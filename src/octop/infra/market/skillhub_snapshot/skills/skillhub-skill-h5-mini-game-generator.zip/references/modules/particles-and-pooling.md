# 粒子/特效与对象池模块

> 本模块提供对象池、粒子系统、特效和空间分区的实现模式，适用于需要频繁创建/销毁对象的游戏类型（shooter / tower-defense / runner / fighting）。

---

## 1. 对象池实现模式

### 1.1 为什么需要对象池

| 场景 | 无对象池 | 有对象池 |
|------|---------|---------|
| 子弹（每帧创建/销毁数十个） | GC 抖动严重 | 零分配 |
| 粒子（每帧创建数百个） | 帧率暴跌 | 稳定 60fps |
| 敌人（频繁生成/死亡） | 内存碎片 | 内存稳定 |

**核心原理**：预分配一批对象，用 `active` 标记管理生命周期，`acquire()` 取出、`release()` 归还，永不 `new`。

### 1.2 通用对象池

```javascript
// js/utils/ObjectPool.js
class ObjectPool {
  /**
   * @param {Function} factory - 创建对象的工厂函数
   * @param {Function} reset - 重置对象状态的函数
   * @param {number} initialSize - 预分配数量
   */
  constructor(factory, reset, initialSize = 0) {
    this.factory = factory;
    this.reset = reset;
    this.pool = [];
    this.active = new Set();

    for (let i = 0; i < initialSize; i++) {
      this.pool.push(factory());
    }
  }

  acquire() {
    let obj;
    if (this.pool.length > 0) {
      obj = this.pool.pop();
    } else {
      obj = this.factory();  // 池空时才创建（极少发生）
    }
    this.active.add(obj);
    return obj;
  }

  release(obj) {
    if (this.active.has(obj)) {
      this.reset(obj);
      this.active.delete(obj);
      this.pool.push(obj);
    }
  }

  releaseAll() {
    for (const obj of this.active) {
      this.reset(obj);
      this.pool.push(obj);
    }
    this.active.clear();
  }

  // 遍历所有活跃对象
  forEachActive(fn) {
    for (const obj of this.active) fn(obj);
  }

  get activeCount() { return this.active.size; }
}
```

### 1.3 专用对象池示例

#### 子弹池（固定大小，丢弃策略）

```javascript
// js/utils/BulletPool.js
class BulletPool {
  constructor(size = 200) {
    this.size = size;
    this.bullets = Array.from({ length: size }, () => ({
      x: 0, y: 0, vx: 0, vy: 0,
      damage: 1, owner: 'player', active: false,
    }));
  }

  acquire(x, y, vx, vy, owner = 'player', damage = 1) {
    const b = this.bullets.find(b => !b.active);
    if (!b) return null;  // 池满，丢弃（优于扩容）
    b.x = x; b.y = y; b.vx = vx; b.vy = vy;
    b.owner = owner; b.damage = damage; b.active = true;
    return b;
  }

  release(b) { b.active = false; }

  updateAll(dt, canvasW, canvasH) {
    for (const b of this.bullets) {
      if (!b.active) continue;
      b.x += b.vx * dt / 1000;
      b.y += b.vy * dt / 1000;
      // 超出屏幕回收
      if (b.x < -20 || b.x > canvasW + 20 || b.y < -20 || b.y > canvasH + 20) {
        this.release(b);
      }
    }
  }

  renderAll(ctx) {
    // 批量绘制：先玩家子弹，再敌人子弹
    ctx.fillStyle = '#0f0';
    for (const b of this.bullets) {
      if (b.active && b.owner === 'player') {
        ctx.fillRect(b.x - 2, b.y - 6, 4, 12);
      }
    }
    ctx.fillStyle = '#f00';
    for (const b of this.bullets) {
      if (b.active && b.owner === 'enemy') {
        ctx.fillRect(b.x - 2, b.y - 2, 4, 4);
      }
    }
  }
}
```

#### 粒子池（大容量）

```javascript
// js/utils/ParticlePool.js
class ParticlePool {
  constructor(size = 500) {
    this.size = size;
    this.particles = Array.from({ length: size }, () => ({
      x: 0, y: 0, vx: 0, vy: 0,
      life: 0, maxLife: 0,
      size: 0, color: '', gravity: 0, alpha: 1,
      active: false,
    }));
  }

  spawn(x, y, vx, vy, life, size, color, gravity = 0) {
    const p = this.particles.find(p => !p.active);
    if (!p) return null;
    p.x = x; p.y = y; p.vx = vx; p.vy = vy;
    p.life = life; p.maxLife = life;
    p.size = size; p.color = color; p.gravity = gravity;
    p.alpha = 1; p.active = true;
    return p;
  }

  updateAll(dt) {
    const dts = dt / 1000;
    for (const p of this.particles) {
      if (!p.active) continue;
      p.x += p.vx * dts;
      p.y += p.vy * dts;
      p.vy += p.gravity * dts;
      p.life -= dt;
      p.alpha = Math.max(0, p.life / p.maxLife);
      if (p.life <= 0) p.active = false;
    }
  }

  renderAll(ctx) {
    // 按颜色分组批量绘制
    const colorGroups = {};
    for (const p of this.particles) {
      if (!p.active) continue;
      if (!colorGroups[p.color]) colorGroups[p.color] = [];
      colorGroups[p.color].push(p);
    }
    for (const [color, group] of Object.entries(colorGroups)) {
      ctx.fillStyle = color;
      for (const p of group) {
        ctx.globalAlpha = p.alpha;
        ctx.fillRect(p.x - p.size/2, p.y - p.size/2, p.size, p.size);
      }
    }
    ctx.globalAlpha = 1;
  }
}
```

### 1.4 对象池使用建议

| 对象类型 | 池大小 | 池满策略 |
|---------|--------|---------|
| 子弹 | 100-300 | 丢弃新子弹 |
| 粒子 | 300-1000 | 丢弃新粒子 |
| 敌人 | 20-50 | 丢弃新敌人 |
| 弹道（塔防） | 50-100 | 丢弃新弹道 |
| 障碍物（跑酷） | 10-20 | 丢弃新障碍 |

---

## 2. 粒子系统

### 2.1 粒子发射器

```javascript
// js/utils/ParticleEmitter.js
class ParticleEmitter {
  constructor(pool, config) {
    this.pool = pool;
    this.config = config;  // 发射参数
    this.emitTimer = 0;
    this.active = false;
  }

  // 在指定位置发射粒子
  burst(x, y, count) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = this._randomRange(this.config.speedRange);
      this.pool.spawn(
        x, y,
        Math.cos(angle) * speed,
        Math.sin(angle) * speed,
        this._randomRange(this.config.lifeRange),
        this._randomRange(this.config.sizeRange),
        this._randomColor(this.config.colors),
        this.config.gravity || 0,
      );
    }
  }

  // 持续发射（每帧调用）
  emit(x, y, dt) {
    this.emitTimer += dt;
    const interval = 1000 / this.config.rate;  // 每秒发射率
    while (this.emitTimer >= interval) {
      this.emitTimer -= interval;
      this.burst(x, y, 1);
    }
  }

  _randomRange([min, max]) {
    return min + Math.random() * (max - min);
  }

  _randomColor(colors) {
    return colors[Math.floor(Math.random() * colors.length)];
  }
}
```

### 2.2 发射模式

| 模式 | 公式 | 适用场景 |
|------|------|---------|
| **点发射** | 随机角度 `Math.random() * π * 2` | 爆炸 |
| **圆周发射** | 均匀角度 `i / count * π * 2` | 冲击波 |
| **锥形发射** | 中心角度 ± 半锥角 | 喷射、火焰 |
| **线段发射** | 沿线段随机点 + 垂直方向 | 尾迹 |

```javascript
// 锥形发射
emitCone(x, y, direction, halfAngle, count) {
  for (let i = 0; i < count; i++) {
    const angle = direction + (Math.random() - 0.5) * 2 * halfAngle;
    const speed = this._randomRange(this.config.speedRange);
    this.pool.spawn(x, y,
      Math.cos(angle) * speed, Math.sin(angle) * speed, ...);
  }
}
```

### 2.3 粒子运动方程

```javascript
// 标准粒子运动（每帧更新）
p.x += p.vx * dt / 1000;        // 位置更新
p.y += p.vy * dt / 1000;
p.vy += p.gravity * dt / 1000;  // 重力
p.life -= dt;                    // 生命衰减
p.alpha = p.life / p.maxLife;   // 透明度随生命递减

// 可选：粒子缩小
p.size *= 0.98;
```

---

## 3. 爆炸特效

### 3.1 爆炸配置模板

```javascript
// 爆炸特效预设
const EXPLOSION_PRESETS = {
  // 小型爆炸（普通敌机）
  small: {
    particleCount: 12,
    speedRange: [80, 200],
    sizeRange: [2, 4],
    lifeRange: [200, 400],
    colors: ['#ff6600', '#ff0000', '#ffaa00'],
    gravity: 0,
  },
  // 大型爆炸（Boss）
  large: {
    particleCount: 40,
    speedRange: [100, 400],
    sizeRange: [3, 8],
    lifeRange: [400, 800],
    colors: ['#ff6600', '#ff0000', '#ffaa00', '#ffff00', '#ffffff'],
    gravity: 200,
  },
  // 击中火花
  hit: {
    particleCount: 6,
    speedRange: [50, 150],
    sizeRange: [1, 3],
    lifeRange: [100, 200],
    colors: ['#ffff00', '#ffffff'],
    gravity: 0,
  },
};

// 触发爆炸
function createExplosion(pool, x, y, presetName) {
  const preset = EXPLOSION_PRESETS[presetName];
  const emitter = new ParticleEmitter(pool, preset);
  emitter.burst(x, y, preset.particleCount);
}
```

### 3.2 冲击波（扩散圆环）

```javascript
class Shockwave {
  constructor(x, y, maxRadius, life, color) {
    this.x = x; this.y = y;
    this.radius = 0;
    this.maxRadius = maxRadius;
    this.life = life;
    this.maxLife = life;
    this.color = color;
    this.active = true;
  }
  update(dt) {
    this.life -= dt;
    this.radius = this.maxRadius * (1 - this.life / this.maxLife);
    if (this.life <= 0) this.active = false;
  }
  render(ctx) {
    ctx.strokeStyle = this.color;
    ctx.globalAlpha = this.life / this.maxLife;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(this.x, this.y, Math.max(0.1, this.radius), 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }
}
```

### 3.3 与游戏模板结合

| 游戏类型 | 爆炸类型 | 触发时机 |
|---------|---------|---------|
| shooter | 小爆炸 + 冲击波 | 敌机被击毁 |
| shooter | 大爆炸 + 多波冲击波 | Boss 死亡 |
| tower-defense | 小爆炸 | 敌人被弹道命中 |
| fighting | 击中火花 | 攻击命中对手 |
| runner | 尘土粒子 | 角色落地 |

---

## 4. 拖尾特效

### 4.1 方式 A：历史位置连线

```javascript
class TrailRenderer {
  constructor(maxLength, color, width) {
    this.points = [];
    this.maxLength = maxLength;
    this.color = color;
    this.width = width;
  }

  addPoint(x, y) {
    this.points.push({ x, y });
    if (this.points.length > this.maxLength) {
      this.points.shift();
    }
  }

  render(ctx) {
    if (this.points.length < 2) return;
    ctx.strokeStyle = this.color;
    ctx.lineWidth = this.width;
    ctx.lineCap = 'round';

    for (let i = 1; i < this.points.length; i++) {
      const alpha = i / this.points.length;
      ctx.globalAlpha = alpha;
      ctx.beginPath();
      ctx.moveTo(this.points[i-1].x, this.points[i-1].y);
      ctx.lineTo(this.points[i].x, this.points[i].y);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
}
```

### 4.2 方式 B：残留 Canvas

```javascript
// 每帧在离屏 Canvas 上画半透明遮罩（产生残留拖尾效果）
class FadeTrail {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
  }
  // 每帧先淡化
  fade(alpha = 0.15) {
    this.ctx.fillStyle = `rgba(0,0,0,${alpha})`;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
  }
}
```

### 4.3 拖尾适用场景

| 方式 | 性能 | 效果 | 适用 |
|------|------|------|------|
| 历史位置连线 | 低 | 精细线条 | 子弹拖尾、剑气 |
| 残留 Canvas | 极低 | 模糊光晕 | 速度线、霓虹效果 |
| 粒子发射 | 中 | 烟雾拖尾 | 引擎尾焰、奔跑尘土 |

---

## 5. 空间分区优化

### 5.1 问题

暴力碰撞检测是 O(n×m)（如 200 颗子弹 × 50 个敌人 = 10000 次/帧），对象数量大时会成为瓶颈。

### 5.2 网格哈希（SpatialGrid）

将屏幕划分为网格，只检测同网格及相邻网格内的对象。

```javascript
// js/utils/SpatialGrid.js
class SpatialGrid {
  constructor(cellSize) {
    this.cellSize = cellSize;
    this.grid = new Map();
  }

  _key(cx, cy) {
    return `${cx},${cy}`;  // 或 cx * 100000 + cy（数值键更快）
  }

  // 插入对象
  insert(obj) {
    const cx = Math.floor(obj.x / this.cellSize);
    const cy = Math.floor(obj.y / this.cellSize);
    const key = this._key(cx, cy);
    if (!this.grid.has(key)) this.grid.set(key, []);
    this.grid.get(key).push(obj);
  }

  // 查询某位置周围的对象
  query(x, y, range) {
    const results = [];
    const minCx = Math.floor((x - range) / this.cellSize);
    const maxCx = Math.floor((x + range) / this.cellSize);
    const minCy = Math.floor((y - range) / this.cellSize);
    const maxCy = Math.floor((y + range) / this.cellSize);
    for (let cx = minCx; cx <= maxCx; cx++) {
      for (let cy = minCy; cy <= maxCy; cy++) {
        const cell = this.grid.get(this._key(cx, cy));
        if (cell) results.push(...cell);
      }
    }
    return results;
  }

  // 清空（每帧重建）
  clear() { this.grid.clear(); }
}
```

### 5.3 使用示例

```javascript
// 碰撞检测优化：子弹 vs 敌人
function checkCollisions(bullets, enemies) {
  const grid = new SpatialGrid(64);  // 64px 网格
  grid.clear();

  // 将敌人插入网格
  for (const enemy of enemies) {
    if (enemy.active) grid.insert(enemy);
  }

  // 每颗子弹只检测附近网格的敌人
  for (const bullet of bullets) {
    if (!bullet.active) continue;
    const nearby = grid.query(bullet.x, bullet.y, bullet.radius + 32);
    for (const enemy of nearby) {
      if (checkAABB(bullet, enemy)) {
        enemy.takeDamage(bullet.damage);
        bullets.release(bullet);
        break;
      }
    }
  }
}
```

### 5.4 性能对比

| 对象数量 | 暴力检测 | 网格哈希 | 提升 |
|---------|---------|---------|------|
| 50 | 2500 次/帧 | ~500 次/帧 | 5x |
| 200 | 40000 次/帧 | ~2000 次/帧 | 20x |
| 500 | 250000 次/帧 | ~5000 次/帧 | 50x |

> **网格大小选择**：`cellSize` 应略大于最大对象的尺寸。常见值 32-128px。

### 5.5 四叉树（简述）

适用于对象分布极不均匀的场景（如大量对象集中在屏幕一侧）。实现复杂度高于网格哈希，在大多数 H5 小游戏中网格哈希已足够。如需实现，参考四叉树的空间递归 subdivde 机制。

---

## 6. 与游戏模板结合总表

| 游戏类型 | 对象池 | 粒子特效 | 空间分区 |
|---------|--------|---------|---------|
| shooter | BulletPool + EnemyPool + ParticlePool | 爆炸 + 冲击波 + 子弹拖尾 | ✅ 网格哈希 |
| tower-defense | ProjectilePool + EnemyPool | 命中火花 + 塔射击特效 | ✅ 塔范围查询 |
| runner | ObstaclePool + CoinPool | 尘土 + 速度线 | ❌（对象少） |
| fighting | ParticlePool + HitSparkPool | 击中火花 + 招式拖尾 | ❌（仅 2 角色） |
