#!/usr/bin/env python3
"""
tracking.json 数据分析引擎
读取 video-performance.json，输出多维度复盘报告。

用法：
  python analyze_tracking.py <tracking_json_path> [--latest N] [--since YYYY-MM-DD]

输出：
  1. 单期明细（播放/完播/互动/粉丝转化）
  2. 跨平台效率对比
  3. 趋势分析（较上期/较均值）
  4. 异常检测（显著偏离均值的条目）
  5. 可蒸馏经验判定
"""

import json, sys, os, io, time
from datetime import datetime, timedelta
from collections import defaultdict

t0 = time.time()

# Fix Windows GBK encoding for emoji output
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

PLATFORM_NAMES = {
    'shipinhao': '视频号',
    'douyin': '抖音',
    'toutiao': '头条',
    'xiaohongshu': '小红书',
}

def load_tracking(path: str) -> dict:
    if not os.path.exists(path):
        print(f"错误: tracking.json 不存在: {path}")
        sys.exit(1)
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def safe_get(d, key, default=0):
    return d.get(key, default) if d else default


def calc_engagement(platform_data: dict) -> float:
    """互动率 = (点赞+评论+分享) / 播放 * 100"""
    views = safe_get(platform_data, 'views', 0)
    if views == 0:
        return 0.0
    likes = safe_get(platform_data, 'likes', 0)
    comments = safe_get(platform_data, 'comments', 0)
    shares = safe_get(platform_data, 'shares', 0)
    return round((likes + comments + shares) / views * 100, 2)


def calc_like_rate(platform_data: dict) -> float:
    """点赞率 = 点赞 / 播放 * 100"""
    views = safe_get(platform_data, 'views', 0)
    if views == 0:
        return 0.0
    return round(safe_get(platform_data, 'likes', 0) / views * 100, 2)


def format_num(n) -> str:
    if n >= 10000:
        return f'{n/10000:.1f}万'
    if n >= 1000:
        return f'{n/1000:.1f}k'
    return str(n)


def analyze(data: dict, since_date: str = None, latest_n: int = None) -> dict:
    """核心分析逻辑，返回结构化结果"""
    episodes = data.get('episodes', [])
    if not episodes:
        return {'error': 'tracking.json 中无 episode 数据'}

    # 过滤
    if since_date:
        episodes = [e for e in episodes if e['date'] >= since_date]
    if latest_n:
        episodes = episodes[-latest_n:]

    # ─── 1. 单期明细 ───
    rows = []
    platform_totals = defaultdict(lambda: {'views': 0, 'likes': 0, 'comments': 0,
                                            'shares': 0, 'completion_sum': 0, 'count': 0})

    for ep in episodes:
        row = {'id': ep.get('id', ''), 'title': ep['title'], 'date': ep['date'],
               'platforms': {}}
        for plat_key, plat_data in ep.get('platforms', {}).items():
            views = safe_get(plat_data, 'views')
            completion = safe_get(plat_data, 'completion_rate')
            eng = calc_engagement(plat_data)
            lr = calc_like_rate(plat_data)

            row['platforms'][plat_key] = {
                'views': views, 'completion_rate': completion,
                'engagement': eng, 'like_rate': lr,
                'likes': safe_get(plat_data, 'likes'),
                'comments': safe_get(plat_data, 'comments'),
                'shares': safe_get(plat_data, 'shares'),
            }

            pt = platform_totals[plat_key]
            pt['views'] += views
            pt['likes'] += safe_get(plat_data, 'likes')
            pt['comments'] += safe_get(plat_data, 'comments')
            pt['shares'] += safe_get(plat_data, 'shares')
            pt['completion_sum'] += completion
            pt['count'] += 1

        rows.append(row)

    # ─── 2. 平台效率 ───
    platform_efficiency = {}
    for pk, pt in platform_totals.items():
        if pt['count'] > 0:
            platform_efficiency[pk] = {
                'name': PLATFORM_NAMES.get(pk, pk),
                'count': pt['count'],
                'total_views': pt['views'],
                'avg_views': round(pt['views'] / pt['count']),
                'avg_completion': round(pt['completion_sum'] / pt['count'], 1),
                'avg_engagement': round(
                    (pt['likes'] + pt['comments'] + pt['shares']) / pt['views'] * 100, 2
                ) if pt['views'] > 0 else 0,
            }

    # ─── 3. 趋势分析 ───
    trend = {}
    if len(rows) >= 2:
        latest = rows[-1]
        prev = rows[-2]
        for pk in latest['platforms']:
            if pk in prev.get('platforms', {}):
                curr_v = latest['platforms'][pk]['views']
                prev_v = prev['platforms'][pk]['views']
                curr_c = latest['platforms'][pk]['completion_rate']
                prev_c = prev['platforms'][pk]['completion_rate']
                trend[pk] = {
                    'views_change': round((curr_v - prev_v) / prev_v * 100, 1) if prev_v > 0 else None,
                    'completion_change': round(curr_c - prev_c, 1),
                }

    # ─── 4. 异常检测 ───
    anomalies = []
    # 计算各平台均值和标准差
    plat_stats = defaultdict(list)
    for row in rows:
        for pk, pd in row['platforms'].items():
            plat_stats[pk].append({
                'views': pd['views'], 'completion': pd['completion_rate'],
                'engagement': pd['engagement'], 'id': row['id'], 'title': row['title'],
            })

    for pk, entries in plat_stats.items():
        if len(entries) < 3:
            continue
        views_list = [e['views'] for e in entries]
        comp_list = [e['completion'] for e in entries]
        eng_list = [e['engagement'] for e in entries]

        avg_v = sum(views_list) / len(views_list)
        avg_c = sum(comp_list) / len(comp_list)
        avg_e = sum(eng_list) / len(eng_list) if any(eng_list) else 0

        for e in entries:
            flags = []
            if e['views'] > avg_v * 2:
                flags.append(f"🔥播放爆炸(+{round((e['views']-avg_v)/avg_v*100)}%)")
            elif avg_v > 0 and e['views'] < avg_v * 0.4:
                flags.append(f"📉播放低迷(-{round((avg_v-e['views'])/avg_v*100)}%)")

            if e['completion'] > 0 and e['completion'] > avg_c + 10:
                flags.append(f"⭐完播率优异(+{round(e['completion']-avg_c,1)}pp)")
            elif e['completion'] > 0 and e['completion'] < avg_c - 10:
                flags.append(f"⚠️完播率偏低(-{round(avg_c-e['completion'],1)}pp)")

            if avg_e > 0 and e['engagement'] > avg_e * 2:
                flags.append(f"💬互动井喷(+{round((e['engagement']-avg_e)/avg_e*100)}%)")

            if flags:
                anomalies.append({
                    'id': e['id'], 'title': e['title'], 'platform': PLATFORM_NAMES.get(pk, pk),
                    'flags': flags,
                })

    # ─── 5. 跨平台覆盖分析 ───
    cross_coverage = defaultdict(int)
    for ep in episodes:
        plat_count = len(ep.get('platforms', {}))
        cross_coverage[plat_count] += 1

    # ─── 6. 完播-互动象限 ───
    quadrants = defaultdict(list)
    for row in rows:
        for pk, pd in row['platforms'].items():
            comp = pd['completion_rate']
            eng = pd['engagement']
            if comp >= 40 and eng >= 5:
                q = '⭐ 高完播+高互动'
            elif comp >= 40 and eng < 5:
                q = '📖 高完播+低互动'
            elif comp < 40 and eng >= 5:
                q = '💬 低完播+高互动'
            else:
                q = '⚠️ 低完播+低互动'
            quadrants[q].append({'id': row['id'], 'title': row['title'],
                                 'platform': PLATFORM_NAMES.get(pk, pk)})

    return {
        'summary': {
            'total_episodes': len(rows),
            'date_range': f"{rows[0]['date']} ~ {rows[-1]['date']}" if rows else 'N/A',
            'platform_coverage': dict(cross_coverage),
        },
        'rows': rows,
        'platform_efficiency': platform_efficiency,
        'trend': trend,
        'anomalies': anomalies,
        'quadrants': quadrants,
    }


def print_report(result: dict, tracking_path: str):
    """格式化输出复盘报告"""
    global t0
    if 'error' in result:
        print(result['error'])
        return

    s = result['summary']
    rows = result['rows']
    pe = result['platform_efficiency']
    trend = result['trend']
    anomalies = result['anomalies']
    quadrants = result['quadrants']

    print(f"""
╔══════════════════════════════════════════════════════════╗
║            📊 视频发布后复盘报告                           ║
║            数据源: {os.path.basename(tracking_path)}                          ║
║            分析时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}                      ║
╚══════════════════════════════════════════════════════════╝

## 一、概览
- 分析范围: {s['date_range']}
- 视频总数: {s['total_episodes']} 期
- 平台覆盖: {', '.join(f'{k}平台={v}期' for k, v in sorted(s['platform_coverage'].items()))}
""")

    # 单期明细
    print("## 二、单期明细\n")
    for row in rows:
        print(f"### {row['id']} | {row['date']} | {row['title'][:40]}")
        print(f"| 平台 | 播放 | 完播率 | 互动率 | 点赞 | 评论 | 分享 |")
        print(f"|------|------|--------|--------|------|------|------|")
        for pk, pd in row['platforms'].items():
            pname = PLATFORM_NAMES.get(pk, pk)
            print(f"| {pname} | {format_num(pd['views'])} | {pd['completion_rate']}% | {pd['engagement']}% | {pd['likes']} | {pd['comments']} | {pd['shares']} |")
        print()

    # 跨平台效率
    print("## 三、平台效率对比\n")
    print(f"| 平台 | 视频数 | 总播放 | 均播放 | 均完播率 | 均互动率 |")
    print(f"|------|--------|--------|--------|----------|----------|")
    for pk in ['shipinhao', 'douyin', 'toutiao', 'xiaohongshu']:
        if pk in pe:
            e = pe[pk]
            print(f"| {e['name']} | {e['count']} | {format_num(e['total_views'])} | {format_num(e['avg_views'])} | {e['avg_completion']}% | {e['avg_engagement']}% |")
    print()

    # 趋势
    if trend:
        print("## 四、趋势分析（最新 vs 上期）\n")
        for pk in ['shipinhao', 'douyin', 'toutiao', 'xiaohongshu']:
            if pk in trend:
                t = trend[pk]
                v_sign = '↗️' if (t['views_change'] or 0) > 0 else '↘️'
                c_sign = '↗️' if (t['completion_change'] or 0) > 0 else '↘️'
                print(f"- {PLATFORM_NAMES.get(pk, pk)}: 播放 {v_sign}{t['views_change']}% | 完播率 {c_sign}{t['completion_change']}pp")
        print()

    # 异常
    if anomalies:
        print("## 五、异常标记\n")
        for a in anomalies:
            print(f"- [{a['platform']}] {a['id']} {a['title'][:30]}: {' / '.join(a['flags'])}")
        print()

    # 象限
    if quadrants:
        print("## 六、完播-互动象限\n")
        for q_name, items in sorted(quadrants.items(), reverse=True):
            if items:
                print(f"### {q_name} ({len(items)}条)")
                for item in items:
                    print(f"- [{item['platform']}] {item['id']} {item['title'][:30]}")
                print()

    # 可蒸馏经验提示
    print("## 七、蒸馏检查\n")
    print("> 检查本次复盘发现是否与 MEMORY.md 已有规律一致，或新规律是否已出现 ≥2 次。")
    print("> Agent 将在流程 E4 中执行蒸馏判定。")

    print(f"\n{'─' * 60}")

    # ⏱️ 耗时日志（P2-6 修复）
    elapsed = round(time.time() - t0, 2)
    print(f"\n⏱️ E段分析引擎耗时：{elapsed}s")


def main():
    if len(sys.argv) < 2:
        print("用法: python analyze_tracking.py <tracking_json> [--latest N] [--since YYYY-MM-DD]")
        print("示例: python analyze_tracking.py data/tracking/video-performance.json --latest 5")
        sys.exit(1)

    tracking_path = sys.argv[1]
    since_date = None
    latest_n = None

    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == '--since' and i + 1 < len(sys.argv):
            since_date = sys.argv[i + 1]
            i += 2
        elif sys.argv[i] == '--latest' and i + 1 < len(sys.argv):
            latest_n = int(sys.argv[i + 1])
            i += 2
        else:
            i += 1

    data = load_tracking(tracking_path)
    result = analyze(data, since_date=since_date, latest_n=latest_n)
    print_report(result, tracking_path)


if __name__ == '__main__':
    main()
