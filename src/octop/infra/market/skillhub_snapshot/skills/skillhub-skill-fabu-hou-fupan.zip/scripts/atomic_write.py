#!/usr/bin/env python3
"""
atomic_write.py — F段写操作原子化与并发安全工具
版本：1.0 (2026-06-14)
用途：
  1. fcntl/msvcrt 5s 阻塞锁，杜绝两个复盘并发写穿
  2. tmp + os.replace() 原子重命名，杜绝写一半中断损坏
  3. 写后回读 3 行断言，杜绝"内容截断/静默丢失" bug
  4. usage/usage_md 追加走 append_file_atomic（单次追加模式）

依赖：Windows 上 fcntl 由 msvcrt 模拟（lock/unlock + 重试）
"""
import os
import sys
import time
import tempfile
from pathlib import Path

# 平台自适应锁
if sys.platform == 'win32':
    import msvcrt
    _USE_FCNTL = False
else:
    import fcntl
    _USE_FCNTL = True

LOCK_TIMEOUT_SEC = 5
LOCK_RETRY_INTERVAL = 0.2


def _lock_file(fh):
    """对已打开的文件句柄加排他锁（阻塞最多 LOCK_TIMEOUT_SEC）"""
    deadline = time.time() + LOCK_TIMEOUT_SEC
    while True:
        try:
            if _USE_FCNTL:
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            else:
                msvcrt.locking(fh.fileno(), msvcrt.LK_LOCK, 1)
            return True
        except (BlockingIOError, OSError, PermissionError):
            if time.time() > deadline:
                return False
            time.sleep(LOCK_RETRY_INTERVAL)


def _unlock_file(fh):
    """释放锁（捕获异常以保证幂等）"""
    try:
        if _USE_FCNTL:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        else:
            msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
    except Exception:
        pass


def _verify_written(path, expected_marker, tail_lines=3):
    """写完回读末尾 N 行，断言 expected_marker 出现在文件中"""
    if not path.exists():
        print(f"  [FAIL] 验证失败：文件不存在 {path}")
        return False
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    if expected_marker not in content:
        print(f"  [FAIL] 验证失败：未找到标记 '{expected_marker}' in {path}")
        return False
    lines = content.splitlines()[-tail_lines:]
    print(f"  [OK] 验证通过：{path.name} 末尾 {tail_lines} 行包含预期标记")
    for ln in lines:
        print(f"     | {ln[:100]}")
    return True


def append_file_atomic(path, block, verify_marker=None):
    """
    原子追加：tmp + os.replace + 锁 + write-verify
    适用于 04/06/07 灵感田文件、usage/YYYY-MM.md 等追加场景
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text('', encoding='utf-8')

    t0 = time.time()

    # 阶段 1：加读锁读原内容（持锁时间极短）
    with open(p, 'r', encoding='utf-8') as fh_r:
        if not _lock_file(fh_r):
            print(f"  [FAIL] 无法获取读锁：{path}（已等待 {LOCK_TIMEOUT_SEC}s）")
            return False
        try:
            original = fh_r.read()
        finally:
            _unlock_file(fh_r)

    # 阶段 2：加写锁 + tmp + 原子替换
    with open(p, 'r+', encoding='utf-8') as fh:
        if not _lock_file(fh):
            print(f"  [FAIL] 无法获取写锁：{path}")
            return False
        try:
            new_content = original + block
            tmp_fd, tmp_path = tempfile.mkstemp(
                prefix=f'.{p.name}.', suffix='.tmp',
                dir=str(p.parent)
            )
            try:
                with os.fdopen(tmp_fd, 'w', encoding='utf-8') as tf:
                    tf.write(new_content)
                # 关键：Windows 下必须先关闭原文件句柄再 os.replace
                fh.close()
                os.replace(tmp_path, p)
            except Exception:
                if os.path.exists(tmp_path):
                    try:
                        os.unlink(tmp_path)
                    except Exception:
                        pass
                raise
        finally:
            try:
                _unlock_file(fh)
            except Exception:
                pass

    elapsed = round(time.time() - t0, 2)
    print(f"  [TIME] 追加完成 {p.name}（{elapsed}s, +{len(block)} chars）")
    if verify_marker:
        return _verify_written(p, verify_marker)
    return True


def replace_block_atomic(path, old, new, verify_marker=None):
    """
    原子替换：用 new 替换文件中第一个 old 出现的位置。
    适用于 MEMORY.md 蒸馏、publish_log.json 状态字段更新。
    """
    p = Path(path)
    if not p.exists():
        print(f"  [FAIL] 文件不存在：{path}")
        return False

    t0 = time.time()
    with open(p, 'r+', encoding='utf-8') as fh:
        if not _lock_file(fh):
            print(f"  [FAIL] 无法获取锁：{path}")
            return False
        try:
            fh.seek(0)
            content = fh.read()
            if old not in content:
                print(f"  [FAIL] 旧字符串未找到：{old[:50]}...")
                return False
            updated = content.replace(old, new, 1)
            tmp_fd, tmp_path = tempfile.mkstemp(
                prefix=f'.{p.name}.', suffix='.tmp',
                dir=str(p.parent)
            )
            try:
                with os.fdopen(tmp_fd, 'w', encoding='utf-8') as tf:
                    tf.write(updated)
                fh.close()
                os.replace(tmp_path, p)
            except Exception:
                if os.path.exists(tmp_path):
                    try:
                        os.unlink(tmp_path)
                    except Exception:
                        pass
                raise
        finally:
            try:
                _unlock_file(fh)
            except Exception:
                pass

    elapsed = round(time.time() - t0, 2)
    print(f"  [TIME] 替换完成 {p.name}（{elapsed}s, -{len(old)}/+{len(new)} chars）")
    if verify_marker:
        return _verify_written(p, verify_marker)
    return True


def update_json_atomic(path, patch_fn, verify_marker=None):
    """
    JSON 安全读改写：加锁读取 JSON → patch_fn(doc) 原地修改 → tmp+os.replace 原子写回。
    适用于 publish_log.json 的 performance / meta.pred_qa / meta.prediction_reconciliation 等字段 upsert。
    并发安全：沿用 5s 阻塞锁；原子性：tmp+os.replace；写后回读断言（verify_marker 可选）。
    """
    import json as _json
    p = Path(path)
    if not p.exists():
        print(f"  [FAIL] 文件不存在：{path}")
        return False

    t0 = time.time()
    with open(p, 'r+', encoding='utf-8') as fh:
        if not _lock_file(fh):
            print(f"  [FAIL] 无法获取锁：{path}")
            return False
        try:
            fh.seek(0)
            doc = _json.load(fh)
            patch_fn(doc)  # 原地修改 doc（如 upsert entries[N].performance / meta.*）
            tmp_fd, tmp_path = tempfile.mkstemp(
                prefix=f'.{p.name}.', suffix='.tmp',
                dir=str(p.parent)
            )
            try:
                with os.fdopen(tmp_fd, 'w', encoding='utf-8') as tf:
                    _json.dump(doc, tf, ensure_ascii=False, indent=2)
                fh.close()
                os.replace(tmp_path, p)
            except Exception:
                if os.path.exists(tmp_path):
                    try:
                        os.unlink(tmp_path)
                    except Exception:
                        pass
                raise
        finally:
            try:
                _unlock_file(fh)
            except Exception:
                pass

    elapsed = round(time.time() - t0, 2)
    print(f"  [TIME] JSON 更新完成 {p.name}（{elapsed}s）")
    if verify_marker:
        return _verify_written(p, verify_marker)
    return True


def self_test():
    """自测：追加 + 替换 + 异常处理"""
    import tempfile as tf
    test_dir = tf.mkdtemp(prefix='atomic_test_')
    test_file = os.path.join(test_dir, 'test.md')
    Path(test_file).write_text('initial\n', encoding='utf-8')

    ok1 = append_file_atomic(test_file, '\n# new block\n', verify_marker='new block')
    ok2 = replace_block_atomic(test_file, 'initial', 'INITIAL', verify_marker='INITIAL')
    ok3 = replace_block_atomic(test_file, 'NOTFOUND', 'X')
    print(f"\n自测结果：追加={ok1} 替换={ok2} 异常处理={not ok3}（预期 False）")
    return ok1 and ok2 and not ok3


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'selftest':
        sys.exit(0 if self_test() else 1)
    print("Usage: python atomic_write.py selftest")
