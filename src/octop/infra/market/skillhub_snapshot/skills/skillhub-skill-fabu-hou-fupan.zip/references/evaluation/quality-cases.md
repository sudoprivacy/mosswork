# 复盘系统 · 效果测评用例集

> 覆盖三个 SKILL：视频数据追踪 → 复盘向导 → 发布后复盘
> 评分方式：三阶段串联，逐段验证

---

## 正常场景（3 条）

### Q-N01：完整复盘流程（数据驱动选题）

**流程**：Excel 拖入 → 视频数据追踪解析 → tracking.json 入库 → 复盘向导触发 → D 段硬阻断 → E 段分析 → F 段回流

**核心验证**：
- 视频数据追踪：Excel 解析 0 失败
- 发布后复盘 D3.5：tracking 数据完整性通过
- 发布后复盘 D4：milestones.review_completed 写入 + 审计字段完整
- 发布后复盘 F4：review-calibration.md 已更新
- 发布后复盘 F4.5：creation-state.json feedback_influence 已同步
- 发布后复盘 F5：deliverables/复盘问题/ 文件已生成

**预期**：全流程通过，无 ❌

### Q-N02：首次运行复盘

**流程**：tracking.json 不存在 → 首次运行豁免

**核心验证**：
- 视频数据追踪：创建 tracking.json
- 发布后复盘 D3.5：首次运行豁免通过
- 正常进入 E 段分析

**预期**：E2/E3 标注「样本<3仅供参考」，跳过 E4 蒸馏

### Q-N03：同一天多条复盘

**流程**：同一天发布 2 条视频 → 48h 后分别复盘

**核心验证**：
- F5 文件命名：`YYYY-MM-DD_{video_id}.md` 格式，不覆盖
- publish_log：两条各有独立的 milestones.review_completed

**预期**：2 条记录独立，文件不覆盖

---

## 边界场景（3 条）

### Q-E01：数据源全不可用

**条件**：tracking.json 存在但所有平台播放量 = 0

**预期**：D3.5 门禁 → data_status: "corrupted"，禁入 E 段

### Q-E02：介于 12h~48h 窗口

**条件**：发布时间 23h 前

**预期**：D2 通过，正常复盘

### Q-E03：样本不足（<3条有效记录）

**条件**：publish_log 中仅 2 条有 review_completed

**预期**：E2 红线保留但标注「样本少仅供参考」，E3 标注「样本<3」

---

## 错误场景（3 条）

### Q-ERR01：<12h 复盘 → D2 阻断

**条件**：发布时间 6h 前

**预期**：D2 闸刀 → ⛔ 终止，输出「数据未成熟」

### Q-ERR02：Excel 解析失败 → D3 阻断

**条件**：Excel 格式异常，解析脚本 exit code ≠ 0

**预期**：D3 → meta.data_status: "failed"，终止

### Q-ERR03：creation-state.json 不可写 → F4.5 失败

**条件**：creation-state.json 被锁定或不存在

**预期**：F4.5 报错 → F 段标注 ⚠️，但 publish_log 仍标记 reviewed（不因 state 同步失败阻断核心复盘）

---

## 版本

| 版本 | 日期 |
|------|------|
| v1.0 | 2026-07-05 |
