#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一书一技能 · 敏感词机检 v1.0（含豁免机制）
退出码: 0=通过/豁免; 1=HARD拦截; 2=免责缺失/危机缺热线
"""
import sys, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
DICT_PATH = os.path.join(HERE, "sensitive-words.md")
EXEMPT_MARK = "<!-- SCAN_EXEMPT -->"

DISCLAIMER_MUST = ["仅供参考", "不构成", "不替代"]

CRISIS_L3 = ["想结束生命", "计划好了", "准备好了", "结束生命", "遗书"]
CRISIS_L2 = ["撑不住了", "不想活", "活不下去", "没意思了", "熬不过去"]

HOTLINES = ["12356", "400-161-9995"]

def load_dict():
    hard, soft = [], []
    mode = None
    try:
        for line in open(DICT_PATH, encoding="utf-8"):
            s = line.strip()
            if s.startswith("## HARD"): mode = "hard"; continue
            if s.startswith("## SOFT"): mode = "soft"; continue
            if s.startswith("#") or not s: continue
            if mode == "hard": hard.append(s)
            elif mode == "soft": soft.append(s)
    except OSError:
        return [], []
    hard = [w for line in hard for w in re.split(r"[、,，]", line) if w.strip()]
    soft = [w for line in soft for w in re.split(r"[、,，]", line) if w.strip()]
    return hard, soft

def head_has_exempt(path):
    try:
        with open(path, encoding="utf-8") as f:
            for n, line in enumerate(f):
                if n >= 12: break
                if EXEMPT_MARK in line: return True
    except OSError:
        return False
    return False

def has_crisis_l3(t): return any(w in t for w in CRISIS_L3)
def has_crisis_l2(t): return any(w in t for w in CRISIS_L2)
def crisis_hotline_ok(t): return all(h in t for h in HOTLINES)
def structure_words(t):
    return any(w in t for w in ["画像", "拆解", "步骤", "建议下一步", "清单如下", "解析如下"])

def main():
    text = ""
    if "--stdin" in sys.argv:
        text = sys.stdin.read()
    elif "--file" in sys.argv:
        i = sys.argv.index("--file")
        fpath = sys.argv[i + 1]
        if head_has_exempt(fpath):
            print("【豁免】含 SCAN_EXEMPT 标记，exit 0。")
            sys.exit(0)
        with open(fpath, encoding="utf-8") as f:
            text = f.read()
    elif len(sys.argv) > 1 and not sys.argv[1].startswith("--"):
        text = sys.argv[1]

    hard_only = "--hard-only" in sys.argv
    hard, soft = load_dict()
    hh = [w for w in hard if w in text]
    ss = [w for w in soft if w in text]
    if hh:
        print("【拦截 HARD】", ", ".join(hh)); sys.exit(1)
    if ss:
        print("【提醒 SOFT】", ", ".join(ss))

    if has_crisis_l3(text):
        if not crisis_hotline_ok(text):
            print("拦截 三级危机缺热线"); sys.exit(2)
        if structure_words(text):
            print("拦截 三级危机仍输出产物"); sys.exit(2)
    elif has_crisis_l2(text) and not crisis_hotline_ok(text):
        print("拦截 二级危机缺热线"); sys.exit(2)

    if crisis_hotline_ok(text) and not structure_words(text) and (
        "真人帮助" in text or has_crisis_l2(text) or has_crisis_l3(text)):
        print("结论：危机应急句放行。"); sys.exit(0)

    if not hard_only:
        missing = [k for k in DISCLAIMER_MUST if k not in text]
        if missing:
            print("【拦截 免责缺失】", ", ".join(missing)); sys.exit(2)

    print("结论：通过。HARD=0。"); sys.exit(0)

if __name__ == "__main__":
    main()
