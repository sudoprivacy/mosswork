# 自媒体发布审核｜Media Publish Review

> 发抖音、小红书、视频号、快手、B站、微博或知乎之前，先让 AI 审一遍——告诉你能不能发、问题在哪、怎么改。

**你有没有遇到过这些问题？**

- 精心剪辑的视频发出去就被限流，不知道哪句话踩了线？
- 带货直播话术写了半天，不确定"全网最低价"能不能说？
- 用了 AI 生成的封面，不知道要不要标注、怎么标注？
- 同一条内容要发三个平台，每个平台规则都不一样？

**自媒体发布审核** 就是为了解决这些问题。它是一个 AI Agent 技能，覆盖国内 7 大主流平台，帮你在发布前完成合规检查、风险定位和一键改稿。

直接上传成片、图文、文章、字幕、口播稿、封面或链接，Skill 检查文字、画面、音轨、来源、授权、AI 使用、商业关系与平台差异，给出简洁、可执行的修改结论——不是扔给你一张违禁词表让你自己查，而是直接告诉你**改哪里、怎么改、改完能不能发**。

## 为什么你需要它

| 痛点 | 自媒体发布审核怎么帮你 |
|---|---|
| 🔇 发完就限流，不知道为什么 | 发布前定位敏感词、违规表述和平台红线，附修改稿 |
| 📋 不确定要不要标 AI/转载/广告 | 按国标 GB 45438-2025 和各平台规则，给出具体标注建议 |
| 🔄 同一内容发多个平台太麻烦 | 一次审核输出多平台适配方案，指出每个平台要改的地方 |
| 💰 带货话术怕踩广告法 | 检查绝对化表述、功效宣称、价格话术和赠品合规 |
| ❓ 低播放不知道是限流还是内容问题 | 区分官方处置、版权限制和普通表现，给诊断建议 |
| 📝 发布前不知道该查什么 | 按内容类型输出发布前自检清单，逐项可勾选 |

## 一句话结果，先给结论

```text
结论：审核没问题，可以直接发。
```

或：

```text
结论：不建议直接发。
问题 1：00:12｜出现了什么 → 怎么改
问题 2：第 2 张图｜出现了什么 → 怎么改
修改稿：可直接复制的版本
待确认：只写会改变结论的缺失信息
```

## 七大平台，一次覆盖

| 平台 | 审核重点 |
|---|---|
| 抖音 | 口播、字幕、首帧、画面、音乐、导流、来源与发布标注 |
| 小红书 | 图文/笔记、种草真实性、合作关系、封面、标签与站外信息 |
| 微信视频号 | 视频、来源与演绎标识、微信生态内发布能力、音乐与授权 |
| 快手 | 短视频、直播、商品信息、互动福利、私下交易与权利素材 |
| B站 | 中长视频、二创版权、分区匹配、弹幕引导、花火商业合作 |
| 微博 | 时事来源真实性、超话话题匹配、营销号治理、网暴防范 |
| 知乎 | 回答专业性、抄袭洗稿、好物推荐佣金关系、答题匹配度 |

## 能审什么

- 成片视频、短视频、直播切片、音频；
- 图片、封面、多图笔记、图文；
- 文章、标题、正文、标签、字幕、口播稿、评论区话术；
- 转载、翻译、二创、第三方音乐/图片/视频素材；
- 带货、商品卡、团购、秒杀、赠品、抽奖与直播话术；
- AI 图片、AI 视频、数字人、AI 配音、换脸、拟声；
- 账号/作品通知后的官方复查与低播放诊断。

## 安装

### 给 Coding Agent 的一句话

```text
请安装这个 skill：
https://github.com/louiseliu/media-publish-review.git
```

### 使用 skills CLI

```bash
npx -y skills@latest add louiseliu/media-publish-review \
  --skill media-publish-review \
  --agent codex \
  --global
```

### 使用 skhub CLI

```bash
skhub add louiseliu/media-publish-review
```

## 怎么用

### 1. 直接审一条视频

```text
使用 $media-publish-review 审核我上传的视频。
我要发抖音，请检查口播、字幕、封面、画面、音乐、AI 标注、授权和导流。
先只给我"能不能直接发 + 最多 3 个问题 + 可直接替换的修改稿"。
```

### 2. 审查小红书图文笔记

```text
使用 $media-publish-review 审核这篇小红书笔记。
请检查标题、正文、图片、标签、商业合作关系和站外导流。
给我可以直接发的修改版。
```

### 3. 审核 B站视频

```text
使用 $media-publish-review 审核这个要发B站的视频。
检查版权素材、分区选择、商业合作标注和弹幕引导。
```

### 4. 多平台适配

```text
使用 $media-publish-review，这条内容我要同时发抖音和小红书。
请分别给我两个平台的审核结论和修改稿。
```

### 5. 审带货或直播话术

```text
使用 $media-publish-review 审核这段快手直播话术和商品卡。
检查价格、库存、赠品、抽奖、互动条件和站外交易风险。
```

## 它会特别检查

- **短视频发布标注**：虚构演绎、AI 生成、营销信息、转载、个人观点或无需标注；
- **事实与来源**：时事、公共政策、社会事件、旧闻、拍摄时间地点；
- **权利**：转载、音乐、影视片段、图片、字体、肖像、隐私与授权范围；
- **商业内容**：广告、赞助、返佣、绝对化表述、功效、价格、库存、福利；
- **高风险领域**：医疗、金融、法律、教育等内容的资质、证据与表达边界；
- **发布适配**：跨平台名称、二维码、账号、外部跳转、商品卡、标题和封面；
- **低播放诊断**：先分清官方处置、资格/版权限制与普通内容表现。

## 设计原则

1. **先审证据，再下结论**：看过什么，就只对什么负责。
2. **先给动作，再讲规则**：默认不超过 3 个最高优先级问题。
3. **词表只做候选**：单词命中不等于违规；最终结合语境、画面、音轨、权利与平台判断。
4. **平台规则与运营经验分开**：不把民间经验伪装成官方规则。
5. **不提供绕审方法**：不把谐音、暗号、隐藏文字或二维码遮挡包装成"过审技巧"。

## 适用边界

- 这是发布前审核与改稿工具，不替代平台最终审核、律师意见或持证专业人士意见；
- 规则、发布页和行业要求会变化，遇到高风险事项时引导用户回到对应平台或监管官方入口复查；
- "转载""个人观点""AI 标识"等声明不能自动修复侵权、虚假、无资质或违法广告问题；
- 对内容的真实性、授权与商业材料，发布者仍应自行留存证明。

## 项目结构

```text
media-publish-review/
├── SKILL.md                     # Skill 主流程
├── agents/openai.yaml           # Codex/Agent 展示信息
├── references/                  # 法律基线、平台规则、声明、输出格式
│   ├── legal-baseline.md
│   ├── risk-taxonomy.md
│   ├── media-inspection.md
│   ├── disclosure-library.md
│   ├── output-schema.md
│   ├── platform-douyin.md
│   ├── platform-xiaohongshu.md
│   ├── platform-weixin-video-accounts.md
│   ├── platform-kuaishou.md
│   ├── platform-bilibili.md
│   ├── platform-weibo.md
│   ├── platform-zhihu.md
│   ├── platform-mention-policy.md
│   ├── platform-fit-guide.md
│   ├── distribution-diagnostics.md
│   ├── live-commerce-review.md
│   ├── knowledge-intake-standard.md
│   ├── official-recheck-routes.md
│   ├── term-patterns.json
│   ├── pre-publish-checklist.md   # 发布前自检清单
│   ├── compliance-scorecard.md    # 合规评分卡
│   └── aigc-labeling-guide.md     # AIGC 标识操作指南
├── scripts/
│   ├── preflight.py             # 文本候选预检
│   ├── test_preflight.py        # 预检行为测试
│   └── test_skill_contract.py   # 结构回归测试
└── docs/                        # 文档
```

## 独有功能

这些功能是本项目独立设计的，在已有同类项目中未见：

| 功能 | 说明 |
|---|---|
| **发布前自检清单** | 按内容类型（视频/图文/直播/文章）和平台输出可勾选的 ✓⚠✗ 清单 |
| **合规评分卡** | 法律合规、平台规则、权利授权、商业合规、内容质量五维度量化评分 |
| **AIGC 标识操作指南** | 对齐 GB 45438-2025 国标，附各平台操作入口和常见场景判断 |
| **AIGC 关键词检测** | 预检脚本自动检测 AI 工具/技术关键词，提醒标识需求 |
| **文本预检评分** | 预检脚本输出快速合规评分，辅助判断优先修改方向 |

## 参考与致谢

本项目在设计过程中研究和参考了以下优秀开源项目的理念，感谢这些项目对社区的贡献：

| 项目 | 参考内容 |
|---|---|
| [XshuiAi/media-publish-check](https://github.com/XshuiAi/media-publish-check) | 自媒体审核 Skill 的基础理念：R0-R4 风险分级、六选一标注门、严格平台专属模式 |
| [safaiyeh/app-store-review-skill](https://github.com/safaiyeh/app-store-review-skill) | Pre-Submission Checklist（发布前清单）的设计模式和风险等级分类 |
| [xixihhhh/clipforge](https://github.com/xixihhhh/clipforge) | 合规默认开的理念、AIGC 国标对齐、广告法违禁词扫描、限流自检评分 |
| [blacktwist/social-media-skills](https://github.com/blacktwist/social-media-skills) | 多平台内容策略的组织方式 |

本项目在上述参考基础上做了大量原创工作：扩展至 7 个国内平台、设计了独立的合规评分卡体系、创建了 AIGC 标识操作指南、开发了自检清单模式，并专注于国内自媒体场景做了深度适配。

## 本地验证

```bash
python3 -m unittest discover -s scripts -p 'test_*.py' -v
```

## 更新日志

查看 [CHANGELOG.md](CHANGELOG.md)。

## License

[MIT](LICENSE)
