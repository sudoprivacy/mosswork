"""附加边界，不计入固定100分；失败时阻止验收。全部本地隔离。"""
import copy, json, subprocess, sys, tempfile, unittest
from pathlib import Path
from openpyxl import Workbook, load_workbook
from test_autoresearch_regressions import g, lookup, minutes, tracker, task, hist, snap, plan, content, SKILL

class Holdout(unittest.TestCase):
    def test_clear_uses_structured_and_verifies(self):
        before=snap([dict(task(),追踪人='示例追踪人')])
        p=plan([{'任务编号':'TASK-999','追踪人':''}],mode='update',fields=['追踪人']); p['allow_clear_reason']='会议明确取消'
        payload,m=g.prepare(p,before)
        self.assertEqual(m['transport'],'structured_json'); self.assertEqual(json.loads(payload)[0]['任务编号'],'TASK-999')
        self.assertTrue(g.verify_payload(payload,m,before)['passed'])
        after=copy.deepcopy(before); after['overview'][0]['追踪人']=''
        self.assertTrue(g.audit(before,after,[m])['passed'])

    def test_partial_completion_retry_only_missing(self):
        rows=[task('TASK-998'),task('TASK-999')]; latest=snap([rows[0]])
        payload,m=g.prepare(plan(rows),latest)
        self.assertEqual(m['row_keys'],['TASK-999']); self.assertEqual(m['skipped_unchanged_keys'],['TASK-998'])
        after=snap(rows); self.assertTrue(g.audit(latest,after,[m])['passed'])
        self.assertEqual(g.prepare(plan(rows),after)[0],'')

    def test_zero_changes_no_reservation(self):
        payload,m=g.prepare(plan([]),snap()); self.assertTrue(g.verify_payload(payload,m,snap())['passed'])
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'state.json'; g.transition(p,'planned',manifest=m)
            with self.assertRaises(ValueError):g.transition(p,'reserved',record_id='MUST-NOT-CREATE')

    def test_manifest_tampering_fails_check_and_audit(self):
        payload,m=g.prepare(plan([task()]),snap()); m['expected_values'][0]['负责人']='错误负责人'
        with self.assertRaises(ValueError):g.verify_payload(payload,m,snap())
        self.assertFalse(g.audit(snap(),snap([task()]),[m])['passed'])

    def test_journal_rejects_other_batch_and_tamper(self):
        _,m=g.prepare(plan([task()]),snap()); _,other=g.prepare(plan([task('TASK-888')]),snap())
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'state.json'; g.transition(p,'planned',manifest=m); g.transition(p,'write_unknown')
            wrong=g.audit(snap(),snap([task('TASK-888')]),[other])
            with self.assertRaises(ValueError):g.transition(p,'verified',evidence=wrong)
            state=json.loads(p.read_text(encoding='utf-8')); state['state']='planned'; p.write_text(json.dumps(state),encoding='utf-8')
            with self.assertRaises(ValueError):g.transition(p,'write_unknown')

    def test_legacy_audit_cannot_complete(self):
        _,m=g.prepare(plan([task()]),snap())
        evidence=g.audit(snap(),snap([task()]),[{'expected_new_tasks':['TASK-999']}])
        self.assertEqual(evidence['verification_level'],'keys_only')
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'state.json'; g.transition(p,'planned',manifest=m); g.transition(p,'write_unknown')
            with self.assertRaises(ValueError):g.transition(p,'verified',evidence=evidence)

    def test_empty_week_creates_no_fake_actions(self):
        c=content(); c['action_items']=[]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'zero.xlsx'; tracker.build_tracker(c,p); tracker.validate_workbook(p,0)
            wb=load_workbook(p); self.assertEqual(wb.active.max_row,1); wb.close()
            minutes.build_weekly_minutes(c,Path(d)/'zero.docx')

    def test_duplicate_and_closed_handoff_rejected(self):
        c=content(); c['action_items']*=2
        with self.assertRaises(ValueError):minutes.validate_action_links(c)
        c=content(); c['action_items'][0]['来源']='承接上周-01'
        c['prior_action_items']=[{'编号':'上周-01','事项':'示例事项','负责人':'示例负责人','原定时限':'原时限','进展状态':'已完成'}]
        with self.assertRaises(ValueError):minutes.validate_action_links(c)

    def test_structured_preserves_multiline_text(self):
        row=task(); row['任务事项']='=示例文字\n第二行\t第三列文字'
        p=plan([row]); p['transport']='structured_json'; payload,m=g.prepare(p,snap())
        self.assertEqual(json.loads(payload)[0]['任务事项'],row['任务事项'])
        self.assertTrue(g.verify_payload(payload,m,snap())['passed'])
        self.assertTrue(g.audit(snap(),snap([row]),[m])['passed'])

    def test_tsv_several_rows_quotes_no_extra_line(self):
        rows=[task('TASK-'+str(i)) for i in (996,997,998)]
        for row in rows:row['任务事项']='含"引号"\n带换行\t带制表符'
        payload,m=g.prepare(plan(rows),snap()); self.assertEqual(m['row_count'],3); self.assertFalse(payload.endswith('\n'))
        self.assertTrue(g.verify_payload(payload,m,snap())['passed'])

    def test_numeric_id_with_alpha_suffix_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'q.xlsx'; wb=Workbook(); ws=wb.active; ws.title=lookup.SEARCH_SHEETS[0]
            ws.append(['唯一编号','客户名称']); ws.append(['PRJ-0422A','示例甲有限公司']); wb.save(p)
            self.assertEqual(lookup.search(p,['422'])['422'],{})

    def test_cli_audit_cannot_overwrite_snapshot(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'before.json'; p.write_text(json.dumps(snap()),encoding='utf-8'); old=p.read_bytes()
            m=Path(d)/'m.json'; m.write_text('{}',encoding='utf-8')
            r=subprocess.run([sys.executable,str(SKILL/'scripts/wecom_sync_guard.py'),'audit','--before',str(p),'--after',str(p),'--manifests',str(m),'--out',str(p)],capture_output=True)
            self.assertNotEqual(r.returncode,0); self.assertEqual(p.read_bytes(),old)

    def test_snapshot_invalid_record_rejected(self):
        for bad in ({'overview':[1],'history':[]},{'overview':[],'history':[{'任务编号':[]}]}):
            with self.assertRaises(ValueError):g.prepare(plan([]),bad)

    def test_new_history_and_parent_together(self):
        before=snap(); _,a=g.prepare(plan([task()]),before); _,b=g.prepare(plan([hist()],target='history'),before)
        self.assertTrue(g.audit(before,snap([task()],[hist()]),[a,b])['passed'])

if __name__=='__main__':unittest.main()
