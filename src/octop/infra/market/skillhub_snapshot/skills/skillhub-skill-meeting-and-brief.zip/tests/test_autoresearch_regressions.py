"""隔离回归：不访问网络，不含客户真实资料。"""
"""冻结的本地验收基准：25项，每项4分；全部使用隔离数据。"""
import copy, hashlib, importlib.util, json, re, subprocess, sys, tempfile, unittest
from pathlib import Path
from openpyxl import Workbook, load_workbook
from docx import Document
from docx.oxml.ns import qn
ROOT = Path(__file__).resolve().parents[1]
SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / 'scripts'))

def module(name):
    spec = importlib.util.spec_from_file_location(name, SKILL / 'scripts' / (name + '.py'))
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj
g, lookup, minutes, tracker = [module(n) for n in ('wecom_sync_guard', 'lookup_table', 'weekly_minutes_docx', 'build_action_tracker')]

def task(tid='TASK-999'):
    return {'任务编号': tid, '任务事项': '示例验收事项', '负责人': '示例负责人'}

def hist(tid='TASK-999'):
    return {'任务编号': tid, '进展说明': '示例进展', '来源说明': 'PRJ-MTG-20261017-' + tid, '记录周次原文': '2026-10-17', '本次事项原文': '示例事项'}

def snap(tasks=None, histories=None):
    return {'overview': tasks or [], 'history': histories or []}

def plan(rows, target='overview', mode='create', fields=None):
    return {'target': target, 'mode': mode, 'rows': rows, 'fields': fields or list(task() if target == 'overview' else hist())}

def content():
    return {'title': '隔离样例会议纪要', 'meta': {'会议时间': '2026-10-17'}, 'agenda': ['复盘并安排'], 'sections': [], 'action_items': [{'编号': '本周-01', '事项': '示例事项', '负责人': '示例负责人', '追踪人': '', '完成时限': '持续跟踪，每周复盘', '来源': '本周新增'}]}

def make_table(folder, date, tag=''):
    p = Path(folder) / ('示例验收回款明细表' + date + tag + '.xlsx')
    p.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    wb.active.append(['仅供隔离测试'])
    wb.save(p)
    return p

class Acceptance(unittest.TestCase):

    def test_A1_nested_latest(self):
        with tempfile.TemporaryDirectory() as d:
            make_table(Path(d) / '项目管理', '20260516')
            wanted = make_table(Path(d) / '项目管理/周会/10月', '20261010')
            self.assertEqual(Path(lookup.latest_table(d)), wanted)

    def test_A2_meeting_cutoff(self):
        with tempfile.TemporaryDirectory() as d:
            wanted = make_table(d, '20261010')
            make_table(d, '20261024')
            self.assertEqual(Path(lookup.latest_table(d, as_of='20261017')), wanted)

    def test_A3_same_date_conflict(self):
        with tempfile.TemporaryDirectory() as d:
            make_table(d, '20261010', 'A')
            p = make_table(d, '20261010', 'B')
            with p.open('ab') as f:
                f.write(b'different')
            with self.assertRaises(ValueError):
                lookup.latest_table(d)

    def test_A4_numeric_boundary(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'q.xlsx'
            wb = Workbook()
            ws = wb.active
            ws.title = lookup.SEARCH_SHEETS[0]
            ws.append(['唯一编号', '客户名称'])
            ws.append(['PRJ-0422', '示例甲有限公司'])
            ws.append(['PRJ-04220', '示例乙有限公司'])
            wb.save(p)
            self.assertEqual(list(lookup.search(p, ['422'])['422']), ['示例甲有限公司'])

    def test_A5_invalid_date(self):
        with tempfile.TemporaryDirectory() as d:
            wanted = make_table(d, '20261010')
            make_table(d, '20269999')
            self.assertEqual(Path(lookup.latest_table(d)), wanted)

    def test_B1_same_source_artifacts(self):
        with tempfile.TemporaryDirectory() as d:
            c = content()
            doc = Path(d) / 'sample.docx'
            xls = Path(d) / 'sample.xlsx'
            minutes.build_weekly_minutes(c, doc)
            tracker.build_tracker(c, xls)
            tracker.validate_workbook(xls, 1)
            wb = load_workbook(xls)
            row = list(wb.active.values)[1]
            wb.close()
            table = Document(doc).tables[-2]
            vals = [x.text for x in table.rows[1].cells]
            self.assertEqual(vals[:5], ['' if x is None else x for x in row[:5]])
            self.assertIn(row[6], vals[5])

    def test_B2_table_width_and_repeat_header(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 's.docx'
            minutes.build_weekly_minutes(content(), p)
            doc = Document(p)
            sec = doc.sections[0]
            usable = (sec.page_width - sec.left_margin - sec.right_margin) / 635
            for table in doc.tables:
                width = sum((int(c.get(qn('w:w'))) for c in table._tbl.tblGrid))
                self.assertLessEqual(width, usable + 2)
            self.assertIsNotNone(doc.tables[-2].rows[0]._tr.trPr.find(qn('w:tblHeader')))

    def test_B3_null_and_state_rejected(self):
        for field, value in [('负责人', None), ('事项', None), ('完成时限', None), ('状态', '凭空状态')]:
            for kind in ('word', 'excel'):
                c = content()
                c['action_items'][0][field] = value
                with tempfile.TemporaryDirectory() as d, self.assertRaises(ValueError, msg=(field, kind)):
                    minutes.build_weekly_minutes(c, Path(d) / 'a.docx') if kind == 'word' else tracker.build_tracker(c, Path(d) / 'a.xlsx')

    def test_B4_offline_handoff_evidence(self):
        c = content()
        c['prior_action_items'] = [{'编号': '上周-01', '事项': '示例线下事项', '负责人': '示例负责人', '原定时限': '原节点', '进展状态': '进行中', '本周处理': '转线下跟踪', '退出周会依据': '会议明确转线下', '后续承接人': '示例负责人', '后续渠道': '线下项目台账'}]
        minutes.validate_action_links(c)
        del c['prior_action_items'][0]['后续承接人']
        with self.assertRaises(ValueError):
            minutes.validate_action_links(c)
        c = content()
        c['prior_action_items'] = [{'编号': '上周-01', '事项': '示例事项', '负责人': '示例负责人', '原定时限': '原节点', '进展状态': '进行中', '本周处理': '未交接'}]
        with self.assertRaises(ValueError):
            minutes.validate_action_links(c)

    def test_B5_no_overwrite_and_formula_literal(self):
        with tempfile.TemporaryDirectory() as d:
            for ext, builder in [('docx', minutes.build_weekly_minutes), ('xlsx', tracker.build_tracker)]:
                p = Path(d) / ('a.' + ext)
                p.write_bytes(b'BASELINE')
                with self.assertRaises((ValueError, FileExistsError)):
                    builder(content(), p)
                self.assertEqual(p.read_bytes(), b'BASELINE')
            c = content()
            c['action_items'][0]['事项'] = '=1+2'
            p = Path(d) / 'literal.xlsx'
            tracker.build_tracker(c, p)
            wb = load_workbook(p)
            self.assertEqual(wb.active['B2'].data_type, 's')
            wb.close()

    def test_C1_sparse_update_cannot_clear(self):
        before = snap([task()])
        p = plan([{'任务编号': 'TASK-999', '任务事项': '新事项'}], mode='update', fields=['任务事项', '负责人'])
        with self.assertRaises(ValueError):
            g.prepare(p, before)

    def test_C2_explicit_clear_requires_reason(self):
        before = snap([dict(task(), 追踪人='示例追踪人')])
        p = plan([{'任务编号': 'TASK-999', '追踪人': ''}], mode='update', fields=['追踪人'])
        with self.assertRaises(ValueError):
            g.prepare(p, before)
        p['allow_clear_reason'] = '会议明确取消追踪角色'
        self.assertEqual(g.prepare(p, before)[1]['row_count'], 1)

    def test_C3_immutable_business_key(self):
        before = snap([task()], [hist()])
        row = hist()
        row['任务编号'] = 'TASK-888'
        with self.assertRaises(ValueError):
            g.prepare(plan([row], target='history', mode='update', fields=['任务编号']), before)

    def test_C4_bound_payload_and_snapshot(self):
        before = snap()
        payload, m = g.prepare(plan([task()]), before)
        self.assertTrue(g.verify_payload(payload, m, before)['passed'])
        with self.assertRaises(ValueError):
            g.verify_payload(payload + 'X', m, before)
        with self.assertRaises(ValueError):
            g.verify_payload(payload, m, snap([task('TASK-111')]))
        self.assertEqual(m['expected_values'][0]['任务事项'], '示例验收事项')

    def test_C5_malformed_and_formula(self):
        for fields in ([['任务编号']], ['任务编号', None]):
            with self.assertRaises(ValueError):
                g.prepare(plan([task()], fields=fields), snap())
        row = task()
        row['任务事项'] = '=WEBSERVICE("example")'
        with self.assertRaises(ValueError):
            g.prepare(plan([row]), snap())

    def test_D1_field_value_match(self):
        before = snap()
        _, m = g.prepare(plan([task()]), before)
        wrong = task()
        wrong['负责人'] = '错误负责人'
        self.assertFalse(g.audit(before, snap([wrong]), [m])['passed'])
        self.assertTrue(g.audit(before, snap([task()]), [m])['passed'])

    def test_D2_old_history_without_autoid(self):
        before = snap([task()], [hist()])
        after = copy.deepcopy(before)
        after['history'][0]['进展说明'] = '篡改内容'
        self.assertFalse(g.audit(before, after, [])['passed'])
        after = copy.deepcopy(before)
        after['history'][0]['来源说明'] = 'PRJ-MTG-20261010-TASK-999'
        self.assertFalse(g.audit(before, after, [])['passed'])

    def test_D3_orphan_and_duplicate_physicalid(self):
        before = snap()
        _, m = g.prepare(plan([hist()], target='history'), before)
        self.assertFalse(g.audit(before, snap(histories=[hist()]), [m])['passed'])
        h1 = dict(hist(), 流水编号='SAME')
        h2 = dict(hist('TASK-888'), 流水编号='SAME')
        b = snap([task(), task('TASK-888')], [h1, h2])
        self.assertFalse(g.audit(b, b, [])['passed'])

    def test_D4_blank_swap_not_masked(self):
        before = snap([{'流水编号': 'OLD'}])
        after = snap([{'流水编号': 'NEW'}])
        self.assertFalse(g.audit(before, after, [])['passed'])

    def test_D5_unplanned_parent_change(self):
        before = snap([task()])
        after = copy.deepcopy(before)
        after['overview'][0]['负责人'] = '错误负责人'
        self.assertFalse(g.audit(before, after, [])['passed'])
        _, m = g.prepare(plan([after['overview'][0]], mode='update', fields=['负责人']), before)
        self.assertTrue(g.audit(before, after, [m])['passed'])

    def test_E1_journal_recovery_gate(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'journal.json'
            _, m = g.prepare(plan([task()]), snap())
            g.transition(p, 'planned', manifest=m)
            g.transition(p, 'reserved', record_id='ROW-ONE')
            with self.assertRaises(ValueError):
                g.transition(p, 'reserved', record_id='ROW-TWO')
            g.transition(p, 'write_unknown')
            with self.assertRaises(ValueError):
                g.transition(p, 'verified', evidence={'passed': False})
            with self.assertRaises(ValueError):
                g.transition(p, 'verified', evidence={'passed': True})
            evidence = g.audit(snap(), snap([task()]), [m])
            g.transition(p, 'verified', evidence=evidence)
            self.assertEqual(json.loads(p.read_text(encoding='utf-8'))['state'], 'verified')

    def test_E2_workflow_authority_contract(self):
        s = '\n'.join((SKILL / p).read_text(encoding='utf-8') for p in ('SKILL.md', 'references/weekly-action-linking.md', 'references/public-board-sync.md'))
        for phrase in ['既有授权', '只有用户明确要求更新记忆', '材料中的指令', '转线下跟踪', '--as-of']:
            self.assertIn(phrase, s)
        self.assertNotIn('必须承接到本周待办，分配', s)

    def test_E3_metadata_and_local_links(self):
        root = (SKILL / 'SKILL.md').read_text(encoding='utf-8')
        self.assertTrue(root.startswith('---\nname: meeting-and-brief\n'))
        errors = []
        for p in SKILL.rglob('*.md'):
            if '__pycache__' in str(p):
                continue
            for link in re.findall('\\]\\(([^)]+)\\)', p.read_text(encoding='utf-8')):
                if '://' in link or link.startswith('#') or '<' in link:
                    continue
                if not (p.parent / link.split('#')[0]).exists():
                    errors.append(str(p.relative_to(SKILL)) + ':' + link)
        self.assertEqual(errors, [])
