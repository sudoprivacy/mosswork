"""隔离数据：不调用任何线上接口。"""
import copy
import importlib.util
from pathlib import Path
import unittest
import tempfile
import zipfile
import re

SPEC = importlib.util.spec_from_file_location('guard', Path(__file__).parents[1] / 'scripts/wecom_sync_guard.py')
guard = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(guard)


def task(tid='TASK-999'):
    return {'任务编号': tid, '任务事项': '示例验收事项', '负责人': '示例负责人'}


def history(tid='TASK-999'):
    return {'流水编号': 'AUTO-1', '任务编号': tid, '进展说明': '示例进展',
            '来源说明': 'PRJ-MTG-20261017-' + tid + '｜示例来源',
            '记录周次原文': '2026-10-17', '本次事项原文': '示例验收事项'}


def empty():
    return {'overview': [], 'history': []}


def plan(rows, target='overview'):
    fields = list(task()) if target == 'overview' else [f for f in history() if f != '流水编号']
    return {'target': target, 'mode': 'create', 'fields': fields, 'rows': rows}


class GuardTests(unittest.TestCase):
    def test_export_with_stale_dimension_still_reads_real_rows(self):
        from openpyxl import Workbook
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'snapshot.xlsx'
            wb = Workbook(); wb.active.title = guard.SHEETS['overview']
            wb.active.append(list(task())); wb.active.append(list(task().values()))
            sheet = wb.create_sheet(guard.SHEETS['history'])
            sheet.append(list(history())); sheet.append(list(history().values()))
            wb.save(path)
            with zipfile.ZipFile(path) as z:
                contents = {name: z.read(name) for name in z.namelist()}
            for name in list(contents):
                if name.startswith('xl/worksheets/') and name.endswith('.xml'):
                    contents[name] = re.sub(rb'<dimension ref="[^"]+"', b'<dimension ref="A1"', contents[name])
            with zipfile.ZipFile(path, 'w') as z:
                for name, data in contents.items(): z.writestr(name, data)
            snapshot = guard.load_snapshot(path)
            self.assertEqual(len(snapshot['overview']), 1)
            self.assertEqual(len(snapshot['history']), 1)

    def test_empty_batch_creates_no_rows(self):
        payload, manifest = guard.prepare(plan([]), empty())
        self.assertEqual(payload, '')
        self.assertEqual(manifest['row_count'], 0)

    def test_trailing_blank_inputs_removed_without_extra_line(self):
        payload, manifest = guard.prepare(plan([task(), {}, None, {'任务事项': '\u200b \n'}]), empty())
        self.assertEqual(manifest['filtered_blank_inputs'], 3)
        self.assertEqual(manifest['row_count'], 1)
        self.assertFalse(payload.endswith('\n'))

    def test_partial_task_is_rejected_not_dropped(self):
        with self.assertRaises(ValueError):
            guard.prepare(plan([{'任务编号': 'TASK-999'}]), empty())

    def test_missing_owner_rejected(self):
        row = task(); row.pop('负责人')
        with self.assertRaises(ValueError):
            guard.prepare(plan([row]), empty())

    def test_embedded_newline_tab_and_quotes_round_trip(self):
        row = task(); row['任务事项'] = '示例"范围"\n和\t节点'
        payload, manifest = guard.prepare(plan([row]), empty())
        self.assertEqual(manifest['row_count'], 1)
        self.assertEqual(manifest['normalized_cells'], 1)
        self.assertNotIn('\n', payload)

    def test_duplicate_business_keys_rejected(self):
        with self.assertRaises(ValueError):
            guard.prepare(plan([task(), task()]), empty())

    def test_retry_of_successful_create_has_zero_rows(self):
        before = empty(); before['overview'] = [task()]
        payload, manifest = guard.prepare(plan([task()]), before)
        self.assertEqual(payload, '')
        self.assertEqual(manifest['expected_new_tasks'], [])

    def test_same_key_changed_content_is_conflict(self):
        before = empty(); before['overview'] = [task()]
        row = task(); row['任务事项'] = '另一事项'
        with self.assertRaises(ValueError):
            guard.prepare(plan([row]), before)

    def test_history_readonly_fields_rejected(self):
        p = plan([history()], 'history'); p['fields'].append('流水编号')
        with self.assertRaises(ValueError):
            guard.prepare(p, empty())

    def test_lookup_column_rejected(self):
        p = plan([history()], 'history'); p['fields'].append('项目编号')
        with self.assertRaises(ValueError):
            guard.prepare(p, empty())

    def test_history_requires_source_text(self):
        row = history(); row.pop('本次事项原文')
        with self.assertRaises(ValueError):
            guard.prepare(plan([row], 'history'), empty())

    def test_history_source_key_must_match_task(self):
        row = history(); row['任务编号'] = 'TASK-998'
        with self.assertRaises(ValueError):
            guard.prepare(plan([row], 'history'), empty())

    def test_history_retry_has_zero_rows(self):
        before = empty(); before['history'] = [history()]
        payload, manifest = guard.prepare(plan([history()], 'history'), before)
        self.assertEqual(payload, '')
        self.assertEqual(manifest['expected_new_history_keys'], [])

    def test_autonumber_only_is_placeholder(self):
        self.assertEqual(guard.classify({'流水编号': 'AUTO-2', '创建人': '系统'}, 'history'), 'placeholder')

    def test_history_predating_source_keys_is_not_an_empty_row(self):
        old = {'流水编号': 'AUTO-0', '任务编号': 'TASK-998', '进展说明': '保留旧业务进展'}
        self.assertEqual(guard.classify(old, 'history'), 'legacy_history')

    def test_legacy_original_text_only_is_business_content(self):
        old = {'流水编号': 'AUTO-0', '任务编号': 'TASK-998', '本次事项原文': '旧事项原文'}
        self.assertEqual(guard.classify(old, 'history'), 'legacy_history')

    def test_default_values_do_not_make_a_business_record(self):
        row = {'任务状态': '未启动', '任务进度': 0, '归档': '□'}
        self.assertEqual(guard.classify(row, 'overview'), 'placeholder')

    def test_unnumbered_child_is_preserved(self):
        child = {'上级-任务编号': 'TASK-999', '最近进展': '示例现场条件确认中', '负责人': '示例负责人'}
        before = empty(); before['overview'] = [task(), child]
        self.assertEqual(guard.classify(child, 'overview'), 'subtask')
        self.assertTrue(guard.audit(before, copy.deepcopy(before), [])['passed'])

    def test_one_more_reserved_empty_row_fails(self):
        after = empty(); after['overview'] = [task(), {'归档': '□'}]
        report = guard.audit(empty(), after, [{'expected_new_tasks': ['TASK-999']}])
        self.assertFalse(report['passed'])
        self.assertEqual(report['stats']['overview']['actual_delta'], 2)

    def test_extra_history_autonumber_fails(self):
        after = empty(); after['history'] = [history(), {'流水编号': 'AUTO-2'}]
        self.assertFalse(guard.audit(empty(), after, [{'expected_new_history_keys': [guard.history_key(history())]}])['passed'])

    def test_partial_history_left_by_interruption_fails(self):
        after = empty(); after['history'] = [{'流水编号': 'AUTO-2', '任务编号': 'TASK-999'}]
        self.assertFalse(guard.audit(empty(), after, [])['passed'])

    def test_changed_child_fails(self):
        before = empty(); before['overview'] = [{'上级-任务编号': 'TASK-999', '最近进展': '原内容'}]
        after = copy.deepcopy(before); after['overview'][0]['最近进展'] = '错误覆盖'
        self.assertFalse(guard.audit(before, after, [])['passed'])

    def test_old_history_body_change_fails(self):
        before = empty(); before['history'] = [history()]
        after = copy.deepcopy(before); after['history'][0]['进展说明'] = '错误覆盖'
        self.assertFalse(guard.audit(before, after, [])['passed'])

    def test_existing_placeholder_is_reported_not_deleted(self):
        before = empty(); before['overview'] = [{'归档': '□'}]
        report = guard.audit(before, copy.deepcopy(before), [])
        self.assertTrue(report['passed'])
        self.assertEqual(report['stats']['overview']['before']['placeholder'], 1)

    def test_intended_create_and_unchanged_retry_audits(self):
        after = empty(); after['overview'] = [task()]; after['history'] = [history()]
        manifest = {'expected_new_tasks': ['TASK-999'], 'expected_new_history_keys': [guard.history_key(history())]}
        self.assertTrue(guard.audit(empty(), after, [manifest])['passed'])
        self.assertTrue(guard.audit(after, copy.deepcopy(after), [])['passed'])


if __name__ == '__main__':
    unittest.main()
