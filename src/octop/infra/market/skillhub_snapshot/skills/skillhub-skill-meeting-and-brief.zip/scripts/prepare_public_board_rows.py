#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prepare_public_board_rows.py — 把本周会议纪要的新增事项，准备成「追加到在线公示表末尾」的数据包。

核心职责（解决两个人工易错点）：
  1. **序号接序**：从在线公示表已有记录中解析出全部编号，取最大值 N，
     本周新增事项从 N+1 开始连续编号，**绝不硬编码起始序号**。
  2. **追加不覆盖**：产出的数据行即按"追加在现有内容之后"排序，
     并明确报告追加起始行号；禁止插入已有行之间。

同时做保守去重：本周里"承接上周-XX"的事项若在在线表中已存在同主体条目，
判为「更新」（不占新编号）；高度相似但不完全相同的判为「待人工确认」，
默认不作为新增，避免重复建档。

用法：
  python prepare_public_board_rows.py \
      --online online_main_1003.csv \
      --content 本周追踪事项.json \
      --week "2026.9.26-2026.10.2" \
      --out new_rows.csv --updates-out updates.csv --review-out review.csv

输入说明：
  --online   在线公示表快照 CSV。表头须含 任务编号/任务事项（其余字段缺失即留空）。
  --content  本周追踪事项 JSON，支持 {rows:[...]} 或 {action_items:[...]}；
             每行需含 会议安排事项/负责人/完成时限，追踪人/状态/备注/来源 可选。
"""

import argparse
import csv
import difflib
import io
import json
import os
import re
import sys
from datetime import datetime

# 在线公示表字段（与智能表格 API 层字段名对齐）
ONLINE_FIELDS = [
    "任务编号", "任务事项", "负责人原文", "追踪人原文",
    "计划时限原文", "任务状态", "原表状态", "最后来源周次", "最近进展",
]
KEY_FIELD = "任务事项"

# 在线「任务状态」既存选项（严禁写入表内不存在的选项）
BOARD_STATUS = ["待核实", "未启动", "进行中", "已完成", "阻塞"]

# 本地纪要状态 → 在线既存选项
STATUS_MAP = {
    "未启动": "未启动",
    "进行中": "进行中",
    "阻塞": "阻塞",
    "完成": "已完成",
    "已完成": "已完成",
    "待核实": "待核实",
}

DEFAULT_PROJECT_REGEX = r"\b[A-Za-z]{2,}[-_]?\d{3,}\b"
NUM_RE = re.compile(r"(\d+)")
WS_RE = re.compile(r"[\s　]+")
PUNCT_RE = re.compile(r"[，。；、：？！,.;:?!（）()\[\]【】\"'“”‘’/\\\-—…·]+")


# ---------- 归一化与相似度 ----------

def norm_text(value):
    """归一化：去空白、去标点，用于重复判定（不改变写出的原文）。"""
    s = str(value or "").strip()
    s = WS_RE.sub("", s)
    s = PUNCT_RE.sub("", s)
    return s.lower()


def similarity(a, b):
    """0~1 相似度。任一方为空即 0。"""
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()


# ---------- 读取在线公示表 ----------

def read_online(path):
    """读取在线公示表快照，返回 (记录列表, 最大序号, 编号前缀)。"""
    if not os.path.isfile(path):
        raise FileNotFoundError(f"在线公示表快照不存在：{path}")
    with io.open(path, encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError("在线公示表快照为空")
        if KEY_FIELD not in reader.fieldnames:
            raise ValueError(f"在线公示表缺少必需列「{KEY_FIELD}」，实际列：{reader.fieldnames}")
        rows = [dict(r) for r in reader]

    records = [r for r in rows if str(r.get(KEY_FIELD) or "").strip()]
    max_no = 0
    prefix = "TASK-"
    seen = []
    for r in rows:
        no = str(r.get("任务编号") or "").strip()
        m = NUM_RE.search(no)
        if m:
            n = int(m.group(1))
            seen.append(n)
            if n > max_no:
                max_no = n
                prefix = re.sub(r"\d+", "", no) or "TASK-"
    return records, max_no, prefix, seen


# ---------- 读取本周纪要 ----------

def read_content(path, fallback_week=""):
    with io.open(path, encoding="utf-8-sig") as handle:
        data = json.load(handle)
    rows = data.get("rows")
    if rows is None:
        rows = data.get("action_items")
    if not isinstance(rows, list) or not rows:
        raise ValueError(f"{path} 中未找到 rows / action_items，或为空列表")

    items = []
    for i, r in enumerate(rows, 1):
        if not isinstance(r, dict):
            raise ValueError(f"第 {i} 条必须是对象")
        subject = str(r.get("会议安排事项", r.get("事项", ""))).strip()
        if not subject:
            raise ValueError(f"第 {i} 条缺少「会议安排事项」")
        items.append({
            "编号": str(r.get("编号", "")).strip(),
            "事项": subject,
            "负责人": str(r.get("负责人", r.get("责任人", ""))).strip(),
            "追踪人": str(r.get("追踪人", "")).strip(),
            "完成时限": str(r.get("完成时限", "")).strip(),
            "状态": str(r.get("状态", "")).strip(),
            "来源": str(r.get("来源", "")).strip(),
            "备注": str(r.get("备注", "")).strip(),
        })
    week = str(data.get("week") or "").strip() or fallback_week
    return items, week


# ---------- 列映射 ----------

def map_status(local_status, warnings, label):
    """本地状态 → 在线既存选项；无法映射时保守用「进行中」并告警。"""
    s = str(local_status or "").strip()
    if not s:
        return "未启动"
    if s == "取消":
        raise ValueError(f"{label}：本地状态「取消」不得自动映射为「已完成」，请按目标表已确认口径人工处理")
    if s in STATUS_MAP:
        return STATUS_MAP[s]
    warnings.append(f"{label}：状态「{s}」不在在线表既存选项 {BOARD_STATUS} 中，已回退「进行中」，请人工确认")
    return "进行中"


def to_board_row(no, item, week, warnings, label):
    """本地一条 → 在线公示表一行（字典）。任务状态为单选项 id，脚本不猜测，留空。"""
    return {
        "任务编号": no,
        "任务事项": item["事项"],
        "负责人原文": item["负责人"],
        "追踪人原文": item["追踪人"],
        "计划时限原文": item["完成时限"],
        "任务状态": "",  # 单选 id：在线表写入时按 UI 选项解析，此处留空由写入流程处理
        "原表状态": map_status(item["状态"], warnings, label),
        "最后来源周次": week,
        "最近进展": item["备注"],
    }


def extract_project(text, regex):
    if not regex:
        return ""
    m = re.search(regex, text or "")
    return m.group(0) if m else ""


# ---------- 主流程 ----------

def prepare(online_path, content_path, week_arg, threshold, include_review, project_regex):
    records, max_no, prefix, existing_nos = read_online(online_path)
    items, week = read_content(content_path, week_arg)

    existing_keys = [norm_text(r.get(KEY_FIELD)) for r in records]
    existing_main = [(r, k) for r, k in zip(records, existing_keys) if k]

    warnings = []
    new_rows, updates, reviews = [], [], []
    next_no = max_no + 1
    # 已匹配过的在线记录，防止本周两条同时命中同一在线条目
    claimed = set()

    for idx, item in enumerate(items, 1):
        label = f"{item['编号'] or '第'+str(idx)+'条'}"
        key = norm_text(item["事项"])
        hit = None
        hit_score = 1.0

        # 1) 完全相等 → 判为已有（更新）
        for pos, (rec, k) in enumerate(existing_main):
            if pos in claimed:
                continue
            if k == key:
                hit, hit_score = rec, 1.0
                claimed.add(pos)
                break

        if hit is not None:
            updates.append({
                "已有任务编号": hit.get("任务编号", ""),
                "已有任务事项": hit.get(KEY_FIELD, ""),
                "本次来源": item["来源"] or "本周新增",
                "更新后原表状态": map_status(item["状态"], warnings, label),
                "更新后最近进展": item["备注"],
                "更新后最后来源周次": week,
                "本地编号": label,
            })
            continue

        # 2) 高度相似 → 待人工确认
        best, best_score, best_pos = None, 0.0, None
        for pos, (rec, k) in enumerate(existing_main):
            if pos in claimed:
                continue
            score = similarity(key, k)
            if score > best_score:
                best, best_score, best_pos = rec, score, pos
        if best is not None and best_score >= threshold:
            reviews.append({
                "本地编号": label,
                "本周事项": item["事项"],
                "疑似已有任务编号": best.get("任务编号", ""),
                "疑似已有事项": best.get(KEY_FIELD, ""),
                "相似度": f"{best_score:.2f}",
                "处理": "默认不新增；确认是同一事项请手工合并，确认是新事项请加入本周新增",
            })
            if include_review:
                claimed.add(best_pos)
            else:
                continue

        # 3) 新增：接序编号
        no = f"{prefix}{next_no}"
        row = to_board_row(no, item, week, warnings, label)
        row["_本地编号"] = label
        row["_本次来源"] = item["来源"] or "本周新增"
        row["_项目号"] = extract_project(item["事项"], project_regex)
        new_rows.append(row)
        next_no += 1

    return {
        "records": records, "max_no": max_no, "prefix": prefix,
        "existing_nos": existing_nos, "week": week,
        "new_rows": new_rows, "updates": updates, "reviews": reviews,
        "warnings": warnings, "items": items,
    }


def write_csv(path, fieldnames, rows):
    if not rows:
        return False
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with io.open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return True


def main():
    ap = argparse.ArgumentParser(description="为本周会议纪要准备「追加到在线公示表末尾」的数据包")
    ap.add_argument("--online", required=True, help="在线公示表快照 CSV（须含 任务编号/任务事项）")
    ap.add_argument("--content", required=True, help="本周追踪事项 JSON（rows 或 action_items）")
    ap.add_argument("--week", default="", help="最后来源周次标签，缺省取 JSON 的 week 字段")
    ap.add_argument("--out", default="", help="新增行输出 CSV，缺省 public-board-new-YYYYMMDD.csv")
    ap.add_argument("--updates-out", default="", help="已有行更新输出 CSV")
    ap.add_argument("--review-out", default="", help="疑似重复待确认输出 CSV")
    ap.add_argument("--threshold", type=float, default=0.82, help="疑似重复相似度阈值，默认 0.82")
    ap.add_argument("--include-review", action="store_true", help="把疑似重复也作为新增（默认跳过）")
    ap.add_argument("--project-regex", default=DEFAULT_PROJECT_REGEX,
                    help=f"事项文本中提取项目号的正则，默认 {DEFAULT_PROJECT_REGEX}；不需要请传空串")
    args = ap.parse_args()

    try:
        result = prepare(
            args.online, args.content, args.week,
            args.threshold, args.include_review, args.project_regex,
        )
    except Exception as exc:
        print(f"准备公示表追加数据失败：{exc}", file=sys.stderr)
        raise

    stamp = datetime.now().strftime("%Y%m%d")
    out = args.out or f"public-board-new-{stamp}.csv"
    upd = args.updates_out or f"public-board-updates-{stamp}.csv"
    rev = args.review_out or f"public-board-review-{stamp}.csv"

    records = result["records"]
    print("=" * 64)
    print("在线公示表现状")
    print(f"  已有记录数     : {len(records)}")
    print(f"  已有编号       : {result['prefix']}1 ~ {result['prefix']}{result['max_no']}"
          f"（最大序号 {result['max_no']}）")
    dup_nos = sorted({n for n in result["existing_nos"]
                      if result["existing_nos"].count(n) > 1})
    if dup_nos:
        print(f"  ⚠ 检测到重复编号: {dup_nos[:10]}")
    print(f"  本周周次       : {result['week'] or '（未提供）'}")
    print("-" * 64)
    print("本周处理结果")
    print(f"  本周事项总数   : {len(result['items'])}")
    print(f"  新增           : {len(result['new_rows'])}")
    print(f"  更新已有       : {len(result['updates'])}")
    print(f"  疑似重复待确认 : {len(result['reviews'])}")
    if result["new_rows"]:
        start = len(records) + 1
        first = result["new_rows"][0]["任务编号"]
        last = result["new_rows"][-1]["任务编号"]
        print("-" * 64)
        print("追加方案（核心要求）")
        print(f"  接序编号       : {first} → {last}（自最大序号 {result['max_no']}+1 起）")
        print(f"  追加位置       : 现有 {len(records)} 行之后，第 {start} 行起；禁止插入已有行之间")
    print("=" * 64)

    if write_csv(out, ONLINE_FIELDS, result["new_rows"]):
        print(f"[✓] 新增行已写出：{out}")
    else:
        print("[·] 没有新增行，未写出新�� CSV")
    if write_csv(upd, ["已有任务编号", "已有任务事项", "本地编号", "本次来源",
                       "更新后原表状态", "更新后最近进展", "更新后最后来源周次"],
                 result["updates"]):
        print(f"[✓] 更新行已写出：{upd}")
    if write_csv(rev, ["本地编号", "本周事项", "疑似已有任务编号", "疑似已有事项",
                       "相似度", "处理"], result["reviews"]):
        print(f"[✓] 待确认清单已写出：{rev}")

    if result["warnings"]:
        print("-" * 64)
        print("告警：")
        for w in result["warnings"]:
            print(f"  ⚠ {w}")


if __name__ == "__main__":
    main()
