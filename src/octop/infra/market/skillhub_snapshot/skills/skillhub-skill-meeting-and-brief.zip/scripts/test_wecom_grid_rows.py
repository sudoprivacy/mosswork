"""隔离回归：逐条载荷、零重放、空白增量和自动化副作用。无网络或线上写入。"""
import copy
import json
import os
import tempfile
import unittest
from pathlib import Path
import wecom_sync_guard as g
from wecom_grid_rows import split_rows


class GridRegression(unittest.TestCase):
    def setUp(self):
        # Retain isolated evidence; never recursively delete a computed path.
        root=Path(os.environ.get('WECOM_TEST_ARTIFACT_DIR',Path.cwd()/'wecom-test-runs'))
        root.mkdir(parents=True,exist_ok=True)
        self.out = Path(tempfile.mkdtemp(prefix='sdqr-test-',dir=root)) / 'rows'
        self.before = {'overview': [], 'history': []}
        self.plan = {'target': 'overview', 'mode': 'create',
                     'fields': ['任务编号', '任务事项', '负责人', '追踪人', '任务进度'],
                     'rows': [{'任务编号': f'TASK-{n}', '任务事项': f'示例事项{n}',
                               '负责人': '示例甲@示例企业', '追踪人': '示例乙@示例企业, 示例丙@示例企业',
                               '任务进度': '0'} for n in (901, 902)]}
        self.payload, self.manifest = g.prepare(self.plan, self.before)

    def test_single_files_preserve_every_member_and_have_no_tail(self):
        index = split_rows(self.payload, self.manifest, self.before, self.out)
        self.assertEqual(index['row_count'], 2)
        for row in index['rows']:
            data = (self.out / row['file']).read_bytes()
            self.assertNotIn(b'\n', data)
            self.assertNotIn(b'\r', data)
            self.assertEqual(row['member_fields']['追踪人'], '示例乙@示例企业, 示例丙@示例企业')
        self.assertEqual('\n'.join((self.out/r['file']).read_text(encoding='utf-8') for r in index['rows']), self.payload)

    def test_modified_payload_is_rejected_before_output(self):
        with self.assertRaises(ValueError):split_rows(self.payload+'\n', self.manifest, self.before, self.out)
        self.assertFalse(self.out.exists())

    def test_stale_snapshot_is_rejected_before_output(self):
        stale=copy.deepcopy(self.before);stale['overview']=[self.plan['rows'][0]]
        with self.assertRaises(ValueError):split_rows(self.payload,self.manifest,stale,self.out)
        self.assertFalse(self.out.exists())

    def test_structured_payload_cannot_be_pasted(self):
        plan=dict(self.plan,transport='structured_json')
        payload,manifest=g.prepare(plan,self.before)
        with self.assertRaises(ValueError):split_rows(payload,manifest,self.before,self.out)
        self.assertFalse(self.out.exists())

    def test_completed_create_replay_produces_zero_row_files(self):
        after={'overview':copy.deepcopy(self.plan['rows']),'history':[]}
        payload,manifest=g.prepare(self.plan,after)
        index=split_rows(payload,manifest,after,self.out)
        self.assertEqual(index['row_count'],0)
        self.assertEqual(list(self.out.glob('*.tsv')),[])

    def test_existing_output_is_not_overwritten(self):
        split_rows(self.payload,self.manifest,self.before,self.out)
        original=(self.out/'0001.tsv').read_bytes()
        with self.assertRaises(FileExistsError):split_rows(self.payload,self.manifest,self.before,self.out)
        self.assertEqual((self.out/'0001.tsv').read_bytes(),original)

    def test_extra_blank_record_fails_full_value_audit(self):
        after={'overview':copy.deepcopy(self.plan['rows'])+[{'归档':'□'}],'history':[]}
        self.assertFalse(g.audit(self.before,after,[self.manifest])['passed'])

    def update_case(self):
        before={'overview':[{'任务编号':'TASK-61','任务事项':'示例采购','负责人':'示例甲',
                             '任务进度':0.95,'计划时限':'2026-11-01','最近进展':'示例完整摘要','归档':'□'}],'history':[]}
        plan={'target':'overview','mode':'update','fields':['归档'],
              'rows':[{'任务编号':'TASK-61','归档':'✅'}]}
        _,manifest=g.prepare(plan,before)
        after=copy.deepcopy(before);after['overview'][0]['归档']='✅'
        return before,after,manifest

    def test_archive_alone_preserves_manual_fields(self):
        before,after,manifest=self.update_case()
        self.assertTrue(g.audit(before,after,[manifest])['passed'])

    def test_archive_automation_changing_95_to_100_is_blocked(self):
        before,after,manifest=self.update_case();after['overview'][0]['任务进度']=1
        self.assertFalse(g.audit(before,after,[manifest])['passed'])

    def test_summary_automation_overwrite_is_blocked(self):
        before,after,manifest=self.update_case();after['overview'][0]['最近进展']='已完成'
        self.assertFalse(g.audit(before,after,[manifest])['passed'])

    def test_original_date_overwrite_is_blocked(self):
        before,after,manifest=self.update_case();after['overview'][0]['计划时限']='2026-11-02'
        self.assertFalse(g.audit(before,after,[manifest])['passed'])

    def test_member_loss_is_blocked(self):
        after={'overview':copy.deepcopy(self.plan['rows']),'history':[]}
        after['overview'][0]['追踪人']='示例乙@示例企业'
        self.assertFalse(g.audit(self.before,after,[self.manifest])['passed'])


if __name__=='__main__':unittest.main(verbosity=2)
