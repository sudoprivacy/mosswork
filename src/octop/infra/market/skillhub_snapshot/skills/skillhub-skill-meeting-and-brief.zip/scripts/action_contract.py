"""Word和Excel共用的待办校验；不补造会议事实。"""
import re

PRIOR_STATES = {'已完成','进行中','未启动','阻塞','取消'}
OPEN_STATES = {'进行中','未启动','阻塞'}
STATES = {'未启动','进行中','阻塞','完成','取消'}

def clean(value):
    return '' if value is None else str(value).strip()

def owner(item):
    return clean(item.get('负责人', item.get('责任人')))

def normalize_current(content):
    items = content.get('action_items', [])
    if not isinstance(items, list):
        raise ValueError('action_items必须是数组')
    result, seen = [], set()
    for i, item in enumerate(items, 1):
        if not isinstance(item, dict):
            raise ValueError('每条待办必须是对象')
        row = {k: clean(v) for k,v in item.items()}
        row['编号'] = clean(item.get('编号', f'本周-{i:02d}'))
        row['负责人'] = owner(item)
        for field in ('事项','负责人','完成时限'):
            if not row.get(field):
                raise ValueError(f'{row["编号"]}缺少{field}')
        if not row['编号'] or row['编号'] in seen:
            raise ValueError('本周编号缺失或重复')
        seen.add(row['编号'])
        row['状态'] = clean(item.get('状态')) or '未启动'
        if row['状态'] == '已完成': row['状态'] = '完成'
        if row['状态'] not in STATES:
            raise ValueError('本周状态无效：'+row['状态'])
        result.append(row)
    return result

def validate(content):
    if not isinstance(content, dict): raise ValueError('内容必须是对象')
    current = normalize_current(content)
    prior = content.get('prior_action_items', [])
    if not isinstance(prior, list): raise ValueError('prior_action_items必须是数组')
    previous = {}
    for i, item in enumerate(prior, 1):
        if not isinstance(item, dict): raise ValueError('上周待办必须是对象')
        item.setdefault('编号', f'上周-{i:02d}')
        key = clean(item['编号'])
        if not key or key in previous: raise ValueError('上周编号缺失或重复')
        if not all(clean(item.get(f)) for f in ('事项','原定时限','进展状态')) or not owner(item):
            raise ValueError(key+'缺少上周必填内容')
        if item['进展状态'] not in PRIOR_STATES: raise ValueError(key+'进展状态无效')
        previous[key] = item
    links = {key:[] for key in previous}
    for row in current:
        source = row.get('来源','')
        if prior and not source: raise ValueError(row['编号']+'缺少来源')
        for key in re.findall(r'上周-\d+',source):
            if key not in previous: raise ValueError('引用不存在的'+key)
            if previous[key]['进展状态'] not in OPEN_STATES: raise ValueError(key+'已关闭，不能继续承接')
            links[key].append(row['编号'])
    for key, item in previous.items():
        if item['进展状态'] not in OPEN_STATES: continue
        if '转线下跟踪' in clean(item.get('本周处理')):
            required = ('退出周会依据','后续承接人','后续渠道')
            if not all(clean(item.get(f)) for f in required): raise ValueError(key+'转线下缺少依据、承接人或渠道')
            if links[key]: raise ValueError(key+'已转线下，不能同时承接为本周周会待办')
            continue
        if not links[key]: raise ValueError(key+'为开放状态但没有承接')
        if not all(cur in re.findall(r'本周-\d+',clean(item.get('本周处理'))) for cur in links[key]):
            raise ValueError(key+'本周处理没有列明全部承接编号')
    return current
