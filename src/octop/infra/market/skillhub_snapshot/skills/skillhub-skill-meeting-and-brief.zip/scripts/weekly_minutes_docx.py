#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
weekly_minutes_docx.py — 按博维附件10 格式生成《验收与回款周会》纪要 docx

格式（references/weekly-action-linking.md）：A4 / 边距30·30·30·25mm / 微软雅黑 /
标题18pt加粗居中 / 正文仿宋四号、首行缩进2字符 / 分层编号、无项目符号 / 表格单倍行距、段后0行。

用法：
  python weekly_minutes_docx.py --sample > content.json          # 导出内容模板
  python weekly_minutes_docx.py --content content.json --out {客户}-项目验收与回款周会-会议纪要-YYYYMMDD.docx

content.json schema 见 SAMPLE_CONTENT。"待办事项跟踪"恒为正文最后实质段落，
其中 prior_action_items 记录上周进展，action_items 记录本周待办及承接关系。
"""
import argparse, copy, json, re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from action_contract import validate as validate_actions
from docx import Document
from docx.shared import Pt, Mm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "微软雅黑"
BODY_FONT = "仿宋"
BODY_SIZE = 14
HEADING_FONT = "黑体"

SAMPLE_CONTENT = {
    "title": "{客户名}  项目验收与回款周会  会议纪要",
    "subtitle": "（2026 年第 23 周 · 2026-06-06）",
    "confidential_note": "内部留档 · 含真实客户名与金额，不对外发送",
    "meta": {
        "会议时间": "2026-06-06（周六）11:30—12:30",
        "会议地点": "腾讯会议（线上）",
        "会议类型": "项目管理会 · 每周验收与回款专题",
        "会议主持人": "{会议主导}",
        "与 会 者": "{集团方}：{会议主导} / {客户方}：{销售负责人}、{验收负责人}、{项目负责人}、{技术负责人}、{财务}、{销售助理} / 咨询方：{咨询项目组}",
    },
    "agenda": [
        "复盘上周待办事项进展，确认完成、延续、阻塞或取消状态；",
        "回顾在手项目验收进展，明确攻坚目标与节点；",
        "盘点新签与存量项目回款计划，研判现金流；",
        "部署在建项目安装调试与资源、外部协调事项。",
    ],
    "sections": [
        {"title": "（一）上半年已验收约300万元，下半年目标调整为3100万元，6月底前攻坚2400万元",
         "bullets": [
             "截至本周，上半年累计完成验收约300万元；经集团调整，上半年验收目标定为3100万元。",
             "6月30日前重点攻坚约2400万元在手项目，主要涉及客户A、客户B、客户C等。",
         ]},
        {"title": "（二）应回未回款项已逐一明确计划，大额项目预计6月底前启动",
         "bullets": [
             "本周已签订客户D等新合同，预付款将陆续到账。",
             "存量项目回款计划明确：客户E、客户B、客户C等。",
         ]},
    ],
    "prior_action_items": [
        {"编号": "上周-01", "事项": "完成设备改造项目验收准备（示例）", "负责人": "{技术负责人}",
         "原定时限": "2026-06-05 前", "进展状态": "已完成",
         "进展说明": "验收资料已提交并完成内部确认", "本周处理": "本项关闭"},
        {"编号": "上周-02", "事项": "推进银行授信资料提交", "负责人": "{会议主导}",
         "原定时限": "2026-06-05 前", "进展状态": "进行中",
         "进展说明": "授信资料已提交，等待银行反馈", "本周处理": "承接至本周-01"},
    ],
    "action_items": [
        {"编号": "本周-01", "事项": "跟进银行授信审批反馈", "负责人": "{会议主导}",
         "追踪人": "{财务负责人}", "完成时限": "2026-06-12 前",
         "来源": "承接上周-02", "备注": "如需补充资料，当日反馈"},
        {"编号": "本周-02", "事项": "协调推进新增项目验收计划", "负责人": "{验收负责人}",
         "追踪人": "{项目负责人}", "完成时限": "2026-06-12 前",
         "来源": "本周新增", "备注": "形成项目节点清单"},
    ],
    "footer": {"整理人": "咨询项目组", "抄送": "{客户名}项目相关部门"},
}

# 正文新输入：主题下先写说明段落，再按items顺序输出1./2./3.事项。
for _section in SAMPLE_CONTENT["sections"]:
    _section["paragraphs"] = _section.pop("bullets", [])
    _section["items"] = []


def set_font(run, size=10.5, bold=False, color=None, font=FONT):
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for a in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        rfonts.set(qn(a), font)


def para(doc, text="", size=10.5, bold=False, align=None, line=1.2,
         before=0, after=4, color=None):
    p = doc.add_paragraph()
    if align is not None:
        p.alignment = align
    pf = p.paragraph_format
    pf.line_spacing = line
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    if text:
        set_font(p.add_run(text), size, bold, color)
    return p



def chinese_number(n):
    digits = "零一二三四五六七八九"
    if not 1 <= n <= 99:
        raise ValueError("二级主题数量须在1至99之间")
    if n < 10:
        return digits[n]
    tens, units = divmod(n, 10)
    return (digits[tens] if tens > 1 else "") + "十" + (digits[units] if units else "")


def unnumber(text):
    # 仅移除标题/议程开头已有的编号；业务数字与正文次序保持原样。
    return re.sub(r"^\s*(?:[（(][一二三四五六七八九十百零〇0-9]+[）)]|[一二三四五六七八九十百零〇]+、|\d+[.．、](?!\d))\s*", "", str(text)).strip()


def body_para(doc, text, heading=False, item_heading=False):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.left_indent = Pt(0)
    pf.first_line_indent = Pt(BODY_SIZE * 2)
    pf.space_before = Pt(6 if heading else 0)
    pf.space_after = Pt(0)
    pf.line_spacing = 1.5
    pf.keep_with_next = bool(heading or item_heading)
    ppr = p._p.get_or_add_pPr()
    ppr.find(qn("w:ind")).set(qn("w:firstLineChars"), "200")
    snap = OxmlElement("w:snapToGrid")
    snap.set(qn("w:val"), "0")
    ppr.append(snap)
    set_font(p.add_run(str(text)), BODY_SIZE, heading or item_heading,
             font=HEADING_FONT if heading else BODY_FONT)
    return p


def body_paragraphs(block):
    paragraphs = block.get("paragraphs", [])
    legacy = block.get("bullets", [])
    if paragraphs and legacy:
        raise ValueError("paragraphs与旧bullets不能同时填入，避免遗漏或重复正文")
    values = paragraphs or legacy
    if not isinstance(values, list) or not all(isinstance(v, str) for v in values):
        raise ValueError("正文paragraphs（或旧bullets）须为字符串数组")
    result = []
    for value in values:
        for line in value.splitlines():
            line = re.sub(r"^\s*[·•▪●]\s*", "", line).strip()
            if line:
                result.append(line)
    return result


def twip_w(cell, twips):
    cell.width = Pt(twips / 20.0)
    tcPr = cell._tc.get_or_add_tcPr()
    tcW = tcPr.find(qn("w:tcW"))
    if tcW is None:
        tcW = OxmlElement("w:tcW")
        tcPr.append(tcW)
    tcW.set(qn("w:w"), str(int(twips)))
    tcW.set(qn("w:type"), "dxa")


def fill_cell(cell, text, bold=False, size=10.5, line=1.0):
    cell.text = ""
    for i, seg in enumerate(str(text).split("\n")):
        p = cell.paragraphs[0] if i == 0 else cell.add_paragraph()
        pf = p.paragraph_format
        pf.line_spacing = line
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)
        # 所有单元格段落显式覆盖样式继承和文档网格，段后按0行记录。
        ppr = p._p.get_or_add_pPr()
        spacing = ppr.find(qn("w:spacing"))
        for key in ("w:beforeLines", "w:afterLines", "w:beforeAutospacing", "w:afterAutospacing"):
            spacing.set(qn(key), "0")
        snap = ppr.find(qn("w:snapToGrid"))
        if snap is None:
            snap = OxmlElement("w:snapToGrid")
            ppr.append(snap)
        snap.set(qn("w:val"), "0")
        set_font(p.add_run(seg), size, bold)


def fixed_layout(table, widths=None):
    tblPr = table._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    if widths:
        grid = table._tbl.tblGrid
        for child in list(grid):
            grid.remove(child)
        for width in widths:
            grid_col = OxmlElement("w:gridCol")
            grid_col.set(qn("w:w"), str(int(width)))
            grid.append(grid_col)


VALID_PRIOR_STATUSES = {"已完成", "进行中", "未启动", "阻塞", "取消"}
OPEN_PRIOR_STATUSES = {"进行中", "未启动", "阻塞"}


def responsible(item):
    """优先使用新字段“负责人”，兼容旧 JSON 的“责任人”键。"""
    return item.get("负责人", item.get("责任人", ""))


def join_parts(*parts):
    return "；".join(str(p).strip().rstrip("；") for p in parts if str(p).strip())


def validate_action_links(c):
    return validate_actions(c)


def build_weekly_minutes(c, out):
    if Path(out).exists():
        raise FileExistsError("输出已存在，请另存新版本")
    c = copy.deepcopy(c)
    c["action_items"] = validate_action_links(c)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Mm(210); sec.page_height = Mm(297)
    sec.top_margin = Mm(30); sec.left_margin = Mm(30)
    sec.right_margin = Mm(30); sec.bottom_margin = Mm(25)
    # 默认样式字体
    st = doc.styles["Normal"]
    st.font.name = FONT; st.font.size = Pt(10.5)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)

    # 标题 / 副标题 / 保密标注
    para(doc, c["title"], size=18, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER,
         line=2.4, after=2)
    if c.get("subtitle"):
        para(doc, c["subtitle"], size=11, align=WD_ALIGN_PARAGRAPH.CENTER, line=1.2, after=2)
    if c.get("confidential_note"):
        para(doc, c["confidential_note"], size=9, align=WD_ALIGN_PARAGRAPH.CENTER,
             line=1.2, after=6, color=(0x88, 0x88, 0x88))

    # 表1 · 会议基本信息
    meta = c["meta"]
    t1 = doc.add_table(rows=len(meta), cols=2)
    t1.style = "Table Grid"; t1.autofit = False; fixed_layout(t1, [1500, 7004])
    for i, (k, v) in enumerate(meta.items()):
        fill_cell(t1.rows[i].cells[0], k, bold=True)
        fill_cell(t1.rows[i].cells[1], v)
        twip_w(t1.rows[i].cells[0], 1500)
        twip_w(t1.rows[i].cells[1], 7004)
    para(doc, after=2)

    # 正文顺序及编号严格按用户样例；不生成项目符号列表。
    body_para(doc, "一、会议议程", heading=True)
    for i, a in enumerate(c.get("agenda", []), 1):
        body_para(doc, f"{i}、{unnumber(a)}")

    body_para(doc, "二、会议小结与决议", heading=True)
    for index, section in enumerate(c.get("sections", []), 1):
        body_para(doc, f"（{chinese_number(index)}）{unnumber(section['title'])}", heading=True)
        for text in body_paragraphs(section):
            body_para(doc, text)
        for number, item in enumerate(section.get("items", []), 1):
            body_para(doc, f"{number}. {unnumber(item['title'])}", item_heading=True)
            for text in body_paragraphs(item):
                body_para(doc, text)

    body_para(doc, "三、待办事项跟踪", heading=True)

    prior_items = c.get("prior_action_items", [])
    if prior_items:
        body_para(doc, "（一）上周待办事项进展", heading=True)
        prior_cols = ["编号", "上周待办事项", "负责人", "原定时限", "进展状态", "进展说明及本周处理"]
        prior_widths = [1150, 2100, 800, 1050, 850, 2554]
        prior_table = doc.add_table(rows=1 + len(prior_items), cols=6)
        prior_table.style = "Table Grid"; prior_table.autofit = False
        fixed_layout(prior_table, prior_widths)
        for j, col in enumerate(prior_cols):
            fill_cell(prior_table.rows[0].cells[j], col, bold=True, size=9.5)
            twip_w(prior_table.rows[0].cells[j], prior_widths[j])
        for i, item in enumerate(prior_items, 1):
            vals = [
                item["编号"], item.get("事项", ""), responsible(item),
                item.get("原定时限", ""), item.get("进展状态", ""),
                join_parts(item.get("进展说明", ""), item.get("本周处理", "")),
            ]
            for j, value in enumerate(vals):
                fill_cell(prior_table.rows[i].cells[j], value, size=9.5)
                twip_w(prior_table.rows[i].cells[j], prior_widths[j])
        para(doc, after=2)

    current_subtitle = "（二）本周待办事项" if prior_items else "（一）本周待办事项"
    body_para(doc, current_subtitle, heading=True)
    cols = ["编号", "会议安排事项", "负责人", "追踪人", "完成时限", "来源/备注"]
    widths = [1150, 2450, 850, 850, 1200, 2004]
    items = c.get("action_items", [])
    t2 = doc.add_table(rows=1 + len(items), cols=6)
    t2.style = "Table Grid"; t2.autofit = False; fixed_layout(t2, widths)
    for j, col in enumerate(cols):
        fill_cell(t2.rows[0].cells[j], col, bold=True, size=9.5)
        twip_w(t2.rows[0].cells[j], widths[j])
    for i, it in enumerate(items, 1):
        vals = [
            it["编号"], it.get("事项", ""), responsible(it), it.get("追踪人", ""),
            it.get("完成时限", ""), join_parts(it.get("来源", ""), it.get("备注", "")),
        ]
        for j, v in enumerate(vals):
            fill_cell(t2.rows[i].cells[j], v, size=9.5)
            twip_w(t2.rows[i].cells[j], widths[j])
    para(doc, after=2)

    # 页脚表
    f = c.get("footer", {"整理人": "咨询项目组", "抄送": "客户项目相关部门"})
    t3 = doc.add_table(rows=1, cols=4)
    fw = [1000, 3252, 1000, 3252]
    t3.style = "Table Grid"; t3.autofit = False; fixed_layout(t3, fw)
    pairs = [("整理人", f.get("整理人", "")), ("抄送", f.get("抄送", ""))]
    cells = t3.rows[0].cells
    fill_cell(cells[0], pairs[0][0], bold=True); fill_cell(cells[1], pairs[0][1])
    fill_cell(cells[2], pairs[1][0], bold=True); fill_cell(cells[3], pairs[1][1])
    for j in range(4):
        twip_w(cells[j], fw[j])

    for table in doc.tables:
        for row in table.rows:
            trpr = row._tr.get_or_add_trPr()
            trpr.append(OxmlElement("w:cantSplit"))
        if len(table.rows) > 1:
            table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
    doc.save(out)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", help="内容 JSON 路径")
    ap.add_argument("--out", help="输出 docx 路径")
    ap.add_argument("--sample", action="store_true", help="打印内容 JSON 模板")
    args = ap.parse_args()
    if args.sample:
        print(json.dumps(SAMPLE_CONTENT, ensure_ascii=False, indent=2))
        return
    if not args.content or not args.out:
        print("需 --content 与 --out（或 --sample）", file=sys.stderr); sys.exit(2)
    with open(args.content, encoding="utf-8-sig") as fh:
        c = json.load(fh)
    print(build_weekly_minutes(c, args.out))


if __name__ == "__main__":
    main()
