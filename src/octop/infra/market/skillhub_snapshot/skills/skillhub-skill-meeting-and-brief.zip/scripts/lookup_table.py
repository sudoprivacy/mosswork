#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lookup_table.py — 《项目验收、回款明细表》定位 + 检索（校对用）

用途（SKILL §2）：
  1) 自动定位 项目管理/ 下最新日期的《项目验收、回款明细表YYYYMMDD.xlsx》（文件名规则见 SKILL §配置）
  2) 按 客户名/项目名/口语项目号/唯一编号 在三张表(26年计划验收明细表/财务数据/回款明细)检索
  → 给 skill 做客户名纠错的"明细表唯一命中?"判定

用法：
  python lookup_table.py --root <项目根目录> --as-of YYYYMMDD --find     # 只打印最新表路径
  python lookup_table.py --root <root> 示例客户                          # 模糊检索
  python lookup_table.py --root <root> 422                               # 口语项目号→按编号列检索
  python lookup_table.py --root <root> 示例客户A 示例客户B --json          # 多词检索, JSON 输出
  python lookup_table.py --file <指定xlsx> 示例客户                       # 指定某版明细表

说明：
  - --root 不给时，从当前目录逐级向上找含 "项目管理" 子目录的目录。
  - 文件名日期取末尾 8 位数字(YYYYMMDD)，取最大者为"最新"。
  - 数字 query 只匹配"唯一编号"列；名称 query 匹配"客户名称/项目名称/摘要"列。
  - 按"核心客户名"去重：仅 1 个客户 → 确证；多个 → 需向用户确认。
"""
import argparse, glob, hashlib, json, os, re, sys
from datetime import datetime
from pathlib import Path

TABLE_GLOB = "*验收*回款*明细表*.xlsx"
CANDIDATE_SUBDIRS = ["项目管理", "报告/营收进展", "销售管理/回款", "销售管理/商机管理"]
SEARCH_SHEETS = ["26年计划验收明细表", "财务数据", "回款明细"]

_PREFIX = re.compile(r"^[\*\s]*(预收款_|预收冲应收_|应收冲预收_|应收账款_|预收账款_|"
                     r"货款_|其他应收款_|收款单_|应收_|预收_)")
_SUFFIX = ["股份有限公司", "有限责任公司", "有限公司", "研究院", "公司", "厂"]


def norm(s):
    return (str(s).replace("（", "(").replace("）", ")")
            .replace("　", "").replace(" ", "").strip())


def core_client(s):
    """从带前后缀的字段抽出标准客户主体名（归一括号/空格）。无公司类后缀视为会计科目噪声 → 返回空。"""
    if not s:
        return ""
    s = str(s)
    if "_" in s:
        s = s.split("_")[-1]                    # 取最后一段：去 票号：/收款单/预收款 等前缀
    s = _PREFIX.sub("", s).strip().lstrip("*").strip()
    s = re.split(r"[-—]", s)[0].strip()        # 去 -张总 / -人名 等后缀
    for suf in _SUFFIX:
        idx = s.find(suf)
        if idx != -1:
            return norm(s[:idx + len(suf)])
    return ""                                    # 无 公司/厂/研究院 后缀 → 丢弃


def find_root(start):
    cur = os.path.abspath(start)
    for _ in range(8):
        for d in CANDIDATE_SUBDIRS:
            if os.path.isdir(os.path.join(cur, d)):
                return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return os.path.abspath(start)


def date_key(path):
    m = re.findall(r"(?<!\d)(\d{8})(?!\d)", os.path.basename(path))
    valid = []
    for value in m:
        try:
            datetime.strptime(value, '%Y%m%d')
            valid.append(value)
        except ValueError:
            pass
    return max(valid) if valid else "00000000"


def latest_table(root, as_of=None):
    """按有效日期选表；历史会议排除会后版本。同日不同内容须明确指定。"""
    if as_of:
        as_of = as_of.replace('-', '')
        if not re.fullmatch(r'\d{8}',as_of):
            raise ValueError('会议日期须为YYYYMMDD或YYYY-MM-DD')
        datetime.strptime(as_of, '%Y%m%d')
    hits = glob.glob(os.path.join(root, "**", TABLE_GLOB), recursive=True)
    hits = [h for h in hits if not os.path.basename(h).startswith("~$")
            and date_key(h) != '00000000' and (not as_of or date_key(h) <= as_of)]
    if not hits:
        return None
    latest = max(date_key(h) for h in hits)
    candidates = sorted(h for h in hits if date_key(h) == latest)
    hashes = {hashlib.sha256(Path(h).read_bytes()).hexdigest() for h in candidates}
    if len(hashes) > 1:
        raise ValueError('同日期明细表内容冲突，请用 --file 指定：' + '；'.join(candidates))
    return candidates[0]


def classify(q):
    """返回 (是否口语项目号, 检索变体)。数字→只匹配唯一编号列。"""
    if re.fullmatch(r"(?:[A-Z][A-Z0-9]{0,7}-)?\d{3,4}", q, re.I):
        return True, {str(int(re.sub(r'^[A-Z][A-Z0-9]{0,7}-', '', q.upper())))}
    return False, {q}


def _col_map(header):
    idx = {}
    for ci, col in enumerate(header):
        for key in ("客户名称", "项目名称", "唯一编号", "合同金额", "贷方金额",
                    "借方金额", "摘要", "确认收入日期", "合同号"):
            if key in col and key not in idx:
                idx[key] = ci
    return idx


def _get(r, idx, key):
    ci = idx.get(key)
    if ci is not None and ci < len(r) and r[ci] is not None:
        return str(r[ci])
    return ""


def search(xlsx, queries):
    import openpyxl
    import warnings
    warnings.simplefilter("ignore")
    wb = openpyxl.load_workbook(xlsx, data_only=True, read_only=True)
    parsed = {q: classify(q) for q in queries}
    out = {q: {} for q in queries}          # q -> {核心客户名: [rec,...]}
    for sn in SEARCH_SHEETS:
        if sn not in wb.sheetnames:
            continue
        rows = list(wb[sn].iter_rows(values_only=True))
        if not rows:
            continue
        header_idx = 0
        for i, r in enumerate(rows[:5]):
            cells = [str(c) for c in r if c is not None]
            if any(k in " ".join(cells) for k in ("客户名称", "摘要", "唯一编号")):
                header_idx = i
                break
        header = [str(c) if c is not None else "" for c in rows[header_idx]]
        idx = _col_map(header)
        for r in rows[header_idx + 1:]:
            uid = _get(r, idx, "唯一编号")
            cust = _get(r, idx, "客户名称") or _get(r, idx, "摘要")
            proj = _get(r, idx, "项目名称")
            if not (uid or cust or proj):
                continue
            for q, (is_num, variants) in parsed.items():
                if is_num:
                    ids = re.findall(r'(?<![A-Za-z0-9])[A-Z][A-Z0-9]{0,7}-(\d{3,4})(?![A-Za-z0-9])', uid, re.I)
                    hit = any(str(int(v)) in variants for v in ids)
                else:
                    hit = any(v and norm(v) in norm(cust + proj) for v in variants)
                if not hit:
                    continue
                cc = core_client(cust)
                if not cc:
                    continue
                rec = {"编号": uid or "-", "项目": proj[:30] or "-", "表": sn,
                       "金额": _get(r, idx, "合同金额") or _get(r, idx, "贷方金额") or "-"}
                bucket = out[q].setdefault(cc, [])
                if rec["编号"] not in {x["编号"] for x in bucket}:
                    bucket.append(rec)
    wb.close()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("queries", nargs="*", help="检索词（客户名/项目号/唯一编号）")
    ap.add_argument("--root", default=".", help="项目根目录")
    ap.add_argument("--file", help="直接指定明细表 xlsx")
    ap.add_argument("--as-of", help="会议日期YYYYMMDD，仅选不晚于该日期的明细表")
    ap.add_argument("--find", action="store_true", help="只打印最新明细表路径")
    ap.add_argument("--json", action="store_true", help="JSON 输出")
    args = ap.parse_args()

    xlsx = args.file
    if not xlsx:
        root = find_root(args.root)
        xlsx = latest_table(root, args.as_of)
        if not xlsx:
            print("[ERR] 未找到《验收、回款明细表》，请用 --file 指定。", file=sys.stderr)
            sys.exit(2)

    if args.find or not args.queries:
        print(xlsx)
        return

    res = search(xlsx, args.queries)
    if args.json:
        print(json.dumps({"table": os.path.basename(xlsx), "results": res},
                         ensure_ascii=False, indent=2))
        return

    print("# 基准表：%s\n" % os.path.basename(xlsx))
    for q in args.queries:
        clients = res.get(q, {})
        if not clients:
            print("【%s】 ✗ 三张表均无匹配 → 需向用户确认（疑误听 / 当周新签）\n" % q)
            continue
        if len(clients) == 1:
            cc, recs = next(iter(clients.items()))
            uids = sorted({r["编号"] for r in recs if r["编号"] != "-"})
            print("【%s】 唯一命中 ✓ → 标准名「%s」" % (q, cc))
            print("        编号: %s（共 %d 条明细）\n" % (", ".join(uids[:8]) or "-", len(recs)))
        else:
            print("【%s】 %d 个不同客户 → 需向用户确认：" % (q, len(clients)))
            for cc, recs in clients.items():
                uids = sorted({r["编号"] for r in recs if r["编号"] != "-"})
                print("        · %s | 编号 %s" % (cc, ", ".join(uids[:4]) or "-"))
            print()


if __name__ == "__main__":
    main()
