"""把已校验网格载荷拆成单条粘贴文件；只写本地文件，不操作公示表。"""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path

import wecom_sync_guard as guard


def split_rows(payload, manifest, before, out_dir):
    guard.verify_payload(payload, manifest, before)
    if manifest.get('transport') != 'grid_tsv':
        raise ValueError('结构化更新不能转换成网格粘贴')
    lines = payload.split('\n') if payload else []
    if len(lines) != manifest['row_count'] or any(not line or '\r' in line for line in lines):
        raise ValueError('每条必须占一个非空物理行，且无尾换行')
    records = []
    for number, (line, key, expected) in enumerate(zip(lines, manifest['row_keys'], manifest['expected_values']), 1):
        parsed = list(csv.reader(io.StringIO(line), delimiter='\t'))
        if parsed != [[expected.get(f, '') for f in manifest['fields']]]:
            raise ValueError('单条载荷与批次字段不符：' + key)
        records.append({
            'sequence': number, 'business_key': key, 'file': f'{number:04d}.tsv',
            'payload_sha256': hashlib.sha256(line.encode('utf-8')).hexdigest(),
            'member_fields': {f: expected[f] for f in ('负责人', '追踪人') if f in expected},
            'status': 'pending_ui_verification',
        })
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=False)
    for line, record in zip(lines, records):
        with (out_dir / record['file']).open('x', encoding='utf-8', newline='') as stream:
            stream.write(line)
    index = {
        'schema_version': 1, 'manifest_sha256': manifest['manifest_sha256'],
        'before_sha256': manifest['before_sha256'], 'fields': manifest['fields'],
        'row_count': len(records), 'rows': records, 'external_write_performed': False,
        'note': 'pending只表示待现场核对，不能证明线上未写入；成员全文保留，不自动去除公司后缀。',
    }
    with (out_dir / 'index.json').open('x', encoding='utf-8') as stream:
        json.dump(index, stream, ensure_ascii=False, indent=2)
    return index


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--payload', required=True)
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--before', required=True)
    parser.add_argument('--out-dir', required=True)
    args = parser.parse_args()
    try:
        # Preserve actual line endings so CRLF/tail changes cannot evade the digest.
        with Path(args.payload).open(encoding='utf-8', newline='') as stream:
            payload = stream.read()
        result = split_rows(payload, json.loads(Path(args.manifest).read_text(encoding='utf-8-sig')),
                            guard.load_snapshot(args.before), args.out_dir)
        print(json.dumps({'passed': True, 'row_count': result['row_count'],
                          'external_write_performed': False}, ensure_ascii=False))
        return 0
    except (ValueError, KeyError, TypeError, OSError, csv.Error) as exc:
        print(json.dumps({'passed': False, 'error': str(exc), 'external_write_performed': False}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
