"""公示表本地预检及快照审计；没有网络、建行、删除或其他线上副作用。"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from datetime import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import re
import uuid

SHEETS = {'overview': '任务总览【新任务】', 'history': '任务进度【详情】【相关责任人更新】'}
SYSTEM = {'流水编号', '创建时间', '创建人', '最新跟进时间', '最新跟进人', '归档时间'}
READONLY = {'overview': SYSTEM, 'history': SYSTEM | {'任务事项', '项目编号'}}
KEY = re.compile(r'^[A-Z][A-Z0-9]{0,7}-MTG-(\d{8})-(TASK-\d+)(?=｜|\s|$)')
ZERO_WIDTH = dict.fromkeys(map(ord, '\u200b\ufeff\u2060\u200e\u200f'), None)


def text(v):
    return '' if v is None else str(v).translate(ZERO_WIDTH).strip()


def present(v):
    return bool(text(v))


def meaningful(row):
    for field, v in row.items():
        if field in SYSTEM or field.startswith('_') or not present(v):
            continue
        if field == '归档' and v in (False, 0, '0', '□', '☐', '未归档'):
            continue
        if field == '任务进度' and v in (0, 0.0, '0', '0.0', '0%'):
            continue
        if field == '任务状态' and v == '未启动':
            continue
        return True
    return False


def classify(row, target):
    if target == 'overview':
        if present(row.get('上级-任务编号')):
            content = {k: v for k, v in row.items() if k != '上级-任务编号'}
            return 'subtask' if meaningful(content) else 'partial_subtask'
        if present(row.get('任务编号')) and present(row.get('任务事项')):
            return 'task'
    elif present(row.get('任务编号')):
        if history_key(row) and present(row.get('进展说明')):
            return 'history'
        if not history_key(row) and any(present(row.get(f)) for f in ('进展说明', '本次事项原文', '任务事项快照')):
            return 'legacy_history'
    return 'partial' if meaningful(row) else 'placeholder'


def history_key(row):
    match = KEY.search(text(row.get('来源说明')))
    return match.group(0) if match else ''


def load_snapshot(path):
    path = Path(path)
    if path.suffix.lower() == '.json':
        data = json.loads(path.read_text(encoding='utf-8-sig'))
        validate_snapshot(data)
        return data
    from openpyxl import load_workbook
    # 企业微信导出文件的dimension有时只写A1，普通模式按实际单元格解析，避免漏读整表。
    wb = load_workbook(path, data_only=True)
    result = {}
    try:
        for target, sheet in SHEETS.items():
            rows = iter(wb[sheet].values)
            header = next(rows)
            result[target] = [dict(zip(header, ('' if v is None else v for v in row))) for row in rows]
    finally:
        wb.close()
    return result


def index_rows(rows, target):
    result = {}
    for row in rows:
        key = text(row.get('任务编号')) if target == 'overview' else history_key(row)
        if not key:
            continue
        if key in result:
            raise ValueError('快照业务键重复：' + key)
        result[key] = row
    return result


def validate_create(row, target):
    required = ['任务编号', '任务事项', '负责人'] if target == 'overview' else [
        '任务编号', '进展说明', '来源说明', '记录周次原文']
    missing = [f for f in required if not present(row.get(f))]
    if missing:
        raise ValueError('新记录缺少必填内容：' + '、'.join(missing))
    if not re.fullmatch(r'TASK-\d+', text(row['任务编号'])):
        raise ValueError('任务编号格式不正确')
    if target == 'history':
        match = KEY.search(text(row['来源说明']))
        if not match or match.group(2) != text(row['任务编号']):
            raise ValueError('会议来源键缺失或与任务编号不一致')
        if match.group(1) != text(row['记录周次原文']).replace('-', ''):
            raise ValueError('会议来源键与记录周次不一致')
        datetime.strptime(match.group(1), '%Y%m%d')
        if not (present(row.get('本次事项原文')) or present(row.get('任务事项快照'))):
            raise ValueError('新进展须保留本次事项原文或任务事项快照')


def prepare(plan, before):
    validate_snapshot(before)
    if not isinstance(plan, dict):
        raise ValueError('计划必须是对象')
    target, mode = plan['target'], plan['mode']
    if target not in SHEETS or mode not in ('create', 'update'):
        raise ValueError('target/mode不支持')
    fields = plan['fields']
    if not isinstance(fields, list) or not fields or not all(isinstance(f, str) and f for f in fields) or len(fields) != len(set(fields)):
        raise ValueError('字段列表为空或重复')
    if not isinstance(plan.get('rows'), list):
        raise ValueError('rows必须是数组')
    transport = plan.get('transport', 'grid_tsv')
    if transport not in ('grid_tsv','structured_json'):
        raise ValueError('不支持的写入载荷类型')
    if mode == 'update' and (target == 'history' or '任务编号' in fields):
        raise ValueError('历史正文采用追加记录；更新不得改写业务编号')
    forbidden = set(fields) & (READONLY[target] | set(plan.get('readonly_fields', [])))
    if forbidden:
        raise ValueError('只读/自动字段不得写入：' + '、'.join(sorted(forbidden)))
    baseline = index_rows(before[target], target)
    output, keys, seen, skipped = [], [], set(), []
    filtered_blank = normalized = 0
    cleared_fields = {}
    for source in plan['rows']:
        if source is None or (isinstance(source, dict) and not any(present(v) for v in source.values())):
            filtered_blank += 1
            continue
        if not isinstance(source, dict):
            raise ValueError('每条输入必须是字段对象')
        if not all(isinstance(f, str) and not isinstance(v, (dict, list)) for f,v in source.items()):
            raise ValueError('字段名须为字符串，字段值须为单值')
        if any(f not in source for f in fields):
            raise ValueError('待写字段缺失，不能将缺失字段解释为清空')
        row = dict(source)
        key = text(row.get('任务编号')) if target == 'overview' else history_key(row)
        if not key or key in seen:
            raise ValueError('输入业务键缺失或重复：' + key)
        seen.add(key)
        for field, v in list(row.items()):
            cleaned = text(v)
            if transport == 'grid_tsv':
                cleaned = cleaned.replace('\r\n', ' ').replace('\r', ' ').replace('\n', ' ').replace('\t', ' ')
            normalized += int(cleaned != text(v))
            row[field] = cleaned
        if transport == 'grid_tsv' and any(re.match(r'^[=+@]', row[f]) or re.match(r'^-(?!\d+(?:\.\d+)?%?$)', row[f]) for f in fields):
            raise ValueError('网格载荷含公式触发前缀，请改用明确按文本写入的结构化接口')
        if mode == 'create':
            validate_create({f: row.get(f, '') for f in fields}, target)
            if key in baseline:
                if all(text(baseline[key].get(f)) == row.get(f, '') for f in fields):
                    skipped.append(key)
                    continue
                raise ValueError('已有相同业务键但内容不同，需改用核对后的更新：' + key)
        else:
            if key not in baseline:
                raise ValueError('更新目标不在最新快照：' + key)
            if not any(present(row.get(f)) for f in fields) and not plan.get('allow_clear_reason'):
                raise ValueError('整条更新为空，需明确清空字段的原因：' + key)
            if any(not present(row[f]) and present(baseline[key].get(f)) for f in fields) and not present(plan.get('allow_clear_reason')):
                raise ValueError('清空已有字段须写明allow_clear_reason：' + key)
            cleared = [f for f in fields if not present(row[f]) and present(baseline[key].get(f))]
            if cleared:
                cleared_fields[key] = cleared
            merged = dict(baseline[key]); merged.update({f: row[f] for f in fields})
            validate_create(merged, target)
            if all(text(baseline[key].get(f)) == row.get(f, '') for f in fields):
                skipped.append(key)
                continue
        output.append([row.get(f, '') for f in fields])
        keys.append(key)
    if mode == 'update' and (cleared_fields or any(not any(present(v) for v in r) for r in output)):
        transport = 'structured_json'  # 清空只能按业务键结构化更新，不能粘贴全空逻辑行
    if transport == 'structured_json':
        objects = [dict(zip(fields,r), **({'任务编号':k} if target == 'overview' else {})) for k,r in zip(keys,output)]
        payload = json.dumps(objects,ensure_ascii=False) if objects else ''
    else:
        buffer = io.StringIO(newline='')
        csv.writer(buffer, delimiter='\t', lineterminator='\n').writerows(output)
        payload = buffer.getvalue()[:-1] if output else ''
        round_trip = list(csv.reader(io.StringIO(payload), delimiter='\t'))
        if round_trip != output or any(len(r) != len(fields) or not any(present(v) for v in r) for r in round_trip):
            raise ValueError('TSV逻辑行列校验失败')
    manifest = {
        'schema_version': 2,
        'transport': transport,
        'cleared_fields': cleared_fields,
        'allow_clear_reason': text(plan.get('allow_clear_reason')) if cleared_fields else '',
        'target': target, 'mode': mode, 'row_count': len(output), 'column_count': len(fields),
        'fields': fields, 'row_keys': keys, 'filtered_blank_inputs': filtered_blank,
        'normalized_cells': normalized, 'skipped_unchanged_keys': skipped,
        'expected_new_tasks': keys if target == 'overview' and mode == 'create' else [],
        'expected_new_history_keys': keys if target == 'history' and mode == 'create' else [],
        'payload_sha256': hashlib.sha256(payload.encode('utf-8')).hexdigest(),
        'external_write_performed': False,
        'before_sha256': digest(before),
        'expected_values': [dict(zip(fields, row)) for row in output],
    }
    manifest['manifest_sha256'] = manifest_digest(manifest)
    return payload, manifest


def fingerprint(row):
    return json.dumps(row, sort_keys=True, ensure_ascii=False, default=str)


def digest(value):
    return hashlib.sha256(fingerprint(value).encode('utf-8')).hexdigest()


def manifest_digest(manifest):
    return digest({k: v for k,v in manifest.items() if k != 'manifest_sha256'})


def validate_snapshot(data):
    if not isinstance(data, dict) or not all(isinstance(data.get(t), list) for t in SHEETS):
        raise ValueError('快照必须包含overview/history数组')
    for target in SHEETS:
        for row in data[target]:
            if not isinstance(row, dict) or not all(isinstance(k,str) and not isinstance(v,(list,dict)) for k,v in row.items()):
                raise ValueError('快照记录必须是字段单值对象')


def verify_payload(payload, manifest, before):
    """真正执行写入前再次检查；失败抛错，不输出可写通过标记。"""
    validate_snapshot(before)
    if manifest.get('schema_version') != 2 or manifest.get('manifest_sha256') != manifest_digest(manifest):
        raise ValueError('批次清单版本或摘要不正确')
    if manifest.get('before_sha256') != digest(before):
        raise ValueError('快照已变化，须重新预检并生成新批次')
    if hashlib.sha256(payload.encode('utf-8')).hexdigest() != manifest.get('payload_sha256'):
        raise ValueError('TSV摘要不符')
    fields, values = manifest['fields'], manifest['expected_values']
    if len(values) != manifest['row_count'] or len(manifest['row_keys']) != len(values):
        raise ValueError('清单记录数不符')
    if manifest.get('transport') == 'structured_json':
        objects = json.loads(payload) if payload else []
        if not isinstance(objects,list) or not all(isinstance(r,dict) for r in objects):
            raise ValueError('结构化载荷必须是对象数组')
        if manifest['target'] == 'overview' and [r.get('任务编号') for r in objects] != manifest['row_keys']:
            raise ValueError('结构化定位键不符')
        parsed = [[r.get(f,'') for f in fields] for r in objects]
    elif manifest.get('transport') == 'grid_tsv':
        parsed = list(csv.reader(io.StringIO(payload), delimiter='\t'))
    else:
        raise ValueError('载荷传输类型不符')
    if parsed != [[r.get(f,'') for f in fields] for r in values] or len(fields) != manifest['column_count']:
        raise ValueError('载荷与清单逐字段不符')
    return {'passed': True, 'manifest_sha256': manifest['manifest_sha256'], 'row_count': len(values), 'external_write_performed': False}


def audit(before, after, manifests):
    errors = []
    try:
        validate_snapshot(before); validate_snapshot(after)
    except ValueError as exc:
        return {'passed': False, 'errors': [str(exc)], 'external_write_performed': False}
    if not isinstance(manifests, list) or not all(isinstance(m, dict) for m in manifests):
        return {'passed': False, 'errors': ['清单必须是对象数组'], 'external_write_performed': False}
    legacy = any(m.get('schema_version') != 2 for m in manifests)
    for m in manifests:
        if m.get('schema_version') == 2:
            if m.get('manifest_sha256') != manifest_digest(m) or m.get('before_sha256') != digest(before):
                errors.append('批次清单被修改或不属于本次基线快照')
    expected_tasks = [k for m in manifests for k in m.get('expected_new_tasks', [])]
    expected_history = [k for m in manifests for k in m.get('expected_new_history_keys', [])]
    if len(expected_tasks) != len(set(expected_tasks)) or len(expected_history) != len(set(expected_history)):
        errors.append('批次清单的新增业务键重复')
    try:
        old_tasks = index_rows(before['overview'], 'overview')
        new_tasks = index_rows(after['overview'], 'overview')
        old_history = index_rows(before['history'], 'history')
        new_history = index_rows(after['history'], 'history')
    except ValueError as exc:
        return {'passed': False, 'errors': [str(exc)], 'external_write_performed': False}
    stats = {}
    for target, expected in [('overview', expected_tasks), ('history', expected_history)]:
        pre = Counter(classify(r, target) for r in before[target])
        post = Counter(classify(r, target) for r in after[target])
        actual_delta = len(after[target]) - len(before[target])
        stats[target] = {'before': dict(pre), 'after': dict(post), 'expected_delta': len(expected), 'actual_delta': actual_delta}
        if actual_delta != len(expected):
            errors.append(f'{target}记录增量不符：预期{len(expected)}，实际{actual_delta}')
        for kind in ('placeholder', 'partial', 'partial_subtask'):
            if post[kind] > pre[kind]:
                errors.append(f'{target}新增{kind}记录：{post[kind] - pre[kind]}')
    if set(new_tasks) - set(old_tasks) != set(expected_tasks):
        errors.append('新增任务编号与批次清单不符')
    if set(new_history) - set(old_history) != set(expected_history):
        errors.append('新增会议进展键与批次清单不符')
    if set(old_tasks) - set(new_tasks):
        errors.append('既有父任务丢失')
    if set(old_history) - set(new_history):
        errors.append('既有会议进展键丢失')
    for target in SHEETS:
        for label, snapshot in [('写前',before),('写后',after)]:
            ids = [text(r.get('流水编号')) for r in snapshot[target] if present(r.get('流水编号'))]
            if len(ids) != len(set(ids)):
                errors.append(target + label + '物理记录标识重复')
        for kind in ('placeholder','partial','partial_subtask'):
            pre = Counter(fingerprint(r) for r in before[target] if classify(r,target) == kind)
            post = Counter(fingerprint(r) for r in after[target] if classify(r,target) == kind)
            if pre != post:
                errors.append(target+'既有空白/残缺记录身份或内容改变：'+kind)
    for key in expected_history:
        if key in new_history and text(new_history[key].get('任务编号')) not in new_tasks:
            errors.append('新进展关联了不存在的父任务：'+key)
    for key, old in old_history.items():
        new = new_history.get(key)
        if new and any(text(old.get(f)) != text(new.get(f)) for f in set(old)|set(new) if f not in SYSTEM | {'任务事项','项目编号'}):
            errors.append('既有会议进展正文被改写：'+key)
    allowed_updates = {}
    for m in manifests:
        if m.get('schema_version') != 2:
            continue
        try:
            target, keys, values, fields = m['target'], m['row_keys'], m['expected_values'], m['fields']
            if len(keys) != len(values) or len(keys) != m['row_count']:
                raise ValueError('批次字段数量不符')
            index = new_tasks if target == 'overview' else new_history
            for key, expected in zip(keys,values):
                if key not in index or any(text(index[key].get(f)) != text(expected.get(f)) for f in fields):
                    errors.append('写后逐字段不符：'+key)
                if m['mode'] == 'update' and target == 'overview':
                    if key in allowed_updates and set(fields) & allowed_updates[key]:
                        errors.append('同一字段出现在多个更新批次：'+key)
                    allowed_updates.setdefault(key,set()).update(fields)
        except (KeyError,ValueError,TypeError) as exc:
            errors.append('清单结构错误：'+str(exc))
    if not legacy:
        for key, old in old_tasks.items():
            new = new_tasks.get(key)
            if new and any(text(old.get(f)) != text(new.get(f)) for f in (set(old)|set(new))-SYSTEM-allowed_updates.get(key,set())):
                errors.append('父任务发生未计划的字段变化：'+key)
    for target, expected, index in [('overview', expected_tasks, new_tasks), ('history', expected_history, new_history)]:
        for key in expected:
            if key in index:
                try:
                    validate_create(index[key], target)
                except ValueError as exc:
                    errors.append(f'{key}：{exc}')
    old_children = Counter(fingerprint(r) for r in before['overview'] if present(r.get('上级-任务编号')))
    new_children = Counter(fingerprint(r) for r in after['overview'] if present(r.get('上级-任务编号')))
    if old_children != new_children:
        errors.append('既有子任务或父子关系发生变化，需重新核对')
    old_rows = {text(r.get('流水编号')): r for r in before['history'] if present(r.get('流水编号'))}
    after_rows = {text(r.get('流水编号')): r for r in after['history'] if present(r.get('流水编号'))}
    if set(old_rows) - set(after_rows):
        errors.append('既有历史记录丢失')
    for key, old in old_rows.items():
        new = after_rows.get(key)
        if new and any(text(v) != text(new.get(f)) for f, v in old.items() if f not in ('任务事项', '项目编号')):
            errors.append('既有历史正文被改写：' + key)
    baseline_review = [{'target': t, 'excel_row': i + 2, 'kind': classify(r, t),
                        'record_id': text(r.get('流水编号')), 'task_id': text(r.get('任务编号'))}
                       for t in SHEETS for i, r in enumerate(before[t])
                       if classify(r, t) in ('placeholder', 'partial', 'partial_subtask')]
    return {'passed': not errors, 'stats': stats, 'baseline_review': baseline_review, 'expected_new_tasks': expected_tasks,
            'expected_new_history_keys': expected_history, 'errors': errors,
            'verification_level': 'keys_only' if legacy else 'full_values',
            'manifest_sha256s': [m.get('manifest_sha256') for m in manifests if m.get('schema_version') == 2],
            'before_sha256': digest(before), 'after_sha256': digest(after),
            'external_write_performed': False}


def save(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def transition(path, event, manifest=None, record_id=None, evidence=None):
    """持久化执行状态。结果未知时必须先回读，不能再次占位。无任何线上写入。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lock = Path(str(path) + '.lock')
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise ValueError('批次正在被操作或上次异常中断，先核对锁文件及线上状态')
    os.close(fd)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        state = json.loads(path.read_text(encoding='utf-8')) if path.exists() else None
        if state and state.get('state_sha256') != digest({k:v for k,v in state.items() if k != 'state_sha256'}):
            raise ValueError('状态文件摘要不符，禁止重放')
        if state is None:
            if event != 'planned' or not manifest or manifest.get('schema_version') != 2 or manifest.get('manifest_sha256') != manifest_digest(manifest):
                raise ValueError('新批次须由有效预检清单进入planned')
            state = {'state':'planned','manifest_sha256':manifest['manifest_sha256'],
                     'before_sha256':manifest['before_sha256'],'row_count':manifest['row_count'],
                     'mode':manifest['mode'],'events':[],'external_write_performed':False}
        else:
            allowed = {'planned':{'reserved','write_unknown'},'reserved':{'write_unknown'},
                       'write_unknown':{'verified','sync_incomplete'},'verified':set(),'sync_incomplete':set()}
            if event not in allowed.get(state['state'],set()):
                raise ValueError('非法状态跳转，须先回读核对：'+state['state']+'→'+event)
            if event == 'reserved':
                if state['mode'] != 'create' or not state['row_count'] or not present(record_id):
                    raise ValueError('仅非空创建批次可登记唯一占位标识')
                state['reserved_record_id'] = text(record_id)
            if event == 'verified':
                if not isinstance(evidence,dict) or evidence.get('passed') is not True or evidence.get('verification_level') != 'full_values' or state['manifest_sha256'] not in evidence.get('manifest_sha256s',[]) or evidence.get('before_sha256') != state['before_sha256'] or not evidence.get('after_sha256'):
                    raise ValueError('verified须绑定本批完整字段回读审计证据')
                state['audit_sha256'] = digest(evidence)
            if event == 'sync_incomplete':
                if not isinstance(evidence,dict) or evidence.get('passed') is not False:
                    raise ValueError('异常状态须保留失败审计报告')
                state['audit_sha256'] = digest(evidence)
        state['state'] = event
        state['events'].append({'event':event,'record_id':text(record_id), 'time':datetime.now().isoformat(timespec='seconds')})
        state.pop('state_sha256',None)
        state['state_sha256'] = digest(state)
        with temp.open('x',encoding='utf-8') as f:
            json.dump(state,f,ensure_ascii=False,indent=2); f.flush(); os.fsync(f.fileno())
        os.replace(temp,path)
        return state
    finally:
        if temp.exists(): temp.unlink()
        lock.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    pre = sub.add_parser('prepare')
    pre.add_argument('--plan', required=True)
    pre.add_argument('--before', required=True)
    pre.add_argument('--out', required=True)
    pre.add_argument('--manifest', required=True)
    check = sub.add_parser('check')
    check.add_argument('--payload', required=True)
    check.add_argument('--manifest', required=True)
    check.add_argument('--before', required=True)
    journal = sub.add_parser('journal')
    journal.add_argument('--state', required=True)
    journal.add_argument('--event', required=True, choices=['planned','reserved','write_unknown','verified','sync_incomplete'])
    journal.add_argument('--manifest')
    journal.add_argument('--record-id')
    journal.add_argument('--evidence')
    post = sub.add_parser('audit')
    post.add_argument('--before', required=True)
    post.add_argument('--after', required=True)
    post.add_argument('--manifests', nargs='+', required=True)
    post.add_argument('--out', required=True)
    args = parser.parse_args()
    try:
        if args.command == 'prepare':
            if Path(args.out).resolve() == Path(args.manifest).resolve():
                raise ValueError('载荷和清单必须是不同路径')
            if Path(args.out).exists() or Path(args.manifest).exists():
                raise ValueError('输出已存在，请为新批次另存路径；不得复用旧载荷或旧清单')
            payload, report = prepare(json.loads(Path(args.plan).read_text(encoding='utf-8-sig')), load_snapshot(args.before))
            with Path(args.out).open('x', encoding='utf-8', newline='') as f:
                f.write(payload)
            with Path(args.manifest).open('x', encoding='utf-8') as f:
                json.dump(report,f,ensure_ascii=False,indent=2)
            print(json.dumps(report, ensure_ascii=False))
        elif args.command == 'check':
            report = verify_payload(Path(args.payload).read_text(encoding='utf-8'),
                                    json.loads(Path(args.manifest).read_text(encoding='utf-8-sig')), load_snapshot(args.before))
            print(json.dumps(report, ensure_ascii=False))
        elif args.command == 'journal':
            report = transition(args.state,args.event,
                                manifest=json.loads(Path(args.manifest).read_text(encoding='utf-8-sig')) if args.manifest else None,
                                record_id=args.record_id,
                                evidence=json.loads(Path(args.evidence).read_text(encoding='utf-8-sig')) if args.evidence else None)
            print(json.dumps(report,ensure_ascii=False))
        else:
            if Path(args.out).exists():
                raise ValueError('审计输出已存在，请另存新路径；不得覆盖快照或旧证据')
            report = audit(load_snapshot(args.before), load_snapshot(args.after),
                           [json.loads(Path(p).read_text(encoding='utf-8-sig')) for p in args.manifests])
            save(args.out, report)
            print(json.dumps(report, ensure_ascii=False))
            if not report['passed']:
                return 2
    except (ValueError, KeyError, TypeError, OSError, csv.Error) as exc:
        print(json.dumps({'passed': False, 'error': str(exc), 'external_write_performed': False}, ensure_ascii=False))
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
