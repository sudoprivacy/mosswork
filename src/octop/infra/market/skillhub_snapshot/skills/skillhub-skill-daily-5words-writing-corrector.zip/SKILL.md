---
name: skillhub-skill-daily-5words-writing-corrector
description: "每日5词英语打卡——每天推荐5个实用英语单词，覆盖多生活场景，支持分类选词，生成互动HTML卡片，邀请用户用中英夹杂写短文打卡，AI辅助语法修正与翻译。适合希望以低压力、有趣方式保持英语语感的用户。当用户提到“打卡”“每日5词”“英语单词”“今天学什么词”等触发词时使用。"
---

# Daily 5 Words — 每日5词打卡

A complete daily English vocabulary practice workflow designed for low-pressure, fun engagement. The user practices by writing a short passage using the 5 words of the day, with Chinese-English mixing fully allowed.

## Core Principles

- **Fun first, not language mastery.** The goal is to make the user *want* to participate daily, not to maximize English learning outcomes.
- **Zero pressure.** Never criticize, never mock, never push for "all-English writing." Chinese-English mixing is explicitly welcomed.
- **Encourage and celebrate every submission.**

## Content Boundaries (MUST state upfront when inviting)

The skill welcomes creative freedom, but some content cannot be processed due to safety policies. When inviting the user to write, ALWAYS include this disclaimer:

> 题材不限，日常、职场、虚构故事都可以。但请注意：涉及暴力伤害、政治敏感人物、仇恨言论、色情或违法内容无法处理。

If a submission falls into these categories, refuse politely and briefly, then invite the user to try a different topic with the same 5 words. Do NOT lecture or moralize.

---

## Phase 1 — Trigger & Mode Selection

When the user triggers the skill (keywords: "打卡", "每日5词", "今天是什么词", "英语单词", "daily 5 words", or when the daily automation fires):

### Step 1: Ask for word selection mode

Present the following menu and wait for the user's choice before proceeding:

| # | Mode | Focus |
|---|------|-------|
| 1 | 🎲 自由混合 | AI automatically covers diverse scenarios |
| 2 | 💼 职场场景 | Meetings, collaboration, reporting, management |
| 3 | 🫂 社交关系 | Communication, empathy, relationships, conflict |
| 4 | 🏠 日常生活 | Daily routines, home, shopping, meals |
| 5 | 😤 情绪表达 | Emotions, stress, mindset, mood |
| 6 | 🎬 行动决策 | Planning, choices, execution, reflection |
| 7 | 📊 难度递进 | From high-frequency to mid-frequency words |

The user replies with a number or mode name. Then proceed to Phase 2.

If this is part of an automation (scheduled daily task) and the user is not present to select, default to mode 1 (自由混合).

---

## Phase 2 — Word Selection & HTML Card Generation

### Word Selection Rules

Given the chosen mode, select 5 practical English words. Follow these rules:

1. **Scenario diversity:** Within any mode, spread the 5 words across different sub-scenarios. Avoid clustering all words in one narrow category.
2. **Historical deduplication:** Scan existing `daily-5-words-*.html` files in the current working directory and extract previously used words from them. Do NOT reuse any word that has appeared in the last 14 days. If fewer than 14 days of history exist, use whatever is available. If no prior files exist, skip the deduplication check.
3. **Practicality:** Prefer words commonly used in real life and workplace settings over obscure vocabulary.
4. **Difficulty progression (mode 7 only):** Start with high-frequency words and gradually increase difficulty across rounds.

### For Each Word, Provide:

- Word (bold, prominent)
- Phonetic transcription (IPA)
- Chinese meaning (with part of speech)
- 1 example sentence (English)
- Chinese translation of the example sentence
- 1 memory tip (in Chinese, short and vivid, using word-root breakdown, associations, or humor)

### HTML Card Generation

Generate an interactive HTML file named `daily-5-words-YYYY-MM-DD.html`.

Use the card template style from `assets/card-template.html` as a reference for CSS variables and structure. The key requirements:

- Each word gets a numbered card with: word, IPA, 🔊 pronunciation button, Chinese meaning, example sentence, Chinese translation, 💡 memory tip
- Example sentences: wrap EVERY word in a `<span class="cw" data-w="WORD" data-t="TRANSLATION" onclick="togglePopup(event)">WORD</span>` tag so that clicking any word shows a popup with its Chinese translation and a mini pronunciation button
- Invitation card at the bottom (purple gradient card inviting the user to write a short passage)
- Web Speech API for pronunciation (function `play(word)`)
- Popup toggle logic for clickable words (function `togglePopup(e)`)
- No external dependencies — everything self-contained in the HTML

Save the HTML file in the current working directory.

### After Generating

Present a brief summary of the 5 words and prompt the user to try the writing challenge. The invitation text should include both the encouragement AND the content boundary disclaimer:

> 试试用这5个词写一段短文或几句话串联起来，中英文夹杂完全没问题，不限长度，写完发给我，我来帮你修正语法 + 翻译中文版！
>
> 题材不限，日常、职场、虚构故事都可以。但请注意：涉及暴力伤害、政治敏感人物、仇恨言论、色情或违法内容无法处理。

---

## Phase 3 — Review & Correction

When the user submits a passage (may contain mixed Chinese and English):

### Step 1: Correct to Full English

Convert the mixed Chinese-English text into grammatically correct complete English. Specifically:

- Translate Chinese portions into natural English
- Fix all grammar errors (tense, subject-verb agreement, prepositions, articles, word order)
- Ensure the corrected version reads as a coherent passage
- **Bold the day's 5 target words** in the corrected version (use `**word**` markdown)
- If generating a saved document, use bold + accent color (e.g., `<strong style="color:#e8644a">word</strong>`)

### Step 2: Grammar Notes

Provide a concise table of key corrections:

| Original | Corrected | Note (short, in Chinese) |
|----------|-----------|--------------------------|
| ... | ... | ... |

- Keep notes short and actionable — explain *what* was fixed, not long theory
- Focus on patterns that help the user avoid the same mistake next time
- Max ~8 rows in the table; skip trivial corrections

### Step 3: Chinese Translation

Provide a complete, fluent Chinese translation of the corrected English passage for side-by-side comparison.

### Step 4: Usage Check

If the user clearly misunderstood a word's meaning or usage, briefly note it. Use phrasing like "顺便提一下，XXX 在这里的用法……" — never scolding, just a helpful pointer.

### Step 5: Encouraging Closing

End with a warm, encouraging note. Acceptable forms:
- Highlight what worked well
- Acknowledge creative use of words
- A light, playful closing

**NEVER:**
- Suggest "try writing in all English next time"
- Criticize the user's English level
- Use sarcasm or condescending tone
- Say "you should…" about writing style

---

## Phase 4 — Archiving & Saving

After completing the correction, generate a clean archive file saved as `daily-5-words-YYYY-MM-DD-review.md`:

```markdown
# 每日5词打卡存档 · YYYY年MM月DD日

**选词模式:** [mode name]
**今日原词:** word1, word2, word3, word4, word5

---

## 修正后英文全文

(Corrected English passage with day's words **bolded** and colored)

---

## 中文翻译

(Complete Chinese translation)
```

The archive file is meant to be clean and shareable — the detailed grammar notes stay in the chat history.

---

## Phase 5 — Continue or End

After archiving, ask the user:

> 今天的打卡完成！想再来一轮新词，还是今天就到这里？

If the user chooses to continue, go back to Phase 1 (mode selection → new 5 words → invite → wait for submission → correct → archive → repeat).

If the user chooses to end, confirm completion and stop.

---

## Important Constraints

### Writing Style in User Interactions
- Use warm, direct Chinese. Skip filler phrases like "Great question!" or "I'd be happy to help!"
- Have personality — be playful but respectful
- Keep interactions concise during correction phases, warmer during invitation phases

### Tone Boundaries
- Never suggest "全程用英文写" or equivalent pressure
- Never compare the user's writing unfavorably to "native" level
- The only acceptable push is: encouraging them to keep coming back daily

### HTML Generation Standards
- Use ASCII straight quotes for all HTML attributes
- Wrap every word in example sentences with clickable spans
- Self-contained, no CDN dependencies
- Responsive, max-width 680px, centered
