#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
itinerary.py —— 行程骨架生成器 & 四年容量规划

注意：本脚本负责「骨架」——区域聚类、交通校验、预算核算、菜系去重，
     并在 Y1 行程中直接填入内置店铺库（data/y1_shops.json）的**已核实候选店**。

店铺库使用原则（硬约束）：
  1. 只输出库里**真实存在**的店，字段一律照抄，不做任何推断补全；
  2. `rating` 字段全库为 null —— 脚本不填、不猜、不估算评分，
     改以 `rating_note` 提示「出发前看一眼点评」；
  3. 库里没有对应品类时，返回 `needs_sourcing`，由小桐走降级链现场核实，
     绝不拿「听说有家不错的」糊弄。

用法：
  # 生成一日行程（Y1 自动带候选店）
  python3 itinerary.py --year 1 --days 1 --meals lunch,dinner \
      --from jiangning --budget 60 --people 2

  # 只出骨架，不带候选店
  python3 itinerary.py --year 1 --days 1 --meals lunch,dinner --no-shops

  # 查看四年容量规划
  python3 itinerary.py --plan

  # 查看当前进度
  python3 itinerary.py --progress
"""

import argparse
import json
import os
import re
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import get_profile, emit, NJ_AREAS, require_profile  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)
SHOP_FILE = os.path.join(SKILL_DIR, "data", "y1_shops.json")

# ------------------------------------------------------------ 常量（源自校历）
# 中国药科大学 2025-2026 学年校历（教务处 jwc.cpu.edu.cn）
WEEKS_PER_YEAR = 39          # 上学期 20 周 + 下学期 19 周
YEARS = 4
GROSS_WEEKS = WEEKS_PER_YEAR * YEARS        # 156
MILITARY_TRAINING = 3.5      # 大一军训 9/1-9/24，新生 9/25 才开课
GRADUATION_EARLY = 4.0       # 大四下毕业离校
EXAM_WEEKS = 16              # 2 周 × 8 学期

MAIN_WEEKS = GROSS_WEEKS - MILITARY_TRAINING - GRADUATION_EARLY - EXAM_WEEKS
LIGHT_WEEKS = EXAM_WEEKS
TOTAL_WEEKS = MAIN_WEEKS + LIGHT_WEEKS       # ≈148.5

DEDUPE_RATE = 0.8            # 20% 为回头店
COMPLETION_RATE = 0.75       # 生病/考试/天气/预算导致的缺席

# ------------------------------------------------------------ 区域与交通
# 从江宁校区出发的单程估算（分钟），不含步行与等车
TRAVEL_FROM_JIANGNING = {
    "江宁区": 20, "秦淮区": 40, "鼓楼区": 50, "玄武区": 50,
    "建邺区": 45, "雨花台区": 40, "栖霞区": 80, "浦口区": 80,
    "六合区": 95, "溧水区": 100, "高淳区": 115,
}
TRAVEL_FROM_XUANWUMEN = {
    "鼓楼区": 12, "玄武区": 15, "秦淮区": 20, "建邺区": 25,
    "雨花台区": 30, "江宁区": 50, "栖霞区": 35, "浦口区": 45,
    "六合区": 70, "溧水区": 80, "高淳区": 95,
}

# 各年份推荐区域（由近及远、由安全到深入）
YEAR_AREAS = {
    1: ["江宁区", "秦淮区", "鼓楼区", "玄武区", "建邺区"],
    2: ["秦淮区", "鼓楼区", "玄武区", "雨花台区", "建邺区", "栖霞区"],
    3: ["鼓楼区", "秦淮区", "玄武区", "建邺区", "雨花台区", "江宁区"],
    4: ["OUT_OF_NANJING"],
}

MEAL_LABEL = {
    "breakfast": "早餐", "brunch": "早午餐", "lunch": "午餐",
    "teatime": "下午茶", "dinner": "晚餐", "latenight": "夜宵",
}

MEAL_TIME = {
    "breakfast": "07:30", "brunch": "10:30", "lunch": "12:00",
    "teatime": "15:00", "dinner": "18:00", "latenight": "21:30",
}

# 顿数 × 菜系去重建议
CUISINE_ROTATION = {
    1: ["本地小吃"],
    2: ["主食类（面/粉/饭）", "正餐类（米饭/小炒）"],
    3: ["小吃", "主食类", "正餐类"],
    4: ["小吃", "主食类", "正餐类", "甜品/饮品"],
}

# 餐段 × 适宜品类（来自 data/y1_shops.json 的品类 id），分主次两档。
# tier 0 = 这个餐段最该吃的；tier 1 = 也成立但没那么对。
# 南京的真实节奏：早上锅贴汤包馄饨，中午一碗面，晚上斩只鸭子，下午甜品，夜里鸭血粉丝。
MEAL_CATEGORIES = {
    "breakfast": {
        0: ["niurouguotie", "jizhitangbao", "chaihuohuntun", "yayoushaobing"],
        1: ["xieqiaohuang", "sushaobing", "shijindoufulao", "zhuangyuandou"],
    },
    "brunch": {
        0: ["jizhitangbao", "pidumian", "laohumian"],
        1: ["chaihuohuntun", "niurouguotie", "yaxuefensi"],
    },
    "lunch": {
        0: ["pidumian", "laohumian", "yaxuefensi"],
        1: ["chaihuohuntun", "niurouguotie"],
    },
    "teatime": {
        0: ["guihuatangyumiao", "chixiaodouyuanxiao", "meihuagao"],
        1: ["tangzhouou", "mizhiou"],
    },
    "dinner": {
        0: ["nanjingkaoya", "yanshuiya", "banya", "pidumian"],
        1: ["yaxuefensi", "niurouguotie"],
    },
    "latenight": {
        0: ["yaxuefensi", "niurouguotie", "nanjingkaoya"],
        1: ["huozhuzi", "zhuangyuandou"],
    },
}

# 餐段人均天花板（元）——早餐人均 60 的店，再好也不该出现在早餐位
MEAL_PRICE_CEILING = {
    "breakfast": 25, "brunch": 30, "lunch": 40,
    "teatime": 25, "dinner": None, "latenight": 30,
}

CONF_RANK = {"high": 0, "medium": 1, "low": 2}

# 品类 id → 中文名（渲染用，避免每次读文件）
CAT_NAMES = {}


def _parse_price(v):
    """把 '25-45' / '35-40元/斤' / '10' 解析成 (下限, 上限)；解析不了返回 (None, None)"""
    if not v:
        return (None, None)
    nums = re.findall(r"\d+", str(v))
    if not nums:
        return (None, None)
    if len(nums) >= 2:
        lo, hi = int(nums[0]), int(nums[1])
        return (min(lo, hi), max(lo, hi))
    return (int(nums[0]), int(nums[0]))


def _hm(text):
    """'21:30' → 1290（分钟）。解析不了返回 None。"""
    m = re.search(r"(\d{1,2}):(\d{2})", str(text or ""))
    if not m:
        return None
    return int(m.group(1)) * 60 + int(m.group(2))


def _parse_hours(v):
    """'07:30-21:00' → (450, 1260)。跨零点自动 +24h。核不到返回 None。

    返回 None 有三种情况——字段为空、格式不认识、只写了一个时间点。
    这三种都属于「不知道」，调用方必须区别对待，不能当成「没问题」。
    """
    if not v:
        return None
    text = str(v)
    if re.search(r"24\s*小时|全天|24h", text, re.I):
        return (0, 24 * 60)
    stamps = re.findall(r"\d{1,2}:\d{2}", text)
    if len(stamps) < 2:
        return None
    start, end = _hm(stamps[0]), _hm(stamps[1])
    if start is None or end is None:
        return None
    if end <= start:          # 跨零点，如 17:00-02:00
        end += 24 * 60
    return (start, end)


def load_shop_library():
    """读内置店铺库，返回 (扁平列表, 元信息)。库不可用时返回 ([], None)。"""
    if not os.path.isfile(SHOP_FILE):
        return [], None
    try:
        with open(SHOP_FILE, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return [], None

    flat = []
    for cat in data.get("categories", []):
        CAT_NAMES[cat["id"]] = cat["name"]
        for s in cat.get("shops", []):
            if s.get("status", "active") != "active":
                continue
            row = dict(s)
            row["_cat_id"] = cat["id"]
            row["_cat_name"] = cat["name"]
            lo, hi = _parse_price(s.get("avg_price"))
            row["_price_lo"], row["_price_hi"] = lo, hi
            flat.append(row)

    total = len(flat)
    covered = len({s["_cat_id"] for s in flat})
    stale = [s for s in flat if _stale_days(s.get("verified_at")) is None
             or _stale_days(s.get("verified_at")) > 90]
    meta = {
        "file": "data/y1_shops.json",
        "categories_covered": covered,
        "categories_total": len(data.get("categories", [])),
        "shops_total": total,
        "stale_count": len(stale),
        "rating_field": "全库为 null（不预置评分，出发前请看点评）",
    }
    return flat, meta


def _stale_days(verified_at):
    if not verified_at:
        return None
    try:
        y, m, d = (int(x) for x in str(verified_at)[:10].split("-"))
        return (date.today() - date(y, m, d)).days
    except (ValueError, TypeError):
        return None


def pick_shop(library, meal, area, budget, used_cats):
    """为某个餐段挑一家候选店 + 2 家备选。

    排序权重：已用品类靠后 → 主档品类 → 不超预算 → 置信度高 → 营业时间明确
              → 车程短 → 贴近目标价位 → 同区域
    到点已打烊的店**不进行程**，单独放进 closed_at_this_time 附注说明。
    返回 None 表示库里没有合适候选（不是编不出，是真的没有）。
    """
    tiers = MEAL_CATEGORIES.get(meal, {})
    if not tiers:
        return None
    cat_tier = {}
    for t, ids in tiers.items():
        for cid in ids:
            cat_tier[cid] = t
    if not cat_tier:
        return None

    # 有效预算 = 用户预算 与 该餐段人均天花板 取小
    ceiling = MEAL_PRICE_CEILING.get(meal)
    eff_budget = min([b for b in (budget, ceiling) if b] or [None]) \
        if (budget or ceiling) else None

    meal_min = _hm(MEAL_TIME.get(meal, "12:00")) or 12 * 60

    fresh = [c for c in cat_tier if c not in used_cats]
    pool = [s for s in library if s["_cat_id"] in cat_tier]
    if not pool:
        return None

    # 按营业时间分流：确认开着 / 这个点已关 / 营业时间没核到
    open_pool, closed_pool = [], []
    for s in pool:
        win = _parse_hours(s.get("hours"))
        if win and not (win[0] <= meal_min <= win[1]):
            closed_pool.append(s)
        else:
            open_pool.append(s)
    # 极端情况：这个餐段候选全部打烊 —— 宁可照实推并标注，也不假装没候选
    all_closed = False
    if not open_pool and closed_pool:
        open_pool, closed_pool, all_closed = closed_pool, [], True

    def key(s):
        used_penalty = 1 if s["_cat_id"] in used_cats else 0
        tier = cat_tier.get(s["_cat_id"], 1)
        # 只对「本餐段还剩的品类」做新鲜度加权；全用完了就允许重复
        if fresh and s["_cat_id"] not in fresh:
            used_penalty = 1
        lo, hi = s["_price_lo"], s["_price_hi"]
        # 未知价格记 0，「贴近目标价位」排序会自然把它排到最后
        mid = ((lo or 0) + (hi or lo or 0)) / 2 if (lo or hi) else 0
        over = 1 if (eff_budget and lo and lo > eff_budget) else 0
        # 目标价位 = 有效预算的 6 成。不是越贵越好，也不是越便宜越好——
        # 预算 90 时该吃到好鸭子，预算 25 时就别推人均 50 的店。
        target = eff_budget * 0.6 if eff_budget else None
        price_dist = abs(mid - target) if target else 0
        conf = CONF_RANK.get(s.get("confidence", "medium"), 1)
        # 营业时间核不到的往后排（不知道 ≠ 没问题），但不排除
        hours_unknown = 0 if _parse_hours(s.get("hours")) else 1
        transit = s.get("transit_min") or 75
        area_miss = 0 if (not area or s.get("area") == area) else 1
        # 顺序：没用过 → 主档 → 不超预算 → 置信高 → 时间明确 → 车程短 → 贴近目标价 → 同区域
        return (used_penalty, tier, over, conf, hours_unknown, transit,
                price_dist, area_miss, s["_cat_name"])

    open_pool.sort(key=key)
    top = open_pool[:3]

    def brief(s):
        win = _parse_hours(s.get("hours"))
        return {
            "name": s["name"],
            "category": s["_cat_name"],
            "address": s.get("address"),
            "area": s.get("area"),
            "avg_price": s.get("avg_price"),
            "hours": s.get("hours"),
            "hours_verified": win is not None,
            "open_all_day": win == (0, 24 * 60),
            "transit_min": s.get("transit_min"),
            "confidence": s.get("confidence", "medium"),
            "verified_at": s.get("verified_at"),
            "tips": s.get("tips"),
        }

    head = top[0]
    notes = []
    if not head.get("hours"):
        notes.append("这家我没核到营业时间，去之前先在点评上确认一眼——"
                     "我不想让你到了才发现没开门。")
    elif _parse_hours(head.get("hours")) is None:
        notes.append(f"这家的营业时间我只有「{head['hours']}」这一条，"
                     "不是标准时间格式，去之前再确认一眼。")
    if head.get("confidence") == "low":
        notes.append("这家只查到一个来源，地址和营业时间都再核一次。")

    # 同一家店可能挂在多个品类下（如芳婆既是糖芋苗也是赤豆元宵），按店名去重
    def dedupe(shops):
        seen, out = set(), []
        for s in shops:
            if s["name"] in seen:
                continue
            seen.add(s["name"])
            out.append({"name": s["name"], "category": s["_cat_name"],
                        "hours": s.get("hours")})
        return out

    result = {
        "status": "from_library",
        "category_id": head["_cat_id"],
        "pick": brief(head),
        "alternatives": [brief(s) for s in top[1:]],
        "rating_note": ("库里不存评分——评分天天变，写进文件那天就开始说谎。"
                        "出发前在点评/美团上扫一眼，顺手确认还在营业。"),
        "confidence_note": " ".join(notes) if notes else None,
    }
    if closed_pool and not all_closed:
        result["closed_at_this_time"] = {
            "note": (f"{MEAL_LABEL.get(meal, '这一顿')}这个点，下面这些已经打烊了"
                     "——想吃就换个时段，别白跑一趟。"),
            "shops": dedupe(closed_pool)[:6],
        }
    if all_closed:
        result["closed_at_this_time"] = {
            "note": (f"库里这个餐段的候选店，这个点全都关门了（下表）。"
                     "行程照给，但你去之前一定要先确认，或者换个餐段。"),
            "shops": dedupe(open_pool)[:6],
            "all_closed": True,
        }
    return result


def travel_minutes(campus, area):
    tbl = TRAVEL_FROM_JIANGNING if campus == "jiangning" else TRAVEL_FROM_XUANWUMEN
    return tbl.get(area, 60)


def plan_capacity():
    rows = []
    for label, meals in [("佛系 · 1天1顿", 1),
                         ("标准 · 1天2顿(中+晚)", 2),
                         ("硬核 · 1天3顿(早中晚)", 3)]:
        raw = TOTAL_WEEKS * meals
        uniq = raw * DEDUPE_RATE
        real = uniq * COMPLETION_RATE
        rows.append({"mode": label, "meals_per_day": meals,
                     "theoretical": round(raw),
                     "after_dedupe": round(uniq),
                     "realistic": round(real)})
    return {
        "source": "中国药科大学 2025-2026 学年校历（教务处）",
        "weeks_per_year": WEEKS_PER_YEAR,
        "gross_weeks": GROSS_WEEKS,
        "deductions": {
            "military_training": MILITARY_TRAINING,
            "graduation_early_leave": GRADUATION_EARLY,
            "exam_weeks_downgraded": EXAM_WEEKS,
        },
        "main_weeks": round(MAIN_WEEKS, 1),
        "light_weeks": LIGHT_WEEKS,
        "total_weeks": round(TOTAL_WEEKS, 1),
        "projections": rows,
        "note": ("去重 %.0f%% = 回头店占比；完成率 %.0f%% = "
                 "生病/考试/天气/预算导致的缺席" % ((1 - DEDUPE_RATE) * 100,
                                                    COMPLETION_RATE * 100)),
    }


def pick_areas(year, campus, meals_n, days):
    """按年份与出发地，挑出适合本次行程的区域（近的优先）"""
    if year == 4:
        return ["（Y4 为江浙沪皖高铁出行，见 references/07）"]
    pool = YEAR_AREAS.get(year, YEAR_AREAS[1])
    scored = sorted(pool, key=lambda a: travel_minutes(campus, a))
    # 一天之内不跨太远：取交通最短的 1-2 个区
    if days == 1 and meals_n <= 2:
        return scored[:1]
    return scored[:2]


def build_itinerary(args):
    profile = get_profile()
    campus = args.frm or profile.get("campus", "jiangning")
    budget = args.budget or profile.get("constraints", {}).get("budget_per_meal", 50)
    meals = [m.strip() for m in args.meals.split(",") if m.strip()]
    invalid = [m for m in meals if m not in MEAL_LABEL]
    if invalid:
        emit({"ok": False, "error": f"未知的餐段: {invalid}，可选: "
                                    f"{list(MEAL_LABEL.keys())}"})
        sys.exit(1)

    areas = pick_areas(args.year, campus, len(meals), args.days)
    per_day = max(1, len(meals) // max(1, args.days))

    # Y1 有内置店铺库，可直接出候选店；Y2-Y4 走降级链现场核实
    library, lib_meta = ([], None) if args.no_shops else load_shop_library()
    use_library = bool(library) and args.year == 1
    used_cats = set()

    days_out = []
    mi = 0
    for d in range(args.days):
        slots = []
        for _ in range(per_day):
            if mi >= len(meals):
                break
            m = meals[mi]
            mi += 1
            area = areas[d % len(areas)]
            rotation = CUISINE_ROTATION.get(len(meals), ["自选"])
            slot = {
                "meal": m,
                "label": MEAL_LABEL[m],
                "time": MEAL_TIME[m],
                "area": area,
                "cuisine_slot": rotation[min(len(slots), len(rotation) - 1)],
            }
            if use_library:
                found = pick_shop(library, m, area, budget, used_cats)
                if found:
                    slot["shop"] = found
                    # 槽位标签跟随实际选中的品类，避免「写小炒、推烤鸭」的自相矛盾
                    slot["cuisine_slot"] = found["pick"]["category"]
                    used_cats.add(found["category_id"])
                else:
                    slot["shop"] = {
                        "status": "needs_sourcing",
                        "reason": "内置库里这个餐段没有合适候选，交给小桐现场查",
                        "how_to": "见 references/10-restaurant-sourcing.md 降级链",
                    }
            else:
                slot["shop"] = {
                    "status": "needs_sourcing",
                    "reason": ("Y%d 暂无内置店铺库" % args.year) if not args.no_shops
                              else "已指定 --no-shops，只出骨架",
                    "how_to": "见 references/10-restaurant-sourcing.md 降级链",
                }
            slots.append(slot)
        days_out.append({"day": d + 1, "slots": slots})

    # 交通核算
    used_areas = list({s["area"] for day in days_out for s in day["slots"]})
    legs = [{"area": a, "one_way_min": travel_minutes(campus, a)}
            for a in used_areas if a in TRAVEL_FROM_JIANGNING
            or a in TRAVEL_FROM_XUANWUMEN]
    max_one_way = max([l["one_way_min"] for l in legs], default=0)
    total_travel = max_one_way * 2

    # 预算核算
    meals_count = len(meals)
    est_food = budget * meals_count * args.people
    est_transit = round((total_travel / 60) * 0 + 5 * args.people * len(used_areas))
    est_total = round(est_food + est_transit, 2)

    warnings = []
    if max_one_way > 45:
        warnings.append(
            f"单程约 {max_one_way} 分钟，往返 {total_travel} 分钟。"
            f"如果不想在路上耗太久，建议换同区域的方案。")
    if "latenight" in meals and campus == "jiangning":
        warnings.append(
            "含夜宵且从江宁出发：1 号线往中国药科大学方向末班约 23:00，注意时间。")
    if est_food > profile.get("constraints", {}).get("budget_monthly", 600) * 0.4:
        warnings.append(
            f"这一趟预计 ¥{est_food}，占你月预算的 "
            f"{est_food / max(1, profile.get('constraints', {}).get('budget_monthly', 600)):.0%}，"
            f"要不要收着点？")

    cons = profile.get("constraints", {}) or {}
    taboos = [x for x in (cons.get("never_eat") or []) + (cons.get("allergies") or [])
              + (profile.get("avoid") or []) if x]
    diet_reminder = None
    if taboos or cons.get("religious"):
        diet_reminder = {
            "never_eat": cons.get("never_eat") or [],
            "allergies": cons.get("allergies") or [],
            "avoid_profile": profile.get("avoid") or [],
            "religious": cons.get("religious"),
            "note": ("店铺库没有食材级字段，脚本**不做**自动过滤——"
                     "这是刻意的：按关键词猜「这家有没有香菜」等于编造。"
                     "请小桐在推荐时逐店口头提醒，或让用户自己看菜单确认。"),
        }

    return {
        "ok": True,
        "year": args.year,
        "campus": campus,
        "days": args.days,
        "people": args.people,
        "meals": meals,
        "areas": areas,
        "shop_library": lib_meta if use_library else {
            "status": "not_used",
            "reason": ("Y%d 暂无内置店铺库，需现场核实" % args.year)
                      if not args.no_shops else "已指定 --no-shops",
        },
        "itinerary": days_out,
        "diet_reminder": diet_reminder,
        "travel": {"legs": legs, "max_one_way_min": max_one_way,
                   "round_trip_min": total_travel},
        "budget": {"per_meal": budget, "people": args.people,
                   "est_food": round(est_food, 2),
                   "est_transit": est_transit,
                   "est_total": est_total},
        "warnings": warnings,
        "next_step": (
            "候选店来自内置店铺库。已按营业时间过滤——到点打烊的不会进主推，"
            "会单独列在 closed_at_this_time 里。营业时间没核到的店已标注，"
            "评分一律以现场为准。"
            if use_library else
            "以上为骨架。请按 references/10-restaurant-sourcing.md "
            "的三级降级链，逐格填入经核实的店铺信息。"),
    }


def progress():
    profile = get_profile()
    st = profile.get("stats", {})
    total = st.get("total_checkins", 0)
    weeks = st.get("weeks_active", 0)
    return {
        "total_checkins": total,
        "weeks_active": weeks,
        "weeks_total": round(TOTAL_WEEKS),
        "progress_pct": round(weeks / TOTAL_WEEKS * 100, 1) if TOTAL_WEEKS else 0,
        "areas_covered": len([a for a in st.get("areas", {}) if a in NJ_AREAS]),
        "areas_total": len(NJ_AREAS),
        "provinces": len(st.get("provinces", {})),
        "current_year": profile.get("current_year", 1),
        "spend": st.get("total_spend", 0),
    }


def main():
    ap = argparse.ArgumentParser(description="行程骨架生成与容量规划")
    ap.add_argument("--year", type=int, default=1, choices=[1, 2, 3, 4])
    ap.add_argument("--days", type=int, default=1, choices=[1, 2])
    ap.add_argument("--meals", default="lunch,dinner")
    ap.add_argument("--from", dest="frm", choices=["jiangning", "xuanwumen"])
    ap.add_argument("--budget", type=float)
    ap.add_argument("--people", type=int, default=1)
    ap.add_argument("--no-shops", action="store_true",
                    help="只出骨架，不填内置店铺库的候选店")
    ap.add_argument("--plan", action="store_true", help="输出四年容量规划")
    ap.add_argument("--progress", action="store_true", help="输出当前进度")
    args = ap.parse_args()

    if args.plan:
        emit(plan_capacity())
    elif args.progress:
        emit(progress())
    else:
        require_profile("生成行程")
        emit(build_itinerary(args))


if __name__ == "__main__":
    main()
