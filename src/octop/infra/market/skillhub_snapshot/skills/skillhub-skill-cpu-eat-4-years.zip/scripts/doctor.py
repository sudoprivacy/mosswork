#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
doctor.py —— 一键自检与排障

解决的问题：
  1. SKILL.md 里的 <SKILL_DIR> 是占位符，靠 Agent 替换，替换失败就找不到脚本。
     本脚本自己解析真实路径，并把它写进 repair 命令里，复制粘贴即可执行。
  2. 脚本报错时提示含糊。这里把每一项检查的「现象 → 原因 → 修复命令」一次说清。

用法：
  python3 scripts/doctor.py              # 全量自检
  python3 scripts/doctor.py --quick      # 只查必需项（快）

输出 JSON：
  ok      —— 必需项是否全部通过
  checks  —— 每一项的状态与说明
  repair  —— 失败项对应的可执行修复命令（已填好真实路径）
"""

import argparse
import json
import os
import py_compile
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.normpath(os.path.dirname(HERE))
DATA_DIR = os.path.join(SKILL_DIR, "data")
REF_DIR = os.path.join(SKILL_DIR, "references")
ASSET_DIR = os.path.join(SKILL_DIR, "assets")
PERSONA_DIR = os.path.join(SKILL_DIR, "persona")

USER_DIR = os.path.expanduser("~/.workbuddy/cpu-eats")

SCRIPTS = ["common.py", "taste_scoring.py", "checkin.py", "itinerary.py",
           "build_profile_site.py", "shops.py", "check_environment.py", "doctor.py"]
REFS = ["01-four-year-map.md", "02-taste-profile.md", "03-badge-system.md",
        "04-campus-geography.md", "05-nanjing-food-basics.md",
        "06-china-regional-cuisine.md", "07-jiangzhehu-wan.md",
        "08-feedback-parsing.md", "09-onboarding-script.md",
        "10-restaurant-sourcing.md", "11-y1-shop-verified.md",
        "12-faq.md", "13-getting-started.md", "setup-guide.md"]
DATA_FILES = ["user_profile_template.json", "y1_shops.json"]

checks = []
repairs = []


def add(cid, title, ok, required, detail, repair=None, plain=None):
    """登记一项检查。

    detail —— 给懂技术的人看的（版本号、路径、退出码）
    plain  —— 给出问题的人看的一句话大白话。不填就退回 detail。
    报错时先念 plain，用户听懂了再决定要不要看 detail。
    """
    checks.append({
        "id": cid, "title": title, "status": "ok" if ok else "fail",
        "required": required, "detail": detail, "plain": plain or detail,
    })
    if not ok and repair:
        repairs.append({"for": cid, "command": repair, "why": plain or detail})
    return ok


def check_python():
    v = sys.version_info
    ok = v >= (3, 9)
    cur = "%d.%d.%d" % (v[0], v[1], v[2])
    add("python3-min-version", "Python 版本", ok, True,
        f"当前 {cur}，要求 >= 3.9（实测 macOS 自带 /usr/bin/python3 3.9.6 通过）",
        "安装 Python 3.9+：https://www.python.org/downloads/ ；"
        "macOS 可执行 xcode-select --install 后用 /usr/bin/python3",
        plain=(f"你电脑里的 Python 是 {cur} 版，够用，没问题。"
               if ok else
               f"你电脑里的 Python 是 {cur} 版，太旧了，跑不起来。"
               "装个新版 Python 就行；Mac 上一般自带的那个就够用。"))


def check_scripts():
    missing = [s for s in SCRIPTS if not os.path.isfile(os.path.join(HERE, s))]
    if missing:
        add("scripts-present", "脚本完整性", False, True,
            f"缺少脚本：{', '.join(missing)}",
            "从备份恢复缺失文件，或重新安装本 Skill",
            plain=f"Skill 的文件不完整，少了 {len(missing)} 个程序文件。"
                  "重新装一次 Skill 就能修好。")
        return
    add("scripts-present", "脚本完整性", True, True, f"{len(SCRIPTS)} 个脚本齐全",
        plain=f"{len(SCRIPTS)} 个程序文件都在，齐全。")

    broken = []
    # 编译产物写进临时目录：既不污染 Skill 目录，也避开 cfile=/dev/null 在 3.9 上的限制
    with tempfile.TemporaryDirectory() as tmp:
        for s in SCRIPTS:
            try:
                py_compile.compile(os.path.join(HERE, s),
                                   cfile=os.path.join(tmp, s + "c"),
                                   doraise=True)
            except py_compile.PyCompileError as e:
                broken.append(f"{s}: {str(e).strip().splitlines()[-1]}")
            except Exception as e:
                broken.append(f"{s}: {e}")
    add("scripts-compile", "脚本可编译", not broken, True,
        "全部脚本语法正常" if not broken else f"编译失败：{'; '.join(broken)}",
        "从备份恢复被改坏的脚本，或重新安装本 Skill",
        plain=("程序文件都能正常读，没有损坏。"
               if not broken else
               f"有 {len(broken)} 个程序文件被改坏了，跑不起来。"
               "重新装一次 Skill 就能修好。"))


def check_resources():
    missing = [f for f in REFS if not os.path.isfile(os.path.join(REF_DIR, f))]
    add("references-present", "知识库文件", not missing, True,
        "references/ 齐全" if not missing else f"缺少：{', '.join(missing)}",
        "从备份恢复 references/ 目录",
        plain=("资料文件都在。"
               if not missing else
               f"少了 {len(missing)} 个资料文件（比如常见问题、上手指南）。"
               "影不影响用要看少的是哪个，建议直接重装 Skill。"))

    missing_d = [f for f in DATA_FILES if not os.path.isfile(os.path.join(DATA_DIR, f))]
    add("data-files-present", "数据文件", not missing_d, True,
        "data/ 齐全" if not missing_d else f"缺少：{', '.join(missing_d)}",
        "从备份恢复 data/ 目录",
        plain=("店铺数据文件都在。"
               if not missing_d else
               "少了店铺数据文件——没它就只能给你方向，给不了具体店名。"
               "重装 Skill 可恢复。"))

    tpl = os.path.join(ASSET_DIR, "profile_template.html")
    add("profile-template-present", "资料库模板", os.path.isfile(tpl), True,
        "assets/profile_template.html 存在" if os.path.isfile(tpl)
        else "模板缺失，资料库无法生成（不会生成残缺页面）",
        "从备份恢复 assets/profile_template.html",
        plain=("导出「我的吃饭档案」用的模板在。"
               if os.path.isfile(tpl) else
               "导出「我的吃饭档案」用的模板丢了，暂时导不出页面。"
               "重装 Skill 可恢复；你的打卡数据不受影响。"))

    persona = os.path.join(PERSONA_DIR, "persona.md")
    add("persona-present", "小桐人格文件", os.path.isfile(persona), True,
        "persona/persona.md 存在" if os.path.isfile(persona)
        else "人格文件缺失，小桐无法开口（首次加载必读）",
        "从备份恢复 persona/persona.md",
        plain=("小桐的说话方式文件在。"
               if os.path.isfile(persona) else
               "小桐的说话方式文件丢了，它没法正常开口。"
               "这个必须修，重装 Skill 即可。"))


def check_data_dir():
    home = os.path.expanduser("~")
    if not os.path.isdir(home):
        add("home-writable", "用户目录可写", False, True,
            f"家目录不存在：{home}", "检查系统用户配置",
            plain="系统找不到你的用户文件夹，可能账户配置有问题。"
                  "这个建议找懂电脑的人看一眼，别自己乱改。")
        return
    writable = os.access(home, os.W_OK)
    exists = os.path.isdir(USER_DIR)
    ok = writable
    detail = f"数据目录 {USER_DIR} " + ("已存在" if exists else "尚未创建（首次建档时自动创建）")
    if not writable:
        detail = f"无写权限：{home}"
    add("user-data-writable", "数据目录可写", ok, True, detail,
        f"修复目录所有者：sudo chown -R $(whoami) {home}/.workbuddy 2>/dev/null || "
        f"echo '请手动确认 {home}/.workbuddy 的所有者为当前用户'",
        plain=("能正常保存你的打卡记录和口味档案。"
               if ok else
               "电脑不让小桐保存数据（没写权限），打卡会存不下来。"
               "下面那条命令能修，但涉及系统权限，拿不准就先问一下懂电脑的人。"))


def check_profile():
    p = os.path.join(USER_DIR, "profile.json")
    exists = os.path.isfile(p)
    add("profile-exists", "用户档案", exists, False,
        f"档案已建立：{p}" if exists
        else f"尚未建档：{p} 不存在。行程生成与资料库导出会以此报错退出（退出码 2），属流程保护非缺陷。",
        f'cd "{SKILL_DIR}" && python3 scripts/checkin.py --init-profile '
        f'--data \'{{"campus":"jiangning","grade":1,"mode":"guided"}}\'',
        plain=("已经知道你是谁了，档案建好了。"
               if exists else
               "小桐还不认识你——先跟它说句话走一遍建档，"
               "或者直接说「随便推荐个」走极速通道，三个问题就能开始吃。"))


def check_shops():
    f = os.path.join(DATA_DIR, "y1_shops.json")
    if not os.path.isfile(f):
        add("shops-data", "Y1 店铺库", False, False, "y1_shops.json 不存在",
            "从备份恢复 data/y1_shops.json",
            plain="店铺数据文件不见了，暂时给不了具体店名。重装 Skill 可恢复。")
        return
    try:
        with open(f, encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as e:
        add("shops-data", "Y1 店铺库", False, False, f"JSON 解析失败：{e}",
            "从备份恢复 data/y1_shops.json",
            plain="店铺数据文件被改坏了，读不出来。重装 Skill 可恢复。")
        return

    from datetime import datetime, date
    cats = data.get("categories", [])
    active = [s for c in cats for s in c.get("shops", [])
              if s.get("status", "active") == "active"]
    covered = len([c for c in cats
                   if any(s.get("status", "active") == "active" for s in c.get("shops", []))])
    stale = []
    for s in active:
        try:
            d = datetime.strptime(str(s.get("verified_at"))[:10], "%Y-%m-%d").date()
        except (ValueError, TypeError):
            stale.append(s.get("name", "?"))
            continue
        if (date.today() - d).days > 90:
            stale.append(s.get("name", "?"))

    ok = covered > 0 and not stale
    detail = (f"{covered}/{len(cats)} 品类，共 {len(active)} 家；"
              f"过期（>90 天）{len(stale)} 家")
    if stale:
        detail += f"，需复验：{', '.join(stale[:5])}" + ("…" if len(stale) > 5 else "")
    add("shops-data", "Y1 店铺库", ok, False, detail,
        f'cd "{SKILL_DIR}" && python3 scripts/shops.py verify',
        plain=(f"店铺数据是新鲜的：{covered} 个品类、{len(active)} 家店，"
               "都在保质期内。"
               if ok else
               f"有 {len(stale)} 家店的信息超过 90 天没复验了，"
               "可能已经关门或搬家。不影响现在用，但推荐时会提示你现场确认。"))


def check_dependencies():
    """可选依赖：缺了只降级，不阻塞。"""
    dep_file = os.path.join(SKILL_DIR, "skill-dependencies.json")
    if not os.path.isfile(dep_file):
        add("dependency-manifest", "依赖清单", False, False,
            "skill-dependencies.json 缺失", "从备份恢复 skill-dependencies.json",
            plain="依赖说明文件丢了，不影响核心功能。重装 Skill 可恢复。")
        return
    add("dependency-manifest", "依赖清单", True, False,
        "skill-dependencies.json 存在（2 项必需 + 6 项可选）",
        plain="依赖清单在。其中只有 2 项是必需的，其余 6 项不装也能用。")

    ce = os.path.join(HERE, "check_environment.py")
    if os.path.isfile(ce):
        try:
            r = subprocess.run([sys.executable, ce, "--capability", "onboarding"],
                               capture_output=True, text=True, timeout=60)
            if r.returncode == 0:
                try:
                    out = json.loads(r.stdout)
                    st = out.get("status") or out.get("overall") or "unknown"
                except Exception:
                    st = "unknown"
                add("env-onboarding", "基础能力环境检查", st == "ready", False,
                    f"onboarding 能力状态：{st}",
                    plain=("基础能力齐全，直接能用。"
                           if st == "ready" else
                           "有些可选的数据源没配（比如实时评分）。"
                           "不影响核心使用——店名、地址、人均、营业时间、行程都有。"))
            else:
                add("env-onboarding", "基础能力环境检查", False, False,
                    f"检查脚本退出码 {r.returncode}（非阻断）",
                    plain="没能确认可选数据源的状态。不影响核心使用，可以继续。")
        except Exception as e:
            add("env-onboarding", "基础能力环境检查", False, False,
                f"检查未跑通（非阻断）：{e}",
                plain="环境检查没跑起来。不影响核心使用，可以继续。")

    add("optional-deps", "可选数据源", True, False,
        "agent-browser / 大众点评 / 小红书 / 美团专家均为可选。"
        "未安装时按 skill-dependencies.json 的降级矩阵降级，核心流程不中断。"
        "注意：check_environment.py 对登录态探测报 unavailable 是预期行为，"
        "装没装看 file 检查，能不能用看登录态，不要反复弹安装引导。",
        plain="大众点评 / 美团 / 小红书这些是「锦上添花」，不装照样能用。"
              "不装只是查不到实时评分，店名、地址、多少钱、几点开门都有。")


def main():
    ap = argparse.ArgumentParser(description="一键自检与排障")
    ap.add_argument("--quick", action="store_true", help="只查必需项（跳过可选依赖）")
    args = ap.parse_args()

    check_python()
    check_scripts()
    check_resources()
    check_data_dir()
    check_profile()
    check_shops()
    if not args.quick:
        check_dependencies()

    failed_required = [c for c in checks if c["required"] and c["status"] == "fail"]
    failed_optional = [c for c in checks
                       if not c["required"] and c["status"] == "fail"]
    ok = not failed_required

    if ok and not failed_optional:
        plain = "全部正常，放心用。"
    elif ok:
        plain = (f"能正常用。有 {len(failed_optional)} 项是可选的没配，"
                 "不影响核心功能——店名、地址、人均、营业时间、行程都有。")
    else:
        plain = (f"有 {len(failed_required)} 个地方坏了，"
                 "小桐可能没法正常工作。下面每一条都写了「人话」和「怎么修」，"
                 "照着做一遍，再重跑一次这个检查。")

    emit = {
        "ok": ok,
        "skill_dir": SKILL_DIR,
        "python": sys.executable,
        "user_data_dir": USER_DIR,
        "checks": checks,
        "repair": repairs,
        "note": (
            "repair 里的命令已填好本机的真实路径，直接复制粘贴执行即可，"
            "不需要再替换 <SKILL_DIR> 占位符。"
        ),
        # 给用户看的一句话：先念这句，别一上来甩技术细节
        "plain": plain,
    }
    if not ok:
        emit["headline"] = (
            f"有 {len(failed_required)} 项必需检查未通过，按 repair 里的命令修复后重跑本脚本。"
        )
    else:
        emit["headline"] = "必需项全部通过，可以正常使用。"

    print(json.dumps(emit, ensure_ascii=False, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
