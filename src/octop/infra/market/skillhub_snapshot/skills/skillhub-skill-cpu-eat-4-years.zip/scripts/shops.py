#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
y1_shops.json 管理工具

职责：
  1. 初始化 Y1 的 20 个必吃品类骨架
  2. 录入/更新核实过的店铺（强制 source + verified_at）
  3. 渲染成 references/11-y1-shop-verified.md 供 Skill 读取
  4. 输出覆盖度统计（哪些品类还没有店）

硬规则：
  - 没有 source / verified_at 的店，一律拒收
  - rating / avg_price 必须来自实测抓取，不接受手写估值
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime, date

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)
DATA_FILE = os.path.join(SKILL_DIR, "data", "y1_shops.json")
OUT_MD = os.path.join(SKILL_DIR, "references", "11-y1-shop-verified.md")

# 数据保鲜期：超过这个天数必须重新走降级链复验
STALE_DAYS = 90

# Y1 必吃清单 20 项（来源：references/01-four-year-map.md）
CATEGORIES = [
    # (id, 名称, 分组, 备注)
    ("yanshuiya",     "盐水鸭",       "鸭",     "冷盘咸鲜，桂花鸭是代表"),
    ("nanjingkaoya",  "南京烤鸭",     "鸭",     "焖炉烤 + 卤汁，和北京烤鸭完全不同"),
    ("banya",         "板鸭 / 酱鸭",  "鸭",     "更咸更紧实，下酒"),
    ("yaxuefensi",    "鸭血粉丝汤",   "鸭",     "配锅贴是标准套餐"),
    ("pidumian",      "皮肚面",       "汤与面", "炸猪皮吸汤，南京独有"),
    ("jizhitangbao",  "鸡汁汤包",     "汤与面", "比上海小笼大、汤更鲜"),
    ("chaihuohuntun", "柴火馄饨",     "汤与面", "老南京深夜食堂"),
    ("laohumian",     "老卤面",       "汤与面", "酱油老卤，和大碗皮肚面同源"),
    ("niurouguotie",  "牛肉锅贴",     "锅贴与饼", "七家湾是清真锅贴圣地，底部焦脆"),
    ("yayoushaobing", "鸭油烧饼",     "锅贴与饼", "鸭油和面，咸香"),
    ("xieqiaohuang",  "蟹壳黄",       "锅贴与饼", "小巧酥脆"),
    ("sushaobing",    "酥烧饼",       "锅贴与饼", "排队名店，趁热"),
    ("guihuatangyumiao", "桂花糖芋苗", "甜与糯", "芋仔 + 桂花糖浆，秋天最应季"),
    ("chixiaodouyuanxiao", "赤豆元宵", "甜与糯", "红豆沙 + 小圆子"),
    ("meihuagao",     "梅花糕",       "甜与糯", "现做现卖，豆沙馅"),
    ("tangzhouou",    "糖粥藕",       "甜与糯", "糯米塞藕孔，浇红糖汁"),
    ("mizhiou",       "蜜汁藕",       "甜与糯", "和糖粥藕同源不同做法"),
    ("shijindoufulao", "什锦豆腐涝",  "杂项",   "豆腐脑的南京版本，加十几种料"),
    ("zhuangyuandou", "状元豆 / 五香蛋", "杂项", "夫子庙小吃"),
    ("huozhuzi",      "活珠子 / 旺鸡蛋", "杂项", "猎奇项，Y1 最后再给，作结业考试"),
]

GROUPS = ["鸭", "汤与面", "锅贴与饼", "甜与糯", "杂项"]

CONF_LABEL = {"high": "高", "medium": "中", "low": "低"}


def emit(obj):
    """统一以 JSON 输出到 stdout，便于 Agent 解析"""
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def load():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save(data):
    data["meta"]["updated_at"] = datetime.now().strftime("%Y-%m-%d")
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def cmd_init(args):
    data = load()
    existing = {c["id"] for c in data["categories"]}
    added = 0
    for cid, name, group, note in CATEGORIES:
        if cid in existing:
            continue
        data["categories"].append(
            {"id": cid, "name": name, "group": group, "note": note, "shops": []}
        )
        added += 1
    save(data)
    print(f"已初始化 {added} 个品类，共 {len(data['categories'])} 个")
    return 0


def cmd_add(args):
    data = load()
    cat = None
    for c in data["categories"]:
        if c["id"] == args.category or c["name"] == args.category:
            cat = c
            break
    if cat is None:
        print(f"品类不存在：{args.category}。先跑 --init 看可用品类。")
        return 1

    payload = json.loads(args.json)
    required = ["name", "source", "verified_at"]
    missing = [k for k in required if not payload.get(k)]
    if missing:
        print(f"拒收：缺少必填字段 {missing}（source / verified_at 是红线）")
        return 1

    shop = {
        "name": payload["name"],
        "rating": payload.get("rating"),
        "review_count": payload.get("review_count"),
        "avg_price": payload.get("avg_price"),
        "address": payload.get("address", ""),
        "district": payload.get("district", ""),
        "area": payload.get("area", ""),
        "campus": payload.get("campus", ""),
        "transit_min": payload.get("transit_min"),
        "hours": payload.get("hours", ""),
        "source": payload["source"],
        "source_url": payload.get("source_url", ""),
        "verified_at": payload["verified_at"],
        "confidence": payload.get("confidence", "medium"),
        "tips": payload.get("tips", ""),
        "status": payload.get("status", "active"),
    }

    # 同名覆盖（视为更新）
    for i, s in enumerate(cat["shops"]):
        if s["name"] == shop["name"]:
            cat["shops"][i] = shop
            save(data)
            print(f"已更新：{cat['name']} / {shop['name']}")
            return 0
    cat["shops"].append(shop)
    save(data)
    print(f"已新增：{cat['name']} / {shop['name']}（{shop['confidence']}）")
    return 0


def cmd_stats(args):
    data = load()
    total_cat = len(data["categories"])
    covered = 0
    total_shop = 0
    lines = []
    for c in data["categories"]:
        n = len([s for s in c["shops"] if s.get("status", "active") == "active"])
        total_shop += n
        if n > 0:
            covered += 1
        flag = "✅" if n >= 2 else ("⚠️" if n == 1 else "❌")
        lines.append(f"  {flag} {c['group']:<5} {c['name']:<14} {n} 家")
    print(f"品类覆盖：{covered}/{total_cat}　店铺总数：{total_shop}")
    print("\n".join(lines))
    return 0


def cmd_render(args):
    data = load()
    today = datetime.now().strftime("%Y-%m-%d")

    parts = [
        "# Y1 已核实店铺库",
        "",
        f"> 数据文件：`data/y1_shops.json`（由 `scripts/shops.py` 维护）",
        f"> 最后更新：**{data['meta']['updated_at']}**　渲染日期：{today}",
        "",
        "**使用规则**：",
        "",
        "1. 推荐时**优先从这里取店**，不临时编造；",
        f"2. 表里每家店都带 `核实时间`，超过 **{STALE_DAYS} 天** 要重新走降级链复验（门店会关、评分会变）；",
        "3. **评分一律不预置**（表里没有评分区，这是故意的）。需要评分时必须走降级链现场查，",
        "   查不到就直说「这家我没查到评分」，不许凭印象给数字；",
        "4. `置信度 低` 的店，推荐时主动对用户说明「这家我只查到一个来源，去之前你再看看」；",
        "   门牌未核实的店，必须提示用户出发前用地图确认；",
        "5. 某品类若为空，说明当时没核实到可信数据 —— **诚实说没找到**，不要用「听说有家不错的」糊弄；",
        "6. `人均` 是公开区间不是实测，只用来做预算档位参考，不要当成精确报价；",
        "7. `营业时间` 为 `—` 的店表示**没核到**（不是 24 小时营业）。行程脚本会把它们",
        "   排在后面并标注「营业时间没核到，去之前确认」；已核到时间的店，行程会按餐段过滤，",
        "   到点打烊的不会进主推。",
        "",
    ]

    for g in GROUPS:
        cats = [c for c in data["categories"] if c["group"] == g]
        if not cats:
            continue
        parts.append(f"## {g}")
        parts.append("")
        for c in cats:
            active = [s for s in c["shops"] if s.get("status", "active") == "active"]
            parts.append(f"### {c['name']}")
            parts.append("")
            parts.append(f"_{c['note']}_")
            parts.append("")
            if not active:
                parts.append("> ⚠️ 尚未核实到可信店铺。推荐前请走降级链现场查。")
                parts.append("")
                continue
            parts.append("| 店名 | 人均 | 区域 | 地址 | 营业时间 | 车程 | 核实 | 置信 |")
            parts.append("|------|------|------|------|------|------|------|------|")
            for s in active:
                price = f"¥{s['avg_price']}" if s.get("avg_price") else "—"
                area = s.get("area") or s.get("district") or "—"
                transit = f"{s['transit_min']}min" if s.get("transit_min") else "—"
                conf = CONF_LABEL.get(s.get("confidence", "medium"), "中")
                addr = (s.get("address") or "—").replace("|", "/")
                hours = (s.get("hours") or "—").replace("|", "/")
                parts.append(
                    f"| {s['name']} | {price} | {area} | {addr} | {hours} | "
                    f"{transit} | {s['verified_at']} | {conf} |"
                )
            parts.append("")
            for s in active:
                if s.get("tips"):
                    src = s.get("source_url") or s.get("source_note") or ""
                    line = f"- **{s['name']}**：{s['tips']}"
                    if src:
                        line += f"（来源：{src}）"
                    parts.append(line)
            if any(s.get("tips") for s in active):
                parts.append("")

    covered = len([c for c in data["categories"]
                   if any(s.get("status", "active") == "active" for s in c["shops"])])
    total_shops = sum(len([s for s in c["shops"] if s.get("status", "active") == "active"])
                      for c in data["categories"])
    all_shops = [s for c in data["categories"] for s in c["shops"]
                 if s.get("status", "active") == "active"]
    n_low = len([s for s in all_shops if s.get("confidence") == "low"])
    n_nohours = len([s for s in all_shops if not _hours_window(s.get("hours"))])
    n_stale = 0
    for s in all_shops:
        age = _age_days(s.get("verified_at"))
        if age is None or age > STALE_DAYS:
            n_stale += 1

    parts.append("---")
    parts.append("")
    parts.append(f"**当前覆盖度**：{covered}/{len(data['categories'])} 个品类，共 {total_shops} 家。")
    parts.append("")
    parts.append("**数据体检**：")
    parts.append("")
    parts.append(f"- 置信度「低」（单一来源或门牌未核实）：**{n_low} 家** —— 推荐时必须主动说明")
    parts.append(f"- 营业时间未核到：**{n_nohours} 家** —— 行程里会排后并标注，不要当成随时可去")
    parts.append(f"- 超过 {STALE_DAYS} 天未复验：**{n_stale} 家** —— 推荐前必须重新走降级链")
    parts.append("- 复算命令：`python3 scripts/shops.py verify`")
    parts.append("")

    with open(OUT_MD, "w", encoding="utf-8") as f:
        f.write("\n".join(parts))
    print(f"已渲染：{OUT_MD}（{covered}/{len(data['categories'])} 品类，{total_shops} 家）")
    return 0


def _age_days(verified_at):
    try:
        d = datetime.strptime(str(verified_at)[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None
    return (date.today() - d).days


def _hours_window(v):
    """'07:30-21:00' / '24小时' → 可用的营业窗口；核不到返回 None。

    与 itinerary.py 的解析保持一致：只写了一个时间点、格式不认识、字段为空，
    都算「不知道」。体检表把它们单列出来，避免把不知道当成没问题。
    """
    if not v:
        return None
    text = str(v)
    if re.search(r"24\s*小时|全天|24h", text, re.I):
        return (0, 24 * 60)

    def hm(t):
        m = re.search(r"(\d{1,2}):(\d{2})", t)
        return int(m.group(1)) * 60 + int(m.group(2)) if m else None

    stamps = re.findall(r"\d{1,2}:\d{2}", text)
    if len(stamps) < 2:
        return None
    a, b = hm(stamps[0]), hm(stamps[1])
    if a is None or b is None:
        return None
    if b <= a:
        b += 24 * 60
    return (a, b)


def cmd_verify(args):
    """数据保鲜体检：哪些店过期了、哪些字段缺失、哪些置信度低。

    推荐前调用，避免把陈旧的店推给用户。输出可直接执行的处理建议。
    """
    data = load()
    stale, weak, noaddr, missing_src, nohours = [], [], [], [], []
    total = 0
    for c in data["categories"]:
        for s in c["shops"]:
            if s.get("status", "active") != "active":
                continue
            total += 1
            label = f"{c['name']} / {s['name']}"
            age = _age_days(s.get("verified_at"))
            if age is None or age > STALE_DAYS:
                stale.append({"shop": label, "verified_at": s.get("verified_at"),
                              "age_days": age})
            if s.get("confidence") == "low":
                weak.append({"shop": label, "reason": "单一来源或门牌未核实"})
            if not (s.get("address") or "").strip() or "未核实" in (s.get("address") or ""):
                noaddr.append({"shop": label, "address": s.get("address")})
            if not s.get("source") or not s.get("verified_at"):
                missing_src.append({"shop": label})
            if not _hours_window(s.get("hours")):
                nohours.append({"shop": label, "hours": s.get("hours")})

    ok = not (stale or missing_src)
    emit({
        "ok": ok,
        "checked": total,
        "stale_days_threshold": STALE_DAYS,
        "stale": stale,
        "low_confidence": weak,
        "address_uncertain": noaddr,
        "missing_source_or_date": missing_src,
        "hours_unverified": nohours,
        "how_to_use": (
            "stale 里的店推荐前必须重新走 references/10 的降级链复验；"
            "low_confidence 的店推荐时要主动说明「这家我只查到一个来源」；"
            "address_uncertain 的店必须提示用户出发前用地图确认门牌；"
            "hours_unverified 的店没有可解析的营业时间，行程里会排在后面并标注"
            "「营业时间没核到，去之前确认」——不要假装它随时开着。"
        ),
    })
    return 0 if ok else 1


def cmd_cats(args):
    for cid, name, group, note in CATEGORIES:
        print(f"{cid:<22} {group:<5} {name}")
    return 0


def main():
    ap = argparse.ArgumentParser(description="Y1 店铺库管理")
    sub = ap.add_subparsers(dest="cmd")

    sub.add_parser("init", help="初始化 20 个品类骨架").set_defaults(func=cmd_init)
    sub.add_parser("cats", help="列出品类 id").set_defaults(func=cmd_cats)
    sub.add_parser("stats", help="覆盖度统计").set_defaults(func=cmd_stats)
    sub.add_parser("verify", help="数据保鲜体检（过期/低置信/门牌未核实）").set_defaults(func=cmd_verify)
    sub.add_parser("render", help="渲染 references/11-y1-shop-verified.md").set_defaults(func=cmd_render)

    p_add = sub.add_parser("add", help="录入/更新一家店")
    p_add.add_argument("--category", required=True, help="品类 id 或中文名")
    p_add.add_argument("--json", required=True, help="店铺 JSON 字符串")
    p_add.set_defaults(func=cmd_add)

    args = ap.parse_args()
    if not args.cmd:
        ap.print_help()
        return 1
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
