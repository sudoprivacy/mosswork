#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
checkin.py —— 打卡记录 + 口味信号提取 + 徽章判定 + 口味漂移

用法：
  # 初始化/更新档案
  python3 checkin.py --init-profile --data '{"campus":"jiangning","grade":1,...}'

  # 记录一次打卡
  python3 checkin.py --name "李记锅贴" --area "秦淮区" --cuisine "南京小吃" \
      --rating 4 --price 45 --dishes "牛肉锅贴,鸭血粉丝汤" \
      --note "汤很鲜，但锅贴凉了" --source dianping

  # 查看徽章与等级
  python3 checkin.py --badges

  # 查看统计
  python3 checkin.py --stats

  # 距上次打卡天数（用于触发「主动索要反馈」）
  python3 checkin.py --days-since

  # 登记心愿（用户随口提的需求，R2.5）
  python3 checkin.py --wish "想吃日料" --wish-note "生日想吃顿好的"

  # 查看心愿清单
  python3 checkin.py --wish-list

  # 吃到了 → 兑现心愿，自动解锁心愿徽章
  python3 checkin.py --name "和风食堂" --area "鼓楼区" --cuisine "日料" \
      --rating 5 --price 120 --note "生日那顿，值了" --source self \
      --wish-done "想吃日料"
"""

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (  # noqa: E402
    DIMS, DIM_LABEL, NJ_AREAS, MILESTONES, AREA_BADGES, AREA_UNLOCK_LINES,
    ensure_dirs, now, now_iso, get_profile, put_profile,
    read_checkins, append_checkin, load_json, save_json, emit,
    blend, calc_score, level_of, next_milestone, bar,
    add_wish, done_wish, get_wishlist, open_wishes, wish_badge_id,
)

BADGES_F = None  # 延迟，见 get_badges


# ------------------------------------------------------------ 口味信号
SIGNAL_RULES = [
    (r"太辣|辣得过瘾|很辣|辣爽",              "spicy",          +0.3),
    (r"不够辣|没什么辣味",                     "spicy",          +0.2),
    (r"麻|花椒",                              "numbing",        +0.2),
    (r"太甜|甜得|甜了",                       "sweet_vs_savory", +0.3),
    (r"不够甜|不甜",                          "sweet_vs_savory", -0.3),
    (r"油腻|太油|腻",                         "richness",       -0.3),
    (r"清爽|不油|清淡",                       "richness",       -0.3),
    (r"很特别|没吃过|新奇|第一次吃",           "adventure",      +0.3),
    (r"内脏|鸭血|大肠|活珠子|折耳根|毛肚",      "offal",          +0.2),
    (r"面|粉|饭|主食|碳水|包子|馒头",           "carb",           +0.1),
    (r"酸|醋|开胃",                           "sour",           +0.2),
    (r"一个人|独自|自己去",                    "solo_dining",    +0.2),
    (r"又来|第\s*[二三四五六七八九十]\s*次|常来|老地方", "loyalty", +0.3),
]

EMOTION_RULES = [
    (r"累|烦|压力大|崩溃|熬|通宵", "tired"),
    (r"开心|庆祝|生日|过了|爽", "happy"),
    (r"难过|想家|失落|emo|低落", "sad"),
]


def extract_signals(note, dishes):
    text = f"{note or ''} {' '.join(dishes or [])}"
    signals = {}
    for pattern, dim, delta in SIGNAL_RULES:
        if re.search(pattern, text):
            if dim in ("spicy", "sweet_vs_savory", "richness"):
                # 方向性维度：负面表达反向
                if re.search(r"太|不够|不|腻", text) and delta > 0:
                    delta = -delta
            signals[dim] = signals.get(dim, 0) + delta
    # 单次上限 0.3
    return {k: max(-0.3, min(0.3, v)) for k, v in signals.items()}


def detect_emotion(note):
    if not note:
        return "neutral"
    for pattern, emo in EMOTION_RULES:
        if re.search(pattern, note):
            return emo
    return "neutral"


# ------------------------------------------------------------ 徽章
def get_badges():
    return load_json(Path.home() / ".workbuddy" / "cpu-eats" / "badges.json",
                     {"unlocked": []})


def put_badges(b):
    save_json(Path.home() / ".workbuddy" / "cpu-eats" / "badges.json", b)


def has(badges, bid):
    return any(x["id"] == bid for x in badges.get("unlocked", []))


def unlock(badges, bid, name, category, line, hidden=False, context=None):
    if has(badges, bid):
        return None
    rec = {
        "id": bid,
        "name": name,
        "category": category,
        "hidden": hidden,
        "unlocked_at": now_iso(),
        "unlock_line": line,
        "context": context,
    }
    badges.setdefault("unlocked", []).append(rec)
    return rec


def check_badges(profile, checkins, badges):
    """返回本次新解锁的徽章列表"""
    new = []
    st = profile["stats"]
    total = st.get("total_checkins", 0)
    areas = st.get("areas", {})
    provinces = st.get("provinces", {})
    shops = st.get("shops", {})
    slots = st.get("by_time_slot", {})
    months = st.get("by_month", {})
    ctx_last = checkins[-1]["shop"]["name"] if checkins else None

    # --- 里程碑 ---
    for n, name in MILESTONES:
        if total >= n:
            r = unlock(badges, f"ms_{n}", name, "milestone",
                       f"{n} 家了。", context=f"第 {n} 家：{ctx_last}")
            if r:
                new.append(r)
                new[-1]["unlock_line"] = MILESTONE_LINES.get(n, f"{n} 家了。")

    # --- 地理：南京各区 ---
    for area, (need, name, line) in AREA_BADGES.items():
        if areas.get(area, 0) >= need:
            r = unlock(badges, f"area_{area}", name, "area", line,
                       context=f"{area} 满 {need} 家")
            if r:
                new.append(r)

    # 过江
    if areas.get("浦口区", 0) + areas.get("六合区", 0) >= 1:
        r = unlock(badges, "cross_river", "过江！", "area",
                   AREA_UNLOCK_LINES["过江！"], hidden=True)
        if r:
            new.append(r)

    # 离开江宁（对江宁校区用户）
    if profile.get("campus") == "jiangning":
        if any(a != "江宁区" for a in areas if areas[a] > 0):
            r = unlock(badges, "leave_jiangning", "进城了", "area",
                       "第一次进城吃饭。值得记一笔。")
            if r:
                new.append(r)

    # 南京通
    if all(areas.get(a, 0) > 0 for a in NJ_AREAS):
        r = unlock(badges, "nj_master", "南京通", "area",
                   AREA_UNLOCK_LINES["南京通"])
        if r:
            new.append(r)

    # --- 菜系：省级 ---
    for prov in provinces:
        r = unlock(badges, f"prov_{prov}", f"{prov}味", "cuisine",
                   f"{prov}，解锁。")
        if r:
            new.append(r)

    if len(provinces) >= 34:
        r = unlock(badges, "all_prov", "全国胃", "cuisine",
                   "在南京，你把中国吃了一遍。这个真的很难。")
        if r:
            new.append(r)

    provinces_js = [p for p in provinces if p in ("江苏",)]
    if len([p for p in provinces if p in JS_CITIES_AS_PROV]) >= 8:
        r = unlock(badges, "su_daqiang", "苏大强", "geo",
                   "散装江苏，你凑齐大半个了。")
        if r:
            new.append(r)

    # --- 彩蛋：行为 ---
    # 回头是岸：同一家 5 次
    for shop, cnt in shops.items():
        if cnt >= 5 and not has(badges, f"loyal_{shop}"):
            r = unlock(badges, f"loyal_{shop}", "回头是岸", "easter",
                       f"有家店你去了第五次了——{shop} 吧？", hidden=True)
            if r:
                new.append(r)

    # 夜行生物 22 点后 15 次
    if slots.get("latenight", 0) >= 15:
        r = unlock(badges, "night_owl", "夜行生物", "easter",
                   "22 点后还在吃，你是真的 nocturne。", hidden=True)
        if r:
            new.append(r)

    # 早八人
    if slots.get("breakfast", 0) >= 10:
        r = unlock(badges, "early_bird", "早八人", "easter",
                   "八点前吃早餐，十次了。", hidden=True)
        if r:
            new.append(r)

    # 嗦粉王（简化：面/粉类菜系 20 家）
    noodle_cnt = sum(v for k, v in profile["stats"].get("cuisines", {}).items()
                     if re.search(r"面|粉|米线", k))
    if noodle_cnt >= 20:
        r = unlock(badges, "noodle_king", "嗦粉王", "easter",
                   "20 家面/粉，你是碳水的信徒。", hidden=True)
        if r:
            new.append(r)

    # 独行侠
    if slots.get("solo", 0) >= 20:
        r = unlock(badges, "solo_rider", "独行侠", "easter",
                   "一个人吃了 20 次。自在是种本事。", hidden=True)
        if r:
            new.append(r)

    # 季节：梧桐叶黄了（11 月 8 次）
    if months.get("11", 0) >= 8:
        r = unlock(badges, "wutong", "梧桐叶黄了", "easter",
                   "梧桐黄的时候，你在外面吃了 8 顿。", hidden=True)
        if r:
            new.append(r)

    # 季节：梅雨季
    if months.get("06", 0) + months.get("07", 0) >= 8:
        r = unlock(badges, "plum_rain", "梅雨季", "easter",
                   "梅雨天也拦不住你出门。", hidden=True)
        if r:
            new.append(r)

    # 坚持：连续 8 周
    if st.get("streak_weeks", 0) >= 8:
        r = unlock(badges, "persist", "坚持", "easter",
                   "八周了，你没断过。", hidden=True)
        if r:
            new.append(r)

    return new


MILESTONE_LINES = {
    1: "第一顿。四年从这顿开始算。",
    5: "5 家了。你已经不是只会吃食堂的人了。",
    10: "两位数。有点上道了。",
    20: "20 家。你开始有『自己喜欢的那几家』了吧。",
    30: "30 家。有些店你大概能带朋友去了。",
    50: "50 家。说你是半个南京人，应该没人反驳。",
    70: "70 家。你是不是已经开始跟人说『那家一般』了？",
    100: "100 家。这是个值得记一下的数字。",
    130: "130 家。你的胃已经是南京的形状了。",
    160: "160 家。你知道自己要什么了。",
    200: "200 家。四年目标达成。",
    250: "250 家。梧桐都黄了四轮了。",
}

JS_CITIES_AS_PROV = ["江苏"]  # 简化占位，实际以城市维度统计


# ------------------------------------------------------------ 时间槽
def slot_of(ts):
    try:
        dt = datetime.fromisoformat(ts)
    except Exception:
        dt = now()
    h = dt.hour
    if 5 <= h < 9:
        return "breakfast"
    if 9 <= h < 11:
        return "brunch"
    if 11 <= h < 14:
        return "lunch"
    if 14 <= h < 17:
        return "teatime"
    if 17 <= h < 21:
        return "dinner"
    return "latenight"


# ------------------------------------------------------------ 主流程
def do_init_profile(data_str):
    profile = get_profile()
    try:
        data = json.loads(data_str) if data_str else {}
    except json.JSONDecodeError as e:
        emit({"ok": False, "error": f"data 不是合法 JSON: {e}"})
        sys.exit(1)

    for k, v in data.items():
        if isinstance(v, dict) and isinstance(profile.get(k), dict):
            profile[k].update(v)
        else:
            profile[k] = v
    profile["updated_at"] = now_iso()
    if not profile.get("created_at"):
        profile["created_at"] = now_iso()
    put_profile(profile)
    emit({"ok": True, "profile": profile})


def do_checkin(args):
    ensure_dirs()
    profile = get_profile()
    badges = get_badges()

    ts = now_iso()
    slot = slot_of(ts)
    dishes = [d.strip() for d in (args.dishes or "").split(",") if d.strip()]

    rec = {
        "checkin_id": f"ck_{now().strftime('%Y%m%d%H%M%S')}",
        "timestamp": ts,
        "time_slot": slot,
        "month": now().strftime("%m"),
        "shop": {
            "name": args.name,
            "area": args.area,
            "cuisine": args.cuisine,
            "province_tag": args.province,
        },
        "rating": args.rating,
        "price": args.price,
        "dishes": dishes,
        "raw_note": args.note,
        "signals": extract_signals(args.note, dishes),
        "emotion": detect_emotion(args.note),
        "social": args.social,
        "source": args.source,
    }

    append_checkin(rec)
    checkins = read_checkins()

    # --- 更新统计 ---
    st = profile["stats"]
    st["total_checkins"] = len(checkins)
    st["total_spend"] = round(st.get("total_spend", 0.0) + (args.price or 0), 2)
    if args.area:
        st["areas"][args.area] = st["areas"].get(args.area, 0) + 1
    if args.cuisine:
        st["cuisines"][args.cuisine] = st["cuisines"].get(args.cuisine, 0) + 1
    if args.province:
        st["provinces"][args.province] = st["provinces"].get(args.province, 0) + 1
    if args.name:
        st["shops"][args.name] = st["shops"].get(args.name, 0) + 1
    st["by_time_slot"][slot] = st["by_time_slot"].get(slot, 0) + 1
    st["by_month"][rec["month"]] = st["by_month"].get(rec["month"], 0) + 1
    if args.social == "solo":
        st["by_time_slot"]["solo"] = st["by_time_slot"].get("solo", 0) + 1

    # 活跃周数
    weeks = {datetime.fromisoformat(c["timestamp"]).strftime("%Y-W%W")
             for c in checkins if c.get("timestamp")}
    st["weeks_active"] = len(weeks)

    # --- 口味信号融合 ---
    prev_taste = dict(profile.get("taste", {}))
    new_taste = dict(prev_taste)
    for dim, delta in rec["signals"].items():
        if dim in new_taste:
            observed = max(0.0, min(10.0, new_taste[dim] + delta * 3))
            new_taste[dim] = blend(new_taste[dim], observed, alpha=0.15)
    profile["taste"] = new_taste
    profile.setdefault("taste_history", []).append(
        {"date": ts, "taste": dict(new_taste), "source": "checkin",
         "shop": args.name})

    profile["last_checkin_at"] = ts
    profile["updated_at"] = ts

    # --- 徽章 ---
    new_badges = check_badges(profile, checkins, badges)

    # --- 心愿兑现（R2.5）：吃到了当初说的那句话 ---
    wish_done = None
    if getattr(args, "wish_done", None):
        item, days = done_wish(args.wish_done, shop=args.name)
        if item:
            line = (f"你 {days} 天前说的「{item['name']}」，今天兑现了。"
                    if days > 0 else f"你说的「{item['name']}」，今天兑现了。")
            b = unlock(badges, wish_badge_id(item), item["name"], "wish", line,
                       context=f"第 {st['total_checkins']} 家：{args.name}")
            if b:
                new_badges.append(b)
            wish_done = {"name": item["name"], "days_pending": days,
                         "note": item.get("note", ""), "line": line,
                         "badge_id": wish_badge_id(item),
                         "new_badge": bool(b)}
        else:
            wish_done = {"error": "no_open_wish", "query": args.wish_done}
    put_badges(badges)

    score = calc_score(profile, badges.get("unlocked", []))
    lvl, lvl_name = level_of(score)
    profile["stats"]["score"] = score
    profile["stats"]["level"] = lvl
    profile["stats"]["level_name"] = lvl_name
    put_profile(profile)

    # --- 漂移 ---
    drift = []
    for d in DIMS:
        o, n = prev_taste.get(d, 5.0), new_taste.get(d, 5.0)
        delta = round(n - o, 2)
        if abs(delta) >= 1.5:
            drift.append({"label": DIM_LABEL[d], "from": o, "to": n,
                          "delta": delta, "arrow": "↑" if delta > 0 else "↓"})

    emit({
        "ok": True,
        "checkin": rec,
        "new_badges": new_badges,
        "wish_done": wish_done,
        "level": {"level": lvl, "name": lvl_name, "score": score},
        "drift": drift,
        "next_milestone": next_milestone(st["total_checkins"]),
        "stats": {
            "total": st["total_checkins"],
            "spend": st["total_spend"],
            "areas_covered": len([a for a in st["areas"] if a in NJ_AREAS]),
            "provinces": len(st["provinces"]),
        },
    })


def do_badges():
    profile = get_profile()
    badges = get_badges()
    unlocked = badges.get("unlocked", [])
    score = calc_score(profile, unlocked)
    lvl, lvl_name = level_of(score)
    visible = [b for b in unlocked if not b.get("hidden")]
    hidden = [b for b in unlocked if b.get("hidden")]
    emit({
        "level": {"level": lvl, "name": lvl_name, "score": score},
        "total_badges": len(unlocked),
        "visible": visible,
        "hidden": hidden,
        "next_milestone": next_milestone(profile["stats"].get("total_checkins", 0)),
    })


def do_stats():
    profile = get_profile()
    st = profile["stats"]
    top_cuisines = sorted(st.get("cuisines", {}).items(),
                          key=lambda x: x[1], reverse=True)[:5]
    top_shops = sorted(st.get("shops", {}).items(),
                       key=lambda x: x[1], reverse=True)[:5]
    emit({
        "total": st.get("total_checkins", 0),
        "spend": st.get("total_spend", 0),
        "areas": st.get("areas", {}),
        "areas_covered": len([a for a in st.get("areas", {}) if a in NJ_AREAS]),
        "areas_total": len(NJ_AREAS),
        "provinces": st.get("provinces", {}),
        "top_cuisines": top_cuisines,
        "top_shops": top_shops,
        "weeks_active": st.get("weeks_active", 0),
    })


def do_days_since():
    profile = get_profile()
    last = profile.get("last_checkin_at")
    if not last:
        emit({"days": None, "should_ask": False})
        return
    try:
        d = (now() - datetime.fromisoformat(last)).days
    except Exception:
        d = None
    emit({"days": d, "last": last,
          "should_ask": bool(d is not None and d >= 5)})


def do_wish(args):
    """登记心愿（R2.5）：用户随口提的觅食需求。"""
    item, created = add_wish(args.wish, note=getattr(args, "wish_note", None))
    if item is None:
        emit({"ok": False, "error": "empty_wish"})
        return
    emit({
        "ok": True,
        "created": created,
        "duplicate": (not created),
        "wish": {"name": item.get("name"), "note": item.get("note", ""),
                 "seq": item.get("seq"), "created_at": item.get("created_at"),
                 "status": item.get("status")},
        "open_count": len(open_wishes()),
    })


def do_wish_list():
    """列出全部心愿，区分未兑现 / 已兑现。"""
    items = get_wishlist()["items"]
    emit({
        "total": len(items),
        "open": [{"name": i.get("name"), "note": i.get("note", ""),
                  "seq": i.get("seq"), "created_at": i.get("created_at")}
                 for i in items if i.get("status") == "open"],
        "done": [{"name": i.get("name"), "note": i.get("note", ""),
                  "done_at": i.get("done_at"), "shop": i.get("shop"),
                  "days_pending": i.get("days_pending", 0)}
                 for i in items if i.get("status") == "done"],
    })


def main():
    ap = argparse.ArgumentParser(description="打卡记录与徽章系统")
    ap.add_argument("--init-profile", action="store_true")
    ap.add_argument("--data", help="JSON 字符串")
    ap.add_argument("--name"); ap.add_argument("--area")
    ap.add_argument("--cuisine"); ap.add_argument("--province")
    ap.add_argument("--rating", type=int)
    ap.add_argument("--price", type=float)
    ap.add_argument("--dishes")
    ap.add_argument("--note")
    ap.add_argument("--source", default="text")
    ap.add_argument("--social", default=None,
                    choices=["solo", "friends", "date", "family"])
    ap.add_argument("--badges", action="store_true")
    ap.add_argument("--stats", action="store_true")
    ap.add_argument("--days-since", action="store_true")
    ap.add_argument("--wish", help="登记一个心愿（用户随口提的觅食需求）")
    ap.add_argument("--wish-note", help="心愿备注（当时为什么想）")
    ap.add_argument("--wish-list", action="store_true", help="列出全部心愿")
    ap.add_argument("--wish-done", help="兑现心愿，与 --name 打卡同时使用")
    args = ap.parse_args()

    if args.init_profile:
        do_init_profile(args.data)
    elif args.wish:
        do_wish(args)
    elif args.wish_list:
        do_wish_list()
    elif args.badges:
        do_badges()
    elif args.stats:
        do_stats()
    elif args.days_since:
        do_days_since()
    elif args.name:
        do_checkin(args)
    else:
        ap.error("需要 --init-profile / --name / --badges / --stats / "
                 "--days-since / --wish / --wish-list")


if __name__ == "__main__":
    main()
