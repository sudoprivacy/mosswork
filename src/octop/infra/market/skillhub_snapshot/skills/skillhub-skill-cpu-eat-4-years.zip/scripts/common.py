#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
common.py —— 共享数据层

数据根目录：~/.workbuddy/cpu-eats/
  profile.json    用户档案
  checkins.jsonl  打卡流水（append-only）
  badges.json     已解锁徽章
  wishlist.json   心愿清单
  cache/          餐厅缓存
  learning/       self-improvement-llm 数据
"""

import json
import os
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

CST = timezone(timedelta(hours=8))
DATA_DIR = Path.home() / ".workbuddy" / "cpu-eats"
CACHE_DIR = DATA_DIR / "cache"
LEARNING_DIR = DATA_DIR / "learning"

PROFILE_F = DATA_DIR / "profile.json"
CHECKINS_F = DATA_DIR / "checkins.jsonl"
BADGES_F = DATA_DIR / "badges.json"
WISHLIST_F = DATA_DIR / "wishlist.json"

TEMPLATE_F = Path(__file__).resolve().parent.parent / "data" / "user_profile_template.json"

# ---------------------------------------------------------------- 维度
DIMS = ["spicy", "numbing", "sweet_vs_savory", "richness",
        "adventure", "offal", "carb", "sour"]

DIM_LABEL = {
    "spicy": "辣度耐受",
    "numbing": "麻感接受",
    "sweet_vs_savory": "甜咸倾向",
    "richness": "油脂厚重",
    "adventure": "猎奇意愿",
    "offal": "特殊食材",
    "carb": "碳水态度",
    "sour": "酸度偏好",
}

# 维度两端的描述（用于生成画像卡文案）
DIM_ENDS = {
    "spicy":          ("一点辣都不要", "变态辣"),
    "numbing":        ("花椒挑出来", "麻到失去知觉"),
    "sweet_vs_savory":("纯咸党", "甜党"),
    "richness":       ("只吃清爽", "越油越香"),
    "adventure":      ("只吃熟悉的", "越怪越想试"),
    "offal":          ("内脏不碰", "内脏爱好者"),
    "carb":           ("严格控碳", "碳水即正义"),
    "sour":           ("不爱酸", "越酸越好"),
}

# 20 题 → 维度映射与选项分值
# 格式: "Qn": (维度, {"A":分值, "B":分值, ...})
QUESTIONS = {
    "Q1":  ("spicy",           {"A": 0, "B": 3, "C": 6, "D": 9}),
    "Q2":  ("numbing",         {"A": 10, "B": 6, "C": 2}),
    "Q3":  ("sweet_vs_savory", {"A": 0, "B": 3, "C": 7, "D": 10}),
    "Q4":  ("richness",        {"A": 10, "B": 4, "C": 1}),
    "Q5":  ("adventure",       {"A": 10, "B": 6, "C": 2}),
    "Q6":  ("offal",           {"A": 10, "B": 6, "C": 1}),   # 同时计入 adventure×0.5
    "Q7":  ("carb",            {"A": 10, "B": 5, "C": 1}),
    "Q8":  ("sour",            {"A": 9, "B": 5, "C": 1}),
    "Q9":  ("spicy",           {"A": 1, "B": 5, "C": 8, "D": 10}),
    "Q10": ("numbing",         {"A": 9, "B": 5, "C": 1}),
    "Q11": ("sweet_vs_savory", {"A": 1, "B": 6, "C": 10}),
    "Q12": ("richness",        {"A": 10, "B": 2, "C": 6}),
    "Q13": ("adventure",       {"A": 9, "B": 5, "C": 1}),
    "Q14": ("offal",           {"A": 10, "B": 5, "C": 0}),
    "Q15": ("carb",            {"A": 10, "B": 6, "C": 2}),
    "Q16": ("sour",            {"A": 9, "B": 5, "C": 1}),
    "Q17": ("adventure",       {"A": 9, "B": 4, "C": 1}),
    "Q19": ("solo_dining",     {"A": 10, "B": 5, "C": 1}),
    "Q20": ("loyalty",         {"A": 10, "B": 6, "C": 3}),
    # Q18 是行为题（预算风格），不计入雷达图，单独存
}

# ---------------------------------------------------------------- 南京 11 区
NJ_AREAS = ["玄武区", "鼓楼区", "建邺区", "秦淮区", "雨花台区", "栖霞区",
            "浦口区", "六合区", "江宁区", "溧水区", "高淳区"]


# ---------------------------------------------------------------- 基础 IO
def ensure_dirs():
    for d in (DATA_DIR, CACHE_DIR, LEARNING_DIR):
        d.mkdir(parents=True, exist_ok=True)


def now():
    return datetime.now(CST)


def now_iso():
    return now().isoformat(timespec="seconds")


def load_json(path, default):
    p = Path(path)
    if not p.exists():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def new_profile():
    if TEMPLATE_F.exists():
        return json.loads(TEMPLATE_F.read_text(encoding="utf-8"))
    return {
        "created_at": now_iso(),
        "onboarding_round": 0,
        "nickname": None,
        "grade": 1,
        "campus": "jiangning",
        "mode": "guided",
        "hometown": {"province": None, "city": None},
        "rhythm": {"days_per_week": 1, "meals_per_day": 2,
                   "meals": ["lunch", "dinner"]},
        "taste": {d: 5.0 for d in DIMS},
        "taste_history": [],
        "constraints": {
            "allergies": [], "religious": None, "never_eat": [],
            "budget_monthly": 600, "budget_per_meal": 50,
            "appetite": "normal", "max_queue": 15,
        },
        "stats": {"total_checkins": 0, "total_spend": 0.0,
                  "areas": {}, "cuisines": {}, "provinces": {},
                  "shops": {}},
        "year_path": [],
        "current_year": 1,
        "last_closing": None,
        "last_checkin_at": None,
        "declined_checkin": False,
    }


def get_profile():
    return load_json(PROFILE_F, new_profile())


def profile_exists():
    """档案是否真的落盘。get_profile() 只读不落盘，靠它判断用户是否完成过 R0 建档。"""
    return PROFILE_F.is_file()


def require_profile(action="执行本操作"):
    """行程与资料库导出前调用：未建档就报错退出，避免用空模板档案静默执行。

    这是流程保护，不是功能缺陷——首次激活流程（R0/onboarding）必须先跑完。
    """
    if profile_exists():
        return
    emit({
        "ok": False,
        "error": "profile_missing",
        "detail": f"{action}前需要先建立用户档案，当前 {PROFILE_F} 不存在。",
        "how_to_fix": (
            "请先执行首次激活流程（SKILL.md §3 / references/09-onboarding-script.md）："
            "收集家乡、年级、校区并完成口味量表，再运行 "
            "python3 scripts/checkin.py --init-profile 建档。"
        ),
        "profile_path": str(PROFILE_F),
    })
    sys.exit(2)


def put_profile(p):
    save_json(PROFILE_F, p)


def read_checkins():
    if not CHECKINS_F.exists():
        return []
    out = []
    for line in CHECKINS_F.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except Exception:
            continue
    return out


def append_checkin(rec):
    ensure_dirs()
    with open(CHECKINS_F, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


# ---------------------------------------------------------------- 心愿徽章
def get_wishlist():
    """返回 {"items":[...]}。兼容旧格式（元素是纯字符串）。"""
    w = load_json(WISHLIST_F, {"items": []})
    if not isinstance(w, dict):
        w = {"items": []}
    items = w.get("items") or []
    norm = []
    for i, it in enumerate(items):
        if isinstance(it, dict):
            norm.append(it)
        elif isinstance(it, str):
            norm.append({"name": it, "note": "", "status": "open",
                         "created_at": "", "seq": i + 1})
    w["items"] = norm
    return w


def _wish_seq(items):
    """下一个心愿序号（用于生成稳定的徽章 id）。"""
    used = 0
    for it in items:
        try:
            used = max(used, int(it.get("seq") or 0))
        except (TypeError, ValueError):
            continue
    return used + 1


def add_wish(text, note=None):
    """登记心愿。返回 (item, created)。已存在同名未兑现心愿时不重复登记。"""
    key = (text or "").strip()
    if not key:
        return None, False
    w = get_wishlist()
    items = w["items"]
    for it in items:
        if it.get("status") == "open" and (it.get("name") or "").strip() == key:
            return it, False
    item = {
        "name": key,
        "note": (note or "").strip(),
        "status": "open",
        "created_at": now_iso(),
        "seq": _wish_seq(items),
    }
    items.append(item)
    ensure_dirs()
    save_json(WISHLIST_F, w)
    return item, True


def _pending_days(item):
    try:
        created = datetime.fromisoformat(item.get("created_at") or "")
    except (ValueError, TypeError):
        return 0
    if created.tzinfo is None:
        created = created.replace(tzinfo=CST)
    return max(0, (now() - created).days)


def done_wish(text, shop=None):
    """兑现心愿（精确匹配优先，其次子串匹配）。返回 (item, pending_days)。"""
    key = (text or "").strip()
    if not key:
        return None, 0
    w = get_wishlist()
    items = w["items"]
    open_items = [it for it in items if it.get("status") == "open"]
    target = None
    for it in open_items:
        if (it.get("name") or "").strip() == key:
            target = it
            break
    if target is None:
        for it in open_items:
            if key in (it.get("name") or ""):
                target = it
                break
    if target is None:
        return None, 0
    days = _pending_days(target)
    target["status"] = "done"
    target["done_at"] = now_iso()
    target["shop"] = shop
    target["days_pending"] = days
    ensure_dirs()
    save_json(WISHLIST_F, w)
    return target, days


def wish_badge_id(item):
    """心愿徽章的稳定 id：wish_001 / wish_002 ..."""
    return "wish_%03d" % int(item.get("seq") or 0)


def open_wishes():
    return [it for it in get_wishlist()["items"] if it.get("status") == "open"]


# ---------------------------------------------------------------- 口味计算
def score_answers(answers):
    """answers: {"Q1":"C", ...} -> {dim: 0-10}"""
    acc = {d: [] for d in DIMS}
    acc["solo_dining"] = []
    acc["loyalty"] = []
    for q, chosen in answers.items():
        if q not in QUESTIONS:
            continue
        dim, opts = QUESTIONS[q]
        val = opts.get(str(chosen).upper().strip())
        if val is None:
            continue
        acc.setdefault(dim, []).append(val)
        # Q6 同时轻度计入 adventure
        if q == "Q6":
            acc["adventure"].append(val * 0.5)
    out = {}
    for d, vals in acc.items():
        out[d] = round(sum(vals) / len(vals), 1) if vals else 5.0
    return out


def blend(old, observed, alpha=0.15):
    """口味衰减融合：new = old*(1-alpha) + observed*alpha"""
    return round(old * (1 - alpha) + observed * alpha, 2)


def dim_text(dim, val):
    """生成某个维度的一句话描述"""
    low, high = DIM_ENDS[dim]
    if val <= 2.5:
        return f"明显偏向「{low}」"
    if val >= 7.5:
        return f"明显偏向「{high}」"
    return "中等，两头都能接受"


def bar(val, width=10):
    filled = int(round(val / 10 * width))
    return "█" * filled + "░" * (width - filled)


# ---------------------------------------------------------------- 徽章规则
# 每条: (id, name, category, tier, hidden, check_fn_description)
MILESTONES = [
    (1, "开张大吉"), (5, "初出茅庐"), (10, "小试牛刀"), (20, "有点上道"),
    (30, "熟门熟路"), (50, "半个南京人"), (70, "老南京了"), (100, "百店斩"),
    (130, "南京胃"), (160, "人间清醒"), (200, "毕业水平"), (250, "梧桐成荫"),
]

AREA_BADGES = {
    "江宁区": (30, "江宁土著", "龙眠大道被你吃透了。"),
    "秦淮区": (15, "秦淮风月", "夫子庙的灯，你看过很多次了吧。"),
    "鼓楼区": (15, "鼓楼常客", "鼓楼这片，你熟。"),
    "玄武区": (10, "玄武湖畔", "玄武门校区那一片，吃明白了。"),
    "建邺区": (10, "建邺新城", "新城也有好东西，对吧。"),
    "雨花台区": (8, "雨花寻味", "雨花台不止有烈士陵园。"),
    "栖霞区": (8, "栖霞秋色", "秋天去栖霞山看枫叶，顺手吃一顿。"),
}

AREA_UNLOCK_LINES = {
    "江宁土著": "龙眠大道被你吃透了。",
    "秦淮风月": "夫子庙的灯，你看过很多次了吧。",
    "鼓楼常客": "鼓楼这片，你熟。",
    "玄武湖畔": "玄武门校区那一片，吃明白了。",
    "建邺新城": "新城也有好东西，对吧。",
    "雨花寻味": "雨花台不止有烈士陵园。",
    "栖霞秋色": "秋天去栖霞山看枫叶，顺手吃一顿。",
    "过江！": "你过江了。江北不再是什么都没有。",
    "南京通": "南京十一个区，你一个没落下。这个不容易。",
}

LEVELS = [
    (0, "新生"), (300, "熟客"), (900, "老饕"),
    (2000, "半个南京人"), (4000, "南京通"), (7000, "梧桐"),
]


def calc_score(profile, badges):
    st = profile.get("stats", {})
    return int(
        st.get("total_checkins", 0) * 10
        + len(badges) * 15
        + st.get("weeks_active", 0) * 5
        + len([a for a in st.get("areas", {}) if a in NJ_AREAS]) * 20
        + len(st.get("provinces", {})) * 12
    )


def level_of(score):
    cur = LEVELS[0]
    for thr, name in LEVELS:
        if score >= thr:
            cur = (thr, name)
    idx = [n for _, n in LEVELS].index(cur[1])
    return idx + 1, cur[1]


def next_milestone(total):
    for n, name in MILESTONES:
        if total < n:
            return {"count": n, "name": name, "remaining": n - total}
    return None


# ---------------------------------------------------------------- 输出
def emit(obj):
    """统一以 JSON 输出到 stdout，便于 Agent 解析"""
    print(json.dumps(obj, ensure_ascii=False, indent=2))
