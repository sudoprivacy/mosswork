#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_profile_site.py —— 生成「在线资料库」单文件 HTML

纯静态、零外部依赖（雷达图与曲线均为手写 SVG），可直接双击打开或发布为在线链接。

用法：
  python3 build_profile_site.py --out ~/Desktop/我的南京吃饭档案.html
  python3 build_profile_site.py --out x.html --title "我的南京吃饭档案"
  python3 build_profile_site.py --stdout        # 打到标准输出（调试用）
"""

import argparse
import html
import math
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (  # noqa: E402
    DIMS, DIM_LABEL, NJ_AREAS, now,
    get_profile, read_checkins, load_json, calc_score, level_of,
    require_profile, emit,
)

TEMPLATE = Path(__file__).resolve().parent.parent / "assets" / "profile_template.html"
BADGES_F = Path.home() / ".workbuddy" / "cpu-eats" / "badges.json"
WISHLIST_F = Path.home() / ".workbuddy" / "cpu-eats" / "wishlist.json"
TOTAL_WEEKS = 148.5

BADGE_ICON = {
    "milestone": "🏁", "area": "🗺️", "cuisine": "🍜",
    "geo": "🚄", "easter": "✨", "wish": "🎀", "unknown": "🔖",
}
BADGE_GROUP = [
    ("milestone", "里程碑"),
    ("area", "地理"),
    ("cuisine", "菜系"),
    ("geo", "江浙沪皖"),
    ("easter", "彩蛋"),
    ("wish", "心愿"),
]


def esc(s):
    return html.escape(str(s if s is not None else ""), quote=True)


# ---------------------------------------------------------------- 雷达图
def radar_svg(taste, size=300, pad=48):
    cx = cy = size / 2
    R = size / 2 - pad
    n = len(DIMS)

    def pt(i, r):
        ang = math.radians(-90 + i * 360.0 / n)
        return cx + r * math.cos(ang), cy + r * math.sin(ang)

    parts = [f'<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" '
             f'xmlns="http://www.w3.org/2000/svg" role="img" '
             f'aria-label="口味雷达图">']

    # 网格
    for ring in (0.25, 0.5, 0.75, 1.0):
        pts = " ".join(f"{p[0]:.1f},{p[1]:.1f}" for p in
                       (pt(i, R * ring) for i in range(n)))
        stroke = "#cfe0d4" if ring < 1 else "#b3ccba"
        parts.append(f'<polygon points="{pts}" fill="none" stroke="{stroke}" '
                     f'stroke-width="1"/>')

    # 轴线 + 标签
    for i in range(n):
        x, y = pt(i, R)
        parts.append(f'<line x1="{cx}" y1="{cy}" x2="{x:.1f}" y2="{y:.1f}" '
                     f'stroke="#d5e3d9" stroke-width="1"/>')
        lx, ly = pt(i, R + 20)
        anchor = "middle"
        if lx > cx + 6:
            anchor = "start"
        elif lx < cx - 6:
            anchor = "end"
        parts.append(f'<text x="{lx:.1f}" y="{ly + 4:.1f}" text-anchor="{anchor}" '
                     f'font-size="11.5" fill="#5c6f66" '
                     f'font-family="-apple-system,PingFang SC,sans-serif">'
                     f'{esc(DIM_LABEL[DIMS[i]])}</text>')

    # 数据多边形
    dpts = []
    for i, d in enumerate(DIMS):
        v = max(0.0, min(10.0, float(taste.get(d, 5.0))))
        dpts.append(pt(i, R * v / 10.0))
    poly = " ".join(f"{p[0]:.1f},{p[1]:.1f}" for p in dpts)
    parts.append(f'<polygon points="{poly}" fill="rgba(111,174,127,.30)" '
                 f'stroke="#4d8a5f" stroke-width="2" stroke-linejoin="round"/>')
    for p in dpts:
        parts.append(f'<circle cx="{p[0]:.1f}" cy="{p[1]:.1f}" r="3.4" '
                     f'fill="#fff" stroke="#4d8a5f" stroke-width="2"/>')

    parts.append("</svg>")
    return "\n".join(parts)


def dim_bars(taste):
    out = []
    for d in DIMS:
        v = float(taste.get(d, 5.0))
        out.append(
            f'<div class="dim"><div class="nm">{esc(DIM_LABEL[d])}</div>'
            f'<div class="bar"><div class="fill" style="width:{v * 10:.0f}%"></div></div>'
            f'<div class="v">{v:.1f}</div></div>')
    return "\n".join(out)


# ---------------------------------------------------------------- 区块
def area_cards(stats):
    areas = stats.get("areas", {})
    out = []
    for a in NJ_AREAS:
        c = areas.get(a, 0)
        need = 30 if a == "江宁区" else 15 if a in ("秦淮区", "鼓楼区") else 10
        pct = min(100, c / need * 100)
        done = " done" if c > 0 else ""
        out.append(
            f'<div class="area{done}"><div class="an">{esc(a)}'
            f'<span>{c} 家</span></div>'
            f'<div class="pb"><div class="pf" style="width:{pct:.0f}%"></div></div></div>')
    return "\n".join(out)


def badge_wall(badges):
    unlocked = badges.get("unlocked", [])
    if not unlocked:
        return ('<div class="empty">还没有徽章。'
                '去吃第一顿吧——「开张大吉」在等你。</div>')
    groups = []
    for key, label in BADGE_GROUP:
        items = [b for b in unlocked if b.get("category") == key]
        if not items:
            continue
        chips = []
        for b in items:
            cls = "badge"
            if b.get("hidden"):
                cls += " hidden"
            elif b.get("name") in ("百店斩", "梧桐成荫", "南京通", "全国胃", "长三角通"):
                cls += " gold"
            ic = BADGE_ICON.get(key, "🔖")
            chips.append(f'<div class="{cls}"><span class="ic">{ic}</span>'
                         f'<div>{esc(b.get("name"))}'
                         f'<span class="dt">{esc((b.get("unlocked_at") or "")[:10])}</span>'
                         f'</div></div>')
        groups.append(f'<div class="bgroup"><div class="bt">{label} · {len(items)}</div>'
                      f'<div class="badges">{"".join(chips)}</div></div>')
    return "\n".join(groups)


def timeline(checkins, limit=12):
    if not checkins:
        return '<div class="empty">还没有记录。吃完第一家，回来告诉我一声。</div>'
    out = []
    for c in list(reversed(checkins))[:limit]:
        ts = c.get("timestamp", "")
        try:
            d = datetime.fromisoformat(ts).strftime("%Y.%m.%d")
        except Exception:
            d = ts[:10]
        shop = c.get("shop", {})
        name = shop.get("name", "未知")
        area = shop.get("area") or ""
        cuisine = shop.get("cuisine") or ""
        stars = "★" * int(c.get("rating") or 0)
        meta = " · ".join(x for x in [area, cuisine] if x)
        if c.get("price"):
            meta += f" · ¥{c['price']}"
        note = c.get("raw_note")
        note_html = (f'<div class="tl-note">{esc(note)}</div>'
                     if note else "")
        out.append(
            f'<div class="tl-item"><div class="tl-d">{esc(d)}</div>'
            f'<div class="tl-n">{esc(name)}<span class="stars">{stars}</span></div>'
            f'<div class="tl-m">{esc(meta)}</div>{note_html}</div>')
    return "\n".join(out)


def drift_section(profile):
    hist = profile.get("taste_history", [])
    if len(hist) < 2:
        return ""
    first, last = hist[0], hist[-1]
    rows = []
    for d in DIMS:
        a = float(first.get("taste", {}).get(d, 5.0))
        b = float(last.get("taste", {}).get(d, 5.0))
        delta = round(b - a, 1)
        if abs(delta) < 1.5:
            continue
        cls = "up" if delta > 0 else "down"
        arrow = "↑" if delta > 0 else "↓"
        rows.append(
            f'<div class="drift-row"><div class="dl">{esc(DIM_LABEL[d])}</div>'
            f'<div class="dv">{a:.1f} → {b:.1f}</div>'
            f'<div class="{cls}">{arrow}{abs(delta):.1f}</div></div>')
    if not rows:
        return ""
    return ('<div class="card"><h2>口味变化</h2>'
            f'{"".join(rows)}</div>')


def wishlist_block():
    w = load_json(WISHLIST_F, {"items": []})
    items = w.get("items", [])
    if not items:
        return ('<div class="empty">还没有心愿。'
                '想吃什么就告诉我，我给你记着。</div>')
    chips = []
    for i in items:
        if isinstance(i, dict):
            name = i.get("name") or ""
            done = i.get("status") == "done"
        else:
            name, done = str(i), False
        if done:
            days = i.get("days_pending") or 0
            shop = i.get("shop") or ""
            sub = "已达成" + (f" · {shop}" if shop else "")
            if days:
                sub += f" · 挂了 {days} 天"
            chips.append(f'<div class="wl-item wl-done"><span>{esc(name)}</span>'
                         f'<span class="wl-sub">{esc(sub)}</span></div>')
        else:
            chips.append(f'<div class="wl-item">{esc(name)}</div>')
    return "".join(chips)


GREETINGS = [
    "这是你的南京。从第 {first} 开始，到第 {total} 家。",
    "一共 {total} 家。每一家我都记着。",
    "{total} 顿了。南京的味道，你应该摸到一点门道了。",
]


def greeting_of(profile, checkins, total):
    if total == 0:
        return "档案已建好。<b>第一顿还没开始。</b>要不要现在就排一个？"
    first = checkins[0].get("shop", {}).get("name", "某家店") if checkins else "某家店"
    return GREETINGS[total % len(GREETINGS)].format(first=esc(first), total=total)


# ---------------------------------------------------------------- 主流程
def build(title):
    profile = get_profile()
    checkins = read_checkins()
    badges = load_json(BADGES_F, {"unlocked": []})
    st = profile.get("stats", {})
    taste = profile.get("taste", {})

    total = st.get("total_checkins", 0) or len(checkins)
    weeks = st.get("weeks_active", 0)
    score = calc_score(profile, badges.get("unlocked", []))
    lvl, lvl_name = level_of(score)

    try:
        import taste_scoring
        ol = taste_scoring.one_liner(taste)
    except Exception:
        ol = ""

    tpl = TEMPLATE.read_text(encoding="utf-8")
    mapping = {
        "{{page_title}}": title,
        "{{greeting}}": greeting_of(profile, checkins, total),
        "{{total}}": str(total),
        "{{badge_count}}": str(len(badges.get("unlocked", []))),
        "{{level}}": str(lvl),
        "{{level_name}}": lvl_name,
        "{{areas_covered}}": str(len([a for a in st.get("areas", {}) if a in NJ_AREAS])),
        "{{provinces}}": str(len(st.get("provinces", {}))),
        "{{spend}}": f'{st.get("total_spend", 0):.0f}',
        "{{weeks_active}}": str(weeks),
        "{{weeks_total}}": str(round(TOTAL_WEEKS)),
        "{{progress_pct}}": f"{min(100, weeks / TOTAL_WEEKS * 100):.1f}",
        "{{radar_svg}}": radar_svg(taste),
        "{{dim_bars}}": dim_bars(taste),
        "{{one_liner}}": esc(ol),
        "{{drift_section}}": drift_section(profile),
        "{{area_cards}}": area_cards(st),
        "{{badge_wall}}": badge_wall(badges),
        "{{timeline}}": timeline(checkins),
        "{{wishlist}}": wishlist_block(),
        "{{generated_at}}": now().strftime("%Y.%m.%d %H:%M"),
    }
    for k, v in mapping.items():
        tpl = tpl.replace(k, v)
    return tpl


def main():
    ap = argparse.ArgumentParser(description="生成在线资料库 HTML")
    ap.add_argument("--out", help="输出路径，如 ~/Desktop/我的南京吃饭档案.html")
    ap.add_argument("--title", default="我的南京吃饭档案")
    ap.add_argument("--stdout", action="store_true", help="输出到标准输出")
    args = ap.parse_args()

    require_profile("导出资料库")
    if not TEMPLATE.is_file():
        emit({
            "ok": False,
            "error": "template_missing",
            "detail": f"资料库模板不存在：{TEMPLATE}",
            "how_to_fix": "从 Skill 发布包恢复 assets/profile_template.html 后重试。",
        })
        sys.exit(2)

    page = build(args.title)

    if args.stdout:
        sys.stdout.write(page)
        return
    if not args.out:
        ap.error("需要 --out 或 --stdout")

    out = Path(args.out).expanduser()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(page, encoding="utf-8")
    print(str(out.resolve()))


if __name__ == "__main__":
    main()
