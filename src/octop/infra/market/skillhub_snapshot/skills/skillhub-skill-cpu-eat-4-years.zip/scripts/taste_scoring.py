#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
taste_scoring.py —— 口味量表打分与画像渲染

用法：
  # 1) 计算 20 题得分
  python3 taste_scoring.py --answers '{"Q1":"C","Q2":"A",...}'

  # 2) 查看当前档案中的口味向量
  python3 taste_scoring.py --show

  # 3) 渲染文本画像卡
  python3 taste_scoring.py --render

  # 4) 把打分结果写入档案（首次建档用）
  python3 taste_scoring.py --answers '{...}' --write
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (  # noqa: E402
    DIMS, DIM_LABEL, DIM_ENDS, bar, dim_text,
    score_answers, get_profile, put_profile, now_iso, emit,
)


def render_card(taste, title="你的口味画像"):
    lines = []
    lines.append(f"🌳 {title}")
    lines.append("")
    for d in DIMS:
        v = taste.get(d, 5.0)
        label = DIM_LABEL[d]
        pad = "　" * (6 - len(label))
        lines.append(f"  {label}{pad} {bar(v)}  {v:>4.1f}   {dim_text(d, v)}")
    return "\n".join(lines)


def extremes(taste):
    """挑出最接近两端的维度作为「边界」。
    中等区间（3.5-6.5）的维度不算边界——那不是边界，是兼容性好。"""
    items = sorted(((d, taste.get(d, 5.0)) for d in DIMS), key=lambda x: x[1])
    low = items[0]
    high = items[-1]
    return low, high


def one_liner(taste):
    low, high = extremes(taste)
    low_txt = DIM_ENDS[low[0]][0]
    high_txt = DIM_ENDS[high[0]][1]
    t = taste
    traits = []
    if t.get("spicy", 5) >= 7:
        traits.append("敢吃辣")
    if t.get("carb", 5) >= 7:
        traits.append("爱碳水")
    if t.get("adventure", 5) >= 7:
        traits.append("愿意猎奇")
    if t.get("offal", 5) >= 7:
        traits.append("内脏也没问题")
    if t.get("sweet_vs_savory", 5) >= 7:
        traits.append("甜党")
    elif t.get("sweet_vs_savory", 5) <= 3:
        traits.append("坚定的咸党")
    if t.get("numbing", 5) >= 7:
        traits.append("麻得越狠越好")
    if not traits:
        traits.append("口味挺中和的")

    head = "你是个" + "、".join(traits) + "的人。"

    # 边界：只有真正贴边的维度才算
    edges = []
    if low[1] <= 3.5:
        edges.append(f"{DIM_LABEL[low[0]]}偏低（{low_txt}）")
    if high[1] >= 6.5:
        edges.append(f"{DIM_LABEL[high[0]]}偏高（{high_txt}）")
    if edges:
        return head + "、".join(edges) + "是你的边界，我会绕着走。"
    return head + "没什么明显的边界，什么都能给你安排。"


def main():
    ap = argparse.ArgumentParser(description="口味量表打分与画像渲染")
    ap.add_argument("--answers", help='JSON 字符串，如 \'{"Q1":"C","Q2":"A"}\'')
    ap.add_argument("--write", action="store_true", help="把结果写入 profile.json")
    ap.add_argument("--show", action="store_true", help="打印当前档案口味向量")
    ap.add_argument("--render", action="store_true", help="渲染文本画像卡")
    args = ap.parse_args()

    if args.show or args.render:
        p = get_profile()
        t = p.get("taste", {})
        if args.show:
            emit({"taste": t, "updated_at": p.get("updated_at")})
        else:
            print(render_card(t))
            print()
            print("── 一句话 ──")
            print(one_liner(t))
        return

    if not args.answers:
        ap.error("需要 --answers，或用 --show / --render")

    try:
        answers = json.loads(args.answers)
    except json.JSONDecodeError as e:
        emit({"ok": False, "error": f"answers 不是合法 JSON: {e}"})
        sys.exit(1)

    scored = score_answers(answers)
    result = {
        "ok": True,
        "taste": scored,
        "card": render_card(scored, "你的口味画像 · 第 1 次测定"),
        "one_liner": one_liner(scored),
    }

    # Q18 单独记录（预算风格，非维度）
    if "Q18" in answers:
        result["budget_style"] = {"A": "quality", "B": "quantity",
                                  "C": "save_up"}.get(
            str(answers["Q18"]).upper(), "quality")

    if args.write:
        p = get_profile()
        prev = dict(p.get("taste", {}))
        is_first = len(p.get("taste_history", [])) == 0
        p["taste"].update(scored) if "taste" in p else p.update({"taste": scored})
        p.setdefault("taste_history", []).append(
            {"date": now_iso(), "taste": dict(scored), "source": "onboarding"})
        p["updated_at"] = now_iso()
        if "budget_style" in result:
            p["rhythm"]["budget_style"] = result["budget_style"]
        put_profile(p)
        result["written"] = True
        # 首次建档时 prev 是默认值 5.0，不算漂移
        result["drift"] = [] if is_first else drift_report(prev, p["taste"])

    emit(result)


def drift_report(old, new, threshold=1.5):
    rows = []
    for d in DIMS:
        o = old.get(d, 5.0)
        n = new.get(d, 5.0)
        delta = round(n - o, 2)
        if abs(delta) >= threshold:
            rows.append({"dim": d, "label": DIM_LABEL[d],
                         "from": o, "to": n, "delta": delta,
                         "arrow": "↑" if delta > 0 else "↓"})
    return rows


if __name__ == "__main__":
    main()
