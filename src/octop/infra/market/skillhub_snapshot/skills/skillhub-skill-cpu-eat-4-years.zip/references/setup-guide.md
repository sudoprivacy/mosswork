# 环境配置指南

本 Skill 是依赖型 Skill。进入正常功能前，先运行环境检查：

```bash
python3 scripts/check_environment.py --capability onboarding
```

可重复传入 `--capability`，只检查本次请求涉及的依赖。加上 `--network` 会执行清单里的匿名只读 HTTPS 健康探测。

检查结果四种状态：

| 状态 | 含义 | 下一步 |
|---|---|---|
| ready | 所需依赖全部可用 | 直接进入正常流程，不显示任何安装引导 |
| partial | 核心可用，部分可选功能不可用 | 正常执行，在结果中标注降级范围 |
| needs_setup | 必需依赖缺失 | 只展示缺失项的配置步骤，配置后重新检查 |
| unavailable | 服务故障、登录失效或版本不兼容 | 展示原因、恢复步骤和降级方案 |

已经通过的项目不重复引导。

---

## 1. python-runtime（必需）

**用途**：运行全部 6 个脚本（建档、打卡、徽章、行程、口味打分、资料库导出）。
**受影响功能**：onboarding、itinerary、restaurant-sourcing、checkin、badge、taste-drift、profile-site。

**版本要求**：Python **3.9 及以上**。实测 macOS 系统自带的 `/usr/bin/python3`（3.9.6）可运行全部脚本，退出码 0。
**关键事实**：所有脚本仅使用 Python 标准库，**不需要 pip 安装任何第三方包，也不需要创建虚拟环境**。

**官方地址**
- 主页：https://www.python.org
- 文档：https://docs.python.org/3/
- 下载：https://www.python.org/downloads/

**安装步骤**
1. `python3 --version` 查看当前版本。
2. 低于 3.9 时前往官方下载页安装。
3. macOS 可直接用系统自带的 `/usr/bin/python3`。
4. 需要第三方包时用 `python3 -m venv ~/.venvs/cpu-eats` 建隔离环境，本 Skill 核心流程不依赖它。

**验证**

```bash
python3 --version
python3 scripts/itinerary.py --plan
```

第二条应正常打印四年容量规划且退出码为 0。

**降级**：Python 不可用时，建档改为对话式口头提问、行程改为人工编排、资料库改为 Markdown 摘要，所有结果标注「未验证」并明确告知数据未落盘。详见 `skill-dependencies.json` 中 `python-runtime` 的 degradation 段。

**撤销**：卸载 Python 即完全停用本 Skill 的脚本能力；无需清理凭据。

---

## 2. local-data-write（必需）

**用途**：把用户档案、打卡流水、徽章写入 `~/.workbuddy/cpu-eats/`，并导出资料库 HTML。
**受影响功能**：onboarding、checkin、badge、profile-site。

**存储位置**

```
~/.workbuddy/cpu-eats/
├── profile.json      用户档案（家乡、年级、校区、口味向量、忌口）
├── checkins.jsonl    打卡流水（append-only）
├── badges.json       已解锁徽章
├── wishlist.json     想吃的店
└── cache/            餐厅核实缓存
```

数据独立于 Skill 目录存放，升级 Skill 不会丢失。

**官方文档**
- 路径操作：https://docs.python.org/3/library/pathlib.html
- 文件与权限：https://docs.python.org/3/library/os.html

**权限配置**
1. 首次运行 `python3 scripts/checkin.py --init-profile` 会自动创建目录。
2. 报 `Permission denied` 时，确认 `~/.workbuddy` 的所有者为当前用户。
3. 导出资料库时另需对 `--out` 指定的目标目录有写权限。

**验证**

```bash
python3 scripts/checkin.py \
  --name "权限自检" --area "鼓楼区" --cuisine "南京小吃" \
  --rating 4 --price 30 --note "权限自检" --source self
```

成功时 `~/.workbuddy/cpu-eats/checkins.jsonl` 会新增一行。

**安全与撤销**
- 数据仅存本机，不上传任何服务。
- 档案含家乡、忌口等个人信息，导出 HTML 前先确认保存位置。
- 彻底清除：`rm -rf ~/.workbuddy/cpu-eats/`（这会删除全部打卡与徽章记录，不可恢复）。

**降级**：不可写时改为对话内记录，每轮结尾提醒数据未持久化；连续三次写入失败转为纯对话模式并说明原因。

---

## 3. agent-browser-cli（可选）

**用途**：L1 降级链中抓取大众点评、小红书的真实店铺数据。
**受影响功能**：restaurant-sourcing（仅此一项，其余功能不受影响）。

**前置条件**：Node.js 18 及以上、npm 在 PATH 中、约 500 MB 磁盘空间用于 Chromium。

**官方地址**
- 仓库与文档：https://github.com/vercel-labs/agent-browser
- 发布页：https://github.com/vercel-labs/agent-browser/releases

**安装步骤**
1. 宿主若已内置 agent-browser Skill，首次加载时自动安装，一般无需手动操作。
2. 手动安装按上游仓库 README 执行，装完用 `agent-browser --version` 验证。
3. **Chromium 下载超时时**（实测 2026-09-02 遇到过），用 `--executable-path` 指向本机已装的 Chrome 跳过下载：

```bash
agent-browser --executable-path \
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  open "https://www.dianping.com"
```

**验证**：`agent-browser --version` 输出版本号；`agent-browser open <url>` 返回 JSON。

**安全与清理**
- 仅读取公开页面信息，不提交表单、不下单、不输入账号密码。
- 用完后 `agent-browser close --all` 关闭，不保留常驻进程。
- 卸载：按上游仓库说明移除 CLI 与 Chromium 缓存目录。

**降级**：不可用时跳过 L1 实抓，进入 L4 内置知识库加公开搜索，所有店铺标注「未经现场核实」。

---

## 4. dianping-account（可选）

**用途**：登录大众点评后抓取实时评分、人均、地址。
**受影响功能**：restaurant-sourcing。

**官方地址**
- 主页：https://www.dianping.com
- 登录页：https://account.dianping.com/pclogin

**登录步骤**
1. 用 agent-browser 打开 https://www.dianping.com 。
2. 触发任意需登录的页面（如搜索），会自动跳转至 https://account.dianping.com/pclogin 。
3. 截图页面上的二维码给用户，请其用**手机大众点评 App 扫码**完成登录。
4. 登录后在同一浏览器 profile 内保持会话，不要清除 Cookie。

**验证**：重新打开 `https://www.dianping.com/search/keyword/5/0_<品类>`，不再跳转 pclogin 且能返回店铺列表。

**凭据存储**：浏览器 Cookie，由 agent-browser 复用的浏览器 profile 保存。本 Skill 不读取、不导出、不上传任何 Cookie 内容，也不接触密码或短信验证码。

**登录失效处理**：跳转回 pclogin 或出现滑块验证即视为失效，重新走扫码流程；连续失效时降级到 L2 或 L4。

**退出与撤销**
- App 端：「我的 → 设置 → 退出登录」。
- 浏览器端：清除 `www.dianping.com` 域下的 Cookie。

**降级**：未登录时降级到小红书；两者都不可用则降级到 L4，结果置信度从 high 降为 medium 或 low 并写明核实日期。

---

## 5. xiaohongshu-account（可选）

**用途**：作为第二数据源做餐厅口碑交叉验证。
**受影响功能**：restaurant-sourcing。

**官方地址**
- 主页与登录入口：https://www.xiaohongshu.com

**登录步骤**
1. 用 agent-browser 打开 https://www.xiaohongshu.com 的搜索页。
2. 笔记列表为空或弹出登录框即表示未登录。
3. 请用户用手机小红书 App 扫码或短信验证登录。
4. 登录后在同一浏览器 profile 内保持会话。

**验证**：搜索结果页能看到笔记标题与正文，而非空白列表。

**凭据存储**：浏览器 Cookie，本 Skill 不读取、不导出、不上传，也不接触密码或验证码。仅读取公开笔记，不点赞、不收藏、不评论、不发帖。

**退出与撤销**
- App 端：「我 → 设置 → 退出登录」。
- 浏览器端：清除 `www.xiaohongshu.com` 域下的 Cookie。

**降级**：小红书仅为可选交叉源，不可用时不影响主流程，双源交叉退化为单源并如实标注。

---

## 6. public-network（可选）

**用途**：匿名只读探测数据源可达性。
**受影响功能**：restaurant-sourcing。

**探测目标**
- https://www.dianping.com
- https://www.xiaohongshu.com

**配置**：无需配置，设备能访问公网即可。

**验证**

```bash
python3 scripts/check_environment.py --capability restaurant-sourcing --network
```

`dianping-reachable` 返回 ready 即通过。探测为匿名只读 HEAD 请求，不携带任何凭据或个人信息。

**降级**：离线时核心功能（建档、打卡、徽章、行程、资料库导出）全部照常可用，仅餐厅实时核实不可用；此时不给任何具体的评分、人均、营业时间数字，只给品类方向与检索式。

---

## 7. meituan-living-expert（可选）

WorkBuddy 的「领券下单找我」（meituan-living-assistant）专家，可作为 L3 数据源补充团购信息。

- 官网：<https://www.meituan.com>
- 服务规则：<https://rules-center.meituan.com/rule-detail/4/1>

**安装**：在 WorkBuddy 的**专家中心**搜索「领券下单找我」并加载。本 Skill **不提供直链下载**——专家由宿主动态装载，其入口脚本由宿主管理，不同宿主版本路径可能不同。

**为什么不做硬路径校验**：2026-09-03 实测到其入口位于
`~/.workbuddy/plugins/marketplaces/experts/plugins/meituan-living-assistant/scripts/run.js`，
但这是宿主缓存目录，**升级后可能变化**。清单中的 `file` 检查按此路径探测，
未命中不代表未安装——以专家中心能否加载为准。

**登录**：首次调用其能力时，若未登录会返回美团扫码登录链接，用手机美团 App 扫码即可。
登录态由专家自身持有，本 Skill 不接触密码、验证码或 token。

> ⚠️ **团购价 ≠ 堂食人均**。该专家返回的是团购套餐价与到店套餐内容，
> **不等于**这家人均多少。引用时必须区分，不得把团购价直接写进档案或当人均推荐。
> 需要人均时，走 L1 大众点评或 L2 小红书另行核实。

**降级**：未安装或未登录时跳过 L3，优先用 L1（若已登录大众点评），
否则走 L4 内置知识库，结果标注来源与核实日期。

---

## 8. dianping-skill（可选）

`openclaw-dianping` Skill，用于读取大众点评的评分、人均、地址。

- 官网：<https://www.dianping.com>
- 登录页：<https://account.dianping.com/pclogin>

**安装**：在 WorkBuddy 的 **Skill 市场**搜索 openclaw-dianping 并安装。
安装后目录名可能带来源后缀（实测为 `openclaw-dianping__skillhub`），
若你以其他方式安装导致清单中的 `file` 检查未命中，忽略该检查即可，不影响使用。

**登录**：与 §4 dianping-account 共用同一份浏览器 Cookie，无需重复登录。

**实测要点**：大众点评搜索页与排行榜页常返回 302 或直接跳验证中心；
未登录时拿不到店铺列表，此时按降级链处理。

**降级**：降级到 L3 美团团购或 L2 小红书；全部不可用时走 L4，
结果标注「未验证」，不给评分与人均数字。

---

## 9. xhs-crosscheck-skill（可选）

`restaurant-crosscheck` Skill，用于小红书 × 大众点评双源交叉验证。

- 参考：<https://www.xiaohongshu.com>

**安装**：在 WorkBuddy 的 **Skill 市场**搜索 restaurant-crosscheck 并安装
（实测目录名 `restaurant-crosscheck__skillhub`）。该 Skill 自身不维护登录态，
复用小红书与大众点评的浏览器 Cookie。

> ⚠️ **可能会输出 mock 数据。** 2026-09-02 实测发现，其简化脚本会按公式生成
> 结构完整但内容非真实抓取的结果（店名、评分均为占位）。用它做交叉验证时，
> **必须人工核对**返回内容：如果多家店的评分呈现规律分布、或店名与已知店铺不符，
> 即为 mock，不得写入 `data/y1_shops.json`，也不得包装成真实评分呈现给用户。

**降级**：不做双源交叉，改用单源结果并明确标注「单源」，置信度上限压到 medium。

---

## 核实记录

| 项 | 值 |
|---|---|
| 核实日期 | 2026-09-03 |
| 适用版本 | 1.4.0 |
| 实测环境 | macOS + 系统 Python 3.9.6 + Node.js 22.22.2 + 本机 Google Chrome |
| 实测结论 | 6 个脚本在零第三方依赖下全部跑通，退出码 0；资料库 HTML 零占位符残留、无外链依赖 |
| 本版新增 | meituan-living-expert、dianping-skill、xhs-crosscheck-skill 三条数据源依赖已完成安装检测（file 检查命中本机已装路径）；其中美团专家入口为 2026-09-03 实测，宿主升级后路径可能变化 |

**待核验项**：大众点评与小红书的页面结构可能随时调整，抓取失败时以实际页面为准，不沿用本文描述的旧路径。
