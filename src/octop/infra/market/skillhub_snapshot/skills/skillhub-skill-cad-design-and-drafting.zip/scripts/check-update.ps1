[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$skillVersion = '1.3.88'
$skillPackage = '@org-qu1qhx78/cad-design-and-drafting'
$updateApi = 'https://api.skillhub.cn/api/v1/skills/cad-design-and-drafting?namespace=org-qu1qhx78'
$updatePage = 'https://skillhub.cn/team-skills/cad-design-and-drafting'
$maximumResponseBytes = 262144

function Convert-SemVer {
    param([string]$Value)
    if ($Value -cnotmatch '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$') {
        throw "Invalid semantic version '$Value'."
    }
    return @([int64]$Matches[1], [int64]$Matches[2], [int64]$Matches[3])
}

function Compare-SemVer {
    param([string]$Left, [string]$Right)
    $leftParts = @(Convert-SemVer $Left)
    $rightParts = @(Convert-SemVer $Right)
    for ($index = 0; $index -lt 3; $index += 1) {
        if ($leftParts[$index] -lt $rightParts[$index]) { return -1 }
        if ($leftParts[$index] -gt $rightParts[$index]) { return 1 }
    }
    return 0
}

function Write-UpdateResult {
    param([string]$Status, [object]$Update)
    [ordered]@{
        skillVersion = $skillVersion
        status = $Status
        update = $Update
        localPackage = $script:localPackage
    } | ConvertTo-Json -Depth 5 -Compress
}

function Invoke-CadSkillUpdateCheck {
    # Local corruption must not be reported as a temporary network failure.
    try {
        . (Join-Path $PSScriptRoot 'verify-skill.ps1')
        $script:localPackage = Get-CadSkillPackage -ExpectedVersion $skillVersion
    } catch {
        $script:localPackage = $null
        Write-UpdateResult 'repair-required' ([ordered]@{
            package = $skillPackage
            page = $updatePage
            error = [ordered]@{ code = 'skill-package-invalid'; message = $_.Exception.Message }
        })
        return
    }
    $savedProtocol = [Net.ServicePointManager]::SecurityProtocol
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $response = Invoke-WebRequest -UseBasicParsing -Method Get -Uri $updateApi `
            -Headers @{ Accept = 'application/json' } -MaximumRedirection 2 -TimeoutSec 10
        $responseUriProperty = $response.BaseResponse.PSObject.Properties['ResponseUri']
        $requestMessageProperty = $response.BaseResponse.PSObject.Properties['RequestMessage']
        if ($null -ne $responseUriProperty -and $null -ne $responseUriProperty.Value) {
            $finalUri = [Uri]$responseUriProperty.Value
        }
        elseif ($null -ne $requestMessageProperty -and $null -ne $requestMessageProperty.Value) {
            $finalUri = [Uri]$requestMessageProperty.Value.RequestUri
        }
        else {
            throw 'SkillHub update check did not expose the final endpoint.'
        }
        if ($finalUri.Scheme -cne 'https' -or $finalUri.Host -cne 'api.skillhub.cn' -or
            $finalUri.AbsolutePath -cne '/api/v1/skills/cad-design-and-drafting' -or
            $finalUri.Query -cne '?namespace=org-qu1qhx78') {
            throw 'SkillHub update check redirected to an unexpected endpoint.'
        }
        $content = [string]$response.Content
        if ([Text.Encoding]::UTF8.GetByteCount($content) -gt $maximumResponseBytes) {
            throw 'SkillHub update response is too large.'
        }
        $document = $content | ConvertFrom-Json
        if ([string]$document.namespace.canonicalName -cne $skillPackage) {
            throw 'SkillHub update response returned an unexpected package.'
        }
        $latestVersion = [string]$document.latestVersion.version
        $null = Convert-SemVer $latestVersion
        $status = if ((Compare-SemVer $skillVersion $latestVersion) -lt 0) {
            'update-available'
        } else {
            'current'
        }
        Write-UpdateResult $status ([ordered]@{
            currentVersion = $skillVersion
            latestVersion = $latestVersion
            package = $skillPackage
            page = $updatePage
        })
    } catch {
        Write-UpdateResult 'unavailable' ([ordered]@{
            currentVersion = $skillVersion
            package = $skillPackage
            page = $updatePage
            error = [ordered]@{
                code = 'update-check-failed'
                message = 'SkillHub update check is temporarily unavailable; the local version remains usable.'
            }
        })
    } finally {
        [Net.ServicePointManager]::SecurityProtocol = $savedProtocol
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    Invoke-CadSkillUpdateCheck
}
