Set-StrictMode -Version 2.0
# Node-hosted Agents can inherit PowerShell 7's module path while launching Windows PowerShell 5.
Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -ErrorAction Stop

function Get-CadSkillPackage {
    param([string]$ExpectedVersion, [string]$ExpectedDigest)

    $root = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
    $manifestPath = Join-Path $root 'references/skill-package.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        throw 'CAD_SKILL_PACKAGE_INVALID: Reinstall the complete Skill package; its file manifest is missing.'
    }
    $manifest = [IO.File]::ReadAllText($manifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
    if ($manifest.schemaVersion -ne 1 -or $manifest.skill -cne 'cad-design-and-drafting' -or
        [string]$manifest.version -cnotmatch '^\d+\.\d+\.\d+$' -or
        ($ExpectedVersion -and [string]$manifest.version -cne $ExpectedVersion)) {
        throw 'CAD_SKILL_PACKAGE_INVALID: Skill identity or version differs from the loaded update checker.'
    }
    $digest = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($ExpectedDigest -and $digest -cne $ExpectedDigest) {
        throw 'CAD_SKILL_CONTEXT_CHANGED: Check this Skill again and reread its entrypoint and execution contract before continuing.'
    }
    $expected = @{}
    foreach ($file in $manifest.files) {
        $relative = [string]$file.path
        if ($relative -cnotmatch '^(SKILL\.md|(scripts|references|assets|knowledge)/[A-Za-z0-9_./-]+)$' -or
            $relative -match '(^|/)\.{1,2}(/|$)|//|/$' -or $relative -ceq 'references/skill-package.json' -or
            $expected.ContainsKey($relative) -or [string]$file.sha256 -cnotmatch '^[0-9a-f]{64}$' -or
            [long]$file.bytes -lt 0) {
            throw 'CAD_SKILL_PACKAGE_INVALID: Invalid or duplicate file identity in the package manifest.'
        }
        $expected[$relative] = $file
    }
    foreach ($required in @('SKILL.md', 'references/agent-execution-contract.md', 'references/runtime-manifest.json',
        'scripts/check-update.ps1', 'scripts/install-runtime.ps1', 'scripts/verify-skill.ps1', 'scripts/invoke-cad.ps1')) {
        if (-not $expected.ContainsKey($required)) { throw "CAD_SKILL_PACKAGE_INVALID: Missing required file $required." }
    }
    # Enumerate explicitly so a linked directory is rejected before traversing it.
    $pending = New-Object 'Collections.Generic.Queue[string]'
    $pending.Enqueue($root)
    $seen = @{}
    while ($pending.Count -gt 0) {
        $directory = $pending.Dequeue()
        foreach ($item in Get-ChildItem -LiteralPath $directory -Force) {
            $relative = $item.FullName.Substring($root.Length + 1).Replace('\', '/')
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "CAD_SKILL_PACKAGE_INVALID: Linked package entry $relative."
            }
            # Installed Runtime and task data are outside the immutable execution payload.
            # The reparse check above still rejects a linked workspace root.
            if ($relative -cin @('.runtime', '.work') -and $item.PSIsContainer) { continue }
            if ($item.PSIsContainer) {
                if ($relative -cnotmatch '^(scripts|references|assets|knowledge)(/|$)') {
                    throw "CAD_SKILL_PACKAGE_INVALID: Unexpected package directory $relative."
                }
                $pending.Enqueue($item.FullName)
                continue
            }
            # Marketplace-owned presentation metadata is outside the released execution payload.
            if ($relative -cin @('references/skill-package.json', '_meta.json', '_skillhub_meta.json', '_user_meta.json', '_icon.png')) { continue }
            if (-not $expected.ContainsKey($relative)) {
                throw "CAD_SKILL_PACKAGE_INVALID: Unexpected file $relative; reinstall the complete Skill instead of overlaying old files."
            }
            $entry = $expected[$relative]
            if ($item.Length -ne [long]$entry.bytes -or
                (Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$entry.sha256) {
                throw "CAD_SKILL_PACKAGE_INVALID: File differs from the released package: $relative."
            }
            $seen[$relative] = $true
        }
    }
    if ($seen.Count -ne $expected.Count) { throw 'CAD_SKILL_PACKAGE_INVALID: The installed Skill has missing files.' }
    $runtime = [IO.File]::ReadAllText((Join-Path $root 'references/runtime-manifest.json'), [Text.Encoding]::UTF8) | ConvertFrom-Json
    [ordered]@{
        skillVersion = [string]$manifest.version
        packageDigest = $digest
        skillRoot = $root
        runtimeVersion = [string]$runtime.version
        runtimeChecksum = [string]$runtime.checksum
        requiredRead = @('SKILL.md', 'references/agent-execution-contract.md')
    }
}
