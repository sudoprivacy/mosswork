[CmdletBinding()]
param([string[]]$Topic = @(), [string]$ContextPath, [string]$CliPath, [string]$PackageDigest,
      [string[]]$DisabledTopic = @(), [string[]]$DisabledVersion = @())

$ErrorActionPreference = 'Stop'
$knowledgeRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../references'))

function Read-KnowledgeJson([string]$Path) {
    if ((Get-Item -LiteralPath $Path).Length -gt 64KB) { throw 'knowledge_file_budget' }
    return [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8) | ConvertFrom-Json
}

function Get-KnowledgeFile([string]$Relative, [string]$Sha256) {
    if ($Relative -cnotmatch '^[a-z0-9-]+(?:/[a-z0-9-]+)*\.(json|md)$') { throw 'knowledge_path_invalid' }
    $path = [IO.Path]::GetFullPath((Join-Path $knowledgeRoot $Relative))
    $item = Get-Item -LiteralPath $path
    $parent = $item
    while ($null -ne $parent -and $parent.FullName.Length -ge $knowledgeRoot.Length) {
        if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'knowledge_link_rejected' }
        $parent = if ($parent -is [IO.FileInfo]) { $parent.Directory } else { $parent.Parent }
    }
    if ($item.Length -gt 64KB -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Sha256) {
        throw 'knowledge_integrity_mismatch'
    }
    return $path
}

# Dot-sourcing is used by the repository release gate; normal invocation only
# reads its small index and the explicitly selected topics.
if ($MyInvocation.InvocationName -eq '.') { return }

# External Agents consume JSON bytes from redirected stdout. Windows console
# code pages must not change source names, observations or applicability text.
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$OutputEncoding = [Text.UTF8Encoding]::new($false)

try {
    # Agents may launch Windows PowerShell with PowerShell 7's module path.
    Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -ErrorAction Stop
    $manifest = Read-KnowledgeJson (Join-Path $knowledgeRoot 'engineering-knowledge-pack-v1-manifest.json')
    if ($DisabledVersion -ccontains $manifest.version) { throw 'knowledge_version_disabled' }
    $indexRef = $manifest.content.topicIndex
    $index = Read-KnowledgeJson (Get-KnowledgeFile $indexRef.path $indexRef.sha256)
    if ($index.schemaVersion -ne 1 -or $index.geometryWriteAllowed -ne $false) { throw 'knowledge_index_invalid' }
    if ($Topic.Count -eq 0) {
        [ordered]@{status='catalog'; generationBlocked=$false; packVersion=$manifest.version;
            topics=@($index.topics | Where-Object { $DisabledTopic -cnotcontains $_.id } | Select-Object id, summary, path, bytes)} | ConvertTo-Json -Depth 10 -Compress
        return
    }
    if ($Topic.Count -gt 3 -or @($Topic | Select-Object -Unique).Count -ne $Topic.Count) { throw 'knowledge_selection_budget' }
    $selected = @()
    $totalBytes = 0
    $context = $null
    $cadInvoker = Join-Path $PSScriptRoot 'invoke-cad.ps1'
    $packageManifest = Join-Path $PSScriptRoot '../references/skill-package.json'
    $runtimeManifest = Join-Path $PSScriptRoot '../references/runtime-manifest.json'
    $cadPackage = $false
    if ($ContextPath) {
        $context = Read-KnowledgeJson ([IO.Path]::GetFullPath($ContextPath))
        $cadPackage = Test-Path -LiteralPath $cadInvoker -PathType Leaf
        if (Test-Path -LiteralPath $runtimeManifest -PathType Leaf) {
            $cadPackage = $cadPackage -or (Read-KnowledgeJson $runtimeManifest).id -ceq 'cad-cli'
        }
        if ($cadPackage -or ($CliPath -and [IO.Path]::GetFileName($CliPath) -ceq 'cad-cli.exe')) {
            if (-not (Test-Path -LiteralPath $cadInvoker -PathType Leaf) -or
                -not (Test-Path -LiteralPath $packageManifest -PathType Leaf)) { throw 'knowledge_evaluator_unavailable' }
            if (-not $PackageDigest) {
                $PackageDigest = (Get-FileHash -LiteralPath $packageManifest -Algorithm SHA256).Hash.ToLowerInvariant()
            }
            if ($PackageDigest -cnotmatch '^[0-9a-f]{64}$') { throw 'knowledge_evaluator_unavailable' }
            $cadPackage = $true
        } elseif (-not $CliPath -or -not (Test-Path -LiteralPath $CliPath -PathType Leaf) -or
            [IO.Path]::GetFileName($CliPath) -cne 'solidworks-cli.exe') { throw 'knowledge_evaluator_unavailable' }
    }
    foreach ($id in $Topic) {
        if ($DisabledTopic -ccontains $id) { continue }
        $entry = @($index.topics | Where-Object { $_.id -ceq $id })
        if ($entry.Count -ne 1) { throw 'knowledge_topic_unknown' }
        $path = Get-KnowledgeFile $entry[0].path $entry[0].sha256
        $totalBytes += (Get-Item -LiteralPath $path).Length
        if ($totalBytes -gt 24KB) { throw 'knowledge_selection_budget' }
        $text = [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8).Replace("`r`n", "`n")
        $parts = $text -split "`n---`n", 2
        if ($parts.Count -ne 2 -or -not $parts[0].StartsWith("---`n")) { throw 'knowledge_topic_invalid' }
        $meta = $parts[0].Substring(4) | ConvertFrom-Json
        if ($meta.id -cne $id -or [datetime]::ParseExact($meta.reviewAfter, 'yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture) -lt [datetime]::UtcNow.Date) {
            throw 'knowledge_review_required'
        }
        $assessment = @{status='insufficient-information'; numericUseAllowed=$false; reason='project-context-not-assessed'}
        $calculations = @()
        if ($null -ne $context) {
        $start = New-Object Diagnostics.ProcessStartInfo
        if ($cadPackage) {
            $start.FileName = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
            $command = '[Console]::InputEncoding = [Text.UTF8Encoding]::new($false); [Console]::In.ReadToEnd() | & ''{0}'' -PackageDigest ''{1}'' -CommandArgs @(''knowledge'', ''--evaluate'', ''--request'', ''-'', ''--json'')' -f
                $cadInvoker.Replace("'", "''"), $PackageDigest
            $start.Arguments = '-NoLogo -NoProfile -NonInteractive -Command "' + $command + '"'
        } else {
            $start.FileName = [IO.Path]::GetFullPath($CliPath)
            $start.Arguments = 'knowledge --evaluate --request - --json'
        }
        $start.UseShellExecute = $false
        $start.CreateNoWindow = $true
        $start.RedirectStandardInput = $true
        $start.RedirectStandardOutput = $true
        $start.RedirectStandardError = $true
        $start.StandardOutputEncoding = [Text.Encoding]::UTF8
        $process = [Diagnostics.Process]::Start($start)
        try {
            $output = $process.StandardOutput.ReadToEndAsync()
            $errors = $process.StandardError.ReadToEndAsync()
            $inputJson = @{schemaVersion=1; reference=$meta; context=$context} | ConvertTo-Json -Depth 30 -Compress
            $inputBytes = [Text.Encoding]::UTF8.GetBytes($inputJson)
            if ($inputBytes.Length -gt 32KB) { throw 'knowledge_input_budget' }
            $process.StandardInput.BaseStream.Write($inputBytes, 0, $inputBytes.Length)
            $process.StandardInput.Close()
            if (-not $process.WaitForExit(5000)) { $process.Kill(); throw 'knowledge_evaluation_timeout' }
            $raw = $output.GetAwaiter().GetResult()
            [void]$errors.GetAwaiter().GetResult()
            if ($process.ExitCode -ne 0 -or [Text.Encoding]::UTF8.GetByteCount($raw) -gt 32KB) { throw 'knowledge_evaluation_unavailable' }
        } finally { if (-not $process.HasExited) { $process.Kill() }; $process.Dispose() }
        $actual = $raw | ConvertFrom-Json
        if ($actual.status -cne 'evaluated' -or $actual.knowledgeId -cne $id) { throw 'knowledge_evaluation_unavailable' }
        $assessment = $actual.assessment
        $calculations = @($actual.calculations)
        }
        $body = $parts[1].Trim()
        if (-not $assessment.numericUseAllowed) {
            $body = $meta.summary
            $meta.quantities = @()
            if ($meta.PSObject.Properties['formulas']) { $meta.formulas = @() }
        }
        $selected += [ordered]@{id=$id; sha256=$entry[0].sha256; metadata=$meta; content=$body; assessment=$assessment; calculations=$calculations}
    }
    $result = [ordered]@{status=$(if ($selected.Count) {'available'} else {'no_match'}); generationBlocked=$false; geometryWriteAllowed=$false;
        packVersion=$manifest.version; numericDefaultsAllowed=$false; topics=$selected}
    $json = $result | ConvertTo-Json -Depth 100 -Compress
    if ([Text.Encoding]::UTF8.GetByteCount($json) -gt 32KB) { throw 'knowledge_response_budget' }
    $json
} catch {
    $reason = [string]$_.Exception.Message
    if ($reason -cnotmatch '^knowledge_[a-z_]+$') { $reason = 'knowledge_unavailable' }
    [ordered]@{status='unavailable'; reason=$reason; generationBlocked=$false;
        next='Continue with the current tool schema and original user facts; do not apply this knowledge as a rule.'} |
        ConvertTo-Json -Compress
}
