[CmdletBinding()]
param(
    [string]$InstallRoot,
    [string]$PackagePath,
    [switch]$ConfirmedByUser
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$skillRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'verify-skill.ps1')
$skillPackage = Get-CadSkillPackage
$pinnedManifestPath = Join-Path $skillRoot 'references\runtime-manifest.json'
if (-not (Test-Path -LiteralPath $pinnedManifestPath -PathType Leaf)) {
    throw 'The package-pinned Runtime manifest is missing.'
}
$pinned = [IO.File]::ReadAllText($pinnedManifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
foreach ($property in @(
    'schemaVersion', 'id', 'version', 'platform', 'resolverUrl', 'allowedDownloadHosts',
    'checksum', 'sizeBytes', 'format', 'entrypoint'
)) {
    if ($null -eq $pinned.PSObject.Properties[$property]) {
        throw "The package-pinned Runtime manifest omitted '$property'."
    }
}
if ([int]$pinned.schemaVersion -ne 1 -or [string]$pinned.id -cne 'cad-cli' -or
    [string]$pinned.version -cnotmatch '^\d+\.\d+\.\d+$' -or
    [string]$pinned.platform -cne 'win-x64' -or
    [string]$pinned.resolverUrl -cne 'https://xiaozhi.qlogicagent.com/api/v15/runtime/cad-cli/resolve?platform=win-x64' -or
    [string]$pinned.checksum -cnotmatch '^[0-9a-f]{64}$' -or
    [int64]$pinned.sizeBytes -le 0 -or [string]$pinned.format -cne 'zip' -or
    [string]$pinned.entrypoint -cne 'cad-cli.exe') {
    throw 'The package-pinned Runtime identity is invalid.'
}
$runtimeId = [string]$pinned.id
$runtimeVersion = [string]$pinned.version
$platform = [string]$pinned.platform
$ResolveUrl = [string]$pinned.resolverUrl
if ([string]::IsNullOrWhiteSpace($InstallRoot)) {
    $InstallRoot = Join-Path $skillRoot '.runtime'
}
$InstallRoot = [IO.Path]::GetFullPath($InstallRoot)

function Assert-Property([object]$Value, [string]$Name) {
    if ($null -eq $Value.PSObject.Properties[$Name]) {
        throw "Runtime resolver omitted required property '$Name'."
    }
}

function Assert-SafeRelativePath([string]$Value, [string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Value) -or [IO.Path]::IsPathRooted($Value)) {
        throw "$Name must be a non-empty relative path."
    }
    $segments = $Value -split '[\\/]'
    if ($segments | Where-Object { $_ -eq '..' -or $_ -eq '.' -or [string]::IsNullOrWhiteSpace($_) }) {
        throw "$Name contains an unsafe path segment."
    }
}

function Test-InstalledRuntime([string]$Destination, [string]$Executable) {
    $metadataPath = Join-Path $Destination 'runtime.json'
    $packagePath = Join-Path $Destination 'runtime-package.json'
    if (-not (Test-Path -LiteralPath $Executable -PathType Leaf) -or
        -not (Test-Path -LiteralPath $metadataPath -PathType Leaf) -or
        -not (Test-Path -LiteralPath $packagePath -PathType Leaf)) {
        return $false
    }
    try {
        $metadata = [IO.File]::ReadAllText($metadataPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
        $package = [IO.File]::ReadAllText($packagePath, [Text.Encoding]::UTF8) | ConvertFrom-Json
        $pinnedManifestSha256 = (Get-FileHash -LiteralPath $pinnedManifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ([string]$metadata.runtimeId -cne $runtimeId -or
            [string]$metadata.version -cne $runtimeVersion -or
            [string]$metadata.platform -cne $platform -or
            [string]$metadata.checksum -cne [string]$pinned.checksum -or
            [int64]$metadata.sizeBytes -ne [int64]$pinned.sizeBytes -or
            [string]$metadata.entrypoint -cne [string]$pinned.entrypoint -or
            [string]$metadata.pinnedManifestSha256 -cne $pinnedManifestSha256 -or
            [int]$package.schemaVersion -ne 3 -or
            [string]$package.runtimeId -cne $runtimeId -or
            [string]$package.version -cne $runtimeVersion -or
            [string]$package.entrypoint -cne [string]$pinned.entrypoint) {
            return $false
        }
        if ($null -eq $metadata.PSObject.Properties['files']) { return $false }
        $installedFiles = @(Get-ChildItem -LiteralPath $Destination -Recurse -Force -File |
            Where-Object { $_.FullName -cne $metadataPath })
        if ($installedFiles.Count -ne @($metadata.files).Count) { return $false }
        foreach ($file in @($metadata.files)) {
            Assert-SafeRelativePath ([string]$file.path) 'cached payload path'
            $path = [IO.Path]::GetFullPath((Join-Path $Destination ([string]$file.path)))
            if (-not $path.StartsWith($Destination.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or
                -not (Test-Path -LiteralPath $path -PathType Leaf) -or
                (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$file.sha256) {
                return $false
            }
        }
        $versionOutput = @(& $Executable '--version' 2>&1)
        if ($LASTEXITCODE -ne 0 -or $versionOutput.Count -ne 1 -or
            [string]$versionOutput[0] -cne "$runtimeId $runtimeVersion") {
            return $false
        }
        $capabilityOutput = @(& $Executable 'capabilities' '--json' 2>&1)
        if ($LASTEXITCODE -ne 0) { return $false }
        $capabilities = ($capabilityOutput -join "`n") | ConvertFrom-Json
        $backends = @($capabilities.diagnostics | Where-Object { $_.component -like 'backend:*' })
        return [string]$capabilities.backend -ceq 'portable' -and
            $backends.Count -eq 1 -and [string]$backends[0].component -ceq 'backend:portable' -and
            [string]$backends[0].status -ceq 'passed'
    }
    catch { return $false }
}

function Write-Result([string]$Executable, [bool]$Cached, [string]$Checksum) {
    [ordered]@{
        runtimeId = $runtimeId
        version = $runtimeVersion
        platform = $platform
        executable = $Executable
        cached = $Cached
        checksum = $Checksum
        executionRuntime = 'portable'
        executableSha256 = (Get-FileHash -LiteralPath $Executable -Algorithm SHA256).Hash.ToLowerInvariant()
        skillPackage = $skillPackage
    } | ConvertTo-Json -Compress
}

Assert-SafeRelativePath ([string]$pinned.entrypoint) 'pinned entrypoint'
$destination = Join-Path (Join-Path (Join-Path $InstallRoot $runtimeId) $runtimeVersion) $platform
$destination = [IO.Path]::GetFullPath($destination)
$executable = [IO.Path]::GetFullPath((Join-Path $destination ([string]$pinned.entrypoint)))
$destinationPrefix = $destination.TrimEnd([char[]]@('\', '/')) + [IO.Path]::DirectorySeparatorChar
if (-not $executable.StartsWith($destinationPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Resolved entrypoint escapes the runtime installation directory.'
}
if (Test-InstalledRuntime $destination $executable) {
    Write-Result $executable $true ([string]$pinned.checksum)
    exit 0
}
if (-not $ConfirmedByUser) {
    throw "Runtime installation requires explicit user confirmation. Review $pinnedManifestPath, then rerun with -ConfirmedByUser."
}

if ([string]::IsNullOrWhiteSpace($PackagePath)) {
    $manifest = Invoke-RestMethod -Method Get -Uri $ResolveUrl -Headers @{ Accept = 'application/json' } -MaximumRedirection 2 -TimeoutSec 20
    foreach ($property in @('id', 'version', 'platform', 'downloadUrl', 'checksum', 'sizeBytes', 'format', 'entrypoint')) {
        Assert-Property $manifest $property
    }
    foreach ($property in @('id', 'version', 'platform', 'checksum', 'sizeBytes', 'format', 'entrypoint')) {
        if ([string]$manifest.$property -cne [string]$pinned.$property) {
            throw "CAD_SKILL_UPDATE_REQUIRED: Runtime resolver property '$property' does not match the package-pinned manifest. Update the complete Skill through its platform and reread its instructions; do not replace only the CLI."
        }
    }
    Assert-SafeRelativePath ([string]$manifest.entrypoint) 'entrypoint'

    $downloadUri = [Uri]$manifest.downloadUrl
    if (-not $downloadUri.IsAbsoluteUri -or $downloadUri.Scheme -cne 'https') {
        throw 'Runtime download URL must use HTTPS.'
    }
    $allowedDownloadHosts = @($pinned.allowedDownloadHosts | ForEach-Object { [string]$_ })
    if ($allowedDownloadHosts.Count -eq 0 -or $allowedDownloadHosts -cnotcontains $downloadUri.Host) {
        throw "Runtime download host '$($downloadUri.Host)' is not package-pinned."
    }
} else {
    $PackagePath = (Resolve-Path -LiteralPath $PackagePath).Path
    if (-not (Test-Path -LiteralPath $PackagePath -PathType Leaf)) {
        throw 'PackagePath must name the exact package pinned by this Skill.'
    }
    $manifest = $pinned
}
New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
$rollbackDestination = $null
$stagingRoot = Join-Path $InstallRoot ('.staging-' + [Guid]::NewGuid().ToString('N'))
$archivePath = Join-Path $stagingRoot 'runtime.zip'
$extractRoot = Join-Path $stagingRoot 'payload'

try {
    New-Item -ItemType Directory -Force -Path $extractRoot | Out-Null
    if (Test-Path -LiteralPath $destination) {
        $destinationParent = Split-Path -Parent $destination
        $rollbackDestination = Join-Path $destinationParent ('.rollback-' + [Guid]::NewGuid().ToString('N'))
        Move-Item -LiteralPath $destination -Destination $rollbackDestination
    }
    if ([string]::IsNullOrWhiteSpace($PackagePath)) {
        $savedProgressPreference = $ProgressPreference
        $ProgressPreference = 'SilentlyContinue'
        try {
            Invoke-WebRequest -Method Get -Uri $downloadUri -OutFile $archivePath -Headers @{ Accept = 'application/octet-stream' } -MaximumRedirection 2 -TimeoutSec 120
        } finally {
            $ProgressPreference = $savedProgressPreference
        }
    } else {
        Copy-Item -LiteralPath $PackagePath -Destination $archivePath
    }

    $archive = Get-Item -LiteralPath $archivePath
    if ($archive.Length -ne [int64]$manifest.sizeBytes) {
        throw "Runtime size mismatch: expected $($manifest.sizeBytes), received $($archive.Length)."
    }
    $actualChecksum = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualChecksum -cne [string]$manifest.checksum) {
        throw "Runtime checksum mismatch: expected $($manifest.checksum), received $actualChecksum."
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
    try {
        $extractPrefix = [IO.Path]::GetFullPath($extractRoot).TrimEnd([char[]]@('\', '/')) + [IO.Path]::DirectorySeparatorChar
        foreach ($entry in $zip.Entries) {
            if ([string]::IsNullOrWhiteSpace($entry.FullName)) { continue }
            $entryName = $entry.FullName.Replace('\', '/')
            if ($entryName -match '(?i)\.(exe|dll)$' -and
                $entryName -cnotin @('cad-cli.exe', 'pdfium/pdfium.dll')) {
                throw "Unexpected Runtime executable: $entryName"
            }
            $candidate = [IO.Path]::GetFullPath((Join-Path $extractRoot $entry.FullName))
            if (-not $candidate.StartsWith($extractPrefix, [StringComparison]::OrdinalIgnoreCase)) {
                throw "Runtime archive contains an unsafe path '$($entry.FullName)'."
            }
        }
    } finally {
        $zip.Dispose()
    }
    [IO.Compression.ZipFile]::ExtractToDirectory($archivePath, $extractRoot)

    $stagedExecutable = [IO.Path]::GetFullPath((Join-Path $extractRoot ([string]$manifest.entrypoint)))
    if (-not (Test-Path -LiteralPath $stagedExecutable -PathType Leaf)) {
        throw "Runtime archive omitted entrypoint '$($manifest.entrypoint)'."
    }
    $metadata = [ordered]@{
        runtimeId = $runtimeId
        version = $runtimeVersion
        platform = $platform
        checksum = [string]$manifest.checksum
        sizeBytes = [int64]$manifest.sizeBytes
        entrypoint = [string]$manifest.entrypoint
        source = if ($PackagePath) { 'package-pinned-local-archive' } else { $ResolveUrl }
        files = @(Get-ChildItem -LiteralPath $extractRoot -Recurse -Force -File | ForEach-Object {
            [ordered]@{
                path = $_.FullName.Substring($extractRoot.TrimEnd([IO.Path]::DirectorySeparatorChar).Length + 1).Replace([IO.Path]::DirectorySeparatorChar, '/')
                sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            }
        })
        pinnedManifestSha256 = (Get-FileHash -LiteralPath $pinnedManifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
    } | ConvertTo-Json -Depth 5
    Set-Content -LiteralPath (Join-Path $extractRoot 'runtime.json') -Value $metadata -Encoding UTF8

    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
    Move-Item -LiteralPath $extractRoot -Destination $destination
    if (-not (Test-InstalledRuntime $destination $executable)) {
        throw 'The installed Runtime failed its identity, version, or portable-only capability probe.'
    }
    if ($rollbackDestination -and (Test-Path -LiteralPath $rollbackDestination)) {
        Remove-Item -LiteralPath $rollbackDestination -Recurse -Force
        $rollbackDestination = $null
    }
    Write-Result $executable $false ([string]$manifest.checksum)
} catch {
    if (Test-Path -LiteralPath $destination) {
        Remove-Item -LiteralPath $destination -Recurse -Force -ErrorAction SilentlyContinue
    }
    if ($rollbackDestination -and (Test-Path -LiteralPath $rollbackDestination)) {
        Move-Item -LiteralPath $rollbackDestination -Destination $destination -ErrorAction SilentlyContinue
        $rollbackDestination = $null
    }
    throw
} finally {
    if (Test-Path -LiteralPath $stagingRoot) {
        Remove-Item -LiteralPath $stagingRoot -Recurse -Force
    }
}
