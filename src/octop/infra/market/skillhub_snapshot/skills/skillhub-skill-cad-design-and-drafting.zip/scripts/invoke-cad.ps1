param([string]$PackageDigest, [string[]]$CommandArgs)

$hasPipelineInput = $MyInvocation.ExpectingInput
$pipelineInput = if ($hasPipelineInput) { @($input) } else { @() }
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
Set-StrictMode -Version 2.0
try {
    if (-not $CommandArgs -or $args.Count -gt 0) {
        throw 'CAD_SKILL_ARGUMENTS_REQUIRED: Pass CLI arguments as -CommandArgs @(...), including standalone stdin markers.'
    }
    if ($PackageDigest -cnotmatch '^[0-9a-f]{64}$') {
        throw 'CAD_SKILL_CONTEXT_REQUIRED: Run check-update.ps1, read localPackage.requiredRead, and pass localPackage.packageDigest.'
    }
    . (Join-Path $PSScriptRoot 'verify-skill.ps1')
    $identity = Get-CadSkillPackage -ExpectedDigest $PackageDigest
    $runtimeJson = & (Join-Path $PSScriptRoot 'install-runtime.ps1')
    $runtime = ($runtimeJson -join "`n") | ConvertFrom-Json
    if ($runtime.skillPackage.packageDigest -cne $identity.packageDigest) {
        throw 'CAD_SKILL_CONTEXT_CHANGED: The Skill changed while resolving its CLI.'
    }
} catch {
    [Console]::Error.WriteLine(([ordered]@{ status = 'environment-invalid'; error = $_.Exception.Message } | ConvertTo-Json -Compress))
    exit 2
}
[Console]::Error.WriteLine(([ordered]@{
    event = 'cad.environment.verified'
    skillVersion = $identity.skillVersion
    packageDigest = $identity.packageDigest
    runtimeVersion = $runtime.version
    executable = $runtime.executable
    executableSha256 = $runtime.executableSha256
} | ConvertTo-Json -Compress))
$ErrorActionPreference = 'Continue'
$PSNativeCommandUseErrorActionPreference = $false
$previousSkillContext = [Environment]::GetEnvironmentVariable('ASTRACLAW_SKILL_CONTEXT', 'Process')
try {
    $env:ASTRACLAW_SKILL_CONTEXT = [ordered]@{
        client = 'cad-cli'
        skillVersion = $identity.skillVersion
        packageDigest = $identity.packageDigest
        runtimeVersion = $runtime.version
    } | ConvertTo-Json -Compress
    if ($hasPipelineInput) {
        $pipelineInput | & ([string]$runtime.executable) @CommandArgs
    } else {
        & ([string]$runtime.executable) @CommandArgs
    }
    $cadExitCode = $LASTEXITCODE
} finally {
    [Environment]::SetEnvironmentVariable('ASTRACLAW_SKILL_CONTEXT', $previousSkillContext, 'Process')
}
exit $cadExitCode
