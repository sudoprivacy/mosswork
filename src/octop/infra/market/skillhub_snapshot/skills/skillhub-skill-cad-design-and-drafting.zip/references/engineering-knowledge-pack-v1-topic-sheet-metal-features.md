---
{"id":"sheet-metal-features","summary":"钣金孔、翻边和折弯附近特征：供应商参数的适用边界","claimKind":"manufacturing-method","revision":"1.1.1","reviewedOn":"2026-09-10","reviewAfter":"2027-03-10","scope":"supplier-advisory","sources":[{"publisher":"Protolabs","url":"https://www.protolabs.com/services/sheet-metal-fabrication/design-guidelines/","section":"Design Guidelines for Common Sheet Metal Features","edition":"web-page-undated; checked 2026-09-10"}],"conditions":["供应商所述钣金制造服务；当前材料、板厚、刀具及报价需确认","不可覆盖用户尺寸或当作所有工厂的最低能力"],"quantities":[{"name":"flange-length-to-thickness","minimum":4,"maximum":null,"unit":"1","sourceIndex":0},{"name":"hole-diameter-to-thickness","minimum":1,"maximum":null,"unit":"1","sourceIndex":0}],"requiredInputs":["supplier","manufacturingProcess","material","thickness","tooling","supplierApproval"],"evidenceClass":"supplier-advice","applicability":[{"key":"supplier","oneOf":["Protolabs"]},{"key":"manufacturingProcess","oneOf":["sheet-metal"]},{"key":"material"},{"key":"thickness","exclusiveMinimum":0,"unit":"mm"},{"key":"tooling"},{"key":"supplierApproval","oneOf":[true]}]}
---
# 钣金孔与翻边

Protolabs 的该服务指南给出：翻边长度至少为板厚的 4 倍，孔或槽的直径至少为板厚。
这些是该供应商的设计指导，不是通用 GB/ISO 阈值。板厚、弯曲方式、刀具与特征位置会改变可制造性。

先确认尺寸所指是孔心、孔边还是折弯切线，再比较距离。孔靠近折弯可能变形，嵌件孔还须满足嵌件厂家的要求。
不要混用其他页面中“孔至边缘”“孔至折弯”的倍数；适用范围不一致时保留两个出处，交由当前制造方案确认。

本页给出的比例是单侧下限，未提供上限。厚度和工艺未定时，无法由这些比例判断某个具体孔或翻边是否适合加工；其他供应商可能具有不同的能力范围。
