# Agent 执行契约

本文件只供 Agent 在实际写入或转换图纸前读取。不要要求用户理解本页术语、字段或命令。

按当前阶段读取相应章节，不为每次局部修订重读整篇：

- 新任务先完成“更新、安装与账户”，已验证的同一任务直接进入“请求构造”。
- 新图读取“请求构造”和“唯一执行路径”；原图修改另外读取“读取与修改源图”。
- 只有实际遇到待澄清、断线或续改时才读取对应的 Job 恢复及历史归属说明。
- 自然语言请求先用 `schema generation-request --json` 查看信封索引，按需查询返回的字段指针。
  只有已有精确图元设计时才批量查询 `schema generation-request --entities <类型列表> --json`。
  本文说明工作流，不维护第二套完整字段表。
- 已有图纸修改先查询 `schema drawing-patch --json`：返回真实补丁字段、generationRequestComposition
  和下一步精确查询路径。补丁放进 requirements.expectedPatch，sourceFiles 提供实际 drawing；
  requiredHandles、requiredDocument、requiredOutputPaths 可省略，由同一完整补丁推导，显式冲突仍报错。
  新增或替换的图元按 `schema drawing-patch --entities <实际类型列表> --json` 一次查询；
  `operation.entity` 使用 `{id,type,layer,...图元字段}`，不要套用 exactEntities 的 properties 嵌套。

## 更新、安装与账户

先确认当前执行环境是 Windows x64 且能调用 Windows PowerShell；Linux、macOS、
Windows ARM 或没有 PowerShell 的云沙箱不能运行本包，不尝试执行 `.exe` 或用替代绘图
脚本冒充该 Skill。报告环境缺口并保留需求，不要求用户关闭沙箱或安全保护。

以下命令从本次实际加载的 Skill 目录运行；安装和更新脚本无需登录或 API Key。
会话首次使用及每个新制图任务开始前执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/check-update.ps1
```

检查先按发布清单逐文件验证 Skill 文档、脚本、知识文件和配套 CLI 清单，再查询更新。
`repair-required` 表示文件缺失、混装或被修改：通过平台重新安装完整包，保留任务输入和已有成果，
不要仅替换 CLI 或手改清单。`update-available` 时告诉用户当前版本和可用版本，并询问是否更新。
用户同意后通过当前 Agent 平台更新完整 `@org-qu1qhx78/cad-design-and-drafting` 包；没有更新入口
时打开回执中的 `page`。随后从平台实际加载的新 Skill 目录重新执行检查，重新读取
`localPackage.requiredRead` 列出的本文件及 `SKILL.md`；不能沿用会话中缓存的旧说明或旧路径。
平台不能重新加载时，保存任务上下文并在新会话继续，不重复提交已执行的生成请求。
拒绝更新、`current` 或网络 `unavailable` 时，仅在 `localPackage` 校验通过后继续使用该完整版本。

保存本次 `localPackage.packageDigest`，所有 CLI 调用均通过本包的 `scripts/invoke-cad.ps1`。
它每次验证当前包、任务读取的包摘要和配套 CLI 文件；不使用 PATH、旧目录或会话记忆里的 CLI。
首次准备或修复 CLI 时，读取 `references/runtime-manifest.json` 的 `sizeBytes` 告知下载量，
已有安装授权则直接使用，否则取得同意后运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/install-runtime.ps1 -ConfirmedByUser
```

安装器只安装 CLI，不更新 Skill 文档；配套本地 ZIP 使用同一安装器的 `-PackagePath` 参数。
首次安装完成后，从本次安装回执确认 `skillPackage.packageDigest` 与更新检查一致，再通过
包内入口依次运行 `--version` 和 `schema generation-request --json`。后者应返回
`ok: true`、`found: true`；账户、制图或文件回读仍未因此验收通过。首次下载尚未获确认时，
先说明下载大小并等待用户确认；不要先调用绘图入口，让安装缺口被误报成制图失败。
以下示例和其他参考中的 `cad-cli <参数>` 均表示同一个受校验入口。例如：

```powershell
& ./scripts/invoke-cad.ps1 -PackageDigest <本次检查的packageDigest> -CommandArgs @('schema', 'generation-request', '--json')
```

通过同一入口执行 `models current --json` 核对实际模型及选择来源；保留用户明确的模型选择，
不能为了匹配默认值而清除旧账户、会话或已保存配置。版本核验和模型设置不是生成质量验收。
CLI 的标准输出和退出码保持原样；标准错误中的 `cad.environment.verified` 回执记录实际 Skill、
CLI 版本、路径与文件摘要，随本次执行证据保留。`CAD_SKILL_CONTEXT_CHANGED` 要求重新检查、
重新读取说明后继续；环境问题不触发付费生成重试。省略 `--backend`，不要求用户选择执行方式。

首次制图可自动创建试用账号。按用户需要使用以下账户操作：

- `auth status --json`：查看脱敏账号、余额和试用状态。
- `auth login --json`：打开浏览器登录或切换账号。
- `auth logout --json`：回到设备试用账号。
- `auth configure --stdin --json`：仅用于用户主动选择的自定义 API Key；通过安全输入送入
  stdin，不写入聊天、命令参数、文件或日志。自定义 Key 不随账号切换。

余额不足时展示 CLI 返回的一次性钱包链接，等待用户自行处理；不自动充值或重复提交可能
已计费的规划请求。首次充值前需要绑定可找回身份。

## 读取与修改源图

DWG/DXF 写回仅开放给整图保存
闭包已证明、目标结果集可完整解释且操作属于当前认证子集的任务。优先用 inspect 返回的唯一
handle；自然语言相对位置先根据 inspect 的实体、图层和几何变成 criteria，空间邻近使用
`geometry.withinBox: [[minX,minY],[maxX,maxY]]`。criteria patch 以 `expectedCount` 固定本次实际
命中数量；能给出整图实体数量不变量时再增加相容的 `entityCount` 前/后置条件。任一数量不符时
整个事务在首个写入前失败，不允许“选中最像的几个”。

修改操作支持批量 `updateProperties` / `transform`、`delete`、`expectedCount: 1` 的
`replace` 和 `add`。给已有客户图增补视口、图框、标题栏或图元时使用同一 `patch` / `edit`；
把客户原图声明为唯一 `drawing`，样式样本声明为 `reference`，不把客户图降为参考后重新画一份。
新增图层、块与纸图必须使用不冲突的身份，不能用 `add` 覆盖原资源。CLI 先解析全部操作和前置条件，
在克隆文档上执行，检查后置条件，再由同一 `ReferenceGraph` 核验 owner/reactor、字典/XRecord、
XData、Group、DrawOrder、HATCH、Leader、DIMASSOC、Field、DynamicBlock、ObjectContext、Image、
Layout、proxy/registered-class 等关系和未触及对象，最后保存重开。删除实体会级联它拥有的属性、
SEQEND 和扩展字典对象闭包，并在提交前再次检查所有删除 handle 没有悬挂引用。

既有图纸的自然语言续改使用 `kind: patch`、`requirements.command: edit` 和唯一
`role: drawing` 源。`previewPath` 仅供 `role: template` 使用；实际图纸先用 `inspect`
生成预览，Agent 读取后通过 `sourceObservations` 记录观察，不把预览路径塞进 drawing 源。

`expectedPatch` 只用于已确定的精确修改，不要从上一份绘图 Plan 直接复制其验收。
闭合轮廓和尺寸引用必须是本次新增／替换实体的 ID，或原图 inspect 得到的真实 handle；
原绘图的语义 ID 不能直接绑定重开的原图。`expectedEntities` 是修改后整份输出的数量，
必须包含未删除的源对象。CLI 在付费规划前用同一原生事务检查精确 patch 的可执行性，
失败时按具体对象和验收差异修正请求，不能删除验收或改动无关对象来通过。

整图文字批量调整不得展开成成千上万个 handle 操作。先用完整 inspect 统计 `dbText`/`mText`
（包括普通块和匿名标注块内文字），再由模型给出高度分段与倍率；服务端把它规范化为带
`geometry.heightRange`、`expectedCount` 和 `heightScale` 的现有 `updateProperties` 事务。
标注文字高度使用 `dimensionStyleTextHeight` 作为实体级标注样式覆盖；只修改所选标注，不改写共享 DimStyle，也不影响其他标注。
CLI 执行该合同；任一分段命中数量漂移、样式不存在或重开后高度/
样式不一致都整单失败。inspect 的 `templateProjection` 必须同时保留图层颜色/线型/线宽、文字与
标注样式、块定义/引用、layout/viewport 和 Plot 设置，空投影不能作为工程结构保真证据。

读取源图时按真实归属区分模型空间、纸空间和块定义。`blockEntityCount` 包括未插入的库存块
与标注图形成员，不能并入可见模型数量。`payload.space=block`、`ownerBlockName` 与
`ownerHandle` 标识定义坐标；只有实际 `placements` 才证明它在图中的位置。库存块中的标题或
零件名称只是源文件事实，不能据此把该块自动插入、认作当前图纸主体或删除其他工程内容。

关联剖面线、引线、字典和未知对象的保留由 CLI 的原生关系检查与保存重开负责。
Agent 根据回执判断实际支持范围，再查看修改区域及未触及内容；不能从“解析成功”推断保真保存成功。
若 CLI 指出对象关系或格式能力缺口，保留原文件和具体失败证据，不删除该对象或降低输出要求来规避。

把“删除左边那个孔”落成 patch 时，先 inspect 并验证该圆确为孔及其母轮廓/关联，再用唯一 handle，
或用 `entityType: circle` 加只包含该圆完整 extents 的 `withinBox`；把“选择附近几条线”落成
`entityType: line`＋窗口并使用实际硬计数。不得把“左边”“附近”原样塞进 selector，也不得在
没有读到源文件字节时猜 handle、窗口或数量。

## 规划、计量与执行凭证

新建、修改、参数化、制表和转换先由 `cad-cli generate` 调用 LLMRouter 完成工程规划、计量并
取得签名 Plan Grant。CLI 执行该 Grant，成功路径继续提交同一 job 的真实交付证据。
模型费用按已确认的实际消耗结算，包括审查、纠错和最终失败的调用；未调用模型的本地校验及
纯等待不会产生模型费用。`failed`、没有 Grant 或用户取消都不代表免费，以回执的账务状态为准。

协商 `cadIncrementalDrafts` 后，完整构件增量由同一编译器校验并签名；`generate` 与 `plan wait`
在最终计划完成前即可执行草稿。草稿保存在输出目录旁的 `cad-drafts/<jobId>/<planHash>/artifacts`，
各版本独立保留，不覆盖父图或已完成成果。`cad_draft_ready` 表示已有可执行草稿；只有真实原生执行
回执中的产物路径才能作为已保存图纸汇报。最终失败回执的 `partialArtifacts` 仍列出保留的文件。
草稿的原始设计与工程、视觉验收继续处于待完成状态；审查不阻断草稿保存和可行的 PDF 导出。
推理活动不代表制图进展：长期没有新增可编译构件时，服务保留检查点，在原任务预算内尝试不同供应
路径；供应恢复失败仍保留草稿，不自动创建新付费任务。Agent 继续查询原 job，不以推理字符数报完成。

### Agent 自主澄清与同一 Job 恢复

恢复中断的 `revise` 时，`plan wait` 同时传入原项目的 `--from`，并继续提供该次修订的原始请求与原 jobId；CLI 在下载前锁定项目、核验并保留父版本，成功后推进同一续改历史。首次生成的恢复不传 `--from`。已经成功提交的 Grant 直接用于执行，不重新恢复为新修订。

是否澄清只由 Agent/LLM 根据用户完整需求决定。不得按缺失字段、置信度、复杂度、对象数量、知识
命中率、模型评分或固定行业清单触发提问。需求足够时继续普通 `generate`；Agent 决定提问时，在
昂贵生成前使用同一请求创建等待态：

```text
cad-cli plan clarify --request - --output <execution-plan.json> --reason <Agent判断> --question <合并问题> --json
cad-cli plan status --job <jobId> --json
cad-cli plan resume --job <jobId> --decision continue --user-input <用户补充> --json
cad-cli plan wait --job <jobId> --request - --output <execution-plan.json> --progress-jsonl --json
```

Agent 也可使用 `--decision assume --assumption <明确假设>` 继续，或 `--decision cancel` 取消。
结构化 stdout 的 Plan Job 投影中，`agentInteraction` 是能力协商后的等待信息；将其中问题呈现给
用户，不让用户处理 JSON。等待期间同一 job 可查询状态，但不得新建或重发付费任务。用户补充作为
同一历史的需求增量进入 Design Intent；Agent 在 `plan wait` 继续提供原始本地请求，以便 CLI 完成
同一项目的本地验证和 Grant 落盘。

轮询断网、响应无法解析或本地等待中断，不证明服务器任务失败。保留返回的 jobId、原始请求和
输出目录，先查 `plan status`，再用上面的 `plan wait` 取回同一任务结果。只有服务端终态与
`billing.safeToCreateReplacement` 明确允许替代任务时，才根据实际错误修正请求后重新生成。

`plan pause` 仅用于仍处于 queued 的已有 job，并通过 compare-and-set 停在安全的生成前边界。
若 job 已被 worker 领取，CLI 会返回不计费的冲突；不得强行中断已发出的 Provider 请求，也不得
创建替代 job。模型审查发现未知项时，由 Agent 判断它是否影响当前交付，不能仅因缺少非必要
信息宣布用户任务失败；已终止请求的后续处理见下一节。

### 失败后的修正与澄清

保留原始需求、源文件、当前完整设计和精确 jobId。先查询终态及结算：`pending`、仍在执行或
结果不确定时继续查询原 job；不得创建第二个计费请求。`billing.safeToCreateReplacement=true`
只表示前次请求可以被替代，不代表新调用免费或授权无限重试。后续调用必须在用户已授权的
费用和调用预算内；无预算授权或将超出时，说明已花费用及具体下一步后再询问。

- 设计缺项或附加要求：依据 `instancePath`、`validationRule` 和具体 finding 修正本地完整请求。
  补齐原话要求的内容，移除无依据的附加条件，保留其余几何。先 `validate`；没有可执行 Grant
  的终态请求用下节 `requestLineage.retryOfJobId` 关联修正后的 `generate`。已有成功产物则走 `revise`。
- 服务审查错误：`failingArtifact=cad-coverage-review` 指向审查本身，不修改图元来迁就审查路径。
  服务已执行定向纠错；仍失败时先核对具体证据，仅在授权预算和明确重试条件内安排一次关联重试。
  同一审查错误重复出现就保留设计并报告服务阻塞，不继续消耗预算，也不要求用户解释内部 Schema。
- 必需的用户决定：只合并询问实质影响交付的冲突或未知值，不把 Agent 擅自添加的条件转嫁给用户。
  原 job 已终止时保留其记录，将关联后的有效请求交给 `plan clarify` 创建等待态；向用户展示问题，
  收到回答后用该等待 job 的 `plan resume`、`plan wait` 继续。该入口追加用户决定，不会重写
  已提交的图元清单；若答案需要改变 `exactEntities` 或 `expectedPatch`，或请求尚无法通过
  本地校验，先在当前对话等待补充。答案到达后由 Agent 修正、验证，再关联提交；不能为建立
  等待记录而伪造几何，也不能带着旧清单假装已应用用户补充。

每次设计修正都必须消除已确认的问题，未变化的设计不能作为“已修复”再次提交。等待补充时
报告“等待补充”，修正期间报告正在修正；历史失败和费用如实保留，完成声明仍以最终文件验收为准。

## 请求构造

### 会话历史归属

同一用户需求的失败重试应保留关联。服务明确允许创建替代任务后，在新请求中传
`requestLineage: {"schemaVersion": 1, "retryOfJobId": "<前次响应中的精确 jobId>"}`；
该字段只关联执行证据，不继承失败的设计，也不改变计费或自动重试授权。仍在运行、等待输入或
结果未确定时继续原 job，不新建替代任务。新需求省略 `retryOfJobId`，CLI 自动声明新的需求；
成功设计的续改使用下述 `revise --from`，不同时提交重试引用。不得用相似文字、文件名或时间猜测 jobId。

当前 Agent 任务中的首轮设计、另一个新产品或另一个 Agent 任务只调用 `generate`，必须省略
`historyContinuation` 和 `parentRequestId`，并为每个设计使用独立项目目录。每次成功后，CLI 在
结构化 stdout 返回统一 `continuation` envelope，并把完整最新版服务端回执与设计血缘写入该项目
目录的 `astraclaw-design-continuation.json`。

已有当前任务的设计且持有其精确产物引用时，用户明确续改，或 Agent 为完成原任务而修复
工程/视觉验收发现的问题，都调用 `revise --from <产物目录、状态文件或上一轮 Grant>`。
后一种情况保留原始 instruction 和用户固定值，把实际缺陷及改动记录为本次修订证据，不冒充
用户新增指令。新设计才使用 generate；不得为了绕过已有设计检查而换目录重建同一设计。
CLI 自动读取项目内的最新版回执并原子
更新 A→A2→A3 血缘；即使 `--from` 指向同目录中的旧 A1 Grant，也不得用 A1 回执覆盖 A2。
Agent 不得拆解、复制、拼接或重写 `historyContinuation`。用户只说“上一个设计”而当前任务没有
对应产物引用时，必须先澄清，不能搜索或猜测。

不得把同一账号、设备、工作目录、Skill 安装目录、调用时间、文件名、相似需求、`sessionId` 或
“最近活跃请求”当作续接证据，也不得建立全局最近任务缓存。不同任务与产品的历史绝不自动混合。

1. 自然语言任务保留原始 `instruction`、真实源文件和交付要求，查询信封索引及当前所需字段即可，
   不先构造图元清单或读取整份 Schema。已有精确设计才运行
   `cad-cli schema generation-request --entities <逗号分隔的类型> --json`，一次读取实际类型及依赖。
   精确请求示例用 `schema generation-request --example --json`，以返回的 `value` 和 `copyPolicy`
   为准；不得发明 `action`、`drawing`、`sheet`、`base_name`、`reference_files` 或 snake_case 字段。
2. 以下精确清单规则仅用于已确定的设计，不是自然语言制图的前置条件。将已有几何、尺寸、视图、
   图纸、标题栏、表格、剖面线和制造标注绑定到稳定语义 ID。
   完整 `exactEntities` 已包含对象和尺寸，省略重复的 `requiredEntityIds`、`requiredDimensionIds`
   和 `exactEntityTypes`，由 CLI 从同一清单生成；显式指定页序时例外，按下文规则本地计算完整索引。`exactEntityTypes`
   不是局部类型提示，而是整份顶层实体 ID/类型清单：只有连同模型为完成设计所需的轮廓、文字和
   辅助实体都已完整确定时才发送。只有实体全部属性也已确定且无需猜测时才使用 `exactEntities`。
   常见二维完整示例见
   [二维请求示例](portable-exact-common-2d.example.json)。
   复测 LLMRouter/工业档案时，原始用户指令、源文件字节、用户模型和交付格式是复测输入；历史
   Agent 派生的 `requirements`、`exactEntities`、`templateContext` 或修复稿
   只能作为故障证据。只有档案带有用户提供或确定性提取的来源证明，且按当前 Schema 重新验证完整
   后，才可进入新请求。不得把旧候选输出当用户事实，也不得为了让旧请求过预检而静默删改真实用户
   约束；应从原始事实构造一份当前版本请求。
   主视、俯视、侧视、剖视和局部详图必须绑定真实模型空间几何及其实际使用的锁定视口，不能只放视图名称。
   视口数量、布局数量与比例以用户要求为准；用户指定单视口时，多视图和明确要求的放大节点共用该视口；
   剖面线的 `boundaryIds` 必须引用本次请求中的真实闭合轮廓。使用 `mechanicalIntent` 时，每个
   `targetSemanticIds` 都指向本次意图中的真实 feature/profile，剖视/详图的 `parentViewId` 指向
   已声明视图；不得把同一轮廓重复贴到多个方向后冒充投影已经完成。
3. 二维制图使用 `generate` + `draw`，设置当前 Schema 支持的文档要求、输出格式和安全相对文件名。
   自然语言设计提交原始 `instruction`、真实源文件和交付要求；云端生成设计参数与对象关系，
   编译器展开工程构件并在同一 Job 内继续未完成步骤。Agent 不必先枚举全部底层图元。
   用户已给出的数值不变，推导和自主设计选择另记来源。未知项只有在会改变工程结果且无法合理
   确定时才集中澄清。已有完整精确设计可写入 `exactEntities`；不需要规则驱动机械计算时省略
   `mechanicalIntent`，不重复手填必需对象和尺寸索引，不将部分精确清单声明为已完成的整图。
   不以猜测源文件内容、删减需求或占位图替代设计。包含样条、剖面线、角度公差、标题栏和焊接符号的完整
   写法见 [高级实体请求示例](advanced-exact-entities.example.json)。保留用户或当前项目选定的标准；
   尚未选定标准且未要求正式符合性时才使用 `enterprise`，不得借此绕过已要求的规则，
   也不得宣称 GB/ISO 审核通过或虚构标准版本。

   原附件观察通过顶层 `sourceObservations` 传递，不拼入原始 `instruction`。精确设计的
   分片、阵列、坐标引用、页序、尺寸测量和局部排版统一见
   [来源、精确设计与纸面组合](natural-language-intake-and-evidence.md)。只修改拥有者参数，
   由当前 CLI 计算依赖并沿同一 validate/generate/revise 链执行；保留已完成对象和真实来源。
   自然语言请求由云端构造工程对象，不要求 Agent 手工重算标题栏列宽、引线或注记包络。
   当前 `schema` 是字段与能力的权威，参考示例只用于理解表达，不能变成额外设计条件。

4. 使用机械语义编译和规则验收时，按当前 CLI Schema 准备完整 `mechanicalIntent`，示例仅用于
   理解字段，不代替当前需求。标准计算或符合性声明绑定项目选定版本和适用规则；仅对当前
   计算或验收所需的材料、工艺和机床能力补充证据。一般标注不因此要求全部工艺资料。
   不要把知识包 JSON 冒充 `mechanicalRulePackFiles`。修订使用 `patch` 和当前 Schema 要求的
   注册图纸源，保留原文件并创建新版本。
5. 新建图、设备布置、厂房规划及专业网络按第 3 条提交原始需求与已有设计。设备外形、接口、
   通道、隔离和线路来自当前需求、源图或明确注明的设计选择；不把示意
   尺寸冒充厂商数据，也不自动补入用户未要求的专业、设备或连接。
6. 对既有底图的完整增补，使用同一 `exactEntities` 合同，将唯一底图的 sourceFiles role 设为
   `drawing`，其余资料设为 `reference`。CLI 按角色和 SHA 读取并绑定原图上下文；清单只包含全部
   新增实体，不重画原对象或猜造块。验收核对原图加新增实体的数量、源对象和样式保留、保存重开
   及最终 PDF。需要删除或修改既有对象时使用 `patch` 与具体事务。派生清单和来源观察单独记录，
   不倒写为用户原话，不以档案中的旧候选代替本次 Agent 设计。

### 按需查询图元合同

`exactEntities.<id>` 使用 `{ "type", "layer", "properties" }`。必填项、枚举、适用的关联字段
与约束以当前安装的 CLI schema 为准，不根据其他 CAD 库猜测，也不加载与当前设计无关的类型。

需要机器可读字段时查询对应实体，例如：

```text
cad-cli schema generation-request --entities polyline2d,dimLinear,dimAngular --json
```

响应中的 `requestEnvelope` 包含公共输入字段，`entityProperties` 和 `$defs` 包含选中类型及其依赖。
据此直接构造请求，无需逐个再查 kind、model、sourceFiles、outputs 或文档设置。
`unknownEntityTypes` 非空时按 `availableEntityTypes` 修正类型名；同次返回的有效合同仍可使用。
不要只查询泛化的 `/$defs/exactEntity` 后猜测 `properties`。

实体样式的可用字段与枚举从当前实体 Schema 查询；省略时继承图层。打印颜色使用当前
`plotSettings` 合同。保存重开后核对实际颜色与线宽，不依靠图层名称或旧版类型清单推断能力。

手工提供精确图元时，按上述 Schema 查询其文字对齐、尺寸、公差、曲线及填充边界字段。
自然语言设计使用编译器展开对象关系；这里不另维护一套字段禁用、默认值或构造规则。
字段用法问题依据工具诊断修正，只有无法从需求和附件确定的设计决定才向用户澄清。

## 唯一执行路径

若 Agent 宿主只允许写入实际 Skill 目录，自动在 `$SKILL/.work/<task-id>/` 使用稳定任务目录，
把预检、Grant 和最终产物都写在其中并直接交付。不得尝试越过宿主沙箱，也不得因为目录已存在
而创建第二次付费规划请求。

把 UTF-8 请求 JSON 通过标准输入交给下列命令。Windows PowerShell 5.1 的默认原生管道
使用 ASCII，会在 CLI 收到输入前把中文替换成 `?`；JSON 仍可能合法，`valid: true` 不能
证明需求文字没有损坏。在 PowerShell 中显式读取 UTF-8，并在整个调用区块设置和恢复编码：

```powershell
$cadRequestJson = Get-Content -LiteralPath $cadRequestPath -Raw -Encoding UTF8
$cadInvoker = Join-Path $cadSkillRoot 'scripts/invoke-cad.ps1'
$cadSavedPipeEncoding = $OutputEncoding
$cadSavedConsoleEncoding = [Console]::OutputEncoding
try {
    $OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    [Console]::OutputEncoding = $OutputEncoding
    $cadValidationJson = $cadRequestJson | & $cadInvoker -PackageDigest $cadPackageDigest `
        -CommandArgs @('validate', '--request', '-', '--output', $cadGrantPath, '--json')
    if ($LASTEXITCODE -ne 0 -or ($cadValidationJson | ConvertFrom-Json).valid -ne $true) {
        throw "CAD request validation failed; inspect the validation result before generation."
    }
    $cadRequestJson | & $cadInvoker -PackageDigest $cadPackageDigest `
        -CommandArgs @('generate', '--request', '-', '--output', $cadGrantPath, '--progress-jsonl', '--json')
} finally {
    $OutputEncoding = $cadSavedPipeEncoding
    [Console]::OutputEncoding = $cadSavedConsoleEncoding
}
```

`$cadSkillRoot` 使用本次实际加载的 Skill 目录，`$cadPackageDigest` 使用更新检查返回的
`localPackage.packageDigest`；请求和产物路径来自当前任务。`revise`、`plan wait` 和其他
传入中文的命令也使用同一入口和编码区块。通过 Python 等宿主执行时，仍调用包内入口，
向其 stdin 写入 `json.dumps(request, ensure_ascii=False).encode("utf-8")` 字节；
不得直接执行缓存的 `.exe` 跳过当前包及 Runtime 校验。发送前对照原始需求检查本地 JSON；
已变成问号的文字必须回到原始输入恢复，不能从模型生成的猜测反推用户要求。

命令形式：

```text
cad-cli validate --request - --output <execution-plan.json> --json
cad-cli generate --request - --output <execution-plan.json> --progress-jsonl --json
cad-cli plan clarify --request - --output <execution-plan.json> --reason <Agent判断> --question <合并问题> --json
cad-cli plan resume --job <jobId> --decision continue --user-input <用户补充> --json
cad-cli plan wait --job <jobId> --request - --output <execution-plan.json> --progress-jsonl --json
cad-cli revise --from <上一轮产物引用> --request - --output <execution-plan-r2.json> --progress-jsonl --json
cad-cli draw --grant <execution-plan.json> --output-dir <目录> --progress-jsonl --json
cad-cli edit --grant <execution-plan.json> --output-dir <目录> --progress-jsonl --json
cad-cli inspect --input <drawing.dwg|drawing.dxf> --output <inspection.json> --preview <preview.svg> --progress-jsonl --json
cad-cli inspect --input <drawing.dwg|drawing.dxf> --preview <regions.pdf> --preview-regions <regions.json> --progress-jsonl --json
cad-cli audit --input <drawing.dwg|drawing.dxf> --plan <audit-plan.json|-> --progress-jsonl --json
cad-cli convert --grant <execution-plan.json> --output-dir <目录> --progress-jsonl --json
```

新设计使用 `generate`，明确续改使用 `revise`；两者都必须先执行只读 `validate`。只有回执
`valid: true` 才能调用可能计费的规划入口；若预检失败，
只修正回执指出的字段，不得用删除 `exactEntities` 或 `mechanicalIntent` 的方式绕过契约。

`CAD_EDITABLE_DRAFT_READY` 表示图纸已成功保存回读并交付，退出码 0、`ok: true`、
`stage: draft`；先向用户提供可编辑图纸和已完成的 PDF，再在同一项目中处理剩余事项。
原始需求、签名待办和实际未完成的输出继续保留，不用评分、复核不可用或未知偏好阻止
已有工程图纸交付，也不把草稿成功说成所有要求或制造施工审核均已完成。

所有写入后端必须验证同一份签名 Grant。知识检索只能形成结构化工程意图和规则输入，不能直接
写几何或绕过 Plan Grant。不得改用临时脚本、直接 CAD 自动化或手写第二套 Schema。

所有可能长时间运行的规划、写入、修改、解析、审计和转换命令都必须带 `--progress-jsonl`，并按
[统一 Agent 长任务事件](agent-task-events.md) 消费事件。CLI 每 20 秒重复最近真实阶段的心跳；最近
心跳仍在 45 秒窗口内时不得把进程判为卡死，也不得启动第二次付费请求。细阶段一旦出现，后续
轮询不得退回 `cloud_engineering` 等笼统兼容阶段。
只有进程退出后的最终 stdout JSON 才能授权下一步。服务端失败必须透传 `validationRule`、
`instancePath`、`failingArtifact`、`checkpointId`、`remainingFindings` 和可执行恢复动作。

## 结构化回执

- `completed`：进入 `SKILL.md` 的交付前质量闭环。
- PDF 的视觉结论以最终文件实际渲染的页面为依据。内容流可能包含嵌套坐标变换、字体矩阵和
  字形定位，未完整解析这些变换的原始数值不能证明文字错行、孔变椭圆或打印比例失真。
  比例疑点需将最终页面上的实际物理尺寸与原生回读尺寸、视口比例及标题栏逐项比较；
  不为核验重复制图。仅文字提取异常而真实页面正常时，不把提取异常当成图纸缺陷。
- `needs_user_input`：向用户展示 Agent 已提出的问题；保持同一 job，等待 Agent 选择 continue、
  assume 或 cancel，不将等待当作失败、卡死或自动重试依据。
- `invalid`：只修正回执指出的输入字段。
- `failed`：按“失败后的修正与澄清”继续处理用户任务；说明简短原因、实际费用和下一步，
  不暴露凭据、receipt、堆栈、内部路径或把未验收产物当作交付。
- 只读检查主流二维 DWG 时可调用 `inspect --input <drawing.dwg> --preview <new-preview.svg>`；
  只有实体几何确实解码成功才返回 `CAD_OK`，SVG 与哈希在结构化 `artifacts` 中返回。结构损坏、
  仅识别文件签名或没有可检查二维几何时按失败处理，不得把空摘要或空预览交给用户。
- `generate` 结果不确定时不得自动重发；先按同一 job、检查点和产物证据对账。没有可持久化签名 Plan
  与结果产物也可能已经产生模型费用，必须先核对账务终态，不能直接新建重复任务。
- 大图按需查看清晰区域时，`regions.json` 为 `[{"name":"区域名称","min":[x0,y0],"max":[x1,y1]}]`。
  坐标采用原图模型坐标及单位；从原生实体或已检查的范围取得，不凭截图猜比例。每个区域生成一页
  PDF，边界相交的内容按窗口裁切。一次支持 1–256 页；更多区域分批读取。回执 `preview-regions`
  诊断绑定源文件与 PDF 哈希，逐页列出窗口和实体计数，并报告范围外实体及完整模型覆盖状态。
  区域预览不包含纸空间；局部通过不能算全图通过。按原始需求检查所有相关页、局部及范围外内容。
- CLI 的云请求绕过系统代理并设置连接与总超时。网络不可用时按一次结构化失败处理；不要因
  Clash、代理或证书错误无限等待，也不要在结果不确定时自动重发付费规划。
