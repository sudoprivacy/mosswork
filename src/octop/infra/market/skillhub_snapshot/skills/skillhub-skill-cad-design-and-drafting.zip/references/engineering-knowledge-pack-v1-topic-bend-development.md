---
{"id":"bend-development","summary":"折弯展开、K 因子、内外尺寸与回弹：先确定工艺再计算","claimKind":"manufacturing-method","revision":"1.1.1","reviewedOn":"2026-09-10","reviewAfter":"2027-03-10","scope":"supplier-advisory","sources":[{"publisher":"Protolabs","url":"https://www.protolabs.com/resources/design-tips/the-basics-of-bend-radii-in-sheet-metal/","section":"The K-factor; Setbacks and Bend Allowances","edition":"web-page-undated; checked 2026-09-10"}],"conditions":["均匀板厚、明确弯曲角及半径定义","K 因子由当前材料、模具和弯曲工艺核准，不采用软件默认值证明下料准确"],"quantities":[],"requiredInputs":["thickness","insideRadius","bendAngleConvention","approvedKFactor","dimensionConvention","material","tooling","bendingProcess","bendDataApproved"],"evidenceClass":"supplier-advice","applicability":[{"key":"thickness","exclusiveMinimum":0,"unit":"mm"},{"key":"insideRadius","minimum":0,"unit":"mm"},{"key":"bendAngleConvention"},{"key":"approvedKFactor"},{"key":"dimensionConvention"},{"key":"material"},{"key":"tooling"},{"key":"bendingProcess"},{"key":"bendDataApproved","oneOf":[true]}]}
---
# 折弯展开

K 因子表示中性层距内表面的距离与板厚之比。展开补偿随材料、板厚、内半径、角度及弯曲方式变化；供应商为自有设备校准的值不能移植成默认值。

以下为按中性层圆弧定义推导的几何计算：转角 θ 用弧度，板厚 t、内半径 R 同单位，则弯曲段展开长度 `BA = θ × (R + K × t)`。
对于 90° 转角，外侧退距为 `R + t`；按外侧虚交点尺寸求下料时，折弯扣除定义为 `BD = 2 × (R + t) − BA`。
必须记录“转角”与“内夹角”的区别及正负号定义，不能仅复制某页面的 bend deduction 名称。

成形视图的外尺寸、内尺寸和展开图总长描述不同的几何量。上述展开关系本身不证明回弹、最小弯曲半径或材料不开裂；缺少当前工艺的 K 值时，下料尺寸不能由该关系唯一确定。
