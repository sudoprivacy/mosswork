---
{"id":"weld-distortion","summary":"焊接定位、接头间隙、分段与平衡顺序；避免把建议当焊接规程","claimKind":"manufacturing-method","revision":"1.1.1","reviewedOn":"2026-09-10","reviewAfter":"2027-03-10","scope":"process-advisory","sources":[{"publisher":"TWI","url":"https://www.twi-global.com/technical-knowledge/job-knowledge/distortion-control-prevention-by-fabrication-techniques-036","section":"Tack welding; Welding sequence; Best practice","edition":"Job Knowledge 036; web revision undated; checked 2026-09-10"}],"conditions":["焊接装配的变形控制候选方法","具体接头、材料和承载要求须由已批准焊接规程覆盖"],"quantities":[],"requiredInputs":["jointGeometry","weldProcedure","material","fixture","weldingSequence","inspectionDatum","weldProcedureApproved"],"evidenceClass":"engineering-fact","applicability":[{"key":"jointGeometry"},{"key":"weldProcedure"},{"key":"material"},{"key":"fixture"},{"key":"weldingSequence"},{"key":"inspectionDatum"},{"key":"weldProcedureApproved","oneOf":[true]}]}
---
# 焊接与变形控制

定位焊用于保持装配位置及接头间隙。长焊缝采用适当的分段、退焊或跳焊顺序，以及围绕中性轴的平衡焊接，可作为降低变形的工艺候选。
退焊的短段施焊方向与总体推进方向相反；跳焊按预定间隔安排短段。两者不能混为一条连续同向焊缝。

图纸应区分最终焊缝要求与施工顺序：分段施焊不等于允许最终焊缝不连续。
不要从示意图推定焊脚、坡口、预热温度、焊材或检测等级。定位、夹具及施焊顺序也不能替代接头强度或焊接工艺评定。

装配间隙、基准与焊后尺寸属于几何检验对象；几何关系成立不能单独证明焊接变形预测、残余应力或工艺合格。
