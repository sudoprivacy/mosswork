---
{"id":"bearing-fit","summary":"轴承配合与初始、安装后、运行游隙的区别；温差及过盈的影响","claimKind":"selection-condition","revision":"1.1.1","reviewedOn":"2026-09-10","reviewAfter":"2027-03-10","scope":"supplier-advisory","sources":[{"publisher":"NSK","url":"https://www.nsk.com/tools-resources/abc-bearings/fits-and-internal-clearance/","section":"Fits; How Clearance Decreases","edition":"Bearing ABCs chapter 7; web revision undated; checked 2026-09-10"}],"conditions":["滚动轴承选型与安装配合","具体轴承型号、载荷方向、材料及工作温度须核实"],"quantities":[],"requiredInputs":["bearingDesignation","shaftLimits","housingLimits","loadDirection","initialClearance","operatingTemperatures","material","fitSelectionApproved"],"evidenceClass":"supplier-advice","applicability":[{"key":"bearingDesignation"},{"key":"shaftLimits"},{"key":"housingLimits"},{"key":"loadDirection"},{"key":"initialClearance"},{"key":"operatingTemperatures"},{"key":"material"},{"key":"fitSelectionApproved","oneOf":[true]}]}
---
# 轴承配合与游隙

轴孔配合控制套圈与轴/座孔之间的尺寸关系；轴承内部游隙是套圈与滚动体系统的另一项属性。
NSK 区分安装前初始游隙、安装后剩余游隙和运行时有效游隙。过盈装配引起套圈变形，内外圈温差也会改变运行游隙。

不能以“轴孔没有几何重叠”证明轴承运行正常，也不能给所有轴承统一选择 H7、k6 或 C3。
先核对轴承型号、载荷旋转关系、温度、材料、安装和轴向定位方式，再采用厂家对应表格及当前项目要求。

对于已明确上下偏差的孔轴配合，孔径区间减轴径区间得到最坏间隙区间。
负区间表示几何过盈，跨零表示可能间隙也可能过盈；这不等于套圈应力或运行游隙已核准。缺少公差不能按零偏差计算。
