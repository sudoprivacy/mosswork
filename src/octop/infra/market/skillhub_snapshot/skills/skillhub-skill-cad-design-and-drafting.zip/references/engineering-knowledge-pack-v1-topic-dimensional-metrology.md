---
{"id":"dimensional-metrology","summary":"尺寸测量温度、热膨胀与不确定度；公差不等于测量能力","claimKind":"technical-requirement","revision":"1.1.1","reviewedOn":"2026-09-10","reviewAfter":"2027-03-10","scope":"metrology-reference","sources":[{"publisher":"NIST","url":"https://emtoolbox.nist.gov/faq/faq.asp","section":"What temperature and humidity should I keep my dimensional metrology lab?; CTE","edition":"Engineering Metrology Toolbox FAQ; checked 2026-09-10"}],"conditions":["尺寸计量参考温度的解释，不是当前项目规范版本的认证","热膨胀修正需当前材料及温度区间的系数和不确定度"],"quantities":[{"name":"dimensional-reference-temperature","minimum":20,"maximum":20,"unit":"degC","sourceIndex":0}],"requiredInputs":["drawingReferenceTemperature","measurementTemperature","materialExpansionCoefficient","measurementUncertainty","measurementDataApproved"],"evidenceClass":"engineering-fact","applicability":[{"key":"drawingReferenceTemperature","minimum":20,"maximum":20,"unit":"degC"},{"key":"measurementTemperature"},{"key":"materialExpansionCoefficient"},{"key":"measurementUncertainty"},{"key":"measurementDataApproved","oneOf":[true]}]}
---
# 尺寸计量的温度与公差

NIST 解释了工业尺寸计量的 20 °C 参考温度及偏离参考温度时的热膨胀修正。
图纸明确的其他参考条件优先。知识中的 20 °C 不是用户已承诺的现场温度，也不证明某版标准符合性。

在系数近似恒定的区间，线膨胀可按 `ΔL = α × L × ΔT` 估算；α 用 1/K，温差用 K，L 与 ΔL 使用同一长度单位。
这是物理关系的计算展开，系数必须取当前材料状态和温区的数据，并考虑其不确定度。

上下公差定义允许尺寸区间，量具分辨率、测量不确定度与机床定位精度各有不同含义，不能互相替代。
图纸中的尺寸及偏差描述设计要求，不等于现场温度、量具能力或实际制件的测量结果。
