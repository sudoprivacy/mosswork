# Project-local source reuse

Load this reference only when the user explicitly supplies a template, an existing drawing, or a
reference file.

- Register project-local DWG, DXF, DWT, PDF, or PNG inputs in the generation request's current
  `sourceFiles` field, using the exact role and format returned by the CLI schema.
- To add a new design to one supplied template while preserving its contents, use
  `kind: plan`, `command: draw`, and one `drawing` source. Local request assembly also
  resolves an unambiguous `template` source to this existing source-preserving addition
  path. It retains the file, instruction, outputs and exact geometry. Multiple editable
  sources remain ambiguous; mechanical intent retains its own source-mode compiler.
- For standardizing an existing customer drawing, use `kind: patch` with `command: edit` and
  assign that drawing the `drawing` role. A separate company drawing used only for its frame,
  title block or style definitions is a `reference`. Inspect both sources locally and bind the
  requested changes to exact source objects. The editable base must contain the engineering
  content that the user asked to preserve; do not start from an empty company frame and ask the
  model to recreate thousands of customer entities.
- A correction is a complete revised drawing created as a new revision; in-place source editing is
  not exposed.
- Keep original sources read-only. Use an isolated task output directory for generated artifacts.
- Reuse customer assets only when the customer explicitly provided them and accepted the
  relevant frame, styles, table layout or parameterized design for this project. A drawing
  supplied for reference alone is not an approved template. Keep each customer's assets local;
  never turn private drawings into public templates or automatically run `library promote`.
- If several candidate sources are genuinely tied, ask the user to choose; do not select by path
  order, filename, or a hidden score.
- If an optional reference is unavailable, continue from zero. If it is mandatory, report the
  missing source and wait for the user.
- Never scan unregistered directories, upload a whole drawing library, expose source contents in
  diagnostics, or infer exact edit handles from a third-party drawing.

The CLI decides how to inspect, validate, bind, and reuse the source. The Agent supplies the user's
complete drawing specification and project-local reference path through the public `cad-cli`
generation request.

## Repeated use within the same project

Use the existing `library` commands for an explicitly supplied asset directory. Register it
read-only with `library add --source-id <local-id> --uri <file-uri> --scope project-<projectId>
--deep-index`, then run `library scan --source-id <local-id>`. Do not register a directory that
contains unrelated customer material. The project ID and approval reference are opaque local
labels, not customer names or document contents. Use a project ID of 1–56 lowercase letters,
digits or hyphens, starting with a letter or digit; `project-` scopes are reserved for private
project reuse.

Use `schema library-reuse` to discover the current context and its `$defs/declaration` contract.
After inspecting the source and recording the customer's acceptance, add a `reuse` declaration
to that file's existing entry in `template-metadata.json`. It has these fields:

- `schemaVersion: 1`, `projectId`, `sourceSha256` (the inspected file's exact lowercase SHA-256),
  and `approvalRef` (a reference to the customer's actual acceptance; never invent acceptance).
- `uses`: the accepted subset of `drawingFrame`, `styles`, `tableStyle`, `parametricDesign`.
- `parameters`: named applicability ranges, each with `unit`, `min`, `max`. Use `{}` for an asset
  with no applicable numeric parameters. A `parametricDesign` must declare its parameters.
  Ranges come from reviewed design applicability, not guesses from the example's dimensions.

Rescan after changing acceptance. Search only the current project scope. `search` uniqueness,
`compare` scores, matching names and a hash-bound semantic map do not approve a design or prove
it fits the customer's requirement. Style comparison covers inspected layer properties, font
references, text and dimension styles; it does not certify font availability, table styles or
engineering suitability. Review the actual asset and read-back evidence for those properties.

For each reuse, write a small local context JSON containing `schemaVersion: 1`, `projectId`,
`purpose` (one accepted use), and `parameters` with every applicable name explicitly set to
`{"unit": "<declared unit>", "value": <current project value>}`. Pass it with
`library derive --source-id <local-id> --resource <relative-file> --output-dir <new-directory>
--reuse-context <context-json> --json`.

The CLI checks scope, acceptance, source hash, purpose, units and parameter ranges before
copying. It copies exact bytes and writes their provenance plus the selected context alongside
the working copy. This is a reference asset, not a finished deliverable or a parameterized
result: a plain derivation does not resize the copied master.

For a new drawing that must use an explicitly requested original frame, inspect the native
block name and use `library extract --source-id <local-id> --resource <relative-file>
--block <original-block-name> --output-dir <new-directory> --reuse-context <context-json> --json`.
This uses the same project, acceptance and hash checks as `derive`; it retains selected native
definitions and their dependencies, removes unrelated drawing entities, and verifies the saved
asset by reopening it. The customer's explicit instruction to use that frame is a valid source
of acceptance for that use; it does not approve unrelated sample designs or cross-project reuse.
Inspect the extracted asset, use it as the new drawing's `drawing` source with `kind: plan`
and `command: draw`, and keep the original reference available. The ordinary generation flow
binds its measured context and adds the requested engineering design while the native transaction
preserves the source baseline. An asset containing only unplaced definitions is not an existing
engineering design; do not search it for the new pipes, parts or labels being requested. Insert
the original block by name with explicit placement and scale;
do not redraw an approximation with the same name. Definitions alone are not a placed frame.
For continuation of an existing engineering drawing, keep that actual drawing as the editable
base instead. Check native member preservation and every printed page after applying the frame.

If the inspected frame or title table is made of ordinary entities rather than a named block,
use the same `library extract` command with repeated `--entity <native-handle>` selections.
Select the exact top-level entities shown by `inspect`, together with their required frame/table
members; do not infer handles from names or select unrelated customer geometry. This mode keeps
their original model/paper placement, preserves dependency and style resources, and verifies the
selected native entities after saving and reopening. Space markers, viewports, nested block
members, duplicate handles and missing dependencies reject; select a block by name for its full
definition. The same project, purpose, acceptance and source-hash checks apply. Inspect the
derived asset before use, and replace prior drawing titles, numbers and values through the normal
generation/edit flow under the current request. Extraction alone is not a new design delivery.

For `parametricDesign`, the accepted declaration must also contain `application`:
`resource` names a JSON generation-request template inside the same registered source,
`sha256` binds its exact bytes, and `bindings` maps every declared parameter to distinct
existing properties under `/requirements/exactEntities/<id>/properties/` or
`/exactEntityArrays/<index>/pattern/`. Bindings cannot overlap.
The template references only this asset in `sourceFiles[0].path` by its relative resource
name. It must not carry a previous task, preview or external entity fragments. Supply the
full current customer `instruction` in the reuse context; template instructions are replaced.
Linear geometry/table sizes accept explicitly named `mm`, `cm`, `m` or `in`: the CLI
converts to the declaration unit before checking its range, then to the drawing unit.
Angles require `deg`; arrays also support spacing, center coordinates and angles.
Use `unit: count` with inclusive positive integer bounds to bind the same quantity to
`/exactEntityArrays/<index>/pattern/count` and the corresponding BOM row cell. The existing
array kernel expands editable geometry and the bound table cell receives the same integer.
Use `{"unit":"choice","choices":["approved choice A","approved choice B"]}` only for
customer-reviewed alternatives, and supply `{"unit":"choice","value":"approved choice A"}`
in the current context. Bind these to `dbText`/`mText` values or BOM row cells together.
Choices outside that list, fractional counts, incompatible units and out-of-range values
are rejected before writing. A process note is not proof that its machining geometry is
implemented: bind geometric parameters too and verify them in the ordinary delivery chain.
Missing choices, quantities and manufacturing requirements are never supplied as defaults.

`derive` applies these explicit values, validates the ordinary CAD request and writes
`<asset>.generation-request.json` plus its hash in the provenance sidecar. Existing
`$ref`/`$calc`/`$area` dependencies remain in the request and are recalculated by the same
generation pipeline. Submit that prepared request through the ordinary generation/edit
flow; `request_prepared_not_executed` is not a modified drawing or a completed delivery.
Missing approval/bindings, stale template bytes or invalid parameters stop before writing.

Continue through the existing `inspect` → `sourceFiles` → generation/edit → delivery workflow.
Carry the current parameter values into the design and its linked dimensions, BOM and notes;
use the existing `$ref`/`$calc`/`$format` relations where applicable. Preserve the customer's
frame, layers, font references and table formatting; replace example identifiers, dimensions,
quantities, materials and process instructions with the current project's actual requirements.
Do not retain a sample's manufacturing requirement merely because it is present in the asset.
Reopen the outputs and check the applied parameters, drawing/BOM/notes agreement and print
layout. A preserved font reference still needs the font available for rendering.

For area schedules, keep the requested target and the measured closed-boundary area distinct.
Bind the plan label, schedule cell and difference from target to the same `$area` value; changing
the boundary must update all three. Do not count a disconnected room, corridor or buffer as part
of another functional room merely to make the total reach its target. Where usable/net area needs
wall, column or equipment exclusions, an enclosing boundary alone does not prove that area.
For simple closed straight XY polyline boundaries, including slanted walls and concave rooms,
use `$area.excludeEntityIds` with up to 64 explicit model-space occupancy boundaries (1024 total
edges and 4096 intersection events). The local resolver clips each occupancy to the room and
subtracts their union, so overlapping/outside columns are not counted twice. Curved, nonplanar
or excessively complex deductions still require independent calculations; do not substitute
bounding boxes or omit an occupancy merely to fit the limit.
Keep a shortfall visible and revise the actual layout under the original requirements.

Build the area program from every original requested function before comparing the proposed
schedule. Include missing functions explicitly; a schedule containing only the rooms already
drawn is not complete coverage. For declared deductions, use verified source placements and
the existing geometry dependencies to subtract actual intersections, without double counting.
Label precisely what has been deducted; column deductions alone do not establish usable area
after new walls, equipment or other exclusions. Check the actual passage against retained
obstacles and its connections, not only two parallel lines or a width label. If two requested
rooms must combine, prove adjacency while preserving required circulation; retain a concrete
conflict as a pending design decision rather than quietly changing the user's program.

Native tables use their actual insertion and row direction. Inspect the complete table extent
on every paper layout, including first/last rows, then reopen the DWG and export again. A table
outside the paper must move or split without shrinking below readable text; matching clipped
PDFs do not establish complete printable delivery.

For declared pipe or wire connections, bind `requirements.spatialRelations` entries with
`kind: endpointConnection`, `first` and `second` native selections (`geometry: boundary`),
`endpoint: start` or `end`, and an explicit positive drawing-unit `tolerance`. The first selection
must resolve to one open path. Bind each required branch to its actual intended parent path;
an interior crossing or a nearby label does not prove a connected endpoint. Reopen and audit the
delivered drawing, feed measured gaps back into the ordinary revision flow, and rerun the same
connections after repair. Do not increase tolerances or omit failed branches to pass the audit.
This verifies geometric attachment only; pipe sizing and system performance need their own
engineering evidence. Use the existing `connectedRoute` contract for circulation routes.
It checks continuous native straight or curved routes against explicitly selected regions
and obstacles. Curve approximation errors are deducted from certified clearance; ambiguous
endpoint membership does not pass. Set `maximumLength` when the project declares a travel
limit; the report compares a conservative native route length with that limit.
For each required door or exit opening, add `passages: [{"opening": <boundary selection>}]`.
Select an actual straight clear-jamb segment, not the door leaf or a width label. The route
must cross it with half the required width available to either jamb; a wide opening elsewhere
does not pass. Passage traversal currently requires a straight-segment route, so curved chord
approximations cannot silently certify a doorway.
An optional passage `headroom` is an ordinary `dimensionRange` with native section/elevation
dimension terms, positive minimum, explicit maximum and project-specific basis. It measures
the actual dimensions; a text assertion or ratio is not accepted as headroom. Declare door
swing occupancy as actual obstacle regions and retain the required exit region as `endRegion`.
Reopen both DWG and DXF and rerun the complete relation. These checks do not find routes,
infer unprovided obstacles or exit suitability, or establish statutory egress compliance.

When changing an existing fill pattern, retain the fill and its boundary rather than deleting
the fill to remove an obstruction. A writer advertising `cadHatchPatternEdits` can update an
ordinary non-gradient HATCH's `patternName`, `angle`, `scale` and ACI `colorIndex` in the same
count-guarded `updateProperties` operation. The shared pattern constructor supplies only its
supported definitions; unknown custom patterns need their actual source definition and a
supported explicit replacement. Reopen the file to check both pattern lines and furniture/text
visibility. Gradient and MPOLYGON fills remain outside this edit subset.

`CAD_LIBRARY_REUSE_REVIEW_REQUIRED` means this candidate needs review; retain the task and its
current revision. Correct Agent-supplied context mistakes from known requirements, choose another
accepted asset, or continue from scratch when the reference is optional. Ask the customer only
for a genuinely missing design decision or acceptance. A mandatory reference remains pending.
Cross-project reuse is deliberately not enabled by this declaration; review its applicability
and customer permission separately before introducing that workflow. Local sidecars record
provenance and applicability; they are not a security boundary against someone editing files.
