# Natural-language intake and evidence contract

Load this reference for every concrete drawing creation or revision. Keep the conversation natural;
the user never needs to write semantic IDs, schemas, or CLI arguments.

## Decide whether to proceed

- Proceed when explicit common 2D geometry and requested outputs are sufficient.
- For an open design, determine routine nominal dimensions and reversible drafting choices within
  the user's delegated scope, and record their basis as design decisions. Ask one compact question
  only when an unresolved interface, source value or load condition changes the requested result
  and cannot be established from the current evidence or delegated design scope. Continue the
  independent drawing work and retain verified draft outputs while that item remains open.
- Use the supplied project standard and source drawing for routine fits, GD&T and manufacturing
  annotations. Ask for an edition/profile when formal conformance approval actually requires it
  and it cannot be established from the project evidence; this is not a prerequisite for drawing.
- Do not ask for an edition when the user explicitly excludes conformance approval. Use the
  `enterprise` document standard and describe the result as project drafting, not GB/ISO approval.
- Do not guess interface dimensions, safety factors, tolerance classes, datum systems, standard
  editions, process capability, or a motor frame from power alone.
- Resolve a coordinate origin and other reversible drafting choices from the request and source.
  Record inferred choices separately. Ask when competing interpretations change real design intent
  and the available evidence cannot resolve them; do not make arbitrary coordinate choices a gate.
- When explicit values cannot hold simultaneously, a requested source is absent, or the original
  text is unreadable, explain the concrete conflict or missing evidence and ask one grouped
  question about the affected item. Preserve the original values and existing files while awaiting
  the answer; continue independent content and exports when a faithful draft can be formed.
  Exact preservation applies to the named source content or user-fixed parameters, not to every
  new paper position, coordinate origin or other reversible drafting choice.
- Use the waiting-input flow in `agent-execution-contract.md` once the request can be represented
  faithfully. Repair an Agent-authored incomplete manifest from the original request and available
  compiler capabilities in the same task; it is not missing customer information. If a required
  absent source prevents any valid task, ask for that source without inventing it or calling
  generation merely to record the question. After the answer, update the same task input and resume
  the existing waiting job when one exists. A renderer, network or schema defect remains a
  technical problem to diagnose; do not relabel it as missing user information.

## Read source images and retain attributed observations

The Agent running this Skill owns image reading and final visual review. Use the host Agent's
image-viewing ability; do not select a cloud CAD vision model or assume that an uploaded file is
visible to the cloud planner. For DWG/DXF, use `inspect --input <source> --output <inspection.json>
--preview <source.pdf> --json`; PDF previews retain drawing pages, while SVG previews show model
space only. Open readable pages and relevant crops with the Agent's available viewing tools. Read
existing PNG/PDF attachments directly. Keep the original bytes and hash; do not infer contents from
archive summaries, filenames or unused block names.

Keep `instruction` as the user's original wording. An archive's `payload.instruction` is what a
previous Agent submitted to the CLI, not proof of the user's verbatim chat. When that original chat
is unavailable, retain this distinction in source observations; do not call an expanded dimension list user
authority merely because it is inside `instruction`. Read the original image and transcribe the
relevant marks before reconciling that transcription with any archived description. Correct a
prior Agent reading directly when the current source establishes the value, retain the old reading
and correction basis in the task evidence, and rebind affected features. Ask only when competing
authoritative sources or an unreadable mark leave a real design choice unresolved.

Record observations separately in the generation
request's `sourceObservations` array. Each observation contains `id`, `sourceSha256`, zero-based
`pageIndex` (0 for a PNG), a human-locatable `region`, `basis`, and `content`. Use `visible` for what
you actually read, `estimated` for approximate image measurements, `inferred` for interpretation,
and `unreadable` for unresolved details. Quote exact dimension text when legible and compare it
with native inspection values when available. A source hash binds identity; it does not certify
your interpretation. Do not promote estimates into manufacturing dimensions or original user
constraints. Keep the evidence concise: at most 64 observations and 64 KiB total; full native
geometry belongs in the existing inspection and design fields.

For drawing comparisons, include dimensions and tolerances even when the user only says "compare
these drawings". Inspect each dimension's raw `measurement`, `textOverride`, style and read-only
`dimensionPresentation`. Its `definitionText` includes native formatting, scale and overrides;
`blockText` records visible text saved in the referenced dimension block. These are separate facts:
equal measurements or entity counts do not establish equal printed dimensions. Compare the actual
pages and changed dimension blocks; unresolved block text means that part of the comparison remains
unverified. Do not dismiss a changed dimension block as harmless regeneration without checking its
visible text. Do not copy presentation evidence into authoring properties.

When supplementing source dimensions, establish the source view, coordinate space, native units and
the relationship between measured geometry and existing labels before placing a new dimension.
A scaled drawing or dimension text override can have a different number from its geometric length;
neither the entire drawing's bounding box nor screenshot pixels alone supply the manufacturing size.
Bind missing dimensions to the intended contour, hole, datum or thickness in that view. Keep separate
whether a dimension is absent, which feature it describes, and whether its value is actually known.
For image reconstruction, reconcile section depth, slope angles and visible/hidden edges across all
provided views before calculating coordinates; a shallow recess cannot become a through-cut merely
because its front outline is similar. Retain source styles and unchanged geometry during additions.

When adopting an exact source length, add `quantity: {"literal":"16.35","value":16.35,"unit":"mm"}`
to that observation. `literal` is the numeric token actually read, before conversion; it must equal
`value`. This example is syntax, not a default dimension.
Where readable, retain `measurementKind` (`length`, `diameter`, `radius`, `angle`), the original
`sourceText` including its symbol, and separately readable `upperDeviation` / `lowerDeviation`.
Do not turn a diameter into an axial length because the numeric value matches. Old observations
without a kind remain untyped; inspect the original region before correcting their interpretation.
Bind the adopted value to an existing `requirements.spatialRelations` `dimensionRange`: one native dimension term, coefficient 1,
`variation: "nominal"`, equal minimum/maximum after unit conversion, and
`basis.sourceRef: "observation/<id>"`. Preserve source identity/version and applicable conditions
in the basis. The CLI measures the actual geometry before generation and again after reopening.
Local assembly canonicalizes a bare sourceRef only when it exactly names a declared observation;
it never selects a dimension by a matching number or changes the source quantity. Use the canonical
reference in authored requests; direct cloud requests with a bare declared ID are rejected early.
For local authoring, prefer `sourceDimensionBindings: [{"observationId":"<id>",
"dimensionId":"<native dimension id>"}]` at the request root. Select the feature explicitly;
the CLI converts the visible source quantity to drawing units and constructs the existing
`dimensionRange` checks before any model call. Reference actual feature coordinates from the
dimension with `$ref`; a dimension drawn separately or a text label cannot prove that feature.
To construct that feature from the same attributed quantity, use
`{"$sourceQuantity":{"observationId":"<id>","unit":"mm"}}` as a numeric property or
`$calc` argument. For example, add an adopted depth to the feature's anchored Y coordinate,
then reference the resulting edge from its dimension and dependent partitions. The expression
requires the corresponding `sourceDimensionBindings` entry and converts the original visible
quantity explicitly (mm/cm/m/in, or deg for an angle). It does not copy a number from observation
prose or resolve an estimated value. Construction and native measurement consume the same fact;
changing the geometry is not replaced by merely rejecting a mismatching dimension afterwards.
One observation can bind corresponding dimensions in multiple views. The local recipe is removed
before submission; its compiled checks remain in the Plan and native readback acceptance.
Sparse revisions inherit omitted bindings. Repair the owning object's coordinates with
`exactEntityRevision`, retaining the source threshold and unrelated objects; do not lower a
threshold to make incorrect geometry pass. Explicitly replace bindings when feature identity changes.
An estimated or unreadable value cannot supply this exact threshold. Do not add quantities for
incidental source content or make every task fill a measurement inventory. Explicit user changes
have their own instruction basis; retain the original observation instead of rewriting history.
For a readable source angle, use `quantity.unit: "deg"` and bind the same nominal
`dimensionRange` to the native angular dimension with `basis.unit: "deg"`. This measures
the defining rays after generation and reopen, not the displayed text override. Lengths and
angles cannot be mixed or converted into each other. Angular tolerance intervals remain
unverified; a nominal angle check does not certify angular manufacturing tolerance.

If the host cannot display a needed image or detail, use its available visual tools or identify
the precise evidence that remains unavailable. Ask only for an essential unresolved source fact;
continue independent drawing content and retain a faithful draft. Do not repeatedly submit the same
request to a text model. Missing cloud pixels need no user action when the Agent's observations and
native evidence already resolve the task.

After generating, open every final PDF page and check it against the original sources and requirements.
For important source labels, transcribe the exact token, prefix, sign, decimal and unit into the
observation before interpreting its meaning. Reopen the original page/region during final review;
compare the original mark with the delivered label, not just with your earlier observation. Keep
unreadable details unresolved; do not draw the most likely value and defer confirmation to delivery.
Record the actual output hash and concrete defects, then revise the same design and recheck changed
pages plus affected relationships. Never call the cloud's text review an independent visual pass.

For generalization acceptance, start with the raw user request, original attachments and this Skill.
Do not read prior solutions, edited requests, prepared geometry or answer-specific scripts. The
evaluating Agent may compute its own design after observing the sources. Freeze the selected sample
and retain first-attempt results, clarification waits, technical failures, intervention, elapsed
time and actual engineering/visual outcomes; corrections do not erase initial failures.
Report generation, local execution, requested file delivery, engineering coverage and visual
review separately. A signed plan or readable draft can succeed at its own stage while the design
remains incomplete. Report correct clarification handling separately; it is neither a generated
drawing nor an execution failure. Keep every selected case in the outcome table, with explicit
denominators for all requests and requests whose necessary inputs are available. Historical cases
already used during development are regression retests; evaluate unseen requests separately.

## Submit original design requirements

For ordinary natural-language generation, keep the original instruction and attachments. Record
source observations and delegated design decisions separately. The executor selects the current
constructor contracts, and the shared kernel expands their geometry, related views and paper
composition. Do not rewrite the request into a second mandatory brief or build an exact entity
inventory before starting generation. The request workflow is in
[agent-execution-contract.md](agent-execution-contract.md).

## Assemble an already determined exact design

The following local fragments and calculations apply when the caller already has an exact design;
they are not a prerequisite for natural-language generation.

Query the contracts for the types actually selected by the design together, for example
`schema generation-request --entities polyline2d,dimLinear,layout,viewport,mText --json`.
The response includes their shared definitions, `localArrays` and `localReferences`; do not walk
every schema pointer or load unrelated representations. Store design parameters and supported
calculations in the local JSON request. Use the CLI's existing array and reference operations below
before writing helper code. A separate small calculation program is only needed for a specific
algorithm the existing local operations do not express; preserve its inputs and verify its result.

For large designs, write small JSON fragments in the output project directory and list their
relative paths in the **top-level** `exactEntityFiles` (JSON pointer `/exactEntityFiles`, never
`/requirements/exactEntityFiles`). Keep a fragment's geometry, notes and evidence together using
`{"entities":[{"id":"<ID>","type":"<type>","layer":"<layer>","...":"native fields"}],
"sourceObservations":[],"spatialRelations":[]}`. The two evidence arrays are optional and use
the existing request contracts; the CLI places them at the request root and in `requirements`,
respectively. Native entities use drawing-plan fields directly, including local references and
calculations; the CLI builds the exact-entity envelopes and derived indexes. An entity ID/object
map with the same entry shape as `requirements.exactEntities` is also accepted. Each file is at
most 256 KiB. A fragment cannot replace original instruction, units or outputs. Duplicate entity,
observation or relation IDs are errors, never implicit replacement. The CLI assembles the complete map
under the existing 4 MiB request limit before ordinary validation and generation. IDs may occur
in only one fragment or the inline map. Keep shared coordinates and supported calculations as local
references and expressions in the owning fragment; do not repeat the entire drawing after a local defect. Once all
fragments and required views are ready, validate the complete request and submit it once. This
is one design, not incremental server authoring or permission to omit unfinished obligations.

Before assembly, decide whether an attachment request means its entire subject or an explicitly
selected region. A highlight/crop is evidence of appearance, not by itself user permission to omit
other content. If the original wording leaves materially different scopes, ask one scope question
before constructing a complete design. Do not diagnose dimensional conflict from image aspect ratio
alone. During final review, compare authored notes and engineering settings back to original facts:
an unrequested tolerance class or process obligation cannot be certified as a harmless convention.
Remove an unnecessary added obligation locally; ask only when the engineering decision is needed.
Ordinary titles, readable layout and accurate captions for the actual print scale/units remain design
choices. The service's same coverage review returns affected object paths for unauthorized additions;
correct those objects, preserving verified geometry and the original evidence.

Use the same geometry for dimensions and connected entities. A local property can contain
`{"$ref":"#/requirements/exactEntities/outline/properties/vertices/0"}` instead of duplicating
that point. The CLI resolves numeric scalars and 2D/3D points after joining fragments, before
schema validation, measurement or paid generation. This is an RFC 6901 pointer into the same
request: escape `/` in an ID as `~1` and `~` as `~0`. References remain in the local input; only
computed values enter the signed request. Change the coordinate owner and regenerate to update
all its dependants. This does not create a persistent native association when editing a separate
DWG later. Derive geometry from source facts in the local calculation; a reference cannot establish
that an image transcription was correct.

For a critical measurable requirement, keep one explicit `dimensionRange` bound to the actual
feature dimension and the original instruction or observation. For example, a required rib depth
must measure endpoints referenced from the rib's section geometry; a plan-view pair of lines or
a note saying "depth 3 mm" cannot prove that depth. Thickness, hole diameter and edge distance
follow the same existing native measurement path. Do not derive the acceptance threshold from
the generated geometry: retain the user's value, unit and authorized tolerance. `validate` exposes
successful measurements in `geometry.spatialChecks`, including the requirement ID, measured and
required intervals, basis, and dimension selector; failures retain these object-specific findings.
Correct the named feature and recompute its dependants, then require native save/reopen acceptance.
These checks verify declared requirements only; separately review whether every critical original
requirement has a corresponding feature and check. They do not infer omitted requirements.

For a scalar derived from known geometry, use
`{"$calc":{"op":"add","args":[{"$ref":"#/requirements/exactEntities/outline/properties/vertices/0/0"},5]}}`.
The existing local resolver supports `add`, `subtract`, `multiply` and `divide`, each with exactly
two numeric operands; nested calculations and geometry references are resolved before validation.
Use the current `localReferences.calculationRule` for supported point calculations: `polar`
builds a point from an origin, true length and angle in degrees; `interpolate` binds a point
on an edge; `distance` and `project` distinguish true length from directional span. Bind
dimension endpoints to the actual feature using `$ref`, rather than copying calculated
coordinates. These operations do not identify features in a source image: a dimension arc
is not evidence of a circular part, and a projected span is not interchangeable with an
inclined edge length. Retain the original observation and check the visible feature first.

For a specified 1:30 viewport, use `{"$calc":{"op":"divide","args":[1,30]}}` for its scale
instead of truncating the fraction. A label height can divide the required paper height by a
reference to that scale. Keep units consistent and record any conversion explicitly. Calculations
do not infer dimensions, establish source truth or alter user constraints. The resolved value must
still satisfy its normal entity contract; division by zero, non-finite results and cycles fail with
the owning property path. Use ordinary local code for calculations outside these operations.

For repeated planar `line`, `circle`, `arc`, `polyline2d`, `dbText` or `mText` groups, use top-level
`exactEntityArrays` rather than writing a task-specific copy loop. Its current pattern schema
and example are included in `schema generation-request --entities ... --json` under `localArrays`.
Each array provides `id`, `sourceIds` and a linear or circular `pattern`; the drawing uses degree
angles. Count includes the original source as member 0, which remains unchanged. Generated IDs
are `<array id>/<member number>/<source ID>`, beginning at member 1. Array order follows declared
dependencies: sources come from the original map or an earlier array. Dimensions can reference
generated coordinates using `$ref` after escaping slashes as `~1`.
Include the outline and its shared labels in the same `sourceIds` group: label positions, DBText
alignment points and rotations follow the geometry, while text content, font and height remain
unchanged. Distinct equipment numbers or member names remain explicit labels whose positions refer
to their member geometry; an array does not invent names or automatically rebind dimension targets.
Keep the source entity and array parameters in the local request. Change that source or parameter
and validate again to update dependent copies and dimensions; do not independently rewrite expanded
coordinates. These arrays use the existing transform kernel and still undergo ordinary complete
request, geometry, signing and execution checks. They do not choose equipment, spacing or dimensions.
Other entities and source drawing modifications continue through their existing contracts.

If validation or coverage finds missing content before the first execution, keep the original
request and supply `exactEntityRevision` with `baselineRequestFile` and explicit `changes`, omitting
`resultFiles`. Add the missing notes, parameter tables, section labels or other designed objects
through the same entity map; include their coordinate dependencies instead of copying the existing
geometry. Keep the complete original instruction and reference sources in the current request.
Omitted observations are inherited from the baseline; an explicit list replaces them and is still
checked against current source hashes. The CLI assembles a complete ordinary draw request; this is not
proof that a native drawing has been executed. An existing drawing source always requires receipts.

For a subsequent revision of an executed declarative design, keep the previous local request
and execution receipts. Set top-level `exactEntityRevision` to
`{"baselineRequestFile":"before.json","resultFiles":["draw-result.json","edit-result.json"]}`
(omit later edit receipts for the first revision). Paths are relative to the output grant directory.
Receipts may be completed or `CAD_EDITABLE_DRAFT_READY`; other failed receipts are not native
baselines. Keep every original obligation and read the signed `acceptance.pendingRequirements`.
Add missing content through the same revision; only a new service review can clear those findings.
The latest artifact hash and actual native content must still match before any edit is compiled.
Keep `kind=plan`, `requirements.command=draw`; declare the current native file as the single drawing
source and name revised `requiredOutputPaths`. For a local change, include only the ordered
`exactEntityRevision.changes` operations instead of copying the complete design. Query
`schema generation-request --pointer /properties/exactEntityRevision --json` for the contract.
Changes address entity fields or array recipes with JSON Pointers and `add`, `replace`, `remove`
or `test`; the CLI loads the baseline fragments, applies those edits, then recomputes dependencies.
In this mode omit current `exactEntities`, `exactEntityFiles` and `exactEntityArrays`. Unchanged
requirements, paper-view recipes and omitted observations are inherited; keep the current instruction
and drawing/reference sources explicit. Replace observations explicitly after correcting a source
reading or changing an attachment. A complete revised design uses the same dependency compiler.
Keep original reference attachments and their observations alongside that drawing source; the local
dependency calculation does not discard the source evidence used to make the design.
The shared validate/generate/revise input path verifies the last receipt's artifact hash and the
native baseline, expands dependencies, and compiles changed IDs into ordinary add/replace/delete
operations. Use `revise --from` to preserve project history, then `edit` to execute its grant.
Unchanged entities are excluded from mutation. Retain every successful execution receipt and the
local request for the next revision, including a sparse request and its unchanged baseline files.
Document/resource changes and objects without complete
native companion bindings require an explicit patch; do not pretend they are an entity-only delta.

Bind an area label or table cell to its boundary with
`{"$area":{"entityId":"outline","unit":"m2","decimals":2,"suffix":" m²"}}`.
The same local resolver computes closed straight `polyline2d` and `circle` areas in model space,
converts the drawing unit to the explicit `mm2`, `cm2`, `m2` or `in2`, and formats the result.
Omit `decimals`, `prefix` and `suffix` for a numeric value; set `decimals` for a table string.
Keep this expression in the owning local fragment so a boundary revision updates every consumer.
Do not independently type area values into both a table and a note. This measures the actual
boundary, not its bounding box or an assumed net usable area. Net area needs explicit, verified
deductions; curved polyline and 3D areas still need the appropriate local calculation. User-fixed
area requirements remain separate constraints: compare the computed result, never overwrite them.

`validate.geometry.dimensions` reports native measurements for a complete new exact drawing.
Compare these values and the adopted source marks before submitting. `dimLinear.rotation` selects
the measurement axis in degrees (0 horizontal, 90 vertical); the endpoints stay on their real
geometry even when offset on the other axis. `dimAligned` measures their distance. Omitted linear
rotation follows the endpoints. Use native automatic dimension text, or a `<>` placeholder with
the requested prefix/suffix; never replace a wrong measured value by typing the desired label.
`validate.geometry.paperObjects` supplies the actual paper rectangles of viewports, tables and
title blocks. Calculate their placement using these native bounds. A `bomTable.insertionPoint`
is its lower-left corner; its height includes the column header, not only data rows.

Reserve time for an actual revision after opening the first PDF. Record concrete page/region
defects, change only their owning geometry or annotation, then generate, draw and inspect again.
Trace a finding to the owning parameter, geometry reference or annotation before revising; preserve
the rest of the design and rerun its calculations. Ask the user only for a real unresolved requirement;
do not turn a tool-schema error into an engineering question. Unprovided designer names and dates
stay blank. A written revision request is not a completed revision.

Use the existing generation-request evidence fields; do not create a second schema:

- Set `requirements.requiredDocument` for document settings established by the request or source.
  Omit undetermined settings and let the current generation contract supply its supported defaults.
- Assign stable, descriptive IDs such as `geometry.base-outline`, `dimension.overall-width`,
  `view.section-a-a`, `layout.sheet-2`, `table.bom`, and `title.sheet-1`.
- With a complete `exactEntities` map, omit the repeated `requiredEntityIds`, `exactEntityTypes`
  and `requiredDimensionIds` indexes: the CLI derives them. If explicit page order needs
  `requiredEntityIds`, compute the complete index locally and put layout IDs in the requested order.
- `requirements.exactEntityTypes` is the complete top-level entity ID/type manifest, not a partial
  type hint. Omit it while the planner still needs to add outlines, annotations or helper geometry;
  use it only when every top-level entity ID and type is already determined.
- For an exact entity manifest, give each expanded occurrence its own ID. For compiler-supported
  arrays and engineering objects, provide the owning object's count and relationships and inspect
  the expanded geometry. A quantity note alone does not prove the objects were constructed.
- Use `layout` and `viewport` IDs for explicit sheets/views, `hatch` for a required section hatch,
  `bomTable` for a BOM, `titleBlock` for each requested title block, and the dedicated
  manufacturing entity types when the drawing-plan schema supports them.
- A `layout` records paper-space metadata; it does not close a separately requested drawing-border
  obligation. When the user asks for a 图框, drawing border or sheet frame, bind a distinct `frame`
  ID to that layout in `exactEntities`; the same local derivation supplies its indexes.
- A requested front/top/side/section/detail view requires its actual geometry. Follow the user's
  layout count, viewport count and scale: multiple views can share one viewport. Bind the requested
  cameras and the model-space geometry they show; section hatch `boundaryIds` must resolve to the
  section contour. Detail enlargement may use a separate viewport or an explicitly requested
  model-space detail in the shared viewport; preserve its source boundary and dimension meaning.
- Use `requirements.exactEntities` when a complete executable design is intentionally fixed.
  For a natural-language design, send the original instruction, verified source evidence, design
  parameters and object relationships through the ordinary compiler path. A model's proposed
  coordinates, table cells or paper arrangement do not become fixed user constraints merely
  because they can be enumerated. Let the owning geometry and layout compiler construct them;
  use its existing area and source-quantity bindings for calculated values. Retain design choices
  and assumptions separately from user facts. Never freeze an incomplete failed draft or silently
  resolve conflicting engineering requirements. Verify the generated content after planning.
- In `exactEntities`, use only the canonical Plan Grant fields returned by the generation-request
  schema. Do not copy portable-backend aliases such as `sheetId`, `sheet`, `paper`, `boundary`, or
  backend-private fields into the strict manifest. Canonical examples include polyline2d
  `vertices`/`closed`/`bulges`, layout
  `name`/`paperSize`, paper-space `layout`, frame `layout`/`size`, viewport `layout`, and hatch
  `patternName`/`boundaryIds` referencing closed contour IDs. When a fully bound common-2D example
  is useful, load [portable-exact-common-2d.example.json](portable-exact-common-2d.example.json);
  adapt its obligations rather than copying unrelated entities.
- For a rounded closed outline, use one closed `polyline2d` with vertices at tangent endpoints and
  one bulge per vertex (`0` for a straight segment, `tan(signed sweep/4)` for an arc). Never retain
  the straight chord and add a separate arc over it.
- Keep `requirements.requiredOutputPaths` aligned one-to-one with `requirements.outputs`.

This contract is deliberately request-specific. It prevents the planner from declaring success
after omitting stated work without imposing universal counts, layouts, standards, or aesthetics.

## Compose the paper without changing the engineering intent

Use `requirements.spatialRelations` for explicitly required geometric relationships. Read the
`spatialRelation` definition from `schema drawing-plan`: clearance applies to door sweeps, obstacles
and annotation envelopes; containment to actual bounded regions; direction to oriented geometry;
projection agreement to corresponding views in a common design coordinate. Select actual entity
IDs or inspected handles. Carry these checks through generation and the native save/reopen report.
Inspect the complete path and every relevant obstacle for continuity; a label claiming an opening
does not create one. A referenced detail needs its actual geometry on the requested page or a
specific user-approved deferred scope. Add relationships from this request, never from a topic keyword.

For layout-only changes to an existing drawing, use the inspected group/handles with a single
`transform` transaction. It moves text insertion and alignment anchors, dimensions and dependent
geometry together. Do not regenerate the whole entity manifest to translate a view. Preserve
legitimate distinct TEXT anchors (including fit/aligned text); they must not be forced equal.
After any change, review both the modified area and affected relationships on the actual PDF.

- For an architectural floor plan, draw stated wall thickness as two faces or closed wall
  footprints. Door and window openings must interrupt both faces and include jamb returns; place
  the leaf and swing arc from the actual hinge, and place window lines inside the opening. A symbol
  over an unbroken wall is not an opening. If wall thickness or opening location is absent and
  materially changes the plan, ask once or state one concept-only assumption.
- Add a layout, viewport, frame, table or title block only when the deliverable or approved project
  profile calls for it; a viewport is not a universal requirement for a simple 2D sheet.
- A layout with paper-space furniture needs a real viewport to show model-space geometry; its
  `scale` field alone does not create a camera. Supply view ownership, requested paper size,
  fixed ratios and explicit annotation sizes through the current author contract. The shared
  compiler computes model bounds, camera fitting, paper-unit text sizes and placement around
  margins and title blocks. Do not hand-calculate those values for a natural-language request.
  Preserve user-fixed camera values and scale; use permitted placement or page allocation
  instead of resizing engineering geometry. The compiler completes generated cameras from
  those declared views; do not add a second hand-built camera for the same view. For an exact
  caller-authored camera, use `locked:true` on `DEFPOINTS`, or an existing source layer verified
  as `plottable:false`; never change source layer flags to pass.
  Read `validate.valid`, not just `ok` or the exit code. If false, apply its specific local findings
  and validate again before `generate`; final file readback and PDF review are still required.
  Use `validate --json --include-compiled` to inspect the exact successfully assembled request;
  `compiledRequest` is returned only when valid and is not a signed Grant. Preserve its compiled
  checks and view ownership when continuing. A `geometry.printFinding` describes the affected
  print output; preserve an existing native drawing and inspect its draft/partial delivery status.
  Use `geometry.annotationLayoutFindings` to select conflicting
  or clipped annotation IDs in `exactEntityRevision.layoutEntityIds`, retain the baseline request,
  and validate the local revision. Do not resubmit the unchanged request or rebuild the whole
  drawing. If fixed scale cannot fit, resolve the reported paper region/ownership constraint;
  annotation repair must not silently change the requested ratio or engineering geometry.
  If `candidateSearchTruncated` is true or the same conflicts remain without a valid proposal,
  revise the owning layout instead of repeating the same annotation search. Keep an explicitly
  requested text-and-line table together: select its complete grid, cells and labels for one
  rigid translation. Do not separate cell values from their rows to make a collision check pass.
- For a locally authored exact design with multiple PDF viewports, supply `entityIds` on each
  viewport or an `exactEntityViews` recipe declaring every view's geometry, dimensions and notes.
  Let the compiler derive ownership from the declared view-to-feature mapping. If that mapping is
  ambiguous, repair the Agent's view definitions in the same task; only an unresolved choice in
  the user's design needs clarification. Proximity and similar ID names alone do not establish it.
- Preserve an explicitly requested text-and-line BOM as one complete grid with all rows. A BOM
  row is not a separate `bomTable`, and a general recommendation to use native tables does not
  override the user's requested representation.
- Treat paper placement as a separate, advisory pass. Reserve distinct zones for the main geometry,
  overall dimensions, feature callouts, notes and tables, then render the PDF and move annotations
  that collide. Never move or resize the manufacturing geometry to improve appearance.
- Keep repeated feature dimensions apart: place overall dimensions outside the main view and
  distribute location, size and radius callouts around different sides when possible.
- Preserve native manufacturing semantics. For a portable diameter dimension, the native
  `dimDiameter` entity carries the meaning; a readable `Ø` text override may be used when needed by
  the available embedded Unicode font. Missing glyphs require repair of the affected derivative;
  they do not revoke an already saved, readable native drawing.
- A visual correction may change paper coordinates, annotation leader positions or whitespace only.
  Correct an established construction or binding error within the existing design authorization.
  A change to user-fixed size, quantity, tolerance, datum or material needs the user's authorization;
  an Agent's proposed value is not automatically user-fixed. Every executable revision still needs
  a new Plan Grant bound to the actual source and original obligations.

## Evaluate the final artifacts

Separate deterministic obligations from advisory review:

- **Incomplete delivery:** missing requested content/output, wrong quantity or size, wrong PDF page
  count, clipping, missing glyphs or an engineering rule failure. Keep the verified files and report
  the affected obligations; continue on the same design without claiming full completion.
- **Unverified artifact:** failed native reopen, a viewport with no geometry, or a section/detail or
  annotation with a missing target. Read the native diagnostics and draft/partial artifact evidence;
  do not claim that unverified content is suitable for manufacturing or construction.
- **Advisory:** whitespace balance, preferred view spacing, title-block styling, and other visual
  choices not fixed by the user or an approved enterprise profile.

Score intent fidelity, editability/readback, manufacturing completeness, print readability and
visual composition independently. Never raise the score merely because the CLI returned
`completed`; the artifact and obligation evidence must support it.
