# 统一 Agent 长任务事件

CAD CLI 的事件只描述真实发生的任务状态，不改变命令的结果、计费、重试或工程验收结论。

## 进程边界

启用 `--progress-jsonl` 后，每条事件作为一行 UTF-8 文本写入 stderr：

```text
::xiaozhiclaw-agent-event-v1::{"protocolVersion":1,"event":"stage.started","taskId":"...","source":"cad-cli","operation":"cad-execution","stageId":"inspect","stageName":"图纸回读与渲染验收","status":"running","summary":"正在检查图纸","elapsedSeconds":12.4,"nextStage":"repair","needsUserReview":false,"heartbeat":false,"sequence":4,"timestamp":"2026-09-01T00:00:00.000Z"}
```

Agent 必须并发、持续排空 stdout 与 stderr，以 `(taskId, sequence)` 去重。普通用户只需看到
`stageName`、`summary`、真实 `completedItems/totalItems/unit`、`currentArtifact`、`checkpointId` 和明确风险；不要展示
前缀、原始 JSON、内部路径、凭证或诊断细节。stdout 的终态 JSON 和进程退出码始终是完成与失败的
唯一 authority。

## 固定事件语义

- `task.started`：任务已建立；`stage.started`：真实阶段已经进入。
- `stage.progress`：服务端真实阶段、计数、当前产物、检查点和风险经 CLI 原样映射；20 秒心跳只重复最近的真实事件，`heartbeat: true` 只证明进程仍存活。
- `stage.completed`：该阶段确已结束；随后才可播报下一阶段。
- `checkpoint.saved`：可恢复证据已持久化，不等于用户审批。
- `artifact.ready`：产物已经写入并完成相应回读/校验，可进入交付清单。
- `review.required`：仅 `needsUserReview: true` 时暂停并询问用户；其他事件不得制造确认门限。
- `task.completed` / `task.failed`：事件流终态，但仍须与 stdout 终态 JSON 一致。

`generate`、`revise` 或 `plan wait` 只形成并校验签名 Grant：它们结束当前阶段，但不得发出
`task.completed`，也不得提交“用户已取得工程成果”的交付证据。只有后续 CAD 写入、重开、回读和
渲染均通过后，执行命令才可发出 `artifact.ready` 与 `task.completed` 并触发同一 job 的结算。

不输出臆测百分比或 ETA；有真实工作量时只输出完成数、总数和单位。45 秒内有新阶段或心跳时不得
判定卡死，更不得新建、重发或重复计费任务。失败或连接不确定时按同一 task/job 的状态与回执恢复。

## CAD 领域阶段

- 从零或精准修改：材料/需求解析 → 来源证据绑定 → 专业工程内容 → 图纸对象与布局构建 → 编译 →
  DWG/DXF/PDF 生成或修改 → 回读/渲染检查 → 问题集单调收敛的定向修订 → 签名与结果持久化 → 结算/正式交付。
- 解析、审计、转换：来源图纸打开 → 实体/对象/布局事实提取 → 规则或渲染检查 → 派生文件回读 →
  正式交付。

阶段 ID 是稳定机器标识，中文 `stageName`/`summary` 是播报文本。阶段完成不能替代图纸内容验收
或工程审批证据。
