# 工程事实与采用

本地与云端知识只保存有来源、版本、单位和适用条件的工程事实。厂商建议是其在指定条件下的主张，历史图纸是源项目证据；两者均不是新项目默认要求。工具字段、能力和执行算法由当前程序提供。

简单明确的任务可以不读取任何知识。需要补充事实时运行 `scripts/read-knowledge.ps1` 查看目录，仅选择当前未知项相关的主题，一次最多三个。哈希验证内容身份，不证明工程结论正确。

采用数值或公式时，为当前对象记录 `engineeringContext`，字段从当前 `schema knowledge-query` 查询。区分原话、附件实测、指定标准、供应商意见、历史经验和模型推断；不同部件使用各自的 `subject`。只填写所选事实的适用条件，缺少某条建议的条件仅表示不采用该建议，不增加制图必填项。

先从当前 `schema knowledge-query` 查询 context 的格式，再运行：
CAD：`scripts/read-knowledge.ps1 -Topic <主题ID> -ContextPath <当前对象事实.json> -PackageDigest <check-update返回的packageDigest>`。
CAD 阅读器通过包内 `invoke-cad.ps1` 校验 Skill 与配套 Runtime 后调用 `knowledge --evaluate --request - --json`，不采用外部 `CliPath`。仅查看目录或事实摘要无需 Runtime。
3D：`scripts/read-knowledge.ps1 -Topic <主题ID> -ContextPath <当前对象事实.json> -CliPath <当前solidworks-cli绝对路径>`。
来源判断不联网或调用模型；CAD 与 3D CLI 使用同一份判断合同。判断不可用时不阻断制图。

- `applicable`：条件匹配，可以形成计算依据；实际尺寸、单位、表示与工艺能力仍需验证。
- `insufficient-information`：保留缺失项和冲突来源，暂不采用数值或公式；继续不受影响的设计，只澄清影响交付的事实。
- `not-applicable`：保留不匹配原因，不采用该条建议；可以选择其他有来源且适用的方案。

尚未判断时只披露摘要、来源和条件；事实目录不要求安装某版执行引擎。知识读取或判断不可用不触发付费生成重试。

若条目包含来源公式，阅读器通过同一离线计算器返回 `calculations`。每个公式单独核对变量来源、单位、缺失和冲突；所需变量完整才返回数值，其他公式保留 pending。单位按该公式声明使用，不猜换算。算术结果不是切削参数选用、材料强度或加工能力批准；不得把公式演算中的输入当成建议值。

发现有害条目时，阅读器可用 `-DisabledTopic <ID>` 停用条目或 `-DisabledVersion <版本>` 停用知识包。云端使用其发布清单和配置的停用列表；本地参数不会修改云端状态。

需要历史项目事实时按需运行当前 CLI 的 `knowledge --request - --json`，传入 query、stage 和同一 context，字段以 `schema knowledge-query` 为准。两套 CLI 使用同一只读证据服务，保留各自的账户入口。使用实际返回的证据和 applicabilityAssessment；模型推断不作为事实返回。未命中、停用或不可用时允许不采用任何知识。

生成请求不填写 `engineeringKnowledge` 或指定 `mode=off` 时不隐式检索云端知识。针对具体未知项需要补充时指定 `mode=auto`，并按需提供已来源化的 context；暂缺 context 可以先了解证据范围，不能使用尚未核准的数值。`knowledgeUse` 记录实际查询、context、版本、完整选择 ID 与采用/修改/未采用理由。本地条目保留原文件哈希和判断回执，不能冒充云端返回的 ID。条件未通过的采用声明保留为未核准。

原附件与用户明确尺寸保持原样。冲突必须带出处说明，不得协调原值后冒充成功；用户批准变更后再进入同一修订流程。

采用判断同时检查条目的 `requiredInputs` 和 `applicability`；前者缺项也不能采用数值。历史项目 ID 相同只说明来源关联，不能证明当前对象、修订版或工况一致；应从当前附件重新核实，再作为独立的当前输入参与计算。

CAD 的 `acceptance.spatialRelations` 只放已经确认的验收要求，始终测量实际图纸。`spatialRelation.knowledge` 仅记录附带依据，知识缺失或不适用不能跳过、放宽或改写该要求。未核准的建议在知识计算回执和采用记录中保留待核准状态，不加入强制验收规则；这样不会阻断不受影响的制图，也不会掩盖真实几何错误。

最终回读和视觉验收按对应产品的执行契约完成。检索命中、算术结果及采用记录不能代替工程内容或视觉验收，也不证明制造能力或符合性。

本目录不提供企业模板、字体、符号块或已批准几何资产。资源以当前程序、原附件及已验证的资产登记为准。符合性声明须有具体标准版本、条款与适用条件，不能由基础知识主题推定。
