---
{"id":"length-units","summary":"英寸与毫米的精确换算；尺寸、上下偏差和面积体积的一致单位","claimKind":"engineering-note","revision":"1.1.0","reviewedOn":"2026-09-10","reviewAfter":"2027-03-10","scope":"unit-definition","sources":[{"publisher":"NIST","url":"https://emtoolbox.nist.gov/publications/nistjresjan-feb2007-112-1.pdf","section":"Historical discussion of the international inch","edition":"Journal of Research of NIST 112(1), 2007"}],"conditions":["国际英寸与毫米的单位换算","源文件单位必须由原文或原生设置确定，不能从图形大小猜测"],"quantities":[{"name":"millimeters-per-international-inch","minimum":25.4,"maximum":25.4,"unit":"mm/in","sourceIndex":0}],"requiredInputs":["sourceUnit","targetUnit"],"evidenceClass":"engineering-fact","applicability":[{"key":"sourceUnit","oneOf":["international-inch","mm"]},{"key":"targetUnit","oneOf":["international-inch","mm"]}]}
---
# 长度单位与比例

国际英寸精确定义为 25.4 mm。换算长度时，名义值、上下偏差及坐标使用同一因子；面积和体积分别使用因子的平方和立方。
这些是定义及其数学推论，不是制造经验默认值。

源文件未声明单位时保留未知，不能因“看起来像毫米”直接缩放。纸上比例与模型单位分开：1:2 视图不表示模型尺寸变成一半。
源图尺寸文字可能覆盖名义显示值，需对照原生测量、尺寸样式比例和实际几何。

缺少单位定义或原始单位声明相互矛盾时，实际缩放因子无法由外形大小唯一确定。
