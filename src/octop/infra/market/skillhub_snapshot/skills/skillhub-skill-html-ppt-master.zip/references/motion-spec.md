# 动效规范

两套机制：**模块入场**（每页每个模块）与**数据图形生长**（有数据/图表的元素）。目标是“快、自然、有顺序感”，全套动作在 1.2 秒内结束，不做炫技。

## 1. 动画清单

| 对象 | 效果 | 时长 | 延迟 |
|---|---|---|---|
| 每个模块（标题区/卡片/横幅/条带/表格） | 上移 15px + 淡入 | 460ms | 按序 ×55ms，上限 550ms |
| 封面/过渡页文字块 | 缩放到 1 + 淡入（`softIn`） | 620ms | 同上 |
| KPI 数字 | 0 → 目标值滚动 | 880ms | 240ms |
| 横向条形 `.bar-fill` | `scaleX(0→1)` 从左生长 | 920ms | 340ms |
| 对比条 `.cmp-fill` | 同上 | 820ms | 320ms |
| 迷你进度条 `.micro-fill` | 同上 | 720ms | 400ms |
| 环形图 `circle` | `stroke-dasharray` 顺时针展开 | 980ms | 300ms |
| 表格行 | 上移 9px + 淡入，逐行 | 400–420ms | 表头 160ms，正文行 ×50ms |
| 图表容器 `.bars/.cmp/.donut/.micro` | 轻微缩入 `softIn` | 500ms | 200ms |

缓动统一 `cubic-bezier(.22,1,.36,1)`（数字用三次方出曲线 `1-(1-p)^3`）。`both` 填充模式，避免延迟期间闪现。

## 2. CSS 部分

```css
@keyframes modIn{0%{opacity:0;transform:translateY(15px)}100%{opacity:1;transform:none}}
@keyframes rowIn{0%{opacity:0;transform:translateY(9px)}100%{opacity:1;transform:none}}
@keyframes barGrow{0%{transform:scaleX(0)}100%{transform:scaleX(1)}}
@keyframes softIn{0%{opacity:0;transform:scale(.97)}100%{opacity:1;transform:none}}

.slide.active .mod{animation:modIn .46s cubic-bezier(.22,1,.36,1) both;animation-delay:var(--d,0s)}
.slide.active .mod-soft{animation:softIn .62s cubic-bezier(.22,1,.36,1) both;animation-delay:var(--d,0s)}

.bar-fill,.cmp-fill,.micro-fill{transform-origin:left center;will-change:transform}
.slide.active .bar-fill{animation:barGrow .92s cubic-bezier(.22,1,.36,1) both;animation-delay:.34s}
.slide.active .cmp-fill{animation:barGrow .82s cubic-bezier(.22,1,.36,1) both;animation-delay:.32s}
.slide.active .micro-fill{animation:barGrow .72s cubic-bezier(.22,1,.36,1) both;animation-delay:.4s}

.slide.active .tbl thead tr{animation:rowIn .4s ease both;animation-delay:.16s}
.slide.active .tbl tbody tr{animation:rowIn .42s ease both;animation-delay:calc(.26s + var(--i,0)*.05s)}
.slide.active .ftable tr{animation:rowIn .38s ease both;animation-delay:calc(.34s + var(--i,0)*.055s)}

.slide.active .bars,.slide.active .cmp,.slide.active .donut,.slide.active .micro{
  animation:softIn .5s cubic-bezier(.22,1,.36,1) both;animation-delay:.2s}
```

## 3. JS 部分（可整段复制）

要点三条：

1. **模块自动收集**：不用手写 `.reveal` 类，脚本按选择器收集后自动加 `.mod` 与 `--d` 延迟；被外层同选择器包含的节点会被剔除，避免嵌套元素重复入场。
2. **数字滚动只动第一个文本节点**：保留 `≥`、`+3`、`万人`、`%` 等前后缀；原始数字串存进 `dataset.raw`，快速翻页不会把中间值当目标。
3. **重放机制**：动画挂在 `.slide.active` 上，切页时 `active` 移除再加回即自动重放；JS 驱动的动画由 `show()` 调用 `runSlideAnim()` 触发。

```js
function setup(slide){
  let nodes = [...slide.querySelectorAll(SEL)];
  nodes = nodes.filter(n => !nodes.some(m => m !== n && m.contains(n)));
  nodes.forEach((n,i)=>{
    n.classList.add('mod');
    if (n.matches(SOFT)) n.classList.add('mod-soft');
    n.style.setProperty('--d', (Math.min(i*0.055,0.55)).toFixed(3)+'s');
  });
  slide.querySelectorAll('.tbl tbody tr').forEach((tr,i)=>tr.style.setProperty('--i',i));
  slide.querySelectorAll('.ftable tr').forEach((tr,i)=>tr.style.setProperty('--i',i));
  slide.querySelectorAll('.kpi-num').forEach(el=>{
    const tn=[...el.childNodes].find(n=>n.nodeType===3 && /\d/.test(n.nodeValue));
    if(tn) el.dataset.raw = tn.nodeValue;
  });
  slide.querySelectorAll('.donut circle').forEach(c=>{
    const d=c.getAttribute('stroke-dasharray'); if(d) c.dataset.dash=d;
  });
}
```

`SEL` 取值：

```
.card,.banner,.strip,.tbl,.s-head,.chain,.ch-metrics,.ch-prose,.toc-item,.toc-p,
.cv-eyebrow,.cv-main,.cv-rule,.cv-sub,.cv-meta,.ch-no,.ch-title,.ch-eyebrow,
.arrow-flow,.flow,.pyr
```

`SOFT` 取值（封面/过渡页文字，用缩入而非上移）：

```
.cv-eyebrow,.cv-main,.cv-rule,.cv-sub,.cv-meta,.ch-no,.ch-title,.ch-eyebrow
```

## 4. 无障碍与稳定性

- `prefers-reduced-motion: reduce` 时全部动画 `animation:none`，`reveal` 类直接置为可见
- 动画只作用于 `opacity` 与 `transform`，不触发布局重排
- 条形动画用 `scaleX` 而不是 `width`，避免逐帧重排
- 表格行 `--i` 由 JS 注入，新增行数不需要改 CSS

## 5. 编辑模式

按 `E` 切换 `body.editing`，给文本节点加 `contenteditable`，同时给 `.slide-inner` 加虚线框提示。编辑态下保留动画，不额外禁用。
