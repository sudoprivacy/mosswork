# 版式与组件规范

以 `assets/template-full.html` 为准。本文档给出可复制的代码片段，改内容时直接替换文字与数值。

## 1. 字号体系（1920×1080 舞台，px）

| 用途 | 字号 | 行高 | 字重 | 字体 |
|---|---|---|---|---|
| 内容页标题 `.s-title` | 50 | 1.1 | 900 | 衬线 |
| 页副标题 `.s-sub` | 21 | 1.45 | 400 | 无衬线 |
| 眉标 `.kicker` | 17 | — | 500 | 无衬线，字距 .16em |
| 卡片标题 `.ct` | 24–25 | 1.26 | 700 | 衬线 |
| 卡内小标 `.cs` | 15 | — | 400 | 无衬线 |
| 正文 `.prose p` | 21 | 1.95 | 400 | 无衬线，首行缩进 2em |
| KPI 数字 `.kpi-num` | 78–82 | .92 | 700 | 数字字体 |
| KPI 标签 `.kpi-lab` | 19–20 | 1.35 | 600 | 无衬线 |
| 卡片正文 `.card-b` | 20 | 1.7 | 400 | 无衬线 |
| 表格正文 `.tbl td` | 19 | 1.45 | 400 | 无衬线 |
| 表格数字 `.tbl td.v/.g` | 24–25 | — | 600/700 | 数字字体 |
| 条带数字 `.sn` | 36–38 | 1 | 700 | 数字字体 |
| 页脚 `.s-foot` | 14 | — | 400 | 无衬线 |

数字一律用 `--font-num`（Barlow Condensed + 中文兜底），中文用 `--font-sans`，标题用 `--font-serif`。三者不可混用。

## 2. 栅格与间距

- 页面内边距：`padding: 52px 86px 70px`；页脚绝对定位 `bottom: 24px`。
- 模块间距：`.slide-inner { gap: 20px }`，栅格 `gap: 18px`。
- 常用栅格：`.g2/.g3/.g4`（等分）、`.g-7-5`、`.g-5-7`、`.g-6-4`、`.g-4-6`（比例分）。
- `.grid.fill` 或 `.card.fill` 吃掉剩余高度，是消除底部空档的唯一手段。
- 卡片内边距：`24px 26px`；KPI 卡 `22px 24px 20px`。

## 3. 卡片系统

```html
<!-- 普通卡：左红竖条 + 白渐变底 + 弥散阴影 -->
<div class="card">
  <div class="card-h"><span class="ic" data-i="target"></span>
    <div><div class="ct">卡片标题</div><div class="cs">副说明</div></div>
  </div>
  <div class="card-b">正文，20px，可用 <b>加粗红字</b> 强调。</div>
</div>

<!-- KPI 卡：顶部图标行 → 数字 → 标签 → 底部说明/进度 -->
<div class="card kpi">
  <div class="kpi-top"><span class="kpi-tag">规 模</span><span class="ic sm" data-i="users"></span></div>
  <div class="kpi-num">1.28<span class="u">万人</span></div>
  <div class="kpi-lab">在册职工</div>
  <div class="kpi-body"><div class="micro">…</div></div>
</div>
```

关键 CSS 约定：

```css
.card{justify-content:space-between}      /* 内容纵向铺开，杜绝底部空档 */
.card.fill{flex:1;min-height:0}           /* 卡片吃满剩余高度（.fill 只在 .grid 上是不够的） */
.card::after{…}                           /* 左侧 3px 渐变红竖条，装饰不可省 */
```

## 4. 正文区（每页 200–330 字）

```html
<div class="card txt fill">
  <div class="card-h"><span class="ic" data-i="book"></span>
    <div><div class="ct">工作实录：xxx</div><div class="cs">原文表述</div></div>
  </div>
  <div class="prose">            <!-- 或 .prose.two 双栏 -->
    <p>第一段……</p>
    <p>第二段……</p>
  </div>
</div>
```

```css
.prose{flex:1;display:flex;flex-direction:column;gap:12px;justify-content:space-evenly}
.prose p{font-size:21px;line-height:1.95;text-align:justify;text-indent:2em}
.prose.two{display:grid;grid-template-columns:1fr 1fr;gap:10px 40px;align-content:center}
```

单栏 300 字约 7 行；双栏各 150 字约 4 行。正文卡宽度超过 900px 时用双栏，否则单栏。

## 5. 图表组件

**横向条形**（占比、构成）：

```html
<div class="bars">
  <div class="bar-row">
    <div class="bar-name">正高级职称专家</div>
    <div class="bar-track"><div class="bar-fill" style="width:100%"></div></div>
    <div class="bar-val">47<span class="u2">人</span><span class="pc">25.3%</span></div>
  </div>
</div>
```

`width` 取该组最大值归一化为 100%。条形高度 24px，圆角 6px，渐变由深红到浅红。

**对比条**（现状 vs 对标）：`.cmp` + `.cmp-fill`，第二组用 `.cmp-fill.mute` 灰化。

**环形图**：SVG 圆环，`r=76`，`stroke-width=20`，周长 477.5；`stroke-dasharray="180 478"` 中的 180 需按比例算（占比 × 477.5）。渐变 `#dg1` 从 `--red-500` 到 `--red-800`。

**卡内小表**（3–5 行）：`.ftable`，右列数字字体、右对齐、红色。

**主表**（4–6 行）：`.tbl`，表头深红渐变、白字，偶数行浅底。列宽用 `th` 的 `width` 控制，首列可带 `.k`（加粗）、数字列 `.v`（灰）/`.g`（红）。

**条带**（4–5 格数字）：`.strip` + `.strip-cell`，`grid-auto-flow:column` 等分。

**流程**（3–4 步）：`.flow` + `.flow-item`，序号方块 31px。

**结论横幅**：`.banner`，深红渐变 + 右侧光斑 + 左侧金色竖条，用于每页的“so what”。

**金字塔**：`.pyr` + `.pyr-lv.l1~l4`，宽度 46% / 68% / 86% / 100% 逐级放大。

**箭头流程**：`.arrow-flow` + `.af-cell` + `.af-arrow`，最后一格可翻成深红底表示终点。

## 6. 页眉页脚

```html
<div class="s-head">
  <div class="kicker"><span class="kn">01</span><span class="kt">主要工作及成效 · 产业链</span></div>
  <h2 class="s-title">编制需求目录，按图引才按需配才</h2>
  <p class="s-sub">可选：一句补充说明，21px</p>
</div>

<div class="s-foot"><span>单位全称 · 汇报主题</span><span class="fr"></span></div>
```

标题红色圆角竖线由 `.s-title::before` 提供（10px 宽、`.92em` 高、`border-radius:5px`、红渐变 + 投影），不要另外加装饰。

## 7. 装饰层（封面/过渡页）

```html
<div class="deco">
  <i class="g-glow-a"></i><i class="g-glow-b"></i>
  <i class="g-ring-a"></i><i class="g-ring-b"></i>
  <i class="corner c-tl"></i><i class="corner c-tr"></i>
  <i class="corner c-bl"></i><i class="corner c-br"></i>
</div>
```

角弧 `.corner`：190px 圆环，`inset:22px` 的 `::after` 叠第二层细环；四个角分别偏移 `-96px`，靠 `.deco{overflow:hidden}` 裁成四分之一弧。

## 8. 图标注册表

```js
const ICONS = { users:'<circle cx="9" cy="7" r="4"/>…', target:'…', layers:'…' };
document.querySelectorAll('[data-i]').forEach(el=>{
  el.innerHTML = '<svg viewBox="0 0 24 24">' + (ICONS[el.getAttribute('data-i')]||'') + '</svg>';
});
```

已有图标：`users target layers award building book shield trending alert network handshake chart flag clock spark check coins link`。新增图标必须是 24×24 viewBox、`fill:none`、`stroke:currentColor`、`stroke-width:1.8` 的线性图标，与既有风格一致。

## 9. 代码书写规范

- 一个 `<section class="slide">` 一页，`data-t` 写页名，页与页之间空一行并加 `<!-- === 01 封面 === -->` 注释。
- 内联样式仅用于一次性微调（宽度百分比、字号档位），系统样式一律进 `<style>`。
- CSS 顺序：令牌 → 舞台 → 页面类型 → 页眉页脚 → 卡片 → 栅格 → 组件 → 动效 → 媒体查询。
- 所有可复用的尺寸写进变量，不在规则里硬编码重复值。
- 页面内不写 `!important`，除非覆盖第三方默认值（本项目仅 `.slide-inner::before{display:none}` 与阶梯覆盖样式使用）。
