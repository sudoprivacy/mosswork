#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""html-PPT 大师 · 结构自检

用法：
    python scripts/check_deck.py <deck.html> [--strict]

检查：标签闭合 / 页数与页序 / 标题规范 / 正文字数 / 外链白名单 / 图标注册 / 页码是否手写 / 舞台与显隐方式。
任何一项 FAIL 即退出码 1。
"""
import re
import sys
import os

CJK = r'\u4e00-\u9fff'
ALLOWED_HOSTS = ('fonts.googleapis.com', 'fonts.gstatic.com')

TITLE_MAX = 26          # 标题最大字数
PROSE_MIN = 150         # 每页正文下限（非空白字符）
PROSE_MAX = 380         # 每页正文上限（非空白字符，约 300 汉字）
PAGES_MIN, PAGES_MAX = 5, 40


def strip_tags(h):
    h = re.sub(r'<br\s*/?>', '\n', h)
    h = re.sub(r'<[^>]+>', '', h)
    return re.sub(r'[ \t]+', ' ', h).strip()


def count_chars(t):
    """字数：非空白字符数（含标点，与 Word「字符数(不计空格)」口径一致）"""
    return len(re.sub(r'\s+', '', t))


def sections(html):
    out = []
    for m in re.finditer(r'<section\b[^>]*class="([^"]*)"[^>]*>(.*?)</section>', html, re.S):
        cls, body = m.group(1), m.group(2)
        kind = 'chapter' if 'chapter' in cls else ('cover' if 'cover' in cls else 'content')
        out.append((kind, body, m.group(0)))
    return out


def titles(html):
    return [strip_tags(x) for x in re.findall(r'<h2 class="s-title">(.*?)</h2>', html, re.S)]


def main():
    if len(sys.argv) < 2:
        print('用法: python check_deck.py <deck.html> [--strict]')
        return 2
    path = sys.argv[1]
    if not os.path.isfile(path):
        print('找不到文件: %s' % path)
        return 2
    strict = '--strict' in sys.argv
    html = open(path, encoding='utf-8').read()

    rows = []

    def chk(name, ok, detail=''):
        rows.append((ok, name, detail))

    # 1. 标签闭合
    sec_o, sec_c = len(re.findall(r'<section\b', html)), len(re.findall(r'</section>', html))
    div_o, div_c = len(re.findall(r'<div\b', html)), len(re.findall(r'</div>', html))
    chk('section 标签闭合', sec_o == sec_c, '%d 开 / %d 闭' % (sec_o, sec_c))
    chk('div 标签闭合', div_o == div_c, '%d 开 / %d 闭' % (div_o, div_c))

    secs = sections(html)
    chk('页数在合理区间', PAGES_MIN <= len(secs) <= PAGES_MAX, '%d 页' % len(secs))

    # 2. 页序
    kinds = [s[0] for s in secs]
    order_ok = bool(kinds) and kinds[0] == 'cover'
    if len(kinds) > 1:
        order_ok = order_ok and kinds[-1] in ('cover', 'content')
    chk('首屏为封面', order_ok, ' '.join(kinds[:3]))
    chk('存在过渡页', kinds.count('chapter') >= 1, '%d 个过渡页' % kinds.count('chapter'))

    # 3. 标题规范
    ts = titles(html)
    long_t = [t for t in ts if count_chars(t) > TITLE_MAX]
    eng_t = [t for t in ts if re.search(r'[A-Za-z]', t)]
    chk('标题长度 <= %d 字' % TITLE_MAX, not long_t,
        ('超长: ' + ' / '.join(t[:14] for t in long_t)) if long_t else '%d 个标题' % len(ts))
    chk('标题无英文', not eng_t, ' / '.join(t[:14] for t in eng_t))
    nowrap = bool(re.search(r'\.s-title\{[^}]*white-space:\s*nowrap', html, re.S))
    chk('标题强制单行', nowrap, '' if nowrap else '缺少 white-space: nowrap')

    # 4. 每页正文字数
    bad_prose, stats = [], []
    for i, (kind, body, _) in enumerate(secs, 1):
        if kind != 'content':
            continue
        if 'toc-list' in body or '目录' in body[:400]:
            continue  # 目录页不计正文字数
        blocks = re.findall(r'<div class="prose[^"]*"[^>]*>(.*?)</div>', body, re.S)
        n = sum(count_chars(strip_tags(b)) for b in blocks)
        stats.append(n)
        if n and not (PROSE_MIN <= n <= PROSE_MAX):
            bad_prose.append('P%d=%d字' % (i, n))
        if not n:
            bad_prose.append('P%d=无正文' % i)
    chk('每页正文 %d-%d 字' % (PROSE_MIN, PROSE_MAX), not bad_prose,
        ' / '.join(bad_prose[:8]) if bad_prose else '范围 %d-%d 字' % (min(stats), max(stats)) if stats else '无正文页')

    # 5. 外链白名单
    ext = re.findall(r'(?:src|href)="(https?://[^"]+)"', html)
    bad_ext = [u for u in ext if not any(h in u for h in ALLOWED_HOSTS)]
    chk('外部资源仅限字体', not bad_ext, ' / '.join(bad_ext[:3]))

    # 6. 图标注册
    used = set(re.findall(r'data-i="([^"]+)"', html))
    m = re.search(r'const ICONS\s*=\s*\{(.*?)\n\};', html, re.S)
    reg = set(re.findall(r'([A-Za-z][A-Za-z0-9]*)\s*:', m.group(1))) if m else set()
    miss = sorted(used - reg)
    chk('图标均已注册', not miss, '缺: ' + ', '.join(miss) if miss else '%d 个图标' % len(reg))

    # 7. 页码是否手写
    hand = re.findall(r'<span class="fr">\s*([^<\s][^<]*)</span>', html)
    chk('页码由脚本回填', not hand, '手写: ' + ', '.join(hand[:3]))

    # 8. 舞台与显隐
    chk('固定 1920 舞台', bool(re.search(r'width:\s*1920px;\s*height:\s*1080px', html.replace('\n', ' '))), '')
    scale = 'innerWidth/1920' in html and 'innerHeight/1080' in html
    chk('舞台等比缩放', scale, '' if scale else '缺少 fit() 缩放')
    disp = re.search(r'\.slide\{[^}]*display\s*:\s*(none|block)', html, re.S)
    chk('显隐不用 display', disp is None, '发现 display 切换' if disp else '')
    chk('动效引擎就位', 'runSlideAnim' in html and 'modIn' in html, '')
    chk('减动效兜底', 'prefers-reduced-motion' in html, '')

    # 输出
    fail = 0
    print('\n  html-PPT 大师 · 结构自检   %s\n' % os.path.basename(path))
    for ok, name, detail in rows:
        if not ok:
            fail += 1
        print('  %s  %-22s %s' % ('PASS' if ok else 'FAIL', name, detail))
    print('\n  结果：%d 项通过，%d 项未通过' % (len(rows) - fail, fail))
    if fail:
        print('  提示：FAIL 项须修正后重新自检；正文页缺内容时补数据，不要靠放大字号掩盖。')
    print('')
    return 0 if fail == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
