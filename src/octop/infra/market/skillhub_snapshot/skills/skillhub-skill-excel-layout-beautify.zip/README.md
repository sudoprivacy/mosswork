# Excel 排版美化

把「能算但读不下去」的工作簿，改成可下发、可培训、可长期维护的版本。

## 解决什么问题

- 表格配色花、字体杂、字号乱，打印或投屏不好看
- 多个部门填报，颜色语义不统一（黄格到底是不是要填）
- 要给领导、客户、审计交付，需要「一看就是正规件」
- 表格改完格式，要能证明「只有格式变了，数据一条没动」

## 怎么做

```
S0 量现状  →  S1 定规范  →  S2 脚本落地  →  S3 验收交付
   只读          写进 JSON     plan/apply      三层核对
```

四个脚本，只依赖 `openpyxl`：

| 脚本 | 作用 |
|---|---|
| `scripts/xl_scan.py` | 只读扫描，出结构指纹、分布画像、偏离清单 |
| `scripts/xl_apply.py` | 三态套用规范（plan / apply / verify），改前自动备份 |
| `scripts/xl_verify.py` | 独立回归核对，逐格比对公式与结构 |
| `scripts/xl_preview.py` | 局部渲染 HTML，用于肉眼核对版面 |

## 快速上手

```bash
# 1. 先量
python scripts/xl_scan.py 工作簿.xlsx -o scan_out/
#    看 scan_out/summary.txt

# 2. 按你的簿调规范
#    重点调 assets/spec_default.json 里 font.ladder.data（等于扫描出的数据区主字号）
#    以及 palette 的七个色值

# 3. 预演，看命中数
python scripts/xl_apply.py 工作簿.xlsx --spec assets/spec_default.json --mode plan

# 4. 分步执行，先字体（不影响版面）
python scripts/xl_apply.py 工作簿.xlsx --spec assets/spec_default.json --mode apply --only font

# 5. 核对
python scripts/xl_apply.py 工作簿.xlsx --mode verify --baseline scan_out/profile.json

# 6. 肉眼核对
python scripts/xl_preview.py 工作簿.xlsx --sheet "某表" --range 4-20 --cols 1-12 -o p.html
```

## 文件结构

```
SKILL.md                        主文档：工作流、红线速查、规范默认值
references/
  01-诊断与基线.md              扫描什么、画像怎么读、四个统计口径陷阱
  02-设计规范.md                配色推导、字体阶梯、行角色三铁律、表头结构
  03-红线十四条.md              每条的红线：现象、机理、判据、正确写法
  04-验收矩阵.md                三层验收、渲染器要点、交付清单
  05-案例_35表预算簿.md         一次真实全簿封版的实测数据与六个决策
scripts/
  xl_scan.py                    扫描
  xl_apply.py                   套用（三态）
  xl_verify.py                  核对
  xl_preview.py                 渲染
assets/
  spec_default.json             默认规范，改这里就能改行为
```

## 三条最值得先看的

1. **红线 1**：用编辑器 SDK 保存带公式的簿，公式 34,416 → 30,177。只允许 openpyxl。
2. **红线 3**：只改 `font.name` 不清 `font.scheme`，Excel 按主题字体渲染，改动完全无效。
3. **红线 6**：明细区的中蓝色是「计算列标记」，不是小计底。按小计处理会变成整列竖条。

完整十四条在 `references/03-红线十四条.md`。

## 实测规模

在一份 35 表、34,416 条公式、1,293 条条件格式、327 处合并区、49,183 个有值格的工作簿上完整跑过：
改动 68,908 格，公式、条件格式、数据验证、定义名称、合并区数量全部零变化。

## 依赖

```bash
pip install openpyxl
pip install formulas      # 仅在需要重算核对公式结果时
```
