#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xl_verify.py — 回归核对（只读）

用法:
    # 拿扫描基线核对改后文件
    python xl_verify.py 改后.xlsx --baseline scan_out/profile.json

    # 直接比对两份文件（改前 vs 改后）
    python xl_verify.py 改后.xlsx --against 改前.xlsx

    # 额外核对若干文本格
    python xl_verify.py 改后.xlsx --baseline scan_out/profile.json \
        --expect "00 封面!C9=V1.1" --expect "S01 看板!C150=V1.1"

判据：八项结构指标全部相等 + 公式逐格一致。任何一项不等即 FAIL（退出码 1）。
"""
import argparse
import collections
import json
import sys

try:
    import openpyxl
except ImportError:
    sys.exit("需要 openpyxl：pip install openpyxl")


def norm_rgb(v):
    if v is None:
        return "NONE"
    s = str(v).strip().lstrip("#").upper()
    if s in ("", "00000000", "NONE"):
        return "NONE"
    return s[-6:] if len(s) >= 6 else s


def font_color_key(fc):
    if fc is None:
        return "NONE"
    try:
        if fc.type == "theme":
            return "theme%s" % fc.theme
    except Exception:
        pass
    return norm_rgb(fc.rgb) if isinstance(fc.rgb, str) else "NONE"


def fingerprint(path):
    """采集与 xl_scan 同口径的指纹"""
    wb = openpyxl.load_workbook(path)
    f = collections.OrderedDict()
    f["sheetnames"] = list(wb.sheetnames)
    f["sheets"] = len(wb.sheetnames)
    f["names"] = len(list(wb.defined_names))

    formulas, used, cf_r, cf_a, dv, merged, links = {}, 0, 0, 0, 0, 0, 0
    fill, fcolor, fname, nfmt = (collections.Counter() for _ in range(4))
    freeze, grid, tab = {}, {}, {}

    for ws in wb.worksheets:
        n = ws.title
        freeze[n] = str(ws.freeze_panes)
        grid[n] = bool(ws.sheet_view.showGridLines)
        tc = ws.sheet_properties.tabColor
        tab[n] = norm_rgb(tc.rgb) if (tc is not None and isinstance(tc.rgb, str)) else None

        merged += len(ws.merged_cells.ranges)
        skip = set()
        for m in ws.merged_cells.ranges:
            for r in range(m.min_row, m.max_row + 1):
                for c in range(m.min_col, m.max_col + 1):
                    if (r, c) != (m.min_row, m.min_col):
                        skip.add((r, c))

        for rng, rl in ws.conditional_formatting._cf_rules.items():
            cf_a += 1
            cf_r += len(rl.rules) if hasattr(rl, "rules") else len(rl)
        dv += len(ws.data_validations.dataValidation)

        for cell in ws._cells.values():
            if (cell.row, cell.column) in skip:
                continue
            fk = norm_rgb(cell.fill.fgColor.rgb) if cell.fill.fill_type else "NONE"
            fill[fk] += 1
            fcolor[font_color_key(cell.font.color)] += 1
            v = cell.value
            if v is None:
                continue
            used += 1
            fname[cell.font.name] += 1
            nfmt[cell.number_format] += 1
            if isinstance(v, str) and v.startswith("="):
                formulas["%s!%s" % (n, cell.coordinate)] = v
            if cell.hyperlink is not None:
                links += 1

    f.update(formulas=formulas, used=used, cf_rules=cf_r, cf_areas=cf_a, dv=dv,
             merged=merged, links=links, fill=dict(fill), fcolor=dict(fcolor),
             fname=dict(fname), nfmt=dict(nfmt), freeze=freeze, grid=grid, tab=tab)
    return f


def from_baseline(path):
    """把 xl_scan 的 profile + dist 拼成同口径指纹"""
    prof = json.load(open(path, encoding="utf-8"))
    dist = json.load(open(path.replace("profile.json", "dist.json"), encoding="utf-8"))
    f = collections.OrderedDict()
    f["sheetnames"] = prof["sheetnames"]
    f["sheets"] = prof["sheets"]
    f["names"] = prof["names"]
    f["formulas"] = prof["formulas"]
    f["used"] = dist["used_cells"]
    f["cf_rules"] = prof["cf_rules"]
    f["cf_areas"] = prof["cf_areas"]
    f["dv"] = prof["dv"]
    f["merged"] = dist["merged_total"]
    f["links"] = dist["links"]
    f["fill"] = dist["fill"]
    f["fcolor"] = dist["font_color"]
    f["fname"] = dist["font_name"]
    f["nfmt"] = dist["number_format"]
    f["freeze"] = dist["freeze"]
    f["grid"] = dist["gridlines"]
    f["tab"] = dist["tab_color"]
    return f


def compare(base, now, strict_formula_body=True):
    rows = []

    def chk(name, a, b, ok=None):
        good = (a == b) if ok is None else ok
        rows.append((name, a, b, bool(good)))
        return good

    def info(name, a, b):
        """信息项：分布本来就会变（apply 就是要改填充/字色），不判 PASS/FAIL"""
        rows.append((name, a, b, None))

    chk("工作表数", base["sheets"], now["sheets"])
    chk("页签序列", "一致" if base["sheetnames"] == now["sheetnames"] else "不一致",
        "一致" if base["sheetnames"] == now["sheetnames"] else "不一致")
    chk("定义名称数", base["names"], now["names"])

    fa, fb = base["formulas"], now["formulas"]
    miss = [k for k in fa if k not in fb]
    add = [k for k in fb if k not in fa]
    chg = [k for k in fa if k in fb and fa[k] != fb[k]]
    chk("公式总数", len(fa), len(fb))
    chk("公式逐格一致",
        "%s 条" % format(len(fa), ","),
        "缺%d/多%d/改%d" % (len(miss), len(add), len(chg)),
        ok=(not miss and not add and not chg))

    chk("条件格式规则", base["cf_rules"], now["cf_rules"])
    chk("条件格式区域", base["cf_areas"], now["cf_areas"])
    chk("数据验证", base["dv"], now["dv"])
    chk("合并区", base["merged"], now["merged"])
    chk("有值单元格", base["used"], now["used"])
    chk("内部超链接", base["links"], now["links"])
    chk("冻结窗格", "一致" if base["freeze"] == now["freeze"] else "不一致",
        "一致" if base["freeze"] == now["freeze"] else "不一致")
    chk("网格线开关", "一致" if base["grid"] == now["grid"] else "不一致",
        "一致" if base["grid"] == now["grid"] else "不一致")
    chk("页签颜色", "一致" if base["tab"] == now["tab"] else "不一致",
        "一致" if base["tab"] == now["tab"] else "不一致")
    info("填充分布", base["fill"], now["fill"])
    info("字色分布", base["fcolor"], now["fcolor"])
    info("字体名分布", base["fname"], now["fname"])
    info("数字格式", base["nfmt"], now["nfmt"])
    return rows, miss, add, chg


def main():
    ap = argparse.ArgumentParser(description="Excel 格式回归核对（只读）")
    ap.add_argument("xlsx")
    ap.add_argument("--baseline", help="xl_scan 产出的 profile.json")
    ap.add_argument("--against", help="直接比对另一份 xlsx")
    ap.add_argument("--expect", action="append", default=[],
                    help='额外核对文本格，格式 "表名!坐标=期望值"，可多次')
    a = ap.parse_args()

    if not a.baseline and not a.against:
        sys.exit("需要 --baseline 或 --against 之一")

    print("=" * 76)
    print("Excel 格式回归核对")
    print("=" * 76)
    print("目标   %s" % a.xlsx)
    now = fingerprint(a.xlsx)

    if a.against:
        print("基准   %s" % a.against)
        base = fingerprint(a.against)
    else:
        print("基准   %s" % a.baseline)
        base = from_baseline(a.baseline)

    rows, miss, add, chg = compare(base, now)
    print("")
    okn = judged = 0
    for name, va, vb, good in rows:
        if good is None:
            flag = "INFO"
            same = (va == vb)
            sa, sb = ("一致" if same else "有差异"), ("一致" if same else "有差异")
        else:
            judged += 1
            okn += good
            flag = "PASS" if good else "FAIL"
            sa, sb = str(va), str(vb)
        if len(sa) > 42: sa = sa[:42] + "…"
        if len(sb) > 42: sb = sb[:42] + "…"
        print("  [%-4s] %-14s %-44s | %s" % (flag, name, sa, sb))
    print("  —— %d/%d PASS（另有 %d 项信息项不计判定）" % (okn, judged, len(rows) - judged))

    if chg:
        print("\n公式文本变化（前 10 条）")
        for k in chg[:10]:
            print("  %s" % k)
            print("    旧 %s" % base["formulas"][k][:96])
            print("    新 %s" % now["formulas"][k][:96])
    if miss:
        print("\n丢失的公式（前 10 条）")
        for k in miss[:10]:
            print("  %s  %s" % (k, base["formulas"][k][:96]))
    if add:
        print("\n新增的公式（前 10 条）")
        for k in add[:10]:
            print("  %s  %s" % (k, now["formulas"][k][:96]))

    exp_ok = 0
    if a.expect:
        print("\n文本格核对")
        wb = openpyxl.load_workbook(a.xlsx)
        for item in a.expect:
            if "=" not in item:
                print("  [SKIP] 格式不对 %s" % item)
                continue
            ref, want = item.split("=", 1)
            sh, co = ref.rsplit("!", 1)
            got = wb[sh][co].value
            good = (str(got) == want)
            exp_ok += good
            print("  [%s] %s!%s" % ("PASS" if good else "FAIL", sh, co))
            if not good:
                print("        期望 %s" % want)
                print("        实际 %s" % got)
        print("  —— %d/%d PASS" % (exp_ok, len(a.expect)))

    total_ok = (okn == judged) and (not a.expect or exp_ok == len(a.expect))
    print("\n总判定：%s" % ("全部 PASS" if total_ok else "存在 FAIL，需回滚或逐项排查"))
    return 0 if total_ok else 1


if __name__ == "__main__":
    sys.exit(main())
