#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xl_scan.py — Excel 排版扫描（只读，不改文件）

用法:
    python xl_scan.py 工作簿.xlsx -o 输出目录
    python xl_scan.py 工作簿.xlsx -o 输出目录 --wl-fill 375C63,4A7078 --wl-font 4A4A4A,FFFFFF

产出:
    profile.json     结构指纹（回归核对基准）
    dist.json        分布画像（字体/字号/字色/填充/数字格式/区域字号）
    offenders.tsv    偏离白名单的逐格清单
    summary.txt      人读摘要

只依赖 openpyxl。
"""
import argparse
import collections
import hashlib
import json
import os
import sys

try:
    import openpyxl
    from openpyxl.utils import get_column_letter as gl
except ImportError:
    sys.exit("需要 openpyxl：pip install openpyxl")

# 默认白名单：七色 + 纯白 + 无填充
DEFAULT_WL_FILL = ["NONE", "375C63", "4A7078", "EEF2F2", "FBF6E9", "F5F7F7", "E9D39C", "FFFFFF"]
DEFAULT_WL_FONT = ["4A4A4A", "FFFFFF", "375C63", "2A4A50", "2C6B51", "A93A2E", "theme1", "NONE"]

HDR_ROWS = (1, 2, 3, 4)


def norm_rgb(v):
    """统一成六位大写十六进制；无值返回 NONE"""
    if v is None:
        return "NONE"
    s = str(v).strip()
    if s.startswith("#"):
        s = s[1:]
    s = s.upper()
    if s in ("", "00000000", "NONE"):
        return "NONE"
    return s[-6:] if len(s) >= 6 else s


def font_color_key(fc):
    """字体色归一：主题色记 themeN，RGB 记六位"""
    if fc is None:
        return "NONE"
    try:
        if fc.type == "theme":
            return "theme%s" % fc.theme
    except Exception:
        pass
    if isinstance(fc.rgb, str):
        return norm_rgb(fc.rgb)
    return "NONE"


def scheme_hazard(scheme_cells):
    """带 scheme 的格按填充归类。

    关键判据不是「有没有值」，而是「会不会有人往这里填数」：
      - 黄底（输入色）空白格带 scheme → 一录数就按主题字体渲染，高危
      - 小计行/标题行的空白格带 scheme → 没人会填，不渲染，可以不动
    """
    by_fill = collections.Counter()
    for _n, _co, fk in scheme_cells:
        by_fill[fk] += 1
    return by_fill


def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def merged_skip(ws):
    """返回合并区从属格集合 —— openpyxl 不给从属格写样式，统计必须跳过"""
    skip = set()
    for m in ws.merged_cells.ranges:
        for r in range(m.min_row, m.max_row + 1):
            for c in range(m.min_col, m.max_col + 1):
                if (r, c) != (m.min_row, m.min_col):
                    skip.add((r, c))
    return skip


def cf_count(ws):
    """条件格式计数，兼容 list / 带 .rules 的对象两种结构"""
    areas, rules = 0, 0
    for _rng, rl in ws.conditional_formatting._cf_rules.items():
        areas += 1
        rules += len(rl.rules) if hasattr(rl, "rules") else len(rl)
    return areas, rules


def scan(path, wl_fill, wl_font):
    wb = openpyxl.load_workbook(path)
    prof = collections.OrderedDict()
    prof["source"] = os.path.basename(path)
    prof["md5"] = md5_file(path)
    prof["size"] = os.path.getsize(path)
    prof["sheets"] = len(wb.sheetnames)
    prof["sheetnames"] = list(wb.sheetnames)
    prof["names"] = len(list(wb.defined_names))

    formula_map = {}
    fname = collections.Counter()          # 有值格字体名
    fsize = collections.Counter()
    fname_size = collections.Counter()
    fcolor = collections.Counter()
    fill = collections.Counter()
    nfmt = collections.Counter()
    size_region = collections.defaultdict(collections.Counter)
    size_sheet = collections.defaultdict(collections.Counter)
    bad_fill, bad_font, bad_white = [], [], []
    scheme_stuck = []
    used_cells = 0
    styled_cells = 0
    links = 0
    freeze, grid, tab = {}, {}, {}

    for ws in wb.worksheets:
        n = ws.title
        freeze[n] = str(ws.freeze_panes)
        grid[n] = bool(ws.sheet_view.showGridLines)
        tc = ws.sheet_properties.tabColor
        tab[n] = norm_rgb(tc.rgb) if (tc is not None and isinstance(tc.rgb, str)) else None
        skip = merged_skip(ws)

        for cell in ws._cells.values():
            if (cell.row, cell.column) in skip:
                continue
            styled_cells += 1
            fk = norm_rgb(cell.fill.fgColor.rgb) if cell.fill.fill_type else "NONE"
            fill[fk] += 1
            if fk not in wl_fill:
                bad_fill.append((n, cell.coordinate, fk))

            f = cell.font
            ck = font_color_key(f.color)
            fcolor[ck] += 1
            if f.scheme is not None:
                scheme_stuck.append((n, cell.coordinate, f.name, f.scheme, fk))
            if ck not in wl_font:
                bad_font.append((n, cell.coordinate, ck))

            v = cell.value
            if v is None:
                continue
            used_cells += 1
            fname[f.name] += 1
            fsize[f.sz] += 1
            fname_size[(f.name, f.sz)] += 1
            nfmt[cell.number_format] += 1
            region = "r%d" % cell.row if cell.row in HDR_ROWS else "data"
            size_region[region][f.sz] += 1
            size_sheet[n][f.sz] += 1

            # 白字无底色 = 隐形
            if ck == "FFFFFF" and not cell.fill.fill_type:
                bad_white.append((n, cell.coordinate, str(v)[:40]))
            # 公式
            if isinstance(v, str) and v.startswith("="):
                formula_map["%s!%s" % (n, cell.coordinate)] = v
            if cell.hyperlink is not None:
                links += 1

        if isinstance(ws.conditional_formatting, object):
            pass

    # 汇总
    prof["formulas"] = formula_map
    prof["formula_count"] = len(formula_map)
    d = collections.OrderedDict()
    d["used_cells"] = used_cells
    d["styled_cells"] = styled_cells
    d["font_name"] = dict(fname.most_common())
    d["font_size"] = {str(k): v for k, v in fsize.most_common()}
    d["font_name_size"] = {"%s|%s" % (k[0], k[1]): v for k, v in fname_size.most_common()}
    d["font_color"] = dict(fcolor.most_common())
    d["fill"] = dict(fill.most_common())
    d["number_format"] = dict(nfmt.most_common())
    d["size_by_region"] = {k: {str(a): b for a, b in v.most_common()}
                           for k, v in size_region.items()}
    d["size_by_sheet"] = {k: {str(a): b for a, b in v.most_common(3)}
                          for k, v in size_sheet.items()}
    d["links"] = links
    d["merged_total"] = sum(len(ws.merged_cells.ranges) for ws in wb.worksheets)
    d["merged_by_sheet"] = {ws.title: len(ws.merged_cells.ranges)
                            for ws in wb.worksheets if ws.merged_cells.ranges}
    d["freeze"] = freeze
    d["gridlines"] = grid
    d["tab_color"] = tab
    d["scheme_stuck_count"] = len(scheme_stuck)
    d["white_on_white"] = len(bad_white)
    d["bad_fill_count"] = len(bad_fill)
    d["bad_font_count"] = len(bad_font)
    return wb, prof, d, bad_fill, bad_font, bad_white, scheme_stuck


def main():
    ap = argparse.ArgumentParser(description="Excel 排版扫描（只读）")
    ap.add_argument("xlsx")
    ap.add_argument("-o", "--out", default="scan_out")
    ap.add_argument("--wl-fill", default=",".join(DEFAULT_WL_FILL))
    ap.add_argument("--wl-font", default=",".join(DEFAULT_WL_FONT))
    ap.add_argument("--input-fill", default="FBF6E9",
                    help="待填输入格的颜色（六位），用于判断空格是否需要改字体")
    ap.add_argument("--no-formula-body", action="store_true",
                    help="只在 profile 里存公式哈希，不存全文（体积小，但排查时看不出改了什么）")
    a = ap.parse_args()

    wl_fill = {x.strip().upper() for x in a.wl_fill.split(",") if x.strip()}
    wl_font = {x.strip() for x in a.wl_font.split(",") if x.strip()}

    os.makedirs(a.out, exist_ok=True)
    wb, prof, dist, bf, bn, bw, ss = scan(a.xlsx, wl_fill, wl_font)

    if a.no_formula_body:
        prof["formulas"] = {k: hashlib.md5(v.encode()).hexdigest() for k, v in prof["formulas"].items()}

    # CF / DV 单独收，避免大对象污染 profile
    prof["cf_areas"] = 0
    prof["cf_rules"] = 0
    prof["dv"] = 0
    for ws in wb.worksheets:
        ar, rl = cf_count(ws)
        prof["cf_areas"] += ar
        prof["cf_rules"] += rl
        prof["dv"] += len(ws.data_validations.dataValidation)

    json.dump(prof, open(os.path.join(a.out, "profile.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    json.dump(dist, open(os.path.join(a.out, "dist.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)

    rows = ["表\t坐标\t类型\t值"]
    for n, co, k in bf:
        rows.append("%s\t%s\t填充越界\t%s" % (n, co, k))
    for n, co, k in bn:
        rows.append("%s\t%s\t字色越界\t%s" % (n, co, k))
    for n, co, v in bw:
        rows.append("%s\t%s\t白字无底色\t%s" % (n, co, v))
    for n, co, name, sch, fk in ss:
        rows.append("%s\t%s\t字体带scheme\t%s/%s/填充%s" % (n, co, name, sch, fk))
    open(os.path.join(a.out, "offenders.tsv"), "w", encoding="utf-8").write("\n".join(rows) + "\n")

    L = []
    def w(s=""):
        print(s)
        L.append(s)

    src = os.path.basename(a.xlsx)
    w("=" * 74)
    w("Excel 排版扫描  %s" % src)
    w("=" * 74)
    w("md5          %s" % prof["md5"])
    w("大小         %s 字节" % format(prof["size"], ","))
    w("工作表       %d 张" % prof["sheets"])
    w("公式         %s 条" % format(prof["formula_count"], ","))
    w("条件格式     %s 条（%s 个区域）" % (format(prof["cf_rules"], ","), format(prof["cf_areas"], ",")))
    w("数据验证     %d 项" % prof["dv"])
    w("合并区       %d 处（%d 张表有合并）" % (dist["merged_total"], len(dist["merged_by_sheet"])))
    w("定义名称     %d 个" % prof["names"])
    w("有值单元格   %s" % format(dist["used_cells"], ","))
    w("有样式单元格 %s" % format(dist["styled_cells"], ","))
    w("内部超链接   %d 个" % dist["links"])
    w("")
    w("字体名（有值格）")
    for k, v in list(dist["font_name"].items())[:8]:
        w("  %-24s %s" % (k, format(v, ",")))
    w("")
    w("字号（有值格）")
    for k, v in list(dist["font_size"].items())[:8]:
        w("  %-8s %s" % (k, format(v, ",")))
    w("")
    w("字号按区域（占比前二）")
    for reg in ("r1", "r2", "r3", "r4", "data"):
        if reg not in dist["size_by_region"]:
            continue
        items = list(dist["size_by_region"][reg].items())[:2]
        tot = sum(dist["size_by_region"][reg].values())
        seg = "  ".join("%spt×%s(%.0f%%)" % (k, format(v, ","), v / tot * 100)
                        for k, v in items)
        w("  %-5s %s" % (reg, seg))
    w("")
    w("填充（有样式格）")
    for k, v in list(dist["fill"].items())[:10]:
        mark = "" if k in wl_fill else "   << 越界"
        w("  %-8s %s%s" % (k, format(v, ","), mark))
    w("")
    w("字色（有样式格）")
    for k, v in list(dist["font_color"].items())[:10]:
        mark = "" if k in wl_font else "   << 越界"
        w("  %-10s %s%s" % (k, format(v, ","), mark))
    w("")
    w("数字格式 %d 种" % len(dist["number_format"]))
    for k, v in list(dist["number_format"].items())[:10]:
        w("  %-34s %s" % (repr(k)[:34], format(v, ",")))
    w("")
    w("专项审计")
    w("  [%s] 填充越界          %d 格" % ("PASS" if not bf else "WARN", len(bf)))
    w("  [%s] 字色越界          %d 格" % ("PASS" if not bn else "WARN", len(bn)))
    w("  [%s] 白字无底色(隐形)   %d 格" % ("PASS" if not bw else "WARN", len(bw)))
    sch_by_fill = scheme_hazard([(a, b, e) for a, b, c, d, e in ss])
    input_hit = sch_by_fill.get(a.input_fill.upper(), 0)
    if not ss:
        w("  [PASS] 字体带scheme      0 格")
    else:
        w("  [%s] 字体带scheme      %d 格  按填充 %s"
          % ("WARN" if input_hit else "INFO", len(ss),
             dict(sch_by_fill.most_common(5))))
        if input_hit:
            w("        ^^ 其中 %d 格是填报列（%s 底）：一录数就按主题字体渲染，必须清 scheme"
              % (input_hit, a.input_fill.upper()))
        else:
            w("        ^^ 均为小计行/标题行空白格，无人填数、不参与渲染，可不动")
    for n, co, v in bw[:5]:
        w("        %s!%s  %s" % (n, co, v))
    w("")
    w("产物：%s/{profile.json, dist.json, offenders.tsv, summary.txt}" % a.out)
    open(os.path.join(a.out, "summary.txt"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
