#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xl_preview.py — 局部渲染，用于肉眼核对版面（只读）

用法:
    # 渲染单区域
    python xl_preview.py 工作簿.xlsx --sheet "S01 数据看板" --range 1-12 --cols 1-17 -o p.html

    # 改前 vs 改后并排
    python xl_preview.py 改后.xlsx --against 改前.xlsx \
        --sheet "B05 房源台账" --range 4-6 --cols 28-33 -o cmp.html

设计要点（三条都是踩过坑才加的）:
    1. 必须带行号列 —— 渲染器把合并区展开错时，没有行号会误判成表格本身有问题
    2. 白字白底标洋红 —— 隐形格自动跳出来，不用逐格查
    3. 并排渲染 —— 单选看不出「这格本来是什么样」
"""
import argparse
import sys
from html import escape

try:
    import openpyxl
    from openpyxl.utils import get_column_letter as gl
except ImportError:
    sys.exit("需要 openpyxl：pip install openpyxl")

HIDE = "〔公式〕"


def parse_range(s):
    if "-" in s:
        a, b = s.split("-", 1)
        return int(a), int(b)
    v = int(s)
    return v, v


def col_px(width):
    """Excel 列宽单位 → 近似像素"""
    return int((width or 8.43) * 7 + 5)


def render(path, sheet, r1, r2, c1, c2, title, show_formula_text=True):
    wb = openpyxl.load_workbook(path)
    if sheet not in wb.sheetnames:
        cand = [n for n in wb.sheetnames if n.startswith(sheet)]
        if not cand:
            raise SystemExit("找不到工作表：%s\n可选：%s" % (sheet, wb.sheetnames))
        sheet = cand[0]
    ws = wb[sheet]

    # 合并区：锚点记 span，从属格跳过
    span, skip = {}, set()
    for m in ws.merged_cells.ranges:
        if m.max_row < r1 or m.min_row > r2:
            continue
        span[(m.min_row, m.min_col)] = (m.max_col - m.min_col + 1, m.max_row - m.min_row + 1)
        for r in range(m.min_row, m.max_row + 1):
            for c in range(m.min_col, m.max_col + 1):
                if (r, c) != (m.min_row, m.min_col):
                    skip.add((r, c))

    widths = {}
    for c in range(c1, c2 + 1):
        letter = gl(c)
        dim = ws.column_dimensions.get(letter)
        widths[c] = col_px(dim.width if dim else 8.43)

    out = []
    for r in range(r1, r2 + 1):
        h = ws.row_dimensions[r].height
        hpx = int(h * 4 / 3) if h else 20
        tds = ['<td class="rn">%d</td>' % r]
        for c in range(c1, c2 + 1):
            if (r, c) in skip:
                continue
            cell = ws.cell(r, c)
            v = cell.value
            if isinstance(v, str) and v.startswith("="):
                v = v if show_formula_text else HIDE
            bg = "#" + str(cell.fill.fgColor.rgb)[-6:] if cell.fill.fill_type else "#ffffff"
            fc = cell.font.color
            color = "#" + str(fc.rgb)[-6:] if (fc is not None and isinstance(fc.rgb, str)) else "#000000"
            if color.upper() == "#FFFFFF" and bg.upper() == "#FFFFFF":
                color = "#FF00FF"          # 白字白底 → 洋红，提示隐形
            fsz = cell.font.sz or 11
            bold = 600 if cell.font.bold else 400
            al = cell.alignment.horizontal or "left"
            indent = "padding-left:%dpx;" % (4 + (cell.alignment.indent or 0) * 8)
            attr = ""
            if (r, c) in span:
                w, hh = span[(r, c)]
                if w > 1:
                    attr += ' colspan="%d"' % w
                if hh > 1:
                    attr += ' rowspan="%d"' % hh
            tds.append(
                '<td%s style="background:%s;color:%s;font-size:%.1fpt;font-weight:%d;'
                'text-align:%s;%s">%s</td>'
                % (attr, bg, color, fsz, bold, al, indent,
                   escape(str(v)) if v is not None else ""))
        out.append('<tr style="height:%dpx">%s</tr>' % (hpx, "".join(tds)))

    head = "".join('<th style="width:%dpx;min-width:%dpx">%s</th>' % (widths[c], widths[c], gl(c))
                   for c in range(c1, c2 + 1))
    return ('<div class="blk"><div class="cap">%s</div>'
            '<table><thead><tr><th class="rn"></th>%s</tr></thead><tbody>%s</tbody></table></div>'
            % (escape(title), head, "".join(out)))


CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{background:#fff;padding:14px;font-family:"PingFang SC","Microsoft YaHei",sans-serif}
.blk{margin-bottom:22px}
.cap{font-size:11pt;font-weight:600;color:#12395B;margin-bottom:6px}
table{border-collapse:collapse;table-layout:fixed}
th{background:#375C63;color:#fff;font-size:8.5pt;font-weight:600;padding:3px 4px;
   border:1px solid #2c4a50;text-align:center}
td{border:1px solid #d8d8d8;padding:2px 5px;white-space:nowrap;overflow:hidden;
   text-overflow:ellipsis;vertical-align:middle}
td.rn{background:#EEE;color:#888;font-size:7.5pt;text-align:right;width:34px;min-width:34px;
      font-family:"SF Mono",Menlo,monospace;padding:2px 4px}
.note{font-size:8.5pt;color:#666;margin-bottom:10px}
"""


def main():
    ap = argparse.ArgumentParser(description="Excel 局部渲染（只读）")
    ap.add_argument("xlsx")
    ap.add_argument("--sheet", required=True)
    ap.add_argument("--range", default="1-20", help="行范围，如 4-12")
    ap.add_argument("--cols", default="1-12", help="列范围，如 1-17")
    ap.add_argument("--against", help="对比文件（改前），并排渲染")
    ap.add_argument("--formula-text", action="store_true", help="显示公式原文而非占位符")
    ap.add_argument("-o", "--out", default="preview.html")
    a = ap.parse_args()

    r1, r2 = parse_range(a.range)
    c1, c2 = parse_range(a.cols)

    body = ""
    if a.against:
        body += ('<div class="note">左：改前（%s）　右／下：改后（%s）　'
                 '洋红色＝白字白底（隐形格）</div>'
                 % (escape(a.against.split("/")[-1]), escape(a.xlsx.split("/")[-1])))
        body += render(a.against, a.sheet, r1, r2, c1, c2,
                       "改前 · %s · r%d—r%d" % (a.sheet, r1, r2), a.formula_text)
        body += render(a.xlsx, a.sheet, r1, r2, c1, c2,
                       "改后 · %s · r%d—r%d" % (a.sheet, r1, r2), a.formula_text)
    else:
        body += render(a.xlsx, a.sheet, r1, r2, c1, c2,
                       "%s · r%d—r%d" % (a.sheet, r1, r2), a.formula_text)

    html = ('<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
            '<title>预览 %s</title><style>%s</style></head><body>%s</body></html>'
            % (escape(a.sheet), CSS, body))
    open(a.out, "w", encoding="utf-8").write(html)
    print("已写出 %s" % a.out)
    print("看什么：标题带是否连贯 / 列头层级 / 明细区有无彩色竖条 / "
          "长文本是否截断 / 有无洋红")
    return 0


if __name__ == "__main__":
    sys.exit(main())
