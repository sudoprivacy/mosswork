#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xl_apply.py — 按规范套用格式（三态：plan / apply / verify）

用法:
    python xl_apply.py 工作簿.xlsx --spec spec.json --mode plan
    python xl_apply.py 工作簿.xlsx --spec spec.json --mode apply
    python xl_apply.py 工作簿.xlsx --spec spec.json --mode verify

设计原则:
    只做「低风险、可全自动」的四类改动，其余留给人工按表配置：
      ① 字体名统一 + 清 font.scheme（红线 3）
      ② 行角色填充与字色（按规则判定）
      ③ r1—r4 表头样式（按字体阶梯）
      ④ 白名单审计（只报告，不改）
    明确不做：数字格式改写、列宽行高、合并区增删、表头行序调整
    —— 这四类需要按表判断语义，脚本猜不准，硬做会毁版。

安全护栏:
    - 不修改任何单元格的 value（公式与常量一律不动）
    - 不新增/删除合并区、条件格式、数据验证
    - apply 前自动备份到 _rollback/
    - verify 逐项比对，任何 FAIL 退出码 1

依赖: openpyxl
"""
import argparse
import collections
import hashlib
import json
import os
import re
import shutil
import sys
from copy import copy

try:
    import openpyxl
except ImportError:
    sys.exit("需要 openpyxl：pip install openpyxl")

CN_NUM = re.compile(r"^[一二三四五六七八九十]+、")


# ---------- 基础工具 ----------

def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def norm_rgb(v):
    if v is None:
        return "NONE"
    s = str(v).strip().lstrip("#").upper()
    if s in ("", "00000000", "NONE"):
        return "NONE"
    return s[-6:] if len(s) >= 6 else s


def argb(hex6):
    """六位 → openpyxl 需要的 ARGB 八位"""
    if not hex6:
        return None
    h = hex6.lstrip("#").upper()
    return "FF" + h if len(h) == 6 else h


def merged_skip(ws):
    skip = set()
    for m in ws.merged_cells.ranges:
        for r in range(m.min_row, m.max_row + 1):
            for c in range(m.min_col, m.max_col + 1):
                if (r, c) != (m.min_row, m.min_col):
                    skip.add((r, c))
    return skip


def should_touch(cell, spec):
    """是否值得改这个格的字体。

    只处理两类：① 有值格；② 填报色（黄底）的空白格——一录数就会露出字体。
    纯空白格（无值、非填报色）不碰：不参与渲染，写了只让文件变大（红线 13）。
    """
    if cell.value is not None:
        return True
    if not cell.fill.fill_type:
        return False
    fk = norm_rgb(cell.fill.fgColor.rgb)
    return fk == norm_rgb(spec["palette"].get("input", "FBF6E9"))


def full_row_merged(ws, row):
    """该行是否有一处合并覆盖「第 1 列到末列」"""
    for m in ws.merged_cells.ranges:
        if m.min_row == row == m.max_row and m.min_col == 1 and m.max_col >= ws.max_column - 1:
            return True
    return False


def row_text(ws, row, max_col=4):
    parts = []
    for c in range(1, min(max_col, ws.max_column) + 1):
        v = ws.cell(row, c).value
        if isinstance(v, str) and not v.startswith("="):
            parts.append(v)
    return " ".join(parts)


# ---------- 行角色判定 ----------

def judge_role(ws, row, spec):
    """判定顺序不可乱：整行合并 → 中文序号 → 特殊 → 合计 → 小计 → 表头 → 明细"""
    hdr = spec["header"]["rows"]
    if row <= hdr:
        return "HEADER"
    if full_row_merged(ws, row):
        return "BLOCK"
    a = ws.cell(row, 1).value
    if isinstance(a, str) and CN_NUM.match(a.strip()):
        return "BLOCK"
    t = row_text(ws, row)
    rr = spec["row_roles"]
    for kw in rr.get("special_keywords", []):
        if kw in t:
            return "SPECIAL"
    for kw in rr.get("total_keywords", []):
        if kw in t:
            return "TOTAL"
    for kw in rr.get("subtotal_keywords", []):
        if kw in t:
            return "SUBTOTAL"
    if any(ws.cell(row, c).value is not None for c in range(1, ws.max_column + 1)):
        return "DETAIL"
    return "EMPTY"


# ---------- 单表处理 ----------

def plan_sheet(ws, spec, changes):
    """只读统计：每个角色多少行、会被改多少格"""
    roles = collections.Counter()
    for r in range(1, ws.max_row + 1):
        role = judge_role(ws, r, spec)
        roles[role] += 1
        if role == "EMPTY":
            continue
        skip = merged_skip(ws)
        for c in range(1, ws.max_column + 1):
            if (r, c) in skip:
                continue
            cell = ws.cell(r, c)
            if not should_touch(cell, spec):
                continue
            want_fill, want_color, want_size, want_bold = style_for(role, cell, spec)
            if will_change(cell, want_fill, want_color, want_size, want_bold, spec):
                changes.append((ws.title, cell.coordinate, role,
                                norm_rgb(cell.fill.fgColor.rgb) if cell.fill.fill_type else "NONE",
                                want_fill or "NONE"))
    return roles


def style_for(role, cell, spec):
    """按角色给出目标样式。返回 (fill_hex|None, font_color_hex|None, size|None, bold)"""
    pal = spec["palette"]
    fnt = spec["font"]
    lad = fnt["ladder"]
    col = fnt["color"]
    is_formula = isinstance(cell.value, str) and cell.value.startswith("=")
    cur_fill = norm_rgb(cell.fill.fgColor.rgb) if cell.fill.fill_type else "NONE"
    is_input = cur_fill == norm_rgb(pal.get("input", "FBF6E9"))

    if role == "BLOCK":
        return pal.get("block"), col.get("banner"), lad.get("data"), True
    if role == "TOTAL":
        return pal.get("block"), col.get("banner"), lad.get("data"), True
    if role == "SUBTOTAL":
        return pal.get("subtotal"), None, None, None
    if role == "SPECIAL":
        return None, None, None, None              # 结论行按原色归并，不整行刷深色
    if role == "DETAIL":
        if is_input:
            return pal.get("input"), col.get("input"), None, None
        # 只洗「计算列标记色」（如 2E75B6），别的一律不动：
        # 明细区可能还有分组底色（EEF2F2），一律转无填充会把分组视觉一起洗掉
        markers = {norm_rgb(x) for x in pal.get("calc_marker_fills", ["2E75B6"])}
        if cur_fill in markers:
            return "NONE", None, None, None
        return None, None, None, None
    return None, None, None, None


def will_change(cell, want_fill, want_color, want_size, want_bold, spec):
    cur_fill = norm_rgb(cell.fill.fgColor.rgb) if cell.fill.fill_type else "NONE"
    if want_fill is not None:
        tgt = "NONE" if want_fill == "NONE" else norm_rgb(want_fill)
        if cur_fill != tgt:
            return True
    if cell.font.name != spec["font"]["family"] or cell.font.scheme is not None:
        return True
    if want_color is not None:
        cur = cell.font.color
        cur_rgb = norm_rgb(cur.rgb) if (cur is not None and isinstance(cur.rgb, str)) else "NONE"
        if cur_rgb != norm_rgb(want_color):
            return True
    if want_size is not None and cell.font.sz != want_size:
        return True
    if want_bold is not None and bool(cell.font.bold) != bool(want_bold):
        return True
    return False


def apply_sheet(ws, spec, stats, only=None):
    """真正写样式。只改 font / fill 两个对象，不碰 value"""
    from openpyxl.styles import PatternFill, Font, Color

    pal = spec["palette"]
    fnt = spec["font"]
    lad = fnt["ladder"]
    col = fnt["color"]
    family = fnt["family"]
    ladder_sizes = set(v for v in lad.values() if v)

    do_font = only in (None, "font", "all")
    do_role = only in (None, "role", "all")
    do_header = only in (None, "header", "all")

    # 表头四行：按阶梯统一字号与字体名
    hdr_sizes = {1: lad.get("banner"), 2: lad.get("attr"),
                 3: lad.get("note"), 4: lad.get("header")}
    for r, size in (hdr_sizes.items() if do_header else []):
        if r > ws.max_row:
            continue
        for c in range(1, ws.max_column + 1):
            cell = ws.cell(r, c)
            if not should_touch(cell, spec):
                continue
            f = copy(cell.font)
            touched = False
            if f.name != family or f.scheme is not None:
                f.name = family
                f.scheme = None
                f.charset = None
                touched = True
            if size and f.sz != size:
                f.sz = size
                touched = True
            if touched:
                cell.font = f
                stats["font"] += 1

    skip = merged_skip(ws)
    for r in range(1, ws.max_row + 1):
        role = judge_role(ws, r, spec)
        stats["roles"][role] += 1
        if role in ("EMPTY", "HEADER") or not do_role:
            # 即便不做角色，也要把字体名/scheme 清掉
            if do_font and role not in ("EMPTY",):
                for c in range(1, ws.max_column + 1):
                    if (r, c) in skip:
                        continue
                    cell = ws.cell(r, c)
                    if not should_touch(cell, spec):
                        continue
                    f = copy(cell.font)
                    if f.name != family or f.scheme is not None:
                        f.name = family
                        f.scheme = None
                        f.charset = None
                        cell.font = f
                        stats["font"] += 1
            continue
        for c in range(1, ws.max_column + 1):
            if (r, c) in skip:
                continue
            cell = ws.cell(r, c)
            if not should_touch(cell, spec):
                continue
            want_fill, want_color, want_size, want_bold = style_for(role, cell, spec)
            if not will_change(cell, want_fill, want_color, want_size, want_bold, spec):
                continue
            # 字体
            f = copy(cell.font)
            if f.name != family or f.scheme is not None:
                f.name = family
                f.scheme = None
                f.charset = None
                stats["font"] += 1
            cur_c = norm_rgb(f.color.rgb) if (f.color is not None and isinstance(f.color.rgb, str)) else "NONE"
            if want_color is not None and cur_c != norm_rgb(want_color):
                f.color = Color(rgb="FF" + norm_rgb(want_color))
                stats["font_color"] += 1
            if want_size is not None and f.sz != want_size:
                f.sz = want_size
            if want_bold is not None:
                f.bold = want_bold
            cell.font = f
            # 填充
            if want_fill is not None:
                if want_fill == "NONE":
                    cell.fill = PatternFill(fill_type=None)
                else:
                    cell.fill = PatternFill("solid", fgColor="FF" + norm_rgb(want_fill))
                stats["fill"] += 1


# ---------- 三态 ----------

SPEC_KEYS = ("palette", "font", "row_roles", "header", "exceptions")


def load_spec(path):
    spec = json.load(open(path, encoding="utf-8"))
    miss = [k for k in SPEC_KEYS if k not in spec]
    if miss:
        sys.exit("spec 缺字段：%s" % miss)
    return spec


def do_plan(path, spec):
    wb = openpyxl.load_workbook(path)
    changes = []
    all_roles = collections.Counter()
    print("=" * 76)
    print("PLAN（只读预演）  %s" % os.path.basename(path))
    print("=" * 76)
    print("md5 %s   大小 %s" % (md5_file(path), format(os.path.getsize(path), ",")))
    print("")
    print("%-26s %6s %8s %8s %8s %8s" % ("工作表", "BLOCK", "SUBTOTAL", "TOTAL", "DETAIL", "待改格"))
    for ws in wb.worksheets:
        before = len(changes)
        roles = plan_sheet(ws, spec, changes)
        all_roles.update(roles)
        print("%-26s %6d %8d %8d %8d %8d"
              % (ws.title[:26], roles["BLOCK"], roles["SUBTOTAL"],
                 roles["TOTAL"], roles["DETAIL"], len(changes) - before))
    print("")
    print("角色合计  %s" % dict(all_roles))
    print("待改单元格 %s" % format(len(changes), ","))
    print("")
    print("红线自检（plan 阶段）")
    wb2 = openpyxl.load_workbook(path)
    formula_n = sum(1 for ws in wb2.worksheets for c in ws._cells.values()
                    if isinstance(c.value, str) and c.value.startswith("="))
    stuck_input = 0
    for ws in wb2.worksheets:
        sk = merged_skip(ws)
        for c in ws._cells.values():
            if (c.row, c.column) in sk:
                continue
            if c.font.scheme is not None and c.fill.fill_type:
                if norm_rgb(c.fill.fgColor.rgb) == norm_rgb(spec["palette"].get("input", "FBF6E9")):
                    stuck_input += 1
    print("  公式 %s 条（本脚本不改 value，改完应完全相等）" % format(formula_n, ","))
    print("  填报格带 scheme（一录数就露字体）：%d 格 %s"
          % (stuck_input, "" if stuck_input else "— 无需处理"))
    print("")
    print("本脚本只做：字体名统一＋清 scheme、行角色填充与字色、r1—r4 表头阶梯")
    print("明确不做：数字格式改写、列宽行高、合并区增删、表头行序调整")
    print("         这四类需按表判断语义，见 references/02-设计规范.md")
    return 0


def do_apply(path, spec, only="all"):
    bak_dir = os.path.join(os.path.dirname(os.path.abspath(path)), "_rollback")
    os.makedirs(bak_dir, exist_ok=True)
    bak = os.path.join(bak_dir, "格式套用_备份.xlsx")
    shutil.copy2(path, bak)
    print("已备份 → %s" % bak)
    before = md5_file(path)

    wb = openpyxl.load_workbook(path)
    stats = collections.Counter()
    stats["roles"] = collections.Counter()
    for ws in wb.worksheets:
        apply_sheet(ws, spec, stats, only)
    wb.save(path)

    after = md5_file(path)
    print("=" * 76)
    print("APPLY 完成")
    print("=" * 76)
    print("md5  %s → %s" % (before, after))
    print("大小 %s → %s" % (format(os.path.getsize(bak), ","), format(os.path.getsize(path), ",")))
    print("")
    print("改动统计")
    print("  字体（名 + scheme）  %s 格" % format(stats["font"], ","))
    print("  字体色               %s 格" % format(stats["font_color"], ","))
    print("  填充                 %s 格" % format(stats["fill"], ","))
    print("  角色分布             %s" % dict(stats["roles"]))
    print("")
    print("下一步：python xl_verify.py %s --against %s" % (os.path.basename(path), bak))
    return 0


def do_verify(path, spec, baseline):
    from xl_verify import fingerprint, compare, from_baseline
    print("=" * 76)
    print("VERIFY  %s" % os.path.basename(path))
    print("=" * 76)
    now = fingerprint(path)
    base = from_baseline(baseline) if baseline else None
    if base is None:
        sys.exit("verify 需要 --baseline <profile.json>")
    rows, miss, add, chg = compare(base, now)
    okn = judged = 0
    for name, va, vb, good in rows:
        if good is None:
            same = (va == vb)
            print("  [INFO] %-14s %-42s | %s"
                  % (name, "一致" if same else "有差异", "一致" if same else "有差异"))
            continue
        judged += 1
        okn += good
        sa, sb = str(va), str(vb)
        if len(sa) > 40: sa = sa[:40] + "…"
        if len(sb) > 40: sb = sb[:40] + "…"
        print("  [%s] %-14s %-42s | %s" % ("PASS" if good else "FAIL", name, sa, sb))
    print("  —— %d/%d PASS（另有 %d 项信息项）" % (okn, judged, len(rows) - judged))
    if chg:
        print("\n公式文本变化 %d 条（本脚本不该产生，务必排查）" % len(chg))
        for k in chg[:5]:
            print("  %s\n    旧 %s\n    新 %s" % (k, base["formulas"][k][:90], now["formulas"][k][:90]))
    ok = (okn == judged)
    print("\n总判定：%s" % ("全部 PASS" if ok else "存在 FAIL，从 _rollback/ 回滚"))
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(description="按规范套用 Excel 格式（三态）")
    ap.add_argument("xlsx")
    ap.add_argument("--spec", default=os.path.join(os.path.dirname(__file__),
                                                   "..", "assets", "spec_default.json"))
    ap.add_argument("--mode", choices=["plan", "apply", "verify"], default="plan")
    ap.add_argument("--baseline", help="扫描基线 profile.json（verify 用）")
    ap.add_argument("--only", choices=["font", "role", "header", "all"], default="all",
                    help="分步执行：先 font（只改字体名与 scheme），再 role（填充与字色），最后 header")
    a = ap.parse_args()

    spec = load_spec(a.spec)
    if a.mode == "plan":
        return do_plan(a.xlsx, spec)
    if a.mode == "apply":
        return do_apply(a.xlsx, spec, a.only)
    return do_verify(a.xlsx, spec, a.baseline)


if __name__ == "__main__":
    sys.exit(main())
