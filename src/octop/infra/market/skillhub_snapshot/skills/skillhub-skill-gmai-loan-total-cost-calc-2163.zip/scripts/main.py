#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""果盟精选 4019（贷款综合成本测算） —— 付费计算引擎（X402 fail-closed 闸门）

规则：无 --payment-proof 拒绝输出（退出码 3 / PAYMENT_REQUIRED）；凭证格式无效退出码 3；
缺必填字段退出码 2 并指明字段名；凭证有效时现场实算并输出报告到 output/。
"""
import argparse
import datetime
import json
import math
import os
import re
import sys

VERSION = "1.0.0"
SLUG = "gmai-loan-total-cost-calc-2163"
FEN = 490
FIELDS = [('principal', '贷款本金（元）', 300000), ('nominal_rate', '名义年利率(0-1)', 0.06), ('months', '期限（月）', 24), ('fee', '一次性服务费（元）', 9000)]
ANCHORS = ['民法典第670条：借款利息不得预先在本金中扣除', '最高人民法院民间借贷司法解释：利率上限为一年期LPR的4倍']
PROOF_RE = re.compile(r"^X402-[A-Za-z0-9]{16,64}$")
BODY = '''
interest=float(I['principal'])*float(I['nominal_rate'])*float(I['months'])/12
fee_rate=float(I['fee'])/float(I['principal'])
real_rate=float(I['nominal_rate'])+fee_rate*12/float(I['months'])
details=[f"利息支出 {m2(interest)} 元","服务费 "+m2(float(I['fee']))+" 元（占本金"+m2(fee_rate*100)+"%）",
         f"综合年化成本约 {m2(real_rate*100)}%（简化口径，未做现金流折现）"]
result=f"综合年化约 {m2(real_rate*100)}%"
verdict="实际年化应以IRR口径重算；一次性费用前置会显著抬高真实成本"
'''


def m2(x):
    return format(float(x), ",.2f")


def n0(x):
    return format(int(round(float(x))), ",")


def fail402(msg):
    print(json.dumps({"code": "PAYMENT_REQUIRED", "message": msg, "skill_slug": SLUG,
                      "price_fen": FEN, "currency": "CNY"}, ensure_ascii=False))
    return 3


def compute(data):
    details, result, verdict = [], "", ""
    g = {"I": data, "m2": m2, "n0": n0, "math": math,
         "details": details, "result": result, "verdict": verdict}
    exec(BODY, g)
    return g["details"], g["result"], g["verdict"]


def write_report(data, details, result, verdict, proof):
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, "deliverable_%s_%s.md" % (SLUG, ts))
    rows_in = "\n".join("| %s | %s |" % (lab, data.get(k, "")) for k, lab, _ in FIELDS)
    rows_calc = "\n".join("- %s" % d for d in details)
    rows_anchor = "\n".join("- %s" % a for a in ANCHORS)
    doc = """# 果盟精选 4019（贷款综合成本测算） · 测算报告

- 生成时间：%s
- 技能：%s（%s）
- 支付凭证：已验（X402，尾号 %s）

## 一、输入回显

| 字段 | 值 |
|---|---|
%s

## 二、计算过程

%s

## 三、结果

**%s**

## 四、判定与建议

%s

## 五、计算口径与真实锚点

%s

## 六、复算说明

本报告全部数字由程序按上述口径实算；把输入数值代入对应公式即可复算验证。引擎版本 %s。
""" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "果盟精选 4019（贷款综合成本测算）", SLUG,
       proof[-4:], rows_in, rows_calc, result, verdict, rows_anchor, VERSION)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(doc)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="")
    ap.add_argument("--payment-proof", default="")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()

    if a.selftest:
        assert not PROOF_RE.match(""), "无凭证必须不匹配"
        assert not PROOF_RE.match("X402-short"), "短凭证必须不匹配"
        assert PROOF_RE.match("X402-SELFTEST0000000000000000"), "合法凭证必须匹配"
        data = {k: d for k, _, d in FIELDS}
        details, result, verdict = compute(data)
        assert result and verdict and details, "默认输入必须可算出非空结果"
        print("selftest PASS: gate=ok calc=ok price_fen=%d version=%s" % (FEN, VERSION))
        return 0

    if not PROOF_RE.match(a.payment_proof or ""):
        return fail402("未检测到有效支付凭证（--payment-proof），拒绝交付。请先完成支付（HTTP 402）后带 X402-<订单号> 凭证重试。")
    if not a.input:
        print("缺少 --input 输入文件")
        return 2
    try:
        with open(a.input, encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print("输入文件不可读:", e)
        return 2
    missing = [lab for k, lab, _ in FIELDS if (k not in data) or (str(data[k]).strip() == "")]
    if missing:
        print("缺少必填字段:", "、".join(missing))
        return 2
    details, result, verdict = compute(data)
    path = write_report(data, details, result, verdict, a.payment_proof)
    print("PAYMENT_OK skill=%s price_fen=%d" % (SLUG, FEN))
    print("RESULT:", result)
    print("VERDICT:", verdict)
    print("REPORT:", path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
