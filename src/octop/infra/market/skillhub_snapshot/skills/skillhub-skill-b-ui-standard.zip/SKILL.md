---
name: skillhub-skill-b-ui-standard
description: "{"
---

{
  "name": "B端中性风标准化UI界面一键生成",
  "description": "生成符合腾讯云、字节火山、阿里AntD v5的B端后台界面，遵循低干扰、高效率、弱装饰设计原则，输出设计Token、栅格、组件规范、前端CSS变量，支持明暗双模式。",
  "skill_type": "human_custom",
  "version": "1.0.0",
  "tags": ["UI设计","B端后台","中台系统","组件化设计"]
}