# 趣搜 GEO 后台文章推送接口规范

将文章保存到趣搜 GEO 后台时，使用本接口。推荐通过 `scripts/push_article.py` 调用（已处理 JSON 转义与错误码），本文件记录底层接口细节，供排查问题或手动调用时参考。

## 接口信息

| 项 | 值 |
|----|----|
| 方法 | `POST` |
| 地址 | `{api_url}/restful/api.json?secret_key={密钥}` |
| 请求头 | `Content-Type: application/json` |
| 超时建议 | 30 秒 |

密钥（`secret_key`）由用户在后台获取，地址：`{backend_url}/#/user/secretkey`。若无密钥：点击「新增密钥」并勾选「授权 WorkBuddy」，创建后复制新密钥。

## 请求体（JSON）

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `id` | int | 是 | 文章 ID。`0` 表示新增；`>0` 表示修改对应 ID 的已有文章 |
| `action` | string | 是 | 固定为 `push_article` |
| `title` | string | 是 | 文章标题 |
| `question` | string | 是 | 创作方向（与文章一同保存到后台） |
| `content` | string | 是 | 文章正文，Markdown 格式 |
| `template` | string | 否 | 模板类型（取值：`brand` / `brand_different` / `ranking` / `product_service` / `industry_qa` / `video` / `virtualman_broadcast`），默认空。创建于第 2 步确认的模板后，建议显式传入以便后台识别文章类型 |

示例：

```json
{
  "id": 0,
  "action": "push_article",
  "title": "yuchong test",
  "question": "yuchong 怎么用",
  "content": "### test\n你好  1232",
  "template": "brand"
}
```

## 响应

成功（`code=0`）时返回 `data`，其中 `id` 为文章 ID（新增时是后台分配的新 ID，修改时等于请求的 ID）：

```json
{
  "code": 0,
  "data": {
    "uid": 1,
    "team_id": 1,
    "knowledge_id": 15,
    "title": "yuchong test",
    "content": "### test\n你好  1232",
    "content_html": "<h3>test</h3>\n<p>&emsp;&emsp;你好  1232</p>",
    "updated_at": "2026-09-08 11:32:24",
    "id": 18
  }
}
```

> **预览地址**：`{backend_url}/#/creation/preview/{id}`，其中 `{backend_url}` 取自 `scripts/config.py` 的 `CONFIG["backend_url"]`，`{id}` 替换为 `data.id`。保存成功后必须把预览地址告知用户，方便打开核查内容。

失败（`code>0`）时返回错误码与提示，常见如无效密钥：

```json
{
  "code": 1001,
  "msg": "无效密钥"
}
```

## 手动调用示例（curl）

```bash
curl --location --request POST '{api_url}/restful/api.json?secret_key={密钥}' \
  --header 'Content-Type: application/json' \
  --header 'Accept: */*' \
  --data-raw '{
    "id": 0,
    "action": "push_article",
    "title": "文章标题",
    "question": "创作方向",
    "content": "### 小标题\n正文内容",
    "template": "brand"
  }'
```

> 注意：`content` 含换行、引号等字符时，直接用 curl 拼接 JSON 容易出错，建议改用 `scripts/push_article.py`，它会用 `json.dumps` 正确转义。
