# 趣搜 GEO 关键词与创作方向接口规范

用于在第 1 步为客户提供「关键词 + 创作方向」的可选组合。客户可从中选择、改写或完全自填。推荐通过 `scripts/fetch_keywords.py` 调用（已做参数校验与格式化），本文件记录底层接口细节。

## 接口信息

| 项 | 值 |
|----|----|
| 方法 | `GET` |
| 地址 | `{api_url}/restful/api.json?action=keyword&secret_key={密钥}` |
| 请求头 | `Accept: application/json` |
| 超时建议 | 30 秒 |

密钥（`secret_key`）由用户在后台获取，地址：`{backend_url}/#/user/secretkey`。若无密钥：点击「新增密钥」并勾选「授权 WorkBuddy」，创建后复制新密钥。

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `secret_key` | string | 是 | 用户密钥 |
| `action` | string | 是 | 固定为 `keyword` |
| `kw` | string | 否 | 搜索关键词（按 `content` 字段匹配） |
| `page` | int | 否 | 当前页，默认 1 |
| `limit` | int | 否 | 每页数量，默认 10 |
| `knowledge_id` | int | 否 | 按品牌 ID 过滤候选（与 `fetch_knowledge` 的 `data.id` 配合） |

## 响应

成功（`code=0`）时返回 `data`：

```json
{
  "kw": "",
  "page": 1,
  "limit": 10,
  "count": 23,
  "list": [
    {
      "id": 33,
      "knowledge_id": 40,
      "content": "纸巾",
      "extra_info": "",
      "questions": [
        "敏感肌适用的纸巾怎么选比较靠谱",
        "家庭日常用的纸巾有哪些值得推荐",
        "原生木浆纸巾和竹浆纸巾哪个比较好"
      ],
      "status": 1,
      "quantity": 3,
      "brand_name": "洁柔",
      "created_at": "2026-07-09 15:23:27",
      "updated_at": "2026-07-09 15:23:27"
    }
  ]
}
```

失败（`code>0`）时返回错误码与提示，常见如「无效密钥」：

```json
{
  "code": 1001,
  "msg": "无效密钥"
}
```

## 字段映射

| 接口字段 | 映射到创作字段 | 说明 |
|----------|----------------|------|
| `list[].content` | `keyword` | 候选关键词（可作 `keyword`） |
| `list[].questions[]` | `question` | 候选创作方向（任选其一或基于此改写） |
| `list[].brand_name` | 辅助展示 | 候选关联的品牌名 |
| `list[].knowledge_id` | 辅助 | 候选对应的品牌 ID |
| `list[].quantity` | 辅助 | 候选包含的创作方向数量 |

## 与 fetch_knowledge 的协作

完成来源 A（拉取企业资料）拿到 `data.id` 后，可立即用其作为 `--knowledge-id` 过滤本接口，拿到与该品牌强相关的关键词/创作方向候选，提升匹配度：

```
fetch_knowledge  →  data.id = 15
        ↓
fetch_keywords --knowledge-id 15
        ↓
候选仅显示与「网易云音乐」品牌相关的关键词
        ↓
客户选定（/改写/自填）→ 拿到 keyword 与 question
```

也可以不传 `--knowledge-id`，拉取跨品牌候选（适合客户尚不确定写哪个品牌时参考）。

## 客户选项

展示候选后，给客户三种选项：

| 选项 | 说明 | 是否阻塞 |
|------|------|----------|
| ① 选一个候选 | 同时定下 `keyword`（=`content`）与 `question`（=选中的 `questions[]`） | 不阻塞 |
| ② 基于候选改写 | 取候选的 `content` 与某条 `questions` 作为草稿，自由改写 | 不阻塞 |
| ③ 完全自填 | 客户忽略候选，直接提供自己的 `keyword` 与 `question` | 不阻塞（推荐兜底） |

## 手动调用示例（curl）

```bash
# 按关键词搜索
curl --location --request GET \
  '{api_url}/restful/api.json?action=keyword&secret_key={密钥}&kw=纸巾' \
  --header 'Accept: application/json'

# 按品牌过滤
curl --location --request GET \
  '{api_url}/restful/api.json?action=keyword&secret_key={密钥}&knowledge_id=15' \
  --header 'Accept: application/json'
```

> 推荐改用 `scripts/fetch_keywords.py`，自动格式化展示为「关键词 + 创作方向列表」。
