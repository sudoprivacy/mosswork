# 趣搜 GEO 素材库接口规范

用于在文章中插入图片。推荐通过 `scripts/fetch_materials.py` 调用（已做参数校验与格式化），本文件记录底层接口细节，供排查问题或手动调用时参考。

## 接口 1：获取素材库列表 action = material

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `secret_key` | string | 是 | 用户密钥（后台 {backend_url}/#/user/secretkey 新增并勾选「授权 WorkBuddy」后获取） |
| `action` | string | 是 | 固定为 `material` |
| `knowledge_id` | int | 是 | 品牌 ID（来自第 1 步 `fetch_knowledge` 的 `data.id`） |
| `page` | int | 否 | 当前页，默认 1 |
| `limit` | int | 否 | 每页数量，默认 15 |
| `kw` | string | 否 | 搜索关键词，按素材库名匹配 |

### 响应

成功（`code=0`）返回 `data`：

```json
{
  "page": 1,
  "limit": 15,
  "count": 1,
  "list": [
    {
      "id": 1,
      "knowledge_id": 15,
      "name": "网易云音乐",
      "desc": "",
      "material_count": 9,
      "material_list": [
        {
          "id": 9,
          "material_id": 1,
          "name": "微信图片_20260729104114_175_556.jpg",
          "content": "https://qusou-kj.oss-cn-guangzhou.aliyuncs.com/files/2026/07/29/422d2101da302500cf90e0057c248724.jpeg",
          "created_at": "2026-07-29 10:58:43"
        }
      ]
    }
  ]
}
```

字段说明：

| 字段 | 说明 |
|------|------|
| `list[].id` | 素材库 ID（即 `material_id`） |
| `list[].name` | 素材库名称 |
| `list[].material_count` | 库内图片总数 |
| `list[].material_list` | 该库前 9 张图片预览（含 `name` 与 `content`，足够覆盖大多数选图场景） |
| `list[].material_list[].id` | 图片 ID |
| `list[].material_list[].name` | 图片原始文件名（建议作为 alt 文本） |
| `list[].material_list[].content` | **图片 URL**（用于 `content` 字段或 Markdown 插入） |
| `list[].material_list[].created_at` | 上传时间 |

> 注意：预览只有前 9 张。如需看更多，改用接口 2（action=material_list）。

## 接口 2：获取素材库内图片列表 action = material_list

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `secret_key` | string | 是 | 用户密钥 |
| `action` | string | 是 | 固定为 `list` |
| `material_id` | int | 是 | 素材库 ID（取自接口 1 的 `list[].id`） |
| `page` | int | 否 | 当前页，默认 1 |
| `limit` | int | 否 | 每页数量，默认 15 |
| `kw` | string | 否 | 搜索关键词，按图片原始文件名匹配 |

### 响应

成功（`code=0`）返回 `data`：

```json
{
  "page": 1,
  "limit": 15,
  "count": 9,
  "list": [
    {
      "id": 9,
      "material_id": 1,
      "name": "微信图片_20260729104114_175_556.jpg",
      "content": "https://qusou-kj.oss-cn-guangzhou.aliyuncs.com/files/2026/07/29/422d2101da302500cf90e0057c248724.jpeg",
      "size": 103229,
      "created_at": "2026-07-29 10:58:43",
      "updated_at": "2026-07-29 10:58:43"
    }
  ],
  "info": {
    "id": 1,
    "knowledge_id": 15,
    "name": "网易云音乐",
    "material_count": 9
  }
}
```

字段说明：

| 字段 | 说明 |
|------|------|
| `list[].id` | 图片 ID |
| `list[].name` | 图片原始文件名（建议作为 alt 文本） |
| `list[].content` | **图片 URL** |
| `list[].size` | 文件大小（字节） |
| `info` | 素材库元信息（库名、库内图片总数等） |

## 端到端工作流

```
第 1 步 fetch_knowledge → data.id (knowledge_id) ─┐
                                                   ↓
第 7 步 fetch_materials --action material --knowledge-id {id}
                → 列出该品牌所有素材库（每库带前 9 张图预览，含 name）
                → 默认：从全部预览图候选池中随机挑 1 张插入（AI 选自然位置）
                ↓
（第 9 步换图反馈时）fetch_materials --action material_list --material-id {mid} --page N
                → 翻页或按 kw 搜索，展示给用户挑选
                ↓
把图片以 Markdown 形式插入正文
                ↓
第 10 步 push_article --content-file（含图片 Markdown）→ 提交到后台
```

## 大库展示策略

为不同规模的素材库设计分层展示，避免一次性把所有图片铺给客户。

### 第一层：素材库总览（默认入口）

调用 `action=material` 一次性拉取该品牌下所有素材库。每个库展示：

- 库名、描述、库内图片总数 `material_count`；
- 前 9 张图的 `id` + `name`（原始文件名）+ `content`（URL）+ Markdown 缩略图。

适用：素材库 < 9 张图时，一次预览就够选图；多库时也便于客户先选库。

### 第二层：库内分页（库内 > 9 张时）

若某库 `material_count > 9`，自动在预览末尾提示：

```
⚠️ 素材库 [N] 共 X 张图，本预览仅前 9 张。需看更多请用 list 翻页。
fetch_materials.py --action material_list --material-id {mid} --page 2
fetch_materials.py --action material_list --material-id {mid} --kw 关键词
```

调用 `action=material_list` 按 `page` / `limit` 翻页，每页 15 张（可调）。`scripts/fetch_materials.py` 在 list 模式下默认输出：

```
# 素材库 [1] 网易云音乐（87 张）
本页 15 张 / 共 87 张

- id=24 | 微信图片_xxx.jpg | 102.3 KB
  ![微信图片_xxx.jpg](https://...)
- id=25 | 微信图片_xxx.jpg | 89.1 KB
  ![微信图片_xxx.jpg](https://...)
...
```

并在末尾输出分页引导：

```
📄 第 1 / 6 页（共 87 张）。换页：--page 2；按名称搜：--kw "客服"。
```

### 第三层：关键词搜索（库内大量同类图）

list 接口支持 `kw` 按图片原始文件名匹配。典型用法：

| 客户表述 | 脚本调用 |
|----------|----------|
| 「看下带『客服』的图片」 | `fetch_materials --action material_list --material-id 1 --kw 客服` |
| 「带 logo 的」 | `fetch_materials --action material_list --material-id 1 --kw logo` |

### 选图结果汇总

客户在多次浏览后给出一组图片（按图片 `id` 或 `content` 选定），skill 整理为：

```
选定图片：
- [id=9]  ![微信图片_xxx.jpg](https://...)   建议插入位置：H2「核心优势」后
- [id=24] ![微信图片_xxx.jpg](https://...)   建议插入位置：H2「客户案例」后
- [id=58] ![微信图片_xxx.jpg](https://...)   建议插入位置：标题下方
```

按客户确认后插入正文。

## 图片插入规范

### Markdown 格式

```markdown
![{alt 文本}]({content 图片 URL})
```

- `alt` 建议：
  - 用 `name`（图片原始文件名）；
  - 或用 `{品牌名}-{场景描述}`（如 `网易云音乐-核心优势`），对 AI 引擎更友好。
- 多张图片时，每张图独占一段，前后留空行，便于 Markdown 渲染。

### 插入位置策略

默认由 SKILL.md 第 7 步选定：从素材库随机挑 1 张图后，**AI 依据正文结构选一个自然位置**（默认在导语之后、首个 H2 小标题之前；无 H2 时插在正文首段后）。

当用户在第 9 步反馈换图 / 调整位置 / 需要多图时，可参考以下三种策略：

| 策略 | 适用 | 说明 |
|------|------|------|
| A. 用户指定 H2 小标题 | 精准控制 | 用户明确「插在 XX 小节」 |
| B. 每个 H2 后自动插入 | 批量铺图 | 全程无需选择 |
| C. 半自动 | 换图反馈 | 展示候选图 + 建议位置，用户确认或调整 |

## 手动调用示例（curl）

```bash
# 拉取素材库列表
curl --location --request GET \
  '{api_url}/restful/api.json?secret_key={密钥}&action=material&knowledge_id=15' \
  --header 'Accept: application/json'

# 拉取素材库 1 内的图片（第 1 页）
curl --location --request GET \
  '{api_url}/restful/api.json?secret_key={密钥}&action=material_list&material_id=1&page=1&limit=15' \
  --header 'Accept: application/json'
```

> 推荐改用 `scripts/fetch_materials.py`，自动处理参数校验与格式化输出。

## 失败响应

`code>0` 时返回错误码与提示，常见如「无效密钥」：

```json
{
  "code": 1001,
  "msg": "无效密钥"
}
```
