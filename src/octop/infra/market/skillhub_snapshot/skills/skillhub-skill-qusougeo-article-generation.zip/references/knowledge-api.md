# 趣搜 GEO 知识库接口规范

用于在创作前拉取客户已维护在趣搜 GEO 后台的结构化企业资料。推荐通过 `scripts/fetch_knowledge.py` 调用（已做字段映射与格式化），本文件记录底层接口细节，供排查问题或手动调用时参考。

## 接口信息

| 项 | 值 |
|----|----|
| 方法 | `GET` |
| 地址 | `{api_url}/restful/api.json?secret_key={密钥}&action=knowledge` |
| 请求头 | `Accept: application/json` |
| 超时建议 | 30 秒 |

密钥（`secret_key`）由用户在后台「用户密钥」页面获取，地址：`{backend_url}/#/user/secretkey`。若无密钥：点击「新增密钥」并勾选「授权 WorkBuddy」，创建后复制新密钥。

## 响应

成功（`code=0`）时返回 `data`，结构示例：

```json
{
  "code": 0,
  "data": {
    "id": 15,
    "uid": 1,
    "team_id": 1,
    "brand_name": "网易云音乐",
    "brand_intro": "网易云音乐于2013年4月23日正式上线……",
    "team_intro": "网易云音乐隶属于网易集团……",
    "target_customer": [["年轻大众音乐爱好者", "……", "……"]],
    "industry": ["在线音乐行业", "文化娱乐行业"],
    "competitive_brands": ["QQ音乐", "酷狗音乐", "酷我音乐", "咪咕音乐", "汽水音乐"],
    "product_service": "提供核心在线音乐服务……",
    "qualification": "港交所上市企业（股票代码9899）……",
    "customer_case": ["网易云音乐作为国内最大的独立音乐人在线孵化器……"],
    "sales_channel": ["官方APP自有销售渠道", "微信生态小程序销售渠道"],
    "service_time": "平台核心在线音乐与社交娱乐服务为7×24小时不间断服务……",
    "contact": "95163298",
    "establishment_time": "2013年4月23日",
    "address": "杭州市滨江区网商路599号网易大厦",
    "document": "# 第一篇章：品牌战略与核心架构……",
    "document_status": -2,
    "sort": 0,
    "created_at": "2026-06-30 10:45:32",
    "updated_at": "2026-07-09 17:40:59"
  }
}
```

失败（`code>0`）时返回错误码与提示，常见如「无效密钥」：

```json
{
  "code": 1001,
  "msg": "无效密钥"
}
```

## 字段映射（接口 → 创作字段）

接口返回的字段按下方映射到「企业资料字段表」，未提供的字段在 `scripts/fetch_knowledge.py` 输出中标注为「未提供」：

| 接口字段 | 映射到创作字段 | 说明 |
|----------|----------------|------|
| `brand_name` | `brand_name` | 必填字段，文章中要突出的品牌名 |
| `brand_intro` | `brand_introduction` | 品牌介绍 |
| `team_intro` | `team_intro` | 团队介绍 |
| `target_customer` | `target_customer` | 数组，按子项分行展示 |
| `industry` | `industry` | 数组 |
| `competitive_brands` | `competitive_brands` | 数组 |
| `product_service` | `product_service` | 文本 |
| `qualification` | `qualification` | 文本 |
| `customer_case` | `customer_case` | 数组（每条一个案例） |
| `establishment_time` | 辅助信息 | 不直接用于创作，可用于品牌宣传模板 |
| `address` | 辅助信息 | 同上 |
| `contact` | 辅助信息 | 同上 |
| `service_time` | 辅助信息 | 同上 |
| `sales_channel` | 辅助信息 | 同上 |

## 注意事项

- `keyword`（关键词）与 `question`（创作方向）**接口不返回**，必须由客户在确认环节补齐。**若客户已指明「优化专项」（如"优化专项：网易集团"）：优化专项本身即围绕关键词建立，`keyword` 默认取该专项关键词**，无需再单独索要；仅当客户未指定专项、需从零推荐主题时才走 1A2 关键词推荐流程。
- 接口字段可能随后台升级变动（增减字段），脚本对未知字段不报错，仅展示已知字段，未映射字段可在 `data` 中查看（使用 `--json`）。
- `customer_case` 是数组，创作品牌测评（`ranking`）/ 品牌推荐（`brand_different`）时可挑选典型案例；创作品牌宣传时可结合 `qualification` 的荣誉佐证。
- `document` 字段是后端长文档（按章节组织），仅在接口数据中无法覆盖所需字段时，作为补充素材参考。

## 手动调用示例（curl）

```bash
curl --location --request GET \
  '{api_url}/restful/api.json?secret_key=43a104578d07f5212738ff96966da6c5&action=knowledge' \
  --header 'Accept: application/json'
```

> 推荐改用 `scripts/fetch_knowledge.py`，脚本会做字段映射与格式化，便于回显给客户确认。
