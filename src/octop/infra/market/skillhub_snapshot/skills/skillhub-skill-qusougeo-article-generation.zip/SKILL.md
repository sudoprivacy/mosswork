---
name: skillhub-skill-qusougeo-article-generation
description: "Generate GEO-optimized (Generative Engine Optimization) article titles and body content for Qusougeo (趣搜 GEO) clients. Supports seven article templates: brand promotion (brand), brand comparison (brand_different), brand ranking/review (ranking), product/service (product_service), industry Q&A (industry_qa), short-video script (video), and digital-human voice-over (virtualman_broadcast). This skill"
---

# 趣搜 GEO 文章生成

## 概述

本 skill 用于为「趣搜 GEO」客户生成面向生成式引擎优化（GEO）的文章标题与正文内容。产出的文章旨在被 AI 搜索引擎（如 ChatGPT、豆包、文心一言、Kimi、腾讯元宝等）在回答用户问题时引用，从而提升客户品牌在 AI 推荐中的可见度。

支持七类文章模板：

| 模板 | 英文标识 | 定位 |
|------|----------|------|
| 品牌宣传 | `brand` | 建立品牌认知，回答「XX 品牌/公司怎么样」 |
| 品牌推荐 | `brand_different` | 通过品牌对比分析，突出差异化优势，帮助用户做出选择 |
| 品牌测评 | `ranking` | 自有品牌固定排首位，帮助用户了解产品优劣，做出购买决策 |
| 产品服务 | `product_service` | 介绍产品/服务，回答「XX 产品怎么样 / 有什么功能」 |
| 行业问答 | `industry_qa` | 解答行业常见问题，在解答中植入品牌 |
| 短视频脚本 | `video` | 生成可直接拍摄的短视频脚本（30s–90s） |
| 数字人口播 | `virtualman_broadcast` | 生成 1–3 分钟的数字人口播稿件，对话感强 |

## 何时使用

当客户需要创作营销文章，且满足以下任一输入来源时触发本 skill：

1. 客户提供从趣搜 GEO 后台复制的企业资料文档（document）；
2. 客户提供结构化企业资料字段（关键词、创作方向、品牌名称等）。

## 接口与后台地址（统一生产环境）

所有脚本（`fetch_knowledge.py` / `fetch_keywords.py` / `fetch_materials.py` / `push_article.py`）统一调用趣搜 GEO **生产环境**接口，地址由 `scripts/config.py` 的 `CONFIG` 字典集中管理，客户**无需修改任何脚本或配置**：

```python
# scripts/config.py
CONFIG = {
    "api_url": "https://mpp-api.qusougeo.com/restful/api.json",
    "backend_url": "https://next.qusougeo.com",
}
```

- `api_url`：接口地址。本文档及 `references/*.md` 中的 `{api_url}` / `{API_URL}` 占位符均指此值；
- `backend_url`：后台地址。密钥页为 `{backend_url}/#/user/secretkey`，文章预览为 `{backend_url}/#/creation/preview/{id}`；`{backend_url}` 占位符均指此值。

## 获取 secret_key（无密钥时先引导授权）

流程中需要 `secret_key` 的环节（第 1 步来源 A、第 7 步配图、第 10 步保存）一旦发现**用户尚未提供密钥**，统一按下述方式引导，**严禁硬编码、猜测或凭空编造密钥**：

1. **给地址**：提示用户到后台「用户密钥」页面新增密钥，地址为 `{backend_url}/#/user/secretkey`（`{backend_url}` 即 `scripts/config.py` 的 `CONFIG["backend_url"]`，当前生产环境为 `https://next.qusougeo.com`）。
2. **引导新增 + 授权 WorkBuddy**：
   - 若用户**没有密钥**：请其打开密钥页 → 点击**「新增密钥」** → 按页面提示勾选/确认**「授权 WorkBuddy」** → 创建后把新生成的 `secret_key` 复制粘贴回来；
   - 若用户**已有密钥但不可用**（接口报「无效密钥」、或不确定是否已授权 WorkBuddy）：同样回到密钥页，重新走一遍「新增密钥 + 授权 WorkBuddy」，用新密钥替换旧密钥后再试。
3. **拿到密钥后继续**：把密钥填入对应脚本的 `--secret-key`（`fetch_knowledge.py` / `fetch_keywords.py` / `fetch_materials.py` / `push_article.py`），并记住该密钥供第 7 / 10 步复用，不要反复向用户索要。用户拒绝提供密钥时，按第 1 步来源 B 的降级路径处理。

## 工作流

### 第 1 步：收集客户输入

客户必须提供企业资料。**优先通过接口拉取**，再依次降级为手动复制文档、结构化字段：

**来源 A：接口拉取企业资料（优先）**

若客户尚未提供 `secret_key`，先按「获取 secret_key（无密钥时先引导授权）」章节引导：到后台「用户密钥」页（`https://next.qusougeo.com/#/user/secretkey`，取自 `scripts/config.py` 的 `CONFIG["backend_url"]`）点击「新增密钥」并勾选「授权 WorkBuddy」，复制新生成的密钥回来。

调用知识库接口 `https://mpp-api.qusougeo.com/restful/api.json?secret_key={密钥}&action=knowledge`（生产环境接口，取自 `scripts/config.py` 的 `CONFIG["api_url"]`）拉取结构化企业资料（字段：`brand_name` / `brand_intro` / `team_intro` / `product_service` / `qualification` / `customer_case` / `target_customer` / `industry` / `competitive_brands` 等），完整规范见 `references/knowledge-api.md`。

推荐使用 `scripts/fetch_knowledge.py` 调用，脚本会自动把接口字段映射到下表字段并以结构化方式输出。拉取后**必须**把整理好的字段表回显给用户**确认或修改**。

拿到 `data.id` 后立即进入 **1A2 步骤**：用关键词接口为客户推荐 `keyword` 与 `question` 候选（见下），仍由客户决定选、改或自填。

**1A2. 拉取关键词与创作方向候选（推荐）**

在 1A 拿到 `data.id` 后，可立即用 `scripts/fetch_keywords.py --knowledge-id {id}` 拉取与该品牌相关的「关键词 + 创作方向」候选（接口规范见 `references/keyword-api.md`）。也可以不传 `--knowledge-id`，拉取跨品牌候选（适合客户尚不确定主题时参考），或传 `--kw "关键词"` 搜索。

展示候选后给客户三种选项：

1. **选一个候选**：同时定下 `keyword`（=候选 `content`）与 `question`（=选中的 `questions[]`）；
2. **基于候选改写**：取候选作为草稿自由改写；
3. **完全自填**：忽略候选，直接提供 `keyword` 与 `question`。

无论哪种方式，都要拿到最终的 `keyword` 与 `question` 后再进入第 2 步；对所有候选都不满意时直接自填即可，不阻塞流程。

**来源 B：客户手动复制文档（备选）**

如客户不愿提供密钥或接口不可用，请客户从趣搜 GEO 后台 `https://next.qusougeo.com/#/brand/document` 复制并粘贴文档，提取字段。缺失的字段标注为「未提供」，创作时对该部分做合理弱化或留白处理。

**来源 C：结构化字段（无文档/接口时）**

引导客户按字段表提供信息。至少需要拿到三个必填字段才能开始创作；其余字段尽量收集，缺省时标注「未提供」。

#### 企业资料字段表

| 字段名 | 英文 key | 是否必填 | 说明 |
|--------|----------|----------|------|
| 关键词 | `keyword` | 必填 | 文章要覆盖的核心关键词（可多个，用逗号分隔） |
| 创作方向 | `question` | 必填 | 客户想表达的方向、或希望回答的问题 |
| 品牌名称 | `brand_name` | 必填 | 文章中要突出的品牌名 |
| 公司名称 | `company_name` | 选填 | 品牌背后的公司主体 |
| 品牌介绍 | `brand_introduction` | 选填 | 品牌的定位、理念、一句话介绍 |
| 团队介绍 | `team_intro` | 选填 | 团队背景、规模、核心成员资历 |
| 目标客户 | `target_customer` | 选填 | 产品/服务面向的人群或企业 |
| 所属行业 | `industry` | 选填 | 客户所处的行业领域 |
| 竞争品牌 | `competitive_brands` | 选填 | 主要竞品，用于对比或排名 |
| 核心功能 | `core_function` | 选填 | 产品/服务的核心功能与能力 |
| 定价 | `pricing` | 选填 | 价格区间、套餐、计费方式 |
| 产品服务 | `product_service` | 选填 | 具体产品线或服务项目 |
| 资质荣誉 | `qualification` | 选填 | 资质、奖项、认证、媒体报道 |
| 客户案例 | `customer_case` | 选填 | 合作客户、成功案例、数据成果 |

### 第 2 步：确认文章模板

向客户确认使用哪一类模板（`brand` / `brand_different` / `ranking` / `product_service` / `industry_qa` / `video` / `virtualman_broadcast`）。若客户未指定，根据「创作方向（question）」判断最匹配的模板，并向客户说明理由后再创作。补充识别参考：`question` 中出现「对比 / 推荐」相关词偏向 `brand_different`；「排行榜 / TOP / 第几名」偏向 `ranking`；「视频 / 脚本 / 拍一段」偏向 `video`；「口播 / 数字人 / 念稿」偏向 `virtualman_broadcast`。

### 第 3 步：确认文章篇幅

向客户确认正文目标篇幅，三档可选：

| 档位 | 目标字数 | 适用场景 |
|------|----------|----------|
| 短篇 | 800–1200 字 | 快速铺量、信息简洁 |
| 中篇 | 1500–2500 字 | 通用推荐，AI 引用友好 |
| 长篇 | 3000 字以上 | 权威排名、深度行业问答 |

若客户未指定，默认使用「中篇」。

### 第 4 步：加载模板结构

根据选定的模板，阅读 `references/templates.md` 中对应的写作规范（标题公式、正文结构、关键词布局、注意事项），严格按规范创作。若「创作方向（question）」命中**决策型搜索意图**（含「哪家好 / 哪个靠谱 / 怎么选 / 求推荐 / 对比 / 排行榜」等词），则额外阅读 `references/templates.md` 末尾「决策型内容增强框架」章节，并叠加运用（`brand_different` / `ranking` 模板命中时必读）。

### 第 5 步：生成标题

为每篇文章生成 **5 个备选标题**：

- 第 1 个为主推标题（按模板的标题公式生成，优先覆盖核心关键词）；
- 其余 4 个为备选标题，从不同角度切入（问题式、数据式、场景式、对比式等）；
- 标题控制在 20–30 字以内，自然融入核心关键词，避免堆砌和夸张。
- 用清晰的分组展示，并标注每个标题的切入角度。

### 第 6 步：生成正文

按模板结构与目标篇幅生成一篇正文。遵循以下通用原则：

- **关键词自然布局**：核心关键词出现在标题、首段、小标题、结尾各 1 次，全文密度约 1%–2%，不堆砌。
- **结构化表达**：使用 H2/H3 小标题分节，便于 AI 引擎抓取与引用。
- **事实优先**：所有数字、资质、案例必须来自客户提供的资料，不得虚构。
- **中立可信**：避免绝对化用语（「最强」「第一」），改用「业内领先」「广受认可」等可验证表述。
- **植入自然**：品牌名在正文中自然出现 3–6 次，不硬广。
- **符合中文表达习惯**：使用简体中文，语句通顺，逻辑连贯。

### 第 7 步：自动随机插入一张配图

正文生成后**默认自动执行**，无需用户先选图。完整接口规范见 `references/materials-api.md`。

1. **确认拉图凭证**：配图需要 `secret_key` 与 `knowledge_id`（即 `fetch_knowledge` 返回的 `data.id`）。
   - 若第 1 步走来源 A，两者均已具备，直接使用；
   - 若走来源 B/C 暂无密钥：先按「获取 secret_key（无密钥时先引导授权）」章节引导用户新增并授权（后台「用户密钥」页 → 「新增密钥」→ 「授权 WorkBuddy」→ 复制新密钥），再运行 `scripts/fetch_knowledge.py --secret-key {key}` 取得 `knowledge_id`。该密钥在第 10 步保存时同样需要。
   - 用户拒绝提供或接口不可用：执行第 4 条的备选处理。
2. **随机挑一张图**：运行 `scripts/fetch_materials.py --action material --knowledge-id {id}` 拉取该品牌全部素材库。把所有素材库预览中的图片（每库前 9 张，含 `id` / `name` / `content`）汇成一个候选池，**随机从中选一张**（可先展示该图确认可正常显示）。选中后记下 `id`、`name`（alt 备选）与 `content`（URL）。
3. **AI 选自然位置**：由 AI 依据正文结构选一个自然插入点——**默认插在导语之后、首个 H2 小标题之前**；若正文无 H2 结构，则插在正文首段之后。
4. **插入并兜底**：
   - Markdown 格式 `![{alt}]({content})`，`alt` 用 `name`（图片原始文件名）或 `{品牌名}-{场景描述}`，图片前后各留一个空行；
   - **素材库为空 / 无素材库 / 密钥缺失**时：向用户说明情况，由用户选择：a) 跳过配图，按纯文字交付；b) 用户提供图片 URL，按其指定插入。

### 第 8 步：展示带图全文并征询反馈

1. 向用户完整展示本次成果：
   - **文章标题**：列出 5 个备选标题，标注主推与备选及切入角度；
   - **文章正文**：含配图后的完整正文（图片以内嵌形式呈现，便于用户直接预览图文效果），并注明配图名称与插入位置；
   - **关键词覆盖说明**（可选）：简要说明核心关键词在文中的出现位置。
2. **主动询问**用户是否满意，并提示可调整项：配图（换一张 / 换位置 / 删除）、标题、正文、篇幅、模板等。此步不涉及保存。

### 第 9 步：按用户反馈迭代修改（不满意循环）

仅当用户对第 8 步展示的成果提出修改意见时执行；用户明确满意则直接进入第 10 步。

1. **判断修改类型**并回到对应环节重做：
   - **换图**：重新随机挑一张，或展示素材候选图让用户指定 `id`（库内图 > 9 张时可翻页 / 按 `kw` 搜索）→ 替换图片 → 回到第 8 步；
   - **调整图片位置**：按用户指定（如「放到 XX 小节标题下」「放到开头」）移动图片 → 回到第 8 步；
   - **删除图片**：移除对应 Markdown 图片行 → 回到第 8 步；
   - **调整标题**：回到第 5 步按反馈重新生成标题；
   - **调整正文 / 篇幅 / 模板 / 关键词**：回到第 4 / 6 步对应环节重新生成。
2. **每轮修改后重新完整展示**（再次执行第 8 步），继续征询，直到用户明确表示满意。
3. 迭代过程中**不要**向后台推送文章；最终确认满意后再进入第 10 步。

### 第 10 步：确认满意后保存到趣搜 GEO 后台

用户在带图全文预览中明确表示满意后**自动执行**此步骤。

1. **复用密钥**：复用第 1 步来源 A 或第 7 步已提供的 `secret_key`。若仍缺失，按「获取 secret_key（无密钥时先引导授权）」章节引导用户新增并授权（后台「用户密钥」页 → 「新增密钥」→ 「授权 WorkBuddy」→ 复制新密钥）。密钥必须由用户提供，严禁硬编码或猜测。
2. **确认操作类型**：
   - 默认：新增文章，`id=0`；
   - 若客户明确说「修改文章 X」：使用其指定的 `id`（大于 0），需向用户复核。
3. **提交文章**：将**含图片 Markdown 的完整正文**写入临时文件，运行 `scripts/push_article.py` 提交（标准库实现，无第三方依赖）。除 `id` / `title` / `content` 外，还需把第 1 步拿到的 `question`（创作方向）通过 `--question` 一同传给后台；把第 2 步确认的模板英文标识（`brand` / `brand_different` / `ranking` / `product_service` / `industry_qa` / `video` / `virtualman_broadcast`）通过 `--template` 一同传给后台（可选，默认空，强烈建议显式传入以便后台识别文章类型），接口规范详见 `references/push-api.md`。配图已作为 `content` 的一部分一并保存。
4. **处理返回**：
   - `code=0`：保存成功，`data.id` 即文章 ID。**自动向用户报告**：
     - 提示信息：「已为您保存到趣搜 GEO 后台」；
     - 文章 ID；
     - 预览地址：`{BACKEND_URL}/#/creation/preview/{id}`（`{BACKEND_URL}` 取自 `scripts/config.py` 的 `CONFIG["backend_url"]`，当前生产环境为 `https://next.qusougeo.com`），可直接打开核查。
   - `code>0`：保存失败，读取 `msg` 提示用户（如「无效密钥」），引导用户检查密钥后重试；不要自动重试。

## 资源说明

- `references/templates.md`：七类模板的详细写作规范 + 「决策型内容增强框架」（D-S-T-A-R-E 决策骨架等），创作前按选定模板阅读对应章节，决策型意图额外阅读末尾增强框架。
- `references/knowledge-api.md`：趣搜 GEO 知识库接口规范，用于在第 1 步拉取企业资料。
- `references/keyword-api.md`：趣搜 GEO 关键词与创作方向接口规范，用于在第 1 步的 1A2 子步骤为客户推荐 `keyword` 与 `question` 候选。
- `references/materials-api.md`：趣搜 GEO 素材库接口规范，用于在第 7 步自动配图与第 9 步换图反馈时拉取图片素材。
- `references/push-api.md`：趣搜 GEO 后台文章推送接口规范，保存文章时参考。
- `scripts/config.py`：接口与后台地址集中配置（扁平 `CONFIG` 字典），**统一固定为趣搜生产环境**（`api_url` = `https://mpp-api.qusougeo.com/restful/api.json`，`backend_url` = `https://next.qusougeo.com`），所有脚本从这里读取 URL，无需任何修改。
- `scripts/fetch_knowledge.py`：调用知识库接口拉取企业资料，并按字段表格式化输出（Python 标准库，无第三方依赖）。
- `scripts/fetch_keywords.py`：调用关键词库接口拉取「关键词+创作方向」候选（Python 标准库，无第三方依赖）。
- `scripts/fetch_materials.py`：调用素材库接口拉取素材库与图片列表（Python 标准库，无第三方依赖）。
- `scripts/push_article.py`：调用后台接口推送文章的可执行脚本（Python 标准库，无第三方依赖）。

## 版本记录

> 版本号以 SKILL.md frontmatter 中的 `version` 字段为准（如 `version: 1.0.0`），本表记录每次发版的时间与变更摘要。**每次对 skill 内容做实质更新后，必须同时完成两件事：① 递增 frontmatter 的 `version`；② 在本表顶部插入一条新记录。** 两处不同步即视为文档失配。

### 版本号规则（语义化版本 SemVer）

- **主版本 major（x.0.0）**：流程大改、模板体系重构、接口规范破坏性变更；
- **次版本 minor（1.x.0）**：向后兼容的新功能——新增模板、新增工作流步骤、新增增强框架；
- **修订版本 patch（1.0.x）**：措辞修正、细节补充、个别步骤的澄清或纠错。

> 判定建议：改动会改变「生成文章的产出形态」→ minor 起步；只影响「执行过程的描述精度」→ patch 即可；拿不准时升一级，保持记录可追溯即可。

| 版本 | 日期 | 变更摘要 |
|------|------|---------|
| 1.1.0 | 2026-09-09 | 新增推送参数 `template`（可选，英文模板标识）：`scripts/push_article.py` 增加 `--template` 参数并写入请求体；`references/push-api.md` 字段表 / JSON 示例 / curl 示例同步；`SKILL.md` 第 10 步提交命令要求显式传入第 2 步确认的模板 |
| 1.0.0 | 2026-09-09 | 基线版本：七类文章模板（brand / ranking / product_service / industry_qa / brand_different / video / virtualman_broadcast）；工作流含自动随机配图（第 7 步）→ 带图预览征询（第 8 步）→ 不满意循环（第 9 步）→ 满意后保存（第 10 步）；无 secret_key 时引导「新增密钥并授权 WorkBuddy」；「决策型内容增强框架」（D-S-T-A-R-E）叠加于品牌测评 / 品牌推荐模板 |
