#!/usr/bin/env python3
"""从趣搜 GEO 知识库接口拉取企业资料。

用法：
    python3 fetch_knowledge.py --secret-key <密钥> [--json]

说明：
    --json    仅输出原始 data JSON，不做字段映射与格式化

示例：
    python3 fetch_knowledge.py --secret-key 43a104578d07f5212738ff96966da6c5

退出码：0=成功，1=失败。
"""

import argparse
import json
import sys
import urllib.error
import urllib.parse
import urllib.request

from config import CONFIG

API_URL = CONFIG["api_url"]
BACKEND_URL = CONFIG["backend_url"]

# 接口字段 → 创作字段展示标签（按创作字段表顺序排列）
FIELD_MAPPING = [
    ("brand_name",         "品牌名称 brand_name"),
    ("brand_intro",        "品牌介绍 brand_introduction"),
    ("team_intro",         "团队介绍 team_intro"),
    ("target_customer",    "目标客户 target_customer"),
    ("industry",           "所属行业 industry"),
    ("competitive_brands", "竞争品牌 competitive_brands"),
    ("product_service",    "产品服务 product_service"),
    ("qualification",      "资质荣誉 qualification"),
    ("customer_case",      "客户案例 customer_case"),
    ("establishment_time", "成立时间（辅助信息）"),
    ("address",            "总部地址（辅助信息）"),
    ("contact",            "联系方式（辅助信息）"),
    ("service_time",       "服务时间（辅助信息）"),
    ("sales_channel",      "销售渠道（辅助信息）"),
]


def fetch_knowledge(secret_key: str) -> dict:
    """调用知识库接口，返回接口完整响应 JSON。"""
    qs = urllib.parse.urlencode({"secret_key": secret_key, "action": "knowledge"})
    url = f"{API_URL}?{qs}"
    req = urllib.request.Request(
        url,
        headers={"Accept": "application/json"},
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _is_empty(value) -> bool:
    if value is None:
        return True
    if isinstance(value, (str, list, dict)) and len(value) == 0:
        return True
    return False


def format_summary(data: dict) -> str:
    """把 data 渲染成供用户确认/修改的字段表。"""
    lines = ["# 企业资料（接口拉取结果，请确认或修改）", ""]
    for key, label in FIELD_MAPPING:
        value = data.get(key)
        if _is_empty(value):
            lines.append(f"- **{label}**：未提供")
            continue
        if isinstance(value, (list, dict)):
            text = json.dumps(value, ensure_ascii=False, indent=2)
        else:
            text = str(value)
        lines.append(f"- **{label}**：{text}")
    lines.append("")
    lines.append("> 注：keyword（关键词）与 question（创作方向）接口未返回，请补齐。")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="从趣搜 GEO 知识库接口拉取企业资料")
    parser.add_argument("--secret-key", required=True, help=f"用户密钥（后台 {BACKEND_URL}/#/user/secretkey 新增并授权 WorkBuddy 后获取）")
    parser.add_argument("--json", action="store_true", help="仅输出原始 data JSON，不做格式化")
    args = parser.parse_args()

    try:
        result = fetch_knowledge(args.secret_key)
    except urllib.error.HTTPError as e:
        print(f"HTTP 错误: {e.code}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"网络错误: {e.reason}", file=sys.stderr)
        sys.exit(1)

    code = result.get("code")
    if code != 0:
        msg = result.get("msg", "未知错误")
        print(f"拉取失败 (code={code}): {msg}", file=sys.stderr)
        sys.exit(1)

    data = result.get("data") or {}
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print(format_summary(data))
    sys.exit(0)


if __name__ == "__main__":
    main()
