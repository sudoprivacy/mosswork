"""趣搜 GEO 接口配置（统一生产环境）。

所有脚本从下方 `CONFIG` 字典读取接口与后台地址，本文件即唯一配置源。
统一使用趣搜 GEO 生产环境，无需（也不支持）切换其他环境。

- api_url     : 接口地址，references/*.md 文档中的 {api_url} 占位符指此值
- backend_url : 后台地址（密钥页 /#/user/secretkey、预览 /#/creation/preview/{id}），
                references/*.md 文档中的 {backend_url} 占位符指此值
"""

CONFIG = {
    "api_url": "https://mpp-api.qusougeo.com/restful/api.json",
    "backend_url": "https://next.qusougeo.com",
}
