#!/usr/bin/env python3
"""推送文章到趣搜 GEO 后台。

用法：
    python3 push_article.py --secret-key <密钥> --title <标题> --question <创作方向> --content-file <markdown文件> [--id 0] [--template <模板id>]

说明：
    --id 0                新增文章（默认）
    --id >0               修改指定 ID 的已有文章
    --template <id>       可选，文章模板英文标识（brand / brand_different / ranking / product_service / industry_qa / video / virtualman_broadcast），默认空

示例：
    python3 push_article.py --secret-key 43a104578d07f5212738ff96966da6c5 \
        --title "yuchong test" \
        --question "yuchong 怎么用" \
        --content-file article.md \
        --template brand
"""

import argparse
import json
import sys
import urllib.error
import urllib.request

from config import CONFIG

API_URL = CONFIG["api_url"]
BACKEND_URL = CONFIG["backend_url"]


def push_article(secret_key: str, article_id: int, title: str, question: str, content: str, template: str = "") -> dict:
    """调用后台接口推送文章，返回接口响应 JSON。"""
    url = f"{API_URL}?secret_key={secret_key}"
    payload = {
        "id": article_id,
        "action": "push_article",
        "title": title,
        "question": question,
        "content": content,
        "template": template,
    }
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Accept": "*/*",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser(description="推送文章到趣搜 GEO 后台")
    parser.add_argument("--secret-key", required=True, help=f"用户密钥（在后台 {BACKEND_URL}/#/user/secretkey 新增并授权 WorkBuddy 后获取）")
    parser.add_argument("--title", required=True, help="文章标题")
    parser.add_argument("--question", required=True, help="创作方向（与文章一同保存到后台）")
    parser.add_argument("--content-file", required=True, help="Markdown 正文文件路径")
    parser.add_argument("--id", type=int, default=0, help="文章 ID，0=新增，>0=修改已有文章")
    parser.add_argument("--template", default="", help="文章模板英文标识（brand/brand_different/ranking/product_service/industry_qa/video/virtualman_broadcast），选填，默认空")
    args = parser.parse_args()

    with open(args.content_file, "r", encoding="utf-8") as f:
        content = f.read()

    try:
        result = push_article(args.secret_key, args.id, args.title, args.question, content, args.template)
    except urllib.error.HTTPError as e:
        print(f"HTTP 错误: {e.code}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"网络错误: {e.reason}", file=sys.stderr)
        sys.exit(1)

    code = result.get("code")
    if code == 0:
        data = result.get("data") or {}
        article_id = data.get("id")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        print(f"保存成功，文章 ID: {article_id}")
        if article_id is not None:
            print(f"预览地址: {BACKEND_URL}/#/creation/preview/{article_id}")
        sys.exit(0)
    else:
        msg = result.get("msg", "未知错误")
        print(f"保存失败 (code={code}): {msg}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
