#!/usr/bin/env python3
"""从趣搜 GEO 素材库拉取图片素材。

用法：
    # 拉取某个品牌下的素材库列表（含每个库的前 15 张图片）
    python3 fetch_materials.py --secret-key <key> --action material --knowledge-id <brand_id>

    # 拉取某个素材库内的图片列表（支持分页与关键词搜索）
    python3 fetch_materials.py --secret-key <key> --action material_list --material-id <material_id>

可选参数：
    --page 1   --limit 15   --kw "搜索词"   --json

退出码：0=成功，1=失败。
"""

import argparse
import json
import sys
import urllib.error
import urllib.parse
import urllib.request

from config import CONFIG

API_URL = CONFIG["api_url"]
BACKEND_URL = CONFIG["backend_url"]


def call_api(secret_key: str, action: str, params: dict) -> dict:
    """统一调用后台接口。"""
    qs = urllib.parse.urlencode({"secret_key": secret_key, "action": action, **params})
    url = f"{API_URL}?{qs}"
    req = urllib.request.Request(
        url,
        headers={"Accept": "application/json"},
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def format_material_libs(data: dict) -> str:
    """格式化素材库列表（material 模式输出）。"""
    libs = data.get("list") or []
    total = data.get("count", len(libs))
    lines = [f"# 素材库列表（共 {total} 个，本页 {len(libs)} 个）", ""]
    if not libs:
        lines.append("（无）")
        return "\n".join(lines)
    for lib in libs:
        lines.append(
            f"## [{lib.get('id')}] {lib.get('name', '')}（{lib.get('material_count', 0)} 张）"
        )
        desc = lib.get("desc")
        if desc:
            lines.append(f"> {desc}")
        preview = lib.get("material_list") or []
        if preview:
            lines.append("")
            lines.append("**预览图（前 9 张，含 `name` 与 `content`）：**")
            for m in preview:
                name = m.get("name") or ""
                content = m.get("content") or ""
                if name:
                    lines.append(f"- id={m.get('id')} | {name}")
                    lines.append(f"  ![{name}]({content})")
                else:
                    lines.append(f"- id={m.get('id')} content={content}")
        lines.append("")
    return "\n".join(lines)


def format_materials(data: dict) -> str:
    """格式化素材库内图片列表（list 模式输出）。"""
    info = data.get("info") or {}
    items = data.get("list") or []
    total = data.get("count", len(items))
    lines = [
        f"# 素材库 [{info.get('id')}] {info.get('name', '')}（{info.get('material_count', 0)} 张）",
        f"本页 {len(items)} 张 / 共 {total} 张",
        "",
    ]
    if not items:
        lines.append("（无）")
        return "\n".join(lines)
    for m in items:
        name = m.get("name", "")
        content = m.get("content", "")
        size = m.get("size", 0) or 0
        size_kb = round(size / 1024, 1) if size else 0
        lines.append(
            f"- **id={m.get('id')}** | 文件名：{name} | 大小：{size_kb} KB"
        )
        lines.append(f"  ![{name}]({content})")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="从趣搜 GEO 素材库拉取图片素材"
    )
    parser.add_argument("--secret-key", required=True, help=f"用户密钥（后台 {BACKEND_URL}/#/user/secretkey 新增并授权 WorkBuddy 后获取）")
    parser.add_argument(
        "--action",
        required=True,
        choices=["material", "material_list"],
        help="material=素材库列表, material_list=素材库内图片",
    )
    parser.add_argument("--knowledge-id", type=int, help="品牌 ID（--action material 时必填）")
    parser.add_argument("--material-id", type=int, help="素材库 ID（--action material_list 时必填）")
    parser.add_argument("--page", type=int, default=1, help="当前页码")
    parser.add_argument("--limit", type=int, default=15, help="每页数量")
    parser.add_argument(
        "--kw",
        default="",
        help="搜索关键词（material 模式按素材库名，list 模式按图片名）",
    )
    parser.add_argument(
        "--json", action="store_true", help="仅输出原始 data JSON，不做格式化"
    )
    args = parser.parse_args()

    if args.action == "material" and not args.knowledge_id:
        parser.error("--action material 时必须传 --knowledge-id")
    if args.action == "material_list" and not args.material_id:
        parser.error("--action material_list 时必须传 --material-id")

    params = {"page": args.page, "limit": args.limit, "kw": args.kw}
    if args.action == "material":
        params["knowledge_id"] = args.knowledge_id
    else:
        params["material_id"] = args.material_id

    try:
        result = call_api(args.secret_key, args.action, params)
    except urllib.error.HTTPError as e:
        print(f"HTTP 错误: {e.code}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"网络错误: {e.reason}", file=sys.stderr)
        sys.exit(1)

    if result.get("code") != 0:
        msg = result.get("msg", "未知错误")
        print(f"拉取失败 (code={result.get('code')}): {msg}", file=sys.stderr)
        sys.exit(1)

    data = result.get("data") or {}
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    elif args.action == "material":
        print(format_material_libs(data))
    else:
        print(format_materials(data))


if __name__ == "__main__":
    main()
