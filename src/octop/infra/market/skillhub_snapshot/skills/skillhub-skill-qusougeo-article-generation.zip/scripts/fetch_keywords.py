#!/usr/bin/env python3
"""从趣搜 GEO 关键词库拉取「关键词+创作方向」候选。

用法：
    # 拉取所有候选（按 kw 搜索）
    python3 fetch_keywords.py --secret-key <key> --kw 纸巾

    # 按品牌过滤（与 fetch_knowledge 的 data.id 配合）
    python3 fetch_keywords.py --secret-key <key> --knowledge-id 15

可选参数：--page 1 --limit 10 --json

退出码：0=成功，1=失败。
"""

import argparse
import json
import sys
import urllib.error
import urllib.parse
import urllib.request

from config import CONFIG

API_URL = CONFIG["api_url"]
BACKEND_URL = CONFIG["backend_url"]


def call_api(secret_key: str, params: dict) -> dict:
    """统一调用后台接口。"""
    qs = urllib.parse.urlencode({"secret_key": secret_key, "action": "keyword", **params})
    url = f"{API_URL}?{qs}"
    req = urllib.request.Request(
        url,
        headers={"Accept": "application/json"},
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def format_keywords(data: dict) -> str:
    """格式化关键词+创作方向候选列表。"""
    items = data.get("list") or []
    total = data.get("count", len(items))
    lines = [
        f"# 关键词+创作方向候选（共 {total} 条，本页 {len(items)} 条）",
        "",
    ]
    if not items:
        lines.append("（无候选，客户需自行输入 keyword 与 question）")
        return "\n".join(lines)
    for i, item in enumerate(items, 1):
        lines.append(f"## [{i}] 关键词：{item.get('content', '')}")
        brand = item.get("brand_name")
        if brand:
            lines.append(
                f"**品牌**：{brand}（knowledge_id={item.get('knowledge_id')}）"
            )
        questions = item.get("questions") or []
        if questions:
            lines.append("")
            lines.append("**创作方向候选**（任选其一或基于此改写）：")
            for j, q in enumerate(questions, 1):
                lines.append(f"  {j}. {q}")
        lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="从趣搜 GEO 关键词库拉取关键词+创作方向候选"
    )
    parser.add_argument("--secret-key", required=True, help=f"用户密钥（后台 {BACKEND_URL}/#/user/secretkey 新增并授权 WorkBuddy 后获取）")
    parser.add_argument("--kw", default="", help="搜索关键词（按 content 字段匹配）")
    parser.add_argument("--knowledge-id", type=int, help="按品牌 ID 过滤候选（与 fetch_knowledge 的 data.id 配合）")
    parser.add_argument("--page", type=int, default=1, help="当前页码")
    parser.add_argument("--limit", type=int, default=10, help="每页数量")
    parser.add_argument("--json", action="store_true", help="仅输出原始 data JSON，不做格式化")
    args = parser.parse_args()

    params = {"page": args.page, "limit": args.limit, "kw": args.kw}
    if args.knowledge_id:
        params["knowledge_id"] = args.knowledge_id

    try:
        result = call_api(args.secret_key, params)
    except urllib.error.HTTPError as e:
        print(f"HTTP 错误: {e.code}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"网络错误: {e.reason}", file=sys.stderr)
        sys.exit(1)

    if result.get("code") != 0:
        msg = result.get("msg", "未知错误")
        print(f"拉取失败 (code={result.get('code')}): {msg}", file=sys.stderr)
        sys.exit(1)

    data = result.get("data") or {}
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print(format_keywords(data))


if __name__ == "__main__":
    main()
