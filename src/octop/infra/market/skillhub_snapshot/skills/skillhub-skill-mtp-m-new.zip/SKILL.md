---
name: skillhub-skill-mtp-m-new
description: "monster 的 MTP 0.2.4 项目设置入口。创建、接入、重构或升级 MTP 项目，或版本前置要求 setup 时使用。"
---

# M-New

```mermaid
flowchart LR
  A["Step 0 Inspect"] --> B["Step 1 Preview"] --> C["Step 2 Apply"] --> D["Step 3 Verify"]
```

## Step 0 Inspect

目标绝对路径、manifest 版本形态、Git 两轴与 `project_kind` 预检 → `blocks/inspect.md`。

## Step 1 Preview

`--target "$PWD"` 只读 dry-run，逐项核对 `target` 等 `--json` 字段 → `blocks/preview-apply.md`。

## Step 2 Apply

同一 `plan_digest` 才可 apply；失败恢复原 bytes → `blocks/preview-apply.md`。

## Step 3 Verify

按 `references/claude-md-guide.md` 写满十节 → `lint` 无 error；
`setup_complete=true` 不证明节内容形态正确 → `blocks/verify.md`。

## Git Capability

无 Git 的 D-1 降级、`revalidate_registry.py` 与 locator 纪律 → `blocks/git-registry.md`。
