# Agent Rules

<!-- MTP:BEGIN version=0.2.4 -->
Read the head block of `ai/NEXT.md` first; follow its pointers for detail. The current Task controls scope, tests, execution, review and rollback.
Think Before Coding: surface assumptions, ambiguity, tradeoffs and the simpler option.
Simplicity First: use the minimum code, process and tests sufficient for real risk.
Surgical Changes: every edit and blocker traces to the Task; unrelated findings go to backlog.
Goal-Driven Execution: define AC, TC, verification and stop when they pass.
The primary Agent alone schedules, integrates and writes `ai/`. Implementation defaults to
`primary`; `parallel` requires Accepted dependencies, real benefit, disjoint declared and actual
scope, an isolated worktree and interrupt capability. Review follows risk: low `self`, medium
`combined`, high `two-stage`, release `independent`. Missing mandatory review blocks Acceptance.
<!-- MTP:END -->

Use minimum diffs. Run affected tests and the Task Gate. Do not fix unrelated findings.
Use give/take only for a real Agent change, session recovery or independent review.
