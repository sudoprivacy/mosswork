# {{PROJECT_NAME}}

<!-- MTP:BEGIN version=0.2.4 -->

> **本文件是「指针入口」，不是内容容器**：只说清 **是什么 / 干什么 / 怎么干 / 到哪了**，
> 细节靠它指到的文件（`ai/`、项目 `references/` 等）展开，**勿把内容塞进来**。
> 面向「Agent 快速读 + 人直接看」：中文为主，保留必要英文 ID（`prj-…`、路径、命令）。

## Project

<!-- MTP:MAP:BEGIN section=Project -->
- 待替换：项目名称、Project ID、Registry ID、生命周期、Accepted source revision，以及入口与事实源的指针（事实源 `ai/brief.md`）。
<!-- MTP:MAP:END section=Project -->

## Current State

<!-- MTP:MAP:BEGIN section=Current State -->
- 待替换：当前阶段一句话（做到哪了）；进度与当前 Task 只留指针，指向 `ai/NEXT.md`，细节不在这里展开。
<!-- MTP:MAP:END section=Current State -->

## End-to-End Flow

<!-- MTP:MAP:BEGIN section=End-to-End Flow -->
<!-- 占位：替换为本项目**真实的端到端流水线**（输入 → 处理 → 输出/交付，含失败/回退回路）。
     依据**项目本体**（入口脚本 / 输入 / 输出）提炼，**不要**写 MTP 协议流程；节点要短、细节外链。
     规范见 m-new `references/claude-md-guide.md`。 -->
```mermaid
flowchart LR
  P["待替换为本项目流水线"] --> Q["…"] --> R["输出/交付"]
```
<!-- MTP:MAP:END section=End-to-End Flow -->

## Structure

<!-- MTP:MAP:BEGIN section=Structure -->
- 待替换：把下面示例换成项目真实结构（只列导航节点；每行 `←` 写用途，深度 2–3 层，禁列生成物）。

```text
<项目根目录名>/
├── <目录>/        ← <用途>
├── <入口文件>     ← <用途>
└── ai/            ← MTP 状态与证据
```

`ai/` 根固定集合（不得新增）：`brief / NEXT / plan / lessons / backlog / OWNER_DECISIONS / IMPL_LOG / review / HANDOFF` + `facts.json / mtp.json / check.sh / registry.py`；额外文件会被 `m-new` 收尾检查告警。
<!-- MTP:MAP:END section=Structure -->

## Entry Points

<!-- MTP:MAP:BEGIN section=Entry Points -->
- 待替换：本项目的 Agent 入口、当前 Task、质量门、Registry helper 分别是什么；只列表，不展开内容。
<!-- MTP:MAP:END section=Entry Points -->

## Scope

<!-- MTP:MAP:BEGIN section=Scope -->
- 待替换：本项目做什么、不做什么（目标与范围）；判据与细节放 `ai/brief.md`，这里只留要点。
<!-- MTP:MAP:END section=Scope -->

## Boundaries

<!-- MTP:MAP:BEGIN section=Boundaries -->
- 待替换：本项目的硬边界（产品 / 安全 / 数据 / 依赖 / 不可逆操作）；未确认的边界不得臆测。
<!-- MTP:MAP:END section=Boundaries -->

## Project Rules And Lessons

<!-- MTP:MAP:BEGIN section=Project Rules And Lessons -->
- 待替换：项目专属规则**要点** + 指针（通用规则 → `AGENTS.md`）；**细节不在此展开**，领域口径放 `ai/brief.md` 与 `references/`。
<!-- MTP:MAP:END section=Project Rules And Lessons -->

## Required Behaviors

<!-- MTP:MAP:BEGIN section=Required Behaviors -->
- 待替换：本项目自己的「触发 → 动作 → 验证」；不要照抄通用流程，只写本项目的硬性行为。
<!-- MTP:MAP:END section=Required Behaviors -->

## Document Navigation

<!-- MTP:MAP:BEGIN section=Document Navigation -->
- 待替换：本项目从哪读到哪（`CLAUDE.md` → `ai/brief.md` → 按需证据）；跨项目先读目标 `CLAUDE.md`，不整包乱开。
<!-- MTP:MAP:END section=Document Navigation -->
<!-- MTP:END -->
