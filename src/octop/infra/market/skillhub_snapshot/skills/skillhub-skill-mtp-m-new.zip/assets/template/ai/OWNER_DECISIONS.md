# Owner Decisions

> 记录 owner 的裁定与授权。每条写清楚：**日期、决定、原话（若有）、影响范围**。

**升级或接入已有项目时**：先读 `ai/IMPL_LOG.md`、`ai/NEXT.md`、`ai/archive/` 与当前 `CLAUDE.md`，
把散落各处的 owner 裁定整理进本文件——一条一段，标明日期与出处。没有可整理的内容就留空，
**不要编造**。

<!-- MTP:ROT:BEGIN segment=owner-decisions-mtp021 -->
<!-- MTP:ROT:END segment=owner-decisions-mtp021 -->
