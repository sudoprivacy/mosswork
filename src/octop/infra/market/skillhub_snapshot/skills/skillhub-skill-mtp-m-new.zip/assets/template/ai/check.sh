#!/usr/bin/env bash
# MTP 0.2.1 project quality Gate.
#
# Project facts live in ai/facts.json (single source of truth). This Gate runs the
# project's own checks and any project-declared extra suites via EXTRA_GATES.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

# Project facts live in ai/facts.json when the project adopts a single-source facts
# checker; run it only if present so a fresh scaffold's Gate stays self-contained.
if [ -f "ai/facts.json" ] && [ -f "scripts/check_facts.py" ]; then
  echo "--> facts single source of truth"
  python3 scripts/check_facts.py --root "$ROOT"
fi

if [ -d "ai/check.d" ]; then
  for suite in ai/check.d/*.sh; do
    [ -e "$suite" ] || continue
    echo "--> $(basename "$suite")"
    bash "$suite"
  done
fi

if [ -n "${EXTRA_GATES:-}" ]; then
  for gate in $EXTRA_GATES; do
    echo "--> extra gate: $gate"
    bash -c "$gate"
  done
fi

echo "[OK] project Gate passed"
