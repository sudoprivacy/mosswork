# Handoff

Only fill this for a real Agent change, session recovery or independent review.
