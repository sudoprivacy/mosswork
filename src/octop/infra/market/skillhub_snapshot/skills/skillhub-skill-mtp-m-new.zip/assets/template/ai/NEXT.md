# Next

> 头部块 = TL;DR + `Main-line Constraints`，是恢复时**唯一必读区**；其余内容按引用读取，不整篇加载。

> TL;DR: shape the project before implementation — define truth in `ai/brief.md`, then route to `m-define`.

## Main-line Constraints

<!-- Standard cross-session summary (AC-CT-3): a resumed session reads this before anything else. -->
- Goal: define project truth in `ai/brief.md`.
- Red lines: no database-as-truth, no runtime/watcher/background service, no network sync.
- Continuity: an approved plan is one-shot continuous execution; stop only at the closed list.
- Peers: register collaboration peers in `ai/peers.json` (id / kind / channel) when present.
- Archive: round documents archive to `ai/archive/<date>-<round>.md` (do not only grow).

- task/state: shape-project / Ready
- plan_commit: pending
- plan_revision: pending
- goal: define project truth in `ai/brief.md`
- route: `m-define`
- read: `CLAUDE.md`, `ai/brief.md`
- done: goal, scope, constraints and success criteria are explicit

## Active Dispatches

Maximum rows: 3.

| dispatch_id | task_id | agent_id | base_sha | worktree | branch | state |
|---|---|---|---|---|---|---|
<!-- MTP:ROT:BEGIN segment=next-mtp021 -->
<!-- MTP:ROT:END segment=next-mtp021 -->
