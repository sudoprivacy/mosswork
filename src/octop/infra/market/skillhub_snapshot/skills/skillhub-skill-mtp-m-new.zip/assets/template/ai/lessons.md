# Project Lessons

## Candidates

<!-- MTP:LESSONS:BEGIN kind=candidates -->
```json
[]
```
<!-- MTP:LESSONS:END kind=candidates -->

## Active Lessons

<!-- MTP:LESSONS:BEGIN kind=active -->
```json
[]
```
<!-- MTP:LESSONS:END kind=active -->
<!-- MTP:ROT:BEGIN segment=lessons-mtp021 -->
<!-- MTP:ROT:END segment=lessons-mtp021 -->
