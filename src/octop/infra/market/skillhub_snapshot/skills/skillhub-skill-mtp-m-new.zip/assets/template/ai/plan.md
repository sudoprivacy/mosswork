# Current Plan

```mermaid
flowchart LR
  A["Shape project facts"] --> B["Plan verifiable Tasks"]
  B --> C["Execute and verify"]
```

Use `m-plan` after shaping. Every Task requires `task_id` plus:

- `goal`, `dependencies`, `allowed_paths`, `artifact`
- `acceptance_criteria`, `test_cases`, `baseline_verification`, `verification`
- `completion_signal`, `risk`, `review`, `rollback`, `execution`, `exclusive_resources`

Execution defaults to `primary`. Use `parallel` only for real benefit with Accepted dependencies,
disjoint scope, isolated worktree and interrupt. Review is `self`, `combined`, `two-stage` or
`independent` according to risk.

Store the approved semantic contract inside one `MTP01-PLAN:BEGIN/END` JSON block and bind it with
`plan_commit` plus `plan_revision` before execution.
<!-- MTP:ROT:BEGIN segment=plan-mtp021 -->
<!-- MTP:ROT:END segment=plan-mtp021 -->
