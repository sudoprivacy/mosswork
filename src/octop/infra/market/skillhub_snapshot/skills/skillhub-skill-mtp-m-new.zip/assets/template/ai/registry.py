#!/usr/bin/env python3
"""Small project-local helper for the MTP local Git Registry."""

import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import typing
import uuid


REGISTRY_ID = "mtp-local-registry-v1"
REGISTRY_SCHEMA = "mtp-registry-v1"
RECORD_SCHEMA = "mtp-registry-record-v1"
CONFIG_KEY = f"mtp.registry.{REGISTRY_ID}"
CANONICAL_BRANCH = "main"
SUMMARY_BATCH_SIZE = 8
DETAIL_BATCH_SIZE = 2
# Non-record files permitted in the Registry root: the identity marker and the
# ignore file (which excludes the derived index and the deletion staging dir).
_NON_RECORD_FILES = {"registry.json", ".gitignore", "README.md"}

_ID_RE = re.compile(r"^(prj|cap|les)-[a-z0-9][a-z0-9-]{2,63}$")
_REVISION_RE = re.compile(r"^[0-9a-f]{40}$")
_FINGERPRINT_RE = re.compile(r"^[0-9a-f]{64}$")
# Tags are free-form, non-ASCII allowed (A-4): a CJK tag such as "决策" is valid. The
# rule only rejects empty, whitespace-bearing or path-unsafe tokens so tags stay
# one-token and diff-friendly; the byte cap is enforced separately.
_TAG_RE = re.compile(r"^[^\s/\\]+$")
# Summary byte ceiling. ASCII compresses to one byte/char; CJK costs three bytes per
# character, so a raw byte cap silently rejects a normal-length Chinese summary. The
# ceiling is expressed as a *character* budget sized so a pure-CJK summary still fits
# ~ the same information as the old 280-byte ASCII cap (A-4).
SUMMARY_MAX_CHARS = 280
_COMMON_FIELDS = {
    "schema", "kind", "id", "title", "summary", "tags", "source_project_id",
    "source_revision", "status", "detail", "evidence", "fingerprint",
}
# Fields excluded when computing the content fingerprint: identity, provenance and
# occurrence bookkeeping must not change the fingerprint, so the same knowledge from
# two projects merges onto one record.
_FINGERPRINT_EXCLUDED = {
    "fingerprint", "id", "source_project_id", "source_revision", "occurrence_count",
    # Provenance/merge bookkeeping: the same knowledge from two projects must produce
    # the same fingerprint, so these must not differ between them.
    "source_projects", "superseded_by",
}
# A project record is a projection of its source ``CLAUDE.md`` Passport: setup and
# refresh derive it and never go through ``publish_record``. A public publish must
# therefore prove the same quality bar before it may write one — a placeholder summary,
# too few substantive tags, a summary that is just the title, or a source without the
# four managed Passport blocks all fail closed.
PROJECT_PLACEHOLDER_PREFIX = "MTP project:"
PROJECT_MIN_SUBSTANTIVE_TAGS = 3
PROJECT_TRIVIAL_TAGS = {"mtp", "project"}
PROJECT_PASSPORT_SECTIONS = ("Project", "Scope", "Current State", "Structure")

_KIND_RULES = {
    "project": {
        "prefix": "prj-",
        "directory": "projects",
        "fields": {"project_root", "entrypoints", "git_state"},
        "statuses": {"active", "archived"},
        "max_bytes": 2048,
    },
    "capability": {
        "prefix": "cap-",
        "directory": "capabilities",
        "fields": {"applicability", "entrypoint", "source_projects", "superseded_by", "applies_to"},
        "statuses": {"active", "review-needed", "superseded", "deprecated"},
        "max_bytes": 1536,
    },
    "lesson": {
        "prefix": "les-",
        "directory": "lessons",
        "fields": {
            "trigger", "symptom", "root_cause", "required_action", "verification",
            "occurrence_count", "high_cost", "source_projects", "superseded_by", "applies_to",
        },
        "statuses": {"candidate", "active", "review-needed", "superseded", "deprecated"},
        "max_bytes": 2048,
    },
}


class RegistryError(RuntimeError):
    def __init__(self, code: str, message: str | None = None) -> None:
        self.code = code
        super().__init__(message or code)


def canonical_json(value: object) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True) + "\n"
    ).encode("utf-8")


def content_fingerprint(record: dict[str, typing.Any]) -> str:
    """Content fingerprint for cross-project merge.

    Two records describing the same knowledge (same kind + content) produce the same
    fingerprint regardless of id, source project/revision or occurrence count, so they
    can merge onto one record. ``fingerprint`` itself is excluded to avoid self-reference.
    """
    subset = {
        key: value for key, value in record.items() if key not in _FINGERPRINT_EXCLUDED
    }
    return hashlib.sha256(canonical_json(subset)).hexdigest()


def _text(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _string_list(value: object, *, max_items: int = 32) -> bool:
    return (
        isinstance(value, list)
        and 0 < len(value) <= max_items
        and all(isinstance(item, str) and item.strip() for item in value)
    )


def _validate_applies_to(value: object, kind: str) -> None:
    """Validate the ``applies_to`` expiry predicate (AC-REG-3).

    ``applies_to`` states *when a record still applies*; when the predicate no longer
    holds, retrieval downgrades the record to ``review-needed`` rather than dropping it.
    The shape is a fixed object ``{"kind", "ref"}`` — ``ref`` is a source revision, path
    or other concrete anchor. An absent value is allowed (no predicate declared).
    """
    if value is None:
        return
    if not isinstance(value, dict) or set(value) != {"kind", "ref"}:
        raise RegistryError(f"invalid-{kind}-applies-to")
    if not _text(value.get("kind")) or not _text(value.get("ref")):
        raise RegistryError(f"invalid-{kind}-applies-to")


# Fields permitted but not required for the kinds that declare them. ``applies_to`` is
# an optional expiry predicate (AC-REG-3): a record without one simply never auto-expires.
# ``git_state`` is optional so every pre-0.2.1 project record stays valid (D-1): it is
# only written as ``"absent"`` when the source project has no Git repository.
_OPTIONAL_FIELDS = {"applies_to", "git_state"}


def validate_record(record: dict[str, typing.Any]) -> None:
    if not isinstance(record, dict):
        raise RegistryError("invalid-record")
    kind = record.get("kind")
    rules = _KIND_RULES.get(kind)
    if rules is None:
        raise RegistryError("invalid-record-kind")
    allowed = _COMMON_FIELDS | rules["fields"]
    required = allowed - _OPTIONAL_FIELDS
    if not (required <= set(record) <= allowed):
        raise RegistryError("invalid-record-fields")
    if record.get("schema") != RECORD_SCHEMA:
        raise RegistryError("invalid-record-schema")
    fingerprint = record.get("fingerprint")
    if not isinstance(fingerprint, str) or not _FINGERPRINT_RE.fullmatch(fingerprint):
        raise RegistryError("invalid-record-fingerprint")
    if fingerprint != content_fingerprint(record):
        raise RegistryError("record-fingerprint-mismatch")

    record_id = record.get("id")
    if (
        not isinstance(record_id, str)
        or not _ID_RE.fullmatch(record_id)
        or not record_id.startswith(rules["prefix"])
    ):
        raise RegistryError("invalid-record-id")
    if not _text(record.get("title")):
        raise RegistryError("invalid-record-title")
    if not _text(record.get("summary")) or len(record["summary"]) > SUMMARY_MAX_CHARS:
        raise RegistryError("invalid-record-summary")

    tags = record.get("tags")
    if (
        not isinstance(tags, list)
        or not tags
        or len(tags) > 12
        or any(
            not isinstance(tag, str)
            or not tag.strip()
            or len(tag.encode("utf-8")) > 32
            or not _TAG_RE.fullmatch(tag)
            for tag in tags
        )
    ):
        raise RegistryError("invalid-record-tags")

    project_id = record.get("source_project_id")
    if (
        not isinstance(project_id, str)
        or not _ID_RE.fullmatch(project_id)
        or not project_id.startswith("prj-")
    ):
        raise RegistryError("invalid-source-project-id")
    revision = record.get("source_revision")
    if not isinstance(revision, str) or not _REVISION_RE.fullmatch(revision):
        raise RegistryError("invalid-source-revision")
    if record.get("status") not in rules["statuses"]:
        raise RegistryError("invalid-record-status")
    if not _text(record.get("detail")):
        raise RegistryError("invalid-record-detail")

    evidence = record.get("evidence")
    if (
        not isinstance(evidence, list)
        or not evidence
        or len(evidence) > 4
        or any(
            not isinstance(pointer, str)
            or not pointer
            or len(pointer.encode("utf-8")) > 160
            for pointer in evidence
        )
    ):
        raise RegistryError("invalid-record-evidence")

    if kind == "project":
        root = record.get("project_root")
        if not isinstance(root, str) or not pathlib.Path(root).is_absolute():
            raise RegistryError("invalid-project-root")
        entrypoints = record.get("entrypoints")
        if not isinstance(entrypoints, list) or not entrypoints or not all(map(_text, entrypoints)):
            raise RegistryError("invalid-project-entrypoints")
    elif kind == "capability":
        if not _text(record.get("applicability")) or not _text(record.get("entrypoint")):
            raise RegistryError("invalid-capability-detail")
        if not _string_list(record.get("source_projects")):
            raise RegistryError("invalid-capability-source-projects")
        if not isinstance(record.get("superseded_by"), list):
            raise RegistryError("invalid-capability-superseded-by")
        _validate_applies_to(record.get("applies_to"), "capability")
    else:
        for field in ("trigger", "symptom", "root_cause", "required_action", "verification"):
            if not _text(record.get(field)):
                raise RegistryError(f"invalid-lesson-{field}")
        count = record.get("occurrence_count")
        if not isinstance(count, int) or isinstance(count, bool) or count < 1:
            raise RegistryError("invalid-lesson-occurrence-count")
        if not isinstance(record.get("high_cost"), bool):
            raise RegistryError("invalid-lesson-high-cost")
        if not _string_list(record.get("source_projects")):
            raise RegistryError("invalid-lesson-source-projects")
        if not isinstance(record.get("superseded_by"), list):
            raise RegistryError("invalid-lesson-superseded-by")
        _validate_applies_to(record.get("applies_to"), "lesson")

    if len(canonical_json(record)) > rules["max_bytes"]:
        raise RegistryError("record-too-large")


def with_fingerprint(record: dict[str, typing.Any]) -> dict[str, typing.Any]:
    """Return a copy of the record with its content fingerprint filled in.

    The fingerprint is derived, so callers set it from the record body rather than
    supplying it by hand.
    """
    value = dict(record)
    value["fingerprint"] = content_fingerprint(record)
    return value


def merge_on_fingerprint(
    existing: dict[str, typing.Any], incoming: dict[str, typing.Any],
) -> dict[str, typing.Any]:
    """Merge an incoming record into an existing record that shares its fingerprint.

    Cross-project merge: keep the existing stable ``id`` (external key) and union
    ``source_projects[]``; for lessons, also sum ``occurrence_count``. Merge only
    applies to reusable knowledge (``lesson``/``capability``); a ``project`` record is
    an identity anchor and is never folded into another. The survivor does not list the
    loser; the loser's own record carries the pointer (see ``superseded_tombstone``).
    """
    if existing.get("fingerprint") != incoming.get("fingerprint"):
        raise RegistryError("merge-fingerprint-mismatch")
    if existing.get("kind") != incoming.get("kind"):
        raise RegistryError("merge-kind-mismatch")
    if existing.get("kind") not in {"lesson", "capability"}:
        raise RegistryError("merge-not-applicable")
    merged = dict(existing)
    if merged.get("kind") == "lesson":
        merged["occurrence_count"] = (
            existing.get("occurrence_count", 0) + incoming.get("occurrence_count", 0)
        )
    seen: list[str] = []
    for item in [*existing.get("source_projects", []), *incoming.get("source_projects", [])]:
        if item not in seen:
            seen.append(item)
    merged["source_projects"] = seen
    # ``superseded_by`` lives on the *loser* (see superseded_tombstone), pointing to this
    # survivor — the survivor does not list its losers. Its own superseded_by is untouched.
    merged["superseded_by"] = list(existing.get("superseded_by", []))
    return merged


def superseded_tombstone(loser: dict[str, typing.Any], survivor_id: str) -> dict[str, typing.Any]:
    """Build the loser's tombstone record after a cross-project merge (AC-REG-1).

    The ``superseded_by`` field lives on the *old* record and points to the surviving
    id: the loser's file keeps its own id but carries ``status="superseded"`` and
    ``superseded_by=[survivor_id]``, so ``id`` stays an external stable key and the old
    id resolves to its survivor without a live file.
    """
    if not isinstance(loser.get("id"), str):
        raise RegistryError("invalid-record-id")
    tombstone = dict(loser)
    tombstone["status"] = "superseded"
    tombstone["superseded_by"] = [survivor_id]
    return with_fingerprint(tombstone)


def canonical_record(record: dict[str, typing.Any]) -> bytes:
    validate_record(record)
    # The fingerprint is deterministic from the record's content (content_fingerprint
    # excludes the ``fingerprint`` key itself), so including it keeps the persisted
    # bytes stable without a self-reference.
    return canonical_json(record)


def _environment(env: dict[str, str] | None) -> dict[str, str]:
    merged = os.environ.copy()
    if env:
        merged.update(env)
    merged.update({
        "GIT_AUTHOR_NAME": "MTP Registry",
        "GIT_AUTHOR_EMAIL": "mtp-registry@example.invalid",
        "GIT_COMMITTER_NAME": "MTP Registry",
        "GIT_COMMITTER_EMAIL": "mtp-registry@example.invalid",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_TERMINAL_PROMPT": "0",
    })
    return merged


def _classify_git_failure(stderr: str) -> str:
    """Map a Git failure to a Registry reason code (AC-REG-2).

    ``lock-contention``/``dirty-shared-state`` are retryable pending conditions; a
    permission or sandbox denial is *not* retryable by the protocol and must be
    surfaced distinctly so callers never loop on it.
    """
    text = stderr.lower()
    if "permission denied" in text or "operation not permitted" in text or "eacces" in text:
        return "permission-denied"
    if "sandbox" in text or "seccomp" in text or "apparmor" in text:
        return "sandbox-denied"
    return "git-operation-failed"


def _git(
    repository: pathlib.Path | None,
    *arguments: str,
    env: dict[str, str] | None = None,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    command = ["git", "-c", "core.hooksPath=/dev/null", "-c", "commit.gpgSign=false"]
    if repository is not None:
        command.extend(["-C", str(repository)])
    command.extend(arguments)
    result = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        env=_environment(env),
    )
    if check and result.returncode:
        raise RegistryError(
            _classify_git_failure(result.stderr or ""),
            result.stderr.strip() or "Git operation failed",
        )
    return result


def _reject_symlink_path(path: pathlib.Path) -> None:
    if path.is_symlink():
        raise RegistryError("unsafe-registry-path")


def _marker(repository: pathlib.Path, env: dict[str, str] | None = None) -> dict[str, typing.Any]:
    result = _git(repository, "show", f"{CANONICAL_BRANCH}:registry.json", env=env, check=False)
    if result.returncode:
        raise RegistryError("registry-identity-mismatch")
    try:
        value = json.loads(result.stdout)
    except json.JSONDecodeError as error:
        raise RegistryError("registry-identity-mismatch") from error
    if value.get("registry_id") != REGISTRY_ID or value.get("schema") != REGISTRY_SCHEMA:
        raise RegistryError("registry-identity-mismatch")
    return value


def _validate_repository(path: pathlib.Path, env: dict[str, str] | None = None) -> None:
    result = _git(path, "rev-parse", "--git-dir", env=env, check=False)
    if result.returncode:
        raise RegistryError("invalid-registry-repository")
    if _git(path, "rev-parse", "--verify", CANONICAL_BRANCH, env=env, check=False).returncode:
        raise RegistryError("invalid-registry-repository")
    _marker(path, env)


def git_available() -> bool:
    """Detect whether a usable Git binary exists without raising.

    A missing or broken Git installation must not crash Registry resolution;
    callers downgrade Registry-dependent capabilities and continue the basic
    document/local path instead (AC-014X-1).
    """
    try:
        result = subprocess.run(
            ["git", "--version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def _locator_form(raw: str) -> str:
    """Classify a raw locator string by syntactic form (no filesystem access).

    Returns one of: empty, relative, unc, windows-drive, posix-absolute, unsafe.
    Windows drive-letter forms are recognised on every host so POSIX tests can
    treat them as parser fixtures without touching the local filesystem
    (AC-014X-6).
    """
    if not isinstance(raw, str) or not raw.strip():
        return "empty"
    text = raw.strip()
    if text.startswith("//") or text.startswith("\\\\"):
        return "unc"
    if (
        len(text) >= 3
        and text[1] == ":"
        and text[0].isalpha()
        and text[2] in ("\\", "/")
    ):
        return "windows-drive"
    path = pathlib.Path(text)
    if not path.is_absolute():
        return "relative"
    if any(part in {".", ".."} for part in path.parts):
        return "unsafe"
    return "posix-absolute"


def normalize_registry_locator(raw: str, *, platform: str | None = None) -> pathlib.Path:
    """Validate a single locator value and return its absolute Path (pure syntax).

    Fails closed on empty, relative, UNC and unsafe forms. This classifier performs
    NO filesystem access — it never calls ``is_symlink`` / ``exists`` / ``is_dir``.
    A Windows drive-letter form is accepted only when the host platform is Windows;
    on a POSIX host it is recognised as a valid Windows form but reported as
    cross-platform inaccessible so the caller never performs filesystem access
    against it (AC-014X-6). Symlink / existence / repository validation belongs to
    ``resolve_registry``, which the caller invokes afterwards (AC-014X-1/-5/-6).
    """
    form = _locator_form(raw)
    if form == "empty":
        raise RegistryError("locator-empty")
    if form == "relative":
        raise RegistryError("locator-relative")
    if form == "unc":
        raise RegistryError("locator-unc")
    host = platform if platform is not None else sys.platform
    if form == "windows-drive":
        if not host.startswith("win"):
            raise RegistryError("locator-cross-platform-inaccessible")
    else:  # posix-absolute
        if host.startswith("win"):
            raise RegistryError("locator-cross-platform-inaccessible")
    path = pathlib.Path(raw.strip())
    if any(part in {".", ".."} for part in path.parts):
        raise RegistryError("unsafe-registry-path")
    return path


def resolve_registry(env: dict[str, str] | None = None) -> dict[str, str]:
    if not git_available():
        raise RegistryError("git-unavailable")
    result = _git(None, "config", "--global", "--get-all", CONFIG_KEY, env=env, check=False)
    values = [line for line in result.stdout.splitlines() if line]
    if result.returncode or not values:
        raise RegistryError("locator-missing")
    if len(values) != 1:
        raise RegistryError("locator-ambiguous")
    raw = values[0]
    path = pathlib.Path(raw)
    if not path.is_absolute() or any(part in {".", ".."} for part in path.parts):
        raise RegistryError("unsafe-registry-path")
    _reject_symlink_path(path)
    if not path.exists() or not path.is_dir():
        raise RegistryError("invalid-registry-repository")
    _validate_repository(path, env)
    revision = _git(path, "rev-parse", CANONICAL_BRANCH, env=env).stdout.strip()
    return {"path": str(path), "registry_id": REGISTRY_ID, "registry_revision": revision}


def read_locator_values(env: dict[str, str] | None = None) -> list[str]:
    """Read the same-OS-user global Git locator values (AC-014X-2).

    Reads only ``git config --global --get-all`` for ``CONFIG_KEY``; local and
    system configuration are never consulted. Returns the non-empty lines. Without
    Git this fails closed to ``git-unavailable`` so callers can downgrade Registry
    capability and continue the non-Git path (AC-014X-1).
    """
    if not git_available():
        raise RegistryError("git-unavailable")
    result = _git(None, "config", "--global", "--get-all", CONFIG_KEY, env=env, check=False)
    return [line for line in result.stdout.splitlines() if line]


def classify_locator(
    values: list[str],
    env: dict[str, str] | None = None,
) -> tuple[str, str | None]:
    """Classify locator values into ``missing``/``ambiguous``/``invalid``/``valid``.

    Drives the M-New bootstrap/repair decision (AC-014X-2/-3): a single syntactically
    valid, existing, structurally sound Registry is ``valid``; no value is ``missing``
    (prompt once then bootstrap); more than one value is ``ambiguous``; any other form
    (empty, duplicate, stale, malformed, moved, mismatched or unsafe) is ``invalid`` and
    requires explicit repair. Performs only read-only validation; it never writes.
    """
    if not values:
        return ("missing", None)
    if len(values) != 1:
        return ("ambiguous", None)
    raw = values[0]
    try:
        path = normalize_registry_locator(raw, platform=sys.platform)
    except RegistryError:
        return ("invalid", None)
    _reject_symlink_path(path)
    if not path.exists() or not path.is_dir():
        return ("invalid", None)
    try:
        _validate_repository(path, env)
    except RegistryError:
        return ("invalid", None)
    return ("valid", str(path))


def validate_registry_target(
    path: str | pathlib.Path,
    *,
    env: dict[str, str] | None = None,
) -> dict[str, str]:
    """Explicit repair validation of a user-supplied absolute Registry path (AC-014X-3).

    Accepts only an absolute path whose Registry ID, ``main`` branch, structure and
    safety checks pass. It never scans disks, guesses a path, silently creates a second
    Registry or overwrites an existing path. Raises ``RegistryError`` on any failure.
    """
    resolved = normalize_registry_locator(str(path), platform=sys.platform)
    _reject_symlink_path(resolved)
    if not resolved.exists() or not resolved.is_dir():
        raise RegistryError("invalid-registry-repository")
    _validate_repository(resolved, env)
    revision = _git(resolved, "rev-parse", CANONICAL_BRANCH, env=env).stdout.strip()
    return {"path": str(resolved), "registry_id": REGISTRY_ID, "registry_revision": revision}


def _record_path(record: dict[str, typing.Any]) -> str:
    rules = _KIND_RULES[record["kind"]]
    return f"{rules['directory']}/{record['id']}.json"


def _path_for_id(identifier: str) -> str:
    if identifier.startswith("prj-"):
        directory = "projects"
    elif identifier.startswith("cap-"):
        directory = "capabilities"
    elif identifier.startswith("les-"):
        directory = "lessons"
    else:
        raise RegistryError("invalid-record-id")
    return f"{directory}/{identifier}.json"


def _show_bytes(
    repository: pathlib.Path,
    revision: str,
    relative: str,
    env: dict[str, str] | None = None,
) -> bytes | None:
    result = _git(repository, "show", f"{revision}:{relative}", env=env, check=False)
    if result.returncode:
        return None
    return result.stdout.encode("utf-8")


def _main_paths(repository: pathlib.Path, env: dict[str, str] | None = None) -> list[str]:
    result = _git(
        repository, "ls-tree", "-r", "--name-only", CANONICAL_BRANCH, env=env, check=False,
    )
    if result.returncode:
        raise RegistryError("invalid-registry-repository")
    return sorted(line for line in result.stdout.splitlines() if line)


def _load_main_records(
    repository: pathlib.Path,
    env: dict[str, str] | None = None,
) -> tuple[str, list[dict[str, typing.Any]]]:
    _validate_repository(repository, env)
    revision = _git(repository, "rev-parse", CANONICAL_BRANCH, env=env).stdout.strip()
    records: list[dict[str, typing.Any]] = []
    for relative in _main_paths(repository, env):
        # Known benign non-record files live in the Registry root too: ``registry.json``
        # (identity marker), ``.gitignore`` (excludes the derived index + staging dir) and
        # ``README.md`` (human entry pointer, T-021-REGREP G-8). Skip them; anything else
        # unexpected still fails closed.
        if relative in _NON_RECORD_FILES:
            continue
        match = re.fullmatch(r"(projects|capabilities|lessons)/((?:prj|cap|les)-[a-z0-9-]+)\.json", relative)
        if match is None:
            raise RegistryError("non-index-artifact")
        content = _show_bytes(repository, revision, relative, env)
        if content is None:
            raise RegistryError("invalid-index-record")
        try:
            record = json.loads(content)
        except json.JSONDecodeError as error:
            raise RegistryError("invalid-index-record") from error
        validate_record(record)
        if _record_path(record) != relative or canonical_record(record) != content:
            raise RegistryError("invalid-index-record")
        if record["kind"] in {"capability", "lesson"} and record["status"] == "deprecated":
            raise RegistryError("non-effective-record")
        records.append(record)
    records.sort(key=lambda item: item["id"])
    return revision, records


def audit_registry(repository: str | pathlib.Path, env: dict[str, str] | None = None) -> dict[str, typing.Any]:
    path = pathlib.Path(repository)
    revision, records = _load_main_records(path, env)
    branches = _git(
        path, "for-each-ref", "--format=%(refname:short)", "refs/heads", env=env,
    ).stdout.splitlines()
    if branches != [CANONICAL_BRANCH]:
        raise RegistryError("orphan-temporary-branch")
    return {"registry_revision": revision, "record_count": len(records)}


def scan_index(repository: str | pathlib.Path, env: dict[str, str] | None = None) -> dict[str, typing.Any]:
    revision, records = _load_main_records(pathlib.Path(repository), env)
    entries = [
        {
            "id": record["id"],
            "kind": record["kind"],
            "title": record["title"],
            "summary": record["summary"],
            "tags": record["tags"],
            "source_project_id": record["source_project_id"],
            "source_revision": record["source_revision"],
            "status": record["status"],
            # applies_to is surfaced so callers can evaluate the expiry predicate; a
            # record whose predicate no longer holds is downgraded to review-needed,
            # never dropped (AC-REG-3).
            "applies_to": record.get("applies_to"),
        }
        for record in records
        if record["status"] in {"active", "review-needed"}
    ]
    return {
        "registry_id": REGISTRY_ID,
        "registry_revision": revision,
        "entries": entries,
        "total_match_cap": None,
    }


def _batch(values: list[typing.Any], offset: int, size: int) -> dict[str, typing.Any]:
    if not isinstance(offset, int) or isinstance(offset, bool) or offset < 0:
        raise RegistryError("invalid-offset")
    entries = values[offset:offset + size]
    next_offset = offset + len(entries)
    if next_offset >= len(values):
        next_offset = None
    return {"entries": entries, "next_offset": next_offset}


def summary_batch(index: dict[str, typing.Any], offset: int = 0) -> dict[str, typing.Any]:
    entries = index.get("entries")
    if not isinstance(entries, list):
        raise RegistryError("invalid-index")
    return _batch(entries, offset, SUMMARY_BATCH_SIZE)


def resolve_superseded(
    repository: str | pathlib.Path, identifier: str, env: dict[str, str] | None = None,
) -> str | None:
    """AC-REG-1: resolve an id that was folded away by a cross-project merge.

    After a merge the loser keeps its own file as a tombstone with ``status="superseded"``
    and ``superseded_by=[survivor_id]`` (the field lives on the old record and points to
    the survivor). Given a loser id, return the survivor's id so ``id`` stays an external
    stable key. Returns ``None`` when the id is not a superseded loser.
    """
    if not isinstance(identifier, str) or not identifier:
        raise RegistryError("invalid-record-id")
    path = pathlib.Path(repository)
    base = _git(path, "rev-parse", CANONICAL_BRANCH, env=env).stdout.strip()
    content = _show_bytes(path, base, _path_for_id(identifier), env)
    if content is None:
        return None
    try:
        record = json.loads(content)
    except json.JSONDecodeError:
        return None
    if record.get("status") == "superseded":
        superseded_by = record.get("superseded_by") or []
        if len(superseded_by) == 1:
            return superseded_by[0]
    return None


def detail_batch(
    repository: str | pathlib.Path,
    identifiers: list[str],
    offset: int = 0,
    env: dict[str, str] | None = None,
) -> dict[str, typing.Any]:
    if not isinstance(identifiers, list) or not all(isinstance(value, str) for value in identifiers):
        raise RegistryError("invalid-record-ids")
    path = pathlib.Path(repository)
    _validate_repository(path, env)
    revision = _git(path, "rev-parse", CANONICAL_BRANCH, env=env).stdout.strip()
    selected = _batch(identifiers, offset, DETAIL_BATCH_SIZE)
    records = []
    for identifier in selected["entries"]:
        relative = _path_for_id(identifier)
        content = _show_bytes(path, revision, relative, env)
        if content is None:
            raise RegistryError("record-not-found")
        try:
            record = json.loads(content)
        except json.JSONDecodeError as error:
            raise RegistryError("invalid-index-record") from error
        validate_record(record)
        # AC-REG-1: a superseded tombstone resolves to its survivor so an old id still
        # returns live knowledge (the tombstone stays on disk for the stable-key link).
        if record.get("status") == "superseded":
            survivor = resolve_superseded(path, identifier, env)
            if survivor is None:
                raise RegistryError("record-not-found")
            identifier = survivor
            relative = _path_for_id(identifier)
            content = _show_bytes(path, revision, relative, env)
            if content is None:
                raise RegistryError("record-not-found")
            try:
                record = json.loads(content)
            except json.JSONDecodeError as error:
                raise RegistryError("invalid-index-record") from error
            validate_record(record)
        if record["id"] != identifier or canonical_record(record) != content:
            raise RegistryError("invalid-index-record")
        records.append(record)
    return {
        "registry_revision": revision,
        "entries": records,
        "next_offset": selected["next_offset"],
    }


# Retryable pending reasons are transient shared-state conditions the next MTP
# invocation may clear. Permission / sandbox denials are NOT retryable: the protocol
# surfaces them as a failure and never loops (AC-REG-2).
RETRYABLE_PENDING_REASONS = frozenset({
    "lock-contention", "dirty-shared-state", "same-record-conflict", "second-main-race",
})


def pending_payload(record_id: str, reason: str) -> dict[str, str]:
    if reason not in RETRYABLE_PENDING_REASONS:
        raise RegistryError(reason)
    return {
        "status": "registry-pending",
        "registry_id": REGISTRY_ID,
        "record_id": record_id,
        "reason": reason,
        "persistence": "project-local-ai/NEXT.md-only",
        "retry": "next-relevant-mtp-invocation",
    }


def _common_directory(repository: pathlib.Path, env: dict[str, str] | None = None) -> pathlib.Path:
    raw = _git(repository, "rev-parse", "--git-common-dir", env=env).stdout.strip()
    value = pathlib.Path(raw)
    return value if value.is_absolute() else repository / value


def _shared_state_reason(repository: pathlib.Path, env: dict[str, str] | None = None) -> str | None:
    common = _common_directory(repository, env)
    if any(common.rglob("*.lock")):
        return "lock-contention"
    bare = _git(repository, "rev-parse", "--is-bare-repository", env=env).stdout.strip() == "true"
    if bare:
        return None
    status = _git(repository, "status", "--porcelain", "--untracked-files=all", env=env, check=False)
    if status.returncode:
        # A failure that is a permission/sandbox denial is not retryable; classify it
        # distinctly instead of masking it as dirty shared state (AC-REG-2).
        return _classify_git_failure(status.stderr or "")
    if status.stdout:
        return "dirty-shared-state"
    return None


def _detach_clean_main(repository: pathlib.Path, env: dict[str, str] | None = None) -> str | None:
    bare = _git(repository, "rev-parse", "--is-bare-repository", env=env).stdout.strip() == "true"
    if bare:
        return None
    branch = _git(repository, "symbolic-ref", "--quiet", "--short", "HEAD", env=env, check=False)
    if branch.returncode != 0 or branch.stdout.strip() != CANONICAL_BRANCH:
        return None
    detached = _git(repository, "checkout", "--detach", "-q", env=env, check=False)
    if detached.returncode:
        return _classify_git_failure(detached.stderr or "")
    return None


def _cleanup_owned(
    repository: pathlib.Path,
    worktree: pathlib.Path,
    temporary_root: pathlib.Path,
    branch: str,
    env: dict[str, str] | None,
) -> None:
    _git(repository, "worktree", "remove", "--force", str(worktree), env=env, check=False)
    _git(repository, "branch", "-D", branch, env=env, check=False)
    shutil.rmtree(temporary_root, ignore_errors=True)


def _empty_tree_record(record: dict[str, typing.Any]) -> bool:
    # Records that leave no file in the index: only ``deprecated``. A ``superseded``
    # tombstone MUST stay on disk — resolve_superseded/detail_batch read it to follow an
    # old id to its survivor; removing it would lose that link.
    return record["status"] in {"deprecated"}


def _prepare_commit(
    repository: pathlib.Path,
    base: str,
    records: list[dict[str, typing.Any]],
    agent_id: str,
    env: dict[str, str] | None,
) -> tuple[str, pathlib.Path, pathlib.Path, str]:
    safe_agent = re.sub(r"[^a-z0-9-]+", "-", agent_id.lower()).strip("-") or "agent"
    token = uuid.uuid4().hex
    branch = f"mtp-{safe_agent}-{token}"
    temporary_root = pathlib.Path(tempfile.mkdtemp(prefix="mtp-registry-"))
    worktree = temporary_root / "worktree"
    result = _git(
        repository, "worktree", "add", "-q", "-b", branch, str(worktree), base,
        env=env, check=False,
    )
    if result.returncode:
        _cleanup_owned(repository, worktree, temporary_root, branch, env)
        raise RegistryError("lock-contention")
    for record in records:
        relative = _record_path(record)
        target = worktree / relative
        if _empty_tree_record(record):
            if target.exists():
                target.unlink()
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(canonical_record(record))
    _git(worktree, "add", "-A", env=env)
    _git(
        worktree, "commit", "-qm", f"registry: update {' '.join(r['id'] for r in records)}",
        "--allow-empty", env=env,
    )
    commit = _git(worktree, "rev-parse", "HEAD", env=env).stdout.strip()
    return commit, worktree, temporary_root, branch


def _plan_merge(
    repository: pathlib.Path, record: dict[str, typing.Any], env: dict[str, str] | None = None,
) -> tuple[dict[str, typing.Any] | None, dict[str, typing.Any] | None]:
    """Cross-project merge plan: if main already holds the same content fingerprint
    (same kind, different id) for a reusable ``lesson``/``capability``, return the
    unioned survivor plus the loser's tombstone. Otherwise ``(None, None)``.

    The survivor (existing id) unions sources / sums lesson occurrences; it does not
    list the loser. The tombstone is the loser's own record with ``status="superseded"``
    and ``superseded_by=[survivor_id]`` (fields live on the old record and point to the
    survivor, AC-REG-1).
    """
    if record.get("kind") not in {"lesson", "capability"}:
        return None, None
    relative = _record_path(record)
    base = _git(repository, "rev-parse", CANONICAL_BRANCH, env=env).stdout.strip()
    for path in _main_paths(repository, env):
        if path == relative:
            continue
        content = _show_bytes(repository, base, path, env)
        if content is None:
            continue
        try:
            candidate = json.loads(content)
        except json.JSONDecodeError:
            continue
        if candidate.get("fingerprint") != record.get("fingerprint"):
            continue
        if candidate.get("kind") != record.get("kind"):
            continue
        survivor = with_fingerprint(merge_on_fingerprint(candidate, record))
        return survivor, superseded_tombstone(record, candidate["id"])
    return None, None


def _collapsed_text(value: str) -> str:
    return " ".join(value.split())


def _plain_text(value: str) -> str:
    """Drop inline markdown decoration so a generated sentence can match its source."""
    return value.replace("**", "").replace("`", "")


def _passport_text(root: str) -> str | None:
    """Return the four managed Passport block bodies, or None unless all four exist."""
    if not root or not pathlib.Path(root).is_absolute():
        return None
    path = pathlib.Path(root) / "CLAUDE.md"
    if not path.is_file():
        return None
    text = path.read_text(encoding="utf-8", errors="replace")
    parts: list[str] = []
    for section in PROJECT_PASSPORT_SECTIONS:
        match = re.search(
            rf"<!-- MTP:MAP:BEGIN section={re.escape(section)} -->"
            rf"(.*?)<!-- MTP:MAP:END section={re.escape(section)} -->",
            text, re.DOTALL,
        )
        if match is None:
            # A partial Passport cannot vouch for the summary; fail closed.
            return None
        parts.append(match.group(1).strip())
    return "\n".join(parts)


def project_record_problem(record: dict[str, typing.Any]) -> str | None:
    """Why a hand-published project record is unacceptable, or None.

    A project record is a projection of its source project's ``CLAUDE.md`` Passport:
    the setup and refresh paths derive it and never go through ``publish_record``.
    A public publish therefore has to prove the same quality bar before it may write.
    """
    summary = record.get("summary")
    if not isinstance(summary, str) or not summary.strip():
        return "project-summary-empty"
    if summary.strip().startswith(PROJECT_PLACEHOLDER_PREFIX) or "待替换" in summary:
        return "project-summary-placeholder"
    substantive = {
        tag for tag in record.get("tags", [])
        if isinstance(tag, str) and tag not in PROJECT_TRIVIAL_TAGS
    }
    if len(substantive) < PROJECT_MIN_SUBSTANTIVE_TAGS:
        return "project-summary-insufficient-tags"
    title = record.get("title")
    if isinstance(title, str) and _collapsed_text(summary) == _collapsed_text(title):
        return "project-summary-equals-title"
    # Fail closed: a project record must be checkable against its source Passport.
    # A missing root, a missing CLAUDE.md or missing managed blocks is not "unknown".
    passport = _passport_text(record.get("project_root"))
    if passport is None:
        return "project-source-passport-missing"
    plain = _plain_text(passport)
    missing = [
        part for part in summary.split("；")
        if part.strip() and _plain_text(part.strip()) not in plain
    ]
    if missing:
        return "project-summary-not-from-passport"
    return None


def publish_record(
    repository: str | pathlib.Path,
    record: dict[str, typing.Any],
    agent_id: str,
    *,
    env: dict[str, str] | None = None,
    merge: bool = False,
    before_integrate: typing.Callable[[int, pathlib.Path], None] | None = None,
) -> dict[str, typing.Any]:
    validate_record(record)
    if record["kind"] == "project":
        problem = project_record_problem(record)
        if problem is not None:
            raise RegistryError(problem)
    if record["kind"] == "lesson" and record["status"] == "candidate":
        raise RegistryError("candidate-local-only")
    path = pathlib.Path(repository)
    _validate_repository(path, env)
    # Cross-project merge is explicit (AC-REG-1/AC-LES-2): a caller that already detected
    # a same-fingerprint record passes ``merge=True`` to fold into it. The default publish
    # never silently collapses records, so distinct ids keep their own entries.
    record_id = record["id"]
    records = [record]
    merged_from: str | None = None
    if merge:
        survivor, tombstone = _plan_merge(path, record, env)
        if survivor is not None and tombstone is not None:
            records = [survivor, tombstone]
            merged_from = survivor["id"]

    def failure(reason: str) -> dict[str, typing.Any]:
        # Retryable transient conditions become registry-pending; a permission/sandbox
        # denial is not retryable and is raised as a hard failure (AC-REG-2).
        return pending_payload(record_id, reason)

    reason = _shared_state_reason(path, env)
    if reason:
        return failure(reason)
    # Remember the entering HEAD form (branch name or detached) so the publish can
    # restore it and leave no detached HEAD behind (0.2.0 publish end-state).
    original_branch = _git(
        path, "symbolic-ref", "--quiet", "--short", "HEAD", env=env, check=False,
    ).stdout.strip()
    reason = _detach_clean_main(path, env)
    if reason:
        return failure(reason)
    try:
        result = _publish_locked(
            path, records, record_id, agent_id, env=env, before_integrate=before_integrate,
        )
        if merged_from is not None and result.get("status") == "published":
            result["merged_from"] = merged_from
        return result
    finally:
        _restore_head(path, original_branch, env)


def _restore_head(
    repository: pathlib.Path, branch: str, env: dict[str, str] | None = None,
) -> None:
    """Restore the entering HEAD form.

    ``_detach_clean_main`` only detaches when HEAD was the canonical branch, so the
    only case that needs undoing is entering on ``main``; re-attach it. Other forms
    (another branch or already detached) were never changed and need no restore.
    """
    if branch == CANONICAL_BRANCH:
        _git(repository, "checkout", "-q", CANONICAL_BRANCH, env=env, check=False)


def _publish_locked(
    path: pathlib.Path,
    records: list[dict[str, typing.Any]],
    record_id: str,
    agent_id: str,
    *,
    env: dict[str, str] | None = None,
    before_integrate: typing.Callable[[int, pathlib.Path], None] | None = None,
) -> dict[str, typing.Any]:

    def desired_bytes(record: dict[str, typing.Any]) -> bytes | None:
        return None if _empty_tree_record(record) else canonical_record(record)

    # Desired end-state per record path; a merge publishes survivor + tombstone together.
    desired = {_record_path(record): desired_bytes(record) for record in records}
    for attempt in range(2):
        base = _git(path, "rev-parse", CANONICAL_BRANCH, env=env).stdout.strip()
        base_content = {relative: _show_bytes(path, base, relative, env) for relative in desired}
        try:
            commit, worktree, temporary_root, branch = _prepare_commit(
                path, base, records, agent_id, env,
            )
        except RegistryError as error:
            if error.code == "lock-contention":
                return pending_payload(record_id, "lock-contention")
            raise
        try:
            if before_integrate is not None:
                before_integrate(attempt, worktree)
            integrated = _git(
                path, "update-ref", f"refs/heads/{CANONICAL_BRANCH}", commit, base,
                env=env, check=False,
            )
            if integrated.returncode == 0:
                return {
                    "status": "published",
                    "registry_id": REGISTRY_ID,
                    "record_id": record_id,
                    "registry_revision": commit,
                    "attempts": attempt + 1,
                }

            current = _git(path, "rev-parse", CANONICAL_BRANCH, env=env).stdout.strip()
            current_content = {relative: _show_bytes(path, current, relative, env) for relative in desired}
            if current_content == desired:
                return {
                    "status": "published",
                    "registry_id": REGISTRY_ID,
                    "record_id": record_id,
                    "registry_revision": current,
                    "attempts": attempt + 1,
                }
            if current_content != base_content:
                return pending_payload(record_id, "same-record-conflict")
            if attempt == 1:
                return pending_payload(record_id, "second-main-race")
        finally:
            _cleanup_owned(path, worktree, temporary_root, branch, env)
    return pending_payload(record_id, "second-main-race")
