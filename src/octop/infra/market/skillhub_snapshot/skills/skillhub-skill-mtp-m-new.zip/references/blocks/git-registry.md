trigger: Git 不可用、Registry locator 缺失或失效、或要核对无 Git 语义
budget: 2000
next: 按 D-1 降级继续；跳过项写进 side_effects

# Git Capability and Registry Locator

Git 是可选增强，不是绝对前置；代码项目未 `git init` 按 Step 0 两轴矩阵硬停。每次调用
`plan_setup.py` 先做轻量能力检查：探测 `git --version`；无 Git 时继续非 Git 本地路径，将 Registry
查找/同步、checkpoint、tag、formal-release 等 Git 依赖能力标记为不可用且永不报告为
verified/Accepted，不要求、不询问、不安装 Registry locator，也不下载或打包 Git 作为隐藏依赖。

**无 Git 语义（D-1）**：目标不是 Git 仓库时仍可 create/adopt/upgrade 并注册——记录
`source_revision` 写 40 个 `0` 哨兵、附加 `git_state: "absent"`，预览 `side_effects` 显式列出
`skip-git-evidence`；这类记录由**仓级** `scripts/revalidate_registry.py` 判 current（该脚本
**不在本技能包内**），不会被永久降级。**current 项目记录没有自动刷新入口**：git 或生命周期变化
后需手工事务补写。Git 二进制不可用时，Registry 写入在 `side_effects` 中显式跳过
（`skip-registry` + 原因）或 fail closed，绝不静默零记录完成。

有 Git 时只读取同一 OS 用户的 `git config --global --get-all mtp.registry.mtp-local-registry-v1`：
唯一非空值即零交互使用；缺失则一次性提示该 OS 用户共享的绝对路径，再 initialize-or-attach 合法
Registry、写入并回读复验；重复/失效/移动/身份不符/结构损坏的值 fail closed 进入显式 repair——只
接受用户给出的绝对路径，校验 Registry ID、`main`、结构和安全后更新，绝不扫描磁盘、猜测路径、
静默创建第二个 Registry 或覆盖已有路径。locator 通过 OS 用户全局配置共享，不写入 Skill 路径、
manifest、`CLAUDE.md` 或 Passport；其他 OS 用户、容器、虚拟机或隔离 Git 配置需显式接入，不隐式
继承。可分发产物（source/candidate/template）不含 Monster 专属 Mac Registry 默认；Windows 风格
绝对路径（如 `D:\MTP_Registry`）仅作测试输入，非内嵌默认。

## 参考

- `references/claude-md-guide.md`：`CLAUDE.md` 十节撰写规范，含 `Structure` 目录树规则。
- `scripts/plan_setup.py`：预览、apply 与全部 `--json` 字段。
- 仓级 `scripts/revalidate_registry.py`：Registry 记录重校验（不在技能包内）。
