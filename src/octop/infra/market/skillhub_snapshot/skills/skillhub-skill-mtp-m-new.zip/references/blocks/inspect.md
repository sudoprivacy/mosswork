trigger: Step 0，确认目标路径、版本形态与 Git 前置
budget: 1900
next: 通过后到 preview-apply.md

# Step 0 Inspect（目标与前置，强制）

遵循 Think Before Coding、Simplicity First、Surgical Changes 和 Goal-Driven Execution：先报告版本
假设、风险和更简单的 current 路径，只执行 digest 绑定的最小 create/adopt/upgrade。

1. **确认目标绝对路径**：`pwd` 或显式给出项目绝对路径。禁止在未确认的 cwd 下使用相对 target；
   命令统一写 `--target "$PWD"` 或绝对路径。
2. **读取版本**：`$SKILL_DIR/MTP_VERSION`；只读检查目标目录与 `ai/mtp.json`。缺失 manifest 是
   create/adopt 的合法输入；目标 `0.2.4` manifest 为**四字段**（`mtp_version`、`profile`、
   `project_id`、`registry_id`），返回 current。`0.1.2` / `0.1.3` / `0.1.4` 的**双字段**
   manifest 与 `0.1.4` 的**四字段** manifest 进入 upgrade；未列出的版本、混合 schema 或额外字段
   零写。损坏 manifest、受管 marker 或 symlink 返回 invalid-project。除明确的
   create/adopt/upgrade 外都零写。
3. **Git 两轴判断**：

   | | 纯文档项目 | 代码项目 |
   |---|---|---|
   | Git 二进制不可用 | 维持 D-1 降级路径 | 同样降级，但 `skip-git-evidence` 必须显式警告并记录；绝不安装 Git |
   | Git 可用、项目未 `git init` | 不适用 | **apply 前硬停**：先 `git init` + 首提交，再重跑本流程 |

   「代码项目」是**确定性检查**，不得自由裁量：目标根目录 2 层内存在可识别源码文件（`.py`
   `.js` `.ts` `.dart` `.go` `.rs` `.java` `.kt` `.swift` `.c` `.cpp` `.cs` `.rb` `.php`
   `.sh` 等）或 manifest（`package.json`、`pyproject.toml`、`Cargo.toml`、`go.mod`、
   `pubspec.yaml`、`pom.xml`、`build.gradle`、`Makefile`、`CMakeLists.txt` 等），或
   `MTP_THINK.md` 声明代码交付物。`project_kind` 字段给出判定结果。
4. **预检**：`plan_setup.py --target <绝对路径> --json`，核对输出的 `target` 等于预期绝对路径、
   `git_precondition` 不为 `hard-stop-code-project-without-git`；任一不符即零写退出。
