trigger: Step 1 预览核对、Step 2 apply 前
budget: 2000
next: apply 成功后到 verify.md

# Step 1 Preview

```bash
python3 "$SKILL_DIR/scripts/plan_setup.py" --target "$PWD" --json
```

预览是只读 dry-run。必须逐项核对：

| 字段 | 含义 | 核对要求 |
|---|---|---|
| `target` | 目标绝对路径 | 必须等于预期项目根 |
| `decision` | create / adopt / upgrade / current / invalid | 符合目标形态 |
| `project_kind` | `code` / `doc` | 与需求原文一致 |
| `git_state` | `repo`+head 或 `absent`+reason | 与 Step 0 判断一致 |
| `git_precondition` | `ok` / `degraded-git-unavailable` / `hard-stop-…` | 不得为 hard-stop |
| `side_effects` | 写 Registry、commit、locator 变更、`skip-*` | 逐条过目 |
| `map_status` | ready / pending / stale | 记录初始状态 |
| `setup_complete` | 地图是否已填完 | 新项目应为 false |
| `ai_extra_files` | `ai/` 根超集文件 | 应为空；非空需说明 |
| `plan_digest` | 计划身份 | 下一步 apply 必须引用 |

# Step 2 Apply

只有 create/adopt/upgrade 可使用同一 digest 执行：

```bash
python3 "$SKILL_DIR/scripts/plan_setup.py" --target "$PWD" --apply \
  --expect-plan-digest <preview-plan-digest> --json
```

目标受管文件在 preview 后变化时 digest 不匹配并零写。apply 使用临时文件和原子 replace；任一失败
恢复原 bytes 与权限并清理新目录。current 重复执行零写，不兼容版本禁止 apply。根目录存在有效
`MTP_THINK.md` 时，只吸收 `Absorption Summary`：项目共识追加到 `ai/brief.md`，开放问题与 Backlog
候选追加到 `ai/backlog.md`。源文件 bytes 纳入 digest 且 apply 后保持不变；非法结构、非 UTF-8、
symlink 或 preview 后漂移均零写。

决策边界：

- 空目录：`create`；普通非 MTP 项目：`adopt`；
- 合同声明支持的终态 `0.1.2` / `0.1.3` / `0.1.4` / `0.2.0` / `0.2.1` / `0.2.2` MTP 项目：
  `upgrade`，按显式逐文件策略迁移目录并在提交事务前验证为 current；
- 当前 `0.2.4` 单版本项目：`current`，actions 为空；其他受管版本拒绝隐式升降级；
- marker 损坏或任一受管路径为 symlink：invalid-project 且零写。

`0.1.2`、`0.1.3`、`0.1.4`、`0.2.0`、`0.2.1`、`0.2.2` 和 `0.2.3` 是受支持的迁移基线；目标 `0.2.4` 不读取
`template_version`。依赖已移除 Skill ID 的非终态工作必须零写阻断，终态历史保留但不再成为路由
入口。后续版本发布前必须为每个受支持旧 MTP 版本加入迁移合同与正反例测试；不识别其他协议。

新建项目生成十区块 `CLAUDE.md`（每节都是 `待替换` 占位）和空 `ai/lessons.md`。create、adopt 或
upgrade 仅创建 `CLAUDE.md` 或按 `section=` 合并其 MTP managed block，保留 block 外用户内容与
项目已写的节正文。
