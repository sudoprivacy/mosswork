# CLAUDE.md 撰写规范（项目地图）

`CLAUDE.md` 是**别的项目通过 Registry 找到本项目时的第一个入口**，也是人/Agent 了解项目的直接入口。
它由 MTP 托管块（`<!-- MTP:BEGIN … -->`）承载，`project_memory sync` 维护其中 10 个托管节。

## 一句话原则

> **CLAUDE.md 是给「人 + Agent」看的第一入口——项目本身要写得具体、看得懂；机务细节才外链。**
> 讲清楚 **是什么 / 干什么 / 怎么干 / 到哪了**（要**具体**，能让人读懂这个项目），
> 但**字段、阈值、口径全文、bug 清单、对账数字**这类**细节**靠它指到的文件展开，**不要塞进来**。

「具体」指**项目层面**：说清它做什么、关键产物是什么、数据/流程怎么走、当前处在什么阶段——
而不是「见 XXX.md」一句话打发。**区分：项目实情（写具体）vs 机务细节（外链）。**

## 10 个托管节各该写什么

| 节 | 回答 | 该写 | 不该写 |
|---|---|---|---|
| `Project` | 是什么 | 名称、`Project ID`、`Registry ID`、入口、事实源；一句项目定位 | — |
| `Current State` | 到哪了 | **具体的当前阶段与在做什么**（能让人看懂进展） | 对账数字、逐条 bug 清单、逐项遗留（→ NEXT） |
| `End-to-End Flow` | 怎么干 | **本项目真实流水线**（输入→处理→输出/交付 + 失败回路），细节外链 | MTP 协议流程（见下） |
| `Structure` | 结构/去哪找 | **一句总述 + 带注释目录树**（导航节点 + 用途 + `ai/` 固定集合），集中在此一处 | 逐文件清单、生成物目录 |
| `Entry Points` | 入口 | `AGENTS.md`/`ai/NEXT.md`/`ai/check.sh` 等 | — |
| `Scope` | 干什么 | **具体做什么、关键产物是什么**（细节→ `ai/brief.md`） | 字段/阈值/口径全文 |
| `Boundaries` | 边界 | 只读输入、不可臆测项 | — |
| `Project Rules And Lessons` | 规则 | 关键规则**要点** + 指针（通用规则→ `AGENTS.md`） | 领域口径全文（→ `ai/brief.md`/`references/`） |
| `Required Behaviors` | 行为 | `触发 → 动作 → 验证` | 散文 |
| `Document Navigation` | 发现次序 | **渐进披露次序**（Registry → `CLAUDE.md` → `ai/`）+ 每个文件「答什么问题」 | 重复列 `Structure` 已有的路径 |

> **路径集中一处**：外部参考路径与 `ai/` 路径**只在 `Structure` 列一次**；别在 `Document Navigation`
> 等处重复。`Structure` 要写清**根目录每个文件夹是干什么用的**（给人看），让人一眼知道去哪儿找。

> **"具体 vs 细节"判据**：换个人读，能否**看懂这个项目做什么、到哪了**？能 → 够具体，留下；
> 读起来是**机务噪声**（字段值、数字、阈值、逐条 bug）→ 外链。**别用"见 XXX.md"一句话打发项目情况。**

## End-to-End Flow 怎么画（关键）

- **画项目自身流水线**，依据是**项目本体**：入口脚本 / 输入数据 / 输出/交付物。**不是** `plan.md`，
  **更不是** MTP 协议（`Define → Plan → Build → Lesson Check → …`）。
- 至少要画：① 主链路；② 失败/回退回路；③ 关键质量门；④ 能力分支（如无 Git）。
- 节点**短**（几个字）；关键口径最多在箭头上留一句；**细节外链**（`references/…`）。
- 新项目默认**十节全部**是占位（`待替换`）——建项目后**必须**逐节替换；未替换即写路径 lint 失败。

## Structure 怎么写（目录树）

`Structure` 固定为「一句总述 + 一个 `text` 目录树代码块 + `ai/` 固定集合说明」：

```text
项目根目录名/
├── src/          ← 源码
├── tests/        ← 测试
└── ai/           ← MTP 状态与证据
```

规则：

1. 根节点写**真实目录名**，与 `project_root` 一致。
2. 深度默认 **2–3 层**，超出 3 层改用指针（`详见 <目录>/README.md`）。
3. 每个条目必须有 `←` 注释，写「它是干什么的」，不是「它是什么类型」。
4. 只列**有导航价值**的目录与入口文件；同类文件用数量概括（`15 个 Dart 文件`）。
5. **排除**生成物与缓存：`build/`、`.dart_tool/`、`node_modules/`、`__pycache__/`、
   `.venv/`、`dist/`。
6. 树必须与真实结构一致；删除或移动目录后同步更新，否则视为文档缺陷。
7. 版本号、数量、唯一产物名等事实可直接写在注释里，便于判断时效。
8. `ai/` 内部文件**不展开进树**，只留 `ai/ ← MTP 状态与证据`，后接 `ai/` 根固定集合说明。

## 语言与体量

- **中文为主**（给人看）；保留必要英文 ID（`prj-…`、路径、命令、字段名——给 Agent 机器化读）。
- **每节尽量短**：一节只答一个问题；超过 1–2 屏就是塞多了，把细节挪出去。
- token/占位符（`{{PROJECT_NAME}}` 等）由 `m-new` 在 scaffold 时替换。

## 反例（E-3 / L-004 实测）

- 模板直接灌通用 MTP 协议流程图 → 24 个注册项目多数粘贴/翻译同一张图，与项目无关。
- `Current State` 塞对账数字、bug 清单 → 应只在 `ai/NEXT.md`。
- `Project Rules And Lessons` 塞领域口径全文 → 应在 `ai/brief.md`/`references/`。

## grep 自查（写完跑一下）

```bash
# 不该出现 MTP 协议词
grep -nE 'Define project facts|Lesson Check|Registry Sync Gate|scan Registry' CLAUDE.md
# 该出现的指针/占位
grep -n '待替换\|指针入口\|ai/NEXT.md\|ai/brief.md' CLAUDE.md
```

## 机器 lint（T-020-MAPLINT）

`project_memory` 带地图质量 lint（`map_lint`）：

- **未替换即失败**（T-021-MAPQUALITY）：模板十节全部带 `待替换` 标记。写路径（m-new scaffold 校验 /
  sync apply）见 `待替换` → **error**；只读扫描 → **warn**。建项目收尾仍有未替换占位，
  **不得报告 setup 完成**（D-8 硬门）。
- **缺失 / 空节 → error**；**正文与模板占位逐字相同 → warn**（说明这节从没被填过）。
- **协议签名 fail-closed（只挂写路径）**：`End-to-End Flow` 段若同时含 `Plan`+`Lesson Check`
  或 `Define`+`Registry Sync`（成对 AND）→ **写路径报错**（m-new scaffold 校验 / sync apply）；
  **只读扫描（`lint` 子命令 / corpus）只 warn**，不炸存量项目。
- **预算 warn-only**：每节 >1200B（臃肿）或 <80B（`见 XXX.md` 式打发）→ warn。
- 自查：`python3 <m-build>/scripts/project_memory.py lint --target <项目>`。
- **豁免**：教育类项目真有名为「Plan/Lesson Check」的工序时，在 `End-to-End Flow` 段内加
  `<!-- mtpl:flow-is-project-specific -->`，该次降为 warn（留 5 秒出路）。
