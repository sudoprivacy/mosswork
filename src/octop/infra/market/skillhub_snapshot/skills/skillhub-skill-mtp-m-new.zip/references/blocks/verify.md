trigger: Step 3，setup 收尾与地图填写
budget: 1000
next: setup_complete=true 才算完成

# Step 3 Verify（收尾硬门 D-8）

1. 重跑 `plan_setup.py --json`；只有 `setup_complete=true` 才算 setup 完成。
2. 逐节填充前**必须先读** `references/claude-md-guide.md`，按**项目本体**写满十节；`Structure`
   节使用带注释目录树。
3. 跑 `m-build/scripts/project_memory.py sync-current-state --apply` 生成 `Current State`。
4. 跑 `m-build/scripts/project_memory.py lint`；有 error 或 warning 时不得报告完成。
5. 重跑 `plan_setup.py --json` 直到 `setup_complete=true`。
6. **升级或接入已有项目**：`ai/OWNER_DECISIONS.md` 由脚本以骨架创建
   （`seed-managed-preserve-content`），随后由主 Agent 读 `ai/IMPL_LOG.md`、`ai/NEXT.md`、
   `ai/archive/` 与 `CLAUDE.md`，把已有的 owner 裁定按「日期 / 决定 / 原话 / 影响范围」整理进去；
   没有可整理的留空，不编造。留空骨架不算完成本步。

`setup_complete=true` 只证明受管块结构与占位完整，**不证明节内容形态正确**。不得以「已
scaffold」报告 setup 完成。

MTP 固定七入口和当前 Task schema。主 Agent 是唯一调度、集成和 `ai/` writer；实现默认 primary，
parallel writer 仅在有真实收益、范围互斥、隔离 worktree 和 interrupt 时允许。审查按风险执行，
不能因能力缺失而降级。
