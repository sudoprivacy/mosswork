#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import uuid
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
CONTRACT_PATH = ROOT / "references/setup-contract.json"
TEMPLATE_ROOT = ROOT / "assets/template"
MTP_END = "<!-- MTP:END -->"
CURRENT_MTP_BEGIN_RE = re.compile(r"<!-- MTP:BEGIN version=([^ ]+) -->")
LEGACY_MTP_BEGIN_RE = re.compile(r"<!-- MTP:BEGIN template=(\d+) -->")
MTP_BEGIN_RE = re.compile(r"<!-- MTP:BEGIN (?:version=[^ ]+|template=\d+) -->")
MTP_MAP_BEGIN_RE = re.compile(r"<!-- MTP:MAP:BEGIN section=(.+?) -->")
MTP_MAP_PRESERVED_BEGIN = "<!-- MTP:MAP-PRESERVED:BEGIN -->"
MTP_MAP_PRESERVED_END = "<!-- MTP:MAP-PRESERVED:END -->"
MTP_MAP_LEGACY_SECTION = "<legacy-block>"
MTP_MAP_REMAINDER_SECTION = "<unmanaged-block-text>"


def _map_end_marker(name: str) -> str:
    return f"<!-- MTP:MAP:END section={name} -->"
PROJECT_NAME_TOKEN = b"{{PROJECT_NAME}}"
PROJECT_ID_TOKEN = b"{{PROJECT_ID}}"
SOURCE_REVISION_TOKEN = b"{{SOURCE_REVISION}}"
PROJECT_ID_RE = re.compile(r"prj-[a-z0-9][a-z0-9-]{2,63}")
SUMMARY_RE = re.compile(r"^## 1\. Absorption Summary\s*$", re.MULTILINE)
SECTION_RE = re.compile(r"^ {0,3}##[ \t]+(?!#)", re.MULTILINE)
FIELD_RE = re.compile(r"^### (.+?)\s*$", re.MULTILINE)
BACKLOG_FIELDS = {"开放问题", "Backlog 候选"}
SKIP_FIELDS = {"吸收提示"}
UPGRADE_OPERATIONS = {
    "preserve-existing",
    "update-managed-block",
    "seed-managed-preserve-content",
    "replace-managed",
    "delete",
}
SEMVER_RE = re.compile(
    r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    r"(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$"
)
# Migration classification must recognize terminal historical routes from the declared 0.1.1 source.
REMOVED_SKILL_IDS = ("m-think", "m-shape", "m-execute")


class SetupError(RuntimeError):
    pass


class TransactionError(SetupError):
    pass


@dataclass
class RegistryTransaction:
    path: Path
    module: Any
    locator_values: tuple[str, ...]
    existed: bool
    original_branch: str | None = None
    created: bool = False
    created_parent_directories: list[Path] = field(default_factory=list)
    registry_exposed: bool = False
    created_base: str | None = None
    locator_changed: bool = False
    base: str | None = None
    prepared_commit: str | None = None
    worktree: Path | None = None
    temporary_root: Path | None = None
    branch: str | None = None
    main_advanced: bool = False
    record_path: str | None = None
    prepared_bytes: bytes | None = None
    effects: list[dict[str, Any]] = field(default_factory=list)


def _exec_quiet(spec: Any) -> Any:
    """Import a module without leaving __pycache__ behind.

    Loading the template's ``ai/registry.py`` (or ``project_memory.py``) from the
    shipped tree otherwise drops a ``.pyc`` next to it, which then fails the package
    contract test and the mirror diff for anyone who runs setup outside the gate.
    """
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    return module


def _load_registry_module() -> Any:
    path = TEMPLATE_ROOT / "ai/registry.py"
    name = f"mtp_setup_registry_{uuid.uuid4().hex}"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise SetupError("registry helper unavailable")
    return _exec_quiet(spec)


def _registry_git_config(module: Any, env: dict[str, str] | None = None) -> tuple[str, ...]:
    result = module._git(None, "config", "--global", "--get-all", module.CONFIG_KEY, env=env, check=False)
    if result.returncode not in (0, 1):
        raise SetupError("registry locator unreadable")
    return tuple(line for line in result.stdout.splitlines() if line)


def _registry_path(value: str | None, contract: dict[str, Any]) -> Path:
    # No portable default: a Registry locator must be supplied explicitly
    # (from git config or a one-time prompt). A Monster-specific path must
    # never be baked into distributed artifacts (AC-014X-5).
    if not value:
        raise SetupError("registry locator required")
    path = Path(value).expanduser()
    if not path.is_absolute() or any(part in {".", ".."} for part in path.parts):
        raise SetupError("unsafe registry path")
    if path.is_symlink():
        raise SetupError("unsafe registry path")
    return path


def _missing_registry_parent_directories(path: Path) -> list[Path]:
    missing: list[Path] = []
    parent = path.parent
    while not parent.exists():
        if parent.is_symlink():
            raise SetupError("unsafe registry path")
        missing.append(parent)
        parent = parent.parent
    if parent.is_symlink() or not parent.is_dir():
        raise SetupError("unsafe registry path")
    return list(reversed(missing))


def _registry_precondition(
    path: Path,
    contract: dict[str, Any],
) -> tuple[dict[str, Any], Any, tuple[str, ...]]:
    module = _load_registry_module()
    values = _registry_git_config(module)
    if len(values) > 1 or (values and values[0] != str(path)):
        raise SetupError("registry locator mismatch")
    state: dict[str, Any] = {
        "path": str(path),
        "locator": list(values),
        "exists": path.exists(),
        "main": None,
        "head": None,
        "shared_state": None,
    }
    if path.exists():
        if not path.is_dir():
            raise SetupError("invalid registry repository")
        try:
            module._validate_repository(path)
        except Exception as error:
            raise SetupError(f"invalid registry repository: {error}") from error
        state["main"] = module._git(path, "rev-parse", module.CANONICAL_BRANCH).stdout.strip()
        head = module._git(path, "symbolic-ref", "--quiet", "--short", "HEAD", check=False)
        state["head"] = head.stdout.strip() if head.returncode == 0 else None
        state["shared_state"] = module._shared_state_reason(path)
        if state["shared_state"]:
            raise SetupError(f"registry unavailable: {state['shared_state']}")
    return state, module, values


def _registry_record(
    target: Path,
    project_id: str,
    source_revision: str,
    git_state: str | None = None,
) -> dict[str, Any] | None:
    title = " ".join(target.name.replace("\n", " ").split()) or "project"
    content = _registry_content(target, title)
    if content is None:
        return None
    record = {
        "schema": "mtp-registry-record-v1",
        "kind": "project",
        "id": project_id,
        "title": title,
        "summary": content["summary"],
        "tags": content["tags"],
        "source_project_id": project_id,
        "source_revision": source_revision,
        "status": "active",
        "detail": "CLAUDE.md#Project Passport",
        "evidence": ["CLAUDE.md", "ai/mtp.json"],
        "project_root": str(target.absolute()),
        "entrypoints": ["CLAUDE.md", "ai/NEXT.md"],
    }
    if git_state == "absent":
        record["git_state"] = "absent"
    # 0.2.0 records carry a content fingerprint (derived, not hand-set).
    return _load_registry_module().with_fingerprint(record)


def _set_registry_locator(module: Any, path: Path, values: tuple[str, ...], env: dict[str, str] | None = None) -> None:
    if values == (str(path),):
        return
    module._git(None, "config", "--global", "--unset-all", module.CONFIG_KEY, env=env, check=False)
    result = module._git(None, "config", "--global", "--add", module.CONFIG_KEY, str(path), env=env, check=False)
    if result.returncode:
        raise SetupError("registry locator write failed")


def _restore_registry_locator(module: Any, values: tuple[str, ...], env: dict[str, str] | None = None) -> None:
    module._git(None, "config", "--global", "--unset-all", module.CONFIG_KEY, env=env, check=False)
    for value in values:
        result = module._git(None, "config", "--global", "--add", module.CONFIG_KEY, value, env=env, check=False)
        if result.returncode:
            raise OSError("registry locator restore failed")


def _acquire_registry_locator_lock(path: Path) -> tuple[Path, int]:
    lock = path.parent / ".mtp-local-registry-v1.lock"
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as error:
        raise SetupError("registry locator lock contention") from error
    return lock, descriptor


def _release_registry_locator_lock(lock: Path, descriptor: int) -> None:
    os.close(descriptor)
    if lock.exists():
        lock.unlink()


def _registry_locator_owned(module: Any, path: Path) -> bool:
    try:
        return _registry_git_config(module) == (str(path),)
    except SetupError:
        return False


def _registry_repair_state(
    capability: str,
    values: tuple[str, ...],
) -> tuple[dict[str, Any] | None, Any, tuple[str, ...], int, list[Path]]:
    """Structured repair state for an ambiguous/duplicate/mismatched/invalid locator.

    Replaces the previous bare ``SetupError("registry locator mismatch")`` so the
    caller can offer explicit repair instead of crashing (AC-014X-3).
    """
    module = _load_registry_module()
    state = {
        "capability": capability,
        "path": None,
        "locator": list(values),
        "exists": None,
        "main": None,
        "head": None,
        "shared_state": None,
    }
    return state, module, tuple(values), 0, []


def _registry_inspect(
    decision: str,
    registry_path: str | None,
    contract: dict[str, Any],
) -> tuple[dict[str, Any] | None, Any, tuple[str, ...], int, list[Path]]:
    """Compute the Registry inspect state for a setup decision (AC-014X-1/-2/-3).

    The same-OS-user global Git locator is the single source of truth. With Git but no
    explicit ``registry_path``: a unique valid locator is reused with zero interaction;
    a missing locator is recorded as needing a one-time bootstrap; an ambiguous/duplicate/
    invalid locator returns a structured repair state instead of raising. An explicit
    ``registry_path`` that conflicts with a valid global locator also returns a structured
    repair state. An explicit path under a missing global locator validates as a
    bootstrap/initialize-or-attach candidate (the registry may not exist yet, in which
    case the apply transaction creates it).
    """
    if decision not in {"create", "adopt", "upgrade"}:
        return None, None, (), 0, []
    module = _load_registry_module()
    if not module.git_available():
        state = {
            "capability": "git-unavailable",
            "path": None,
            "locator": [],
            "exists": None,
            "main": None,
            "head": None,
            "shared_state": None,
        }
        return state, module, (), 0, []
    # Global locator is the single source of truth (AC-014X-2/-4).
    try:
        values = tuple(module.read_locator_values())
    except module.RegistryError:
        values = ()
    kind, located = module.classify_locator(list(values))
    if registry_path:
        supplied = str(registry_path)
        if kind == "valid" and located != supplied:
            # Explicit path conflicts with a valid global locator -> explicit repair.
            return _registry_repair_state("registry-locator-mismatch", values)
        effective_path = supplied
    else:
        if kind == "valid":
            effective_path = located
        elif kind == "missing":
            state = {
                "capability": "registry-locator-missing",
                "path": None,
                "locator": list(values),
                "exists": None,
                "main": None,
                "head": None,
                "shared_state": None,
            }
            return state, module, tuple(values), 1, []
        else:  # ambiguous / invalid
            return _registry_repair_state(f"registry-locator-{kind}", values)
    path = _registry_path(effective_path, contract)
    if kind in ("valid", "missing"):
        registry_state, module, locator_values = _registry_precondition(path, contract)
    else:
        # Ambiguous/invalid global locator: an explicit path is an explicit repair
        # candidate and must be validated directly, without the global mismatch check.
        try:
            result = module.validate_registry_target(path)
        except module.RegistryError:
            return _registry_repair_state(f"registry-locator-{kind}", values)
        registry_state = {
            "path": result["path"],
            "locator": list(values),
            "exists": True,
            "main": result["registry_revision"],
            "head": None,
            "shared_state": None,
        }
        # Preserve the *observed* global locator values so the apply transaction
        # actually replaces them: _set_registry_locator short-circuits when the
        # supplied values already equal the target path, which would otherwise
        # leave duplicate/stale locators behind (AC-014X-3 repair->write->re-read).
        locator_values = tuple(values)
    registry_directories = (
        [] if registry_state["exists"] else _missing_registry_parent_directories(path)
    )
    registry_mutations = len(registry_directories) + (0 if registry_state["exists"] else 1)
    registry_mutations += 0 if locator_values else 1
    registry_mutations += 2  # prepare off-main and final CAS advancement
    return registry_state, module, tuple(locator_values), registry_mutations, registry_directories


def bootstrap_locator(
    registry_path: str | Path,
    *,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    """One-time bootstrap of the global Git Registry locator (AC-014X-2).

    Validates the user-supplied absolute path, writes it to the same-OS-user global Git
    config, then re-reads it to confirm. Requires Git and fails closed on any validation
    or write error. Never scans disks or silently creates a second Registry.
    """
    return _write_locator(registry_path, env=env)


def repair_locator(
    registry_path: str | Path,
    *,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Explicit repair of a moved, identity-mismatched or otherwise invalid locator (AC-014X-3).

    Accepts only a user-supplied absolute path whose Registry ID, ``main`` branch,
    structure and safety checks pass, then writes and re-validates it. Never overwrites
    an existing path silently or guesses a replacement.
    """
    return _write_locator(registry_path, env=env)


def _write_locator(
    registry_path: str | Path,
    *,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    module = _load_registry_module()
    if not module.git_available():
        raise SetupError("cannot write locator without Git")
    resolved = module.validate_registry_target(registry_path, env=env)
    current = _registry_git_config(module, env)
    lock, descriptor = _acquire_registry_locator_lock(Path(registry_path))
    try:
        _set_registry_locator(module, Path(registry_path), current, env)
        reread = module.resolve_registry(env=env)
    finally:
        _release_registry_locator_lock(lock, descriptor)
    if reread["path"] != resolved["path"]:
        raise SetupError("locator re-validation mismatch after write")
    return reread


def _bootstrap_registry(state: RegistryTransaction, injector: FaultInjector) -> None:
    """Create/validate the Registry and write the locator; no project record."""
    module = state.module
    path = state.path
    if not state.existed:
        for directory in _missing_registry_parent_directories(path):
            directory.mkdir()
            state.created_parent_directories.append(directory)
            injector.mutation()
        path.mkdir()
        state.created = True
        result = module._git(None, "init", "-q", "-b", module.CANONICAL_BRANCH, str(path), check=False)
        if result.returncode:
            raise SetupError("registry initialization failed")
        state.effects.append({"action": "create-registry", "path": str(path)})
        marker = {"registry_id": module.REGISTRY_ID, "schema": module.REGISTRY_SCHEMA}
        (path / "registry.json").write_bytes(module.canonical_json(marker))
        module._git(path, "add", "registry.json")
        module._git(path, "commit", "-qm", "registry: initialize")
        state.created_base = module._git(path, "rev-parse", module.CANONICAL_BRANCH).stdout.strip()
        state.registry_exposed = state.locator_values == (str(path),)
        injector.mutation()
    else:
        module._validate_repository(path)

    locator_lock, locator_descriptor = _acquire_registry_locator_lock(path)
    try:
        _set_registry_locator(module, path, state.locator_values)
    finally:
        _release_registry_locator_lock(locator_lock, locator_descriptor)
    state.registry_exposed = True
    if state.locator_values != (str(path),):
        state.locator_changed = True
        state.effects.append({"action": "set-registry-locator", "path": str(path)})
        injector.mutation()


def _prepare_registry(
    state: RegistryTransaction,
    record: dict[str, Any],
    injector: FaultInjector,
) -> None:
    module = state.module
    path = state.path
    _bootstrap_registry(state, injector)

    state.original_branch = state.module._git(
        path, "symbolic-ref", "--quiet", "--short", "HEAD", check=False,
    ).stdout.strip() or None
    reason = module._shared_state_reason(path)
    if reason:
        raise SetupError(f"registry unavailable: {reason}")
    reason = module._detach_clean_main(path)
    if reason:
        raise SetupError(f"registry unavailable: {reason}")
    state.base = module._git(path, "rev-parse", module.CANONICAL_BRANCH).stdout.strip()
    state.record_path = f"projects/{record['id']}.json"
    state.prepared_bytes = module.canonical_record(record)
    commit, worktree, temporary_root, branch = module._prepare_commit(
        path, state.base, [record], "m-new", None,
    )
    state.prepared_commit = commit
    state.worktree = worktree
    state.temporary_root = temporary_root
    state.branch = branch
    state.effects.append({
        "action": "write-registry-record",
        "registry": str(path),
        "kind": record.get("kind"),
        "directory": "projects" if record.get("kind") == "project" else None,
    })
    injector.mutation()


def _cleanup_registry_prepare(state: RegistryTransaction) -> None:
    if state.worktree is None or state.temporary_root is None or state.branch is None:
        return
    state.module._cleanup_owned(
        state.path, state.worktree, state.temporary_root, state.branch, None,
    )
    branch = state.module._git(
        state.path, "show-ref", "--verify", f"refs/heads/{state.branch}", check=False,
    )
    if branch.returncode == 0 or state.worktree.exists() or state.temporary_root.exists():
        raise SetupError("registry temporary state cleanup failed")
    state.worktree = None
    state.temporary_root = None
    state.branch = None


def _finalize_registry(state: RegistryTransaction, injector: FaultInjector) -> None:
    if state.base is None or state.prepared_commit is None:
        raise SetupError("registry transaction is incomplete")
    result = state.module._git(
        state.path, "update-ref", f"refs/heads/{state.module.CANONICAL_BRANCH}",
        state.prepared_commit, state.base, check=False,
    )
    if result.returncode:
        raise SetupError("registry main changed during setup")
    state.main_advanced = True
    state.effects.append({
        "action": "commit-registry",
        "registry": str(state.path),
        "identity": REGISTRY_COMMIT_IDENTITY,
    })
    injector.mutation()
    _cleanup_registry_prepare(state)
    # Restore the HEAD form we detached during prepare: entering on the canonical branch
    # must leave the Registry worktree on that branch (not a detached HEAD). Without this
    # a freshly bootstrapped Registry is left detached with a working tree that does not
    # reflect main.
    if state.original_branch == state.module.CANONICAL_BRANCH and state.path.exists():
        restored = state.module._git(
            state.path, "checkout", "-q", state.module.CANONICAL_BRANCH, check=False,
        )
        if restored.returncode:
            raise SetupError("registry checkout restore failed")


def _new_registry_is_unshared(state: RegistryTransaction, own_lock: Path | None = None) -> bool:
    expected = state.base or state.created_base
    if not state.created or expected is None or not state.path.exists():
        return False
    module = state.module
    main = module._git(
        state.path, "rev-parse", module.CANONICAL_BRANCH, check=False,
    )
    if main.returncode or main.stdout.strip() != expected:
        return False
    refs = module._git(
        state.path, "for-each-ref", "--format=%(refname)", check=False,
    )
    if refs.returncode or refs.stdout.splitlines() != [f"refs/heads/{module.CANONICAL_BRANCH}"]:
        return False
    worktrees = module._git(state.path, "worktree", "list", "--porcelain", check=False)
    if worktrees.returncode or len(re.findall(r"^worktree ", worktrees.stdout, re.M)) != 1:
        return False
    common = module._common_directory(state.path)
    locks = list(common.rglob("*.lock"))
    if any(path != own_lock for path in locks):
        return False
    status = module._git(state.path, "status", "--porcelain", "--untracked-files=all", check=False)
    return status.returncode == 0 and not status.stdout


def _remove_new_registry_if_unshared(state: RegistryTransaction) -> bool:
    if not state.path.exists():
        return False
    if not state.registry_exposed:
        shutil.rmtree(state.path)
        return True
    try:
        locator_lock, locator_descriptor = _acquire_registry_locator_lock(state.path)
    except SetupError:
        return False
    common = state.module._common_directory(state.path)
    lock = common / "refs" / "heads" / f"{state.module.CANONICAL_BRANCH}.lock"
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        _release_registry_locator_lock(locator_lock, locator_descriptor)
        return False
    try:
        os.close(descriptor)
        if not _registry_locator_owned(state.module, state.path):
            return False
        if not _new_registry_is_unshared(state, lock):
            return False
        if not _registry_locator_owned(state.module, state.path):
            return False
        shutil.rmtree(state.path)
        return True
    finally:
        if lock.exists():
            lock.unlink()
        _release_registry_locator_lock(locator_lock, locator_descriptor)


def _git_blob_oid(content: bytes) -> str:
    """Object id Git assigns to ``content`` as a blob (SHA-1 repositories)."""
    return hashlib.sha1(b"blob %d\0" % len(content) + content).hexdigest()


def _rollback_registry(state: RegistryTransaction) -> None:
    errors: list[str] = []
    if state.main_advanced and state.base and state.prepared_commit and state.path.exists():
        current = state.module._git(
            state.path, "rev-parse", state.module.CANONICAL_BRANCH, check=False,
        ).stdout.strip()
        if current != state.prepared_commit:
            errors.append("restore registry main failed")
        else:
            # Move the branch back with a CAS first: preparation left HEAD detached, so
            # a reset alone would only move the detached HEAD.
            result = state.module._git(
                state.path, "update-ref", f"refs/heads/{state.module.CANONICAL_BRANCH}",
                state.base, state.prepared_commit, check=False,
            )
            if result.returncode:
                errors.append("restore registry main failed")
            elif state.record_path:
                # Ownership is decided by content on both sides of the checkout, never
                # by path alone: a foreign worktree edit or a foreign staged blob that
                # happens to land on our record path must survive untouched.
                expected = state.prepared_bytes
                record_file = state.path / state.record_path
                worktree_bytes = record_file.read_bytes() if record_file.is_file() else None
                worktree_mode = (
                    stat.S_IMODE(record_file.stat().st_mode) if record_file.is_file() else None
                )
                # Compare the staged blob by object id, never by re-reading it through a
                # text-mode pipe: universal newlines would hide a CRLF foreign blob.
                index = state.module._git(
                    state.path, "ls-files", "-s", "--", state.record_path, check=False,
                )
                index_entries = [line for line in index.stdout.splitlines() if line.strip()]
                index_fields = index_entries[0].split() if len(index_entries) == 1 else []
                index_matches = bool(
                    len(index_fields) >= 2
                    and index_fields[0] == "100644"
                    and index_fields[1] == _git_blob_oid(expected)
                )
                no_index = not index_entries
                no_worktree = worktree_bytes is None
                worktree_owned = (
                    not no_worktree
                    and worktree_bytes == expected
                    and worktree_mode == 0o644
                )
                foreign = (
                    index.returncode != 0
                    # An entry we cannot match is foreign.
                    or (not no_index and not index_matches)
                    # Bytes that are not ours are foreign.
                    or (not no_worktree and not worktree_owned)
                    # Either side alone is foreign: a staged deletion (no index entry)
                    # or an unstaged deletion (no worktree file) must both survive.
                    or (no_index != no_worktree)
                )
                if foreign:
                    errors.append(
                        f"registry index or worktree has foreign content: {state.record_path}"
                    )
                elif worktree_bytes is None and not index_entries:
                    # The record never reached the main worktree (the failure hit before
                    # the finalize checkout); rolling main back is all that is needed.
                    pass
                elif state.module._git(
                    state.path, "cat-file", "-e", f"{state.base}:{state.record_path}", check=False,
                ).returncode == 0:
                    restored = state.module._git(
                        state.path, "checkout", state.base, "--", state.record_path, check=False,
                    )
                    if restored.returncode:
                        errors.append("restore registry worktree failed")
                else:
                    # The transaction created this record; drop it from index and disk
                    # without touching any other path in the shared Registry.
                    state.module._git(
                        state.path, "rm", "--cached", "--ignore-unmatch", "-q",
                        state.record_path, check=False,
                    )
                    if record_file.exists():
                        record_file.unlink()
    try:
        _cleanup_registry_prepare(state)
    except Exception as error:
        errors.append(str(error))
    created_registry_removed = False
    if state.created and state.path.exists():
        try:
            created_registry_removed = _remove_new_registry_if_unshared(state)
        except OSError as error:
            errors.append(f"remove new registry failed: {error}")
    elif state.original_branch == state.module.CANONICAL_BRANCH and state.path.exists():
        result = state.module._git(state.path, "checkout", "-q", state.module.CANONICAL_BRANCH, check=False)
        if result.returncode:
            errors.append("restore registry checkout failed")
    if state.locator_changed and (not state.created or created_registry_removed or not state.path.exists()):
        try:
            locator_lock, locator_descriptor = _acquire_registry_locator_lock(state.path)
            try:
                if not (state.created and created_registry_removed) or _registry_locator_owned(
                    state.module, state.path,
                ):
                    _restore_registry_locator(state.module, state.locator_values)
            finally:
                _release_registry_locator_lock(locator_lock, locator_descriptor)
        except (OSError, SetupError) as error:
            errors.append(str(error))
    if not state.created or created_registry_removed or not state.path.exists():
        for directory in reversed(state.created_parent_directories):
            try:
                if directory.exists():
                    directory.rmdir()
            except OSError as error:
                errors.append(f"remove new registry parent failed: {error}")
    if errors:
        raise OSError("; ".join(errors))


@dataclass
class FaultInjector:
    fail_after: int | None = None
    rollback_failures: int = 0
    mutations: int = 0

    def mutation(self) -> None:
        self.mutations += 1
        if self.fail_after == self.mutations:
            raise SetupError(f"injected failure after mutation {self.mutations}")

    def before_rollback(self) -> None:
        if self.rollback_failures > 0:
            self.rollback_failures -= 1
            raise OSError("injected rollback failure")


def load_contract() -> dict[str, Any]:
    value = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise SetupError("invalid setup contract")
    _upgrade_specs(value)
    return value


def _relative_path(value: Any) -> str:
    if not isinstance(value, str) or not value:
        raise SetupError("invalid managed relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or path.as_posix() != value or any(part in {"", ".", ".."} for part in path.parts):
        raise SetupError("invalid managed relative path")
    return value


def _semver(value: Any) -> tuple[tuple[int, int, int], tuple[str, ...] | None]:
    match = SEMVER_RE.fullmatch(value) if isinstance(value, str) else None
    if match is None:
        raise SetupError("invalid upgrade version")
    prerelease = None if match.group(4) is None else tuple(match.group(4).split("."))
    if prerelease is not None and any(item.isdigit() and len(item) > 1 and item[0] == "0" for item in prerelease):
        raise SetupError("invalid upgrade version")
    return (int(match.group(1)), int(match.group(2)), int(match.group(3))), prerelease


def _compare_semver(left: Any, right: Any) -> int:
    left_core, left_pre = _semver(left)
    right_core, right_pre = _semver(right)
    if left_core != right_core:
        return -1 if left_core < right_core else 1
    if left_pre is None or right_pre is None:
        return 0 if left_pre is right_pre else (1 if left_pre is None else -1)
    for left_item, right_item in zip(left_pre, right_pre):
        if left_item == right_item:
            continue
        left_numeric = left_item.isdigit()
        right_numeric = right_item.isdigit()
        if left_numeric and right_numeric:
            return -1 if int(left_item) < int(right_item) else 1
        if left_numeric != right_numeric:
            return -1 if left_numeric else 1
        return -1 if left_item < right_item else 1
    return (len(left_pre) > len(right_pre)) - (len(left_pre) < len(right_pre))


def _upgrade_specs(contract: dict[str, Any]) -> list[dict[str, Any]]:
    upgrade = contract.get("upgrade")
    if not isinstance(upgrade, dict) or set(upgrade) != {
        "source_namespace", "baseline", "path_policy", "release_requirement",
        "supported_path_fields", "operation_values", "supported",
    }:
        raise SetupError("invalid upgrade contract")
    baseline = upgrade["baseline"]
    if (
        upgrade["source_namespace"] != "MTP"
        or upgrade["path_policy"] != "explicit-to-current"
        or upgrade["supported_path_fields"] != ["from", "managed_paths", "operations"]
        or not isinstance(upgrade["operation_values"], list)
        or not all(isinstance(item, str) for item in upgrade["operation_values"])
        or set(upgrade["operation_values"]) != UPGRADE_OPERATIONS
        or not isinstance(upgrade["release_requirement"], str)
        or not upgrade["release_requirement"]
        or not isinstance(baseline, dict)
        or set(baseline) != {"mtp_version"}
        or not isinstance(baseline["mtp_version"], str)
        or not baseline["mtp_version"]
        or not isinstance(upgrade["supported"], list)
    ):
        raise SetupError("invalid upgrade contract")

    template_values = contract.get("template_files")
    if not isinstance(template_values, list) or not all(isinstance(item, str) for item in template_values):
        raise SetupError("invalid template files")
    template_files = set(template_values)
    target_version = contract.get("version", {}).get("mtp_version")
    baseline_version = baseline["mtp_version"]
    _semver(target_version)
    _semver(baseline_version)
    sources: set[str] = set()
    for spec in upgrade["supported"]:
        if not isinstance(spec, dict) or set(spec) != {"from", "managed_paths", "operations"}:
            raise SetupError("invalid upgrade path")
        source = spec["from"]
        managed_paths = spec["managed_paths"]
        operations = spec["operations"]
        if (
            not isinstance(source, dict)
            or set(source) != {"mtp_version"}
            or not isinstance(source["mtp_version"], str)
            or not source["mtp_version"]
            or not isinstance(operations, dict)
            or not isinstance(managed_paths, list)
            or not all(isinstance(item, str) for item in managed_paths)
            or len(managed_paths) != len(set(managed_paths))
            or not template_files.issubset(operations)
        ):
            raise SetupError("invalid upgrade path")
        managed = {_relative_path(relative) for relative in managed_paths}
        if not {"AGENTS.md", "CLAUDE.md", "ai/mtp.json"}.issubset(managed):
            raise SetupError("invalid upgrade source managed paths")
        _semver(source["mtp_version"])
        identity = source["mtp_version"]
        if _compare_semver(identity, baseline_version) < 0 or _compare_semver(identity, target_version) >= 0:
            raise SetupError("upgrade source is outside the supported version range")
        if identity in sources:
            raise SetupError("duplicate upgrade source")
        sources.add(identity)
        for relative, operation in operations.items():
            _relative_path(relative)
            if operation not in UPGRADE_OPERATIONS:
                raise SetupError("invalid upgrade operation")
            if relative in template_files and operation == "delete":
                raise SetupError("target template file cannot be deleted")
            if relative not in template_files and operation != "delete":
                raise SetupError("non-template upgrade path must be deleted")
            if operation == "delete" and relative not in managed:
                raise SetupError("upgrade cannot delete an unowned path")
        if operations.get("ai/mtp.json") != "replace-managed":
            raise SetupError("upgrade must replace ai/mtp.json")
    if baseline_version not in sources:
        raise SetupError("upgrade baseline must be supported")
    return upgrade["supported"]


def _upgrade_spec(manifest: dict[str, Any], contract: dict[str, Any]) -> dict[str, Any] | None:
    identity = manifest["mtp_version"]
    return next(
        (
            spec for spec in _upgrade_specs(contract)
            if spec["from"]["mtp_version"] == identity
        ),
        None,
    )


def _managed_relatives(contract: dict[str, Any]) -> list[str]:
    relatives = set(contract["template_files"])
    for spec in _upgrade_specs(contract):
        relatives.update(spec["operations"])
    return sorted(relatives)


def _managed_paths(target: Path, contract: dict[str, Any]) -> list[Path]:
    paths = [target / relative for relative in _managed_relatives(contract)]
    paths.extend((
        target / "ai",
        target / "AGENTS.md",
        target / "CLAUDE.md",
        target / "MTP_THINK.md",
    ))
    return paths


def _reject_symlinks(target: Path, contract: dict[str, Any]) -> None:
    absolute = target.absolute()
    for path in (absolute, *absolute.parents[:-1]):
        if path.is_symlink() and path.parent != Path(path.anchor):
            raise SetupError(f"target path cannot contain a symlink: {path}")
    for path in _managed_paths(target, contract):
        current = path
        while current != target:
            if current.is_symlink():
                raise SetupError(f"managed path cannot be a symlink: {current.relative_to(target)}")
            current = current.parent
    ai = target / "ai"
    if ai.exists() and not ai.is_dir():
        raise SetupError("managed ai path must be a directory")
    for relative in _managed_relatives(contract):
        path = target / relative
        if path.exists() and not path.is_file():
            raise SetupError(f"managed file path is not a file: {relative}")


def _manifest(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise SetupError("invalid manifest") from error
    if not isinstance(value, dict):
        raise SetupError("invalid manifest fields")
    return value


def _marker_value(path: Path, begin_re: re.Pattern[str], end: str, namespace: str) -> str | None:
    if not path.exists():
        return None
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as error:
        raise SetupError(f"invalid managed root encoding: {path.name}") from error
    begins = list(begin_re.finditer(text))
    end_count = text.count(end)
    has_marker = f"<!-- {namespace}:BEGIN" in text or end in text
    if not has_marker:
        return None
    if len(begins) != 1 or end_count != 1 or begins[0].start() > text.index(end):
        raise SetupError(f"invalid managed marker: {path.name}")
    return begins[0].group(1)


def _validate_markers(
    target: Path,
    expected: str | None,
    begin_re: re.Pattern[str],
    *,
    required: bool,
) -> bool:
    values = [
        _marker_value(target / name, begin_re, MTP_END, "MTP")
        for name in ("AGENTS.md", "CLAUDE.md")
    ]
    if required and any(value is None for value in values):
        raise SetupError("versioned project requires both managed root blocks")
    present = [value for value in values if value is not None]
    if present and len(set(present)) != 1:
        raise SetupError("managed root template versions disagree")
    if expected is not None and present and present[0] != expected:
        raise SetupError("managed root template does not match manifest")
    return bool(present)


def _current_manifest(manifest: dict[str, Any], contract: dict[str, Any]) -> str | None:
    fields = set(manifest)
    if fields not in (
        {"mtp_version", "profile"},
        {"mtp_version", "profile", "project_id", "registry_id"},
    ):
        return None
    version = manifest["mtp_version"]
    if manifest["profile"] != contract["version"]["profile"]:
        raise SetupError("unsupported profile")
    if not isinstance(version, str):
        raise SetupError("invalid MTP version")
    _semver(version)
    if fields != {"mtp_version", "profile"}:
        # A four-field manifest is a *modern* project (project_id/registry_id present).
        # If it matches the current version it is "current"; if it is an older release it
        # is a modern prior release to upgrade from (its identity fields are validated by
        # the same rules). Returning the version lets classify() route it to the upgrade
        # path rather than treating an older four-field manifest as a hard error.
        if not isinstance(manifest.get("project_id"), str) or not PROJECT_ID_RE.fullmatch(manifest["project_id"]):
            raise SetupError("invalid project_id")
        if manifest.get("registry_id") != contract["registry"]["registry_id"]:
            raise SetupError("invalid registry_id")
    elif version == contract["version"]["mtp_version"]:
        raise SetupError("current project manifest is incomplete")
    return version


def _upgrade_manifest(manifest: dict[str, Any], contract: dict[str, Any]) -> bool:
    # Both manifest schemas may be an upgrade source: the old two-field schema and the
    # modern four-field schema (project_id/registry_id). An older modern-schema release with an
    # accompanying `from:0.1.4` spec is thus upgradeable, not "unsupported".
    if set(manifest) not in (
        {"mtp_version", "profile"},
        {"mtp_version", "profile", "project_id", "registry_id"},
    ):
        return False
    if manifest["profile"] != contract["version"]["profile"]:
        raise SetupError("unsupported profile")
    return _upgrade_spec(manifest, contract) is not None


def _upgrade_source_is_terminal(target: Path) -> bool:
    """Only old-ID history is preserved; active old-ID work cannot be migrated."""
    next_path = target / "ai/NEXT.md"
    if not next_path.exists():
        return True
    try:
        text = next_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as error:
        raise SetupError("invalid upgrade state") from error
    if not any(skill_id in text for skill_id in REMOVED_SKILL_IDS):
        return True
    state = re.search(r"^- task/state:\s*.+?/\s*(\w+)", text, re.MULTILINE)
    return state is not None and state.group(1) == "Accepted"


def classify(target: Path, contract: dict[str, Any]) -> str:
    _reject_symlinks(target, contract)
    manifest = _manifest(target / "ai/mtp.json")
    if manifest is None:
        if _validate_markers(target, None, CURRENT_MTP_BEGIN_RE, required=False) or \
                _validate_markers(target, None, LEGACY_MTP_BEGIN_RE, required=False):
            raise SetupError("managed markers require ai/mtp.json")
        return "create" if not target.exists() or not any(
            path.name != ".git" for path in target.iterdir()
        ) else "adopt"
    current_version = _current_manifest(manifest, contract)
    if current_version is not None:
        if current_version != contract["version"]["mtp_version"]:
            if not _upgrade_manifest(manifest, contract) or _upgrade_spec(manifest, contract) is None:
                return "unsupported-project-version"
            _validate_markers(target, current_version, CURRENT_MTP_BEGIN_RE, required=True)
            if not _upgrade_source_is_terminal(target):
                raise SetupError("non-terminal work depends on removed Skill ID")
            return "upgrade"
        _validate_markers(target, current_version, CURRENT_MTP_BEGIN_RE, required=True)
        missing = [relative for relative in contract["template_files"] if not (target / relative).is_file()]
        if missing:
            raise SetupError(f"current project missing required managed files: {', '.join(missing)}")
        return "current"
    raise SetupError("invalid manifest fields")


def planned_actions(target: Path, decision: str, contract: dict[str, Any]) -> list[dict[str, str]]:
    if decision in {"current", "unsupported-project-version"}:
        return []
    actions: list[dict[str, str]] = []
    if decision == "upgrade":
        manifest = _manifest(target / "ai/mtp.json")
        spec = None if manifest is None else _upgrade_spec(manifest, contract)
        if spec is None:
            raise SetupError("missing declared upgrade path")
        operations = spec["operations"]
        source_managed = set(spec["managed_paths"])
        ordered = [*contract["template_files"], *sorted(set(operations) - set(contract["template_files"]))]
        for relative in ordered:
            destination = target / relative
            operation = operations[relative]
            if destination.exists() and operation != "preserve-existing" and relative not in source_managed:
                raise SetupError(f"upgrade cannot modify an unowned path: {relative}")
            if operation == "delete":
                if destination.exists():
                    actions.append({"path": relative, "operation": operation})
            elif operation == "preserve-existing":
                if not destination.exists():
                    actions.append({"path": relative, "operation": "create"})
            elif operation in {"update-managed-block", "seed-managed-preserve-content"}:
                actions.append({
                    "path": relative,
                    "operation": operation if destination.exists() else "create",
                })
            else:
                actions.append({"path": relative, "operation": operation})
        return actions
    for relative in contract["template_files"]:
        destination = target / relative
        policy = contract["adoption_policy"][relative]
        if not destination.exists():
            operation = "create"
        elif decision == "adopt" and policy in {
            "update-managed-block", "seed-managed-preserve-content",
        }:
            operation = policy
        else:
            continue
        actions.append({"path": relative, "operation": operation})
    return actions


def _think_absorption(target: Path) -> dict[str, str] | None:
    source = target / "MTP_THINK.md"
    if not source.exists():
        return None
    if source.is_symlink() or not source.is_file():
        raise SetupError("invalid Think source")
    data = source.read_bytes()
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise SetupError("invalid Think source encoding") from error
    matches = list(SUMMARY_RE.finditer(text))
    if len(matches) != 1:
        raise SetupError("Think source requires one Absorption Summary")
    start = matches[0].end()
    next_section = SECTION_RE.search(text, start)
    summary = text[start:next_section.start() if next_section else len(text)].strip()
    fields = list(FIELD_RE.finditer(summary))
    if not fields:
        raise SetupError("Think Absorption Summary has no fields")

    brief_parts: list[str] = []
    backlog_parts: list[str] = []
    for index, field in enumerate(fields):
        name = field.group(1).strip()
        body_start = field.end()
        body_end = fields[index + 1].start() if index + 1 < len(fields) else len(summary)
        body = summary[body_start:body_end].strip()
        if not body or name in SKIP_FIELDS:
            continue
        rendered = f"### {name}\n{body}"
        (backlog_parts if name in BACKLOG_FIELDS else brief_parts).append(rendered)

    if not brief_parts and not backlog_parts:
        raise SetupError("Think Absorption Summary has no absorbable content")

    digest = hashlib.sha256(data).hexdigest()
    marker = f"<!-- MTP:ABSORBED source=MTP_THINK.md sha256={digest} -->"
    return {
        "sha256": digest,
        "brief": marker + "\n" + "\n\n".join(brief_parts) + "\n",
        "backlog": marker + "\n" + "\n\n".join(backlog_parts) + "\n",
    }


SENTINEL_SOURCE_REVISION = "0" * 40
REGISTRY_COMMIT_IDENTITY = "MTP Registry <mtp-registry@example.invalid>"


def _project_memory_module() -> Any | None:
    """Load the map rules (`m-build`'s project_memory) installed beside this skill."""
    path = Path(__file__).resolve().parents[2] / "m-build/scripts/project_memory.py"
    if not path.is_file():
        return None
    spec = importlib.util.spec_from_file_location(
        f"mtp_setup_project_memory_{uuid.uuid4().hex}", path,
    )
    if spec is None or spec.loader is None:
        return None
    return _exec_quiet(spec)


AI_ROOT_FILES = frozenset({
    "backlog.md", "brief.md", "check.sh", "facts.json", "HANDOFF.md",
    "IMPL_LOG.md", "lessons.md", "mtp.json", "NEXT.md", "OWNER_DECISIONS.md",
    "plan.md", "registry.py", "review.md",
})

CODE_MANIFESTS = frozenset({
    "package.json", "pyproject.toml", "setup.py", "Cargo.toml", "go.mod",
    "pubspec.yaml", "pom.xml", "build.gradle", "Gemfile", "composer.json",
    "CMakeLists.txt", "Makefile", "mix.exs", "Package.swift",
})
CODE_EXTENSIONS = frozenset({
    ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".dart", ".go",
    ".rs", ".java", ".kt", ".swift", ".c", ".h", ".cc", ".cpp", ".hpp",
    ".cs", ".rb", ".php", ".sh", ".m", ".mm", ".scala", ".pl", ".lua",
})
CODE_DECLARATIONS = ("交付代码", "代码实现", "源码", "code deliverable")
PROJECT_SCAN_SKIP = frozenset({
    ".git", "node_modules", "build", "dist", ".venv", "venv", "__pycache__",
    ".dart_tool", "target", ".next", "vendor",
})


def _project_kind(target: Path, max_depth: int = 2) -> str:
    """D1: deterministic code-vs-doc classification; no free-form agent judgement.

    Bounded walk only (``iterdir`` + depth cap); never a repo-wide scan.
    """
    base = target.resolve()
    if not base.is_dir():
        return "doc"
    stack: list[tuple[Path, int]] = [(base, 0)]
    while stack:
        current, depth = stack.pop()
        try:
            entries = list(current.iterdir())
        except OSError:
            continue
        for entry in entries:
            try:
                is_dir = entry.is_dir()
            except OSError:
                continue
            if is_dir:
                if (
                    depth + 1 < max_depth
                    and entry.name not in PROJECT_SCAN_SKIP
                    and not entry.name.startswith(".")
                ):
                    stack.append((entry, depth + 1))
                continue
            if entry.name in CODE_MANIFESTS or entry.suffix in CODE_EXTENSIONS:
                return "code"
    think = base / "MTP_THINK.md"
    if think.is_file():
        text = think.read_text(encoding="utf-8", errors="replace")
        if any(marker in text for marker in CODE_DECLARATIONS):
            return "code"
    return "doc"


def _git_precondition(target: Path, git_state: dict[str, Any], project_kind: str) -> str:
    """Two-axis matrix: Git unavailable degrades; code project without git hard-stops."""
    if git_state["reason"] == "git-unavailable":
        return "degraded-git-unavailable"
    if project_kind == "code" and git_state["state"] == "absent":
        return "hard-stop-code-project-without-git"
    return "ok"


# B: Registry discovery summary is derived from the Passport managed blocks only.
PASSPORT_SECTIONS = ("Project", "Scope", "Current State", "Structure")
SEED_TAGS = frozenset({
    "rural-road", "road", "gis", "flutter", "fastapi", "postgis", "minio",
    "weak-network", "photo-workflow", "short-video", "remotion", "macos",
    "voice-agent", "codex", "skill-hub", "service-hub", "automation",
    "documents", "reporting", "data-pipeline", "cli", "desktop", "web",
    "mobile", "api", "registry", "mcp", "testing", "scheduling", "gis-data",
    # AC-B-6: domain words already in use by the four hand-written records the
    # 0.2.1 discovery feedback cites as the only readable ones.
    "road-routing", "rpp", "networkx", "shapefile",
    "wecom", "personal-wechat", "workbuddy", "session-archive", "bot",
    "task-management", "yq-yuejihua", "segment-level-linkage",
    "defect-dictionary", "monthly-plan",
})
SUMMARY_MIN_TAGS = 3


def _passport_bodies(target: Path) -> dict[str, str]:
    """Return the four Passport managed-block bodies by section; never other ai/ files."""
    path = target / "CLAUDE.md"
    if not path.is_file():
        return {}
    text = path.read_text(encoding="utf-8", errors="replace")
    bodies: dict[str, str] = {}
    for section in PASSPORT_SECTIONS:
        pattern = (
            rf"<!-- MTP:MAP:BEGIN section={re.escape(section)} -->"
            rf"(.*?)<!-- MTP:MAP:END section={re.escape(section)} -->"
        )
        match = re.search(pattern, text, re.DOTALL)
        if match:
            bodies[section] = match.group(1).strip()
    return bodies


def _passport_blocks(target: Path) -> str:
    bodies = _passport_bodies(target)
    return "\n".join(bodies.get(section, "") for section in PASSPORT_SECTIONS)


def _first_sentence(body: str) -> str:
    for raw in body.splitlines():
        line = raw.strip().lstrip("-*").strip()
        if not line or line.startswith(("```", "├", "└", "│", "`ai/` 根固定集合")):
            continue
        line = line.replace("**", "").replace("`", "")
        sentence = re.split(r"[。；;.]", line, maxsplit=1)[0].strip()
        if sentence:
            return sentence
    return ""


def _collapsed_text(value: str) -> str:
    return " ".join(value.split())


def _summary_sources_missing(parts: list[str], sources: dict[str, str]) -> list[str]:
    """AC-B-3: every summary part must be exactly a declared Passport section sentence.

    Comparing whole parts against their own section's first sentence is a source-span
    provenance check: it rejects short, non-Latin and compound-token fabrications that a
    token-boundary scan lets through (``AI 三维建模 GIS``, ``gis`` vs ``not-gis``,
    ``123gis`` vs ``gis``).
    """
    allowed = {_first_sentence(body).strip() for body in sources.values()}
    return [part for part in parts if part.strip() not in allowed]


def _registry_content(target: Path, title: str) -> dict[str, Any] | None:
    """Derive summary/tags from the Passport; return None when the result is hollow."""
    bodies = _passport_bodies(target)
    blocks = "\n".join(bodies.get(section, "") for section in PASSPORT_SECTIONS)
    if not blocks or "待替换" in blocks:
        return None
    scope = _first_sentence(bodies.get("Scope", ""))
    current = _first_sentence(bodies.get("Current State", ""))
    lowered = blocks.lower()
    tags = sorted({
        tag for tag in SEED_TAGS
        # A domain word is bounded by anything that is not a tag character; hyphens are
        # tag characters, so ``gis`` must not match inside ``not-gis``.
        if re.search(rf"(?<![a-z0-9-]){re.escape(tag)}(?![a-z0-9-])", lowered)
    })
    if len(tags) < SUMMARY_MIN_TAGS:
        return None
    parts = [part for part in (scope, current) if part]
    summary = "；".join(parts)
    if not summary or summary.startswith("MTP project:"):
        return None
    if _collapsed_text(summary) == _collapsed_text(title):
        return None
    if _summary_sources_missing(parts, bodies):
        return None
    return {"summary": summary[:280], "tags": ["mtp", "project", *tags][:12]}


def _ai_root_extra(target: Path) -> list[str]:
    """L-028: report files outside the fixed ai/ root set; never blocks setup."""
    ai_root = target / "ai"
    if not ai_root.is_dir():
        return []
    return sorted(
        item.name for item in ai_root.iterdir()
        if item.is_file() and item.name not in AI_ROOT_FILES
    )


def _map_status(target: Path) -> dict[str, Any]:
    """D-8 hard gate input: is the project map actually filled in?"""
    module = _project_memory_module()
    if module is None:
        return {"ready": False, "pending": [], "stale": False, "errors": ["map-check-unavailable"]}
    return module.map_status(target)


def _git_state(target: Path) -> dict[str, Any]:
    """Describe the target's Git evidence: ``repo`` with HEAD, or ``absent`` + reason.

    The state feeds the plan digest, so a plan previewed before ``git init`` can no
    longer be applied to a repository (and vice versa). ``absent`` is a declared
    state, not an error: the Registry record then carries the sentinel revision and
    ``git_state: "absent"`` (D-1).
    """
    try:
        probe = subprocess.run(
            ["git", "-C", str(target), "rev-parse", "--show-toplevel"],
            check=False,
            capture_output=True,
            text=True,
        )
        head = subprocess.run(
            ["git", "-C", str(target), "rev-parse", "HEAD"],
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        return {"state": "absent", "reason": "git-unavailable", "head": None}
    if probe.returncode != 0:
        return {"state": "absent", "reason": "not-a-repository", "head": None}
    revision = head.stdout.strip()
    if head.returncode == 0 and re.fullmatch(r"[0-9a-f]{40}", revision):
        return {"state": "repo", "reason": None, "head": revision}
    return {"state": "absent", "reason": "no-head", "head": None}


def _source_revision(target: Path) -> str:
    state = _git_state(target)
    if state["state"] == "repo":
        return state["head"]
    return SENTINEL_SOURCE_REVISION


def _template_file(
    relative: str,
    target: Path | None = None,
    project_id: str = "{{PROJECT_ID}}",
    source_revision: str = "{{SOURCE_REVISION}}",
) -> tuple[bytes, int]:
    path = TEMPLATE_ROOT / relative
    content = path.read_bytes()
    if target is not None:
        project_name = target.name.replace("\\", "/").replace('"', "'").replace("`", "'")
        project_name = " ".join(project_name.splitlines()).strip() or "project"
        content = content.replace(PROJECT_NAME_TOKEN, project_name.encode("utf-8"))
        content = content.replace(PROJECT_ID_TOKEN, project_id.encode("utf-8"))
        content = content.replace(SOURCE_REVISION_TOKEN, source_revision.encode("utf-8"))
    return content, stat.S_IMODE(path.stat().st_mode)


def _managed_block(template: bytes) -> bytes:
    text = template.decode("utf-8")
    match = MTP_BEGIN_RE.search(text)
    if match is None:
        raise SetupError("template managed block is missing")
    end = text.find(MTP_END, match.start())
    if end == -1:
        raise SetupError("template managed block is incomplete")
    return text[match.start():end + len(MTP_END)].encode("utf-8")


def _map_sections(text: str) -> dict[str, str]:
    """MAP section bodies keyed by the stable ``section=`` id, never by heading text."""
    sections: dict[str, str] = {}
    for match in MTP_MAP_BEGIN_RE.finditer(text):
        name = match.group(1)
        end = text.find(_map_end_marker(name), match.end())
        if end == -1:
            raise SetupError(f"managed map section incomplete: {name}")
        sections[name] = text[match.end():end]
    return sections


def _map_block_remainder(block: str) -> str:
    """Text inside the managed block that no MAP section covers (custom user content)."""
    begin = MTP_BEGIN_RE.search(block)
    end = block.rfind(MTP_END)
    inner = block[begin.end() if begin else 0:end if end != -1 else len(block)]
    pieces: list[str] = []
    cursor = 0
    for match in MTP_MAP_BEGIN_RE.finditer(inner):
        marker = _map_end_marker(match.group(1))
        stop = inner.find(marker, match.end())
        if stop == -1:
            break
        pieces.append(inner[cursor:match.start()])
        cursor = stop + len(marker)
    pieces.append(inner[cursor:])
    return "".join(pieces)


def _merge_map(existing: str, template: str) -> tuple[str, dict[str, Any]]:
    """Merge the template managed block into an existing document, preserving map facts.

    Every template section keeps the *existing* body byte-for-byte when that
    ``section=`` id exists; sections the template dropped move to a PRESERVED list at
    the block tail, as does any content inside the old block that no section covered.
    Nothing the project wrote is silently discarded (AC-MAPPRESERVE-1/-3).
    """
    begin = MTP_BEGIN_RE.search(existing)
    if begin is None:
        return template, {"preserved": [], "added": sorted(_map_sections(template)),
                          "replaced": [], "removed": []}
    end = existing.rfind(MTP_END)
    old_block = existing[begin.start():end + len(MTP_END)] if end != -1 else existing[begin.start():]
    existing_sections = _map_sections(old_block)
    template_sections = _map_sections(template)
    out: list[str] = []
    cursor = 0
    preserved: list[str] = []
    added: list[str] = []
    replaced: list[str] = []
    for match in MTP_MAP_BEGIN_RE.finditer(template):
        name = match.group(1)
        stop = template.find(_map_end_marker(name), match.end())
        body = template[match.end():stop]
        out.append(template[cursor:match.end()])
        if name in existing_sections:
            old = existing_sections[name]
            out.append(old)
            (preserved if old == body else replaced).append(name)
        else:
            out.append(body)
            added.append(name)
        cursor = stop
    out.append(template[cursor:])
    block = "".join(out)

    kept: dict[str, str] = {
        name: body for name, body in existing_sections.items() if name not in template_sections
    }
    remainder = _map_block_remainder(old_block).strip("\n")
    custom_lines = [
        line for line in remainder.splitlines()
        if line.strip() and not re.match(r"^#{1,6} ", line)
    ]
    if custom_lines:
        name = MTP_MAP_LEGACY_SECTION if not existing_sections else MTP_MAP_REMAINDER_SECTION
        kept[name] = "\n" + "\n".join(custom_lines) + "\n"
    if kept:
        tail = [MTP_MAP_PRESERVED_BEGIN]
        for name in sorted(kept):
            tail.extend([
                f"<!-- MTP:MAP:BEGIN section={name} -->",
                kept[name].strip("\n"),
                _map_end_marker(name),
            ])
        tail.append(MTP_MAP_PRESERVED_END)
        position = block.rfind(MTP_END)
        block = block[:position] + "\n".join(tail) + "\n" + block[position:]
    changes = {
        "preserved": sorted(preserved),
        "added": sorted(added),
        "replaced": sorted(replaced),
        "removed": sorted(kept),
    }
    return existing[:begin.start()] + block + (existing[end + len(MTP_END):] if end != -1 else ""), changes


def _update_root(existing: bytes, template: bytes) -> bytes:
    try:
        text = existing.decode("utf-8")
    except UnicodeDecodeError as error:
        raise SetupError("managed root is not UTF-8") from error
    block = _managed_block(template).decode("utf-8")
    match = MTP_BEGIN_RE.search(text)
    if match is None:
        separator = b"" if not existing else (b"\n" if existing.endswith(b"\n") else b"\n\n")
        return existing + separator + block.encode("utf-8") + b"\n"
    if MTP_MAP_BEGIN_RE.search(block) is None:
        # No map sections in the template (e.g. AGENTS.md): keep whole-block replacement.
        end = text.find(MTP_END, match.start())
        return (text[:match.start()] + block + text[end + len(MTP_END):]).encode("utf-8")
    merged, _changes = _merge_map(text, block)
    return merged.encode("utf-8")


def _map_changes(target: Path) -> dict[str, Any] | None:
    """Preview disclosure: how the upgrade will change the project's map (AC-MAPPRESERVE-2)."""
    path = target / "CLAUDE.md"
    if not path.exists():
        return None
    existing = path.read_bytes()
    try:
        text = existing.decode("utf-8")
    except UnicodeDecodeError:
        return None
    if MTP_BEGIN_RE.search(text) is None:
        return None
    merged, changes = _merge_map(text, _managed_block(_template_file("CLAUDE.md")[0]).decode("utf-8"))
    changes["bytes_before"] = len(existing)
    changes["bytes_after"] = len(merged.encode("utf-8"))
    return changes


def _seed_managed_content(
    relative: str,
    existing: bytes,
    template: bytes,
    target_version: str,
) -> bytes:
    # The project's real state comes first; the template skeleton follows, explicitly
    # labelled so it can never pass for the current state (AC-MAPPRESERVE-4).
    header = f"<!-- MTP:PRESERVED version={target_version} path={relative} -->\n".encode("utf-8")
    skeleton = (
        f"<!-- {target_version} 模板骨架：由 Agent 按项目实际覆写 -->\n".encode("utf-8")
        + template.rstrip()
        + b"\n"
    )
    return header + existing + (b"" if existing.endswith(b"\n") else b"\n") + b"\n" + skeleton


def build_updates(
    target: Path,
    actions: list[dict[str, str]],
    absorption: dict[str, str] | None = None,
    target_version: str | None = None,
    project_id: str = "{{PROJECT_ID}}",
    source_revision: str = "{{SOURCE_REVISION}}",
) -> dict[Path, tuple[bytes, int]]:
    if target_version is None:
        target_version = load_contract()["version"]["mtp_version"]
    updates: dict[Path, tuple[bytes, int]] = {}
    for action in actions:
        relative = action["path"]
        operation = action["operation"]
        if operation == "delete":
            continue
        destination = target / relative
        template, template_mode = _template_file(relative, target, project_id, source_revision)
        if operation in {"create", "replace-managed"}:
            updates[destination] = (template, template_mode)
            continue
        existing = destination.read_bytes()
        mode = stat.S_IMODE(destination.stat().st_mode)
        if operation == "update-managed-block":
            content = _update_root(existing, template)
        elif operation == "seed-managed-preserve-content":
            content = _seed_managed_content(relative, existing, template, target_version)
        else:
            raise SetupError(f"unknown setup operation: {operation}")
        updates[destination] = (content, mode)
    if absorption is not None:
        for relative, key in (("ai/brief.md", "brief"), ("ai/backlog.md", "backlog")):
            destination = target / relative
            if destination in updates:
                content, mode = updates[destination]
            elif destination.exists():
                content = destination.read_bytes()
                mode = stat.S_IMODE(destination.stat().st_mode)
            else:
                content, mode = _template_file(relative, target, project_id, source_revision)
            addition = absorption[key].encode("utf-8")
            separator = b"" if not content else (b"\n" if content.endswith(b"\n") else b"\n\n")
            updates[destination] = (content + separator + addition, mode)
    return updates


def _preconditions(target: Path, contract: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for relative in (*_managed_relatives(contract), "MTP_THINK.md"):
        path = target / relative
        if not path.exists():
            result[relative] = {"kind": "missing"}
        else:
            data = path.read_bytes()
            result[relative] = {
                "kind": "file",
                "mode": stat.S_IMODE(path.stat().st_mode),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
    return result


def _verify_transaction_state(
    target: Path,
    contract: dict[str, Any],
    expected: dict[str, dict[str, Any]],
    updates: dict[Path, tuple[bytes, int]],
    mutated_paths: set[Path],
) -> None:
    actual = _preconditions(target, contract)
    for relative, precondition in expected.items():
        path = target / relative
        wanted = precondition
        if path in mutated_paths:
            if path in updates:
                content, mode = updates[path]
                wanted = {
                    "kind": "file",
                    "mode": mode,
                    "sha256": hashlib.sha256(content).hexdigest(),
                }
            else:
                wanted = {"kind": "missing"}
        if actual[relative] != wanted:
            raise SetupError("plan digest mismatch")


def _missing_directories(target: Path, updates: dict[Path, tuple[bytes, int]]) -> list[Path]:
    missing: set[Path] = set()
    for path in updates:
        parent = path.parent
        while not parent.exists():
            missing.add(parent)
            parent = parent.parent
    return sorted(missing, key=lambda path: (len(path.parts), path.as_posix()))


def _minted_project_id(target: Path) -> str:
    """Deterministic id for a project that has no prior identity.

    Derived from the absolute target path so the *preview* can name the exact id an
    apply would mint (a random id could not be disclosed ahead of execution).
    """
    seed = str(target.absolute()).encode("utf-8")
    return "prj-" + hashlib.sha256(seed).hexdigest()[:32]


def _registry_project_records(target: Path, registry_state: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Project records in the Registry whose ``project_root`` is this target (read-only)."""
    if registry_state is None:
        return []
    path = registry_state.get("path")
    if path is None or not registry_state.get("exists"):
        return []
    directory = Path(path) / "projects"
    if not directory.is_dir():
        return []
    wanted = str(target.absolute())
    records: list[dict[str, Any]] = []
    for item in sorted(directory.glob("*.json")):
        try:
            value = json.loads(item.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise SetupError(f"invalid registry record: {item.name}") from error
        if not isinstance(value, dict) or not isinstance(value.get("project_root"), str):
            continue
        if str(Path(value["project_root"]).expanduser()) == wanted:
            records.append(value)
    return records


def _project_identity(
    target: Path,
    manifest: dict[str, Any] | None,
    registry_records: list[dict[str, Any]],
) -> dict[str, Any]:
    """Resolve the project id an apply must use (L-018: an upgrade never re-forges it).

    Precedence: the existing manifest id, then the Registry record whose
    ``project_root`` is this target, then a deterministic freshly minted id. A
    manifest/Registry disagreement or several Registry identities for one root is a
    conflict: apply fails closed with zero writes (AC-IDENTITY-3).
    """
    manifest_id: str | None = None
    if manifest is not None and "project_id" in manifest:
        value = manifest.get("project_id")
        if not isinstance(value, str) or not PROJECT_ID_RE.fullmatch(value):
            raise SetupError("invalid project_id")
        manifest_id = value
    record_ids = sorted({
        record["id"] for record in registry_records
        if isinstance(record.get("id"), str)
    })
    if manifest_id is not None:
        conflict = {"manifest": manifest_id, "registry": record_ids} if record_ids and record_ids != [manifest_id] else None
        source, project_id = "manifest", manifest_id
    elif len(record_ids) == 1:
        conflict = None
        source, project_id = "registry", record_ids[0]
    elif record_ids:
        conflict = {"manifest": None, "registry": record_ids}
        source, project_id = "registry", None
    else:
        conflict = None
        source, project_id = "minted", _minted_project_id(target)
    return {
        "source": source,
        "project_id": project_id,
        "manifest_project_id": manifest_id,
        "registry_project_ids": record_ids,
        "requires_confirmation": source == "minted",
        "conflict": conflict,
    }


def _side_effects(
    decision: str,
    registry_state: dict[str, Any] | None,
    locator_values: tuple[str, ...],
    git_state: dict[str, Any],
    record_ready: bool = True,
) -> list[dict[str, Any]]:
    """The complete, identifier-free list of writes the apply transaction will perform.

    Preview and apply build this same list; apply fails closed if its freshly recomputed
    list differs from the plan's (AC-PREVIEW-3). The new record's id is deliberately not
    part of an entry: it is minted during apply, so embedding it would make the preview
    unable to state the truth before execution.
    """
    if decision not in {"create", "adopt", "upgrade"}:
        return []
    effects: list[dict[str, Any]] = []
    if git_state["state"] == "absent":
        effects.append({
            "action": "skip-git-evidence",
            "reason": git_state["reason"],
            "sentinel": SENTINEL_SOURCE_REVISION,
            "fields": ["CLAUDE.md#Accepted source revision", "registry.source_revision"],
        })
    if registry_state is None:
        return effects
    path = registry_state.get("path")
    if path is None:
        # Git unavailable or locator unresolved: the Registry write cannot happen.
        # Declare it instead of finishing with a silently missing record (AC-PREVIEW-8).
        effects.append({
            "action": "skip-registry",
            "reason": registry_state.get("capability") or "registry-unavailable",
        })
        return effects
    if not registry_state.get("exists"):
        effects.append({"action": "create-registry", "path": path})
    if tuple(locator_values) != (path,):
        effects.append({"action": "set-registry-locator", "path": path})
    if not record_ready:
        # Bootstrap still runs; only the project record is deferred until the
        # Passport is filled and an explicit refresh (or Sync Gate) runs.
        effects.append({
            "action": "skip-registry-record",
            "reason": "passport-summary-not-ready",
        })
        return effects
    effects.append({
        "action": "write-registry-record",
        "registry": path,
        "kind": "project",
        "directory": "projects",
    })
    effects.append({
        "action": "commit-registry",
        "registry": path,
        "identity": REGISTRY_COMMIT_IDENTITY,
    })
    return effects


def _canonical_effects(effects: list[dict[str, Any]]) -> list[str]:
    """Order-insensitive canonical form of a side-effect list, for equality checks."""
    return sorted(json.dumps(effect, sort_keys=True, separators=(",", ":")) for effect in effects)


def inspect(target: Path, registry_path: str | None = None) -> dict[str, Any]:
    contract = load_contract()
    decision = classify(target, contract)
    actions = planned_actions(target, decision, contract)
    absorption = _think_absorption(target) if decision in {"create", "adopt"} else None
    updates = build_updates(target, actions, absorption, contract["version"]["mtp_version"])
    deletions = [target / action["path"] for action in actions if action["operation"] == "delete"]
    missing_directories = _missing_directories(target, updates)
    registry_state, _registry_module, _locator_values, registry_mutations, registry_directories = _registry_inspect(
        decision, registry_path, contract
    )
    missing_directories = [
        directory for directory in missing_directories if directory not in registry_directories
    ]
    project_kind = _project_kind(target)
    git_state = _git_state(target)
    git_precondition = _git_precondition(target, git_state, project_kind)
    registry_content = (
        _registry_content(target, " ".join(target.name.replace("\n", " ").split()) or "project")
        if decision in {"create", "adopt", "upgrade"} else None
    )
    side_effects = _side_effects(
        decision, registry_state, tuple(_locator_values), git_state,
        record_ready=registry_content is not None,
    )
    if registry_content is None:
        # Bootstrap (create-registry / set-registry-locator) still runs; only the
        # prepare and finalize writes are skipped until the Passport is filled.
        registry_mutations = max(0, registry_mutations - 2)
    project_identity = _project_identity(
        target,
        _manifest(target / "ai/mtp.json"),
        _registry_project_records(target, registry_state),
    )
    identity = {
        "actions": actions,
        "contract_sha256": hashlib.sha256(CONTRACT_PATH.read_bytes()).hexdigest(),
        "decision": decision,
        "git_state": git_state,
        "git_precondition": git_precondition,
        "project_kind": project_kind,
        "registry_content_sha256": (
            None if registry_content is None
            else hashlib.sha256(json.dumps(registry_content, sort_keys=True).encode()).hexdigest()
        ),
        "identity": project_identity,
        "preconditions": _preconditions(target, contract),
        "template_state": {
            relative: {
                "mode": stat.S_IMODE((TEMPLATE_ROOT / relative).stat().st_mode),
                "sha256": hashlib.sha256((TEMPLATE_ROOT / relative).read_bytes()).hexdigest(),
            }
            for relative in contract["template_files"]
        },
        "target": str(target.absolute()),
        "target_version": contract["version"]["mtp_version"],
        "think_absorption": None if absorption is None else {"sha256": absorption["sha256"]},
        "registry": registry_state,
    }
    digest = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    source_digest = hashlib.sha256(json.dumps({
        "contract_sha256": identity["contract_sha256"],
        "template_state": identity["template_state"],
    }, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    map_status = _map_status(target) if decision in {"create", "adopt", "upgrade", "current"} else None
    return {
        "actions": actions,
        "ai_extra_files": _ai_root_extra(target),
        "apply_allowed": decision in {"create", "adopt", "upgrade"}
        and project_identity["conflict"] is None
        and git_precondition != "hard-stop-code-project-without-git",
        "decision": decision,
        "git_state": git_state,
        "git_precondition": git_precondition,
        "project_kind": project_kind,
        "identity": project_identity,
        "map_status": map_status,
        "setup_complete": decision == "current" and bool(map_status and map_status["ready"]),
        "map_changes": _map_changes(target) if decision in {"create", "adopt", "upgrade"} else None,
        "mutation_count": registry_mutations + len(missing_directories) + 2 * len(updates) + len(deletions),
        "plan_digest": digest,
        "preconditions": identity["preconditions"],
        "side_effects": side_effects,
        "source_digest": source_digest,
        "target_version": contract["version"]["mtp_version"],
        "think_absorption": identity["think_absorption"],
        "registry": registry_state,
        "write_allowed": False,
    }


def _temporary(path: Path, suffix: str) -> Path:
    return path.with_name(f".{path.name}.mtp-{suffix}")


def _restore(
    originals: dict[Path, tuple[bytes, int] | None],
    mutated_paths: set[Path],
    created_directories: list[Path],
    temporary_paths: set[Path],
    injector: FaultInjector,
) -> None:
    injector.before_rollback()
    errors: list[str] = []
    for temporary in temporary_paths:
        try:
            temporary.unlink(missing_ok=True)
        except OSError as error:
            errors.append(f"remove {temporary}: {error}")
    for path, original in reversed(list(originals.items())):
        if path not in mutated_paths:
            continue
        try:
            if original is None:
                path.unlink(missing_ok=True)
                continue
            content, mode = original
            temporary = _temporary(path, "restore")
            if temporary.exists() or temporary.is_symlink():
                raise OSError(f"restore path already exists: {temporary}")
            temporary_paths.add(temporary)
            temporary.write_bytes(content)
            temporary.chmod(mode)
            os.replace(temporary, path)
            temporary_paths.discard(temporary)
        except OSError as error:
            errors.append(f"restore {path}: {error}")
    for directory in reversed(created_directories):
        try:
            if directory.exists():
                directory.rmdir()
        except OSError as error:
            errors.append(f"remove directory {directory}: {error}")
    if errors:
        raise OSError("; ".join(errors))


def refresh_registry(target: Path, registry_path: str | None = None) -> dict[str, Any]:
    """B: explicit refresh trigger — write the Passport-derived record for a current project."""
    contract = load_contract()
    current = inspect(target, registry_path)
    if current["decision"] != "current":
        raise SetupError("registry refresh requires a current project")
    state, module, locator_values, _, _ = _registry_inspect("create", registry_path, contract)
    if state is None or state.get("path") is None:
        raise SetupError("registry unavailable")
    identity = current["identity"]
    project_id = identity.get("project_id")
    if not isinstance(project_id, str):
        raise SetupError("project identity unresolved")
    record = _registry_record(
        target, project_id, _source_revision(target), _git_state(target)["state"],
    )
    if record is None:
        raise SetupError("registry-summary-not-ready: fill the CLAUDE.md Passport first")
    # AC-B-5: refreshing an unchanged Passport must produce zero-diff, so compare the
    # canonical bytes already on main before opening a transaction.
    registry_root = Path(state["path"])
    main = module._git(
        registry_root, "rev-parse", module.CANONICAL_BRANCH, check=False,
    ).stdout.strip()
    if main:
        existing = module._show_bytes(registry_root, main, f"projects/{record['id']}.json")
        if existing == module.canonical_record(record):
            return {
                "ok": True,
                "record": record["id"],
                "registry": state["path"],
                "changes": 0,
            }
    tx = RegistryTransaction(
        path=Path(state["path"]),
        module=module,
        locator_values=tuple(locator_values),
        existed=bool(state.get("exists")),
    )
    injector = FaultInjector()
    try:
        _prepare_registry(tx, record, injector)
        _finalize_registry(tx, injector)
    except Exception as error:
        # AC-B-4: the refresh entry must leave no detached HEAD, temporary worktree or
        # owned branch behind when preparation or the CAS advancement fails.
        rollback_errors: list[str] = []
        try:
            _rollback_registry(tx)
        except Exception as rollback_error:
            rollback_errors.append(str(rollback_error))
        if rollback_errors:
            raise TransactionError(
                f"{error}; registry rollback failed: {'; '.join(rollback_errors)}"
            ) from error
        raise
    return {"ok": True, "record": record["id"], "registry": state["path"]}


def apply_transaction(
    target: Path,
    plan: dict[str, Any],
    injector: FaultInjector,
    registry_path: str | None = None,
    effect_sink: list[dict[str, Any]] | None = None,
    confirm_minted_identity: bool = False,
) -> tuple[int, bool]:
    contract = load_contract()
    current = inspect(target, registry_path)
    _reject_symlinks(target, contract)
    if current.get("git_precondition") == "hard-stop-code-project-without-git":
        raise SetupError("code project requires git init before apply")
    if (
        current["plan_digest"] != plan["plan_digest"]
        or _preconditions(target, contract) != plan["preconditions"]
    ):
        raise SetupError("plan digest mismatch")
    if plan.get("side_effects") != current["side_effects"]:
        raise SetupError("side effects plan mismatch")
    absorption = _think_absorption(target) if plan["decision"] in {"create", "adopt"} else None
    project_identity = current["identity"]
    if project_identity["conflict"] is not None:
        raise SetupError("project identity conflict")
    if project_identity["requires_confirmation"] and not confirm_minted_identity:
        raise SetupError("minted project identity requires explicit confirmation")
    project_id = project_identity["project_id"]
    if not isinstance(project_id, str):
        raise SetupError("project identity unresolved")
    revision = _source_revision(target)
    git_state = _git_state(target)["state"]
    updates = build_updates(
        target,
        plan["actions"],
        absorption,
        contract["version"]["mtp_version"],
        project_id,
        revision,
    )
    deletions = [
        target / action["path"]
        for action in plan["actions"]
        if action["operation"] == "delete"
    ]
    directories = _missing_directories(target, updates)
    originals = {
        path: None if not path.exists() else (path.read_bytes(), stat.S_IMODE(path.stat().st_mode))
        for path in (*updates, *deletions)
    }
    created_directories: list[Path] = []
    mutated_paths: set[Path] = set()
    temporary_paths: set[Path] = set()
    registry_state = None
    registry_tx: RegistryTransaction | None = None
    registry_state, module, locator_values, _registry_mutations, _registry_directories = _registry_inspect(
        plan["decision"], registry_path, contract
    )
    if registry_state != plan.get("registry"):
        raise SetupError("registry plan digest mismatch")
    registry_tx = None
    if registry_state is not None and registry_state.get("path") is not None:
        registry_tx = RegistryTransaction(
            path=Path(registry_state["path"]),
            module=module,
            locator_values=tuple(locator_values),
            existed=bool(registry_state["exists"]),
        )
    for path in (*updates, *deletions):
        restore = _temporary(path, "restore")
        temporary = _temporary(path, "tmp") if path in updates else None
        if (
            (temporary is not None and (temporary.exists() or temporary.is_symlink()))
            or restore.exists()
            or restore.is_symlink()
        ):
            raise SetupError(f"temporary setup path already exists: {path.name}")
    try:
        registry_record = False
        if registry_tx is not None:
            record = _registry_record(target, project_id, revision, git_state)
            if record is None:
                _bootstrap_registry(registry_tx, injector)
            else:
                _prepare_registry(registry_tx, record, injector)
                registry_record = True
            directories = [directory for directory in directories if not directory.exists()]
        for directory in directories:
            _reject_symlinks(target, contract)
            _verify_transaction_state(target, contract, plan["preconditions"], updates, mutated_paths)
            directory.mkdir()
            created_directories.append(directory)
            injector.mutation()
        for path, (content, mode) in updates.items():
            temporary = _temporary(path, "tmp")
            _reject_symlinks(target, contract)
            _verify_transaction_state(target, contract, plan["preconditions"], updates, mutated_paths)
            temporary_paths.add(temporary)
            temporary.write_bytes(content)
            temporary.chmod(mode)
            injector.mutation()
            _reject_symlinks(target, contract)
            _verify_transaction_state(target, contract, plan["preconditions"], updates, mutated_paths)
            os.replace(temporary, path)
            temporary_paths.discard(temporary)
            mutated_paths.add(path)
            injector.mutation()
        for path in deletions:
            _reject_symlinks(target, contract)
            _verify_transaction_state(target, contract, plan["preconditions"], updates, mutated_paths)
            path.unlink()
            mutated_paths.add(path)
            injector.mutation()
        _reject_symlinks(target, contract)
        _verify_transaction_state(target, contract, plan["preconditions"], updates, mutated_paths)
        if classify(target, contract) != "current":
            raise SetupError("setup did not produce a current project")
        if registry_tx is not None:
            if registry_record:
                _finalize_registry(registry_tx, injector)
        # The preview promised an exact side-effect set; the transaction must have
        # performed exactly that set or it does not get to report success (AC-PREVIEW-3).
        executed = [
            effect for effect in current["side_effects"] if effect["action"].startswith("skip-")
        ]
        if registry_tx is not None:
            executed.extend(registry_tx.effects)
        if _canonical_effects(executed) != _canonical_effects(current["side_effects"]):
            raise SetupError("side effects mismatch")
        if effect_sink is not None:
            effect_sink.extend(executed)
    except Exception as error:
        retried = False
        rollback_errors: list[str] = []
        try:
            _restore(originals, mutated_paths, created_directories, temporary_paths, injector)
        except Exception:
            retried = True
            try:
                _restore(originals, mutated_paths, created_directories, temporary_paths, injector)
            except Exception as rollback_error:
                try:
                    _restore(originals, mutated_paths, created_directories, temporary_paths, injector)
                except Exception as emergency_error:
                    rollback_errors.append(
                        f"project rollback failed after retry: {rollback_error}; "
                        f"emergency restore failed: {emergency_error}"
                    )
                else:
                    rollback_errors.append(
                        f"project rollback failed after retry: {rollback_error}; "
                        "emergency restore completed"
                    )
        if registry_tx is not None:
            try:
                _rollback_registry(registry_tx)
            except Exception as registry_error:
                rollback_errors.append(f"registry rollback failed: {registry_error}")
        if rollback_errors:
            raise TransactionError(f"{error}; {'; '.join(rollback_errors)}") from error
        message = f"setup failed: {error}"
        if retried:
            message += "; rollback retried"
        raise TransactionError(message) from error
    return injector.mutations, bool(updates)


def main() -> int:
    parser = argparse.ArgumentParser(description="Plan or apply MTP Template 1 setup")
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--expect-plan-digest")
    parser.add_argument("--inject-failure-after", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--inject-rollback-failures", type=int, default=0, help=argparse.SUPPRESS)
    parser.add_argument("--registry-path", help=argparse.SUPPRESS)
    parser.add_argument(
        "--confirm-minted-identity",
        action="store_true",
        help="apply a plan whose preview discloses a freshly minted project id",
    )
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--refresh-registry", action="store_true")
    args = parser.parse_args()
    target = args.target.expanduser()
    if args.refresh_registry:
        try:
            payload = refresh_registry(target, args.registry_path)
        except (OSError, SetupError, UnicodeDecodeError, json.JSONDecodeError) as error:
            print(f"invalid-project: {error}", file=sys.stderr)
            return 2
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        elif payload.get("changes") == 0:
            print(f"registry unchanged: {payload['record']}")
        else:
            print(f"registry refreshed: {payload['record']}")
        return 0
    try:
        result = inspect(target, args.registry_path)
        if args.apply:
            if not args.expect_plan_digest:
                raise SetupError("apply requires --expect-plan-digest")
            if args.expect_plan_digest != result["plan_digest"]:
                raise SetupError("plan digest mismatch")
            if result["decision"] == "unsupported-project-version":
                raise SetupError("unsupported project version is write-protected")
            if result["decision"] == "current":
                result["applied"] = False
            elif not result["apply_allowed"]:
                raise SetupError("setup decision is not writable")
            else:
                if args.inject_failure_after is not None and not 1 <= args.inject_failure_after <= result["mutation_count"]:
                    raise SetupError("failure injection is outside the mutation range")
                if args.inject_rollback_failures < 0:
                    raise SetupError("rollback failure injection cannot be negative")
                if args.inject_rollback_failures and args.inject_failure_after is None:
                    raise SetupError("rollback failure injection requires a forward failure")
                injector = FaultInjector(args.inject_failure_after, args.inject_rollback_failures)
                mutations, applied = apply_transaction(
                    target,
                    result,
                    injector,
                    args.registry_path,
                    confirm_minted_identity=args.confirm_minted_identity,
                )
                result["applied"] = applied
                result["mutations"] = mutations
                result["write_allowed"] = True
        elif args.inject_failure_after is not None or args.inject_rollback_failures:
            raise SetupError("failure injection requires --apply")
    except TransactionError as error:
        print(f"setup-failed: {error}", file=sys.stderr)
        return 2
    except (OSError, SetupError, UnicodeDecodeError, json.JSONDecodeError) as error:
        print(f"invalid-project: {error}", file=sys.stderr)
        return 2
    extra = result.get("ai_extra_files") or []
    if extra:
        print(
            f"warning: ai/ has files outside the fixed set: {', '.join(extra)}",
            file=sys.stderr,
        )
    if args.json:
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    else:
        applied = result.get("applied", False)
        print(f"{result['decision']}: {len(result['actions'])} actions; applied={str(applied).lower()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
