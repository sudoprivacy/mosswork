---
name: skillhub-skill-summarize
description: "smart summarization capability in the office and document processing domain. Use when the user wants to 支持对网页、PDF、Word、TXT、播客、YouTube 视频等进行智能摘要提取. Triggers: summarize, nano-pdf、docx. Not for requests unrelated to smart summarization. Risk level L0. 中文触发：summarize、nano-pdf、docx。"
---

# 智能摘要（summarize）

## 用途

支持对网页、PDF、Word、TXT、播客、YouTube 视频等进行智能摘要提取。

> 分类：二、办公与文档处理类（office and document processing）  
> 技能类型：智能摘要  
> 风险等级：低  
> 门禁档位：**L0** — 只读 / 无副作用，可直接执行；仍遵守“先确认再改生产”的通用原则。

## 触发条件

- 用户提到 `summarize`、需要智能摘要能力，或提出对应诉求时触发。
- 典型触发词：summarize、支持对网页、PDF、Word、TXT、播客、YouTube 视频等进行智能摘要提取。
- 关联技能：nano-pdf、docx。

## 何时不要使用

- 与智能摘要无关的请求：不要触发，交给更合适的技能或直接回答。
- 前置依赖未就绪（未授权 / 缺 CLI / 缺网络）时：**停下并报告**，不要降级为让用户粘贴明文凭据。
- 超出本技能声明范围的目标（其他系统、其他账号）：不越权操作。

## 功能清单

- 网页、PDF、Word、TXT 文本摘要
- 播客与 YouTube 视频内容摘要
- 提炼要点、生成概要

## 标准操作流程

1. 确认输入来源与输出目标（文件路径、笔记库、邮箱、云端），不擅自上传或外发内容。
2. 按用户指定的格式/模板生成或编辑，保持样式一致、结构清晰。
3. 涉及外部账号（笔记/邮箱/办公套件）时，仅使用已授权的连接，敏感字段走密钥引用而非明文。
4. 批量处理前先用单条样本验证效果，再放量。
5. 交付后说明产物位置与后续可操作的入口。

## 外部依赖与前置检查

- 依赖：视来源可能需要网络。开箱即用，无需额外配置。

## 典型使用场景

1. 快速消化长文档与长视频
2. 信息聚合与要点提取

## 使用提示

官方推荐办公场景的高频技能之一。

## 备注

- 关联技能：nano-pdf、docx。
- 本技能由规划规格 README 自动落地生成，操作细节（具体 API/CLI/连接）应在接入真实运行时补全。
- 通用铁律：先验证现状 → 列影响面 → 取得确认 → 再执行；不可逆或涉钱/涉密的动作用最高门禁。
