import argparse
import calendar
import datetime
import html
import json
import os
import re
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request


DEFAULT_HOST = "gate.gov-bid.com"
SEARCH_PATH = "/outer-gateway/bid/SearchProjectForAI"
DETAIL_PATH = "/outer-gateway/bid/getZTBProjectDetailForAI"
CLASS_NAMES = {"全部信息", "招标信息", "中标信息", "合同信息", "采购意向", "拍租信息"}
MAX_RESPONSE_BYTES = 5 * 1024 * 1024
CHINA_TIME = datetime.timezone(datetime.timedelta(hours=8))


class QueryError(Exception):
    def __init__(self, category, message):
        super().__init__(message)
        self.category = category


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        raise QueryError("redirect_blocked", "已阻止服务重定向，避免向其他地址发送凭据。")


class SafeParser(argparse.ArgumentParser):
    def error(self, message):
        raise QueryError("arguments", "命令参数无效，请查看--help；不要把密钥放入命令行。")


def read_setting(name):
    value = os.environ.get(name, "").strip()
    if value or os.name != "nt":
        return value
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as registry:
            value = winreg.QueryValueEx(registry, name)[0]
            return value.strip() if isinstance(value, str) else ""
    except OSError:
        return ""


def scrub(value, secret=""):
    if isinstance(value, dict):
        return {key: scrub(item, secret) for key, item in value.items()}
    if isinstance(value, list):
        return [scrub(item, secret) for item in value]
    if isinstance(value, str):
        if secret:
            value = value.replace(secret, "[REDACTED]")
            value = value.replace(urllib.parse.quote(secret, safe=""), "[REDACTED]")
        return re.sub(r"(?i)([?&](?:key|api_key|token)=)[^&\s\"<>]+", r"\1[REDACTED]", value)
    return value


def server_origin(value, allowed_host=None):
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise QueryError("configuration", "服务地址必须是无内嵌凭据的HTTPS地址。")
    if parsed.query or parsed.fragment or parsed.path.rstrip("/") not in ("", "/outer-gateway"):
        raise QueryError("configuration", "服务地址只能包含域名及可选的/outer-gateway前缀。")
    if parsed.port not in (None, 443):
        raise QueryError("configuration", "服务地址仅支持HTTPS默认端口。")
    if parsed.hostname != DEFAULT_HOST and parsed.hostname != allowed_host:
        raise QueryError("configuration", "自定义服务域名需经用户确认并显式指定--allow-server-host。")
    return "https://" + parsed.netloc


def parse_boundary(value, end=False):
    try:
        if len(value) == 10:
            day = datetime.date.fromisoformat(value)
            moment = datetime.datetime.combine(day, datetime.time(23, 59, 59) if end else datetime.time())
        else:
            moment = datetime.datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
        return moment.strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        raise QueryError("arguments", "日期须为YYYY-MM-DD或YYYY-MM-DD HH:MM:SS。") from None


def date_window(mode, start=None, end=None, today=None):
    if bool(start) != bool(end):
        raise QueryError("arguments", "自定日期时须同时提供起止日期。")
    if start:
        lower, upper = parse_boundary(start), parse_boundary(end, end=True)
    else:
        today = today or datetime.datetime.now(CHINA_TIME).date()
        if mode == "analysis":
            month_index = today.year * 12 + today.month - 1 - 6
            year, month_index = divmod(month_index, 12)
            month = month_index + 1
            first = datetime.date(year, month, min(today.day, calendar.monthrange(year, month)[1]))
        else:
            first = today - datetime.timedelta(days=29)
        lower, upper = parse_boundary(first.isoformat()), parse_boundary(today.isoformat(), end=True)
    if lower > upper:
        raise QueryError("arguments", "开始日期不能晚于结束日期。")
    return lower, upper


def previous_record_keys(value):
    if not value:
        return []
    if len(value) > 8192:
        raise QueryError("arguments", "上一页记录标识超出本地输入限制。")
    try:
        records = json.loads(value)
    except ValueError:
        raise QueryError("arguments", "上一页记录须为仅含id和publishTime的JSON数组。") from None
    if not isinstance(records, list) or len(records) > 20:
        raise QueryError("arguments", "上一页记录须为最多20条标识的数组。")
    keys = []
    for record in records:
        if (not isinstance(record, dict) or set(record) != {"id", "publishTime"}
                or not is_integer(record["id"]) or record["id"] < 1
                or not isinstance(record["publishTime"], str)):
            raise QueryError("arguments", "上一页记录只能包含有效id和publishTime。")
        parse_boundary(record["publishTime"])
        keys.append((record["id"], record["publishTime"]))
    return keys


def build_plan(args, today=None):
    if not 1 <= args.page_size <= 20 or args.page < 1:
        raise QueryError("arguments", "页码须为正整数，Agent接口每页条数须为1至20。")
    if not 1 <= args.timeout <= 120:
        raise QueryError("arguments", "单次网络超时须在1至120秒之间。")
    if args.mode == "detail":
        if args.id is None or args.id < 1 or not args.publish_time:
            raise QueryError("arguments", "详情查询须提供实际结果的--id和--publish-time。")
        if args.all or args.start_date or args.end_date or args.max_pages or args.previous_records_json:
            raise QueryError("arguments", "详情查询不能使用列表日期或全量翻页参数。")
        payload = {"id": args.id, "publishTime": parse_boundary(args.publish_time)}
        return {"path": DETAIL_PATH, "payload": payload, "mode": "detail", "max_pages": 1}
    previous_keys = previous_record_keys(args.previous_records_json)
    if args.page > 1 and not (args.start_date and args.end_date):
        raise QueryError("arguments", "续页须沿用上一页的明确起止日期，避免跨日改变查询范围。")
    if args.previous_records_json and args.page < 2:
        raise QueryError("arguments", "上一页记录仅用于第2页及后续续页。")
    selected = [name.strip() for name in args.classes.split(",")]
    if not selected or any(name not in CLASS_NAMES for name in selected):
        raise QueryError("arguments", "公告分类必须使用随包文档列明的中文类别和英文逗号。")
    pages = args.max_pages if args.max_pages is not None else (5 if args.mode == "analysis" or args.all else 1)
    if not 1 <= pages <= 20:
        raise QueryError("arguments", "单批最多页数须为1至20，默认分析或全量批次为5页。")
    if args.mode == "query" and pages > 1 and not args.all:
        raise QueryError("arguments", "查询默认仅一页，明确需要全量时才使用--all。")
    lower, upper = date_window(args.mode, args.start_date, args.end_date, today)
    payload = {"startDate": lower, "endDate": upper, "pageId": args.page,
               "pageNumber": args.page_size, "className": ",".join(selected), "OrderByType": "发布时间"}
    for field, value in [("areaName", args.area), ("keyword", args.keyword), ("excludeKW", args.exclude),
                         ("inCludeKW", args.include), ("companyName", args.company)]:
        if value:
            payload[field] = value
    return {"path": SEARCH_PATH, "payload": payload, "mode": args.mode, "max_pages": pages,
            "previous_keys": previous_keys}


class Client:
    def __init__(self, origin, secret, timeout=20, max_requests=5, opener=None):
        self.origin = origin
        self.secret = secret
        self.timeout = timeout
        self.max_requests = max_requests
        self.requests_attempted = 0
        self.opener = opener or urllib.request.build_opener(NoRedirect())

    def call(self, path, payload):
        for attempt in range(2):
            if self.requests_attempted >= self.max_requests:
                raise QueryError("request_budget", "已达到本批请求上限，未完成部分需确认后继续。")
            request = urllib.request.Request(
                self.origin + path + "?" + urllib.parse.urlencode({"key": self.secret}),
                data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                headers={"Content-Type": "application/json", "Accept": "application/json"}, method="POST")
            self.requests_attempted += 1
            try:
                with self.opener.open(request, timeout=self.timeout) as response:
                    if response.status != 200:
                        raise QueryError("http_error", "数据服务返回非成功HTTP状态。")
                    content = response.read(MAX_RESPONSE_BYTES + 1)
                if len(content) > MAX_RESPONSE_BYTES:
                    raise QueryError("response_limit", "响应超过本地安全读取上限，未作为空结果处理。")
                try:
                    result = json.loads(content.decode("utf-8-sig"))
                except (UnicodeError, ValueError):
                    raise QueryError("invalid_response", "服务返回内容不是有效JSON，请由维护方检查。") from None
                if not isinstance(result, dict):
                    raise QueryError("invalid_response", "服务响应结构异常，请由维护方检查。")
                if result.get("code") != 200 or str(result.get("subCode")) != "0000000000":
                    raise QueryError("business_error", "业务返回不符合文档成功示例，请维护方核查权限、额度或接口状态。")
                if not isinstance(result.get("data"), dict):
                    raise QueryError("invalid_response", "业务数据结构异常，不能当作零条结果。")
                return result["data"]
            except urllib.error.HTTPError as error:
                if error.code == 401:
                    category, message = "authentication", "接口鉴权失败，请检查安全配置中的凭据。"
                elif error.code == 403:
                    category, message = "permission", "接口拒绝访问，请确认账号权限；不自动重试。"
                elif error.code == 429:
                    category, message = "rate_or_quota", "服务限制本次请求，请确认限流或额度；不自动重试。"
                else:
                    category, message = "http_error", "数据服务返回HTTP错误，请维护方检查；未当作无商机。"
                if error.fp is not None:
                    error.close()
                raise QueryError(category, message) from None
            except (urllib.error.URLError, TimeoutError, socket.timeout, ConnectionError):
                if attempt == 0 and self.requests_attempted < self.max_requests:
                    time.sleep(0.5)
                    continue
                raise QueryError("network", "数据请求失败或超时，请稍后重试或联系维护方。") from None


def is_integer(value):
    return isinstance(value, int) and not isinstance(value, bool)


def validate_page(data, payload):
    records = data.get("data")
    if not isinstance(records, list) or not all(isinstance(record, dict) for record in records):
        raise QueryError("invalid_response", "列表data.data缺失或类型异常，不能作为空列表。")
    if data.get("pageId") != payload["pageId"] or not is_integer(data.get("pageId")):
        raise QueryError("pagination", "服务返回页码与请求不一致，已停止续页。")
    reported_size = data.get("pageNumber")
    if reported_size is not None and (not is_integer(reported_size) or reported_size < 0):
        raise QueryError("pagination", "服务返回页大小类型或取值异常，已停止处理；不能当作零条结果。")
    if not isinstance(data.get("hasNext"), bool):
        raise QueryError("pagination", "服务未返回有效的hasNext，无法确认覆盖范围。")
    if "total" in data and (not is_integer(data["total"]) or data["total"] < 0):
        raise QueryError("invalid_response", "总数格式异常，不将本页数量当作总数。")
    if len(records) > payload["pageNumber"] or (not records and data["hasNext"]):
        raise QueryError("pagination", "服务列表数量与分页状态冲突，已停止续页。")
    for record in records:
        if not is_integer(record.get("id")) or record["id"] < 1 or not isinstance(record.get("publishTime"), str):
            raise QueryError("invalid_response", "记录ID或发布时间缺失，无法可靠续查和关联。")
        try:
            parse_boundary(record["publishTime"])
        except QueryError:
            raise QueryError("invalid_response", "服务返回的发布时间格式异常，无法可靠关联。") from None
    return records


def run_search(client, plan):
    records, pages, warnings = [], [], []
    previous_keys = set(tuple(key) for key in plan.get("previous_keys", []))
    seen, last_page_keys, duplicates_removed = set(previous_keys), [], 0
    payload = dict(plan["payload"])
    has_next, last_total, stopped, failure = None, None, "page_budget", None
    for page_index in range(plan["max_pages"]):
        try:
            data = client.call(SEARCH_PATH, payload)
            current = validate_page(data, payload)
            identities = [(record["id"], record["publishTime"]) for record in current]
            if current and not any(identity not in seen for identity in identities):
                raise QueryError("pagination", "续页未产生新记录，已停止以避免重复请求。")
            for record, identity in zip(current, identities):
                if identity not in seen:
                    records.append(record)
                    seen.add(identity)
                else:
                    duplicates_removed += 1
            last_page_keys = list(dict.fromkeys(identities))
            pagination_verified = data.get("pageNumber") == payload["pageNumber"]
            pages.append({"page": payload["pageId"], "raw_count": len(current),
                          "requested_page_size": payload["pageNumber"],
                          "reported_page_size": data.get("pageNumber"),
                          "pagination_verified": pagination_verified})
            has_next, last_total = data["hasNext"], data.get("total")
            payload["pageId"] += 1
            if not pagination_verified:
                warnings.append({"category": "page_size_metadata",
                                 "message": "已保留有效本页；页大小回显未确认，仅暂停自动批量翻页。用户明确续页时可沿用原条件请求下一页并核验重复，不代表全量。",
                                 "page": pages[-1]["page"], "requested": payload["pageNumber"],
                                 "reported": data.get("pageNumber")})
                stopped = "pagination_metadata_unverified"
                break
            if not has_next:
                stopped = "service_end"
                break
        except QueryError as error:
            failure, stopped = error, error.category
            break
    continuation_verified = bool(pages) and all(page["pagination_verified"] for page in pages)
    manual_continuation_available = bool(pages) and has_next is True and failure is None
    if duplicates_removed:
        warnings.append({"category": "duplicate_records", "count": duplicates_removed,
                         "message": "已移除与已知记录重复的公告ID和发布时间组合；未为补足数量追加请求。"})
    if plan["payload"]["pageId"] > 1 and not previous_keys:
        warnings.append({"category": "previous_page_not_supplied",
                         "message": "组件未收到上一页记录标识，需结合会话已看记录检查跨页重复；不保证无遗漏或固定快照。"})
    complete = continuation_verified and plan["payload"]["pageId"] == 1 and has_next is False and failure is None
    result = {"status": "error" if failure and not pages else "partial" if failure else "ok",
              "mode": plan["mode"], "filters": plan["payload"], "pages": pages,
              "records": records, "raw_count": sum(page["raw_count"] for page in pages),
              "record_count": len(records), "server_total": last_total, "has_next": has_next,
              "next_page": payload["pageId"] if manual_continuation_available else None,
              "manual_continuation_available": manual_continuation_available,
              "duplicates_removed": duplicates_removed,
              "previous_page_checked": bool(previous_keys),
              "last_page_record_keys": [{"id": identity[0], "publishTime": identity[1]}
                                        for identity in last_page_keys],
              "continuation_verified": continuation_verified, "warnings": warnings,
              "acquisition_complete": complete, "market_coverage_complete": False,
              "coverage": "已从首页获取至服务端标记的末页，仍非全市场覆盖证明" if complete else "部分页面或样本，不是全量",
              "stop_reason": stopped, "requests_attempted": client.requests_attempted,
              "query_executed": client.requests_attempted > 0, "error": None}
    if failure:
        result["error"] = {"category": failure.category, "message": str(failure)}
    return result


def public_record(record, include_content=False):
    fields = ["id", "newsTypeName", "title", "publishTime", "areaName", "projectMoney", "projectClass",
              "purchaseType", "siginUpStopDate", "bidStartDate", "collectUrl", "sbkjBidUrl",
              "proviceName", "cityName", "countyName", "projectClassName", "partAName", "partBName", "agentName"]
    if include_content:
        fields.append("content")
    result = {field: record[field] for field in fields if field in record}
    if isinstance(result.get("title"), str):
        result["title"] = html.unescape(re.sub(r"<[^>]*>", "", result["title"]))
    for field in ["partAInfo", "partBInfo", "agencyInfo"]:
        parties = record.get(field)
        if isinstance(parties, list):
            result[field] = [{"name": party["name"]} for party in parties
                             if isinstance(party, dict) and isinstance(party.get("name"), str)]
    return result


def parser():
    command = SafeParser(description="招标中标首页查询与有界分析取数；不会自动获取密钥或安装依赖。", allow_abbrev=False)
    command.add_argument("mode", choices=["query", "analysis", "detail"])
    for name in ["area", "keyword", "exclude", "include", "company"]:
        command.add_argument("--" + name, default="视频监控|监控摄像机|监控系统" if name == "keyword" else "")
    command.add_argument("--classes", default="招标信息")
    command.add_argument("--start-date")
    command.add_argument("--end-date")
    command.add_argument("--page", type=int, default=1)
    command.add_argument("--page-size", type=int, default=10)
    command.add_argument("--previous-records-json", help="上一页id/publishTime数组，仅用于已明确要求的续页去重。")
    command.add_argument("--max-pages", type=int)
    command.add_argument("--max-requests", type=int)
    command.add_argument("--all", action="store_true")
    command.add_argument("--timeout", type=int, default=20)
    command.add_argument("--id", type=int)
    command.add_argument("--publish-time")
    command.add_argument("--allow-server-host")
    command.add_argument("--include-content", action="store_true")
    command.add_argument("--dry-run", action="store_true", help="只显示无密钥请求计划，不读密钥、不联网。")
    return command


def main(argv=None):
    client, secret = None, ""
    try:
        args = parser().parse_args(argv)
        plan = build_plan(args)
        origin = server_origin(read_setting("BBIAO_SERVER_URL") or "https://" + DEFAULT_HOST, args.allow_server_host)
        budget = args.max_requests if args.max_requests is not None else (5 if plan["max_pages"] > 1 else 2)
        if not 1 <= budget <= 20:
            raise QueryError("arguments", "单批请求上限须为1至20，包含网络重试。")
        if args.dry_run:
            output = {"status": "plan_only", "plan": plan, "server": origin,
                      "max_requests": budget, "requests_attempted": 0, "query_executed": False}
        else:
            secret = read_setting("BBIAO_API_KEY")
            if not secret:
                raise QueryError("missing_key", "未配置接口凭据，未发出业务查询请求；请按技能开通说明配置。")
            client = Client(origin, secret, args.timeout, budget)
            if args.mode == "detail":
                detail = client.call(DETAIL_PATH, plan["payload"])
                if detail.get("id") != args.id or not isinstance(detail.get("content"), str):
                    raise QueryError("invalid_response", "详情ID或正文结构异常，不能视为核验完成。")
                output = {"status": "ok", "mode": "detail", "record": public_record(detail, True),
                          "query_executed": True, "requests_attempted": client.requests_attempted}
            else:
                output = run_search(client, plan)
                output["records"] = [public_record(record, args.include_content) for record in output["records"]]
        print(json.dumps(scrub(output, secret), ensure_ascii=False, indent=2))
        return 1 if output["status"] in ("error", "partial") else 0
    except QueryError as error:
        output = {"status": "error", "error": {"category": error.category, "message": str(error)},
                  "requests_attempted": client.requests_attempted if client else 0,
                  "query_executed": bool(client and client.requests_attempted)}
    except (ValueError, OSError):
        output = {"status": "error", "error": {"category": "runtime", "message": "运行环境或数据处理异常，请维护方检查。"},
                  "requests_attempted": client.requests_attempted if client else 0,
                  "query_executed": bool(client and client.requests_attempted)}
    print(json.dumps(scrub(output, secret), ensure_ascii=False, indent=2))
    return 1


if __name__ == "__main__":
    sys.exit(main())
