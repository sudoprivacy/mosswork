---
name: skillhub-skill-mlg-m4a-to-mp3
description: "M4A 转 MP3 音频格式转换工具。将 M4A/AAC 音频文件批量转换为 MP3 格式，支持自定义比特率、采样率、递归目录扫描和输出目录设置。当用户需要将 M4A 文件转换为 MP3、批量转换音频格式、或处理音频格式不兼容问题时触发此 Skill。关键词：M4A转MP3、音频转换、格式转换、AAC转MP3、批量转换音频。"
---

# M4A to MP3 Converter

## Overview

Convert M4A audio files to widely-compatible MP3 format using ffmpeg as the backend engine. Supports single-file and batch directory conversion with configurable bitrate, sample rate, and output paths. The conversion script auto-resolves the ffmpeg binary — if system ffmpeg is not installed, it automatically falls back to the `imageio-ffmpeg` package which bundles a static ffmpeg binary.

## When to Use

Trigger this skill when the user:

- Asks to convert M4A files to MP3 format
- Has audio files in M4A/AAC format that need MP3 compatibility
- Wants to batch convert a folder of M4A recordings to MP3
- Needs to change audio bitrate or sample rate during conversion
- Mentions keywords: M4A转MP3, 音频转换, 格式转换, convert m4a to mp3, audio conversion

## Prerequisites

The script auto-resolves ffmpeg in this order:

1. **System ffmpeg** — if `ffmpeg` is available in PATH, use it directly.
2. **imageio-ffmpeg** — if system ffmpeg is missing, the script auto-installs the `imageio-ffmpeg` pip package, which bundles a static ffmpeg binary. No manual installation required.

No user action is needed — the script handles everything automatically.

## Conversion Script

The core conversion logic is in `scripts/m4a_to_mp3.py`. Execute it with Python:

```bash
python scripts/m4a_to_mp3.py <input> [options]
```

### Key Options

| Option | Flag | Default | Description |
|--------|------|---------|-------------|
| Input | (positional) | — | M4A file or directory path |
| Output | `-o` | Same name, .mp3 | Output file or directory |
| Bitrate | `-b` | 192 | MP3 bitrate in kbps (64/96/128/160/192/256/320) |
| Sample rate | `-s` | Original | Audio sample rate in Hz (22050/32000/44100/48000/96000) |
| Recursive | `-r` | Off | Recursively scan subdirectories |
| Overwrite | `-f` | Off | Overwrite existing files |
| Quiet | `-q` | Off | Suppress detailed output |
| Output dir | `-d` | — | Batch output directory (preserves structure) |

## Workflow

### Step 1: Identify Input

Determine what the user wants to convert:

- **Single file**: User provides a specific `.m4a` file path
- **Batch**: User provides a directory path containing `.m4a` files
- Ask whether to scan subdirectories recursively if not specified

### Step 2: Determine Output Settings

Confirm or infer these settings based on user requirements:

- **Output location**: Same directory as source, or a custom output directory
- **Bitrate**: Default 192kbps is good for most use cases. Use 320kbps for high quality, 128kbps for smaller files
- **Sample rate**: Default preserves original. Specify if the user needs a specific rate
- **Overwrite**: Ask the user if existing files should be overwritten

### Step 3: Execute Conversion

Run the conversion script with the appropriate arguments:

```bash
# Single file conversion
python scripts/m4a_to_mp3.py "/path/to/audio.m4a" -o "/path/to/output.mp3" -b 192

# Batch conversion (recursive, to custom output directory)
python scripts/m4a_to_mp3.py "/path/to/m4a_folder/" -r -d "/path/to/mp3_output/" -b 320 -f

# Batch conversion (same directory, overwrite existing)
python scripts/m4a_to_mp3.py "/path/to/m4a_folder/" -r -f
```

### Step 4: Report Results

After conversion, report to the user:

- Number of files successfully converted
- Number of files that failed (if any)
- Output file locations
- Any errors encountered

## Common Use Cases

### Convert a single M4A file

```bash
python scripts/m4a_to_mp3.py "C:/Users/me/recording.m4a"
```

Output: `C:/Users/me/recording.mp3` (same directory, 192kbps)

### Batch convert a folder with subfolders

```bash
python scripts/m4a_to_mp3.py "C:/Users/me/Music/" -r -d "C:/Users/me/Music_MP3/" -b 320
```

Recursively converts all `.m4a` files, outputs to `Music_MP3/` preserving folder structure, at 320kbps.

### Quick conversion with overwrite

```bash
python scripts/m4a_to_mp3.py "C:/recordings/" -r -f -q
```

Converts all M4A files in `recordings/` and subfolders, overwrites existing MP3s, quiet mode.

## Error Handling

The script handles common errors gracefully:

- **ffmpeg not found**: Auto-installs `imageio-ffmpeg` package as fallback
- **Input file not found**: Reports error and skips to next file in batch mode
- **Conversion timeout**: 10-minute timeout per file, reports the failed file
- **Output file exists**: Skips by default, use `-f` to overwrite
- **Permission errors**: Reports the specific error for diagnosis

## Technical Notes

- The script uses `libmp3lame` encoder for MP3 output, which is the standard high-quality MP3 encoder
- Metadata (ID3 tags) from the source M4A file is preserved during conversion
- The script works on Windows, macOS, and Linux
- For very large batch jobs, the script processes files sequentially to avoid memory issues
