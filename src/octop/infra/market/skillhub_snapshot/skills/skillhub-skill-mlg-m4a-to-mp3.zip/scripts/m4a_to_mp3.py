#!/usr/bin/env python3
"""
M4A to MP3 Converter
====================
Convert M4A audio files to MP3 format using ffmpeg as the backend.
Supports single file conversion, batch directory conversion, and configurable output settings.

Usage:
    python m4a_to_mp3.py <input_path> [options]

    # Convert a single file
    python m4a_to_mp3.py /path/to/audio.m4a

    # Convert a single file with custom output
    python m4a_to_mp3.py /path/to/audio.m4a -o /path/to/output.mp3

    # Convert all M4A files in a directory (recursive)
    python m4a_to_mp3.py /path/to/folder/ -r

    # Convert with custom bitrate and sample rate
    python m4a_to_mp3.py /path/to/audio.m4a -b 256 -s 48000

    # Overwrite existing files without asking
    python m4a_to_mp3.py /path/to/folder/ -r -f
"""

import argparse
import os
import subprocess
import sys
import glob


# ── ffmpeg binary resolution ──────────────────────────────────────────────

def get_ffmpeg_path():
    """
    Resolve the ffmpeg executable path.
    Priority:
      1. System ffmpeg (in PATH)
      2. imageio-ffmpeg bundled binary (auto-installed if missing)
    """
    # 1) Try system ffmpeg
    try:
        result = subprocess.run(
            ["ffmpeg", "-version"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return "ffmpeg"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # 2) Try imageio-ffmpeg package (bundles a static ffmpeg binary)
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        # Attempt to install imageio-ffmpeg into the current environment
        print("[INFO] ffmpeg not found on system. Attempting to install imageio-ffmpeg...")
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "--quiet", "imageio-ffmpeg"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            import imageio_ffmpeg
            return imageio_ffmpeg.get_ffmpeg_exe()
        except Exception as e:
            print(f"[ERROR] Failed to install imageio-ffmpeg: {e}", file=sys.stderr)
            print("[ERROR] Please install ffmpeg manually or run: pip install imageio-ffmpeg", file=sys.stderr)
            sys.exit(1)


# ── Core conversion logic ─────────────────────────────────────────────────

def convert_m4a_to_mp3(input_file, output_file=None, bitrate=192, sample_rate=None,
                       ffmpeg_path="ffmpeg", overwrite=False, quiet=False):
    """
    Convert a single M4A file to MP3.

    Args:
        input_file:    Path to the input .m4a file.
        output_file:   Path for the output .mp3 file. If None, uses same name with .mp3 extension.
        bitrate:       MP3 bitrate in kbps (e.g. 128, 192, 256, 320).
        sample_rate:   Audio sample rate in Hz (e.g. 44100, 48000). None = preserve original.
        ffmpeg_path:   Path to the ffmpeg executable.
        overwrite:     If True, overwrite existing output files without asking.
        quiet:         If True, suppress ffmpeg stderr output.

    Returns:
        True if conversion succeeded, False otherwise.
    """
    if not os.path.isfile(input_file):
        print(f"[ERROR] Input file not found: {input_file}", file=sys.stderr)
        return False

    if not input_file.lower().endswith(".m4a"):
        print(f"[WARN] Input file does not have .m4a extension: {input_file}", file=sys.stderr)

    # Determine output path
    if output_file is None:
        base, _ = os.path.splitext(input_file)
        output_file = base + ".mp3"
    else:
        # If output is a directory, place file inside it
        if os.path.isdir(output_file):
            base = os.path.splitext(os.path.basename(input_file))[0]
            output_file = os.path.join(output_file, base + ".mp3")

    # Check overwrite
    if os.path.exists(output_file) and not overwrite:
        print(f"[SKIP] Output already exists (use -f to overwrite): {output_file}")
        return True  # Not an error, just skipped

    # Build ffmpeg command
    cmd = [ffmpeg_path]
    if overwrite:
        cmd.append("-y")  # Overwrite without asking
    cmd.extend(["-i", input_file])

    # Audio codec settings
    cmd.extend(["-codec:a", "libmp3lame", "-b:a", f"{bitrate}k"])

    if sample_rate is not None:
        cmd.extend(["-ar", str(sample_rate)])

    cmd.append(output_file)

    if quiet:
        cmd.extend(["-loglevel", "error"])

    # Run conversion
    try:
        if not quiet:
            print(f"[CONVERT] {input_file} -> {output_file} ({bitrate}kbps)")
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if result.returncode != 0:
            print(f"[ERROR] ffmpeg failed for: {input_file}", file=sys.stderr)
            if result.stderr:
                # Print last 5 lines of stderr for diagnosis
                stderr_lines = result.stderr.strip().split("\n")
                for line in stderr_lines[-5:]:
                    print(f"  {line}", file=sys.stderr)
            return False
        if not quiet:
            print(f"  [OK] Done: {output_file}")
        return True
    except subprocess.TimeoutExpired:
        print(f"[ERROR] Conversion timed out for: {input_file}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"[ERROR] Unexpected error converting {input_file}: {e}", file=sys.stderr)
        return False


def convert_directory(input_dir, bitrate=192, sample_rate=None, recursive=False,
                      ffmpeg_path="ffmpeg", overwrite=False, output_dir=None, quiet=False):
    """
    Convert all M4A files in a directory to MP3.

    Args:
        input_dir:     Directory containing .m4a files.
        bitrate:       MP3 bitrate in kbps.
        sample_rate:   Audio sample rate in Hz. None = preserve original.
        recursive:     If True, search subdirectories.
        ffmpeg_path:   Path to ffmpeg executable.
        overwrite:     If True, overwrite existing output files.
        output_dir:    Output directory. If None, outputs go alongside inputs.
        quiet:         If True, suppress detailed output.

    Returns:
        (success_count, fail_count)
    """
    pattern = "**/*.m4a" if recursive else "*.m4a"
    m4a_files = glob.glob(os.path.join(input_dir, pattern), recursive=recursive)

    if not m4a_files:
        print(f"[INFO] No .m4a files found in: {input_dir}"
              + (" (recursive)" if recursive else ""))
        return (0, 0)

    print(f"[INFO] Found {len(m4a_files)} M4A file(s) to convert.\n")

    success = 0
    fail = 0
    for i, m4a_file in enumerate(m4a_files, 1):
        # Determine output path
        if output_dir:
            # Preserve relative directory structure in output
            rel_path = os.path.relpath(m4a_file, input_dir)
            out_file = os.path.join(output_dir, os.path.splitext(rel_path)[0] + ".mp3")
            os.makedirs(os.path.dirname(out_file), exist_ok=True)
        else:
            out_file = None  # Same directory as input

        print(f"[{i}/{len(m4a_files)}]", end=" ")
        ok = convert_m4a_to_mp3(
            m4a_file, output_file=out_file, bitrate=bitrate,
            sample_rate=sample_rate, ffmpeg_path=ffmpeg_path,
            overwrite=overwrite, quiet=quiet
        )
        if ok:
            success += 1
        else:
            fail += 1

    return (success, fail)


# ── CLI entry point ───────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Convert M4A audio files to MP3 format.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Convert a single file
  python m4a_to_mp3.py song.m4a

  # Convert with custom output path
  python m4a_to_mp3.py song.m4a -o output.mp3

  # Batch convert all M4A in a folder (recursive)
  python m4a_to_mp3.py ./music/ -r

  # Convert with 320kbps bitrate
  python m4a_to_mp3.py song.m4a -b 320

  # Convert to a specific output directory
  python m4a_to_mp3.py ./m4a_files/ -r -d ./mp3_files/

  # Overwrite existing files
  python m4a_to_mp3.py ./music/ -r -f
        """
    )
    parser.add_argument(
        "input",
        help="Input .m4a file or directory containing .m4a files"
    )
    parser.add_argument(
        "-o", "--output",
        default=None,
        help="Output file path (for single file) or output directory (for batch)"
    )
    parser.add_argument(
        "-d", "--output-dir",
        default=None,
        help="Output directory for batch conversion (preserves folder structure)"
    )
    parser.add_argument(
        "-b", "--bitrate",
        type=int, default=192,
        choices=[64, 96, 128, 160, 192, 256, 320],
        help="MP3 bitrate in kbps (default: 192)"
    )
    parser.add_argument(
        "-s", "--sample-rate",
        type=int, default=None,
        choices=[22050, 32000, 44100, 48000, 96000],
        help="Audio sample rate in Hz (default: preserve original)"
    )
    parser.add_argument(
        "-r", "--recursive",
        action="store_true",
        help="Recursively search subdirectories for .m4a files"
    )
    parser.add_argument(
        "-f", "--overwrite",
        action="store_true",
        help="Overwrite existing output files without asking"
    )
    parser.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Suppress detailed ffmpeg output"
    )

    args = parser.parse_args()

    # Resolve ffmpeg binary
    ffmpeg_path = get_ffmpeg_path()
    print(f"[INFO] Using ffmpeg: {ffmpeg_path}\n")

    input_path = os.path.abspath(args.input)

    if os.path.isdir(input_path):
        # Batch mode
        output_dir = args.output_dir or args.output
        success, fail = convert_directory(
            input_dir=input_path,
            bitrate=args.bitrate,
            sample_rate=args.sample_rate,
            recursive=args.recursive,
            ffmpeg_path=ffmpeg_path,
            overwrite=args.overwrite,
            output_dir=output_dir,
            quiet=args.quiet
        )
        print(f"\n{'='*50}")
        print(f"[DONE] Success: {success} | Failed: {fail}")
        if fail > 0:
            sys.exit(1)
    elif os.path.isfile(input_path):
        # Single file mode
        ok = convert_m4a_to_mp3(
            input_file=input_path,
            output_file=args.output,
            bitrate=args.bitrate,
            sample_rate=args.sample_rate,
            ffmpeg_path=ffmpeg_path,
            overwrite=args.overwrite,
            quiet=args.quiet
        )
        if not ok:
            sys.exit(1)
    else:
        print(f"[ERROR] Input path does not exist: {input_path}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
