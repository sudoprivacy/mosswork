## Description: <br>
An AI Dungeon Master skill for D&D 5e (2024) that guides narrative play, modular campaigns, combat adjudication, live party state, and conversational character creation. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[ackiles](https://clawhub.ai/user/ackiles) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External players and game masters use this skill to run D&D 5e sessions in an agent workspace, including save/load flow, module selection, character creation, combat resolution, and structured game-state tracking. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can read and write local game state and uses save/cache files in the working directory. <br>
Mitigation: Run it in a sandboxed campaign workspace and avoid importing untrusted save files. <br>
Risk: Artifact evidence includes broad workspace-agent behavior and personal-assistant sections that may expose unrelated personal context. <br>
Mitigation: Remove or disable AGENTS.md personal-assistant sections before installation. <br>
Risk: The echo/LLM feature can send text externally if a user enables and configures it. <br>
Mitigation: Keep the feature disabled unless users consent to external processing and explicitly configure credentials. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/ackiles/dnd-dm-skill) <br>
- [SKILL.md](artifact/SKILL.md) <br>
- [DM_RULES.md](artifact/references/DM_RULES.md) <br>
- [DM_TEMPLATES.md](artifact/references/DM_TEMPLATES.md) <br>
- [CHAR_CREATION.md](artifact/references/CHAR_CREATION.md) <br>
- [ECHO_ARC.md](artifact/references/ECHO_ARC.md) <br>
- [CODE_LIBRARY.md](artifact/code/CODE_LIBRARY.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Conversational Markdown with tables, JSON snippets, Python/API call examples, and local file updates.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May read and write local game-state files such as saves, world_state.json, live_party.json, and scene caches.] <br>

## Skill Version(s): <br>
1.1.2 (source: frontmatter, artifact metadata, server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
