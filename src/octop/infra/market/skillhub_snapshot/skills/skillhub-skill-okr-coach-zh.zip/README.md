# OKR 撰写与对齐教练

中国大厂版 OKR 教练——教你把模糊愿望写成可衡量的 O+KR、做季度对齐、避开『伪 KR』陷阱。覆盖个人 OKR、团队 OKR、跨部门对齐。

## 这是什么

`okr-coach-zh` 是一个针对**中国本地场景**原创设计的 OpenClaw / SkillHub Agent Skill。
从问题定义、框架设计、示例都是为中国用户从零写的，不是任何已有项目的翻译或 fork。

## 触发场景

详见 `SKILL.md` 的 description 字段，AI 会自动判断何时调用。常见关键词：

- `OKR`
- `目标对齐`
- `Objective`
- `Key Result`
- `季度复盘`
- `团队管理`
- `字节 OKR`

## 安装

### SkillHub（推荐）

通过 SkillHub Web 界面安装：https://skillhub.cloud.tencent.com/skills/okr-coach-zh

### OpenClaw / Claude Code

```bash
mkdir -p ~/.claude/skills
cp -R okr-coach-zh ~/.claude/skills/okr-coach-zh
```

### Cursor

把整个文件夹放到项目的 `.cursor/skills/okr-coach-zh/` 下，重启 Cursor 即可。

## 用法

直接用自然语言描述需求，AI 会自动加载本 skill。例如：

```
帮我用 OKR 撰写与对齐教练 来 ...
```

## License

MIT © 2026 ikun

## 反馈

- 觉得有用：在 SkillHub 给个 star
- 报 bug / 建议：SkillHub 评论区留言
