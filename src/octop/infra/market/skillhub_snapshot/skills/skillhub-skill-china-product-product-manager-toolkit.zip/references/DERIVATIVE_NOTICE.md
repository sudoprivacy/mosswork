# 衍生版本说明

- 原项目：[alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills/blob/aa8d778811a557a2c28ccadda4cf3d0bd028a4cc/.gemini/skills/product-manager-toolkit/SKILL.md)
- 原文件：`.gemini/skills/product-manager-toolkit/SKILL.md`
- 固定提交：`aa8d778811a557a2c28ccadda4cf3d0bd028a4cc`
- 许可证：`MIT`，全文见 `LICENSE.md`
- 原发布对象：`product-manager-toolkit`
- 新发布对象：`china-product-product-manager-toolkit`
- 修改内容：重新定义中国业务场景、输入、工作流、交付物、质量门槛、使用边界和语义化 Slug。
- 未删除原许可证义务，也未扩大为无法验证的平台执行能力。
