import argparse
import csv
import gzip
import http.client
import json
import pathlib
import re
import sys
import ssl
import urllib.error
import urllib.request
import zlib

ENDPOINT = "https://api.trmesh.com/api/pay-skills"
SPEC = json.loads((pathlib.Path(__file__).parent.parent / "references" / "skill.json").read_text(encoding="utf-8"))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class TransportError(OSError):
    """只输出受控诊断，不暴露异常原文、响应片段或支付凭证。"""
    def __init__(self, error, stage, status=None):
        reason = error.reason if isinstance(error, urllib.error.URLError) else error
        self.stage = stage
        self.status = status
        if isinstance(reason, TimeoutError):
            self.kind = "timeout"
        elif isinstance(reason, (EOFError, http.client.IncompleteRead)):
            self.kind = "incomplete_response"
        elif isinstance(reason, (gzip.BadGzipFile, zlib.error)):
            self.kind = "invalid_compression"
        elif isinstance(reason, ssl.SSLError):
            self.kind = "tls_error"
        else:
            self.kind = "connection_error"
        super().__init__(self.kind)

    def details(self):
        value = {"errorStage": self.stage, "errorType": self.kind}
        if self.status is not None:
            value["httpStatus"] = self.status
        return value


def emit(value):
    print(json.dumps(value, ensure_ascii=False))


def fail(code, context=None):
    emit({"code": code, **(context or {})})
    return 1


def send(path, body=None, headers=None):
    request = urllib.request.Request(
        ENDPOINT + path, None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8"),
        {"Content-Type": "application/json", "User-Agent": "SkillHubClient/1.0", "Accept-Encoding": "gzip", **(headers or {})}, method="GET" if body is None else "POST",
    )
    try:
        response = urllib.request.build_opener(NoRedirect()).open(request, timeout=60)
    except urllib.error.HTTPError as error:
        response = error
    except (OSError, http.client.HTTPException) as error:
        # urllib.open 同时包含连接及等待响应头，不能把这里超时误判为上游失败。
        raise TransportError(error, "request") from error
    with response:
        status = response.code
        try:
            # 只协商标准库可解码的 gzip，同时兼容未压缩的旧响应。
            encoding = getattr(response, "headers", {}).get("Content-Encoding", "").strip().lower()
            if encoding not in ("", "identity", "gzip"):
                return {"code": "invalid_service_response", "httpStatus": status,
                        "errorStage": "response_body", "errorType": "unsupported_encoding"}
            data = json.load(gzip.GzipFile(fileobj=response) if encoding == "gzip" else response)
        except (OSError, http.client.HTTPException, EOFError, zlib.error) as error:
            raise TransportError(error, "response_body", status) from error
        except ValueError:
            data = None
    return {**(data if isinstance(data, dict) else {"code": "invalid_service_response"}), "httpStatus": status}


def invoke(resume):
    context = json.load(sys.stdin)
    if not isinstance(context, dict):
        return fail("invalid_input")
    headers = {}
    order = None
    if resume:
        try:
            body = context["request"]
            order = context["order"]
            if body["capability"] != SPEC["key"]:
                return fail("invalid_order_context")
            order_id, access = order["orderId"], order["orderAccess"]
            code = order["WeixinPay"]["WeixinPay-Required"]
            if not (re.fullmatch(r"PS[0-9A-F]{30}", order_id) and re.fullmatch(r"[0-9A-F]{64}", access) and re.fullmatch(r"[!-~]{1,2048}", code)):
                return fail("invalid_order_context")
            headers = {"X-Out-Trade-No": order_id, "X-Skill-Order-Access": access, "WeixinPay-Required": code}
        except (KeyError, ValueError, TypeError):
            return fail("invalid_order_context")
    else:
        if set(context) - {"query", "payload"} or not all(isinstance(context.get(key, {}), dict) for key in ("query", "payload")):
            return fail("invalid_input")
        body = {"capability": SPEC["key"], "query": context.get("query", {}), "payload": context.get("payload", {})}
    try:
        result = send("/invoke", body, headers)
    except TransportError as error:
        return fail("network_error", {"request": body, "order": order, **error.details()})
    except (OSError, http.client.HTTPException):
        return fail("network_error", {"request": body, "order": order})
    if result["httpStatus"] == 402:
        try:
            candidate = {key: result[key] for key in ("orderId", "orderAccess", "amountFen", "currency", "WeixinPay")}
            if not (re.fullmatch(r"PS[0-9A-F]{30}", candidate["orderId"]) and
                    re.fullmatch(r"[0-9A-F]{64}", candidate["orderAccess"]) and
                    type(candidate["amountFen"]) is int and candidate["amountFen"] > 0 and
                    candidate["currency"] == "CNY" and
                    re.fullmatch(r"[!-~]{1,2048}", candidate["WeixinPay"]["WeixinPay-Required"]) and
                    (order is None or candidate == order)):
                raise ValueError("invalid_payment_response")
        except (KeyError, TypeError, ValueError):
            # 异常支付响应不能丢掉已有订单，否则重建单可能导致重复付款。
            return fail("invalid_payment_response", {"request": body, "order": order})
        order = candidate
    emit({**result, "request": body, "order": order})
    return 0


def plan():
    # 只计算用户可审阅的业务步骤报价，不联网、不创建订单、不执行采集。
    value = json.load(sys.stdin)
    steps = value.get("steps") if isinstance(value, dict) else None
    if not isinstance(steps, list) or not 1 <= len(steps) <= 100:
        return fail("invalid_plan")
    rows = []
    for index, step in enumerate(steps, 1):
        if not isinstance(step, dict):
            return fail("invalid_plan")
        count, description = step.get("requests"), step.get("description")
        if type(count) is not int or not 1 <= count <= 1000 or not isinstance(description, str) or not description.strip() or len(description) > 500:
            return fail("invalid_plan")
        rows.append({"step": index, "description": description.strip(), "requests": count, "amountFen": count * 5})
    emit({"estimateOnly": True, "currency": "CNY", "unitPriceFen": 5, "steps": rows,
          "requests": sum(row["requests"] for row in rows), "amountFen": sum(row["amountFen"] for row in rows)})
    return 0


def safe_cell(value):
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
        value = "'" + value
    return value


def export(path, array_path):
    result = json.load(sys.stdin)
    if not isinstance(result, dict) or result.get("httpStatus") != 200 or result.get("code") == "order_refund":
        return fail("invalid_csv_input")
    data = result
    try:
        for part in array_path.split("."):
            data = data[part]
    except (KeyError, TypeError):
        return fail("invalid_csv_path")
    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list) or any(not isinstance(row, dict) for row in data):
        return fail("invalid_csv_input")
    fields = list(dict.fromkeys(key for row in data for key in row))
    with open(path, "x", newline="", encoding="utf-8-sig") as output:
        writer = csv.writer(output)
        writer.writerow([safe_cell(field) for field in fields or ["empty_result"]])
        for row in data:
            writer.writerow([safe_cell(row.get(field)) for field in fields])
    emit({"path": path, "count": len(data)})
    return 0


def main():
    parser = argparse.ArgumentParser(description=SPEC["name"])
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("version")
    commands.add_parser("schema")
    commands.add_parser("plan")
    invoke_parser = commands.add_parser("invoke")
    invoke_parser.add_argument("--resume", action="store_true")
    export_parser = commands.add_parser("csv")
    export_parser.add_argument("path")
    export_parser.add_argument("--array-path", required=True)
    args = parser.parse_args()
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    try:
        if args.command == "version":
            emit({"slug": SPEC["slug"], "version": SPEC.get("version", "1.0.0"), "capability": SPEC["key"]})
            return 0
        if args.command == "schema":
            emit(send("/capabilities/" + SPEC["key"]))
            return 0
        if args.command == "invoke":
            return invoke(args.resume)
        if args.command == "plan":
            return plan()
        return export(args.path, args.array_path)
    except FileExistsError:
        return fail("csv_exists")
    except (ValueError, TypeError, KeyError):
        return fail("invalid_input")
    except TransportError as error:
        return fail("network_error", error.details())
    except (OSError, http.client.HTTPException):
        return fail("request_or_file_error")


if __name__ == "__main__":
    raise SystemExit(main())
