f = r'C:\Users\Administrator\Desktop\meeting-action-tracker\scripts\tracker.py'
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()
n = c.count('def _parse_owner')
print(f'_parse_owner count: {n}')
print(f'_clean_content count: {c.count("def _clean_content")}')

# Find the extract function usage
idx = c.find('owner = _parse_owner')
print(f'first extraction call at index: {idx}')
print(c[idx-30:idx+120])
print('---')
idx2 = c.find('owner = _parse_owner', idx+10)
print(f'second extraction call at index: {idx2}')
