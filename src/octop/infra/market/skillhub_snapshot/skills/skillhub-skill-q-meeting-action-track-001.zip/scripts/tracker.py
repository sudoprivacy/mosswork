#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
行动项追踪器 CLI — 会议行动项全生命周期管理
=============================================

功能:
  1. extract  — 从会议记录中提取行动项
  2. list     — 按状态/负责人列出行动项
  3. assign   — 分配负责人及更新信息
  4. report   — 生成进度报告（Markdown）
  5. overdue  — 检查逾期行动项

数据存储: action-items.json（脚本上级目录）
"""

import argparse
import calendar
import json
import os
import re
import sys
from datetime import datetime, date, timedelta
from pathlib import Path

# ── 配置 ─────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = BASE_DIR / "action-items.json"

DATE_FORMAT = "%Y-%m-%d"
DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S"


# ── 数据层 ───────────────────────────────────────────────────────────

def load_data() -> dict:
    """读取 action-items.json, 若文件不存在则返回空结构。"""
    if DATA_FILE.exists():
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"items": [], "metadata": {"last_synced": "", "total_items": 0, "overdue_count": 0}}


def save_data(data: dict) -> None:
    """将数据写入 action-items.json。"""
    now = datetime.now().strftime(DATETIME_FORMAT)
    data["metadata"]["last_synced"] = now
    data["metadata"]["total_items"] = len(data["items"])
    data["metadata"]["overdue_count"] = sum(1 for i in data["items"] if _is_overdue(i))
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _is_overdue(item: dict) -> bool:
    """判断行动项是否逾期: status 不是 done, deadline < 今天"""
    if item.get("status") == "done":
        return False
    dl = item.get("deadline")
    if not dl:
        return False
    try:
        return datetime.strptime(dl, DATE_FORMAT).date() < date.today()
    except ValueError:
        return False


def _next_id(data: dict) -> int:
    if not data["items"]:
        return 1
    return max(i["id"] for i in data["items"]) + 1


# ── 自然语言解析 ────────────────────────────────────────────────────

def _parse_deadline(text: str) -> str | None:
    """从文本中解析截止日期, 返回 YYYY-MM-DD 或 None。"""
    today = date.today()
    text = text.strip()

    # 1) 完整日期
    m = re.search(r"(\d{4})[年/-](\d{1,2})[月/-](\d{1,2})[日号]?", text)
    if m:
        return f"{int(m[1]):04d}-{int(m[2]):02d}-{int(m[3]):02d}"

    # 2) 月+日
    m = re.search(r"(\d{1,2})月(\d{1,2})[日号]?", text)
    if m:
        return f"{today.year}-{int(m[1]):02d}-{int(m[2]):02d}"

    # 3) 相对日期
    if "明天" in text or "明日" in text:
        return (today + timedelta(days=1)).strftime(DATE_FORMAT)
    if "后天" in text:
        return (today + timedelta(days=2)).strftime(DATE_FORMAT)

    # 4) 星期
    wd_map = {"一": 0, "二": 1, "三": 2, "四": 3, "五": 4, "六": 5, "日": 6, "天": 6}
    for cn_wd, tgt in wd_map.items():
        if f"下周{cn_wd}" in text:
            ahead = (tgt - today.weekday() + 7) % 7 or 7
            return (today + timedelta(days=ahead + 7)).strftime(DATE_FORMAT)
        if f"本周{cn_wd}" in text or f"这周{cn_wd}" in text:
            ahead = (tgt - today.weekday() + 7) % 7
            return (today + timedelta(days=ahead)).strftime(DATE_FORMAT)

    # 5) 月底/本月
    if "月底" in text or "月末" in text or "本月" in text:
        last = calendar.monthrange(today.year, today.month)[1]
        return f"{today.year}-{today.month:02d}-{last:02d}"

    # 6) 尽快
    if "尽快" in text or "尽早" in text:
        return (today + timedelta(days=3)).strftime(DATE_FORMAT)

    # 7) 下个月
    if "下个月" in text or "下月" in text:
        nm = today.month + 1
        ny = today.year
        if nm > 12:
            nm = 1
            ny += 1
        last = calendar.monthrange(ny, nm)[1]
        return f"{ny}-{nm:02d}-{last:02d}"

    return None


def _parse_owner(text: str) -> str | None:
    """从文本中提取负责人名称。"""
    bad = {"在", "这个", "那个", "什么", "怎么", "可以", "需要",
           "应该", "已经", "没有", "不是", "就是", "还是", "或者",
           "这些", "那些", "一个", "我们", "你们", "他们", "大家",
           "优先", "重点", "尽快", "紧急", "必须", "务必"}

    name = None
    # 由/让/请 + 名字 + 动词
    m = re.search(r"(?:由|让|请|叫|委托)([\u4e00-\u9fa5]{2,4})(?:来)?(?:负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|输出|修改|准备|制定|更新)", text)
    if m:
        name = m.group(1)
    # 名字+职务+动词
    if not name:
        m = re.search(r"([\u4e00-\u9fa5]{2,3})(?:经理|主管|组长|老师|工|总)(?:负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|输出)", text)
        if m:
            name = m.group(1)
    # 名字+动词
    if not name:
        m = re.search(r"([\u4e00-\u9fa5]{2,4})(?:负责|需要|跟进|落实|处理|完成|搞定|执行|更新|提交|输出|整理|安排|准备)", text)
        if m:
            name = m.group(1)
    # 交给/给 + 名字
    if not name:
        m = re.search(r"(?:交给|给|交由|安排)([\u4e00-\u9fa5]{2,4})", text)
        if m:
            name = m.group(1)
    # 清单格式 "张三："
    if not name:
        m = re.search(r"(?:^|\s)([\u4e00-\u9fa5]{2,4})[：:]\s+", text)
        if m:
            name = m.group(1)

    if name:
        # 去除名字后的尾缀词
        for sfx in ["优先", "重点", "尽快", "紧急", "必须", "务必", "马上", "立即"]:
            if name.endswith(sfx):
                name = name[:-len(sfx)]
                break
        if name not in bad and 2 <= len(name) <= 4:
            return name
    return None


def _parse_priority(text: str) -> str:
    """根据关键词判断优先级。"""
    if any(w in text for w in ["紧急", "优先", "马上", "立即", "尽快", "重要", "关键", "必须", "务必"]):
        return "high"
    if any(w in text for w in ["有空", "顺便", "不着急", "后续", "视情况"]):
        return "low"
    return "medium"


def _clean_content(sentence: str) -> str:
    """清理句子，提取核心行动描述。"""
    c = sentence

    # 去掉 由/让/请/叫 + 名字(含职务) + 动作词 前缀
    c = re.sub(
        r"^(?:由|让|请|叫|委托)?"
        r"[\u4e00-\u9fa5]{2,4}(?:经理|主管|组长|工|总)?"
        r"(?:负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|更新|输出)"
        r"[：:、]?\s*",
        "", c
    ).strip()

    # 去掉 名字(含职务) 在/要/需 + 时间 前缀
    c = re.sub(
        r"^[\u4e00-\u9fa5]{2,4}(?:工|总|经理|主管)?"
        r"(?:在|要|需|需要|必须|务必|会|将)"
        r"(?:下个?周[一二三四五日六日]?|今天|明天|后天|月底|本月|下个月|"
        r"\d+月\d+日|\d+[天日内]?)[前内]?"
        r"[，,：:]?\s*",
        "", c
    ).strip()

    # 去掉 名字: 前缀
    c = re.sub(r"^[\u4e00-\u9fa5]{2,4}[：:]\s*", "", c).strip()

    # 去掉编号 1. / 1、/ (1)
    c = re.sub(r"^\(?\d+[.、,，\)]?\s*", "", c).strip()

    # 去掉句首 在/于 + 时间 前缀
    c = re.sub(
        r"^(?:在|于)"
        r"(?:下个?周[一二三四五日六日]?|今天|明天|后天|月底|本月|下个月|"
        r"\d+月\d+日|\d+[天日内]?)[前内]?"
        r"[，,：:]?\s*",
        "", c
    ).strip()

    return c


def _extract_action_items(text: str) -> list[dict]:
    """从文本中提取多个行动项。"""
    items = []
    sentences = [s.strip() for s in re.split(r"[。；\n]", text) if s.strip()]
    action_kw = ["负责", "跟进", "完成", "搞定", "落实", "执行",
                 "更新", "提交", "输出", "处理", "整理", "写",
                 "做", "弄", "安排", "准备", "优化", "修复"]

    for sentence in sentences:
        if not any(w in sentence for w in action_kw):
            continue

        owner = _parse_owner(sentence)
        deadline = _parse_deadline(sentence)
        priority = _parse_priority(sentence)
        content = _clean_content(sentence)

        if not content or len(content) < 4:
            continue

        items.append({
            "content": content,
            "owner": owner or "待分配",
            "deadline": deadline or "",
            "priority": priority,
        })

    return items


# ── CLI 命令 ─────────────────────────────────────────────────────────

def cmd_extract(args: argparse.Namespace) -> None:
    """从文本中提取行动项。"""
    text = args.text
    if not text:
        text = sys.stdin.read().strip()
    if not text:
        print("未提供会议记录文本。使用 --text 参数或通过管道传入。")
        sys.exit(1)

    data = load_data()
    parsed = _extract_action_items(text)

    if not parsed:
        print("未能从输入中识别出行动项。")
        print('  示例: "张三负责完成竞品分析，下周五前提交"')
        sys.exit(1)

    new_items = []
    source = args.source or datetime.now().strftime("会议-%Y-%m-%d")
    now = datetime.now().strftime(DATETIME_FORMAT)

    for p in parsed:
        item = {
            "id": _next_id(data),
            "content": p["content"],
            "owner": p["owner"],
            "deadline": p["deadline"],
            "priority": p["priority"],
            "status": "pending",
            "source": source,
            "created": now,
            "updated": now,
            "notes": "",
        }
        data["items"].append(item)
        new_items.append(item)

    save_data(data)

    print(f"成功提取 {len(new_items)} 个行动项 (来源: {source})\n")
    for item in new_items:
        dl = item["deadline"] or "未设定"
        print(f"  #{item['id']:02d} [{item['priority'].upper():5s}] "
              f"{item['content'][:40]:40s} -> {item['owner']}  "
              f"(截止: {dl})")
    print()
    print("  使用 python tracker.py list 查看看板")
    print("  使用 python tracker.py assign --id N --owner 姓名 调整负责人")


def cmd_list(args: argparse.Namespace) -> None:
    """列出行动项, 支持多种筛选。"""
    data = load_data()
    items = data["items"]

    if not items:
        print("暂无行动项。使用 extract 命令从会议记录中提取。")
        return

    # 更新逾期状态
    for item in items:
        if _is_overdue(item) and item["status"] not in ("done", "overdue"):
            item["status"] = "overdue"
    save_data(data)

    if args.status:
        items = [i for i in items if i["status"] == args.status]
    if args.owner:
        items = [i for i in items if args.owner in i["owner"]]
    if args.priority:
        items = [i for i in items if i["priority"] == args.priority]

    if not items:
        print("没有符合条件的行动项。")
        return

    status_order = {"overdue": 0, "pending": 1, "in_progress": 2, "done": 3}
    items.sort(key=lambda x: (status_order.get(x["status"], 99), x.get("deadline") or "9999"))

    print(f"{'ID':>4s} {'状态':>10s} {'优先级':>6s} {'负责人':>8s}  "
          f"{'截止日期':10s}  行动项")
    print("-" * 85)
    for item in items:
        s_icon = {"pending": "[待执行]", "in_progress": "[进行中]",
                  "done": "[已完成]", "overdue": "[已逾期]"}.get(
            item["status"], item["status"])
        p_icon = {"high": "高", "medium": "中", "low": "低"}.get(
            item["priority"], item["priority"])
        dl = item.get("deadline", "")[:10] if item.get("deadline") else "--"
        ct = item["content"][:40]
        print(f"  {item['id']:02d} {s_icon:>10s} {p_icon:>6s} "
              f"{item['owner']:>8s}  {dl:10s}  {ct}")

    total = len(data["items"])
    done_c = sum(1 for i in data["items"] if i["status"] == "done")
    overdue_c = sum(1 for i in data["items"] if _is_overdue(i))
    print(f"\n  总计: {total}  |  已完成: {done_c}  |  "
          f"逾期: {overdue_c}  |  显示: {len(items)}")


def cmd_assign(args: argparse.Namespace) -> None:
    """分配/更新行动项。"""
    data = load_data()
    item = next((i for i in data["items"] if i["id"] == args.id), None)

    if not item:
        print(f"未找到 ID 为 {args.id} 的行动项。")
        sys.exit(1)

    now = datetime.now().strftime(DATETIME_FORMAT)

    if args.owner:
        item["owner"] = args.owner
    if args.deadline:
        item["deadline"] = args.deadline
    if args.status:
        item["status"] = args.status
    if args.priority:
        item["priority"] = args.priority

    item["updated"] = now
    save_data(data)

    print(f"已更新行动项 #{args.id}:")
    print(f"  内容: {item['content']}")
    print(f"  负责人: {item['owner']}")
    print(f"  截止: {item.get('deadline', '未设定') or '未设定'}")
    print(f"  状态: {item['status']}")
    print(f"  优先级: {item['priority']}")


def cmd_report(args: argparse.Namespace) -> None:
    """生成 Markdown 格式的行动项进度报告。"""
    data = load_data()
    items = data["items"]
    total = len(items)

    done_c = sum(1 for i in items if i["status"] == "done")
    in_p = sum(1 for i in items if i["status"] == "in_progress")
    pend = sum(1 for i in items if i["status"] == "pending")
    overdue_c = sum(1 for i in items if _is_overdue(i))
    rate = round(done_c / total * 100, 1) if total > 0 else 0

    owners = {}
    for item in items:
        o = item["owner"]
        if o not in owners:
            owners[o] = {"p": 0, "ip": 0, "d": 0, "ov": 0}
        if _is_overdue(item):
            owners[o]["ov"] += 1
        owners[o][{"pending": "p", "in_progress": "ip", "done": "d",
                    "overdue": "ov"}.get(item["status"], "p")] += 1

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")

    lines = [
        "---",
        "# 行动项执行报告",
        f"**生成时间**: {now_str}",
        f"**数据源**: {DATA_FILE.name}",
        "",
        "---",
        "",
        "## 总览",
        "",
        "| 指标 | 数值 |",
        "|------|------|",
        f"| 总行动项 | {total} |",
        f"| 已完成 | {done_c} ({rate}%) |",
        f"| 进行中 | {in_p} |",
        f"| 待执行 | {pend} |",
        f"| 逾期 | {overdue_c} |",
        "",
    ]

    if owners:
        lines += [
            "## 各负责人执行情况",
            "",
            "| 负责人 | 待执行 | 进行中 | 已完成 | 逾期 | 完成率 |",
            "|--------|--------|--------|--------|------|--------|",
        ]
        for o, s in sorted(owners.items()):
            ot = sum(s.values())
            od = s["d"]
            or_ = round(od / ot * 100, 1) if ot > 0 else 0
            lines.append(
                f"| {o} | {s['p']} | {s['ip']} | {od} | {s['ov']} | {or_}% |"
            )

    o_items = [i for i in items if _is_overdue(i)]
    if o_items:
        lines += ["", "## 逾期清单", "",
                   "| ID | 行动项 | 负责人 | 截止日期 | 逾期天数 |",
                   "|----|--------|--------|----------|----------|"]
        today = date.today()
        for oi in sorted(o_items, key=lambda x: x.get("deadline", "")):
            dl = oi.get("deadline", "")
            od_d = 0
            if dl:
                try:
                    od_d = (today - datetime.strptime(dl, DATE_FORMAT).date()).days
                except ValueError:
                    pass
            lines.append(
                f"| {oi['id']} | {oi['content'][:30]} | "
                f"{oi['owner']} | {dl} | {od_d}天 |"
            )
    else:
        lines += ["", "## 逾期清单", "", "无逾期行动项。"]

    fu = [i for i in items if i["status"] in ("pending", "in_progress", "overdue")]
    if fu:
        lines += ["", "## 下次会议待跟进", "",
                   "| ID | 行动项 | 负责人 | 截止日期 | 状态 |",
                   "|----|--------|--------|----------|------|"]
        sl = {"pending": "待执行", "in_progress": "进行中", "overdue": "已逾期"}
        for fi in fu:
            lbl = sl.get(fi["status"], fi["status"])
            lines.append(
                f"| {fi['id']} | {fi['content'][:30]} | "
                f"{fi['owner']} | {fi.get('deadline', '未设定') or '未设定'} | {lbl} |"
            )

    lines += ["", "---", "*报告由 meeting-action-tracker 自动生成*"]
    report_text = "\n".join(lines)

    print(report_text)

    rf = BASE_DIR / f"action-report-{datetime.now().strftime('%Y%m%d-%H%M%S')}.md"
    with open(rf, "w", encoding="utf-8") as f:
        f.write(report_text)
    print(f"\n报告已保存: {rf}")


def cmd_overdue(args: argparse.Namespace) -> None:
    """检查并列出逾期行动项。"""
    data = load_data()
    o_items = [i for i in data["items"] if _is_overdue(i)]

    if not o_items:
        print("所有行动项均在截止日期内！")
        return

    print(f"逾期行动项 (共 {len(o_items)} 项):\n")
    today = date.today()
    for oi in o_items:
        dl = oi.get("deadline", "未知")
        ds = ""
        if dl:
            try:
                od = (today - datetime.strptime(dl, DATE_FORMAT).date()).days
                ds = f"逾期 {od} 天" if od > 0 else "今天截止"
            except ValueError:
                ds = "日期格式异常"
        print(f"  #{oi['id']:02d} {oi['content'][:45]:45s}")
        print(f"     负责人: {oi['owner']:8s}  |  截止: {dl:10s}  |  {ds}\n")

    updated = False
    for item in o_items:
        if item["status"] != "overdue":
            item["status"] = "overdue"
            item["updated"] = datetime.now().strftime(DATETIME_FORMAT)
            updated = True
    if updated:
        save_data(data)
        print("已将上述行动项标记为 'overdue'")


# ── 主入口 ────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="tracker.py",
        description="行动项追踪器 - 会议行动项全生命周期管理",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""使用示例:
  # 从会议记录中提取行动项
  python tracker.py extract --text "张三负责竞品分析，下周五前完成"

  # 从管道读取
  cat meeting.md | python tracker.py extract

  # 列出所有待办
  python tracker.py list

  # 按状态筛选
  python tracker.py list --status overdue

  # 分配负责人
  python tracker.py assign --id 1 --owner "张三"

  # 生成进度报告
  python tracker.py report

  # 检查逾期
  python tracker.py overdue
        """,
    )

    sub = parser.add_subparsers(dest="command", help="可用命令")

    # extract
    pe = sub.add_parser("extract", help="从会议记录中提取行动项")
    pe.add_argument("--text", "-t", type=str, default="",
                    help="会议记录文本 (或从 stdin 传入)")
    pe.add_argument("--source", "-s", type=str, default="",
                    help="来源会议名称")

    # list
    pl = sub.add_parser("list", help="列出行动项")
    pl.add_argument("--status", "-s", type=str,
                    choices=["pending", "in_progress", "done", "overdue"],
                    default="", help="按状态筛选")
    pl.add_argument("--owner", "-o", type=str, default="",
                    help="按负责人筛选")
    pl.add_argument("--priority", "-p", type=str,
                    choices=["high", "medium", "low"],
                    default="", help="按优先级筛选")

    # assign
    pa = sub.add_parser("assign", help="分配/更新行动项")
    pa.add_argument("--id", "-i", type=int, required=True, help="行动项 ID")
    pa.add_argument("--owner", "-o", type=str, default="",
                    help="负责人姓名")
    pa.add_argument("--deadline", "-d", type=str, default="",
                    help="截止日期 (YYYY-MM-DD)")
    pa.add_argument("--status", "-s", type=str,
                    choices=["pending", "in_progress", "done", "overdue"],
                    default="", help="更新状态")
    pa.add_argument("--priority", "-p", type=str,
                    choices=["high", "medium", "low"],
                    default="", help="更新优先级")

    # report
    sub.add_parser("report", help="生成行动项进度报告 (Markdown)")

    # overdue
    sub.add_parser("overdue", help="检查逾期行动项")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return

    {"extract": cmd_extract, "list": cmd_list, "assign": cmd_assign,
     "report": cmd_report, "overdue": cmd_overdue}[args.command](args)


if __name__ == "__main__":
    main()
