import re

def _parse_owner(text):
    bad = {"在", "这个", "那个", "什么", "怎么", "可以", "需要",
           "应该", "已经", "没有", "不是", "就是", "还是", "或者",
           "这些", "那些", "一个", "我们", "你们", "他们", "大家",
           "优先", "重点", "尽快", "紧急", "必须", "务必"}

    name = None
    m = re.search(r"(?:由|让|请|叫|委托)([\u4e00-\u9fa5]{2,4})(?:来)?(?:负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|输出|修改|准备|制定|更新)", text)
    if m:
        name = m.group(1)
    if not name:
        m = re.search(r"([\u4e00-\u9fa5]{2,3})(?:经理|主管|组长|老师|工|总)(?:负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|输出)", text)
        if m:
            name = m.group(1)
    if not name:
        m = re.search(r"([\u4e00-\u9fa5]{2,4})(?:负责|需要|跟进|落实|处理|完成|搞定|执行|更新|提交|输出|整理|安排|准备)", text)
        if m:
            name = m.group(1)
    if not name:
        m = re.search(r"(?:交给|给|交由|安排)([\u4e00-\u9fa5]{2,4})", text)
        if m:
            name = m.group(1)
    if not name:
        m = re.search(r"(?:^|\s)([\u4e00-\u9fa5]{2,4})[：:]\s+", text)
        if m:
            name = m.group(1)

    if name:
        for sfx in ["优先", "重点", "尽快", "紧急", "必须", "务必", "马上", "立即"]:
            if name.endswith(sfx):
                name = name[:-len(sfx)]
                break
        if name not in bad and 2 <= len(name) <= 4:
            return name
    return None

# Test
tests = [
    "张三负责完成用户注册流程优化",
    "李四负责在周三前输出竞品分析报告",
    "王五需在月底前完成A/B测试方案设计",
    "由张三完成竞品分析",
    "张经理负责跟进客户反馈",
]
for t in tests:
    result = _parse_owner(t)
    print(f"'{t}' -> '{result}'")
