f = r'C:\Users\Administrator\Desktop\meeting-action-tracker\scripts\tracker.py'
with open(f, 'r', encoding='utf-8') as fh:
    c = fh.read()

# Show _extract_action_items
idx = c.find('def _extract_action_items')
end = c.find('def cmd_extract', idx)
print(c[idx:end])
