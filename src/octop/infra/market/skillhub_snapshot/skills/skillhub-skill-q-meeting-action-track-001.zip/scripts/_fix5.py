import re

with open(r'C:\Users\Administrator\Desktop\meeting-action-tracker\scripts\tracker.py', 'r', encoding='utf-8') as f:
    c = f.read()

# Fix 1: Change pattern 3 to use lookahead instead of consuming match
old_pat3 = r'([\u4e00-\u9fa5]{2,4})(?:负责|需要|跟进|落实|处理|完成|搞定|执行|更新|提交|输出|整理|安排|准备)'
new_pat3 = r'([\u4e00-\u9fa5]{2,4})(?=负责|需要|跟进|落实|处理|完成|搞定|执行|更新|提交|输出|整理|安排|准备)'
c = c.replace(old_pat3, new_pat3)

# Fix 2: Fix pattern 1 similar issue - use lookahead for the verb
old_pat1 = r'(?:由|让|请|叫|委托)([\u4e00-\u9fa5]{2,4})(?:来)?(?:负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|输出|修改|准备|制定|更新)'
new_pat1 = r'(?:由|让|请|叫|委托)([\u4e00-\u9fa5]{2,4})(?:来)?(?=负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|输出|修改|准备|制定|更新)'
c = c.replace(old_pat1, new_pat1)

# Fix 3: Fix pattern 2 similarly
old_pat2 = r'([\u4e00-\u9fa5]{2,3})(?:经理|主管|组长|老师|工|总)(?:负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|输出)'
new_pat2 = r'([\u4e00-\u9fa5]{2,3})(?:经理|主管|组长|老师|工|总)(?=负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|输出)'
c = c.replace(old_pat2, new_pat2)

# Fix 4: Fix _clean_content similarly - avoid consuming "完成" etc in prefix removal
old_cc1 = r'[\u4e00-\u9fa5]{2,4}(?:经理|主管|组长|工|总)?(?:负责|处理|跟进|完成|搞定|执行|做|弄|写|整理|落实|更新|输出)[：:、]?\s*'
new_cc1 = r'[\u4e00-\u9fa5]{2,4}(?:经理|主管|组长|工|总)?(?:负责|处理|跟进|搞定|执行|做|弄|写|整理|落实|更新|输出)[：:、]?\s*'
c = c.replace(old_cc1, new_cc1)

with open(r'C:\Users\Administrator\Desktop\meeting-action-tracker\scripts\tracker.py', 'w', encoding='utf-8') as f:
    f.write(c)

print("Fixed!")
