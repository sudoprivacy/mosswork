---
name: skillhub-skill-n8n-github-jira-ticket-automator
description: "通过 n8n REST API 部署 n8n 工作流，使用 GitHub Trigger 节点捕获新问题事件，并通过 Jira Cloud REST API 将其转换为 Jira 工单。标签、优先级映射和负责人路由规则使用 n8n 的 Function 节点与自定义 JavaScript 进行配置。"
---

# n8n GitHub Issue到Jira工单自动化器

Deploys an n8n workflow via the n8n REST API using the GitHub Trigger node to capture new issue events and transform them into Jira tickets via the Jira Cloud REST API. Labels, priority mappings, and assignee routing rules are configured using n8n's Function node with custom JavaScript.

## Installation

Use the upstream install or setup path that matches your environment:
- npm
- npm credentials
- Docker
- Docker Compose

Requirements and caveats from upstream:
- Accessing linked items in the Code node
- Preserving linking in the Code node
- Item linking for node creators

Basic usage or getting-started notes:
- Learning path
- Choose your n8n
- Quickstarts

- Source: https://docs.n8n.io/

## Documentation

- https://docs.n8n.io/
