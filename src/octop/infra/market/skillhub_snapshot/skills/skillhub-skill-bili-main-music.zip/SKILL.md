---
name: skillhub-skill-bili-main-music
description: "当用户想按 B 站「音乐」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：音乐、B站分区、rid 3。"
---

# B 站分区 · 音乐

- 一级分区 rid：`3`；网页路由：`/v/music/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 97 条榜单条目，覆盖 11 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| AI音乐 | 2 | 2 | 265 |
| MV | 5 | 8 | 193 |
| VOCALOID·UTAU | 3 | 9 | 30 |
| 乐评盘点 | 13 | 9 | 243 |
| 原创音乐 | 5 | 9 | 28 |
| 演奏 | 15 | 10 | 59 |
| 电台 | 3 | 4 | 267 |
| 翻唱 | 18 | 9 | 31 |
| 音乐教学 | 1 | 2 | 244 |
| 音乐现场 | 9 | 10 | 29 |
| 音乐综合 | 23 | 10 | 130 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### AI音乐

数据来源：二级分区 7 日榜，可用 2 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| “儿时最爱玩的东西南北，你还会叠么？” | 一罐蠢乃酱 | [BV1yPZmYZE3P](https://www.bilibili.com/video/BV1yPZmYZE3P) | 51.1 万 |
| 《室内系的TrackMaker》DJ版 如果萌是一种天赋 | byd小绫 | [BV1gDdnYREEL](https://www.bilibili.com/video/BV1gDdnYREEL) | 172.8 万 |

### MV

数据来源：二级分区 7 日榜，可用 8 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【SMTR25】SMTR25 Introduction film_JUSTIN | SMTR25 | [BV1uJZUYqESL](https://www.bilibili.com/video/BV1uJZUYqESL) | 282.8 万 |
| 汪苏泷2024十万伏特演唱会纪录片《生于罗曼》 | 汪苏泷 | [BV1uGZ2YeEiS](https://www.bilibili.com/video/BV1uGZ2YeEiS) | 56.4 万 |
| MARK《1999》MV | SMTOWN | [BV1F4RdYNEti](https://www.bilibili.com/video/BV1F4RdYNEti) | 50.9 万 |
| “戴上耳机，感受丝滑串烧” | 南风未满 | [BV19yZ2YrEgu](https://www.bilibili.com/video/BV19yZ2YrEgu) | 169.8 万 |
| 从偶像到同行：方大同与大师们的跨时空音乐对话 | 爱吃巨无霸鸡肉堡 | [BV12edJY2ETK](https://www.bilibili.com/video/BV12edJY2ETK) | 33.2 万 |

### VOCALOID·UTAU

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 你可能不认识我，但你也许听过或者背过我写的歌词，那认识一下？ | 邪叫教主 | [BV1oUZDYsEUY](https://www.bilibili.com/video/BV1oUZDYsEUY) | 279.1 万 |
| 【初音未来原创】我是洛天依 | 鬼面P | [BV1BcZUYSEQQ](https://www.bilibili.com/video/BV1BcZUYSEQQ) | 230.1 万 |
| ［清明节安康］术力口已逝P主 | 下雪冰川 | [BV12pZZYxEvk](https://www.bilibili.com/video/BV12pZZYxEvk) | 109.9 万 |
| 【洛天依初音未来合唱】我是初音未来，我才是洛天依 | -森久保行野- | [BV1nzRXYbEtJ](https://www.bilibili.com/video/BV1nzRXYbEtJ) | 77.5 万 |
| ナユタン星人 - 惑星ループ/行星环 (ft.初音ミク) OFFICIAL MUSIC VIDEO | ナユタン星人_官方 | [BV16LZmYnEhC](https://www.bilibili.com/video/BV16LZmYnEhC) | 27.1 万 |

### 乐评盘点

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 国外声乐老师的李宗盛初体验《山丘》神级LIVE舞台 REACTION | JKAI杰凯 | [BV1YQRrYDEs9](https://www.bilibili.com/video/BV1YQRrYDEs9) | 128.2 万 |
| 周杰伦居然一直在“抄袭”？！终极抄袭鉴定｜洗歌/音乐裁缝/采样/说唱/嘻哈/以父之名/双刀/我的地盘/麦芽糖/牛仔很忙/loop/音乐版权/编曲/音乐制作/洗稿 | PM玩乐志 | [BV1NEZdYHEpj](https://www.bilibili.com/video/BV1NEZdYHEpj) | 71.1 万 |
| 一秒回到真童年！1900-2000年日本动漫歌曲排行榜TOP100（2025年最新版）小时候也吃得太好了！ | 小小佐仓千代 | [BV1cVZmYXEp3](https://www.bilibili.com/video/BV1cVZmYXEp3) | 90.3 万 |
| 一直“当当当”的是啥歌？宋雨琦新歌刷屏全网，几天就5亿播放 | 音乐Wu哥 | [BV1gbdHYfEpj](https://www.bilibili.com/video/BV1gbdHYfEpj) | 444.1 万 |
| 爆哭！外国音乐人缅怀方大同听《春风吹》泪洒现场 | 拉美小姐姐Waleska | [BV1dFZAYXE9e](https://www.bilibili.com/video/BV1dFZAYXE9e) | 55.7 万 |

### 原创音乐

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 草东没有派对 | 為由 | [BV1ijRfYBEc2](https://www.bilibili.com/video/BV1ijRfYBEc2) | 95.3 万 |
| 【Avicii】⚡️Super idol の Love⚡️ | 诗人月Bryan | [BV1GNRqYqEqF](https://www.bilibili.com/video/BV1GNRqYqEqF) | 107.6 万 |
| 地球形态1—30大合集！ | 蓝色星尘2 | [BV1wtZ2YWEH4](https://www.bilibili.com/video/BV1wtZ2YWEH4) | 300.0 万 |
| 你可能不认识我，但你或许听过我改的歌！是时候认识一下了… | 糖醋蛋黄 | [BV1evZhYYEox](https://www.bilibili.com/video/BV1evZhYYEox) | 63.9 万 |
| 4.“你所期盼的春天” | 在虚无中永存 | [BV1ZVdJYcEjF](https://www.bilibili.com/video/BV1ZVdJYcEjF) | 98.4 万 |

### 演奏

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| “残影是相机的极限，而不是我的极限” | 神秘の东方PB玩家 | [BV1dzRqYVEwg](https://www.bilibili.com/video/BV1dzRqYVEwg) | 1120.7 万 |
| 珍贵影像《优雅oiiaii》 | 浑元Rysn | [BV1XkRyYsEKc](https://www.bilibili.com/video/BV1XkRyYsEKc) | 183.7 万 |
| 五音疗愈，听完稳定情绪心情莫名愉悦，五音属木多听能心情愉悦疏肝解郁 | 布和笛箫 | [BV1qHR6YpEt1](https://www.bilibili.com/video/BV1qHR6YpEt1) | 54.3 万 |
| 当我和邻居在下浩里排练，竟然偶遇甲亢哥#甲亢哥 #甲亢哥来重庆 #钢琴 #小提琴 #阳光彩虹小白马 | 鹏鹏-piano | [BV1HDZ1YUEF2](https://www.bilibili.com/video/BV1HDZ1YUEF2) | 149.7 万 |
| #Maneskin#iwannabeyourslave#小提琴#无声卡清唱#10后 | Bellalalalaw | [BV17MZXYhEfX](https://www.bilibili.com/video/BV17MZXYhEfX) | 65.6 万 |

### 电台

数据来源：二级分区 7 日榜，可用 4 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| "我的无力成为了我的败笔" | 白白的空格 | [BV1r4Z9YTE3X](https://www.bilibili.com/video/BV1r4Z9YTE3X) | 81.5 万 |
| 循环歌单\|“ 听这首歌的麻烦拍我一下，我怕收藏之后落灰”\|《山楂树之恋DJ版》 | 绪笔梦生花 | [BV13PRZYZEhV](https://www.bilibili.com/video/BV13PRZYZEhV) | 193.0 万 |
| 循环歌单｜《自娱自乐》｜“我学着一个人一整天都不失落” | 忆于音 | [BV12kfMYpEcd](https://www.bilibili.com/video/BV12kfMYpEcd) | 14.0 万 |
| 循环歌单\|“权威の小曲”“大手子の小曲”\|《Dancin (权威小曲)-Yalo》\|动态歌词【Hi-Res无损】 | 心刚音乐库 | [BV1zBZZYLEga](https://www.bilibili.com/video/BV1zBZZYLEga) | 23.2 万 |

### 翻唱

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 百万粉丝奖牌开箱 感恩有你 | 上官龍輝 | [BV1n9ZmYsEE9](https://www.bilibili.com/video/BV1n9ZmYsEE9) | 273.3 万 |
| 我爱你们，胜过爱我自己 | 田一名sir | [BV1LeR2YBEoz](https://www.bilibili.com/video/BV1LeR2YBEoz) | 177.8 万 |
| 谢谢你们带来的音乐，再见 | 吹拉弹唱慕星银 | [BV1qzZZYyESZ](https://www.bilibili.com/video/BV1qzZZYyESZ) | 80.7 万 |
| 《跳楼机》粤语版 女版翻唱  ｜ “好天气好得应该分离。” | 糖糖YuzeTang | [BV1HMRBYWEhh](https://www.bilibili.com/video/BV1HMRBYWEhh) | 241.6 万 |
| 神呐神呐 听不到吗？✨『弄 舌』兰音Reine | 兰音Reine | [BV1u1RyYpE59](https://www.bilibili.com/video/BV1u1RyYpE59) | 235.2 万 |

### 音乐教学

数据来源：二级分区 7 日榜，可用 2 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 一个你听过但是叫不出名字的采样（Orchestra Hit） | Synthet官方字幕组 | [BV15wZdYAEof](https://www.bilibili.com/video/BV15wZdYAEof) | 307.2 万 |
| 歌手唱歌声压拉满，你的声音却入不了麦？一条视频教你轻松解决！ | Jason-老湿 | [BV1XrRdY9Ehn](https://www.bilibili.com/video/BV1XrRdY9Ehn) | 202.3 万 |

### 音乐现场

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 你可能不认识我，但你也许可能，大约有概率听过我唱的歌～ | Lily陈洁丽 | [BV1BwRXY9EdL](https://www.bilibili.com/video/BV1BwRXY9EdL) | 229.8 万 |
| 去年崩铁演唱会知更鸟这段真是太震撼了！ | 小怡教官 | [BV1bvZmYqE4a](https://www.bilibili.com/video/BV1bvZmYqE4a) | 109.7 万 |
| Yellowzero跳楼机cover | 黄龄 | [BV11kdcYbELc](https://www.bilibili.com/video/BV11kdcYbELc) | 162.9 万 |
| 【王心凌7K】仙女下凡王心凌！今天这套花仙子凌真的全场最佳啊啊啊啊#王心凌泉州演唱会#大眠 | 王心凌FM | [BV1vyRzYmE3J](https://www.bilibili.com/video/BV1vyRzYmE3J) | 133.6 万 |
| #石凯MaybeOneDay舞蹈版# 时隔多年再一次的舞蹈版，希望大家可以喜欢！❤️ | 石凯kk | [BV1xARBYoE5x](https://www.bilibili.com/video/BV1xARBYoE5x) | 32.5 万 |

### 音乐综合

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| E人绑架了I人... | 战斗员10号 | [BV13xZRYoEs8](https://www.bilibili.com/video/BV13xZRYoEs8) | 106.0 万 |
| “过气歌手”的实力到底有多强？ | 八零九零音乐 | [BV1CER2YUEZ8](https://www.bilibili.com/video/BV1CER2YUEZ8) | 276.7 万 |
| 他拿下了华语年度最佳专辑!丨第四届HMA颁奖典礼丨HOPICO | HOPICO | [BV1CxfTYLEy8](https://www.bilibili.com/video/BV1CxfTYLEy8) | 86.1 万 |
| 【宝藏歌曲合集】白鸽乌鸦相爱的戏码 只会出现在童话 | 果粒橙音乐 | [BV1ZLRSY7E1E](https://www.bilibili.com/video/BV1ZLRSY7E1E) | 77.4 万 |
| “战争还要多久结束……少女的愿望只想回去过上个普通生活”//Lofi and CHill type beat💔 | 以實瑪利亞_Official | [BV15MdwYrEhd](https://www.bilibili.com/video/BV15MdwYrEhd) | 32.5 万 |

## 名称差异与覆盖说明

- 分区表列出但本次榜单未返回条目：音乐粉丝饭拍（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=3." https://api.bilibili.com/x/web-interface/ranking/v2?rid=3&type=all. Accessed 6 Nov. 2026.
