# 数据来源、边界与引用

## 采集说明

本体系的数据来自哔哩哔哩公开 Web 接口，无需登录。主榜采集脚本为 `scripts/fetch_all_zones.py`，原始快照为 `data/zones_snapshot.json`；二级分区 7 日榜采集脚本为 `fetch_subzones.py`（工作区内），用于补齐主榜里条目过少的子分区。分区名称与 rid 的对照参考公开的社区整理分区表；**现行子分区名称一律以接口实际返回的 `tname` 字段为准**。

## 数据边界（必读）

1. 公开排行榜接口只返回标题、UP 主、BV 号、播放量、弹幕数、点赞数、时长、发布时间、简介等元数据；它不返回视频口播、字幕、选集目录或章节大纲。本体系不含视频里的具体讲解内容。
2. 榜单是采集时刻的快照，名次与播放量持续变化；它不代表全站创作者排名，也不构成质量评价。
3. 部分一级分区（番剧、国创、资讯、广告）在当前排行榜接口返回 `code=-400`，因此本体系不为它们提供视频条目，只保留分区结构与路由。
4. 社区分区表里标注「已下线」「重定向」的条目属于历史记录，本体系不用它们承载现行榜单数据。
5. 分区名称在社区文档与当前接口之间存在个别差异（例如知识区文档写「野生技术协会」、接口返回「野生技能协会」；动画区文档写「手办·模玩」、接口返回「模玩·周边」）。本体系保留接口名称，并在分区分册中列出差异，不做合并或改写。
6. 本体系不虚构 UP 主、不虚构视频标题、不虚构播放数据。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2." https://api.bilibili.com/x/web-interface/ranking/v2?rid=36&type=all. Accessed 6 Nov. 2026.

Bilibili. "分区排行榜接口 /x/web-interface/ranking/region." https://api.bilibili.com/x/web-interface/ranking/region?rid=208&day=7. Accessed 6 Nov. 2026.

好奇星人知识喵. "知识分区调整公告." *哔哩哔哩*, https://www.bilibili.com/read/cv6289732. Accessed 5 Nov. 2026.
