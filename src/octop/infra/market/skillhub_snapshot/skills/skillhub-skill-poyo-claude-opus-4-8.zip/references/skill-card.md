## Description: <br>
Helps agents prepare Claude Opus 4.8 Messages API payloads for PoYo, including system prompts, multi-turn conversations, tools, structured output, prompt caching, vision content blocks, streaming, and server-side curl integration. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to build and review PoYo Claude Opus 4.8 Messages API requests, including payload structure, authentication headers, streaming behavior, tool definitions, and response parsing notes. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Live use sends prompts, messages, images, and tool inputs included in the payload to PoYo's API. <br>
Mitigation: Review payloads before submitting them and avoid sending private or regulated data unless PoYo is approved for that use. <br>
Risk: The skill requires a POYO_API_KEY for live API calls. <br>
Mitigation: Keep the API key in server-side environment variables or a backend secret manager, and do not expose it in browser code, logs, screenshots, repositories, or chat output. <br>
Risk: Prepared examples can trigger real network requests when the included shell script is run. <br>
Mitigation: Run the script only from a trusted shell with an explicitly reviewed JSON payload and a safe server-side environment. <br>
Risk: Streaming requests require client code that can correctly consume streamed responses. <br>
Mitigation: Enable streaming only when the application has streaming-aware response handling. <br>


## Reference(s): <br>
- [PoYo Claude Opus 4.8 model page](https://poyo.ai/models/claude-opus-4-8) <br>
- [PoYo Claude Messages API documentation](https://docs.poyo.ai/api-manual/chat-series/claude-messages) <br>
- [Skill API reference](references/api.md) <br>
- [ClawHub skill page](https://clawhub.ai/coolhackboy/skills/poyo-claude-opus-4-8) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON payloads and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include synchronous or streaming handling notes, response parsing guidance, and server-side API key configuration.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
