# 衍生版本说明

- 原项目：[finsilabs/awesome-ecommerce-skills](https://github.com/finsilabs/awesome-ecommerce-skills)
- 原文件：`skills/infrastructure-performance/database-optimization-commerce/SKILL.md`
- 原始能力名：`database-optimization-commerce`
- 固定提交：`30a1fb674e41284e738608c059690c251699eb07`
- 原文件哈希：`182fd3ac7b16e0fd591a0d74e1d371faa31923548e0f7a448a8723c282529eae`
- 许可证：`MIT`，全文见 `LICENSE.md`
- 新对象：`private-community-team-performance-coaching`
- 中文名称：私域社群团队管理绩效反馈与辅导行动记录｜简诗 AI

本版本不是对上游名称的逐词翻译。它重新限定了中国业务对象、操作过程、证据要求、交付模板和国内示例，并保留上游来源、作者版权与许可证义务。任何真实发布、发送、付费、权限或生产操作仍需用户明确授权。
