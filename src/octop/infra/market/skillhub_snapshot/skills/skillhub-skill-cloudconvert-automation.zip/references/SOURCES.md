# 来源与授权说明

- 原始 Skill：`cloudconvert-automation`
- GitHub 来源：[ComposioHQ/awesome-claude-skills](https://github.com/ComposioHQ/awesome-claude-skills/tree/master/composio-skills/cloudconvert-automation)
- 固定分支：`master`
- 原始目录：`composio-skills/cloudconvert-automation`
- 本次下载日期：2026-07-29
- 授权状态：源 Skill 目录中未检测到许可证文件；在取得作者明确授权前，不建议商业再发布。

本文件用于 SkillHub Pay 发布审核。不得因为删除或隐藏许可证文件就推断获得再发布权。
