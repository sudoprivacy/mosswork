# z-init（软件工程项目文档初始化）

一句话：项目确认后，把早期想法的产物转成工程文档基线——目录、模板、编号、追踪一次到位，待确认处留槽不编造。系列终点与工程起点，通过文件契约（AGENTS.md）与任何下游阶段功能集松耦合。

## 何时使用

说"项目初始化、初始化项目文档、搭文档骨架、文档脚手架、立项后开工、建项目文档规范、按软件工程规范建文档"，或新仓库建好说"开工/搭文档"时触发。

## 用法速览

- 问法：「项目定了，按规范初始化项目文档」；纯模板：「搭文档骨架，需求后面补」
- 用法卡：聊天说 `z-init help`，ZCode 下 `/z-init-help` 直达
- 预期：一轮 4 问（名字定位/类型/档位/协作约定）；个人试用建议轻量档；建档后自查报告 + 收口交接说明

## 核心机制

- **Gate**：确认"已立项"才动手；还在犹豫→建议先 z-assess；无早期产物→"纯模板模式"只搭骨架并声明需求待补。
- **三档位**：轻量（个人/小团队，6 件）｜标准（常规团队，13 件）｜完整（对齐 GB/T 8567 全集，招投标/验收场景）。
- **SRS（29148 lite）**：1.1 项目宪章（3–5 条不可变红线，变更须对照）；需求表带 ID/优先级/验证方式；写不出验证方式的需求进开放问题，不硬塞。
- **种子化规则**：登记册→SRS 需求表（ID 继承续编）、评估报告→风险登记册与里程碑前置，每处标来源，无来源留空槽不编造。
- **接口契约（松耦合边界）**：建档生成 `AGENTS.md`——文件所有权表、SRS 单一事实源（下游 spec 文件为派生视图、可再生禁手改）、需求类改动唯一入口变更台账、管理类文档经确认直接更新；收口必出交接说明（SRS 第 3 章喂 spec 工具、改动走变更回流）。
- **需求管理四锚点**：唯一标识（R-xxx 永不复用）、基线（git tag 建议命令）、变更控制（需求类走台账，变更前对照宪章自查）、双向追踪（矩阵断链即评审问题）。

## 与 z-系列的关系

```
z-flow-kickoff（编排：开场协议→契约→横幅→交接→续跑）
   └─ z-pyramid(拆解) → z-clarify(澄清→登记册) ⇄ z-chain(生态/干系人事实)
                              ↓
                       z-assess(四维+风险+假设 → Go/No-Go)
                              ↓ Go
                       z-init(本 skill：文档基线化) → 下游 spec/开发（松耦合，AGENTS.md 契约）
```

上游产物全部留在 `docs/00-立项/` 作可追溯凭据（冻结只读）；本 skill 产出 `docs/01–05` 基线与 AGENTS.md 契约后交接给下游（spec-kit / Kiro / OpenSpec 等任选，只认文件契约）。基线后项目再入：变更走 `05-管理/变更/`（z-clarify/z-assess 承接），独立二期视作新立项重走全链。整链编排见 z-flow-kickoff；上游产物缺失时按"纯模板模式"退化。

## 安装

### ZCode（推荐：随系列整装，symlink 安装）

```bash
git clone https://github.com/zimy0033/z-skill-series.git ~/z-skill-series
bash ~/z-skill-series/install.sh
```

install.sh 把 `skills/*` 以 symlink 装入 `~/.zcode/skills/`（help 命令装入 `~/.zcode/commands/`）；更新只需 `git -C ~/z-skill-series pull`，无需重装。GitHub HTTPS 不稳时可改用 SSH。

### 单独安装（任一 agent）

把 `skills/z-init` 目录复制到目标 agent 的 skills 目录（ZCode 用户级 `~/.zcode/skills/`，项目级 `<项目>/.zcode/skills/`）。安装后重启会话生效。skills CLI 子路径安装已实测可用：`npx skills add zimy0033/z-skill-series/skills/z-init`。

## License

MIT
