#!/usr/bin/env python3
"""班级综测分整理助手：处理学院大表与班级小表之间的双向转换。"""
import argparse
import calendar
import json
import os
import re
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


# ===== 公共常量 =====
SCORE_TYPES = {"A", "C", "D"}
SEMESTER_START_MONTHS = {3, 9}  # 学期首月基础 10 分

# 学院大表固定列（出现在参考样例中的表头）
BIG_FIXED_COLS = ["姓名", "学号", "所在行政班级", "公寓楼", "寝室号", "床位号", "总分"]

# 班级小表模板结构
CLASS_TEMPLATE = {
    "title": "{semester}{month}月份{score_type}项积分综合测评汇总表",
    "headers": ["序号", "姓名", "基础分", "{score_type}项积分加减分明细", "{month}月{score_type}分", "{score_type}分累积", "签字"],
}

# 大表名单相关列
ROSTER_COLS = ["学号", "姓名", "所在行政班级", "公寓楼", "寝室号", "床位号"]


# ===== 班级名称解析 =====

def parse_class_name(name: str) -> dict:
    """解析班级名称为结构化字段，避免 S 班与普通班混淆。"""
    s = name.strip().upper().replace("（", "(").replace("）", ")")
    is_s = "(S)" in s or re.search(r"[-]?S\d+", s) is not None
    s_clean = s.replace("(S)", "").replace("S", "").replace("班", "").replace("-", "")
    m = re.search(r"(\d{4})(\d+)", s_clean)
    if not m:
        raise ValueError(f"无法解析班级名称：{name}")
    return {"major": "法学", "year": m.group(1), "num": m.group(2), "is_s": is_s}


def class_name_key(name: str) -> tuple:
    parsed = parse_class_name(name)
    return (parsed["year"], parsed["num"], parsed["is_s"])


def infer_class_name_in_big(small_class_name: str) -> list[str]:
    """根据班级小表标题，推导学院大表中可能的班级名称写法。"""
    parsed = parse_class_name(small_class_name)
    year, num, is_s = parsed["year"], parsed["num"], parsed["is_s"]
    if is_s:
        return [
            f"法学(S){year}-{num}班", f"法学{year}-S{num}班",
            f"法学{year}S{num}班", f"法学(S){year}-{num}", f"法学{year}-S{num}",
        ]
    return [
        f"法学{year}-{num}班", f"法学{year}{num}班",
        f"法学{year}-{num}", f"法学{year}{num}",
    ]


# ===== 学期 / 日期工具 =====

def get_semester_months(month: int) -> list[int]:
    """根据目标月份返回整个学期的月份列表。"""
    if month in (3, 4, 5, 6):
        return [3, 4, 5, 6]          # 上半年（第二学期）
    if month in (9, 10, 11, 12):
        return [9, 10, 11, 12]       # 下半年（第一学期）
    raise ValueError(f"月份 {month} 不在 3-6 或 9-12 范围内，无法确定学期。")


def get_semester_year(semester: str, month: int) -> int:
    """从学期名称推导月份对应的年份。"""
    m = re.search(r"(\d{4})-(\d{4})学年(第一|第二)学期", semester)
    if m:
        y1, y2 = int(m.group(1)), int(m.group(2))
        if m.group(3) == "第二":
            return y2   # 3-6 月用结束年
        return y1       # 9-12 月用起始年
    return datetime.now().year


def get_month_last_day(year: int, month: int) -> int:
    return calendar.monthrange(year, month)[1]


# ===== 学院大表读取 =====

def find_header_row(ws, max_rows=5):
    for r in range(1, min(ws.max_row, max_rows) + 1):
        row = [ws.cell(r, c).value for c in range(1, ws.max_column + 1)]
        if any(v is not None and str(v).strip() in BIG_FIXED_COLS for v in row):
            return r, row
    raise ValueError("无法识别学院大表表头，请检查前 5 行是否包含固定列名。")


def load_students_from_big(big_path: str, class_name: str):
    """从学院大表中提取指定班级的学生名单与活动明细。"""
    wb = load_workbook(big_path, data_only=True)
    ws = wb.active
    header_row, headers = find_header_row(ws)

    try:
        class_col = headers.index("所在行政班级") + 1
        name_col = headers.index("姓名") + 1
        total_col = headers.index("总分") + 1
    except ValueError as e:
        raise ValueError(f"学院大表缺少必要列：{e}")

    activity_cols = []
    for idx, h in enumerate(headers, start=1):
        if h is None:
            continue
        h_str = str(h).strip()
        if h_str not in BIG_FIXED_COLS:
            activity_cols.append((idx, h_str))

    target_key = class_name_key(class_name)
    students = []
    for r in range(header_row + 1, ws.max_row + 1):
        cell_class = ws.cell(r, class_col).value
        if cell_class is None:
            continue
        try:
            if class_name_key(str(cell_class)) != target_key:
                continue
        except ValueError:
            continue

        name = ws.cell(r, name_col).value
        if not name:
            continue

        details = []
        for c, col_name in activity_cols:
            v = ws.cell(r, c).value
            if v is None or v == "":
                continue
            try:
                score = float(v)
            except (ValueError, TypeError):
                continue
            if score == 0:
                continue
            prefix = "+" if score > 0 else ""
            details.append(f"{col_name}{prefix}{score:g}")

        total = ws.cell(r, total_col).value
        try:
            total = float(total) if total is not None else 0.0
        except (ValueError, TypeError):
            total = 0.0

        students.append({
            "name": str(name).strip(),
            "details": "、".join(details),
            "month_total": total,
        })

    return students


def get_base_score(score_type: str, month: int) -> int:
    if score_type == "A":
        return 10
    if score_type in {"C", "D"}:
        return 10 if month in SEMESTER_START_MONTHS else 0
    raise ValueError(f"不支持的分数类型：{score_type}")


def load_previous_totals(prev_path: str, score_type: str):
    """读取上月班级小表，返回 {姓名: 累积得分}。"""
    if not prev_path or not os.path.exists(prev_path):
        return {}
    wb = load_workbook(prev_path, data_only=True)
    sheet = wb[wb.sheetnames[0]] if prev_path.endswith((".xlsx", ".xlsm")) else wb.active
    header_row = name_col = acc_col = None
    for r in range(1, min(sheet.max_row, 5) + 1):
        for c in range(1, sheet.max_column + 1):
            v = sheet.cell(r, c).value
            if v is None:
                continue
            vs = str(v).strip()
            if vs == "姓名":
                header_row, name_col = r, c
            if vs == f"{score_type}分累积":
                acc_col = c
    if header_row is None or name_col is None or acc_col is None:
        return {}
    totals = {}
    for r in range(header_row + 1, sheet.max_row + 1):
        name = sheet.cell(r, name_col).value
        acc = sheet.cell(r, acc_col).value
        if not name:
            continue
        try:
            totals[str(name).strip()] = float(acc) if acc is not None else 0.0
        except (ValueError, TypeError):
            totals[str(name).strip()] = 0.0
    return totals


# ===== 模式1：副班长 —— 整学期小表 =====

def build_month_sheet(ws, students, class_name, score_type, month, semester,
                      year, prev_totals=None, fill_data=False):
    """生成一个月份的 sheet（当前月填数据，其他月留空模板）。"""
    base_score = get_base_score(score_type, month)
    last_day = get_month_last_day(year, month)

    title = CLASS_TEMPLATE["title"].format(semester=semester, month=month, score_type=score_type)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=7)
    ws.cell(1, 1, title)
    ws.cell(1, 1).font = Font(bold=True, size=14)
    ws.cell(1, 1).alignment = Alignment(horizontal="center", vertical="center")

    ws.cell(2, 1, "班级：")
    ws.cell(2, 2, class_name)
    ws.cell(2, 6, "日期：")
    ws.cell(2, 7, f"{year}.{month}.{last_day}")

    headers = [h.format(score_type=score_type, month=month) for h in CLASS_TEMPLATE["headers"]]
    for c, h in enumerate(headers, start=1):
        cell = ws.cell(3, c, h)
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9E1F2")
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for i, stu in enumerate(students, start=1):
        r = i + 3
        ws.cell(r, 1, i)
        ws.cell(r, 2, stu["name"])
        ws.cell(r, 3, base_score)
        if fill_data:
            month_total = base_score + stu.get("month_total", 0.0)
            prev = prev_totals.get(stu["name"], 0.0) if prev_totals else 0.0
            cumulative = prev + month_total
            ws.cell(r, 4, stu.get("details", ""))
            ws.cell(r, 5, month_total)
            ws.cell(r, 6, cumulative)
        else:
            ws.cell(r, 4, "")
            ws.cell(r, 5, "")
            ws.cell(r, 6, "")
        ws.cell(r, 7, "")
        for c in range(1, 8):
            ws.cell(r, c).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    sign_row = len(students) + 4
    ws.cell(sign_row, 1, "班级测评小组签字：")
    ws.cell(sign_row + 1, 1, "中队测评小组签字：")
    ws.cell(sign_row + 2, 1, "指导员签字：")

    ws.column_dimensions["A"].width = 8
    ws.column_dimensions["B"].width = 12
    ws.column_dimensions["C"].width = 10
    ws.column_dimensions["D"].width = 50
    ws.column_dimensions["E"].width = 12
    ws.column_dimensions["F"].width = 12
    ws.column_dimensions["G"].width = 12


def build_semester_workbook(students, class_name, score_type, current_month,
                            semester, prev_totals=None):
    """生成整学期多 sheet 工作簿。"""
    months = get_semester_months(current_month)
    year = get_semester_year(semester, current_month)
    wb = Workbook()
    wb.remove(wb.active)  # 删除默认空 sheet

    for m in months:
        ws = wb.create_sheet(title=f"{m}月")
        fill = (m == current_month)
        build_month_sheet(ws, students, class_name, score_type, m, semester, year,
                          prev_totals if fill else None, fill_data=fill)
    return wb


def mode_class_from_big(args):
    students = load_students_from_big(args.big_table, args.class_name)
    if not students:
        raise ValueError(f"在学院大表中未找到班级 {args.class_name} 的学生，请检查班级名称。")

    prev_totals = load_previous_totals(args.prev_month, args.score_type)
    wb = build_semester_workbook(
        students, args.class_name, args.score_type, args.month, args.semester, prev_totals
    )
    out = args.output or f"{args.class_name}_{args.score_type}分_{args.semester}.xlsx"
    wb.save(out)
    return out


# ===== 模式2：学院干部 =====

def sync_roster(ws, roster: list[dict], header_row: int, sync_delete: bool = False):
    """按新名单同步学院大表的学生（新增/更新/可选删除）。

    在原 worksheet 上直接修改（不保存），同步宿舍号、班级、学号、姓名等。
    返回改动说明列表。
    """
    headers = [ws.cell(header_row, c).value for c in range(1, ws.max_column + 1)]
    col_map = {str(h).strip(): i + 1 for i, h in enumerate(headers) if h is not None}
    id_col = col_map.get("学号")
    if id_col is None:
        raise ValueError("学院大表缺少『学号』列，无法同步名单。")

    existing = {}
    for r in range(header_row + 1, ws.max_row + 1):
        sid = ws.cell(r, id_col).value
        if sid is not None:
            existing[str(sid).strip()] = r

    new_ids = {str(s.get("学号", "")).strip() for s in roster}
    changes = []

    for stu in roster:
        sid = str(stu.get("学号", "")).strip()
        if not sid:
            continue
        if sid in existing:
            r = existing[sid]
            for field in ROSTER_COLS:
                if field in col_map and field in stu:
                    cell = ws.cell(r, col_map[field])
                    new_val = stu[field]
                    if str(cell.value).strip() != str(new_val).strip():
                        old = cell.value
                        cell.value = new_val
                        changes.append(f"更新 {sid} 的 {field}：{old} -> {new_val}")
        else:
            r = ws.max_row + 1
            for field in ROSTER_COLS:
                if field in col_map:
                    ws.cell(r, col_map[field], stu.get(field, ""))
            existing[sid] = r
            changes.append(f"新增学生 {sid} {stu.get('姓名', '')}")

    if sync_delete:
        for sid, r in list(existing.items()):
            if sid not in new_ids:
                ws.delete_rows(r, 1)
                changes.append(f"删除学生 {sid}")

    return changes


def fill_big_table(big_path: str, activities: list[dict], out_path: str, roster=None, sync_delete=False):
    """在学院大表中同步名单（可选）并新增活动/扣分列，按名单填入分数。"""
    wb = load_workbook(big_path)
    ws = wb.active
    header_row, headers = find_header_row(ws)

    if roster:
        changes = sync_roster(ws, roster, header_row, sync_delete)
        print("名单同步：")
        for ch in changes:
            print(f"  - {ch}")

    name_col = headers.index("姓名") + 1
    total_col = headers.index("总分") + 1

    first_activity_col = None
    for c in range(1, total_col):
        h = ws.cell(header_row, c).value
        if h is not None and str(h).strip() not in BIG_FIXED_COLS:
            first_activity_col = c
            break
    if first_activity_col is None:
        first_activity_col = total_col

    for act in reversed(activities):
        col_to_insert = total_col
        ws.insert_cols(col_to_insert)
        ws.cell(header_row, col_to_insert, act["name"])
        ws.cell(header_row, col_to_insert).font = Font(bold=True)
        ws.cell(header_row, col_to_insert).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        for r in range(header_row + 1, ws.max_row + 1):
            name = ws.cell(r, name_col).value
            if not name:
                continue
            score = act["scores"].get(str(name).strip())
            if score is not None:
                ws.cell(r, col_to_insert, score)

    new_total_col = total_col + len(activities)
    last_activity_col = new_total_col - 1
    for r in range(header_row + 1, ws.max_row + 1):
        ws.cell(r, new_total_col, f"=SUM({get_column_letter(first_activity_col)}{r}:{get_column_letter(last_activity_col)}{r})")

    wb.save(out_path)
    return out_path


def parse_activities_json(raw: str) -> list[dict]:
    data = json.loads(raw)
    if isinstance(data, dict):
        return [{"name": k, "scores": v} for k, v in data.items()]
    return data


def parse_roster_json(raw: str) -> list[dict]:
    return json.loads(raw)


def mode_fill_big(args):
    """学院干部模式：先同步名单（可选），再填入活动分数。"""
    roster = parse_roster_json(args.roster) if args.roster else None
    activities = parse_activities_json(args.activities)
    out = args.output or f"filled_{os.path.basename(args.big_table)}"
    return fill_big_table(args.big_table, activities, out, roster, args.sync_delete)


# ===== 模式3：学期汇总 =====

def semester_summary(month_files: list[str], score_type: str, out_path: str):
    months = []
    all_students = {}

    for path in month_files:
        wb = load_workbook(path, data_only=True)
        ws = wb[wb.sheetnames[0]]
        header_row = name_col = month_total_col = acc_col = month = None

        m = re.search(r"(\d{1,2})月", os.path.basename(path))
        if m:
            month = int(m.group(1))

        for r in range(1, min(ws.max_row, 5) + 1):
            for c in range(1, ws.max_column + 1):
                v = ws.cell(r, c).value
                if v is None:
                    continue
                vs = str(v).strip()
                if vs == "姓名":
                    header_row, name_col = r, c
                if re.match(rf"\d+月{score_type}分", vs):
                    month_total_col = c
                if vs == f"{score_type}分累积":
                    acc_col = c

        if header_row is None or name_col is None:
            print(f"跳过 {path}：未找到表头")
            continue

        for r in range(header_row + 1, ws.max_row + 1):
            name = ws.cell(r, name_col).value
            if not name:
                continue
            name = str(name).strip()
            month_total = ws.cell(r, month_total_col).value if month_total_col else None
            acc = ws.cell(r, acc_col).value if acc_col else None
            try:
                month_total = float(month_total) if month_total is not None else 0.0
            except (ValueError, TypeError):
                month_total = 0.0
            try:
                acc = float(acc) if acc is not None else 0.0
            except (ValueError, TypeError):
                acc = 0.0

            if name not in all_students:
                all_students[name] = {"months": {}}
            all_students[name]["months"][month] = {"month_total": month_total, "acc": acc}
            if month is not None:
                months.append(month)

    months = sorted(set(months))

    wb = Workbook()
    ws = wb.active
    ws.title = "学期汇总"
    headers = ["序号", "姓名"] + [f"{m}月得分" for m in months] + ["学期累计"]
    for c, h in enumerate(headers, start=1):
        cell = ws.cell(1, c, h)
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9E1F2")
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for i, (name, data) in enumerate(sorted(all_students.items()), start=1):
        r = i + 1
        ws.cell(r, 1, i)
        ws.cell(r, 2, name)
        final_acc = 0.0
        for idx, m in enumerate(months, start=3):
            val = data["months"].get(m, {}).get("month_total", 0.0)
            ws.cell(r, idx, val)
            acc = data["months"].get(m, {}).get("acc", 0.0)
            if acc:
                final_acc = acc
        ws.cell(r, len(months) + 3, final_acc)

    wb.save(out_path)
    return out_path


def mode_summary(args):
    out = args.output or f"学期{args.score_type}分汇总.xlsx"
    return semester_summary(args.month_files, args.score_type, out)


# ===== 命令行入口 =====

def main():
    parser = argparse.ArgumentParser(description="班级综测分整理助手")
    sub = parser.add_subparsers(dest="mode", required=True)

    p1 = sub.add_parser("class_from_big", help="副班长模式：生成整学期本班小表")
    p1.add_argument("--big-table", required=True, help="学院大表 xlsx 路径")
    p1.add_argument("--class-name", required=True, help="班级名称，如：法学2025-S3班")
    p1.add_argument("--score-type", required=True, choices=SCORE_TYPES, help="分数类型：A/C/D")
    p1.add_argument("--month", required=True, type=int, help="当前月份 1-12")
    p1.add_argument("--semester", default="2025-2026学年第二学期", help="学期名称")
    p1.add_argument("--prev-month", help="上月班级小表路径，用于计算累计分")
    p1.add_argument("--output", help="输出文件路径")

    p2 = sub.add_parser("fill_big", help="学院干部模式：同步名单并填入活动分数")
    p2.add_argument("--big-table", required=True, help="学院大表 xlsx 路径")
    p2.add_argument("--activities", required=True, help="活动数据 JSON 字符串")
    p2.add_argument("--roster", help="新名单 JSON 字符串（可选，用于同步）")
    p2.add_argument("--sync-delete", action="store_true", help="删除不在新名单中的学生")
    p2.add_argument("--output", help="输出文件路径")

    p3 = sub.add_parser("summary", help="学期汇总模式：合并各月班级小表")
    p3.add_argument("--month-files", nargs="+", required=True, help="各月班级小表路径")
    p3.add_argument("--score-type", required=True, choices=SCORE_TYPES, help="分数类型")
    p3.add_argument("--output", help="输出文件路径")

    args = parser.parse_args()

    if args.mode == "class_from_big":
        out = mode_class_from_big(args)
    elif args.mode == "fill_big":
        out = mode_fill_big(args)
    elif args.mode == "summary":
        out = mode_summary(args)
    else:
        raise ValueError(f"未知模式：{args.mode}")

    print(f"已生成：{out}")


if __name__ == "__main__":
    main()
