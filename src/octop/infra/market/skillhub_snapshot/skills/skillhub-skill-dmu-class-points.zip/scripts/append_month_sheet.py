# -*- coding: utf-8 -*-
"""
模式四：向已有班级小表追加一个月度 sheet（格式完全复用现有月份 sheet）。

典型场景：某两个月合并在一张学院大表里（如"6、7月"），需要往班级小表新增
一个同名 sheet，而不重新生成整份学期文件。

用法示例：
python append_month_sheet.py \
  --big-table "6、7月D分.xlsx" \
  --small "S3班D分评测表.xlsx" \
  --big-class "法学(S)2025-3班" \
  --sheet-name "6、7月" \
  --template-sheet "6月" \
  --prev-sheet "5月" \
  --title "2025-2026学年第二学期6、7月份D项积分综合测评汇总表" \
  --date "2026.7.31" \
  --score-col-name "6、7月D分" \
  --output "S3班D分评测表(含6、7月).xlsx"

约定：
- 大表结构：第1行表头，第1-6列为 姓名/班级/学号/公寓楼/寝室号/床位号，
  第7列起至倒数第2列为活动列，最后一列为"总计"（仅用于校验，得分自行求和）。
- 小表结构：第1行标题，第2行班级/日期，第3行表头
  （序号|姓名|基础分|明细|X月D分|D分累积|签字），第4-36行为学生，37-39行为签字行。
- 基础分：D/C 分仅在学期首月给 10 分，其余月份填 0；A 分每月 10 分（用 --base 指定）。
- 累积分 = 上月累积（--prev-sheet 的第6列）+ 本月得分。
- 原小表不会被覆盖。
"""
import argparse
import openpyxl
from openpyxl.styles import Alignment

ROW_START, ROW_END = 4, 36  # 学生行区间（含）


def read_big(path, sheet_name, big_class):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[sheet_name] if sheet_name else wb[wb.sheetnames[0]]
    header = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    acts = header[6:ws.max_column - 1]
    scores = {}
    for r in range(2, ws.max_row + 1):
        if str(ws.cell(r, 2).value or "").strip() != big_class:
            continue
        name = str(ws.cell(r, 1).value or "").strip()
        if not name:
            continue
        detail, total = [], 0.0
        for i, a in enumerate(acts):
            v = ws.cell(r, 7 + i).value
            if v in (None, "", 0):
                continue
            v = float(v)
            n = int(v) if v.is_integer() else round(v, 2)
            detail.append(f"{a}+{n}D")
            total += v
        total = round(total, 2)
        ref = ws.cell(r, ws.max_column).value  # 总计列，仅校验
        if ref not in (None, "") and abs(float(ref) - total) > 1e-9:
            print(f"[警告] {name}: 大表总计 {ref} ≠ 逐项求和 {total}")
        scores[name] = ("、".join(detail), total)
    return scores


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--big-table", required=True)
    ap.add_argument("--big-sheet", default=None, help="大表 sheet 名，默认第一个")
    ap.add_argument("--small", required=True, help="现有班级小表")
    ap.add_argument("--big-class", required=True, help="班级在大表中的写法，如 法学(S)2025-3班")
    ap.add_argument("--sheet-name", required=True, help="新建 sheet 名，如 6、7月")
    ap.add_argument("--template-sheet", required=True, help="作为格式模板的现有 sheet，如 6月")
    ap.add_argument("--prev-sheet", required=True, help="上月 sheet，用于取累积分")
    ap.add_argument("--title", required=True)
    ap.add_argument("--date", required=True, help="该月最后一天，如 2026.7.31")
    ap.add_argument("--score-col-name", required=True, help="第5列表头，如 6、7月D分")
    ap.add_argument("--base", type=float, default=0, help="基础分，D/C 非首月为 0")
    ap.add_argument("--drop-sheets", nargs="*", default=[],
                    help="新 sheet 生成后删除的旧月份 sheet，如：6月（合并月必填）")
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    scores = read_big(args.big_table, args.big_sheet, args.big_class)

    wb = openpyxl.load_workbook(args.small)
    new = wb.copy_worksheet(wb[args.template_sheet])
    new.title = args.sheet_name
    new["A1"] = args.title
    new["F2"] = "日期："
    new["G2"] = args.date
    new["E3"] = args.score_col_name
    new["E3"].alignment = Alignment(horizontal="center", vertical="center")  # 得分列表头居中

    ws_prev = wb[args.prev_sheet]
    prev_cum = {}
    for r in range(ROW_START, ROW_END + 1):
        n = str(ws_prev.cell(r, 2).value or "").strip()
        prev_cum[n] = ws_prev.cell(r, 6).value or 0

    missing = []
    for r in range(ROW_START, ROW_END + 1):
        name = str(new.cell(r, 2).value or "").strip()
        if not name:
            continue
        if name not in scores:
            missing.append(name)
            continue
        detail, total = scores[name]
        new.cell(r, 3).value = args.base
        new.cell(r, 4).value = detail or None
        new.cell(r, 5).value = total
        new.cell(r, 6).value = round(float(prev_cum.get(name, 0)) + total, 2)

    for s in args.drop_sheets:  # 合并月：删掉被并入的旧月份 sheet，避免重复计分
        if s in wb.sheetnames:
            wb.remove(wb[s])
            print("已删除旧 sheet:", s)

    wb.save(args.output)
    print("已保存:", args.output)
    print("sheets:", wb.sheetnames)
    print("本班匹配人数:", len(scores), "| 小表未匹配:", missing)


if __name__ == "__main__":
    main()
