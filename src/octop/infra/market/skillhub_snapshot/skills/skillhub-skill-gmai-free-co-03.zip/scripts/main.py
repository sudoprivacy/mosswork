# -*- coding: utf-8 -*-
"""SLA目标设定与测算实操清单（gmai-free-co-03）业务主脚本
免费技能：零费用，安装后可直接运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：SLA目标设定与测算实操方案与规格建议（含费用测算表与口径说明）；容量与水位测算表（现水位 / 目标水位 / 扩容触发线）；监控告警清单（指标 + 阈值 + 处置动作）
建议输入（专业字段）：系统与资源；资源范围；账号与授权
"""
import json, os, re, sys, time

SLUG = "gmai-free-co-03"
TITLE = "SLA目标设定与测算实操清单"
PRICE_FEN = 0
CATEGORY = "可观测性与站点可靠性"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['系统与资源', True, ['系统', '资源', '实例'], '决定规格与成本测算基础'], ['资源范围', True, ['范围', '计费项', '区域'], '范围决定费用与配额口径'], ['账号与授权', True, ['账号', '权限', '只读授权'], '无只读权限不得取用真实用量数据'], ['集群与版本', False, ['集群', '运行时', '版本'], '版本差异影响能力与限制'], ['配置与用量', False, ['配置', '用量', '水位'], '用于容量与成本反推'], ['已知故障', False, ['故障', '瓶颈', '告警'], '用于定位可用性薄弱环节']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'finds': [['生产环境管理端口对公网开放', '高', '安全组放行 0.0.0.0/0 的管理端口', '管理面暴露，凭据泄露即可被控制', '收敛来源 IP 或改走内网/跳板访问'], ['工作负载未设置资源请求与上限', '高', '容器未配置 requests/limits', '单容器可耗尽节点资源，影响同节点其他服务', '为全部工作负载设置 requests 与 limits'], ['实例规格与负载不匹配', '中', '峰值 CPU 利用率长期低于 15%', '资源闲置推高单位成本', '按 P95 利用率右尺寸或改用弹性伸缩'], ['缺少多可用区部署', '中', '关键服务单可用区运行', '单区故障将导致服务中断', '关键服务跨可用区部署'], ['存储未分层', '低', '冷数据仍使用高频访问存储类型', '存储成本偏高', '按访问频次分层并设置生命周期策略'], ['成本未按标签归集', '中', '资源缺少归属标签', '无法做成本归因与预算控制', '强制标签策略并出月度成本报表']], 'tools': "```bash\nkubectl get pods -A -o wide                     # 工作负载分布\nkubectl get deploy -A -o jsonpath='{..resources}'  # 资源请求与上限\nkubectl top nodes && kubectl top pods -A        # 实际资源占用\ntf state list                                   # 基础设施清单（如使用 IaC）\n```"}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['云资源成本口径：按计费项与计费周期取价（区分按量计费与包年包月）', '容量水位通行口径：稳态水位建议 ≤70%，扩容触发线按峰值余量设定', '可用性设计：多可用区部署、限流熔断与降级路径', '可观测性三支柱：指标（Metrics）、日志（Logs）、链路（Traces）', 'SLA 与错误预算（Error Budget）口径：以可用性目标反推可停机时长']
# 自检项（输入完备度）
CHECKS = [['SLA目标设定与测算实操·环境与规模核查', ['SLA目标设定与测算实操', 'SLA'], '先确认实例规格、副本数、流量量级与预算上限，缺项不报价'], ['SLA目标设定与测算实操·成本与容量口径', ['SLA', '告警可执行可关单'], '费用按真实计费项与计费周期口径测算，容量按水位（建议≤70%）反推'], ['SLA目标设定与测算实操·可用性与故障域', ['告警可执行可关单', '容量按水位反推扩容触发线'], '覆盖多可用区、限流熔断与降级路径，明确 SLA 目标与影响面'], ['SLA目标设定与测算实操·可观测性落地', ['SLA目标设定与测算实操', '目标设定与测算实操清单'], '给出监控指标、告警阈值与定位顺序，告警必须可执行、可关单'], ['SLA目标设定与测算实操·诚信红线', ['伪造监控数据', '隐瞒故障'], '不得伪造监控数据或隐瞒线上故障，命中即终止']]
# 交付物构成
DELIVERABLES = ['SLA目标设定与测算实操方案与规格建议（含费用测算表与口径说明）', '容量与水位测算表（现水位 / 目标水位 / 扩容触发线）', '监控告警清单（指标 + 阈值 + 处置动作）']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L


# ---------------- doc 范式：通用文书 / 表格 / 清单 ----------------

def _sec_scope(ctx):
    L = ["| 输入项 | 要求 | 本次情况 |", "|---|---|---|"]
    for name, req, al, why in FIELDS:
        v = ctx["fv"](name)
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选",
                                       brief(v, 60) or "待补充"))
    L.append("")
    L.append("> 上表为本次成稿的口径基础。标注「待补充」的项不作臆测，正文中以【待补充】标出。")
    return L


def _sec_frame(ctx):
    L = ["| 段落 | 内容要点 | 产出形态 |", "|---|---|---|"]
    nd = len(DELIVERABLES)
    for i, (item, kws, advice) in enumerate(CHECKS, 1):
        if nd == 0:
            d = TITLE
        elif i <= nd:
            d = DELIVERABLES[i - 1]
        else:
            d = "并入「%s」" % DELIVERABLES[0]
        L.append("| 第 %d 段 · %s | %s | %s |" % (i, item, brief(advice, 46), brief(d, 30)))
    return L


def _sec_draft(ctx):
    L = ["以下为按本技能交付段落生成的成稿骨架。每段给出：**本段依据（取自你的输入）→ 撰写要点"
         "（本域专业口径）→ 自查关键词（交付前逐项核对）**；红线段落只标注禁止情形。", ""]
    for i, (item, kws, advice) in enumerate(CHECKS, 1):
        L.append("**%d. %s**" % (i, item))
        if "命中即终止" in advice:
            L.append("- 红线：%s" % advice)
            L.append("- 处理：命中不得变通承接，直接终止并说明理由。")
            L.append("")
            continue
        fn = FIELDS[(i - 1) % len(FIELDS)] if FIELDS else ("材料", True, [], "材料缺失")
        v = ctx["fv"](fn[0])
        L.append("- 本段依据：%s → %s" % (fn[0], brief(v, 70) or "【待补充：%s】" % fn[3]))
        L.append("- 撰写要点：%s" % advice)
        L.append("- 自查关键词：%s" % "、".join(kws[:3]))
        L.append("")
    return L


def _sec_basis(ctx):
    L = ["| 段落 | 依据来源（本域锚点） |", "|---|---|"]
    for i, (item, kws, advice) in enumerate(CHECKS, 1):
        a = ANCHORS[(i - 1) % len(ANCHORS)] if ANCHORS else "—"
        L.append("| 第 %d 段 · %s | %s |" % (i, item, a))
    return L


def _sec_deliver(ctx):
    L = []
    for d in DELIVERABLES:
        L.append("- 交付物：%s" % d)
    L.append("")
    L.append("- 留痕口径：保留输入原始材料、本报告与定稿版本号；变更须记说明，便于复现与回滚。")
    L.append("- 复用口径：替换【】内字段即可复用于同类场景；单位、时间窗或口径版本变更时，"
             "须重新核对本报告「四、口径与依据对照」。")
    return L


def _sec_finds(ctx):
    P = ctx["spec"]["params"] or {}
    fs = P.get("finds") or []
    if not fs:
        return []
    L = ["| 问题 | 等级 | 证据要点 | 影响 | 改进动作 |", "|---|---|---|---|---|"]
    for r in fs[:8]:
        L.append("| " + " | ".join(str(x) for x in list(r)[:5]) + " |")
    return L


def sections(ctx):
    """通用文书交付物：口径确认 → 结构骨架 → 成品正文 → 依据对照 → 交付留痕"""
    L = [
        ("一、需求与口径确认", _sec_scope(ctx)),
        ("二、交付结构骨架", _sec_frame(ctx)),
        ("三、成稿骨架与撰写口径", _sec_draft(ctx)),
        ("四、口径与依据对照", _sec_basis(ctx)),
    ]
    f = _sec_finds(ctx)
    if f:
        L.append(("五、本域常见问题与对策", f))
        L.append(("六、交付与留痕", _sec_deliver(ctx)))
    else:
        L.append(("五、交付与留痕", _sec_deliver(ctx)))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：免费（Free Skill · 零费用）",
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
