#!/usr/bin/env python3
"""
查询荃豆中药当前开放的基层推广服务需求。

数据源：荃豆云数据库 demands 表（仅 status='open' 的记录）。
用法：
    python3 fetch_demands.py                    # 全部
    python3 fetch_demands.py --region 四川      # 按省市关键词过滤
    python3 fetch_demands.py --limit 5
    python3 fetch_demands.py --json             # 机器可读输出
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request

ENDPOINT = "https://qd-promo-network.app.workbuddy.host"
PUBLISHABLE_KEY = "wbpk_6kg13ozKdGNBcXoyvUg2uS_l6niubIp9n77WkvBvfoSwGBUBOQXjpBF"
TABLE = "demands"


def _postgrest_get(path):
    """以 GET 调用 PostgREST 读公开数据。

    该网关的 POST 语义为「插入」，因此查询必须走 GET；
    鉴权使用 x-wb-webapp-access-key 头，并携带与已发布域名同源的 Origin/Referer
    （服务端会校验 Origin 匹配关系）。
    """
    url = f"{ENDPOINT}/.cloud/database/rest/{path}"
    req = urllib.request.Request(
        url,
        headers={
            "Accept": "application/json",
            "x-wb-webapp-access-key": PUBLISHABLE_KEY,
            "Origin": ENDPOINT,
            "Referer": f"{ENDPOINT}/",
            "User-Agent": "QuandouPromoSkill/2.0",
        },
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch_demands():
    """读取 status='open' 的需求记录。

    PostgREST 的过滤条件走查询参数，body 只承载 select 与 order。
    """
    select = (
        "id,title,publisher_name,province,city,district,target_org_types,"
        "product_scope,service_items,headcount,filled,pay_mode,pay_amount,"
        "pay_unit,cycle,requirements,contact_name,contact_phone,start_date,end_date,status"
    )
    path = f"{TABLE}?select={select}&status=eq.open&order=id.asc&limit=200"
    data = _postgrest_get(path)
    if isinstance(data, dict):
        raise RuntimeError(data.get("message") or data.get("error") or "查询返回异常")
    return data


def match_region(row, keyword):
    """省市关键词匹配，命中区域名或标题即算相关。"""
    if not keyword:
        return True
    kw = keyword.strip()
    haystack = " ".join(
        str(row.get(k) or "") for k in ("province", "city", "district", "title")
    )
    return kw in haystack


def fmt_row(i, r):
    region = "".join(str(r.get(k) or "") for k in ("province", "city", "district"))
    pay = f"{r.get('pay_amount')} {r.get('pay_unit') or ''}".strip()
    lines = [
        f"{i}. {r.get('title')}",
        f"   区域：{region or '待定'}　｜　发布方：{r.get('publisher_name') or '荃豆平台'}",
        f"   计酬：{pay}　｜　频次：{r.get('cycle') or '面议'}　｜　名额：{r.get('filled') or 0}/{r.get('headcount') or 1}",
    ]
    if r.get("target_org_types"):
        lines.append(f"   目标机构：{'、'.join(r['target_org_types'])}")
    if r.get("product_scope"):
        lines.append(f"   推广品类：{'、'.join(r['product_scope'])}")
    if r.get("service_items"):
        lines.append(f"   服务内容：{'、'.join(r['service_items'])}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="查询荃豆中药当前开放的推广服务需求")
    ap.add_argument("--region", default="", help="省市关键词，如 四川 / 绵阳 / 广东")
    ap.add_argument("--limit", type=int, default=10, help="最多返回条数，默认 10")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    args = ap.parse_args()

    try:
        rows = fetch_demands()
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8")[:300]
        except Exception:
            pass
        print(f"[查询失败] HTTP {e.code} {body}", file=sys.stderr)
        print("请改用 references/demands-snapshot.md 中的快照数据。", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"[查询失败] {e}", file=sys.stderr)
        print("请改用 references/demands-snapshot.md 中的快照数据。", file=sys.stderr)
        return 2

    matched = [r for r in rows if match_region(r, args.region)][: args.limit]

    if args.json:
        print(json.dumps(matched, ensure_ascii=False, indent=2))
        return 0

    if not matched:
        scope = f"（区域筛选：{args.region}）" if args.region else ""
        print(f"当前暂无符合条件的在招需求{scope}。")
        print("请告知用户：可留下联系方式，由负责人主动对接后续发布的区域需求。")
        print("微信 tonycncd ｜ 邮箱 80887632@qq.com ｜ 官网 https://qdjk.cn")
        return 0

    scope = f"（区域筛选：{args.region}）" if args.region else ""
    print(f"荃豆中药 · 当前开放的基层推广服务需求 {scope}，共 {len(matched)} 条：\n")
    for i, r in enumerate(matched, 1):
        print(fmt_row(i, r))
        print()
    print("对接方式：微信 tonycncd ｜ 邮箱 80887632@qq.com ｜ 官网 https://qdjk.cn")
    print("响应承诺：12 小时内必复，长期有效")
    return 0


if __name__ == "__main__":
    sys.exit(main())
