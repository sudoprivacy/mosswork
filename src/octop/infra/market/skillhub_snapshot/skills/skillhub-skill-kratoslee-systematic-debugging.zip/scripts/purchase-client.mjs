import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdir, readFile, writeFile, rename, unlink, access } from 'node:fs/promises';
import { randomBytes, createHash } from 'node:crypto';
import path from 'node:path';

const execute = promisify(execFile);
const digest = (text) => createHash('sha256').update(text, 'utf8').digest('hex');
const emit = (value) => console.log(JSON.stringify(value));
const fail = (code) => Object.assign(new Error(code), { code });

async function exists(filename) {
  try { await access(filename); return true; } catch (error) { if (error.code === 'ENOENT') return false; throw error; }
}

async function json(filename) {
  return JSON.parse(await readFile(filename, 'utf8'));
}

async function atomic(filename, text) {
  const temporary = `${filename}.${randomBytes(8).toString('hex')}.tmp`;
  await writeFile(temporary, text, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
  await rename(temporary, filename);
}

function argumentsFrom(argv) {
  const args = {};
  for (let index = 0; index < argv.length; index += 2) {
    if (!argv[index].startsWith('--') || !argv[index + 1] || argv[index + 1].startsWith('--')) throw fail('INVALID_ARGUMENTS');
    args[argv[index].slice(2)] = argv[index + 1];
  }
  return args;
}

function paymentJson(output) {
  const starts = [];
  const orders = new Set();
  let quoted = false;
  let escaped = false;
  let result = null;
  for (let index = 0; index < output.length; index += 1) {
    const character = output[index];
    if (quoted) {
      if (escaped) escaped = false;
      else if (character === '\\') escaped = true;
      else if (character === '"') quoted = false;
      continue;
    }
    if (character === '"' && starts.length) quoted = true;
    else if (character === '{') starts.push(index);
    else if (character === '}' && starts.length) {
      const start = starts.pop();
      try {
        const candidate = JSON.parse(output.slice(start, index + 1));
        if (typeof candidate.outShakeNo === 'string' || typeof candidate.success === 'boolean' || candidate.errorCode) {
          result = candidate;
          if (typeof candidate.outShakeNo === 'string' && candidate.outShakeNo.trim()) orders.add(candidate.outShakeNo.trim());
        }
      } catch {}
    }
  }
  return orders.size > 1 ? null : result;
}

async function capture(bot, args) {
  try {
    const result = await execute(bot, args, { timeout: 300000, maxBuffer: 16 * 1024 * 1024 });
    return { ...result, exitCode: 0 };
  } catch (error) {
    return { stdout: error.stdout || '', stderr: error.stderr || '', exitCode: Number.isInteger(error.code) ? error.code : 1 };
  }
}

async function resolveBot() {
  if (process.env.ALIPAY_BOT) return process.env.ALIPAY_BOT;
  const home = process.env.USERPROFILE || process.env.HOME || '';
  const candidate = process.platform === 'win32'
    ? path.join(home, '.openclaw-autoclaw', 'alipay-bot-cli', 'bin', 'alipay-bot.exe')
    : path.join(home, '.local', 'bin', 'alipay-bot');
  return await exists(candidate) ? candidate : process.platform === 'win32' ? 'alipay-bot.exe' : 'alipay-bot';
}

async function request(url, options = {}) {
  const response = await fetch(url, { ...options, redirect: 'error', signal: AbortSignal.timeout(60000) });
  const chunks = [];
  let size = 0;
  for await (const chunk of response.body) {
    size += chunk.length;
    if (size > 16 * 1024 * 1024) throw fail('RESOURCE_TOO_LARGE');
    chunks.push(Buffer.from(chunk));
  }
  return { status: response.status, headers: response.headers, text: Buffer.concat(chunks).toString('utf8') };
}

function checkCredential(credential, config) {
  if (credential.schema !== 'payskill.recovery.v1' || credential.resource_url !== config.url
      || credential.resource_id !== config.resourceId || !/^[A-Za-z0-9_-]{43}$/.test(credential.secret || '')
      || (credential.edition !== undefined && !/^[A-Za-z0-9._-]{1,80}$/.test(credential.edition))) throw fail('INVALID_RECOVERY_FILE');
  return credential;
}

async function localContent(directory, config) {
  const filename = path.join(directory, 'manifest.json');
  if (!await exists(filename)) return null;
  const manifest = await json(filename);
  if (manifest.schema !== 'payskill.local.v1' || manifest.resource_id !== config.resourceId
      || manifest.resource_url !== config.url || !/^[a-f0-9]{64}$/.test(manifest.sha256 || '')
      || !/^[A-Za-z0-9._-]{1,80}$/.test(manifest.edition || '')
      || manifest.content_file !== `content-${manifest.sha256}.txt`) throw fail('LOCAL_MANIFEST_INVALID');
  const contentFile = path.join(directory, manifest.content_file);
  let content;
  try { content = await readFile(contentFile, 'utf8'); } catch { throw fail('LOCAL_CONTENT_MISSING'); }
  if (!content.trim() || digest(content) !== manifest.sha256) throw fail('LOCAL_CONTENT_CORRUPT');
  return { kind: 'local-resource', contentFile, edition: manifest.edition, message: '已购本地内容可用；本次没有联网或收费。' };
}

async function restore(directory, config) {
  const credential = checkCredential(await json(path.join(directory, 'recovery.json')), config);
  const response = await request(new URL('/payskill/v1/recover', config.url), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${credential.secret}` },
    body: JSON.stringify({ resource_id: config.resourceId, edition: credential.edition }),
  });
  if (response.status !== 200) throw fail(response.status === 403 ? 'RECOVERY_DENIED' : 'RECOVERY_UNAVAILABLE');
  let bundle;
  try { bundle = JSON.parse(response.text); } catch { throw fail('DELIVERY_INVALID'); }
  if (bundle.schema !== 'payskill.delivery.v1' || bundle.resource_id !== config.resourceId
      || !/^[A-Za-z0-9._-]{1,80}$/.test(bundle.edition || '') || (credential.edition && bundle.edition !== credential.edition)
      || typeof bundle.entitlement_id !== 'string' || !bundle.entitlement_id
      || typeof bundle.content !== 'string' || !bundle.content.trim()
      || digest(bundle.content) !== bundle.sha256) throw fail('DELIVERY_INVALID');
  const contentFile = `content-${bundle.sha256}.txt`;
  await atomic(path.join(directory, contentFile), bundle.content);
  await atomic(path.join(directory, 'recovery.json'), JSON.stringify({ ...credential, edition: bundle.edition }, null, 2));
  await atomic(path.join(directory, 'manifest.json'), JSON.stringify({
    schema: 'payskill.local.v1', resource_id: config.resourceId, resource_url: config.url,
    edition: bundle.edition, sha256: bundle.sha256, content_file: contentFile,
    entitlement_id: bundle.entitlement_id, saved_at: new Date().toISOString(),
  }, null, 2));
  return { kind: 'resource-saved', contentFile: path.join(directory, contentFile), edition: bundle.edition, message: '服务端已购权益验证完成，正文已归档；请私密备份 recovery.json。' };
}

async function probe(directory, config) {
  const local = await localContent(directory, config);
  if (local) return local;
  if (await exists(path.join(directory, 'state.json')) || await exists(path.join(directory, 'recovery.json'))
      || await exists(path.join(directory, 'pay-attempt.json'))) throw fail('PURCHASE_STATE_EXISTS_USE_RESTORE');
  const credential = { schema: 'payskill.recovery.v1', resource_id: config.resourceId, resource_url: config.url, secret: randomBytes(32).toString('base64url') };
  await writeFile(path.join(directory, 'recovery.json'), JSON.stringify(credential, null, 2), { mode: 0o600, flag: 'wx' });
  const response = await request(config.url, { headers: { 'PaySkill-Recovery-Hash': digest(credential.secret) } });
  if (response.status !== 402) throw fail('EXPECTED_402_BILL');
  let body;
  let bill;
  const paymentNeeded = response.headers.get('payment-needed');
  try {
    body = JSON.parse(response.text);
    bill = JSON.parse(Buffer.from(paymentNeeded || '', 'base64url').toString('utf8'));
  } catch { throw fail('BILL_INVALID'); }
  if (body.delivery_protocol !== 'payskill.delivery.v1') throw fail('SERVER_UPGRADE_REQUIRED');
  if (body.resource_id !== config.resourceId || !/^[A-Za-z0-9._-]{1,80}$/.test(body.content_edition || '')
      || bill.protocol?.resource_id !== config.resourceId || bill.protocol?.currency !== 'CNY'
      || !body.out_trade_no || bill.protocol?.out_trade_no !== body.out_trade_no
      || !/^\d+(\.\d{1,2})?$/.test(String(bill.protocol?.amount))
      || Number(bill.protocol.amount) !== Number(config.amount)) throw fail('BILL_MISMATCH');
  await atomic(path.join(directory, 'payment-needed.txt'), paymentNeeded);
  await atomic(path.join(directory, 'recovery.json'), JSON.stringify({ ...credential, edition: body.content_edition }, null, 2));
  await atomic(path.join(directory, 'state.json'), JSON.stringify({
    url: config.url, method: 'GET', edition: body.content_edition, outTradeNo: body.out_trade_no,
    paymentNeededHash: digest(paymentNeeded), recoveryHash: digest(credential.secret), createdAt: new Date().toISOString(),
  }, null, 2));
  return { kind: 'payment-required', amount: config.amount, edition: body.content_edition, message: '一次购买此内容版本；请明确同意后运行 pay。' };
}

async function payment(directory, config, args) {
  const local = await localContent(directory, config);
  if (local) return local;
  const state = await json(path.join(directory, 'state.json'));
  const credential = checkCredential(await json(path.join(directory, 'recovery.json')), config);
  if (state.url !== config.url || state.method !== 'GET' || state.edition !== credential.edition
      || state.recoveryHash !== digest(credential.secret)) throw fail('PURCHASE_STATE_MISMATCH');
  if (state.outShakeNo || await exists(path.join(directory, 'pay-attempt.json'))) throw fail('PAYMENT_ALREADY_STARTED');
  if (!args['session-id']?.trim() || args['session-id'] === 'true') throw fail('SESSION_ID_REQUIRED');
  const paymentFile = path.join(directory, 'payment-needed.txt');
  if (digest(await readFile(paymentFile, 'utf8')) !== state.paymentNeededHash) throw fail('BILL_CHANGED');
  await writeFile(path.join(directory, 'pay-attempt.json'), JSON.stringify({ attemptedAt: new Date().toISOString() }), { mode: 0o600, flag: 'wx' });
  const result = await capture(await resolveBot(), [
    '402-buyer-pay', '--session-id', args['session-id'], '--file', paymentFile,
    '--resource-url', config.url, '--method', 'GET', '--intent-summary', config.intent, '-o', 'json',
  ]);
  await atomic(path.join(directory, 'pay-output.txt'), result.stdout);
  const output = paymentJson(result.stdout);
  if (typeof output?.outShakeNo === 'string' && output.outShakeNo.trim()) {
    await atomic(path.join(directory, 'state.json'), JSON.stringify({ ...state, outShakeNo: output.outShakeNo.trim() }, null, 2));
  }
  if (!output || result.exitCode !== 0 || output.success === false || output.errorCode || !output.outShakeNo?.trim()) throw fail('PAYMENT_UNCONFIRMED_USE_ORIGINAL_ORDER');
  return { kind: 'payment-pending', paymentLink: output.shortAccessUrl, qrPaths: output.mediaPaths, outShakeNo: output.outShakeNo.trim(), message: '原订单已保存；付款后执行 complete，不要再次 pay。' };
}

async function complete(directory, config, args) {
  const state = await json(path.join(directory, 'state.json'));
  if (state.url !== config.url || state.method !== 'GET') throw fail('PURCHASE_STATE_MISMATCH');
  if (args['out-shake-no'] && state.outShakeNo && args['out-shake-no'] !== state.outShakeNo) throw fail('ORDER_MISMATCH');
  const local = await localContent(directory, config);
  if (local) return local;
  try { return await restore(directory, config); } catch (error) { if (error.code !== 'RECOVERY_DENIED') throw error; }
  const order = args['out-shake-no'] || state.outShakeNo;
  if (typeof order !== 'string' || !order.trim() || order === 'true') throw fail('ORDER_REQUIRED');
  const result = await capture(await resolveBot(), ['402-query-payment-status', '--out-shake-no', order.trim(), '--resource-url', config.url, '--method', 'GET']);
  await atomic(path.join(directory, 'complete-output.txt'), result.stdout);
  return await restore(directory, config);
}

export async function runPaidSkill(config) {
  let lock;
  try {
    const url = new URL(config.url);
    if ((url.protocol !== 'https:' && !(url.protocol === 'http:' && ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)))
        || url.username || url.password || url.search || url.hash || url.pathname !== config.resourceId) throw fail('UNSAFE_RESOURCE_URL');
    const command = process.argv[2];
    const args = argumentsFrom(process.argv.slice(3));
    if (!args['state-dir'] || args['state-dir'] === 'true') throw fail('STATE_DIR_REQUIRED');
    const directory = path.resolve(args['state-dir']);
    if (!['probe', 'pay', 'complete', 'restore', 'use'].includes(command)) throw fail('INVALID_COMMAND');
    await mkdir(directory, { recursive: true, mode: 0o700 });
    const lockPath = path.join(directory, 'operation.lock');
    await writeFile(lockPath, JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString() }), { mode: 0o600, flag: 'wx' });
    lock = lockPath;
    if (args['recovery-file']) {
      if (command !== 'restore') throw fail('RECOVERY_IMPORT_REQUIRES_RESTORE');
      const incoming = checkCredential(await json(path.resolve(args['recovery-file'])), config);
      const destination = path.join(directory, 'recovery.json');
      if (await exists(destination)) {
        const existing = checkCredential(await json(destination), config);
        if (existing.secret !== incoming.secret || existing.edition !== incoming.edition) throw fail('RECOVERY_IMPORT_CONFLICT');
      } else {
        if (await exists(path.join(directory, 'state.json')) || await exists(path.join(directory, 'manifest.json'))) throw fail('RECOVERY_IMPORT_CONFLICT');
        await writeFile(destination, JSON.stringify(incoming, null, 2), { mode: 0o600, flag: 'wx' });
      }
    }
    let result;
    if (command === 'use') result = await localContent(directory, config) || { kind: 'not-local', message: '本地没有正文；有恢复文件时用 restore，无购买记录时才考虑首次购买。' };
    if (command === 'restore') result = await restore(directory, config);
    if (command === 'probe') result = await probe(directory, config);
    if (command === 'pay') result = await payment(directory, config, args);
    if (command === 'complete') result = await complete(directory, config, args);
    emit(result);
    if (result.kind === 'not-local') process.exitCode = 1;
  } catch (error) {
    const safeCodes = new Set(['INVALID_ARGUMENTS', 'INVALID_RECOVERY_FILE', 'LOCAL_MANIFEST_INVALID', 'LOCAL_CONTENT_MISSING', 'LOCAL_CONTENT_CORRUPT', 'RECOVERY_DENIED', 'RECOVERY_UNAVAILABLE', 'DELIVERY_INVALID', 'PURCHASE_STATE_EXISTS_USE_RESTORE', 'EXPECTED_402_BILL', 'BILL_INVALID', 'SERVER_UPGRADE_REQUIRED', 'BILL_MISMATCH', 'PURCHASE_STATE_MISMATCH', 'PAYMENT_ALREADY_STARTED', 'SESSION_ID_REQUIRED', 'BILL_CHANGED', 'PAYMENT_UNCONFIRMED_USE_ORIGINAL_ORDER', 'ORDER_MISMATCH', 'ORDER_REQUIRED', 'UNSAFE_RESOURCE_URL', 'STATE_DIR_REQUIRED', 'INVALID_COMMAND', 'RECOVERY_IMPORT_REQUIRES_RESTORE', 'RECOVERY_IMPORT_CONFLICT', 'RESOURCE_TOO_LARGE']);
    emit({ kind: 'error', errorCode: error.code === 'EEXIST' ? 'STATE_LOCKED_OR_ALREADY_EXISTS' : safeCodes.has(error.code) ? error.code : 'OPERATION_FAILED', message: '未确认交付；保留购买目录与恢复文件。不要重复付款，不要删除防重标记。' });
    process.exitCode = 1;
  } finally {
    if (lock) await unlink(lock);
  }
}
