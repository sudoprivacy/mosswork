#!/usr/bin/env node
import { runPaidSkill } from './purchase-client.mjs';

await runPaidSkill({
  url: process.env.PAYSKILL_RESOURCE_URL || 'https://kratoslee.cn/skill/systematic-debugging',
  resourceId: '/skill/systematic-debugging',
  amount: '29.90',
  intent: '一次购买当前版本知识库，本地持续复用',
});
