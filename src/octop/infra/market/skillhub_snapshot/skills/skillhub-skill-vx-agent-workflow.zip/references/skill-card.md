## Description: <br>
Token-efficient command execution patterns for AI agents using vx-managed tools to filter verbose build, test, lint, GitHub, and shell command output across platforms. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[loonghao](https://clawhub.ai/user/loonghao) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and AI agents use this skill to keep command output concise while running builds, tests, linting, GitHub operations, and other verbose development workflows. It provides cross-platform vx command patterns for filtering output, selecting structured fields, and tracking token savings. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Security review flagged a bundled helper in the release for launching nested review tooling with broad filesystem authority and approval bypass behavior. <br>
Mitigation: Review the skill before installing, use it only in trusted local checkouts, and prefer no-bypass or no-yolo execution settings where available. <br>
Risk: Aggressive command-output filtering can hide diagnostic context or command failures from the agent. <br>
Mitigation: Start with compact filters, save full command output for failure recovery, and expand from summaries to contextual logs when filtered output is insufficient. <br>


## Reference(s): <br>
- [ClawHub listing: Vx Agent Workflow](https://clawhub.ai/loonghao/vx-agent-workflow) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration] <br>
**Output Format:** [Markdown guidance with inline shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Cross-platform command filters, structured-output recipes, and token-saving patterns for verbose development workflows.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
