# 错题本更新 Prompt

> 每次对话结束后，自动更新用户的错题本
> 错题本是 AI 决定下次案例和重点的依据

## 数据结构

```json
{
  "user_id": "user-001",
  "created_at": "2026-09-01",
  "updated_at": "2026-09-02",
  "total_sessions": 8,
  "total_minutes": 360,
  "weak_points": {
    "wp-1_倾听不足": {
      "count": 2,
      "last_triggered": "2026-08-25",
      "severity": "mild",
      "trend": "decreasing",
      "examples": [
        {
          "session_id": "session-002",
          "case_id": "case-1",
          "quote": "咨询师打断来访者 3 次",
          "context": "来访者说妈妈期望时被打断"
        }
      ],
      "drill_completed": 1
    },
    "wp-2_共情不足": {
      "count": 4,
      "last_triggered": "2026-09-01",
      "severity": "moderate",
      "trend": "stable",
      "examples": [
        {
          "session_id": "session-005",
          "case_id": "case-15",
          "quote": "你说'我理解'但没命名情绪",
          "context": "来访者哭的时候"
        }
      ],
      "drill_completed": 0
    },
    "wp-3_开放式提问不足": {
      "count": 6,
      "last_triggered": "2026-09-02",
      "severity": "high",
      "trend": "increasing",
      "examples": [
        {
          "session_id": "session-008",
          "case_id": "case-8",
          "quote": "连续 5 个封闭式问题",
          "context": "探索闺蜜背叛事件时"
        }
      ],
      "drill_completed": 0
    }
  },
  "strong_points": {
    "sp-1_边界清晰": "100% 维持专业关系",
    "sp-2_不评判": "零价值判断"
  },
  "current_priority_weak_points": ["wp-3", "wp-2"],
  "next_drill_focus": "wp-3 开放式提问",
  "next_drill_recommendation": "case-3 儿童案例 + case-15 妈妈案例"
}
```

## 趋势判断算法

```
severity 升级条件：
- count 5+: moderate
- count 10+: high
- last_triggered 7 天内: active
- count 5+ 且 last_triggered 7 天内: critical

trend 判断：
- increasing: 最近 3 次出现次数 > 之前 3 次
- decreasing: 最近 3 次 < 之前 3 次
- stable: 持平
```

## 错题本如何影响下次练习

### 1. AI 来访者自动调整
- wp-3 突出 → AI 来访者会故意"测"封闭性问题
- wp-2 突出 → AI 来访者会用更多情绪化语言
- wp-4 突出 → AI 来访者会故意问"你说我该怎么办"

### 2. 推荐案例
- wp-3 突出 → 推荐开放式提问密集的案例（儿童、社交焦虑）
- wp-2 突出 → 推荐情绪化重的案例（创伤、丧亲）
- wp-4 突出 → 推荐易引诱咨询师给建议的案例（婚姻、育儿）

### 3. 微练习生成
- wp-3 → 5 道"封闭式转开放式"练习
- wp-2 → 5 道"命名情绪"练习
- wp-4 → 5 道"何时给建议 vs 不给"判断题

## 错题本展示给用户

### 仪表盘视图

```
📊 你的错题本

最弱 3 项：
1. 开放式提问不足（6 次/8 次练习）⬆️
2. 共情不足（4 次/8 次）→
3. 过度给建议（2 次/8 次）⬇️

最强 3 项：
1. 边界清晰（0 次违反）
2. 不评判（0 次价值判断）
3. 危机识别（无漏掉）

推荐练习：
- 5 道开放式提问转换题
- 案例 3（6 岁女孩）
- 案例 15（38 岁妈妈）
```

## 错题本与主规划的对应

错误模式与心略 SMILE 5 因子映射：
- wp-1 倾听不足 → 反映 I（认知/理解）短板
- wp-2 共情不足 → 反映 M（心力/共情能力）
- wp-3 提问不足 → 反映 L（方法/技能）短板
- wp-4 过早建议 → 反映 L（方法不当）
- wp-5 价值判断 → 反映 E（环境/咨询师个人）
- wp-6 边界 → 反映伦理遵守
- wp-7 伦理 → 反映专业知识
- wp-8 危机 → 反映专业判断

错题本是咨询师的"个人 SMILE 画像"——通过练习识别短板。
