## Description: <br>
Poyo Wan 2 5 helps agents prepare and submit PoYo Wan 2.5 text-to-video and image-to-video generation jobs through the PoYo API. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to create PoYo Wan 2.5 video-generation payloads, choose text-to-video or image-to-video parameters, and submit or explain asynchronous task follow-up when the user requests it. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: PoYo API keys can be exposed if copied into browser code, public repositories, logs, screenshots, or chat output. <br>
Mitigation: Keep POYO_API_KEY in a server-side environment or secret manager and avoid printing or logging it. <br>
Risk: Prompts, private image URLs, callback URLs, and generated media URLs may contain sensitive information sent to PoYo or callback receivers. <br>
Mitigation: Review payload JSON before submission and avoid sending sensitive values unless the user accepts PoYo's handling of that data. <br>
Risk: Submitting a prepared payload creates an external asynchronous video-generation task. <br>
Mitigation: Make live API calls only after an explicit user request from a trusted server-side shell, then report the returned task_id for controlled follow-up. <br>


## Reference(s): <br>
- [PoYo Wan 2.5 model page](https://poyo.ai/models/wan-2-5) <br>
- [PoYo Wan 2.5 text-to-video API docs](https://docs.poyo.ai/api-manual/video-series/wan2.5-text-to-video) <br>
- [PoYo Wan 2.5 image-to-video API docs](https://docs.poyo.ai/api-manual/video-series/wan2.5-image-to-video) <br>
- [ClawHub skill page](https://clawhub.ai/coolhackboy/skills/poyo-wan-2-5) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON payloads and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include a submitted task_id when the user explicitly requests execution in a safe server-side environment.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
