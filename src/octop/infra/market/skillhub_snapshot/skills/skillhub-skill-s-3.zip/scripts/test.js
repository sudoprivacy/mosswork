const { JSDOM } = require("jsdom");
const fs = require("fs");
const path = require("path");

const htmlPath = path.join(__dirname, "assets", "travel-souvenir-hub.html");
const html = fs.readFileSync(htmlPath, "utf8");

// 隔离 localStorage
const localStorageData = {};
const dom = new JSDOM(html, {
  url: "http://localhost/",
  pretendToBeVisual: true,
  runScripts: "dangerously",
  storageQuota: 10000000,
  beforeParse(window) {
    window.localStorage = {
      getItem(k) { return localStorageData[k] || null; },
      setItem(k, v) { localStorageData[k] = String(v); },
      removeItem(k) { delete localStorageData[k]; },
      clear() { for (const k in localStorageData) delete localStorageData[k]; }
    };
  }
});

const window = dom.window;
const document = window.document;
const ls = window.localStorage;

let pass = 0, fail = 0;
function assert(cond, msg) {
  if (cond) { pass++; console.log("✅ " + msg); }
  else { fail++; console.log("❌ " + msg); }
}

// 等待脚本执行
setTimeout(() => {
  try {
    // 1. 无运行时错误，基本元素存在
    assert(document.querySelector("h1").textContent.includes("旅行纪念品挑选台"), "标题正确渲染");
    assert(document.getElementById("todayCnt"), "今日待处理计数元素存在");
    assert(document.getElementById("ovRing"), "决策分布进度环元素存在");
    assert(document.getElementById("ovCats"), "分类图表元素存在");

    // 2. 种子数据正确初始化
    const trips = JSON.parse(ls.getItem("wb_travelsouvenir_trips") || "[]");
    const principles = JSON.parse(ls.getItem("wb_travelsouvenir_principles") || "[]");
    const candidates = JSON.parse(ls.getItem("wb_travelsouvenir_candidates") || "[]");
    const practices = JSON.parse(ls.getItem("wb_travelsouvenir_practices") || "[]");

    assert(trips.length >= 1, "种子旅行计划 >= 1 条");
    assert(principles.length >= 4, "种子选购原则 >= 4 条");
    assert(candidates.length >= 4, "种子候选纪念品 >= 4 条");
    assert(practices.length >= 1, "种子固定做法 >= 1 条");

    // 3. 原则分类覆盖 4+ 类，候选分类覆盖 2+ 类
    const prinCats = new Set(principles.map(x => x.cat));
    const candCats = new Set(candidates.map(x => x.cat));
    assert(prinCats.size >= 4, `原则分类覆盖 ${prinCats.size} 类，>=4`);
    assert(candCats.size >= 2, `候选分类覆盖 ${candCats.size} 类，>=2`);

    // 4. 已买件数与花费计算正确
    const bought = candidates.filter(x => x.decide === "已买");
    const spend = bought.reduce((s, x) => s + (parseFloat(x.price) || 0), 0);
    const displayedBought = document.getElementById("stBought").textContent;
    const displayedSpend = document.getElementById("stSpend").textContent;
    assert(displayedBought === String(bought.length), `已买件数显示正确：${displayedBought} === ${bought.length}`);
    assert(displayedSpend === spend.toFixed(2), `已花费显示正确：${displayedSpend} === ${spend.toFixed(2)}`);

    // 5. 置顶逾期项可捕获（种子中旅行选购截止日为昨天）
    const todayCnt = document.getElementById("todayCnt").textContent;
    assert(parseInt(todayCnt) > 0, `今日待处理捕获到逾期项：${todayCnt}`);

    // 6. renderAll 函数存在
    assert(typeof window.renderAll === "function", "renderAll 函数存在");

    // 7. 清空示例只删 sample
    window.clearData("sample");
    document.getElementById("mOk").click(); // 确认弹窗
    setTimeout(() => {
      try {
        const tripsAfter = JSON.parse(ls.getItem("wb_travelsouvenir_trips") || "[]");
        const candidatesAfter = JSON.parse(ls.getItem("wb_travelsouvenir_candidates") || "[]");
        assert(tripsAfter.every(x => !x.sample), "清空示例后 trips 无 sample 标记");
        assert(candidatesAfter.every(x => !x.sample), "清空示例后 candidates 无 sample 标记");

        // 8. 新增数据后能正确渲染
        document.getElementById("tr_name").value = "测试旅行";
        document.getElementById("tr_budget").value = "200";
        document.getElementById("tr_dest").value = "测试地";
        window.addTrip();
        const trips2 = JSON.parse(ls.getItem("wb_travelsouvenir_trips") || "[]");
        assert(trips2.some(x => x.name === "测试旅行"), "新增旅行计划成功写入 localStorage");

        console.log("\n测试结果：通过 " + pass + "，失败 " + fail);
        process.exit(fail > 0 ? 1 : 0);
      } catch (e) {
        console.error("测试异常：", e);
        process.exit(1);
      }
    }, 100);
  } catch (e) {
    console.error("测试异常：", e);
    process.exit(1);
  }
}, 200);
