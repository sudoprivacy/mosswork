#!/usr/bin/env python3
"""Validate an MTP 0.2.0 semantic plan and calculate its stable identity."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
import unicodedata
from pathlib import Path, PurePosixPath
from typing import Any


SUMMARY_BATCH_SIZE = 8
DETAIL_BATCH_SIZE = 2
_DISCOVERY_TERM_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._+-]*|[\u4e00-\u9fff]")


class DiscoveryError(RuntimeError):
    pass


SEMANTIC_FIELDS = ("goal", "dependencies", "task_contracts", "success_criteria")
TASK_FIELDS = (
    "goal",
    "dependencies",
    "allowed_paths",
    "artifact",
    "acceptance_criteria",
    "test_cases",
    "baseline_verification",
    "verification",
    "completion_signal",
    "risk",
    "review",
    "rollback",
    "execution",
    "exclusive_resources",
)
EXECUTION_VALUES = {"primary", "delegate", "parallel"}
REVIEW_VALUES = {"self", "combined", "two-stage", "independent"}
RISK_REVIEW = {
    "low": "self",
    "medium": "combined",
    "high": "two-stage",
    "release": "independent",
}
STATE_ONLY_PATHS = {"ai/NEXT.md", "ai/review.md", "ai/IMPL_LOG.md"}
COMMIT_RE = re.compile(r"[0-9a-f]{40}|[0-9a-f]{64}")
MARKED_PLAN_RE = re.compile(
    r"<!-- MTP01-PLAN:BEGIN -->\s*```json\s*(.*?)\s*```\s*<!-- MTP01-PLAN:END -->",
    re.DOTALL,
)
AC_ID_RE = re.compile(r"^(AC-[A-Z0-9]+-\d+):\s+.+")
TC_ID_RE = re.compile(r"^(TC-[A-Z0-9]+-\d+) covers ((?:AC-[A-Z0-9]+-\d+)(?:, AC-[A-Z0-9]+-\d+)*):\s+.+")


def _normalized(value: Any) -> Any:
    if isinstance(value, str):
        value = value.replace("\r\n", "\n").replace("\r", "\n")
        return unicodedata.normalize("NFC", value)
    if isinstance(value, list):
        return [_normalized(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _normalized(item) for key, item in value.items()}
    if value is None or isinstance(value, (bool, int, float)):
        return value
    raise TypeError(f"unsupported semantic value: {type(value).__name__}")


def canonical_semantic_bytes(plan: dict[str, Any]) -> bytes:
    semantic = {field: plan[field] for field in SEMANTIC_FIELDS}
    return json.dumps(
        _normalized(semantic),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def plan_revision(plan: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_semantic_bytes(plan)).hexdigest()


def load_marked_plan(text: str) -> Any:
    if text.count("<!-- MTP01-PLAN:BEGIN -->") != 1 or text.count("<!-- MTP01-PLAN:END -->") != 1:
        raise ValueError("exactly one complete marked MTP01 plan JSON block is required")
    match = MARKED_PLAN_RE.search(text)
    if match is None:
        raise ValueError("exactly one complete marked MTP01 plan JSON block is required")
    return json.loads(match.group(1))


def load_plan(path: Path) -> Any:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        return json.loads(text)
    return load_marked_plan(text)


def _nonempty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _string_list(value: Any, *, allow_empty: bool = True) -> bool:
    return (
        isinstance(value, list)
        and (allow_empty or bool(value))
        and all(_nonempty_string(item) for item in value)
    )


def evidence_ids(task: Any) -> tuple[set[str], dict[str, set[str]], list[str]]:
    """Return stable AC/TC coverage or deterministic contract errors."""
    if not isinstance(task, dict):
        return set(), {}, ["task evidence contract"]
    acceptance = task.get("acceptance_criteria")
    test_cases = task.get("test_cases")
    if not isinstance(acceptance, list) or not isinstance(test_cases, list):
        return set(), {}, ["task evidence contract"]
    ac_ids: set[str] = set(); coverage: dict[str, set[str]] = {}; errors: list[str] = []
    for item in acceptance:
        match = AC_ID_RE.fullmatch(item) if isinstance(item, str) else None
        if match is None:
            errors.append("acceptance criterion stable ID")
        elif match.group(1) in ac_ids:
            errors.append("duplicate acceptance criterion ID")
        else:
            ac_ids.add(match.group(1))
    for item in test_cases:
        match = TC_ID_RE.fullmatch(item) if isinstance(item, str) else None
        if match is None:
            errors.append("test case stable ID or coverage")
            continue
        tc_id = match.group(1)
        if tc_id in coverage:
            errors.append("duplicate test case ID")
            continue
        covered = set(match.group(2).split(", "))
        if not covered.issubset(ac_ids):
            errors.append("test case covers unknown acceptance criterion")
        coverage[tc_id] = covered
    if ac_ids and set().union(*coverage.values()) != ac_ids:
        errors.append("uncovered acceptance criterion")
    return ac_ids, coverage, sorted(set(errors))


def _covers_primary_state(allowed_path: str) -> bool:
    try:
        candidate = _scope_path(allowed_path)
        for state_path in STATE_ONLY_PATHS:
            state = _scope_path(state_path)
            if _path_within(state_path, allowed_path) or state in candidate.parents:
                return True
        return False
    except (TypeError, ValueError):
        return True


def _scope_path(value: str) -> PurePosixPath:
    for suffix in ("/**", "/*"):
        if value.endswith(suffix):
            value = value[: -len(suffix)]
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError("unsafe scope path")
    return path


def _path_within(actual: str, allowed: str) -> bool:
    actual_path = _scope_path(actual)
    allowed_path = _scope_path(allowed)
    if allowed.endswith(("/**", "/*")):
        return actual_path == allowed_path or allowed_path in actual_path.parents
    return actual_path == allowed_path


def validate_plan(plan: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(plan, dict):
        return ["plan must be an object"]
    if set(plan) != set(SEMANTIC_FIELDS):
        errors.append("plan fields must be exactly: " + ", ".join(SEMANTIC_FIELDS))
        return errors
    if not _nonempty_string(plan["goal"]):
        errors.append("goal must be a non-empty string")
    if not _string_list(plan["dependencies"]):
        errors.append("dependencies must be a string list")
    if not _string_list(plan["success_criteria"], allow_empty=False):
        errors.append("success_criteria must be a non-empty string list")

    tasks = plan["task_contracts"]
    if not isinstance(tasks, list) or not tasks:
        errors.append("task_contracts must be a non-empty list")
        return errors
    task_ids: set[str] = set()
    task_dependencies: dict[str, list[str]] = {}
    expected_fields = {"task_id", *TASK_FIELDS}
    for index, task in enumerate(tasks):
        label = f"task_contracts[{index}]"
        if not isinstance(task, dict):
            errors.append(f"{label} must be an object")
            continue
        if set(task) != expected_fields:
            errors.append(f"{label} fields are incomplete or unknown")
            continue
        task_id = task["task_id"]
        if not _nonempty_string(task_id):
            errors.append(f"{label}.task_id must be non-empty")
        elif task_id in task_ids:
            errors.append(f"duplicate task_id: {task_id}")
        else:
            task_ids.add(task_id)
            task_dependencies[task_id] = (
                task["dependencies"]
                if _string_list(task["dependencies"])
                else []
            )
        for field in TASK_FIELDS:
            if field in {"dependencies", "exclusive_resources"}:
                if not _string_list(task[field]):
                    errors.append(f"{label}.{field} must be a string list")
            elif field == "allowed_paths":
                if not _string_list(task[field], allow_empty=False):
                    errors.append(f"{label}.allowed_paths must be a non-empty string list")
            elif field in {"acceptance_criteria", "test_cases"}:
                if not _string_list(task[field], allow_empty=False):
                    errors.append(f"{label}.{field} must be a non-empty string list")
            elif field == "execution":
                if not isinstance(task[field], str) or task[field] not in EXECUTION_VALUES:
                    errors.append(f"{label}.execution is invalid")
            elif field == "review":
                if not isinstance(task[field], str) or task[field] not in REVIEW_VALUES:
                    errors.append(f"{label}.review is invalid")
            elif not _nonempty_string(task[field]):
                errors.append(f"{label}.{field} must be a non-empty string")
        risk = task.get("risk")
        expected_review = RISK_REVIEW.get(risk) if isinstance(risk, str) else None
        if expected_review is None:
            errors.append(f"{label}.risk is invalid")
        elif task.get("review") != expected_review:
            errors.append(f"{label}.review does not match risk")
        if task.get("risk") == "low" and task.get("execution") != "primary":
            errors.append(f"{label} low risk work must use primary execution")
        _, _, evidence_errors = evidence_ids(task)
        errors.extend(f"{label}.{error}" for error in evidence_errors)
        allowed_paths = task.get("allowed_paths")
        if _string_list(allowed_paths) and any(_covers_primary_state(path) for path in allowed_paths):
            errors.append(f"{label}.allowed_paths includes primary-only state")

    external_dependencies = set(plan["dependencies"]) if _string_list(plan["dependencies"]) else set()
    for task_id, dependencies in task_dependencies.items():
        for dependency in dependencies:
            if dependency == task_id:
                errors.append(f"{task_id} depends on itself")
            elif dependency not in task_ids and dependency not in external_dependencies:
                errors.append(f"{task_id} has unknown dependency: {dependency}")

    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(task_id: str) -> None:
        if task_id in visiting:
            errors.append("task dependency cycle")
            return
        if task_id in visited:
            return
        visiting.add(task_id)
        for dependency in task_dependencies.get(task_id, []):
            if dependency in task_dependencies:
                visit(dependency)
        visiting.remove(task_id)
        visited.add(task_id)

    for task_id in task_dependencies:
        visit(task_id)
    return errors


def validate_identity(plan: dict[str, Any], plan_commit: str, revision: str) -> list[str]:
    errors = validate_plan(plan)
    if not COMMIT_RE.fullmatch(plan_commit):
        errors.append("plan_commit must be a full Git object id")
    if revision != plan_revision(plan):
        errors.append("plan_revision does not match semantic inputs")
    return errors


def _load_registry_helper(project_root: Path):
    helper = project_root / "ai/registry.py"
    if helper.is_symlink() or not helper.is_file():
        raise DiscoveryError("registry-helper-missing")
    spec = importlib.util.spec_from_file_location("mtp_project_registry", helper)
    if spec is None or spec.loader is None:
        raise DiscoveryError("registry-helper-unimportable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_capability_matrix():
    """Load the optional-Git capability matrix (AC-014X-7) from the M-Build skill.

    The matrix is a pure, dependency-free decision module; it is loaded by path
    so M-Plan can consult it without importing the M-Build package directly.
    """
    module_path = Path(__file__).resolve().parents[2] / "m-build" / "scripts" / "capability_matrix.py"
    if module_path.is_symlink() or not module_path.is_file():
        raise DiscoveryError("capability-matrix-missing")
    spec = importlib.util.spec_from_file_location("mtp_capability_matrix", module_path)
    if spec is None or spec.loader is None:
        raise DiscoveryError("capability-matrix-unimportable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _discovery_terms(query: str) -> list[str]:
    value = query.strip().lower()
    return list(dict.fromkeys(_DISCOVERY_TERM_RE.findall(value))) if value else []


def _discovery_score(entry: dict[str, Any], terms: list[str]) -> int:
    """Relevance score for one index entry.

    Weighted field matching gives a deterministic relevance ordering instead of the
    old token-OR noise: an id hit weighs more than a summary hit, and the score is the
    sum of field weights over the distinct query terms satisfied.
    """
    weights = {"id": 3, "kind": 2, "title": 2, "tags": 2, "summary": 1, "source_project_id": 1}
    text = {field: str(entry.get(field, "")).lower() for field in weights}
    score = 0
    for term in terms:
        for field, weight in weights.items():
            if term in text[field]:
                score += weight
    return score


def _discovery_matches(entry: dict[str, Any], terms: list[str]) -> bool:
    # An empty query matches everything (complete index scan); a non-empty query must
    # satisfy at least one term. Ranking uses _discovery_score.
    return True if not terms else _discovery_score(entry, terms) > 0


def _discovery_relevant(entry: dict[str, Any], terms: list[str]) -> bool:
    """AC-REG-2 relevance gate: is the score high enough for an executable answer?

    A single weak hit (e.g. one summary term, weight 1) is not enough to claim an
    executable verified answer. Requiring at least two satisfied terms (or one hit in a
    high-weight field: id/title/tags/kind) keeps a lone summary coincidence from being
    reported as a confident `executable-verified-answer`, so "no high-scoring hit" is
    distinguished from a real match.
    """
    if not terms:
        return False
    if _discovery_score(entry, terms) >= 2:
        return True
    return any(
        _discovery_score(entry, [term]) >= 2 for term in terms
    )


def _discovery_git_head(root: Path, env: dict[str, str] | None) -> str | None:
    result = subprocess.run(
        ["git", "-C", str(root), "rev-parse", "HEAD"], capture_output=True,
        text=True, env=env, check=False,
    )
    value = result.stdout.strip()
    return value if result.returncode == 0 and re.fullmatch(r"[0-9a-f]{40}", value) else None


def _discovery_read(path: Path, loaded: list[str]) -> str | None:
    if path.is_symlink() or not path.is_file():
        return None
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None
    loaded.append(str(path))
    return text


def _discovery_source(
    project: dict[str, Any], record: dict[str, Any], loaded: list[str],
    env: dict[str, str] | None,
) -> dict[str, Any] | None:
    root = Path(project.get("project_root", ""))
    if not root.is_absolute() or root.is_symlink() or not root.is_dir():
        return None
    current_revision = _discovery_git_head(root, env)
    if (
        current_revision is None
        or current_revision != project.get("source_revision")
        or current_revision != record.get("source_revision")
    ):
        return None
    claude = _discovery_read(root / "CLAUDE.md", loaded)
    if claude is None:
        return None
    evidence: list[str] = []
    for pointer in record.get("evidence", []):
        candidate = (root / pointer.split("#", 1)[0]).resolve()
        try:
            candidate.relative_to(root.resolve())
        except ValueError:
            continue
        if _discovery_read(candidate, loaded) is not None:
            evidence.append(pointer)
    return {
        "project_id": project["id"], "project_root": str(root),
        "claude_entrypoint": record.get("detail", "CLAUDE.md"),
        "claude_bytes": len(claude.encode("utf-8")),
        "evidence": evidence, "source_revision": current_revision,
    }


def _discovery_unavailable(task_class: str, reason: str) -> dict[str, Any]:
    status = {
        "explicit-cross-project": "block-lookup",
        "registry-relevant": "registry-pending",
    }.get(task_class, "continue-degraded")
    return {
        "status": status, "registry_revision": None, "scanned_ids": [],
        "matching_ids": [], "selected_record_ids": [], "applicability": [],
        "records": [], "capabilities": [], "sources": [], "loaded_paths": [],
        "stop": "registry-unavailable", "reason": reason,
    }


def discover(
    project_root: str | Path, query: str = "", *,
    task_class: str = "registry-relevant", env: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Read-only complete-index, 8-summary/2-detail Registry discovery."""
    root = Path(project_root).expanduser()
    cap = _load_capability_matrix()
    git_ok = cap.git_available()
    try:
        helper = _load_registry_helper(root)
        resolved = helper.resolve_registry(env=env)
        index = helper.scan_index(resolved["path"], env=env)
    except Exception as error:
        if not git_ok:
            state = cap.LocatorState.ABSENT_GIT
        else:
            message = str(error)
            # AC-014X-2/3/7 distinguish a single missing locator (resume after
            # bootstrap) from an ambiguous / invalid / structurally broken locator,
            # which must fail closed into explicit repair rather than be guessed.
            if "locator-missing" in message:
                state = cap.LocatorState.MISSING
            else:
                state = cap.LocatorState.INVALID
        outcome = cap.eval_capability("m-plan", state)[cap.Op.SHARED_LOOKUP]
        return _discovery_unavailable(task_class, cap.reason_for(outcome))

    terms = _discovery_terms(query)
    scanned_ids = [entry["id"] for entry in index["entries"]]
    candidates: list[dict[str, Any]] = []
    offset: int | None = 0
    summary_batches = 0
    while offset is not None:
        batch = helper.summary_batch(index, offset)
        summary_batches += 1
        candidates.extend(entry for entry in batch["entries"] if _discovery_matches(entry, terms))
        offset = batch["next_offset"]
    # Rank candidates by relevance so the progressive detail reads the best matches
    # first; ties break on id for determinism. Empty query keeps stable-id order.
    if terms:
        candidates.sort(key=lambda e: (-_discovery_score(e, terms), e["id"]))
    candidate_ids = [entry["id"] for entry in candidates]

    details: list[dict[str, Any]] = []
    offset = 0
    detail_batches = 0
    while offset < len(candidate_ids):
        batch = helper.detail_batch(resolved["path"], candidate_ids, offset, env=env)
        detail_batches += 1
        details.extend(batch["entries"])
        offset = len(candidate_ids) if batch["next_offset"] is None else batch["next_offset"]
    project_ids = list(dict.fromkeys(
        item["source_project_id"] for item in details if item["kind"] != "project"
    ))
    projects: dict[str, dict[str, Any]] = {}
    offset = 0
    while offset < len(project_ids):
        batch = helper.detail_batch(resolved["path"], project_ids, offset, env=env)
        detail_batches += 1
        projects.update({item["id"]: item for item in batch["entries"]})
        offset = len(project_ids) if batch["next_offset"] is None else batch["next_offset"]

    loaded: list[str] = []
    selected: list[dict[str, Any]] = []
    capabilities: list[dict[str, str]] = []
    sources: list[dict[str, Any]] = []
    applicability: list[dict[str, Any]] = []
    stale: list[str] = []
    review_needed: list[str] = []
    for record in details:
        # A record already flagged stale in the Registry (status review-needed) or whose
        # source project can no longer be read is downgraded, never dropped (AC-REG-3).
        if record.get("status") == "review-needed":
            review_needed.append(record["id"])
            applicability.append({"id": record["id"], "applicable": False, "reason": "registry-review-needed"})
            continue
        project = record if record["kind"] == "project" else projects.get(record["source_project_id"])
        source = _discovery_source(project, record, loaded, env) if project else None
        if source is None:
            stale.append(record["id"])
            applicability.append({"id": record["id"], "applicable": False, "reason": "stale-or-unreadable-source"})
            continue
        selected.append(record); sources.append(source)
        applicability.append({"id": record["id"], "applicable": True, "reason": "current-source-match"})
        if record["kind"] == "capability":
            capabilities.append({
                "name": record["title"], "purpose": record["summary"],
                "applicability": record["applicability"],
                "source_project_id": record["source_project_id"],
                "entrypoint": record["entrypoint"], "source_revision": record["source_revision"],
            })
    # AC-REG-2 stop criteria: relevance threshold + no-high-score vs matched-but-stale.
    # 'no-match'          -- query terms satisfy no candidate at all;
    # 'no-relevant-match' -- there are token matches but none clears the relevance gate;
    # 'matched-but-stale' -- relevant matches exist but none has a live, current source;
    # 'executable-verified-answer' -- at least one relevant match with a live source.
    relevant_ids = [entry["id"] for entry in candidates if _discovery_relevant(entry, terms)]
    if not terms:
        stop = "candidate-exhaustion"
    elif not candidate_ids:
        stop = "no-match"
    elif not relevant_ids:
        stop = "no-relevant-match"
    elif selected:
        stop = "executable-verified-answer"
    else:
        stop = "matched-but-stale"
    return {
        "status": "ok", "registry_revision": resolved["registry_revision"],
        "scanned_ids": scanned_ids, "matching_ids": candidate_ids,
        "relevant_ids": relevant_ids,
        "selected_record_ids": [item["id"] for item in selected],
        "applicability": applicability, "records": selected, "capabilities": capabilities,
        "sources": sources, "loaded_paths": loaded, "stale_ids": stale,
        "review_needed_ids": review_needed,
        "summary_batches": summary_batches, "detail_batches": detail_batches,
        "stop": stop,
    }


def _run_discover(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="validate_plan.py discover", description="Run Registry discovery")
    parser.add_argument("--project-root", type=Path, default=Path("."))
    parser.add_argument("--query", default="")
    parser.add_argument("--task-class", default="registry-relevant",
                        choices=["registry-relevant", "explicit-cross-project", "local-only-not-registry-relevant"])
    args = parser.parse_args(argv)
    try:
        result = discover(args.project_root, args.query, task_class=args.task_class)
    except (OSError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "error", "reason": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    # Peek argv: `discover ...` is a subcommand; the positional plan form still works (G-2①).
    if argv and argv[0] == "discover":
        return _run_discover(argv[1:])

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("plan", type=Path, help="JSON file containing the semantic plan")
    parser.add_argument("--print-revision", action="store_true")
    parser.add_argument("--plan-commit")
    parser.add_argument("--plan-revision")
    args = parser.parse_args(argv)

    try:
        plan = load_plan(args.plan)
        errors = validate_plan(plan)
        if bool(args.plan_commit) != bool(args.plan_revision):
            errors.append("--plan-commit and --plan-revision must be supplied together")
        elif args.plan_commit and args.plan_revision:
            errors = validate_identity(plan, args.plan_commit, args.plan_revision)
    except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
        errors = [str(exc)]

    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1
    if args.print_revision:
        print(plan_revision(plan))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
