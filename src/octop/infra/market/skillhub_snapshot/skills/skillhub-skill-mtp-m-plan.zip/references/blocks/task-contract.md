trigger: 拆 Task、写 AC/TC、定风险与审查
budget: 1900
next: 合同写好后读 plan-identity.md 绑定身份

# Task 合同

所有规划遵循 Think Before Coding、Simplicity First、Surgical Changes 和 Goal-Driven Execution：
先写明假设、歧义、取舍和更简单方案，只规划完成目标所需的最小改动，并让每项修改、测试和审查都能
追溯到 Task 的 AC、TC 和验证。

1. 将目标拆成可独立交付和验证的 Task。每个 Task 必须包含 `task_id`，以及 `goal`、
   `dependencies`、`allowed_paths`、`artifact`、`acceptance_criteria`、`test_cases`、
   `baseline_verification`、`verification`、`completion_signal`、`risk`、`review`、`rollback`、
   `execution` 和 `exclusive_resources`。每个验收条件使用唯一 `AC-...` ID；每个测试用例使用唯一
   `TC-...` ID，并显式列出其覆盖的 AC。不得有未知、重复或未覆盖的 ID，也不得为不存在的 TC 声称
   验证。
2. 明确依赖、允许路径和独占资源。默认使用 `execution=primary`，按风险选择 `review`：低风险
   self、中风险 combined、高风险 two-stage、发布 independent。风险理由必须说明影响面、可逆性、
   失败后果、可验证性以及真实风险信号。
3. 边界明确、局部、可逆、可确定验证，且不涉及实质歧义、共享合同、业务数据迁移、权限或安全
   边界、远程不可逆副作用、大范围删除、真实并发或不可验证行为的工作才是简单低风险：由主 Agent
   自己执行，Reviewer 和子 Agent 调用数均为零，只做受影响验证，不建立独立审查 artifact；不要为
   并发而拆分 Task。`parallel` 只用于有真实并行收益、依赖已 Accepted、声明范围和实际范围都不
   相交、且隔离 worktree 与中断能力可用的例外写入。复杂 Task 缺少 `child` 时主 Agent 顺序执行；
   缺少写隔离或中断时 Blocked，除非用户明确许可主 Agent 顺序执行。合同要求的 Reviewer 不可用时
   一律 Blocked。
