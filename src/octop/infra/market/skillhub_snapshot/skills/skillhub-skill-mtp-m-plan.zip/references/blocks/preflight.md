trigger: 写计划前，或审批/AC 标注状态不明
budget: 1100
next: 通过后读 task-contract.md 拆 Task

# 计划前置

只读取 `CLAUDE.md`、`ai/brief.md`、当前 `ai/plan.md` 和被明确引用的证据。方向仍有实质性不确定时
返回 `m-define`，不写计划。

## 地图预检（零写）

写计划前跑 `python3 <m-build>/scripts/project_memory.py status --target <项目>`。`ready=false`（仍有 `待替换`，或缺节 / 空节）或 `stale=true`（`Current State` 与
`ai/NEXT.md` 的事实不一致）时**零写并路由修复**：未就绪 → 先补地图（`m-new` 收尾流程）；陈旧 →
`sync-current-state --apply` 后再规划。地图未就绪不得进入 Registry 预检之后的规划。

`gate` 数组是 GATE 的三项质量检查（`missing-h1` / `placeholder-h1` / `junk-h1`、`structure-*`、
`name-title-mismatch`）。`name-title-mismatch` 默认 `warn`（回填完成前只提示，不阻断），把
`project_memory.py` 的 `NAME_TITLE_ENFORCEMENT` 改成 `block` 后即阻断规划。其余两项按 H1 与
Structure 的修复指引先补地图再规划。

## Approval Preflight

写计划前先读 `ai/NEXT.md` 的审批状态（`tools/approval.py approval_state`）：`approval` 取
`pending` / `approved`，`approved` 必须带 `approved_by`。存在未闭合的 `blocking_open_questions`
时，`tools/approval.py blocking_gate` 判定为 `route=m-define, write_allowed=false`——此时**零写
返回 m-define**，不得生成或修订计划。

每个 AC 带 `verifiable` 三档：`machine` / `manual` / `declared`；`manual` 必须写复核人
（`reviewer`），由 `tools/approval.py ac_verifiable_tier` 校验。AC 文本仍是计划证据主体，
`verifiable` 作为其**随附标注**（如 `AC-XX-1 (verifiable=machine): ...`），不改变 AC 覆盖契约；
`manual` 的复核人写在该 AC 标注内。
