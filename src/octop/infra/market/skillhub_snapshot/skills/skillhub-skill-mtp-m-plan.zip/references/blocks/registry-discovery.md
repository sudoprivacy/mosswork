trigger: 需要多步计划或跨项目信息
budget: 1600
next: 发现结果作为计划证据保留，再拆 Task

# Registry 预检与渐进式发现

创建或修订多步计划前，主 Agent 自动调用当前项目安装的 `scripts/validate_plan.py` 的 `discover`
路径，加载项目内 `ai/registry.py` 并通过机器级 Git locator 定位独立 Registry。不得按 Skill 安装
路径、项目路径副本或文件系统扫描推测 Registry。

发现顺序固定为：

1. 完整读取 Registry active index，按 stable ID 升序记录全部 `scanned_ids` 和`registry_revision`；
   无总匹配上限。
2. 以 8 条为一批读取 summary，筛出可能相关的 Lesson、Project 和 capability，记录
   `matching_ids`。不足以判断时继续下一批。
3. 以 2 条为一批读取 detail；先读取来源项目 `CLAUDE.md`，再只打开该记录 evidence
   指针所指向且与问题相关的最小文件。不得读取 `MTP_THINK.md` 或广泛加载项目。
4. 将过期、缺失或与来源项目当前 HEAD 不一致的 `source_revision` 排除，并记录 `applicability`、
   `selected_record_ids`、停止条件和已加载路径。

结果必须作为计划证据保留。无匹配是有效的 `candidate-exhaustion`，不是失败。
**跨项目合流（AC-REG-1）**：待写入记录 `fingerprint` 命中既有 lesson/capability 时，用
`tools.registry publish --merge` 并入（默认 publish 不自动合并，避免不同 id 同内容被静默塌掉）；
合流后旧 id 经 `resolve_superseded` 解析回幸存记录。

Registry 不可用时：local-only 且非 Registry relevant 继续降级；显式跨项目问题阻断；其余 Registry
relevant 情况记录 `registry-pending` 到项目 `ai/NEXT.md`，不污染 `CLAUDE.md`。发现只提供导航和
证据，不复制、调用、集成或修改其他项目。

普通单步 Direct Path 不触发该预检；只有确实需要多步计划或跨项目信息的问题才进入该路径。清晰、
边界明确、局部、可逆且可确定验证的单步请求不进入本 Skill，也不创建正式计划；直接交给 `m-build`
的 Direct Path。不得为了流程完整把简单工作包装成 Task。
