trigger: 合同写完、要校验 revision、绑定 plan_commit
budget: 800
next: 用户批准后提交并回 m-build

# 计划身份

1. 在 `ai/plan.md` 的 `MTP01-PLAN:BEGIN/END` 标记内保存一个 JSON 语义合同：`goal`、
   `dependencies`、`task_contracts` 和 `success_criteria`。运行
   `python3 $SKILL_DIR/scripts/validate_plan.py ai/plan.md --print-revision` 校验结构并计算规范化
   SHA-256 `plan_revision`；校验失败时不更新现行计划。
2. 用户批准后提交包含该合同的 Git commit，将其 SHA 作为 `plan_commit`。使用脚本的
   `--plan-commit` 与 `--plan-revision` 复核身份，再只更新 `ai/NEXT.md` 的当前 Task、
   `plan_commit` 和 `plan_revision`。
3. `ai/NEXT.md`、`ai/review.md`、`ai/IMPL_LOG.md` 是状态文件，不参与 revision；目标、依赖、
   Task 合同或成功标准变化时必须生成新 revision，并使旧 revision 的未接受派发失效。

本 Skill 只写 `ai/plan.md` 和 `ai/NEXT.md`，不写 `CLAUDE.md` 或 `ai/lessons.md`，不执行实现、
不调度 Agent、不写审查结果。计划就绪后返回 `m-build`。
