---
name: skillhub-skill-mtp-m-plan
description: "monster 的 MTP 0.2.4 主流程计划入口。方向已经明确，需要创建或修订可独立验证的多步实施 Task 时使用。"
---

# M-Plan

```mermaid
flowchart LR
  A["Preflight"] --> B["Registry 发现"] --> C["拆 Task"] --> D["绑身份"]
```

## Version Preflight

写入前读取 `$SKILL_DIR/MTP_VERSION` 和 `ai/mtp.json`。manifest 缺失、profile
不是 `lightweight`、缺少有效 `project_id` / `registry_id` 或版本不匹配时，返回
`m-new` 且零写。只有完整 Bundle `0.2.4` 项目才继续。

## 读哪块

| 状态 | 读 |
|---|---|
| 地图/审批/AC 标注未定 | `blocks/preflight.md` |
| 要跨项目查 Lesson 或能力 | `blocks/registry-discovery.md` |
| 拆 Task、写 AC/TC | `blocks/task-contract.md` |
| 写 JSON 合同、绑 revision | `blocks/plan-identity.md` |

## 硬要求

1. 机器校验才是 Gate：`validate_plan.py` 不通过就不更新现行计划。
2. 地图预检 `ready=false` 或 `stale=true` 时零写并路由修复。
3. 不得把局部、可逆的单步工作包装成 Task；简单工作走 `m-build` Direct Path。
