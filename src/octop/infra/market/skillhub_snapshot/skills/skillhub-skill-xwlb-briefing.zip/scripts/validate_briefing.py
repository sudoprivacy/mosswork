# -*- coding: utf-8 -*-
"""validate_briefing.py — 生成物结构校验（0.1.9，生成唯一性防线）。

按文件名自动判别类型：
  含「要闻速览」 -> 负责人版；含「政策解读」 -> 工作底稿。

用法：
  python validate_briefing.py "<草稿md>" [更多md ...]

输出：每个文件一行 JSON {"file","kind","ok","errors","warnings","sha256"}。
任何 error -> 退出码 1。生成后必须跑、errors 清零才算产出（0.1.9 生成隔离纪律）。

说明：结构/要素可代码化校验；措辞一致不可校验也不追求——唯一性的可保证定义
= 结构一致 + 要素齐全 + 红线词不出现。数字溯源靠人工对照 联播原文/。
"""
import hashlib
import json
import re
import sys
from pathlib import Path

DATE_RE = r"\d{4}年\d{1,2}月\d{1,2}日"

# 负责人版红线词：内部流程信息不允许上版（0.1.5 口径 + 0.1.9 固化）
CHAIRMAN_FORBIDDEN = {
    "【相关】": "负责人版零解读：不得出现【相关】段",
    "待复核": "状态词不得上版",
    "已定稿": "状态词不得上版",
    "工作底稿": "内部产物名不得上版",
    "AI 草稿": "内部流程信息不得上版",
    "AI 初稿": "内部流程信息不得上版",
    # 0.1.10：溯源是内部工序，说明字样不得上版（新闻原文里的"首次"不受影响，
    # 故只拦"首次+工序动词"组合，不拦单词"首次"）
    "首次覆盖": "溯源工序说明不得上版",
    "首次收录": "溯源工序说明不得上版",
    "首次纳入跟踪": "溯源工序说明不得上版",
    "首次开始跟踪": "溯源工序说明不得上版",
}
# 0.1.13 P1-2：内宣栏目名黑名单以正则拦截（【...】在联播中即栏目名标记）
BRACKET_RE = __import__("re").compile(r"【[^】]+】")
# 0.1.13 P1-3：跟踪表起点允许的两种格式
START_RE = __import__("re").compile(r"^\d{1,2}月\d{1,2}日(（检索窗口内最早出现日）)?$")
# 0.1.13 P1-1：负责人版量化参数
MAX_ITEMS = 8
MAX_ITEM_BODY = 120
# 期数（0.1.5 拍板不上版）
QISHU_RE = re.compile(r"第\s*\d+\s*期")


def kind_of(name: str) -> str | None:
    if "要闻速览" in name:
        return "decision-maker"
    if "政策解读" in name:
        return "draft"
    return None


def validate_decision_maker(text: str, errors: list, warnings: list, src_path=None) -> None:
    # P1-1/P1-2/P1-3 的结构化检查见下方
    if not text.lstrip().startswith("# 中央新闻联播要闻速览"):
        errors.append("首行标题应为「# 中央新闻联播要闻速览」")
    if not re.search(rf"^{DATE_RE} · 星期[一二三四五六日]\s*$", text, re.M):
        errors.append("缺少日期行（YYYY年M月D日 · 星期X，独占一行）")
    if "**今日主线**" not in text:
        errors.append("缺少「**今日主线**」")
    for sec in ("## 一、政策要闻", "## 二、经济与国际", "## 四、来源"):
        if sec not in text:
            errors.append(f"缺少章节「{sec}」")
    if "## 三、持续跟踪" not in text:
        warnings.append("无「持续跟踪」表（允许：当日无连续事件时）")
    if "tv.cctv.com/lm/xwlb/day/" not in text:
        errors.append("缺少央视网当日栏目页来源链接")
    for word, why in CHAIRMAN_FORBIDDEN.items():
        if word in text:
            errors.append(f"红线词「{word}」：{why}")
    if QISHU_RE.search(text):
        errors.append("出现期数（0.1.5 拍板不上版）")
    # 0.1.13 P1-2：内宣栏目名（【...】）不得上版
    for m in BRACKET_RE.finditer(text):
        errors.append(f"内宣栏目名「{m.group(0)}」不得上版（0.1.13 黑名单），条目需中性重写")
    # 0.1.13 P1-1：条目数 ≤8、单条正文 ≤120 字
    lines = text.splitlines()
    item_idx = [i for i, ln in enumerate(lines) if re.match(r"^\*\*\d+｜", ln)]
    if len(item_idx) > MAX_ITEMS:
        errors.append(f"条目数 {len(item_idx)} 超上限 {MAX_ITEMS}（0.1.13 一页纸量化参数）")
    bounds = item_idx + [next((i for i, ln in enumerate(lines) if ln.startswith("## ") and i > (item_idx[-1] if item_idx else 0)), len(lines))]
    for n, i0 in enumerate(item_idx, 1):
        i1 = bounds[bounds.index(i0) + 1] if (bounds.index(i0) + 1) < len(bounds) else len(lines)
        body = "".join(lines[i0 + 1:i1]).replace("*", "").replace(" ", "").replace("｜", "")
        title = lines[i0].replace("*", "")
        if len(body) > MAX_ITEM_BODY:
            errors.append(f"条目 {n}「{title[:24]}…」正文 {len(body)} 字，超上限 {MAX_ITEM_BODY}（0.1.13）")
    # 0.1.23：主线行形态——必须为普通粗体行，禁用引用前缀（> 会渲染成副标题框）
    main_line = next((ln for ln in lines if "今日主线" in ln), None)
    if main_line is None:
        errors.append("缺少「今日主线」行（模板：**今日主线**：<一句话，≤40字>）")
    elif main_line.lstrip().startswith(">"):
        errors.append("0.1.23 主线行禁用引用前缀（> ）——按模板应为普通粗体行 **今日主线**：…")
    # 0.1.13 P1-3：跟踪表起点格式；0.1.21：起点须有事件档案支撑
    in_table = False
    track_rows = []  # (事项, 起点日期)
    for ln in lines:
        if ln.startswith("## 三、持续跟踪"):
            in_table = True
            continue
        if ln.startswith("## ") and in_table:
            in_table = False
        if in_table and ln.startswith("| ") and "事项" not in ln and "---" not in ln:
            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
            # 0.1.15：事项 | 最新进展（今日） | 后续观察点 | 起点（末列为起点日期）
            if len(cells) < 4:
                errors.append(f"跟踪表「{cells[0][:16]}」列数 {len(cells)} 不足 4（0.1.15 结构：事项 | 最新进展（今日） | 后续观察点 | 起点）")
            elif re.search(r"未被播报|缺席|未提及|未播出|今日无", cells[1]):
                errors.append(f"0.1.23 跟踪表「{cells[0][:16]}」最新进展含内部代谢状态词（未被播报/缺席等）——今日未提及的事件不得入表")
            elif not START_RE.match(cells[-1]):
                errors.append(f"跟踪表「{cells[0][:16]}」起点「{cells[-1]}」格式不符（应为 X月X日 或 X月X日（检索窗口内最早出现日））")
            else:
                track_rows.append((cells[0], cells[-1]))
    # 0.1.21：溯源结论必须落盘事件档案——跟踪表非空 ⇒ 事件档案目录非空，
    # 且每个「非当日起点」行的起点日期必须能在某份档案中找到（防止起点记当日/凭记忆滚动）。
    if track_rows:
        archive_dir = None
        if src_path is not None:
            cand = Path(src_path).resolve().parent.parent / "事件档案"
            if cand.is_dir():
                archive_dir = cand
        if archive_dir is None:
            if src_path is not None:
                errors.append("0.1.21 事件档案目录缺失（期望 中间产物/事件档案/）——溯源结论必须落盘事件档案")
            else:
                warnings.append("0.1.21 事件档案目录未找到（期望 中间产物/事件档案/），无法校验起点支撑")
        else:
            archives = list(archive_dir.glob("*.md"))
            if not archives:
                errors.append("跟踪表非空但 中间产物/事件档案/ 为空（0.1.21：溯源结论必须落盘事件档案）")
            else:
                corpus = "".join(f.read_text(encoding="utf-8") for f in archives)
                today_cn = None
                if src_path is not None:
                    m0 = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})", Path(src_path).name)
                    if m0:
                        today_cn = f"{int(m0.group(2))}月{int(m0.group(3))}日"
                for item, start in track_rows:
                    if today_cn and start == today_cn:
                        continue  # 当日首现：档案当日落盘即可，不强制历史日期命中
                    if start not in corpus:
                        errors.append(f"跟踪表「{item[:16]}」起点「{start}」无事件档案支撑（0.1.21：溯源结论必须写入 中间产物/事件档案/ 且档案含该起点日期）")


def validate_draft(text: str, errors: list, warnings: list) -> None:
    if not re.search(rf"^# 新闻联播政策解读 · {DATE_RE}\s*$", text.lstrip(), re.M):
        errors.append("首行标题应为「# 新闻联播政策解读 · YYYY年M月D日」")
    if not re.search(r"^>\s*\*\*状态：AI 草稿", text, re.M):
        errors.append("缺少状态行「> **状态：AI 草稿，待复核方复核后定稿**」")
    for sec in ("## 一、政策要闻", "## 二、国际要闻", "## 三、一句话研判"):
        if sec not in text:
            errors.append(f"缺少章节「{sec}」")
    if "核验来源" not in text:
        errors.append("缺少「核验来源」段")
    if "未作外部补充" not in text:
        warnings.append("核验来源未声明「未作外部补充」")


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    args = [a for a in sys.argv[1:] if a.strip()]
    if not args:
        print(json.dumps({"error": "no_input", "hint": "用法：validate_briefing.py <草稿md> [更多md]"},
                         ensure_ascii=False))
        sys.exit(2)
    total_errors = 0
    for a in args:
        p = Path(a)
        if not p.exists():
            print(json.dumps({"file": a, "ok": False, "errors": ["file_not_found"], "warnings": []},
                             ensure_ascii=False))
            total_errors += 1
            continue
        kind = kind_of(p.name)
        if kind == "decision-maker" and "中央新闻联播要闻速览" not in p.name:
            print(json.dumps({"file": p.name, "ok": False,
                              "errors": ["P1-4 文件名必须含「中央新闻联播要闻速览」（0.1.13 命名契约）"],
                              "warnings": []}, ensure_ascii=False))
            total_errors += 1
            continue
        if kind is None:
            print(json.dumps({"file": p.name, "ok": False,
                              "errors": ["文件名无法判别类型：应含「要闻速览」或「政策解读」"], "warnings": []},
                             ensure_ascii=False))
            total_errors += 1
            continue
        text = p.read_text(encoding="utf-8")
        errors, warnings = [], []
        if kind == "decision-maker":
            if not re.match(r"^\d{4}-\d{2}-\d{2} 中央新闻联播要闻速览\.md$", p.name):
                errors.append("0.1.21 文件名日期格式不符（应为 YYYY-MM-DD 中央新闻联播要闻速览.md）")
            validate_decision_maker(text, errors, warnings, src_path=p)
        else:
            validate_draft(text, errors, warnings)
        total_errors += len(errors)
        print(json.dumps({"file": p.name, "kind": kind, "ok": not errors,
                          "errors": errors, "warnings": warnings,
                          "sha256": hashlib.sha256(p.read_bytes()).hexdigest()[:16]},
                         ensure_ascii=False))
    sys.exit(1 if total_errors else 0)


if __name__ == "__main__":
    main()
