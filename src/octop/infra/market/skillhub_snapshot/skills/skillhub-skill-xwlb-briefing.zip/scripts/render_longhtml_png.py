# -*- coding: utf-8 -*-
"""render_longhtml_png.py -- Render the decision-maker long-image HTML into the push-ready PNG.

0.1.8: turns the ad-hoc Edge screenshot pipeline into a skill script, fixing the
pitfalls hit on 2026-09-21:
  1. Edge's --screenshot flag requires a NATIVE path (a file:// URI fails with 0x7B);
     only the target URL uses as_uri().
  2. The crop step needs Pillow + numpy. The managed WorkBuddy Python lacks them;
     this script fails fast with the exact venv interpreter to use instead.
  3. Edge must be launched via subprocess from Python (PowerShell Start-Process
     breaks on PATH/Path env duplication in some sessions).

Pipeline: Edge headless window 774 css px (= 750 content + 24 scrollbar reserve),
device-scale-factor 2, screenshot 1548 px wide -> crop to 1500 px (drops the
scrollbar column); bottom cut at last non-white row + 140 physical px (Home
indicator safe area, 0.1.7).

Usage:
  python render_longhtml_png.py "<longimage.html>" [--out "<out.png>"] [--window-height 10000]

Output: JSON line {"ok": true, "out": ..., "size": [w, h], "bytes": n}
"""
import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

# 0.1.20 跨平台：Windows Edge → Linux/any chromium 系 → 环境变量 XWLB_BROWSER 最高优先
EDGE_CANDIDATES = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
    "/snap/bin/chromium",
]


SHOT_READY_BYTES = 100_000
POLL_SECONDS = 20


def find_edge() -> str:
    import shutil
    override = os.environ.get("XWLB_BROWSER")
    if override and Path(override).exists():
        return override
    for p in EDGE_CANDIDATES:
        if Path(p).exists():
            return p
    for cand in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "msedge"):
        exe = shutil.which(cand)
        if exe:
            return exe
    raise SystemExit(json.dumps({"ok": False,
                                 "error": "no chromium-family browser found（Windows Edge / Linux chromium / $XWLB_BROWSER 均未命中）；"
                                          "Linux 可先执行 bootstrap.sh 或 apt install chromium"},
                                ensure_ascii=False))


def check_runtime() -> None:
    try:
        import numpy  # noqa: F401
        from PIL import Image  # noqa: F401
    except ImportError:
        raise SystemExit(json.dumps({
            "ok": False,
            "error": "PNG 渲染需要 Pillow + numpy；当前 Python 缺少依赖。请先 pip install pillow numpy（或运行 bootstrap.sh）",
        }, ensure_ascii=False))


def crop(shot_path: Path, out_path: Path, window_height: int) -> tuple:
    import numpy as np
    from PIL import Image

    img = Image.open(shot_path).convert("L")
    w, h = img.size
    a = np.asarray(img)
    # density scan band: exclude right scrollbar column and bottom margin
    band = a[: h - 400, 100:1350]
    rows = (band < 245).sum(axis=1)
    nz = [i for i, v in enumerate(rows) if v > 3]
    last = nz[-1] if nz else h
    if last > h - 500:
        print(json.dumps({"warn": f"content ends near viewport bottom (row {last}/{h}); "
                                  f"may be truncated -- retry with --window-height {window_height * 2}"}, ensure_ascii=False),
              file=sys.stderr)
    crop_h = min(h, last + 140)

    full = Image.open(shot_path).convert("RGB")
    out = full.crop((0, 0, 1500, crop_h))
    out.save(out_path, "PNG")
    return out.size


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("html", help="path to the long-image HTML")
    ap.add_argument("--out", help="output PNG path (default: same stem .png)")
    ap.add_argument("--window-height", type=int, default=10000)
    args = ap.parse_args()

    check_runtime()

    html = Path(args.html).resolve()
    if not html.exists():
        raise SystemExit(json.dumps({"ok": False, "error": f"html not found: {html}"}, ensure_ascii=False))
    out_png = Path(args.out).resolve() if args.out else html.with_name(html.stem.replace("_长图", "") + ".png")
    shot = out_png.with_name(f"_shot_{out_png.stem}.png")

    edge = find_edge()
    cmd = [
        edge,
        "--headless=new", "--disable-gpu", "--hide-scrollbars",
        "--force-device-scale-factor=2",
        f"--window-size=774,{args.window_height}",
        "--default-background-color=FFFFFFFF",
        f"--screenshot={shot}",          # NATIVE path -- a URI here fails with 0x7B
        html.as_uri(),                    # only the target URL is a URI
    ]
    r = subprocess.run(cmd, capture_output=True, timeout=120)

    deadline = time.time() + POLL_SECONDS
    while time.time() < deadline:
        if shot.exists() and shot.stat().st_size > SHOT_READY_BYTES:
            break
        time.sleep(0.5)
    else:
        err = r.stderr.decode("utf-8", "ignore")[-1500:]
        raise SystemExit(json.dumps({"ok": False, "error": "screenshot not ready", "edge_stderr": err}, ensure_ascii=False))

    try:
        size = crop(shot, out_png, args.window_height)
    finally:
        if shot.exists():
            os.remove(shot)

    print(json.dumps({"ok": True, "out": str(out_png), "size": list(size), "bytes": out_png.stat().st_size}, ensure_ascii=False))


if __name__ == "__main__":
    main()
