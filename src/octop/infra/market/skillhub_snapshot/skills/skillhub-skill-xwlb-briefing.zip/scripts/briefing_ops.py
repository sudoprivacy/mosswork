# -*- coding: utf-8 -*-
"""briefing_ops.py — xwlb-briefing skill 的状态记账工具。

数据目录（业务数据，一律在 skill 目录之外）：
  解析顺序（0.1.9 起）：--data-dir 参数 > 环境变量 XWLB_BRIEFING_DATA_DIR > 报错拒绝落盘。
  ⚠ 已删除 cwd/Documents 静默兜底：落点不确定时报 data_dir_unspecified，由调用方显式给路径。
  布局：产出物/（仅交付物，默认 PNG）、中间产物/<日期>/（md+HTML）、联播原文/（原始抓取）、历史版本/（--force 重登记留底）、
        state.json（状态）、口径反馈登记.md
  兼容：首次运行时自动把旧目录 drafts/raw/草稿 改名为 联播原文/产出物，并同步 state.json 内的路径。

子命令：
  status                                概览：今日/最近条目与缺口
  register --date YYYYMMDD --method manual --files "a;b" [--force]   登记一次产出
                                        同日期已登记时默认拒绝（already_registered）；
                                        --force 才覆盖且旧稿自动留底（仅限用户明确要求）
  finalize --date YYYYMMDD              待复核 -> 已定稿（重命名文件并更新状态）
  gap      --date YYYYMMDD --reason "…" 登记缺口（当天未产出）
  feedback --text "…"                   追加口径反馈
"""
import argparse
import json
import os
import pathlib
import sys
from datetime import datetime

STATUS_REVIEW = "待复核"
# 0.1.13：人工复核暂停——联播条目已过央视人工审核，登记即「已定稿」可直接推送；
# 恢复人工复核时改回 REGISTER_STATUS = STATUS_REVIEW
REGISTER_STATUS = "已定稿"
STATUS_FINAL = "已定稿"
DEFAULT_DIRNAME = "新闻联播速览"
DRAFT_DIR = "产出物"        # 0.1.13 更名（原 草稿/，0.1.9 前为 drafts/）
RAW_DIR = "联播原文"        # 0.1.9 起（原 raw/）
HISTORY_DIR = "历史版本"    # 0.1.9 起新增：--force 重登记时旧稿自动留底


def migrate_legacy(base: pathlib.Path) -> None:
    """0.1.9：把旧的英文子文件夹（drafts/raw）改名为中文，并同步 state.json 里的路径。幂等。"""
    pairs = [("drafts", DRAFT_DIR), ("raw", RAW_DIR), ("草稿", DRAFT_DIR)]
    moved = []
    for old, new in pairs:
        src, dst = base / old, base / new
        if src.exists() and src.is_dir() and not dst.exists():
            src.rename(dst)
            moved.append(f"{old}->{new}")
    if not moved:
        return
    sp = base / "state.json"
    if sp.exists():
        import re
        text = sp.read_text(encoding="utf-8")
        for old, new in pairs:
            # 0.1.13：用正则按路径段替换，兼容混合分隔符（如 /drafts\ 历史脏路径）
            text = re.sub(rf"[\\/]{re.escape(old)}[\\/]", f"\\\\{new}\\\\", text)
        sp.write_text(text, encoding="utf-8")
    print(json.dumps({"migrated": moved}, ensure_ascii=False), file=sys.stderr)


def data_dir(cli_dir: str | None) -> pathlib.Path:
    # 0.1.9：删除 cwd/Documents 静默兜底——落点不确定时宁可报错让调用方自纠，
    # 也绝不在"猜测的路径"下静默新建目录（跨终端落点漂移的根因）。
    if cli_dir:
        base = pathlib.Path(cli_dir)
    elif os.environ.get("XWLB_BRIEFING_DATA_DIR"):
        base = pathlib.Path(os.environ["XWLB_BRIEFING_DATA_DIR"])
    else:
        print(json.dumps({
            "error": "data_dir_unspecified",
            "hint": "未指定业务数据目录，已拒绝落盘。请显式传 --data-dir \"<当前工作区>/新闻联播速览\"，"
                    "或设置环境变量 XWLB_BRIEFING_DATA_DIR。禁止从记忆/历史会话推断路径。",
        }, ensure_ascii=False))
        sys.exit(1)
    migrate_legacy(base)
    (base / DRAFT_DIR).mkdir(parents=True, exist_ok=True)
    (base / RAW_DIR).mkdir(parents=True, exist_ok=True)
    return base


def load_state(base: pathlib.Path) -> dict:
    p = base / "state.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {"entries": {}, "gaps": []}


def save_state(base: pathlib.Path, state: dict) -> None:
    (base / "state.json").write_text(
        json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def cmd_status(args, base: pathlib.Path, state: dict) -> None:
    today = datetime.now().strftime("%Y%m%d")
    out = {"data_dir": str(base), "today": today,
           "today_entry": state["entries"].get(today),
           "today_gap": next((g for g in state["gaps"] if g["date"] == today), None),
           "recent_entries": dict(list(sorted(state["entries"].items(), reverse=True))[:5]),
           "open_gaps": [g for g in state["gaps"] if g["date"] not in state["entries"]]}
    print(json.dumps(out, ensure_ascii=False, indent=2))


def _sha256(path: pathlib.Path) -> str:
    import hashlib
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _archive_old(base: pathlib.Path, date: str, entry: dict) -> dict | None:
    """--force 重登记前，把旧稿复制进 历史版本/<日期>/<时间戳>_文件名。返回留痕信息。"""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dst_dir = base / HISTORY_DIR / date
    copied = []
    for f in entry.get("files", []):
        p = pathlib.Path(f)
        if p.exists():
            dst_dir.mkdir(parents=True, exist_ok=True)
            dst = dst_dir / f"{ts}_{p.name}"
            dst.write_bytes(p.read_bytes())
            copied.append(str(dst))
    if not copied:
        return None
    return {"archived_at": datetime.now().isoformat(timespec="seconds"),
            "status": entry.get("status"), "files": entry.get("files"),
            "copies": copied}


def cmd_register(args, base: pathlib.Path, state: dict) -> None:
    files = [f for f in args.files.split(";") if f.strip()]
    missing = [f for f in files if not pathlib.Path(f).exists()]
    if missing:
        print(json.dumps({"error": "file_not_found", "missing": missing},
                         ensure_ascii=False))
        sys.exit(1)
    existing = state["entries"].get(args.date)
    if existing and not getattr(args, "force", False):
        # 0.1.9：同日期默认拒绝重登记——防静默覆盖、防已定稿被静默打回。
        print(json.dumps({"error": "already_registered", "date": args.date,
                          "status": existing.get("status"),
                          "hint": "该日期已有稿件。仅当用户明确说\u201c删除旧稿重新出\u201d时，"
                                  "AI 才可加 --force 重登记（旧稿会自动留底到 历史版本/）。"},
                         ensure_ascii=False))
        sys.exit(1)
    entry = {"status": STATUS_REVIEW, "files": files, "method": args.method,
             "registered_at": datetime.now().isoformat(timespec="seconds"),
             "sha256": [_sha256(pathlib.Path(f)) for f in files]}
    if existing and args.force:
        entry["history"] = existing.get("history", [])
        archived = _archive_old(base, args.date, existing)
        if archived:
            entry["history"].append(archived)
            entry["note"] = "force re-register；旧稿已留底 历史版本/"
    entry["status"] = REGISTER_STATUS  # 0.1.13 人工复核暂停：登记即可推送
    state["entries"][args.date] = entry
    # 该日期如有缺口记录则视为已补
    state["gaps"] = [g for g in state["gaps"] if g["date"] != args.date]
    save_state(base, state)
    out = {"ok": True, "date": args.date, "status": REGISTER_STATUS,
           "files": files}
    if existing:
        out["note"] = "force re-register；旧稿已留底 历史版本/"
    print(json.dumps(out, ensure_ascii=False))


def cmd_finalize(args, base: pathlib.Path, state: dict) -> None:
    entry = state["entries"].get(args.date)
    if not entry:
        print(json.dumps({"error": "no_entry", "date": args.date}, ensure_ascii=False))
        sys.exit(1)
    if entry["status"] == STATUS_FINAL:
        print(json.dumps({"ok": True, "date": args.date, "status": STATUS_FINAL,
                          "note": "already_final"}, ensure_ascii=False))
        return
    renamed = []
    for f in entry["files"]:
        p = pathlib.Path(f)
        if STATUS_REVIEW in p.name:
            np = p.with_name(p.name.replace(STATUS_REVIEW, STATUS_FINAL))
            p.rename(np)
            renamed.append(str(np))
        else:
            renamed.append(str(p))
    entry["files"] = renamed
    entry["status"] = STATUS_FINAL
    entry["finalized_at"] = datetime.now().isoformat(timespec="seconds")
    save_state(base, state)
    print(json.dumps({"ok": True, "date": args.date, "status": STATUS_FINAL,
                      "files": renamed}, ensure_ascii=False))


def cmd_gap(args, base: pathlib.Path, state: dict) -> None:
    state["gaps"].append({"date": args.date, "reason": args.reason,
                          "at": datetime.now().isoformat(timespec="seconds")})
    save_state(base, state)
    print(json.dumps({"ok": True, "date": args.date, "reason": args.reason},
                     ensure_ascii=False))


def cmd_feedback(args, base: pathlib.Path, state: dict) -> None:
    p = base / "口径反馈登记.md"
    with p.open("a", encoding="utf-8") as f:
        f.write(f"- {datetime.now().strftime('%Y-%m-%d %H:%M')} {args.text}\n")
    print(json.dumps({"ok": True, "file": str(p)}, ensure_ascii=False))


SLUG = "xwlb-briefing"
NAMESPACE = "indiv-ray"


def cmd_self_update(args, base: pathlib.Path, state: dict) -> None:
    """0.1.17：技能自更新——skillhub install（带命名空间）+ @namespace 目录拍平 + 版本回显。

    用法：python briefing_ops.py self-update   （--skill-dir 缺省=本脚本所在技能目录）
    输出 JSON：成功 {"ok":true,"version":"x.y.z"}；失败 {"ok":false,"step":…,..} 且退出码 2。
    0.1.18 保护闸：若目标目录是开发源码（SKILL.md 含「负责人」标记），拒绝覆盖以防自毁。
    """
    import re as _re
    import shutil
    import subprocess
    skill_dir = pathlib.Path(args.skill_dir).resolve()
    sk = skill_dir / "SKILL.md"
    if sk.exists() and "负责人" in sk.read_text(encoding="utf-8"):
        print(json.dumps({"ok": False, "step": "dev-source-guard",
                          "hint": "检测到开发源码目录（canonical），self-update 拒绝覆盖；请对已安装副本运行"}, ensure_ascii=False))
        sys.exit(2)
    root = skill_dir.parent
    try:
        # 解析 CLI：Windows 下是 skillhub.cmd/.exe；.cmd/.bat 须经 cmd /c 启动
        exe = None
        for cand in ("skillhub", "skillhub.exe", "skillhub.cmd", "skillhub.bat"):
            exe = shutil.which(cand)
            if exe:
                break
        if not exe:
            home = pathlib.Path.home() / ".local" / "bin"
            for name in ("skillhub", "skillhub.exe", "skillhub.cmd"):
                c = home / name
                if c.exists():
                    exe = str(c)
                    break
        if not exe:
            print(json.dumps({"ok": False, "step": "cli-missing",
                              "hint": "skillhub CLI 不存在"}, ensure_ascii=False))
            sys.exit(2)
        cmd = ["cmd", "/c", exe] if exe.lower().endswith((".cmd", ".bat")) else [exe]
        p = subprocess.run(
            cmd + ["install", SLUG, "--namespace", NAMESPACE, "--force", "--json"],
            cwd=str(root), capture_output=True, text=True, timeout=300,
        )
        out = (p.stdout or "").strip()
        m = _re.search(r"\{.*\}", out)
        if p.returncode != 0 or not m:
            print(json.dumps({"ok": False, "step": "install", "returncode": p.returncode,
                              "stdout": out[-400:], "stderr": (p.stderr or "")[-400:]},
                             ensure_ascii=False))
            sys.exit(2)
        info = json.loads(m.group(0))
        target = pathlib.Path(info.get("targetDir", ""))
        if not target.is_dir():
            print(json.dumps({"ok": False, "step": "locate", "targetDir": str(target)},
                             ensure_ascii=False))
            sys.exit(2)
        # 拍平：install 落位为 <root>/@indiv-ray/xwlb-briefing，把内容覆盖进技能目录
        shutil.copytree(target, skill_dir, dirs_exist_ok=True)
        ver = ""
        if sk.exists():
            mm = _re.search(r"^version:\s*(\S+)", sk.read_text(encoding="utf-8"), _re.M)
            ver = mm.group(1) if mm else ""
        print(json.dumps({"ok": True, "version": ver}, ensure_ascii=False))
    except FileNotFoundError:
        print(json.dumps({"ok": False, "step": "cli-missing",
                          "hint": "skillhub CLI 不存在"}, ensure_ascii=False))
        sys.exit(2)
    except subprocess.TimeoutExpired:
        print(json.dumps({"ok": False, "step": "timeout"}, ensure_ascii=False))
        sys.exit(2)


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--skill-dir",
                    default=str(pathlib.Path(__file__).resolve().parent.parent),
                    help="技能目录；缺省=本脚本所在的 xwlb-briefing 目录")
    ap.add_argument("--data-dir", default=None,
                    help="业务数据目录；缺省按 环境变量 > 当前工作区/新闻联播速览 > Documents 解析")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status")
    r = sub.add_parser("register")
    r.add_argument("--date", required=True)
    r.add_argument("--method", default="manual", choices=["manual", "auto"])
    r.add_argument("--files", required=True)
    r.add_argument("--force", action="store_true",
                   help="覆盖已有登记；仅当用户明确说\u201c删除旧稿重新出\u201d时才可使用")
    f = sub.add_parser("finalize")
    f.add_argument("--date", required=True)
    g = sub.add_parser("gap")
    g.add_argument("--date", required=True)
    g.add_argument("--reason", required=True)
    fb = sub.add_parser("feedback")
    fb.add_argument("--text", required=True)
    sub.add_parser("self-update")
    args = ap.parse_args()

    if args.cmd == "self-update":
        cmd_self_update(args, pathlib.Path("."), {})
        return
    base = data_dir(args.data_dir)
    state = load_state(base)
    {"status": cmd_status, "register": cmd_register, "finalize": cmd_finalize,
     "gap": cmd_gap, "feedback": cmd_feedback}[args.cmd](args, base, state)


if __name__ == "__main__":
    main()
