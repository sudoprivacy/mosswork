# -*- coding: utf-8 -*-
"""抓取央视网《新闻联播》某日期当期：条目列表 + 各条目文字稿。
用法: python fetch_xwlb.py 20260911 20260912 20260913
输出: 每天一个 JSON（条目标题/链接/正文），写到 stdout 或 --outdir。
"""
import argparse
import json
import re
import sys
import time
import urllib.request

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}


def fetch(url: str) -> str:
    req = urllib.request.Request(url, headers=UA)
    raw = urllib.request.urlopen(req, timeout=30).read()
    for enc in ("utf-8", "gbk"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def get_day_items(date8: str):
    """day 页: https://tv.cctv.com/lm/xwlb/day/YYYYMMDD.shtml"""
    url = f"https://tv.cctv.com/lm/xwlb/day/{date8}.shtml"
    html = fetch(url)
    y = date8[:4]; m = date8[4:6]; d = date8[6:]
    pat = re.compile(
        r'href="(https://tv\.cctv\.com/%s/%s/%s/VIDE[^"]+\.shtml)"[^>]*?title="([^"]+)"'
        % (y, m, d)
    )
    seen, items = set(), []
    for u, t in pat.findall(html):
        if u in seen:
            continue
        seen.add(u)
        t = t.replace("完整版", "").strip().strip("[]视频").strip()
        items.append({"url": u, "title": t})
    return url, items


def get_item_text(url: str) -> str:
    """条目页正文: 优先 content_area（完整文字稿），回退 video_brief（一句话简介）。"""
    html = fetch(url)
    html = re.sub(r"<(script|style)[^>]*>.*?</\1>", "", html, flags=re.S)
    m = re.search(r'<div class="content_area"[^>]*>(.*?)</div>', html, re.S)
    if m:
        paras = [re.sub(r"<[^>]+>", "", p).strip()
                 for p in re.findall(r"<p[^>]*>(.*?)</p>", m.group(1), re.S)]
        paras = [re.sub(r"\s+", " ", p) for p in paras if p]
        if paras:
            return "\n".join(paras)
    m = re.search(r'<div class="video_brief">(.*?)</div>', html, re.S)
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", m.group(1))).strip() if m else ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dates", nargs="+", help="YYYYMMDD 一个或多个")
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--no-text", action="store_true", help="只抓条目列表不抓正文")
    args = ap.parse_args()

    for date8 in args.dates:
        day_url, items = get_day_items(date8)
        print(f"== {date8}: {len(items)} 条, day页 {day_url}", file=sys.stderr)
        if not args.no_text:
            for i, it in enumerate(items):
                try:
                    it["text"] = get_item_text(it["url"])
                except Exception as e:  # 保留异常信息，不静默
                    it["text"] = ""
                    it["error"] = f"{type(e).__name__}: {e}"
                print(f"  [{i+1}/{len(items)}] {len(it.get('text',''))}字 {it['title'][:30]}", file=sys.stderr)
                time.sleep(0.4)  # 温和限速
        out = {"date": date8, "day_url": day_url, "items": items}
        line = json.dumps(out, ensure_ascii=False)
        if args.outdir:
            import pathlib
            pathlib.Path(args.outdir).mkdir(parents=True, exist_ok=True)
            path = f"{args.outdir}/xwlb_{date8}.json"
            with open(path, "w", encoding="utf-8") as f:
                f.write(line)
            print(path, file=sys.stderr)
        else:
            print(line)


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    main()
