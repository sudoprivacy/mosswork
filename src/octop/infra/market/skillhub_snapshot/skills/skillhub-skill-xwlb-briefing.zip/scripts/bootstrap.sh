#!/usr/bin/env bash
# bootstrap.sh -- xwlb-briefing 环境自举（0.1.20，幂等；Linux 沙箱用）
# 用法：bash bootstrap.sh   （通常由云端提示词第 0 步在解压后的包内调用）
# 输出：末行体检 JSON {"bootstrap":"done","version":..,"browser":..,"fonts":..,"data_dir":..}
set -u
export TZ=Asia/Shanghai
SKILL_SRC="$(cd "$(dirname "$0")/.." && pwd)"        # 包内技能根（SKILL.md 所在目录）
SKILL_DST="/workspace/skills/xwlb-briefing"
DATA_DIR="/workspace/新闻联播速览"

mkdir -p /workspace/skills "$DATA_DIR"
rm -rf "$SKILL_DST" && cp -r "$SKILL_SRC" "$SKILL_DST"   # 每次引导都落到最新包=天然自更新
# 0.1.21 ast 自检闸：直连下载端点不过审闸门，坏包必须在这里被拦下
python3 -c "import ast,glob; [ast.parse(open(f,encoding='utf-8').read()) for f in glob.glob('$SKILL_DST/scripts/*.py')]" 2>/dev/null \
  || { echo '{"bootstrap":"syntax-error","hint":"包内脚本 ast 解析失败，拒绝使用"}'; exit 2; }

python3 -m pip install --quiet pillow numpy playwright 2>/dev/null
python3 -m playwright install chromium >/dev/null 2>&1 || echo '{"warn":"playwright chromium install failed"}'
(apt-get install -y -qq fonts-noto-cjk >/dev/null 2>&1 || sudo apt-get install -y -qq fonts-noto-cjk >/dev/null 2>&1) \
  || echo '{"warn":"fonts-noto-cjk install failed; 中文可能显示为方块"}'

VERSION=$(grep -m1 '^version:' "$SKILL_DST/SKILL.md" | awk '{print $2}')
BROWSER=$(command -v chromium || command -v chromium-browser || command -v google-chrome || echo playwright-bundled)
FONTS=$(fc-list :lang=zh 2>/dev/null | head -1 | cut -d: -f1)
[ -n "$FONTS" ] && FONTS="ok" || FONTS="missing"
echo "{\"bootstrap\":\"done\",\"version\":\"$VERSION\",\"browser\":\"$BROWSER\",\"fonts\":\"$FONTS\",\"data_dir\":\"$DATA_DIR\"}"
