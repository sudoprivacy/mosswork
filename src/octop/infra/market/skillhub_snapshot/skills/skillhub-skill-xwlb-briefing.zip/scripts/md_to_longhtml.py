# -*- coding: utf-8 -*-
"""md_to_longhtml.py — 负责人版 Markdown → 手机长图 HTML（0.1.4 新增）。

用法：
  python md_to_longhtml.py <负责人版.md> [--out 输出.html]

输入：references/briefing-discipline.md 定义的负责人版模板
（h1 标题 / > 期数行 / 日期行 / **N｜标题**：事实 段落 / 持续跟踪表 / 来源列表）。
输出：竖版长图 HTML（750px 宽，手机浏览器打开后截图即可推送），与输入同目录。
命名：`2026-09-16_负责人版_待复核.md` → `2026-09-16_负责人版_长图_待复核.html`
（状态后缀保留，briefing_ops.py finalize 会自动连带重命名）。

仅用标准库，不依赖第三方包。
"""
import argparse
import html
import json
import pathlib
import re
import sys

STATUS_SUFFIXES = ("待复核", "已定稿")
# 0.1.6 命名：状态后缀移出文件名，角色名映射为可读标题
TITLE_TOKENS = {"_负责人版": " 新闻联播要闻速览", "_工作底稿": " 新闻联播政策解读"}

CSS = """
*{margin:0;padding:0;box-sizing:border-box}
body{background:#e8eaed;font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#26282b}
.page{width:750px;margin:0;background:#fff;min-height:100vh;padding-bottom:48px}
.hero{background:linear-gradient(160deg,#8f1d22,#b42a30);color:#fff;padding:130px 44px 40px}
.hero h1{font-size:46px;letter-spacing:2px;line-height:1.4}
.date{margin-top:18px;font-size:27px;opacity:.92}
.sub{margin-top:10px;font-size:24px;opacity:.85;line-height:1.6}
.content{padding:36px 44px 0}
h2.sec{font-size:34px;color:#8f1d22;margin:44px 0 22px;padding-left:20px;border-left:10px solid #b42a30;line-height:1.4}
.card{background:#f7f8fa;border-radius:16px;padding:28px 30px;margin-bottom:22px}
.card .t{font-size:30px;font-weight:700;color:#8f1d22;line-height:1.55;margin-bottom:12px}
.card .b{font-size:28px;line-height:1.8;color:#333}
.card.lead{background:#fdf3f3;border:2px solid #e5b8ba}
p.plain{font-size:28px;line-height:1.8;margin-bottom:20px}
table{width:100%;border-collapse:collapse;margin:8px 0 24px;font-size:26px}
th{background:#8f1d22;color:#fff;padding:14px;font-weight:600;text-align:left}
td{border:1px solid #e3dadb;padding:14px;line-height:1.6;vertical-align:top}
ul{margin:0 0 24px 40px}
li{font-size:26px;line-height:1.8;color:#444;margin-bottom:10px}
a{color:#b42a30;word-break:break-all}
"""


_LINK_RE = re.compile(
    r"\[([^\]]+)\]\((https?://[^)\s]+)\)"          # [文字](链接)
    r"|(https?://[^\s<>\"')\uff09]+)"               # 裸 URL（含中文右括号前截断）
)


def _link_sub(m: re.Match) -> str:
    if m.group(1):
        return f'<a href="{m.group(2)}">{m.group(1)}</a>'
    return f'<a href="{m.group(3)}">{m.group(3)}</a>'


def inline(s: str) -> str:
    """先转义再渲染行内格式：[文字](链接)、裸 URL、**加粗**。"""
    s = html.escape(s)
    s = _LINK_RE.sub(_link_sub, s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
    return s


def output_name(src: pathlib.Path) -> pathlib.Path:
    """新命名：`2026-09-19 新闻联播要闻速览.md` → `2026-09-19 新闻联播要闻速览_长图.html`；
    兼容旧命名（含 _负责人版/_工作底稿/状态后缀）输入。"""
    stem = src.stem
    for s in STATUS_SUFFIXES:
        if stem.endswith(s):
            stem = stem[: -len(s) - 1]
    for old, new in TITLE_TOKENS.items():
        stem = stem.replace(old, new)
    return src.with_name(f"{stem}_长图.html")


def render(md_text: str) -> str:
    lines = md_text.splitlines()
    title = sub = date_str = ""
    content = []
    for ln in lines:
        s = ln.strip()
        if s.startswith("# ") and not title:
            title = s[2:].strip()
            continue
        if s.startswith("> ") and not sub:
            sub = s[2:].strip()
            continue
        if not date_str and not content and re.match(r"^\d{4}年\d{1,2}月\d{1,2}日", s):
            date_str = s
            continue
        content.append(ln)

    body: list[str] = []
    para: list[str] = []
    table: list[str] = []
    ul: list[str] = []

    def flush_para() -> None:
        if not para:
            return
        p = " ".join(para).strip()
        m = re.match(r"^\*\*(.+?)\*\*[：:]\s*(.*)$", p, re.S)
        if m:
            t, b = m.group(1), m.group(2)
            cls = "card lead" if "今日主线" in t else "card"
            body.append(f'<div class="{cls}"><div class="t">{inline(t)}</div>'
                        f'<div class="b">{inline(b)}</div></div>')
        else:
            body.append(f'<p class="plain">{inline(p)}</p>')
        para.clear()

    def flush_table() -> None:
        if not table:
            return
        rows = [r for r in table if not re.match(r"^\|[\s:|-]+\|$", r.strip())]
        parsed = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows]
        if parsed:
            thead = "<tr>" + "".join(f"<th>{inline(c)}</th>" for c in parsed[0]) + "</tr>"
            trows = "".join("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in row)
                            + "</tr>" for row in parsed[1:])
            # 0.1.21：四列表（跟踪表）钉死列宽，防起点列被挤成一字一行
            colgroup = ""
            if len(parsed[0]) == 4:
                colgroup = ('<colgroup><col style="width:16%"><col style="width:36%">'
                            '<col style="width:26%"><col style="width:22%"></colgroup>')
            body.append(f"<table>{colgroup}<thead>{thead}</thead><tbody>{trows}</tbody></table>")
        table.clear()

    def flush_ul() -> None:
        if ul:
            body.append("<ul>" + "".join(f"<li>{inline(i)}</li>" for i in ul) + "</ul>")
            ul.clear()

    for ln in content:
        s = ln.strip()
        if s.startswith("|"):
            flush_para()
            flush_ul()
            table.append(s)
        elif s.startswith("- "):
            flush_para()
            flush_table()
            ul.append(s[2:].strip())
        elif s.startswith("## "):
            flush_para()
            flush_table()
            flush_ul()
            body.append(f'<h2 class="sec">{inline(s[3:].strip())}</h2>')
        elif not s:
            flush_para()
            flush_table()
            flush_ul()
        else:
            flush_table()
            flush_ul()
            para.append(s)
    flush_para()
    flush_table()
    flush_ul()

    return (
        '<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
        f"<title>{html.escape(title)}</title>\n<style>{CSS}</style>\n</head>\n<body>\n"
        '<div class="page">\n'
        f'<header class="hero"><h1>{inline(title)}</h1>'
        f'<div class="date">{inline(date_str)}</div>'
        + (f'<div class="sub">{inline(sub)}</div>' if sub else '') + '</header>\n'
        f'<main class="content">\n{"".join(body)}\n</main>\n'
        "</div>\n</body>\n</html>\n"
    )


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="负责人版 md → 手机长图 HTML")
    ap.add_argument("input", help="负责人版 Markdown 路径")
    ap.add_argument("--out", default=None, help="输出 HTML 路径（缺省同目录自动命名）")
    args = ap.parse_args()
    src = pathlib.Path(args.input)
    if not src.exists():
        print(json.dumps({"error": "input_not_found", "input": str(src)},
                         ensure_ascii=False))
        sys.exit(1)
    out = pathlib.Path(args.out) if args.out else output_name(src)
    out.write_text(render(src.read_text(encoding="utf-8")), encoding="utf-8")
    print(json.dumps({"ok": True, "out": str(out), "bytes": out.stat().st_size},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
