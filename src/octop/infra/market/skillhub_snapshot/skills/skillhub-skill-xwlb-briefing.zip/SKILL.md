---
name: skillhub-skill-xwlb-briefing
description: "This skill MUST trigger whenever the user mentions \\u65b0\\u95fb\\u8054\\u64ad (CCTV News Broadcast / Xinwen Lianbo) or \\u8054\\u64ad in ANY form or context, e.g. \\u65b0\\u95fb\\u8054\\u64ad\\u901f\\u89c8, \\u65b0\\u95fb\\u8054\\u64ad\\u8981\\u95fb\\u901f\\u89c8, \\u65b0\\u95fb\\u8054\\u64ad\\u89e3\\u8bfb, \\u65b0\\u95fb\\u8054\\u64ad\\u65e5\\u62a5, \\u65b0\\u95fb\\u8054\\u64ad\\u6c47\\u62a5, \\u65b0\\u95fb\\u8054\\u64ad\\u7b80\\u62a5, \\"
---

# XWLB Briefing (CCTV News Broadcast Daily Briefing)

## Core principle

Every fact and number in a briefing must come from the fetched source text of that day's broadcast. Never fabricate, never fill gaps with guesses, never predict trends. Unverifiable items must be marked as pending verification. Sending anything to the decision-maker is a human action and is out of scope for this skill.

## Defaults

- Data lives OUTSIDE this skill directory. Resolution order (0.1.9): `--data-dir` argument > env `XWLB_BRIEFING_DATA_DIR` > **hard error (`data_dir_unspecified`)**. There is NO cwd/Documents fallback — never guess a path from memory or past sessions; if the script errors, pass the explicit workspace path it asks for.
- When invoked inside a WorkBuddy session, ALWAYS pass `--data-dir "<workspace>/新闻联播速览"` so every generated file lands in the user's workspace, where it is visible in the workspace file view. After generating, finalizing, or recording feedback, quote the workspace-relative path (e.g. 「文件在工作区的『新闻联播速览』文件夹」) in the reply.
- Layout (0.1.13): `产出物/`（**只放交付物**——默认仅 PNG）, `中间产物/<YYYY-MM-DD>/`（负责人版 md + 长图 HTML 等管线中间文件）, `联播原文/`（raw JSON）, `历史版本/`（--force 重登记留底）, `state.json`, `口径反馈登记.md`. Legacy `drafts/`+`raw/` are auto-renamed on first run.
- Locate an available Python 3.10+ runtime. Scripts use the standard library only, no third-party packages.
- **Default deliverable = the long-image PNG only, and it is the ONLY file in `产出物/` (0.1.13, hard rule)**. Pipeline intermediates (decision-maker Markdown, long-image HTML) are generated into `中间产物/<YYYY-MM-DD>/` — never into `产出物/`. After the PNG renders, MOVE the PNG into `产出物/`. The working draft (`新闻联播政策解读.md`) is NOT generated unless the user explicitly asks for it (then it goes into `产出物/` too, since it is a deliverable on request). Optional formats on request: 「要文字版 / 要md」→ move the md from `中间产物/` into `产出物/` and deliver; 「要html」→ same for the html; 「要解读」→ compose the working draft into `产出物/`, validate, and re-register with the updated file list.
- **Reply discipline (0.1.12)**: after generation the reply is ONE line — the PNG path + 可直接推送. Never restate the briefing content, main line, item counts, or file dumps unless the user asks.
- Status (0.1.13): 人工复核暂停——联播条目已过央视人工审核，登记即「已定稿」，产物可直接推送；复核流程保留，恢复时改回。One review owner per day when review is active.

## Environment requirements (0.1.20)

- Python 3.9+ with Pillow + numpy (PNG crop)；渲染用 chromium 系无头浏览器（Windows Edge / Linux chromium / `$XWLB_BROWSER` 环境变量均可），**中文需 CJK 字体**（Linux: `fonts-noto-cjk`），时区须为北京时间（`TZ=Asia/Shanghai`）。
- Linux/沙箱首次使用：执行包内 `scripts/bootstrap.sh`（幂等自举：装依赖+字体+自安装到 /workspace/skills，末行输出体检 JSON）。推荐入口=云端提示词第 0 步的直连下载三行式，CLI 非必需。

## Context isolation (0.1.9/0.1.10 生成隔离纪律)

Generation must be reproducible on ANY terminal regardless of what memories that terminal holds:

- Information sources (0.1.10): (a) the day's raw JSON in `联播原文/`, (b) **historical broadcast pages fetched on demand for origin-tracing** (day-page URL pattern, any date), (c) `references/briefing-discipline.md`. Do NOT pull in company background, business figures, or project context from terminal memory, SOUL/USER files, or past sessions. Local historical archives are only an acceleration cache — never the basis of origin-tracing.
- 【相关】 in the working draft stays at the neutral「对企业的解读」level the discipline defines — do not inject company-specific details the rules don't contain.
- The decision-maker version uses a neutral official-document tone; it must not inherit the terminal's persona.
- After writing the decision-maker Markdown, ALWAYS run `scripts/validate_briefing.py` on it (see Action 1 step 6) — errors must be zero before registering. The working draft, when generated on request, must pass validation the same way.

## Action 1: Generate today's briefing (出今天的新闻联播速览)

1. Determine today's date as YYYYMMDD. Check state first via `status`; if today's drafts already exist, do NOT regenerate — show the existing drafts and remind the user that regeneration requires their explicit phrase 「删除旧稿重新出」 (then and only then re-register with `--force`; the old files are auto-archived to `历史版本/`).
2. Fetch the source text:

   ```text
   python scripts/fetch_xwlb.py YYYYMMDD --outdir <data-dir>/联播原文
   ```

   On failure, retry ONCE. If it still fails (typical before ~19:30, when the day's broadcast has not aired yet), do ALL of the following instead of a bare failure:
   a. Record a gap with the ops script (`gap --date YYYYMMDD --reason "..."`).
   b. Tell the user plainly: 今天的联播尚未播出或数据未就绪，今天的速览暂时无法生成；今晚 19:40 后再试即可。
   c. Run `status` and list the dates that DO have briefings (e.g. 「目前已有：9月16日（待复核）」), offering to open any of them or the latest one right away.
   Never produce a briefing from memory or web search substitutes. The skill must give a useful answer at ANY hour of the day — testing outside broadcast hours is expected behavior, not an error case.
3. Read the fetched JSON in `联播原文/`. BEFORE composing, run **tracking-table daily re-estimation + origin-tracing (0.1.15)**: the tracking table is a DYNAMIC hotspot surface — the day's table = events still mentioned in TODAY's raw JSON (an event absent from 3 consecutive generations auto-exits, archived as one cooling line in `中间产物/事件档案/`). For each event **entering the table for the first time**, determine its true start date by **fetching historical day pages online** (`fetch_xwlb.py YYYYMMDD`) in two stages: doubling probes (T-3 → T-7 → T-14 → T-28, ≤4 fetches, using the event's keyword group incl. aliases) to bracket the first no-mention day, then binary search inside the bracket to the exact first-appearance day D (D mentioned AND D-1 not mentioned). Write the result (start date + keyword group) into `中间产物/事件档案/<事件名>.md`; on later days NEVER re-trace — only update 最新进展/观察点 from the day's JSON. 30 days is a protection cap, not the event boundary: only when keywords hit EVERY day within the cap write `X月X日（检索窗口内最早出现日）`; normally write the bare true start date. Local archives/last issue accelerate but must NEVER cause start=today or skipped tracing — origin-tracing must work online in any environment on its very first run. Then generate the **decision-maker Markdown ONLY** (0.1.12: the working draft is on-request) into the data dir's `中间产物/<YYYY-MM-DD>/` (0.1.13: intermediates NEVER go into `产出物/`), following `references/briefing-discipline.md` AND the Context isolation rules above strictly. Tracking-table columns (0.1.15): `事项 | 最新进展（今日） | 后续观察点 | 起点`. Note the 0.1.6 naming: no status suffix in filenames — status lives only in state.json.
   - `<data-dir>/中间产物/<YYYY-MM-DD>/<YYYY-MM-DD> 中央新闻联播要闻速览.md` (intermediate — the PNG is composed from it)
   - `<data-dir>/中间产物/<YYYY-MM-DD>/<YYYY-MM-DD> 新闻联播政策解读.md` — **only when the user asked** for 解读/文字版 in this same invocation (deliverable on request — this one goes to `产出物/`)
4. Convert the decision-maker version into the phone long-image HTML:

   ```text
   python scripts/md_to_longhtml.py "<data-dir>/中间产物/<YYYY-MM-DD>/<YYYY-MM-DD> 中央新闻联播要闻速览.md"
   ```

   This produces `<YYYY-MM-DD> 中央新闻联播要闻速览_长图.html` in the same `中间产物/<YYYY-MM-DD>/` folder. If it fails, say so in one line — do not block the briefing on the long image.
5. Render the long-image PNG (the push artifact). IMPORTANT: the crop step needs Pillow + numpy, which the managed WorkBuddy Python lacks — run this step with the venv interpreter (path below is the verified one on this machine):

   ```text
   <你的venv解释器路径>\Scripts\python.exe（需含 Pillow + numpy） scripts/render_longhtml_png.py "<data-dir>/中间产物/<YYYY-MM-DD>/<YYYY-MM-DD> 中央新闻联播要闻速览_长图.html"
   ```

   This produces `<YYYY-MM-DD> 中央新闻联播要闻速览.png` next to the HTML (Edge headless, 774px viewport, crop to 1500px wide + 140px bottom safe area — 0.1.7 safe-area params are baked in). **Then MOVE the PNG into `<data-dir>/产出物/`** (0.1.13: 产出物 holds deliverables only). If Edge or the PNG step fails, keep the HTML in `中间产物/` and reply with the HTML path in one line — do not block the briefing.
6. Validate the decision-maker Markdown (0.1.9, mandatory — errors must be zero). If the working draft was generated on request, validate it too:

   ```text
   python scripts/validate_briefing.py "<data-dir>/中间产物/<YYYY-MM-DD>/<YYYY-MM-DD> 中央新闻联播要闻速览.md"
   ```

   Fix any reported error (it names the problem) and re-run until `ok: true`. If a `register` call later fails with `already_registered`, that means the date already has briefing files: show them and ask the user — do NOT add `--force` unless the user explicitly says 「删除旧稿重新出」.
7. Register the run (0.1.13: PNG from `产出物/`, md+html from `中间产物/<YYYY-MM-DD>/`; append the working draft from `产出物/` when it was generated on request):

   ```text
   python scripts/briefing_ops.py --skill-dir <this-skill-directory> --data-dir "<workspace>/新闻联播速览" register --date YYYYMMDD --method manual --files "<png_in_产出物>;<decision-maker_md_in_中间产物>;<longimage_html_in_中间产物>"
   ```

8. Reply in ONE line (0.1.12 reply discipline): the PNG path (in `产出物/`) + 可直接推送. Nothing else — no main line, no item count, no file dumps, no content restatement.

## Action 2: Open a briefing (打开今天的速览 / 打开X月X日的速览 / 打开最新的速览)

1. Run `status` (with the same `--data-dir`). If the user named a date, present that day's artifact; otherwise present the latest entry. For the decision-maker version prefer the long-image PNG when it exists (that is the format pushed to the decision-maker); use the HTML for phone-screenshot fallback and the Markdown for content-level review. Working draft if asked.
2. If the requested date has no briefing but has a gap record, say so plainly with the recorded reason, then list the dates that DO have briefings and offer to open one.
3. If the user just says 「打开速览」 without a date, show the latest available briefing and mention its date explicitly.

## Action 3: Revise (user describes the change in words)

1. Restate the intended change in one sentence and wait for confirmation before editing.
2. Apply the edit to the draft file. Never alter a number or fact unless the user explicitly says so; if the user asks to change a fact, first check the raw JSON in `raw/` and report what the source actually says.
3. After editing, quote the changed sentence so the user can verify. If the edit touched a decision-maker-version Markdown that has a long-image HTML sibling, re-run `md_to_longhtml.py` on it so the two stay in sync; if a PNG sibling exists too, re-run `render_longhtml_png.py` (venv interpreter, see Action 1 step 5) and report the regenerated paths.

## Action 4: Finalize (复核完成)

1. Run:

   ```text
   python scripts/briefing_ops.py --skill-dir <this-skill-directory> --data-dir "<workspace>/新闻联播速览" finalize --date YYYYMMDD
   ```

2. Report the finalized file paths and remind the user: sending to the decision-maker is done by a human, outside this skill.

## Feedback (记一条口径反馈：...)

1. Append the user's words verbatim:

   ```text
   python scripts/briefing_ops.py --skill-dir <this-skill-directory> --data-dir "<workspace>/新闻联播速览" feedback --text "<user's feedback>"
   ```

2. Confirm what was recorded. Feedback never changes generation rules by itself; rules are recalibrated in batch by the AI team.

## Failure handling

- Fetch failure after one retry: record gap (`gap --date ... --reason "..."`), no briefing, honest reply WITH the graceful fallback of Action 1 step 2 (explain why + list available dates).
- Partial item failures: keep successful items, note failed ones at the top of the draft, never silently drop items.
- Same-day rerun: blocked by `already_registered` (0.1.9) unless the user explicitly asks with the phrase 「删除旧稿重新出」; only then re-register with `--force` (old files are auto-archived to `历史版本/`).
- `data_dir_unspecified` (0.1.9): the script refused to guess a data location. Reply to yourself: pass `--data-dir "<workspace>/新闻联播速览"` explicitly — never infer the path from memory.
- Validation failure: `validate_briefing.py` reports named errors; fix the Markdown and re-run until clean. Never register a briefing with validation errors.
- PNG render failure: non-blocking — reply with the HTML path in the same one-line style. Typical causes: Edge not found, or Pillow/numpy missing under the current Python (re-run with the venv interpreter from Action 1 step 5; the script's error message names it).
- Any-hour usability: outside broadcast hours the skill still works — generate past dates, open available briefings, record feedback. 「无法生成今天的」永远伴随「已有日期清单」一起返回。

## Maintenance

- Keep all business data (drafts, state, raw, feedback) outside this skill directory.
- For rule or template changes, update `references/briefing-discipline.md`, raise `VERSION`, and reinstall. Never edit installed copies directly.
