---
name: skillhub-skill-yetech-sipmetaemu
description: "SIP Meta for Java 代码生成技能。根据用户需求生成调用本地 yet-sip4j-libsip jar 与 libsip.dll 的 Java 代码，用于生成 Meta XML 文件。当用户要求生成 Meta、加文本/图片/水印/表格/线条/底纹/书签/目录页、设置纸张/换页/多SubJob/页眉页脚、或将 Meta 转 PDF 时使用。"
---

# SIP.Meta for Java — Meta 文件生成 Skill

> 本 Skill 用于指导 AI 根据用户需求，调用 SIP.Meta for Java（libsip.dll + yet-sip4j-libsip jar）生成 Meta 文件的 Java 代码。

## 0. 角色与使用规则（AI 必读）

你是一个 **SIP.Meta for Java 代码生成助手**。当用户想"生成 Meta 文件 / 套版 / 报表 / 添加文本图片表格水印书签"等需求时，你必须：

1. **只使用本文档中列出的类、方法与常量**，不要臆造不存在的 API。
2. **默认初始化方式固定为绝对路径加载**（除非用户明确要求其它方式）：
   ```java
   // 根据传入的绝对路径加载 （windows .dll , linux .so）
   SipLibrary.initialize("C://SIP5//libsip.dll");
   ```
   Linux 下传入 `.so` 绝对路径，例如 `SipLibrary.initialize("/opt/sip5/libsip.so");`
3. **坐标/尺寸单位统一为"微米"（1/1000 mm）**。例如 A4 竖向 = 宽 210000、高 297000；10mm = 10000。
4. **回答时在末尾用"参考文档"列出你用到的文章公网链接**（每篇 API 均带 URL），格式见第 17 节。
5. 生成完整可运行的 Java 类（含 `package`、`import`、`main` 方法），遵循第 3 节的标准调用顺序。
6. 若用户需求涉及的 API 在文档中标注"编辑中/取消"，应主动告知并给出替代方案。

---

## 1. 项目介绍

SIP.Meta for Java 是专门对 Meta 文档进行操作的 Java 类库，帮助模板开发人员在 J2SE/J2EE 中生成 Meta 文档，运行环境无需安装任何 SIP 产品。支持 Windows/Linux 跨平台，兼容大部分国产操作系统。支持组件：图层、文本、图片、形状、线条、条形码、二维码、底纹网格、表格、书签等。

- 项目介绍 URL：https://www.yuque.com/u12450864/sipmeta/ndiunq0ylm9h87eh
- 架构图 URL：https://www.yuque.com/u12450864/sipmeta/rd6z81qa7ukb4gtk

## 2. 基本概念

### 2.1 单位

- **基本单位：微米（1/1000 mm）**
- URL：https://www.yuque.com/u12450864/sipmeta/qbyanp0cc9gftrab
- 换算：`1 mm = 1000`；`1 cm = 10000`；A4(210×297mm) = `210000 × 297000`；B5 ≈ `176000 × 250000`。

### 2.2 核心类与包

| 类/包                                           | 说明                                                                                                                |
| --------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| `com.yetech.libsip.SipLibrary`                | 本地库加载入口                                                                                                           |
| `com.yetech.libsip.SipMetaDocument`           | Meta 文档主操作类（核心）                                                                                                   |
| `com.yetech.libsip.exception.LibSipException` | 异常，方法普遍 `throws LibSipException`                                                                                  |
| `com.yetech.libsip.constant.*`                | 常量：`Plex`/`BindSide`/`Orientation`/`Transparent`/`FontWeight`/`FontStyle`/`FlipType`/`PatternStyle`               |
| `com.yetech.libsip.model.*`                   | 模型：`SipJobInfo`/`SipSubjobInfo`/`SipAreaInfo`/`SipDim`/`SipImagePage`/`SipShapeInfo`/`SipLineStyle`/`SipFillInfo` |
| `com.yetech.libsip.util.SipErrUtils`          | `GetLastErrCode()` 获取最近错误码                                                                                        |

## 3. 环境搭建与标准代码骨架

### 3.1 依赖准备

1. 引入 JAR 包：`yet-sip4j-libsip-0.0.1-SNAPSHOT.jar`（Eclipse/IDEA 外部引用方式添加）。URL：https://www.yuque.com/u12450864/sipmeta/krqqxgekq0rpko6i
2. 加载本地库 `libsip.dll`。URL：https://www.yuque.com/u12450864/sipmeta/od41dsao81pu8bfg
3. 第三方依赖库（`freetype.dll`、`libiconv.dll`、`libxml2.dll`）放至 `C:\Windows\System32`。URL：https://www.yuque.com/u12450864/sipmeta/ce1qa7htfgmbrugc
4. 项目创建流程（Eclipse/IDEA）：https://www.yuque.com/u12450864/sipmeta/uanrtolx5gbg4aef

### 3.2 SipLibrary 本地库加载类（三种方式，默认用方式三）

URL：https://www.yuque.com/u12450864/sipmeta/od41dsao81pu8bfg

```java
package com.yetech.libsip;

public class SipLibrary {
    private static String LIBNAME = "libsip";

    /** 方式二：从 java.library.path 搜索（System.loadLibrary） */
    public static void initialize() {
        System.loadLibrary(LIBNAME);
    }

    /** 方式三【默认】：绝对路径加载，需写全文件名含前后缀（System.load） */
    public static void initialize(String libFileName) {
        System.load(libFileName);
    }

    /** 方式一：从环境变量 SIP_LIBSIP_LIBRARY 获取路径 */
    public static void loadSipNativeLibrary() {
        String sipLibraryPath = System.getenv("SIP_LIBSIP_LIBRARY");
        if (sipLibraryPath == null || sipLibraryPath.isEmpty()) {
            throw new IllegalStateException("环境变量 SIP_LIBSIP_LIBRARY 未配置或值为空");
        }
        System.load(sipLibraryPath);
    }
}
```

### 3.3 标准调用顺序（生命周期）

```
initialize() → new SipMetaDocument(...) → NewMeta()
  → NewSubjob(...) → SetMedia(...) → [区域/文本/图片/表格/书签等套版操作 + FormFeed 换页]
  → CloseSubjob()
→ CloseMeta()
```

- `NewMeta()` 是第一个 SIPAPI 动作（创建并自动开始一个 Job）。URL：https://www.yuque.com/u12450864/sipmeta/qs5h2ry8st141oe9
- `CloseMeta()` 是最后一个动作，结束并产生 Meta 文件，自动释放所有 SIP 资源。URL：https://www.yuque.com/u12450864/sipmeta/qptiq8bl7s7gy7vt

### 3.4 完整可运行骨架（AI 生成代码的模板）

```java
package com.example.sipmeta;

import com.yetech.libsip.SipLibrary;
import com.yetech.libsip.SipMetaDocument;
import com.yetech.libsip.constant.BindSide;
import com.yetech.libsip.constant.Orientation;
import com.yetech.libsip.constant.Plex;
import com.yetech.libsip.constant.Transparent;
import com.yetech.libsip.exception.LibSipException;

public class GenerateMetaDemo {
    public static void main(String[] args) throws LibSipException {
        // 1. 加载本地库（默认：绝对路径方式）
        // 根据传入的绝对路径加载 （windows .dll , linux .so）
        SipLibrary.initialize("C://SIP5//libsip.dll");

        System.out.println("Hello SIP Meta for Java!");

        // 2. 生成的 Meta 文件输出路径
        String metaFileName = "D:\\sample\\Meta\\sample_out.mta";

        // 3. 创建 SipMetaDocument(文件路径, Job描述, 创建人, 保留参数0)
        SipMetaDocument doc = new SipMetaDocument(metaFileName, "Job描述", "创建人", 0);

        // 4. 创建 Meta，返回唯一主键 id
        long metaId = doc.NewMeta();
        System.out.println("Meta Id=" + metaId);

        // 5. 创建 SubJob(描述, 单双面, 装订类型, 装订边距)
        doc.NewSubjob("SubJob-1", Plex.DUPLEX, BindSide.NONE, 0);

        // 6. 设置页面纸张(纸张名, 方向)
        doc.SetMedia("A4:PLAIN:WHITE:80", Orientation.PORT);

        // 7. 创建套版区域(名称,层级,方向,透明,X,Y,宽,高)，返回 areaId
        long areaId = doc.NewArea("Area_1", 0, Orientation.PORT, Transparent.NONE,
                                  0, 0, 210000, 297000);

        // ===== 在这里插入各类套版操作：文本/图片/线条/表格/书签等 =====
        doc.SetCursorPos(areaId, 10000, 10000);
        doc.TextOut(areaId, "Hello 文本");
        doc.LineFeed(areaId);

        // 8. 换页（按需）
        doc.FormFeed();

        // 9. 结束 SubJob
        doc.CloseSubjob();

        // 10. 关闭 Meta，生成文件
        doc.CloseMeta();
    }
}
```

---

## 4. Job / SubJob / 页面管理 API

> 通用说明：绝大多数 `Set*/Add*/New*/Close*` 方法**成功返回状态码 0**，失败自动输出错误日志并退出程序；`Get*/New*Area/ImageOpen` 等返回具体值。

### 4.1 创建 Meta — `NewMeta()`

- 方法：`long SipMetaDocument.NewMeta()`，返回 Meta 唯一主键 id。
- URL：https://www.yuque.com/u12450864/sipmeta/qs5h2ry8st141oe9

### 4.2 关闭 Meta — `CloseMeta()`

- 方法：`SipMetaDocument.CloseMeta()`，结束并产生 Meta 文件，自动释放资源。
- URL：https://www.yuque.com/u12450864/sipmeta/qptiq8bl7s7gy7vt

### 4.3 加载全局数据 — `LoadGlobalData`

- 方法：`long LoadGlobalData(String globalData)`；globalData 为两层 XML 字符串，第二层节点名对应同名字段套入数据。成功返回 0。
- URL：https://www.yuque.com/u12450864/sipmeta/lx1gxfia7cpnbays
  
  ```java
  String globalData = "<Root><Field1>全局变量1</Field1><Field2>全局变量2</Field2></Root>";
  long rc = doc.LoadGlobalData(globalData);
  ```

### 4.4 映射系统栏位 — `RemapToSysField`

- 方法：`long RemapToSysField(String projectName, String formFile, String fieldNameList, long sysFieldId)`；在 SubJob 前调用，将 Form 中指定名称栏位映射为系统栏位。projectName 传 `""` 表示不使用工程版本管理。
- sysFieldId 映射见第 13 节系统变量表。
- URL：https://www.yuque.com/u12450864/sipmeta/gszr3pv22q5v2s80
  
  ```java
  doc.RemapToSysField("", "D:\\path\\demo2.hef", "pageNo", 1);
  ```

### 4.5 获取 Job 信息 — `GetJobInfo`

- 方法：`SipJobInfo GetJobInfo()`，返回 `com.yetech.libsip.model.SipJobInfo`。
- URL：https://www.yuque.com/u12450864/sipmeta/bwoar5x7zpbney6f

### 4.6 获取 Subjob 总数 — `GetTotalSubjob`

- 方法：`long GetTotalSubjob()`；第一个 NewSubJob 之前初始值为 0。
- URL：https://www.yuque.com/u12450864/sipmeta/niwflg6kygyttill

### 4.7 获取 Job 总印数 — `GetTotalJobPage`

- 方法：`long GetTotalJobPage()`，含已完成套版目录页的总印数。
- URL：https://www.yuque.com/u12450864/sipmeta/wbi4i01k1i1aovn1

### 4.8 获取 Job 总纸张数 — `GetTotalJobSheet`

- 方法：`long GetTotalJobSheet()`，依各 SubJob 单双面算出的总纸张数。
- URL：https://www.yuque.com/u12450864/sipmeta/hu1vqwlsd9zt44td

### 4.9 创建 SubJob — `NewSubjob`

- 方法：`long NewSubjob(String subJobDesc, long plex, long bindSide, long bindMargin)`
  - `plex`：0-单面，1-双面
  - `bindSide`：0-不装订，1-向左装订，2-向上装订
  - `bindMargin`：装订边距
- URL：https://www.yuque.com/u12450864/sipmeta/kfl3o58p4p44wbfh
  
  ```java
  doc.NewSubjob("SubJob-1", Plex.DUPLEX, BindSide.NONE, 0);
  ```

### 4.10 结束 SubJob — `CloseSubjob`

- 方法：`long CloseSubjob()`；若最后一个 SubJob 未结束就 CloseMeta，会自动结束它。
- URL：https://www.yuque.com/u12450864/sipmeta/kxgl02bqb73cbghq

### 4.11 获取当前 SubJob 信息 — `GetSubjobInfo`

- 方法：`SipSubjobInfo GetSubjobInfo()`，含编号、描述、Plex、BindSide、BindMargin、总页数、StartJobpage。
- URL：https://www.yuque.com/u12450864/sipmeta/ibvwyk7l2291gwwa

### 4.12 设置纸张 — `SetMedia`

- 方法：`long SetMedia(String mediaName, long mediaOrientation)`
  - mediaName 例：`"A4:PLAIN:WHITE:80"`、`"B5:PLAIN:WHITE:80"`
  - orientation：0-竖向，1-横向，2-竖向翻转，3-横向翻转
  - 若当前页已有输出，会自动换页（双面模式可能多次换页保证正面打印）。
- URL：https://www.yuque.com/u12450864/sipmeta/lql7gych34gdzarb

### 4.13 获取纸张尺寸 — `GetPageDim`

- 方法：`SipDim GetPageDim()`，单位 1/1000mm，返回 `SipDim`。
- URL：https://www.yuque.com/u12450864/sipmeta/wwxx905iqnmgo40c

### 4.14 换页 — `FormFeed`

- 方法：`long FormFeed()`，新建一页。
- URL：https://www.yuque.com/u12450864/sipmeta/rotvt433nzfbv562

### 4.15 页面备注 — `AddPageMemo`

- 方法：`long AddPageMemo(String memoName, String memoVal)`；产生在 MetaXML 中，转换出的 PDF 不含该信息。
- URL：https://www.yuque.com/u12450864/sipmeta/cyrxq7q26gepzvrw

### 4.16 页码/纸张次相关

| 方法                            | 说明               | URL                                                      |
| ----------------------------- | ---------------- | -------------------------------------------------------- |
| `long SetPageNo(long pageNo)` | 设置页码流水号          | https://www.yuque.com/u12450864/sipmeta/ep4pmksge1wnnuey |
| `long GetPageNo()`            | 获取页码流水号（套版顺序页次）  | https://www.yuque.com/u12450864/sipmeta/ohckasyep3eesizl |
| `long GetTocPageIndex()`      | 获取目录页次           | https://www.yuque.com/u12450864/sipmeta/abfc9ogsgistvg8l |
| `long GetPageIndex()`         | 获取内文页次           | https://www.yuque.com/u12450864/sipmeta/gt0grpv0p7mob7n9 |
| `long GetPostTocPageIndex()`  | 获取目录页后内文页次       | https://www.yuque.com/u12450864/sipmeta/dqgql2td6g7zwmhf |
| `long EndPageCounting()`      | 停止内文页次计数         | https://www.yuque.com/u12450864/sipmeta/pk21nzlbvxgv2rza |
| `long GetSheetIndex()`        | 获取当前页依套版顺序的纸张次   | https://www.yuque.com/u12450864/sipmeta/oz6a2gymyqmv1bup |
| `long GetUserPageIndex()`     | 获取用户自定义页次        | https://www.yuque.com/u12450864/sipmeta/it5qgy9gkz8nox3u |
| `long EndUserPageCounting()`  | 停止自定义页次计数器（重设为1） | https://www.yuque.com/u12450864/sipmeta/tnrhpw1ri3eff82i |

> 另有一份"取消/改名/新增函数"清单（GetUserTotalPage、GetTotalPage、GetTotalSheet、BeginUserTotalPage、SetUserPageNo、EndUserTotalPage→SipMeta_EndUserPageCounting、GetSheetNo→GetSheetIndex、GetUserPageNo→GetUserPageIndex、SetPageNo、GetPageNo、GetTocPageIndex、GetPageIndex、GetPostTocPageIndex、EndPageCounting），URL：https://www.yuque.com/u12450864/sipmeta/ymgafz531vxggfsr。**生成代码时优先使用上面表格中的现行 `SipMetaDocument` 方法。**

---

## 5. 套版区域（Area / Layer）API

### 5.1 新建区域 — `NewArea`

- 方法一：`long NewArea(String areaName, long level, long orientation, long transparent, long xpos, long ypos, long width, long height)`，返回 areaId。
- 方法二（用模型对象）：`long NewArea(String areaName, SipAreaInfo areaInfo)`。
  - level 越大层级越高，重叠时高层覆盖低层；transparent：0-否，1-是。
- 系统默认存在一个与纸张同大小的区域（ID=1, NAME=BASE）。
- URL：https://www.yuque.com/u12450864/sipmeta/kz6enrkde550x3du
  
  ```java
  long areaId = doc.NewArea("Area_1", 0, Orientation.PORT, Transparent.NONE, 0, 0, 210000, 297000);
  // 或
  SipAreaInfo info = new SipAreaInfo();
  info.setXpos(0L).setYpos(0L).setLevel(0L).setOrientation(Orientation.PORT)
    .setTransparent(Transparent.NONE).setWidth(210000).setHeight(297000);
  long areaId2 = doc.NewArea("Area_1", info);
  ```

### 5.2 释放区域 — `ReleaseArea` / `ReleaseAllArea`

- `long ReleaseArea(long areaId)`：释放指定区域（ID=1 默认区不可释放）；FormFeed 前释放会导致该区域之前套版无效；SubJob 结束自动释放所有区域。URL：https://www.yuque.com/u12450864/sipmeta/wkguitaozt5k1cr0
- `long ReleaseAllArea()`：释放全部自定义区域。URL：https://www.yuque.com/u12450864/sipmeta/rduii61ax4lr968s

### 5.3 按名称取 ID / 按 ID 取名称 / 取信息

| 方法                                      | 说明                    | URL                                                      |
| --------------------------------------- | --------------------- | -------------------------------------------------------- |
| `long GetAreaIDbyName(String areaName)` | 按名称取 areaId           | https://www.yuque.com/u12450864/sipmeta/dlk8bmsf0aq5w7rs |
| `String GetAreaName(long areaId)`       | 按 ID 取名称              | https://www.yuque.com/u12450864/sipmeta/qvz5s9tkamn1s74h |
| `SipAreaInfo GetAreaInfo(long areaId)`  | 取区域信息（层级/宽高/坐标/方向/透明） | https://www.yuque.com/u12450864/sipmeta/nvw2c2l504xsggl4 |

---

## 6. 文本（Text）API

### 6.1 添加文本 — `TextOut`

- 方法：`long TextOut(long areaId, String content)`；在当前光标位置套字，光标自动右移；多段 TextOut 到 LineFeed 时一并输出，可用不同字型大小，最终以文字基线对齐输出。
- URL：https://www.yuque.com/u12450864/sipmeta/dov5cl0grake9mxl

### 6.2 换行 — `LineFeed`

- 方法：`long LineFeed(long areaId)`；移到下一打印行起始位置，下移高度由 SetLineSpacing 设定，默认 1/6 吋。
- URL：https://www.yuque.com/u12450864/sipmeta/yqecmkqx5ggteu81

### 6.3 设置文本坐标 — `SetCursorPos`

- 方法：`long SetCursorPos(long areaId, long Xpos, long Ypos)`；移动光标会自动先执行 LineFeed。
- URL：https://www.yuque.com/u12450864/sipmeta/kqkoicmd6so12gvt

### 6.4 字体设置

| 方法                                      | 说明                                                                     | URL                                                      |
| --------------------------------------- | ---------------------------------------------------------------------- | -------------------------------------------------------- |
| `long SetAscFont(String ascFontName)`   | 设定英文字字型                                                                | https://www.yuque.com/u12450864/sipmeta/vglovgrkt8ombpym |
| `long SetDBfont(String dbFontName)`     | 设定中文字字型                                                                | https://www.yuque.com/u12450864/sipmeta/iq53nuh619s0rm4z |
| `long SetFontWeight(long fontWeight)`   | 设定字型粗细（>=700 视为加粗，可用 `FontWeight.BOLD`）                                | https://www.yuque.com/u12450864/sipmeta/vt2oyb92mfx3hca6 |
| `long SetFontStyle(String fontStyle)`   | 字体样式：常规/`Italic`/`Underline`/`Stroke`，多个用英文逗号分隔，如 `"Italic,Underline"` | https://www.yuque.com/u12450864/sipmeta/vf3bs365wgnfdrui |
| `long SetFontSize(double fontSize)`     | 设定字体大小                                                                 | https://www.yuque.com/u12450864/sipmeta/doy7gut2a6bgis1i |
| `long SetLineSpacing(long lineSpacing)` | 设定行间距（每次换行下移距离）                                                        | https://www.yuque.com/u12450864/sipmeta/cesw16tgp91azkvc |
| `long SetPitch(long pitch)`             | 设定字间距（每英吋几个英文字，默认传 0）                                                  | https://www.yuque.com/u12450864/sipmeta/oegbrblz90tsh79e |

> 示例中还出现 `SetFontColor(String color)`（6 位 16 进制，如 `"000000"`），见水印示例。生成彩色文本时可配合使用。

### 6.5 文本套版典型片段

```java
doc.SetCursorPos(areaId, 10000, 10000);
doc.SetDBfont("楷体");
doc.SetFontSize(24);
doc.SetPitch(0);
doc.SetFontWeight(FontWeight.BOLD);
doc.SetFontStyle("Italic,Underline");
doc.TextOut(areaId, "添加文本ABCD123");
doc.LineFeed(areaId);
```

---

## 7. 图片 / 影像（Image）API

### 7.1 打开 / 关闭图档

| 方法                                                       | 说明                                                                       | URL                                                      |
| -------------------------------------------------------- | ------------------------------------------------------------------------ | -------------------------------------------------------- |
| `long ImageOpen(String projectName, String imgFileName)` | 开启图档并返回 imgId；支持 PDF/TIFF/TIF/JPEG/JPG/PNG/BMP；projectName 传 `""` 不用工程管理 | https://www.yuque.com/u12450864/sipmeta/yihfqpgrlk1voggg |
| `long ImageClose(long imgId)`                            | 关闭图档                                                                     | https://www.yuque.com/u12450864/sipmeta/uywirvqq8gzzboc1 |

### 7.2 套贴图档

| 方法                                                                                                      | 说明                                                                                                    | URL                                                      |
| ------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- | -------------------------------------------------------- |
| `long ImagePut(long areaId, long imgId, long pageIndex, long ULxpos, long ULypos, boolean autoAreaFit)` | 图档指定页套贴，需自行控制 FormFeed。autoAreaFit=true 时自动将 BoundingBox 调整到指定坐标至 Area 右下角（其它尺寸/缩放设置失效）；false 按其它设置输出 | https://www.yuque.com/u12450864/sipmeta/ol642u7udq5si2xc |
| `long ImageUse(long areaId, long imgId, long ULxpos, long ULypos, boolean autoAreaFit)`                 | 整个图档多页套版，每页套版后自动换页，可能自动加页首/页尾/水印                                                                      | https://www.yuque.com/u12450864/sipmeta/qeas5krmtpch1gr7 |

### 7.3 图档信息查询

| 方法                                                          | 说明                                            | URL                                                      |
| ----------------------------------------------------------- | --------------------------------------------- | -------------------------------------------------------- |
| `String GetImageType(long imgId)`                           | 获取图档格式（pdf/tiff/...）                          | https://www.yuque.com/u12450864/sipmeta/ncl5l3rktr66e8og |
| `String GetImageFileName(long imgId)`                       | 获取已开启图档完整路径含名称                                | https://www.yuque.com/u12450864/sipmeta/ubon8yxxsvg6vbpq |
| `long GetImageTotalPage(long imgId)`                        | 获取图档总页数                                       | https://www.yuque.com/u12450864/sipmeta/mgoslgixigefni9e |
| `SipImagePage GetImagePageInfo(long imgId, long pageIndex)` | 获取图档页信息（页次/宽px/高px/分辨率/缩放旋转框宽高/旋转角度/翻转类型/长宽比） | https://www.yuque.com/u12450864/sipmeta/nudkk2qha3tn76x5 |

### 7.4 图档尺寸 / 分辨率 / 变换

| 方法                                                                            | 说明                                                     | URL                                                      |
| ----------------------------------------------------------------------------- | ------------------------------------------------------ | -------------------------------------------------------- |
| `long SetImageRes(long imgId, long XRes, long YRes)`                          | 设定所有页分辨率 dpi（无分辨率图需设定才能算尺寸；已有分辨率则等于调整尺寸，尺寸=像素/分辨率）     | https://www.yuque.com/u12450864/sipmeta/eknlbogmfvao8zvu |
| `long SetImagePageRes(long imgId, long pageIndex, long XRes, long YRes)`      | 设定指定页分辨率                                               | https://www.yuque.com/u12450864/sipmeta/wiiehi0ae5aw8ugz |
| `long SetImageBoundingBox(long imgId, long width, long height)`               | 设定所有页打印尺寸（1/1000mm），可能自动调整分辨率形成缩放；配合 KeepXYratio 保持长宽比 | https://www.yuque.com/u12450864/sipmeta/cmiafdbnwu79krym |
| `long ImageRotate(long imgId, long antiClockDegree)`                          | 旋转所有页，逆时针，单位 1/1000 度（45000=45°，90000=90°）             | https://www.yuque.com/u12450864/sipmeta/kv6bpifwghcxmm6i |
| `long ImagePageRotate(long imgId, long pageIndex, long antiClockDegree)`      | 旋转指定页                                                  | https://www.yuque.com/u12450864/sipmeta/gfy6gct7unv58gb8 |
| `long ImageFlip(long imgId, long flipType)`                                   | 翻转所有页（0-None,1-水平,2-垂直，可用 `FlipType.HORIZONTAL`）       | https://www.yuque.com/u12450864/sipmeta/bcnp6y2127nm60g4 |
| `long ImagePageFlip(long imgId, long pageIndex, long flipType)`               | 翻转指定页                                                  | https://www.yuque.com/u12450864/sipmeta/azkd1zwz7uc5ibnu |
| `long ImageZooming(long imgId, long XRatio, long YRatio)`                     | 缩放所有页，单位 1/1000（1000=1:1）；超区域尺寸会报"区域的坐标不合格"            | https://www.yuque.com/u12450864/sipmeta/fxrhl97ysfik3zxe |
| `long ImagePageZooming(long imgId, long pageIndex, long XRatio, long YRatio)` | 缩放指定页                                                  | https://www.yuque.com/u12450864/sipmeta/uxvhx0kqirac3q8i |
| `long SetImageKeepXYratio(long imgId, long XYRatio)`                          | 所有页保持长宽比缩放（0-否,1-是）                                    | https://www.yuque.com/u12450864/sipmeta/gr8b7gmd68s55kz9 |
| `long SetImagePageKeepXYratio(long imgId, long pageIndex, long XYRatio)`      | 指定页保持长宽比缩放                                             | https://www.yuque.com/u12450864/sipmeta/vlhcqzgpog035wzl |

### 7.5 图片套版典型片段

```java
long imgId = doc.ImageOpen("", "D:\\libdll\\images\\logo\\a.pdf");
doc.SetImageBoundingBox(imgId, 210000, 297000);
doc.ImagePut(areaId, imgId, 1, 0, 0, true);   // 指定页
doc.FormFeed();
doc.ImageUse(areaId, imgId, 0, 0, true);      // 所有页自动换页
doc.ImageClose(imgId);
```

---

## 8. 线条 / 形状 / 底纹（Shape）API

### 8.1 添加线条 — `LineOut`

- 方法：`long LineOut(long areaId, long ULxpos, long ULypos, long BRxpos, long BRypos, long style, long thickness, String color)`
  - (ULx,ULy)=起点，(BRx,BRy)=终点；color 为 6 位 16 进制（如 `"FF0000"`）。
- URL：https://www.yuque.com/u12450864/sipmeta/hhbftywnx1oktnab
  
  ```java
  doc.LineOut(areaId, 10000, 10000, 100000, 10000, 0, 1, "FF0000");
  ```

### 8.2 添加四边相同线条底纹 — `BoxOut`

- 方法：`long BoxOut(long areaId, SipShapeInfo shapeInfo, SipLineStyle lineStyle, SipFillInfo fillInfo)`
- URL：https://www.yuque.com/u12450864/sipmeta/uqzzqu87o51vvglh

### 8.3 添加四边自定义线条底纹 — `BoxOutEx`

- 方法：`long BoxOutEx(long areaId, SipShapeInfo shapeInfo, SipLineStyle topLineStyle, SipLineStyle leftLineStyle, SipLineStyle bottomLineStyle, SipLineStyle rightLineStyle, SipFillInfo fillInfo)`；某边可传 `null` 表示不画。
- URL：https://www.yuque.com/u12450864/sipmeta/gt2e7vwq80zad82n

### 8.4 模型对象构造

```java
// 形状：四角坐标 (ULx,ULy, URx,URy, BRx,BRy, BLx,BLy)
SipShapeInfo shapeInfo = new SipShapeInfo(10000,10000, 50000,10000, 50000,50000, 10000,50000);
// 线条样式：样式, 粗细, 颜色
SipLineStyle lineStyle = new SipLineStyle(1, 10, "FF0000");
// 底纹样式：PatternStyle, 密度, 前景色, 背景色
SipFillInfo fillInfo = new SipFillInfo(PatternStyle.PERCENT_5, 300, "000000", "FF0000");

doc.BoxOut(areaId, shapeInfo, lineStyle, fillInfo);
doc.BoxOutEx(areaId, shapeInfo, null, null, lineStyle, new SipLineStyle(1,5,"FFFFFF"), fillInfo);
```

---

## 9. 表单 / 区块（Form / Segment）API

> 数据约定：**Segment 数据为两层 XML**，第一层节点名可自由定义，第二层节点名必须与表单 `.hef` 中 Field 字段名一致。`SegmentMulti` 为**三层 XML**（第二层是每笔 DataRoot）。projectName 传 `""` 表示不使用工程版本管理。

### 9.1 Form 控制

| 方法                                                                                                                   | 说明                                   | URL                                                      |
| -------------------------------------------------------------------------------------------------------------------- | ------------------------------------ | -------------------------------------------------------- |
| `long FormUse(long areaId, String projectName, String formFile, long userDefineTopMargin, long userDefineBotMargin)` | 设定默认 Form 并指定上下边界（-1 表示使用 Form 自身定义） | https://www.yuque.com/u12450864/sipmeta/eiev3wy5r5lnqfhr |
| `long FormNoUse(long areaId)`                                                                                        | 重设上下边界为 0 并取消表头尾                     | https://www.yuque.com/u12450864/sipmeta/uy7cb7ybteymmqoq |

### 9.2 区块光标位置

| 方法                                          | 说明                    | URL                                                      |
| ------------------------------------------- | --------------------- | -------------------------------------------------------- |
| `long SetSegPos(long areaId, long segYpos)` | 移动目前区块 Y 坐标（1/1000mm） | https://www.yuque.com/u12450864/sipmeta/ggdph7kui9hantb5 |
| `long GetSegPos(long areaId)`               | 获取目前区块 Y 坐标           | https://www.yuque.com/u12450864/sipmeta/irmq222dyw2fyxcg |

### 9.3 区块套版

| 方法                                                                                                                                                                   | 说明                                                                          | URL                                                                                                                       |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| `long SegmentUse(long areaId, String projectName, String formFile, String segName, String segData)`                                                                  | 堆栈区块套版，当前位置套版并下移区块高度；超下边界自动换页；segData 可为 `""`                               | https://www.yuque.com/u12450864/sipmeta/cgwm1q94dfzsrqsf                                                                  |
| `long SegmentMulti(long areaId, String projectName, String formFile, String segNameList, long maxPageSegs, long tblHeaderMode, String segData)`                      | 自动堆栈多笔区块；segNameList 用 `,` 分隔多个 Segment 轮替；tblHeaderMode：0-不加表头,1-加1次,2-每页加 | https://www.yuque.com/u12450864/sipmeta/rmwgg9dhb9qgy6wm                                                                  |
| `long SegmentMultiEx(long areaId, String projectName, String formFile, String segNameList, long extDirection, long maxPageSegs, long tblHeaderMode, String segData)` | 分栏自动堆栈；群组间用 `;` 分割、群组内用 `,`；extDirection：1=N型,2=Z型；maxPageSegs 必须>0         | N型 https://www.yuque.com/u12450864/sipmeta/lafmkk0bpml6g1p8 / Z型 https://www.yuque.com/u12450864/sipmeta/uwfqgoh093pm9ttf |
| `long SegmentToc(String segName, String formFile, long maxPageSegs, long tblHeaderMode)`（可带 areaId 重载）                                                               | 自动调用书签数据进行目录页套版                                                             | https://www.yuque.com/u12450864/sipmeta/pu7lwcsg6opfc1d2                                                                  |

### 9.4 表头 / 页首 / 页尾区块

| 方法                                                                                                                  | 说明                                              | URL                                                      |
| ------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------- | -------------------------------------------------------- |
| `long TblHeaderSegOn(long areaId, String projectName, String formFile, String segName, String segData)`             | 为 SegmentMulti 设定表头区块（首页或每页），segData 为空时只套表头    | https://www.yuque.com/u12450864/sipmeta/tz75h0yb58evzgaf |
| `long TblHeaderSegOff(long areaId)`                                                                                 | 停用区块组表头                                         | https://www.yuque.com/u12450864/sipmeta/nslrif3mtu8q81xq |
| `long HeaderSegAdd(long areaId, String projectName, String formFile, String segName, long segYpos, String segData)` | 新增页首区块；segYpos=1 表示与前一个 HeaderSegment 接续，第一个用 0 | https://www.yuque.com/u12450864/sipmeta/wzwpk8go4mxskauv |
| `long HeaderSegOff(long areaId)`                                                                                    | 停用区块组页首                                         | https://www.yuque.com/u12450864/sipmeta/xsqaf4e6xg19zdz1 |
| `long FooterSegAdd(long areaId, String projectName, String formFile, String segName, long segYpos, String segData)` | 新增页尾区块，默认由下边界（FormUse 设定）开始                     | https://www.yuque.com/u12450864/sipmeta/qcfyd10rq106xnkd |
| `long FooterSegOff(long areaId)`                                                                                    | 停用区块组页尾                                         | https://www.yuque.com/u12450864/sipmeta/sd0t9k4b23o6umbz |

### 9.5 Segment 数据 XML 示例

```xml
<!-- SegmentUse / TblHeaderSegOn / HeaderSegAdd / FooterSegAdd：两层 XML，第二层=字段名 -->
<SegHeader>
    <headerName>元镁科技股份有限公司</headerName>
</SegHeader>

<!-- SegmentMulti / SegmentMultiEx：三层 XML，第二层=每笔 DataRoot，第三层=字段名 -->
<tbBody>
    <data><Name>张无忌1</Name><Sex>男</Sex><Age>1</Age></data>
    <data><Name>张无忌2</Name><Sex>男</Sex><Age>1</Age></data>
</tbBody>
```

---

## 10. 书签 / 目录（Bookmark / Contents）API

### 10.1 章 / 节 / 页签（均有 4 个重载）

| 方法                                                                                                                  | 说明                            | URL                                                      |
| ------------------------------------------------------------------------------------------------------------------- | ----------------------------- | -------------------------------------------------------- |
| `AddChapter(name)` / `AddChapter(name,userPageNo)` / `AddChapter(name,value)` / `AddChapter(name,value,userPageNo)` | 设定章名称；下次设定 Chapter 前的页面都属于该章  | https://www.yuque.com/u12450864/sipmeta/pi4vgqh4d66enchi |
| `AddSection(...)`（4 个重载同上）                                                                                          | 设定节名称，下属于当前章；**未先设章就设节会报错**   | https://www.yuque.com/u12450864/sipmeta/bq2qae0so2poa4h0 |
| `AddBookmark(...)`（4 个重载同上）                                                                                         | 设定页签，下属于当前节；**未先设章/节就设页签会报错** | https://www.yuque.com/u12450864/sipmeta/el3w42dk3i7kyxqg |

调用顺序约束：`AddChapter` → `AddSection` → `AddBookmark`。

### 10.2 获取书签集 — `EnumBookmark`

- 方法：`String EnumBookmark()`，返回 SubJob 内 Chapter/Section/Bookmark 的 XML 字符串。
- URL：https://www.yuque.com/u12450864/sipmeta/fn0u6u19l83r9el6
  
  ```xml
  <BookmarkRoot>
  <Chapter Name="Chapter" PageNo="1" UserPageNo="1">
    <Section Name="Section" PageNo="1" UserPageNo="1">
      <Bookmark Name="Bookmark" PageNo="1" UserPageNo="1"/>
    </Section>
  </Chapter>
  </BookmarkRoot>
  ```

### 10.3 目录页

| 方法                         | 说明            | URL                                                      |
| -------------------------- | ------------- | -------------------------------------------------------- |
| `long ContentsPageHere()`  | 设置目录页将插入的页面位置 | https://www.yuque.com/u12450864/sipmeta/hew7nvqu6t9nxzsm |
| `long ContentsPageBegin()` | 开始对目录页进行套版    | https://www.yuque.com/u12450864/sipmeta/am5v78havvoxhdut |

---

## 11. 水印（Watermark）API

| 方法                                                    | 说明                       | URL                                                      |
| ----------------------------------------------------- | ------------------------ | -------------------------------------------------------- |
| `long SetWatermark(long imgId, long Xpos, long Ypos)` | 设定自动每页加水印；imgId 为水印图档 ID | https://www.yuque.com/u12450864/sipmeta/mybhn03h9ammchtc |
| `long ResetWatermark()`                               | 取消水印；不会自动关闭 ImageFile    | https://www.yuque.com/u12450864/sipmeta/bnlz7roqkzwoar0s |

```java
long imgId = doc.ImageOpen("", "D:\\libdll\\images\\logo\\watermark.png");
doc.SetImageBoundingBox(imgId, 210000, 297000);
doc.SetWatermark(imgId, 0, 0);
doc.ImageClose(imgId);
// 需要取消时
doc.ResetWatermark();
```

---

## 12. 常量速查表（`com.yetech.libsip.constant.*`）

| 常量类            | 取值                                                                      |
| -------------- | ----------------------------------------------------------------------- |
| `Plex`         | `SIMPLEX=0`(单面)、`DUPLEX=1`(双面)                                          |
| `BindSide`     | `NONE=0`(不装订)、`LEFT=1`(向左)、`TOP=2`(向上)                                  |
| `Orientation`  | `PORT=0`(竖向)、`LAND=1`(横向)、`IPORT=2`(竖向翻转)、`ILAND=3`(横向翻转)               |
| `Transparent`  | `NONE=0`(不透明)、`1`(透明)                                                   |
| `FontWeight`   | `BOLD`（>=700 视为加粗）                                                      |
| `FontStyle`    | `ITALIC`/`UNDERLINE`/`STROKE`（字符串 `"Italic","Underline","Stroke"`，逗号分隔） |
| `FlipType`     | `NONE=0`、`HORIZONTAL=1`(水平)、`VERTICAL=2`(垂直)                            |
| `PatternStyle` | 底纹样式，如 `PERCENT_5` 等                                                    |

---

## 13. 系统变量映射表（用于 `RemapToSysField` / 系统栏位）

URL：https://www.yuque.com/u12450864/sipmeta/kdq8l75hgvg2lz2g

| 变量名              | 描述                            | ID  |
| ---------------- | ----------------------------- | --- |
| PageNo           | 页码流水号（不含目录页的页次）               | 1   |
| SheetIndex       | 套版起算的内文纸张次                    | 2   |
| SheetCount       | 套版起算的内文纸张数                    | 3   |
| TocPageIndex     | 目录页的页次                        | 4   |
| TocPageCount     | 目录页的页数                        | 5   |
| PageIndex        | 套版起算的内文页次                     | 6   |
| PageCount        | 套版起算的内文页数                     | 7   |
| UserPageIndex    | 自定义起算页次                       | 8   |
| UserPageCount    | 自定义起算页次数                      | 9   |
| PostTocPageIndex | 目录页后起算的内文页次                   | 10  |
| PostTocPageCount | 目录页后起算的内文页数                   | 11  |
| SysTime          | 系统时间                          | 12  |
| 数字格式             | `"0"`=补0，`"9"`=省略，`"."`=小数点位置 | —   |

---

## 14. Meta 转 PDF（SIP.PDF for Java）

| 方法                                                  | 说明                    | URL                                                      |
| --------------------------------------------------- | --------------------- | -------------------------------------------------------- |
| `Itext2PDFHelper.toPdf(metaFileName, pdfFilePath)`  | Meta 转单个 PDF          | https://www.yuque.com/u12450864/sipmeta/rwr87y1mtgeer5tl |
| `Itext2PDFHelper.toPdfs(metaFileName, pdfFilePath)` | Meta 按 SubJob 转多个 PDF | https://www.yuque.com/u12450864/sipmeta/hk7r59c6qpepew7x |

> 依赖 `sip4j-pdf.jar`。示例代码 import 了 `com.yetech.sip4j.pdf.ConvertHelper`，实际调用为 `Itext2PDFHelper.toPdf/toPdfs`，生成代码时保持一致。

```java
String metaFileName = "D:\\sample\\Meta\\sample_meta_01.xml";
String pdfFilePath  = "D:\\sample\\pdf\\sample_meta_01.pdf";
Itext2PDFHelper.toPdf(metaFileName, pdfFilePath);   // 单个
Itext2PDFHelper.toPdfs(metaFileName, pdfFilePath);  // 按 SubJob 多个
```

---

## 15. 错误码对照表（排错用）

URL：https://www.yuque.com/u12450864/sipmeta/rgv6e95lkg1sdy81

常见前缀分类：`SERR_META_*`(4097+)、`SERR_SUBJOB_*`(8193+)、`SERR_AREA_*`(12289+)、`SERR_TEXT_*`、`SERR_SEG_*`(20481+)、`SERR_IMG_*`(40961+)、`SERR_FONT_*`(45057+)、`SERR_FORM_*`(49153+)、`SERR_ICONV_*`(53249+)、`SERR_BASE_*`(57345+)。

高频错误提示：

- `SERR_SUBJOB_NOCHAPTER(8202)`：先建立 CHAPTER 才能建立 SECTION/BOOKMARK。
- `SERR_SUBJOB_NOSECTION(8203)`：先建立 SECTION 才能建立 BOOKMARK。
- `SERR_AREA_OVERSIZE(12295)`：区域范围超出纸张大小。
- `SERR_AREA_INVALIDPOS(12292)`：区域的坐标不合格（常见于缩放后超区域）。
- `SERR_SEG_INVALIDMAXPAGESSEG(20484)`：SegmentMultiEx 的 MaxPageSegs 必须 > 0。
- `SERR_BASE_INVALIDMEDIANAME(57345)`：纸张名称不合格。
- `UNDEFINED(-1)`：找不到对应错误代码。

> 需要完整错误码枚举时引用上方 URL。可用 `SipErrUtils.GetLastErrCode()` 获取最近错误码。

---

## 16. AI 生成代码检查清单（生成后自检）

1. ✅ 已使用 `SipLibrary.initialize("绝对路径");` 作为默认初始化。
2. ✅ `new SipMetaDocument(路径, Job描述, 创建人, 0)` → `NewMeta()` 开头。
3. ✅ 有 `NewSubjob` + `SetMedia` 才开始页面操作。
4. ✅ 文本/图片/线条操作前已 `NewArea` 取得 areaId（或直接用默认区 ID=1）。
5. ✅ 所有坐标/尺寸单位为微米（1/1000mm）。
6. ✅ 书签遵循 Chapter→Section→Bookmark 顺序。
7. ✅ Segment 数据 XML 层级正确（SegmentUse 两层 / SegmentMulti 三层，末层节点=表单字段名）。
8. ✅ 结尾有 `FormFeed()`（按需）→ `CloseSubjob()` → `CloseMeta()`。
9. ✅ 方法均处理 `throws LibSipException`。
10. ✅ 末尾附"参考文档"链接列表。

---

## 17. 回答引用格式（必须遵守）

每次生成代码后，在结尾用如下格式列出所引用的文章链接：

```
参考文档：
- 创建 Meta：https://www.yuque.com/u12450864/sipmeta/qs5h2ry8st141oe9
- 添加文本 TextOut：https://www.yuque.com/u12450864/sipmeta/dov5cl0grake9mxl
- ...（仅列出本次实际用到的 API 对应链接）
```
