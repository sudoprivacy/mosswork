﻿#!/usr/bin/env node
/**
 * exam-api: Cross-platform CLI for the exam system REST API.
 *
 * Usage:
 *   node exam-api.mjs --api-key TOKEN resource action [options]
 *   node exam-api.mjs resource action [options]          # reads EXAM_API_KEY env
 */

import { parseArgs } from "node:util";

const DEFAULT_BASE = "https://www.qshuati.xyz";
const API_PREFIX = "/api/v1";

// --- helpers -------------------------------------------------------------

function die(msg, code = 1) {
  console.error(JSON.stringify({ error: msg, code }));
  process.exit(code);
}

function out(data) {
  if (data === null || data === undefined) {
    console.log(JSON.stringify({ ok: true }));
  } else {
    console.log(JSON.stringify(data, null, 2));
  }
}

async function req(method, path, body, { apiKey, baseUrl }) {
  const url = `${baseUrl.replace(/\/+$/, "")}${API_PREFIX}${path}`;
  const headers = {
    "Content-Type": "application/json",
    Accept: "application/json",
  };
  // Support both JWT Bearer token and API Key
  if (apiKey && apiKey.startsWith("qst_")) {
    headers["X-API-Key"] = apiKey;
  } else {
    headers["Authorization"] = `Bearer ${apiKey}`;
  }
  const opts = { method, headers };
  if (body !== undefined) opts.body = JSON.stringify(body);

  let resp;
  try {
    resp = await fetch(url, opts);
  } catch (e) {
    die(`Network error: ${e.message}`, 2);
  }

  const text = await resp.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    die(`HTTP ${resp.status}: ${text}`, resp.status);
  }

  if (!resp.ok) {
    die(data.message || `HTTP ${resp.status}`, resp.status);
  }
  if (data.code !== undefined && data.code !== 0) {
    die(data.message || "unknown error", data.code);
  }
  return data.data ?? data;
}

const GET    = (p, ctx)        => req("GET",    p, undefined, ctx);
const POST   = (p, body, ctx)  => req("POST",   p, body,      ctx);
const PATCH  = (p, body, ctx)  => req("PATCH",  p, body,      ctx);
const PUT    = (p, body, ctx)  => req("PUT",    p, body,      ctx);
const DELETE = (p, body, ctx)  => req("DELETE",  p, body,      ctx);

function qs(params) {
  const entries = Object.entries(params).filter(([, v]) => v !== undefined && v !== null);
  return entries.length
    ? "?" + entries.map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join("&")
    : "";
}

// --- command handlers ----------------------------------------------------

const commands = {
  // --- user -------------------------------------------------------------
  "user me":       (a, ctx) => GET("/users/me", ctx),
  "user stats":    (a, ctx) => GET("/users/me/stats", ctx),
  "user calendar": (a, ctx) =>
    GET(`/users/me/calendar${qs({ year: a.year, month: a.month })}`, ctx),

  "user update": (a, ctx) => {
    const body = {};
    if (a.nickname !== undefined) body.nickname = a.nickname;
    if (a["avatar-url"] !== undefined) body.avatar_url = a["avatar-url"];
    return PATCH("/users/me", body, ctx);
  },

  "user api-key":        (a, ctx) => GET("/users/me/api-key", ctx),
  "user regenerate-key": (a, ctx) => POST("/users/me/api-key/regenerate", undefined, ctx),

  // --- spaces ------------------------------------------------------------
  "spaces list":   (a, ctx) =>
    GET(`/spaces${a["with-stats"] ? "?with_stats=true" : ""}`, ctx),
  "spaces get":    (a, ctx) => GET(`/spaces/${a.id}`, ctx),
  "spaces create": (a, ctx) =>
    POST("/spaces", { name: a.name, description: a.description || "" }, ctx),
  "spaces update": (a, ctx) => {
    const body = {};
    if (a.name !== undefined) body.name = a.name;
    if (a.description !== undefined) body.description = a.description;
    return PATCH(`/spaces/${a.id}`, body, ctx);
  },
  "spaces archive":   (a, ctx) => POST(`/spaces/${a.id}/archive`,   undefined, ctx),
  "spaces unarchive": (a, ctx) => POST(`/spaces/${a.id}/unarchive`, undefined, ctx),
  "spaces join":      (a, ctx) => POST("/spaces/join", { space_code: a.code }, ctx),
  "spaces members":   (a, ctx) => GET(`/spaces/${a["space-id"]}/members`, ctx),
  "spaces stats":     (a, ctx) => GET(`/spaces/${a.id}/stats`, ctx),

  // --- banks -------------------------------------------------------------
  "banks list": (a, ctx) =>
    GET(`/spaces/${a["space-id"]}/banks${qs({ keyword: a.keyword })}`, ctx),
  "banks all":   (a, ctx) => GET("/banks", ctx),
  "banks get":   (a, ctx) => GET(`/banks/${a.id}`, ctx),
  "banks stats": (a, ctx) => GET(`/banks/${a.id}/stats`, ctx),
  "banks create": (a, ctx) => {
    const body = { name: a.name, description: a.description || "" };
    if (a.visibility) body.visibility = a.visibility;
    return POST(`/spaces/${a["space-id"]}/banks`, body, ctx);
  },
  "banks update": (a, ctx) => {
    const body = {};
    if (a.name !== undefined) body.name = a.name;
    if (a.description !== undefined) body.description = a.description;
    return PATCH(`/banks/${a.id}`, body, ctx);
  },
  "banks delete": (a, ctx) => DELETE(`/banks/${a.id}`, undefined, ctx),
  "banks import": (a, ctx) =>
    POST("/banks/import", { share_code: a.code, target_space_id: a["space-id"] }, ctx),

  "banks batch-create": (a, ctx) => {
    let items;
    try { items = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return POST(`/spaces/${a["space-id"]}/banks`, items, ctx);
  },
  "banks batch-update": (a, ctx) => {
    let items;
    try { items = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return PATCH("/banks/batch", items, ctx);
  },
  "banks batch-delete": (a, ctx) => {
    let ids;
    try { ids = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return DELETE("/banks/batch", { ids }, ctx);
  },

  // --- chapters ----------------------------------------------------------
  "chapters list":  (a, ctx) => GET(`/banks/${a["bank-id"]}/chapters`, ctx),
  "chapters stats": (a, ctx) => GET(`/banks/${a["bank-id"]}/chapters/stats`, ctx),
  "chapters get":   (a, ctx) => GET(`/chapters/${a.id}`, ctx),
  "chapters create": (a, ctx) => {
    const body = { name: a.name, description: a.description || "" };
    if (a.sort !== undefined) body.sort = Number(a.sort);
    return POST(`/banks/${a["bank-id"]}/chapters`, body, ctx);
  },
  "chapters update": (a, ctx) => {
    const body = {};
    if (a.name !== undefined) body.name = a.name;
    if (a.description !== undefined) body.description = a.description;
    if (a.sort !== undefined) body.sort = Number(a.sort);
    return PATCH(`/chapters/${a.id}`, body, ctx);
  },
  "chapters delete": (a, ctx) => DELETE(`/chapters/${a.id}`, undefined, ctx),

  "chapters batch-create": (a, ctx) => {
    let items;
    try { items = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return POST(`/banks/${a["bank-id"]}/chapters`, items, ctx);
  },
  "chapters batch-update": (a, ctx) => {
    let items;
    try { items = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return PATCH("/chapters/batch", items, ctx);
  },
  "chapters batch-delete": (a, ctx) => {
    let ids;
    try { ids = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return DELETE("/chapters/batch", { ids }, ctx);
  },

  // --- questions ---------------------------------------------------------
  "questions list": (a, ctx) => {
    const p = { type: a.type, page: a.page, page_size: a["page-size"] };
    return GET(`/chapters/${a["chapter-id"]}/questions${qs(p)}`, ctx);
  },
  "questions get": (a, ctx) =>
    GET(`/questions/${a.id}${a["include-answer"] ? "?include_answer=true" : ""}`, ctx),
  "questions create": (a, ctx) => {
    let body;
    try { body = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return POST(`/chapters/${a["chapter-id"]}/questions`, body, ctx);
  },
  "questions update": (a, ctx) => {
    let body;
    try { body = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return PATCH(`/questions/${a.id}`, body, ctx);
  },
  "questions delete": (a, ctx) => DELETE(`/questions/${a.id}`, undefined, ctx),
  "questions search": (a, ctx) => {
    const p = {
      keyword: a.keyword, bank_id: a["bank-id"], chapter_id: a["chapter-id"],
      type: a.type, difficulty: a.difficulty,
      page: a.page, page_size: a["page-size"],
      include_answer: a["include-answer"] ? "true" : undefined,
    };
    return GET(`/spaces/${a["space-id"]}/questions/search${qs(p)}`, ctx);
  },
  "questions ai-parse": (a, ctx) =>
    POST("/questions/ai-parse", { content: a.content, type: a.type || undefined }, ctx),

  "questions batch-create": (a, ctx) => {
    let items;
    try { items = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return POST(`/chapters/${a["chapter-id"]}/questions`, items, ctx);
  },
  "questions batch-update": (a, ctx) => {
    let items;
    try { items = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return PATCH("/questions/batch", items, ctx);
  },
  "questions batch-delete": (a, ctx) => {
    let ids;
    try { ids = JSON.parse(a.json); } catch { die("Invalid --json"); }
    return DELETE("/questions/batch", { ids }, ctx);
  },
};

// --- option definitions --------------------------------------------------

const globalOptions = {
  "api-key":  { type: "string" },
  "base-url": { type: "string" },
};

const subOptions = {
  "user me":       {},
  "user stats":    {},
  "user calendar": { year: { type: "string" }, month: { type: "string" } },
  "user update":   { nickname: { type: "string" }, "avatar-url": { type: "string" } },
  "user api-key":        {},
  "user regenerate-key": {},

  "spaces list":       { "with-stats": { type: "boolean", default: false } },
  "spaces get":        { id: { type: "string" } },
  "spaces create":     { name: { type: "string" }, description: { type: "string", default: "" } },
  "spaces update":     { id: { type: "string" }, name: { type: "string" }, description: { type: "string" } },
  "spaces archive":    { id: { type: "string" } },
  "spaces unarchive":  { id: { type: "string" } },
  "spaces join":       { code: { type: "string" } },
  "spaces members":    { "space-id": { type: "string" } },
  "spaces stats":      { id: { type: "string" } },

  "banks list":    { "space-id": { type: "string" }, keyword: { type: "string" } },
  "banks all":     {},
  "banks get":     { id: { type: "string" } },
  "banks stats":   { id: { type: "string" } },
  "banks create":  { "space-id": { type: "string" }, name: { type: "string" }, description: { type: "string", default: "" }, visibility: { type: "string" } },
  "banks update":  { id: { type: "string" }, name: { type: "string" }, description: { type: "string" } },
  "banks delete":  { id: { type: "string" } },
  "banks import":  { code: { type: "string" }, "space-id": { type: "string" } },

  "banks batch-create": { "space-id": { type: "string" }, json: { type: "string" } },
  "banks batch-update": { json: { type: "string" } },
  "banks batch-delete": { json: { type: "string" } },

  "chapters list":   { "bank-id": { type: "string" } },
  "chapters stats":  { "bank-id": { type: "string" } },
  "chapters get":    { id: { type: "string" } },
  "chapters create": { "bank-id": { type: "string" }, name: { type: "string" }, description: { type: "string", default: "" }, sort: { type: "string" } },
  "chapters update": { id: { type: "string" }, name: { type: "string" }, description: { type: "string" }, sort: { type: "string" } },
  "chapters delete": { id: { type: "string" } },

  "chapters batch-create": { "bank-id": { type: "string" }, json: { type: "string" } },
  "chapters batch-update": { json: { type: "string" } },
  "chapters batch-delete": { json: { type: "string" } },

  "questions list":     { "chapter-id": { type: "string" }, type: { type: "string" }, page: { type: "string" }, "page-size": { type: "string" } },
  "questions get":      { id: { type: "string" }, "include-answer": { type: "boolean", default: false } },
  "questions create":   { "chapter-id": { type: "string" }, json: { type: "string" } },
  "questions update":   { id: { type: "string" }, json: { type: "string" } },
  "questions delete":   { id: { type: "string" } },
  "questions search":   { "space-id": { type: "string" }, keyword: { type: "string" }, "bank-id": { type: "string" }, "chapter-id": { type: "string" }, type: { type: "string" }, difficulty: { type: "string" }, page: { type: "string" }, "page-size": { type: "string" }, "include-answer": { type: "boolean", default: false } },
  "questions ai-parse": { content: { type: "string" }, type: { type: "string" } },

  "questions batch-create": { "chapter-id": { type: "string" }, json: { type: "string" } },
  "questions batch-update": { json: { type: "string" } },
  "questions batch-delete": { json: { type: "string" } },
};

// --- main ----------------------------------------------------------------

async function main() {
  const rawArgs = process.argv.slice(2);
  const positional = [];
  const optionArgs = [];

  for (let i = 0; i < rawArgs.length; i++) {
    if (rawArgs[i].startsWith("--")) {
      optionArgs.push(rawArgs[i]);
      const next = rawArgs[i + 1];
      if (next && !next.startsWith("--")) {
        optionArgs.push(next);
        i++;
      }
    } else {
      positional.push(rawArgs[i]);
    }
  }

  const resource = positional[0];
  const action = positional[1];
  if (!resource || !action) {
    console.error("Usage: node exam-api.mjs [--api-key KEY] [--base-url URL] <resource> <action> [options]");
    console.error("\nResources: user, spaces, banks, chapters, questions");
    process.exit(1);
  }

  const cmdKey = `${resource} ${action}`;
  const handler = commands[cmdKey];
  if (!handler) {
    die(`Unknown command: ${cmdKey}\nAvailable: ${Object.keys(commands).join(", ")}`);
  }

  const optConfig = { ...globalOptions, ...(subOptions[cmdKey] || {}) };
  let values;
  try {
    ({ values } = parseArgs({ options: optConfig, args: optionArgs, strict: true }));
  } catch (e) {
    die(`Invalid options: ${e.message}`);
  }

  const apiKey  = values["api-key"]  || process.env.EXAM_API_KEY;
  const baseUrl = values["base-url"] || process.env.EXAM_API_BASE || DEFAULT_BASE;

  if (!apiKey) {
    die("Missing --api-key or EXAM_API_KEY environment variable");
  }

  const ctx = { apiKey, baseUrl };
  const result = await handler(values, ctx);
  out(result);
}

main().catch((e) => die(e.message));