#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ClassIn小店商品上架助手 · demo 样张生成脚本

技能包内不含任何图片文件（SkillHub 等渠道禁止上传二进制），
三套 demo 的封面 / 长图样张都在客户本地现场渲染出来。

用法
  python scripts/make_demo.py                     # 默认输出到 ./demo样张/
  python scripts/make_demo.py --outdir 我的手样张  # 指定输出目录
  python scripts/make_demo.py --only 02           # 只生成某一套（01/02/03）

输出（每套 demo 一组）
  01_引流体验_商品封面.png / @2x / _276x184
  01_引流体验_商品详情长图.png + _预览.jpg
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
DEMO_DIR = os.path.join(SKILL, "assets", "demo")
TPL_COVER = os.path.join(SKILL, "assets", "template", "商品封面_模板.html")
TPL_LONG = os.path.join(SKILL, "assets", "template", "商品详情长图_模板.html")


def run(args: list[str]) -> None:
    r = subprocess.run([sys.executable] + args, capture_output=True, text=True)
    out = (r.stdout or "") + (r.stderr or "")
    print(out.rstrip())
    if r.returncode != 0:
        raise SystemExit("出图失败：%s" % " ".join(args))


def one(demo_path: str, outdir: str, tmpdir: str) -> None:
    name = os.path.basename(demo_path.rstrip("/\\"))
    data = json.load(open(os.path.join(demo_path, "demo内容.json"), encoding="utf-8"))
    tag = name.split("_")[0]

    # ---- 封面 ----
    cover_data = dict(data.get("cover") or {})
    cover_json = os.path.join(tmpdir, f"{tag}_cover.json")
    json.dump(cover_data, open(cover_json, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    cover_html = os.path.join(outdir, f"{name}_商品封面.html")
    print(f"\n== {name} · 封面 ==")
    run([os.path.join(HERE, "fill.py"), "--template", TPL_COVER,
         "--data", cover_json, "--out", cover_html])
    run([os.path.join(HERE, "render.py"), "--cover", cover_html,
         "--out", os.path.join(outdir, f"{name}_商品封面.png")])

    # ---- 长图 ----
    long_data = dict(data.get("long") or {})
    long_json = os.path.join(tmpdir, f"{tag}_long.json")
    json.dump(long_data, open(long_json, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    long_html = os.path.join(outdir, f"{name}_商品详情长图.html")
    print(f"\n== {name} · 详情长图 ==")
    run([os.path.join(HERE, "fill.py"), "--template", TPL_LONG,
         "--data", long_json, "--out", long_html])
    run([os.path.join(HERE, "render.py"), "--html", long_html,
         "--out", os.path.join(outdir, f"{name}_商品详情长图.png"), "--preview"])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="demo样张", help="样张输出目录，默认 ./demo样张")
    ap.add_argument("--only", default="", help="只生成指定序号，如 02")
    a = ap.parse_args()

    outdir = os.path.abspath(a.outdir)
    os.makedirs(outdir, exist_ok=True)
    tmpdir = os.path.join(outdir, ".tmp")
    os.makedirs(tmpdir, exist_ok=True)

    demos = sorted(d for d in os.listdir(DEMO_DIR)
                   if os.path.isdir(os.path.join(DEMO_DIR, d))
                   and os.path.exists(os.path.join(DEMO_DIR, d, "demo内容.json")))
    if a.only:
        demos = [d for d in demos if d.startswith(a.only)]
    if not demos:
        raise SystemExit("没有找到可用的 demo（assets/demo/*/demo内容.json）")

    for d in demos:
        one(os.path.join(DEMO_DIR, d), outdir, tmpdir)
    shutil.rmtree(tmpdir, ignore_errors=True)
    print(f"\n完成：{len(demos)} 套 demo 样张已生成 → {outdir}")


if __name__ == "__main__":
    main()
