#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ClassIn小店商品上架助手 · 模板填充脚本
把一份 JSON 内容填进长图/封面 HTML 模板，按需删掉客户没勾选的模块。

用法
  python fill.py --template ../assets/template/商品详情长图_模板.html \
                 --data 商品内容.json --out 商品详情长图.html

JSON 结构（未提供的 token 会原样保留并给出警告）
{
  "theme": "clean",                       # clean | warm | bold | ink
  "blocks": {"teacher": true, "features": true, "catalog": true,
             "howto": true, "service": true, "reviews": false, "agreement": true,
             "cta": true},                # false = 该模块整块删除
  "tokens": {"商品课程名称": "...", "价格": "99", ...}
}

提示：跑完看终端最后一行——「残留占位符 0 个」才算干净。
"""
import argparse
import json
import os
import re
import sys

TOKEN_RE = re.compile(r"\{\{([^{}]+)\}\}")

# 无真实照片时的老师形象照占位（内联 SVG）。技能包内不存任何图片文件，
# 保证在禁止上传二进制的分发渠道（如 SkillHub）也能完整安装。
PLACEHOLDER_TEACHER = (
    "data:image/svg+xml;base64,"
    "PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdo"
    "dD0iNDAwIiB2aWV3Qm94PSIwIDAgMzAwIDQwMCI+CjxkZWZzPjxsaW5lYXJHcmFkaWVudCBpZD0i"
    "ZyIgeDE9IjAiIHkxPSIwIiB4Mj0iMCIgeTI9IjEiPgo8c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29s"
    "b3I9IiNEREUzRUUiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNDM0NDREIiLz48L2xp"
    "bmVhckdyYWRpZW50PjwvZGVmcz4KPHJlY3Qgd2lkdGg9IjMwMCIgaGVpZ2h0PSI0MDAiIGZpbGw9"
    "InVybCgjZykiLz4KPGNpcmNsZSBjeD0iMTUwIiBjeT0iMTQ4IiByPSI1NiIgZmlsbD0iI0ZGRkZG"
    "RiIgb3BhY2l0eT0iMC45NSIvPgo8cGF0aCBkPSJNMTUwIDIxNGMtNTYgMC05NCAzMy05NCA4MHYx"
    "MDZoMTg4VjI5NGMwLTQ3LTM4LTgwLTk0LTgweiIgZmlsbD0iI0ZGRkZGRiIgb3BhY2l0eT0iMC45"
    "NSIvPgo8L3N2Zz4="
)


def find_block_span(html: str, name: str):
    """用标签计数找 <div ... data-block="name"> 到配对的 </div> 之间的区间。"""
    m = re.search(r'<div[^>]*data-block="%s"[^>]*>' % re.escape(name), html)
    if not m:
        return None
    start = m.start()
    i = m.end()
    depth = 1
    tag = re.compile(r"<(/?)div\b[^>]*?(/?)>", re.I)
    while depth > 0:
        t = tag.search(html, i)
        if not t:
            return None
        if t.group(1):          # 闭合
            depth -= 1
        elif not t.group(2):    # 自闭合 <div ... /> 不计
            depth += 1
        i = t.end()
    return start, i


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    html = open(a.template, encoding="utf-8").read()
    data = json.load(open(a.data, encoding="utf-8"))

    # 1) 主题
    theme = data.get("theme")
    if theme:
        html, n = re.subn(r'<body data-theme="[a-z]*"', '<body data-theme="%s"' % theme, html)
        if not n:
            print("警告：模板里没找到 data-theme，主题未切换")

    # 1.5) 封面版式（text = 纯图文 / teacher = 老师形象）
    layout = data.get("layout")
    if layout:
        html, n = re.subn(r'(<body[^>]*?data-layout=")[a-z]*(")', r'\g<1>%s\g<2>' % layout, html)
        if not n:
            print("提示：模板里没有 data-layout（长图模板无此属性，可忽略）")

    # 2) 删模块
    blocks = data.get("blocks") or {}
    for name, keep in blocks.items():
        if keep:
            continue
        span = find_block_span(html, name)
        if span:
            # 连同前后空行一起去掉
            s, e = span
            while s > 0 and html[s - 1] in " \t":
                s -= 1
            while e < len(html) and html[e] in "\r\n":
                e += 1
            html = html[:s] + html[e:]
            print("  已删除模块：%s" % name)
        else:
            print("  警告：模块 %s 未在模板中找到" % name)

    # 3) 填 token
    tokens = data.get("tokens") or {}
    missing = []

    # 3.0) 老师照片：客户还没给真实照片时，用内联 SVG 占位，避免出图时出现破图/空框
    #      模板里的 token 名带说明后缀（如「老师照片路径，纯图文版可留空」），所以按前缀匹配
    for key in list(tokens.keys()):
        if key.startswith(("老师形象照路径", "老师照片路径")) and \
                str(tokens[key]).strip() in ("", "__placeholder__"):
            tokens[key] = PLACEHOLDER_TEACHER
            print("  老师照片为空 → 已用占位图（交付时记得列入待替换清单）")

    def rep(m):
        key = m.group(1)
        if key in tokens:
            return str(tokens[key])
        missing.append(key)
        return m.group(0)

    html = TOKEN_RE.sub(rep, html)

    out_dir = os.path.dirname(os.path.abspath(a.out))
    os.makedirs(out_dir, exist_ok=True)
    open(a.out, "w", encoding="utf-8").write(html)
    print("已写出：%s" % a.out)

    # 4) 检查封面图有没有被误放进长图
    bad = []
    for m in re.finditer(r'<img[^>]*src="([^"]+)"', html):
        src = m.group(1)
        if re.search(r"封面|cover", src, re.I):
            bad.append(src)
    if bad:
        print("⚠ 检出封面图被放进了长图：" + "、".join(sorted(set(bad))))
        print("  封面（276×184）和详情长图是两件独立物料。长图里只允许出现老师形象照与好评截图，")
        print("  请删掉引用封面图的那个区块（头图用 HTML 文字排，不要贴封面 PNG）。")

    # 检查残留时忽略 HTML 注释里的示例 token
    check = re.sub(r"<!--.*?-->", "", html, flags=re.S)
    left = sorted(set(TOKEN_RE.findall(check)))
    if left:
        print("残留占位符 %d 个：%s" % (len(left), "、".join(left)))
        print("↑ 这些位置会以 {{}} 原样出现在长图上，务必补齐或删掉对应模块。")
    else:
        print("残留占位符 0 个 ✔ 可以出图")
    if missing:
        sys.exit(1) if os.environ.get("STRICT") else None


if __name__ == "__main__":
    main()
