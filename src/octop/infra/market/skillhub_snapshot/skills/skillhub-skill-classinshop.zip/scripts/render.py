#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ClassIn小店商品上架助手 · 出图脚本
把 HTML 模板渲染成可直接上传的 PNG。

用法
  长图： python render.py --html 商品详情长图.html --out 商品详情长图.png
         python render.py --html 商品详情长图.html --out 商品详情长图.png --width 1080
  封面： python render.py --cover 商品封面.html --out 商品封面.png
         → 同时输出 商品封面.png(276×184) 与 商品封面@2x.png(552×368)
  预览： python render.py --html 商品详情长图.html --out x.png --preview
         （额外存一份 480 宽的 _预览.jpg，方便微信里发给客户看）

依赖： pip install playwright pillow && playwright install chromium
"""
from __future__ import annotations

import argparse
import os
import sys

try:
    from PIL import Image
except ImportError:
    sys.exit("缺少 Pillow：pip install pillow")

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sys.exit("缺少 playwright：pip install playwright && playwright install chromium")


def _uri(path: str) -> str:
    from pathlib import Path
    return Path(os.path.abspath(path)).as_uri()


def _save(im: Image.Image, out: str, width: int | None = None) -> None:
    if width and im.width > width:
        h = round(im.height * width / im.width)
        im = im.resize((width, h), Image.LANCZOS)
    im.save(out, "PNG", optimize=True)
    print(f"  → {out}  {im.width}x{im.height}  {os.path.getsize(out)/1024:.0f}KB")


def render_long(html: str, out: str, width: int | None, preview: bool, scale: int) -> None:
    with sync_playwright() as p:
        b = p.chromium.launch()
        page = b.new_page(viewport={"width": 750, "height": 1200}, device_scale_factor=scale)
        page.goto(_uri(html), wait_until="networkidle")
        page.wait_for_timeout(600)
        # 等图片全部加载完（避免长图出现空白块）
        page.evaluate("""() => Promise.all(
            Array.from(document.images).filter(i => !i.complete)
                 .map(i => new Promise(r => { i.onload = i.onerror = r; }))
        )""")
        png = page.screenshot(full_page=True)
        b.close()

    tmp = out + ".raw.png"
    open(tmp, "wb").write(png)
    im = Image.open(tmp)
    _save(im, out, width)
    os.remove(tmp)

    if preview:
        pv = os.path.splitext(out)[0] + "_预览.jpg"
        w = 480
        im2 = im.convert("RGB").resize((w, round(im.height * w / im.width)), Image.LANCZOS)
        im2.save(pv, "JPEG", quality=80, optimize=True)
        print(f"  → {pv}  {im2.width}x{im2.height}（微信预览用）")


def render_cover(html: str, out: str, scale: int) -> None:
    scale = max(scale, 4)  # 封面必须 ≥4 倍渲染，保证 828×552 主图清晰
    with sync_playwright() as p:
        b = p.chromium.launch()
        page = b.new_page(viewport={"width": 276, "height": 184}, device_scale_factor=scale)
        page.goto(_uri(html), wait_until="networkidle")
        page.wait_for_timeout(400)
        page.evaluate("""() => Promise.all(
            Array.from(document.images).filter(i => !i.complete)
                 .map(i => new Promise(r => { i.onload = i.onerror = r; }))
        )""")
        png = page.screenshot(clip={"x": 0, "y": 0, "width": 276, "height": 184})
        b.close()

    tmp = out + ".raw.png"
    open(tmp, "wb").write(png)
    im = Image.open(tmp)
    base, ext = os.path.splitext(out)
    # 主图：3 倍高清（平台会自动缩放显示，比直接传 276×184 清晰得多）
    _save(im, f"{base}{ext or '.png'}", 828)
    _save(im, f"{base}@2x.png", 552)
    _save(im, f"{base}_276x184.png", 276)
    os.remove(tmp)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", help="长图 HTML 路径")
    ap.add_argument("--cover", help="封面 HTML 路径（276×184）")
    ap.add_argument("--out", required=True, help="输出 PNG 路径")
    ap.add_argument("--width", type=int, default=1080, help="长图输出宽度，默认 1080（传 0 保持原始像素）")
    ap.add_argument("--scale", type=int, default=2, help="渲染倍率，默认 2")
    ap.add_argument("--preview", action="store_true", help="额外输出 480 宽 JPG 预览图")
    a = ap.parse_args()

    out_dir = os.path.dirname(os.path.abspath(a.out))
    os.makedirs(out_dir, exist_ok=True)

    if a.cover:
        print("渲染封面…")
        render_cover(a.cover, a.out, a.scale)
    elif a.html:
        print("渲染长图…")
        render_long(a.html, a.out, a.width or None, a.preview, a.scale)
    else:
        ap.error("需要 --html 或 --cover 之一")


if __name__ == "__main__":
    main()
