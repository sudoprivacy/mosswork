#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
photo-library-cleaner — 相册整理分析引擎（零依赖，纯标准库）
扫描一个目录（默认 ~/Pictures），把"该删/该归档/该复查"的照片和视频找出来，
给出可回收空间与清理清单。本脚本【只分析、不删除】，
删除/移出动作由用户人工确认后执行，安全优先。

用法示例：
  python3 clean.py --path ~/Pictures
  python3 clean.py --path D:/Photos --json > plan.json
  python3 clean.py --path ~/Pictures --older-years 3 --video-mb 200 --top 20
  python3 clean.py --path ~/Pictures --export candidates.txt
"""
import argparse
import hashlib
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone

IMAGE_EXTS = {
    ".jpg", ".jpeg", ".png", ".heic", ".heif", ".gif", ".bmp",
    ".webp", ".tif", ".tiff", ".raw", ".arw", ".cr2", ".cr3",
    ".dng", ".nef", ".orf", ".rw2", ".sr2",
}
VIDEO_EXTS = {
    ".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv", ".m4v",
    ".3gp", ".mpg", ".mpeg", ".webm",
}
SCREENSHOT_PATTERNS = re.compile(
    r"(screenshot|screen[-_ ]?shot|截屏|截图|capture|screenie|snip)", re.IGNORECASE
)
# 常见存放截图的目录名
SCREENSHOT_DIRS = re.compile(r"(screenshot|截屏|截图|capture)", re.IGNORECASE)

CHUNK = 1 << 20  # 1MB 分块读，避免大视频占内存


def md5_of(path):
    h = hashlib.md5()
    try:
        with open(path, "rb") as f:
            while True:
                chunk = f.read(CHUNK)
                if not chunk:
                    break
                h.update(chunk)
    except OSError:
        return None
    return h.hexdigest()


def human(n):
    """字节 -> 人类可读"""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f}{unit}" if unit != "B" else f"{int(n)}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def iter_media(root):
    for dirpath, dirnames, filenames in os.walk(root):
        for fn in filenames:
            ext = os.path.splitext(fn)[1].lower()
            if ext in IMAGE_EXTS or ext in VIDEO_EXTS:
                yield os.path.join(dirpath, fn)


def main():
    ap = argparse.ArgumentParser(description="相册整理分析（只分析不删除）")
    ap.add_argument("--path", default=os.path.expanduser("~/Pictures"),
                    help="要扫描的目录，默认 ~/Pictures")
    ap.add_argument("--older-years", type=int, default=2,
                    help="超过该年的照片标记为'旧'，默认 2 年")
    ap.add_argument("--video-mb", type=float, default=100.0,
                    help="视频大于该 MB 视为大视频，默认 100MB")
    ap.add_argument("--burst", type=int, default=4,
                    help="同一分钟内拍摄 >= 该张数视为连拍，默认 4")
    ap.add_argument("--top", type=int, default=0,
                    help="仅显示体积最大的前 N 个候选文件，0=全部")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    ap.add_argument("--export", metavar="FILE",
                    help="把候选文件路径导出到该文本文件（每行一个）")
    args = ap.parse_args()

    root = os.path.expanduser(args.path)
    if not os.path.isdir(root):
        sys.stderr.write(f"[错误] 目录不存在: {root}\n")
        return 2

    now = datetime.now()
    cutoff_dt = datetime(now.year - args.older_years, now.month, now.day)
    cutoff_ts = cutoff_dt.timestamp()

    total_files = 0
    total_bytes = 0
    hashes = defaultdict(list)          # md5 -> [paths]
    screenshots = []                    # (path, size)
    large_videos = []                  # (path, size)
    old_media = []                     # (path, size, mtime)
    by_minute = defaultdict(list)      # (date, minute) -> [(path, size)]

    for path in iter_media(root):
        try:
            st = os.stat(path)
        except OSError:
            continue
        size = st.st_size
        mtime = st.st_mtime
        ext = os.path.splitext(path)[1].lower()
        total_files += 1
        total_bytes += size

        # 重复：内容哈希
        h = md5_of(path)
        if h:
            hashes[h].append(path)

        fn = os.path.basename(path)
        parent = os.path.basename(os.path.dirname(path))

        # 截图疑似：文件名或父目录命中
        if SCREENSHOT_PATTERNS.search(fn) or SCREENSHOT_DIRS.search(parent):
            screenshots.append((path, size))

        if ext in VIDEO_EXTS and size >= args.video_mb * 1024 * 1024:
            large_videos.append((path, size))

        if mtime < cutoff_ts:
            old_media.append((path, size, mtime))

        dt = datetime.fromtimestamp(mtime)
        key = (dt.strftime("%Y-%m-%d"), dt.hour * 60 + dt.minute)
        by_minute[key].append((path, size, ext))

    # ---- 重复组 ----
    dup_groups = []
    dup_reclaim = 0
    dup_keep = 0
    for h, paths in hashes.items():
        if len(paths) > 1:
            sizes = [os.path.getsize(p) for p in paths]
            keep = max(sizes)
            dup_keep += keep
            dup_reclaim += sum(sizes) - keep
            dup_groups.append({
                "md5": h[:10],
                "count": len(paths),
                "group_bytes": sum(sizes),
                "reclaim": sum(sizes) - keep,
                "sample": paths[:3],
            })
    dup_groups.sort(key=lambda g: g["reclaim"], reverse=True)

    # ---- 连拍 ----
    burst_groups = []
    burst_reclaim = 0
    for key, items in by_minute.items():
        imgs = [i for i in items if i[2] in IMAGE_EXTS]
        if len(imgs) >= args.burst:
            # 保留第一张，其余标记可清理
            keep_one = imgs[0]
            extras = [i for i in imgs if i != keep_one]
            b_reclaim = sum(s for _, s, _ in extras)
            burst_reclaim += b_reclaim
            burst_groups.append({
                "when": f"{key[0]} {key[1]//60:02d}:{key[1]%60:02d}",
                "count": len(imgs),
                "reclaim": b_reclaim,
                "keep": keep_one,
                "extras": [p for p, _, _ in extras][:5],
            })
    burst_groups.sort(key=lambda g: g["reclaim"], reverse=True)

    # ---- 候选汇总（去重到文件集合）----
    candidate_set = set()
    for g in dup_groups:
        # 除样本第一张外都算候选；这里把整组样本都加（人工再筛）
        for p in g["sample"][1:]:
            candidate_set.add(p)
    for p, _ in screenshots:
        candidate_set.add(p)
    for p, _ in large_videos:
        candidate_set.add(p)
    for p, _, _ in old_media:
        candidate_set.add(p)
    for g in burst_groups:
        for p in g["extras"]:
            candidate_set.add(p)

    candidate_bytes = sum(os.path.getsize(p) for p in candidate_set)

    summary = {
        "scanned_dir": root,
        "scanned_at": now.isoformat(timespec="seconds"),
        "total_files": total_files,
        "total_bytes": total_bytes,
        "total_human": human(total_bytes),
        "duplicates": {
            "groups": len(dup_groups),
            "files_involved": sum(g["count"] for g in dup_groups),
            "reclaim_bytes": dup_reclaim,
            "reclaim_human": human(dup_reclaim),
        },
        "screenshots": {
            "count": len(screenshots),
            "bytes": sum(s for _, s in screenshots),
            "human": human(sum(s for _, s in screenshots)),
        },
        "large_videos": {
            "count": len(large_videos),
            "bytes": sum(s for _, s in large_videos),
            "human": human(sum(s for _, s in large_videos)),
        },
        "old_media": {
            "count": len(old_media),
            "bytes": sum(s for _, s, _ in old_media),
            "human": human(sum(s for _, s, _ in old_media)),
            "older_than": f"{args.older_years} 年",
        },
        "bursts": {
            "groups": len(burst_groups),
            "reclaim_bytes": burst_reclaim,
            "reclaim_human": human(burst_reclaim),
        },
        "candidate_total": {
            "files": len(candidate_set),
            "bytes": candidate_bytes,
            "human": human(candidate_bytes),
            "pct_of_library": round(100 * candidate_bytes / total_bytes, 1) if total_bytes else 0,
        },
        "thresholds": {
            "older_years": args.older_years,
            "video_mb": args.video_mb,
            "burst": args.burst,
        },
    }

    if args.json:
        out = dict(summary)
        out["dup_groups"] = dup_groups[: args.top] if args.top else dup_groups
        out["burst_groups"] = burst_groups[: args.top] if args.top else burst_groups
        out["screenshots_list"] = [p for p, _ in screenshots]
        out["large_videos_list"] = [p for p, _ in large_videos]
        out["candidate_files"] = sorted(candidate_set)
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        print("=" * 60)
        print("相册整理分析报告")
        print("=" * 60)
        print(f"扫描目录 : {root}")
        print(f"媒体总数 : {total_files} 个  ({summary['total_human']})")
        print("-" * 60)
        print(f"[重复]    {summary['duplicates']['groups']} 组（涉及 "
              f"{summary['duplicates']['files_involved']} 个文件），可回收 "
              f"{summary['duplicates']['reclaim_human']}")
        print(f"[截图]    {summary['screenshots']['count']} 张疑似截图，约 "
              f"{summary['screenshots']['human']}")
        print(f"[大视频]  {summary['large_videos']['count']} 个 > {args.video_mb:.0f}MB，约 "
              f"{summary['large_videos']['human']}")
        print(f"[旧文件]  {summary['old_media']['count']} 个早于 "
              f"{summary['thresholds']['older_years']} 年，约 {summary['old_media']['human']}")
        print(f"[连拍]    {summary['bursts']['groups']} 组连拍，可删冗余约 "
              f"{summary['bursts']['reclaim_human']}")
        print("-" * 60)
        print(f">>> 候选清理总计：{len(candidate_set)} 个文件，可回收 "
              f"{summary['candidate_total']['human']} "
              f"（占相册 {summary['candidate_total']['pct_of_library']}%）")
        print("=" * 60)
        print("提示：本脚本只分析、不删除。请人工核对下列清单后再处理：")
        if dup_groups:
            print(f"  重复组 Top {min(args.top or 5, len(dup_groups))}：")
            for g in dup_groups[: (args.top or 5)]:
                print(f"    · {g['count']} 张相同，回收 {human(g['reclaim'])}  e.g. {g['sample'][0]}")
        if burst_groups:
            print(f"  连拍 Top {min(args.top or 5, len(burst_groups))}：")
            for g in burst_groups[: (args.top or 5)]:
                print(f"    · {g['when']} 拍了 {g['count']} 张，建议留 1 张，回收 {human(g['reclaim'])}")
        if large_videos:
            print(f"  大视频 Top {min(args.top or 3, len(large_videos))}：")
            for p, s in sorted(large_videos, key=lambda x: -x[1])[: (args.top or 3)]:
                print(f"    · {human(s)}  {p}")
        print("=" * 60)

    if args.export:
        with open(args.export, "w", encoding="utf-8") as f:
            for p in sorted(candidate_set):
                f.write(p + "\n")
        if not args.json:
            print(f"[已导出候选清单] {args.export}  ({len(candidate_set)} 行)")

    return 0


if __name__ == "__main__":
    sys.exit(main())
