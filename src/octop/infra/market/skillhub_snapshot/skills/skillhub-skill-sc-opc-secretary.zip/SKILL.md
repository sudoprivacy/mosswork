---
name: skillhub-skill-sc-opc-secretary
description: "从打工人到 CEO：用 AI 搭建 OPC（一人公司）。用于 OpenClaw 课程第 5 节：日程、纪要、待办、周报骨架与 CEO 视角委派复盘。 触发词：一人公司、OPC、日程、纪要、待办、周报、秘书虾。"
---

# opc-secretary

## 课程定位

- 节次：第 5 节
- 模块：模块二 · OPC / 副业 / 职场
- 标题：从打工人到 CEO：用 AI 搭建 OPC（一人公司）
- 核心目的：日程、纪要、待办、周报骨架与 CEO 视角委派复盘。
- 上游参考：agent-browser、feishu-doc、tencent-docs、ai-planer

## 使用流程

1. 把用户需求拆成目标、角色、截止时间、依赖与风险。
2. 输出 CEO 视角任务看板：必须包含待办、委派建议、下一步确认。
3. 生成会议纪要或周报时，先列事实，再列行动项与负责人。
4. 需要提醒时只生成提醒计划，不代替用户登录第三方账号。

## 标准输出

- `任务看板.md`
- `会议纪要.md`
- `周报骨架.md`
- `提醒计划.csv`

## MCP/API 边界

- 默认允许：feishu-doc、腾讯文档、scheduler、filesystem
- 可选能力：agent-browser 仅用于合规浏览器演示
- 禁用能力：Google Calendar、Google Workspace
- 备注：机构日历/邮件视本地合规环境而定，凭据走环境变量或 skills.entries。

## 合规检查

执行前先回答三件事：

1. 数据或素材是否由用户提供、平台导出、公开授权或课程 demo 提供。
2. 是否涉及账号登录、批量操作、隐私、金融、医疗、未成年人或版权。
3. 是否需要人工确认后再调用外部 API 或工具。

若任一项不确定，先给出手动 SOP 或待确认清单，不直接调用外部服务。
