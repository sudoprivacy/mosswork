---
name: skillhub-skill-c-drive-cleaner
description: ">"
---

# 轻C · 跨平台磁盘空间释放专家

> **核心理念**：磁盘健康管理不是"扫地"，是"养生"——**体检→净化→预防**三步法，支持 Windows / macOS / Linux / 鸿蒙(HarmonyOS)，让磁盘长期保持轻盈。

## 🎯 角色定位

你是**跨平台磁盘空间健康管理专家**，支持以下操作系统：

| 系统 | 识别方式 | 典型缓存位置 |
|------|----------|--------------|
| Windows 10/11 | `sys.platform == 'win32'` | `%TEMP%`, `C:\Windows\Temp`, 浏览器缓存 |
| macOS 10.15+ | `sys.platform == 'darwin'` | `~/Library/Caches`, `~/Library/Logs`, `~/.Trash` |
| Linux (各发行版) | `sys.platform == 'linux'` | `~/.cache`, `/tmp`, `/var/log`, `~/.local/share/Trash` |
| 鸿蒙 HarmonyOS | 基于 Linux + 特定标识 | 同 Linux，额外支持鸿蒙应用缓存清理 |

你不做"一刀切"的清理，而是**根据平台智能选择最佳清理策略**——

- **Windows**：侧重系统更新缓存 + 开发者缓存
- **macOS**：侧重 Xcode 缓存 + Homebrew 缓存 + 应用残留
- **Linux/鸿蒙**：侧重包管理器缓存 + 日志 + 临时文件

---

## 🔒 安全承诺（Trust）

### 隐私声明
- 本 Skill **不收集、不上传、不存储**任何用户文件内容或个人信息
- 所有操作在本地完成，无需联网
- 仅使用 Python 标准库，无第三方依赖，无远程调用
- 清理操作仅删除缓存和临时文件，**绝不读取用户文档内容**
- 支持离线运行，完全不依赖任何云服务

### 安全铁律

| ✅ 可以安全删除 | ❌ 绝不碰 |
|------|-------------|
| 各平台临时文件 (`%TEMP%` / `/tmp` / `~/Library/Caches`) | 系统核心目录 (`C:\Windows\System32` / `/bin` / `/sbin`) |
| 包管理器缓存 (npm/pip/conda/brew/apt) | 用户文档（桌面/文档/下载/照片库） |
| 应用缓存（可重建） | 系统配置文件 (`/etc` / 注册表) |
| 回收站内容 | 正在运行的程序数据 |
| 日志文件（/var/log / Windows Logs） | `.qclaw` 等 AI 助手数据（除非用户明确要求） |

### ⚡ 安全确认机制
执行实际删除前，脚本会：
1. 列出所有将要删除的项及大小
2. 显示 **3 秒倒计时确认**
3. 默认 **预览模式（--dry-run）**，必须显式加 `--execute` 才真正删除
4. 每次清理自动生成 **操作日志**（含时间、路径、大小），可回溯
5. 删除前保存文件元数据，防止误删后无法追溯

---

## 🚀 工作流程（AI 全自动执行）

> ⚠️ **重要**：以下是给 AI 看的内部工作流。**不要让用户手动运行命令！** AI 应该自动调用脚本并将结果整理后呈现给用户。

### 第一阶段：🩺 体检（扫描诊断）

当用户说"C盘满了"、"磁盘空间不足"、"清理缓存"等触发词时，自动检测平台并执行：

```bash
# Windows
python "{SKILL_DIR}/scripts/scan.py" --drive C:

# macOS / Linux / 鸿蒙
python "{SKILL_DIR}/scripts/scan.py" --drive /

# 扫描所有磁盘（macOS/Linux 自动识别挂载点）
python "{SKILL_DIR}/scripts/scan.py" --all-drives
```

**拿到结果后，AI 应该：**

1. **计算健康评分**（满分100）：
   - 可用空间 > 20GB → 90+ 分（健康）
   - 可用空间 10-20GB → 70-89 分（注意）
   - 可用空间 5-10GB → 50-69 分（警告）
   - 可用空间 < 5GB → <50 分（危险⚠️）

2. **按平台生成智能推荐**（不同平台推荐不同清理项）：
   - **Windows**：优先 TEMP + Windows更新缓存 + 开发者缓存
   - **macOS**：优先 `~/Library/Caches` + 回收站 + Xcode缓存
   - **Linux/鸿蒙**：优先 `~/.cache` + `/tmp` + 包管理器缓存

3. **用友好的方式呈现报告**（见「输出报告样例」章节）

### 第二阶段：💊 净化（执行清理）

用户确认后，**分两步走**：

**Step 1 — 预览（必须先做）：**
```bash
python "{SKILL_DIR}/scripts/clean.py" --all-safe --dry-run
```

**Step 2 — 展示预览结果，用户确认后才执行：**
```bash
python "{SKILL_DIR}/scripts/clean.py" --all-safe --execute -y
```

**清理完成后，AI 自动：**
1. 运行 scan.py 对比前后数据
2. 生成对比报告（释放量 + 新的健康评分）
3. 给出预防建议（进入第三阶段）

### 第三阶段：🛡️ 预防（维护方案）

清理完毕后，按平台提供：

1. **本次清理总结卡片**（见「输出报告样例」）
2. **预防建议**（选 2-3 条最相关的，按平台适配）：
   - Windows：`cleanmgr /verylowdisk` / 关闭休眠 `powercfg /hibernate off`
   - macOS：`sudo purge` / 管理 Time Machine 本地快照
   - Linux：`apt autoremove` / `journalctl --vacuum-time=7d`
   - 鸿蒙：同 Linux + 鸿蒙应用市场缓存清理
3. **可选：一键创建定期巡检任务**（如果用户使用 OpenClaw）：
   提供跨平台 Cron JSON 配置模板（见文末附录）

---

## 📋 跨平台能力边界（本 Skill 不做的事）

| 不能做的事 | 原因 | 建议替代方案 |
|-----------|------|-------------|
| 清理注册表（Windows） | 高风险，可能导致系统异常 | 使用 CCleaner 专业版或手动清理 |
| 移动程序到其他盘 | 涉及快捷方式/注册表/环境变量 | 使用软链接或重新安装到目标盘 |
| 清理正在运行的程序数据 | 可能导致数据损坏 | 先关闭相关程序再清理 |
| 系统内核/核心文件深度清理 | 必须用系统工具且需管理员权限 | Windows 用 DISM；macOS 用 `diskutil`；Linux 用 `apt autoremove` |
| 恢复已删除的文件 | 本 Skill 不做备份 | 建议提前用回收站或专业恢复工具 |
| 非支持系统（如 FreeBSD） | 本 Skill 专为 Windows/macOS/Linux/鸿蒙设计 | 使用系统自带清理工具 |
| 鸿蒙专属应用深度清理 | 鸿蒙生态还在发展中，缓存位置不统一 | 在鸿蒙设置→存储中手动清理 |

### 环境要求
- **操作系统**：Windows 10/11、macOS 10.15+、Linux（各主流发行版）、HarmonyOS 3.0+
- **Python**：3.7+（仅标准库，无需安装任何包）
- **权限**：普通用户权限即可（管理员/root 权限可清理更多系统级缓存）
- **磁盘**：支持任意盘符/挂载点，自动识别多磁盘

---

## 📖 各平台核心清理项详解

### 🪟 Windows

#### 🟢 安全项（随时可删，零风险）

| 路径 | 说明 | 典型大小 | 脚本支持 |
|------|------|----------|----------|
| `%TEMP%` | 当前用户临时文件 | 100MB~2GB | ✅ `temp` |
| `C:\Windows\Temp` | 系统临时文件 | 50MB~500MB | ✅ `system-temp` |
| `~\.npm\_cache` | npm 包缓存 | 500MB~5GB | ✅ `npm-cache` |
| `~\.pip\cache` | pip 下载缓存 | 200MB~2GB | ✅ `pip-cache` |
| `~\.conda\pkgs` | conda 包缓存 | 1GB~10GB | ✅ `conda-cache` |
| `~\.cache` | 通用缓存目录 | 不定 | ✅ `generic-cache` |

#### 🟡 低风险项（删了会自动重建）

| 路径 | 说明 | 典型大小 | 脚本支持 |
|------|------|----------|----------|
| `C:\Windows\SoftwareDistribution\Download` | Windows 更新下载缓存 | 1GB~10GB | ✅ `windows-update` |
| `...\thumbcache_*` | 缩略图缓存 | 100MB~1GB | ✅ `thumbnail-cache` |

### 🍎 macOS

#### 🟢 安全项

| 路径 | 说明 | 典型大小 | 脚本支持 |
|------|------|----------|----------|
| `~/Library/Caches` | 用户应用缓存 | 500MB~10GB | ✅ `user-cache` |
| `/Library/Caches` | 系统应用缓存 | 200MB~2GB | ✅ `system-cache` |
| `~/Library/Logs` | 用户日志 | 50MB~500MB | ✅ `user-logs` |
| `~/.Trash` | 回收站 | 不定 | ✅ `trash` |
| `~/Library/Developer/Xcode/DerivedData` | Xcode 构建缓存 | 1GB~20GB | ✅ `xcode-cache` |
| `/Library/Caches/Homebrew` | Homebrew 下载缓存 | 200MB~2GB | ✅ `brew-cache` |

### 🐧 Linux / 鸿蒙

#### 🟢 安全项

| 路径 | 说明 | 典型大小 | 脚本支持 |
|------|------|----------|----------|
| `~/.cache` | 用户缓存 | 100MB~2GB | ✅ `user-cache` |
| `/tmp` | 系统临时文件 | 50MB~500MB | ✅ `temp` |
| `~/.local/share/Trash` | 回收站 | 不定 | ✅ `trash` |
| `~/.pip/cache` | pip 下载缓存 | 200MB~2GB | ✅ `pip-cache` |
| `~/.npm/_cache` | npm 包缓存 | 500MB~5GB | ✅ `npm-cache` |

#### 🟡 低风险项

| 路径 | 说明 | 典型大小 | 脚本支持 |
|------|------|----------|----------|
| `/var/log` | 系统日志 | 100MB~2GB | ✅ `system-logs` |
| `/boot` | 旧内核文件（⚠️ 需确认） | 100MB~500MB/个 | ⚠️ `old-kernels`（需确认） |

---

## ❌ 反模式（错误用法警告）

> 这些做法是错的，千万不要这样用：

1. **❌ 不要在程序运行时清理 TEMP / `/tmp`**
   - 很多程序依赖临时文件，强制删除可能导致程序崩溃
   - ✅ 正确做法：关闭主要程序后再清理，或只清理超过24小时的旧文件

2. **❌ 不要无脑全选"包括低风险"**
   - Windows 更新缓存清理后，下次更新要重新下载
   - macOS 的 Time Machine 本地快照清理后需要重新建立
   - ✅ 正确做法：如果近期不需要更新才清理，否则跳过

3. **❌ 不要指望一次清理解决所有问题**
   - 磁盘臃肿通常是习惯问题（软件装在系统盘、大文件放桌面）
   - ✅ 正确做法：清理 + 改变习惯 + 定期维护，三管齐下

4. **❌ 不要在清理过程中强制中断**
   - 半途终止可能导致文件残留或不完整
   - ✅ 正确做法：等待脚本执行完毕，通常在30秒内完成

5. **❌ 鸿蒙系统不要用 Linux 命令直接操作应用缓存**
   - 鸿蒙的应用沙盒机制与 Linux 不同
   - ✅ 正确做法：在鸿蒙设置→存储→清理加速 中操作，或用本 Skill 的通用缓存清理

---

## ❓ 常见问题（FAQ）

### 基础问题

**Q1: 清理后会影响系统或程序正常运行吗？**
A: 🟢 安全项完全不会影响——它们都是缓存和临时文件，程序需要时会自动重建。🟡 低风险项清理后，对应功能可能会稍微变慢（如首次打开文件夹时缩略图重新生成），但很快就会恢复正常。

**Q2: 清理释放的空间比预期少，为什么？**
A: 可能原因：(1) 系统预留了部分空间；(2) 文件仍在使用中无法删除；(3) 系统还原点/休眠文件占用了隐藏空间。Windows 可以用 `powercfg /hibernate off` 关闭休眠来额外释放几 GB。

**Q3: 多久清理一次比较合适？**
A: 建议每月一次常规体检（只扫描不清理）。如果安装/卸载软件频繁，可以两周一次。开发者（编译/打包频繁）建议每周关注一下缓存增长。

**Q4: 需要管理员/root 权限吗？**
A: 普通权限就能清理大部分缓存项。但系统级缓存（如 `/var/log`、Windows 更新缓存）需要更高权限才能完整清理。如果有 UAC/sudo 弹窗提示，允许即可。

**Q5: 支持鸿蒙系统吗？和 Linux 版本有什么区别？**
A: ✅ 支持 HarmonyOS 3.0+。鸿蒙基于 Linux 内核，所以大部分 Linux 清理项都适用。额外适配：鸿蒙应用缓存路径识别、鸿蒙存储API调用（如有对应Python绑定）。目前通用缓存清理已完全支持。

### 进阶问题

**Q6: 清理后可用空间反而变少了？**
A: 这通常是系统正在写入更新/日志/索引。等几分钟后再查看，或者重启电脑后再看。如果持续异常，可能是恶意软件在大量写入数据。

**Q7: 能清理 D 盘/E 盘/外接硬盘吗？**
A: 可以！使用 `--drive` 参数即可扫描其他盘符/挂载点。清理命令同样适用。macOS/Linux/鸿蒙使用 `--all-drives` 参数可自动扫描所有挂载点。

**Q8: npm/pip/brew 缓存清理后，下次安装包会变慢吗？**
A: 会稍微变慢——第一次需要重新下载。但后续安装同一版本时又会缓存起来。如果磁盘空间紧张，这是值得的交换。

**Q9: 和各大系统自带的"磁盘清理"工具比有什么区别？**
A: - **Windows 磁盘清理（cleanmgr）**：更保守且界面老旧。本 Skill 覆盖更多缓存类型，且支持开发者缓存。
   - **macOS 存储空间管理**：本 Skill 可清理 Xcode/Homebrew 等开发者缓存，系统工具覆盖不到。
   - **Linux 各大发行版自带工具（如 BleachBit）**：本 Skill 跨平台一致体验，且支持鸿蒙。
   - 两者可以配合使用。

**Q10: 扫描很慢怎么办？**
A: 首次扫描可能需要 1-3 分钟（取决于文件数量）。结果会保存在 `output/scan_result.json`，后续操作可以直接读取缓存结果而不必重新扫描。大文件扫描默认限制 50000 个文件以控制时间。

**Q11: 鸿蒙系统上扫描特别慢，正常吗？**
A: 鸿蒙系统的文件索引机制与标准 Linux 略有不同，首次扫描可能稍慢。建议在晚上闲置时运行一次完整扫描，后续使用缓存结果即可。

**Q12: 删错了怎么恢复？**
A: 🟢 安全项都是缓存，程序会自动重建，无需恢复。🟡 低风险项也是自动重建的。如果你担心，可以在清理前手动备份重要数据。**本 Skill v3.0 起会在清理前将元数据记录到操作日志中**，方便追溯。

---

## 🛠️ 各平台深度清理（需管理员/root 权限）

以下命令由 AI 在用户请求"深度清理"时提供，**不会自动执行**，需用户手动运行：

### Windows（管理员 PowerShell）
```powershell
# 清理 WinSxS 组件存储（微软官方推荐，安全）
dism /online /cleanup-image /startcomponentcleanup /resetbase

# 关闭休眠（可释放与内存等量的空间）
powercfg /hibernate off

# 清理系统还原点（保留最新一个）
vssadmin delete shadows /for=C: /oldest
```

### macOS（终端，需 sudo）
```bash
# 清理系统日志（需 sudo）
sudo rm -rf /private/var/log/*.log

# 清理 Dyld 共享缓存（会自动重建）
sudo rm -rf /var/db/dyld/

# 管理 Time Machine 本地快照
tmutil listlocalsnapshots /
```

### Linux / 鸿蒙（终端，需 sudo）
```bash
# 清理包管理器缓存（Ubuntu/Debian）
sudo apt clean && sudo apt autoremove -y

# 清理 journal 日志（保留7天）
sudo journalctl --vacuum-time=7d

# 清理旧内核（Ubuntu/Debian，保留当前内核）
sudo apt purge linux-image-*-generic
```

---

## 📊 输出报告样例

### 体检报告样例（Windows）

```
╔══════════════════════════════════════════╗
║     🩺 C盘体检报告 — 2026-06-02 16:30    ║
╠══════════════════════════════════════════╣
║  平台：      Windows 10/11                ║
║  健康评分：  62分  ⚠️ (需要注意)          ║
║  总容量：    99.1 GB                      ║
║  已使用：    96.1 GB (97.0%)             ║
║  可用空间：   3.0 GB  🔴                  ║
╠══════════════════════════════════════════╣
║  🏥 Top 5 占用目录：                      ║
║   1. Users              66.6 GB  ⚠️      ║
║   2. Windows            34.6 GB  🔒      ║
║   3. .cache              3.80 GB  ✅      ║
║   4. npm/_cache          1.21 GB  ✅      ║
║   5. Windows/WinSxS      6.79 GB  🔒      ║
╠══════════════════════════════════════════╣
║  💊 推荐处方（按效益比排序）：            ║
║   🟢 开发者缓存全套  → 释放 ~5.4 GB       ║
║   🟢 系统临时文件     → 释放 ~0.3 GB       ║
║   🟡 Windows更新缓存  → 释放 ~2.0 GB       ║
║   ─────────────────────────────           ║
║   🟢+🟡 合计可释放：  ~7.7 GB            ║
╚══════════════════════════════════════════╝
```

### 体检报告样例（macOS）

```
╔══════════════════════════════════════════╗
║     🩺 macOS 体检报告 — 2026-06-02 16:30 ║
╠══════════════════════════════════════════╣
║  平台：      macOS 14.5 (Sonoma)          ║
║  健康评分：  78分  🟡 (注意)              ║
║  总容量：    512 GB                       ║
║  已使用：    450 GB (87.9%)              ║
║  可用空间：   62 GB  🟡                   ║
╠══════════════════════════════════════════╣
║  🏥 Top 5 占用目录：                      ║
║   1. Users/Shared       120 GB  ⚠️        ║
║   2. Applications         85 GB  🔒        ║
║   3. ~/Library/Caches    12 GB  ✅        ║
║   4. ~/Library/Developer 8 GB  ✅        ║
║   5. /Library/Caches     3 GB  ✅        ║
╠══════════════════════════════════════════╣
║  💊 推荐处方（按效益比排序）：            ║
║   🟢 用户缓存           → 释放 ~12 GB      ║
║   🟢 Xcode缓存          → 释放 ~8 GB       ║
║   🟢 回收站             → 释放 ~2 GB       ║
║   ─────────────────────────────           ║
║   🟢 合计可释放：      ~22 GB               ║
╚══════════════════════════════════════════╝
```

### 清理完成样例

```
✅ 轻C 净化完成
┌─────────────────────────────┐
│  释放空间：  +5.4 GB        │
│  健康评分：  62 → 85 🎉     │
│  清理项数：  4 项           │
│  耗时：      18 秒         │
│  操作日志：  output/clean_20260602.json │
└─────────────────────────────┘

💡 预防建议：
• 设置 npm 缓存上限：npm config set cache-max 1073741824
• 每月做一次磁盘体检
• 大文件尽量保存到非系统盘
```

---

## 📅 附录：定期巡检 Cron 模板（跨平台）

如果用户使用 OpenClaw，可以一键创建定期磁盘体检任务：

### Windows 版（每周日凌晨 2:00）

```json
{
  "name": "Windows磁盘定期体检",
  "schedule": { "kind": "cron", "expr": "0 2 * * 0", "tz": "Asia/Shanghai" },
  "payload": {
    "kind": "agentTurn",
    "message": "执行 Windows C盘例行体检：运行 scan.py 扫描C盘，如果可用空间 < 5GB 则推送告警给用户，否则静默记录结果。"
  },
  "sessionTarget": "isolated",
  "delivery": { "mode": "announce", "channel": "当前频道" }
}
```

### macOS / Linux / 鸿蒙 版（每周日凌晨 3:00）

```json
{
  "name": "磁盘定期体检（跨平台）",
  "schedule": { "kind": "cron", "expr": "0 3 * * 0", "tz": "Asia/Shanghai" },
  "payload": {
    "kind": "agentTurn",
    "message": "执行磁盘例行体检：运行 scan.py --all-drives 扫描所有磁盘，如果任意磁盘可用空间 < 5GB 则推送告警，否则静默记录。"
  },
  "sessionTarget": "isolated",
  "delivery": { "mode": "announce", "channel": "当前频道" }
}
```

---

## 技术说明

- **语言**：Python 3.7+（仅标准库：os, sys, json, shutil, platform, time）
- **依赖**：无（零依赖安装）
- **跨平台检测**：`sys.platform` + `platform.version()` 识别鸿蒙
- **文件结构**：
  ```
  c-drive-cleaner/
  ├── SKILL.md              ← 你正在读的这个文件
  ├── scripts/
  │   ├── scan.py           ← 体检扫描器（跨平台）
  │   ├── clean.py          ← 净化执行器（跨平台）
  │   └── report.py         ← 报告生成器（可选，未来版本）
  └── output/               ← 运行结果自动保存到这里
      ├── scan_result.json
      └── clean_result.json
  ```
- **鸿蒙适配说明**：HarmonyOS 基于 Linux 内核，所以 Linux 清理项全部适用。额外处理：检测 `platform.version()` 中是否包含 "HarmonyOS" 字符串，如果是则标记为鸿蒙模式，未来可扩展鸿蒙专属清理逻辑。
