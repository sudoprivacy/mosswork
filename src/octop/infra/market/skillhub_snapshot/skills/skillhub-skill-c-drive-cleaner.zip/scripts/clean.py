# -*- coding: utf-8 -*-
"""
磁盘清理执行器 v3.0 - 跨平台安全净化引擎
支持: Windows / macOS / Linux / HarmonyOS (鸿蒙)

仅使用 Python 标准库，无需第三方依赖
v3.0 新增：跨平台支持、鸿蒙OS适配、安全确认增强、操作日志增强
"""
import os
import sys
import json
import shutil
import time
import platform
from datetime import datetime

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
OUTPUT_DIR = os.path.join(SKILL_DIR, 'output')
TRASH_META_DIR = os.path.join(SKILL_DIR, '_trash_meta')
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(TRASH_META_DIR, exist_ok=True)

# ========== 平台检测 ==========
PLATFORM = platform.system()
IS_WINDOWS = PLATFORM == 'Windows'
IS_MACOS = PLATFORM == 'Darwin'
IS_LINUX = PLATFORM == 'Linux'
IS_HARMONY = 'HarmonyOS' in platform.version() or 'HarmonyOS' in platform.platform()

def get_platform_label():
    if IS_HARMONY:
        return "HarmonyOS (鸿蒙)"
    elif IS_MACOS:
        return "macOS"
    elif IS_LINUX:
        return "Linux"
    elif IS_WINDOWS:
        return "Windows"
    else:
        return PLATFORM


# ========== 跨平台清理项定义 ==========

# Windows 清理项
WIN_CLEAN_ITEMS = {
    "用户临时文件": {"path_func": lambda: os.environ.get('TEMP', ''), "risk": "safe", "key": "temp", "desc": "用户临时文件"},
    "系统临时文件": {"path": r"C:\Windows\Temp", "risk": "safe", "key": "system-temp", "desc": "Windows 系统临时文件"},
    "缩略图缓存": {"path_func": lambda: os.environ.get('LOCALAPPDATA', '') + r"\Microsoft\Windows\Explorer", "pattern": "thumbcache_*", "risk": "low", "key": "thumbnail-cache", "desc": "Windows 缩略图缓存"},
    "Windows日志": {"path": r"C:\Windows\Logs\CBS", "risk": "low", "key": "windows-logs", "desc": "Windows CBS 日志"},
    "Windows更新缓存": {"path": r"C:\Windows\SoftwareDistribution\Download", "risk": "low", "key": "windows-update", "desc": "Windows 更新下载缓存"},
}

# macOS 清理项
MACOS_CLEAN_ITEMS = {
    "用户缓存": {"path_func": lambda: os.path.expanduser("~/Library/Caches"), "risk": "safe", "key": "user-cache", "desc": "macOS 用户缓存"},
    "系统缓存": {"path": "/Library/Caches", "risk": "low", "key": "system-cache", "desc": "macOS 系统缓存"},
    "用户日志": {"path_func": lambda: os.path.expanduser("~/Library/Logs"), "risk": "safe", "key": "user-logs", "desc": "macOS 用户日志"},
    "回收站": {"path_func": lambda: os.path.expanduser("~/.Trash"), "risk": "safe", "key": "trash", "desc": "macOS 回收站"},
    "Xcode缓存": {"path_func": lambda: os.path.expanduser("~/Library/Developer/Xcode/DerivedData"), "risk": "safe", "key": "xcode-cache", "desc": "Xcode 构建缓存"},
    "brew缓存": {"path": "/Library/Caches/Homebrew", "risk": "safe", "key": "brew-cache", "desc": "Homebrew 下载缓存"},
}

# Linux / 鸿蒙 清理项
LINUX_CLEAN_ITEMS = {
    "用户缓存": {"path_func": lambda: os.path.expanduser("~/.cache"), "risk": "safe", "key": "user-cache", "desc": "Linux 用户缓存"},
    "系统日志": {"path": "/var/log", "risk": "low", "key": "system-logs", "desc": "系统日志 (/var/log)"},
    "临时文件": {"path": "/tmp", "risk": "safe", "key": "temp", "desc": "系统临时文件 (/tmp)"},
    "回收站": {"path_func": lambda: os.path.expanduser("~/.local/share/Trash"), "risk": "safe", "key": "trash", "desc": "Linux 回收站"},
    "旧内核": {"path": "/boot", "risk": "confirm", "key": "old-kernels", "desc": "旧内核文件 (/boot) — 需确认"},
}

# 通用开发者缓存（跨平台）
DEV_CLEAN_ITEMS = {
    "npm缓存": {"path_func": lambda: os.path.expanduser("~/.npm/_cache"), "risk": "safe", "key": "npm-cache", "desc": "npm 包缓存"},
    "pip缓存": {"path_func": lambda: os.path.expanduser("~/.pip/cache"), "risk": "safe", "key": "pip-cache", "desc": "pip 下载缓存"},
    "conda包缓存": {"path_func": lambda: os.path.expanduser("~/.conda/pkgs"), "risk": "safe", "key": "conda-cache", "desc": "conda 包缓存"},
    "NuGet缓存": {"path_func": lambda: os.path.expanduser("~/.nuget/packages"), "risk": "safe", "key": "nuget-cache", "desc": "NuGet 包缓存", "platforms": ["Windows"]},
    "Gradle缓存": {"path_func": lambda: os.path.expanduser("~/.gradle/caches"), "risk": "safe", "key": "gradle-cache", "desc": "Gradle 构建缓存"},
    "Cargo缓存": {"path_func": lambda: os.path.expanduser("~/.cargo/registry"), "risk": "safe", "key": "cargo-cache", "desc": "Rust Cargo 缓存"},
    "通用缓存": {"path_func": lambda: os.path.expanduser("~/.cache"), "risk": "safe", "key": "generic-cache", "desc": "通用缓存目录"},
}


def get_clean_items_for_platform():
    """根据当前平台返回对应的清理项"""
    if IS_HARMONY or IS_LINUX:
        items = {**LINUX_CLEAN_ITEMS, **DEV_CLEAN_ITEMS}
    elif IS_MACOS:
        items = {**MACOS_CLEAN_ITEMS, **DEV_CLEAN_ITEMS}
    else:  # Windows 默认
        items = {**WIN_CLEAN_ITEMS, **DEV_CLEAN_ITEMS}
    
    # 过滤掉不适用的平台
    filtered = {}
    for name, info in items.items():
        platforms = info.get("platforms", None)
        if platforms is None:
            filtered[name] = info
        elif PLATFORM in platforms or (IS_HARMONY and "Linux" in platforms):
            filtered[name] = info
    return filtered


def get_dir_size(path):
    if not path or not os.path.exists(path):
        return 0
    total = 0
    try:
        for entry in os.scandir(path):
            if entry.is_file(follow_symlinks=False):
                total += entry.stat().st_size
            elif entry.is_dir(follow_symlinks=False):
                try:
                    total += get_dir_size(entry.path)
                except (PermissionError, OSError):
                    pass
    except (PermissionError, OSError):
        pass
    return total


def format_size(size_bytes):
    if size_bytes < 0:
        return "未知"
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


def save_trash_meta(item_name, path, deleted_entries, freed_bytes):
    """保存删除元数据"""
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    meta_file = os.path.join(TRASH_META_DIR, f"trash_{item_name.replace(' ', '_')}_{ts}.json")
    
    meta = {
        "deleted_at": datetime.now().isoformat(),
        "item_name": item_name,
        "target_path": path,
        "platform": PLATFORM,
        "platform_label": get_platform_label(),
        "total_freed_bytes": freed_bytes,
        "total_freed_str": format_size(freed_bytes),
        "entry_count": len(deleted_entries),
        "entries": deleted_entries[:100],
        "truncated": len(deleted_entries) > 100,
        "note": "这些都是缓存/临时文件，程序需要时会自动重建",
    }
    
    with open(meta_file, 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2, default=str)
    
    return meta_file


def clean_dir(path, dry_run=True, item_name=""):
    """清理目录内容（不删除目录本身）"""
    if not path or not os.path.exists(path):
        return 0, [], f"路径不存在：{path}"

    freed = 0
    errors = []
    deleted_entries = []
    count = 0

    try:
        for entry in os.scandir(path):
            try:
                entry_info = {
                    "name": entry.name,
                    "is_dir": entry.is_dir(follow_symlinks=False),
                }
                
                if entry.is_file(follow_symlinks=False):
                    sz = entry.stat().st_size
                    if not dry_run:
                        os.remove(entry.path)
                    freed += sz
                    count += 1
                    entry_info["size"] = sz
                    entry_info["path"] = entry.path
                    deleted_entries.append(entry_info)
                    
                elif entry.is_dir(follow_symlinks=False):
                    sz = get_dir_size(entry.path)
                    if not dry_run:
                        shutil.rmtree(entry.path, ignore_errors=True)
                    freed += sz
                    count += 1
                    entry_info["size"] = sz
                    entry_info["path"] = entry.path
                    deleted_entries.append(entry_info)
                    
            except (PermissionError, OSError) as e:
                errors.append({"entry": entry.name, "error": str(e)})
    except (PermissionError, OSError) as e:
        errors.append({"error": str(e)})

    if not dry_run and deleted_entries and item_name:
        save_trash_meta(item_name, path, deleted_entries, freed)

    status = "预览" if dry_run else "已清理"
    msg = f"{status} {count} 个文件/文件夹，{format_size(freed)}"
    if errors:
        msg += f"（{len(errors)}个因权限不足跳过）"

    return freed, errors, msg


def clean_files_by_pattern(dir_path, pattern_prefix, dry_run=True, item_name=""):
    """按前缀匹配清理特定文件"""
    if not dir_path or not os.path.isdir(dir_path):
        return 0, [], "目录不存在"

    freed = 0
    count = 0
    errors = []
    deleted_entries = []
    prefix = pattern_prefix.replace("*", "")

    try:
        for f in os.listdir(dir_path):
            if f.startswith(prefix):
                fp = os.path.join(dir_path, f)
                if os.path.isfile(fp):
                    sz = os.path.getsize(fp)
                    if not dry_run:
                        os.remove(fp)
                    freed += sz
                    count += 1
                    deleted_entries.append({"name": f, "path": fp, "size": sz, "is_dir": False})
    except (PermissionError, OSError) as e:
        errors.append({"error": str(e)})

    if not dry_run and deleted_entries and item_name:
        save_trash_meta(item_name, dir_path, deleted_entries, freed)

    status = "预览" if dry_run else "已清理"
    return freed, errors, f"{status} {count} 个文件，{format_size(freed)}"


def get_disk_free(path="/" if not IS_WINDOWS else "C:\\"):
    """获取磁盘剩余空间"""
    try:
        import shutil
        usage = shutil.disk_usage(path)
        return usage.free
    except Exception:
        return 0


def countdown(seconds=3):
    """倒计时确认"""
    print(f"\n  ⏱️  将在 {seconds} 秒后开始执行清理...")
    for i in range(seconds, 0, -1):
        print(f"    {i}...")
        time.sleep(1)


def main():
    dry_run = True
    items_to_clean = []
    clean_safe_only = False
    skip_confirm = False

    # 解析参数
    i = 0
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg in ('--dry-run', '--preview'):
            dry_run = True
        elif arg in ('--execute', '--run', '--force'):
            dry_run = False
        elif arg == '--all-safe':
            clean_safe_only = True
            all_items = get_clean_items_for_platform()
            for name, info in all_items.items():
                if info['risk'] == 'safe':
                    items_to_clean.append(name)
        elif arg.startswith('--items='):
            items_str = arg.split('=', 1)[1]
            items_to_clean = [x.strip() for x in items_str.split(',')]
        elif arg == '-y' or arg == '--yes':
            skip_confirm = True
        i += 1

    platform_label = get_platform_label()
    mode_label = "🔍 预览模式（不会删除任何文件）" if dry_run else "⚡ 执行模式（将实际删除）"
    print("=" * 60)
    print(f"  轻C · 净化器 v3.0 - {platform_label} 版")
    print(f"  {mode_label}")
    print(f"  ⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # 清理前磁盘状态
    default_path = "C:\\" if IS_WINDOWS else "/"
    free_before = get_disk_free(default_path)
    print(f"\n  清理前磁盘可用：{format_size(free_before)}")

    # 如果是执行模式且未跳过确认，显示倒计时
    if not dry_run and not skip_confirm and items_to_clean:
        print("\n  即将执行以下清理操作：")
        all_items = get_clean_items_for_platform()
        for name in items_to_clean:
            info = all_items.get(name, {})
            icon = "🟢" if info.get('risk') == 'safe' else "🟡"
            print(f"    {icon} {name} — {info.get('desc', '')}")
        countdown(3)

    # 执行清理
    total_freed = 0
    results = []
    all_errors = []

    all_items = get_clean_items_for_platform()
    
    if not items_to_clean:
        # 默认清理所有安全项
        items_to_clean = [n for n, i in all_items.items() if i['risk'] == 'safe']

    for item_name in items_to_clean:
        if item_name not in all_items:
            print(f'\n  ❌ 未知清理项：{item_name}，跳过')
            continue

        info = all_items[item_name]
        path = info.get("path")
        if path is None and "path_func" in info:
            try:
                path = info["path_func"]()
            except Exception:
                path = ""

        icon = "🟢" if info['risk'] == 'safe' else "🟡"
        print(f"\n  {icon} [{item_name}] {info.get('desc', '')}")

        if "pattern" in info:
            freed, errs, msg = clean_files_by_pattern(path, info["pattern"], dry_run, item_name if not dry_run else "")
        else:
            freed, errs, msg = clean_dir(path, dry_run, item_name if not dry_run else "")

        total_freed += freed
        results.append({"name": item_name, "freed": freed, "msg": msg})
        
        if errs:
            all_errors.extend(errs)
            print(f"     → {msg}")
            print(f"     → ⚠️ {len(errs)} 个文件跳过（权限不足）")
        else:
            print(f"     → {msg}")

    # 清理后对比
    print(f"\n{'─'*55}")
    if not dry_run:
        free_after = get_disk_free(default_path)
        actual_freed = free_after - free_before
        
        print(f"  清理后磁盘可用：{format_size(free_after)}")
        print(f"  实际释放空间：   {format_size(actual_freed)}")
    else:
        print(f"  📊 本次预计释放：{format_size(total_freed)}")
        print(f"  💡 这是预览模式。如需实际清理，请加 --execute 参数")

    # 错误汇总
    if all_errors:
        print(f"\n  ⚠️  错误汇总（共 {len(all_errors)} 个权限错误）：")
        unique_errors = {}
        for e in all_errors:
            key = e.get('error', '未知')[:40]
            unique_errors[key] = unique_errors.get(key, 0) + 1
        for err_msg, cnt in list(unique_errors.items())[:5]:
            print(f"    • {err_msg} (×{cnt}次)")

    # 保存结果
    result = {
        "version": "3.0",
        "platform": PLATFORM,
        "platform_label": platform_label,
        "is_harmonyos": IS_HARMONY,
        "mode": "dry_run" if dry_run else "execute",
        "time": datetime.now().isoformat(),
        "items_cleaned": results,
        "total_freed": total_freed,
        "total_freed_gb": round(total_freed / (1024**3), 2),
        "disk_before_free": free_before,
        "disk_before_free_gb": round(free_before / (1024**3), 2),
        "error_count": len(all_errors),
        "errors_summary": all_errors[:20],
    }
    if not dry_run:
        free_after = get_disk_free(default_path)
        result["disk_after_free"] = free_after
        result["disk_after_free_gb"] = round(free_after / (1024**3), 2)
        result["actual_freed"] = free_after - free_before
        result["actual_freed_gb"] = round((free_after - free_before) / (1024**3), 2)

    json_path = os.path.join(OUTPUT_DIR, 'clean_result.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=str)
    
    print(f"\n  {'='*60}")
    print(f"  💾 操作日志：{json_path}")
    if not dry_run:
        print(f"  🗑️  删除元数据：{TRASH_META_DIR}\\")
    print(f"  ✅ 净化完成\n")


if __name__ == '__main__':
    main()
