# -*- coding: utf-8 -*-
"""
磁盘空间扫描器 v3.0 - 跨平台体检诊断引擎
支持: Windows / macOS / Linux / HarmonyOS (鸿蒙)

仅使用 Python 标准库，无需第三方依赖
v3.0 新增：跨平台支持、鸿蒙OS适配、多盘符扫描、异常全景报告增强
"""
import os
import sys
import json
import shutil
import platform
from datetime import datetime

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
OUTPUT_DIR = os.path.join(SKILL_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ========== 平台检测 ==========
PLATFORM = platform.system()  # 'Windows', 'Darwin'(macOS), 'Linux', 'HarmonyOS'
IS_WINDOWS = PLATFORM == 'Windows'
IS_MACOS = PLATFORM == 'Darwin'
IS_LINUX = PLATFORM == 'Linux'
# 鸿蒙检测：HarmonyOS 基于 Linux，但有特定标识
IS_HARMONY = 'HarmonyOS' in platform.version() or 'HarmonyOS' in platform.platform()


def get_platform_label():
    if IS_HARMONY:
        return "HarmonyOS (鸿蒙)"
    elif IS_MACOS:
        return "macOS"
    elif IS_LINUX:
        return "Linux"
    elif IS_WINDOWS:
        return "Windows"
    else:
        return PLATFORM


# ========== 跨平台缓存目录定义 ==========

# Windows 缓存项
WIN_SAFE_ITEMS = {
    "用户临时文件": {"path_func": lambda: os.environ.get('TEMP', ''), "risk": "safe", "desc": "用户临时文件 (%TEMP%)", "key": "temp"},
    "系统临时文件": {"path": r"C:\Windows\Temp", "risk": "safe", "desc": "Windows 系统临时文件", "key": "system-temp"},
    "缩略图缓存": {"path_func": lambda: os.environ.get('LOCALAPPDATA', '') + r"\Microsoft\Windows\Explorer", "pattern": "thumbcache_*", "risk": "low", "desc": "Windows 缩略图缓存", "key": "thumbnail-cache"},
    "Windows日志": {"path": r"C:\Windows\Logs\CBS", "risk": "low", "desc": "Windows CBS 日志", "key": "windows-logs"},
    "Windows更新缓存": {"path": r"C:\Windows\SoftwareDistribution\Download", "risk": "low", "desc": "Windows 更新下载缓存", "key": "windows-update"},
}

# macOS 缓存项
MACOS_SAFE_ITEMS = {
    "用户缓存": {"path_func": lambda: os.path.expanduser("~/Library/Caches"), "risk": "safe", "desc": "macOS 用户缓存 (~/Library/Caches)", "key": "user-cache"},
    "系统缓存": {"path": "/Library/Caches", "risk": "low", "desc": "macOS 系统缓存", "key": "system-cache"},
    "用户日志": {"path_func": lambda: os.path.expanduser("~/Library/Logs"), "risk": "safe", "desc": "macOS 用户日志", "key": "user-logs"},
    "回收站": {"path_func": lambda: os.path.expanduser("~/.Trash"), "risk": "safe", "desc": "macOS 回收站 (~/.Trash)", "key": "trash"},
    "Xcode缓存": {"path_func": lambda: os.path.expanduser("~/Library/Developer/Xcode/DerivedData"), "risk": "safe", "desc": "Xcode 构建缓存", "key": "xcode-cache"},
    "pip缓存": {"path_func": lambda: os.path.expanduser("~/.pip/cache"), "risk": "safe", "desc": "pip 下载缓存", "key": "pip-cache"},
    "brew缓存": {"path": "/Library/Caches/Homebrew", "risk": "safe", "desc": "Homebrew 下载缓存", "key": "brew-cache"},
}

# Linux / 鸿蒙 缓存项
LINUX_SAFE_ITEMS = {
    "用户缓存": {"path_func": lambda: os.path.expanduser("~/.cache"), "risk": "safe", "desc": "Linux 用户缓存 (~/.cache)", "key": "user-cache"},
    "系统日志": {"path": "/var/log", "risk": "low", "desc": "系统日志 (/var/log)", "key": "system-logs"},
    "临时文件": {"path": "/tmp", "risk": "safe", "desc": "系统临时文件 (/tmp)", "key": "temp"},
    "回收站": {"path_func": lambda: os.path.expanduser("~/.local/share/Trash"), "risk": "safe", "desc": "Linux 回收站", "key": "trash"},
    "pip缓存": {"path_func": lambda: os.path.expanduser("~/.pip/cache"), "risk": "safe", "desc": "pip 下载缓存", "key": "pip-cache"},
    "npm缓存": {"path_func": lambda: os.path.expanduser("~/.npm/_cache"), "risk": "safe", "desc": "npm 包缓存", "key": "npm-cache"},
    "conda包缓存": {"path_func": lambda: os.path.expanduser("~/.conda/pkgs"), "risk": "safe", "desc": "conda 包缓存", "key": "conda-cache"},
}

# 通用开发者缓存（跨平台）
DEV_CACHE_ITEMS = {
    "npm缓存": {"path_func": lambda: os.path.expanduser("~/.npm/_cache"), "risk": "safe", "desc": "npm 包缓存", "key": "npm-cache", "platforms": ["Windows", "Darwin", "Linux"]},
    "pip缓存": {"path_func": lambda: os.path.expanduser("~/.pip/cache"), "risk": "safe", "desc": "pip 下载缓存", "key": "pip-cache", "platforms": ["Windows", "Darwin", "Linux"]},
    "conda包缓存": {"path_func": lambda: os.path.expanduser("~/.conda/pkgs"), "risk": "safe", "desc": "conda 包缓存", "key": "conda-cache", "platforms": ["Windows", "Darwin", "Linux"]},
    "NuGet缓存": {"path_func": lambda: os.path.expanduser("~/.nuget/packages"), "risk": "safe", "desc": "NuGet 包缓存", "key": "nuget-cache", "platforms": ["Windows"]},
    "Gradle缓存": {"path_func": lambda: os.path.expanduser("~/.gradle/caches"), "risk": "safe", "desc": "Gradle 构建缓存", "key": "gradle-cache", "platforms": ["Windows", "Darwin", "Linux"]},
    "Cargo缓存": {"path_func": lambda: os.path.expanduser("~/.cargo/registry"), "risk": "safe", "desc": "Rust Cargo 缓存", "key": "cargo-cache", "platforms": ["Windows", "Darwin", "Linux"]},
    "通用缓存": {"path_func": lambda: os.path.expanduser("~/.cache"), "risk": "safe", "desc": "通用缓存目录 (~/.cache)", "key": "generic-cache", "platforms": ["Windows", "Darwin", "Linux"]},
}


def get_cache_items_for_platform():
    """根据当前平台返回对应的缓存项列表"""
    if IS_HARMONY or IS_LINUX:
        items = {**LINUX_SAFE_ITEMS, **DEV_CACHE_ITEMS}
    elif IS_MACOS:
        items = {**MACOS_SAFE_ITEMS, **DEV_CACHE_ITEMS}
    else:  # Windows 默认
        items = {**WIN_SAFE_ITEMS, **DEV_CACHE_ITEMS}
    
    # 过滤掉不适用的平台
    filtered = {}
    for name, info in items.items():
        platforms = info.get("platforms", None)
        if platforms is None:
            filtered[name] = info
        elif PLATFORM in platforms or (IS_HARMONY and "Linux" in platforms):
            filtered[name] = info
    return filtered


def get_default_drive():
    """获取默认扫描盘符/路径"""
    if IS_WINDOWS:
        return "C:\\"
    elif IS_MACOS:
        return "/"
    elif IS_HARMONY or IS_LINUX:
        return "/"
    else:
        return "/"


def get_all_drives():
    """获取所有可扫描的盘符/挂载点"""
    drives = []
    if IS_WINDOWS:
        import string
        from ctypes import windll
        bitmask = windll.kernel32.GetLogicalDrives()
        for letter in string.ascii_uppercase:
            if bitmask & 1:
                drives.append(f"{letter}:\\")
            bitmask >>= 1
    elif IS_MACOS:
        drives = ["/", "/Volumes/Home", "/Volumes/Macintosh HD"]
        # 获取所有挂载卷
        try:
            for entry in os.scandir("/Volumes"):
                if entry.is_dir():
                    drives.append(entry.path)
        except Exception:
            pass
    elif IS_HARMONY or IS_LINUX:
        drives = ["/", "/home"]
        try:
            for entry in os.scandir("/mnt"):
                if entry.is_dir():
                    drives.append(entry.path)
        except Exception:
            pass
    return list(set(drives))  # 去重


def get_dir_size(path):
    """计算目录大小，出错时返回 -1"""
    if not path or not os.path.exists(path):
        return -1
    total = 0
    try:
        for entry in os.scandir(path):
            if entry.is_file(follow_symlinks=False):
                total += entry.stat().st_size
            elif entry.is_dir(follow_symlinks=False):
                try:
                    total += get_dir_size(entry.path)
                except (PermissionError, OSError):
                    pass
    except (PermissionError, OSError):
        pass
    return total


def format_size(size_bytes):
    """格式化字节为可读大小"""
    if size_bytes < 0:
        return "无法访问"
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


def calc_health_score(free_gb, total_gb, pct_used):
    """计算磁盘健康评分（满分100）"""
    free_pct = (free_gb / total_gb) * 100 if total_gb > 0 else 0
    
    if free_gb >= 20:
        base = 95
    elif free_gb >= 10:
        base = 85 - (20 - free_gb) * 1.0
    elif free_gb >= 5:
        base = 65 - (10 - free_gb) * 4.0
    else:
        base = max(10, 45 - (5 - free_gb) * 7.0)
    
    if pct_used > 98:
        base -= 15
    elif pct_used > 95:
        base -= 8
    elif pct_used > 90:
        base -= 3
    
    return max(0, min(100, round(base)))


def get_health_label(score):
    if score >= 90:
        return "健康", "🟢"
    elif score >= 70:
        return "注意", "🟡"
    elif score >= 50:
        return "警告", "🟠"
    else:
        return "危险", "🔴"


def calc_benefit_ratio(size_bytes, risk_level):
    if size_bytes <= 0:
        return 0
    risk_map = {"safe": 1, "low": 3, "confirm": 9}
    risk_factor = risk_map.get(risk_level, 9)
    return size_bytes / risk_factor


def scan_top_dirs(drive, top_n=20):
    """扫描磁盘根目录下各文件夹大小"""
    results = []
    skipped_dirs = []
    
    try:
        entries = list(os.scandir(drive))
    except PermissionError as e:
        skipped_dirs.append({"name": drive, "reason": str(e)})
        return results, skipped_dirs

    for entry in entries:
        if not entry.is_dir(follow_symlinks=False):
            continue
        name = entry.name
        # 跨平台跳过系统保护目录
        skip_names = ['$RECYCLE.BIN', 'System Volume Information', 'Recovery',
                      '.Trashes', '.Spotlight-V100', '.fseventsd',
                      'lost+found', '.Trash', '.localized']
        if name in skip_names:
            continue
        try:
            size = get_dir_size(entry.path)
        except (PermissionError, OSError) as e:
            skipped_dirs.append({"name": name, "path": entry.path, "reason": str(e)})
            size = -1
        results.append({"name": name, "path": entry.path, "size": size, "size_str": format_size(size)})

    results.sort(key=lambda x: x["size"], reverse=True)
    return results[:top_n], skipped_dirs


def scan_cache_items():
    """扫描所有预定义的缓存项"""
    items = []
    skipped = []
    cache_items = get_cache_items_for_platform()

    for name, info in cache_items.items():
        path = info.get("path")
        if path is None and "path_func" in info:
            try:
                path = info["path_func"]()
            except Exception as e:
                skipped.append({"item": name, "reason": f"路径解析失败: {e}"})
                path = ""
        
        if not path:
            size = -1
        else:
            try:
                size = get_dir_size(path)
            except (PermissionError, OSError) as e:
                size = -2
                skipped.append({"item": name, "path": path, "reason": f"权限不足: {e}"})
        
        if "pattern" in info and path and os.path.isdir(path):
            prefix = info["pattern"].replace("*", "")
            total = 0
            try:
                for f in os.listdir(path):
                    if f.startswith(prefix):
                        fp = os.path.join(path, f)
                        if os.path.isfile(fp):
                            total += os.path.getsize(fp)
            except (PermissionError, OSError) as e:
                skipped.append({"item": name, "reason": f"扫描模式文件时出错: {e}"})
            size = total
        
        benefit = calc_benefit_ratio(size, info.get("risk", "confirm"))
        
        items.append({
            "name": name,
            "path": path,
            "size": size,
            "size_str": format_size(size),
            "risk": info["risk"],
            "desc": info["desc"],
            "key": info.get("key", name),
            "benefit_ratio": benefit,
        })

    items.sort(key=lambda x: x["benefit_ratio"], reverse=True)
    return items, skipped


def scan_large_files(drive, min_size_mb=100, top_n=20):
    """找出大于指定大小的文件"""
    min_bytes = min_size_mb * 1024 * 1024
    large_files = []
    scanned = 0
    access_errors = []

    sys_skip = ['$RECYCLE.BIN', 'System Volume Information', 'Recovery',
                 'Windows\\System32', 'Windows\\WinSxS',
                 '.Trashes', '.Spotlight-V100', 'lost+found']

    for root, dirs, files in os.walk(drive):
        dirs[:] = [d for d in dirs if d not in sys_skip]
        for fname in files:
            try:
                fp = os.path.join(root, fname)
                size = os.path.getsize(fp)
                if size >= min_bytes:
                    large_files.append({
                        "name": fname,
                        "path": fp,
                        "size": size,
                        "size_str": format_size(size),
                    })
                scanned += 1
            except (PermissionError, OSError) as e:
                access_errors.append(str(fp))
                continue

        if scanned > 50000:
            break

    large_files.sort(key=lambda x: x["size"], reverse=True)
    return large_files[:top_n], len(access_errors)


def main():
    drive = get_default_drive()
    
    # 解析参数
    i = 0
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg.startswith("--drive="):
            drive = arg.split("=", 1)[1]
        elif arg == "--all-drives":
            # 扫描所有盘
            pass  # 在后面处理
        i += 1

    platform_label = get_platform_label()
    print("=" * 60)
    print(f"  轻C · 磁盘体检报告")
    print(f"  🖥️  平台：{platform_label}")
    print(f"  ⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # 多盘扫描
    if "--all-drives" in sys.argv:
        drives = get_all_drives()
        print(f"\n  扫描所有磁盘：{', '.join(drives)}")
        for d in drives:
            usage = shutil.disk_usage(d)
            free_gb = usage.free / (1024**3)
            total_gb = usage.total / (1024**3)
            pct = (usage.used / usage.total) * 100
            score = calc_health_score(free_gb, total_gb, pct)
            label, icon = get_health_label(score)
            print(f"    {d:<15} {total_gb:>6.1f} GB  已用{pct:>5.1f}%  可用{free_gb:>6.1f} GB  {icon}{label}")
        print()
        drive = drives[0] if drives else drive  # 默认扫描第一个

    # ===== 磁盘总览 =====
    usage = shutil.disk_usage(drive)
    total_gb = usage.total / (1024**3)
    used_gb = usage.used / (1024**3)
    free_gb = usage.free / (1024**3)
    pct_used = (usage.used / usage.total) * 100
    
    score = calc_health_score(free_gb, total_gb, pct_used)
    label, icon = get_health_label(score)

    print(f"\n  📊 磁盘总览：{drive.rstrip('/\\')}")
    print(f"  总容量：{total_gb:.1f} GB")
    print(f"  已使用：{used_gb:.1f} GB ({pct_used:.1f}%)")
    print(f"  可用：  {free_gb:.1f} GB")
    print(f"\n  🩺 健康评分：{score} 分 {icon} ({label})")

    # ===== Top 目录 =====
    print(f"\n{'─'*55}")
    print(f"  📁 Top 占用目录：")
    print(f"{'─'*55}")
    top_dirs, dir_skipped = scan_top_dirs(drive)
    for i, d in enumerate(top_dirs, 1):
        warn = " ⚠️" if d['size'] > 2*1024**3 else ""
        lock = " 🔒" if d['name'] in ('Windows', 'Program Files', 'Program Files (x86)',
                                        'Library', 'System', 'private', 'usr', 'bin') else ""
        cleanable = " ✅" if d['size'] > 0 and d['name'] not in ('Windows', 'Program Files', 'Program Files (x86)', '.qclaw', 'Library', 'System') else ""
        print(f"    {i:2}. {d['name']:<25} {d['size_str']:>10}{warn}{lock}{cleanable}")

    # ===== 缓存扫描 =====
    print(f"\n{'─'*55}")
    print(f"  💊 推荐处方（按效益比排序）：")
    print(f"{'─'*55}")
    cache_items, cache_skipped = scan_cache_items()
    safe_total = 0
    low_risk_total = 0

    for item in cache_items:
        icon_risk = "🟢" if item['risk'] == 'safe' else "🟡"
        if item['size'] > 0:
            if item['risk'] == 'safe':
                safe_total += item['size']
            else:
                low_risk_total += item['size']
            benefit_mb = item['benefit_ratio'] / 1024 / 1024
            print(f"  {icon_risk} {item['name']:<16} {item['size_str']:>10}  效益比:{benefit_mb:.0f}MB/风险  ({item['desc']})")
        elif item['size'] == -2:
            print(f"  ⛔ {item['name']:<16} {'权限不足':>10}  需管理员权限")
        else:
            print(f"  ⊘ {item['name']:<16} {'不存在':>10}")

    print(f"\n    🟢 安全项合计可释放：{format_size(safe_total)}")
    if low_risk_total > 0:
        print(f"    🟡 含低风险可释放：     {format_size(safe_total + low_risk_total)}")

    # ===== 大文件 =====
    print(f"\n{'─'*55}")
    print(f"  📄 大文件 Top 15（>100MB）：")
    print(f"{'─'*55}")
    large_files, file_errors = scan_large_files(drive, min_size_mb=100, top_n=15)
    if large_files:
        for i, f in enumerate(large_files, 1):
            display_path = f['path'] if len(f['path']) <= 65 else "..." + f['path'][-62:]
            print(f"    {i:2}. {f['size_str']:>8}  {display_path}")
    else:
        print("    （未找到超过100MB的文件，或扫描被权限限制）")

    # ===== 异常全景报告 =====
    all_skipped = dir_skipped + cache_skipped
    if all_skipped or file_errors > 0:
        print(f"\n{'═'*55}")
        print(f"  ⚠️  异常报告（以下路径无法访问/扫描）：")
        print(f"{'═'*55}")
        if dir_skipped:
            print(f"\n  📁 因权限跳过的目录（{len(dir_skipped)}个）：")
            for d in dir_skipped[:10]:
                reason = d.get('reason', '未知错误')[:50]
                print(f"    • {d.get('name', '?')} — {reason}")
        if cache_skipped:
            print(f"\n  🧹 缓存项扫描异常（{len(cache_skipped)}个）：")
            for c in cache_skipped[:10]:
                print(f"    • {c.get('item', '?')} — {c.get('reason', '?')[:60]}")
        if file_errors > 0:
            print(f"\n  📄 大文件扫描中遇到 {file_errors} 个权限错误（已跳过）")
        print(f"\n  💡 提示：部分系统目录需要管理员权限才能完整扫描。")

    # ===== 输出 JSON =====
    result = {
        "version": "3.0",
        "platform": PLATFORM,
        "platform_label": platform_label,
        "is_harmonyos": IS_HARMONY,
        "scan_time": datetime.now().isoformat(),
        "health_score": score,
        "health_label": label,
        "disk": {
            "drive": drive,
            "total": usage.total,
            "used": usage.used,
            "free": usage.free,
            "total_gb": round(total_gb, 2),
            "used_gb": round(used_gb, 2),
            "free_gb": round(free_gb, 2),
            "pct_used": round(pct_used, 1),
        },
        "top_dirs": top_dirs,
        "cache_items": sorted(cache_items, key=lambda x: x['benefit_ratio'], reverse=True),
        "large_files": large_files,
        "summary": {
            "safe_cleanable": safe_total,
            "low_risk_cleanable": safe_total + low_risk_total,
            "safe_cleanable_gb": round(safe_total / (1024**3), 2),
            "low_risk_cleanable_gb": round((safe_total + low_risk_total) / (1024**3), 2),
        },
        "skipped": {
            "dirs": dir_skipped,
            "cache": cache_skipped,
            "file_access_errors": file_errors,
        }
    }

    json_path = os.path.join(OUTPUT_DIR, 'scan_result.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n  💾 详细结果已保存：{json_path}")
    print(f"  🩺 体检完成。建议将报告交由 AI 分析后给出净化方案。\n")


if __name__ == '__main__':
    main()
