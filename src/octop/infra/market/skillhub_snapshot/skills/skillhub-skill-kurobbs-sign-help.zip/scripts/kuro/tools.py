"""工具函数（移植自 Kuro-autosignin tools.py）"""

import logging
import random
import time
import uuid
from typing import Optional

from .http_client import KuroHttpClient
from .constants import API

logger = logging.getLogger("kuro")


def random_delay(min_seconds: int = 5, max_seconds: int = 15) -> float:
    """随机延迟后等待，用于重试抖动，避免请求过快触发限流"""
    delay_seconds = random.uniform(min_seconds, max_seconds)
    logger.info("将在 %.2f 秒后重试...", delay_seconds)
    time.sleep(delay_seconds)
    return delay_seconds


def get_user_info_by_token(
    token: str, devcode: str, distinct_id: str, source: str = "ios", version: str = "2.2.0"
) -> Optional[str]:
    """根据 token 获取用户 ID（用于配置自动填充）"""
    try:
        client = KuroHttpClient(token, devcode, distinct_id, source, version)
        response = client.user_info_post(API.USER_MINE, raise_on_error=False)
        if response.is_success() and response.data:
            user_id = response.data.get("mine", {}).get("userId")
            if user_id:
                logger.info("获取用户信息成功，用户ID: %s", user_id)
                return user_id
        logger.error("获取用户信息失败: %s", response.message)
        return None
    except Exception as e:
        logger.error("请求失败: %s", e)
        return None


def get_game_user_id(
    token: str,
    game_id: int,
    devcode: str,
    distinct_id: str,
    source: str = "ios",
    version: str = "2.2.0",
) -> Optional[str]:
    """获取绑定游戏账号角色 ID（战双=2, 鸣潮=3）"""
    try:
        client = KuroHttpClient(token, devcode, distinct_id, source, version)
        response = client.user_info_post(
            API.USER_ROLE_LIST, data={"gameId": str(game_id)}, raise_on_error=False
        )
        if response.is_success() and response.data:
            roles = response.data
            if roles and len(roles) > 0:
                role_id = roles[0].get("roleId")
                logger.info("获取游戏%s角色ID成功: %s", game_id, role_id)
                return role_id
        logger.error("获取绑定游戏账号列表失败: %s", response.message)
        return None
    except Exception as e:
        logger.error("请求失败: %s", e)
        return None


def new_device_ids() -> tuple:
    """生成新的设备标识 (devcode, distinct_id)"""
    return str(uuid.uuid4()), str(uuid.uuid4())
