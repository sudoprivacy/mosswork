"""论坛签到与每日任务模块（移植自 Kuro-autosignin forum_sign_in.py）"""

import logging
import time
from typing import List, Optional

from .http_client import KuroHttpClient
from .constants import API, TaskType
from .models import SignInResult, ResponseStatus

logger = logging.getLogger("kuro")


class ForumSignIn:
    """论坛签到与每日任务（刷金币/积分）"""

    def __init__(self, client: KuroHttpClient):
        self.client = client

    def get_forum_list(self) -> Optional[List[dict]]:
        try:
            data = {
                "forumId": "9",
                "gameId": "3",
                "pageIndex": "1",
                "pageSize": "20",
                "searchType": "3",
                "timeType": "0",
            }
            response = self.client.bbs_post(API.FORUM_LIST, data, raise_on_error=False)
            if response.is_success() and response.data:
                posts = response.data.get("postList", [])
                logger.info("成功获取帖子列表，共 %d 篇", len(posts))
                return posts
            logger.error("获取帖子列表失败: %s", response.message)
            return None
        except Exception as e:
            logger.error("获取帖子列表失败: %s", e)
            return None

    def get_post_detail(self, post_id: str) -> bool:
        """浏览帖子"""
        try:
            data = {"isOnlyPublisher": "0", "postId": post_id, "showOrderTyper": "2"}
            response = self.client.bbs_post(
                API.FORUM_POST_DETAIL, data, raise_on_error=False
            )
            return response.is_success()
        except Exception as e:
            logger.error("浏览帖子失败，帖子ID: %s, 错误: %s", post_id, e)
            return False

    def like_post(self, post_id: str, user_id: str) -> bool:
        """点赞帖子"""
        try:
            data = {
                "forumId": 11,
                "gameId": 3,
                "likeType": 1,
                "operateType": 1,
                "postCommentId": "",
                "postCommentReplyId": "",
                "postId": post_id,
                "postType": 1,
                "toUserId": user_id,
            }
            response = self.client.bbs_post(API.FORUM_LIKE, data, raise_on_error=False)
            return response.is_success()
        except Exception as e:
            logger.error("点赞帖子失败，帖子ID: %s, 错误: %s", post_id, e)
            return False

    def share_post(self) -> bool:
        try:
            response = self.client.bbs_post(
                API.TASK_SHARE, {"gameId": 3}, raise_on_error=False
            )
            return response.is_success()
        except Exception as e:
            logger.error("分享帖子失败: %s", e)
            return False

    def forum_sign_in(self) -> bool:
        """论坛签到"""
        try:
            response = self.client.bbs_post(
                API.USER_SIGN_IN, {"gameId": "2"}, raise_on_error=False
            )
            if response.is_success():
                logger.info("论坛签到成功")
                return True
            logger.error("论坛签到失败: %s", response.message)
            return False
        except Exception as e:
            logger.error("论坛签到失败: %s", e)
            return False

    def get_task_list(self) -> Optional[List[dict]]:
        try:
            response = self.client.bbs_post(
                API.TASK_PROCESS, {"gameId": "0"}, raise_on_error=False
            )
            if response.is_success() and response.data:
                tasks = response.data.get("dailyTask", [])
                logger.info("成功获取任务列表，共 %d 个任务", len(tasks))
                return tasks
            logger.error("获取任务列表失败: %s", response.message)
            return None
        except Exception as e:
            logger.error("获取任务列表失败: %s", e)
            return None

    def get_total_gold(self) -> Optional[int]:
        try:
            response = self.client.bbs_post(API.GOLD_TOTAL, raise_on_error=False)
            if response.is_success() and response.data:
                return response.data.get("goldNum", 0)
            return None
        except Exception as e:
            logger.error("获取金币总数失败: %s", e)
            return None

    # ---- 各任务执行器 ----

    def do_task_sign_in(self) -> str:
        return "签到成功" if self.forum_sign_in() else "签到失败"

    def do_task_view_posts(self) -> str:
        posts = self.get_forum_list()
        if not posts:
            return "获取帖子列表失败"
        view_count = 0
        for post in posts[:3]:
            if self.get_post_detail(post["postId"]):
                view_count += 1
            time.sleep(1)  # 限流保护
        return f"已浏览 {view_count}/3 篇帖子"

    def do_task_like_posts(self) -> str:
        posts = self.get_forum_list()
        if not posts:
            return "获取帖子列表失败"
        like_count = 0
        for i, post in enumerate(posts[:5], 1):
            if self.like_post(post["postId"], post["userId"]):
                like_count += 1
                logger.info("第 %d 次点赞成功", i)
            time.sleep(1)  # 限流保护
        return f"已点赞 {like_count}/5 次"

    def do_task_share_post(self) -> str:
        return "分享成功" if self.share_post() else "分享失败"

    def execute_tasks(self) -> SignInResult:
        """执行全部未完成的论坛每日任务并汇总积分"""
        try:
            logger.info("开始执行论坛每日任务")
            messages = []

            tasks = self.get_task_list()
            if not tasks:
                return SignInResult(ResponseStatus.FAILED, "获取任务列表失败")

            for task in tasks:
                if int(task.get("process", 0)) == 1:
                    continue  # 已完成任务跳过

                remark = task.get("remark", "")
                logger.info("开始处理任务: %s", remark)

                task_result = ""
                if remark == TaskType.SIGN_IN.value:
                    task_result = self.do_task_sign_in()
                elif remark == TaskType.VIEW_POSTS.value:
                    task_result = self.do_task_view_posts()
                elif remark == TaskType.LIKE_POSTS.value:
                    task_result = self.do_task_like_posts()
                elif remark == TaskType.SHARE_POST.value:
                    task_result = self.do_task_share_post()

                if task_result:
                    messages.append(f"{remark}: {task_result}")
                time.sleep(1)  # 限流保护

            tasks = self.get_task_list()
            if tasks:
                gain_gold = sum(
                    task.get("gainGold", 0)
                    for task in tasks
                    if task.get("process") == 1
                )
                total_gold = self.get_total_gold()
                summary = f"今日任务已完成，总计获取金币: {gain_gold}"
                if total_gold is not None:
                    summary += f"；现在剩余：{total_gold} 金币"
                messages.append(summary)
                logger.info(summary)

            return SignInResult(ResponseStatus.SUCCESS, "\n".join(messages))

        except Exception as e:
            message = f"论坛签到流程失败: {e}"
            logger.error(message)
            return SignInResult(ResponseStatus.FAILED, message)
