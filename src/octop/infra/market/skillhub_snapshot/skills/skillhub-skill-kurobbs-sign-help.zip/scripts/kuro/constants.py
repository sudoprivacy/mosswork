"""常量和枚举定义（移植自 Kuro-autosignin constants.py）"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict


class GameType(Enum):
    """游戏类型枚举"""

    PGR = "2"  # 战双帕弥什
    WUWA = "3"  # 鸣潮

    @property
    def name_zh(self) -> str:
        return {GameType.PGR: "战双", GameType.WUWA: "鸣潮"}[self]

    @property
    def server_id(self) -> str:
        return {
            GameType.PGR: "1000",
            GameType.WUWA: "76402e5b20be2c39f095a152090afddc",
        }[self]


class TaskType(Enum):
    """论坛每日任务类型"""

    SIGN_IN = "用户签到"
    VIEW_POSTS = "浏览3篇帖子"
    LIKE_POSTS = "点赞5次"
    SHARE_POST = "分享1次帖子"


class ErrorCode(Enum):
    """库街区 API 错误代码"""

    SUCCESS = 200
    ALREADY_SIGNED = 1511  # 今天已签到
    USER_INFO_ERROR = 1513  # 用户信息异常
    LOGIN_EXPIRED = 220  # 登录过期


@dataclass
class ApiEndpoint:
    """API 端点配置"""

    # 用户相关
    USER_MINE: str = "https://api.kurobbs.com/user/mineV2"
    USER_SIGN_IN: str = "https://api.kurobbs.com/user/signIn"
    USER_ROLE_LIST: str = "https://api.kurobbs.com/user/role/findRoleList"

    # 论坛相关
    FORUM_LIST: str = "https://api.kurobbs.com/forum/list"
    FORUM_POST_DETAIL: str = "https://api.kurobbs.com/forum/getPostDetail"
    FORUM_LIKE: str = "https://api.kurobbs.com/forum/like"

    # 任务相关
    TASK_PROCESS: str = "https://api.kurobbs.com/encourage/level/getTaskProcess"
    TASK_SHARE: str = "https://api.kurobbs.com/encourage/level/shareTask"

    # 金币相关
    GOLD_TOTAL: str = "https://api.kurobbs.com/encourage/gold/getTotalGold"

    # 游戏签到相关
    GAME_SIGN_IN: str = "https://api.kurobbs.com/encourage/signIn/v2"
    GAME_SIGN_RECORD: str = "https://api.kurobbs.com/encourage/signIn/queryRecordV2"
    GAME_SIGN_INIT: str = "https://api.kurobbs.com/encourage/signIn/initSignInV2"
    GAME_REPLENISH_SIGN: str = "https://api.kurobbs.com/encourage/signIn/repleSigInV2"


API = ApiEndpoint()


COMMON_HEADERS: Dict[str, str] = {
    "Accept": "*/*",
    "Accept-Language": "zh-CN,zh-Hans;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
}

BBS_HEADERS_TEMPLATE: Dict[str, str] = {
    **COMMON_HEADERS,
    "Host": "api.kurobbs.com",
    "source": "ios",
    "lang": "zh-Hans",
    "User-Agent": "KuroGameBox/48 CFNetwork/1492.0.1 Darwin/23.3.0",
    "channelId": "1",
    "channel": "appstore",
    "version": "2.2.0",
    "model": "iPhone15,2",
    "osVersion": "17.3",
    "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
}

GAME_HEADERS_TEMPLATE: Dict[str, str] = {
    **COMMON_HEADERS,
    "Host": "api.kurobbs.com",
    "Accept": "application/json, text/plain, */*",
    "Sec-Fetch-Site": "same-site",
    "source": "ios",
    "Sec-Fetch-Mode": "cors",
    "Origin": "https://web-static.kurobbs.com",
    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) KuroGameBox/2.2.0",
}

USER_INFO_HEADERS_TEMPLATE: Dict[str, str] = {
    "osversion": "Android",
    "countrycode": "CN",
    "ip": "10.0.2.233",
    "model": "2211133C",
    "source": "android",
    "lang": "zh-Hans",
    "version": "1.0.9",
    "versioncode": "1090",
    "content-type": "application/x-www-form-urlencoded",
    "accept-encoding": "gzip",
    "user-agent": "okhttp/3.10.0",
}

# h5（网页端）请求头：网页登录的 token 必须配合 source=h5 使用
H5_HEADERS_TEMPLATE: Dict[str, str] = {
    "Accept": "application/json, text/plain, */*",
    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
    "source": "h5",
    "version": "3.3.2",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36",
    "Origin": "https://www.kurobbs.com",
    "Referer": "https://www.kurobbs.com/",
    "Accept-Language": "zh-CN,zh-Hans;q=0.9",
}
