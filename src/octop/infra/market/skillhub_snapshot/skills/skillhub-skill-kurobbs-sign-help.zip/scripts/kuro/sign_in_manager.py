"""签到管理器/编排器（移植自 Kuro-autosignin sign_in_manager.py）"""

import datetime
import time
from typing import List, Tuple

from .config_manager import ConfigManager
from .models import ResponseStatus, TaskSummary, TokenExpiredException, UserInfoException
from .http_client import KuroHttpClient
from .game_sign_in import GameSignIn
from .forum_sign_in import ForumSignIn
from .constants import GameType
from .tools import random_delay

import logging

logger = logging.getLogger("kuro")


class SignInManager:
    """签到管理器：单用户签到（重试/异常分流）+ 全量执行"""

    def __init__(self, config_manager: ConfigManager):
        self.config_manager = config_manager

    def sign_in_user(self, user_name: str) -> Tuple[ResponseStatus, List[str]]:
        """执行单个用户签到，失败随机延迟后重试"""
        config = self.config_manager.load_user_config(user_name)
        if not config:
            msg = f"{user_name} 配置加载失败，跳过签到"
            return ResponseStatus.FAILED, [msg]

        max_retries = config.get_max_retries()
        retry_count = 0

        while retry_count <= max_retries:
            messages = []
            if retry_count == 0:
                messages.append(f"{user_name} 签到开始")
            else:
                messages.append(f"{user_name} 签到重试 (第 {retry_count}/{max_retries} 次)")

            if not config.enable:
                msg = f"{user_name} 已禁用，跳过签到"
                logger.info(msg)
                return ResponseStatus.SKIPPED, [msg]

            if not config.token:
                msg = f"{user_name} 的 token 为空，跳过签到"
                logger.error(msg)
                self.config_manager.disable_user(user_name)
                return ResponseStatus.FAILED, messages + [msg]

            # 配置不完整时自动填充 userId / roleId
            if not config.completed:
                logger.info("%s 配置文件不完整，开始执行填充流程", user_name)
                if not self.config_manager.fill_config(user_name, config.token):
                    msg = f"{user_name} 配置填充失败，跳过签到"
                    return ResponseStatus.FAILED, messages + [msg]
                config = self.config_manager.load_user_config(user_name)

            try:
                client = KuroHttpClient(
                    token=config.token,
                    devcode=config.get_devcode(),
                    distinct_id=config.get_distinct_id(),
                    source=config.source,
                    version=config.version,
                )

                # 游戏签到（鸣潮 + 战双）
                game_signer = GameSignIn(client)
                current_month = datetime.datetime.now().strftime("%m")

                wuwa_role_id = config.get_game_role_id("3")
                if wuwa_role_id:
                    result = game_signer.sign_in(
                        game_type=GameType.WUWA,
                        role_id=wuwa_role_id,
                        user_id=config.get_user_id(),
                        month=current_month,
                        auto_replenish=config.auto_replenish_sign,
                    )
                    messages.append(result.message)

                pgr_role_id = config.get_game_role_id("2")
                if pgr_role_id:
                    result = game_signer.sign_in(
                        game_type=GameType.PGR,
                        role_id=pgr_role_id,
                        user_id=config.get_user_id(),
                        month=current_month,
                        auto_replenish=config.auto_replenish_sign,
                    )
                    messages.append(result.message)

                # 论坛签到与每日任务
                forum_signer = ForumSignIn(client)
                result = forum_signer.execute_tasks()
                messages.append(result.message)

                messages.append(f"{user_name} 签到结束")
                logger.info("%s 签到完成", user_name)
                return ResponseStatus.SUCCESS, messages

            except TokenExpiredException:
                # 登录失效：自动禁用，等用户更新 token
                msg = f"{user_name} 登录已过期，自动禁用该用户（请更新 token 后将 enable 改回 true）"
                logger.error(msg)
                self.config_manager.disable_user(user_name)
                return ResponseStatus.FAILED, messages + [msg]

            except UserInfoException:
                msg = f"{user_name} 用户信息异常，自动禁用该用户"
                logger.error(msg)
                self.config_manager.disable_user(user_name)
                return ResponseStatus.FAILED, messages + [msg]

            except Exception as e:
                # 网络/未知错误：随机延迟后重试
                msg = f"{user_name} 签到失败: {e}"
                logger.error(msg)
                messages.append(msg)
                retry_count += 1
                if retry_count <= max_retries:
                    logger.info("%s 将在随机延迟后进行第 %d/%d 次重试", user_name, retry_count, max_retries)
                    random_delay()
                    continue
                final_msg = f"{user_name} 重试 {max_retries} 次后仍然失败，放弃签到"
                logger.error(final_msg)
                return ResponseStatus.FAILED, messages + [final_msg]

    def run_all(self) -> Tuple[TaskSummary, List[str]]:
        """执行所有用户的签到"""
        all_messages = []
        success_users, failed_users, disabled_users = [], [], []

        current_date = datetime.datetime.now().strftime("%Y-%m-%d")
        start_msg = f"{current_date} 开始签到任务"
        all_messages.append(start_msg)
        logger.info(start_msg)

        for user_name in self.config_manager.list_all_configs():
            time.sleep(1)  # 用户间限流保护
            status, messages = self.sign_in_user(user_name)
            all_messages.extend(messages)

            if status == ResponseStatus.SKIPPED:
                continue
            elif status == ResponseStatus.FAILED:
                config = self.config_manager.load_user_config(user_name)
                if config and not config.enable:
                    disabled_users.append(user_name)
                else:
                    failed_users.append(user_name)
            else:
                success_users.append(user_name)

        summary = TaskSummary(
            date=current_date,
            success_users=success_users,
            failed_users=failed_users,
            disabled_users=disabled_users,
        )
        summary_msg = str(summary)
        logger.info(summary_msg)
        all_messages.append(summary_msg)

        return summary, all_messages
