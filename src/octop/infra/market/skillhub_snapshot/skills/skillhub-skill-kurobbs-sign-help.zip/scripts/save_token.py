"""保存并验证 token 到用户配置

流程：调用 user/mineV2 验证 token 有效性（无效则拒绝保存）→ 生成 devcode/distinct_id
→ 写入 <用户名>.yaml（completed=false，userId/roleId 由签到流程自动填充）。

用法：
    python save_token.py --user 名字 --token TOKEN
    echo TOKEN | python save_token.py --user 名字        # 从 stdin 读取
    python save_token.py --user 名字 --candidates K1=V1 K2=V2   # 多候选逐一验证
"""

import argparse
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from kuro.http_client import KuroHttpClient
from kuro.constants import API
from kuro.tools import new_device_ids
from kuro.config_manager import ConfigManager, default_config_dir

import yaml


def validate_token(
    token: str, devcode: str, distinct_id: str, source: str = "ios", version: str = "2.2.0"
) -> tuple:
    """验证 token，返回 (是否有效, userId 或错误信息)"""
    try:
        client = KuroHttpClient(token, devcode, distinct_id, source, version)
        response = client.user_info_post(API.USER_MINE, raise_on_error=False)
        if response.is_success() and response.data:
            user_id = response.data.get("mine", {}).get("userId")
            if user_id:
                return True, str(user_id)
        return False, f"API 返回异常: code={response.code} msg={response.message}"
    except Exception as e:
        return False, f"验证请求失败: {e}"


def save_user_token(
    user_name: str,
    token: str,
    config_dir: str,
    devcode: str = None,
    distinct_id: str = None,
    source: str = "ios",
    version: str = "2.2.0",
) -> bool:
    """验证并保存 token 到 <user_name>.yaml；devcode/distinct_id 缺省时新生成。

    网页端 token 必须传 source=h5 version=3.3.2 及登录时的 devcode/distinct_id。
    """
    if not devcode or not distinct_id:
        devcode, distinct_id = new_device_ids()
    ok, info = validate_token(token, devcode, distinct_id, source, version)
    if not ok:
        print(f"[FAIL] token 无效，未保存。原因: {info}")
        return False

    config_manager = ConfigManager(config_dir)
    config_path = config_manager.get_config_path(user_name)

    # 保留已有配置中的非凭证字段（如 enable / auto_reple_sign / retry_times）
    existing = {}
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8-sig") as f:
                existing = yaml.safe_load(f) or {}
        except Exception:
            existing = {}

    existing.update(
        {
            "token": token,
            "enable": existing.get("enable", True),
            "completed": False,  # 下次签到时自动填充 roleId
            "source": source,
            "version": version,
            "game_info": {
                "devcode": devcode,
                "distinct_id": distinct_id,
            },
            "user_info": {"userId": info},
        }
    )
    with open(config_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(existing, f, allow_unicode=True, default_flow_style=False)

    print(f"[OK] 用户 {user_name} 的 token 已验证并保存到: {config_path}")
    print(f"     userId: {info}")
    return True


def main():
    parser = argparse.ArgumentParser(description="验证并保存库街区 token")
    parser.add_argument("--user", required=True, help="用户名（配置文件名）")
    parser.add_argument("--token", help="token 值；不提供则从 stdin 读取")
    parser.add_argument("--candidates", nargs="*", help="多候选格式 K=V，逐一验证取第一个有效值")
    parser.add_argument("--source", default="ios", help="凭证来源端：ios/android/h5（网页 token 用 h5）")
    parser.add_argument("--version", default="2.2.0", help="配套版本号（h5 为 3.3.2）")
    parser.add_argument("--devcode", help="登录时的 devCode（网页 token 必传）")
    parser.add_argument("--distinct-id", help="登录时的 distinct_id（网页 token 必传）")
    parser.add_argument("--config-dir", help="配置目录（默认 ~/.workbuddy/kuro-bbs-autosign/config）")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    if args.candidates:
        # 多候选场景（如浏览器 localStorage 扫描出多个疑似 token）
        for item in args.candidates:
            if "=" not in item:
                continue
            key, value = item.split("=", 1)
            print(f"尝试候选: {key} (长度 {len(value)})")
            if save_user_token(
                args.user, value, args.config_dir or default_config_dir(),
                devcode=args.devcode, distinct_id=args.distinct_id,
                source=args.source, version=args.version,
            ):
                print(f"[OK] 有效 token 来自 localStorage 键: {key}")
                return 0
        print("[FAIL] 所有候选均无效")
        return 1

    token = args.token or (sys.stdin.read().strip() if not sys.stdin.isatty() else "")
    if not token:
        print("[FAIL] 未提供 token")
        return 1

    return 0 if save_user_token(
        args.user, token, args.config_dir or default_config_dir(),
        devcode=args.devcode, distinct_id=args.distinct_id,
        source=args.source, version=args.version,
    ) else 1


if __name__ == "__main__":
    sys.exit(main())
