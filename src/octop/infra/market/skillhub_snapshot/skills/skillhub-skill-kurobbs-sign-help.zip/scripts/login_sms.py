"""短信验证码直登（移植自 Kuro-autosignin login.py）

调用 api.kurobbs.com/user/sdkLogin（Android okhttp 头），用手机号+短信验证码
换取 token 并保存到用户配置。适合无法使用浏览器时的兜底方案。

短信验证码获取方式：浏览器打开 https://www.kurobbs.com/mc/home/9 请求验证码，
或库街区 App 登录页触发。

用法：
    python login_sms.py --user 名字 --mobile 138xxxxxxxx
    # 提示后输入收到的验证码
"""

import argparse
import logging
import os
import sys

import requests

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from kuro.tools import new_device_ids
from save_token import save_user_token
from kuro.config_manager import default_config_dir

SDK_LOGIN_URL = "https://api.kurobbs.com/user/sdkLogin"

HEADERS = {
    "osversion": "Android",
    "countrycode": "CN",
    "ip": "192.168.1.101",
    "model": "2211133C",
    "source": "android",
    "lang": "zh-Hans",
    "version": "1.0.9",
    "versioncode": "1090",
    "content-type": "application/x-www-form-urlencoded",
    "accept-encoding": "gzip",
    "user-agent": "okhttp/3.10.0",
}


def sdk_login(devcode: str, distinct_id: str, mobile: str, code: str) -> str:
    """调用 sdkLogin，成功返回 token，失败抛异常"""
    headers = dict(HEADERS)
    headers.update({"devcode": devcode, "distinct_id": distinct_id})

    data = {
        "code": code,
        "devCode": devcode,
        "gameList": "",
        "mobile": mobile,
    }
    response = requests.post(SDK_LOGIN_URL, headers=headers, data=data, timeout=30)
    response.raise_for_status()
    rsp = response.json()

    if rsp.get("code") != 200:
        raise RuntimeError(f"登录失败: {rsp}")

    data_part = rsp.get("data") or {}
    token = data_part.get("token") or (data_part.get("userInfo") or {}).get("token")
    if not token:
        raise RuntimeError(f"响应中未找到 token，data 字段: {data_part}")
    return token


def main():
    parser = argparse.ArgumentParser(description="库街区短信验证码直登")
    parser.add_argument("--user", required=True, help="用户名（配置文件名）")
    parser.add_argument("--mobile", required=True, help="手机号")
    parser.add_argument("--code", help="短信验证码；不提供则交互式输入")
    parser.add_argument("--config-dir", help="配置目录")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    devcode, distinct_id = new_device_ids()
    code = args.code or input("请输入收到的短信验证码：").strip()

    token = sdk_login(devcode, distinct_id, args.mobile, code)
    print(f"[OK] sdkLogin 成功，token 已获取（长度 {len(token)}）")

    ok = save_user_token(
        args.user, token, args.config_dir or default_config_dir(),
        devcode=devcode, distinct_id=distinct_id,
    )
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
