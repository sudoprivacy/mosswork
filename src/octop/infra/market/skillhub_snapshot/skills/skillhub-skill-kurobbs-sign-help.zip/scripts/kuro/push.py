"""多渠道结果通知（精简移植自 Kuro-autosignin push.py）

支持渠道：ftqq(Server酱) / pushplus / bark / dingrobot / feishubot /
telegram / wintoast / webhook。由 push.ini 的 [setting] push_server 决定启用哪些，
支持逗号分隔多渠道。
"""

import configparser
import os
from typing import Optional

import requests

import logging

logger = logging.getLogger("kuro")

http = requests.Session()


def _load_ini(config_dir: str) -> Optional[configparser.ConfigParser]:
    ini_path = os.path.join(config_dir, "push.ini")
    if not os.path.exists(ini_path):
        logger.info("推送配置不存在: %s，跳过推送", ini_path)
        return None
    cfg = configparser.ConfigParser()
    cfg.read(ini_path, encoding="utf-8-sig")
    return cfg


def ftqq(title, message, cfg):
    http.post(
        url=f"https://sctapi.ftqq.com/{cfg.get('setting', 'push_token')}.send",
        data={"title": title, "desp": message},
    )
    logger.info("Server酱 推送成功")


def pushplus(title, message, cfg):
    http.post(
        url="https://www.pushplus.plus/send",
        data={
            "token": cfg.get("setting", "push_token"),
            "title": title,
            "content": message,
        },
    )
    logger.info("Pushplus 推送成功")


def bark(title, message, cfg):
    import urllib.parse

    t = urllib.parse.quote_plus(title)
    m = urllib.parse.quote_plus(message)
    http.get(url=f"{cfg.get('bark', 'api_url')}/{cfg.get('bark', 'token')}/{t}/{m}")
    logger.info("Bark 推送成功")


def dingrobot(title, message, cfg):
    http.post(
        url=cfg.get("dingrobot", "webhook"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        json={"msgtype": "text", "text": {"content": f"{title}\r\n{message}"}},
    )
    logger.info("钉钉机器人推送完成")


def feishubot(title, message, cfg):
    http.post(
        url=cfg.get("feishubot", "webhook"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        json={"msg_type": "text", "content": {"text": f"{title}\r\n{message}"}},
    )
    logger.info("飞书机器人推送完成")


def telegram(title, message, cfg):
    http.post(
        url="https://{}/bot{}/sendMessage".format(
            cfg.get("telegram", "api_url"), cfg.get("telegram", "bot_token")
        ),
        data={
            "chat_id": cfg.get("telegram", "chat_id"),
            "text": f"{title}\r\n{message}",
        },
    )
    logger.info("Telegram 推送成功")


def wintoast(title, message, cfg):
    try:
        from win11toast import toast

        toast(app_id="kuro-bbs-autosign", title=title, body=message)
        logger.info("Windows Toast 推送成功")
    except ImportError:
        logger.error("Windows Toast 需要 pip install win11toast")


def webhook(title, message, cfg):
    http.post(
        url=cfg.get("webhook", "webhook_url"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        json={"title": title, "message": message},
    )
    logger.info("Webhook 推送完成")


def push(config_dir: str, message: str, title: str = "库街区签到") -> bool:
    """按 push.ini 配置推送结果。push_level: 1=仅最后总结 2=全部消息 3=逐条"""
    cfg = _load_ini(config_dir)
    if cfg is None or not cfg.getboolean("setting", "enable", fallback=False):
        logger.info("推送未启用")
        return False

    push_level = cfg.getint("setting", "push_level", fallback=1)
    func_names = cfg.get("setting", "push_server", fallback="").lower()

    payloads = {
        1: [message.splitlines()[-1] if message else message],
        2: [message],
    }.get(push_level, message.splitlines() if push_level == 3 else [message])

    for func_name in [n.strip() for n in func_names.split(",") if n.strip()]:
        func = globals().get(func_name)
        if not func:
            logger.error("未知推送服务: %s，请检查 push.ini [setting] push_server", func_name)
            continue
        for payload in payloads:
            try:
                func(title, payload, cfg)
            except Exception as e:
                logger.error("%s 推送失败: %s", func_name, e)
    return True
