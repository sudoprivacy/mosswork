"""配置管理模块（移植自 Kuro-autosignin config_manager.py）"""

import logging
import os
from typing import List, Optional

import yaml

from .models import UserConfig
from .tools import get_user_info_by_token, get_game_user_id, new_device_ids

logger = logging.getLogger("kuro")


def default_config_dir() -> str:
    """默认配置目录：环境变量 > ~/.workbuddy/kuro-bbs-autosign/config"""
    env_dir = os.environ.get("KURO_BBS_CONFIG_PATH")
    if env_dir:
        return env_dir
    return os.path.join(
        os.path.expanduser("~"), ".workbuddy", "kuro-bbs-autosign", "config"
    )


class ConfigManager:
    """按用户的 YAML 配置管理器"""

    def __init__(self, config_dir: Optional[str] = None):
        self.config_dir = config_dir or default_config_dir()
        os.makedirs(self.config_dir, exist_ok=True)
        logger.info("配置目录: %s", self.config_dir)

    def get_config_path(self, user_name: str) -> str:
        return os.path.join(self.config_dir, f"{user_name}.yaml")

    def load_user_config(self, user_name: str) -> Optional[UserConfig]:
        config_path = self.get_config_path(user_name)
        if not os.path.exists(config_path):
            logger.error("配置文件不存在: %s", config_path)
            return None
        try:
            with open(config_path, "r", encoding="utf-8-sig") as f:
                data = yaml.safe_load(f)
            if not data:
                logger.error("配置文件为空: %s", config_path)
                return None
            if "retry_times" not in data:
                data["retry_times"] = 3
                with open(config_path, "w", encoding="utf-8") as f:
                    yaml.safe_dump(data, f, allow_unicode=True, default_flow_style=False)
            return UserConfig.from_dict(user_name, data)
        except Exception as e:
            logger.error("加载配置文件失败: %s", e)
            return None

    def save_user_config(self, config: UserConfig) -> bool:
        config_path = self.get_config_path(config.name)
        try:
            data = {
                "token": config.token,
                "enable": config.enable,
                "completed": config.completed,
                "auto_reple_sign": config.auto_replenish_sign,
                "source": config.source,
                "version": config.version,
                "retry_times": config.retry_times,
                "game_info": config.game_info,
                "user_info": config.user_info,
            }
            with open(config_path, "w", encoding="utf-8") as f:
                yaml.safe_dump(data, f, allow_unicode=True, default_flow_style=False)
            return True
        except Exception as e:
            logger.error("保存配置文件失败: %s", e)
            return False

    def disable_user(self, user_name: str) -> bool:
        """Token 失效等场景下自动禁用用户"""
        config = self.load_user_config(user_name)
        if not config:
            return False
        config.enable = False
        result = self.save_user_config(config)
        if result:
            logger.info("已禁用用户: %s", user_name)
        return result

    def enable_user(self, user_name: str) -> bool:
        config = self.load_user_config(user_name)
        if not config:
            return False
        config.enable = True
        result = self.save_user_config(config)
        if result:
            logger.info("已启用用户: %s", user_name)
        return result

    def fill_config(
        self,
        user_name: str,
        token: str,
        devcode: Optional[str] = None,
        distinct_id: Optional[str] = None,
    ) -> bool:
        """自动填充配置：生成设备标识、拉取 userId 与游戏 roleId"""
        config = self.load_user_config(user_name)
        if not config:
            return False
        try:
            # 设备标识与 token 绑定：已存在则保留（尤其是网页 h5 token），缺失才生成
            devcode = config.game_info.get("devcode") or devcode
            distinct_id = config.game_info.get("distinct_id") or distinct_id
            if not devcode or not distinct_id:
                devcode, distinct_id = new_device_ids()
            config.game_info["devcode"] = devcode
            config.game_info["distinct_id"] = distinct_id

            user_id = get_user_info_by_token(
                token, devcode, distinct_id, config.source, config.version
            )
            if user_id:
                config.user_info["userId"] = user_id
            else:
                logger.error("获取用户ID失败: %s", user_name)
                return False

            wuwa_role_id = get_game_user_id(
                token, 3, devcode, distinct_id, config.source, config.version
            )  # 鸣潮
            pgr_role_id = get_game_user_id(
                token, 2, devcode, distinct_id, config.source, config.version
            )  # 战双
            if wuwa_role_id:
                config.game_info["wwroleId"] = wuwa_role_id
            if pgr_role_id:
                config.game_info["eeeroleId"] = pgr_role_id

            config.completed = True
            if self.save_user_config(config):
                logger.info("%s 的配置文件已成功填充", user_name)
                return True
            return False
        except Exception as e:
            logger.error("填充配置文件失败: %s", e)
            return False

    def list_all_configs(self) -> List[str]:
        try:
            files = os.listdir(self.config_dir)
            user_names = [
                os.path.splitext(f)[0] for f in files if f.endswith(".yaml")
            ]
            logger.debug("找到 %d 个配置文件", len(user_names))
            return user_names
        except Exception as e:
            logger.error("列出配置文件失败: %s", e)
            return []
