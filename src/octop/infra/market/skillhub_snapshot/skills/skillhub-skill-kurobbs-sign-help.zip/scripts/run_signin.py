"""库街区自动签到入口

用法：
    python run_signin.py                     # 全部用户签到 + 推送
    python run_signin.py --user <name>       # 只签指定用户
    python run_signin.py --config-dir <dir>  # 指定配置目录
    python run_signin.py --debug             # 调试日志
    python run_signin.py --no-push           # 跳过推送
"""

import argparse
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from kuro.config_manager import ConfigManager, default_config_dir
from kuro.sign_in_manager import SignInManager
from kuro import push as push_module


def parse_args():
    parser = argparse.ArgumentParser(description="库街区（鸣潮）自动签到")
    parser.add_argument("--user", help="只执行指定用户的签到（默认全部）")
    parser.add_argument("--config-dir", help="配置目录（默认 ~/.workbuddy/kuro-bbs-autosign/config）")
    parser.add_argument("--debug", action="store_true", help="启用 DEBUG 日志")
    parser.add_argument("--no-push", action="store_true", help="跳过结果推送")
    return parser.parse_args()


def main():
    args = parse_args()
    logging.basicConfig(
        level=logging.DEBUG if args.debug else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    logger = logging.getLogger("kuro")

    logger.info("=" * 50)
    logger.info("库街区自动签到程序启动")
    logger.info("=" * 50)

    config_dir = args.config_dir or default_config_dir()
    config_manager = ConfigManager(config_dir)
    manager = SignInManager(config_manager)

    if args.user:
        status, messages = manager.sign_in_user(args.user)
        summary_text = "\n".join(messages)
    else:
        _, messages = manager.run_all()
        summary_text = "\n".join(messages)

    # 输出结果摘要
    print("\n" + "=" * 50)
    print(summary_text)
    print("=" * 50)

    # 推送通知
    if not args.no_push:
        try:
            push_module.push(config_dir, summary_text)
        except Exception as e:
            logger.error("推送通知失败: %s", e)

    logger.info("签到任务执行完成")
    return 0


if __name__ == "__main__":
    sys.exit(main())
