"""HTTP 客户端封装（移植自 Kuro-autosignin http_client.py）"""

import logging
import socket
from typing import Dict, Optional, Any

import requests

from .constants import (
    BBS_HEADERS_TEMPLATE,
    GAME_HEADERS_TEMPLATE,
    USER_INFO_HEADERS_TEMPLATE,
    H5_HEADERS_TEMPLATE,
)
from .models import ApiResponse, NetworkException

logger = logging.getLogger("kuro")


def get_ip_address() -> str:
    """获取本机出口 IP（UDP 探测，不真正发包到外网业务）"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip_address = s.getsockname()[0]
    except OSError:
        ip_address = "127.0.0.1"
    finally:
        s.close()
    return ip_address


class HttpClient:
    """HTTP 客户端基类"""

    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.session = requests.Session()

    def _request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        data: Optional[Dict[str, Any]] = None,
        raise_on_error: bool = True,
    ) -> ApiResponse:
        try:
            logger.debug("请求 %s %s data=%s", method, url, data)
            response = self.session.request(
                method=method, url=url, headers=headers, data=data, timeout=self.timeout
            )
            response.raise_for_status()
            logger.debug("响应: %s", response.text[:2000])

            result = ApiResponse.from_dict(response.json())
            if not result.is_success() and raise_on_error:
                logger.error("请求失败: %s", result.message)
            return result

        except requests.RequestException as e:
            error_msg = f"网络请求失败: {e}"
            logger.error(error_msg)
            if raise_on_error:
                raise NetworkException(error_msg)
            return ApiResponse(success=False, code=-1, message=error_msg)
        except ValueError as e:
            error_msg = f"响应解析失败: {e}"
            logger.error(error_msg)
            if raise_on_error:
                raise NetworkException(error_msg)
            return ApiResponse(success=False, code=-1, message=error_msg)

    def post(
        self,
        url: str,
        headers: Dict[str, str],
        data: Optional[Dict[str, Any]] = None,
        raise_on_error: bool = True,
    ) -> ApiResponse:
        return self._request("POST", url, headers, data, raise_on_error)

    def get(
        self, url: str, headers: Dict[str, str], raise_on_error: bool = True
    ) -> ApiResponse:
        return self._request("GET", url, headers, raise_on_error=raise_on_error)


class KuroHttpClient(HttpClient):
    """库街区 HTTP 客户端"""

    def __init__(
        self,
        token: str,
        devcode: Optional[str] = None,
        distinct_id: Optional[str] = None,
        source: str = "ios",
        version: str = "2.2.0",
    ):
        super().__init__()
        self.token = token
        self.devcode = devcode or ""
        self.distinct_id = distinct_id or ""
        self.source = source
        self.version = version
        self.ip = get_ip_address()

    def _base_h5_headers(self) -> Dict[str, str]:
        headers = H5_HEADERS_TEMPLATE.copy()
        headers.update(
            {
                "token": self.token,
                "devCode": self.devcode,
                "devcode": self.devcode,
                "distinct_id": self.distinct_id,
            }
        )
        return headers

    def get_bbs_headers(self) -> Dict[str, str]:
        if self.source == "h5":
            return self._base_h5_headers()
        headers = BBS_HEADERS_TEMPLATE.copy()
        headers.update(
            {
                "Cookie": f"user_token={self.token}",
                "Ip": self.ip,
                "distinct_id": self.distinct_id,
                "devCode": self.devcode,
                "token": self.token,
                "source": self.source,
                "version": self.version,
            }
        )
        return headers

    def get_game_headers(self) -> Dict[str, str]:
        if self.source == "h5":
            return self._base_h5_headers()
        headers = GAME_HEADERS_TEMPLATE.copy()
        headers.update(
            {
                "devCode": f"{self.ip}, Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) KuroGameBox/{self.version}",
                "token": self.token,
                "source": self.source,
                "version": self.version,
            }
        )
        return headers

    def get_user_info_headers(self) -> Dict[str, str]:
        if self.source == "h5":
            return self._base_h5_headers()
        headers = USER_INFO_HEADERS_TEMPLATE.copy()
        headers.update(
            {
                "devcode": self.devcode,
                "distinct_id": self.distinct_id,
                "token": self.token,
                "source": self.source,
                "version": self.version,
            }
        )
        return headers

    def bbs_post(self, url, data=None, raise_on_error=True) -> ApiResponse:
        return self.post(url, self.get_bbs_headers(), data, raise_on_error)

    def game_post(self, url, data=None, raise_on_error=True) -> ApiResponse:
        return self.post(url, self.get_game_headers(), data, raise_on_error)

    def user_info_post(self, url, data=None, raise_on_error=True) -> ApiResponse:
        return self.post(url, self.get_user_info_headers(), data, raise_on_error)
