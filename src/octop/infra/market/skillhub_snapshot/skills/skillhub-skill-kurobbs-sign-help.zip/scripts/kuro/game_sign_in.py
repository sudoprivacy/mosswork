"""游戏签到模块（移植自 Kuro-autosignin game_sign_in.py）"""

import logging
from typing import Optional

from .http_client import KuroHttpClient
from .constants import API, GameType, ErrorCode
from .models import (
    SignInResult,
    ResponseStatus,
    TokenExpiredException,
    UserInfoException,
)

logger = logging.getLogger("kuro")


class GameSignIn:
    """游戏签到类（鸣潮 / 战双）"""

    def __init__(self, client: KuroHttpClient):
        self.client = client

    def get_sign_reward(
        self, game_type: GameType, role_id: str, user_id: str
    ) -> Optional[str]:
        """查询当日签到奖励名称"""
        try:
            data = {
                "gameId": game_type.value,
                "serverId": game_type.server_id,
                "roleId": role_id,
                "userId": user_id,
            }
            response = self.client.game_post(
                API.GAME_SIGN_RECORD, data, raise_on_error=False
            )
            if response.is_success() and response.data:
                if isinstance(response.data, list) and len(response.data) > 0:
                    return response.data[0].get("goodsName", "未知奖励")
            logger.error("获取签到奖励失败: %s", response.message)
            return None
        except Exception as e:
            logger.error("获取签到奖励失败: %s", e)
            return None

    def check_replenish_count(
        self, game_type: GameType, role_id: str, user_id: str
    ) -> int:
        """查询可补签次数"""
        try:
            data = {
                "gameId": game_type.value,
                "serverId": game_type.server_id,
                "roleId": role_id,
                "userId": user_id,
            }
            response = self.client.game_post(
                API.GAME_SIGN_INIT, data, raise_on_error=False
            )
            if response.is_success() and response.data:
                omission_num = response.data.get("omissionNum", 0)
                logger.info("%s 可补签天数: %s", game_type.name_zh, omission_num)
                return omission_num
            return 0
        except Exception as e:
            logger.error("检查补签失败: %s", e)
            return 0

    def replenish_sign(
        self, game_type: GameType, role_id: str, user_id: str, month: str
    ) -> SignInResult:
        """执行补签"""
        try:
            data = {
                "gameId": game_type.value,
                "serverId": game_type.server_id,
                "roleId": role_id,
                "userId": user_id,
                "reqMonth": month,
            }
            logger.info("%s 开始补签", game_type.name_zh)
            response = self.client.game_post(
                API.GAME_REPLENISH_SIGN, data, raise_on_error=False
            )
            if response.code == ErrorCode.SUCCESS.value:
                reward = self.get_sign_reward(game_type, role_id, user_id)
                message = f"{game_type.name_zh} 补签成功"
                if reward:
                    message += f"，补签奖励: {reward}"
                logger.info(message)
                return SignInResult(ResponseStatus.SUCCESS, message, {"reward": reward})
            message = f"{game_type.name_zh} 补签失败: {response.message}"
            logger.error(message)
            return SignInResult(ResponseStatus.FAILED, message)
        except Exception as e:
            message = f"{game_type.name_zh} 补签失败: {e}"
            logger.error(message)
            return SignInResult(ResponseStatus.FAILED, message)

    def sign_in(
        self,
        game_type: GameType,
        role_id: str,
        user_id: str,
        month: str,
        auto_replenish: bool = False,
    ) -> SignInResult:
        """执行游戏签到（含已签到识别与自动补签）"""
        try:
            data = {
                "gameId": game_type.value,
                "serverId": game_type.server_id,
                "roleId": role_id,
                "userId": user_id,
                "reqMonth": month,
            }
            logger.info("%s 开始签到", game_type.name_zh)
            response = self.client.game_post(API.GAME_SIGN_IN, data, raise_on_error=False)

            if response.code == ErrorCode.SUCCESS.value:
                reward = self.get_sign_reward(game_type, role_id, user_id)
                message = f"{game_type.name_zh} 签到成功"
                if reward:
                    message += f"，签到奖励: {reward}"
                result = SignInResult(ResponseStatus.SUCCESS, message, {"reward": reward})

            elif response.code == ErrorCode.ALREADY_SIGNED.value:
                # 已签到：视为成功，跳过不重试
                reward = self.get_sign_reward(game_type, role_id, user_id)
                message = f"{game_type.name_zh} 今天已签到"
                if reward:
                    message += f"，签到奖励: {reward}"
                result = SignInResult(ResponseStatus.SUCCESS, message, {"reward": reward})

            elif response.code == ErrorCode.USER_INFO_ERROR.value:
                raise UserInfoException(f"{game_type.name_zh} 签到报错：用户信息异常")

            elif response.code == ErrorCode.LOGIN_EXPIRED.value:
                raise TokenExpiredException(f"{game_type.name_zh} 签到报错：登录已过期，请重新获取 token")

            else:
                message = f"{game_type.name_zh} 签到失败: {response.message} (代码: {response.code})"
                logger.error(message)
                return SignInResult(ResponseStatus.FAILED, message)

            if auto_replenish and result.status == ResponseStatus.SUCCESS:
                omission_count = self.check_replenish_count(game_type, role_id, user_id)
                if omission_count > 0:
                    replenish_result = self.replenish_sign(game_type, role_id, user_id, month)
                    result.message += f"\n{replenish_result.message}"

            return result

        except (TokenExpiredException, UserInfoException):
            raise
        except Exception as e:
            message = f"{game_type.name_zh} 签到失败: {e}"
            logger.error(message)
            return SignInResult(ResponseStatus.FAILED, message)
