"""kuro-bbs-autosign 核心包：库街区自动签到（移植自 Kuro-autosignin）"""
