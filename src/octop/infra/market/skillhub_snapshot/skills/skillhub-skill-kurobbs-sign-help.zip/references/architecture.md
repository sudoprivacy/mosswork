# kuro-bbs-autosign 架构与 API 参考

## 模块依赖关系

```
run_signin.py (入口)
  └── sign_in_manager.SignInManager   ← 编排层
        ├── config_manager.ConfigManager  ← 配置层（YAML 按用户管理）
        ├── tools (random_delay / fill 辅助)
        └── 每个用户:
              ├── http_client.KuroHttpClient  ← 网络层（token 注入三套请求头）
              ├── game_sign_in.GameSignIn     ← 业务层：游戏签到+补签
              └── forum_sign_in.ForumSignIn   ← 业务层：论坛任务+金币
  └── push.push                       ← 通知层（push.ini 驱动）
```

## 登录态模型

- **唯一凭证**：`user_token`，来自库街区 App 的请求 Cookie/头中的 `token` 字段。
- **设备标识**：`devcode` 与 `distinct_id`，首次运行时用 `uuid.uuid4()` 生成并写入 `game_info`，之后保持不变（保证设备一致性，降低风控概率）。
- **用户信息**：`userId`（`user/mineV2` 获取）与 `roleId`（`user/role/findRoleList` 按 gameId 获取），由 `ConfigManager.fill_config()` 自动回填，`completed: true` 表示已填充。

### Token 获取路径

**凭证体系实测结论（2026-09）**：
- 网页端登录（www.kurobbs.com）后：token 在 localStorage `auth` JSON 的 `token` 字段（JWT 格式）；`devCode` = localStorage `dc`；`distinct_id` = localStorage `distinct_id`。
- **该 token 必须配合请求头 `source: h5` + `version: 3.3.2` 使用**，且 devCode/distinct_id 必须用登录时的值——用 ios/android 头或新造 devCode 都会返回 code 220。
- 实测 h5 凭证可正常调用全部所需接口：user/mineV2、user/role/findRoleList、encourage/level/getTaskProcess、游戏签到、论坛任务。
- 网页登录有 GeeTest 滑块拼图验证码（geetest_btn 手柄 81x51，拼图 80x80，背景 300x200 显示为 302x201）；缺口定位用 slice/bg 图的梯度模板匹配，y 坐标可交叉验证（匹配 y + 150 ≈ slice 元素 top）。

1. **浏览器自动登录（默认，用 WorkBuddy 内置浏览器 agent-browser）**——完整流程见 SKILL.md「方式 A」：
   - 打开 `https://www.kurobbs.com/mc/home/9`（主站 main.html 可能白屏，/mc/ 移动端路径稳定）；
   - 点头像弹登录框 → 填手机号 → 勾协议 → 获取验证码（过滑块）→ 用户回填验证码登录；
   - 从 localStorage 一次性提取 `auth.token` / `dc` / `distinct_id`；
   - `save_token.py --source h5 --version 3.3.2 --devcode <dc> --distinct-id <id>` 验证并入库。
2. **短信直登（login_sms.py，移植自参考项目 login.py）**
   - 验证码触发页：`https://www.kurobbs.com/mc/home/9` 或库街区 App 登录页；
   - POST `user/sdkLogin`（Android okhttp 头，body: `code/devCode/gameList/mobile`），响应 `data.token` 即凭证；
   - 登录用的 devcode/distinct_id 原样保存进配置，保持设备一致性。
3. **手动抓包**：App 请求头 `token` 直接填入 yaml（App token 配 source=ios/android）。

### UserConfig 新增字段

- `source`：凭证来源端，`ios`（App 默认）/ `android` / `h5`（网页 token 必填）。
- `version`：与 source 配套，ios=2.2.0，h5=3.3.2。
- http_client 依据 source 切换请求头模板：h5 使用浏览器 UA + Origin/Referer 的 H5_HEADERS_TEMPLATE，三套接口统一用同一套头。

### Token 获取方法（手动抓包，兜底）

1. 手机安装抓包工具（Stream / HttpCanary / Charles 等）；
2. 打开库街区 App 任意页面，抓取 `api.kurobbs.com` 的请求；
3. 复制请求头中的 `token`（或 Cookie 中 `user_token=` 后的值）填入 `<用户名>.yaml` 的 `token` 字段。

## API 端点清单（api.kurobbs.com）

| 端点 | 用途 |
|---|---|
| `user/mineV2` | 获取用户信息（userId） |
| `user/sdkLogin` | 手机号+短信验证码登录（换 token，login_sms.py 用） |
| `user/signIn` | 论坛签到 |
| `user/role/findRoleList` | 获取游戏角色列表（roleId） |
| `forum/list` | 帖子列表（浏览/点赞任务用） |
| `forum/getPostDetail` | 浏览帖子 |
| `forum/like` | 点赞 |
| `encourage/level/getTaskProcess` | 每日任务列表与进度 |
| `encourage/level/shareTask` | 分享任务 |
| `encourage/gold/getTotalGold` | 金币余额 |
| `encourage/signIn/v2` | 游戏签到 |
| `encourage/signIn/queryRecordV2` | 签到记录（奖励名称） |
| `encourage/signIn/initSignInV2` | 签到初始化（可补签次数 omissionNum） |
| `encourage/signIn/repleSigInV2` | 补签 |

## 错误码语义

| code | 含义 | 处理 |
|---|---|---|
| 200 | 成功 | 正常流程 |
| 220 | 登录过期 | 抛 `TokenExpiredException` → 自动禁用用户 |
| 1511 | 今日已签到 | 视为成功，跳过 |
| 1513 | 用户信息错误 | 抛 `UserInfoException` → 自动禁用用户 |

## 请求头要点

- 论坛（bbs）：伪装 iOS KuroGameBox App，Cookie 带 `user_token`，头带 `token`/`devCode`/`distinct_id`/`Ip`。
- 游戏签到（game）：伪装 web 端（Origin web-static.kurobbs.com），`devCode` 格式为 `"<ip>, <UA>"`。
- 用户信息（user_info）：伪装 Android okhttp 端。
- 三套头的模板在 `constants.py`，注入逻辑在 `http_client.KuroHttpClient`。

## 定时自动化建议

WorkBuddy 自动化（recurring）示例提示词：

> 运行 kuro-bbs-autosign 技能：执行 C:\Users\Administrator\.workbuddy\skills\kuro-bbs-autosign\scripts\run_signin.py（用 Python 3.13.12），把签到总结汇报给我；如有用户被自动禁用（token 过期）请特别提醒。

建议每日 09:00 左右执行（签到周期按自然日重置）。

## 与参考项目 sign_in_manager.py 的对应关系

| 参考项目 | 本 skill | 差异 |
|---|---|---|
| log.py 自定义日志 | 标准 logging（logger 名 "kuro"） | 简化依赖 |
| 全局 requests Session | 每客户端独立 Session | 无功能差异 |
| push.py 全量 14 渠道 | 精简 8 渠道 | 保留最常用渠道，ini 格式不变 |
| config 环境变量 KuroBBS_config_path | KURO_BBS_CONFIG_PATH，默认 ~/.workbuddy/kuro-bbs-autosign/config | 凭证与 skill 目录解耦 |
| ql_main/index/task_scheduler（青龙面板） | 不移植 | 由 WorkBuddy 自动化替代定时调度 |
