---
name: skillhub-skill-kurobbs-sign-help
description: "库街区（库洛游戏社区 KuroBBS）自动登录与签到技能。基于用户 Token 完成鸣潮/战双帕弥什游戏签到（含自动补签）、论坛每日任务（签到/浏览/点赞/分享）与金币积分领取，支持多用户配置、失败重试、Token 失效自动禁用与多渠道结果通知。当用户要求「库街区签到」「鸣潮自动签到」「库街区刷积分」「库洛社区每日任务」或需要排查签到失败/Token 失效问题时使用。"
---

# kuro-bbs-autosign — 库街区自动签到技能

本技能将「库街区 App」（api.kurobbs.com）的每日自动化操作封装为一套可直接运行的 Python 脚本：登录态维护、游戏签到、论坛任务刷积分、结果通知。模块划分移植自 Kuro-autosignin 项目的 `sign_in_manager.py` 体系。

## 功能范围

1. **登录态维护与 Token 管理**：以 `user_token` 为唯一凭证（Cookie 形式）；首次运行自动生成 `devcode`/`distinct_id` 设备标识，自动拉取 `userId` 与游戏 `roleId` 回填配置；Token 失效（code 220）或用户信息异常（code 1513）时自动禁用该用户并通知。
2. **游戏签到**：鸣潮（gameId=3）与战双（gameId=2）每日签到，成功后查询当日奖励名称；支持自动补签（查询 `omissionNum` 后调用补签接口）。
3. **论坛任务与积分领取**：读取每日任务列表，逐项执行「用户签到 / 浏览 3 篇帖子 / 点赞 5 次 / 分享 1 次帖子」，已完成的任务自动跳过，最后汇总今日获得金币与当前金币余额。
4. **执行结果通知**：支持 Server酱、pushplus、Bark、钉钉机器人、飞书机器人、Telegram、Windows Toast、通用 Webhook；推送级别 1=仅总结 / 2=全部消息 / 3=逐条推送。

## 模块划分（对应 sign_in_manager.py 参考体系）

| 模块（scripts/kuro/） | 职责 | 参考来源 |
|---|---|---|
| `constants.py` | API 端点、三类请求头模板、GameType/TaskType/ErrorCode 枚举 | constants.py |
| `models.py` | ApiResponse/SignInResult/UserConfig/TaskSummary 数据类；TokenExpiredException 等异常体系 | models.py |
| `http_client.py` | KuroHttpClient：统一请求封装 + bbs/game/user_info 三套请求头 | http_client.py |
| `tools.py` | 本机 IP 获取、随机延迟、按 token 拉取用户信息与角色 ID | tools.py |
| `config_manager.py` | 按用户 YAML 配置的加载/保存/填充/禁用 | config_manager.py |
| `game_sign_in.py` | 游戏签到、奖励查询、补签 | game_sign_in.py |
| `forum_sign_in.py` | 论坛签到与每日任务编排、金币统计 | forum_sign_in.py |
| `sign_in_manager.py` | 编排器：单用户签到（重试/随机延迟/异常分流）与 run_all 全量执行 | sign_in_manager.py |
| `push.py` | 多渠道推送，ini 配置驱动 | push.py |

登录辅助脚本（scripts/ 根目录）：

| 脚本 | 职责 | 参考来源 |
|---|---|---|
| `save_token.py` | 调 mineV2 验证 token 有效性 → 写入用户 yaml（支持多候选逐一验证） | 基于 tools/config_manager |
| `login_sms.py` | 手机号+短信验证码直登 sdkLogin 换 token 并保存（浏览器不可用时的兜底） | login.py |

详细架构说明与 API 清单见 `references/architecture.md`。

## 登录与 Token 获取（三选一）

**关键知识（实测验证）**：网页端登录后的凭证体系与 App 不同——token 存于 localStorage 的 `auth` 键（JSON 内 `token` 字段），且**必须**配套 `source: h5` + `version: 3.3.2` 请求头，以及登录时的 `devCode`（localStorage `dc` 键）与 `distinct_id`；三者任缺或 devCode 不匹配都会返回 code 220。

### 方式 A：WorkBuddy 内置浏览器自动登录（推荐，已实测跑通）

1. `agent-browser open https://www.kurobbs.com/mc/home/9` → `wait --load networkidle`（若 SPA 白屏，改用 /mc/home/9 移动端路径必成功）。
2. `eval "document.querySelector('.kr-avatar').click()"` 打开登录弹窗（协议勾选框为 SVG，需 eval 点击其父容器）。
3. 请用户提供手机号 → `agent-browser type "input[placeholder='请输入手机号码']" <手机号>`；点击协议勾选框；点击「获取验证码」——会弹出 GeeTest 滑块拼图验证码：
   - 用 `eval` 读取 `[class*=geetest_bg]` 与 `[class*=geetest_slice_bg]` 的 background-image URL；
   - 下载两张图，对 slice(80x80) 在 bg(300x200) 上做**梯度模板匹配**得到缺口 x（y 校验：匹配 y+150 应等于 slice 元素 top）；
   - 拖动距离 = 缺口x × 302/300（CSS 缩放），用 `agent-browser mouse move/down/分步move/up` 模拟人手轨迹（分 8-10 步、轻微抖动、末端过冲回拉）。
4. 用户提供 6 位验证码 → 填入 `input[placeholder='请输入6位验证码']` → 点「登录」。
5. 登录成功后一次性提取三件套：
   ```js
   eval "(() => { const auth = JSON.parse(localStorage.getItem('auth')); return JSON.stringify({token: auth.token, devcode: localStorage.getItem('dc'), distinct_id: localStorage.getItem('distinct_id')}); })()"
   ```
6. 保存（h5 凭证必须带全部参数）：
   ```bash
   python <skill>/scripts/save_token.py --user <昵称> --token <token> --source h5 --version 3.3.2 --devcode <dc> --distinct-id <distinct_id>
   ```
7. `agent-browser close` 收尾。

### 方式 B：短信验证码直登（无浏览器兜底，参考 login.py）

```bash
# 先在 https://www.kurobbs.com/mc/home/9 或库街区 App 触发短信验证码，然后：
python <skill>/scripts/login_sms.py --user <名字> --mobile 138xxxxxxxx
# 按提示输入验证码；脚本调 sdkLogin（Android 头）换 token 并保存
```

### 方式 C：手动抓包

抓包库街区 App 请求 api.kurobbs.com，复制请求头 `token`，手动填入 `<用户名>.yaml`（App token 配 source=ios/android）。


## 配置方式（账号凭证存放位置）

- 默认配置目录：`~/.workbuddy/kuro-bbs-autosign/config/`（可用环境变量 `KURO_BBS_CONFIG_PATH` 或 `--config-dir` 覆盖）。**凭证不放入 skill 目录**，避免 skill 更新时丢失或泄露。
- 每个用户一个 `<用户名>.yaml`，模板见 `assets/config/user.example.yaml`，必填字段仅 `token`（库街区 App 抓包获取，见 architecture.md）。
- 推送配置 `push.ini`（可选），模板见 `assets/config/push.example.ini`。

## 运行环境与依赖

- Python 3.10+；依赖 `requests`、`pyyaml`（见 `scripts/requirements.txt`）。
- 本机 Python：`C:\Users\Administrator\.workbuddy\binaries\python\versions\3.13.12\python.exe`；缺包时先建 venv：`<python> -m venv C:\Users\Administrator\.workbuddy\binaries\python\envs\default` 后用其 pip 安装。

## 运行入口

```bash
# 全部用户签到（常规用法）
python <skill>/scripts/run_signin.py
# 指定用户 / 配置目录 / 调试日志 / 关闭推送
python <skill>/scripts/run_signin.py --user <name> --config-dir <dir> --debug --no-push
```

每日定时执行：建议用 WorkBuddy 自动化（recurring），提示词中写明「运行 kuro-bbs-autosign 技能的签到脚本并汇报结果」。

## 异常处理策略

| 场景 | 识别方式 | 处理 |
|---|---|---|
| 登录失效 | code 220 | 抛 TokenExpiredException → 自动 `enable: false` 禁用该用户，通知用户重新抓包更新 token |
| 用户信息异常 | code 1513 | 抛 UserInfoException → 同上自动禁用 |
| 重复签到 | code 1511 | 视为成功（返回「今天已签到」+奖励），不重试 |
| 网络错误/其他失败 | 异常或非 200 | 随机延迟 5–15s 后重试，默认最多 3 次（`retry_times`），耗尽后放弃并计入失败 |
| 限流 | 连续失败/响应异常 | 用户之间固定 sleep 1s；任务之间 sleep 1s；重试用随机延迟抖动 |
| 验证码/风控 | 未知错误码且反复出现 | 不自动重试爆破；记录完整响应码与 message，通知用户人工处理 |

## 工作流指引

1. **首次使用**：按上文「登录与 Token 获取」三选一完成配置（推荐方式 A 浏览器自动登录）→ 运行脚本（自动填充 userId/roleId 并回写 `completed: true`）。
2. **每日签到**：直接运行 `scripts/run_signin.py`；结束读取输出的 `TaskSummary` 向用户汇报成功/失败/禁用名单。
3. **排查失败**：加 `--debug` 重跑查看请求/响应；code 220 时用「登录与 Token 获取」流程重新登录换新 token（脚本会保留其余配置并重新启用 `enable: true` 语义的 token 字段，但需手动把 yaml 中 `enable` 改回 `true`）。
4. **新增推送渠道**：编辑配置目录下 `push.ini`（格式见 assets 模板），`push_server` 支持逗号分隔多渠道。
