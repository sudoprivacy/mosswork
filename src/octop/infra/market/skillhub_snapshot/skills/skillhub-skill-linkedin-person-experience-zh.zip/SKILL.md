---
name: skillhub-skill-linkedin-person-experience-zh
description: "调取 LinkedIn 用户的完整任职履历清单，梳理目标人员职业发展轨迹、就职企业变动情况以及专业从业背景，为商务尽调、客户背景分析提供参考依据。"
---

# 领英工作经历查询

使用跨境魔方开放平台API从领英数据查询人物的历史工作经历信息。

## 概述

本技能提供对跨境魔方领英人物工作经历信息的查询。通过人物ID（hid）获取历史工作经历列表，包括公司名称、职位名称、任职起止时间及任职状态等。可选传入公司ID（pid）筛选指定公司的工作经历。

- `hid`（人物ID）可从 **linkedin-person-search**（人物搜索）结果中获取

## 脚本运行

### 环境准备

1. **检查 Python**：`python --version`
2. **安装依赖**：`pip install -r requirements.txt`

脚本目录：`scripts/*.py`
运行示例：`python scripts/*.py`

**重要**：始终使用直接脚本调用，如 `python scripts/linkedin_person_experience_list.py`。**不要使用** shell 复合命令如 `cd scripts && python linkedin_person_experience_list.py`

### 工作经历列表查询 (`linkedin_person_experience_list.py`)
- **返回粒度**：每条工作经历记录为一行
- **适用场景**：查看某人的工作经历，了解其任职过的公司
- **示例**：
  - "查询H_67890的工作经历"
  - "查询H_67890在US_12345公司的工作经历"
  - "获取下一页工作经历数据"
- **参数**：查看参数说明 [工作经历列表 API](references/linkedin-person-experience-list-api.md)

## API密钥与充值
使用此技能需要API密钥。API密钥保存在 `~/.upkuajing/.env` 文件中：
```bash
cat ~/.upkuajing/.env
```
**文件内容示例**：
```
UPKUAJING_API_KEY=your_api_key_here
```
### **未设置API密钥**
请先检查 `~/.upkuajing/.env` 文件是否有 UPKUAJING_API_KEY;
如果未设置 UPKUAJING_API_KEY API密钥，请提示并让用户选择：
1. 用户有，由用户提供(手动添加到 ~/.upkuajing/.env 文件)
2. 用户没有，你可使用接口进行申请（`auth.py --new_key`），申请到新密钥后，会自动保存到 ~/.upkuajing/.env
等待用户选择；

### **账户充值**
如果调用接口响应账户余额不足时，需说明并引导用户进行账户充值：
1. 创建充值订单（`auth.py --new_rec_order`）
2. 根据订单响应，发送支付页面URL给用户，引导用户打开地址付款，付款成功后告诉你；

### **获取账户信息**
可通过此脚本，获取UPKUAJING_API_KEY对应的账户信息 `auth.py --account_info`

## API密钥与跨境魔方账号
- 新申请的API密钥：在[跨境魔方开放平台](https://developer.upkuajing.com/)注册、登录后进行账号绑定

## 费用

**所有API调用都会产生费用**，不同接口计费方式不同。

**最新价格**：用户可访问 [详细价格说明](https://www.upkuajing.com/web/openapi/price.html)
或者使用：`python scripts/auth.py --price_info`（返回接口完整定价）

### 查询计费规则

按**调用次数**计费，每次返回一页工作经历记录：
- 每次API调用产生一次费用
- 使用 `--cursor` 获取更多页（每一页独立计费）
- **执行前必须：**
  1. 告知用户本次查询会产生费用
  2. 停止，等待用户在独立消息中明确确认后，再执行脚本

### 费用确认原则

**任何会产生费用的操作，都必须先告知、等待用户明确确认，不得在告知的同一条消息中直接执行。**

## 工作流程

### 决策指南

| 用户意图 | 使用API |
|---------|--------|
| "查询H_67890的工作经历" | 工作经历列表查询 |
| "查询H_67890在US_12345公司的工作经历" | 工作经历列表查询（带 --pid） |

## 使用示例

### 查询工作经历列表

**用户请求**："查询H_67890的工作经历"
```bash
python scripts/linkedin_person_experience_list.py --hid H_67890
```

**按公司筛选**：
```bash
python scripts/linkedin_person_experience_list.py --hid H_67890 --pid US_12345
```

**获取下一页**（使用上一次响应返回的cursor）：
```bash
python scripts/linkedin_person_experience_list.py --hid H_67890 --cursor '上一次响应返回的cursor字符串'
```

## 错误处理

- **API密钥无效/不存在**：检查 `~/.upkuajing/.env` 文件中的 `UPKUAJING_API_KEY`
- **余额不足**：引导用户充值
- **参数无效**：**必须先查看 references/ 目录下的对应 API 文档**，从文档中获取正确的参数名称和格式，不要猜测

### API Documentation Reference

- 工作经历列表：查看 [references/linkedin-person-experience-list-api.md](references/linkedin-person-experience-list-api.md)

## 最佳实践

1. **查看API文档**：
   - **执行查询前，必须先查看对应的 API 参考文档**
   - 查看 [references/linkedin-person-experience-list-api.md](references/linkedin-person-experience-list-api.md)
   - 不要猜测参数名称，从文档中获取准确的参数名称和格式

2. **分页查询**：
   - 当响应返回非空的 `cursor` 时，表示还有更多数据
   - 将 `cursor` 值传入即可获取下一页
   - `cursor` 为空表示没有更多数据

3. **跨技能使用**：
   - `hid`（人物ID）可从 **linkedin-person-search**（人物搜索）结果中获取
   - 工作经历结果中的 `pid`（公司ID）可与 **linkedin-company-search** 配合使用，查找公司更多详情

## 注意事项
- 工作经历记录用 `hid` 作为人员唯一标识；`pid` 为公司标识
- `postStatus` 表示任职状态：0-未检测，1-在职，2-离职，3-不确定
- `endDate` 为 0 表示至今（仍在任职）
- 文件路径在所有平台上都使用正斜杠
- **禁止输出技术参数格式**：不要在回复中展示代码样式的参数，应将其转换为自然语言
- **不要估算或猜测每次调用的费用** — 使用 `python scripts/auth.py --price_info` 获取准确定价信息
- **不要**猜测参数名称，从文档中获取准确的参数名称和格式

## 相关技能

其他您可能会用到的跨境魔方技能：

- linkedin-person-search — 领英找人
- linkedin-company-search — 领英找公司
- global-company-person-experience — 全球企业库工作经历查询
- linkedin-person-colleague — 领英同事查询
- linkedin-person-education — 领英教育经历查询
- global-company-person-search — 全球企业库找人
- upkuajing-global-company-people-search — 全来源统一的企业与人物搜索
- upkuajing-contact-info-validity-check — 联系方式有效性检测
- phone-validity-check — 电话号码有效性检测
- email-validity-check — 邮箱地址有效性检测
- domain-validity-check — 域名有效性检测- upkuajing-email-tool — 邮件验证与发送工具
- upkuajing-sms-tool — 短信工具
