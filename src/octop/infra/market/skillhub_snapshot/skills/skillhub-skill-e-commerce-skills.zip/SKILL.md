---
name: skillhub-skill-e-commerce-skills
description: "This skill should be used when the user wants to produce e-commerce visual and video content at scale, including product hero/detail images, marketing short videos, social-media seeding posts (Xiaohongshu/Douyin/朋友圈 style), and detail-page / landing-page copywriting. Trigger when the user asks for \"电商主图\", \"商品详情图\", \"详情页\", \"种草图文\", \"带货文案\", \"宣传视频\", \"产品展示视频\", \"淘宝/京东/拼多多/抖音/小红书素材\", \"给我一批产品图\", \"生成品牌宣传片\","
---

# Ecommerce Content Studio

A guided, end-to-end workflow for producing e-commerce visual assets (product images, marketing videos, seeding posts, detail-page copy) from a short product brief.

## When to use this skill

Trigger on any request that involves producing or refreshing e-commerce creative assets:
- Product hero images, white-background shots, lifestyle scenes, comparison charts, feature callouts, A/B test variants
- Short marketing videos (product showcase, hands-on demo, brand reel, talking-head promo)
- Xiaohongshu / Douyin / WeChat seeding posts (image + caption pair)
- Detail page (详情页) / landing page copywriting and visual hooks
- Listing refreshes, seasonal campaigns, new-product launches

Skip when the user only wants:
- A single one-off image without e-commerce context
- Pure document writing with no visual generation
- Code/data work unrelated to content production

## Operating principles

1. **Dialogue first.** Always collect a structured brief before generating anything. Never assume product details.
2. **Channel-aware.** Each Chinese e-commerce platform has different image/video specs and stylistic norms — pick the right template per channel.
3. **Batch over single.** E-commerce usually needs 4–8 image variants and 2–3 video variants for A/B; produce in batches, not one-by-one.
4. **Copy and visual together.** Every asset ships with ready-to-use copy (title / bullets / caption / hook).
5. **Reproducible prompts.** Store the exact prompts used so the user can re-run or tweak later.

## Workflow

### Step 1 — Collect the product brief (dialogue)

Use `AskUserQuestion` to gather the minimum viable brief. Run questions in this order, one batch at a time. Do not overwhelm the user.

**Batch A — What & for whom** (must collect):
1. 产品是什么？(product name + category, e.g. "蓝牙耳机 / 3C数码")
2. 核心卖点 / 差异化是什么？(3–5 selling points, e.g. "降噪 / 续航30h / 轻盈")
3. 目标人群？(age, gender, lifestyle, e.g. "25–35 都市白领通勤族")
4. 价格带？(budget / mid / premium, e.g. "¥299 入门款")

**Batch B — Where & how** (must collect):
5. 投放平台？(淘宝/京东/拼多多/抖音/小红书/视频号/独立站 — multi-select)
6. 品牌调性？(可选: 国潮 / 极简 / 高级感 / 活泼 / 科技 / 复古 / 治愈 / 专业)
7. 产出类型？(主图 / 详情图 / 宣传视频 / 种草图文 / 详情页文案 — multi-select)

**Batch C — Optional refinements**:
8. 配色 / 视觉关键词？(e.g. "莫兰迪 / 黑金 / 马卡龙")
9. 必须出现的元素？(logo / 包装 / 代言人 / IP 形象 / 特定场景)
10. 忌讳的元素？(竞品 logo / 医疗器械感 / 宗教符号 / 任何敏感元素)

If the user already provided most of this information in their initial message, only ask for what's missing.

Write the collected brief into a structured object and **confirm with the user once before generating**:

```yaml
product: <name>
category: <category>
selling_points: [p1, p2, p3]
audience: <age, gender, lifestyle>
price_band: <budget | mid | premium>
channels: [taobao, jd, xiaohongshu, ...]
tone: <tone words>
deliverables: [hero_image, detail_images, video, seeding_post, copy]
palette: [colors]
must_have: [elements]
avoid: [elements]
```

### Step 2 — Pick generation specs from references

Load the matching reference files:

| Deliverable | Reference to read |
|---|---|
| Product / detail images | `references/platform-specs.md` (for size & ratio), `assets/prompts/image-prompts.md` (for prompt templates) |
| Marketing videos | `references/platform-specs.md` (for duration & aspect), `assets/prompts/video-prompts.md` |
| Seeding posts | `references/copywriting-frameworks.md` |
| Detail / landing copy | `references/copywriting-frameworks.md` |

Cross-reference platform specs → match each `channel` to the right output dimensions (1:1 主图, 3:4 详情图, 9:16 短视频, 16:9 横版, etc.).

### Step 3 — Generate images (batch)

For each visual deliverable requested:

1. Compose a high-quality prompt in English (text-to-image models perform best in English) by combining:
   - Subject: the product with key visual details
   - Setting / background: lifestyle scene or studio per the brief
   - Lighting & camera: studio softbox / golden hour / macro close-up / etc.
   - Style: brand tone keywords
   - Quality boosters: "ultra-detailed, commercial photography, sharp focus, 8K"
2. Call the multimodal generation skill with one prompt per variant. Aim for **4–6 image variants per product**:
   - 1 hero / main shot
   - 1–2 lifestyle / scene shots
   - 1 detail / macro shot (texture, ingredient, craftsmanship)
   - 1 comparison or "before/after" shot if relevant
   - 1 text-overlay-ready shot (clean background for adding卖点文案)
3. For each generated image, briefly note what variant it is and which selling point it highlights.
4. If the user wants on-image Chinese text (卖点文字 / 价格 / 折扣), generate text-free base images and add text in post — text-to-image models are unreliable with Chinese characters.

### Step 4 — Generate videos (batch)

For each video deliverable:

1. Pick the right **video template** from `assets/prompts/video-prompts.md`:
   - **Product showcase** (产品展示): rotating hero shot, sleek studio
   - **Lifestyle / hands-on** (使用场景): real-world usage, relatable cast
   - **Brand reel** (品牌宣传片): 15s cinematic mood piece
   - **Talking-head promo** (口播带货): requires the user to provide a face / spokesperson
2. Compose the prompt with subject + motion description (camera movement, action, transitions).
3. For each video, also write a **script / voiceover** (Chinese, 30–60s) using `references/copywriting-frameworks.md` (PAS / AIDA / 卖点列举).
4. Generate 2–3 variants for A/B testing.

### Step 5 — Write copy (batch)

Use frameworks from `references/copywriting-frameworks.md`. For each channel produce:

| Channel | Asset | Length guideline |
|---|---|---|
| 淘宝/京东/拼多多 主图 | 标题 6–14 字 + 卖点短句 4–8 字 | punchy, keyword-dense |
| 详情页 | 钩子句 + 卖点段落 + 信任背书 + 行动号召 | 200–500 字 |
| 小红书 种草 | 标题（emoji + 悬念）+ 正文（体验流 + 干货） | 300–600 字 |
| 抖音 口播 | 钩子（前 3 秒）+ 卖点 + 促单 | 80–150 字 |
| 视频号 / 朋友圈 | 短文案 + 标签 | 30–80 字 |

Use the **collect → highlight → proof → CTA** rhythm. Always include platform-native emoji conventions where appropriate (小红书: 适度 emoji; 淘宝: 促销图标如🔥💥).

### Step 6 — Package and deliver

Organize all outputs by channel folder and present to the user:

```
<product-name>-assets/
├── taobao/
│   ├── hero-1.png ... hero-4.png
│   ├── detail-1.png ... detail-6.png
│   └── copy.md
├── xiaohongshu/
│   ├── post-1.png ... post-3.png
│   └── captions.md
├── video/
│   ├── showcase-15s.mp4
│   ├── showcase-30s.mp4
│   └── script.md
└── briefs/
    └── brief.yaml  ← the collected brief
```

Use `deliver_attachments` to send all final files. Keep the `brief.yaml` so the user can re-run the workflow later.

### Step 7 — Memory and skill update (mandatory)

After delivering, write a memory note to today's daily log describing what was produced and which prompt templates performed well. If a new prompt template emerged that wasn't in `assets/prompts/`, add it so the next run benefits.

## Quality rules

- **Chinese text in images**: never rely on the image model to write correct Chinese. Generate clean base images and overlay text separately, or use English text in the prompt.
- **Brand consistency**: keep palette, typography hints, and tone vocabulary consistent across all assets in one batch.
- **Platform compliance**: respect each platform's image ratio, file-size limit, and content policy. Read `references/platform-specs.md` before generating.
- **No fabricated facts**: if the user didn't provide specs (续航 30h, 2000mAh, etc.), do not invent them. Use placeholders like `[续航时间待确认]`.
- **Sensitive content**: refuse medical efficacy claims, absolute terms (最/第一/国家级), political or religious imagery, and any content in the user-content policy. Always stay on the safer side.

## Bundled resources

- `references/platform-specs.md` — Chinese e-commerce platform image/video specs (淘宝, 京东, 拼多多, 抖音, 小红书, 视频号)
- `references/copywriting-frameworks.md` — Headline formulas, AIDA / PAS / 4P1S, 种草 / 带货 / 详情页 frameworks
- `assets/prompts/image-prompts.md` — Reusable image prompt templates (studio, lifestyle, macro, comparison, scene)
- `assets/prompts/video-prompts.md` — Reusable video prompt templates (showcase, lifestyle, brand reel, talking-head)
- `assets/templates/brief-template.yaml` — Brief intake template (also see the yaml block in Step 1)