# 电商视频提示词模板库

> 视频提示词比图片更需要明确"运动"和"时间"维度。按模板填空即可。

## 通用视频尾缀

```
Smooth cinematic camera movement, natural ambient lighting, shallow depth of field, professional color grading, ultra-detailed, 4K, no text overlay
```

## 一、产品展示视频（Product Showcase）

适合: 淘宝主图视频、品牌官网上架视频、详情页顶部自动播放。

### 1.1 旋转展示

```
A [产品] on a turntable slowly rotating 360 degrees, clean seamless [white/dark] background, smooth camera dolly-in from wide to close-up over 15 seconds, soft even studio lighting, reflections on glossy surface, premium commercial product video, 4K
```

### 1.2 360 度环绕

```
Slow 360-degree orbit shot around a [产品] placed on a [surface], camera moving smoothly, every angle revealed, soft studio lighting with rim light highlighting contours, premium commercial video, 4K
```

### 1.3 悬浮上升

```
A [产品] slowly rising from the [surface] into mid-air, particles of light floating around it, dark moody background with subtle gradient, camera tilts up following the product, premium commercial product video, 4K
```

## 二、使用场景视频（Lifestyle / Hands-on）

适合: 抖音/小红书种草视频、品牌广告片。

### 2.1 真人使用

```
Close-up shot of a [人物描述] using a [产品] in [场景], natural relaxed movements, camera follows the hand action, soft natural lighting, cinematic shallow depth of field, lifestyle commercial video, 4K
```

范例（耳机）:
```
Close-up shot of a 25-year-old Asian woman in a cafe, gently removing wireless earbuds from her ears and placing them on a wooden table, then pressing play on her phone, soft afternoon window light, cinematic shallow depth of field, lifestyle commercial video, 4K
```

### 2.2 制作过程（食品/手工艺）

```
Overhead shot of [手工/制作过程] hands working on [产品], ingredients and tools visible, warm natural lighting, time-lapse feeling with smooth slow motion, artisan craftsmanship video, 4K
```

范例（手工皂）:
```
Overhead shot of artisan hands pouring melted soap base into a wooden mold, scattered botanicals and essential oil bottles around, warm natural lighting, smooth slow motion, artisan craftsmanship video, 4K
```

## 三、品牌宣传片（Brand Reel）

适合: 视频号、品牌官网首页、品牌 TVC、社媒品牌话题。

### 3.1 情绪叙事

```
Cinematic montage: [场景 1: 工艺/原料], dissolve to [场景 2: 真实使用], dissolve to [场景 3: 关键卖点特写], final shot of [产品] hero placement with [氛围]. Cohesive [color palette] throughout, orchestral or lo-fi background music implied, cinematic commercial brand film, 4K
```

范例（咖啡品牌）:
```
Cinematic montage: opening shot of coffee cherries rippling in the sun, dissolve to a barista's hands tamping espresso, dissolve to steam rising from a freshly poured latte with latte art, final hero shot of the coffee bag against a deep brown background with golden light flares. Cohesive warm earth tones throughout, cinematic commercial brand film, 4K
```

### 3.2 产品亮相（Reveal）

```
Camera starts on a close-up of [关键材质/工艺细节], slowly pulls back through a [意象: 烟雾/光柱/花瓣] reveal to show the full [产品] sitting on a [stage], dramatic lighting from behind, cinematic product reveal video, 4K
```

## 四、口播带货视频（Talking-head / Promo）

适合: 抖音口播、视频号种草、达人合作。

> **注意**: 真实口播需要人物形象/数字人形象。如果用户没有提供,告知需要先准备素材或使用数字人生成能力。

### 4.1 标准口播

```
Medium close-up shot of a [人物: 形象/着装], facing camera, well-lit with [柔光灯 + 环形灯], [背景: 简洁/书架/品牌色背景], direct eye contact with camera, talking naturally with subtle hand gestures, talking-head promo video style, 4K
```

### 4.2 走播 / Vlog 风

```
Handheld follow shot of a [人物] walking through [场景: 商超/商场/展厅], holding [产品], showing it to camera with natural excitement, slightly shaky but energetic camera, real ambient sound, vlog-style product review video, 4K
```

## 五、过程 / 实验对比视频

适合: 美妆、清洁、家居、健身器材——需要"看效果"的品类。

### 5.1 Before-After 平铺

```
Top-down shot of a [表面] divided into two halves, left half [脏/旧/普通], right half [干净/新/用产品处理后], a hand applies [产品] on the left, time-lapse shows transformation, both halves become visible in final frame, satisfying before-after video, 4K
```

### 5.2 倒计时 / 爆款元素

```
Slow motion shot of [液体/粉末/泡沫] pouring / splashing / foaming on a [产品/场景], high-speed camera at 120fps revealing micro details, dramatic backlighting, satisfying slow-motion product video, 4K
```

## 六、节日 / 大促氛围视频

### 6.1 节日品牌片

```
Festive commercial video: [产品] as the hero, surrounded by [节日元素], particles of [金色雪花/亮片/花瓣] floating in slow motion, [节日色彩] lighting, celebratory mood, brand festive commercial, 4K
```

### 6.2 倒计时促销

```
A [产品] sits in the center of the frame, a 3D countdown timer rotates around it (10, 9, 8...), sparks and confetti bursts in the final 3 seconds, bold red and gold promotional color palette, dynamic commercial promo video, 4K
```

## 七、配音/旁白脚本模板（中文, 用于 voice-over）

### 7.1 30 秒脚本

```
[0–3s 钩子]
"你还在为 [痛点] 发愁吗?"

[3–10s 痛点]
"每次 [具体场景], 不仅 [痛点描述],
还浪费了你 [时间/金钱/精力]"

[10–22s 解决方案 + 卖点]
"今天给大家推荐 [产品名],
它能做到 [核心卖点 1],
还能 [核心卖点 2],
更重要的是 [核心卖点 3]"

[22–30s 促单]
"现在下单立减 [X] 元,
链接就在左下角小黄车,
前 [N] 名还送 [赠品]!"
```

### 7.2 60 秒品牌片脚本

```
[0–5s  意境画面, 低音乐起]
[无旁白, 只展示品牌 logo 演变或产品工艺]

[5–20s  品牌故事]
"X 年前, 我们在 [城市/起源],
想做一款 [初心],
不为颠覆, 只为 [价值]"

[20–40s 产品理念 + 工艺]
"所以有了这一款 [产品名],
每一道工序, 都来自 [工艺/匠人],
每一个细节, 都为 [用户体验] 而设计"

[40–55s 用户场景]
"它陪我们走过 [使用场景 A],
也陪我们度过 [使用场景 B],
[生活方式的升华]"

[55–60s 收束 + slogan]
"[品牌 slogan]"
[画面回到产品 hero shot + logo]
```

## 视频时长/节奏建议

| 时长 | 镜头数 | 节奏 | 适合 |
|---|---|---|---|
| 6–9s | 1–2 个 | 快速、冲击 | 抖音开头、信息流广告 |
| 15s | 2–3 个 | 中等 | 抖音/小红书标准 |
| 30s | 4–5 个 | 完整故事 | 详情页视频、品牌广告 |
| 60s | 6–8 个 | 慢叙事 | 品牌 TVC、视频号长视频 |

每个镜头建议停留 3–5 秒,前 3 秒必须抓住注意力。