# 电商图片提示词模板库

> 直接复用或微调使用。所有提示词以英文为主（多模态模型对英文表现更佳）,中文仅作为注释参考。

## 一、通用质量尾缀（追加到每个提示词末尾）

```
ultra-detailed, commercial product photography, sharp focus, soft studio lighting, 8K resolution, professional color grading, no text, no watermark
```

## 二、白底主图模板

适用于淘宝/京东/拼多多主图首图,过审最快。

```
A single [产品] on a pure white seamless background, soft even lighting with no harsh shadows, the product is centered and occupies 60% of the frame, ultra-clean composition, shot with a 100mm macro lens at f/8, ultra-detailed, commercial product photography, sharp focus, 8K
```

变量:
- `产品` → e.g. "wireless bluetooth earbuds, matte black finish"
- 主色: 可加 "in matte black / pure white / pastel pink"

## 三、生活方式场景图

小红书/抖音种草、详情页场景图常用。

```
[Lifestyle scene description]. On the [surface], a [产品] sits naturally in use, [人物/动作描述]. Warm natural daylight from a window on the left, soft shadows, shallow depth of field with creamy bokeh, lifestyle photography aesthetic, ultra-detailed, 8K, no text
```

范例（蓝牙耳机 + 通勤场景）:
```
A young female office worker in a modern subway carriage, wearing a beige knit sweater, listening to music with small white wireless earbuds. Soft window light, shallow depth of field with creamy bokeh, lifestyle photography aesthetic, ultra-detailed, 8K, no text
```

范例（保温杯 + 户外露营）:
```
A brushed stainless steel thermos bottle on a pine wood picnic table, steam rising from the open lid, surrounded by pine trees and golden sunset light, camping lifestyle scene, warm natural tones, shallow depth of field, ultra-detailed, 8K, no text
```

## 四、特写 / 微距图

突出材质、工艺、纹理,适合卖点图。

```
Extreme close-up macro shot of [产品 detail], [材质/工艺/纹理] clearly visible, side lighting revealing [质感/光泽], dark moody background, shot with a 100mm macro lens, ultra-detailed, commercial product photography, 8K
```

范例（耳机微距）:
```
Extreme close-up macro shot of the ear tip of a wireless earbud, the soft silicone texture and metal mesh grille clearly visible, side lighting revealing the matte black finish, dark gradient background, ultra-detailed, commercial product photography, 8K
```

## 五、对比图 / Before-After

适合功效类、美妆类、家居清洁类。

```
Split-screen comparison, left side labeled area showing [before state], right side showing [after state] with [产品], identical lighting and camera angle on both sides, clean studio composition, commercial photography, ultra-detailed, 8K, no text
```

注意: 提示词中**不要写中文文字**,用英文 placeholder（"before"/"after"）;真实文字后期叠加。

## 六、卖点强调图（纯背景,留白给后期加文字）

```
A [产品] placed at the [position] on a [纯色背景], with a large negative space area on the [left/right/top] reserved for text overlay. Clean studio lighting, soft shadows, commercial product photography, sharp focus, 8K
```

范例:
```
A perfume bottle placed at the bottom-right of the frame on a deep burgundy background, with a large negative space area on the upper-left reserved for text overlay. Clean studio lighting, soft shadows, commercial product photography, sharp focus, 8K
```

## 七、节日/季节主题图

适合大促、新品上市。

```
[产品] placed on a [节日符号装饰的桌面], 主题色彩为 [节日配色], 周围点缀 [节日元素], 柔和自然光, 节日氛围浓郁但克制, 商业摄影, 超清细节, 8K, 无文字
```

范例（圣诞）:
```
A skincare gift set placed on a dark green velvet surface, surrounded by pine sprigs, red berries, and warm fairy lights, soft bokeh, festive but elegant mood, commercial photography, ultra-detailed, 8K, no text
```

## 八、模特手持 / 真人使用图

适合服饰、配饰、3C、美妆。

```
A [人物描述: 年龄/性别/风格] holding/using [产品], natural relaxed pose, [场景], eye-level camera angle, natural lighting, candid lifestyle photography aesthetic, ultra-detailed, 8K, no text
```

范例（包）:
```
A 28-year-old Asian woman with shoulder-length black hair, wearing a cream knit dress, holding a small leather crossbody bag, walking through a sunlit autumn park, natural candid pose, eye-level angle, soft afternoon light, lifestyle photography, ultra-detailed, 8K, no text
```

## 九、多产品组合 / 全家福

适合套装、礼盒、组合促销。

```
A flat-lay composition of [产品组合], artfully arranged on a [背景材质], [装饰元素] scattered around for context, top-down view, even soft lighting, balanced symmetrical composition, commercial product photography, ultra-detailed, 8K, no text
```

范例:
```
A flat-lay composition of a 5-piece skincare set (cleanser, toner, serum, moisturizer, sunscreen), arranged on a white marble surface with a sprig of fresh green leaves and a folded linen cloth, top-down view, even soft lighting, balanced composition, commercial product photography, ultra-detailed, 8K, no text
```

## 十、动态模糊 / 速度感图

适合数码、运动、汽车用品。

```
[产品] in motion, [动作描述如: 飞驰/旋转/喷洒], motion blur trails in the background, sharp focus on the product, dramatic lighting, dynamic commercial photography, ultra-detailed, 8K
```

范例:
```
A pair of running shoes mid-stride on a wet city pavement, water splashing around, motion blur on the background, sharp focus on the shoes, dramatic side lighting, dynamic commercial photography, ultra-detailed, 8K
```

## 调色 / 风格关键词库

按品牌调性选用,直接加在提示词末尾。

| 风格 | 关键词 |
|---|---|
| 高级感 / 极简 | `minimalist, muted tones, high-end editorial, neutral palette, soft shadows` |
| 国潮 | `Chinese aesthetic, ink wash painting elements, traditional motifs, deep red and gold` |
| 活泼 / 年轻 | `vibrant saturated colors, playful composition, candy palette, pop art style` |
| 科技感 / 数码 | `futuristic, neon accent lighting, dark background, glossy reflective surface, cyberpunk` |
| 治愈 / 家居 | `warm beige tones, natural wood textures, soft window light, cozy home interior` |
| 复古 | `vintage film grain, warm analog tones, retro props, 70s color palette` |
| 食品 / 食欲感 | `steam rising, glossy texture, warm golden lighting, shallow depth of field, mouth-watering` |
| 美妆 / 高级感 | `soft pink and rose gold palette, glass and crystal props, dreamy bokeh, glossy finish` |
| 母婴 | `pastel mint and cream, soft toys, gentle diffused lighting, tender mood` |

## 一次性批量生成建议

为同一 SKU 出图时,先确定一个**基准提示词**(白底主图),再基于它派生:

1. **基准**: 白底主图（产品 + 白底 + 100mm 微距）
2. **派生 1**: 微距特写（聚焦材质细节）
3. **派生 2**: 生活方式场景（人 + 真实场景）
4. **派生 3**: 卖点留白图（大留白,后期加文字）
5. **派生 4**: 对比图（如适用）
6. **派生 5**: 节日/促销主题

5–6 张一套,覆盖详情页所有板块。