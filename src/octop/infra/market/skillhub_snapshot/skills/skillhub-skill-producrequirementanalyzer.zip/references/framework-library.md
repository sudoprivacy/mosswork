# 框架速查库（references · 渐进披露）

> 本文件是 `产品需求分析` Skill 的**渐进披露**附件：SKILL.md 只保留路由与用法，框架细节下沉到此。
> 内容来源：① 吸收自 PM Master（广度工具箱）的实用方法；② 产品大师方法论情报库（OSINT，50+ 框架精选）。
> 用法：分析时按 SKILL.md「框架索引」路由，按需读本文件对应小节。

---

## A. 需求深挖（主干 · 经典理论）

### A1 进化心理学 · 四大进化驱动力
- 生存 / 社会 / 能力 / 意义。映射到"停用后的不适"。
- ⚠️ "驱动力→不适"映射为作者归纳、未验证，须用产品行为证据支撑。

### A2 JTBD（待完成的工作）
- 功能 / 情感 / 社会工作三层。
- Job Story 范式：「当 ___ 时，我想要 ___，以便 ___。」

### A3 SDT（自我决定理论）
- 自主感 / 胜任感 / 关联感，各 1–10 评分 + 功能证据。

### A4 竞争替代矩阵
- 需求强度（高/中/低）× 替代难度（难/中/易）→ 护城河评估。

---

## B. 吸收自 PM Master 的实用方法（分支）

### B1 5W1H（需求澄清）
- Who / What / Why / Where / When / How。用于步骤 1 输入获取。

### B2 Y 模型（俞军需求模型）· 需求→功能桥接
```
用户需求 → 需求背后的人性/心理（=A1–A3 结论）
              ↓
         产品功能（满足该人性的功能点）
              ↓
         产品属性（快/美/稳…可感知特性）
```
- 作用：把"心理需求"落成"可开发功能"，弥补只分析不落地。

### B3 用户故事 / Job Stories（需求表达）
- 「作为 <角色>，我想要 <功能>，以便 <JTBD 动机/心理需求>。」
- 可直接进 PRD。

### B4 KANO 模型（需求属性分类）
- 基本型（缺了流失）/ 期望型（越多越满意）/ 兴奋型（超预期）。
- 用于步骤 6 给需求空白标属性。

### B5 重要–满意矩阵（需求空白排序）
- 高重要 × 低满意 = 优先补；高重要 × 高满意 = 守成；低重要 = 暂缓。

### B6 RICE（量化优先级）
- RICE = Reach × Impact × Confidence ÷ Effort。

### B7 MoSCoW（快速分档）
- Must / Should / Could / Won't。

### B8 假设验证（让分析可证伪）
- 每条核心结论改写为假设 + 验证方法（如 JTBD 访谈 5–10 人）。

### B9 机会解决方案树 OST（Teresa Torres）
- 期望结果 → 机会 → 方案 → 实验。用于复杂需求的机会化。

### B10 痛点分析（Pain Point Analysis）
- 从"用户现在哪里痛"反推需求，与 A1"停用不适"同源互证。

---

## C. 产品大师方法论情报库（精选 · OSINT）

> 下列为产品大师的代表框架，按产品全生命周期分组，供深度需求/战略分析时取用。完整 50 条见情报报告。

### C1 产品战略
- **Jobs To Be Done**（Clayton Christensen）：从"任务"而非画像定义需求。
- **Product Vision Board**（Roman Pichler）：愿景/用户/需求/价值/功能对齐。
- **Product-Market Fit Pyramid**（Dan Olsen）：市场→用户→需求→价值→功能→UX 收敛。
- **Product Positioning / Obviously Awesome**（April Dunford）：六问定位法。
- **DHM Model**（Gibson Biddle）：Delight / Hard-to-copy / Margin-enhancing 三条件才是真战略。

### C2 需求分析
- **Opportunity Solution Tree**（Teresa Torres）：结果→机会→方案→实验。
- **Importance × Satisfaction**（Dan Olsen）：见 B5。
- **Kano**（见 B4）。

### C3 用户研究
- **Continuous Discovery Habits**（Teresa Torres）：每周与真实客户对话成节奏。
- **The Mom Test**（Rob Fitzpatrick）：访谈不问假问题，问具体行为。
- **Assumption Mapping**（David Bland）：按重要性×不确定性排假设，先测最高风险。

### C4 PRD / 需求表达
- **PRFAQ / Working Backwards**（Amazon）：先写新闻稿+FAQ，从客户视角反推。
- **User Story Mapping**（Jeff Patton）：活动→任务→故事，规划发布切片。

### C5 优先级排序
- **RICE**（见 B6）、**MoSCoW**（见 B7）、**WSJF**（SAFe：成本延迟÷规模）。
- **Four Big Risks**（Marty Cagan）：价值/可用/可行/商业可行，发现即去风险。
- **Now-Next-Later Roadmap**（Janna Bastow）：方向而非承诺日期。

### C6 敏捷执行 / 验证
- **Lean Startup / BML**（Eric Ries）：构建–度量–学习。
- **Dual-Track Agile**（Marty Cagan）：发现轨 + 交付轨并行。
- **Hooked Model**（Nir Eyal）：触发–行动–多变奖励–投入，设计习惯。

### C7 乔布斯产品方法论（认知放大器研究 · 可选启发）
- **Focus（做减法）**：每条新增需求须说明它替代/淘汰了什么。
- **从用户体验倒推技术**：先定"目标用户体验一句话"，再倒推功能。
- **端到端整合**：追问需求是否破坏整体体验一致性。
- **完美主义重启**：关键体验不达标时建议回退重做而非带病发布。
- 详见 `steve-jobs-cognitive-amplifier.md`（置信度均 ≥78%，6 条 🥇 一手证据）。

---

## E. 场景化最佳实践（按产品类型选用）

> 评测反馈：框架有说明但缺场景化指引。下列给"什么产品用哪套"的最小建议。

- **早期 / 单人创意产品**：走轻量模式 → 只判主导驱动力 + 1 条 Job Story + MoSCoW 分档 + 1 假设。
- **成熟 SaaS / 协作工具**（Notion、飞书）：完整 9 步，重点 SDT 关联感 + 竞争替代护城河。
- **社交 / 内容产品**（抖音、微信）：社会驱动为主，重点 JTBD 社会工作层 + Hooked Model 验证习惯。
- **电商 / 交易产品**：生存驱动（交易确定性）+ 竞争替代（信任壁垒），用 Four Big Risks 去风险。
- **做减法场景**（乔布斯式 Focus）：每加 1 需求，先答"它淘汰/替代了什么"，否则砍。
- **验证优先**：任何"未验证假设"上线前，至少用 The Mom Test 问 3–5 真实用户行为，不靠臆测。

---

## D. 使用纪律
- 不堆章节：只挂与本次分析相关的框架，避免 railroading。
- 置信度：每个外部框架引用若用于结论，须标证据等级（🥇一手 / 🥈权威二手 / ❓传闻）。
- 负向约束：见 SKILL.md「Gotchas / 错误台账」，运行中发现即追加。
