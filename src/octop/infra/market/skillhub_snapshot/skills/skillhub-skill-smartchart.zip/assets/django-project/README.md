# __PROJECT__

基于 SmartChart（Django）的项目骨架，由 smartchart skill 生成。

## 目录

| 路径 | 用途 |
|---|---|
| `manage.py` | Django 管理入口 |
| `__PROJECT__/` | 项目配置包（settings / urls / wsgi / asgi） |
| `__PROJECT__/settings.py` | 已挂好 `smart_chart.echart` / `oa` / `scheduler` 三个 app |
| `templates/` / `static/` / `media/` / `_files/` / `log/` | 运行时目录（已建好，日志目录必须存在，否则启动报错） |
| `requirements.txt` | 依赖：`smartchart>8.0` |
| `templates/diy/` | 仪表盘模板目录（平台按 `{仪表盘id}_{时间戳}.html` 存） |

## 启动

用系统 Python（多项目共用一份 smartchart，不建 venv）：

```bash
python manage.py runserver 0.0.0.0:8000 --insecure --noreload
# Windows 同理；python 不在 PATH 时用完整路径
```

访问 http://127.0.0.1:8000 ，管理员默认 `admin / admin`。

## 常用命令

```bash
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py collectstatic
```

## 注意

- `secret_key.txt` 首次启动自动生成，已加入 `.gitignore`，不要外传。
- 数据库默认 SQLite，落在项目根 `db.sqlite3`（每个项目各一份，互不干扰）；换 MySQL 改 `DATABASES` 即可。
- 仪表盘 HTML 同步到本项目时，模板写到 **项目根 `templates/diy/`**
  （不是包内目录），用 `local_dashboard.py --project <项目根> ...`。
- 大版本升级 smartchart 后如报 `no such column: xxx`，说明老库表结构与新版不一致，需重建库。
