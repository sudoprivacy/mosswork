#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把 Agent 生成的 HTML 同步到 SmartChart 的仪表盘。

两种目标，自动选择（也可用 --project 显式指定）:
  1. 项目模式：目录里有 manage.py → 用项目 python 跑 manage.py shell，
     库是项目根 db.sqlite3，模板目录是**项目根** templates/diy
  2. 本地实例模式：~/.smartchart/local 那份 → 用 venv 里的 smartchart CLI，
     模板目录在包内 templates/diy

模板目录都由 Django 侧 settings.BASE_DIR 算出，脚本不拼路径。

子命令:
  list                      列出仪表盘及其当前模板文件
  show <id>                 打印某个仪表盘的模板原文
  push <html> --id N        覆盖已有仪表盘的模板
  push <html> --new "名称"   先在库里建一条仪表盘记录，再写模板
  pull <id> -o file         导出平台上的模板（改之前先做这步）
  remove-template <id>      删掉自定义模板，回退到 common.html

用法:
  local_dashboard.py list                       # 自动选目标
  local_dashboard.py --project /path/to/proj list     # --project 须在子命令之前
  SMARTCHART_PROJECT=/path/to/proj local_dashboard.py list

三条硬规则（用户约定，别改回去）:
  1. push 不能直接落盘裸 HTML——先 wrap_as_template：源文件含 '{%' 则原样用，
     否则套 baselite.html 骨架（正文进 body block，最后一个 <script> 搬进 footer block）
  2. 改已有仪表盘时先 pull 出真实 HTML，在其基础上改，再 push 回去
  3. 推送目标必须核对名称 + 经用户确认（备份 ≠ 可以擅自覆盖）

存储规则（SmartChart 8.0.9 实测）:
  - 仪表盘记录: 表 echart_echartdashboardsetup_v2
  - 模板文件  : <BASE_DIR>/templates/diy/{仪表盘id}_{时间戳}.html
  - 写入沿用平台规则: 按 '{id}_' 前缀找到旧模板，写新的后删掉旧的
  - 改库/覆盖前先停服务，绝不在服务运行时动它的 sqlite
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HOME = Path.home()
BASE = Path(os.environ.get("SMARTCHART_LOCAL_HOME", str(HOME / ".smartchart" / "local")))
IS_WIN = os.name == "nt"
MARK = "SMTJSON "
PH = "__SMTMARK__"   # 占位符，注入前替换成 MARK
SUB = "diy"          # 模板所在的子目录


def log(msg):
    print(msg, flush=True)


def wrap_as_template(html):
    """按平台编辑器保存逻辑处理 HTML（与平台保存路径保持一致）。

    - 源文件里已含 '{%'（说明本身就是 Django 模板骨架）→ 原样使用，不再包装；
    - 否则套 `baselite.html` 骨架：正文进 body block，
      并把**最后一个** <script>…</script> 块搬进 footer block（平台用 rfind 取的）。

    除「搬最后一个 script」外不做任何转换：不拆 style、不改 script 内容、不动标签。
    """
    if '{%' in html:
        return html
    script = ''
    script_start = html.rfind('<script')
    script_end = html.rfind('</script>')
    if 0 <= script_start < script_end:
        script_end += len('</script>')
        script = html[script_start:script_end]
        html = html[:script_start] + html[script_end:]
    return ('{% extends "echart/baselite.html" %}\n{% block body %}' + html +
            '\n{% endblock %}\n{% block footer %}\n' + script + '\n{% endblock %}')


def venv_smartchart():
    bindir = BASE / "venv" / ("Scripts" if IS_WIN else "bin")
    return str(bindir / ("smartchart.exe" if IS_WIN else "smartchart"))


# ------------------------------------------------- 目标环境：项目 or 本地实例
def detect_project(start=None):
    """未显式指定时，从当前目录向上最多 3 层找 manage.py。"""
    p = Path(start or os.getcwd()).resolve()
    for _ in range(4):
        if (p / "manage.py").is_file():
            return p
        if p.parent == p:
            break
        p = p.parent
    return None


def pick_project_python(proj, explicit=None):
    """候选顺序：--python > .smartchart/project.json > 当前 python（系统那一份）。

    不建 venv：多项目共用系统里那一份 smartchart。逐个验证能否 import。
    """
    candidates = []
    if explicit:
        candidates.append(explicit)
    meta = proj / ".smartchart" / "project.json"
    if meta.is_file():
        try:
            candidates.append(json.loads(meta.read_text(encoding="utf-8"))["python"])
        except Exception:
            pass
    candidates.append(sys.executable)

    for c in candidates:
        if not c or (not Path(c).is_file() and shutil.which(c) is None):
            continue
        rc = subprocess.run([c, "-c", "import smart_chart, django"], cwd=str(proj),
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if rc.returncode == 0:
            return c
    return None


def resolve_env(project_dir=None, python=None):
    """决定 Django 执行入口。两种模式见文件头说明。"""
    proj = Path(project_dir).expanduser().resolve() if project_dir else detect_project()
    if proj:
        if not (proj / "manage.py").is_file():
            raise SystemExit("× %s 下没有 manage.py，不是 smartchart 项目目录" % proj)
        py = pick_project_python(proj, python)
        if not py:
            raise SystemExit(
                "× 找不到能 import smartchart 的解释器（已试：.smartchart/project.json、"
                "当前 python）。\n"
                "  装依赖：python -m pip install -r requirements.txt\n"
                "  或指定：--python /path/to/python（本机 SmartChart 实例那份："
                "~/.smartchart/local/venv/bin/python3）")
        return {"mode": "project", "root": proj, "cwd": str(proj), "python": py,
                "cmd": [py, "manage.py", "shell"],
                "backup": proj / ".smartchart" / "diy_backup"}

    exe = venv_smartchart()
    if not os.path.exists(exe):
        raise SystemExit("× 未找到 %s，请先执行 local_setup.py install；"
                         "或加 --project 指向用 init_project.py 生成的项目" % exe)
    return {"mode": "local", "root": None, "cwd": str(BASE),
            "cmd": [exe, "shell"], "backup": BASE / "diy_backup"}


_ENV = None


def get_env(project_dir=None, python=None):
    """解析一次并缓存；project_dir 支持命令行或环境变量 SMARTCHART_PROJECT。"""
    global _ENV
    if _ENV is None:
        _ENV = resolve_env(project_dir or os.environ.get("SMARTCHART_PROJECT"), python)
    return _ENV


def env_label(env=None):
    env = env or get_env()
    if env["mode"] == "project":
        return "项目模式  根目录: %s" % env["root"]
    return "本地实例模式  ~/.smartchart/local"


# ------------------------------------------------- 在 Django 环境里执行代码
def dj_replace(tpl, **kv):
    """模板串里含 Django 语法与 % 格式化，统一用占位符替换。"""
    out = tpl.replace(PH, MARK)
    for k, v in kv.items():
        out = out.replace("__%s__" % k, str(v))
    return out


CODE_PATHS = """
import json, os
from django.conf import settings
print("__SMTMARK__" + json.dumps({
    "diy": os.path.join(str(settings.BASE_DIR), "templates", "__SUB__"),
}))
"""

CODE_LIST = """
import json
from smart_chart.echart.models import EchartDashboardSetup_v2
rows = []
for o in EchartDashboardSetup_v2.objects.all().order_by("id"):
    rows.append({
        "id": o.id, "name": o.name, "remark": o.remark,
        "project": o.project_name_id, "conn": o.conn_id,
        "tags": o.tags, "parent": o.parent_dashboard_id,
        "update": str(o.update_time),
    })
print("__SMTMARK__" + json.dumps({"rows": rows}))
"""

CODE_CREATE = """
import json
from smart_chart.echart.models import EchartDashboardSetup_v2
kw = {"name": __NAME__, "remark": __REMARK__, "tags": __TAGS__}
if __PROJECT__:
    kw["project_name_id"] = __PROJECT__
if __CONN__:
    kw["conn_id"] = __CONN__
try:
    o = EchartDashboardSetup_v2.objects.create(**kw)
    print("__SMTMARK__" + json.dumps({"id": o.id, "name": o.name}))
except Exception as e:
    print("__SMTMARK__" + json.dumps({"error": "%s: %s" % (type(e).__name__, e)}))
"""

# 读 / 写 / 删模板；内容通过临时文件中转，避免超长字符串进命令行
CODE_READ = """
import json, os
from django.conf import settings
did = __DID__
base = os.path.join(str(settings.BASE_DIR), "templates", "__SUB__")
hit = ""
if os.path.isdir(base):
    names = sorted(n for n in os.listdir(base) if n.startswith(str(did) + "_"))
    if names:
        hit = names[-1]
content = ""
if hit:
    with open(os.path.join(base, hit), encoding="utf-8") as f:
        content = f.read()
print("__SMTMARK__" + json.dumps({"dir": base, "file": hit, "content": content}))
"""

CODE_WRITE = """
import json, os, time
from django.conf import settings
from smart_chart.echart.models import EchartDashboardSetup_v2
did = __DID__
src = __SRC__
base = os.path.join(str(settings.BASE_DIR), "templates", "__SUB__")
os.makedirs(base, exist_ok=True)
content = open(src, encoding="utf-8").read()

prefix = str(did) + "_"
old = sorted(n for n in os.listdir(base) if n.startswith(prefix))
while True:
    new_name = prefix + ("%.6f" % time.time()) + ".html"
    if new_name not in old:
        break
with open(os.path.join(base, new_name), "w", encoding="utf-8") as f:
    f.write(content)
removed = []
for n in old:
    try:
        os.remove(os.path.join(base, n))
        removed.append(n)
    except Exception:
        pass

# touch 一下，让列表页 update_time 变动（该字段是 auto_now）
touched = False
try:
    EchartDashboardSetup_v2.objects.get(id=did).save()
    touched = True
except Exception:
    pass
print("__SMTMARK__" + json.dumps({
    "dir": base, "file": new_name, "removed": removed,
    "touched": touched, "bytes": len(content.encode("utf-8")),
}))
"""

CODE_REMOVE_TPL = """
import json, os
from django.conf import settings
did = __DID__
base = os.path.join(str(settings.BASE_DIR), "templates", "__SUB__")
removed = []
if os.path.isdir(base):
    for n in sorted(n for n in os.listdir(base) if n.startswith(str(did) + "_")):
        os.remove(os.path.join(base, n))
        removed.append(n)
print("__SMTMARK__" + json.dumps({"removed": removed}))
"""


def dj(code, timeout=180, env=None):
    env = env or get_env()
    fd, path = tempfile.mkstemp(suffix=".py", prefix="smt_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(dj_replace(code, SUB=SUB))
        with open(path, encoding="utf-8") as f:
            proc = subprocess.run(env["cmd"], stdin=f, cwd=env["cwd"],
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                  text=True, timeout=timeout)
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    return proc.stdout or ""


def dj_json(code, timeout=180):
    """执行并返回结构化数据；失败返回 {"error": ...}。"""
    out = dj(code, timeout)
    for line in out.splitlines():
        s = line.strip()
        if s.startswith(MARK):
            try:
                return json.loads(s[len(MARK):])
            except Exception as e:
                return {"error": "解析返回失败: %s" % e}
    tail = "\n".join(out.splitlines()[-6:])
    return {"error": "未拿到结构化返回，输出尾部：\n" + tail}


def get_diy_dir():
    r = dj_json(dj_replace(CODE_PATHS, SUB=SUB))
    if "error" in r:
        raise SystemExit("× 无法定位模板目录：" + r["error"])
    return Path(r["diy"])


def find_template(diy, dash_id):
    """返回该仪表盘当前生效的模板文件名，没有则 ''。"""
    if not Path(diy).is_dir():
        return ""
    hits = sorted(p.name for p in Path(diy).glob("%d_*" % dash_id))
    return hits[-1] if hits else ""


# ------------------------------------------------- 子命令
def cmd_list(args):
    env = get_env(getattr(args, "project", None))
    diy = get_diy_dir()
    r = dj_json(CODE_LIST)
    if "error" in r:
        log("× 查询失败：" + r["error"])
        return 1
    rows = r.get("rows", [])
    if not rows:
        log("模板目录: %s" % diy)
        log("还没有仪表盘。可用 push --new 创建。")
        return 0
    log("模板目录: %s" % diy)
    log("")
    log("%-4s %-24s %-7s %-7s %s" % ("ID", "名称", "项目", "数据源", "当前模板文件"))
    log("-" * 78)
    for row in rows:
        hit = find_template(diy, row["id"])
        log("%-4s %-24s %-7s %-7s %s" % (
            row["id"], row["name"][:24], row["project"] or "-", row["conn"] or "-",
            hit if hit else "(无，回退 common.html)"))
    log("")
    log("改已有仪表盘前先:  pull <id> -o /tmp/xxx.html   拿真实内容再改，不要凭空重写。")
    return 0


def cmd_show(args):
    r = dj_json(dj_replace(CODE_READ, DID=args.id))
    if "error" in r:
        log("× 读取失败：" + r["error"])
        return 1
    if not r.get("file"):
        log("仪表盘 %d 暂无自定义模板，当前使用 common.html" % args.id)
        return 0
    log("# 文件: %s/%s" % (r["dir"], r["file"]))
    log("-" * 60)
    log(r.get("content", ""))
    return 0


def cmd_pull(args):
    """原样导出平台上的模板，供在其基础上修改。"""
    r = dj_json(dj_replace(CODE_READ, DID=args.id))
    if "error" in r:
        log("× 导出失败：" + r["error"])
        return 1
    if not r.get("file"):
        log("× 仪表盘 %d 没有自定义模板（还在用 common.html），无法导出。" % args.id)
        return 1
    text = r["content"]
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        log("√ 已原样导出: %s -> %s（%d 字符）" % (r["file"], args.out, len(text)))
        log("  改完用: push %s --id %d 写回。" % (args.out, args.id))
    else:
        log(text)
    return 0


def cmd_push(args):
    src = Path(args.html)
    if not src.is_file():
        log("× 找不到文件: %s" % src)
        return 1
    dash_id = args.id

    if dash_id is None:
        if not args.new:
            log("× 请二选一: --id <已有仪表盘>  或  --new <新建名称>")
            return 1
        r = dj_json(dj_replace(CODE_CREATE,
                               NAME=repr(args.new),
                               REMARK=repr(args.remark or ""),
                               TAGS=repr(args.tags or ""),
                               PROJECT=args.proj_id or "None",
                               CONN=args.conn or "None"))
        if "error" in r:
            log("× 创建仪表盘失败：" + r["error"])
            return 1
        dash_id = r["id"]
        log("√ 已创建仪表盘 id=%s  name=%s" % (dash_id, r["name"]))

    diy = get_diy_dir()
    if args.id is not None and diy.is_dir():
        olds = sorted(diy.glob("%d_*" % dash_id))
        if olds and not args.no_backup:
            bak = get_env(getattr(args, "project", None))["backup"]
            bak.mkdir(parents=True, exist_ok=True)
            for p in olds:
                shutil.copy2(p, bak / ("%s.%s" % (p.name, time.strftime("%Y%m%d-%H%M%S"))))
            log("√ 已备份旧模板 %d 个 -> %s" % (len(olds), bak))
        elif olds:
            log("! 该仪表盘已有模板将被覆盖: %s" % ", ".join(p.name for p in olds))

    # 按平台保存逻辑套骨架（无 '{%' 时才套），内容本身原样保留。
    # Django 进程通过临时文件路径读取内容。
    raw = src.read_text(encoding="utf-8")
    content = wrap_as_template(raw)
    tmp = tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, encoding="utf-8")
    try:
        tmp.write(content)
        tmp.close()
        r = dj_json(dj_replace(CODE_WRITE, DID=dash_id, SRC=repr(tmp.name)))
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass

    if "error" in r:
        log("× 写入模板失败：" + r["error"])
        return 1
    log("√ 已原样写入: %s/%s（%s 字节）" % (r["dir"], r["file"], r.get("bytes", "?")))
    if r.get("removed"):
        log("  已清理旧模板: %s" % ", ".join(r["removed"]))
    if not r.get("touched"):
        log("  ! 未能 touch 仪表盘记录（id 可能不存在），列表页更新时间可能不变")
    log("")
    log("仪表盘 id=%s 已更新，浏览器强制刷新即可。" % dash_id)
    return 0


def cmd_remove_template(args):
    r = dj_json(dj_replace(CODE_REMOVE_TPL, DID=args.id))
    if "error" in r:
        log("× 失败：" + r["error"])
        return 1
    removed = r.get("removed") or []
    if removed:
        log("√ 已删除 %s，该仪表盘回退到 common.html" % ", ".join(removed))
    else:
        log("仪表盘 %d 本来就没有自定义模板" % args.id)
    return 0


def build_parser():
    p = argparse.ArgumentParser(
        description="SmartChart 仪表盘 HTML 同步（push 前按平台规则套骨架，其余原样）")
    p.add_argument("--project", help="smartchart 项目根目录（含 manage.py）；"
                                     "不给则自动探测当前目录，再回退本地实例")
    p.add_argument("--python", help="项目模式下指定解释器（默认：项目 .venv / project.json）")
    sub = p.add_subparsers(dest="cmd")

    ls = sub.add_parser("list", help="列出仪表盘及当前模板文件")
    ls.set_defaults(func=cmd_list)

    sh = sub.add_parser("show", help="打印模板原文")
    sh.add_argument("id", type=int)
    sh.set_defaults(func=cmd_show)

    ps = sub.add_parser("push", help="写入仪表盘模板（裸 HTML 自动套骨架）")
    ps.add_argument("html", help="本地 HTML 文件路径")
    ps.add_argument("--id", type=int, help="覆盖已有仪表盘")
    ps.add_argument("--new", help="新建仪表盘并指定名称（需唯一）")
    ps.add_argument("--remark", default="")
    ps.add_argument("--tags", default="", help="逗号分割")
    ps.add_argument("--proj-id", type=int, help="仪表盘归属的 SmartChart 项目 id（库里的分组，不是目录）")
    ps.add_argument("--conn", type=int, help="默认数据源 id")
    ps.add_argument("--no-backup", action="store_true", help="覆盖前不备份旧模板")
    ps.set_defaults(func=cmd_push)

    pl = sub.add_parser("pull", help="原样导出模板（改之前先做这步）")
    pl.add_argument("id", type=int)
    pl.add_argument("-o", "--out", help="输出文件")
    pl.set_defaults(func=cmd_pull)

    rm = sub.add_parser("remove-template", help="删除自定义模板，回退 common.html")
    rm.add_argument("id", type=int)
    rm.set_defaults(func=cmd_remove_template)

    return p


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not getattr(args, "cmd", None):
        parser.print_help()
        return 0
    try:
        env = get_env(getattr(args, "project", None), getattr(args, "python", None))
        log("目标: %s" % env_label(env))
        return args.func(args)
    except KeyboardInterrupt:
        log("\n已中断")
        return 130
    except Exception as e:
        log("× 错误: %s" % e)
        return 1


if __name__ == "__main__":
    sys.exit(main())
