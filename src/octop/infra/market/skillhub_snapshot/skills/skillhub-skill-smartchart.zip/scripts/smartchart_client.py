#!/usr/bin/env python3
"""
SmartChart 数据服务 API 客户端

零第三方依赖：仅使用 Python 标准库（urllib / hashlib / json），
因此可在任意安装了 Python 3 的机器上直接运行，无需 pip install。

用法（SCRIPT 为本脚本路径，PY 为 python3）:
    # 配置与数据集管理
    {PY} {SCRIPT} ping
    {PY} {SCRIPT} list-datasets
    {PY} {SCRIPT} add-dataset --id 123 --name "销售数据" --desc "查询销售" --operation query
    {PY} {SCRIPT} remove-dataset --id 123

    # 数据操作
    {PY} {SCRIPT} query --dataset 123 --param '{"key":"val"}'
    {PY} {SCRIPT} query-post --dataset 123 --pagesize 100 --pg 1
    {PY} {SCRIPT} write --dataset 123 --ds '[["A","B"],["a1","b1"]]'
    {PY} {SCRIPT} update --dataset 123 --ds '[{"id":1,"name":"x"}]'
    {PY} {SCRIPT} upload --type 配置名 --file /path/to/file.xlsx

    # 模块方式
    from smartchart_client import SmartChartClient
    client = SmartChartClient()  # 默认读取 ~/.smartchart/config.json，可传路径覆盖
    result = client.query(dataset_id=123)
"""

import argparse
import csv
import hashlib
import json
import os
import re
import sys
import time
import zipfile
from urllib import error as urllib_error
from urllib import parse as urllib_parse
from urllib import request as urllib_request


def resolve_path(explicit_path, filename):
    """
    解析配置/注册表路径，优先级：显式指定 > 项目级(.smartchart/) > 用户级(~/.smartchart/)。

    用户级目录位于家目录下，跨项目共享且不会随项目提交到 git。
    """
    if explicit_path:
        return explicit_path if os.path.isabs(explicit_path) else os.path.join(os.getcwd(), explicit_path)
    project_path = os.path.join(os.getcwd(), ".smartchart", filename)
    if os.path.exists(project_path):
        return project_path
    return os.path.join(os.path.expanduser("~"), ".smartchart", filename)


def _http_get(url, params):
    """标准库 GET 请求，返回 (status_code, json_dict)。"""
    query = urllib_parse.urlencode(params, safe="", quote_via=urllib_parse.quote)
    full_url = f"{url}?{query}"
    req = urllib_request.Request(full_url, method="GET")
    try:
        with urllib_request.urlopen(req, timeout=15) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib_error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8"))
        except Exception:
            return e.code, {"status": e.code, "msg": f"HTTP 错误 {e.code}"}
    except urllib_error.URLError as e:
        raise ConnectionError(str(e.reason))


def _http_post_form(url, data):
    """标准库表单 POST（application/x-www-form-urlencoded），返回 json_dict。"""
    body = urllib_parse.urlencode(data, safe="", quote_via=urllib_parse.quote).encode("utf-8")
    req = urllib_request.Request(
        url, data=body, method="POST",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib_request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib_error.HTTPError as e:
        try:
            return json.loads(e.read().decode("utf-8"))
        except Exception:
            return {"status": e.code, "msg": f"HTTP 错误 {e.code}"}
    except urllib_error.URLError as e:
        raise ConnectionError(str(e.reason))


def _http_post_multipart(url, fields, file_path=None):
    """
    标准库 multipart/form-data POST，支持可选文件上传。
    fields: dict，普通表单字段；file_path: 可选本地文件路径。
    """
    boundary = "----smartchart_multipart_boundary_7Q2x"
    parts = []
    for key, val in fields.items():
        parts.append(
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{key}"\r\n\r\n'
            f"{val}\r\n".encode("utf-8")
        )
    if file_path and os.path.exists(file_path):
        filename = os.path.basename(file_path)
        with open(file_path, "rb") as f:
            filedata = f.read()
        parts.append(
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
            f"Content-Type: application/octet-stream\r\n\r\n".encode("utf-8")
            + filedata
            + b"\r\n"
        )
    body = b"".join(parts) + f"--{boundary}--\r\n".encode("utf-8")
    req = urllib_request.Request(
        url, data=body, method="POST",
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    try:
        with urllib_request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib_error.HTTPError as e:
        if e.code == 504:
            return {"result": "timeout", "data": "处理超时，请等待邮件通知结果"}
        try:
            return json.loads(e.read().decode("utf-8"))
        except Exception:
            return {"result": "error", "data": f"请求失败，状态码: {e.code}"}
    except urllib_error.URLError as e:
        raise ConnectionError(str(e.reason))


class SmartChartClient:
    """SmartChart 数据服务 API 客户端"""

    def __init__(self, config_path=None):
        """
        初始化客户端，从配置文件加载连接信息。

        路径解析优先级：显式指定 > 项目级(.smartchart/config.json) > 用户级(~/.smartchart/config.json)。

        Args:
            config_path: 配置文件路径，默认自动查找用户级/项目级配置
        """
        config_file = resolve_path(config_path, "config.json")
        if not os.path.exists(config_file):
            raise FileNotFoundError(
                f"配置文件不存在: {config_file}\n"
                f"请创建配置文件，格式如下:\n"
                f'{{"base_url": "http://localhost:8000", "visitor": "your_username", "secret_key": "your_secret_key"}}'
                f'\n用户级默认路径: ~/.smartchart/config.json（跨项目共享）'
            )
        with open(config_file, "r", encoding="utf-8") as f:
            config = json.load(f)

        self.base_url = config["base_url"].rstrip("/")
        self.visitor = config["visitor"]
        self.secret_key = config["secret_key"]

    def ping(self):
        """
        测试与 SmartChart 服务器的连通性。

        Returns:
            dict: {"status": 200, "msg": "连接成功"} 或 {"status": 403/500, "msg": "错误信息"}
        """
        url = f"{self.base_url}/echart/dataset_api/"
        token, stamp = self._generate_token("ping")
        params = {
            "visitor": self.visitor,
            "token": token,
            "type": "ping",
            "stamp": stamp,
        }
        try:
            status, _ = _http_get(url, params)
            if status == 200:
                return {"status": 200, "msg": f"连接成功 ({self.base_url})"}
            elif status == 403:
                return {"status": 403, "msg": "认证失败，请检查 visitor 和 secret_key"}
            else:
                return {"status": status, "msg": f"服务器返回状态码: {status}"}
        except ConnectionError as e:
            return {"status": 500, "msg": f"无法连接到 {self.base_url}，请检查地址: {e}"}
        except Exception as e:
            return {"status": 500, "msg": f"连接失败: {e}"}

    def _generate_token(self, dataset_id):
        """生成 SHA1 签名 token"""
        stamp = int(time.time() * 1000)
        raw = f"{self.secret_key}{stamp}{self.visitor}{dataset_id}"
        token = hashlib.sha1(raw.encode("utf-8")).hexdigest()
        return token, stamp

    def query(self, dataset_id, param=None, pagesize=None, pg=None):
        """
        GET 方式查询数据（推荐，查询一律优先使用）。

        Args:
            dataset_id: 数据集 ID
            param: 查询参数字典，如 {"参数A": "值"}
            pagesize: 每页数据条数。传入后（需同时传 pg）启用后端分页：
                由数据库 count+LIMIT/OFFSET 完成分页，不缓存全量数据，
                每页 data 均含表头，total 为数据总行数
            pg: 页码，从 1 开始

        Returns:
            dict: 不分页时 {"data": [[表头...], [行1...], ...], "result": "success", "maxpg": 1, "pg": 1}
                  分页时 {"data": [...], "status": 200, "msg": "success", "maxpg": N, "pg": N, "total": N}
        """
        token, stamp = self._generate_token(dataset_id)
        url = f"{self.base_url}/echart/dataset_api/"
        params = {
            "visitor": self.visitor,
            "token": token,
            "type": dataset_id,
            "stamp": stamp,
        }
        if pagesize:
            params["pagesize"] = pagesize
            params["pg"] = pg or 1
        if param:
            params["param"] = json.dumps(param, ensure_ascii=False)
        try:
            return _http_get(url, params)[1]
        except ConnectionError as e:
            return {"result": "error", "msg": str(e)}

    def query_post(self, dataset_id, pagesize=None, pg=1, param=None):
        """
        POST 方式查询数据（适用于后台定时同步数据，日常查询请用 GET 的 query）。

        Args:
            dataset_id: 数据集 ID
            pagesize: 每页数据条数。传入后（需同时传 pg）启用后端分页：
                由数据库 count+LIMIT/OFFSET 完成分页，不缓存全量数据，
                每页 data 均含表头，total 为数据总行数
            pg: 页码，从 1 开始
            param: 查询参数字典

        Returns:
            dict: 分页时 {"data": [...], "status": 200, "msg": "success", "maxpg": N, "pg": N, "total": N}
                  不传 pagesize 时返回全量数据（带缓存），行为与 GET 请求一致
        """
        token, stamp = self._generate_token(dataset_id)
        url = f"{self.base_url}/echart/dataset_api/"
        data = {
            "visitor": self.visitor,
            "token": token,
            "stamp": stamp,
            "type": dataset_id,
        }
        if pagesize:
            data["pagesize"] = pagesize
            data["pg"] = pg or 1
        if param:
            data["param"] = json.dumps(param, ensure_ascii=False)
        try:
            return _http_post_form(url, data)
        except ConnectionError as e:
            return {"result": "error", "msg": str(e)}

    def write(self, dataset_id, ds, update=0):
        """
        写入数据到 SmartChart。

        Args:
            dataset_id: 数据集 ID（对应懒加载数据集序号）
            ds: 数据内容，支持以下格式:
                - 二维数组: [["字段A","字段B"],["值1","值2"]]
                - 单行字典: [{"id": 1, "name": "john"}]
                - 单行数组: ["a", "b"]
            update: 操作类型，0=新增，1=更新（按主键）

        Returns:
            dict: {"status": 200, "msg": "success"}
        """
        token, stamp = self._generate_token(dataset_id)
        url = f"{self.base_url}/echart/dataset_api/"
        data = {
            "visitor": self.visitor,
            "token": token,
            "stamp": stamp,
            "type": dataset_id,
            "ds": json.dumps(ds, ensure_ascii=False),
            "update": update,
        }
        try:
            return _http_post_form(url, data)
        except ConnectionError as e:
            return {"result": "error", "msg": str(e)}

    def update(self, dataset_id, ds):
        """
        按主键更新数据（write 的快捷方式，update=1）。

        Args:
            dataset_id: 数据集 ID
            ds: 数据内容，需包含主键字段

        Returns:
            dict: {"status": 200, "msg": "success"}
        """
        return self.write(dataset_id, ds, update=1)

    def upload_file(self, upload_type, file_path, mail=None, filename=None):
        """
        上传文件到 SmartChart。

        Args:
            upload_type: 上传配置名称（在"数据管道->上传配置"中设定）
            file_path: 本地文件路径
            mail: 可选，上传完成后发送结果邮件，多收件人用逗号分隔
            filename: 可选，指定则仅重新处理已上传的文件，不重新上传

        Returns:
            dict: {"data": "消息", "result": "success" 或 "error"}
        """
        token, stamp = self._generate_token(upload_type)
        url = f"{self.base_url}/etl/api/upload_file_api/"
        fields = {
            "visitor": self.visitor,
            "token": token,
            "stamp": stamp,
            "type": upload_type,
        }
        if mail:
            fields["mail"] = mail
        if filename:
            fields["filename"] = filename

        if not os.path.exists(file_path) and not filename:
            raise FileNotFoundError(f"文件不存在: {file_path}")

        try:
            return _http_post_multipart(url, fields, file_path=file_path if os.path.exists(file_path) else None)
        except ConnectionError as e:
            return {"result": "error", "data": str(e)}

    def ask(self, dataset_id, prompt, param=None):
        """
        智能问数 / 路由型数据集专用流程。

        某些数据集（如「智能问数」）本身不直接返回数据，而是返回一个路由指令：
        其 data.msg 是一段内嵌 JSON 字符串，形如
            {"tool":"askdata","msg":"查询...","param":{"table":"","name":""}}
        其中：
            - tool  ：真实数据集名称（下一步要调用的数据集）
            - msg   ：原自然语言提示词，转为下一步的 prompt 参数
            - param ：附加查询参数（如 table/name），非空值会一并带入

        本方法自动完成：第一次调用路由数据集 → 解析路由指令 → 第二次调用
        真实数据集并返回其结果。

        Args:
            dataset_id: 路由数据集 ID（如「智能问数」）
            prompt: 自然语言查询提示词
            param: 附加参数（可选），会与 prompt 合并后传给第一次调用

        Returns:
            dict: 第二次调用（真实数据集）的结果；若第一步失败、或解析不到路由指令，则返回第一步结果
        """
        # 第一次：调用路由数据集
        first_param = {"prompt": prompt}
        if param:
            first_param.update(param)
        first = self.query(dataset_id, param=first_param)
        if first.get("result") != "success":
            return first

        # 解析路由指令（data.msg 是内嵌 JSON 字符串）
        data = first.get("data")
        msg_raw = data.get("msg") if isinstance(data, dict) else None
        if not msg_raw or not isinstance(msg_raw, str):
            return first  # 无路由指令，直接返回（可能已是最终数据）

        try:
            route = json.loads(msg_raw)
        except (json.JSONDecodeError, TypeError):
            return first

        tool = route.get("tool")
        if not tool:
            return first

        # 组合第二步参数：prompt 必带，param 中的非空值一并带入（过滤空值避免干扰查询）
        second_param = {"prompt": route.get("msg") or prompt}
        extra = route.get("param") or {}
        if isinstance(extra, dict):
            for k, v in extra.items():
                if v not in (None, ""):
                    second_param[k] = v

        # 第二次：调用真实数据集
        return self.query(tool, param=second_param)


class DatasetRegistry:
    """数据集注册表管理"""

    def __init__(self, registry_path=None):
        # 路径解析优先级：显式指定 > 项目级(.smartchart/datasets.json) > 用户级(~/.smartchart/datasets.json)
        self.path = resolve_path(registry_path, "datasets.json")

    def _load(self):
        if not os.path.exists(self.path):
            return {"datasets": []}
        with open(self.path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _save(self, data):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def list_datasets(self):
        """列出所有已注册的数据集"""
        registry = self._load()
        datasets = registry.get("datasets", [])
        if not datasets:
            print("尚未注册任何数据集")
            print(f"注册表路径: {self.path}")
            return
        print(f"已注册 {len(datasets)} 个数据集:")
        print("-" * 60)
        for ds in datasets:
            op_label = {"query": "查询", "write": "写入", "update": "更新", "upload": "上传"}.get(ds.get("operation", ""), ds.get("operation", ""))
            print(f"  ID: {ds['id']:<10} | {ds['name']:<15} | [{op_label}]")
            print(f"             描述: {ds.get('description', '无')}")
            if ds.get("params"):
                print(f"             参数: {', '.join(ds['params'].keys())}")
            if ds.get("fields"):
                print(f"             字段: {', '.join(ds['fields'])}")
            if ds.get("notes"):
                print(f"             备注: {ds['notes']}")
            print()

    def add_dataset(self, ds_id, name, description, operation, params=None, fields=None, notes=None):
        """注册新数据集"""
        registry = self._load()
        for i, ds in enumerate(registry["datasets"]):
            if str(ds["id"]) == str(ds_id):
                registry["datasets"][i] = self._build_entry(ds_id, name, description, operation, params, fields, notes)
                self._save(registry)
                print(f"已更新数据集 [{ds_id}] {name}")
                return
        registry["datasets"].append(self._build_entry(ds_id, name, description, operation, params, fields, notes))
        self._save(registry)
        print(f"已注册数据集 [{ds_id}] {name}")

    def remove_dataset(self, ds_id):
        """删除数据集"""
        registry = self._load()
        before = len(registry["datasets"])
        registry["datasets"] = [ds for ds in registry["datasets"] if str(ds["id"]) != str(ds_id)]
        if len(registry["datasets"]) < before:
            self._save(registry)
            print(f"已删除数据集 [{ds_id}]")
        else:
            print(f"未找到数据集 [{ds_id}]")

    @staticmethod
    def _build_entry(ds_id, name, description, operation, params, fields, notes):
        entry = {
            "id": ds_id,
            "name": name,
            "description": description,
            "operation": operation,
        }
        if params:
            entry["params"] = params if isinstance(params, dict) else json.loads(params)
        if fields:
            entry["fields"] = fields if isinstance(fields, list) else json.loads(fields)
        if notes:
            entry["notes"] = notes
        return entry


def _extract_rows(result):
    """从 API 返回结果中提取二维表格数据（兼容多种返回结构）。"""
    if not isinstance(result, dict):
        return None
    data = result.get("data")
    # 情况1：data 直接是二维数组
    if isinstance(data, list) and data and isinstance(data[0], list):
        return data
    # 情况2：data 是 dict，msg 字段是二维数组（GET / ask 常见形态）
    if isinstance(data, dict):
        msg = data.get("msg")
        if isinstance(msg, list) and msg and isinstance(msg[0], list):
            return msg
    return None


def _estimate_chars(rows):
    """估算二维数据的字符总量，用于判断是否需要落盘。"""
    return sum(len(str(c)) for r in rows for c in r)


def _write_xlsx(rows, path):
    """
    纯标准库生成最小可打开的 .xlsx（inlineStr 内联字符串，无需 openpyxl）。
    生成结果可被 Excel / WPS / openpyxl / pandas 正常打开。
    """
    def esc(s):
        return (str(s).replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace('"', "&quot;"))

    body = []
    for r in rows:
        cells = "".join(
            f'<c t="inlineStr"><is><t xml:space="preserve">{esc(c)}</t></is></c>'
            for c in r
        )
        body.append(f"<row>{cells}</row>")

    sheet = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
             f'<sheetData>{"".join(body)}</sheetData></worksheet>')

    content_types = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                     '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                     '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                     '<Default Extension="xml" ContentType="application/xml"/>'
                     '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                     '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                     '</Types>')

    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            '</Relationships>')

    workbook = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>')

    wb_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
               '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
               '</Relationships>')

    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("xl/workbook.xml", workbook)
        z.writestr("xl/_rels/workbook.xml.rels", wb_rels)
        z.writestr("xl/worksheets/sheet1.xml", sheet)


def _save_result(rows, fmt, path):
    """将二维数据保存为指定格式文件（标准库实现，零第三方依赖）。"""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    if fmt == "csv":
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f).writerows(rows)
    elif fmt == "tsv":
        with open(path, "w", encoding="utf-8-sig") as f:
            for r in rows:
                f.write("\t".join(str(c) for c in r) + "\n")
    elif fmt == "json":
        with open(path, "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=2)
    elif fmt == "xlsx":
        _write_xlsx(rows, path)
    else:
        raise ValueError(f"不支持的格式: {fmt}")


def _auto_path(fmt, name=None):
    """
    生成默认落盘路径：<工作空间>/smartchart_results/<名称>_<时间戳>.<fmt>

    默认落在当前工作目录（cwd，即 Agent 工作空间）下的 smartchart_results/，
    与具体项目绑定，便于用户直接查看、分析或提交；不写死用户级公共目录。
    可用 --save /path/to/file 显式覆盖。
    """
    d = os.path.join(os.getcwd(), "smartchart_results")
    os.makedirs(d, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    safe = re.sub(r"[^\w一-龥-]", "_", str(name or "result"))[:40]
    return os.path.join(d, f"{safe}_{ts}.{fmt}")


def _print_small(rows):
    """打印小数据全量（最多 20 行）。"""
    header = rows[0]
    print(f"表头: {header}")
    print(f"数据行数: {len(rows) - 1}")
    print("---")
    for i, row in enumerate(rows):
        if i > 20:
            print(f"... 共 {len(rows)} 行，已显示前 20 行")
            break
        print(row)


def _print_result(result, save=False, fmt="csv", threshold=100,
                  force_full=False, no_save=False, name=None):
    """
    输出查询结果。

    大数据保护：当数据行数或估算字符数超过阈值时，默认自动落盘，
    仅打印「摘要 + 文件路径」，避免把全量数据塞进对话上下文。

    Args:
        save:      True=自动存默认路径；或传具体文件路径字符串
        fmt:       落盘格式 csv/json/tsv/xlsx（默认 csv）
        threshold: 自动落盘行数阈值（默认 100）
        force_full:强制打印全量（覆盖自动落盘）
        no_save:   禁用自动落盘
        name:      用于生成默认文件名的数据集名
    """
    rows = _extract_rows(result)

    # 非表格型结果（错误 / 状态信息等）原样打印
    if rows is None:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    header = rows[0]
    nrows = len(rows) - 1
    ncols = len(header)
    big = nrows > threshold or _estimate_chars(rows) > 20000

    do_save = bool(save) or (big and not no_save and not force_full)
    if do_save:
        path = save if isinstance(save, str) else _auto_path(fmt, name)
        try:
            _save_result(rows, fmt, path)
        except Exception as e:
            print(f"[落盘失败] {e}")
            _print_small(rows)
            return
        print(f"[数据已保存] {path}")
        print(f"  格式: {fmt}  行数: {nrows}  列数: {ncols}")
        print(f"  表头: {header}")
        print(f"  前3行预览: {rows[1:4]}")
        print("  (数据量较大，已落盘为文件；后续分析请直接读取该文件，"
              "不要将全量数据复制到对话中)")
        return

    # 小数据：打印全量
    _print_small(rows)


def main():
    parser = argparse.ArgumentParser(description="SmartChart 数据服务 API 客户端")
    parser.add_argument("--config", default=None, help="配置文件路径（默认: ~/.smartchart/config.json，项目级 .smartchart/config.json 可覆盖）")
    parser.add_argument("--datasets", default=None, help="数据集注册表路径（默认: ~/.smartchart/datasets.json，项目级可覆盖）")

    subparsers = parser.add_subparsers(dest="action", help="操作类型")

    # ping
    subparsers.add_parser("ping", help="测试与 SmartChart 服务器的连通性")

    # list-datasets
    subparsers.add_parser("list-datasets", help="列出已注册的数据集")

    # add-dataset
    p_add = subparsers.add_parser("add-dataset", help="注册新数据集")
    p_add.add_argument("--id", required=True, help="数据集 ID")
    p_add.add_argument("--name", required=True, help="数据集名称")
    p_add.add_argument("--desc", required=True, help="数据集描述")
    p_add.add_argument("--operation", required=True, choices=["query", "write", "update", "upload"], help="操作类型")
    p_add.add_argument("--params", default=None, help='参数 JSON，如 \'{"year":"年份","region":"区域"}\'')
    p_add.add_argument("--fields", default=None, help='字段列表 JSON，如 \'["字段A","字段B"]\'')
    p_add.add_argument("--notes", default=None, help="备注说明")

    # remove-dataset
    p_rm = subparsers.add_parser("remove-dataset", help="删除已注册的数据集")
    p_rm.add_argument("--id", required=True, help="数据集 ID")

    # query (GET, 推荐，支持分页)
    p_query = subparsers.add_parser("query", help="GET 方式查询数据（推荐，支持分页）")
    p_query.add_argument("--dataset", required=True, help="数据集 ID")
    p_query.add_argument("--param", default=None, help="查询参数 JSON 字符串")
    p_query.add_argument("--pagesize", type=int, default=None, help="每页条数（传入后启用后端分页，需配合 --pg）")
    p_query.add_argument("--pg", type=int, default=1, help="页码，从 1 开始")

    # query-post (POST, 适用于后台定时同步)
    p_qpost = subparsers.add_parser("query-post", help="POST 方式查询数据（适用于后台定时同步，日常查询请用 query）")
    p_qpost.add_argument("--dataset", required=True, help="数据集 ID")
    p_qpost.add_argument("--pagesize", type=int, default=None, help="每页条数（传入后启用后端分页，需配合 --pg）")
    p_qpost.add_argument("--pg", type=int, default=1, help="页码")
    p_qpost.add_argument("--param", default=None, help="查询参数 JSON 字符串")

    # write
    p_write = subparsers.add_parser("write", help="写入数据（新增）")
    p_write.add_argument("--dataset", required=True, help="数据集 ID")
    p_write.add_argument("--ds", required=True, help="数据内容 JSON 字符串")

    # update
    p_update = subparsers.add_parser("update", help="更新数据（按主键）")
    p_update.add_argument("--dataset", required=True, help="数据集 ID")
    p_update.add_argument("--ds", required=True, help="数据内容 JSON 字符串")

    # upload
    p_upload = subparsers.add_parser("upload", help="上传文件")
    p_upload.add_argument("--type", required=True, help="上传配置名称")
    p_upload.add_argument("--file", required=True, help="文件路径")
    p_upload.add_argument("--mail", default=None, help="结果通知邮箱")

    # ask（智能问数：路由型数据集二次调用）
    p_ask = subparsers.add_parser("ask", help="智能问数：先调路由数据集，再自动调真实数据集")
    p_ask.add_argument("--dataset", required=True, help="问数路由数据集 ID（如「智能问数」）")
    p_ask.add_argument("--prompt", required=True, help="自然语言查询提示词")
    p_ask.add_argument("--param", default=None, help="附加查询参数 JSON 字符串（可选）")

    # 给查询类命令统一追加「落盘 / 大数据保护」参数
    for p in (p_query, p_qpost, p_ask):
        p.add_argument("--save", nargs="?", const=True, default=False,
                       help="保存结果为文件；可跟路径，不带值则存到工作空间下的 smartchart_results/")
        p.add_argument("--format", default="csv", choices=["csv", "json", "tsv", "xlsx"],
                       help="落盘文件格式（默认 csv，纯文本可直接读取；xlsx 由标准库生成）")
        p.add_argument("--threshold", type=int, default=100,
                       help="自动落盘行数阈值（默认 100，超过则自动落盘而非打印全量）")
        p.add_argument("--no-save", action="store_true", help="禁用自动落盘")
        p.add_argument("--full", action="store_true", help="强制打印全量（覆盖自动落盘）")

    args = parser.parse_args()

    if not args.action:
        parser.print_help()
        sys.exit(1)

    # 数据集管理命令不需要 SmartChartClient
    if args.action in ("list-datasets", "add-dataset", "remove-dataset"):
        registry = DatasetRegistry(args.datasets)
        if args.action == "list-datasets":
            registry.list_datasets()
        elif args.action == "add-dataset":
            registry.add_dataset(
                ds_id=args.id, name=args.name, description=args.desc,
                operation=args.operation, params=args.params, fields=args.fields, notes=args.notes
            )
        elif args.action == "remove-dataset":
            registry.remove_dataset(args.id)
        sys.exit(0)

    try:
        client = SmartChartClient(args.config)
    except FileNotFoundError as e:
        print(f"错误: {e}")
        sys.exit(1)

    try:
        if args.action == "ping":
            result = client.ping()

        elif args.action == "query":
            param = json.loads(args.param) if args.param else None
            result = client.query(
                dataset_id=args.dataset,
                param=param,
                pagesize=args.pagesize,
                pg=args.pg,
            )

        elif args.action == "query-post":
            param = json.loads(args.param) if args.param else None
            result = client.query_post(
                dataset_id=args.dataset,
                pagesize=args.pagesize,
                pg=args.pg,
                param=param,
            )

        elif args.action == "write":
            ds = json.loads(args.ds)
            result = client.write(dataset_id=args.dataset, ds=ds)

        elif args.action == "update":
            ds = json.loads(args.ds)
            result = client.update(dataset_id=args.dataset, ds=ds)

        elif args.action == "upload":
            result = client.upload_file(
                upload_type=args.type,
                file_path=args.file,
                mail=args.mail,
            )

        elif args.action == "ask":
            param = json.loads(args.param) if args.param else None
            result = client.ask(dataset_id=args.dataset, prompt=args.prompt, param=param)

        _print_result(
            result,
            save=getattr(args, "save", False),
            fmt=getattr(args, "format", "csv"),
            threshold=getattr(args, "threshold", 100),
            force_full=getattr(args, "full", False),
            no_save=getattr(args, "no_save", False),
            name=getattr(args, "dataset", None),
        )

    except json.JSONDecodeError as e:
        print(f"JSON 解析错误: {e}")
        sys.exit(1)
    except ConnectionError as e:
        print(f"连接错误: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
