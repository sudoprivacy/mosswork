#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SmartChart 本地版安装 / 启动 / 停止 管理脚本

子命令:
  install   安装本地 SmartChart（建虚拟环境 -> 装包 -> 初始化数据库 -> 建管理员 -> 生成桌面快捷方式）
  start     启动本地服务（后台运行）并等待就绪
  stop      停止本地服务
  restart   重启本地服务
  status    查看运行状态
  shortcut  重新生成桌面快捷启动方式
  console   前台启动（调试用，Ctrl+C 停止）

设计要点:
  - 全部数据落在 ~/.smartchart/local/ ，虚拟环境在 <BASE>/venv
  - **启动时的 cwd 必须始终是 BASE**：SmartChart 默认把 db.sqlite3 建在
    当前工作目录，换目录启动会生成全新空库（表现为管理员账号丢失）
  - 跨平台：macOS / Linux / Windows
"""

import argparse
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

HOME = Path.home()
BASE = Path(os.environ.get("SMARTCHART_LOCAL_HOME", str(HOME / ".smartchart" / "local")))
VENV = BASE / "venv"
LOG_FILE = BASE / "server.log"
PID_FILE = BASE / "smartchart.pid"
CONF_FILE = BASE / "local.json"
DESKTOP_SCRIPT = BASE / "start_console.py"

IS_WIN = os.name == "nt"
IS_MAC = sys.platform == "darwin"

DEFAULT_PORT = 8000
DEFAULT_ADMIN = "admin"
DEFAULT_PASSWORD = "admin"
PYPI_MIRROR = "https://mirrors.aliyun.com/pypi/simple"
PYPI_OFFICIAL = "https://pypi.org/simple"

MIN_SAFE_VERSION = "8.0"

# smartchart 只从官网获取（PyPI 后续可能不再发行）；pip 源只用来拉 Django 等依赖
WHEEL_URL = "https://www.smartchart.cn/media/smartchart-8.0.9-py3-none-any.whl"


def resolve_wheel_url(args=None):
    """--wheel-url > 环境变量 SMARTCHART_WHEEL_URL > 内置常量。"""
    return (getattr(args, "wheel_url", None)
            or os.environ.get("SMARTCHART_WHEEL_URL")
            or WHEEL_URL)


def wheel_version(url=None):
    """从 whl 文件名解析版本，如 smartchart-8.0.9-py3-none-any.whl → 8.0.9。"""
    m = re.search(r"smartchart-([0-9][0-9A-Za-z.]*?)-py3", url or WHEEL_URL)
    return m.group(1) if m else ""


# ---------------------------------------------------------------- 基础工具
def log(msg):
    print(msg, flush=True)


def step(idx, total, msg):
    log("[%d/%d] %s" % (idx, total, msg))


def venv_python():
    p = VENV / ("Scripts/python.exe" if IS_WIN else "bin/python3")
    if not p.exists():
        p = VENV / ("Scripts/python.exe" if IS_WIN else "bin/python")
    return str(p)


def venv_bin(name):
    return str(VENV / ("bin/%s" % name))


def _popen_kwargs(capture):
    kw = {}
    if capture:
        kw.update(stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if IS_WIN:
        kw["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    return kw


def run(cmd, cwd=None, env=None, check=True, capture=True, timeout=None):
    """运行命令并返回输出；capture=True 时实时打印输出。"""
    if capture:
        proc = subprocess.run(cmd, cwd=cwd, env=env, **_popen_kwargs(True))
    else:
        proc = subprocess.run(cmd, cwd=cwd, env=env, **_popen_kwargs(False))
    if check and proc.returncode != 0:
        raise RuntimeError("命令失败 (%d): %s" % (proc.returncode, " ".join(cmd)))
    return proc


def run_stream(cmd, cwd=None, env=None):
    """流式执行命令，实时把子进程输出打到终端（长任务用）。"""
    proc = subprocess.Popen(
        cmd, cwd=cwd, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace",
    )
    buf = []
    for line in proc.stdout:
        line = line.rstrip()
        if line:
            log("    | " + line)
            buf.append(line)
    proc.wait()
    return proc.returncode, "\n".join(buf)


def load_conf():
    if CONF_FILE.exists():
        try:
            return json.loads(CONF_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def save_conf(data):
    BASE.mkdir(parents=True, exist_ok=True)
    conf = load_conf()
    conf.update(data)
    CONF_FILE.write_text(json.dumps(conf, ensure_ascii=False, indent=2), encoding="utf-8")


def port_owner_pid(port):
    """查出占用端口的进程 PID；无法判断返回 None。

    用于区分「本脚本管理的实例」和「外部进程（如 PATH 上系统安装的 smartchart）」，
    后者会抢占端口，导致用户访问到的并不是本实例。
    """
    try:
        # 必须限定 -sTCP:LISTEN，否则会把「连到该端口的客户端」（如浏览器）也算进来
        out = subprocess.run(["lsof", "-ti", "tcp:%d" % port, "-sTCP:LISTEN"],
                             stdout=subprocess.PIPE, text=True,
                             stderr=subprocess.DEVNULL, timeout=10).stdout.strip()
        if out:
            return int(out.split()[0])
    except Exception:
        pass
    try:  # Linux 兜底
        import re
        out2 = subprocess.run(["ss", "-lptn", "sport = :%d" % port], stdout=subprocess.PIPE,
                              text=True, stderr=subprocess.DEVNULL, timeout=10).stdout
        m = re.search(r"pid=(\d+)", out2)
        if m:
            return int(m.group(1))
    except Exception:
        pass
    return None


def port_open(port, host="127.0.0.1"):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.6)
        return s.connect_ex((host, port)) == 0


def http_ok(url, timeout=3):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "smartchart-local"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status < 500
    except urllib.error.HTTPError as e:
        return e.code < 500
    except Exception:
        return False


def base_url():
    conf = load_conf()
    return "http://127.0.0.1:%d" % int(conf.get("port", DEFAULT_PORT))


# ---------------------------------------------------------------- Python 选择
def py_version(exe):
    try:
        out = subprocess.run(
            [exe, "-c", "import sys;print('%d.%d' % sys.version_info[:2])"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=20,
        )
        if out.returncode == 0:
            return tuple(int(x) for x in out.stdout.strip().split("."))
    except Exception:
        pass
    return None


def pick_base_python(preferred=None):
    """挑一个 3.8 <= ver <= 3.12 的解释器；找不到就退回当前解释器。"""
    candidates = []
    if preferred:
        candidates.append(preferred)
    candidates += [
        shutil.which("python3.12"),
        shutil.which("python3.11"),
        shutil.which("python3.10"),
        shutil.which("python3.9"),
        shutil.which("python3"),
        sys.executable,
    ]
    seen, ordered = set(), []
    for c in candidates:
        if c and c not in seen:
            seen.add(c)
            ordered.append(c)

    fallback = None
    for exe in ordered:
        ver = py_version(exe)
        if not ver:
            continue
        if fallback is None:
            fallback = (exe, ver)
        if (3, 8) <= ver <= (3, 12):
            return exe, ver
    if fallback:
        log("    ! 未找到官方推荐的 Python 3.8~3.12，退而使用 %s (%s)，若依赖编译失败请加 --python 指定 3.12"
            % (fallback[0], ".".join(str(x) for x in fallback[1])))
        return fallback
    raise RuntimeError("未找到可用的 Python 3 解释器，请先安装 Python 3.8+：https://www.python.org/downloads/")


# ---------------------------------------------------------------- install
def last_error(out, n=8):
    """取输出末尾若干有效行，用于展示真实报错。"""
    lines = [l for l in (out or "").splitlines() if l.strip()]
    return "\n".join("    | " + l for l in lines[-n:])


def detect_db_path():
    """探测 Django 实际使用的数据库路径。

    SmartChart 会沿 cwd 向上查找 config.ini，若上层目录已有 config.ini，
    数据库会落在那一层而不是 BASE，因此必须实测而非假设。
    """
    exe = venv_bin("smartchart")
    try:
        proc = subprocess.run(
            [exe, "shell", "-c",
             "from django.conf import settings; print(settings.DATABASES['default'].get('NAME',''))"],
            cwd=str(BASE), stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            text=True, timeout=90,
        )
        for line in reversed(proc.stdout.splitlines()):
            line = line.strip()
            if not line or line.startswith("Traceback") or line.startswith("File "):
                continue
            if line.startswith("/") or line.endswith(".sqlite3") or "\\" in line:
                return line
    except Exception:
        pass
    return ""


def looks_like_exists(out):
    """判断创建管理员失败是否仅仅因为账号已存在。"""
    low = (out or "").lower()
    return ("already exists" in low
            or "already taken" in low
            or "unique constraint" in low
            or "已存在" in out)


def pip_cmd(vpy, pkgs, index, upgrade=False):
    """构造 pip install 命令。

    安全约束（不要改回去）：不使用 --trusted-host，也不关闭任何 TLS 校验；
    证书问题请让用户修本机 CA（macOS 跑一次 Install Certificates.command）。
    """
    cmd = [vpy, "-m", "pip", "install"]
    if upgrade:
        cmd.append("-U")
    if index:
        cmd += ["-i", index]
    cmd += pkgs
    return cmd


def look_like_ssl_error(out):
    low = (out or "").lower()
    return ("certificate_verify_failed" in low
            or "certificate verify failed" in low
            or "ssl certerror" in low)


def pip_install_smartchart(vpy, index, args):
    """安装 smartchart，返回 (是否成功, 最后一次输出)。

    只从官网 whl 装（PyPI 后续可能不再发行）；index 只用于拉 Django 等依赖。
    """
    url = resolve_wheel_url(args)
    log("    官网 whl: %s" % url)
    code, last_out = run_stream(
        pip_cmd(vpy, [url], index, upgrade=getattr(args, "upgrade", False)),
        cwd=str(BASE))
    return code == 0, last_out


def read_pkg_version(vpy):
    try:
        out = subprocess.run([vpy, "-m", "pip", "show", "smartchart"],
                             stdout=subprocess.PIPE, text=True,
                             stderr=subprocess.DEVNULL, timeout=30).stdout
        for line in out.splitlines():
            if line.startswith("Version:"):
                return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return ""


def _http_text(url, timeout=10):
    """读取 URL 文本（仅用于只读查询，如查最新版本号）。

    TLS 校验按系统默认开启（不设 check_hostname=False / CERT_NONE）；
    取不到就交给调用方按「查不到版本」处理，不做任何降级。
    """
    req = urllib.request.Request(url, headers={"User-Agent": "smartchart-local-setup"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "ignore")


def version_key(v):
    """版本号排序键，支持 8.0.9 / 7.8.1 / 8.0-rc1 这类写法。"""
    out = []
    for p in re.split(r"[^0-9A-Za-z]+", v):
        out.append((0, int(p), "") if p.isdigit() else (1, 0, p))
    return out


def is_safe_version(ver):
    """版本号是否高于风险区间（7.5.4 ~ 8.0）。空版本视为不安全。"""
    if not ver:
        return False
    try:
        return version_key(ver) > version_key(MIN_SAFE_VERSION)
    except Exception:
        return False


def latest_upstream_version(timeout=10):
    """查 PyPI 官方上 smartchart 的最新版本号，失败返回 ''。"""
    try:
        data = json.loads(_http_text("https://pypi.org/pypi/smartchart/json", timeout))
        return (data.get("info") or {}).get("version") or ""
    except Exception:
        return ""



def rotate_backups(db_path, keep=3):
    """只保留最近 keep 份数据库备份，避免多次升级后堆积。"""
    try:
        d = os.path.dirname(db_path)
        name = os.path.basename(db_path) + ".bak."
        baks = sorted(p for p in os.listdir(d) if p.startswith(name))
        while len(baks) > keep:
            old = baks.pop(0)
            os.remove(os.path.join(d, old))
            log("    已清理旧备份: %s" % old)
    except Exception:
        pass


SCHEMA_SNIPPET = (
    "from django.db import connection\n"
    "from django.apps import apps\n"
    "missing = []\n"
    "for m in apps.get_models():\n"
    "    t = m._meta.db_table\n"
    "    try:\n"
    "        cols = {c.name for c in connection.introspection.get_table_description(connection.cursor(), t)}\n"
    "    except Exception:\n"
    "        continue\n"
    "    if not cols:\n"
    "        continue\n"
    "    for f in m._meta.fields:\n"
    "        if f.column not in cols:\n"
    "            missing.append('%s.%s' % (t, f.column))\n"
    "print('SMTCHECK')\n"
    "for x in missing[:30]:\n"
    "    print('MISSING', x)\n"
    "print('SMTEND')\n"
)


def check_missing_columns(timeout=180):
    """对比 Django 模型字段与数据库实际列，返回 (缺失列表, 错误信息)。

    背景：SmartChart 8.0.9 把 tags 字段直接写进了 echart.0001_initial（改写初始迁移），
    老库 migrate 时只会说 "No migrations to apply"，表里永远补不上这一列，
    直到打开首页才炸 django.db.utils.OperationalError: no such column: xxx。
    migrate 的退出码察觉不到这类问题，必须比对 schema 才能发现。

    缺失列表为 None 表示没能完成检测（区别于「检测了但没问题」的空列表）。
    """
    try:
        out = subprocess.run([venv_bin("smartchart"), "shell", "-c", SCHEMA_SNIPPET],
                             cwd=str(BASE), stdout=subprocess.PIPE,
                             stderr=subprocess.DEVNULL, text=True, timeout=timeout).stdout
    except Exception as e:
        return None, str(e)
    items, collecting = [], False
    for line in out.splitlines():
        s = line.strip()
        if s == "SMTCHECK":
            collecting = True
            continue
        if s == "SMTEND":
            break
        if collecting and s.startswith("MISSING "):
            items.append(s.split(" ", 1)[1].strip())
    return items, ""


def report_missing_columns(missing):
    """把缺失字段打印成可操作的提示。"""
    log("")
    log("⚠ 数据库缺少 %d 个字段（新版模型有，老表里没有）：" % len(missing))
    for x in missing[:10]:
        log("    - " + x)
    if len(missing) > 10:
        log("    ... 其余 %d 个" % (len(missing) - 10))
    log("  原因：新版把这些字段直接写进了**初始迁移**，老库 migrate 会显示")
    log("        「No migrations to apply」，于是永远补不上（migrate 退出码仍是 0）。")
    log("  表现：页面报 no such column: <上列某字段>。")
    log("  修复：%s %s upgrade --reset-db" % (sys.executable, os.path.abspath(__file__)))
    log("        （会先备份当前库，再重建，现有仪表盘/数据源配置会清空）")


def trash_db(db_path):
    """把数据库移到 ~/.smartchart/trash/ 而非直接删除，留恢复余地。"""
    trash = BASE / "trash"
    trash.mkdir(parents=True, exist_ok=True)
    dst = trash / ("%s.%s" % (os.path.basename(db_path), time.strftime("%Y%m%d-%H%M%S")))
    shutil.move(db_path, dst)
    return dst


def reset_db_flow(port, was_running, conf):
    """重建数据库：备份 → 移入 trash → migrate → 建管理员 → 按需重启。"""
    db_path = conf.get("db_path") or detect_db_path()
    if db_path and os.path.exists(db_path):
        bak = "%s.before-reset.%s" % (db_path, time.strftime("%Y%m%d-%H%M%S"))
        shutil.copy2(db_path, bak)
        log("已备份 : %s" % bak)
        dst = trash_db(db_path)
        log("旧库已移入 : %s（不是永久删除，需要可从此恢复）" % dst)
    elif db_path:
        log("数据库不存在，直接新建: %s" % db_path)

    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    code, out = run_stream([venv_bin("smartchart"), "migrate"], cwd=str(BASE), env=env)
    if code != 0:
        log("× migrate 失败：")
        log(last_error(out, 10))
        return 1
    log("√ 数据库已重建")

    user = conf.get("admin_user", DEFAULT_ADMIN)
    passwd = conf.get("admin_password", DEFAULT_PASSWORD)
    env2 = os.environ.copy()
    env2["DJANGO_SUPERUSER_PASSWORD"] = passwd
    code, out = run_stream(
        [venv_bin("smartchart"), "createsuperuser", "--noinput",
         "--username", user, "--email", "%s@example.com" % user],
        cwd=str(BASE), env=env2,
    )
    if code != 0 and not looks_like_exists(out):
        log("! 创建管理员失败：%s" % last_error(out, 4))
    else:
        log("√ 管理员已就绪 : %s / %s" % (user, passwd))

    if was_running:
        log("重启服务以加载新库 ...")
        cmd_start(argparse.Namespace(port=port, open=False, console=False))
        time.sleep(2)
        healthy = http_ok("http://127.0.0.1:%d" % port)
        log("健康检查 : %s" % ("√正常" if healthy else ("×异常，请看日志 %s" % LOG_FILE)))

    missing, err = check_missing_columns()
    if missing is None:
        log("! 结构自检未能完成: %s" % err)
    elif missing:
        report_missing_columns(missing)
        return 1
    else:
        log("√ 结构自检通过：数据库表结构与当前版本一致")
    return 0


def cmd_check(args):
    """只做表结构自检，不改任何东西。"""
    if not VENV.exists():
        log("× 尚未安装本地 SmartChart")
        return 1
    log("正在比对模型与数据库表结构 ...")
    missing, err = check_missing_columns()
    if missing is None:
        log("× 无法完成检查: %s" % err)
        return 1
    if not missing:
        log("√ 一致：没有缺失字段")
        return 0
    report_missing_columns(missing)
    return 1


def cmd_install(args):
    total = 6
    BASE.mkdir(parents=True, exist_ok=True)

    step(1, total, "检查 Python 环境")
    if VENV.exists() and not args.force:
        log("    ! 已存在虚拟环境 %s，跳过创建（要重装请加 --force）" % VENV)
    pyexe, ver = pick_base_python(args.python)
    log("    使用解释器: %s (Python %s)" % (pyexe, ".".join(str(x) for x in ver)))

    step(2, total, "创建独立虚拟环境 %s" % VENV)
    if not VENV.exists() or args.force:
        if VENV.exists():
            shutil.rmtree(VENV)
        run([pyexe, "-m", "venv", str(VENV)], capture=True)
        log("    √ 虚拟环境已创建")
    else:
        log("    √ 复用已有虚拟环境")

    vpy = venv_python()
    step(3, total, "安装 smartchart 包（首次安装可能需要几分钟）")
    index = args.index_url or PYPI_MIRROR
    # 升级 pip 失败不影响主流程（venv 自带 pip 通常够用）
    pip_up = [vpy, "-m", "pip", "install", "--upgrade", "pip"]
    if index:
        pip_up += ["-i", index]
    run_stream(pip_up, cwd=str(BASE))
    ok, out = pip_install_smartchart(vpy, index, args)
    if not ok:
        log("")
        log("× smartchart 包安装失败。最后一段输出：")
        log("\n".join("    | " + l for l in out.splitlines()[-8:]))
        log("")
        if look_like_ssl_error(out):
            log("  看起来是 SSL 证书校验失败，常见修复方式：")
            if IS_MAC:
                log("    · macOS 官方 Python 安装包需运行一次：")
                log('      /Applications/Python\\ 3.12/Install\\ Certificates.command')
            log("    · 或本机处于代理/内网环境，可先 curl 试试连通性：")
            log("      curl -I https://pypi.org/simple/smartchart/")
            log("    · 依赖（Django 等）仍从 pip 源下载，可换源重试：")
            log("      --index-url https://pypi.org/simple")
            log("  注意：本脚本不会用 --trusted-host 跳过校验（那会让下载链失去 TLS 保护）。")
        else:
            log("  常见原因：网络不通 / 公司代理限制 / 官网 whl 地址有变。")
            log("  · 换镜像拉依赖：--index-url https://mirrors.aliyun.com/pypi/simple")
            log("  · 指定新版 whl：--wheel-url <官网 whl 地址>")
        return 1

    pkg_ver = read_pkg_version(vpy)
    if not os.path.exists(venv_bin("smartchart")):
        log("× 包已安装但未找到可执行文件 %s，请检查安装是否完整" % venv_bin("smartchart"))
        return 1
    if not is_safe_version(pkg_ver):
        log("")
        log("× 安装到的版本 %s 不在安全范围（要求 > %s，%s 及以下存在供应链风险）。"
            % (pkg_ver or "未知", MIN_SAFE_VERSION, MIN_SAFE_VERSION))
        log("  当前装的是官网 whl：%s" % resolve_wheel_url(args))
        log("  请换一个更高版本的官网 whl：--wheel-url <官网 whl 地址>")
        return 1
    log("    √ smartchart %s 安装完成" % (pkg_ver or "已安装"))

    step(4, total, "初始化数据库（工作目录 %s）" % BASE)
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    exe = venv_bin("smartchart")
    # v8.0+ 需先 makemigrations 再 migrate
    code, out = run_stream([exe, "makemigrations"], cwd=str(BASE), env=env)
    if code != 0:
        log("    ! makemigrations 未完全成功（多数情况可忽略），错误：")
        log(last_error(out, 4))
    code, out = run_stream([exe, "migrate"], cwd=str(BASE), env=env)
    if code != 0:
        log("")
        log("× 数据库初始化失败，最后错误：")
        log(last_error(out, 10))
        log("")
        log("  migrate 是必须成功的步骤，请按上面错误修好后重跑 install。")
        log("  最常见原因：INSTALLED_APPS / ext_apps 里配置了不存在的模块")
        log("  （例如自定义加了对不起版本的 app），或数据库文件无写权限。")
        return 1
    log("    √ 数据库初始化完成")
    db_path = detect_db_path()
    if db_path:
        save_conf({"db_path": db_path})
        log("    数据库实际路径: %s" % db_path)
        if os.path.dirname(os.path.abspath(db_path)) != str(BASE):
            log("    ! 注意：数据库不在安装目录下。SmartChart 会沿上级目录查找 config.ini，")
            log("      上面的 config.ini 决定了数据库位置。想独立存放可在 %s 放一份 config.ini。" % BASE)

    step(5, total, "创建超级管理员")
    user = args.admin_user or DEFAULT_ADMIN
    passwd = args.admin_password or DEFAULT_PASSWORD
    env2 = os.environ.copy()
    env2["DJANGO_SUPERUSER_PASSWORD"] = passwd
    code, out = run_stream(
        [venv_bin("smartchart"), "createsuperuser", "--noinput",
         "--username", user, "--email", "%s@example.com" % user],
        cwd=str(BASE), env=env2,
    )
    if code != 0:
        if looks_like_exists(out):
            log("    √ 管理员已存在，跳过创建: %s" % user)
        else:
            log("    ! 创建管理员失败，错误：")
            log(last_error(out, 6))
            log("      服务仍可启动，稍后可手工创建: %s createsuperuser" % exe)
    else:
        log("    √ 管理员已就绪: %s / %s" % (user, passwd))

    save_conf({
        "port": args.port,
        "admin_user": user,
        "admin_password": passwd,
        "version": pkg_ver,
        "python": vpy,
        "base": str(BASE),
    })

    step(6, total, "生成桌面快捷启动方式")
    created = make_shortcut(args.port)
    for c in created:
        log("    √ " + c)

    log("")
    log("=" * 56)
    log("安装完成！")
    log("  管理脚本目录 : %s" % BASE)
    log("  配置文件     : %s" % CONF_FILE)
    log("  快捷方式     : %s" % (created[0] if created else "(未生成，见下方提示)"))
    log("")
    log("现在执行启动： %s %s start --open" % (sys.executable, __file__))
    log("")
    log("重要提示（v8.0 必看）：首次登录后请进入右上角头像 →")
    log("  「产品认证」→「激活高级功能」→「组件升级」，完成组件初始化。")
    log("=" * 56)
    return 0


# ---------------------------------------------------------------- 启动 / 停止
def read_pid():
    if not PID_FILE.exists():
        return None
    try:
        pid = int(PID_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        return None
    try:
        os.kill(pid, 0)
        return pid
    except Exception:
        return None


def kill_pid(pid):
    if IS_WIN:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        try:
            os.kill(pid, 15)
            for _ in range(30):
                time.sleep(0.2)
                try:
                    os.kill(pid, 0)
                except OSError:
                    return True
            os.kill(pid, 9)
        except OSError:
            pass
    return True


def live_pid(port):
    """端口已在监听时返回 True（不论是否本脚本启动）。"""
    return port_open(port)


def start_server(port, foreground=False, open_browser=False):
    conf = load_conf()
    if not VENV.exists():
        raise RuntimeError("尚未安装本地 SmartChart，请先执行 install")
    if not foreground and port_open(port):
        mine = read_pid()
        owner = port_owner_pid(port)
        if mine and owner == mine:
            log("服务已在运行（本脚本管理的实例 PID=%s）" % mine)
            log("  地址: http://127.0.0.1:%d" % port)
            if open_browser:
                open_browser_url("http://127.0.0.1:%d" % port)
            return 0
        log("")
        log("× 端口 %d 已被占用，且占用者不是本脚本管理的实例。" % port)
        if owner:
            log("  占用进程 PID=%s" % owner)
            log("  它可能是在别处启动的 smartchart（例如 PATH 上由其它 Python 装的旧版本）。")
            log("  核实它用的是哪个环境：")
            log("    lsof -p %s | grep site-packages" % owner)
        # 只有查的就是默认管理端口时，才谈得上「本脚本记录的实例」
        if mine and port == int(load_conf().get("port", DEFAULT_PORT)):
            log("  （本脚本记录的实例 PID=%s 不在该端口上）" % mine)
        log("")
        log("  三种处理方式：")
        log("    ① 停掉占用进程后重跑 start        kill %s" % (owner or "<PID>"))
        log("    ② 换端口启动                      --port 8010")
        log("    ③ 若确认它就是你要的实例，用 <管理脚本> status --port %d 看详情" % port)
        return 1

    exe = venv_bin("smartchart")
    addr = "0.0.0.0:%d" % port
    cmd = [exe, "runserver", addr, "--insecure", "--noreload"]
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")

    if foreground:
        log("前台启动 %s（Ctrl+C 停止），工作目录 %s" % (" ".join(cmd), BASE))
        proc = subprocess.run(cmd, cwd=str(BASE), env=env)
        return proc.returncode

    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    lf = open(LOG_FILE, "a", encoding="utf-8")
    kwargs = {"cwd": str(BASE), "env": env, "stdout": lf, "stderr": subprocess.STDOUT}
    if IS_WIN:
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    proc = subprocess.Popen(cmd, **kwargs)
    PID_FILE.write_text(str(proc.pid), encoding="utf-8")

    log("正在启动本地 SmartChart ...")
    deadline = time.time() + 120
    ok = False
    while time.time() < deadline:
        if http_ok("http://127.0.0.1:%d" % port):
            ok = True
            break
        if proc.poll() is not None:
            break
        time.sleep(1)

    if not ok:
        log("× 启动失败或未能在 120s 内就绪，请查看日志: %s" % LOG_FILE)
        tail = ""
        try:
            tail = "\n".join(open(LOG_FILE, encoding="utf-8", errors="replace").readlines()[-25:])
        except Exception:
            pass
        if tail:
            log("---- 日志尾部 ----\n" + tail)
        return 1

    log("√ 已启动  PID=%s  端口=%s" % (proc.pid, port))
    log("  访问地址  : %s" % base_url())
    log("  管理员    : %s / %s" % (conf.get("admin_user", DEFAULT_ADMIN),
                                   conf.get("admin_password", DEFAULT_PASSWORD)))
    log("  日志文件  : %s" % LOG_FILE)
    if open_browser:
        open_browser_url(base_url())
    return 0


def open_browser_url(url):
    try:
        if IS_MAC:
            subprocess.run(["open", url], check=False)
        elif IS_WIN:
            os.startfile(url)  # noqa: S606
        else:
            subprocess.run(["xdg-open", url], check=False)
        log("  已尝试打开浏览器: %s" % url)
    except Exception as e:
        log("  打开浏览器失败，请手动访问 %s (%s)" % (url, e))


def cmd_start(args):
    conf = load_conf()
    port = args.port or int(conf.get("port", DEFAULT_PORT))
    return start_server(port, foreground=args.console, open_browser=args.open)


def cmd_stop(args):
    port = args.port or int(load_conf().get("port", DEFAULT_PORT))
    pid = read_pid()
    stopped = False
    if pid:
        log("停止进程 PID=%s ..." % pid)
        kill_pid(pid)
        stopped = True
        PID_FILE.unlink(missing_ok=True)
    else:
        log("未找到运行中的进程记录")

    if not IS_WIN:
        # 兜底：按端口查杀（防止 pid 文件丢失导致残留）
        try:
            out = subprocess.run(["lsof", "-ti", "tcp:%d" % port],
                                 stdout=subprocess.PIPE, text=True).stdout.strip()
            for p in out.split():
                try:
                    os.kill(int(p), 15)
                    stopped = True
                except Exception:
                    pass
        except FileNotFoundError:
            pass

    if stopped:
        time.sleep(1)
    still = port_open(port)
    log("√ 已停止" if not still else "× 端口 %d 仍在监听，可能由其他进程占用（飞书/其它服务），请手工排查" % port)
    return 0 if not still else 1


def cmd_restart(args):
    cmd_stop(argparse.Namespace(port=args.port))
    time.sleep(1)
    return cmd_start(argparse.Namespace(port=args.port, open=args.open, console=False))


def status_lines(port=None):
    """返回状态信息行，供 status 与 menu 复用。"""
    conf = load_conf()
    port = port or int(conf.get("port", DEFAULT_PORT))
    pid = read_pid()
    listening = port_open(port)
    healthy = http_ok("http://127.0.0.1:%d" % port)
    owner = port_owner_pid(port) if listening else None
    if owner and pid and owner != pid:
        owner_desc = "PID %s  ⚠ 外部进程，非本脚本启动的实例" % owner
    elif owner:
        owner_desc = "PID %s  √ 本脚本管理的实例" % owner
    else:
        owner_desc = "-"
    return [
        "安装目录 : %s  %s" % (BASE, "√已安装" if VENV.exists() else "×未安装"),
        "版本     : %s" % (conf.get("version", "-")),
        "端口     : %s  %s" % (port, "√监听中" if listening else "×未监听"),
        "占用者   : %s" % owner_desc,
        "进程记录 : %s" % (("PID " + str(pid)) if pid else "×无运行中的进程记录"),
        "健康检查 : %s" % ("√正常" if healthy else "×不可访问"),
        "访问地址 : http://127.0.0.1:%d" % port,
        "管理员   : %s / %s" % (conf.get("admin_user", "-"), conf.get("admin_password", "-")),
        "数据库   : %s" % conf.get("db_path", "-"),
        "日志文件 : %s" % LOG_FILE,
    ]


def cmd_status(args):
    for line in status_lines(args.port):
        log(line)
    return 0


def cmd_menu(args):
    """交互式菜单，供桌面快捷方式调用（双击后可选启动/停止/重启）。"""
    port = int(load_conf().get("port", DEFAULT_PORT))

    def read_choice():
        try:
            sys.stdout.write("  请输入序号后回车: ")
            sys.stdout.flush()
            return sys.stdin.readline().strip()
        except (EOFError, KeyboardInterrupt):
            return None

    while True:
        listening = port_open(port)
        log("")
        log("=" * 48)
        log("   SmartChart 本地服务")
        log("=" * 48)
        if not VENV.exists():
            log("   ! 尚未安装，请先执行 install")
            return 1
        log("   当前状态: %s     地址: http://127.0.0.1:%d"
            % ("● 运行中" if listening else "○ 未运行", port))
        log("")
        log("   [1] 启动服务（并自动打开浏览器）")
        log("   [2] 停止服务")
        log("   [3] 重启服务")
        log("   [4] 查看详细状态")
        log("   [5] 打开浏览器")
        log("   [0] 退出本窗口")
        log("-" * 48)
        choice = read_choice()
        if choice is None:
            log("")
            log("   非交互环境，请直接使用命令：start / stop / status / restart")
            return 0
        if choice == "1":
            if listening:
                log("   服务已在运行中，直接打开浏览器。")
                open_browser_url("http://127.0.0.1:%d" % port)
            else:
                start_server(port, foreground=False, open_browser=True)
        elif choice == "2":
            cmd_stop(argparse.Namespace(port=port))
        elif choice == "3":
            cmd_stop(argparse.Namespace(port=port))
            time.sleep(1)
            start_server(port, foreground=False, open_browser=True)
        elif choice == "4":
            log("")
            for line in status_lines(port):
                log("   " + line)
        elif choice == "5":
            open_browser_url("http://127.0.0.1:%d" % port)
        elif choice == "0":
            log("")
            log("   已退出。服务在后台继续运行，再次双击本图标可管理。")
            return 0
        else:
            log("   ! 无效输入，请输入 0~5")


# ---------------------------------------------------------------- 桌面快捷方式
def desktop_dir():
    if IS_WIN:
        cands = [
            Path(os.environ.get("USERPROFILE", str(HOME))) / "Desktop",
            Path(os.environ.get("USERPROFILE", str(HOME))) / "OneDrive" / "Desktop",
            Path(os.environ.get("PUBLIC", "")) / "Desktop",
        ]
    else:
        cands = [HOME / "Desktop", HOME / "桌面"]
        try:
            out = subprocess.run(
                ["osascript", "-e", "POSIX path of (path to desktop folder)"],
                stdout=subprocess.PIPE, text=True, timeout=5,
            )
            if out.returncode == 0 and out.stdout.strip():
                cands.insert(0, Path(out.stdout.strip()))
        except Exception:
            pass
    for c in cands:
        try:
            if c and c.is_dir():
                return c
        except Exception:
            continue
    return HOME


def make_shortcut(port=DEFAULT_PORT):
    """在桌面生成快捷启动入口，返回生成的文件列表。

    要点：
      - 文件名统一用 smartchart
      - 用**虚拟环境里的解释器**跑管理脚本，与服务进程同环境，不依赖系统 python
      - 内容是交互式菜单（可选启动/停止/重启/状态），而非无条件 start
    """
    script = os.path.abspath(__file__)
    desktop = desktop_dir()
    pyexe = venv_python() if VENV.exists() else sys.executable
    created = []

    # 清理旧命名的快捷方式（由早期版本生成）
    for old in ("启动 SmartChart.command", "启动 SmartChart.bat", "启动 SmartChart.desktop"):
        p = desktop / old
        if p.exists():
            try:
                p.unlink()
                log("    √ 已清理旧快捷方式: %s" % p)
            except Exception:
                pass

    if IS_WIN:
        target = desktop / "smartchart.bat"
        content = (
            "@echo off\r\n"
            "chcp 65001 >nul\r\n"
            "title SmartChart\r\n"
            '"{py}" "{script}" menu\r\n'
            "pause\r\n"
        ).format(py=pyexe, script=script)
        target.write_text(content, encoding="utf-8")
        created.append(str(target))

    elif IS_MAC:
        target = desktop / "smartchart.command"
        content = (
            "#!/bin/bash\n"
            'cd "$HOME"\n'
            '"{py}" "{script}" menu\n'
            'if [ $? -ne 0 ]; then\n'
            '  echo ""\n'
            '  read -n 1 -s -r -p "按任意键关闭本窗口..."\n'
            '  echo ""\n'
            'fi\n'
        ).format(py=pyexe, script=script)
        target.write_text(content, encoding="utf-8")
        os.chmod(target, 0o755)
        # 去掉 macOS 隔离属性，否则双击会提示「无法打开」
        try:
            subprocess.run(["xattr", "-d", "com.apple.quarantine", str(target)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        created.append(str(target))

    else:  # Linux
        target = desktop / "smartchart.desktop"
        content = (
            "[Desktop Entry]\n"
            "Type=Application\n"
            "Name=smartchart\n"
            "Comment=管理本地 SmartChart 服务（启动/停止/重启）\n"
            'Exec="{py}" "{script}" menu\n'
            "Terminal=true\n"
            "Categories=Development;\n"
        ).format(py=pyexe, script=script)
        target.write_text(content, encoding="utf-8")
        try:
            os.chmod(target, 0o755)
        except Exception:
            pass
        created.append(str(target))

    save_conf({"port": port, "shortcut": created[0]})
    return created


def cmd_shortcut(args):
    conf = load_conf()
    port = args.port or int(conf.get("port", DEFAULT_PORT))
    created = make_shortcut(port)
    for c in created:
        log("√ 已生成: " + c)
    log("双击该文件即可启动本地 SmartChart（macOS 首次可能被安全策略拦截，右键→打开 即可）")
    return 0


def cmd_upgrade(args):
    """升级 smartchart 到最新版本。

    相比 'install --upgrade' 多做了几件事：
      - 升级前后对比版本号，明确告知是否真的升了
      - 升级前备份数据库（migrate 会改表结构，留退路）
      - 若服务正在运行则自动重启，否则进程仍加载旧代码、升级不生效
      - 升级后做表结构自检，发现「模型有、表里没有」的字段会明确报出来
    """
    if not VENV.exists():
        log("× 尚未安装本地 SmartChart，请先执行 install")
        return 1

    # 用户已明确要求重建库时的快捷路径（不必先升版本）
    if getattr(args, "reset_db", False):
        conf0 = load_conf()
        initial_port = args.port or int(conf0.get("port", DEFAULT_PORT))
        was_up = port_owner_pid(initial_port) is not None
        if was_up:
            cmd_stop(argparse.Namespace(port=initial_port))
            time.sleep(1)
        return reset_db_flow(initial_port, was_up, conf0)

    vpy = venv_python()
    conf = load_conf()
    port = args.port or int(conf.get("port", DEFAULT_PORT))
    before = read_pkg_version(vpy)

    # 只装官网 whl：目标版本从 whl 文件名取，不依赖 PyPI（后者可能不再发行）
    index = args.index_url or PYPI_MIRROR
    url = resolve_wheel_url(args)
    target = wheel_version(url)
    upstream = latest_upstream_version()   # 仅参考：PyPI 未必同步官网

    if target and not is_safe_version(target):
        log("× 官网 whl 版本是 %s，未超过安全下限 %s，本次不升级。"
            % (target, MIN_SAFE_VERSION))
        log("  请换一个更高版本的官网 whl：--wheel-url <官网 whl 地址>")
        return 1

    log("当前版本 : %s" % (before or "未知"))
    log("目标版本 : %s（官网 whl）" % (target or "未知"))
    if upstream and target and version_key(upstream) > version_key(target):
        log("! PyPI 上有更高版本 %s，但本脚本只装官网 whl；要用请 --wheel-url 指定" % upstream)
    log("使用源   : %s（仅用于拉依赖）" % index)
    log("工作目录 : %s" % BASE)
    log("")

    # 1) 升级前备份数据库
    db_path = conf.get("db_path") or detect_db_path()
    if db_path and os.path.exists(db_path):
        bak = "%s.bak.%s" % (db_path, time.strftime("%Y%m%d-%H%M%S"))
        try:
            shutil.copy2(db_path, bak)
            log("数据库备份 : %s" % bak)
            rotate_backups(db_path)
        except Exception as e:
            log("! 数据库备份失败（升级继续）: %s" % e)

    # 2) 记录服务是否在跑，稍后决定要不要重启
    was_running = port_owner_pid(port) is not None

    # 3) 走 install 的升级通道：pip -U → migrate → 管理员 → 快捷方式
    rc = cmd_install(argparse.Namespace(
        python=args.python,
        port=port,
        admin_user=args.admin_user or conf.get("admin_user", DEFAULT_ADMIN),
        admin_password=args.admin_password or conf.get("admin_password", DEFAULT_PASSWORD),
        index_url=index,
        wheel_url=getattr(args, "wheel_url", None),
        force=False,
        upgrade=True,
    ))
    if rc != 0:
        log("")
        log("× 升级未完成，数据库备份仍保留着，可放心重试。")
        return rc

    after = read_pkg_version(vpy)
    if not is_safe_version(after):
        log("")
        log("× 升级后版本仍是 %s，未超过安全下限 %s。" % (after or "未知", MIN_SAFE_VERSION))
        log("  请检查源：%s" % index)
        return 1
    log("")
    changed = not (before and after and before == after)
    if changed:
        log("版本更新 : %s → %s" % (before or "?", after or "?"))
    else:
        log("版本未变化（仍是 %s）。做一次表结构自检，确认库与当前版本是否匹配 ..." % after)

    # 3.5) 表结构自检：新版可能把新字段写进**初始迁移**，老库 migrate 察觉不到
    #      （退出码仍是 0、输出 "No migrations to apply"），
    #      只能比对模型与真实列才能发现。吸取 8.0.9 升级事故的教训。
    missing, err = check_missing_columns()
    if missing is None:
        log("! 表结构自检未能完成: %s" % err)
        missing = []
    elif missing:
        report_missing_columns(missing)
        if was_running:
            cmd_stop(argparse.Namespace(port=port))
            log("")
            log("  服务已停止：旧库结构不完整，继续运行只会不断报 no such column。")
        log("")
        log("× 升级未完成：版本已是 %s，但数据库结构不兼容，必须重建库。" % after)
        log("  备份已在上面，直接执行：upgrade --reset-db")
        return 1
    else:
        log("√ 表结构自检通过")

    if not changed:
        # 没真升上去就别重启，白白打断正在使用的人
        log("")
        log("已是最新且结构一致，无需重启。")
        if was_running:
            log("服务保持运行: http://127.0.0.1:%d" % port)
        return 0

    # 4) 让新代码生效
    if was_running:
        log("")
        log("服务升级前处于运行状态，正在重启以加载新版本...")
        cmd_stop(argparse.Namespace(port=port))
        time.sleep(1)
        cmd_start(argparse.Namespace(port=port, open=False, console=False))
        time.sleep(2)
        healthy = http_ok("http://127.0.0.1:%d" % port)
        log("重启后健康检查 : %s" % ("√正常" if healthy else ("×异常，请看日志 %s" % LOG_FILE)))
        log("访问地址       : http://127.0.0.1:%d" % port)
    else:
        log("服务当前未运行，需要时执行 start 即可。")
    return 0


# ---------------------------------------------------------------- CLI
def build_parser():
    p = argparse.ArgumentParser(description="SmartChart 本地安装与启动管理")
    sub = p.add_subparsers(dest="cmd")

    ins = sub.add_parser("install", help="安装本地 SmartChart")
    ins.add_argument("--python", help="用于创建虚拟环境的 Python 解释器路径")
    ins.add_argument("--port", type=int, default=DEFAULT_PORT, help="服务端口，默认 8000")
    ins.add_argument("--admin-user", default=DEFAULT_ADMIN)
    ins.add_argument("--admin-password", default=DEFAULT_PASSWORD)
    ins.add_argument("--index-url", help="pip 源（只用于拉依赖），默认阿里云镜像")
    ins.add_argument("--wheel-url", help="官网 whl 地址，默认 %s" % WHEEL_URL)
    ins.add_argument("--force", action="store_true", help="已存在时强制重装虚拟环境")
    ins.add_argument("--upgrade", action="store_true", help="升级 smartchart 而非首次安装")
    ins.set_defaults(func=cmd_install)

    st = sub.add_parser("start", help="启动服务（后台）")
    st.add_argument("--port", type=int)
    st.add_argument("--open", action="store_true", help="启动后自动打开浏览器")
    st.add_argument("--console", action="store_true", help="前台启动（调试）")
    st.set_defaults(func=cmd_start)

    sp = sub.add_parser("stop", help="停止服务")
    sp.add_argument("--port", type=int)
    sp.set_defaults(func=cmd_stop)

    rs = sub.add_parser("restart", help="重启服务")
    rs.add_argument("--port", type=int)
    rs.add_argument("--open", action="store_true")
    rs.set_defaults(func=cmd_restart)

    ss = sub.add_parser("status", help="查看运行状态")
    ss.add_argument("--port", type=int)
    ss.set_defaults(func=cmd_status)

    sc = sub.add_parser("shortcut", help="重新生成桌面快捷方式")
    sc.add_argument("--port", type=int)
    sc.set_defaults(func=cmd_shortcut)

    up = sub.add_parser("upgrade", help="升级 smartchart 到最新版本（备份数据库 + 自动重启）")
    up.add_argument("--port", type=int)
    up.add_argument("--index-url", help="pip 源（只用于拉依赖），默认阿里云镜像")
    up.add_argument("--wheel-url", help="官网 whl 地址，默认 %s" % WHEEL_URL)
    up.add_argument("--python", help="重建虚拟环境时使用的解释器（一般不填）")
    up.add_argument("--admin-user", default=None)
    up.add_argument("--admin-password", default=None)
    up.add_argument("--reset-db", dest="reset_db", action="store_true",
                    help="重建数据库（先备份再清空），修复升级后 no such column 报错")

    ck = sub.add_parser("check", help="检查数据库表结构与当前版本是否一致（只读，不改任何东西）")
    ck.set_defaults(func=cmd_check)

    mn = sub.add_parser("menu", help="交互式菜单（桌面快捷方式调用）")
    mn.set_defaults(func=cmd_menu)

    return p


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not getattr(args, "cmd", None):
        parser.print_help()
        return 0
    BASE.mkdir(parents=True, exist_ok=True)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        log("\n已中断")
        return 130
    except Exception as e:
        log("× 错误: %s" % e)
        return 1


if __name__ == "__main__":
    sys.exit(main())
