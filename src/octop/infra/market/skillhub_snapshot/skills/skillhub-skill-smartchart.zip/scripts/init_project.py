#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基于 SmartChart 初始化一个 Django 项目。

模板来源：assets/django-project/（参考 magiccube 项目的 settings.py / urls.py）
占位符：模板中的 __PROJECT__ 会替换成真实项目名；目录 project/ 会重命名为项目名。

子命令：
  init    生成项目骨架（可选装依赖 / 迁移 / 建管理员 / 启动）
  check   检查已有项目：结构、解释器、依赖版本、Django 自检
  run     启动开发服务
  stop    停止已启动的服务

仅依赖 Python 3 标准库。
"""

import argparse
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATE_DIR = SKILL_DIR / 'assets' / 'django-project'
PLACEHOLDER = '__PROJECT__'

PKG_NAME = 'smartchart'
MIN_VERSION = (8, 0)
PYPI_MIRROR = 'https://mirrors.aliyun.com/pypi/simple/'
PYPI_OFFICIAL = 'https://pypi.org/simple'
# 兜底：源上找不到包（PyPI 未发布 / 镜像滞后）时，用官网 whl 直装
WHEEL_URL = 'https://www.smartchart.cn/media/smartchart-8.0.9-py3-none-any.whl'

RUNTIME_DIRS = ['log', 'templates', 'static', 'media', '_files']
# 复制模板时跳过的目录（Python 可能在这些目录里留缓存）
SKIP_NAMES = ('__pycache__', '.DS_Store')


# ---------------------------------------------------------------- 基础工具


def log(msg):
    print(msg, flush=True)


def step(msg):
    print('\n==> %s' % msg, flush=True)


def run(cmd, cwd=None, env=None, capture=False, check=False):
    """执行命令；capture=True 时返回 (returncode, stdout, stderr)。"""
    if isinstance(cmd, list):
        printable = ' '.join(cmd)
    else:
        printable = cmd
    log('    $ %s' % printable)
    if capture:
        p = subprocess.run(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, text=True)
        if check and p.returncode != 0:
            raise RuntimeError('命令失败: %s\n%s' % (printable, p.stderr))
        return p.returncode, p.stdout, p.stderr
    rc = subprocess.run(cmd, cwd=cwd, env=env).returncode
    if check and rc != 0:
        raise RuntimeError('命令失败（退出码 %s）: %s' % (rc, printable))
    return rc


def is_windows():
    return os.name == 'nt'


def valid_name(name):
    return bool(re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', name)) and name != PLACEHOLDER


def parse_version(v):
    parts = []
    for p in str(v).split('.')[:3]:
        m = re.match(r'\d+', p)
        parts.append(int(m.group()) if m else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def port_in_use(port, host='127.0.0.1'):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, port)) == 0


def health_check(port, timeout=60):
    url = 'http://127.0.0.1:%s/' % port
    deadline = time.time() + timeout
    while time.time() < deadline:
        if port_in_use(port):
            try:
                with urllib.request.urlopen(url, timeout=3) as resp:
                    if resp.status < 500:
                        return True
            except Exception:
                pass
        time.sleep(1)
    return False


# ---------------------------------------------------------------- 项目生成


def render_templates(target_dir, name):
    """复制模板到目标目录，目录名 project/ 改成项目名，文本里的 __PROJECT__ 替换掉。

    模板文件用真实扩展名（不是 .tpl），所以一律按文本读入做替换，
    读不了的（二进制）原样复制。
    """
    created = []
    for item in sorted(TEMPLATE_DIR.rglob('*')):
        rel = item.relative_to(TEMPLATE_DIR)
        if any(p in SKIP_NAMES for p in rel.parts):
            continue
        # 模板目录 project/ → 真实项目名
        parts = [name if p == 'project' else p for p in rel.parts]
        dest = Path(target_dir).joinpath(*parts)

        if item.is_dir():
            dest.mkdir(parents=True, exist_ok=True)
            continue

        dest.parent.mkdir(parents=True, exist_ok=True)
        try:
            content = item.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            shutil.copy2(item, dest)
        else:
            dest.write_text(content.replace(PLACEHOLDER, name), encoding='utf-8')
        created.append(str(dest))
    return created


def create_runtime_dirs(target_dir):
    for d in RUNTIME_DIRS:
        p = Path(target_dir) / d
        p.mkdir(parents=True, exist_ok=True)
        keep = p / '.gitkeep'
        if not keep.exists():
            keep.write_text('', encoding='utf-8')


def apply_database(settings_path, db):
    """按 --engine 改写 settings.py 的 DATABASES 段（按哨兵注释替换）。"""
    if not db or db.get('engine', 'sqlite') == 'sqlite':
        return
    text = Path(settings_path).read_text(encoding='utf-8')
    block = """DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': '%(name)s',
        'USER': '%(user)s',
        'PASSWORD': '%(password)s',
        'HOST': '%(host)s',
        'PORT': '%(port)s',
    },
}""" % {
        'name': db.get('name', ''),
        'user': db.get('user', ''),
        'password': db.get('password', ''),
        'host': db.get('host', 'localhost'),
        'port': db.get('port', '3306'),
    }
    new_text, n = re.subn(
        r'# ============ DATABASE-START ============.*?# ============ DATABASE-END ============',
        block, text, flags=re.S)
    if n != 1:
        log('    ! 未找到 DATABASE 哨兵注释，请手工改 DATABASES')
        return
    Path(settings_path).write_text(new_text, encoding='utf-8')

    # Django 的 mysql 后端要 MySQLdb 接口，smartchart 自带 pymysql，这里做兼容注入
    init_file = Path(settings_path).parent / '__init__.py'
    inject = 'import pymysql\n\npymysql.install_as_MySQLdb()\n'
    content = init_file.read_text(encoding='utf-8') if init_file.exists() else ''
    if 'install_as_MySQLdb' not in content:
        init_file.write_text(content + '\n' + inject, encoding='utf-8')
    log('    数据库已切换为 MySQL，并在 %s 注入 pymysql 兼容' % init_file.name)


# ---------------------------------------------------------------- 环境相关


def project_meta_file(target_dir):
    return Path(target_dir) / '.smartchart' / 'project.json'


def write_project_meta(target_dir, name, python, port):
    """记录项目用的解释器，供 check / run / 仪表盘同步复用。"""
    meta = project_meta_file(target_dir)
    meta.parent.mkdir(parents=True, exist_ok=True)
    meta.write_text(json.dumps({
        'name': name, 'python': str(python), 'port': port,
        'created': time.strftime('%Y-%m-%d %H:%M:%S'),
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    return meta


def read_project_meta(target_dir):
    meta = project_meta_file(target_dir)
    if not meta.is_file():
        return None
    try:
        return json.loads(meta.read_text(encoding='utf-8'))
    except Exception:
        return None


def pick_python(target_dir, explicit=None):
    """--python > .smartchart/project.json 记录的解释器 > 当前解释器（系统 python）。

    不做 venv：多项目共用系统里那一份 smartchart，装一次到处可用。
    """
    if explicit:
        return explicit
    meta = read_project_meta(target_dir) or {}
    p = meta.get('python')
    if p and Path(p).exists():
        return p
    return sys.executable


def installed_version(python):
    code = ("import importlib.metadata as m;"
            "print(m.version('%s'))" % PKG_NAME)
    try:
        rc, out, err = run([python, '-c', code], capture=True)
        if rc == 0 and out.strip():
            return out.strip()
    except Exception:
        pass
    return None


def verify_smartchart(python):
    ver = installed_version(python)
    log('    smartchart 版本: %s' % (ver or '未知'))
    if ver and parse_version(ver) > MIN_VERSION:
        return ver
    raise RuntimeError(
        '装到的版本 %s 不满足要求（需 > 8.0）。'
        '换官方源或官网 whl 重试：--index-url %s / %s' % (ver, PYPI_OFFICIAL, WHEEL_URL))


def pip_install(target_dir, python, index_url=None, wheel_url=None):
    """只从官网 whl 装 smartchart（PyPI 后续可能不再发行）。

    index_url 只用于拉 Django 等依赖；包本身直连官网。
    """
    step('安装依赖 smartchart（官网 whl）')
    url = wheel_url or WHEEL_URL
    log('    官网 whl: %s' % url)
    cmd = [python, '-m', 'pip', 'install', url]
    if index_url:
        cmd += ['--index-url', index_url]
    rc, out, err = run(cmd, cwd=target_dir, capture=True)
    if rc == 0:
        return verify_smartchart(python)
    raise RuntimeError('依赖安装失败:\n%s' % ((err or out))[-2000:])


def manage(target_dir, python, args, env=None, check=False, capture=False):
    return run([python, 'manage.py'] + args, cwd=target_dir, env=env,
               check=check, capture=capture)


def migrate(target_dir, python):
    step('初始化数据库')
    manage(target_dir, python, ['makemigrations'], check=True)
    manage(target_dir, python, ['migrate'], check=True)
    log('    数据库已就绪: %s' % (Path(target_dir) / 'db.sqlite3'))


def create_superuser(target_dir, python, user, password):
    step('创建管理员 %s' % user)
    env = os.environ.copy()
    env['DJANGO_SUPERUSER_PASSWORD'] = password
    rc, out, err = manage(target_dir, python,
                          ['createsuperuser', '--noinput',
                           '--username', user,
                           '--email', '%s@example.com' % user],
                          env=env, capture=True)
    if rc == 0:
        log('    管理员已创建: %s / %s' % (user, password))
    else:
        log('    ! 创建失败（可能已存在或密码不合规则）: %s' %
            (err or out).strip().splitlines()[-1])


# ---------------------------------------------------------------- 服务启停


def start_server(target_dir, python, port, console=False):
    step('启动服务')
    if port_in_use(port):
        raise RuntimeError('端口 %s 已被占用，换一个 --port' % port)
    cmd = [python, 'manage.py', 'runserver', '0.0.0.0:%s' % port,
           '--insecure', '--noreload']
    if console:
        log('    前台运行，Ctrl+C 结束')
        run(cmd, cwd=target_dir)
        return None
    logfile = Path(target_dir) / 'server.log'
    with open(logfile, 'ab') as f:
        proc = subprocess.Popen(cmd, cwd=target_dir, stdout=f, stderr=f)
    (Path(target_dir) / '.smartchart.pid').write_text(str(proc.pid), encoding='utf-8')
    log('    后台启动 PID=%s，日志: %s' % (proc.pid, logfile))
    if health_check(port):
        log('    服务已就绪: http://127.0.0.1:%s' % port)
    else:
        log('    ! 未在 60s 内就绪，看日志: %s' % logfile)
    return proc.pid


def stop_server(target_dir):
    step('停止服务')
    pid_file = Path(target_dir) / '.smartchart.pid'
    if not pid_file.exists():
        log('    没有记录到 PID（服务可能不是本脚本启动的）')
        return
    pid = int(pid_file.read_text(encoding='utf-8').strip())
    try:
        if is_windows():
            run(['taskkill', '/PID', str(pid), '/F'])
        else:
            os.kill(pid, 15)
        log('    已停止 PID=%s' % pid)
    except Exception as e:
        log('    ! 停止失败: %s' % e)
    pid_file.unlink(missing_ok=True)


# ---------------------------------------------------------------- 子命令


def cmd_init(a):
    name = a.name
    if not valid_name(name):
        raise SystemExit('项目名不合法：%s（需为 Python 标识符，如 magiccube）' % name)

    target = Path(a.dir).expanduser().resolve() if a.dir else Path.cwd() / name
    if target.exists() and any(target.iterdir()) and not a.force:
        raise SystemExit('目录非空: %s\n加 --force 覆盖同名文件（不会删除已有文件）' % target)
    target.mkdir(parents=True, exist_ok=True)

    step('生成项目骨架: %s（项目名 %s）' % (target, name))
    files = render_templates(target, name)
    log('    写入 %s 个文件' % len(files))
    create_runtime_dirs(target)
    log('    运行时目录: %s' % '、'.join(RUNTIME_DIRS))

    apply_database(target / name / 'settings.py', {
        'engine': a.engine,
        'name': a.db_name, 'user': a.db_user, 'password': a.db_password,
        'host': a.db_host, 'port': a.db_port,
    })

    python = a.python or sys.executable
    meta = write_project_meta(target, name, python, a.port)

    if a.install:
        pip_install(target, python, a.index_url, a.wheel_url)

    if a.migrate:
        if not a.install and installed_version(python) is None:
            raise SystemExit('当前解释器里没有 smartchart，先 --install（装到该解释器），'
                             '或用 --python 指向已装好的 python')
        migrate(target, python)

    if a.superuser:
        create_superuser(target, python, a.admin_user, a.admin_password)

    step('完成')
    log('  项目目录 : %s' % target)
    log('  解释器   : %s' % python)
    log('  项目信息 : %s（仪表盘同步会用它找解释器）' % meta)
    log('  启动     : %s manage.py runserver 0.0.0.0:%s --insecure --noreload'
        % (python, a.port))
    log('  访问     : http://127.0.0.1:%s' % a.port)

    if a.run:
        start_server(target, python, a.port, console=a.console)


def cmd_check(a):
    target = Path(a.dir).expanduser().resolve()
    step('检查项目: %s' % target)
    name = a.name or guess_project_name(target)
    if not name:
        raise SystemExit('猜不出项目名，用 --name 指定')
    log('  项目名   : %s' % name)

    ok = True
    for f in ['manage.py', '%s/settings.py' % name, '%s/urls.py' % name,
              '%s/wsgi.py' % name]:
        p = target / f
        log('  %-28s %s' % (f, 'OK' if p.exists() else '缺失'))
        ok = ok and p.exists()
    for d in RUNTIME_DIRS:
        p = target / d
        log('  %-28s %s' % (d + '/', 'OK' if p.exists() else '缺失'))
        ok = ok and p.exists()

    python = pick_python(target, a.python)
    log('  解释器   : %s' % python)
    ver = installed_version(python)
    if ver is None:
        log('  smartchart: 未安装（python -m pip install -r requirements.txt）')
        ok = False
    else:
        good = parse_version(ver) > MIN_VERSION
        log('  smartchart: %s %s' % (ver, '(OK)' if good else '(需 > 8.0)'))
        ok = ok and good

    if ok and not a.skip_django_check:
        step('Django 自检 (manage.py check)')
        rc, out, err = manage(target, python, ['check'], capture=True)
        log((out or '') + (err or ''))
        ok = rc == 0
    log('\n结论: %s' % ('通过' if ok else '有问题，按上面的提示处理'))


def guess_project_name(target):
    """从 manage.py 里读 DJANGO_SETTINGS_MODULE 推断项目名。"""
    mp = Path(target) / 'manage.py'
    if mp.exists():
        m = re.search(r"DJANGO_SETTINGS_MODULE',\s*'([^']+)\.settings'",
                      mp.read_text(encoding='utf-8'))
        if m:
            return m.group(1)
    for p in Path(target).iterdir():
        if p.is_dir() and (p / 'settings.py').exists():
            return p.name
    return None


def cmd_run(a):
    target = Path(a.dir).expanduser().resolve()
    start_server(target, pick_python(target, a.python), a.port, console=a.console)


def cmd_stop(a):
    stop_server(Path(a.dir).expanduser().resolve())


# ---------------------------------------------------------------- 入口


def main():
    p = argparse.ArgumentParser(description='基于 SmartChart 初始化 Django 项目')
    sub = p.add_subparsers(dest='cmd', required=True)

    def add_common(sp):
        sp.add_argument('--dir', required=True, help='项目根目录')
        sp.add_argument('--python', help='指定解释器（默认：project.json 记录，其次当前 python）')
        sp.add_argument('--name', help='项目包名（默认自动推断）')

    # init
    pi = sub.add_parser('init', help='生成项目骨架')
    pi.add_argument('--name', required=True, help='项目名/包名，如 magiccube')
    pi.add_argument('--dir', help='目标目录（默认 ./<项目名>）')
    pi.add_argument('--force', action='store_true', help='目录非空时也生成')
    pi.add_argument('--python', help='指定解释器（默认当前 python，即系统那一份）')
    pi.add_argument('--install', action='store_true', help='安装依赖（smartchart 走官网 whl）')
    pi.add_argument('--index-url', help='pip 源，只用于拉 Django 等依赖（默认阿里云）')
    pi.add_argument('--wheel-url', help='官网 whl 地址，默认 %s' % WHEEL_URL)
    pi.add_argument('--migrate', action='store_true', help='执行 makemigrations + migrate')
    pi.add_argument('--superuser', action='store_true', help='创建管理员')
    pi.add_argument('--admin-user', default='admin')
    pi.add_argument('--admin-password', default='admin')
    pi.add_argument('--engine', choices=['sqlite', 'mysql'], default='sqlite')
    pi.add_argument('--db-name'), pi.add_argument('--db-user')
    pi.add_argument('--db-password'), pi.add_argument('--db-host', default='localhost')
    pi.add_argument('--db-port', default='3306')
    pi.add_argument('--run', action='store_true', help='生成后直接启动')
    pi.add_argument('--console', action='store_true', help='前台启动（看实时日志）')
    pi.add_argument('--port', type=int, default=8000)
    pi.set_defaults(func=cmd_init)

    # check
    pc = sub.add_parser('check', help='检查已有项目')
    add_common(pc)
    pc.add_argument('--skip-django-check', action='store_true')
    pc.set_defaults(func=cmd_check)

    # run
    pr = sub.add_parser('run', help='启动开发服务')
    add_common(pr)
    pr.add_argument('--port', type=int, default=8000)
    pr.add_argument('--console', action='store_true')
    pr.set_defaults(func=cmd_run)

    # stop
    ps = sub.add_parser('stop', help='停止服务')
    ps.add_argument('--dir', required=True)
    ps.set_defaults(func=cmd_stop)

    a = p.parse_args()
    try:
        a.func(a)
    except RuntimeError as e:
        print('\n[错误] %s' % e, file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
