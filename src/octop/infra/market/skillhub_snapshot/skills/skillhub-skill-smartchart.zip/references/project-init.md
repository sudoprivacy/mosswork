# 基于 SmartChart 初始化 Django 项目

用户需求示例：「用 smartchart 建个项目」「初始化一个 smartchart 项目」「搭个 Django 项目挂 smartchart」「照 magiccube 那样给我生成一套项目骨架」。

产出是一个**可自由扩展的自定义 Django 项目**（project 包 + manage.py），
`smartchart` 只是其中的一个普通依赖包，`smart_chart.echart / oa / scheduler` 以 app 形式挂进来。

## 先分清：这不是「本机安装 SmartChart」

| 场景 | 走哪份文档 |
|---|---|
| 想装一份能直接用的 SmartChart 服务、启停升级、桌面快捷方式 | `local-install.md`（`local_setup.py`） |
| 想**自己开发/扩展**，有自己的 app、自己的 settings 和 urls | **本文档**（`init_project.py`） |

两者不冲突：本地装好的实例可以照常用；本文档生成的是一个新的开发项目骨架。

## 快速执行

`{PY} = python3`，`{IP} = {SKILL_DIR}/scripts/init_project.py`

```bash
# 只生成骨架（smartchart 已装在系统 python 里时最常用）
{PY} {IP} init --name myproj --dir /path/to/myproj --migrate --superuser

# 一步到位：装依赖（装到系统 python）→ 初始化库 → 建管理员 → 启动
{PY} {IP} init --name myproj --dir /path/to/myproj \
    --install --migrate --superuser --run --port 8000

# 指定另一个已装好 smartchart 的解释器
{PY} {IP} init --name myproj --dir /path/to/myproj \
    --python ~/.smartchart/local/venv/bin/python3 --migrate --superuser

{PY} {IP} check --dir /path/to/myproj     # 体检：结构 / 解释器 / 版本 / manage.py check
{PY} {IP} run   --dir /path/to/myproj --port 8000 --console   # 启动（--console 前台看日志）
{PY} {IP} stop  --dir /path/to/myproj     # 停止（按 .smartchart.pid）
```

### 参数

| 参数 | 说明 |
|---|---|
| `--name` | 项目名/包名（必填，需是合法 Python 标识符，如 `magiccube`） |
| `--dir` | 目标目录，默认 `./<项目名>`；目录非空需加 `--force` |
| `--python` | 指定解释器，默认当前 python（系统那一份）；会记进 `.smartchart/project.json` 供后续复用 |
| `--install` | 安装 `requirements.txt`（`smartchart>8.0`） |
| `--index-url` | pip 源；默认阿里云，失败自动换 PyPI 官方 |
| `--migrate` | 跑 `makemigrations` + `migrate` |
| `--superuser` | 创建管理员，配合 `--admin-user` / `--admin-password`（默认 admin/admin） |
| `--engine mysql` + `--db-name/--db-user/--db-password/--db-host/--db-port` | 换 MySQL，默认 SQLite（项目根 `db.sqlite3`） |
| `--run` / `--port` / `--console` | 生成后启动；`--console` 前台运行看实时日志 |

> 只用标准库，Windows / macOS / Linux 都能跑。venv 路径自动适配 `Scripts` 或 `bin`。

## 生成出来的结构

```
myproj/
├── manage.py
├── myproj/                 # 项目包（模板里叫 project/，生成时重命名）
│   ├── settings.py         # 已挂 smart_chart.echart / oa / scheduler
│   ├── urls.py             # ''、m/、lg/、admin/、echart/、oa/、scheduler/ + .txt 验证文件
│   ├── wsgi.py / asgi.py
│   └── __init__.py
├── requirements.txt        # smartchart>8.0
├── README.md / .gitignore
├── .smartchart/project.json     # 记录本项目用的解释器（供 check / run / 仪表盘同步复用）
└── log/ templates/ static/ media/ _files/     # 运行时目录，已建好
```

模板源头是 magiccube 项目的 `settings.py` / `urls.py`，占位符 `__PROJECT__` 在生成时替换成项目名。
**`log/` 必须存在**——settings 里的日志 handler 不会自动建目录，缺了启动就报错。

## 环境：统一用系统 Python，不建 venv

- smartchart 装在系统 python 里，**一次安装，所有项目共用**；每个项目只是各自一套
  settings + urls + 自己的 `db.sqlite3`，互不干扰。
- 装依赖：`{PY} {IP} init ... --install`（等价 `python -m pip install -r requirements.txt`）。
  系统 python 装包若报权限不足，手工加 `--user`：
  `python -m pip install --user -r requirements.txt`。
- 解释器选择顺序：`--python` > 项目 `.smartchart/project.json` 记录的 > 当前 python。
  `check` / `run` / 仪表盘同步都按这个顺序找，不用每次重复指定。
- 本机那份 SmartChart 实例（local-install.md）的 venv 也能直接拿来用：
  `--python ~/.smartchart/local/venv/bin/python3`，不必再装一次。


## 生成之后

```bash
cd /path/to/myproj
python manage.py runserver 0.0.0.0:8000   # 启动
# 或用记录的解释器：{PY} {IP} run --dir /path/to/myproj --port 8000
```

- 访问 http://127.0.0.1:8000 ，管理员默认 `admin / admin`
- 改密码：`python manage.py changepassword 用户名`
- **v8.0 首次登录必做**：右上角头像 → 产品认证 → 激活高级功能 → 组件升级，否则组件不初始化
- 加自己的 app：`python manage.py startapp xxx`，再写进 `INSTALLED_APPS`



## 仪表盘 HTML 同步到本项目

项目模式下**模板目录是项目根 `templates/diy/`**（不是包内目录，因为自定义项目的
`settings.BASE_DIR` 指向项目根）。同步脚本会自动识别，不用手工拼路径：

```bash
{PY} {LD} --project /path/to/myproj list                       # 列出本项目的仪表盘
{PY} {LD} --project /path/to/myproj pull <id> -o /tmp/x.html   # 改之前先导出
{PY} {LD} --project /path/to/myproj push /tmp/x.html --id <id> # 写回
{PY} {LD} --project /path/to/myproj push /tmp/x.html --new "名称"
```

- `{LD}` = `{SKILL_DIR}/scripts/local_dashboard.py`
- 不写 `--project` 时，会从当前目录向上找 `manage.py`，找到就按项目模式跑，
  找不到才回退到 `~/.smartchart/local` 那份本地实例。
- 覆盖旧模板的备份落在 `<项目根>/.smartchart/diy_backup/`。
- 建仪表盘时若指定归属项目 id，参数是 `--proj-id`（别和 `--project` 混淆：
  后者是目录，前者是库里的项目分组）。
- ⚠️ 服务在跑的时候别动它的 sqlite（项目自己的 runserver 也一样），先 `stop` 再改库。

## 边界

- 本脚本只负责**骨架 + 环境 + 初始化**，不生成业务代码；页面/仪表盘 HTML 仍走 `html-guide.md`。
- 生成的项目里若要访问远程 SmartChart 服务器的数据集，仍需在
  `~/.smartchart/config.json`（或项目级 `.smartchart/config.json`）配 `base_url`，流程回到 `api-reference.md`。
