# 仪表盘 HTML 同步

把 Agent 生成的 HTML 同步到 SmartChart 仪表盘。脚本：`scripts/local_dashboard.py`（下文 `{DA}`）。

## 目标：项目 还是 本地实例

| 目标 | 怎么选 | 模板目录 |
|---|---|---|
| 用 `init_project.py` 建的 smartchart 项目 | `--project <项目根>`（**须写在子命令之前**）；不给则从 cwd 向上找 `manage.py` | **项目根 `templates/diy/`** |
| 本机实例（`local_setup.py install`） | 找不到 `manage.py` 时的兜底 | 包内 `smart_chart/templates/diy/` |

两者都由 Django 侧 `settings.BASE_DIR` 算出，脚本不拼路径。运行时开头会打印「目标」一行，先确认是不是你要的那个。

项目模式的解释器取自 `.smartchart/project.json`（`init_project.py` 生成时写入），也可用 `--python` 覆盖；多项目共用系统 python 里那一份 smartchart，不建 venv。

## 三条硬规则

1. **push 不能直接落盘裸 HTML**，先按平台保存逻辑套骨架（脚本 `wrap_as_template`）：
   内容已含 `{%` → 原样用；否则套 `baselite.html` 骨架（正文进 `body` block，
   **最后一个** `<script>` 搬进 `footer` block），其余内容一律不动。
   > 骨架是 `baselite.html`，不是 `base.html`（后者是 UI 编辑器那条路径）。
   > 旧说法「push 就是原样复制、不套 extends/block」已作废。
2. **改已有仪表盘 → 先 `pull` 出平台真实 HTML**，在它基础上改再 push 回去，不要凭空重写。
3. **推送目标必须核对名称 + 经用户确认**，不要图省事塞进随便一条已有仪表盘。

### 推送前确认清单

1. `{DA} list` → 拿 id + 名称 + 是否已有模板
2. 核对名称与用户诉求对得上；**对不上就停下来问用户**，不要猜 id
3. 向用户确认：id、名称、新建还是**覆盖已有模板**、旧模板会不会备份
4. 确认后再 push：新建 `--new "名称"`，覆盖 `--id <id>` 且**先 pull 一份存档**

## 用法

```bash
{PY} {DA} list                                   # 有哪些仪表盘、有没有自定义模板
{PY} {DA} pull <id> -o /tmp/board.html           # 【改之前必做】导出平台真实 HTML
{PY} {DA} push /tmp/board.html --id <id>         # 改完写回（自动备份 + 删旧）
{PY} {DA} push my.html --new "新仪表盘"           # 新建一条仪表盘记录并写入模板
{PY} {DA} show <id>                              # 看模板原文
{PY} {DA} remove-template <id>                   # 删掉自定义模板，回退 common.html
```

指定目标（也可用环境变量 `SMARTCHART_PROJECT`）：

```bash
{PY} {DA} --project /path/to/myproj list
{PY} {DA} --project /path/to/myproj push my.html --new "新仪表盘"
{PY} {DA} --project /path/to/myproj --python /path/to/python list
```

写完后浏览器强制刷新。**新建建议**：先在浏览器里建一条并由编辑器保存一次（id 和初始模板由平台生成，授权字段不缺），再用脚本 push 覆盖内容。

> `push --proj-id <n>` 是仪表盘在库里归属的项目分组 id，和 `--project`（目录）不是一回事。

## 存储位置

| 项 | 值 |
|---|---|
| 仪表盘记录 | 表 `echart_echartdashboardsetup_v2` |
| 模板目录 | 项目模式 `<项目根>/templates/diy/`；本地实例模式 `<site-packages>/smart_chart/templates/diy/` |
| 文件命名 | `{仪表盘id}_{时间戳}.html`，如 `1_1791780997.365382.html` |
| 无自定义模板 | 回退该目录 `common.html` |

写入沿用平台规则：按 `{id}_` 前缀找旧模板 → 写新的 `{id}_{时间戳}.html` → 删旧的。
覆盖前备份：项目模式 `<项目根>/.smartchart/diy_backup/`，本地实例模式 `~/.smartchart/local/diy_backup/`（`--no-backup` 可关）。

## 排障

| 现象 | 处理 |
|---|---|
| 改完浏览器没变化 | 强制刷新（Cmd/Ctrl+Shift+R） |
| 页面报模板语法错 | push 的文件缺骨架；`list` 找同类仪表盘，`pull` 一份照着写 |
| 组件拖不动 | 缺 `/*=start_drag=*//*=end_drag=*/` 标记块，或 `.smtdrag` 没写 `position:absolute` |
| `disk I/O error` | 别在服务运行时动它的库（项目模式同理，先停项目的 runserver）；受限环境也可能直接写不了 SQLite |
| 跑到了错误的目标 | 看输出开头「目标」一行；用 `--project` 显式指定，且必须写在子命令之前 |
| `找不到能 import smartchart 的解释器` | 系统 python 没装包：`python -m pip install -r requirements.txt`（权限不足加 `--user`），或 `--python` 指定 |
| 想回滚 | 从 `diy_backup/` 挑备份，用 `push` 覆盖回去 |

## 为什么修改必须先 pull

平台编辑器保存出来的是 Django 模板（不是裸 HTML）：

```
{% extends "echart/base.html" %}{% block head %}…{% endblock %}{% block body %}
<vue id="vue_app">{% for div in div_list %}{{div}}{% endfor %}…</vue>
{% endblock %}{% block javascript %}…{% endblock %}{% block footer %}{% endblock %}
```

凭空生成的对不上，所以**涉及修改一律先 `pull`**。新建场景不受此限制——内容由 Agent 决定，脚本只负责搬运与套骨架。
