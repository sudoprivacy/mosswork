# 本地安装 SmartChart

用户需求示例：「安装本地 smartchart」「本地部署一个 smartchart」「装一个 smartchart 到本机」「帮我把 smartchart 跑起来」。

统一走 **独立虚拟环境** 方案，不污染系统 Python，且重启/换目录都不丢数据。

## 快速执行（推荐直接用脚本）

`{PY} = python3`，`{LS} = {SKILL_DIR}/scripts/local_setup.py`

```bash
{PY} {LS} install                                   # 一键安装（建 venv → 装包 → 初始化库 → 建管理员 → 桌面快捷方式）
{PY} {LS} install --python /path/to/python3.12      # 指定解释器（官方推荐 3.12.x）
{PY} {LS} install --force                           # 强制重装（重建 venv，不动数据库）

{PY} {LS} upgrade            # 升级（推荐：备份数据库 → 装新版 → migrate → 自动重启）
{PY} {LS} upgrade --index-url https://pypi.org/simple   # 指定源

{PY} {LS} start --open        # 启动并自动开浏览器
{PY} {LS} status              # 看端口/进程/版本/账号/数据库路径
{PY} {LS} check               # 只读：检查库表结构与当前版本是否一致（缺字段会报 no such column）
{PY} {LS} stop                # 停止
{PY} {LS} restart --open      # 重启
{PY} {LS} menu                # 交互式菜单（桌面快捷方式调的就是它）
{PY} {LS} shortcut            # 重新生成桌面快捷方式
{PY} {LS} start --console     # 前台启动，实时看日志（调试用）
```

### upgrade 与 install --upgrade 的区别

两者都能升，`upgrade` 多做三件事，日常升级请用它：

| 行为 | `upgrade` | `install --upgrade` |
|---|---|---|
| 升级前后对比版本号，告知是否真升了 | √ | 静默 |
| 升级前备份数据库（`db.sqlite3.bak.<时间戳>`，自动保留最近 3 份） | √ | × |
| 服务在运行时自动重启以加载新版 | √ | ×（进程仍跑旧代码） |
| 已是最新时不重启（避免打断在线会话） | √ | — |

**注意**：别用 `install --force` 来「升级」，它会重建整个虚拟环境，代价远大于 `upgrade`。

### 装包来源：只认官网 whl

PyPI 后续可能不再发行 smartchart，所以 `install` / `upgrade` 都**直接装官网 whl**，


目标版本从 whl 文件名解析，跟 PyPI 无关。镜像滞后现在只可能影响依赖（Django 等）下载，
装不动就换源：`--index-url https://pypi.org/simple`。

脚本行为：

- 工作目录固定 `~/.smartchart/local/`，虚拟环境在 `~/.smartchart/local/venv`
- 默认管理员 `admin / admin`（可用 `--admin-user` / `--admin-password` 改）
- 默认端口 8000，被占用时先 `status` 排查，或 `--port 8001`
- pip 默认走阿里云镜像 `--index-url`（可覆盖），装包失败会自动换 PyPI 官方源重试一次
- **只从官网 whl 装 smartchart**：`https://www.smartchart.cn/media/smartchart-8.0.9-py3-none-any.whl`
  （PyPI 后续可能不再发行）。pip 源只用来拉 Django 等依赖
- 换新版：`--wheel-url <新版 whl 地址>`，或用环境变量 `SMARTCHART_WHEEL_URL`
- TLS 校验全程开启：不用 `--trusted-host`，查询版本也不关校验
- 快捷方式与菜单都用 **venv 里的解释器**跑，不依赖系统 python

## 目录与文件

| 路径 | 用途 |
|---|---|
| `~/.smartchart/local/venv` | 独立虚拟环境 |
| `~/.smartchart/local/server.log` | 运行日志，排障先看这里 |
| `~/.smartchart/local/local.json` | 端口、版本、管理员、数据库、快捷方式路径 |
| `~/.smartchart/local/smartchart.pid` | 进程 PID |
| 数据库 | 不一定在上面，见下方「数据库不一定在 BASE 里」 |
| `<数据库>.bak.<时间戳>` | `upgrade` 自动生成的备份，保留最近 3 份 |
| `<数据库>.before-reset.<时间戳>` | `upgrade --reset-db` 重建前生成的备份 |
| `~/.smartchart/trash/` | `--reset-db` 移走的旧库（不是永久删除） |

### ⚠️ 数据库在哪：固定在 HOME 下，跟 cwd 无关（实测修正）

**结论：数据库实际路径是 `~/.smartchart/db.sqlite3`，与当前工作目录无关。**

实测证据：把 cwd 切到 `/tmp/sctest` 并在该目录放一份 `config.ini`，执行 `smartchart shell -c` 打印
`connection.settings_dict['NAME']`，得到的仍是 `/Users/johnyan/.smartchart/db.sqlite3`。

> 早期这里写的是「沿 cwd 向上逐级查找 config.ini」，那其实是从
> 「看到了 `local/db.sqlite3` 空壳」反推出来的猜测，已被上面的实测推翻。
> 库往 HOME 落盘，是 SmartChart 自身的行为，不是本脚本能左右的。

影响：

- 换目录启动**不会**生成新空库，之前担心的「管理员账号丢失」不会发生
- `~/.smartchart/local/db.sqlite3` 若出现，只是无害的空壳，可以忽略或删掉
- 判断依据永远看 `{PY} {LS} status` 的「数据库」一行（脚本实测得出的真实路径），不要靠猜

```bash
{PY} {LS} status            # 关注最后几行：数据库 / 访问地址 / 管理员
```


## 桌面快捷方式

`install` 会自动生成，也可单独 `{PY} {LS} shortcut` 重建：

| 平台 | 文件 |
|---|---|
| macOS | `~/Desktop/smartchart.command` |
| Windows | `%USERPROFILE%` 下的 `Desktop/smartchart.bat`（自动兼容 OneDrive 重定向桌面） |
| Linux | `~/Desktop/smartchart.desktop` |

**双击后进入菜单，而不是无条件启动**：

```
   SmartChart 本地服务
   当前状态: ● 运行中     地址: http://127.0.0.1:8000

   [1] 启动服务（并自动打开浏览器）
   [2] 停止服务
   [3] 重启服务
   [4] 查看详细状态
   [5] 打开浏览器
   [0] 退出本窗口
```

要点：

- 快捷键里调用的解释器必须是 **venv 里的 python**（`~/.smartchart/local/venv/bin/python3`），
  与被管理的服务进程同环境，不依赖系统 python。`make_shortcut()` 已自动取 `venv_python()`；
  仅当 venv 不存在时才退回当前解释器，所以重装后记得再跑一次 `shortcut`。
- 旧命名 `启动 SmartChart.*` 会被 `shortcut` 自动清理。
- 菜单在非交互环境（无 stdin）会提示改用命令行子命令，不会卡死。
- macOS 首次双击若被拦截：右键 → 打开；或 `xattr -d com.apple.quarantine ~/Desktop/smartchart.command`
