# 拖拽布局模式（Draggable Layout）

用户要求「可拖拽 / 拖拽布局 / 自由布局 / 大屏可编辑」时启用；未提及则用常规 grid / flex。**拖拽只是布局层选项**，看板 demo 与系统页面都能叠加，数据层规范不变。

## 硬约束

1. **定位只写在回写块内**：平台拖拽后仅覆盖 `/*=start_drag=*/` 与 `/*=end_drag=*/` 之间的内容，因此组件的 `top/left/width/height` 只能出现在块内。块外（含内联 style）不得残留，否则拖完会被旧样式顶回去。
2. **组件标记**：`<div class="card smtdrag" id="idsmt_N">`；`class` 必含 `smtdrag`，`id` 按 DOM 顺序从 `idsmt_0` 连续递增。外观（背景 / 边框 / 字号等）写在组件自身 class 上，不要给 `.smtdrag` 写视觉样式；但下列基础样式**必须写入**（拖拽定位依赖它，可放在任意 `<style>` 内）：

```css
*{margin:0;padding:0}
html,body{height:100%;width:100%}
.smtdrag{position:absolute}
```

如需边框盒模型，可在 `*` 选择器追加 `box-sizing:border-box`。
3. **顶层扁平挂载**：所有 `.smtdrag` 直接挂在 `<body>` 下，中间不套任何容器；放进卡片 / 栅格 / flex 子项会让百分比相对错误父容器计算，拖拽必漂移。组件**内部**排版不限。

## 回写块

```html
<style>
/*=start_drag=*/
#idsmt_0{top:2.6%;left:1.5%;width:40.2%;height:43.5%}
#idsmt_1{top:2.9%;left:44%;width:35.2%;height:42.7%}
/*=end_drag=*/
</style>
```

一个组件一行，禁止合并选择器（回写会整行替换）；块内只放定位。

## 定位值

- `%` 单位、保留 1 位小数；初始按网格切分，**留 1%~2% 间隙互不重叠**；
- 只写 `top + left + width + height`，不写 right / bottom、不用 transform；层叠用 `z-index`。

## DOM 骨架

```html
<body>
  <div class="card smtdrag" id="idsmt_0">…KPI 指标卡…</div>
  <div class="card smtdrag" id="idsmt_1">…图表容器…</div>
</body>
```

适合做拖拽单元：指标卡、图表容器、地图 / 拓扑、排行榜 / 列表、图片、标题栏。浮层类控件（导航、弹窗、抽屉、分页器）不进拖拽体系。

## 自查

- `smtdrag` id 连续递增；
- 含上述三段基础样式（reset + 撑满 + `.smtdrag{position:absolute}`）；
- 定位属性零残留于回写块外，`.smtdrag` 上无视觉样式；
- 全部为 `<body>` 直接子元素；
- 百分比 1 位小数，初始不重叠。
