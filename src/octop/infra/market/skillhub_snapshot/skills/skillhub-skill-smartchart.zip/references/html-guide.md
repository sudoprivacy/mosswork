# HTML 生成规范

生成 HTML 前**先判断要哪一类**：

| 用户诉求 | 产物 | 数据怎么来 |
|---|---|---|
| 「看板」「报表」「仪表盘」「分析」 | **看板 demo**：纯展示，无业务交互 | 数据内嵌 `ds` 变量 |
| 「系统」「需求系统」「页面」「功能」 | **系统页面**：真实业务页（有查询、有提交），可直接复制进 SmartChart 跑 | `ds_refresh` / `ds_save` 占位接口 |

> 用户若提出「可拖拽 / 拖拽布局 / 自由布局 / 大屏可编辑」，先按上表定型（数据流不变），再叠加 **`references/drag-layout.md`** 的拖拽布局约定后一并产出。


## 通用禁止（两类都适用）

- 不做后端服务、不做本地代理
- **不在浏览器端（HTML/JS）里写 `fetch` 调 SmartChart API**
- 密钥（`secret_key`、`visitor` 等）绝不写入 HTML 或任何前端代码

## 数据集 ID 约定

- **查询与保存是两个不同的数据集**，各用一个 ID，**不要复用同一个**。
- 注册表里没有明确 ID 时，按用户默认编号约定给缺省值：

  | ID | 用途 | 走哪个接口 |
  |---|---|---|
  | `0` | 表格类查询（默认） | `ds_refresh` |
  | `1` | 保存（写入 / 更新） | `ds_save` |
  | `2` | 选项 / 下拉来源（设备台账、人员名单等） | `ds_refresh` |

- 因此 `DS` 通常按「业务语义 + 查询/保存分离」命名：

```js
// 0=表格查询  1=保存  2=选项(下拉来源)
const DS = { inspectionQuery: 0, inspectionSave: 1, equipment: 2 };
```

---

## A. 看板 / 报表 demo

1. **数据嵌入**：JS 二维数组变量（如 `var ds = [[表头行], [数据行], ...]`），首行为表头，字段与数据集一致；**嵌入不超过 500 条**，超出先筛选 / 汇总 / 分层。
2. **数据与渲染分离**：数据集中在 `ds` 变量，渲染逻辑**按表头名建索引**读取，不硬编码列位置。
3. **写入 / 更新**：生成对应的数据格式变量占位即可。

**用户侧流程**：复制 HTML 进 SmartChart，用查询结果替换 `ds` 变量即可动态更新，渲染逻辑无需改动。

---

## B. 系统页面（可直接复制进 SmartChart 运行）

生成**真实业务系统页**，查询与提交只做**占位**，不写 `fetch`、不写模拟后端。

### 接入层：三个接入函数（查询 / 提交 / 上传）

全站唯一的数据出入口，业务代码只调这三个：

```js
// 数据集 ID 集中管理（0=表格查询 1=保存 2=选项；查询与保存是不同数据集）
const DS = { inspectionQuery: 0, inspectionSave: 1, equipment: 2 };

// ① 查询：同步返回 data 二维数组（首行表头）
function ds_refresh(id, param, type) {
  return SEED[id];          // 占位种子数据，接好后删除此行
}

// ② 提交：mode 0=写入(单条字典, 不含 id) / 1=更新({id, 变更字段})
function ds_save(id, content, mode) {
  console.log('[SmartChart.save] dataset=' + id + ' mode=' + mode, content);
  return { status: 200, msg: '成功' };
}

// ③ 上传文件：异步，结果只在回调里拿（平台内置函数，接好后整个删掉）
function ds_uploadfile(blob, filename, name, callback, ossConfig) {
  console.log('[SmartChart.upload]', filename);
  callback({ url: URL.createObjectURL(blob) });   // 占位：本地可预览，接好后删除
}
```

### 调用约定（必须严格遵守）

- **查询**：`let data = ds_refresh(id, param, 'list')`；无参数时 `ds_refresh(id, null, 'list')`。
- **提交**：`let res = ds_save(id, content, mode)`。
  - **写入（mode 0）**：单记录用**普通字典**，键为字段名、**不含 id**（id 服务端自增）：

    ```js
    ds_save(DS.inspectionSave, {'设备编码':'EQ-001', '点检结果':'正常' }, 0)
    ```

  - **更新（mode 1）**：**只提交 `id` + 发生变化的字段**（差量），未改字段不要重复提交：

    ```js
    ds_save(DS.inspectionSave, { id: 2, '状态':'已处理' }, 1)
    ```

- **上传**：`ds_uploadfile(blob, filename, null, callback)`，**异步**——url只在 `callback` 里拿。
- 数据集 ID 一律走 `DS.xxx`，**不在业务代码里硬编码数字**；保存用「保存集」ID、查询用「查询集」ID。

### 数据结构与渲染

- 所有数据为二维数组、首行表头；渲染逻辑**按表头名建索引**，不硬编码列位置。
- 页面加载时用 `ds_refresh` 拉数据到运行时变量，再由渲染函数消费。
- **表头必须来自 `ds_refresh` 的真实返回，不能从 `SEED` 取**。加载时把返回首行存为运行时表头变量（如 `let inspHeader = ins[0]`），渲染 / 索引 / 提交一律用该变量。这样删掉 `SEED` 后业务函数照常工作——**业务函数里禁止出现 `SEED[...]`，SEED 只允许出现在 `ds_refresh` 占位那一行**。
- **后台自动记录的字段**（操作人、创建时间等）前端**不要提交**，表单里做成只读展示即可。
- 选项数据集常带附加字段；选中某项时用该字段**自动带出**到表单对应输入框，减少手填。
- **每个业务流程都要接上 `ds_save`**（提交表单、状态流转、状态变更），让「下单 → 处理 → 完成」全链路都有数据落库，而不是只有个演示按钮。


### 去 demo 化

- 系统页面里**不要**出现「模拟」「演示 Demo」「原型」等措辞；按钮写真实动作（「提交」「查询」「核验」），不写「模拟核验」。
- `SEED` 仅作占位预览，注释标明「接好真实后端后删除 `return SEED[id]`」。
