# SmartChart API 参考

占位符：`{PY}` = `python3`，`{SCRIPT}` = `{SKILL_DIR}/scripts/smartchart_client.py`。

## 连通性

```bash
{PY} {SCRIPT} ping
```

## 查询 query-post

```bash
# 全量查询：返回二维数组，第一行为表头
{PY} {SCRIPT} query-post --dataset <数据集ID> --param '{"参数A":"值"}'

# 分页：传 pagesize + pg，每页 data 均含表头，total 为总行数
{PY} {SCRIPT} query-post --dataset <ID> --pagesize 100 --pg 1 --param '{"参数A":"值"}'
```

### 落盘选项（大数据保护）

```bash
{PY} {SCRIPT} query-post --dataset <ID> --param '{...}' --save              # 自动落盘到 smartchart_results/
{PY} {SCRIPT} query-post --dataset <ID> --save /path/to/out.csv --format csv # 指定路径与格式（csv/json/tsv/xlsx，默认 csv）
{PY} {SCRIPT} query-post --dataset <ID> --full                              # 强制打印全量（仅调试小数据）
{PY} {SCRIPT} query-post --dataset <ID> --threshold 50                      # 调整自动落盘阈值（默认 100）
{PY} {SCRIPT} query-post --dataset <ID> --no-save                           # 临时关闭自动落盘
```

- 默认：行数 > `--threshold`（默认 100）或估算字符量 > 20000 时自动落盘，无需显式 `--save`。
- 落盘目录 `smartchart_results/`，文件名 `<数据集名>_<时间戳>.csv`。
- 落盘后脚本只输出「摘要 + 文件路径」，不输出全量数据。

## 写入 write（新增）

二维数组，第一行为表头，**仅第一个字段名加 `__` 前缀**（如 `__字段A, 字段B`）启用自定义表头；`id` 由服务端自增，无需传。

```bash
{PY} {SCRIPT} write --dataset <数据集ID> --ds '[["__字段A","字段B"],["值1","值2"],["值3","值4"]]'
```

- `update` 参数必须传数字（`write` 命令默认传 0）
- 审计字段（`create_time` / `update_time` / `updater`）由服务端自动填充

## 更新 update（按主键）

字典数组，每行含主键字段 + 要改的字段。**二维数组不能用于更新。**

```bash
{PY} {SCRIPT} update --dataset <ID> --ds '[{"id":1,"name":"新值"},{"id":2,"name":"新值2"}]'
```

## 智能问数 / 路由型数据集

部分数据集（如「智能问数」）不直接返回数据，而返回路由指令（`data.msg` 为内嵌 JSON 字符串）：

```json
{"tool":"askdata","msg":"查询2024年各区域销售情况","param":{"table":"","name":""}}
```

- `tool`：下一步要调用的真实数据集名称
- `msg`：自然语言提示词，自动转为下一步的 `prompt` 参数
- `param`：附加查询参数，非空值带入（自动过滤空字符串）

`ask` 命令自动完成「调路由数据集 → 解析路由 → 调真实数据集」两次调用，返回第二次结果；鉴权失败或解析不到路由时返回第一步原始结果：

```bash
{PY} {SCRIPT} ask --dataset <路由数据集ID> --prompt "查询2024年各区域销售情况" [--param '{"额外参数":"值"}']
```

## Python 模块调用

```python
import sys
sys.path.insert(0, "{SKILL_DIR}/scripts")
from smartchart_client import SmartChartClient

client = SmartChartClient()   # 默认读 ~/.smartchart/config.json，可传路径覆盖
result = client.query_post(dataset_id=123, param={"参数A": "值"}, pagesize=100, pg=1)
client.write(dataset_id=123, ds=[["__A","B"],["a1","b1"]])      # 新增
client.update(dataset_id=123, ds=[{"id": 1, "name": "新值"}])   # 更新
```

## 返回格式

| 操作 | 关键字段 | 说明 |
|---|---|---|
| 查询（不分页） | `data`, `result`, `maxpg`, `pg` | `data` 二维数组首行为表头；`maxpg`/`pg` 固定为 1 |
| 查询（分页） | `data`, `status`, `msg`, `maxpg`, `pg`, `total` | `status=200` 成功；`total` 为总行数，每页 `data` 均含表头 |
| 写入 / 更新 | `status`, `msg` | `status=200` 成功 |
| ping | `status`, `msg` | 连通性结果 |

## 大数据处理约定（Agent 必须遵守）

原则：**数据落盘为文件，对话只留「摘要 + 文件路径」，分析时从文件读。**

1. 数据量大时（注册表 `notes` 标注、用户要求、行数超阈值）加 `--save`，或分页逐页取数。
2. 落盘后只读摘要（行数 / 列数 / 表头 / 前 3 行预览 / 路径），**绝不把数据行复制回对话**。
3. 分析时读文件：`csv`/`tsv`/`json` 用 Read 工具或 `{PY}` 脚本；`xlsx` 用 `{PY}` 脚本（openpyxl/pandas）。
4. 交付物放工作目录并 `present_files` 呈现，不把原始数据贴进对话。

默认 csv（纯文本，Read 可直接读）；需用户用 Excel 打开时再 `--format xlsx`。

## 数据集管理

```bash
{PY} {SCRIPT} list-datasets
{PY} {SCRIPT} add-dataset --id 123 --name "销售数据" --desc "查询各区域销售" --operation query
{PY} {SCRIPT} remove-dataset --id 123
```

也可直接编辑注册表文件（`~/.smartchart/datasets.json` 或项目级）。
