#!/usr/bin/env -S /Users/eriklee/.local/bin/uv run
# /// script
# requires-python = ">=3.11"
# dependencies = [
#   "openai>=1.76.0",
# ]
# ///

from __future__ import annotations

import argparse
import base64
import datetime as dt
import getpass
import json
import os
import re
import sys
from contextlib import ExitStack
from pathlib import Path
from typing import Any

from openai import OpenAI


STYLE_PROFILES = {
    "flat-tech-infographic": {
        "style_text": (
            "flat technical infographic illustration, clean grouped modules, clear arrows, "
            "soft professional palette, concise bilingual labels, document-friendly composition"
        ),
    },
    "flat-illustration": {
        "style_text": (
            "flat illustration, simple geometric forms, concise annotations, soft editorial look"
        ),
    },
    "sketchnote": {
        "style_text": (
            "hand-drawn sketchnote style, notebook feel, soft linework, compact explanatory callouts"
        ),
    },
    "soft-tech-diagram": {
        "style_text": (
            "soft technical diagram, subtle dashed containers, layered modules, light academic visual language"
        ),
    },
    "repo-architecture-clean": {
        "style_text": (
            "clean repository architecture diagram, crisp blocks, restrained decoration, "
            "clear ownership and dependency labels"
        ),
    },
}

SIZE_PRESETS = {
    "doc-hd": "1536x1024",
    "doc-2k": "2048x1152",
    "doc-4k": "3840x2160",
    "3:2": "1536x1024",
    "1:1": "1024x1024",
    "16:9": "1536x1024",
    "auto": "auto",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate technical document illustrations.")
    parser.add_argument("--brief", help="Short illustration brief.")
    parser.add_argument("--brief-file", help="Path to a UTF-8 text file containing the brief.")
    parser.add_argument("--title", default="doc-illustration")
    parser.add_argument("--mode", choices=["text-only", "reference+text"], default="text-only")
    parser.add_argument("--reference-image", action="append", default=[])
    parser.add_argument(
        "--style-profile",
        default="flat-tech-infographic",
        choices=sorted(STYLE_PROFILES),
    )
    parser.add_argument("--size", default="auto")
    parser.add_argument(
        "--quality",
        default="auto",
        choices=["auto", "high", "medium", "low"],
    )
    parser.add_argument("--language", default="zh-en")
    parser.add_argument("--output-dir", default="output/doc-illustration")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def load_brief(args: argparse.Namespace) -> str:
    parts: list[str] = []
    if args.brief:
        parts.append(args.brief.strip())
    if args.brief_file:
        parts.append(Path(args.brief_file).read_text(encoding="utf-8").strip())
    brief = "\n\n".join(part for part in parts if part)
    if not brief:
        raise SystemExit("Error: provide --brief or --brief-file.")
    return brief


def normalize_reference_images(paths: list[str]) -> list[str]:
    normalized: list[str] = []
    for raw_path in paths:
        path = Path(raw_path).expanduser().resolve()
        if not path.is_file():
            raise SystemExit(f"Error: reference image not found: {path}")
        normalized.append(str(path))
    return normalized


def slugify(text: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return slug or "doc-illustration"


def get_api_settings(require_key: bool) -> tuple[str | None, str | None]:
    api_key = os.getenv("OPENAI_API_KEY")
    base_url = os.getenv("OPENAI_BASE_URL")
    if api_key:
        return api_key, base_url
    if not require_key:
        return None, base_url
    if sys.stdin.isatty() and sys.stderr.isatty():
        api_key = getpass.getpass("OPENAI_API_KEY is missing. Enter a temporary key: ").strip()
        if api_key:
            return api_key, base_url
    raise SystemExit(
        "Error: OPENAI_API_KEY is required. Set it in your shell, for example:\n"
        "  export OPENAI_API_KEY='sk-...'\n"
        "  export OPENAI_BASE_URL='https://your-proxy.example/v1'  # optional"
    )


def resolve_model_name(base_url: str | None) -> str:
    if not base_url:
        return "gpt-image-2"
    normalized = base_url.rstrip("/").lower()
    if normalized.startswith("https://api.ofox.ai/v1"):
        return "openai/gpt-image-2"
    return "gpt-image-2"


def detect_diagram_type(brief: str) -> str:
    lower = brief.lower()

    repo_terms = (
        "repo",
        "repository",
        "codebase",
        "folder structure",
        "directory structure",
        "module relationship",
        "module dependency",
        "package structure",
        "目录",
        "仓库",
    )
    if any(term in lower for term in repo_terms):
        return "repo architecture diagram"
    if any(token in lower for token in ("process", "workflow", "步骤", "流程")):
        return "process diagram"
    if any(token in lower for token in ("knowledge", "card", "指南", "总结", "笔记")):
        return "knowledge card"
    if any(token in lower for token in ("architecture", "system", "服务", "架构")):
        return "architecture diagram"
    return "technical infographic"


def build_prompt(
    *,
    brief: str,
    title: str,
    mode: str,
    style_profile: str,
    language: str,
    size_label: str,
    reference_images: list[str],
) -> str:
    style_text = STYLE_PROFILES[style_profile]["style_text"]
    diagram_type = detect_diagram_type(brief)
    ref_clause = ""
    if mode == "reference+text" and reference_images:
        ref_clause = (
            "Use the provided reference image or images only for style guidance such as palette, "
            "line quality, spacing, icon treatment, and annotation tone. "
            "Do not copy their literal subject matter. "
            f"Reference count: {len(reference_images)}. "
        )
    return (
        f"Create a polished technical document illustration titled '{title}'. "
        f"Diagram type: {diagram_type}. "
        f"Use a {style_text}. "
        "Make it suitable for insertion into engineering notes or a design document. "
        "Prefer a clear information hierarchy with section titles, concise Chinese/English labels, "
        "short notes, arrows, grouped modules, and strong readability. "
        "Avoid dense paragraph blocks. "
        f"Language mode: {language}. "
        f"Target aspect ratio preset: {size_label}. "
        f"Mode: {mode}. "
        f"{ref_clause}"
        f"Content brief:\n{brief}"
    ).strip()


def make_output_paths(output_dir: str, title: str) -> tuple[Path, Path]:
    ts = dt.datetime.now().strftime("%Y%m%d-%H%M")
    stem = f"{ts}-{slugify(title)}"
    output_root = Path(output_dir).expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    return output_root / f"{stem}.png", output_root / f"{stem}.json"


def metadata_dict(
    *,
    args: argparse.Namespace,
    brief: str,
    prompt: str,
    reference_images: list[str],
    image_path: Path | None,
    model_name: str,
) -> dict[str, Any]:
    return {
        "title": args.title,
        "brief": brief,
        "mode": args.mode,
        "style_profile": args.style_profile,
        "size": args.size,
        "resolved_size": SIZE_PRESETS.get(args.size, args.size),
        "quality": args.quality,
        "language": args.language,
        "model": model_name,
        "reference_images": reference_images,
        "prompt": prompt,
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        "output_files": [str(image_path)] if image_path else [],
        "dry_run": args.dry_run,
    }


def build_client(api_key: str | None, base_url: str | None) -> OpenAI:
    kwargs: dict[str, Any] = {}
    if api_key:
        kwargs["api_key"] = api_key
    if base_url:
        kwargs["base_url"] = base_url
    return OpenAI(**kwargs)


def generate_text_only(
    client: OpenAI,
    model_name: str,
    prompt: str,
    size: str,
    quality: str,
) -> bytes:
    response = client.images.generate(
        model=model_name,
        prompt=prompt,
        n=1,
        size=size,
        quality=quality,
    )
    return base64.b64decode(response.data[0].b64_json)


def generate_from_reference(
    client: OpenAI,
    model_name: str,
    prompt: str,
    size: str,
    reference_images: list[str],
    quality: str,
) -> bytes:
    with ExitStack() as stack:
        image_files = [stack.enter_context(open(path, "rb")) for path in reference_images]
        response = client.images.edit(
            model=model_name,
            image=image_files,
            prompt=prompt,
            size=size,
            quality=quality,
        )
    return base64.b64decode(response.data[0].b64_json)


def main() -> int:
    args = parse_args()
    brief = load_brief(args)
    reference_images = normalize_reference_images(args.reference_image)
    if args.mode == "reference+text" and not reference_images:
        raise SystemExit("Error: reference+text mode requires at least one --reference-image.")

    resolved_size = SIZE_PRESETS.get(args.size, args.size)
    _, preview_base_url = get_api_settings(require_key=False)
    model_name = resolve_model_name(preview_base_url)
    prompt = build_prompt(
        brief=brief,
        title=args.title,
        mode=args.mode,
        style_profile=args.style_profile,
        language=args.language,
        size_label=args.size,
        reference_images=reference_images,
    )
    image_path, meta_path = make_output_paths(args.output_dir, args.title)

    if args.dry_run:
        metadata = metadata_dict(
            args=args,
            brief=brief,
            prompt=prompt,
            reference_images=reference_images,
            image_path=None,
            model_name=model_name,
        )
        meta_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        print("Mode: dry-run")
        print(f"Style: {args.style_profile}")
        print(f"Model: {model_name}")
        print(f"Prompt saved to: {meta_path}")
        print(json.dumps(metadata, ensure_ascii=False, indent=2))
        return 0

    api_key, base_url = get_api_settings(require_key=True)
    model_name = resolve_model_name(base_url)
    client = build_client(api_key, base_url)

    if args.mode == "reference+text":
        image_bytes = generate_from_reference(
            client,
            model_name,
            prompt,
            resolved_size,
            reference_images,
            args.quality,
        )
    else:
        image_bytes = generate_text_only(
            client,
            model_name,
            prompt,
            resolved_size,
            args.quality,
        )

    image_path.write_bytes(image_bytes)
    metadata = metadata_dict(
        args=args,
        brief=brief,
        prompt=prompt,
        reference_images=reference_images,
        image_path=image_path,
        model_name=model_name,
    )
    meta_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")

    print("Mode: generate")
    print(f"Style: {args.style_profile}")
    print(f"Image: {image_path}")
    print(f"Metadata: {meta_path}")
    print(f"Markdown: ![{args.title}]({image_path})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
