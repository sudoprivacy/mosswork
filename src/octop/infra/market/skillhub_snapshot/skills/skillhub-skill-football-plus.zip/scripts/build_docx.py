#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把「赛事洞悉」Markdown 报告转换为 Word 文档 (.docx)。

用法:
    python build_docx.py --md 赛事洞悉_X_vs_Y.md --out 赛事洞悉_X_vs_Y.docx

支持:
- # / ## / ### 标题
- > 引用块
- --- 分隔线
- | 表头 | 单元格 | 管道表格 (自动识别分隔行)
- 以 \\t 分隔的模型表 (如「模型共识」段)
- - / * 无序列表
- **加粗** 行内样式
- 中文使用「微软雅黑」字体，表格带网格线与表头底色
"""
import argparse
import re
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

CJK_FONT = "Microsoft YaHei"


def _set_cjk(run):
    run.font.name = CJK_FONT
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn('w:eastAsia'), CJK_FONT)
    rfonts.set(qn('w:ascii'), CJK_FONT)
    rfonts.set(qn('w:hAnsi'), CJK_FONT)


def set_style_cjk(style, size=None, color=None, bold=None):
    style.font.name = CJK_FONT
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn('w:eastAsia'), CJK_FONT)
    rfonts.set(qn('w:ascii'), CJK_FONT)
    rfonts.set(qn('w:hAnsi'), CJK_FONT)
    if size is not None:
        style.font.size = Pt(size)
    if color is not None:
        style.font.color.rgb = color
    if bold is not None:
        style.font.bold = bold


def add_bottom_border(paragraph):
    p = paragraph._p
    pPr = p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '6')
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), 'BBBBBB')
    pBdr.append(bottom)
    pPr.append(pBdr)


def add_runs(paragraph, text):
    parts = re.split(r'(\*\*[^*]+\*\*)', text)
    for part in parts:
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            run = paragraph.add_run(part[2:-2])
            run.bold = True
        else:
            run = paragraph.add_run(part)
        _set_cjk(run)


def make_table(doc, rows, header=True):
    rows = [[c for c in r] for r in rows]
    # 去除每行的尾部空单元格，避免多余空列
    for r in rows:
        while r and r[-1] == '':
            r.pop()
    ncol = max(len(r) for r in rows) if rows else 1
    table = doc.add_table(rows=len(rows), cols=ncol)
    try:
        table.style = 'Table Grid'
    except Exception:
        pass
    table.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for i, row in enumerate(rows):
        cells = row + [''] * (ncol - len(row))
        for j, val in enumerate(cells):
            cell = table.cell(i, j)
            cell.text = ''
            p = cell.paragraphs[0]
            add_runs(p, val)
            for run in p.runs:
                run.font.size = Pt(9.5)
            if header and i == 0:
                for run in p.runs:
                    run.bold = True
                tcPr = cell._tc.get_or_add_tcPr()
                shd = OxmlElement('w:shd')
                shd.set(qn('w:val'), 'clear')
                shd.set(qn('w:color'), 'auto')
                shd.set(qn('w:fill'), 'DDEBF7')
                tcPr.append(shd)
    return table


def add_horizontal_line(doc):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    add_bottom_border(p)
    return p


def convert(md_path, out_path):
    with open(md_path, encoding='utf-8') as f:
        lines = f.read().split('\n')

    doc = Document()
    set_style_cjk(doc.styles['Normal'], size=10.5)
    for name in ['Heading 1', 'Heading 2', 'Heading 3']:
        try:
            set_style_cjk(doc.styles[name],
                          color=RGBColor(0x1F, 0x3B, 0x73),
                          bold=True)
        except Exception:
            pass

    i, n = 0, len(lines)
    while i < n:
        stripped = lines[i].strip()
        if stripped == '':
            i += 1
            continue
        if stripped == '---':
            add_horizontal_line(doc)
            i += 1
            continue
        if stripped.startswith('#'):
            level = len(stripped) - len(stripped.lstrip('#'))
            text = stripped.lstrip('#').strip()
            h = doc.add_heading(text, level=min(level, 3))
            for run in h.runs:
                _set_cjk(run)
            i += 1
            continue
        if stripped.startswith('>'):
            quote_lines = []
            while i < n and lines[i].strip().startswith('>'):
                quote_lines.append(lines[i].strip().lstrip('>').strip())
                i += 1
            p = doc.add_paragraph()
            add_runs(p, '　'.join(quote_lines))
            for run in p.runs:
                run.italic = True
                run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
            p.paragraph_format.space_after = Pt(4)
            continue
        if stripped.startswith('|') and '|' in stripped[1:]:
            rows = []
            while i < n and lines[i].strip().startswith('|'):
                cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
                rows.append(cells)
                i += 1
            data = [r for r in rows
                    if not all(re.fullmatch(r'[-: ]+', c) for c in r)]
            if data:
                make_table(doc, data, header=True)
            doc.add_paragraph().paragraph_format.space_after = Pt(2)
            continue
        if '\t' in lines[i]:
            rows = []
            while i < n and '\t' in lines[i]:
                rows.append([c.strip() for c in lines[i].split('\t')])
                i += 1
            if rows:
                make_table(doc, rows, header=True)
            doc.add_paragraph().paragraph_format.space_after = Pt(2)
            continue
        if re.match(r'^[-*]\s+', stripped):
            while i < n and re.match(r'^[-*]\s+', lines[i].strip()):
                item = re.sub(r'^[-*]\s+', '', lines[i].strip())
                p = doc.add_paragraph(style='List Bullet')
                add_runs(p, item)
                i += 1
            continue
        p = doc.add_paragraph()
        add_runs(p, stripped)
        p.paragraph_format.space_after = Pt(4)
        i += 1

    doc.save(out_path)
    print(f"OK -> {out_path}")


def main():
    ap = argparse.ArgumentParser(description="Markdown 赛事洞悉报告转 Word")
    ap.add_argument('--md', required=True, help='输入 Markdown 文件路径')
    ap.add_argument('--out', required=True, help='输出 .docx 文件路径')
    args = ap.parse_args()
    convert(args.md, args.out)


if __name__ == '__main__':
    main()
