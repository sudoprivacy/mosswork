#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
赛事洞悉 · 模型计算脚本
==================================================
把采集到的「速率类」数据喂进来，确定性地算出：
  1) ELO 实力差 → 胜/平/负概率
  2) 泊松分布 → 期望进球、总进球分布、大小球概率
  3) 加权概率（ELO × 泊松，可配权重）
  4) 每个选项的「价值点」f* = (odds * p - (1-p)) / odds

用法示例：
  python compute_models.py \
      --elo-home 1650 --elo-away 1515 \
      --gf-home 1.6 --ga-home 0.9 --gf-away 1.4 --ga-away 1.5 \
      --odds-home 1.68 --odds-draw 3.40 --odds-away 4.55 \
      --ou-line 2.5 --ou-over 1.95 --ou-under 1.85

输出：默认打印可直接粘贴的 Markdown 片段；加 --json 打印 JSON。
所有参数均可省略，省略时用括号内"估计值"并提示需联网核实。
"""
import argparse
import json
import math

HOME_ADV = 70          # 主场优势折合 ELO 分
DRAW_BASE = 0.27       # 基础平局率（联赛平均量级）
MAX_GOALS = 12         # 泊松截断


def elo_probs(elo_home, elo_away, home_adv=HOME_ADV, draw_base=DRAW_BASE):
    dr = (elo_home - elo_away) + home_adv
    we = 1.0 / (1.0 + 10 ** (-dr / 400.0))   # 期望得分(胜=1,平=0.5)
    w = we - 0.5 * draw_base
    l = 1.0 - w - draw_base
    w = max(w, 0.01)
    l = max(l, 0.01)
    s = w + draw_base + l
    return w / s, draw_base / s, l / s


def poisson_probs(gf_home, ga_home, gf_away, ga_away):
    # 期望进球：本方进攻与对手防守的几何平均（避免简单相加导致偏高）
    exp_home = math.sqrt(max(gf_home, 0.01) * max(ga_away, 0.01))
    exp_away = math.sqrt(max(gf_away, 0.01) * max(ga_home, 0.01))

    def pmf(lam, k):
        return math.exp(-lam) * (lam ** k) / math.factorial(k)

    ph = [pmf(exp_home, k) for k in range(MAX_GOALS + 1)]
    pa = [pmf(exp_away, k) for k in range(MAX_GOALS + 1)]

    p_win = p_draw = p_loss = 0.0
    total = [0.0] * (2 * MAX_GOALS + 1)
    for h in range(MAX_GOALS + 1):
        for a in range(MAX_GOALS + 1):
            p = ph[h] * pa[a]
            if h > a:
                p_win += p
            elif h == a:
                p_draw += p
            else:
                p_loss += p
            total[h + a] += p
    return {
        "exp_home": exp_home,
        "exp_away": exp_away,
        "p_win": p_win,
        "p_draw": p_draw,
        "p_loss": p_loss,
        "total": total,
    }


def over_under(total, line):
    over = sum(total[t] for t in range(len(total)) if t > line)
    under = 1.0 - over
    return over, under


def value_point(odds, p):
    if odds <= 0:
        return 0.0
    return (odds * p - (1.0 - p)) / odds


def pct(x):
    return f"{x * 100:.1f}%"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--elo-home", type=float, default=1600.0)
    ap.add_argument("--elo-away", type=float, default=1550.0)
    ap.add_argument("--gf-home", type=float, default=1.5)
    ap.add_argument("--ga-home", type=float, default=1.2)
    ap.add_argument("--gf-away", type=float, default=1.3)
    ap.add_argument("--ga-away", type=float, default=1.4)
    ap.add_argument("--odds-home", type=float, default=2.10)
    ap.add_argument("--odds-draw", type=float, default=3.20)
    ap.add_argument("--odds-away", type=float, default=3.40)
    ap.add_argument("--ou-line", type=float, default=2.5)
    ap.add_argument("--ou-over", type=float, default=1.90)
    ap.add_argument("--ou-under", type=float, default=1.90)
    ap.add_argument("--w-elo", type=float, default=0.5, help="加权时 ELO 权重")
    ap.add_argument("--w-pois", type=float, default=0.5, help="加权时 泊松 权重")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    ew, ed, el = elo_probs(args.elo_home, args.elo_away)
    pois = poisson_probs(args.gf_home, args.ga_home, args.gf_away, args.ga_away)
    over, under = over_under(pois["total"], args.ou_line)

    # 归一化权重
    we = args.w_elo
    wp = args.w_pois
    s = we + wp
    we, wp = we / s, wp / s

    ww = we * ew + wp * pois["p_win"]
    wd = we * ed + wp * pois["p_draw"]
    wl = we * el + wp * pois["p_loss"]
    ws = ww + wd + wl
    ww, wd, wl = ww / ws, wd / ws, wl / ws

    exp_total = pois["exp_home"] + pois["exp_away"]
    lo, hi = math.floor(exp_total * 10) / 10, math.ceil(exp_total * 10) / 10

    vf_h = value_point(args.odds_home, ww)
    vf_d = value_point(args.odds_draw, wd)
    vf_a = value_point(args.odds_away, wl)

    result = {
        "elo": {"home": ew, "draw": ed, "away": el},
        "poisson": {
            "home": pois["p_win"], "draw": pois["p_draw"], "away": pois["p_loss"],
            "exp_home": pois["exp_home"], "exp_away": pois["exp_away"],
            "exp_total": exp_total,
        },
        "weighted": {"home": ww, "draw": wd, "away": wl},
        "over_under": {"line": args.ou_line, "over": over, "under": under},
        "value": {
            "home": {"odds": args.odds_home, "f": vf_h},
            "draw": {"odds": args.odds_draw, "f": vf_d},
            "away": {"odds": args.odds_away, "f": vf_a},
        },
        "params": {
            "elo_diff": args.elo_home - args.elo_away,
            "gf_home": args.gf_home, "ga_home": args.ga_home,
            "gf_away": args.gf_away, "ga_away": args.ga_away,
        },
    }

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    # ---- Markdown 片段（直接粘贴进报告"三、模型共识与机构倾向"）----
    out = []
    out.append("三、模型共识与机构倾向")
    out.append("模型\t主胜概率\t平局概率\t客胜概率\t总进球预期\t核心逻辑")
    out.append(
        f"ELO实力差\t{pct(ew)}\t{pct(ed)}\t{pct(el)}\t-\t"
        f"实力分差+{int(args.elo_home - args.elo_away)}（含主场+{HOME_ADV}）"
    )
    out.append(
        f"泊松分布\t{pct(pois['p_win'])}\t{pct(pois['p_draw'])}\t{pct(pois['p_loss'])}\t"
        f"{exp_total:.1f}球\t客队客场场均{args.ga_away:.1f}失球"
    )
    out.append(
        f"加权值\t{pct(ww)}\t{pct(wd)}\t{pct(wl)}\t{lo:.1f}-{hi:.1f}球\t"
    )
    # 价值点（取绝对值最大的一项展示，通常客胜）
    best = max(result["value"].items(), key=lambda kv: abs(kv[1]["f"]))
    side_cn = {"home": "主胜", "draw": "平局", "away": "客胜"}[best[0]]
    fv = best[1]["f"]
    prob_used = ww if best[0] == "home" else (wd if best[0] == "draw" else wl)
    out.append(f"{side_cn}价值点：")
    out.append(
        f"f* = ({best[1]['odds']}×{prob_used*100:.1f}% - {(1-prob_used)*100:.1f}%)/{best[1]['odds']} = {fv:+.3f} "
        f"{'（正价值）' if fv > 0 else '（无价值）'}"
    )
    out.append("")
    out.append(
        f"大小球参考：{args.ou_line} 球 → 大球概率 {pct(over)} / 小球概率 {pct(under)}"
    )
    print("\n".join(out))


if __name__ == "__main__":
    main()
