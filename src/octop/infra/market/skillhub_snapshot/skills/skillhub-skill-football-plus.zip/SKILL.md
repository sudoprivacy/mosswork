---
name: skillhub-skill-football-plus
description: "足球（含韩K联、J联赛、欧洲五大联赛、中超、世界杯/亚洲杯等）赛事深度分析技能。当用户给出两支球队（可带联赛）并希望做赛事洞悉、盘口赔率分析、胜负与大小球研判、价值投注时触发。本技能输出结构化的四段式分析：赔率异动与天气矛盾点、战意与伤停权重表、ELO+泊松模型共识与价值点、终局决策矩阵与仓位建议，并可整合多场给出信心排序。"
---

# 赛事洞悉（Match Insight）

## Overview

把任意"主队 vs 客队（联赛）"输入，产出一份结构化的足球赛事研判报告：从赔率异动、天气、战意伤停，到 ELO/泊松模型共识与价值点，再到带仓位建议的终局决策矩阵。适用于研究竞彩/亚盘方向、大小球、波胆与多场组合策略。

报告严格遵循 `assets/template.md` 的章节结构。数值计算交给 `scripts/compute_models.py`，保证概率与价值点一致、可复现。

## When to use

用户出现以下任意表达即触发：
- 「赛事洞悉：A队 vs B队」/「分析一下 A 对 B（联赛）」
- 「帮我看 A vs B 的盘口/赔率/胜负/大小球」
- 直接给出两队名 + 联赛（如「韩K联 首尔 浦项」）
- 要求"像之前那个赛事分析"一样的输出

## Workflow

### Step 1 · 解析输入
提取 `主队`、`客队`、`联赛`。联赛缺失时根据队名推断并注明"推测来源"。

### Step 2 · 采集数据（WebSearch / WebFetch）
按 `references/methodology.md` 第 1 节逐项采集，至少覆盖：
- 近 5–10 场战绩 + 主客场拆分（场均进/失球、控球率、客队客场进球占比）
- 排名与战意（积分差、争冠/亚冠/保级）
- 伤停名单（缺阵主力及位置，量化攻防影响）
- 比赛地天气与温度预报（雨战胜率对比）
- 赔率：竞彩/机构胜平负初赔→现赔、亚盘盘口水位、让球赔付 vs 市场均值、大小球盘口
- 交锋历史（H2H）、可搜到的 ELO/实力分

> 用户提供的数据优先采用，仅补足缺失项。所有"估计值"在文中标注，区分"已确认/估计"。

### Step 3 · 运行模型脚本
把采集到的数值代入 `scripts/compute_models.py`（用 managed python 运行）：

```bash
C:/Users/19441/.workbuddy/binaries/python/versions/3.13.12/python.exe \
  ~/.workbuddy/skills/足球赛事分析/scripts/compute_models.py \
  --elo-home <主队ELO> --elo-away <客队ELO> \
  --gf-home <主队主场场均进球> --ga-home <主队主场场均失球> \
  --gf-away <客队客场场均进球> --ga-away <客队客场场均失球> \
  --odds-home <主胜赔> --odds-draw <平赔> --odds-away <客胜赔> \
  --ou-line <大小球线> --ou-over <大球赔> --ou-under <小球赔>
```

脚本打印可直接粘贴进报告第三、四段的 Markdown 片段（含 ELO/泊松/加权概率表与价值点 `f*`）。缺数据时用脚本默认值并标注"示例估计"。

### Step 4 · 组装报告
严格按 `assets/template.md` 四段式撰写：
1. **核心矛盾点**：一句话点出赔率/盘口动作与基本面是否背离；给出赔率变动轨迹；天气段说明对技术/身体流打法的影响（控球率 + 天气战胜率对比）。
2. **战意与伤停权重**：表格（排名/伤停/近期状态/关键因子）+ 一句话"转折点"量化。
3. **模型共识与机构倾向**：三行模型表（ELO / 泊松 / 加权）+ 价值点公式行（用脚本输出，确保 `p` 取自加权概率）。
4. **终局决策矩阵**：选项配 S/A/B 评级与仓位%（合计≈100%）+ 终极策略组合 + 止损提示（临场变量触发权重修正）。

多场比赛时在末尾追加"多场整合策略"表（推荐组合 / 仓位 / ★ 信心评级 / 黄金定律总结）。

### Step 5 · 转 Word 并交付
报告先以 Markdown 写出（便于模型脚本与人工校对），再用 `scripts/build_docx.py` 转成 Word 文档。

> **路径可移植性**：下方 venv 路径用 `~`（用户主目录）写法，跨机器/跨用户名通用。本机 managed python 的具体版本路径见运行时环境的 "Available binaries"（如 `C:/Users/<你用户名>/.workbuddy/binaries/python/versions/3.13.12/python.exe`）。首次使用需先建 venv 并装 python-docx（仅需一次）。

```bash
# 0) 首次使用：基于本机 managed python 建 venv 并装依赖（仅需一次）
C:/Users/19441/.workbuddy/binaries/python/versions/3.13.12/python.exe -m venv ~/.workbuddy/binaries/python/envs/default
~/.workbuddy/binaries/python/envs/default/Scripts/python.exe -m pip install python-docx

# 1) 写出 Markdown 源文件（保留，便于后续修订）
赛事洞悉_{主队}_vs_{客队}.md

# 2) 转成 .docx
~/.workbuddy/binaries/python/envs/default/Scripts/python.exe \
  ~/.workbuddy/skills/足球赛事分析/scripts/build_docx.py \
  --md "赛事洞悉_{主队}_vs_{客队}.md" \
  --out "赛事洞悉_{主队}_vs_{客队}.docx"
```

- 转换器自动识别：标题、`>` 引用、`---` 分隔线、`|` 管道表格、`\t` 分隔的模型表、`-` 列表、`**加粗**`；中文默认「微软雅黑」，表格带网格线与表头底色。
- 调用 present_files 交付该 `.docx`（同时保留 `.md` 源），并在小结中附"分析仅供参考、理性投注"提示。

## Reference files

- `references/methodology.md` — 数据采集清单、模型口径、各章节撰写规范、价值点公式一致性要求。
- `assets/template.md` — 最终报告的结构模板（含占位符与字段说明），输出须严格对齐。
- `scripts/compute_models.py` — 确定性模型计算（ELO/泊松/加权/价值点），禁止手写这些数值。
- `scripts/build_docx.py` — 把 Markdown 报告转成 Word 文档（依赖 managed venv 的 python-docx）。
