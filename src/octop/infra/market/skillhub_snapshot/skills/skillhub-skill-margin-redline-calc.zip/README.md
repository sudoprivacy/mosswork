# 大促利润红线计算器（margin-redline-calc）

TikTok Shop 美区单 SKU 报活动前测算：五层费用瀑布、两场景两档保本价、报/剔三值判定（RED/GREEN/BOUNDARY）。

## 特点

- **零依赖**：纯 Python 标准库，任何环境直接跑；
- **口径纪律**：活动期/平时两场景分开，SP 按 4.5–5.5% 区间输出，永不给单点承诺；
- **费率透明**：每项费率带来源与生效日期，佣金 6%↔8%、交易费两说并存如实标注（见 references/fee-sources.md）；
- **不收费、不联网、不索要店铺数据**。

## 环境检测与安装指引

**检测（一条命令）**：

```bash
python3 scripts/calc.py --check
# 输出 env.status=OK + env.selftest=PASS 即环境就绪；FAIL 时看 env.hint
```

**安装（按平台，缺 Python 才需要）**：

| 平台 | 指引 |
|---|---|
| macOS | 通常自带 `python3`；首次提示时点装 Xcode 命令行工具（`xcode-select --install`） |
| Linux | 大多预装；Debian/Ubuntu：`sudo apt install python3` |
| Windows | 推荐 WSL：终端执行 `wsl --install` 后在 WSL 内用 `python3`；或到 python.org 装 3.x |

**要求**：Python 3.6+，纯标准库——**无需 pip、无需网络、不写任何文件**（输出已内置 UTF-8 兼容，Windows 中文/特殊字符输出不会崩）。

## 用法

```bash
# 平时测算
python3 scripts/calc.py --price 20 --cost 8 --shipping 4

# 报活动测算（活动价 + 达人占比）
python3 scripts/calc.py --price 20 --cost 8 --shipping 4 --campaign-price 15 --share 1.0
```

## 双锚点自检（内置验收用例）

- 平时：`$20 → profit=4.60, be_bare=14.46, be_ads=16.44`
- 活动：`$15 全达人 → profit=-1.88..-1.73, be_bare=17.52-17.78, flag=RED`

## 免责

测算结果非平台结算承诺；你店实际费率可能与公开表不同，以结算单为准。
