#!/usr/bin/env python3
"""大促利润红线计算器（SkillHub 钩子技能，自包含零依赖）。

单 SKU：五层费用瀑布 + 两场景两档保本价 + 报/剔三值判定。
费率来源与争议标注见 references/fee-sources.md；本脚本不联网、不收费、不索要店铺数据。

内置双锚点验收用例：
  python3 scripts/calc.py --price 20 --cost 8 --shipping 4
      → normal profit=4.60 be_bare=14.46 be_ads=16.44
  python3 scripts/calc.py --price 15 --cost 8 --shipping 4 --campaign-price 15 --share 1.0
      → campaign profit=-1.88..-1.73 be_bare=17.52-17.78 flag=RED
"""
import argparse
import sys
from decimal import Decimal, ROUND_HALF_UP

# 可移植性：非 UTF-8 输出环境（Windows cp936/cp1252、LANG=C 管道）必须照常工作。
# 统一切到 UTF-8 + errors=replace——坏字符降级为 ? 而不是整段崩溃。
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

# 美区公开费率默认值（来源/生效日期/争议见 references/fee-sources.md，核实于 2026-11-12）
DEFAULTS = {
    "referral": 0.06,            # 佣金；另有 8% 涨价多说，官方未确认
    "transaction": 0.0,          # 交易费：争议项，默认 0（若你店结算单有，按实际）
    "sp_base": 0.035,            # Smart Promotion 非活动期（全店 GMV）
    "sp_extra_low": 0.010,       # 活动期加点下限
    "sp_extra_high": 0.020,      # 活动期加点上限
    "campaign_service": 0.01,    # 活动服务费（仅活动期）
    "affiliate_rate": 0.15,      # 达人佣金名义费率（按出单占比加权计入）
    "return_rate": 0.05,         # 退货预留（含退款管理费 20%×佣金、上限 $5、不退的达人佣金、货损）
    "ad_target": 0.10,           # 含投流保本价的目标利润率
    "refund_rate_of_referral": 0.20,
    "refund_cap": 5.0,
}

RED, GREEN, BOUNDARY = "RED", "GREEN", "BOUNDARY"


def money(x):
    return Decimal(str(round(float(x), 10))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def fee_totals(referral, tx, affiliate, ret, campaign):
    """返回 (下限合计, 上限合计)。平时上下限相等；活动期含活动服务费 + SP 区间。"""
    base = referral + tx + affiliate + ret
    if not campaign:
        return base, base
    sp_low = DEFAULTS["sp_base"] + DEFAULTS["sp_extra_low"]
    sp_high = DEFAULTS["sp_base"] + DEFAULTS["sp_extra_high"]
    return base + DEFAULTS["campaign_service"] + sp_low, base + DEFAULTS["campaign_service"] + sp_high


def break_even(fixed, total_pct, target=0.0):
    denom = 1.0 - total_pct - target
    if denom <= 0:
        raise SystemExit("ERROR: 费用合计+目标 ≥ 100%，无保本价")
    return fixed / denom


def refund_memo(price, referral, ret_rate):
    """退款管理费每单期望值（备查行，不扣减——已含在退货预留内）。"""
    per_refund = min(DEFAULTS["refund_rate_of_referral"] * referral * price, DEFAULTS["refund_cap"])
    return ret_rate * per_refund


def env_check():
    """环境检测（--check）：Python 版本、平台、输出编码、双锚点自检——全部通过才 status=OK。"""
    import platform
    ver = sys.version_info
    print("env.python=%s" % platform.python_version())
    print("env.platform=%s" % platform.platform())
    print("env.stdout_encoding=%s" % getattr(sys.stdout, "encoding", "unknown"))

    if ver < (3, 6):
        print("env.status=FAIL")
        print("env.hint=需要 Python 3.6+，当前 %s。Windows 建议 WSL 或到 python.org 安装。"
              % platform.python_version())
        return 1

    # 双锚点自检（与验收锚点同源：4.60 / -1.88..-1.73）
    try:
        n_low, _ = fee_totals(DEFAULTS["referral"], DEFAULTS["transaction"],
                              DEFAULTS["affiliate_rate"] * 0.4, DEFAULTS["return_rate"], False)
        profit_n = money(20 * (1 - n_low) - 12)
        c_low, c_high = fee_totals(DEFAULTS["referral"], DEFAULTS["transaction"],
                                   DEFAULTS["affiliate_rate"] * 1.0, DEFAULTS["return_rate"], True)
        worst = money(15 * (1 - c_high) - 12)
        best = money(15 * (1 - c_low) - 12)
        ok = (str(profit_n) == "4.60" and str(worst) == "-1.88" and str(best) == "-1.73")
    except Exception as e:  # noqa: BLE001
        print("env.status=FAIL")
        print("env.hint=自检异常: %r" % e)
        return 1

    if not ok:
        print("env.selftest=FAIL (got %s / %s..%s)" % (profit_n, worst, best))
        print("env.status=FAIL")
        print("env.hint=计算自检未过——Python 环境异常，请重装 Python 3 后重试")
        return 1
    print("env.selftest=PASS (4.60 / -1.88..-1.73)")
    print("env.status=OK")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description="单 SKU 大促利润红线测算（美区）")
    p.add_argument("--check", action="store_true", help="环境检测：版本/编码/锚点自检后退出")
    p.add_argument("--price", type=float, default=None, help="日常售价 USD")
    p.add_argument("--cost", type=float, default=None, help="采购成本 USD")
    p.add_argument("--shipping", type=float, default=None, help="运费 USD")
    p.add_argument("--campaign-price", type=float, default=None, help="活动价（不报活动则省略）")
    p.add_argument("--share", type=float, default=0.4, help="达人出单占比 0-1（默认 0.4，估算须标注）")
    p.add_argument("--affiliate-rate", type=float, default=DEFAULTS["affiliate_rate"])
    p.add_argument("--return-rate", type=float, default=DEFAULTS["return_rate"])
    p.add_argument("--referral", type=float, default=DEFAULTS["referral"],
                   help="佣金率（默认 0.06，两说并存见 references/fee-sources.md）")
    a = p.parse_args(argv)

    if a.check:
        return env_check()
    missing = [k for k in ("price", "cost", "shipping") if getattr(a, k) is None]
    if missing:
        p.error("缺少必需参数: %s" % ", ".join("--" + k for k in missing))
    if a.price <= 0:
        p.error("--price 必须 > 0")
    if a.cost < 0 or a.shipping < 0:
        p.error("--cost / --shipping 不能为负")
    if a.campaign_price is not None and a.campaign_price <= 0:
        p.error("--campaign-price 必须 > 0")
    if not (0 <= a.share <= 1):
        p.error("--share 必须在 0-1")
    if a.cost > a.price:
        print("WARNING: 成本(%s) > 售价(%s)——请先与用户复述确认数字" % (a.cost, a.price), file=sys.stderr)

    fixed = a.cost + a.shipping
    tx = DEFAULTS["transaction"]
    affiliate = a.affiliate_rate * a.share

    n_low, _ = fee_totals(a.referral, tx, affiliate, a.return_rate, False)
    n_profit = a.price * (1 - n_low) - fixed
    n_be = break_even(fixed, n_low)
    n_be_ads = break_even(fixed, n_low, DEFAULTS["ad_target"])

    print("scenario=normal total_pct=%.2f%% profit=%s be_bare=%s be_ads=%s" % (
        n_low * 100, money(n_profit), money(n_be), money(n_be_ads)))
    print("fees_normal=ref=%.2f%%|tx=%.2f%%|aff=%.2f%%(=%.2f%%×share%.2f)|ret=%.2f%%" % (
        a.referral * 100, tx * 100, affiliate * 100, a.affiliate_rate * 100, a.share,
        a.return_rate * 100))

    if a.campaign_price is None:
        print("refund_admin_memo=%s" % money(refund_memo(a.price, a.referral, a.return_rate)))
        print("disclaimer=基于公开费率测算，非平台结算承诺；实际费率以你的结算单为准")
        return 0

    c_low, c_high = fee_totals(a.referral, tx, affiliate, a.return_rate, True)
    worst = a.campaign_price * (1 - c_high) - fixed   # SP 上限 = 最坏
    best = a.campaign_price * (1 - c_low) - fixed     # SP 下限 = 最好
    if money(best) < 0:
        flag = RED
    elif money(worst) > 0:
        flag = GREEN
    else:
        flag = BOUNDARY

    print("scenario=campaign total_pct=%.2f-%.2f%% profit=%s..%s be_bare=%s-%s be_ads=%s-%s" % (
        c_low * 100, c_high * 100, money(worst), money(best),
        money(break_even(fixed, c_low)), money(break_even(fixed, c_high)),
        money(break_even(fixed, c_low, DEFAULTS["ad_target"])),
        money(break_even(fixed, c_high, DEFAULTS["ad_target"]))))
    print("fees_campaign=%s|cs=%.2f%%|sp=%.1f-%.1f%%" % (
        "ref=%.2f%%|tx=%.2f%%|aff=%.2f%%|ret=%.2f%%" % (
            a.referral * 100, tx * 100, affiliate * 100, a.return_rate * 100),
        DEFAULTS["campaign_service"] * 100,
        (DEFAULTS["sp_base"] + DEFAULTS["sp_extra_low"]) * 100,
        (DEFAULTS["sp_base"] + DEFAULTS["sp_extra_high"]) * 100))
    print("flag=%s" % flag)
    if flag == RED:
        print("advice=剔：活动价最好情形（SP 下限）仍亏")
    elif flag == GREEN:
        print("advice=报：活动价最坏情形（SP 上限）仍赚")
    else:
        print("advice=区间触线：按 SP 上限再测算后决定，报告须明示区间")
    print("refund_admin_memo=%s(备查，已含在退货预留内)" % money(refund_memo(a.campaign_price, a.referral, a.return_rate)))
    print("disclaimer=基于公开费率测算，非平台结算承诺；实际费率以你的结算单为准")
    return 0


if __name__ == "__main__":
    sys.exit(main())
