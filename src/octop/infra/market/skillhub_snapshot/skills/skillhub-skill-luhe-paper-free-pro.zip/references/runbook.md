# 执行手册（runbook）

> 技术性操作速查：配置、微信扫码登录、登录态检查、一键成文、错误处理、接口契约。
> agent 在对应环节按需读取本节执行；**技术细节与字段坑详见 `implementation.md` / `api-contract.md`**。
> 用户可见话术一律来自 `conversation-scripts.md`，本文件内容严禁直接输出给用户。

---

## §0 交互规则补充

### 新用户引导（统一口径）

- **新用户**：开局不要求登录，先免费走选题 / 文献确认；**只有真正调用一键成文接口、且接口明确返回需要登录时**，才出微信二维码（用户侧话术见 `conversation-scripts.md §0.11 / §0.2b`）。
- **老用户**：直接读本地凭证，不重复引导。

### 发出前自检清单（0.8 红线配套，逐项过，全过才能发）

1. 有没有"我在描述自己动作"的开头？（回显/确认一下参数/检查/判定/走流程…）→ 删掉，直接给内容
2. 有没有把内部决策逻辑念给用户？（"语言未指定，按默认处理""检测到已登录""余额充足"…）→ 删掉，默认值静默生效
3. 有没有软技术味词？（见 playbook.md 红线禁忌 2b）→ 换口语
4. 有没有硬内部词？（见 playbook.md 红线禁忌 2）→ 删掉
5. 整句是不是"真人客服会对客户说的话"？不是 → 整句删除或改写

**正反例对照**：
- ❌"已探活…按规范走已登录唤起流程" → ✅"已登录，直接给我主题就能开写。"
- ❌"我已掌握交互规范。现在按流程读取配置拿到平台地址，再调用接口探活验证凭证" → ✅"登录成功！你现在可以直接开写了。"（前者在描述 agent 自己的操作步骤，禁止出现在用户可见正文）

---

## §1 配置

### 数据目录

**凭证与产出分开存放**：凭证统一落**全局配置**（skill 根目录 config.json，本机所有会话共用）；产出落**用户工作空间**（每次会话新建目录，属正常）。
```
~/.workbuddy/skills/luhe-paper-free-pro/config.json             ← 凭证（本副本专用，跨会话免扫码）
<用户工作空间>/paper-writer-data/                              ← 产出（outputs/、status.json、history.json、登录二维码与登录状态）
```
- config 读取优先级：`--config` > `LUHE_CONFIG` > 数据目录/paper-writer-data/config.json > skill 根目录/config.json。
- **写入落点（`resolve_credential_config`）**：默认写 skill 根目录 config.json；显式 `--config` / `$LUHE_CONFIG` 优先；工作空间若已有历史凭证文件则继续沿用（老用户不掉登录）。**不再向工作空间复制凭证副本**——工作空间每会话新建目录，写在那里会导致新会话读不到、被迫反复扫码。
- 产出台根目录：`LUHE_PAPER_DATA_DIR` > 当前运行目录(cwd)/paper-writer-data。
- **必须从用户工作空间启动脚本**（不要 cd 进 scripts）；配套脚本自动定位产出路径。

### config 字段

| 字段 | 说明 |
|------|------|
| `base_url` / `lit_host` | 平台地址，**唯一来源**：所有脚本与文档均从这里读，不写死任何环境地址（lit_host 缺省回退 base_url）。**必须是第一方 HTTPS 地址**（`https://luhe.cqvip.com`），见下方 🔴 地址铁律 |
| `platform_url` | 露禾主站 `https://luhe.cqvip.com`（仅用于文献详情页链接） |
| `token` | 微信扫码登录获取的凭证（绝不在对话中明文展示；登录后自动写入全局配置） |
| `token_source` | 固定 `wechat_mp_qr` |
| `user` | 登录接口返回的原始用户信息（调试用） |
| `onboarded` | 是否已登录过（登录成功后写 true） |

> ⚠️ 全局配置里含凭证，**分享 / 导出 skill 包前必须先清空 `token`**（`selfcheck.py --prepack` 会拦截）。

> 🔴 **地址铁律（2026-09-14 安全加固）**：`base_url` / `lit_host` 只允许**第一方 HTTPS**（`*.cqvip.com`）。**严禁**指向第三方域名 —— 尤其 natapp / ngrok 之类**内网穿透**，或任何明文 `http://`。原因：这几条链路全都把敏感数据交给该地址 ——
> - `login.py`：取微信二维码、回传登录 ticket → 换回 **token**；
> - `generate.py` / `export.py` / `paper_preview_server.py`：携带 token 头（`edu-big-data-server-user-skill`）与**论文主题/正文**；
> - `lit_host`：承载引文串拉取（同样是带 token 的请求）。
>
> 明文 HTTP 下中间人可读可改；免费隧道子域一旦过期，既会失效，也可能被第三方重新注册，DNS 可随时被改指到任意主机。`config.example.json` 是**用户直接复制使用的模板**，因此模板里的地址等于将要生效的地址，与在用配置同标准。`selfcheck.py --prepack` 已把该口径做成**硬门槛**（模板或出厂 `config.json` 不合规则拒绝打包）。

### 退出登录 / 清空凭证

把全局 `config.json` 的 `token`（关键）、`token_source`、`user`、`active_task` 置空即可——**登录态的唯一判定口径就是 `token` 是否非空**（`login.py` / `selfcheck.py` 均取 `cfg.get("token")`）。无需删文件，`base_url` 等配置保留；清空后下次用到需登录的环节会重新出二维码。凭证可随时重扫恢复，故清空前**不必留明文备份**（备份等于没清）。

⚠️ 历史遗留副本需一并检查（旧版本或其它技能可能写过）：

- 旧技能目录 `~/.workbuddy/skills/luhe-paper/config.json`
- 早期工作空间 `<工作空间>/paper-writer-data/config.json`、`login_status.json`（扫码 ticket）
- `website-agent-testing/luhe_cookies.json` 里的 JWT cookie
- WorkBuddy 自身运行数据（`traces/`、`projects/`、`audit-log/`、`logs/`、`file-history/`、`artifact-index/`、`workspace/sessions/*/modify_backup/`）会留存调用历史中的凭证明文 —— 属**活动留痕、非凭证存储位置**，一般不必处理（清理会影响历史会话记录、审计追溯与文件版本历史）

### 运行环境（解释器）

本机技能依赖装在**隔离虚拟环境**，跑脚本一律用它：

```
~/.workbuddy/binaries/python/envs/default/Scripts/python.exe   # Python 3.13.14
```

该环境已含 `segno`（二维码渲染，登录必需）、`python-docx`、`requests`。
用它跑 `selfcheck.py` 应为「尚未登录」WARN + 其余通过；若改用 managed 解释器 `binaries/python/versions/3.13.12/python.exe` 会**缺 segno** → 登录时二维码渲染失败、自检报 FAIL（属环境选错，不是配置问题）。

### 自检

```bash
cd scripts
python selfcheck.py            # 结构 + 依赖 + 配置（离线）
python selfcheck.py --online   # 上面 + 真连服务器
```

---

## §2 登录（微信扫码）

### 鉴权模型

token 由微信扫码登录获取，请求时作 header（`edu-big-data-server-user-skill: {token}`）下发；所有请求必须带 `User-Agent`（缺失会被网关拦 403）。详见 `api-contract.md §0`。

### 流程（登录脚本一条命令跑完）

> 🔴 **触发铁律（与 playbook §0.2b 一致）**：登录二维码**绝不预先弹出**。未登录用户先走完免费前置环节（选题 / 文献确认），**再尝试调用一键成文接口**；只有该接口明确返回登录态失效 / 需要登录（401/403/505 或明文「need login / 请登录」）时，才执行下述步骤 2-3 出二维码。开局、生成前都不要主动推登录。

1. 不做任何登录预判：直接尝试调用一键成文接口（凭证如有则随请求自动带上）；仅当该接口明确返回登录态失效 / 需要登录（401/403/505 或明文「need login / 请登录」）时，才执行步骤 2-3 出二维码（见上方铁律）。
2. 跑登录脚本取微信二维码 → 渲染 PNG → 把图片给用户扫。
3. 脚本轮询 `POST /server-user/skill/user/login`（每 3s），扫码后自动把凭证写入**全局配置**（skill 根目录 config.json，本机所有会话共用，跨会话免扫码）
   （`token` + `token_source="wechat_mp_qr"` + `onboarded=true`），按 0.3 话术播报。

```bash
# ⚠️ 二维码渲染依赖 segno：用隔离 venv 的 python 跑（<VENV_PY> 为本机隔离环境 python.exe 路径，
#    形如 <home>/.workbuddy/binaries/python/envs/default/Scripts/python.exe）
#    隔离环境已预装 segno；若缺失脚本会硬失败提示安装（二维码严禁以链接形式交付，无降级）
cd "<用户工作空间>"
"$VENV_PY" <skill路径>/scripts/login.py \
  --qr-image "<工作空间>/paper-writer-data/outputs/login_qr.png" \
  --status-file "<工作空间>/paper-writer-data/login_status.json"
# base_url 自动从 config.json 读取（全局配置优先，回退数据目录/历史落点），无需 --base-url
```

> 产出（二维码图片、登录状态文件）仍写用户工作空间——它们是**本次会话**的临时产物；**凭证写全局配置**（见 §1「写入落点」）。

- **推荐用法**：`--no-wait` 先出码给用户，后台再跑一次带 ticket 的轮询；或直接后台跑完整流程，轮询状态文件的 `status`（`waiting_scan` / `ok` / `expired` / `timeout` / `failed`）。
- **二维码交付（2026-09-11 修正：内联展示必须用内嵌数据，不能只给本地文件路径）**：
  - ⚠️ **踩过的坑**：`show_widget` 里用**本地绝对路径**引用图片——无论 HTML 的 `<img src="C:/.../login_qr.png">` 还是 SVG 的 `<image href="C:/...">`——在部分宿主环境下**不渲染**，用户只看到空白卡片（表现为「二维码没展示成功」）。SVG `<image>` 元素尤其容易被过滤。
  - ✅ **正确做法（三层一次给全，用户任选其一扫；三份必须同码）**：
    1. **内联展示**：`show_widget` 用 HTML 片段，`<img src="data:image/png;base64,<二维码 PNG 的 base64>">` —— 数据自带、不依赖任何外部地址。base64 从 `login_qr.png` 读出（455 字节图约 620 字符，可直接内联；用隔离 venv 的 python 读，别手抄长串）。**用 HTML `<img>`，不要用 SVG `<image>`**。
    2. **文件卡片**：`present_files` 交付 PNG；并额外给两张更易扫的：
       - 放大版 `login_qr_big.png`：原图 ×3 最近邻放大（328→984），无需二维码内容即可生成，最稳妥；
       - 矢量版 `qr_vec.svg`：`segno.make(qr_url, error="m").save(..., scale=1, border=4, light=None)` 直接输出，可无损放大。
    3. 最后在话术里说明「三张是同一个码，任选能看到的扫」。
  - 🔴 **同码校验**：放大版/矢量版必须用**登录时那次的 `qr_url`** 重渲染（同一字符串即同码）。可用「重渲染 PNG 与原 `login_qr.png` 字节比对」确认（相等即同码）。**不要**为了重新出图去 `--ticket` 重复取码或另起轮询进程。
  - 🔴 **qr_url 会被轮询进程覆盖**：`login_status.json` 的 `qr_url` / `qr_image` / `expire_seconds` 在轮询进程写入后可能变为 `null`（只剩 `ticket`）。**所以出码当下就要把 `qr_url` 记下来**（写进 `pending_params.json` 或自留变量），别等到用户反馈「扫不了」时再回头找。
- **过期 / 换一张**：用户说「二维码过期 / 扫不了」→ 重跑登录脚本换新码即可（二维码有效期约 5 分钟）。
- ⚠️ 路径参数用 Git Bash 的 `C:/` 形式绝对路径；PowerShell 反斜杠绝对路径会被吞并回退默认路径。

> 鉴权模型、环境地址规则的技术细节见 `references/implementation.md`。

---

## §3 登录态检查

```bash
# 在用户工作空间运行；config 自动从全局配置读取（无则回退数据目录历史落点）
python <skill路径>/scripts/generate.py --check-login
```

凭证有效退出码 0，失效退出码 1（失效时走 §2 重新扫码登录）。

> ⚠️ **不要把 `--check-login` 当作「要不要弹码」的唯一依据（2026-09-11 修正）**：该探针走的是**权益接口**，
> 账号无对应权益时会返回 `code:0`（HTTP 200），旧实现据此误报「已失效」，导致持有有效凭证的用户被无谓要求重扫。
> 现已改为**网关是否接受凭证**为准（仅 401/403/505/507 判失效；网络异常不下失效结论）。
> 探针判「有效」仍可能被后端在成文/导出时拒绝——**是否需要登录，一律以成文/导出接口的真实返回为准**（need_login 流程）。

---

## §4 一键成文

### 参数

| 参数 | 取值 |
|------|------|
| 标题 | 用户自由输入 |
| 语言 | 中文 / 英文 |
| 字数 | 3000 / 5000 / 8000 |

### 启动生成

必须用 `scripts/generate.py`（SSE 流式解析，正常 2-4 分钟）。用 Bash `run_in_background: true` 启动。

```bash
# 在用户工作空间运行；产出自动落 <工作空间>/paper-writer-data/，config 优先读数据目录
python <skill路径>/scripts/generate.py \
  --title "标题" --language 中文 --word-count 5000
```

### 轮询进度与自动重试

每隔 20-30 秒读进度：处理中 → 按阶段播报；成功 → 按交付流程；失败 → 自动重试。

**🔴 need_login 立即响应（最高优先级，先于一切重试）**：生成任务一旦返回「需要登录」（status.json 出现 `need_login`、或后台任务以**退出码 3**结束），**立即**：① 停掉该后台任务（不得继续挂着）；② 当个回复内**先向用户转述平台返回的原因**（status.json 的 `need_login_reason` 字段，脚本保证任何 need_login 判定必带此字段——后端给了文案用文案，只给状态码则按状态码解释，如「平台返回 401，身份未通过验证」），**再**出微信二维码 + 登录引导；**严禁不解释原因直接弹码**。脚本行为：need_login 时「预生成二维码 → 退出码 3」，二维码图片路径与登录状态文件路径写在 status.json 的 `login_qr_image` / `login_status_file` 字段，agent 直接取图展示即可。**严禁**在后台运行时让脚本阻塞等待扫码（用户看不到码，只会卡死）；**严禁**并发多个登录等待进程（占满平台连接数触发 429，扫码确认会一直失败）。同一时刻只允许一个登录轮询进程。仅前台交互场景可显式传 `--auto-login` 在脚本内等待扫码并续写。

**自动重试规则**：
1. 平台侧临时故障（Neo4j/timeout/502/503/504/SSE 未收到 paper.done）→ 自动重跑一次，一句话同步："平台临时出了点小状况，已自动重新发起。"
   （成功判定为「收到 paper.done + 正文非空」，不看 paper_id —— 见 `api-contract.md §3`）
2. 只自动重试 1 次；第二次仍失败才停下来问用户。
3. 凭证失效不适用自动重试，先引导重新扫码登录（即 need_login 立即响应流程）。

### 交付（命令）

生成成功后**必须同时做两件事**：① 交付预览——首选直接 `present_files` 自包含 HTML（已内嵌平台 docx，双击直开即可阅读+下载，无服务依赖）；备选启动本地预览服务回 `http://127.0.0.1:{端口}/` 地址（回地址前必须 curl 探测 200）；② 用 `present_files` 交付 docx 文件。

```bash
# 在用户工作空间运行；html/payload 在 <工作空间>/paper-writer-data/outputs/ 下
# token / base_url 优先从 config.json 自动读取，两者都已配置时可省略对应参数
python <skill路径>/scripts/paper_preview_server.py \
  --html paper-writer-data/outputs/论文_xxx.html \
  --payload paper-writer-data/outputs/preview_payload.json \
  --port 0
```

- **「重开预览」指令**：用户说「重新打开预览 / 预览打不开 / 预览地址失效」等 → **不重新生成论文**，按以下固定路径处理：
  1. 先探测**上次交付的地址**（`curl --noproxy '*' -s -o /dev/null -w "%{http_code}" http://127.0.0.1:{旧端口}/`）——200 说明服务仍存活，**直接复用同一地址**，无需重拉；
  2. 非 200 → 读 `outputs/last_preview.json`（含 html/payload/docx 路径）重拉预览服务（命令见下），把新地址回给用户；
  3. 离线 docx 不变，可一并重新 `present_files` 交付。
- **预览服务生命周期**：服务空闲无请求会自毁退出（默认 60 分钟，可加 `--idle-timeout <秒>` 调短，如 `--idle-timeout 600` 即 10 分钟）；自毁、Ctrl-C、启动失败三条路径**都会释放端口并让进程正常退出**，无需手动 kill，也不会因反复重开而残留进程。同一端口只允许一个服务实例。
- 🔴 **回服务地址前必须健康检查（防死链硬步骤）**：回预览地址给用户前，必须用 `curl --noproxy '*'` 探测目标端口返回 200（见 §4「交付（命令）」上方 playbook §0.7 交付硬规则；`--noproxy '*'` 不可省，宿主机有 `http_proxy` 时探测会被代理接管而误判）；非 200 优先改交自包含 HTML（无需重拉服务），或重拉后再交付，**禁止交付未就绪的地址**。
- 🔴 **交付形态**：预览交付首选「自包含 HTML + docx 文件」（HTML 已内嵌 docx，file:// 直开下载可用）；本地预览服务地址作备选（需托管动态导出时），禁止宣称「HTML 直开下载按钮会失效」——base64 直出路径不依赖服务。
- **Word 下载铁律**：唯一内容来源 = 平台导出的真实 docx（contentJson 含 chart/table/formula/code base64，平台 `/export` 原样渲染，参考文献也在 `contentJson` 的「参考文献」节点 `children` 中由平台一并渲染）。**严禁从 HTML/纯文本重建 docx**，否则表格/公式必丢。预览页「下载 Word 文档」按钮内联 base64 直出平台原始 docx（`window.__DOCX_B64__`），离线可下、零丢失。python-docx 仅用于章节缺失兜底修复（仅环境已装库时生效，绝不运行时自动安装）。凭证失效时导出会报 505，此时引导用户重新扫码登录。
- 交付前完整度检查、SSE 内容捕获、参考文献随 contentJson 渲染等技术细节见 `references/implementation.md`。

---

## §5 错误处理速查

| 场景 | 处理 |
|------|------|
| 二维码扫了没反应 | 看状态文件的 status；超时/过期就重跑登录脚本换码。**先确认没有别的登录轮询进程在跑（429 Connections Exceed = 连接被占满），同一时刻只保留一个** |
| 登录成功但取不到凭证 | 看状态文件的原始返回，给凭证提取逻辑补字段 |
| 凭证失效（接口报 401/403/505） | 立即停掉后台生成任务 → 出二维码引导重新扫码登录（need_login 立即响应，见 §4） |
| 生成失败（平台故障） | 自动重跑一次（§4 自动重试）；**退出码 3 不算失败，是 need_login 信号，走登录引导** |
| Word 缺章节/参考文献 | 完整度检查自动修复 |
| 生成失败（`Data truncation: reference_vip`） | 自定义文献超 15 篇；生成前把用户所选降采至 ≤15 篇再传入 |
| 检索结果与关键词无关（如查「数学」返回 Covid-19 / AIGC 等无关高被引论文） | 匿名（未登录）检索用 `by_ref_cnt` 排序会失效（忽略检索词、返回全库最高被引）；改用 `--sort relevance` 重检，候选正常后再归纳选题 |

先跑 `python selfcheck.py --online`，多数问题它会指出；仍无法定位时按上表现象逐项排查。

---

## §6 接口速查

接口清单、字段、成功判定与已知坑统一见 `references/api-contract.md`，本文件不重复。

---

## §7 打包规范

打包 skill 前必须先跑预检（自动查以下所有项）：

```bash
python <skill路径>/scripts/selfcheck.py --prepack
```

预检覆盖：`scripts/__pycache__/`、`scripts/luhe/`（旧版残留）、`config.json`（含 token 凭证，不得入包）、skill 目录内 outputs/、status.json、history.json 等产出残留、references 交叉引用断链、版本号三处一致性。预检全过再压缩，确保安装包干净。

## §8 版本号规则（每次修改后自动递增）

| 修改规模 | 判定标准 | 示例 |
|---------|---------|------|
| major（X.0.0） | 重大重构 / 不兼容变更（如鉴权模型更换、脚本调用方式改变） | 1.1.0 → 2.0.0 |
| minor（0.X.0） | 功能新增 / 交互行为变化（如新能力、交互流程调整、新增话术节点） | 1.0.0 → 1.1.0 |
| patch（0.0.X） | 小修小补（措辞微调、bug 修复、市场元数据 / 搜索词优化） | 1.1.0 → 1.1.1 |

- 修改完成后立即判断规模并递增 version，**三处同步**：SKILL.md frontmatter + `_meta.json` + `_skillhub_meta.json`。
- 打包产物命名带版本号（`luhe-paper-free_v{版本}.zip`），版本号三处同步维护于 `SKILL.md` frontmatter + `_meta.json` + `_skillhub_meta.json`。
- 多档变更并存时按最高档递增。
