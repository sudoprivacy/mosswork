# 露禾平台接口适配说明（Skill 直连）

> 环境 base_url：以 config.json 的 `base_url` 字段为准（唯一来源，脚本与文档均不写死环境地址）
> 完整地址 = base_url + 路径

本文件是平台接口的**唯一契约来源**（字段、响应、成功判定、已知坑），其他文档不再重复这些字段。

---

## 0. 通用约定

- **鉴权（统一模型）**：
  所有需登录的接口（用户服务、写作服务）统一使用同一套鉴权头：
  ```
  edu-big-data-server-user-skill: {token}
  ```
  token 只作自定义 header 下发（不带 Cookie）；`/server-user`、`/server-agent` 全部使用同一套鉴权。
- **token 来源**：微信扫码登录（详见下方 §1）。
- **token 有效期**：按平台口径约 30 天（本地不做到期校验，失效由接口返回 401/403/505 暴露后重新扫码）。
- **Content-Type**：`application/json`（POST 接口）
- **User-Agent**：必须带，缺失可能被网关拦截 403。

---

## 1. 微信扫码登录

### 1.1 取二维码 `GET /server-user/wechat/mp/mp-qrcode`

- 无需登录；**GET**（POST 会返回 `Request method 'POST' is not supported`）
- 返回 `data`：

| 字段 | 类型 | 说明 |
|------|------|------|
| `ticket` | string | 二维码票据，轮询登录时用 |
| `url` | string | 二维码内容地址（`http://weixin.qq.com/q/...`），渲染成二维码给用户扫 |
| `expireSeconds` | int | 有效期（秒），对客口径统一为「约 5 分钟」 |

```
GET {base_url}/server-user/wechat/mp/mp-qrcode
```
```json
{"data":{"ticket":"gQF68TwAAAAAAAAAAS5...","expireSeconds":300,"url":"http://weixin.qq.com/q/02b0dYNbT2dHr1Hlhv1G11"},"message":"成功","code":200}
```

> ⚠️ `url` 是 `http://weixin.qq.com/...` 关注/登录链接，**不是** `weixin://` 支付协议，可安全展示；但仍建议只展示二维码图片，不把原始串贴给用户。

### 1.2 轮询登录 `POST /server-user/skill/user/login`

- body：`{"ticket": "<上一步的 ticket>"}`
- **未扫码**：返回 `code=200` + `data=null`（**这是正常状态，不是错误**，继续轮询）
- **已扫码**：`data` 携带登录凭证 → 写入本地配置
- `ticket` 为空 → `code=500` + `message:"ticket 不能为空"`
- 默认每 3 秒轮询一次，最长等待 `expireSeconds`（上限由 `--timeout` 控制）

```
POST {base_url}/server-user/skill/user/login
Content-Type: application/json
{"ticket":"gQF68TwAAAAAAAAAAS5..."}
```

- 未扫码响应：`{"data":null,"message":"成功","code":200}`

---

## 2. 登录态检查 `GET /server-user/cu/user-assets/rights/code?code=longEssayWriting`

- 需登录（统一鉴权头）
- **唯一用途**：判断凭证是否仍有效；**不得向用户展示响应里的任何权益 / 金币字段**
- ⚠️ **判定口径（2026-09-11 修正，勿改回 `code == 200`）**：该接口返回的是**账号权益**而非凭证有效性——账号无对应权益时返回 `{"data":null,"message":"未知错误","code":0}`（HTTP 仍 200）。正确口径 = **网关是否接受该凭证**：HTTP 200 且响应体未显式给出 401/403/505/507 即视为有效，仅 401/403/505/507 判失效；网络类异常不下失效结论（误判失效会逼用户无谓重扫）。

```
GET {base_url}/server-user/cu/user-assets/rights/code?code=longEssayWriting
edu-big-data-server-user-skill: {token}
```

---

## 3. 期刊一键成文 `POST /server-agent/writing/paper-agent/one-click-generate-skill`

- 返回 **SSE 流**（不是普通 JSON）；**免费体验额度内无需登录即可调用**，后端要求登录时会在鉴权/额度校验失败时返回 401（或 SSE 空流）
- **必须带 Header `Accept: text/event-stream`**，否则服务端不吐流
- **按需登录**：直接发起 SSE 生成请求（带 `Accept: text/event-stream`）。若后端返回 `code=401` 或 SSE 流为空（未返回任何内容），即判定需要登录，据此拉起微信扫码登录后重试生成；免费额度内后端正常返回流，直接成文，无需预检或强制扫码。
- 完整地址 = `base_url` + `/server-agent/writing/paper-agent/one-click-generate-skill`
- body 字段（实测必填格式）：

| 字段 | 说明 | 取值 |
|------|------|------|
| `title` | 论文标题 | 任意字符串 |
| `language` | 语言 | `中文` / `英文` |
| `threadId` | 串联多次请求 | `"test"` + 20 位随机数字 |
| `type` | 类型 | 固定 `"1"`（期刊成文） |
| `Wordcount` | 字数档位 | 字符串：`"3000"` / `"5000"` / `"8000"` |
| `wordCountLimit` | 字数上限 | 整数：`3000` / `5000` / `8000` |
| `referenceVip` ⚠️ | **自定义参考文献（可选）**：用户从期刊高级检索结果中挑选的文献「对象数组」，让平台优先 / 强制引用这些文献生成参考文献。不传则平台自动推荐 | **字符串形式的 JSON 数组 `[{}]`**：`json.dumps(文献对象数组, ensure_ascii=False)`。每个对象必须携带平台契约的完整字段：`file_id`（数字 id）+ 检索原始条目全量字段（`abstr`/`authorInfo`/`journalInfo`/`beginPage`/`endPage`/`doi`/`vol`/`num`/`keywordInfo`/`fundInfo`/`pubDate`/`type`/`typename`/`byRefCnt` 等）。由检索脚本从候选结果抽取所选编号后写出，以字符串形式的 JSON 数组经接口传入（**双键同发**：`referenceVip` + `reference-vip` 兼容旧网关路径）。检索时用 `types=1`（期刊）、`size=20`，按相关度 / 被引量 / 年份排序 |

> **自定义参考文献采纳规则**：
> 1. 每个文献对象必须带全量字段 + `file_id`，缺字段后端解析不出文献对象，表现为「所选 0 命中」。
> 2. 用户选不足 15 篇时系统会去文献库补足引用池。
> 3. 补足后模型仍按相关性自由标引，不保证所选 100% 被引用。

- ⚠️ `Wordcount`（首字母大写，**字符串**）与 `wordCountLimit`（驼峰，**整数**）大小写/类型不同，照此原样传
- SSE 事件顺序：`abstract.done` → `paper.created` → `outline.done` → 正文/进度分片 → `paper.done`
- ✅ **成功判定 = 收到 `paper.done` + 正文非空**。`paper.done` 载荷只有
  `threadId / keywords / outlineTree / content / contentLength`，**不含 `paperId`**，切勿以 `paper_id` 判定成败。
- **生成时长约 2-4 分钟**；脚本按流式边收边解析（`--max-wait` 默认 600s 兜底），不靠单次 curl 拿结果
- 请求示例：
```
POST {base_url}/server-agent/writing/paper-agent/one-click-generate-skill
Header: Accept: text/event-stream
edu-big-data-server-user-skill: {token}
{
  "title": "基于项目式学习的小学科学课程设计",
  "language": "中文",
  "threadId": "test" + "12345678901234567890",
  "type": "1",
  "Wordcount": "5000",
  "wordCountLimit": 5000
}
```

---

## 4. 导出 Word `POST /server-agent/writing/paper/export/direct`

- body：

| 字段 | 类型 | 说明 |
|------|------|------|
| `type` | string | 论文类型，与成文接口的 `type` 一致（期刊成文固定 `"1"`） |
| `title` | string | 论文标题 |
| `abstracts` | string | 摘要 |
| `keywords` | string | 关键词 |
| `authors` | string | 作者简介（无则传空串） |
| `contentJson` | List\<DocumentSection\> | 完整章节树，含「参考文献」节点 |

- 返回 `{code:200, data:"<docx 的 OSS 下载链接>"}`；`data` 为空视为失败
- ⚠️ `contentJson` 必须完整：缺章节会导致导出的 docx 缺内容
```
POST {base_url}/server-agent/writing/paper/export/direct
Content-Type: application/json
edu-big-data-server-user-skill: {token}
{
  "type": "1",
  "title": "基于项目式学习的小学科学课程设计",
  "abstracts": "……",
  "keywords": "项目式学习；科学课程",
  "authors": "",
  "contentJson": [ ... ]
}
```

---

## 5. 参考文献引文 `POST /server-agent/writing/paper/literaturereference`


- **body = 文献 ID 字符串数组**（非 `{"fileId":...}`）：`["7108348057","7200932273",...]`
- **主机 = `lit_host`（缺省回退 `base_url`，二者均以 config.json 为准）**
- ⚠️ **必须带 `User-Agent` 头**，否则网关可能返回 403
- **返回** `{code:200, message:"成功", data:[{id, gbstr}, ...]}`。`gbstr` 为平台封装好的 GB/T 7714 引文串，**不返回 type 字段**——详情链接 type 默认约定为 `1`
- **用途**：① 取 `gbstr` 作为参考文献条目文本（替代本地格式化）；② 按 `id` 构造详情页 URL 供点击跳转（详情页固定走主站 `https://luhe.cqvip.com/weResearch/literatureDetail/{id}/1`，与 API 主机解耦）
- 处理策略：一次性批量拉取全部 gbstr（best-effort，失败则降级为本地格式化）
```
POST {base_url}/server-agent/writing/paper/literaturereference
edu-big-data-server-user-skill: {token}
User-Agent: Mozilla/5.0 ...
Content-Type: application/json
["7108348057","7200932273","7108917486"]
```
- 响应示例：
```json
{"data":[{"id":"7108348057","gbstr":"曹璐.项目式教学在语文教学中的应用研究[J].文教资料,2022:110-113."}, ...],"message":"成功","code":200}
```

---

## 接口清单速查（6 个）

| # | 方法 | 路径 | 鉴权 | 用途 |
|---|------|------|------|------|
| 1 | GET | /server-user/wechat/mp/mp-qrcode | 否 | 取微信登录二维码（ticket + url） |
| 2 | POST | /server-user/skill/user/login | 否（body 带 ticket） | 轮询登录换凭证 |
| 3 | GET | /server-user/cu/user-assets/rights/code?code=longEssayWriting | 统一鉴权 | 登录态检查（探活） |
| 4 | POST | /server-agent/writing/paper-agent/one-click-generate-skill | 看后端返回  | 一键成文（SSE） |
| 5 | POST | /server-agent/writing/paper/export/direct | 否  | 导出 docx（免 paperId） |
| 6 | POST | /server-agent/writing/paper/literaturereference |否  | 参考文献引文 gbstr |

「统一鉴权」= token 作 header（`edu-big-data-server-user-skill: {token}`）下发，不带 Cookie。token 由微信扫码登录获取，base_url / lit_host 一律以 config.json 为准。
