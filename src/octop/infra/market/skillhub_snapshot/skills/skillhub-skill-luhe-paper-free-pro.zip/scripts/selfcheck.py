#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""自检脚本 —— 装完 skill 先跑这个，确认环境和配置没问题。

用法：
    cd scripts
    python selfcheck.py            # 结构冒烟 + 依赖检查 + 配置检查（离线，默认）
    python selfcheck.py --unit     # 上面 + 跑完整单元测试
    python selfcheck.py --online   # 上面 + 真连服务器（查登录态 / 探文献接口）

退出码：0 全通过；1 有致命问题；上层可据此判断是否继续。
"""

import argparse
import importlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

OK, WARN, FAIL = "  [OK]  ", " [WARN] ", " [FAIL] "

_results = {"ok": 0, "warn": 0, "fail": 0}

# 平台地址的受信口径：必须是第一方（维普/露禾 *.cqvip.com）+ 显式 HTTPS。
# 背景（2026-09-14 安全加固）：config.example.json 的 base_url/lit_host 曾被设为第三方
# 免费内网穿透域名（明文 HTTP，如 *.natappfree.cc）。用户按模板复制即把微信登录凭证
# （header edu-big-data-server-user-skill）与论文正文发往该地址；明文 HTTP 下中间人可读
# 可改，且免费隧道子域到期后会被第三方重新注册、DNS 可随时被改指到任意主机。
FIRST_PARTY_SUFFIXES = (".cqvip.com",)


def audit_platform_url(url, label="base_url"):
    """审计单个平台地址 → 返回问题描述列表（空列表 = 合规）。

    纯函数（不打印、不读文件），便于单测。口径两条：
      1. 必须显式 `https://` —— 明文 HTTP 会让凭证与正文以明文过网；
      2. 主机必须是第一方 `*.cqvip.com` —— 第三方域（含内网穿透）一律不受信。
    """
    raw = (url or "").strip()
    if not raw:
        return [f"{label} 为空"]
    m = re.match(r"^([A-Za-z][A-Za-z0-9+.\-]*)://([^/?#]+)", raw)
    if not m:
        return [f"{label} 不是带 scheme 的合法 URL：{raw}"]
    scheme = m.group(1).lower()
    # 去掉 userinfo（user:pass@host）再取主机名
    hostport = m.group(2).split("@")[-1]
    host = hostport.split(":")[0].strip("[]").lower()

    problems = []
    if scheme != "https":
        problems.append(
            f"{label} 使用明文 {scheme.upper()}（{raw}）：登录凭证与论文正文会明文过网，中间人可读可改")
    if not any(host == s.lstrip(".") or host.endswith(s) for s in FIRST_PARTY_SUFFIXES):
        problems.append(
            f"{label} 指向非第一方域名 `{host}`（{raw}）：第三方域名（尤其内网穿透）不受信，"
            f"凭证与正文会被发往该主机；应改为第一方 HTTPS 地址，如 https://luhe.cqvip.com")
    return problems


def _check_url_field(url, label, level, where=""):
    """按给定级别上报单个地址字段的问题；返回问题条数。"""
    problems = audit_platform_url(url, label)
    for p in problems:
        _say(level, f"平台地址不合规{'（' + where + '）' if where else ''}", p)
    return len(problems)


def _say(level, msg, detail=""):
    if level is OK:
        _results["ok"] += 1
    elif level is WARN:
        _results["warn"] += 1
    else:
        _results["fail"] += 1
    print(f"{level}{msg}" + (f"\n         └─ {detail}" if detail else ""))


def section(name):
    print(f"\n=== {name} ===")


# ---------------------------------------------------------------------------
# 1. 文件结构
# ---------------------------------------------------------------------------

def check_layout():
    section("文件结构")
    required = [
        ("SKILL.md", ROOT),
        ("config.example.json", ROOT),
        ("scripts/generate.py", ROOT),
        ("scripts/login.py", ROOT),
        ("references/api-contract.md", ROOT),
    ]
    for rel, base in required:
        p = os.path.join(base, rel.replace("/", os.sep))
        if os.path.isfile(p):
            _say(OK, f"存在 {rel}")
        else:
            _say(FAIL, f"缺失 {rel}", f"应在 {p}")

    # 产出目录应在用户数据目录（不随 skill 打包）；此处只验证可创建，不在 skill 根目录建任何东西
    try:
        import generate as _G
        data_out = os.path.join(_G.resolve_data_dir(), "outputs")
        os.makedirs(data_out, exist_ok=True)
        _say(OK, f"输出目录就绪（用户数据目录：{data_out}）")
    except Exception as e:
        _say(FAIL, "无法创建输出目录（用户数据目录）", str(e))


# ---------------------------------------------------------------------------
# 2. 依赖
# ---------------------------------------------------------------------------

def check_deps():
    section("Python 依赖")
    if sys.version_info < (3, 8):
        _say(FAIL, f"Python 版本过低：{sys.version.split()[0]}", "需要 3.8+")
    else:
        _say(OK, f"Python {sys.version.split()[0]}")

    # 必需：标准库即可完成成文与导出
    for mod in ("json", "urllib.request", "argparse"):
        try:
            importlib.import_module(mod)
            _say(OK, f"标准库 {mod}")
        except Exception as e:
            _say(FAIL, f"标准库 {mod} 不可用", str(e))

    # 可选：缺了只影响单一能力，不阻断主流程
    optional = {
        "docx": "python-docx —— 主流程已零依赖（参考文献随 contentJson 由平台渲染、作者简介移除、完整度核对均为标准库实现，不会因缺此包而丢文献）；python-docx 仅用于离线重建工具 repair_from_log.py 的章节缺失兜底修复",
    }
    for mod, why in optional.items():
        try:
            importlib.import_module(mod)
            _say(OK, f"可选依赖 {mod} 已安装")
        except ImportError:
            _say(WARN, f"可选依赖 {mod} 未安装", why)

    # 必需（登录链路）：segno 缺失时无法渲染二维码 PNG，且严禁以链接形式交付 → 硬失败
    try:
        import segno  # noqa: F401
        _say(OK, "segno 已安装（二维码渲染）")
    except ImportError:
        _say(FAIL, "segno 未安装",
             "微信扫码登录必需：隔离环境执行 pip install segno（二维码严禁以链接形式交付，无降级路径）")


# ---------------------------------------------------------------------------
# 3. 模块可导入 + 关键函数在位
# ---------------------------------------------------------------------------

def check_imports():
    section("模块与接口")
    try:
        import generate as G
    except Exception as e:
        _say(FAIL, "generate.py 导入失败", str(e))
        return None
    _say(OK, "generate.py 可导入")

    expected = [
        "build_auth_headers", "resolve_config_path", "load_config", "gen_payload",
        "parse_body_sections", "build_references_items", "remap_citations",
        "validate_citations", "stream_generate", "export_and_download",
        "render_html_preview", "check_login",
    ]
    missing = [fn for fn in expected if not callable(getattr(G, fn, None))]
    if missing:
        _say(FAIL, "generate.py 缺少函数", ", ".join(missing))
    else:
        _say(OK, f"generate.py 关键函数齐全（{len(expected)} 个）")

    try:
        import login as L
        _say(OK, "login.py 可导入")
        lmissing = [fn for fn in ("fetch_qrcode", "login_with_ticket", "extract_token",
                                  "make_qr_image", "poll_login", "resolve_config_path")
                    if not callable(getattr(L, fn, None))]
        if lmissing:
            _say(FAIL, "login.py 缺少函数", ", ".join(lmissing))
        else:
            _say(OK, "login.py 关键函数齐全")
    except Exception as e:
        _say(FAIL, "login.py 导入失败", str(e))
    return G


# ---------------------------------------------------------------------------
# 4. 配置
# ---------------------------------------------------------------------------

def check_config(G):
    section("配置")
    if G is None:
        return None

    env_hint = os.environ.get("LUHE_CONFIG")
    path = G.resolve_config_path()
    abspath = os.path.abspath(path)
    data_dir = os.path.abspath(G.resolve_data_dir())
    if env_hint:
        origin = "$LUHE_CONFIG"
    elif abspath.startswith(data_dir + os.sep) or abspath == os.path.join(data_dir, "config.json"):
        origin = "用户数据目录"
    else:
        origin = "skill 根目录（全局）"
    print(f"         配置来源：{origin} → {path}")
    if origin == "$LUHE_CONFIG":
        _say(OK, "config.json 取自 $LUHE_CONFIG 指定位置（用户自选落点）")
    elif origin == "skill 根目录（全局）":
        # 凭证的预期落点：本机所有会话共用（工作空间每会话新建目录，写在那里会导致新会话读不到）
        _say(OK, "config.json 位于全局配置（本机所有会话共用，跨会话免扫码）")
    else:
        _say(WARN, "config.json 位于用户数据目录（历史落点）",
             "仍可正常使用；凭证写全局配置可避免新会话读不到而重复扫码")

    cfg = G.load_config(path)
    if cfg is None:
        _say(WARN, "未找到 config.json（首次使用属正常）",
             "复制 config.example.json 为 config.json，填 base_url 后即可登录")
        return None
    _say(OK, "config.json 可读")

    if cfg.get("base_url"):
        _say(OK, f"base_url = {cfg['base_url']}")
    else:
        _say(FAIL, "config.json 缺 base_url", "填平台地址（取值参考 config.example.json；脚本不写死任何环境地址）")

    lit = cfg.get("lit_host") or cfg.get("base_url") or ""
    _say(OK, f"lit_host = {lit}" if lit else "lit_host 未配置（将回退 base_url）")

    # 地址安全性：明文 HTTP / 非第一方域名会把凭证与正文发往不受信主机
    bad = 0
    for field in ("base_url", "lit_host"):
        if cfg.get(field):
            bad += _check_url_field(cfg[field], field, WARN, where="在用 config.json")
    if bad == 0:
        _say(OK, "平台地址安全性：第一方 + HTTPS，合规")

    if cfg.get("token"):
        _say(OK, "已有登录凭证", f"来源：{cfg.get('token_source') or '未知'}")
    else:
        _say(WARN, "尚未登录", "在对话里跑 scripts/login.py 出微信二维码，扫码后自动写入凭证")
    return cfg


# ---------------------------------------------------------------------------
# 5. 单元测试
# ---------------------------------------------------------------------------

def run_unit():
    section("单元测试")
    r = subprocess.run([sys.executable, os.path.join(HERE, "runtests.py")],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    tail = (r.stderr or r.stdout or "").strip().splitlines()
    summary = next((l for l in reversed(tail) if l.startswith("Ran ") or l in ("OK",) or l.startswith("FAILED")), "")
    ran = next((l for l in tail if l.startswith("Ran ")), "")
    if r.returncode == 0:
        _say(OK, f"单元测试通过（{ran or summary}）")
    else:
        _say(FAIL, "单元测试未通过", "\n         ".join(tail[-12:]))


# ---------------------------------------------------------------------------
# 6. 联网端到端
# ---------------------------------------------------------------------------

def run_online(G, cfg):
    section("联网检查")
    if not cfg or not cfg.get("base_url"):
        _say(WARN, "跳过：无 base_url", "先配置 config.json")
        return
    if not cfg.get("token"):
        _say(WARN, "跳过：未登录", "先在对话里完成登录")
        return

    ok = G.check_login(cfg["base_url"], cfg["token"])
    if ok:
        _say(OK, "登录态有效")
    else:
        _say(FAIL, "登录态已失效", "重新跑 scripts/login.py 扫码登录")

    lit = cfg.get("lit_host") or cfg.get("base_url") or ""
    m = G.fetch_references_batch(lit, cfg["token"], ["0"])
    # 探针文献号必然查不到，只验证「连得上、没被 WAF 拦」——异常时函数返回 {}
    if isinstance(m, dict):
        _say(OK, f"文献引文接口可达（{lit}）")
    else:
        _say(FAIL, "文献引文接口异常", "检查 lit_host 是否为正式域名、User-Agent 是否被 WAF 拦截")


# ---------------------------------------------------------------------------
# 6. 打包预检（--prepack）
# ---------------------------------------------------------------------------

def _check_prepack_residue():
    """skill 目录内不得有运行残留 / 凭证。"""
    section("打包残留检查")
    bad_dirs = [
        ("scripts/__pycache__", True), ("scripts/luhe", True),
        ("outputs", True), ("paper-writer-data", True),
    ]
    for rel, is_dir in bad_dirs:
        p = os.path.join(ROOT, rel.replace("/", os.sep))
        if os.path.exists(p):
            _say(FAIL, f"存在残留 {rel}/", "打包前删除该目录")
        else:
            _say(OK, f"无 {rel}/ 残留")
    for rel in ("status.json", "history.json"):
        p = os.path.join(ROOT, rel)
        if os.path.isfile(p):
            _say(FAIL, f"存在残留 {rel}", "打包前删除（产出应只落在用户工作空间）")
        else:
            _say(OK, f"无 {rel} 残留")

    cfg = os.path.join(ROOT, "config.json")
    if os.path.isfile(cfg):
        try:
            with open(cfg, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("token"):
                _say(FAIL, "skill 根目录 config.json 含 token 凭证",
                     "凭证本就该留在本机（全局配置），不得随包分发；打包 / 分享前必须把 token 置空")
            else:
                _say(WARN, "skill 根目录存在空 config.json",
                     "可保留作出厂默认；确认无凭证后打包")
        except Exception as e:
            _say(FAIL, "skill 根目录 config.json 不可解析", str(e))
    else:
        _say(OK, "skill 根目录无 config.json（干净）")


def _check_reference_links():
    """references/*.md 之间的 § 交叉引用不断链。

    规则：`话术 §X.Y` / `conversation-scripts.md §X.Y` 形式的引用必须能在
    conversation-scripts.md 中找到对应 `## §X.Y` 标题；`runbook §N` 同理。
    """
    section("文档交叉引用检查")
    refs = os.path.join(ROOT, "references")
    texts = {}
    for fn in os.listdir(refs):
        if fn.endswith(".md"):
            with open(os.path.join(refs, fn), "r", encoding="utf-8") as f:
                texts[fn] = f.read()

    broken = []
    for fn, text in texts.items():
        # 引用话术库节点的写法：话术 §0.2b / conversation-scripts.md §0.4 等
        for m in re.finditer(r"(?:conversation-scripts(?:\.md)?[^\n]{0,12})?话术\s*[§]([0-9a-z.]+)", text):
            anchor = m.group(1)
            target = texts.get("conversation-scripts.md", "")
            if f"§{anchor}" not in target:
                broken.append(f"{fn} → 话术 §{anchor}（conversation-scripts.md 无此节）")
        # 引用 runbook 节点的写法：runbook §4 / runbook.md §0
        for m in re.finditer(r"runbook(?:\.md)?\s*[§]([0-9]+)", text):
            anchor = m.group(1)
            target = texts.get("runbook.md", "")
            if not re.search(rf"^##\s*[§]{anchor}\b", target, re.M):
                broken.append(f"{fn} → runbook §{anchor}（runbook.md 无此节）")
    if broken:
        for b in broken[:12]:
            _say(FAIL, "交叉引用断链", b)
        if len(broken) > 12:
            _say(FAIL, f"另有 {len(broken) - 12} 处断链未列出")
    else:
        _say(OK, "references 交叉引用无断链")


def _check_version_consistency():
    """版本号三处同步：SKILL.md frontmatter / _meta.json / _skillhub_meta.json。"""
    section("版本号一致性")
    skill_md = os.path.join(ROOT, "SKILL.md")
    versions = {}
    try:
        with open(skill_md, "r", encoding="utf-8") as f:
            m = re.search(r"^version:\s*([0-9.]+)\s*$", f.read(), re.M)
        if m:
            versions["SKILL.md"] = m.group(1)
    except Exception:
        pass
    for fn in ("_meta.json", "_skillhub_meta.json"):
        try:
            with open(os.path.join(ROOT, fn), "r", encoding="utf-8") as f:
                versions[fn] = json.load(f).get("version")
        except Exception:
            pass
    if len(versions) < 3:
        _say(WARN, "版本文件读取不全", f"已读到：{versions}")
        return
    vals = set(versions.values())
    if len(vals) == 1:
        _say(OK, f"版本号三处一致（{vals.pop()}）")
    else:
        _say(FAIL, "版本号不一致", str(versions))


def _check_template_address(level=WARN):
    """出厂模板 config.example.json 的地址合规性。

    模板会被用户（或 agent）直接复制为 config.json，故模板里的地址就是**将要生效**的
    地址，必须与在用配置同标准：第一方 + HTTPS。
    """
    path = os.path.join(ROOT, "config.example.json")
    if not os.path.isfile(path):
        _say(level, "未找到 config.example.json", "用户无模板可复制，无法配置平台地址")
        return 1
    try:
        with open(path, "r", encoding="utf-8") as f:
            tpl = json.load(f)
    except Exception as e:
        _say(FAIL, "config.example.json 不可解析", str(e))
        return 1
    bad = 0
    for field in ("base_url", "lit_host"):
        if tpl.get(field):
            bad += _check_url_field(tpl[field], field, level, where="config.example.json 模板")
    if bad == 0:
        _say(OK, "出厂模板地址合规（第一方 + HTTPS）")
    return bad


def _check_platform_addresses():
    """打包硬门槛：出厂模板与出厂 config.json 的平台地址一律不得指向第三方明文地址。"""
    section("平台地址安全（打包硬门槛）")
    _check_template_address(FAIL)
    cfg = os.path.join(ROOT, "config.json")
    if not os.path.isfile(cfg):
        _say(OK, "skill 根目录无 config.json（无需检查）")
        return
    try:
        with open(cfg, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        _say(FAIL, "skill 根目录 config.json 不可解析", str(e))
        return
    bad = 0
    for field in ("base_url", "lit_host"):
        if data.get(field):
            bad += _check_url_field(data[field], field, FAIL, where="skill 根目录 config.json")
    if bad == 0:
        _say(OK, "skill 根目录 config.json 地址合规")


def run_prepack():
    print(">>> 打包预检（--prepack）")
    _check_prepack_residue()
    _check_platform_addresses()
    _check_reference_links()
    _check_version_consistency()


# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description="luhe-paper-free 自检")
    ap.add_argument("--unit", action="store_true", help="附带跑单元测试")
    ap.add_argument("--online", action="store_true", help="附带跑联网端到端检查（含 --unit）")
    ap.add_argument("--prepack", action="store_true",
                    help="打包预检：残留文件 / 凭证外泄 / 平台地址安全 / 文档交叉引用断链 / 版本号三处一致性")
    args = ap.parse_args()

    print("luhe-paper-free 自检")
    print(f"skill 根目录：{ROOT}")

    if args.prepack:
        run_prepack()
        section("结论")
        r = _results
        print(f"通过 {r['ok']} · 提醒 {r['warn']} · 失败 {r['fail']}")
        if r["fail"]:
            print("打包预检未通过，请先按上面 [FAIL] 处理。")
            return 1
        print("打包预检通过，可以打包。")
        return 0

    check_layout()
    check_deps()
    G = check_imports()
    cfg = check_config(G)

    if args.unit or args.online:
        run_unit()
    if args.online:
        run_online(G, cfg)

    section("结论")
    r = _results
    print(f"通过 {r['ok']} · 提醒 {r['warn']} · 失败 {r['fail']}")
    if r["fail"]:
        print("存在致命问题，请先按上面 [FAIL] 处理。")
        return 1
    if r["warn"]:
        print("可以正常使用；[WARN] 是建议项，不影响主流程。")
    else:
        print("一切正常。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
