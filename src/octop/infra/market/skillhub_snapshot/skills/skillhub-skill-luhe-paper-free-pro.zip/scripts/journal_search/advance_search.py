"""
advance_search.py — 维普/露禾 期刊高级检索（一步法）

直接调用 POST https://eduagent.cqvip.com/server-journal/journal/AdvanceSearch
（无需 SSE 两步生成检索式，conditions 由调用方直接提供）。

用法：
  python advance_search.py "人工智能"
  python advance_search.py "人工智能" --field U --year-start 2020 --year-end 2026 --sort by_ref_cnt --size 20
  python advance_search.py --conditions '[{"content":"人工智能","field":"U","exact":false,"logicalOperator":"AND"}]'
  python advance_search.py "人工智能" --json
  python advance_search.py "人工智能" -o result.md
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional

from common import (
    ADVANCE_SEARCH_PATH,
    BASE_URL,
    DEFAULT_AGS_CODES,
    DEFAULT_TYPES,
    Document,
    EduAgentCookieError,
    SearchResult,
    build_headers,
    get_cookie,
    http_post_json,
    parse_response,
    resolve_output_path,
)


# ---------------------------------------------------------------------------
# 构造请求体
# ---------------------------------------------------------------------------

# 排序码映射：支持原始接口码与易记别名
_SORT_ALIASES = {
    "": "",
    "relevance": "",
    "related": "",
    "by_ref_cnt": "by_ref_cnt",
    "cited": "by_ref_cnt",
    "cite": "by_ref_cnt",
    "pub_date": "pub_date",
    "time": "pub_date",
    "date": "pub_date",
}


def normalize_sort(value: str) -> str:
    """把排序参数归一为接口接受的码。

    "" / relevance → 相关度倒序
    by_ref_cnt / cited → 被引量倒序
    pub_date / time → 时间倒序
    """
    key = (value or "").strip().lower()
    if key not in _SORT_ALIASES:
        # 未知值：原样透传，由接口决定是否报错
        return value
    return _SORT_ALIASES[key]


def build_conditions(
    query: Optional[str],
    field: str,
    exact: bool,
    raw_conditions: Optional[str],
) -> List[Dict[str, Any]]:
    """根据 query+field 或原始 conditions JSON 构造 AdvanceSearch 的 conditions 数组。"""
    if raw_conditions:
        try:
            parsed = json.loads(raw_conditions)
        except json.JSONDecodeError as exc:
            raise ValueError(f"--conditions 不是合法 JSON：{exc}") from exc
        if not isinstance(parsed, list):
            raise ValueError("--conditions 必须是数组")
        return [dict(c) for c in parsed if isinstance(c, dict)]

    if not query:
        raise ValueError("未提供 query 也未提供 --conditions，无法构造检索条件")

    return [
        {
            "content": query,
            "exact": exact,
            "logicalOperator": "AND",
            "field": field,
        }
    ]


def build_body(
    conditions: List[Dict[str, Any]],
    *,
    year_start: Optional[int],
    year_end: Optional[int],
    sort: str,
    order: bool,
    language: str,
    types: List[int],
    ags_codes: List[str],
    page: int,
    size: int,
    open_synonym: bool,
    open_force_translate: bool,
) -> Dict[str, Any]:
    """拼装与抓包一致的需要体。"""
    return {
        "yearStart": year_start,
        "yearEnd": year_end,
        "sort": sort,
        "page": page,
        "size": size,
        "order": order,
        "language": language,
        "ags": True,
        "aggsParams": {},
        "conditions": conditions,
        "types": types,
        "agsCodes": ags_codes,
        "timeStart": None,
        "timeEnd": None,
        "timeType": None,
        "openSynonym": open_synonym,
        "openForceTranslate": open_force_translate,
    }


# ---------------------------------------------------------------------------
# 核心调用
# ---------------------------------------------------------------------------

def advance_search(
    conditions: List[Dict[str, Any]],
    *,
    year_start: Optional[int] = None,
    year_end: Optional[int] = None,
    sort: str = "",
    order: bool = False,
    language: str = "",
    types: Optional[List[int]] = None,
    ags_codes: Optional[List[str]] = None,
    page: int = 1,
    size: int = 10,
    open_synonym: bool = False,
    open_force_translate: bool = False,
    cookie: Optional[str] = None,
    query_label: str = "",
    timeout: float = 60.0,
) -> SearchResult:
    """调用 AdvanceSearch，返回 SearchResult。

    Note: Cookie 凭据通过环境变量 EDUAGENT_COOKIE 提供，不允许参数传入。
    """
    ck = cookie or ""
    if not ck:
        try:
            ck = get_cookie()
        except EduAgentCookieError:
            ck = ""  # 无凭据时匿名检索（检索接口本身免登录）
    body = build_body(
        conditions,
        year_start=year_start,
        year_end=year_end,
        sort=sort,
        order=order,
        language=language,
        types=types if types is not None else DEFAULT_TYPES,
        ags_codes=ags_codes if ags_codes is not None else DEFAULT_AGS_CODES,
        page=page,
        size=size,
        open_synonym=open_synonym,
        open_force_translate=open_force_translate,
    )

    url = f"{BASE_URL}{ADVANCE_SEARCH_PATH}"
    headers = build_headers(ck)
    data = http_post_json(url, body, headers, timeout)

    result = parse_response(query_label, data)
    if result.code not in (200, None) or not data.get("data"):
        raise RuntimeError(
            f"AdvanceSearch 返回异常：code={result.code} message={result.message}"
        )
    return result


# ---------------------------------------------------------------------------
# Markdown 渲染
# ---------------------------------------------------------------------------

def _safe_filename(query: str) -> str:
    s = re.sub(r"[《》<>:\"/\\|?*\r\n\t]", "", query or "").strip()
    s = re.sub(r"\s+", "_", s)
    return s[:40] or "journal"


def build_markdown(result: SearchResult) -> str:
    pag = result.pagination
    total = pag.get("total")
    page = pag.get("page")
    total_pages = pag.get("total_pages")
    size = pag.get("size")

    lines: List[str] = []
    lines.append(f"# 期刊检索结果：{result.query}")
    lines.append("")
    lines.append(
        f"- 命中总数：**{total}** 篇"
        f"（第 {page}/{total_pages} 页，每页 {size} 条）"
    )
    lines.append(f"- 状态：code={result.code} {result.message}")
    lines.append("")

    lines.append("## 文献列表")
    lines.append("")
    if not result.documents:
        lines.append("_未检索到相关文献。_")
    for i, doc in enumerate(result.documents, 1):
        lines.append(f"### {i}. {doc.title}")
        meta = []
        if doc.authors:
            meta.append(doc.authors)
        if doc.journal:
            meta.append(doc.journal)
        if doc.year:
            meta.append(str(doc.year))
        if doc.typename:
            meta.append(doc.typename)
        if doc.vol or doc.issue:
            vol_issue = f"Vol.{doc.vol} No.{doc.issue}" if doc.vol and doc.issue else (doc.vol or doc.issue)
            meta.append(vol_issue)
        if meta:
            lines.append("**" + " | ".join(meta) + "**")
        extra = []
        if doc.cited is not None:
            extra.append(f"被引 {doc.cited}")
        if doc.views is not None:
            extra.append(f"浏览 {doc.views}")
        if doc.collections is not None:
            extra.append(f"收藏 {doc.collections}")
        if extra:
            lines.append("`" + " · ".join(extra) + "`")
        if doc.abstract:
            ab = doc.abstract
            lines.append(ab[:400] + ("…" if len(ab) > 400 else ""))
        if doc.doi:
            lines.append(f"DOI: {doc.doi}")
        if doc.detail_url:
            lines.append(f"[详情链接]({doc.detail_url})")
        lines.append("")

    return "\n".join(lines)


def write_markdown_report(result: SearchResult, output: Optional[str]) -> str:
    md = build_markdown(result)
    fname = None if output else f"journal_{_safe_filename(result.query)}.md"
    path = resolve_output_path(output, fname)
    with open(path, "w", encoding="utf-8") as f:
        f.write(md)
    return path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _csv_ints(s: str) -> List[int]:
    return [int(x) for x in s.split(",") if x.strip()]


def _csv_strs(s: str) -> List[str]:
    return [x.strip() for x in s.split(",") if x.strip()]


def main() -> int:
    parser = argparse.ArgumentParser(
        description="维普/露禾 期刊高级检索（eduagent AdvanceSearch）"
    )
    parser.add_argument("query", nargs="?", default=None, help="检索词（默认字段 U=题名）")
    parser.add_argument("--field", default="U",
                        help="字段码：U 题名/K 关键词/A 作者/J 刊名/S 单位/C 分类号/O 文摘/R 基金")
    parser.add_argument("--exact", action="store_true", help="精确匹配（默认模糊）")
    parser.add_argument("--year-start", type=int, default=None, help="起始年份")
    parser.add_argument("--year-end", type=int, default=None, help="结束年份")
    parser.add_argument("--sort", default="",
                        help="排序：relevance/"" 相关度倒序 | by_ref_cnt/cited 被引量倒序 | pub_date/time 时间倒序")
    parser.add_argument("--order", action="store_true", help="反转排序方向（升序）")
    parser.add_argument("--language", default="", help="语言过滤：zh 中文 / en 英文 / 留空全部")
    parser.add_argument("--types", default=",".join(str(t) for t in DEFAULT_TYPES),
                        help="文献类型，逗号分隔，默认 1（期刊）")
    parser.add_argument("--ags-codes", default=",".join(DEFAULT_AGS_CODES),
                        help="聚合分面维度，逗号分隔")
    parser.add_argument("--page", type=int, default=1, help="页码（默认 1）")
    parser.add_argument("--size", type=int, default=10, help="每页条数（默认 10）")
    parser.add_argument("--conditions", default=None,
                        help="原始 conditions 数组 JSON，覆盖 query 拼装")
    parser.add_argument("--open-synonym", action="store_true", help="开启同义词扩展")
    parser.add_argument("--open-force-translate", action="store_true", help="开启强制翻译")
    parser.add_argument("--json", action="store_true", help="以 JSON 输出完整聚合结果")
    parser.add_argument("-o", "--output", default=None,
                        help="Markdown 报告输出路径（默认按检索词自动命名）")
    parser.add_argument("--no-md", action="store_true", help="不写 Markdown 文件（调试用）")
    args = parser.parse_args()

    try:
        conditions = build_conditions(args.query, args.field, args.exact, args.conditions)
    except ValueError as exc:
        print(f"[参数错误] {exc}", file=sys.stderr)
        return 2

    try:
        result = advance_search(
            conditions,
            year_start=args.year_start,
            year_end=args.year_end,
            sort=normalize_sort(args.sort),
            order=args.order,
            language=args.language,
            types=_csv_ints(args.types),
            ags_codes=_csv_strs(args.ags_codes),
            page=args.page,
            size=args.size,
            open_synonym=args.open_synonym,
            open_force_translate=args.open_force_translate,
            query_label=args.query or "(conditions)",
        )
    except EduAgentCookieError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(f"# 期刊检索：{result.query}")
        print(f"命中 {result.pagination.get('total')} 篇"
              f"（第 {result.pagination.get('page')}/{result.pagination.get('total_pages')} 页）")
        print()
        for i, doc in enumerate(result.documents, 1):
            cited = f" 被引{doc.cited}" if doc.cited is not None else ""
            meta = " | ".join(x for x in [doc.authors, doc.journal, str(doc.year), doc.typename] if x)
            print(f"{i}. {doc.title}")
            if meta:
                print(f"   {meta}{cited}")
            if doc.abstract:
                print(f"   {doc.abstract[:160]}{'…' if len(doc.abstract) > 160 else ''}")
            if doc.detail_url:
                print(f"   {doc.detail_url}")
            print()

    if not args.no_md:
        md_path = write_markdown_report(result, args.output)
        print(f"[报告] 已生成 Markdown：{md_path}", file=sys.stderr)
        if args.json:
            print(md_path)

    return 0


if __name__ == "__main__":
    sys.exit(main())
