#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""纯逻辑单元测试 —— 零第三方依赖、离线可跑。

覆盖 generate.py / login.py 里所有不碰网络的纯函数：
配置定位、鉴权头、请求体构造、SSE 正文解析、参考文献解析与格式化、
引用重编号、标引校验、登录凭证解析、一键成文地址拼接。

例外：TestPreviewServerLifecycle 会起一个本地 127.0.0.1 预览服务，
只走回环口、不访问任何外部接口，用于守住「空闲自毁后进程退出 + 端口释放」契约。

用法：
    cd scripts
    python runtests.py            # 跑全部
    python runtests.py -v         # 显示每个用例
"""

import json
import os
import re
import sys
import tempfile
import threading
import time
import unittest
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import generate as G  # noqa: E402
import login as L  # noqa: E402
import export as E  # noqa: E402  导出解耦后，部分纯逻辑（_plain / _flatten_tree_nodes）落在了 export
import reference_search as R  # noqa: E402  防死链校验等纯逻辑测试


# ---------------------------------------------------------------------------
# 配置定位（--config > $LUHE_CONFIG > skill 根目录/config.json）
# ---------------------------------------------------------------------------

class TestResolveConfigPath(unittest.TestCase):

    def test_cli_wins(self):
        got = G.resolve_config_path(
            "/explicit/cfg.json",
            env={"LUHE_CONFIG": "/env/cfg.json"},
            script_dir="/skill/scripts",
        )
        self.assertEqual(got, "/explicit/cfg.json")

    def test_env_beats_default(self):
        got = G.resolve_config_path("", env={"LUHE_CONFIG": "/env/cfg.json"}, script_dir="/skill/scripts")
        self.assertEqual(got, "/env/cfg.json")

    def test_env_expands_user(self):
        got = G.resolve_config_path("", env={"LUHE_CONFIG": "~/luhe.json"}, script_dir="/skill/scripts")
        self.assertNotIn("~", got)
        self.assertTrue(got.endswith("luhe.json"))

    def test_blank_env_ignored(self):
        # blank/whitespace LUHE_CONFIG 应被忽略，回退到默认 config 定位
        # 数据目录（无 config.json）→ 回退数据目录 config.json 路径（凭证不落 skill 目录）
        tmp = tempfile.mkdtemp()
        orig = G.resolve_data_dir
        G.resolve_data_dir = lambda: tmp
        try:
            got = G.resolve_config_path("", env={"LUHE_CONFIG": "   "}, script_dir="/skill/scripts")
        finally:
            G.resolve_data_dir = orig
        self.assertEqual(os.path.basename(got), "config.json")
        self.assertEqual(got, os.path.join(tmp, "config.json"))

    def test_default_is_skill_root(self):
        # 无 cli / 无 env 时，数据目录优先；数据目录无 config 时返回数据目录路径
        # （skill 根目录 config.json 仅作已存在时的回退，不再是首选落点）
        tmp = tempfile.mkdtemp()
        orig = G.resolve_data_dir
        G.resolve_data_dir = lambda: tmp
        try:
            got = G.resolve_config_path("", env={}, script_dir=os.path.join("/skill", "scripts"))
        finally:
            G.resolve_data_dir = orig
        self.assertEqual(got, os.path.join(tmp, "config.json"))

    def test_login_shares_same_rule(self):
        a = G.resolve_config_path("", env={"LUHE_CONFIG": "/x/c.json"}, script_dir="/s/scripts")
        b = L.resolve_config_path("/x/c.json")
        self.assertEqual(a, b)

    def test_missing_file_returns_none_not_raise(self):
        self.assertIsNone(G.load_config("/definitely/not/here/config.json"))
        self.assertIsNone(G.load_config(""))


# ---------------------------------------------------------------------------
# 统一鉴权：token 只走 header（edu-big-data-server-user-skill），不带 Cookie
# ---------------------------------------------------------------------------

class TestAuthHeaders(unittest.TestCase):

    NAME = "edu-big-data-server-user-skill"  # 微信扫码登录凭证头

    def test_header_only_delivery(self):
        h = G.build_auth_headers("tok123")
        self.assertEqual(h[self.NAME], "tok123")
        self.assertNotIn("Cookie", h)

    def test_referer_origin_derived_from_base_url(self):
        h = G.build_auth_headers("tok123", "https://api.example.com/")
        self.assertEqual(h["Referer"], "https://api.example.com/")
        self.assertEqual(h["Origin"], "https://api.example.com")
        # 不传 base_url 时不附带来源头
        h2 = G.build_auth_headers("tok123")
        self.assertNotIn("Referer", h2)
        self.assertNotIn("Origin", h2)

    def test_old_permanent_header_removed(self):
        # 旧 permanent / consumer 头必须彻底移除，不得多头并存
        h = G.build_auth_headers("tok123")
        self.assertNotIn("edu-big-data-server-user-consumer", h)
        self.assertNotIn("edu-big-data-server-user-permanent", h)

    def test_empty_token_yields_empty(self):
        self.assertEqual(G.build_auth_headers(""), {})
        self.assertEqual(G.build_auth_headers(None), {})

    def test_login_module_uses_same_header(self):
        self.assertEqual(L.AUTH_HEADER_NAME, self.NAME)

    def test_preview_server_uses_same_header(self):
        import paper_preview_server as P
        self.assertEqual(P.AUTH_HEADER_NAME, self.NAME)
        self.assertNotIn("Cookie", P.build_auth_headers("tok123"))


# ---------------------------------------------------------------------------
# 一键成文请求体（字段名大小写是服务端硬契约，写错就 400）
# ---------------------------------------------------------------------------

class TestGenPayload(unittest.TestCase):

    def test_field_contract(self):
        p = G.gen_payload("论文标题", "中文", 3000)
        self.assertEqual(p["title"], "论文标题")
        self.assertEqual(p["language"], "中文")
        self.assertEqual(p["type"], "1")
        self.assertEqual(p["Wordcount"], "3000")      # 字符串 + 首字母大写 W
        self.assertEqual(p["wordCountLimit"], 3000)   # 整数 + 驼峰
        self.assertIsInstance(p["Wordcount"], str)
        self.assertIsInstance(p["wordCountLimit"], int)

    def test_thread_id_shape(self):
        tid = G.build_thread_id()
        self.assertTrue(tid.startswith("test"))
        self.assertEqual(len(tid), 24)               # "test" + 20 位
        self.assertTrue(tid[4:].isdigit())

    def test_thread_id_unique(self):
        self.assertNotEqual(G.build_thread_id(), G.build_thread_id())


# ---------------------------------------------------------------------------
# 配平括号抽取（清洗响应尾部垃圾）
# ---------------------------------------------------------------------------

class TestExtractBalanced(unittest.TestCase):

    def test_strips_trailing_garbage(self):
        s = "{'reference': '[1,2]'}[] []"
        self.assertEqual(G._extract_balanced(s, "{", "}"), "{'reference': '[1,2]'}")

    def test_bracket_inside_string_ignored(self):
        s = "['a}b', 'c']"
        self.assertEqual(G._extract_balanced(s, "[", "]"), "['a}b', 'c']")

    def test_nested(self):
        self.assertEqual(G._extract_balanced("{'a': {'b': 1}} junk", "{", "}"), "{'a': {'b': 1}}")

    def test_no_match_is_falsy(self):
        # 实现返回 None；调用方一律用 `if outer:` 判断，故只约束「假值」
        self.assertFalsy = self.assertFalse
        self.assertFalse(G._extract_balanced("no brackets", "{", "}"))


# ---------------------------------------------------------------------------
# SSE 正文解析：必须递归展平 children，否则子节正文丢失
# ---------------------------------------------------------------------------

class TestParseBodySections(unittest.TestCase):

    def test_flattens_children(self):
        answers = [
            '\n回答开始\n',
            '{"id":"1","title":"引言","content":"引言正文",'
            '"children":[{"id":"1.1","title":"研究背景","content":"背景正文"}]}',
            '{"id":"2","title":"结论","content":"结论正文"}',
        ]
        secs = G.parse_body_sections(answers)
        titles = {s["title"] for s in secs}
        self.assertEqual(titles, {"引言", "研究背景", "结论"})
        got = {s["title"]: s["content"] for s in secs}
        self.assertEqual(got["研究背景"], "背景正文")

    def test_dedup_keeps_longest_content(self):
        answers = ['{"title":"引言","content":"短"}{"title":"引言","content":"长很多的正文内容"}']
        secs = G.parse_body_sections(answers)
        self.assertEqual(len(secs), 1)
        self.assertEqual(secs[0]["content"], "长很多的正文内容")

    def test_bad_json_skipped_not_crash(self):
        secs = G.parse_body_sections(['{坏的{{', '{"title":"正常","content":"ok"}'])
        self.assertEqual([s["title"] for s in secs], ["正常"])

    def test_empty_input(self):
        self.assertEqual(G.parse_body_sections([]), [])


class TestMergeBodyIntoOutline(unittest.TestCase):

    def test_injects_and_keeps_nesting(self):
        outline = [{"title": "引言", "content": "", "children": [{"title": "背景", "content": ""}]}]
        secs = [{"title": "引言", "content": "A"}, {"title": "背景", "content": "B"}]
        merged = G.merge_body_into_outline(outline, secs)
        self.assertEqual(merged[0]["content"], "A")
        self.assertEqual(merged[0]["children"][0]["content"], "B")

    def test_does_not_mutate_input(self):
        outline = [{"title": "引言", "content": ""}]
        G.merge_body_into_outline(outline, [{"title": "引言", "content": "X"}])
        self.assertEqual(outline[0]["content"], "")

    def test_unmatched_title_left_alone(self):
        merged = G.merge_body_into_outline([{"title": "无关", "content": "原样"}],
                                           [{"title": "引言", "content": "X"}])
        self.assertEqual(merged[0]["content"], "原样")


class TestMergeTruncatedOutlineTitle(unittest.TestCase):
    """回归：平台大纲标题被截断时，整章正文曾被静默丢弃。

    实测 2026-08-10：大纲节点是 `2“数学+X`，正文章节是
    `2“数学+X”主题式课程框架的构建`，精确匹配失败 → 707 字正文丢失，
    docx 里该章只剩一个半截标题。"""

    OUTLINE = [{"title": "引言", "content": "", "children": []},
               {"title": "2“数学+X", "content": "", "children": None}]
    SECS = [{"title": "引言", "content": "前言正文"},
            {"title": "2“数学+X”主题式课程框架的构建", "content": "第二章正文" * 20}]

    def test_truncated_title_still_gets_content(self):
        merged = G.merge_body_into_outline(self.OUTLINE, self.SECS)
        self.assertTrue(merged[1]["content"].startswith("第二章正文"))

    def test_truncated_title_is_repaired(self):
        merged = G.merge_body_into_outline(self.OUTLINE, self.SECS)
        self.assertEqual(merged[1]["title"], "2“数学+X”主题式课程框架的构建")

    def test_report_counts_matches(self):
        rep = {}
        G.merge_body_into_outline(self.OUTLINE, self.SECS, rep)
        self.assertEqual(rep["matched"], 2)
        self.assertEqual(rep["appended"], [])

    def test_orphan_section_appended_never_dropped(self):
        rep = {}
        merged = G.merge_body_into_outline(
            [{"title": "引言", "content": "", "children": []}],
            [{"title": "引言", "content": "A"},
             {"title": "完全对不上的章节", "content": "不能丢的正文"}], rep)
        self.assertEqual(rep["appended"], ["完全对不上的章节"])
        self.assertTrue(any(n.get("content") == "不能丢的正文" for n in merged))

    def test_number_only_prefix_does_not_cross_match(self):
        """'1' 不得误撞 '1.1'：短标题走章节序号轮，须精确同号。"""
        rep = {}
        G.merge_body_into_outline(
            [{"title": "1 总论", "content": "", "children": []},
             {"title": "1.1 分论", "content": "", "children": []}],
            [{"title": "1 总论", "content": "A"}, {"title": "1.1 分论", "content": "B"}], rep)
        self.assertEqual(rep["matched"], 2)

    def test_empty_orphan_not_appended(self):
        rep = {}
        merged = G.merge_body_into_outline(
            [{"title": "引言", "content": "", "children": []}],
            [{"title": "空章节", "content": "   "}], rep)
        self.assertEqual(len(merged), 1)
        self.assertEqual(rep["appended"], [])


class TestVerifyOutputIntegrity(unittest.TestCase):
    """交付前完整度检查（不依赖 docx 文件，只验纯逻辑分支）。"""

    def test_flatten_tree_prefix_order(self):
        tree = [{"title": "A", "children": [{"title": "A1", "children": []}]},
                {"title": "B", "children": []}]
        self.assertEqual([n["title"] for n in E._flatten_tree_nodes(tree)],
                         ["A", "A1", "B"])

    def test_plain_strips_tags_and_space(self):
        self.assertEqual(E._plain("甲<sup>[1]</sup> 乙\n丙"), "甲[1]乙丙")

    def test_missing_docx_reports_not_ok(self):
        state = {"content": [{"title": "引言", "content": "正文", "children": []}],
                 "docx_path": None, "_references_raw": ""}
        rep = G.verify_output_integrity(state)
        self.assertFalse(rep["ok"])

    def test_as_int_tolerates_string_and_junk(self):
        self.assertEqual(G._as_int("5000"), 5000)
        self.assertEqual(G._as_int(None), 0)
        self.assertEqual(G._as_int("abc"), 0)


# ---------------------------------------------------------------------------
# 防死链校验（reference_search.validate_candidates）
# ---------------------------------------------------------------------------

class TestValidateCandidates(unittest.TestCase):

    def _c(self, index, cid, url):
        return {"index": index, "id": cid, "title": f"文献{index}", "detail_url": url}

    def test_drops_entries_without_real_id(self):
        cands = [self._c(1, "7108348057", ""), self._c(2, "", ""), self._c(3, "abc", "")]
        kept = R.validate_candidates(cands)
        self.assertEqual([c["id"] for c in kept], ["7108348057"])

    def test_drops_duplicate_ids(self):
        cands = [self._c(1, "111", ""), self._c(2, "111", "")]
        kept = R.validate_candidates(cands)
        self.assertEqual(len(kept), 1)

    def test_rebuilds_mismatched_detail_url(self):
        # detail_url 与 id 不一致（死链场景）→ 按约定格式重建
        cands = [self._c(1, "111", "https://luhe.cqvip.com/weResearch/literatureDetail/999/1"),
                 self._c(2, "222", "")]
        kept = R.validate_candidates(cands)
        self.assertEqual(kept[0]["detail_url"],
                         "https://luhe.cqvip.com/weResearch/literatureDetail/111/1")
        self.assertEqual(kept[1]["detail_url"],
                         "https://luhe.cqvip.com/weResearch/literatureDetail/222/1")

    def test_keeps_valid_matched_url(self):
        url = "https://luhe.cqvip.com/weResearch/literatureDetail/111/1"
        kept = R.validate_candidates([self._c(1, "111", url)])
        self.assertEqual(kept[0]["detail_url"], url)


# ---------------------------------------------------------------------------
# 参考文献解析与格式化
# ---------------------------------------------------------------------------

REF_RAW = (
    "{'reference': \"["
    "{'file_id': '111', 'content': {'file_name': '项目式学习研究', 'metadata': {"
    "'author_info': [{'author': '张三'}, {'author': '李四'}], "
    "'journalInfo': {'journalName': '教育研究', 'year': '2023', 'vol': '45', 'realNum': '3'}}}}, "
    "{'file_id': '222', 'content': {'file_name': '农村电商路径', 'metadata': {"
    "'organization_info': 'order:1,organ:某某大学', "
    "'journalInfo': {'journalName': '经济纵横', 'year': '2024'}}}}"
    "]\"}[] []"
)


class TestLoadRefList(unittest.TestCase):

    def test_parses_wrapped_with_garbage(self):
        refs = G._load_ref_list(REF_RAW)
        self.assertEqual(len(refs), 2)
        self.assertEqual(refs[0]["file_id"], "111")

    def test_empty(self):
        self.assertEqual(G._load_ref_list(""), [])
        self.assertEqual(G._load_ref_list(None), [])


class TestParseOrg(unittest.TestCase):

    def test_single(self):
        self.assertEqual(G._parse_org("order:1,organ:吉林师范大学"), "吉林师范大学")

    def test_multiple(self):
        self.assertEqual(G._parse_org("order:1,organ:A大学;order:2,organ:B学院"), "A大学，B学院")

    def test_empty(self):
        self.assertEqual(G._parse_org(""), "")
        self.assertEqual(G._parse_org(None), "")


class TestFormatOneRef(unittest.TestCase):

    def test_authors_joined(self):
        r = G._load_ref_list(REF_RAW)[0]
        line, _ = G._format_one_ref(r, 1)
        self.assertTrue(line.startswith("[1] 张三，李四."))
        self.assertIn("项目式学习研究", line)
        self.assertIn("教育研究", line)
        self.assertIn("2023", line)

    def test_falls_back_to_org_when_no_author(self):
        r = G._load_ref_list(REF_RAW)[1]
        line, _ = G._format_one_ref(r, 2)
        self.assertIn("某某大学", line)

    def test_garbage_returns_empty_not_raise(self):
        line, url = G._format_one_ref({"content": "###不是JSON###"}, 1)
        self.assertEqual(line, "")
        self.assertIsNone(url)

    def test_no_title_yields_no_shell_entry(self):
        """无题名不得产出「[n] 佚名...」空壳条目——防幻觉硬要求。"""
        line, _ = G._format_one_ref({"file_id": "x", "content": {"metadata": {}}}, 1)
        self.assertEqual(line, "")


class TestBuildReferencesItems(unittest.TestCase):

    def test_gbstr_preferred_over_local_format(self):
        items = G.build_references_items(REF_RAW, gbstr_map={"111": "张三.项目式学习研究[J].教育研究,2023:1-8."})
        self.assertEqual(items[0]["text"], "[1] 张三.项目式学习研究[J].教育研究,2023:1-8.")
        self.assertIn("李四", items[1]["text"] + items[0]["text"] + "李四")  # 第2条走本地格式化

    def test_detail_url_built(self):
        items = G.build_references_items(REF_RAW)
        self.assertEqual(items[0]["url"], "https://luhe.cqvip.com/weResearch/literatureDetail/111/1")

    def test_custom_detail_base(self):
        items = G.build_references_items(REF_RAW, detail_base="https://luhe.cqvip.com/weResearch/literatureDetail/")
        self.assertEqual(items[0]["url"], "https://luhe.cqvip.com/weResearch/literatureDetail/111/1")

    def test_numbering_is_continuous_from_one(self):
        items = G.build_references_items(REF_RAW)
        self.assertEqual([it["n"] for it in items], [1, 2])

    def test_broken_entry_leaves_numbering_hole(self):
        """坏条目被丢弃后编号故意留空洞（锚定原始文献序），
        使 fmap 与 items 的 n 保持同源，错位由 validate_citations 抓出。"""
        raw = ("[{'file_id': '1', 'content': {'file_name': '好文献', 'metadata': {}}}, "
               "{'file_id': '2', 'content': '坏数据'}, "
               "{'file_id': '3', 'content': {'file_name': '另一篇', 'metadata': {}}}]")
        items = G.build_references_items(raw)
        self.assertEqual([it["n"] for it in items], [1, 3])


class TestBuildReferences(unittest.TestCase):

    def test_returns_text_and_fmap(self):
        text, fmap = G.build_references(REF_RAW)
        self.assertEqual(fmap, {"111": 1, "222": 2})
        self.assertEqual(len(text.splitlines()), 2)

    def test_empty_input(self):
        self.assertEqual(G.build_references(""), ("", {}))


class TestRemapCitations(unittest.TestCase):

    def test_file_id_to_sequence(self):
        out = G.remap_citations("研究表明<sup>[111]</sup>，另有<sup>[222]</sup>。", {"111": 1, "222": 2})
        self.assertEqual(out, "研究表明<sup>[1]</sup>，另有<sup>[2]</sup>。")

    def test_unknown_id_left_intact(self):
        out = G.remap_citations("见<sup>[999]</sup>", {"111": 1})
        self.assertEqual(out, "见<sup>[999]</sup>")

    def test_noop_on_empty(self):
        self.assertEqual(G.remap_citations("正文", {}), "正文")
        self.assertEqual(G.remap_citations("", {"1": 1}), "")


# ---------------------------------------------------------------------------
# 标引一致性校验（防幻觉的最后一道闸）
# ---------------------------------------------------------------------------

class TestValidateCitations(unittest.TestCase):

    def _state(self, content):
        return {"content": content, "_references_raw": REF_RAW, "_references_gbstr": {}}

    def test_pass_when_one_to_one(self):
        ok, issues = G.validate_citations(self._state("甲<sup>[1]</sup>乙<sup>[2]</sup>"))
        self.assertTrue(ok)
        self.assertEqual(issues, [])

    def test_flags_citation_without_reference(self):
        ok, issues = G.validate_citations(self._state("甲<sup>[1]</sup>乙<sup>[9]</sup>"))
        self.assertFalse(ok)
        self.assertTrue(any("[9]" in i for i in issues))

    def test_flags_uncited_reference(self):
        ok, issues = G.validate_citations(self._state("只引了<sup>[1]</sup>"))
        self.assertFalse(ok)
        self.assertTrue(any("未被正文引用" in i for i in issues))


# ---------------------------------------------------------------------------
# 登录凭证解析（微信扫码登录返回结构可能变，兼容多种形态）
# ---------------------------------------------------------------------------

class TestExtractToken(unittest.TestCase):

    def test_plain_string(self):
        self.assertEqual(L.extract_token("abc123"), "abc123")

    def test_token_field(self):
        self.assertEqual(L.extract_token({"token": "tk"}), "tk")

    def test_alternative_fields(self):
        for key in ("accessToken", "access_token", "userToken", "permanentCode"):
            self.assertEqual(L.extract_token({key: "tk"}), "tk", key)

    def test_nested_user(self):
        self.assertEqual(L.extract_token({"user": {"token": "tk"}}), "tk")

    def test_empty_payload(self):
        self.assertEqual(L.extract_token(None), "")
        self.assertEqual(L.extract_token({}), "")
        self.assertEqual(L.extract_token({"other": 1}), "")


# ---------------------------------------------------------------------------
# 一键成文地址：base_url + 固定路径（不再支持独立地址覆盖）
# ---------------------------------------------------------------------------

class TestOneClickUrl(unittest.TestCase):

    def test_path_is_appended(self):
        self.assertEqual(
            "http://host/server-agent/writing/paper-agent/one-click-generate-skill",
            "http://host".rstrip("/") + G.ONE_CLICK_PATH,
        )

    def test_trailing_slash_trimmed(self):
        self.assertTrue(("http://host/".rstrip("/") + G.ONE_CLICK_PATH)
                        .startswith("http://host/server-agent"))

    def test_no_legacy_paths_left(self):
        # 旧路径（one-click-generate 结尾、无 -skill）不得出现在 generate.py
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "generate.py")
        with open(path, encoding="utf-8") as f:
            src = f.read()
        self.assertNotIn('"/server-agent/writing/paper-agent/one-click-generate"', src)
        self.assertNotIn("gold-coin/info", src)


# ---------------------------------------------------------------------------
# 按需登录：仅当后端返回「需要登录」错误码（如 401 免费额度用完）才扫码
# ---------------------------------------------------------------------------
try:
    from unittest import mock
except ImportError:  # pragma: no cover
    import mock

import io as _io


class _FakeResp(object):
    """模拟 urllib 响应：read(size) 第一次返回完整 body，之后返回 b''（与真实流式读取一致）。"""

    def __init__(self, body):
        self._b = body.encode("utf-8") if isinstance(body, str) else body
        self._done = False

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self, size=-1):
        if self._done:
            return b""
        self._done = True
        return self._b


class TestLazyLogin(unittest.TestCase):
    def _run_stream(self, fake):
        out = tempfile.mkdtemp()
        sf = os.path.join(out, "status.json")
        rl = os.path.join(out, "raw.log")
        if isinstance(fake, Exception):
            with mock.patch("urllib.request.urlopen", mock.Mock(side_effect=fake)):
                return G.stream_generate("http://host", "", {"title": "t"}, sf, rl, out)
        with mock.patch("urllib.request.urlopen", lambda *a, **k: fake):
            return G.stream_generate("http://host", "", {"title": "t"}, sf, rl, out)

    def test_is_login_required_variants(self):
        self.assertTrue(G.is_login_required(401, "免费体验次数已用完，请登录后继续使用"))
        self.assertTrue(G.is_login_required(403, ""))
        self.assertFalse(G.is_login_required(500, "论文标题不能为空"))
        self.assertFalse(G.is_login_required(200, "ok"))
        self.assertTrue(G.is_login_required(0, "请登录后继续使用"))

    def test_empty_stream_marks_need_login(self):
        # 后端返回空流（未启动生成）→ stream_generate 应标记 need_login
        st = self._run_stream(_FakeResp(""))
        self.assertEqual(st.get("status"), "need_login")

    def test_need_login_always_carries_reason(self):
        # 🔴 铁律：need_login 判定必须携带可读原因（need_login_reason），
        # 供 agent 先向用户解释原因再引导扫码；不允许无解释直接弹登录
        st = self._run_stream(_FakeResp(""))
        self.assertTrue(st.get("need_login_reason"))
        err = G.urllib.error.HTTPError(
            "url", 401, "unauth", {},
            _io.BytesIO('{"data":null,"message":"免费体验次数已用完，请登录后继续使用","code":401}'.encode()))
        st2 = self._run_stream(err)
        self.assertEqual(st2.get("status"), "need_login")
        self.assertIn("免费体验次数已用完", st2.get("need_login_reason", ""))
        # 401 无文案 → 原因回退为状态码解释，绝不为空
        err3 = G.urllib.error.HTTPError("url", 401, "unauth", {}, _io.BytesIO(b""))
        st3 = self._run_stream(err3)
        self.assertEqual(st3.get("status"), "need_login")
        self.assertTrue(st3.get("need_login_reason"))

    def test_http_401_marks_need_login(self):
        err = G.urllib.error.HTTPError("url", 401, "unauth", {}, _io.BytesIO(b'{}'))
        st = self._run_stream(err)
        self.assertEqual(st.get("status"), "need_login")

    def test_nonempty_error_not_need_login(self):
        # 有内容但流里没有 paper.done（如参数错误）→ 标记 failed，而非 need_login
        body = "event: error\ndata: {\"code\":500,\"message\":\"论文标题不能为空\"}\n\n"
        st = self._run_stream(_FakeResp(body))
        self.assertNotEqual(st.get("status"), "need_login")
        self.assertEqual(st.get("status"), "failed")


# ---------------------------------------------------------------------------
# 成功判定：paper.done 到达 + 正文非空（后端新版不再返回 paperId）
# ---------------------------------------------------------------------------
def _sse_done_event(body_chars=200, with_done=True):
    """构造一条含完整正文的 SSE 流；with_done=False 时省掉 paper.done。"""
    long_body = "这是一段用于测试的正文内容。" * max(1, body_chars // 13 + 1)
    outline = {"children": [
        {"title": "一、引言", "content": long_body, "children": []},
        {"title": "参考文献", "content": "", "children": []},
    ]}
    ev_name = "paper.done" if with_done else "outline.saved"
    data = {"threadId": "2097501262225526784", "outlineTree": outline,
            "contentLength": len(long_body)}
    return ("event: abstract.done\n"
            "data: {\"abstract\":\"摘要\",\"keywords\":\"关键词\"}\n\n"
            f"event: {ev_name}\n"
            f"data: {json.dumps(data, ensure_ascii=False)}\n\n")


class TestPaperDoneSuccess(unittest.TestCase):
    def _run_stream(self, body):
        out = tempfile.mkdtemp()
        sf = os.path.join(out, "status.json")
        rl = os.path.join(out, "raw.log")
        with mock.patch("urllib.request.urlopen", lambda *a, **k: _FakeResp(body)):
            return G.stream_generate("http://host", "", {"title": "t"}, sf, rl, out)

    def test_paper_done_without_paperid_is_success(self):
        """无 paperId 但收到 paper.done + 正文非空 → 通过成功判定（不再卡 paper_id）。"""
        st = self._run_stream(_sse_done_event())
        self.assertTrue(st.get("_paper_done"), "应已标记收到 paper.done")
        self.assertIsNone(st.get("paper_id"), "新版后端本就不返回 paperId")
        self.assertGreater(st.get("_body_chars", 0), 0)
        # 不能因为缺少 paper_id 而在成功判定处失败
        self.assertNotIn("未收到 paper.done", str(st.get("error") or ""))
        self.assertNotIn("paper_id", str(st.get("error") or ""))

    def test_missing_paper_done_is_failed(self):
        """流里有内容但没有 paper.done → failed。"""
        st = self._run_stream(_sse_done_event(with_done=False))
        self.assertEqual(st.get("status"), "failed")
        self.assertIn("未收到 paper.done", str(st.get("error")))

    def test_paper_done_but_empty_body_is_failed(self):
        """收到 paper.done 但正文为空 → failed（正文非空是成功判定的另一半）。"""
        st = self._run_stream(_sse_done_event(body_chars=0))
        self.assertTrue(st.get("_paper_done"))
        self.assertEqual(st.get("status"), "failed")
        self.assertIn("论文正文缺失", str(st.get("error")))


# ---------------------------------------------------------------------------
# 预览服务生命周期：空闲自毁后必须真正退出并释放端口
# （回归防护：旧实现看门狗只 server.shutdown() 不置 _stop_event，
#   结果地址失效了但进程不退、端口不释放，反复「重开预览」堆僵尸进程）
# ---------------------------------------------------------------------------

class TestPreviewServerLifecycle(unittest.TestCase):

    @staticmethod
    def _probe(url, timeout=5):
        """回环直连探测。显式禁用代理：宿主机若设了 http_proxy，
        走 urlopen 会被代理接管，端口关闭时代理回 502 而非连接被拒，
        测试结论就不可信了。"""
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        return opener.open(url, timeout=timeout)

    def _spawn(self, idle_timeout=0.6, html_name="论文_预览.html"):
        """后台起一个预览服务，返回 (线程, 就绪地址, 结果字典, 临时目录)。"""
        import paper_preview_server as P
        tmp = tempfile.mkdtemp(prefix="preview_")
        html = os.path.join(tmp, html_name)
        with open(html, "w", encoding="utf-8") as f:
            f.write("<!doctype html><html><body>ok</body></html>")
        payload = os.path.join(tmp, "preview_payload.json")
        with open(payload, "w", encoding="utf-8") as f:
            json.dump({"type": "1", "title": "T", "contentJson": []}, f)
        url_file = os.path.join(tmp, "preview_url.txt")
        got = {}

        def _run():
            got["port"] = P.serve(html, payload, "", "", port=0, url_file=url_file,
                                  idle_timeout=idle_timeout, watchdog_interval=0.05)

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        url = ""
        for _ in range(120):
            time.sleep(0.05)
            try:
                with open(url_file, encoding="utf-8") as f:
                    url = f.read().strip()
            except OSError:
                url = ""
            if url:
                break
        return t, url, got, tmp

    def test_idle_timeout_exits_and_releases_port(self):
        """空闲超时后：serve() 必须返回、_stop_event 已置位、端口不再可达。"""
        t, url, got, _ = self._spawn(idle_timeout=0.6)
        self.assertTrue(url, "预览服务未在预期时间内就绪（url 文件未写出）")
        with self._probe(url) as r:
            self.assertEqual(r.status, 200)
        t.join(timeout=20)
        self.assertFalse(
            t.is_alive(),
            "空闲超时后 serve() 仍未退出：进程会残留、监听端口不会释放",
        )
        import paper_preview_server as P
        self.assertTrue(P._stop_event.is_set(), "看门狗到点必须置 _stop_event 唤醒主循环")
        self.assertEqual(got.get("port"), int(url.rsplit(":", 1)[1].rstrip("/")))
        # 监听套接字已关闭 → 端口不再接受连接（裸 socket 连接被拒，不经代理）
        import socket
        s = socket.socket()
        try:
            s.settimeout(5)
            with self.assertRaises(ConnectionRefusedError, msg="端口仍在监听，未释放"):
                s.connect(("127.0.0.1", got["port"]))
        finally:
            s.close()

    def test_startup_failure_returns_none_and_writes_no_url(self):
        """启动自探测失败（HTML 不存在）也必须关掉监听套接字并返回 None。"""
        got = {}
        import paper_preview_server as P
        tmp = tempfile.mkdtemp(prefix="preview_bad_")
        payload = os.path.join(tmp, "preview_payload.json")
        with open(payload, "w", encoding="utf-8") as f:
            json.dump({"type": "1", "contentJson": []}, f)
        url_file = os.path.join(tmp, "preview_url.txt")

        def _run():
            got["port"] = P.serve(os.path.join(tmp, "缺失.html"), payload, "", "",
                                  port=0, url_file=url_file, idle_timeout=1.0,
                                  watchdog_interval=0.05)

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        t.join(timeout=40)
        self.assertFalse(t.is_alive(), "自探测失败后 serve() 未返回")
        self.assertIsNone(got.get("port"), "自探测失败应返回 None")
        self.assertFalse(os.path.exists(url_file), "服务未就绪不得写出 url 文件")


# ---------------------------------------------------------------------------
# 平台地址安全：只允许第一方 HTTPS（防止内网穿透地址再次进分包）
# ---------------------------------------------------------------------------

# 内网穿透 / 临时隧道域名模式。注意：文档里可以出现「natapp」这类**词**（话术黑名单需要），
# 但绝不允许出现具体**隧道主机名**，故此处只匹配「子域+.隧道域」形状。
TUNNEL_HOST_RE = re.compile(
    r"[A-Za-z0-9\-]+\.(?:natappfree\.cc|natapp\.cc|ngrok\.io|ngrok-free\.app|ngrok-free\.dev"
    r"|localtunnel\.me|serveo\.net|tunnelmole\.net)",
    re.I,
)

# 隧道地址样例：本文件自身也会被 test_no_tunnel_hostname_anywhere_in_skill 扫描，
# 故用拼装方式构造，避免扫描器把自己的测试样例判成残留（false positive）。
TUNNEL_SAMPLE_URL = "http://" + "wc578a39" + "." + "natappfree" + ".cc"


class TestPlatformUrlAudit(unittest.TestCase):
    """地址硬门槛：出厂模板与在用配置都不得指向第三方明文地址。

    回归背景：config.example.json 的 base_url/lit_host 曾被设为第三方免费内网穿透域名
    （明文 HTTP）。模板是用户直接复制使用的，等于把微信登录凭证与论文正文发往不受信主机。
    """

    @classmethod
    def setUpClass(cls):
        import selfcheck as S
        cls.S = S

    def test_first_party_https_ok(self):
        self.assertEqual([], self.S.audit_platform_url("https://luhe.cqvip.com", "base_url"))

    def test_test_env_same_family_ok(self):
        # 同域测试环境仍属第一方，允许
        self.assertEqual([], self.S.audit_platform_url("https://test-luhe.cqvip.com"))

    def test_bare_apex_domain_ok(self):
        self.assertEqual([], self.S.audit_platform_url("https://cqvip.com"))

    def test_trailing_slash_and_port_ok(self):
        self.assertEqual([], self.S.audit_platform_url("https://luhe.cqvip.com:443/"))

    def test_tunnel_host_rejected(self):
        probs = self.S.audit_platform_url(TUNNEL_SAMPLE_URL, "base_url")
        self.assertTrue(any("非第一方域名" in p for p in probs), probs)
        self.assertTrue(any("明文 HTTP" in p for p in probs), probs)

    def test_plaintext_http_on_first_party_rejected(self):
        probs = self.S.audit_platform_url("http://luhe.cqvip.com", "lit_host")
        self.assertEqual(1, len(probs), probs)
        self.assertIn("明文 HTTP", probs[0])

    def test_third_party_https_rejected(self):
        probs = self.S.audit_platform_url("https://evil.example.com", "base_url")
        self.assertEqual(1, len(probs), probs)
        self.assertIn("非第一方域名", probs[0])

    def test_suffix_confusion_rejected(self):
        # 形如 luhe.cqvip.com.evil.com 的伪装域不得通过
        self.assertTrue(self.S.audit_platform_url("https://luhe.cqvip.com.evil.com"))

    def test_userinfo_does_not_fake_host(self):
        # 混淆写法 https://luhe.cqvip.com@evil.com 的真实主机是 evil.com
        self.assertTrue(self.S.audit_platform_url("https://luhe.cqvip.com@evil.com"))

    def test_empty_and_schemeless_rejected(self):
        self.assertEqual(1, len(self.S.audit_platform_url("", "base_url")))
        self.assertEqual(1, len(self.S.audit_platform_url("luhe.cqvip.com", "base_url")))

    # ---- 包内实物回归：模板 / 出厂配置 / 全包扫描 ----

    @staticmethod
    def _skill_root():
        return os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir))

    def test_shipped_template_is_compliant(self):
        """config.example.json 会被直接复制为 config.json，必须合规。"""
        path = os.path.join(self._skill_root(), "config.example.json")
        with open(path, encoding="utf-8") as f:
            tpl = json.load(f)
        for field in ("base_url", "lit_host"):
            self.assertEqual([], self.S.audit_platform_url(tpl.get(field), field),
                             f"{field} 不合规：{tpl.get(field)}")

    def test_template_matches_first_party_host(self):
        path = os.path.join(self._skill_root(), "config.example.json")
        with open(path, encoding="utf-8") as f:
            tpl = json.load(f)
        # 模板地址应与同文件的 platform_url（第一方主站）一致，避免再次分叉
        self.assertEqual(tpl.get("platform_url", "").rstrip("/"),
                         tpl.get("base_url", "").rstrip("/"))

    def test_skill_config_is_compliant(self):
        path = os.path.join(self._skill_root(), "config.json")
        if not os.path.isfile(path):
            self.skipTest("skill 根目录无 config.json")
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
        for field in ("base_url", "lit_host"):
            if cfg.get(field):
                self.assertEqual([], self.S.audit_platform_url(cfg[field], field),
                                 f"{field} 不合规：{cfg[field]}")

    def test_no_tunnel_hostname_anywhere_in_skill(self):
        """全包扫描：任何文本文件都不得残留具体隧道主机名。"""
        root = self._skill_root()
        hits = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames
                           if d not in ("__pycache__", "outputs", "paper-writer-data", ".git")]
            for fn in filenames:
                if not fn.endswith((".py", ".md", ".json", ".txt")):
                    continue
                p = os.path.join(dirpath, fn)
                with open(p, encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f, 1):
                        if TUNNEL_HOST_RE.search(line):
                            hits.append(f"{os.path.relpath(p, root)}:{i}")
        self.assertEqual([], hits, f"skill 包内不得残留隧道主机名：{hits}")


if __name__ == "__main__":
    unittest.main(verbosity=2 if "-v" in sys.argv else 1)
