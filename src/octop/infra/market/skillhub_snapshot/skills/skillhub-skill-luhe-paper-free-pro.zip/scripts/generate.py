#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
论文一键成文 SSE 客户端
--------------------------------------------------
负责：① 打开 one-click-generate 的 SSE 流 ② 解析事件、实时写进度
      ③ 捕获「生成正文」正文流 + 「合并参考文献id」参考文献列表
      ④ 流结束后把正文/参考文献按标题注入 outline 各节点
      ⑤ 流结束后调用 export.py 完成 docx 导出。

数据要点：
- 大纲骨架取 paper.done 的 outlineTree.children；该节点的 content 为空，正文另有来源。
- 正文在 paper.chunk(name=生成正文) 的 answer 流里，是一串 {title,content} JSON 对象。
- 参考文献在 paper.chunk(name=合并参考文献id) 的响应里。
- 捕获不到正文时明确失败，不产出只有标题的空稿。
- 成功判定 = 收到 eventName=paper.done + 正文非空（不依赖 paperId 字段）。

用法:
  # 便捷模式（推荐）：从 config.json 读取 base_url/token/lit_host
  python generate.py \
    --config ../config.json \
    --title "语文项目式教学研究" \
    --language 中文 --word-count 5000 \
    --output-dir ../outputs --status-file ../status.json

  # 显式参数模式（向后兼容）
  python generate.py \
    --base-url <平台地址，见 config.json> \
    --token <登录token> \
    --title "语文项目式教学研究" \
    --language 中文 --word-count 3000 \
    --output-dir ./outputs --status-file ./status.json

  # 仅检查登录态
  python generate.py --config ../config.json --check-login

导出 Word 已独立到同级 export.py，本文件只在 stream_generate 末尾调用 export_and_download。
"""

import argparse
import base64
import copy
import json
import os
import shutil
import sys
import time
import ast
import re
import zipfile
from datetime import datetime

try:
    import urllib.request
    import urllib.error
    import urllib.parse
except ImportError:
    pass


# ---------------------------------------------------------------------------
# 与 export.py 的边界
#
# 设计：导出（HTTP 调 /export/direct + 注入 + 完整度校验）已解耦到 export.py，
# 本文件只做 SSE 流式生成。stream_generate 末尾调用 export_and_download。
# ---------------------------------------------------------------------------
_here = os.path.dirname(os.path.abspath(__file__))
if _here not in sys.path:
    sys.path.insert(0, _here)

# 让 export.py 中的 _gen() 找到本模块（同时也支持 export.py 直接作为 __main__ 跑）
sys.modules.setdefault("generate", sys.modules.get("__main__"))

from export import (  # noqa: E402  必须在 sys.path / sys.modules 设置之后
    EXPORT_PATH,
    export_and_download,
    verify_output_integrity,
    validate_citations,
    repair_docx_missing_sections,
)
#: 引用 export 的解析模块（引用 / 大纲正文合并等仍在本文件，因与生成流强耦合）


#: 站点识别登录态的请求头名称（常量，站点唯一）
#: 登录方式：微信扫码登录，token 由 scripts/login.py 走
#: GET /server-user/wechat/mp/mp-qrcode + POST /server-user/skill/user/login 获取，
#: 凭证走 edu-big-data-server-user-skill 头（旧 permanent 头已弃用）。
AUTH_HEADER_NAME = "edu-big-data-server-user-skill"

#: 统一 User-Agent（不带会被 WAF 拦截 403）
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
)

#: 一键成文接口路径：one-click-generate-skill。
ONE_CLICK_PATH = "/server-agent/writing/paper-agent/one-click-generate-skill"

#: 触发「需要登录」的后端错误码与文案（仅当后端返回该错误码才要求微信扫码登录，
#: 免费体验额度内可直接成文，无需登录）。
#: 已与后端确认：未登录或免费体验次数耗尽时，一键成文接口（JSON 形态）同步返回
#:     {"data":null,"message":"免费体验次数已用完，请登录后继续使用","code":401}
#: 若后端调整错误码/文案，请同步修改下方两处常量。
LOGIN_REQUIRED_CODES = (401, 403)
LOGIN_REQUIRED_HINTS = (
    "请登录", "登录", "免费体验", "unauthorized", "not authorized",
    "token", "未登录", "失效", "过期", "expire", "请先登录", "需要登录",
)


def is_login_required(code, message=""):
    """判定后端响应是否表示「需要登录 / 免费额度已用完」。

    依据：未登录或免费体验次数耗尽时，一键成文接口（JSON 形态）返回 code=401 及提示文案。
    该错误码为「按需登录」的唯一触发条件——免费额度内后端不会返回它，可直接成文。
    """
    if code in LOGIN_REQUIRED_CODES:
        return True
    msg = (message or "").lower()
    return any(h.lower() in msg for h in LOGIN_REQUIRED_HINTS)


def _extract_backend_message(raw):
    """从后端返回体中提取 message 字段（尽力而为，提取不到返回空串）。

    后端错误体通常为 {"data":null,"message":"...","code":401} 形态；
    用于 need_login 判定时把后端原始提示透传给上层展示给用户。
    """
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return str(obj.get("message") or obj.get("msg") or "").strip()
    except Exception:
        pass
    # 非 JSON 体：去掉 HTML 标签后截取纯文本（网关错误页兜底）
    text = re.sub(r"<[^>]+>", " ", raw or "").strip()
    return text[:120]


def trigger_login(base_url, cfg_path, status_file, qr_image, timeout=300):
    """触发微信扫码登录（复用 login.py）。成功返回 token 字符串，失败返回 None。

    二维码图片写入 qr_image，登录状态写入 status_file（含 qr_image 路径），供 agent/用户扫码。
    """
    try:
        import login as _login
    except Exception as e:
        log(f"[WARN] 无法加载 login 模块: {e}")
        return None
    try:
        tok = _login.ensure_logged_in(base_url, cfg_path, qr_image, status_file, timeout=timeout)
    except Exception as e:
        log(f"[错误] 登录流程异常: {e}")
        return None
    return tok or None


def build_auth_headers(token, base_url=""):
    """统一鉴权头：token 走 header（edu-big-data-server-user-skill），不再带 Cookie。

    头名为 edu-big-data-server-user-skill（由 login.py 走微信扫码登录，
    GET /server-user/wechat/mp/mp-qrcode + POST /server-user/skill/user/login 获取。

    base_url 来自 config.json；提供时附带同源 Referer/Origin，
    避免生产 WAF 把缺少来源头的请求判为 403。

    若 token 为空返回空 dict（调用方需自行处理）。"""
    if not token:
        return {}
    headers = {
        AUTH_HEADER_NAME: token,
        "User-Agent": USER_AGENT,
    }
    if base_url:
        headers["Referer"] = base_url.rstrip("/") + "/"
        headers["Origin"] = base_url.rstrip("/")
    return headers


def now_ts():
    return datetime.now().strftime("%H:%M:%S")


def log(msg, raw_log):
    line = f"[{now_ts()}] {msg}"
    print(line, flush=True)
    if raw_log:
        try:
            with open(raw_log, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass


def save_status(state, status_file):
    state["updated_at"] = datetime.now().isoformat()
    try:
        with open(status_file, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"[WARN] 写状态文件失败: {e}", None)


def build_thread_id():
    import random
    return "test" + "".join(str(random.randint(0, 9)) for _ in range(20))


def gen_payload(title, language, word_count, reference_vip=None):
    wc = str(word_count)
    payload = {
        "title": title,
        "language": language,            # 中文 / 英文
        "threadId": build_thread_id(),  # "test" + 20位数字
        "type": "1",                      # 固定期刊成文
        "Wordcount": wc,                 # 字符串，首字母大写
        "wordCountLimit": int(word_count),  # 整数，驼峰
    }
    # 自定义参考文献：用户挑选的文献「对象数组」。双键同发（referenceVip 为真实契约键）。
    # 值是文献对象数组序列化后的 JSON 字符串，每个对象须带全量字段：
    # file_id/abstr/authorInfo/journalInfo/beginPage/endPage/doi/vol/num 等
    # （reference_search.py --select 输出的即完整对象）。
    # 入参 reference_vip 为 list[dict] 时自动序列化；传字符串则视为已序列化，原样透传。
    if reference_vip:
        ref_str = reference_vip if isinstance(reference_vip, str) \
            else json.dumps(list(reference_vip), ensure_ascii=False)
        payload["referenceVip"] = ref_str    # 前端真实契约键（驼峰）
        payload["reference-vip"] = ref_str   # 旧网关兼容键（连字符，双发兜底）
    return payload


# ---------------------------------------------------------------------------
# 正文 / 参考文献 解析
# ---------------------------------------------------------------------------

def parse_body_sections(answers):
    """把「生成正文」节点的 answer 片段流解析为 [{title, content}, ...]。

    answer 流形如：
        \\n回答开始\\n{"id":"..","title":"引言","content":"...","children":[...]}{...}...
    即一串独立的 JSON 对象，用 raw_decode 顺序解析。

    ⚠️ 关键：每个章节对象可能带 ``children`` 数组，里面是子节（1.1 / 1.2 …）
    且子节带有各自的正文 content。必须递归展平到所有层级，否则子节正文会丢失。"""
    raw = "".join(answers)
    dec = json.JSONDecoder()
    top = []
    i, n = 0, len(raw)
    while i < n:
        lb = raw.find("{", i)
        if lb < 0:
            break
        try:
            obj, end = dec.raw_decode(raw, lb)
        except Exception:
            i = lb + 1
            continue
        if isinstance(obj, dict):
            top.append(obj)
        i = end

    flat = []

    def _flatten(objs):
        for o in objs:
            if not isinstance(o, dict):
                continue
            if "title" in o:
                flat.append(o)
            children = o.get("children")
            if isinstance(children, list) and children:
                _flatten(children)

    _flatten(top)
    # 去重：同 title 保留 content 最长者（章节与其子节 title 不同，不会冲突）
    best = {}
    for sec in flat:
        t = sec.get("title", "")
        c = sec.get("content", "") or ""
        if t not in best or len(c) > len(best[t].get("content", "") or ""):
            best[t] = sec
    return list(best.values())


def _as_int(v, default=0):
    """宽松转整数（payload 里字数可能是字符串）。"""
    try:
        return int(str(v).strip())
    except Exception:
        return default


def _norm_title(t):
    """标题归一化：去空白与中英文标点，用于容错匹配。"""
    t = str(t or "")
    t = re.sub(r"[\s\u3000]+", "", t)
    t = re.sub(r"[“”\"'‘’「」『』（）()\[\]【】，,。.：:；;、!！?？+\-—_/\\|]", "", t)
    return t.lower()


def _section_no(t):
    """抽取章节序号前缀，如 '1.1 xxx' -> '1.1'；无序号返回 ''。"""
    m = re.match(r"\s*(\d+(?:\.\d+)*)", str(t or ""))
    return m.group(1) if m else ""


def merge_body_into_outline(outline_children, sections, report=None):
    """把正文流的 {title, content} 按标题注入 outline 各节点（保留嵌套结构）。

    ⚠️ 关键修复（v0.5.9）：平台大纲节点的 title 可能被截断
    （实测 `2“数学+X”主题式课程框架的构建` 在大纲里只剩 `2“数学+X`），
    旧实现用**精确字典匹配**，一旦标题对不上就静默丢掉整章正文 —— 该章在
    docx/HTML 里只剩一个标题。

    现改为四轮匹配（精确 → 归一化 → 前缀 → 章节序号），并且：
    - 命中后若正文标题更完整，用它**回填修复**被截断的大纲标题；
    - 所有仍未匹配上的正文章节**追加到树末尾**，确保正文永不丢失。

    report: 可选 dict，回填 matched / appended / unmatched_titles 供完整度检查使用。
    """
    if not isinstance(outline_children, list):
        return outline_children

    tree = copy.deepcopy(outline_children)
    nodes = []

    def collect(ns):
        for nd in ns:
            if isinstance(nd, dict):
                nodes.append(nd)
                ch = nd.get("children")
                if isinstance(ch, list):
                    collect(ch)

    collect(tree)

    secs = [s for s in sections if isinstance(s, dict) and s.get("title")]
    used = [False] * len(secs)
    taken = set()

    def assign(node, sec):
        content = sec.get("content") or ""
        if content:
            node["content"] = content
        st = str(sec.get("title") or "").strip()
        nt = str(node.get("title") or "").strip()
        # 平台大纲标题被截断时，正文标题更完整 → 回填修复
        if st and len(st) > len(nt) and _norm_title(st).startswith(_norm_title(nt)):
            node["title"] = st

    def run_pass(predicate):
        for si, sec in enumerate(secs):
            if used[si]:
                continue
            for ni, node in enumerate(nodes):
                if ni in taken:
                    continue
                if predicate(node, sec):
                    assign(node, sec)
                    used[si] = True
                    taken.add(ni)
                    break

    # 1) 精确标题
    run_pass(lambda nd, s: str(nd.get("title") or "").strip() == str(s.get("title") or "").strip())
    # 2) 归一化后相等
    run_pass(lambda nd, s: _norm_title(nd.get("title")) == _norm_title(s.get("title"))
             and _norm_title(s.get("title")) != "")

    # 3) 前缀包含（一方是另一方的前缀，且短者足够长，避免 '1' 误撞 '1.1'）
    def _prefix_match(nd, s):
        a, b = _norm_title(nd.get("title")), _norm_title(s.get("title"))
        if not a or not b:
            return False
        short, long_ = (a, b) if len(a) <= len(b) else (b, a)
        return len(short) >= 4 and long_.startswith(short)

    run_pass(_prefix_match)

    # 4) 章节序号相同（如大纲 '2' 与正文 '2 xxx'）
    def _no_match(nd, s):
        na, nb = _section_no(nd.get("title")), _section_no(s.get("title"))
        return bool(na) and na == nb

    run_pass(_no_match)

    # 5) 兜底：仍未匹配的正文章节追加到树末尾，绝不丢正文
    appended = []
    for si, sec in enumerate(secs):
        if used[si] or not (sec.get("content") or "").strip():
            continue
        tree.append({
            "title": str(sec.get("title") or "").strip(),
            "content": sec.get("content") or "",
            "children": [],
        })
        appended.append(str(sec.get("title") or "").strip())

    if isinstance(report, dict):
        report["matched"] = sum(1 for u in used if u)
        report["sections_total"] = len(secs)
        report["appended"] = appended
        report["unmatched_titles"] = [
            str(secs[i].get("title") or "") for i, u in enumerate(used) if not u
        ]

    return tree


def _extract_balanced(s, open_ch, close_ch):
    """从字符串中抽取第一个配平的括号子串（支持引号内的括号，跳过转义）。

    用于清洗「合并参考文献id」响应里常见的尾部垃圾，例如：
        {'reference': '[...list...]'}[] []
    直接 ast.literal_eval 会失败，这里只取第一个完整的结构体。"""
    n = len(s)
    i = 0
    start = -1
    depth = 0
    in_str = False
    qc = None
    while i < n:
        c = s[i]
        if in_str:
            if c == "\\":
                i += 2
                continue
            if c == qc:
                in_str = False
            i += 1
            continue
        if c in ('"', "'"):
            in_str = True
            qc = c
            i += 1
            continue
        if c == open_ch:
            if start < 0:
                start = i
                depth = 1
            else:
                depth += 1
        elif c == close_ch:
            depth -= 1
            if start >= 0 and depth == 0:
                return s[start:i + 1]
        i += 1
    return None


def _extract_all_balanced_lists(s):
    """抽取字符串中所有「顶层配平」的 [...] 段并返回（用于平台把「系统检索[]」+「用户所选[{...}]」\n    拼接为 [][{...}] 的情形——必须合并所有非空列表段，不能只取第一个空列表）。"""
    res = []
    n = len(s)
    i = 0
    while i < n:
        if s[i] == "[":
            seg = _extract_balanced(s[i:], "[", "]")
            if seg:
                res.append(seg)
                i += len(seg)
                continue
        i += 1
    return res


def _load_ref_list(raw_ref):
    """把「合并参考文献id」响应解析为参考文献 dict 列表。兼容 JSON / Python repr / 尾部垃圾。"""
    if not raw_ref:
        return []
    txt = raw_ref.strip()
    # 1) 先取外层包裹 {...}（可能是 {'reference': "..."} 或 {...}）
    outer = _extract_balanced(txt, "{", "}")
    obj = None
    if outer:
        try:
            obj = ast.literal_eval(outer)
        except Exception:
            obj = None
    ref = None
    if isinstance(obj, dict):
        ref = obj.get("reference")
    if not isinstance(ref, str):
        ref = txt  # 没有外层包裹，整段就是列表
    # 2) 取内层列表 [...]；平台常把「系统检索[]」+「用户所选[{...}]」拼接为 [][{...}]，
    #    需抽取所有顶层列表段、合并其中非空项（只取第一个会拿到空列表丢光文献）。
    if isinstance(ref, str):
        items = []
        for seg in _extract_all_balanced_lists(ref):
            try:
                parsed = ast.literal_eval(seg)
            except Exception:
                continue
            if isinstance(parsed, list):
                items.extend(parsed)
        if items:
            return items
    if isinstance(ref, list):
        return ref
    return []


def _parse_org(organization_info):
    """从 'order:1,organ:吉林师范大学;order:2,organ:...' 提取机构名。"""
    if not organization_info:
        return ""
    import re as _re
    orgs = _re.findall(r"organ:([^;]+)", organization_info)
    return "，".join(o.strip() for o in orgs if o.strip())


def _extract_ref_url(item):
    """尽力从参考文献条目中找外部链接（当前平台数据普遍不含，返回 None）。"""
    if not isinstance(item, dict):
        return None
    cand = []
    for k, v in item.items():
        if isinstance(v, str) and re.search(r"url|link|src|href|article|doc", k, re.I) and v.strip().startswith("http"):
            cand.append(v.strip())
    for sub in (item.get("content"), item.get("metadata")):
        if isinstance(sub, dict):
            for k, v in sub.items():
                if isinstance(v, str) and re.search(r"url|link|src|href|article|doc", k, re.I) and v.strip().startswith("http"):
                    cand.append(v.strip())
    return cand[0] if cand else None


def _format_one_ref(r, i):
    """把单条参考文献格式化为 GB/T 7714 文本，返回 (line, url)。"""
    try:
        item = r.get("content", r) if isinstance(r, dict) else r
        if isinstance(item, str):
            try:
                item = json.loads(item)
            except Exception:
                try:
                    item = ast.literal_eval(item)
                except Exception:
                    item = {}
        if not isinstance(item, dict):
            return "", None
        fid = str(r.get("file_id") or item.get("file_id") or "")
        title = (item.get("file_name") or (item.get("metadata") or {}).get("title") or "").strip()
        # 无题名 = 该条目没解析出有效内容，宁可丢弃也不能产出「[n] 佚名...」空壳条目
        # （空壳会混进参考文献列表，正是防幻觉要杜绝的）
        if not title:
            return "", None
        meta = item.get("metadata", {}) or {}
        authors = meta.get("author_info") or []
        author_names = [a.get("author") for a in authors if isinstance(a, dict) and a.get("author")]
        if author_names:
            author_str = "，".join(author_names)
        else:
            org = _parse_org(meta.get("organization_info"))
            author_str = org or "佚名"
        ji = meta.get("journalInfo", {}) or {}
        journal = ji.get("journalName") or ji.get("journalNameAlt") or ""
        year = ji.get("year") or ""
        vol = ji.get("vol") or ""
        num = ji.get("realNum") or ji.get("num") or ""
        parts = [f"[{i}] {author_str}. {title}."]
        if journal:
            parts.append(f" {journal}")
        if year:
            parts.append(f", {year}")
        if vol:
            parts.append(f", {vol}")
        if num:
            parts.append(f"({num})")
        parts.append(".")
        line = "".join(parts).replace(" .", ".").strip()
        url = _extract_ref_url(item)
        return line, url
    except Exception:
        return "", None


def build_references_items(raw_ref, gbstr_map=None, detail_base=None):
    """返回 [{n, text, file_id, url}, ...]。

    text 优先用 literaturereference 接口返回的 gbstr（平台封装好的 GB/T 7714 引文串），
    接口不可用时降级用 _format_one_ref 本地格式化。url 为露禾文献详情页
    （{detail_base}/<file_id>/1，点击引用上标/文献条目即跳转）。"""
    detail_base = (detail_base or "https://luhe.cqvip.com/weResearch/literatureDetail").rstrip("/")
    refs = _load_ref_list(raw_ref)
    out = []
    for i, r in enumerate(refs, 1):
        fid = str(r.get("file_id") or "") if isinstance(r, dict) else ""
        text = ""
        # 优先用接口 gbstr（已含作者.题名[J].出处,年:页码. 完整格式）
        if gbstr_map and fid and fid in gbstr_map:
            text = f"[{i}] {gbstr_map[fid]}"
        if not text:
            line, _ = _format_one_ref(r, i)
            text = line
        if not text:
            continue
        url = (detail_base + "/" + fid + "/1") if fid else ""
        out.append({"n": i, "text": text, "file_id": fid, "url": url})
    return out


def fetch_references_batch(lit_host, token, file_ids):
    """POST /server-agent/writing/paper/literaturereference 批量拉取参考文献引文(gbstr)。

    正确调用方式（参考 luhe-paper/paper_render.py，实测通过）：
    - body = 文献 ID 字符串数组（**非** {"fileId":...}，旧写法会返回「未知错误」）
    - 主机走 config.json 的 lit_host / base_url
    - **必须带 User-Agent 头**，否则 WAF 直接返回 403
    - 鉴权用统一模型（build_auth_headers），token 走 header
    - 返回 data = [{id, gbstr}]，gbstr 为平台封装好的 GB/T 7714 引文串

    best-effort：失败返回 {}。返回 {file_id: gbstr}。"""
    if not file_ids:
        return {}
    url = lit_host.rstrip("/") + "/server-agent/writing/paper/literaturereference"
    headers = {
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT,
    }
    headers.update(build_auth_headers(token, lit_host))
    body = json.dumps([str(fid) for fid in file_ids]).encode()
    try:
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=25) as resp:
            rj = json.loads(resp.read().decode("utf-8"))
        if rj.get("code") not in (200, 0) or not rj.get("data"):
            return {}
        data = rj["data"]
        if not isinstance(data, list):
            return {}
        m = {}
        for item in data:
            if isinstance(item, dict):
                rid = str(item.get("id") or "")
                gb = item.get("gbstr") or ""
                if rid and gb:
                    m[rid] = gb
        return m
    except Exception:
        return {}


def build_references(raw_ref, gbstr_map=None):
    """把参考文献列表格式化为 GB/T 7714 条目，并返回 (text, fileid->[n] 映射)。

    text 优先用接口 gbstr（形如 '[1] 曹璐.项目式教学...[J].文教资料,2022:110-113.'），
    接口不可用时降级本地格式化。映射用于把正文中的 <sup>[file_id]</sup> 重编号为 [1] [2] ...。"""
    refs = _load_ref_list(raw_ref)
    if not refs:
        return "", {}
    items = build_references_items(raw_ref, gbstr_map)
    lines = [it["text"] for it in items]
    fmap = {}
    for i, r in enumerate(refs, 1):
        fid = str(r.get("file_id") or "") if isinstance(r, dict) else ""
        if fid:
            fmap[fid] = i
    return "\n".join(lines), fmap


def remap_citations(content, fmap):
    """把正文里的 <sup>[file_id]</sup> 重编号为 <sup>[n]</sup>，与参考文献列表对齐。"""
    if not fmap or not content:
        return content
    import re as _re

    def repl(m):
        fid = m.group(1)
        return f"<sup>[{fmap[fid]}]</sup>" if fid in fmap else m.group(0)

    return re.sub(r"<sup>\[([^\]]+)\]</sup>", repl, content)


def _parse_ref_vip_objs(payload):
    """从 payload 的 referenceVip / reference-vip 字段解析出用户传入的文献对象数组，
    作为参考文献的兜底数据源（平台「合并参考文献id」事件未返回文献列表时使用）。"""
    if not isinstance(payload, dict):
        return []
    raw = payload.get("referenceVip") or payload.get("reference-vip") or ""
    if isinstance(raw, list):
        return raw
    if isinstance(raw, str):
        try:
            objs = json.loads(raw)
            return objs if isinstance(objs, list) else []
        except Exception:
            return []
    return []


def _extract_cited_file_ids(content):
    """从正文 content 树里提取所有被标引的文献编号（形如 [7201014120]，8 位以上数字）。

    用于平台「合并参考文献id」事件未返回文献列表（_references_raw 为空）时，
    自动从正文实际标引的文献 file_id 重建参考文献，确保文末不丢失。"""
    ids = []
    if not isinstance(content, list):
        return ids

    def walk(nodes):
        for nd in nodes:
            if isinstance(nd, dict):
                c = nd.get("content") or ""
                if isinstance(c, str):
                    for m in re.finditer(r"\[(\d{8,})\]", c):
                        ids.append(m.group(1))
                if isinstance(nd.get("children"), list):
                    walk(nd["children"])

    walk(content)
    seen, out = set(), []
    for i in ids:
        if i not in seen:
            seen.add(i)
            out.append(i)
    return out


# ---------------------------------------------------------------------------
# SSE 事件处理
# ---------------------------------------------------------------------------

def dispatch_event(event_name, data_str, state, raw_log):
    """处理单个 SSE 事件，提取正文 / 参考文献 / 错误。

    成功判定的唯一信号是 paper.done 事件。
    """
    log(f"event: {event_name}", raw_log)
    parsed = None
    if data_str:
        try:
            parsed = json.loads(data_str)
        except Exception:
            parsed = data_str
    state["events"].append({"event": event_name, "data": parsed})

    if isinstance(parsed, dict):
        # ---- 捕获「生成正文」正文流 ----
        if event_name == "paper.chunk" and parsed.get("name") == "生成正文":
            resp = parsed.get("response")
            if isinstance(resp, list):
                for el in resp:
                    if isinstance(el, dict) and isinstance(el.get("answer"), str):
                        state.setdefault("_body_answers", []).append(el["answer"])
            elif isinstance(resp, str):
                state.setdefault("_body_answers", []).append(resp)

        # ---- 捕获「合并参考文献id」参考文献列表 ----
        if event_name == "paper.chunk" and parsed.get("name") == "合并参考文献id":
            resp = parsed.get("response")
            if isinstance(resp, str) and resp.strip():
                state["_references_raw"] = resp  # 取最后一次（最完整）

        # ---- 捕获「摘要/关键词」（abstract.done）----
        if event_name == "abstract.done":
            if parsed.get("abstract"):
                state["_abstract"] = parsed["abstract"]
            if parsed.get("keywords"):
                state["_keywords"] = parsed["keywords"]

        # ---- 捕获大纲结构（作为骨架；content 稍后由正文流注入）----
        if "outlineTree" in parsed and isinstance(parsed["outlineTree"], dict):
            children = parsed["outlineTree"].get("children")
            if isinstance(children, list) and len(children) > 0:
                state["content"] = children

        # ---- 错误事件（如 Neo4j 连接失败）----
        if event_name == "error":
            msg = str(parsed.get("message", parsed))
            state.setdefault("_errors", []).append(msg)
            log(f"  [ERROR EVENT] {msg}", raw_log)

        # 阶段 / 进度
        if parsed.get("message"):
            state["stage"] = str(parsed["message"])
        if parsed.get("stage"):
            state["stage"] = str(parsed["stage"])
        if isinstance(parsed.get("progress"), (int, float)):
            state["progress"] = parsed["progress"]
        if parsed.get("title"):
            state["title"] = parsed["title"]

    if event_name == "paper.done":
        # 后端「生成完毕」的唯一权威信号
        state["_paper_done"] = True
    if event_name in ("paper.done", "outline.saved"):
        state["stage"] = "论文生成完成，正在导出 Word"
        state["progress"] = 99
    log(f"  -> paper_done={state.get('_paper_done')} "
        f"stage={state['stage']} progress={state['progress']}", raw_log)


def stream_generate(base_url, token, payload, status_file, raw_log, output_dir, max_wait=600, lit_host=""):
    """一键成文（SSE）。完整地址 = base_url + ONE_CLICK_PATH；lit_host 缺省回退 base_url。"""
    lit_host = lit_host or base_url
    url = base_url.rstrip("/") + ONE_CLICK_PATH
    headers = {"Accept": "text/event-stream", "Content-Type": "application/json",
               "User-Agent": USER_AGENT}
    # 统一鉴权：token 走 header（edu-big-data-server-user-skill）
    headers.update(build_auth_headers(token, base_url))
    body = json.dumps(payload).encode("utf-8")
    state = {
        "status": "processing",
        "stage": "已提交，等待服务器响应",
        "progress": 0,
        "_paper_done": False,   # 后端「生成完毕」信号（eventName=paper.done），成功判定的唯一依据
        "content": None,
        "title": payload.get("title"),
        "type": payload.get("type") or "1",   # 论文类型，导出接口与成文接口共用
        "language": payload.get("language", "中文"),
        "events": [],
        "error": None,
        "docx_path": None,
        "_body_answers": [],
        "_references_raw": "",
        "_user_references": _parse_ref_vip_objs(payload),  # 兜底数据源：用户传入的文献对象数组
        "_references_rebuilt": False,
        "_errors": [],
        "_output_dir": output_dir,
        "_abstract": "",
        "_keywords": "",
        "html_path": None,
        "_target_words": _as_int(payload.get("wordCountLimit") or payload.get("Wordcount")),
    }
    save_status(state, status_file)
    log(f"POST {url}", raw_log)
    log(f"payload={json.dumps(payload, ensure_ascii=False)}", raw_log)
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=1800)
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:500]
        # 仅当后端用错误码（401/403）明确要求登录时才判定 need_login；
        # 🔴 判定必须携带可读原因（need_login_reason）透传给上层——agent 须先向用户
        # 说明原因再引导扫码，禁止不解释直接弹登录。后端未给文案时用状态码兜底解释。
        backend_msg = _extract_backend_message(detail)
        if e.code in LOGIN_REQUIRED_CODES:
            state["status"] = "need_login"
            state["need_login_reason"] = (
                backend_msg or f"平台返回了「{e.code}」状态（{ '身份未通过验证' if e.code in (401,403) else '需要登录' }），需要微信扫码确认身份后继续"
            )
        else:
            state["status"] = "failed"
        state["error"] = f"HTTP {e.code}: {detail}"
        save_status(state, status_file)
        log(state["error"], raw_log)
        return state
    except Exception as e:
        state["status"] = "failed"
        state["error"] = str(e)
        save_status(state, status_file)
        log(state["error"], raw_log)
        return state

    buf = b""
    event_name = None
    data_parts = []
    received_any = False
    start = time.time()
    while True:
        if time.time() - start > max_wait:
            state["status"] = "failed"
            state["error"] = f"超过最大等待 {max_wait}s"
            save_status(state, status_file)
            log(state["error"], raw_log)
            break
        try:
            chunk = resp.read(4096)
        except Exception as e:
            state["status"] = "failed"
            state["error"] = f"读取流异常: {e}"
            save_status(state, status_file)
            log(state["error"], raw_log)
            break
        if not chunk:
            break
        received_any = True
        buf += chunk
        while b"\n" in buf:
            line_b, buf = buf.split(b"\n", 1)
            line = line_b.decode("utf-8", "replace").rstrip("\r")
            if raw_log:
                try:
                    with open(raw_log, "a", encoding="utf-8") as f:
                        f.write(line + "\n")
                except Exception:
                    pass
            if line.strip() == "":
                if event_name:
                    dispatch_event(event_name, "\n".join(data_parts), state, raw_log)
                    save_status(state, status_file)
                event_name = None
                data_parts = []
                continue
            if line.startswith("event:"):
                event_name = line[6:].strip()
            elif line.startswith("data:"):
                data_parts.append(line[5:].strip())

    # ---------- 流结束：合并正文/参考文献，并做失败判定 ----------
    # 成功判定：以 eventName=paper.done 为「生成完毕」的唯一权威信号，不以 paper_id 为准
    # （paper.done 载荷只有 threadId/keywords/outlineTree/content/contentLength）。
    if not state.get("_paper_done"):
        if not received_any:
            # 后端返回空流：未启动生成任务（未登录 / 免费额度用完时后端以此表态）。
            # 🔴 必须携带可读原因（need_login_reason），上层先向用户说明原因、再引导扫码，
            # 禁止不解释原因直接弹登录。
            state["status"] = "need_login"
            state["_empty_response"] = True
            state["need_login_reason"] = "平台没有开始生成（返回了空响应），通常是尚未登录或免费体验次数已用完"
            state["error"] = "SSE 返回空流（后端未返回内容，可能需要登录）"
        else:
            state["status"] = "failed"
            state["_empty_response"] = False
            errs = state.get("_errors", [])
            reason = "；".join(errs) if errs else "未收到 paper.done 事件（生成未完成）"
            state["error"] = f"SSE 流结束但未收到 paper.done：{reason}"
        save_status(state, status_file)
        log(state["error"], raw_log)
        return state
    log("已收到 paper.done，判定生成完毕", raw_log)

    # 1) 注入正文
    answers = state.get("_body_answers", [])
    if answers and isinstance(state["content"], list):
        sections = parse_body_sections(answers)
        mreport = {}
        state["content"] = merge_body_into_outline(state["content"], sections, mreport)
        state["_merge_report"] = mreport
        log(f"已注入正文：{mreport.get('matched', 0)}/{len(sections)} 个章节节点匹配大纲", raw_log)
        if mreport.get("appended"):
            log(f"[修复] {len(mreport['appended'])} 个正文章节未匹配大纲（大纲标题可能被平台截断），"
                f"已追加到文末避免丢失：{mreport['appended']}", raw_log)

    # 2) 写入参考文献（逐条入「参考文献」节点 children，随 contentJson 一并导出；
    #    并同步把正文里的 <sup>[file_id]</sup> 重编号为 [n]）
    ref_raw = state.get("_references_raw", "")
    # 兜底：平台「合并参考文献id」事件未返回文献列表（_references_raw 为空）时，
    # 自动从「正文已标引的文献 file_id」重建参考文献；正文无标引则用用户传入文献兜底。
    # 这对应规则里的「文献不完整自动生成」——保证文末参考文献列表不缺失。
    if not ref_raw:
        _cited_ids = _extract_cited_file_ids(state.get("content"))
        if not _cited_ids and state.get("_user_references"):
            _cited_ids = [str(r.get("file_id") or r.get("id") or "").strip()
                          for r in state["_user_references"]
                          if (r.get("file_id") or r.get("id"))]
        _cited_ids = [i for i in _cited_ids if i]
        if _cited_ids:
            _gb = fetch_references_batch(lit_host, token, _cited_ids) if (lit_host and token) else {}
            if _gb:
                _rebuilt = [{"file_id": fid, "id": fid} for fid in _cited_ids if fid in _gb]
                if _rebuilt:
                    ref_raw = json.dumps(_rebuilt, ensure_ascii=False)
                    state["_references_raw"] = ref_raw
                    state["_references_gbstr"] = _gb
                    state["_references_rebuilt"] = True
                    log(f"参考文献为空，已从正文标引自动重建 {len(_rebuilt)} 篇文献（gbstr 兜底）", raw_log)
    if ref_raw:
        # 先批量拉取接口封装好的引文 gbstr（literaturereference，best-effort）
        file_ids = [str(r.get("file_id") or "") for r in _load_ref_list(ref_raw) if r.get("file_id")]
        gbstr_map = {}
        if file_ids:
            gbstr_map = fetch_references_batch(lit_host, token, file_ids)
            if gbstr_map:
                state["_references_gbstr"] = gbstr_map
                log(f"已从接口获取 {len(gbstr_map)} 篇文献引文(gbstr)", raw_log)
            else:
                log("[WARN] literaturereference 接口未返回引文，降级用本地格式化", raw_log)
        ref_text, fmap = build_references(ref_raw, gbstr_map)
        if ref_text:
            # 先把正文里的 <sup>[file_id]</sup> 重编号为 [1][2]... 与文献列表对齐
            if fmap and isinstance(state["content"], list):
                def remap_node(nodes):
                    for nd in nodes:
                        if isinstance(nd, dict):
                            if nd.get("content"):
                                nd["content"] = remap_citations(nd["content"], fmap)
                            if isinstance(nd.get("children"), list):
                                remap_node(nd["children"])
                remap_node(state["content"])
            # 把参考文献逐条写入「参考文献」节点的 children，与平台 contentJson 原生结构一致；
            # 导出接口按 children 渲染文末文献列表，故不再本地注入 docx。
            ref_entries = [ln.strip() for ln in ref_text.splitlines() if ln.strip()]
            def set_ref(nodes):
                for nd in nodes:
                    if isinstance(nd, dict):
                        if "参考文献" in str(nd.get("title", "")):
                            nd["content"] = ""
                            nd["children"] = [
                                {"title": "", "content": e, "children": []}
                                for e in ref_entries
                            ]
                            return True
                        if isinstance(nd.get("children"), list):
                            if set_ref(nd["children"]):
                                return True
                return False
            if isinstance(state["content"], list):
                if set_ref(state["content"]):
                    log(f"已写入参考文献：{len(ref_entries)} 条（逐条入 children，随 contentJson 一并导出）",
                        raw_log)
                else:
                    # 平台大纲被截断时可能整个缺少「参考文献」节点 → 追加一个，
                    # 否则 contentJson 与导出的 docx 都会完全没有参考文献。
                    state["content"].append({
                        "title": "参考文献",
                        "content": "",
                        "children": [
                            {"title": "", "content": e, "children": []}
                            for e in ref_entries
                        ],
                    })
                    log(f"[修复] 大纲缺少「参考文献」节点，已追加并写入 {len(ref_entries)} 条", raw_log)
        else:
            log("[WARN] 参考文献列表解析为空，参考文献未注入", raw_log)

    # 3) 失败判定：必须有实质正文（递归统计，排除「参考文献」节点）
    body_chars = 0
    if isinstance(state["content"], list):
        def _count_body(nodes):
            total = 0
            for nd in nodes:
                if not isinstance(nd, dict):
                    continue
                if "参考文献" in str(nd.get("title", "")):
                    continue
                total += len(str(nd.get("content") or ""))
                if isinstance(nd.get("children"), list):
                    total += _count_body(nd["children"])
            return total
        body_chars = _count_body(state["content"])
    state["_body_chars"] = body_chars
    # 阈值 100 字：低于此值视为「只有标题的空壳」，不进入导出（避免产出空文档）
    if body_chars < 100:
        state["status"] = "failed"
        errs = state.get("_errors", [])
        reason = "；".join(errs) if errs else "未捕获到正文内容（生成可能未完成）"
        state["error"] = (f"论文正文缺失（正文仅 {body_chars} 字）：{reason}。"
                          f"已中止导出，避免产出仅含标题的空文档。")
        save_status(state, status_file)
        log(state["error"], raw_log)
        return state
    log(f"正文完整性检查通过：{body_chars} 字（>100 字阈值）", raw_log)

    export_and_download(base_url, token, state, status_file, raw_log, output_dir)
    return state


# ---------------------------------------------------------------------------
# HTML 预览渲染（与导出 docx 解耦；参考文献由导出接口按 contentJson 渲染，
# 本文件不再对 docx 做本地注入）。
# ---------------------------------------------------------------------------

def _html_escape(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _render_body_content(content, cite_url_map=None):
    """把节点 content（纯文本 + <sup>[n]</sup> 标记）转成带可点击引用上标的 HTML 段落。

    cite_url_map: {n: 来源文献详情页 URL}，命中则引用上标跳转该详情页（新标签打开）。"""
    if not content:
        return ""
    esc = _html_escape(content)

    def repl(m):
        n = m.group(1)
        url = (cite_url_map or {}).get(n)
        if url:
            return (f'<a class="cite" href="{_html_escape(url)}" target="_blank" '
                    f'rel="noopener" title="跳转来源文献详情页 [{n}]">[{n}]</a>')
        return f'<a class="cite" href="#ref-{n}" title="跳转至参考文献 [{n}]">[{n}]</a>'

    html = re.sub(r"&lt;sup&gt;\[(\d+)\]&lt;/sup&gt;", repl, esc)
    paras = [p.strip() for p in html.split("\n") if p.strip()]
    return "\n".join(f"<p>{p}</p>" for p in paras)


# ---------------------------------------------------------------------------
# 富媒体渲染（图表 / 表格 / 公式 / 代码）
# 设计：预览页必须「图文、公式渲染不丢」。优先用平台下发的 xxxBase64 直出 <img>
#      （无损、最稳）；无 base64 时退回结构化重绘（Chart.js 画图表 / MathJax 渲公式
#      / 三线表 / 代码块）。
# ---------------------------------------------------------------------------

def _render_chart_struct(c):
    """结构化图表 → Chart.js 配置（页面底部统一 new Chart 实例化）。"""
    global _CHARTS
    if "_CHARTS" not in globals():
        _CHARTS = []
    idx = len(_CHARTS)
    cfg = {
        "type": c.get("type", "bar"),
        "data": {
            "labels": c.get("xAxis", []),
            "datasets": [
                {
                    "label": s.get("name", ""),
                    "data": s.get("data", []),
                    "backgroundColor": ["#9db8ff", "#5b8def", "#7f77dd", "#1d9e75"][i % 4],
                    "borderRadius": 4,
                    "maxBarThickness": 48,
                }
                for i, s in enumerate(c.get("series", []))
            ],
        },
        "options": {
            "responsive": True,
            "maintainAspectRatio": False,
            "plugins": {
                "legend": {"display": bool(c.get("legend", False))},
                "title": {"display": True, "text": c.get("title", ""), "font": {"size": 14}},
            },
            "scales": {
                "y": {
                    "beginAtZero": True,
                    "title": {"display": True, "text": c.get("yAxis", {}).get("title", "")},
                }
            },
        },
    }
    _CHARTS.append(cfg)
    desc = c.get("description", "")
    figcap = f'<figcaption>{_html_escape(desc)}</figcaption>' if desc else ""
    return (f'<figure class="chart-fig"><div class="chart-box">'
            f'<canvas id="chart{idx}"></canvas></div>{figcap}</figure>')


def _render_table_struct(t):
    """结构化表格 → 期刊标准三线表（顶线+栏目线+底线，无竖线/内横线/斑马纹）。"""
    headers = t.get("headers", [])
    rows = t.get("data", [])
    if not rows:
        return ""
    rem = [k for k in rows[0].keys() if k != "item"]
    keymap = (["item"] + rem)[: len(headers)]
    th = "".join(f"<th>{_html_escape(h)}</th>" for h in headers)
    body = ""
    for r in rows:
        cells = ""
        for i in range(len(headers)):
            key = keymap[i] if i < len(keymap) else None
            val = str(r.get(key, "")) if key else ""
            cells += f"<td>{_html_escape(val)}</td>"
        body += f"<tr>{cells}</tr>"
    cap = t.get("title", "")
    desc = t.get("description", "")
    cap_html = (f'<caption><b>{_html_escape(cap)}</b>'
                f'<span class="tbl-desc">{_html_escape(desc)}</span></caption>') if cap else ""
    return (f'<div class="table-wrap"><table class="paper-table">'
            f"{cap_html}<thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div>")


def _render_formula_struct(f):
    return f'<div class="formula">{_html_escape(f)}</div>'


def _render_code_struct(code):
    return f'<pre class="code-block"><code>{_html_escape(code)}</code></pre>'


def _render_rich_media(node):
    """渲染节点上的富媒体（图表/表格/公式/代码），保证预览不丢可视化元素。

    优先级：平台下发的 xxxBase64 直出 <img>（无损） > 结构化重绘（Chart.js/MathJax/三线表/代码块）。
    """
    out = []
    # 1) 平台下发的 base64 图片（无损、最稳）
    b64_pairs = [
        ("chartBase64", "图表"), ("tableBase64", "表格"),
        ("formulaBase64", "公式"), ("codeBase64", "代码"),
    ]
    for field, label in b64_pairs:
        v = node.get(field)
        if isinstance(v, str) and v.strip():
            src = v if v.startswith("data:") else "data:image/png;base64," + v
            out.append(
                f'<figure class="media-fig"><img src="{_html_escape(src)}" '
                f'alt="{label}"><figcaption>{label}</figcaption></figure>')
    # 2) 结构化兜底（仅当没有对应 base64 时）
    if node.get("chart") and not node.get("chartBase64") and isinstance(node.get("chart"), dict):
        out.append(_render_chart_struct(node["chart"]))
    if node.get("table") and not node.get("tableBase64") and isinstance(node.get("table"), dict):
        out.append(_render_table_struct(node["table"]))
    if node.get("formula") and not node.get("formulaBase64") and isinstance(node.get("formula"), str):
        out.append(_render_formula_struct(node["formula"]))
    if node.get("code") and not node.get("codeBase64") and isinstance(node.get("code"), str):
        out.append(_render_code_struct(node["code"]))
    return "".join(out)


def render_html_preview(state, html_path):
    """生成可阅读 HTML 预览页（富媒体完整渲染 + 右上角「下载 Word 文档」按钮）。

    - 标题 + 摘要/关键词 + 正文（引用上标可点击跳转来源文献详情页）+ 参考文献列表。
    - 图表/表格/公式/代码均渲染（xxxBase64 直出 img 优先，MathJax/Chart.js 结构化兜底），
      保证图文公式不丢。
    - 右上角固定「下载 Word 文档」按钮：**优先用内联 base64 Blob 直出平台原始 docx**
      （window.__DOCX_B64__，即平台导出的真实 docx，已内嵌预览），表格/公式/图片零丢失。
      HTML 是自包含交付物：双击直开（file://）或托管在任意静态服务下，下载按钮都可用，
      不依赖任何后端端点；仅当内联缺失（如离线重建成品未捕获 docx）时才回退到
      POST /export（本地预览服务的导出端点，仅托管场景可用）。
    """
    global _CHARTS
    _CHARTS = []
    if not html_path:
        return False
    try:
        title = state.get("title") or "论文"
        abstract = state.get("_abstract", "") or ""
        keywords = state.get("_keywords", "") or ""
        content = state.get("content") if isinstance(state.get("content"), list) else []
        gbstr_map = state.get("_references_gbstr") or {}
        ref_items = build_references_items(state.get("_references_raw", ""), gbstr_map)
        cite_url_map = {str(it["n"]): it["url"] for it in ref_items if it.get("url")}
        # 内联真实 docx（base64）：预览页「下载 Word」优先用 Blob 直出这份真实 docx，
        # 表格/公式/图片全部保留；不依赖 /export，WorkBuddy 右侧静态预览也能正常下载。
        docx_b64 = state.get("docx_b64") or ""
        docx_name = state.get("docx_name") or "论文.docx"
        docx_refs = False  # 本版本不再本地注入参考文献，Word 以平台导出为准

        p = []
        p.append("<!DOCTYPE html>")
        p.append("<html lang='zh-CN'><head><meta charset='utf-8'>")
        p.append("<meta name='viewport' content='width=device-width, initial-scale=1'>")
        p.append("<title>" + _html_escape(title) + " - 预览</title>")
        # MathJax（公式）+ Chart.js（图表）按需联网加载
        p.append("<script>window.MathJax={tex:{inlineMath:[['$','$'],['\\\\(','\\\\)']],"
                 "displayMath:[['$$','$$'],['\\\\[','\\\\]']]},svg:{fontCache:'global'}};</script>")
        p.append("<script src='https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js' async></script>")
        p.append("<script src='https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js'></script>")
        p.append(
            "<style>"
            "body{font-family:-apple-system,'Segoe UI','Microsoft YaHei',serif;"
            "max-width:900px;margin:0 auto;padding:32px 20px 80px;color:#1a1a1a;line-height:1.9;background:#fff;}"
            ".title{text-align:center;font-size:24px;font-weight:700;margin:8px 0 24px;}"
            "h2{font-size:19px;border-left:4px solid #2c6ecb;padding-left:10px;margin:28px 0 10px;}"
            "h3{font-size:16px;margin:18px 0 8px;color:#333;}"
            ".abstract,.keywords{background:#f7f9fc;border:1px solid #e6ecf5;border-radius:6px;padding:12px 16px;margin:14px 0;}"
            ".abstract h2,.keywords h2{font-size:15px;border:none;padding:0;margin:0 0 6px;color:#2c6ecb;}"
            ".missing{color:#999;font-style:italic;}"
            "p{text-align:justify;margin:10px 0;text-indent:2em;}"
            "a.cite{color:#2c6ecb;text-decoration:none;font-size:.82em;vertical-align:super;padding:0 1px;}"
            "a.cite:hover{text-decoration:underline;}"
            ".references ul{list-style:none;padding-left:0;}"
            ".references li{margin:6px 0;}"
            ".references li a{color:#2c6ecb;}"
            ".footer{margin-top:30px;color:#999;font-size:12px;text-align:center;}"
            ".media-fig{margin:18px 0;text-align:center;}"
            ".media-fig img{max-width:100%;border:1px solid #e6ecf5;border-radius:8px;}"
            ".media-fig figcaption{font-size:13px;color:#666;margin-top:6px;}"
            ".table-wrap{margin:18px 0;overflow-x:auto;}"
            "table.paper-table{border-collapse:collapse;width:100%;font-size:14.5px;background:#fff;border:none;}"
            "table.paper-table caption{padding:6px 4px 12px;text-align:center;color:#1a1a1a;font-size:14px;border:none;}"
            "table.paper-table caption b{font-size:15px;font-weight:600;}"
            ".tbl-desc{display:block;color:#666;font-size:13px;margin-top:4px;font-weight:400;}"
            "table.paper-table th,table.paper-table td{border:none;padding:8px 12px;vertical-align:top;text-align:left;}"
            "table.paper-table thead th{border-top:2px solid #1a1a1a;border-bottom:1px solid #1a1a1a;font-weight:600;}"
            "table.paper-table tbody tr:last-child td{border-bottom:2px solid #1a1a1a;}"
            ".chart-fig{margin:20px 0;}"
            ".chart-box{height:340px;background:#fff;border:1px solid #e6ecf5;border-radius:10px;padding:16px;}"
            ".chart-fig figcaption{margin-top:8px;font-size:13px;color:#666;text-align:center;}"
            ".formula{margin:18px 0;padding:16px;background:#f6f8fa;border:1px solid #e6ecf5;"
            "border-radius:8px;overflow-x:auto;text-align:center;font-size:18px;}"
            "pre.code-block{margin:18px 0;border-radius:10px;border:1px solid #e6ecf5;background:#f6f8fa;"
            "padding:16px;overflow:auto;font-size:13.5px;line-height:1.6;}"
            "pre.code-block code{font-family:Consolas,Menlo,monospace;background:none;padding:0;}"
            ".export-bar{position:sticky;top:0;z-index:50;display:flex;gap:12px;align-items:center;"
            "justify-content:center;padding:10px 16px;margin:0 0 12px;"
            "background:rgba(255,255,255,.92);backdrop-filter:blur(6px);border:1px solid #e6ecf5;"
            "border-radius:0 0 12px 12px;box-shadow:0 2px 10px rgba(31,35,40,.06);}"
            ".export-bar button{cursor:pointer;border:none;border-radius:8px;padding:9px 18px;"
            "font-size:14px;font-weight:600;color:#fff;background:#2c6ecb;transition:.15s;}"
            ".export-bar button:hover{background:#2459cf;}"
            ".export-bar .status{font-size:13px;color:#666;}"
            ".export-bar .status.err{color:#c0392b;}"
            ".export-bar .status.ok{color:#1a7f37;}"
            ".export-bar .status.warn{color:#b7791f;}"
            ".export-bar .warn-box{display:none;margin-top:6px;max-width:420px;"
            "font-size:12px;line-height:1.5;color:#b7791f;background:#fffaf0;"
            "border:1px solid #f0d9a8;border-radius:6px;padding:6px 8px;}"
            "</style>"
        )
        p.append("</head><body>")
        # 右上角下载工具条
        p.append("<div class='export-bar'>")
        p.append("<button id='btn-export' onclick='exportWord()'>下载 Word 文档</button>")
        p.append("<span id='export-status' class='status'></span>")
        p.append("<a id='export-manual' class='manual-link' "
                 "style='display:none;color:#2c6ecb;font-size:13px;font-weight:600;text-decoration:none;"
                 "padding:2px 8px;border:1px solid #2c6ecb;border-radius:6px;'>手动下载 Word</a>")
        p.append("<div id='export-warning' class='warn-box'></div>")
        p.append("</div>")
        p.append("<article class='paper'>")
        p.append(f"<h1 class='title'>{_html_escape(title)}</h1>")
        abs_html = _html_escape(abstract) if abstract else "<span class='missing'>（本次生成未返回摘要）</span>"
        kw_html = _html_escape(keywords) if keywords else "<span class='missing'>（本次生成未返回关键词）</span>"
        # 摘要/关键词小节标题随论文语言切换（英文论文用 Abstract / Keywords）
        _lang = state.get("language", "中文")
        _abs_label = "Abstract" if _lang == "英文" else "摘要"
        _kw_label = "Keywords" if _lang == "英文" else "关键词"
        p.append("<section class='abstract'><h2>" + _abs_label + "</h2><p style='text-indent:2em;'>" + abs_html + "</p></section>")
        p.append("<section class='keywords'><h2>" + _kw_label + "</h2><p style='text-indent:0;'>" + kw_html + "</p></section>")

        def walk(nodes, depth):
            for nd in nodes:
                if not isinstance(nd, dict):
                    continue
                t = nd.get("title", "")
                # 跳过「参考文献」节点（中英文标题都识别）：由下方 references 区块统一渲染，避免标题/正文重复
                if "作者简介" in t or "参考文献" in t or "reference" in t.lower():
                    continue
                if t:
                    htag = "h2" if depth == 0 else "h3"
                    p.append(f"<{htag}>{_html_escape(t)}</{htag}>")
                c = nd.get("content", "") or ""
                if c:
                    p.append(_render_body_content(c, cite_url_map))
                # 富媒体（节点自身的图表/表格/公式/代码）
                rm = _render_rich_media(nd)
                if rm:
                    p.append(rm)
                walk(nd.get("children", []) or [], depth + 1)

        if content:
            walk(content, 0)
        if ref_items:
            lang = state.get("language", "")
            ref_heading = "References" if lang in ("英文", "English", "en", "EN") else "参考文献"
            p.append(f"<section class='references'><h2>{ref_heading}</h2><ul>")
            for it in ref_items:
                if it["url"]:
                    p.append(
                        f"<li id='ref-{it['n']}'><a href='{_html_escape(it['url'])}' target='_blank' rel='noopener'>"
                        f"{_html_escape(it['text'])}</a></li>"
                    )
                else:
                    p.append(f"<li id='ref-{it['n']}'>{_html_escape(it['text'])}</li>")
            p.append("</ul></section>")
        p.append("<div class='footer'>本预览由 WorkBuddy 论文 Skill 生成 · 点击引用上标或文献条目可跳转来源文献详情页</div>")
        p.append("</article>")
        # 图表实例化 + 导出按钮逻辑
        p.append("<script>")
        p.append("Chart.defaults.font.family='-apple-system,\"PingFang SC\",\"Microsoft YaHei\",sans-serif';")
        p.append("Chart.defaults.color='#57606a';")
        p.append("var CHARTS=" + json.dumps(_CHARTS, ensure_ascii=False) + ";")
        p.append("CHARTS.forEach(function(cfg,i){var el=document.getElementById('chart'+i);"
                 "if(el) new Chart(el,cfg);});")
        p.append("window.__DOCX_B64__=" + json.dumps(docx_b64) + ";")
        p.append("window.__DOCX_NAME__=" + json.dumps(docx_name) + ";")
        p.append("window.__DOCX_REFS__=" + json.dumps(docx_refs) + ";")
        # 下载策略：base64 优先（自包含，file:// 直开或任意静态托管下都可用）；
        # 内联缺失时才回退 POST /export（仅本地预览服务托管场景可用）。
        p.append("function exportWord(){"
                 "var st=document.getElementById('export-status');"
                 "var manual=document.getElementById('export-manual');"
                 "function dlB64(msg){"
                 "var b64=window.__DOCX_B64__||'';"
                 "if(!b64){return false;}"
                 "try{"
                 "var bin=atob(b64);var len=bin.length;var bytes=new Uint8Array(len);"
                 "for(var i=0;i<len;i++){bytes[i]=bin.charCodeAt(i);}"
                 "var blob=new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});"
                 "var url=URL.createObjectURL(blob);"
                 "var fname=window.__DOCX_NAME__||'\u8bba\u6587.docx';"
                 "var a=document.createElement('a');a.href=url;a.download=fname;"
                 "document.body.appendChild(a);a.click();document.body.removeChild(a);"
                 "if(manual){manual.href=url;manual.download=fname;manual.style.display='inline-block';}"
                 "setTimeout(function(){try{URL.revokeObjectURL(url);}catch(e){}},60000);"
                 "st.textContent=msg;st.className='status ok';"
                 "return true;}"
                 "catch(err){return false;}}"
                 "if(dlB64('\u4e0b\u8f7d\u6210\u529f\uff08\u56fe\u8868/\u516c\u5f0f/\u56fe\u7247\u5747\u5df2\u4fdd\u7559\uff09')){return;}"
                 "st.textContent='\u6b63\u5728\u901a\u8fc7\u5e73\u53f0\u91cd\u65b0\u5bfc\u51fa Word\u2026';st.className='status';"
                 "if(manual){manual.style.display='none';}"
                 "fetch('/export',{method:'POST',headers:{'Content-Type':'application/json'},"
                 "body:'{}'})"
                 ".then(function(r){return r.json();})"
                 ".then(function(d){"
                 "if(d.url){"
                 "var fname2=d.url.split('?')[0].split('/').pop()||'\u8bba\u6587.docx';"
                 "var win=window.open(d.url,'_blank');"
                 "if(!win){var a2=document.createElement('a');a2.href=d.url;a2.download=fname2;a2.target='_blank';"
                 "a2.rel='noopener';document.body.appendChild(a2);a2.click();document.body.removeChild(a2);}"
                 "if(manual){manual.setAttribute('data-dl',d.url);manual.style.display='inline-block';manual.onclick=function(ev){ev.preventDefault();var u=this.getAttribute('data-dl');if(u){var f2=document.createElement('iframe');f2.style.display='none';f2.src=u;document.body.appendChild(f2);setTimeout(function(){document.body.removeChild(f2);},120000);}return false;};}"
                 "st.textContent='\u5df2\u7531\u5e73\u53f0\u91cd\u65b0\u5bfc\u51fa\uff0c\u6b63\u5728\u4e0b\u8f7d\u2026\u82e5\u672a\u81ea\u52a8\u5f39\u51fa\u4fdd\u5b58\u6846\uff0c\u8bf7\u70b9\u53f3\u4fa7\u300c\u624b\u52a8\u4e0b\u8f7d Word\u300d';st.className='status ok';"
                 "}"
                 "else{"
                 "st.textContent='\u4e0b\u8f7d\u5931\u8d25\uff1a'+(d.error||'\u672a\u77e5\u9519\u8bef');st.className='status err';}})"
                 ".catch(function(e){"
                 "st.textContent='\u4e0b\u8f7d\u5931\u8d25\uff1a'+(e&&e.message||e);"
                 "st.className='status err';});}")
        p.append("</script>")
        p.append("</body></html>")
        with open(html_path, "w", encoding="utf-8") as f:
            f.write("\n".join(p))
        log(f"HTML 预览已生成（含富媒体+下载按钮）: {html_path}", None)
        return True
    except Exception as e:
        log(f"[WARN] HTML 预览生成失败：{e}", None)
        return False


def check_login(base_url, token):
    """登录态探活（GET /server-user/cu/user-assets/rights/code，统一鉴权）。

    ⚠️ 判定口径（2026-09-11 修正，勿改回 `code == 200`）：
    该接口返回的是「账号权益」，**不是**「凭证有效性」——账号没有对应权益时会返回
    `{"data":null,"message":"未知错误","code":0}`（HTTP 仍为 200）。旧实现要求
    `code == 200`，会把持有有效凭证的用户误判为「已失效」，进而无谓地弹二维码要求重新扫码。

    正确口径：**网关是否接受该凭证** —— HTTP 200 且响应体未显式给出鉴权失败码即视为有效；
    只有 401/403/505/507 才判定失效。网络类异常（超时/网关抖动）**不下失效结论**（返回 True），
    因为「误判有效」无害（真失效会在成文/导出接口再次暴露并走 need_login 流程），
    而「误判失效」有害（会打断用户流程、逼用户重新扫码）。
    """
    if not (token or "").strip():
        return False
    url = base_url.rstrip("/") + "/server-user/cu/user-assets/rights/code?code=longEssayWriting"
    headers = build_auth_headers(token, base_url)
    try:
        req = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:
        if e.code in (401, 403, 505, 507):
            return False
        log(f"[WARN] 登录态检查失败（{e.code}），不下失效结论：{e}", None)
        return True
    except Exception as e:
        log(f"[WARN] 登录态检查失败（{type(e).__name__}），不下失效结论：{e}", None)
        return True
    try:
        result = json.loads(raw)
    except Exception:
        return True  # HTTP 200 但非 JSON：网关已放行，按有效处理
    if isinstance(result, dict) and result.get("code") in (401, 403, 505, 507):
        return False
    return True


def resolve_data_dir():
    """定位用户产出根目录（用户工作空间）。

    优先级：环境变量 LUHE_PAPER_DATA_DIR > 当前运行目录(cwd)/paper-writer-data。
    agent 从用户工作空间运行脚本时，产出自动落在 <工作空间>/paper-writer-data/
    （outputs/、status.json、history.json 等）。
    注意：config.json 与产出同放数据目录（凭证不随 skill 升级丢失），见 resolve_config_path。
    """
    env = (os.environ.get("LUHE_PAPER_DATA_DIR") or "").strip()
    if env:
        return os.path.expanduser(env)
    return os.path.join(os.path.abspath(os.getcwd()), "paper-writer-data")


def resolve_config_path(cli_path="", env=None, script_dir=None, data_dir=None):
    """按优先级定位 config.json，返回路径字符串（可能不存在）或 ""。

    优先级（高 → 低）：
      1. --config 显式传入
      2. 环境变量 LUHE_CONFIG（如 ~/.workbuddy/luhe-config.json）
      3. 数据目录 config.json（<resolve_data_dir()>/config.json）—— 默认位置（凭证不随 skill 升级丢失）
      4. skill 根目录/config.json（scripts/ 的上一级）—— 出厂默认与回退

    纯函数：env / script_dir / data_dir 可注入，便于离线测试。
    """
    if cli_path:
        return cli_path
    env = os.environ if env is None else env
    env_path = (env.get("LUHE_CONFIG") or "").strip()
    if env_path:
        return os.path.expanduser(env_path)
    data_dir = resolve_data_dir if data_dir is None else data_dir
    data_cfg = os.path.join(data_dir(), "config.json")
    if os.path.exists(data_cfg):
        return data_cfg
    if script_dir is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    skill_cfg = os.path.join(os.path.dirname(script_dir), "config.json")
    if os.path.exists(skill_cfg):
        return skill_cfg
    return data_cfg


def load_config(config_path):
    """从 config.json 读取 base_url / token / lit_host 等字段，返回 dict 或 None。"""
    if not config_path:
        return None
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return None
    except Exception as e:
        log(f"[WARN] 读取 config.json 失败: {e}", None)
        return None


def main():
    p = argparse.ArgumentParser(description="论文一键成文 SSE 客户端")
    p.add_argument("--config", default="",
                   help="config.json 路径；不传则依次找环境变量 LUHE_CONFIG、数据目录 paper-writer-data/config.json、skill 根目录/config.json")
    p.add_argument("--base-url", default="",
                   help="平台地址；不传则从 config.json 读取（脚本不写死任何环境地址）")
    p.add_argument("--token", default="", help="[可选] 登录凭证；缺省时直接生成，后端要求登录才拉起微信扫码")
    p.add_argument("--title", default="", help="论文标题（--check-login 模式下可省略）")
    p.add_argument("--language", default="中文", choices=["中文", "英文"])
    p.add_argument("--word-count", type=int, default=5000, choices=[3000, 5000, 8000])
    _data_dir = resolve_data_dir()
    p.add_argument("--output-dir", default=os.path.join(_data_dir, "outputs"))
    p.add_argument("--status-file", default=os.path.join(_data_dir, "status.json"))
    p.add_argument("--raw-log", default=os.path.join(_data_dir, "sse_raw.log"))
    p.add_argument("--max-wait", type=int, default=600,
                   help="SSE 流最长等待秒数（默认 600；正常生成约 2-4 分钟）")
    p.add_argument("--lit-host", default="",
                   help="文献引文接口主机（默认从 config.json 读，缺省回退 base_url）")
    p.add_argument("--reference-vip", default="",
                   help="自定义参考文献：文献对象数组。可传 (a) @文件路径.json 指向含所选文献对象的数组；"
                        "(b) 内联 JSON 字符串如 '[{\"id\":\"7202367986\"}]'；留空则沿用系统自动推荐")
    p.add_argument("--check-login", action="store_true",
                   help="仅检查登录态是否有效后退出（不生成论文）")
    p.add_argument("--login-timeout", type=int, default=300, help="微信扫码登录等待超时（秒，默认 300）")
    p.add_argument("--qr-image", default="", help="微信二维码 PNG 输出路径（默认 <数据目录>/outputs/login_qr.png）")
    p.add_argument("--login-status-file", default="", help="登录状态文件（默认 <数据目录>/login_status.json）")
    p.add_argument("--no-auto-login", action="store_true",
                   help="[已废弃·默认行为] 后端要求登录时立即退出（退出码 3），由上层引导扫码；保留参数向后兼容")
    p.add_argument("--auto-login", action="store_true",
                   help="后端要求登录时在脚本内阻塞等待扫码、成功后自动续写（仅前台交互场景；"
                        "后台运行时禁用——用户看不到二维码，只会无限等待）")
    args = p.parse_args()

    # 从 config.json 补全缺省值（--config > $LUHE_CONFIG > 数据目录 > skill 根目录）
    cfg_path = resolve_config_path(args.config)
    cfg = load_config(cfg_path)
    if cfg:
        if not args.base_url:
            args.base_url = cfg.get("base_url", "")
        if not args.token:
            args.token = cfg.get("token", "")
        if not args.lit_host:
            args.lit_host = cfg.get("lit_host", "")
    # lit_host 缺省回退 base_url（脚本不写死任何环境地址）
    if not args.lit_host:
        args.lit_host = args.base_url

    if not args.base_url:
        print("[错误] 未配置平台地址：请在 config.json 填写 base_url（参考 config.example.json），"
              "或用 --base-url 显式指定")
        return

    if args.check_login:
        if not args.token:
            print("[登录态] 未登录（config.json 无 token）")
            sys.exit(1)
        ok = check_login(args.base_url, args.token)
        print("[登录态] 有效" if ok else "[登录态] 已失效，请重新扫码登录")
        sys.exit(0 if ok else 1)

    if not args.title.strip():
        print("[错误] 未提供 --title（生成模式必填）")
        return

    # 解析 --reference-vip：支持 @文件.json / 路径.json（文献对象数组）或内联 JSON 字符串
    ref_vip = None
    if args.reference_vip:
        raw = args.reference_vip.strip()
        if raw.startswith("@") or raw.endswith(".json"):
            fp = raw[1:] if raw.startswith("@") else raw
            try:
                with open(fp, "r", encoding="utf-8") as f:
                    ref_vip = json.load(f)
            except Exception as e:
                print(f"[错误] 读取 reference-vip 文件失败: {e}", file=sys.stderr)
                sys.exit(2)
        else:
            try:
                ref_vip = json.loads(raw)
            except Exception as e:
                print(f"[错误] --reference-vip 不是合法 JSON 或文件路径: {e}", file=sys.stderr)
                sys.exit(2)

    data_dir = resolve_data_dir()
    qr_image = args.qr_image or os.path.join(data_dir, "outputs", "login_qr.png")
    login_status = args.login_status_file or os.path.join(data_dir, "login_status.json")

    try:
        open(args.raw_log, "w").close()
    except Exception:
        pass

    log("=== 开始论文一键成文 ===", args.raw_log)
    payload = gen_payload(args.title, args.language, args.word_count, reference_vip=ref_vip)

    # 按需登录：直接发起 SSE 生成；后端用空流 / 401 表达「需要登录」。
    # need_login 时【立即退出、交还控制权给上层】，由 agent 出二维码引导用户扫码，
    # 扫完重新发起生成。后台任务中禁止阻塞等待扫码——用户看不到二维码，
    # 只会表现为"一直挂着不动"。
    # 仅当显式传 --auto-login（前台交互场景）才在脚本内等待扫码并续写。
    token = args.token
    while True:
        state = stream_generate(
            args.base_url, token, payload,
            args.status_file, args.raw_log, args.output_dir, args.max_wait,
            lit_host=args.lit_host,
        )

        # 后端要求登录（401/403 且带明确文案 / 免费额度用完）
        if state.get("status") == "need_login":
            # 🔴 铁律：need_login 必须携带后端原始提示（need_login_reason），
            # 上层须先向用户说明原因再引导扫码；空流等无凭据场景已改判 failed，不会走到这里。
            qr_hint = state.get("need_login_reason") or state.get("error") or ""
            if not args.auto_login:
                # 默认路径：立即退出。退出码 3 = 需要登录（上层凭此立刻引导用户扫码）。
                # 同时预生成二维码图片并写状态文件，让 agent 可直接展示给用户。
                state["status"] = "need_login"
                state["login_qr_image"] = qr_image
                state["login_status_file"] = login_status
                state["need_login_reason"] = qr_hint
                save_status(state, args.status_file)
                log(f"[登录] 后端要求登录（原因：{qr_hint}）：预生成二维码并立即退出（退出码 3），等待用户扫码",
                    args.raw_log)
                print(f"[登录] 后端要求登录，原因：{qr_hint}")
                print(f"[登录] 二维码图片：{qr_image}")
                print(f"[登录] 登录状态文件：{login_status}")
                try:
                    import login as _login
                    _login.ensure_logged_in(args.base_url, resolve_config_path(args.config),
                                            qr_image, login_status, timeout=0)
                except Exception as e:
                    log(f"[WARN] 预生成二维码失败: {e}", args.raw_log)
                sys.exit(3)
            # --auto-login：前台交互场景，出码后阻塞等待扫码，成功则续写
            log("[登录] 后端要求登录，重新扫码…", args.raw_log)
            print(f"[登录] 后端要求登录，正在重新生成微信二维码（图片：{qr_image}）")
            tok = trigger_login(args.base_url, cfg_path, login_status, qr_image,
                                timeout=args.login_timeout)
            if tok:
                token = tok
                args.token = tok
                cfg = load_config(cfg_path)
                if not args.lit_host and cfg.get("lit_host"):
                    args.lit_host = cfg["lit_host"]
                continue
            # 扫码超时/失败：同样退出交还控制权，不无限重试
            log("[登录] 等待扫码超时或失败，退出（退出码 3）", args.raw_log)
            state["status"] = "need_login"
            state["error"] = state.get("error") or "等待扫码超时或失败"
            save_status(state, args.status_file)
            sys.exit(3)
        break

    log("=== 结束 ===", args.raw_log)


if __name__ == "__main__":
    main()
