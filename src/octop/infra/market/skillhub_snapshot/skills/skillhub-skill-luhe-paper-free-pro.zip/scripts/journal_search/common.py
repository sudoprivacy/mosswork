"""
eduagent-journal-search 公共模块

封装 维普/露禾 期刊高级检索接口：
  POST https://eduagent.cqvip.com/server-journal/journal/AdvanceSearch

提供：配置常量、Cookie 凭据管理、HTTP 请求（标准库 urllib，无第三方依赖）、
文献条目解析（Document 数据模型）、聚合分面解析。

凭据约定：
  环境变量 EDUAGENT_COOKIE 是 eduagent.cqvip.com 的完整登录态 Cookie。
  获取方式见 SKILL.md「凭据约定」：浏览器登录后从 AdvanceSearch 请求头复制 Cookie。
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# --- 配置 ---------------------------------------------------------------

BASE_URL = "https://eduagent.cqvip.com"
ENV_VAR_NAME = "EDUAGENT_COOKIE"
ADVANCE_SEARCH_PATH = "/server-journal/journal/AdvanceSearch"

# 文献详情页链接模板（用 .format(id=..., type=...) 填充）。
# 站点详情路由可能随版本变化，若打不开请按 references/fields.md 调整。
LITERATURE_DETAIL_URL = BASE_URL + "/weResearch/literatureDetail/{id}/{type}"

# 本 skill 安装目录（scripts/ 的上一级），用于保护机制：
# 任何写文件的默认落点都落在「工作目录」内，不允许落到 skill 目录本身。
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DEFAULT_TYPES = [1]
DEFAULT_AGS_CODES = ["Y", "J", "A", "O", "C", "S", "class_lhzxx", "range"]

# 期刊「收录来源 / 评价围栏」代码 → 中文可读名。
# 来源：AdvanceSearch 返回 journalInfo.range（数组）+ journalInfo.isCore（0/1）。
# 注意：部分代码（如 AMI_A_S / NSSD）的确切含义需平台侧最终确认，
# 未知代码一律原样展示，便于核对而非臆造含义。
JOURNAL_RANGE_LABELS = {
    "PKU": "北大核心",
    "CSSCI": "CSSCI(南大核心)",
    "CSCD": "CSCD",
    "AMI": "AMI核心(社科院)",
    "WANFANG": "万方",
    "CNKI": "知网",
    "NSSD": "国家社科文献中心",
    "CORE": "核心",
}

# 不展示的收录代码（用户要求隐藏：疑似武大核心 / 北大核心另一标注 / 维普核心，
# 含义待平台确认，干脆不展示，避免干扰挑选）。
HIDDEN_RANGE_CODES = {"RCCSE_C", "BDHX", "VIP_C"}


def map_journal_range(codes, is_core: int = 0) -> str:
    """把 journalInfo.range 的代码列表转成「中文(原码)」可读名；未知代码原样保留。

    位于 HIDDEN_RANGE_CODES 中的代码不展示（既不显示中文也不显示原码）。
    """
    if not codes and not is_core:
        return ""
    labels = []
    for c in (codes or []):
        cs = str(c).strip().upper()
        if cs in HIDDEN_RANGE_CODES:
            continue  # 用户要求隐藏的码，完全不展示
        name = None
        if cs.startswith("AMI"):
            name = "AMI核心(社科院)"
        elif cs in JOURNAL_RANGE_LABELS:
            name = JOURNAL_RANGE_LABELS[cs]
        if name:
            labels.append(f"{name}({c})")  # 翻译 + 保留原名
        else:
            labels.append(str(c))          # 未知代码原样展示，不臆造含义
    if is_core and not any("北大核心" in x for x in labels):
        labels.append("北大核心")           # isCore 布尔，无原码可附
    seen, out = set(), []
    for x in labels:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return "、".join(out)


def doc_is_core_indexed(doc) -> bool:
    """是否为核心期刊收录：北大核心(isCore=1 / PKU) 或 南大核心(CSSCI)。"""
    codes = [str(c).strip().upper() for c in (doc.journal_range or [])]
    return doc.is_core == 1 or "PKU" in codes or "CSSCI" in codes


def rank_core_first(docs) -> list:
    """核心文献（北大核心/南大核心）置顶，组内保持原序（稳定排序）。"""
    return sorted(docs, key=lambda d: 0 if doc_is_core_indexed(d) else 1)

# 站点识别所需的固定请求头（来自用户抓包的原始 curl）
DEFAULT_HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    "Content-Type": "application/json",
    "m-referrer": "https://luhe.cqvip.com/",
    "Origin": "https://eduagent.cqvip.com",
    "Referer": "https://eduagent.cqvip.com/scientific-research2/writing",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0"
    ),
}


# --- 凭据 ---------------------------------------------------------------

class EduAgentCookieError(RuntimeError):
    """缺少 EDUAGENT_COOKIE 环境变量时抛出。"""


def get_cookie(env_var: str = ENV_VAR_NAME) -> str:
    """从环境变量读取登录态 Cookie，找不到时抛出带说明的异常。"""
    cookie = os.environ.get(env_var, "").strip()
    if not cookie:
        raise EduAgentCookieError(
            f"未检测到环境变量 {env_var}（登录态 Cookie 缺失）。\n"
            "获取方式：浏览器登录 https://eduagent.cqvip.com，\n"
            "开发者工具 → Network → 过滤 AdvanceSearch → 复制 Request Headers 的"
            f" 完整 Cookie 值，写入系统环境变量 {env_var}。"
        )
    return cookie


def build_headers(cookie: str) -> Dict[str, str]:
    """构造请求头。Cookie 是站点识别用户的关键；cookie 为空时匿名检索（不带 Cookie）。"""
    headers = dict(DEFAULT_HEADERS)
    if cookie and str(cookie).strip():
        headers["Cookie"] = cookie
    return headers


# --- 标准库 HTTP（替代 requests，无需第三方依赖）------------------------

def _encode_body(body: Any) -> bytes:
    return json.dumps(body).encode("utf-8")


def _make_request(url: str, body: Any, headers: Dict[str, str], timeout: float):
    """用标准库发起 JSON POST，返回 urllib 响应对象（调用方负责读取/关闭）。"""
    req = urllib.request.Request(
        url, data=_encode_body(body), headers=dict(headers), method="POST"
    )
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:  # 非 2xx
        detail = ""
        try:
            detail = e.read().decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            pass
        raise RuntimeError(f"HTTP {e.code}: {detail[:500]}") from e


def http_post_json(
    url: str,
    body: Any,
    headers: Dict[str, str],
    timeout: float = 60.0,
) -> Any:
    """发起 JSON POST 并解析响应为 JSON。"""
    with _make_request(url, body, headers, timeout) as resp:
        raw = resp.read().decode("utf-8", "replace")
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        raise RuntimeError(f"响应不是合法 JSON：{raw[:300]}")


# --- 数据模型 -----------------------------------------------------------

@dataclass
class Document:
    """单条期刊文献检索结果。"""
    id: str = ""
    title: str = ""
    authors: str = ""
    journal: str = ""
    year: str = ""
    typename: str = ""
    journal_range: List[str] = field(default_factory=list)  # journalInfo.range 收录来源代码
    is_core: int = 0                                       # journalInfo.isCore 北大核心标识
    doi: str = ""
    abstract: str = ""
    keywords: str = ""
    cited: Any = None       # byRefCnt 被引频次
    views: Any = None       # viewCnt 浏览
    collections: Any = None  # collectionCnt / collectNum 收藏
    pub_date: str = ""
    vol: str = ""
    issue: str = ""
    pages: str = ""
    fund: str = ""
    detail_url: str = ""
    type_code: int = 0
    raw: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "authors": self.authors,
            "journal": self.journal,
            "year": self.year,
            "typename": self.typename,
            "journal_range": self.journal_range,
            "is_core": self.is_core,
            "doi": self.doi,
            "abstract": self.abstract,
            "keywords": self.keywords,
            "cited": self.cited,
            "views": self.views,
            "collections": self.collections,
            "pub_date": self.pub_date,
            "vol": self.vol,
            "issue": self.issue,
            "pages": self.pages,
            "fund": self.fund,
            "detail_url": self.detail_url,
            "type_code": self.type_code,
        }

    def citation(self) -> str:
        """GB/T 7714 风格的简明引用（不含序号）。"""
        segs: List[str] = []
        if self.authors:
            segs.append(self.authors)
        if self.title:
            segs.append(self.title)
        source_parts = []
        if self.journal:
            source_parts.append(self.journal)
        if self.year:
            source_parts.append(self.year)
        if source_parts:
            segs.append(", ".join(source_parts) + ".")
        if self.doi:
            segs.append(f"DOI: {self.doi}")
        elif self.detail_url:
            segs.append(self.detail_url)
        return ". ".join(segs) if segs else (self.title or "(无题)")


def _first_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    if isinstance(value, list):
        return str(value[0]) if value else default
    return str(value)


def parse_document(entry: Dict[str, Any]) -> Optional[Document]:
    """解析 AdvanceSearch dataModels 中的单条文献（扁平字段结构）。

    字段映射（实测自接口返回）：
      - id / lngid → 文献唯一标识（优先 id）
      - title → 题名
      - authorInfo: [{name, organ, ...}] → 作者
      - journalname / journalInfo.name → 期刊名
      - year / journalInfo.year / pubDate → 年份
      - type / typename → 文献类型
      - abstr → 文摘；keywordInfo: [{name}] → 关键词
      - byRefCnt → 被引；viewCnt → 浏览；collectionCnt/collectNum → 收藏
      - doi / pdfPath / vol / num / beginPage / endPage / fundInfo → 其他元数据
    """
    if not isinstance(entry, dict):
        return None

    doc_id = _first_str(entry.get("id") or entry.get("lngid"))
    if not doc_id:
        doc_id = str(entry.get("lngid") or "")

    # 作者
    authors = ""
    ai = entry.get("authorInfo")
    if isinstance(ai, list):
        names = [
            a.get("name") for a in ai
            if isinstance(a, dict) and a.get("name")
        ]
        if names:
            authors = "; ".join(names)
    elif isinstance(ai, str):
        authors = ai

    # 期刊名 + 收录来源(range) + 北大核心(isCore)
    journal = entry.get("journalname") or ""
    jinfo = entry.get("journalInfo")
    jrange: List[str] = []
    is_core = 0
    if isinstance(jinfo, dict):
        journal = journal or (jinfo.get("name") or "")
        rg = jinfo.get("range")
        if isinstance(rg, list):
            jrange = [str(x) for x in rg if x]
        ic = jinfo.get("isCore")
        if isinstance(ic, int):
            is_core = ic
        elif isinstance(ic, str) and ic.isdigit():
            is_core = int(ic)

    # 年份（优先 year，其次 journalInfo.year，其次 pubDate 前 4 位）
    year = _first_str(entry.get("year"))
    if not year and isinstance(jinfo, dict):
        year = _first_str(jinfo.get("year"))
    if not year:
        pd = _first_str(entry.get("pubDate"))
        if len(pd) >= 4:
            year = pd[:4]

    # 文摘 + 关键词
    abstract = entry.get("abstr") or entry.get("abstract") or ""
    keywords = ""
    kw = entry.get("keywordInfo")
    if isinstance(kw, list):
        kwn = [k.get("name") for k in kw if isinstance(k, dict) and k.get("name")]
        if kwn:
            keywords = "; ".join(kwn)
            if abstract and not abstract.endswith("\n"):
                abstract = abstract + f"\n关键词：{keywords}"
            elif abstract:
                abstract = abstract + f"\n关键词：{keywords}"

    # 期/卷/页
    vol = _first_str(entry.get("vol") or (jinfo or {}).get("vol"))
    issue = _first_str(entry.get("num"))
    begin = _first_str(entry.get("beginPage"))
    end = _first_str(entry.get("endPage"))
    pages = f"{begin}-{end}" if begin and end else (begin or end)

    # 基金
    fund = ""
    fi = entry.get("fundInfo")
    if isinstance(fi, list):
        fund = "; ".join(str(x) for x in fi if x)
    elif isinstance(fi, str):
        fund = fi

    type_code = entry.get("type")
    if not isinstance(type_code, int):
        type_code = 0

    detail_url = ""
    if doc_id:
        detail_url = LITERATURE_DETAIL_URL.format(id=doc_id, type=type_code)

    return Document(
        id=doc_id,
        title=str(entry.get("title") or ""),
        authors=str(authors),
        journal=str(journal),
        year=str(year),
        typename=str(entry.get("typename") or "期刊"),
        journal_range=jrange,
        is_core=is_core,
        doi=str(entry.get("doi") or ""),
        abstract=str(abstract),
        keywords=str(keywords),
        cited=entry.get("byRefCnt"),
        views=entry.get("viewCnt"),
        collections=entry.get("collectionCnt") or entry.get("collectNum"),
        pub_date=str(entry.get("pubDate") or ""),
        vol=str(vol),
        issue=str(issue),
        pages=str(pages),
        fund=str(fund),
        detail_url=str(detail_url),
        type_code=type_code,
        raw=entry,
    )


@dataclass
class SearchResult:
    """一次 AdvanceSearch 的聚合结果。"""
    query: str
    code: int = 0
    message: str = ""
    documents: List[Document] = field(default_factory=list)
    aggs: List[Any] = field(default_factory=list)
    pagination: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "query": self.query,
            "code": self.code,
            "message": self.message,
            "total": self.pagination.get("total"),
            "page": self.pagination.get("page"),
            "size": self.pagination.get("size"),
            "total_pages": self.pagination.get("total_pages"),
            "has_next": self.pagination.get("has_next"),
            "documents": [d.to_dict() for d in self.documents],
            "aggs": self.aggs,
        }


def parse_response(query: str, data: Dict[str, Any]) -> SearchResult:
    """把 AdvanceSearch 的 JSON 响应解析为 SearchResult。"""
    code = data.get("code", 0)
    message = data.get("message", "")
    payload = data.get("data") or {}

    models = payload.get("dataModels") or []
    if not isinstance(models, list):
        models = []

    docs: List[Document] = []
    for entry in models:
        doc = parse_document(entry)
        if doc is not None:
            docs.append(doc)

    aggs = payload.get("aggs") or []
    if not isinstance(aggs, list):
        aggs = []

    pagination = {
        "page": payload.get("pageIndex"),
        "size": payload.get("pageSize"),
        "total": payload.get("totalCount"),
        "total_pages": payload.get("totalPages"),
        "has_next": payload.get("hasNextPages"),
        "has_prev": payload.get("hasPrevPages"),
    }

    return SearchResult(
        query=query,
        code=code,
        message=message,
        documents=docs,
        aggs=aggs,
        pagination=pagination,
    )


# --- 输出路径保护 -------------------------------------------------------

def resolve_output_path(output: Optional[str], default_name: str) -> str:
    """解析 Markdown 报告的最终输出路径，禁止落到 skill 目录内。"""
    if output:
        base = output if os.path.isabs(output) else os.path.join(os.getcwd(), output)
    else:
        base = os.path.join(os.getcwd(), default_name)

    norm_base = os.path.normpath(os.path.abspath(base))
    norm_skill = os.path.normpath(SKILL_DIR)
    try:
        inside_skill = os.path.commonpath([norm_base, norm_skill]) == norm_skill
    except ValueError:
        inside_skill = False

    if inside_skill:
        ws = os.environ.get("WORKBUDDY_WORKSPACE")
        fallback_dir = ws if (ws and os.path.isdir(ws)) else os.path.expanduser("~")
        print(
            f"[eduagent] 警告：默认输出目录位于 skill 目录内，已改写到：{fallback_dir}",
            file=sys.stderr,
        )
        base = os.path.join(fallback_dir, os.path.basename(norm_base))
    return base
