#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""本地论文预览服务（127.0.0.1，自动端口）。

用法：
  python paper_preview_server.py \
    --html ../outputs/论文_xxx_日期.html \
    --payload ../outputs/preview_payload.json \
    --token <登录token> \
    --base-url <平台地址，见 config.json> \
    --port 0 \
    --url-file ../outputs/preview_url.txt

职责：
  1. 托管富媒体 HTML 阅读页（图文/公式完整渲染），在浏览器打开即可整篇预览。
  2. 提供 POST /export 端点：浏览器点「下载 Word 文档」按钮时调本服务，
    本服务用服务端持有的论文元信息 + contentJson 调露禾导出接口
    （POST /server-agent/writing/paper/export/direct）拿到 docx 直链回传，浏览器触发下载。
    参考文献由导出接口按 contentJson「参考文献」节点 children 渲染，本服务不再本地注入。
     —— token 与 contentJson 始终在服务端，绝不进入浏览器，安全。

设计要点：
  * 服务与调用方同一进程，能直接用登录 token，不向浏览器暴露凭证。
  * 静态文件仅允许访问工作目录内的白名单扩展名，防目录穿越。
  * 自探测就绪后再写入 url 文件并打印端口行，agent 拿到即可直接推送预览地址。
  * 空闲超时（默认 60 分钟，`--idle-timeout` 可调）无请求即自动退出，
    并**确保监听套接字一并关闭、端口释放**（统一关闭出口见 serve() 的 finally），
    防进程残留与端口长期占用；前端关闭页面后随之回收。
"""

import argparse
import http.server
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

AUTH_HEADER_NAME = "edu-big-data-server-user-skill"  # 微信扫码登录凭证头
#: 统一 User-Agent（不带会被 WAF 拦截 403）
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
)
EXPORT_PATH = "/server-agent/writing/paper/export/direct"

_ALLOWED_EXT = (".html", ".js", ".css", ".json", ".png", ".svg", ".ico")
_HEARTBEAT_PATH = "/__ping__"
_IDLE_TIMEOUT = 3600.0        # 空闲多久自动退出（秒）；CLI --idle-timeout 可覆盖
_WATCHDOG_INTERVAL = 15.0     # 看门狗轮询与主循环等待间隔（秒）

_last_activity = 0.0
_activity_lock = threading.Lock()
_stop_event = threading.Event()


def build_auth_headers(token):
    """统一鉴权头：token 走 header（edu-big-data-server-user-skill），不带 Cookie。"""
    if not token:
        return {}
    return {
        AUTH_HEADER_NAME: token,
        "User-Agent": USER_AGENT,
    }


def _local_opener():
    """回环探测专用 opener：**显式禁用代理**。

    `urllib.request.urlopen` 会读取 http_proxy / https_proxy 环境变量，若宿主机配了
    代理（沙箱、企业网络很常见），对 127.0.0.1 的自探测会被送到代理，代理连不上本地
    端口就回 502 —— 服务其实早已就绪，却被判成「启动自探测失败」。本机回环无需代理，
    故这里一律走直连。
    """
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _touch():
    global _last_activity
    with _activity_lock:
        _last_activity = time.monotonic()


def _idle_seconds():
    with _activity_lock:
        return time.monotonic() - _last_activity


def _export_paper(base_url, token, content_json, meta=None, retries=3):
    """调露禾导出接口拿 docx 直链（免 paperId）。

    meta 为导出所需的论文元信息：type/title/abstracts/keywords/authors。
    contentJson 含 xxxBase64，服务端据此嵌图。
    """
    if not content_json:
        raise RuntimeError("导出 Word 的 contentJson 为空")
    m = meta or {}
    body = {
        "type": m.get("type") or "1",
        "title": m.get("title") or "",
        "abstracts": m.get("abstracts") or "",
        "keywords": m.get("keywords") or "",
        "authors": m.get("authors") or "",
        "contentJson": content_json,
    }
    last_err = None
    for attempt in range(retries):
        try:
            url = base_url.rstrip("/") + EXPORT_PATH
            req = urllib.request.Request(
                url, data=json.dumps(body).encode("utf-8"),
                headers={**build_auth_headers(token), "Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                rj = json.loads(resp.read().decode("utf-8"))
            if rj.get("code") != 200:
                raise RuntimeError(f"导出失败（code={rj.get('code')}）：{rj.get('msg')}")
            dl = rj.get("data")
            if not dl:
                raise RuntimeError("导出成功但未返回下载链接")
            return dl
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"导出 HTTP {e.code}")
        except Exception as e:  # 隧道抖动等非业务异常，重试
            last_err = e
            if attempt < retries - 1:
                time.sleep(2)
    raise RuntimeError(f"导出失败（重试 {retries} 次仍异常）：{last_err}")


# （参考文献相关辅助函数已移除：参考文献由导出接口按 contentJson「参考文献」节点的
#   children 渲染，本服务不再本地解析/注入 docx。）


# （docx 零依赖读写 / 参考文献注入相关函数已移除：参考文献由导出接口按 contentJson 渲染。）


def _download_and_augment(base_url, token, content_json, root, meta=None):
    """调平台导出接口拿 docx 直链 → 下载到本地 → 返回本服务 /download 路由的相对地址。

    返回 (download_rel_url, injected_bool, warning_text)。参考文献由导出接口按 contentJson
    「参考文献」节点 children 渲染，本服务不再本地注入 docx。
    登录方式为微信扫码，凭证失效时须回到对话里重新扫码，本服务不做自动续期。"""
    def export_once(tok):
        return _export_paper(base_url, tok, content_json, meta)

    url = export_once(token)
    dl_name = "paper_preview.docx"
    dl_path = os.path.join(root, dl_name)
    try:
        req_d = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req_d, timeout=120) as dresp:
            data = dresp.read()
        with open(dl_path, "wb") as f:
            f.write(data)
    except Exception as e:
        # 平台 docx 下载失败：退回原始直链，明确告警
        print(f"[WARN] 平台 docx 下载失败，退回原始直链：{e}", file=sys.stderr)
        return url, False, "平台 docx 下载失败，已退回原始导出链接"
    # 参考文献由导出接口按 contentJson 渲染，无需本地注入。
    return "/download/" + dl_name, False, ""


class _Handler(http.server.BaseHTTPRequestHandler):
    root = "."
    payload = {"type": "1", "contentJson": []}
    base_url = ""
    token = ""

    def _send_json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path):
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError:
            self.send_error(404, "Not Found")
            return
        ext = os.path.splitext(path)[1].lower()
        ctype = {
            ".html": "text/html; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".png": "image/png",
            ".svg": "image/svg+xml",
            ".ico": "image/x-icon",
        }.get(ext, "application/octet-stream")
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        route = self.path.split("?", 1)[0]
        # 浏览器会对中文文件名做 percent-encode，先解码以正确匹配路由
        route = urllib.parse.unquote(route)
        if route == _HEARTBEAT_PATH:
            _touch()
            self._send_json({"ok": True, "ts": int(time.time())})
            return
        _touch()
        # 下载 docx（平台原始导出，未做本地后处理）
        if route.startswith("/download/"):
            self._serve_download(route)
            return
        # 预览页：/ 与 /<html 文件名> 都服务 HTML
        if route in ("/", "/" + os.path.basename(_Handler._html_name)):
            self._serve_preview_html()
            return
        if ".." in route or not route.startswith("/"):
            self.send_error(403, "Forbidden")
            return
        rel = route.lstrip("/")
        full = os.path.normpath(os.path.join(self.root, rel))
        if not full.startswith(os.path.abspath(self.root)):
            self.send_error(403, "Forbidden")
            return
        if os.path.isfile(full) and rel.lower().endswith(_ALLOWED_EXT):
            self._send_file(full)
        else:
            self.send_error(404, "Not Found")

    def _serve_preview_html(self):
        """服务预览 HTML（整篇阅读 + 右上角「下载 Word 文档」按钮由 HTML 自带）。"""
        path = os.path.join(self.root, _Handler._html_name)
        try:
            with open(path, "r", encoding="utf-8") as f:
                html = f.read()
        except OSError:
            self.send_error(404, "Not Found")
            return
        data = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_download(self, route):
        fname = urllib.parse.unquote(route[len("/download/"):])
        # 防目录穿越：仅允许当前目录内、纯文件名、.docx 结尾
        if not fname or "/" in fname or "\\" in fname or ".." in fname:
            self.send_error(403, "Forbidden")
            return
        full = os.path.normpath(os.path.join(self.root, fname))
        if not full.startswith(os.path.abspath(self.root)) or not full.lower().endswith(".docx"):
            self.send_error(403, "Forbidden")
            return
        if not os.path.isfile(full):
            self.send_error(404, "Not Found")
            return
        try:
            with open(full, "rb") as f:
                data = f.read()
        except OSError:
            self.send_error(404, "Not Found")
            return
        # 下载文件名优先用论文标题（RFC 5987 编码），ASCII 兜底
        title = (_Handler.payload.get("title") or "").strip()
        disp = f'attachment; filename="{fname}"'
        if title:
            disp += f"; filename*=UTF-8''{urllib.parse.quote(title + '.docx')}"
        self.send_response(200)
        self.send_header(
            "Content-Type",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
        self.send_header("Content-Disposition", disp)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        _touch()
        if self.path.split("?", 1)[0] != "/export":
            self.send_error(404, "Not Found")
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            payload = json.loads(raw.decode("utf-8") or "{}")
        except Exception as e:
            self._send_json({"error": f"请求体解析失败：{e}"}, status=400)
            return
        # 优先用请求里的元信息，否则用服务端持有的（来自 preview_payload.json）
        content_json = payload.get("contentJson") or _Handler.payload.get("contentJson")
        meta = {
            "type": payload.get("type") or _Handler.payload.get("type") or "1",
            "title": payload.get("title") or _Handler.payload.get("title") or "",
            "abstracts": payload.get("abstracts") or _Handler.payload.get("abstracts") or "",
            "keywords": payload.get("keywords") or _Handler.payload.get("keywords") or "",
            "authors": payload.get("authors") or _Handler.payload.get("authors") or "",
        }
        if not isinstance(content_json, list):
            self._send_json({"error": "缺少 contentJson"}, status=400)
            return
        try:
            dl_url, injected, warning = _download_and_augment(
                _Handler.base_url, _Handler.token, content_json, _Handler.root, meta
            )
            self._send_json({"url": dl_url, "injected": injected, "warning": warning})
        except Exception as e:
            self._send_json({"error": str(e)}, status=502)

    def log_message(self, fmt, *args):
        pass


def _shutdown_server(server):
    """幂等关闭：停 serve_forever 循环 → 关监听套接字（这一步才真正释放端口）。

    两件事都不可省：只 shutdown() 只是让 serve_forever 退出，监听 socket 仍开着，
    端口不会释放；只 server_close() 则 serve_forever 线程还在跑。可重复调用。
    """
    try:
        server.shutdown()
    except Exception:
        pass
    try:
        server.server_close()
    except Exception:
        pass


def _watchdog(server, idle_timeout, interval):
    """空闲看门狗：到点**置停止位**并唤醒主循环，由 serve() 的 finally 统一关闭。

    ⚠️ 历史坑（勿回退）：旧实现到点只 `server.shutdown()` 就 return，没有
    `_stop_event.set()`。结果 serve_forever 停了、地址失效了，但主循环
    `while not _stop_event.is_set()` 一直在等一个永不到来的事件 —— 进程不退出、
    监听 socket 不关闭、端口不释放，反复「重开预览」只会越堆越多僵尸进程。
    所以这里到点必须 set() 停止位（wait 会立即被唤醒，主循环随即进入 finally）。
    """
    while not _stop_event.is_set():
        if _idle_seconds() >= idle_timeout:
            print(f"[预览服务] 空闲 {int(idle_timeout)}s 无请求，自动关闭并释放端口",
                  file=sys.stderr)
            _stop_event.set()
            return
        _stop_event.wait(interval)


def serve(html_path, payload_path, token, base_url, port=0, url_file=None,
          host="127.0.0.1", idle_timeout=None, watchdog_interval=None):
    """启动预览服务并阻塞至空闲超时/中断；返回实际监听端口（失败返回 None）。

    退出契约（重要）：本函数**保证**返回前关闭 serve_forever 循环并释放监听端口，
    唯一关闭出口是下方的 finally —— 调用方拿到返回值即意味着进程可以正常退出、
    端口已释放。idle_timeout / watchdog_interval 传 None 时取模块默认值。
    """
    idle_timeout = _IDLE_TIMEOUT if idle_timeout is None else float(idle_timeout)
    watchdog_interval = (_WATCHDOG_INTERVAL if watchdog_interval is None
                         else float(watchdog_interval))
    root = os.path.abspath(os.path.dirname(html_path))
    _Handler.root = root
    _Handler._html_name = os.path.basename(html_path)
    _Handler.base_url = base_url
    _Handler.token = token
    try:
        with open(payload_path, "r", encoding="utf-8") as f:
            _Handler.payload = json.load(f)
    except Exception as e:
        print(f"[WARN] 读取预览负载失败：{e}（/export 将要求请求自带 contentJson）",
              file=sys.stderr)
        _Handler.payload = {"type": "1", "contentJson": []}

    _stop_event.clear()
    _touch()
    server = http.server.ThreadingHTTPServer((host, port), _Handler)
    actual_port = server.server_address[1]
    # 预览页固定在根路径「/」提供，避免中文文件名导致浏览器/自探测客户端
    # 路由匹配失败（percent-encode 问题）。用户拿到的地址干净且无乱码。
    ready_url = f"http://{host}:{actual_port}/"

    # 自探测就绪：后台 serve_forever 后 self-probe 确认 200，再写 url 文件/打印端口
    # （探测走直连、不经代理，见 _local_opener 注释）
    threading.Thread(target=server.serve_forever, daemon=True).start()
    probe = _local_opener()
    ok = False
    for _ in range(50):
        time.sleep(0.1)
        try:
            with probe.open(ready_url, timeout=2) as r:
                if r.status == 200:
                    ok = True
                    break
        except Exception:
            pass
    if not ok:
        print("[ERROR] 本地预览服务启动自探测失败", file=sys.stderr)
        _stop_event.set()
        _shutdown_server(server)      # 自探测失败也必须释放端口，否则同样残留
        return None

    # 写入 url 文件（agent 读取用），同时打印端口行
    if url_file:
        try:
            with open(url_file, "w", encoding="utf-8") as f:
                f.write(ready_url + "\n")
        except Exception:
            pass
    print(f"[预览服务] 已启动：{ready_url}（空闲 {int(idle_timeout)}s 无请求将自动关闭）",
          file=sys.stderr)

    wd = threading.Thread(target=_watchdog,
                          args=(server, idle_timeout, watchdog_interval),
                          daemon=True)
    wd.start()
    try:
        while not _stop_event.is_set():
            _stop_event.wait(watchdog_interval)
    except KeyboardInterrupt:
        pass
    finally:
        # 唯一关闭出口：无论空闲自毁、Ctrl-C 还是异常，都走这里释放端口
        _stop_event.set()
        _shutdown_server(server)
    return actual_port


def main():
    p = argparse.ArgumentParser(description="论文本地预览服务")
    p.add_argument("--html", required=True, help="富媒体 HTML 预览文件路径")
    p.add_argument("--payload", required=True, help="preview_payload.json（论文元信息+contentJson）")
    p.add_argument("--token", default="", help="登录 token（服务端持有，不进浏览器）；缺省从 config.json 读")
    p.add_argument("--base-url", default="", help="露禾 base_url；缺省从 config.json 读")
    p.add_argument("--port", type=int, default=0, help="监听端口（0=自动分配空闲端口）")
    p.add_argument("--host", default="127.0.0.1", help="监听地址（默认 127.0.0.1）")
    p.add_argument("--url-file", default="", help="把预览地址写入此文件，供调用方读取")
    p.add_argument("--idle-timeout", type=float, default=None,
                   help=f"空闲多少秒无请求后自动关闭并释放端口（默认 {int(_IDLE_TIMEOUT)}；"
                        f"判定精度为看门狗轮询间隔 {int(_WATCHDOG_INTERVAL)} 秒）")
    args = p.parse_args()

    if not args.base_url or not args.token:
        cfg = _load_cfg()
        args.base_url = args.base_url or cfg.get("base_url", "")
        args.token = args.token or cfg.get("token", "")
    if not args.base_url:
        print("[错误] 未配置平台地址：请在 config.json 填写 base_url（参考 config.example.json），"
              "或用 --base-url 显式指定", file=sys.stderr)
        return
    serve(args.html, args.payload, args.token, args.base_url,
          port=args.port, url_file=args.url_file, host=args.host,
          idle_timeout=args.idle_timeout)


def _load_cfg():
    """按优先级读 config.json：$LUHE_CONFIG > 数据目录 > skill 根目录。失败返回 {}。"""
    env_path = (os.environ.get("LUHE_CONFIG") or "").strip()
    candidates = ([os.path.expanduser(env_path)] if env_path else []) + [
        os.path.join(os.path.abspath(os.getcwd()), "paper-writer-data", "config.json"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json"),
    ]
    for path in candidates:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            continue
    return {}


if __name__ == "__main__":
    main()
