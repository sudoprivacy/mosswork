#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信扫码登录（Skill 专用）
--------------------------------------------------
负责：① 取微信二维码（含 ticket） ② 把二维码内容渲染成 PNG 图片
      ③ 轮询登录结果 ④ 登录成功后把凭证写入 config.json

接口（均挂在 base_url 上）：
  GET  /server-user/wechat/mp/mp-qrcode        → data.{ticket, url, expireSeconds}
  POST /server-user/skill/user/login  {ticket} → 未扫码时 data=null；扫码后 data 携带凭证

用法:
  # ① 日常：取码 + 渲染二维码 + 轮询登录（推荐后台跑，轮询状态文件）
  python login.py \
    --qr-image "<工作空间>/paper-writer-data/outputs/login_qr.png" \
    --status-file "<工作空间>/paper-writer-data/login_status.json"
  （config 默认优先读 <工作空间>/paper-writer-data/config.json，无则回退 skill 根目录；
    登录成功后凭证自动落位数据目录，skill 升级不丢）

  # ② 只出码不等待（先给用户扫码，稍后再轮询）
  python login.py --no-wait

  # ③ 拿着已有 ticket 单独轮询
  python login.py --ticket "<ticket>" --timeout 300

状态文件字段（供 agent 读取）:
  status        waiting_scan | ok | expired | timeout | failed
  ticket        二维码票据
  qr_url        二维码内容地址（http://weixin.qq.com/...）
  qr_image      本地二维码 PNG 路径（渲染成功时）
  expire_seconds 二维码有效期（秒）
  token_len     登录成功后写入的凭证长度（不落明文）
  error         失败原因
"""

import argparse
import json
import os
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime

#: 站点识别登录态的请求头名称（微信扫码登录凭证）
AUTH_HEADER_NAME = "edu-big-data-server-user-skill"

#: 统一 User-Agent（不带可能被网关拦截）
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
)

#: 二维码接口与登录接口路径
QRCODE_PATH = "/server-user/wechat/mp/mp-qrcode"
LOGIN_PATH = "/server-user/skill/user/login"

#: 登录态判定：接口返回这些说明票据已作废
EXPIRED_HINTS = ("过期", "失效", "expire", "expired", "invalid", "不存在")


# ---------------------------------------------------------------- 基础工具

def now_ts():
    return datetime.now().strftime("%H:%M:%S")


def log(msg, raw_log=None):
    line = f"[{now_ts()}] {msg}"
    print(line, flush=True)
    if raw_log:
        try:
            with open(raw_log, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass


def resolve_data_dir():
    """定位用户产出根目录（用户工作空间）。

    优先级：环境变量 LUHE_PAPER_DATA_DIR > 当前运行目录(cwd)/paper-writer-data。
    """
    env = (os.environ.get("LUHE_PAPER_DATA_DIR") or "").strip()
    if env:
        return os.path.expanduser(env)
    return os.path.join(os.path.abspath(os.getcwd()), "paper-writer-data")


def resolve_config_path(cli_path=""):
    """按优先级定位 config.json：--config > $LUHE_CONFIG > 用户数据目录 > skill 根目录。

    数据目录（用户工作空间）优先：凭证所在文件，升级/重装 skill 不丢；
    skill 根目录 config.json 仅作出厂默认与回退（打包时会被清理）。
    """
    if cli_path:
        return cli_path
    env_path = (os.environ.get("LUHE_CONFIG") or "").strip()
    if env_path:
        return os.path.expanduser(env_path)
    data_cfg = os.path.join(resolve_data_dir(), "config.json")
    if os.path.exists(data_cfg):
        return data_cfg
    skill_cfg = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")
    if os.path.exists(skill_cfg):
        return skill_cfg
    return skill_cfg


def skill_config_path():
    """skill 根目录 config.json（全局配置，所有工作会话共用）。"""
    return os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")


def resolve_credential_config(cfg_path=""):
    """确定**凭证写入**的目标配置文件：统一落在全局配置（skill 根目录 config.json）。

    ⚠️ 落点口径（2026-09-11 修正，勿改回「写入用户工作空间」）：
    凭证需要在**本机所有会话间共用**，而用户工作空间是**每次会话新建一个目录**
    （如 WorkBuddy 的 <时间戳> 目录）。把凭证写进工作空间，等于只写在其中一个目录里：
    新开会话的工作空间读不到 → 用户被迫反复扫码。故凭证落点固定为全局配置。

    - 显式指定（--config / $LUHE_CONFIG，且不在数据目录内）→ 原样返回，尊重用户自选落点
    - 兼容历史：工作空间 paper-writer-data/config.json 已存在凭证 → 继续沿用（老用户不掉登录）
    - 其余情况 → skill 根目录 config.json（**不再向工作空间复制副本**）
    """
    data_cfg = os.path.join(resolve_data_dir(), "config.json")
    skill_cfg = skill_config_path()
    if cfg_path:
        p = os.path.abspath(cfg_path)
        if p not in (os.path.abspath(data_cfg), os.path.abspath(skill_cfg)):
            return cfg_path
    env_path = (os.environ.get("LUHE_CONFIG") or "").strip()
    if env_path:
        return os.path.expanduser(env_path)
    if os.path.exists(data_cfg):          # 兼容历史落点
        return data_cfg
    return skill_cfg


def load_config(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}
    except Exception as e:
        log(f"[WARN] 读取 config.json 失败: {e}")
        return {}


def save_config(path, cfg):
    cfg["updated_at"] = datetime.now().isoformat(timespec="seconds")
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def save_status(state, status_file):
    state["updated_at"] = datetime.now().isoformat(timespec="seconds")
    try:
        os.makedirs(os.path.dirname(status_file) or ".", exist_ok=True)
        with open(status_file, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"[WARN] 写状态文件失败: {e}")


def http_json(url, method="GET", body=None, headers=None, timeout=20):
    h = {"Content-Type": "application/json", "User-Agent": USER_AGENT}
    if headers:
        h.update(headers)
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8", "replace")
    try:
        return json.loads(raw)
    except Exception:
        return {"_raw": raw}


# ---------------------------------------------------------------- 登录流程

def fetch_qrcode(base_url):
    """取微信二维码。返回 dict：{ticket, url, expire_seconds}。"""
    url = base_url.rstrip("/") + QRCODE_PATH
    result = http_json(url, method="GET", timeout=20)
    if result.get("code") != 200:
        raise RuntimeError(f"获取二维码失败: code={result.get('code')} msg={result.get('message')}")
    data = result.get("data") or {}
    ticket = data.get("ticket") or ""
    qr_url = data.get("url") or ""
    if not ticket:
        raise RuntimeError("获取二维码失败：接口未返回 ticket")
    try:
        expire = int(data.get("expireSeconds") or 300)
    except Exception:
        expire = 300
    return {"ticket": ticket, "url": qr_url, "expire_seconds": expire}


def login_with_ticket(base_url, ticket):
    """用 ticket 换登录凭证。

    返回 (ok: bool, data, message: str)：
      - 未扫码：接口 code=200 且 data 为空 → (False, None, "")
      - 已扫码：data 携带凭证 → (True, data, "")
      - 票据作废 / 报错：→ (False, None, message)
    """
    if not ticket:
        return (False, None, "ticket 不能为空")
    url = base_url.rstrip("/") + LOGIN_PATH
    try:
        result = http_json(url, method="POST", body={"ticket": ticket}, timeout=20)
    except Exception as e:
        return (False, None, f"登录请求异常: {e}")
    code = result.get("code")
    message = str(result.get("message") or "")
    data = result.get("data")
    if code != 200:
        return (False, None, message or f"登录失败 code={code}")
    if data in (None, "", {}, []):
        return (False, None, "")  # 尚未扫码
    return (True, data, "")


def extract_token(data):
    """从登录返回里取凭证字符串（兼容多种返回结构）。

    优先取常见凭证字段；data 本身是字符串时直接返回；支持一层嵌套（user / data / userInfo）。
    """
    if isinstance(data, str):
        return data.strip()
    if not isinstance(data, dict):
        return ""
    keys = ("token", "accessToken", "access_token", "userToken", "tokenValue",
            "permanent", "permanentCode", "idToken", "sessionId", "sessionKey",
            AUTH_HEADER_NAME)
    for k in keys:
        v = data.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    for k in ("user", "data", "userInfo", "loginInfo", "result", "tokenInfo"):
        sub = data.get(k)
        if isinstance(sub, (dict, str)):
            t = extract_token(sub)
            if t:
                return t
    return ""


def make_qr_image(content, qr_image, required=True):
    """把二维码内容渲染成 PNG。成功返回路径。

    required=True（默认）时渲染失败直接抛 RuntimeError——二维码原始链接严禁
    输出到对话（会被宿主拦截并错配跳转），因此「退化成给链接」不是合法降级；
    调用方必须先确保 segno 可用（隔离 venv 已预装），或捕获后硬失败并提示安装。
    required=False 仅用于离线测试桩。
    """
    try:
        import segno
    except ImportError as e:
        if required:
            raise RuntimeError(
                "二维码渲染依赖 segno 未安装。严禁把二维码链接输出给用户——"
                "请先在隔离环境执行 pip install segno 再重试登录"
            ) from e
        return ""
    try:
        os.makedirs(os.path.dirname(qr_image) or ".", exist_ok=True)
        segno.make(content, error="m").save(qr_image, scale=8, border=4)
        return qr_image
    except Exception as e:
        if required:
            raise RuntimeError(f"生成二维码图片失败: {e}（不得以链接形式交付二维码）") from e
        log(f"[WARN] 生成二维码图片失败: {e}")
        return ""


def poll_login(base_url, ticket, timeout=300, interval=3, status_file=None, state=None,
               cfg_path="", raw_log=None):
    """轮询登录结果。成功则写 config 并返回 (True, state)。"""
    state = state if state is not None else {}
    deadline = time.time() + max(10, int(timeout))
    waited = 0
    while time.time() < deadline:
        ok, data, message = login_with_ticket(base_url, ticket)
        if ok:
            token = extract_token(data)
            if not token:
                state["status"] = "failed"
                state["error"] = "登录成功但未取到凭证字段（请把接口返回结构反馈给平台）"
                state["raw_login_data"] = data if isinstance(data, (dict, str)) else str(data)
                save_status(state, status_file)
                log(state["error"], raw_log)
                return (False, state)
            cfg_path = resolve_credential_config(cfg_path or resolve_config_path(""))
            cfg = load_config(cfg_path)
            cfg["token"] = token
            cfg["token_source"] = "wechat_mp_qr"
            cfg["onboarded"] = True
            cfg["user"] = data if isinstance(data, dict) else {"raw": data}
            save_config(cfg_path, cfg)
            state["status"] = "ok"
            state["token_len"] = len(token)
            state["error"] = None
            save_status(state, status_file)
            log(f"登录成功，凭证已写入 config（长度 {len(token)}）", raw_log)
            return (True, state)
        if message:
            low = message.lower()
            if any(h in low for h in EXPIRED_HINTS) or any(h in message for h in EXPIRED_HINTS):
                state["status"] = "expired"
                state["error"] = f"二维码已失效：{message}"
                save_status(state, status_file)
                log(state["error"], raw_log)
                return (False, state)
            log(f"[提示] {message}", raw_log)
        time.sleep(interval)
        waited += interval
    state["status"] = "timeout"
    state["error"] = f"等待扫码超时（{timeout}s），请重新获取二维码"
    save_status(state, status_file)
    log(state["error"], raw_log)
    return (False, state)


def ensure_logged_in(base_url, cfg_path, qr_image="", status_file="", timeout=300, interval=3):
    """取微信二维码并轮询登录；成功返回 token 字符串，失败返回 None。

    供 generate.py 等「按需登录」流程复用：把二维码图片写入 qr_image、
    把登录状态写入 status_file（含 qr_image 路径，供 agent/用户展示扫码）。
    阻塞式：会一直轮询直到扫码成功或超时（需人工用微信扫二维码）。

    timeout=0 特例（供 generate.py 的「出码即退出」模式使用）：
    只取码渲染图片、写 waiting_scan 状态后立即返回 None，不进入轮询——
    避免后台生成任务在用户看不到二维码的情况下无限阻塞等待。
    """
    cfg_path = resolve_credential_config(cfg_path or resolve_config_path(""))
    state = {
        "status": "processing", "ticket": None, "qr_url": None,
        "qr_image": None, "expire_seconds": None, "token_len": None, "error": None,
    }
    try:
        qr = fetch_qrcode(base_url)
    except Exception as e:
        state["status"] = "failed"
        state["error"] = f"获取二维码失败: {e}"
        if status_file:
            save_status(state, status_file)
        log(state["error"])
        return None

    state["ticket"] = qr["ticket"]
    state["qr_url"] = qr["url"]
    state["expire_seconds"] = qr["expire_seconds"]
    img = make_qr_image(qr["url"] or qr["ticket"], qr_image)
    if img:
        state["qr_image"] = img
        log(f"二维码已生成: {img}（请用微信扫一扫）")

    if int(timeout) <= 0:
        # 出码即退出：写 waiting_scan 状态后立即返回，等待上层引导用户扫码
        state["status"] = "waiting_scan"
        if status_file:
            save_status(state, status_file)
        return None

    if status_file:
        save_status(state, status_file)

    wait = min(int(timeout), int(qr["expire_seconds"] or timeout)) or int(timeout)
    ok, st = poll_login(
        base_url, qr["ticket"], timeout=wait, interval=interval,
        status_file=status_file, state=state, cfg_path=cfg_path,
    )
    if ok:
        cfg = load_config(cfg_path)
        return cfg.get("token", "")
    return None


def main():
    _data_dir = resolve_data_dir()
    p = argparse.ArgumentParser(description="微信扫码登录（Skill 专用）")
    p.add_argument("--config", default="",
                   help="config.json 路径（默认优先用户数据目录 paper-writer-data/，回退 skill 根目录）")
    p.add_argument("--base-url", default="", help="平台地址（默认取 config.json 的 base_url）")
    p.add_argument("--qr-image", default=os.path.join(_data_dir, "outputs", "login_qr.png"),
                   help="二维码 PNG 输出路径")
    p.add_argument("--status-file", default=os.path.join(_data_dir, "login_status.json"))
    p.add_argument("--raw-log", default=os.path.join(_data_dir, "login_raw.log"))
    p.add_argument("--ticket", default="", help="已有 ticket，直接轮询登录（不再取新码）")
    p.add_argument("--timeout", type=int, default=300, help="等待扫码的最长秒数（默认 300）")
    p.add_argument("--interval", type=int, default=3, help="轮询间隔秒数（默认 3）")
    p.add_argument("--no-wait", action="store_true", help="只出二维码不等待扫码")
    args = p.parse_args()

    cfg_path = resolve_config_path(args.config)
    cfg = load_config(cfg_path)
    base_url = args.base_url or cfg.get("base_url") or ""
    if not base_url:
        print("[错误] 未配置平台地址：请在 config.json 填写 base_url（参考 config.example.json），"
              "或用 --base-url 显式指定", file=sys.stderr)
        sys.exit(2)

    state = {
        "status": "processing", "ticket": None, "qr_url": None,
        "qr_image": None, "expire_seconds": None, "token_len": None, "error": None,
    }

    try:
        if args.ticket:
            state["ticket"] = args.ticket
        else:
            qr = fetch_qrcode(base_url)
            state["ticket"] = qr["ticket"]
            state["qr_url"] = qr["url"]
            state["expire_seconds"] = qr["expire_seconds"]
            img = make_qr_image(qr["url"] or qr["ticket"], args.qr_image)
            if img:
                state["qr_image"] = img
                log(f"二维码已生成: {img}")
            if args.timeout > qr["expire_seconds"]:
                args.timeout = qr["expire_seconds"]

        if args.no_wait:
            state["status"] = "waiting_scan"
            save_status(state, args.status_file)
            log(f"等待扫码（ticket 有效期 {state['expire_seconds']}s）")
            return

        if not state.get("ticket"):
            state["status"] = "failed"
            state["error"] = "缺少 ticket（既未取到新码也未传入 --ticket）"
            save_status(state, args.status_file)
            log(state["error"])
            sys.exit(1)

        state["status"] = "waiting_scan"
        save_status(state, args.status_file)
        ok, state = poll_login(
            base_url, state["ticket"], timeout=args.timeout, interval=args.interval,
            status_file=args.status_file, state=state,
            cfg_path=resolve_credential_config(cfg_path), raw_log=args.raw_log,
        )
        sys.exit(0 if ok else 1)
    except SystemExit:
        raise
    except Exception as e:
        state["status"] = "failed"
        state["error"] = str(e)
        save_status(state, args.status_file)
        log(f"[错误] {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
