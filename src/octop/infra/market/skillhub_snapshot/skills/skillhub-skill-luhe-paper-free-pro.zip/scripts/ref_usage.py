# -*- coding: utf-8 -*-
"""自定义参考文献引用采纳检测（agent 静默调用，输出不直接给用户）。

用法（在用户工作空间运行）：
    python ref_usage.py --html paper-writer-data/outputs/论文_xxx.html \
                        --refs paper-writer-data/ref_selected.json

功能：统计「用户挑选的文献（user_selected:true）」中有几篇被正文实际标引。

检测兼容两种正文标引写法：
  (A) 旧写法：正文直接保留 [file_id] / [id]（文献列表未注入时）；
  (B) 新写法：文献注入后正文被重编号为 [1]..[15]，参考文献段为 [1] 条目…[15] 条目。
      此时按「用户文献标题 → 参考文献段落里的序号 N」映射，再统计正文（参考文献段之前）
      出现的 [N] 次数，避免与参考文献列表自身的 [N] 前缀重复计数。

输出 JSON：
    {
      "user_total": 5,
      "cited_total": 2,
      "cited":  [{"title":..., "count":3}, ...],
      "uncited": [{"title":...}, ...]
    }

注意：检测完全离线（只读 html 与 refs JSON），不调接口、不扣费。
"""
import argparse
import html as html_mod
import json
import os
import re
import sys


def html_plain_text(path):
    raw = open(path, encoding="utf-8").read()
    text = re.sub(r"<[^>]+>", " ", raw)
    return html_mod.unescape(text)


def count_in_body(text, ident):
    """统计「正文（参考文献段之前）」里 [ident] 标注出现次数。

    用参考文献段作为分界，避免把文末参考文献列表自身的 [N] 前缀算进引用次数。
    """
    if not ident:
        return 0
    token = "[%s]" % str(ident).strip()
    # 以「参考文献」标题切分，只统计之前的部分
    idx = text.rfind("参考文献")
    body = text[:idx] if idx >= 0 else text
    return body.count(token)


def extract_ref_entries(text):
    """从正文纯文本抽取参考文献条目 -> {N: entry_text}（按 [N] 顺序拆分）。"""
    idx = text.rfind("参考文献")
    sec = text[idx:] if idx >= 0 else text
    entries = {}
    for m in re.finditer(r"\[(\d+)\][ \t]*([\s\S]*?)(?=\n*[\[（]?\d+[\]）]|\Z)", sec):
        n = int(m.group(1))
        entries[n] = m.group(2).strip()
    # 兜底：若上面的负向预查没切干净，用更宽松的 [N] 切分
    if not entries:
        for m in re.finditer(r"\[(\d+)\][ \t]*([\s\S]*?)(?=\[(\d+)\]|\Z)", sec):
            n = int(m.group(1))
            entries[n] = m.group(2).strip()
    return entries


def main():
    p = argparse.ArgumentParser(description="检测用户所选文献在生成正文中的实际引用情况")
    p.add_argument("--html", required=True, help="生成的论文 HTML 路径")
    p.add_argument("--refs", required=True, help="reference_search.py --select 写出的文献对象数组 JSON")
    p.add_argument("-o", "--output", default="", help="结果 JSON 输出路径（可选，默认只打印）")
    args = p.parse_args()

    if not os.path.exists(args.html):
        print("[ref_usage] 找不到 HTML：%s" % args.html, file=sys.stderr)
        return 1
    if not os.path.exists(args.refs):
        print("[ref_usage] 找不到文献 JSON：%s" % args.refs, file=sys.stderr)
        return 1

    refs = json.load(open(args.refs, encoding="utf-8"))
    text = html_plain_text(args.html)
    ref_entries = extract_ref_entries(text)

    user_refs = [r for r in refs if r.get("user_selected")]
    # 无 user_selected 标记时全部视为用户所选
    if not user_refs:
        user_refs = list(refs)

    cited, uncited = [], []
    for r in user_refs:
        title = (r.get("title") or "").strip()
        ids = {str(r.get(k) or "").strip() for k in ("file_id", "id")}
        cnt = 0
        method = ""
        # (A) 旧写法：正文直接保留 [file_id] / [id]
        for i in ids:
            c = count_in_body(text, i)
            if c > cnt:
                cnt, method = c, "file_id"
        # (B) 新写法：按标题在参考文献段落定位序号 N，统计正文 [N]
        if cnt == 0 and title and ref_entries:
            for n, entry in ref_entries.items():
                if title and title in entry:
                    c = count_in_body(text, n)
                    if c > cnt:
                        cnt, method = c, "seq-%d" % n
                    break
        if cnt > 0:
            cited.append({"title": title, "count": cnt})
        else:
            uncited.append({"title": title})

    result = {
        "user_total": len(user_refs),
        "cited_total": len(cited),
        "cited": cited,
        "uncited": uncited,
    }
    out = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out)
        print("[ref_usage] 结果已写出 %s" % args.output, file=sys.stderr)
    print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
