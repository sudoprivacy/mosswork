#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自定义参考文献检索封装（论文 skill 侧）

从 config.json 读取 luhe 永久 token，作为 eduagent AdvanceSearch 的登录态 Cookie，
调用期刊高级检索，返回前 N 篇最符合要求的文献。

为何不直接用 advance_search.py：
  - advance_search.py 默认从环境变量 EDUAGENT_COOKIE 读凭据；本封装改为复用论文 skill
    的 luhe token（实测 luhe token 可直接作为 eduagent 的 Cookie 使用），避免让用户
    额外配置 eduagent_cookie，也避免把 token 透传到命令行（防泄露到日志/历史）。
  - 输出「编号列表」供 Agent 展示给用户挑选，并写出 JSON 候选文件（含 id 映射），
    用户回复编号时 Agent 可据此翻译为文献 id，最终传给一键成文的 referenceVip。

用法:
  # 按被引量倒序，近三年，前 20 篇
  python reference_search.py "人工智能" --sort by_ref_cnt --year-start 2023 --size 20

  # 输出 JSON 候选（含 id），并写出候选文件供后续挑选映射
  python reference_search.py "项目式学习" --sort relevance -o ref_candidates.json --json

  # 多关键词合并检索（选题辅助用）：竖线分隔多组检索词，按 id 去重合并、核心置顶
  python reference_search.py --queries "小学语文 项目式学习|项目式学习 语文教学" \
      --sort by_ref_cnt --year-start 2021 --size 20 -o topic_candidates.json --json
"""
import argparse
import json
import os
import re
import sys

# 把 journal_search 子目录加入路径，使 advance_search 内部的 `from common import` 能命中
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "journal_search"))
from advance_search import advance_search, normalize_sort, build_conditions  # noqa: E402
from common import map_journal_range, doc_is_core_indexed, rank_core_first, HIDDEN_RANGE_CODES  # noqa: E402


# 文献详情页固定格式（与 api-contract.md「参考文献引文」一节约定一致）
_DETAIL_URL_RE = re.compile(r"^https://luhe\.cqvip\.com/weResearch/literatureDetail/(\d+)/1$")


def build_detail_url(file_id):
    """按平台约定构造文献详情页链接（id 必须来自真实检索结果，禁止凭记忆手写）。"""
    return f"https://luhe.cqvip.com/weResearch/literatureDetail/{file_id}/1"


def validate_candidates(candidates, source="检索结果"):
    """防死链校验：每条候选必须有真实数字 id，且 detail_url 与 id 严格一致。

    返回 (ok, problems)；发现问题的条目直接剔除并告警——手写/凭记忆拼 id
    会产生死链，此函数是脚本级兜底（不依赖 agent 记得规则）。
    """
    problems, kept = [], []
    seen = set()
    for c in candidates:
        cid = str(c.get("id") or "").strip()
        if not cid or not cid.isdigit():
            problems.append(f"候选 #{c.get('index', '?')} 缺少真实数字 id（标题: {str(c.get('title', ''))[:20]}）")
            continue
        if cid in seen:
            problems.append(f"候选 #{c.get('index', '?')} id={cid} 重复，已去重")
            continue
        url = c.get("detail_url") or ""
        m = _DETAIL_URL_RE.match(url or "")
        if not m or m.group(1) != cid:
            # detail_url 缺失或与 id 不一致 → 按约定格式重建（id 本身来自检索结果，可信）
            c["detail_url"] = build_detail_url(cid)
        seen.add(cid)
        kept.append(c)
    if problems:
        print(f"[防死链] {source}剔除/修正 {len(problems)} 条："
              + "；".join(problems), file=sys.stderr)
    return kept


def resolve_config_path(cli_path=""):
    """按优先级定位 config.json（与 generate.py 一致）：--config > LUHE_CONFIG > 数据目录 > skill 根目录。"""
    if cli_path:
        return cli_path
    env = os.environ.get("LUHE_CONFIG", "").strip()
    if env:
        return os.path.expanduser(env)
    env_dir = (os.environ.get("LUHE_PAPER_DATA_DIR") or "").strip()
    data_dir = os.path.expanduser(env_dir) if env_dir else os.path.join(
        os.path.abspath(os.getcwd()), "paper-writer-data")
    data_cfg = os.path.join(data_dir, "config.json")
    if os.path.exists(data_cfg):
        return data_cfg
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json")


def load_config(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def main():
    p = argparse.ArgumentParser(description="自定义参考文献检索（eduagent AdvanceSearch，复用 luhe token）")
    p.add_argument("query", nargs="?", default="", help="检索词（默认字段 U=题名）；--select 抽取模式下可省略")
    p.add_argument("--queries", default="",
                   help="多组检索词（竖线分隔，如 '小学语文 项目式学习|项目式学习 语文教学'），"
                        "逐组检索后按 id 去重合并、核心置顶重排（选题辅助用）")
    p.add_argument("--field", default="U",
                   help="字段码：U 题名/K 关键词/A 作者/J 刊名/S 单位/C 分类号/O 文摘/R 基金")
    p.add_argument("--year-start", type=int, default=None, help="起始年份")
    p.add_argument("--year-end", type=int, default=None, help="结束年份")
    p.add_argument("--sort", default="",
                   help="排序：relevance/'' 相关度倒序 | by_ref_cnt/cited 被引量倒序 | pub_date/time 时间倒序")
    p.add_argument("--size", type=int, default=20, help="返回条数（默认 20）")
    p.add_argument("--no-core-first", action="store_true",
                   help="关闭「核心文献(北大/南大核心)置顶」重排（默认开启）")
    p.add_argument("--config", default="", help="config.json 路径（默认自动定位 skill 根目录）")
    p.add_argument("--json", action="store_true", help="以 JSON 输出完整候选（含 id）")
    p.add_argument("-o", "--output", default=None, help="候选 JSON 写出路径（含 id 映射，供 Agent 挑选）")
    # 按编号抽取所选文献对象（用于生成时作为 reference-vip 的内容）
    p.add_argument("--candidates", default="", help="已有候选 JSON 路径（配合 --select 抽取所选文献对象）")
    p.add_argument("--select", default="", help="从候选 JSON 中按编号抽取，逗号分隔如 1,3,5；写出为文献对象数组")
    p.add_argument("--fill-to", type=int, default=0,
                   help="（配合 --select）按候选相关度顺序补足至 N 篇：用户所选在前、补充在后。"
                        "平台规则：自定义参考文献不足 15 篇时系统会拼接检索结果、用户所选可能不被采用，"
                        "建议 --fill-to 15 完全掌控引用池")
    args = p.parse_args()

    # 非抽取模式必须有检索词（query 或 --queries）
    if not args.select and not args.query and not args.queries:
        print("[错误] 未指定检索词 query / --queries，且未使用 --select 抽取模式", file=sys.stderr)
        return 2

    # ---- 抽取模式：从已有候选文件按编号选出文献对象数组 ----
    if args.select:
        cand_path = args.candidates
        if not cand_path:
            print("[错误] --select 需配合 --candidates 指定候选 JSON 路径", file=sys.stderr)
            return 2
        if not os.path.exists(cand_path):
            print(f"[错误] 候选文件不存在: {cand_path}", file=sys.stderr)
            return 2
        with open(cand_path, "r", encoding="utf-8") as f:
            all_cands = json.load(f)
        # 防死链校验：抽取前先剔除无真实 id / 链接与 id 不一致的候选
        all_cands = validate_candidates(all_cands, source=f"候选文件 {cand_path} ")
        idxs = set()
        for part in args.select.split(","):
            part = part.strip()
            if "-" in part:  # 范围格式，如 1-15 / 2-6
                a, _, b = part.partition("-")
                if a.isdigit() and b.isdigit():
                    for n in range(int(a), int(b) + 1):
                        idxs.add(n)
            elif part.isdigit():
                idxs.add(int(part))
        if not idxs:
            print(f"[错误] 编号格式无法解析: {args.select}（示例: 1,3,5 或 1-15 或 1-3,5）", file=sys.stderr)
            return 2
        selected = [c for c in all_cands if c.get("index") in idxs]
        if not selected:
            print(f"[错误] 编号 {args.select} 未匹配到任何候选", file=sys.stderr)
            return 2
        # 去掉内部 UI 编号 index，输出「完整文献对象数组」作为 referenceVip 的内容。
        # 对象 = ① AdvanceSearch 原始条目全量字段(raw，含 abstr/authorInfo/journalInfo/
        # beginPage/endPage/doi/vol/num 等平台契约字段) ② 显式 file_id 别名（数字 id，
        # 与平台文献引擎 file_id 同格式） ③ 拍平的展示辅助字段（title/authors/journal/...）。
        def build_ref_obj(c):
            raw = c.get("raw") or {}
            obj = dict(raw)                       # 完整原始条目（契约字段权威来源）
            obj["file_id"] = str(raw.get("id") or c.get("id") or "")   # 显式提供 file_id
            for k in ("title", "authors", "journal", "year", "cited",
                      "journal_range", "is_core", "core_flag",
                      "journal_range_label", "detail_url"):
                if k in c and k not in obj:
                    obj[k] = c[k]
            return obj

        selected = [c for c in all_cands if c.get("index") in idxs]
        objs = [build_ref_obj(c) for c in selected]

        # 补足模式：平台规则「自定义文献 <15 篇会拼接系统检索结果」，用户所选可能被挤出。
        # 按候选相关度顺序（候选文件即按检索排序）补足到 fill_to 篇，用户所选保持在前。
        filled = 0
        if args.fill_to > 0 and len(objs) < args.fill_to:
            have = set(c.get("index") for c in selected)
            fill_objs = [build_ref_obj(c) for c in all_cands
                         if c.get("index") not in have]
            need = args.fill_to - len(objs)
            took = fill_objs[:need]
            for o in took:
                o["user_selected"] = False       # 标记：非用户选择，系统补足
            objs.extend(took)
            filled = len(took)
            if len(objs) < args.fill_to:
                print(f"[警告] 候选池仅 {len(all_cands)} 篇，无法补足至 {args.fill_to} 篇"
                      f"（当前 {len(objs)} 篇，仍可能触发平台拼接）；建议加大 --size 重新检索",
                      file=sys.stderr)
        for i, o in enumerate(objs):
            o.setdefault("user_selected", True)
            o["ref_order"] = i + 1               # 平台「合并参考文献id」按 NO 顺序注入

        out = args.output or os.path.join(os.path.dirname(os.path.abspath(cand_path)), "ref_selected.json")
        os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            json.dump(objs, f, ensure_ascii=False, indent=2)
        if filled:
            print(f"[selected] 已写出 {len(objs)} 篇文献对象到 {out}"
                  f"（用户所选 {len(selected)} 篇在前 + 按相关度补足 {filled} 篇）",
                  file=sys.stderr)
        else:
            print(f"[selected] 已写出 {len(objs)} 篇所选文献对象到 {out}", file=sys.stderr)
        return 0

    cfg = load_config(resolve_config_path(args.config)) or {}
    token = cfg.get("token", "")
    if not token:
        # 免费体验环节（未绑定）：检索接口本身免登录，匿名模式仍可返回候选。
        print("[提示] 未读取到 token，以匿名模式检索（免费体验环节：选题 / 文献候选）", file=sys.stderr)

    # 组装检索词列表：--queries 优先（多组），否则单 query
    query_list = [q.strip() for q in args.queries.split("|") if q.strip()] if args.queries else []
    if not query_list and args.query:
        query_list = [args.query]
    if not query_list:
        print("[错误] 未指定检索词 query / --queries", file=sys.stderr)
        return 2

    # 核心置顶时放大抓取池（≥100），确保核心论文只要存在就能被捞起并浮到顶部
    # （核心论文常被相关度排序压到后排，池太小捞不到）
    fetch_size = args.size if args.no_core_first else max(args.size, 100)

    merged = []
    seen_ids = set()
    try:
        for q in query_list:
            conditions = build_conditions(q, args.field, False, None)
            result = advance_search(
                conditions,
                year_start=args.year_start,
                year_end=args.year_end,
                sort=normalize_sort(args.sort),
                size=fetch_size,
                types=[1],  # 仅期刊，符合论文参考文献场景
                cookie=token,  # 复用 luhe token 作为 eduagent 登录态 Cookie
                query_label=q,
            )
            for d in result.documents:
                if d.id in seen_ids:
                    continue
                seen_ids.add(d.id)
                merged.append(d)
    except ValueError as exc:
        print(f"[参数错误] {exc}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"[检索失败] {exc}", file=sys.stderr)
        return 2

    if not merged:
        print("未检索到相关文献，请调整关键词或放宽时间范围。")
        return 0

    # 核心文献（北大核心/南大核心）置顶重排，便于优先推荐
    docs = merged
    if not args.no_core_first:
        docs = rank_core_first(docs)
    docs = docs[:args.size]  # 重排后取前 N 篇展示

    # 构造候选（编号 + 关键信息 + 完整原始条目）
    # ⚠️ raw 必须保留：生成时 referenceVip 需携带平台契约的完整文献对象
    # （file_id/abstr/authorInfo/journalInfo/beginPage/endPage/doi/vol/num 等），
    # 只传拍平后的摘要字段会导致后端无法识别、自定义参考文献不生效。
    candidates = []
    for i, d in enumerate(docs, 1):
        candidates.append({
            "index": i,
            "id": d.id,
            "title": d.title,
            "authors": d.authors,
            "journal": d.journal,
            "year": d.year,
            "cited": d.cited,
            "journal_range": [c for c in d.journal_range
                              if str(c).strip().upper() not in HIDDEN_RANGE_CODES],
            "is_core": d.is_core,
            "core_flag": doc_is_core_indexed(d),
            "journal_range_label": map_journal_range(d.journal_range, d.is_core),
            "detail_url": d.detail_url,
            "raw": d.raw,  # AdvanceSearch 原始条目全量字段（文献对象契约的权威来源）
        })

    if args.json:
        print(json.dumps(candidates, ensure_ascii=False, indent=2))
    else:
        q_label = " | ".join(query_list)
        print(f"# 检索：{q_label}（合并后 {len(merged)} 篇，展示前 {len(docs)} 篇）")
        print("| # | 标题 | 作者 | 出处 | 年份 | 被引 | 收录 | 核心 |")
        print("|---|------|------|------|------|------|------|------|")
        for c in candidates:
            cited = c["cited"] if c["cited"] is not None else "—"
            year = c["year"] or "—"
            jr = c["journal_range_label"] or "—"
            core = "⭐" if c["core_flag"] else "—"
            title = c["title"].replace("|", "/")
            print(f"| {c['index']} | {title} | {c['authors']} | {c['journal']} | {year} | {cited} | {jr} | {core} |")

    if args.output:
        out_dir = os.path.dirname(os.path.abspath(args.output))
        os.makedirs(out_dir, exist_ok=True)
        # 写盘前再过一次防死链校验（detail_url 与 id 一致；不一致按约定格式重建）
        candidates = validate_candidates(candidates, source="候选写出 ")
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(candidates, f, ensure_ascii=False, indent=2)
        print(f"[候选] 已写出候选映射（已过防死链校验）：{args.output}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
