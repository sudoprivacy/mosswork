#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
论文 Word 导出模块（与生成链路解耦）。

职责：
1. 调平台 POST /server-agent/writing/paper/export/direct 拿 docx OSS 直链（免 paperId）
2. 下载 docx → 落地本地
3. 完整性核验（verify_output_integrity）：docx/HTML 是否完整承载 contentJson 的正文与参考文献
4. 标引一致性（validate_citations）：正文引用集合 == 参考文献列表集合
5. 缺失章节兜底修复（repair_docx_missing_sections）

参考文献处理：生成链路已把参考文献逐条写入 contentJson「参考文献」节点的 children，
导出接口据此渲染文末文献列表，本模块不再对 docx 做任何本地注入。

运行模式：
A. 由 generate.py 在 SSE 流结束后自动调用（默认）
B. 离线：直接对 status.json 中已抓到的论文状态再走一遍导出
   python export.py --state <state.json> --output-dir ./outputs

依赖：仅调露禾 HTTP 接口需要 generate.py 内的少量工具
（log / save_status / build_auth_headers / build_references_items /
_extract_cited_file_ids / USER_AGENT），通过 _gen() 懒加载，避免与 generate.py 互相 import。
"""

import argparse
import base64
import json
import os
import re
import sys
import urllib.error
import urllib.request
import zipfile
from datetime import datetime


# ---------------------------------------------------------------------------
# 模块常量
# ---------------------------------------------------------------------------

#: 导出 Word 接口路径（免 paperId）
EXPORT_PATH = "/server-agent/writing/paper/export/direct"

#: 导出文件名命名模板：论文_<title12>_<YYYYmmdd_HHMM>.docx
_MAX_TITLE_LEN_FOR_NAME = 12


# ---------------------------------------------------------------------------
# 跨模块访问（避免循环 import）
# ---------------------------------------------------------------------------

def _gen():
    """延迟加载 generate 模块，仅在用到其工具函数时调用。

    处理两种入口：
    - 由 generate.py 通过 `from export import ...` 加载本模块，运行时再访问
      generate.tools。`import generate` 会按磁盘文件作为独立模块加载（与 __main__
      分开实例），函数/常量等值是相同的。
    - 直接 `python scripts/export.py` 启动：此时 generate 不在 sys.modules，
      按磁盘文件首次加载。
    """
    cached = sys.modules.get("_luhe_generate_proxy")
    if cached is not None:
        return cached
    here = os.path.dirname(os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)
    import generate as _g
    sys.modules["_luhe_generate_proxy"] = _g
    return _g


# ---------------------------------------------------------------------------
# docx 零依赖读取工具（zipfile + XML 字符串操作）
#
# 仅用于「完整度核验」读取段落文本，不再对 docx 做任何写入 / 注入。
# ---------------------------------------------------------------------------

_PARA_RE_G = re.compile(r"<w:p[ >].*?</w:p>|<w:p [^>]*/>", re.S)


def _docx_xml(path):
    with zipfile.ZipFile(path) as z:
        return z.read("word/document.xml").decode("utf-8")


def _docx_paras(xml):
    """返回 [(match, 纯文本)]，match 供后续按位置切片。"""
    return [(m, re.sub(r"<[^>]+>", "", m.group(0)).strip())
            for m in _PARA_RE_G.finditer(xml)]


def _log(msg, raw_log):
    """本模块自用日志器，避免对 generate.py log 的依赖。"""
    g = _gen()
    return g.log(msg, raw_log)


def _save_status(state, status_file):
    g = _gen()
    return g.save_status(state, status_file)


# （参考文献不再本地注入 docx。）
# 生成链路已把参考文献逐条写入 contentJson「参考文献」节点的 children，
# 导出接口（/export/direct）据此渲染文末文献列表。本模块只做核验与修复，不做写入。


# ---------------------------------------------------------------------------
# 完整度 / 修复用到的工具（章节树展平 + 跨格式指纹比对）
# ---------------------------------------------------------------------------

def _flatten_tree_nodes(nodes, out=None):
    if out is None:
        out = []
    if isinstance(nodes, list):
        for nd in nodes:
            if isinstance(nd, dict):
                out.append(nd)
                _flatten_tree_nodes(nd.get("children"), out)
    return out


def _plain(s):
    """去标签、去空白，用于跨格式（tree / docx / html）比对指纹。"""
    s = re.sub(r"<[^>]+>", "", str(s or ""))
    return re.sub(r"[\s\u3000]+", "", s)


def _docx_paragraph_texts(path):
    """读 docx 段落文本列表。零依赖优先，python-docx 兜底；都失败返回 None。"""
    if not path or not os.path.exists(path):
        return None
    try:
        return [t for _m, t in _docx_paras(_docx_xml(path))]
    except Exception:
        pass
    try:
        from docx import Document
    except Exception:
        return None
    try:
        return [p.text for p in Document(path).paragraphs]
    except Exception:
        return None


def _docx_rich_counts(path):
    """统计 docx 内富媒体数量（tables / omml / images），用于下载前后比对。

    返回 dict；依赖缺失或读取失败返回 None。"""
    try:
        from docx import Document
    except Exception:
        return None
    try:
        doc = Document(path)
        tables = len(doc.tables)
        omml = 0
        images = 0
        try:
            with zipfile.ZipFile(path) as zf:
                for nm in zf.namelist():
                    if nm.startswith("word/") and nm.endswith(".xml"):
                        try:
                            xml = zf.read(nm).decode("utf-8", "ignore")
                        except Exception:
                            continue
                        omml += xml.count("<m:oMath")
                        images += xml.count("<a:blip")
        except Exception:
            pass
        return {"tables": tables, "omml": omml, "images": images}
    except Exception:
        return None


def _rich_degraded(before, after):
    """比对前后富媒体数量，任一维度减少即视为退化（内容丢失）。"""
    if not before or not after:
        return False
    return (after["tables"] < before["tables"]
            or after["omml"] < before["omml"]
            or after["images"] < before["images"])


def _html_plain_text(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            s = f.read()
    except Exception:
        return None
    s = re.sub(r"<script.*?</script>", "", s, flags=re.S | re.I)
    s = re.sub(r"<style.*?</style>", "", s, flags=re.S | re.I)
    return re.sub(r"<[^>]+>", "", s)


# ---------------------------------------------------------------------------
# 完整性校验 + 标引校验
# ---------------------------------------------------------------------------

def verify_output_integrity(state, raw_log=None, target_words=0):
    """核对 docx / HTML 是否完整承载了 SSE 流里抓到的正文与参考文献。

    风险：平台 export 按 contentJson 渲染，大纲被截断 / 标题对不上时整章正文可能
    只剩标题，交付前必须拦一道。

    返回 report dict（同时写入 state['integrity']），字段：
      ok / issues / missing_sections / docx_chars / tree_chars /
      html_chars / ref_expected / ref_in_docx / target_words
    """
    g = _gen()
    report = {
        "ok": True, "issues": [], "missing_sections": [],
        "tree_chars": 0, "docx_chars": 0, "html_chars": 0,
        "ref_expected": 0, "ref_in_docx": 0, "target_words": target_words,
    }
    nodes = _flatten_tree_nodes(state.get("content"))
    body_nodes = [nd for nd in nodes
                  if (nd.get("content") or "").strip()
                  and "参考文献" not in str(nd.get("title", ""))]
    report["tree_chars"] = sum(len(_plain(nd.get("content"))) for nd in body_nodes)

    refs = g.build_references_items(state.get("_references_raw", ""),
                                    state.get("_references_gbstr") or {})
    report["ref_expected"] = len(refs)

    paras = _docx_paragraph_texts(state.get("docx_path"))
    if paras is None:
        report["issues"].append("无法读取 docx 正文（python-docx 缺失或文件损坏），跳过完整度核对")
        report["ok"] = False
    else:
        docx_plain = _plain("\n".join(paras))
        report["docx_chars"] = len(docx_plain)
        report["ref_in_docx"] = sum(
            1 for t in paras if re.match(r"^\s*\[\d+\]", t or ""))
        for nd in body_nodes:
            probe = _plain(nd.get("content"))[:24]
            if probe and probe not in docx_plain:
                report["missing_sections"].append(str(nd.get("title") or "")[:40])
        if report["missing_sections"]:
            report["issues"].append(
                f"docx 缺失 {len(report['missing_sections'])} 个章节的正文：{report['missing_sections']}")
        if report["ref_expected"] and report["ref_in_docx"] < report["ref_expected"]:
            report["issues"].append(
                f"docx 参考文献只有 {report['ref_in_docx']} 条，应为 {report['ref_expected']} 条")
        # 兜底防线：docx 参考文献 0 条但正文有引用 → 文献列表丢失。
        if report["ref_in_docx"] == 0:
            _has_cite = bool(g._extract_cited_file_ids(state.get("content"))) \
                or bool(state.get("_user_references"))
            if _has_cite:
                report["issues"].append(
                    "docx 参考文献为 0 条，但正文确有引用标注/用户传入了文献，文献列表缺失（建议重新生成）")

    if state.get("html_path"):
        htxt = _html_plain_text(state["html_path"])
        if htxt is not None:
            hp = _plain(htxt)
            report["html_chars"] = len(hp)
            miss_h = [str(nd.get("title") or "")[:40] for nd in body_nodes
                      if _plain(nd.get("content"))[:24]
                      and _plain(nd.get("content"))[:24] not in hp]
            if miss_h:
                report["issues"].append(f"HTML 缺失章节正文：{miss_h}")

    report["ok"] = not report["issues"]
    if raw_log:
        if report["ok"]:
            _log(f"[完整度] 通过：正文 {report['tree_chars']} 字全部落入 docx，"
                 f"参考文献 {report['ref_in_docx']}/{report['ref_expected']} 条", raw_log)
        else:
            _log("[完整度] 告警：" + "；".join(report["issues"]), raw_log)
    state["integrity"] = report
    return report


def validate_citations(state, raw_log=None):
    """标引一致性校验：正文引用编号集合 == 参考文献列表编号集合。

    返回 (ok, issues)；错位时写 raw_log 告警。"""
    g = _gen()
    issues = []
    refs = g.build_references_items(state.get("_references_raw", ""),
                                    state.get("_references_gbstr") or {})
    ref_nums = {it["n"] for it in refs}
    body = json.dumps(state.get("content", ""), ensure_ascii=False)
    cites = set(int(x) for x in re.findall(r"\[(\d+)\]", body) if x.isdigit())
    missing = cites - ref_nums
    orphan = ref_nums - cites
    if missing:
        issues.append(f"正文引用编号 {sorted(missing)} 在参考文献列表中无对应项")
    if orphan:
        issues.append(f"参考文献 {sorted(orphan)} 未被正文引用")
    ok = not issues
    if raw_log:
        if ok:
            _log("[标引校验] 通过：正文引用与文献列表一一对应", raw_log)
        else:
            _log("[标引校验] 告警：" + "；".join(issues), raw_log)
    return ok, issues


# ---------------------------------------------------------------------------
# 缺失章节兜底修复（python-docx）
# ---------------------------------------------------------------------------

def _find_title_stub(doc, full_title):
    """在 docx 里找被平台截断的半截标题段落（其归一化文本是完整标题的前缀）。

    找到后由调用方补全文本，避免补章节时产生重复标题。"""
    target = _gen()._norm_title(full_title)
    if not target:
        return None
    for p in doc.paragraphs:
        t = (p.text or "").strip()
        nt = _gen()._norm_title(t)
        if not nt or nt == target:
            continue
        if len(nt) >= 2 and len(t) <= 40 and target.startswith(nt):
            return p
    return None


def _set_paragraph_text(paragraph, text):
    """把段落文本整体替换为 text（保留段落样式与首个 run 的字符格式）。"""
    runs = paragraph.runs
    if runs:
        runs[0].text = text
        for r in runs[1:]:
            r.text = ""
    else:
        paragraph.add_run(text)
    return paragraph


def _insert_paragraph_after_ref(anchor, text, style=None):
    """在 anchor 段落之前插入新段落（用于把缺失章节补到「参考文献」之前）。"""
    from docx.oxml import OxmlElement
    from docx.text.paragraph import Paragraph
    new_p = OxmlElement("w:p")
    anchor._p.addprevious(new_p)
    para = Paragraph(new_p, anchor._parent)
    if text:
        para.add_run(text)
    if style is not None:
        try:
            para.style = style
        except Exception:
            pass
    return para


def _insert_paragraph_after(paragraph, text, style=None):
    """在 paragraph 之后插入一个新段落（章节修复时逐段补回正文用；与参考文献注入无关）。"""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    from docx.text.paragraph import Paragraph
    new_p = OxmlElement("w:p")
    paragraph._p.addnext(new_p)
    new_para = Paragraph(new_p, paragraph._parent)
    if text:
        new_para.add_run(text)
    if style is not None:
        try:
            new_para.style = style
        except Exception:
            pass
    return new_para


def repair_docx_missing_sections(docx_path, state, report, raw_log=None):
    """把完整度检查发现的「docx 缺失章节」用本地 python-docx 补回去。

    插入位置：若存在「参考文献」标题则插在其前，否则追加到文末；
    多个缺失章节按章节树原顺序补齐。返回补回的章节数。"""
    if not docx_path or not report or not report.get("missing_sections"):
        return 0
    try:
        from docx import Document
    except Exception:
        return 0
    try:
        doc = Document(docx_path)
        missing = set(report["missing_sections"])
        nodes = [nd for nd in _flatten_tree_nodes(state.get("content"))
                 if str(nd.get("title") or "")[:40] in missing]
        if not nodes:
            return 0
        anchor = None
        for p in doc.paragraphs:
            if "参考文献" in (p.text or "") and len(_plain(p.text)) <= 8:
                anchor = p
                break
        heading_style = body_style = None
        for p in doc.paragraphs:
            nm = str(p.style.name).lower() if p.style is not None else ""
            if heading_style is None and nm.startswith("heading"):
                heading_style = p.style
            if body_style is None and (p.text or "").strip() and not nm.startswith("heading"):
                body_style = p.style

        def _emit(text, style):
            if anchor is not None:
                return _insert_paragraph_after_ref(anchor, text, style)
            p = doc.add_paragraph(text)
            if style is not None:
                try:
                    p.style = style
                except Exception:
                    pass
            return p

        for nd in nodes:
            title = str(nd.get("title") or "").strip()
            body = re.sub(r"<[^>]+>", "", str(nd.get("content") or "")).strip()
            segs = [s for s in body.split("\n") if s.strip()]
            stub = _find_title_stub(doc, title)
            if stub is not None:
                _set_paragraph_text(stub, title)
                after = stub
                for seg in segs:
                    after = _insert_paragraph_after(after, seg, body_style)
                continue
            _emit(title, heading_style)
            for seg in segs:
                _emit(seg, body_style)
        doc.save(docx_path)
        _log(f"[修复] 已把 {len(nodes)} 个缺失章节补回 docx："
             f"{[str(n.get('title'))[:20] for n in nodes]}", raw_log)
        return len(nodes)
    except Exception as e:
        _log(f"[WARN] 补齐 docx 缺失章节失败：{e}", raw_log)
        return 0


# ---------------------------------------------------------------------------
# 主入口：导出 + 落盘 + 后置校验 / 修复
# ---------------------------------------------------------------------------

def _as_int_code(v):
    """业务码转 int（无法转换时返回 0，不参与登录判定）。"""
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def export_and_download(base_url, token, state, status_file, raw_log, output_dir):
    """导出 Word 完整流程。

    1) POST /server-agent/writing/paper/export/direct 拿 docx OSS 直链
       （参考文献随 contentJson「参考文献」节点 children 一并提交，由平台渲染）
    2) 下载 docx 到本地并写入 preview_payload.json / last_preview.json
    3) 标引一致性校验
    4) 完整性核验
    5) HTML 预览（调 generate.render_html_preview 完成）
    6) last_preview.json 记录本服务的入口与参数
    """
    g = _gen()
    export_url = base_url.rstrip("/") + EXPORT_PATH
    payload = {
        "type": state.get("type") or "1",
        "title": state.get("title") or "",
        "abstracts": state.get("_abstract") or "",
        "keywords": state.get("_keywords") or "",
        "authors": state.get("_authors") or "",
        "contentJson": state["content"] if isinstance(state["content"], list) else [],
    }
    headers = {"Content-Type": "application/json", "User-Agent": g.USER_AGENT}
    headers.update(g.build_auth_headers(token, base_url))
    req = urllib.request.Request(export_url, data=json.dumps(payload).encode(),
                                 headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        _log(f"export 返回: {json.dumps(result, ensure_ascii=False)[:400]}", raw_log)
        if result.get("code") == 200:
            docx_url = result.get("data")
            if docx_url:
                os.makedirs(output_dir, exist_ok=True)
                try:
                    req_d = urllib.request.Request(docx_url,
                                                  headers={"User-Agent": g.USER_AGENT})
                    with urllib.request.urlopen(req_d, timeout=120) as dresp:
                        docx_bytes = dresp.read()
                except Exception as e:
                    state["status"] = "failed"
                    state["error"] = f"docx 下载失败: {e}（直链: {docx_url}）"
                    _log(state["error"], raw_log)
                else:
                    # 参考文献由导出接口按 contentJson「参考文献」节点 children 渲染，不再本地注入 docx。
                    state["docx_b64"] = base64.b64encode(docx_bytes).decode("ascii")
                    safe_title = (state.get("title") or "论文")[:_MAX_TITLE_LEN_FOR_NAME] \
                        .replace(" ", "_").replace("/", "_")
                    date_str = datetime.now().strftime("%Y%m%d_%H%M")
                    state["docx_name"] = f"论文_{safe_title}_{date_str}.docx"
                    try:
                        docx_path = os.path.join(output_dir, state["docx_name"])
                        with open(docx_path, "wb") as df:
                            df.write(docx_bytes)
                        state["docx_path"] = docx_path
                        _log(f"docx 已落盘: {docx_path}（{len(docx_bytes)} 字节）", raw_log)
                    except Exception as e:
                        _log(f"[WARN] docx 落盘失败（不影响预览内嵌，仅影响本地文件交付）: {e}", raw_log)
                    state["status"] = "succeeded"
                    state["stage"] = "论文已生成，预览可下载 Word"
                    state["progress"] = 100
                    state["error"] = None
                    _log(f"docx 已从平台导出并内嵌预览（{len(docx_bytes)} 字节）", raw_log)
                    html_path = os.path.join(output_dir, state["docx_name"][:-5] + ".html")
                    validate_citations(state, raw_log)
                    verify_output_integrity(
                        state, raw_log,
                        target_words=state.get("_target_words") or 0)
                    _log(f"[框架完整性] 标题{'✓' if state.get('title') else '✗'} "
                         f"摘要{'✓' if state.get('_abstract') else '✗'} "
                         f"关键词{'✓' if state.get('_keywords') else '✗'} "
                         f"参考文献{len(g.build_references_items(state.get('_references_raw',''), state.get('_references_gbstr') or {}))}条",
                         raw_log)
                    if g.render_html_preview(state, html_path):
                        state["html_path"] = html_path
                    try:
                        pl = {
                            "type": state.get("type") or "1",
                            "title": state.get("title") or "",
                            "abstracts": state.get("_abstract", "") or "",
                            "keywords": state.get("_keywords", "") or "",
                            "authors": state.get("_authors", "") or "",
                            "contentJson": state.get("content") if isinstance(state.get("content"), list) else [],
                        }
                        payload_path = os.path.join(output_dir, "preview_payload.json")
                        with open(payload_path, "w", encoding="utf-8") as pf:
                            json.dump(pl, pf, ensure_ascii=False, indent=2)
                        state["preview_payload"] = payload_path
                        _log(f"预览负载已写出: {payload_path}", raw_log)
                        try:
                            lp = {
                                "html": html_path,
                                "payload": payload_path,
                                "docx": "",
                                "title": state.get("title") or "",
                                "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            }
                            lp_path = os.path.join(output_dir, "last_preview.json")
                            with open(lp_path, "w", encoding="utf-8") as lf:
                                json.dump(lp, lf, ensure_ascii=False, indent=2)
                            _log(f"预览入口已记录: {lp_path}", raw_log)
                        except Exception as e:
                            _log(f"[WARN] 预览入口记录失败：{e}", raw_log)
                    except Exception as e:
                        _log(f"[WARN] 预览负载写出失败：{e}", raw_log)
            else:
                state["status"] = "failed"
                state["error"] = "export 返回 data 为空（contentJson 可能不完整，需人工导出）"
                _log(state["error"], raw_log)
        else:
            _biz_msg = str(result.get("msg") or result.get("message") or "").strip()
            if g.is_login_required(_as_int_code(result.get("code")), _biz_msg):
                # 业务码明确要求登录（如 401 免费额度用完）→ 需重新扫码，原因透传
                state["status"] = "need_login"
                state["need_login_reason"] = _biz_msg or "导出 Word 时平台要求登录后继续"
            else:
                state["status"] = "failed"
            state["error"] = f"export 失败: code={result.get('code')} msg={result.get('msg') or result.get('message')}"
            _log(state["error"], raw_log)
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:500]
        # 导出接口返回 401/403/505 = 凭证失效，需重新扫码；必须携带后端原始提示透传给用户
        backend_msg = ""
        try:
            _obj = json.loads(detail)
            if isinstance(_obj, dict):
                backend_msg = str(_obj.get("message") or _obj.get("msg") or "").strip()
        except Exception:
            pass
        if e.code in (401, 403, 505) or g.is_login_required(0, backend_msg):
            state["status"] = "need_login"
            state["need_login_reason"] = backend_msg or f"导出 Word 时凭证已失效（HTTP {e.code}），需重新扫码登录"
        else:
            state["status"] = "failed"
        state["error"] = f"export HTTP {e.code}: {detail}"
        _log(state["error"], raw_log)
    except Exception as e:
        state["status"] = "failed"
        state["error"] = f"export 请求异常: {e}"
        _log(state["error"], raw_log)
    _save_status(state, status_file)


# ---------------------------------------------------------------------------
# CLI：单独运行（对已抓到的 state.json 走一遍导出 / 完整度 / 修复）
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description="论文 Word 导出（独立运行模式）")
    ap.add_argument("--state", required=True, help="status.json 路径（必须含 content/title/_abstract 等字段）")
    ap.add_argument("--base-url", default="", help="平台地址；不传则从 config.json 读取")
    ap.add_argument("--token", default="")
    ap.add_argument("--output-dir", default="")
    ap.add_argument("--status-file", default="")
    ap.add_argument("--raw-log", default="")
    ap.add_argument("--mode", choices=["full", "verify_only", "repair"], default="full",
                    help="full=导出+校验+HTML；verify_only=仅校验已有 docx；repair=校验后兜底修复")
    args = ap.parse_args()

    if not args.base_url or not args.token:
        g = _gen()
        cfg = g.load_config(g.resolve_config_path("")) or {}
        args.base_url = args.base_url or cfg.get("base_url", "")
        args.token = args.token or cfg.get("token", "")
    if not args.base_url:
        print("[错误] 未配置平台地址：请在 config.json 填写 base_url（参考 config.example.json），"
              "或用 --base-url 显式指定", file=sys.stderr)
        sys.exit(2)

    with open(args.state, "r", encoding="utf-8") as f:
        state = json.load(f)
    output_dir = args.output_dir or os.path.join(os.path.dirname(os.path.abspath(args.state)), "outputs")
    status_file = args.status_file or args.state
    raw_log = args.raw_log or os.path.join(os.path.dirname(os.path.abspath(args.state)), "sse_raw.log")

    if args.mode == "verify_only":
        rep = verify_output_integrity(state, raw_log, target_words=state.get("_target_words") or 0)
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return

    if args.mode == "repair":
        rep = verify_output_integrity(state, raw_log, target_words=state.get("_target_words") or 0)
        if rep.get("missing_sections"):
            n = repair_docx_missing_sections(state.get("docx_path"), state, rep, raw_log)
            print(f"[修复] 已补章节 {n} 个")
        else:
            print("[修复] 无缺失章节，跳过")
        return

    export_and_download(args.base_url, args.token, state,
                        status_file, raw_log, output_dir)
    print(f"[done] status={state.get('status')} docx={state.get('docx_path')} "
          f"html={state.get('html_path')}")


if __name__ == "__main__":
    main()
