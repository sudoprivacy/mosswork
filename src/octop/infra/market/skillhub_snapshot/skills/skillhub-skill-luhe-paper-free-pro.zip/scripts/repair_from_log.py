#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从已抓取的 SSE 原始日志离线重建成品（不重新生成、不再扣费）。

用途：一次生成已经完成、但因平台大纲截断 / 标题对不上导致 docx 丢章节或缺参考文献时，
用 sse_raw.log 里已经拿到的正文与文献，重新调用导出接口生成完整 docx + HTML。
参考文献由生成链路写入 contentJson「参考文献」节点 children，导出接口据此渲染，
本工具不再对 docx 做本地注入。

  python repair_from_log.py --raw-log ../sse_raw.log --config ../config.json [--src-docx <原docx目录推算输出>]
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import generate as G


def collect_from_log(path):
    """从 SSE 原始日志还原 outline / 正文流 / 参考文献原始串。"""
    outline, answers, ref_raw, title, abstract, keywords, paper_id = None, [], "", "", "", "", None
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for ln in f:
            ln = ln.rstrip("\n")
            if not ln.startswith("data:"):
                continue
            try:
                p = json.loads(ln[5:].strip())
            except Exception:
                continue
            if not isinstance(p, dict):
                continue
            if p.get("name") == "生成正文":
                r = p.get("response")
                if isinstance(r, list):
                    for el in r:
                        if isinstance(el, dict) and isinstance(el.get("answer"), str):
                            answers.append(el["answer"])
                elif isinstance(r, str):
                    answers.append(r)
            if p.get("name") == "合并参考文献id":
                r = p.get("response")
                if isinstance(r, str) and r.strip():
                    ref_raw = r
            if p.get("abstract"):
                abstract = p["abstract"]
            if p.get("keywords"):
                keywords = p["keywords"]
            if "outlineTree" in p and isinstance(p["outlineTree"], dict):
                ch = p["outlineTree"].get("children")
                if isinstance(ch, list) and ch:
                    outline = ch
                if p["outlineTree"].get("title"):
                    title = p["outlineTree"]["title"]
            for k in ("paperId", "paper_id"):
                if p.get(k):
                    paper_id = p[k]
    return outline, answers, ref_raw, title, abstract, keywords, paper_id


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-log", required=True)
    ap.add_argument("--src-docx", default="",
                    help="（可选）以其所在目录作为修复后 docx 的输出目录")
    ap.add_argument("--config", default="")
    ap.add_argument("--target-words", type=int, default=0)
    args = ap.parse_args()

    cfg = G.load_config(G.resolve_config_path(args.config)) or {}
    token = cfg.get("token", "")
    lit_host = cfg.get("lit_host") or cfg.get("base_url") or ""
    if not lit_host:
        print("[WARN] config.json 未配置 base_url/lit_host，引文串拉取将跳过（降级本地格式化）")

    outline, answers, ref_raw, title, abstract, keywords, paper_id = collect_from_log(args.raw_log)
    if not outline or not answers:
        print("[FAIL] 日志里没有可用的大纲或正文流")
        return 1

    secs = G.parse_body_sections(answers)
    rep = {}
    content = G.merge_body_into_outline(outline, secs, rep)
    print(f"[合并] {rep['matched']}/{rep['sections_total']} 章匹配大纲，追加 {len(rep['appended'])} 章")

    state = {
        "content": content, "title": title, "paper_id": paper_id,
        "_references_raw": ref_raw, "_abstract": abstract, "_keywords": keywords,
        "_references_gbstr": {}, "docx_path": None, "html_path": None,
    }

    # 参考文献：拉引文串 → 正文标注重编号 → 写入「参考文献」节点 children（随 contentJson 一并导出）
    ref_text = ""
    if ref_raw:
        file_ids = [str(r.get("file_id") or "") for r in G._load_ref_list(ref_raw) if r.get("file_id")]
        gbstr = G.fetch_references_batch(lit_host, token, file_ids) if file_ids else {}
        state["_references_gbstr"] = gbstr or {}
        print(f"[文献] 取到引文 {len(gbstr or {})}/{len(file_ids)} 篇")
        ref_text, fmap = G.build_references(ref_raw, gbstr or {})
        if fmap:
            def remap(ns):
                for nd in ns:
                    if isinstance(nd, dict):
                        if nd.get("content"):
                            nd["content"] = G.remap_citations(nd["content"], fmap)
                        if isinstance(nd.get("children"), list):
                            remap(nd["children"])
            remap(state["content"])
        if ref_text:
            ref_entries = [ln.strip() for ln in ref_text.splitlines() if ln.strip()]
            def set_ref(ns):
                for nd in ns:
                    if isinstance(nd, dict):
                        if "参考文献" in str(nd.get("title", "")):
                            nd["content"] = ""
                            nd["children"] = [
                                {"title": "", "content": e, "children": []}
                                for e in ref_entries
                            ]
                            return True
                        if isinstance(nd.get("children"), list) and set_ref(nd["children"]):
                            return True
                return False
            if not set_ref(state["content"]):
                state["content"].append({
                    "title": "参考文献", "content": "",
                    "children": [{"title": "", "content": e, "children": []} for e in ref_entries],
                })
                print("[修复] 大纲缺少「参考文献」节点，已追加")

    # 参考文献已写入 content children，连同正文一并交由导出接口渲染，不再本地注入 docx。
    output_dir = os.path.dirname(os.path.abspath(args.src_docx)) if args.src_docx else os.path.dirname(os.path.abspath(args.raw_log))
    status_file = os.path.join(output_dir, "repair_state.json")
    G.export_and_download(lit_host, token, "", state, status_file, None, output_dir)
    out_docx = state.get("docx_path") or ""

    html_path = state.get("html_path") or ""
    if not html_path:
        html_path = os.path.splitext(out_docx)[0] + ".html"

    r = G.verify_output_integrity(state, None, args.target_words)
    if r.get("missing_sections"):
        G.repair_docx_missing_sections(out_docx, state, r, None)
        r = G.verify_output_integrity(state, None, args.target_words)

    print("\n=== 完整度报告 ===")
    print(f"正文字数(树)   : {r['tree_chars']}")
    print(f"docx 字数      : {r['docx_chars']}")
    print(f"参考文献       : docx {r['ref_in_docx']} / 应有 {r['ref_expected']}")
    print(f"缺失章节       : {r['missing_sections'] or '无'}")
    print(f"结论           : {'✅ 完整' if r['ok'] else '⚠ ' + '；'.join(r['issues'])}")
    print(f"\ndocx: {out_docx}\nhtml: {state.get('html_path')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
