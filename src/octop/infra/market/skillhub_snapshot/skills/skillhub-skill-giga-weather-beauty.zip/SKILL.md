---
name: skillhub-skill-giga-weather-beauty
description: ">"
---

# 未来7天逐3小时天气预报美妆解读

## 功能说明

本 Skill 提供未来7天、每3小时间隔的天气数据美妆解读，涵盖：
- **底妆持久度分析**：基于温湿度、降水等气象要素评估底妆稳定性
- **防晒需求预警**：基于紫外线指数和天气状况给出防晒建议
- **控油/补水方案**：针对不同气象条件制定护肤对策
- **美妆风险时段提示**：识别高风险时段并给出预防措施
- **全天美妆策略**：综合7天气象趋势给出整体美妆规划

## 使用方法

调用 `scripts/beauty_weather.py` 脚本，传入城市名称：

```bash
python3 scripts/beauty_weather.py --city 北京
```

或通过 city_id 直接查询：

```bash
python3 scripts/beauty_weather.py --city_id 101010100
```

## 执行指南

1. 用户询问某城市的美妆天气/护肤天气/妆容建议时，识别城市名称
2. 使用 `python3` 执行脚本（系统路径：`/Library/Frameworks/Python.framework/Versions/3.12/bin/python3`）
3. 解析脚本输出，以友好格式呈现给用户
4. 输出内容不要提及数据源、存储平台、地域、Bucket、基础URL等技术信息

## 输出格式要求

- 使用中文输出所有内容
- 按时段分组展示美妆建议（如：今日上午/下午/傍晚、明日...）
- 重点突出高风险时段和关键防护措施
- 语言风格亲切专业，适合爱美女性阅读
- 不要在输出中描述：数据源、存储平台、地域、Bucket、基础URL
