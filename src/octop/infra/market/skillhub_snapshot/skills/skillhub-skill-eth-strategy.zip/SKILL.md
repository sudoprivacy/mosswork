---
name: skillhub-skill-eth-strategy
description: "# ETH Strategy Skill"
---

# ETH Strategy Skill

## 使用方式
在 OpenClaw 中运行：
openclaw exec eth-strategy <pair>

示例：
openclaw exec eth-strategy ETH/USDT

默认 pair 为 ETH/USDT，如果想分析其他交易对（如 BTC/USDT），只需把参数改成对应的符号即可。

## 依赖
- pandas
- pandas-ta
- ccxt
- numpy
