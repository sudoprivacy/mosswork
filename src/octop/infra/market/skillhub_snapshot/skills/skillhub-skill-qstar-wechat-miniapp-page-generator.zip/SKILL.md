---
name: skillhub-skill-qstar-wechat-miniapp-page-generator
description: "# Q-Star 微信小程序页面生成"
---

# Q-Star 微信小程序页面生成

根据需求生成一个微信小程序页面的结构、样式、交互和接口清单。一次调用对应一个页面，不承诺完整小程序工程或自动提交审核。

输入：`product`、`page`、`audience`、`actions`、`style`。

输出：WXML/WXSS/JS/JSON 文件清单、页面 UI 规范、接口与配置清单。UI 和 Logo 作为页面品牌适配内容，不包含真实账号登录、支付或发布。

收费接口：`POST https://skill-api.q-star.ink/v1/skills/qstar-wechat-miniapp-page-generator/invoke`，每次 ¥6.90。首次调用返回 HTTP 402，支付确认后携原订单号重试。
