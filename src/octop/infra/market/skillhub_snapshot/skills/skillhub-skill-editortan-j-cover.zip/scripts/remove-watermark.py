"""
Remove the "图片由AI生成" watermark from ImageGen output.

Strategy:
1. Detect white/light-gray text pixels in the bottom-right region (where the watermark sits).
2. Build a binary mask of the watermark.
3. Use OpenCV inpainting (Telea) to fill in those pixels with surrounding texture.
4. Run inpainting a second time on any remaining bright spots to clean up edges.
5. Apply a small blur+sharpen pass in the masked area only to hide any residual seams.

Usage:
    python remove-watermark.py <input.png> <output.png>
                              [--bottom 0.10] [--right 0.30]
                              [--dilate 5] [--inpaint-radius 6]
                              [--v-threshold 175] [--s-threshold 75]
"""

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image


def detect_watermark_mask(img_bgr: np.ndarray,
                          bottom_frac: float,
                          right_frac: float,
                          v_threshold: int,
                          s_threshold: int) -> np.ndarray:
    """Return a uint8 mask (0/255) of pixels that look like the white watermark text.

    We restrict the search to the bottom-right rectangle and require pixels to be
    near-white AND low-saturation.
    """
    h, w = img_bgr.shape[:2]
    y0 = int(h * (1 - bottom_frac))
    x0 = int(w * (1 - right_frac))
    roi = img_bgr[y0:, x0:]

    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    v = hsv[..., 2]
    s = hsv[..., 1]

    bright = v > v_threshold
    low_sat = s < s_threshold
    not_pure_white = v < 255

    mask_roi = (bright & low_sat & not_pure_white).astype(np.uint8) * 255

    full = np.zeros((h, w), dtype=np.uint8)
    full[y0:, x0:] = mask_roi
    return full


def hard_watermark_rect_mask(img_bgr: np.ndarray,
                             bottom_frac: float = 0.06,
                             right_frac: float = 0.32,
                             left_frac: float = 0.55) -> np.ndarray:
    """Hard rectangular mask covering the entire ImageGen watermark zone.

    ImageGen always places '图片由AI生成' in the lower-right corner. The text is
    small but its anti-aliased pixels can be hard to catch with a single
    threshold. Masking the whole text band lets the inpainter fill it cleanly
    with surrounding texture.
    """
    h, w = img_bgr.shape[:2]
    y0 = int(h * (1 - bottom_frac))
    y1 = h
    x0 = int(w * left_frac)
    x1 = int(w * (1 - right_frac) + w * right_frac)  # right edge
    x1 = w
    full = np.zeros((h, w), dtype=np.uint8)
    full[y0:y1, x0:x1] = 255
    return full


def dilate_mask(mask: np.ndarray, ksize: int, iters: int) -> np.ndarray:
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ksize, ksize))
    return cv2.dilate(mask, kernel, iterations=iters)


def inpaint(img_bgr: np.ndarray, mask: np.ndarray, radius: int) -> np.ndarray:
    return cv2.inpaint(img_bgr, mask, inpaintRadius=radius, flags=cv2.INPAINT_TELEA)


def second_pass_remaining_bright(img_bgr: np.ndarray,
                                 search_region: np.ndarray,
                                 v_threshold: int,
                                 s_threshold: int) -> np.ndarray:
    """Within the search region, mask any pixel still bright+low-saturation and re-inpaint.

    Returns a fresh mask covering only the remaining watermark ghosts.
    """
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    v = hsv[..., 2]
    s = hsv[..., 1]
    bright = v > v_threshold
    low_sat = s < s_threshold
    candidate = (bright & low_sat).astype(np.uint8) * 255
    candidate = cv2.bitwise_and(candidate, search_region)
    return candidate


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--bottom", type=float, default=0.10)
    parser.add_argument("--right", type=float, default=0.30)
    parser.add_argument("--dilate", type=int, default=7)
    parser.add_argument("--inpaint-radius", type=int, default=8)
    parser.add_argument("--v-threshold", type=int, default=175)
    parser.add_argument("--s-threshold", type=int, default=75)
    parser.add_argument("--v-threshold2", type=int, default=160,
                        help="Lower threshold for second-pass ghost cleanup")
    args = parser.parse_args()

    if not args.input.is_file():
        print(f"Input not found: {args.input}", file=sys.stderr)
        return 1

    img_bgr = cv2.imread(str(args.input), cv2.IMREAD_COLOR)
    if img_bgr is None:
        print(f"Failed to read: {args.input}", file=sys.stderr)
        return 1
    h, w = img_bgr.shape[:2]
    print(f"Image: {w}x{h}")

    # Pass 1: precise (HSV-based) mask + Telea inpainting — catches the most obvious text.
    mask_precise = detect_watermark_mask(img_bgr, args.bottom, args.right,
                                         args.v_threshold, args.s_threshold)
    p_precise = int((mask_precise > 0).sum())
    print(f"Precise mask: {p_precise} px")

    # Pass 1b: hard rectangular mask covering the entire watermark band — guarantees
    # the text region is fully repainted, even when anti-aliased pixels slip past
    # the HSV threshold. This is the workhorse step.
    mask_rect = hard_watermark_rect_mask(img_bgr)
    p_rect = int((mask_rect > 0).sum())
    print(f"Rect mask: {p_rect} px ({p_rect / (h * w) * 100:.3f}%)")

    # Combine: union of both passes.
    mask_d = cv2.bitwise_or(mask_precise, mask_rect)
    mask_d = dilate_mask(mask_d, ksize=5, iters=1)
    p1 = int((mask_d > 0).sum())
    print(f"Combined pass-1 mask: {p1} px")

    if p1 == 0:
        cv2.imwrite(str(args.output), img_bgr)
        return 0

    result = inpaint(img_bgr, mask_d, radius=args.inpaint_radius)

    # Pass 2: detect remaining bright/low-sat pixels inside the search region and re-inpaint.
    y0 = int(h * (1 - args.bottom))
    x0 = int(w * (1 - args.right))
    search_region = np.zeros((h, w), dtype=np.uint8)
    search_region[y0:, x0:] = 255

    ghost = second_pass_remaining_bright(result, search_region,
                                          args.v_threshold2, args.s_threshold)
    # Only keep ghost pixels that overlap with the original watermark zone.
    ghost = cv2.bitwise_and(ghost, search_region)
    p2 = int((ghost > 0).sum())
    print(f"Pass-2 ghost mask: {p2} px")

    if p2 > 0:
        ghost_d = dilate_mask(ghost, ksize=5, iters=2)
        result = inpaint(result, ghost_d, radius=max(4, args.inpaint_radius - 2))

    # Local polish: slight blur+sharpen in the masked area only.
    blurred = cv2.GaussianBlur(result, (0, 0), sigmaX=0.8)
    sharp = cv2.addWeighted(result, 1.20, blurred, -0.20, 0)

    blur_mask_f = cv2.GaussianBlur(mask_d.astype(np.float32) / 255.0, (0, 0), sigmaX=2.0)
    blur_mask_3 = np.dstack([blur_mask_f] * 3)
    blend = (sharp * blur_mask_3 + result * (1 - blur_mask_3)).astype(np.uint8)

    # Extra: any remaining "ghost" pixel that's still brighter than its 7x7 local median
    # gets nudged toward the local median to hide the very last traces.
    hsv = cv2.cvtColor(blend, cv2.COLOR_BGR2HSV)
    v_ch_f = hsv[..., 2].astype(np.float32)
    s_ch = hsv[..., 1]
    local_med = cv2.medianBlur(hsv[..., 2], 7).astype(np.float32)
    ghost_v = (v_ch_f > local_med + 8) & (s_ch < 80)
    # Only consider ghost pixels in the search region.
    ghost_v &= (search_region > 0)
    ghost_v_u8 = (ghost_v.astype(np.uint8)) * 255
    if int(ghost_v_u8.sum()) > 0:
        # Smooth value channel toward local median in those pixels.
        alpha = 0.85
        v_ch_f[ghost_v] = (alpha * local_med[ghost_v] + (1 - alpha) * v_ch_f[ghost_v])
        hsv[..., 2] = np.clip(v_ch_f, 0, 255).astype(np.uint8)
        blend = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        print(f"Final ghost suppression: {int(ghost_v_u8.sum() / 255)} px")

    img_rgb = cv2.cvtColor(blend, cv2.COLOR_BGR2RGB)
    Image.fromarray(img_rgb).save(args.output, "PNG", optimize=True)
    print(f"Saved: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
