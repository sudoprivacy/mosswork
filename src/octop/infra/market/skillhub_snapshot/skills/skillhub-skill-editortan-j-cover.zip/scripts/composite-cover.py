#!/usr/bin/env python3
"""
composite-cover.py — Overlay a transparent journal title template onto a cover background.

Supports two template variants (light-background and dark-background) and automatically
selects the appropriate one based on the background brightness or an explicit user choice.
It can also replace the year/volume/issue text stamped in the template's white bar.

Usage:
  # Auto-select overlay based on background brightness
  python composite-cover.py background.png \
    --overlay-light jscnu-cover-overlay-light.png \
    --overlay-dark  jscnu-cover-overlay-dark.png \
    --output cover-mockup.png

  # Force a specific variant
  python composite-cover.py background.png \
    --overlay-light jscnu-cover-overlay-light.png \
    --overlay-dark  jscnu-cover-overlay-dark.png \
    --mode dark \
    --output cover-mockup.png

  # Replace the issue line (e.g. "2026年第58卷第1期")
  python composite-cover.py background.png \
    --overlay-light jscnu-cover-overlay-light.png \
    --overlay-dark  jscnu-cover-overlay-dark.png \
    --mode auto \
    --year 2026 --volume 58 --issue 1 \
    --output cover-mockup.png

  # Or provide the exact issue text
  python composite-cover.py background.png \
    --overlay-light jscnu-cover-overlay-light.png \
    --overlay-dark  jscnu-cover-overlay-dark.png \
    --issue-text "2026年第58卷第1期" \
    --output cover-mockup.png
"""

import argparse
import sys
from pathlib import Path

import numpy as np

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("ERROR: Pillow is not installed. Install with: pip install Pillow", file=sys.stderr)
    sys.exit(1)


def find_bar_region(overlay: Image.Image) -> tuple[int, int]:
    """Locate the year/volume/issue semi-transparent white bar in the overlay.

    The bar is a horizontally-wide, semi-transparent white/gray band (alpha ~20-100).
    We find it by scanning rows where a high percentage of pixels are light-coloured
    and semi-transparent.
    Returns (top_y, bottom_y) in overlay coordinates, or (0, 0) if not found.
    """
    arr = np.array(overlay.convert("RGBA"))
    h, w = arr.shape[:2]
    r, g, b, a = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2], arr[:, :, 3]

    # Semi-transparent light/white bar: light RGB and alpha in the 20-100 range.
    is_bar = (r > 180) & (g > 180) & (b > 180) & (a > 20) & (a < 110)

    row_frac = [is_bar[y].sum() / w for y in range(h)]

    start = end = 0
    in_bar = False
    for y, frac in enumerate(row_frac):
        if not in_bar and frac > 0.7:
            start = y
            in_bar = True
        elif in_bar and frac < 0.7:
            end = y
            break
    if in_bar and end == 0:
        end = h

    return start, end


def _find_system_font() -> str | None:
    """Return a reasonable Windows Chinese font path, or None if not found."""
    candidates = [
        r"C:\Windows\Fonts\msyh.ttc",       # Microsoft YaHei
        r"C:\Windows\Fonts\msyhbd.ttc",     # Microsoft YaHei Bold
        r"C:\Windows\Fonts\simhei.ttf",    # SimHei
        r"C:\Windows\Fonts\simsun.ttc",     # SimSun
    ]
    for path in candidates:
        if Path(path).is_file():
            return path
    return None


def _replace_bar_text(
    overlay: Image.Image,
    issue_text: str,
    font_path: str | None,
    text_color: tuple[int, int, int, int] | None = None,
) -> Image.Image:
    """Erase the existing year/volume/issue text in the overlay and draw new text.

    Parameters
    ----------
    overlay : the transparent overlay template image.
    issue_text : the replacement year/volume/issue string.
    font_path : path to a TTF/OTF font, or ``None`` to use the default.
    text_color : explicit RGBA colour for the replacement text.  When ``None``
        the colour is auto-detected from the original bar pixels.  Callers should
        pass ``(0,0,0,255)`` for the light overlay (black text) and
        ``(255,255,255,255)`` for the dark overlay (white text).
    """
    start, end = find_bar_region(overlay)
    if start >= end:
        print("Warning: could not locate issue bar; text will not be replaced.", file=sys.stderr)
        return overlay

    w = overlay.width
    bar_h = end - start

    # Clone the overlay and replace the bar region with a fresh bar of the same colour.
    bar_area = overlay.crop((0, start, w, end))
    arr = np.array(bar_area.convert("RGBA"))
    mask = arr[:, :, 3] > 20
    if mask.any():
        avg_rgb = int(arr[mask, :3].mean())
        avg_alpha = int(arr[mask, 3].mean())
    else:
        avg_rgb, avg_alpha = 255, 51

    fresh_bar = Image.new("RGBA", (w, bar_h), (avg_rgb, avg_rgb, avg_rgb, avg_alpha))
    out = overlay.copy()
    out.paste(fresh_bar, (0, start))

    # Use the explicit text colour if provided; otherwise auto-detect from bar pixels.
    if text_color is None:
        bar_gray = (arr[:, :, 0].astype(int) + arr[:, :, 1] + arr[:, :, 2]) // 3
        solid = arr[:, :, 3] > 100
        if solid.sum() > 0:
            bar_base = int(bar_gray[solid].mean())
            dark_text = (bar_gray < bar_base - 40) & solid
            light_text = (bar_gray > bar_base + 40) & solid
            if dark_text.sum() > light_text.sum():
                text_color = (0, 0, 0, 255)
            else:
                text_color = (255, 255, 255, 255)
        else:
            text_color = (0, 0, 0, 255)

    draw = ImageDraw.Draw(out)

    # Choose font size so that the text occupies roughly 50-70% of the bar height.
    font_size = int(bar_h * 0.55)
    if font_path and Path(font_path).is_file():
        try:
            font = ImageFont.truetype(font_path, font_size)
        except Exception as e:
            print(f"Warning: failed to load font {font_path}: {e}", file=sys.stderr)
            font = ImageFont.load_default()
    else:
        font = ImageFont.load_default()

    # Right-align the text, leaving a small margin.
    bbox = draw.textbbox((0, 0), issue_text, font=font)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]

    # Measure a single CJK character width for position offsets.
    char_bbox = draw.textbbox((0, 0), "字", font=font)
    char_w = char_bbox[2] - char_bbox[0]

    margin_x = int(bar_h * 0.4)
    x = max(0, w - text_w - margin_x)
    y = start + (bar_h - text_h) // 2

    # Move left by 2 CJK character widths.
    x -= 2 * char_w
    # Move up by 1/3 of the character height.
    y -= text_h // 3

    draw.text((x, y), issue_text, fill=text_color, font=font)

    return out


def _background_brightness(background: Image.Image) -> float:
    """Return the average brightness (0-255) of the upper third of the background."""
    # Use the upper third where the journal text will sit.
    upper = background.crop((0, 0, background.width, int(background.height * 0.33)))
    gray = upper.convert("L")
    return float(np.array(gray).mean())


def select_overlay_path(
    background: Image.Image,
    light_path: str | None,
    dark_path: str | None,
    mode: str,
    threshold: float = 140.0,
) -> str:
    """Pick the overlay path based on explicit mode or detected background brightness."""
    if mode == "light":
        if light_path is None:
            raise ValueError("Light overlay requested but --overlay-light not provided.")
        return light_path
    if mode == "dark":
        if dark_path is None:
            raise ValueError("Dark overlay requested but --overlay-dark not provided.")
        return dark_path

    # Auto mode: detect brightness and fall back to the single overlay if only one is given.
    brightness = _background_brightness(background)
    print(f"Detected upper-region brightness: {brightness:.1f}")
    if brightness >= threshold:
        if light_path is None and dark_path is None:
            raise ValueError("No overlay provided.")
        if light_path:
            return light_path
        return dark_path
    else:
        if dark_path:
            return dark_path
        return light_path


def composite_cover(
    background_path: str,
    light_overlay_path: str | None,
    dark_overlay_path: str | None,
    output_path: str,
    mode: str = "auto",
    year: str | None = None,
    volume: str | None = None,
    issue: str | None = None,
    issue_text: str | None = None,
    font_path: str | None = None,
    brightness_threshold: float = 140.0,
):
    bg = Image.open(background_path)
    if bg.mode != "RGBA":
        bg = bg.convert("RGBA")

    # Decide which overlay to use.
    overlay_path = select_overlay_path(bg, light_overlay_path, dark_overlay_path, mode, brightness_threshold)
    print(f"Using overlay: {overlay_path}")

    overlay = Image.open(overlay_path)
    if overlay.mode != "RGBA":
        overlay = overlay.convert("RGBA")

    # Optionally replace the issue-line text.
    if issue_text is None and (year or volume or issue):
        # Format in the same style as the template: "2026年第58卷第1期"
        y = year if year else "YYYY"
        v = volume if volume else "V"
        i = issue if issue else "I"
        issue_text = f"{y}年第{v}卷第{i}期"

    if issue_text:
        # Locate a font if none specified.
        if font_path is None:
            font_path = _find_system_font()
        # Determine text colour from which overlay was selected:
        #   light overlay  → black text  (for light backgrounds)
        #   dark overlay   → white text  (for dark backgrounds)
        if overlay_path == dark_overlay_path and dark_overlay_path != light_overlay_path:
            text_color = (255, 255, 255, 255)  # white
        else:
            text_color = (0, 0, 0, 255)        # black
        overlay = _replace_bar_text(overlay, issue_text, font_path, text_color=text_color)

    # Resize overlay to match background dimensions.
    if overlay.size != bg.size:
        overlay = overlay.resize(bg.size, Image.LANCZOS)

    # Composite: background first, then overlay on top.
    result = Image.alpha_composite(bg, overlay)

    # Save as RGB PNG.
    result_rgb = result.convert("RGB")
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result_rgb.save(str(output_path), "PNG")
    print(f"Saved: {output_path} ({result_rgb.size[0]} x {result_rgb.size[1]} px)")


def main():
    parser = argparse.ArgumentParser(description="Composite journal cover overlay onto background")
    parser.add_argument("background", help="Cover background image path")
    parser.add_argument("--overlay", help="Single overlay path (legacy; prefer --overlay-light/--overlay-dark)")
    parser.add_argument("--overlay-light", help="Overlay variant for light backgrounds")
    parser.add_argument("--overlay-dark", help="Overlay variant for dark backgrounds")
    parser.add_argument("--output", default="cover-mockup.png", help="Output PNG path")
    parser.add_argument(
        "--mode",
        choices=["auto", "light", "dark"],
        default="auto",
        help="Overlay selection mode. Auto uses the upper-region brightness of the background.",
    )
    parser.add_argument("--brightness-threshold", type=float, default=140.0,
                        help="Brightness threshold (0-255) for auto mode; above=light, below=dark")
    parser.add_argument("--year", help="Issue year, e.g. 2026")
    parser.add_argument("--volume", help="Volume number, e.g. 58")
    parser.add_argument("--issue", help="Issue number, e.g. 1")
    parser.add_argument("--issue-text", help="Full issue line text, e.g. '2026年第58卷第1期'")
    parser.add_argument("--font", help="Path to a TrueType/OpenType font for the issue text")
    args = parser.parse_args()

    if not Path(args.background).exists():
        print(f"ERROR: Background file not found: {args.background}", file=sys.stderr)
        sys.exit(1)

    # Default to the journal overlays bundled with this skill (references/) so the
    # skill works out-of-the-box for other users. Explicit --overlay* flags override.
    skill_refs = Path(__file__).resolve().parent.parent / "references"
    default_light = skill_refs / "jscnu-cover-overlay-light.png"
    default_dark = skill_refs / "jscnu-cover-overlay-dark.png"

    light_path = args.overlay_light or args.overlay or (str(default_light) if default_light.exists() else None)
    dark_path = args.overlay_dark or args.overlay or (str(default_dark) if default_dark.exists() else None)

    # Notify when we fall back to the bundled 华南师范大学学报 templates so the
    # user/agent knows a custom journal's branding is NOT being applied.
    using_default = (
        (light_path == str(default_light) and default_light.exists())
        or (dark_path == str(default_dark) and default_dark.exists())
    )
    if using_default:
        print(
            "NOTE: No custom overlay supplied -> using the bundled 华南师范大学学报（自然科学版） "
            "templates by default.",
            file=sys.stderr,
        )
        print(
            "      For other journals, provide two transparent PNG overlays via "
            "--overlay-light (dark text, for light backgrounds) and --overlay-dark "
            "(light text, for dark backgrounds).",
            file=sys.stderr,
        )

    if light_path is None and dark_path is None:
        print("ERROR: At least one overlay must be provided via --overlay-light, --overlay-dark, or --overlay", file=sys.stderr)
        sys.exit(1)

    for p in (light_path, dark_path):
        if p is not None and not Path(p).exists():
            print(f"ERROR: Overlay file not found: {p}", file=sys.stderr)
            sys.exit(1)

    composite_cover(
        background_path=args.background,
        light_overlay_path=light_path,
        dark_overlay_path=dark_path,
        output_path=args.output,
        mode=args.mode,
        year=args.year,
        volume=args.volume,
        issue=args.issue,
        issue_text=args.issue_text,
        font_path=args.font,
        brightness_threshold=args.brightness_threshold,
    )


if __name__ == "__main__":
    main()
