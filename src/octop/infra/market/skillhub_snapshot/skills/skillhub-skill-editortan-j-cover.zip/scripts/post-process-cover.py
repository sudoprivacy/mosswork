#!/usr/bin/env python3
"""
post-process-cover.py — A4 journal cover post-processing.

Takes an ImageGen output image, crops to A4 portrait ratio (1:1.414),
resizes to the target DPI, and applies a lens-blur (defocus) effect on
the upper portion so that text (journal name, logo, issue info) can be
added later without visual conflict — while keeping the image content
visible for a natural, smooth transition.

Usage:
  python post-process-cover.py input.png --output cover-A4.png
  python post-process-cover.py input.png --output cover-A4.png --dpi 300 \
    --blur-radius 45 --lighten-opacity 0.15 --blur-ratio 0.25
"""

import argparse
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
except ImportError:
    print("ERROR: Pillow is not installed. Install with: pip install Pillow", file=sys.stderr)
    sys.exit(1)


def crop_to_a4(img: Image.Image) -> Image.Image:
    """Center-crop image to A4 portrait ratio (1:1.4142)."""
    a4_ratio = 1.0 / 1.4142  # width / height
    w, h = img.size
    current_ratio = w / h

    if current_ratio > a4_ratio:
        # Too wide — crop sides
        new_w = int(h * a4_ratio)
        x0 = (w - new_w) // 2
        return img.crop((x0, 0, x0 + new_w, h))
    else:
        # Too tall — crop top/bottom (keep more of the bottom)
        new_h = int(w / a4_ratio)
        y0 = (h - new_h) // 2
        return img.crop((0, y0, w, y0 + new_h))


def resize_to_dpi(img: Image.Image, dpi: int) -> Image.Image:
    """Resize image to A4 dimensions at the given DPI."""
    cm_to_px = lambda cm: int(cm / 2.54 * dpi)
    target_w = cm_to_px(21.0)   # A4 width = 21 cm
    target_h = cm_to_px(29.7)   # A4 height = 29.7 cm
    return img.resize((target_w, target_h), Image.LANCZOS)


def apply_lens_blur(
    img: Image.Image,
    blur_radius: float,
    lighten_opacity: float,
    blur_ratio: float,
    feather_ratio: float = 0.08,
) -> Image.Image:
    """
    Apply a lens-blur (defocus) effect on the upper portion of the image.

    - The top `blur_ratio` of the image gets a strong Gaussian blur.
    - A feathered transition band (`feather_ratio` of height) smoothly
      blends the blurred region into the sharp lower region.
    - A subtle white overlay (`lighten_opacity`) is applied on top of
      the blurred area to slightly lift brightness for text readability,
      but NOT a solid white wash — the image content remains visible.

    Parameters
    ----------
    blur_radius : float
        Gaussian blur radius in pixels. Larger = more defocused.
    lighten_opacity : float
        White overlay strength on the blurred area (0 = no lightening,
        1 = full white). Typically 0.1–0.25.
    blur_ratio : float
        Fraction of image height that is fully blurred (0–0.5).
    feather_ratio : float
        Fraction of image height for the transition band between
        blurred and sharp regions.
    """
    w, h = img.size
    blur_h = int(h * blur_ratio)
    feather_h = int(h * feather_ratio)
    # Total affected height = blur + feather transition
    total_h = min(blur_h + feather_h, h)

    if img.mode != "RGBA":
        img = img.convert("RGBA")

    # --- Step 1: Create a blurred copy of the entire image ---
    blurred = img.filter(ImageFilter.GaussianBlur(radius=blur_radius))

    # --- Step 2: Build a vertical alpha mask ---
    # Top region (0..blur_h): full blur, alpha = 1
    # Feather region (blur_h..total_h): alpha fades from 1 to 0
    # Below total_h: no blur, alpha = 0
    mask = Image.new("L", (w, h), 0)  # start fully opaque-black = no effect
    draw = ImageDraw.Draw(mask)

    # Fully blurred region
    for y in range(blur_h):
        draw.line([(0, y), (w, y)], fill=255)

    # Feathered transition: smooth alpha from 255 to 0
    for y in range(blur_h, total_h):
        t = (y - blur_h) / max(feather_h, 1)
        # Use a smooth curve (cosine) for natural transition
        alpha = int(255 * (0.5 + 0.5 * (1 - t) * (1 - t) * (3 - 2 * (1 - t))))
        # Simpler: linear is fine too, but cosine feels more like lens blur
        alpha = int(255 * (1.0 - t) ** 0.7)  # slight curve
        draw.line([(0, y), (w, y)], fill=alpha)

    # --- Step 3: Composite blurred version onto original using mask ---
    # Where mask=255 (top), show blurred; where mask=0 (bottom), show original
    result = img.copy()
    # paste blurred image, using mask as the alpha
    result.paste(blurred, (0, 0), mask)

    # --- Step 4: Subtle lightening on the blurred upper area ---
    if lighten_opacity > 0:
        overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw2 = ImageDraw.Draw(overlay)

        for y in range(total_h):
            t = y / max(total_h, 1)
            # Lighten strongest at top, fading to 0 at feather boundary
            alpha = int(255 * lighten_opacity * (1.0 - t) ** 1.2)
            draw2.line([(0, y), (w, y)], fill=(255, 255, 255, alpha))

        result = Image.alpha_composite(result, overlay)

    return result


def main():
    parser = argparse.ArgumentParser(
        description="Post-process ImageGen output into A4 journal cover background."
    )
    parser.add_argument("input", help="Input image path (from ImageGen)")
    parser.add_argument("--output", default="cover-A4.png", help="Output PNG path")
    parser.add_argument("--dpi", type=int, default=300, help="Target DPI (72/96/150/300)")
    parser.add_argument("--blur-radius", type=float, default=45,
                        help="Gaussian blur radius in px (larger = more defocused)")
    parser.add_argument("--lighten-opacity", type=float, default=0.15,
                        help="Subtle white overlay on blurred area (0-1, typically 0.1-0.25)")
    parser.add_argument("--blur-ratio", type=float, default=0.25,
                        help="Fraction of image height to blur (0-0.5)")
    parser.add_argument("--feather-ratio", type=float, default=0.08,
                        help="Transition band height as fraction of image height (0-0.2)")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"ERROR: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    print(f"Loading: {input_path}")
    img = Image.open(input_path)
    print(f"  Original size: {img.size[0]} x {img.size[1]} px")

    # Step 1: Crop to A4 ratio
    print("Cropping to A4 ratio (1:1.4142)...")
    img = crop_to_a4(img)
    print(f"  Cropped size: {img.size[0]} x {img.size[1]} px")

    # Step 2: Resize to target DPI
    print(f"Resizing to {args.dpi} DPI...")
    img = resize_to_dpi(img, args.dpi)
    print(f"  Final size: {img.size[0]} x {img.size[1]} px")

    # Step 3: Apply lens blur on upper portion
    print(f"Applying lens blur (radius={args.blur_radius}px, "
          f"lighten={args.lighten_opacity}, blur_ratio={args.blur_ratio}, "
          f"feather={args.feather_ratio})...")
    img = apply_lens_blur(
        img,
        blur_radius=args.blur_radius,
        lighten_opacity=args.lighten_opacity,
        blur_ratio=args.blur_ratio,
        feather_ratio=args.feather_ratio,
    )

    # Step 4: Save
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    # Flatten to RGB for PNG output (no alpha channel needed)
    if img.mode == "RGBA":
        background = Image.new("RGB", img.size, (255, 255, 255))
        background.paste(img, mask=img.split()[3])
        img = background
    img.save(str(output_path), "PNG", dpi=(args.dpi, args.dpi))
    print(f"Saved: {output_path}")
    print(f"  Dimensions: {img.size[0]} x {img.size[1]} px @ {args.dpi} DPI")
    print("Done.")


if __name__ == "__main__":
    main()
