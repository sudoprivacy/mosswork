---
name: skillhub-skill-editortan-j-cover
description: "Generates a creative A4 journal cover background from a theme description or paper abstract. Parses year/volume/issue and the visual theme, generates a text-free artwork via ImageGen, removes the AI watermark, crops to A4 at 300 DPI, applies a lens-blur on the upper quarter, and composites a transparent journal-title overlay (auto-selected light/dark to match the background tone). On first use for"
---

# Journal Cover Design

## Overview

Generate a single A4 journal cover background image from a **theme description or paper abstract provided as plain text**. The workflow parses the user's text input to extract the subject theme and year/volume/issue, then uses ImageGen to create the visual artwork, and PIL post-processing to apply a lens-blur (defocus) effect on the upper 1/4 of the image. The skill can also composite a transparent journal-title overlay onto the background, automatically choosing the light or dark variant based on the background tone and replacing the year/volume/issue text when the template provides a relabelable bar.

**Key constraints:**
- Generated background contains NO text whatsoever.
- Lower 3/4: rich visual artwork representing the paper's themes.
- Upper 1/4: image content preserved but Gaussian-blurred, with a subtle brightness lift for text safety.
- Final dimensions: A4 portrait (default 2480 x 3508 px at 300 DPI).
- Optional final mockup: background + transparent overlay composited with alpha blending.
- Overlay templates: provide a **light** variant (dark text, for light backgrounds) and a **dark** variant (light text, for dark backgrounds). The skill auto-selects which to use.
- **Default branding**: This skill ships with the **华南师范大学学报（自然科学版）** overlay templates bundled in `references/` and uses them automatically when no custom overlay is supplied. It is fully usable out-of-the-box for that journal.
- **Other journals**: When a user is from a different journal, the skill must first prompt the user to provide **two hand-made transparent PNG overlay templates** (one for light backgrounds with dark journal-name text, one for dark backgrounds with light journal-name text), each containing only the fixed elements (journal LOGO, journal name, etc.). If the user does not provide them, the skill falls back to the bundled 华南师范大学学报 templates and clearly tells the user that the output still carries the default journal's branding.
- Issue line: the overlay template may contain a sample year/volume/issue line; the skill can replace it with the user's actual year/volume/issue when the template has a relabelable semi-transparent bar.

## When to Use

- User provides a theme description or paper abstract as **plain text** (not a URL) and asks for a journal cover / 期刊封面 / 封面设计 / cover art.
- User's input follows the canonical format `2026年第58卷第5期：封面绘图描述文本。` (year/volume/issue FIRST, then a full-width colon, then the description). Trailing or citation-style year/volume/issue is also tolerated.
- User says "设计封面", "生成封面底图", "journal cover background", or similar.
- User wants a text-free cover background image for later text/layout work.

## Workflow

### Step 0: Parse the User's Text Input

**Canonical input format — always prompt the user with this form:**

```
2026年第58卷第5期：封面绘图描述文本（研究主题、方法、主要发现等）。
```

- The **year/volume/issue** comes **FIRST**, followed by a full-width Chinese colon `：`, then the **theme description / abstract** of the paper.
- Tolerated alternates (parsing also handles them): a trailing `2026年第58卷第2期`, or a citation-style tail such as `2026, 58(2): 10-20`. But the front-loaded `YYYY年第VV卷第II期：…` form is the one to show users.

When the user hasn't supplied input yet, or the input is ambiguous, show them the canonical format verbatim, e.g.:

> 请提供封面输入，格式为：`2026年第58卷第5期：封面绘图描述文本。` 其中前半部分为年卷期，冒号后为论文的绘图主题描述（如研究对象、方法、关键发现）。

**Input example (canonical):**
```
2026年第58卷第5期：针对高速SCARA机器人在精密作业中因残余振动引发的定位延迟，提出一种融合几何参数优化的振动抑制方法。基于包含杆长、关节间距、截面惯性矩等关键几何参数的拉格朗日动力学模型，揭示了高速运动下的几何参数与振动模态的关联……
```

**Parse the input to extract:**
- **Year / Volume / Issue** — from the leading `YYYY年第VV卷第II期` prefix (before the first `：` colon). Patterns: `(\d{4})年`, `第(\d+)卷`, `第(\d+)期`. If not found at the front, scan the whole text for these patterns (handles trailing/citation-style inputs).
- **Abstract/theme text** — everything after the first `：` colon (or, if the year/volume/issue is trailing, everything before it).
- **Background tone preference** — check if the user mentions `浅色底图` (light) or `深色底图` (dark). If not specified, infer from the subject matter or default to light.

If the year/volume/issue is missing from the text, ask the user to provide it in the `YYYY年第VV卷第II期：描述文本` format. If the user provides a URL instead of text, use WebFetch to extract the abstract, then proceed.

### Step 1: Analyze the Text for Visual Themes

Read the theme description or abstract text and identify 2-4 concrete visual elements that represent the core subject. Ask:

- What objects, structures, or phenomena are central to the research?
- What visual metaphors capture the key insight?
- What color palette suits the subject (e.g., biological = greens/blues, astronomical = deep blues/golds, chemical = vibrant multi-color)?

Refer to `references/cover-prompt-guide.md` for theme extraction strategies and example mappings.

### Step 2: Craft the ImageGen Prompt

Build a prompt with the following structure, adapting the color/tone paragraph to the user's light/dark preference:

```
A scientific journal cover artwork for A4 portrait format. NO TEXT, NO LETTERS, NO NUMBERS, NO WORDS anywhere in the image.

The artwork fills the entire vertical canvas, but the main subject should be placed well inside the central ~80% of the frame, leaving a quiet margin of about one-tenth of the canvas on all four sides (top, bottom, left, right) for bleed/crop safety. The upper portion (about one quarter) should contain a continuation of the scene rendered with a soft, atmospheric, slightly out-of-focus quality — gentle bokeh, subtle gradients, and diffuse light — so that it can later serve as a background for journal text. The lower three-quarters feature the main detailed subject: [detailed visual description based on the theme description].

The overall composition should be vertical and balanced, with the strongest detail and visual weight in the lower two-thirds, gradually softening upward. The top edge should be [light and airy / deep and moody], consistent with a [light / dark] overall color scheme.

Style: [art style, e.g., digital illustration / 3D render / watercolor scientific art].
Color palette: [colors derived from the subject, biased toward light/dark based on user preference].
Vertical composition, portrait orientation, high detail, professional quality.
```

**Light-background prompts** should emphasize:
- Soft whites, pale gradients, warm daylight, airy atmosphere, high-key tones.
- The upper quarter should feel bright and clean.

**Dark-background prompts** should emphasize:
- Deep blues, blacks, golds, dramatic lighting, low-key tones, cosmic or night settings.
- The upper quarter should feel rich but not overly bright.

**Prompt rules:**
- Always start with "NO TEXT, NO LETTERS, NO NUMBERS, NO WORDS".
- Instruct ImageGen to keep the main subject inside the central ~80% of the canvas with a **10% quiet margin on all four sides** for bleed/crop safety.
- Describe the upper 1/4 as "soft, atmospheric, slightly out-of-focus" — ImageGen should still place content there, not a blank wash.
- Describe the lower 3/4 with rich visual detail.
- Keep the prompt under 300 words.
- Use English for the prompt (ImageGen performs better with English).

### Step 3: Generate the Image with ImageGen

Call the ImageGen tool:

```
ImageGen(
  prompt=<crafted_prompt>,
  size="1024x1536",
  quality="high",
  output_dir=<workspace_output_dir>
)
```

- Size `1024x1536` gives a portrait ratio (1:1.5), closest to A4 (1:1.414).
- Use `quality="high"` for best results.
- The output will be a PNG file in the specified directory.

> **Note:** ImageGen stamps an "图片由AI生成" watermark in the lower-right corner of every output. This watermark is part of the service's policy and cannot be suppressed by prompt wording. The next step removes it.

### Step 3.5: Remove the ImageGen Watermark

Run the watermark removal script on the ImageGen output **before** post-processing. The script uses an HSV-based detection pass plus a hard rectangular mask covering the entire watermark band, then OpenCV Telea inpainting to repaint the area with the surrounding texture. A second pass catches any faint anti-aliased remnants, and a final local polish blends the repaired region with the original.

```bash
<python_path> <skill_path>/scripts/remove-watermark.py \
  <imagegen_output_png> \
  <cleaned_output_png>
```

Requirements: `opencv-python-headless` and `numpy` (install with `pip install opencv-python-headless numpy`).

Default parameters work for the standard ImageGen watermark position (bottom-right band, ~30% width × 6% height). Tunable flags if the watermark ever moves:
- `--bottom` / `--right` / `--left-frac` — geometric bounds of the watermark band.
- `--v-threshold` / `--s-threshold` — HSV-based white-pixel detection sensitivity.
- `--inpaint-radius` — radius of the inpainting neighborhood.

### Step 4: PIL Post-Processing

Run the post-processing script to:
1. Crop the image to exact A4 ratio (1:1.414).
2. Resize to target resolution (default: 2480 x 3508 px at 300 DPI).
3. Apply a Gaussian blur on the upper 1/4 with a feathered transition, plus a subtle brightness lift.

```bash
<python_path> <skill_path>/scripts/post-process-cover.py \
  <input_image> \
  --output <output_path> \
  --dpi 300 \
  --blur-radius 45 \
  --lighten-opacity 0.10 \
  --blur-ratio 0.25
```

**Parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--output` | `cover-A4.png` | Output file path |
| `--dpi` | `300` | Target DPI (72/96/150/300) |
| `--blur-radius` | `45` | Gaussian blur radius in pixels (larger = more defocused) |
| `--lighten-opacity` | `0.15` | White lift strength on blurred area (0-1) |
| `--blur-ratio` | `0.25` | Fraction of image height blurred from top (0-0.5) |
| `--feather-ratio` | `0.08` | Transition band between blurred and sharp regions |

### Step 5: Composite Journal Overlay (Optional)

If the user provides transparent PNG overlay(s), composite the appropriate one onto the processed background.

Prepare two variants if available:
- **Light overlay** (e.g., `jscnu-cover-overlay-light.png`) — dark text, intended for light backgrounds.
- **Dark overlay** (e.g., `jscnu-cover-overlay-dark.png`) — light text, intended for dark backgrounds.

The skill bundles both variants in `references/` and uses them automatically when `--overlay-light`/`--overlay-dark` are omitted. Pass explicit paths only to override with a different journal's templates.

#### Using this skill for a DIFFERENT journal

This skill is published for reuse by other journals. Follow this rule before compositing for a non-华南师范大学学报 user:

1. **Detect the journal.** If the user is from 华南师范大学学报（自然科学版） (or does not specify a journal), skip to the composite command below — the bundled templates apply automatically.
2. **If the user is from another journal, prompt them up-front to provide two hand-made transparent overlay PNGs.** On first use (or whenever the journal differs from the default), show the user this exact prompt:

   > 请采用绘图设计软件生成 2 张期刊封面透明套字模板图（png 格式），分别适配深色背景（浅色刊名文字）和浅色背景（深色刊名文字）。透明套字模板只包含期刊 LOGO 和刊名信息等固定元素。

   The two PNGs must be:
   - **浅色背景套字**：深色（黑/深灰）刊名文字，用于浅色 AI 底图。
   - **深色背景套字**：浅色（白/浅灰）刊名文字，用于深色 AI 底图。
   - 透明背景、A4 竖版，且刊名/LOGO、年卷期条的位置需与本刊模板一致（年卷期条检测依赖上中部一条半透明色带）。
3. **If the user uploads their two overlays**, pass them via `--overlay-light` and `--overlay-dark` in the composite command below.
4. **If the user provides no custom overlay**, run the composite command without `--overlay-light`/`--overlay-dark` — the script falls back to the bundled 华南师范大学学报 templates and prints a `NOTE` to that effect. After generating, explicitly tell the user: *"当前封面仍使用《华南师范大学学报（自然科学版）》默认套字模板；如需更换为贵刊刊名，请用设计软件生成两套透明套字 PNG 后提供给我。"*

Run the composite script:

```bash
<python_path> <skill_path>/scripts/composite-cover.py \
  <background_png> \
  --overlay-light <light_overlay_png> \
  --overlay-dark  <dark_overlay_png> \
  --mode auto \
  --year <year> \
  --volume <volume> \
  --issue <issue> \
  --output <mockup_path>
```

The script:
- Measures the average brightness of the upper third of the background.
- Selects `--overlay-light` if the background is bright, otherwise `--overlay-dark`.
  - The user can override with `--mode light` or `--mode dark`.
- If `--year`/`--volume`/`--issue` (or `--issue-text`) are provided, it locates the template's year/volume/issue bar, refreshes the bar, and redraws the text in the overlay-matched colour:
  - Black for the light overlay (dark text on light background).
  - White for the dark overlay (light text on dark background).
- The issue text is right-aligned by default, then shifted **left by 2 CJK character widths** and **up by 1/3 of the character height**.
- Resizes the overlay to match the background dimensions.
- Uses alpha compositing so the transparent areas of the overlay reveal the background.
- Saves the final RGB PNG mockup.
- If no overlay paths are provided, falls back to the bundled 华南师范大学学报 templates and prints a `NOTE` to stderr.

Legacy single-template usage is still supported via `--overlay <path>`.

**Composite parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--background` | (required) | Path to the processed cover background PNG |
| `--overlay-light` | — | Light-background overlay (dark text) |
| `--overlay-dark` | — | Dark-background overlay (light text) |
| `--overlay` | — | Legacy single overlay path |
| `--mode` | `auto` | `auto` / `light` / `dark` overlay selection |
| `--brightness-threshold` | `140` | Brightness boundary for auto mode (0-255) |
| `--year` | — | Issue year, e.g., `2026` |
| `--volume` | — | Volume number, e.g., `58` |
| `--issue` | — | Issue number, e.g., `1` |
| `--issue-text` | — | Full issue line, e.g., `2026年第58卷第1期` |
| `--font` | — | Optional path to a Chinese font for the issue text |
| `--output` | `cover-mockup.png` | Output mockup path |

### Step 6: Present the Result

Use `present_files` to show the final PNG(s). If an overlay was composited, present both the background-only PNG and the final mockup so the user can download either.

## Dimension Presets (A4 Portrait)

| DPI | Width (px) | Height (px) | Use case |
|-----|-----------|-------------|----------|
| 72 | 595 | 842 | Screen preview |
| 96 | 794 | 1123 | High-quality screen |
| 150 | 1240 | 1754 | Print draft |
| 300 | 2480 | 3508 | Print quality |

## Content Guidelines

- **No text**: The generated image must contain zero text. ImageGen may still produce stray characters — the upper-quarter blur helps mask any that appear there.
- **Visual theme**: Choose concrete, recognizable imagery over abstract concepts. "A DNA double helix made of golden light" is better than "the concept of genetics".
- **Color harmony**: Derive the palette from the subject. Avoid clashing colors that would conflict with future text overlays.
- **Upper area continuity**: The prompt should describe the upper quarter as a soft, atmospheric continuation of the lower scene. The PIL post-processing will apply the actual defocus effect.

## Technical Notes

- ImageGen generates at 1024x1536 px; the PIL script upscales to the target A4 resolution using LANCZOS resampling.
- The lens-blur effect applies a Gaussian blur to the upper `blur-ratio` of the canvas, then uses an alpha feather mask to blend smoothly into the sharp lower region.
- A subtle white overlay is applied only on the blurred region to lift brightness for text readability; the underlying image content remains visible.
- If ImageGen produces text in the lower 3/4, regenerate with a stronger "NO TEXT" emphasis in the prompt. PIL cannot remove text from the lower area.
- The script requires Pillow (PIL). Install: `pip install Pillow`.
- The composite script requires numpy. Install: `pip install numpy`.
- Overlay auto-selection: when `--mode auto` is used, brightness is measured on the upper third of the background (the text area). A threshold of 140 works well for most light/dark boundaries; tune with `--brightness-threshold`.
- Issue text replacement: the composite script locates the white bar, fills it with the same average color/alpha, and draws the new issue text in the overlay-matched colour (black for `--overlay-light`, white for `--overlay-dark`). The text is right-aligned, then shifted **left by 2 CJK character widths** and **up by 1/3 of the character height**. If the default Windows font is unavailable, pass `--font` to a TTF/TTC file.
- Overlay default fallback: if `--overlay-light`/`--overlay-dark` are omitted, the script uses the bundled 华南师范大学学报（自然科学版） templates in `references/` and prints a `NOTE` to stderr. For any other journal, pass your own two hand-made PNG overlays via `--overlay-light` / `--overlay-dark` (see "Using this skill for a DIFFERENT journal" in Step 5).

## Resources

- `scripts/remove-watermark.py` — Detects and inpaints the "图片由AI生成" watermark ImageGen stamps in the lower-right corner. Uses OpenCV Telea inpainting with a precise HSV mask and a hard rectangular safety band.
- `scripts/post-process-cover.py` — Crops to A4 ratio, resizes to target DPI, and applies the upper-quarter lens-blur effect.
- `scripts/composite-cover.py` — Composites a journal-title overlay onto the processed cover background. Supports light/dark overlay variants, automatic selection based on background brightness, and year/volume/issue text replacement.
- `references/cover-prompt-guide.md` — Theme extraction strategies, light/dark prompt adaptation, ImageGen prompt templates by research domain, and color palette recommendations.
