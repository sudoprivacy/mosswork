#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_docx.py — 8D 报告 Markdown → Word(.docx) 转换器（零硬编码依赖，仅需 python-docx）

用法：
  python gen_docx.py report.md                       # 输出 report.docx（同目录同名）
  python gen_docx.py report.md -o 8D报告.docx        # 指定输出路径
  python gen_docx.py -t template.md -o 模板.docx      # 转换模板
  cat report.md | python gen_docx.py -               # 从 stdin 读

特性：
  - 标题层级映射：# → 标题（居中大号，作封面标题）；## → 一级标题；### → 二级；#### → 三级
  - 表格：自动识别 Markdown 表格，首行做表头（加粗+浅灰底），列宽自适应
  - 列表：'-/*/+' 转项目符号；'1. / 1)' 转自动编号
  - 行内格式：**粗体** *斜体* `代码` 均识别
  - 引用 '> ' 转斜体缩进段；代码块 ``` 转等宽段
  - 每个 '## D' 步骤标题前自动分页，形成正式报告的步骤隔离

依赖：python-docx。缺失时给出安装提示（pip install python-docx）。
"""

import sys
import re
import os
import datetime

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
except ImportError:
    sys.stderr.write(
        "缺少依赖 python-docx。请先安装：\n"
        "  pip install python-docx\n"
        "（WorkBuddy 用户：在 managed python venv 中执行上面命令即可）\n"
    )
    sys.exit(2)


# ---------- 行内格式解析 ----------
def add_inline(paragraph, text):
    """把含 **粗体** / *斜体* / `代码` 的文本按片段写入段落。"""
    # 先按代码块拆分（保护反引号内容）
    parts = re.split(r'(`[^`]+`)', text)
    for part in parts:
        if not part:
            continue
        if part.startswith('`') and part.endswith('`') and len(part) >= 2:
            run = paragraph.add_run(part[1:-1])
            run.font.name = 'Consolas'
            run.font.size = Pt(9)
            continue
        # 粗体：**...**
        segs = re.split(r'(\*\*[^*]+\*\*)', part)
        for seg in segs:
            if not seg:
                continue
            if seg.startswith('**') and seg.endswith('**') and len(seg) >= 4:
                run = paragraph.add_run(seg[2:-2])
                run.bold = True
            else:
                # 斜体：*...*（非 **）
                its = re.split(r'(\*[^*]+\*)', seg)
                for it in its:
                    if not it:
                        continue
                    if it.startswith('*') and it.endswith('*') and len(it) >= 2:
                        run = paragraph.add_run(it[1:-1])
                        run.italic = True
                    else:
                        paragraph.add_run(it)


def set_cell_bg(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    tcPr.append(shd)


def shade_header(row):
    for cell in row.cells:
        set_cell_bg(cell, 'D9E2F3')
        for p in cell.paragraphs:
            for r in p.runs:
                r.bold = True


def is_table_row(line):
    return line.strip().startswith('|') and line.strip().endswith('|')


def parse_table_row(line):
    cells = [c.strip() for c in line.strip().strip('|').split('|')]
    return cells


def is_separator_row(line):
    s = line.strip().strip('|')
    return bool(re.match(r'^[\s:\-|+]+$', s)) and '-' in s


def build_table(doc, rows):
    parsed = [parse_table_row(r) for r in rows]
    ncols = max(len(p) for p in parsed)
    table = doc.add_table(rows=0, cols=ncols)
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for ri, cells_data in enumerate(parsed):
        cells = table.add_row().cells
        for ci in range(ncols):
            val = cells_data[ci] if ci < len(cells_data) else ''
            cells[ci].text = ''
            add_inline(cells[ci].paragraphs[0], val)
        if ri == 0:
            shade_header(table.rows[0])
    return table


# ---------- 主转换 ----------
def convert(md_text, out_path):
    doc = Document()

    # 默认字体（中英混排）
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

    lines = md_text.splitlines()
    i = 0
    n = len(lines)
    first_h1 = True

    # 收集表格缓冲
    table_buf = []

    def flush_table():
        nonlocal table_buf
        if len(table_buf) >= 2:
            # 去掉分隔行
            rows = [table_buf[0]] + [r for r in table_buf[1:] if not is_separator_row(r)]
            build_table(doc, rows)
            doc.add_paragraph('')
        table_buf = []

    while i < n:
        line = lines[i]
        stripped = line.strip()

        # 表格处理（遇到非表格行时由下方 else 分支统一 flush）
        if is_table_row(line):
            table_buf.append(line)
            i += 1
            continue
        else:
            if table_buf:
                flush_table()

        # 代码块
        if stripped.startswith('```'):
            lang = stripped[3:].strip()
            i += 1
            code_lines = []
            while i < n and not lines[i].strip().startswith('```'):
                code_lines.append(lines[i])
                i += 1
            i += 1  # skip closing ```
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.3)
            run = p.add_run('\n'.join(code_lines))
            run.font.name = 'Consolas'
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
            continue

        # 标题
        m = re.match(r'^(#{1,4})\s+(.*)$', line)
        if m:
            level = len(m.group(1))
            text = m.group(2).strip()
            if level == 1:
                if first_h1:
                    # 封面标题
                    p = doc.add_paragraph()
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    p.paragraph_format.space_before = Pt(120)
                    run = p.add_run(text)
                    run.bold = True
                    run.font.size = Pt(22)
                    run.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
                    sub = doc.add_paragraph()
                    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    today = datetime.date.today().strftime('%Y-%m-%d')
                    r2 = sub.add_run('8D 问题解决报告 · 生成日期 ' + today)
                    r2.font.size = Pt(11)
                    r2.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
                    doc.add_page_break()
                    first_h1 = False
                else:
                    p = doc.add_heading(level=1)
                    add_inline(p, text)
                i += 1
                continue
            else:
                # D 步骤标题前分页
                if level == 2 and re.match(r'^(D[0-8]|D\d)', text):
                    doc.add_page_break()
                p = doc.add_heading(level=level - 1)  # docx Heading 1/2/3
                add_inline(p, text)
                i += 1
                continue

        # 分隔线
        if re.match(r'^(\-{3,}|\*{3,}|_{3,})$', stripped):
            p = doc.add_paragraph()
            pPr = p._p.get_or_add_pPr()
            pbdr = OxmlElement('w:pBdr')
            bottom = OxmlElement('w:bottom')
            bottom.set(qn('w:val'), 'single')
            bottom.set(qn('w:sz'), '6')
            bottom.set(qn('w:space'), '1')
            bottom.set(qn('w:color'), 'BFBFBF')
            pbdr.append(bottom)
            pPr.append(pbdr)
            i += 1
            continue

        # 引用
        if stripped.startswith('>'):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.3)
            run = p.add_run(stripped.lstrip('> '))
            run.italic = True
            run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
            i += 1
            continue

        # 列表
        lm = re.match(r'^(\s*)([-*+])\s+(.*)$', line)
        nm = re.match(r'^(\s*)(\d+)[.)]\s+(.*)$', line)
        if lm or nm:
            p = doc.add_paragraph(style='List Bullet' if lm else 'List Number')
            p.paragraph_format.left_indent = Inches(0.3)
            add_inline(p, (lm or nm).group(3))
            i += 1
            continue

        # 空行
        if stripped == '':
            i += 1
            continue

        # 普通段落
        p = doc.add_paragraph()
        add_inline(p, stripped)
        i += 1

    if table_buf:
        flush_table()

    doc.save(out_path)
    return out_path


def main():
    import argparse
    ap = argparse.ArgumentParser(description='8D 报告 Markdown → Word 转换器')
    ap.add_argument('input', help='输入 Markdown 文件路径，或 - 表示 stdin')
    ap.add_argument('-o', '--output', help='输出 .docx 路径（默认同目录同名 .docx）')
    args = ap.parse_args()

    if args.input == '-':
        md_text = sys.stdin.read()
        out_path = args.output or '8d-report.docx'
    else:
        if not os.path.exists(args.input):
            sys.stderr.write('文件不存在：%s\n' % args.input)
            sys.exit(1)
        with open(args.input, encoding='utf-8') as f:
            md_text = f.read()
        if args.output:
            out_path = args.output
        else:
            base, _ = os.path.splitext(args.input)
            out_path = base + '.docx'

    convert(md_text, out_path)
    print('已生成 Word 报告：' + os.path.abspath(out_path))


if __name__ == '__main__':
    main()
