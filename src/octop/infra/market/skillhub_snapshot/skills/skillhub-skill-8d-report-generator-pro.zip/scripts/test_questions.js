#!/usr/bin/env node
'use strict';
// 回归测试：--questions 输出条数须与 references/review-questions.md 对齐（缺陷 3 自检）
const { execFileSync } = require('child_process');
const path = require('path');
const out = execFileSync(process.execPath, [path.join(__dirname, 'd8.js'), '--questions'], { encoding: 'utf8' });
const q = JSON.parse(out);
const counts = {};
let total = 0;
for (const k of Object.keys(q)) { counts[k] = q[k].length; total += q[k].length; }
console.log('各步条数：', JSON.stringify(counts));

let ok = true;
if (counts.D4 !== 12) { console.error('✗ D4 应为 12 条，实际', counts.D4); ok = false; }
if (counts.D7 !== 6) { console.error('✗ D7 应为 6 条，实际', counts.D7); ok = false; }
if (total !== 56) { console.error('✗ 总数应为 56 条，实际', total); ok = false; }
if (ok) { console.log('✓ 评审追问清单条数对齐 review-questions.md（共', total, '条）'); process.exit(0); }
else { process.exit(1); }
