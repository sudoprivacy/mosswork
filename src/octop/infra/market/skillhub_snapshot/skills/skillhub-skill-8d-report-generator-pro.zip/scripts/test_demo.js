#!/usr/bin/env node
'use strict';
// 回归测试：内置 --demo 样板（定义为及格样板）不应再被机检误报
// 覆盖缺陷 2（4 项误判已修复）、缺陷 5（系统链识别）、缺陷 1（D06/D18 不误伤样板）
const { execFileSync } = require('child_process');
const path = require('path');
const out = execFileSync(process.execPath, [path.join(__dirname, 'd8.js'), '--demo'], { encoding: 'utf8' });
const r = JSON.parse(out);

const need = ['改善前后数据对比', '筛选数据(已筛数/发现数/缺陷数)', '措施完成证据(照片/图纸/修订文件)'];
const missing = r.missingElements.filter(e => need.includes(e));
const fatal = r.deviations.filter(d => d.sev === '致命').map(d => d.id);
const d06 = r.deviations.some(d => d.id === 'D06');
const d18 = r.deviations.some(d => d.id === 'D18');
const multiInMissing = r.missingElements.includes('多根因贡献率');

let ok = true;
if (missing.length) { console.error('✗ --demo 仍误报缺失要素：', missing); ok = false; }
if (fatal.length) { console.error('✗ --demo 出现致命偏差：', fatal); ok = false; }
if (d06) { console.error('✗ --demo 误报 D06 缺系统链（样板含管理根因）'); ok = false; }
if (d18) { console.error('✗ --demo 误报 D18 只有纠正无预防（样板含预防/横展）'); ok = false; }
if (multiInMissing) { console.error('✗ --demo 单根因误报多根因贡献率缺失'); ok = false; }
if (r.dualChain.system !== true) { console.error('✗ --demo 系统链未识别'); ok = false; }

console.log('verdict      :', r.verdict);
console.log('missing      :', JSON.stringify(r.missingElements));
console.log('deviations   :', r.deviations.map(d => d.id + ':' + d.sev).join(', ') || '(无)');
if (ok) { console.log('✓ 回归通过：--demo 样板机检全绿'); process.exit(0); }
else { process.exit(1); }
