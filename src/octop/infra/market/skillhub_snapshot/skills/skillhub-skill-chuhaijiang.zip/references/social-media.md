# 社媒管理 SOP

目标：管理 TikTok / Instagram 等社媒账号——发布内容、运营评论、收发私信、看数据、查达人带货订单、经营自己的 TikTok Shop 店铺。

## 前提：账号绑定

所有社媒操作都基于已绑定的账号。先 social_accounts(action="list") 查询已绑定列表。首次需要生成授权链接时再读一次 `account_info.channel`：`commercial` 的 TikTok/Instagram/Facebook 授权返回 `ref`，用 `bind_status` 后再 `list`；`member_connector` 复用 SaaS 授权路由且不返回 `ref`，持有人完成授权后直接用 `list` 确认。两者不拆成不同 Tool。

- 无绑定账号，要操作 Instagram / Facebook → 分别调用 social_accounts(action="get_instagram_auth_url" / "get_facebook_auth_url")；只支持 Instagram Business/Creator 专业账号。把 `auth_url` 发给可信账号持有人；商业通道保留 `ref` 并查 `bind_status`，会员通道完成后直接查 `list`。Facebook 一次授权可能绑定多个 Page，最终必须用 list 取完整账号列表。YouTube 暂无 MCP 授权 action，仍需去出海匠网页端（https://www.chuhaijiang.com）绑定
- TikTok Shop 挂车发布或达人带货订单 → 使用 `get_tiktok_shop_auth_url`；普通达人号、店铺官方号和营销号绑定后均为 `tiktok-shop-pc`。`type` 只选区域授权应用：cross-border（默认，US/BR/MX）、mx-local（墨西哥）、domestic（美国）、local-jp（日本）、local-eu（DE/ES/FR/GB/IE/IT），不决定账号身份。两条通道都在持有人完成授权后用 `list(platforms=["tiktok-shop-pc"])` 确认；生成链接本身不等于绑定成功。已有有效绑定且具备订单读取权限时直接复用
- 无绑定账号，要操作的是普通 TikTok 视频账号（不含 Shop 挂车及带货订单）→ **优先用授权链接绑定**，扫码是用户明确要求时才用的兜底：
  1. 调 social_accounts(action="get_tiktok_auth_url") 拿 `auth_url`；把链接发给账号持有人（不必是当前对话的用户本人——云手机、代运营场景很常见），提醒在任意浏览器打开登录确认即可
  2. `commercial` 用响应中的同一 `ref` 调 `bind_status`，间隔不得短于 3 秒，`status=bound` 后停止；`pending` 同时可能表示尚未授权、未知/过期 ref 或回执未写入，不能直接断言失败。`member_connector` 没有 `ref`，不调用 `bind_status`，持有人完成后查 `list`。两种通道最终都用 list 确认账号可见；后续 social_* 参数取 list 的数字 `id`，不要取回执里的外部字符串 `platform_account_id`
  3. 只有用户明确说想扫码时才走 login_qrcode：
     a. 先提醒用户打开手机 TikTok App 准备好（二维码几分钟内有效，提前准备减少换码）
     b. 调 social_accounts(action="login_qrcode")，**展示二维码的方式严格按返回结果里 hint 给出的决策阶梯执行**——阶梯细节、渲染命令、有效期、轮询与过期语义都以 hint 为准，它随服务端更新、每次调用都是最新版，不要凭记忆或本文档做；hint 会要求拿到二维码后立刻开始轮询 login_check，**不要等用户确认看到码再轮询**——没轮询过的码，用户真扫时会被判定已过期
     c. 核心纪律：**确认用户真的看到了二维码，再让他扫**；各级都走不通时不要自行变通（如复述二维码内容），引导用户去出海匠网页端（https://www.chuhaijiang.com → 账号管理 → 连接 TikTok）完成绑定
     d. 绑定成功后用 list 确认，再继续原操作
- 有多个账号 → 操作前和用户确认用哪个

## 发布流程（social_publish）

查询话题建议时，`social_tools(action="hashtag")` 的 `keyword` 必须是无空白字符的单个词，例如从 “water bottle” 提取 `bottle`；不要直接传整句、空格短语或多个词，否则上游返回 400。

新建发布使用 `social_publish(action="upload_and_publish")`。其 `platform_config` 优先使用结构化对象，MCP 在请求上游前自动序列化；已经持有上游原始请求的旧调用方仍可传合法 JSON 对象字符串。发布走的是存储 bucket 字段，不是 URL——视频发布只认 bucket_name + bucket_key（字段映射见 upload_file 工具说明）。

1. **备齐素材（把文件送进出海匠存储）**：
   - 本地文件：upload_file(file_name) 拿预签名上传地址 → 用 shell 执行 PUT 上传（命令模板见 upload_file 工具说明）→ 记下返回的 bucket 字段
   - AI 生成的素材：check_task 返回的结果 URL **不能直接发布**，先下载到本地，再走上面的 upload_file + PUT
2. **组装发布内容**：bucket 字段 + video_title + publications（账号、标题/描述、记录标签、定时时间）；多文件/轮播用 media_items。`publications[].tags` 只是出海匠内部记录标签，不会自动变成平台 hashtag；需要发布的话题写入实际平台标题/描述。普通上传的 `media_items[].order` 从 **1** 开始。每个账号的 `platform_config` 都是独立的**结构化对象**；MCP 自动转换成上游 JSON 字符串。发布链路由 `platform_account_id` 对应的账号决定，给普通 TikTok 账号塞 `product_id` 不会把它变成 TikTok Shop 挂车发布。TikTok Business 视频/图文的位置标签使用成对的 `location_id` + `location_name`；先用 social_tools(action="location_search") 按目标账号搜索，不猜 ID。AI 生成内容声明按发布链路选择 `is_aigc` 或 `is_ai_generated`，规则见下文
3. **发布前必须确认**：把账号、素材、文案、发布时间、位置标签（如有）和当前 Tool 响应能够确认的消耗完整展示给用户。拿到明确同意再提交——发布是不可撤回的外发动作
4. **有限跟踪结果**：upload_and_publish 返回 `session_token` 后先检查 `skipped_accounts`，非空表示部分账号未受理，必须反馈。建议等 **3–5 秒**再调用 social_publish(action="session")，后续每次间隔 **3–5 秒**；从发布提交起自动跟踪最长 **1 分钟**。会话终态是 `completed / completed_with_errors / cancelled / failed`，`completed_with_errors` 是常见的多账号混合结果，必须逐条检查 `publications[].status/error_message`；进入终态立刻停止。1 分钟仍为 `in_progress`，就告知用户“发布已提交，平台仍在处理；你可以之后让我再查”，不要继续轮询或重发发布请求。用户之后明确要求查询状态时再单独查询；发布成功后，把每个成功目标的 `platform_url` 反馈给用户。**进行中的发布在 records 里查不到，不要用 records 判断"发没发出去"**

### TikTok 发布音乐策略

先按目标账号区分普通 TikTok Business 与 TikTok Shop：两者都有音乐库选曲能力，但搜索入口和发布 ID 不同。下面的 Business 音乐参数不适用于 TikTok Personal 或 Shop；Shop 视频/图文流程见本节后半部分。一个请求发多个账号时，每个 `publications[]` 目标独立配置。

1. **默认不搜索候选音乐**：用户只是要求发布内容、没有主动提到选歌/搜歌/复用音乐时，不调用 music_search、music_recent 或 shop_music_search，不要额外给出一长串配乐让用户决策
2. **图文默认推荐自动配乐**：发布普通 TikTok 图文且用户没有指定歌曲时，在发布方案中推荐 `{"auto_add_music":true}`，无需调用音乐查询接口；这是待确认的默认建议，仍要在最终发布清单中明确展示，不能静默添加。视频发布没有对应的自动配乐默认项，用户未提音乐就不添加音乐配置
3. **用户明确提出音乐需求时才查询**：先确认目标账号并读取 `account_info.channel`，再按 `social_tools` 当前 Tool 描述选择曾用音乐或搜索音乐。消耗以当前响应为准。热门音乐是市场数据，用户未给国家时先确认目标市场
4. **查询后让用户选择**：展示歌曲名、艺术家、时长、风格和 `preview_url`，不要只凭标题替用户选。最终写入发布配置的是返回的 `song_clip_id`，**不是** `commercial_music_id`
5. **组装每个发布目标的配置**：
   - 视频指定音乐：`{"music_sound_id":"<song_clip_id>","music_sound_volume":80,"video_original_sound_volume":20}`
   - 可选裁剪：`music_sound_start` / `music_sound_end` 均为毫秒且不得小于 0；两者同时传时 end 必须大于 start
   - `music_sound_volume`、`video_original_sound_volume` 范围都是 0–100；音乐音量默认 100
   - 图文默认推荐自动配乐：`{"auto_add_music":true}`；用户明确选择歌曲后改用 `{"music_sound_id":"<song_clip_id>"}`，二者不能同时传
6. **纳入最终确认**：发布确认清单除账号、素材、文案和时间外，还要列出自动配乐开关，或已选音乐的名称/艺术家、裁剪区间、音乐音量和原声音量。用户确认后，把上述字段直接放进 `social_publish(action="upload_and_publish")` 的 `publications[].platform_config` 对象发布，由 MCP 负责序列化

是否进入 TikTok Shop 挂车链路取决于 `platform_account_id` 对应的账号类型，不取决于是否塞入 `product_id`。目标是 TikTok Shop 账号时，上述 TikTok Business 音乐参数以及 privacy、评论/合拍/合集、`is_aigc` 不适用；普通 TikTok 账号即使误传 `product_id` 也不会切换成挂车发布。挂车视频的 AI 生成内容声明使用 `is_ai_generated`。

**TikTok Shop 音乐库选曲（视频和图文）**：用户提出“从音乐库选 Lofi”等需求时，先确认目标 Shop 账号和 `account_info.channel`。使用 `social_tools(action="shop_music_search")`，商业和会员通道均有对应路由，消耗以当前 Tool 描述和响应为准。按当前 Tool 合同传目标账号和关键词，展示返回歌曲的名称、作者、时长和试听链接，让用户选择。翻页沿用同一账号与关键词，并带上响应中的搜索 ID 和下一页游标；检查业务错误和实际歌曲列表，HTTP 200、可用性探测或空列表都不能证明已找到合适歌曲，不硬编码地区白名单。

选中的 Shop `music[].id` 写入同一目标的 `publications[].platform_config.music_id`，不使用 Business 的 `song_clip_id` / `music_sound_id`。图文仍需完整的 `post_type` 及对应商品链接或店铺锚点；`music_id` 不代替挂车配置。将歌曲和试听链接纳入最终发布确认，用户未提音乐时不自动搜索或给 Shop 套用 `auto_add_music`。

**自定义音频是另一项需求**：“上传自定义 Lofi 音频”不等于从 Shop 音乐库选曲。当前 Shop 图文发布合同未提供自定义音频上传字段，不能把本地音频路径、URL 或任意 ID 当作 `music_id`。可向用户说明音乐库选曲方案；如需改做合成音频的视频，须先确认内容形式的变更，不擅自把图文改成视频。

### TikTok Shop 视频主动预检

- `enable_precheck` 只控制 TikTok Shop 挂车视频发布前的**可选主动预检**；默认 `false`
- 省略该字段或明确传 `false` 都会跳过主动预检，直接进入发布；这不等于绕过 TikTok 最终的平台审核
- 只有用户明确要求先做额外预检时才传 `true`；发布确认清单要展示最终开关值

### TikTok AI 生成内容声明

- TikTok Business 商家授权账号的普通视频和图文发布使用 `is_aigc`；该字段在此链路正常生效
- 目标账号为 TikTok Shop 且发布挂车视频时使用 `is_ai_generated`；不要同时把 `is_aigc` 当作有效声明字段
- TikTok Shop 挂车图文当前不支持 AI 生成内容声明，`is_ai_generated` 不适用；其他不支持的设置遵循 TikTok 账号内默认值
- 发布前确认清单要明确展示是否声明 AI 生成内容，并按实际链路写入正确字段

### TikTok 发布位置标签

- 仅支持 TikTok Business 商家授权账号的视频和图文发布
- `location_id` 与 `location_name` 必须成对放进同一账号的 `publications[].platform_config` 对象；名称必须与 ID 对应，缺少任一字段时位置标签不生效
- 先按 `social_tools` 当前 Tool 描述查询位置候选，再让用户按名称/地址确认。把同一结果里的 ID/名称成对使用，不根据地名猜 ID；消耗以当前响应为准
- 一个请求发布到多个账号时，每个账号可单独设置位置；发布前确认清单要逐账号展示

## 评论运营（social_comments）

- 评论是先同步后查询的：拉不到评论先 sync 再 list。sync 是异步的，刚 sync 完立刻 list 拿到空结果，先等几秒重试一次，别急着下"没有评论"的结论
- 拉取帖子评论，按情感/主题归类，给用户运营建议
- 回复评论也是外发动作：批量回复前把回复内容清单给用户确认
- 处理不当评论分两种：自己账号发的用删除（delete），**他人发的评论删不掉，用隐藏（hide）**让其对外不可见；隐藏可随时恢复，删除不可逆——两者都逐条和用户确认

## 私信运营（social_messages）

层级是：渠道（一个绑定的社媒账号，如一个 WhatsApp 号）→ 会话（与一个联系人/群的对话）→ 消息。定位目标会话按 channels → conversations → list 逐层走。

- 典型场景：客户咨询分流（用 AI 洞察标签 kol/b2b/buyer/fan 筛会话）、批量查未读、代写回复
- **发私信是外发动作**：发送前把目标会话、消息内容给用户确认；回复多个会话时列清单一次确认
- 读消息时的 mark_as_read 会向对方发已读回执（如 WhatsApp 蓝勾）——只想看不想让对方知道已读时不要带这个参数
- 改会话备注（remark）在 WhatsApp 上会同步改写对方联系人的显示名——这是对外可见的变更，批量打标签前先让用户确认命名方式
- 私信媒体不走 upload_file，用 social_messages 的 upload 专用通道（工具说明里有字段映射）
- 发送失败提示发送窗口关闭（20510）时如实告知用户：平台限制超时未回复的会话不能主动发消息，不是故障
- **渠道列表为空 ≠ 用户没绑账号**：私信要求绑定授权包含私信权限。逐条排查引导——早期绑定的账号需重新授权绑定；TikTok 只有 Business 账号支持私信（个人账号可在 TikTok App 内免费切换，切换后重新扫码）；Instagram/Facebook 要在出海匠控制台绑定

## 店铺经营（social_seller）

前提是 TikTok Shop **Seller 店铺主体授权**（`tiktok-shop-seller`），通过出海匠网页「资产 → 店铺」绑定。`get_tiktok_shop_auth_url` 绑定的是发布带货内容的 TikTok 账号（`tiktok-shop-pc`），包括店铺官方号和营销号；授权这些账号不等于授权 Seller 店铺，切换 `type` 也不能替代卖家授权。MCP 当前没有 Seller 店铺授权 action。

- 典型场景：每日店铺健康检查（daily_report 传昨天日期）、多店对比（shops_overview）、库存/滞销盘点（products + product_detail 看 SKU 库存）
- daily_report 是"取报告"不是"算报告"：status=generating 时等 5-10 秒再取，**每次调用都消耗当前通道额度**，拿到 ready 结果就复用，不要高频轮询
- **长时间 generating 是静默输入错误**，不是慢：先停下检查账号是不是卖家类型、日期是不是严格 YYYY-MM-DD，修正输入而不是继续重试烧钱
- 给用户呈现日报时注意口径：战报是当日实时订单口径，经营分析是 T-2 口径，两块数字对不上是正常的，主动说明
- 别拿 social_seller 做选品调研——那是 search 的活；这里只管用户自己的店

## 达人带货数据（social_commerce，仅出海匠）

使用 `action="orders"` 查询用户已绑定 `tiktok-shop-pc` 账号的已采集带货订单、SKU 明细和佣金。与 `social_seller` 的卖家店铺订单、`search/get_related` 的市场数据区分。新绑定后需等待后台采集，查询本身不触发历史回填。

- 账号：`account_ids` 用内部数字 ID；省略查询当前身份可见达人号，响应 `data.data.coverage.accounts[].id` 也可用于定位。授权过期但仍绑定时可能可查历史，解绑后不可查。普通 TikTok 或 Seller 授权不能替代带订单读取权限的 Shop 账号授权
- 日期：`start_time/end_time` 同时传 Unix 秒，起点包含、终点不包含，最多 366 天；省略默认近 30 天。按用户时区计算时间戳，`timezone` 不会自动移动已有时间戳
- 详情：从列表复制 `account_id/order_id/create_time`，用同一 `orders` action，指定该账号、精确订单号和包含下单时间的日期范围，移除无关筛选并翻页取齐 SKU。只传订单号仍受近 30 天限制，`selected` 也不会绕过日期、其他筛选或分页
- 分页：`total/page_size` 是 SKU 行数，同一订单可跨页，不能把 total 当订单数。按任务需要限定翻页规模；固定账号、时间、筛选、排序与 page_size，只递增 page，读够 total 或空页停止。超过 1000 页按账号或不重叠时间段拆分；后台可能继续同步，用 `account_id+order_id+sku_id` 去重更新
- 完整性：明细在 `data.data.orders`。空列表仅当 `empty_confirmed=true` 才表示已采范围内无匹配；否则检查账号、日期、筛选和各账号 `range_complete`。非空也要看 coverage；`as_of` 是查询时间，`last_observed_at` 是采集时间，`all_complete` 不保证佣金已最终结算。错误不能当成空数据
- 金额：Decimal 计算，保留各金额自身币种，null/缺失为未知而非零。`unit_price×quantity` 是归因商品金额，不是实付 GMV；退款和退货不重复扣减；总佣金不再叠加标准/广告/奖励组成项；实际佣金不是银行到账凭证。当前商品资料不能覆盖历史价格，原始 attributes 不擅自换算单位，跨币种不直接相加
- 消耗：商业通道每次翻页独立计费，价格以当前 Tool 描述和 usage 为准；会员通道走 SaaS 调用额度，不套商业价格。批量翻页前查 `account_info`，不默认拉完所有历史

## 数据分析（social_analytics）

- 账号维度：粉丝增长、主页访问、整体互动趋势
- 内容维度：单帖播放/点赞/评论/分享，找出表现最好的内容模式
- 产出建议用表格 + 一段结论（什么内容类型在涨、建议多发什么）

## 辅助工具（social_tools）

发布相关的辅助能力（如话题/音乐查询等）。音乐查询触发条件与发布参数衔接按上面的“TikTok 发布音乐策略”执行。

达人选品与橱窗管理：`affiliate_products` 搜索选品广场，佣金率用万分比（1000=10%）；`shop_products` 查询当前 shop/showcase；`showcase_add/remove/top` 会真实修改达人橱窗，执行前列出账号、商品 ID 和目标顺序让用户确认。add 的 HTTP 成功响应仍可能带逐商品 `errors`；remove/top 当前成功响应没有逐商品结果，调用后必须用 shop_products 复查，不能仅凭空 `data` 宣称全部成功。

## 注意

- 发布、回复、删除、解绑、橱窗增删/置顶都是有外部影响的动作：**没有用户明确确认不执行**
- upload_file 返回的访问 URL（cdn_url / signed_url）是给 ai_generate 当参考素材或给用户预览用的；发布用的是 bucket 字段，两者不要混
- 用户要"定时发布"时确认平台是否支持该参数，不支持就明说，不要假装成功
