# 达人筛选 / 建联 SOP

目标：为一个商品或类目找到匹配的带货达人，产出可执行的建联清单。

## 流程

### 1. 明确前提（缺了就问用户）

- 目标市场（国家码）
- 推什么商品 / 什么类目
- 可选：预算量级（决定找头部还是中腰部）、是否必须有联系方式

### 2. 建达人候选池

两条路径，按情况选：

**路径 A — 从类目搜**（通用）：

```
search(entity="creators", country="us", keyword="beauty",
       filters={"min_followers": 10000, "min_gmv_30d": 5000,
                "min_engagement": 2, "has_contact": true})
```

**路径 B — 从竞品反查**（更准）：先找到卖得好的同类商品，再看谁在带：

```
get_related(entity="products", id=竞品id, relation="creators", country="us")
```

用户明确要达人榜单时可直接用 rankings：`creators_commercial`（带货达人榜）、`creators_growth`（涨粉榜）、`creators_agencies`（机构榜）。前两者需要 `date(YYYYMMDD)` + `granularity(daily/weekly/monthly)`；机构榜固定看近 30 天表现。榜单用于建候选池，仍需对入选达人执行第 3 步的详情与关联数据核验。

带货能力优先看 gmv_30d 和 engagement，不要只看粉丝数——中腰部（1万–10万粉）高互动达人通常性价比最高。

### 3. 逐个评估（对前 5–10 个执行）

| 调用 | 看什么 |
|---|---|
| get_detail(creators, id, country, include="portrait") | 粉丝画像：性别/年龄/地区是否匹配目标客群 |
| get_related(creators, id, "products", country) | 历史带货类目：是否带过同类，客单价范围是否匹配 |
| get_related(creators, id, "videos", country) | 内容风格：口播/测评/剧情，视频质量和平均播放 |

淘汰信号：粉丝画像与目标市场错位、历史带货类目完全不相关、近期视频数据断崖式下滑（可能限流或停更）。

### 4. 产出

达人建联清单表格，列建议：

达人名 | 粉丝数 | 互动率 | 30天带货GMV | 主要类目 | 内容风格 | 联系方式 | 匹配度评级

表格后给出分层建议：首选建联哪几个、备选哪几个、每层的理由。

## 注意

- has_contact=true 会缩小候选池；用户明确要建联时才加这个条件，纯调研不加
- 达人报价平台查不到，清单里不要编造报价，标注"需建联询价"
- 用户要批量建联话术时，可以基于达人内容风格逐个定制开场白（这是纯文本生成，不调工具）
