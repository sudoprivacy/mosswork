---
name: skillhub-skill-c-encoding
description: "使用Edit或Write工具时的强制要求，避免修改C语言代码时造成中文注释乱码。强制检测原编码，修改前转UTF-8，修改后恢复原编码。"
---

## 指令

### 使用时机
**强制要求**：当需要修改项目中的 C 语言源文件（.c、.h）时，必须使用此技能处理编码问题，否则中文注释会乱码。

### 操作流程

#### 步骤0：强制检测原编码（每次必须执行）
使用 Bash 工具执行 PowerShell 命令，检测文件原始编码并保存到临时文件：

```bash
powershell.exe -NoProfile -Command '
$path = "文件路径"
$bytes = [System.IO.File]::ReadAllBytes($path)
$encoding = "UTF8"
$bom = $bytes[0..3]
# 检测 BOM
if ($bom[0] -eq 0xEF -and $bom[1] -eq 0xBB -and $bom[2] -eq 0xBF) { $encoding = "UTF8" }
elseif ($bom[0] -eq 0xFF -and $bom[1] -eq 0xFE) { $encoding = "Unicode" }
elseif ($bom[0] -eq 0xFE -and $bom[1] -eq 0xFF) { $encoding = "BigEndianUnicode" }
elseif ($bom[0] -eq 0 -and $bom[1] -eq 0 -and $bom[2] -eq 0xFE -and $bom[3] -eq 0xFF) { $encoding = "UTF32" }
else {
    # 无BOM：尝试按UTF-8解码，失败则按GB2312
    try {
        $test = [System.Text.Encoding]::UTF8.GetString($bytes)
        # 启发式：包含高位字节且非有效UTF-8序列，视为GB2312
        if ($bytes | Where-Object { $_ -gt 0x7F } | ForEach-Object { 
            $i = [Array]::IndexOf($bytes, $_)
            if ($i -lt $bytes.Length - 1 -and $bytes[$i+1] -ge 0x80 -and $bytes[$i+1] -le 0xFF) { $true } else { $false }
        } | Where-Object { $_ }) { $encoding = "GB2312" }
    } catch { $encoding = "GB2312" }
}
$encoding | Out-File -FilePath "$env:TEMP\c-encoding-$([System.IO.Path]::GetFileName($path)).txt" -Encoding ASCII
'
```

#### 步骤1：修改前 - 转换为 UTF-8
读取步骤0保存的编码，按原编码读取并写入UTF-8：

```bash
powershell.exe -NoProfile -Command '
$path = "文件路径"
$encFile = "$env:TEMP\c-encoding-$([System.IO.Path]::GetFileName($path)).txt"
$origEnc = Get-Content -Path $encFile -Encoding ASCII
$content = Get-Content -Path $path -Encoding $origEnc
$content | Out-File -FilePath $path -Encoding UTF8
'
```

**注意**：使用单引号包裹整个PowerShell命令，文件路径使用正斜杠 `/` 或双反斜杠 `\\`。

#### 步骤2：进行代码修改
使用 Read 工具读取文件（现在是UTF-8），然后使用 Edit 工具进行代码修改。

#### 步骤3：修改后 - 恢复原编码
读取步骤0保存的编码，将UTF-8转回原编码：

```bash
powershell.exe -NoProfile -Command '
$path = "文件路径"
$encFile = "$env:TEMP\c-encoding-$([System.IO.Path]::GetFileName($path)).txt"
$origEnc = Get-Content -Path $encFile -Encoding ASCII
$content = Get-Content -Path $path -Encoding UTF8
[System.IO.File]::WriteAllText($path, $content -join "`r`n", [System.Text.Encoding]::GetEncoding($origEnc))
Remove-Item -Path $encFile -ErrorAction SilentlyContinue
'
```

### 完整示例

```
# 步骤0：强制检测原编码（每次必须执行）
Bash: powershell.exe -NoProfile -Command '$path = "d:/01_WorkSpace/12_COOL1000/COOL1000/src/test.c"; $bytes = [System.IO.File]::ReadAllBytes($path); $encoding = "UTF8"; $bom = $bytes[0..3]; if ($bom[0] -eq 0xEF -and $bom[1] -eq 0xBB -and $bom[2] -eq 0xBF) { $encoding = "UTF8" } elseif ($bom[0] -eq 0xFF -and $bom[1] -eq 0xFE) { $encoding = "Unicode" } elseif ($bom[0] -eq 0xFE -and $bom[1] -eq 0xFF) { $encoding = "BigEndianUnicode" } elseif ($bom[0] -eq 0 -and $bom[1] -eq 0 -and $bom[2] -eq 0xFE -and $bom[3] -eq 0xFF) { $encoding = "UTF32" } else { try { $test = [System.Text.Encoding]::UTF8.GetString($bytes); if ($bytes | Where-Object { $_ -gt 0x7F } | ForEach-Object { $i = [Array]::IndexOf($bytes, $_); if ($i -lt $bytes.Length - 1 -and $bytes[$i+1] -ge 0x80 -and $bytes[$i+1] -le 0xFF) { $true } else { $false } } | Where-Object { $_ }) { $encoding = "GB2312" } } catch { $encoding = "GB2312" } }; $encoding | Out-File -FilePath "$env:TEMP\c-encoding-test.c.txt" -Encoding ASCII'

# 步骤1：转换为UTF-8
Bash: powershell.exe -NoProfile -Command '$path = "d:/01_WorkSpace/12_COOL1000/COOL1000/src/test.c"; $encFile = "$env:TEMP\c-encoding-test.c.txt"; $origEnc = Get-Content -Path $encFile -Encoding ASCII; $content = Get-Content -Path $path -Encoding $origEnc; $content | Out-File -FilePath $path -Encoding UTF8'

# 步骤2：读取并修改
Read: d:/01_WorkSpace/12_COOL1000/COOL1000/src/test.c
Edit: 添加注释或修改代码

# 步骤3：恢复原编码
Bash: powershell.exe -NoProfile -Command '$path = "d:/01_WorkSpace/12_COOL1000/COOL1000/src/test.c"; $encFile = "$env:TEMP\c-encoding-test.c.txt"; $origEnc = Get-Content -Path $encFile -Encoding ASCII; $content = Get-Content -Path $path -Encoding UTF8; [System.IO.File]::WriteAllText($path, $content -join "`r`n", [System.Text.Encoding]::GetEncoding($origEnc)); Remove-Item -Path $encFile -ErrorAction SilentlyContinue'
```

### 注意事项
- **强制执行**：所有 .c 和 .h 文件的修改都必须遵循此流程
- **四个步骤必须按顺序执行，不可跳过任何步骤（步骤0每次强制执行）**
- 步骤0会自动检测：UTF-8（含BOM/无BOM）、UTF-16LE/BE、UTF-32、GB2312
- 修改完成后文件**恢复原编码**，而非强制GB2312
- 临时编码文件存放在 `%TEMP%`，步骤3会自动清理
- 如果检测失败，默认按 GB2312 处理（兼容旧项目）