# 保护清单（Protection Manifest）

> 执行任何清理动作前**必须先读本文件**，并实测核验每一项的存在性与大小。
> 本清单基于 2026-09-02 的一次真实清理实战沉淀，保护对象以实测值为准。

---

## 一、硬保护（Hard Protect）——任何档位下都不触碰

| 对象 | 典型路径 | 实测体积 | 说明 |
|------|----------|----------|------|
| WorkBuddy 对话主库 | `%USERPROFILE%\.workbuddy\workbuddy.db` | 6.9 MB | **对话记录本体，最高优先级** |
| WorkBuddy 会话本体 | `%USERPROFILE%\.workbuddy\workspace\sessions\<uuid>\` | 每会话约 1 MB | 见下方「关键例外」 |
| WorkBuddy 核心运行时 | `%USERPROFILE%\.workbuddy\binaries\`、`skills\` | 合计约 3–5 GB | 删了 WorkBuddy 会直接失效 |
| Obsidian 配置 | `%APPDATA%\obsidian\` | 46 MB | 含插件与布局配置 |
| Obsidian 保险库 | `D:\obsidian\`（以实际为准） | 351 MB | **用户的知识资产** |
| Wiki | `D:\LLM_Wiki\`（以实际为准） | 246 MB | 用户的知识资产 |
| 微信文件 | `%USERPROFILE%\xwechat_files\` | 1.2–3.7 GB | 聊天记录关联，只迁移不删 |
| 用户文档 | 桌面 / 文档 / 图片 / 下载 | 按实测 | 个人数据 |

### 关键例外：`modify_backup` 不是对话数据

`sessions\<uuid>\modify_backup\` 是 WorkBuddy 的「文件修改前备份」目录。

**判定流程**：

1. 体积判据：正常会话约 1 MB。若某会话目录 >500 MB，进入下一步。
2. 内容判据：查看内部文件类型。若是 `Qt5WebEngineCore.dll`、`qbcore.dll`、`DocConvert.zip`、
   浏览器缓存图片等**第三方程序文件** → 确认为被删缓存的副本。
3. 处置：可清理（建议先移 D 盘暂存）。

**保守替代判据**（当无法确认来源时）：只清理能明确追溯到「本轮已删除缓存路径」的条目，其余保留。

> 实测案例：2026-09-02 清理中，该目录一度膨胀到 4595 MB（13471 个文件），
> 内容全部是刚被清掉的 QQ 浏览器与腾讯文档缓存副本。清掉后 `.workbuddy` 从 9.56 GB 回落到 5.07 GB。

---

## 二、软保护（Soft Protect）——需用户确认

| 对象 | 风险 | 说明 |
|------|------|------|
| Python 用户包 | 高 | `%APPDATA%\Python\`（约 2.6 GB）。移动会让 pip 环境直接失效，**默认不动** |
| 应用配置目录 | 中 | 各类 AppData\Roaming 下的程序配置。清理可能导致应用状态错乱 |
| Program Files / Program Files (x86) | 高 | 移动会破坏注册表与快捷方式，**只报告不动** |
| Windows 目录 | 高 | 同上 |

---

## 三、可安全清理（Safe to Clean）

| 对象 | 典型路径 | 说明 |
|------|----------|------|
| puppeteer/playwright 残留 | `%TEMP%\puppeteer_dev_chrome_profile-*` | **本 Skill 头号目标**，官方至今未修复 |
| 安装包 | `%TEMP%\*.exe` | 安装完成即废 |
| 安装日志 | `%TEMP%\Setup Log*` | 每条可达 4 MB |
| 安装残留目录 | `%TEMP%\QMI*`、`%TEMP%\uninst*` | 一次性目录 |
| WorkBuddy traces/logs | `~/.workbuddy\traces\`、`logs\` | 运行轨迹，可清理（注意：清理会失去排障依据） |
| 应用缓存 | 浏览器/播放器/协作工具缓存 | 建议移 D 盘暂存 |

---

## 四、需管理员权限（只报告，不执行）

- 系统还原卷影副本：`vssadmin list shadowstorage`
- `pagefile.sys` / `hiberfil.sys` 调整
- WinSxS 组件存储清理
- Windows Update 缓存

> 本 Skill **一律不执行**上述项目，仅在报告中提示用户以管理员身份自行处理。

---

## 五、保护清单自检命令

每次执行前跑一遍，确认保护对象完好：

```bash
for p in "$USERPROFILE/.workbuddy" "$APPDATA/obsidian" "/d/obsidian" "/d/LLM_Wiki" "$USERPROFILE/xwechat_files"; do
  [ -e "$p" ] && du -sm "$p" 2>/dev/null | awk -v q="$p" '{printf "  %8.0f MB  %s\n", $1, q}' || echo "  ⚠️ 缺失: $p"
done
ls -la "$USERPROFILE/.workbuddy/workbuddy.db" 2>/dev/null
```

**任何一项显示"缺失" → 立即停止清理并报告用户。**
