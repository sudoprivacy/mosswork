# 扫描目标清单（Scan Targets）

> 社区可扩展：发现新的空间吞噬者 → 在对应分类下追加一行 → 记录来源与判据。
> 本表所有路径均经 2026-09-02 实测验证（Windows 11 / WorkBuddy 环境）。

---

## 分类 A · Agent 运行时残留（本 Skill 独有，通用工具不覆盖）

| 路径模式 | 典型体积 | 判据 | 风险 |
|----------|----------|------|------|
| `%TEMP%\puppeteer_dev_chrome_profile-*` | 每个 1–2 GB，聚合可达 14.5 GB+ | 912 个目录 / 10.7 万文件（实测） | 低，**删前必须确认无浏览器进程** |
| `%TEMP%\playwright_chromiumdev_profile-*` | 同上 | 同上 | 低，同上 |
| `%TEMP%\playwright-artifacts-*` | 中等 | Playwright 产物目录 | 低 |
| `%TEMP%\.org.chromium.Chromium.*` | 中等 | Chromium 原生临时目录 | 低 |
| `~/.workbuddy\workspace\sessions\<id>\modify_backup\` | 异常时 4.6 GB+ | 见 protection-manifest 例外条款 | 中，需按判据区分 |
| `~/.agent-browser\` | 841 MB（实测） | Agent 浏览器缓存 | 低 |
| `~/.workbuddy\traces\` | 1.9 GB（实测） | 运行轨迹 | 中，清理后失去排障依据 |
| `~/.workbuddy\logs\` | 336 MB（实测） | 运行日志 | 低 |
| `%TEMP%\node-compile-cache\` | 数百 MB | Node 编译缓存 | 低 |

**背景**：puppeteer/playwright 残留是**官方至今未修复的已知问题**（GitHub 多个 issue 长期挂起）。
社区报告普遍达 20–25 GB，有案例因 `/tmp` 打满导致服务器无法启动。
本 Skill 把它列为头号清理目标，这是相对通用工具的核心差异化。

---

## 分类 B · 系统与应用垃圾（通用工具也覆盖）

| 路径模式 | 说明 | 风险 |
|----------|------|------|
| `%TEMP%\*.exe` | 安装包（实测 449 MB + 378 MB） | 低 |
| `%TEMP%\Setup Log*` | 安装日志（实测 25 条共 73 MB） | 低 |
| `%TEMP%\QMI*` | 安装残留（实测 101 MB） | 低 |
| `%TEMP%\uninst*` | 卸载程序临时文件 | 低 |
| 浏览器缓存 | Chrome / Edge / QQ 浏览器 | 低 |
| 播放器缓存 | QQLive 等（实测 1.2 GB） | 低 |
| 协作工具缓存 | 腾讯文档桌面版（实测 1.9 GB） | 中，建议应用内清理 |

---

## 分类 C · 可迁移用户数据

| 对象 | 典型体积 | 迁移方式 | 是否可代劳 |
|------|----------|----------|------------|
| 微信文件 | 1.2–3.7 GB | 微信「设置 → 文件管理」改路径 | ❌ 只给步骤 + 先备份 |
| 图片库 | 1.7 GB | 文件夹「属性 → 位置」移动 | ❌ 需用户 GUI 操作（`reg` 常被禁用） |
| 下载目录 | 按实测 | 同上 | ❌ 同上 |
| Obsidian 保险库 | 351 MB | Obsidian 内切换保险库路径 | ⚠️ 建议由用户在应用内操作 |

---

## 分类 D · 勿动（只报告）

| 对象 | 实测体积 | 原因 |
|------|----------|------|
| `C:\Windows` | 11.3 GB | 移动会破坏系统 |
| `C:\Program Files` / `(x86)` | 6.1 / 4.9 GB | 移动会破坏注册表与快捷方式 |
| `%APPDATA%\Python` | 2.6 GB | 移动会让 pip 环境失效 |
| `C:\ProgramData` | 1.6 GB | 系统级数据 |

---

## 扫描时必须排除的自引用链接

Windows 在用户目录下维护了若干指向本体的 junction，扫描会把它们**重复计入**，导致总量虚高一倍：

```
Application Data   → AppData\Roaming
Local Settings     → AppData\Local
My Documents       → Documents
Cookies            → AppData\Local\Microsoft\Windows\INetCookies
NetHood / PrintHood / Recent / SendTo / Templates / Start Menu
```

**处置**：`du` 扫描时排除这些条目，或以 `AppData\` 的实测值为准，不要累加链接目录。

---

## 快速扫描命令集

```bash
# 用户目录一级（>100 MB）
cd "$USERPROFILE" && for d in .[a-z]* */; do
  s=$(du -sm "$d" 2>/dev/null | cut -f1); [ -n "$s" ] && [ "$s" -gt 100 ] && printf "%8.0f MB  %s\n" "$s" "$d"
done | sort -rn

# AppData 二级
cd "$USERPROFILE/AppData" && du -sm */ | sort -rn | head -10

# Temp 内按目录聚合真凶
cd "$TEMP" && find . -mindepth 1 -type f -printf "%s %h\n" 2>/dev/null \
  | awk '{split($2,a,"/"); k=a[2]; s[k]+=$1} END {for(x in s) printf "%.0f MB  %s\n", s[x]/1048576, x}' \
  | sort -rn | head -12

# puppeteer 残留量化
cd "$TEMP" && ls -d puppeteer_dev_chrome_profile-* 2>/dev/null | wc -l
```

---

## 贡献新条目

发现新的空间吞噬者时，追加一行并注明：
`| 路径模式 | 典型体积 | 判据 | 风险 | 发现日期 |`

同时在 `MISTAKES.md` 记录：为什么之前的扫描没发现它。
