## Description: <br>
Guides agents through APIDot Grok Imagine Video 1.5 image-to-video workflows, including docs routing, async task handling, polling, webhooks, and API key safety. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[jiehao71727](https://clawhub.ai/user/jiehao71727) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to plan APIDot Grok Imagine Video 1.5 integrations, route to current APIDot documentation, and handle async video generation workflows safely. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: APIDot API keys could be exposed if copied into browser code, public repositories, logs, screenshots, or chat output. <br>
Mitigation: Keep APIDOT_API_KEY in server-side environment variables or a backend secret manager and avoid echoing credentials in generated guidance. <br>
Risk: Private prompts, source media URLs, generated video URLs, or callback URLs could leak through logging or debugging output. <br>
Mitigation: Avoid logging private prompts, media URLs, generated URLs, callback URLs, and other sensitive workflow data. <br>
Risk: Model-specific request fields, pricing, availability, or limits may change after the skill release. <br>
Mitigation: Verify current request fields, pricing, availability, and limits in the live APIDot docs before making real API calls. <br>


## Reference(s): <br>
- [Local APIDot Grok Imagine Video 1.5 Reference](references/api.md) <br>
- [APIDot Docs](https://apidot.ai/docs) <br>
- [Grok Imagine Video 1.5 Model Page](https://apidot.ai/models/grok-imagine-video-1-5) <br>
- [Grok Imagine Video 1.5 API Docs](https://apidot.ai/docs/grok-imagine-video-1-5) <br>
- [APIDot Webhooks](https://apidot.ai/docs/webhooks) <br>
- [APIDot Examples](https://github.com/APIDotAI/apidot-examples) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, code, configuration] <br>
**Output Format:** [Markdown guidance with optional code and configuration snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Documentation-only skill with no executable files, bundled API client, install automation, network calls, or stored credentials.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
