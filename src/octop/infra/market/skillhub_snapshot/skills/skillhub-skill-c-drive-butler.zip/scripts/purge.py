#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 专有许可（Source-Available Proprietary）
# Copyright (c) 2026 淮安市恒与变电子商务有限公司（英文简称 HaConvar / convar）. All rights reserved.
# 仅授权个人自用与内部运行、源码审计；禁止未经书面授权的再分发与商业使用。
# 完整条款见仓库根目录 LICENSE 的 A 部分（本文件属于 A 部分"核心引擎"）。
#
r"""逐文件删除器：宿主批量删除限流时的急救工具。
用法: py purge.py <目录1> [目录2 ...]

只接受"具体缓存目录"（如 AppData\\Local\\SomeApp\\Cache）。防护：

0. 路径规范化：剥 \\?\ 前缀 + 8.3 短名展开（PROGRA~1 -> Program Files）。
   红线全部按"展开后的长名"比较；短名无法展开时保守拒绝。
1. 红线根（防止手滑或参数拼接事故）：
   驱动器根、C:\\Users、用户主目录、桌面/下载/文档/图片/视频/音乐顶层
   精确命中即拒；Windows、Program Files(含 x86/W6432)、ProgramData
   以及其他用户的家目录——整棵子树拒绝，任何后代路径都不放行。
2. 缓存准入：其余目标必须通过与 scan/clean 完全相同的
   butler.cache_cleanable_reason() 单口径校验（缓存名特征、个人目录
   强特征、git 仓库、Package Cache、系统/工作目录排除段）。
3. 链接边界：junction/符号链接是两个命名空间之间
   的别名——名为 Cache 的 junction 可指向受保护目录，字符串红线判合法、
   os.walk 却会走进目标。遍历时 reparse point 边界绝不穿越：目标根本身
   是链接就只摘链接，子目录里的链接一律剪除并单独摘链，链接目标里的
   一个文件都不会被删。

实际删除使用的路径与安全检查使用的路径是同一个规范化结果；
>260 字符的深路径经 \\?\ 扩展前缀访问。purge.py 不是"任意目录删除器"；
非缓存名的目录请走人工确认后的其他流程，本工具不放行。
"""
import ctypes
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import butler as _butler  # noqa: E402  复用缓存准入单口径，禁止在本文件另立规则

# 8.3 短名段形态：1-6 个非点字符 + ~ + 1-2 位数字，可选 .扩展名(<=3)
_SHORT83_RE = re.compile(r"^[^.\\/]{1,6}~\d{1,2}(?:\.[^.\\/]{1,3})?$", re.I)


def _get_long_path_name(s):
    """GetLongPathNameW：把含 8.3 短名的路径展开为长名（路径须存在）。

    失败（不存在/非 Windows/API 异常）原样返回，由调用方走保守拒绝。
    """
    if os.name != "nt":
        return s
    try:
        k32 = ctypes.windll.kernel32
        need = k32.GetLongPathNameW(str(s), None, 0)
        if not need or need >= 32768:
            return s
        buf = ctypes.create_unicode_buffer(need)
        if k32.GetLongPathNameW(str(s), buf, need):
            return buf.value
    except Exception:
        pass
    return s


def _exists_lenient(p):
    r"""存在性判断；普通形式失败时再用 \\?\ 扩展前缀试一次（深路径）。"""
    if os.path.exists(p):
        return True
    try:
        return os.path.exists(_butler.win32_extended_path(p))
    except OSError:
        return False


def norm(p):
    s = os.path.abspath(str(p))
    # 剥掉 Windows 长路径前缀，否则 \\?\C:\Users\... 会和红线表对不上而漏拦
    p_unc = "\\\\?\\UNC\\"
    p_long = "\\\\?\\"
    if s.startswith(p_unc):
        s = "\\\\" + s[len(p_unc):]
    elif s.startswith(p_long):
        s = s[len(p_long):]
    s = os.path.normcase(os.path.normpath(s))
    # 8.3 短名展开：红线根按长名建立，PROGRA~1/PROGRA~3 这类
    # 别名不展开就会在字符串前缀比较中漏过子树红线。purge 只删存在的
    # 路径，所以按存在性门控展开即可全覆盖；不存在的路径稍后由 main 丢弃，
    # 但短名段若残留仍会在 dangerous_reason 中被保守拒绝。
    if _exists_lenient(s):
        long = _get_long_path_name(s)
        if long:
            s = os.path.normcase(os.path.normpath(long))
    return s


def _has_unresolved_shortname(p):
    return any(_SHORT83_RE.match(seg) for seg in re.split(r"[\\/]", p) if seg)


def dangerous_reason(raw):
    """目标不允许删除时返回原因，允许时返回 None。

    第零层：8.3 短名无法展开即拒；
    第一层：红线根精确拒绝 + 系统/安装/他人目录整棵子树拒绝；
    第二层：复用 butler.cache_cleanable_reason，与 scan/clean 同一把尺子。
    """
    p = norm(raw)

    # 0. 仍残留 8.3 段：短名没展开成功（路径不存在或 API 失败）。
    #    purge 只接受明确的长名缓存目录，短名别名一律保守拒绝。
    if _has_unresolved_shortname(p):
        return "8.3 短名路径无法解析，拒绝"

    drive_root = os.path.splitdrive(p)[0] + os.sep
    up = norm(os.environ.get("USERPROFILE", os.path.expanduser("~")))

    # 1a. 精确命中即拒（这些路径本身）
    exact = [
        (drive_root, "驱动器根目录"),
        (norm(r"C:\Users"), "所有用户目录的父目录"),
        (up, "当前用户主目录"),
    ]
    for sub, cn in [("Desktop", "桌面"), ("Downloads", "下载"),
                    ("Documents", "文档"), ("Pictures", "图片"),
                    ("Videos", "视频"), ("Music", "音乐")]:
        exact.append((norm(os.path.join(up, sub)), "个人目录顶层(%s)" % cn))
    for base, why in exact:
        if p == base:
            return why

    # 1b. 系统/安装地盘：整棵子树拒绝，任何后代路径都不放行
    #     （purge 是手动急救工具，这些地盘里的缓存只由 butler clean 的
    #     固定类别流程处理，不接受手工指定路径）
    subtree = [
        (norm(os.environ.get("WINDIR", r"C:\Windows")), "Windows 系统目录子树"),
        (norm(os.environ.get("ProgramFiles", r"C:\Program Files")),
         "Program Files 应用安装目录子树"),
        (norm(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")),
         "Program Files (x86) 应用安装目录子树"),
        (norm(os.environ.get("ProgramW6432", "")),
         "Program Files 应用安装目录子树"),
        (norm(os.environ.get("ProgramData", r"C:\ProgramData")),
         "ProgramData 系统/应用数据目录子树"),
    ]
    for base, why in subtree:
        if base and (p == base or p.startswith(base + os.sep)):
            return why

    # 1c. C:\Users 下不属于当前用户名的，是其他用户的个人目录。
    #     只在 USERPROFILE 直接位于 C:\Users 下时启用（真实 Windows 总是
    #     如此）；重定向/沙盒环境（家目录在别的盘或临时目录里）跳过本检查，
    #     避免把物理上落在 C:\Users 下的沙盒误判成"他人目录"。
    users = norm(r"C:\Users")
    if up.startswith(users + os.sep) and p.startswith(users + os.sep):
        my_user = up[len(users) + 1:].split(os.sep)[0]
        target_user = p[len(users) + 1:].split(os.sep)[0]
        if target_user and target_user != my_user:
            return "其他用户的个人目录"

    # 2. 缓存准入单口径：缓存名特征 / 个人目录强特征 / git / Package Cache
    #    / 系统与工作目录排除段，全部与 scan、clean 保持一致。
    #    allow_reparse_root=True：purge 对显式点名的 junction 根有独立的
    #    只摘链实现（见 main 删除通道），链接本身允许作为操作目标；
    #    8.3 展开与红线子树（本函数 0/1 层）照旧生效，口子只开给链接根。
    return _butler.cache_cleanable_reason(p, allow_reparse_root=True)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    raw_args = [p for p in argv if not p.startswith("-")]
    if not raw_args:
        print("无有效目标")
        return 0

    # 入口处规范化一次：安全检查与实际删除必须用同一个路径变量
    # （短名展开/前缀剥离后的长名），杜绝检查与执行路径不一致
    targets = [(raw, norm(raw)) for raw in raw_args]

    # 任何一个目标命中红线就整单拒绝，不执行任何删除
    blocked = []
    for raw, canonical in targets:
        why = dangerous_reason(raw)
        if why:
            blocked.append((raw, canonical, why))
    if blocked:
        print("!! 拒绝执行：以下目标受 purge.py 红线保护")
        for raw, canonical, why in blocked:
            # 同时给输入原样与规范化结果，短名/相对路径手法一目了然
            print("   [%s] %s -> %s" % (why, raw, canonical))
        print("   本工具只清具体缓存目录，绝不清空个人目录或系统目录本身。")
        return 2

    paths = [canonical for _, canonical in targets if _exists_lenient(canonical)]
    if not paths:
        print("无有效目标（路径均不存在）")
        return 0

    freed = 0
    nfile = 0
    fail = 0
    t0 = time.time()

    for root in paths:
        # 根本身是 junction/符号链接：红线只能看到链接位置（字符串世界），
        # 链接指向谁是文件系统世界的事。只摘链接本身，绝不走进目标
        if _butler.is_reparse_point(root):
            ok = _butler.unlink_dir_link(root)
            print("[%s] reparse point（junction/符号链接），仅移除链接本身，"
                  "不进入目标目录 %s" % (root, "OK" if ok else "失败"),
                  flush=True)
            if not ok:
                fail += 1
            continue
        files = []
        dirs = []
        links = []
        # 遍历根加 \\?\ 扩展前缀：根可能不长但子孙 >260；
        # reparse point 子目录一律剪除：链接目标不属于本树，
        # 绝不能 d[:] = [] 却不摘链——会导致链接残留；链接收集后单独删。
        # 历史教训：普通子目录不许剪枝（曾导致只删了顶层文件）。
        walk_root = _butler.win32_extended_path(root)
        for r, d, fs in os.walk(walk_root, topdown=True,
                                onerror=lambda e: None):
            links.extend(_butler.prune_reparse_dirs(r, d))
            for f in fs:
                files.append(os.path.join(r, f))
            dirs.append(r)
        total = len(files)
        print("[%s] %d 个文件, %d 个链接(只摘链), 开始删除"
              % (root, total, len(links)), flush=True)
        for i, f in enumerate(files):
            try:
                sz = os.path.getsize(f)
            except OSError:
                continue
            try:
                os.remove(f)
                freed += sz
                nfile += 1
            except Exception:
                fail += 1
            if (i + 1) % 500 == 0:
                print("   已删 %d/%d, 释放 %.2f GB, 用时 %.0fs"
                      % (i + 1, total, freed / 2 ** 30, time.time() - t0), flush=True)
        # 摘链接（junction/目录符号链接只删链接，不碰目标）
        for lk in links:
            if not _butler.unlink_dir_link(lk):
                fail += 1
        # 清理空目录（自底向上；链接已摘除，不会出现在 dirs 里）
        for d in sorted(dirs, key=len, reverse=True):
            try:
                os.rmdir(d)
            except OSError:
                pass

    print("完成: 删除 %d 个文件, 释放 %.2f GB, 失败 %d, 用时 %.0fs"
          % (nfile, freed / 2 ** 30, fail, time.time() - t0), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
