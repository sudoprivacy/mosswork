#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 专有许可（Source-Available Proprietary）
# Copyright (c) 2026 淮安市恒与变电子商务有限公司（英文简称 HaConvar / convar）. All rights reserved.
# 仅授权个人自用与内部运行、源码审计；禁止未经书面授权的再分发与商业使用。
# 完整条款见仓库根目录 LICENSE 的 A 部分（本文件属于 A 部分"核心引擎"）。
#
r"""
C盘管家 (c-drive-butler) - Windows 磁盘瘦身引擎
==============================================
四个动作，按此顺序做：

  reclaim 隐藏占用回收：$RECYCLE.BIN / Windows.old / 更新缓存（收益最高，先跑它）
  scan    只读体检：磁盘水位 + 分类占用 + TOP大文件 + 可清理缓存清单（绝不改任何东西）
  clean   清理垃圾：临时文件 / 包管理缓存 / 浏览器缓存 / 崩溃转储 / 软件缓存 / 回收站
  migrate 大文件搬家：把用户目录里的大文件迁到 D 盘，原位留快捷方式

铁律：
  1. scan 永远只读
  2. clean / migrate 默认 dry-run（只列清单），必须显式加 --execute 才真动手
  3. clean 只删"可再生数据"（缓存/临时/转储），绝不碰用户文档
  4. migrate 只动用户目录（下载/桌面/文档/图片/视频/音乐），不动 AppData 和系统目录
  5. 每次执行都落一份 Markdown 报告到 ~/c-drive-butler-reports/
  6. 档位（edition）：免费技能版只门控深度清理与大文件搬家的"执行"，
     预览/体检/reclaim/固定类别清理永久免费；门控在引擎内部统一生效

用法（Windows 上用 py 启动器；直接敲 python 可能命中应用商店占位符）：
  py butler.py reclaim                       隐藏占用回收预览（建议第一步）
  py butler.py reclaim --execute --yes       真回收（回收站/更新缓存/Windows.old）
  py butler.py scan                          默认范围（个人目录 + AppData + ProgramData）
  py butler.py scan --scope all              全盘（慢，2-5 分钟）
  py butler.py scan --top 40                 TOP 大文件数量
  py butler.py clean                         预览可清理项
  py butler.py clean --execute --yes         真清理
  py butler.py clean --execute --yes --no-recycle-bin   跳过清回收站
  py butler.py migrate                       预览迁移清单
  py butler.py migrate --execute --target E: --yes      真迁移到 E 盘
  py butler.py migrate --min-size 500        只搬大于 500MB 的文件（默认 500）
"""

import os
import re
import sys
import json
import time
import shutil
import argparse
import functools
import subprocess
import heapq
import collections
import ctypes
from ctypes import wintypes
from pathlib import Path
from datetime import datetime

VERSION = "1.0.1"

# --json 模式：静默人话输出，命令结束后由 main 打印一份结构化结果
JSON_MODE = False
LAST_RESULT = {}

# 控制台可能走 GBK，只用 ASCII 符号，避免 UnicodeEncodeError
TAG_PREVIEW = "[PREVIEW]"
TAG_CLEAN = "[CLEAN]  "
TAG_SKIP = "[SKIP]   "
TAG_MOVE = "[MOVE]   "
TAG_INFO = "[INFO]   "
TAG_LOCK = "[PRO]    "


# ============ 版本档位（free / pro） ============
#
# 免费技能版与付费客户端共用同一份引擎，档位只决定两处 Pro 执行门：
#   - clean 的深度项（scan 发现的软件缓存目录 + 大户专项）执行
#   - migrate 执行
# 预览、scan、reclaim、固定类别清理（临时文件/浏览器缓存/回收站等）在 free
# 档全部开放。
#
# 档位单一配置源，优先级从高到低（任何代码只允许读 edition_info()）：
#   1. 环境变量 C_DRIVE_BUTLER_EDITION=free|pro（测试/排障用）
#   2. 技能包根目录标记文件 EDITION.FREE（免费分发包由打包脚本生成；
#      首行可写客户端落地页 URL，第二行起可写自定义引导语）
#   3. 默认 pro（研发主干 / 付费客户端）
EDITION_ENV = "C_DRIVE_BUTLER_EDITION"
EDITION_FREE_MARKER = "EDITION.FREE"
PRO_FEATURE_DEEP_CLEAN = "deep_clean"
PRO_FEATURE_MIGRATE = "migrate"


@functools.lru_cache(maxsize=1)
def edition_info():
    r"""返回 {"edition": "free"|"pro", "pro_url": str, "note": str}。

    结果做了缓存；测试中切换环境变量后必须 edition_info.cache_clear()。
    """
    marker = Path(__file__).resolve().parent.parent / EDITION_FREE_MARKER
    env = os.environ.get(EDITION_ENV, "").strip().lower()
    edition = env if env in ("free", "pro") else \
        ("free" if marker.is_file() else "pro")
    pro_url, note = "", ""
    if edition == "free" and marker.is_file():
        try:
            raw = marker.read_text(encoding="utf-8").splitlines()
        except OSError:
            raw = []
        if raw:
            # Windows PowerShell 5.1 的 utf8 默认带 BOM，首行 URL 必须剥掉
            pro_url = raw[0].lstrip("\ufeff").strip()
            note = "\n".join(raw[1:]).strip()
    return {"edition": edition, "pro_url": pro_url, "note": note}


def is_free_edition():
    return edition_info()["edition"] == "free"


def pro_upgrade_text(feature=None):
    """Pro 门控统一引导文案（控制台 / Markdown / HTML / JSON 共用一个出处）。"""
    lead = {PRO_FEATURE_MIGRATE: "大文件搬家",
            PRO_FEATURE_DEEP_CLEAN: "深度清理"}.get(
        feature, "深度清理与大文件搬家")
    info = edition_info()
    head = "%s为客户端版（Pro）功能" % lead
    if info["pro_url"]:
        return "%s，了解与获取：%s" % (head, info["pro_url"])
    if info["note"]:
        return "%s。%s" % (head, info["note"])
    return "%s，客户端版正在开发中，免费版可继续使用全部预览与固定类别清理。" % head


def out(text=""):
    if JSON_MODE:
        return
    try:
        print(text)
    except UnicodeEncodeError:
        print(text.encode("ascii", "replace").decode("ascii"))


def emit(payload):
    """登记本命令的结构化结果（--json 时由 main 统一打印）。"""
    LAST_RESULT.clear()
    LAST_RESULT.update(payload)


def fmt_size(num):
    # 清理途中后台程序可能正在写盘，真实到账差值为负很常见；
    # 先取绝对值再套负号，否则会打印出 "+-884736.0 B" 这类天文数字
    num = float(num)
    neg = num < 0
    num = abs(num)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if num < 1024.0:
            text = "%.1f %s" % (num, unit)
            return ("-" + text) if neg else text
        num /= 1024.0
    text = "%.1f PB" % num
    return ("-" + text) if neg else text


def fmt_delta(num):
    """带符号的空间差值：+1.7 GB / -864.0 KB / 0.0 B。"""
    if num > 0:
        return "+" + fmt_size(num)
    return fmt_size(num)


# ============ 缓存识别策略 ============
#
# 三条血泪教训（v2.1 安全修复）：
# 1) 旧版 endswith("log") 把 catalog / dialog / myblog / analog 统统判成日志目录 ——
#    这些可能是应用数据目录，删掉就是事故。短词必须按"词"匹配
#    （分隔符或驼峰边界），不能裸 endswith。实测：
#      catalog/dialog/epilog -> 旧规则 True（错），新规则 False
#      GPUCache / UBALog / Code Cache / npm-cache -> 新旧都 True（对）
# 2) 个人目录（桌面/下载/文档…）里用户可能自建 tmp/temp 工作目录，
#    同一套启发式会把它们当垃圾删掉。个人目录只认"应用运行时缓存"强特征，
#    AppData/系统目录才放开完整启发式。
# 3) Package Cache 是 MSI/Burn 的卸载/修复缓存（ProgramData 和 AppData\Local
#    各有一份），名字带 cache 但绝对不能删，全局禁判。

# 完整启发式（仅限 AppData / ProgramData / Windows 等"应用与系统地盘"）
# 注意：裸 "gpu" / "crash" 不许进 EXACT —— 真有软件的数据目录恰好叫 gpu，
# 整棵删掉就是事故；GPUCache 能靠分词 [gpu,cache] 命中最后一个词 cache，
# CrashDumps 同理命中 dumps，收益不丢、风险归零。
CACHE_WORD_EXACT = frozenset([
    "cache", "temp", "tmp", "log", "logs", "dumps",
    "shader", "crashpad", "ulog", "webviewcache", "thumbcache",
])
CACHE_WORD_LAST = frozenset([
    "cache", "temp", "tmp", "log", "logs", "dumps", "shader",
])
CACHE_CONTAINS = (
    "cachestorage", "service worker", "code cache", "blob_storage",
    "session storage", "gecko_cache", "remote_resource_cache", "crash dump",
    "gpucache", "weappcache", "cachedata", "cacheddata", "crashreport", "shadercache",
)

# 个人目录强特征：只认应用运行时缓存，裸 tmp/temp/gpu 一律不认
PERSONAL_WORD_LAST = frozenset(["cache", "log", "logs", "dumps"])
PERSONAL_WHOLE = frozenset([
    "gpucache", "webviewcache", "weappcache", "thumbtemp", "thumbcache",
    "crashpad", "ulog", "cachestorage", "crashdumps",
])

# 全局禁判：即使在 AppData 里也不能当缓存删（键为小写全名）
CACHE_NAME_DENY = frozenset(["package cache"])

# 非字母数字即分隔符；额外切出驼峰边界：GPUCache -> [gpu, cache]
_TOKEN_SPLIT = re.compile(
    r"[^0-9a-zA-Z]+|(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])"
)


def _name_tokens(name):
    return [p.lower() for p in _TOKEN_SPLIT.split(name) if p]


def is_cache_dirname(name):
    """完整启发式：目录名是否像缓存（仅用于 AppData/系统地盘）。"""
    low = name.lower()
    if low in CACHE_NAME_DENY:
        return False
    if low in CACHE_WORD_EXACT:
        return True
    toks = _name_tokens(name)
    if toks and toks[-1] in CACHE_WORD_LAST:
        return True
    return any(w in low for w in CACHE_CONTAINS)


def is_personal_cache_dirname(name):
    """个人目录专用的严格判定：宁可漏判，不可误伤用户自建目录。"""
    low = name.lower()
    if low in CACHE_NAME_DENY:
        return False
    if low in PERSONAL_WHOLE:
        return True
    toks = _name_tokens(name)
    if toks and toks[-1] in PERSONAL_WORD_LAST:
        return True
    return any(w in low for w in CACHE_CONTAINS)


# 缓存清理时排除（自身/系统/显卡驱动/引擎安装目录，误清代价大）。
# 裸名按"路径段相等"匹配（workbuddy 不再误伤 myworkbuddy 这类目录），
# 带斜杠的按锚定子串匹配。cocos 必须带 ProgramData 前缀：
# 那是引擎资源库（SAFETY 红线，删了编辑器起不来），但用户项目自身的
# cocos 缓存在个人目录下，走严格判定，不受这里影响。
CACHE_EXCLUDE_SEGMENT = frozenset(["workbuddy", "microsoft", "nvidia"])
CACHE_EXCLUDE_ANCHORED = ("\\uv\\", "\\windows\\", r"\programdata\cocos")


def in_excluded_path(low):
    """受保护路径判定：裸名按目录段相等，锚定项按完整子串。"""
    if CACHE_EXCLUDE_SEGMENT & {seg.lower() for seg in re.split(r"[\\/]", low) if seg}:
        return True
    return any(anchor in low for anchor in CACHE_EXCLUDE_ANCHORED)

# 迁移源目录：用户目录名 -> 目标子目录名（中文分类）
MIGRATE_SOURCES = {
    "Downloads": "下载",
    "Desktop": "桌面",
    "Documents": "文档",
    "Pictures": "图片",
    "Videos": "视频",
    "Music": "音乐",
}

REPORT_DIR = Path(os.environ.get("USERPROFILE", ".")) / "c-drive-butler-reports"


def user_profile():
    return Path(os.environ.get("USERPROFILE", str(Path.home())))


def local_appdata():
    return Path(os.environ.get("LOCALAPPDATA", ""))


def roaming_appdata():
    return Path(os.environ.get("APPDATA", ""))


def windir():
    return Path(os.environ.get("WINDIR", r"C:\Windows"))


def drive_of(path):
    return str(path)[:2].upper()


# ============ 缓存路径准入（scan 报表与 clean 共用同一口径） ============

def norm(p):
    return os.path.normcase(os.path.normpath(str(p)))


def win32_extended_path(path):
    r"""给 Windows 绝对路径加 \\?\ 扩展长度前缀，让 fs API 支持 >260 深路径。

    - 本地绝对路径 C:\\a\\b -> \\\\?\\C:\\a\\b
    - UNC \\\\server\\share  -> \\\\?\\UNC\\server\\share
    - 已是扩展前缀/非 Windows/相对路径原样返回
    注意：扩展前缀会关闭 . / .. 与斜杠的自动转换，调用方必须先 normpath；
    专门用于"只做文件系统操作"的场合（遍历/计数/删除），不要拿去做
    报表展示或与 Path.parts 相关的匹配。
    """
    s = str(path)
    if os.name != "nt" or not s:
        return s
    if s.startswith("\\\\?\\"):
        return s
    s = os.path.normpath(s)
    if s.startswith("\\\\"):  # UNC
        return "\\\\?\\UNC\\" + s.lstrip("\\")
    if os.path.isabs(s):
        return "\\\\?\\" + s
    return s


# ============ reparse point（junction/符号链接/mount point）边界 ============
#
# 红线：安全准入按"路径字符串"判定，而 os.walk 按
# 文件系统实体遍历——junction 是两个命名空间之间的别名，一个名为 Cache
# 的 junction 可以指向 Program Files 里的任意目录。字符串层面路径合法，
# 但遍历一旦穿越链接，删除就发生在红线视野之外的另一个目录上。
# 因此所有遍历（扫描计数与删除）统一语义：reparse point 边界绝不穿越，
# 链接本身只摘链、不递归。
FILE_ATTRIBUTE_REPARSE_POINT = 0x0400


def is_reparse_point(path):
    r"""路径是否为 reparse point（junction/目录符号链接/文件符号链接/mount point）。

    注意 os.path.islink() 对 junction 返回 False（junction 是 reparse
    point 但不是符号链接），必须查 FILE_ATTRIBUTE_REPARSE_POINT 属性位；
    os.lstat 不跟随链接，对悬空链接也能取到属性。\\?\ 扩展前缀同样适用。
    """
    try:
        st = os.lstat(str(path))
    except OSError:
        return False
    return bool(getattr(st, "st_file_attributes", 0)
                & FILE_ATTRIBUTE_REPARSE_POINT)


def prune_reparse_dirs(root, dirs):
    """os.walk(topdown=True) 内联调用：原地剪掉 reparse point 子目录。

    返回被剪掉的链接完整路径列表（供删除流程单独摘链）。计数遍历时
    丢弃返回值即可——链接本身不占文件字节，其目标子树不计入本树。
    """
    links = []
    kept = []
    for d in dirs:
        p = os.path.join(str(root), d)
        if is_reparse_point(p):
            links.append(p)
        else:
            kept.append(d)
    dirs[:] = kept
    return links


def unlink_dir_link(path):
    r"""只摘除目录类 reparse point（junction/目录符号链接）本身，绝不进入目标。

    os.rmdir 对 junction/目录符号链接只删链接；先按普通形式试，深路径
    用 \\?\ 前缀。只能对 is_reparse_point 已确认的路径调用。
    """
    for cand in (str(path), win32_extended_path(str(path))):
        try:
            os.rmdir(cand)
            return True
        except OSError:
            continue
    return False


@functools.lru_cache(maxsize=4096)
def inside_git_repo(path):
    """路径是否处于某个 git 工作区内（逐级向上找 .git）。

    SAFETY 红线：代码仓库里的东西一律不碰（node_modules/.next 等缓存也不碰，
    用户可能正在跑构建，仓库内的删除应交给 git 自己的流程）。
    """
    cur = Path(path)
    try:
        if not cur.is_dir():
            cur = cur.parent
    except OSError:
        return False
    root = cur.anchor
    while True:
        try:
            if (cur / ".git").exists():
                return True
        except OSError:
            return False
        if str(cur) == root or cur.parent == cur:
            return False
        cur = cur.parent


def personal_roots():
    """六个人个人目录（桌面/下载/文档/图片/视频/音乐）的规范路径集合。"""
    up = user_profile()
    return {norm(up / sub) for sub in MIGRATE_SOURCES}


def in_personal_tree(path):
    low = norm(path)
    for base in personal_roots():
        if low == base or low.startswith(base + os.sep):
            return True
    return False


def program_files_roots():
    """应用安装目录（可能有多个：64 位 + x86 + 重定向）。"""
    names = ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432")
    return {norm(os.environ[n]) for n in names if os.environ.get(n)}


def in_program_files_tree(path):
    low = norm(path)
    return any(low == base or low.startswith(base + os.sep)
               for base in program_files_roots())


# ============ 8.3 短名展开与链接最终目标解析 ====
#
# GUI 路径安全回归实测出两条准入旁路：
#   1) C:\\PROGRA~1\\... 形态的 8.3 别名绕过 "\\program files\\" 字符串锚点，
#      同一路径长名被拦、短名放行；
#   2) 名为 Cache 的 junction 指向红线目录时，按"链接路径"做准入，
#      删除决策发生在另一个命名空间；批量通道还会把链接当已清理静默摘除。
# 准入因此必须落在"路径真实落地在哪里"：先展开 8.3，再把 junction/符号链接
# 解析到最终目标；短名展不开、或路径发生任何链接穿越，一律保守拒绝。
_SHORT83_RE = re.compile(r"^[^.\\/]{1,6}~\d{1,2}(?:\.[^.\\/]{1,3})?$", re.I)


def has_short83_segment(path_str):
    return any(_SHORT83_RE.match(seg)
               for seg in re.split(r"[\\/]", str(path_str)) if seg)


def get_long_path_name(s):
    """GetLongPathNameW：把含 8.3 短名的路径展开为长名（路径须存在）。

    失败（不存在/非 Windows/API 异常）原样返回，由调用方走保守拒绝。
    """
    if os.name != "nt":
        return s
    try:
        k32 = ctypes.windll.kernel32
        need = k32.GetLongPathNameW(str(s), None, 0)
        if not need or need >= 32768:
            return s
        buf = ctypes.create_unicode_buffer(need)
        if k32.GetLongPathNameW(str(s), buf, need):
            return buf.value
    except Exception:
        pass
    return s


def _strip_extended_prefix(s):
    if s.startswith("\\\\?\\UNC\\"):
        return "\\\\" + s[len("\\\\?\\UNC\\"):]
    if s.startswith("\\\\?\\"):
        return s[4:]
    return s


def final_resolved_path(path):
    """路径展开 8.3 并解析 junction/符号链接/mount point 后的最终真实路径。

    GetFinalPathNameByHandleW + FILE_NAME_NORMALIZED（8.3 一并规范化），
    以 DOS 盘符形式返回；目录句柄用 FILE_FLAG_BACKUP_SEMANTICS 打开，
    深路径自动加 \\\\?\\ 前缀。返回的是 norm 后的小写绝对路径；
    无法解析（不存在/非绝对路径/非 Windows/API 失败）返回 None。
    """
    if os.name != "nt":
        return norm(path)
    s = os.path.normpath(str(path))
    if not os.path.isabs(s):
        return None
    is_unc = s.startswith("\\\\")
    bare = _strip_extended_prefix(s)
    if is_unc or bare.startswith("\\\\"):
        extended = "\\\\?\\UNC\\" + bare.lstrip("\\")
    else:
        extended = "\\\\?\\" + bare
    try:
        k32 = ctypes.windll.kernel32
        k32.CreateFileW.argtypes = [
            wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
            ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        k32.CreateFileW.restype = wintypes.HANDLE
        k32.GetFinalPathNameByHandleW.argtypes = [
            wintypes.HANDLE, wintypes.LPWSTR, wintypes.DWORD, wintypes.DWORD]
        k32.GetFinalPathNameByHandleW.restype = wintypes.DWORD
        GENERIC_READ = 0x80000000
        FILE_SHARE_ALL = 0x00000007
        OPEN_EXISTING = 3
        FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
        INVALID_HANDLE = ctypes.c_void_p(-1).value
        h = k32.CreateFileW(
            extended, GENERIC_READ, FILE_SHARE_ALL, None, OPEN_EXISTING,
            FILE_FLAG_BACKUP_SEMANTICS, None)
        if not h or h == INVALID_HANDLE:
            return None
        try:
            size = k32.GetFinalPathNameByHandleW(h, None, 0, 0)
            if not size:
                return None
            buf = ctypes.create_unicode_buffer(size)
            n = k32.GetFinalPathNameByHandleW(h, buf, size, 0)
            if not n:
                return None
            return norm(_strip_extended_prefix(buf.value))
        finally:
            k32.CloseHandle(h)
    except Exception:
        return None


def cache_cleanable_reason(path, allow_reparse_root=False):
    """返回不可清理的原因字符串；返回 None 表示按当前策略可以清。

    scan 的可清理清单、HTML 报表数字、clean 的实际删除全部走这里，
    保证"体检说能清 X"和"实际真清 X"口径一致。
    对历史 scan 留下的旧清单同样重新校验，防止规则修复后旧清单继续害人。

    allow_reparse_root：仅 purge 手动急救可用。purge 对"用户显式点名的
    junction 根"有独立的只摘链实现（绝不进入目标），其调用方在自己那层
    已保证删除语义；GUI/clean 的清单准入永远不许放开。
    """
    p0 = Path(path)
    low = norm(p0)
    # 第零层：8.3 短名 + reparse 别名。准入只认真实落地路径：
    # - 短名存在且能展开 -> 用长名继续判；展不开 -> 拒；
    # - 根本身是链接 -> 拒（摘链也不允许，避免"静默摘除、无拦截呈现"）；
    # - 最终目标与名义路径不一致（路径穿越 junction/符号链接）-> 拒。
    root_is_link = is_reparse_point(p0)
    if allow_reparse_root and root_is_link:
        # purge 显式点名的链接根：红线路径按链接本身判，删除走只摘链通道
        p, low = p0, low
    else:
        had_short = has_short83_segment(low)
        long0 = norm(get_long_path_name(low)) if had_short else low
        if had_short and has_short83_segment(long0):
            return "8.3短名路径无法解析，拒绝"
        if root_is_link or (had_short and is_reparse_point(long0)):
            return "链接目录(junction/符号链接)根，拒绝"
        final = final_resolved_path(long0)
        if final is None:
            if had_short:
                return "8.3短名路径无法解析，拒绝"
            p, low = p0, low
        else:
            if final != (long0 if had_short else low):
                return "路径穿越链接目录(junction/符号链接)，拒绝"
            p, low = Path(final), final
    # 不只看最后一级：Package Cache 内部任何层级都不能当缓存删
    # （如 AppData\Local\Package Cache\bundle\cache）
    if CACHE_NAME_DENY & {part.lower() for part in p.parts}:
        return "卸载/修复缓存(Package Cache)"
    if in_excluded_path(low):
        return "受保护目录(系统/驱动/工作目录)"
    # Program Files 是应用安装地盘：哪怕目录名叫 cache（如 GoogleUpdater
    # 的 crx_cache），也只能走应用自身/卸载器流程，不做文件级删除
    if in_program_files_tree(p):
        return "应用安装目录(Program Files)"
    if inside_git_repo(p):
        return "代码仓库内(git)"
    if in_personal_tree(p):
        return None if is_personal_cache_dirname(p.name) else "个人目录非缓存强特征"
    return None if is_cache_dirname(p.name) else "不符合缓存特征"


# ============ 占用归因（仅用于提示"该关谁"，不参与任何删除决策） ============
#
# 删除失败时用户最需要的信息不是"被占用或无权限"，而是"我该关哪个程序"。
# 这里只按路径做高精度字符串推断，不枚举进程、不调用 WMI/handle.exe：
# 推断错了最坏是多一句提示，绝不改变删什么、不删什么。
OWNER_HINTS = [
    ("\\google\\chrome\\", "Chrome 浏览器（chrome.exe）"),
    ("\\microsoft\\edge\\", "Microsoft Edge（msedge.exe）"),
    ("\\wxwork\\", "企业微信（WXWork.exe）"),
    ("\\tencent files\\", "QQ/TIM（QQ.exe）"),
    ("\\tencent\\qq\\", "QQ（QQ.exe）"),
    ("\\wechat files\\", "微信（WeChat.exe）"),
    ("\\tencent\\wechat\\", "微信（WeChat.exe）"),
    ("\\kingsoft\\", "WPS（wps.exe / et.exe / wpp.exe）"),
    ("\\microsoft\\teams\\", "Microsoft Teams（Teams.exe）"),
    ("\\ms-playwright\\", "Playwright 自动测试浏览器（停掉跑测试的终端/node）"),
    ("puppeteer", "Puppeteer 自动测试浏览器（停掉跑测试的终端/node）"),
    ("\\npm-cache\\", "npm（停掉正在装包的终端/node）"),
    ("\\pip\\cache\\", "pip（停掉正在装包的终端/python）"),
    ("\\bcut\\", "必剪（Bcut.exe）"),
    ("\\jianyingpro\\", "剪映专业版（JianyingPro.exe）"),
    ("\\doudian", "抖店工作台"),
    ("\\微信开发者工具", "微信开发者工具（wechatdevtools.exe）"),
    ("\\crashdumps", "刚崩溃过的程序（崩溃转储，重启后再清即可）"),
]


def owner_hint(path):
    """根据路径推断占用者提示文案，推断不出返回 None。"""
    low = norm(path)
    for needle, who in OWNER_HINTS:
        if needle in low:
            return who
    # 内嵌 WebView2（很多国产工作台/IM 用）：EBWebView 的上一级多为宿主目录名。
    # 用小写串定位、用原始串取名，提示里保留程序目录的真实大小写。
    segs = re.split(r"[\\/]", low)
    if "ebwebview" in segs:
        i = segs.index("ebwebview")
        if i > 0:
            raw = re.split(r"[\\/]", str(path))
            host = raw[i - 1] if len(raw) == len(segs) and raw[i - 1] else segs[i - 1]
            return "内嵌 WebView2 的程序（%s，退出该程序后重试）" % host
    return None


# ============ 体检：扫描 ============

class Scanner:
    def __init__(self, roots, min_cache_mb=20, top_n=25, verbose=False,
                 personal_roots=None):
        self.roots = roots
        self.min_cache = min_cache_mb * 1024 * 1024
        self.top_n = top_n
        self.verbose = verbose
        # 这些根下使用"个人目录严格判定"，防止用户自建的 tmp/temp 工作目录被当垃圾
        self.personal_roots = {norm(r) for r in (personal_roots or [])}
        self.total_scanned = 0
        self.file_count = 0
        self.big_files = []          # heap of (size, path)
        self.cache_dirs = []         # (size, path)，仅收录通过安全准入的
        self.dir_totals = {}         # 聚合键 -> size
        self.errors = 0

    def _in_personal_roots(self, path):
        """候选路径是否落在个人目录里（按目录边界比较）。

        不能只比扫描根本身：--scope all 时根是整个用户目录，
        桌面/下载是它下面的子树，照样要走严格判定。
        """
        low = norm(path)
        return any(low == base or low.startswith(base + os.sep)
                   for base in self.personal_roots)

    def _push_big(self, size, path):
        if len(self.big_files) < self.top_n:
            heapq.heappush(self.big_files, (size, str(path)))
        elif size > self.big_files[0][0]:
            heapq.heapreplace(self.big_files, (size, str(path)))

    def walk(self):
        started = time.time()
        for root in self.roots:
            root = Path(root)
            if not root.exists():
                out("%s 跳过不存在的路径: %s" % (TAG_INFO, root))
                continue
            if self.verbose:
                out("%s 扫描 %s ..." % (TAG_INFO, root))
            depth_root = len(Path(root).parts)
            for cur, dirs, files in os.walk(root, topdown=True):
                # 不穿越 junction/符号链接：发现与计数只认真实目录树，
                # 防止链接把子树别名引进扫描（也避开 Application Data
                # 之类的 junction 回环）
                prune_reparse_dirs(cur, dirs)
                curp = Path(cur)
                # 缓存目录：候选路径落在个人目录里用严格判定，其余用完整启发式；
                # 只有"达阈值且通过安全准入"才收录并剪枝，其余照常深入，
                # 保证 TOP 目录/大文件统计不漏算。
                prune = []
                for d in dirs:
                    p = curp / d
                    # 全局禁判（Package Cache）：不收录也不遍历，
                    # 否则 ProgramData 下动辄数 GB 的卸载缓存会被白白走一遍
                    if d.lower() in CACHE_NAME_DENY:
                        prune.append(d)
                        continue
                    matcher = (is_personal_cache_dirname if self._in_personal_roots(p)
                               else is_cache_dirname)
                    if not matcher(d):
                        continue
                    try:
                        s = self._size(p)
                    except OSError:
                        continue
                    if s >= self.min_cache and cache_cleanable_reason(p) is None:
                        self.cache_dirs.append((s, str(p)))
                        prune.append(d)
                if prune:
                    dirs[:] = [d for d in dirs if d not in prune]
                # 聚合键：根目录下最多 3 层
                key_parts = curp.parts[:depth_root + 3]
                key = os.path.join(*key_parts)
                sub = 0
                for f in files:
                    try:
                        fp = curp / f
                        st = fp.stat()
                        if st.st_size <= 0:
                            continue
                        sub += st.st_size
                        self.file_count += 1
                        self._push_big(st.st_size, fp)
                    except OSError:
                        self.errors += 1
                        continue
                if sub:
                    self.dir_totals[key] = self.dir_totals.get(key, 0) + sub
                    self.total_scanned += sub
        self.elapsed = time.time() - started
        return self

    def _size(self, path):
        total = 0
        for r, d, fs in os.walk(win32_extended_path(path), topdown=True):
            prune_reparse_dirs(r, d)
            for f in fs:
                try:
                    total += os.path.getsize(os.path.join(r, f))
                except OSError:
                    pass
        return total

    def top_dirs(self, n=15):
        return sorted(self.dir_totals.items(), key=lambda kv: -kv[1])[:n]

    def top_files(self):
        return sorted(self.big_files, key=lambda t: -t[0])

    def top_cache(self, n=25):
        return sorted(self.cache_dirs, key=lambda t: -t[0])[:n]

    def cache_total(self):
        return sum(s for s, _ in self.cache_dirs)


def disk_usage(drive):
    try:
        total, used, free = shutil.disk_usage(drive + "\\")
        return total, used, free
    except OSError:
        return 0, 0, 0


# ============ 清理 ============

# PowerShell 删除的硬性时限。曾出现 Remove-Item 卡在被占用文件上
# 半小时不返回（1800s），整个清理跟着挂死；超时即判"疑似被占用"，
# 转 Python 逐文件兜底，并在报告里标注，制度上不允许单次卡死。
PS_TREE_TIMEOUT = 120      # 单棵目录删除上限（秒）
PS_BATCH_TIMEOUT = 180     # 批量（每批最多 20 路径）上限（秒）

# 让子 PowerShell 把输出按 UTF-8 吐回，避免中文路径在 GBK 控制台下
# 被 Python 按系统 ANSI 解码而乱码/抛 UnicodeDecodeError
_PS_ENCODING_PREFIX = "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
_PS_RUN_KW = dict(capture_output=True, encoding="utf-8", errors="replace")


def ps_delete_tree(path, timeout=PS_TREE_TIMEOUT):
    """用 PowerShell Remove-Item 整棵删除。

    返回 True=已删净，False=失败（权限/占用/策略），None=超时（疑似被占用）。

    为什么优先用 PowerShell 而不是 Python（性能原因，不是绕过保护）：
    AI 工作台宿主对 Python 侧删除操作（os.remove / shutil.rmtree）有每轮会话
    批量限流（50 个文件触发 SAFE_DELETE_BULK_CONFIRM_REQUIRED），且 Python 删
    是把文件推进回收站，每 ~0.4s 一项，删 5 万文件要半小时。
    PowerShell Remove-Item 是 Windows 原生批量通道，实测 514 个顶层目录秒级清空。
    因此工具在批量通道之外保留补偿性保护：路径准入单口径、默认预览、
    双确认、硬超时、残留复核与真实空间差值汇报。
    """
    # 超过 MAX_PATH 的深路径用 \\?\ 扩展前缀（Remove-Item/Test-Path 在
    # Win10+ 的 PS5.1 支持）；短路径保持原样
    lit = win32_extended_path(path) if len(str(path)) >= 240 else str(path)
    lit = lit.replace("'", "''")
    cmd = (_PS_ENCODING_PREFIX
           + "Remove-Item -LiteralPath '%s' -Recurse -Force -ErrorAction SilentlyContinue; "
           "if (Test-Path -LiteralPath '%s') { exit 1 } else { exit 0 }" % (lit, lit))
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
                           timeout=timeout, **_PS_RUN_KW)
        return r.returncode == 0
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return False


def ps_delete_paths(paths, chunk=20, timeout=PS_BATCH_TIMEOUT):
    """批量删除，返回 (仍然存在的路径集合, 超时的路径集合)。

    每个清理目标各起一次 powershell.exe 要 300ms+，整机几十项就是十几秒；
    合并成每批最多 chunk 个路径、一个进程搞定。删不掉的项目（被占用/无权限）
    由 PowerShell 回吐路径，调用方再走 Python 逐文件兜底。
    超时的整组进第二个集合：那不是普通失败，要向用户标注"疑似被占用"。
    """
    targets = [Path(p) for p in paths
               if p and Path(p).exists() and not is_reparse_point(p)]
    survivors = set()
    timed_out = set()
    for i in range(0, len(targets), chunk):
        group = targets[i:i + chunk]
        def _lit(p):
            s = win32_extended_path(p) if len(str(p)) >= 240 else str(p)
            return s.replace("'", "''")

        joined = "','".join(_lit(p) for p in group)
        cmd = (_PS_ENCODING_PREFIX
               + "$ps = @('%s'); "
               "Remove-Item -LiteralPath $ps -Recurse -Force -ErrorAction SilentlyContinue; "
               "foreach($x in $ps){ if(Test-Path -LiteralPath $x){ Write-Output $x } }"
               % joined)
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
                               timeout=timeout, **_PS_RUN_KW)
            alive = {ln.strip() for ln in (r.stdout or "").splitlines() if ln.strip()}
        except subprocess.TimeoutExpired:
            survivors.update(group)
            timed_out.update(group)
            continue
        except Exception:
            survivors.update(group)
            continue
        def _echo_key(s):
            # 回显的长路径带 \\?\ 前缀，比较前剥掉（norm 不剥此前缀）
            k = norm(s)
            if k.startswith("\\\\?\\unc\\"):
                k = "\\\\" + k[len("\\\\?\\unc\\"):]
            elif k.startswith("\\\\?\\"):
                k = k[4:]
            return k

        want = {_echo_key(p): p for p in group}
        matched = set()
        unknown = False
        for ln in alive:
            hit = want.get(_echo_key(ln))
            if hit is not None:
                matched.add(hit)
            else:
                unknown = True
        if unknown:
            # 控制台编码导致回显路径对不上：保守起见把整组视为需兜底
            survivors.update(group)
        else:
            survivors.update(matched)
    return survivors, timed_out


def recycle_bin_size(drive="C"):
    """回收站真实体积。

    PowerShell 里必须用单引号 'C:\\$RECYCLE.BIN'：双引号中的 $Recycle 会被
    当成变量展开成空串、路径退化为 C:\\.Bin（不存在 → 读到 0），与大小写无关。
    本机曾因这一处漏算 15.25 GB，以为"删了文件但空间没回来"，
    实际全躺在回收站里。
    """
    cmd = (_PS_ENCODING_PREFIX
           + "$s = (Get-ChildItem '%s:\\$RECYCLE.BIN' -Force -Recurse "
           "-ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; "
           "if ($s) { [math]::Round($s,0) } else { 0 }" % drive)
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
                           timeout=180, **_PS_RUN_KW)
        lines = [x.strip() for x in (r.stdout or "").splitlines() if x.strip()]
        raw = lines[-1] if lines else ""
        return int(float(raw)) if raw else 0
    except Exception:
        return 0


def ps_run(cmd, timeout=300):
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                            _PS_ENCODING_PREFIX + cmd],
                           timeout=timeout, **_PS_RUN_KW)
        return r.returncode, (r.stdout or "")
    except Exception:
        return -1, ""


def tree_size(path):
    s = 0
    try:
        for r, d, fs in os.walk(win32_extended_path(path), topdown=True,
                                onerror=lambda e: None):
            prune_reparse_dirs(r, d)
            for f in fs:
                try:
                    s += os.path.getsize(os.path.join(r, f))
                except OSError:
                    pass
    except OSError:
        pass
    return s


class Cleaner:
    def __init__(self, execute=False, do_recycle=True, cache_dirs=None, min_cache_mb=20,
                 include_dev_browsers=False, pro_locked=None):
        self.execute = execute
        self.do_recycle = do_recycle
        self.cache_dirs = cache_dirs or []
        # Playwright/Puppeteer 下载的浏览器二进制默认不当缓存删（删了得联网重下）
        self.include_dev_browsers = include_dev_browsers
        # Pro 门控：free 档下深度项（scan 缓存目录 + 大户专项）只预览不执行。
        # None = 取全局档位唯一来源 edition_info()，测试可显式传 True/False。
        self.pro_locked = is_free_edition() if pro_locked is None else pro_locked
        self.freed = 0
        self.cleaned = []
        self.skipped = []
        # 被安全策略挡下的缓存项 (name, path, size, reason)
        self.protected = []
        # free 档位下被门控、本轮未执行的 Pro 项 (name, path, size)
        self.locked = []
        # 跳过项的占用归因 norm(path) -> 提示文案（仅展示用）
        self.skip_hints = {}
        # 已处理路径（带尾部分隔符的规范前缀），避免固定类别与缓存清单重复计数
        self.handled = []

    def _lock_item(self, name, path, size):
        """登记一项因 Pro 门控未执行的深度清理项（不动磁盘）。"""
        self.locked.append((name, str(path), size))
        out("  %s %s: %s  <- %s" % (TAG_LOCK, name, fmt_size(size), path))

    def _mark_handled(self, path):
        self.handled.append(norm(path).rstrip("\\/") + os.sep)

    def already_handled(self, path):
        """必须按目录边界比较，防止 C:\\x\\Temp 误伤 C:\\x\\TempCopy。"""
        low = norm(path)
        return any(low.startswith(h) or low == h.rstrip("\\/")
                   for h in self.handled)

    def tag(self):
        return TAG_CLEAN if self.execute else TAG_PREVIEW

    def _record_skip(self, name, path, size):
        self.skipped.append((name, str(path), size))
        who = owner_hint(path)
        if who:
            self.skip_hints[norm(path)] = who
        return who

    @staticmethod
    def _owner_tail(path):
        who = owner_hint(path)
        return ("  建议关闭: %s" % who) if who else ""

    def _delete_tree(self, path, max_files=None, use_powershell=True):
        """删掉整个子树，返回 (释放字节, 删除文件数, 失败数)。

        两条路线，按此顺序：
        1. PowerShell `Remove-Item -Recurse -Force` —— 首选。Windows 原生批量
           通道，几万文件秒级，一次 subprocess 搞定；安全靠工具自身的准入/预览/
           双确认/超时/复核保证，与通道选择相互独立。
        2. 逐文件 os.remove + 自底向上 os.rmdir —— 兜底。PowerShell 被策略拦掉
           或目标被占用时退到这里，慢（每项 ~0.4s）但能啃动单个文件。

        批量删除的幸存者（被占用/无权限）调本方法时 use_powershell=False：
        PS 刚刚已经失败过一次，不必再为每项重启一次 powershell.exe。
        """
        path = Path(path)
        if not path.exists():
            return 0, 0, 0
        # 根本身是 reparse point：只摘链接本身，绝不递归（也绝不交给
        # PowerShell——Remove-Item 对 junction 的行为随 PS 版本不同）
        if is_reparse_point(path):
            return 0, 0, 0 if unlink_dir_link(path) else 1
        files, dirs, links = [], [], []
        # 遍历根加 \\?\ 前缀：父目录虽短、子孙可能 >260，
        # 不加前缀时 os.walk 会静默漏进深目录（onerror 之外直接看不见）
        for r, d, fs in os.walk(win32_extended_path(path), topdown=True,
                               onerror=lambda e: None):
            # 剪到的 junction/符号链接单独摘链，绝不走进目标子树
            links.extend(prune_reparse_dirs(r, d))
            for f in fs:
                files.append(os.path.join(r, f))
            dirs.append(r)
        if max_files:
            files = files[:max_files]
        total = 0
        for f in files:
            try:
                total += os.path.getsize(f)
            except OSError:
                pass
        # 无论走哪条路线，链接都先用 Python 摘掉：剩下的实体树里不含
        # 任何 reparse point，PowerShell 5.1/7 行为差异就与我们无关了
        link_fail = 0
        for lk in links:
            if not unlink_dir_link(lk):
                link_fail += 1
        # 路线 1：PowerShell 整棵端掉（返回 None=超时，同样落到路线 2 兜底）
        if use_powershell and ps_delete_tree(path) is True:
            return total, len(files), link_fail
        # 路线 2：Python 逐文件删
        freed = 0
        removed = 0
        failed = link_fail
        for f in files:
            try:
                size = os.path.getsize(f)
            except OSError:
                continue
            try:
                os.remove(f)
                freed += size
                removed += 1
            except OSError:
                failed += 1
        for d in sorted(dirs, key=len, reverse=True):
            try:
                os.rmdir(d)
            except OSError:
                pass
        return freed, removed, failed

    def _wipe_dir(self, path, name, pro=False):
        """清空目录内容（保留目录本身）。

        pro=True 表示大户专项类 Pro 深度项：free 档执行时只登记到 locked，
        磁盘一个字节都不动；预览模式下照常列出（预览全开，不挡视线）。
        """
        path = Path(path)
        if not path.exists():
            return
        try:
            size = 0
            for r, d, fs in os.walk(win32_extended_path(path), topdown=True):
                prune_reparse_dirs(r, d)
                for f in fs:
                    try:
                        size += os.path.getsize(os.path.join(r, f))
                    except OSError:
                        pass
        except OSError:
            return
        if size == 0:
            return
        self._mark_handled(path)
        if pro and self.execute and self.pro_locked:
            # free 档执行：Pro 深度项不删，登记后返回
            self._lock_item(name, path, size)
            return
        if not self.execute:
            self.cleaned.append((name, str(path), size))
            self.freed += size
            out("  %s %s: %s  <- %s" % (TAG_PREVIEW, name, fmt_size(size), path))
            return
        try:
            # 用扩展前缀列目录（自身可能 >260）；拼回普通表示，
            # 真正删除时由 ps_delete_paths/_delete_tree 再加前缀
            items = [os.path.join(str(path), name)
                     for name in os.listdir(win32_extended_path(path))]
        except OSError:
            items = []
        # 目录类 reparse point（junction/目录符号链接）不进 PS 批处理：
        # 只摘链接本身，杜绝 Remove-Item 跨版本穿越链接删目标
        link_items = [p for p in items
                      if os.path.isdir(p) and is_reparse_point(p)]
        items = [p for p in items if p not in link_items]
        for lk in link_items:
            unlink_dir_link(lk)
        # 一层里可能有上千个子项，每个各起一次 powershell 要十几分钟；
        # 合并成一次批量调用，再把删不掉的丢给 Python 兜底。
        timed = set()
        if items:
            survivors, timed = ps_delete_paths(items)
            for survivor in survivors:
                # PS 刚失败过一次，幸存者一律 use_powershell=False，
                # 不许为每个幸存者再起一次 powershell.exe（docstring 同款约定）
                self._delete_tree(survivor, use_powershell=False)
        after = 0
        if path.exists():
            for r, d, fs in os.walk(win32_extended_path(path), topdown=True):
                prune_reparse_dirs(r, d)
                for f in fs:
                    try:
                        after += os.path.getsize(os.path.join(r, f))
                    except OSError:
                        pass
        delta = size - after
        if delta > 0:
            self.cleaned.append((name, str(path), delta))
            self.freed += delta
            out("  %s %s: 释放 %s" % (TAG_CLEAN, name, fmt_size(delta)))
            if after > 0:
                # 大部分删掉、只剩被占用的小尾巴
                who = owner_hint(path)
                if who:
                    self.skip_hints[norm(path)] = who
                out("  %s %s: 残留 %s 未删%s%s"
                    % (TAG_SKIP, name, fmt_size(after),
                       "（PowerShell 删除超时，疑似被占用）" if timed else "",
                       ("  建议关闭: %s" % who) if who else ""))
        else:
            who = self._record_skip(name, path, size)
            out("  %s %s: 被占用或无权限 (%s)%s%s"
                % (TAG_SKIP, name, fmt_size(size),
                   " PowerShell 删除超时，疑似被占用；" if timed else "",
                   ("建议关闭: %s" % who) if who else ""))

    def _wipe_pattern(self, path, pattern, name):
        path = Path(path)
        if not path.exists():
            return
        files = [f for f in path.glob(pattern) if f.is_file()]
        if not files:
            return
        size = 0
        for f in files:
            try:
                size += f.stat().st_size
            except OSError:
                pass
        if size == 0:
            return
        if not self.execute:
            self.cleaned.append((name, str(path), size))
            self.freed += size
            out("  %s %s: %s (%d 个文件)" % (TAG_PREVIEW, name, fmt_size(size), len(files)))
            return
        removed = 0
        for f in files:
            try:
                f.unlink(missing_ok=True)
                removed += 1
            except OSError:
                pass
        if removed:
            self.cleaned.append((name, str(path), size))
            self.freed += size
            out("  %s %s: 释放 %s (%d 个文件)" % (TAG_CLEAN, name, fmt_size(size), removed))
        else:
            who = self._record_skip(name, path, size)
            out("  %s %s: 被占用或无权限%s"
                % (TAG_SKIP, name, ("  建议关闭: %s" % who) if who else ""))

    def run(self):
        local = local_appdata()
        roaming = roaming_appdata()
        win = windir()
        temp = Path(os.environ.get("TEMP", r"C:\Windows\Temp"))
        up = user_profile()

        out("\n>> 用户临时文件")
        self._wipe_dir(temp, "用户临时文件")

        out("\n>> Windows 系统临时文件（需管理员）")
        self._wipe_dir(win / "Temp", "Windows临时文件")

        out("\n>> 包管理器缓存")
        for p in [local / "npm-cache", roaming / "npm-cache"]:
            self._wipe_dir(p, "npm缓存")
        for p in [local / "pip" / "cache", roaming / "pip" / "cache"]:
            self._wipe_dir(p, "pip缓存")

        out("\n>> 浏览器缓存")
        for base, bname in [
            (local / "Google" / "Chrome" / "User Data", "Chrome"),
            (local / "Microsoft" / "Edge" / "User Data", "Edge"),
        ]:
            if not base.exists():
                continue
            try:
                profiles = [d for d in base.iterdir() if d.is_dir()]
            except OSError:
                continue
            for profile in profiles:
                for cache in ["Cache", "Code Cache", "GPUCache", "ShaderCache"]:
                    self._wipe_dir(profile / cache, "%s/%s" % (bname, cache))

        out("\n>> 开发工具缓存")
        # Playwright/Puppeteer 目录里是已下载的浏览器二进制（几百MB~1GB+），
        # 删了下次跑测试要联网重下，性质是"攒下来的运行时"不是缓存：
        # 默认跳过，显式加 --include-dev-browsers 才清。
        dev_browser_dirs = [local / "ms-playwright", local / "puppeteer",
                            up / ".cache" / "puppeteer"]
        if self.include_dev_browsers:
            self._wipe_dir(dev_browser_dirs[0], "Playwright浏览器")
            self._wipe_dir(dev_browser_dirs[1], "Puppeteer缓存")
            self._wipe_dir(dev_browser_dirs[2], "Puppeteer缓存(.cache)")
        elif any(p.exists() for p in dev_browser_dirs):
            # 只提示一次，不逐路径刷屏
            out("  %s 已跳过 Playwright/Puppeteer 浏览器二进制"
                "（删了需联网重下；确要清理加 --include-dev-browsers）" % TAG_INFO)

        out("\n>> 崩溃转储与错误报告")
        self._wipe_dir(local / "CrashDumps", "崩溃转储")
        self._wipe_dir(local / "Microsoft" / "Windows" / "WER", "Windows错误报告")

        out("\n>> 缩略图缓存")
        self._wipe_pattern(local / "Microsoft" / "Windows" / "Explorer",
                           "thumbcache_*.db", "缩略图缓存")

        out("\n>> Windows 更新缓存（需管理员）")
        self._wipe_dir(win / "SoftwareDistribution" / "Download", "Windows更新缓存")

        out("\n>> 软件缓存目录（来自 scan 结果）")
        # scan 清单可能来自旧规则甚至旧机器，删除前必须逐项重新过安全准入；
        # 预览与执行走同一把尺子，绝不允许"报表说能清就直接删"。
        pending = []
        for size, p in self.cache_dirs:
            pth = Path(p)
            if self.already_handled(pth):
                continue
            if not pth.exists():
                self.protected.append((pth.name, str(pth), size, "路径已不存在"))
                continue
            reason = cache_cleanable_reason(pth)
            if reason:
                self.protected.append((pth.name, str(pth), size, reason))
                out("  %s %s: %s (%s)" % (TAG_SKIP, reason, pth.name,
                                          str(pth.parent)[:60]))
                continue
            self._mark_handled(pth)
            pending.append((size, pth))

        if not self.execute:
            for size, pth in pending:
                self.cleaned.append((pth.name, str(pth), size))
                self.freed += size
                out("  %s %s: %s  <- %s" % (TAG_PREVIEW, fmt_size(size), pth.name,
                                            str(pth.parent)[:60]))
        elif self.pro_locked:
            # free 档执行：scan 发现的软件缓存目录属深度清理，整批只登记不删
            for size, pth in pending:
                self._lock_item(pth.name, str(pth), size)
        elif pending:
            # 批量删除：一个 PowerShell 进程处理一批，删不掉的（占用/权限）
            # 回吐后再走 Python 逐文件兜底，避免每项各起一次 powershell.exe
            survivors, timed = ps_delete_paths([pth for _, pth in pending])
            timed_n = {norm(p) for p in timed}
            for pth in survivors:
                self._delete_tree(pth, use_powershell=False)
            for size, pth in pending:
                after = tree_size(pth) if pth.exists() else 0
                # scan 之后缓存可能被程序清掉或继续增长，账面为负按 0 计；
                # 真实释放量以命令末尾的 C 盘可用空间差值为准
                delta = max(size - after, 0)
                who = owner_hint(pth)
                if who:
                    self.skip_hints[norm(pth)] = who
                overtime = norm(pth) in timed_n
                if delta > 0:
                    self.cleaned.append((pth.name, str(pth), delta))
                    self.freed += delta
                if after > 0:
                    tail = "残留 %s，可能被占用" % fmt_size(after) if delta > 0 \
                        else "被占用或无权限"
                    if overtime:
                        tail += "（PowerShell 删除超时）"
                    if delta <= 0:
                        self._record_skip(pth.name, pth, size)
                    out("  %s %s: %s%s%s  <- %s"
                        % (TAG_CLEAN if delta > 0 else TAG_SKIP, pth.name,
                           ("释放 %s " % fmt_size(delta)) if delta > 0 else "",
                           "(" + tail + ")",
                           ("  建议关闭: %s" % who) if who else "",
                           str(pth.parent)[:60]))
                elif delta > 0:
                    out("  %s %s: %s  <- %s" % (TAG_CLEAN, fmt_size(delta), pth.name,
                                                str(pth.parent)[:60]))
                else:
                    self.skipped.append((pth.name, str(pth), size))
                    out("  %s %s: 未释放（清单大小可能已过期）" % (TAG_SKIP, pth.name))

        out("\n>> 大户专项（常规缓存词表抓不到的应用仓库）")
        self._heavy_hitters()

        if self.do_recycle:
            out("\n>> 回收站")
            self._recycle_bin()
        return self

    def _heavy_hitters(self):
        """大户专项：目录名不含 cache/log/temp 这类词，所以 scan 的缓存词表抓不到。
        全部实测于本机：WPS 加载项版本池 1.76G、必剪素材 1.62G、微信开发者工具 1.09G、
        WorkBuddy 升级器残留安装包 0.49G。
        """
        local = local_appdata()
        roaming = roaming_appdata()

        # 1) WPS 加载项版本池：同名插件只保留最高版本，老版本包全删
        VER_RE = re.compile(r"^(?P<name>.+?)_(?P<ver>[\d.]+)$")
        pool = roaming / "kingsoft" / "wps" / "addons" / "pool" / "win-i386"
        if pool.is_dir():
            groups = collections.defaultdict(list)
            try:
                names = [d.name for d in pool.iterdir() if d.is_dir()]
            except OSError:
                names = []
            for name in names:
                m = VER_RE.match(name)
                if not m:
                    continue
                try:
                    ver = tuple(int(x) for x in m.group("ver").split("."))
                except ValueError:
                    continue
                groups[m.group("name")].append((ver, pool / name))
            for key, items in groups.items():
                if len(items) < 2:
                    continue
                items.sort(key=lambda x: x[0], reverse=True)
                for ver, full in items[1:]:
                    self._wipe_dir(full, "WPS加载项旧版/%s" % key, pro=True)

        # 2) 必剪(BCUT) 素材缓存：可再生，删后首次启动会重新拉取
        for p in [local / "BCUT" / "local_res" / "datas"]:
            if p.is_dir():
                self._wipe_dir(p, "必剪素材缓存", pro=True)

        # 3) 微信开发者工具小程序运行时缓存
        wx = local / "微信开发者工具" / "User Data"
        if wx.is_dir():
            for r, d, fs in os.walk(wx, topdown=True, onerror=lambda e: None):
                prune_reparse_dirs(r, d)
                if os.path.basename(r) in ("WeappCache", "WeappCache_v2",
                                           "WeappPlugin", "WeappVendor",
                                           "WeappPluginBox"):
                    d[:] = []
                    self._wipe_dir(r, "微信开发者工具缓存", pro=True)

        # 4) 桌面/更新器残留的安装包：一次性几百 MB ~ 1 GB
        for base in (local, roaming):
            try:
                dirs = [x for x in base.iterdir() if x.is_dir()]
            except OSError:
                continue
            for d in dirs:
                if "updater" not in d.name.lower() and "update" not in d.name.lower():
                    continue
                try:
                    files = [f for f in d.iterdir() if f.is_file()
                             and f.suffix.lower() in (".exe", ".msi", ".zip", ".7z", ".pkg")]
                except OSError:
                    continue
                total = 0
                for f in files:
                    try:
                        total += f.stat().st_size
                    except OSError:
                        pass
                if total < 20 * 1024 ** 2:
                    continue
                name = "%s 残留安装包" % d.name
                if not self.execute:
                    self.cleaned.append((name, str(d), total))
                    self.freed += total
                    out("  %s %s: %s (%d 个文件)" % (TAG_PREVIEW, name,
                                                    fmt_size(total), len(files)))
                    continue
                if self.pro_locked:
                    # free 档执行：大户残留安装包属 Pro 深度项，不删
                    self._lock_item(name, str(d), total)
                    continue
                freed = 0
                nfail = 0
                for f in files:
                    try:
                        sz = f.stat().st_size
                        f.unlink(missing_ok=True)
                        freed += sz
                    except OSError:
                        nfail += 1
                if freed:
                    self.cleaned.append((name, str(d), freed))
                    self.freed += freed
                    out("  %s %s: 释放 %s" % (TAG_CLEAN, name, fmt_size(freed)))
                if nfail:
                    out("  %s %s: %d 个文件被占用" % (TAG_SKIP, name, nfail))

    def _recycle_bin(self):
        """回收站：本技能里单项收益最高的一处；路径在 PS 中须单引号防变量展开。"""
        size = recycle_bin_size()
        if not self.execute:
            if size > 0:
                self.cleaned.append(("回收站 $RECYCLE.BIN", "C:\\$RECYCLE.BIN", size))
                self.freed += size
                out("  %s 回收站 $RECYCLE.BIN: %s（预览，执行时才清空）"
                    % (TAG_PREVIEW, fmt_size(size)))
            else:
                out("  %s 回收站: 空" % TAG_INFO)
            return
        if size <= 0:
            out("  %s 回收站: 空" % TAG_INFO)
            return
        rc, _ = ps_run("Clear-RecycleBin -DriveLetter C -Force "
                       "-ErrorAction SilentlyContinue", timeout=300)
        after = recycle_bin_size()
        got = max(size - after, 0)
        if got > 0:
            self.cleaned.append(("回收站 $RECYCLE.BIN", "C:\\$RECYCLE.BIN", got))
            self.freed += got
        out("  %s 回收站 $RECYCLE.BIN: %s -> %s%s"
            % (TAG_CLEAN, fmt_size(size), fmt_size(after),
               "" if rc == 0 else "（部分失败，可能需管理员）"))


# ============ 迁移 ============

class Migrator:
    def __init__(self, target_drive="D:", min_size_mb=500, execute=False):
        self.target_drive = target_drive.rstrip(":\\/") + ":\\"
        self.min_size = min_size_mb * 1024 * 1024
        self.execute = execute
        self.up = user_profile()
        self.target_root = Path(self.target_drive) / "C盘迁移"
        self.moved = []
        self.total_moved = 0
        # 预检失败的原因（非空则 run 不动任何文件）；门牌创建失败的明细
        self.preflight_errors = []
        self.warnings = []

    def _shortcut(self, target_path, shortcut_path):
        try:
            ps = ("$ws = New-Object -ComObject WScript.Shell; "
                  "$sc = $ws.CreateShortcut('%s'); "
                  "$sc.TargetPath = '%s'; "
                  "$sc.Save()" % (str(shortcut_path).replace("'", "''"),
                                  str(target_path).replace("'", "''")))
            subprocess.run(["powershell", "-NoProfile", "-Command",
                            _PS_ENCODING_PREFIX + ps],
                           timeout=30, **_PS_RUN_KW)
            return shortcut_path.exists()
        except Exception:
            return False

    def _scan(self, source):
        """枚举大文件。绝不用 rglob：pathlib 会穿越 junction 把链接目标
        子树的文件算成 C 盘可搬家文件，
        统一走 os.walk + prune_reparse_dirs 的不穿越语义。"""
        result = []
        for cur, dirs, files in os.walk(str(source), topdown=True):
            prune_reparse_dirs(cur, dirs)
            for fn in files:
                fp = Path(cur) / fn
                try:
                    if fp.is_symlink():
                        continue
                    s = fp.stat().st_size
                    if s >= self.min_size:
                        result.append((fp, s))
                except OSError:
                    continue
        return result

    def _preflight(self, plan):
        """SAFETY 承诺：目标盘不存在/与 C 同盘/空间不足，直接放弃，不部分迁移。

        plan: [(src, size, source_root, category], ...]
        """
        target_letter = self.target_drive[:2].upper()
        c_letter = "C:"
        # 1) 目标盘必须在线（U盘/移动硬盘没插时 Path 不存在）
        if not Path(self.target_drive).exists():
            self.preflight_errors.append("目标盘 %s 不存在或未就绪" % target_letter)
        # 2) 同盘迁移不释放任何空间（同卷 rename），禁止
        if target_letter == c_letter:
            self.preflight_errors.append("目标盘 %s 与 C 盘是同一卷，迁移不释放空间"
                                         % target_letter)
        if self.preflight_errors:
            return
        # 3) 空间必须容得下全部计划项（预检整体通过才动手，不迁一半）
        need = sum(sz for _, sz, _, _ in plan)
        try:
            free = shutil.disk_usage(self.target_drive)[2]
        except OSError:
            self.preflight_errors.append("无法读取 %s 可用空间" % target_letter)
            return
        if free < need:
            self.preflight_errors.append(
                "%s 可用 %s，计划迁移 %s，空间不足"
                % (target_letter, fmt_size(free), fmt_size(need)))

    def run(self):
        # 先把六个源目录全部扫完再预检：要么全做，要么不做
        plan = []
        for sub, category in MIGRATE_SOURCES.items():
            source = self.up / sub
            if not source.exists():
                continue
            for src, size in self._scan(source):
                plan.append((src, size, source, category))

        self._preflight(plan)
        if self.preflight_errors:
            for why in self.preflight_errors:
                out("  %s %s" % (TAG_SKIP, why))
            return self

        groups = collections.OrderedDict()
        for src, size, source, category in plan:
            groups.setdefault(category, []).append((src, size, source))
        for category, items in groups.items():
            out("\n>> %s: %d 个大文件（目标 %s）"
                % (category, len(items), self.target_drive.rstrip("\\")))
            dest_dir = self.target_root / category
            for src, size, source in sorted(items, key=lambda x: -x[1]):
                dest = dest_dir / src.name
                counter = 1
                while dest.exists():
                    dest = dest_dir / ("%s_%d%s" % (src.stem, counter, src.suffix))
                    counter += 1
                if not self.execute:
                    self.moved.append((src.name, str(dest), size))
                    self.total_moved += size
                    out("  %s %s (%s)" % (TAG_PREVIEW, src.relative_to(source), fmt_size(size)))
                    continue
                try:
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(src), str(dest))
                    self.moved.append((src.name, str(dest), size))
                    self.total_moved += size
                    if not self._shortcut(dest, src.with_suffix(".lnk")):
                        # 文件已搬走但门牌没建成：绝不能沉默，明确告知新位置
                        self.warnings.append((src.name, str(dest)))
                        out("  %s %s (%s) -> %s" % (TAG_MOVE, src.name, fmt_size(size), dest))
                        out("  %s 快捷方式创建失败，文件新位置: %s" % (TAG_INFO, dest))
                    else:
                        out("  %s %s (%s) -> %s" % (TAG_MOVE, src.name, fmt_size(size), dest))
                except OSError as e:
                    out("  %s %s: %s" % (TAG_SKIP, src.name, e))
        if self.warnings:
            out("\n  %s %d 个文件的快捷方式没建成，文件都在 %s 下，可手动建快捷方式"
                % (TAG_INFO, len(self.warnings), self.target_root))
        return self


# ============ 报告 ============

def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def render_scan_html(total, used, free, top_dirs, top_files, cache_list, cache_total,
                     elapsed, cache_count=None):
    """生成自包含 HTML 体检报告（内联 CSS + 手绘 SVG，离线双击可用）。

    cache_list 是展示用的前 N 项；cache_count 是全部命中数（默认同展示数）。
    """
    pct = (used * 100.0 / total) if total else 0
    bar_color = "#38a169" if pct < 70 else ("#d69e2e" if pct < 88 else "#e53e3e")
    max_dir = max([v for _, v in top_dirs], default=1) or 1
    max_file = max([v for v, _ in top_files], default=1) or 1

    dir_rows = []
    for k, v in top_dirs:
        w = v * 100.0 / max_dir
        dir_rows.append(
            '<tr><td class="p">%s</td>'
            '<td class="barcell"><div class="bar" style="width:%.1f%%"></div></td>'
            '<td class="n">%s</td></tr>' % (esc(k), w, fmt_size(v)))

    file_rows = []
    for v, p in top_files:
        w = v * 100.0 / max_file
        file_rows.append(
            '<tr><td class="p">%s</td>'
            '<td class="barcell"><div class="bar b2" style="width:%.1f%%"></div></td>'
            '<td class="n">%s</td></tr>' % (esc(p), w, fmt_size(v)))

    cache_rows = []
    for v, p in cache_list:
        cache_rows.append('<tr><td class="p">%s</td><td class="n">%s</td></tr>'
                          % (esc(p), fmt_size(v)))

    # 已用/可用环形图
    sweep_free = (free * 100.0 / total) if total else 0
    sweep_used = (used * 100.0 / total) if total else 0
    c = 2 * 3.14159265 * 70
    used_len = c * sweep_used / 100.0
    free_len = c - used_len

    tmpl = u"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>C盘体检报告</title>
<style>
*{box-sizing:border-box}
body{margin:0;padding:28px;background:#f5f6f8;color:#1a202c;
 font-family:"Microsoft YaHei","PingFang SC",-apple-system,Segoe UI,sans-serif;line-height:1.6}
.wrap{max-width:960px;margin:0 auto}
h1{font-size:22px;margin:0 0 4px}
.sub{color:#718096;font-size:13px;margin-bottom:22px}
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:22px}
.kpi{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:16px}
.kpi .t{font-size:12px;color:#718096}
.kpi .v{font-size:22px;font-weight:700;margin-top:4px}
.kpi .x{font-size:12px;color:#a0aec0}
.card{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:20px;margin-bottom:18px}
.card h2{font-size:15px;margin:0 0 14px;padding-bottom:10px;border-bottom:1px solid #edf2f7}
.water{height:26px;background:#edf2f7;border-radius:13px;overflow:hidden;display:flex}
.water i{display:block;height:100%}
.legend{display:flex;gap:18px;font-size:12px;color:#4a5568;margin-top:10px}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px}
table{width:100%;border-collapse:collapse;font-size:13px}
td{padding:5px 6px;vertical-align:middle}
td.p{font-family:Consolas,Monaco,monospace;color:#2d3748;word-break:break-all;max-width:520px}
td.n{text-align:right;white-space:nowrap;color:#4a5568;font-variant-numeric:tabular-nums}
.barcell{width:120px}
.bar{height:8px;background:#4299e1;border-radius:4px}
.bar.b2{background:#805ad5}
.totalbox{background:#ebf8ff;border:1px solid #bee3f8;border-radius:10px;padding:16px;
 margin-top:14px;font-size:15px}
.totalbox b{font-size:20px;color:#2b6cb0}
.tip{background:#fffaf0;border:1px solid #feebc8;border-radius:10px;padding:16px;font-size:13px;color:#744210}
code{background:#edf2f7;padding:2px 6px;border-radius:4px;font-family:Consolas,monospace}
.ring{display:flex;align-items:center;gap:26px}
.ringtxt{font-size:13px;color:#4a5568}
@media(max-width:720px){.kpis{grid-template-columns:repeat(2,1fr)}}
</style></head><body><div class="wrap">
<h1>C 盘体检报告</h1>
<div class="sub">生成时间 __NOW__ &nbsp;|&nbsp; 扫描耗时 __ELAPSED__ 秒 &nbsp;|&nbsp; C盘管家 c-drive-butler</div>

<div class="kpis">
 <div class="kpi"><div class="t">总容量</div><div class="v">__TOTAL__</div><div class="x">C 盘</div></div>
 <div class="kpi"><div class="t">已用</div><div class="v">__USED__</div><div class="x">__PCT__%</div></div>
 <div class="kpi"><div class="t">可用</div><div class="v" style="color:__BAR_COLOR__">__FREE__</div><div class="x">剩余空间</div></div>
 <div class="kpi"><div class="t">可清理</div><div class="v" style="color:#2b6cb0">__CACHE_TOTAL__</div><div class="x">缓存/临时</div></div>
</div>

<div class="card">
 <h2>空间分布</h2>
 <div class="ring">
  <svg width="180" height="180" viewBox="0 0 180 180">
   <circle cx="90" cy="90" r="70" fill="none" stroke="#edf2f7" stroke-width="26"/>
   <circle cx="90" cy="90" r="70" fill="none" stroke="__BAR_COLOR__" stroke-width="26"
    stroke-dasharray="__USED_LEN__ __FREE_LEN__" transform="rotate(-90 90 90)"/>
   <text x="90" y="86" text-anchor="middle" font-size="26" font-weight="700" fill="#1a202c">__PCT0__%</text>
   <text x="90" y="106" text-anchor="middle" font-size="12" fill="#718096">已占用</text>
  </svg>
  <div class="ringtxt">
   已用 __USED__<br>可用 __FREE__<br>总容量 __TOTAL__
  </div>
 </div>
 <div class="water" style="margin-top:16px">
  <i style="width:__PCT__%;background:__BAR_COLOR__"></i>
 </div>
 <div class="legend">
  <span><i class="dot" style="background:__BAR_COLOR__"></i>已用 __PCT__%</span>
  <span><i class="dot" style="background:#cbd5e0"></i>可用 __RESTPCT__%</span>
 </div>
</div>

<div class="card">
 <h2>占用 TOP 目录</h2>
 <table>__DIR_ROWS__</table>
</div>

<div class="card">
 <h2>TOP 大文件</h2>
 <table>__FILE_ROWS__</table>
</div>

<div class="card">
 <h2>可清理项（缓存 / 临时 / 可再生，删除不影响使用）__CACHE_SCOPE__</h2>
 <table>__CACHE_ROWS__</table>
 <div class="totalbox">预计可释放 <b>__CACHE_TOTAL__</b>（__CACHE_CNT__ 项的完整合计；
 表格按设置只列前 __CACHE_SHOWN__ 项）</div>
</div>

<div class="tip">
 <b>下一步怎么清？</b><br>
 先预览：<code>py butler.py clean</code><br>
 确认后执行：<code>py butler.py clean --execute --yes</code><br><br>
 清完发现 C 盘可用空间没变，多半是进了回收站，补一句
 <code>Clear-RecycleBin -Force</code> 即可真正释放。
</div>
__PRO_HOOK__
</div></body></html>"""

    # 免费技能版三处钩子之一：HTML 报告底部品牌+Pro 引导（pro 档不渲染）
    info = edition_info()
    if info["edition"] == "free":
        pro_hook = ('<div class="tip" style="background:#ebf8ff;'
                    'border-color:#bee3f8;color:#2a4365">'
                    '<b>本报告由 C盘管家免费技能版生成。</b><br>'
                    + esc(pro_upgrade_text(None)))
        if info["pro_url"]:
            pro_hook += ('<br><a href="%s" style="color:#2b6cb0">%s</a>'
                         % (esc(info["pro_url"]), esc(info["pro_url"])))
        pro_hook += "</div>"
    else:
        pro_hook = ""

    vals = {
        "NOW": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "ELAPSED": "%.1f" % elapsed,
        "TOTAL": fmt_size(total),
        "USED": fmt_size(used),
        "FREE": fmt_size(free),
        "PCT": "%.1f" % pct,
        "PCT0": "%.0f" % pct,
        "RESTPCT": "%.1f" % (100 - pct),
        "BAR_COLOR": bar_color,
        "CACHE_TOTAL": fmt_size(cache_total),
        "CACHE_CNT": str(len(cache_list) if cache_count is None else cache_count),
        "CACHE_SHOWN": str(len(cache_list)),
        "CACHE_SCOPE": "" if cache_count in (None, len(cache_list)) else
                       "（仅列前 %d 项）" % len(cache_list),
        "USED_LEN": "%.1f" % used_len,
        "FREE_LEN": "%.1f" % free_len,
        "DIR_ROWS": "".join(dir_rows),
        "FILE_ROWS": "".join(file_rows),
        "CACHE_ROWS": "".join(cache_rows) or '<tr><td class="p">(未发现)</td><td class="n">-</td></tr>',
        "PRO_HOOK": pro_hook,
    }
    html = tmpl
    for _k, _v in vals.items():
        html = html.replace("__%s__" % _k, _v)
    return html


def write_report(name, lines, ts=None):
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    ts = ts or datetime.now().strftime("%Y%m%d_%H%M%S")
    f = REPORT_DIR / ("%s_%s.md" % (name, ts))
    f.write_text("\n".join(lines), encoding="utf-8")
    return f


def cmd_scan(args):
    up = user_profile()
    local = local_appdata()
    roaming = roaming_appdata()
    win = windir()

    if args.scope == "user":
        roots = [up / "Downloads", up / "Desktop", up / "Documents",
                 up / "Pictures", up / "Videos", up / "Music"]
    elif args.scope == "appdata":
        roots = [local, roaming]
    elif args.scope == "all":
        pf = Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
        pf86 = Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"))
        roots = [up, win, pf, pf86, Path("C:\\ProgramData")]
    else:  # default = user + appdata + ProgramData
        # ProgramData 是长期被漏掉的黑洞：本机实测 8.13 GB（cocos 引擎 5.4G、
        # 微信输入法补丁 1.3G），不在用户目录下，老版本 default 扫描完全看不见
        roots = [up / "Downloads", up / "Desktop", up / "Documents",
                 up / "Pictures", up / "Videos", up / "Music", local, roaming,
                 Path("C:\\ProgramData")]

    roots = [r for r in roots if r and str(r) and Path(r).exists()]
    total, used, free = disk_usage("C:")
    started_at = datetime.now()

    out("=" * 68)
    out("  C盘管家 - 磁盘体检（只读，不改动任何文件）")
    out("=" * 68)
    out("  扫描范围: %s" % ", ".join(str(r) for r in roots))
    out("  时间: %s" % started_at.strftime("%Y-%m-%d %H:%M:%S"))

    # 无论哪种 scope，六个个人目录（桌面/下载/文档/图片/视频/音乐）下都只认
    # 应用运行时缓存强特征，防止用户自建的 tmp/temp 工作目录被当垃圾
    personal_dirs = [up / sub for sub in MIGRATE_SOURCES]
    s = Scanner(roots, min_cache_mb=args.min_cache, top_n=args.top,
                verbose=args.verbose, personal_roots=personal_dirs).walk()

    out("\n【磁盘水位】C 盘")
    if total:
        out("  总容量 %s | 已用 %s (%.1f%%) | 可用 %s"
            % (fmt_size(total), fmt_size(used), used * 100.0 / total, fmt_size(free)))
    out("  本次遍历文件 %d 个，合计 %s，耗时 %.1f 秒"
        % (s.file_count, fmt_size(s.total_scanned), s.elapsed))
    out("  （合计只含普通遍历；已识别为可清理缓存的目录按整棵计入下方小计，"
        "不重复累加）")

    out("\n【占用 TOP 目录】")
    for key, size in s.top_dirs(args.top_dirs):
        out("  %10s  %s" % (fmt_size(size), key))

    out("\n【TOP 大文件】")
    for size, p in s.top_files():
        out("  %10s  %s" % (fmt_size(size), p))

    out("\n【可清理缓存目录】(>=%dMB，可再生，删除不影响使用)" % args.min_cache)
    cl = s.top_cache(args.cache_list)
    for size, p in cl:
        out("  %10s  %s" % (fmt_size(size), p))
    if not cl:
        out("  (未发现)")
    out("  小计: %s" % fmt_size(s.cache_total()))

    lines = ["# C盘管家 体检报告", "",
             "生成时间: %s" % started_at.strftime("%Y-%m-%d %H:%M:%S"), "",
             "## 磁盘水位", "",
             "- C盘总容量: %s" % fmt_size(total),
             "- 已用: %s (%.1f%%)" % (fmt_size(used), used * 100.0 / total if total else 0),
             "- 可用: %s" % fmt_size(free), "",
             "## 占用 TOP 目录", "",
             "| 大小 | 路径 |", "|---|---|"]
    for k, v in s.top_dirs(args.top_dirs):
        lines.append("| %s | `%s` |" % (fmt_size(v), k))
    lines += ["", "## TOP 大文件", "", "| 大小 | 文件 |", "|---|---|"]
    for v, p in s.top_files():
        lines.append("| %s | `%s` |" % (fmt_size(v), p))
    lines += ["", "## 可清理缓存", "", "| 大小 | 目录 |", "|---|---|"]
    for v, p in cl:
        lines.append("| %s | `%s` |" % (fmt_size(v), p))
    lines += ["", "**可清理小计: %s**" % fmt_size(s.cache_total())]
    if is_free_edition():
        # 免费技能版三处钩子之一：体检报告结尾（报告本身是自传播载体）
        lines += ["", "---",
                  "_本报告由 **C盘管家免费技能版** 生成，扫描全程本地只读、不上传任何数据。_",
                  "_%s_" % pro_upgrade_text(None)]

    # 机器可读清单，供 clean 复用
    cache_json = REPORT_DIR / "last-scan-cache.json"
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    cache_json.write_text(json.dumps(
        [{"size": v, "path": p} for v, p in s.cache_dirs], ensure_ascii=False, indent=1),
        encoding="utf-8")

    ts = started_at.strftime("%Y%m%d_%H%M%S")
    f = write_report("scan", lines, ts=ts)

    html = render_scan_html(total, used, free, s.top_dirs(args.top_dirs),
                            s.top_files(), cl, s.cache_total(), s.elapsed,
                            cache_count=len(s.cache_dirs))
    hf = REPORT_DIR / ("scan_%s.html" % ts)
    hf.write_text(html, encoding="utf-8")

    out("\n" + "=" * 68)
    out("  报告: %s" % f)
    out("  可视化报告: %s" % hf)
    out("  缓存清单(供 clean 用): %s" % cache_json)
    if is_free_edition():
        out("  " + pro_upgrade_text(None))
    out("=" * 68)

    emit({
        "command": "scan", "mode": "readonly", "scope": args.scope,
        "edition": edition_info()["edition"],
        "pro_url": edition_info()["pro_url"],
        "roots": [str(r) for r in roots],
        "disk": {"total": total, "used": used, "free": free},
        "file_count": s.file_count, "scanned_bytes": s.total_scanned,
        "elapsed_sec": round(s.elapsed, 1),
        "cache": {"total_bytes": s.cache_total(), "count": len(s.cache_dirs),
                  "items": [{"size": v, "path": p} for v, p in cl]},
        "reports": {"markdown": str(f), "html": str(hf),
                    "cache_list": str(cache_json)},
    })
    return 0


def cmd_clean(args):
    cache_dirs = []
    cj = REPORT_DIR / "last-scan-cache.json"
    if args.use_scan:
        if not cj.exists():
            out("%s 未找到 scan 缓存清单: %s" % (TAG_INFO, cj))
            out("       本轮不含 scan 发现的软件缓存目录；建议先跑: py butler.py scan")
        else:
            try:
                raw = json.loads(cj.read_text(encoding="utf-8"))
                cache_dirs = [(int(c["size"]), str(c["path"])) for c in raw]
            except Exception as e:
                out("%s scan 清单损坏，已忽略: %s" % (TAG_INFO, e))
                cache_dirs = []
            if cache_dirs:
                age_days = (time.time() - cj.stat().st_mtime) / 86400
                if age_days > 7:
                    out("%s scan 清单已 %.0f 天，大小可能变化；删除前会逐项重新校验"
                        "路径与安全规则，建议有空重跑 scan。" % (TAG_INFO, age_days))
                if not any(Path(p).exists() for _, p in cache_dirs):
                    out("%s 清单中的路径均已不存在，建议重跑 scan。" % TAG_INFO)

    if args.execute and not args.yes:
        out("!" * 68)
        out("  即将执行真实清理。此操作会删除缓存/临时文件，不可恢复。")
        out("  确认请加 --yes 参数。")
        out("!" * 68)
        emit({"command": "clean", "aborted": True, "reason": "confirmation_required"})
        return 2

    out("=" * 68)
    out("  C盘管家 - 清理  模式: %s" % ("实际执行" if args.execute else "预览(不动手)"))
    out("=" * 68)
    drive_free_before = disk_usage("C:")[2]

    c = Cleaner(execute=args.execute, do_recycle=not args.no_recycle_bin,
                cache_dirs=cache_dirs,
                pro_locked=getattr(args, "_force_pro_locked", None),
                include_dev_browsers=getattr(args, "include_dev_browsers", False)).run()

    out("\n【清理汇总】可释放 %s（已清 %d 项，跳过 %d 项，安全拦截 %d 项%s）"
        % (fmt_size(c.freed), len(c.cleaned), len(c.skipped), len(c.protected),
           ("，Pro 门控 %d 项" % len(c.locked)) if c.locked else ""))
    if c.protected:
        out("  以下项目本次未动:")
        for name, path, size, reason in c.protected:
            out("   - [%s] %s (%s) %s" % (reason, name, fmt_size(size), path))
    if c.skip_hints:
        out("  删不动的项目，请关闭对应程序后重跑：")
        for hint in sorted(set(c.skip_hints.values())):
            out("   - %s" % hint)
    if c.locked:
        locked_bytes = sum(z for _, _, z in c.locked)
        out("\n【Pro 深度项（免费版只预览、本次未执行）】合计 %s（%d 项）"
            % (fmt_size(locked_bytes), len(c.locked)))
        for name, path, size in c.locked:
            out("   - %s (%s) %s" % (name, fmt_size(size), path))
        out("  " + pro_upgrade_text(PRO_FEATURE_DEEP_CLEAN))

    lines = ["# C盘管家 清理报告", "",
             "模式: %s" % ("实际执行" if args.execute else "预览"),
             "时间: %s" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "",
             "## 明细", "", "| 项目 | 大小 | 路径 |", "|---|---|---|"]
    for name, path, size in c.cleaned:
        lines.append("| %s | %s | `%s` |" % (name, fmt_size(size), path))
    lines += ["", "**合计: %s**" % fmt_size(c.freed)]
    if c.skipped:
        lines += ["", "## 跳过（被占用/无权限，未删成）", "",
                  "| 项目 | 大小 | 建议关闭 | 路径 |",
                  "|---|---|---|---|"]
        for name, path, size in c.skipped:
            lines.append("| %s | %s | %s | `%s` |"
                         % (name, fmt_size(size),
                            c.skip_hints.get(norm(path), "-"), path))
    if c.protected:
        lines += ["", "## 安全拦截（本次未动）", "",
                  "| 原因 | 项目 | 大小 | 路径 |", "|---|---|---|---|"]
        for name, path, size, reason in c.protected:
            lines.append("| %s | %s | %s | `%s` |"
                         % (reason, name, fmt_size(size), path))
    if c.locked:
        lines += ["", "## Pro 深度项（免费版未执行）", "",
                  "| 项目 | 大小 | 路径 |", "|---|---|---|"]
        for name, path, size in c.locked:
            lines.append("| %s | %s | `%s` |" % (name, fmt_size(size), path))
        lines += ["", "> " + pro_upgrade_text(PRO_FEATURE_DEEP_CLEAN)]
    if is_free_edition():
        lines += ["", "---",
                  "_本报告由 C盘管家免费技能版生成；体检/预览/固定类别清理永久免费。_"]

    if args.execute:
        after = disk_usage("C:")[2]
        real = after - drive_free_before
        out("  C盘可用空间: %s -> %s (实际 %s)"
            % (fmt_size(drive_free_before), fmt_size(after), fmt_delta(real)))
        lines += ["", "C盘可用空间: %s -> %s" % (fmt_size(drive_free_before), fmt_size(after))]
        # 本机实测：账面删除量与实际到账经常差一大截，必须解释，不许报喜不报忧
        gap = c.freed - real
        if real < 0 and c.freed > 0:
            # 清理途中后台程序在写盘：可用空间不升反降，属正常现象
            out("  %s 账面删除 %s，但清理途中其他程序写入了 %s，"
                "可用空间净变化 %s；被占用的磁盘块重启后仍会释放。"
                % (TAG_INFO, fmt_size(c.freed), fmt_size(-real), fmt_delta(real)))
            lines += ["", "> 清理途中后台写入 %s，净变化 %s（账面删除 %s）"
                      % (fmt_size(-real), fmt_delta(real), fmt_size(c.freed))]
        elif gap > 100 * 1024 ** 2:
            out("  %s 账面删除 %s，实际只回收 %s，差额 %s" %
                (TAG_INFO, fmt_size(c.freed), fmt_size(real), fmt_size(gap)))
            out("     原因: Windows 下被进程占用的文件，删后目录项消失但磁盘块不还。")
            out("     处理: 关闭相关程序或重启后自动释放，不必重复跑清理。")
            lines += ["", "> 实际回收 %s，差额 %s（被进程占用的磁盘块，重启后释放）"
                      % (fmt_size(real), fmt_size(gap))]
        if real == 0 and c.freed > 0:
            out("  %s 本轮空间无变化，属上述现象，非失败。" % TAG_INFO)
    else:
        out("  提示: 加 --execute --yes 才会真正清理")

    f = write_report("clean", lines)
    out("  报告: %s" % f)

    result = {
        "command": "clean", "mode": "execute" if args.execute else "preview",
        "edition": edition_info()["edition"],
        "book_freed_bytes": c.freed,
        "cleaned_count": len(c.cleaned), "skipped_count": len(c.skipped),
        "protected_count": len(c.protected),
        "locked_count": len(c.locked),
        "locked_bytes": sum(z for _, _, z in c.locked),
        "locked": [{"name": n, "path": p, "size": z} for n, p, z in c.locked],
        "pro_url": edition_info()["pro_url"],
        "cleaned": [{"name": n, "path": p, "size": z} for n, p, z in c.cleaned],
        "skipped": [{"name": n, "path": p, "size": z,
                     "hint": c.skip_hints.get(norm(p))}
                    for n, p, z in c.skipped],
        "protected": [{"name": n, "path": p, "size": z, "reason": r}
                      for n, p, z, r in c.protected],
        "free_before_bytes": drive_free_before,
        "report": str(f),
    }
    if args.execute:
        result["free_after_bytes"] = after
        result["real_freed_bytes"] = real
    emit(result)
    return 0


def cmd_migrate(args):
    if args.execute and is_free_edition():
        # 免费技能版：搬家执行整体门控（预检也不用跑，一个文件都不会动）
        msg = pro_upgrade_text(PRO_FEATURE_MIGRATE)
        out("!" * 68)
        out("  大文件搬家为客户端版（Pro）功能，免费版可无限次生成预览清单。")
        out("  " + msg)
        out("!" * 68)
        emit({"command": "migrate", "aborted": True, "reason": "pro_only",
              "feature": PRO_FEATURE_MIGRATE,
              "edition": "free", "pro_url": edition_info()["pro_url"],
              "message": msg})
        return 3
    if args.execute and not args.yes:
        out("!" * 68)
        out("  即将把大文件搬到其他盘。原位会留快捷方式。")
        out("  确认请加 --yes 参数。")
        out("!" * 68)
        emit({"command": "migrate", "aborted": True, "reason": "confirmation_required"})
        return 2
    out("=" * 68)
    out("  C盘管家 - 大文件迁移  目标盘: %s  只搬大于 %dMB 的文件  模式: %s"
        % (args.target, args.min_size, "实际执行" if args.execute else "预览"))
    out("=" * 68)
    m = Migrator(target_drive=args.target, min_size_mb=args.min_size,
                 execute=args.execute).run()
    if m.preflight_errors:
        out("\n【迁移中止】预检未通过，未移动任何文件:")
        for why in m.preflight_errors:
            out("  - %s" % why)
        out("  处理: 插好目标盘/换一个盘/调小 --min-size 后重跑。")
        emit({"command": "migrate", "aborted": True,
              "errors": m.preflight_errors})
        return 1
    out("\n【迁移汇总】%d 个文件，共 %s" % (len(m.moved), fmt_size(m.total_moved)))
    if m.warnings:
        out("  其中 %d 个文件快捷方式创建失败（报告里标 [!]，按新位置去取）"
            % len(m.warnings))
    if not args.execute and is_free_edition():
        out("  " + pro_upgrade_text(PRO_FEATURE_MIGRATE))
    warn_names = {n for n, _ in m.warnings}
    lines = ["# C盘管家 迁移报告", "",
             "模式: %s" % ("实际执行" if args.execute else "预览"),
             "目标盘: %s" % args.target, "",
             "| 文件 | 大小 | 新位置 | 门牌 |", "|---|---|---|---|"]
    for name, dest, size in m.moved:
        flag = "缺失[!]" if name in warn_names else "OK"
        lines.append("| %s | %s | `%s` | %s |" % (name, fmt_size(size), dest, flag))
    lines += ["", "**合计: %s**" % fmt_size(m.total_moved)]
    if not args.execute and is_free_edition():
        lines += ["", "> " + pro_upgrade_text(PRO_FEATURE_MIGRATE)]
    if m.warnings:
        lines += ["", "## 快捷方式创建失败的文件（文件本身已迁移，去新位置取）", ""]
        for name, dest in m.warnings:
            lines.append("- `%s` -> `%s`" % (name, dest))
    f = write_report("migrate", lines)
    out("  报告: %s" % f)
    emit({
        "command": "migrate", "mode": "execute" if args.execute else "preview",
        "edition": edition_info()["edition"],
        "pro_url": edition_info()["pro_url"],
        "target": args.target, "min_size_mb": args.min_size,
        "moved_count": len(m.moved), "moved_bytes": m.total_moved,
        "moved": [{"name": n, "dest": d, "size": z} for n, d, z in m.moved],
        "shortcut_failed": [{"name": n, "dest": d} for n, d in m.warnings],
        "report": str(f),
    })
    return 0


# ============ 隐藏占用回收（v2.0） ============

# 磁盘上说被占着、但在用户目录里怎么翻都找不到的那部分，主要藏在这几处
RECLAIM_TARGETS = [
    ("$RECYCLE.BIN 回收站", "C:\\$RECYCLE.BIN", "recycle"),
    ("Windows 旧系统残留", "C:\\Windows.old", "tree"),
    ("升级临时目录", "C:\\$WINDOWS.~BT", "tree"),
    # 注意：Windows 更新下载缓存（SoftwareDistribution\\Download）不放在这里 ——
    # clean 的固定类别已经清它（只清内容、保留目录），两边都计会让
    # reclaim -> clean 连跑时账面虚高一倍。
    ("传递优化缓存", "C:\\ProgramData\\Microsoft\\Windows\\DeliveryOptimization", "tree"),
    # CBS 只清内容保留目录本身：服务栈按固定路径写日志，目录没了未必及时重建
    ("CBS 安装日志", "C:\\Windows\\Logs\\CBS", "contents"),
]

# 看得见但删不得、或需要管理员/改系统设置的，只给命令不代劳
READONLY_ITEMS = [
    ("C:\\hiberfil.sys", "休眠文件，体积≈物理内存。管理员跑 powercfg -h off 可释放"),
    ("C:\\pagefile.sys", "虚拟内存。系统属性→高级→性能里改大小，别手工删"),
    ("C:\\swapfile.sys", "UWP 交换文件，同上"),
    ("卷影副本/系统还原", "vssadmin list shadowstorage 查看，"
                        "vssadmin Resize ShadowStorage /For=C: /On=C: /MaxSize=2GB 缩容"),
]

# 巨大但绝对不能碰：生产工具、卸载依赖、系统组件。删了要出事
DO_NOT_TOUCH_SIZED = [
    ("C:\\ProgramData\\cocos", "Cocos Creator 引擎资源库（小游戏开发工具），删了编辑器起不来"),
    ("C:\\ProgramData\\Package Cache", "VC++ / .NET 卸载缓存，修复或卸载程序时要用"),
]
DO_NOT_TOUCH_NOTE = [
    ("C:\\Program Files / Program Files (x86)", "应用安装目录，只能走卸载器"),
    ("C:\\Windows\\WinSxS", "组件存储，只能 dism /StartComponentCleanup，手工删会炸系统"),
    ("C:\\Windows\\Installer", "MSI 安装源，删了程序无法卸载/修复"),
    ("C:\\System Volume Information", "系统还原点与卷影，用 vssadmin 管"),
]


def cmd_reclaim(args):
    """回收隐藏占用。这是「C盘又满了」时收益最高的一步，建议先跑它。

    本机实测：连续清理多轮只回到 6 GB，一度以为是"删了不还"；
    实际是 15.25 GB 躺在 C:\\$RECYCLE.BIN 里（PowerShell 双引号中 $Recycle
    被展开为变量，单引号写法才能读到），清掉后可用空间从 6 GB 跳到 17 GB。
    """
    execute = bool(args.execute and args.yes)
    du = disk_usage("C:\\")
    free0, total = du[2], du[0]
    out("=" * 68)
    out("  C盘管家 - 隐藏占用回收   模式: %s" % ("实际执行" if execute else "预览"))
    out("=" * 68)
    out("可用空间: %s / 共 %s (已用 %s)\n"
        % (fmt_size(free0), fmt_size(total), fmt_size(total - free0)))

    plan = []
    for name, path, kind in RECLAIM_TARGETS:
        if kind == "recycle":
            size = recycle_bin_size()
        else:
            size = tree_size(path) if os.path.isdir(path) else 0
        if size > 0:
            plan.append((name, path, kind, size))

    lines = ["# C盘管家 隐藏占用回收报告", "",
             "模式: %s" % ("实际执行" if execute else "预览"),
             "时间: %s" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "",
             "| 项目 | 大小 | 路径 |", "|---|---|---|"]

    out(">> 可回收项")
    sub = 0
    if not plan:
        out("  （干净，没找到隐藏大户）")
    for name, path, kind, size in plan:
        sub += size
        out("  %s %s: %s" % (TAG_PREVIEW, name, fmt_size(size)))
        out("        %s" % path)
        lines.append("| %s | %s | `%s` |" % (name, fmt_size(size), path))
    lines += ["", "**可回收合计: %s**" % fmt_size(sub)]

    out("\n>> 需要管理员/系统设置，本技能只读提示")
    for item, fix in READONLY_ITEMS:
        size = 0
        try:
            if os.path.isfile(item):
                size = os.path.getsize(item)
        except OSError:
            size = 0
        tail = " (%s)" % fmt_size(size) if size else ""
        out("  %s %s%s" % (TAG_INFO, item, tail))
        out("        %s" % fix)

    out("\n>> 巨大但绝对不能删")
    for path, why in DO_NOT_TOUCH_SIZED:
        if not os.path.isdir(path):
            continue
        size = tree_size(path)
        if size < 200 * 1024 ** 2:
            continue
        out("  %s %s: %s" % (TAG_SKIP, path, fmt_size(size)))
        out("        %s" % why)
    for path, why in DO_NOT_TOUCH_NOTE:
        out("  %s %s" % (TAG_SKIP, path))
        out("        %s" % why)

    out("\n可回收合计: %s" % fmt_size(sub))

    def reclaim_payload(f, free1=None, got=None):
        d = {"command": "reclaim", "mode": "execute" if execute else "preview",
             "plan": [{"name": n, "path": p, "kind": k, "size": z}
                      for n, p, k, z in plan],
             "book_bytes": sub, "free_before_bytes": free0, "report": str(f)}
        if free1 is not None:
            d["free_after_bytes"] = free1
            d["real_freed_bytes"] = got
        return d

    if not execute:
        out("提示: 加 --execute --yes 才真动手")
        f = write_report("reclaim", lines)
        out("报告: %s" % f)
        emit(reclaim_payload(f))
        return 0

    out("\n>> 执行")
    for name, path, kind, size in plan:
        if kind == "recycle":
            rc, _ = ps_run("Clear-RecycleBin -DriveLetter C -Force "
                           "-ErrorAction SilentlyContinue", timeout=600)
            left = recycle_bin_size()
            out("  %s %s: %s -> %s%s"
                % (TAG_CLEAN, name, fmt_size(size), fmt_size(left),
                   "" if rc == 0 else " (部分失败，可能需管理员)"))
        elif kind == "contents":
            try:
                items = [str(x) for x in Path(path).iterdir()]
            except OSError:
                items = []
            survivors, _timed = ps_delete_paths(items) if items else (set(), set())
            ok = not survivors
            out("  %s %s: %s" % (TAG_CLEAN if ok else TAG_SKIP, name,
                                "内容已清空（目录保留）" if ok
                                else "部分失败，多半是权限 -> 用管理员 PowerShell 重跑"))
        else:
            rc = ps_delete_tree(path)
            if rc is None:
                out("  %s %s: 删除超时（%ds），疑似被占用 -> 关闭相关程序或重启后重跑"
                    % (TAG_SKIP, name, PS_TREE_TIMEOUT))
            else:
                out("  %s %s: %s" % (TAG_CLEAN if rc else TAG_SKIP, name,
                                    "已删除" if rc else "失败，多半是权限 -> 用管理员 PowerShell 重跑"))
            ok = rc is True
            if not ok and path in (r"C:\Windows.old", r"C:\$WINDOWS.~BT"):
                out("        系统残留受 TrustedInstaller 保护时，可用管理员命令行：")
                out("        takeown /F \"%s\" /R /D Y && icacls \"%s\" /grant administrators:F /T"
                    % (path, path))
                out("        然后再重跑本命令。")

    free1 = disk_usage("C:\\")[2]
    got = free1 - free0
    out("\n可用空间: %s -> %s (实际 %s)" % (fmt_size(free0), fmt_size(free1), fmt_delta(got)))
    gap = sub - got
    if gap > 100 * 1024 ** 2:
        out("  %s 账面 %s / 实际 %s，差额 %s" %
            (TAG_INFO, fmt_size(sub), fmt_size(got), fmt_size(gap)))
        out("     多半是被进程占用的磁盘块，或文件删了仍勾在回收站里，重启后自动到账。")
    lines += ["", "实际回收: %s（可用空间 %s -> %s）" % (fmt_size(got), fmt_size(free0), fmt_size(free1))]
    f = write_report("reclaim", lines)
    out("报告: %s" % f)
    emit(reclaim_payload(f, free1, got))
    return 0


def main():
    if sys.platform != "win32":
        out("本技能只支持 Windows（依赖 AppData / PowerShell / 回收站接口）。")
        return 1

    ap = argparse.ArgumentParser(
        description="C盘管家 - Windows 磁盘瘦身")
    ap.add_argument("--version", action="version",
                    version="c-drive-butler %s" % VERSION)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add_json(sp):
        sp.add_argument("--json", action="store_true",
                        help="只输出一份 JSON 结构化结果（供程序/AI 调用）")

    p = sub.add_parser("scan", help="只读体检")
    p.add_argument("--scope", choices=["default", "user", "appdata", "all"], default="default")
    p.add_argument("--top", type=int, default=25, help="TOP 大文件数量")
    p.add_argument("--top-dirs", type=int, default=15, help="TOP 目录数量")
    p.add_argument("--min-cache", type=int, default=20, help="缓存目录只清 ≥ N MB，默认 20")
    p.add_argument("--cache-list", type=int, default=25, help="缓存清单展示条数")
    p.add_argument("--verbose", action="store_true")
    add_json(p)
    p.set_defaults(func=cmd_scan)

    p = sub.add_parser("clean", help="清理垃圾（默认预览）")
    p.add_argument("--execute", action="store_true", help="真正执行")
    p.add_argument("--yes", action="store_true", help="跳过确认")
    p.add_argument("--no-recycle-bin", action="store_true", help="不清回收站")
    p.add_argument("--use-scan", dest="use_scan", action="store_true", default=True,
                   help="复用上次 scan 的缓存清单（默认开启）")
    p.add_argument("--no-use-scan", dest="use_scan", action="store_false",
                   help="不复用 scan 清单，只清固定类别")
    p.add_argument("--include-dev-browsers", action="store_true",
                   help="连 Playwright/Puppeteer 已下载的浏览器二进制一起清"
                        "（默认不删，删了需联网重下）")
    add_json(p)
    p.set_defaults(func=cmd_clean)

    p = sub.add_parser("reclaim", help="隐藏占用回收（回收站/Windows.old/升级残留/CBS，建议先跑）")
    p.add_argument("--execute", action="store_true")
    p.add_argument("--yes", action="store_true")
    add_json(p)
    p.set_defaults(func=cmd_reclaim)

    p = sub.add_parser("migrate", help="大文件迁移（默认预览）")
    p.add_argument("--execute", action="store_true")
    p.add_argument("--yes", action="store_true")
    p.add_argument("--target", default="D:", help="目标盘，默认 D:")
    p.add_argument("--min-size", type=int, default=500, help="只搬大于 N MB 的文件，默认 500")
    add_json(p)
    p.set_defaults(func=cmd_migrate)

    args = ap.parse_args()
    global JSON_MODE
    JSON_MODE = bool(getattr(args, "json", False))
    rc = args.func(args)
    if JSON_MODE:
        # version 在出口统一注入，各 cmd 的 emit 不用各自维护
        print(json.dumps({"version": VERSION, **LAST_RESULT},
                         ensure_ascii=False, indent=1))
    return rc


if __name__ == "__main__":
    sys.exit(main())
