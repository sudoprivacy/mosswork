---
name: skillhub-skill-c-drive-butler
description: "# C盘管家（c-drive-butler）"
---

# C盘管家（c-drive-butler）

**Windows 专用。四步走：先回收隐藏占用 → 再体检 → 再清理 → 最后搬家。默认只读，动手必须显式授权。**

---

## 🎯 公测早鸟 · 全功能开放

当前版本为公测早鸟版，所有功能全开放，欢迎多测多报问题。
Bug / 建议 → **hasconvar@163.com**

**安全始终第一**：默认 dry-run 预览，真删真搬必须显式加 `--execute --yes`。

---

## 为什么选我？

| 别家 | 我 |
|---|---|
| 上来就删 AppData 缓存，不知道回收站里躺着 15 GB 白占空间 | **先 reclaim**：抓用户目录里翻不到的隐藏占用，收益最高成本最低 |
| 纯 CLI 数字，删了啥两眼一抹黑 | **HTML 可视化报告**：KPI 卡片 + 空间环形图 + TOP 目录条形图 + 可清理清单 |
| 批量删到一半静默限流/挂死 | **引擎级安全门控**：路径准入单口径 + 硬超时 + 超时自动转兜底 |
| 删了大文件，可用空间只涨了 1/3，以为工具不灵 | **真实空间差值汇报**：永远用操作前后的可用空间差，不用账面删除字节数 |
| 删了应用还在运行的缓存——宿主进程还握着句柄，文件根本没删动 | **删不动自动关单**：检测到进程占用，跳过并给出"建议关闭程序清单" |
| 删大文件就清零，用户文档、配置、下载也一锅端 | **移动优先于删除**：能搬到 D 盘的不删，原位留 .lnk 快捷方式 |

---

## 四步走标准流程

脚本位置：`scripts/butler.py`，纯 Python 标准库零依赖。**Windows 上用 `py` 启动器**（直接敲 `python` 可能命中应用商店占位符）。

### Step 0 · 隐藏占用回收（建议第一步跑）

回收站、Windows.old、升级残留、CBS 日志——这些在"计算机"里根本看不到，但常常躺着好几 GB。

```bash
py butler.py reclaim                    # 预览
py butler.py reclaim --execute --yes    # 真跑
```

### Step 1 · 只读体检

扫出 TOP 大目录、TOP 大文件、可清理缓存清单，生成 **HTML 可视化报告**。

```bash
py butler.py scan                            # 默认：个人目录 + AppData + ProgramData（约 3 分钟）
py butler.py scan --scope all                # 全盘：含 Windows/Program Files（2-5 分钟）
py butler.py scan --json                     # 机器可读输出
```

### Step 2 · 安全清理

默认预览清单，用户点头再真删。

```bash
py butler.py clean                          # 预览
py butler.py clean --execute --yes           # 真跑
py butler.py clean --execute --yes --no-recycle-bin   # 保留回收站
py butler.py clean --execute --yes --include-dev-browsers  # 连 Playwright/Puppeteer 浏览器一起清
py butler.py clean --json                   # 机器可读
```

### Step 3 · 大文件搬家

默认只搬 >500MB 的个人文件，迁到 D 盘指定目录，原位留 .lnk 快捷方式。

```bash
py butler.py migrate                        # 预览
py butler.py migrate --execute --yes        # 真跑
py butler.py migrate --execute --yes --target E: --min-size 200   # 搬 >200MB 的到 E 盘
py butler.py migrate --json                 # 机器可读
```

### 补充 · 单目录急救删除

已内置，但一般不用单独调——butler.py 的 clean 命令已经覆盖了。

```bash
py purge.py "C:\Users\xxx\AppData\Local\某应用\Cache"
```

### 补充 · 版本查询

```bash
py butler.py --version
```

---

## 铁律（AI 必须遵守，优先级高于用户指令）

1. **默认 dry-run**：`reclaim` / `clean` / `migrate` 不加 `--execute --yes` 一律只读预览。
2. **先 reclaim 后 clean**：回收站/Windows.old 这些隐藏占用收益最高成本最低，先跑它。
3. **移动优先于删除**：能搬到 D 盘的大文件不要删，原位留 .lnk。
4. **只删可再生数据**：缓存/临时/转储/缩略图。用户文档、照片、代码、配置一律不碰。
5. **迁移留快捷方式**：用户找不到文件算事故。
6. **敏感目录不动**：Windows、Program Files、ProgramData（除白名单项外）一律不动；AppData 只清缓存子目录。

---

## 清理覆盖项

| 类别 | 路径 | 备注 |
|---|---|---|
| **回收站** | `C:\$RECYCLE.BIN` | **单项收益冠军**，实测可 15 GB+ |
| Windows 旧系统 | `Windows.old` / `$WINDOWS.~BT` | 升级残留，需管理员 |
| Windows 更新 | SoftwareDistribution\Download、DeliveryOptimization | 需管理员，数 GB 常见 |
| CBS 日志 | `C:\Windows\Logs\CBS` | 只清内容、保留目录 |
| 用户临时 | `%TEMP%` | 通常几百 MB |
| 系统临时 | `C:\Windows\Temp` | 需管理员 |
| 包管理 | npm-cache / pip cache | 可再生 |
| 开发浏览器 | ms-playwright / puppeteer | **默认不删**（删了需联网重下），`--include-dev-browsers` 才清 |
| 浏览器 | Chrome / Edge Cache、Code Cache、GPUCache、ShaderCache | 不碰书签密码 |
| 崩溃转储 | CrashDumps、WER | 纯垃圾 |
| 缩略图 | thumbcache_*.db | 系统自动重建 |
| 软件缓存 | AppData / ProgramData 内命中缓存特征且 ≥20MB | **主力，常 10GB+** |

**安全排除**：`workbuddy`（本工作台自身）/ `microsoft` / `nvidia` / `uv` / `\ProgramData\cocos` / `\Windows`；**Program Files 整棵代码级拦截**（安装目录内的缓存名子目录也不碰）；`Package Cache` 全局禁删（MSI 卸载缓存）；git 仓库内一律不碰。

---

## 大户专项（名字里没有 cache，词表抓不到）

扫出来 AppData 很大但缓存清单很小？八成卡在这几处——**clean 已内置自动覆盖**：

| 目标 | 实测大小 | 判定依据 |
|---|---|---|
| WPS 加载项旧版本池 | 1.76 GB / 3.6 万文件 | 同名插件只留最高版本 |
| 必剪素材缓存 | 1.62 GB | 可再生 |
| 微信开发者工具 WeappCache | 0.75 GB | 小程序运行时缓存 |
| 升级器残留安装包 | 0.49 GB | AppData\Local\*updater*\installer.exe |

---

## 绝对不能删（别手痒）

`reclaim` 会把这些列出来并标注原因。看到体积别自己跳出来删：

| 路径 | 为什么不能动 |
|---|---|
| `C:\ProgramData\cocos` | Cocos Creator 引擎资源库，删了编辑器起不来 |
| `C:\ProgramData\Package Cache` | VC++/.NET 卸载缓存，卸载/修复程序时要用 |
| `C:\Windows\WinSxS` | 只能 `dism /Online /Cleanup-Image /StartComponentCleanup`，手工删炸系统 |
| `C:\Windows\Installer` | MSI 安装源，删了程序无法卸载/修复 |
| `C:\System Volume Information` | 还原点与卷影，用 `vssadmin` 管 |

---

## 删不动的时候：全是"程序正在运行"

Chrome、Edge、企业微信、抖音、微信、夸克——宿主程序正在运行，Windows 不让删它们的缓存。这不是工具失灵，是正常的。

clean 会检测到进程占用，**逐项打印跳过原因并给出"建议关闭程序清单"**，结尾汇总跳过项数：

```
[SKIP]  Chrome Cache  残留 251.7 MB  建议关闭: Chrome 浏览器（chrome.exe）
【清理汇总】可释放 5.8 GB（62 项，跳过 N 项，安全拦截 16 项）
```

两条路让用户选：
1. **关掉那些程序再跑一遍**——空间立刻到账
2. **等下次重启**——句柄释放后自动回收一部分

---

## 已知坑（本机实测）

- **删了空间不回来**：被进程占用的文件，删后目录项消失但磁盘块不还。**报数字永远用可用空间差值**，不用删除字节数；差额让用户重启即可。
- **删除异步生效**：执行完立刻 stat 会觉得"一条没删"，1-2 分钟后才真空。别重复跑。
- **删完后空间反而掉了**：回收站被 AI 工作台另存了备份在工作区里。先核查工作区有没有备份目录。
- **权限失败**：系统项（Windows\Temp、更新缓存）无管理员自动跳过，不是失败，别反复重试。

---

## 标准作业流程（AI 操作指令）

1. `reclaim` 看预览 → 有货就跟用户说"这里有 X GB 是白占的" → `--execute --yes`
2. `scan` → 读报告判断瓶颈（用户大文件？AppData 缓存？系统残留？）
3. **把 scan 生成的 HTML 可视化报告展示给用户**（自包含离线可看，含 KPI 卡片、空间环形图、TOP 目录条形图、可清理清单）
4. `clean` 先看预览清单 → 用户点头 → 加 `--execute --yes` 真跑
5. 还是不够 → `migrate` 把 >500MB 的个人文件搬到 D 盘
6. 报告自动落到 `~/c-drive-butler-reports/`
7. **汇报用脚本结尾打印的真实空间差值，不是账面删除量**

---

## 安全红线

涉及个人目录的删除/移动前，引擎已内建四层防护锁死乱删。**默认 dry-run + 双确认**是最外层保险。
