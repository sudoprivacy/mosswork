# B站视频脚本策划

为 B 站知识区、科技区、生活区视频生成选题、标题、脚本、分镜和三连引导。

## 内容

- `SKILL.md`：技能主体说明
- `_meta.json`：SkillHub 元数据
- `README.md`：使用说明
- `LICENSE.md`：MIT License

## 触发关键词

- B站脚本
- 视频大纲
- 三连
- 知识区
- UP主
- 分镜

## 作者

原创：ikun

## License

MIT © 2026 ikun
