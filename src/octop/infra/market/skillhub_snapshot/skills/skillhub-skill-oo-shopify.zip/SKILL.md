---
name: skillhub-skill-oo-shopify
description: "Shopify REST Admin (shopify.com). Use this skill for ANY Shopify REST Admin request — searching and reading data. Whenever a task involves Shopify REST Admin, use this skill instead of calling the API directly."
---

# Shopify REST Admin

Operate **Shopify REST Admin** through your OOMOL-connected account. This skill calls the `shopify` connector with the [oo CLI](https://github.com/oomol-lab/oo-cli); OOMOL injects credentials server-side, so you never handle raw tokens.

## Running an action

Assume the user has already installed the oo CLI, signed in, and connected Shopify REST Admin. **Do not run `oo auth login` or open the connection URL proactively — just run the action.** Fall back to [First-time setup](#first-time-setup) only when a command actually fails with an auth or connection error.

**1. Inspect the contract** to get the authoritative input/output schema before building a payload:

```bash
oo connector schema "shopify" --action "<action_name>"
```

**2. Run the action** with a JSON payload that matches the input schema:

```bash
oo connector run "shopify" --action "<action_name>" --data '<json>' --json
```

- `--data` takes a JSON object string or `@path/to/file.json`; omit it to send `{}`.
- The response is `{ "data": ..., "meta": { "executionId": "..." } }`; the execution id lives under `meta.executionId`.

Each action is listed below with a one-line description; actions that change state carry a `[write]` or `[destructive]` tag. Before constructing `--data`, fetch the action's live schema with `oo connector schema` to get its authoritative input fields.

## Available actions

- `count_articles` — Count Shopify REST articles in a blog with optional filters.
- `count_blogs` — Count Shopify REST blogs in the connected shop.
- `count_pages` — Count Shopify REST pages with optional filters.
- `get_article` — Retrieve one Shopify REST article by blog ID and article ID.
- `get_blog` — Retrieve one Shopify REST blog by numeric ID.
- `get_page` — Retrieve one Shopify REST page by numeric ID.
- `get_shop` — Retrieve the connected Shopify REST Admin shop configuration.
- `list_article_tags` — List Shopify REST article tags across all articles in the connected shop.
- `list_articles` — List Shopify REST articles in a blog with optional filters and pagination.
- `list_blogs` — List Shopify REST blogs with optional handle filtering and pagination.
- `list_pages` — List Shopify REST pages with optional filters and pagination.

## Safety

- Untagged actions are reads (get / list / search) — safe to run directly.
- **Actions tagged `[write]` change Shopify REST Admin state — confirm the exact payload and effect with the user before running.**
- **Actions tagged `[destructive]` remove or overwrite data — always confirm the target and get explicit approval first.**

## First-time setup

These are **one-time** steps — do not repeat them on every call. Run a step only when a command fails for the matching reason.

- **`oo: command not found`** — install the oo CLI (other platforms: <https://cli.oomol.com/install-guide.md>):

  ```bash
  curl -fsSL https://cli.oomol.com/install.sh | bash    # macOS / Linux
  ```

  ```powershell
  irm https://cli.oomol.com/install.ps1 | iex           # Windows PowerShell
  ```

- **Not signed in / authentication error** — sign in to your OOMOL account once:

  ```bash
  oo auth login
  ```

- **`scope_missing` / `credential_expired` / `app_not_ready` / `app_not_found`** — Shopify REST Admin is not connected, or the connection expired or lacks a scope. Connect once (auth type: API key) at:

  ```text
  https://console.oomol.com/app-connections?provider=shopify
  ```

- **HTTP 402 / `OOMOL_INSUFFICIENT_CREDIT`** — billing stop. Recharge at `https://console.oomol.com/billing/token-recharge` before retrying.

## Resources

- Shopify REST Admin homepage: https://www.shopify.com
