# 安装与命令

首次使用请先登录 [文知管理平台](https://user.wenzhilab.com/)，在「API Key 管理」创建自己的文知 API Key；在私有聊天中提供给智能体，由它配置到本地。聊天和工具记录可能保留 Key。

## 运行与配置

将整个 `bilibili-to-markdown` 文件夹交给支持 `SKILL.md` 的宿主加载，保留子目录。脚本也可独立运行。需要 Python 3.10+，没有第三方 pip/npm 依赖；Windows 可用 `py -3` 代替示例中的 `python3`。不同宿主的 Skill 安装目录和授权方式由该宿主决定。

智能体在本机运行配置命令（手动配置时请替换脚本实际路径）：

```sh
python3 /path/to/bilibili-to-markdown/scripts/bilibili.py configure --output-dir "/path/to/文案"
```

手动运行时终端会隐藏输入平台 API Key；智能体运行时通过 `WENZHI_API_KEY` 环境变量提供 Key，验证账户后保存配置。不要在回复中复述真实 Key，也不要把它写进 Skill 文件。配置文件默认 `~/.wenzhi/bilibili-to-markdown/config.json`，新配置文件在 POSIX 上仅当前用户可读写。

仅需要平台 Key 和本地目录。网关固定为 `https://skillapi.wenzhilab.com/gateway`；不向文件下载地址发送平台 Key。

可选环境变量：`WENZHI_API_KEY` 覆盖配置中的 Key；`WENZHI_OUTPUT_DIR` 覆盖默认保存目录。默认优先使用系统实际下载目录下的 `wenzhi`；下载目录不存在时使用当前工作目录下的 `wenzhi`。配置、报价和确认前会检查目录可写，不可用则要求指定其他目录。所有命令的 `--config` 全局选项放在子命令之前。客户端不保存任务日志；请保留返回的云端任务编号。

## 常用命令

以下 `SCRIPT` 表示 `scripts/bilibili.py` 的绝对路径，`TASK_ID` 表示报价返回的云端任务编号。

```sh
python3 SCRIPT wallet
python3 SCRIPT inspect "https://space.bilibili.com/68963288"
python3 SCRIPT tasks --url "https://space.bilibili.com/68963288"
python3 SCRIPT tasks --page 2
python3 SCRIPT quote "https://www.bilibili.com/video/BV1KSBSB2EXa/" --timeout 120
python3 SCRIPT quote "https://space.bilibili.com/68963288" --limit 2 --output-dir "/path/to/文案"
python3 SCRIPT quote "https://space.bilibili.com/68963288" --all
python3 SCRIPT quote "https://space.bilibili.com/68963288" --range 31 60
python3 SCRIPT status TASK_ID
python3 SCRIPT confirm TASK_ID --quote-id QUOTE_ID --max-points 57 --yes
python3 SCRIPT wait TASK_ID --timeout 300 --interval 10
python3 SCRIPT resume TASK_ID --timeout 300
python3 SCRIPT download TASK_ID
python3 SCRIPT download TASK_ID --output-dir "/another/path"
```

`57` 只是命令格式示例，不是固定价格；使用本次展示并获授权的实际积分上限。`quote` 返回 `task.quote`（报价编号、总积分、有效期）及 `items`（标题、时长、每项积分）、`task_id` 和 `output_dir`。报价未生成完时返回当前分析状态，可用 `resume TASK_ID` 继续查询；不会自行确认。

`inspect` 查询链接类型、主页视频总数和可选范围，不创建转写任务。主页超过 30 条且用户未指定范围时，先让用户选择最新 30 条、全部或自定义范围。`--limit` 默认 30；`--all` 选择全部；`--range` 按最新在前的投稿序号选择，含起点和终点。三者互斥，单任务最多 1000 条，范围序号最大 10000。范围终点超过实际数量时取到最后一条，并在报价中展示实际范围。

`tasks` 查询当前 Key 所属用户的 B站任务，每页 50 条；`--url` 解析为规范来源地址，自动检查最多 20 页（1000 条）并返回匹配的 `matches`。`unidentified` 是尚无可比对来源的任务，`has_more` 表示还需翻页。相同主页不代表相同范围或相同视频清单；不要仅凭链接自动复用。用户说“继续”时使用选定的原任务编号；普通新请求遇到未完成旧任务时让用户选择。

大清单分析可能较久；等待窗口结束后使用原 `TASK_ID` 继续查询。完整清单只在报价就绪或执行结束时读取，运行中展示任务计数。命令输出最多预览 50 项，`items_total` 为读取总数、`items_truncated` 表示预览省略；报价的 `item_count` 和 `total_points` 始终覆盖全部选定视频。全部视频仍只确认一次总报价，失败视频退回对应积分。主页分析期间数量变化时，任务返回 `PROFILE_CHANGED`；`VIDEO_LIMIT_EXCEEDED` 表示全部超过 1000 条，应选择范围；`INVALID_RANGE` 表示起点超出主页或给单视频使用了范围。

`confirm` 仅确认当前报价；余额不足时充值后可重试同一报价，过期报价需要重新展示新报价。重复确认由服务端复用，不额外扣分。

`wait`/`resume` 的单次等待窗口最大 3600 秒，查询间隔为 5–60 秒。这不是云端任务时限。窗口结束且任务仍在运行时返回 `waiting: true`、当前进度和 `next_action`；继续使用同一 `TASK_ID` 调用 `resume`，不重新报价、确认或扣费。单次网关请求另有超时和最多两次重试，因此网络异常时命令可能略晚于等待窗口退出；文件下载中断可恢复同一任务。

`resume` 在已完成或部分完成时下载可用文件；未确认时展示报价，失败时返回失败状态，不重建任务。`download` 获取新的签名链接，下载所有已交付文件；`download_complete` 指所有可交付文件本地保存完成，仍需检查 `task_status`、`failed_items` 确认云端是否部分失败。

## 输出与退出码

stdout 每次输出一个 JSON 对象，进度写入 stderr。关键字段：`task.status`、`task.billing`、`items`、`task_id`、`download.files[].path`（resume），或 `files[].path`（download）。不把命令 `ok=true` 当作云端任务成功；查询本身成功时任务仍可能失败或等待中。

- `0`：命令完成；等待结束可能仍有任务在运行，检查状态。
- `1`：请求、配置、预算或本地错误，`error` 含稳定错误码；网络错误可恢复同一任务。
- `2`：文件仅部分下载，成功文件已保留；恢复下载不重做转写。
- `130`：用户中断本地等待，云端仍可能继续。

常见错误：`UNAUTHORIZED` 更新 Key；`INSUFFICIENT_BALANCE` 充值；`QUOTE_EXPIRED` 重新报价并确认；`FILES_EXPIRED` 已过服务端保留期；`BUDGET_EXCEEDED` 未扣费，不自动增大上限；`NETWORK_ERROR` 若已有任务编号则查询原任务；若创建报价未返回任务编号，可以重新报价。

客户端不保存任务日志。下载先在内存中完成大小、UTF-8 和哈希校验，再以独占方式新建 MD，不覆盖同名文件。单个 MD 最大 16 MB。若本地写入中途失败，可能留下未完成的文件；客户端不会将它报告为成功，重试下载时会校验哈希并另选文件名。
