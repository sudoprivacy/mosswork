#!/usr/bin/env python3
"""文知 B站转 Markdown 客户端。Python 3.10+，无需第三方依赖。"""
import argparse
import getpass
import json
import os
import re
import sys
from pathlib import Path
sys.dont_write_bytecode = True
from wenzhi_client.api import Api
from wenzhi_client.config import DEFAULT_CONFIG, default_output_dir, ensure_output_dir, load_config, save_config
from wenzhi_client.errors import ClientError
from wenzhi_client.storage import read_json
from wenzhi_client.workflow import Workflow


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", help="配置文件，默认 ~/.wenzhi/bilibili-to-markdown/config.json")
    sub = p.add_subparsers(dest="command", required=True)
    configure = sub.add_parser("configure", help="验证并保存平台 API Key 和本地目录")
    configure.add_argument("--output-dir")
    sub.add_parser("wallet", help="查询积分余额")
    inspect = sub.add_parser("inspect", help="查询链接类型和主页视频数量，不创建转写任务")
    inspect.add_argument("url")
    tasks = sub.add_parser("tasks", help="查询本人近期 B站任务；可按视频或主页链接筛选")
    tasks.add_argument("--url", help="仅显示同一视频或主页的任务")
    tasks.add_argument("--page", type=int, default=1, help="页码，默认 1，每页 50 条")
    quote = sub.add_parser("quote", help="创建报价；不确认、不扣积分")
    quote.add_argument("url", help="BV号、视频/主页链接或完整分享文本")
    selection = quote.add_mutually_exclusive_group()
    selection.add_argument("--limit", type=int, help="最新若干条，默认 30，最多 1000")
    selection.add_argument("--all", action="store_true", help="全部视频，单任务最多 1000 条")
    selection.add_argument("--range", type=int, nargs=2, metavar=("START", "END"), help="按最新在前的投稿序号指定闭区间")
    quote.add_argument("--output-dir")
    quote.add_argument("--timeout", type=int, default=120)
    confirm = sub.add_parser("confirm", help="确认已展示的报价；可能预扣积分")
    confirm.add_argument("task_id", help="云端任务编号")
    confirm.add_argument("--quote-id", required=True)
    confirm.add_argument("--max-points", type=int, required=True)
    confirm.add_argument("--yes", action="store_true")
    status = sub.add_parser("status", help="查询当前任务和视频清单")
    status.add_argument("task_id")
    for name in ("wait", "resume"):
        cmd = sub.add_parser(name, help="等待任务" if name == "wait" else "恢复原任务，完成后下载")
        cmd.add_argument("task_id")
        cmd.add_argument("--timeout", type=int, default=300)
        cmd.add_argument("--interval", type=int, default=10)
    download = sub.add_parser("download", help="获取新的文件链接，保存已交付的 Markdown")
    download.add_argument("task_id")
    download.add_argument("--output-dir")
    return p


def emit(value, *, error=False):
    print(json.dumps(value, ensure_ascii=False), file=sys.stderr if error else sys.stdout, flush=True)


def configure(args):
    path = Path(args.config or DEFAULT_CONFIG).expanduser().resolve()
    old = read_json(path) if path.exists() else {}
    output_dir = args.output_dir or old.get("output_dir") or str(default_output_dir())
    key = os.environ.get("WENZHI_API_KEY", "")
    if not key:
        if not sys.stdin.isatty():
            raise ClientError("API_KEY_REQUIRED", "请在终端交互输入 Key，或通过 WENZHI_API_KEY 环境变量提供。")
        key = getpass.getpass("文知平台 API Key（输入不显示）: ").strip()
    if not re.fullmatch(r"wz_(?:sk_)?[a-fA-F0-9]{64}", key):
        raise ClientError("INVALID_API_KEY", "平台 API Key 格式不正确。")
    wallet = Api(key).wallet()
    output_dir = ensure_output_dir(output_dir)
    save_config(path, key, output_dir)
    return {"configured": True, "config_file": str(path),
            "output_dir": str(Path(output_dir).expanduser().resolve()), "wallet": wallet}


def main(argv=None):
    args = parser().parse_args(argv)
    workflow = None
    try:
        if hasattr(args, "timeout") and not 0 <= args.timeout <= 3600:
            raise ClientError("INVALID_ARGUMENT", "--timeout 须为 0–3600 秒。")
        if hasattr(args, "interval") and not 5 <= args.interval <= 60:
            raise ClientError("INVALID_ARGUMENT", "--interval 须为 5–60 秒。")
        if args.command == "configure":
            result = configure(args)
        else:
            config = load_config(args.config)
            output_dir = getattr(args, "output_dir", None) or config["output_dir"]
            api = Api(config["api_key"])
            workflow = Workflow(api, output_dir,
                                progress=lambda value: emit({"progress": value}, error=True))
            if args.command == "wallet":
                result = {"wallet": api.wallet()}
            elif args.command == "inspect":
                result = api.inspect(args.url)
            elif args.command == "tasks":
                result = workflow.tasks(args.url, args.page)
            elif args.command == "quote":
                result = workflow.quote(args.url, args.limit if args.limit is not None else 30, args.timeout, mode="all" if args.all else "range" if args.range else "latest", start=args.range[0] if args.range else None, end=args.range[1] if args.range else None)
            elif args.command == "confirm":
                result = workflow.confirm(args.task_id, args.quote_id, args.max_points, args.yes)
            elif args.command == "status":
                result = workflow.status(args.task_id)
            elif args.command == "wait":
                result = workflow.wait(args.task_id, args.timeout, args.interval)
            elif args.command == "resume":
                result = workflow.resume(args.task_id, args.timeout, args.interval)
            else:
                result = workflow.download(args.task_id, args.output_dir)
        complete = result.get("download", result).get("download_complete", True)
        emit({"ok": complete, **result})
        return 0 if complete else 2
    except ClientError as error:
        if workflow and workflow.current_task:
            error.details.setdefault("task_id", workflow.current_task)
        emit({"ok": False, "error": error.as_dict()})
        return 1
    except KeyboardInterrupt:
        emit({"ok": False, "error": {"code": "INTERRUPTED", "message": "已停止等待。云端任务不会因此取消，可恢复原任务。", "task_id": workflow.current_task if workflow else None}})
        return 130
    except OSError:
        emit({"ok": False, "error": {"code": "LOCAL_IO_ERROR", "message": "本地文件读写失败，请检查目录权限和磁盘空间。", "task_id": workflow.current_task if workflow else None}})
        return 1


if __name__ == "__main__":
    sys.exit(main())
