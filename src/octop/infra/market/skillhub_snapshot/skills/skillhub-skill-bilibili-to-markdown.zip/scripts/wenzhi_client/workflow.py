import re
import time
import uuid
from .config import ensure_output_dir
from .downloads import Downloader
from .errors import ClientError

TERMINAL = {"succeeded", "partial_succeeded", "failed", "needs_attention"}


class Workflow:
    def __init__(self, api, output_dir, *, downloader=None, sleep=time.sleep, clock=time.monotonic, progress=None):
        self.api, self.output_dir = api, output_dir
        self.downloader = downloader or Downloader()
        self.sleep, self.clock, self.progress = sleep, clock, progress
        self.current_task = None

    def quote(self, url, limit, timeout, *, mode="latest", start=None, end=None):
        if not isinstance(url, str) or not url.strip() or len(url) > 4000 or mode not in ("latest", "all", "range") or type(limit) is not int or not 1 <= limit <= 1000:
            raise ClientError("INVALID_INPUT", "请提供 B站链接，选择最新若干条、全部或指定范围，单任务最多 1000 条。")
        value = {"url": url.strip()}
        if mode == "range":
            if type(start) is not int or type(end) is not int or not 1 <= start <= end <= 10000 or end - start + 1 > 1000:
                raise ClientError("INVALID_INPUT", "范围须为 1–10000 内的序号，单次最多 1000 条。")
            value.update(mode=mode, start=start, end=end)
        elif mode == "all":
            value["mode"] = "all"
        else:
            value["limit"] = limit
        ensure_output_dir(self.output_dir)
        # 同一次 HTTP 请求的自动重试沿用此键；调用失败后不在本地保存键或任务。
        task = self.api.quote(value, "client_" + uuid.uuid4().hex)
        task_id = task.get("task_id")
        self.api._task_id(task_id)
        self.current_task = task_id
        return self.wait(task_id, timeout, 5)

    def status(self, task_id):
        self.api._task_id(task_id)
        self.current_task = task_id
        task = self.api.task(task_id)
        if task.get("task_id") != task_id or task.get("skill_id") != "bilibili-to-markdown":
            raise ClientError("INVALID_RESPONSE", "任务响应与当前 Skill 不一致。")
        items = [] if task.get("status") in ("analyzing", "queued", "running") else self.api.items(task_id)
        return {"task_id": task_id, "output_dir": ensure_output_dir(self.output_dir),
                "task": task, "items": items[:50], "items_total": task.get("total_items", len(items)),
                "items_truncated": task.get("total_items", len(items)) > len(items[:50]),
                "requires_confirmation": task.get("status") == "quoted"}

    def tasks(self, url=None, page=1):
        source_url = None
        if url:
            inspected = self.api.inspect(url)
            source_url = inspected.get("source_url")
            if not isinstance(source_url, str) or not source_url:
                raise ClientError("INVALID_RESPONSE", "链接解析结果缺少来源地址。")
        matches, unknown, total = [], [], 0
        last_page = page
        for current_page in range(page, min(page + 20, 10001)):
            result = self.api.tasks(current_page)
            rows, total = result.get("items"), result.get("total")
            if not isinstance(rows, list) or type(total) is not int or total < 0:
                raise ClientError("INVALID_RESPONSE", "历史任务列表响应无效。")
            if any(not isinstance(row, dict) or row.get("skill_id") != "bilibili-to-markdown" for row in rows):
                raise ClientError("INVALID_RESPONSE", "历史任务列表包含无效数据。")
            matches.extend(row for row in rows if source_url is None or row.get("source_url") == source_url)
            unknown.extend(row for row in rows if source_url is not None and not row.get("source_url"))
            last_page = current_page
            if source_url is None or current_page * 50 >= total or not rows:
                break
        return {"source_url": source_url, "page": page, "searched_through_page": last_page,
                "total": total, "matches": matches, "unidentified": unknown, "has_more": last_page * 50 < total}

    def wait(self, task_id, timeout, interval):
        deadline = self.clock() + timeout
        while True:
            snapshot = self.status(task_id)
            status = snapshot["task"].get("status")
            if status == "quoted" or status in TERMINAL:
                return {**snapshot, "waiting": False}
            if self.clock() >= deadline:
                return {**snapshot, "waiting": True,
                        "next_action": "云端任务仍在进行；稍后用同一 task_id 调用 resume，不要重新报价或确认。"}
            if self.progress:
                self.progress({"task_id": task_id, "status": status,
                               "processed": snapshot["task"].get("processed_items", 0),
                               "total": snapshot["task"].get("total_items", 0)})
            self.sleep(min(interval, max(0, deadline - self.clock())))

    def confirm(self, task_id, quote_id, max_points, yes):
        if not yes or not re.fullmatch(r"[a-f0-9]{32}", quote_id or "") or type(max_points) is not int or max_points < 0:
            raise ClientError("CONFIRMATION_REQUIRED", "确认执行需要 --yes、已展示的 --quote-id 和 --max-points 积分上限。")
        snapshot = self.status(task_id)
        task = snapshot["task"]
        quote = task.get("quote") or {}
        points = quote.get("total_points")
        if quote.get("quote_id") != quote_id:
            raise ClientError("QUOTE_MISMATCH", "报价与已确认的报价编号不一致，请重新展示报价。")
        if type(points) is not int or points < 0 or points > max_points:
            raise ClientError("BUDGET_EXCEEDED", "报价超过积分上限，未执行确认。")
        if not task.get("billing") and (task.get("status") != "quoted" or not task.get("quote_valid")):
            raise ClientError("QUOTE_EXPIRED", "报价未就绪或已过期，请重新核对报价。")
        ensure_output_dir(self.output_dir)
        confirmed = self.api.confirm(task_id, quote_id)
        if confirmed.get("task_id") != task_id:
            raise ClientError("INVALID_RESPONSE", "确认响应中的任务编号不一致。")
        return {**snapshot, "task": confirmed, "requires_confirmation": False}

    def download(self, task_id, output_dir=None):
        snapshot = self.status(task_id)
        directory = ensure_output_dir(output_dir or self.output_dir)
        listing = self.api.files(task_id)
        files = listing.get("files")
        if listing.get("task_id") != task_id or not isinstance(files, list) or not 1 <= len(files) <= 1000:
            raise ClientError("INVALID_RESPONSE", "文件清单无效。")
        saved, errors = [], []
        for file in files:
            item_id = file.get("item_id") if isinstance(file, dict) else None
            if not item_id or file.get("status") != "ready":
                errors.append({"item_id": item_id, "code": "FILE_NOT_READY", "message": "文件尚不可下载或已过期。"})
                continue
            try:
                try:
                    record = self.downloader.save(file, directory)
                except ClientError as error:
                    if error.code != "DOWNLOAD_URL_EXPIRED":
                        raise
                    fresh = self.api.files(task_id)
                    if fresh.get("task_id") != task_id or not isinstance(fresh.get("files"), list):
                        raise ClientError("INVALID_RESPONSE", "刷新后的文件清单无效。")
                    file = next((f for f in fresh["files"] if isinstance(f, dict) and f.get("item_id") == item_id and f.get("status") == "ready"), None)
                    if not file:
                        raise ClientError("FILES_EXPIRED", "文件已不可下载。")
                    record = self.downloader.save(file, directory)
                saved.append(record)
            except ClientError as error:
                errors.append({"item_id": item_id, **error.as_dict()})
        return {"task_id": task_id, "output_dir": directory,
                "task_status": snapshot["task"].get("status"), "failed_items": snapshot["task"].get("failed_items", 0),
                "files": saved, "errors": errors, "download_complete": not errors and len(saved) == len(files)}

    def resume(self, task_id, timeout, interval):
        snapshot = self.wait(task_id, timeout, interval)
        if snapshot["task"].get("status") in ("succeeded", "partial_succeeded"):
            return {**snapshot, "download": self.download(task_id)}
        return snapshot
