import json
import os
import stat
from pathlib import Path
from .errors import ClientError


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    payload = (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0), 0o600)
        with os.fdopen(fd, "wb") as output:
            if not stat.S_ISREG(os.fstat(output.fileno()).st_mode):
                raise OSError("配置不是普通文件")
            if os.name == "posix":
                os.fchmod(output.fileno(), 0o600)
            output.write(payload)
            output.flush()
            os.fsync(output.fileno())
    except OSError:
        raise ClientError("LOCAL_IO_ERROR", "本地配置无法写入，请检查目录权限和磁盘空间。") from None


def read_json(path, *, max_bytes=1024 * 1024):
    try:
        if Path(path).stat().st_size > max_bytes:
            raise ValueError()
        value = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError()
        return value
    except (OSError, ValueError):
        raise ClientError("INVALID_LOCAL_FILE", "本地配置无法读取。") from None
