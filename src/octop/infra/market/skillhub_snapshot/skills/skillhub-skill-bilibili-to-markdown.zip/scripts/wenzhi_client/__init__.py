"""文知 Skill 客户端；仅依赖 Python 标准库。"""
