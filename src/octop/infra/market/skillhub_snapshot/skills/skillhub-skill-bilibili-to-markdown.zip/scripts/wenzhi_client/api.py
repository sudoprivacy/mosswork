import http.client
import json
import re
import time
import urllib.error
import urllib.request
from .config import API_BASE
from .errors import ClientError
TASK_ID = re.compile(r"t[0-9a-f]{32}\Z")

MESSAGES = {
    "UNAUTHORIZED": "API Key 无效、已过期或账号无访问资格。",
    "INSUFFICIENT_BALANCE": "积分余额不足，请充值后重试确认原任务。",
    "QUOTE_EXPIRED": "报价已过期；请重新报价并核对价格，不要自动确认新报价。",
    "QUOTE_MISMATCH": "报价已改变，请重新查看并核对报价。",
    "IDEMPOTENCY_CONFLICT": "同一幂等键不能更换输入，请重新报价。",
    "TASK_NOT_FOUND": "任务不存在或当前 API Key 无权访问。",
    "FILES_NOT_READY": "文件尚未交付或没有可下载文件。",
    "FILES_EXPIRED": "文件已过保留期，无法继续下载。",
    "INVALID_INPUT": "输入应为 B站视频链接、BV号、分享文本或用户主页链接。",
    "SKILL_NOT_FOUND": "Skill 不存在或暂未上架。",
    "RATE_LIMITED": "服务繁忙，请稍后恢复同一任务。",
}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def default_opener():
    return urllib.request.build_opener(NoRedirect())


class Api:
    def __init__(self, key, *, opener=None, sleep=time.sleep):
        self.key, self.opener, self.sleep = key, opener or default_opener(), sleep

    def request(self, path, body=None):
        if not path.startswith("/v1/") or "\r" in path or "\n" in path:
            raise ClientError("INVALID_REQUEST", "接口路径无效。")
        headers = {"Authorization": "Bearer " + self.key, "Accept": "application/json"}
        data = None
        if body is not None:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        for attempt in range(3):
            req = urllib.request.Request(API_BASE + path, data=data, headers=headers)
            retryable = False
            try:
                with self.opener.open(req, timeout=20) as response:
                    raw = response.read(2 * 1024 * 1024 + 1)
                if len(raw) > 2 * 1024 * 1024:
                    raise ValueError()
                value = json.loads(raw)
                if not isinstance(value, dict) or value.get("code") != "OK" or not isinstance(value.get("data"), dict):
                    raise ValueError()
                return value["data"]
            except urllib.error.HTTPError as error:
                retryable = error.code in (429, 500, 502, 503, 504)
                try:
                    payload = json.loads(error.read(65536))
                    code = payload.get("code", "API_ERROR")
                    if not isinstance(code, str) or not re.fullmatch(r"[A-Z0-9_]{1,80}", code):
                        code = "API_ERROR"
                except (ValueError, AttributeError):
                    code = "API_ERROR"
                finally:
                    error.close()
                failure = ClientError(code, MESSAGES.get(code, "请求未完成，请检查服务状态或恢复原任务。"), retryable=retryable, http_status=error.code)
            except (urllib.error.URLError, TimeoutError, OSError, http.client.HTTPException):
                retryable = True
                failure = ClientError("NETWORK_ERROR", "网络请求失败。若已获得任务编号，请查询原任务；报价请求失败可重新报价。", retryable=True)
            except (ValueError, UnicodeError):
                raise ClientError("INVALID_RESPONSE", "服务返回格式异常，请稍后查询原任务。") from None
            if not retryable or attempt == 2:
                raise failure from None
            # 报价与确认均依赖服务端幂等键/报价ID；重试不新建请求标识。
            self.sleep(attempt + 1)

    def wallet(self):
        return self.request("/v1/wallet")

    def inspect(self, url):
        return self.request("/v1/skills/bilibili-to-markdown/inspect", {"input": {"url": url}})

    def quote(self, value, key):
        return self.request("/v1/skills/bilibili-to-markdown/quote", {"input": value, "idempotency_key": key})

    def task(self, task_id):
        self._task_id(task_id)
        return self.request("/v1/tasks/" + task_id)

    def tasks(self, page=1):
        if type(page) is not int or not 1 <= page <= 10000:
            raise ClientError("INVALID_ARGUMENT", "任务页码须为 1–10000。")
        return self.request(f"/v1/tasks?skill_id=bilibili-to-markdown&page={page}&page_size=50")

    def items(self, task_id):
        self._task_id(task_id)
        values = []
        for page in range(1, 21):
            result = self.request(f"/v1/tasks/{task_id}/items?page={page}&page_size=50")
            rows, total = result.get("items"), result.get("total")
            if not isinstance(rows, list) or type(total) is not int or not 0 <= total <= 1000:
                raise ClientError("INVALID_RESPONSE", "视频清单响应无效。")
            values.extend(rows)
            if len(values) == total:
                return values
            if not rows or len(values) > total:
                break
        raise ClientError("INVALID_RESPONSE", "视频清单不完整。")

    def confirm(self, task_id, quote_id):
        self._task_id(task_id)
        return self.request(f"/v1/tasks/{task_id}/confirm", {"quote_id": quote_id})

    def files(self, task_id):
        self._task_id(task_id)
        return self.request(f"/v1/tasks/{task_id}/files")

    @staticmethod
    def _task_id(value):
        if not isinstance(value, str) or not TASK_ID.fullmatch(value):
            raise ClientError("INVALID_TASK_ID", "任务编号格式无效。")
