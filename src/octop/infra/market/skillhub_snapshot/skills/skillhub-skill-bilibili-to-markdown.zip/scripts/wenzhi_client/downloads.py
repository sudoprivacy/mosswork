import http.client
import codecs
import hashlib
import os
import re
import stat
import unicodedata
import urllib.error
from pathlib import Path
from urllib.parse import urlsplit
from .api import default_opener
from .errors import ClientError

MAX_MD = 16 * 1024 * 1024


def filename(value):
    if not isinstance(value, str) or not value.lower().endswith(".md"):
        raise ClientError("INVALID_FILE", "服务返回的文件名不是 Markdown。")
    name = unicodedata.normalize("NFC", value)
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f\x7f]', "_", name).strip(" .")
    stem = name[:-3].strip(" .") or "视频文案"
    if re.fullmatch(r"(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?", stem):
        stem = "_" + stem
    while len(stem.encode("utf-8")) > 170:
        stem = stem[:-1]
    return stem + ".md"


def download_url(value):
    if not isinstance(value, str) or len(value) > 16384:
        raise ClientError("INVALID_DOWNLOAD_URL", "下载地址无效。")
    try:
        u = urlsplit(value)
        port = u.port
    except ValueError:
        raise ClientError("INVALID_DOWNLOAD_URL", "下载地址无效。") from None
    host = u.hostname or ""
    allowed = re.fullmatch(r"[a-f0-9]{32}(?:\.(?:eu|us|fedramp))?\.r2\.cloudflarestorage\.com", host) or re.fullmatch(r"[a-z0-9][a-z0-9.-]*\.oss-[a-z0-9-]+\.aliyuncs\.com", host)
    if u.scheme != "https" or u.username or u.password or port not in (None, 443) or not allowed:
        raise ClientError("INVALID_DOWNLOAD_URL", "仅接受网关返回的 HTTPS R2/OSS 文件地址。")
    return value


def local_hash(path):
    try:
        if path.is_symlink():
            return None
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        with os.fdopen(fd, "rb") as source:
            if not stat.S_ISREG(os.fstat(source.fileno()).st_mode) or os.fstat(source.fileno()).st_size > MAX_MD:
                return None
            h = hashlib.sha256()
            while chunk := source.read(65536):
                h.update(chunk)
            return h.hexdigest()
    except OSError:
        return None


class Downloader:
    def __init__(self, opener=None):
        self.opener = opener or default_opener()

    def save(self, file, directory):
        size, item_id = file.get("size"), file.get("item_id")
        if type(size) is not int or not 0 < size <= MAX_MD or not isinstance(item_id, str) or not re.fullmatch(r"i[0-9a-f]{32}", item_id):
            raise ClientError("INVALID_FILE", "文件大小或文件编号无效。")
        name = filename(file.get("filename"))
        directory = Path(directory).expanduser().resolve()
        directory.mkdir(parents=True, exist_ok=True)
        url = download_url(file.get("url"))
        chunks = []
        try:
            # 下载和完整性校验先在内存中完成；单个 MD 上限 16 MB。
            with self.opener.open(url, timeout=30) as response:
                if response.status != 200:
                    raise ClientError("DOWNLOAD_FAILED", "文件下载响应异常。", retryable=True)
                content_type = response.headers.get("Content-Type", "").lower()
                if "html" in content_type or "json" in content_type:
                    raise ClientError("INVALID_FILE", "下载响应不是 Markdown 文件。")
                h, count = hashlib.sha256(), 0
                decoder = codecs.getincrementaldecoder("utf-8")("strict")
                while chunk := response.read(65536):
                    count += len(chunk)
                    if count > size:
                        raise ClientError("INVALID_FILE", "下载数据超过声明大小。")
                    decoder.decode(chunk)
                    if b"\x00" in chunk:
                        raise ClientError("INVALID_FILE", "下载内容包含异常二进制数据。")
                    chunks.append(chunk)
                    h.update(chunk)
                decoder.decode(b"", final=True)
            if count != size:
                raise ClientError("INCOMPLETE_DOWNLOAD", "文件未下载完整，请恢复同一任务。", retryable=True)
        except urllib.error.HTTPError as error:
            code = error.code
            error.close()
            raise ClientError("DOWNLOAD_URL_EXPIRED" if code == 403 else "DOWNLOAD_FAILED", "文件地址不可用，请重新获取下载链接。", retryable=True) from None
        except (urllib.error.URLError, OSError, TimeoutError, http.client.HTTPException):
            raise ClientError("DOWNLOAD_FAILED", "下载中断，请恢复同一任务。", retryable=True) from None
        except UnicodeError:
            raise ClientError("INVALID_FILE", "下载内容不是有效 UTF-8 文本。") from None
        digest = h.hexdigest()
        payload = b"".join(chunks)
        for attempt in range(100):
            suffix = "" if attempt == 0 else "-" + item_id[-8:] + ("" if attempt == 1 else "-" + str(attempt))
            target = directory / (Path(name).stem + suffix + ".md")
            if target.exists() or target.is_symlink():
                if local_hash(target) == digest:
                    return {"item_id": item_id, "filename": target.name, "path": str(target), "size": size, "sha256": digest, "reused": True}
                continue
            try:
                fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
                with os.fdopen(fd, "wb") as output:
                    output.write(payload)
                    output.flush()
                    os.fsync(output.fileno())
                if local_hash(target) != digest:
                    raise ClientError("OUTPUT_WRITE_FAILED", "本地文件校验失败，请检查磁盘后重试下载。")
                return {"item_id": item_id, "filename": target.name, "path": str(target), "size": size, "sha256": digest, "reused": False}
            except FileExistsError:
                continue
            except OSError:
                # 无删除权限时保留可能未写完的文件；它不会被记为成功，重试会校验哈希并另选文件名。
                raise ClientError("OUTPUT_WRITE_FAILED", "本地文件写入失败；请检查目录权限和磁盘空间。") from None
        raise ClientError("OUTPUT_CONFLICT", "同名文件过多，请选择新的输出目录。")
