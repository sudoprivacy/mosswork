class ClientError(Exception):
    def __init__(self, code, message, *, retryable=False, **details):
        super().__init__(message)
        self.code, self.message, self.retryable = code, message, retryable
        self.details = details

    def as_dict(self):
        return {"code": self.code, "message": self.message,
                "retryable": self.retryable, **self.details}
