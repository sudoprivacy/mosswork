import os
import re
from pathlib import Path
from .errors import ClientError
from .storage import write_json, read_json

API_BASE = "https://skillapi.wenzhilab.com/gateway"
DEFAULT_CONFIG = Path.home() / ".wenzhi" / "bilibili-to-markdown" / "config.json"


def _windows_downloads():
    # Windows Known Folder 可识别用户移动到其他磁盘或 OneDrive 的“下载”。
    try:
        import ctypes
        import uuid

        class Guid(ctypes.Structure):
            _fields_ = [("data1", ctypes.c_uint32), ("data2", ctypes.c_uint16),
                        ("data3", ctypes.c_uint16), ("data4", ctypes.c_ubyte * 8)]

        folder = Guid.from_buffer_copy(uuid.UUID("374de290-123f-4565-9164-39c4925e467b").bytes_le)
        raw = ctypes.c_void_p()
        shell = ctypes.windll.shell32
        shell.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(Guid), ctypes.c_uint32,
                                                ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
        shell.SHGetKnownFolderPath.restype = ctypes.c_long
        if shell.SHGetKnownFolderPath(ctypes.byref(folder), 0, None, ctypes.byref(raw)) != 0:
            return None
        try:
            return Path(ctypes.wstring_at(raw)) if raw.value else None
        finally:
            ctypes.windll.ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
            ctypes.windll.ole32.CoTaskMemFree(raw)
    except (AttributeError, OSError, ValueError):
        return None


def default_output_dir():
    downloads = _windows_downloads() if os.name == "nt" else Path.home() / "Downloads"
    return (downloads if downloads and downloads.is_dir() else Path.cwd()) / "wenzhi"


def ensure_output_dir(value):
    path = Path(value).expanduser().resolve()
    try:
        path.mkdir(parents=True, exist_ok=True)
        if not path.is_dir() or not os.access(path, os.W_OK | os.X_OK):
            raise OSError("目录不可写")
    except OSError:
        raise ClientError("OUTPUT_DIR_UNAVAILABLE", "保存目录无法创建或写入，请指定一个可写的本地目录。") from None
    return str(path)


def load_config(path=None, require_key=True):
    path = Path(path or DEFAULT_CONFIG).expanduser().resolve()
    value = read_json(path) if path.exists() else {}
    key = os.environ.get("WENZHI_API_KEY") or value.get("api_key", "")
    if key and (not isinstance(key, str) or not re.fullmatch(r"wz_(?:sk_)?[a-fA-F0-9]{64}", key)):
        raise ClientError("INVALID_API_KEY", "平台 API Key 格式不正确。")
    if require_key and not key:
        raise ClientError("API_KEY_REQUIRED", "请先运行 configure，或设置 WENZHI_API_KEY 环境变量。")
    output = os.environ.get("WENZHI_OUTPUT_DIR") or value.get("output_dir") or str(default_output_dir())
    if not isinstance(output, str) or not output.strip():
        raise ClientError("INVALID_OUTPUT_DIR", "请指定本地保存目录。")
    return {"api_key": key, "output_dir": str(Path(output).expanduser().resolve()), "config_path": path}


def save_config(path, key, output_dir):
    value = read_json(path) if Path(path).exists() else {}
    value.update(api_key=key, output_dir=str(Path(output_dir).expanduser().resolve()))
    write_json(path, value)
