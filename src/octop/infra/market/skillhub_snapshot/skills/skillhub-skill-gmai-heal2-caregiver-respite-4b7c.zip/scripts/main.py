# -*- coding: utf-8 -*-
"""照护者喘息计划（gmai-heal2-caregiver-respite-4b7c）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：喘息计划（压力自查/安排建议）；支持资源地图；求助提示
建议输入（专业字段）：机构类型；业务场景
"""
import json, os, re, sys, time

SLUG = "gmai-heal2-caregiver-respite-4b7c"
TITLE = "照护者喘息计划"
PRICE_FEN = 1490
CATEGORY = "情绪陪伴"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['机构类型', True, ['机构', '单位类型', '场所'], '机构类型决定适用的管理规范'], ['业务场景', True, ['场景', '业务流程', '服务内容'], '界定流程与质控范围'], ['人员配置', False, ['人员', '岗位配置', ' staffing'], '角色缺位是流程失效的常见原因']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'flow': [['记录', '按统一模板记录情绪事件、触发情境与身体反应'], ['陪伴练习', '按自助练习（呼吸放松、认知重构、书写表达）引导练习并记录反应'], ['观察回看', '按周回看情绪曲线与练习完成情况，标注异常波动'], ['转介提示', '出现自伤自杀等危机信号或持续加重时，提示联系心理援助热线12356或精神科就诊'], ['复盘归档', '按周期复盘并归档记录，供专业人员参考']], 'kpis': [['记录连续性', '≥90%', '有记录天数 ÷ 统计天数', '记录台账'], ['危机信号识别率', '100%', '已标注危机信号条数 ÷ 应标注条数', '记录复核'], ['转介提示触达率', '100%', '触达转介提示次数 ÷ 危机信号次数', '陪伴记录'], ['练习完成率', '≥70%', '完成练习次数 ÷ 计划练习次数', '练习打卡'], ['自助边界声明率', '100%', '含边界声明输出次数 ÷ 输出总次数', '输出抽检']]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['《中华人民共和国精神卫生法》非医疗机构不得从事精神障碍诊断治疗的边界', '全国统一心理援助热线12356危机转介路径', '认知行为疗法（CBT）认知重构与行为激活的自助练习框架', 'Worden哀悼四任务模型（接受丧失、经历悲伤、适应环境、重建生活）', '渐进式肌肉放松与腹式呼吸训练要点', '企业EAP（员工帮助计划）服务边界与保密原则']
# 自检项（输入完备度）
CHECKS = [['照护者喘息计划·自助边界声明', ['照护者喘息计划'], '先声明非诊疗定位与《精神卫生法》边界，不评估不判定'], ['照护者喘息计划·记录与情境梳理', ['照护者喘息计划'], '按模板梳理情绪事件、触发情境与身体反应'], ['照护者喘息计划·练习方案设计', ['照护者喘息计划'], '按CBT自助框架设计练习并标注完成口径'], ['照护者喘息计划·危机转介核查', ['照护者喘息计划'], '出现自伤自杀等危机信号即提示12356热线或就诊，不做风险评级'], ['照护者喘息计划·计划与追踪交付', ['照护者喘息计划'], '输出练习计划、观察指标与周度回看模板']]
# 交付物构成
DELIVERABLES = ['喘息计划（压力自查/安排建议）', '支持资源地图', '求助提示']
FOOTER = "本报告为情绪自助与陪伴参考，不构成诊疗建议；危机信号请立即联系12356或就医。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """医疗健康运营交付物：流程与角色 → 质控指标 → 合规边界 → 记录模板 → 改进措施"""
    P = ctx["spec"]["params"]; L = []
    org = ctx["fv"]("机构类型")
    scene = ctx["fv"]("业务场景") or ctx["spec"]["title"]
    kpis = P.get("kpis") or []      # [[指标, 目标值, 计算方式, 数据来源], ...]
    staff = ctx["fv"]("人员配置")
    flow = P.get("flow") or []

    L.append(("一、流程与角色", [
        "- 机构类型：%s" % (brief(org, 40) or "（未提供，机构类型决定适用的管理规范）"),
        "- 业务场景：%s" % (brief(scene, 50)),
        "- 人员配置：%s" % (brief(staff, 50) or "（未提供，角色缺位是流程失效的常见原因）"),
        "",
        "| 环节 | 执行角色 | 关键动作 | 留痕 |", "|---|---|---|---|",
    ] + (["| %d. %s | 待明确 | %s | 记录表单/系统留痕 |" % (i, f[0], f[1]) for i, f in enumerate(flow, 1)]
         if flow else ["| 1. 待补充环节 | 待明确 | 需按实际业务梳理 | — |"])))

    rows = ["| 指标 | 目标值 | 计算方式 | 数据来源 | 监测频次 |", "|---|---|---|---|---|"]
    for k in kpis:
        rows.append("| %s | %s | %s | %s | 月度 |" % (k[0], k[1], k[2], k[3]))
    if not kpis:
        rows.append("| 待补充指标 | — | — | — | — |")
    L.append(("二、质控与管理指标", rows))

    L.append(("三、合规边界", [
        "- 本技能输出为运营管理参考，**不构成医疗诊断、治疗建议或疗效评价**；涉及诊疗的判断由具备资质的医务人员作出。",
        "- 涉及患者信息处理的环节，须遵循个人信息保护与医疗数据管理的相关规定，做到最小必要、限定用途、可追溯。",
        "- 涉及药品、器械、诊疗科目与广告宣传的，须遵守相应监管要求；不得发布未经审批的医疗宣传内容。",
        "- 涉及不良事件或医疗质量安全事件的，按机构制度与监管要求上报，不得瞒报或延迟报告。",
    ]))

    L.append(("四、记录模板", [
        "| 记录 | 必填要素 | 保存要求 |", "|---|---|---|",
        "| 业务登记记录 | 时间、对象标识、事项、执行人、结果 | 按规定期限保存，可追溯 |",
        "| 质量检查记录 | 检查项、标准、结果、整改要求、复核人 | 留存备查 |",
        "| 异常/不良事件记录 | 发生经过、影响、处置、上报状态 | 按规定上报并留档 |",
        "| 培训与考核记录 | 内容、对象、时间、结果 | 留存备查 |",
        "",
        "记录设计原则：**谁执行谁记录、当班当次记录、修改留痕**。",
    ]))

    L.append(("五、改进措施", [
        "| 方向 | 措施 | 验证方式 |", "|---|---|---|",
        "| 流程标准化 | 把高频操作固化为标准流程与检查表 | 执行一致率抽样 |",
        "| 指标可视化 | 关键指标按月出图，异常自动提示 | 指标台账月度趋势 |",
        "| 角色补位 | 明确每个环节的执行与复核角色 | 岗位职责与实际相符 |",
        "| 培训闭环 | 培训—考核—上岗—复训形成闭环 | 考核记录 |",
        "| 反馈机制 | 建立对象反馈渠道并定期复盘 | 反馈处理率 |",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
