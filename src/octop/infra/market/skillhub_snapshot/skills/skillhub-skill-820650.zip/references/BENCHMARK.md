# SkillHub 同类技能调研与 v3.3.0 优化说明

调研日期：2026-11-10　|　调研对象：SkillHub 上「新闻收集 / 整理 / 日报」类技能　|　适用版本：Daily News for Yu v3.3.0

> 本文只记录**可核实**的内容。所有技能包均通过官方下载端点
> `https://api.skillhub.cn/api/v1/download?slug=<URL编码后的 @作者/技能名>` 取得（均返回 HTTP 200 / `application/zip`），
> 解压后逐文件阅读源码；**网页详情页只展示摘要，不作为设置依据**。
> 所有数值、参数名、函数名、行号均来自包内原文；未读到的内容一律标「未检出 / 待补查」，不推测。

---

## 一、检索覆盖与包清单

两轮检索：

1. `site:skillhub.cn 新闻 日报 采集 整理 skill` → 5 条结果，其中 4 个是可下载技能。
2. `site:skillhub.cn (新闻联播 OR 热搜 OR 逐字稿 OR 早报 OR 资讯聚合) skill` → 5 条结果，其中 4 个是可下载技能、1 个是第三方博客介绍（不作为一手来源）。

共取得并解压 **8 个技能包**：

| # | 技能坐标 | 详情页 URL | 包内文件数 | 定位 |
| --- | --- | --- | ---: | --- |
| 1 | `@user_15292d5a/yjkj-news-digest` | https://www.skillhub.cn/skills/user_15292d5a/yjkj-news-digest | 19 | 中文产业新闻采集与日摘要，SQLite 流水线 |
| 2 | `@user_d8796fc4/ch-news-reporter` | https://skillhub.cn/skills/user_d8796fc4/ch-news-reporter | 45 | 统一新闻表 + evidence packet + report profile |
| 3 | `@user_bda4df7b/openclaw-news-homepage-fetcher` | https://skillhub.cn/skills/user_bda4df7b/openclaw-news-homepage-fetcher | 5 | 首页优先抓取、翻译、Word-ready 日报 |
| 4 | `@user_f9ec4da5/auto-daily-report` | https://www.skillhub.cn/skills/user_f9ec4da5/auto-daily-report | 12 | 六维打分体系、编辑红线、自动化推送 |
| 5 | `@user_ae76a857/ai-news-known` | https://www.skillhub.cn/skills/user_ae76a857/ai-news-known | 8（含 node_modules） | 8 大中文热榜 + 本地记忆去重 |
| 6 | `@user_d93c4aed/news-aggregator-skill-v2` | https://www.skillhub.cn/skills/user_d93c4aed/news-aggregator-skill-v2 | 48 | 28 源聚合、统一模板、犯错笔记 |
| 7 | `@user_a86bc281/news-broadcast-daily` | 由第三方博客给出坐标，包已下载核验 | 3 | 《新闻联播》主要内容 + 网友热评 |
| 8 | `@user_d0c0f066/75215896` | https://skillhub.cn/skills/user_d0c0f066/75215896 | 3 | 六平台热搜 + A 股早盘分析 |

---

## 二、逐包关键设置（原文核实）

### 1. yjkj-news-digest

| 项目 | 原文位置 | 关键设置 |
| --- | --- | --- |
| 跨天去重 | `config.py:161-164` | `CROSS_DAY_DEDUP_ENABLED = True`、`CROSS_DAY_HISTORY_DAYS = 3`、`CROSS_DAY_THRESHOLD = 0.75`、`CROSS_DAY_WARN_THRESHOLD = 0.60` |
| 去重算法 | `cross_day_dedup.py:8-15, 56-128` | `0.5×标题Jaccard + 0.25×数字匹配 + 0.25×内容词重叠`；三条硬规则：标题全等→1.0、候选标题嵌入历史摘要→1.0、**双方都有显著数字但不共享→0.0**（放行周期性数据新闻） |
| 过滤执行 | `cross_day_dedup.py:167-226` | ≥0.75 拦截；0.60–0.75 警告但保留；<0.60 通过 |
| 同日去重 | `similarity.py` / `config.py:96` | 字符 2-gram Jaccard，`SIMILARITY_THRESHOLD = 0.90` |
| 输出上限 | `config.py:95` | `MAX_OUTPUT_COUNT = 50` |
| 智能选段 | `fetcher.py:61-205` | 位置加分（首段 +10）、数字 +2.5/个、信号词 +3、导语/背景降权、完整句截断 |
| 编码与超时 | `fetcher.py:277-328`、`config.py:114-121` | 36kr 15s、cinn/cnii 30s、gov.cn 专用 UA + SSL 回退；统一浏览器请求头 |
| 乱码检测 | `rules_config.py:444-461` | 西里尔字母命中，或非 CJK/ASCII 字符占比 > 0.5 |
| 电头/噪声清理 | `rules_config.py:223-313, 356-395` | 40+ 条电头正则、无信息增量公告排除、句末智能截断 |

### 2. ch-news-reporter

| 项目 | 原文位置 | 关键设置 |
| --- | --- | --- |
| 截断检测 | `prepare_report_data.py:713-724` | `tail = content.rstrip()[-3:]; return tail.endswith("…") or tail.endswith("...")` —— 只认**结尾**省略号 |
| 补全候选 | `prepare_report_data.py:727-783` | `build_enrichment_candidates()`，截断项生成 `article_url` 目标并标 `truncated=True`、`reason = "RSS content truncated — fetch full article from source URL"` |
| 覆盖度 | `prepare_report_data.py:786-812` | `build_coverage()` 输出 `expected_sources` / `by_source` / `missing` / `all_present` |
| 覆盖结论 | `prepare_report_data.py:1009-1012` | `coverage["feed_failures"]`、`coverage["degraded"] = bool(feed_failures)`、`coverage["complete"] = all_present and not feed_failures` |
| 源感知配额 | `prepare_report_data.py:416-490`、`tests/test_ai_daily_value_gates.py:20-61` | `preferred_limits` + `hard_max_share = 0.4`；测试断言 5 个源各至少 1 条、单源不超过 4 条（10 条上限） |
| 价值闸门 | `tests/test_ai_daily_value_gates.py:90-214` | `grading_audit` 必填、`candidate_budget = 2` 为硬上限、`s_confirmed` 需官方 + 独立两类证据且 `confirmation_blockers` 为空 |
| 信源台账 | `config/sources.yaml:1-21` | 逐源标注「有官方 RSS / 需 enrich / 已核实但抓不到」及具体原因（如 `rss.xml 上游持续返回 HTTP 500`） |

### 3. auto-daily-report

| 项目 | 原文位置 | 关键设置 |
| --- | --- | --- |
| 三层过滤 | `references/scoring-system.md:9-25` | Layer 1 门槛 → Layer 2 打分 → Layer 3 编辑决策 |
| 六维打分 | `scoring-system.md:64-76, 141-147` | 格局影响力 30% / 信息独特性 20% / 数据硬度 20% / 时效敏感性 15% / 受众相关性 10% / 交叉验证度 5%；`总分 = (Σ 维度×权重) × 5` |
| 门槛硬条件 | `scoring-system.md:31-46` | 领域相关、时效性、信源可追溯、非广告、有实质内容 |
| 板块分配 | `scoring-system.md:159-179` | ≥80 头条（最多 3）、60–79 速递、40–59 无硬数字不收录、<40 不收录；另有冷启动保护、反垄断（同一主体只留 2 条） |
| 质量红线 | `references/editorial-rules-template.md:92-110` | 红线 1「每条信息必须附原始来源链接」、红线 2 关键数据交叉验证、红线 3「不编造不存在的信息」、红线 5「没有新闻也是新闻，不硬凑头条」 |
| 不发清单 | `editorial-rules-template.md:51-72` | 纯转述无增量、同事件第 N 次跟进、标题党、超时效旧闻等 10 类 |
| 调研方法 | `references/research-methodology.md:114-128, 223` | 信源分层清单 L1–L5、交叉验证做法 |

### 4. openclaw-news-homepage-fetcher

| 项目 | 原文位置 | 关键设置 |
| --- | --- | --- |
| 不适用场景 | `SKILL.md:19-26` | 单篇摘要、社媒/论坛、绕过付费墙、实时高频监控均不适用 |
| 先读参考 | `SKILL.md:28-37` | 每次选源先读 `source_catalog.md`；程序化配置读 `source_manifest.yaml` |
| 首页优先 | `SKILL.md:53-81` | Hero 主卡片 → Latest/Top Stories 列表 → 栏目页前两屏；明确跳过 Opinion / Live / Video / Newsletter / Tag 页 |
| 完整性判断 | `SKILL.md:73-81` | 标题明确、来源可识别、数个实质段落、时间可见、非纯视频图库 |
| 输出字段 | `SKILL.md:93-111` | `source_name` / `source_region` / `section` / `article_url` / `title_original` / `published_at` / `author` / `summary_zh` / `body_zh` / `extraction_note` 等 12 字段 |
| 异常标记 | `SKILL.md:51, 113-128` | 付费墙记「受限页面」，链接失效写失败说明，**不要伪造内容** |
| 机器可读源清单 | `references/source_manifest.yaml:1-20` | `selection_policy.default_mode: homepage_first`、`exclude_by_default` 列表、逐源 `id/name/region/language/homepage/sections` |

### 5. ai-news-known

| 项目 | 原文位置 | 关键设置 |
| --- | --- | --- |
| 本地记忆 | `SKILL.md:81-103` | `data/history.json` 记录 `hash` / `title` / `source` / `timestamp` |
| 文档宣称阈值 | `SKILL.md:83-86` | 「完全匹配：跳过」「相似度 > 70%：跳过」 |
| **实际实现** | `scripts/fetch_ai_news.py:436-475` | `compute_title_hash()` 用 SHA-256 前 16 位；`_compute_similarity_hash()` 去标点后取中文字符 + 排序英文词再哈希（前 12 位）；`is_duplicate()` 只做 `exact_match` / `similar_match` **两次精确比对，代码中不存在 70% 阈值** |
| 记忆清理 | `fetch_ai_news.py:39-41, 493-507` | `MAX_HISTORY_RECORDS = 500`、`MAX_HISTORY_DAYS = 30` |

> 这是本次调研发现的一处**文档与实现不一致**。v3.3.0 不引用其「70%」说法，只借鉴「用本地历史做跨天比对」这一思路，阈值改取 yjkj-news-digest 中**代码里真实存在的** 0.75 / 0.60。

### 6. news-aggregator-skill-v2

| 项目 | 原文位置 | 关键设置 |
| --- | --- | --- |
| 严格规则 | `SKILL.md:131-138` | 时间字段必填，缺失标 `Unknown Time`；**Anti-Hallucination：只用 JSON 里的数据、不发明新闻、不虚构因果**；Smart Fill（不足 5 条时从更宽时间窗补数） |
| 绝对时间教训 | `MISTAKES.md:3-24` | 把 Unix 时间戳格式化成 `HH:MM` 丢掉日期，导致「12 小时前」被报告成「1 小时前」；结论「数据层必须保留完整日期时间」 |
| 空数据风险 | `MISTAKES.md:28-56` | 「Empty Data is the mother of Hallucination」；硬过滤必须配软回退 |
| 陈旧缓存教训 | `MISTAKES.md:78-93` | 曾把一个月前的 `wallstreetcn_raw.json` 当成当日数据；预防：优先当前执行 stdout、读缓存前核对时间戳、严格遵守规定路径 |

### 7. news-broadcast-daily

| 项目 | 原文位置 | 关键设置 |
| --- | --- | --- |
| 源优先级 | `SKILL.md:16-33` | 央视网「今日新闻联播速览」→ 财联社「要闻 N 条」→ 央视网当日节目页 → 主流媒体转载 |
| 不编造 | `SKILL.md:32-33` | 当日未播出或文字稿不可获取时「在输出文件中如实说明，不编造内容」 |
| 热评 | `SKILL.md:35-61` | 并行搜索 3–4 条、按新闻类型预判是否值得搜、每条热评 ≤200 字 |

### 8. 每日热点信息分析报告（75215896）

| 项目 | 原文位置 | 关键设置 |
| --- | --- | --- |
| 失败隔离 | `SKILL.md:30-32` | 「If any platform fails, mark it as `[获取失败]` and continue.」 |
| 无热度值兜底 | `SKILL.md:41-43` | B 站按名次反向加权 `score = 75 - (rank - 1) * 4` |
| 交易日回退 | `SKILL.md:23-25, 49` | 先试昨日、最多回溯 7 天，并在报告标注「数据截至{YYYYMMDD}收盘」 |

---

## 三、逐项对比：采纳 / 不采纳

### 3.1 采纳并落地（8 项）

| # | 借鉴点 | 来源（文件:行 / 函数） | 本技能 v3.2.0 状态 | v3.3.0 变更 | 依据 |
| --- | --- | --- | --- | --- | --- |
| O1 | 结尾截断检测 | `ch-news-reporter/prepare_report_data.py:713-724` | 无 | `quality_gates.is_content_truncated()`，只标记不删改 | 只认结尾省略号，避免把原文中正常出现的「…」误判 |
| O2 | 乱码标题检测 | `yjkj-news-digest/rules_config.py:444-461` | 无 | `quality_gates.has_garbled_text()` | 编码错乱会直接破坏「逐字」承诺，须可检出 |
| O3 | Coverage 一等公民 | `ch-news-reporter/prepare_report_data.py:786-812, 1009-1012` | 只有分散的 `data_gaps` / 各源 `status` | `quality_gates.build_coverage()` → `summary.coverage`：`expected_sources` / `by_source` / `missing` / `feed_failures` / `degraded` / `complete` | 把「哪一路没到」从文字描述升级为结构化、可断言的判定 |
| O4 | 逐字自校验 + 证据包 | `auto-daily-report/editorial-rules-template.md:100-104` 红线 1/3；`ch-news-reporter` evidence packet + `grading_audit` 校验 | 依赖外部 `probe/verify5.py` 读快照目录复核 | `quality_gates.build_evidence()` 用**本次 bundles** 直接校验每个要点，`integrity` 记录 exact / normalized 命中数与未命中清单；每条挂 `evidence`（源内条号、具体页面 URL、`content_sha256`、要点哈希） | 自校验不依赖外部目录，换电脑后仍成立；来源链接与内容指纹可回溯 |
| O5 | 快照时间戳 + 硬上限 | `news-aggregator-skill-v2/MISTAKES.md:78-93` | `--allow-stale` 直接取目录中排序最靠前的快照，不核年龄 | `load_stale()` 解析文件名时间戳，计算 `age_hours`，写入 `bundle.snapshot`，超过 `--stale-max-age-hours`（默认 48）即拒用 | 防止多日前的快照被当作本轮结果；与「不编造、如实标注」一致 |
| O6 | 按站点差异化超时 + 发现证据 | `yjkj-news-digest/fetcher.py:277-328`；`openclaw/SKILL.md:51, 113-128` | 单值 `--timeout=20`；发现逻辑失败只写一句文字 | `HOST_TIMEOUTS` 取 `max(--timeout, 站点下限)`（36氪 15 / 东财 30 / 百度 20）；`bundle.discovery` 记录发现 URL、HTTP 状态、字节数、标记命中数、实际超时、是否使用回退 | 用数据而非猜测定位源站变化；不缩短用户显式指定的超时 |
| O7 | 跨天去重 | `yjkj-news-digest/cross_day_dedup.py:56-128`、`config.py:161-164`；`ai-news-known` 本地历史思路 | 完全没有跨天维度，同一事件隔天重复出现 | 新增 `scripts/cross_day.py`，历史取自本技能自己产出的 `entries-*.json`（零数据库）；3 天窗口 / 0.75 拦截 / 0.60 警告保留 / 数字差异化硬放行；**默认关闭**，`--cross-day-dedup` 才启用 | 本技能默认「不遗漏任何独立新闻点」，去重会删条目，故设为显式可选并在 `cross_day_audit` 全量留痕 |
| O8 | 源站署名行排除 | `yjkj-news-digest/rules_config.py:223-313`（电头/记者/编辑署名正则）、`fetcher.py::is_boilerplate`；`auto-daily-report/editorial-rules-template.md:51-72` 不发清单 | 2026-11-10 实跑发现 36氪第 47 条「整理丨几何鱼」（无正文的编辑署名）被当作一条新闻进入 HTML | `editorial.collect_items()` 在「标题严格匹配署名模式且无正文」时排除，记入 `merge_audit.excluded_index_items`；`quality` 中同步标 `boilerplate_bylines` | 署名行不是独立新闻点，展示它会形成假条目；限定「无正文」才排除，避免误杀含这些词的新闻标题 |

> 说明：O1–O6 为常开且不改变条目集合的「诊断型优化」；O7 是唯一会改变条目数的「功能型优化」，因此默认关闭。全部优化均**不新增 HTML 版面、不新增每条新闻的展示字段**。

### 3.2 明确不采纳（含反例与拒绝理由）

| 借鉴点 | 来源 | 拒绝理由 |
| --- | --- | --- |
| LLM 摘要 / 改写 / 翻译、120–220 字中文摘要 | `yjkj-news-digest/stage2_5_llm_summary.py`、`openclaw/SKILL.md:83-91` | 违反「正文逐字保留、不改写、不转述、不以摘要替代原文」硬约束 |
| 六维打分体系替换现有公式、打分表外显 | `auto-daily-report/scoring-system.md:141-147, 197-211` | 用户已明确「取消分类」「每条只保留三项元数据」「删除评分算式」；改公式或外显打分表会破坏既定输出规则 |
| 头条 / 速递板块分配、<40 分不收录、反垄断只留 2 条 | `scoring-system.md:159-179` | 本技能要求「不遗漏独立新闻点」并显示全部整合条目，截断会丢事实 |
| 源感知配额 `hard_max_share=0.4` | `ch-news-reporter/tests/test_ai_daily_value_gates.py:20-61` | 同上；该机制适用于「限量报告」，本技能是「全量日报」 |
| 关键词黑白名单过滤、领域相关性门槛 | `yjkj-news-digest/rules_config.py:11-167`、`auto-daily-report/scoring-system.md:31-46` | 本技能按源站全量采集，不做主题筛选；过滤词表主观且会误杀（该包自己就记录了「相亲」「艺人」等词误杀并被迫改长词） |
| Smart Fill（不足 5 条从更宽时间窗补数） | `news-aggregator-skill-v2/SKILL.md:137` | 直接违反「不编造、不补全」与「状态异常时 items 为空」 |
| 「没有新闻也是新闻」式判断声明、热评、小红书文案 | `editorial-rules-template.md:106`、`news-broadcast-daily/SKILL.md:35-61`、`ai-news-known/SKILL.md:186-207` | 引入源站之外的内容与版面，超出本技能产出范围 |
| SQLite 数据库 / 500 条记忆表 | `yjkj-news-digest/database.py`、`ai-news-known/fetch_ai_news.py:39-41` | 破坏零第三方依赖与跨电脑免初始化；本技能用自带 `entries-*.json` 作历史即可 |
| 邮件推送、cron 自动创建、ECharts 图表、锚点目录 | `auto-daily-report/references/email-template.md`、`editorial-rules-template.md:110` | 用户明确限定单篇两部分 HTML；且本技能不主动创建定时任务 |
| **首页优先发现回退** | `openclaw/SKILL.md:53-81`、`source_manifest.yaml` | **实地核验不成立**：2026-11-10 探测 36氪首页 HTTP 200 / 25,361 B / `8点1氪` 0 命中 / `/p/` 0 命中（SPA 壳）；东财首页 118,023 B、要闻页 344,283 B 均 0 处「早餐」；东财站内搜索页 13,592 B / 0 个文章 ID（JS 渲染）。无可用回退入口，标为「待补查」，不写成能力 |
| ai-news-known 文档宣称的「相似度 > 70%」 | `ai-news-known/SKILL.md:83-86` | 实现里没有该阈值（`fetch_ai_news.py:460-475` 只做两次哈希精确比对）；引用未经实现支撑的数值会形成虚假依据 |
| 每条附解读 / So What / 冲突比共识更有价值 | `editorial-rules-template.md:19-28` | 属于编辑观点，本技能要点必须是源站逐字原文句 |

---

## 四、优化前后对照（行为层面）

| 行为 | v3.2.0 | v3.3.0 |
| --- | --- | --- |
| HTML 结构 | 两部分 | **不变，仍为两部分** |
| 每条新闻展示字段 | 排序号 + 来源 + 源内第几条 + 得分 + 要点 | **不变** |
| 结尾截断 / 乱码标题 | 不可检出 | 写入 `quality.flags` 与 `data_gaps`，只标记不删改 |
| 覆盖度 | 需人工读各源 `status` | `coverage.complete` / `missing` / `feed_failures` 可断言 |
| 逐字校验 | 需外部脚本读快照目录 | 内置 `integrity.all_verbatim`，直接用本次 bundles |
| 陈旧快照 | 不核年龄，可能用很旧的快照 | 先算 `age_hours`，>48h 拒用；`snapshot.timestamp_verified=True` |
| 超时 | 全站统一 20s | `max(20, 站点下限)`，东财 30s |
| 发现失败 | 只有一句状态文字 | `discovery` 留存 HTTP 状态、字节数、标记命中数 |
| 跨天重复 | 无法识别 | `--cross-day-dedup` 可选启用，审计可复核 |

---

## 五、实跑验证与修正记录（2026-11-10）

| 验证项 | 结果 |
| --- | --- |
| 5 + 2 个脚本编译 | `PY_COMPILE_OK` |
| 主流程实跑 | `EXIT=0`；四路：联播 OK 12 / 36氪 OK 47 / 东财 `STALE_SNAPSHOT` 34（28.1 小时前）/ 百度 OK 50 |
| 最终条目 | 141 条整合条目；得分 18.70–66.80 严格非升序 |
| HTML 版面 | 仍为「一、源站 / 二、新闻」两部分，141 个条目卡片，四条 URL 全部 `concrete=True` |
| 逐字性 | 内置 `integrity` 368/368 精确命中；独立验收脚本**回源联播当期页**（56,816 B）+ 快照池复核 369/369 命中，0 处虚构 |
| 独立验收 `probe/verify6.py` | `ALL_PASS` |
| 专项验收 `probe/verify6_gates.py` | `ALL_PASS`：跨天硬规则 4 项、合并逻辑回归、快照年龄上限、跨天去重全链路 |

验证中发现并修正的 4 个真实问题（均为本次新增代码或既有数据缺陷，已全部复验）：

1. `time_integrity()` 只认 ISO 格式，把 36氪合法的 `2026-11-10 08:01:00  +0800` 误报 `MALFORMED`。已扩展为 ISO / RFC 2822 / 中文日期多格式解析，并单测 9 组样例。
2. `coverage.complete=true` 与顶层 `status=DEGRADED` 自相矛盾：`STALE_SNAPSHOT` 原未计入降级。已把陈旧源纳入 `stale_sources`、`degraded` 与 `complete` 判据。
3. 旧版（v3.2.0）快照没有 `discovery` 字段，导致该路诊断为空。已如实标 `NOT_RECORDED_IN_OLD_SNAPSHOT`，不反推 HTTP 状态与字节数。
4. 36氪第 47 条「整理丨几何鱼」是无正文的编辑署名，被当作新闻条目。已在整合层按「无正文 + 标题严格匹配署名模式」排除，并写入 `merge_audit.excluded_index_items`。

另有一处**测试脚本缺陷**（非产品缺陷）：跨天去重专项测试先清空输出目录，把刚构造的历史文件一并删除，导致 `history_items=0`；调整构造顺序后通过（拦截 5 条、141→136、排序号重排连续、审计明细齐全）。

**为什么本次合并数为 0**：`editorial.py` 未改动，本次实际数据经全对诊断 `related() > 0` 的条目对为 0，属数据特征，不是合并失效。已用合成数据回归验证两条例相近新闻仍会合并（原始 2 → 整合 1）。

---

## 六、未覆盖 / 数据缺口

1. **东方财富早餐稳定发现入口仍待补查**：要闻页会随列表滚动更新挤出早餐链接（2026-11-09 17:29 已实测）。本版只保留探测证据与 `--allow-stale`，未找到经核验可用的回退入口，不臆造。
2. 36氪 RSS 与文章页可能因缓存/源站修订出现微小动态差异，已有 `--verify-kr` 量化记录，不做合并补全。
3. 百度榜单、东财 `div#ContentBody`、联播主源页面结构均可能改版，已有 `PARSE_ERROR` 处置流程，需长期监测。
4. `cross_day` 的历史依赖 `output/daily/entries-*.json`；若用户清空输出目录，历史窗口归零，脚本如实返回 `NO_HISTORY`，不会编造历史。
5. 本次调研覆盖的是两轮检索命中的 8 个技能包；SkillHub 全站是否存在其他更相关技能，未做穷尽枚举，不作「已覆盖全部同类」的结论。
6. 图标、SkillHub 实际上传与账号凭据属上一轮任务，不在本次范围；上传仍受实名认证 / API Token / CLI 缺失阻塞。
