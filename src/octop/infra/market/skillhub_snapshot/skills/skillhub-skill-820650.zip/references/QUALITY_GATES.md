# v3.3.0 质量闸与诊断字段规格

适用：`scripts/quality_gates.py`（确定性实现）、`scripts/cross_day.py`（可选）、`scripts/collect_sources.py`、`scripts/news_daily.py`、`scripts/build_daily.py`
核验日期：2026-11-10　|　版本：3.3.0

本文件只规定**机器可读层**的行为。HTML 仍严格为「一、源站 / 二、新闻（按重要性排序）」两部分，每条新闻仍只呈现排序号、来源、源内第几条、得分与整合要点。

---

## 一、总原则

1. **只标记、不删改**：质量闸不删除任何条目、不改写任何逐字原文、不补写任何内容。异常进入 JSON 的 `quality.flags` 与 `data_gaps`。
2. **不因为诊断而降级源状态**：`status` 仍只由采集层的完整性校验决定；质量闸不把 `OK` 改成 `INCOMPLETE`。
3. **零第三方依赖**：全部用 Python 标准库实现；不引入数据库、不引入新的运行时文件。
4. **不进 HTML**：`coverage` / `quality` / `integrity` / `cross_day` / `collector` 全部只写入 `news-daily-*.json` 与 `entries-*.json`。

---

## 二、逐源质量闸 `quality_gates.inspect_bundle(bundle)`

写入 `bundle["quality"]`，字段：

| 字段 | 含义 | 判据来源 |
| --- | --- | --- |
| `truncated_items` | 正文或标题**结尾**为 `…` / `...` 的条目 | `ch-news-reporter/prepare_report_data.py:713-724` |
| `garbled_titles` | 西里尔字母命中，或非 CJK/ASCII 字符占比 > 0.5 | `yjkj-news-digest/rules_config.py:444-461` |
| `empty_body_orders` | 无正文的条号 | 本技能自定；`baidu_hot` 按源站口径本就可能无正文，标 `body_optional_by_source=true` 且不计为缺陷 |
| `boilerplate_bylines` | 无正文且标题为源站署名行（如「整理丨几何鱼」） | `yjkj-news-digest/rules_config.py:223-313`、`fetcher.py::is_boilerplate`；由 `editorial.collect_items()` 排除，不是独立新闻点 |
| `time_fields` | `retrieved_at` 与实际存在的期号/更新字段（`published_at` / `broadcast_date` / `source_update_time`）的时间完整性 | `news-aggregator-skill-v2/MISTAKES.md:3-24` |
| `snapshot` | 快照文件名、采集时刻、年龄小时数、上限、时间戳已核 | `MISTAKES.md:78-93` |
| `discovery` | 发现入口 URL、HTTP 状态、字节数、标记命中数、实际超时、回退状态 | `openclaw/SKILL.md:51, 113-128` |
| `content_sha256` | 采集层已有内容指纹，直接引用 | 本技能 v2.0 起 |
| `flags` | 机器可读异常码 | 见下表 |

| flag | 触发 |
| --- | --- |
| `TRUNCATED_TAIL_DETECTED` | `truncated_items` 非空 |
| `GARBLED_TITLE_DETECTED` | `garbled_titles` 非空 |
| `EMPTY_BODY_DETECTED` | `empty_body_orders` 非空 |
| `BOILERPLATE_BYLINE_DETECTED` | `boilerplate_bylines` 非空（信息性标记，已在整合层排除） |
| `TIME_FIELD_LOST_DATE` | 任一时间字段退化为 `HH:MM` |
| `TIME_FIELD_MALFORMED` | 任一时间字段无法按 ISO 解析 |

`time_integrity()` 返回 `OK` / `CLOCK_ONLY` / `MISSING` / `MALFORMED`，解析时接受 ISO 8601、RFC 2822（`email.utils.parsedate_to_datetime`）、`YYYY-MM-DD HH:MM:SS +0800` 与中文日期四种本技能实际出现的格式，避免把合法时间误报为畸形。数据层保留完整日期时间，展示层才决定如何呈现，这是「不要把绝对时间压成相对时间」的直接落实。

---

## 三、覆盖度 `quality_gates.build_coverage(bundles, expected)`

借鉴 `ch-news-reporter/prepare_report_data.py:786-812`：

```text
expected_sources = [xwlb, kr8, em_breakfast, baidu_hot]
by_source[sid]    = bundle[sid].item_count
missing           = [sid for sid in expected_sources if by_source[sid] == 0]
feed_failures     = [{source_id, status, status_detail} for 状态非 OK/OK_FROM_CACHE/OK_FROM_LOCAL/STALE_SNAPSHOT]
stale_sources     = [{source_id, age_hours, detail} for 状态 == STALE_SNAPSHOT]
degraded          = bool(missing) or bool(feed_failures) or bool(stale_sources)
complete          = bool(not missing and not feed_failures and not stale_sources)
```

`STALE_SNAPSHOT` 计入降级，是为了与编排层「任一路 `status != OK` 即 `DEGRADED`」保持一致；否则会同时出现 `coverage.complete=true` 与 `status=DEGRADED` 的自相矛盾结论。

`complete` 只描述**采集覆盖度**，不代表事实真伪或新闻价值。

---

## 四、逐字自校验与证据包 `quality_gates.build_evidence(result, bundles)`

借鉴 `auto-daily-report/references/editorial-rules-template.md:100-104`（质量红线 1、3）与 `ch-news-reporter` 的 evidence packet / `grading_audit` 校验：

1. 原文池 = 本次运行四个 bundle 内所有 `items[].title + "\n" + items[].body`。
2. 对每个整合条目的 `lead` 与每条 `points`，先做**精确子串**匹配；仅当去空白后能匹配时，记 `verbatim_normalized_hits`（单独计数，不与精确命中混同）。
3. 两者都不命中 → 记入 `verbatim_misses`（`rank` + 前 90 字符），`integrity.all_verbatim = false`。
4. 每条挂 `evidence`：
   - `source_refs[]`：`source_id` / `source_name` / `order` / `entry_id` / `title` / `source_url` / `content_sha256`
   - `quote_sha256[]`：主题行与每个要点的 SHA-256 前 16 位，便于跨期比对（不是内容本身，不用于还原原文）

`integrity` 字段：`quote_total` / `verbatim_exact_hits` / `verbatim_normalized_hits` / `verbatim_misses` / `all_verbatim` / `evidence_complete` / `source_pool_items`。

这替代了原先必须借助外部脚本读快照目录的验收方式；换电脑、换目录后仍成立。

---

## 五、陈旧快照硬上限 `collect_sources.load_stale()`

```
cap     = 文件名 YYYYMMDD-HHMMSS 解析为北京时间
age_h   = (now - cap) / 3600
若 cap 无法解析 或 age_h < 0 或 age_h > --stale-max-age-hours(默认 48) → 返回 None（拒用）
否则 bundle.snapshot = {file, captured_at, age_hours, max_age_hours, timestamp_verified: true}
```

拒用后该路保持原状态（通常 `NOT_PUBLISHED`），HTML 第一部分该行显示「当期具体页面未检出」，不回退主页、不编造。

---

## 六、按站点差异化超时与发现证据

```
HOST_TIMEOUTS = {"www.36kr.com": 15, "finance.eastmoney.com": 30, "top.baidu.com": 20}
effective_timeout(url, base) = max(base, HOST_TIMEOUTS[host])
```

取 `max` 保证不缩短用户显式指定的 `--timeout`。`bundle.discovery` 记录：`url` / `http_status` / `bytes` / `marker` / `marker_hits` / `effective_timeout` / `fallback_used` / `fallback_status` / `note`。

**已核验并明确不实施「首页优先」回退**（2026-11-10 实地探测）：36氪首页 25,361 B / `8点1氪` 0 / `/p/` 0；东财首页 118,023 B / 0 处「早餐」；东财要闻页 344,283 B / 0 处「早餐」；东财站内搜索页 13,592 B / 0 个文章 ID。全部标 `fallback_status = NOT_ADOPTED`，不把探测失败伪装成可用能力。

---

## 七、可选跨天去重 `cross_day.py`（默认关闭）

| 参数 | 值 | 来源 |
| --- | --- | --- |
| `HISTORY_DAYS` | 3 | `yjkj-news-digest/config.py:162` |
| `BLOCK_THRESHOLD` | 0.75 | `config.py:163` |
| `WARN_THRESHOLD` | 0.60 | `config.py:164` |
| 综合分 | `0.5×标题Jaccard + 0.25×数字匹配 + 0.25×内容词重叠`（无数字时 `0.5+0.5`） | `cross_day_dedup.py:122-128` |

三条硬规则（`cross_day_dedup.py:78-96`）：标题清洗后全等 → 1.0；候选标题（去标点，≥8 字）出现在历史摘要 → 1.0；双方都有显著数字但不共享 → 0.0（放行每月 PMI/CPI 等周期性新闻）。

历史来源：`output/daily/entries-*.json`，按文件内 `today` / `generated_at` 的日期过滤窗口；不新建数据库、不写额外状态文件。启用后：

- 拦截条目整条剔除，`cross_day_audit.blocked[]` 留 `rank_before` / `lead` / `similarity` / `matched_date` / `matched_title`；
- 0.60–0.75 记 `warned[]` 但保留；
- 剩余条目重新连续编号；`entry_count` 更新，`merged_item_count` 保持「同日合并数」原义不变；
- `cross_day_audit.status` ∈ `DISABLED` / `NO_HISTORY` / `APPLIED`。

**默认关闭的理由**：本技能硬约束是「不遗漏独立新闻点」，而跨天去重会删条目。它是用户显式选择的额外能力，不是默认行为。

---

## 八、作用域

本文件所有规则**仅适用于 Daily News for Yu 这一新闻收集功能**，不得外推为其他技能、其他报告类型或用户的通用偏好。v3.0.0 的两部分版面、取消分类 / 微博热搜、抽取式要点、字段精简等既有约定不变。
