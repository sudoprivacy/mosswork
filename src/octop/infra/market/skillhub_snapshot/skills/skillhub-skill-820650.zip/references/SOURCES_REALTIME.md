# 实时信息源核验档案（三路实时 + 《新闻联播》共四源）

首次核验：2026-11-09 11:31–12:46（北京时间）
补充核验：2026-11-09 17:18–17:40（v3.0.0 修订后复测）
环境：Windows / Python 3.13 / 标准库 urllib，零第三方依赖

**v3.0.0 变更**：按需求取消「微博热搜前 50」这一路。当前四源为《新闻联播》逐字稿、36氪「8点1氪」、东方财富财经早餐、百度热搜前 50。采集层其余逻辑（逐字、完整性校验、状态机、重试、快照）未改动。

---

## 一、36氪「8点1氪」

| 项目 | 内容 |
| --- | --- |
| 主入口 | `https://www.36kr.com/feed`（RSS，UTF-8，30 条最新文章） |
| 最新一期发现 | RSS `<item>` 中 `<title>` 含「8点1氪」且 `<pubDate>` 最新者 |
| 正文来源 | 该 item 的 `<description>`（**即整期正文 HTML 全文**，非摘要） |
| 实测期号 | 2026-11-09 08:01:11 +0800 |
| 文章 ID / 链接 | `4061760472585347` → `https://www.36kr.com/p/4061760472585347` |
| 正文容器 | 文章页 `<div class="common-width content articleDetailContent kr-rich-text-wrapper">` |
| 实测 | 正文 HTML 7835–7845 字节 → 纯文本约 6565 字符，切分 26 条，原文块覆盖率 100% |

### 关键坑与处置

- **`36kr.com/p/{id}`（无 www）返回 WAF 验证码页**（约 14.6KB，含 `wafCaptchaVerifyData`）；**必须用 `www.36kr.com/p/{id}`**。`m.36kr.com` 同样被 WAF 拦截。
- 首页 `36kr.com/`、搜索页均为约 25KB SPA 空壳；`gateway.36kr.com` 的 POST 搜索 / 栏目接口返回 HTTP 500。RSS 是唯一稳定入口。
- **RSS 与文章页并非恒定一致**：12:36 首次比对 `IDENTICAL: True`；12:38 复测出现 2 字符差异（RSS 7837 / 文章页 7835）。`--verify-kr` 输出 `identical` / `ratio` / `diff_count` 与差异片段，正文以本次采集的 RSS 为准，不合并、不补全。

---

## 二、东方财富财经早餐

| 项目 | 内容 |
| --- | --- |
| 发现页 | `https://finance.eastmoney.com/yaowen.html`（财经要闻，UTF-8） |
| 最新一期发现 | 页面顺序中第一条标题含「东方财富财经早餐」的 `<a href>` |
| 12:46 实测链接 | `https://finance.eastmoney.com/a/202611083925667993.html` |
| 实测标题 / 发布时间 / 来源 | `东方财富财经早餐 11月9日周一` / `2026-11-09 06:00` / `东方财富Choice数据` |
| 正文容器 | `<div class="txtinfos" id="ContentBody">`（需按 div 深度匹配，避免嵌套截断） |
| 实测 | 正文 HTML 18571 字节 → 纯文本 5109 字符，58 个原文块，切分 34–35 条，覆盖率 100% |

### 关键坑与处置

- `finance.eastmoney.com/a/czqyw.html` 与财经首页**不含早餐链接**；搜索页仅 13KB JS 壳。
- 正文存在两种段落格式：①「标题独立成段」；②「标题正文同段」`<p><strong>伯克希尔：</strong>正文…</p>`。`inline_heading()` 处理同段格式，`title + body` 拼接等于原段落文本，不丢字。
- 站内导览块「点击查看更多上市公司重大公告>>」无正文，已排除出条目（原文仍完整保留在 `full_text`）。
- 标题期号、页面发布时间、文章 ID 前缀是三个独立事实，**未推断其对应关系**。

### 17:29 新增实测：要闻页滚动更新导致早餐链接消失

- 17:29 抓取 `yaowen.html` 得到 233,996 字符（12:46 时约 335KB），页面内「早餐」字样 **0 次**，339 个链接中无早餐标题 → 采集器如实返回 `NOT_PUBLISHED`，`items=[]`。
- 判定：这是源站列表滚动更新把当日早餐挤出要闻页，不是解析故障。**采集发现逻辑未改动**（本次修订仅调整输出规则与文件结构）。
- 处置：正式运行使用既有的 `--allow-stale`，复用 12:52:46 已通过完整性校验的**同一期**快照（34 条，覆盖率 100%），汇总 JSON 标 `STALE_SNAPSHOT` 及原采集时刻。该快照是本次会话早前真实采集结果，不是补写、不是编造、也不冒充执行时刻实时数据。
- 长期监测项：若要闻页持续不再保留早餐链接，需重新核验一个稳定的最新期发现入口，并按第七节流程更新本档案。

---

## 三、百度热搜实时榜前 50

| 项目 | 内容 |
| --- | --- |
| 入口 | `https://top.baidu.com/board?tab=realtime`（UTF-8，约 215KB） |
| 数据位置 | HTML 注释 `<!--s-data:{...}-->` → `data.cards[0].content` |
| 字段 | `word`、`desc`、`hotScore`、`hotTag`、`index`、`rawUrl`、`isTop`、`updateTime` |
| 实测 | 返回 51 项：`content[0]` 为 `isTop=True` 置顶项，其余 `index` 0..49 共 50 条 |

### 口径

- **排除置顶项后按页面顺序取前 50**；置顶项单列 `pinned_item`，不占名次、不计入前 50。
- `updateTime` 为字符串型 Unix 秒（实测 `'1794198938'`），按 `int()` 兼容后转为北京时间。
- 热度值、标签均为源站**原值**，不换算、不解释。

---

## 四、已取消的一路：微博热搜前 50（仅留溯源，不参与运行）

按 v3.0.0 需求，`collect_weibo()` 函数、`WEIBO_API` 常量、`SOURCE_META` 注册、`COLLECTORS` 条目与 `--only` 选项均已移除；脚本不再向 `weibo.com` 发起任何请求。以下为 2026-11-09 12:46 的历史核验结论，保留仅供日后如需恢复时参考：

| 项目 | 内容 |
| --- | --- |
| 入口 | `https://weibo.com/ajax/side/hotSearch`（JSON，约 33KB） |
| 必需请求头 | `Referer: https://weibo.com/`、`X-Requested-With: XMLHttpRequest`、`Accept: application/json` |
| 数据位置 | `data.realtime`；置顶政务话题在 `data.hotgov` |
| 实测 | 返回 52 项，其中 `realpos` 1..50 共 50 条有效名次，另 1–2 条无 `realpos` 的商业推广项 |
| 关键坑 | 不带上述请求头返回 HTTP 403；`s.weibo.com/top/summary` 不带 Cookie 仅 9.6KB 空壳；`m.weibo.cn` 容器接口返回 432 |
| 处置（历史） | 按 `realpos` 1..50 严格取 50 条并剔除推广项，`hotgov` 置顶单列 |

---

## 五、完整性校验规则（四源共用）

| 类型 | 校验项 | 不通过时 |
| --- | --- | --- |
| 文章（36氪 / 东财） | 全文 ≥1000 字符；原文块覆盖率 = 100%；条目数 > 0；东财须含「每日精选」版块 | `INCOMPLETE`，`items=[]` |
| 榜单（百度） | 有效条目 = 50；每条 `word` 非空 | `INCOMPLETE`，`items=[]` |
| 结构 | RSS 有 `<item>`；内嵌数据可解析；正文容器存在 | `PARSE_ERROR` |
| 网络 | HTTP 错误 / 超时 / 403 | `SOURCE_UNAVAILABLE`，按 `--retries` 退避重试 |
| 最新期缺失 | RSS 30 条无「8点1氪」；要闻页无早餐链接 | `NOT_PUBLISHED` |

任何异常状态下 `items` 为空，不生成替代内容。`--allow-stale` 仅显式开启时返回历史快照，并标 `STALE_SNAPSHOT` + 原采集时刻。

---

## 六、v3.0.0 实跑基线（2026-11-09 下午）

| 源 | 状态 | 条目 | 备注 |
| --- | --- | ---: | --- |
| 《新闻联播》 | `OK` | 11 | 最近一期 2026-11-08（当日 19:00 首播前，当日稿未发布） |
| 36氪 8点1氪 | `OK` | 26 | 含 1 个「今日热点导览」块，整合时排除 |
| 东方财富早餐 | `STALE_SNAPSHOT` | 34 | 当日 12:52:46 已校验的同一期；17:29 要闻页已无早餐链接 |
| 百度热搜 | `OK` | 50 | 置顶 1 条单列 |
| **整合结果** | — | **113** | 原始 120 条（121 − 1 导览），合并 4 组共 7 条；要点逐字命中 319/319，独立新闻点覆盖 120/120 |

---

## 七、失效处置

1. 出现 `PARSE_ERROR` 或连续 `SOURCE_UNAVAILABLE`：**立即停止交付该路内容**，不猜测、不用其他网站临时替代后声称是内置源数据。
2. 保存当期原始响应（可用 `collect_sources.py --only <sid>` 复现），比对结构差异。
3. 若需换源，必须重新执行本档案第一至五节核验（每日更新、最新期发现、逐字全文、条数 / 覆盖率校验），并更新本文件与 `SKILL.md` 第二节。
4. 核验通过前保持返回异常状态，不降级为摘要版或要点版；汇总 JSON 如实记录降级状态。
5. HTML 按需求不展示状态与缺口版面；状态与缺口的唯一权威记录是汇总 JSON 与 `entries-*.json` 的审计字段，不得因此省略核验。

---

## 八、v3.1.0 具体文章 URL 重新核实（2026-11-09 18:00）

### 8.1 变更动机

v3.0.0 的 HTML 第一部分把 36氪列成 `https://www.36kr.com/feed`（RSS 主页）、东财列成 `https://finance.eastmoney.com/yaowen.html`（要闻列表页），**不是具体推文 / 文章**。按需求改为按当期动态取得的**具体文章落地页**，`build_daily.py` 从 bundle 的 `source_url` 读取，不再硬编码。

### 8.2 取得方式（动态，每期自动更新）

| 源 | 发现入口（仅内部使用） | 具体页面 URL 的生成 |
| --- | --- | --- |
| 36氪 | `https://www.36kr.com/feed` | 取标题含「8点1氪」且 `pubDate` 最新的 `<item>` → `<link>` 正则 `/p/(\d+)` → `https://www.36kr.com/p/{pid}` |
| 东财 | `https://finance.eastmoney.com/yaowen.html` | 取第一条标题含「东方财富财经早餐」的链接 → `/a/(\d+)\.html` → `https://finance.eastmoney.com/a/{aid}.html` |
| 《新闻联播》 | 首页最新归档日期 | `https://cn.govopendata.com/xinwenlianbo/{YYYYMMDD}/` |
| 百度热搜 | — | `https://top.baidu.com/board?tab=realtime`（榜单页即本次取数的具体页面） |

采集层 `collect_kr8()` / `collect_em()` 原本就已把具体文章页写入 `b["source_url"]`；本次改的是**展示层**，采集逻辑未动。

### 8.3 实地核实结果（HTTP GET，标准库 urllib）

| 源 | URL | HTTP | 响应字节 | 与当期一致性证据 |
| --- | --- | ---: | ---: | --- |
| 36氪 | `https://www.36kr.com/p/4061760472585347` | 200 | 117,849（首次）/ 88,416（二次，动态渲染差异） | 页面含「8点1氪」且命中当期标题关键词「黄仁勋」「比亚迪」「Anthropic」；**无 WAF 验证页**；`<title>` 由前端渲染故脚本未检出，改以正文关键词核对 |
| 东财 | `https://finance.eastmoney.com/a/202611083925667993.html` | 200 | 84,260 / 72,256 | `<title>` = 「东方财富财经早餐 11月9日周一 _ 东方财富网」，与 `issue.title` 一致；含 `div#ContentBody` 与「每日精选」版块 |
| 《新闻联播》 | `https://cn.govopendata.com/xinwenlianbo/20261108/` | 200 | 53,023 | `<title>` = 「2026年11月8日新闻联播 文字版」，与当期播出日期一致 |
| 百度热搜 | `https://top.baidu.com/board?tab=realtime` | 200 | 约 215KB | 实时榜单，内嵌 `<!--s-data:...-->` 可解析 |

结论：两路 URL 已定位到**当期具体文章**，不是主页站点或栏目列表。RSS 与要闻页保留为内部发现入口，不再作为 HTML 中的展示 URL。

### 8.4 展示层校验与异常处置

`build_daily.py` 的 `CONCRETE_URL` 对四条 URL 做正则校验：36氪须匹配 `/p/\d+`，东财须匹配 `/a/\d+\.html`，联播须匹配 `/xinwenlianbo/\d{8}/`，百度须为实时榜单页。汇总 JSON 的 `source_urls` 逐条记录 `{url, concrete}`。

若某期 `source_url` 缺失或不合格，HTML 该行显示「当期具体页面未检出（不回退主页、不编造）」，**不降级为 RSS 页、列表页或官网首页**。这与「不编造、不补全」一致：宁可少一个可点链接，也不拿主页冒充具体文章。

v3.2.0 补充修复：`skeleton()` 原本用发现入口（`yaowen.html` / `36kr.com/feed`）初始化 `source_url`，采集失败时该主页 URL 会残留进 bundle 与汇总 JSON。现于 `finalize()` 中，凡状态非 `OK` / `STALE_SNAPSHOT` 一律把 `source_url` 置空；成功采集与 `--allow-stale` 快照的具体文章页不受影响。2026-11-09 全新目录（无本地快照）实跑复测：东财返回 `NOT_PUBLISHED` 时，HTML 该行显示「当期具体页面未检出」，页面内不含 `yaowen.html`、不含 `36kr.com/feed`。

### 8.5 长期监测项

- 36氪文章页为前端渲染，响应字节数在不同请求间可能变化（本次 117,849 / 88,416），但当期关键词与无 WAF 两项稳定；若后续出现 WAF，须按 `--verify-kr` 的既有结论改用带 `www` 的域名或重新核验入口。
- 东财要闻页滚动更新已于 17:29 观察到早餐链接消失（见第二节）；此时具体文章 URL 来自当日已校验快照，仍可访问且内容一致。若文章页本身也失效，展示层应如实标「未检出」，不得拼造 ID。

---

## 九、v3.3.0 采集体检增强（2026-11-10）

1. **按站点差异化超时**：`collect_sources.py` 的 `HOST_TIMEOUTS = {"www.36kr.com": 15, "finance.eastmoney.com": 30, "top.baidu.com": 20}`，实际超时取 `max(--timeout, 站点下限)`。借鉴 `yjkj-news-digest/fetcher.py::fetch_page` 的分站点超时做法；取 `max` 是为了不缩短用户显式指定的值。
2. **发现入口探测证据**：每路 `bundle.discovery` 记录 `url` / `http_status` / `bytes` / `marker` / `marker_hits` / `effective_timeout` / `fallback_used` / `fallback_status` / `note`。借鉴 `openclaw-news-homepage-fetcher/SKILL.md` 的「标记异常」与 `news-aggregator-skill-v2/MISTAKES.md` 的「不要猜 API」。
3. **陈旧快照年龄上限**：`load_stale()` 解析快照文件名时间戳，计算 `age_hours` 写入 `bundle.snapshot`；超过 `--stale-max-age-hours`（默认 48）即拒用。2026-11-10 实跑东财快照 28.1 小时，正常放行；专项测试用上限 1 小时，快照被拒用、状态回到 `NOT_PUBLISHED`、HTML 如实标「当期具体页面未检出」。
4. **旧快照兼容**：v3.2.0 及更早的快照没有 `discovery` 字段，统一标 `NOT_RECORDED_IN_OLD_SNAPSHOT`，不反推 HTTP 状态、字节数与标记命中数。

### 9.1 「首页优先」回退的实地核验结论（未采纳）

| 探测 URL | HTTP | 字节 | 关键标记命中 |
| --- | ---: | ---: | --- |
| `https://www.36kr.com/` | 200 | 25,361 | `8点1氪` 0 / `/p/` 0（SPA 壳） |
| `https://finance.eastmoney.com/` | 200 | 118,023 | 「早餐」0 |
| `https://finance.eastmoney.com/yaowen.html` | 200 | 344,283 | 「早餐」0 |
| `https://so.eastmoney.com/news/s?keyword=东方财富财经早餐` | 200 | 13,592 | 文章 ID 0（JS 渲染） |

结论：`openclaw` 的「首页优先、频道补充、正文确认」在本技能四源上**没有可用回退入口**，故不实施，只保留探测证据。东财早餐稳定发现入口记为**待补查**；在找到并核验新入口前，继续依赖 `--allow-stale` 复用已校验快照，不编造当期文章 ID 或链接。
