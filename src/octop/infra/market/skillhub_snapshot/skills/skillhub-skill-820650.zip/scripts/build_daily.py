#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Daily News for Yu — HTML 日报生成 (build_daily.py)

v3.2.0（2026-11-09）：按需求撤销 v3.1.0 新增的「二、汇总梗概」，
恢复为「一、源站 / 二、新闻（按重要性排序）」两部分。
v3.1.0 的另一项改动（URL 定位到当期具体页面）**保留**。
v3.3.0：仅在机器可读 summary 中新增 coverage / quality / integrity /
cross_day / collector 诊断字段；**HTML 版面仍严格为两部分**，每条新闻仍只呈现
排序号、来源、源内第几条、得分与整合要点。

第一部分四个 URL 由采集层 bundle 动态取得：36氪取当期「8点1氪」文章页、
东方财富取当期早餐文章页、《新闻联播》取当期按日页、百度取实时榜单页；
不再列 RSS / 列表 / 官网主页。取不到合格具体页面时如实标「未检出」，
不回退主页、不编造。

新闻条目只呈现排序号、紧随其后的来源、源内第几条、得分与整合要点；
不呈现归类依据、评分算式、采集时刻、原文出处链接、逐字原文或其他后半段标注。
"""

from __future__ import annotations

import html
import json
import os
import re
from datetime import datetime, timedelta, timezone

CN_TZ = timezone(timedelta(hours=8))

SOURCE_ORDER = ["xwlb", "kr8", "em_breakfast", "baidu_hot"]
SOURCE_SHORT = {
    "xwlb": "新闻联播", "kr8": "36氪 8点1氪", "em_breakfast": "东方财富早餐",
    "baidu_hot": "百度热搜",
}
BAIDU_BOARD = "https://top.baidu.com/board?tab=realtime"

# 具体要求：URL 必须落到「当期具体页面」，不是站点首页 / 栏目列表 / RSS 主页
CONCRETE_URL = {
    "xwlb": re.compile(r"^https?://cn\.govopendata\.com/xinwenlianbo/\d{8}/?$"),
    "kr8": re.compile(r"^https?://(?:www\.)?36kr\.com/p/\d+/?$"),
    "em_breakfast": re.compile(r"^https?://finance\.eastmoney\.com/a/\d+\.html$"),
    "baidu_hot": re.compile(r"^https?://top\.baidu\.com/board\?tab=realtime$"),
}
SITE_NAMES = [
    ("xwlb", "《新闻联播》"),
    ("kr8", "36氪「8点1氪」"),
    ("em_breakfast", "东方财富财经早餐"),
    ("baidu_hot", "百度热搜"),
]


def esc(s) -> str:
    return html.escape(str(s if s is not None else ""), quote=True)


def para(s) -> str:
    return esc(s).replace("\n", "<br>\n")


CSS = """
:root{--bg:#f7f8fa;--card:#fff;--ink:#1f2328;--muted:#5b6470;--line:#e3e7ec;--accent:#1a5fb4}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
font-family:"PingFang SC","Microsoft YaHei","Hiragino Sans GB","Source Han Sans SC",system-ui,sans-serif;
font-size:15.5px;line-height:1.85}
.wrap{max-width:960px;margin:0 auto;padding:30px 22px 70px}
h1{margin:0 0 22px;font-size:25px;letter-spacing:.4px;font-weight:650}
h2{font-size:18px;margin:30px 0 14px;padding-bottom:8px;border-bottom:2px solid var(--line);font-weight:650}
.sites{list-style:none;margin:0;padding:0}
.sites li{padding:8px 0;border-bottom:1px dashed var(--line);display:flex;flex-wrap:wrap;gap:10px;align-items:baseline}
.sites .nm{min-width:170px;font-weight:600}
.sites a{color:var(--accent);text-decoration:none;word-break:break-all;font-size:14.5px}
.sites a:hover{text-decoration:underline}
.missing{color:#a4501a;font-size:13.5px}
.item{background:var(--card);border:1px solid var(--line);border-radius:9px;
padding:14px 18px;margin-bottom:11px;break-inside:avoid}
.line{display:flex;flex-wrap:wrap;gap:8px;align-items:baseline;font-size:13.5px;color:var(--muted)}
.no{display:inline-block;min-width:30px;text-align:center;color:#fff;background:var(--accent);
border-radius:5px;font-weight:700;font-size:12.5px;padding:1px 6px}
.srcname{color:var(--ink);font-weight:650;font-size:14.5px}
.sep{color:#c3cad3}
.score{color:var(--accent);font-weight:650}
.lead{font-size:16px;font-weight:650;line-height:1.7;margin:9px 0 7px}
.pts{margin:0;padding:0 0 0 18px}
.pts li{font-size:14.5px;line-height:1.85;margin-bottom:4px;color:#30363d;word-break:break-word}
@media(max-width:640px){.wrap{padding:18px 12px 48px}h1{font-size:21px}.item{padding:12px 13px}
.sites .nm{min-width:100%}}
@media print{body{background:#fff}.item{border-color:#ccc;box-shadow:none}}
"""


def concrete_sites(bundles: dict) -> list[tuple[str, str, bool]]:
    """按当期 bundle 取具体页面 URL；不合格一律不展示链接，不回退到主页。"""
    rows = []
    for sid, name in SITE_NAMES:
        b = bundles.get(sid) or {}
        url = (b.get("source_url") or "").strip()
        if sid == "baidu_hot" and not url:
            url = BAIDU_BOARD
        ok = bool(url) and bool(CONCRETE_URL[sid].match(url))
        rows.append((name, url, ok))
    return rows


def render_sites(rows: list[tuple[str, str, bool]]) -> str:
    out = ['<ul class="sites">']
    for name, url, ok in rows:
        if ok:
            out.append('<li><span class="nm">%s</span><a href="%s" target="_blank" rel="noopener">%s</a></li>'
                       % (esc(name), esc(url), esc(url)))
        else:
            out.append('<li><span class="nm">%s</span>'
                       '<span class="missing">当期具体页面未检出（不回退主页、不编造）</span></li>'
                       % esc(name))
    out.append('</ul>')
    return "\n".join(out)


def render_entry(e: dict) -> str:
    out = ['<article class="item">', '<div class="line">']
    out.append('<span class="no">%s</span>' % e["rank"])
    out.append('<span class="srcname">%s</span>' % esc(e["source"]))
    out.append('<span class="sep">|</span><span>源内第 %s 条</span>' % esc(e["source_orders"]))
    out.append('<span class="sep">|</span><span class="score">得分 %s</span>' % esc(e["score"]))
    out.append('</div>')
    out.append('<div class="lead">%s</div>' % esc(e["lead"]))
    if e["points"]:
        out.append('<ul class="pts">')
        for p in e["points"]:
            out.append('<li>%s</li>' % para(p))
        out.append('</ul>')
    out.append('</article>')
    return "\n".join(out)


def render(bundles: dict, ed: dict, meta: dict):
    report_date = meta.get("report_date", "")
    generated = meta.get("generated_at", "")
    degraded = meta.get("degraded", False)
    rows = concrete_sites(bundles)

    H = ['<!DOCTYPE html>', '<html lang="zh-CN">', '<head>',
         '<meta charset="utf-8">',
         '<meta name="viewport" content="width=device-width,initial-scale=1">',
         '<title>Daily News for Yu · %s</title>' % esc(report_date),
         '<style>%s</style>' % CSS,
         '</head><body><main class="wrap">',
         '<h1>Daily News for Yu · %s</h1>' % esc(report_date)]

    H.append('<section><h2>一、源站</h2>')
    H.append(render_sites(rows))
    H.append('</section>')

    H.append('<section><h2>二、新闻（按重要性排序）</h2>')
    for e in ed["entries"]:
        H.append(render_entry(e))
    H.append('</section>')

    H.append('</main></body></html>')
    html_text = "\n".join(H)

    summary = {
        "generated_at": generated,
        "report_date": report_date,
        "degraded": degraded,
        "source_status": {sid: {
            "status": (bundles.get(sid) or {}).get("status", "SOURCE_UNAVAILABLE"),
            "item_count": (bundles.get(sid) or {}).get("item_count", 0),
            "retrieved_at": (bundles.get(sid) or {}).get("retrieved_at", ""),
        } for sid in SOURCE_ORDER},
        "source_urls": {sid: {"url": url, "concrete": ok}
                        for (sid, _), (_, url, ok) in zip(SITE_NAMES, rows)},
        "entry_count": ed["entry_count"],
        "original_item_count": ed["original_item_count"],
        "merged_item_count": ed["merged_item_count"],
        "merge_audit": ed["merge_audit"],
        "scoring": ed["scoring"],
        "top10": [{"rank": e["rank"], "lead": e["lead"], "source": e["source"],
                   "score": e["score"]} for e in ed["entries"][:10]],
        # 状态与缺口仅保留在机器可读 JSON，按需求不进入 HTML 版面
        "data_gaps": meta.get("data_gaps", []),
        # v3.3.0 新增：全部为机器可读诊断，不进入 HTML
        "version": "3.3.0",
        "coverage": meta.get("coverage", {}),
        "quality": {sid: (bundles.get(sid) or {}).get("quality", {}) for sid in SOURCE_ORDER},
        "integrity": ed.get("integrity", {}),
        "cross_day": ed.get("cross_day_audit", {"enabled": False, "status": "DISABLED"}),
        "collector": meta.get("collector", {}),
    }
    return html_text, summary


def write_report(out_dir: str, report_date: str, html_text: str, summary: dict):
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.now(CN_TZ).strftime("%Y%m%d-%H%M")
    hp = os.path.join(out_dir, "news-daily-%s.html" % stamp)
    jp = os.path.join(out_dir, "news-daily-%s.json" % stamp)
    with open(hp, "w", encoding="utf-8", newline="\n") as f:
        f.write(html_text)
    with open(jp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    summary["output_files"] = [hp, jp]
    return hp, jp
