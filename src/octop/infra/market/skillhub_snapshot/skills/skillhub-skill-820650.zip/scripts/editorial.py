#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Daily News for Yu — 条目整合与重要性排序层 (editorial.py)

v3.0.0（2026-11-09）按需求重构：
  1. 取消分类体系；不再产生 category / category_basis / score_formula 等字段。
  2. 对四个源站的全部已采集条目做统一整合：合并同类及信息关联相近条目，
     句级去重保留各自核心事实，避免重复。
  3. 仅依据新闻学标准对「整合后」条目计算重要性得分并排序，只保留得分数值。
  4. 「整合后的新闻要点」采用抽取式原文句（逐字取自源站标题与正文），
     不改写、不转述、不补写、不调用模型概括 —— 这是不虚构事实的确定性保证。

铁律：要点中的每个句子都能在源站逐字原文中找到；合并只做组织，不创造新事实。
合并依据、被去重句、评分因子等审计信息写入机器可读 JSON，不进入 HTML 版面。
"""

from __future__ import annotations

import difflib
import re
from collections import Counter
from datetime import date, datetime, timedelta, timezone

CN_TZ = timezone(timedelta(hours=8))

# 四个源站（微博热搜已于 v3.0.0 取消）
SOURCE_ORDER = ["xwlb", "kr8", "em_breakfast", "baidu_hot"]
SOURCE_SHORT = {
    "xwlb": "新闻联播",
    "kr8": "36氪 8点1氪",
    "em_breakfast": "东方财富早餐",
    "baidu_hot": "百度热搜",
}
AUTHORITY = {
    "xwlb": 1.00,           # 中央级电视新闻
    "em_breakfast": 0.80,   # 专业财经媒体
    "kr8": 0.70,            # 专业科技商业媒体
    "baidu_hot": 0.30,      # 聚合舆情榜，非事实源
}
SOURCE_INDEX = {sid: i for i, sid in enumerate(SOURCE_ORDER)}
HOT_SOURCES = {"baidu_hot"}

# 新闻学「重要性 / 影响面」的可观测代理词（不是事实真伪判断）
IMPACT_TERMS = [
    "习近平", "国务院", "国常会", "中共中央", "政治局", "全会", "部署", "印发",
    "政策性资金", "地方债", "资本市场", "央行", "货币政策", "财政部",
    "发改委", "关税", "制裁", "中美", "十五五", "专项债", "人民币",
    "火灾", "事故", "死亡", "遇难", "突发", "调查组", "地震", "台风", "暴雪", "疫情",
    "破产", "停产", "裁员", "收购", "涨价", "跌停", "涨停", "禁令", "通报",
]

# 重要性权重（合计 100）；仅输出合成得分，不输出算式
WEIGHTS = {"A": 35, "M": 20, "P": 15, "H": 12, "R": 10, "T": 8}

# 合并参数：宁可少合并，也不把两个独立新闻点并成一条
MERGE_THRESHOLD = 0.58          # 触发合并的关联分下限
SAME_SOURCE_MIN_LITERAL = 0.42  # 同源合并额外要求的字面相似度下限（同源条目多为编辑刻意分开的独立新闻）
MAX_GROUP_MEMBERS = 5           # 单组上限，防止一个高频实体把整份日报串成一条
MAX_POINTS = 12
DEDUP_RATIO = 0.90
INDEX_TITLES = ("今日热点导览", "导览", "本期目录", "本期要目")

# v3.3.0：源站署名行（如「整理丨几何鱼」）不是独立新闻点。
# 借鉴 yjkj-news-digest/rules_config.py::DATATYPE_PATTERNS 与
# fetcher.py::is_boilerplate 的编辑署名清理；仅在「标题严格匹配且无正文」时排除，
# 避免误杀含这些词的新闻标题。
BYLINE_TITLE = re.compile(r"^(?:整理|编辑|责编|校对|记者|来源|撰文|排版)\s*[丨|:：、]", re.I)


def is_boilerplate_byline(title: str, body: str) -> bool:
    return bool(not (body or "").strip() and BYLINE_TITLE.match((title or "").strip()))

# 栏目型/泛化标题不参与合并（如「国内联播快讯」与「国际联播快讯」字面极像，
# 但内容完全不同；只靠字面相似度会把它们错误并成一条）
GENERIC_TITLE_MARKERS = ("联播快讯", "今日热点", "本期目录", "本期要目", "早报", "早餐")

# 主题词停用表：过滤「为什么」「来了」「万元」这类不构成事件实体的高频片段
STOP_TERMS = (
    "为什么", "是不是", "怎么", "如何", "来了", "还能", "回应", "公布", "宣布",
    "最新", "突然", "联播快讯", "学习贯彻", "精神", "中国", "全国", "今日",
    "事件", "消息", "视频", "现场", "官方", "网友", "第一", "一个", "可以",
    "没有", "这个", "什么", "已经", "我们", "你们", "他们", "表示", "认为",
    "发现", "出现", "开始", "结束", "万元", "亿元", "美元", "人民币", "公司",
    "可能", "真的", "居然", "竟然", "终于", "直接", "立刻", "马上", "以后",
    "现在", "昨天", "今天", "明天", "上午", "下午", "晚上", "记者", "报道",
    "新闻", "热点", "有关", "相关", "进行", "实现", "成为", "多少", "哪些", "快讯",
)
# 事件/动作词：仅共享主体名（人名、公司名）不足以判定同一事件，
# 必须另有共现的事件词，或标题字面高度接近。词表为可审计的显式规则。
EVENT_TERMS = (
    "婚外情", "出轨", "触雷", "起火", "被盗", "劫案", "收购", "违约", "调查",
    "停产", "裁员", "夺冠", "免单", "轮毂装反", "发布", "道歉", "离职",
    "涨价", "跌停", "涨停", "通报", "事故", "火灾", "遇难", "地震", "台风",
    "上市", "路演", "估值", "融资", "减持", "增持", "中标", "签约", "开工",
    "投产", "落成", "竣工", "获批", "禁令", "制裁", "关税", "降息", "加息",
    "捐赠", "捐款", "回应", "发布会", "财报", "净利", "营收", "破产",
    "清算", "重组", "立案", "触雷起火", "货物被盗", "订单违约", "捐",
)
# 同一事件的不同措辞：两条分别命中同一组内的不同词，视为事件共现
EVENT_GROUPS = (
    ("婚外情", "出轨", "外遇", "不忠"),
    ("被盗", "劫案", "失窃", "盗窃", "偷"),
    ("触雷", "起火", "爆炸", "触礁"),
    ("收购", "并购", "买下", "收购传闻"),
    ("捐", "捐赠", "捐款", "捐助", "再捐"),
    ("夺冠", "免单", "冠军"),
    ("坐高铁", "高铁", "行李箱", "一人一箱"),
)

TOPIC_DF_MIN, TOPIC_DF_MAX = 2, 12
_LATIN = re.compile(r"[a-z0-9]{3,}")

_PUNCT = re.compile(
    r"[\s\u3000\xa0#，。！？；：、,.!?;:\"'“”‘’()（）\[\]【】<>《》\-—…·|/\\]+")
_SENT_SPLIT = re.compile(r"(?<=[。！？!?；;])\s*|\n+")


# --------------------------------------------------------------------------
# 文本归一与相似度（仅用于判定，不写回任何原文字段）
# --------------------------------------------------------------------------

def norm(s) -> str:
    return _PUNCT.sub("", str(s if s is not None else "")).lower()


def bigrams(s: str) -> set[str]:
    return {s[i:i + 2] for i in range(len(s) - 1)} if len(s) >= 2 else ({s} if s else set())


def similarity(a: str, b: str) -> tuple[float, str]:
    """返回 (0..1 相似度, 可复核的判定依据)。归一仅用于比较。"""
    na, nb = norm(a), norm(b)
    if len(na) < 4 or len(nb) < 4:
        return 0.0, ""
    if na == nb:
        return 1.0, "标题归一后完全相同"
    if len(na) >= 8 and na in nb:
        return 0.95, "一方标题完整包含另一方"
    if len(nb) >= 8 and nb in na:
        return 0.95, "一方标题完整包含另一方"
    ba, bb = bigrams(na), bigrams(nb)
    union = ba | bb
    j = len(ba & bb) / len(union) if union else 0.0
    r = difflib.SequenceMatcher(None, na, nb).ratio()
    s = max(j, 0.90 * r)
    nums_a, nums_b = set(re.findall(r"\d+", na)), set(re.findall(r"\d+", nb))
    if nums_a & nums_b and len(ba & bb) >= 3:
        s += 0.12  # 共享同一数字（伤亡数、金额、日期）+ 共享字组，显著抬升同事件概率
    return round(min(1.0, s), 4), "二元字组 Jaccard=%.3f；序列比=%.3f；共享数字=%s" % (
        j, r, "是" if nums_a & nums_b else "否")


# --------------------------------------------------------------------------
# 主题词挖掘与关联判定
#
# 仅靠字面相似度无法识别「信息关联相近」：例如「黄仁勋发布致英伟达全员信」
# 与「黄仁勋承认婚外情 英伟达还能投吗」字面重合很低，却是同一事件簇；
# 反过来「国内联播快讯」与「国际联播快讯」字面高度相似，却是两条独立新闻。
# 因此改为：跨条目复现的事件实体词共现为主，字面相似度为辅，栏目型标题不参与合并。
# --------------------------------------------------------------------------

def is_generic(title: str) -> bool:
    n = norm(title)
    return len(n) < 5 or any(w in n for w in GENERIC_TITLE_MARKERS)


def mine_topics(titles: list[str]) -> list[str]:
    """从全体标题自动挖掘跨条目复现的事件实体词，无需外部词典或模型。"""
    freq = Counter()
    for t in titles:
        n = norm(t)
        if not n:
            continue
        segs = set()
        for L in (3, 4, 5, 6):
            for i in range(len(n) - L + 1):
                segs.add(n[i:i + L])
        for w in _LATIN.findall(n):
            segs.add(w)
        for s in segs:
            freq[s] += 1
    cand = [s for s, c in freq.items()
            if TOPIC_DF_MIN <= c <= TOPIC_DF_MAX and len(s) >= 3
            # 必须是连续 3 字以上的中文片段或纯英文词；排除「000」「00亿美」等数字碎片
            and (re.search(r"[\u4e00-\u9fff]{3,}", s) or re.fullmatch(r"[a-z]{3,}", s))
            and not any(w in s for w in STOP_TERMS)]
    cand.sort(key=lambda x: (-len(x), -freq[x], x))
    keep: list[str] = []
    for s in cand:
        # 仅当短词被更长且更高频的候选完整包含时才视为冗余
        if any(s in t and len(t) > len(s) and freq[s] <= freq[t] for t in keep):
            continue
        keep.append(s)
    return keep


def related(a: str, b: str, ta: set, tb: set, same_source: bool) -> tuple[float, str]:
    """判定「同类 / 信息关联相近」，返回 (关联分, 可复核依据)。"""
    if is_generic(a) or is_generic(b):
        return 0.0, ""
    na, nb = norm(a), norm(b)
    shared = sorted(ta & tb)
    lit, _ = similarity(a, b)
    common_events = [w for w in EVENT_TERMS if w in na and w in nb]
    for grp in EVENT_GROUPS:
        ha = [w for w in grp if w in na]
        hb = [w for w in grp if w in nb]
        if ha and hb:
            tag = "%s↔%s" % (ha[0], hb[0])
            if tag not in common_events:
                common_events.append(tag)
    # 两条通道之一：① 共享主题词且共现事件词（同主体 + 同动作）；② 标题字面高度接近
    # 只共享「比亚迪」「马斯克」「英伟达」等主体名而不共现事件词的，一律不合并
    if not (shared and common_events) and lit < 0.60:
        return 0.0, ""
    if same_source and lit < SAME_SOURCE_MIN_LITERAL:
        return 0.0, ""
    s = min(1.0, 0.60 + 0.08 * min(len(shared), 3)
            + 0.10 * min(len(common_events), 3) + 0.60 * lit)
    return round(s, 4), "共享主题词「%s」；共现事件词「%s」；字面相似度 %.3f%s" % (
        "、".join(shared[:4]), "、".join(common_events[:4]), lit,
        ("（同源附加门槛 %.2f）" % SAME_SOURCE_MIN_LITERAL) if same_source else "")


# --------------------------------------------------------------------------
# 期号日期与时效（沿用原实现，仅去掉微博）
# --------------------------------------------------------------------------

def issue_date(bundle: dict):
    sid = bundle.get("source_id")
    iss = bundle.get("issue", {}) or {}
    s = ""
    if sid == "xwlb":
        s = iss.get("broadcast_date") or bundle.get("resolved_date") or ""
    elif sid in ("kr8", "em_breakfast"):
        s = (iss.get("published_at") or "")[:10]
        if not s or s == "未检出":
            s = iss.get("page_date") or ""
    if not s or s == "未检出":
        return None
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        return None


def recency(sid: str, bundle: dict, today: date) -> float:
    if sid in HOT_SOURCES:
        return 1.00
    d = issue_date(bundle)
    if d is None:
        return 0.60
    if d == today:
        return 1.00
    if d == today - timedelta(days=1):
        return 0.60
    return 0.30


# --------------------------------------------------------------------------
# 采集条目 -> 统一条目池
# --------------------------------------------------------------------------

def collect_items(bundles: dict, today: date) -> tuple[list[dict], list[dict]]:
    items, excluded = [], []
    for sid in SOURCE_ORDER:
        b = bundles.get(sid) or {}
        if not isinstance(b, dict):
            continue
        if b.get("status") not in ("OK", "OK_FROM_CACHE", "STALE_SNAPSHOT", "OK_FROM_LOCAL"):
            continue
        its = b.get("items") or []
        n = len(its)
        t_val = recency(sid, b, today)
        for it in its:
            title = (it.get("title") or "").strip()
            body = (it.get("body") or "").strip()
            if title in INDEX_TITLES:
                excluded.append({"source_id": sid, "order": it.get("order", 0),
                                 "title": title, "reason": "站内目录/导览块，非独立新闻点"})
                continue
            if is_boilerplate_byline(title, body):
                excluded.append({"source_id": sid, "order": it.get("order", 0),
                                 "title": title, "reason": "源站编辑署名行，无正文，非独立新闻点"})
                continue
            order = int(it.get("order", 0) or 0)
            meta = it.get("meta", {}) or {}
            items.append({
                "entry_id": "%s-%s" % (sid, order),
                "source_id": sid,
                "source_name": SOURCE_SHORT.get(sid, sid),
                "order": order,
                "rank": int(meta.get("rank", order) or order),
                "title": title,
                "body": body,
                "section": it.get("section", ""),
                "position": 1.00 if n <= 1 else round(1 - (order - 1) / (n - 1), 4),
                "recency": t_val,
            })
    # 种子顺序：权威度降序 -> 源序 -> 源内顺序，保证同样输入必得同样分组
    items.sort(key=lambda x: (-AUTHORITY.get(x["source_id"], 0.30),
                              SOURCE_INDEX.get(x["source_id"], 9), x["order"], x["entry_id"]))
    return items, excluded


# --------------------------------------------------------------------------
# 合并：同类 / 信息关联相近
# --------------------------------------------------------------------------

def cluster(items: list[dict]) -> list[dict]:
    """贪心分组：只与各组种子比较，避免链式滚雪球合并。"""
    groups: list[dict] = []
    for it in items:
        best, best_s, best_reason = None, 0.0, ""
        for g in groups:
            if len(g["members"]) >= MAX_GROUP_MEMBERS:
                continue
            seed = g["members"][0]
            s, reason = related(
                it["title"], seed["title"], it.get("topics", set()), seed.get("topics", set()),
                it["source_id"] == seed["source_id"])
            if s >= MERGE_THRESHOLD and s > best_s:
                best, best_s, best_reason = g, s, reason
        if best is not None:
            it["similarity"] = round(best_s, 4)
            it["merge_reason"] = best_reason
            best["members"].append(it)
        else:
            it["similarity"] = 1.0
            it["merge_reason"] = "组内首个条目（种子）"
            groups.append({"members": [it]})
    return groups


# --------------------------------------------------------------------------
# 整合后的新闻要点：抽取式原文句 + 句级去重
# --------------------------------------------------------------------------

def split_sentences(body: str) -> list[str]:
    return [x.strip() for x in _SENT_SPLIT.split(body) if x and len(x.strip()) >= 6]


def info_score(s: str) -> int:
    v = 0
    if re.search(r"\d", s):
        v += 2
    if re.search(r"[%％万亿亿元美元人民币]", s):
        v += 1
    if len(s) >= 25:
        v += 1
    if re.search(r"(表示|指出|宣布|发布|公布|决定|要求|同比|环比|预计|发生|造成|回应|签署|通过)", s):
        v += 1
    return v


def representative(item: dict) -> list[str]:
    """每个成员最多贡献 2 个逐字原文句；短正文整段保留，绝不截断或改写。"""
    body = item["body"]
    if not body:
        return []
    if len(body) <= 90:
        return [body]
    sents = split_sentences(body)
    if not sents:
        return [body]
    idx = sorted(sorted(range(len(sents)), key=lambda i: (-info_score(sents[i]), i))[:2])
    return [sents[i] for i in idx]


def dedup_keep(seq: list[str], limit: int) -> tuple[list[str], list[str]]:
    kept, dropped = [], []
    for s in seq:
        n = norm(s)
        if not n:
            continue
        dup = False
        for x in kept:
            nx = norm(x)
            if n == nx:
                dup = True
                break
            if min(len(n), len(nx)) >= 8 and \
                    difflib.SequenceMatcher(None, n, nx).ratio() >= DEDUP_RATIO:
                dup = True
                break
        if dup or len(kept) >= limit:
            dropped.append(s)
            continue
        kept.append(s)
    return kept, dropped


def build_points(g: dict) -> tuple[str, list[str], list[str], int]:
    members = g["members"]
    lead = members[0]["title"] or members[0]["source_name"]
    seq: list[str] = []
    # 其他成员的不同标题本身即核心事实，逐字保留
    for m in members[1:]:
        t = m["title"]
        if t and t != lead:
            seq.append(t)
    # 每个成员贡献逐字原文句
    omitted = 0
    for m in members:
        reps = representative(m)
        seq.extend(reps)
        raw = m["body"]
        if raw and len(raw) > 90:
            omitted += max(0, len(split_sentences(raw)) - len(reps))
    pool = [lead] + seq
    kept, dropped = dedup_keep(pool, MAX_POINTS + 1)
    pts = [x for x in kept if x != lead]
    return lead, pts, dropped, omitted


# --------------------------------------------------------------------------
# 新闻学重要性评分（无分类、无算式输出）
# --------------------------------------------------------------------------

def score_group(g: dict) -> tuple[float, dict]:
    m = g["members"]
    sids = {x["source_id"] for x in m}
    A = max(AUTHORITY.get(s, 0.30) for s in sids)
    M = min(1.0, 0.35 * (len(sids) - 1) + 0.20 * (len(m) - len(sids)))
    P = m[0]["position"]
    text = g["lead"] + " " + " ".join(g["points"])
    H = 1.00 if any(w in text for w in IMPACT_TERMS) else 0.00
    rs = [1 - (x["rank"] - 1) / 50 for x in m if x["source_id"] in HOT_SOURCES]
    R = round(max(rs), 4) if rs else 0.00
    T = max(x["recency"] for x in m)
    s = sum(WEIGHTS[k] * v for k, v in
            (("A", A), ("M", M), ("P", P), ("H", H), ("R", R), ("T", T)))
    f = {"A": round(A, 4), "M": round(M, 4), "P": round(P, 4),
         "H": round(H, 4), "R": round(R, 4), "T": round(T, 4)}
    return round(s, 2), f


def source_meta(g: dict) -> tuple[str, str, list[dict]]:
    order_seen: list[str] = []
    for m in g["members"]:
        if m["source_id"] not in order_seen:
            order_seen.append(m["source_id"])
    source = " · ".join(SOURCE_SHORT.get(s, s) for s in order_seen)
    parts = []
    for s in order_seen:
        os_ = sorted({m["order"] for m in g["members"] if m["source_id"] == s})
        parts.append("、".join(str(x) for x in os_))
    return source, " / ".join(parts), [
        {"source_id": m["source_id"], "source_name": m["source_name"], "order": m["order"],
         "entry_id": m["entry_id"], "title": m["title"]}
        for m in g["members"]]


# --------------------------------------------------------------------------
# 主入口
# --------------------------------------------------------------------------

def build_entries(bundles: dict, today: date | None = None) -> dict:
    """返回整合后、按重要性排序的条目列表及机器可读的合并/评分审计。"""
    today = today or datetime.now(CN_TZ).date()
    items, excluded = collect_items(bundles, today)
    topics = mine_topics([x["title"] for x in items])
    for it in items:
        n = norm(it["title"])
        it["topics"] = {t for t in topics if t in n}
    groups = cluster(items)

    entries = []
    for i, g in enumerate(groups, 1):
        lead, pts, dropped, omitted = build_points(g)
        g["lead"], g["points"] = lead, pts
        score, factors = score_group(g)
        source, orders, refs = source_meta(g)
        entries.append({
            "group_id": "g%03d" % i,
            "lead": lead,
            "points": pts,
            "source": source,
            "source_orders": orders,
            "score": score,
            # 以下为机器可读审计字段，按需求不进入 HTML 版面
            "member_refs": refs,
            "member_count": len(g["members"]),
            "factors": factors,
            "merge_evidence": [
                {"entry_id": m["entry_id"], "title": m["title"],
                 "similarity": m.get("similarity"), "reason": m.get("merge_reason", "")}
                for m in g["members"]],
            "dropped_duplicate_points": dropped,
            "omitted_body_sentences": omitted,
        })

    entries.sort(key=lambda x: (-x["score"],
                                min(SOURCE_INDEX.get(r["source_id"], 9) for r in x["member_refs"]),
                                min(r["order"] for r in x["member_refs"]),
                                x["group_id"]))
    for i, e in enumerate(entries, 1):
        e["rank"] = i

    multi = [
        {"group_id": e["group_id"], "rank": e["rank"], "lead": e["lead"],
         "member_count": e["member_count"], "score": e["score"],
         "evidence": e["merge_evidence"]}
        for e in entries if e["member_count"] > 1]
    return {
        "generated_at": datetime.now(CN_TZ).isoformat(timespec="seconds"),
        "today": today.isoformat(),
        "entries": entries,
        "entry_count": len(entries),
        "original_item_count": len(items),
        "merged_item_count": len(items) - len(entries),
        "merge_audit": {
            "merge_threshold": MERGE_THRESHOLD,
            "same_source_min_literal": SAME_SOURCE_MIN_LITERAL,
            "topic_term_count": len(topics),
            "topic_terms": topics[:120],
            "generic_title_markers": list(GENERIC_TITLE_MARKERS),
            "max_group_members": MAX_GROUP_MEMBERS,
            "max_points": MAX_POINTS,
            "dedup_ratio": DEDUP_RATIO,
            "excluded_index_items": excluded,
            "multi_member_group_count": len(multi),
            "multi_member_groups": multi,
            "dropped_duplicate_point_count": sum(len(e["dropped_duplicate_points"]) for e in entries),
            "omitted_body_sentence_count": sum(e["omitted_body_sentences"] for e in entries),
            "point_source": "要点为源站标题与正文的逐字原文句抽取，按信息量选取并句级去重；未改写、未转述、未补写",
        },
        "scoring": {
            "weights": WEIGHTS,
            "authority": AUTHORITY,
            "tie_break": "按 (-得分, 最高权威源序, 最小源内顺序, 组ID) 确定性排序",
            "notice": "得分为编辑排序指标，不是事实真伪或新闻价值的官方判定；HTML 仅展示得分数值",
        },
    }
