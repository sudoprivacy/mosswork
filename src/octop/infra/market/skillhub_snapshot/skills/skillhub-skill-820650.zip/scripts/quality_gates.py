#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Daily News for Yu — 质量闸、覆盖度与可追溯性 (quality_gates.py)

v3.3.0 新增。借鉴来源（均为 SkillHub 公开技能包原文，见 references/BENCHMARK.md）：
  1. ch-news-reporter / scripts/prepare_report_data.py
       is_content_truncated()   —— 结尾省略号检测
       build_coverage()         —— coverage 作为一等公民
       query_collection_failures() —— 逐源失败清单
  2. ch-news-reporter / tests/test_ai_daily_value_gates.py
       grading_audit 校验         —— 证据/审计字段必须存在且可复核
  3. yjkj-news-digest / scripts/news_digest_v2/rules_config.py
       has_garbled_title()      —— 西里尔字母 / 非 CJK 比例乱码检测
  4. news-aggregator-skill-v2 / MISTAKES.md
       「Absolute Time」教训    —— 数据层禁止把绝对时间压成 HH:MM
       「Stale Cache」教训      —— 读缓存前必须核对时间戳
  5. auto-daily-report / references/editorial-rules-template.md
       质量红线 1「每条信息必须附原始来源链接」、红线 3「不编造不存在的信息」

硬约束（本技能专有，不因借鉴而放松）：
  * 质量闸**只标记、不删改**：不删除任何条目、不改写任何逐字原文、不补写内容。
  * 所有新增字段仅进入机器可读 JSON，不进入两部分 HTML 版面。
  * 零第三方依赖，仅 Python 标准库。
"""

from __future__ import annotations

import hashlib
import re
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime

CN_TZ = timezone(timedelta(hours=8))
SOURCE_ORDER = ["xwlb", "kr8", "em_breakfast", "baidu_hot"]

# 百度热搜条目按源站口径本就可能没有正文；不作为「内容缺失」缺陷，只如实计数。
BODY_OPTIONAL_SOURCES = {"baidu_hot"}


# --------------------------------------------------------------------------
# 一、逐字原文质量闸（借鉴 ch-news-reporter / yjkj-news-digest）
# --------------------------------------------------------------------------

def is_content_truncated(content: str) -> bool:
    """源站 feed 自身截断：只在**结尾**出现省略号才算，中间出现不算。

    与 ch-news-reporter/scripts/prepare_report_data.py::is_content_truncated 同口径：
        tail = content.rstrip()[-3:]
        return tail.endswith("…") or tail.endswith("...")
    """
    if not content:
        return False
    tail = content.rstrip()[-3:]
    return tail.endswith("…") or tail.endswith("...")


def has_garbled_text(text: str) -> bool:
    """编码错乱检测：与 yjkj-news-digest/rules_config.py::has_garbled_title 同口径。

    GBK 页面被误读为 UTF-8 时标题会出现西里尔字母；另设非 CJK/非 ASCII 占比 > 0.5 兜底。
    """
    if not text:
        return False
    if re.search(r"[\u0430-\u044f\u0410-\u042f]", text):
        return True
    non_cjk_ascii = sum(
        1 for c in text
        if not (0x4E00 <= ord(c) <= 0x9FFF or 0x3000 <= ord(c) <= 0x303F
                or ord(c) == 0x20 or ord(c) == 0x3001
                or 0x0020 <= ord(c) <= 0x007E)
    )
    return len(text) > 5 and non_cjk_ascii / len(text) > 0.5


_ONLY_CLOCK = re.compile(r"^\d{1,2}:\d{2}(?::\d{2})?$")


_DATETIME_FORMATS = ("%Y-%m-%d %H:%M:%S %z", "%Y-%m-%d %H:%M:%S",
                     "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y年%m月%d日 %H:%M")


def _parse_any_datetime(value: str):
    """接受本技能四个源站实际出现的三种格式，不把合法格式误报为畸形。

    ISO 8601（东财/百度/采集时刻）、RFC 2822（36氪 RSS pubDate）、
    「YYYY-MM-DD HH:MM:SS  +0800」（36氪清洗后）、中文日期。
    """
    s = re.sub(r"\s+", " ", str(value).strip()).replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        pass
    try:
        return parsedate_to_datetime(s)
    except (TypeError, ValueError, IndexError):
        pass
    for f in _DATETIME_FORMATS:
        try:
            return datetime.strptime(s, f)
        except ValueError:
            continue
    return None


def time_integrity(value: str) -> str:
    """数据层时间字段完整性。返回 OK / CLOCK_ONLY / MISSING / MALFORMED。

    借鉴 news-aggregator-skill-v2/MISTAKES.md 第一条：把 Unix 时间戳格式化成 HH:MM
    会丢掉日期，导致「12 小时前」被误判为「1 小时前」。数据层必须保留完整日期时间。
    """
    if not value or str(value).strip() in ("", "未检出"):
        return "MISSING"
    if _ONLY_CLOCK.match(str(value).strip()):
        return "CLOCK_ONLY"
    return "OK" if _parse_any_datetime(value) else "MALFORMED"


def issue_time_value(b: dict) -> tuple[str, str]:
    """按源取真正存在的期号/更新时间字段，避免把「字段不存在」误记为畸形。"""
    issue = b.get("issue") or {}
    for key in ("published_at", "broadcast_date", "source_update_time", "updateTime"):
        if issue.get(key):
            return key, str(issue[key])
    return "", ""


# 源站署名行：不是独立新闻点。借鉴 yjkj-news-digest/rules_config.py 的
# DATATYPE_PATTERNS（记者/编辑/通讯员署名）与 fetcher.py::is_boilerplate。
BYLINE_TITLE = re.compile(r"^(?:整理|编辑|责编|校对|记者|来源|撰文|排版)\s*[丨|:：、]", re.I)


def is_byline_title(title: str) -> bool:
    return bool(BYLINE_TITLE.match((title or "").strip()))


def inspect_bundle(b: dict) -> dict:
    """逐源质量体检。**只标记、不删改**，结果写入 bundle['quality'] 与汇总 JSON。"""
    sid = b.get("source_id", "")
    items = b.get("items") or []
    truncated, garbled, empty_body, bylines = [], [], [], []
    for it in items:
        title = it.get("title", "") or ""
        body = it.get("body", "") or ""
        if is_content_truncated(body) or is_content_truncated(title):
            truncated.append({"order": it.get("order", 0), "title": title[:80],
                              "tail": (body or title).rstrip()[-12:]})
        if has_garbled_text(title):
            garbled.append({"order": it.get("order", 0), "title": title[:80]})
        if not body.strip() and is_byline_title(title):
            bylines.append({"order": it.get("order", 0), "title": title[:80]})
        elif not body.strip() and sid not in BODY_OPTIONAL_SOURCES:
            empty_body.append(it.get("order", 0))

    tkey, tval = issue_time_value(b)
    time_fields = {
        "retrieved_at": time_integrity(b.get("retrieved_at", "")),
        (tkey or "issue_time"): time_integrity(tval),
    }
    flags = []
    if truncated:
        flags.append("TRUNCATED_TAIL_DETECTED")
    if garbled:
        flags.append("GARBLED_TITLE_DETECTED")
    if empty_body:
        flags.append("EMPTY_BODY_DETECTED")
    if bylines:
        flags.append("BOILERPLATE_BYLINE_DETECTED")
    if "CLOCK_ONLY" in time_fields.values():
        flags.append("TIME_FIELD_LOST_DATE")
    if "MALFORMED" in time_fields.values():
        flags.append("TIME_FIELD_MALFORMED")

    q = {
        "source_id": sid,
        "status": b.get("status", ""),
        "item_count": len(items),
        "truncated_items": truncated,
        "garbled_titles": garbled,
        "empty_body_orders": empty_body,
        "boilerplate_bylines": bylines,
        "body_optional_by_source": sid in BODY_OPTIONAL_SOURCES,
        "time_field_key": tkey or "",
        "time_fields": time_fields,
        "snapshot": dict(b.get("snapshot") or {}),
        "discovery": dict(b.get("discovery") or {}),
        "flags": flags,
        "content_sha256": b.get("content_sha256", ""),
        "policy": "只标记不删改：不删除条目、不改写原文、不补写；异常进入机器可读 JSON，不进入 HTML",
    }
    b["quality"] = q
    if flags:
        for f in flags:
            g = "[质量闸] %s：%s 命中 %s 项" % (
                sid, f,
                {"TRUNCATED_TAIL_DETECTED": len(truncated),
                 "GARBLED_TITLE_DETECTED": len(garbled),
                 "EMPTY_BODY_DETECTED": len(empty_body),
                 "BOILERPLATE_BYLINE_DETECTED": len(bylines),
                 "TIME_FIELD_LOST_DATE": 1,
                 "TIME_FIELD_MALFORMED": 1}.get(f, 0))
            if g not in b.get("data_gaps", []):
                b.setdefault("data_gaps", []).append(g)
    return q


# --------------------------------------------------------------------------
# 二、Coverage 一等公民（借鉴 ch-news-reporter / build_coverage）
# --------------------------------------------------------------------------

def build_coverage(bundles: dict, expected: list[str] | None = None) -> dict:
    """按源列出应到 / 实到条数、缺失源与逐源失败清单，供机器可读诊断。"""
    expected = expected or list(SOURCE_ORDER)
    by_source, failures, missing, stale = {}, [], [], []
    for sid in expected:
        b = bundles.get(sid) or {}
        n = int(b.get("item_count", 0) or 0)
        by_source[sid] = n
        if n == 0:
            missing.append(sid)
        st = b.get("status", "SOURCE_UNAVAILABLE")
        if st == "STALE_SNAPSHOT":
            stale.append({"source_id": sid,
                          "age_hours": (b.get("snapshot") or {}).get("age_hours"),
                          "detail": b.get("status_detail", "")})
        elif st not in ("OK", "OK_FROM_CACHE", "OK_FROM_LOCAL"):
            failures.append({"source_id": sid, "status": st,
                             "detail": b.get("status_detail", "")})
    # 顶层 degraded 判据是「任一路 status != OK」，因此 STALE_SNAPSHOT 必须计入，
    # 否则出现 coverage.complete=true 与 status=DEGRADED 自相矛盾的结论。
    degraded = bool(missing) or bool(failures) or bool(stale)
    return {
        "expected_sources": expected,
        "by_source": by_source,
        "missing": missing,
        "all_present": not missing,
        "feed_failures": failures,
        "stale_sources": stale,
        "degraded": degraded,
        "complete": bool(not missing and not failures and not stale),
        "note": "complete 要求四路均有内容、无失败、且无陈旧快照；只描述采集覆盖度，不代表事实真伪，不进入 HTML",
    }


# --------------------------------------------------------------------------
# 三、逐字自校验与证据包（借鉴 auto-daily-report 质量红线 / ch-news-reporter evidence packet）
# --------------------------------------------------------------------------

def _norm_ws(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


def build_evidence(result: dict, bundles: dict) -> dict:
    """给每个整合条目挂可回溯证据，并内置逐字原文命中校验（替代外部验收脚本）。"""
    pool: list[str] = []
    pool_norm: list[str] = []
    for sid in SOURCE_ORDER:
        for it in (bundles.get(sid) or {}).get("items") or []:
            s = (it.get("title", "") or "") + "\n" + (it.get("body", "") or "")
            pool.append(s)
            pool_norm.append(_norm_ws(s))

    exact = normalized = total = 0
    misses = []
    for e in result.get("entries", []):
        refs = []
        for r in e.get("member_refs", []):
            sid = r.get("source_id", "")
            b = bundles.get(sid) or {}
            refs.append({
                "source_id": sid,
                "source_name": r.get("source_name", ""),
                "order": r.get("order", 0),
                "entry_id": r.get("entry_id", ""),
                "title": r.get("title", ""),
                "source_url": b.get("source_url", ""),
                "content_sha256": b.get("content_sha256", ""),
            })
        e["evidence"] = {
            "source_refs": refs,
            "quote_sha256": [hashlib.sha256(x.encode("utf-8")).hexdigest()[:16]
                             for x in [e["lead"]] + list(e.get("points", []))],
        }
        for q in [e["lead"]] + list(e.get("points", [])):
            total += 1
            if any(q in s for s in pool):
                exact += 1
            elif any(_norm_ws(q) in s for s in pool_norm):
                normalized += 1
            else:
                misses.append({"rank": e.get("rank"), "quote": q[:90]})

    integrity = {
        "quote_total": total,
        "verbatim_exact_hits": exact,
        "verbatim_normalized_hits": normalized,
        "verbatim_misses": misses,
        "all_verbatim": not misses,
        "evidence_complete": all(e.get("evidence", {}).get("source_refs")
                                  for e in result.get("entries", [])),
        "source_pool_items": len(pool),
        "note": "逐字命中指整合要点可在本次采集的标题/正文中原样找到；normalized 仅去除空白差异，单独计数",
    }
    result["integrity"] = integrity
    return integrity
