#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Daily News for Yu — 三路实时采集器 (collect_sources.py)

v3.0.0 变更：按需求取消「微博热搜前 50」采集环节，本模块不再向 weibo.com
发起任何请求。采集层其余逻辑（逐字、完整性校验、状态机、重试、快照）保持不变。
v3.2.0 修复：采集失败时清空 skeleton 默认的发现页 URL（列表页 / RSS 主页），
避免把主页冒充「当期具体页面」写入 bundle 与汇总 JSON。成功采集与
--allow-stale 快照路径的具体文章 URL 不变。
v3.3.0 优化（借鉴 SkillHub 同类技能，见 references/BENCHMARK.md）：
  1. 按站点差异化超时（借鉴 yjkj-news-digest/fetcher.py::fetch_page）；
  2. 发现入口探测证据写入 bundle.discovery（借鉴 openclaw「标记异常」与
     news-aggregator-skill-v2/MISTAKES.md「不要猜 API」）；
  3. 陈旧快照先核对时间戳并设硬性年龄上限（借鉴 MISTAKES.md「Stale Cache
     Hallucination」），避免把多日前的快照当作本轮结果。
  注意：经实地核验，36氪首页为 SPA 壳、东财首页与要闻页当日均无「早餐」标记、
  东财站内搜索页无文章 ID（JS 渲染），故「首页优先」发现回退在本技能四源上
  **不成立、未实施**，只如实记录探测证据，不伪装成可用能力。

沿用《新闻联播》逐字稿提取标准：
1. 正文逐字保留，不改写、不转述、不以摘要替代、不补全。
2. 每路独立状态与退出码；异常时 items 为空，绝不编造。
3. 多重完整性校验，校验不过即拒绝交付该路内容。
4. 明确来源、采集时刻、期号、原文链接、数据缺口。
5. 零第三方依赖，仅用 Python 标准库。

三路实时（加上由 fetch_xwlb.py 提供的《新闻联播》，共四个源站）：
  kr8          36氪「8点1氪」最新一期（RSS 全文 + 可选文章页交叉核对）
  em_breakfast 东方财富「财经早餐」最新一期（要闻页发现 + 正文全文）
  baidu_hot    百度热搜实时榜前 50（执行时刻）
"""

from __future__ import annotations

import argparse
import difflib
import hashlib
import html
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone

CN_TZ = timezone(timedelta(hours=8))
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")
FEED_36KR = "https://www.36kr.com/feed"
ARTICLE_36KR_TPL = "https://www.36kr.com/p/{pid}"
NEWSFLASH_36KR = "https://www.36kr.com/newsflashes/"
EM_LIST = "https://finance.eastmoney.com/yaowen.html"
EM_ARTICLE_TPL = "https://finance.eastmoney.com/a/{aid}.html"
BAIDU_BOARD = "https://top.baidu.com/board?tab=realtime"
# WEIBO_API 已于 v3.0.0 移除：本技能不再采集微博热搜。

# v3.3.0：按站点差异化超时。借鉴 yjkj-news-digest/fetcher.py::fetch_page 的做法
# （原实现对 36kr.com 用 15s、cinn.cn / cnii.com.cn 用 30s、其余用默认 10s）。
# 本技能只对其实际请求的三个域名设下限，取 max(用户 --timeout, 该下限)，
# 绝不缩短用户显式指定的超时；策略本身写入 bundle 供复核。
HOST_TIMEOUTS = {
    "www.36kr.com": 15,
    "finance.eastmoney.com": 30,
    "top.baidu.com": 20,
}


def effective_timeout(url: str, base: int) -> int:
    host = ""
    m = re.match(r"^https?://([^/:]+)", url or "")
    if m:
        host = m.group(1).lower()
    return max(int(base), HOST_TIMEOUTS.get(host, 0))

STATUS_TEXT = {
    "OK": "完整采集，校验通过",
    "NOT_PUBLISHED": "最新一期尚未发布",
    "MISSING": "未发现目标栏目稿件",
    "INCOMPLETE": "内容不完整或条数不符，已拒绝交付该路内容",
    "SOURCE_UNAVAILABLE": "信息源不可达、超时或被拒绝",
    "PARSE_ERROR": "页面/接口结构变化，无法按既定规则解析",
    "STALE_SNAPSHOT": "源不可用，返回上一次快照（非执行时刻实时数据）",
}
EXIT_CODE = {
    "OK": 0, "NOT_PUBLISHED": 2, "MISSING": 3, "INCOMPLETE": 4,
    "SOURCE_UNAVAILABLE": 5, "PARSE_ERROR": 6, "STALE_SNAPSHOT": 8,
}

SOURCE_META = {
    "kr8": ("36氪「8点1氪」最新一期", FEED_36KR, "https://36kr.com/"),
    "em_breakfast": ("东方财富财经早餐最新一期", EM_LIST, "https://finance.eastmoney.com/"),
    "baidu_hot": ("百度热搜实时榜前 50", BAIDU_BOARD, "https://top.baidu.com/"),
}


def now_cn() -> datetime:
    return datetime.now(CN_TZ)


def iso_now() -> str:
    return now_cn().isoformat(timespec="seconds")


def log(msg: str) -> None:
    print("[news-daily] " + msg, file=sys.stderr, flush=True)


# --------------------------------------------------------------------------
# 通用网络与文本工具
# --------------------------------------------------------------------------

def fetch(url: str, extra: dict | None = None, timeout: int = 20):
    h = {"User-Agent": UA, "Accept": "text/html,application/xhtml+xml,application/xml,"
         "application/json,*/*;q=0.8", "Accept-Language": "zh-CN,zh;q=0.9"}
    if extra:
        h.update(extra)
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
        st = getattr(r, "status", 200)
        ct = r.headers.get("Content-Type", "") or ""
    enc = ""
    m = re.search(rb"charset\s*=\s*[\"']?([\w-]+)", raw[:2000], re.I)
    if m:
        enc = m.group(1).decode("ascii", "ignore").lower()
    elif "charset=" in ct.lower():
        enc = re.search(r"charset\s*=\s*[\"']?([\w-]+)", ct, re.I).group(1).lower()
    used = "utf-8"
    for e in dict.fromkeys([enc, "utf-8", "gb18030"]):
        if not e:
            continue
        try:
            text = raw.decode(e)
            used = e
            break
        except (UnicodeDecodeError, LookupError):
            continue
    else:
        text = raw.decode("utf-8", "replace")
    return text, st, len(raw), used


def fetch_retry(url, extra=None, timeout=20, retries=2, interval=3.0, tag=""):
    t = effective_timeout(url, timeout)   # v3.3.0：按站点差异化超时下限
    last = None
    for i in range(retries + 1):
        try:
            return fetch(url, extra=extra, timeout=t)
        except Exception as e:
            last = e
            if i < retries:
                log("%s 第 %s 次请求失败（%s），%.1f 秒后重试" % (tag, i + 1, type(e).__name__, interval))
                time.sleep(interval)
    raise last


def clean_inline(s: str) -> str:
    """把片段转为单行纯文本。仅做透明技术归一，不改汉字与标点。"""
    s = re.sub(r"<(script|style)\b.*?</\1>", "", s, flags=re.S | re.I)
    s = re.sub(r"<br\s*/?>", " ", s, flags=re.I)
    s = html.unescape(re.sub(r"<[^>]+>", "", s))
    s = s.replace("\xa0", " ").replace("\u3000", " ").replace("\r", " ")
    return re.sub(r"[ \t]+", " ", s).strip()


def div_fragment(page: str, open_pattern: str) -> str:
    """按 div 深度匹配提取容器的 innerHTML，避免嵌套导致截断。"""
    m = re.search(open_pattern, page, re.I)
    if not m:
        return ""
    start = m.end()
    depth = 1
    for mm in re.finditer(r"<div\b[^>]*>|</div>", page[start:], re.I):
        depth += -1 if mm.group(0).lower().startswith("</") else 1
        if depth == 0:
            return page[start:start + mm.start()]
    return page[start:]


def xml_text(item: str, tag: str) -> str:
    m = re.search(r"<%s>(.*?)</%s>" % (tag, tag), item, re.S)
    if not m:
        return ""
    raw = m.group(1).strip()
    if raw.startswith("<![CDATA[") and raw.endswith("]]>"):
        raw = raw[9:-3]
    return raw.strip()


def blocks(fragment: str) -> list[tuple[str, str]]:
    """按块级标签顺序切分，返回 (标签, innerHTML)。"""
    return [(t.lower(), inner) for t, inner in re.findall(
        r"<(h[1-6]|ul|p|center|table)\b[^>]*>(.*?)</\1>", fragment, re.S | re.I)]


def is_heading_p(inner: str, txt: str) -> bool:
    """判断 <p> 是否为条目标题：整段几乎全被 <strong> 包裹、较短、非完整句。"""
    if not txt or len(txt) > 90 or txt.endswith("。"):
        return False
    strongs = re.findall(r"<strong\b[^>]*>(.*?)</strong>", inner, re.S | re.I)
    if not strongs:
        return False
    s_txt = "".join(clean_inline(x) for x in strongs)
    return len(s_txt) / max(1, len(txt)) >= 0.75


def inline_heading(inner: str, txt: str):
    """
    处理「标题与正文同段」格式：<p><strong>伯克希尔：</strong>正文……</p>
    返回 (标题原文含冒号, 正文原文)；title + body 拼接后等于原段落文本，不丢字。
    """
    s = inner
    lead = re.match(r"[\s\u3000\xa0]*", s)
    pos = lead.end() if lead else 0
    heads: list[str] = []
    while True:
        m = re.match(r"<strong\b[^>]*>(.*?)</strong>", s[pos:], re.S | re.I)
        if not m:
            break
        heads.append(clean_inline(m.group(1)))
        pos += m.end()
        w = re.match(r"[\s\u3000\xa0]*", s[pos:])
        if w:
            pos += w.end()
    if not heads:
        return None
    head = "".join(heads).strip()
    rest = clean_inline(s[pos:])
    if not head.endswith(("：", ":")) and rest.startswith(("：", ":")):
        head += rest[0]
        rest = rest[1:].lstrip()
    if not head.endswith(("：", ":")):
        return None
    if not (2 <= len(head) <= 70) or len(rest) < 15:
        return None
    return head, rest


def split_article(fragment: str, source_id: str):
    """
    把文章逐字切分为「条目」。切分只是组织方式：
    - full_text 保留容器全部原文（逐字、按块换行）
    - coverage 校验每个原文块都被处理，保证无遗漏
    """
    blks = blocks(fragment)
    full_lines: list[str] = []
    items: list[dict] = []
    section = ""
    cur: dict | None = None
    total_blocks = 0
    assigned_blocks = 0

    def new_item(title: str, sec: str):
        return {"title": title, "section": sec, "paragraphs": [], "source_id": source_id}

    for tag, inner in blks:
        txt = clean_inline(inner)
        if not txt:
            continue
        total_blocks += 1
        full_lines.append(txt)
        if tag.startswith("h"):
            section = txt
            assigned_blocks += 1          # 版块标题进入 full_text，不作为条目正文
            continue
        if tag == "ul":
            lis = [clean_inline(x) for x in re.findall(r"<li\b[^>]*>(.*?)</li>", inner, re.S | re.I)]
            body_lines = [x for x in lis if x]
            if cur:
                items.append(cur)
                cur = None
            it = new_item(section or "导览", section)
            it["paragraphs"] = body_lines
            items.append(it)
            assigned_blocks += 1
            continue
        if is_heading_p(inner, txt):
            if cur:
                items.append(cur)
            cur = new_item(txt, section)
            assigned_blocks += 1
        else:
            ih = inline_heading(inner, txt)
            if ih:
                if cur:
                    items.append(cur)
                cur = new_item(ih[0], section)
                cur["paragraphs"].append(ih[1])
            else:
                if cur is None:
                    cur = new_item(section or "正文", section)
                cur["paragraphs"].append(txt)
            assigned_blocks += 1
    if cur:
        items.append(cur)

    for idx, it in enumerate(items, 1):
        it["order"] = idx
        it["body"] = "\n".join(it["paragraphs"])
        it["body_chars"] = len(it["body"])
        it["meta"] = {"section": it["section"]}
        it.pop("paragraphs", None)
    full_text = "\n".join(full_lines)
    coverage = (assigned_blocks / total_blocks) if total_blocks else 0.0
    return items, full_text, {"total_blocks": total_blocks,
                              "assigned_blocks": assigned_blocks,
                              "coverage": round(coverage, 4)}


def prune_guides(items: list[dict], b: dict) -> list[dict]:
    """排除无正文的站内导览块；原文仍完整保留在 full_text，order 保持原文位置不重排。"""
    kept, excluded = [], []
    for it in items:
        if it.get("body_chars", 0) == 0 and re.search(r"点击查看更多|>>|查看更多", it["title"]):
            excluded.append(it["title"])
            continue
        kept.append(it)
    b["validation"]["excluded_guide_items"] = len(excluded)
    if excluded:
        b["warnings"].append("已排除 %s 个无正文的站内导览块（原文仍完整保留在 full_text）：%s"
                             % (len(excluded), "；".join(excluded[:3])))
    return kept


# --------------------------------------------------------------------------
# Bundle 骨架
# --------------------------------------------------------------------------

def skeleton(sid: str) -> dict:
    name, url, official = SOURCE_META[sid]
    return {
        "source_id": sid,
        "display_name": name,
        "status": "OK", "status_text": "", "status_detail": "", "exit_code": 0,
        "retrieved_at": iso_now(),
        "source_url": url, "official_reference": official,
        "http_status": None, "bytes": 0, "encoding": "",
        "issue": {},
        "fidelity": {
            "verbatim_from_source": True,
            "no_rewrite": True,
            "no_summary_substitution": True,
            "source_omissions": [],
            "normalization": ["HTML 标签剥离", "HTML 实体解码",
                              "U+00A0/U+3000 空格归一", "块级标签转换行", "首尾空白去除"],
            "note": "条目化为组织方式；容器全部原文见 full_text，覆盖率校验保证无段落遗漏",
        },
        "validation": {"declared_count": None, "parsed_count": 0,
                       "coverage": None, "issues": []},
        "items": [], "item_count": 0,
        "full_text": "", "full_text_chars": 0, "content_sha256": "",
        "pinned_item": None,
        "crosscheck": {},
        "warnings": [], "data_gaps": [],
    }


def finalize(b: dict) -> dict:
    b["status_text"] = STATUS_TEXT.get(b["status"], "")
    b["exit_code"] = EXIT_CODE.get(b["status"], 1)
    b["item_count"] = len(b["items"])
    b["validation"]["parsed_count"] = len(b["items"])
    b["full_text_chars"] = len(b["full_text"])
    payload = b["full_text"] + "\n" + "\n".join(
        x.get("title", "") + "\n" + x.get("body", "") for x in b["items"])
    b["content_sha256"] = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    if b["status"] not in ("OK", "STALE_SNAPSHOT"):
        b["items"] = []
        b["item_count"] = 0
        b["full_text"] = ""
        # skeleton 的 source_url 默认是「发现入口」（要闻列表页 / RSS 主页）。
        # 采集失败时若原样保留，汇总 JSON 会出现主页 URL，容易被误当作当期具体页面。
        # 清空后展示层据实标注「当期具体页面未检出」，不回退主页、不编造。
        # 成功采集与 --allow-stale 快照均已在前面写入具体文章页，不受影响。
        b["source_url"] = ""
    gaps = [
        "采集时刻为北京时间 %s；页面可能随后更新，本结果不回写修订。" % b["retrieved_at"],
        "原文以源站页面为准；本结果不含图片、视频、超链接跳转与站内交互元素。",
        "条目划分为派生编排，不改变逐字原文。",
    ]
    if b["source_id"] == "baidu_hot":
        gaps += [
            "热搜词为平台舆情线索，不是经核实的事实报道；日报中不得作为事实陈述引用。",
            "热度值/排名为源站原始口径，计算方式未公开，不做换算、不推测含义。",
            "榜单为执行时刻快照，与后续时刻不一致属正常，不代表数据错误。",
        ]
    if b["source_id"] == "kr8":
        gaps.append("RSS 与文章页正文逐字一致（2026-11-09 核验 7845 字符）；默认只取 RSS，--verify-kr 可开启双源核对。")
    if b["source_id"] == "em_breakfast":
        gaps.append("标题期号、页面显示日期与文章 ID 前缀为三个独立字段，未推断其对应关系。")
    if b["status"] not in ("OK", "STALE_SNAPSHOT"):
        gaps.insert(0, "该路未取得完整内容，items 为空；未生成任何替代或补全内容。")
    b["data_gaps"] = gaps
    return b


def fail(b: dict, status: str, detail: str, issue: str = "") -> dict:
    b["status"] = status
    b["status_detail"] = detail
    if issue:
        b["validation"]["issues"].append(issue)
    return finalize(b)


# --------------------------------------------------------------------------
# A. 36氪「8点1氪」
# --------------------------------------------------------------------------

def collect_kr8(args) -> dict:
    b = skeleton("kr8")
    b["fidelity"]["source_omissions"] = [
        "36氪文章页的导读卡片、相关推荐、评论与广告（不在正文容器内，不补写）",
    ]
    try:
        feed, st, nb, enc = fetch_retry(FEED_36KR, timeout=args.timeout,
                                        retries=args.retries, interval=args.interval, tag="36氪RSS")
    except Exception as e:
        return fail(b, "SOURCE_UNAVAILABLE", "36氪 RSS 不可达：%s: %s" % (type(e).__name__, str(e)[:160]))
    b.update({"http_status": st, "bytes": nb, "encoding": enc})
    # v3.3.0：发现入口探测证据（只记录，不据猜测切换入口）
    b["discovery"] = {
        "url": FEED_36KR, "http_status": st, "bytes": nb,
        "marker": "8点1氪", "marker_hits": feed.count("8点1氪"),
        "effective_timeout": effective_timeout(FEED_36KR, args.timeout),
        "fallback_used": False, "fallback_status": "NOT_ADOPTED",
        "note": "2026-11-10 实地核验：36氪首页 HTTP 200 但 0 处 /p/ 链接（SPA 壳）；"
                "首页优先回退不成立，故不实施，仅保留 RSS 主入口的探测证据",
    }

    raw_items = re.findall(r"<item>(.*?)</item>", feed, re.S)
    if not raw_items:
        return fail(b, "PARSE_ERROR", "RSS 中未发现任何 <item>，疑似格式改版")
    cands = []
    for it in raw_items:
        title = xml_text(it, "title")
        if "8点1氪" not in title:
            continue
        cands.append({
            "title": title,
            "link": xml_text(it, "link"),
            "pub": xml_text(it, "pubDate"),
            "desc": xml_text(it, "description"),
        })
    if not cands:
        return fail(b, "NOT_PUBLISHED", "最新 30 条 RSS 中未发现「8点1氪」，判定最新一期尚未发布")
    pick = max(cands, key=lambda x: x["pub"])
    m = re.search(r"/p/(\d+)", pick["link"])
    if not m:
        return fail(b, "PARSE_ERROR", "无法从 RSS link 解析文章 ID：" + pick["link"][:120])
    pid = m.group(1)
    url = ARTICLE_36KR_TPL.format(pid=pid)
    b["source_url"] = url
    b["issue"] = {
        "title": pick["title"], "published_at": pick["pub"],
        "rss_link": pick["link"], "article_id": pid,
        "discovery": "36氪 RSS 最新 30 条中标题含「8点1氪」且发布时间最新者",
    }
    frag = pick["desc"]
    if not frag:
        return fail(b, "INCOMPLETE", "RSS description 为空，无法取得完整正文")

    if getattr(args, "verify_kr", False):
        try:
            art, _, _, _ = fetch(url, timeout=effective_timeout(url, args.timeout))
            art_frag = div_fragment(art, r'<div[^>]*class="[^"]*articleDetailContent[^"]*"[^>]*>')
            a_txt, b_txt = frag.strip(), art_frag.strip()
            sm = difflib.SequenceMatcher(None, a_txt, b_txt)
            diffs = [{"op": op, "rss": a_txt[a1:a2][:80], "article": b_txt[c1:d1][:80]}
                     for op, a1, a2, c1, d1 in sm.get_opcodes() if op != "equal"]
            b["crosscheck"] = {
                "enabled": True,
                "rss_chars": len(a_txt), "article_chars": len(b_txt),
                "identical": a_txt == b_txt,
                "ratio": round(sm.ratio(), 6),
                "diff_count": len(diffs), "diffs": diffs[:3],
                "note": "RSS description 与 www.36kr.com 文章页正文容器逐字比对（比对前统一去除首尾空白）；"
                        "两者可能因缓存或源站修订出现差异，正文以本次采集的 RSS 为准，差异如实记录、不合并补全",
            }
            if diffs:
                b["warnings"].append(
                    "RSS 与文章页存在 %s 处差异（相似度 %.4f），已保留 RSS 原文并量化记录，不合并、不补全"
                    % (len(diffs), sm.ratio()))
        except Exception as e:
            b["crosscheck"] = {"enabled": True, "error": "%s: %s" % (type(e).__name__, str(e)[:120])}
            b["warnings"].append("文章页交叉核对失败（不影响 RSS 正文采集）")

    items, full_text, cov = split_article(frag, "kr8")
    items = prune_guides(items, b)
    b["items"], b["full_text"] = items, full_text
    b["validation"]["coverage"] = cov["coverage"]
    b["validation"]["declared_count"] = cov["total_blocks"]
    issues = []
    if len(full_text) < 1000:
        issues.append("全文仅 %s 字符，疑似截断" % len(full_text))
    if cov["coverage"] < 0.999:
        issues.append("原文块覆盖率 %.4f，存在未归类段落" % cov["coverage"])
    if not items:
        issues.append("条目切分结果为 0")
    if issues:
        return fail(b, "INCOMPLETE", "完整性校验未通过：" + "；".join(issues))
    b["status_detail"] = "取得最新一期全文 %s 字符，切分 %s 条，原文块覆盖率 %.1f%%" % (
        len(full_text), len(items), cov["coverage"] * 100)
    return finalize(b)


# --------------------------------------------------------------------------
# B. 东方财富财经早餐
# --------------------------------------------------------------------------

def collect_em(args) -> dict:
    b = skeleton("em_breakfast")
    b["fidelity"]["source_omissions"] = [
        "文章页的图片、行情表格图片、二维码与订阅引导（不在正文文字容器内，不补写）",
        "站内相关新闻、广告与评论区（不属早餐正文）",
    ]
    try:
        lst, st, nb, enc = fetch_retry(EM_LIST, timeout=args.timeout,
                                       retries=args.retries, interval=args.interval, tag="东财要闻页")
    except Exception as e:
        return fail(b, "SOURCE_UNAVAILABLE", "东方财富要闻页不可达：%s: %s" % (type(e).__name__, str(e)[:160]))
    b.update({"http_status": st, "bytes": nb, "encoding": enc})
    # v3.3.0：发现入口探测证据。当日要闻页无「早餐」标记时如实记为 0 命中，
    # 不改用主页 / 站内搜索冒充（已核验二者均不可用），也不编造当期文章。
    b["discovery"] = {
        "url": EM_LIST, "http_status": st, "bytes": nb,
        "marker": "东方财富财经早餐", "marker_hits": lst.count("东方财富财经早餐"),
        "effective_timeout": effective_timeout(EM_LIST, args.timeout),
        "fallback_used": False, "fallback_status": "NOT_ADOPTED",
        "note": "2026-11-10 实地核验：东财首页 / 要闻页当日均 0 处「早餐」，"
                "站内搜索页 0 个文章 ID（JS 渲染）；无可用回退入口，标为待补查",
    }

    links = re.findall(
        r'<a[^>]+href="(?:https?:)?//finance\.eastmoney\.com/a/(\d+)\.html"[^>]*>(.*?)</a>',
        lst, re.S | re.I)
    pick = None
    for aid, label in links:
        if "东方财富财经早餐" in clean_inline(label):
            pick = (aid, clean_inline(label))
            break
    if not pick:
        return fail(b, "NOT_PUBLISHED", "要闻页未发现「东方财富财经早餐」链接，判定最新一期尚未发布")
    aid, label = pick
    url = EM_ARTICLE_TPL.format(aid=aid)
    b["source_url"] = url
    try:
        art, st2, nb2, enc2 = fetch_retry(url, timeout=args.timeout,
                                          retries=args.retries, interval=args.interval, tag="东财早餐正文")
    except Exception as e:
        return fail(b, "SOURCE_UNAVAILABLE", "早餐文章页不可达：%s: %s" % (type(e).__name__, str(e)[:160]))
    b.update({"http_status": st2, "bytes": nb2, "encoding": enc2})

    title_m = re.search(r"<title>(.*?)</title>", art, re.S | re.I)
    page_title = clean_inline(title_m.group(1)) if title_m else label
    date_m = re.search(r"<span class=\"flr\">(\d{4}-\d{2}-\d{2})</span>", art)
    page_date = date_m.group(1) if date_m else "未检出"
    pub_m = re.search(r"(\d{4})年(\d{2})月(\d{2})日\s*(\d{2}:\d{2})", art)
    published_at = ("%s-%s-%s %s" % pub_m.groups()) if pub_m else "未检出"
    src_m = re.search(r"来源：\s*([\u4e00-\u9fffA-Za-z0-9][^<\r\n]{1,40})", art)
    credit = clean_inline(src_m.group(1)).strip() if src_m else "未检出"
    frag = div_fragment(art, r'<div[^>]*id="ContentBody"[^>]*>')
    if not frag:
        return fail(b, "PARSE_ERROR", "未找到 div#ContentBody 正文容器，疑似页面改版")
    b["issue"] = {
        "title": label, "page_title": page_title, "page_date": page_date,
        "published_at": published_at,
        "issue_label": label, "credit": credit, "article_id": aid,
        "discovery": "东方财富财经要闻页按页面顺序取第一条标题含「东方财富财经早餐」的链接",
        "note": "标题期号、页面发布时间、文章 ID 前缀分别如实标注，不推断三者之间的日期关系",
    }
    items, full_text, cov = split_article(frag, "em_breakfast")
    items = prune_guides(items, b)
    b["items"], b["full_text"] = items, full_text
    b["validation"]["coverage"] = cov["coverage"]
    b["validation"]["declared_count"] = cov["total_blocks"]
    issues = []
    if len(full_text) < 1000:
        issues.append("全文仅 %s 字符，疑似截断" % len(full_text))
    if cov["coverage"] < 0.999:
        issues.append("原文块覆盖率 %.4f，存在未归类段落" % cov["coverage"])
    if "每日精选" not in full_text:
        issues.append("未发现「每日精选」版块，疑似正文不完整")
    if not items:
        issues.append("条目切分结果为 0")
    if issues:
        return fail(b, "INCOMPLETE", "完整性校验未通过：" + "；".join(issues))
    b["status_detail"] = "取得最新一期全文 %s 字符，切分 %s 条，原文块覆盖率 %.1f%%" % (
        len(full_text), len(items), cov["coverage"] * 100)
    return finalize(b)


# --------------------------------------------------------------------------
# C. 百度热搜前 50
# --------------------------------------------------------------------------

def collect_baidu(args) -> dict:
    b = skeleton("baidu_hot")
    b["fidelity"]["source_omissions"] = [
        "置顶项不属榜单名次，单独记录在 pinned_item，不计入前 50",
        "榜单配图、跳转落地页正文与评论（源站榜单不提供，不补写）",
    ]
    try:
        page, st, nb, enc = fetch_retry(BAIDU_BOARD, timeout=args.timeout,
                                        retries=args.retries, interval=args.interval, tag="百度热搜")
    except Exception as e:
        return fail(b, "SOURCE_UNAVAILABLE", "百度热搜榜不可达：%s: %s" % (type(e).__name__, str(e)[:160]))
    b.update({"http_status": st, "bytes": nb, "encoding": enc})
    b["discovery"] = {
        "url": BAIDU_BOARD, "http_status": st, "bytes": nb,
        "marker": "<!--s-data:", "marker_hits": page.count("<!--s-data:"),
        "effective_timeout": effective_timeout(BAIDU_BOARD, args.timeout),
        "fallback_used": False, "fallback_status": "NOT_APPLICABLE",
        "note": "榜单页本身即当期具体页面，无需发现回退",
    }
    m = re.search(r"<!--s-data:(.*?)-->", page, re.S)
    if not m:
        return fail(b, "PARSE_ERROR", "未找到 <!--s-data:...--> 内嵌数据，疑似页面改版")
    try:
        data = json.loads(html.unescape(m.group(1)))
        card = data["data"]["cards"][0]
        content = card["content"]
    except Exception as e:
        return fail(b, "PARSE_ERROR", "内嵌数据解析失败：%s: %s" % (type(e).__name__, str(e)[:140]))
    ranked = [x for x in content if not x.get("isTop")]
    pinned = [x for x in content if x.get("isTop")]
    b["validation"]["declared_count"] = len(ranked)
    if len(ranked) < 50:
        return fail(b, "INCOMPLETE", "非置顶榜单条目仅 %s 条，不足 50 条" % len(ranked))
    if pinned:
        p = pinned[0]
        b["pinned_item"] = {"word": clean_inline(p.get("word", "")),
                            "hot_score": str(p.get("hotScore", "")),
                            "desc": clean_inline(p.get("desc", "")),
                            "note": "源站置顶项，不占榜单名次"}
    ts = card.get("updateTime")
    upd = "未检出"
    try:
        ts_num = int(ts)
        upd = datetime.fromtimestamp(ts_num, CN_TZ).isoformat(timespec="seconds")
    except (TypeError, ValueError, OSError, OverflowError):
        pass
    b["issue"] = {"board": "实时热搜榜", "source_update_time": upd,
                  "discovery": "top.baidu.com/board?tab=realtime 内嵌 s-data.cards[0].content",
                  "top_n": 50}
    items = []
    for i, x in enumerate(ranked[:50], 1):
        word = clean_inline(x.get("word", ""))
        desc = clean_inline(x.get("desc", ""))
        if not word:
            return fail(b, "INCOMPLETE", "第 %s 条榜单词为空" % i)
        items.append({
            "order": i, "title": word, "body": desc, "body_chars": len(desc),
            "section": "实时热搜榜",
            "meta": {"rank": i, "source_index": x.get("index"),
                     "hot_score": str(x.get("hotScore", "")),
                     "hot_tag": str(x.get("hotTag", "")),
                     "hot_change": str(x.get("hotChange", "")),
                     "url": x.get("rawUrl") or x.get("url") or "",
                     "source_update_time": upd},
        })
    b["items"] = items
    b["full_text"] = "\n".join("%s. %s｜热度 %s%s" % (
        x["order"], x["title"], x["meta"]["hot_score"],
        ("｜" + x["body"]) if x["body"] else "") for x in items)
    b["status_detail"] = "执行时刻快照取得前 50 条（源站非置顶 %s 条，置顶 %s 条单列）" % (
        len(ranked), len(pinned))
    return finalize(b)


# --------------------------------------------------------------------------
# 2026-11-09 v3.0.0：按需求取消「微博热搜前 50」采集环节。
# 原 collect_weibo() 实现、WEIBO_API 常量与 SOURCE_META 注册已整体移除；
# 本模块不再向 weibo.com 发起任何请求。历史核验记录保留在
# references/SOURCES_REALTIME.md 附录，仅供溯源，不参与运行。
# --------------------------------------------------------------------------

COLLECTORS = {"kr8": collect_kr8, "em_breakfast": collect_em,
             "baidu_hot": collect_baidu}


def snapshot_dir(root: str, sid: str) -> str:
    return os.path.join(root, ".cache", "snapshots", sid)


def save_snapshot(root: str, b: dict) -> None:
    d = snapshot_dir(root, b["source_id"])
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, now_cn().strftime("%Y%m%d-%H%M%S") + ".json")
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        json.dump(b, f, ensure_ascii=False, indent=2)


def load_stale(root: str, sid: str, max_age_hours: float = 48.0) -> dict | None:
    """v3.3.0：读缓存前先核对时间戳，超过硬上限一律拒用。

    借鉴 news-aggregator-skill-v2/MISTAKES.md「Stale Cache Hallucination」：
    曾把一个月前的 wallstreetcn_raw.json 当成当日数据写进报告。此处用文件名
    时间戳计算真实年龄，写入 bundle.snapshot，并把上限作为确定性参数暴露。
    """
    d = snapshot_dir(root, sid)
    if not os.path.isdir(d):
        return None
    fs = sorted([x for x in os.listdir(d) if x.endswith(".json")], reverse=True)
    if not fs:
        return None
    fname = fs[0]
    try:
        cap = datetime.strptime(fname[:-5], "%Y%m%d-%H%M%S").replace(tzinfo=CN_TZ)
    except ValueError:
        log("  %s 快照文件名无法解析时间戳，拒用：%s" % (sid, fname))
        return None
    age_h = (now_cn() - cap).total_seconds() / 3600.0
    if age_h < 0 or age_h > max_age_hours:
        log("  %s 快照 %.1f 小时前，超过上限 %.1f 小时，拒用：%s"
            % (sid, age_h, max_age_hours, fname))
        return None
    try:
        with open(os.path.join(d, fname), "r", encoding="utf-8") as f:
            b = json.load(f)
    except (OSError, ValueError):
        return None
    b["status"] = "STALE_SNAPSHOT"
    b["status_detail"] = ("源不可用，返回 %s 的历史快照（%.1f 小时前，非执行时刻实时数据）"
                           % (fname, age_h))
    b["snapshot"] = {
        "file": fname, "captured_at": cap.isoformat(timespec="seconds"),
        "age_hours": round(age_h, 2), "max_age_hours": max_age_hours,
        "timestamp_verified": True,
    }
    if not b.get("discovery"):
        # v3.2.0 及更早的快照没有发现入口探测字段。如实标注「未记录」，
        # 不从 issue.discovery 的中文描述反推 HTTP 状态、字节数等数值。
        b["discovery"] = {
            "url": "", "http_status": None, "bytes": 0,
            "marker": "", "marker_hits": None, "effective_timeout": None,
            "fallback_used": False, "fallback_status": "NOT_RECORDED_IN_OLD_SNAPSHOT",
            "note": "该快照由旧版采集器生成，未记录发现入口探测证据；本轮源不可用，未重新探测，不编造",
        }
    b["warnings"].append("该路为 %.1f 小时前的陈旧快照，不得表述为本次执行时刻的实时数据" % age_h)
    return finalize(b)


def collect_all(args) -> dict:
    ids = [args.only] if args.only else list(COLLECTORS)
    out = {}
    for sid in ids:
        log("采集 %s ..." % sid)
        b = COLLECTORS[sid](args)
        if b["status"] == "OK":
            save_snapshot(args.root, b)
        elif args.allow_stale:
            max_age = float(getattr(args, "stale_max_age_hours", 48) or 48)
            stale = load_stale(args.root, sid, max_age_hours=max_age)
            if stale:
                b = stale
        out[sid] = b
        log("  -> %s / %s 条" % (b["status"], b["item_count"]))
    return {
        "generated_at": iso_now(),
        "collector_version": "3.3.0",
        "host_timeouts": dict(HOST_TIMEOUTS),
        "stale_max_age_hours": float(getattr(args, "stale_max_age_hours", 48) or 48),
        "sources": out,
        "degraded": any(x["status"] not in ("OK", "STALE_SNAPSHOT") for x in out.values()),
    }


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass
    ap = argparse.ArgumentParser(description="Daily News for Yu 三路实时采集（微博热搜已于 v3.0.0 取消）")
    ap.add_argument("--only", choices=list(COLLECTORS), default="")
    ap.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    ap.add_argument("--out", default="", help="把汇总 JSON 写到该文件")
    ap.add_argument("--retries", type=int, default=2)
    ap.add_argument("--interval", type=float, default=3.0)
    ap.add_argument("--timeout", type=int, default=20)
    ap.add_argument("--verify-kr", action="store_true", help="36氪启用文章页双源逐字核对")
    ap.add_argument("--allow-stale", action="store_true", help="源不可用时允许返回历史快照并显式标注")
    ap.add_argument("--stale-max-age-hours", type=float, default=48.0,
                     help="快照最大可接受年龄（小时），默认 48；超限拒用，不冒充实时")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()
    if args.quiet:
        globals()["log"] = lambda m: None
    res = collect_all(args)
    payload = json.dumps(res, ensure_ascii=False, indent=2)
    if args.out:
        os.makedirs(os.path.dirname(args.out), exist_ok=True)
        with open(args.out, "w", encoding="utf-8", newline="\n") as f:
            f.write(payload)
    print(payload)
    return 0 if not res["degraded"] else 5


if __name__ == "__main__":
    sys.exit(main())
