#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《新闻联播》逐字稿提取器 (Daily News for Yu / fetch_xwlb.py)

设计约束（不可放宽）：
1. 零第三方依赖，仅用 Python 标准库，保证长期可运行。
2. 正文直接从源站原始 HTML 提取，逐字保留原文措辞与标点；
   不改写、不转述、不摘要、不补全、不臆造。
3. 源站未收录的内容（电头、片头片尾口播、逐条播出时间戳）
   一律留空并显式标注，绝不补写。
4. 任何异常均返回明确状态，items 为空，不以任何形式生成替代内容。

信息源：https://cn.govopendata.com/xinwenlianbo/YYYYMMDD/
官方核对页：https://tv.cctv.com/lm/xwlb/day/YYYYMMDD.shtml
核验记录见 references/SOURCE.md
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone

CN_TZ = timezone(timedelta(hours=8))
SCHEMA_VERSION = "1.0.0"
SOURCE_NAME = "公共数据开放平台 · 新闻联播文字版 (cn.govopendata.com)"
BASE_URL = "https://cn.govopendata.com/xinwenlianbo/"
OFFICIAL_DAY_TPL = "https://tv.cctv.com/lm/xwlb/day/{ymd}.shtml"
BROADCAST_WINDOW = "19:00-19:30"
MIN_BODY_CHARS = 10
DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36"
)
# 以脚本所在目录反推 skill 根目录：换电脑、换目录名后默认输出与缓存仍落在当前技能内
SKILL_HOME = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

STATUS_TEXT = {
    "OK": "完整获取，三重条数校验通过",
    "OK_FROM_CACHE": "命中本地缓存，缓存内容此前已通过完整性校验",
    "NOT_PUBLISHED": "目标播出日期的逐字稿尚未上线（源站返回 0 条）",
    "MISSING": "历史日期无稿件（源站返回 0 条），不重试",
    "INCOMPLETE": "稿件存在但内容不完整或条数不一致，已拒绝作为完整稿交付",
    "SOURCE_UNAVAILABLE": "信息源不可达、超时或被拒绝",
    "PARSE_ERROR": "页面结构发生变化，无法按既定规则解析",
    "INVALID_DATE": "输入日期非法或超出可解析范围",
}
EXIT_CODE = {
    "OK": 0, "OK_FROM_CACHE": 0, "NOT_PUBLISHED": 2, "MISSING": 3,
    "INCOMPLETE": 4, "SOURCE_UNAVAILABLE": 5, "PARSE_ERROR": 6, "INVALID_DATE": 7,
}

# 页面解析规则（2019–2026 抽样验证一致）
RE_ARTICLE = re.compile(r"<article\b[^>]*content-section[^>]*>(.*?)</article>", re.S | re.I)
RE_H2 = re.compile(r"<h2\b[^>]*>(.*?)</h2>", re.S | re.I)
RE_H2_ID = re.compile(r"<h2\b[^>]*\bid=[\"'](\d+)[\"']", re.I)
RE_BODY = re.compile(r"<div\b[^>]*content-body[^>]*>(.*?)</div>", re.S | re.I)
RE_P = re.compile(r"<p\b[^>]*>(.*?)</p>", re.S | re.I)
RE_TOC = re.compile(r"<li>\s*<a\s+href=[\"']#section-(\d+)[\"']", re.I)
RE_DECLARED = re.compile(r"收录当日\s*(\d+)\s*条新闻")
RE_DATE_LINK = re.compile(r"/xinwenlianbo/(\d{8})/")

STOP_NGRAMS = set("""
的 了 和 与 及 在 是 有 为 对 从 到 以 把 被 让 使 并 也 而 就 都 还 将 已 更 最 等 中 上 下 内 外 前 后
我们 你们 他们 这个 那个 这些 那些 表示 指出 强调 认为 显示 数据 今年 去年 今天 昨天 目前 同时 其中 通过
进行 实现 推动 加强 开展 提供 建设 发展 工作 有关 方面 情况 问题 以来 一周 一日 一个月 不断 持续 进一步
央视网 新闻联播 消息 记者 报道 编辑 责任 责任编辑 一是 二是 三是 以及 之一 之一 相关 各自 分别 共同
""".split())


def now_cn() -> datetime:
    return datetime.now(CN_TZ)


def iso_now() -> str:
    return now_cn().isoformat(timespec="seconds")


def log(msg: str) -> None:
    """运行日志走 stderr，保证 stdout 是纯 JSON。"""
    print("[xwlb] " + msg, file=sys.stderr, flush=True)


# --------------------------------------------------------------------------
# 网络与编码
# --------------------------------------------------------------------------

def fetch(url: str, timeout: int) -> tuple[str, int, int, str]:
    req = urllib.request.Request(url, headers={
        "User-Agent": DEFAULT_UA,
        "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        status = getattr(resp, "status", 200)
        ctype = resp.headers.get("Content-Type", "") or ""
    candidates: list[str] = []
    m = re.search(rb"charset\s*=\s*[\"']?([\w-]+)", raw[:2000], re.I)
    if not m:
        m = re.search(r"charset\s*=\s*[\"']?([\w-]+)", ctype, re.I)
        if m:
            candidates.append(m.group(1).lower())
    else:
        candidates.append(m.group(1).decode("ascii", "ignore").lower())
    candidates += ["utf-8", "gb18030"]
    used = "utf-8"
    for enc in dict.fromkeys(candidates):
        try:
            text = raw.decode(enc)
            used = enc
            break
        except (UnicodeDecodeError, LookupError):
            continue
    else:
        text = raw.decode("utf-8", "replace")
    return text, status, len(raw), used


def clean_text(fragment: str) -> str:
    """仅做透明的技术归一，不改动任何汉字与标点。"""
    s = re.sub(r"<script\b.*?</script>", "", fragment, flags=re.S | re.I)
    s = re.sub(r"<style\b.*?</style>", "", s, flags=re.S | re.I)
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", "", s)
    s = html.unescape(s)
    s = s.replace("\xa0", " ").replace("\u3000", " ")
    return s.strip()


# --------------------------------------------------------------------------
# 页面解析
# --------------------------------------------------------------------------

def parse_page(page: str, ymd: str) -> dict:
    declared_m = RE_DECLARED.search(page)
    declared = int(declared_m.group(1)) if declared_m else None
    toc_ids = RE_TOC.findall(page)
    raw_items = []
    for art in RE_ARTICLE.findall(page):
        h = RE_H2.search(art)
        b = RE_BODY.search(art)
        i = RE_H2_ID.search(art)
        title = clean_text(h.group(1)) if h else ""
        item_id = i.group(1) if i else ""
        paragraphs: list[str] = []
        empty_dropped = 0
        if b:
            blocks = RE_P.findall(b.group(1))
            if not blocks:
                blocks = [b.group(1)]
            for blk in blocks:
                t = clean_text(blk)
                if t:
                    paragraphs.append(t)
                else:
                    empty_dropped += 1
        body = "\n\n".join(paragraphs)
        raw_items.append({
            "title": title,
            "body": body,
            "paragraphs": paragraphs,
            "item_id": item_id,
            "empty_paragraphs_dropped": empty_dropped,
        })
    return {"declared": declared, "toc_ids": toc_ids, "raw_items": raw_items}


# --------------------------------------------------------------------------
# 条目划分 / 关键词（确定性派生分析，与原文严格分离）
# --------------------------------------------------------------------------

def classify(title: str) -> dict:
    t = title.strip()
    m = re.match(r"^【(.+?)】", t)
    if m:
        return {"type": "column", "label": m.group(1), "is_brief": False,
                "method": "标题【】专栏标识（规则）"}
    if "国内联播快讯" in t:
        return {"type": "domestic_brief", "label": "国内联播快讯", "is_brief": True,
                "method": "标题关键词（规则）"}
    if "国际联播快讯" in t:
        return {"type": "international_brief", "label": "国际联播快讯", "is_brief": True,
                "method": "标题关键词（规则）"}
    if t in ("联播快讯",) or "联播快讯" in t:
        return {"type": "brief", "label": "联播快讯", "is_brief": True,
                "method": "标题关键词（规则）"}
    if "央视快评" in t or "评论员文章" in t or "新华社长篇通讯" in t:
        return {"type": "commentary", "label": "评论/通讯", "is_brief": False,
                "method": "标题关键词（规则）"}
    return {"type": "regular", "label": "", "is_brief": False, "method": "默认归类（规则）"}


# 虚词单字：含这些字的候选片段一律丢弃，避免"面从严治""台人士表"类碎片
STOP_CHARS = set(
    "的了在是和与及为对从到以把被让使并也而就都还将已更最等上下内外前后"
    "们这那其之所由于且或但又再很太各每该本此些个①②③④⑤⑥⑦⑧⑨⑩"
)


def keywords(title: str, body: str, top_n: int) -> list[str]:
    """
    无词典关键词：字符 n-gram + 左右邻字多样性（成词度）过滤。
    完全确定性、零依赖；不是语义分词，不是原文，不得替代 body。
    """
    text = title + "。" + body
    chunks = re.findall(r"[\u4e00-\u9fff]+", text)
    title_grams: set[str] = set()
    for ch in re.findall(r"[\u4e00-\u9fff]+", title):
        for n in (2, 3, 4):
            for i in range(len(ch) - n + 1):
                title_grams.add(ch[i:i + n])

    counter: Counter[str] = Counter()
    left: dict[str, set[str]] = defaultdict(set)
    right: dict[str, set[str]] = defaultdict(set)
    for ch in chunks:
        for n in (2, 3, 4):
            for i in range(len(ch) - n + 1):
                g = ch[i:i + n]
                if g in STOP_NGRAMS or len(set(g)) == 1:
                    continue
                if any(c in STOP_CHARS for c in g):
                    continue
                counter[g] += 1
                left[g].add(ch[i - 1] if i > 0 else "#")
                right[g].add(ch[i + n] if i + n < len(ch) else "#")

    candidates: list[tuple[float, str, int]] = []
    for g, c in counter.items():
        if c < 2:
            continue
        ld, rd = len(left[g]), len(right[g])
        # 左右邻均需有 2 种以上不同字符，否则视为长词的切分碎片
        if min(ld, rd) < 2:
            continue
        score = c * (len(g) ** 0.6) * (1 + 0.3 * (ld + rd))
        if g in title_grams:
            score *= 3.0
        candidates.append((score, g, c))
    candidates.sort(reverse=True)

    picked: list[str] = []
    for _, g, _ in candidates:
        if any(g in p or p in g for p in picked):
            continue
        picked.append(g)
        if len(picked) >= top_n:
            break
    return picked


# --------------------------------------------------------------------------
# 结果骨架
# --------------------------------------------------------------------------

def skeleton(requested: str, resolved: str | None, status: str, detail: str) -> dict:
    ymd = (resolved or "").replace("-", "")
    return {
        "schema_version": SCHEMA_VERSION,
        "status": status,
        "status_text": STATUS_TEXT.get(status, ""),
        "status_detail": detail,
        "exit_code": EXIT_CODE.get(status, 1),
        "requested_date": requested,
        "resolved_date": resolved,
        "broadcast_window": BROADCAST_WINDOW,
        "broadcast_window_note": (
            "《新闻联播》CCTV-1 固定首播时段为 19:00-19:30；"
            "信息源按播出日期归档，不提供逐条播出时间戳，故不生成逐条时间。"
        ),
        "source": {
            "name": SOURCE_NAME,
            "url": BASE_URL + ymd + "/" if ymd else BASE_URL,
            "official_day_page": OFFICIAL_DAY_TPL.format(ymd=ymd) if ymd else "",
            "retrieved_at": iso_now(),
            "http_status": None,
            "bytes": 0,
            "encoding": "",
            "declared_item_count": None,
            "toc_item_count": None,
            "parsed_item_count": 0,
            "content_sha256": "",
        },
        "fidelity": {
            "verbatim_from_source": True,
            "no_rewrite": True,
            "no_summary_substitution": True,
            "source_omissions": [
                "央视网消息（新闻联播）：电头/栏目导语（信息源未收录，不补写）",
                "片头、片尾口播及主播串词（信息源未收录，不补写）",
                "逐条播出时间戳（信息源未提供，不推测）",
            ],
            "normalization": [
                "HTML 标签剥离", "HTML 实体解码",
                "不换行空格(U+00A0)/全角空格(U+3000) 归一为普通空格",
                "段落首尾空白去除", "多段落以两个换行连接",
            ],
            "crosscheck": (
                "2026-10-28 抽样：本源正文与央视网官方文稿正文 563 字符逐字一致（含标点），"
                "差异仅为官方电头被本源剥离。详见 references/SOURCE.md"
            ),
        },
        "validation": {
            "declared_equals_parsed": None,
            "toc_equals_parsed": None,
            "all_bodies_nonempty": None,
            "all_bodies_min_chars": MIN_BODY_CHARS,
            "issues": [],
        },
        "cache": {
            "enabled": False, "hit": False, "path": "", "fingerprint": "",
            "updated_at": "", "unchanged": False, "source_revised": False,
        },
        "dedup": {
            "mode": "mark", "duplicates_detected": 0, "duplicates_removed": 0,
            "method": "同页内 (标题,正文) 完全相同者标注 duplicate_of；默认不删除，避免破坏播报顺序",
        },
        "retry": {
            "attempts": [], "applied": False, "policy": "",
        },
        "analysis": {
            "level": "none", "generated_by": "deterministic",
            "is_verbatim": False,
            "notice": "分析字段为派生结果，与逐字原文严格分离，不得替代 body 字段",
        },
        "items": [],
        "item_count": 0,
        "warnings": [],
        "data_gaps": [],
    }


def fill_gaps(r: dict) -> None:
    gaps = [
        "信息源未收录电头『央视网消息（新闻联播）：』及片头片尾口播，未补写。",
        "信息源未提供逐条播出时间戳，仅提供 19:00-19:30 固定首播窗口，未推测。",
        "信息源未提供逐条对应的央视网官方原文链接；仅给出按日官方页面用于人工核对。",
        "主播、画面、字幕、配乐、时长等音视频要素不在文本源覆盖范围。",
    ]
    if r["status"] not in ("OK", "OK_FROM_CACHE"):
        gaps.insert(0, "本期未取得完整逐字稿，items 为空；未生成任何替代或补全内容。")
    if r["analysis"]["level"] == "none":
        gaps.append("本次未启用可选分析字段（--analysis none）。")
    if r["analysis"]["level"] in ("basic", "full"):
        gaps.append("关键词为字符 n-gram 词频结果，非语义分词；条目划分为标题规则归类，非官方分类。")
    if r["analysis"]["level"] == "full":
        gaps.append("key_points 待由上层模型填充；脚本不生成要点，避免以转述冒充原文。")
    r["data_gaps"] = gaps


# --------------------------------------------------------------------------
# 日期解析
# --------------------------------------------------------------------------

def resolve_date(spec: str, timeout: int) -> tuple[str | None, str, str]:
    """返回 (解析后日期, 错误信息, 提示信息)。提示信息不是错误。"""
    spec = (spec or "today").strip().lower()
    today = now_cn().date()
    if spec == "today":
        return today.isoformat(), "", ""
    if spec == "yesterday":
        return (today - timedelta(days=1)).isoformat(), "", ""
    if spec == "latest":
        try:
            page, _, _, _ = fetch(BASE_URL, timeout)
            ds = sorted(set(RE_DATE_LINK.findall(page)), reverse=True)
            if not ds:
                return None, "首页未发现任何日期归档链接，无法解析 latest", ""
            d = datetime.strptime(ds[0], "%Y%m%d").date()
            return d.isoformat(), "", "latest 解析自首页最新归档日期：" + ds[0]
        except Exception as e:
            return None, "latest 解析失败（首页不可达）：" + type(e).__name__ + ": " + str(e)[:120], ""
    s = re.sub(r"[/\.]", "-", spec.strip())
    m = re.fullmatch(r"(\d{4})-?(\d{2})-?(\d{2})", s)
    if not m:
        return None, "日期格式不支持：" + spec, ""
    try:
        d = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError as e:
        return None, "非法日期：" + str(e), ""
    if d > today + timedelta(days=1):
        return None, "日期超出可解析范围（不允许超过明日）：" + d.isoformat(), ""
    if d.year < 1990:
        return None, "日期过早，超出信息源归档范围：" + d.isoformat(), ""
    return d.isoformat(), "", ""


# --------------------------------------------------------------------------
# 缓存
# --------------------------------------------------------------------------

def cache_path(cache_dir: str, ymd: str) -> str:
    return os.path.join(cache_dir, ymd + ".json")


def fingerprint(items: list[dict]) -> str:
    payload = json.dumps(
        [(x["order"], x["title"], x["body"]) for x in items],
        ensure_ascii=False, separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def read_cache(path: str) -> dict | None:
    try:
        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if isinstance(obj, dict) and obj.get("status") in ("OK", "OK_FROM_CACHE") and obj.get("items"):
            return obj
    except (OSError, ValueError, TypeError):
        pass
    return None


def write_cache(path: str, result: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


# --------------------------------------------------------------------------
# 主流程（单次抓取）
# --------------------------------------------------------------------------

def run_once(args, resolved: str, requested: str) -> dict:
    ymd = resolved.replace("-", "")
    url = BASE_URL + ymd + "/"
    r = skeleton(requested, resolved, "OK", "")
    r["cache"]["enabled"] = not args.no_cache
    r["cache"]["path"] = cache_path(args.cache_dir, ymd) if not args.no_cache else ""
    r["dedup"]["mode"] = args.dedup
    r["analysis"]["level"] = args.analysis
    if args.analysis == "full":
        r["analysis"]["generated_by"] = "deterministic + model(待填充)"
    else:
        r["analysis"]["generated_by"] = "deterministic"

    if not args.no_cache and not args.force:
        cached = read_cache(r["cache"]["path"])
        if cached:
            cached["status"] = "OK_FROM_CACHE"
            cached["status_text"] = STATUS_TEXT["OK_FROM_CACHE"]
            cached["status_detail"] = "直接返回已通过完整性校验的本地缓存，未发起网络请求"
            cached["exit_code"] = 0
            cached.setdefault("cache", {})["hit"] = True
            cached["cache"]["path"] = r["cache"]["path"]
            cached["cache"]["enabled"] = True
            cached["cache"]["served_at"] = iso_now()
            cached.setdefault("retry", {})["attempts"] = [{"n": 1, "at": iso_now(),
                                                           "status": "OK_FROM_CACHE", "detail": "缓存命中"}]
            fill_gaps(cached)
            return cached

    if getattr(args, "html", ""):
        try:
            with open(args.html, "r", encoding="utf-8", errors="replace") as f:
                page = f.read()
            http_status, nbytes, enc = 200, len(page.encode("utf-8")), "utf-8(local-file)"
            r["source"]["url"] = os.path.abspath(args.html)
            r["warnings"].append("离线模式：从本地 HTML 解析，未访问网络；结果不代表源站当前状态")
        except OSError as e:
            r["status"] = "SOURCE_UNAVAILABLE"
            r["status_detail"] = "离线 HTML 读取失败：%s" % e
            r["items"] = []
            fill_gaps(r)
            return r
    else:
        try:
            page, http_status, nbytes, enc = fetch(url, args.timeout)
        except urllib.error.HTTPError as e:
            r["status"] = "SOURCE_UNAVAILABLE"
            r["status_detail"] = "源站返回 HTTP %s %s" % (e.code, e.reason)
            r["source"]["http_status"] = e.code
            r["source"]["retrieved_at"] = iso_now()
            r["items"] = []
            fill_gaps(r)
            return r
        except Exception as e:
            r["status"] = "SOURCE_UNAVAILABLE"
            r["status_detail"] = "%s: %s" % (type(e).__name__, str(e)[:200])
            r["source"]["retrieved_at"] = iso_now()
            r["items"] = []
            fill_gaps(r)
            return r

    r["source"].update({
        "http_status": http_status, "bytes": nbytes, "encoding": enc,
        "retrieved_at": iso_now(),
    })

    parsed = parse_page(page, ymd)
    declared, toc_ids, raw_items = parsed["declared"], parsed["toc_ids"], parsed["raw_items"]
    r["source"]["declared_item_count"] = declared
    r["source"]["toc_item_count"] = len(toc_ids)
    r["source"]["parsed_item_count"] = len(raw_items)

    if declared is None:
        r["status"] = "PARSE_ERROR"
        r["status_detail"] = "未找到 JSON-LD 声明条数，疑似页面结构改版；拒绝猜测内容"
        r["validation"]["issues"].append("缺少『收录当日 N 条新闻』声明")
        r["items"] = []
        fill_gaps(r)
        return r

    if declared == 0 and len(raw_items) == 0 and len(toc_ids) == 0:
        target = date.fromisoformat(resolved)
        today = now_cn().date()
        if target >= today:
            r["status"] = "NOT_PUBLISHED"
            r["status_detail"] = (
                "%s 期文字稿尚未上线（源站声明 0 条）。当日 19:00 首播、19:30 结束，"
                "文字稿通常于播出后上线；建议定时任务安排在 21:00 之后。" % resolved
            )
        else:
            r["status"] = "MISSING"
            r["status_detail"] = "%s 为历史日期，源站存档 0 条，判定为稿件缺失（不重试、不补写）" % resolved
        r["validation"].update({"declared_equals_parsed": True, "toc_equals_parsed": True,
                                "all_bodies_nonempty": None})
        r["items"] = []
        fill_gaps(r)
        return r

    items: list[dict] = []
    for idx, raw in enumerate(raw_items, 1):
        item = {
            "order": idx,                       # DOM 顺序 = 播报顺序
            "title": raw["title"],
            "body": raw["body"],                # 逐字原文，唯一权威正文
            "body_chars": len(raw["body"]),
            "paragraphs": raw["paragraphs"],
            "item_id": raw["item_id"],
            "anchor": (BASE_URL + ymd + "/#" + raw["item_id"]) if raw["item_id"] else "",
            "section": classify(raw["title"]) if args.analysis in ("basic", "full") else None,
            "analysis": None,
            "duplicate_of": None,
        }
        if args.analysis in ("basic", "full"):
            kw = keywords(raw["title"], raw["body"], args.keyword_count)
            a = {
                "keywords": kw,
                "keyword_status": "ok" if kw else "no_candidate",
                "keyword_method": "char-ngram + 左右邻成词度 (确定性，非语义分词，非原文)",
                "key_points": [],
                "key_points_pending": args.analysis == "full",
                "is_verbatim": False,
            }
            item["analysis"] = a
        items.append(item)

    # 完整性三重校验
    issues: list[str] = []
    deq = (declared == len(items))
    teq = (len(toc_ids) == len(items)) if toc_ids else None
    if not deq:
        issues.append("源站声明 %s 条，实际解析 %s 条" % (declared, len(items)))
    if teq is False:
        issues.append("页面目录 %s 条，实际解析 %s 条" % (len(toc_ids), len(items)))
    bodies_ok = True
    for it in items:
        if not it["title"]:
            issues.append("第 %s 条标题为空" % it["order"])
            bodies_ok = False
        if not it["body"]:
            issues.append("第 %s 条正文为空" % it["order"])
            bodies_ok = False
        elif len(it["body"]) < MIN_BODY_CHARS:
            issues.append("第 %s 条正文仅 %s 字符，疑似截断" % (it["order"], len(it["body"])))
            bodies_ok = False
    r["validation"].update({
        "declared_equals_parsed": deq,
        "toc_equals_parsed": teq,
        "all_bodies_nonempty": bodies_ok,
        "issues": issues,
    })

    # 去重：默认仅标注，不删除，避免破坏播报顺序与完整性
    seen: dict[tuple[str, str], int] = {}
    for it in items:
        k = (it["title"], it["body"])
        if args.dedup in ("mark", "drop") and k in seen:
            it["duplicate_of"] = seen[k]
            r["dedup"]["duplicates_detected"] += 1
        else:
            seen[k] = it["order"]
    if args.dedup == "drop" and r["dedup"]["duplicates_detected"]:
        removed = r["dedup"]["duplicates_detected"]
        items = [x for x in items if x["duplicate_of"] is None]
        r["dedup"]["duplicates_removed"] = removed
        issues.append("按 --dedup drop 移除 %s 条重复条目，与源站声明条数不再一致" % removed)
        r["warnings"].append("已启用强制去重，播报顺序编号保留原值、不重排")

    if issues:
        r["status"] = "INCOMPLETE"
        r["status_detail"] = "完整性校验未通过：" + "；".join(issues[:6])
        r["items"] = []          # 关键：不完整则不交付任何正文，防止残缺稿被当作完整稿
        r["item_count"] = 0
        fill_gaps(r)
        return r

    r["items"] = items
    r["item_count"] = len(items)
    r["status"] = "OK"
    r["status_detail"] = "完整获取 %s 条，声明/目录/解析三重条数一致，正文逐字保留" % len(items)
    fp = fingerprint(items)
    r["source"]["content_sha256"] = fp
    r["cache"]["fingerprint"] = fp

    # 缓存写入：仅完整稿入缓存
    if not args.no_cache:
        cp = r["cache"]["path"]
        old = read_cache(cp)
        if old:
            old_fp = old.get("cache", {}).get("fingerprint", "")
            if old_fp and old_fp != fp:
                r["cache"]["source_revised"] = True
                r["warnings"].append("源站内容较缓存发生变化，已更新缓存并保留旧版本")
                try:
                    bak = cp.replace(".json", "." + now_cn().strftime("%Y%m%d%H%M%S") + ".bak.json")
                    os.replace(cp, bak)
                except OSError:
                    pass
            elif old_fp == fp:
                r["cache"]["unchanged"] = True
        if not r["cache"]["unchanged"] or not os.path.exists(cp):
            write_cache(cp, json.loads(json.dumps(r, ensure_ascii=False)))
        r["cache"]["updated_at"] = iso_now()

    fill_gaps(r)
    return r


# --------------------------------------------------------------------------
# 重试策略
# --------------------------------------------------------------------------

def should_retry(status: str, resolved: str | None, attempt: int, max_attempts: int) -> tuple[bool, str]:
    if attempt >= max_attempts:
        return False, "已达最大尝试次数 %s" % max_attempts
    if status in ("SOURCE_UNAVAILABLE", "PARSE_ERROR"):
        return True, "临时性访问/解析异常，可重试"
    if status == "NOT_PUBLISHED":
        if not resolved:
            return False, "日期未解析，不重试"
        target = date.fromisoformat(resolved)
        today = now_cn().date()
        if target > today:
            return False, "未来日期，无需重试"
        n = now_cn()
        if target == today and (n.hour * 60 + n.minute) < 19 * 60 + 30:
            return False, "当日 19:30 前节目尚未播完，此时重试无意义；建议 21:00 后运行或加 --wait"
        return True, "已过首播时段但文字稿未上线，按退避策略重试"
    return False, "状态 %s 不适用自动重试" % status


# --------------------------------------------------------------------------
# Markdown 输出
# --------------------------------------------------------------------------

def to_markdown(r: dict) -> str:
    L: list[str] = []
    d = r["resolved_date"] or r["requested_date"]
    L.append("# 《新闻联播》逐字稿 · %s" % d)
    L.append("")
    L.append("- 状态：`%s` — %s" % (r["status"], r["status_text"]))
    L.append("- 说明：%s" % r["status_detail"])
    L.append("- 首播时段：%s（%s）" % (r["broadcast_window"], r["broadcast_window_note"]))
    L.append("- 信息源：%s" % r["source"]["url"])
    L.append("- 官方按日核对页：%s" % (r["source"]["official_day_page"] or "不适用"))
    L.append("- 原始抓取时间：%s" % r["source"]["retrieved_at"])
    if r["cache"].get("served_at"):
        L.append("- 本次读取时间：%s（缓存命中，未发起网络请求）" % r["cache"]["served_at"])
    L.append("- 校验：声明 %s 条 / 目录 %s 条 / 解析 %s 条" % (
        r["source"]["declared_item_count"], r["source"]["toc_item_count"],
        r["source"]["parsed_item_count"]))
    L.append("- 缓存：%s；去重：检出 %s 条、移除 %s 条" % (
        "命中" if r["cache"]["hit"] else "未命中",
        r["dedup"]["duplicates_detected"], r["dedup"]["duplicates_removed"]))
    L.append("")
    L.append("> 正文字段 `body` 为源站原文逐字提取，未改写、未转述、未摘要。"
             "分析字段（若有）为派生结果，不替代原文。")
    L.append("")

    if r["items"]:
        L.append("## 本期目录（%s 条，按播报顺序）" % r["item_count"])
        L.append("")
        for it in r["items"]:
            L.append("%s. %s" % (it["order"], it["title"]))
        L.append("")
        L.append("## 逐字正文")
        L.append("")
        for it in r["items"]:
            L.append("### %s. %s" % (it["order"], it["title"]))
            L.append("")
            L.append(it["body"])
            L.append("")
            meta = ["条目 ID `%s`" % it["item_id"] if it["item_id"] else "条目 ID 未提供",
                    "正文 %s 字" % it["body_chars"]]
            if it["section"]:
                meta.append("归类 `%s`" % it["section"]["type"])
            if it["analysis"] and it["analysis"]["keywords"]:
                meta.append("关键词（n-gram 成词度，非原文）：" + "、".join(it["analysis"]["keywords"]))
            elif it["analysis"] and it["analysis"].get("keyword_status") == "no_candidate":
                meta.append("关键词：未检出（短文本无合格候选，不编造）")
            if it["duplicate_of"]:
                meta.append("与第 %s 条完全重复" % it["duplicate_of"])
            L.append("*%s*" % "；".join(meta))
            L.append("")
    else:
        L.append("## 逐字正文")
        L.append("")
        L.append("本次未取得完整逐字稿，按约束不输出任何正文、不生成替代内容。")
        L.append("")
        if r["retry"]["attempts"]:
            L.append("### 尝试记录")
            L.append("")
            for a in r["retry"]["attempts"]:
                L.append("- 第 %s 次（%s）：`%s` — %s" % (a["n"], a["at"], a["status"], a["detail"]))
            L.append("")

    L.append("## 校验与溯源")
    L.append("")
    L.append("| 项目 | 值 |")
    L.append("| --- | --- |")
    L.append("| 声明条数 = 解析条数 | %s |" % r["validation"]["declared_equals_parsed"])
    L.append("| 目录条数 = 解析条数 | %s |" % r["validation"]["toc_equals_parsed"])
    L.append("| 正文非空 | %s |" % r["validation"]["all_bodies_nonempty"])
    L.append("| 正文最小字符数阈值 | %s |" % r["validation"]["all_bodies_min_chars"])
    L.append("| 内容指纹 SHA-256 | `%s` |" % (r["source"]["content_sha256"] or "无"))
    L.append("| 逐字保留 | %s |" % r["fidelity"]["verbatim_from_source"])
    L.append("| 转述/摘要替代 | %s |" % (not r["fidelity"]["no_summary_substitution"]))
    L.append("")
    if r["validation"]["issues"]:
        L.append("校验问题：")
        L.append("")
        for x in r["validation"]["issues"]:
            L.append("- %s" % x)
        L.append("")
    L.append("原文口径说明：%s" % r["fidelity"]["crosscheck"])
    L.append("")
    L.append("技术归一（不改汉字与标点）：%s。" % "；".join(r["fidelity"]["normalization"]))
    L.append("")

    L.append("## 未覆盖 / 数据缺口")
    L.append("")
    for g in r["data_gaps"]:
        L.append("- %s" % g)
    L.append("")
    return "\n".join(L)


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="《新闻联播》逐字稿提取器：逐字原文 + 结构化输出 + 明确异常状态",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""示例：
  python fetch_xwlb.py --date 2026-11-08
  python fetch_xwlb.py --date latest --format both
  python fetch_xwlb.py --date today --wait --max-wait 7200
  python fetch_xwlb.py --date 2026-11-08 --analysis full --format json
退出码：0 完整/缓存命中，2 未发布，3 历史缺失，4 不完整，5 源不可用，6 解析失败，7 日期非法
""",
    )
    ap.add_argument("--date", default="today",
                    help="today | yesterday | latest | YYYY-MM-DD | YYYYMMDD（默认 today）")
    ap.add_argument("--out", default=os.path.join(SKILL_HOME, "output"),
                    help="输出目录（默认 skill 目录下 output/）")
    ap.add_argument("--cache-dir", default=os.path.join(SKILL_HOME, ".cache"),
                    help="缓存目录")
    ap.add_argument("--format", choices=["json", "md", "both"], default="both",
                    help="输出格式（默认 both）")
    ap.add_argument("--analysis", choices=["none", "basic", "full"], default="basic",
                    help="可选分析字段：none 仅原文；basic 加条目划分+词频关键词；full 预留要点（默认 basic）")
    ap.add_argument("--keyword-count", type=int, default=8, help="每条关键词数量（默认 8）")
    ap.add_argument("--dedup", choices=["mark", "drop", "off"], default="mark",
                    help="重复条目策略：mark 仅标注（默认，不破坏完整性）；drop 删除并降级为 INCOMPLETE；off 不检测")
    ap.add_argument("--retries", type=int, default=2, help="最大重试次数（默认 2）")
    ap.add_argument("--interval", type=float, default=20.0, help="重试基础间隔秒（默认 20）")
    ap.add_argument("--max-interval", type=float, default=600.0, help="单次重试最大间隔秒（默认 600）")
    ap.add_argument("--wait", action="store_true",
                    help="长等待模式：自动把重试次数提高到 12、间隔提高到 300 秒（若未显式指定）")
    ap.add_argument("--max-wait", type=float, default=7200.0, help="长等待模式总时长上限秒（默认 7200）")
    ap.add_argument("--timeout", type=int, default=25, help="单次 HTTP 超时秒（默认 25）")
    ap.add_argument("--force", action="store_true", help="忽略缓存强制重抓")
    ap.add_argument("--no-cache", action="store_true", help="不读不写缓存")
    ap.add_argument("--stdout-json", action="store_true",
                    help="无论 --format 为何，均把完整 JSON 打印到 stdout（默认仅 --format=json/both 时打印）")
    ap.add_argument("--html", default="",
                    help="离线诊断：从本地 HTML 文件解析而非联网（用于回归测试与页面存档复核）")
    ap.add_argument("--quiet", action="store_true", help="抑制 stderr 日志")
    return ap


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass
    args = build_parser().parse_args()
    if args.quiet:
        globals()["log"] = lambda m: None
    if args.wait:
        if args.retries == 2:
            args.retries = 12
        if args.interval == 20.0:
            args.interval = 300.0
    requested = args.date
    resolved, err, note = resolve_date(requested, args.timeout)
    r = skeleton(requested, resolved, "OK", "")
    if note:
        r["warnings"].append(note)
    r["cache"]["enabled"] = not args.no_cache
    r["dedup"]["mode"] = args.dedup
    r["analysis"]["level"] = args.analysis

    if err or not resolved:
        r["status"] = "SOURCE_UNAVAILABLE" if "latest" in requested.lower() else "INVALID_DATE"
        r["status_text"] = STATUS_TEXT[r["status"]]
        r["status_detail"] = err or "日期解析失败"
        r["exit_code"] = EXIT_CODE[r["status"]]
        r["items"] = []
        fill_gaps(r)
        result = r
    else:
        total_start = time.monotonic()
        attempt = 0
        result = None
        while True:
            attempt += 1
            cur = run_once(args, resolved, requested)
            at = iso_now()
            st = cur["status"]
            detail = cur["status_detail"]
            log("第 %s 次尝试：%s — %s" % (attempt, st, detail[:110]))
            if st in ("OK", "OK_FROM_CACHE", "MISSING", "INCOMPLETE", "INVALID_DATE"):
                _, why = should_retry(st, resolved, attempt, args.retries + 1)
                cur["retry"]["attempts"].append({
                    "n": attempt, "at": at, "status": st,
                    "detail": "终止（%s）：%s" % (why, detail[:110]),
                })
                cur["retry"]["policy"] = "仅 SOURCE_UNAVAILABLE / PARSE_ERROR / 已过首播时段的 NOT_PUBLISHED 重试"
                result = cur
                break
            retry, reason = should_retry(st, resolved, attempt, args.retries + 1)
            cur["retry"]["attempts"].append({"n": attempt, "at": at, "status": st,
                                             "detail": reason})
            if not retry:
                cur["retry"]["policy"] = reason
                result = cur
                break
            delay = min(args.interval * (1.5 ** (attempt - 1)), args.max_interval)
            if args.wait and (time.monotonic() - total_start + delay) > args.max_wait:
                cur["retry"]["policy"] = "达到 --max-wait 总时长上限，停止重试"
                cur["retry"]["attempts"][-1]["detail"] += "；达到总时长上限，停止"
                result = cur
                break
            cur["retry"]["applied"] = True
            log("等待 %.1f 秒后重试（%s）" % (delay, reason))
            time.sleep(delay)
            # 下一轮重新组装 attempts
            if result is None:
                pending = cur["retry"]["attempts"]
                args._pending_attempts = getattr(args, "_pending_attempts", []) + pending
        if result is None:
            result = r
        # 汇总全部尝试记录
        if hasattr(args, "_pending_attempts"):
            merged = args._pending_attempts + result["retry"]["attempts"]
            seen = set()
            uniq = []
            for a in merged:
                k = (a["n"], a["at"], a["status"])
                if k not in seen:
                    seen.add(k)
                    uniq.append(a)
            result["retry"]["attempts"] = uniq
        if result["retry"]["applied"] is False and len(result["retry"]["attempts"]) > 1:
            result["retry"]["applied"] = True

    # 最终状态与退出码必须以实际状态为准，避免骨架默认值(0)泄漏
    result["exit_code"] = EXIT_CODE.get(result["status"], 1)
    result["status_text"] = STATUS_TEXT.get(result["status"], "")
    if note and note not in result.get("warnings", []):
        result.setdefault("warnings", []).append(note)

    # 输出
    ymd = (result["resolved_date"] or now_cn().date().isoformat()).replace("-", "")
    os.makedirs(args.out, exist_ok=True)
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.format in ("json", "both"):
        with open(os.path.join(args.out, ymd + ".json"), "w", encoding="utf-8", newline="\n") as f:
            f.write(payload)
    if args.format in ("md", "both"):
        with open(os.path.join(args.out, ymd + ".md"), "w", encoding="utf-8", newline="\n") as f:
            f.write(to_markdown(result))
    if args.stdout_json or args.format in ("json", "both"):
        print(payload)

    log("状态=%s 条目=%s 退出码=%s 输出目录=%s" % (
        result["status"], result["item_count"], result["exit_code"], args.out))
    return result["exit_code"]


if __name__ == "__main__":
    sys.exit(main())
