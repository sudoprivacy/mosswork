#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Daily News for Yu — 跨天重复新闻识别 (cross_day.py)

v3.3.0 新增，**默认关闭**（--cross-day-dedup 显式开启）。

借鉴来源：SkillHub @user_15292d5a/yjkj-news-digest
  scripts/news_digest_v2/cross_day_dedup.py::_compute_cross_day_similarity
  scripts/news_digest_v2/config.py:
      CROSS_DAY_HISTORY_DAYS = 3
      CROSS_DAY_THRESHOLD = 0.75      # 拦截
      CROSS_DAY_WARN_THRESHOLD = 0.60 # 警告但保留
  核心三条硬规则原样沿用：
      1 标题清洗后完全一致 -> 1.0（拦截）
      2 候选标题出现在历史摘要 -> 1.0（拦截）
      3 双方都有显著数字且不共享 -> 0.0（放行，覆盖每月 PMI/CPI 等周期性新闻）
  综合分 = 0.5*标题Jaccard + 0.25*数字匹配 + 0.25*内容词重叠（无数字时 0.5+0.5）

与本技能既有约束的边界：
  * 历史来源不是数据库，而是本技能自己产出的 output/daily/entries-*.json，零新依赖。
  * 只比较**整合后条目**，不改逐字原文；命中拦截的条目整条剔除并记录审计，可复核。
  * 默认关闭：本技能默认「不遗漏任何独立新闻点」，跨天去重属于用户可选的额外能力。
  * 开启后 HTML 版面不变（仍为两部分），仅条目数减少并重排序号。
"""

from __future__ import annotations

import glob
import json
import os
import re
from datetime import date, datetime, timedelta, timezone

CN_TZ = timezone(timedelta(hours=8))

HISTORY_DAYS = 3
BLOCK_THRESHOLD = 0.75
WARN_THRESHOLD = 0.60


# --------------------------------------------------------------------------
# 与原实现同口径的清洗与特征
# --------------------------------------------------------------------------

def clean_title(title: str) -> str:
    if not title:
        return ""
    title = re.sub(r"[【】\[\]（）()\u201c\u201d\u2018\u2019\"']", "", title)
    title = re.sub(r"[\u00b7\u3001\uff0c\u3002\uff1a\uff1b\s\u2014]+", " ", title)
    return title.strip().lower()


def significant_numbers(text: str) -> set[str]:
    if not text:
        return set()
    nums = re.findall(r"\d+\.?\d*", text)
    return {n for n in nums if len(n) >= 3 or "." in n}


def content_words(text: str) -> set[str]:
    if not text:
        return set()
    return set(re.findall(r"[\u4e00-\u9fa5]{2,}", text))


def cross_day_similarity(candidate: dict, history_item: dict) -> float:
    """返回 0.0-1.0。阈值与硬规则见模块说明。"""
    c_title_raw = candidate.get("title", "") or ""
    h_title_raw = history_item.get("title", "") or ""
    c_summary = candidate.get("summary", "") or ""
    h_summary = history_item.get("summary", "") or ""

    c_clean, h_clean = clean_title(c_title_raw), clean_title(h_title_raw)

    # 硬规则 1：标题完全一致
    if c_clean and c_clean == h_clean:
        return 1.0

    # 硬规则 2：候选标题嵌入历史摘要
    bare = re.sub(r"[\s\u00b7\u3001\uff0c\u3002\uff1a\uff1b\u2014\u201c\u201d\u2018\u2019"
                  r"【】\[\]（）()\"]", "", c_title_raw)
    if bare and len(bare) >= 8 and bare in h_summary:
        return 1.0

    # 硬规则 3：数字差异化
    c_text = c_title_raw + " " + c_summary
    h_text = h_title_raw + " " + h_summary
    c_nums, h_nums = significant_numbers(c_text), significant_numbers(h_text)
    shared = c_nums & h_nums
    if c_nums and h_nums and not shared:
        return 0.0

    if not c_clean or not h_clean:
        return 0.0
    cw, hw = set(c_clean.split()), set(h_clean.split())
    union = cw | hw
    title_sim = len(cw & hw) / len(union) if union else 0.0

    num_sim = 0.0
    if shared:
        num_sim = len(shared) / min(len(c_nums), len(h_nums))

    ckw, hkw = content_words(c_summary), content_words(h_summary)
    kw_sim = 0.0
    if ckw and hkw:
        u = ckw | hkw
        kw_sim = len(ckw & hkw) / len(u) if u else 0.0

    if not c_nums and not h_nums:
        score = 0.5 * title_sim + 0.5 * kw_sim
    else:
        score = 0.5 * title_sim + 0.25 * num_sim + 0.25 * kw_sim
    return min(1.0, score)


# --------------------------------------------------------------------------
# 历史：复用本技能自己产出的 entries-*.json，不引入数据库
# --------------------------------------------------------------------------

def load_history(out_dir: str, days: int = HISTORY_DAYS,
                 today: date | None = None) -> tuple[list[dict], list[str]]:
    today = today or datetime.now(CN_TZ).date()
    lower = today - timedelta(days=days)
    history, files, errors = [], [], []
    for p in sorted(glob.glob(os.path.join(out_dir, "entries-*.json"))):
        try:
            with open(p, "r", encoding="utf-8") as f:
                d = json.load(f)
            raw = (d.get("today") or d.get("generated_at") or "")[:10]
            d0 = date.fromisoformat(raw) if raw else None
            if d0 is None or d0 < lower or d0 >= today:
                continue
            files.append(os.path.basename(p))
            for e in d.get("entries", []):
                history.append({
                    "title": e.get("lead", ""),
                    "summary": " ".join(e.get("points", [])),
                    "date": d0.isoformat(),
                    "rank": e.get("rank", 0),
                    "file": os.path.basename(p),
                })
        except (OSError, ValueError, TypeError) as ex:
            errors.append("%s: %s" % (os.path.basename(p), type(ex).__name__))
    return history, files + errors


def apply(result: dict, history: list[dict], enabled: bool = False,
          history_days: int = HISTORY_DAYS) -> dict:
    """按跨天阈值拦截 / 警告；完成后重排序号并写 cross_day_audit。"""
    audit = {
        "enabled": bool(enabled),
        "history_days": history_days,
        "block_threshold": BLOCK_THRESHOLD,
        "warn_threshold": WARN_THRESHOLD,
        "history_items": len(history),
        "blocked": [], "warned": [],
        "blocked_count": 0, "warned_kept_count": 0,
        "status": "DISABLED" if not enabled else "NO_HISTORY",
    }
    if not enabled:
        result["cross_day_audit"] = audit
        return result
    if not history:
        result["cross_day_audit"] = audit
        return result

    audit["status"] = "APPLIED"
    kept = []
    for e in result.get("entries", []):
        c = {"title": e.get("lead", ""), "summary": " ".join(e.get("points", []))}
        best, matched = 0.0, None
        for h in history:
            s = cross_day_similarity(c, h)
            if s > best:
                best, matched = s, h
        row = {"rank_before": e.get("rank"), "lead": c["title"][:90],
               "similarity": round(best, 4)}
        if best >= BLOCK_THRESHOLD:
            row.update({"matched_date": (matched or {}).get("date", ""),
                        "matched_title": (matched or {}).get("title", "")[:90]})
            audit["blocked"].append(row)
            continue
        if best >= WARN_THRESHOLD:
            row["matched_date"] = (matched or {}).get("date", "")
            audit["warned"].append(row)
        kept.append(e)

    for i, e in enumerate(kept, 1):
        e["rank"] = i
    result["entries"] = kept
    result["entry_count"] = len(kept)
    audit["blocked_count"] = len(audit["blocked"])
    audit["warned_kept_count"] = len(audit["warned"])
    result["cross_day_audit"] = audit
    return result
