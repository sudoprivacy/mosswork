#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Daily News for Yu — 一键编排入口 (news_daily.py)

v3.0.0（2026-11-09）：取消微博热搜采集；取消分类；统一整合全部已采集条目后
仅按重要性排序。
v3.1.0（2026-11-09）：第一部分四个 URL 改为动态取得的当期具体页面
（36氪 / 东财为具体文章页，联播为当期按日页）。
v3.2.0（2026-11-09）：按需求撤销 v3.1.0 新增的「汇总梗概」，
HTML 恢复「源站 / 新闻」两部分；具体页面 URL 口径保留。
v3.3.0（2026-11-10）：借鉴 SkillHub 同类技能，新增逐源质量闸、coverage
一等公民、逐字自校验证据包、快照时效硬上限、按站点差异化超时，以及
默认关闭的可选跨天去重；全部新增字段只进入机器可读 JSON，HTML 版面不变。

执行流程：
  1. 三路实时采集（36氪 8点1氪 / 东方财富早餐 / 百度热搜前50）
  2. 载入《新闻联播》逐字稿（优先联网取最近一期已发布，失败则回退本地已有稿）
  3. 合并同类及信息关联相近条目，生成抽取式整合要点；按新闻学重要性评分排序
  4. 生成单篇两部分 HTML 新闻日报 + 汇总 JSON + 整合审计 JSON

零第三方依赖，仅 Python 标准库。
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import subprocess
import sys
from argparse import Namespace
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_daily as bd          # noqa: E402
import collect_sources as cs      # noqa: E402
import editorial as ed            # noqa: E402
import quality_gates as qg        # noqa: E402  v3.3.0
import cross_day as xd            # noqa: E402  v3.3.0

CN_TZ = timezone(timedelta(hours=8))
XWLB_SCRIPT = os.path.join(HERE, "fetch_xwlb.py")


def log(msg: str) -> None:
    print("[news-daily] " + msg, file=sys.stderr, flush=True)


def iso_now() -> str:
    return datetime.now(CN_TZ).isoformat(timespec="seconds")


# --------------------------------------------------------------------------
# 《新闻联播》已有内容 -> 统一 bundle
# --------------------------------------------------------------------------

def xwlb_to_bundle(d: dict, note: str = "") -> dict:
    st = d.get("status", "SOURCE_UNAVAILABLE")
    ok = st in ("OK", "OK_FROM_CACHE")
    src = d.get("source", {})
    items = []
    for it in d.get("items", []):
        sec = it.get("section") or {}
        items.append({
            "order": it.get("order", 0),
            "title": it.get("title", ""),
            "body": it.get("body", ""),
            "body_chars": it.get("body_chars", len(it.get("body", ""))),
            "section": sec.get("type", "") if isinstance(sec, dict) else "",
            "meta": {"item_id": it.get("item_id", ""), "anchor": it.get("anchor", ""),
                     "source_section": sec.get("label", "") if isinstance(sec, dict) else ""},
        })
    full = "\n".join("%s. %s\n%s" % (x["order"], x["title"], x["body"]) for x in items)
    return {
        "source_id": "xwlb",
        "display_name": "《新闻联播》逐字稿",
        "status": "OK" if ok else st,
        "status_text": d.get("status_text", ""),
        "status_detail": (note + "｜" if note else "") + d.get("status_detail", ""),
        "exit_code": 0 if ok else d.get("exit_code", 5),
        "retrieved_at": src.get("retrieved_at", iso_now()),
        "source_url": src.get("url", ""),
        "official_reference": src.get("official_day_page", ""),
        "http_status": src.get("http_status"),
        "bytes": src.get("bytes", 0),
        "encoding": src.get("encoding", ""),
        "issue": {
            "broadcast_date": d.get("resolved_date") or "未检出",
            "window": d.get("broadcast_window", "19:00-19:30"),
            "item_count": d.get("item_count", 0),
            "note": note or "按最近一期已发布稿；当日 19:00 首播前调用时，最新一期为前一播出日",
        },
        "fidelity": d.get("fidelity", {}),
        "validation": d.get("validation", {}),
        "items": items if ok else [],
        "item_count": len(items) if ok else 0,
        "full_text": full if ok else "",
        "full_text_chars": len(full) if ok else 0,
        "content_sha256": src.get("content_sha256", ""),
        "pinned_item": None,
        "crosscheck": {"note": d.get("fidelity", {}).get("crosscheck", "")},
        "warnings": list(d.get("warnings", [])),
        "data_gaps": list(d.get("data_gaps", [])),
    }


def fetch_xwlb_online(args) -> dict | None:
    cmd = [sys.executable, XWLB_SCRIPT, "--date", "latest",
           "--no-cache", "--format", "json", "--quiet", "--retries", "0"]
    try:
        cp = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                            timeout=max(60, args.timeout * 3))
        if cp.stdout.strip().startswith("{"):
            return json.loads(cp.stdout)
    except (subprocess.SubprocessError, ValueError, OSError) as e:
        log("新闻联播联网取数失败：%s" % type(e).__name__)
    return None


def load_local_xwlb(root: str) -> dict | None:
    pat = os.path.join(root, "output", "[0-9]" * 8 + ".json")
    for p in sorted(glob.glob(pat), reverse=True):
        try:
            with open(p, "r", encoding="utf-8") as f:
                d = json.load(f)
            if d.get("status") in ("OK", "OK_FROM_CACHE") and d.get("items"):
                return d
        except (OSError, ValueError):
            continue
    return None


def get_xwlb_bundle(args) -> dict:
    if args.skip_xwlb:
        return {"source_id": "xwlb", "display_name": "《新闻联播》逐字稿",
                "status": "SOURCE_UNAVAILABLE", "status_detail": "本次按 --skip-xwlb 跳过",
                "items": [], "item_count": 0, "data_gaps": ["本次跳过了《新闻联播》一路"],
                "validation": {}, "fidelity": {}, "issue": {}, "warnings": []}
    online = fetch_xwlb_online(args)
    if online and online.get("status") in ("OK", "OK_FROM_CACHE"):
        note = ("联网取最近一期已发布稿（%s）；本次执行日 %s 的当日稿在 19:00 首播前不可用"
                % (online.get("resolved_date"), args.date))
        return xwlb_to_bundle(online, note)
    local = load_local_xwlb(args.root)
    if local:
        return xwlb_to_bundle(local, "联网取数不可用，回退到本地已有稿件（标注为非本次实时抓取）")
    if online:
        return xwlb_to_bundle(online, "联网取数未取得完整稿")
    return {"source_id": "xwlb", "display_name": "《新闻联播》逐字稿",
            "status": "SOURCE_UNAVAILABLE", "status_detail": "联网与本地均无可用的完整逐字稿",
            "items": [], "item_count": 0, "data_gaps": ["《新闻联播》一路无任何可用稿件"],
            "validation": {}, "fidelity": {}, "issue": {}, "warnings": []}


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------

def merge_gaps(bundles: dict) -> list[str]:
    """只汇总各源真实缺口，供机器可读 JSON 使用；按需求不进入 HTML 版面。"""
    gaps = []
    for sid in bd.SOURCE_ORDER:
        b = bundles.get(sid) or {}
        for g in b.get("data_gaps", []):
            g = g.strip()
            if g and g not in gaps:
                gaps.append("[%s] %s" % (bd.SOURCE_SHORT.get(sid, sid), g))
    return gaps


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass
    ap = argparse.ArgumentParser(description="Daily News for Yu — 一键生成 HTML 新闻日报")
    ap.add_argument("--date", default=datetime.now(CN_TZ).date().isoformat(),
                    help="日报日期 YYYY-MM-DD（默认今天，仅用于命名与期号说明）")
    ap.add_argument("--root", default=os.path.dirname(HERE))
    ap.add_argument("--out", default="", help="日报输出目录（默认 <skill>/output/daily）")
    ap.add_argument("--retries", type=int, default=2)
    ap.add_argument("--interval", type=float, default=3.0)
    ap.add_argument("--timeout", type=int, default=20)
    ap.add_argument("--verify-kr", action="store_true", help="36氪启用 RSS 与文章页双源逐字核对")
    ap.add_argument("--allow-stale", action="store_true", help="源不可用时允许返回历史快照并显式标注（默认关闭）")
    ap.add_argument("--skip-xwlb", action="store_true", help="调试用：跳过《新闻联播》一路")
    ap.add_argument("--strict", action="store_true", help="任一路降级即返回非零退出码")
    ap.add_argument("--stale-max-age-hours", type=float, default=48.0,
                     help="陈旧快照最大可接受年龄（小时），默认 48；超限拒用")
    ap.add_argument("--cross-day-dedup", action="store_true",
                     help="可选：对最近 N 天已发布条目做跨天去重（默认关闭，保证不遗漏独立新闻点）")
    ap.add_argument("--cross-day-days", type=int, default=3,
                     help="跨天去重历史窗口天数，默认 3")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()
    if args.quiet:
        globals()["log"] = lambda m: None
        cs.log = lambda m: None
    args.out = args.out or os.path.join(args.root, "output", "daily")

    cargs = Namespace(only="", root=args.root, allow_stale=args.allow_stale,
                      retries=args.retries, interval=args.interval, timeout=args.timeout,
                      verify_kr=args.verify_kr, quiet=args.quiet,
                      stale_max_age_hours=args.stale_max_age_hours)
    log("开始三路实时采集（微博热搜已于 v3.0.0 取消）...")
    collected = cs.collect_all(cargs)
    bundles = dict(collected["sources"])
    log("载入《新闻联播》逐字稿 ...")
    bundles["xwlb"] = get_xwlb_bundle(args)

    # v3.3.0 质量闸：只标记不删改；结果进入 bundle.quality 与汇总 JSON
    log("逐源质量闸与覆盖度检查 ...")
    for sid in bd.SOURCE_ORDER:
        qg.inspect_bundle(bundles.get(sid) or {})
    coverage = qg.build_coverage(bundles, bd.SOURCE_ORDER)
    if coverage["missing"]:
        log("  覆盖度缺口：%s" % ", ".join(coverage["missing"]))

    degraded = any((bundles.get(sid) or {}).get("status") != "OK" for sid in bd.SOURCE_ORDER)
    log("条目整合与重要性排序 ...")
    result = ed.build_entries({sid: (bundles.get(sid) or {}) for sid in bd.SOURCE_ORDER})

    # v3.3.0 可选跨天去重（默认关闭）；历史只取本技能自己产出的 entries-*.json
    if args.cross_day_dedup:
        hist, hfiles = xd.load_history(args.out, days=args.cross_day_days)
        log("跨天去重：历史 %s 条（文件 %s 份）" % (len(hist), len(hfiles)))
        result = xd.apply(result, hist, enabled=True, history_days=args.cross_day_days)
    else:
        result = xd.apply(result, [], enabled=False)

    # v3.3.0 内置逐字自校验 + 每条目可回溯证据包
    integrity = qg.build_evidence(result, bundles)
    if not integrity["all_verbatim"]:
        log("  警告：%s 处要点未逐字命中原文，已写入 integrity.verbatim_misses"
            % len(integrity["verbatim_misses"]))

    meta = {"generated_at": iso_now(), "report_date": args.date,
            "degraded": degraded, "data_gaps": merge_gaps(bundles),
            "coverage": coverage,
            "collector": {"version": collected.get("collector_version"),
                          "timeout_policy": "按站点取 max(--timeout, 站点下限)",
                          "stale_max_age_hours": args.stale_max_age_hours,
                          "cross_day_dedup": args.cross_day_dedup}}
    html_text, summary = bd.render(bundles, result, meta)
    hp, jp = bd.write_report(args.out, args.date, html_text, summary)
    summary["full_entries_json"] = os.path.join(args.out, "entries-%s.json" %
                                                datetime.now(CN_TZ).strftime("%Y%m%d-%H%M"))
    with open(summary["full_entries_json"], "w", encoding="utf-8", newline="\n") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    run_summary = {
        "status": "DEGRADED" if degraded else "OK",
        "generated_at": summary["generated_at"],
        "report_date": summary["report_date"],
        "sources": summary["source_status"],
        "entry_count": summary["entry_count"],
        "original_item_count": summary["original_item_count"],
        "merged_item_count": summary["merged_item_count"],
        "multi_member_groups": summary["merge_audit"]["multi_member_group_count"],
        "top5": summary["top10"][:5],
        "source_urls": summary["source_urls"],
        "output_files": [hp, jp, summary["full_entries_json"]],
        "data_gaps_count": len(summary["data_gaps"]),
        "version": "3.3.0",
        "coverage": summary["coverage"],
        "integrity": {k: summary["integrity"].get(k) for k in
                      ("quote_total", "verbatim_exact_hits", "verbatim_normalized_hits",
                       "all_verbatim", "evidence_complete")},
        "quality_flags": {sid: q.get("flags", []) for sid, q in summary["quality"].items()},
        "cross_day": {k: summary["cross_day"].get(k) for k in
                      ("enabled", "status", "history_items", "blocked_count", "warned_kept_count")},
    }
    print(json.dumps(run_summary, ensure_ascii=False, indent=2))
    log("日报已生成：%s" % hp)
    if degraded and args.strict:
        return 5
    if all(summary["source_status"][s]["status"] in ("SOURCE_UNAVAILABLE", "PARSE_ERROR")
           for s in bd.SOURCE_ORDER):
        return 5
    return 0


if __name__ == "__main__":
    sys.exit(main())
