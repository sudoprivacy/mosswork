# E-Ink Agent Skill

An AI Agent Skill for converting web pages to ebooks, translating ebooks, converting file formats, generating mind maps, and text-to-speech — powered by the [E-Ink](https://e-ink.me) API.

Compatible with [Codex](https://openai.com/index/codex/), [Cursor](https://cursor.com), [Claude Code](https://docs.anthropic.com/en/docs/claude-code), OpenClaw, and any AI coding agent that supports the skills convention.

## Features

- **Webpage to Ebook** — Convert any URL to EPUB, PDF, or Markdown
- **File Format Conversion** — 30+ format conversions (EPUB, PDF, Markdown, HTML, DOCX, TXT, MOBI, etc.)
- **Ebook Translation** — AI-powered EPUB translation to any language
- **Text to Speech** — Convert text to MP3 audio with multiple voices
- **Mind Map Generation** — Extract structure or AI-generate mind maps from books
- **Credits Check** — Monitor your E-Ink account balance

## Installation

### Option A: npx (recommended)

```bash
npx e-ink-skill
```

This installs the skill to Codex by default:

```bash
${CODEX_HOME:-$HOME/.codex}/skills/e-ink
```

You can target another agent or a custom skill root explicitly:

```bash
npx e-ink-skill --cursor       # ~/.cursor/skills/e-ink
npx e-ink-skill --claude       # ~/.claude/skills/e-ink
npx e-ink-skill --openclaw     # ~/.openclaw/skills/e-ink
npx e-ink-skill --agents       # ~/.agents/skills/e-ink
npx e-ink-skill --path ~/.agents/skills
npx e-ink-skill --all          # Install to all known skill roots
npx e-ink-skill --uninstall    # Remove from the selected target; Codex by default
```

### Option B: git clone

```bash
# Codex
git clone https://github.com/Selenium39/e-ink-skill.git "${CODEX_HOME:-$HOME/.codex}/skills/e-ink"

# Cursor
git clone https://github.com/Selenium39/e-ink-skill.git ~/.cursor/skills/e-ink

# Claude Code
git clone https://github.com/Selenium39/e-ink-skill.git ~/.claude/skills/e-ink

# OpenClaw
git clone https://github.com/Selenium39/e-ink-skill.git ~/.openclaw/skills/e-ink
```

### 2. Get an API key

1. Create an account at [e-ink.me](https://e-ink.me)
2. Go to [Dashboard](https://e-ink.me/dashboard) and create an API key
3. Set the environment variable:

```bash
export EINK_API_KEY="eink_your_api_key_here"
```

Add this to your `~/.zshrc` or `~/.bashrc` for persistence.

### 3. Use it

The skill is automatically available in your AI agent. Try asking:

- "Convert https://e-ink.me to EPUB"
- "Translate this EPUB file to Chinese"
- "Convert book.epub to PDF"
- "Read this article aloud as MP3"
- "Generate a mind map from this PDF"
- "Check my E-Ink credits"

## Credits

API calls consume credits from your E-Ink account:

| Action | Credits |
|--------|---------|
| Webpage to ebook | 3 per URL |
| File conversion | 2 (PDF OCR: 5) |
| Translation | 3 |
| Text to speech | 5 |
| Mind map (structure) | 2 |
| Mind map (AI) | 5 |

Purchase credits at [e-ink.me/pricing](https://e-ink.me/pricing).

## API Documentation

Full API documentation is available at [e-ink.me/developers](https://e-ink.me/developers).

## License

MIT
