# E-Ink Agent Skill

一个用于 E-Ink API 的 AI Agent Skill，可以把网页和文件转换为电子书、翻译 EPUB、生成书籍思维导图，并将文本合成为语音。

兼容 Codex、Cursor、Claude Code、OpenClaw，以及其他支持 skill 约定的 AI 编程 Agent。

## 功能

- **网页转电子书**：将 URL 转换为 EPUB、PDF 或 Markdown
- **文件格式转换**：支持 EPUB、PDF、Markdown、HTML、DOCX、TXT、MOBI 等 30 多种格式
- **电子书翻译**：将 EPUB 翻译为指定语言
- **文本转语音**：将文本合成为 MP3 音频
- **思维导图生成**：从 EPUB 或 PDF 中提取结构，或用 AI 生成思维导图
- **余额查询**：查询 E-Ink 账户剩余 credits

## 安装

### 方式 A：npx（推荐）

```bash
npx e-ink-skill
```

默认会安装到 Codex skill 目录：

```bash
${CODEX_HOME:-$HOME/.codex}/skills/e-ink
```

也可以显式指定其他 Agent 或自定义 skill root：

```bash
npx e-ink-skill --cursor       # ~/.cursor/skills/e-ink
npx e-ink-skill --claude       # ~/.claude/skills/e-ink
npx e-ink-skill --openclaw     # ~/.openclaw/skills/e-ink
npx e-ink-skill --agents       # ~/.agents/skills/e-ink
npx e-ink-skill --path ~/.agents/skills
npx e-ink-skill --all          # 安装到所有已知 skill root
npx e-ink-skill --uninstall    # 从选中的目标卸载；默认目标是 Codex
```

如果某个 Agent 使用自己的 skill 目录，优先使用该 Agent 官方推荐的安装目录；也可以用 `--path <skill-root>` 指定根目录，安装器会在里面创建 `e-ink` 子目录。

### 方式 B：git clone

```bash
# Codex
git clone https://github.com/Selenium39/e-ink-skill.git "${CODEX_HOME:-$HOME/.codex}/skills/e-ink"

# Cursor
git clone https://github.com/Selenium39/e-ink-skill.git ~/.cursor/skills/e-ink

# Claude Code
git clone https://github.com/Selenium39/e-ink-skill.git ~/.claude/skills/e-ink

# OpenClaw
git clone https://github.com/Selenium39/e-ink-skill.git ~/.openclaw/skills/e-ink
```

## 获取 API Key

1. 在 [e-ink.me](https://e-ink.me) 创建账户。
2. 打开 [Dashboard](https://e-ink.me/dashboard) 并创建 API key。
3. 设置环境变量：

```bash
export EINK_API_KEY="eink_your_api_key_here"
```

建议把这行加入 `~/.zshrc` 或 `~/.bashrc`，方便之后自动生效。

## 使用示例

安装后，在支持 skills 的 AI Agent 中直接提出需求即可，例如：

- “把 https://e-ink.me 转成 EPUB”
- “把这个 EPUB 翻译成中文”
- “把 book.epub 转成 PDF”
- “把这篇文章读出来并保存成 MP3”
- “从这个 PDF 生成思维导图”
- “查询我的 E-Ink credits 余额”

## Credits 消耗

API 调用会消耗 E-Ink 账户 credits：

| 操作 | Credits |
|------|---------|
| 网页转电子书 | 每个 URL 3 |
| 文件格式转换 | 2（PDF OCR 为 5） |
| 翻译 | 3 |
| 文本转语音 | 5 |
| 思维导图（结构模式） | 2 |
| 思维导图（AI 模式） | 5 |

可以在 [e-ink.me/pricing](https://e-ink.me/pricing) 购买 credits。

## API 文档

完整 API 文档见 [e-ink.me/developers](https://e-ink.me/developers)。

## License

MIT
