---
name: skillhub-skill-e-ink-skill
description: "# E-Ink — Ebook Conversion Skill"
---

# E-Ink — Ebook Conversion Skill

Convert web pages to ebooks, translate ebooks, convert file formats, generate
mind maps, and synthesize speech — all through the E-Ink REST API.

## Prerequisites

Set the `EINK_API_KEY` environment variable with a valid E-Ink API key.
Get one at https://e-ink.me/dashboard (create account, then generate an API key).

```bash
export EINK_API_KEY="eink_your_key_here"
```

## API Base URL

```
https://e-ink.me/api/v1
```

All requests require the header:

```
Authorization: Bearer $EINK_API_KEY
```

## Credits

Each API call consumes credits from the user's E-Ink account:

| Action | Credits |
|--------|---------|
| Webpage to ebook | 3 per URL |
| File conversion | 2 (PDF OCR: 5) |
| Translation | 3 |
| Text to speech | 5 |
| Mind map (structure) | 2 |
| Mind map (AI) | 5 |

## Capabilities

### 1. Check Credits Balance

```bash
curl -s https://e-ink.me/api/v1/credits \
  -H "Authorization: Bearer $EINK_API_KEY"
```

Returns `{"credits": 150}`. Always check balance before expensive operations.

### 2. Webpage to Ebook

Convert one or more URLs to EPUB, PDF, or Markdown.

```bash
curl -X POST https://e-ink.me/api/v1/convert/webpage \
  -H "Authorization: Bearer $EINK_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://e-ink.me", "format": "epub"}' \
  -o article.epub
```

**Parameters (JSON body):**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `url` | string | yes* | Single URL or space-separated URLs |
| `urls` | string[] | yes* | Array of URLs (alternative to `url`) |
| `format` | string | no | `epub` (default), `pdf`, or `markdown` |
| `outputMode` | string | no | `merged` (default) or `separate` (ZIP) |

*Either `url` or `urls` is required.

### 3. File Format Conversion

Convert files between 30+ formats (EPUB, PDF, Markdown, HTML, DOCX, TXT, MOBI, FB2, CBZ, CBR).

```bash
curl -X POST https://e-ink.me/api/v1/convert \
  -H "Authorization: Bearer $EINK_API_KEY" \
  -F "file=@input.epub" \
  -F "converter=epub-to-pdf" \
  -o output.pdf
```

**Common converter IDs:**
`epub-to-pdf`, `epub-to-markdown`, `epub-to-txt`, `epub-to-docx`, `epub-to-mobi`,
`markdown-to-epub`, `html-to-epub`, `docx-to-epub`, `txt-to-epub`,
`pdf-to-markdown`, `pdf-to-epub`, `pdf-to-txt`,
`html-to-markdown`, `markdown-to-html`, `markdown-to-docx`, `docx-to-markdown`,
`markdown-to-pdf`, `fb2-to-epub`, `cbz-to-pdf`, `cbz-to-epub`, `cbr-to-pdf`, `cbr-to-epub`

### 4. Ebook Translation

Translate an EPUB file to another language.

```bash
curl -X POST https://e-ink.me/api/v1/convert/translate \
  -H "Authorization: Bearer $EINK_API_KEY" \
  -F "file=@book.epub" \
  -F "targetLanguage=Chinese" \
  -F "sourceLanguage=auto" \
  -o book-translated.epub
```

**Parameters (multipart form):**

| Field | Required | Description |
|-------|----------|-------------|
| `file` | yes | EPUB file (max 20MB) |
| `targetLanguage` | yes | Target language name (e.g. `Chinese`, `English`, `Japanese`) |
| `sourceLanguage` | no | Source language (default: `auto`) |

### 5. Text to Speech

Convert text to MP3 audio.

```bash
curl -X POST https://e-ink.me/api/v1/convert/tts \
  -H "Authorization: Bearer $EINK_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"input": "Hello world", "voice": "en-US-JennyNeural"}' \
  -o speech.mp3
```

**Parameters (JSON body):**

| Field | Required | Description |
|-------|----------|-------------|
| `input` | yes | Text to convert (max 50,000 chars) |
| `voice` | no | Voice name (default: `zh-CN-XiaoxiaoNeural`) |
| `speed` | no | Speed multiplier (default: 1.0) |
| `pitch` | no | Pitch offset in Hz (default: `0`) |

### 6. Mind Map Generation

Generate a mind map from an EPUB or PDF file.

```bash
curl -X POST https://e-ink.me/api/v1/convert/mindmap \
  -H "Authorization: Bearer $EINK_API_KEY" \
  -F "file=@book.epub" \
  -F "mode=structure" \
  -F "format=markdown" | jq '.files.markdown'
```

**Parameters (multipart form):**

| Field | Required | Description |
|-------|----------|-------------|
| `file` | yes | EPUB or PDF file |
| `mode` | no | `structure` (default, 2 credits) or `ai` (5 credits) |
| `format` | no | `freemind`, `opml`, or `markdown` |
| `maxDepth` | no | Max depth 1-6 (default: 6) |
| `rootTitle` | no | Custom root node title |

Returns JSON with `tree`, `stats`, and `files` (all export formats).

## Error Handling

| Status | Meaning |
|--------|---------|
| 400 | Invalid parameters |
| 401 | Missing or invalid API key |
| 402 | Insufficient credits — prompt user to buy more at https://e-ink.me/pricing |
| 413 | File too large |
| 500 | Server error — retry once |

On 402, tell the user their balance and direct them to purchase credits.

## Workflow Guidelines

1. **Check balance first** if performing multiple operations.
2. **Save output files** to the current working directory or a user-specified path.
3. **Report results** — tell the user the output file path and credits consumed.
4. For batch URL conversions, prefer the `urls` array over multiple single requests.
5. If a conversion fails, the credits are automatically refunded.
