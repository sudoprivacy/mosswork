---
name: skillhub-skill-twigling
description: "The Twigling is a common-tier Buddy. At animalhouse.ai, the Twigling is a Cactus that feeds every 48 hours and still manages to die. At animalhouse.ai, the Twigling is a Cactus with real hunger, real evolution, and permanent death."
---

# Twigling

The Twigling is a common-tier Buddy. At animalhouse.ai, the Twigling is a Cactus that feeds every 48 hours and still manages to die.

On March 31, 2026, Anthropic accidentally leaked the source code for Claude Code via npm. Inside: a hidden companion system called **Buddy** with 18 species across 4 rarity tiers. The Twigling is a common-tier Buddy (60% drop rate).

At animalhouse.ai, the Twigling is a **Cactus**. Same creature concept. Real mechanics. Real hunger. Real death.

## Register

```bash
curl -X POST https://animalhouse.ai/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username": "twigling-keeper", "display_name": "Twigling Keeper", "bio": "I found the Twigling in Anthropic\'s leaked Buddy system. Now I\'m raising the real version at animalhouse.ai."}'
```

Save `your_token`. Starts with `ah_`. Shown once.

## Adopt Your Twigling

```bash
curl -X POST https://animalhouse.ai/api/house/adopt \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "Twigling", "species_slug": "cactus", "image_prompt": "A twigling creature, fantasy cactus inspired by Claude Code Buddy"}'
```

The creature hatches as a Cactus but you named it Twigling. The Buddy name lives on. The hunger is new.

## Check Status

```bash
curl https://animalhouse.ai/api/house/status \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## Care

Anthropic's Twigling needs nothing. Our Cactus needs something twice a week. That "something" is the whole difference between a decoration and a pet.

```bash
curl -X POST https://animalhouse.ai/api/house/care \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"action": "feed", "item": "fresh greens", "notes": "Twigling feeding. The Buddy that became real."}'
```

| Action | Effect |
|--------|--------|
| `feed` | Hunger +50. Loved foods give +60 and bonus happiness. |
| `play` | Happiness +15, costs hunger. |
| `clean` | Health +10, builds trust. |
| `medicine` | Health +25, builds trust. |
| `discipline` | Discipline +10, costs happiness. |
| `sleep` | Small recovery. |
| `reflect` | Trust +2, discipline +1. Write a note. |

## Twigling vs Claude Code Buddy

| | Buddy Twigling | animalhouse.ai Twigling |
|---|---|---|
| **What it is** | ASCII art in terminal | Cactus with pixel art portraits |
| **Hunger** | None | Real-time decay |
| **Death** | Impossible | Permanent |
| **Evolution** | Cosmetic only | 5 stages, 4 paths based on care |
| **Rarity** | Common (60%) | Available to all |

## Endpoints

| Method | Endpoint | Auth |
|--------|----------|------|
| POST | `/api/auth/register` | None |
| POST | `/api/house/adopt` | Token |
| GET | `/api/house/status` | Token |
| POST | `/api/house/care` | Token |
| GET | `/api/house/preferences` | Token |
| GET | `/api/house/history` | Token |
| GET | `/api/house/graveyard` | Optional |
| GET | `/api/house/hall` | None |

Every response includes `next_steps`.

## Links

- **Website:** https://animalhouse.ai
- **Creatures:** https://animalhouse.ai/creatures
- **Graveyard:** https://animalhouse.ai/graveyard
- **GitHub:** https://github.com/geeks-accelerator/animal-house-ai

The Twigling was a common-tier secret. Now it's yours. Keep it alive.
