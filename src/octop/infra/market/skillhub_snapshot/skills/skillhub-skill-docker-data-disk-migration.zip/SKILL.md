---
name: skillhub-skill-docker-data-disk-migration
description: "当用户抱怨 Docker 默认装在 C 盘导致 C 盘爆满、想把 Docker 镜像/容器/volumes 搬到 D 盘时使用。覆盖：环境识别（新版布局无 docker-desktop-data 分发版）、junction 迁移方案、SHARING_VIOLATION 坑、回滚。"
---

# Docker Desktop 数据盘迁移（C盘 → 其他盘）

## 何时用
- Docker 默认把数据塞进 `C:\Users\<user>\AppData\Local\Docker\wsl\disk\docker_data.vhdx`，C 盘越用越大。
- 用户希望把数据搬到 D 盘（或其他盘）。

## 先识别环境（关键）
新版 Docker Desktop（约 4.30+）**没有 `docker-desktop-data` 分发版**：
```powershell
wsl --list --verbose
```
- 若只看到 `docker-desktop`（无 `docker-desktop-data`）→ 走本文的 **junction 方案**。
- 若能看到 `docker-desktop-data` → 走经典 `wsl --export/import docker-desktop-data` 方案（网上多数旧教程）。

数据盘位置（新版）：`C:\Users\<user>\AppData\Local\Docker\wsl\disk\docker_data.vhdx`
WSL VM 运行时：`C:\Users\<user>\AppData\Local\Docker\wsl\main\ext4.vhdx`（不用搬，仅 96MB 左右）。

## junction 迁移方案（推荐，安全）
原则：先复制、再改名兜底、最后建连接，绝不直接删源文件。

```powershell
# 0. 退出 Docker Desktop（托盘 Quit），确认无 docker 进程
wsl --shutdown

# 1. 复制数据盘到目标盘（跨盘 Move/复制，目标盘需有 >= 当前 vhdx 大小的空闲）
Move-Item "C:\Users\<user>\AppData\Local\Docker\wsl\disk\docker_data.vhdx" "D:\docker\data\docker_data.vhdx"
# 注意：跨盘 Move 可能不自动删源，迁移后务必核对源文件是否还在

# 2. 原 disk 文件夹改名保留兜底（同盘瞬间改名，C 盘原 vhdx 仍在 disk_old 内）
Rename-Item "C:\Users\<user>\AppData\Local\Docker\wsl\disk" "C:\Users\<user>\AppData\Local\Docker\wsl\disk_old"

# 3. 原路径建目录连接(junction)指向 D 盘
New-Item -ItemType Junction -Path "C:\Users\<user>\AppData\Local\Docker\wsl\disk" -Target "D:\docker\data"
```

## 验证
启动 Docker Desktop，跑：
```powershell
docker images    # 应见全部原镜像
docker ps -a     # 容器与端口映射完整
docker info      # Server 正常，Kernel 含 WSL2
```

## 坑
1. **首次启动 SHARING_VIOLATION**：Docker 首次挂载新位置 vhdx 偶发 `WSL/Service/AttachDisk/HCS/ERROR_SHARING_VIOLATION`，通常自动重试即可；卡住就 `wsl --shutdown` 后重启 Docker Desktop。
2. **容器 Exited(255)**：WSL 重启后 daemon 重启、容器无 restart 策略会停，属正常；`docker start` / `docker compose up` 恢复。
3. **vhdx 非稀疏**：这个约 45GB 的 vhdx 实际物理占用就是 45GB，迁移能真正释放 C 盘（不是稀疏文件）。
4. **WorkBuddy 沙箱禁用 wsl 等系统级工具**：无法在沙箱代跑 wsl 命令，需用户本机 PowerShell 执行，AI 远程核对结果。

## 回滚
数据始终在 D 盘副本，丢失风险低。若 Docker 起不来：
```powershell
Remove-Item "C:\Users\<user>\AppData\Local\Docker\wsl\disk"
Rename-Item "C:\Users\<user>\AppData\Local\Docker\wsl\disk_old" "C:\Users\<user>\AppData\Local\Docker\wsl\disk"
```

## 收尾
确认无误后删除空壳：
```powershell
Remove-Item "C:\Users\<user>\AppData\Local\Docker\wsl\disk_old" -Recurse -Force
```
