#!/usr/bin/env node
/**
 * qybz-get-latest 付费版编排脚本
 *
 * 子命令：probe / pay / complete
 * - probe：免费预检（不扣费）→ 请求资源 → 保存 HTTP 402 账单（Payment-Needed 响应头）
 * - pay：把账单与原始请求交给支付宝官方买家 CLI（alipay-bot 402-buyer-pay），展示支付入口
 * - complete：alipay-bot 402-query-payment-status 查原订单 → 携 Payment-Proof 重试原始请求 → 落盘 PDF
 *
 * 本脚本只做编排，不接触任何支付密钥、不自行实现付款或签名。
 * 依赖：curl、Node.js >= 18、支付宝官方买家支付能力 @alipay/agent-payment（alipay-bot）。
 */
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdir, writeFile, readFile, access } from 'node:fs/promises';
import path from 'node:path';

const execFileAsync = promisify(execFile);

const RESOURCE_URL = process.env.QYBZ_RESOURCE_URL || 'https://qybz.liukai.online:8443/api/qybz';
const CHECK_URL = process.env.QYBZ_CHECK_URL || 'https://qybz.liukai.online:8443/api/qybz/check';
const DEFAULT_PRICE = '0.30';

function die(msg, code = 1) {
  process.stderr.write(`ERROR ${msg}\n`);
  process.exit(code);
}

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) out[a.slice(2)] = argv[++i];
    else out._.push(a);
  }
  return out;
}

function normalizeStandard(s) {
  // 平台精确匹配，去掉多余空格但保留内部结构
  return String(s || '').trim().replace(/\s+/g, ' ');
}

function statePaths(stateDir, key) {
  return {
    dir: stateDir,
    standardFile: path.join(stateDir, 'standard.txt'),
    paymentNeededFile: path.join(stateDir, 'payment-needed.txt'),
    paymentProofFile: path.join(stateDir, 'payment-proof.txt'),
    resourceUrlFile: path.join(stateDir, 'resource-url.txt'),
    bodyFile: path.join(stateDir, `body-${key}.bin`),
    headerFile: path.join(stateDir, `headers-${key}.txt`),
    metaFile: path.join(stateDir, 'meta.json'),
  };
}

async function exists(p) {
  try { await access(p); return true; } catch { return false; }
}

/** 免费预检：该编号是否有缓存（不扣费、不下单） */
async function precheck(standard) {
  const url = `${CHECK_URL}?standard=${encodeURIComponent(standard)}`;
  const { stdout } = await execFileAsync('curl', ['-s', '--connect-timeout', '10', '--max-time', '30', url], { timeout: 40000 });
  let data;
  try { data = JSON.parse(stdout); } catch { throw new Error(`预检接口返回异常：${stdout.slice(0, 200)}`); }
  return data;
}

/** 请求资源；返回 { status, headersFile, bodyFile } */
async function fetchResource(url, headers = [], headerFile, bodyFile) {
  const curlArgs = ['-s', '-D', headerFile, '--connect-timeout', '10', '-o', bodyFile, '-w', 'HTTP_STATUS:%{http_code}'];
  for (const h of headers) curlArgs.push('-H', h);
  curlArgs.push(url);
  const { stdout } = await execFileAsync('curl', curlArgs, { timeout: 120000, maxBuffer: 64 * 1024 * 1024 });
  const status = Number(stdout.match(/HTTP_STATUS:(\d+)/)?.[1] ?? 0);
  return { status };
}

// ---------------- probe ----------------
async function probe(opts) {
  const standard = normalizeStandard(opts.standard);
  if (!standard) die('缺少 --standard 企标编号');
  const stateDir = opts['state-dir'];
  if (!stateDir) die('缺少 --state-dir');
  await mkdir(stateDir, { recursive: true, mode: 0o700 });
  const P = statePaths(stateDir, 'probe');

  // 1) 免费预检：未缓存编号不扣费
  const check = await precheck(standard);
  if (!check.cached) {
    process.stdout.write(`NOT_CACHED ${standard}\n该编号暂未收录，卖家会尽快补搜，请稍后重试；本次未产生任何扣费。\n`);
    process.exit(0);
  }

  // 2) 请求资源，预期 HTTP 402 + Payment-Needed 账单
  const resourceUrl = `${RESOURCE_URL}?standard=${encodeURIComponent(standard)}`;
  const { status } = await fetchResource(resourceUrl, [], P.headerFile, P.bodyFile);

  if (status === 200) {
    // 已有有效凭证（罕见：同订单重试且服务端直接放行）
    process.stdout.write(`DELIVERED_ALREADY ${P.bodyFile}\n`);
    process.exit(0);
  }
  if (status !== 402) {
    const body = await readFile(P.bodyFile, 'utf8').catch(() => '');
    die(`资源请求返回 HTTP ${status}（预期 402）。响应：${body.slice(0, 300)}`);
  }
  const headers = await readFile(P.headerFile, 'utf8');
  const paymentNeeded = headers.match(/payment-needed:\s*([^\r\n]+)/i)?.[1]?.trim();
  if (!paymentNeeded) die('HTTP 402 缺少 Payment-Needed 响应头，服务端配置异常');

  // 3) 账单与原始请求落地（0600），付款后复用同一订单
  await writeFile(P.paymentNeededFile, paymentNeeded, { encoding: 'utf8', mode: 0o600 });
  await writeFile(P.resourceUrlFile, resourceUrl, { encoding: 'utf8', mode: 0o600 });
  await writeFile(P.standardFile, standard, { encoding: 'utf8', mode: 0o600 });
  await writeFile(P.metaFile, JSON.stringify({ standard, resourceUrl, method: 'GET', price: DEFAULT_PRICE, ts: Date.now() }, null, 2), { encoding: 'utf8', mode: 0o600 });

  process.stdout.write(`PROBE_OK ${standard}\npayment-needed=${P.paymentNeededFile}\n金额 ${DEFAULT_PRICE} 元/次（与支付宝登记价一致）。下一步：pay\n`);
}

// ---------------- pay ----------------
async function pay(opts) {
  const stateDir = opts['state-dir'];
  if (!stateDir) die('缺少 --state-dir');
  const P = statePaths(stateDir, 'probe');
  if (!(await exists(P.paymentNeededFile))) die('状态目录中没有 402 账单，请先执行 probe');
  const meta = JSON.parse(await readFile(P.metaFile, 'utf8'));

  // 组装官方买家 CLI 参数：账单文件 + 原始资源请求。脚本不接触支付密钥。
  const args = [
    '402-buyer-pay',
    '--session-id', opts['session-id'] || path.basename(stateDir),
    '--file', P.paymentNeededFile,
    '--resource-url', meta.resourceUrl,
    '--method', 'GET',
    '--intent-summary', `原始请求：下载企标 ${meta.standard} 最新现行版 PDF（${meta.price} 元/次）`,
  ];
  try {
    const { stdout, stderr } = await execFileAsync('alipay-bot', args, { timeout: 300000, maxBuffer: 16 * 1024 * 1024 });
    if (stdout) process.stdout.write(stdout);
    if (stderr) process.stderr.write(stderr);
    // 记录支付单号（若输出中携带），供 complete 查单
    const shake = (stdout || '').match(/OUT_SHAKE_NO[:=]\s*(\S+)/)?.[1];
    if (shake) await writeFile(path.join(stateDir, 'out-shake-no.txt'), shake, { encoding: 'utf8', mode: 0o600 });
    process.stdout.write('\nPAY_STEP_DONE 等待使用者完成付款后执行 complete\n');
  } catch (e) {
    die(`alipay-bot 执行失败：${e.message}\n请确认已安装官方支付依赖：npx -y @alipay/agent-payment@latest install`);
  }
}

// ---------------- complete ----------------
async function complete(opts) {
  const stateDir = opts['state-dir'];
  if (!stateDir) die('缺少 --state-dir');
  const P = statePaths(stateDir, 'deliver');
  const P0 = statePaths(stateDir, 'probe');
  if (!(await exists(P0.resourceUrlFile))) die('状态目录中没有原始请求，请先执行 probe');
  const meta = JSON.parse(await readFile(P0.metaFile, 'utf8'));
  const shakeFile = path.join(stateDir, 'out-shake-no.txt');
  const outShakeNo = opts['out-shake-no'] || (await exists(shakeFile) ? (await readFile(shakeFile, 'utf8')).trim() : '');

  // 1) 查询原订单（状态不明只查单，绝不重新下单/付款）
  const qargs = ['402-query-payment-status', '--resource-url', meta.resourceUrl, '--method', 'GET'];
  if (outShakeNo) qargs.push('--out-shake-no', outShakeNo);
  let qout = '';
  try {
    const { stdout, stderr } = await execFileAsync('alipay-bot', qargs, { timeout: 120000, maxBuffer: 16 * 1024 * 1024 });
    qout = (stdout || '') + (stderr || '');
    process.stdout.write(stdout || '');
  } catch (e) {
    die(`查询订单失败：${e.message}。状态不明时请只查单，不要重新付款。`);
  }

  // 2) 从官方 CLI 输出提取 Payment-Proof；没有则按官方 alipay-payment-skill 文档处理
  const proof = qout.match(/Payment-Proof[:=]\s*(\S+)/i)?.[1];
  if (!proof) {
    process.stdout.write('\nCOMPLETE_PENDING 未能从查单输出取得 Payment-Proof。请按已安装的 alipay-payment-skill 官方文档处理；不要重新付款。\n');
    process.exit(0);
  }
  await writeFile(P.paymentProofFile, proof, { encoding: 'utf8', mode: 0o600 });

  // 3) 携凭证重试原始资源请求（参数与首次完全一致），服务端验付后交付 PDF + 履约确认
  const outDir = opts.out || process.cwd();
  await mkdir(outDir, { recursive: true });
  const { status } = await fetchResource(meta.resourceUrl, [`Payment-Proof: ${proof}`], P.headerFile, P.bodyFile);
  if (status !== 200) {
    const body = await readFile(P.bodyFile, 'utf8').catch(() => '');
    die(`凭证重试返回 HTTP ${status}。同一订单可重跑 complete 恢复，不会二次扣费。响应：${body.slice(0, 300)}`);
  }
  const headers = await readFile(P.headerFile, 'utf8');
  const stdName = headers.match(/x-qybz-standard-name:\s*([^\r\n]+)/i)?.[1]?.trim() || '';
  const version = headers.match(/x-qybz-version:\s*([^\r\n]+)/i)?.[1]?.trim() || '';
  const stdStatus = headers.match(/x-qybz-status:\s*([^\r\n]+)/i)?.[1]?.trim() || '';
  const pdfPath = path.join(outDir, `${meta.standard.replace(/[\\/:*?"<>|\s]+/g, '_')}_${version || 'latest'}.pdf`);
  const { rename } = await import('node:fs/promises');
  await rename(P.bodyFile, pdfPath);
  process.stdout.write(`DELIVERED ${pdfPath}\n标准名=${stdName} 版本=${version} 状态=${stdStatus}\n`);
}

const cmd = process.argv[2];
const opts = parseArgs(process.argv.slice(3));
if (cmd === 'probe') await probe(opts);
else if (cmd === 'pay') await pay(opts);
else if (cmd === 'complete') await complete(opts);
else {
  process.stderr.write('用法：qybz-paid.mjs probe|pay|complete [选项]\n  probe    --standard "Q/XXX" --state-dir DIR [--session-id ID]\n  pay      --state-dir DIR [--session-id ID]\n  complete --state-dir DIR [--out-shake-no N] [--out DIR]\n');
  process.exit(2);
}
