---
name: skillhub-skill-qybz-get-latest
description: "按企标标准编号获取「最新 + 现行有效」的企标原文 PDF（付费，0.3 元/次）。当使用者给出企标编号（如 Q/SHYR 041、Q31/0118000217C014）并要求下载企标原文/全文/PDF、或要求确认是不是最新版/现行有效时使用。使用者只需提供编号，不需要 hexId、链接或账号。"
---

# 企标最新现行版下载（付费版，按编号）

**给一个企标编号，产出该编号「最新 + 现行有效」版本的 PDF。**
本技能通过部署在服务端的收费接口交付，使用支付宝 AI 按量付费：**0.30 元/次**，
未付款时接口返回 **HTTP 402 账单**，买家扫码付款后携 **Payment-Proof** 凭证重试取回资源，
服务端验付、交付并发送**履约确认（ack）**。

- 支付依赖：官方买家支付能力 `@alipay/agent-payment`（提供 `alipay-bot` CLI）。
  使用前确认已安装：`npx -y @alipay/agent-payment@latest install`，并确认能加载官方 `alipay-payment-skill`。
- 本技能包**不含任何密钥、证书、账号**；下载能力全部在服务端完成。

## 触发词与输入

- 触发：给出企标编号并要求下载原文 / 全文 / PDF / 判定最新版或现行有效。
- 输入：一个或多个企标编号（如 `Q/SHYR 041`、`Q31/0118000217C014`）。
- 输出：PDF 文件路径 + 版本信息（标准名/版本号/发布时间/现行状态）。

## 价格与计费口径

- 单次价格：**0.30 元/次**（与支付宝服务登记价、服务端账单、SkillHub 展示价一致）。
- 计费单位：**每个编号一次扣费**。多个编号依次走完整流程，每次先确认再付款。
- 未缓存编号**不会扣费**（见下方第 1 步预检）。

## 支付流程（WorkBuddy 按此执行，脚本子命令 probe / pay / complete）

每个编号独立执行下列流程。状态文件统一放在 `~/.qybz-get-latest/.state/<SESSION_KEY>/`（权限 0600）。

**第 0 步 — 安装买家支付依赖（首次一次即可）**

```bash
npx -y @alipay/agent-payment@latest install
```

**第 1 步 — probe：免费预检 + 触发 402 账单**

```bash
node "<技能目录>/scripts/qybz-paid.mjs" probe --standard "Q/SHYR 041" \
  --state-dir ~/.qybz-get-latest/.state/<SESSION_KEY> --session-id <SESSION_KEY>
```

脚本行为：

1. 先请求免费预检接口（不扣费、不下单）。
   - 返回 `cached: false` → 该编号暂无缓存，**直接告知使用者「该编号暂未收录，卖家会尽快补搜，请稍后重试；本次未产生任何扣费」**，流程结束。
   - 返回 `cached: true` → 继续。
2. 请求资源接口，未付款时预期返回 **HTTP 402** 与 **Payment-Needed** 响应头（账单）。
3. 脚本把账单与原始请求写入状态文件，供付款后复用同一订单。
4. 输出 `PROBE_OK ... payment-needed=<账单文件>`，进入第 2 步。

**第 2 步 — pay：展示账单与金额，等待使用者扫码付款（先向使用者确认！）**

```bash
node "<技能目录>/scripts/qybz-paid.mjs" pay \
  --state-dir ~/.qybz-get-latest/.state/<SESSION_KEY> --session-id <SESSION_KEY>
```

- 脚本调用官方买家 CLI `alipay-bot 402-buyer-pay`，展示用途（原始请求：下载企标 <编号> 最新现行版 PDF）、
  金额（0.30 元）与支付入口，**必须停下来等使用者完成扫码授权，不得代付或跳过**。
- 使用者付款后进入第 3 步。

**第 3 步 — complete：查原订单 → 携凭证重试 → 交付 PDF**

```bash
node "<技能目录>/scripts/qybz-paid.mjs" complete \
  --state-dir ~/.qybz-get-latest/.state/<SESSION_KEY> \
  --out-shake-no <pay 步骤输出的 OUT_SHAKE_NO>
```

- 脚本调用 `alipay-bot 402-query-payment-status` 查询原订单（**不重新下单、不重复付款**），
  状态不明时只查单，绝不发起新付款。
- 查到已支付后，脚本携 **Payment-Proof** 凭证重试原始资源请求（参数与首次完全一致）；
  服务端验付、交付 PDF 并发送履约确认。
- 脚本把 PDF 落盘到 `--out` 目录（默认当前目录）并打印 `DELIVERED <PDF路径> 标准名 版本 状态`。

**第 4 步 — 多编号**：对下一个编号重复第 1~3 步（每次新开一个 state 子目录）。

## 失败与恢复规则（必须遵守）

- **同一订单重试**：付款成功但交付失败时，重跑 `complete`（同一 `--out-shake-no`、同一状态目录），
  服务端幂等，不会二次扣费。
- **状态不明**：只调用查单，不重复付款、不追加回执。
- **回执失败**：仅当官方 CLI 输出明确显示回执失败且使用者要求恢复时，按官方 `alipay-payment-skill`
  文档处理；成功路径不追加独立回执。
- **绝不**：自行实现付款或签名、伪造/复用他人 Payment-Proof、在未付款时声称已交付。

## 依赖与安装

- Node.js ≥ 18（脚本仅用标准库 + curl + `alipay-bot`）。
- 买家支付依赖：`@alipay/agent-payment`（安装命令见第 0 步）。
- 技能包目录：`SKILL.md` + `scripts/qybz-paid.mjs`，无密钥、无 .env、无状态文件、无 node_modules。

## 隐私与合规

- 技能包与状态文件不含任何支付宝密钥（密钥只存在于卖家服务端）。
- 使用者提供的编号只发送到本技能登记的服务端接口与支付宝支付体系。
