# 服务端信息

服务端地址已固化进脚本（买家零配置），**已实测外网可达**（2026-11-10）：

- 收费资源端点：`https://qybz.liukai.online:8443/api/qybz`
- 免费预检端点：`https://qybz.liukai.online:8443/api/qybz/check`

价格口径：0.30 元/次（支付宝登记价 = 服务端账单 = SkillHub 展示价）。

> 服务端为 IPv6-only（CNAME → 主域 AAAA → 绿联 NAS），IPv4-only 网络的买家可能无法访问。
> 若将来地址变更，需同步修改 `scripts/qybz-paid.mjs` 顶部的两个默认值并重新打包上传 SkillHub。
