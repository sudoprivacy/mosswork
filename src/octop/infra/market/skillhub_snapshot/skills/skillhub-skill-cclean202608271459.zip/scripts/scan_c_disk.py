#!/usr/bin/env python3
"""C盘清理大师 - 只读扫描脚本。

仅统计各清理目标的大小，绝不删除、修改、移动任何文件。
输出 Markdown 表格报告，按大小降序排列。
"""

import os
import sys
import locale

# 常见清理目标注册表：名称, 路径, 安全等级, 说明
TARGETS = [
    ("用户临时文件", os.path.expandvars(r"%TEMP%"), "safe",
     "程序运行残留，可安全清理"),
    ("系统临时文件", r"C:\Windows\Temp", "safe",
     "系统临时文件，可安全清理"),
    ("Windows 更新缓存", r"C:\Windows\SoftwareDistribution\Download",
     "safe", "已下载的更新安装包残留"),
    ("Windows 错误报告", r"C:\ProgramData\Microsoft\Windows\WER",
     "safe", "崩溃转储与错误报告"),
    ("缩略图缓存", os.path.expandvars(
        r"%LOCALAPPDATA%\Microsoft\Windows\Explorer"), "safe",
     "Explorer 缩略图缓存（thumbcache_*）"),
    ("Chrome 缓存", os.path.expandvars(
        r"%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache"), "safe",
     "浏览器缓存"),
    ("Edge 缓存", os.path.expandvars(
        r"%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Cache"), "safe",
     "浏览器缓存"),
    ("pip 缓存", os.path.expandvars(r"%LOCALAPPDATA%\pip\cache"), "safe",
     "Python 包下载缓存"),
    ("npm 缓存", os.path.expandvars(r"%LOCALAPPDATA%\npm-cache"), "safe",
     "Node 包下载缓存"),
    ("NuGet 缓存", os.path.expandvars(r"%USERPROFILE%\.nuget\packages"),
     "caution", ".NET 包缓存，清理后需重新下载"),
    ("崩溃转储 Minidump", r"C:\Windows\Minidump", "caution",
     "蓝屏转储文件，排查问题后可删"),
    ("内存转储", r"C:\Windows\MEMORY.DMP", "caution",
     "完整内存转储，可能数 GB"),
    ("Windows 旧日志", r"C:\Windows\Logs", "caution",
     "系统日志，排查问题后可清"),
    ("传递优化文件", r"C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization",
     "caution", "更新分发缓存"),
    ("休眠文件", r"C:\hiberfil.sys", "caution",
     "休眠功能占用，通常等于内存大小；建议用 powercfg /h off 关闭而非删除"),
]

IGNORE_NAMES = {"pagefile.sys", "swapfile.sys", "hiberfil.sys"}


def dir_size(path):
    """只读统计目录大小（字节）。忽略权限错误与系统页面文件。"""
    total = 0
    if os.path.isfile(path):
        try:
            return os.path.getsize(path)
        except OSError:
            return 0
    if not os.path.isdir(path):
        return -1  # 不存在
    for root, dirs, files in os.walk(path, onerror=lambda e: None):
        for name in files:
            if name.lower() in IGNORE_NAMES:
                continue
            try:
                total += os.path.getsize(os.path.join(root, name))
            except OSError:
                pass
    return total


def fmt_size(nbytes):
    if nbytes < 0:
        return "不存在"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if nbytes < 1024:
            return f"{nbytes:.1f} {unit}"
        nbytes /= 1024
    return f"{nbytes:.1f} PB"


def main():
    # 避免在非 Windows 上误跑
    if sys.platform != "win32" and os.name != "nt":
        print("此脚本仅适用于 Windows。")
        return 1

    results = []
    for name, path, level, note in TARGETS:
        size = dir_size(path)
        if size > 0:
            results.append((size, name, path, level, note))

    results.sort(reverse=True)

    print("# C盘清理大师 - 只读扫描报告\n")
    print("| 大小 | 目标 | 路径 | 等级 | 说明 |")
    print("|------|------|------|------|------|")
    safe_total = caution_total = 0
    for size, name, path, level, note in results:
        mark = {"safe": "🟢 安全", "caution": "🟡 谨慎"}[level]
        print(f"| {fmt_size(size)} | {name} | `{path}` | {mark} | {note} |")
        if level == "safe":
            safe_total += size
        else:
            caution_total += size

    print(f"\n**🟢 安全项合计：{fmt_size(safe_total)}**")
    print(f"**🟡 谨慎项合计：{fmt_size(caution_total)}**")
    print(f"**预估可释放总量：{fmt_size(safe_total + caution_total)}**")
    print("\n> 本报告为只读扫描结果，未删除任何文件。清理需经用户确认后执行。")
    print("> 红线区域（桌面/文档/下载/系统核心目录）不在清理范围内。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
