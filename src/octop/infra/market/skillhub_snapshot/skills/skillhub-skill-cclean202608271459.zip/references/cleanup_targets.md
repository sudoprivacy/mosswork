# 清理目标分级表

C 盘清理目标的安全分级、清理方式与风险说明。清理执行前必须对照本表逐项核对等级。

## 🟢 安全级（用户整体确认一次即可执行）

| 目标 | 典型路径 | 清理方式 | 说明 |
|------|---------|---------|------|
| 用户临时文件 | `%TEMP%` | 删除目录内容（保留目录本身） | 程序运行残留；正在运行的程序可能占用个别文件，跳过即可 |
| 系统临时文件 | `C:\Windows\Temp` | 删除目录内容 | 同上 |
| Windows 更新缓存 | `C:\Windows\SoftwareDistribution\Download` | 删除目录内容或运行 `cleanmgr` | 已安装完成的更新包残留 |
| Windows 错误报告 | `C:\ProgramData\Microsoft\Windows\WER` | 删除目录内容 | 崩溃报告，无保留价值 |
| 缩略图缓存 | `%LOCALAPPDATA%\Microsoft\Windows\Explorer\thumbcache_*` | 仅删 `thumbcache_*` 文件 | 删除后首次打开文件夹会重建 |
| Chrome/Edge 缓存 | `...\User Data\Default\Cache` | 删除 Cache 目录内容 | 不含书签、密码、历史 |
| pip / npm 缓存 | `%LOCALAPPDATA%\pip\cache`、`npm-cache` | 删除目录内容 | 下次安装重新下载 |

## 🟡 谨慎级（逐项确认，宁漏勿删）

| 目标 | 典型路径 | 清理方式 | 风险 |
|------|---------|---------|------|
| 回收站 | `C:\$Recycle.Bin` | `Clear-RecycleBin -Confirm` | 清空后不可恢复，用户可能有后悔药依赖 |
| 崩溃转储 | `C:\Windows\Minidump`、`MEMORY.DMP` | 确认无需排查后删除 | 删除后无法分析蓝屏原因 |
| Windows 日志 | `C:\Windows\Logs` | 删除旧日志 | 排查系统问题时需要 |
| NuGet 包缓存 | `%USERPROFILE%\.nuget\packages` | 删除后重新还原 | 离线环境下重新下载困难 |
| 传递优化缓存 | `...\DeliveryOptimization` | 设置中清理 | 影响更新分发效率 |
| 休眠文件 | `C:\hiberfil.sys` | 用 `powercfg /h off` 关闭（勿直接删） | 关闭后无法休眠；直接删除会损坏功能 |
| 下载目录大文件 | `Downloads` | **仅报告，用户自行处理** | 绝不代删 |

## 🔴 红线（永远不清理、不列入清理项）

- 桌面（Desktop）、文档（Documents）、下载（Downloads）目录本体
- 图片、视频、音乐等个人媒体目录
- 用户主目录（`C:\Users\<user>`）整体
- `C:\Windows`（除上表明确的 Temp/Logs/SoftwareDistribution 子路径外）
- `C:\Program Files`、`C:\Program Files (x86)`、`C:\ProgramData` 整体
- `pagefile.sys`、`swapfile.sys`（虚拟内存，由系统管理）
- 注册表、`AppData` 整体目录（只允许其中明确的 Cache 子路径）
- 任何 HKEY 注册表操作

## 大文件排查建议（只报告不删除）

当常规清理释放空间不足时，可只读扫描 C 盘大文件（>1GB）并向用户报告路径与大小，由用户决定处理方式。典型大文件：虚拟机磁盘、系统镜像 ISO、旧备份、录屏文件。发现此类文件时仅提示，绝不列入自动清理。
