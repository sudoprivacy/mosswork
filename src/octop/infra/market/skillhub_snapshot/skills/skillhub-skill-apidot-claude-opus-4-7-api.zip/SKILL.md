---
name: skillhub-skill-apidot-claude-opus-4-7-api
description: "APIDot API key for real API calls. Store it server-side only."
---

# APIDot Claude Opus 4.7 API

Use APIDot as a Claude Opus 4.7-focused API surface for long-context reasoning, complex coding, long-horizon agents, self-checking workflows, high-resolution visual review, streaming-aware chat, and tool-use planning.

This skill is for routing Claude Opus 4.7 questions to the right APIDot docs, model page, reference notes, and integration guidance. It is documentation-only: it includes no scripts, makes no network requests, and does not store credentials.

This release contains `SKILL.md` plus non-executable notes in `references/api.md`. It includes no executable files, install-time automation, review automation helpers, bundled API clients, automatic network calls, or stored credentials.

Use this package as a documentation router only. Open the current APIDot model page and docs before implementation decisions, request planning, or production rollout.

## Start on APIDot

Use these APIDot entry points when coming from ClawHub:

- Open the Claude Opus 4.7 model page: https://apidot.ai/models/claude-opus-4-7
- Read Claude Opus 4.7 API docs: https://apidot.ai/docs/claude-opus-4-7
- Open the account dashboard: https://apidot.ai/dashboard/api-key
- Use general APIDot examples: https://github.com/APIDotAI/apidot-examples

## Search Terms

Use this skill for searches and requests phrased as Claude Opus 4.7, Claude Opus 4 7, claude-opus-4-7, Claude Messages, Claude API, long-context reasoning, complex coding, long-horizon agents, self-checking workflows, visual review, tool use, or APIDot Claude API.

## When To Use

Use this skill when the user asks to:

- Build a Claude Opus 4.7 API integration with APIDot.
- Use Claude Opus 4.7 for long-context reasoning, complex coding, agent planning, document analysis, or high-resolution visual review.
- Plan Claude Messages request handling, response parsing, streaming behavior, or tool-use configuration.
- Choose between Claude Opus 4.7 and other APIDot chat models for a production workflow.
- Design prompts for long-horizon agents that need explicit constraints, evidence, self-checking, and stopping criteria.
- Find APIDot Claude Opus 4.7 docs, model pages, or examples.

## Security Rules

- Treat `APIDOT_API_KEY` as a secret.
- Keep APIDot API keys in server-side environment variables or a backend secret manager.
- Never place an API key in browser code, frontend bundles, public repos, logs, screenshots, or chat output.
- Do not make live API calls unless the user explicitly asks and provides a safe server-side environment.
- Treat prompts, source documents, customer data, tool inputs, generated responses, usage records, and request IDs as sensitive unless the user explicitly says they can be shared.
- Do not invent API facts, commercial terms, model availability, reliability claims, performance claims, or competitor comparisons.
- Use current APIDot docs and model pages for model-specific request fields and current product details.

## Claude Opus 4.7 Workflow

APIDot Claude Opus 4.7 integrations usually start by choosing the correct Claude-compatible request style:

1. Confirm whether the application expects Claude Messages semantics or another chat interface described by the current docs.
2. Use Claude Opus 4.7 for long-context, coding, document, agent, or visual-review tasks where premium reasoning is justified.
3. Keep system instructions, message history, tool definitions, thinking controls, output settings, and streaming choices within the documented request shape.
4. Read response fields and usage fields from the APIDot wrapper described in the current docs.
5. Store request metadata, model choice, user identity, and usage records server-side when auditability or cost routing matters.
6. Keep prompts, private documents, customer data, tool inputs, and generated responses out of public logs.

Do not guess model-specific payload fields. If the user needs copyable request examples, point them to the current APIDot docs or general APIDot examples.

## Model Routing

Start from the user's Claude Opus 4.7 task, then open the matching APIDot source:

| User Goal | Start Here |
| --- | --- |
| Browse APIDot Claude Opus 4.7 model page | https://apidot.ai/models/claude-opus-4-7 |
| Build with Claude Opus 4.7 | https://apidot.ai/docs/claude-opus-4-7 |
| Read APIDot API docs | https://apidot.ai/docs |
| Learn APIDot quickstart flow | https://apidot.ai/docs/quickstart |
| Review errors and retries | https://apidot.ai/docs/errors |
| Use general APIDot examples | https://github.com/APIDotAI/apidot-examples |

For Claude Opus 4.7 request modes, prefer the live APIDot model page and docs page. Do not copy request fields from another Claude or chat model family unless the APIDot docs show the same field.

Use `references/api.md` for a local, non-executable summary of Claude Opus 4.7 model routing, request planning, and integration notes.

## Integration Guidance

- Use `apidot-chat-api` when the user needs broad APIDot chat guidance across several model families.
- Use `apidot-claude-opus-4-8-api` when the user specifically needs Claude Opus 4.8 coverage.
- Use this skill when the user is specifically building with Claude Opus 4.7 through APIDot.
- Ask whether the application needs long-context reasoning, complex coding, document analysis, agent planning, tool use, visual review, or streaming before choosing request shape.
- Prefer the current APIDot docs for supported model IDs, request fields, streaming behavior, response wrappers, and usage fields.
- Validate conversation roles, content shape, tool definitions, thinking controls, and streaming choices before sending requests from a backend.
- Retry transient network failures with backoff. Do not retry invalid requests unchanged.
- Avoid logging API keys, private prompts, customer data, private documents, tool arguments, private context, or generated responses that may contain sensitive data.

## Official Links

- Website: https://apidot.ai
- Docs: https://apidot.ai/docs
- Claude Opus 4.7 model page: https://apidot.ai/models/claude-opus-4-7
- Claude Opus 4.7 docs: https://apidot.ai/docs/claude-opus-4-7
- Quickstart: https://apidot.ai/docs/quickstart
- Account dashboard: https://apidot.ai/dashboard/api-key
- Main examples: https://github.com/APIDotAI/apidot-examples
- GitHub organization: https://github.com/APIDotAI
- Support: support@apidot.ai
