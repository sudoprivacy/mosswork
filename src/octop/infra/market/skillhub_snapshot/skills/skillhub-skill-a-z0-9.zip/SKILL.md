---
name: skillhub-skill-a-z0-9
description: "「制作视频」Skill（开发者：叶羊大佬）——按 OPUS 5.5「确定性渲染」视频制作流程产出专业级视频（模型当导演写代码，无头浏览器逐帧截图，ffmpeg 合成，程序化配乐，自动发布检查）。适用场景：用户要制作/生成视频、动效短片、科普动画、数据图表视频、产品宣传片、开场 Logo 动画、3D 运镜大片，或提到 OPUS 5.5、确定性渲染、renderFrame(t)。触发词：做视频、视频制作、动画视频、宣传片、OPUS 5.5。"
---

# 制作视频

> OPUS 5.5「确定性渲染」视频制作流程（完整版） · **开发者：叶羊大佬**

核心思想：**LLM 不生成像素，只当导演**。模型输出「确定性场景代码」，无头浏览器逐帧截图，ffmpeg 合成 MP4，程序化配乐，自动质检。每一帧都是时间 t 的纯函数，改一处只重跑一处。

## 文件清单（本目录即完整工具链）

| 文件 | 用途 |
|------|------|
| `motion-3d.js` | 核心引擎：缓动/**72 运镜**/3D摄影机/**22 排版**/**40 后期**（挂载 `window.OV`） |
| `fx-plus.js` | 增强包：PBR材质/投影阴影/粒子系统/流体背景/镜头光晕/**12 文字特效 + 5 天气 + 3 景深**（挂载 `window.OVX`，需在 motion-3d.js 之后加载） |
| `render.py` | 逐帧渲染器：`python3 render.py scene.html frames/ 30` |
| `snap.py` | 快速抽帧调试：`python3 snap.py scene.html 0.5 3 8`（秒数） |
| `audio.py` | 程序化配乐+音效：`python3 audio.py out.wav --dur 12 --bpm 120 --mood cinematic --sfx "3=impact"`（**24 mood / 44 SFX**） |
| `publish_check.py` | 发布前自动检查：17 项硬指标 + 抽帧拼图 |
| `preview.py` | 实时预览服务器：浏览器看片+热重载+逐帧步进 |
| `assemble.py` | 多场景拼接器：转场（**40 种 xfade**）/配乐/字幕/剪辑点踩点一条龙 |
| `terrain.js` | 程序化地形 + 水面渲染：**16 调色板 + 16 biome 预设 + GTA 式随机世界 world() + CPU 实时水（14 频波场）**（挂载 `window.OVT`） |
| `gl-water.js` | GPU 实时地形+水面：WebGL fragment raycast（10 项波浪法线/菲涅尔/反光路径），吃 `OVT.world()` 数据（挂载 `window.OVGL`） |
| `physics.js` | 确定性物理引擎：重力/碰撞/反弹/**绳索/软体/爆炸/磁场/布料/弹簧/摆链/涡流/湍流（10 能力）**（挂载 `window.OVP`） |
| `model3d.js` | 3D 模型加载与绘制：**JSON/OBJ/STL/PLY** + 实例化 + 轮廓描边（挂载 `window.OVM`） |
| `models.py` | 3D 模型搜索下载引擎：Poly Haven CC0 API，search/get/convert 子命令 |
| `shader.js` | GPU 着色器层：WebGL raymarching（挂载 `window.OVGL`） |
| `flagship.html` | 旗舰样片场景（学习范例：全能力用法） |
| `enhanced.html` | 增强样片：OVX 电影感特效范例 |
| `terrain-sample.html` / `water-sample.html` | 地形 / 水渲染范例（water 版已接 CPU 实时水） |
| `world-sample.html` | GTA 式随机世界范例（三段 × 4s 每段一个新 seed 世界） |
| `water-gl-sample.html` | GPU 实时地形+水面范例（raycast shader 双画布） |
| `physics-sample.html` | 物理 + CC0 模型导入范例 |
| `gpu-sample.html` | GPU 双画布范例 |
| `icon.png` / `icon.svg` | Skill 图标 |

## 流程（7 步 + 发布门禁）

```
[1]意图结构化 → [2]分镜脚本(beat sheet) → [3]场景代码(帧契约)
→ [3.5]套用引擎库 → [4]snap 抽帧调试 → [5]render 全量渲染
→ [6]ffmpeg 合成+配乐 → [7]publish_check 发布检查 → 交付
```

### 第 1 步：意图结构化
输出 JSON Schema（topic/audience/duration/resolution/fps/aspect/language/style{palette,font,mood}/facts/audio/output_name）。
- `facts` 防幻觉：所有数字必须来自用户数据或已查证来源。
- 用户没给品牌色/logo 时**必须问**，否则产出默认货。
- 配色可直接用 `OV.UTIL.PALETTES`（cinema/tech/paper/night/mono）。

### 第 2 步：分镜脚本（Beat Sheet）
时间轴表格：每段的时间/画面/文字/动效。切镜与重音**对齐节拍**（BPM 整数倍），节拍点同时是配乐 `--hits` 的时刻。先给用户过目再写代码。

### 第 3 步：场景代码（帧契约）
自包含 HTML + `<script src="motion-3d.js">`：
1. 单 `<canvas>`，尺寸精确等于分辨率，无 CSS 缩放
2. 暴露 `window.DURATION`、`window.FPS`、`window.renderFrame(t)`（从零重绘第 t 秒）
3. **纯函数铁律**：禁 `Date.now`/`performance.now`/`Math.random`（用 `OV.mulberry32(seed)`）/帧间累积状态
4. 预览循环允许 rAF，但画面只由 t 决定
5. 中文显式写 `"Noto Sans CJK SC"`；负面约束（无水印/无真实 logo）写进生成提示词

### 第 3.5 步：引擎库速查（window.OV）

**缓动 E**（禁 linear）：入场 `outExpo/outQuint`，退场 `inCubic/inExpo`，镜头 `inOutCubic/inOutSine/cine`，回弹 `outBack/outElastic/outBounce`。

**元素运动 MOVE**：`entrance(t,at,dur,{dy,dx,scaleFrom,ease})` 返回 `{p,e,dx,dy,scale,alpha}`；`exit`；`stagger(t,at,i,stag,dur,dy)` 错帧；`countUp/drawOn/float/spring/alongPath`。

**2D 运镜 SHOOT（72 个，全部返回 `{x,y,zoom,rot,blur}`；世界系平移：正 x 内容右移）**：
- 基础 7：`pushIn/pullOut/pan/whipPan/handheld/impact/breathe`
- 增强 9：`dolly/crane/arc/orbitMove/zoomPunch/dutch/roll/vertigo/tilt`
- 翻倍 19：`dollyZoom/orbit360/spiral/figure8/snorricam/steadicam/truckLeft/crab/pedestal/follow/reveal/whipTilt/shake/floatDrift/rampSpeed/circleDolly/pushPullBreath/rollOrbit/tiltShift/lazySusan`
- 再翻倍 36（曲线类）：`helixUp/doubleHelix/lissajous/roseCurve/epitrochoid` 数学曲线轨迹
- 再翻倍 36（节奏类）：`easeZoom/heartZoom/stairDolly/surgePull/dropDown/riseUp/peakDive/swayLR/nodUD/jitterHi/driftWind/rampDown/pulseAccel/stutterStep/slowMoZone`
- 再翻倍 36（reveal 类）：`cornerPeek/blindOpen/irisOpen/doorSwing/curtainUp/splitZoom/mirrorPan/cornerPeel`
- 再翻倍 36（运动类）：`pendulumSwing/waveRide/tornadoSpin/orbitEllipse/dollyArcBack/craneBoom/flyThrough/barrelRoll`
- 叠加：`compose(t,shots)` 自由叠加；`sequence(t,shots)` 镜头表 `[{from,to,move:"dolly",arg:[...]}]`——**多机位剪辑用这一个驱动整段**
- 应用：`apply(ctx,cam,w,h)` 一行应用；**UI 层在 restore 后画**，只跟 0.5 倍微抖
- 窗口型运镜（whipPan/zoomPunch/impact/whipTilt/shake）**窗外必须归零**，勿 Hold（已修）
- 注意 `pushPullBreath(t,period,k)` 周期参数别传 0（sin(t/0)=NaN）

**3D 摄影机 Camera3D**：
```js
const cam = new OV.Camera3D({x,y,z, fov:980, cx:W/2, cy:H/2, fogNear:1500, fogFar:3400, fogColor:bg});
cam.lookAt({x,y,z}); cam.roll = 0.01;
cam.render(ctx, faces);          // 画家算法+法线背面剔除+方向光+雾，一步到位
const pr = cam.project(point);   // {x,y,z,scale,fog,alpha} 或 null(近裁剪)
```
- 路径运镜：`OV.UTIL.catmullRom(points,80)` 平滑 + `OV.UTIL.samplePath(path,u)`
- 环绕：`D3.orbit(t,a,b,{a0,a1,r0,r1,y0,y1})`；推轨：`D3.dolly`
- 几何：`D3.cube(cx,cy,cz,size,color,{stroke,glow})`（法线自动计算）、`D3.sphere`、`D3.line(a,b,color,width,alpha)`（**必须传 Vec3：`D3.V(x,y,z)`**）、`D3.grid`、`D3.field(n,{seed})`
- 旋转：`D3.spinFace(f, ang, tilt)`
- 剔除用世界空间法线（`normal·(camPos-faceCenter)>0` 可见），不存在屏幕绕序问题

**排版 TYPE（22 个）+ LOOK（12 个）= 34**：
- `perChar(ctx,text,t,at,{x,y,font,color,stagger,glow})` 逐字入场；`wrap` 折行；`cycle(t,words,at,each,fade)` 叠化轮播；`stat(t,at,dur,to,{prefix,suffix,decimals})` 数字滚动
- 翻倍 7：`lineMask` 行遮罩揭幕 / `scramble` 乱码逐位锁定 / `splitReveal` 分裂揭示 / `waveText` 波浪起伏 / `stamp` 砸章盖章 / `stackText` 堆叠落位 / `countdown` 倒计时
- 再翻倍 11：`typeOn` 机打+光标 / `blurIn` 模糊聚焦 / `flipChar` 翻牌 / `dropChar` 重力落字 / `neonFlicker` 霓虹闪烁 / `glitchText` RGB 分离故障 / `wavePath` 波浪路径 / `bubbleText` 弹跳 / `rotateIn` 旋入 / `shatterText` 碎裂四散 / `matrixChar` 矩阵字符雨
- LOOK（OVX，需先加载 fx-plus.js）12 个：`gradientText` 渐变字 / `keyword` 关键词扫过 / `typewriter` 打字机+光标 / `neon` 霓虹 / `outlineText` 描边字 / `marquee` 跑马灯 + 新 6 `chromeText` 金属银渐变 / `glassText` 玻璃半透 / `fireText` 火焰 / `iceText` 冰晶 / `rainbowFlow` 彩虹流 / `stroke3D` 3D 凸出

**时间 TIME**：`beat(t,bpm)` 节拍网格；`pulse(t,at,bpm,decay)` 踩点脉冲；`keyframes(t,kf,ease)` 关键帧。

**后期 FX（40 个）**：`motionBlur/vignette/grain/glow/letterbox(2.35)/scanlines/scrim/flash/grade` + 翻倍 10 `halation/lightLeak/filmBurn/chromatic/glitch/bokeh/vhs/dreamy/duotone/rgbPulse` + `godRays` 丁达尔光束 + 再翻倍 20：`dof/irisBlur/radialBlur/tiltBlur` 四档景深模糊（离屏半分辨率+条带裁剪）/ `rain/snow/dust/fogLayer/starfield/bokehFloat` 确定性粒子层 / `lightShaft/edgeGlow/anamorphic` 光效 / `heatWave/underwater/crtCurve/hologram` 环境扭曲 / `pixelMosaic` 局部马赛克 / `lutGrade` 6 预设 LUT 分级（tealOrange/bleach/noir/golden/cyber/cross）/ `filmGate` 片门抖动。推荐叠加顺序：scrim(压角)→vignette→grain→flash(踩点)→letterbox；氛围镜加 halation+lightLeak+godRays，冲击镜加 chromatic+glitch+rgbPulse+radialBlur，天气镜加 rain/snow/fogLayer，风格化加 lutGrade+crtCurve。

**噪声**：`noise1(seed)` 手持抖动；`noise2/fbm2(seed)` 流体云雾；`mulberry32(seed)` 确定性随机。

### 第 3.6 步：增强包 OVX（追求电影感时引入）

`<script src="fx-plus.js"></script>`（必须在 motion-3d.js 之后）。

**PBR 材质 MAT**：对每个可见面调 `MAT.shade(face, cam.pos, {shininess, specK})` 返回 `{fill, spec, edge}`——三灯模型（主光/补光/轮廓光）+ 环境光遮蔽近似 + Blinn-Phong 高光（窄高光+宽光泽双分量）。自绘渲染循环时用它替代 cam.render 的简单着色；`edge` 用于描边强度（掠射面轮廓光）。

**投影阴影 SHADOW**（比阴影贴图便宜 100 倍，视觉收益极大）：
- `SHADOW.blob(ctx,cam,{x,y,z,size}, groundY, {alpha,spread})` 软阴影椭圆，按高度衰减
- `SHADOW.contact(...)` 接触暗边，让物体"站得住"
- `SHADOW.beam(...)` 体积光柱

**粒子 PARTICLE**：
- `make(n,{seed,...})` 确定性粒子池
- `drift(ctx,cam,pool,t,{color,alpha})` 飘升尘埃
- `burst(ctx,cam,origin,t,at,{n,speed,dur})` 踩点爆发（配 impact/beat 用）
- `network(ctx,cam,pool,t,{maxD})` 距离连线网络（科技感标配）

**背景 BG**：`fluid(ctx,w,h,t,{cell,c1,c2,c3,glow})` fbm 流体噪声背景（比纯渐变高级）；`techGrid` 滚动网格；`spot` 聚光。

**镜头 LENS**：`flare(x,y,r,color,alpha,t)` 镜头光晕（核心+光条+光环）；`dispersion(ctx,canvas,w,h,amount)` RGB 色散（踩点时用）；`barrel` 镜头畸变。

**文字 LOOK（12 个）**：`gradientText` 渐变字；`keyword` 关键词高亮扫过；`typewriter` 打字机+光标；`neon` 霓虹发光；`outlineText` 描边字；`marquee` 跑马灯 + 新 6 `chromeText` 多段银渐变+深描边 / `glassText` 半透填充+内描边高光 / `fireText` 暖渐变+摇曳辉光 / `iceText` 冷青+白霜边+晶粒 / `rainbowFlow` 色相循环渐变 / `stroke3D` 层叠侧壁+顶面。

**天气 WEATHER（5 个）**（确定性粒子，全屏氛围层，`opt={}` 可调 n/alpha/color）：
- `rain(ctx,w,h,t,{n})` 风斜雨丝 + 落地溅点；`snow` 摇摆飘落 + 大小景深
- `dustMotes` 上浮闪烁光尘；`fogBank` 低频漂移雾块（椭圆缩放）
- `storm` 雨 + 周期性闪电双闪（0.12s / 0.3-0.4s 节奏）

**景深 DOF（3 个）**（离屏半分辨率 + filter blur，与 FX.dof 家族同源）：
- `focusBlur(ctx,w,h,{amount,hole})` 焦点圆清晰 + 外围渐进模糊
- `tiltShift(ctx,w,h,{band,amount})` 移轴微缩：中央清晰带 + 上下模糊
- `bokehField(ctx,w,h,t,{})` 焦外大光斑场（慢漂柔焦圆盘）

自绘 PBR 渲染循环模板（替代 cam.render）：
```js
for (const f of faces) { /* 投影+法线剔除+按z排序 */ 
  const sh = MAT.shade(f, cam.pos, f._mat);
  ctx.fillStyle = sh.fill; ctx.fill();
  ctx.strokeStyle = rgba(f.stroke, 0.25 + sh.edge*0.75); ctx.stroke();  // 轮廓光描边
}

### 第 4 步：snap 抽帧调试（省 80% 时间）
`python3 snap.py scene.html 0.5 2.6 8.1 11` → Read 目检。**每改一次必抽帧**，确认后再全量。

### 第 5 步：全量渲染
`python3 render.py scene.html frames/ 30`。性能参考：2D ≈0.014s/帧；3D+后期 ≈0.10s/帧（360 帧约 37s）。红线：`ctx.filter` 半径封顶 2.5px、`blur>1` 才启用。

### 第 6 步：配乐 + 合成
```bash
python3 audio.py bgm.wav --dur 12 --bpm 120 --mood tech --hits 4,8   # hits=踩点秒数
ffmpeg -y -framerate 30 -i frames/f%04d.png -i bgm.wav \
  -c:v libopenh264 -b:v 8M -pix_fmt yuv420p -c:a aac -b:a 192k \
  -shortest -movflags +faststart final.mp4
```
- 有 libx264 时优先 `-c:v libx264 -crf 20`；沙箱用 `libopenh264`
- **24 种 mood**：`tech/epic/chill/cinematic/lofi/trailer`（原 6）+ `horror/action/romance/scifi/docu/retro`（翻倍 6）+ `ambient/synthwave/jazz/rock/dnb/trap/folk/bossa/noir/space/cyber/battle`（再翻倍 12）——cinematic（钟琴+拍手+风+泵动+4 分琶音）、trailer（riser+重鼓）、lofi（黑胶噪声+swing）、horror（不协和音+迫降低频）、action（双踩+军鼓滚奏）、romance（钢琴+弦乐pad）、scifi（方波琶音+ring mod）、docu（马林巴+柔鼓）、retro（风琴+vinyl）、ambient（无鼓+低鸣床+风铃）、synthwave（80s 复古+电子脉冲）、jazz（swing+沙锤+马林巴）、rock（双踩+强 pump）、dnb（碎拍+密琶音）、trap（808 贝斯+黑胶）、folk（木音+沙锤）、bossa（swing+沙锤+马林巴）、noir（风琴+风+迫低）、space（低鸣+风铃+脉冲）、cyber（电子脉冲+密琶音）、battle（太鼓+锣+泵动）
- 新音色钩子（v2）：`taiko` 太鼓替换 kick 音色 / `gong` 小节头锣击 / `shaker` 反拍沙锤 / `chime` 随机风铃 / `pulse` 电子脉冲 / `drone` 低鸣床——按 mood 字典键自动编排
- 分层：鼓组（kick/snare/hat 型可配）+ 贝斯 + pad 铺底 + 琶音 + 转场音效；`--intro/--outro` 控制淡入淡出
- **音效库 SFX 44 个**（`--sfx "3.0=impact,6.0=whoosh:0.8"`，秒=音效名[:增益]）：
  原 11：`whoosh / impact / boom / riser / click / shutter / clap / tom / heartbeat / sparkle / wind`
  翻倍 11：`glass / metal / wood / water / fire / thunder / coin / door / ui / error / success`
  再翻倍 22：`laser / zap / sweep / upsuck / punch / pop / splat / chime / gong / taiko / shaker / cymbal / drone / pulse / glitch / typekey / swipe / magic / powerup / heal / camera / dial`
- **mix 子命令**：`python3 audio.py mix.wav --dur 12 --music my.wav --sfx "3=impact"`——给已有音乐单独铺音效轨
- `--music-gain`（默认 0.72）/ `--sfx-gain`（默认 0.95）分别控音乐与音效音量
- 音频已留 2.5dB 余量（AAC 编码会抬高峰值，实测 0.89 增益会顶到 0dB）

### 第 7 步：publish_check（发布门禁，全过才算完成）
```bash
python3 publish_check.py final.mp4 --expect 1280x720 --fps 30 --dur 12 --contact contact.png
```
17 项：h264/yuv420p/分辨率/偶数宽高/帧率/时长/帧数/音轨/音画差/响度/峰值/静音/首末帧亮度/黑屏占比/冻结帧/体积 + 抽帧拼图（Read 目检）。exit 0 才能交付。

### 长片（多场景）：assemble.py
写 `film.json`（scenes 数组 + transition + audio + subtitles），一条命令产出完整长片：
```bash
python3 assemble.py film.json            # 并行渲染→统一规格→转场(xfade)→配乐→字幕(.srt)
python3 assemble.py film.json --burn-subs # 字幕烧进画面（libass，Noto CJK）
```
- 转场类型（**40 种 xfade 映射**）：`fade / whip(滑动) / dissolve / zoom / wipe / dipblack(渐黑)`（原 7）+ 翻倍 11 `glitch / rgbGlitch / flashCut / circleWipe / slideUp / smoothZoom / pixelize / radial / diagWipe / vSlice / hBlur` + 再翻倍 20 `wipeRight / wipeUp / wipeDown / slideRight / slideDown / circleOpen / circleClose / rectCrop / vertClose / distance / fadeGrays / diagTL / diagBL / diagBR / vSliceD / wipeTL / wipeTR / wipeBL / wipeBR / smoothLeft`；`cut、jcut` 走 concat 硬切（不进 xfade）。全局默认+每场景可覆盖 `transition_in`
- 全部 38 个 xfade 目标已本地 ffmpeg 实测（`rectclose/rectopen` 在该版本未实现，已换 `rectcrop/vertclose` 等价映射；映射失败自动退化硬切）
- 转场时长会计入重叠：总时长 = Σ场景时长 - Σ转场时长（已实测校准）
- hits 的秒数按**拼接后全局时间轴**填
- 修改某场景后删除 `_build/frames/scN` 再跑，只重渲该场景
- 产出后按提示直接跑 publish_check

**剪辑点自动踩点**（无需手填 hits）： assemble.py 收集每个 `transition_in` 的发生时刻，按转场类型自动排音效——
| 转场 | 自动音效 |
|---|---|
| cut / jcut | 前 0.12s whoosh + 当点 click |
| whip | 前 0.35s whoosh + 当点 impact |
| dipblack | 前 0.4s riser + 当点 boom |
| fade/dissolve/zoom/wipe | 前 0.3s whoosh |
| glitch/rgbGlitch | 前 0.25s metal + 当点 click + error |
| flashCut | 前 0.3s riser + 当点 impact |
- 叠加显式 cues：`"audio": {"sfx": "7.7=impact:0.85,9.55=click"}`（如镜头内鼓点/标题落点）
- xfade 成功后时间轴前移，踩点 cue 会同步前移（已修）；`cut` 走 concat 硬切不缩时长
- 多机位剪辑范式：每镜头独立 html（各自 DURATION），运镜用 `SHOOT.sequence` 镜头表；参考 `film2/` 四机位演示（3D→地形→物理→文字卡，whip/cut/dipblack 混用）与 `film3/` 翻倍能力展示（PLY 导入+实例化+轮廓 → volcano biome+8 调色板 → 磁场/绳索/软体/爆炸，flashCut/glitch 新转场）

### 实时预览：preview.py
```bash
python3 preview.py scene.html --port 8080   # 浏览器打开 http://127.0.0.1:8080/scene.html
```
- 文件保存自动刷新（mtime 轮询）；空格播放/暂停；←→ 单帧步进
- 通过 HTTP 提供文件，解决 file:// 跨文件引用（motion-3d.js 加载失败的问题）
- 浮层显示时间码/总时长/帧数

### 交付
1. 成片放 `/workspace`，语义命名
2. `present_files` 呈现成片（+可选拼图）
3. 附说明：主题/时长/规格/亮点 + 迭代指引（"改第 N 秒 → 改 scene 对应段 → 重跑 render.py"）

### 片尾署名卡（发布标配）
每个样片/成片在结尾 2s 放署名卡——Skill 名「制作视频」+ 开发者「叶羊大佬」。实现惯例（三个样片均已内置，可直接抄）：

```js
const CREDITS_T = 12;   // = 原 DURATION；DURATION 再 +2
/* renderFrame 内，UI 层之后、FX 后期之前： */
if (t >= CREDITS_T) {
  const ct = t - CREDITS_T;
  const ov = Math.min(1, ct / 0.5) * (ct > 1.6 ? Math.max(0, (2.0 - ct) / 0.4) : 1);
  ctx.save();
  ctx.fillStyle = `rgba(8,14,24,${0.88 * ov})`; ctx.fillRect(0, 0, W, H);   // 暗幕（ scene 继续在幕后动）
  if (ov > 0.05) {
    TYPE.perChar(ctx, "制作视频", ct, 0.15, { align: "center", x: W/2, y: 286, tracking: 16,
      font: "300 32px 'Noto Sans CJK SC', system-ui", color: "rgba(255,233,214,0.62)", dur: 0.7, alpha: ov });
    TYPE.perChar(ctx, "叶羊大佬", ct, 0.55, { align: "center", x: W/2, y: 392,
      font: "800 84px 'Noto Sans CJK SC', system-ui", color: "#ffe9d6",
      stagger: 0.1, dur: 0.8, dy: 46, glow: "rgba(255,150,80,0.9)", alpha: ov });
    const cul = MOVE.drawOn(ct, 1.0, 0.6, E.inOutQuint);
    if (cul > 0) { ctx.globalAlpha = cul * ov; ctx.fillStyle = "#ff9a5a"; ctx.fillRect(W/2 - 110, 424, 220 * cul, 3); }
    /* 第三行小字：本片技术亮点（可选） */
  }
  ctx.restore();
}
```

- 原 UI 层（标题/HUD/cycle）用 `if (t < CREDITS_T)` 包起来，避免与署名卡重叠
- 相机路径最后一个关键帧会在署名段自动钳位静止，水面/粒子继续动（time 驱动）——幕后"活的"暗幕比纯黑更有质感

## 实战坑表（全部实测踩过）

| 坑 | 解法 |
|----|------|
| 运动廉价/卡顿 | 禁 linear；MOVE.entrance+stagger；静止期加 float/handheld/grain |
| 3D 主体消失/飞出 | 勿手写 yaw/pitch 旋转；用 Camera3D 正交基（已内置） |
| 相机穿进方块（大黑面吞屏） | 运镜路径避开几何体；y 拉高、远离 ring 半径；snap 逐段检查 |
| 屏幕绕序剔除误杀 | 已改为世界空间法线剔除；cube 法线由面心-体心对齐，自动正确 |
| D3.line 报 a.add is not a function | 端点必须 Vec3：`D3.V(x,y,z)` |
| UI 与 letterbox/卡片重叠 | 布局先算遮幅高度（w/2.35 的上下边）；入场元素相互错开或前序淡出 |
| ctx.filter 拖慢 10 倍 | 封顶 2.5px、>1 才启用 |
| AAC 后峰值顶 0dB | audio.py 已留余量；自调音频峰值 ≤-1.5dB |
| ffmpeg 缺 libx264 | `libopenh264 -b:v 6M~8M` |
| 中文方块 | 字体写 `Noto Sans CJK SC` + `document.fonts.ready` |
| 渲染结果不可复现 | 场景混入 Date.now/random/累积状态，违反帧契约 |
| 手机黑屏 | 缺 `-pix_fmt yuv420p` |
| 场景脚本静默失败 | renderFrame undefined → 用 pageerror 捕获（snap 会超时报错） |
| 暗色成片被判"黑屏" | 深色主题 luma≈0.02，publish_check 已将 pix_th 调至 0.03 |
| 标题卡被判"冻结帧" | 静止卡正常；但遵循"永远有微动"（float/handheld），占比>45% 才 FAIL |
| xfade 拼接后时长没缩短 | 转场类型没进实现映射表（whip→slideleft）；assemble.py 已内置 |
| file:// 下 motion-3d.js 加载失败 | 用 preview.py 走 HTTP，或把场景和库放同目录 |
| PBR 高光恒为 0 | 大平面近看 n·half 很难接近 1；OVX 已用窄高光+宽光泽双分量，勿改回单 pow |
| 粒子/网络太抢戏 | network 包一层 globalAlpha 0.5；burst 只在踩点用 |
|  whipPan 播完内容永久偏移出屏 | 窗口外必须归零（已修）；震屏/变焦类同理——窗外返回单位值，别 Hold |
| ctx.ellipse 报 7 arguments required | ellipse(x,y,rx,ry,rot,start,end) 要 7 参，阴影椭圆常漏起始角 |
| D3.cube(ctx,cam,...) 画不出东西 | D3.cube 是**几何生成器**返回面数组，渲染走 `cam.render(ctx, faces)`；D3.grid/orbit 同理 |
| D3.grid 传了 (ctx, cam, opts) 却没画 | grid(cam, opt) 返回**点对数组**且不用 cam 参数；需 `gl.map(([a,b]) => D3.line(a,b,c,1))` 后一次 `cam.render`——film2 曾因此丢了地面网格（不报错，最难发现） |
| D3.line 端点传普通对象崩 | field() 返回 `{x,y,z}` 裸对象，line 要 Vec3：`D3.V(d.x,d.y,d.z)` |
| Vec3 cannot be invoked without 'new' | OV 导出的 Vec3 是类；端点用 `D3.V(x,y,z)` |
| 文字版式被运镜推飞出画 | vertigo 硬编码 340px 平移；文字卡用 pushIn/pan/roll，忌大平移 |
| OVT 地形选位选到水下 | `sample()` 返回 h×amp（0..amp），水面=water×amp；先用 node 扫高度图再定相机关键帧 |
| OVT.render 调色板/太阳/雾全不生效 | `render(ctx, T, cam, opts)` 是 **4 参**：相机与选项必须分开两个对象传；合并传成 cam 则 opts=undefined，全部静默 fallback natural（不报错，最难发现） |
| 模型 draw 出 0 面（全被剔除） | OBJ/STL 面绕序决定法线；数据内翻时从外部看全是背面。写测试数据时逐面用右手定则核绕序 |
| 批量调运镜出 NaN | 非 `(t,a,b)` 签名的运镜（pushPullBreath/impact/zoomPunch/shake…）别用 `(t,0,2)` 占位调用，period/at 传 0 会 NaN |
| STL 导入后 outline 无线条 | STL 逐面存顶点无共享索引，必须先 `OVM.weld`（fromSTL 已内置）；outline 用几何量化键兜底 |
| 菲涅尔反射恒为 1（水面死白） | 视线 rd 朝下时 `dot(rd,N)` 为负 → `max(0,vd)` 恒 0 → F 恒 1；必须用 `nv = max(0, -dot(rd,N))`（CPU renderWater 与 GPU shadeWater 同约定） |
| 海面水带只有几 px（特效全 skip） | 旧版 colTop 混合陆地/水面命中，纯水列收敛到地平线，`top<=horizon` 把整片海面 skip；须单独 colLand 追踪陆地露出，纯水列水带延伸到屏幕底 |
| assemble.py 重渲染已渲染场景（playwright 超时） | 帧目录是 **0-based `sc0`**（不是 sc1）；放错 → isdir False 触发重渲染，headless 无 GL 直接超时 |
| headless WebGL 全 null | swiftshader 参数组（`--use-gl=swiftshader` 等）在新版 Chromium 全被禁；必须 `xvfb-run -a` 包裹 + `headless=False` + `--use-gl=desktop`（mesa GLX）才拿得到 context |
| xfade `rectopen/rectclose` 报 Not yet implemented | 本地 ffmpeg 版本未实现该族；已换 `rectcrop/vertclose` 等价映射，映射表失败会自动退化 concat 硬切 |
| 布料/摆链求解抖动发散 | PBD 迭代数与弹簧刚度联动：cloth 结构 stiff=1.0 硬约束 + 剪切 0.45 软；w 风质量默认 0.5，别超过 2.0 |


### 何时用 GPU 层（决策表）

| 需求 | 用哪层 |
|---|---|
| 标题/字幕/图表/转场/胶片颗粒 | Canvas 2D（OV/OVX）——永远够用 |
| 真实软阴影、镜面反射、体积光、雾 | WebGL（OVGL raymarching） |
| 二者都要 | 双画布合成：gl 底层 → `#frame` UI 层，抓 `#frame` |

### 参考场景
`gpu-sample.html` —— 完整 GPU 双画布样片源码（相机关键帧 + beat 踩点 + UI 合成 + FX 后期），新 GPU 项目直接复制改造。

## 程序化地形 + 贴图（terrain.js / window.OVT）

确定性种子噪声高度图 + 体素列投射（Comanche 风格轮廓投射）。渲染约 0.15s/帧 @720p，360 帧并行 4-worker 实测 **73 秒**——需要"自然大片"时优先用它而不是 GPU raymarching。

```html
<script src="terrain.js"></script>
<script>
const T = OVT.generate({ seed: 7, size: 256, scale: 0.02, amp: 2.2, water: 0.32, rough: 0.5 });
OVT.render(ctx, T, { x, z, yaw, lift, alt: 1.5, pitch: 0.14, fov: 1.1 },
  { palette: "natural", sun: [0.9, 0.75], fog: [175,200,218], maxDist: 150 });
</script>
```

- `generate(opts)`：seed 固定即完全可复现；`amp` 振幅、`water` 水面（0..1 相对高度）、`rough` 细节占比；内置对比拉伸 + 山脊层（局部隆起雪山）+ 边缘岛屿衰减
- `render(ctx, T, cam, opts)`：相机 `{x,z,yaw,lift,alt,pitch,fov}`；贴图五档（水/沙/草/岩/雪）按 `hn=表面高度/amp` 查档——**`amp` 越大档位越往低跑**（amp=2.4 时 hn 上限 0.42，只有沙+草；amp≈1.0 五档全reachable，坡度>0.22 另走岩壁色）
- **贴图细节**：世界坐标 fbm + 细粒 hash 双层扰动颜色（岩石斑驳/草色变化）；法线差分光照 + 距离雾 + 水面高光
- 内置调色板（16 个）：`natural / sunset / desert / alien` + 翻倍 4 `tundra / volcano / jungle / moon` + 再翻倍 8 `dawn / ocean / cherry / cyber / ash / aurora / toxic / vintage`；`res` 列步长可换性能（2 = 快一倍略糙）
- **biome 预设（16 个）**：`OVT.generate({ ...OVT.BIOMES.alpine, seed: 3 })` 直接出对应地貌高度参数——`archipelago / continent / alpine / volcano / tundra / jungle / moon / lake` + 再翻倍 8 `canyon / reef / mesa / glacier / swamp / highland / badlands / oasis`
- 相机路线用对象关键帧自己插值（`TIME.keyframes` 只支持数值/数组）；`yaw` 记得最短角
- 坑：俯仰 `pitch` 会移动地平线，天空会自动铺到地平线；`lift` 是离地间隙（amp 单位，0.3~0.7；负值可贴翼掠飞）；`sample()` 返回 h×amp，水面高度=water×amp——选机位先用 node 加载 terrain.js 扫高度图，避开大面积浅水

### GTA 式随机世界生成（`OVT.world(seed, opts)`）

`generate()` 是参数化调地貌；要 **"每帧世界都不同、非预定地图"** 的开放世界感，用 `world()`——域扭曲 + 山脊噪声 + 热扩散侵蚀 + 高度×湿度 biome 分布，一个 seed 一座完整大陆：

```js
const T = OVT.world(2026, { size: 256, water: 0.26, amp: 2.6, ridge: 0.62, warp: 0.50 });
// T = { h, wet, biome, size, seed, water, amp }——biome 为逐格类型图
const b = OVT.BIOME_NAMES[T.biome[cy * T.size + cx]]; // 0 深海 … 6 雪顶
```

- **domain warping**：采样坐标先被一层 fbm 扭曲（`px = x + qx*size*0.18*warp`）——海岸线不再是平行噪声纹，出现 GTA 式"被揉过的"大陆轮廓
- **ridged multifractal**：`(1-|noise*2-1|)²` 脊线噪声叠 4 octave，配合 `sstep(0.45,0.72)` 山脉掩码——山脊成脊、山谷成型，不是糊掉的凸包
- **热扩散侵蚀**：2 轮 talus 搬运（坡度 >talus 的格按高差往低邻搬运 `min(c*0.5, d*0.35)`）——消除噪声毛刺，山脚出现真实冲积扇
- **7 类 biome**：按高度×湿度（`wet` 第二层噪声）分类——0 深海 / 1 浅海 / 2 沙滩 / 3 森林 / 4 草原 / 5 岩石 / 6 雪顶；渲染时 `BIOME_TINT` 乘性叠色（森林偏绿、草原偏黄、雪顶偏冷）
- **确定性**：同 seed 逐位可复现（回归已验）；不同 seed 高度图差异 >80%（实测 98.2%），随机感真实
- 参考样片：`world-sample.html`（三段 × 4s 每段一个新 seed 世界，HUD 实时显示当前 biome 名）

### 连续渲染 v3（马赛克根治）

旧版马赛克感来自 5 处硬切：纹理 `hash2(floor(wx*24))` 每 1/24 格硬跳变 / 高度色带分段常数 / 坡度 `slope>0.22` 一刀切 / 山脊 `max(0,mount-0.44)` 硬断层 / 云层 8px 横条 `fillRect`。v3 全部改连续：

- **高度色带**：`bandColor(pal, hn, out)` 五档间线性插值，色带无级过渡
- **坡度混合**：`sstep(0.10, 0.30, slope)` 连续混入岩壁色，崖壁有渐变岩土带
- **山脊层**：`sstep(0.42, 0.62, mount)` smoothstep，雪山轮廓连续
- **纹理**：双层低频 fbm（`wx*3.5` 幅度 20 + `wx*10` 幅度 7）——**高频 fbm 沿列投射射线步长 0.22 会混叠出等高线横纹**，必须降频（CPU+GPU 同步）
- **云层**：按列连续 fbm 密度三段竖直渐变，消除横条
- **`res>1` 列间插值**：span 收集 + 列间逐像素 lerp，低性能档也无竖纹
- **列内逐行插值（v4，梯田纹根治）**：逐 span 平涂会在崖壁留下 10~14px 硬边梯田（马赛克感最后根源）；v4 每列收集 span 采样点后按 piecewise-linear 逐行插值写 ImageData → 连续竖向渐变，硬边全消（实测崖壁硬边 4 条→1 条真实地平线）；dStep 同步 0.22→0.16
- GPU 侧同源修复：`marchTerrain` 加**线性穿越精化**（射线在步间穿过高度场时插值交点）→ 每像素命中连续，梯田量化边消失

### 水渲染（terrain.js 内置）

- `opts.time`（传帧时间 t）驱动**波浪粼光**：多频正弦高波峰画短亮段，只在太阳方向成镜面带
- **深度渐变水面**：近处深、远处雾化；**太阳镜面**亮点随距离增强
- **岸边泡沫**：水位线附近列画白沫渐变；**浅水透色**：水下地表透出蓝绿；**湿沙暗带**贴岸加深
- **fbm 云层天空**：随 t 缓慢漂移；`sunset` 黄昏调色板（暖天空/暖雾/暖镜面）
- 用法：`OVT.render(ctx, T, cam, { palette: "sunset", time: t, sun: [角度, 强度], fog: [r,g,b] })`
- 调色板：`natural / sunset / desert / alien / tundra / volcano / jungle / moon / dawn / ocean / cherry / cyber / ash / aurora / toxic / vintage`（16 个）；地形增强：坡度连续混合岩壁色、山脊层雪山、湿沙带
- 参考样片：`water-sample.html`（黄昏海岸）、`terrain-sample.html`（草原湖泊）

### CPU 实时水面（`waterMode: "realtime"`）

把上面经典水换成 **真实波动物理高度场**——14 个 Gerstner 正弦叠加（13 低频涌浪 + 1 高频涟漪 `k=1.15, a=0.0045, w=4.5`），有限差分求法线，整帧实时重算：

```js
OVT.render(ctx, T, cam, { palette: "sunset", time: t, sun: [0.9, 0.75], fog: [...],
                          waterMode: "realtime" });   // ← 一行切换
```

- **独立入口**：`OVT.water(ctx, terrain, cam, opts)` 即 `renderWater`——直接调它只画水层（天空+陆地已画时做增量）
- **波浪法线天空反射**：菲涅尔 `F = 0.05 + 0.95*(1-nv)^4.5`（`nv = max(0, -dot(rd, N))`）——俯视 F→0.05 不是死黑，加 `skyRef*0.08` ambient 兜底
- **太阳镜面 + 屏幕方位窄带反光路径**：Blinn-Phong `pow(240)*1.6` + `exp(-(dAng*3)²)` 窄带（波高越大越亮）——太阳在水面拖出的真实光路
- **岸边泡沫**：`shore<0.5` 极浅窄带白沫 + 波峰 `hC>0.046` 白丝，动态破碎
- **ImageData 快路径**：水带整写 `ImageData`（ABGR 小端 pack），比逐像素 fillRect 快一个量级；720p 单帧水面约 5ms
- 实测帧间像素差 9.09（无重绘则 0）——实时流动的回归断言；参考样片 `water-sample.html`（`waterMode:"realtime"` 版）

## 确定性物理 + 3D 模型加载（physics.js / model3d.js / models.py）

### OVP 物理引擎（`window.OVP`）
固定步长积分（默认 1/240s），`poseAt(t)` **每帧从 t=0 重积分**——天然满足帧契约（并行渲染逐位一致）。
```js
const PHY = OVP.scatter(OVP.world({ gravity: [0, -520, 0], ground: -180 }), 12,
  { radius: 300, height: 380, seed: 21, rMin: 40, rMax: 72, e: 0.62 });
const balls = PHY.poseAt(t);   // [{p:[x,y,z], v, r, color, ...}]
```
- 支持：重力 / 地面反弹（弹性 e）/ 球-球冲量碰撞 / 边界墙 / `drag` 空气阻力
- **翻倍四能力（v2）**：`w.rope(anchor, n, {seg})` 绳索（6 迭代 PBD 抗拉伸，首节 pin 锚定）/ `w.soft(cx,cy,cz,{n,radius})` 软体（fibonacci 球壳+压力径向恢复+邻居弹簧）/ `w.explode({at,x,y,z,radius,power})` 定时爆炸（跨时刻一次性径向冲量）/ `w.attract({x,y,z,strength,radius,t0,t1})` 磁场（线性衰减吸附）
- **再翻倍五能力（v3）**：
  - `w.cloth(cx,cy,cz,{nx,ny,seg,wind})` 布料：nx×ny 质点网格 + 结构弹簧（硬）+ 剪切弹簧（软，对角）+ 确定性风场（基准风+阵风+相位偏移）；顶行每隔 `pinEvery` 列锚定（`pinTop:false` 全自由）
  - `w.spring({a,b,anchor,rest,k,damp})` 显式弹簧：胡克位置修正 + 法向阻尼；b 省略时连世界坐标锚点（悬挂/弹绳）
  - `w.pendulum(anchor, n, {seg,theta,phi})` 刚性摆链：多节硬距离链，可设初始摆角松手做钟摆运动
  - `w.vortex({x,y,z,axis,radius,strength,pull})` 涡流：绕轴切向旋转 + 径向吸引（龙卷风/排水口）
  - `w.turbulence({strength,scale,speed})` 湍流：确定性伪 curl 噪声风场（旗帜/落叶/尘埃）
- 场力时间窗 `t0/t1` 全部支持（`Infinity` 为永久生效）
- **单位必须与相机像素级一致**：世界即屏幕单位。720p 场景重力约 -520、球半径 40~78、离地 380px ≈ 1.2s 着地（可预算踩点时刻）
- `scatter(w,n,{radius,height,seed,rMin,rMax,e,colors})` 确定性撒球；seed 固定即可复现
- 坑：爆炸 `at` 恰为 dt 整数倍时浮点会同时跨过两侧步长导致不触发——已加 EPS 容差 + fired 本地副本修复；直接引用 explosions 会破坏 poseAt 幂等
- 参考样片：`physics-sample.html`

### OVM 3D 模型引擎（`window.OVM`）
```js
OVM.load("barrel_03.json", m => { MESH = m; window.renderFrame = _renderFrame; }); // 异步！
OVM.draw(ctx, MESH, cam, { pos:[0,-150,60], scale:195, yaw:t*0.9, color:[205,155,95],
                           light:[0.4,0.9,0.4], spec:0.55, specShininess:18, edge:"rgba(255,220,180,0.12)" });
```
- 画家算法平面着色 + 背面剔除 + Blinn-Phong 镜面高光；适配 `Camera3D`（`cam.project`）
- **四种导入**：`OVM.load(url)` 网格 JSON / `OVM.fromOBJ(text)` / `OVM.fromSTL(str|ArrayBuffer)`（ASCII+二进制，自动 weld 顶点焊接）/ `OVM.fromPLY(str|ArrayBuffer)`（ASCII+二进制 LE/BE，Quad 扇形三角化，附加属性自动跳过）
- **翻倍渲染**：`OVM.instanced(ctx, mesh, cam, items, opts)` 同网格多实例批绘（items=[{pos,scale,yaw,pitch,color,...}]）；`OVM.outline(ctx, mesh, cam, opts)` 剪影视廓描边（先 outline 后 draw 盖心；expand 控厚度、width/color/glow 可控）；`OVM.stats(mesh)` 顶点/面数/包围盒；`OVM.weld(m)` 顶点焊接+去退化面
- **加载竞态**：XHR 完成前不得暴露 `window.renderFrame`，否则出黑帧；render.py/snap.py 已带 `--allow-file-access-from-files`

### models.py 模型搜索下载（Poly Haven 免密钥，全 CC0）
```bash
python3 models.py search barrel          # 关键词搜模型（type=models 列表+过滤）
python3 models.py get barrel_03          # 下载 glTF → 转 mesh JSON（同目录落盘）
python3 models.py url barrel_03          # 只看下载地址
python3 models.py convert a.gltf         # 本地 glTF/GLB → mesh JSON
```
- glTF 解析：accessor/bufferView + node matrix/四元数变换 + 居中归一化 → `OVM.load` 直接吃的 JSON
- 素材站 Poly Haven（polyhaven.com）全部 CC0 可商用；无需 API key
- 典型流：`search 关键词 → get 资产名 → 场景里 OVM.load + 物理/运镜组合`

## 效率（render.py 并行版）

```bash
python3 render.py scene.html frames/ --workers 4   # 4 页面并行
python3 render.py scene.html frames/               # 默认 workers = CPU数/2（上限 8）
```

- **实测**：2D 360 帧 37s → 14s（~2.7×）；GPU raymarching 受 SwiftShader 单帧开销限制，workers 加速同样有效
- **断点续渲**：已存在且非空的帧自动跳过；中断后重跑同一条命令即可续渲（0 成本）。`--clean` 强制全部重渲
- **确定性保证**：每帧是 t 的纯函数，并行/串行输出逐位一致（已验证 md5），放心并行
- 调优优先级：先 `snap` 抽帧定稿 → 并行全量渲染 → ffmpeg 封装。不要边渲边改场景
- 沙箱内 workers 不要超过 CPU 数，否则 SwiftShader 互相争抢反而变慢

## 适用边界
擅长：动效图形、UI 演示、动画图表、Logo 揭示、科普讲解、3D 线框/科技感大片、社交模板。
不擅长：写实人物/自然运镜/唇形同步——此类让模型产出镜头清单+文生视频提示词，外部模型出素材后回本流程拼接。

## 自检（改动引擎库后必跑）
```bash
node regress_all.js      # Node 侧：72 运镜 / 40 后期 / 34 排版 / 天气 5+景深 3 / 模型四格式 / 地形 16+16 / 物理十能力 / 随机世界+实时水
python3 regress_audio.py # Python 侧：24 mood / 44 SFX / CLI / 40 xfade 转场映射
node model3d_test.js     # 模型引擎深度：STL/PLY 解析 + 焊接 + 渲染确定性
```
三个脚本共 **150+ 项**断言（Node 侧 63 项 + Python 侧 + 模型深度），全过才允许发布；任一失败先修再打包。

## GPU 着色器层（shader.js / window.OVGL）

需要真实光影（SDF 光线步进、软阴影、镜面反射、体积光、ACES 色调映射、大气雾）时，在场景中加载 `shader.js`：

```html
<script src="shader.js"></script>
<canvas id="gl" width="1920" height="1080" style="position:absolute;inset:0"></canvas>
<canvas id="frame" width="1920" height="1080"></canvas> <!-- 2D UI 层，最终成片取此画布 -->
<script>
const gl = OVGL.init(document.getElementById('gl'));
window.renderFrame = (t) => {
  const cam = {pos:[Math.sin(t*.4)*6,2.5,Math.cos(t*.4)*6], target:[0,1,0]};
  gl.draw(t, {cam, beat: OV.TIME.beat(t,120).pulse}); // WebGL 底层
  const ctx = document.getElementById('frame').getContext('2d');
  ctx.clearRect(0,0,1920,1080); /* 再画 2D UI：标题/字幕/FX */
};
</script>
```

- `OVGL.init(canvas)` → `{draw(t, {cam, target, beat})}`；`cam/target` 为 [x,y,z] 数组
- **双画布结构**：WebGL 底层 + `#frame` 2D UI 层。render.py/snap.py 抓取优先 `#frame`，所以 UI 一定会入画；绝不能只留 WebGL canvas 当输出
- **GLSL 用 GLSL ES 1.0 语法**：`dot(n, L)`，不能写 JS 风格的 `n.dot(L)`
- **沙盒无 GPU**：headless Chromium 的 WebGL 全部被禁。必须外部包裹 `xvfb-run -a` 并用**有头模式 + desktop GL**（新版 Chromium 的 swiftshader 参数组全被禁，`--use-gl=desktop` 走 mesa GLX 才拿得到 context）：

```bash
xvfb-run -a sh -c 'OV_GPU=1 python3 render.py gpu.html frames/ 30'
xvfb-run -a sh -c 'OV_GPU=1 python3 snap.py gpu.html 1.0 3.2 6.5'
```

- SwiftShader 软渲染 raymarching 速度可接受（约 0.2~0.4s/帧 @1080p），帧数多时先抽帧调好再全量渲
- GPU 模式抽帧必做：raymarching 场景相机穿模/黑面问题比 2D 更隐蔽，先 `snap` 目检 3~4 帧再全量渲染

## GPU 实时地形 + 水面（gl-water.js / window.OVGL）

上面 CPU 路径再往上一档：**真 3D raycast 全在 fragment shader 里跑**——每像素射线同时与地形高度场纹理和水面波浪平面求交、近者胜。加载 `gl-water.js`（与 `shader.js` 是两个独立 GPU 层，按需选一，别同时加载）：

```html
<script src="terrain.js"></script>
<script src="gl-water.js"></script>
<canvas id="gl" width="1280" height="720" style="position:absolute;inset:0"></canvas>
<canvas id="frame" width="1280" height="720"></canvas> <!-- 2D UI 层，成片抓此画布 -->
<script>
const T = OVT.world(2026, { size: 256, water: 0.26, amp: 2.6, ridge: 0.62, warp: 0.50 });
const glc = OVGL.init(document.getElementById('gl'));
glc.setTerrain(T);   // 高度图 → Uint8Array LUMINANCE 纹理上传
window.renderFrame = (t) => {
  const camH = OVT.sample(T, x, z);
  glc.render(t, { x, z, yaw, lift: camH + 5.0, fov: 1.1,
                  water: T.water * T.amp, palette: "natural",
                  sun: [0.9, 0.75], fog: [175,200,218], time: t });
  const ctx = document.getElementById('frame').getContext('2d');
  ctx.clearRect(0,0,1280,720); /* 再画 2D UI：标题/字幕/FX */
};
</script>
```

- **统一入口**：`OVGL.init(canvas)` → `{setTerrain(T), render(t, cam)}`；地形数据直接吃 `OVT.world()` / `OVT.generate()` 的返回对象
- **真 3D raycast**：`marchTerrain` 220 步（d=0.5 起、dStep 0.22×1.018，与 CPU 列投射同参数）；射线方向用 `atan` 形式与 CPU 视锥一致——两路渲染同一世界同机位画面接近，可混剪
- **波浪法线**：`waveH` 8 低频 + 高频涟漪（0.0045·sin(1.15x+0.85y+4.5t)）共 10 项，差分出法线后过菲涅尔/镜面/反光路径/泡沫（与 CPU renderWater 同约定同参数）
- **天空**：渐变 + 太阳 `pow900` + fbm 云；太阳屏幕方位 `phi = yaw + atan(1.68·cos(sunA)·fov)`，与 CPU 天空太阳位置同约定
- **成本**：WebGL1 + 全屏 fragment 跑 220 步 raycast，沙箱 mesa 软渲染约 0.5~1.5s/帧 @720p——**样片用 24fps + 短时长**（8s/192 帧实测可接受），先 snap 目检再全量
- **必须 xvfb**：见上文 GPU 段坑表——headless swiftshader 全被禁，`xvfb-run -a` + `headless=False` + `--use-gl=desktop` 缺一不可；render.py/snap.py 的 GPU 分支已内置该参数组
- **双画布铁律**：WebGL canvas 绝不能当输出画布；UI/标题/FX 全画在 `#frame` 上，render.py/snap.py 抓 `#frame`
- 参考样片：`water-gl-sample.html`（海岸巡航 → 内陆山地两段机位，实时帧耗时 HUD）
