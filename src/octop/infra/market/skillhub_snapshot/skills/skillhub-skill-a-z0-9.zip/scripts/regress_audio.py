# opus-video 翻倍能力全量回归 v3（Python 侧）
# 覆盖：audio.py（24 mood / 44 SFX / CLI 冒烟）· assemble.py（40 个 xfade 转场映射）
# 运行：python3 regress_audio.py
import importlib.util
import subprocess
import sys
import tempfile
import os
import re
import numpy as np

SKILL = "/root/.codebuddy/skills/opus-video"
spec = importlib.util.spec_from_file_location("aud", os.path.join(SKILL, "audio.py"))
aud = importlib.util.module_from_spec(spec)
spec.loader.exec_module(aud)

passed = failed = 0
def ok(cond, msg):
    global passed, failed
    if cond:
        passed += 1
        print("  PASS  " + msg)
    else:
        failed += 1
        print("  FAIL  " + msg)

# ========== 1. MOODS 24 ==========
print("\n[1] 配乐 mood（目标 24）")
moods = list(aud.MOODS)
ok(len(moods) == 24, f"mood {len(moods)} 个（{', '.join(moods)}）")
need = ("prog", "cutoff", "kick", "snare", "hat")
missing = [m for m in moods if not all(k in aud.MOODS[m] for k in need)]
ok(not missing, f"24 mood 均含 prog/cutoff/kick/snare/hat 字段{missing and ' → 缺: ' + ', '.join(missing) or ''}")
new_moods = {"ambient", "synthwave", "jazz", "rock", "dnb", "trap",
             "folk", "bossa", "noir", "space", "cyber", "battle"}
ok(new_moods <= set(moods), f"12 个新 mood 全部在库{new_moods - set(moods) and ' → 缺: ' + ', '.join(new_moods - set(moods)) or ''}")

# ========== 2. SFX 44 ==========
print("\n[2] 音效库（目标 44）")
sfx_names = list(aud.SFX)
ok(len(sfx_names) == 44, f"SFX {len(sfx_names)} 个（{', '.join(sfx_names)}）")
bad = []
peaks = []
for name, fn in aud.SFX.items():
    try:
        sig = fn(0.8)
        sig2 = fn(0.8)                       # 确定性：同参数两次生成逐位一致
        if not np.array_equal(sig, sig2):
            bad.append(name + ":非确定性")
            continue
        if len(sig) == 0:
            bad.append(name + ":空信号")
            continue
        pk = float(np.max(np.abs(sig)))
        peaks.append(pk)
        if not (0.05 < pk <= 1.0):
            bad.append(f"{name}:峰值 {pk:.2f} 越界")
    except Exception as e:
        bad.append(f"{name}:{e}")
ok(not bad, f"44 SFX 全部可生成、确定性且峰值合理{bad and ' → ' + '; '.join(bad) or ''}")
ok(len(peaks) == 44, f"44 SFX 全部产出信号（{len(peaks)}/44）")
new_sfx = {"laser", "zap", "sweep", "upsuck", "punch", "pop", "splat", "chime",
           "gong", "taiko", "shaker", "cymbal", "drone", "pulse", "glitch",
           "typekey", "swipe", "magic", "powerup", "heal", "camera", "dial"}
ok(new_sfx <= set(sfx_names), f"22 个新 SFX 全部在库{new_sfx - set(sfx_names) and ' → 缺: ' + ', '.join(new_sfx - set(sfx_names)) or ''}")

# ========== 2.5 新 mood 构建冒烟 ==========
print("\n[2.5] 24 mood 逐一构建")
mbad = []
for mood in moods:
    try:
        y = aud.build(4.0, bpm=120, mood=mood, seed=1)
        if not (np.all(np.isfinite(y)) and 0.1 < float(np.max(np.abs(y))) <= 1.0):
            mbad.append(f"{mood}:信号异常")
    except Exception as e:
        mbad.append(f"{mood}:{e}")
ok(not mbad, f"24 mood build() 全部产出有效信号{mbad and ' → ' + '; '.join(mbad) or ''}")

# ========== 3. build_sfx cues 语法 ==========
print("\n[3] build_sfx 踩点混音")
mix = aud.build_sfx(2.0, [(0.2, "impact", 0.9), (0.8, "click", 0.5), (1.5, "coin")])
ok(len(mix) == int(2.0 * aud.SR), f"混音长度 {len(mix)} == 2.0s×{aud.SR}")
ok(0.05 < float(np.max(np.abs(mix))) <= 1.0, f"混音峰值 {float(np.max(np.abs(mix))):.2f} 合理")

# ========== 4. CLI 冒烟（cinematic + sfx 轨） ==========
print("\n[4] audio.py CLI 冒烟")
with tempfile.TemporaryDirectory() as td:
    out = os.path.join(td, "smoke.wav")
    r = subprocess.run(
        [sys.executable, os.path.join(SKILL, "audio.py"), out,
         "--dur", "1.5", "--bpm", "100", "--mood", "cinematic",
         "--sfx", "0.2=impact:0.8,0.9=click:0.6"],
        capture_output=True, text=True)
    ok(r.returncode == 0 and os.path.exists(out), f"CLI 生成成功 {os.path.basename(out)}（rc={r.returncode}）{r.stderr[-200:] if r.returncode else ''}")
    if os.path.exists(out):
        import wave
        with wave.open(out) as w:
            ok(w.getnframes() > 0, f"WAV 可读（{w.getnframes()} 帧 / {w.getframerate()}Hz / {w.getnchannels()}ch）")

# ========== 5. assemble.py 转场映射 ==========
print("\n[5] assemble.py 转场库（xfade 映射目标 40）")
src = open(os.path.join(SKILL, "assemble.py")).read()
m = re.search(r"DIAG = \{(.*?)\}", src, re.S)
ok(m is not None, "DIAG 映射块存在")
if m:
    pairs = re.findall(r'"(\w+)":\s*"(\w+)"', m.group(1))
    nones = re.findall(r'"(\w+)":\s*None', m.group(1))
    ok(len(pairs) + len(nones) == 40, f"映射条目共 {len(pairs) + len(nones)} 个（40 = 原 20 + 新 20）")
    ok(len(pairs) == 38, f"xfade 映射 {len(pairs)} 个（38 = 原 18 + 新 20）")
    ok(len(nones) == 2 and sorted(nones) == ["cut", "jcut"], f"硬切 {len(nones)} 个（cut/jcut 走 concat）")
    # 新转场名齐全
    new_names = {"glitch", "rgbGlitch", "flashCut", "circleWipe", "slideUp",
                 "smoothZoom", "pixelize", "radial", "diagWipe", "vSlice", "hBlur",
                 "wipeRight", "wipeUp", "wipeDown", "slideRight", "slideDown",
                 "circleOpen", "circleClose", "rectCrop", "vertClose",
                 "distance", "fadeGrays", "diagTL", "diagBL", "diagBR",
                 "vSliceD", "wipeTL", "wipeTR", "wipeBL", "wipeBR", "smoothLeft"}
    have = {k for k, _ in pairs}
    ok(new_names <= have, f"31 个新转场全部在映射中{new_names - have and ' → 缺: ' + ', '.join(new_names - have) or ''}")

print(f"\n===== Python 侧回归：{passed} 通过 / {failed} 失败 =====")
sys.exit(1 if failed else 0)
