# 快速抽帧调试器：只渲染指定时刻，不完整跑 300 帧
# 用法：
#   python3 snap.py scene.html 1.0 5.0 9.0          # 常规（canvas2d）
#   xvfb-run -a python3 snap.py scene.html --gl 1.0 # WebGL 样片（headless 无 GL，需 xvfb + desktop GL）
import asyncio, base64, pathlib, sys
from playwright.async_api import async_playwright
USE_GL = "--gl" in sys.argv
TIMES = [float(x) for x in sys.argv[2:] if x != "--gl"]
async def main():
    scene = pathlib.Path(sys.argv[1]).resolve()
    async with async_playwright() as p:
        if USE_GL:
            b = await p.chromium.launch(headless=False, args=["--use-gl=desktop", "--enable-unsafe-swiftshader"])
        else:
            b = await p.chromium.launch(args=["--force-color-profile=srgb","--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader"])
        pg = await b.new_page(viewport={"width":1280,"height":720}, device_scale_factor=1)
        await pg.goto(scene.as_uri())
        await pg.wait_for_function("typeof window.renderFrame==='function'")
        await pg.evaluate("document.fonts.ready")
        for t in TIMES:
            data = await pg.evaluate("(t)=>{const c=document.querySelector('#frame')||document.querySelector('canvas');window.renderFrame(t);return c.toDataURL('image/png')}", t)
            out = f"snap_{str(t).replace('.','_')}.png"
            pathlib.Path(out).write_bytes(base64.b64decode(data.split(",",1)[1]))
            print(out)
        await b.close()
asyncio.run(main())
