#!/usr/bin/env python3
"""
opus-video / publish_check.py
发布前自动检查：一次跑完全部硬指标，输出可读报告 + 联系人用的抽帧拼图。

用法:
  python3 publish_check.py final.mp4 --expect 1280x720 --fps 30 --dur 12 \
      --frames /path/to/frames_dir --contact out_contact.png

检查项:
  1. 容器/编码：h264 + yuv420p（否则手机黑屏）
  2. 规格：分辨率 / 帧率 / 时长 / 总帧数，与预期比对
  3. 黑帧：首帧、末帧亮度；全片黑帧占比
  4. 冻结帧：连续相同帧检测（画面卡死）
  5. 音频：是否存在、时长是否匹配、是否静音、峰值/响度
  6. 抽帧拼图：默认 6 宫格，供人工目检
退出码: 0 全过 / 1 有 FAIL
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile


def run(cmd):
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return p.returncode, p.stdout.strip(), p.stderr.strip()


def probe(path):
    rc, out, err = run(
        f'ffprobe -v error -print_format json -show_format -show_streams "{path}"')
    if rc != 0:
        raise RuntimeError(f"ffprobe 失败: {err}")
    return json.loads(out)


class Report:
    def __init__(self):
        self.rows = []

    def add(self, name, ok, detail):
        self.rows.append((name, ok, detail))

    @property
    def failed(self):
        return [r for r in self.rows if r[1] is False]

    def render(self):
        w = max(len(r[0]) for r in self.rows) + 2
        lines = []
        for name, ok, detail in self.rows:
            mark = "PASS" if ok is True else ("WARN" if ok is None else "FAIL")
            lines.append(f"  [{mark}] {name.ljust(w)} {detail}")
        return "\n".join(lines)


def check_spec(info, expect_w, expect_h, expect_fps, expect_dur, rep):
    vs = [s for s in info["streams"] if s["codec_type"] == "video"]
    if not vs:
        rep.add("视频流", False, "不存在")
        return None
    v = vs[0]
    rep.add("视频流", True, f"{v['codec_name']} {v.get('profile','')} {v.get('pix_fmt','')}")
    rep.add("像素格式", v.get("pix_fmt") == "yuv420p",
            f"{v.get('pix_fmt')}（非 yuv420p 在部分手机/浏览器会黑屏）")
    w, h = v.get("width"), v.get("height")
    if expect_w and expect_h:
        rep.add("分辨率", (w, h) == (expect_w, expect_h), f"{w}x{h}（期望 {expect_w}x{expect_h}）")
    else:
        rep.add("分辨率", True, f"{w}x{h}")
    rep.add("偶数宽高", w % 2 == 0 and h % 2 == 0, f"{w}x{h}")
    num, den = v.get("r_frame_rate", "0/1").split("/")
    fps = float(num) / float(den or 1)
    if expect_fps:
        rep.add("帧率", abs(fps - expect_fps) < 0.05, f"{fps:.2f}（期望 {expect_fps}）")
    else:
        rep.add("帧率", True, f"{fps:.2f}")
    dur = float(info["format"].get("duration", 0))
    nb = v.get("nb_frames")
    if expect_dur:
        rep.add("时长", abs(dur - expect_dur) < 0.1, f"{dur:.3f}s（期望 {expect_dur}s）")
        if nb and nb.isdigit():
            rep.add("帧数", int(nb) == round(expect_dur * fps),
                    f"{nb}（期望 {round(expect_dur*fps)}）")
    else:
        rep.add("时长", True, f"{dur:.3f}s")
    return v


def check_audio(info, expect_dur, rep):
    aus = [s for s in info["streams"] if s["codec_type"] == "audio"]
    if not aus:
        rep.add("音轨", None, "无音轨（静音发布，注意平台播放器兼容）")
        return
    a = aus[0]
    adur = float(a.get("duration", 0))
    vdur = float(info["format"].get("duration", 0))
    rep.add("音轨", True, f"{a['codec_name']} {a.get('sample_rate')}Hz {a.get('channels')}ch {adur:.2f}s")
    rep.add("音画时长差", abs(adur - vdur) < 0.15, f"{abs(adur-vdur):.3f}s")


def loudness(path, rep):
    rc, out, err = run(f'ffmpeg -hide_banner -i "{path}" -af volumedetect -f null /dev/null')
    txt = err + out
    mean = max_ = None
    for line in txt.splitlines():
        if "mean_volume:" in line:
            mean = float(line.split("mean_volume:")[1].split("dB")[0].strip())
        if "max_volume:" in line:
            max_ = float(line.split("max_volume:")[1].split("dB")[0].strip())
    if mean is None:
        rep.add("响度", False, "无法测量")
        return
    rep.add("平均响度", -30 < mean < -5, f"{mean:.1f} dB（发布建议 -20 ~ -12）")
    rep.add("峰值", max_ < -0.5, f"{max_:.1f} dB（>-0.5 有削波风险，编码会抬高峰值）")
    rep.add("非静音", mean > -50, f"{mean:.1f} dB")


def frame_luma(path, t):
    """取 t 秒处的平均亮度（0-255）"""
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        tmp = f.name
    rc, _, _ = run(f'ffmpeg -y -v error -ss {t} -i "{path}" -frames:v 1 "{tmp}"')
    if rc != 0 or not os.path.exists(tmp):
        return None
    try:
        from PIL import Image
        import numpy as np
        im = np.asarray(Image.open(tmp).convert("L"), dtype=float)
        return float(im.mean()), float(im.std())
    finally:
        os.unlink(tmp)


def check_frames(path, dur, rep):
    a = frame_luma(path, 0.0)
    b = frame_luma(path, max(0, dur - 0.05))
    if a:
        rep.add("首帧亮度", a[0] > 6, f"{a[0]:.1f}（<6 视为黑屏）")
    if b:
        rep.add("末帧亮度", b[0] > 6, f"{b[0]:.1f}")
    # 全片黑帧比例
    rc, out, _ = run(
        f'ffmpeg -hide_banner -i "{path}" -vf blackdetect=d=0.05:pix_th=0.03 -an -f null /dev/null')
    blacks = [l for l in (out + _).splitlines() if "black_start" in l]
    total_black = 0.0
    for l in blacks:
        try:
            seg = l.split("black_start:")[1]
            s = float(seg.split("black_end:")[0])
            e = float(seg.split("black_end:")[1].split()[0])
            total_black += e - s
        except Exception:
            pass
    rep.add("黑屏占比", total_black < max(1.5, dur * 0.15),
            f"{total_black:.2f}s / {dur:.1f}s")


def check_freeze(path, dur, rep):
    """冻结帧检测：连续 0.8s 完全相同的画面视为卡死"""
    rc, out, _ = run(
        f'ffmpeg -hide_banner -i "{path}" -vf "freezedetect=n=0.001:d=0.8" -an -f null /dev/null')
    freezes = [l for l in (out + _).splitlines() if "freeze_start" in l]
    # 静止标题卡属正常设计；仅当静止占比过高才判失败
    frozen_total = 0.0
    for l in freezes:
        try:
            s0 = float(l.split("freeze_start:")[1].split("freeze_duration:")[0])
            d0 = float(l.split("freeze_duration:")[1].split(".")[0].strip() or 0)
            frozen_total += d0
        except Exception:
            pass
    ok = frozen_total < dur * 0.45
    rep.add("冻结帧", ok,
            f"静止 {frozen_total:.1f}s/{dur:.1f}s（{len(freezes)} 段；标题卡静止属正常，占比过高说明缺微动）")


def contact_sheet(path, dur, out, cols=3, rows=2):
    n = cols * rows
    with tempfile.TemporaryDirectory() as td:
        for i in range(n):
            t = dur * i / (n - 1) if n > 1 else 0
            if i == n - 1:
                t = max(0, dur - 0.08)
            run(f'ffmpeg -y -v error -ss {t:.3f} -i "{path}" -frames:v 1 "{td}/s{i}.png"')
        args = " ".join(f'-i "{td}/s{i}.png"' for i in range(n))
        filt = "".join(f"[{i}:v]scale=480:-1,drawtext=text='{i+1}':x=10:y=10:fontsize=28:fontcolor=yellow:box=1:boxcolor=black@0.6[v{i}];" for i in range(n))
        layout = "|".join(f"{(i%cols)}*w{(i//cols)}*h".replace("w0", "w0").replace("h0", "h0") for i in range(n))
        # 用 xstack 拼图（比 tile 更可控）
        stack_in = "".join(f"[v{i}]" for i in range(n))
        rc, _, err = run(
            f'ffmpeg -y -v error {args} -filter_complex "{filt}{stack_in}xstack=inputs={n}:layout={layout}:fill=black" "{out}"')
        if rc != 0:
            # 退化：直接用 tile
            run(f'ffmpeg -y -v error {args} -filter_complex "{filt}{stack_in}hstack=inputs={n}" "{out}"')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--expect", default="", help="分辨率，如 1280x720")
    ap.add_argument("--fps", type=float, default=0)
    ap.add_argument("--dur", type=float, default=0)
    ap.add_argument("--contact", default="", help="抽帧拼图输出路径")
    args = ap.parse_args()

    if not os.path.exists(args.video):
        print(f"文件不存在: {args.video}")
        sys.exit(2)

    rep = Report()
    info = probe(args.video)
    ew = eh = 0
    if args.expect:
        ew, eh = [int(x) for x in args.expect.lower().split("x")]
    v = check_spec(info, ew, eh, args.fps or 0, args.dur or 0, rep)
    check_audio(info, args.dur or float(info["format"].get("duration", 0)), rep)
    loudness(args.video, rep)
    dur = float(info["format"].get("duration", 0))
    check_frames(args.video, dur, rep)
    check_freeze(args.video, dur, rep)

    size_mb = os.path.getsize(args.video) / 1024 / 1024
    rep.add("文件体积", 0.05 < size_mb < 500, f"{size_mb:.2f} MB")

    print("\n=== 发布前检查报告 ===")
    print(f"文件: {args.video}")
    print(rep.render())

    if args.contact:
        contact_sheet(args.video, dur, args.contact)
        print(f"\n抽帧拼图: {args.contact}")

    fails = rep.failed
    print(f"\n结论: {'全部通过 ✅' if not fails else f'{len(fails)} 项不合格 ❌'}")
    for name, ok, detail in fails:
        print(f"  - {name}: {detail}")
    sys.exit(0 if not fails else 1)


if __name__ == "__main__":
    main()
