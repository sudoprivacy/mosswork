/* ============================================================
   opus-video · terrain.js — 程序化地形 + 贴图 + 水渲染层（window.OVT）
   确定性：种子噪声高度图 + 体素列投射（Comanche 风格轮廓投射）
   每帧为 t 的纯函数，~0.15s/帧 @720p，可安全并行
   增强：波浪粼光 / 太阳镜面 / 岸边泡沫 / 浅水透色 / 坡度岩壁 /
        雪线 / fbm 云层天空 / 黄昏调色板
   ============================================================ */
(function () {
  /* ---- 确定性 PRNG（mulberry32） ---- */
  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function hash2(x, y, seed) {
    let h = (x * 374761393 + y * 668265263 + seed * 1442695041) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }
  const sm = (t) => t * t * (3 - 2 * t);
  function sstep(a, b, x) { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); }
  function noise2(x, y, seed) {
    const xi = Math.floor(x), yi = Math.floor(y);
    const xf = x - xi, yf = y - yi;
    const a = hash2(xi, yi, seed), b = hash2(xi + 1, yi, seed);
    const c = hash2(xi, yi + 1, seed), d = hash2(xi + 1, yi + 1, seed);
    const u = sm(xf), v = sm(yf);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  /* ridged multifractal：脊线噪声，专产山脉 */
  function ridged(x, y, seed, oct) {
    oct = oct || 4;
    let v = 0, amp = 0.5, f = 1, norm = 0, prev = 1;
    for (let i = 0; i < oct; i++) {
      let n = 1 - Math.abs(noise2(x * f, y * f, seed + i * 131) * 2 - 1);
      n *= n;
      v += n * amp * prev;
      prev = n; norm += amp; amp *= 0.5; f *= 2;
    }
    return v / norm;
  }
  /* 分形布朗运动 */
  function fbm(x, y, seed, oct) {
    oct = oct || 4;
    let v = 0, amp = 0.5, f = 1, norm = 0;
    for (let i = 0; i < oct; i++) {
      v += noise2(x * f, y * f, seed + i * 101) * amp;
      norm += amp; amp *= 0.5; f *= 2;
    }
    return v / norm;
  }

  /* ---- 高度图生成 ---- */
  function generate(opts) {
    opts = opts || {};
    const size = opts.size || 256;
    const seed = opts.seed != null ? opts.seed : 7;
    const scale = opts.scale || 0.02;
    const rough = opts.rough != null ? opts.rough : 0.5;
    const h = new Float32Array(size * size);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const base = fbm(x * scale, y * scale, seed, 5);
        const detail = fbm(x * scale * 4, y * scale * 4, seed + 777, 3);
        let v = base * (1 - rough) + detail * rough * 0.6;
        // 山脊层：大尺度掩码 + ridged 细节，smoothstep 过渡（无硬断层）
        const mount = ridged(x * scale * 0.7, y * scale * 0.7, seed + 555, 4);
        v += sstep(0.42, 0.62, mount) * 1.6 * (0.5 + detail * 0.7);
        h[y * size + x] = v;
      }
    }
    // 对比拉伸：拉开山谷与山峰
    for (let k = 0; k < h.length; k++) h[k] = Math.min(1, Math.max(0, (h[k] - 0.5) * 1.75 + 0.5));
    // 边缘衰减（岛屿感）
    const m = size * 0.5;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = Math.abs(x - m) / m, dy = Math.abs(y - m) / m;
        const d = Math.min(1, Math.max(dx, dy));
        h[y * size + x] *= 1 - sm(Math.max(0, d - 0.62) / 0.38);
      }
    }
    const water = opts.water != null ? opts.water : 0.32;
    return { h, size, seed, water, amp: opts.amp != null ? opts.amp : 2.2 };
  }

  /* ============================================================
     GTA 式随机世界生成：domain warping + ridged 山脉 + 热扩散侵蚀
     + 高度×湿度 biome 分布。每个 seed 一片全新地貌，非预定地图。
     ============================================================ */
  const NB = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  const BIOME_NAMES = ["深海", "浅海", "沙滩", "森林", "草原", "岩石", "雪顶"];
  function world(seed, opts) {
    opts = opts || {};
    const size = opts.size || 256;
    const water = opts.water != null ? opts.water : 0.34;
    const warp = opts.warp != null ? opts.warp : 0.55;      // 域扭曲强度（河谷蜿蜒度）
    const ridgeAmp = opts.ridge != null ? opts.ridge : 0.55; // 山脉权重
    const h = new Float32Array(size * size);
    const wet = new Float32Array(size * size);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        /* domain warping：采样坐标被另一层 fbm 扭曲 → 非重复的蜿蜒地貌 */
        const qx = fbm(x * 0.012, y * 0.012, seed + 11, 3) - 0.5;
        const qy = fbm(x * 0.012, y * 0.012, seed + 29, 3) - 0.5;
        const px = x + qx * size * 0.18 * warp;
        const py = y + qy * size * 0.18 * warp;
        const base = fbm(px * 0.014, py * 0.014, seed + 7, 5);
        const ridge = ridged(px * 0.009, py * 0.009, seed + 53, 5);
        /* 山脉掩码：平原→丘陵→山脉自然过渡，不处处是山 */
        const mask = sstep(0.45, 0.72, base);
        h[y * size + x] = base + ridge * ridgeAmp * mask;
        wet[y * size + x] = fbm(x * 0.02 + 40, y * 0.02 - 17, seed + 91, 4);
      }
    }
    /* 归一化 + 对比拉伸 */
    let mn = 1e9, mx = -1e9;
    for (const v of h) { if (v < mn) mn = v; if (v > mx) mx = v; }
    let inv = 1 / Math.max(1e-6, mx - mn);
    for (let k = 0; k < h.length; k++) h[k] = (h[k] - mn) * inv;
    for (let k = 0; k < h.length; k++) h[k] = Math.min(1, Math.max(0, (h[k] - 0.5) * 1.35 + 0.5));
    /* 热扩散侵蚀（2 轮）：高差超 talus 处向低邻搬运 → 消碎片、出冲沟 */
    const talus = 0.012;
    for (let pass = 0; pass < 2; pass++) {
      const dh = new Float32Array(h.length);
      for (let y = 1; y < size - 1; y++) {
        for (let x = 1; x < size - 1; x++) {
          const i = y * size + x, c = h[i];
          let d = 0;
          for (const [ox, oz] of NB) if (c - h[i + oz * size + ox] > talus) d += c - h[i + oz * size + ox] - talus;
          if (d > 0) {
            const mv = Math.min(c * 0.5, d * 0.35);
            dh[i] -= mv;
            for (const [ox, oz] of NB) {
              const diff = c - h[i + oz * size + ox];
              if (diff > talus) dh[i + oz * size + ox] += mv * (diff - talus) / d;
            }
          }
        }
      }
      for (let k = 0; k < h.length; k++) h[k] += dh[k];
    }
    mn = 1e9; mx = -1e9;
    for (const v of h) { if (v < mn) mn = v; if (v > mx) mx = v; }
    inv = 1 / Math.max(1e-6, mx - mn);
    for (let k = 0; k < h.length; k++) h[k] = (h[k] - mn) * inv;
    /* biome 分布：高度 × 湿度 → 7 类 */
    const biome = new Uint8Array(size * size);
    for (let k = 0; k < h.length; k++) {
      const hv = h[k], wv = wet[k];
      biome[k] = hv < water - 0.05 ? 0 : hv < water ? 1 : hv < water + 0.025 ? 2
        : hv > 0.80 ? 6 : hv > 0.68 ? 5 : wv > 0.58 ? 3 : wv > 0.42 ? 4 : 5;
    }
    return { h, wet, biome, size, seed, water, amp: opts.amp != null ? opts.amp : 2.6 };
  }

  /* ---- 调色板（自然 / 黄昏 / 沙漠 / 异星） ---- */
  const PALETTES = {
    natural: {
      bands: [
        { hi: 0.32, col: [30, 90, 150] }, { hi: 0.38, col: [212, 190, 130] },
        { hi: 0.62, col: [70, 140, 70] }, { hi: 0.80, col: [110, 100, 90] },
        { hi: 1.01, col: [238, 240, 245] },
      ],
      rock: [105, 96, 88], water: [26, 82, 138], shallow: [70, 160, 170],
      foam: [235, 242, 245], sky: ["#8ec5e8", "#e8f4f8"], fog: [175, 200, 218],
    },
    sunset: {
      bands: [
        { hi: 0.30, col: [25, 60, 105] }, { hi: 0.36, col: [214, 168, 120] },
        { hi: 0.60, col: [88, 118, 78] }, { hi: 0.80, col: [96, 82, 74] },
        { hi: 1.01, col: [246, 232, 220] },
      ],
      rock: [92, 78, 70], water: [32, 58, 96], shallow: [96, 120, 130],
      foam: [250, 226, 200], sky: ["#3a2a5a", "#ff9a5a"], fog: [255, 176, 128],
      sun: [255, 214, 160],
    },
    desert: {
      bands: [
        { hi: 0.30, col: [50, 110, 150] }, { hi: 0.40, col: [225, 195, 130] },
        { hi: 0.75, col: [200, 150, 90] }, { hi: 1.01, col: [170, 100, 70] },
      ],
      rock: [150, 110, 80], water: [30, 90, 140], shallow: [90, 160, 170],
      foam: [240, 230, 210], sky: ["#a8c8e0", "#f4e0c0"], fog: [225, 205, 180],
    },
    alien: {
      bands: [
        { hi: 0.30, col: [60, 20, 90] }, { hi: 0.42, col: [90, 200, 180] },
        { hi: 0.70, col: [60, 60, 130] }, { hi: 1.01, col: [230, 120, 200] },
      ],
      rock: [80, 60, 120], water: [90, 30, 120], shallow: [140, 220, 210],
      foam: [220, 240, 235], sky: ["#2a1040", "#c85aa0"], fog: [180, 120, 190],
      sun: [255, 200, 255],
    },
    /* ---- 翻倍调色板 v2（4 → 8）---- */
    tundra: {   // 寒带苔原：低植被 + 低雪线
      bands: [
        { hi: 0.30, col: [40, 80, 120] }, { hi: 0.38, col: [140, 130, 100] },
        { hi: 0.55, col: [90, 110, 80] }, { hi: 0.75, col: [100, 100, 105] },
        { hi: 1.01, col: [245, 248, 252] },
      ],
      rock: [95, 95, 100], water: [30, 70, 110], shallow: [80, 130, 150],
      foam: [240, 245, 250], sky: ["#9ab8d8", "#e8eef4"], fog: [200, 215, 228],
    },
    volcano: {  // 火山：灰黑基底 + 熔岩红
      bands: [
        { hi: 0.28, col: [30, 50, 60] }, { hi: 0.40, col: [70, 60, 58] },
        { hi: 0.65, col: [40, 35, 35] }, { hi: 0.85, col: [120, 60, 40] },
        { hi: 1.01, col: [230, 90, 30] },
      ],
      rock: [60, 50, 48], water: [40, 30, 30], shallow: [90, 60, 50],
      foam: [200, 180, 170], sky: ["#301828", "#c85a3a"], fog: [90, 60, 55],
      sun: [255, 150, 90],
    },
    jungle: {   // 丛林：高饱和深绿
      bands: [
        { hi: 0.30, col: [30, 90, 80] }, { hi: 0.42, col: [200, 180, 130] },
        { hi: 0.60, col: [40, 100, 50] }, { hi: 0.85, col: [60, 130, 70] },
        { hi: 1.01, col: [120, 130, 120] },
      ],
      rock: [70, 80, 70], water: [25, 80, 75], shallow: [60, 150, 140],
      foam: [230, 245, 240], sky: ["#7ab8a8", "#e0f0e0"], fog: [190, 215, 200],
    },
    moon: {     // 月球：无大气黑色天空 + 全灰地表
      bands: [
        { hi: 0.30, col: [55, 58, 65] }, { hi: 0.42, col: [120, 118, 112] },
        { hi: 0.70, col: [150, 148, 142] }, { hi: 1.01, col: [235, 235, 230] },
      ],
      rock: [110, 108, 102], water: [40, 42, 50], shallow: [80, 82, 90],
      foam: [200, 200, 200], sky: ["#000000", "#101018"], fog: [60, 60, 70],
      sun: [255, 255, 250],
    },
    /* ---- 翻倍调色板 v3（8 → 16）---- */
    dawn: {     // 黎明：粉橙渐层 + 淡青雾
      bands: [
        { hi: 0.30, col: [38, 74, 120] }, { hi: 0.38, col: [226, 178, 150] },
        { hi: 0.62, col: [96, 128, 92] }, { hi: 0.82, col: [120, 108, 100] },
        { hi: 1.01, col: [248, 240, 235] },
      ],
      rock: [108, 100, 96], water: [40, 80, 120], shallow: [120, 160, 175],
      foam: [252, 232, 220], sky: ["#5a6a9a", "#ffc9a8"], fog: [235, 200, 190],
      sun: [255, 226, 190],
    },
    ocean: {    // 深海：靛蓝主调 + 绿松石浅滩
      bands: [
        { hi: 0.30, col: [12, 46, 92] }, { hi: 0.38, col: [216, 205, 160] },
        { hi: 0.60, col: [46, 110, 96] }, { hi: 0.80, col: [88, 96, 104] },
        { hi: 1.01, col: [232, 240, 242] },
      ],
      rock: [86, 94, 100], water: [16, 60, 110], shallow: [64, 190, 190],
      foam: [235, 245, 248], sky: ["#3a7ab0", "#cfe8f4"], fog: [170, 205, 220],
      sun: [240, 250, 255],
    },
    cherry: {   // 樱花季：粉白花瓣色调
      bands: [
        { hi: 0.30, col: [60, 80, 110] }, { hi: 0.38, col: [235, 200, 195] },
        { hi: 0.62, col: [150, 170, 130] }, { hi: 0.82, col: [140, 120, 118] },
        { hi: 1.01, col: [250, 240, 240] },
      ],
      rock: [120, 108, 108], water: [50, 80, 110], shallow: [150, 170, 185],
      foam: [252, 240, 238], sky: ["#8a9ac0", "#ffd8e0"], fog: [240, 210, 215],
      sun: [255, 230, 230],
    },
    cyber: {    // 赛博：霓虹紫青 + 洋红高光
      bands: [
        { hi: 0.30, col: [20, 12, 48] }, { hi: 0.40, col: [40, 200, 190] },
        { hi: 0.66, col: [56, 40, 120] }, { hi: 0.86, col: [90, 70, 150] },
        { hi: 1.01, col: [250, 120, 220] },
      ],
      rock: [70, 60, 110], water: [30, 20, 80], shallow: [80, 230, 220],
      foam: [220, 250, 245], sky: ["#160a30", "#c850c8"], fog: [120, 80, 180],
      sun: [255, 130, 240],
    },
    ash: {      // 灰烬火山：暗红余烬 + 黑岩
      bands: [
        { hi: 0.30, col: [30, 18, 16] }, { hi: 0.40, col: [90, 60, 50] },
        { hi: 0.64, col: [70, 50, 44] }, { hi: 0.84, col: [110, 80, 70] },
        { hi: 1.01, col: [220, 140, 90] },
      ],
      rock: [60, 44, 40], water: [50, 24, 20], shallow: [110, 70, 50],
      foam: [200, 170, 150], sky: ["#1a0e0c", "#c85030"], fog: [110, 70, 60],
      sun: [255, 150, 90],
    },
    aurora: {   // 极光：绿青天幕 + 雪原
      bands: [
        { hi: 0.30, col: [16, 40, 60] }, { hi: 0.40, col: [180, 210, 220] },
        { hi: 0.64, col: [90, 120, 110] }, { hi: 0.84, col: [130, 140, 140] },
        { hi: 1.01, col: [240, 250, 250] },
      ],
      rock: [100, 110, 115], water: [24, 56, 76], shallow: [90, 170, 180],
      foam: [230, 245, 245], sky: ["#061428", "#3ad8a0"], fog: [150, 190, 200],
      sun: [200, 255, 230],
    },
    toxic: {    // 毒沼：硫黄绿 + 浑浊水
      bands: [
        { hi: 0.30, col: [40, 60, 30] }, { hi: 0.42, col: [150, 160, 70] },
        { hi: 0.66, col: [90, 110, 50] }, { hi: 0.86, col: [110, 120, 60] },
        { hi: 1.01, col: [200, 210, 120] },
      ],
      rock: [90, 100, 60], water: [60, 80, 30], shallow: [140, 160, 60],
      foam: [200, 210, 140], sky: ["#4a5a20", "#c8d890"], fog: [160, 170, 100],
      sun: [230, 255, 160],
    },
    vintage: {  // 复古胶片：褪色暖褐
      bands: [
        { hi: 0.30, col: [50, 66, 84] }, { hi: 0.40, col: [205, 180, 140] },
        { hi: 0.64, col: [130, 120, 88] }, { hi: 0.84, col: [120, 100, 78] },
        { hi: 1.01, col: [238, 226, 200] },
      ],
      rock: [116, 104, 88], water: [52, 72, 92], shallow: [130, 150, 150],
      foam: [238, 230, 210], sky: ["#6a7a90", "#e8d8b8"], fog: [215, 200, 175],
      sun: [255, 240, 210],
    },
  };

  /* ---- 连续高度色带：相邻 band 间插值（消除硬切马赛克） ---- */
  function bandColor(pal, hn, out) {
    const B = pal.bands;
    if (hn <= B[0].hi) { out[0] = B[0].col[0]; out[1] = B[0].col[1]; out[2] = B[0].col[2]; return out; }
    for (let k = 1; k < B.length; k++) {
      if (hn < B[k].hi) {
        const a = B[k - 1].col, b = B[k].col;
        const u = (hn - B[k - 1].hi) / (B[k].hi - B[k - 1].hi);
        out[0] = a[0] + (b[0] - a[0]) * u;
        out[1] = a[1] + (b[1] - a[1]) * u;
        out[2] = a[2] + (b[2] - a[2]) * u;
        return out;
      }
    }
    const L = B[B.length - 1].col; out[0] = L[0]; out[1] = L[1]; out[2] = L[2]; return out;
  }
  /* biome 乘性色调（world() 世界用）：森林暗绿 / 草原亮黄 / 岩石灰 / 雪顶提亮 */
  const BIOME_TINT = {
    2: [1.06, 1.00, 0.86], 3: [0.74, 0.98, 0.74], 4: [0.96, 1.06, 0.78],
    5: [1.02, 0.99, 0.94], 6: [1.06, 1.06, 1.10],
  };

  /* ---- 采样 ---- */
  function sample(t, x, z) {
    const s = t.size;
    const gx = ((x % s) + s) % s, gz = ((z % s) + s) % s;
    const x0 = gx | 0, z0 = gz | 0;
    const x1 = (x0 + 1) % s, z1 = (z0 + 1) % s;
    const fx = gx - x0, fz = gz - z0;
    const h = t.h;
    const a = h[z0 * s + x0], b = h[z0 * s + x1];
    const c = h[z1 * s + x0], d = h[z1 * s + x1];
    return (a + (b - a) * fx + (c - a) * fz + (a - b - c + d) * fx * fz) * t.amp;
  }
  function slopeAt(t, x, z) {
    const e = 0.6;
    const hx = sample(t, x + e, z) - sample(t, x - e, z);
    const hz = sample(t, x, z + e) - sample(t, x, z - e);
    return Math.hypot(hx, hz);
  }
  function lightAt(t, x, z, sunA, sunK) {
    const e = 0.6;
    const hx = sample(t, x + e, z) - sample(t, x - e, z);
    const hz = sample(t, x, z + e) - sample(t, x, z - e);
    let lit = 0.62 + sunK * 0.38 * ((-hx * Math.cos(sunA) - hz * Math.sin(sunA)) * 2.2 + 0.35);
    return Math.max(0.52, Math.min(1.3, lit));
  }

  /* ---- 渲染 v3：连续高度色带 + 坡度平滑混合 + biome tint + 列间插值（无马赛克） ---- */
  function render(ctx, terrain, cam, opts) {
    opts = opts || {};
    const W = ctx.canvas.width, H = ctx.canvas.height;
    const { water } = terrain;
    const pal = PALETTES[opts.palette || "natural"] || PALETTES.natural;
    const res = opts.res || 1;
    const maxDist = opts.maxDist || 150;
    const fogC = opts.fog || pal.fog;
    const t = opts.time || 0;
    const sunA = opts.sun ? opts.sun[0] : 0.8;
    const sunK = opts.sun ? opts.sun[1] : 0.7;
    const wl = water * terrain.amp;
    const wlN = water;
    const horizon = H * 0.5 + (cam.pitch || 0) * H;
    const sunCol = pal.sun || [255, 245, 220];
    const useBiome = !!terrain.biome;
    const rgb = [0, 0, 0];

    /* ===== 天空：渐变 + 太阳 + 连续 fbm 云层（按列密度 → 竖直渐变带，无硬条） ===== */
    const sky = pal.sky;
    const g = ctx.createLinearGradient(0, 0, 0, horizon);
    g.addColorStop(0, sky[0]); g.addColorStop(1, sky[1]);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, horizon + 1);
    const sunX = W * 0.5 + Math.cos(sunA) * W * 0.42;
    const sunY = horizon * 0.32;
    const sg = ctx.createRadialGradient(sunX, sunY, 4, sunX, sunY, 150);
    sg.addColorStop(0, `rgba(${sunCol[0]},${sunCol[1]},${sunCol[2]},0.95)`);
    sg.addColorStop(0.2, `rgba(${sunCol[0]},${sunCol[1]},${sunCol[2]},0.4)`);
    sg.addColorStop(1, `rgba(${sunCol[0]},${sunCol[1]},${sunCol[2]},0)`);
    ctx.fillStyle = sg; ctx.fillRect(sunX - 160, sunY - 160, 320, 320);
    // 云层：每列连续 fbm 密度 → 顶淡/中实/底淡三段竖直渐变（连续无跳变）
    for (let i = 0; i < W; i += res) {
      const dens = fbm(cam.yaw * 0.9 + t * 0.012, i * 0.012, 4242, 4);
      if (dens > 0.50) {
        const a = Math.min(0.38, (dens - 0.50) * 1.4);
        const y0 = horizon * 0.05, hgt = 8 + (dens - 0.50) * 72;
        ctx.fillStyle = `rgba(255,255,255,${a * 0.45})`;
        ctx.fillRect(i, y0, res, hgt * 0.3);
        ctx.fillStyle = `rgba(255,255,255,${a})`;
        ctx.fillRect(i, y0 + hgt * 0.3, res, hgt * 0.4);
        ctx.fillStyle = `rgba(255,255,255,${a * 0.4})`;
        ctx.fillRect(i, y0 + hgt * 0.7, res, hgt * 0.3);
      }
    }

    const fov = cam.fov || 1.1;
    const scaleH = H * 0.9 * (cam.alt || 1);
    const camH = sample(terrain, cam.x, cam.z) + 0.25 + (cam.lift || 0);
    const nCols = (W / res | 0) + 2;
    const colLand = new Float32Array(nCols).fill(-1);   // 该列陆地露出水面的最高命中（-1 = 纯水列）
    const colShore = new Uint8Array(nCols);
    /* v4：每列收集 span [sy, r, g, b]（近→远，sy 递减）；之后列内逐行颜色插值，梯田硬边根治 */
    const colSpans = new Array(nCols);

    for (let i = 0; i < W; i += res) {
      const ci = i / res | 0;
      const rayA = cam.yaw + Math.atan((i - W / 2) / (W / 2) * fov);
      const dx = Math.sin(rayA), dz = -Math.cos(rayA);
      let d = 0.5, ybuf = H;
      let dStep = 0.16;
      while (d < maxDist && ybuf > 0) {
        const wx = cam.x + dx * d, wz = cam.z + dz * d;
        const th = sample(terrain, wx, wz);
        const surf = Math.max(th, wl);
        const sy = horizon - ((surf - camH) * scaleH) / d;
        if (sy < ybuf) {
          if (th > wl + 0.004 && colLand[ci] < 0) colLand[ci] = sy;  // 陆地露出（首个即最高）
          const hn = surf / terrain.amp;
          const slope = slopeAt(terrain, wx, wz);
          const shade = lightAt(terrain, wx, wz, sunA, sunK);
          /* --- 连续着色：高度带插值 --- */
          bandColor(pal, hn, rgb);
          let r = rgb[0], gg = rgb[1], b = rgb[2];
          /* --- 坡度平滑混合岩壁（sstep，非硬阈值） --- */
          const rockW = sstep(0.10, 0.30, slope);
          r += (pal.rock[0] - r) * rockW; gg += (pal.rock[1] - gg) * rockW; b += (pal.rock[2] - b) * rockW;
          if (hn <= wlN + 0.004) { r = pal.shallow[0]; gg = pal.shallow[1]; b = pal.shallow[2]; }
          /* --- biome 乘性色调（world() 随机世界） --- */
          if (useBiome) {
            const bx = ((wx | 0) % terrain.size + terrain.size) % terrain.size;
            const bz = ((wz | 0) % terrain.size + terrain.size) % terrain.size;
            const tint = BIOME_TINT[terrain.biome[bz * terrain.size + bx]];
            if (tint) { r *= tint[0]; gg *= tint[1]; b *= tint[2]; }
          }
          /* --- 连续纹理：双层低频 fbm（高频会沿射线步长混叠出横纹） --- */
          const t1 = fbm(wx * 3.5, wz * 3.5, terrain.seed + 31, 3);
          const t2 = fbm(wx * 10, wz * 10, terrain.seed + 77, 2);
          const n = (t1 - 0.5) * 20 + (t2 - 0.5) * 7;
          r += n; gg += n; b += n;
          r *= shade; gg *= shade; b *= shade;
          // 岸边湿沙暗带
          if (hn > wlN && hn < wlN + 0.035) {
            r = r * 0.62 + 40; gg = gg * 0.62 + 36; b = b * 0.62 + 34;
            colShore[ci] = 1;
          }
          // 距离雾
          const fog = Math.min(1, Math.pow(d / maxDist, 1.4));
          r = r * (1 - fog) + fogC[0] * fog;
          gg = gg * (1 - fog) + fogC[1] * fog;
          b = b * (1 - fog) + fogC[2] * fog;
          const rr = r | 0, ggg = gg | 0, bb = b | 0;
          (colSpans[ci] || (colSpans[ci] = [])).push([sy, rr, ggg, bb]);
          ybuf = sy;
        }
        d += dStep;
        dStep *= 1.018;
      }
    }

    /* ===== 列内逐行颜色插值（v4）：piecewise-linear 穿过各 span 采样点 =====
       旧版逐 span 平涂 → 崖壁出现 10~14px 梯田硬边（马赛克感根源）；
       现在每列按 span 边界逐行插值 → 连续竖向渐变，硬边消失。 */
    let yTop = H;
    for (let ci = 0; ci < nCols; ci++) {
      const A = colSpans[ci];
      if (A && A.length && A[A.length - 1][0] < yTop) yTop = A[A.length - 1][0];
    }
    if (yTop < H) {
      const yTopI = yTop < 0 ? 0 : Math.floor(yTop);
      const id = ctx.getImageData(0, yTopI, W, H - yTopI);
      const px = new Uint32Array(id.data.buffer);
      for (let ci = 0; ci < nCols; ci++) {
        const A = colSpans[ci];
        if (!A) continue;
        const i0 = ci * res;
        for (let k = 0; k < A.length; k++) {
          const sy = A[k][0], r = A[k][1], g = A[k][2], b = A[k][3];
          const syPrev = k === 0 ? H : A[k - 1][0];        // 近侧边界（sy 更大）
          const rP = k === 0 ? r : A[k - 1][1];
          const gP = k === 0 ? g : A[k - 1][2];
          const bP = k === 0 ? b : A[k - 1][3];
          if (sy >= H) continue;
          const yA = Math.max(yTopI, Math.ceil(sy)), yB = Math.min(H, Math.ceil(syPrev));
          const span = syPrev - sy;
          const rowBase = (yA - yTopI) * W + i0;
          for (let y = yA; y < yB; y++) {
            const tt = span > 0.001 ? (y - sy) / span : 0;
            const rr = (r + (rP - r) * tt) | 0;
            const gg = (g + (gP - g) * tt) | 0;
            const bb = (b + (bP - b) * tt) | 0;
            const c = (255 << 24) | (bb << 16) | (gg << 8) | rr;
            for (let p = 0; p < res; p++) px[rowBase + (y - yA) * W + p] = c;
          }
        }
      }
      ctx.putImageData(id, 0, yTopI);
    }

    /* ===== 水层：realtime 走 OVT.water 高度场引擎；否则经典渐变+粼光 ===== */
    if (opts.waterMode === "realtime") {
      renderWater(ctx, terrain, cam, opts);
    } else {
      for (let i = 0; i < W; i += res) {
        const ci = i / res | 0;
        /* 水带 = [horizon, 陆地遮挡处]；纯水列延伸到屏幕底（colLand=-1） */
        const land = colLand[ci];
        const top = land > 0 ? Math.min(land, H) : H;
        if (top <= horizon) continue;
        const wg = ctx.createLinearGradient(0, horizon, 0, top);
        wg.addColorStop(0, `rgba(${pal.water[0]},${pal.water[1]},${pal.water[2]},0.35)`);
        wg.addColorStop(0.35, `rgba(${pal.water[0]},${pal.water[1]},${pal.water[2]},0.82)`);
        wg.addColorStop(1, `rgba(${pal.water[0] * 0.7 | 0},${pal.water[1] * 0.7 | 0},${pal.water[2] * 0.8 | 0},0.92)`);
        ctx.fillStyle = wg;
        ctx.fillRect(i, horizon - 2, res, top - horizon + 2);
        // 波浪粼光（确定性多频正弦）
        const wave = Math.sin(i * 0.14 + t * 2.2) * Math.sin(i * 0.061 - t * 1.5)
                   + 0.5 * Math.sin(i * 0.31 - t * 3.1);
        const spec = Math.pow(Math.max(0, wave), 6);
        const distF = 1 - Math.min(1, (top - horizon) / H);
        if (spec > 0.30 && top - horizon > 10) {
          const sp = Math.min(0.85, spec * (0.3 + distF * 0.6));
          const w = 4 + spec * 8;
          const y = horizon + (top - horizon) * (0.1 + 0.55 * Math.abs(Math.sin(t * 1.7 + i * 0.9)));
          ctx.fillStyle = `rgba(${sunCol[0]},${sunCol[1]},${sunCol[2]},${sp})`;
          ctx.fillRect(i, y, w, 1.6);
        }
        // 岸边泡沫
        if (colShore[ci]) {
          const fg = ctx.createLinearGradient(0, top - 10, 0, top + 6);
          fg.addColorStop(0, `rgba(${pal.foam[0]},${pal.foam[1]},${pal.foam[2]},0)`);
          fg.addColorStop(0.6, `rgba(${pal.foam[0]},${pal.foam[1]},${pal.foam[2]},0.55)`);
          fg.addColorStop(1, `rgba(${pal.foam[0]},${pal.foam[1]},${pal.foam[2]},0)`);
          ctx.fillStyle = fg;
          ctx.fillRect(i, top - 10, res, 16);
        }
      }
    }

    return { horizon };
  }

  /* ============================================================
     CPU 实时水面引擎（v3）：
     每帧重算 6 频 Gerstner 高度场 → 有限差分法线 →
     天空渐变反射 + 菲涅尔 + 太阳镜面 + 深度透射 +
     波峰白丝 + 岸边泡沫。ImageData 整带写回（快路径）。
     用法：OVT.render(ctx,T,cam,{waterMode:"realtime",time:t})
           或独立调用 OVT.water(ctx,T,cam,opts)
     ============================================================ */
  function renderWater(ctx, terrain, cam, opts) {
    opts = opts || {};
    const W = ctx.canvas.width, H = ctx.canvas.height;
    const t = opts.time || 0;
    const pal = PALETTES[opts.palette || "natural"] || PALETTES.natural;
    const fogC = opts.fog || pal.fog;
    const sunCol = pal.sun || [255, 245, 220];
    const wl = terrain.water * terrain.amp;
    const horizon = H * 0.5 + (cam.pitch || 0) * H;
    const fov = cam.fov || 1.1;
    const scaleH = H * 0.9 * (cam.alt || 1);
    const camH = sample(terrain, cam.x, cam.z) + 0.25 + (cam.lift || 0);
    const sunA = opts.sun ? opts.sun[0] : 0.8;
    const maxDist = opts.maxDist || 150;
    if (camH <= wl + 0.02) return;                 // 相机贴水/水下 → 不画
    const wRes = opts.waterRes || 1;

    /* 确定性波场：13 低频 + 1 高频涟漪（种子派生，v5 翻倍） */
    const rnd = rng((terrain.seed ^ 0x51ed) >>> 0);
    const waves = [];
    for (let k = 0; k < 14; k++) {
      const ang = rnd() * Math.PI * 2;
      const kk = k === 13 ? 1.15 : 0.08 + rnd() * 0.30;
      waves.push({
        dx: Math.cos(ang) * kk, dz: Math.sin(ang) * kk,
        w: k === 13 ? 4.5 : 0.8 + rnd() * 2.2,
        a: k === 13 ? 0.0045 : (0.026 / (1 + k * 0.7)) * (0.6 + rnd() * 0.8),
        ph: rnd() * Math.PI * 2,
      });
    }
    function wh(x, z, tt) {
      let v = 0;
      for (let k = 0; k < 14; k++) {
        const wv = waves[k];
        v += wv.a * Math.sin(wv.dx * x + wv.dz * z + wv.w * tt + wv.ph);
      }
      return v;
    }

    /* 轻量列投射：只求每列陆地露出点（-1 = 纯水列，水延伸到屏幕底） */
    const nCols = (W / wRes | 0) + 2;
    const colLand = new Float32Array(nCols).fill(-1);
    const colDx = new Float32Array(nCols), colDz = new Float32Array(nCols);
    let anyWater = false;
    for (let i = 0; i < W; i += wRes) {
      const ci = i / wRes | 0;
      const rayA = cam.yaw + Math.atan((i - W / 2) / (W / 2) * fov);
      const dx = Math.sin(rayA), dz = -Math.cos(rayA);
      colDx[ci] = dx; colDz[ci] = dz;
      let d = 0.5, dStep = 0.22, land = -1;
      while (d < maxDist) {
        const th = sample(terrain, cam.x + dx * d, cam.z + dz * d);
        if (th > wl + 0.004) {
          const sy = horizon - ((th - camH) * scaleH) / d;
          if (sy < H && (land < 0 || sy < land)) land = sy;
          if (land >= 0 && land <= horizon) break;   // 陆地遮到地平线 → 该列水不可见
        }
        d += dStep; dStep *= 1.018;
      }
      colLand[ci] = land;
      if (land < 0 || land > horizon) anyWater = true;
    }
    if (!anyWater) return;

    /* 水带 bbox → ImageData 整带写回 */
    let yHi = 0;
    for (let ci = 0; ci < nCols; ci++) {
      const land = colLand[ci];
      const top = land > 0 ? Math.min(land, H) : H;
      if (top > yHi) yHi = top;
    }
    const y0 = Math.max(0, Math.floor(horizon));
    const y1 = Math.min(H, Math.ceil(yHi));
    if (y1 <= y0) return;
    const id = ctx.getImageData(0, y0, W, y1 - y0);
    const px = new Uint32Array(id.data.buffer);

    /* 太阳方向（方位对齐天空太阳光晕） */
    const phi = cam.yaw + sunA, el = 0.45;
    const Lx = Math.cos(el) * Math.sin(phi), Ly = Math.sin(el), Lz = -Math.cos(el) * Math.cos(phi);
    /* 天空渐变端点（pal.sky hex → rgb） */
    const hx2 = (hx) => { const n = parseInt(hx.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
    const skyTop = hx2(pal.sky[0]), skyBot = hx2(pal.sky[1]);
    const wr = pal.water[0], wg = pal.water[1], wb = pal.water[2];
    const sr = pal.shallow[0], sg2 = pal.shallow[1], sb = pal.shallow[2];
    const fr = fogC[0], fg = fogC[1], fb = fogC[2];
    const sunR = sunCol[0], sunG = sunCol[1], sunB = sunCol[2];

    for (let y = y0; y < y1; y++) {
      const row = (y - y0) * W;
      for (let i = 0; i < W; i += wRes) {
        const ci = i / wRes | 0;
        /* 该列水带顶：陆地遮挡处或屏幕底（纯水列） */
        const land = colLand[ci];
        const top = land > 0 ? Math.min(land, H) : H;
        if (top <= y) continue;                    // 地形已遮挡此行
        const d = (camH - wl) * scaleH / Math.max(1, y - horizon);
        const wx = cam.x + colDx[ci] * d, wz = cam.z + colDz[ci] * d;
        /* 波高 + 有限差分法线 */
        const e = 0.35;
        const hC = wh(wx, wz, t);
        const hx = (wh(wx + e, wz, t) - wh(wx - e, wz, t)) / (2 * e);
        const hz = (wh(wx, wz + e, t) - wh(wx, wz - e, t)) / (2 * e);
        let nx = -hx, ny = 1, nz = -hz;
        const nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
        nx /= nl; ny /= nl; nz /= nl;
        /* 视线 V */
        let vx = wx - cam.x, vy = wl + hC - camH, vz = wz - cam.z;
        const vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
        vx /= vl; vy /= vl; vz /= vl;
        /* 反射 R = V - 2(V·N)N → 天空色（反射角映射天空渐变） */
        const vd = vx * nx + vy * ny + vz * nz;
        const rx = vx - 2 * vd * nx, ry = vy - 2 * vd * ny, rz = vz - 2 * vd * nz;
        let skyR, skyG, skyB;
        if (ry > 0.02) {
          const u = Math.min(1, ry / 0.35);
          const uu = u * u * (3 - 2 * u);
          skyR = skyBot[0] + (skyTop[0] - skyBot[0]) * uu;
          skyG = skyBot[1] + (skyTop[1] - skyBot[1]) * uu;
          skyB = skyBot[2] + (skyTop[2] - skyBot[2]) * uu;
        } else { skyR = wr; skyG = wg; skyB = wb; }   // 反射朝下 → 深水
        /* 菲涅尔（nv = 法线·朝眼方向；俯视弱、掠射强） */
        const nv = Math.max(0, -(vx * nx + vy * ny + vz * nz));
        const F = 0.05 + 0.95 * Math.pow(1 - nv, 4.5);
        /* 水体色：远处深、近处透浅 */
        const near = 1 / (1 + d * 0.12);
        const bodyR = wr + (sr - wr) * near * 0.5;
        const bodyG = wg + (sg2 - wg) * near * 0.5;
        const bodyB = wb + (sb - wb) * near * 0.5;
        let r = bodyR * (1 - F) + skyR * (F + 0.08);
        let gg = bodyG * (1 - F) + skyG * (F + 0.08);
        let b = bodyB * (1 - F) + skyB * (F + 0.08);
        /* 太阳镜面（Blinn-Phong 高光带） */
        let hxv = Lx + vx, hyv = Ly + vy, hzv = Lz + vz;
        const hl = Math.sqrt(hxv * hxv + hyv * hyv + hzv * hzv);
        hxv /= hl; hyv /= hl; hzv /= hl;
        const spec = Math.pow(Math.max(0, nx * hxv + ny * hyv + nz * hzv), 240) * 1.6;
        if (spec > 0.003) {
          const s2 = Math.min(1, spec);
          r += (sunR - r) * s2; gg += (sunG - gg) * s2; b += (sunB - b) * s2;
        }
        /* 太阳反光路径：屏幕方位窄带 + 波高调制闪烁（俯视也可见） */
        const rayA = Math.atan2(colDx[ci], -colDz[ci]);
        const phiP = cam.yaw + Math.atan(1.68 * Math.cos(sunA) * fov);
        const dAng = rayA - phiP;
        const path = Math.exp(-(dAng * 3.0) * (dAng * 3.0)) * (0.55 + 0.45 * Math.min(1, hC * 18)) * 0.22;
        if (path > 0.01) {
          r += (sunR - r) * path; gg += (sunG - gg) * path; b += (sunB - b) * path;
        }
        /* 泡沫：岸边极浅窄带（浪线） + 波峰白丝 */
        const th = sample(terrain, wx, wz);
        const shore = (wl - th) / (terrain.amp * 0.05);
        if (shore > 0 && shore < 0.5) {
          const pulse = 0.55 + 0.45 * Math.sin(wx * 7 + wz * 5 + t * 3.2);
          const fa = (0.5 - shore) * 1.5 * pulse;
          r += (240 - r) * fa; gg += (246 - gg) * fa; b += (250 - b) * fa;
        }
        if (hC > 0.046) {
          const fa = Math.min(0.5, (hC - 0.046) * 9);
          r += (235 - r) * fa; gg += (244 - gg) * fa; b += (248 - b) * fa;
        }
        /* 距离雾（与地形一致） */
        const fog = Math.min(1, Math.pow(d / maxDist, 1.4));
        r = r * (1 - fog) + fr * fog;
        gg = gg * (1 - fog) + fg * fog;
        b = b * (1 - fog) + fb * fog;
        const ri = r < 0 ? 0 : r > 255 ? 255 : r | 0;
        const gi = gg < 0 ? 0 : gg > 255 ? 255 : gg | 0;
        const bi = b < 0 ? 0 : b > 255 ? 255 : b | 0;
        px[row + i] = (255 << 24) | (bi << 16) | (gi << 8) | ri;
      }
    }
    ctx.putImageData(id, 0, y0);
  }

  /* ---- 翻倍 biome 预设 v2：generate({...OVT.BIOMES.volcano, seed:3}) 一键切换地貌 ---- */
  const BIOMES = {
    archipelago: { size: 256, scale: 0.018, amp: 2.4, water: 0.34, rough: 0.45 },  // 群岛
    continent:   { size: 256, scale: 0.014, amp: 2.6, water: 0.22, rough: 0.55 },  // 大陆
    alpine:      { size: 256, scale: 0.020, amp: 2.8, water: 0.18, rough: 0.65 },  // 高山
    volcano:     { size: 256, scale: 0.022, amp: 3.0, water: 0.10, rough: 0.70 },  // 火山
    tundra:      { size: 256, scale: 0.016, amp: 1.9, water: 0.26, rough: 0.40 },  // 苔原
    jungle:      { size: 256, scale: 0.024, amp: 2.5, water: 0.30, rough: 0.60 },  // 丛林
    moon:        { size: 256, scale: 0.019, amp: 2.2, water: 0.00, rough: 0.50 },  // 月球（无水）
    lake:        { size: 256, scale: 0.017, amp: 2.0, water: 0.42, rough: 0.42 },  // 湖泽
    /* ---- 翻倍 biome 预设 v3（8 → 16）---- */
    canyon:      { size: 256, scale: 0.016, amp: 2.7, water: 0.14, rough: 0.72 },  // 峡谷（深切）
    reef:        { size: 256, scale: 0.024, amp: 2.2, water: 0.46, rough: 0.55 },  // 礁海（多岛浅水）
    mesa:        { size: 256, scale: 0.015, amp: 2.4, water: 0.12, rough: 0.35 },  // 平顶山（台地）
    glacier:     { size: 256, scale: 0.018, amp: 3.0, water: 0.20, rough: 0.30 },  // 冰川（低粗糙高振幅）
    swamp:       { size: 256, scale: 0.022, amp: 1.6, water: 0.50, rough: 0.60 },  // 沼泽（高水位）
    highland:    { size: 256, scale: 0.013, amp: 2.9, water: 0.22, rough: 0.58 },  // 高原（和缓台地）
    badlands:    { size: 256, scale: 0.019, amp: 2.5, water: 0.16, rough: 0.80 },  // 恶地（强侵蚀感）
    oasis:       { size: 256, scale: 0.020, amp: 2.1, water: 0.30, rough: 0.38 },  // 绿洲（沙中水泊）
  };

  window.OVT = {
    generate, world, render, water: renderWater, sample, slopeAt, fbm, noise2, ridged, sstep,
    PALETTES, BIOMES, BIOME_NAMES, BIOME_TINT, rng, hash2,
  };
})();
