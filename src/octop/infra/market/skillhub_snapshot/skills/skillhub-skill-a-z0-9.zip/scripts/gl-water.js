/* ============================================================
   opus-video · gl-water.js — GPU 实时地形 + 水面渲染（window.OVGL）
   WebGL1 全屏 fragment shader：
   · 真 3D raycast（ray 与地形高度场 + 水面平面分别求交，近者胜）
   · 高度场纹理上传（LUMINANCE 8bit，与 CPU sample 同双线性）
   · 地形：连续高度色带 + 坡度混合岩壁 + fbm 纹理 + 光照 + 距离雾
   · 水面：4 频程序化波法线 + 菲涅尔天空反射 + 太阳镜面 + 岸边/波峰泡沫
   · 天空：渐变 + 太阳 + fbm 云层
   与 CPU OVT.render 视锥/雾/波场同构 → 两条路径视觉一致。
   ============================================================ */
(function () {
  const VERT = `
attribute vec2 aPos;
varying vec2 vUv;
void main(){ vUv = aPos * 0.5 + 0.5; gl_Position = vec4(aPos, 0.0, 1.0); }`;

  const FRAG = `
precision highp float;
varying vec2 vUv;
uniform vec2  uRes;
uniform float uCamX, uCamH, uCamZ;
uniform float uYaw, uPitch, uFov;
uniform float uAmp, uWl, uTime, uSunA, uMaxDist, uSeed;
uniform sampler2D uHeight;
uniform vec3  uSkyTop, uSkyBot, uFog, uSunCol;
uniform vec3  uWaterD, uWaterS, uRock, uFoam, uShallow;
uniform vec3  uBands[5];
uniform float uBandHi[5];

float hash(vec2 p, float s){
  p = fract(p * 0.1031 + vec2(s * 0.017, s * 0.031));
  p += dot(p, p + 33.33);
  return fract((p.x + p.y) * p.x);
}
float vnoise(vec2 p, float s){
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  float a = hash(i, s), b = hash(i + vec2(1,0), s);
  float c = hash(i + vec2(0,1), s), d = hash(i + vec2(1,1), s);
  return a + (b-a)*u.x + (c-a)*u.y + (a-b-c+d)*u.x*u.y;
}
float fbm(vec2 p, float s){
  float v = 0.0, a = 0.5, f = 1.0, n = 0.0;
  for (int i = 0; i < 4; i++){ v += vnoise(p * f, s + float(i) * 13.7) * a; n += a; a *= 0.5; f *= 2.0; }
  return v / n;
}
float heightAt(vec2 p){
  vec2 uv = fract(p / 256.0);
  return texture2D(uHeight, uv).r;
}
vec3 sunDir(){
  float phi = uYaw + atan(1.68 * cos(uSunA) * uFov);
  float el = 0.45;
  return vec3(cos(el) * sin(phi), sin(el), -cos(el) * cos(phi));
}

/* ---- 3D raycast 地形（与 CPU 列投射同参数：d=0.5 起，dStep 0.16×1.018）
   线性穿越精化：射线在步间穿过高度场时插值交点 → 命中连续，无梯田量化边 ---- */
float marchTerrain(vec3 ro, vec3 rd, out vec3 hitP){
  float d = 0.5, ds = 0.16;
  float dPrev = d;
  float hPrev = heightAt((ro + rd * d).xz) * uAmp;
  for (int k = 0; k < 220; k++){
    if (d > uMaxDist) break;
    vec3 q = ro + rd * d;
    float h = heightAt(q.xz) * uAmp;
    if (q.y < h){
      /* 在 [dPrev, d] 之间对射线高度与地形高度做线性插值求交点 */
      float y0 = (ro + rd * dPrev).y, y1 = q.y;
      float denom = (y0 - hPrev) + (h - y1);
      float f = denom > 1e-5 ? (y0 - hPrev) / denom : 0.0;
      f = clamp(f, 0.0, 1.0);
      d = mix(dPrev, d, f);
      hitP = ro + rd * d;
      return d;
    }
    dPrev = d; hPrev = h;
    d += ds; ds *= 1.018;
  }
  return -1.0;
}

/* ---- 程序化波浪（4 低频 + 1 高频涟漪，解析导数得法线） ---- */
float waveH(vec2 p, float t){
  return 0.020 * sin(p.x * 0.21 + p.y * 0.13 + t * 1.4)
       + 0.016 * sin(p.x * 0.37 - p.y * 0.29 + t * 2.1)
       + 0.011 * sin(p.x * 0.61 + p.y * 0.44 - t * 2.8)
       + 0.007 * sin(p.x * 0.93 - p.y * 0.71 + t * 3.4)
       + 0.0055 * sin(p.x * 1.28 + p.y * 1.07 - t * 3.9)
       + 0.0042 * sin(p.x * 1.57 - p.y * 1.33 + t * 4.3)
       + 0.0031 * sin(p.x * 1.91 + p.y * 1.62 - t * 4.9)
       + 0.0023 * sin(p.x * 2.27 - p.y * 1.94 + t * 5.4)
       + 0.0045 * sin(p.x * 1.15 + p.y * 0.85 + t * 4.5);
}
vec2 waveN(vec2 p, float t){
  float e = 0.35;
  return vec2((waveH(p + vec2(e, 0.0), t) - waveH(p - vec2(e, 0.0), t)) / (2.0 * e),
              (waveH(p + vec2(0.0, e), t) - waveH(p - vec2(0.0, e), t)) / (2.0 * e));
}

vec3 shadeSky(vec3 rd){
  float u = clamp(rd.y / 0.5, 0.0, 1.0);
  vec3 col = mix(uSkyBot, uSkyTop, u * u * (3.0 - 2.0 * u));
  vec3 L = sunDir();
  float s = max(0.0, dot(rd, L));
  col += uSunCol * (pow(s, 900.0) * 0.95 + pow(s, 8.0) * 0.12);
  /* fbm 云层（随 t 漂移） */
  vec2 cp = vec2(atan(rd.x, -rd.z) - uYaw, rd.y) * 2.2;
  float dens = fbm(cp + vec2(uTime * 0.012, 0.0), 4242.0);
  float cloud = smoothstep(0.50, 0.62, dens) * smoothstep(0.05, 0.25, rd.y);
  col = mix(col, vec3(1.0), cloud * 0.55);
  return col;
}

vec3 shadeWater(vec3 P, vec3 rd, float d){
  vec2 g = waveN(P.xz, uTime);
  vec3 N = normalize(vec3(-g.x, 1.0, -g.y));
  float vd = dot(rd, N);
  vec3 R = rd - 2.0 * vd * N;
  vec3 skyRef = R.y > 0.02
    ? mix(uSkyBot, uSkyTop, smoothstep(0.0, 0.35, R.y))
    : uWaterD;
  float nv = clamp(-vd, 0.0, 1.0);          // 法线·朝眼方向
  float F = 0.05 + 0.95 * pow(1.0 - nv, 4.5);
  float near = 1.0 / (1.0 + d * 0.12);
  vec3 body = mix(uWaterD, uWaterS, near * 0.5);
  vec3 col = mix(body, skyRef, F) + skyRef * 0.08;
  /* 太阳镜面（收敛高光） */
  vec3 Hv = normalize(sunDir() + (-rd));
  float spec = pow(max(0.0, dot(N, Hv)), 300.0) * 1.3;
  col = mix(col, uSunCol, clamp(spec, 0.0, 1.0));
  /* 太阳反光路径（屏幕方位窄带 + 波高闪烁） */
  float rayA = atan(rd.x, -rd.z);
  float phiP = uYaw + atan(1.68 * cos(uSunA) * uFov);
  float dAng = rayA - phiP;
  float hC = waveH(P.xz, uTime);
  float path = exp(-(dAng * 3.0) * (dAng * 3.0)) * (0.55 + 0.45 * clamp(hC * 18.0, 0.0, 1.0)) * 0.22;
  col = mix(col, uSunCol, clamp(path, 0.0, 1.0));
  /* 岸边泡沫：仅极浅窄带（shore∈[0,0.5]）→ 浪线而非整片台地 */
  float th = heightAt(P.xz) * uAmp;
  float shore = (uWl * uAmp - th) / (uAmp * 0.05);
  if (shore > 0.0 && shore < 0.5){
    float pulse = 0.55 + 0.45 * sin(P.x * 7.0 + P.z * 5.0 + uTime * 3.2);
    col = mix(col, uFoam, (0.5 - shore) * 1.5 * pulse);
  }
  if (hC > 0.046) col = mix(col, uFoam, clamp((hC - 0.046) * 9.0, 0.0, 0.5));
  return col;
}

vec3 shadeTerrain(vec3 P, vec3 rd, float d){
  float h = heightAt(P.xz) * uAmp;
  float hn = h / uAmp;
  /* 连续高度色带 */
  vec3 c = uBands[0];
  for (int i = 1; i < 5; i++){
    if (hn < uBandHi[i]){
      float u = (hn - uBandHi[i-1]) / (uBandHi[i] - uBandHi[i-1]);
      c = mix(uBands[i-1], uBands[i], u);
      break;
    }
    c = uBands[i];
  }
  /* 坡度混合岩壁 */
  float e = 0.6;
  float hx = (heightAt(P.xz + vec2(e, 0.0)) - heightAt(P.xz - vec2(e, 0.0))) * uAmp;
  float hz = (heightAt(P.xz + vec2(0.0, e)) - heightAt(P.xz - vec2(0.0, e))) * uAmp;
  float slope = length(vec2(hx, hz));
  c = mix(c, uRock, smoothstep(0.10, 0.30, slope));
  if (hn <= uWl + 0.004) c = uShallow;
  /* 连续 fbm 纹理（低频防混叠横纹） */
  float t1 = fbm(P.xz * 3.5, uSeed + 31.0);
  float t2 = fbm(P.xz * 10.0, uSeed + 77.0);
  c += (t1 - 0.5) * 0.085 + (t2 - 0.5) * 0.03;
  /* 光照（与 CPU lightAt 同式） */
  float lit = clamp(0.62 + 0.266 * ((-hx * cos(uSunA) - hz * sin(uSunA)) * 2.2 + 0.35), 0.52, 1.3);
  c *= lit;
  /* 岸边湿沙暗带 */
  if (hn > uWl && hn < uWl + 0.035) c *= 0.72;
  return c;
}

void main(){
  vec2 ndc = vUv * 2.0 - 1.0;
  float ax = uYaw + atan(2.0 * ndc.x * uFov);
  float ay = uPitch + atan(2.0 * ndc.y * uFov * 0.62);
  vec3 rd = vec3(cos(ay) * sin(ax), sin(ay), -cos(ay) * cos(ax));
  vec3 ro = vec3(uCamX, uCamH, uCamZ);
  vec3 hitP;
  float dt = marchTerrain(ro, rd, hitP);
  float wlH = uWl * uAmp;
  float tw = (wlH - ro.y) / rd.y;
  bool isWater = (tw > 0.0) && (ro.y > wlH) && (dt < 0.0 || tw < dt);
  if (isWater){
    vec3 col = shadeWater(ro + rd * tw, rd, tw);
    float fog = min(1.0, pow(tw / uMaxDist, 1.4));
    col = mix(col, uFog, fog);
    gl_FragColor = vec4(col, 1.0);
  } else if (dt > 0.0){
    vec3 col = shadeTerrain(hitP, rd, dt);
    float fog = min(1.0, pow(dt / uMaxDist, 1.4));
    col = mix(col, uFog, fog);
    gl_FragColor = vec4(col, 1.0);
  } else {
    gl_FragColor = vec4(shadeSky(rd), 1.0);
  }
}`;

  const glsl = { prog: null, loc: {}, canvas: null, gl: null, tex: null };

  function compile(gl, type, src) {
    const s = gl.createShader(type);
    gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      throw new Error("shader: " + gl.getShaderInfoLog(s));
    }
    return s;
  }
  function init(canvas) {
    const gl = canvas.getContext("webgl", { antialias: true, preserveDrawingBuffer: true })
           || canvas.getContext("experimental-webgl", { antialias: true, preserveDrawingBuffer: true });
    if (!gl) throw new Error("WebGL 不可用");
    const vs = compile(gl, gl.VERTEX_SHADER, VERT);
    const fs = compile(gl, gl.FRAGMENT_SHADER, FRAG);
    const p = gl.createProgram();
    gl.attachShader(p, vs); gl.attachShader(p, fs); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error("link: " + gl.getProgramInfoLog(p));
    gl.useProgram(p);
    /* 全屏 quad */
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const aPos = gl.getAttribLocation(p, "aPos");
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
    /* uniform 位置 */
    const names = ["uRes", "uCamX", "uCamH", "uCamZ", "uYaw", "uPitch", "uFov",
      "uAmp", "uWl", "uTime", "uSunA", "uMaxDist", "uSeed", "uHeight",
      "uSkyTop", "uSkyBot", "uFog", "uSunCol", "uWaterD", "uWaterS", "uRock",
      "uFoam", "uShallow", "uBands", "uBandHi"];
    const loc = {};
    for (const n of names) loc[n] = gl.getUniformLocation(p, n);
    /* 高度图纹理 */
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
    gl.viewport(0, 0, canvas.width, canvas.height);
    glsl.gl = gl; glsl.canvas = canvas; glsl.loc = loc; glsl.tex = tex; glsl.prog = p;
    return glsl;
  }

  /* 上传高度场（terrain.h Float32Array [0,1] → LUMINANCE 8bit） */
  function setTerrain(terrain, palette) {
    const gl = glsl.gl;
    const n = terrain.size;
    const data = new Uint8Array(n * n);
    for (let k = 0; k < n * n; k++) data[k] = Math.max(0, Math.min(255, terrain.h[k] * 255)) | 0;
    gl.bindTexture(gl.TEXTURE_2D, glsl.tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, n, n, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, data);
    glsl.terrain = terrain;
    glsl.palette = palette || null;
  }

  /* 每帧渲染 */
  function render(cam, opts) {
    opts = opts || {};
    const gl = glsl.gl, loc = glsl.loc;
    const T = glsl.terrain;
    if (!T) return;
    const OVT = window.OVT;
    const pal = (OVT && OVT.PALETTES[opts.palette || "natural"]) || null;
    const camH = OVT.sample(T, cam.x, cam.z) * T.amp + 0.25 + (cam.lift || 0);
    gl.uniform2f(loc.uRes, glsl.canvas.width, glsl.canvas.height);
    gl.uniform1f(loc.uCamX, cam.x);
    gl.uniform1f(loc.uCamH, camH);
    gl.uniform1f(loc.uCamZ, cam.z);
    gl.uniform1f(loc.uYaw, cam.yaw);
    gl.uniform1f(loc.uPitch, cam.pitch || 0);
    gl.uniform1f(loc.uFov, cam.fov || 1.1);
    gl.uniform1f(loc.uAmp, T.amp);
    gl.uniform1f(loc.uWl, T.water);
    gl.uniform1f(loc.uTime, opts.time || 0);
    gl.uniform1f(loc.uSunA, opts.sun ? opts.sun[0] : 0.8);
    gl.uniform1f(loc.uMaxDist, opts.maxDist || 150);
    gl.uniform1f(loc.uSeed, T.seed);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, glsl.tex);
    gl.uniform1i(loc.uHeight, 0);
    const hex = (hx) => { const n = parseInt(hx.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; };
    const rgb = (c) => [c[0] / 255, c[1] / 255, c[2] / 255];
    if (pal) {
      gl.uniform3fv(loc.uSkyTop, hex(pal.sky[0]));
      gl.uniform3fv(loc.uSkyBot, hex(pal.sky[1]));
      gl.uniform3fv(loc.uFog, rgb(opts.fog || pal.fog));
      gl.uniform3fv(loc.uSunCol, rgb(pal.sun || [255, 245, 220]));
      gl.uniform3fv(loc.uWaterD, rgb(pal.water));
      gl.uniform3fv(loc.uWaterS, rgb(pal.shallow));
      gl.uniform3fv(loc.uRock, rgb(pal.rock));
      gl.uniform3fv(loc.uFoam, rgb(pal.foam));
      gl.uniform3fv(loc.uShallow, rgb(pal.shallow));
      const bc = [];
      for (const b of pal.bands) bc.push(b.col[0] / 255, b.col[1] / 255, b.col[2] / 255);
      gl.uniform3fv(loc.uBands, bc);
      const bh = [];
      for (const b of pal.bands) bh.push(b.hi);
      gl.uniform1fv(loc.uBandHi, bh);
    }
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  window.OVGL = { init, setTerrain, render };
})();
