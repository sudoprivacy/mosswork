/* ============================================================
   opus-video · model3d.js — 3D 模型加载引擎（window.OVM）
   导入：网格 JSON / OBJ / STL（ASCII+二进制）/ PLY（ASCII+二进制）
   渲染：画家算法 + Blinn-Phong 单网格 draw / 实例化批绘 instanced
         / 剪影视廓描边 outline
   依赖 motion-3d.js 的 OV.Camera3D 做正交基投影
   ============================================================ */
(function () {
  const _cache = {};

  /* 加载网格 JSON（同步 url / 异步） */
  function load(url, cb) {
    if (_cache[url]) { cb && cb(_cache[url]); return _cache[url]; }
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url, !!cb);
    xhr.onload = () => {
      const m = JSON.parse(xhr.responseText);
      _cache[url] = m; cb && cb(m);
    };
    xhr.send();
    if (!cb) { _cache[url] = JSON.parse(xhr.responseText); return _cache[url]; }
  }

  /* OBJ 文本解析（v/f 行；三角化） */
  function fromOBJ(text) {
    const pos = [], indices = [];
    for (const line of text.split("\n")) {
      const t = line.trim().split(/\s+/);
      if (t[0] === "v") pos.push([+t[1], +t[2], +t[3]]);
      else if (t[0] === "f") {
        const idx = t.slice(1).map(s => (parseInt(s.split("/")[0], 10) - 1));
        for (let k = 1; k + 1 < idx.length; k++) indices.push(idx[0], idx[k], idx[k + 1]);
      }
    }
    return normalize({ name: "obj", positions: pos, indices });
  }

  /* STL 解析：string 走 ASCII（solid/facet/outer loop/vertex），ArrayBuffer 走二进制
     二进制 STL：80B 头 + uint32 面数 + 50B/面（法线 3f + 顶点 9f + uint16 属性） */
  function fromSTL(input) {
    const positions = [], indices = [];
    if (typeof input === "string") {
      const verts = [];
      for (const line of input.split("\n")) {
        const t = line.trim().split(/\s+/);
        if (t[0] === "vertex") verts.push([+t[1], +t[2], +t[3]]);
      }
      for (let i = 0; i + 2 < verts.length; i += 3) {
        const base = positions.length;
        positions.push(verts[i], verts[i + 1], verts[i + 2]);
        indices.push(base, base + 1, base + 2);
      }
      return normalize(weld({ name: "stl", positions, indices }));
    }
    const buf = input instanceof ArrayBuffer ? input : input.buffer;
    const dv = new DataView(buf);
    const tris = Math.min(dv.getUint32(80, true), Math.floor((dv.byteLength - 84) / 50));
    for (let i = 0; i < tris; i++) {
      const base = positions.length;
      for (let v = 0; v < 3; v++) {
        const p = 84 + i * 50 + 12 + v * 12;
        positions.push([dv.getFloat32(p, true), dv.getFloat32(p + 4, true), dv.getFloat32(p + 8, true)]);
      }
      indices.push(base, base + 1, base + 2);
    }
    return normalize(weld({ name: "stl-bin", positions, indices }));
  }

  /* PLY 解析：ASCII / binary_little_endian / binary_big_endian
     支持 property list uchar|uint8|int|uint vertex_indices，任意附加属性（nx/uv/color）自动跳过 */
  function fromPLY(input) {
    const isStr = typeof input === "string";
    const buf = isStr ? null : (input instanceof ArrayBuffer ? input : input.buffer);
    let headText, bodyStart;
    if (isStr) {
      const headEnd = input.indexOf("end_header");
      if (headEnd < 0) throw new Error("PLY: missing end_header");
      headText = input.slice(0, headEnd);
      bodyStart = headEnd + "end_header".length;
    } else {
      const bytes = new Uint8Array(buf);
      const probe = new TextDecoder("latin1").decode(bytes.subarray(0, Math.min(bytes.length, 1 << 16)));
      const headEnd = probe.indexOf("end_header");
      if (headEnd < 0) throw new Error("PLY: missing end_header");
      headText = probe.slice(0, headEnd);
      bodyStart = headEnd + "end_header".length;
      while (bodyStart < bytes.length && (bytes[bodyStart] === 13 || bytes[bodyStart] === 10)) bodyStart++;
    }
    let format = "ascii", nV = 0, nF = 0, elem = null;
    const vProps = [], fListProps = [];
    for (const raw of headText.split("\n")) {
      const t = raw.trim().split(/\s+/);
      if (!t[0] || t[0] === "ply" || t[0] === "comment" || t[0] === "obj_info") continue;
      if (t[0] === "format") format = t[1];
      else if (t[0] === "element") {
        elem = t[1];
        if (elem === "vertex") nV = +t[2] || 0;
        else if (elem === "face") nF = +t[2] || 0;
      }
      else if (t[0] === "property" && elem === "vertex") vProps.push({ type: t[1], name: t[2] });
      else if (t[0] === "property" && elem === "face" && t[1] === "list") fListProps.push({ count: t[2], type: t[3], name: t[4] });
    }
    const xi = vProps.findIndex(p => p.name === "x");
    const yi = vProps.findIndex(p => p.name === "y");
    const zi = vProps.findIndex(p => p.name === "z");
    if (xi < 0 || yi < 0 || zi < 0) throw new Error("PLY: missing x/y/z vertex properties");
    const positions = [], indices = [];
    const SZ = { char: 1, uchar: 1, uint8: 1, int8: 1, short: 2, ushort: 2, uint16: 2, int16: 2, int: 4, uint: 4, uint32: 4, float: 4, float32: 4, double: 8, float64: 8 };
    function rdNum(dv, off, type, le) {
      switch (type) {
        case "char": case "int8": return dv.getInt8(off);
        case "uchar": case "uint8": return dv.getUint8(off);
        case "short": case "int16": return dv.getInt16(off, le);
        case "ushort": case "uint16": return dv.getUint16(off, le);
        case "int": case "uint": case "uint32": return dv.getInt32(off, le);
        case "float": case "float32": return dv.getFloat32(off, le);
        case "double": case "float64": return dv.getFloat64(off, le);
      }
      return 0;
    }
    if (format === "ascii") {
      const body = isStr ? input.slice(bodyStart)
        : new TextDecoder("latin1").decode(new Uint8Array(buf).subarray(bodyStart));
      const tok = body.split(/\s+/).filter(s => s.length);
      let p = 0;
      for (let i = 0; i < nV; i++) {
        const xyz = [0, 0, 0];
        for (const pr of vProps) {
          const val = +tok[p++];
          if (pr.name === "x") xyz[0] = val;
          else if (pr.name === "y") xyz[1] = val;
          else if (pr.name === "z") xyz[2] = val;
        }
        positions.push(xyz);
      }
      for (let i = 0; i < nF; i++) {
        const cnt = +tok[p++];
        const first = +tok[p];
        for (let k = 1; k + 1 < cnt; k++) indices.push(first, +tok[p + k], +tok[p + k + 1]);
        p += cnt;
      }
    } else {
      const dv = new DataView(buf);
      const le = format.indexOf("little") >= 0;
      let off = bodyStart;
      for (let i = 0; i < nV; i++) {
        const xyz = [0, 0, 0];
        for (const pr of vProps) {
          const val = rdNum(dv, off, pr.type, le);
          off += SZ[pr.type] || 4;
          if (pr.name === "x") xyz[0] = val;
          else if (pr.name === "y") xyz[1] = val;
          else if (pr.name === "z") xyz[2] = val;
        }
        positions.push(xyz);
      }
      for (let i = 0; i < nF && fListProps.length; i++) {
        const pr = fListProps[0];
        const cnt = rdNum(dv, off, pr.count, le); off += SZ[pr.count] || 1;
        const vs = [];
        for (let k = 0; k < cnt; k++) { vs.push(rdNum(dv, off, pr.type, le)); off += SZ[pr.type] || 4; }
        for (let k = 1; k + 1 < vs.length; k++) indices.push(vs[0], vs[k], vs[k + 1]);
      }
    }
    return normalize(weld({ name: "ply", positions, indices }));
  }

  /* 顶点焊接：按量化坐标合并重复顶点（STL 逐面存顶点/PLY Quad 网格必需），并去退化面 */
  function weld(m, eps) {
    const e = eps || 1e-4;
    const q = v => Math.round(v / e);
    const map = new Map(), positions = [], remap = [];
    for (const p of m.positions) {
      const key = q(p[0]) + "," + q(p[1]) + "," + q(p[2]);
      let id = map.get(key);
      if (id == null) { id = positions.length; positions.push(p); map.set(key, id); }
      remap.push(id);
    }
    const indices = [];
    for (let i = 0; i < m.indices.length; i += 3) {
      const a = remap[m.indices[i]], b = remap[m.indices[i + 1]], c = remap[m.indices[i + 2]];
      if (a !== b && b !== c && a !== c) indices.push(a, b, c);
    }
    m.positions = positions; m.indices = indices;
    return m;
  }

  /* 居中归一化到半径 1 */
  function normalize(m) {
    const pos = m.positions;
    let cx = 0, cy = 0, cz = 0;
    for (const p of pos) { cx += p[0]; cy += p[1]; cz += p[2]; }
    cx /= pos.length; cy /= pos.length; cz /= pos.length;
    let r = 0;
    for (const p of pos) r = Math.max(r, Math.hypot(p[0] - cx, p[1] - cy, p[2] - cz));
    r = r || 1;
    m.positions = pos.map(p => [(p[0] - cx) / r, (p[1] - cy) / r, (p[2] - cz) / r]);
    return m;
  }

  /* 渲染网格（单实例内核；外部请用 draw / instanced）
     ctx / cam: OV.Camera3D 实例（相机已 place）
     opts: {pos:[x,y,z], scale, yaw, pitch, color, light:[x,y,z]方向, edge, alpha, cull:true} */
  function _drawOne(ctx, mesh, cam, opts) {
    const o = opts || {};
    const scale = (o.scale || 1) * 1.0;
    const yaw = o.yaw || 0, pitch = o.pitch || 0;
    const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
    const col = o.color || [200, 210, 220];
    const light = o.light || [0.5, 0.8, 0.3];
    const pos = mesh.positions, idx = mesh.indices;

    // 变换 + 投影全部顶点
    const n = pos.length;
    const proj = new Array(n);
    const L = norm(light);
    for (let i = 0; i < n; i++) {
      let x = pos[i][0] * scale, y = pos[i][1] * scale, z = pos[i][2] * scale;
      // yaw（绕 y）
      let x2 = x * cy + z * sy, z2 = -x * sy + z * cy;
      // pitch（绕 x）
      let y2 = y * cp - z2 * sp, z3 = y * sp + z2 * cp;
      const off = o.pos || [0, 0, 0];
      const pr = cam.project({ x: x2 + off[0], y: y2 + off[1], z: z3 + off[2] });
      proj[i] = pr || { x: 0, y: 0, z: 0, alpha: 0 };   // 近平面后方 → 该面后续被剔除
    }
    // 面 + 深度排序（画家算法）
    const faces = [];
    for (let f = 0; f < idx.length; f += 3) {
      const a = idx[f], b = idx[f + 1], c = idx[f + 2];
      const pa = pos[a], pb = pos[b], pc = pos[c];
      // 世界空间法线（已含旋转：用旋转后顶点近似即可，误差可忽略）
      const e1 = sub(rot(pb, yaw, pitch), rot(pa, yaw, pitch));
      const e2 = sub(rot(pc, yaw, pitch), rot(pa, yaw, pitch));
      const nrm = norm(cross(e1, e2));
      // 视线方向（相机→面心）
      const ctr = rot([(pa[0]+pb[0]+pc[0])/3*scale, (pa[1]+pb[1]+pc[1])/3*scale, (pa[2]+pb[2]+pc[2])/3*scale], yaw, pitch);
      const off = o.pos || [0, 0, 0];
      const view = norm(sub3([ctr[0]+off[0], ctr[1]+off[1], ctr[2]+off[2]], [cam.pos.x, cam.pos.y, cam.pos.z]));
      const back = nrm[0]*view[0] + nrm[1]*view[1] + nrm[2]*view[2];
      if (o.cull !== false && back > 0) continue;   // 背面剔除
      const diff = Math.max(0.18, -(nrm[0]*L[0] + nrm[1]*L[1] + nrm[2]*L[2]));
      const depth = proj[a].z + proj[b].z + proj[c].z;
      faces.push({ a, b, c, diff, depth });
    }
    faces.sort((p, q) => q.depth - p.depth);
    ctx.globalAlpha = o.alpha != null ? o.alpha : 1;
    for (const f of faces) {
      const A = proj[f.a], B = proj[f.b], C = proj[f.c];
      if (A.alpha === 0 || B.alpha === 0 || C.alpha === 0) continue;
      const sp = f.spec || 0;
      ctx.fillStyle = `rgb(${Math.min(255, col[0]*f.diff + sp*230)|0},${Math.min(255, col[1]*f.diff + sp*230)|0},${Math.min(255, col[2]*f.diff + sp*230)|0})`;
      ctx.beginPath();
      ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.lineTo(C.x, C.y);
      ctx.closePath(); ctx.fill();
      if (o.edge) {
        ctx.strokeStyle = o.edge; ctx.lineWidth = 0.5;
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
    return faces.length;
  }

  /* 单网格渲染 */
  function draw(ctx, mesh, cam, opts) { return _drawOne(ctx, mesh, cam, opts); }

  /* 同网格多实例批量绘制（共享一次面遍历，逐实例变换）
     items: [{pos, scale, yaw, pitch, color, edge, alpha, ...}, ...]，opts 为全局默认值 */
  function instanced(ctx, mesh, cam, items, opts) {
    const base = opts || {};
    let total = 0;
    for (const it of items) {
      const o = {};
      for (const k in base) o[k] = base[k];
      for (const k in it) o[k] = it[k];
      total += _drawOne(ctx, mesh, cam, o);
    }
    return total;
  }

  /* 剪影视廓描边：对正面面集合求「仅属于一个正面」的边（几何键，兼容未焊接网格）并描边
     用法：先 outline 再 draw 原网格盖心；opts 同 draw，额外：
     - expand: 网格外扩系数（默认 1.05，决定描边厚度）
     - width / color / glow: 线宽 / 颜色 / shadowBlur 光晕 */
  function outline(ctx, mesh, cam, opts) {
    const o = opts || {};
    const scale = (o.scale || 1) * (o.expand != null ? o.expand : 1.05);
    const yaw = o.yaw || 0, pitch = o.pitch || 0;
    const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
    const pos = mesh.positions, idx = mesh.indices;
    const off = o.pos || [0, 0, 0];
    const proj = new Array(pos.length), tp = new Array(pos.length);
    for (let i = 0; i < pos.length; i++) {
      let x = pos[i][0] * scale, y = pos[i][1] * scale, z = pos[i][2] * scale;
      let x2 = x * cy + z * sy, z2 = -x * sy + z * cy;
      let y2 = y * cp - z2 * sp, z3 = y * sp + z2 * cp;
      const wx = x2 + off[0], wy = y2 + off[1], wz = z3 + off[2];
      tp[i] = [wx, wy, wz];
      proj[i] = cam.project({ x: wx, y: wy, z: wz }) || { x: 0, y: 0, z: 0, alpha: 0 };
    }
    const seen = new Map();
    const q = v => Math.round(v * 1000);
    for (let f = 0; f < idx.length; f += 3) {
      const A = tp[idx[f]], B = tp[idx[f + 1]], C = tp[idx[f + 2]];
      const nrm = norm(cross(sub(B, A), sub(C, A)));
      const ctr = [(A[0] + B[0] + C[0]) / 3, (A[1] + B[1] + C[1]) / 3, (A[2] + B[2] + C[2]) / 3];
      const view = norm(sub3(ctr, [cam.pos.x, cam.pos.y, cam.pos.z]));
      if (nrm[0] * view[0] + nrm[1] * view[1] + nrm[2] * view[2] > 0) continue;   // 背面不构成轮廓
      for (const [i1, i2] of [[idx[f], idx[f + 1]], [idx[f + 1], idx[f + 2]], [idx[f + 2], idx[f]]]) {
        const P = tp[i1], Q = tp[i2];
        const k1 = q(P[0]) + "," + q(P[1]) + "," + q(P[2]);
        const k2 = q(Q[0]) + "," + q(Q[1]) + "," + q(Q[2]);
        const key = k1 < k2 ? k1 + "|" + k2 : k2 + "|" + k1;
        const rec = seen.get(key);
        if (rec) rec.count++;
        else seen.set(key, { count: 1, P: proj[i1], Q: proj[i2] });
      }
    }
    ctx.save();
    ctx.globalAlpha = o.alpha != null ? o.alpha : 1;
    ctx.strokeStyle = o.color || "rgba(0,0,0,0.9)";
    ctx.lineWidth = o.width || 2;
    ctx.lineJoin = "round";
    if (o.glow) { ctx.shadowColor = o.color || "rgba(0,0,0,0.9)"; ctx.shadowBlur = o.glow; }
    let strokes = 0;
    for (const e of seen.values()) {
      if (e.count !== 1) continue;                       // 仅剪影边
      if (e.P.alpha === 0 || e.Q.alpha === 0) continue;
      ctx.beginPath();
      ctx.moveTo(e.P.x, e.P.y); ctx.lineTo(e.Q.x, e.Q.y);
      ctx.stroke(); strokes++;
    }
    ctx.restore();
    return strokes;
  }

  /* 网格统计（选型/调试用） */
  function stats(mesh) {
    const pos = mesh.positions || [];
    const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (const p of pos) for (let k = 0; k < 3; k++) {
      if (p[k] < mn[k]) mn[k] = p[k];
      if (p[k] > mx[k]) mx[k] = p[k];
    }
    return {
      name: mesh.name || "mesh",
      vertices: pos.length,
      faces: (mesh.indices || []).length / 3,
      min: mn, max: mx,
      size: [mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]]
    };
  }

  /* ---- 工具 ---- */
  function rot(p, yaw, pitch) {
    const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
    const x2 = p[0] * cy + p[2] * sy, z2 = -p[0] * sy + p[2] * cy;
    return [x2, p[1] * cp - z2 * sp, p[1] * sp + z2 * cp];
  }
  function sub(a, b) { return [a[0]-b[0], a[1]-b[1], a[2]-b[2]]; }
  const sub3 = sub;
  function cross(a, b) {
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
  }
  function norm(a) {
    const l = Math.hypot(a[0], a[1], a[2]) || 1;
    return [a[0]/l, a[1]/l, a[2]/l];
  }

  window.OVM = { load, fromOBJ, fromSTL, fromPLY, weld, normalize, draw, instanced, outline, stats };
})();
