#!/usr/bin/env python3
"""
opus-video / assemble.py
多场景拼接器：把多个 scene.html 分别渲染、统一规格、做转场、拼成一支长片，
并按全局时间轴生成配乐与字幕。

用法:
  python3 assemble.py film.json
  python3 assemble.py film.json --skip-render      # 复用已有 frames（改音频/字幕时）

film.json 结构:
{
  "output": "final.mp4",
  "width": 1920, "height": 1080, "fps": 30,
  "transition": {"type": "fade", "dur": 0.5},
  "audio": {"mood": "epic", "bpm": 120, "hits": [4.0, 12.5]},
  "scenes": [
    {"html": "sc01_open.html", "dur": 4.0, "name": "开场"},
    {"html": "sc02_data.html", "dur": 6.0, "name": "数据", "transition_in": {"type":"whip","dur":0.45}}
  ],
  "subtitles": [
    {"start": 0.4, "end": 3.6, "text": "确定性渲染"},
    {"start": 4.2, "end": 9.5, "text": "每一帧都是 t 的纯函数"}
  ]
}

行为:
  1. 逐场景调用 render.py（可并行），各自输出 frames/scN
  2. 用 ffmpeg 把每场景编码为统一规格的中间片段
  3. 按转场拼接（17 种：fade / whip / cut / dipblack / glitch / rgbGlitch / flashCut /
     circleWipe / slideUp / smoothZoom / pixelize / radial / diagWipe / vSlice / hBlur /
     dissolve / zoom / wipe / slide），交叉淡化用 xfade
  4. 生成配乐（audio.py），按全局时间轴叠加字幕（可选烧录）
  5. 产出 final.mp4，可直接交给 publish_check.py
"""
import argparse
import concurrent.futures
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def run(cmd, quiet=True):
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if p.returncode != 0 and not quiet:
        print(p.stdout)
        print(p.stderr)
    return p.returncode, p.stdout, p.stderr


def encode_variant():
    """探测可用 H.264 编码器：优先 libx264，退化 libopenh264"""
    rc, out, _ = run("ffmpeg -hide_banner -encoders 2>/dev/null | grep -c libx264")
    if out.strip() and int(out.strip()) > 0:
        return "-c:v libx264 -preset medium -crf 20"
    return "-c:v libopenh264 -b:v 8M"


def render_scene(scene, idx, cfg, workdir):
    """渲染单个场景，返回中间片路径与真实时长"""
    html = scene["html"]
    frames = os.path.join(workdir, f"frames/sc{idx}")
    fps = cfg.get("fps", 30)
    # 优先复用已有帧
    if not cfg.get("__skip_render") or not os.path.isdir(frames) or len(os.listdir(frames)) == 0:
        cmd = f'cd "{os.path.dirname(os.path.abspath(html))}" && python3 "{HERE}/render.py" "{os.path.basename(html)}" "{frames}" {fps}'
        rc, out, err = run(cmd)
        if rc != 0:
            raise RuntimeError(f"场景 {idx} 渲染失败: {err[-800:]}")
    n = len([f for f in os.listdir(frames) if f.endswith(".png")])
    dur = n / fps
    # 统一规格编码（偶数宽高由 scale 保证）
    w, h = cfg.get("width", 1280), cfg.get("height", 720)
    enc = encode_variant()
    mid = os.path.join(workdir, f"seg{idx}.mp4")
    cmd = (f'ffmpeg -y -v error -framerate {fps} -i "{frames}/f%04d.png" '
           f'-vf "scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=black" '
           f'{enc} -pix_fmt yuv420p -r {fps} "{mid}"')
    rc, _, err = run(cmd)
    if rc != 0:
        raise RuntimeError(f"场景 {idx} 编码失败: {err[-500:]}")
    return {"idx": idx, "path": mid, "dur": dur, "name": scene.get("name", f"场景{idx}")}


def build_audio(cfg, total, workdir, cut_points=None):
    """生成音乐 + 音效混音轨。
    cut_points: [(t, transition_type), ...] —— 每个剪辑点自动踩点音效。"""
    a = cfg.get("audio") or {}
    if not a or a.get("mood") == "none":
        return None
    out = os.path.join(workdir, "bgm.wav")
    hits = list(a.get("hits", []))
    cues = []   # (t, name, amp)
    # 剪辑点自动踩点
    for t, ttype in (cut_points or []):
        if ttype in ("cut", "jcut"):
            cues.append((max(0, t - 0.12), "whoosh", 0.8))
            cues.append((t, "click", 0.9))
        elif ttype in ("whip",):
            cues.append((max(0, t - 0.35), "whoosh", 1.0))
            cues.append((t, "impact", 0.8))
        elif ttype in ("dipblack",):
            cues.append((max(0, t - 0.4), "riser", 0.7))
            cues.append((t, "boom", 0.8))
        elif ttype in ("glitch", "rgbGlitch"):
            cues.append((max(0, t - 0.2), "metal", 0.5))
            cues.append((t, "click", 0.9))
            cues.append((t + 0.06, "error", 0.5))
        elif ttype in ("flashCut",):
            cues.append((max(0, t - 0.25), "riser", 0.4))
            cues.append((t, "impact", 0.9))
        else:   # fade/dissolve/slide/zoom/wipe/圆扫/像素化/斜切/竖切/模糊
            cues.append((max(0, t - 0.3), "whoosh", 0.7))
    # 用户显式 cues（film.json: audio.sfx: "3.0=impact,6.0=sparkle"）
    for part in str(a.get("sfx", "")).split(","):
        part = part.strip()
        if "=" in part:
            t, rest = part.split("=", 1)
            amp = 1.0
            if ":" in rest:
                rest, amp = rest.split(":", 1)
                amp = float(amp)
            cues.append((float(t), rest.strip(), amp))
            if float(t) not in hits:
                hits.append(float(t))
    sfx = ",".join(f"{t:.3f}={n}" + (f":{g}" if g != 1.0 else "") for t, n, g in sorted(cues))
    cmd = (f'python3 "{HERE}/audio.py" "{out}" --dur {total:.3f} '
           f'--bpm {a.get("bpm", 120)} --mood {a.get("mood", "tech")} '
           f'--hits "{",".join(str(h) for h in hits)}" --sfx "{sfx}" '
           f'--music-gain {a.get("music_gain", 0.72)} --sfx-gain {a.get("sfx_gain", 0.95)}')
    rc, _, err = run(cmd)
    if rc != 0:
        print(f"  配乐生成失败（继续无音轨）: {err[-300:]}")
        return None
    print(f"  音效轨: {len(cues)} 个 cue（剪辑点自动踩点 + 显式指定）")
    return out


def write_srt(subs, path):
    def ts(x):
        h = int(x // 3600); m = int(x % 3600 // 60); s = int(x % 60); ms = int((x - int(x)) * 1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
    with open(path, "w", encoding="utf-8") as f:
        for i, s in enumerate(subs, 1):
            f.write(f"{i}\n{ts(s['start'])} --> {ts(s['end'])}\n{s['text']}\n\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--skip-render", action="store_true")
    ap.add_argument("--burn-subs", action="store_true", help="把字幕烧进画面（默认只附 .srt）")
    args = ap.parse_args()

    cfg = json.load(open(args.config))
    cfg["__skip_render"] = args.skip_render
    workdir = os.path.join(os.path.dirname(os.path.abspath(args.config)), "_build")
    os.makedirs(workdir, exist_ok=True)
    fps = cfg.get("fps", 30)
    scenes = cfg["scenes"]
    print(f"共 {len(scenes)} 个场景")

    # 1. 并行渲染（2 路，避免 CPU 打满互相拖慢）
    results = [None] * len(scenes)
    with concurrent.futures.ThreadPoolExecutor(max_workers=cfg.get("parallel", 4)) as ex:
        futs = {ex.submit(render_scene, s, i, cfg, workdir): i for i, s in enumerate(scenes)}
        for fu in concurrent.futures.as_completed(futs):
            i = futs[fu]
            results[i] = fu.result()
            print(f"  场景 {i} 完成: {results[i]['dur']:.2f}s")

    # 2. 计算拼接时间轴（转场处两段重叠）
    default_tr = cfg.get("transition", {"type": "fade", "dur": 0.5})
    timeline, acc = [], 0.0
    for i, r in enumerate(results):
        tin = scenes[i].get("transition_in") or (default_tr if i > 0 else {"type": "none", "dur": 0})
        tdur = float(tin.get("dur", 0)) if tin.get("type") not in (None, "none") else 0.0
        start = max(0.0, acc - tdur)
        timeline.append({"start": start, "dur": r["dur"], "tr": tin, "tdur": tdur})
        acc = start + r["dur"]
    total = acc
    print(f"总时长: {total:.2f}s")

    # 3a. 收集剪辑点（供音效踩点；用 list 以便 xfade 成功后同步前移）
    cut_points = [[timeline[i]["start"], (scenes[i].get("transition_in") or default_tr if i > 0 else {}).get("type", "cut")]
                  for i in range(1, len(results))]

    # 3. 拼接（逐段串行：每步产出临时片，避免多输入滤镜链的时序/格式问题）
    silent = os.path.join(workdir, "silent.mp4")
    cur = results[0]["path"]
    cur_dur = results[0]["dur"]
    for i in range(1, len(results)):
        tl = timeline[i]
        tr = tl["tr"] or {}
        ttype = tr.get("type")
        tdur = min(float(tl["tdur"]), cur_dur - 0.1, results[i]["dur"] - 0.1)
        nxt = os.path.join(workdir, f"chain{i}.mp4")
        DIAG = {"fade": "fade", "dissolve": "dissolve", "whip": "slideleft",
                "slide": "slideleft", "zoom": "zoomin", "wipe": "wipeleft",
                "dipblack": "fadeblack", "cut": None, "jcut": None,
                # ---- 翻倍转场库 v2（xfade 映射 7 → 18；cut/jcut 另走 concat 硬切）----
                "glitch": "hlslice", "rgbGlitch": "hrslice", "flashCut": "fadewhite",
                "circleWipe": "circlecrop", "slideUp": "slideup", "smoothZoom": "zoomin",
                "pixelize": "pixelize", "radial": "radial", "diagWipe": "diagtr",
                "vSlice": "vuslice", "hBlur": "hblur",
                # ---- 翻倍转场库 v3（20 → 40；已本地 ffmpeg 实测）----
                "wipeRight": "wiperight", "wipeUp": "wipeup", "wipeDown": "wipedown",
                "slideRight": "slideright", "slideDown": "slidedown",
                "circleOpen": "circleopen", "circleClose": "circleclose",
                "rectCrop": "rectcrop", "vertClose": "vertclose",
                "distance": "distance", "fadeGrays": "fadegrays",
                "diagTL": "diagtl", "diagBL": "diagbl", "diagBR": "diagbr",
                "vSliceD": "vdslice", "wipeTL": "wipetl", "wipeTR": "wipetr",
                "wipeBL": "wipebl", "wipeBR": "wipebr", "smoothLeft": "smoothleft"}
        if ttype in DIAG and tdur > 0.05:
            off = max(0, cur_dur - tdur)
            trans = DIAG[ttype]
            cmd = (f'ffmpeg -y -v error -i "{cur}" -i "{results[i]["path"]}" '
                   f'-filter_complex "[0:v][1:v]xfade=transition={trans}:duration={tdur:.3f}:offset={off:.3f}[v]" '
                   f'-map "[v]" {encode_variant()} -pix_fmt yuv420p -r {fps} "{nxt}"')
            rc, _, err = run(cmd)
            if rc == 0:
                cur_dur = off + results[i]["dur"]
                # 去除转场重叠后，后续时间轴（含音效踩点）整体前移
                for j in range(i + 1, len(timeline)):
                    timeline[j]["start"] -= tdur
                    cut_points[j - 1][0] -= tdur
                cur = nxt
                continue
            print(f"  段 {i} 转场({trans})失败，改用硬切: {err.strip().splitlines()[-1][:120] if err.strip() else ''}")
        # 硬切（whip/cut/失败退化）
        lst = os.path.join(workdir, "list.txt")
        with open(lst, "w") as f:
            f.write(f"file '{os.path.abspath(cur)}'\nfile '{os.path.abspath(results[i]['path'])}'\n")
        rc, _, err = run(f'ffmpeg -y -v error -f concat -safe 0 -i "{lst}" {encode_variant()} -pix_fmt yuv420p -r {fps} "{nxt}"')
        if rc != 0:
            raise RuntimeError(f"段 {i} 拼接失败: {err[-400:]}")
        cur_dur += results[i]["dur"]
        cur = nxt
    run(f'ffmpeg -y -v error -i "{cur}" -c copy "{silent}"')
    total = cur_dur

    # 4. 配乐 + 字幕
    bgm = build_audio(cfg, total, workdir, cut_points)
    out = cfg.get("output", "final.mp4")
    if not os.path.isabs(out):
        out = os.path.join(os.path.dirname(os.path.abspath(args.config)), out)

    srt = os.path.join(workdir, "subs.srt")
    has_subs = bool(cfg.get("subtitles"))
    if has_subs:
        write_srt(cfg["subtitles"], srt)

    if args.burn_subs and has_subs:
        # 烧录字幕：需要 libass + 转义路径
        vf = f"subtitles='{srt}':force_style='FontName=Noto Sans CJK SC,FontSize=22,PrimaryColour=&H00FFFFFF,BorderStyle=1,Outline=1'"
        vf = vf.replace("\\", "/").replace(":", "\\:")
        cmd = f'ffmpeg -y -v error -i "{silent}"'
        if bgm:
            cmd += f' -i "{bgm}"'
        cmd += f' -vf "{vf}" {encode_variant()} -pix_fmt yuv420p'
        if bgm:
            cmd += ' -c:a aac -b:a 192k -shortest'
        cmd += f' -movflags +faststart "{out}"'
    else:
        cmd = f'ffmpeg -y -v error -i "{silent}"'
        if bgm:
            cmd += f' -i "{bgm}" -c:a aac -b:a 192k -shortest'
        cmd += f' -c:v copy -movflags +faststart "{out}"'
    rc, _, err = run(cmd)
    if rc != 0:
        raise RuntimeError(f"最终封装失败: {err[-600:]}")

    if has_subs and not args.burn_subs:
        import shutil
        shutil.copy(srt, os.path.splitext(out)[0] + ".srt")
        print(f"  字幕文件: {os.path.splitext(out)[0]}.srt")

    print(f"完成: {out}  总时长 {total:.2f}s  场景 {len(results)}  音轨 {'有' if bgm else '无'}")
    print(f"下一步: python3 publish_check.py \"{out}\" --expect {cfg.get('width',1280)}x{cfg.get('height',720)} --fps {fps} --dur {total:.2f}")


if __name__ == "__main__":
    main()
