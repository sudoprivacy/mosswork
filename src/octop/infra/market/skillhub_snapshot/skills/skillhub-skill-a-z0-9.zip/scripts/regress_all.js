/* opus-video 翻倍能力全量回归 v3（Node 侧）
   覆盖：motion-3d（SHOOT 72 / FX 40 / TYPE 22 / D3）
        · fx-plus（LOOK 12 / WEATHER 5 / DOF 3）
        · model3d（STL/PLY/instanced/outline）· terrain（16 调色板 + 16 biome + 14 频波场）
        · physics（10 能力：确定性/绳索/软体/爆炸/磁场/布料/弹簧/摆链/涡流/湍流）
   运行：node regress_all.js */
const fs = require("fs");
const path = require("path");
const SKILL = "/root/.codebuddy/skills/opus-video";

/* ---- 浏览器桩 ---- */
function makeCtx(w = 1280, h = 720) {
  const log = [];
  const grad = { addColorStop: () => {} };
  return {
    log, canvas: { width: w, height: h },
    fillStyle: "", strokeStyle: "", lineWidth: 1, lineJoin: "", lineCap: "",
    globalAlpha: 1, globalCompositeOperation: "source-over",
    shadowColor: "", shadowBlur: 0, font: "", textAlign: "", textBaseline: "",
    filter: "none",
    measureText: t => ({ width: String(t).length * 20 }),
    createLinearGradient: () => grad, createRadialGradient: () => grad,
    createPattern: () => null,
    getImageData: (x, y, ww, hh) => ({ data: new Uint8ClampedArray(ww * hh * 4), width: ww, height: hh }),
    putImageData: () => {}, drawImage: () => {},
    save: () => log.push("save"), restore: () => log.push("restore"),
    beginPath: () => log.push("beginPath"),
    moveTo: () => {}, lineTo: () => {}, closePath: () => log.push("closePath"),
    fill: () => log.push("fill"), stroke: () => log.push("stroke"),
    fillRect: () => log.push("fillRect"), strokeRect: () => {}, clearRect: () => {},
    fillText: t => log.push("fillText " + t), strokeText: () => log.push("strokeText"),
    arc: () => log.push("arc"), ellipse: () => log.push("ellipse"),
    translate: () => {}, rotate: () => {}, scale: () => {}, transform: () => {}, setTransform: () => {},
    clip: () => {}, rect: () => log.push("rect"),
    quadraticCurveTo: () => {}, bezierCurveTo: () => {},
  };
}
global.window = global;
global.document = { createElement: () => ({ width: 0, height: 0, getContext: () => makeCtx(0, 0) }) };

const OV = require(path.join(SKILL, "motion-3d.js"));
const OVX = require(path.join(SKILL, "fx-plus.js"));
require(path.join(SKILL, "model3d.js"));   // 挂 global.OVM
require(path.join(SKILL, "terrain.js"));   // 挂 global.OVT
require(path.join(SKILL, "physics.js"));   // 挂 global.OVP
const OVM = global.OVM, OVT = global.OVT, OVP = global.OVP;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { pass++; console.log("  PASS  " + msg); }
  else { fail++; console.log("  FAIL  " + msg); }
}

/* ========== A. SHOOT 72 运镜 ========== */
console.log("\n[A] SHOOT 运镜库（目标 72）");
const shootKeys = Object.keys(OV.SHOOT).filter(k => typeof OV.SHOOT[k] === "function");
const moves = shootKeys.filter(k => !["compose", "sequence", "apply"].includes(k));
ok(moves.length === 72, `运镜函数 ${moves.length} 个（72 = 原 36 + 新 36）`);
// 非 (t,a,b) 签名的运镜需专属调用（generic (t,0,2) 会把 0 传给 at/period 等参数）
const special = {
  handheld: () => OV.SHOOT.handheld(1.0),
  impact: () => OV.SHOOT.impact(1.0, 0.5),
  breathe: () => OV.SHOOT.breathe(1.0),
  zoomPunch: () => OV.SHOOT.zoomPunch(1.0, 0.5),
  roll: () => OV.SHOOT.roll(1.0),
  snorricam: () => OV.SHOOT.snorricam(1.0),
  steadicam: () => OV.SHOOT.steadicam(1.0),
  shake: () => OV.SHOOT.shake(1.0, 0.5),
  floatDrift: () => OV.SHOOT.floatDrift(1.0),
  pushPullBreath: () => OV.SHOOT.pushPullBreath(1.0),
};
let bad = [];
for (const k of moves) {
  try {
    const r = (special[k] || (() => OV.SHOOT[k](1.0, 0, 2)))();
    if (!r || typeof r !== "object" || !Object.values(r).every(v => typeof v !== "number" || Number.isFinite(v))) bad.push(k + ":返回值异常");
  } catch (e) { bad.push(k + ":" + e.message); }
}
ok(bad.length === 0, `72 运镜逐一调用全部返回有限数值${bad.length ? " → " + bad.join("; ") : ""}`);
// 窗口型运镜窗外归零（历史 bug 回归）
ok(OV.SHOOT.whipPan(5, 0, 1, 900, -1).x === 0 && OV.SHOOT.whipPan(5, 0, 1, 900, -1).blur === 0, "whipPan 窗外归零");
ok(!OV.SHOOT.zoomPunch(5, 1.2).zoom || OV.SHOOT.zoomPunch(5, 1.2).zoom === 1, "zoomPunch 窗外归零");
ok(!OV.SHOOT.impact(5, 1.2).zoom || OV.SHOOT.impact(5, 1.2).zoom === 1, "impact 窗外归零");
// compose / sequence
const comp = OV.SHOOT.compose(1.5, [{ fn: t => OV.SHOOT.pushIn(t, 0, 3) }, { fn: t => OV.SHOOT.pan(t, 0, 3, -60) }]);
ok(comp && comp.zoom > 1 && comp.x < 0, `compose 叠加运镜（zoom ${comp.zoom.toFixed(3)} / x ${comp.x.toFixed(1)}）`);
const seq = OV.SHOOT.sequence(1.5, [{ move: "pushIn", from: 0, to: 3 }]);
ok(seq && typeof seq === "object" && seq.zoom > 1, "sequence 按 move 名调度");
// 确定性
const cA = OV.SHOOT.compose(1.5, [{ fn: t => OV.SHOOT.pushIn(t, 0, 3) }, { fn: t => OV.SHOOT.pan(t, 0, 3, -60) }]);
ok(JSON.stringify(cA) === JSON.stringify(comp), "compose 确定性");

/* ========== B. FX 40 后期 ========== */
console.log("\n[B] FX 后期库（目标 40）");
const fxKeys = Object.keys(OV.FX).filter(k => typeof OV.FX[k] === "function");
ok(fxKeys.length === 40, `FX 后期 ${fxKeys.length} 个（40 = 原 20 + 新 20）`);
const fxCalls = {
  motionBlur: c => OV.FX.motionBlur(c, 3, () => {}, 4),
  vignette: c => OV.FX.vignette(c, 1280, 720),
  grain: c => OV.FX.grain(c, 1280, 720, 1.0),
  glow: c => OV.FX.glow(c, 640, 360, 200, "rgba(255,255,255,0.5)"),
  letterbox: c => OV.FX.letterbox(c, 1280, 720),
  scanlines: c => OV.FX.scanlines(c, 1280, 720),
  scrim: c => OV.FX.scrim(c, 1280, 720),
  flash: c => OV.FX.flash(c, 1280, 720, 0.5),
  grade: c => OV.FX.grade(c, 1280, 720, "255,200,120", 0.3),
  halation: c => OV.FX.halation(c, 1280, 720),
  lightLeak: c => OV.FX.lightLeak(c, 1280, 720, 1.0),
  filmBurn: c => OV.FX.filmBurn(c, 1280, 720, 1.0, 0.8),
  chromatic: c => OV.FX.chromatic(c, 1280, 720),
  glitch: c => OV.FX.glitch(c, 1280, 720, 1.0),
  bokeh: c => OV.FX.bokeh(c, 1280, 720, 1.0),
  vhs: c => OV.FX.vhs(c, 1280, 720, 1.0),
  dreamy: c => OV.FX.dreamy(c, 1280, 720),
  duotone: c => OV.FX.duotone(c, 1280, 720),
  rgbPulse: c => OV.FX.rgbPulse(c, 1280, 720, 1.0, 0.9),
  godRays: c => OV.FX.godRays(c, 1280, 720, 640, 300),
  // ---- v3 新增 20 ----
  dof: c => OV.FX.dof(c, 1280, 720, 2.5, 0.22),
  rain: c => OV.FX.rain(c, 1280, 720, 1.0),
  snow: c => OV.FX.snow(c, 1280, 720, 1.0),
  dust: c => OV.FX.dust(c, 1280, 720, 1.0),
  fogLayer: c => OV.FX.fogLayer(c, 1280, 720, 1.0),
  lightShaft: c => OV.FX.lightShaft(c, 1280, 720, 640, 300),
  irisBlur: c => OV.FX.irisBlur(c, 1280, 720, 2, 0.3),
  radialBlur: c => OV.FX.radialBlur(c, 1280, 720, 0.12, 6),
  tiltBlur: c => OV.FX.tiltBlur(c, 1280, 720, 10, 0),
  pixelMosaic: c => OV.FX.pixelMosaic(c, 1280, 720, 400, 300, 300, 200, 12),
  edgeGlow: c => OV.FX.edgeGlow(c, 1280, 720),
  lutGrade: c => OV.FX.lutGrade(c, 1280, 720, "tealOrange", 1),
  filmGate: c => OV.FX.filmGate(c, 1280, 720, 1.0),
  anamorphic: c => OV.FX.anamorphic(c, 1280, 720, 640, 300),
  starfield: c => OV.FX.starfield(c, 1280, 720, 1.0),
  bokehFloat: c => OV.FX.bokehFloat(c, 1280, 720, 1.0),
  heatWave: c => OV.FX.heatWave(c, 1280, 720, 1.0),
  underwater: c => OV.FX.underwater(c, 1280, 720, 1.0),
  crtCurve: c => OV.FX.crtCurve(c, 1280, 720, 1.0),
  hologram: c => OV.FX.hologram(c, 1280, 720, 1.0),
};
let fxBad = [];
for (const [k, fn] of Object.entries(fxCalls)) {
  try { fn(makeCtx()); } catch (e) { fxBad.push(k + ":" + e.message); }
}
ok(fxBad.length === 0, `40 后期逐一 ctx 调用无抛错${fxBad.length ? " → " + fxBad.join("; ") : ""}`);
// godRays 实际产出光楔
const gctx = makeCtx();
OV.FX.godRays(gctx, 1280, 720, 640, 300, 5, 1.2, 0.2);
ok(gctx.log.filter(l => l === "fill").length === 5, `godRays 产出 5 个光楔（实际 ${gctx.log.filter(l => l === "fill").length}）`);
// lutGrade 六预设全覆盖
let lutBad = [];
for (const p of ["tealOrange", "bleach", "noir", "golden", "cyber", "cross"]) {
  try { OV.FX.lutGrade(makeCtx(), 1280, 720, p, 1); } catch (e) { lutBad.push(p + ":" + e.message); }
}
ok(lutBad.length === 0, `lutGrade 6 预设全部可跑${lutBad.length ? " → " + lutBad.join("; ") : ""}`);

/* ========== C. TYPE 22 + LOOK 12 排版 ========== */
console.log("\n[C] 排版特效（TYPE 22 + LOOK 12 = 34）");
const typeKeys = Object.keys(OV.TYPE).filter(k => typeof OV.TYPE[k] === "function");
ok(typeKeys.length === 22, `TYPE ${typeKeys.length} 个（22 = 原 11 + 新 11）`);
const typeCalls = {
  perChar: c => OV.TYPE.perChar(c, "CodeBody 测试", 1.0, 0.5),
  wrap: c => OV.TYPE.wrap(c, "一二三四五六七八九十", 200, "24px sans"),
  cycle: () => OV.TYPE.cycle(1.0, ["甲", "乙"], 0.5),
  stat: () => OV.TYPE.stat(1.0, 0.5, 1.0, 42),
  lineMask: c => OV.TYPE.lineMask(c, "逐行揭幕", 1.0, 0.5),
  scramble: c => OV.TYPE.scramble(c, "SCRAMBLE", 100, 100, 1.0, 0.5),
  splitReveal: c => OV.TYPE.splitReveal(c, "裂开", 100, 100, 1.0, 0.5),
  waveText: c => OV.TYPE.waveText(c, "波浪", 100, 100, 1.0),
  stamp: c => OV.TYPE.stamp(c, "盖章", 100, 100, 1.0, 0.5),
  stackText: c => OV.TYPE.stackText(c, ["一", "二"], 100, 100, 1.0, 0.5),
  countdown: c => OV.TYPE.countdown(c, 100, 100, 1.0, 5, 0.5),
  // ---- v3 新增 11 ----
  typeOn: c => OV.TYPE.typeOn(c, "机打文字", 1.0, 0),
  blurIn: c => OV.TYPE.blurIn(c, "模糊聚焦", 1.0, 0),
  flipChar: c => OV.TYPE.flipChar(c, "翻牌", 1.0, 0),
  dropChar: c => OV.TYPE.dropChar(c, "落字", 1.0, 0),
  neonFlicker: c => OV.TYPE.neonFlicker(c, "霓虹", 1.0, 0),
  glitchText: c => OV.TYPE.glitchText(c, "故障", 1.0, 0),
  wavePath: c => OV.TYPE.wavePath(c, "波路径", 1.0, 0),
  bubbleText: c => OV.TYPE.bubbleText(c, "弹跳", 1.0, 0),
  rotateIn: c => OV.TYPE.rotateIn(c, "旋入", 1.0, 0),
  shatterText: c => OV.TYPE.shatterText(c, "碎裂", 1.0, 0),
  matrixChar: c => OV.TYPE.matrixChar(c, "矩阵", 1.0, 0),
};
let typeBad = [];
for (const [k, fn] of Object.entries(typeCalls)) {
  try { fn(makeCtx()); } catch (e) { typeBad.push(k + ":" + e.message); }
}
ok(typeBad.length === 0, `22 排版逐一调用无抛错${typeBad.length ? " → " + typeBad.join("; ") : ""}`);
const lookKeys = Object.keys(OVX.LOOK).filter(k => typeof OVX.LOOK[k] === "function");
ok(lookKeys.length === 12, `LOOK ${lookKeys.length} 个（12 = 原 6 + 新 6）`);
let lookBad = [];
try { OVX.LOOK.gradientText(makeCtx(), "渐变字", 100, 100, "48px sans", "#fff", "#000"); } catch (e) { lookBad.push("gradientText:" + e.message); }
try { OVX.LOOK.typewriter(makeCtx(), "打字机文字", 100, 100, 1.0, 0.5); } catch (e) { lookBad.push("typewriter:" + e.message); }
try { OVX.LOOK.neon(makeCtx(), "霓虹", 100, 100, 1.0); } catch (e) { lookBad.push("neon:" + e.message); }
try { OVX.LOOK.marquee(makeCtx(), "跑马灯", 100, 100, 1.0); } catch (e) { lookBad.push("marquee:" + e.message); }
try { OVX.LOOK.chromeText(makeCtx(), "金属字", 100, 100, "48px sans"); } catch (e) { lookBad.push("chromeText:" + e.message); }
try { OVX.LOOK.glassText(makeCtx(), "玻璃字", 100, 100, "48px sans"); } catch (e) { lookBad.push("glassText:" + e.message); }
try { OVX.LOOK.fireText(makeCtx(), "火焰字", 100, 100, "48px sans", 1.0); } catch (e) { lookBad.push("fireText:" + e.message); }
try { OVX.LOOK.iceText(makeCtx(), "冰晶字", 100, 100, "48px sans"); } catch (e) { lookBad.push("iceText:" + e.message); }
try { OVX.LOOK.rainbowFlow(makeCtx(), "彩虹流", 100, 100, "48px sans", 1.0); } catch (e) { lookBad.push("rainbowFlow:" + e.message); }
try { OVX.LOOK.stroke3D(makeCtx(), "3D 凸出", 100, 100, "48px sans"); } catch (e) { lookBad.push("stroke3D:" + e.message); }
ok(lookBad.length === 0, `LOOK 12 深度调用无抛错${lookBad.length ? " → " + lookBad.join("; ") : ""}`);

/* ========== C2. WEATHER 5 + DOF 3 ========== */
console.log("\n[C2] 天气 + 景深（WEATHER 5 + DOF 3）");
const weatherKeys = Object.keys(OVX.WEATHER).filter(k => typeof OVX.WEATHER[k] === "function");
const dofKeys = Object.keys(OVX.DOF).filter(k => typeof OVX.DOF[k] === "function");
ok(weatherKeys.length === 5, `WEATHER ${weatherKeys.length} 个（${weatherKeys.join("/")}）`);
ok(dofKeys.length === 3, `DOF ${dofKeys.length} 个（${dofKeys.join("/")}）`);
let wBad = [];
try { OVX.WEATHER.rain(makeCtx(), 1280, 720, 1.0); } catch (e) { wBad.push("rain:" + e.message); }
try { OVX.WEATHER.snow(makeCtx(), 1280, 720, 1.0); } catch (e) { wBad.push("snow:" + e.message); }
try { OVX.WEATHER.dustMotes(makeCtx(), 1280, 720, 1.0); } catch (e) { wBad.push("dustMotes:" + e.message); }
try { OVX.WEATHER.fogBank(makeCtx(), 1280, 720, 1.0); } catch (e) { wBad.push("fogBank:" + e.message); }
try { OVX.WEATHER.storm(makeCtx(), 1280, 720, 1.0); } catch (e) { wBad.push("storm:" + e.message); }
ok(wBad.length === 0, `WEATHER 5 逐一调用无抛错${wBad.length ? " → " + wBad.join("; ") : ""}`);
let dBad = [];
try { OVX.DOF.focusBlur(makeCtx(), 1280, 720, 2.5, 0.34); } catch (e) { dBad.push("focusBlur:" + e.message); }
try { OVX.DOF.tiltShift(makeCtx(), 1280, 720, 0.3, 2.5); } catch (e) { dBad.push("tiltShift:" + e.message); }
try { OVX.DOF.bokehField(makeCtx(), 1280, 720, 1.0); } catch (e) { dBad.push("bokehField:" + e.message); }
ok(dBad.length === 0, `DOF 3 逐一调用无抛错${dBad.length ? " → " + dBad.join("; ") : ""}`);
// 天气确定性（同 t 两次调用 log 一致）
const rnA = makeCtx(), rnB = makeCtx();
OVX.WEATHER.rain(rnA, 1280, 720, 2.5);
OVX.WEATHER.rain(rnB, 1280, 720, 2.5);
ok(JSON.stringify(rnA.log) === JSON.stringify(rnB.log), "WEATHER.rain 确定性（同 t 同图案）");

/* ========== D. D3 几何（film2 规范模式回归） ========== */
console.log("\n[D] D3 几何/渲染");
const cam = new OV.Camera3D({ x: 0, y: 0, z: -900, cx: 640, cy: 360 });
cam.lookAt({ x: 0, y: 0, z: 0 });
const cubeFaces = OV.D3.cube(0, 0, 0, 200, "#1c2b3a", { stroke: "#8fd", lineWidth: 2 });
ok(Array.isArray(cubeFaces) && cubeFaces.length === 6, `D3.cube 生成 6 面（实际 ${cubeFaces.length}）`);
const dctx = makeCtx();
let renderErr = null;
try { cam.render(dctx, cubeFaces, {}); } catch (e) { renderErr = e.message; }
ok(!renderErr, `cam.render 绘制无抛错${renderErr ? " → " + renderErr : ""}`);
ok(OV.D3.V && OV.D3.line && OV.D3.orbit && OV.D3.grid && OV.D3.field && OV.D3.spinFace, "D3 工具函数齐全（V/line/orbit/grid/field/spinFace）");

/* ========== E. model3d 翻倍能力（轻量复核） ========== */
console.log("\n[E] 模型引擎（STL/PLY/instanced/outline）");
const quadSTL = `solid q
facet normal 0 0 1
outer loop
vertex 0 0 0
vertex 100 0 0
vertex 100 100 0
endloop
endfacet
facet normal 0 0 1
outer loop
vertex 0 0 0
vertex 100 100 0
vertex 0 100 0
endloop
endfacet
endsolid q`;
const mq = OVM.fromSTL(quadSTL);
const sq = OVM.stats(mq);
ok(sq.vertices === 4 && sq.faces === 2, `ASCII STL 焊接（${sq.vertices} 顶点 / ${sq.faces} 面）`);
const ply = `ply
format ascii 1.0
element vertex 4
property float x
property float y
property float z
element face 1
property list uchar int vertex_indices
end_header
0 0 0
100 0 0
100 100 0
0 100 0
4 0 1 2 3`;
const mp = OVM.fromPLY(ply);
const sp = OVM.stats(mp);
ok(sp.vertices === 4 && sp.faces === 2, `ASCII PLY Quad 拆面（${sp.vertices} 顶点 / ${sp.faces} 面）`);
const mctx = makeCtx();
const cubeOBJ = `v -50 -50 -50
v 50 -50 -50
v 50 50 -50
v -50 50 -50
v -50 -50 50
v 50 -50 50
v 50 50 50
v -50 50 50
f 1 4 3 2
f 5 6 7 8
f 1 2 6 5
f 2 3 7 6
f 3 4 8 7
f 4 1 5 8`;
const mObj = OVM.fromOBJ(cubeOBJ);
const cam2 = new OV.Camera3D({ x: -600, y: 500, z: -900, cx: 640, cy: 360 });
cam2.lookAt({ x: 0, y: 0, z: 0 });
const fCount = OVM.draw(mctx, mObj, cam2, { scale: 200, color: [180, 200, 220] });
ok(fCount === 6, `draw 斜角机位 6 正面（实际 ${fCount}）`);
const iCount = OVM.instanced(mctx, mObj, cam2, [{ pos: [-300, 0, 0] }, { pos: [0, 0, 0] }, { pos: [300, 0, 0] }], { scale: 150 });
ok(iCount === 18, `instanced 3 实例 18 面（实际 ${iCount}）`);
const oCount = OVM.outline(mctx, mObj, cam2, { scale: 200 });
ok(oCount === 6, `outline 6 条剪影视廓边（实际 ${oCount}）`);

/* ========== F. terrain 16 调色板 + 16 biome ========== */
console.log("\n[F] 地形引擎（调色板 16 + biome 16 + 14 频波场）");
const palKeys = Object.keys(OVT.PALETTES);
const biomeKeys = Object.keys(OVT.BIOMES);
ok(palKeys.length === 16, `调色板 ${palKeys.length} 个（${palKeys.join("/")}）`);
ok(biomeKeys.length === 16, `biome ${biomeKeys.length} 个（${biomeKeys.join("/")}）`);
const T = OVT.generate({ seed: 7, size: 64, scale: 0.02, amp: 2.2, water: 0.32, rough: 0.5 });
ok(T && T.h && T.h.length === 64 * 64, `generate 64×64 高度图（${T.h.length} 点）`);
const hv = OVT.sample(T, 32, 32), sl = OVT.slopeAt(T, 32, 32);
ok(Number.isFinite(hv) && Number.isFinite(sl), `sample/slopeAt 有限（h=${hv.toFixed(3)} slope=${sl.toFixed(3)}）`);
let tErr = null;
try { OVT.render(makeCtx(), T, {}); } catch (e) { tErr = e.message; }
ok(!tErr, `render 绘制无抛错${tErr ? " → " + tErr : ""}`);
// 16 个调色板逐一渲染
let palBad = [];
for (const k of palKeys) {
  try { OVT.render(makeCtx(), T, {}, { palette: k }); } catch (e) { palBad.push(k + ":" + e.message); }
}
ok(palBad.length === 0, `16 调色板逐一渲染无抛错${palBad.length ? " → " + palBad.join("; ") : ""}`);
// biome 预设可直接喂 generate
let biomeBad = [];
for (const k of biomeKeys) {
  try { OVT.generate(Object.assign({ seed: 3, size: 32 }, OVT.BIOMES[k])); } catch (e) { biomeBad.push(k + ":" + e.message); }
}
ok(biomeBad.length === 0, `16 个 biome 预设均可生成${biomeBad.length ? " → " + biomeBad.join("; ") : ""}`);

/* ---- F2. GTA 式随机世界 + CPU 实时水 ---- */
console.log("\n[F2] 随机世界 + 实时水");
const W1 = OVT.world(1234, { size: 64 });
const W2 = OVT.world(9999, { size: 64 });
ok(W1.biome.length === 64 * 64, `world 64×64 + biome 图（${W1.biome.length}）`);
let diffCnt = 0;
for (let k = 0; k < W1.h.length; k++) if (Math.abs(W1.h[k] - W2.h[k]) > 0.05) diffCnt++;
ok(diffCnt / W1.h.length > 0.8, `不同 seed 地貌差异 ${(diffCnt / W1.h.length * 100).toFixed(0)}%（GTA 式随机）`);
const W1b = OVT.world(1234, { size: 64 });
ok(W1b.h.every((v, i) => v === W1.h[i]), "world 同 seed 确定性（逐位一致）");
const biomeSet = new Set(W1.biome);
ok(biomeSet.size >= 3, `biome 多样性：${biomeSet.size} 类（${[...biomeSet].map(b => OVT.BIOME_NAMES[b]).join("/")}）`);
/* 实时水：持久 backing store 验证逐帧重算（t 不同 → 像素不同） */
function waterCtx(w, h) {
  const base = makeCtx(w, h);
  const store = new Map();
  base.__store = store;
  base.getImageData = (x, y, ww, hh) => {
    const key = x + "," + y + "," + ww + "," + hh;
    if (!store.has(key)) store.set(key, new Uint8ClampedArray(ww * hh * 4));
    return { data: store.get(key), width: ww, height: hh };
  };
  base.putImageData = () => {};
  return base;
}
const TW = OVT.generate({ seed: 3, size: 64, water: 0.34, amp: 2.2 });
const camW = { x: 32, z: 32, yaw: 0.9, lift: 5.0, alt: 1.2, pitch: 0.12, fov: 1.2 };
const wcA = waterCtx(320, 200), wcB = waterCtx(320, 200);
let rwErr = null;
try {
  OVT.render(wcA, TW, camW, { palette: "sunset", time: 0.5, waterMode: "realtime", maxDist: 120 });
  OVT.render(wcB, TW, camW, { palette: "sunset", time: 2.5, waterMode: "realtime", maxDist: 120 });
} catch (e) { rwErr = e.message; }
ok(!rwErr, `realtime 水渲染无抛错${rwErr ? " → " + rwErr : ""}`);
let wDiff = 0;
if (!rwErr) {
  for (const [k, arr] of wcA.__store) {
    const other = wcB.__store.get(k);
    if (!other) continue;
    for (let i = 0; i < arr.length; i += 4) {
      if (Math.abs(arr[i] - other[i]) > 2) wDiff++;
    }
  }
}
ok(wDiff > 50, `实时水逐帧重算：${wDiff} 像素随时间变化（t=0.5 vs t=2.5，14 频波场）`);
let wErr2 = null;
try { OVT.render(makeCtx(), TW, {}, { palette: "natural" }); } catch (e) { wErr2 = e.message; }
ok(!wErr2, `经典水模式回归无抛错${wErr2 ? " → " + wErr2 : ""}`);
// GPU 路径：gl-water.js 源码级校验（API 齐备 + 着色器关键件）
const glSrc = fs.readFileSync(path.join(SKILL, "gl-water.js"), "utf8");
ok(/window\.OVGL\s*=\s*\{\s*init/.test(glSrc), "gl-water.js 导出 OVGL.init");
ok(/float waveH\(/.test(glSrc) && /marchTerrain\(/.test(glSrc), "gl-water.js 波场 + raycast 着色器齐备");
ok((glSrc.match(/sin\(p\.x \* [\d.]+/g) || []).length >= 9, `gl-water.js GPU 波场 10 项（实测 ${(glSrc.match(/sin\(p\.x \* [\d.]+/g) || []).length} 项）`);
ok(glSrc.includes("1.68 * cos(uSunA) * uFov"), "gl-water.js 太阳反光路径与 CPU 同方位约定");

/* ========== G. physics 十能力 ========== */
console.log("\n[G] 物理引擎（10 能力）");
const scatterOpts = { radius: 300, height: 380, seed: 21, rMin: 40, rMax: 72, e: 0.62 };
const w1 = OVP.scatter(OVP.world({ gravity: [0, -520, 0], ground: -180 }), 8, scatterOpts);
const w2 = OVP.scatter(OVP.world({ gravity: [0, -520, 0], ground: -180 }), 8, scatterOpts);
const h1 = w1.poseAt(1.0).map(b => b.p.join(",")).join("|");
const h2 = w2.poseAt(1.0).map(b => b.p.join(",")).join("|");
ok(h1 === h2 && h1.length > 0, "① 确定性：同 seed 两次积分逐位一致");
// 绳索
const wr = OVP.world({ gravity: [0, -520, 0] });
const rp = wr.rope([0, 300, 0], 8, { seg: 30 });
const ropePose = wr.poseAt(1.2);
let rl = 0;
for (let i = 1; i < rp.idx.length; i++) {
  const a = ropePose[rp.idx[i - 1]].p, b = ropePose[rp.idx[i]].p;
  rl += Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
}
const rErr = Math.abs(rl - rp.seg * 7) / (rp.seg * 7);
ok(rErr < 0.05, `② 绳索抗拉伸：1.2s 长度误差 ${(rErr * 100).toFixed(1)}% < 5%`);
ok(ropePose[rp.idx[0]].p[1] === 300, "② 绳索首节锚定不动");
// 软体
const ws = OVP.world({ gravity: [0, -520, 0] });
const sf = ws.soft(0, 200, 0, { n: 20, radius: 60 });
const sPose = ws.poseAt(0.8);
let cx = 0, cy = 0, cz = 0;
for (const i of sf.idx) { cx += sPose[i].p[0]; cy += sPose[i].p[1]; cz += sPose[i].p[2]; }
cx /= sf.idx.length; cy /= sf.idx.length; cz /= sf.idx.length;
let sr = 0;
for (const i of sf.idx) sr = Math.max(sr, Math.hypot(sPose[i].p[0] - cx, sPose[i].p[1] - cy, sPose[i].p[2] - cz));
ok(sr > 20 && sr < 100, `③ 软体形态保持：最大半径 ${sr.toFixed(1)}（未溃散/未爆炸）`);
// 爆炸
const we = OVP.scatter(OVP.world({ gravity: [0, 0, 0] }), 6, { radius: 100, height: 0, seed: 3 });
we.explode({ at: 0.05, x: 0, y: 0, z: 0, radius: 300, power: 600 });
const eb = we.poseAt(0.0).map(b => Math.hypot(b.p[0], b.p[1], b.p[2]));
const ea = we.poseAt(0.5).map(b => Math.hypot(b.p[0], b.p[1], b.p[2]));
const moved = ea.filter((v, i) => v > eb[i] + 5).length;
ok(moved >= 5, `④ 爆炸冲量：${moved}/6 粒子被推开`);
// 爆炸幂等（poseAt 反复调用结果一致，验证 fired 不进闭包状态）
ok(JSON.stringify(we.poseAt(0.5)) === JSON.stringify(we.poseAt(0.5)), "④ 爆炸后 poseAt 幂等（fired 本地化）");
// 磁场（全部靠近 + 平均距离显著减小）
const wm = OVP.scatter(OVP.world({ gravity: [0, 0, 0] }), 6, { radius: 300, height: 0, seed: 3 });
wm.attract({ x: 0, y: 0, z: 0, strength: 6000, radius: 500, t0: 0, t1: 5 });
const mb = wm.poseAt(0.0).map(b => Math.hypot(b.p[0], b.p[1], b.p[2]));
const ma = wm.poseAt(1.0).map(b => Math.hypot(b.p[0], b.p[1], b.p[2]));
const allCloser = ma.every((v, i) => v <= mb[i] + 1);
const avgDrop = (1 - ma.reduce((s, v) => s + v, 0) / mb.reduce((s, v) => s + v, 0)) * 100;
ok(allCloser && avgDrop > 20, `⑤ 磁场吸引：${ma.filter((v, i) => v < mb[i] - 20).length}/6 显著靠近，平均距离 -${avgDrop.toFixed(0)}%`);
// ⑥ 布料：锚定行不动 + 受风摆动 + 结构弹簧不崩
const wcl = OVP.world({ gravity: [0, -520, 0] });
const cl = wcl.cloth(0, 300, 0, { nx: 8, ny: 8, seg: 26, wind: [600, 0, 0] });
const clPose = wcl.poseAt(1.2);
let pinOk = true, clMove = 0, clStretch = 0;
for (let j = 0; j < cl.ny; j++) {
  for (let i = 0; i < cl.nx; i++) {
    const p = clPose[cl.idx[j * cl.nx + i]].p;
    if (j === 0 && i % 2 === 0 && Math.abs(p[1] - 300) > 0.01) pinOk = false;
    if (j > 0) clMove += Math.abs(p[0] - (i - (cl.nx - 1) / 2) * 26);
    if (i + 1 < cl.nx) {
      const q = clPose[cl.idx[j * cl.nx + i + 1]].p;
      clStretch = Math.max(clStretch, Math.hypot(q[0] - p[0], q[1] - p[1], q[2] - p[2]) - 26);
    }
  }
}
ok(pinOk && clMove > 5, `⑥ 布料：锚定行不动 + 受风位移 ${clMove.toFixed(0)}`);
ok(clStretch < 15, `⑥ 布料结构弹簧不崩（最大拉伸 ${clStretch.toFixed(1)}）`);
// ⑦ 显式弹簧：悬挂收敛 + 确定性
const wsp = OVP.world({ gravity: [0, -520, 0] });
wsp.add({ p: [0, 300, 0], v: [0, 0, 0], r: 5, m: 1 });
wsp.spring({ a: 0, anchor: [0, 600, 0], rest: 200, k: 0.5, damp: 0.15 });
const spPose = wsp.poseAt(2.5);
const spD = Math.hypot(spPose[0].p[0], spPose[0].p[1] - 600, spPose[0].p[2]);
ok(spD < 400, `⑦ 弹簧悬挂收敛（距锚点 ${spD.toFixed(0)}）`);
ok(JSON.stringify(wsp.poseAt(2.5)) === JSON.stringify(spPose), "⑦ 弹簧确定性");
// ⑧ 摆链：摆动相位不同 + 节长守恒
const wpd = OVP.world({});
const pd = wpd.pendulum([0, 400, 0], 6, { seg: 25, theta: Math.PI * 0.4 });
const pdA = wpd.poseAt(0.8)[pd.idx[5]].p, pdB = wpd.poseAt(2.5)[pd.idx[5]].p;
ok(Math.abs(pdA[0] - pdB[0]) > 3, `⑧ 摆链摆动（x(0.8)=${pdA[0].toFixed(1)} vs x(2.5)=${pdB[0].toFixed(1)}）`);
const pdS = wpd.poseAt(2.5);
const pdLen = Math.hypot(pdS[pd.idx[5]].p[0] - pdS[pd.idx[4]].p[0],
                         pdS[pd.idx[5]].p[1] - pdS[pd.idx[4]].p[1],
                         pdS[pd.idx[5]].p[2] - pdS[pd.idx[4]].p[2]);
ok(Math.abs(pdLen - 25) < 8, `⑧ 摆链节长守恒（${pdLen.toFixed(2)}）`);
// ⑨ 涡流：切向旋转 + 径向吸引
const wvx = OVP.world({ gravity: [0, 0, 0], drag: 0 });
wvx.add({ p: [200, 0, 0], v: [0, 0, 0], r: 1 });
wvx.vortex({ x: 0, y: 0, z: 0, axis: [0, 1, 0], radius: 500, strength: 200, pull: 0.5 });
const vxPose = wvx.poseAt(1.5);
const vxR = Math.hypot(vxPose[0].p[0], vxPose[0].p[2]);
ok(Math.abs(vxPose[0].v[2]) > 1, `⑨ 涡流切向旋转（vz=${vxPose[0].v[2].toFixed(1)}）`);
ok(vxR < 195, `⑨ 涡流径向吸引（r=${vxR.toFixed(1)}）`);
// ⑩ 湍流：确定性伪噪声加速
const wtb = OVP.world({ gravity: [0, 0, 0] });
wtb.add({ p: [0, 100, 0], v: [0, 0, 0], r: 1 });
wtb.turbulence({ strength: 1500, scale: 0.02, speed: 1.5 });
const tbPose = wtb.poseAt(1.0);
const tbSp = Math.hypot(tbPose[0].v[0], tbPose[0].v[1], tbPose[0].v[2]);
ok(tbSp > 5, `⑩ 湍流扰动加速（speed=${tbSp.toFixed(1)}）`);

console.log(`\n===== Node 侧回归：${pass} 通过 / ${fail} 失败 =====`);
process.exit(fail ? 1 : 0);
