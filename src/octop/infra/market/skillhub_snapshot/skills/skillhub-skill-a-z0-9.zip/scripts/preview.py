#!/usr/bin/env python3
"""
opus-video / preview.py
实时预览服务器：浏览器打开即可看到 scene.html 的动画，保存文件自动刷新。

用法:
  python3 preview.py                        # 服务当前目录，默认找 scene.html
  python3 preview.py flagship.html --port 8080
  python3 preview.py . --port 8080          # 目录模式，自动列出所有 html

特点:
  - 零依赖（标准库 http.server + websockets 可选）
  - 通过 HTTP 提供文件，避免 file:// 的跨文件限制（motion-3d.js 能正常加载）
  - 注入热重载脚本：轮询 .mtime，变化即 location.reload()
  - 顶部浮层显示 播放/暂停/逐帧/时间码，按空格暂停、←→ 单帧步进
"""
import argparse
import http.server
import os
import socketserver
import sys
import threading
import time
import urllib.parse

INJECT = r"""
<script>
(function(){
  if (window.__ovPreview) return; window.__ovPreview = true;
  // ---------- 热重载：轮询当前页 mtime ----------
  const SELF = location.pathname;
  let last = null;
  async function poll(){
    try{
      const r = await fetch('/__mtime?f=' + encodeURIComponent(SELF), {cache:'no-store'});
      const j = await r.json();
      if (last !== null && j.mtime !== last) { location.reload(); return; }
      last = j.mtime;
    }catch(e){}
    setTimeout(poll, 700);
  }
  poll();
  // ---------- 浮层控制 ----------
  const bar = document.createElement('div');
  bar.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:99999;font:12px ui-monospace,monospace;'
    + 'color:#cfe6ff;background:rgba(8,12,18,.82);border:1px solid rgba(120,180,240,.35);'
    + 'border-radius:8px;padding:8px 10px;display:flex;gap:10px;align-items:center;backdrop-filter:blur(6px);'
    + 'user-select:none;cursor:default';
  bar.innerHTML = '<span style="opacity:.55">PREVIEW</span>'
    + '<button id="ovPlay" style="all:unset;cursor:pointer;color:#5be2a1">暂停</button>'
    + '<button id="ovStep" style="all:unset;cursor:pointer;color:#9fc7ff">+1帧</button>'
    + '<span id="ovTime">0.000s</span><span id="ovInfo" style="opacity:.5"></span>';
  document.addEventListener('DOMContentLoaded', () => document.body.appendChild(bar));
  if (document.readyState !== 'loading') document.body.appendChild(bar);

  const D = () => window.DURATION || 6;
  const F = () => window.FPS || 30;
  let playing = true, frozen = 0, t0 = performance.now();

  // 接管预览循环：覆盖 rAF 实现，保证暂停/步进可控
  const realRAF = window.requestAnimationFrame.bind(window);
  window.requestAnimationFrame = function(cb){
    if (!playing) { return realRAF(() => {}); }
    return realRAF(cb);
  };
  // 用定时器同步时间码（不干预场景自身的绘制）
  setInterval(() => {
    const el = document.getElementById('ovTime');
    const info = document.getElementById('ovInfo');
    if (!el) return;
    const t = playing ? ((performance.now() - (t0 + frozen)) / 1000) % D() : ((frozen / 1000) % D());
    el.textContent = t.toFixed(3) + 's';
    if (info) info.textContent = `${D()}s · ${F()}fps · ${Math.round(D()*F())}帧`;
    // 同步到全局，方便控制台调试
    window.__ovTime = t;
  }, 100);

  document.addEventListener('click', (e) => {
    if (e.target.id === 'ovPlay') {
      playing = !playing;
      if (playing) { t0 = performance.now() - frozen; }
      else { frozen = performance.now() - t0; }
      e.target.textContent = playing ? '暂停' : '播放';
      e.target.style.color = playing ? '#5be2a1' : '#ffb454';
    }
    if (e.target.id === 'ovStep') {
      playing = false;
      document.getElementById('ovPlay').textContent = '播放';
      document.getElementById('ovPlay').style.color = '#ffb454';
      frozen = (frozen + 1000 / F()) % (D() * 1000);
      if (window.renderFrame) window.renderFrame(frozen / 1000 % D());
    }
  });
  document.addEventListener('keydown', (e) => {
    if (e.code === 'Space') { e.preventDefault(); document.getElementById('ovPlay').click(); }
    if (e.code === 'ArrowRight' || e.code === 'ArrowLeft') {
      e.preventDefault();
      playing = false;
      const d = (e.code === 'ArrowRight' ? 1 : -1) * (e.shiftKey ? 10 : 1) * 1000 / F();
      frozen = (frozen + d + D() * 1000) % (D() * 1000);
      if (window.renderFrame) window.renderFrame(frozen / 1000 % D());
      document.getElementById('ovPlay').textContent = '播放';
    }
  });
})();
</script>
"""


class Handler(http.server.SimpleHTTPRequestHandler):
    root = "."

    def log_message(self, fmt, *args):
        pass  # 静音

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        # 热重载探测接口
        if parsed.path == "/__mtime":
            q = urllib.parse.parse_qs(parsed.query)
            f = q.get("f", ["/"])[0].lstrip("/")
            p = os.path.join(self.root, f)
            try:
                m = os.path.getmtime(p)
            except OSError:
                m = 0
            body = ('{"mtime": %f}' % (m * 1000)).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return

        fpath = os.path.join(self.root, parsed.path.lstrip("/") or "index.html")
        if parsed.path in ("", "/"):
            fpath = os.path.join(self.root, self.server.default_file)
        if os.path.isfile(fpath) and fpath.endswith(".html"):
            with open(fpath, "rb") as fh:
                html = fh.read().decode("utf-8", "replace")
            # 注入到 </body> 前
            if "</body>" in html:
                html = html.replace("</body>", INJECT + "</body>", 1)
            else:
                html += INJECT
            body = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        return super().do_GET()


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("target", nargs="?", default=".", help="html 文件或目录")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--host", default="0.0.0.0")
    args = ap.parse_args()

    target = os.path.abspath(args.target)
    if os.path.isdir(target):
        Handler.root = target
        htmls = [f for f in sorted(os.listdir(target)) if f.endswith(".html")]
        default = "scene.html" if "scene.html" in htmls else (htmls[0] if htmls else "index.html")
    else:
        Handler.root = os.path.dirname(target)
        default = os.path.basename(target)

    srv = Server((args.host, args.port), Handler)
    srv.default_file = default
    url = f"http://127.0.0.1:{args.port}/{default}"
    print(f"预览已启动: {url}")
    print("  空格 播放/暂停 · ←→ 单帧 · Shift+←→ 十帧 · 保存文件自动刷新")
    print("  Ctrl+C 退出")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止")


if __name__ == "__main__":
    main()
