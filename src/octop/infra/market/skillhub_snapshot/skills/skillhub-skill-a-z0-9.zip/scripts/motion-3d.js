/* ============================================================
   opus-video / motion-3d.js  v2.0
   确定性视频渲染引擎：丝滑运动 / 3D 摄影机 / 运镜 / 排版 / 后期调色
   纯 Canvas 2D，零外部依赖，全部为 t 的纯函数
   全局挂载：window.OV
   ============================================================ */
(function (global) {
  "use strict";

  /* ============ 0. 数学基元 ============ */
  const PI = Math.PI, TAU = PI * 2;
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const smoothstep = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
  const seg = (t, a, b) => (b - a === 0 ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a)));
  const rgba = (hex, a) => {
    const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r},${g},${b},${a})`;
  };
  const mix = (c1, c2, t) => {
    const p = h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
    const [r1, g1, b1] = p(c1), [r2, g2, b2] = p(c2);
    const h = v => Math.round(v).toString(16).padStart(2, "0");
    return `#${h(lerp(r1, r2, t))}${h(lerp(g1, g2, t))}${h(lerp(b1, b2, t))}`;
  };

  /* ============ 1. 缓动 ============ */
  const E = {
    linear: x => x,
    inSine: x => 1 - Math.cos((x * PI) / 2),
    outSine: x => Math.sin((x * PI) / 2),
    inOutSine: x => -(Math.cos(PI * x) - 1) / 2,
    inQuad: x => x * x, outQuad: x => 1 - (1 - x) * (1 - x),
    inOutQuad: x => (x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2),
    inCubic: x => x * x * x, outCubic: x => 1 - Math.pow(1 - x, 3),
    inOutCubic: x => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2),
    inQuart: x => Math.pow(x, 4), outQuart: x => 1 - Math.pow(1 - x, 4),
    inOutQuart: x => (x < 0.5 ? 8 * Math.pow(x, 4) : 1 - Math.pow(-2 * x + 2, 4) / 2),
    inQuint: x => Math.pow(x, 5), outQuint: x => 1 - Math.pow(1 - x, 5),
    inOutQuint: x => (x < 0.5 ? 16 * Math.pow(x, 5) : 1 - Math.pow(-2 * x + 2, 5) / 2),
    inExpo: x => (x <= 0 ? 0 : Math.pow(2, 10 * x - 10)),
    outExpo: x => (x >= 1 ? 1 : 1 - Math.pow(2, -10 * x)),
    inOutExpo: x => (x <= 0 ? 0 : x >= 1 ? 1 : x < 0.5 ? Math.pow(2, 20 * x - 10) / 2 : (2 - Math.pow(2, -20 * x + 10)) / 2),
    inCirc: x => 1 - Math.sqrt(1 - x * x), outCirc: x => Math.sqrt(1 - Math.pow(x - 1, 2)),
    inOutCirc: x => (x < 0.5 ? (1 - Math.sqrt(1 - 4 * x * x)) / 2 : (Math.sqrt(1 - Math.pow(-2 * x + 2, 2)) + 1) / 2),
    outBack: (x, s = 1.70158) => 1 + (s + 1) * Math.pow(x - 1, 3) + s * Math.pow(x - 1, 2),
    inBack: (x, s = 1.70158) => (s + 1) * Math.pow(x, 3) - s * x * x,
    outElastic: x => (x === 0 ? 0 : x === 1 ? 1 : Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * TAU / 3) + 1),
    outBounce: x => {
      const n = 7.5625, d = 2.75;
      if (x < 1 / d) return n * x * x;
      if (x < 2 / d) return n * (x -= 1.5 / d) * x + 0.75;
      if (x < 2.5 / d) return n * (x -= 2.25 / d) * x + 0.9375;
      return n * (x -= 2.625 / d) * x + 0.984375;
    },
    // 长镜头专用：两端缓、中段匀
    cine: x => (x < 0.35 ? 0.5 * Math.pow(x / 0.35, 2) * 0.35 : x > 0.65 ? 1 - 0.5 * Math.pow((1 - x) / 0.35, 2) * 0.35 : 0.175 + (x - 0.35) / 0.3 * 0.65),
  };

  /* ============ 2. 确定性噪声 ============ */
  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function noise1(seed) {
    const rnd = mulberry32(seed), n = 512, arr = new Float32Array(n);
    for (let i = 0; i < n; i++) arr[i] = rnd() * 2 - 1;
    return function (x) {
      const i = Math.floor(x), f = x - i, u = f * f * (3 - 2 * f);
      const a = arr[((i % n) + n) % n], b = arr[(((i + 1) % n) + n) % n];
      return a + (b - a) * u;
    };
  }
  function noise2(seed) {
    const rnd = mulberry32(seed), n = 128, arr = new Float32Array(n * n);
    for (let i = 0; i < n * n; i++) arr[i] = rnd() * 2 - 1;
    const at = (x, y) => arr[(((y % n) + n) % n) * n + (((x % n) + n) % n)];
    return function (x, y) {
      const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi;
      const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
      const a = at(xi, yi), b = at(xi + 1, yi), c = at(xi, yi + 1), d = at(xi + 1, yi + 1);
      return lerp(lerp(a, b, u), lerp(c, d, u), v);
    };
  }
  function fbm2(seed) {
    const a = noise2(seed), b = noise2(seed + 7), c = noise2(seed + 19);
    return (x, y) => a(x, y) * 0.6 + b(x * 2.1, y * 2.1) * 0.28 + c(x * 4.3, y * 4.3) * 0.12;
  }

  /* ============ 3. 时间线 / 节拍 / 关键帧 ============ */
  const TIME = {
    at(t, a, b) { return { p: seg(t, a, b), active: t >= a && t < b, local: t - a, dur: b - a }; },
    beat(t, bpm = 120, offset = 0) {
      const bt = 60 / bpm, n = (t - offset) / bt;
      return { index: Math.floor(n), p: n - Math.floor(n), bt, local: (t - offset) % bt };
    },
    // 踩点脉冲：每个 beat 触发一次指数衰减
    pulse(t, at, bpm = 120, decay = 3) {
      const bt = 60 / bpm, d = t - at;
      if (d < 0) return 0;
      const k = Math.floor(d / bt), local = d - k * bt;
      return Math.exp(-local * decay * 6) * Math.max(0, 1 - k * 0.28);
    },
    // 关键帧插值（数值或数组）
    keyframes(t, kf, ease = E.inOutCubic) {
      if (t <= kf[0][0]) return kf[0][1];
      for (let i = 0; i < kf.length - 1; i++) {
        const t0 = kf[i][0], v0 = kf[i][1], t1 = kf[i + 1][0], v1 = kf[i + 1][1];
        if (t <= t1) {
          const p = ease(seg(t, t0, t1));
          return typeof v0 === "number" ? lerp(v0, v1, p) : v0.map((v, j) => lerp(v, v1[j], p));
        }
      }
      return kf[kf.length - 1][1];
    },
  };

  /* ============ 4. 元素运动 ============ */
  const MOVE = {
    entrance(t, at, dur = 0.7, opt = {}) {
      const p = seg(t, at, at + dur);
      const e = (opt.ease || E.outExpo)(p);
      const dx = (opt.dx || 0) * (1 - e), dy = (opt.dy === undefined ? 40 : opt.dy) * (1 - e);
      const s = lerp(opt.scaleFrom === undefined ? 0.94 : opt.scaleFrom, 1, e);
      return { p, e, dx, dy, scale: s, alpha: opt.fade === false ? 1 : smoothstep(0, 0.45, p) };
    },
    exit(t, at, dur = 0.5, opt = {}) {
      const p = seg(t, at, at + dur);
      const e = (opt.ease || E.inCubic)(p);
      return { p, e, dx: (opt.dx || 0) * e, dy: (opt.dy || -30) * e, scale: lerp(1, opt.scaleTo || 0.96, e), alpha: 1 - smoothstep(0, 0.85, p) };
    },
    countUp(t, at, dur, from, to, ease = E.outExpo) {
      const e = ease(seg(t, at, at + dur));
      return from + (to - from) * e;
    },
    drawOn(t, at, dur, ease = E.inOutCubic) { return ease(seg(t, at, at + dur)); },
    stagger(t, at, i, stag = 0.08, dur = 0.6, dy = 32) {
      const p = seg(t, at + i * stag, at + i * stag + dur);
      const e = E.outExpo(p);
      return { p, e, dy: dy * (1 - e), alpha: smoothstep(0, 0.4, p) };
    },
    float(t, amp = 6, freq = 0.5, phase = 0) { return Math.sin((t * freq + phase) * TAU) * amp; },
    spring(t, target, at, opt = {}) {
      const k = opt.k || 120, c = opt.c || 14, dt = 1 / 120;
      let x = opt.from || 0, v = opt.v0 || 0;
      const steps = Math.max(0, Math.floor((t - at) / dt));
      if (steps > 300) return target;
      for (let i = 0; i < steps; i++) { v += (k * (target - x) - c * v) * dt; x += v * dt; }
      return x;
    },
    alongPath(pts, p) {
      p = clamp(p) * (pts.length - 1);
      const i = Math.min(pts.length - 2, Math.floor(p)), f = p - i;
      return { x: lerp(pts[i][0], pts[i + 1][0], f), y: lerp(pts[i][1], pts[i + 1][1], f) };
    },
  };

  /* ============ 5. 运镜（2D 层） ============ */
  const SHOOT = {
    pushIn(t, a, b, from = 1.0, to = 1.08, ease = E.inOutSine) {
      return { zoom: lerp(from, to, ease(seg(t, a, b))) };
    },
    pullOut(t, a, b, from = 1.12, to = 1.0, ease = E.inOutSine) {
      return { zoom: lerp(from, to, ease(seg(t, a, b))) };
    },
    pan(t, a, b, dx = -60, dy = 0, ease = E.inOutCubic) {
      const p = ease(seg(t, a, b)); return { x: dx * p, y: dy * p };
    },
    whipPan(t, a, b, dist = 900, dir = -1) {
      // 一次性甩入：窗口外恒为 0；窗口内从 ±dist 甩到 0（dir=-1 从左侧甩入）
      if (t < a || t > b) return { x: 0, blur: 0 };
      const p = seg(t, a, b);
      const e = p < 0.5 ? E.inCubic(p * 2) * 0.5 : 0.5 + E.outCubic((p - 0.5) * 2) * 0.5;
      return { x: dir * dist * (1 - e), blur: Math.sin(p * PI) * 18 };
    },
    handheld(t, amp = 3, freq = 0.7, seed = 7) {
      const n1 = noise1(seed), n2 = noise1(seed + 31), n3 = noise1(seed + 77);
      return { x: n1(t * freq) * amp, y: n2(t * freq * 1.1) * amp * 0.8, rot: n3(t * freq * 0.6) * 0.0015 * amp };
    },
    impact(t, at, strength = 14, decay = 0.28) {
      const d = t - at;
      if (d < 0 || d > decay * 4) return { x: 0, y: 0, rot: 0 };
      const k = Math.exp(-d / decay) * strength;
      return { x: Math.sin(d * 90) * k, y: Math.cos(d * 110) * k * 0.6, rot: Math.sin(d * 70) * k * 0.0006 };
    },
    breathe(t, amount = 0.012, period = 6) { return { zoom: 1 + Math.sin(t / period * TAU) * amount }; },
    /* ---- 增强运镜库 ---- */
    dolly(t, a, b, dist = 260, ease = E.inOutCubic) {          // 轨道推拉（横向）
      const p = ease(seg(t, a, b)); return { x: dist * p };
    },
    crane(t, a, b, dist = 220, ease = E.inOutCubic) {          // 升降（纵向）
      const p = ease(seg(t, a, b)); return { y: dist * p };
    },
    arc(t, a, b, r = 300, ease = E.inOutSine) {                // 弧线绕行（x/y 圆运动）
      const p = ease(seg(t, a, b)) * PI * 0.5;
      return { x: Math.sin(p) * r, y: -Math.sin(p) * r * 0.35 + (1 - Math.cos(p)) * r * 0.35 };
    },
    orbitMove(t, a, b, r = 260, spins = 0.25, ease = E.inOutSine) { // 环绕（带缩放呼吸）
      const p = ease(seg(t, a, b));
      return { x: Math.sin(p * TAU * spins) * r, y: Math.cos(p * TAU * spins * 0.7) * r * 0.2 };
    },
    zoomPunch(t, at, strength = 1.35, decay = 0.4) {           // 冲击变焦（鼓点）
      const d = t - at;
      if (d < 0 || d > decay * 4) return { zoom: 1 };
      return { zoom: 1 + (strength - 1) * Math.exp(-d / decay) };
    },
    dutch(t, a, b, to = 0.09, ease = E.inOutSine) {            // 荷兰角（倾斜）
      const p = ease(seg(t, a, b)); return { rot: to * p };
    },
    roll(t, speed = 0.3) { return { rot: t * speed }; },       // 持续滚转
    vertigo(t, a, b, zoomTo = 1.25, ease = E.inOutCubic) {     // 眩晕推轨（推近+反向变焦）
      const p = ease(seg(t, a, b));
      return { x: 340 * p, zoom: lerp(1, zoomTo, p) };
    },
    tilt(t, a, b, dy = -160, ease = E.inOutCubic) {            // 俯仰摇
      const p = ease(seg(t, a, b)); return { y: dy * p };
    },
    /* 镜头表：shots=[{from,to,move,arg}]，按时间窗叠加运镜（多机位剪辑用） */
    /* ---- 翻倍运镜库 v2（18 → 36）---- */
    dollyZoom(t, a, b, zoomTo = 1.3, ease = E.inOutCubic) {   // 真·滑动变焦（推近同时视野收紧）
      const p = ease(seg(t, a, b));
      return { zoom: lerp(1, zoomTo, p), blur: Math.sin(p * PI) * 2 };
    },
    orbit360(t, a, b, r = 260, ease = E.inOutSine) {          // 360° 完整环绕
      const p = ease(seg(t, a, b)) * TAU;
      return { x: Math.sin(p) * r, y: -Math.cos(p) * r * 0.22 };
    },
    spiral(t, a, b, r = 220, spins = 1, ease = E.inOutSine) { // 螺旋升降环绕
      const p = ease(seg(t, a, b)) * TAU * spins;
      const rr = r * (1 - 0.3 * ease(seg(t, a, b)));
      return { x: Math.sin(p) * rr, y: -Math.cos(p * 0.5) * rr * 0.45 };
    },
    figure8(t, a, b, r = 240, ease = E.inOutSine) {           // 8 字轨迹
      const p = ease(seg(t, a, b)) * TAU;
      return { x: Math.sin(p) * r, y: Math.sin(p * 2) * r * 0.35 };
    },
    snorricam(t, seed = 5) {                                  // 主观视角（锁定主体、只抖环境）
      const n1 = noise1(seed), n2 = noise1(seed + 13);
      return { x: n1(t * 0.9) * 5, y: n2(t * 1.1) * 4, rot: n1(t * 0.5) * 0.002 };
    },
    steadicam(t, seed = 9, amp = 1.6) {                       // 斯坦尼康（超稳漂浮感）
      const n1 = noise1(seed), n2 = noise1(seed + 41);
      return { x: n1(t * 0.35) * amp, y: n2(t * 0.3) * amp * 0.7 };
    },
    truckLeft(t, a, b, dist = 300, ease = E.inOutCubic) {     // 横移（左）
      const p = ease(seg(t, a, b)); return { x: -dist * p };
    },
    crab(t, a, b, dist = 200, freq = 3, ease = E.inOutSine) { // 蟹行（横移+高频侧摆）
      const p = ease(seg(t, a, b));
      return { x: dist * p, y: Math.sin(t * freq) * 12, rot: Math.sin(t * freq * 0.5) * 0.01 };
    },
    pedestal(t, a, b, dist = 180, ease = E.inOutCubic) {      // 升降机（垂直）
      const p = ease(seg(t, a, b)); return { y: -dist * p };
    },
    follow(t, a, b, dist = 120, ease = E.inOutSine) {         // 跟随（缓移近主体）
      const p = ease(seg(t, a, b)); return { x: dist * p, zoom: 1 + p * 0.06 };
    },
    reveal(t, a, b, dist = 260, ease = E.outQuint) {          // 揭示（拉开让主体入画）
      const p = ease(seg(t, a, b)); return { x: dist * p, zoom: 1 + p * 0.1 };
    },
    whipTilt(t, a, b, dist = 500, dy = -80) {                 // 甩镜接俯仰
      if (t < a || t > b) return { x: 0, y: 0, blur: 0 };
      const p = seg(t, a, b);
      const e = p < 0.6 ? E.inCubic(p / 0.6) : 1;
      return { x: dist * (1 - e), y: dy * Math.max(0, (p - 0.6) / 0.4), blur: Math.sin(p * PI) * 14 };
    },
    shake(t, at, strength = 8, decay = 0.35) {                // 高频抖动（爆炸/撞击）
      const d = t - at;
      if (d < 0 || d > decay * 5) return { x: 0, y: 0, rot: 0 };
      const k = Math.exp(-d / decay) * strength;
      return { x: Math.sin(d * 130) * k, y: Math.cos(d * 97) * k * 0.7, rot: Math.sin(d * 61) * k * 0.0008 };
    },
    floatDrift(t, seed = 3, amp = 6) {                        // 漂浮漂移（缓慢无规则）
      const n1 = noise1(seed), n2 = noise1(seed + 17);
      return { x: n1(t * 0.22) * amp, y: n2(t * 0.18) * amp * 0.6, zoom: 1 + n2(t * 0.1) * 0.008 };
    },
    rampSpeed(t, a, b, from = 0.5, to = 2.5) {                // 速度斜坡（时间重映射，用于卡点加速）
      const p = seg(t, a, b);
      const sp = lerp(from, to, E.inOutCubic(p));
      return { x: (t - a) * sp * 30 - (t - a) * from * 30, zoom: 1 + p * 0.05 };
    },
    circleDolly(t, a, b, r = 300, ease = E.inOutQuint) {      // 绕行推轨（绕同时近）
      const p = ease(seg(t, a, b)) * PI * 0.5;
      return { x: Math.sin(p) * r, y: -Math.sin(p) * r * 0.2, zoom: 1 + p * 0.18 };
    },
    pushPullBreath(t, period = 4, k = 0.03) {                 // 呼吸推拉（更长周期）
      return { zoom: 1 + Math.sin(t / period * TAU) * k };
    },
    rollOrbit(t, a, b, r = 240, spins = 1.5) {                // 滚转环绕（边转边滚）
      const p = seg(t, a, b) * TAU * spins;
      return { x: Math.sin(p) * r, y: Math.cos(p * 0.8) * r * 0.25, rot: p * 0.12 };
    },
    tiltShift(t, a, b, blur = 6) {                            // 移轴微缩（往返横移）
      const p = E.inOutSine(seg(t, a, b)) * 2 - 1;
      return { x: p * 140, blur: 0 };
    },
    lazySusan(t, a, b, r = 260, ease = E.inOutSine) {         // 环绕横移（弧形扫过主体，过中点微推近）
      const ang = (ease(seg(t, a, b)) - 0.5) * 1.2;
      return { x: Math.sin(ang) * r, zoom: 1 + Math.abs(Math.sin(ang)) * 0.04 };
    },
    sequence(t, shots) {
      const out = { x: 0, y: 0, zoom: 1, rot: 0, blur: 0 };
      for (const s of shots) {
        const from = s.from || 0, to = s.to || Infinity;
        if (t < from || t >= to) continue;
        const move = SHOOT[s.move];
        if (!move) continue;
        const c = move(t, from, to, s.arg);
        out.x += c.x || 0; out.y += c.y || 0;
        out.zoom *= c.zoom === undefined ? 1 : c.zoom;
        out.rot += c.rot || 0;
        out.blur = Math.max(out.blur, c.blur || 0);
      }
      return out;
    },
    /* ===== 翻倍 36 运镜（第二轮 36→72） ===== */
    helixUp(t, a, b, r = 70, rise = 0.5) {           // 螺旋上升：边环绕边抬升
      const p = seg(t, a, b), ang = p * TAU * 1.5;
      return { x: Math.cos(ang) * r, y: -rise * p * (b - a), zoom: 1 + p * 0.06 };
    },
    doubleHelix(t, a, b, r = 60) {                   // 双螺旋：两条相错 180° 的弧线
      const p = seg(t, a, b), ang = p * TAU * 2 + (p > 0.5 ? Math.PI : 0);
      return { x: Math.cos(ang) * r * (0.5 + 0.5 * (1 - Math.abs(p - 0.5) * 2)), y: Math.sin(ang) * r * 0.5 };
    },
    lissajous(t, a, b, ax = 90, ay = 50, kx = 3, ky = 2) {  // 利萨如：正交异频谐振
      const p = seg(t, a, b) * TAU;
      return { x: Math.sin(kx * p) * ax, y: Math.sin(ky * p + Math.PI / 2) * ay };
    },
    roseCurve(t, a, b, r = 80, k = 3) {              // 玫瑰线：r = R·cos(kθ)
      const p = seg(t, a, b) * TAU;
      const rr = Math.cos(k * p) * r;
      return { x: Math.cos(p) * rr, y: Math.sin(p) * rr };
    },
    epitrochoid(t, a, b, R = 60, r = 18, d = 34) {   // 外摆线：滚圆外点轨迹
      const p = seg(t, a, b) * TAU, s = (R + r) / r;
      return { x: (R + r) * Math.cos(p) - d * Math.cos(s * p), y: (R + r) * Math.sin(p) - d * Math.sin(s * p) };
    },
    easeZoom(t, a, b, from = 1, to = 1.15, k = 3) {  // 指数缓变焦
      return { zoom: lerp(from, to, Math.pow(seg(t, a, b), k)) };
    },
    heartZoom(t, a, b, amp = 0.05, bpm = 120) {      // 心跳变焦
      const ph = (t - a) * bpm / 60, beat = Math.exp(-3 * (ph % 1)) * Math.max(0, Math.sin(ph * Math.PI * 2));
      return { zoom: 1 + amp * beat };
    },
    stairDolly(t, a, b, steps = 5, total = 0.2) {    // 阶梯推近：分段跳动推进
      const p = seg(t, a, b), i = Math.min(steps - 1, Math.floor(p * steps));
      return { zoom: 1 + total * (i + 1) / steps, blur: Math.max(0, 1 - ((p * steps) % 1) * 6) * 1.5 };
    },
    surgePull(t, a, b, amp = 0.06, freq = 2) {       // 涌退：正弦呼吸推拉
      return { zoom: 1 + amp * Math.sin(seg(t, a, b) * TAU * freq) };
    },
    dropDown(t, a, b, dist = 300, ease = E.inQuad) { // 坠降：加速下落
      return { y: dist * ease(seg(t, a, b)) };
    },
    riseUp(t, a, b, dist = 300, ease = E.outQuad) {  // 抬升：减速上升
      return { y: -dist * ease(seg(t, a, b)) };
    },
    peakDive(t, a, b, up = 120, down = 320) {        // 峰俯冲：先抬后俯冲
      const p = seg(t, a, b);
      return { y: p < 0.35 ? -up * E.outCubic(p / 0.35) : -up + (down + up) * E.inQuad((p - 0.35) / 0.65) };
    },
    swayLR(t, a, b, amp = 80, freq = 1.5) {          // 横摆
      return { x: Math.sin(seg(t, a, b) * TAU * freq) * amp };
    },
    nodUD(t, a, b, amp = 60, freq = 2) {             // 点头
      return { y: Math.sin(seg(t, a, b) * TAU * freq) * amp };
    },
    jitterHi(t, a, b, amp = 3, freq = 24) {          // 高频微振（紧张感）
      const p = seg(t, a, b);
      return { x: Math.sin(t * freq) * amp * p, y: Math.cos(t * freq * 1.3) * amp * p };
    },
    driftWind(t, a, b, amp = 100, freq = 0.6) {      // 风漂：缓慢不规则漂移
      const p = seg(t, a, b);
      return { x: (Math.sin(p * TAU * freq) + 0.4 * Math.sin(p * TAU * freq * 2.7)) * amp,
               y: Math.cos(p * TAU * freq * 0.8) * amp * 0.3 };
    },
    rampDown(t, a, b, dist = 500) {                  // 减速推进（越推越慢）
      return { x: -dist * (1 - Math.pow(1 - seg(t, a, b), 2)) };
    },
    pulseAccel(t, a, b, dist = 400, kicks = 3) {     // 脉冲加速：分段冲刺
      const p = seg(t, a, b), ph = (p * kicks) % 1;
      const i = Math.floor(p * kicks);
      return { x: -dist * (i / kicks + Math.pow(ph, 2.2) / kicks) };
    },
    stutterStep(t, a, b, steps = 6, dist = 200) {    // 顿步骤：逐格跳进
      const p = seg(t, a, b), i = Math.min(steps, Math.floor(p * steps));
      return { x: -dist * i / steps, blur: Math.max(0, 1 - ((p * steps) % 1) * 8) * 2 };
    },
    slowMoZone(t, a, b, zone = [0.4, 0.6], dist = 300) {  // 慢区：中段减速
      const p = seg(t, a, b);
      const e = p < zone[0] ? p / zone[0] * 0.2 : p > zone[1] ? 0.2 + (p - zone[1]) / (1 - zone[1]) * 0.8 : 0.2;
      return { x: -dist * e };
    },
    cornerPeek(t, a, b, dist = 500) {                // 角窥：从角部滑入
      const p = E.outCubic(seg(t, a, b));
      return { x: (1 - p) * dist, y: (1 - p) * dist * 0.6, zoom: 1 + p * 0.05 };
    },
    blindOpen(t, a, b, bands = 6, spread = 60) {     // 百叶开：分段错位展开
      const p = seg(t, a, b);
      return { y: (1 - p) * spread * Math.sin(p * bands * Math.PI) };
    },
    irisOpen(t, a, b, amp = 0.1) {                   // 光圈开：变焦式张开
      const p = seg(t, a, b);
      return { zoom: 1 + amp * Math.sin(p * Math.PI), blur: (1 - Math.sin(p * Math.PI)) * 2 };
    },
    doorSwing(t, a, b, amp = 0.03) {                 // 门摆：透视摆入
      const p = seg(t, a, b);
      return { rot: (1 - p) * amp * Math.sin(p * Math.PI * 2), zoom: 1 + 0.04 * p };
    },
    curtainUp(t, a, b, dist = 400) {                 // 幕升：自下掀起
      const p = E.outQuint(seg(t, a, b));
      return { y: (1 - p) * dist };
    },
    splitZoom(t, a, b, amp = 0.08) {                 // 分裂变焦：先分后合
      const p = seg(t, a, b);
      return { zoom: 1 + amp * Math.sin(p * Math.PI), x: Math.sin(p * TAU) * 30 };
    },
    mirrorPan(t, a, b, dist = 300) {                 // 镜像平移：去而复返
      const p = seg(t, a, b);
      return { x: -dist * Math.sin(p * Math.PI) };
    },
    pendulumSwing(t, a, b, amp = 0.05, freq = 1.2) { // 摆扫：单摆视角
      const p = seg(t, a, b);
      return { rot: amp * Math.sin(p * TAU * freq) * (1 - p * 0.3), x: Math.sin(p * TAU * freq) * 20 };
    },
    waveRide(t, a, b, amp = 40, freq = 2.5) {        // 浪驰：起伏骑行
      const p = seg(t, a, b);
      return { y: Math.sin(p * TAU * freq) * amp, zoom: 1 + 0.03 * Math.sin(p * TAU * freq + 1) };
    },
    tornadoSpin(t, a, b, amp = 0.06, freq = 2) {     // 龙卷旋：边旋边收
      const p = seg(t, a, b);
      return { rot: p * TAU * freq * 0.12, zoom: 1 + amp * p, x: Math.cos(p * TAU * freq) * 40 * (1 - p) };
    },
    orbitEllipse(t, a, b, rx = 90, ry = 45, turns = 1) {  // 椭圆轨
      const p = seg(t, a, b) * TAU * turns;
      return { x: Math.cos(p) * rx, y: Math.sin(p) * ry };
    },
    dollyArcBack(t, a, b, dist = 400, arc = 150) {   // 弧退：边退边弧移
      const p = seg(t, a, b);
      return { x: dist * p, y: -Math.sin(p * Math.PI) * arc, zoom: 1 - 0.06 * p };
    },
    craneBoom(t, a, b, up = 260, arm = 180) {        // 摇臂 boom：抬臂横移
      const p = seg(t, a, b);
      return { y: -up * E.inOutCubic(p), x: -arm * p, zoom: 1 + 0.05 * p };
    },
    flyThrough(t, a, b, dist = 600) {                // 穿行：冲刺 + 速度模糊
      const p = seg(t, a, b);
      return { x: -dist * Math.pow(p, 2), zoom: 1 + 0.25 * p, blur: p * 4 };
    },
    cornerPeel(t, a, b, dist = 420) {                // 角揭：斜向揭幕
      const p = E.outCubic(seg(t, a, b));
      return { x: (1 - p) * dist, y: -(1 - p) * dist * 0.5 };
    },
    barrelRoll(t, a, b, turns = 1, amp = 0.05) {     // 桶滚：整幅翻滚
      const p = seg(t, a, b);
      return { rot: p * TAU * turns * amp * 4, zoom: 1 + 0.02 * Math.sin(p * Math.PI) };
    },
    compose(t, shots) {
      const out = { x: 0, y: 0, zoom: 1, rot: 0, blur: 0 };
      for (const s of shots) {
        if (s.until !== undefined && t > s.until) continue;
        if (s.from !== undefined && t < s.from) continue;
        const c = s.fn(t);
        out.x += c.x || 0; out.y += c.y || 0;
        out.zoom *= c.zoom === undefined ? 1 : c.zoom;
        out.rot += c.rot || 0;
        out.blur = Math.max(out.blur, c.blur || 0);
      }
      return out;
    },
    apply(ctx, cam, w, h) {
      ctx.translate(w / 2 + (cam.x || 0), h / 2 + (cam.y || 0));
      ctx.rotate(cam.rot || 0);
      ctx.scale(cam.zoom || 1, cam.zoom || 1);
      ctx.translate(-w / 2, -h / 2);
    },
  };

  /* ============ 6. 3D 引擎 ============ */
  class Vec3 {
    constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; }
    add(v) { return new Vec3(this.x + v.x, this.y + v.y, this.z + v.z); }
    sub(v) { return new Vec3(this.x - v.x, this.y - v.y, this.z - v.z); }
    mul(s) { return new Vec3(this.x * s, this.y * s, this.z * s); }
    dot(v) { return this.x * v.x + this.y * v.y + this.z * v.z; }
    cross(v) { return this.crossE(v); }
    // 标准右手叉积 this × v
    crossE(v) { return new Vec3(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x); }
    len() { return Math.sqrt(this.dot(this)); }
    norm() { const l = this.len() || 1; return this.mul(1 / l); }
    lerp(v, t) { return new Vec3(lerp(this.x, v.x, t), lerp(this.y, v.y, t), lerp(this.z, v.z, t)); }
  }

  class Camera3D {
    constructor(opt = {}) {
      this.pos = new Vec3(opt.x || 0, opt.y || 0, opt.z || -900);
      this.target = new Vec3(0, 0, 0);
      this.fov = opt.fov || 900;
      this.cx = opt.cx || 0; this.cy = opt.cy || 0;
      this.roll = 0;
      this.near = opt.near || 20;
      this.fogNear = opt.fogNear || 1600;
      this.fogFar = opt.fogFar || 3600;
      this.fogColor = opt.fogColor || "#05070b";
    }
    lookAt(p) { this.target = new Vec3(p.x, p.y, p.z); return this; }
    setPos(x, y, z) { this.pos = new Vec3(x, y, z); return this; }
    basis() {
      const f = this.target.sub(this.pos).norm();
      // u = 世界up 对 f 正交化；r = u × f —— 使相机朝 -z 看时 r = +X（屏幕右）
      let u = new Vec3(0, 1, 0).sub(f.mul(new Vec3(0, 1, 0).dot(f)));
      if (u.len() < 1e-6) u = new Vec3(1, 0, 0);   // 视线竖直的退化情况
      u = u.norm();
      const r = u.cross(f).norm();
      return { f, r, u };
    }
    toCam(p) {
      const b = this.basis();
      const d = new Vec3(p.x - this.pos.x, p.y - this.pos.y, p.z - this.pos.z);
      return { x: d.dot(b.r), y: d.dot(b.u), z: d.dot(b.f) };
    }
    project(p) {
      const c = this.toCam(p), z = c.z;
      if (z < this.near) return null;
      const s = this.fov / z;
      let sx = c.x * s, sy = -c.y * s;
      if (this.roll) {
        const cr = Math.cos(this.roll), sr = Math.sin(this.roll);
        const nx = sx * cr - sy * sr, ny = sx * sr + sy * cr; sx = nx; sy = ny;
      }
      return {
        x: this.cx + sx, y: this.cy + sy, z, scale: s,
        fog: clamp((z - this.fogNear) / (this.fogFar - this.fogNear)),
        alpha: clamp(1 - (z - this.fov * 0.6) / (this.fov * 3), 0, 1),
      };
    }
    // 渲染面数组（画家算法 + 背面剔除 + 方向光 + 雾）
    render(ctx, faces, opt = {}) {
      const list = [];
      for (const f of faces) {
        const pr = []; let ok = true, zsum = 0;
        for (const v of f.verts) {
          const q = this.project(v);
          if (!q) { ok = false; break; }
          pr.push(q); zsum += q.z;
        }
        if (!ok) continue;
        // 背面剔除：用世界空间法线与"面中心→相机"的夹角判定，避免屏幕绕序符号问题
        if (!f.double && f.normal) {
          const cx = f.verts.reduce((s, v) => s + v.x, 0) / f.verts.length;
          const cy2 = f.verts.reduce((s, v) => s + v.y, 0) / f.verts.length;
          const cz = f.verts.reduce((s, v) => s + v.z, 0) / f.verts.length;
          const toCam = new Vec3(this.pos.x - cx, this.pos.y - cy2, this.pos.z - cz);
          if (f.normal.dot(toCam) <= 0) continue;
        }
        list.push({ f, pr, z: zsum / pr.length });
      }
      list.sort((a, b) => b.z - a.z);
      for (const it of list) this.paint(ctx, it.f, it.pr, it.z);
      return list.length;
    }
    paint(ctx, f, pr, z) {
      const fog = clamp((z - this.fogNear) / (this.fogFar - this.fogNear));
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(pr[0].x, pr[0].y);
      for (let i = 1; i < pr.length; i++) ctx.lineTo(pr[i].x, pr[i].y);
      ctx.closePath();
      if (f.stroke) {
        ctx.strokeStyle = rgba(f.stroke, (f.strokeAlpha === undefined ? 1 : f.strokeAlpha) * (1 - fog * 0.85));
        ctx.lineWidth = f.lineWidth || 1.2;
        ctx.stroke();
      }
      if (f.fill !== false) {
        let base = f.color || "#334455";
        if (f.lit !== false && f.normal) {
          const L = new Vec3(-0.4, 0.8, -0.45).norm();
          const lam = Math.max(0, f.normal.dot(L));
          const sh = 0.30 + lam * 0.70;
          base = `rgb(${Math.round(parseInt(base.slice(1, 3), 16) * sh)},${Math.round(parseInt(base.slice(3, 5), 16) * sh)},${Math.round(parseInt(base.slice(5, 7), 16) * sh)})`;
        }
        if (f.glow) { ctx.shadowColor = f.glow; ctx.shadowBlur = 16 * (f.glowK || 1); }
        ctx.globalAlpha = f.alpha === undefined ? 1 : f.alpha;
        ctx.fillStyle = base;
        ctx.fill();
      }
      ctx.restore();
      if (fog > 0.01) {
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(pr[0].x, pr[0].y);
        for (let i = 1; i < pr.length; i++) ctx.lineTo(pr[i].x, pr[i].y);
        ctx.closePath();
        ctx.globalAlpha = fog * 0.92;
        ctx.fillStyle = this.fogColor;
        ctx.fill();
        ctx.restore();
      }
    }
  }

  /* ---------- 3D 几何体 ---------- */
  const D3 = {
    V: (x, y, z) => new Vec3(x, y, z),
    cube(cx, cy, cz, size, color, opt = {}) {
      const h = size / 2;
      const v = [
        new Vec3(cx - h, cy - h, cz - h), new Vec3(cx + h, cy - h, cz - h),
        new Vec3(cx + h, cy + h, cz - h), new Vec3(cx - h, cy + h, cz - h),
        new Vec3(cx - h, cy - h, cz + h), new Vec3(cx + h, cy - h, cz + h),
        new Vec3(cx + h, cy + h, cz + h), new Vec3(cx - h, cy + h, cz + h),
      ];
      // 绕序统一为"从外部看逆时针"；法线由顶点顺序算出，保证与绕序一致
      const defs = [
        // 前(z-) 后(z+) 下(y-) 上(y+) 左(x-) 右(x+)，从外部看均为逆时针
        { idx: [3, 2, 1, 0] }, { idx: [4, 5, 6, 7] },
        { idx: [7, 6, 2, 3] }, { idx: [0, 1, 5, 4] },
        { idx: [4, 7, 3, 0] }, { idx: [1, 2, 6, 5] },
      ];
      // 每个面的"目标外法线"由几何位置决定（面心 - 体心），再按顶点绕序的叉积符号校正
      const center = new Vec3(cx, cy, cz);
      return defs.map(d => {
        const verts = d.idx.map(i => v[i]);
        const fc = verts.reduce((s, p) => s.add(p), new Vec3()).mul(1 / verts.length);
        const want = fc.sub(center).norm();                    // 该面朝外的方向
        const raw = verts[1].sub(verts[0]).crossE(verts[2].sub(verts[0])).norm();
        const n = raw.dot(want) < 0 ? raw.mul(-1) : raw;       // 与几何朝向对齐
        return {
          verts, normal: n, color,
          stroke: opt.stroke, lineWidth: opt.lineWidth, glow: opt.glow, alpha: opt.alpha, double: opt.double,
        };
      });
    },
    sphere(cx, cy, cz, r, color, opt = {}) {
      const segU = opt.segU || 12, segV = opt.segV || 8, faces = [];
      const pt = (u, v) => {
        const th = u * TAU, ph = v * PI;
        return new Vec3(cx + r * Math.sin(ph) * Math.cos(th), cy + r * Math.cos(ph), cz + r * Math.sin(ph) * Math.sin(th));
      };
      for (let i = 0; i < segU; i++) for (let j = 0; j < segV; j++) {
        const a = pt(i / segU, j / segV), b = pt((i + 1) / segU, j / segV);
        const c = pt((i + 1) / segU, (j + 1) / segV), d = pt(i / segU, (j + 1) / segV);
        const n = new Vec3((a.x + c.x) / 2 - cx, (a.y + c.y) / 2 - cy, (a.z + c.z) / 2 - cz).norm();
        faces.push({ verts: [a, b, c, d], normal: n, color, stroke: opt.stroke, alpha: opt.alpha });
      }
      return faces;
    },
    line(a, b, color, width = 2, alpha = 1) {
      const d = new Vec3(b.x - a.x, b.y - a.y, b.z - a.z).norm();
      let side = d.cross(new Vec3(0, 1, 0));
      if (side.len() < 1e-5) side = new Vec3(1, 0, 0);
      side = side.norm().mul(width / 2);
      return { verts: [a.add(side), b.add(side), b.sub(side), a.sub(side)], color, double: true, lit: false, alpha };
    },
    grid(cam, opt = {}) {
      const size = opt.size || 2400, step = opt.step || 200, y = opt.y || -260;
      const lines = [];
      for (let x = -size; x <= size; x += step) lines.push([new Vec3(x, y, -size), new Vec3(x, y, size)]);
      for (let z = -size; z <= size; z += step) lines.push([new Vec3(-size, y, z), new Vec3(size, y, z)]);
      return lines;
    },
    field(n, opt = {}) {
      const rnd = mulberry32(opt.seed || 42), out = [];
      for (let i = 0; i < n; i++) {
        out.push({
          x: (rnd() - 0.5) * (opt.spread || 2600),
          y: (rnd() - 0.5) * (opt.height || 1400),
          z: rnd() * (opt.depth || 3000) - 1200,
          r: 1 + rnd() * 2.5, ph: rnd() * TAU,
        });
      }
      return out;
    },
    orbit(t, a, b, opt = {}) {
      const ease = opt.ease || E.inOutCubic;
      const p = ease(seg(t, a, b));
      const ang = lerp(opt.a0 || -0.5, opt.a1 || 0.5, p);
      const rad = lerp(opt.r0 || 900, opt.r1 || 700, p);
      const h = lerp(opt.y0 || 120, opt.y1 || 260, p);
      return { x: Math.sin(ang) * rad + (opt.cx || 0), y: h, z: -Math.cos(ang) * rad + (opt.cz || 0) };
    },
    dolly(t, a, b, from, to, ease = E.inOutQuint) {
      const p = ease(seg(t, a, b));
      return { x: lerp(from.x, to.x, p), y: lerp(from.y, to.y, p), z: lerp(from.z, to.z, p) };
    },
    // 旋转一个面（绕 y 轴，可选 x 轴倾斜）
    spinFace(f, ang, tilt = 0) {
      const c = Math.cos(ang), s = Math.sin(ang), ct = Math.cos(tilt), st = Math.sin(tilt);
      const rot = v => {
        const x1 = v.x * c - v.z * s, z1 = v.x * s + v.z * c;
        return new Vec3(x1, v.y * ct - z1 * st, v.y * st + z1 * ct);
      };
      return {
        verts: f.verts.map(rot), normal: f.normal ? rot(f.normal) : undefined,
        color: f.color, stroke: f.stroke, lineWidth: f.lineWidth, glow: f.glow,
        alpha: f.alpha, double: f.double, lit: f.lit,
      };
    },
    dofScale(z, near = 900, far = 2200) {
      if (z < near) return Math.min(2.5, ((near - z) / near) * 2.5);
      if (z > far) return Math.min(2.5, ((z - far) / 600) * 1.5);
      return 0;
    },
  };

  /* ============ 7. 排版 ============ */
  const TYPE = {
    perChar(ctx, text, t, at, opt = {}) {
      const chars = [...text];
      const stag = opt.stagger || 0.035, dur = opt.dur || 0.6;
      const font = opt.font || "600 48px 'Noto Sans CJK SC', system-ui, sans-serif";
      ctx.save(); ctx.font = font;
      const widths = chars.map(c => ctx.measureText(c).width);
      const trk = opt.tracking || 0;
      const totalW = widths.reduce((a, b) => a + b, 0) + trk * (chars.length - 1);
      let cx = opt.align === "center" ? (opt.x || 0) - totalW / 2 : opt.align === "right" ? (opt.x || 0) - totalW : (opt.x || 0);
      chars.forEach((c, i) => {
        const p = seg(t, at + i * stag, at + i * stag + dur);
        if (p > 0) {
          const e = E.outExpo(p);
          ctx.globalAlpha = (opt.alpha === undefined ? 1 : opt.alpha) * smoothstep(0, 0.5, p);
          ctx.fillStyle = opt.color || "#ffffff";
          ctx.shadowColor = opt.glow || "transparent";
          ctx.shadowBlur = opt.glow ? 16 : 0;
          ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
          ctx.fillText(c, cx, (opt.y || 0) + (1 - e) * (opt.dy === undefined ? 36 : opt.dy));
        }
        cx += widths[i] + trk;
      });
      ctx.restore();
      return totalW;
    },
    wrap(ctx, text, maxW, font) {
      ctx.save(); ctx.font = font;
      const lines = []; let line = "";
      for (const ch of [...text]) {
        if (ctx.measureText(line + ch).width > maxW && line) { lines.push(line); line = ch; }
        else line += ch;
      }
      if (line) lines.push(line);
      ctx.restore();
      return lines;
    },
    cycle(t, words, at, each = 1.2, fade = 0.35) {
      if (t < at) return null;
      const idx = Math.min(words.length - 1, Math.floor((t - at) / each));
      const local = t - at - idx * each;
      const a = smoothstep(0, fade, local) * (idx === words.length - 1 ? 1 : 1 - smoothstep(each - fade, each, local));
      return { text: words[idx], alpha: a, index: idx };
    },
    stat(t, at, dur, to, opt = {}) {
      const v = MOVE.countUp(t, at, dur, opt.from || 0, to, opt.ease || E.outExpo);
      const dec = opt.decimals || 0;
      const s = dec ? v.toFixed(dec) : Math.round(v).toLocaleString("en-US");
      return { value: v, text: (opt.prefix || "") + s + (opt.suffix || "") };
    },
    /* ---- 翻倍排版库 v2（TYPE 4 → 11）---- */
    lineMask(ctx, text, t, at, opt = {}) {                    // 行遮罩 reveal：文字从遮罩下揭出
      const p = E.outQuint(seg(t, at, at + (opt.dur || 0.7)));
      if (p <= 0) return 0;
      ctx.save();
      ctx.font = opt.font || "700 64px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = opt.align || "left";
      ctx.fillStyle = opt.color || "#ffffff";
      const x = opt.x || 0, y = opt.y || 0;
      const m = ctx.measureText(text);
      const w = m.width, h = (opt.lineH || 76);
      // 遮罩矩形：高度按 p 展开（从中间向上下）或从左推右
      const mh = h * p;
      ctx.beginPath();
      ctx.rect(opt.align === "center" ? x - w / 2 : x, y - h * 0.72, w, mh);
      ctx.clip();
      ctx.fillText(text, x, y);
      ctx.restore();
      return p;
    },
    scramble(ctx, text, x, y, t, at, opt = {}) {              // 乱码解锁：逐位定格
      const chars = "▀▁▂▃▄▅▆▇█▉▊▋▌▍▎▏#$%&@*0123456789ABCDEF";
      const n = [...text].length;
      // cps = 每秒锁定字符数（原实现写成「每 cps 秒锁一字」，语义颠倒，16 字符要 224s——已修）
      const done = Math.max(0, Math.min(n, Math.floor((t - at) * (opt.cps || 14))));
      if (t < at) return 0;
      const rnd = mulberry32(1234);
      let out = "";
      for (let i = 0; i < n; i++) {
        if (i < done) out += [...text][i];
        else {
          // 每 1/12 秒重摇一次（确定性）
          const f = Math.floor(t * 12) + i * 7;
          const r = mulberry32(f * 2654435761 >>> 0);
          out += chars[Math.floor(r() * chars.length)];
        }
      }
      ctx.save();
      ctx.font = opt.font || "700 52px ui-monospace, monospace";
      ctx.fillStyle = opt.color || "#5be2a1";
      ctx.textAlign = opt.align || "left";
      ctx.shadowColor = opt.glow || "rgba(91,226,161,0.6)";
      ctx.shadowBlur = opt.shadowBlur || 12;
      ctx.fillText(out, x, y);
      ctx.restore();
      return done;
    },
    splitReveal(ctx, text, x, y, t, at, opt = {}) {           // 分裂两半向两侧滑入
      const p = E.outQuint(seg(t, at, at + (opt.dur || 0.6)));
      if (p <= 0) return 0;
      ctx.save();
      ctx.font = opt.font || "900 96px 'Noto Sans CJK SC', system-ui";
      const half = Math.ceil([...text].length / 2);
      const left = [...text].slice(0, half).join(""), right = [...text].slice(half).join("");
      ctx.fillStyle = opt.color || "#ffffff";
      const off = (1 - p) * (opt.dist || 160);
      ctx.save();
      ctx.beginPath(); ctx.rect(x - 600, y - 140, 600 - 2, 280); ctx.clip();
      ctx.textAlign = "right";                    // 右锚：off=0 时左半右缘正好落在 x
      ctx.fillText(left, x - off, y);
      ctx.restore();
      ctx.save();
      ctx.beginPath(); ctx.rect(x + 2, y - 140, 600 - 2, 280); ctx.clip();
      ctx.textAlign = "left";                     // 左锚：与左半无缝拼接（原实现两半都 center 会重叠）
      ctx.fillText(right, x + off, y);
      ctx.restore();
      ctx.restore();
      return p;
    },
    waveText(ctx, text, x, y, t, opt = {}) {                  // 波浪起伏文字（常驻动效）
      const chars = [...text];
      ctx.save();
      ctx.font = opt.font || "800 60px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = opt.align || "left";
      ctx.fillStyle = opt.color || "#ffffff";
      const cw = ctx.measureText("测").width || 60;
      chars.forEach((ch, i) => {
        const dy = Math.sin(t * (opt.speed || 3) - i * (opt.phase || 0.5)) * (opt.amp || 8);
        ctx.fillText(ch, x + i * cw * (opt.tracking || 1.02), y + dy);
      });
      ctx.restore();
      return chars.length;
    },
    stamp(ctx, text, x, y, t, at, opt = {}) {                 // 印章砸入：缩放回弹+旋转
      const d = t - at;
      if (d < 0) return 0;
      const p = Math.min(1, d / (opt.dur || 0.4));
      const s = E.outBack(p) * (opt.scale || 1);
      const rot = (1 - E.outQuint(p)) * (opt.rot || -0.12);
      ctx.save();
      ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
      ctx.font = opt.font || "900 88px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = "center";
      ctx.fillStyle = opt.color || "#c8452d";
      ctx.fillText(text, 0, 0);
      ctx.restore();
      return p;
    },
    stackText(ctx, texts, x, y, t, at, opt = {}) {            // 堆叠轮播：上下翻页
      const each = opt.each || 1.2, fade = opt.fade || 0.35;
      const idx = Math.min(texts.length - 1, Math.floor((t - at) / each));
      if (t < at || idx < 0) return null;
      const local = t - at - idx * each;
      const a = smoothstep(0, fade, local) * (idx === texts.length - 1 ? 1 : 1 - smoothstep(each - fade, each, local));
      ctx.save();
      ctx.font = opt.font || "700 56px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = opt.align || "left";
      ctx.globalAlpha = a;
      ctx.fillStyle = opt.color || "#ffffff";
      const dy = (1 - smoothstep(0, fade, local)) * (opt.dy || 40);
      ctx.fillText(texts[idx], x, y + dy);
      ctx.restore();
      return { text: texts[idx], alpha: a, index: idx };
    },
    countdown(ctx, x, y, t, from, at, opt = {}) {             // 倒计时 3-2-1
      const d = t - at;
      if (d < 0 || d > from + 1.2) return null;
      const n = Math.max(0, from - Math.floor(d));
      const local = d - (from - n);
      const p = Math.min(1, local / 0.9);
      ctx.save();
      ctx.translate(x, y);
      const s = E.outBack(p) * 1.0;
      ctx.scale(s, s);
      ctx.globalAlpha = 1 - p * 0.85;
      ctx.font = opt.font || "900 200px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = "center";
      ctx.fillStyle = opt.color || "#ffffff";
      ctx.shadowColor = opt.glow || "rgba(255,255,255,0.5)";
      ctx.shadowBlur = 30;
      ctx.fillText(String(n), 0, 60);
      ctx.restore();
      return n;
    },
    /* ===== 翻倍 11 文字动画（11→22） ===== */
    typeOn(ctx, text, t, at = 0, opt = {}) {          // 逐字机打 + 闪烁光标
      const cps = opt.cps || 12, p = seg(t, at, text.length / cps + 0.4);
      const n = Math.floor(p * text.length);
      const shown = text.slice(0, n);
      ctx.save();
      ctx.font = opt.font || "600 48px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = opt.align || "left"; ctx.fillStyle = opt.color || "#ffffff";
      ctx.shadowColor = opt.glow || "transparent"; ctx.shadowBlur = opt.glow ? 14 : 0;
      ctx.fillText(shown, opt.x || 0, opt.y || 0);
      if (n < text.length && Math.sin(t * 10) > -0.3) {  // 光标
        const w = ctx.measureText(shown).width;
        ctx.fillRect((opt.x || 0) + (opt.align === "center" ? w / 2 : 0), (opt.y || 0) - 40, 3, 44);
      }
      ctx.restore();
      return n;
    },
    blurIn(ctx, text, t, at = 0, opt = {}) {          // 模糊聚焦入
      const chars = [...text], stag = opt.stagger || 0.05;
      ctx.save();
      ctx.font = opt.font || "700 64px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      let cx = opt.x || 0;
      chars.forEach((c, i) => {
        const p = seg(t, at + i * stag, at + i * stag + 0.7);
        if (p > 0) {
          const e = E.outCubic(p);
          ctx.filter = `blur(${(1 - e) * 8}px)`;
          ctx.globalAlpha = e;
          ctx.fillStyle = opt.color || "#ffffff";
          ctx.fillText(c, cx, opt.y || 0);
          ctx.filter = "none";
        }
        cx += ctx.measureText(c).width;
      });
      ctx.restore();
    },
    flipChar(ctx, text, t, at = 0, opt = {}) {        // 翻牌：scaleX 翻转逐字
      const chars = [...text], stag = opt.stagger || 0.06;
      ctx.save();
      ctx.font = opt.font || "800 72px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      let cx = opt.x || 0;
      chars.forEach((c, i) => {
        const p = seg(t, at + i * stag, at + i * stag + 0.6);
        const w = ctx.measureText(c).width;
        if (p > 0) {
          const e = E.outBack(p);
          ctx.save();
          ctx.translate(cx + w / 2, opt.y || 0);
          ctx.scale(Math.max(0.02, Math.abs(Math.cos(p * Math.PI)) * e), e);
          ctx.globalAlpha = Math.min(1, p * 3);
          ctx.fillStyle = opt.color || "#ffffff";
          ctx.fillText(c, -w / 2, 0);
          ctx.restore();
        }
        cx += w;
      });
      ctx.restore();
    },
    dropChar(ctx, text, t, at = 0, opt = {}) {        // 落字：重力弹跳逐字
      const chars = [...text], stag = opt.stagger || 0.05;
      ctx.save();
      ctx.font = opt.font || "800 72px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      let cx = opt.x || 0;
      chars.forEach((c, i) => {
        const d = t - (at + i * stag);
        const w = ctx.measureText(c).width;
        if (d > 0) {
          const bounce = d < 0.5 ? Math.abs(Math.sin(d * Math.PI * 2.2)) * 60 * Math.max(0, 1 - d * 2) : 0;
          const drop = Math.min(1, d / 0.25) * 0;
          ctx.globalAlpha = Math.min(1, d * 4);
          ctx.fillStyle = opt.color || "#ffffff";
          ctx.fillText(c, cx, (opt.y || 0) - bounce);
        }
        cx += w;
      });
      ctx.restore();
    },
    neonFlicker(ctx, text, t, at = 0, opt = {}) {     // 霓虹闪烁：多层辉光 + 随机闪烁
      const p = seg(t, at, 0.5);
      const flick = Math.sin(t * 31) > 0.93 ? 0.3 : 1;
      ctx.save();
      ctx.font = opt.font || "700 64px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = opt.align || "left";
      ctx.globalAlpha = p * flick;
      const col = opt.color || "#66e0ff";
      ctx.shadowColor = col; ctx.shadowBlur = 26;
      ctx.fillStyle = col; ctx.fillText(text, opt.x || 0, opt.y || 0);
      ctx.shadowBlur = 48;
      ctx.fillStyle = "rgba(255,255,255,0.85)"; ctx.fillText(text, opt.x || 0, opt.y || 0);
      ctx.restore();
    },
    glitchText(ctx, text, t, at = 0, opt = {}) {      // 故障文本：RGB 分离 + 跳动
      const p = seg(t, at, 0.4);
      const g = Math.sin(t * 47) > 0.7 ? 1 : 0;
      ctx.save();
      ctx.font = opt.font || "800 64px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = opt.align || "left";
      ctx.globalAlpha = p;
      const dx = g ? (Math.sin(t * 91) * 5) : 0;
      ctx.fillStyle = "rgba(255,0,60,0.8)"; ctx.fillText(text, (opt.x || 0) + dx, (opt.y || 0) + (g ? 2 : 0));
      ctx.fillStyle = "rgba(0,200,255,0.8)"; ctx.fillText(text, (opt.x || 0) - dx, (opt.y || 0) - (g ? 2 : 0));
      ctx.fillStyle = opt.color || "#ffffff"; ctx.fillText(text, opt.x || 0, opt.y || 0);
      ctx.restore();
    },
    wavePath(ctx, text, t, at = 0, opt = {}) {        // 波浪路径：逐字正弦起伏
      const chars = [...text], amp = opt.amp || 14, k = opt.k || 0.35;
      ctx.save();
      ctx.font = opt.font || "700 56px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      const p = seg(t, at, 0.6);
      let cx = opt.x || 0;
      chars.forEach((c, i) => {
        const w = ctx.measureText(c).width;
        const ph = i * k - t * 3;
        ctx.save();
        ctx.globalAlpha = p;
        ctx.translate(cx, (opt.y || 0) + Math.sin(ph) * amp * p);
        ctx.rotate(Math.cos(ph) * 0.08 * p);
        ctx.fillStyle = opt.color || "#ffffff";
        ctx.shadowColor = opt.glow || "transparent"; ctx.shadowBlur = opt.glow ? 12 : 0;
        ctx.fillText(c, 0, 0);
        ctx.restore();
        cx += w;
      });
      ctx.restore();
    },
    bubbleText(ctx, text, t, at = 0, opt = {}) {      // 弹跳字：过冲回弹
      const chars = [...text], stag = opt.stagger || 0.07;
      ctx.save();
      ctx.font = opt.font || "800 68px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      let cx = opt.x || 0;
      chars.forEach((c, i) => {
        const p = seg(t, at + i * stag, at + i * stag + 0.8);
        const w = ctx.measureText(c).width;
        if (p > 0) {
          const e = E.outElastic(p);
          ctx.save();
          ctx.translate(cx + w / 2, opt.y || 0);
          ctx.scale(0.6 + 0.4 * e, 0.6 + 0.4 * e);
          ctx.globalAlpha = Math.min(1, p * 2.5);
          ctx.fillStyle = opt.color || "#ffffff";
          ctx.fillText(c, -w / 2, 0);
          ctx.restore();
        }
        cx += w;
      });
      ctx.restore();
    },
    rotateIn(ctx, text, t, at = 0, opt = {}) {        // 旋入：绕纵轴旋开
      const p = seg(t, at, 0.8);
      const e = E.outCubic(p);
      ctx.save();
      ctx.font = opt.font || "800 72px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = opt.align || "left";
      ctx.translate(opt.x || 0, opt.y || 0);
      ctx.rotate((1 - e) * -0.5);
      ctx.scale(Math.max(0.05, e), 1);
      ctx.globalAlpha = Math.min(1, p * 1.6);
      ctx.fillStyle = opt.color || "#ffffff";
      ctx.shadowColor = opt.glow || "transparent"; ctx.shadowBlur = opt.glow ? 16 : 0;
      ctx.fillText(text, 0, 0);
      ctx.restore();
    },
    shatterText(ctx, text, t, at = 0, opt = {}) {     // 碎裂：文字炸开四散
      const p = seg(t, at, 1.0);
      const n = Math.min(26, Math.max(8, text.length * 2));
      const rnd = mulberry32(7);
      ctx.save();
      ctx.font = opt.font || "800 72px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = "center";
      const W0 = ctx.measureText(text).width;
      if (p < 0.35) {
        ctx.globalAlpha = 1 - p / 0.35 * 0.9;
        ctx.fillStyle = opt.color || "#ffffff";
        ctx.fillText(text, opt.x || 0, opt.y || 0);
      }
      const q = Math.max(0, (p - 0.3) / 0.7);
      if (q > 0) {
        for (let i = 0; i < n; i++) {
          const ang = rnd() * TAU, sp = 40 + rnd() * 160;
          const fx = (opt.x || 0) + Math.cos(ang) * sp * q;
          const fy = (opt.y || 0) + Math.sin(ang) * sp * q + 90 * q * q;
          const s = Math.max(0.05, 1 - q * 1.1);
          ctx.save();
          ctx.globalAlpha = (1 - q) * 0.9;
          ctx.translate(fx, fy);
          ctx.rotate(ang * q * 3);
          ctx.scale(s, s);
          ctx.fillStyle = opt.color || "#ffffff";
          ctx.fillText(rnd() > 0.5 ? text[i % text.length] : text[text.length - 1 - (i % text.length)], 0, 0);
          ctx.restore();
        }
      }
      ctx.restore();
    },
    matrixChar(ctx, text, t, at = 0, opt = {}) {      // 矩阵字符雨：逐字解码显现
      const chars = [...text], stag = opt.stagger || 0.09;
      const glyphs = "01ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ#%&@$*";
      ctx.save();
      ctx.font = opt.font || "600 52px ui-monospace, monospace";
      ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
      let cx = opt.x || 0;
      chars.forEach((c, i) => {
        const d = t - (at + i * stag);
        const w = ctx.measureText(c).width;
        if (d > 0) {
          const solved = Math.min(1, d / 0.5);
          const gl = glyphs[Math.floor(t * 30 + i * 7) % glyphs.length];
          ctx.globalAlpha = 0.4 + 0.6 * solved;
          ctx.fillStyle = solved >= 1 ? (opt.color || "#7dffb0") : "#2fae6a";
          ctx.shadowColor = "#39ff88"; ctx.shadowBlur = solved >= 1 ? 12 : 4;
          ctx.fillText(solved >= 1 ? c : gl, cx, opt.y || 0);
        }
        cx += w;
      });
      ctx.restore();
    },
  };

  /* ============ 8. 后期 ============ */
  const FX = {
    motionBlur(ctx, blur, drawScene, samples = 6) {
      if (!blur || blur < 0.5) return drawScene(0);
      ctx.save();
      for (let i = 0; i < samples; i++) {
        ctx.globalAlpha = i === 0 ? 1 : 0.2;
        drawScene((i / (samples - 1) - 0.5) * blur);
      }
      ctx.restore();
    },
    vignette(ctx, w, h, strength = 0.45) {
      const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.32, w / 2, h / 2, Math.max(w, h) * 0.78);
      g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, `rgba(0,0,0,${strength})`);
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    },
    grain(ctx, w, h, t, intensity = 0.05) {
      const rnd = mulberry32(Math.floor(t * 24) + 1);
      ctx.save(); ctx.globalAlpha = intensity;
      for (let i = 0; i < 800; i++) ctx.fillRect(rnd() * w, rnd() * h, 1.7, 1.7);
      ctx.restore();
    },
    glow(ctx, x, y, r, color) {
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, color); g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    },
    letterbox(ctx, w, h, ratio = 2.35) {
      const targetH = w / ratio, bar = Math.max(0, (h - targetH) / 2);
      ctx.fillStyle = "#000"; ctx.fillRect(0, 0, w, bar); ctx.fillRect(0, h - bar, w, bar);
      return bar;
    },
    scanlines(ctx, w, h, alpha = 0.04, gap = 3) {
      ctx.save(); ctx.globalAlpha = alpha; ctx.fillStyle = "#000";
      for (let y = 0; y < h; y += gap) ctx.fillRect(0, y, w, 1);
      ctx.restore();
    },
    scrim(ctx, w, h, dir = "bottom", strength = 0.7) {
      const g = dir === "bottom"
        ? ctx.createLinearGradient(0, h * 0.45, 0, h)
        : ctx.createLinearGradient(0, 0, w, 0);
      g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, `rgba(0,0,0,${strength})`);
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    },
    // 屏幕闪白（转场冲击）
    flash(ctx, w, h, k, color = "255,255,255") {
      if (k <= 0) return;
      ctx.save(); ctx.globalAlpha = clamp(k); ctx.fillStyle = `rgb(${color})`; ctx.fillRect(0, 0, w, h); ctx.restore();
    },
    // 调色：整体色调覆盖 + 对比（用两次叠加近似）
    grade(ctx, w, h, color, alpha, mode = "overlay") {
      ctx.save(); ctx.globalCompositeOperation = mode; ctx.globalAlpha = alpha;
      ctx.fillStyle = color; ctx.fillRect(0, 0, w, h); ctx.restore();
    },
    /* ---- 翻倍后期库 v2（10 → 20）---- */
    halation(ctx, w, h, k = 0.18) {                           // 光晕溢出：亮区扩散暖色辉光（电影镜头灵魂）
      const c = document.createElement("canvas"); c.width = w; c.height = h;
      const x = c.getContext("2d");
      x.drawImage(ctx.canvas, 0, 0);
      x.globalCompositeOperation = "source-over";
      // 阈值提取亮部：提亮 + 模糊近似（分段叠加）
      x.clearRect(0, 0, w, h);
      x.filter = "blur(9px) brightness(1.6)";
      x.drawImage(ctx.canvas, 0, 0);
      x.filter = "none";
      ctx.save(); ctx.globalCompositeOperation = "screen"; ctx.globalAlpha = k;
      ctx.drawImage(c, 0, 0); ctx.restore();
    },
    lightLeak(ctx, w, h, t, seed = 3, k = 0.22) {             // 漏光：缓慢游走的暖色光斑
      const n = noise1(seed);
      const cx = w * (0.5 + n(t * 0.07) * 0.45), cy = h * (0.3 + noise1(seed + 7)(t * 0.05) * 0.3);
      const r = Math.max(w, h) * (0.35 + 0.1 * Math.sin(t * 0.3));
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, `rgba(255,170,90,${k})`);
      g.addColorStop(0.5, `rgba(255,120,60,${k * 0.4})`);
      g.addColorStop(1, "rgba(255,100,50,0)");
      ctx.save(); ctx.globalCompositeOperation = "screen";
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); ctx.restore();
    },
    filmBurn(ctx, w, h, t, at, dur = 0.6) {                   // 胶片烧灼：过场白闪+边缘焦黄
      const d = t - at;
      if (d < 0 || d > dur) return;
      const p = d / dur;
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = Math.sin(p * PI) * 0.85;
      const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.1, w / 2, h / 2, Math.max(w, h) * 0.7);
      g.addColorStop(0, "rgba(255,240,200,0.9)");
      g.addColorStop(0.6, "rgba(255,160,60,0.35)");
      g.addColorStop(1, "rgba(120,40,10,0)");
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      ctx.restore();
    },
    chromatic(ctx, w, h, amount = 2.5) {                      // RGB 色差：边缘分离
      if (amount < 0.5) return;
      const c = document.createElement("canvas"); c.width = w; c.height = h;
      const x = c.getContext("2d");
      x.drawImage(ctx.canvas, 0, 0);
      ctx.save(); ctx.globalCompositeOperation = "screen";
      x.clearRect(0, 0, w, h);
      x.filter = "url(#none)";
      // 红蓝通道错位近似：整体微移叠加
      ctx.globalAlpha = 0.5;
      ctx.drawImage(c, -amount, 0);           // 暗含暖移
      ctx.drawImage(c, amount, 0);
      ctx.globalAlpha = 0.28;
      ctx.drawImage(c, 0, -amount * 0.5);
      ctx.restore();
    },
    glitch(ctx, w, h, t, seed = 7, k = 0.5) {                 // 故障艺术：横向切片错位
      const rnd = mulberry32((Math.floor(t * 12) * 2654435761 + seed) >>> 0);
      const c = document.createElement("canvas"); c.width = w; c.height = h;
      const x = c.getContext("2d");
      x.drawImage(ctx.canvas, 0, 0);
      const n = 4 + Math.floor(rnd() * 6);
      ctx.save();
      for (let i = 0; i < n; i++) {
        const sy = Math.floor(rnd() * h), sh = 4 + Math.floor(rnd() * 26);
        const dx = Math.floor((rnd() - 0.5) * 60 * k);
        ctx.drawImage(c, 0, sy, w, sh, dx, sy, w, sh);
      }
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = 0.12 * k;
      ctx.drawImage(c, 3, 0);
      ctx.fillStyle = "rgba(255,0,80,0.05)"; ctx.fillRect(0, 0, w, h);
      ctx.restore();
    },
    bokeh(ctx, w, h, t, seed = 5, n = 14) {                   // 焦外光斑：漂浮圆形散景
      const rnd = mulberry32(seed);
      ctx.save(); ctx.globalCompositeOperation = "screen";
      for (let i = 0; i < n; i++) {
        const bx = rnd() * w, by = rnd() * h;
        const r = 6 + rnd() * 26, ph = rnd() * TAU, sp = 6 + rnd() * 14;
        const x = bx + Math.sin(t * 0.3 + ph) * 20, y = (by - t * sp) % (h + 80);
        const yy = y < -40 ? y + h + 80 : y;
        const g = ctx.createRadialGradient(x, yy, 0, x, yy, r);
        const hue = 30 + rnd() * 40;
        g.addColorStop(0, `hsla(${hue},80%,75%,0.20)`);
        g.addColorStop(0.75, `hsla(${hue},80%,65%,0.10)`);
        g.addColorStop(1, `hsla(${hue},80%,60%,0)`);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, yy, r, 0, TAU); ctx.fill();
      }
      ctx.restore();
    },
    vhs(ctx, w, h, t, k = 0.5) {                              // 录像带：扫描带 + 底部抖动条
      ctx.save();
      ctx.globalAlpha = 0.10 * k;
      const bandY = (t * 90) % (h + 120) - 60;
      const g = ctx.createLinearGradient(0, bandY - 30, 0, bandY + 30);
      g.addColorStop(0, "rgba(255,255,255,0)");
      g.addColorStop(0.5, "rgba(255,255,255,0.5)");
      g.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = g; ctx.fillRect(0, bandY - 30, w, 60);
      ctx.globalAlpha = 0.16 * k;
      const jitter = Math.sin(t * 47) > 0.7 ? (Math.sin(t * 131) * 3) : 0;
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.fillRect(0, h * 0.82 + jitter, w, 3);
      ctx.fillStyle = "rgba(0,0,0,0.4)";
      ctx.fillRect(0, h * 0.86 + jitter, w, 8);
      ctx.restore();
    },
    dreamy(ctx, w, h, k = 0.35) {                             // 柔焦梦核：整体弥散+提亮
      const c = document.createElement("canvas"); c.width = w; c.height = h;
      const x = c.getContext("2d");
      x.filter = "blur(7px) brightness(1.18) saturate(1.15)";
      x.drawImage(ctx.canvas, 0, 0);
      ctx.save(); ctx.globalCompositeOperation = "screen"; ctx.globalAlpha = k;
      ctx.drawImage(c, 0, 0); ctx.restore();
    },
    duotone(ctx, w, h, dark = "#0a1a3a", light = "#ffd9a0", k = 0.55) { // 双色调：暗部/亮部重映射
      const c = document.createElement("canvas"); c.width = w; c.height = h;
      const x = c.getContext("2d");
      x.drawImage(ctx.canvas, 0, 0);
      x.globalCompositeOperation = "source-atop";
      const g = x.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, light); g.addColorStop(1, dark);
      x.fillStyle = g; x.fillRect(0, 0, w, h);
      ctx.save(); ctx.globalAlpha = k;
      ctx.drawImage(c, 0, 0); ctx.restore();
    },
    rgbPulse(ctx, w, h, t, at, k = 6) {                       // RGB 分离脉冲：踩点时通道炸开
      const d = t - at;
      if (d < 0 || d > 0.4) return;
      const amp = Math.exp(-d / 0.12) * k;
      const c = document.createElement("canvas"); c.width = w; c.height = h;
      const x = c.getContext("2d");
      x.drawImage(ctx.canvas, 0, 0);
      ctx.save(); ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = 0.6;
      ctx.drawImage(c, -amp, 0);
      ctx.drawImage(c, amp, 0);
      ctx.restore();
    },
    // 丁达尔光束（神光）：从亮点向外辐射的柔和光楔，lighter 叠加（体积光雾感）
    godRays(ctx, w, h, x, y, rays = 7, len = 1.4, alpha = 0.16, color = "255,240,210") {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      const rnd = mulberry32(99);
      const L = Math.max(w, h) * len;
      for (let i = 0; i < rays; i++) {
        const ang = (i / rays) * TAU + rnd() * 0.6;
        const spread = 0.05 + rnd() * 0.09;
        const g = ctx.createLinearGradient(x, y, x + Math.cos(ang) * L, y + Math.sin(ang) * L);
        g.addColorStop(0, `rgba(${color},${alpha})`);
        g.addColorStop(1, `rgba(${color},0)`);
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.arc(x, y, L, ang - spread, ang + spread);
        ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    },
    /* ===== 翻倍 20 后期（20→40） ===== */
    dof(ctx, w, h, amount = 2.5, edge = 0.22) {       // 景深：边缘带模糊（离屏半分辨率 + 条带裁剪）
      if (amount < 0.5) return;
      const off = document.createElement("canvas");
      off.width = Math.max(2, w >> 1); off.height = Math.max(2, h >> 1);
      const oc = off.getContext("2d");
      oc.drawImage(ctx.canvas, 0, 0, off.width, off.height);
      oc.filter = `blur(${amount}px)`;
      oc.drawImage(off, 0, 0);
      oc.filter = "none";
      const ew = Math.round(w * edge);
      ctx.save();
      ctx.drawImage(off, 0, 0, off.width, off.height, 0, 0, ew, h);            // 左
      ctx.drawImage(off, 0, 0, off.width, off.height, w - ew, 0, ew, h);       // 右
      const eh = Math.round(h * edge * 0.6);
      ctx.drawImage(off, 0, 0, off.width, off.height, 0, 0, w, eh);            // 上
      ctx.drawImage(off, 0, 0, off.width, off.height, 0, h - eh, w, eh);       // 下
      ctx.restore();
    },
    rain(ctx, w, h, t, n = 90, seed = 11) {            // 雨层：确定性雨丝
      const rnd = mulberry32(seed);
      ctx.save(); ctx.globalCompositeOperation = "screen";
      ctx.strokeStyle = "rgba(180,205,235,0.5)"; ctx.lineWidth = 1.2;
      for (let i = 0; i < n; i++) {
        const x0 = rnd() * w, y0 = rnd() * h, len = 14 + rnd() * 26, sp = 900 + rnd() * 500;
        const y = (y0 + t * sp) % (h + 60) - 30;
        ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x0 - 3, y + len); ctx.stroke();
      }
      ctx.restore();
    },
    snow(ctx, w, h, t, n = 70, seed = 23) {            // 雪层：飘落雪点
      const rnd = mulberry32(seed);
      ctx.save(); ctx.fillStyle = "rgba(255,255,255,0.75)";
      for (let i = 0; i < n; i++) {
        const x0 = rnd() * w, y0 = rnd() * h, r = 1 + rnd() * 2.6, sp = 40 + rnd() * 70, ph = rnd() * TAU;
        const y = (y0 + t * sp) % (h + 20) - 10;
        const x = x0 + Math.sin(t * 0.8 + ph) * 22;
        ctx.globalAlpha = 0.35 + rnd() * 0.5;
        ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      }
      ctx.restore();
    },
    dust(ctx, w, h, t, n = 40, seed = 31) {            // 浮尘：缓慢上浮光尘
      const rnd = mulberry32(seed);
      ctx.save(); ctx.globalCompositeOperation = "screen";
      for (let i = 0; i < n; i++) {
        const x0 = rnd() * w, y0 = rnd() * h, r = 0.8 + rnd() * 2.2, sp = 8 + rnd() * 22, ph = rnd() * TAU;
        const y = h - ((y0 + t * sp) % (h + 20));
        const x = x0 + Math.sin(t * 0.5 + ph) * 30;
        const g = ctx.createRadialGradient(x, y, 0, x, y, r * 3);
        g.addColorStop(0, "rgba(255,240,210,0.5)"); g.addColorStop(1, "rgba(255,240,210,0)");
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, y, r * 3, 0, TAU); ctx.fill();
      }
      ctx.restore();
    },
    fogLayer(ctx, w, h, t, seed = 41, alpha = 0.16) {  // 流动雾层：低频横向条带
      const rnd = mulberry32(seed);
      ctx.save(); ctx.globalCompositeOperation = "screen";
      for (let i = 0; i < 3; i++) {
        const y0 = h * (0.3 + i * 0.22) + Math.sin(t * 0.3 + i * 2) * 20;
        const g = ctx.createLinearGradient(0, y0 - 60, 0, y0 + 60);
        g.addColorStop(0, `rgba(200,210,220,0)`);
        g.addColorStop(0.5, `rgba(200,210,220,${alpha})`);
        g.addColorStop(1, `rgba(200,210,220,0)`);
        ctx.fillStyle = g;
        const x = ((t * (12 + i * 8) + rnd() * 400) % (w + 400)) - 200;
        ctx.fillRect(x - 300, y0 - 60, 600, 120);
      }
      ctx.restore();
    },
    lightShaft(ctx, w, h, x, y, ang = -0.5, n = 3, alpha = 0.10) {  // 光轴：斜向长光束
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < n; i++) {
        const L = Math.max(w, h) * 1.6;
        const a = ang + (i - (n - 1) / 2) * 0.10;
        const g = ctx.createLinearGradient(x, y, x + Math.cos(a) * L, y + Math.sin(a) * L);
        g.addColorStop(0, `rgba(255,244,214,${alpha})`);
        g.addColorStop(1, "rgba(255,244,214,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + Math.cos(a - 0.09) * L, y + Math.sin(a - 0.09) * L);
        ctx.lineTo(x + Math.cos(a + 0.09) * L, y + Math.sin(a + 0.09) * L);
        ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    },
    irisBlur(ctx, w, h, amount = 2, hole = 0.3) {      // 光圈模糊：中心清晰圆 + 边缘模糊
      if (amount < 0.5) return;
      const off = document.createElement("canvas");
      off.width = Math.max(2, w >> 1); off.height = Math.max(2, h >> 1);
      const oc = off.getContext("2d");
      oc.drawImage(ctx.canvas, 0, 0, off.width, off.height);
      oc.filter = `blur(${amount}px)`;
      oc.drawImage(off, 0, 0); oc.filter = "none";
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, w, h);
      ctx.arc(w / 2, h / 2, Math.min(w, h) * hole / 2, 0, TAU, true);
      ctx.clip("evenodd");
      ctx.drawImage(off, 0, 0, off.width, off.height, 0, 0, w, h);
      ctx.restore();
    },
    radialBlur(ctx, w, h, strength = 0.12, steps = 6) {  // 径向模糊：中心缩放冲刺
      if (strength < 0.01) return;
      const off = document.createElement("canvas");
      off.width = w; off.height = h;
      off.getContext("2d").drawImage(ctx.canvas, 0, 0);
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      for (let i = 1; i <= steps; i++) {
        const s = 1 + strength * i / steps;
        ctx.globalAlpha = 0.30 / i;
        ctx.drawImage(off, w / 2 - w * s / 2, h / 2 - h * s / 2, w * s, h * s);
      }
      ctx.restore();
    },
    tiltBlur(ctx, w, h, strength = 10, dir = 0) {      // 定向模糊：速度方向拖影
      if (strength < 1) return;
      const off = document.createElement("canvas");
      off.width = w; off.height = h;
      off.getContext("2d").drawImage(ctx.canvas, 0, 0);
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      for (let i = 1; i <= 5; i++) {
        const d = strength * i / 5;
        ctx.globalAlpha = 0.22 / i;
        ctx.drawImage(off, Math.cos(dir) * d, Math.sin(dir) * d);
      }
      ctx.restore();
    },
    pixelMosaic(ctx, w, h, x, y, rw, rh, block = 12) { // 局部马赛克：块平均
      x = Math.max(0, x | 0); y = Math.max(0, y | 0);
      rw = Math.min(w - x, rw | 0); rh = Math.min(h - y, rh | 0);
      if (rw <= 0 || rh <= 0) return;
      const id = ctx.getImageData(x, y, rw, rh);
      const px = new Uint32Array(id.data.buffer);
      for (let by = 0; by < rh; by += block) {
        for (let bx = 0; bx < rw; bx += block) {
          let sr = 0, sg = 0, sb = 0, n = 0;
          for (let j = 0; j < block && by + j < rh; j++) {
            for (let i2 = 0; i2 < block && bx + i2 < rw; i2++) {
              const c = px[(by + j) * rw + bx + i2];
              sr += c & 255; sg += (c >> 8) & 255; sb += (c >> 16) & 255; n++;
            }
          }
          const cc = (255 << 24) | (((sb / n) | 0) << 16) | (((sg / n) | 0) << 8) | ((sr / n) | 0);
          for (let j = 0; j < block && by + j < rh; j++)
            for (let i2 = 0; i2 < block && bx + i2 < rw; i2++)
              px[(by + j) * rw + bx + i2] = cc;
        }
      }
      ctx.putImageData(id, x, y);
    },
    edgeGlow(ctx, w, h, thick = 26, color = "255,190,120", alpha = 0.30) {  // 边缘内发光
      ctx.save();
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, `rgba(${color},${alpha})`); g.addColorStop(0.25, `rgba(${color},0)`);
      g.addColorStop(0.75, `rgba(${color},0)`); g.addColorStop(1, `rgba(${color},${alpha})`);
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      const g2 = ctx.createLinearGradient(0, 0, w, 0);
      g2.addColorStop(0, `rgba(${color},${alpha})`); g2.addColorStop(0.2, `rgba(${color},0)`);
      g2.addColorStop(0.8, `rgba(${color},0)`); g2.addColorStop(1, `rgba(${color},${alpha})`);
      ctx.fillStyle = g2; ctx.fillRect(0, 0, w, h);
      ctx.restore();
    },
    lutGrade(ctx, w, h, preset = "tealOrange", amount = 1) {  // LUT 色彩分级（6 预设）
      const P = {
        tealOrange:  { shadowTint: [10, 60, 80],  highTint: [255, 170, 100], sat: 1.12, con: 1.06 },
        bleach:      { shadowTint: [30, 30, 40],  highTint: [255, 255, 245], sat: 0.82, con: 1.10 },
        noir:        { shadowTint: [8, 10, 14],   highTint: [255, 255, 255], sat: 0.0,  con: 1.25 },
        golden:      { shadowTint: [40, 24, 8],   highTint: [255, 214, 140], sat: 1.18, con: 1.04 },
        cyber:       { shadowTint: [16, 8, 48],   highTint: [120, 255, 230], sat: 1.30, con: 1.08 },
        cross:       { shadowTint: [24, 48, 40],  highTint: [255, 120, 160], sat: 1.22, con: 0.96 },
      };
      const p = P[preset] || P.tealOrange;
      const id = ctx.getImageData(0, 0, w, h);
      const d = id.data;
      for (let i = 0; i < d.length; i += 4) {
        let r = d[i], g = d[i + 1], b = d[i + 2];
        const lum = (r * 0.299 + g * 0.587 + b * 0.114) / 255;
        const k = Math.min(1, Math.max(0, (lum - 0.5) * 2 + 0.5));
        r += (p.shadowTint[0] - r) * (1 - k) * 0.35 * amount;
        g += (p.shadowTint[1] - g) * (1 - k) * 0.35 * amount;
        b += (p.shadowTint[2] - b) * (1 - k) * 0.35 * amount;
        r += (p.highTint[0] - r) * k * 0.30 * amount;
        g += (p.highTint[1] - g) * k * 0.30 * amount;
        b += (p.highTint[2] - b) * k * 0.30 * amount;
        const avg = (r + g + b) / 3;
        r = avg + (r - avg) * p.sat; g = avg + (g - avg) * p.sat; b = avg + (b - avg) * p.sat;
        r = (r - 128) * p.con + 128; g = (g - 128) * p.con + 128; b = (b - 128) * p.con + 128;
        d[i] = r < 0 ? 0 : r > 255 ? 255 : r;
        d[i + 1] = g < 0 ? 0 : g > 255 ? 255 : g;
        d[i + 2] = b < 0 ? 0 : b > 255 ? 255 : b;
      }
      ctx.putImageData(id, 0, 0);
    },
    filmGate(ctx, w, h, t, amp = 1.6) {                // 片门抖动：整幅微移
      const dx = (Math.sin(t * 71.3) + Math.sin(t * 37.7) * 0.5) * amp;
      const dy = (Math.cos(t * 63.1) + Math.cos(t * 41.3) * 0.5) * amp * 0.6;
      const off = document.createElement("canvas");
      off.width = w; off.height = h;
      off.getContext("2d").drawImage(ctx.canvas, 0, 0);
      ctx.clearRect(0, 0, w, h);
      ctx.drawImage(off, dx, dy);
    },
    anamorphic(ctx, w, h, x, y, alpha = 0.35) {        // 变形宽屏光斑：横向拉长蓝晕
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      const g = ctx.createLinearGradient(x - w * 0.4, y, x + w * 0.4, y);
      g.addColorStop(0, "rgba(80,140,255,0)");
      g.addColorStop(0.5, `rgba(120,170,255,${alpha})`);
      g.addColorStop(1, "rgba(80,140,255,0)");
      ctx.fillStyle = g;
      ctx.fillRect(x - w * 0.4, y - 2, w * 0.8, 4);
      const g2 = ctx.createRadialGradient(x, y, 0, x, y, 60);
      g2.addColorStop(0, `rgba(255,255,255,${alpha})`);
      g2.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.arc(x, y, 60, 0, TAU); ctx.fill();
      ctx.restore();
    },
    starfield(ctx, w, h, t, n = 120, seed = 53) {      // 星野：闪烁繁星
      const rnd = mulberry32(seed);
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < n; i++) {
        const x = rnd() * w, y = rnd() * h * 0.85, b = 0.3 + rnd() * 0.7;
        const tw = 0.6 + 0.4 * Math.sin(t * (1 + rnd() * 3) + i);
        ctx.fillStyle = `rgba(255,255,255,${b * tw * 0.9})`;
        const r = rnd() < 0.08 ? 1.6 : 0.7;
        ctx.fillRect(x, y, r, r);
      }
      ctx.restore();
    },
    bokehFloat(ctx, w, h, t, seed = 61, n = 8) {       // 浮焦大光斑：慢漂柔焦
      const rnd = mulberry32(seed);
      ctx.save(); ctx.globalCompositeOperation = "screen";
      for (let i = 0; i < n; i++) {
        const x = rnd() * w, y = rnd() * h, r = 30 + rnd() * 60, ph = rnd() * TAU;
        const px = x + Math.sin(t * 0.2 + ph) * 40, py = (y + t * 10) % (h + 120) - 60;
        const g = ctx.createRadialGradient(px, py, r * 0.6, px, py, r);
        const hue = 20 + rnd() * 50;
        g.addColorStop(0, `hsla(${hue},70%,70%,0.10)`);
        g.addColorStop(1, `hsla(${hue},70%,70%,0)`);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(px, py, r, 0, TAU); ctx.fill();
      }
      ctx.restore();
    },
    heatWave(ctx, w, h, t, amp = 4, slices = 36) {     // 热浪扭曲：条带正弦位移
      const sy = Math.ceil(h / slices);
      for (let i = 0; i < slices; i++) {
        const dx = Math.sin(i * 0.7 + t * 3.2) * amp * (0.5 + 0.5 * Math.sin(i * 0.21 + t));
        ctx.drawImage(ctx.canvas, 0, i * sy, w, sy, dx, i * sy, w, sy);
      }
    },
    underwater(ctx, w, h, t, tint = "20,80,120", alpha = 0.14) {  // 水下发波 + 蓝调
      const sy = Math.ceil(h / 44);
      for (let i = 0; i < 44; i++) {
        const dx = Math.sin(i * 0.5 + t * 1.8) * 5 * (0.4 + 0.6 * Math.sin(i * 0.13 + t * 0.7));
        ctx.drawImage(ctx.canvas, 0, i * sy, w, sy, dx, i * sy, w, sy);
      }
      ctx.save();
      ctx.fillStyle = `rgba(${tint},${alpha})`;
      ctx.fillRect(0, 0, w, h);
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < 5; i++) {                     // 焦散光网
        const y = (i * h / 5 + t * 30) % h;
        const g = ctx.createLinearGradient(0, y - 20, 0, y + 20);
        g.addColorStop(0, "rgba(150,220,255,0)"); g.addColorStop(0.5, "rgba(150,220,255,0.10)"); g.addColorStop(1, "rgba(150,220,255,0)");
        ctx.fillStyle = g; ctx.fillRect(0, y - 20, w, 40);
      }
      ctx.restore();
    },
    crtCurve(ctx, w, h, t) {                            // CRT 曲面：桶形畸变 + 扫描线
      const sy = 6;
      for (let i = 0; i * sy < h; i++) {
        const y = i * sy, v = (y / h - 0.5) * 2;
        const s = 1 - Math.abs(v) * 0.06;
        ctx.drawImage(ctx.canvas, 0, y, w, sy, w / 2 - w * s / 2, y, w * s, sy);
      }
      ctx.save();
      ctx.globalAlpha = 0.10; ctx.fillStyle = "#000";
      for (let y = 0; y < h; y += 3) ctx.fillRect(0, y, w, 1);
      ctx.globalAlpha = 0.05 + 0.03 * Math.sin(t * 20);
      const g = ctx.createRadialGradient(w / 2, h / 2, h * 0.3, w / 2, h / 2, h * 0.75);
      g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "rgba(0,0,0,1)");
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      ctx.restore();
    },
    hologram(ctx, w, h, t, alpha = 0.12) {              // 全息：扫描掠影 + 青调闪烁
      ctx.save();
      const y = (t * 0.35 % 1) * h;
      const g = ctx.createLinearGradient(0, y - 60, 0, y + 60);
      g.addColorStop(0, "rgba(90,220,255,0)");
      g.addColorStop(0.5, `rgba(90,220,255,${alpha * 2})`);
      g.addColorStop(1, "rgba(90,220,255,0)");
      ctx.fillStyle = g; ctx.fillRect(0, y - 60, w, 120);
      ctx.globalAlpha = 0.05 + 0.03 * Math.sin(t * 40);
      ctx.fillStyle = "#5fe0ff"; ctx.fillRect(0, 0, w, h);
      ctx.globalAlpha = 0.06;
      ctx.fillStyle = "#000";
      for (let yy = 0; yy < h; yy += 4) ctx.fillRect(0, yy, w, 1);
      ctx.restore();
    },
  };
  const UTIL = {
    rnd: mulberry32,
    PALETTES: {
      cinema: { bg: "#0a0c10", fg: "#f2f5f9", ac: "#e8b464", ac2: "#8b9dc3", sub: "#8e99a8" },
      tech: { bg: "#05070b", fg: "#eef3fa", ac: "#5be2a1", ac2: "#7c5cff", sub: "#7c8ba1" },
      paper: { bg: "#f4f1ea", fg: "#1a1a1a", ac: "#c8452d", ac2: "#2f5d50", sub: "#6b6b6b" },
      night: { bg: "#080b14", fg: "#e6ebff", ac: "#ff7a59", ac2: "#4d7cff", sub: "#8891a8" },
      mono: { bg: "#111111", fg: "#f0f0f0", ac: "#f0f0f0", ac2: "#888888", sub: "#777777" },
    },
    catmullRom(points, samples = 60) {
      const p = points, out = [];
      for (let i = 0; i < p.length - 1; i++) {
        const p0 = p[Math.max(0, i - 1)], p1 = p[i], p2 = p[i + 1], p3 = p[Math.min(p.length - 1, i + 2)];
        for (let j = 0; j < samples; j++) {
          const t = j / samples, t2 = t * t, t3 = t2 * t;
          const f = (a, b, c, d) => 0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
          out.push({ x: f(p0.x, p1.x, p2.x, p3.x), y: f(p0.y, p1.y, p2.y, p3.y), z: f(p0.z, p1.z, p2.z, p3.z) });
        }
      }
      out.push(p[p.length - 1]);
      return out;
    },
    samplePath(path, t) {
      const i = clamp(t) * (path.length - 1);
      const a = Math.floor(i), f = i - a;
      const p1 = path[a], p2 = path[Math.min(path.length - 1, a + 1)];
      return { x: lerp(p1.x, p2.x, f), y: lerp(p1.y, p2.y, f), z: lerp(p1.z === undefined ? 0 : p1.z, p2.z === undefined ? 0 : p2.z, f) };
    },
  };

  global.OV = {
    E, MOVE, SHOOT, Camera3D, D3, TYPE, FX, TIME, UTIL,
    Vec3, clamp, lerp, seg, smoothstep, mix, rgba, noise1, noise2, fbm2, mulberry32, TAU, PI,
  };
  if (typeof module !== "undefined") module.exports = global.OV;
})(typeof window !== "undefined" ? window : globalThis);
