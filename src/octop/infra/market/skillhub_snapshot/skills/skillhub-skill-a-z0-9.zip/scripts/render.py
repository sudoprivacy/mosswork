"""OPUS 5.5 流程 · 确定性逐帧渲染器（并行版）
用法: python3 render.py scene.html frames/ [fps] [--workers N] [--gpu]
  或环境变量 OV_GPU=1 开 GPU（mesa desktop GL，需外部 xvfb-run -a 包裹：
  xvfb-run -a python3 render.py scene.html frames/ --gpu）
场景契约: HTML 暴露 window.renderFrame(t) / window.DURATION / window.FPS

效率:
  --workers N   开 N 个页面并行渲染（默认: CPU 数/2, 上限 8）
  断点续渲      已存在且非空的 f####.png 自动跳过（--clean 强制重渲）
"""
import asyncio, base64, os, pathlib, sys
from playwright.async_api import async_playwright

RENDER_JS = ("(t)=>{const c=document.querySelector('#frame')||document.querySelector('canvas');"
             "window.renderFrame(t);return c.toDataURL('image/png')}")


async def render_page(page, scene_uri, indices, fps, outdir, total, tag):
    await page.goto(scene_uri)
    await page.wait_for_function("typeof window.renderFrame === 'function'")
    await page.evaluate("document.fonts.ready")
    done = 0
    for i in indices:
        data = await page.evaluate(RENDER_JS, i / fps)
        (outdir / f"f{i:04d}.png").write_bytes(base64.b64decode(data.split(",", 1)[1]))
        done += 1
        if done % 60 == 0:
            print(f"  [{tag}] 帧 {i+1}/{total}")


async def main():
    if len(sys.argv) < 3:
        sys.exit("用法: python3 render.py scene.html frames/ [fps] [--workers N] [--clean]")
    scene = pathlib.Path(sys.argv[1]).resolve()
    outdir = pathlib.Path(sys.argv[2])
    fps, workers, clean = None, None, "--clean" in sys.argv
    gpu = "--gpu" in sys.argv or os.environ.get("OV_GPU") == "1"
    if "--workers" in sys.argv:
        workers = int(sys.argv[sys.argv.index("--workers") + 1])

    async with async_playwright() as p:
        args = ["--font-render-hinting=none", "--force-color-profile=srgb", "--allow-file-access-from-files"]
        if gpu:
            # headless swiftshader 在此环境不可用 → xvfb 虚拟显示 + mesa desktop GL
            args += ["--use-gl=desktop", "--enable-unsafe-swiftshader", "--no-sandbox"]
        headless = not gpu
        browser = await p.chromium.launch(args=args, headless=headless)
        probe = await browser.new_page(viewport={"width": 1920, "height": 1080},
                                       device_scale_factor=1)
        await probe.goto(scene.as_uri())
        await probe.wait_for_function("typeof window.renderFrame === 'function'")
        await probe.evaluate("document.fonts.ready")
        duration = await probe.evaluate("window.DURATION")
        fps = fps or (await probe.evaluate("window.FPS") or 30)
        w, h = await probe.evaluate(
            "[(document.querySelector('#frame')||document.querySelector('canvas')).width,"
            " (document.querySelector('#frame')||document.querySelector('canvas')).height]")
        w, h = int(w), int(h)
        vp = {"width": w, "height": h}
        await probe.set_viewport_size(vp)
        await probe.close()

        outdir.mkdir(parents=True, exist_ok=True)
        if clean:
            for f in outdir.glob("f*.png"):
                f.unlink()
        total = round(duration * fps)
        todo = [i for i in range(total)
                if not (outdir / f"f{i:04d}.png").exists()
                or (outdir / f"f{i:04d}.png").stat().st_size == 0]
        skipped = total - len(todo)
        if skipped:
            print(f"  断点续渲: 跳过 {skipped} 帧，剩 {len(todo)} 帧")
        if workers is None:
            workers = min(8, max(1, (os.cpu_count() or 4) // 2))
        workers = min(workers, len(todo)) if todo else 1

        # 轮询分配帧号，负载均衡
        buckets = [todo[k::workers] for k in range(workers)] if todo else [[]]
        if workers > 1:
            print(f"  并行渲染: {workers} workers × {w}x{h}")
        results = await asyncio.gather(*[
            render_page(await browser.new_page(viewport=vp, device_scale_factor=1),
                        scene.as_uri(), b, fps, outdir, total, f"w{k}")
            for k, b in enumerate(buckets)])
        await browser.close()
    print(f"完成: {total} 帧 @ {fps}fps, 时长 {duration}s, 输出目录 {outdir}")


asyncio.run(main())
