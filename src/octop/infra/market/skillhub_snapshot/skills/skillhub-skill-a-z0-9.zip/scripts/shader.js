/* ============================================================
   opus-video / shader.js  v1.0   WebGL 着色器层
   真实光影：SDF 光线步进 · 软阴影 · 镜面反射地面 · 体积光 · 大气雾
   用法:
     const gl = OVGL.init(document.getElementById("gl"));   // 离屏 WebGL canvas
     window.renderFrame = function(t){
       gl.draw(t, { cam:{x,y,z}, target:{x,y,z}, beat:0..1, hue:0 });
       ctx.drawImage(document.getElementById("gl"), 0, 0);  // 合成进 2D 画布
       ... 2D UI 层
     };
   确定性：所有输入只有 t 与相机参数，满足帧契约
   ============================================================ */
(function (global) {
  "use strict";

  const VERT = `
attribute vec2 a_pos;
void main(){ gl_Position = vec4(a_pos, 0.0, 1.0); }`;

  /* 场景：菱形排列的立方体阵列 + 反射地面 + 体积光 + 雾 */
  const FRAG = `
precision highp float;
uniform vec2  u_res;
uniform float u_time;
uniform vec3  u_cam;
uniform vec3  u_tgt;
uniform float u_beat;    // 踩点脉冲 0..1
uniform float u_hue;     // 色相偏移

#define MAX_DIST 40.0
#define SURF     0.002

/* ---------- SDF ---------- */
mat2 rot(float a){ float c=cos(a), s=sin(a); return mat2(c,-s,s,c); }
float sdBox(vec3 p, vec3 b){ vec3 q=abs(p)-b; return length(max(q,0.0))+min(max(q.x,max(q.y,q.z)),0.0); }
float smin(float a, float b, float k){ float h=clamp(0.5+0.5*(b-a)/k,0.0,1.0); return mix(b,a,h)-k*h*(1.0-h); }

/* 场景距离场：地面 + 中央悬浮立方体 + 卫星方块 */
float map(vec3 p){
  float t = u_time;
  // 地面
  float d = p.y + 1.2;
  // 主体：旋转 + 呼吸
  vec3 q = p - vec3(0.0, 1.1 + sin(t*0.8)*0.12, 0.0);
  q.xz *= rot(t*0.5);
  q.xy *= rot(t*0.23);
  float core = sdBox(q, vec3(0.85 + u_beat*0.05));
  // 主体线框感：挖空网格槽
  float slots = min(min(
      abs(fract(q.x*2.0)-0.5),
      abs(fract(q.y*2.0)-0.5)),
      abs(fract(q.z*2.0)-0.5)) / 2.0;
  core = max(core, slots - 0.06);            // 镂空
  d = min(d, core);
  // 卫星：7 个环绕
  for (int i = 0; i < 7; i++) {
    float fi = float(i);
    float a  = fi / 7.0 * 6.2832 + t * 0.22;
    float r  = 2.3 + mod(fi, 3.0) * 0.85;
    vec3 c   = vec3(cos(a) * r, 0.55 + sin(t * 0.9 + fi * 1.7) * 0.45 + mod(fi,2.0)*0.5, sin(a) * r);
    vec3 o   = p - c;
    o.xz *= rot(t * 0.7 + fi);
    d = min(d, sdBox(o, vec3(0.34)));
  }
  return d;
}

/* ---------- 法线 ---------- */
vec3 calcN(vec3 p){
  vec2 e = vec2(0.0015, 0.0);
  return normalize(vec3(
    map(p+e.xyy)-map(p-e.xyy),
    map(p+e.yxy)-map(p-e.yxy),
    map(p+e.yyx)-map(p-e.yyx)));
}

/* ---------- 软阴影（iq penumbra trick）---------- */
float softShadow(vec3 ro, vec3 rd){
  float res = 1.0, t = 0.02;
  for (int i = 0; i < 40; i++) {
    float h = map(ro + rd * t);
    res = min(res, 9.0 * h / t);
    t += clamp(h, 0.02, 0.35);
    if (res < 0.005 || t > 18.0) break;
  }
  return clamp(res, 0.0, 1.0);
}

/* ---------- AO ---------- */
float calcAO(vec3 p, vec3 n){
  float occ = 0.0, sca = 1.0;
  for (int i = 0; i < 5; i++) {
    float h = 0.02 + 0.13 * float(i);
    occ += (h - map(p + n * h)) * sca;
    sca *= 0.72;
  }
  return clamp(1.0 - 2.2 * occ, 0.0, 1.0);
}

/* ---------- 主光方向（左上前） ---------- */
const vec3 LDIR = normalize(vec3(-0.55, 0.75, -0.42));

vec3 shade(vec3 p, vec3 n, vec3 rd, float m){
  float dif = clamp(dot(n, LDIR), 0.0, 1.0);
  float sh  = dif > 0.01 ? softShadow(p + n*0.01, LDIR) : 0.0;
  float ao  = calcAO(p, n);
  // 轮廓光（背后）
  float rim = pow(clamp(1.0 + dot(n, rd), 0.0, 1.0), 3.0) * 0.5;
  // Blinn-Phong 高光
  vec3 hv = normalize(LDIR - rd);
  float spe = pow(clamp(dot(n, hv), 0.0, 1.0), 42.0) * dif * sh;

  // 材质区分：地面反射率低、方块亮
  vec3 alb = m > 0.5 ? vec3(0.16, 0.22, 0.28) : vec3(0.30, 0.38, 0.46);
  vec3 col = alb * (0.10 + 0.9 * dif * sh) * ao;
  col += vec3(0.35, 0.95, 0.65) * rim * 0.5;         // 绿色轮廓光
  col += vec3(0.9, 0.98, 1.0) * spe * 1.2;
  // 主体镂空内发绿光（自发光）
  if (m > 0.5) col += vec3(0.10, 0.55, 0.34) * u_beat * 1.4;
  return col;
}

/* ---------- 体积光：沿视线累积亮度 ---------- */
vec3 volumetric(vec3 ro, vec3 rd, float maxT){
  float acc = 0.0;
  const int STEPS = 24;
  float st = maxT / float(STEPS);
  float t = st * 0.5;
  for (int i = 0; i < STEPS; i++) {
    vec3 p = ro + rd * t;
    // 只在光路上累积：投影到光方向
    float shadow = 1.0;
    float h = map(p);
    shadow = smoothstep(0.0, 1.0, h * 2.2);
    float lightAmt = clamp(dot(normalize(p - ro), LDIR), 0.0, 1.0);
    acc += shadow * lightAmt * st * 0.055;
    t += st;
  }
  acc *= 0.55 + u_beat * 0.8;
  return vec3(0.30, 0.85, 0.58) * acc;
}

/* ---------- tonemap ---------- */
vec3 aces(vec3 x){
  return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14), 0.0, 1.0);
}

void main(){
  vec2 uv = (gl_FragCoord.xy * 2.0 - u_res) / u_res.y;

  /* 相机 */
  vec3 ro = u_cam;
  vec3 ww = normalize(u_tgt - ro);
  vec3 uu = normalize(cross(ww, vec3(0.0, 1.0, 0.0)));
  vec3 vv = cross(uu, ww);
  vec3 rd = normalize(uv.x*uu + uv.y*vv + 1.9*ww);

  /* 主光线步进 */
  float t = 0.0, m = -1.0;
  for (int i = 0; i < 110; i++) {
    vec3 p = ro + rd * t;
    float d = map(p);
    if (d < SURF) { m = mod(p.y, 2.0) > 1.6 ? 1.0 : 0.0; break; }
    t += d * 0.9;
    if (t > MAX_DIST) break;
  }

  vec3 col;
  if (t < MAX_DIST) {
    vec3 p = ro + rd * t;
    vec3 n = calcN(p);
    col = shade(p, n, rd, m);
    /* 地面反射：一次反射 raymarch（只对地面） */
    if (m < 0.5) {
      vec3 rr = reflect(rd, n);
      float rt = 0.05; float rm = -1.0;
      for (int i = 0; i < 48; i++) {
        float h = map(p + rr * rt);
        if (h < SURF) { rm = 1.0; break; }
        rt += h * 0.9;
        if (rt > 12.0) break;
      }
      if (rm > 0.0) {
        vec3 rp = p + rr * rt;
        vec3 rn = calcN(rp);
        col += shade(rp, rn, rr, 1.0) * 0.35;      // 反射强度
      }
      // 地面菲涅尔衰减
      col *= 0.55 + 0.45 * pow(clamp(1.0 + rd.y, 0.0, 1.0), 1.6);
    }
    /* 大气雾 */
    float fog = 1.0 - exp(-0.028 * t * t);
    col = mix(col, vec3(0.012, 0.022, 0.036), fog);
  } else {
    col = vec3(0.012, 0.022, 0.036);
  }

  /* 体积光 + 背景 */
  col += volumetric(ro, rd, min(t, 26.0));

  /* 星点背景 */
  vec3 bg = vec3(0.012, 0.022, 0.036);
  float star = pow(max(0.0, sin(rd.x*140.0)*sin(rd.y*140.0)), 60.0);
  col += bg + vec3(0.5,0.7,0.9)*star*0.12;

  /* tonemap + 轻微暗角 */
  col = aces(col * 1.25);
  vec2 q = gl_FragCoord.xy / u_res;
  col *= 0.35 + 0.65 * pow(16.0 * q.x*q.y*(1.0-q.x)*(1.0-q.y), 0.28);

  gl_FragColor = vec4(col, 1.0);
}`;

  function init(glCanvas) {
    const gl = glCanvas.getContext("webgl", {
      preserveDrawingBuffer: true,
      antialias: false,
      alpha: false,
    });
    if (!gl) throw new Error("WebGL 不可用");
    const mk = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS))
        throw new Error("着色器编译失败: " + gl.getShaderInfoLog(s));
      return s;
    };
    const prog = gl.createProgram();
    gl.attachShader(prog, mk(gl.VERTEX_SHADER, VERT));
    gl.attachShader(prog, mk(gl.FRAGMENT_SHADER, FRAG));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS))
      throw new Error("链接失败: " + gl.getProgramInfoLog(prog));
    gl.useProgram(prog);
    // 全屏三角形
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, "a_pos");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const U = {};
    for (const n of ["u_res", "u_time", "u_cam", "u_tgt", "u_beat", "u_hue"])
      U[n] = gl.getUniformLocation(prog, n);

    return {
      draw(t, opt = {}) {
        const cam = opt.cam || { x: 0, y: 1.2, z: -5 };
        const tgt = opt.target || { x: 0, y: 1, z: 0 };
        gl.viewport(0, 0, glCanvas.width, glCanvas.height);
        gl.uniform2f(U.u_res, glCanvas.width, glCanvas.height);
        gl.uniform1f(U.u_time, t);
        gl.uniform3f(U.u_cam, cam.x, cam.y, cam.z);
        gl.uniform3f(U.u_tgt, tgt.x, tgt.y, tgt.z);
        gl.uniform1f(U.u_beat, clamp(opt.beat || 0, 0, 1));
        gl.uniform1f(U.u_hue, opt.hue || 0);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      },
      gl,
    };
  }

  function clamp(v, a = 0, b = 1) { return Math.min(b, Math.max(a, v)); }
  global.OVGL = { init };
})(typeof window !== "undefined" ? window : globalThis);
