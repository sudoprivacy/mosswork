/* model3d.js 翻倍能力冒烟测试：fromSTL / fromPLY / weld / instanced / outline / stats
   运行：node model3d_test.js */
const fs = require("fs");
const crypto = require("crypto");
const path = require("path");

// ---- 浏览器桩 ----
global.window = global;
global.document = { createElement: () => ({ width: 0, height: 0, getContext: () => null }) };

const SKILL = "/root/.codebuddy/skills/opus-video";
eval(fs.readFileSync(path.join(SKILL, "motion-3d.js"), "utf8"));
eval(fs.readFileSync(path.join(SKILL, "model3d.js"), "utf8"));

const OV = global.OV, OVM = global.OVM;
if (!OV || !OVM) { console.error("FAIL: OV/OVM 未挂载"); process.exit(1); }

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { pass++; console.log("  PASS  " + msg); }
  else { fail++; console.log("  FAIL  " + msg); }
}

// ---- ctx 记录桩 ----
function makeCtx() {
  const log = [];
  const ctx = {
    log,
    fillStyle: "", strokeStyle: "", lineWidth: 1, lineJoin: "", globalAlpha: 1,
    shadowColor: "", shadowBlur: 0,
    beginPath() { log.push("beginPath"); },
    moveTo(x, y) { log.push(`moveTo ${x.toFixed(2)} ${y.toFixed(2)}`); },
    lineTo(x, y) { log.push(`lineTo ${x.toFixed(2)} ${y.toFixed(2)}`); },
    closePath() { log.push("closePath"); },
    fill() { log.push("fill"); },
    stroke() { log.push("stroke"); },
    save() { log.push("save"); },
    restore() { log.push("restore"); },
  };
  return ctx;
}
const md5 = s => crypto.createHash("md5").update(s).digest("hex").slice(0, 12);

// 相机放左-上-前斜角：可见 -x / +y / -z 三个面 = 6 三角面
const cam = new OV.Camera3D({ x: -600, y: 500, z: -900, fov: 900, cx: 640, cy: 360 });
cam.lookAt({ x: 0, y: 0, z: 0 });

// ========== 1. OBJ（回归） ==========
console.log("\n[1] OBJ 解析（回归）");
const cubeOBJ = `v -50 -50 -50
v 50 -50 -50
v 50 50 -50
v -50 50 -50
v -50 -50 50
v 50 -50 50
v 50 50 50
v -50 50 50
f 1 4 3 2
f 5 6 7 8
f 1 2 6 5
f 2 3 7 6
f 3 4 8 7
f 4 1 5 8`;
const mObj = OVM.fromOBJ(cubeOBJ);
const sObj = OVM.stats(mObj);
ok(sObj.vertices === 8 && sObj.faces === 12, `OBJ 立方体 8 顶点 / 12 面（实际 ${sObj.vertices}/${sObj.faces}）`);
// normalize 以「质心最大半径」归一化：立方体角距 50*√3=86.6 → size=100/86.6≈1.1547
ok(Math.abs(Math.max(...sObj.size) - 100 / (50 * Math.sqrt(3))) < 1e-3,
  `归一化半径 1（size ${sObj.size.map(v => v.toFixed(3))}）`);

// ========== 2. ASCII STL ==========
console.log("\n[2] ASCII STL 解析");
// 四边形拆两个三角形：A(0,0,0) B(100,0,0) C(100,100,0) D(0,100,0)
const asciiSTL = `solid quad
facet normal 0 0 1
outer loop
vertex 0 0 0
vertex 100 0 0
vertex 100 100 0
endloop
endfacet
facet normal 0 0 1
outer loop
vertex 0 0 0
vertex 100 100 0
vertex 0 100 0
endloop
endfacet
endsolid quad`;
const mSTLa = OVM.fromSTL(asciiSTL);
const sSTLa = OVM.stats(mSTLa);
ok(sSTLa.vertices === 4 && sSTLa.faces === 2, `ASCII STL 焊接 6→4 顶点 / 2 面（实际 ${sSTLa.vertices}/${sSTLa.faces}）`);

// ========== 3. 二进制 STL ==========
console.log("\n[3] 二进制 STL 解析");
function buildBinarySTL(tris) {
  const buf = new ArrayBuffer(84 + tris.length * 50);
  const dv = new DataView(buf);
  const header = "CodeBody binary STL smoke test";
  for (let i = 0; i < header.length; i++) dv.setUint8(i, header.charCodeAt(i));
  dv.setUint32(80, tris.length, true);
  tris.forEach((t, i) => {
    const base = 84 + i * 50;
    dv.setFloat32(base, 0, true); dv.setFloat32(base + 4, 0, true); dv.setFloat32(base + 8, 1, true);
    t.forEach((v, k) => {
      dv.setFloat32(base + 12 + k * 12, v[0], true);
      dv.setFloat32(base + 16 + k * 12, v[1], true);
      dv.setFloat32(base + 20 + k * 12, v[2], true);
    });
    dv.setUint16(base + 48, 0, true);
  });
  return buf;
}
// 立方体 12 三角面（与 OBJ 同几何，顶点重复存储）
const P8 = [[-50, -50, -50], [50, -50, -50], [50, 50, -50], [-50, 50, -50],
            [-50, -50, 50], [50, -50, 50], [50, 50, 50], [-50, 50, 50]];
const quads = [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]];
const tris12 = [];
for (const q of quads) { tris12.push([P8[q[0]], P8[q[1]], P8[q[2]]], [P8[q[0]], P8[q[2]], P8[q[3]]]); }
const mSTLb = OVM.fromSTL(buildBinarySTL(tris12));
const sSTLb = OVM.stats(mSTLb);
ok(sSTLb.vertices === 8 && sSTLb.faces === 12, `二进制 STL 焊接 36→8 顶点 / 12 面（实际 ${sSTLb.vertices}/${sSTLb.faces}）`);

// ========== 4. ASCII PLY ==========
console.log("\n[4] ASCII PLY 解析（Quad + 附加属性）");
const asciiPLY = `ply
format ascii 1.0
comment smoke test
element vertex 4
property float x
property float y
property float z
property uchar red
element face 2
property list uchar int vertex_indices
end_header
0 0 0 255
100 0 0 0
100 100 0 0
0 100 0 0
4 0 1 2 3
3 0 2 3`;
const mPlya = OVM.fromPLY(asciiPLY);
const sPlya = OVM.stats(mPlya);
ok(sPlya.vertices === 4 && sPlya.faces === 3, `ASCII PLY Quad 扇形三角化 4 顶点 / 3 面（实际 ${sPlya.vertices}/${sPlya.faces}）`);

// ========== 5. 二进制 PLY ==========
console.log("\n[5] 二进制 PLY 解析（little-endian + nx 属性）");
const plyHeader = `ply
format binary_little_endian 1.0
element vertex 4
property float x
property float y
property float z
property float nx
element face 2
property list uchar int vertex_indices
end_header
`;
const headBytes = Buffer.from(plyHeader, "latin1");
const bodyLen = 4 * 16 + 2 * 13; // 顶点 3f+1f，面 uchar+3×int32
const plyBuf = new ArrayBuffer(headBytes.length + bodyLen);
new Uint8Array(plyBuf).set(headBytes, 0);
const pdv = new DataView(plyBuf);
let off = headBytes.length;
const pv = [[0, 0, 0, 0], [100, 0, 0, 0], [100, 100, 0, 0], [0, 100, 0, 0]];
for (const v of pv) for (const n of v) { pdv.setFloat32(off, n, true); off += 4; }
for (const f of [[0, 1, 2], [0, 2, 3]]) {
  pdv.setUint8(off, 3); off += 1;
  for (const i of f) { pdv.setInt32(off, i, true); off += 4; }
}
const mPlyb = OVM.fromPLY(plyBuf);
const sPlyb = OVM.stats(mPlyb);
ok(sPlyb.vertices === 4 && sPlyb.faces === 2, `二进制 PLY 4 顶点 / 2 面（实际 ${sPlyb.vertices}/${sPlyb.faces}）`);
ok(off === plyBuf.byteLength, `二进制 PLY 消费字节数精确（${off} === ${plyBuf.byteLength}）`);

// ========== 6. draw 渲染 + 确定性 ==========
console.log("\n[6] draw 渲染与确定性");
const c1 = makeCtx();
const n1 = OVM.draw(c1, mObj, cam, { pos: [0, 0, 0], scale: 200, color: [180, 200, 220], edge: "#0a0f14" });
const c2 = makeCtx();
const n2 = OVM.draw(c2, mObj, cam, { pos: [0, 0, 0], scale: 200, color: [180, 200, 220], edge: "#0a0f14" });
ok(n1 > 0 && n1 === 6, `draw 返回正面数 ${n1}（斜角机位应见 3 面 = 6 三角面）`);
ok(md5(c1.log.join("\n")) === md5(c2.log.join("\n")), "draw 两次渲染逐调用一致（确定性）");
ok(c1.log.filter(l => l === "fill").length === n1, `fill 次数 ${c1.log.filter(l => l === "fill").length} === 面数 ${n1}`);

// ========== 7. instanced 实例化 ==========
console.log("\n[7] instanced 实例化批绘");
const ci = makeCtx();
const items = [
  { pos: [-300, 0, 0], scale: 120, color: [220, 90, 90] },
  { pos: [0, 0, 0], scale: 160, color: [90, 220, 120] },
  { pos: [300, 0, 0], scale: 120, color: [90, 120, 220], yaw: 0.6 },
];
const total = OVM.instanced(ci, mObj, cam, items, { edge: "#000" });
ok(total === n1 * 3, `instanced 3 实例总面数 ${total} === 单实例 ${n1} × 3`);
ok(ci.log.filter(l => l === "fill").length === total, "fill 次数与总面数一致");

// ========== 8. outline 轮廓描边 ==========
console.log("\n[8] outline 剪影视廓描边");
const co = makeCtx();
const strokes = OVM.outline(co, mObj, cam, { scale: 200, width: 2.5, color: "#000" });
ok(strokes > 0, `outline 描边数 ${strokes} > 0（3 面可见时应为 6 条剪影边）`);
const co2 = makeCtx();
const strokes2 = OVM.outline(co2, mObj, cam, { scale: 200, width: 2.5, color: "#000" });
ok(md5(co.log.join("\n")) === md5(co2.log.join("\n")), "outline 两次渲染逐调用一致（确定性）");
ok(co.log.filter(l => l === "stroke").length === strokes, "stroke 次数与返回描边数一致");

// outline + draw 叠加（标准用法：先描边后盖心）
const cc = makeCtx();
OVM.outline(cc, mObj, cam, { scale: 200 });
OVM.draw(cc, mObj, cam, { scale: 200, color: [200, 210, 220] });
ok(cc.log.indexOf("stroke") < cc.log.lastIndexOf("fill"), "叠加顺序正确（stroke 在 fill 之前）");

// ========== 9. weld 单独验证 ==========
console.log("\n[9] weld 顶点焊接");
const dup = {
  name: "dup",
  positions: [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 0, 0], [1, 0, 0], [1, 1, 0]],
  indices: [0, 1, 2, 3, 4, 5],
};
const welded = OVM.weld(dup);
ok(welded.positions.length === 3 && welded.indices.length === 6, `weld 6→3 顶点，索引重映射（实际 ${welded.positions.length}/${welded.indices.length}）`);
const degen = { name: "d", positions: [[0, 0, 0], [0, 0, 0], [1, 1, 1]], indices: [0, 1, 2] };
ok(OVM.weld(degen).indices.length === 0, "退化面（两顶点重合）被剔除");

console.log(`\n===== 结果：${pass} 通过 / ${fail} 失败 =====`);
process.exit(fail ? 1 : 0);
