"""OPUS 5.5 skill · 3D 模型搜索/下载引擎（Poly Haven API，免密钥，全 CC0）
用法:
  python3 models.py search <关键词> [--limit 8]      # 搜索模型（名称/标签/分类）
  python3 models.py url <资产ID>                      # 打印 glTF 下载直链
  python3 models.py get <资产ID> -o models/           # 下载并转换为 skill 网格 JSON
  python3 models.py convert <file.gltf> -o models/x.json  # 本地 gltf → 网格 JSON

网格 JSON 契约（供 model3d.js 的 OVM.load 使用）:
  { "name": str, "positions": [x,y,z,...], "indices": [i,...] }  # 已合并所有 primitive 并应用节点变换
注意: Poly Haven API 要求自定义 User-Agent（其 ToS 2.4）。
"""
import argparse, base64, json, pathlib, struct, sys, urllib.request

UA = {"User-Agent": "opus-video-skill/1.0"}
API = "https://api.polyhaven.com"
CACHE = pathlib.Path.home() / ".cache/opus-video-polyhaven.json"


def _get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


def assets(force=False):
    if CACHE.exists() and not force:
        return json.loads(CACHE.read_text())
    data = json.loads(_get(f"{API}/assets?type=models"))
    CACHE.parent.mkdir(parents=True, exist_ok=True)
    CACHE.write_text(json.dumps(data))
    return data


def search(query, limit=8):
    q = query.lower()
    hits = []
    for aid, a in assets().items():
        hay = " ".join([aid, a.get("name", ""), " ".join(a.get("tags", [])),
                        " ".join(a.get("categories", []))]).lower()
        if all(w in hay for w in q.split()):
            hits.append((aid, a))
    hits.sort(key=lambda x: -x[1].get("download_count", 0))
    for aid, a in hits[:limit]:
        print(f"{aid:32s} {a.get('polycount','?'):>7} tris  "
              f"{a.get('name','')[:40]:42s} cat={','.join(a.get('categories',[])[:2])}")
    print(f"-- {len(hits)} 个结果（显示前 {min(limit,len(hits))}）--")
    return [aid for aid, _ in hits]


def dl_url(aid, res="1k"):
    files = json.loads(_get(f"{API}/files/{aid}"))
    g = files.get("gltf", {}).get(res) or files.get("gltf", {})
    gltf = (g.get("gltf") or {}).get("url")
    return gltf, g.get("include", {})


def _read_accessor(gltf_json, bin_files, acc_i):
    acc = gltf_json["accessors"][acc_i]
    bv = gltf_json["bufferViews"][acc["bufferView"]]
    buf = bin_files[bv.get("buffer", 0)]
    off = bv.get("byteOffset", 0) + acc.get("byteOffset", 0)
    n = acc["count"]
    comp = {5126: "f", 5123: "H", 5125: "I", 5121: "B"}[acc["componentType"]]
    sizes = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}
    cnt = sizes[acc["type"]]
    stride = bv.get("byteStride") or cnt * struct.calcsize(comp)
    out = []
    for k in range(n):
        o = off + k * stride
        out.append(struct.unpack_from("<" + comp * cnt, buf, o))
    return out


def _node_transform(node):
    if "matrix" in node:
        m = node["matrix"]  # 列主序 16
        return [m[i::4] for i in range(4)]  # 行主序 rows
    t = node.get("translation", [0, 0, 0])
    r = node.get("rotation", [0, 0, 0, 1])  # xyzw 四元数
    s = node.get("scale", [1, 1, 1])
    x, y, z, w = r
    rot = [
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ]
    M = [[rot[i][j] * s[j] for j in range(3)] + [0] for i in range(3)]
    M.append([t[0], t[1], t[2], 1])
    return M


def _mat_mul(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(4)) for j in range(4)] for i in range(4)]


def _xform(M, p):
    return [M[0][0] * p[0] + M[0][1] * p[1] + M[0][2] * p[2] + M[0][3],
            M[1][0] * p[0] + M[1][1] * p[1] + M[1][2] * p[2] + M[1][3],
            M[2][0] * p[0] + M[2][1] * p[1] + M[2][2] * p[2] + M[2][3]]


def gltf_to_mesh(gltf_path, out_path):
    gltf_path = pathlib.Path(gltf_path)
    gltf = json.loads(gltf_path.read_text())
    # 读 bin buffers
    bin_files = []
    for b in gltf["buffers"]:
        uri = b.get("uri", "")
        if uri.startswith("data:"):
            bin_files.append(base64.b64decode(uri.split(",", 1)[1]))
        else:
            bin_files.append((gltf_path.parent / uri).read_bytes())
    positions, indices = [], []
    scene = gltf["scenes"][gltf.get("scene", 0)]
    for ni in scene["nodes"]:
        node = gltf["nodes"][ni]
        M = _node_transform(node)
        mesh_ids = list(node.get("meshes", []))
        if "mesh" in node:
            mesh_ids.append(node["mesh"])
        for mi in mesh_ids:
            mesh = gltf["meshes"][mi]
            for prim in mesh["primitives"]:
                base = len(positions)
                for p in _read_accessor(gltf, bin_files, prim["attributes"]["POSITION"]):
                    positions.append(_xform(M, p))
                idxs = _read_accessor(gltf, bin_files, prim["indices"])
                indices.extend(t[0] + base for t in idxs)
    if not positions:
        sys.exit("gltf 中未找到网格数据")
    # 居中 + 归一化到半径 1
    xs = [p[0] for p in positions]; ys = [p[1] for p in positions]; zs = [p[2] for p in positions]
    cx, cy, cz = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, (min(zs) + max(zs)) / 2
    r = max(max(abs(v - c) for v in axis) for axis, c in ((xs, cx), (ys, cy), (zs, cz))) or 1
    positions = [[(p[0] - cx) / r, (p[1] - cy) / r, (p[2] - cz) / r] for p in positions]
    out = {"name": gltf_path.stem, "positions": positions, "indices": indices}
    pathlib.Path(out_path).write_text(json.dumps(out))
    print(f"转换完成: {out_path}  顶点 {len(positions)}  三角形 {len(indices)//3}")


def get(aid, outdir="models"):
    outdir = pathlib.Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    gltf_url, include = dl_url(aid)
    tmp = outdir / f"{aid}.gltf"
    tmp.write_bytes(_get(gltf_url))
    gltf = json.loads(tmp.read_text())
    for b in gltf["buffers"]:
        if b.get("uri") and not b["uri"].startswith("data:"):
            (outdir / b["uri"]).write_bytes(_get(gltf_url.rsplit("/", 1)[0] + "/" + b["uri"]))
    out = outdir / f"{aid}.json"
    gltf_to_mesh(tmp, out)
    tmp.unlink()
    print(f"来源: Poly Haven (CC0)  https://polyhaven.com/a/{aid}")
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("search"); s.add_argument("query"); s.add_argument("--limit", type=int, default=8)
    u = sub.add_parser("url"); u.add_argument("aid"); u.add_argument("--res", default="1k")
    g = sub.add_parser("get"); g.add_argument("aid"); g.add_argument("-o", default="models")
    c = sub.add_parser("convert"); c.add_argument("gltf"); c.add_argument("-o", required=True)
    a = ap.parse_args()
    if a.cmd == "search": search(a.query, a.limit)
    elif a.cmd == "url": print(dl_url(a.aid, a.res)[0])
    elif a.cmd == "get": get(a.aid, a.o)
    elif a.cmd == "convert": gltf_to_mesh(a.gltf, a.o)
