/* ============================================================
   opus-video / fx-plus.js  v1.0   增强包
   光照材质（PBR 近似/投影阴影/AO）· 粒子系统 · 流体背景 · 摄影机镜头效果
   依赖 motion-3d.js（需先加载），挂载到 window.OVX
   全部为 t 的纯函数，满足确定性渲染契约
   ============================================================ */
(function (global) {
  "use strict";
  const OV = global.OV;
  if (!OV) throw new Error("fx-plus.js 需要先加载 motion-3d.js");

  const { clamp, lerp, seg, rgba, smoothstep, mulberry32, noise2, fbm2, TAU } = OV;
  const V = (x, y, z) => new OV.Vec3(x, y, z);

  /* ============================================================
     1. 材质 MAT：PBR 近似着色
     把「基色 + 法线 + 光向 + 视线」算成最终填充色 + 高光
     ============================================================ */
  const LIGHTS = {
    key: V(-0.45, 0.82, -0.5),      // 主光（左上前）
    fill: V(0.7, 0.25, -0.3),       // 补光（右侧，弱）
    rim: V(0.2, 0.35, 1.0),         // 轮廓光（背后打过来）
    ambient: 0.16,
    keyColor: [255, 246, 232],
    fillColor: [120, 150, 210],
    rimColor: [91, 226, 161],
  };

  const MAT = {
    // 单面着色：返回 {fill, spec, rim}
    shade(face, camPos, opt = {}) {
      const n = face.normal;
      const fc = face._center || (() => {
        const c = face.verts.reduce((s, v) => s.add(v), V(0, 0, 0)).mul(1 / face.verts.length);
        face._center = c; return c;
      })();
      const toCam = V(camPos.x - fc.x, camPos.y - fc.y, camPos.z - fc.z).norm();
      const view = toCam;

      const base = face.color || "#22323f";
      const br = parseInt(base.slice(1, 3), 16), bg = parseInt(base.slice(3, 5), 16), bb = parseInt(base.slice(5, 7), 16);

      // 主光（Lambert）
      const dk = Math.max(0, n.dot(LIGHTS.key));
      // 补光
      const df = Math.max(0, n.dot(LIGHTS.fill)) * 0.35;
      // 轮廓光：法线与视线垂直处最强（边缘发光）
      const dr = Math.pow(1 - Math.max(0, Math.abs(n.dot(view))), 2.4) * 0.85;
      // 环境光遮蔽近似：朝下的面更暗（地面遮挡）
      const ao = 0.72 + 0.28 * clamp(n.y * 0.5 + 0.5);

      const amb = LIGHTS.ambient;
      let r = br * (amb + dk * 0.92) * ao + LIGHTS.fillColor[0] * df * 0.25 + LIGHTS.rimColor[0] * dr * 0.30;
      let g = bg * (amb + dk * 0.92) * ao + LIGHTS.fillColor[1] * df * 0.25 + LIGHTS.rimColor[1] * dr * 0.30;
      let b = bb * (amb + dk * 0.92) * ao + LIGHTS.fillColor[2] * df * 0.25 + LIGHTS.rimColor[2] * dr * 0.30;

      // 高光（Blinn-Phong）：半角向量必须归一化，否则点积永远小于 1，高光恒为 0
      const half = LIGHTS.key.add(view).norm();
      const shin = opt.shininess === undefined ? 18 : opt.shininess;
      const ndh = Math.max(0, n.dot(half));
      // 窄高光 + 宽光泽：大平面近看时 ndh 很难接近 1，宽分量保证"有材质感"
      const spec = Math.pow(ndh, shin) * 0.8 + Math.pow(ndh, 4) * 0.22;
      r += spec * 210 * (opt.specK || 1);
      g += spec * 210 * (opt.specK || 1);
      b += spec * 215 * (opt.specK || 1);

      const fill = `rgb(${Math.round(clamp(r, 0, 255))},${Math.round(clamp(g, 0, 255))},${Math.round(clamp(b, 0, 255))})`;
      return {
        fill, spec: spec * (opt.specK || 1),
        edge: dr,                    // 轮廓光强度（用于描边）
        toCam, n, center: fc,
      };
    },
  };

  /* ============================================================
     2. 投影阴影 SHADOW
     对每个物体在地面投一个软阴影椭圆（按高度/距离衰减）
     比真实阴影贴图便宜 100 倍，但视觉收益极大
     ============================================================ */
  const SHADOW = {
    // 在 groundY 平面画软阴影；obj={x,z,size,y}
    blob(ctx, cam, obj, groundY, opt = {}) {
      const p = cam.project(V(obj.x, groundY + 0.5, obj.z));
      if (!p) return;
      const hgt = Math.max(0, obj.y - groundY);
      const k = clamp(1 - hgt / (opt.fade || 900), 0.08, 1);
      const r = obj.size * p.scale * (opt.spread || 0.85) * (1 + hgt / 1400);
      const a = (opt.alpha === undefined ? 0.55 : opt.alpha) * k;
      if (a < 0.01) return;
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
      g.addColorStop(0, `rgba(0,0,0,${a})`);
      g.addColorStop(0.55, `rgba(0,0,0,${a * 0.45})`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.scale(1, opt.squash || 0.34);          // 透视压扁
      ctx.translate(-p.x, -p.y);
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU); ctx.fill();
      ctx.restore();
    },
    // 接触阴影：物体底部贴地的一圈暗边，让物体"站得住"
    contact(ctx, cam, obj, groundY, opt = {}) {
      const p = cam.project(V(obj.x, groundY + 1, obj.z));
      if (!p) return;
      const r = obj.size * p.scale * 0.55;
      ctx.save();
      ctx.translate(p.x, p.y); ctx.scale(1, 0.25); ctx.translate(-p.x, -p.y);
      const g = ctx.createRadialGradient(p.x, p.y, r * 0.2, p.x, p.y, r);
      g.addColorStop(0, `rgba(0,0,0,${opt.alpha || 0.7})`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU); ctx.fill();
      ctx.restore();
    },
    // 光束体积感：从光源到地面的锥形光柱（透明渐变）
    beam(ctx, cam, from, to, width, color, alpha = 0.12) {
      const a = cam.project(from), b = cam.project(to);
      if (!a || !b) return;
      const w = width * ((a.scale + b.scale) / 2) * 0.5;
      const g = ctx.createLinearGradient(a.x, a.y, b.x, b.y);
      g.addColorStop(0, rgba(color, alpha));
      g.addColorStop(1, rgba(color, 0));
      ctx.save();
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(a.x - w * 0.25, a.y);
      ctx.lineTo(a.x + w * 0.25, a.y);
      ctx.lineTo(b.x + w, b.y);
      ctx.lineTo(b.x - w, b.y);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    },
  };

  /* ============================================================
     3. 粒子系统 PARTICLE
     预计算粒子池（确定性），逐帧只算位置
     ============================================================ */
  const PARTICLE = {
    // 生成粒子池
    make(n, opt = {}) {
      const rnd = mulberry32(opt.seed || 77);
      const out = [];
      for (let i = 0; i < n; i++) {
        out.push({
          x: (rnd() - 0.5) * (opt.spreadX || 1400),
          y: (rnd() - 0.5) * (opt.spreadY || 800),
          z: rnd() * (opt.depth || 1800) - 600,
          vx: (rnd() - 0.5) * (opt.speed || 30),
          vy: 8 + rnd() * (opt.speed || 30),
          vz: (rnd() - 0.5) * (opt.speed || 20),
          r: (opt.size || 2) * (0.4 + rnd() * 1.6),
          ph: rnd() * TAU,
          life: 0.4 + rnd() * 0.6,
        });
      }
      return out;
    },
    // 飘升粒子：灰尘/星屑/能量流
    drift(ctx, cam, pool, t, opt = {}) {
      const color = opt.color || "#a8c8e8";
      const alpha = opt.alpha === undefined ? 0.7 : opt.alpha;
      const wrapY = (opt.wrapY || 900);
      for (const p of pool) {
        const y = ((p.y + p.vy * t + opt.baseY * 0 - p.ph * 30) % wrapY);
        const pos = V(
          p.x + Math.sin(t * 0.6 + p.ph) * (opt.sway || 18) + p.vx * t * 0.5,
          y - wrapY * 0.35 + Math.cos(t * 0.4 + p.ph) * 10,
          p.z + p.vz * t * 0.4
        );
        const pr = cam.project(pos);
        if (!pr) continue;
        const a = alpha * pr.alpha * (0.35 + 0.65 * Math.abs(Math.sin(t * 0.9 + p.ph)));
        if (a < 0.02) continue;
        const rr = Math.max(0.35, p.r * pr.scale * 2.2);
        ctx.globalAlpha = a;
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.arc(pr.x, pr.y, rr, 0, TAU); ctx.fill();
      }
      ctx.globalAlpha = 1;
    },
    // 爆发粒子：在 at 秒从中心炸开（配踩点）
    burst(ctx, cam, origin, t, at, opt = {}) {
      const age = t - at;
      if (age < 0 || age > (opt.dur || 1.4)) return;
      const rnd = mulberry32(opt.seed || 9);
      const n = opt.n || 90;
      const k = opt.speed || 900;
      const ease = 1 - Math.pow(1 - age / (opt.dur || 1.4), 2.2);
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      for (let i = 0; i < n; i++) {
        const a = rnd() * TAU, ph = Math.acos(rnd() * 2 - 1);
        const sp = 0.35 + rnd() * 0.65;
        const d = ease * k * sp;
        const pos = V(
          origin.x + Math.sin(ph) * Math.cos(a) * d,
          origin.y + Math.cos(ph) * d,
          origin.z + Math.sin(ph) * Math.sin(a) * d
        );
        const pr = cam.project(pos);
        if (!pr) continue;
        const life = 1 - age / (opt.dur || 1.4);
        ctx.globalAlpha = life * 0.9;
        ctx.fillStyle = i % 3 === 0 ? (opt.color2 || "#ffffff") : (opt.color || "#5be2a1");
        const r = Math.max(0.5, (2.6 + rnd() * 2) * pr.scale * 1.6 * life);
        ctx.beginPath(); ctx.arc(pr.x, pr.y, r, 0, TAU); ctx.fill();
      }
      ctx.restore();
    },
    // 粒子连线网络：距离阈值内连线（科技感标配）
    network(ctx, cam, pool, t, opt = {}) {
      const pts = [];
      for (const p of pool) {
        const pr = cam.project(V(p.x + Math.sin(t * 0.4 + p.ph) * 20,
          p.y + Math.cos(t * 0.5 + p.ph) * 16, p.z));
        if (pr) pts.push(pr);
      }
      const maxD = opt.maxD || 170;
      ctx.save();
      ctx.strokeStyle = rgba(opt.color || "#5be2a1", opt.lineAlpha || 0.16);
      ctx.lineWidth = opt.lineWidth || 0.8;
      for (let i = 0; i < pts.length; i++) {
        for (let j = i + 1; j < pts.length; j++) {
          const dx = pts[i].x - pts[j].x, dy = pts[i].y - pts[j].y;
          const d2 = dx * dx + dy * dy;
          if (d2 > maxD * maxD) continue;
          ctx.globalAlpha = (1 - Math.sqrt(d2) / maxD) * (opt.lineAlpha || 0.16) * 4;
          ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y); ctx.stroke();
        }
      }
      ctx.restore();
      // 节点
      for (const pr of pts) {
        ctx.globalAlpha = 0.75 * pr.alpha;
        ctx.fillStyle = opt.color || "#5be2a1";
        ctx.beginPath(); ctx.arc(pr.x, pr.y, Math.max(0.8, 1.6 * pr.scale * 2), 0, TAU); ctx.fill();
      }
      ctx.globalAlpha = 1;
    },
  };

  /* ============================================================
     4. 流体/渐变背景 BG
     用 fbm 噪声画缓慢流动的暗色流体，比纯渐变高级得多
     ============================================================ */
  const BG = {
    // 流体噪声背景（按小网格渲染再放大，性能友好）
    fluid(ctx, w, h, t, opt = {}) {
      const cell = opt.cell || 40;
      const gw = Math.ceil(w / cell), gh = Math.ceil(h / cell);
      const f = fbm2(opt.seed || 3);
      const c1 = opt.c1 || "#0b1622", c2 = opt.c2 || "#152535", c3 = opt.c3 || "#050709";
      // 底色
      ctx.fillStyle = c3; ctx.fillRect(0, 0, w, h);
      for (let y = 0; y < gh; y++) {
        for (let x = 0; x < gw; x++) {
          const nx = x / gw * (opt.scale || 3.2), ny = y / gh * (opt.scale || 2.0);
          const v = f(nx + t * (opt.speed || 0.08), ny + t * (opt.speed2 || 0.05));
          const k = clamp((v + 0.6) / 1.4);
          const col = k > 0.5 ? mixHex(c2, c1, (k - 0.5) * 2) : mixHex(c3, c2, k * 2);
          ctx.fillStyle = col;
          // 边缘重叠 1px 防止缝隙
          ctx.fillRect(x * cell - 0.5, y * cell - 0.5, cell + 1, cell + 1);
        }
      }
      // 顶部主光源辉光
      if (opt.glow) {
        const g = ctx.createRadialGradient(w * (opt.glowX || 0.28), h * (opt.glowY || 0.18), 0,
          w * (opt.glowX || 0.28), h * (opt.glowY || 0.18), w * 0.55);
        g.addColorStop(0, rgba(opt.glow, opt.glowA || 0.16));
        g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      }
    },
    // 径向聚光（摄影棚感）
    spot(ctx, w, h, x, y, r, color, alpha) {
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, rgba(color, alpha));
      g.addColorStop(0.45, rgba(color, alpha * 0.35));
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    },
    // 细密网格（科技底板）
    techGrid(ctx, w, h, t, opt = {}) {
      const s = opt.size || 48, a = opt.alpha || 0.06;
      ctx.save();
      ctx.strokeStyle = rgba(opt.color || "#5b8fc9", a);
      ctx.lineWidth = 1;
      const off = (t * (opt.speed || 12)) % s;
      for (let x = -off; x < w + s; x += s) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
      }
      for (let y = -off; y < h + s; y += s) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
      }
      ctx.restore();
    },
  };

  function mixHex(a, b, k) {
    const p = h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
    const A = p(a), B = p(b);
    const h = v => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, "0");
    return `#${h(lerp(A[0], B[0], k))}${h(lerp(A[1], B[1], k))}${h(lerp(A[2], B[2], k))}`;
  }

  /* ============================================================
     5. 摄影机镜头效果 LENS
     ============================================================ */
  const LENS = {
    // 镜头光晕：亮点处的横向光条
    flare(ctx, x, y, r, color, alpha = 0.5, t = 0) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      // 核心
      const g = ctx.createRadialGradient(x, y, 0, x, y, r * 0.28);
      g.addColorStop(0, rgba(color, alpha));
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 0.28, 0, TAU); ctx.fill();
      // 横向光条
      const gx = ctx.createLinearGradient(x - r * 1.6, y, x + r * 1.6, y);
      gx.addColorStop(0, "rgba(0,0,0,0)");
      gx.addColorStop(0.5, rgba(color, alpha * 0.55));
      gx.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = gx; ctx.fillRect(x - r * 1.6, y - 1.2, r * 3.2, 2.4);
      // 光环
      ctx.strokeStyle = rgba(color, alpha * 0.28);
      ctx.lineWidth = 1.5;
      for (let i = 1; i <= 2; i++) {
        ctx.beginPath();
        ctx.arc(x + r * 0.55 * i, y + r * 0.12 * i * Math.sin(t + i), r * 0.09 * i, 0, TAU);
        ctx.stroke();
      }
      ctx.restore();
    },
    // 景深：按对焦距离做可分离模糊（radial falloff 的近似）
    dof(ctx, canvas, w, h, focusZ, opt = {}) {
      if (!focusZ) return;
      const k = opt.strength || 0.35;
      ctx.save();
      ctx.globalAlpha = k;
      const s = 1 + k * 0.006;
      ctx.drawImage(canvas, -w * (s - 1) / 2, -h * (s - 1) / 2, w * s, h * s);
      ctx.restore();
    },
    // 遮幅 + 画面轻微弯曲（CRT/镜头畸变）
    barrel(ctx, canvas, w, h, amount = 0.012) {
      if (amount <= 0) return;
      ctx.save();
      ctx.clearRect(0, 0, w, h);
      const rows = 60;
      const rowH = h / rows;
      for (let i = 0; i < rows; i++) {
        const v = (i / rows - 0.5) * 2;
        const shrink = 1 + amount * (v * v - 0.35);
        const sw = w * shrink;
        ctx.drawImage(canvas, 0, i * rowH, w, rowH,
          (w - sw) / 2, i * rowH, sw, rowH);
      }
      ctx.restore();
    },
    // 色散：RGB 三通道微分离，冲击/甩镜时用
    dispersion(ctx, canvas, w, h, amount, alpha = 0.55) {
      if (!amount) return;
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = alpha * 0.5;
      ctx.drawImage(canvas, -amount, 0);
      ctx.drawImage(canvas, amount, 0);
      ctx.restore();
    },
  };

  /* ============================================================
     6. 文字增强 LOOK（阴影/描边/渐变字/光标）
     ============================================================ */
  const LOOK = {
    gradientText(ctx, text, x, y, font, c1, c2, opt = {}) {
      ctx.save();
      ctx.font = font;
      ctx.textAlign = opt.align || "left";
      const m = ctx.measureText(text);
      const g = ctx.createLinearGradient(x, y - 40, x, y + 8);
      g.addColorStop(0, c1); g.addColorStop(1, c2);
      if (opt.shadow) { ctx.shadowColor = opt.shadow; ctx.shadowBlur = opt.shadowBlur || 24; }
      ctx.fillStyle = g;
      ctx.fillText(text, x, y);
      ctx.restore();
      return m.width;
    },
    // 逐字描边高亮（关键词强调）
    keyword(ctx, text, x, y, t, at, opt = {}) {
      const p = OV.E.inOutQuint(seg(t, at, at + (opt.dur || 0.6)));
      ctx.save();
      ctx.font = opt.font || "700 44px 'Noto Sans CJK SC', system-ui";
      const wd = ctx.measureText(text).width;
      const hgt = (opt.h || 56);
      ctx.fillStyle = rgba(opt.color || "#5be2a1", 0.18);
      ctx.fillRect(x - 8, y - hgt + 10, (wd + 16) * p, hgt);
      ctx.fillStyle = opt.textColor || "#eef3fa";
      ctx.fillText(text, x, y);
      ctx.restore();
    },
    // 打字机
    typewriter(ctx, text, x, y, t, at, opt = {}) {
      const cps = opt.cps || 14;
      const n = Math.max(0, Math.min(text.length, Math.floor((t - at) * cps)));
      if (t < at) return 0;
      ctx.save();
      ctx.font = opt.font || "400 28px 'Noto Sans CJK SC', system-ui";
      ctx.fillStyle = opt.color || "#eef3fa";
      ctx.textAlign = opt.align || "left";
      const shown = [...text].slice(0, n).join("");
      ctx.fillText(shown, x, y);
      if (opt.caret && Math.floor(t * 2) % 2 === 0 && n < text.length) {
        const wd = ctx.measureText(shown).width;
        ctx.fillStyle = opt.caretColor || "#5be2a1";
        ctx.fillRect(x + (opt.align === "center" ? -wd / 2 : 0) + wd + 4, y - 24, 2, 28);
      }
      ctx.restore();
      return n;
    },
    // 霓虹灯管字：多层描边辉光 + 闪烁
    neon(ctx, text, x, y, t, opt = {}) {
      const flick = opt.flicker ? (Math.sin(t * 31) > 0.92 ? 0.4 : 1) : 1;
      ctx.save();
      ctx.font = opt.font || "800 72px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = opt.align || "left";
      ctx.textBaseline = opt.baseline || "alphabetic";
      const core = opt.color || "#ff3ec8";
      ctx.shadowColor = core;
      ctx.shadowBlur = 26 * flick;
      ctx.fillStyle = "rgba(255,255,255,0.95)";
      ctx.fillText(text, x, y);
      ctx.shadowBlur = 44 * flick;
      ctx.fillStyle = core;
      ctx.globalAlpha = 0.75 * flick;
      ctx.fillText(text, x, y);
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
      ctx.restore();
      return flick;
    },
    // 空心描边字
    outlineText(ctx, text, x, y, opt = {}) {
      ctx.save();
      ctx.font = opt.font || "900 110px 'Noto Sans CJK SC', system-ui";
      ctx.textAlign = opt.align || "left";
      ctx.lineWidth = opt.width || 3;
      ctx.strokeStyle = opt.color || "#ffffff";
      if (opt.glow) { ctx.shadowColor = opt.color; ctx.shadowBlur = opt.glow; }
      ctx.strokeText(text, x, y);
      if (opt.fill) { ctx.fillStyle = opt.fill; ctx.fillText(text, x, y); }
      ctx.restore();
      return 1;
    },
    // 跑马灯：横向匀速滚动（t 驱动，可无缝循环）
    marquee(ctx, text, x, y, t, opt = {}) {
      ctx.save();
      ctx.font = opt.font || "600 34px 'Noto Sans CJK SC', system-ui";
      ctx.fillStyle = opt.color || "#ffffff";
      ctx.textAlign = "left";
      const full = text + (opt.sep || "   ◆   ");
      const w = ctx.measureText(full).width;
      const speed = opt.speed || 120;
      let off = (t * speed) % w;
      if (off > 0) off -= w;
      for (let i = 0; off + i * w < x + (opt.clipW || 4000); i++) {
        if (off + i * w + w < x) continue;
        ctx.fillText(full, x + off + i * w, y);
      }
      ctx.restore();
      return w;
    },
    /* ===== 翻倍 6 文字特效（6→12） ===== */
    chromeText(ctx, text, x, y, font, opt = {}) {      // 金属字：多段银渐变 + 深描边
      ctx.save();
      ctx.font = font; ctx.textAlign = opt.align || "left"; ctx.textBaseline = "alphabetic";
      const g = ctx.createLinearGradient(0, y - 50, 0, y + 10);
      g.addColorStop(0, "#f8fbff"); g.addColorStop(0.42, "#b9c6d6");
      g.addColorStop(0.5, "#5f6f82"); g.addColorStop(0.56, "#e8f0f8");
      g.addColorStop(0.72, "#8fa0b3"); g.addColorStop(1, "#eef4fa");
      ctx.lineWidth = opt.stroke || 3; ctx.strokeStyle = "rgba(20,26,36,0.85)";
      ctx.strokeText(text, x, y);
      ctx.fillStyle = g; ctx.fillText(text, x, y);
      ctx.restore();
      return ctx.measureText(text).width;
    },
    glassText(ctx, text, x, y, font, opt = {}) {       // 玻璃字：半透填充 + 内描边高光
      ctx.save();
      ctx.font = font; ctx.textAlign = opt.align || "left"; ctx.textBaseline = "alphabetic";
      ctx.fillStyle = "rgba(255,255,255,0.16)";
      ctx.fillText(text, x, y);
      ctx.lineWidth = 1.6; ctx.strokeStyle = "rgba(255,255,255,0.85)";
      ctx.strokeText(text, x, y);
      ctx.save();
      ctx.clip();
      const g = ctx.createLinearGradient(0, y - 44, 0, y);
      g.addColorStop(0, "rgba(255,255,255,0.5)"); g.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = g;
      ctx.fillRect(x - 200, y - 50, 800, 60);
      ctx.restore();
      ctx.restore();
      return ctx.measureText(text).width;
    },
    fireText(ctx, text, x, y, font, t, opt = {}) {     // 火焰字：暖渐变 + 摇曳辉光
      const f = 0.85 + 0.15 * Math.sin(t * 12) * Math.sin(t * 5.3 + 1);
      ctx.save();
      ctx.font = font; ctx.textAlign = opt.align || "left"; ctx.textBaseline = "alphabetic";
      const g = ctx.createLinearGradient(0, y - 46, 0, y + 12);
      g.addColorStop(0, "#fff6c8"); g.addColorStop(0.35, "#ffb43c");
      g.addColorStop(0.75, "#f2501b"); g.addColorStop(1, "#a81208");
      ctx.fillStyle = g;
      ctx.shadowColor = `rgba(255,110,30,${0.8 * f})`; ctx.shadowBlur = 30 * f;
      ctx.fillText(text, x, y + Math.sin(t * 9) * 1.2);
      ctx.restore();
      return ctx.measureText(text).width;
    },
    iceText(ctx, text, x, y, font, opt = {}) {         // 冰晶字：冷青 + 白霜边 + 晶粒
      ctx.save();
      ctx.font = font; ctx.textAlign = opt.align || "left"; ctx.textBaseline = "alphabetic";
      const g = ctx.createLinearGradient(0, y - 46, 0, y + 8);
      g.addColorStop(0, "#f2fdff"); g.addColorStop(0.5, "#9fd9ee"); g.addColorStop(1, "#4d8fb5");
      ctx.lineWidth = 2; ctx.strokeStyle = "rgba(240,252,255,0.9)";
      ctx.strokeText(text, x, y);
      ctx.fillStyle = g; ctx.fillText(text, x, y);
      const rnd = mulberry32(17);
      ctx.fillStyle = "rgba(255,255,255,0.75)";
      const w = ctx.measureText(text).width;
      for (let i = 0; i < 10; i++) ctx.fillRect(x + rnd() * w, y - 44 + rnd() * 46, 1.4, 1.4);
      ctx.restore();
      return w;
    },
    rainbowFlow(ctx, text, x, y, font, t, opt = {}) {  // 彩虹流：色相循环渐变
      ctx.save();
      ctx.font = font; ctx.textAlign = opt.align || "left"; ctx.textBaseline = "alphabetic";
      const w = ctx.measureText(text).width;
      const g = ctx.createLinearGradient(x, y, x + w, y);
      for (let i = 0; i <= 6; i++) {
        g.addColorStop(i / 6, `hsl(${(t * 90 + i * 51) % 360},85%,62%)`);
      }
      ctx.fillStyle = g;
      ctx.shadowColor = `hsla(${(t * 90) % 360},90%,60%,0.6)`; ctx.shadowBlur = 20;
      ctx.fillText(text, x, y);
      ctx.restore();
      return w;
    },
    stroke3D(ctx, text, x, y, font, opt = {}) {        // 3D 凸出字：层叠侧壁 + 顶面
      const depth = opt.depth || 10, col = opt.color || "#ffd9a0", side = opt.side || "#8a4a1c";
      ctx.save();
      ctx.font = font; ctx.textAlign = opt.align || "left"; ctx.textBaseline = "alphabetic";
      ctx.fillStyle = side;
      for (let i = depth; i >= 1; i--) ctx.fillText(text, x + i * 0.8, y + i * 0.8);
      ctx.fillStyle = col;
      if (opt.glow) { ctx.shadowColor = opt.glow; ctx.shadowBlur = 18; }
      ctx.fillText(text, x, y);
      ctx.restore();
      return ctx.measureText(text).width;
    },
  };

  /* ============================================================
     7. 天气系统 WEATHER（t 驱动，确定性层）
     ============================================================ */
  const WEATHER = {
    rain(ctx, w, h, t, n = 110, opt = {}) {            // 雨：风斜雨丝 + 落地溅点
      const rnd = mulberry32(opt.seed || 11);
      const wind = opt.wind === undefined ? -0.22 : opt.wind;
      ctx.save(); ctx.globalCompositeOperation = "screen";
      ctx.lineWidth = opt.width || 1.3;
      for (let i = 0; i < n; i++) {
        const x0 = rnd() * (w + 200) - 100, y0 = rnd() * h, len = 16 + rnd() * 30, sp = 950 + rnd() * 620;
        const y = (y0 + t * sp) % (h + 60) - 30;
        const x = x0 + wind * (y - y0);
        const a = 0.25 + rnd() * 0.4;
        ctx.strokeStyle = `rgba(175,200,235,${a})`;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + wind * len, y + len); ctx.stroke();
        if (y > h - 24 && rnd() > 0.6) {                // 落地溅点
          ctx.fillStyle = `rgba(200,220,240,${a})`;
          ctx.beginPath(); ctx.arc(x, h - 6, 1.6, 0, TAU); ctx.fill();
        }
      }
      ctx.restore();
    },
    snow(ctx, w, h, t, n = 90, opt = {}) {             // 雪：摇摆飘落 + 大小景深
      const rnd = mulberry32(opt.seed || 23);
      ctx.save();
      for (let i = 0; i < n; i++) {
        const x0 = rnd() * w, y0 = rnd() * h, r = (1 + rnd() * 2.8) * (opt.scale || 1);
        const sp = 36 + rnd() * 78, ph = rnd() * TAU, sway = 18 + rnd() * 26;
        const y = (y0 + t * sp) % (h + 24) - 12;
        const x = x0 + Math.sin(t * 0.9 + ph) * sway;
        ctx.globalAlpha = 0.3 + rnd() * 0.55;
        ctx.fillStyle = "#ffffff";
        ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      }
      ctx.restore();
    },
    dustMotes(ctx, w, h, t, n = 46, opt = {}) {        // 光尘：上浮闪烁微粒
      const rnd = mulberry32(opt.seed || 31);
      ctx.save(); ctx.globalCompositeOperation = "screen";
      for (let i = 0; i < n; i++) {
        const x0 = rnd() * w, y0 = rnd() * h, r = 0.9 + rnd() * 2.4;
        const sp = 7 + rnd() * 24, ph = rnd() * TAU;
        const y = h - ((y0 + t * sp) % (h + 24));
        const x = x0 + Math.sin(t * 0.55 + ph) * 34;
        const tw = 0.5 + 0.5 * Math.sin(t * 2.4 + i);
        const g = ctx.createRadialGradient(x, y, 0, x, y, r * 3.4);
        g.addColorStop(0, `rgba(255,242,214,${0.5 * tw})`);
        g.addColorStop(1, "rgba(255,242,214,0)");
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, y, r * 3.4, 0, TAU); ctx.fill();
      }
      ctx.restore();
    },
    fogBank(ctx, w, h, t, opt = {}) {                  // 雾团：低频漂移雾块
      const rnd = mulberry32(opt.seed || 41);
      const n = opt.banks || 3;
      ctx.save(); ctx.globalCompositeOperation = "screen";
      for (let i = 0; i < n; i++) {
        const cx = rnd() * w, cy = h * (0.35 + rnd() * 0.5), rw = 220 + rnd() * 260, rh = 60 + rnd() * 70;
        const drift = Math.sin(t * 0.18 + i * 2.1) * 90;
        const x = ((cx + drift) % (w + rw * 2)) - rw;
        const g = ctx.createRadialGradient(x, cy, 0, x, cy, rw);
        g.addColorStop(0, `rgba(205,214,224,${opt.alpha || 0.13})`);
        g.addColorStop(1, "rgba(205,214,224,0)");
        ctx.fillStyle = g;
        ctx.save(); ctx.translate(x, cy); ctx.scale(1, rh / rw);
        ctx.beginPath(); ctx.arc(0, 0, rw, 0, TAU); ctx.fill();
        ctx.restore();
      }
      ctx.restore();
    },
    storm(ctx, w, h, t, opt = {}) {                    // 雷暴：雨 + 周期性闪电
      this.rain(ctx, w, h, t, opt.rain || 150, { wind: opt.wind === undefined ? -0.5 : opt.wind });
      const period = opt.period || 6.5;
      const ph = t % period;
      if (ph < 0.12 || (ph > 0.3 && ph < 0.4)) {
        const a = ph < 0.12 ? 1 - ph / 0.12 : 1 - (ph - 0.3) / 0.1;
        ctx.save();
        ctx.fillStyle = `rgba(220,230,255,${0.5 * a})`;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
      }
    },
  };

  /* ============================================================
     8. 景深 DOF（离屏模糊 + 焦点控制）
     ============================================================ */
  const DOF = {
    focusBlur(ctx, w, h, amount = 2.5, hole = 0.34) {  // 焦点圆清晰 + 外围渐进模糊
      if (amount < 0.5) return;
      const off = document.createElement("canvas");
      off.width = Math.max(2, w >> 1); off.height = Math.max(2, h >> 1);
      const oc = off.getContext("2d");
      oc.drawImage(ctx.canvas, 0, 0, off.width, off.height);
      oc.filter = `blur(${amount}px)`;
      oc.drawImage(off, 0, 0); oc.filter = "none";
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, w, h);
      ctx.arc(w / 2, h / 2, Math.min(w, h) * hole / 2, 0, TAU, true);
      ctx.clip("evenodd");
      ctx.drawImage(off, 0, 0, off.width, off.height, 0, 0, w, h);
      ctx.restore();
    },
    tiltShift(ctx, w, h, band = 0.3, amount = 2.5) {   // 移轴微缩：中央清晰带 + 上下模糊
      if (amount < 0.5) return;
      const off = document.createElement("canvas");
      off.width = Math.max(2, w >> 1); off.height = Math.max(2, h >> 1);
      const oc = off.getContext("2d");
      oc.drawImage(ctx.canvas, 0, 0, off.width, off.height);
      oc.filter = `blur(${amount}px)`;
      oc.drawImage(off, 0, 0); oc.filter = "none";
      const y0 = h * (0.5 - band / 2), y1 = h * (0.5 + band / 2);
      ctx.save();
      ctx.drawImage(off, 0, 0, off.width, off.height, 0, 0, w, y0);            // 上糊
      ctx.drawImage(off, 0, 0, off.width, off.height, 0, y1, w, h - y1);       // 下糊
      ctx.restore();
    },
    bokehField(ctx, w, h, t, opt = {}) {               // 焦外光斑场：大柔焦圆盘
      const rnd = mulberry32(opt.seed || 61);
      const n = opt.n || 9;
      ctx.save(); ctx.globalCompositeOperation = "screen";
      for (let i = 0; i < n; i++) {
        const x = rnd() * w, y = rnd() * h, r = 26 + rnd() * 58, ph = rnd() * TAU;
        const px = x + Math.sin(t * 0.22 + ph) * 44;
        const py = (y + t * 11) % (h + 130) - 65;
        const hue = 18 + rnd() * 54;
        const g = ctx.createRadialGradient(px, py, r * 0.55, px, py, r);
        g.addColorStop(0, `hsla(${hue},72%,72%,0.12)`);
        g.addColorStop(1, `hsla(${hue},72%,72%,0)`);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(px, py, r, 0, TAU); ctx.fill();
      }
      ctx.restore();
    },
  };

  global.OVX = { MAT, SHADOW, PARTICLE, BG, LENS, LOOK, WEATHER, DOF, LIGHTS, mixHex };
  if (typeof module !== "undefined") module.exports = global.OVX;
})(typeof window !== "undefined" ? window : globalThis);
