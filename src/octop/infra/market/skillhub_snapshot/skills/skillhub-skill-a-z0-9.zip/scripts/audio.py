#!/usr/bin/env python3
"""
opus-video / audio.py
程序化配乐合成器：无外部素材、无网络，按 BPM 生成鼓组/贝斯/铺底/音效，
输出 WAV，再由 ffmpeg 封装进视频。

用法:
  python3 audio.py out.wav --dur 12 --bpm 120 --key A --mood tech
  python3 audio.py out.wav --dur 12 --bpm 120 --key A --mood epic --hits 2.0,5.0,8.5

设计要点:
  - 所有振荡器自己写，不依赖 numpy 之外的东西
  - 鼓组是"合成鼓"：正弦扫频 kick、噪声 snare、高通 hat —— 听感干净不廉价
  - 铺底用锯齿波 + 轻微 detune + 慢起慢收，模仿 analog pad
  - hits 参数在指定秒数插入"冲击音"，与画面甩镜/转场对齐
"""
import argparse
import struct
import sys
import wave

import numpy as np

SR = 44100
TAU = 2 * np.pi


# ---------- 基础工具 ----------
def midi_to_freq(m):
    return 440.0 * (2 ** ((m - 69) / 12))


NOTE_MAP = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5, "F#": 6,
            "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}


def note_freq(name):
    """'A3' -> 220Hz"""
    pitch = name[:-1]
    octave = int(name[-1])
    return midi_to_freq(12 * (octave + 1) + NOTE_MAP[pitch])


def env(n, a=0.005, d=0.2, s=0.0, r=0.05):
    """简单 ADSR 包络"""
    t = np.arange(n) / SR
    total = n / SR
    e = np.zeros(n)
    ai = int(a * SR)
    di = int(d * SR)
    ri = int(r * SR)
    si = max(0, n - ai - di - ri)
    e[:ai] = np.linspace(0, 1, ai) if ai else []
    if di:
        e[ai:ai + di] = np.linspace(1, s, di)
    e[ai + di:ai + di + si] = s
    if ri:
        e[ai + di + si:] = np.linspace(s, 0, n - (ai + di + si))
    return e[:n]


def lowpass(x, cutoff, order=2):
    """一阶/二阶 RC 低通（频域实现，简单可靠）"""
    n = len(x)
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(n, 1 / SR)
    H = 1 / np.sqrt(1 + (f / max(cutoff, 20)) ** (2 * order))
    return np.fft.irfft(X * H, n)


def highpass(x, cutoff, order=2):
    n = len(x)
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(n, 1 / SR)
    H = 1 / np.sqrt(1 + (max(cutoff, 20) / np.maximum(f, 1e-9)) ** (2 * order))
    return np.fft.irfft(X * H, n)


def soft_clip(x, drive=1.0):
    return np.tanh(x * drive) / np.tanh(drive)


# ---------- 乐器 ----------
def kick(dur=0.45, f0=120, f1=42, amp=0.9):
    n = int(dur * SR)
    t = np.arange(n) / SR
    f = f1 + (f0 - f1) * np.exp(-t * 28)
    phase = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(phase) * np.exp(-t * 6.5)
    click = np.random.default_rng(1).normal(0, 1, n) * np.exp(-t * 220) * 0.25
    return soft_clip((body + click) * amp, 1.4)


def snare(dur=0.25, amp=0.45, seed=2):
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    noise = rng.normal(0, 1, n)
    noise = highpass(noise, 1400) * np.exp(-t * 22)
    tone = np.sin(2 * np.pi * 185 * t) * np.exp(-t * 30) * 0.6
    return soft_clip((noise + tone) * amp, 1.2)


def hat(dur=0.08, amp=0.22, seed=3):
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    noise = highpass(rng.normal(0, 1, n), 7000, 3)
    return noise * np.exp(-t * 55) * amp


def sub_bass(freq, dur, amp=0.5):
    n = int(dur * SR)
    t = np.arange(n) / SR
    wave = np.sin(2 * np.pi * freq * t) + 0.25 * np.sin(4 * np.pi * freq * t)
    return soft_clip(wave * amp * env(n, 0.01, 0.05, 0.75, 0.06), 1.1)


def pad(notes, dur, amp=0.22, detune=0.004, cutoff=1800):
    """多声部锯齿铺底，带 detune 的模拟温暖感"""
    n = int(dur * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for name in notes:
        f = note_freq(name)
        for k in (-1, 0, 1):
            ff = f * (1 + detune * k)
            # 简易带限锯齿：叠加前 6 次谐波
            for h in range(1, 7):
                out += np.sin(2 * np.pi * ff * h * t + k * 0.7) / (h * 1.6)
    out = lowpass(out / max(len(notes), 1), cutoff)
    e = env(n, a=dur * 0.35, d=dur * 0.1, s=0.85, r=dur * 0.45)
    return out * e * amp


def pluck(freq, dur=0.35, amp=0.3):
    n = int(dur * SR)
    t = np.arange(n) / SR
    w = np.sin(2 * np.pi * freq * t) + 0.4 * np.sin(2 * np.pi * freq * 2 * t) + 0.2 * np.sin(2 * np.pi * freq * 3 * t)
    return w * np.exp(-t * 9) * amp


def whoosh(dur=0.7, amp=0.4, seed=5):
    """甩镜/转场风声：噪声带通 + 包络"""
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    x = rng.normal(0, 1, n)
    x = lowpass(highpass(x, 400), 3500)
    e = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 2
    return x * e * amp


def impact(dur=0.9, amp=0.65):
    """冲击音：低频 thud + 短促噪声"""
    n = int(dur * SR)
    t = np.arange(n) / SR
    boom = np.sin(2 * np.pi * (60 + 40 * np.exp(-t * 10)) * t) * np.exp(-t * 4.5)
    rng = np.random.default_rng(9)
    cr = lowpass(rng.normal(0, 1, n), 900) * np.exp(-t * 18) * 0.5
    return soft_clip((boom + cr) * amp, 1.3)


def riser(dur=2.0, amp=0.3, seed=11):
    """上升音：噪声 + 音高上扬，用于段落推进"""
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    x = rng.normal(0, 1, n)
    # 逐渐打开的滤波器：用分段重采样近似
    segs = 12
    y = np.zeros(n)
    for i in range(segs):
        a, b = int(i / segs * n), int((i + 1) / segs * n)
        y[a:b] = highpass(lowpass(x[a:b], 300 * (1 + i * 1.8)), 200 + i * 120)
    e = np.linspace(0, 1, n) ** 2
    return y * e * amp



def bell(freq, dur=0.8, amp=0.25):
    t = np.arange(int(dur * SR)) / SR
    y = (np.sin(TAU * freq * t) * 0.6 + np.sin(TAU * freq * 2.76 * t) * 0.25
         + np.sin(TAU * freq * 5.4 * t) * 0.1) * np.exp(-t * 5.5)
    return y * amp

def clap(dur=0.22, amp=0.4, seed=9):
    rng = np.random.default_rng(seed)
    t = np.arange(int(dur * SR)) / SR
    n = rng.standard_normal(len(t))
    y = np.zeros(len(t))
    for k, off in enumerate([0, 0.012, 0.024]):
        i0 = int(off * SR)
        e = np.exp(-np.arange(len(t) - i0) / SR * (28 - k * 6))
        y[i0:] += n[:len(t) - i0] * e * (0.8 - k * 0.15)
    return highpass(y, 1400) * amp

def tom(dur=0.3, amp=0.4, f0=220):
    t = np.arange(int(dur * SR)) / SR
    f = f0 * np.exp(-t * 9) + 60
    return np.sin(TAU * np.cumsum(f) / SR) * np.exp(-t * 8) * amp

def wind(dur=4.0, amp=0.10, seed=17):
    rng = np.random.default_rng(seed)
    n = rng.standard_normal(int(dur * SR))
    y = lowpass(n, 420)
    # 缓慢起伏的包络（环境风声）
    t = np.arange(len(y)) / SR
    env = 0.55 + 0.45 * np.sin(TAU * t * 0.11 + seed) * np.sin(TAU * t * 0.043)
    return y * env * amp * 6

def vinyl(dur=4.0, amp=0.05, seed=23):
    rng = np.random.default_rng(seed)
    n = rng.standard_normal(int(dur * SR))
    y = highpass(n, 2500)
    # 爆豆声（稀疏脉冲）
    pops = (rng.random(len(y)) < 0.0004).astype(float) * rng.standard_normal(len(y))
    return (y * 0.6 + pops * 2) * amp

def sparkle(freq=2093, dur=1.2, amp=0.16):
    t = np.arange(int(dur * SR)) / SR
    y = np.zeros(len(t))
    for k, f in enumerate([1, 1.5, 2, 2.5]):
        i0 = int(k * 0.09 * SR)
        if i0 >= len(t): break
        b = bell(freq * f, dur - k * 0.09, amp=0.6 - k * 0.12)
        y[i0:i0 + len(b)] += b[:len(t) - i0]
    return y * amp

def boom(dur=1.1, amp=0.7):
    t = np.arange(int(dur * SR)) / SR
    f = 70 * np.exp(-t * 4) + 28
    return np.sin(TAU * np.cumsum(f) / SR) * np.exp(-t * 3.2) * amp

def click(dur=0.03, amp=0.5, seed=31):
    rng = np.random.default_rng(seed)
    n = rng.standard_normal(int(dur * SR))
    return highpass(n, 3000) * np.exp(-np.arange(len(n)) / SR * 160) * amp

def shutter(dur=0.18, amp=0.45):
    y = np.zeros(int(dur * SR))
    c1 = click(0.02, amp, 1)
    c2 = click(0.03, amp * 0.8, 2)
    y[:len(c1)] += c1
    i2 = int(0.09 * SR)
    y[i2:i2 + len(c2)] += c2[:len(y) - i2]
    return y

def heartbeat(dur=1.1, amp=0.6):
    y = np.zeros(int(dur * SR))
    b1 = boom(0.25, amp)
    b2 = boom(0.22, amp * 0.7)
    y[:len(b1)] += b1
    i2 = int(0.34 * SR)
    y[i2:i2 + len(b2)] += b2[:len(y) - i2]
    return y


# ---------- 翻倍音效库 v2（11 → 22）----------
def glass(dur=0.5, amp=0.4, seed=41):
    """玻璃碎裂：高频多共振峰 + 脆性噪声"""
    rng = np.random.default_rng(seed)
    t = np.arange(int(dur * SR)) / SR
    y = np.zeros(len(t))
    for k, f in enumerate([3200, 4700, 6100, 8300, 11200]):
        i0 = int(k * 0.02 * SR)
        b = bell(f, dur - k * 0.02, amp=0.5 - k * 0.08)
        y[i0:i0 + len(b)] += b[:len(t) - i0]
    shard = highpass(rng.standard_normal(len(t)), 5000) * np.exp(-t * 12) * 0.35
    return soft_clip((y + shard) * amp, 1.4)

def metal(dur=0.6, amp=0.4, seed=43):
    """金属撞击：非谐波泛音列 + 快速衰减"""
    t = np.arange(int(dur * SR)) / SR
    y = np.zeros(len(t))
    for k, r in enumerate([1.0, 1.51, 2.13, 2.97, 3.87]):
        y += np.sin(TAU * 520 * r * t) * np.exp(-t * (9 + k * 6)) / (1 + k * 0.9)
    rng = np.random.default_rng(seed)
    strike = bandpass(rng.standard_normal(len(t)), 2600, 4) * np.exp(-t * 40) * 0.4
    return soft_clip((y + strike) * amp, 1.3)

def wood(dur=0.16, amp=0.4, f0=640):
    """木鱼/木头：短促方波 + 木质共振"""
    t = np.arange(int(dur * SR)) / SR
    y = np.sign(np.sin(TAU * f0 * t)) * 0.5 + np.sin(TAU * f0 * 1.58 * t) * 0.3
    return lowpass(y * np.exp(-t * 45), 2400) * amp

def water(dur=0.45, amp=0.35, seed=47):
    """水滴/水声：上滑音 + 气泡噪声"""
    rng = np.random.default_rng(seed)
    t = np.arange(int(dur * SR)) / SR
    f = 500 + 900 * np.clip(t / 0.06, 0, 1) * np.exp(-t * 3)
    drop = np.sin(TAU * np.cumsum(f) / SR) * np.exp(-t * 7)
    bub = lowpass(rng.standard_normal(len(t)), 1800) * np.exp(-t * 14) * 0.25
    return soft_clip((drop + bub) * amp, 1.3)

def fire(dur=1.6, amp=0.22, seed=53):
    """火焰噼啪：低频咆哮 + 随机爆点"""
    rng = np.random.default_rng(seed)
    t = np.arange(int(dur * SR)) / SR
    roar = lowpass(rng.standard_normal(len(t)), 320)
    e = 0.6 + 0.4 * np.sin(TAU * t * 2.3 + seed) * np.sin(TAU * t * 0.7)
    crack = (rng.random(len(t)) < 0.004).astype(float) * highpass(rng.standard_normal(len(t)), 2600)
    return (roar * e * 0.8 + crack * 1.6) * amp

def thunder(dur=2.4, amp=0.5, seed=59):
    """远雷：低频轰鸣 + 缓慢滚动包络"""
    rng = np.random.default_rng(seed)
    t = np.arange(int(dur * SR)) / SR
    rumble = lowpass(rng.standard_normal(len(t)), 190)
    crack = bandpass(rng.standard_normal(len(t)), 900, 3) * np.exp(-((t - 0.15) ** 2) / 0.004) * 0.8
    e = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 1.5
    return (rumble + crack) * e * amp

def coin(dur=0.7, amp=0.35):
    """金币叮当：双音叠响"""
    t = np.arange(int(dur * SR)) / SR
    y = bell(1568, dur, amp=0.5) + bell(2093, dur, amp=0.35)
    c = click(0.02, 0.3, 7)
    y[:len(c)] += c
    return y * amp

def door(dur=0.9, amp=0.3, seed=61):
    """门吱呀：摩擦噪声 + 缓动"""
    rng = np.random.default_rng(seed)
    t = np.arange(int(dur * SR)) / SR
    n = rng.standard_normal(len(t))
    # 吱呀：噪声带通 + 音高微摆的频率抖动（用振幅调制近似）
    squeak = bandpass(n, 1400, 6) * (0.7 + 0.3 * np.sin(TAU * t * 2.2))
    e = np.clip(np.sin(TAU * t / dur * 1.5), 0, 1) ** 2
    thunk = lowpass(n, 300) * np.exp(-((t - dur * 0.92) ** 2) / 0.0008) * 0.9
    return (squeak * e * 0.5 + thunk) * amp

def ui(dur=0.14, amp=0.3, up=True):
    """UI 提示音：短正弦双音"""
    t = np.arange(int(dur * SR)) / SR
    f1, f2 = (660, 990) if up else (880, 660)
    y = np.zeros(len(t))
    h = int(0.055 * SR)
    y[:h] += np.sin(TAU * f1 * t[:h]) * np.exp(-t[:h] * 22)
    y[h:] += np.sin(TAU * f2 * t[h:]) * np.exp(-t[h:] * 18)
    return y * amp

def error(dur=0.35, amp=0.3):
    """错误提示：下行不谐双音"""
    t = np.arange(int(dur * SR)) / SR
    y = (np.sin(TAU * 330 * t) + np.sin(TAU * 247 * t + 0.4)) * np.exp(-t * 8)
    dip = np.sin(TAU * 300 * t * np.clip(1 - t / dur, 0.3, 1))
    return (y * 0.6 + dip * 0.4) * amp

def success(dur=0.5, amp=0.3):
    """成功提示：上行三音琶音"""
    t = np.arange(int(dur * SR)) / SR
    y = np.zeros(len(t))
    for k, f in enumerate([523, 659, 784]):
        i0 = int(k * 0.07 * SR)
        seg = t[:len(t) - i0]
        y[i0:] += np.sin(TAU * f * seg) * np.exp(-seg * 9) * (0.7 - k * 0.1)
    return y * amp

def bandpass(x, center, q=2.0):
    """简易带通：高通+低通组合近似"""
    lo = max(60, center / max(q, 0.5))
    hi = min(SR * 0.45, center * max(q, 0.5))
    return lowpass(highpass(x, lo), hi)

def marimba(freq, dur=0.5, amp=0.3):
    """马林巴：基音 + 四度泛音 + 快衰减"""
    t = np.arange(int(dur * SR)) / SR
    y = np.sin(TAU * freq * t) * 0.7 + np.sin(TAU * freq * 4 * t) * 0.2 * np.exp(-t * 14)
    return y * np.exp(-t * 8) * amp

def organ(freq, dur, amp=0.22):
    """风琴：多谐波持续音（additive）"""
    t = np.arange(int(dur * SR)) / SR
    y = np.zeros(len(t))
    for h, g in [(1, 1.0), (2, 0.5), (3, 0.32), (4, 0.22), (8, 0.1)]:
        y += np.sin(TAU * freq * h * t) * g
    return y / 2.1 * amp * env(len(t), a=dur * 0.08, d=dur * 0.1, s=0.8, r=dur * 0.3)


# ---------- SFX 翻倍 v2：22 个新音效 ----------
def laser(dur=0.35, amp=0.4):
    """激光：频率指数下滑 + 轻失真"""
    t = np.arange(int(dur * SR)) / SR
    f = 2400 * np.exp(-t * 9) + 180
    phase = TAU * np.cumsum(f) / SR
    return soft_clip(np.sin(phase) * np.exp(-t * 5) * amp, 1.4)


def zap(dur=0.22, amp=0.4, seed=7):
    """电弧：带通噪声 + 幅度方波抖动"""
    t = np.arange(int(dur * SR)) / SR
    rng = np.random.default_rng(seed)
    n = rng.normal(0, 1, len(t))
    y = bandpass(n, 3000, 6) * (0.45 + 0.55 * np.sign(np.sin(TAU * 130 * t)))
    return y * np.exp(-t * 16) * amp


def sweep(dur=1.2, amp=0.3, seed=13):
    """扫频：带通噪声中心频率指数扫过 300Hz→12kHz"""
    n = int(dur * SR)
    rng = np.random.default_rng(seed)
    x = rng.normal(0, 1, n)
    y = np.zeros(n)
    segs = 24
    for k in range(segs):
        i0, i1 = int(k * n / segs), int((k + 1) * n / segs)
        c = 300 * (40 ** (k / segs))
        y[i0:i1] = bandpass(x[i0:i1], c, 4)
    t = np.arange(n) / SR
    return y * np.minimum(t / 0.15, 1) * np.minimum((dur - t) / 0.25, 1) * amp


def upsuck(dur=0.8, amp=0.35, seed=17):
    """反向上吸：sweep 倒放（冲击前倒计时经典）"""
    return sweep(dur, amp, seed)[::-1]


def punch(dur=0.2, amp=0.6):
    """重击：低频 thump + 短噪声"""
    t = np.arange(int(dur * SR)) / SR
    f = 160 * np.exp(-t * 30) + 50
    body = np.sin(TAU * np.cumsum(f) / SR) * np.exp(-t * 25)
    rng = np.random.default_rng(23)
    crack = rng.normal(0, 1, len(t)) * np.exp(-t * 90) * 0.3
    return soft_clip((body + crack) * amp, 1.5)


def pop(dur=0.12, amp=0.4):
    """气泡：正弦快速上滑 """
    t = np.arange(int(dur * SR)) / SR
    f = 300 + 900 * t / dur
    return np.sin(TAU * np.cumsum(f) / SR) * np.exp(-t * 30) * amp


def splat(dur=0.3, amp=0.4, seed=19):
    """粘滞：低通噪声 + 频率下滑 """
    t = np.arange(int(dur * SR)) / SR
    rng = np.random.default_rng(seed)
    n = lowpass(rng.normal(0, 1, len(t)), 900)
    f = 500 * np.exp(-t * 10) + 120
    wob = 0.6 + 0.4 * np.sin(TAU * np.cumsum(f) / SR)
    return n * wob * np.exp(-t * 12) * amp


def chime(dur=1.4, amp=0.25, seed=29):
    """风铃：随机泛音叠加，长衰减 """
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    for k in range(4):
        f = 1046 * (1 + rng.random() * 0.8)
        i0 = int(rng.random() * 0.05 * SR)
        seg = t[:n - i0]
        y[i0:] += np.sin(TAU * f * seg) * np.exp(-seg * (5 + rng.random() * 4)) * (0.6 - k * 0.12)
    return y * amp


def gong(dur=2.6, amp=0.5):
    """锣：非谐泛音 + 长衰减 + 起振噪声 """
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = np.zeros(n)
    for f, g, d in [(98, 1.0, 1.6), (147, 0.7, 2.2), (201, 0.5, 3.0),
                    (263, 0.35, 3.6), (331, 0.22, 4.4), (419, 0.12, 5.2)]:
        y += np.sin(TAU * f * t) * g * np.exp(-t * d)
    rng = np.random.default_rng(31)
    y += rng.normal(0, 1, n) * np.exp(-t * 26) * 0.08
    return soft_clip(y, 1.2) * amp * np.minimum(t / 0.01, 1)


def taiko(dur=0.5, amp=0.6, f0=180):
    """太鼓：低频体 + 皮面拍击 """
    t = np.arange(int(dur * SR)) / SR
    f = f0 * np.exp(-t * 16) + 60
    body = np.sin(TAU * np.cumsum(f) / SR) * np.exp(-t * 9)
    skin = np.sin(TAU * 420 * t) * np.exp(-t * 40) * 0.3
    return soft_clip((body + skin) * amp, 1.3)


def shaker(dur=0.18, amp=0.3, seed=37):
    """沙锤：高通噪声极短衰减 """
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    return highpass(rng.normal(0, 1, n), 5200, 2) * np.exp(-t * 45) * amp


def cymbal(dur=1.8, amp=0.3, seed=41):
    """镲片：高通噪声 + 中频带通强调，长衰减 """
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    nz = rng.normal(0, 1, n)
    return (highpass(nz, 4200, 2) * 0.6 + bandpass(nz, 3200, 5) * 0.5) * np.exp(-t * 3.2) * amp


def drone(dur=4.0, amp=0.18):
    """低鸣：双失谐锯齿谐波 + 低通 + 慢包络 """
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = np.zeros(n)
    for f, g in [(55, 1.0), (55.4, 0.8), (82.5, 0.5), (110.7, 0.3)]:
        y += (np.sin(TAU * f * t) + 0.4 * np.sin(TAU * f * 2 * t)) * g
    return lowpass(y / 2.5, 400) * amp * env(n, a=dur * 0.2, d=dur * 0.15, s=0.85, r=dur * 0.4)


def pulse(dur=0.3, amp=0.4, freq=880):
    """电子脉冲：方波 + 快衰减 """
    t = np.arange(int(dur * SR)) / SR
    sq = np.sign(np.sin(TAU * freq * t))
    return lowpass(sq, 2600) * np.exp(-t * 22) * amp


def glitch(dur=0.35, amp=0.4, seed=43):
    """故障：随机方波片段 + 幅度量化 """
    n = int(dur * SR)
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    i = 0
    while i < n:
        seg = int(rng.random() * 0.06 * SR) + 60
        f = 200 + rng.random() * 3000
        t = np.arange(min(seg, n - i)) / SR
        y[i:i + len(t)] = np.sign(np.sin(TAU * f * t)) * (0.4 + rng.random() * 0.6)
        i += seg
    return np.round(y * 4) / 4 * np.exp(-np.arange(n) / SR * 6) * amp


def typekey(dur=0.05, amp=0.35, seed=47):
    """键盘敲击：极短高频点击 """
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    y = highpass(rng.normal(0, 1, n), 2800) * 0.5 + np.sin(TAU * 2100 * t) * 0.5
    return y * np.exp(-t * 260) * amp


def swipe(dur=0.4, amp=0.3, seed=51):
    """滑动：三段带通噪声移频 """
    n = int(dur * SR)
    rng = np.random.default_rng(seed)
    x = rng.normal(0, 1, n)
    y = np.zeros(n)
    for k, c in enumerate([1400, 2600, 4200]):
        i0, i1 = int(k * n / 3), int((k + 1) * n / 3)
        y[i0:i1] = bandpass(x[i0:i1], c, 4)
    t = np.arange(n) / SR
    return y * np.minimum(t / 0.05, 1) * np.minimum((dur - t) / 0.1, 1) * amp


def magic(dur=1.0, amp=0.3, seed=53):
    """魔法：上行随机泛音闪烁 """
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    for k in range(5):
        f = 784 * (1 + k * 0.25) * (1 + rng.random() * 0.15)
        i0 = int(k * 0.09 * SR)
        seg = t[:n - i0]
        y[i0:] += np.sin(TAU * f * seg) * np.exp(-seg * 4) * (0.5 - k * 0.07)
    return y * np.minimum(t / 0.1, 1) * amp


def powerup(dur=0.9, amp=0.35):
    """能量上升：方波 + 八度叠加，滑音上行 """
    t = np.arange(int(dur * SR)) / SR
    f = 220 * (6 ** (t / dur))
    ph = TAU * np.cumsum(f) / SR
    sq = np.sign(np.sin(ph)) * 0.5 + np.sign(np.sin(ph * 2)) * 0.25
    return lowpass(sq, 3200) * np.minimum(t / 0.08, 1) * amp


def heal(dur=1.2, amp=0.3):
    """治疗：双音平行上行 + 柔和包络 """
    t = np.arange(int(dur * SR)) / SR
    f1 = 523 * (1.5 ** (t / dur))
    f2 = 784 * (1.5 ** (t / dur))
    y = (np.sin(TAU * np.cumsum(f1) / SR) + np.sin(TAU * np.cumsum(f2) / SR)) * 0.5
    return y * env(len(t), a=0.06, d=0.1, s=0.7, r=dur * 0.45) * amp


def camera(dur=0.25, amp=0.4):
    """单反：反光板抬起噪声 + 落位双击 """
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(59)
    nz = rng.normal(0, 1, n)
    y = nz * np.exp(-t * 60) * 0.8
    y[int(0.12 * SR):] += rng.normal(0, 1, max(0, n - int(0.12 * SR))) * np.exp(-(t[int(0.12 * SR):] - 0.12) * 120) * 0.6
    return bandpass(y, 2400, 3) * amp


def dial(dur=0.3, amp=0.3):
    """拨号：DTMF 式双音交替 """
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = np.zeros(n)
    half = n // 2
    for i0, i1, f1, f2 in [(0, half, 697, 1209), (half, n, 770, 1477)]:
        seg = t[i0:i1] - t[i0]
        y[i0:i1] = (np.sin(TAU * f1 * seg) + np.sin(TAU * f2 * seg)) * 0.5
    return y * np.minimum(t / 0.01, 1) * np.minimum((dur - t) / 0.05, 1) * amp


# ---------- SFX 库（44 个） ----------
SFX = {
    "whoosh": lambda amp=1.0: whoosh(0.7, 0.4 * amp, 5),
    "impact": lambda amp=1.0: impact(0.9, 0.65 * amp),
    "boom": lambda amp=1.0: boom(1.1, 0.7 * amp),
    "riser": lambda amp=1.0: riser(2.0, 0.3 * amp, 11),
    "click": lambda amp=1.0: click(0.03, 0.5 * amp),
    "shutter": lambda amp=1.0: shutter(0.18, 0.45 * amp),
    "clap": lambda amp=1.0: clap(0.22, 0.4 * amp),
    "tom": lambda amp=1.0: tom(0.3, 0.4 * amp),
    "heartbeat": lambda amp=1.0: heartbeat(1.1, 0.6 * amp),
    "sparkle": lambda amp=1.0: sparkle(2093, 1.2, 0.16 * amp),
    "wind": lambda amp=1.0: wind(4.0, 0.1 * amp, 17),
    "glass": lambda amp=1.0: glass(0.5, 0.4 * amp),
    "metal": lambda amp=1.0: metal(0.6, 0.4 * amp),
    "wood": lambda amp=1.0: wood(0.16, 0.4 * amp),
    "water": lambda amp=1.0: water(0.45, 0.35 * amp),
    "fire": lambda amp=1.0: fire(1.6, 0.22 * amp),
    "thunder": lambda amp=1.0: thunder(2.4, 0.5 * amp),
    "coin": lambda amp=1.0: coin(0.7, 0.35 * amp),
    "door": lambda amp=1.0: door(0.9, 0.3 * amp),
    "ui": lambda amp=1.0: ui(0.14, 0.3 * amp),
    "error": lambda amp=1.0: error(0.35, 0.3 * amp),
    "success": lambda amp=1.0: success(0.5, 0.3 * amp),
    # ---- v2 新增 22 ----
    "laser": lambda amp=1.0: laser(0.35, 0.4 * amp),
    "zap": lambda amp=1.0: zap(0.22, 0.4 * amp),
    "sweep": lambda amp=1.0: sweep(1.2, 0.3 * amp),
    "upsuck": lambda amp=1.0: upsuck(0.8, 0.35 * amp),
    "punch": lambda amp=1.0: punch(0.2, 0.6 * amp),
    "pop": lambda amp=1.0: pop(0.12, 0.4 * amp),
    "splat": lambda amp=1.0: splat(0.3, 0.4 * amp),
    "chime": lambda amp=1.0: chime(1.4, 0.25 * amp),
    "gong": lambda amp=1.0: gong(2.6, 0.5 * amp),
    "taiko": lambda amp=1.0: taiko(0.5, 0.6 * amp),
    "shaker": lambda amp=1.0: shaker(0.18, 0.3 * amp),
    "cymbal": lambda amp=1.0: cymbal(1.8, 0.3 * amp),
    "drone": lambda amp=1.0: drone(4.0, 0.18 * amp),
    "pulse": lambda amp=1.0: pulse(0.3, 0.4 * amp),
    "glitch": lambda amp=1.0: glitch(0.35, 0.4 * amp),
    "typekey": lambda amp=1.0: typekey(0.05, 0.35 * amp),
    "swipe": lambda amp=1.0: swipe(0.4, 0.3 * amp),
    "magic": lambda amp=1.0: magic(1.0, 0.3 * amp),
    "powerup": lambda amp=1.0: powerup(0.9, 0.35 * amp),
    "heal": lambda amp=1.0: heal(1.2, 0.3 * amp),
    "camera": lambda amp=1.0: camera(0.25, 0.4 * amp),
    "dial": lambda amp=1.0: dial(0.3, 0.3 * amp),
}


def build_sfx(dur, cues, gain=0.9):
    """cues: [(t, name), ...] 或 [(t, name, amp), ...]"""
    n = int(dur * SR)
    mix = np.zeros(n)
    for c in cues:
        t, name = c[0], c[1]
        amp = c[2] if len(c) > 2 else 1.0
        fn = SFX.get(name)
        if not fn:
            continue
        i = int(t * SR)
        if i >= n:
            continue
        sig = fn(amp)
        mix[i:i + len(sig)] += sig[: max(0, n - i)]
    return mix * gain


# ---------- 编排 ----------
MOODS = {
    # 和弦走向 + 鼓型密度
    "tech": {"prog": [["A2", "E3", "A3", "C4"], ["F2", "C3", "F3", "A3"], ["C3", "G3", "C4", "E4"], ["G2", "D3", "G3", "B3"]],
             "kick": (1, 0, 0, 1), "snare": (0, 0, 1, 0), "hat": (1, 1, 1, 1), "cutoff": 2400},
    "epic": {"prog": [["D2", "A2", "D3", "F3"], ["B1", "F2", "B2", "D3"], ["G2", "D3", "G3", "B3"], ["A2", "E3", "A3", "C4"]],
             "kick": (1, 0, 0, 0), "snare": (0, 0, 1, 0), "hat": (0, 1, 0, 1), "cutoff": 1500},
    "chill": {"prog": [["C3", "G3", "C4", "E4"], ["A2", "E3", "A3", "C4"], ["F2", "C3", "F3", "A3"], ["G2", "D3", "G3", "B3"]],
              "kick": (1, 0, 0, 0), "snare": (0, 0, 0, 0), "hat": (0, 0, 1, 0), "cutoff": 1200},
    "cinematic": {"prog": [["D2", "A2", "D3", "F3"], ["B1", "F2", "B2", "D3"], ["G2", "D3", "G3", "B3"], ["A2", "E3", "A3", "C4"]],
                  "kick": (1, 0, 0, 0), "snare": (0, 0, 1, 0), "hat": (0, 1, 0, 1), "cutoff": 1100,
                  "bell": True, "clap": True, "wind": 0.5, "pump": 0.45, "arp": 4},
    "lofi": {"prog": [["F2", "C3", "F3", "A3"], ["D2", "A2", "D3", "F3"], ["A#1", "F2", "A#2", "D3"], ["C2", "G2", "C3", "E3"]],
             "kick": (1, 0, 0, 0), "snare": (0, 0, 1, 0), "hat": (0, 0, 1, 0), "cutoff": 900,
             "vinyl": 0.7, "pump": 0.3, "arp": 2, "swing": 0.16},
    "trailer": {"prog": [["D2", "A2", "D3", "F3"], ["D2", "A2", "D3", "F3"], ["A#1", "F2", "A#2", "D3"], ["C2", "G2", "C3", "E3"]],
                "kick": (1, 0, 0, 0), "snare": (0, 0, 1, 0), "hat": (0, 1, 0, 1), "cutoff": 1600,
                "bell": True, "clap": True, "wind": 0.35, "pump": 0.5, "arp": 8, "riser": True},
    "horror": {"prog": [["A1", "F2", "A#2", "F2"], ["A1", "F2", "A#2", "C3"], ["E1", "C2", "G2", "B2"], ["G1", "D2", "F2", "A#2"]],
               "kick": (1, 0, 0, 0), "snare": (0, 0, 0, 0), "hat": (0, 0, 1, 0), "cutoff": 620,
               "wind": 0.7, "pump": 0.6, "arp": 0},
    "action": {"prog": [["D2", "A2", "D3", "F3"], ["G2", "D3", "G3", "A#3"], ["A#2", "F3", "A#3", "D4"], ["C3", "G3", "C4", "D#4"]],
               "kick": (1, 0, 1, 0), "snare": (0, 0, 1, 0), "hat": (1, 1, 1, 1), "cutoff": 2100,
               "bell": True, "clap": True, "pump": 0.4, "arp": 8},
    "romance": {"prog": [["C3", "G3", "C4", "E4"], ["F2", "C3", "F3", "A3"], ["G2", "D3", "G3", "B3"], ["A2", "E3", "A3", "C4"]],
                "kick": (1, 0, 0, 0), "snare": (0, 0, 0, 0), "hat": (0, 0, 1, 0), "cutoff": 1500,
                "organ": 0.8, "pump": 0.2, "arp": 2},
    "scifi": {"prog": [["A2", "E3", "A3", "C4"], ["D3", "A3", "D4", "F4"], ["F2", "C3", "F3", "A3"], ["G2", "D3", "G3", "B3"]],
              "kick": (1, 0, 0, 0), "snare": (0, 0, 1, 0), "hat": (1, 0, 1, 0), "cutoff": 2000,
              "marimba": 0.9, "organ": 0.5, "wind": 0.2, "pump": 0.25, "arp": 4},
    "docu": {"prog": [["G2", "D3", "G3", "B3"], ["C3", "G3", "C4", "E4"], ["A2", "E3", "A3", "C4"], ["F2", "C3", "F3", "A3"]],
             "kick": (1, 0, 0, 0), "snare": (0, 0, 0, 0), "hat": (0, 1, 0, 1), "cutoff": 1300,
             "organ": 0.5, "pump": 0.15, "arp": 0},
    "retro": {"prog": [["A2", "E3", "A3", "C4"], ["F2", "C3", "F3", "A3"], ["D3", "A3", "D4", "F4"], ["G2", "D3", "G3", "B3"]],
              "kick": (1, 0, 0, 1), "snare": (0, 0, 1, 0), "hat": (1, 1, 1, 1), "cutoff": 1800,
              "vinyl": 0.4, "pump": 0.45, "arp": 4, "swing": 0.1},
    # ---- v2 新增 12 个情绪 ----
    "ambient": {"prog": [["C2", "G2", "C3", "E3"], ["A1", "E2", "A2", "C3"], ["F1", "C2", "F2", "A2"], ["G1", "D2", "G2", "B2"]],
                "kick": (0, 0, 0, 0), "snare": (0, 0, 0, 0), "hat": (0, 0, 0, 0), "cutoff": 900,
                "drone": 0.9, "chime": 0.5, "arp": 0},
    "synthwave": {"prog": [["D2", "A2", "D3", "F3"], ["A#1", "F2", "A#2", "D3"], ["F2", "C3", "F3", "A3"], ["C2", "G2", "C3", "E3"]],
                  "kick": (1, 0, 1, 0), "snare": (0, 0, 1, 0), "hat": (1, 1, 1, 1), "cutoff": 2200,
                  "pulse": 0.5, "pump": 0.35, "arp": 8},
    "jazz": {"prog": [["D2", "A2", "D3", "F3"], ["G2", "D3", "G3", "B3"], ["C2", "G2", "C3", "E3"], ["A1", "E2", "A2", "C3"]],
             "kick": (1, 0, 0, 0), "snare": (0, 0, 1, 0), "hat": (0, 0, 1, 0), "cutoff": 1400,
             "shaker": 0.8, "marimba": 0.6, "organ": 0.4, "swing": 0.18, "arp": 2},
    "rock": {"prog": [["E2", "B2", "E3", "G#3"], ["C2", "G2", "C3", "E3"], ["G2", "D3", "G3", "B3"], ["D2", "A2", "D3", "F3"]],
             "kick": (1, 0, 1, 0), "snare": (0, 0, 1, 0), "hat": (1, 1, 1, 1), "cutoff": 2600,
             "pump": 0.2, "arp": 4},
    "dnb": {"prog": [["A1", "E2", "A2", "C3"], ["F1", "C2", "F2", "A2"], ["C2", "G2", "C3", "E3"], ["G1", "D2", "G2", "B2"]],
            "kick": (1, 0, 0, 1), "snare": (0, 0, 1, 0), "hat": (1, 1, 1, 1), "cutoff": 2000,
            "pump": 0.3, "arp": 8},
    "trap": {"prog": [["A#1", "F2", "A#2", "D3"], ["G1", "D2", "G2", "B2"], ["C2", "G2", "C3", "E3"], ["F1", "C2", "F2", "A2"]],
             "kick": (1, 0, 0, 0), "snare": (0, 0, 1, 0), "hat": (1, 1, 1, 1), "cutoff": 1900,
             "vinyl": 0.25, "pump": 0.35, "arp": 2},
    "folk": {"prog": [["C2", "G2", "C3", "E3"], ["G1", "D2", "G2", "B2"], ["A1", "E2", "A2", "C3"], ["F1", "C2", "F2", "A2"]],
             "kick": (1, 0, 0, 0), "snare": (0, 0, 0, 0), "hat": (0, 0, 1, 0), "cutoff": 1600,
             "shaker": 0.6, "marimba": 0.5, "organ": 0.3, "arp": 2},
    "bossa": {"prog": [["C2", "G2", "C3", "E3"], ["A1", "E2", "A2", "C3"], ["D2", "A2", "D3", "F3"], ["G1", "D2", "G2", "B2"]],
              "kick": (1, 0, 0, 0), "snare": (0, 0, 1, 0), "hat": (0, 1, 1, 0), "cutoff": 1500,
              "shaker": 0.9, "marimba": 0.7, "organ": 0.3, "swing": 0.12, "arp": 2},
    "noir": {"prog": [["A1", "F2", "A#2", "E3"], ["D2", "A2", "D3", "F3"], ["G1", "D2", "G2", "B2"], ["C2", "G2", "C3", "E3"]],
             "kick": (1, 0, 0, 0), "snare": (0, 0, 0, 0), "hat": (0, 0, 1, 0), "cutoff": 700,
             "wind": 0.6, "organ": 0.7, "pump": 0.25, "arp": 0},
    "space": {"prog": [["C2", "G2", "C3", "E3"], ["F1", "C2", "F2", "A2"], ["A#1", "F2", "A#2", "D3"], ["G1", "D2", "G2", "B2"]],
              "kick": (1, 0, 0, 0), "snare": (0, 0, 0, 0), "hat": (0, 0, 1, 0), "cutoff": 900,
              "drone": 1.0, "chime": 0.6, "pulse": 0.5, "arp": 4},
    "cyber": {"prog": [["E2", "B2", "E3", "G#3"], ["C2", "G2", "C3", "E3"], ["A#1", "F2", "A#2", "D3"], ["F1", "C2", "F2", "A2"]],
              "kick": (1, 0, 1, 0), "snare": (0, 0, 1, 0), "hat": (1, 1, 1, 1), "cutoff": 2800,
              "pulse": 0.8, "pump": 0.3, "arp": 8},
    "battle": {"prog": [["D2", "A2", "D3", "F3"], ["A#1", "F2", "A#2", "D3"], ["D2", "A2", "D3", "F3"], ["C2", "G2", "C3", "E3"]],
               "kick": (1, 0, 1, 0), "snare": (0, 0, 1, 0), "hat": (0, 1, 0, 1), "cutoff": 2000,
               "taiko": 1.0, "gong": 0.5, "pump": 0.4, "riser": True},
}


def build(dur, bpm=120, mood="tech", hits=(), intro=1.0, outro=0.8, seed=0):
    n = int(dur * SR)
    mix = np.zeros(n)
    beat = 60.0 / bpm
    m = MOODS.get(mood, MOODS["tech"])
    prog = m["prog"]
    bar = beat * 4
    nbars = int(np.ceil(dur / bar))

    def add(sig, at):
        i = int(at * SR)
        if i >= n:
            return
        seg = sig[: max(0, n - i)]
        mix[i:i + len(seg)] += seg

    # 铺底（每小节换和弦）
    for b in range(nbars):
        chord = prog[b % len(prog)]
        add(pad(chord, bar * 1.05, amp=0.20, cutoff=m["cutoff"]), b * bar)

    # 鼓组 + 贝斯
    for b in range(nbars):
        t0 = b * bar
        if t0 > dur - outro:
            continue
        for q in range(4):
            tq = t0 + q * beat
            if m["kick"][q]:
                add(taiko(0.4, 0.55) if m.get("taiko") else kick(), tq)
            if m["snare"][q]:
                add(snare(seed=seed + b), tq)
            if m["hat"][q]:
                add(hat(seed=seed + b * 7 + q), tq + beat * 0.5)
        # 贝斯：根音，跟 kick 同步
        root = prog[b % len(prog)][0]
        add(sub_bass(note_freq(root) / 2, beat * 1.6, amp=0.42), t0)

    # 高音点缀（琶音密度由 mood 的 arp 决定：2/4/8 分音符）
    arp = m.get("arp", 8 if mood in ("tech", "chill") else 0)
    if arp:
        rng = np.random.default_rng(seed + 42)
        for b in range(nbars):
            chord = prog[b % len(prog)]
            for q in range(arp):
                if rng.random() < 0.35:
                    nm = chord[1 + (q % 2)]
                    add(pluck(note_freq(nm) * 2, amp=0.14), b * bar + q * beat * 4 / arp)
    # 钟琴（cinematic/trailer：小节头敲击）
    if m.get("bell"):
        for b in range(nbars):
            if b * bar > dur - outro:
                continue
            chord = prog[b % len(prog)]
            for k in range(3):
                add(bell(note_freq(chord[2]) * (1 + k * 0.5), 1.0, amp=0.10), b * bar)
    # 拍手（替代/叠加军鼓，cinematic/trailer）
    if m.get("clap"):
        for b in range(nbars):
            for q in range(4):
                if m["snare"][q] and b * bar + q * beat < dur - outro:
                    add(clap(0.22, 0.30, seed=seed + b * 3 + q), b * bar + q * beat)
    # 环境风声（cinematic/trailer）
    if m.get("wind"):
        add(wind(min(dur, 8.0), amp=0.10 * m["wind"], seed=seed + 5), 0)
    # 黑胶噪声（lofi）
    if m.get("vinyl"):
        add(vinyl(min(dur, 8.0), amp=0.05 * m["vinyl"], seed=seed + 8), 0)
    # 马林巴（scifi/romance：木质音头旋律）
    if m.get("marimba"):
        for b in range(nbars):
            if b * bar > dur - outro:
                continue
            chord = prog[b % len(prog)]
            for q in range(4):
                if b * bar + q * beat < dur - outro:
                    add(marimba(note_freq(chord[1 + (q % 2)]) * (1 + (q % 3) * 0.5),
                                0.5, amp=0.13 * m["marimba"]), b * bar + q * beat + beat * 0.5)
    # 风琴持续和声（docu/scifi：长音铺底）
    if m.get("organ"):
        for b in range(nbars):
            chord = prog[b % len(prog)]
            add(organ(note_freq(chord[0]), bar * 0.9, amp=0.14 * m["organ"]), b * bar)

    # ---- v2 新特性：锣 / 沙锤 / 风铃 / 电子脉冲 / 低鸣 ----
    # 锣（battle：小节头重击）
    if m.get("gong"):
        for b in range(nbars):
            if b * bar > dur - outro:
                continue
            add(gong(2.4, 0.32 * m["gong"]), b * bar)
    # 沙锤（jazz/bossa/folk：反拍碎音）
    if m.get("shaker"):
        for b in range(nbars):
            for q in range(4):
                if b * bar + q * beat < dur - outro:
                    add(shaker(0.14, 0.16 * m["shaker"], seed=seed + b * 5 + q),
                        b * bar + q * beat + beat * 0.5)
    # 风铃（ambient/space：随机闪烁）
    if m.get("chime"):
        rng2 = np.random.default_rng(seed + 77)
        for b in range(nbars):
            for q in range(4):
                if rng2.random() < 0.3:
                    chord = prog[b % len(prog)]
                    add(chime(1.1, 0.10 * m["chime"], seed=seed + b + q),
                        b * bar + q * beat)
    # 电子脉冲（synthwave/space/cyber：半拍方波点）
    if m.get("pulse"):
        for b in range(nbars):
            chord = prog[b % len(prog)]
            for q in range(2):
                if b * bar + q * beat * 2 < dur - outro:
                    add(pulse(0.25, 0.30 * m["pulse"], note_freq(chord[0]) * 2),
                        b * bar + q * beat * 2)
    # 低鸣床（ambient/space）
    if m.get("drone"):
        add(drone(min(dur, 8.0), amp=0.12 * m["drone"]), 0)

    # 转场音效：段首 whoosh + 指定 hits
    add(whoosh(0.9, 0.35), max(0, intro - 0.9))
    for h in hits:
        add(whoosh(0.55, 0.42, seed=int(h * 10) + 3), max(0, h - 0.45))
        add(impact(), max(0, h))
    # 结尾上升音
    add(riser(1.6, 0.22), max(0, dur - 2.2))

    # sidechain 泵动（全局 ducking：kick 后整 mix 瞬间压低再恢复）
    if m.get("pump"):
        tt = np.arange(n) / SR
        duck = np.ones(n)
        for b in range(nbars):
            for q in range(4):
                if not m["kick"][q]:
                    continue
                d = tt - (b * bar + q * beat)
                mask = (d > 0) & (d < 0.5)
                duck[mask] *= (1 - m["pump"] * np.exp(-d[mask] / 0.09))
        mix *= duck

    # 整体包络：淡入淡出，避免爆音
    fi = int(min(0.35, dur * 0.1) * SR)
    fo = int(min(1.2, dur * 0.25) * SR)
    mix[:fi] *= np.linspace(0, 1, fi)
    mix[-fo:] *= np.linspace(1, 0, fo)

    # 轻度压缩 + 归一化
    mix = soft_clip(mix, 1.15)
    peak = np.max(np.abs(mix)) or 1
    # 留 2.5dB 余量给 AAC 编码（编码后峰值会被抬高，实测会顶到 0dB）
    mix = mix / peak * 0.78
    return mix


def write_wav(path, mono):
    data = (np.clip(mono, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


def parse_cues(text):
    """'3.0=impact,6.0=whoosh:0.8' → [(3.0,'impact',1.0),(6.0,'whoosh',0.8)]"""
    cues = []
    for part in text.split(","):
        part = part.strip()
        if not part or "=" not in part:
            continue
        t, name = part.split("=", 1)
        amp = 1.0
        if ":" in name:
            name, a = name.split(":", 1)
            amp = float(a)
        cues.append((float(t), name.strip(), amp))
    return cues


def read_wav(path):
    with wave.open(path, "rb") as w:
        n = w.getnframes()
        raw = w.readframes(n)
        ch = w.getnchannels()
        sr = w.getframerate()
    a = np.frombuffer(raw, dtype="<i2").astype(np.float64) / 32768.0
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1)
    return a, sr


def resample_to(a, sr, n):
    if len(a) == n:
        return a
    idx = np.linspace(0, len(a) - 1, n)
    return np.interp(idx, np.arange(len(a)), a)


def main():
    argv = sys.argv[1:]
    # 子命令（保持旧用法：第一个参数不是子命令时按音乐模式解析）
    sub = argv[0] if argv and argv[0] in ("music", "track", "sfx", "mix") else "music"
    if sub != "music":
        argv = argv[1:]
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--dur", type=float, default=10)
    ap.add_argument("--bpm", type=float, default=120)
    ap.add_argument("--mood", default="tech", choices=list(MOODS))
    ap.add_argument("--key", default="A")
    ap.add_argument("--hits", default="", help="逗号分隔的冲击时刻(秒)")
    ap.add_argument("--intro", type=float, default=1.0)
    ap.add_argument("--outro", type=float, default=0.8)
    ap.add_argument("--sfx", default="", help="音效轨: '3.0=impact,6.0=whoosh:0.8'")
    ap.add_argument("--music", default="", help="mix 模式：已有音乐 wav 路径")
    ap.add_argument("--music-gain", type=float, default=0.72)
    ap.add_argument("--sfx-gain", type=float, default=0.95)
    args = ap.parse_args(argv)
    n = int(args.dur * SR)
    hits = [float(x) for x in args.hits.split(",") if x.strip()]
    cues = parse_cues(args.sfx)

    if sub == "sfx":
        # 纯音效轨
        mix = build_sfx(args.dur, cues, args.sfx_gain)
    else:
        # track/mix：音乐 + 音效
        if sub == "mix" and args.music:
            m, msr = read_wav(args.music)
            music = resample_to(m, msr, n) * args.music_gain
        else:
            music = build(args.dur, args.bpm, args.mood, hits, args.intro, args.outro) * args.music_gain
        sfx = build_sfx(args.dur, cues, args.sfx_gain)
        mix = music + sfx

    # 总线：软限幅 + 归一化（留 5.2dB 余量，AAC 编码会抬高峰值 2~3dB）
    mix = soft_clip(mix, 1.15)
    peak = np.max(np.abs(mix)) or 1
    mix = mix / peak * 0.55
    write_wav(args.out, mix)
    print(f"音频已生成: {args.out}  时长 {args.dur}s  模式 {sub}"
          + (f"  BPM {args.bpm}  风格 {args.mood}" if sub != "sfx" else "")
          + (f"  音效 {len(cues)} 个" if cues else ""))


if __name__ == "__main__":
    main()
