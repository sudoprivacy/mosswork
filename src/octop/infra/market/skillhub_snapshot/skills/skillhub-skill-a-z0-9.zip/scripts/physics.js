/* ============================================================
   opus-video · physics.js — 确定性物理引擎（window.OVP）
   固定步长积分：poseAt(t) 从 t=0 重新积分到 t，天然满足帧契约
   （同一 t 永远同一姿态，可并行渲染、可复现）
  支持：重力 / 地面反弹 / 球-球碰撞 / 边界墙 / 空气阻力
        绳索链约束 / 软体压力球 / 定时爆炸冲量 / 磁场吸附
        布料网格（结构+剪切弹簧+风场）/ 涡流场 / 显式弹簧
        刚性摆链 / 湍流风场（v3 翻倍）
  ============================================================ */
(function () {
  /* 确定性 PRNG（mulberry32） */
  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* world({gravity:[x,y,z], ground:y, bounds:{min,max}, dt, drag})
     body: {p:[x,y,z], v:[x,y,z], r:半径, m:质量, e:弹性0..1, color, pin:是否锚定} */
  function world(opts) {
    const o = opts || {};
    const g = o.gravity != null ? o.gravity : [0, -9.8, 0];
    const ground = o.ground != null ? o.ground : 0;
    const dt = o.dt || 1 / 240;
    const bounds = o.bounds || null;   // {min:[..], max:[..]}
    const bodies = [];
    const drag = o.drag != null ? o.drag : 0.0;   // 空气阻力（每步线性衰减）
    const explosions = [];   // {at, x, y, z, radius, power}
    const attractors = [];   // {x, y, z, strength, radius, t0, t1}
    const vortices = [];     // {x,y,z, ax,ay,az, radius, strength, pull, t0, t1}
    const turbulences = [];  // {strength, scale, speed, t0, t1}
    const constraints = [];  // {type:"rope"|"soft"|"cloth"|"spring"|"pendulum", ...}

    function add(b) {
      bodies.push({
        p: b.p.slice(), v: (b.v || [0, 0, 0]).slice(),
        r: b.r != null ? b.r : 0.3, m: b.m || 1,
        e: b.e != null ? b.e : 0.72, color: b.color || "#ffffff",
        spin: b.spin || 0, grounded: false, pin: !!b.pin,
      });
      return bodies[bodies.length - 1];
    }

    /* 场力：吸附 / 涡流 / 湍流 / 布料风（积分前施加） */
    function applyFields(s, time) {
      for (const a of attractors) {
        if (time < a.t0 || time > a.t1) continue;
        for (const b of s) {
          if (b.pin) continue;
          const dx = a.x - b.p[0], dy = a.y - b.p[1], dz = a.z - b.p[2];
          const d2 = dx * dx + dy * dy + dz * dz;
          const d = Math.sqrt(d2);
          if (d > a.radius) continue;
          // 线性衰减（近场最强、边界归零），尺度友好：500≈半重力
          const f = a.strength * Math.max(0, 1 - d / a.radius) / b.m;
          b.v[0] += (dx / d) * f * dt; b.v[1] += (dy / d) * f * dt; b.v[2] += (dz / d) * f * dt;
        }
      }
      /* 涡流：绕轴切向旋转 + 径向吸引（龙卷风/排水口） */
      for (const vx of vortices) {
        if (time < vx.t0 || time > vx.t1) continue;
        const al = Math.hypot(vx.ax, vx.ay, vx.az) || 1;
        const ux = vx.ax / al, uy = vx.ay / al, uz = vx.az / al;
        for (const b of s) {
          if (b.pin) continue;
          const dx = b.p[0] - vx.x, dy = b.p[1] - vx.y, dz = b.p[2] - vx.z;
          const tp = dx * ux + dy * uy + dz * uz;               // 轴向投影
          const rx = dx - ux * tp, ry = dy - uy * tp, rz = dz - uz * tp;  // 径向向量
          const rl = Math.hypot(rx, ry, rz);
          if (rl > vx.radius || rl < 1e-6) continue;
          const fall = Math.max(0, 1 - rl / vx.radius);
          // 切向 = 轴 × 径向
          const tx = uy * rz - uz * ry, ty = uz * rx - ux * rz, tz = ux * ry - uy * rx;
          const tl = Math.hypot(tx, ty, tz) || 1;
          const f = vx.strength * fall / b.m;
          b.v[0] += (tx / tl) * f * dt; b.v[1] += (ty / tl) * f * dt; b.v[2] += (tz / tl) * f * dt;
          if (vx.pull) {   // 径向向内吸引（越近越强）
            const pf = vx.pull * vx.strength * fall * fall / b.m;
            b.v[0] -= (rx / rl) * pf * dt; b.v[1] -= (ry / rl) * pf * dt; b.v[2] -= (rz / rl) * pf * dt;
          }
        }
      }
      /* 湍流：确定性伪 curl 噪声风场（无旋度近似，旗帜/落叶/尘埃） */
      for (const tb of turbulences) {
        if (time < tb.t0 || time > tb.t1) continue;
        const sc = tb.scale, tt = time * tb.speed;
        for (const b of s) {
          if (b.pin) continue;
          const f = tb.strength / b.m;
          b.v[0] += (Math.sin(b.p[1] * sc + tt) * Math.cos(b.p[2] * sc * 1.3 - tt * 0.7)) * f * dt;
          b.v[1] += (Math.sin(b.p[2] * sc * 0.9 + tt * 1.2) * Math.cos(b.p[0] * sc * 1.1 + tt * 0.5)) * f * dt * 0.6;
          b.v[2] += (Math.sin(b.p[0] * sc * 1.2 - tt * 0.9) * Math.cos(b.p[1] * sc * 0.8 + tt * 1.1)) * f * dt;
        }
      }
      /* 布料风场：基准风 + 确定性阵风 + 沿质点位置的相位偏移 */
      for (const c of constraints) {
        if (c.type !== "cloth") continue;
        const tt = time * c.windSpeed;
        const wx = c.wind[0], wy = c.wind[1], wz = c.wind[2];
        for (const i of c.idx) {
          const b = s[i];
          if (b.pin) continue;
          const gust = 0.55 + 0.45 * Math.sin(tt * 0.8 + b.p[1] * c.windScale * 0.5);
          const fx = (wx * gust + Math.sin(b.p[1] * c.windScale + tt) * wx * 0.4) / b.m;
          const fy = (wy * gust + Math.sin(b.p[0] * c.windScale * 1.2 + tt * 1.3) * Math.abs(wx) * 0.18) / b.m;
          const fz = (wz * gust + Math.cos(b.p[0] * c.windScale + tt * 0.9) * Math.abs(wx) * 0.3) / b.m;
          b.v[0] += fx * dt; b.v[1] += fy * dt; b.v[2] += fz * dt;
        }
      }
    }

    /* 爆炸：跨过 at 时刻一次性施加径向冲量
       注意：at 恰为 dt 整数倍时浮点会同时错过于两侧步长（0.04999.. / 0.05000..004），
       故加 EPS 容差 + fired 标记；fired 存于 poseAt 本地副本，保证 poseAt 纯函数 */
    function fireExplosions(s, prevT, time, exList) {
      for (const ex of exList) {
        if (ex.fired) continue;
        if (!(prevT < ex.at && time + 1e-9 >= ex.at)) continue;
        ex.fired = true;
        for (const b of s) {
          if (b.pin) continue;
          const dx = b.p[0] - ex.x, dy = b.p[1] - ex.y, dz = b.p[2] - ex.z;
          const dist = Math.hypot(dx, dy, dz);
          if (dist > ex.radius || dist < 1e-6) continue;
          const k = ex.power * (1 - dist / ex.radius) / b.m;
          b.v[0] += (dx / dist) * k; b.v[1] += (dy / dist) * k + ex.power * 0.25 / b.m; b.v[2] += (dz / dist) * k;
        }
      }
    }

    /* 成对距离弹簧投影（PBD；stiff=1 硬约束，<1 软弹簧） */
    function springPair(s, a, b, rest, stiff) {
      const dx = b.p[0] - a.p[0], dy = b.p[1] - a.p[1], dz = b.p[2] - a.p[2];
      const d = Math.hypot(dx, dy, dz) || 1e-6;
      const diff = (d - rest) / d * stiff;
      const wa = a.pin ? 0 : 1, wb = b.pin ? 0 : 1, ws = wa + wb || 1;
      a.p[0] += dx * diff * (wa / ws); a.p[1] += dy * diff * (wa / ws); a.p[2] += dz * diff * (wa / ws);
      b.p[0] -= dx * diff * (wb / ws); b.p[1] -= dy * diff * (wb / ws); b.p[2] -= dz * diff * (wb / ws);
    }

    /* 约束求解（PBD 位置投影；绳索/摆链 6 迭代抗重力拉伸） */
    function solveConstraints(s) {
      for (let iter = 0; iter < 6; iter++) {
        for (const c of constraints) {
          if (c.type === "rope" || c.type === "pendulum") {
            for (let k = 0; k + 1 < c.idx.length; k++) {
              const a = s[c.idx[k]], b = s[c.idx[k + 1]];
              const dx = b.p[0] - a.p[0], dy = b.p[1] - a.p[1], dz = b.p[2] - a.p[2];
              const d = Math.hypot(dx, dy, dz) || 1e-6;
              const diff = (d - c.seg) / d;
              const wa = a.pin ? 0 : 1, wb = b.pin ? 0 : 1, ws = wa + wb || 1;
              a.p[0] += dx * diff * (wa / ws); a.p[1] += dy * diff * (wa / ws); a.p[2] += dz * diff * (wa / ws);
              b.p[0] -= dx * diff * (wb / ws); b.p[1] -= dy * diff * (wb / ws); b.p[2] -= dz * diff * (wb / ws);
            }
          } else if (c.type === "soft") {
            // 压力：质心漂移 → 径向恢复力（近似体积守恒）
            let cx = 0, cy = 0, cz = 0, cnt = 0;
            for (const i of c.idx) { const b = s[i]; if (b.pin) continue; cx += b.p[0]; cy += b.p[1]; cz += b.p[2]; cnt++; }
            if (cnt > 0) { cx /= cnt; cy /= cnt; cz /= cnt; }
            let curR = 0;
            for (const i of c.idx) { const b = s[i]; if (b.pin) continue; curR += Math.hypot(b.p[0] - cx, b.p[1] - cy, b.p[2] - cz); }
            curR = cnt > 0 ? curR / cnt : c.restR;
            const push = (c.restR - curR) * c.pressure;
            for (const i of c.idx) {
              const b = s[i];
              if (b.pin) continue;
              const dx = b.p[0] - cx, dy = b.p[1] - cy, dz = b.p[2] - cz;
              const d = Math.hypot(dx, dy, dz) || 1e-6;
              b.v[0] += (dx / d) * push * dt * 60; b.v[1] += (dy / d) * push * dt * 60; b.v[2] += (dz / d) * push * dt * 60;
            }
            // 邻居弹簧
            for (let k = 0; k < c.idx.length; k++) {
              const a = s[c.idx[k]], b = s[c.idx[(k + 1) % c.idx.length]];
              const dx = b.p[0] - a.p[0], dy = b.p[1] - a.p[1], dz = b.p[2] - a.p[2];
              const d = Math.hypot(dx, dy, dz) || 1e-6;
              const diff = (d - c.rest) / d * 0.5;
              a.p[0] += dx * diff; a.p[1] += dy * diff; a.p[2] += dz * diff;
              b.p[0] -= dx * diff; b.p[1] -= dy * diff; b.p[2] -= dz * diff;
            }
          } else if (c.type === "cloth") {
            /* 布料：结构弹簧（右/下，硬）+ 剪切弹簧（对角，软） */
            const idx = c.idx, nx = c.nx, ny = c.ny;
            for (let j = 0; j < ny; j++) {
              for (let i = 0; i < nx; i++) {
                const a = s[idx[j * nx + i]];
                if (i + 1 < nx) springPair(s, a, s[idx[j * nx + i + 1]], c.rest, c.stiff);
                if (j + 1 < ny) springPair(s, a, s[idx[(j + 1) * nx + i]], c.rest, c.stiff);
              }
            }
            for (let j = 0; j + 1 < ny; j++) {
              for (let i = 0; i + 1 < nx; i++) {
                springPair(s, s[idx[j * nx + i]], s[idx[(j + 1) * nx + i + 1]], c.shearRest, c.shear);
                springPair(s, s[idx[j * nx + i + 1]], s[idx[(j + 1) * nx + i]], c.shearRest, c.shear);
              }
            }
          } else if (c.type === "spring") {
            /* 显式弹簧：胡克位置修正 + 法向阻尼（可连世界锚点） */
            const a = s[c.a];
            const b = c.b >= 0 ? s[c.b] : null;
            const bx = b ? b.p[0] : c.anchor[0], by = b ? b.p[1] : c.anchor[1], bz = b ? b.p[2] : c.anchor[2];
            const dx = bx - a.p[0], dy = by - a.p[1], dz = bz - a.p[2];
            const d = Math.hypot(dx, dy, dz) || 1e-6;
            const nx2 = dx / d, ny2 = dy / d, nz2 = dz / d;
            const corr = (d - c.rest) * c.k;
            const wa = a.pin ? 0 : 1, wb = (b && b.pin) ? 0 : 1, ws = wa + wb || 1;
            a.p[0] += nx2 * corr * (wa / ws); a.p[1] += ny2 * corr * (wa / ws); a.p[2] += nz2 * corr * (wa / ws);
            if (b) { b.p[0] -= nx2 * corr * (wb / ws); b.p[1] -= ny2 * corr * (wb / ws); b.p[2] -= nz2 * corr * (wb / ws); }
            if (c.damp > 0) {
              const rvx = (b ? b.v[0] : 0) - a.v[0], rvy = (b ? b.v[1] : 0) - a.v[1], rvz = (b ? b.v[2] : 0) - a.v[2];
              const dv = (rvx * nx2 + rvy * ny2 + rvz * nz2) * c.damp;
              a.v[0] += nx2 * dv * (wa / ws); a.v[1] += ny2 * dv * (wa / ws); a.v[2] += nz2 * dv * (wa / ws);
              if (b) { b.v[0] -= nx2 * dv * (wb / ws); b.v[1] -= ny2 * dv * (wb / ws); b.v[2] -= nz2 * dv * (wb / ws); }
            }
          }
        }
      }
    }

    /* 单步积分（time = 本步开始时的模拟时钟） */
    function step(s, time, exList) {
      const n = bodies.length;
      applyFields(s, time);
      const prevT = time;
      const nextT = time + dt;
      fireExplosions(s, prevT, nextT, exList);
      for (const b of s) {
        if (b.pin) continue;
        b.v[0] += g[0] * dt; b.v[1] += g[1] * dt; b.v[2] += g[2] * dt;
        if (drag) { b.v[0] *= (1 - drag); b.v[1] *= (1 - drag); b.v[2] *= (1 - drag); }
        b.p[0] += b.v[0] * dt; b.p[1] += b.v[1] * dt; b.p[2] += b.v[2] * dt;
        b.grounded = false;
      }
      /* 地面 */
      for (const b of s) {
        if (b.pin) continue;
        if (b.p[1] - b.r < ground) {
          b.p[1] = ground + b.r;
          if (b.v[1] < 0) b.v[1] = -b.v[1] * b.e;
          if (Math.abs(b.v[1]) < 0.35) { b.v[1] = 0; b.grounded = true; }
          b.v[0] *= 0.985; b.v[2] *= 0.985;   // 摩擦
        }
      }
      /* 边界墙 */
      if (bounds) {
        for (const b of s) {
          if (b.pin) continue;
          for (let k = 0; k < 3; k++) {
            if (b.p[k] - b.r < bounds.min[k]) { b.p[k] = bounds.min[k] + b.r; b.v[k] = Math.abs(b.v[k]) * b.e; }
            if (b.p[k] + b.r > bounds.max[k]) { b.p[k] = bounds.max[k] - b.r; b.v[k] = -Math.abs(b.v[k]) * b.e; }
          }
        }
      }
      /* 球-球 */
      for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
          const a = s[i], c = s[j];
          if (a.pin && c.pin) continue;
          const dx = c.p[0] - a.p[0], dy = c.p[1] - a.p[1], dz = c.p[2] - a.p[2];
          const dist = Math.hypot(dx, dy, dz), min = a.r + c.r;
          if (dist < min && dist > 1e-6) {
            const nx = dx / dist, ny = dy / dist, nz = dz / dist;
            const push = (min - dist) / 2;
            if (!a.pin) { a.p[0] -= nx * push; a.p[1] -= ny * push; a.p[2] -= nz * push; }
            if (!c.pin) { c.p[0] += nx * push; c.p[1] += ny * push; c.p[2] += nz * push; }
            const rvx = c.v[0] - a.v[0], rvy = c.v[1] - a.v[1], rvz = c.v[2] - a.v[2];
            const rel = rvx * nx + rvy * ny + rvz * nz;
            if (rel < 0) {
              const e = Math.min(a.e, c.e);
              const jimp = -(1 + e) * rel / (1 / a.m + 1 / c.m);
              if (!a.pin) { a.v[0] -= (jimp / a.m) * nx; a.v[1] -= (jimp / a.m) * ny; a.v[2] -= (jimp / a.m) * nz; }
              if (!c.pin) { c.v[0] += (jimp / c.m) * nx; c.v[1] += (jimp / c.m) * ny; c.v[2] += (jimp / c.m) * nz; }
            }
          }
        }
      }
      solveConstraints(s);
    }

    /* t 时刻姿态：从初始状态重新积分（确定性核心） */
    function poseAt(t) {
      const s = bodies.map(b => ({ p: b.p.slice(), v: b.v.slice(),
                                   r: b.r, m: b.m, e: b.e, color: b.color,
                                   pin: b.pin, grounded: false }));
      const exLocal = explosions.map(e => Object.assign({}, e));   // fired 标记仅本次积分有效
      const steps = Math.min(20000, Math.round(t / dt));
      for (let k = 0; k < steps; k++) step(s, k * dt, exLocal);
      return s;
    }

    /* ---- 翻倍能力 v2：绳索 / 软体 / 爆炸 / 磁场 ---- */
    function explode(cfg) {
      explosions.push({
        at: cfg.at || 1.0, x: cfg.x || 0, y: cfg.y || 0, z: cfg.z || 0,
        radius: cfg.radius || 300, power: cfg.power || 600,
      });
      return w;
    }
    function attract(cfg) {
      attractors.push({
        x: cfg.x || 0, y: cfg.y || 0, z: cfg.z || 0,
        strength: cfg.strength != null ? cfg.strength : 4000,
        radius: cfg.radius || 500, t0: cfg.t0 != null ? cfg.t0 : 0, t1: cfg.t1 != null ? cfg.t1 : Infinity,
      });
      return w;
    }
    /* 绳索：从 anchor 垂下 n 节链，首节锚定 */
    function rope(anchor, n, opts) {
      const o = opts || {};
      const seg = o.seg || 26, r = o.r || 4, m = o.m || 0.6, e = o.e != null ? o.e : 0.05;
      const color = o.color || "#d8c9a8";
      const idx = [];
      const base = bodies.length;
      for (let i = 0; i < n; i++) {
        add({ p: [anchor[0], anchor[1] - i * seg, anchor[2]], v: [0, 0, 0],
              r, m, e, color, pin: i === 0 });
        idx.push(base + i);
      }
      constraints.push({ type: "rope", idx, seg });
      return { idx, seg };
    }
    /* 软体： fibonacci 球壳 + 压力 + 邻居弹簧（果冻 blob） */
    function soft(cx, cy, cz, opts) {
      const o = opts || {};
      const n = o.n || 20, R = o.radius || 60;
      const idx = [];
      const base = bodies.length;
      const golden = Math.PI * (3 - Math.sqrt(5));
      for (let i = 0; i < n; i++) {
        const y = 1 - (i / (n - 1)) * 2;
        const rad = Math.sqrt(Math.max(0, 1 - y * y));
        const th = golden * i;
        add({ p: [cx + Math.cos(th) * rad * R, cy + y * R, cz + Math.sin(th) * rad * R],
              v: [0, 0, 0], r: o.r || R * 0.16, m: o.m || 0.8,
              e: o.e != null ? o.e : 0.2, color: o.color || "#ff6e8a" });
        idx.push(base + i);
      }
      // 估算邻居间距（球面均匀点的平均边长）
      const rest = 2 * R * Math.sin(Math.PI / n) * 1.6;
      constraints.push({ type: "soft", idx, rest, pressure: o.pressure != null ? o.pressure : 0.5, restR: R });
      return { idx, rest };
    }

    /* ---- 翻倍能力 v3：布料 / 弹簧 / 摆链 / 涡流 / 湍流 ---- */
    /* 布料：nx×ny 质点网格 + 结构弹簧（硬）+ 剪切弹簧（软）+ 确定性风场。
       默认顶行每隔 pinEvery 列锚定（pinTop:false 全自由）。 */
    function cloth(cx, cy, cz, opts) {
      const o = opts || {};
      const nx = o.nx || 9, ny = o.ny || 9, seg = o.seg || 26;
      const idx = [];
      const base = bodies.length;
      const pinEvery = o.pinEvery || 2;
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const pinTop = (o.pinTop !== false) && j === 0 && (i % pinEvery === 0);
          add({
            p: [cx + (i - (nx - 1) / 2) * seg, cy - j * seg, cz],
            v: (o.v || [0, 0, 0]).slice(),
            r: o.r || 3.2, m: o.m || 0.5, e: o.e != null ? o.e : 0.02,
            color: o.color || "#e8e4da", pin: pinTop,
          });
          idx.push(base + j * nx + i);
        }
      }
      constraints.push({
        type: "cloth", idx, nx, ny,
        rest: seg, shearRest: seg * Math.SQRT2,
        stiff: o.stiff != null ? o.stiff : 1.0,
        shear: o.shear != null ? o.shear : 0.45,
        wind: o.wind || [120, 0, 0],
        windScale: o.windScale || 0.03,
        windSpeed: o.windSpeed || 1.6,
      });
      return { idx, nx, ny };
    }
    /* 显式弹簧：a、b 为 body 索引；b 省略时用 anchor 世界坐标做固定端。
       k 为每步位置修正比例（0..1），damp 为法向阻尼（0..1） */
    function spring(cfg) {
      constraints.push({
        type: "spring",
        a: cfg.a, b: cfg.b != null ? cfg.b : -1,
        anchor: cfg.anchor || [0, 0, 0],
        rest: cfg.rest != null ? cfg.rest : 120,
        k: cfg.k != null ? cfg.k : 0.35,
        damp: cfg.damp != null ? cfg.damp : 0.08,
      });
      return w;
    }
    /* 摆链：从锚点伸出的刚性多节链，可设初始摆角 theta（松手做钟摆运动） */
    function pendulum(anchor, n, opts) {
      const o = opts || {};
      const seg = o.seg || 26, r = o.r || 4, m = o.m || 0.6, e = o.e != null ? o.e : 0.02;
      const color = o.color || "#c8d8ff";
      const theta0 = o.theta != null ? o.theta : Math.PI * 0.35;   // 初始摆角（相对竖直向下）
      const phi = o.phi || 0;                                      // 方位角
      const idx = [];
      const base = bodies.length;
      const dx0 = Math.sin(theta0) * Math.cos(phi), dy0 = -Math.cos(theta0), dz0 = Math.sin(theta0) * Math.sin(phi);
      for (let i = 0; i < n; i++) {
        add({
          p: [anchor[0] + dx0 * (i + 1) * seg, anchor[1] + dy0 * (i + 1) * seg, anchor[2] + dz0 * (i + 1) * seg],
          v: [0, 0, 0], r, m, e, color, pin: i === 0,
        });
        idx.push(base + i);
      }
      constraints.push({ type: "pendulum", idx, seg });
      return { idx, seg };
    }
    /* 涡流：绕 axis 轴切向旋转 + 径向吸引（strength 切向、pull 径向比例） */
    function vortex(cfg) {
      vortices.push({
        x: cfg.x || 0, y: cfg.y || 0, z: cfg.z || 0,
        ax: (cfg.axis || [0, 1, 0])[0], ay: (cfg.axis || [0, 1, 0])[1], az: (cfg.axis || [0, 1, 0])[2],
        radius: cfg.radius || 500,
        strength: cfg.strength != null ? cfg.strength : 60,
        pull: cfg.pull != null ? cfg.pull : 0.25,
        t0: cfg.t0 != null ? cfg.t0 : 0, t1: cfg.t1 != null ? cfg.t1 : Infinity,
      });
      return w;
    }
    /* 湍流：确定性伪 curl 噪声风场（strength 力、scale 空间频率、speed 时间频率） */
    function turbulence(cfg) {
      turbulences.push({
        strength: cfg.strength != null ? cfg.strength : 900,
        scale: cfg.scale || 0.02,
        speed: cfg.speed || 1.2,
        t0: cfg.t0 != null ? cfg.t0 : 0, t1: cfg.t1 != null ? cfg.t1 : Infinity,
      });
      return w;
    }

    const w = { add, poseAt, bodies, dt, explode, attract, rope, soft,
                cloth, spring, pendulum, vortex, turbulence, constraints };
    return w;
  }

  /* 便捷：在圆形区域撒 N 个球（确定性） */
  function scatter(w, n, opts) {
    const o = opts || {};
    const r = o.radius || 2.4, h = o.height || 4, seed = o.seed != null ? o.seed : 7;
    const rand = rng(seed);
    const colors = o.colors || ["#5be2a1", "#5aa9ff", "#ffb45e", "#ff6e8a"];
    for (let i = 0; i < n; i++) {
      const a = rand() * Math.PI * 2, d = rand() * r;
      w.add({
        p: [Math.cos(a) * d, h + rand() * 2, Math.sin(a) * d],
        v: [(rand() - 0.5) * 3, 0, (rand() - 0.5) * 3],
        r: (o.rMin || 0.22) + rand() * ((o.rMax || 0.42) - (o.rMin || 0.22)),
        m: 1, e: o.e != null ? o.e : 0.68,
        color: colors[i % colors.length],
      });
    }
    return w;
  }

  window.OVP = { world, scatter, rng };
})();
