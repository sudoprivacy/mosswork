---
name: skillhub-skill-bili-main-dance
description: "当用户想按 B 站「舞蹈」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：舞蹈、B站分区、rid 129。"
---

# B 站分区 · 舞蹈

- 一级分区 rid：`129`；网页路由：`/v/dance/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 95 条榜单条目，覆盖 7 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 国风舞蹈 | 9 | 4 | 200 |
| 宅舞 | 23 | 10 | 20 |
| 明星舞蹈 | 16 | 10 | 199 |
| 舞蹈教程 | 2 | 1 | 156 |
| 舞蹈综合 | 15 | 9 | 154 |
| 街舞 | 10 | 6 | 198 |
| 颜值·网红舞 | 20 | 9 | 255 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 国风舞蹈

数据来源：二级分区 7 日榜，可用 4 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 出发！用舞蹈的方式打开云南旅行 | -欣小萌- | [BV1HERkYAEGN](https://www.bilibili.com/video/BV1HERkYAEGN) | 108.9 万 |
| 谁家的俏皮丫头？一蹦一跳还怪可爱的 | 十元酱少女 | [BV1eQZUY1ELx](https://www.bilibili.com/video/BV1eQZUY1ELx) | 32.1 万 |
| 如果当时 | 是大莹子哟 | [BV1nyRoYrEBN](https://www.bilibili.com/video/BV1nyRoYrEBN) | 18.0 万 |
| 入夏啦 | 文文要早睡呀 | [BV122dAYeEmv](https://www.bilibili.com/video/BV122dAYeEmv) | 29.5 万 |

### 宅舞

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 上班四年，觉醒替身 | -三三三元 | [BV1a2RqYBEvQ](https://www.bilibili.com/video/BV1a2RqYBEvQ) | 662.7 万 |
| “哇！这就是身材健康的学姐嘛？” | 紫颜-小仙紫 | [BV1JgZoY1E6k](https://www.bilibili.com/video/BV1JgZoY1E6k) | 125.5 万 |
| 喜欢流萤的有福啦！ | 爪子drumdoll | [BV1sAZoYnEaR](https://www.bilibili.com/video/BV1sAZoYnEaR) | 54.5 万 |
| 蝶来辣 | 小屿屿屿_ | [BV1W6RoY5EXA](https://www.bilibili.com/video/BV1W6RoY5EXA) | 50.2 万 |
| 很不高兴为您服务😕 | 灯果 | [BV1arZ9YoExk](https://www.bilibili.com/video/BV1arZ9YoExk) | 41.3 万 |

### 明星舞蹈

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 健康好身材✌就要跳出来！ | -阿猫_ | [BV1xBZoY4EdV](https://www.bilibili.com/video/BV1xBZoY4EdV) | 55.5 万 |
| 什么？！学姐私底下竟然是这样的... | 咝小喵MAO | [BV1CHZdYEEhU](https://www.bilibili.com/video/BV1CHZdYEEhU) | 25.3 万 |
| Air全曲翻跳 昨天的评委秀～提问：这个视频满足以下哪些条件？ 卡点 控制 延伸 下腰 转圈 表管 | 汤圆圆圆周 | [BV1BcRXYsEsR](https://www.bilibili.com/video/BV1BcRXYsEsR) | 53.5 万 |
| 【史诗翻拍】是谁淋雨跑去沙丘拍了Like Jennie? | qzk在期中考 | [BV1NsZUYPER2](https://www.bilibili.com/video/BV1NsZUYPER2) | 54.6 万 |
| 现扒了一下dancebreak后半段 | -啵啵fu- | [BV12HRzYYEUs](https://www.bilibili.com/video/BV12HRzYYEUs) | 59.3 万 |

### 舞蹈教程

数据来源：二级分区 7 日榜，可用 1 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| “跳起来向旁边走，怎么整的？”Jennie-Like jennie舞蹈细节教学讲解 | 小虎_诶 | [BV1t1ooYZEX5](https://www.bilibili.com/video/BV1t1ooYZEX5) | 13.4 万 |

### 舞蹈综合

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【不齐舞团】老辈子整的活还可以吧？ | 不齐舞团 | [BV1ZMRoYKEmE](https://www.bilibili.com/video/BV1ZMRoYKEmE) | 353.2 万 |
| 夏日海边开场曲💗 | 周末yuuko | [BV18vZmYqEUS](https://www.bilibili.com/video/BV18vZmYqEUS) | 23.3 万 |
| 给我看爽了！萨克斯魔性律动舞！ | 杂鱼川i | [BV1hYdcYvEmP](https://www.bilibili.com/video/BV1hYdcYvEmP) | 29.1 万 |
| 干哪来了？跳这个腿会消失的舞还是疫情结束的时候！ | 牵然熊 | [BV1gRRDY6EPB](https://www.bilibili.com/video/BV1gRRDY6EPB) | 67.2 万 |
| 起猛了！手办更新了！ | 轻歌er | [BV121dAYNEae](https://www.bilibili.com/video/BV121dAYNEae) | 30.5 万 |

### 街舞

数据来源：二级分区 7 日榜，可用 6 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 这首歌以前帅我一脸，现在还是帅我一脸！ | Storm_Bamboo竹子 | [BV1hBZSYVEyZ](https://www.bilibili.com/video/BV1hBZSYVEyZ) | 155.9 万 |
| 庄园里一个人都没有 | 青巷不是春卷 | [BV1EGZRYiEL9](https://www.bilibili.com/video/BV1EGZRYiEL9) | 44.4 万 |
| 夏天和泫雅一起来了｜bubblepop | 伊栗子- | [BV1FSR1YzEsA](https://www.bilibili.com/video/BV1FSR1YzEsA) | 20.1 万 |
| 我悟了！跳舞进步最快的方法，太太太实用了 | 49小可爱啦 | [BV165dcYmEDw](https://www.bilibili.com/video/BV165dcYmEDw) | 8.5 万 |
| 甲亢哥Super idol 《热爱105°的你》F3篮团小团舞倾情演绎！ | f3篮团花式篮球团舞 | [BV1bndwYYEac](https://www.bilibili.com/video/BV1bndwYYEac) | 35.3 万 |

### 颜值·网红舞

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 杂鱼～杂鱼 | 傲娇怪比 | [BV12eR1YUEpr](https://www.bilibili.com/video/BV12eR1YUEpr) | 49.1 万 |
| 水母头女友初体验~ | 雪柔睡不醒 | [BV1NyRBYfENK](https://www.bilibili.com/video/BV1NyRBYfENK) | 44.3 万 |
| 我被这个开头音乐洗脑了 | LENivayaAya_爱雅 | [BV19eR9YDEa9](https://www.bilibili.com/video/BV19eR9YDEa9) | 38.7 万 |
| 难以抗拒的..温香软玉 | 阿呆每天都不想动 | [BV1vrZdYvEBs](https://www.bilibili.com/video/BV1vrZdYvEBs) | 39.3 万 |
| 爷就是帅 | 小鹿库库 | [BV1NsZ2YxE47](https://www.bilibili.com/video/BV1NsZ2YxE47) | 18.0 万 |

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=129." https://api.bilibili.com/x/web-interface/ranking/v2?rid=129&type=all. Accessed 6 Nov. 2026.
