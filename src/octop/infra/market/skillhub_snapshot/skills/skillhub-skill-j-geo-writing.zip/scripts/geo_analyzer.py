#!/usr/bin/env python3
"""GEO内容评分分析器 - 对文章进行生成式引擎优化五维度评分

仅依赖标准库。运行：
    python geo_analyzer.py --file 文章.md
    python geo_analyzer.py --file 文章.md --format text
"""

import argparse
import json
import re
import os
import sys
from collections import Counter


# ===== 复用规则常量 =====

CONTEXT_DEPS = [
    "如前所述", "如上文", "如上所述", "如前文", "aforementioned", "as mentioned",
    "如前面提到", "如上所示", "如前", "见上文", "见前文", "前文提到",
]

NUMBER_PATTERNS = [
    r'\d+\.?\d*\s*%',
    r'\d{4}\s*[年]',
    r'\d+\.?\d*\s*(万|亿|千|百|倍|个|家|项|次|条|种)',
    r'\d+\.?\d*\s*(million|billion|thousand|k)',
    r'(?:增长|下降|提升|降低|减少|提高|达到|超过|约|近)\s*\d',
    r'(?:研究|报告|调查|数据|统计|实验).{0,6}?\d+',
]

COMPARISON_PATTERNS = [
    r'(?:相比|对比|高于|低于|优于|劣于|超过|不及).{2,20}(?:\d+%|\d+倍|\d+[万千百])',
    r'(?:提升|增长|下降|减少)\s*(?:了|达|约)?\s*\d+\.?\d*\s*%',
    r'(?:是|为).{2,10}(?:的\s*)?\d+\.?\d*\s*倍',
]

CASE_PATTERNS = [
    r'(?:案例|实例|例如|比如|以.*为例|实测|实测数据)',
    r'(?:客户|用户|企业|公司|品牌).{2,20}(?:使用|采用|实施|通过)',
]

SOURCE_PATTERNS = [
    r'(?:根据|据|来自|来源|依据).{2,30}(?:报告|研究|数据|统计|调查)',
    r'(?:研究|论文|报告|白皮书).{0,10}(?:显示|指出|表明|发现)',
    r'(?:来源|Source|src)[:：]\s*',
    r'\[\d+\]',
    r'(?:发布于|发表于|发布日期)',
    r'(?:大学|University|Institute|研究院|研究所)',
]

QUOTE_PATTERNS = [
    r'["\u201c].{10,100}["\u201d]\s*[-——]\s*\S+',
    r'["\u201c].{10,100}["\u201d]',
]

AUTHORITY_PATTERNS = [
    r'(?:学术论文|期刊|paper|journal)',
    r'(?:官方|official|官网)',
    r'(?:报告|report|白皮书|whitepaper)',
    r'(?:专家|学者|教授|博士|professor)',
]

AUTHOR_PATTERNS = [
    r'(作者|writer|by|撰文|编辑|来源)[:：\s]',
]

# 常见AI/搜索相关实体（用于检测核心实体的重复频次）
KNOWN_ENTITIES = [
    "ChatGPT", "Perplexity", "Claude", "Gemini", "Kimi", "豆包", "文心一言",
    "通义千问", "Copilot", "Bing", "Google", "Princeton", "GEO", "SEO",
    "AI Overview", "Generative Engine Optimization",
    "Deepseek", "DeepSeek", "混元", "智谱AI", "智普", "深度求索",
]

ENTITY_PATTERNS = [
    r'[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*',
    r'[A-Z]{2,}',
    r'[\u4e00-\u9fff]{2,6}(?:公司|集团|平台|系统|技术|框架|工具|引擎|模型|大学|研究院)',
]


# ===== 工具函数 =====

def read_content(file_path):
    """读取文件内容，兼容 UTF-8 / UTF-8-SIG / GBK"""
    if not os.path.exists(file_path):
        print(json.dumps({"error": f"文件不存在: {file_path}"}, ensure_ascii=False))
        sys.exit(1)
    last_err = None
    for enc in ("utf-8", "utf-8-sig", "gbk"):
        try:
            with open(file_path, "r", encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, LookupError) as e:
            last_err = e
            continue
    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception as e:
        print(json.dumps({"error": f"读取文件失败: {e}"}, ensure_ascii=False))
        sys.exit(1)


def strip_noise(text):
    """移除代码块与表格行，避免污染事实/实体统计"""
    text = re.sub(r"```.*?```", "", text, flags=re.DOTALL)
    lines = []
    for ln in text.split("\n"):
        s = ln.strip()
        if s.startswith("|") and s.endswith("|") and "|" in s[1:-1]:
            continue
        lines.append(ln)
    return "\n".join(lines)


def count_unique(patterns, text):
    """对多个正则匹配做去重叠计数，避免同一处被多次加分"""
    spans = []
    for pat in patterns:
        for m in re.finditer(pat, text, re.IGNORECASE):
            spans.append((m.start(), m.end()))
    spans.sort()
    merged, count = [], 0
    for s, e in spans:
        if merged and s < merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))
            count += 1
    return count


def iter_unique_matches(patterns, text):
    """返回去重叠后的匹配区间列表 [(start, end, text), ...]"""
    spans = []
    for pat in patterns:
        for m in re.finditer(pat, text, re.IGNORECASE):
            spans.append((m.start(), m.end(), m.group(0)))
    spans.sort()
    merged = []
    for s, e, g in spans:
        if merged and s < merged[-1][1]:
            continue
        merged.append((s, e, g))
    return merged


# ===== 多平台专属检查 =====

PLATFORM_LABELS = {
    "general": "通用（多平台）",
    "chatgpt": "ChatGPT / Google AI Overview",
    "perplexity": "Perplexity",
    "doubao": "豆包",
    "kimi": "Kimi",
    "tongyi": "通义千问",
    "wenxin": "文心一言",
    "deepseek": "Deepseek",
    "hunyuan": "混元",
    "zhipu": "智谱AI",
}


def platform_group(p):
    if p in ("doubao", "kimi", "tongyi", "wenxin", "deepseek", "hunyuan", "zhipu"):
        return "china"
    if p == "perplexity":
        return "perplexity"
    if p == "chatgpt":
        return "chatgpt"
    return "general"


def apply_platform_checks(platform, text, paragraphs, scores, all_suggestions, all_details, platform_suggestions):
    """根据目标平台调整评分与建议（在五维基础上做增量修正）。

    platform_suggestions: list，平台专属建议以 dict({'dimension','suggestion'}) 形式追加，
    便于在 generate_report 中与五维通用建议合并、排序、打标。
    """
    group = platform_group(platform)
    notes = []
    clean = strip_noise(text)

    if group == "perplexity":
        # 实时检索 + 引用链接：强调数据新鲜度与可点击来源
        recent_years = len(re.findall(r'(?:2024|2025|2026)\s*年|\b202[4-6]\b', clean))
        all_details.setdefault("platform_perplexity", {})["recent_year_mentions"] = recent_years
        if recent_years == 0:
            scores["citation"] = max(0, scores["citation"] - 8)
            platform_suggestions.append({
                "dimension": "citation",
                "suggestion": "Perplexity 偏好最新数据，建议补充 2024-2026 年的时效性数据/年份"})
        has_link = bool(re.search(r'https?://|\[[^\]]+\]\(http', clean))
        all_details.setdefault("platform_perplexity", {})["has_source_link"] = has_link
        if not has_link:
            scores["citation"] = max(0, scores["citation"] - 5)
            platform_suggestions.append({
                "dimension": "citation",
                "suggestion": "Perplexity 会展示引用链接，建议为关键来源提供可点击的 URL 或文献链接"})
        notes.append("已按 Perplexity 偏好强化：数据新鲜度 + 来源链接")

    elif group == "chatgpt":
        # 权威摘要、结构化片段：强调结论前置 + FAQ + 清晰来源
        has_faq = bool(re.search(r'(?:FAQ|常见问题|常见问答|问答)', text, re.IGNORECASE))
        all_details.setdefault("platform_chatgpt", {})["has_faq"] = has_faq
        if not has_faq:
            scores["structure"] = max(0, scores["structure"] - 6)
            platform_suggestions.append({
                "dimension": "structure",
                "suggestion": "ChatGPT / AI Overview 偏好可直接摘取的问答结构，建议补充 FAQ 章节"})
        notes.append("已按 ChatGPT / AI Overview 偏好强化：结构化片段 + FAQ")

    elif group == "china":
        # 中文长上下文、实体一致：强调中文实体重复 + 本土权威源
        cn_authority = bool(re.search(
            r'(知乎|36氪|钛媒体|澎湃|新华社|人民网|官方|研究报告|中国|国内|国家统计局|工信部|腾讯|阿里|字节|百度|智谱|深度求索|清华)',
            clean))
        all_details.setdefault("platform_china", {})["has_cn_authority"] = cn_authority
        if not cn_authority:
            scores["citation"] = max(0, scores["citation"] - 6)
            platform_suggestions.append({
                "dimension": "citation",
                "suggestion": f"{PLATFORM_LABELS.get(platform, platform)} 偏好本土权威信源，"
                              f"建议补充中文权威来源（如官方数据、行业研究报告、权威媒体）"})
        notes.append(f"已按 {PLATFORM_LABELS.get(platform, platform)} 偏好强化：中文实体一致性 + 本土权威源")
        # 平台专属细化检查（文心一言/Deepseek/混元/智谱AI 各有侧重）
        notes += china_specific_checks(platform, text, clean, scores, all_details, platform_suggestions)

    return notes


def china_specific_checks(platform, text, clean, scores, all_details, platform_suggestions):
    """国内平台（文心一言/Deepseek/混元/智谱AI）的差异化专属检查。

    基础 'china' 检查（中文实体一致性 + 本土权威源）对所有国内平台生效；
    以下为每个平台叠加的、与其模型特性匹配的细化检查，结果以 dict 形式追加到 platform_suggestions。
    """
    notes = []
    if platform == "wenxin":
        # 文心一言（百度 ERNIE）：知识图谱检索 + 百度搜索可索引
        has_def = bool(re.search(r'[\u4e00-\u9fff]{2,10}\s*(?:是|指|即|为)\s*.{4,40}', clean))
        all_details.setdefault("platform_wenxin", {})["has_definitional_sentence"] = has_def
        if not has_def:
            scores["structure"] = max(0, scores["structure"] - 4)
            platform_suggestions.append({
                "dimension": "structure",
                "suggestion": "文心一言基于百度知识图谱，建议为关键实体补充'XX 是/指 …'式百科定义句，"
                              "提升知识图谱检索与引用命中率"})
        notes.append("已针对文心一言强化：知识图谱友好 + 百科式实体定义")
    elif platform == "deepseek":
        # Deepseek：技术推理、开源、代码友好
        has_tech = bool(re.search(r'```|代码|函数|算法|API|开源|模型权重|推理|训练|参数|算式', clean))
        all_details.setdefault("platform_deepseek", {})["has_technical_depth"] = has_tech
        if not has_tech:
            scores["factual_density"] = max(0, scores["factual_density"] - 4)
            platform_suggestions.append({
                "dimension": "factual_density",
                "suggestion": "Deepseek 对技术内容（代码、算法、可验证推理过程）引用偏好更强，"
                              "建议补充技术细节 / 代码示例 / 可复现数据"})
        notes.append("已针对 Deepseek 强化：技术深度与可验证推理")
    elif platform == "hunyuan":
        # 混元（腾讯）：多模态、列表/图文友好、腾讯生态
        has_list = bool(re.search(r'(?:^|\n)\s*[-*]\s+|(?:\n)\s*\d+\.\s+', text, re.MULTILINE)) or ("|" in text)
        all_details.setdefault("platform_hunyuan", {})["has_multimodal_structure"] = has_list
        if not has_list:
            scores["structure"] = max(0, scores["structure"] - 4)
            platform_suggestions.append({
                "dimension": "structure",
                "suggestion": "混元（腾讯）多模态能力强，建议多用列表 / 分点 / 表格 / 图文结构，"
                              "提升多模态解析与引用友好度"})
        notes.append("已针对混元强化：多模态友好结构 + 腾讯生态信源")
    elif platform == "zhipu":
        # 智谱AI（清华 GLM）：学术、研究、可验证引用
        has_academic = bool(re.search(r'(论文|研究|学术|期刊|实验|数据集|arXiv|知网|清华|智谱|KEG)', clean))
        all_details.setdefault("platform_zhipu", {})["has_academic_source"] = has_academic
        if not has_academic:
            scores["citation"] = max(0, scores["citation"] - 4)
            platform_suggestions.append({
                "dimension": "citation",
                "suggestion": "智谱AI（GLM）源自清华 KEG，对学术 / 研究类内容更友好，"
                              "建议补充论文、研究数据或学术来源标注"})
        notes.append("已针对智谱AI强化：学术引用与可验证研究数据")
    return notes


def split_paragraphs(text):
    """将文本拆分为段落列表，过滤空行"""
    lines = text.strip().split("\n")
    paragraphs = []
    current = []
    for line in lines:
        stripped = line.strip()
        if stripped == "":
            if current:
                paragraphs.append("\n".join(current))
                current = []
        else:
            current.append(stripped)
    if current:
        paragraphs.append("\n".join(current))
    return paragraphs


# ===== 维度分析 =====

def analyze_extractability(text, paragraphs):
    """维度一：可提取性分析"""
    score = 50
    suggestions = []
    details = {}

    content_paragraphs = [p for p in paragraphs if not p.startswith("#")]
    details["total_paragraphs"] = len(content_paragraphs)

    # 段落长度：每段不超过5行（约200字）
    long_paragraphs = sum(1 for p in content_paragraphs if len(p) > 200)
    details["long_paragraphs"] = long_paragraphs
    if long_paragraphs == 0:
        score += 15
    else:
        ratio = long_paragraphs / max(len(content_paragraphs), 1)
        if ratio < 0.2:
            score += 10
        elif ratio < 0.4:
            score += 5
        else:
            score -= 10
            suggestions.append(f"有{long_paragraphs}个段落超过200字，建议拆分为更短的段落，每段控制在5行（约200字）以内")

    # 上下文依赖表述
    dep_count = count_unique([re.escape(d) for d in CONTEXT_DEPS], text)
    details["context_dependency_count"] = dep_count
    if dep_count == 0:
        score += 15
    elif dep_count <= 2:
        score += 5
    else:
        score -= 10
        suggestions.append(f"发现{dep_count}处上下文依赖表述（如'如前所述'），建议改为独立完整的表述")

    # 逐段开头是否直接给结论（可提取性核心）
    weak_openers = 0
    for p in content_paragraphs:
        first_line = p.split("\n")[0] if "\n" in p else p
        first_sentence = re.split(r"[。.!?！？]", first_line)[0].strip()
        if len(first_sentence) < 8:
            weak_openers += 1
            continue
        if re.match(r"^(在|当我们|今天|最近|随着|对于|关于|首先|其次|另外|此外|总的来说|综上所述|众所周知|其实|事实上)", first_sentence):
            weak_openers += 1
    details["weak_opening_paragraphs"] = weak_openers
    ratio_weak = weak_openers / max(len(content_paragraphs), 1)
    if ratio_weak <= 0.2:
        score += 10
    elif ratio_weak <= 0.4:
        pass
    else:
        score -= 10
        suggestions.append(f"有{weak_openers}个段落开头偏铺垫/依赖上下文，建议每段开头1-2句直接给出结论或答案")

    # 首段定义性内容
    if content_paragraphs:
        first_para = content_paragraphs[0]
        has_definition = bool(re.search(r"(是|指|即|定义为|是指|是一种|是一套|是一个)", first_para))
        details["first_paragraph_has_definition"] = has_definition
        if has_definition:
            score += 10
        else:
            suggestions.append("首段建议包含核心概念的直接定义，使AI能快速识别文章主题")

        first_len = len(first_para)
        details["first_paragraph_length"] = first_len
        if 80 <= first_len <= 160:
            score += 10
        elif first_len < 60:
            score -= 5
            suggestions.append("首段过短，建议扩展到80-160字，包含定义、价值和适用范围")
        elif first_len > 200:
            score -= 5
            suggestions.append("首段过长，建议精简到80-160字，确保可独立引用")

    return min(max(score, 0), 100), suggestions, details


def analyze_entity_density(text, paragraphs):
    """维度二：实体密度与权威分析"""
    score = 50
    suggestions = []
    details = {}

    clean = strip_noise(text)
    headings = [p for p in paragraphs if p.startswith("#")]
    details["heading_count"] = len(headings)

    # 收集所有命中的实体文本以统计频次
    entity_tokens = []
    for pattern in ENTITY_PATTERNS:
        entity_tokens += re.findall(pattern, clean)
    text_lower = clean.lower()
    for e in KNOWN_ENTITIES:
        c = text_lower.count(e.lower())
        if c:
            entity_tokens += [e] * c

    char_count = len(clean.replace(" ", "").replace("\n", ""))
    entity_count = len(entity_tokens)
    entity_density = (entity_count / max(char_count, 1)) * 100
    details["entity_count"] = entity_count
    details["char_count"] = char_count
    details["entity_density_per_100_chars"] = round(entity_density, 2)

    if entity_density >= 2.0:
        score += 20
    elif entity_density >= 1.0:
        score += 12
    elif entity_density >= 0.5:
        score += 5
    else:
        suggestions.append("实体密度偏低，建议增加核心概念、品牌、产品、技术名称等专有名词的出现频次")

    # 核心实体重复频次（取出现最多的实体）
    freq = Counter(t for t in entity_tokens if len(t) >= 2)
    if freq:
        top_entity, top_count = freq.most_common(1)[0]
        details["top_entity"] = top_entity
        details["top_entity_count"] = top_count
        if top_count >= 5:
            score += 10
        else:
            suggestions.append(f"核心实体重复频次偏低（最多'{top_entity}'仅{top_count}次），建议在全文自然重复核心实体不少于5次")
    else:
        details["top_entity"] = None
        details["top_entity_count"] = 0

    # 首段是否定义了核心实体
    if paragraphs:
        first_content = ""
        for p in paragraphs:
            if not p.startswith("#"):
                first_content = p
                break
        has_entity_def = bool(re.search(
            r'[（(][A-Za-z\u4e00-\u9fff]+[）)]|是指|定义为|即[是]|（Generative|（SEO|（GEO',
            first_content
        ))
        details["first_paragraph_has_entity_definition"] = has_entity_def
        if has_entity_def:
            score += 15
        else:
            suggestions.append("建议在首段对核心实体进行明确定义，如'GEO（Generative Engine Optimization，生成式引擎优化）是...'")

    # 作者/来源信息
    has_author = bool(re.search("|".join(AUTHOR_PATTERNS), text, re.IGNORECASE))
    details["has_author_info"] = has_author
    if has_author:
        score += 10
    else:
        suggestions.append("建议添加作者信息和专业资质说明，增强实体权威性")

    return min(max(score, 0), 100), suggestions, details


def analyze_factual_density(text, paragraphs):
    """维度三：事实密度分析"""
    score = 50
    suggestions = []
    details = {}

    clean = strip_noise(text)
    fact_spans = iter_unique_matches(NUMBER_PATTERNS, clean)
    fact_count = len(fact_spans)
    content_paragraphs = [p for p in paragraphs if not p.startswith("#")]
    para_count = max(len(content_paragraphs), 1)
    facts_per_para = fact_count / para_count
    details["fact_count"] = fact_count
    details["facts_per_paragraph"] = round(facts_per_para, 2)

    if facts_per_para >= 1.2:
        score += 25
    elif facts_per_para >= 0.8:
        score += 15
    elif facts_per_para >= 0.4:
        score += 8
    else:
        suggestions.append("事实密度偏低，建议为核心论点补充具体数据、百分比、年份等可验证信息")

    # 对比数据
    comparison_count = count_unique(COMPARISON_PATTERNS, clean)
    details["comparison_data_count"] = comparison_count
    if comparison_count >= 3:
        score += 15
    elif comparison_count >= 1:
        score += 8
    else:
        suggestions.append("建议增加对比数据（如'提升了XX%'、'是XX的X倍'），增强说服力")

    # 具体案例
    case_count = count_unique(CASE_PATTERNS, clean)
    details["case_count"] = case_count
    if case_count >= 2:
        score += 10
    elif case_count >= 1:
        score += 5
    else:
        suggestions.append("建议补充1-2个具体案例或实测数据，增强内容的可引用价值")

    # 被引用的"事实"比例（抑制单纯堆数字刷分）
    cited = 0
    for s, e, _ in fact_spans:
        window = clean[max(0, s - 40): min(len(clean), e + 40)]
        if re.search(r'(根据|据|来源|研究|报告|显示|指出|表明|官方|大学|论文|调查|统计)', window):
            cited += 1
    details["cited_fact_count"] = cited
    details["uncited_fact_count"] = fact_count - cited
    if fact_count > 0 and cited / fact_count < 0.5:
        score -= 8
        suggestions.append(f"有{fact_count - cited}处数据/数字未就近标注来源，建议为关键数字补充出处（如'根据XX研究报告'），避免被判定为无依据陈述")

    return min(max(score, 0), 100), suggestions, details


def analyze_structure(text, paragraphs):
    """维度四：结构化程度分析"""
    score = 50
    suggestions = []
    details = {}

    h1_count = len(re.findall(r'^#\s+', text, re.MULTILINE))
    h2_count = len(re.findall(r'^##\s+', text, re.MULTILINE))
    h3_count = len(re.findall(r'^###\s+', text, re.MULTILINE))
    details["h1_count"] = h1_count
    details["h2_count"] = h2_count
    details["h3_count"] = h3_count

    if h2_count >= 3:
        score += 15
    elif h2_count >= 1:
        score += 8
    else:
        suggestions.append("建议使用H2标题将内容分为3个以上的主题区块")

    unordered_lists = len(re.findall(r'^[\s]*[-*]\s+', text, re.MULTILINE))
    ordered_lists = len(re.findall(r'^[\s]*\d+[.)、]\s+', text, re.MULTILINE))
    total_list_items = unordered_lists + ordered_lists
    details["unordered_list_items"] = unordered_lists
    details["ordered_list_items"] = ordered_lists

    if total_list_items >= 8:
        score += 15
    elif total_list_items >= 4:
        score += 10
    elif total_list_items >= 1:
        score += 5
    else:
        suggestions.append("建议使用列表（有序或无序）组织要点，列表比段落更容易被AI提取")

    headings = re.findall(r'^#{1,3}\s+(.+)$', text, re.MULTILINE)
    question_titles = 0
    number_titles = 0
    for h in headings:
        if re.search(r'[？?]|如何|怎么|什么|为什么|哪些|能否', h):
            question_titles += 1
        if re.search(r'\d', h):
            number_titles += 1
    details["question_style_titles"] = question_titles
    details["titles_with_numbers"] = number_titles

    if question_titles >= 2 or number_titles >= 2:
        score += 10
    elif question_titles >= 1 or number_titles >= 1:
        score += 5
    else:
        suggestions.append("建议标题直接回答用户问题或包含数字（如'GEO怎么写？5个核心策略'）")

    has_faq = bool(re.search(r'(?:FAQ|常见问题|常见问答|问答)', text, re.IGNORECASE))
    details["has_faq_section"] = has_faq
    if has_faq:
        score += 10
    else:
        suggestions.append("建议添加FAQ章节，列出用户高频问题并直接回答")

    return min(max(score, 0), 100), suggestions, details


def analyze_citation_quality(text, paragraphs):
    """维度五：引用与来源质量分析"""
    score = 50
    suggestions = []
    details = {}

    clean = strip_noise(text)
    source_count = count_unique(SOURCE_PATTERNS, clean)
    details["source_mention_count"] = source_count

    if source_count >= 5:
        score += 25
    elif source_count >= 3:
        score += 18
    elif source_count >= 1:
        score += 8
    else:
        suggestions.append("内容为零来源标注，建议为关键数据和声明添加来源（如'根据XX研究报告'）")

    quote_count = count_unique(QUOTE_PATTERNS, clean)
    details["quote_count"] = quote_count
    if quote_count >= 3:
        score += 15
    elif quote_count >= 1:
        score += 8
    else:
        suggestions.append("建议添加1-2条权威来源的直接引用，增强内容可信度")

    authority_types = 0
    for pattern in AUTHORITY_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            authority_types += 1
    details["authority_source_types"] = authority_types
    if authority_types >= 3:
        score += 10
    elif authority_types >= 2:
        score += 6
    else:
        suggestions.append("建议引用多种类型的权威来源（学术论文、官方数据、行业报告等）")

    # 事实与来源的关联性：有数字但几乎无来源 -> 强提示
    fact_spans = iter_unique_matches(NUMBER_PATTERNS, clean)
    cited = 0
    for s, e, _ in fact_spans:
        window = clean[max(0, s - 40): min(len(clean), e + 40)]
        if re.search(r'(根据|据|来源|研究|报告|显示|指出|表明|官方|大学|论文|调查|统计)', window):
            cited += 1
    details["facts_total"] = len(fact_spans)
    details["facts_with_source"] = cited
    if len(fact_spans) >= 3 and cited == 0:
        score -= 10
        suggestions.append("文中含多处数据但完全未标注来源，建议至少为核心数字补充权威出处")

    return min(max(score, 0), 100), suggestions, details


# ===== 报告生成 =====

def generate_report(scores, all_suggestions, all_details, platform="general", platform_notes=None, platform_suggestions=None):
    """生成综合评分报告"""
    total_score = sum(scores.values()) / len(scores)

    if total_score >= 85:
        grade = "A"
        grade_desc = "优秀 - 内容高度适配AI搜索引擎引用"
    elif total_score >= 70:
        grade = "B"
        grade_desc = "良好 - 内容基本满足GEO要求，部分维度可优化"
    elif total_score >= 55:
        grade = "C"
        grade_desc = "一般 - 内容存在明显短板，需要针对性优化"
    else:
        grade = "D"
        grade_desc = "较差 - 内容需要大幅重构以适配AI搜索引擎"

    dim_names = {
        "extractability": "可提取性",
        "entity_density": "实体密度",
        "factual_density": "事实密度",
        "structure": "结构化程度",
        "citation": "引用质量",
    }

    priority_suggestions = []
    # 通用五维建议（type=dimension）
    for dim in scores:
        for s in all_suggestions.get(dim, []):
            priority_suggestions.append({
                "type": "dimension",
                "dimension": dim_names.get(dim, dim),
                "dimension_key": dim,
                "current_score": scores[dim],
                "suggestion": s,
            })
    # 平台专属建议（type=platform，仅当用户选定非通用平台时存在）
    for ps in (platform_suggestions or []):
        dim = ps["dimension"]
        priority_suggestions.append({
            "type": "platform",
            "platform": platform,
            "platform_label": PLATFORM_LABELS.get(platform, platform),
            "dimension": dim_names.get(dim, dim),
            "dimension_key": dim,
            "current_score": scores.get(dim, 0),
            "suggestion": ps["suggestion"],
        })

    # 排序：平台专属建议优先（与用户目标最相关），其次按维度分升序（分越低越优先）
    type_rank = {"platform": 0, "dimension": 1}
    priority_suggestions.sort(key=lambda x: (type_rank[x["type"]], x["current_score"]))

    report = {
        "overall_score": round(total_score, 1),
        "grade": grade,
        "grade_description": grade_desc,
        "dimension_scores": {
            "extractability": {"score": scores["extractability"], "label": "可提取性"},
            "entity_density": {"score": scores["entity_density"], "label": "实体密度"},
            "factual_density": {"score": scores["factual_density"], "label": "事实密度"},
            "structure": {"score": scores["structure"], "label": "结构化程度"},
            "citation": {"score": scores["citation"], "label": "引用质量"},
        },
        "analysis_details": all_details,
        "optimization_suggestions": priority_suggestions,
        "platform": platform,
        "platform_label": PLATFORM_LABELS.get(platform, platform),
        "platform_notes": platform_notes or [],
        "summary": f"综合评分{round(total_score, 1)}分（{grade}级）。{grade_desc}。共{len(priority_suggestions)}条优化建议。",
    }
    return report


def format_text_report(report):
    lines = []
    lines.append("=" * 42)
    lines.append("GEO 内容评分报告")
    lines.append("=" * 42)
    lines.append(f"目标平台：{report.get('platform_label', report.get('platform', 'general'))}")
    lines.append(f"综合评分：{report['overall_score']} 分（{report['grade']}级）")
    lines.append(report["grade_description"])
    for n in report.get("platform_notes", []):
        lines.append(f"  · {n}")
    lines.append("")
    lines.append("维度得分：")
    for k, v in report["dimension_scores"].items():
        lines.append(f"  {v['label']:<6} {v['score']}")
    lines.append("")
    sugg = report["optimization_suggestions"]
    lines.append(f"优化建议（共{len(sugg)}条，按优先级）：")
    if not sugg:
        lines.append("  （暂无，继续保持）")
    for i, s in enumerate(sugg, 1):
        tag = " [平台]" if s.get("type") == "platform" else ""
        lines.append(f"  {i}. [{s['dimension']} {s['current_score']}]{tag} {s['suggestion']}")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="GEO内容评分分析器 - 对文章进行生成式引擎优化五维度评分")
    parser.add_argument("--file", required=True, help="待分析的文章文件路径")
    parser.add_argument("--format", choices=["json", "text"], default="json", help="输出格式：json（默认）或 text（人类可读）")
    parser.add_argument("--platform", default="general", choices=list(PLATFORM_LABELS.keys()),
                        help="目标AI平台：general/chatgpt/perplexity/doubao/kimi/tongyi/wenxin/deepseek/hunyuan/zhipu，启用平台专属检查")
    parser.add_argument("--summary", action="store_true", help="仅输出精简评分摘要（平台+总分+维度分+平台专属建议）")
    args = parser.parse_args()

    text = read_content(args.file)
    if len(text.strip()) < 80:
        msg = "文章内容过短（少于80字），无法进行有效分析"
        print(json.dumps({"error": msg}, ensure_ascii=False) if args.format == "json" else msg)
        sys.exit(1)

    paragraphs = split_paragraphs(text)

    scores = {}
    all_suggestions = {}
    all_details = {}

    scores["extractability"], all_suggestions["extractability"], all_details["extractability"] = analyze_extractability(text, paragraphs)
    scores["entity_density"], all_suggestions["entity_density"], all_details["entity_density"] = analyze_entity_density(text, paragraphs)
    scores["factual_density"], all_suggestions["factual_density"], all_details["factual_density"] = analyze_factual_density(text, paragraphs)
    scores["structure"], all_suggestions["structure"], all_details["structure"] = analyze_structure(text, paragraphs)
    scores["citation"], all_suggestions["citation"], all_details["citation"] = analyze_citation_quality(text, paragraphs)

    platform_suggestions = []
    platform_notes = apply_platform_checks(args.platform, text, paragraphs, scores, all_suggestions, all_details, platform_suggestions)
    report = generate_report(scores, all_suggestions, all_details, args.platform, platform_notes, platform_suggestions)

    if args.summary:
        summary = {
            "platform": report["platform"],
            "platform_label": report["platform_label"],
            "overall_score": report["overall_score"],
            "grade": report["grade"],
            "dimension_scores": {k: v["score"] for k, v in report["dimension_scores"].items()},
            "platform_notes": report["platform_notes"],
            "platform_suggestions": [s["suggestion"] for s in report["optimization_suggestions"]
                                     if s.get("type") == "platform"],
        }
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        sys.exit(0)

    if args.format == "text":
        print(format_text_report(report))
    else:
        print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
