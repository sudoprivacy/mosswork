#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
山海经 Skill · 最佳季节路线推荐器
用法：python3 season_matrix.py                    # 显示全年月份矩阵
      python3 season_matrix.py 10                  # 查看某月最佳路线 TOP 10
      python3 season_matrix.py --list              # 列出所有路线
功能：根据月份推荐最佳徒步路线，支持国内/国外/雪山分类筛选
"""

import sys
import json
from datetime import datetime

# 路线季节数据库（基于v4数据 + 行业经验）
ROUTES = [
    # ===== 国内 入门级 =====
    {"name": "虎跳峡高路", "months": [2,3,4,5,9,10,11], "tier": "入门", "region": "国内", "elev": 2660},
    {"name": "武功山反穿", "months": [4,5,6,7,8,9,10], "tier": "入门", "region": "国内", "elev": 1918},
    {"name": "麦理浩径精华", "months": [10,11,12,1,2,3,4], "tier": "入门", "region": "国内(HK)", "elev": 957},
    {"name": "库拉岗日", "months": [4,5,6,7,8,9,10], "tier": "入门", "region": "国内", "elev": 5363},
    {"name": "漓江徒步", "months": [3,4,5,9,10,11], "tier": "入门", "region": "国内", "elev": 1100},
    {"name": "龙脊梯田", "months": [4,5,9,10], "tier": "入门", "region": "国内", "elev": 2142},
    {"name": "三峡红叶", "months": [11,12], "tier": "入门", "region": "国内", "elev": 1370},
    {"name": "林海雪原", "months": [12,1,2], "tier": "入门", "region": "国内", "elev": 1696},
    {"name": "腾格里沙漠", "months": [4,5,6,7,8,9,10], "tier": "入门", "region": "国内", "elev": 1345},
    # ===== 国内 进阶级 =====
    {"name": "雨崩转山", "months": [2,3,4,5,6,7,8,9,10,11], "tier": "进阶", "region": "国内", "elev": 3800},
    {"name": "喀拉峻百公里", "months": [5,6,7], "tier": "进阶", "region": "国内", "elev": 2920},
    {"name": "长穿毕", "months": [6,7,8,9,10,11], "tier": "进阶", "region": "国内", "elev": 4660},
    {"name": "乌孙古道", "months": [6,7,8,9,10], "tier": "进阶", "region": "国内", "elev": 3830},
    {"name": "贡嘎西南坡", "months": [5,6,7,8,9,10,11], "tier": "进阶", "region": "国内", "elev": 4500},
    {"name": "格聂C线", "months": [5,6,7,8,9,10], "tier": "进阶", "region": "国内", "elev": 4980},
    {"name": "洛克线", "months": [5,6,7,8,9,10], "tier": "进阶", "region": "国内", "elev": 4750},
    {"name": "珠峰东坡", "months": [5,6,9,10], "tier": "进阶", "region": "国内", "elev": 5350},
    {"name": "亚丁大转", "months": [5,6,7,8,9,10], "tier": "进阶", "region": "国内", "elev": 5036},
    {"name": "扎尕那", "months": [5,6,7,8,9,10], "tier": "进阶", "region": "国内", "elev": 4140},
    {"name": "墨脱徒步", "months": [5,6,7,8,9,10], "tier": "进阶", "region": "国内", "elev": 4200},
    {"name": "他念他翁", "months": [5,6,7,8,9,10], "tier": "进阶", "region": "国内", "elev": 4970},
    # ===== 国内 自虐/世界级 =====
    {"name": "狼塔C+V", "months": [8,9,10], "tier": "自虐", "region": "国内", "elev": 4010},
    {"name": "阿里转山(冈仁波齐)", "months": [5,6,7,8,9,10], "tier": "自虐", "region": "国内", "elev": 5630},
    # ===== 雪山 =====
    {"name": "四姑娘山大峰", "months": [5,6,7,8,9,10], "tier": "雪山", "region": "国内", "elev": 5025},
    {"name": "四姑娘山二峰", "months": [5,6,7,8,9,10], "tier": "雪山", "region": "国内", "elev": 5276},
    {"name": "哈巴雪山", "months": [4,5,6,7,8,9,10,11,12], "tier": "雪山", "region": "国内", "elev": 4370},
    {"name": "玉珠峰", "months": [5,6,7,8,9,10], "tier": "雪山", "region": "国内", "elev": 6178},
    {"name": "那玛峰", "months": [5,6,7,8,9,10,11], "tier": "雪山", "region": "国内", "elev": 5588},
    # ===== 国外 =====
    {"name": "TMB勃朗峰环线", "months": [6,7,8,9], "tier": "世界级", "region": "欧洲", "elev": 2714},
    {"name": "多洛米蒂", "months": [6,7,8,9,10], "tier": "世界级", "region": "欧洲", "elev": 2945},
    {"name": "西班牙朝圣之路", "months": [4,5,6,9,10], "tier": "入门", "region": "欧洲", "elev": 1650},
    {"name": "挪威三石", "months": [7,8], "tier": "进阶", "region": "欧洲", "elev": 1116},
    {"name": "EBC往返线", "months": [3,4,5,10,11], "tier": "世界级", "region": "尼泊尔", "elev": 5550},
    {"name": "ACT大环线", "months": [3,4,5,10,11], "tier": "世界级", "region": "尼泊尔", "elev": 5416},
    {"name": "布恩山+ABC", "months": [3,4,5,10,11,12], "tier": "进阶", "region": "尼泊尔", "elev": 4130},
    {"name": "鱼尾峰环线", "months": [10,11,12,1,2,3,4,5], "tier": "进阶", "region": "尼泊尔", "elev": 4500},
    {"name": "EBC三垭口大环", "months": [4,5,10,11], "tier": "自虐", "region": "尼泊尔", "elev": 5106},
    {"name": "日本熊野古道", "months": [3,4,5,10,11], "tier": "入门", "region": "日本", "elev": 700},
    {"name": "冰岛兰德曼纳劳卡", "months": [6,7,8], "tier": "进阶", "region": "冰岛", "elev": 1020},
    {"name": "乞力马扎罗", "months": [1,2,6,7,8,9,10,11,12], "tier": "雪山", "region": "非洲", "elev": 5895},
    {"name": "格鲁吉亚全景", "months": [5,6,7,8,9,10], "tier": "入门", "region": "中亚", "elev": 3300},
]

# 月份名称
MONTH_NAMES = ["","1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"]
SEASON_EMOJI = {1:"❄️",2:"❄️",3:"🌸",4:"🌸",5:"🌿",6:"☀️",7:"☀️",8:"☀️",9:"🍂",10:"🍂",11:"🍂",12:"❄️"}

def print_full_matrix():
    """打印全年月份矩阵"""
    print(f"\n{'='*90}")
    print(f"📅 山海经 · 全年最佳徒步季节矩阵")
    print(f"{'='*90}")
    
    # 表头
    header = f"{'路线':<22s}"
    for m in range(1, 13):
        header += f" {m:>2s}"
    print(header)
    print("-" * 90)
    
    for route in ROUTES:
        row = f"{route['name']:<22s}"
        for m in range(1, 13):
            if m in route["months"]:
                row += "  ●"
            else:
                row += "  ·"
        print(row)
    
    print(f"\n● = 推荐季节   · = 不推荐（雨季/封山/极端天气）")
    print(f"⚠️ 高海拔线路（>4000m）最佳窗口通常更窄，请结合具体年份天气判断")


def print_month_top(month_num, limit=15):
    """打印某月TOP路线"""
    valid = [r for r in ROUTES if month_num in r["months"]]
    # 按海拔+难度排序（优先推荐当季最具代表性的）
    valid.sort(key=lambda r: (r["elev"], len(r["months"])))
    
    print(f"\n{'='*60}")
    print(f"📅 {month_num}月 ({MONTH_NAMES[month_num]}) — 最佳徒步路线 TOP {min(limit, len(valid))}")
    print(f"{SEASON_EMOJI.get(month_num,'')} 季节特征")
    print(f"{'='*60}")
    print(f"\n{'排名':<4s} {'路线':<20s} {'等级':<6s} {'地区':<8s} {'海拔':<8s}")
    print("-"*56)
    
    for i, r in enumerate(valid[:limit], 1):
        print(f"  {i:<2}  {r['name']:<20s} {r['tier']:<6s} {r['region']:<8s} {r['elev']}m")
    
    if not valid:
        print("  （该月无推荐路线，可能为极端天气月份）")


def list_routes():
    """列出所有路线"""
    print(f"\n📋 共收录 {len(ROUTES)} 条路线：\n")
    for region in ["国内", "国内(HK)", "尼泊尔", "欧洲", "日本", "冰岛", "非洲", "中亚"]:
        routes = [r for r in ROUTES if r["region"] == region]
        if routes:
            print(f"\n【{region}】({len(routes)}条)")
            for r in routes:
                months_str = ",".join([MONTH_NAMES[m] for m in r["months"]])
                print(f"  • {r['name']:<18s} | {r['tier']:<6s} | {r['elev']}m | 最佳: {months_str}")


if __name__ == "__main__":
    args = sys.argv[1:]
    
    if not args or (len(args) == 1 and args[0].isdigit()):
        month = int(args[0]) if args and args[0].isdigit() else datetime.now().month
        print_month_top(month)
        print("\n提示: 输入月份查看该月推荐，如: python3 season_matrix.py 10")
        print("      无参数显示当前月份推荐，--matrix 显示全年矩阵")
        print("      --list 列出所有路线")
        
    elif "--matrix" in args:
        print_full_matrix()
        
    elif "--list" in args:
        list_routes()
        
    else:
        # 尝试当作月份解析
        try:
            month = int(args[0])
            if 1 <= month <= 12:
                print_month_top(month)
            else:
                print("❌ 请输入 1-12 的月份")
                sys.exit(1)
        except ValueError:
            print(f"❌ 未知参数: {' '.join(args)}")
            print("用法:")
            print("  python3 season_matrix.py          # 当月推荐")
            print("  python3 season_matrix.py 10       # 10月推荐")
            print("  python3 season_matrix.py --matrix # 全年矩阵")
            print("  python3 season_matrix.py --list   # 路线列表")
