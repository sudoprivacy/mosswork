#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
山海经 Skill · 装备打包清单生成器
用法：python3 packing_checklist.py "雨崩转山"
功能：根据路线名称自动匹配装备需求，输出可勾选的打包清单
"""

import sys, os
import json

# 路线-难度映射（基于v4数据的关键参数）
ROUTE_PROFILES = {
    # 入门级（低海拔/短距离/设施好）
    "虎跳峡": {"tier": "entry", "elevation": 2660, "days": 3, "camping": False},
    "武功山": {"tier": "entry", "elevation": 1918, "days": 3, "camping": True},
    "麦理浩径": {"tier": "entry", "elevation": 957, "days": 3, "camping": False},
    "库拉岗日": {"tier": "entry", "elevation": 5363, "days": 7, "camping": False},
    "漓江徒步": {"tier": "entry", "elevation": 1100, "days": 5, "camping": False},
    "龙脊梯田": {"tier": "entry", "elevation": 2142, "days": 6, "camping": False},
    # 进阶级
    "雨崩转山": {"tier": "advanced", "elevation": 3800, "days": 6, "camping": True},
    "喀拉峻百公里": {"tier": "advanced", "elevation": 2920, "days": 7, "camping": True},
    "长穿毕": {"tier": "advanced", "elevation": 4660, "days": 5, "camping": True},
    "乌孙古道": {"tier": "advanced", "elevation": 3830, "days": 9, "camping": True},
    "贡嘎西南坡": {"tier": "advanced", "elevation": 4500, "days": 6, "camping": True},
    "格聂C线": {"tier": "advanced", "elevation": 4980, "days": 9, "camping": True},
    "洛克线": {"tier": "advanced", "elevation": 4750, "days": 8, "camping": True},
    "珠峰东坡": {"tier": "advanced", "elevation": 5350, "days": 12, "camping": True},
    "亚丁大转": {"tier": "advanced", "elevation": 5036, "days": 9, "camping": True},
    "扎尕那": {"tier": "advanced", "elevation": 4140, "days": 7, "camping": True},
    # 自虐级
    "狼塔": {"tier": "extreme", "elevation": 4010, "days": 12, "camping": True},
    "阿里转山": {"tier": "extreme", "elevation": 5630, "days": 11, "camping": True},
    "EBC": {"tier": "extreme", "elevation": 5550, "days": 13, "camping": True},
    "ACT": {"tier": "extreme", "elevation": 5416, "days": 14, "camping": True},
    "TMB": {"tier": "extreme", "elevation": 2714, "days": 11, "camping": False},  # 山屋
}

# 基础装备库（按类别）
GEAR_BASE = {
    "服装": [
        ("冲锋衣裤（硬壳，GTX级别）", True),
        ("抓绒/薄羽绒中间层", True),
        ("速干T恤×2-3件", True),
        ("速干裤子×2条（一条备用）", True),
        ("羊毛袜×3-4双（美利奴优先）", True),
        ("内衣裤套装×2套", True),
        ("遮阳帽 + 抓绒帽（高海拔必备）", True),
        ("手套（薄款+厚款各一）", True),
        ("雨裙或轻量雨衣", True),
    ],
    "鞋具": [
        ("中帮防水登山鞋（已磨合至少50km）", True),
        ("营地拖鞋（解放双脚神器）", True),
        ("雪套（雪地/碎石路段）", "snow"),
    ],
    "背包": [
        (f"登山包（{'50-65L' if __import__('json').loads('false') else '50-65L'}重装 / 30L轻装）", True),
        ("防雨罩（必须，背包不防水）", True),
        ("压缩袋×2-3个（衣物分类压缩）", True),
    ],
    "睡眠系统": [
        ("睡袋（温标需低于夜间最低温10℃以上）", "camp"),
        ("防潮垫（R值2.0+）", "camp"),
        ("枕头（充气或衣物替代）", "camp"),
    ],
    "导航通讯": [
        ("手机 + 离线地图（两步路/奥维预下载轨迹）", True),
        ("充电宝（20000mAh×1-2个）", True),
        ("头灯（备用电池）", True),
        ("纸图+罗盘（电子设备失效时的保底）", "adv"),
        ("卫星电话/InReach（无信号区域必备）", "ext"),
    ],
    "水具饮食": [
        ("水壶/水袋（总容量≥2L）", True),
        ("炉头+气罐（煮路餐/热水）", "camp"),
        ("餐具（钛杯+折叠勺叉）", True),
        ("路餐（每日：能量胶2+坚果+牛肉干+饼干）", True),
    ],
    "急救安全": [
        ("急救包（绷带/止血带/纱布/碘伏/创可贴）", True),
        ("个人药品（布洛芬/乙酰唑胺/蒙脱石散/个人处方药）", True),
        ("防晒霜SPF50+ + 唇膏", True),
        ("登山杖（一对，减负30%膝盖压力）", True),
        ("保险单打印件（含救援条款确认）", True),
    ],
    "其他": [
        ("身份证/边防证/许可证原件", True),
        ("现金（山区无信号时唯一支付方式）", True),
        ("垃圾袋（带走所有垃圾）", True),
        ("湿纸巾+手消", True),
        ("相机/GoPro（选带）", False),
    ]
}


def match_route(name):
    """模糊匹配路线名"""
    name = name.strip()
    for key in ROUTE_PROFILES:
        if key in name or name in key:
            return key, ROUTE_PROFILES[key]
    return None, None


def generate_checklist(route_name):
    """生成装备清单"""
    key, profile = match_route(route_name)
    
    if not profile:
        print(f"⚠️ 未找到「{route_name}」的路线档案，生成通用清单。")
        profile = {
            "tier": "unknown",
            "elevation": 3000,
            "days": 5,
            "camping": True,
        }
    
    tier = profile["tier"]
    elev = profile["elevation"]
    days = profile["days"]
    need_camp = profile["camping"]
    
    # 判定规则
    is_high = elev >= 3500
    is_long = days >= 7
    is_extreme = tier == "extreme"
    
    print(f"\n{'='*60}")
    print(f"🎒 {route_name or '通用'} — 装备打包清单")
    print(f"{'='*60}")
    print(f"📍 等级: {'入门' if tier=='entry' else '进阶' if tier=='advanced' else '自虐/世界级' if tier=='extreme' else '未知'}")
    print(f"🏔 最高海拔: {elev}m {'⚠️ 高海拔' if is_high else ''}")
    print(f"📅 天数: {days}天 {'📦 需露营装备' if need_camp else '🏠 山屋/客栈为主'}")
    print(f"{'='*60}\n")
    
    total_items = 0
    checked_items = 0
    
    for category, items in GEAR_BASE.items():
        print(f"\n## 📦 {category}")
        print("-" * 40)
        
        for item, condition in items:
            include = True
            
            if condition is True:
                include = True
            elif condition is False:
                include = False
            elif condition == "camp":
                include = need_camp
            elif condition == "snow":
                include = is_high or is_extreme
            elif condition == "adv":
                include = is_long or is_extreme
            elif condition == "ext":
                include = is_extreme
            
            if include:
                total_items += 1
                checked_items += 1
                print(f"  ☑️ {item}")
            else:
                print(f"  ☐ {item} （本次不需要）")
    
    print(f"\n{'='*60}")
    print(f"✅ 需携带: {checked_items} 项")
    print(f"💡 提示:")
    if is_high:
        print(f"   • 高海拔路线建议额外准备: 乙酰唑胺(预防高反)、血氧仪(监测)")
    if need_camp:
        print(f"   • 露营路线睡袋温标建议: 最低气温-10℃ → 选 -15℃~ -20℃ 睡袋")
    if is_extreme:
        print(f"   • 自虐级路线强烈建议: 卫星通讯设备(InReach/Zoleo) + 含直升机救援的保险")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 packing_checklist.py <路线名称>")
        print("示例: python3 packing_checklist.py 雨崩转山")
        print("\n可用路线示例:")
        for r in sorted(ROUTE_PROFILES.keys()):
            p = ROUTE_PROFILES[r]
            print(f"  {r:12s} | {p['elevation']}m | {p['days']}天 | {'露营' if p['camping'] else '客栈'}")
        sys.exit(1)
    
    route_name = " ".join(sys.argv[1:])
    generate_checklist(route_name)
