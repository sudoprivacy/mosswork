# -*- coding: utf-8 -*-
# gmai-travel-itinerary-checker-0e7c core (unique engine, stdlib json+re+datetime)
"""旅行行程合理性引擎：时间不可达、闭馆日、交通断裂、预算缺口。"""
import json
import re
from datetime import datetime, timedelta

_DT_FORMATS = ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
                "%Y-%m-%d", "%Y/%m/%d %H:%M", "%Y/%m/%d")
_CLOSED_DAY_MAP = {"周一": 0, "周二": 1, "周三": 2, "周四": 3, "周五": 4, "周六": 5, "周日": 6,
                    "星期一": 0, "星期二": 1, "星期三": 2, "星期四": 3, "星期五": 4,
                    "星期六": 5, "星期日": 6, "星期天": 6, "monday": 0, "tuesday": 1,
                    "wednesday": 2, "thursday": 3, "friday": 4, "saturday": 5, "sunday": 6}


def _finding(rule, severity, line, desc, evidence, suggestion, path):
    return {"rule": rule, "severity": severity, "line": int(line),
            "description": desc, "evidence": str(evidence).strip()[:120],
            "suggestion": suggestion, "path": path}


def _parse_dt(raw):
    if raw is None:
        return None
    s = str(raw).strip()
    for fmt in _DT_FORMATS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def _to_num(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", "").replace(" ", "").replace("¥", "").replace("￥", "").replace("元", "")
    m = re.match(r"^-?\d+(?:\.\d+)?", s)
    return float(m.group(0)) if m else None


def _collect(payload):
    bundles = []
    if isinstance(payload, dict) and isinstance(payload.get("itinerary"), list):
        items = [i for i in payload["itinerary"] if isinstance(i, dict)]
        if items:
            bundles.append(("<inline>", items, payload))
    for item in (payload.get("files") or []) if isinstance(payload, dict) else []:
        path = item.get("path", "<file>")
        if not str(path).lower().endswith(".json"):
            continue
        try:
            doc = json.loads(item.get("content") or "")
        except (ValueError, TypeError):
            continue
        if isinstance(doc, dict) and isinstance(doc.get("itinerary"), list):
            items = [i for i in doc["itinerary"] if isinstance(i, dict)]
            if items:
                bundles.append((path, items, doc))
    return bundles


def check_travel_itinerary(payload):
    findings = []
    for fpath, items, owner in _collect(payload or {}):
        cfg = owner.get("config") if isinstance(owner, dict) and isinstance(owner.get("config"), dict) else {}
        budget = _to_num(cfg.get("budget") or owner.get("budget"))
        transit_speed = float(cfg.get("transit_speed_kmh", 40))

        parsed = []
        for i, item in enumerate(items, 1):
            tp = str(item.get("type") or item.get("category") or "").lower()
            start = _parse_dt(item.get("start") or item.get("start_time") or item.get("time"))
            end = _parse_dt(item.get("end") or item.get("end_time"))
            location = str(item.get("location") or item.get("place") or item.get("name") or "")
            cost = _to_num(item.get("cost") or item.get("price") or item.get("费用"))
            closed_days = item.get("closed_days") or item.get("闭馆日") or []
            if isinstance(closed_days, str):
                closed_days = [closed_days]
            duration_min = _to_num(item.get("duration_minutes") or item.get("时长"))
            distance_km = _to_num(item.get("distance_km") or item.get("距离"))
            transit_from = str(item.get("from") or item.get("departure") or "")
            transit_to = str(item.get("to") or item.get("arrival") or "")
            parsed.append({
                "idx": i, "type": tp, "start": start, "end": end, "location": location,
                "cost": cost, "closed_days": closed_days, "duration_min": duration_min,
                "distance_km": distance_km, "transit_from": transit_from, "transit_to": transit_to,
                "raw": item
            })

        # ---- time_unreachable：时间不可达 ----
        for j in range(len(parsed) - 1):
            cur, nxt = parsed[j], parsed[j + 1]
            if cur["end"] and nxt["start"]:
                gap = (nxt["start"] - cur["end"]).total_seconds() / 3600  # hours
                if gap < 0:
                    findings.append(_finding(
                        "time_unreachable", "Critical", cur["idx"],
                        "第%d项结束 %s 晚于第%d项开始 %s，时间倒置" % (cur["idx"], cur["end"], nxt["idx"], nxt["start"]),
                        "gap=%.1fh line_a=%d line_b=%d" % (gap, cur["idx"], nxt["idx"]),
                        "行程时间不得倒置，重新排序或删除冲突项", fpath))
                elif gap == 0 and cur["location"] != nxt["location"] and cur["type"] != "transit" and nxt["type"] != "transit":
                    findings.append(_finding(
                        "time_unreachable", "Major", nxt["idx"],
                        "第%d项结束与第%d项开始时间相同但地点不同(%s→%s)，无通勤时间" % (cur["idx"], nxt["idx"], cur["location"], nxt["location"]),
                        "gap=0 locations_differ=yes",
                        "不同地点间需预留交通时间，至少30分钟", fpath))
                else:
                    # 检查距离与时间是否合理
                    if cur["type"] == "transit" and nxt["type"] != "transit":
                        # 当前是交通段，检查距离/时间比
                        if cur["distance_km"] and gap > 0:
                            speed = cur["distance_km"] / gap
                            if speed > 300:
                                findings.append(_finding(
                                    "time_unreachable", "Major", cur["idx"],
                                    "交通段 %s→%s 距离 %gkm 分配 %gh，速度 %gkm/h 不可达" % (cur["transit_from"], cur["transit_to"], cur["distance_km"], gap, speed),
                                    "speed=%.0fkm/h gap=%.1fh dist=%gkm" % (speed, gap, cur["distance_km"]),
                                    "根据交通方式预留合理时间，高铁800km/h+需3h+", fpath))

        # ---- closed_day_visit：闭馆日参观 ----
        for p in parsed:
            if p["type"] in ("attraction", "museum", "景点", "场馆", "scenic") and p["closed_days"]:
                if p["start"]:
                    weekday = p["start"].weekday()
                    closed_nums = set()
                    for cd in p["closed_days"]:
                        cd_str = str(cd).strip()
                        if cd_str in _CLOSED_DAY_MAP:
                            closed_nums.add(_CLOSED_DAY_MAP[cd_str])
                    if weekday in closed_nums:
                        day_name = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][weekday]
                        findings.append(_finding(
                            "closed_day_visit", "Major", p["idx"],
                            "景点 %s 在 %s 闭馆但行程安排了参观" % (p["location"], day_name),
                            "location=%s weekday=%d closed=%s" % (p["location"], weekday, p["closed_days"]),
                            "闭馆日不安排参观，改至开放日或换景点", fpath))

        # ---- transport_break：交通断裂（前一地点与后一地点无交通段）----
        for j in range(len(parsed) - 1):
            cur, nxt = parsed[j], parsed[j + 1]
            if (cur["location"] and nxt["location"] and cur["location"] != nxt["location"]
                    and cur["type"] != "transit" and nxt["type"] != "transit"):
                # 两个不同地点的活动之间无交通段
                has_transit = any(parsed[k]["type"] == "transit" for k in range(j, j + 2))
                if not has_transit:
                    findings.append(_finding(
                        "transport_break", "Major", nxt["idx"],
                        "从 %s 到 %s 之间无交通段，地点变更但缺少交通安排" % (cur["location"], nxt["location"]),
                        "from=%s to=%s transit=missing" % (cur["location"], nxt["location"]),
                        "不同地点间需插入交通段(打车/地铁/高铁等)并预留时间", fpath))

        # ---- budget_gap：预算缺口 ----
        if budget is not None:
            total_cost = sum((p["cost"] or 0) for p in parsed)
            if total_cost > budget:
                findings.append(_finding(
                    "budget_gap", "Major", 1,
                    "行程总费用 %g 超过预算 %g，缺口 %g" % (total_cost, budget, total_cost - budget),
                    "total=%g budget=%g gap=%g" % (total_cost, budget, total_cost - budget),
                    "压缩可选项目或增加预算，优先保证交通与住宿", fpath))

    critical = sum(1 for f in findings if f["severity"] == "Critical")
    major = sum(1 for f in findings if f["severity"] == "Major")
    minor = sum(1 for f in findings if f["severity"] == "Minor")
    score = max(0, 100 - critical * 25 - major * 12 - minor * 4)
    verdict = "REJECT" if critical > 0 or major >= 2 or score < 70 else "PASS"
    summary = ("发现 %d 处行程合理性问题(Critical %d/Major %d)"
               % (len(findings), critical, major)) if findings else "行程合理性检查通过"
    suggestions = sorted({"[%s] %s" % (f["rule"], f["suggestion"]) for f in findings})[:6]
    return {"verdict": verdict, "score": score, "findings": findings,
            "summary": summary, "suggestions": suggestions}
