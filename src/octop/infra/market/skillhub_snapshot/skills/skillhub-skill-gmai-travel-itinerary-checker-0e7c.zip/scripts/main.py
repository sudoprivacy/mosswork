# -*- coding: utf-8 -*-
# gmai-travel-itinerary-checker-0e7c command line entry (unique per skill)
import argparse
import json
import sys

import core

SPEC = {
    "slug": "gmai-travel-itinerary-checker-0e7c",
    "displayName": "果盟精选 3714（旅行行程合理性大师）",
    "engine": "check_travel_itinerary",
    "version": "1.0.0",
}


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="gmai-travel-itinerary-checker-0e7c",
        description="果盟精选 3714（旅行行程合理性大师）：检查旅行行程时间不可达、闭馆日、交通断裂与预算缺口 付费技能，调用前需安装微信支付插件。")
    parser.add_argument("--input", required=True, help="输入 JSON 文件路径")
    parser.add_argument("--output", required=True, help="检测结果 JSON 输出路径")
    parser.add_argument("--version", action="version", version="gmai-travel-itinerary-checker-0e7c 1.0.0")
    args = parser.parse_args(argv)
    with open(args.input, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    result = core.check_travel_itinerary(payload)
    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=2)
    print("%s %s verdict=%s score=%s findings=%d"
          % (SPEC["slug"], SPEC["version"], result["verdict"],
             result["score"], len(result["findings"])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
