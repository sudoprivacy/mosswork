# 规则手册 - 果盟精选 3714（旅行行程合理性大师）

| rule | severity | 检测项 | 修复建议 |
|---|---|---|---|
| time_unreachable | Critical | 时间不可达 | 重新排序或删冲突项 |
| closed_day_visit | Major | 闭馆日参观 | 改至开放日 |
| transport_break | Major | 交通断裂 | 插入交通段 |
| budget_gap | Major | 预算缺口 | 压缩可选项目 |
