# 版本日志(CHANGELOG)

## v1.0.0 · 2026-08-09

**首发版本**

### 新增
- 18 文件多目录结构(`assets/` + `references/{answers,cases,cases_live,handbook,standards,theory}/`)
- 5 步路由 SOP(`references/handbook/5-step-routing.md`)
- Token 预算管理(`assets/token-budget-table.md`)
- 9 大知识库路由图(`references/answers/kb-routing-decision.md`)
- 4 大节省 Token 技巧(`references/answers/token-saver-techniques.md`)
- 长文档分片读取术(`references/handbook/5-step-routing.md`)
- 缓存复用机制(`references/theory/rag-routing-theory.md`)
- 自动归类 + 标签建议(`references/handbook/kb-optimization-checklist.md`)
- 一页纸速查卡(`assets/quick-reference.md`)

### 设计亮点
- **Token 优先**:首条强制原则
- **普通人能上手**:不假定开发者背景
- **5 步 SOP**:理论浓缩为操作
- **缓存复用**:一次检索多次复用
- **多文件协同**:18 文件,每个有实质内容

### 文件统计
- 18 文件 · 9 目录
- 平均每个文件 ~4 KB
- 总大小 ~70 KB

---

## 计划中(v1.1+)

- [ ] IMA 多模态检索适配(图片 / 音频 / 视频)
- [ ] 个人知识图谱自动构建
- [ ] 跨平台协同(WorkBuddy / QClaw / Claude Code)
- [ ] 智能剪枝(自动识别冗余内容)
- [ ] AI 自动补全(空文件夹自动补建议)

---

## 反馈渠道

- SkillHub 评论区