# IMA Token 优化官 · 总索引(index.md)

> 全库导航 — 任何时候不知道"哪个文件放什么内容",查这里。

## 速查导航

| 你想知道什么 | 看哪个文件 |
|---|---|
| **怎么用本 Skill?** | `SKILL.md`(入口) |
| **5 步路由 SOP?** | `references/handbook/5-step-routing.md` |
| **怎么节省 Token?** | `references/answers/token-saver-techniques.md` |
| **路由怎么判断?** | `references/answers/kb-routing-decision.md` |
| **Token 预算表?** | `assets/token-budget-table.md` |
| **路由规则速查?** | `assets/kb-routing-rules.md` |
| **一页纸速查?** | `assets/quick-reference.md` |
| **常见问题?** | `references/cases/common-issues.md` |
| **2026 最新技巧?** | `references/cases_live/2026-tips.md` |
| **优化清单?** | `references/handbook/kb-optimization-checklist.md` |
| **IMA 平台规则?** | `references/standards/ima-platform-rules.md` |
| **Token 策略?** | `references/standards/token-policy.md` |
| **知识库组织标准?** | `references/standards/kb-organization-standards.md` |
| **RAG 路由理论?** | `references/theory/rag-routing-theory.md` |
| **输出模板?** | `assets/output-templates.md` |

## 文件分类索引

### 📘 入口文件(4 个)
- `SKILL.md` — Skill 入口
- `README.md` — 作者维护手册
- `index.md` — 本文件(总索引)
- `CHANGELOG.md` — 版本日志

### 🛠 assets/ 工具(4 个)
- `assets/quick-reference.md` — 一页纸速查
- `assets/token-budget-table.md` — Token 预算表
- `assets/kb-routing-rules.md` — 路由规则速查
- `assets/output-templates.md` — 输出模板

### 📚 references/ 知识资产(10 个)

**answers/ 标准答案(2 个)**
- `references/answers/kb-routing-decision.md` — 知识库路由决策
- `references/answers/token-saver-techniques.md` — 节省 Token 技巧

**cases/ 案例(1 个)**
- `references/cases/common-issues.md` — 常见问题案例

**cases_live/ 最新案例(1 个)**
- `references/cases_live/2026-tips.md` — 2026 最新技巧

**handbook/ 操作手册(2 个)**
- `references/handbook/5-step-routing.md` — 5 步路由 SOP
- `references/handbook/kb-optimization-checklist.md` — 知识库优化清单

**standards/ 规范标准(3 个)**
- `references/standards/ima-platform-rules.md` — IMA 平台规则
- `references/standards/token-policy.md` — Token 策略
- `references/standards/kb-organization-standards.md` — 知识库组织标准

**theory/ 理论基础(1 个)**
- `references/theory/rag-routing-theory.md` — RAG 路由理论

## 文件统计

| 类型 | 数量 | 平均大小 |
|---|---|---|
| 入口文件 | 4 | 3 KB |
| assets/ | 4 | 4 KB |
| references/answers/ | 2 | 5 KB |
| references/cases/ | 1 | 5 KB |
| references/cases_live/ | 1 | 5 KB |
| references/handbook/ | 2 | 4 KB |
| references/standards/ | 3 | 5 KB |
| references/theory/ | 1 | 3 KB |
| **总计** | **18 个** | **~4 KB** |

---

## 快速使用路径

### 路径 1 · 节省 Token(30 秒)
```
触发"节省 Token" → 看你当前 Token 用法 → 给出优化建议
```

### 路径 2 · 智能检索(1 分钟)
```
触发"知识库路由" → 告诉 AI 你的问题 → AI 自动路由到对的知识库
```

### 路径 3 · 整理优化(批量)
```
触发"知识库整理" → 自动归类 + 标签 + 去重 → 输出整理清单
```

---

## 维护建议

- IMA 平台更新:每月检查 `references/standards/ima-platform-rules.md`
- Token 策略:每季度评估 `references/standards/token-policy.md`
- 案例库:每月补充新发现
- 路由规则:每半年根据用户反馈调整