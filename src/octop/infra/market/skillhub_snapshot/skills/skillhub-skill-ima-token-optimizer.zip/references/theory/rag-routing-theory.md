# RAG 路由理论

> 用途:深度理解 RAG 与路由机制,优化 Skill 性能。

---

## 一、RAG 基础

### 什么是 RAG

```
RAG = Retrieval-Augmented Generation
    = 检索增强生成
```

**核心思想**:
- 不要让 AI"凭空"回答
- 先检索知识库
- 把检索结果作为上下文
- AI 基于真实信息回答

### RAG 工作流程

```
用户问题
   ↓
[1] 问题分析
   ↓
[2] 检索知识库
   ↓
[3] 找到相关文档
   ↓
[4] 提取关键信息
   ↓
[5] 生成回答
   ↓
用户收到答案
```

### RAG 的优势

- ✅ 答案基于真实信息
- ✅ 可引用 / 可审计
- ✅ 减少 AI 编造
- ✅ 信息可更新

### RAG 的局限

- ❌ 检索消耗 Token
- ❌ 长文档处理难
- ❌ 语义匹配不准
- ❌ 上下文窗口限制

---

## 二、路由的本质

### 什么是路由

```
路由 = 在多个知识库中,选择加载哪些的决策
```

**路由解决的问题**:
- 9 个知识库,只用 1-2 个
- 不全库加载
- 节省 60-80% Token

### 路由的核心决策

```
决策 1:用哪个库?(主库 + 副库)
决策 2:用多少?(预算级别)
决策 3:怎么用?(摘要 / 全文 / 分片)
```

---

## 三、路由决策算法

### 算法 1 · 关键词权重

```python
def route_by_keywords(question, knowledge_bases):
    scores = {}
    for kb in knowledge_bases:
        score = 0
        for keyword in kb.keywords:
            if keyword in question:
                score += 1
        scores[kb.name] = score
    
    # 排序
    sorted_kbs = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    
    # 主库 + 副库
    main = sorted_kbs[0]
    secondary = [kb for kb in sorted_kbs[1:3] if kb[1] >= main[1] * 0.5]
    
    return main, secondary
```

### 算法 2 · 语义嵌入

```python
def route_by_embedding(question, knowledge_bases):
    question_embedding = embed(question)
    
    similarities = {}
    for kb in knowledge_bases:
        kb_embedding = embed(kb.description)
        similarity = cosine(question_embedding, kb_embedding)
        similarities[kb.name] = similarity
    
    return sorted(similarities.items(), key=lambda x: x[1], reverse=True)
```

### 算法 3 · 历史对话

```python
def route_with_history(question, history, knowledge_bases):
    # 检查历史对话,确定上下文
    if last_kb_used := find_last_kb(history):
        # 优先使用上次的库
        return last_kb_used
    
    # 否则按关键词路由
    return route_by_keywords(question, knowledge_bases)
```

---

## 四、缓存复用机制

### 为什么需要缓存

```
场景:用户在 5 分钟内问了 3 个相关问题
- 问题 1:"客户 A 的合同"
- 问题 2:"客户 A 的付款"
- 问题 3:"客户 A 的项目"

如果不缓存:
- 问题 1:检索 + 缓存(5000 tokens)
- 问题 2:重新检索(3000 tokens)
- 问题 3:重新检索(3000 tokens)
- 总:11000 tokens

如果缓存复用:
- 问题 1:检索 + 缓存(5000 tokens)
- 问题 2:复用缓存 + 部分检索(1500 tokens)
- 问题 3:复用缓存 + 部分检索(1500 tokens)
- 总:8000 tokens
- 节省:27%
```

### 缓存设计

```python
class TokenCache:
    def __init__(self, ttl_minutes=30):
        self.cache = {}
        self.ttl = ttl_minutes * 60  # 秒
    
    def get(self, key):
        if key in self.cache:
            timestamp, data = self.cache[key]
            if time.time() - timestamp < self.ttl:
                return data
            else:
                del self.cache[key]
        return None
    
    def set(self, key, data):
        self.cache[key] = (time.time(), data)
    
    def is_expired(self, key):
        if key not in self.cache:
            return True
        timestamp, _ = self.cache[key]
        return time.time() - timestamp >= self.ttl
```

### 缓存策略

**策略 1 · 时间过期**
```
默认 30 分钟过期
过期后自动重新检索
```

**策略 2 · 内容失效**
```
文件被修改 → 缓存失效
文件被删除 → 缓存失效
```

**策略 3 · 用户主动**
```
用户:"刷新缓存" → 清空所有缓存
```

---

## 五、长文档分片读取

### 为什么需要分片

```
场景:50,000 字 PDF
如果不分片:
- 一次性读 → 50,000 tokens → 超限 → 失败

如果分片:
- 按章节分(每章 3,000 字)
- 读 1 章 = 3,000 tokens
- 读 5 章 = 15,000 tokens
- 用户按需选择 → 节省 70%
```

### 分片策略

**策略 1 · 按章节**
```
适用:结构化文档(书籍 / 论文)
优点:符合用户思维
缺点:章节字数不均
```

**策略 2 · 按字数**
```
适用:非结构化文档
每 3,000 字一片
```

**策略 3 · 按主题**
```
适用:跨章节主题
先识别主题 → 按主题分片
```

### 分片元数据

```python
class DocumentChunk:
    def __init__(self, doc_id, chunk_id, content):
        self.doc_id = doc_id
        self.chunk_id = chunk_id
        self.content = content
        self.summary = generate_summary(content)
        self.keywords = extract_keywords(content)
        self.embedding = generate_embedding(content)
```

---

## 六、Token 优化理论

### Token 消耗模型

```
Total Tokens = Base + Retrieval + Reading + Summary + Context

Base = 500(系统开销)
Retrieval = N × 200(每个文档 200 tokens 检索开销)
Reading = Σ Reading_i(每个文档的读取)
Summary = 300(摘要生成)
Context = 100-2000(历史对话)
```

### 优化目标

```
minimize(Total Tokens)
subject to:
- 答案质量 ≥ 阈值
- 检索准确率 ≥ 阈值
- 用户满意度 ≥ 阈值
```

### 优化方法

**方法 1 · 减少 N(检索文档数)**
```
效果:每次检索节省 200 tokens
适用:路由精准
```

**方法 2 · 减少 Reading(单文档读取)**
```
效果:每文档节省 N tokens
适用:摘要优先 + 分片
```

**方法 3 · 减少 Context(历史对话)**
```
效果:每对话节省 100-2000 tokens
适用:清空历史 / 总结历史
```

---

## 七、跨库协同理论

### 跨库的必要性

```
场景:用户问"基于项目经验设计提案"

只查工作库:
- 有项目经验(60%)
- 缺方案模板(0%)

跨库检索:
- 工作库:项目经验(60%)
- 创作库:方案模板(30%)
- 综合答案 = 90%
```

### 跨库成本

```
跨库数:1 主 + 2 副
单库加载:N tokens
跨库总成本:N × 3 + 协同开销 = 3.5N

vs 单库:
- 单库加载:N tokens
- 信息量:60%
```

### 跨库原则

- 主库 80% + 副库 15-20%
- 跨库数 ≤ 3
- 协同开销 < 10%

---

## 八、缓存复用理论

### 复用率模型

```
命中率 = 复用次数 / 总检索次数

例:5 次检索,3 次复用
命中率 = 3/5 = 60%
节省率 = 60% × 复用成本 / 总成本
     ≈ 60% × 50% = 30%
```

### 提高命中率

- 延长缓存时间(30 分钟 → 1 小时)
- 主动识别"相关"问题
- 提供"复用提示"

---

## 九、Token 优化理论框架

### 综合优化模型

```
Token = Base(500)
     + Retrieval(N × 200)
     + Reading(Σ Reading_i)
     + Summary(300)
     + Context(100-2000)

优化方向:
- 减少 N:路由精准(节省 60-80%)
- 减少 Reading:摘要优先(节省 70%+)
- 减少 Context:清空历史(节省 50%+)
- 缓存复用:复用率 60%(节省 30%)
```

### 综合优化效果

```
无优化:16,667 tokens / 次(平均)
全优化:4,700 tokens / 次(平均)
节省:72%
```

---

## 十、未来发展

### 趋势 1 · AI 自动路由
```
IMA 1.6 计划:
- AI 自动判断问题类型
- 自动选择知识库
- 自动设置预算
```

### 趋势 2 · 智能缓存
```
未来:
- AI 预测用户下一步问题
- 主动预加载
- 自适应缓存时长
```

### 趋势 3 · 个人知识图谱
```
IMA 1.6 计划:
- 自动构建知识图谱
- 显示文件关系
- 智能推荐
```

---

> **核心心法**:**理论指导实践,实践验证理论**。
> RAG + 路由 + 缓存,是 IMA Token 优化的三大支柱。