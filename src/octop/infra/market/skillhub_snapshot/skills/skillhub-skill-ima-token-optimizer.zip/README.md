# IMA Token 优化官 · 作者维护手册

> 给 **Skill 作者 / 维护者** 看的,描述设计哲学与迭代方式。
> **使用者不需要读这个文件** — 用 `SKILL.md` 即可。

## 设计哲学

### 一、Token 优先,不堆功能

市面上很多"知识库管理 Skill"靠堆功能——整理、打标、分类、检索、生成……
本 Skill 坚持:**最优先解决"Token 浪费"**——这是 90% 用户的最大痛点。

### 二、让普通人能上手

很多"高级 Skill"假定用户是开发者,需要懂 API、懂 RAG、懂 Embedding。
本 Skill 假定用户是 **普通白领 / 学生 / 内容创作者**——他们只想"少花 Token,调对文件"。

### 三、5 步 SOP,胜过复杂理论

理论可以复杂,操作必须简单。
本 Skill 把所有理论浓缩成 **5 步 SOP** —— 用户只需说"整理我的笔记",AI 就按 SOP 走。

### 四、缓存复用是核心创新

大多数 Skill 只解决"如何检索",本 Skill 解决"如何避免重复检索"。
**一次检索,多次复用**——这是 IMA 平台的天然优势,其他工具做不到。

## 版本历史

详见 `CHANGELOG.md`。

## 怎么更新

### 触发更新
- IMA 平台新版本 → 更新 `references/standards/ima-platform-rules.md`
- IMA 新功能 → 更新 SKILL.md 的相关章节
- 用户新痛点 → 增加新章节或新文件

### 内容维护
- 案例库每季度更新
- Token 预算根据平台调整

## 使用方式

### 方式 A · IMA 内置触发
```
直接说"IMA Token 优化""知识库整理""跨库检索"
```

### 方式 B · 文件夹整体上传
把整个 `tongyue-ima-optimizer/` 文件夹上传到 IMA 知识库。
IMA 会自动识别 SKILL.md 作为入口。

### 方式 C · 单 SKILL.md 上传(简单版)
只上传 SKILL.md,其他文件可选。
功能会减少但仍可用。

## 不做的事

- ❌ 不替代 ima-knowledge / ima-note 平台内置 Skill
- ❌ 不替代专业 RAG 框架(LangChain / LlamaIndex)
- ❌ 不替代专业知识库工具(Notion AI / Obsidian Copilot)
- ❌ 不承诺所有问题都能找到答案
- ❌ 不修改用户原有知识库结构(只给建议)

## 联系反馈

- 在 SkillHub 评论区留言
- 反馈:SkillHub 评论区 / IMA 反馈通道