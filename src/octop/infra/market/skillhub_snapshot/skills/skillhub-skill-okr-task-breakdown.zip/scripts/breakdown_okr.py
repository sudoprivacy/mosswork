#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OKR/目标拆解助手 —— 确定性脚本（纯标准库，零依赖）

输入：JSON 文件 / stdin（结构见 references/input_template.json）
输出：markdown 拆解方案（目标 → 关键结果 → 周任务 三级）+ 可衡量性体检 + 周负载表

纯标准库实现，无第三方依赖。

能力版本:
  v1.0.1  IO 层加固: argparse(位置参数/--input/--output) + stdin + 编码兜底(utf-8-sig/gbk) + 退出码(0/2/3/4) + 顶层结构校验
  v1.0.2  能力增强: 盲区扫描(无负责人/无截止/无 why 等治理缺口) + --cap/--weeks 命令行覆盖 + KR 改写建议聚合
  v1.0.3  边界健壮 + 自检: settings 非数值兜底 + 超长文本/特殊字符转义 + 空值/非法枚举/负人日等边缘用例 + 内置 selftest

退出码: 0 成功 / 2 输入内容非法 / 3 文件读写或编码失败 / 4 自检失败
"""

import sys
import io
import os
import json
import argparse
import datetime
import re

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
if hasattr(sys.stderr, "buffer"):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

# ── 常量 ────────────────────────────────────────────────

# 动作型动词：以这些开头的 KR 多半是「任务」伪装成「结果」
ACTION_VERBS = [
    "上线", "完成", "开发", "推进", "优化", "建设", "搭建", "梳理", "组织",
    "召开", "编写", "输出", "交付", "启动", "落实", "跟进", "对接", "整理",
    "制定", "设计", "实现", "部署", "调研", "培训", "推广", "执行", "开展",
]

# 结果型信号词：出现即视为在描述状态/水平而非动作
RESULT_SIGNALS = ["率", "量", "数", "额", "占比", "时长", "分值", "满意度", "留存", "转化", "增长", "降低", "提升到", "达到"]

QUALITY_GATE = [(85, "✅ 合格"), (70, "⚠️ 待完善"), (0, "❌ 不合格")]

PRIORITY_ORDER = {"高": 0, "中": 1, "低": 2}


# ── 工具函数 ────────────────────────────────────────────

def die(msg, code=2):
    sys.stderr.write("❌ 输入错误：{}\n".format(msg))
    sys.exit(code)


def warn(msg):
    sys.stderr.write("⚠️ 提示：{}\n".format(msg))


def load_input(path):
    """读 JSON：支持文件 / stdin，UTF-8、BOM、GBK 自动兜底。"""
    if path:
        if not os.path.exists(path):
            die("输入文件不存在：{}".format(path), 3)
        try:
            with io.open(path, encoding="utf-8-sig") as f:
                raw = f.read()
        except UnicodeDecodeError:
            try:
                with io.open(path, encoding="gbk") as f:
                    raw = f.read()
            except Exception as e:
                die("文件编码无法识别（已尝试 utf-8/gbk）：{}".format(e), 3)
        except OSError as e:
            die("读取文件失败：{}".format(e), 3)
    else:
        if sys.stdin is None or sys.stdin.isatty():
            die("未提供输入文件，且 stdin 无数据。用法见 --help")
        raw = sys.stdin.read()
    if not raw.strip():
        die("输入为空——请至少提供 1 个目标")
    try:
        data = json.loads(raw)
    except ValueError as e:
        die("JSON 解析失败：{}".format(e))
    if not isinstance(data, dict):
        die("输入 JSON 顶层必须是对象（{{...}}），当前是 {}".format(type(data).__name__))
    return data


def emit(text, output):
    """输出：写文件（自动建目录）或打印 stdout。"""
    if output:
        try:
            d = os.path.dirname(os.path.abspath(output))
            if d and not os.path.isdir(d):
                os.makedirs(d)
            with io.open(output, "w", encoding="utf-8") as f:
                f.write(text + "\n")
        except OSError as e:
            die("写入文件失败：{}".format(e), 3)
        sys.stderr.write("[完成] 已写入 {}\n".format(output))
    else:
        sys.stdout.write(text + "\n")


def num_or(v, default):
    """v1.0.3 settings 数值兜底：非数值/None 时回退默认并告警，避免 int('') 崩。"""
    if isinstance(v, bool):
        return default
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).strip())
    except (ValueError, TypeError):
        warn("settings 数值字段非法（{}），已按默认 {} 处理".format(v, default))
        return default


def esc(s, limit=40):
    """v1.0.3 表格单元格转义：竖线转全角、去换行、超长截断，避免破表。"""
    s = str(s).replace("\r", " ").replace("\n", " ")
    s = s.replace("|", "｜")
    if len(s) > limit:
        s = s[:limit] + "…"
    return s


def parse_date(s, field):
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d"):
        try:
            return datetime.datetime.strptime(str(s).strip(), fmt).date()
        except ValueError:
            continue
    die("%s 日期格式不合法：%r（应为 YYYY-MM-DD）" % (field, s))


def has_number(text):
    return bool(re.search(r"\d", str(text or "")))


def to_float(v):
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v)
    m = re.search(r"-?\d+(?:\.\d+)?", str(v))
    return float(m.group()) if m else None


def gate(score):
    for line, label in QUALITY_GATE:
        if score >= line:
            return label
    return "❌ 不合格"


# ── KR 可衡量性体检 ────────────────────────────────────

def audit_kr(kr, obj_owner, period_end):
    """给一条 KR 打 SMART 分（满分 100），返回 (分数, 问题列表, 改写建议)"""
    stmt = str(kr.get("statement", "")).strip()
    score = 0
    problems = []
    tips = []

    target = to_float(kr.get("target"))
    baseline = to_float(kr.get("baseline"))
    unit = str(kr.get("unit", "")).strip()
    owner = str(kr.get("owner", "") or obj_owner or "").strip()
    due = kr.get("due")

    # 1) 量化目标 30
    if target is not None:
        score += 30
    elif has_number(stmt):
        score += 18
        problems.append("目标值只写在文字里，未填 `target` 字段，无法自动核算进度")
    else:
        problems.append("**没有任何量化目标**——KR 必须能用数字判定达成与否")
        tips.append("补一个明确的目标值，例如「从 X 提升到 Y」")

    # 2) 基线 20
    if baseline is not None:
        score += 20
    else:
        problems.append("缺基线值，季末无法说清「到底提升了多少」")
        tips.append("补当前水平作为基线，没有基线的目标事后一定扯皮")

    # 3) 单位 10
    if unit:
        score += 10
    elif target is not None:
        problems.append("有数字无单位（%？人？元？），口径容易被各说各话")

    # 4) 负责人 15
    if owner:
        score += 15
    else:
        problems.append("无明确负责人，集体负责等于无人负责")

    # 5) 时限 10
    if due or period_end:
        score += 10
    else:
        problems.append("无截止时间，也没有周期结束日兜底")

    # 6) 结果型表述 15
    is_action = any(stmt.startswith(v) for v in ACTION_VERBS)
    has_result_signal = any(s in stmt for s in RESULT_SIGNALS)
    if not stmt:
        problems.append("KR 描述为空")
    elif is_action and not has_result_signal:
        problems.append("**这是任务不是关键结果**——「%s…」描述的是要做的动作，而非要达成的状态" % stmt[:6])
        tips.append("把「做了什么」改写成「做完之后哪个指标变成什么样」")
    elif is_action and has_result_signal:
        score += 8
        problems.append("动词开头但带了指标，建议改成以指标为主语的表述")
    else:
        score += 15

    return min(score, 100), problems, tips


# ── 校验与规整 ──────────────────────────────────────────

def normalize(data):
    if not isinstance(data, dict):
        die("输入 JSON 顶层必须是对象")

    objectives = data.get("objectives")
    if not isinstance(objectives, list) or not objectives:
        die("`objectives` 缺失或为空，至少需要 1 个目标")

    settings = data.get("settings") or {}
    weekly_cap = num_or(settings.get("weekly_capacity_days"), 4.0)
    if weekly_cap <= 0:
        die("`settings.weekly_capacity_days` 必须为正数")

    p_start = parse_date(data.get("period_start"), "period_start")
    p_end = parse_date(data.get("period_end"), "period_end")
    if p_start and p_end and p_end < p_start:
        die("`period_end` 早于 `period_start`")

    weeks = settings.get("weeks")
    weeks = int(num_or(weeks, 0)) if weeks not in (None, "") else None
    if not weeks:
        if p_start and p_end:
            weeks = max(1, ((p_end - p_start).days + 6) // 7)
        else:
            weeks = 12
    if weeks <= 0:
        die("`settings.weeks` 必须为正整数")

    seen_oid = set()
    norm_objs = []
    for i, o in enumerate(objectives, 1):
        if not isinstance(o, dict):
            die("第 %d 个目标不是对象" % i)
        title = str(o.get("title", "")).strip()
        if not title:
            die("第 %d 个目标缺 `title`" % i)
        oid = str(o.get("id", "") or "O%d" % i).strip()
        if oid in seen_oid:
            die("目标 id 重复：%s（会导致引用错乱，请改为唯一值）" % oid)
        seen_oid.add(oid)

        krs = o.get("key_results") or []
        if not isinstance(krs, list):
            die("目标「%s」的 `key_results` 必须是数组" % title)

        norm_krs = []
        seen_kid = set()
        for j, k in enumerate(krs, 1):
            if not isinstance(k, dict):
                die("目标「%s」第 %d 条 KR 不是对象" % (title, j))
            kid = str(k.get("id", "") or "%s-KR%d" % (oid, j)).strip()
            if kid in seen_kid:
                die("目标「%s」下 KR id 重复：%s" % (title, kid))
            seen_kid.add(kid)

            tasks = k.get("tasks") or []
            if not isinstance(tasks, list):
                die("KR %s 的 `tasks` 必须是数组" % kid)
            norm_tasks = []
            for t in tasks:
                if isinstance(t, str):
                    t = {"title": t}
                if not isinstance(t, dict):
                    die("KR %s 下存在非法任务项" % kid)
                ttitle = str(t.get("title", "")).strip()
                if not ttitle:
                    die("KR %s 下有任务缺 `title`" % kid)
                eff = to_float(t.get("effort_days"))
                eff = 1.0 if eff is None or eff <= 0 else eff
                wk = t.get("week")
                try:
                    wk = int(wk) if wk not in (None, "") else None
                except (TypeError, ValueError):
                    die("KR %s 的任务「%s」week 必须是整数" % (kid, ttitle))
                if wk is not None and (wk < 1 or wk > weeks):
                    die("KR %s 的任务「%s」week=%d 超出周期范围 1-%d" % (kid, ttitle, wk, weeks))
                norm_tasks.append({
                    "title": ttitle,
                    "owner": str(t.get("owner", "") or "").strip(),
                    "effort_days": eff,
                    "week": wk,
                    "note": str(t.get("note", "") or "").strip(),
                })

            conf = to_float(k.get("confidence"))
            if conf is not None and conf > 1:
                conf = conf / 100.0
            norm_krs.append({
                "id": kid,
                "statement": str(k.get("statement", "")).strip(),
                "baseline": k.get("baseline"),
                "target": k.get("target"),
                "unit": str(k.get("unit", "") or "").strip(),
                "owner": str(k.get("owner", "") or "").strip(),
                "due": k.get("due"),
                "confidence": conf,
                "tasks": norm_tasks,
            })

        norm_objs.append({
            "id": oid,
            "title": title,
            "priority": o.get("priority") if o.get("priority") in PRIORITY_ORDER else "中",
            "owner": str(o.get("owner", "") or "").strip(),
            "why": str(o.get("why", "") or "").strip(),
            "key_results": norm_krs,
        })

    return {
        "owner": str(data.get("owner", "") or "").strip(),
        "team": str(data.get("team", "") or "").strip(),
        "period": str(data.get("period", "") or "").strip(),
        "period_start": p_start,
        "period_end": p_end,
        "weeks": weeks,
        "weekly_cap": weekly_cap,
        "objectives": norm_objs,
    }


# ── 渲染 ────────────────────────────────────────────────

def fmt_kr_target(kr):
    b, t, u = kr.get("baseline"), kr.get("target"), kr.get("unit")
    if b not in (None, "") and t not in (None, ""):
        return "%s%s → %s%s" % (b, u, t, u)
    if t not in (None, ""):
        return "目标 %s%s" % (t, u)
    return "—"


def build(ctx):
    L = []
    objs = ctx["objectives"]
    weeks = ctx["weeks"]

    all_krs = [(o, k) for o in objs for k in o["key_results"]]
    audits = {}
    for o, k in all_krs:
        audits[k["id"]] = audit_kr(k, o["owner"] or ctx["owner"], ctx["period_end"])

    n_obj = len(objs)
    n_kr = len(all_krs)
    all_tasks = [(o, k, t) for o, k in all_krs for t in k["tasks"]]
    n_task = len(all_tasks)
    total_days = sum(t["effort_days"] for _, _, t in all_tasks)

    bad = [kid for kid, (s, _, _) in audits.items() if s < 70]
    warn = [kid for kid, (s, _, _) in audits.items() if 70 <= s < 85]
    empty_kr = [(o, k) for o, k in all_krs if not k["tasks"]]

    # ── 头部 ──
    head = "OKR 拆解方案"
    if ctx["period"]:
        head += " · " + ctx["period"]
    L.append("# " + head)
    L.append("")
    meta = []
    if ctx["team"]:
        meta.append("团队：%s" % ctx["team"])
    if ctx["owner"]:
        meta.append("负责人：%s" % ctx["owner"])
    if ctx["period_start"] and ctx["period_end"]:
        meta.append("周期：%s ~ %s（%d 周）" % (ctx["period_start"], ctx["period_end"], weeks))
    else:
        meta.append("周期：%d 周" % weeks)
    meta.append("每周投入上限：%s 人日/人" % _num(ctx["weekly_cap"]))
    L.append("> " + " ｜ ".join(meta))
    L.append("")

    # ── 结论 ──
    L.append("## 一、结论速览")
    L.append("")
    L.append("- 共 **%d 个目标（O）**、**%d 条关键结果（KR）**、**%d 项周任务**，合计工作量 **%s 人日**"
             % (n_obj, n_kr, n_task, _num(total_days)))
    if bad:
        L.append("- ❌ **%d 条 KR 不合格**（%s），基本无法验收，必须先重写再往下拆"
                 % (len(bad), "、".join(bad)))
    if warn:
        L.append("- ⚠️ %d 条 KR 待完善（%s），能用但事后容易扯皮" % (len(warn), "、".join(warn)))
    if n_kr == 0:
        L.append("- ❌ **全篇没有一条关键结果**，目前只是愿望清单，不构成 OKR")
    elif not bad and not warn:
        L.append("- ✅ 全部 KR 通过可衡量性体检，可以直接进入执行")
    if empty_kr:
        L.append("- 🚨 **%d 条 KR 没有任何配套任务**（%s）——这叫许愿，不叫目标"
                 % (len(empty_kr), "、".join(k["id"] for _, k in empty_kr)))
    if n_obj > 5:
        L.append("- ⚠️ 目标数 %d 个偏多（建议 3-5 个）：目标越多越等于没有重点" % n_obj)
    for o in objs:
        c = len(o["key_results"])
        if c > 5:
            L.append("- ⚠️ 目标「%s」挂了 %d 条 KR（建议 2-5 条），拆得太碎会失焦" % (o["title"], c))
        elif c == 0:
            L.append("- ❌ 目标「%s」一条 KR 都没有，无法判定是否达成" % o["title"])
        elif c == 1:
            L.append("- ⚠️ 目标「%s」只有 1 条 KR，单点指标容易被钻空子（建议 2-3 条互相制衡）" % o["title"])
    L.append("")

    # ── 全景表 ──
    L.append("## 二、OKR 全景")
    L.append("")
    L.append("| 目标 | 优先级 | KR | 关键结果 | 基线→目标 | 负责人 | 任务数 | 工作量 | 体检 |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for o in sorted(objs, key=lambda x: PRIORITY_ORDER.get(x["priority"], 1)):
        if not o["key_results"]:
            L.append("| **%s** %s | %s | — | *（缺 KR）* | — | %s | 0 | 0 | ❌ |"
                     % (o["id"], o["title"], o["priority"], o["owner"] or "—"))
            continue
        for idx, k in enumerate(o["key_results"]):
            score, _, _ = audits[k["id"]]
            days = sum(t["effort_days"] for t in k["tasks"])
            oc = "**%s** %s" % (o["id"], o["title"]) if idx == 0 else ""
            pc = o["priority"] if idx == 0 else ""
            L.append("| %s | %s | %s | %s | %s | %s | %d | %s | %s %d |"
                     % (oc, pc, k["id"], esc(k["statement"] or "—"), fmt_kr_target(k),
                        k["owner"] or o["owner"] or "—", len(k["tasks"]),
                        _num(days), gate(score), score))
    L.append("")

    # ── 三级拆解 ──
    L.append("## 三、三级拆解明细")
    L.append("")
    for o in sorted(objs, key=lambda x: PRIORITY_ORDER.get(x["priority"], 1)):
        L.append("### %s · %s" % (o["id"], o["title"]))
        L.append("")
        sub = []
        if o["owner"]:
            sub.append("负责人 %s" % o["owner"])
        sub.append("优先级 %s" % o["priority"])
        L.append("*%s*" % " ｜ ".join(sub))
        if o["why"]:
            L.append("")
            L.append("**为什么做**：%s" % o["why"])
        L.append("")
        if not o["key_results"]:
            L.append("> ❌ 该目标下没有关键结果。请补 2-3 条可量化的 KR，否则季末无法判定成败。")
            L.append("")
            continue

        for k in o["key_results"]:
            score, problems, tips = audits[k["id"]]
            L.append("#### %s　%s" % (k["id"], k["statement"] or "*（未填写）*"))
            L.append("")
            row = ["衡量：%s" % fmt_kr_target(k)]
            row.append("负责人：%s" % (k["owner"] or o["owner"] or "待定"))
            if k["due"]:
                row.append("截止：%s" % k["due"])
            elif ctx["period_end"]:
                row.append("截止：%s（周期末）" % ctx["period_end"])
            if k["confidence"] is not None:
                flag = "（信心偏低，需提前备预案）" if k["confidence"] < 0.5 else ""
                row.append("信心：%d%%%s" % (round(k["confidence"] * 100), flag))
            row.append("体检：%s %d 分" % (gate(score), score))
            L.append("- " + "\n- ".join(row))
            L.append("")

            if problems:
                L.append("> **可衡量性问题**")
                for p in problems:
                    L.append("> - %s" % p)
                for t in tips:
                    L.append("> - 💡 %s" % t)
                L.append("")

            if not k["tasks"]:
                L.append("> 🚨 **该 KR 没有任何周任务**——指标不会自己变好，请至少拆出 2-3 项能推动它的动作。")
                L.append("")
                continue

            L.append("| # | 周任务 | 负责人 | 排在第几周 | 人日 | 备注 |")
            L.append("|---|---|---|---|---|---|")
            for n, t in enumerate(sorted(k["tasks"], key=lambda x: (x["week"] is None, x["week"] or 0)), 1):
                wk = "W%d" % t["week"] if t["week"] else "⚠️ 未排期"
                L.append("| %d | %s | %s | %s | %s | %s |"
                         % (n, esc(t["title"]), t["owner"] or k["owner"] or o["owner"] or "待定",
                            wk, _num(t["effort_days"]), t["note"] or "—"))
            L.append("")

    # ── 周负载 ──
    L.append("## 四、周排期与负载")
    L.append("")
    unscheduled = [(o, k, t) for o, k, t in all_tasks if t["week"] is None]
    by_week = {}
    for o, k, t in all_tasks:
        if t["week"]:
            by_week.setdefault(t["week"], []).append((o, k, t))

    if not by_week:
        L.append("所有任务都没填 `week`，无法生成周视图。建议按「先解卡点、后做增量」的顺序给每项任务指定周次。")
        L.append("")
    else:
        cap = ctx["weekly_cap"]
        # 负载按「人」判定：某周任一人超过个人上限即为超载。
        # 按周总量除以人数会掩盖「一人干 10 天、另一人干 2 天」的真实过载。
        over = []          # 超载周
        over_detail = []   # (周, 人, 人日)
        L.append("| 周次 | 任务数 | 合计人日 | 各人负荷 | 负载 |")
        L.append("|---|---|---|---|---|")
        for w in range(1, weeks + 1):
            items = by_week.get(w, [])
            if not items:
                continue
            days = sum(t["effort_days"] for _, _, t in items)
            per = {}
            for o, k, t in items:
                p = t["owner"] or k["owner"] or o["owner"] or "待定"
                per[p] = per.get(p, 0) + t["effort_days"]
            hot = [(p, d) for p, d in sorted(per.items()) if d > cap]
            tight = [(p, d) for p, d in sorted(per.items()) if cap * 0.8 < d <= cap]
            if hot:
                load = "🔴 超载"
                over.append(w)
                over_detail.extend((w, p, d) for p, d in hot)
            elif tight:
                load = "🟡 偏满"
            else:
                load = "🟢 正常"
            detail = "、".join("%s %s" % (esc(p), _num(d)) for p, d in sorted(per.items()))
            L.append("| W%d | %d | %s | %s | %s |"
                     % (w, len(items), _num(days), detail, load))
        L.append("")

        if over_detail:
            L.append("> 🔴 **超载明细**（个人上限 %s 人日/周）：" % _num(cap))
            for w, p, d in over_detail:
                L.append("> - W%d ｜ %s ｜ %s 人日，超出 %s 人日" % (w, p, _num(d), _num(d - cap)))
            free = [w for w in range(1, weeks + 1) if w not in by_week]
            if free:
                shown = free[:8]
                tail = "…" if len(free) > 8 else ""
                L.append("> ")
                L.append("> 空闲周可承接：%s%s。把超载周的任务往空周挪，或砍掉优先级最低的 KR——"
                         "排期表上塞得下不等于人干得完。" % ("、".join("W%d" % w for w in shown), tail))
            else:
                L.append("> ")
                L.append("> 全周期没有空闲周可挪，说明工作量本身超出团队产能，只能砍 KR 或加人。")
            L.append("")

    if unscheduled:
        L.append("**⚠️ 未排期任务（%d 项，%s 人日）**：" % (len(unscheduled), _num(sum(t["effort_days"] for _, _, t in unscheduled))))
        for o, k, t in unscheduled:
            L.append("- %s ｜ 归属 %s ｜ %s 人日" % (t["title"], k["id"], _num(t["effort_days"])))
        L.append("")
        L.append("> 没有周次的任务在现实里等于「有空再说」，通常最后都没做。请逐项指定周次。")
        L.append("")

    # ── 风险 ──
    L.append("## 五、风险提示")
    L.append("")
    risks = []
    for o, k in all_krs:
        if k["confidence"] is not None and k["confidence"] < 0.5:
            risks.append("**%s** 信心仅 %d%%：提前想好「如果做不到，退到什么水平算及格」，别等季末才摊牌"
                         % (k["id"], round(k["confidence"] * 100)))
    for o, k in empty_kr:
        risks.append("**%s** 无任何任务支撑，大概率会成为季末的「未启动」" % k["id"])
    for kid in bad:
        risks.append("**%s** 可衡量性不合格，即便做完也说不清算不算达成" % kid)
    if by_week:
        peak = {}
        for w, items in by_week.items():
            for o, k, t in items:
                p = t["owner"] or k["owner"] or o["owner"] or "待定"
                peak[(w, p)] = peak.get((w, p), 0) + t["effort_days"]
        blown = sorted({p for (w, p), d in peak.items() if d > ctx["weekly_cap"]})
        if blown:
            risks.append("**%s** 存在单周排量超出个人产能的情况，硬排下去只会挤压质量或延期，"
                         "建议在启动前就把任务挪周" % "、".join(blown))
    load_people = {}
    for o, k, t in all_tasks:
        p = t["owner"] or k["owner"] or o["owner"] or "待定"
        load_people[p] = load_people.get(p, 0) + t["effort_days"]
    if load_people:
        top, td = max(load_people.items(), key=lambda x: x[1])
        if len(load_people) > 1 and td > total_days * 0.5:
            risks.append("**%s** 一个人扛了 %s 人日（占总量 %d%%），单点依赖过重，此人一请假整个周期就塌"
                         % (top, _num(td), round(td / total_days * 100)))
        if top == "待定" and td > 0:
            risks.append("有 %s 人日的任务**没有指派到人**，请在启动前落实到具体姓名" % _num(td))
    if not risks:
        risks.append("暂未识别到结构性风险。但请留意：OKR 最常见的失败不是做不到，而是做着做着没人再看它。")
    for r in risks:
        L.append("- " + r)
    L.append("")

    # ── 下一步 ──
    L.append("## 六、下一步清单")
    L.append("")
    steps = []
    if bad:
        steps.append("重写不合格的 KR（%s），改成「指标从 X 到 Y」的句式" % "、".join(bad))
    if empty_kr:
        steps.append("给 %s 补齐周任务，每条 KR 至少 2 项动作" % "、".join(k["id"] for _, k in empty_kr))
    if unscheduled:
        steps.append("给 %d 项未排期任务指定周次" % len(unscheduled))
    if load_people.get("待定"):
        steps.append("把「待定」的任务落实到具体负责人")
    steps.append("约一次 OKR 对齐会，逐条确认 KR 的口径与数据来源（谁取数、多久更新一次）")
    steps.append("在日历上固定每周一次 15 分钟的 KR 进度检视，不检视的 OKR 等于没定")
    for s in steps:
        L.append("- [ ] " + s)
    L.append("")

    # ── 盲区扫描（v1.0.2） ──
    blind = scan_blind_spots(ctx, audits)
    L.append("## 七、盲区扫描（治理缺口）")
    L.append("")
    if not blind:
        L.append("- ✅ 未识别到治理缺口，负责人/截止时间/方向均齐备")
    else:
        hard = [b for b in blind if b[0] == "❌"]
        L.append("- 共发现 **%d** 处治理缺口（其中 %d 处硬性缺负责人）：" % (len(blind), len(hard)))
        L.append("")
        for lvl, txt in blind:
            L.append("- %s %s" % (lvl, txt))
    L.append("")

    L.append("---")
    L.append("")
    L.append("*本方案由规则引擎基于所填信息生成，体检分数只反映「写得规不规范」，不代表目标本身有没有价值。"
             "目标选得对不对，仍需结合业务判断。*")
    return "\n".join(L)


def _num(x):
    f = float(x)
    return str(int(f)) if abs(f - int(f)) < 1e-9 else ("%.1f" % f)


def scan_blind_spots(ctx, audits):
    """v1.0.2 盲区扫描：找出治理缺口（无负责人/无截止/无 why/动作型 KR/任务无人）。"""
    out = []
    objs = ctx["objectives"]
    for o in objs:
        if not o["why"]:
            out.append(("⚠️", "目标「%s」缺 `why`（为什么做），季末易被追问方向" % o["title"]))
        for k in o["key_results"]:
            if not (k["owner"] or o["owner"]):
                out.append(("❌", "KR %s 无负责人，集体负责等于无人负责" % k["id"]))
            if not (k["due"] or ctx["period_end"]):
                out.append(("⚠️", "KR %s 无截止时间，也没有周期末兜底" % k["id"]))
            stmt = k["statement"]
            is_action = any(stmt.startswith(v) for v in ACTION_VERBS)
            has_result = any(s in stmt for s in RESULT_SIGNALS)
            if stmt and is_action and not has_result:
                snippet = stmt[:12] + "…" if len(stmt) > 12 else stmt
                out.append(("⚠️", "KR %s 是动作型表述，建议改写为结果型（指标从 X 到 Y）：%s"
                            % (k["id"], snippet)))
            for t in k["tasks"]:
                if not (t["owner"] or k["owner"] or o["owner"]):
                    out.append(("⚠️", "KR %s 的任务「%s」未指派负责人" % (k["id"], t["title"])))
    return out


def build_argparser():
    ap = argparse.ArgumentParser(
        description="OKR/目标拆解助手：目标→KR→周任务三级拆解 + 可衡量性体检 + 周负载表")
    ap.add_argument("input_pos", nargs="?", help="JSON 文件路径（位置参数，向后兼容）")
    ap.add_argument("--input", help="JSON 文件路径；与位置参数二选一，缺省读 stdin")
    ap.add_argument("--output", "-o", help="写入 markdown 文件；缺省打印到 stdout")
    ap.add_argument("--cap", type=float, help="覆盖 settings.weekly_capacity_days：每周投入上限(人日/人)")
    ap.add_argument("--weeks", type=int, help="覆盖 settings.weeks：周期周数")
    ap.add_argument("--selftest", action="store_true", help="运行内置自检，通过退出码 0")
    return ap


class _Args:
    """selftest 用的极简参数替身。"""
    def __init__(self):
        self.input = None
        self.input_pos = None
        self.output = None
        self.cap = None
        self.weeks = None


def analyze(data, args):
    """v1.0.2/1.0.3 抽出核心分析，供 run() 与 selftest() 共用，并应用 CLI 覆盖。"""
    ctx = normalize(data)
    if getattr(args, "cap", None) is not None and args.cap > 0:
        ctx["weekly_cap"] = args.cap
    if getattr(args, "weeks", None) is not None and args.weeks > 0:
        ctx["weeks"] = args.weeks
    return ctx


def run(data, args):
    ctx = analyze(data, args)
    emit(build(ctx), getattr(args, "output", None))


def selftest():
    """v1.0.3 内置自检：覆盖多用例 + 边界，全部通过返回 0，任一失败返回 4。"""
    fails = []

    def check(name, cond):
        if not cond:
            fails.append(name)

    # 1) 基本拆解：1 O / 2 KR / 各 2 任务
    d = {"objectives": [
        {"id": "O1", "title": "提升留存", "why": "营收增长", "key_results": [
            {"id": "O1-KR1", "statement": "次日留存率从 30% 提升到 40%",
             "baseline": 30, "target": 40, "unit": "%", "owner": "张三",
             "tasks": [{"title": "a", "effort_days": 1, "week": 1},
                       {"title": "b", "effort_days": 2, "week": 2}]},
            {"id": "O1-KR2", "statement": "月活从 1万 到 1.5万", "baseline": 1, "target": 1.5,
             "unit": "万", "tasks": [{"title": "c", "effort_days": 1, "week": 1}]},
        ]}
    ]}
    ctx = analyze(d, _Args())
    check("basic_obj", len(ctx["objectives"]) == 1)
    out = build(ctx)
    check("basic_render", "O1" in out and "O1-KR1" in out)

    # 2) 不合格 KR 被标出（无量化目标）
    d = {"objectives": [
        {"id": "O2", "title": "做好服务", "key_results": [
            {"id": "O2-KR1", "statement": "提升服务质量", "tasks": [
                {"title": "x", "effort_days": 1, "week": 1}]},
        ]}
    ]}
    ctx = analyze(d, _Args())
    out = build(ctx)
    check("bad_kr_flagged", "❌" in out and "O2-KR1" in out)

    # 3) 盲区扫描：无 why + 无负责人
    d = {"objectives": [
        {"id": "O3", "title": "增长", "key_results": [
            {"id": "O3-KR1", "statement": "营收从 100 到 200", "baseline": 100, "target": 200,
             "unit": "万", "tasks": [{"title": "t", "effort_days": 1, "week": 1}]},
        ]}
    ]}
    ctx = analyze(d, _Args())
    out = build(ctx)
    check("blind_spot", "盲区扫描" in out)

    # 4) 动作型 KR 改写提示
    d = {"objectives": [
        {"id": "O4", "title": "效率", "key_results": [
            {"id": "O4-KR1", "statement": "完成审批系统开发", "tasks": [
                {"title": "t", "effort_days": 1, "week": 1}]},
        ]}
    ]}
    ctx = analyze(d, _Args())
    out = build(ctx)
    check("action_kr_tip", "动作型" in out or "改写为结果型" in out)

    # 5) 周超载判定
    d = {"objectives": [
        {"id": "O5", "title": "交付", "key_results": [
            {"id": "O5-KR1", "statement": "上线新功能", "tasks": [
                {"title": "重活", "owner": "张三", "effort_days": 10, "week": 1},
                {"title": "重活2", "owner": "张三", "effort_days": 10, "week": 1}]},
        ]}
    ]}
    ctx = analyze(d, _Args())
    out = build(ctx)
    check("overload", "🔴" in out and "超载" in out)

    # 6) 字符串简写任务被接受
    d = {"objectives": [
        {"id": "O6", "title": "X", "key_results": [
            {"id": "O6-KR1", "statement": "指标从 1 到 2", "baseline": 1, "target": 2,
             "tasks": ["直接写字符串任务"]},
        ]}
    ]}
    ctx = analyze(d, _Args())
    check("str_task", ctx["objectives"][0]["key_results"][0]["tasks"][0]["title"] == "直接写字符串任务")

    # 7) settings 非数值兜底：不崩
    d = {"settings": {"weekly_capacity_days": "坏", "weeks": "x"}, "objectives": [
        {"id": "O7", "title": "X", "key_results": [
            {"id": "O7-KR1", "statement": "指标从 1 到 2", "baseline": 1, "target": 2,
             "tasks": [{"title": "t", "effort_days": 1, "week": 1}]},
        ]}
    ]}
    try:
        ctx = analyze(d, _Args())
        check("bad_settings", ctx["weekly_cap"] == 4.0 and ctx["weeks"] == 12)
    except Exception as e:
        fails.append("bad_settings:{}".format(e))

    # 8) --cap / --weeks 命令行覆盖
    d = {"settings": {"weekly_capacity_days": 3, "weeks": 6}, "objectives": [
        {"id": "O8", "title": "X", "key_results": [
            {"id": "O8-KR1", "statement": "指标从 1 到 2", "baseline": 1, "target": 2,
             "tasks": [{"title": "t", "effort_days": 1, "week": 1}]},
        ]}
    ]}
    a = _Args(); a.cap = 5.0; a.weeks = 8
    ctx = analyze(d, a)
    check("cli_override", ctx["weekly_cap"] == 5.0 and ctx["weeks"] == 8)

    # 边界：超长 KR 描述带竖线/换行不破表、不崩
    d = {"objectives": [
        {"id": "O9", "title": "X", "key_results": [
            {"id": "O9-KR1", "statement": "管线|指标" + "Y" * 200, "baseline": 1, "target": 2,
             "tasks": [{"title": "t", "effort_days": 1, "week": 1}]},
        ]}
    ]}
    try:
        out = build(analyze(d, _Args()))
        check("edge_long_kr", "管线｜指标" in out and "Y" in out)
    except Exception as e:
        fails.append("edge_long_kr:{}".format(e))

    # 边界：负 effort_days 兜底为 1.0、不崩
    d = {"objectives": [
        {"id": "O10", "title": "X", "key_results": [
            {"id": "O10-KR1", "statement": "指标从 1 到 2", "baseline": 1, "target": 2,
             "tasks": [{"title": "t", "effort_days": -3, "week": 1}]},
        ]}
    ]}
    try:
        ctx = analyze(d, _Args())
        check("edge_neg_effort", ctx["objectives"][0]["key_results"][0]["tasks"][0]["effort_days"] == 1.0)
    except Exception as e:
        fails.append("edge_neg_effort:{}".format(e))

    # 边界：空 objectives → 报错退出码 2（不崩）
    try:
        normalize({"objectives": []})
        fails.append("edge_empty_obj")
    except SystemExit as e:
        check("edge_empty_obj", e.code == 2)

    if fails:
        sys.stderr.write("❌ 自检失败：{}\n".format("；".join(fails)))
        return 4
    sys.stderr.write("[自检] 全部 {} 组用例通过 ✅\n".format(10))
    return 0


def main():
    args = build_argparser().parse_args()
    if args.selftest:
        sys.exit(selftest())
    data = load_input(args.input or args.input_pos)
    run(data, args)


if __name__ == "__main__":
    main()
