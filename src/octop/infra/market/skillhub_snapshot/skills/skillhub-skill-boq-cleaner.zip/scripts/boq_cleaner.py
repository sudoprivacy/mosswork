#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
分部分项工程量清单计价表数据清洗脚本
根据boq-cleaner skill要求清洗和合并Excel数据
"""

import pandas as pd
import openpyxl
import os
import re
import sys

# 设置标准输出编码为UTF-8，避免Windows控制台乱码
sys.stdout.reconfigure(encoding='utf-8')


def _add_summary_sheet(wb, data_ws, header_map, source_count):
    """
    在清洗结果工作簿中新增“清洗汇总”工作表：
    - 数据源文件数、清单总项数、合价合计(元/万元)
    - 按数据来源分组合价汇总
    """
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    s = wb.create_sheet('清洗汇总')
    title_fill = PatternFill('solid', fgColor='2F5496')
    title_font = Font(name='微软雅黑', bold=True, color='FFFFFF', size=12)
    label_font = Font(name='微软雅黑', bold=True, size=11)
    sub_fill = PatternFill('solid', fgColor='D9E1F2')
    thin = Side(style='thin', color='D9D9D9')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    right_align = Alignment(horizontal='right', vertical='center')
    center = Alignment(horizontal='center', vertical='center')

    s['A1'] = '分部分项工程量清单清洗汇总'
    s['A1'].font = title_font
    s['A1'].fill = title_fill
    s['A1'].alignment = center
    s.merge_cells('A1:C1')
    s.row_dimensions[1].height = 26

    total_rows = max(data_ws.max_row - 1, 0)
    total_price = 0.0
    if '合价' in header_map:
        col = header_map['合价']
        for r in range(2, data_ws.max_row + 1):
            v = data_ws.cell(row=r, column=col).value
            if isinstance(v, (int, float)):
                total_price += v

    rows = [
        ('数据源文件数', source_count, ''),
        ('清单总项数', total_rows, ''),
        ('合价合计(元)', round(total_price, 2), '#,##0.00'),
        ('合价合计(万元)', round(total_price / 10000, 2), '#,##0.00'),
    ]
    r0 = 3
    for i, (label, val, fmt) in enumerate(rows):
        rr = r0 + i
        s.cell(row=rr, column=1, value=label).font = label_font
        s.cell(row=rr, column=1).border = border
        vc = s.cell(row=rr, column=2, value=val)
        vc.border = border
        vc.alignment = right_align
        if fmt:
            vc.number_format = fmt
        s.cell(row=rr, column=3).border = border

    sr = r0 + len(rows) + 2
    s.cell(row=sr, column=1, value='分来源合价汇总').font = label_font
    sr += 1
    for cc, htext in enumerate(['数据来源', '项数', '合价(元)'], start=1):
        c = s.cell(row=sr, column=cc, value=htext)
        c.font = label_font
        c.fill = sub_fill
        c.border = border
    sr += 1

    if '数据来源' in header_map and '合价' in header_map:
        src_col = header_map['数据来源']
        price_col = header_map['合价']
        agg = {}
        for r in range(2, data_ws.max_row + 1):
            src = data_ws.cell(row=r, column=src_col).value
            v = data_ws.cell(row=r, column=price_col).value
            if src is None:
                continue
            src = str(src)
            agg.setdefault(src, [0, 0.0])
            agg[src][0] += 1
            if isinstance(v, (int, float)):
                agg[src][1] += v
        for src, (cnt, amt) in agg.items():
            s.cell(row=sr, column=1, value=src).border = border
            c2 = s.cell(row=sr, column=2, value=cnt)
            c2.border = border
            c2.alignment = right_align
            c3 = s.cell(row=sr, column=3, value=round(amt, 2))
            c3.border = border
            c3.alignment = right_align
            c3.number_format = '#,##0.00'
            sr += 1

    s.column_dimensions['A'].width = 22
    s.column_dimensions['B'].width = 16
    s.column_dimensions['C'].width = 18


def _style_excel_report(output_file, source_count):
    """
    对输出的Excel进行专业格式化：
    - 表头：深蓝底白字加粗、居中、按内容自适应列宽
    - 数值列：千分位 + 两位小数
    - 全表细边框、冻结首行、开启自动筛选、斑马纹
    - 新增“清洗汇总”工作表
    """
    from openpyxl import load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = load_workbook(output_file)
    ws = wb.active
    ws.title = "分部分项清单"

    col_config = {
        '序号': (8, None, 'center'),
        '项目编码': (16, None, 'center'),
        '项目名称': (32, None, 'left'),
        '项目特征': (42, None, 'left'),
        '计量单位': (10, None, 'center'),
        '工程量': (14, '#,##0.00', 'right'),
        '单价': (14, '#,##0.00', 'right'),
        '合价': (18, '#,##0.00', 'right'),
        '数据来源': (22, None, 'left'),
    }

    header_fill = PatternFill('solid', fgColor='2F5496')
    header_font = Font(name='微软雅黑', bold=True, color='FFFFFF', size=11)
    zebra_fill = PatternFill('solid', fgColor='F2F6FC')
    thin = Side(style='thin', color='D9D9D9')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    align_map = {
        'left': Alignment(horizontal='left', vertical='center', wrap_text=True),
        'center': Alignment(horizontal='center', vertical='center', wrap_text=True),
        'right': Alignment(horizontal='right', vertical='center'),
    }

    header_map = {}
    for col_idx in range(1, ws.max_column + 1):
        name = ws.cell(row=1, column=col_idx).value
        if name is not None:
            header_map[str(name)] = col_idx

    for name, col_idx in header_map.items():
        c = ws.cell(row=1, column=col_idx)
        c.fill = header_fill
        c.font = header_font
        c.alignment = align_map['center']
        c.border = border
        width, _, _ = col_config.get(name, (18, None, 'left'))
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    for r in range(2, ws.max_row + 1):
        for name, col_idx in header_map.items():
            c = ws.cell(row=r, column=col_idx)
            _, num_fmt, align = col_config.get(name, (18, None, 'left'))
            c.border = border
            c.alignment = align_map.get(align, align_map['left'])
            if num_fmt and isinstance(c.value, (int, float)):
                c.number_format = num_fmt
        if r % 2 == 0:
            for col_idx in header_map.values():
                ws.cell(row=r, column=col_idx).fill = zebra_fill

    ws.freeze_panes = 'A2'
    ws.row_dimensions[1].height = 24
    last_col = get_column_letter(ws.max_column)
    ws.auto_filter.ref = f"A1:{last_col}{ws.max_row}"

    _add_summary_sheet(wb, ws, header_map, source_count)

    wb.save(output_file)

def find_target_sheet(file_path, keyword="分部分项"):
    """查找包含关键字的工作表"""
    try:
        wb = openpyxl.load_workbook(file_path, read_only=True)
        
        # 先检查sheet名称
        for sheet_name in wb.sheetnames:
            if keyword in sheet_name:
                wb.close()
                return sheet_name
        
        # 再检查前10行内容
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            found = False
            for row_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
                if row_idx > 10:
                    break
                row_text = ' '.join([str(cell) if cell else '' for cell in row])
                if keyword in row_text:
                    found = True
                    break
            if found:
                wb.close()
                return sheet_name
        
        wb.close()
    except Exception as e:
        print(f"[ERROR] 读取文件失败: {file_path}, 错误: {e}")
    
    return None

def identify_columns(file_path, sheet_name, max_search_rows=20):
    """识别8个核心字段所在的列"""
    keywords_map = {
        '序号': ['序号', '编号', '流水号', '#'],
        '项目编码': ['项目编码', '编码', '项目编号', '清单编码'],
        '项目名称': ['项目名称', '名称'],
        '项目特征': ['项目特征', '项目特征描述', '特征描述'],
        '计量单位': ['计量单位', '单位'],
        '工程量': ['工程量', '数量', '工程数量'],
        '单价': ['单价', '综合单价', '单价合计'],
        '合价': ['合价', '合价金额', '综合合价']
    }
    
    try:
        wb = openpyxl.load_workbook(file_path, read_only=True)
        ws = wb[sheet_name]
        
        found_columns = {}
        
        for row_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
            if row_idx > max_search_rows:
                break
            
            for col_idx, cell_value in enumerate(row, 1):
                if cell_value and isinstance(cell_value, str):
                    cell_text = cell_value.strip()
                    
                    for field, keywords in keywords_map.items():
                        if field in found_columns:
                            continue
                        
                        for keyword in keywords:
                            if keyword in cell_text:
                                found_columns[field] = col_idx
                                break
            
            if len(found_columns) == 8:
                break
        
        wb.close()
        
        if len(found_columns) == 8:
            print("[OK] 成功识别所有8个字段")
            for field, col in found_columns.items():
                print(f"    - {field}: 第{col}列")
            return found_columns
        else:
            print(f"[WARNING] 只找到 {len(found_columns)}/8 个字段")
            for field in keywords_map.keys():
                if field not in found_columns:
                    print(f"    - 缺失: {field}")
            return None
            
    except Exception as e:
        print(f"[ERROR] 识别列失败: {e}")
        return None

def is_valid_sequence(value):
    """判断序号是否为有效值"""
    if value is None or value == '':
        return False
    
    str_value = str(value).strip()
    
    try:
        num = float(str_value)
        return num > 0
    except:
        pass
    
    if re.match(r'^\d+(\.\d+)?$', str_value):
        return True
    
    return False

def extract_data(file_path, sheet_name, column_mapping):
    """从工作表中提取数据"""
    try:
        wb = openpyxl.load_workbook(file_path, read_only=True)
        ws = wb[sheet_name]
        
        data = []
        headers_row = None
        
        # 找到标题行
        for row_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
            for col_idx, cell_value in enumerate(row, 1):
                if cell_value and '序号' in str(cell_value):
                    headers_row = row_idx
                    break
            if headers_row:
                break
        
        if not headers_row:
            print("[ERROR] 未找到标题行")
            wb.close()
            return []
        
        print(f"  标题行在第 {headers_row} 行")
        
        # 从标题行之后开始读取数据
        prev_row_data = {}
        for row_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
            if row_idx <= headers_row:
                continue
            
            seq_col = column_mapping['序号']
            seq_value = row[seq_col - 1] if seq_col <= len(row) else None
            
            if not is_valid_sequence(seq_value):
                continue
            
            row_data = {}
            for field, col_idx in column_mapping.items():
                value = row[col_idx - 1] if col_idx <= len(row) else None
                
                # 处理合并单元格的空值（向前填充）
                if value is None or value == '':
                    if prev_row_data:
                        value = prev_row_data.get(field)
                
                row_data[field] = value
            
            # 数据验证
            if not row_data.get('项目编码'):
                prev_row_data = row_data
                continue
            
            try:
                quantity = float(row_data.get('工程量', 0) or 0)
                unit_price = float(row_data.get('单价', 0) or 0)
                total_price = float(row_data.get('合价', 0) or 0)
                
                if quantity < 0 or unit_price < 0 or total_price < 0:
                    print(f"[WARNING] 第{row_idx}行包含负数，已跳过")
                    prev_row_data = row_data
                    continue
            except:
                pass
            
            data.append(row_data)
            prev_row_data = row_data
        
        wb.close()
        
        print(f"  成功提取 {len(data)} 行数据")
        return data
        
    except Exception as e:
        print(f"[ERROR] 提取数据失败: {e}")
        import traceback
        traceback.print_exc()
        return []

def clean_and_merge(files, output_file):
    """清洗并合并多个Excel文件"""
    all_data = []
    
    for file_path in files:
        file_name = os.path.basename(file_path)
        file_name_no_ext = os.path.splitext(file_name)[0]
        
        print("\n" + "="*60)
        print(f"处理文件: {file_name}")
        print("="*60)
        
        # Step1: 查找目标工作表
        target_sheet = find_target_sheet(file_path)
        if not target_sheet:
            print("[ERROR] 未找到包含'分部分项'的工作表，跳过")
            continue
        
        print(f"[OK] 找到工作表: {target_sheet}")
        
        # Step2: 识别列
        column_mapping = identify_columns(file_path, target_sheet)
        if not column_mapping:
            print("[ERROR] 列识别失败，跳过")
            continue
        
        # Step3: 提取数据
        data = extract_data(file_path, target_sheet, column_mapping)
        if not data:
            print("[ERROR] 未提取到数据，跳过")
            continue
        
        # Step4: 添加数据来源列
        for row in data:
            row['数据来源'] = file_name_no_ext
        
        all_data.extend(data)
    
    if not all_data:
        print("\n[ERROR] 没有成功提取到任何数据")
        return False
    
    # Step5: 合并所有数据
    print("\n" + "="*60)
    print("合并数据...")
    print("="*60)
    
    df = pd.DataFrame(all_data)
    
    required_columns = ['序号', '项目编码', '项目名称', '项目特征', '计量单位', '工程量', '单价', '合价', '数据来源']
    for col in required_columns:
        if col not in df.columns:
            df[col] = None
    
    df = df[required_columns]
    df.reset_index(drop=True, inplace=True)
    
    # Step6: 输出到Excel
    print(f"总共合并 {len(df)} 行数据")
    print(f"输出到: {output_file}")
    
    os.makedirs(os.path.dirname(output_file) if os.path.dirname(output_file) else '.', exist_ok=True)
    df.to_excel(output_file, index=False, engine='openpyxl')

    # 输出美化：表头样式 / 列宽 / 数字格式 / 边框 / 冻结首行 / 自动筛选 / 汇总表
    try:
        source_count = int(df['数据来源'].nunique()) if '数据来源' in df.columns else 0
        _style_excel_report(output_file, source_count)
        print("[OK] 报表格式美化完成")
    except Exception as e:
        print(f"[WARN] 报表美化失败（已输出原始数据）: {e}")

    print("\n[OK] 清洗完成！")
    return True

if __name__ == "__main__":
    files = [
        r'C:\Users\18357\Desktop\数据清洗Skill测试表格\结构工程.xlsx',
        r'C:\Users\18357\Desktop\数据清洗Skill测试表格\装修工程.xlsx'
    ]
    
    output_file = r'C:\Users\18357\Desktop\清洗合并结果.xlsx'
    
    print("="*60)
    print("分部分项工程量清单计价表数据清洗")
    print("="*60)
    
    success = clean_and_merge(files, output_file)
    
    if success:
        print(f"\n结果已保存到: {output_file}")
    else:
        print("\n清洗失败，请检查输入文件")
