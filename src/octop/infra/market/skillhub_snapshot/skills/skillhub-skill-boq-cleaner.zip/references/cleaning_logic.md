# 分部分项工程量清单计价表清洗逻辑参考

本文档提供详细的数据清洗逻辑说明，供WorkBuddy在执行清洗任务时参考。

## 一、输入参数说明

| 参数 | 说明 | 默认值 | 示例 |
|------|------|--------|------|
| `input_folder` | Excel文件所在文件夹路径 | 必填 | `C:/Users/18357/Desktop/数据/` |
| `output_file` | 输出文件路径 | 必填 | `C:/Users/18357/Desktop/结果.xlsx` |
| `sheet_key_word` | 目标工作表特征值 | `分部分项` | `清单` |
| `header_rows` | 列识别搜索范围 | `20` | `15` |

## 二、详细处理流程

### Step 1: 扫描文件夹

**功能**：获取所有Excel文件

**实现逻辑**：
```python
# 支持格式
excel_extensions = ['.xlsx', '.xls']

# 排除临时文件
if not filename.startswith('~$'):
    excel_files.append(file_path)
```

**输出**：Excel文件路径列表

---

### Step 2: 遍历工作簿文件

**功能**：打开工作簿并记录名称

**实现逻辑**：
1. 使用 `openpyxl.load_workbook()` 打开工作簿
2. 提取工作簿名称（不含扩展名）作为数据来源
3. 记录到日志：`f"处理文件: {workbook_name}"`

**注意事项**：
- 处理加密或损坏的Excel文件时需捕获异常
- 记录无法打开的文件路径和错误原因

---

### Step 3: 识别有效工作表

**功能**：自动识别包含"分部分项"数据的工作表

**判断条件**：
```
IF 工作表非空
   AND (工作表名称包含特征值 
        OR 前10行内容包含特征值)
THEN 为候选工作表
```

**实现逻辑**：
```python
# 检查工作表名称
if sheet_key_word in sheet_name:
    return sheet_name

# 检查前10行内容
for row_idx, row in enumerate(ws.iter_rows(max_row=10)):
    row_text = ' '.join([str(cell.value) if cell.value else '' for cell in row])
    if sheet_key_word in row_text:
        return sheet_name
```

**优先级**：
1. 工作表名称匹配（优先）
2. 前10行内容匹配

**输出**：第一个匹配的工作表名称

---

### Step 4: 列识别与验证

**功能**：自动识别8个必需字段所在列

**搜索范围**：前N行（默认20行）

**关键字映射表**：

| 字段名称 | 匹配关键字（按优先级） |
|----------|------------------------|
| 序号 | `序号`, `编号`, `流水号`, `#` |
| 项目编码 | `项目编码`, `编码`, `项目编号`, `清单编码`|
| 项目名称 | `项目名称`, `名称` |
| 项目特征 | `项目特征`, `项目特征描述`, `特征描述` |
| 计量单位 | `计量单位`, `单位` |
| 工程量 | `工程量`, `数量`, `工程数量` |
| 单价 | `单价`, `综合单价`, `单价合计` |
| 合价 | `合价`, `合价金额`, `综合合价` |

**实现逻辑**：
```python
# 在前N行中搜索每个字段
for row_idx in range(header_rows):
    row = df.iloc[row_idx]
    
    for field, keywords in KEYWORD_MAPPING.items():
        for keyword in keywords:
            if keyword in cell_text:
                column_mapping[field] = col_idx
                break
```

**验证条件**：
```
IF 找到所有8个必需字段
THEN 列识别成功，继续处理
ELSE 跳过该工作表
```

**输出**：字段名到列索引的映射字典

---

### Step 5: 行识别与提取

**功能**：识别有效数据行并提取数据

**有效行判断条件**：
```
IF 序号列的值满足以下任一条件:
   - 是整数 (1, 2, 3...)
   - 是浮点数 (1.1, 2.5...)
   - 是可转换为数字的字符串 ("1", "2.1")
   AND 序号值 > 0
THEN 为有效行
ELSE 跳过该行
```

**实现逻辑**：
```python
def is_valid_serial(value) -> bool:
    # 尝试转换为整数
    try:
        int_val = int(str(value).strip())
        return int_val > 0
    except ValueError:
        pass
    
    # 尝试转换为浮点数
    try:
        float_val = float(str(value).strip())
        return float_val > 0
    except ValueError:
        pass
    
    # 正则匹配数字格式
    if re.match(r'^\d+(\.\d+)?$', str(value).strip()):
        return True
    
    return False
```

**提取数据**：
- 遍历"序号"列的每一行
- 对有效行：提取8个核心字段的数据
- 对无效行：跳过

**输出**：包含有效数据的DataFrame

---

### Step 6: 数据清洗与验证

**功能**：清洗数据并验证数据质量

#### 6.1 合并单元格处理

**逻辑**：向前填充空值

```python
# 对关键字段进行向前填充
key_fields = ['项目编码', '项目名称', '计量单位']
for field in key_fields:
    df[field] = df[field].fillna(method='ffill')
```

**示例**：
```
原始数据：
项目编码    项目名称    工程量
010101001  挖土方      100
           挖土方      200  ← 合并单元格，需填充

填充后：
项目编码    项目名称    工程量
010101001  挖土方      100
010101001  挖土方      200  ← 已填充
```

#### 6.2 空值处理

**规则**：关键字段不能为空

```python
# 删除项目编码为空的行
df = df.dropna(subset=['项目编码'])
```

#### 6.3 数值验证

**规则**：工程量、单价、合价必须为非负数

```python
# 转换为数值类型
df['工程量'] = pd.to_numeric(df['工程量'], errors='coerce')
df['单价'] = pd.to_numeric(df['单价'], errors='coerce')
df['合价'] = pd.to_numeric(df['合价'], errors='coerce')

# 处理负数值
if skip_negative_values:
    df = df[df['工程量'] >= 0]
    df = df[df['单价'] >= 0]
    df = df[df['合价'] >= 0]
else:
    # 标记但不删除
    df['工程量_负数标记'] = df['工程量'] < 0
```

#### 6.4 公式验证（可选）

**规则**：合价 ≈ 工程量 × 单价

```python
if validate_formula:
    calculated = df['工程量'] * df['单价']
    diff = abs(df['合价'] - calculated)
    
    # 允许0.01的误差
    invalid_mask = diff > 0.01
    
    if invalid_mask.any():
        logger.warning(f"发现 {invalid_mask.sum()} 行合价计算不一致")
```

#### 6.5 格式标准化

**规则**：统一数据类型

```python
# 序号统一为字符串
df['序号'] = df['序号'].astype(str)

# 数值字段统一为浮点数
numeric_fields = ['工程量', '单价', '合价']
for field in numeric_fields:
    df[field] = df[field].astype(float)
```

---

### Step 7: 添加数据来源列

**功能**：在最后新增一列"数据来源"

**实现逻辑**：
```python
# 提取工作簿名称（不含扩展名）
source_name = os.path.splitext(os.path.basename(file_path))[0]

# 添加数据来源列
df['数据来源'] = source_name
```

**输出字段**：

| 序号 | 字段名称 | 说明 |
|------|----------|------|
| 1 | 序号 | 清单项序号 |
| 2 | 项目编码 | 清单项目编码 |
| 3 | 项目名称 | 清单项目名称 |
| 4 | 项目特征 | 项目特征描述 |
| 5 | 计量单位 | 计量单位 |
| 6 | 工程量 | 工程数量 |
| 7 | 单价 | 综合单价 |
| 8 | 合价 | 合价金额 |
| 9 | 数据来源 | 来源工作簿名称 |

---

### Step 8: 合并所有数据

**功能**：将所有有效工作表的数据纵向合并

**实现逻辑**：
```python
# 合并所有数据
merged_df = pd.concat(all_data, ignore_index=True)

# 重置索引
merged_df.reset_index(drop=True, inplace=True)
```

**注意事项**：
- 确保所有DataFrame的列顺序一致
- 使用 `ignore_index=True` 重置索引

---

### Step 9: 输出结果（含专业格式化）

**功能**：保存为Excel文件，并对报表做美观化处理

**实现逻辑**：
```python
# 确保输出目录存在
os.makedirs(os.path.dirname(output_file), exist_ok=True)

# 先落盘为原始数据
merged_df.to_excel(output_file, index=False, engine='openpyxl')

# 报表美化（失败不影响数据落盘）
_style_excel_report(output_file, len(all_data))
```

`_style_excel_report` 负责以下美化，使输出真正具备造价报表观感：
- 表头：深蓝底（#2F5496）白字加粗、居中，按字段自适应列宽
- 数值列（工程量 / 单价 / 合价）：`#,##0.00` 千分位 + 两位小数
- 全表细边框；冻结首行（`A2`）；开启自动筛选（`A1:I{n}`）
- 斑马纹：偶数行浅灰底色（`#F2F6FC`）提升可读性
- 新增“清洗汇总”工作表：数据源文件数、清单总项数、合价合计（元 / 万元）、分来源合价汇总

**可选输出**：清洗日志

```python
if output_log:
    log_file = output_file.replace('.xlsx', '_log.txt')
    with open(log_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(logs))
```

---

## 三、异常处理机制

| 异常场景 | 检测方式 | 处理方式 | 日志级别 |
|----------|----------|----------|----------|
| 文件夹不存在 | `os.path.exists()` | 报错终止 | ERROR |
| Excel文件无法打开 | `try-except` | 跳过该文件 | WARNING |
| 找不到匹配的工作表 | 遍历后未找到 | 跳过该工作簿 | WARNING |
| 必需字段缺失 | 检查映射字典长度 | 跳过该工作表 | ERROR |
| 序号格式异常 | `is_valid_serial()` | 跳过该行 | INFO |
| 数值为负数 | 数值验证 | 标记或跳过 | WARNING |
| 合并单元格导致空值 | 检测空值 | 向前填充 | INFO |
| 合价计算不一致 | 公式验证 | 标记异常 | WARNING |

---

## 四、配置选项说明

### 4.1 skip_negative_values

**类型**：布尔值

**默认值**：`False`

**说明**：
- `True`：跳过（删除）包含负数值的行
- `False`：保留负数值行，但标记异常

**使用建议**：
- 数据质量较高时设为 `False`，保留所有数据
- 数据质量较差时设为 `True`，提高数据清洁度

---

### 4.2 fill_merged_cells

**类型**：布尔值

**默认值**：`True`

**说明**：
- `True`：向前填充合并单元格导致的空值
- `False`：保留空值，可能需要后续手动处理

**使用建议**：
- 绝大多数情况下应保持 `True`
- 仅在确认无合并单元格时设为 `False`

---

### 4.3 validate_formula

**类型**：布尔值

**默认值**：`False`

**说明**：
- `True`：验证合价是否等于工程量 × 单价
- `False`：跳过验证，提高处理速度

**使用建议**：
- 数据审计时设为 `True`
- 快速汇总时设为 `False`

---

### 4.4 output_log

**类型**：布尔值

**默认值**：`True`

**说明**：
- `True`：输出详细的清洗日志
- `False`：不输出日志，减少I/O操作

**使用建议**：
- 调试和审计时保持 `True`
- 生产环境批量处理时可设为 `False`

---

## 五、性能优化建议

### 5.1 内存优化

**问题**：处理大量文件时可能占用大量内存

**解决方案**：
```python
# 分批处理
batch_size = 10
for i in range(0, len(excel_files), batch_size):
    batch = excel_files[i:i+batch_size]
    # 处理当前批次
    # 处理完后释放内存
```

### 5.2 速度优化

**问题**：逐个读取Excel文件速度较慢

**解决方案**：
```python
# 使用多线程/多进程
from concurrent.futures import ThreadPoolExecutor

with ThreadPoolExecutor(max_workers=4) as executor:
    futures = [executor.submit(process_file, f) for f in excel_files]
    results = [f.result() for f in futures]
```

### 5.3 I/O优化

**问题**：频繁读写磁盘

**解决方案**：
```python
# 输出日志时批量写入
if len(logs) >= 100:
    write_logs_to_file(logs)
    logs.clear()
```

---

## 六、测试用例

### 6.1 正常场景

**测试1**：单个Excel文件，包含标准格式的分部分项表
- **输入**：1个.xlsx文件，工作表名称为"分部分项工程量清单计价表"
- **预期输出**：成功提取所有数据并保存

**测试2**：多个Excel文件，混合格式
- **输入**：5个.xlsx文件，部分使用"清单"作为关键字
- **预期输出**：所有文件的数据成功合并

**测试3**：包含合并单元格
- **输入**：Excel文件包含合并的项目编码单元格
- **预期输出**：空值被正确填充

---

### 6.2 异常场景

**测试4**：文件夹不存在
- **输入**：不存在的路径
- **预期输出**：报错并终止

**测试5**：Excel文件损坏
- **输入**：故意损坏的.xlsx文件
- **预期输出**：跳过该文件，继续处理其他文件

**测试6**：缺少必需字段
- **输入**：工作表缺少"合价"列
- **预期输出**：跳过该工作表，记录日志

**测试7**：负数值
- **输入**：工程量包含负数
- **预期输出**：根据配置标记或跳过

---

## 七、常见问题排查

### Q1: 找不到匹配的工作表

**可能原因**：
1. 工作表名称不包含特征值
2. 前10行内容不包含特征值
3. 特征值拼写错误

**解决方法**：
1. 检查 `sheet_key_word` 参数是否正确
2. 手动打开Excel文件，查看工作表名称和内容
3. 尝试使用更通用的关键字（如"清单"）

---

### Q2: 无法识别某些字段

**可能原因**：
1. 字段名称使用了未定义的关键字
2. 字段在第20行之后
3. 字段名称包含特殊字符或空格

**解决方法**：
1. 在 `KEYWORD_MAPPING` 中添加更多关键字
2. 增大 `header_rows` 参数
3. 手动检查Excel文件，确认字段名称

---

### Q3: 数据提取不完整

**可能原因**：
1. 序号格式不符合预期
2. 有效行判断逻辑过于严格
3. 隐藏行或筛选导致数据缺失

**解决方法**：
1. 检查 `is_valid_serial()` 函数逻辑
2. 手动检查Excel文件，确认数据行范围
3. 禁用筛选和隐藏行

---

### Q4: 合并后数据重复

**可能原因**：
1. 同一个文件被处理多次
2. 工作表被重复识别

**解决方法**：
1. 检查文件路径是否重复
2. 检查工作表识别逻辑，确保只取第一个匹配项
3. 在合并前对数据进行去重

---

## 八、扩展功能建议

### 8.1 支持更多文件格式

**目标**：支持.csv, .ods等格式

**实现思路**：
```python
def read_file(file_path: str, sheet_name: str):
    if file_path.endswith('.csv'):
        return pd.read_csv(file_path)
    elif file_path.endswith(('.xlsx', '.xls')):
        return pd.read_excel(file_path, sheet_name=sheet_name)
    elif file_path.endswith('.ods'):
        return pd.read_excel(file_path, sheet_name=sheet_name, engine='odf')
```

---

### 8.2 支持自定义字段映射

**目标**：允许用户自定义字段和关键字的映射关系

**实现思路**：
```python
# 从配置文件读取映射
with open('keyword_mapping.json', 'r', encoding='utf-8') as f:
    KEYWORD_MAPPING = json.load(f)
```

---

### 8.3 支持数据去重

**目标**：合并后自动去重

**实现思路**：
```python
# 基于项目编码和项目名称去重
merged_df.drop_duplicates(subset=['项目编码', '项目名称'], inplace=True)
```

---

### 8.4 支持数据验证报告

**目标**：生成详细的数据质量报告

**实现思路**：
```python
report = {
    'total_rows': len(merged_df),
    'empty_cells': merged_df.isna().sum().to_dict(),
    'negative_values': (merged_df[['工程量', '单价', '合价']] < 0).sum().to_dict(),
    'formula_errors': invalid_count
}

with open('data_quality_report.json', 'w', encoding='utf-8') as f:
    json.dump(report, f, ensure_ascii=False, indent=2)
```

---

## 九、总结

本参考文档详细说明了分部分项工程量清单计价表数据清洗的完整逻辑，包括：

1. **输入参数**：4个可配置参数
2. **处理流程**：9个步骤，从扫描文件夹到输出结果
3. **判断条件**：4类判断条件（有效工作表、有效列、有效行、有效数据）
4. **异常处理**：7种异常场景的处理方式
5. **配置选项**：4个配置项，支持灵活调整
6. **性能优化**：内存、速度、I/O三个方面的优化建议
7. **测试用例**：7个测试场景（4个正常+3个异常）
8. **问题排查**：4个常见问题的解决方法
9. **扩展功能**：4个潜在的扩展方向

通过本文档，WorkBuddy可以深入理解数据清洗的每一个细节，从而更准确地执行任务，并在遇到问题时快速定位和解决。
