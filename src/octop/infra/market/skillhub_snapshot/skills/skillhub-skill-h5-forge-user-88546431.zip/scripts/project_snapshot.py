#!/usr/bin/env python3
"""Generate a compact H5/Web project snapshot for fast-mode cold starts."""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path


def load_stack_scanner(repo: Path):
    path = repo / "scripts" / "h5_stack_scan.py"
    spec = importlib.util.spec_from_file_location("h5_stack_scan", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load scanner: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def first_existing(root: Path, patterns: list[str], limit: int = 5) -> list[str]:
    results: list[str] = []
    seen: set[str] = set()
    for pattern in patterns:
        for path in root.glob(pattern):
            if path.is_file():
                value = str(path.relative_to(root))
            elif path.is_dir():
                value = str(path.relative_to(root)) + "/"
            else:
                continue
            if value not in seen:
                seen.add(value)
                results.append(value)
            if len(results) >= limit:
                return results
    return results


def summarize_signals(signals: dict[str, object]) -> dict[str, list[str]]:
    summary: dict[str, list[str]] = {}
    for category, tools in signals.items():
        if not isinstance(tools, dict):
            continue
        high: list[str] = []
        medium: list[str] = []
        for name, info in tools.items():
            if not isinstance(info, dict):
                continue
            confidence = info.get("confidence")
            if confidence == "high":
                high.append(name)
            elif confidence == "medium":
                medium.append(name)
        names = high if high else medium[:2]
        if names:
            summary[category] = names[:4]
    return summary


def top_dirs(root: Path) -> list[str]:
    for dirname in ("src", "app", "pages"):
        directory = root / dirname
        if directory.exists():
            return sorted(str(path.relative_to(root)) + "/" for path in directory.iterdir() if path.is_dir())[:12]
    return []


def find_project_guardrails(root: Path) -> list[str]:
    project_name = root.name
    patterns = [
        f".claude/.h5-forge/projects/{project_name}.project_guardrails.yaml",
        f".trae/.h5-forge/projects/{project_name}.project_guardrails.yaml",
        f".agent/.h5-forge/projects/{project_name}.project_guardrails.yaml",
        f".h5-forge/projects/{project_name}.project_guardrails.yaml",
    ]
    cards: list[str] = []
    for pattern in patterns:
        cards.extend(str(path.relative_to(root)) for path in root.glob(pattern))
    return cards


def similar_entries(root: Path) -> list[str]:
    candidates = first_existing(
        root,
        [
            "src/**/*Page.*",
            "src/**/*page.*",
            "src/**/*List.*",
            "src/**/*Detail.*",
            "src/**/*Form.*",
            "src/features/*/",
        ],
        limit=12,
    )
    return [item for item in candidates if ".test." not in item and ".spec." not in item][:5]


def snapshot(root: Path) -> dict[str, object]:
    repo = Path(__file__).resolve().parents[1]
    scanner = load_stack_scanner(repo)
    stack = scanner.scan(root)

    signal_summary = summarize_signals(stack["signals"])

    return {
        "project_root": str(root),
        "is_h5_project": stack["is_h5_project"],
        "package_json": "package.json" if (root / "package.json").exists() else None,
        "src_top_dirs": top_dirs(root),
        "project_guardrails": find_project_guardrails(root),
        "routing_entries": first_existing(root, ["src/**/*router*.*", "src/**/*route*.*", "app/**/*page.*", "pages/**/*.*"]),
        "state_entries": first_existing(
            root,
            [
                "src/**/*store*.*",
                "src/**/*slice*.*",
                "src/**/*context*.*",
                "src/**/*provider*.*",
                "src/**/*composable*.*",
            ],
        ),
        "network_entries": first_existing(root, ["src/**/*api*.*", "src/**/*request*.*", "src/**/*http*.*", "src/**/*client*.*"]),
        "styling_entries": first_existing(root, ["src/**/*.module.css", "src/**/*.module.scss", "src/**/*style*.*", "src/**/*theme*.*", "tailwind.config.*"]),
        "test_entries": first_existing(root, ["src/**/*.test.*", "src/**/*.spec.*", "tests/**/*.*", "e2e/**/*.*"]),
        "shared_entries": first_existing(root, ["src/shared/**/*.*", "src/common/**/*.*", "src/components/**/*.*", "src/lib/**/*.*", "src/core/**/*.*"]),
        "similar_entries": similar_entries(root),
        "stack_summary": signal_summary,
        "stack_signals": stack["signals"],
    }


def print_text(data: dict[str, object]) -> None:
    print(f"project_root: {data['project_root']}")
    print(f"is_h5_project: {str(data['is_h5_project']).lower()}")
    print(f"package_json: {data['package_json']}")
    print(f"project_guardrails: {', '.join(data['project_guardrails']) if data['project_guardrails'] else 'none'}")
    print(f"src_top_dirs: {', '.join(data['src_top_dirs']) if data['src_top_dirs'] else 'none'}")
    print(f"routing_entries: {', '.join(data['routing_entries']) if data['routing_entries'] else 'none'}")
    print(f"state_entries: {', '.join(data['state_entries']) if data['state_entries'] else 'none'}")
    print(f"network_entries: {', '.join(data['network_entries']) if data['network_entries'] else 'none'}")
    print(f"styling_entries: {', '.join(data['styling_entries']) if data['styling_entries'] else 'none'}")
    print(f"test_entries: {', '.join(data['test_entries']) if data['test_entries'] else 'none'}")
    print(f"shared_entries: {', '.join(data['shared_entries']) if data['shared_entries'] else 'none'}")
    print(f"similar_entries: {', '.join(data['similar_entries']) if data['similar_entries'] else 'none'}")
    stack_summary = data.get("stack_summary", {})
    if stack_summary:
        print("stack_summary:")
        for category, names in stack_summary.items():
            print(f"  {category}: {', '.join(names)}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_root", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    root = args.project_root.resolve()
    data = snapshot(root)
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print_text(data)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
