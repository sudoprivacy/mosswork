#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib.sh"

python3 scripts/validate_project_guardrails.py --allow-placeholders \
  references/project_guardrails_template.yaml \
  memory/projects/example_project.project_guardrails.yaml

python3 scripts/validate_h5_stack_scan.py
python3 scripts/validate_project_guardrails_resolution.py
python3 scripts/project_snapshot.py tests/fixtures/h5_sample >/dev/null

tmp_guardrails="$(mktemp -t h5-forge-guardrails.XXXXXX.yaml)"
python3 scripts/init_project_guardrails.py tests/fixtures/h5_sample --output "$tmp_guardrails" >/dev/null
grep -q 'root_type: "h5_existing"' "$tmp_guardrails" || fail "init_project_guardrails did not detect h5_existing"
grep -q 'project_guardrails:' "$tmp_guardrails" || fail "init_project_guardrails did not use project_guardrails root key"
grep -q 'guardrails_quality:' "$tmp_guardrails" || fail "init_project_guardrails did not emit guardrails_quality"
grep -q '_draft' "$tmp_guardrails" && fail "init_project_guardrails still generates draft files"
rm -f "$tmp_guardrails"
info "init_project_guardrails validation passed"

tmp_empty_project="$(mktemp -d -t h5-forge-empty.XXXXXX)"
empty_state="$(python3 scripts/detect_project_root_state.py "$tmp_empty_project")"
printf '%s\n' "$empty_state" | grep -q '"root_type": "empty_new"' || fail "detect_project_root_state did not classify empty dir as empty_new"
printf '%s\n' "$empty_state" | grep -q '"forge_enabled": true' || fail "detect_project_root_state did not enable forge for empty_new"
rm -rf "$tmp_empty_project"

tmp_non_h5="$(mktemp -d -t h5-forge-nonh5.XXXXXX)"
printf 'hello\n' > "$tmp_non_h5/README.md"
non_h5_state="$(python3 scripts/detect_project_root_state.py "$tmp_non_h5")"
printf '%s\n' "$non_h5_state" | grep -q '"root_type": "non_h5"' || fail "detect_project_root_state did not classify non-h5 workspace"
printf '%s\n' "$non_h5_state" | grep -q '"forge_enabled": false' || fail "detect_project_root_state did not disable forge for non-h5 workspace"
rm -rf "$tmp_non_h5"

python3 scripts/route_golden_tests.py
