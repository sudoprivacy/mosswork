#!/usr/bin/env python3
"""Detect whether the current root is an empty new workspace, H5/Web app, or non-H5 workspace."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path


def visible_entries(root: Path) -> list[str]:
    return sorted(entry.name for entry in root.iterdir() if not entry.name.startswith("."))


def detect_root_state(root: Path) -> dict[str, object]:
    entries = visible_entries(root)
    is_empty_dir = len(entries) == 0
    has_package_json = (root / "package.json").is_file()
    has_src_dir = (root / "src").is_dir()
    has_index_html = (root / "index.html").is_file()

    if is_empty_dir:
        root_type = "empty_new"
        forge_enabled = True
    elif has_package_json or has_src_dir or has_index_html:
        root_type = "h5_existing"
        forge_enabled = True
    else:
        root_type = "non_h5"
        forge_enabled = False

    return {
        "project_root": str(root),
        "project_name": root.name,
        "root_type": root_type,
        "forge_enabled": forge_enabled,
        "is_empty_dir": is_empty_dir,
        "has_package_json": has_package_json,
        "has_src_dir": has_src_dir,
        "has_index_html": has_index_html,
        "ignored_hidden_files": True,
        "visible_entries": entries[:20],
        "checked_at": int(time.time()),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root", nargs="?", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    print(json.dumps(detect_root_state(root), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
