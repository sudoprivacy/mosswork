# H5 Forge Reference - Frontend Skills Integration

H5 Forge 负责总控和项目内决策，不替代 React、Vue、Next、Vite、Tailwind、测试、浏览器调试等通用前端 skills。

H5 Forge 不要求仓库内存在本地 `frontend-skills/` 目录。是否调用前端协作 skill，由大模型在当前环境中自行探索和匹配。

## 目标

前端协作 skills 的职责只有两类：

1. 提供通用实现蓝图或专项能力
2. 提供浏览器、测试、调试等执行能力

H5 Forge 的职责始终不变：

1. 判断当前阶段是否允许委托
2. 判断委托后的结果是否符合当前项目项目护栏
3. 在缺少协作 skill 时安全降级，不阻塞主流程

## 探测优先级

默认先由大模型探索当前环境中可协作的前端 skill，而不是假设存在某个本地副本目录。

按以下顺序探测：

1. 当前会话上下文已明确列出的可用 skills
2. 本地映射文件 `.h5-forge/skill_mapping.local.env`
3. 当前工作区 `.claude/skills/`、`.agents/skills/`、`.cc-switch/skills/`、`.trae/skills/`
4. 当前宿主根目录 `~/.claude/skills/`、`~/.agents/skills/`、`~/.cc-switch/skills/`、`~/.trae/skills/`

`references/frontend_skill_aliases.yaml` 提供抽象 skill 名到常见别名的映射，用于在探索过程中做等价识别。

## 本地映射文件

`scripts/discover_h5_skills.sh` 会写入 `.h5-forge/skill_mapping.local.env`，当前支持以下字段：

```bash
H5_FORGE_SKILL_SOURCE="/absolute/path/to/skills/root"
H5_FORGE_SKILL_SOURCE_TYPE="项目内技能目录|宿主根技能目录"
H5_FORGE_SKILL_SOURCE_SET_AT="YYYY-MM-DD HH:MM:SS"
```

用途：

- 固定一个优先搜索的 skill 根目录
- 避免每次任务都重新猜测从哪个目录找前端协作 skill
- 让大模型在探索时优先查看同一套目录

如果需要统一选择协作目录，引导用户运行：

```bash
scripts/discover_h5_skills.sh
```

## 委托决策规则

### 需求理解阶段

不要委托。这个阶段属于项目和业务理解，必须由 H5 Forge 自己完成。

### UI 解析阶段

如果问题主要是以下任一项，可以委托：

- 响应式布局
- CSS 布局溢出
- 移动端适配
- 设计稿到组件拆分
- 设计系统 token、组件状态矩阵

优先参考：

- `frontend-building-layouts`
- `frontend-design-system`

### 架构与实现设计阶段

如果问题主要是以下任一项，可以委托：

- React / Vue / Next / Nuxt 分层架构
- 路由方式
- 数据请求和缓存
- 表单管理
- 状态管理
- SSR / SSG / CSR 边界
- i18n 接入

优先参考：

- `frontend-architecting-apps`
- `frontend-routing`
- `frontend-handling-http-and-json`
- `frontend-managing-state`
- `frontend-localizing-apps`

### 页面开发阶段

如果问题主要是以下任一项，可以委托：

- 组件测试
- E2E 测试
- Storybook / 组件预览
- 浏览器调试
- 本地页面交互回归

优先参考：

- `frontend-testing-apps`
- `frontend-browser-debug`

## 当 delegation_map 命中时怎么执行

当 `delegation_map.yaml` 某条规则命中时，controller 按以下顺序执行：

1. 先用 `skill` 抽象名判断当前需要的能力类型
2. 再查当前会话可用 skills 是否有同名或近义 skill
3. 若未命中，则用 `frontend_skill_aliases.yaml` 的别名做等价匹配
4. 若仍未命中，则读取该条目的 `fallback`
5. 对用户透明输出“已委托”或“已降级到内置流程”

推荐日志格式：

```text
[h5-forge] 架构设计师：委托 frontend-routing
[h5-forge] 架构设计师：frontend-routing 未安装，降级到内置路由规则
```

## 降级原则

如果环境里未安装对应 skill：

- 不阻塞任务
- 回退到 H5 Forge 内置参考文档和本地流程
- 必须向用户透明说明当前正在使用降级模式
- 优先使用 `delegation_map.yaml` 中声明的 `fallback` 文件，而不是临时拍脑袋给通用建议

降级优先级：

1. `delegation_map.yaml` 当前条目的 `fallback`
2. 角色文档中的内置判断规则
3. 通用 reference 文档
4. 最后才是模型自带常识

## 优先识别的 Skill 类型

H5 Forge 不绑定某个“官方 h5 skills”仓库。优先识别以下命名方向：

- `react-*`
- `vue-*`
- `next-*`
- `vite-*`
- `web-*`
- `frontend-*`
- `h5-*`

## 收口规则

即使调用前端协作 skills，H5 Forge 仍负责最终收口：

1. 是否符合当前项目目录结构
2. 是否符合当前项目命名规则
3. 是否符合当前项目主流框架和状态管理模式
4. 是否需要复用已有页面、组件、hook、store 或 API 层
5. 是否要压缩或调整通用建议，避免和项目现状冲突
6. 是否需要把本次降级或委托结果写回项目护栏或阶段摘要包

换句话说：

- 前端协作 skill 提供通用最佳实践或执行能力
- H5 Forge 负责项目内适配和最终决策
