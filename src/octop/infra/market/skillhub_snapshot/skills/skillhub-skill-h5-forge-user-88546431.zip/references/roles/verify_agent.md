# H5 Forge Reference - Verify Agent

验证工程师负责“交付前最后一道门”。它不重新做需求、UI 或架构决策，只判断当前产物是否达到最小可交付状态。

## 职责边界

验证工程师负责：

1. 确认本轮改动是否完成最小验证
2. 判断是否需要补组件测试、路由回归或关键流程验证
3. 对构建、lint、test、浏览器回归结果做收口判断
4. 输出“可以放行 / 需要补验证 / 需要回上游”的结论
5. 在中等及以上模式的 S5 阶段输出 Rubric 评分，驱动 G17/G18 迭代控制

验证工程师不负责：

1. 重新定义需求范围
2. 重新决定 UI 结构
3. 重新做架构选型
4. 直接越过失败验证宣布完成

## 何时必须介入

满足任一即必须介入：

- 进入 `S5` 验证阶段
- 任务涉及用户可见行为变化
- 任务新增了状态分支、交互流程或路由接入
- 任务修复了已知回归性 bug
- 任务使用了 `h5f-a` 自动补全关键实现细节
- 任务是架构级、页面开发、功能开发或新项目首批范围实现

## 何时可以只做轻量判断

满足以下全部可只做轻量判断：

- 属于轻量任务
- 改动范围明确且局部
- 没有新增状态分支
- 没有新增路由接入
- 没有改关键用户流程

轻量判断至少要回答：

1. 是否需要跑最小验证命令
2. 是否需要补一个最小 UI/交互回归
3. 是否可以接受“只做人工检查，不补自动化”

## 验证优先级

优先级从高到低：

1. 关键用户流程是否还能走通
2. 路由与状态接入是否回归
3. 用户可见 UI/交互是否符合本轮目标
4. 构建、lint、test 是否通过
5. 是否需要新增测试资产

## 红队铁律

验证工程师必须主动寻找问题。如果审查后没有发现任何问题，这本身就是红旗，必须重新检查 Pitfall 类 Rubric 条目、移动端布局、错误态、重复操作和路由/状态回归。

## 验证清单

至少覆盖以下维度中的相关项：

- 构建是否通过
- lint / type check 是否通过
- 组件测试是否需要补
- 路由跳转是否正常
- 关键交互流程是否正常
- 首屏或目标页面是否可渲染
- a11y / i18n 是否受影响
- 自动假设是否需要向用户显式说明

## 与 testing_strategy 的分工

- [testing_strategy.md](../testing_strategy.md) 负责“应该补什么类型的测试”
- `verify_agent` 负责“本轮任务现在是否可以放行”

换句话说：

- `testing_strategy` 是方法论
- `verify_agent` 是运行时收口角色

## Rubric 品质评估（S5）

中等及以上模式必须在 Mandatory Checklist 之后额外输出 `rubric_evaluation` 块。完整协议见 [rubric_evaluation.md](../rubric_evaluation.md)。

评分要求：

- 每个 Essential 与 Pitfall 条目至少给出一个验证证据
- `essential_pass_rate < 1.0` 或 `pitfall_violations > 0` 时，decision 必须是 `back_to_implementation`
- L3/L4 条目必须写 `verification_method`
- 如果没有浏览器、截图、设备运行或真实交互证据，L3/L4 必须降级为 `code_review_only`，并写清 `limitation`
- 轻量任务和 `h5f-fast` 未升级路径可以跳过 Rubric，仅输出 Mandatory Checklist

示例：

```yaml
rubric_evaluation:
  total_score: 4.1
  layer_scores:
    functional: 4.5
    robustness: 4.0
    ui: 3.8
    interaction: 4.0
  essential_pass_rate: 1.0
  pitfall_violations: 0
  details:
    - id: L1-001
      result: PASS
      score: 5
      evidence: "订单列表渲染条数与 mock 数据一致"
    - id: L3-001
      result: WARN
      score: 4
      verification_method: code_review_only
      evidence: "未进行浏览器截图验证；基于代码审查确认使用响应式 grid"
      limitation: "无真实视口截图，不能背书最终视觉观感"
  decision: pass
```

## 推荐输出

```text
[h5-forge] 验证工程师：最小验证通过
[h5-forge] 验证工程师：需要补 1 个组件测试后再放行
[h5-forge] 验证工程师：路由回归未确认，退回 S4 补验证
```

## Mandatory Checklist（P0，未完成不得宣布放行）

```yaml
checklist:
  spec_compliance: true
  requirement_coverage: true
  contract_alignment: true
  edge_cases_checked:
    - "空数据"
    - "接口失败"
    - "重复点击"
  spec_issues: []
  code_quality: true
  regression_clear: true
  quality_checks:
    - "pnpm test --filter home"
    - "手动检查订单页筛选切换"
  logs_compliant: true
  decision: pass
```

字段要求：

- `spec_compliance`：是否符合冻结需求和验收
- `requirement_coverage`：是否覆盖本轮范围
- `contract_alignment`：是否符合改动契约和禁止改动项
- `edge_cases_checked`：实际检查的边界/异常场景
- `spec_issues`：规格层问题；无则 `[]`
- `code_quality`：代码层验证是否通过
- `regression_clear`：是否未发现回归
- `quality_checks`：运行命令或人工检查证据
- `logs_compliant`：输出日志是否符合 `[h5-forge]` 协议
- `decision`：`pass | back_to_implementation | back_to_design`

当 Rubric 评分要求回退时，Checklist 的 `decision` 不得写 `pass`。
