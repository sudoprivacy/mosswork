# H5 Forge Reference - H5 技术栈识别

项目护栏扫描不再只看通用目录结构，必须识别 H5/Web 技术栈信号。

## 扫描入口

```bash
scripts/h5_stack_scan.py /path/to/h5-app
scripts/project_snapshot.py /path/to/h5-app --json
```

## 识别范围

| 类别 | 识别目标 |
|------|---------|
| 框架 | React、Vue、Next、Nuxt、Vite |
| 状态管理 | Zustand、Redux、Pinia、Vuex、React Context |
| 路由 | React Router、Vue Router、Next Router |
| 网络层 | Axios、fetch、TanStack Query、SWR |
| 样式 | Tailwind、Sass、CSS Modules、styled-components / Emotion |
| 测试 | Vitest、Jest、Testing Library、Playwright、Cypress |
| 国际化 | i18next、vue-i18n |
| 组件库 | Ant Design、Vant、Element Plus、Naive UI |

## 证据来源

每个技术栈信号都来自以下证据之一：

1. `package.json` 依赖
2. 关键配置文件名
3. 关键源码 token
4. 常见约定文件路径

## 置信度

- `high`：至少 3 条独立证据
- `medium`：至少 1 条直接证据
- `low`：未检测到直接证据，只能依赖其他文档或人工确认

扫描结果只作为草案依据，不能直接覆盖团队显式规则。

## 识别后的使用方式

识别结果主要服务以下场景：

1. 选择 `stack_profiles`
2. 生成项目护栏草案
3. 生成 `project_snapshot`
4. 判断应该优先委托哪些前端协作 skills

## 最低判断要求

首次接入已有项目时，至少要能回答：

1. 当前主框架是什么
2. 当前主路由方案是什么
3. 当前 client state 方案是什么
4. 当前 server state / 请求方案是什么
5. 当前样式方案是什么
6. 当前测试方案是什么

如果这 6 项中有 3 项以上仍不明确，不能假装“栈已识别完成”，必须以 `low confidence` 输出并在项目护栏草案中保留不确定字段。
