# H5 Forge Reference - Stack Profiles

技术栈 profile 是项目护栏初始化的建议模板。它不覆盖项目扫描结果，只用于给 `init_project_guardrails.py` 补足低置信度字段和确认清单。

## 内置 profile

| Profile | 适用场景 | 目录结构 | 路由组织 | Server State | Client State | Request 层 | Testing 默认项 |
|---------|----------|----------|----------|--------------|--------------|------------|----------------|
| `zustand_feature_profile` | Zustand / 状态管理库，feature-first 目录 | `src/features/*` | React Router / 页面路由集中管理 | Query hooks 或轻量本地 fetch 包装 | Zustand | `api/` + hooks | Vitest + Testing Library |
| `redux_module_profile` | Redux 风格，module-first 目录 | `src/modules/*` | Router 与模块入口协作 | RTK Query 或集中 request client | Redux Toolkit | `services/` / `store/` | Vitest / Jest + 关键流程回归 |
| `vue_pinia_profile` | Vue/Pinia 风格，feature-first 目录 | `src/features/*` 或 `src/modules/*` | Vue Router | composables + query / fetch | Pinia | `api/` + composables | Vitest + Vue Testing Library |
| `react_query_profile` | TanStack Query / SWR，server state 进入 query hooks | feature-first 或 app-router 协作 | React Router / Next Router | TanStack Query / SWR | 局部 state 或轻量 store | `query/` / `client/` | Vitest + 关键 query 回归 |
| `lean_h5_profile` | 尚未形成复杂架构的新项目或快速验证项目 | 扁平或轻量 feature-first | 最小路由接入 | 轻量 fetch/axios | 本地 state / Context | 简单 request 封装 | 最小人工回归 + 局部测试 |

## 自动选择规则

`scripts/init_project_guardrails.py --profile auto` 的推荐顺序：

1. 检测到 Redux → `redux_module_profile`
2. 检测到 Zustand → `zustand_feature_profile`
3. 检测到 Vue/Pinia → `vue_pinia_profile`
4. 检测到 TanStack Query / SWR → `react_query_profile`
5. 无明显主流技术栈 → `lean_h5_profile`

## 使用方式

```bash
python3 scripts/init_project_guardrails.py /path/to/app --profile auto
python3 scripts/init_project_guardrails.py /path/to/app --profile zustand_feature_profile
python3 scripts/init_project_guardrails.py /path/to/app --interactive
```

`--interactive` 会输出推荐 profile、扫描摘要和高风险确认清单。脚本仍只写 `_draft` 草案，不直接生成正式项目护栏。

## 原则

- profile 是建议，不是事实
- 扫描 evidence 优先于 profile
- profile 填补低置信度字段时必须保留 low / medium confidence
- 用户确认前只能写 `*.project_guardrails_draft.yaml`
- profile 解决的是“默认值不足”，不是“覆盖项目既有约定”
