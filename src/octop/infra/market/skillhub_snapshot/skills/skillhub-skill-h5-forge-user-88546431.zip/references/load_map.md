# H5 Forge Reference - Load Map

这个文件定义主 skill 之外的按需加载映射。主 `SKILL.md` 不再重复列出大量“遇到什么就读什么”的声明。

## 场景 -> 参考文件

### 迭代中项目首次接入

- [project_init_flow.md](project_init_flow.md)
- [existing_project_entry.md](existing_project_entry.md)
- [existing_project_scan.md](existing_project_scan.md)
- [h5_stack_detection.md](h5_stack_detection.md)
- [stack_profiles.md](stack_profiles.md)
- [project_guardrails_template.yaml](project_guardrails_template.yaml)
- [example_project_guardrails.yaml](example_project_guardrails.yaml)
- [existing_rules_discovery.md](existing_rules_discovery.md)

### 新 H5/Web 应用从 0 到 1

- [new_project_cocreation_mode.md](new_project_cocreation_mode.md)
- [new_project_app_profiles.md](new_project_app_profiles.md)
- [new_project_profile_selection.md](new_project_profile_selection.md)
- [stack_profiles.md](stack_profiles.md)
- [project_init_flow.md](project_init_flow.md)
- [project_guardrails_template.yaml](project_guardrails_template.yaml)

### 相似实现检索与复用追踪

- [similar_implementation_search.md](similar_implementation_search.md)

### 进入具体任务执行

- [fast_mode.md](fast_mode.md)
- [autonomous_mode.md](autonomous_mode.md)
- [decision_and_question_protocol.md](decision_and_question_protocol.md)
- [task_runtime_prompt.md](task_runtime_prompt.md)

### 需要记忆读写规则

- [memory_protocol.md](memory_protocol.md)

### 需要工程判断标准或 H5/Web 专项规则

- [engineering_heuristics.md](engineering_heuristics.md)
- [h5_stack_detection.md](h5_stack_detection.md)
- [stack_profiles.md](stack_profiles.md)

### 需要前端协作 skills 委托规则

- [frontend_skills.md](frontend_skills.md)
- [frontend_skill_aliases.yaml](frontend_skill_aliases.yaml)
- [delegation_map.yaml](delegation_map.yaml)

### 需要判断宿主对子代理的支持与降级路径

- [host_subagent_support.md](host_subagent_support.md)

### 需要网络层项目规则

- [network_and_api.md](network_and_api.md)

### 需要路由层项目规则

- [routing_and_navigation.md](routing_and_navigation.md)

### 需要测试与质量建议

- [roles/verify_agent.md](roles/verify_agent.md)
- [rubric_evaluation.md](rubric_evaluation.md)
- [tdd_discipline.md](tdd_discipline.md)
- [testing_strategy.md](testing_strategy.md)
- [quality_gates.md](quality_gates.md)
- [build_and_quality.md](build_and_quality.md)

### 需要决策、提问或阶段门禁细则

- [decision_and_question_protocol.md](decision_and_question_protocol.md)
- [fast_mode.md](fast_mode.md)
- [autonomous_mode.md](autonomous_mode.md)
- [phase_checkpoint.md](phase_checkpoint.md)

### 需要反模式、模板或调试手册

- [anti_patterns.md](anti_patterns.md)
- [templates_catalog.md](templates_catalog.md)
- [debugging_playbook.md](debugging_playbook.md)
- [systematic_debugging.md](systematic_debugging.md)

### 需要架构决策记录格式

- [adr_format.md](adr_format.md)

### 需要角色交接格式

- [role_handoff_formats.md](role_handoff_formats.md)

### 需要处理输入不完整场景

- [input_incomplete_handling.md](input_incomplete_handling.md)

### 需要可见性标记或当前大任务状态规则

- [skill_visibility.md](skill_visibility.md)
- [session_management.md](session_management.md)

### 需要启动握手输出格式

- [startup_handshake.md](startup_handshake.md)

### 需要项目护栏协议

- [project_guardrails_protocol.md](project_guardrails_protocol.md)

### 需要项目初始化流程

- [project_init_flow.md](project_init_flow.md)

### 需要触发词权威列表

- [trigger_words.md](trigger_words.md)

### 需要主工作流可视化

- [workflow_diagram.md](workflow_diagram.md)

### 需要代码审查模式

- [code_review_mode.md](code_review_mode.md)

### 需要迁移辅助

- [migration_assist.md](migration_assist.md)

### 需要国际化/无障碍检查

- [i18n_a11y_check.md](i18n_a11y_check.md)

### 需要案例或验证记录

- [case_studies.md](case_studies.md)
- [case_study_member_center.md](case_study_member_center.md)
- [case_study_large_rework.md](case_study_large_rework.md)
- [validation_log.md](validation_log.md)
- [demo_transcript.md](demo_transcript.md)
- [mode_test_cases.md](mode_test_cases.md)

### 需要发布与产品化检查

- [release_playbook.md](release_playbook.md)
- [release_bindings.json](release_bindings.json)
- [maintenance_map.md](maintenance_map.md)
- [archive/rule_card_validation.md](archive/rule_card_validation.md)

### 需要跨 forge controller 协议或模型选择建议

- [forge_controller_protocol.md](forge_controller_protocol.md)
- [model_selection.md](model_selection.md)

## 反向索引：每个参考文件被哪些上层文件引用

维护时用此表检查引用完整性。新增 reference 文件时同步更新此表。

| 参考文件 | 被引用方 |
|---------|---------|
| task_runtime_prompt.md | SKILL.md（执行协议）、load_map.md |
| phase_checkpoint.md | SKILL.md（阶段门禁）、task_runtime_prompt.md、load_map.md |
| fast_mode.md | SKILL.md（h5f-fast）、load_map.md |
| autonomous_mode.md | SKILL.md（h5f-a）、load_map.md |
| decision_and_question_protocol.md | SKILL.md（提问协议）、task_runtime_prompt.md、skill_visibility.md、load_map.md |
| skill_visibility.md | SKILL.md（输出日志）、load_map.md |
| session_management.md | SKILL.md（上下文恢复）、load_map.md |
| startup_handshake.md | SKILL.md（启动判定）、load_map.md |
| project_guardrails_protocol.md | SKILL.md（项目护栏检查）、task_runtime_prompt.md、load_map.md |
| archive/rule_card_validation.md | load_map.md |
| project_init_flow.md | SKILL.md（项目初始化）、load_map.md |
| memory_protocol.md | SKILL.md（记忆机制）、load_map.md |
| engineering_heuristics.md | load_map.md |
| h5_stack_detection.md | load_map.md |
| stack_profiles.md | load_map.md |
| frontend_skills.md | load_map.md |
| frontend_skill_aliases.yaml | frontend_skills.md、load_map.md |
| delegation_map.yaml | frontend_skills.md、load_map.md |
| host_subagent_support.md | SKILL.md（并行协议）、task_runtime_prompt.md、load_map.md |
| similar_implementation_search.md | SKILL.md（相似实现）、load_map.md |
| input_incomplete_handling.md | load_map.md |
| network_and_api.md | load_map.md |
| routing_and_navigation.md | load_map.md |
| roles/verify_agent.md | task_runtime_prompt.md、load_map.md |
| rubric_evaluation.md | SKILL.md（目标治理）、roles/verify_agent.md、load_map.md、release_bindings.json |
| tdd_discipline.md | SKILL.md（目标治理）、load_map.md |
| systematic_debugging.md | SKILL.md（核心原则）、load_map.md |
| forge_controller_protocol.md | load_map.md、maintenance_map.md |
| model_selection.md | load_map.md |
| release_bindings.json | maintenance_map.md、load_map.md |
| testing_strategy.md | task_runtime_prompt.md、load_map.md |
| quality_gates.md | task_runtime_prompt.md、load_map.md |
| build_and_quality.md | load_map.md |
| anti_patterns.md | load_map.md |
| templates_catalog.md | load_map.md |
| debugging_playbook.md | load_map.md |
| adr_format.md | load_map.md |
| role_handoff_formats.md | load_map.md |
| code_review_mode.md | load_map.md |
| migration_assist.md | load_map.md |
| i18n_a11y_check.md | load_map.md |
| release_playbook.md | load_map.md |
| case_studies.md | load_map.md |
| case_study_member_center.md | load_map.md |
| case_study_large_rework.md | load_map.md |
| mode_test_cases.md | load_map.md |
| demo_transcript.md | load_map.md |
| validation_log.md | load_map.md |
| trigger_words.md | SKILL.md（命中路由）、README.md、QUICKSTART.md、CHEATSHEET.md、load_map.md |
| workflow_diagram.md | load_map.md |
| roles/page_engineer.md | task_runtime_prompt.md、load_map.md |
| roles/requirement_analyst.md | task_runtime_prompt.md、load_map.md |
| roles/ui_designer.md | task_runtime_prompt.md、load_map.md |
| roles/architecture_designer.md | task_runtime_prompt.md、load_map.md |
