# H5 Forge Quickstart

3 分钟上手，只记两类内容：`怎么触发` 和 `怎么自检`。

## 用户入口

### 1. 标准入口

```text
h5f- 新增一个订单列表页，接入现有路由和状态管理
```

标准入口会自动路由：小改动直接做，新页面/大功能先收口需求、UI 和架构。

### 2. 快速入口

```text
h5f-fast 帮我把登录页按钮颜色和文案改掉
```

快速入口优先走轻量/中等路径，最多读取少量关键文件。发现结构风险时才升级。

### 3. 全自动入口

```text
h5f-a 做一个会员中心页，缺少的部分按你推荐方案推进直到做完
```

全自动入口会把非阻塞缺口写成 `auto_assumption` 并继续执行。高风险事项仍会中断确认。

### 4. 首次接入已有项目

```text
h5f- 这是一个迭代中的 H5/Web 项目。先扫描项目结构，生成规则卡草案，不要写代码。
```

## 维护命令

### 1. 初始化项目

```bash
scripts/project_snapshot.py /path/to/h5-app
scripts/init_rule_card.py /path/to/h5-app --interactive
```

`project_snapshot.py` 会输出目录结构、技术栈摘要、路由入口、状态入口、网络入口、测试入口和共享层线索。

### 2. 协作 skill 探测

```bash
scripts/discover_h5_skills.sh
```

用于固定前端协作 skills 的优先搜索目录，写入 `.h5-forge/skill_mapping.local.env`。

### 3. 自检

```bash
scripts/doctor.sh
scripts/validate_release.sh
```

自检会检查版本一致、规则卡 schema、H5 技术栈扫描、路由 golden、文档链接和 demo fixture。

完整触发词与匹配规则见 [references/trigger_words.md](references/trigger_words.md)。
