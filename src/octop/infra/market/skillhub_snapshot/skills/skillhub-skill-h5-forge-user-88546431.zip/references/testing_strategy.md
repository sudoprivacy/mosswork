# H5 Forge Reference - Testing Strategy

H5 Forge 把测试视为交付链路的一部分，而不是事后补丁。

## 这份文档负责什么

这份文档只回答一个问题：

`本轮任务应该补什么类型的测试？`

是否可以放行，由 [roles/verify_agent.md](roles/verify_agent.md) 决定；这份文档不直接宣布“验证通过”。

## 基本原则

1. 小改动不强行补重测试，但必须判断是否影响已有行为
2. 新组件、新交互、新状态切换优先考虑 Component 测试
3. 关键用户流程优先考虑集成测试或 E2E
4. 可复用 UI 组件优先考虑预览、storybook-like 展示或状态矩阵
5. 修复回归性 bug 时，优先补最接近回归点的最小测试

## 何时加 Component 测试

以下场景优先考虑：

- 新增可复用组件
- 组件存在明显交互行为
- 组件有多种状态展示
- 修复过 UI 逻辑 bug，且容易回归

如果工作区有前端协作 skills，优先委托：

- `frontend-testing-apps`
- 或项目已安装的 Vitest / Testing Library 类 skill

## 何时加集成测试

以下场景优先考虑：

- 登录、下单、支付、续费、搜索等关键主路径
- 多页面跳转且状态依赖明显
- Bug 修复涉及完整用户流程
- 路由接入、权限分支、表单提交流程

如果工作区有前端协作 skills，优先委托：

- `frontend-testing-apps`
- 或项目已安装的 Playwright / Cypress / Testing Library 类 skill

## 何时只做最小验证

以下场景通常可以不新增自动化，只做最小验证说明：

- 文案、颜色、间距、局部样式小改动
- 已定位且局部的非流程类 bug 修复
- 不新增状态分支
- 不改关键用户路径

即便如此，也要显式说明为什么“不补自动化”是可接受的。

## 测试文件放置建议

默认约定：

- Component 测试：`test/components/` 或贴近 feature 的 `test/features/<feature>/`
- 集成 / E2E 测试：`e2e/`、`tests/e2e/` 或项目现有目录
- 组件预览 / story-like：项目既有 `stories/`、`playground/` 或 `preview/`

最终仍以项目现有主流结构为准。

## 命名建议

- Component 测试：`<component_or_page_name>.test.js/ts(x)`
- 集成测试：`<flow_name>.flow.test.js/ts(x)` 或项目主流命名
- E2E：`<flow_name>.spec.js/ts`

## 最低测试判断

在页面开发结束后，至少做一次判断：

1. 是否改了用户可见行为？
2. 是否引入了新的状态分支？
3. 是否修了容易回归的问题？
4. 是否属于关键用户路径？
5. 是否新增了路由、权限、缓存或请求链路？

如果至少有一个答案是“是”，就不应直接跳过测试策略说明。

## 推荐输出

```text
[h5-forge] 验证工程师：建议补 1 个组件测试，覆盖 loading / success / error 三态
[h5-forge] 验证工程师：本轮只做最小人工回归，不新增自动化，原因是改动仅限按钮文案
```
