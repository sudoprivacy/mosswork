# H5 Forge Maintenance Map

这份文档只服务维护者。它回答一件事：**想改某类规则时，最少需要同步哪些文件。**

不要把它写成协议文档。它是维护导航图，不是行为规范。

## 1. 改阶段门禁

必看：

- [SKILL.md](../SKILL.md)
- [decision_and_question_protocol.md](decision_and_question_protocol.md)
- [task_runtime_prompt.md](task_runtime_prompt.md)

必改：

- [SKILL.md](../SKILL.md)
- [scripts/gate_check.py](../scripts/gate_check.py)
- [scripts/validate_release.sh](../scripts/validate_release.sh) 或对应 `scripts/release_checks/*.sh`

如果门禁依赖 session 状态，还要改：

- [session_management.md](session_management.md)
- [scripts/ff_session.sh](../scripts/ff_session.sh)
- [scripts/controller.py](../scripts/controller.py)

## 2. 改 session 字段

必改：

- [session_management.md](session_management.md)
- [scripts/ff_session.sh](../scripts/ff_session.sh)

通常还要改：

- [scripts/gate_check.py](../scripts/gate_check.py)
- [scripts/controller.py](../scripts/controller.py)
- [scripts/release_checks/session.sh](../scripts/release_checks/session.sh)
- [scripts/release_checks/gates.sh](../scripts/release_checks/gates.sh)

## 3. 改角色边界

必改：

- [roles/requirement_analyst.md](roles/requirement_analyst.md)
- [roles/ui_designer.md](roles/ui_designer.md)
- [roles/architecture_designer.md](roles/architecture_designer.md)
- [roles/page_engineer.md](roles/page_engineer.md)
- [roles/verify_agent.md](roles/verify_agent.md)

如果角色边界涉及文件写入权限，还要改：

- [scripts/gate_check.py](../scripts/gate_check.py)
- [agent_isolation_protocol.md](agent_isolation_protocol.md)

## 4. 改 `h5f-fast` / `h5f-a` 豁免边界

必改：

- [SKILL.md](../SKILL.md)
- [fast_mode.md](fast_mode.md)
- [autonomous_mode.md](autonomous_mode.md)
- [decision_and_question_protocol.md](decision_and_question_protocol.md)

通常还要改：

- [scripts/gate_check.py](../scripts/gate_check.py)
- [scripts/release_checks/gates.sh](../scripts/release_checks/gates.sh)
- [scripts/release_checks/output_protocol.sh](../scripts/release_checks/output_protocol.sh)

## 5. 改 output protocol / 日志协议

必改：

- [skill_visibility.md](skill_visibility.md)
- [task_runtime_prompt.md](task_runtime_prompt.md)
- [scripts/validate_output.sh](../scripts/validate_output.sh)

通常还要改：

- [scripts/release_checks/output_protocol.sh](../scripts/release_checks/output_protocol.sh)
- [README.md](../README.md)

## 6. 改 project guardrails 协议

必改：

- [project_guardrails_protocol.md](project_guardrails_protocol.md)
- [scripts/check_project_guardrails.sh](../scripts/check_project_guardrails.sh)
- [scripts/init_project_guardrails.py](../scripts/init_project_guardrails.py)

通常还要改：

- [scripts/hook_check_project_guardrails.sh](../scripts/hook_check_project_guardrails.sh)
- [scripts/release_checks/guardrails.sh](../scripts/release_checks/guardrails.sh)

## 7. 改发布校验

入口：

- [scripts/validate_release.sh](../scripts/validate_release.sh)

按领域改对应模块：

- 元数据与版本：`scripts/release_checks/metadata.sh`
- guardrails 与路由：`scripts/release_checks/guardrails.sh`
- session：`scripts/release_checks/session.sh`
- gate 与 controller：`scripts/release_checks/gates.sh`
- 角色 checklist 与 Rubric：`scripts/release_checks/checklists.sh`
- Rubric 评分证据：`scripts/release_checks/rubric_evaluation.sh`
- release binding：`scripts/release_checks/release_bindings.sh`
- 日志与输出协议：`scripts/release_checks/output_protocol.sh`

原则：

- 不要再把新的大段逻辑直接塞回 `validate_release.sh`
- 优先在对应模块文件里新增/修改断言

## 7.1 改目标治理 / Rubric

必改：

- [SKILL.md](../SKILL.md)
- [rubric_evaluation.md](rubric_evaluation.md)
- [roles/requirement_analyst.md](roles/requirement_analyst.md)
- [roles/verify_agent.md](roles/verify_agent.md)

通常还要改：

- [scripts/validate_checklist.py](../scripts/validate_checklist.py)
- [scripts/validate_rubric.py](../scripts/validate_rubric.py)
- [scripts/validate_rubric_evaluation.py](../scripts/validate_rubric_evaluation.py)
- [scripts/release_checks/checklists.sh](../scripts/release_checks/checklists.sh)
- [scripts/release_checks/rubric_evaluation.sh](../scripts/release_checks/rubric_evaluation.sh)

release_binding: RB-CHECKLIST-001
release_binding: RB-RUBRIC-EVAL-001

## 7.2 改 P0/P1 release binding

必改：

- [release_bindings.json](release_bindings.json)
- [scripts/validate_release_bindings.py](../scripts/validate_release_bindings.py) 或对应 release check
- [scripts/release_checks/release_bindings.sh](../scripts/release_checks/release_bindings.sh)

原则：

- 新增或修改 P0/P1 行为规则时，必须在 [release_bindings.json](release_bindings.json) 中保留正反例。
- 每个 binding 必须至少有一个 active doc 中的 `release_binding:` 标记。

release_binding: RB-BINDINGS-001

## 8. 改入口文档

用户入口：

- [README.md](../README.md)
- [QUICKSTART.md](../QUICKSTART.md)
- [CHEATSHEET.md](../CHEATSHEET.md)

维护入口：

- [load_map.md](load_map.md)
- [maintenance_map.md](maintenance_map.md)

## 9. 先查哪里，再动哪里

推荐顺序：

1. 先看 [core_contracts.yaml](core_contracts.yaml) 确认当前主数据项
2. 再看这份 `maintenance_map.md` 找出受影响文件
3. 最后跑 `bash scripts/validate_release.sh`

## 10. Release Binding Index

- release_binding: RB-ROUTE-001 — 触发词与路由 golden cases
- release_binding: RB-GUARDRAILS-001 — 项目根状态与 project_guardrails
- release_binding: RB-GATE-001 — S4 写入门禁
- release_binding: RB-GATE-002 — 核心定义、子单元、范围风险、计划冲突与退出锁
- release_binding: RB-SESSION-001 — 等待态与恢复
- release_binding: RB-SESSION-002 — G17/G18 迭代控制
- release_binding: RB-OUTPUT-001 — 可见输出协议
- release_binding: RB-AUTONOMOUS-001 — h5f-a 豁免边界与全自动摘要
- release_binding: RB-DOCS-001 — active docs 与脚本引用同步
