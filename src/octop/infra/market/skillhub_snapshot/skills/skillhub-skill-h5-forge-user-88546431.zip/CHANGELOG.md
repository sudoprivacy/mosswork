# Changelog

说明：

- `v0.1.0` 开启 v 前缀发布线，用于和历史无 `v` 的 `0.x.x` 版本隔离
- `0.4.x` 及更早版本保留为历史事实；当前现行入口、规则卡路径和发布检查以 `v0.1.0` 后的文档为准

## v0.3.5

发布 H5 Forge v0.3.5：对齐 Flutter Forge v0.3.4 的通用治理能力，并保留 H5/Web 专项适配层。

### 目标治理与验证

- 新增 `references/rubric_evaluation.md`：引入 `quality_tier`、Rubric 条目、S5 评分和 G17/G18 迭代控制。
- 新增 `references/tdd_discipline.md`：polished/production 品质锚定时激活测试先行纪律。
- 新增 `references/systematic_debugging.md`：S4 遇到 bug、测试失败或异常行为时先调查根因，再修复。
- 更新 `SKILL.md`：新增目标治理、连续执行、G17/G18/G12b、方案零占位符规则和 P1/P2 维护规则。

### Controller 与发布绑定

- 新增 `references/forge_controller_protocol.md`：记录跨 forge 的通用 controller 协议和 H5 当前映射。
- 新增 `references/model_selection.md`：提供角色、阶段和策略对应的模型选择建议。
- 新增 `references/release_bindings.json` 与 `scripts/validate_release_bindings.py`：P0/P1 规则必须绑定 release check。
- 新增 `scripts/validate_rubric.py` 与 `scripts/validate_rubric_evaluation.py`：校验 Rubric 条目和 S5 评分块。

### 运行面同步

- 更新 `scripts/ff_session.sh`：加入迭代状态更新能力。
- 更新 `scripts/gate_check.py`：同步新版 gate 结构，并适配 H5/Web 文件类型、状态管理、路由和共享层边界。
- 更新 `scripts/controller.py` 与 `scripts/validate_output.sh`：同步角色上下文过滤和输出协议增强。
- 新增 `scripts/release_checks/checklists.sh`、`rubric_evaluation.sh`、`release_bindings.sh`，并接入发布校验。

## v0.3.0

全面复刻 Flutter Forge v0.3.0 的门禁代码化、角色边界硬隔离和全局宪法机制到 H5/Web 技术栈。

### 核心概念变更

- **规则卡 → 项目护栏**（`rule_card` → `project_guardrails`）：全面重命名，概念从"规则记忆文件"升级为"项目锚点与长期护栏"
- **Global Constitution**：新增 7 条全局宪法，高于模式、角色和执行策略
- **角色隔离执行**：每个角色通过隔离子代理执行，避免单 LLM 上下文污染和角色越权
- **项目根状态模型**：`detect_project_root_state.py` 三态分类（`h5_existing` / `non_h5` / `empty_new`）

### 新增文件

- 新增 `references/project_guardrails_protocol.md`：项目护栏协议，替代 `rule_card_protocol.md`
- 新增 `references/agent_isolation_protocol.md`：角色隔离执行协议，5 角色子代理架构与 Gate 5 代码强制边界
- 新增 `references/core_contracts.yaml`：核心数据契约，session 字段、gate 定义、策略矩阵和维护面映射
- 新增 `references/workflow_diagram.md`：主工作流 digraph 可视化（主流程/阶段门禁/策略选择）
- 新增 `references/issue-ledger.md`：agent-pm 审查问题生命周期记录
- 新增 `references/maintenance_map.md`：维护导航图，改某类规则时的最少同步文件清单
- 新增 `scripts/controller.py`：决策引擎，角色选择、上下文组装、agent prompt 生成
- 新增 `scripts/gate_check.py`：Gate 1-11 门禁检查，角色越权写入阻断（Gate 5）
- 新增 `scripts/validate_checklist.py`：角色 checklist YAML 校验
- 新增 `scripts/validate_output_prefix.sh`：输出前缀校验
- 新增 `scripts/check_project_guardrails.sh`：项目护栏快速查找，替代 `check_rule_card.sh`
- 新增 `scripts/hook_check_project_guardrails.sh`：preToolCall hook，替代 `hook_check_rule_card.sh`
- 新增 `scripts/init_project_guardrails.py`：项目护栏初始化，替代 `init_rule_card.py`
- 新增 `scripts/validate_project_guardrails.py`：项目护栏校验，替代 `validate_rule_card.py`
- 新增 `scripts/validate_project_guardrails_resolution.py`：项目护栏路径解析校验
- 新增 `scripts/detect_project_root_state.py`：项目根状态检测（h5_existing/non_h5/empty_new）
- 新增 `scripts/release_checks/` 目录：发布校验模块化（lib/metadata/guardrails/session/gates/output_protocol）
- 新增 `tests/checklist_fixtures/` 目录：7 个角色 checklist 正反例测试用例

### 重写文件

- 重写 `SKILL.md`：新增 Global Constitution、角色隔离执行、项目根状态模型、门禁 #12-#16（目标/范围/验收/约束冻结、子单元冻结、超范围回退、工作模式锁、验证真实性）
- 重写 `references/session_management.md`：新增 `save-resume`/`check-resume`/`consume-resume` 命令、20+ 新 session 字段、host 目录优先级
- 重写 `references/task_runtime_prompt.md`：增强启动序列、项目护栏集成、角色隔离执行流程
- 重写 `references/skill_visibility.md`：新增 checklist 校验集成、输出前缀校验
- 重写 `references/trigger_words.md`：更新触发词清单和防误触发规则

### 更新文件

- 更新 `scripts/ff_session.sh`：新增 `save-resume`/`check-resume`/`consume-resume` 命令、新 session 字段（改动契约/确认状态/目标状态/范围状态/验收状态/约束状态/当前子单元/子单元状态/验证状态/超范围风险/计划冲突状态/任务结束条件/工作模式锁/退出许可/摘要包）
- 更新 `scripts/classify_task.sh`：`should_load_rule_card` → `should_load_project_guardrails`、`rule_card_check` → `project_guardrails_check`
- 更新 `scripts/validate_output.sh`：新增 `--expect-fast`/`--expect-autonomous`、增强收口校验（S1/S5 链、角色结论要求）
- 更新 `scripts/validate_release.sh`：模块化调用 `release_checks/*.sh`
- 更新 5 个角色文件：新增 Mandatory Checklist YAML 块、角色边界硬隔离约束
- 更新 `references/load_map.md`：新增项目护栏协议、角色隔离、核心契约等文件映射

### 存档

- `references/rule_card_protocol.md` → `references/archive/rule_card_protocol.md`
- `references/rule_card_validation.md` → `references/archive/rule_card_validation.md`
- `references/validation_log.md` → `references/archive/validation_log.md`

### 删除旧文件

- 删除 `scripts/check_rule_card.sh`（替代：`scripts/check_project_guardrails.sh`）
- 删除 `scripts/hook_check_rule_card.sh`（替代：`scripts/hook_check_project_guardrails.sh`）
- 删除 `scripts/init_rule_card.py`（替代：`scripts/init_project_guardrails.py`）
- 删除 `scripts/validate_rule_card.py`（替代：`scripts/validate_project_guardrails.py`）
- 删除 `scripts/validate_rule_card_resolution.py`（替代：`scripts/validate_project_guardrails_resolution.py`）

## v0.2.1

本次发布把 h5-forge 的主控协议、验证收口、前端协作委托和对外文档统一到同一条产品线，并明确前端协作 skill 由大模型在当前环境中自行探索，不要求仓库内提供本地 `frontend-skills/` 目录。

### 协议与参考文档

- `SKILL.md` 补回 `Iron Law`，恢复“先确认需求与方案，再写实现”的全局硬门禁
- 重组 `references/load_map.md`，补齐决策协议、子代理支持、验证角色和流程总览入口
- 新增 `references/roles/verify_agent.md`，把“测试策略”和“放行决策”正式拆开
- 新增 `references/workflow_diagram.md`，提供主流程、`h5f-fast`、`h5f-a` 的可视化总览
- 收口 `references/task_runtime_prompt.md`、`references/testing_strategy.md`、`references/system_prompt.md`

### 前端协作 skills

- 重写 `references/frontend_skills.md`，改为由大模型自行探索当前环境中的可用前端 skills
- 重写 `references/delegation_map.yaml`，保留抽象能力、常见别名和 fallback，不再声明本地 `frontend-skills/` 路径
- 保留 `references/frontend_skill_aliases.yaml` 作为抽象 skill 到常见别名的等价映射

### 扫描与项目摘要

- 更新 `references/h5_stack_detection.md` 与 `references/stack_profiles.md`，补齐 H5/Web 技术栈识别、profile 用法和低置信字段原则
- 扩展 `scripts/project_snapshot.py`，新增样式入口、共享层、相似实现和更干净的技术栈摘要输出

### 对外文档

- 更新 `README.md`、`QUICKSTART.md`、`CHEATSHEET.md`
- README 中统一当前版本显示、前端协作 skill 探测顺序、参考文档映射和项目结构说明

## v0.2.0

全面复刻 Flutter Forge v0.2.2 的成熟机制到 H5/Web 技术栈。核心目标：让 h5-forge 拥有与 flutter-forge 同等质量的工程化保障，同时保留 H5/Web 特有的前端协作 skills 集成。

### 新增文件

- 新增 `references/trigger_words.md`：触发词单一权威来源，包含防误触发硬规则和文档引用规则
- 新增 `scripts/validate_checklist.py`：角色 checklist YAML 校验脚本，支持 4 个角色（requirement_analyst/ui_designer/architecture_designer/page_engineer）
- 新增 `scripts/hook_check_rule_card.sh`：preToolCall hook，未初始化项目写操作硬阻断，H5/Web 特化风险 token（package.json/vite.config/webpack.config/store/context/reducer/src/core/src/shared）
- 新增 `references/phase_checkpoint.md`：阶段转换检查点动作（状态回写→输出校验→阶段日志输出），S2→S4 硬阻断检查清单

### 重写文件

- 重写 `SKILL.md`：全面对齐 flutter-forge P0/P1 规则体系，新增 gate #9（S2→S4 硬阻断）、#10（session 持久化）、#11（写前改动契约），新增首行 controller 输出强制、checklist 校验 P0 规则、trigger_words.md 引用、规则卡缓存和 task gate 集成
- 重写 `references/task_runtime_prompt.md`：17 步启动序列、脚本路径解析、session 恢复强匹配/弱匹配/反向排除、checklist 校验（P0）、阶段转换自检矩阵、草案静默转正检查、S2 后用户追加输入处理
- 重写 `references/skill_visibility.md`：P0/P1 执行强制性分级表、增强输出校验（--require-s4/--require-complete）、裸结论拦截、写前改动契约跟踪、中等任务示例

### 更新文件

- 更新 `scripts/check_rule_card.sh`：新增 --cached（300s TTL）、--json、--increment-usage、--reset-usage、--increment-reminder、--reset-reminder、--promote-draft 模式，新增 draft_usage_count/draft_reminder_count 跟踪和 runtime 状态文件管理
- 更新 `scripts/classify_task.sh`：新增 --project-root/--write-gate 选项，扩展输出字段（should_load_rule_card/rule_card_check/required_phases/upgrade_signals），新增 task_gate.json 写入供 hook 集成，新增等待态和启动握手检测，新增 h5f- 触发词剥离
- 更新 `scripts/validate_output.sh`：新增 --require-complete/--require-s4 参数，新增阶段全名校验（如 S1 需求确认 不可写 S1 需求分析），新增裸结论拦截，新增写前改动契约跟踪，新增全自动模式检测（h5f-a 豁免契约要求）
- 更新 `scripts/ff_session.sh`：新增 wait 子命令（--waiting_state/--expected_input/--pending_question/--task_object），新增 session 字段（等待状态/等待输入类型/待确认问题/任务对象/恢复键/最近用户输入）
- 更新 `references/rule_card_protocol.md`：新增缓存机制节（300s TTL/cache_hit/cache_age）、草案计数与转正节（--increment-usage/--promote-draft）、脚本降级路径解析节
- 更新 `references/load_map.md`：新增 trigger_words.md、phase_checkpoint.md 和 4 个角色文件的场景→文件映射和反向索引

### 角色 Checklist 强制化

4 个角色文件新增 Mandatory Checklist（P0）YAML 块：

- `references/roles/page_engineer.md`：target_files/changes/freeze_alignment/deviations/regression_scope/verification_type/commands_run
- `references/roles/requirement_analyst.md`：business_goal/scope_in/scope_out/key_branches/non_functional/task_semantic/decision
- `references/roles/ui_designer.md`：source/blocks/hierarchy/interactions/missing_inputs/component_ownership/decision
- `references/roles/architecture_designer.md`：module_layout/state_management/routing/freeze_constraints/reuse_strategy/write_scope/decision

### 关键机制移植

从 Flutter Forge 理解思路后复刻（非简单复制）：

1. **S2→S4 硬阻断**：S2 方案确认完成后必须在下一条回复进入 S4 实现中，不允许在 S2 输出结论后退出
2. **写前改动契约**：中等及以上非 h5f-a 任务进入写操作前必须输出允许改动/禁止改动/行为不变项/确认状态
3. **Session 持久化**：每次阶段切换/等待用户输入时通过 ff_session.sh 写入状态，支持上下文压缩后恢复
4. **规则卡缓存与草案转正**：300s TTL 缓存 + 连续 5 次无冲突使用自动转正
5. **preToolCall hook 写阻断**：未初始化项目写操作硬阻断，task gate 放行轻量/直通写入
6. **Checklist 校验**：角色宣布放行前必须输出 YAML checklist 并通过 validate_checklist.py 校验
7. **输出格式校验增强**：--require-s4 防 S2 掉链、--require-complete 强制完成日志
8. **触发词单一来源**：trigger_words.md 作为唯一权威清单，其他文档不再维护并列清单

### 适配差异

- 路径前缀：h5-forge 使用 `src/` 而非 `lib/`，`.h5-forge/` 而非 `.flutter-forge/`
- 风险 token：H5/Web 特化（package.json/vite.config/webpack.config/store/context/reducer）替代 Flutter 特化（pubspec.yaml/provider/bloc/cubit）
- 角色数量：h5-forge 4 个角色（无 verify_agent），checklist 校验只覆盖 4 个
- 前端协作 skills：h5-forge 保留原有前端 skills 集成不变

## v0.1.2

回溯 Flutter Forge v0.1.4 的规则卡初始化链路修复。

- 修复规则卡初始化链路根因：SKILL.md 路由步骤 1 从概念描述改为明确脚本执行指令（"运行 `scripts/check_rule_card.sh`"），标注"必须执行的动作，不是可选判断"，解决 agent 跳过规则卡检查的问题

## v0.1.1

对齐 Flutter Forge v0.1.3 的成熟机制，补齐参考文档、脚本和协议。

- 修复 "h5f a" 触发词不一致：SKILL.md 触发条件补充 "h5f a"，classify_task.sh 正则修复 `h5f a` 不匹配问题
- 新增 `references/decision_and_question_protocol.md`：决策域、一问一答、阶段门禁、摘要包协议、前置阶段并发边界
- 修复路由顺序重复维护：SKILL.md 路由改为 12 步单一权威定义
- 修复脚本失败回退缺失：check_rule_card.sh 和 classify_task.sh 脚本不存在或执行失败时补充降级路径
- 修复 h5f-fast 升级后日志限额冲突：明确升级日志不计入轻量任务 2 条限额
- 优化 Session 恢复判定：增加强匹配/弱匹配/反向排除三级判定规则
- 补充"等待态"行为约束：上下文保持、恢复方式、超时处理
- 新增 S6 完成阶段定义：收口状态 + 完成日志 + 规则卡出口 + 退出
- 新增 h5f-fast vs h5f-a 快速对比表
- 新增升级信号判定标准表（需求缺口/UI结构决策/架构边界风险）
- 新增降级条件定义
- 新增用户中途打断/取消协议
- 新增 C3 冻结输出要求（目标与场景/结构方向/工程组织/首批范围）
- 新增 S0 退出条件定义
- 新增 `references/host_subagent_support.md`：宿主子代理并行支持协议与串行降级
- 补齐 `references/fast_mode.md`：从 28 行扩展到 118 行，补充升级条件、UI 边界、降级规则、可见输出
- 补齐 `references/skill_visibility.md`：从 128 行扩展到 310 行，补全日志分层、各任务类型可见性、输出校验脚本
- 补齐 `references/autonomous_mode.md`：从 34 行扩展到 84 行，补充触发方式、自动决策范围、中断确认、阶段门禁变化
- 补齐 `references/rule_card_protocol.md`：从 133 行扩展到 225 行，补充快速查找脚本、草案校验、用户询问规范
- 补齐 `references/stack_profiles.md`：从 22 行扩展到 40 行，补充自动选择规则和使用示例
- 新增 `scripts/classify_task.sh`：任务预分类脚本，输出 mode/confidence/policy/matched_by
- 新增 `scripts/check_rule_card.sh`：规则卡快速查找脚本，输出 status/path/project_name
- 新增 `scripts/validate_output.sh`：输出格式校验，检查 [h5-forge] 标记、模式名、阶段编号、角色名
- 新增 `scripts/ff_session.sh`：session.md 结构化管理（read/init/update/reset/validate）
- 新增 `scripts/find_existing_rules.sh`：扫描项目中已有规则文件
- 修复 .skillhub.json 版本格式：`v0.1.0` → `0.1.1`（JSON 应无 v 前缀）
- 修复 README 示例阶段名：`需求理解 -> 设计包` → `页面开发`，对齐 SKILL.md 模式名
- P0/P1 规则补充 h5f-fast/h5f-a 行为约束和决策协议交叉引用

## v0.1.0

全新 v 前缀发布线，复刻 Flutter Forge 新方案到 H5/Web 技术栈，并补齐规则卡项目隔离。

- 新增 `h5f-fast` 快速入口：轻量优先、冷启动扫描摘要、明确风险才升级
- 新增 `h5f-a` 全自动入口：普通缺口采用推荐方案和 `auto_assumption` 继续推进，高风险才中断确认
- 新增 H5 技术栈扫描：识别 React/Vue/Next/Nuxt/Vite、状态管理、路由、网络层、样式、测试和组件库信号
- 新增 `scripts/project_snapshot.py`、`scripts/init_rule_card.py`、`scripts/doctor.sh`、`scripts/validate_project.sh`
- 新增规则卡校验、路由 golden 测试、文档同步检查和 H5 技术栈扫描测试
- 新增 QUICKSTART、CHEATSHEET、fast/autonomous mode、stack profiles、release playbook、demo transcript 和 mode test cases
- README 顶部入口调整为 `h5f-` / `h5f-fast` / `h5f-a` 三个核心入口
- 规则卡正式来源限定为当前目标项目目录内 `<project>.rule_card.yaml` 精确命中
- 禁止读取 `~/.claude/projects/.../memory/*.yaml`、其它项目目录或其它项目名的规则卡作为兜底
- 无规则卡时生成 `.h5-forge/projects/<project>.rule_card_draft.yaml` 草案
- 新增 `scripts/validate_rule_card_resolution.py` 并纳入 `validate_release.sh`
- 版本元数据统一到 `v0.1.0`

## 0.4.2

架构级任务分类与运维直通重定义

- 新增架构级任务分类：优化/重构/代码审查/迁移/依赖清理/i18n-a11y，角色流程为架构设计师 → 页面工程师
- 运维直通重定义：仅覆盖排除场景（非 H5 任务），npm/eslint/CI 等工程任务改为轻量任务
- 新增角色流程选择表：有 UI → 四角色，无 UI → 跳 UI 设计师，架构级 → 跳需求+UI，轻量 → 页面工程师
- Description 精简为 3 行，与 flutter-forge 格式统一
- 模式表合并：代码审查/迁移/i18n-a11y 合并为架构级任务一个模式
- 新增高风险结构决策定义
- 修复误路由纠正与需求阶段强制重开的触发短语冲突
- question_budget.md 新增 LA 层级、架构设计师全程主导说明和角色流程选择表
- code_review_mode.md、migration_assist.md 输出格式统一为 `[h5-forge] 架构设计师：`
- i18n_a11y_check.md 加 `[h5-forge] 架构设计师：` 输出前缀
- skill_visibility.md 加运维直通和架构级任务标记
- README 同步更新路由图、架构图、模式表、讨论触发条件
- 修复组件抽取标准矛盾（architecture_designer.md 对齐 engineering_heuristics.md）
- README 绝对路径改相对路径

## 0.4.1

触发机制与会话管理修复

- 重写 SKILL.md frontmatter description：加入硬触发关键词（`h5f-`/`h5f -`/`h5f `）、强制调用规则、排除场景、防误判规则
- 新建 `references/session_management.md`：子任务清单格式、精确写入时机、恢复逻辑
- `skill_visibility.md` 会话状态段落改为引用 session_management.md
- `load_map.md` 新增 session_management.md 条目

## 0.4.0

统一四角色提问预算与确认门禁

- 新增 `references/shared_workflow_gates/question_budget.md`，把 `L1-L4` 提问预算从主规则中拆出
- `SKILL.md` 新增四角色提问预算摘要，明确完整流程不等于问题越多越好
- `requirement_confirmation.md`、`role_gate_matrix.md` 补充预算和放行规则
- 需求分析师与 UI 设计师角色卡补充预算说明，强调“问到够用就停”
- 修正 README 中错误的 `3.0.0` 展示，统一 `VERSION`、`.skillhub.json` 和 README 版本号到 `0.4.0`

## 0.3.0

0.3.0 是一次面向”工作流产品化”的大版本升级，重点把新项目共创、规则卡初始化、项目阶段判断和共享门禁整理成更稳定的整体系统，并对主入口文档做了第一轮瘦身。

- 正式把新项目流程拆成两个独立维度：`项目阶段` 决定是否进入共创模式，`架构状态` 决定规则卡是提取还是初始化
- 新增新项目入口三分流：明确共创意图、明确初始化意图、意图不清时默认推荐共创
- 新增“新增业务模块”的判定示例，明确区分现有项目扩展、空项目首个业务模块、新项目已有架构和忽略旧代码重做
- 新项目共创与规则卡初始化正式解耦：共创先回答“做什么”，初始化再回答“怎么组织工程”
- 继续收紧确认粒度和 UI 结构草案闸门，保证从想法到页面结构、从结构到架构的确认链路稳定
- 对 `SKILL.md` 和 `README.md` 做第一轮瘦身，减少重复规则和长示例，把详细分流与示例下沉到 reference 文件
- 共享门禁、项目初始化流程、新项目共创模式与 README 说明同步对齐，降低后续跨项目同步成本

## 0.2.3

0.2.3 是一次面向“确认粒度”和“UI 输出节奏”的细化版本，重点收紧用户确认的生效范围，并把新项目共创里的 UI 输出拆成结构草案和完整结构两步。

- 补强确认绑定规则：用户一句“确认 / 可以 / 按这个来 / 没问题”只对上一轮明确摘要生效，不能自动吞掉摘要外的未决项
- 补强确认回写要求：如果仍有未决项，必须先回写“已确认 / 待确认”，再继续追问关键问题
- 补强 UI 首轮输出闸门：新项目共创模式下，UI 设计师在方向确认后的第一轮只允许输出“结构草案”，不得一次性展开完整页面结构包
- 更新角色交接格式：新增“结构草案确认状态”，明确未通过时禁止下发完整 UI 包
- 同步更新主规则、运行时提示、共享确认门禁和 README 说明

## 0.2.2

0.2.2 是一次面向规则抽象和跨项目同步效率的版本，重点把顾问式协作和老项目顾问提问沉淀成共享工作流规则。

- 新增 `references/shared_workflow_gates/advisor_collaboration.md`，抽取四角色统一的顾问式协作规则
- 新增 `references/shared_workflow_gates/legacy_project_consulting.md`，抽取老项目扫描、复用判断、规则冲突和改动边界不清时的顾问式提问规则
- 更新 `shared_workflow_gates/README.md`，把共享工作流主题扩展到顾问式协作和老项目顾问提问
- 主规则同步强化：老项目模式下也要求先给默认建议和原因，再提出关键确认问题
- 老项目入口与扫描规则同步强化：迭代中项目不再只是扫描后执行，而是按顾问式提问方式推进关键确认

## 0.2.1

0.2.1 是一次面向“共创体验”的细化版本，重点补强了新项目共创后半段的确认闸门，以及四个角色统一的顾问式协作方式。

- 补强新项目共创后半段：需求分析师每轮必须带推荐建议，UI 设计师和架构设计师新增确认闸门，避免后半段一次性倾倒完整方案
- 明确四个角色都应按顾问式协作工作，不只是需求分析师；其中需求分析师最主动，页面工程师也需要提供第一版实现建议和实现层取舍建议
- 补强页面工程师角色卡：从被动执行改为实现层顾问，要求在新项目共创模式下先给“第一版实现建议”，再展开详细实现步骤
- 新增 UI 方向确认状态和架构落地确认状态，要求在进入下一个角色前明确是否允许继续下发

## 0.2.0

0.2.0 是一次面向工作流稳定性的升级版本，重点补强了路由纠偏、需求确认闸门、新项目共创模式，以及跨项目可复用的共享门禁规则。

- 支持误路由纠正：用户指出缺少 UI/架构/需求分析接入时，直接切回正确流程，不再二次询问是否升级
- 补强需求阶段纠偏：用户明确说“这是一个需求”“需要需求分析”“重新做需求分析”时，必须直接回到需求分析师，不得继续页面工程师执行态
- 补强需求分析停机条件：如果歧义会影响核心页面的形态、模板复用、内容源、路由、首屏目标、返回路径、SEO 或主要交互，必须先向用户提问，不能自动把默认值下发到 UI/架构/实现
- 补强需求确认闸门：需求分析完成后，只有在用户确认状态为“允许进入下一角色”时，才允许切到 UI/架构；首页、详情页、列表页、表单页、交易页、内容页等核心页面必须先讨论展示字段、区块组成和内容逻辑
- 泛化续写触发示例：移除项目专属关键词，改为通用页面/模块/详情页/交互表达，避免把 h5-forge 误收窄到单一业务场景
- 重构触发系统为“硬触发 + 语义触发 + 示例表达”三层结构，减少关键词堆积导致的误判和维护成本
- 新增 `new_project_cocreation_mode.md`，支持从模糊想法出发，通过多轮问答逐步收口需求、风格和页面结构，再落地成新项目
- 新增 `references/shared_workflow_gates/` 子目录，沉淀可在 H5 Forge 与 Flutter Forge 之间直接复制的通用门禁规则
- 收紧 10 秒测试：从需求/设计开始的新页面、新模块、新项目任务优先进入完整流程，不能因描述清晰而误判为轻量任务

## 0.1.0

H5 Forge 首个公开版本，基于 Flutter Forge 的工作流形态改造为 H5/Web 项目协作 skill。

- 新增 H5/Web 项目主控 `SKILL.md`
- 支持“硬排除 + 运维直通 + 轻量执行 + 完整流程”的任务路由
- 支持已有 H5/Web 项目接入和新 H5/Web 应用 `mvp / business / team` profile
- 支持规则卡、会话状态、相似实现检索、输入不完整处理和完整流程升级原因
- 支持误路由纠正：用户指出缺少 UI/架构接入时，直接切回正确流程，不再二次询问是否升级
- 补强需求阶段纠偏：用户明确说“这是一个需求”“需要需求分析”“重新做需求分析”时，必须直接回到需求分析师，不得继续页面工程师执行态
- 补强需求分析停机条件：如果歧义会影响核心页面的形态、模板复用、内容源、路由、首屏目标、返回路径、SEO 或主要交互，必须先向用户提问，不能自动把默认值下发到 UI/架构/实现
- 补强需求确认闸门：需求分析完成后，只有在用户确认状态为“允许进入下一角色”时，才允许切到 UI/架构；首页、详情页、列表页、表单页、交易页、内容页等核心页面必须先讨论展示字段、区块组成和内容逻辑
- 泛化续写触发示例：移除博客项目专属关键词，改为通用页面/模块/详情页/交互表达，避免把 h5-forge 误收窄到单一业务场景
- 新增 `references/shared_workflow_gates/` 子目录，沉淀可在 H5 Forge 与 Flutter Forge 之间直接复制的通用门禁规则
- 新增 `new_project_cocreation_mode.md`，支持从模糊想法出发，通过多轮问答逐步收口需求、风格和页面结构，再落地成新项目
- 重构触发系统为“硬触发 + 语义触发 + 示例表达”三层结构，减少关键词堆积导致的误判和维护成本
- 补强新项目共创后半段：需求分析师每轮必须带推荐建议，UI 设计师和架构设计师新增确认闸门，避免后半段一次性倾倒完整方案
- 补强老项目顾问式提问：迭代中项目扫描、复用判断、规则冲突、改动边界不清时，也必须先给默认建议和原因，再提出关键确认问题
- 收紧 10 秒测试：从需求/设计开始的新页面、新模块、新项目任务优先进入完整流程，不能因描述清晰而误判为轻量任务
- 新增前端项目质量、路由、网络层、测试、i18n/a11y、代码审查和迁移参考文档
- 新增 MIT License、贡献指南、GitHub issue 模板和开源发布检查清单
- 新增 `scripts/discover_h5_skills.sh`，用于探测本地可协作的前端 skills
