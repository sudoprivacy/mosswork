#!/usr/bin/env python3
"""
Unified Skill authorization helper.

The Skill instructions should call this file before running any protected
capability. The helper owns all local credential storage, WorkBuddy JWT binding,
and optional remote authorization checks.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Any


AUTH_OK = "AUTH_OK"
AUTH_REQUIRED = "AUTH_REQUIRED"
AUTH_INVALID = "AUTH_INVALID"
AUTH_BIND_OK = "AUTH_BIND_OK"
AUTH_ACTION_REQUIRED = "AUTH_ACTION_REQUIRED"

# Backward-compatible signal names used by older Skill instructions.
SIGNAL_MISSING = "CREDENTIALS_MISSING"
SIGNAL_INVALID = "CREDENTIALS_INVALID"


SKILL_ROOT = Path(__file__).resolve().parents[1]


def load_skill_meta() -> dict[str, Any]:
    """Load package metadata when available."""
    for name in ("_meta.json", "_skillhub_meta.json"):
        path = SKILL_ROOT / name
        if not path.exists():
            continue
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def detect_default_skill_code() -> str:
    """Return platform skillCode from _meta.json.slug, then fall back to folder name."""
    meta = load_skill_meta()
    slug = str(meta.get("slug", "")).strip()
    if slug:
        return slug
    return SKILL_ROOT.name


def safe_cache_name(skill_code: str) -> str:
    """Make a stable cache file name for a Skill code."""
    value = skill_code.strip() or "unknown-skill"
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value)
    return value.strip("._-") or "unknown-skill"


SKILL_CODE = os.environ.get("SKILL_CODE", detect_default_skill_code())
# 默认地址由后端当前环境的 SKILL_AUTH_API_BASE 注入，运行时仍可通过同名环境变量覆盖。
API_BASE_URL = os.environ.get(
    "SKILL_AUTH_API_BASE",
    "https://s.1100111.cn",
).rstrip("/")
BIND_URL = os.environ.get("SKILL_AUTH_BIND_URL",
                          f"{API_BASE_URL}/baitong_ai/api/skill/bind")
VERIFY_URL = os.environ.get("SKILL_AUTH_VERIFY_URL",
                            f"{API_BASE_URL}/baitong_ai/api/skill/verify")
CACHE_FILE = None

# Legacy path used by the first xxxx-search prototype. Kept as read fallback.
LEGACY_CACHE_FILE = Path.home() / ".workbuddy" / ".xxxx_search_credentials.json"


def cache_file_for(skill_code: str | None = None, agent: str = "workbuddy") -> Path:
    """Return the credential cache path for the requested Skill.

    Agent routing:
    - "workbuddy" → ~/.workbuddy/skill_auth/{skill}.json
    - "qwenwork"  → ~/.qwen/skill_auth/{skill}.json
    - anything else falls back as-is (backward-compat for unknown agents).
    """
    if CACHE_FILE is not None:
        return Path(CACHE_FILE)
    target_skill_code = skill_code or SKILL_CODE
    if agent == "qwenwork":
        root = Path.home() / ".qwenworkcn"
    else:
        root = Path.home() / ".workbuddy"
    return root / "skill_auth" / f"{safe_cache_name(target_skill_code)}.json"


def _now_ms() -> str:
    return str(int(time.time() * 1000))


def make_sign_headers(app_key: str, app_secret: str) -> dict[str, str]:
    """Build the platform signature headers."""
    timestamp = _now_ms()
    raw = app_key + timestamp + app_secret
    sign = hashlib.md5(raw.encode("utf-8")).hexdigest()
    return {
        "X-App-Key": app_key,
        "X-Timestamp": timestamp,
        "X-Sign": sign,
        "Content-Type": "application/json; charset=utf-8",
    }


def save_credentials(
    app_key: str,
    app_secret: str,
    *,
    workbuddy_sub: str = "",
    skill_code: str | None = None,
    mcp_token: str = "",
    mcp_url: str = "",
    agent: str = "workbuddy",
) -> None:
    """Save credentials for this Skill with user binding metadata.

    The cache file is routed by agent: workbuddy → ~/.workbuddy/, qwenwork → ~/.qwen/.
    """
    target_skill_code = skill_code or SKILL_CODE
    cache_file = cache_file_for(target_skill_code, agent=agent)
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "skill_code": target_skill_code,
        "app_key": app_key.strip(),
        "app_secret": app_secret.strip(),
        "mcp_token": (mcp_token or "").strip(),
        "mcp_url": (mcp_url or "").strip(),
        "workbuddy_sub": workbuddy_sub.strip(),
        "saved_at": int(time.time()),
    }
    cache_file.write_text(json.dumps(
        data, ensure_ascii=False, indent=2), encoding="utf-8")
    cache_file.chmod(stat.S_IRUSR | stat.S_IWUSR)
    print(f"[auth] credentials saved: {cache_file}")


def _read_cache_file(path: Path) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        raise ValueError("cache file is empty")
    data = json.loads(raw)
    if not str(data.get("app_key", "")).strip():
        raise ValueError("app_key is empty")
    if not str(data.get("app_secret", "")).strip():
        raise ValueError("app_secret is empty")
    return data


def load_credential_record(*, skill_code: str | None = None, agent: str = "") -> dict[str, Any]:
    """Load the full credential cache record."""
    target_skill_code = skill_code or SKILL_CODE
    # 默认从环境变量取 agent；未设置时回退 workbuddy（向后兼容）
    effective_agent = agent or os.environ.get("BT_SKILL_AGENT", "workbuddy").lower()
    cache_path = cache_file_for(target_skill_code, agent=effective_agent)
    if not cache_path.exists() and SKILL_CODE == "xxxx-search" and LEGACY_CACHE_FILE.exists():
        cache_path = LEGACY_CACHE_FILE

    if not cache_path.exists():
        print(AUTH_REQUIRED)
        print(SIGNAL_MISSING)
        print_bind_instruction(target_skill_code)
        sys.exit(1)

    try:
        return _read_cache_file(cache_path)
    except (json.JSONDecodeError, ValueError, KeyError) as exc:
        print(AUTH_INVALID)
        print(SIGNAL_INVALID)
        print(f"[auth] credential cache is invalid: {exc}", file=sys.stderr)
        print_bind_instruction(target_skill_code)
        sys.exit(1)


def load_credentials() -> tuple[str, str]:
    """Return (app_key, app_secret). Imported by business scripts."""
    data = load_credential_record()
    return str(data["app_key"]).strip(), str(data["app_secret"]).strip()


def parse_jwt_payload(token: str) -> dict[str, Any]:
    """Parse a WorkBuddy JWT payload without verifying the signature."""
    parts = token.strip().split(".")
    if len(parts) != 3:
        raise ValueError(
            f"invalid JWT format, expected 3 parts, got {len(parts)}")

    payload_b64 = parts[1]
    padding = 4 - len(payload_b64) % 4
    if padding != 4:
        payload_b64 += "=" * padding

    try:
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        return json.loads(payload_bytes.decode("utf-8"))
    except Exception as exc:
        raise ValueError(f"failed to decode JWT payload: {exc}") from exc


# JWT 形如 eyJ...>.eyJ...>.eyJ...>，用于从日志/项目 jsonl 原样提取超长 token，避免手抄损坏签名。
_JWT_PATTERN = re.compile(r"eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+")


def recover_jwt_from_text(text: str) -> str:
    """从文本里提取"最近一次、且能完整解码"的 WorkBuddy 业务 JWT（配合 parse_jwt_payload 过滤）。

    <p>超长 JWT 一旦手抄/拼进命令行极易破坏签名，造成"假 401"，浪费排查时间。
    本函数让 token 全程走文本/文件解析，并收紧匹配：
      - 只接受 payload 携带 sub 的完整业务 JWT，排除残缺/示例 token；
      - 多条候选时优先取"靠近文本末尾（最近一次 connect_cloud_service 返回）"的那条，
        避免盲目取最长误中其它会话/示例 token。</p>

    返回匹配到的 token；未找到抛 ValueError。
    """
    last_valid = ""
    # findall 按出现顺序返回；从前往后扫描，最后写入的 last_valid 即为"最近一条"
    for candidate in _JWT_PATTERN.findall(text or ""):
        candidate = candidate.strip()
        try:
            payload = parse_jwt_payload(candidate)
        except ValueError:
            continue
        # 只接受携带 sub 的完整业务 JWT，排除 header-only/残缺/示例 token
        if not str(payload.get("sub", "")).strip():
            continue
        last_valid = candidate
    if not last_valid:
        raise ValueError(
            "JWT_TOKEN_NOT_FOUND|未从文本中提取到可解码的业务 JWT")
    return last_valid


def recover_jwt_from_log_file(log_path: str) -> str:
    """从会话日志/项目 jsonl 等文件里原样提取最长有效 JWT。文件不存在/无有效 token 抛 ValueError/OSError。"""
    raw = Path(log_path).read_text(encoding="utf-8", errors="replace")
    return recover_jwt_from_text(raw)


def _post_json(url: str, body: dict[str, Any], headers: dict[str, str], timeout: int) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        error_body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {error_body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"network error: {exc.reason}") from exc

    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"non-JSON response: {raw}") from exc


def _result_ok(result: dict[str, Any]) -> bool:
    code = result.get("code")
    if code in (200, 0, None):
        return True
    return str(code).lower() in ("200", "0", "success")


def _extract_credentials(data: dict[str, Any], result: dict[str, Any]) -> tuple[str, str, str, str]:
    """从绑定响应 data 中提取 (app_key, app_secret, mcp_token, mcp_url)。

    mcp_token（bt_mcp_xxx）与 mcp_url 由服务端绑定流程下发，供客户端配置 MCP 连接器；
    老后端/非 MCP 场景不返回时为空串，不阻塞绑定。
    """
    app_key = str(data.get("app_key") or data.get("appKey") or "").strip()
    app_secret = str(data.get("app_secret")
                     or data.get("appSecret") or "").strip()
    mcp_token = str(data.get("mcp_token")
                    or data.get("mcpToken") or "").strip()
    mcp_url = str(data.get("mcp_url")
                  or data.get("mcpUrl") or "").strip()
    if not app_key or not app_secret:
        raise RuntimeError(
            f"bind response missing app_key/app_secret: {json.dumps(result, ensure_ascii=False)}")
    return app_key, app_secret, mcp_token, mcp_url


def call_bind_api(
    *,
    workbuddy_sub: str,
    phone: str,
    nickname: str = "",
    skill_code: str | None = None,
    base_api: str = "",  # 与 auth_runtime 签名对齐；本兜底实现用自身全局 URL，忽略该值
) -> tuple[str, str, str, str]:
    """Bind WorkBuddy user identity and return platform credentials."""
    body: dict[str, Any] = {
        "skillCode": skill_code or SKILL_CODE,
        "workbuddySub": workbuddy_sub,
        "phone": phone,
    }
    if nickname:
        body["nickname"] = nickname

    result = _post_json(
        BIND_URL,
        body,
        {"Content-Type": "application/json; charset=utf-8"},
        timeout=15,
    )

    if not _result_ok(result):
        raise RuntimeError(
            f"bind failed: code={result.get('code')}, msg={result.get('msg')}")

    data = result.get("data", result)
    return _extract_credentials(data, result)


def call_verify_api(record: dict[str, Any], *, skill_code: str | None = None,
                    base_api: str = "") -> None:  # 与 auth_runtime 签名对齐，兜底实现忽略
    """Verify cached credentials with the platform."""
    app_key = str(record["app_key"]).strip()
    app_secret = str(record["app_secret"]).strip()
    body = {
        "skillCode": skill_code or record.get("skill_code") or SKILL_CODE,
        "workbuddySub": record.get("workbuddy_sub", ""),
    }
    result = _post_json(
        VERIFY_URL,
        body,
        make_sign_headers(app_key, app_secret),
        timeout=15,
    )
    if not _result_ok(result):
        raise RuntimeError(
            f"authorization failed: code={result.get('code')}, msg={result.get('msg')}")


# ==================== 鉴权壳 V2：手机号直取 + 共享鉴权运行时版本（方案A） ====================

# IdP /account 地址，可用环境变量覆盖，方便开发/UAT/生产隔离。
IDP_ACCOUNT_URL = os.environ.get(
    "WORKBUDDY_IDP_ACCOUNT_URL",
    "https://www.codebuddy.cn/auth/realms/copilot/account",
).rstrip("/")
# V2 绑定接口与运行时清单接口。
RESOLVE_BIND_URL = os.environ.get(
    "WORKBUDDY_AUTH_RESOLVE_BIND_URL",
    f"{API_BASE_URL}/baitong_ai/api/skill/bind/resolveWorkbuddyAccount",
)
RUNTIME_MANIFEST_URL = os.environ.get(
    "WORKBUDDY_AUTH_RUNTIME_MANIFEST_URL",
    f"{API_BASE_URL}/baitong_ai/api/skill/authRuntime/getAuthRuntimeManifest",
)

# 中国大陆手机号：11 位，1 开头，第二位 3-9。
CHINA_MOBILE = re.compile(r"^1[3-9]\d{9}$")


def is_cn_mobile(raw: str) -> bool:
    """判断是否为 11 位中国大陆手机号（不经国家码预处理）。"""
    return bool(CHINA_MOBILE.fullmatch(str(raw or "").strip()))


def normalize_cn_phone(raw: str) -> str:
    """标准化为 11 位中国大陆手机号。
    <p>只移除开头的 +86/86 与分隔空白，不能全局删除字符串中的 86，避免误删中间真实 86。</p>
    """
    value = re.sub(r"[\s\-()]", "", str(raw or "").strip())
    if value.startswith("+86"):
        value = value[3:]
    elif len(value) == 13 and value.startswith("86"):
        value = value[2:]
    if not CHINA_MOBILE.fullmatch(value):
        raise ValueError("IdP 返回的手机号格式不正确")
    return value


def _get_json(url: str, headers: dict[str, str], timeout: Any) -> dict[str, Any]:
    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"network error: {exc.reason}") from exc
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"non-JSON response: {raw}") from exc


def call_idp_account(token: str) -> dict[str, Any]:
    """方案A：auth.py 直接用 connect_cloud_service().token 调 IdP /account 提取企业成员属性。
    <p>安全要求：token 不打印、不写凭证缓存、不入 URL/异常；日志不记录完整响应。</p>
    """
    # urllib 只支持单个 socket 超时；读超时用于兜底 IdP 慢响应。
    read_timeout = int(os.environ.get("WORKBUDDY_IDP_READ_TIMEOUT", "10"))
    result = _get_json(
        IDP_ACCOUNT_URL,
        {"Authorization": f"Bearer {token}", "Accept": "application/json"},
        timeout=read_timeout,
    )
    if not isinstance(result, dict):
        raise RuntimeError("IDP_RESPONSE_INVALID|非 JSON 响应")
    return result


def resolve_enterprise_phone(account: dict[str, Any]) -> str:
    """从 IdP /account.attributes 提取当前企业手机号并标准化。
    <p>优先当前登录企业(plugin-last-login-ent)，回退 enterprise_id；
    精确读取 ent-phone-number:<enterpriseId>；多值歧义抛 IDP_PHONE_AMBIGUOUS。</p>
    """
    attributes = account.get("attributes") or {}
    if not isinstance(attributes, dict):
        raise RuntimeError("IDP_PHONE_NOT_FOUND|attributes 缺失")

    enterprise_id: str = ""
    last_login = attributes.get("plugin-last-login-ent")
    if isinstance(last_login, list) and last_login and str(last_login[0]).strip():
        enterprise_id = str(last_login[0]).strip()
    if not enterprise_id:
        ent = attributes.get("enterprise_id")
        if isinstance(ent, list) and ent and str(ent[0]).strip():
            enterprise_id = str(ent[0]).strip()

    def _valid(p: Any) -> str:
        s = str(p).strip()
        if s:
            try:
                return normalize_cn_phone(s)
            except ValueError:
                pass
        return ""

    if enterprise_id:
        phones = attributes.get(f"ent-phone-number:{enterprise_id}")
        if isinstance(phones, list):
            for p in phones:
                v = _valid(p)
                if v:
                    return v
            raise RuntimeError("IDP_PHONE_NOT_FOUND|当前企业手机号为空或无有效号码")
    # 兜底：所有 ent-phone-number:* 只有一个唯一有效值才使用
    candidates: set[str] = set()
    for k, v in attributes.items():
        if str(k).startswith("ent-phone-number:") and isinstance(v, list):
            for p in v:
                vv = _valid(p)
                if vv:
                    candidates.add(vv)
    if len(candidates) == 1:
        return candidates.pop()
    if len(candidates) > 1:
        raise RuntimeError("IDP_PHONE_AMBIGUOUS|存在多个不同企业手机号且无法确认当前企业")
    raise RuntimeError("IDP_PHONE_NOT_FOUND|未找到企业手机号")


def load_auth_version_info() -> dict[str, Any]:
    """读取包内 _auth_version.json（技能现状版本信息），缺失视为 V1 老包。"""
    path = SKILL_ROOT / "_auth_version.json"
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def call_resolve_bind_api(body: dict[str, Any], base_api: str = "") -> tuple[str, str, str, str]:
    """调用百通 V2 解析绑定接口，返回 (app_key, app_secret, mcp_token, mcp_url)。
    base_api 与 auth_runtime 签名对齐，兜底实现用自身全局 RESOLVE_BIND_URL，忽略该值。"""
    result = _post_json(
        RESOLVE_BIND_URL,
        body,
        {"Content-Type": "application/json; charset=utf-8"},
        timeout=20,
    )
    if not _result_ok(result):
        raise RuntimeError(
            f"bind failed: code={result.get('code')}, msg={result.get('msg')}")
    data = result.get("data", result)
    return _extract_credentials(data, result)


# 共享鉴权运行时目录：所有装了 V2 Bootstrap 的 Skill 共用（§11.3）。
AUTH_RUNTIME_DIR = Path.home() / ".workbuddy" / "auth-runtime"
AUTH_RUNTIME_CURRENT = AUTH_RUNTIME_DIR / "current.json"
AUTH_RUNTIME_STAGING = AUTH_RUNTIME_DIR / "staging"
AUTH_RUNTIME_LOCK = AUTH_RUNTIME_DIR / "update.lock"

# ==================== 内置验签公钥表（Ed25519） ====================
# publicKeyId -> base64(Ed25519 32字节 raw 公钥)。与后端 bt.auth-runtime.signer.keys 的 keyId 对应。
# - auth-runtime-dev：本地联调用，对应 application-dev.yml 中 auth-runtime-dev 私钥的公钥。
# - auth-runtime-2026-01：生产签名公钥，对应后端 bt.auth-runtime.signer.keys 中同 keyId 的私钥
#   （私钥由生产环境变量 AUTH_RUNTIME_SIGN_PRIVATE_KEY 注入，不在仓库）。客户端只内置公钥。
AUTH_RUNTIME_PUBLIC_KEYS: dict[str, str] = {
    "auth-runtime-dev": "L6BzArF1jnuPevSzbTfo1Lmh+bQq6FiIAd0vfoaxrTI=",
    "auth-runtime-2026-01": "c9S6L4Lx7bleU17Y8fcFqBpucq6rb0V3mOZ4l7OP8eM=",
}

# ==================== 纯 Python Ed25519 验签（RFC 8032，零第三方依赖） ====================
# 后端发布签名对象 = 运行时包 SHA-256 的 32 字节原始摘要。本实现仅验签、不做签名，
# 随技能包分发，保持 auth.py 纯标准库风格、离线可用。

_ED25519_Q = 2 ** 255 - 19
_ED25519_L = 2 ** 252 + 27742317777372353535851937790883648493
_ED25519_D = -121665 * pow(121666, _ED25519_Q - 2, _ED25519_Q) % _ED25519_Q
_ED25519_I = pow(2, (_ED25519_Q - 1) // 4, _ED25519_Q)


def _ed25519_inv(x: int) -> int:
    """模 p 求逆。"""
    return pow(x, _ED25519_Q - 2, _ED25519_Q)


def _ed25519_xrecover(y: int) -> int:
    """由 y 坐标解出 x 坐标（RFC 8032 §5.1.3）。非法则抛 ValueError。"""
    xx = (y * y - 1) * _ed25519_inv(_ED25519_D * y * y + 1) % _ED25519_Q
    x = pow(xx, (_ED25519_Q + 3) // 8, _ED25519_Q)
    if (x * x - xx) % _ED25519_Q != 0:
        x = x * _ED25519_I % _ED25519_Q
    if (x * x - xx) % _ED25519_Q != 0:
        raise ValueError(f"xrecover failed for y={y}")
    if x & 1:
        x = _ED25519_Q - x
    return x


_ED25519_BY = 4 * _ed25519_inv(5) % _ED25519_Q
_ED25519_BX = _ed25519_xrecover(_ED25519_BY)
_ED25519_B = (_ED25519_BX, _ED25519_BY)


def _ed25519_add(P: tuple[int, int], Q: tuple[int, int]) -> tuple[int, int]:
    """Twisted Edwards 完备加法（RFC 8032 附录，a=-1，无除零分支）。"""
    x1, y1 = P
    x2, y2 = Q
    x3 = (x1 * y2 + x2 * y1) * _ed25519_inv(1 + _ED25519_D * x1 * x2 * y1 * y2) % _ED25519_Q
    y3 = (y1 * y2 + x1 * x2) * _ed25519_inv(1 - _ED25519_D * x1 * x2 * y1 * y2) % _ED25519_Q
    return (x3, y3)


def _ed25519_scalarmult(P: tuple[int, int], e: int) -> tuple[int, int]:
    """标量乘法（double-and-add）。e==0 返回单位元 (0,1)。"""
    if e == 0:
        return (0, 1)
    Q = _ed25519_scalarmult(P, e // 2)
    Q = _ed25519_add(Q, Q)
    if e & 1:
        Q = _ed25519_add(Q, P)
    return Q


def _ed25519_decode_point(s: bytes) -> tuple[int, int]:
    """解码压缩点（后 255 位为 y，最高位为 x 符号）。非法则抛 ValueError。"""
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _ed25519_xrecover(y)
    if (x & 1) != sign:
        x = _ED25519_Q - x
    return (x, y)


def _ed25519_point_neg(P: tuple[int, int]) -> tuple[int, int]:
    """点取负：-(x,y) = (-x,y)。"""
    return (-P[0] % _ED25519_Q, P[1])


def _ed25519_verify(public: bytes, signature: bytes, message: bytes) -> bool:
    """纯 Python Ed25519 验签（RFC 8032 §5.1.7）。

    Args:
        public: 32 字节压缩公钥。
        signature: 64 字节签名（R||S）。
        message: 被签名数据（此处为包 SHA-256 的 32 字节原始摘要）。

    Returns:
        签名有效返回 True，否则 False。任何异常/非法编码均视为无效。
    """
    if len(public) != 32 or len(signature) != 64:
        return False
    try:
        A = _ed25519_decode_point(public)
        R = _ed25519_decode_point(signature[:32])
    except ValueError:
        return False
    s = int.from_bytes(signature[32:], "little")
    s &= (1 << 253) - 1
    if s >= _ED25519_L:
        return False
    h = int.from_bytes(hashlib.sha512(signature[:32] + public + message).digest(), "little") % _ED25519_L
    minus_hA = _ed25519_point_neg(_ed25519_scalarmult(A, h))
    sB = _ed25519_scalarmult(_ED25519_B, s)
    return _ed25519_add(sB, minus_hA) == R


def _verify_runtime_signature(zip_bytes: bytes, manifest: dict[str, Any]) -> None:
    """校验运行时包的 Ed25519 发布签名（Fail-Closed）。

    后端签名对象 = 包内容的 SHA-256 原始摘要。manifest 缺失签名/公钥、公钥未知、
    或验签失败均抛 RuntimeError，从而中止本次运行时更新（强制更新会 Fail-Closed 退出）。

    Args:
        zip_bytes: 下载后的运行时 zip 原始字节。
        manifest: 运行时清单（含 signature / publicKeyId）。
    """
    signature_b64 = (manifest.get("signature") or "").strip()
    key_id = (manifest.get("publicKeyId") or "").strip()
    if not signature_b64 or not key_id:
        raise RuntimeError("manifest 缺少签名或公钥ID，拒绝更新")
    public_b64 = AUTH_RUNTIME_PUBLIC_KEYS.get(key_id)
    if not public_b64:
        raise RuntimeError(f"未知的公钥ID: {key_id}，拒绝更新")
    try:
        public_key = base64.b64decode(public_b64)
        signature = base64.b64decode(signature_b64)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"签名/公钥 base64 解析失败: {exc}") from exc
    digest = hashlib.sha256(zip_bytes).digest()
    if not _ed25519_verify(public_key, signature, digest):
        raise RuntimeError("Ed25519 发布签名校验失败，拒绝更新")


def installed_runtime_version() -> str:
    """本机已安装的共享运行时版本（读 current.json）；未安装返回空串。"""
    try:
        cur = json.loads(AUTH_RUNTIME_CURRENT.read_text(encoding="utf-8"))
        return str(cur.get("latestRuntimeVersion", "") or "").strip()
    except (OSError, json.JSONDecodeError):
        return ""


def _download(url: str, dest: Path) -> None:
    """下载运行时包到本地文件，仅允许 http/https。"""
    scheme = url.split(":", 1)[0].lower()
    if scheme not in ("http", "https"):
        raise RuntimeError(f"不支持的下载协议: {scheme}")
    try:
        urllib.request.urlretrieve(url, dest)
    except Exception as exc:
        raise RuntimeError(f"下载运行时包失败: {exc}") from exc


# 用户级更新锁残留判定阈值：锁文件存在超过该秒数即视为上次中断(进程被杀/未走到 finally)留下的残留，允许回收。
RUNTIME_LOCK_MAX_AGE = 600


def _lock_is_stale() -> bool:
    """锁文件是否残留：内部 PID 已不存在，或文件年龄超过阈值。两者都不满足则视为被活进程正常持有。"""
    try:
        if time.time() - AUTH_RUNTIME_LOCK.stat().st_mtime > RUNTIME_LOCK_MAX_AGE:
            return True
        pid_text = AUTH_RUNTIME_LOCK.read_text(encoding="utf-8").strip()
        pid = int(pid_text) if pid_text else 0
        if pid > 0:
            try:
                os.kill(pid, 0)
            except PermissionError:
                # 进程存在但无权信号 → 视为存活
                return False
            except OSError:
                # 进程不存在/不可探测（含 Windows 下残留 pid）→ 视为残留，倾向回收
                return True
    except (OSError, ValueError):
        pass
    return False


def _acquire_runtime_lock() -> bool:
    """获取用户级更新锁（O_EXCL）。
    返回 False 表示被其他活进程持有（或回收后仍未抢到）；若是残留锁（进程已死/超时）则自动回收后重试。"""
    AUTH_RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(AUTH_RUNTIME_LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode("utf-8"))
        os.close(fd)
        return True
    except FileExistsError:
        # 已被占用：仅当判定为残留时才回收重试，活进程持有则等下次
        if _lock_is_stale():
            try:
                AUTH_RUNTIME_LOCK.unlink()
            except OSError:
                return False
            try:
                fd = os.open(AUTH_RUNTIME_LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, str(os.getpid()).encode("utf-8"))
                os.close(fd)
                return True
            except FileExistsError:
                return False
        return False


def _release_runtime_lock() -> None:
    try:
        AUTH_RUNTIME_LOCK.unlink()
    except OSError:
        pass


def _atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _prune_versions(keep_latest: str) -> None:
    """保留最近两个已验证版本目录，其余清理，供回滚。"""
    versions_dir = AUTH_RUNTIME_DIR / "versions"
    if not versions_dir.is_dir():
        return
    try:
        dirs = sorted(
            (d for d in versions_dir.iterdir() if d.is_dir() and d.name != keep_latest),
            key=lambda d: d.stat().st_mtime_ns,
            reverse=True,
        )
        for stale in dirs[1:]:
            shutil.rmtree(stale, ignore_errors=True)
    except OSError:
        pass


def _detect_skill_title() -> str:
    """从本地已安装(旧版) SKILL.md 提取真实技能标题名（首个 # 标题行后的内容）。

    旧 SKILL.md 由技能包渲染产出真实技能名（如中文），比 _meta.json.name 更可靠
    （后者可能未渲染或为英文 slug）。找不到标题返回空串。
    """
    try:
        for line in (SKILL_ROOT / "SKILL.md").read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if not s.startswith("#"):
                continue
            if s.startswith("## ") or s.startswith("###"):
                continue
            if s.startswith("# "):
                return s[2:].strip()
            return s[1:].strip()
        return ""
    except OSError:
        return ""


def _render_skill_md(skill_new: Path) -> str:
    """远端指令模板渲染已在本分发版本中停用。"""
    raise RuntimeError("remote instruction template rendering disabled")


def _apply_runtime_update(manifest: dict[str, Any], latest: str) -> bool:
    """运行时包更新已在本分发版本中停用，始终返回未更新。

    本分发版本不下载、不解压、不执行任何外部代码，也不改写本地指令文件。
    """
    print("[auth] runtime update disabled in this distribution", file=sys.stderr)
    return False


def check_runtime_update() -> None:
    """共享运行时自更新已在本分发版本中停用。

    原实现会在启动时向远端获取版本清单并应用更新，本分发版本不再联网拉取，
    授权校验流程不受影响。
    """
    return


def load_shared_runtime() -> dict[str, Any]:
    """共享运行时动态加载已在本分发版本中停用，固定回落为包内内联鉴权实现。

    本分发版本不进行任何外部模块的动态装载，直接返回空字典，
    由调用方回落为包内自带的内联默认鉴权逻辑（行为等价，无外部代码执行）。
    """
    return {}


def _load_runtime_module(installed: Path):
    """从指定运行时目录加载 auth_runtime.py 模块；失败返回 None。

    <p>供 load_shared_runtime（读 current.json 指向的已装版本）与 _apply_runtime_update
    （本次刚解压落位的 target_dir）共用。load_shared_runtime 复用本方法可保持单一加载实现。</p>
    """
    try:
        module_path = installed / "auth_runtime.py"
        if not module_path.is_file():
            return None
        import importlib.util
        spec = importlib.util.spec_from_file_location("shared_auth_runtime", module_path)
        if spec is None or spec.loader is None:
            return None
        module = importlib.util.module_from_spec(spec)
        sys.path.insert(0, str(installed))
        spec.loader.exec_module(module)
        return module
    except Exception:
        return None


# 已对外宣布过的运行时版本（避免同一进程内对同一版本反复打印）
_ANNOUNCED_RUNTIME_VER: set[str] = set()


def _rt(name: str) -> Any:
    """从共享鉴权运行时取方法；缺失则回落 auth.py 内置同名实现（兜底）。
    每次经 load_shared_runtime 重新 exec 最新运行时，取到即优先使用，从而实现鉴权逻辑热更。"""
    loaded = load_shared_runtime()
    module = loaded.get("module")
    if module is not None:
        fn = getattr(module, name, None)
        if callable(fn):
            ver = str(loaded.get("version", "") or "").strip()
            if ver and ver not in _ANNOUNCED_RUNTIME_VER:
                _ANNOUNCED_RUNTIME_VER.add(ver)
                print(f"[auth] using shared auth runtime v{ver} ({name})")
            return fn
    return globals().get(name)


def bind_v2_from_token(token: str, *, skill_code: str | None = None) -> None:
    """V2 绑定（方案A）。
    <p>preferred_username 为手机号 → 直接走个人路径；否则调 IdP 解析企业手机号。
    服务端不接收 access_token，只接收解析出的手机号与身份字段。</p>
    """
    # 鉴权逻辑优先从共享运行时取最新实现；运行时缺失回落内置兜底（离线可用）
    parse_jwt_payload = _rt("parse_jwt_payload")
    is_cn_mobile = _rt("is_cn_mobile")
    normalize_cn_phone = _rt("normalize_cn_phone")
    call_idp_account = _rt("call_idp_account")
    resolve_enterprise_phone = _rt("resolve_enterprise_phone")
    extract_enterprise_id = _rt("extract_enterprise_id")
    extract_enterprise_name = _rt("extract_enterprise_name")
    call_resolve_bind_api = _rt("call_resolve_bind_api")
    payload = parse_jwt_payload(token)
    workbuddy_sub = str(payload.get("sub", "")).strip()
    preferred = str(payload.get("preferred_username", "")).strip()
    nickname = str(payload.get("nickname", "")).strip()
    oneid = str(payload.get("oneid", "")).strip()
    if not workbuddy_sub:
        raise SystemExit("[auth] JWT payload missing required field: sub")

    version = load_auth_version_info()
    bootstrap_version = str(version.get("bootstrapVersion", "")).strip()
    runtime_version = str(version.get("authRuntimeVersion", "")).strip()
    protocol_version = str(version.get("protocolVersion", "")).strip()

    body: dict[str, Any] = {
        "skillCode": skill_code or SKILL_CODE,
        "workbuddySub": workbuddy_sub,
        "preferredUsername": preferred,
        "nickname": nickname,
        "agent": "workbuddy",
        "bootstrapVersion": bootstrap_version,
        "runtimeVersion": runtime_version,
        "protocolVersion": protocol_version,
    }

    if is_cn_mobile(preferred):
        # 个人用户：preferred_username 即手机号（个人账号无企业归属，不带企业字段）
        body["resolvedPhone"] = normalize_cn_phone(preferred)
        body["workbuddyOneid"] = oneid
        body["workbuddyAccount"] = nickname
    else:
        # 企业用户：auth.py 本地直调 IdP 解析企业手机号（方案A）
        account = call_idp_account(token)
        body["resolvedPhone"] = resolve_enterprise_phone(account)
        body["workbuddyOneid"] = oneid or str(account.get("username", "") or "")
        body["workbuddyAccount"] = nickname or str(account.get("lastName", "") or "")
        body["workbuddyEnterpriseId"] = extract_enterprise_id(account) or ""
        # 企业名快照：IdP 无独立字段，从 department* 组织全路径首段提取；取不到留空不阻断绑定
        body["workbuddyEnterpriseName"] = extract_enterprise_name(account) or ""

    creds = call_resolve_bind_api(body, base_api=API_BASE_URL)
    # 兼容解包：新绑定返回四元组(app_key, app_secret, mcp_token, mcp_url)，旧运行时返回二元组/三元组时按位兜底
    if len(creds) >= 3:
        app_key, app_secret, mcp_token = creds[0], creds[1], creds[2]
        mcp_url = creds[3] if len(creds) >= 4 else ""
    else:
        app_key, app_secret = creds
        mcp_token, mcp_url = "", ""
    save_credentials(
        app_key,
        app_secret,
        workbuddy_sub=workbuddy_sub,
        skill_code=skill_code or SKILL_CODE,
        mcp_token=mcp_token,
        mcp_url=mcp_url,
        agent="workbuddy",
    )
    print(AUTH_BIND_OK)
    print("[auth] bind succeeded")


def bind_qwenwork_local(*, skill_code: str | None = None) -> None:
    """QwenWork（千问办公）本地取号绑定。

    <p>QwenWorkCN 桌面端不提供 WorkBuddy connect_cloud_service 类似的取号工具，
    改为：解密本地登录态 auth-v2.dat 得到会话 JWT → 调网关 /userinfo 取完整手机号与身份字段 →
    复用后端 resolveWorkbuddyAccount 绑定协议（workbuddySub 由 qwenwork userId 承载）。个人用户路径。</p>
    """
    # 鉴权逻辑优先从共享运行时取最新实现；运行时缺失回落本文件内置兜底
    qwenwork_load_session = _rt("qwenwork_load_session")
    qwenwork_fetch_userinfo = _rt("qwenwork_fetch_userinfo")
    qwenwork_resolve_phone = _rt("qwenwork_resolve_phone")
    qwenwork_extract_identity = _rt("qwenwork_extract_identity")

    session = qwenwork_load_session()
    token = str(session.get("token") or "").strip()
    if not token:
        raise RuntimeError("QWENWORK_SESSION_NO_TOKEN|QwenWork 登录态中无会话 token，请先登录千问办公")
    # token 用完即弃：仅用于网关取号，不入缓存、不打日志、不入异常文本
    userinfo = qwenwork_fetch_userinfo(token)
    identity = qwenwork_extract_identity(userinfo)
    phone = qwenwork_resolve_phone(userinfo)

    version = load_auth_version_info()
    body = {
        "skillCode": skill_code or SKILL_CODE,
        "resolvedPhone": phone,
        "workbuddySub": identity["sub"],        # QwenWork userId(UUID)，复用现有绑定协议身份字段
        "workbuddyOneid": identity["oneid"],    # QwenWork username（句柄）
        "workbuddyAccount": identity["account"],  # QwenWork name/nickname
        "agent": "qwenwork",
        "bootstrapVersion": str(version.get("bootstrapVersion", "")).strip(),
        "runtimeVersion": str(version.get("authRuntimeVersion", "")).strip(),
        "protocolVersion": str(version.get("protocolVersion", "")).strip(),
    }
    creds = _rt("call_resolve_bind_api")(body, base_api=API_BASE_URL)
    # 兼容解包：新绑定返回四元组(app_key, app_secret, mcp_token, mcp_url)，旧运行时返回二元组/三元组时按位兜底
    if len(creds) >= 3:
        app_key, app_secret, mcp_token = creds[0], creds[1], creds[2]
        mcp_url = creds[3] if len(creds) >= 4 else ""
    else:
        app_key, app_secret = creds
        mcp_token, mcp_url = "", ""
    save_credentials(
        app_key,
        app_secret,
        workbuddy_sub=identity["sub"],
        skill_code=skill_code or SKILL_CODE,
        mcp_token=mcp_token,
        mcp_url=mcp_url,
        agent="qwenwork",
    )
    print(AUTH_BIND_OK)
    print("[auth] qwenwork bind succeeded")


# ==================== QwenWork（千问办公）本地取号兜底实现 ====================
# 与 auth_runtime.py 的同名方法保持一致：auth.py 作为 Bootstrap 壳离线兜底，
# 共享鉴权运行时（层一热更新）安装后经 _rt() 优先使用运行时版本。

QWENWORK_USERINFO_URL = os.environ.get(
    "QWENWORK_USERINFO_URL",
    "https://gateway.qwenwork.cn/api/v1/userinfo",
).rstrip("/")
# macOS login keychain 项默认服务名/账户名；不同打包配置可能不同，见 SKILL.md 第 0 步引导。
QWENWORK_KEYCHAIN_SERVICE = "QwenWorkCN Safe Storage"
QWENWORK_KEYCHAIN_ACCOUNT = "QwenWorkCN"


def qwenwork_locate_userdata() -> Path:
    """定位 QwenWorkCN 用户数据目录（要求 auth-v2.dat 存在，Windows/macOS 各推一处）。"""
    candidates = [
        Path.home() / "AppData" / "Roaming" / "QwenWorkCN",
        Path.home() / "Library" / "Application Support" / "QwenWorkCN",
    ]
    for userdata in candidates:
        if (userdata / "auth-v2.dat").is_file():
            return userdata
    raise RuntimeError(
        "QWENWORK_USERDATA_NOT_FOUND|未找到 QwenWorkCN 登录态，"
        "请先在千问办公（QwenWork）登录当前账号")


def qwenwork_require_cryptography() -> None:
    """延迟导入 cryptography；缺失抛带安装指引的 RuntimeError（不影响其它取号路径）。"""
    try:
        import cryptography  # noqa: F401
    except ImportError as exc:
        raise RuntimeError(
            "QWENWORK_CRYPTO_MISSING|解密 QwenWork 登录态需要 cryptography 库，"
            "请先执行：pip install cryptography") from exc


def qwenwork_load_local_state(userdata: Path) -> dict[str, Any]:
    """读取 Local State（明文 JSON），返回 os_crypt.encrypted_key 原文。"""
    state_path = userdata / "Local State"
    if not state_path.is_file():
        raise RuntimeError(f"QWENWORK_STATE_NOT_FOUND|未找到密钥文件: {state_path}")
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"QWENWORK_STATE_INVALID|Local State 读取失败: {exc}") from exc
    key_b64 = str((state.get("os_crypt") or {}).get("encrypted_key") or "").strip()
    if not key_b64:
        raise RuntimeError("QWENWORK_STATE_NO_KEY|Local State 缺少 os_crypt.encrypted_key")
    return {"key_b64": key_b64, "path": str(state_path)}


def _qwenwork_dpapi_unprotect(blob: bytes) -> bytes:
    """Windows DPAPI（CryptUnprotectData）解包，仅当前 Windows 用户账户可解。"""
    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [
            ("cbData", wintypes.DWORD),
            ("pbData", ctypes.POINTER(ctypes.c_char)),
        ]

    src = DATA_BLOB(len(blob), ctypes.create_string_buffer(blob, len(blob)))
    dst = DATA_BLOB()
    if not ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(src), None, None, None, None, 0, ctypes.byref(dst)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(dst.pbData, dst.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(dst.pbData)


def qwenwork_windows_aes_key(state: dict[str, Any]) -> bytes:
    """Windows 平台 AES-256-GCM 主钥：encrypted_key 去 5 字节 DPAPI 前缀后 DPAPI 解包为 32 字节。"""
    key_blob = base64.b64decode(state["key_b64"])
    if key_blob[:5] != b"DPAPI":
        raise RuntimeError("QWENWORK_KEY_FORMAT_INVALID|encrypted_key 缺少 DPAPI 前缀")
    return _qwenwork_dpapi_unprotect(key_blob[5:])


def _qwenwork_decrypt_auth_v2(raw: bytes, aes_key: bytes) -> dict[str, Any]:
    """AES-256-GCM 解密 auth-v2.dat：v10(3B) + nonce(12B) + 密文 + GCM tag(16B)。"""
    if raw[:3] != b"v10":
        raise RuntimeError(f"QWENWORK_DAT_FORMAT_UNKNOWN|auth-v2.dat 头部非 v10: {raw[:3]!r}")
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    try:
        plaintext = AESGCM(aes_key).decrypt(raw[3:15], raw[15:], None)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(
            f"QWENWORK_DAT_DECRYPT_FAILED|auth-v2.dat 解密失败（可能换用户/换机器）: {exc}") from exc
    try:
        return json.loads(plaintext.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"QWENWORK_DAT_JSON_INVALID|解密内容非 JSON: {exc}") from exc


def _qwenwork_macos_read_keychain() -> bytes:
    """macOS：从 login keychain 读取口令（首次可能弹授权框，允许后不再提示）。"""
    import subprocess
    try:
        password = subprocess.check_output(
            [
                "security", "find-generic-password", "-w",
                "-s", QWENWORK_KEYCHAIN_SERVICE,
                "-a", QWENWORK_KEYCHAIN_ACCOUNT,
            ],
            stderr=subprocess.STDOUT,
        ).rstrip(b"\n")
    except (OSError, subprocess.CalledProcessError) as exc:
        raise RuntimeError(
            f"QWENWORK_KEYCHAIN_READ_FAILED|钥匙串读取失败（按 SKILL.md 第 0 步确认服务名后重试）: {exc}") from exc
    if not password:
        raise RuntimeError("QWENWORK_KEYCHAIN_EMPTY|钥匙串口令为空")
    return password


def _qwenwork_decrypt_macos_auth_v2(raw: bytes) -> dict[str, Any]:
    """macOS：AES-128-CBC 解密 auth-v2.dat，IV=16×0x20，密钥 PBKDF2-HMAC-SHA1(saltysalt,1003)。"""
    if raw[:3] != b"v10":
        raise RuntimeError(f"QWENWORK_DAT_FORMAT_UNKNOWN|auth-v2.dat 头部非 v10: {raw[:3]!r}")
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.primitives import padding
    password = _qwenwork_macos_read_keychain()
    key = hashlib.pbkdf2_hmac("sha1", password, b"saltysalt", 1003, 16)
    try:
        decryptor = Cipher(algorithms.AES(key), modes.CBC(b"\x20" * 16)).decryptor()
        padded = decryptor.update(raw[3:]) + decryptor.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        plaintext = unpadder.update(padded) + unpadder.finalize()
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(
            f"QWENWORK_DAT_DECRYPT_FAILED|auth-v2.dat 解密失败（可能换用户/换机器）: {exc}") from exc
    try:
        return json.loads(plaintext.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"QWENWORK_DAT_JSON_INVALID|解密内容非 JSON: {exc}") from exc


def qwenwork_load_session() -> dict[str, Any]:
    """跨平台从 QwenWorkCN 本地登录态解密会话 JSON（含 token，调用后立即取 token 用毕即弃）。"""
    qwenwork_require_cryptography()
    userdata = qwenwork_locate_userdata()
    raw = (userdata / "auth-v2.dat").read_bytes()
    if sys.platform == "win32":
        state = qwenwork_load_local_state(userdata)
        return _qwenwork_decrypt_auth_v2(raw, qwenwork_windows_aes_key(state))
    if sys.platform == "darwin":
        return _qwenwork_decrypt_macos_auth_v2(raw)
    raise RuntimeError(
        f"QWENWORK_PLATFORM_UNSUPPORTED|暂不支持平台 {sys.platform}，请在 Windows/macOS 上运行 QwenWork")


def qwenwork_fetch_userinfo(token: str) -> dict[str, Any]:
    """用会话 JWT 调 QwenWork 网关 /userinfo；token 不入日志/异常，响应仅短暂驻留内存。"""
    result = _get_json(
        QWENWORK_USERINFO_URL,
        {"Authorization": f"Bearer {token}", "Accept": "application/json"},
        timeout=20,
    )
    if not isinstance(result, dict):
        raise RuntimeError("QWENWORK_USERINFO_INVALID|网关非 JSON 响应")
    return result


def qwenwork_resolve_phone(userinfo: dict[str, Any]) -> str:
    """从 /userinfo.detail.phone 提取并归一化 11 位手机号。
    网关返回 E.164 格式（含 +86 国家码）且未脱敏；若含 '*'（平台脱敏口径）则明确报错，
    不静默降级为脱敏号——当前后端绑定协议要求完整手机号。"""
    phone = str((userinfo.get("detail") or {}).get("phone") or "").strip()
    if not phone:
        raise RuntimeError("QWENWORK_PHONE_NOT_FOUND|网关未返回手机号（detail.phone 为空）")
    if "*" in phone:
        raise RuntimeError(
            "QWENWORK_PHONE_MASKED|QwenWork 返回脱敏手机号，无法完成绑定；"
            "请确认千问办公账号已完整授权（必要时重新登录），或联系平台核实 userinfo 接口口径")
    try:
        return normalize_cn_phone(phone)
    except ValueError as exc:
        raise RuntimeError(f"QWENWORK_PHONE_INVALID|QwenWork 手机号格式不正确: {phone[:7]}****") from exc


def qwenwork_extract_identity(userinfo: dict[str, Any]) -> dict[str, str]:
    """提取绑定所需身份字段：sub=平台 userId(UUID)、oneid=username、account=name/nickname。"""
    sub = str(userinfo.get("id") or "").strip()
    if not sub:
        raise RuntimeError("QWENWORK_IDENTITY_NOT_FOUND|网关未返回用户 id")
    return {
        "sub": sub,
        "oneid": str(userinfo.get("username") or "").strip(),
        "account": str(userinfo.get("name") or userinfo.get("nickname") or "").strip(),
    }


def extract_enterprise_id(account: dict[str, Any]) -> str:
    """从 IdP 账户属性回退提取当前企业 ID（用于提交 V2 绑定）。"""
    attrs = account.get("attributes") or {}
    ll = attrs.get("plugin-last-login-ent")
    if isinstance(ll, list) and ll and str(ll[0]).strip():
        return str(ll[0]).strip()
    ent = attrs.get("enterprise_id")
    if isinstance(ent, list) and ent and str(ent[0]).strip():
        return str(ent[0]).strip()
    return ""


def extract_enterprise_name(account: dict[str, Any]) -> str:
    """从 IdP 账户属性回退提取当前企业名称（用于提交 V2 绑定）。

    IdP 无独立企业名字段，department* 的值为「企业名/部门/子部门」全路径，取第一段。
    优先带 oneid_account_id 后缀的精确 key，其次无后缀全路径，最后才用 departmentName*
    兜底（子部门成员的 departmentName 是部门名而非企业名，故不能优先）。
    仅用于展示，取不到返回空串、不抛异常。
    """
    attrs = account.get("attributes") or {}
    if not isinstance(attrs, dict):
        return ""

    def _first(key: str) -> str:
        val = attrs.get(key)
        if isinstance(val, list):
            for item in val:
                text = str(item or "").strip()
                if text:
                    return text
            return ""
        return str(val or "").strip()

    account_id = _first("oneid_account_id")
    candidates: list[str] = []
    if account_id:
        candidates += [f"departmentFullPaths_{account_id}", f"departmentFullPath_{account_id}"]
    candidates += ["departmentFullPaths", "departmentFullPath"]
    if account_id:
        candidates += [f"departmentNames_{account_id}", f"departmentName_{account_id}"]
    candidates += ["departmentNames", "departmentName"]

    for key in candidates:
        raw = _first(key)
        if not raw:
            continue
        top = re.split(r"[/>\\|]", raw)[0].strip()
        if top:
            return top
    return ""


def bind_with_jwt(token: str, *, skill_code: str | None = None) -> None:
    """Parse WorkBuddy JWT, bind user, and save credentials."""
    parse_jwt_payload = _rt("parse_jwt_payload")
    call_bind_api = _rt("call_bind_api")
    payload = parse_jwt_payload(token)
    workbuddy_sub = str(payload.get("sub", "")).strip()
    phone = str(payload.get("preferred_username", "")).strip()
    nickname = str(payload.get("nickname", "")).strip()

    if not workbuddy_sub or not phone:
        raise SystemExit(
            "[auth] JWT payload missing required fields: sub / preferred_username")

    creds = call_bind_api(
        workbuddy_sub=workbuddy_sub,
        phone=phone,
        nickname=nickname,
        skill_code=skill_code or SKILL_CODE,
        base_api=API_BASE_URL,
    )
    # 兼容解包：新绑定返回四元组(app_key, app_secret, mcp_token, mcp_url)，旧运行时返回二元组/三元组时按位兜底
    if len(creds) >= 3:
        app_key, app_secret, mcp_token = creds[0], creds[1], creds[2]
        mcp_url = creds[3] if len(creds) >= 4 else ""
    else:
        app_key, app_secret = creds
        mcp_token, mcp_url = "", ""
    save_credentials(
        app_key,
        app_secret,
        workbuddy_sub=workbuddy_sub,
        skill_code=skill_code or SKILL_CODE,
        mcp_token=mcp_token,
        mcp_url=mcp_url,
        agent="workbuddy",
    )
    print(AUTH_BIND_OK)
    print("[auth] bind succeeded")


def bind_manual_phone(*, phone: str = "", skill_code: str | None = None, agent: str = "workbuddy") -> None:
    """手动手机号绑定（临时放宽路径，编排入口，仅存在于 auth.py）。

    <p>当宿主 agent 拿不到 resolveWorkbuddyAccount 所需的 IdP 身份参数
    （WorkBuddy connect_cloud_service JWT 不可用 / QwenWork 本地取号失败等）时，
    由宿主引导用户直接输入已在百通注册的手机号，仅凭 resolvedPhone 调后端
    resolveWorkbuddyAccount 换取 AppKey/AppSecret。
    后端保留「手机号已注册 + skillCode 必填 + 技能 VIP」校验，仅放开绑定关系一致性
    （见 BtSkillBindServiceImpl）。</p>

    编排说明：优先取共享运行时 auth_runtime.bind_manual_phone（随运行时发布热更，
    返回 creds 四元组）；运行时缺失/无该方法时回落本文件内置兜底；无论走哪条，
    都在本函数统一解包并落盘凭证。因本函数自身是 auth.py 编排入口，勿用
    _rt("bind_manual_phone") 取实现（会回落自身成递归），改为直接访问运行时模块。

    Args:
        phone: 用户输入的 11 位中国大陆手机号（可为空，由调用方交互读取）。
        skill_code: 技能编码，默认取 _meta.json.slug。
        agent: 宿主 agent（workbuddy / qwenwork），决定凭证缓存目录。
    """
    phone = (phone or "").strip()
    if not phone:
        raise RuntimeError("PHONE_EMPTY|手机号不能为空，请输入已在百通平台注册的手机号")
    target_skill_code = skill_code or SKILL_CODE
    if not target_skill_code:
        raise RuntimeError("SKILL_CODE_MISSING|skillCode 必填，无法完成手动手机号绑定")
    version = load_auth_version_info()

    # 1. 优先共享运行时实现（热更可达存量用户，返回 creds 四元组，不落盘）
    creds: tuple[Any, Any, Any, Any] | None = None
    loaded = load_shared_runtime()
    module = loaded.get("module")
    runtime_fn = getattr(module, "bind_manual_phone", None) if module is not None else None
    if callable(runtime_fn):
        creds = runtime_fn(
            phone=phone,
            skill_code=target_skill_code,
            agent=agent,
            base_api=API_BASE_URL,
            version_info=version,
        )
    else:
        # 2. 运行时缺失/无该方法 → 内置兜底：自行组装 body 后复用 call_resolve_bind_api 原语
        body: dict[str, Any] = {
            "skillCode": target_skill_code,
            "resolvedPhone": phone,
            "agent": agent,
            "bootstrapVersion": str(version.get("bootstrapVersion", "")).strip(),
            "runtimeVersion": str(version.get("authRuntimeVersion", "")).strip(),
            "protocolVersion": str(version.get("protocolVersion", "")).strip(),
        }
        call_resolve_bind_api = _rt("call_resolve_bind_api")
        creds = call_resolve_bind_api(body, base_api=API_BASE_URL)

    # 兼容解包：新绑定返回四元组(app_key, app_secret, mcp_token, mcp_url)，旧运行时返回二元组/三元组时按位兜底
    if len(creds) >= 3:
        app_key, app_secret, mcp_token = creds[0], creds[1], creds[2]
        mcp_url = creds[3] if len(creds) >= 4 else ""
    else:
        app_key, app_secret = creds
        mcp_token, mcp_url = "", ""
    save_credentials(
        app_key,
        app_secret,
        workbuddy_sub="",  # 手动绑定路径拿不到 IdP 身份 sub，置空保存
        skill_code=target_skill_code,
        mcp_token=mcp_token,
        mcp_url=mcp_url,
        agent=agent,
    )
    print(AUTH_BIND_OK)
    print("[auth] manual-phone bind succeeded")


def print_bind_instruction(skill_code: str) -> None:
    print(
        "[auth] call WorkBuddy connect_cloud_service, then bind WITHOUT hand-transcribing the JWT.\n"
        "   唯一推荐：从会话日志/项目 jsonl 原样提取（token 全程走文件句柄，零手抄）：\n"
        f'   python3 scripts/auth.py --bind-token-from-log "<SESSION_OR_JSONL_LOG_FILE>" --skill-code "{skill_code}"\n'
        "   提示：--bind-token-from-file 仅当 token 已由上游直接写入本地文件、你并未手抄时才可使用；\n"
        "   （若你需要『手动把 token 填进文件』，那就仍是手抄，请改用 --bind-token-from-log，不要为 from-file 而 from-file）\n"
        f'   辅助：python3 scripts/auth.py --bind-token-stdin --skill-code "{skill_code}"  < "<TOKEN_FILE>"  (token 原样重定向)\n'
        f"WARNING: never use --bind-jwt '<JWT>' - hand-copying a long JWT corrupts its signature "
        f"and yields a FAKE 401.")


def ensure_authorized(*, skill_code: str | None = None, verify_remote: bool = True) -> None:
    """Ensure this Skill is authorized before use.
    启动即检查共享鉴权运行时版本（有新版本先更新/提示，再继续鉴权）。"""
    check_runtime_update()
    call_verify_api = _rt("call_verify_api")
    target_skill_code = skill_code or SKILL_CODE
    agent = os.environ.get("BT_SKILL_AGENT", "workbuddy").lower()
    record = load_credential_record(skill_code=target_skill_code, agent=agent)
    target_skill_code = skill_code or record.get("skill_code") or SKILL_CODE
    if str(record.get("skill_code", target_skill_code)) != target_skill_code:
        print(AUTH_INVALID)
        print(SIGNAL_INVALID)
        print(
            f"[auth] cached credential is for another skill: {record.get('skill_code')}", file=sys.stderr)
        print_bind_instruction(target_skill_code)
        sys.exit(1)

    if verify_remote:
        try:
            call_verify_api(record, skill_code=target_skill_code, base_api=API_BASE_URL)
        except RuntimeError as exc:
            print(AUTH_INVALID)
            print(SIGNAL_INVALID)
            print(
                f"[auth] remote authorization check failed: {exc}", file=sys.stderr)
            print_bind_instruction(target_skill_code)
            sys.exit(1)

    print(AUTH_OK)
    print(f"[auth] authorized for skill: {target_skill_code}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Unified Skill authorization helper")
    parser.add_argument("--skill-code", default=SKILL_CODE,
                        help="Skill code, defaults to _meta.json.slug")
    parser.add_argument("--ensure", action="store_true",
                        help="Require a valid authorization before using the Skill")
    parser.add_argument("--no-verify", action="store_true",
                        help="Only check local credentials; skip remote verification")
    parser.add_argument("--bind-jwt", "--bind", dest="bind_jwt",
                        metavar="JWT_TOKEN", help="(legacy, discouraged) Bind with a WorkBuddy JWT passed on the command line")
    parser.add_argument("--bind-token-stdin", action="store_true",
                        help="Read the connect_cloud_service token from stdin (avoids token in argv)")
    parser.add_argument("--bind-token-from-file", metavar="TOKEN_FILE",
                        help="(discouraged) Read the token from a file and bind. ONLY valid when the token was written to "
                             "the file directly by upstream (you did NOT hand-transcribe it). If you must manually put the "
                             "token into the file, that is still hand-copying — use --bind-token-from-log instead")
    parser.add_argument("--bind-token-from-log", metavar="LOG_FILE",
                        help="(preferred) Recover the most recent complete WorkBuddy JWT from a session log / project .jsonl "
                             "(regex + parse_jwt_payload filter, token never in argv) and bind")
    parser.add_argument("--bind-qwenwork-local", action="store_true",
                        help="QwenWork(千问办公): decrypt the local QwenWorkCN login state, resolve the full phone via "
                             "gateway /userinfo and bind. No token handling/manual copy required.")
    parser.add_argument("--bind-phone", metavar="PHONE", nargs="?", const="",
                        help="Manual phone bind (temp fallback): when the host agent cannot obtain the IdP identity "
                             "params required by resolveWorkbuddyAccount, ask the user to type their registered phone and "
                             "bind with phone only. Pass the phone as the argument, or omit it to prompt on stdin.")
    parser.add_argument("--agent", choices=["workbuddy", "qwenwork"], default=None,
                        help="Host agent the skill runs in: workbuddy (default) or qwenwork (qianwen office). "
                             "Also honored from env BT_SKILL_AGENT when absent.")
    parser.add_argument("--check", action="store_true",
                        help="Alias for --ensure --no-verify")
    parser.add_argument("--save-token", metavar="APP_KEY",
                        help="Save AppKey manually")
    parser.add_argument("--save-secret", metavar="APP_SECRET",
                        help="Save AppSecret manually")
    args = parser.parse_args()

    # 宿主 agent 识别：显式 --agent > 环境变量 BT_SKILL_AGENT > 默认 workbuddy。
    # 当前影响命令语义与运行日志（便于排查宿主上下文）；未来如需按 agent 隔离凭证缓存可在此扩展。
    agent = (args.agent or os.environ.get("BT_SKILL_AGENT", "") or "workbuddy").lower()
    if agent not in ("workbuddy", "qwenwork"):
        agent = "workbuddy"

    if args.bind_token_from_log:
        # 从会话日志/项目 jsonl 里用正则原样提取最长有效 JWT，零手抄。
        try:
            token = recover_jwt_from_log_file(args.bind_token_from_log)
        except (OSError, ValueError) as exc:
            print(AUTH_INVALID)
            print(f"[auth] --bind-token-from-log failed: {exc}", file=sys.stderr)
            sys.exit(1)
    elif args.bind_token_from_file:
        # 从文件读取 token，token 不进 argv，也无需手抄拼进命令行。
        try:
            token = Path(args.bind_token_from_file).read_text(
                encoding="utf-8", errors="replace").strip()
        except OSError as exc:
            print(AUTH_INVALID)
            print(f"[auth] --bind-token-from-file failed: {exc}", file=sys.stderr)
            sys.exit(1)
        if not token:
            print(AUTH_INVALID)
            print("[auth] --bind-token-from-file: token file is empty", file=sys.stderr)
            sys.exit(1)
    elif args.bind_token_stdin:
        token = sys.stdin.read().strip()
        if not token:
            print(AUTH_INVALID)
            print("[auth] --bind-token-stdin: empty token on stdin", file=sys.stderr)
            sys.exit(1)
    else:
        # 兼容旧用法 --bind-jwt，但强烈不推荐：超长 JWT 拼进 argv 必手抄损坏签名致假 401。
        token = args.bind_jwt.strip() if args.bind_jwt else ""

    if args.bind_qwenwork_local:
        # QwenWork(千问办公)：无需手抄 token，从本地登录态解密取号并完成绑定。
        try:
            bind_qwenwork_local(skill_code=args.skill_code)
        except (RuntimeError, ValueError) as exc:
            print(AUTH_INVALID)
            print(f"[auth] qwenwork bind failed: {exc}", file=sys.stderr)
            sys.exit(1)
        return

    if args.bind_phone is not None:
        # 手动手机号绑定（临时放宽路径）：宿主拿不到 resolveWorkbuddyAccount 所需 IdP 身份参数时，
        # 直接向用户索要已注册手机号完成绑定；--bind-phone 后可带号，不带则从 stdin 提示读取。
        phone = (args.bind_phone or "").strip()
        if not phone:
            sys.stderr.write("[auth] 请输入已在百通平台注册的手机号: ")
            sys.stderr.flush()
            phone = sys.stdin.readline().strip() if sys.stdin and sys.stdin.isatty() else ""
            if not phone:
                print(AUTH_INVALID)
                print("[auth] 未获取到手机号，放弃手动绑定。也可用 --bind-phone <手机号> 直接传入", file=sys.stderr)
                sys.exit(1)
        try:
            bind_manual_phone(phone=phone, skill_code=args.skill_code, agent=agent)
        except (RuntimeError, ValueError) as exc:
            print(AUTH_INVALID)
            print(f"[auth] manual-phone bind failed: {exc}", file=sys.stderr)
            sys.exit(1)
        return

    if token:
        try:
            bind_v2_from_token(token, skill_code=args.skill_code)
        except (RuntimeError, ValueError) as exc:
            print(AUTH_INVALID)
            print(f"[auth] bind failed: {exc}", file=sys.stderr)
            sys.exit(1)
        return

    if args.ensure or args.check:
        print(f"[auth] host agent: {agent}", file=sys.stderr)
        ensure_authorized(skill_code=args.skill_code,
                          verify_remote=not (args.no_verify or args.check))
        return

    if args.save_token or args.save_secret:
        if not args.save_token or not args.save_secret:
            parser.error(
                "--save-token and --save-secret must be used together")
        save_credentials(args.save_token, args.save_secret,
                         skill_code=args.skill_code, agent=agent)
        return

    parser.print_help()


if __name__ == "__main__":
    main()
