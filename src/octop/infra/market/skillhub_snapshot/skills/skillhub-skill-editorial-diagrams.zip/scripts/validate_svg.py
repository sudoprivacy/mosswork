#!/usr/bin/env python3
"""
validate_svg.py — editorial-diagrams (ed-diag) 确定性合规校验器

对生成的 .html（内嵌 SVG）或 .svg 文件执行 SKILL.md 中"算术型/API 级"硬约束：
  1. 4px 网格：所有坐标/尺寸可被 4 整除（豁免：描边宽度、不透明度、marker 内部、dash 数组、圆角 4/6/8）
  2. 字号白名单：8, 12, 16, 20, 24, 28, 32, 40
  3. 对角线 <line>（x1!=x2 且 y1!=y2 为硬失败）
  4. accent 焦点计数（画布区 ≤2，图例条带不计）
  5. 禁止 writing-mode 垂直文本
  6. 禁止阴影（box-shadow / feDropShadow / drop-shadow）
  7. 禁止 JetBrains Mono
  8. 禁止 Mermaid / drawio / 外部 JS（<script> 标签）
  9. 箭头标签遮罩启发式：8px mono 标签数应 ≤ 小遮罩矩形数

用法：
  python validate_svg.py <file.html|file.svg> [更多文件...]

退出码：0 = 通过（可含警告）；1 = 存在 ERROR。
"""
import re
import sys

ALLOWED_FONT_SIZES = {8, 12, 16, 20, 24, 28, 32, 40}
ALLOWED_RADII = {4, 6, 8}
ACCENT_HEX = "#eb6c36"
ACCENT_RGB_RE = re.compile(r"rgba\(\s*235\s*,\s*108\s*,\s*54", re.I)


def extract_svg(text):
    m = re.search(r"<svg[\s\S]*?</svg>", text)
    return m.group(0) if m else None


def numbers_in(s):
    return [float(n) for n in re.findall(r"-?\d+\.?\d*", s)]


def validate(path):
    errors, warnings = [], []
    try:
        text = open(path, encoding="utf-8").read()
    except OSError as e:
        return [f"无法读取文件: {e}"], []

    # ---- 文档级禁令（不依赖 SVG） ----
    if re.search(r"<script[\s>]", text, re.I):
        errors.append("JS：存在 <script> 标签（输出必须无 JavaScript）")
    if re.search(r"mermaid|drawio|mxgraph", text, re.I):
        errors.append("格式：检测到 Mermaid/drawio 引用（禁止）")
    if re.search(r"jetbrains", text, re.I):
        errors.append("字体：检测到 JetBrains Mono（禁止作为通用 UI 字体）")
    if re.search(r"box-shadow|feDropShadow|drop-shadow", text, re.I):
        errors.append("阴影：检测到 shadow（阴影出局，边框入局）")
    if re.search(r"writing-mode", text, re.I):
        errors.append("文本：检测到 writing-mode 垂直文本（禁止）")

    svg = extract_svg(text)
    if svg is None:
        errors.append("未找到 <svg> 节点")
        return errors, warnings

    vb = re.search(r'viewBox="([\d.\s-]+)"', svg)
    vb_h = float(vb.group(1).split()[3]) if vb else None
    if vb is None:
        warnings.append("viewBox：未定义")
    legend_y_min = (vb_h - 64) if vb_h else float("inf")  # 图例条带 ≈ 底部 60px + 余量

    body = re.sub(r"<defs>[\s\S]*?</defs>", "", svg)  # marker 内部属装饰原语，豁免

    # ---- 1. 4px 网格 ----
    grid_bad = []
    attr_re = re.compile(r'(?<![a-z-])(x1|x2|y1|y2|x|y|cx|cy|width|height|rx|ry)="(-?[\d.]+)"')
    for m in attr_re.finditer(body):
        k, v = m.group(1), float(m.group(2))
        if k in ("rx", "ry") and v in ALLOWED_RADII:
            continue
        if v % 4 != 0:
            grid_bad.append(f"{k}={v:g}")
    for m in re.finditer(r'points="([\d.,\s-]+)"', body):
        for n in numbers_in(m.group(1)):
            if n % 4 != 0:
                grid_bad.append(f"points 含 {n:g}")
    for m in re.finditer(r'(?<![a-z])d="([\d.,A-Za-z\s-]+)"', body):
        for n in numbers_in(m.group(1)):
            if n % 4 != 0:
                grid_bad.append(f"path 含 {n:g}")
    if grid_bad:
        errors.append(f"4px 网格：{len(grid_bad)} 处不可被 4 整除 → {grid_bad[:12]}"
                      + (" ..." if len(grid_bad) > 12 else ""))

    # ---- 2. 字号白名单 ----
    fs_bad = sorted({float(v) for v in re.findall(r'font-size="?([\d.]+)', body)
                     if float(v) not in ALLOWED_FONT_SIZES})
    if fs_bad:
        errors.append(f"字号：{fs_bad} 不在白名单 {sorted(ALLOWED_FONT_SIZES)}")

    # ---- 3. 对角线 <line> ----
    for m in re.finditer(r"<line\b[^>]*>", body):
        tag = m.group(0)
        g = lambda k: float(re.search(rf'{k}="(-?[\d.]+)"', tag).group(1))
        if all(re.search(rf'{k}="', tag) for k in ("x1", "y1", "x2", "y2")):
            if g("x1") != g("x2") and g("y1") != g("y2"):
                errors.append(f"对角线：<line> ({g('x1'):g},{g('y1'):g})→({g('x2'):g},{g('y2'):g}) 非水平/垂直（硬失败）")

    # ---- 4. accent 焦点计数（画布区） ----
    canvas_accent = 0
    for m in re.finditer(r"<(rect|circle|ellipse|polygon|path|line)\b[^>]*>", body):
        tag = m.group(0)
        is_accent = (ACCENT_HEX in tag) or bool(ACCENT_RGB_RE.search(tag))
        if not is_accent:
            continue
        ys = []
        for k in ("y", "cy", "y1", "y2"):
            km = re.search(rf'(?<![a-z]){k}="(-?[\d.]+)"', tag)
            if km:
                ys.append(float(km.group(1)))
        pm = re.search(r'points="([\d.,\s-]+)"', tag)
        if pm:
            nums = numbers_in(pm.group(1))
            ys += nums[1::2]
        if ys and max(ys) >= legend_y_min:
            continue  # 图例条带内的 accent 样本不计
        canvas_accent += 1
    if canvas_accent > 2:
        errors.append(f"accent：画布区 {canvas_accent} 个焦点元素（>2，焦点信号被抹掉）")
    else:
        warnings.append(f"accent：画布区 {canvas_accent} 个焦点元素（≤2 合规）")

    # ---- 5. 箭头标签遮罩启发式 ----
    label_count = len(re.findall(r"<text[^>]*font-size=\"?8\"?[^>]*>", body))
    mask_count = len(re.findall(r'<rect[^>]*height="12"[^>]*>', body))
    if label_count > mask_count:
        warnings.append(f"遮罩启发式：8px 标签 {label_count} 个 > 12px 高遮罩矩形 {mask_count} 个，"
                        "请人工确认每个箭头标签都有不透明遮罩")

    return errors, warnings


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    total_err = 0
    for path in sys.argv[1:]:
        errors, warnings = validate(path)
        print(f"== {path} ==")
        for w in warnings:
            print(f"  [WARN] {w}")
        for e in errors:
            print(f"  [ERROR] {e}")
        if not errors:
            print("  ✅ 通过（无 ERROR）")
        total_err += len(errors)
    sys.exit(1 if total_err else 0)


if __name__ == "__main__":
    main()
