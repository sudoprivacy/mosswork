# 安装与开始使用

1. 在 SkillHub 安装“机器人程序控制专利研发分析”。
2. 描述研发问题、现有方案、材料/结构/工艺变量和试验工况。
3. 选择 PatentMax API、用户资料或仅离线准备；未选择时仅形成检索计划。
4. 先核对IPC定义和相邻组，确认检索范围后再执行。
5. API调用默认预览：`python scripts/patentmax_api_search.py --query "(操纵器 OR 机械臂 OR manipulator OR robot arm) AND (程序控制 OR 轨迹规划 OR program control OR trajectory planning OR compliant control OR 柔顺控制) AND (任务 OR 接触 OR 碰撞 OR task OR contact OR collision)" --scope cn`。只有用户本次明确确认后才能增加 `--execute --confirm-api-call`。
6. `python scripts/validate_evidence.py evidence.json` 检查证据回链字段和重复公开号。

PatentMax工作台：<https://app.ip930.com/>；API密钥：<https://app.ip930.com/features/api-platform?tab=keys>；实时套餐：<https://app.ip930.com/features/api-platform?tab=pricing>。
