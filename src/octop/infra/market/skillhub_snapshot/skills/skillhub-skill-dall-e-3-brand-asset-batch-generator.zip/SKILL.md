---
name: skillhub-skill-dall-e-3-brand-asset-batch-generator
description: "使用OpenAI Images API与DALL-E 3批量生成品牌资产。管理提示词工程，以确保图标、横幅和社交媒体模板中品牌标识的一致性。"
---

# DALL-E 3品牌资产批量生成器

使用OpenAI Images API与DALL-E 3批量生成品牌资产。管理提示词工程，以确保图标、横幅和社交媒体模板中品牌标识的一致性。

## 安装

无法自动提取基于源码的安装或使用说明。在敏感工作流程中运行此技能之前，请先查看上游项目。

- Source: https://platform.openai.com/docs/guides/images
