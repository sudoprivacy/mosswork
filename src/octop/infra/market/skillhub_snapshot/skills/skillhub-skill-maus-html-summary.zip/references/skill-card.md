## Description: <br>
Turns articles, transcripts, long posts, and raw text into self-contained illustrated HTML explainers with simple language, source-grounded extraction, and explanatory SVG metaphors. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[nefas11](https://clawhub.ai/user/nefas11) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users, writers, educators, and agents use this skill to turn source text into a self-contained, source-faithful HTML explainer with structured main ideas, inline SVG metaphors, omissions, and a short memory hook. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Implicit invocation may transform private or sensitive source text into an HTML document. <br>
Mitigation: Use only content appropriate for transformation, avoid sensitive source text unless authorized, and review the generated HTML before sharing. <br>
Risk: Summaries can omit nuance or introduce unsupported details if the source is ambiguous. <br>
Mitigation: Review the generated explainer against the source text, especially the main ideas, omissions, and memory hook. <br>


## Reference(s): <br>
- [SVG Skeleton Patterns](artifact/svg-patterns.md) <br>
- [Maus HTML Summary on ClawHub](https://clawhub.ai/nefas11/maus-html-summary) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Code, Guidance] <br>
**Output Format:** [Self-contained HTML document with inline CSS and inline SVG] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [No external scripts, fonts, images, fetches, or stylesheet links; output includes a pre-emit audit checklist.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
