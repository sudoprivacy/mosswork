#!/usr/bin/env python3
"""从小红书 RedSkill 商店下载技能包压缩包(zip)，仅下载、不安装。

用法:
    python3 download_redskill_pkg.py <identifier 或完整安装命令> [输出目录或 .zip 路径]

identifier 解析规则:
    - 纯 identifier:      atiansolo-cut-skill
    - 完整安装命令:       redskill install atiansolo-cut-skill
                          redskill install atiansolo-cut-skill --dir ./skills

输出路径规则(默认当前目录):
    - 省略第二参数:       ./<identifier>.zip
    - 指定目录:           <目录>/<identifier>.zip
    - 指定 .zip 路径:     直接使用该路径
"""
from __future__ import annotations

import hashlib
import os
import re
import sys

REDSKILL_SRC = os.path.expanduser("~/.redskill/src")
IDENT_RE = re.compile(r"redskill\s+install\s+(\S+)", re.IGNORECASE)


def parse_identifier(arg: str) -> str:
    """从输入中提取技能 identifier，支持纯 identifier 或完整 redskill install 命令。"""
    arg = arg.strip()
    m = IDENT_RE.search(arg)
    if m:
        return m.group(1).strip()
    arg = arg.strip("'\"")
    if arg.startswith("install "):
        arg = arg[len("install "):].strip()
    return arg


def resolve_output(identifier: str, arg: str) -> str:
    """确定输出路径，返回绝对路径。"""
    default_name = f"{identifier}.zip"
    if not arg:
        return os.path.join(os.getcwd(), default_name)
    arg = arg.strip().strip("'\"")
    if arg.endswith(".zip"):
        return os.path.abspath(arg)
    return os.path.abspath(os.path.join(arg, default_name))


def main() -> int:
    if len(sys.argv) < 2:
        print(
            "用法: python3 download_redskill_pkg.py "
            "<identifier 或 'redskill install xxx'> [输出目录/.zip]",
            file=sys.stderr,
        )
        return 2

    identifier = parse_identifier(sys.argv[1])
    if not identifier:
        print(f"无法从输入中解析技能 identifier: {sys.argv[1]!r}", file=sys.stderr)
        return 2

    if not os.path.isdir(REDSKILL_SRC):
        print(f"未找到 RedSkill CLI 源码目录: {REDSKILL_SRC}", file=sys.stderr)
        print(
            "请先安装 RedSkill 商店:\n"
            "  curl -fsSL https://fe-video-qc.xhscdn.com/fe-platform-file/"
            "104101b8320fbjem2620653u0hejenq0004pf88g6ask5i.sh | bash",
            file=sys.stderr,
        )
        return 1

    sys.path.insert(0, REDSKILL_SRC)
    try:
        import api
        import config
    except ImportError as e:
        print(f"RedSkill CLI 源码加载失败: {e}", file=sys.stderr)
        return 1

    try:
        metadata = config.load_metadata()
        result = api.get_skill_bundle(identifier, metadata)
    except Exception as e:
        print(f"获取技能包失败: {e}", file=sys.stderr)
        print(
            "提示: 请确认 identifier 是否正确，可先运行 redskill search <关键词> 查找",
            file=sys.stderr,
        )
        return 1

    try:
        zip_bytes = result.zip_bytes if result.zip_bytes else api.download_bytes(result.zip_url)
    except Exception as e:
        print(f"下载技能包失败: {e}", file=sys.stderr)
        return 1

    if result.sha256:
        actual = hashlib.sha256(zip_bytes).hexdigest()
        if actual != result.sha256:
            print(f"sha256 校验失败: 实际 {actual} != 声明 {result.sha256}", file=sys.stderr)
            return 1

    out_path = resolve_output(identifier, sys.argv[2] if len(sys.argv) > 2 else "")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    with open(out_path, "wb") as f:
        f.write(zip_bytes)

    print(f"OK saved={out_path}")
    print(
        f"identifier={result.identifier} version={result.version or 'N/A'} "
        f"size={len(zip_bytes)} bytes sha256={result.sha256 or 'N/A'}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
