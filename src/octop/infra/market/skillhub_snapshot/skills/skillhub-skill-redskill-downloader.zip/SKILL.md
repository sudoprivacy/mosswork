---
name: skillhub-skill-redskill-downloader
description: "从小红书 RedSkill 商店下载技能包压缩包（zip），仅下载、不安装。当用户想要下载小红书技能/技能包、复制了 \"redskill install xxx\" 命令并要求得到压缩包、或提到具体技能 identifier（如 atiansolo-cut-skill）希望下载 zip 时使用。This skill should be used when the user wants to download a RedSkill (Xiaohongshu/小红书) skill package as a zip archive without installing it. 触发词：下载小红书技能、技能包下载、redskill 技能下载、下载技能压缩包、download skill package、redskill download。"
---

# Redskill Downloader

## Overview

将 RedSkill 商店中的任意技能下载为 zip 压缩包，**仅下载、不安装**——不会修改任何 skill 目录，也不写入安装记录。用户从小红书复制的安装命令（如 `redskill install atiansolo-cut-skill`）或纯 identifier 均可直接使用。

## 前置条件

RedSkill CLI 必须已安装（脚本依赖 `~/.redskill/src` 下的 `api.py` / `config.py`）：

```bash
ls ~/.local/bin/redskill        # 存在即已安装
```

若未安装，先执行官方安装命令：

```bash
curl -fsSL https://fe-video-qc.xhscdn.com/fe-platform-file/104101b8320fbjem2620653u0hejenq0004pf88g6ask5i.sh | bash
```

## 使用流程

1. **解析技能 identifier**：
   - 用户给出纯 identifier（如 `atiansolo-cut-skill`）→ 直接使用。
   - 用户给出完整安装命令（如 `redskill install atiansolo-cut-skill` 或带 `--dir` 等参数）→ 提取第一个 `redskill install` 后的单词作为 identifier。
   - 无法解析时，向用户确认要下载的技能名。

2. **执行下载脚本**（工作目录为当前会话工作区，输出默认落在当前目录）：

   ```bash
   python3 <skill_dir>/scripts/download_redskill_pkg.py "<identifier 或完整命令>" [输出目录或 .zip 路径]
   ```

   其中 `<skill_dir>` 为本技能所在目录（`~/.workbuddy/skills/redskill-downloader`）。

3. **向用户报告结果**，包含：
   - 保存路径（绝对路径）
   - 技能版本、包大小、sha256 校验结果
   - 明确说明"未安装"（若用户后续想安装，可用 `redskill install <identifier>`）

## 输入与输出示例

| 用户输入 | 命令 | 输出 |
|---|---|---|
| `下载 atiansolo-cut-skill` | `python3 .../download_redskill_pkg.py atiansolo-cut-skill` | `./atiansolo-cut-skill.zip` |
| 复制了 `redskill install atiansolo-cut-skill` | `python3 .../download_redskill_pkg.py "redskill install atiansolo-cut-skill" ./dist` | `./dist/atiansolo-cut-skill.zip` |

## 错误处理

- **技能不存在**：脚本输出 `Skill 不存在或已下架` 并返回退出码 1。此时可建议用户先运行 `redskill search <关键词>` 查找正确 identifier，或向用户确认。
- **RedSkill CLI 未安装**：脚本提示先安装 RedSkill 商店（见前置条件）。
- **sha256 校验失败**：脚本拒绝保存并返回退出码 1，向用户说明下载内容异常。

## Resources

- `scripts/download_redskill_pkg.py`：核心下载脚本。复用 RedSkill CLI 的 `api.get_skill_bundle` 获取技能包 zip 并校验 sha256，不触发安装流程。
