---
name: skillhub-skill-agent-git-oracle
description: "Advanced repository analysis and refactoring guide. Identifies technical debt and architectural anti-patterns using AI reasoning."
---

# Agent Git Oracle

Take your codebase from legacy to sovereign. This skill performs deep-scan audits of your local git repositories, identifying areas of high complexity, potential logic leaks, and opportunities for Agent-Native refactoring.

## Features
- **Debt Detection**: Highlights "Dirty Code" that increases cognitive load.
- **Agentic Mapping**: Suggests how to convert traditional modules into autonomous tools.
- **Commit Wisdom**: Summarizes the "Why" behind large architectural shifts in your project.

## Usage
```bash
npx openclaw skill run agent-git-oracle --path ./your-repo
```

## Why it costs $0.10?
To fund the compute required for deep structural analysis.
