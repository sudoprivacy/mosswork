## Description: <br>
Helps agents prepare and submit Seedance 2.0 Mini video generation jobs on PoYo, including text-to-video, image-to-video, reference-guided video, polling, and webhook follow-up. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to create PoYo Seedance 2.0 Mini request payloads, submit async video generation tasks, and guide follow-up through polling or webhooks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uses a PoYo API key to submit video generation requests. <br>
Mitigation: Keep POYO_API_KEY in a server-side environment or secret manager, and avoid exposing it in browser code, repositories, logs, screenshots, or chat output. <br>
Risk: Submitted prompts, media URLs, and callback URLs may contain confidential or private information. <br>
Mitigation: Review payloads before submission and avoid sending confidential prompts, private media URLs, or sensitive callback URLs unless the user trusts PoYo and the callback receiver. <br>
Risk: Live API submission can incur external processing and account activity. <br>
Mitigation: Only make live PoYo API calls when the user explicitly asks and provides a trusted server-side environment. <br>


## Reference(s): <br>
- [PoYo Seedance 2.0 Mini API Reference](references/api.md) <br>
- [PoYo Seedance 2 Mini model page](https://poyo.ai/models/seedance-2-mini) <br>
- [PoYo Seedance 2 Mini API docs](https://docs.poyo.ai/api-manual/video-series/seedance-2-mini) <br>
- [ClawHub skill page](https://clawhub.ai/coolhackboy/skills/poyo-seedance-2-mini) <br>
- [Publisher profile](https://clawhub.ai/user/coolhackboy) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON payload examples and shell command snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include selected model id, generation mode, payload summary, task_id after submission, and next-step polling or webhook guidance.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
