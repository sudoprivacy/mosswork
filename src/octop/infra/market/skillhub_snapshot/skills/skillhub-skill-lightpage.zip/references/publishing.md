# 发布说明

单文件须为 UTF-8 HTML，自带资源可以内嵌；显式 --preview 可额外上传静态封面。依赖旁边的 CSS、JS 或图片时上传整个静态目录，根目录须有非空 index.html。目录和所有嵌套资源共最多 100 个文件，展开及 ZIP 各最多 50 MiB。脚本按稳定顺序和固定时间戳打包，同样文件生成相同摘要。

仅发布用户允许公开的内容。客户端忽略隐藏文件、node_modules、依赖清单与 source map，拒绝符号链接、设备文件和明确的私钥；这些检查不等于完整脱敏。敏感内容也可能在 HTML、JSON 或图片中，不能把忽略规则当作公开授权。

静态资源支持 HTML、CSS、JS/MJS、JSON、常见图片、字体、音视频、WASM 和文本。服务器不执行构建、Node、Python、PHP，不代理任意 URL，不提供数据库。分享 URL 形如 https://lightpage.hqdx.store/p/abcd1234/（8 位短码示例），直接使用服务端返回的真实 URL；去掉路径即轻页首页，顶部“我的作品”进入个人管理页。JavaScript 在访客浏览器执行，不加 sandbox，localStorage 可用但同一公开域的作品共享存储；不要在其中保存平台凭证或宣称具有作品间私有存储。Service Worker 和定位在托管环境中禁用；摄像头、麦克风允许页面请求，须访客自己授权，并处理不支持和拒绝。

HTML src、link href、poster、srcset/imagesrcset、内联样式和 CSS url/@import 会检查本地资源是否存在。已识别的站点根路径、目录越界、file/内网地址、HTTP 混合内容、base 和平台明确禁用的 object/embed 会在上传前拒绝。动态 JS、SVG 和跨域代码只提供启发式提示，不下载、不执行或自动改写远端资源；不能当作完整语法检查或安全隔离。完整操作见[发布前审查](preflight.md)。

每身份作品数量、每作品版本数量不限，usage.site_limit 与 usage.version_limit 均为 null。平台完全免费，作品不设到期时间，更新不改变链接。不设每身份总存储额度，usage.storage_limit_bytes=null；平台仍有整体存储和日流量预算。准确限制见 usage 和错误返回。没有付费或续期端点，免费不表示资源无限。

需要只做本地检查时：

```bash
python3 "/实际skill目录/scripts/litepage.py" publish /作品/dist --check
```

该命令不会注册或上传，输出文件数、大小、摘要、外部资源标记和 review（最多 20 条提示、has_more/total、browser_verified=false）。提示不含匹配的源码或完整外链；有 has_more 时按文件继续人工检查，不能当作没有其他问题。列表默认 10 条、上限 50，使用响应 next_cursor 按需翻页，不遍历全量。

路径托管要求本地资源使用相对地址（如 ./assets/app.js），不能使用 /assets/app.js 这类站点根路径；构建工具应设置相对 base（例如 Vite --base=./）。CLI 会拒绝已识别的根路径资源引用；运行时 JS 路径仍由作品作者检查。


## 可见性与首页封面

轻页的产品规则是默认 `public`：作品可在轻页首页作品列表被发现，由平台展示和推广。用户指定 `private` 时，作品不进入首页列表，平台不展示或推广，用户通过拿到的链接访问。未启用密码时，两种模式都允许任何持有链接的人无需登录访问；`private` 本身不提供密码保护，不等于下架，也不能阻止链接被转发。需要密码时使用下面的独立密码分享功能。

发布可用 `--visibility public|private`，新作品缺省 public；更新不指定则保留原值。单独切换用 `python3 "/实际skill目录/scripts/litepage.py" visibility 作品UUID private --revision 当前版本号`，先按需读取 status。交付说明实际可见性与链接访问边界。旧作品迁移为 private，不能未经用户要求批量公开。客户端会检查新参数支持情况；服务未升级时报告能力缺口，不移除 private 参数后继续上传。

封面截图是可选的；不传 --preview 直接发布即可，首页使用默认封面。用户需要自定义封面时提供真实网页首屏截图：按[feed 预览截图](preflight.md#feed-预览截图)在本地生成并检查，使用 `--preview /截图/cover.png` 与作品一起上传，可用 `--description "简短介绍"` 提供最多 240 字符的说明。不为普通发布默认生成截图或安装截图依赖。自定义截图不能伪造，用户要求更新封面时提供新图片；不传 --preview 会清除旧版本封面。可用 `python3 "/实际skill目录/scripts/litepage.py" feed --limit 10` 匿名浏览，不自动遍历或打开全部作品。



## 密码分享

用户要求密码分享时，使用上传目录之外的 UTF-8 密码文件（4–128 字符），不把密码写入命令字面量、URL、回执或作品内容。末尾换行会移除。客户端先检查服务支持 password，不支持时停止，不能去掉密码选项继续发布。

```bash
python3 "/实际skill目录/scripts/litepage.py" publish "/作品/dist" --password-file "/私有目录/password.txt"
```

首次发布可原子启用保护；普通更新不带密码文件保留原密码，用户要求更换时明确传入新密码文件。已有作品的重设／移除流程见[重设页面密码](management.md#重设页面密码)，无需重新上传页面或提供旧分享密码。重试原发布操作须使用原密码；幂等冲突不能换 ID 绕过。

返回 password_protected=true 才能说明密码已启用；CLI 还检查未授权公开入口跳转到密码页。保护覆盖作品 HTML 及嵌套图片、脚本等资源，并使作品退出首页展示。访客输入分享者提供的密码后获得一小时浏览器授权；更换密码使旧授权失效，链接不变。分别交付链接和用户指定的密码，避免在不合适的公开渠道泄露；分享二维码只编码链接。HEAD 只能验证密码入口，不能证明授权后的页面运行正常。移除密码会恢复 visibility 对首页展示的控制，应按用户要求执行。

密码保护不能收回已经下载的副本，也不提供同域作品间的浏览器隔离；能力边界和既有同源存储风险仍按[发布前审查](preflight.md)处理。
