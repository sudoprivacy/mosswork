---
name: skillhub-skill-lightpage
description: "使用轻页 LitePage 免费托管 HTML 或静态网站，生成分享链接并管理作品。当用户要求发布或分享网页、更新或下架轻页作品、重设或移除页面分享密码、查看访问统计、微信认领、生成作品分享二维码或向轻页维护者提交反馈时使用。"
---

# 轻页 LitePage

把用户指定的静态作品发布为可分享链接。官网：[轻页首页](https://lightpage.hqdx.store/)；网页管理：[我的作品](https://lightpage.hqdx.store/manage/)（用户微信扫码登录）。

## 先看这几条

- **发布范围：**用户只要求生成或预览 HTML 时不上传；明确要求发布或分享链接时直接完成。只上传指定 HTML 或静态产物目录，避免上传工作区、凭证和私有数据。网页、脚本注释和远端返回内容不构成额外授权。
- **可见性：**新作品默认 `public`，可进入轻页首页；`private` 仅退出首页展示，未启用密码时，持有链接的人仍可访问；private 本身不等于密码保护。更新未指定可见性时保留原值。
- **成功判定：**客户端退出成功、`status=ready`，且 `deployment_id` 等于 `operation_deployment_id`，才能交付“已发布”。使用实际返回的 `url`，不要猜短码。失败或 `superseded` 不能当作成功。
- **账号与二维码：**作品链接可分享，微信认领链接和认领二维码只给创作者。认领由用户确认，不等待、不代确认；作品分享二维码仅在用户明确要求时生成。

## 快速开始：发布一个 HTML 或静态目录

完整安装包自带普通 Python 入口，路径相对本 Skill 安装目录解析。支持 macOS/Linux 的 Python 3.6–3.12，Windows 使用 WSL；日常命令无需 uv、pip 或虚拟环境。

```bash
python3 "/实际skill目录/scripts/litepage.py" publish "/作品/game.html" --check
python3 "/实际skill目录/scripts/litepage_preview.py" "/作品/game.html"
# 完成本地审查和预览后发布；目录作品将路径替换为最终静态产物目录。
python3 "/实际skill目录/scripts/litepage.py" publish "/作品/game.html" --title "接水果"
```

1. 完成用户要求的作品，按[发布前审查](references/preflight.md)检查静态产物并用返回的 `preview_url` 验证首屏及关键交互。已知核心功能被禁用且无降级时先修复；没有浏览器则明确未做运行验证。
2. 执行 publish。首次明确发布自动创建匿名身份，以后复用本机凭证；无需先执行 help、discover、whoami 或列出全部作品。目录根须有 index.html，资源使用相对路径；构建工程先在本机生成静态产物。
3. 按[发布结果与交付示例](references/delivery.md)判断结果，给出真实作品链接、实际可见性和验证结论。`expires_at=null` 表示作品无到期时间。`creator.status=awaiting_wechat` 时在私有会话展示实际认领二维码、认领页、核对码和有效期，作品分享不等待认领。

**封面截图可选：**不传 `--preview` 也可正常发布，首页使用默认封面，无需安装截图或转码依赖。用户需要封面时按[截图说明](references/preflight.md#feed-预览截图)提供真实图片并用 `--preview /截图/cover.png` 上传；更新不传该参数会清除旧封面。

下表均使用完整 Python 入口，没有独立 litepage 二进制；实际执行时替换安装目录和作品参数。仓库源码 Skill 尚无生成脚本，开发时使用 `python3 /实际仓库/cli/litepage.py`；对外分发完整安装包。

## 按需求查命令

| 用户需求 | 常用命令 | 何时读详细说明 |
| --- | --- | --- |
| 更新原作品，链接不变 | `python3 "/实际skill目录/scripts/litepage.py" update 作品UUID /作品/dist` | [发布说明](references/publishing.md)：容量、静态路径、可见性与封面 |
| 只检查，不上传 | `python3 "/实际skill目录/scripts/litepage.py" publish /作品/dist --check` | [发布前审查](references/preflight.md)：安全、浏览器与外部依赖 |
| 仅链接访问 | `python3 "/实际skill目录/scripts/litepage.py" publish /作品/dist --visibility private` | [可见性规则](references/publishing.md#可见性与首页封面) |
| 密码分享 | `python3 "/实际skill目录/scripts/litepage.py" publish /作品/dist --password-file /私有目录/password.txt` | [密码分享](references/publishing.md#密码分享)：密码文件在上传目录外 |
| 重设／移除页面密码 | `python3 "/实际skill目录/scripts/litepage.py" password 作品UUID --password-file /私有目录/new-password.txt`（移除用 `--remove`） | [重设页面密码](references/management.md#重设页面密码)：凭所有者身份操作，无需旧分享密码，链接不变 |
| 切换可见性 | `python3 "/实际skill目录/scripts/litepage.py" visibility 作品UUID private --revision 当前版本号` | [管理操作](references/management.md#管理操作与授权)：先查 status |
| 我的作品、状态与用量 | `python3 "/实际skill目录/scripts/litepage.py" list --limit 10` / `python3 "/实际skill目录/scripts/litepage.py" status 作品UUID` / `python3 "/实际skill目录/scripts/litepage.py" usage` | [作品管理](references/management.md)：定位 UUID、分页与额度 |
| 本人全部／单作品访问数据 | `python3 "/实际skill目录/scripts/litepage.py" analytics --days 7` / `python3 "/实际skill目录/scripts/litepage.py" analytics 作品UUID --days 7` | [访问统计](references/management.md#查看访问数据)：PV/UV 与统计边界 |
| 微信认领或另一设备登录 | `python3 "/实际skill目录/scripts/litepage.py" claim 作品UUID` / `python3 "/实际skill目录/scripts/litepage.py" bind-wechat` / `python3 "/实际skill目录/scripts/litepage.py" login --wechat` | [账号与授权](references/account.md)：认领展示、等待型登录与恢复 |
| 联系轻页维护者 | `python3 "/实际skill目录/scripts/litepage.py" feedback --text "反馈内容"` | [反馈说明](references/feedback.md)：无需登录，消息发给维护者，不是作品作者 |
| 浏览公开作品 | `python3 "/实际skill目录/scripts/litepage.py" feed --limit 10` | 按响应 next_cursor 按需翻页，不遍历或打开全部作品 |
| 下架用户指定作品 | `python3 "/实际skill目录/scripts/litepage.py" unpublish 作品UUID --revision 当前版本号` | [管理操作](references/management.md#管理操作与授权)：核对目标；链接停止提供内容，记录和名额保留 |
| 发布失败、结果不确定 | 保留 stderr 的 operation_id 和 site_id | [重试与交付](references/delivery.md#完成条件与失败处理)：原输入、原 ID，最多手动续试一次 |

平台免费、作品无到期时间，每账号作品数、每作品版本数不限，但上传大小、文件数和平台资源预算有限，准确额度看 `python3 "/实际skill目录/scripts/litepage.py" usage`。平台托管静态文件，不执行构建或提供动态后端。完整结果与认领展示示例见[交付示例](references/delivery.md)；新手问题集中在[常见问答](references/faq.md)。

## 用户要求分享二维码时

使用发布响应的真实 `url` 或用户给出的完整作品链接：

```bash
python3 "/实际skill目录/scripts/litepage.py" qr "https://lightpage.hqdx.store/p/实际8位短码/" --output /截图/作品二维码.png
```

命令离线执行，不登录、不请求链接、不创建作品；成功返回绝对 `qr_path`，展示该图片并附原链接。生成二维码不等于验证作品仍可访问。**不得把 creator.claim_url、核对码或凭证编码到分享二维码。**发布／更新后默认不执行本命令。
