"""LitePage's small, standalone publishing command surface."""

import argparse
import base64
import hashlib
import json
import os
import re
import socket
import sys
import tempfile
import uuid
from pathlib import Path
from urllib.parse import urlparse

from echo_cli import transport
from echo_cli.client import API, APIError, checked
from echo_cli.compat import subparsers, unlink
from echo_cli.credentials import CredentialStore, atomic_json
from echo_cli.litepage_bundle import bundle
from echo_cli.litepage_feedback import submit as submit_feedback
from echo_cli.qr import create_login_qr, png
from echo_cli.skill_version import LITEPAGE_SKILL_VERSION

DEFAULT_SERVER = "https://lightpage.hqdx.store"


def credential_store(server, directory):
    store = CredentialStore(server, directory=directory)
    # The official product moved its API origin, but both hosts use the same
    # hosting devices. Keep the old file (and lock) instead of copying secrets.
    if server == DEFAULT_SERVER and not store.path.exists() and not store.pending_path.exists():
        legacy = CredentialStore("https://echo.hqdx.store", directory=directory)
        if legacy.path.exists():
            return legacy
    return store


class LitePageAPI(API):
    skill_name = "lightpage"
    skill_version = LITEPAGE_SKILL_VERSION

    def request(self, method, path, **kwargs):
        if path in {"/v1/hosting/feed", "/v1/hosting/feedback"}:
            # Browsing and contact never read credentials, refresh or register.
            kwargs.pop("authenticated", None)
            return checked(self.send(method, path, retry=True, **kwargs))
        return super().request(method, path, **kwargs)

    def send(self, method, path, **kwargs):
        if path in {"/v1/hosting/feed", "/v1/hosting/feedback"}:
            kwargs["headers"] = {
                k: v for k, v in kwargs.get("headers", {}).items() if k.lower() != "authorization"
            }
        if path in {"/v1/auth/anonymous", "/v1/auth/connect", "/v1/auth/bind", "/v1/me"}:
            path = path.replace("/v1/", "/v1/hosting/", 1)
        return super().send(method, path, **kwargs)


def parser():
    root = argparse.ArgumentParser(
        prog="litepage", description="轻页 LitePage · 发布静态网页、管理作品与查询访问统计"
    )
    root.add_argument("--server", default=os.getenv("LITEPAGE_SERVER", DEFAULT_SERVER))
    commands = subparsers(root, dest="command")
    for name in ("publish", "update"):
        cmd = commands.add_parser(name)
        if name == "update":
            cmd.add_argument("site_id", type=uuid.UUID)
        cmd.add_argument("source", type=Path)
        cmd.add_argument("--title")
        cmd.add_argument(
            "--password-file",
            type=Path,
            help="UTF-8 file containing a sharing password; never printed",
        )
        cmd.add_argument("--visibility", choices=["public", "private"])
        cmd.add_argument("--description")
        cmd.add_argument("--preview", type=Path, help="Local webpage screenshot (PNG/JPEG/WebP)")
        cmd.add_argument(
            "--operation-id", type=uuid.UUID, help="Reuse this ID after an uncertain result"
        )
        cmd.add_argument(
            "--check", action="store_true", help="Validate locally; no registration or upload"
        )
    qr = commands.add_parser("qr", help="Generate a share-link PNG locally, only on request")
    qr.add_argument("url", help="Exact published work URL")
    qr.add_argument(
        "--output", type=Path, required=True, help="Output PNG; missing directories are created"
    )
    qr.add_argument(
        "--overwrite", action="store_true", help="Replace output after user confirmation"
    )
    status = commands.add_parser("status")
    status.add_argument("site_id", type=uuid.UUID)
    claim = commands.add_parser("claim", help="Get a private creator WeChat claim link")
    claim.add_argument("site_id", type=uuid.UUID)
    listing = commands.add_parser("list")
    listing.add_argument("--limit", type=int, choices=range(1, 51), default=10, metavar="1-50")
    listing.add_argument("--cursor")
    commands.add_parser("usage")
    analytics = commands.add_parser("analytics", help="Read owned works' PV/UV statistics")
    analytics.add_argument("site_id", type=uuid.UUID, nargs="?", help="Omit for all owned works")
    analytics.add_argument("--days", type=int, choices=range(1, 31), default=7, metavar="1-30")
    feed = commands.add_parser("feed")
    feed.add_argument("--limit", type=int, choices=range(1, 21), default=10, metavar="1-20")
    feed.add_argument("--cursor")
    feedback = commands.add_parser("feedback", help="Contact the LitePage maintainer without login")
    message = feedback.add_mutually_exclusive_group(required=True)
    message.add_argument("--text", help="Feedback body, at most 5000 characters")
    message.add_argument("--text-file", type=Path, help="UTF-8 feedback file")
    feedback.add_argument("--work-url", help="Optional related work URL")
    feedback.add_argument("--contact", help="Optional, unverified reply contact")
    feedback.add_argument(
        "--operation-id", type=uuid.UUID, help="Reuse this ID after an uncertain result"
    )
    visibility = commands.add_parser("visibility")
    visibility.add_argument("site_id", type=uuid.UUID)
    visibility.add_argument("value", choices=["public", "private"])
    visibility.add_argument("--revision", type=int, required=True)
    password = commands.add_parser("password", help="Set, change or remove sharing password")
    password.add_argument("site_id", type=uuid.UUID)
    choice = password.add_mutually_exclusive_group(required=True)
    choice.add_argument("--password-file", type=Path)
    choice.add_argument("--remove", action="store_true")
    password.add_argument(
        "--revision", type=int, help="Expected revision; omit to read current site status"
    )
    unpublish = commands.add_parser("unpublish")
    unpublish.add_argument("site_id", type=uuid.UUID)
    unpublish.add_argument("--revision", type=int, required=True)
    login = commands.add_parser("login")
    login.add_argument("--wechat", action="store_true", required=True)
    login.add_argument("--force", action="store_true")
    commands.add_parser("bind-wechat")
    commands.add_parser("logout")
    return root


def share_qr(url, output, overwrite=False):
    """Encode a published work link offline, without identity or API access."""
    target = urlparse(url)
    if (
        target.scheme != "https"
        or not target.hostname
        or target.username
        or target.password
        or target.query
        or target.fragment
        or not re.fullmatch(r"/p/(?:[a-z0-9]{8}|[0-9a-f]{32})/", target.path)
    ):
        raise RuntimeError("Use the exact published HTTPS work URL, not a private claim link")
    path = output.expanduser().absolute()
    if path.suffix.lower() != ".png":
        raise RuntimeError("QR output must be a .png file")
    data = png(url)
    path.parent.mkdir(parents=True, exist_ok=True)
    if overwrite:
        fd, temporary = tempfile.mkstemp(prefix=".share-qr-", suffix=".png", dir=str(path.parent))
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
            os.replace(temporary, str(path))
        finally:
            unlink(Path(temporary))
    else:
        try:
            with path.open("xb") as stream:
                stream.write(data)
        except FileExistsError:
            raise FileExistsError(
                "二维码文件已存在。请询问用户：换文件名还是覆盖？确认覆盖后才添加 --overwrite。"
            ) from None
    return {"url": url, "qr_path": str(path)}


def ensure_identity(api):
    with api.store.lock():
        saved = api.store.load()
    if saved is None:
        api.native_login(socket.gethostname(), mode="anonymous", agent="轻页创作者")
        print("匿名发布：请保留本机凭证；绑定微信后可跨设备恢复作品。", file=sys.stderr)


def claim_handoff(api, creator):
    """Add a private local image without extra API calls or authorization polling."""
    if creator.get("status") != "awaiting_wechat":
        return creator
    uri = creator.get("claim_url", "")
    try:
        if not isinstance(uri, str) or len(uri) > 2048:
            raise ValueError("Invalid claim URL")
        target = urlparse(uri)
        if (
            target.scheme != "https"
            or not target.hostname
            or target.username
            or target.password
            or target.query
            or target.fragment
            or not re.fullmatch(
                r"/connect/(?:[a-z0-9]{10}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})",
                target.path,
            )
        ):
            raise ValueError("Invalid claim URL")
        path = create_login_qr(uri, directory=api.store.path.parent)
    except (OSError, RuntimeError, ValueError):
        # Upload is already complete; a local image failure must not cause re-upload.
        return {**creator, "qr_error": "二维码生成失败，请打开认领页扫码；无需重新发布作品。"}
    return {**creator, "qr_path": str(path.resolve())}


def read_password(path, *, allow_empty=False):
    if path is None:
        return None
    if path.stat().st_size > 1024:
        raise RuntimeError("Password file is too large")
    value = path.read_text(encoding="utf-8").rstrip("\r\n")
    if allow_empty and value == "":
        return None
    if not 4 <= len(value) <= 128 or any(ord(c) < 32 for c in value):
        raise RuntimeError("Password must contain 4–128 characters without control characters")
    return value


def publish(api, args):
    password = read_password(args.password_file)
    if args.password_file and args.source.is_dir():
        try:
            args.password_file.resolve().relative_to(args.source.resolve())
        except ValueError:
            pass
        else:
            raise RuntimeError("Keep the password file outside the uploaded directory")
    if args.description is not None and len(args.description) > 240:
        raise RuntimeError("Description must be at most 240 characters")
    data, summary = bundle(args.source, args.preview)
    options = {
        k: v
        for k, v in {
            "visibility": args.visibility,
            "description": args.description,
            "preview_path": "litepage-preview.webp" if args.preview else None,
        }.items()
        if v is not None
    }
    if args.check:
        return {"status": "checked", **summary}
    if summary["review"]["findings"]:
        print(json.dumps({"event": "prepublish_review", **summary["review"]}), file=sys.stderr)
    ensure_identity(api)
    if options or password is not None:
        features = api.request("GET", "/v1/hosting/usage", authenticated=True).get(
            "publishing_features", []
        )
        required = {"preview" if k == "preview_path" else k for k in options}
        if password is not None:
            required.add("password")
        if not required.issubset(features):
            raise RuntimeError(
                "Server does not support the requested publishing options; no files uploaded"
            )
    source = str(args.source.expanduser().absolute())
    site_arg = str(args.site_id) if args.command == "update" else None
    key = hashlib.sha256(
        json.dumps([api.server, args.command, source, site_arg]).encode()
    ).hexdigest()
    journal = api.store.path.parent / f"publish-{key}.json"
    current = (
        api.request("GET", f"/v1/hosting/sites/{site_arg}", authenticated=True)
        if site_arg
        else None
    )
    with api.store.lock():
        if journal.is_symlink():
            raise RuntimeError("Publish journal must not be a symlink")
        previous = json.loads(journal.read_text()) if journal.exists() else None
        if args.operation_id:
            receipt_path = api.store.path.parent / f"operation-{args.operation_id}.json"
            if receipt_path.is_symlink():
                raise RuntimeError("Operation receipt must not be a symlink")
            previous = json.loads(receipt_path.read_text()) if receipt_path.exists() else None
        elif previous and previous.get("complete"):
            previous = None
        if previous:
            if (
                previous["server"] != api.server
                or previous["sha256"] != summary["sha256"]
                or previous["requested_title"] != args.title
                or previous["source"] != source
                or previous["target"] != site_arg
                or previous.get("options", {}) != options
            ):
                raise RuntimeError(
                    "Pending operation differs; restore the original files/title or explicitly choose a new --operation-id"
                )
            record = previous
        else:
            record = {
                "server": api.server,
                "source": source,
                "target": site_arg,
                "site_id": site_arg or str(uuid.uuid4()),
                "deployment_id": str(args.operation_id or uuid.uuid4()),
                "expected_revision": current["revision"] if current else 0,
                "title": args.title or (current["title"] if current else args.source.stem),
                "requested_title": args.title,
                "options": options,
                "sha256": summary["sha256"],
                "complete": False,
            }
        receipt_path = api.store.path.parent / f"operation-{record['deployment_id']}.json"
        atomic_json(journal, record)
        atomic_json(receipt_path, record)
    print(
        json.dumps(
            {
                "event": "publish_operation",
                "operation_id": record["deployment_id"],
                "site_id": record["site_id"],
            }
        ),
        file=sys.stderr,
    )
    result = api.request(
        "PUT",
        f"/v1/hosting/sites/{record['site_id']}/deployments/{record['deployment_id']}",
        authenticated=True,
        content=data,
        headers={
            "Content-Type": "application/zip",
            **(
                {"X-LitePage-Password": base64.b64encode(password.encode("utf-8")).decode("ascii")}
                if password is not None
                else {}
            ),
        },
        params={
            "title": record["title"],
            "expected_revision": record["expected_revision"],
            **record.get("options", {}),
        },
    )
    if password is not None and not result.get("password_protected"):
        raise RuntimeError("Server did not confirm password protection; do not share the URL")
    if result["status"] == "ready" and result["deployment_id"] == record["deployment_id"]:
        # Fresh unauthenticated connection: never leak platform credentials to uploaded HTML.
        url = urlparse(result["url"])
        if (
            url.scheme != "https"
            or url.username
            or not url.hostname
            or not (
                re.fullmatch(r"/p/[a-z0-9]{8}/", url.path)
                or url.path == f"/p/{uuid.UUID(record['site_id']).hex}/"
            )
            or url.query
            or url.fragment
        ):
            raise RuntimeError("Server returned an invalid content URL")
        try:
            with transport.Client(timeout=15, follow_redirects=False) as visitor:
                response = visitor.head(result["url"])
            if result.get("password_protected"):
                if (
                    response.status_code != 303
                    or response.headers.get("x-litepage-password-protected") != "1"
                ):
                    raise RuntimeError("Password protection was not verified at the public URL")
            elif (
                response.status_code != 200
                or response.headers.get("x-litepage-sha256") != summary["entry_sha256"]
            ):
                raise RuntimeError(
                    "Published files are not yet verified at the public URL; use status or retry this operation ID"
                )
        except transport.TransportError:
            raise RuntimeError(
                "Upload committed but public access could not be verified; retry the same operation ID"
            ) from None
    elif result["deployment_id"] != record["deployment_id"]:
        result["status"] = "superseded"
    record["complete"] = True
    with api.store.lock():
        atomic_json(receipt_path, record)
        atomic_json(journal, record)
    if summary["external_resources"]:
        result["warning"] = (
            "External resources remain external; their availability is not guaranteed by hosting"
        )
    if "creator" in result:
        result["creator"] = claim_handoff(api, result["creator"])
    return result


def execute(api, args):
    if args.command == "feedback":
        return submit_feedback(api, args)
    if args.command == "qr":
        return share_qr(args.url, args.output, args.overwrite)
    if args.command in {"publish", "update"}:
        return publish(api, args)
    if args.command == "feed":
        return api.request(
            "GET",
            "/v1/hosting/feed",
            params={"limit": args.limit, **({"cursor": args.cursor} if args.cursor else {})},
        )
    if args.command == "password":
        password = read_password(args.password_file, allow_empty=True)
        path = f"/v1/hosting/sites/{args.site_id}"
        revision = args.revision
        if revision is None:
            revision = api.request("GET", path, authenticated=True)["revision"]
        return api.request(
            "PUT",
            path + "/password",
            authenticated=True,
            json={"password": password, "expected_revision": revision},
        )
    if args.command == "visibility":
        return api.request(
            "PUT",
            f"/v1/hosting/sites/{args.site_id}/visibility",
            authenticated=True,
            json={"visibility": args.value, "expected_revision": args.revision},
        )
    if args.command == "login":
        return api.native_login(socket.gethostname(), mode="wechat", force=args.force)
    if args.command == "bind-wechat":
        return api.native_login(socket.gethostname(), binding=True)
    if args.command == "logout":
        result = api.request("DELETE", "/v1/hosting/device", authenticated=True)
        with api.store.lock():
            api.store.delete()
        return result
    if args.command == "status":
        return api.request("GET", f"/v1/hosting/sites/{args.site_id}", authenticated=True)
    if args.command == "claim":
        return claim_handoff(
            api, api.request("POST", f"/v1/hosting/sites/{args.site_id}/claim", authenticated=True)
        )
    if args.command == "unpublish":
        return api.request(
            "PUT",
            f"/v1/hosting/sites/{args.site_id}/unpublish",
            authenticated=True,
            json={"expected_revision": args.revision},
        )
    if args.command == "usage":
        return api.request("GET", "/v1/hosting/usage", authenticated=True)
    if args.command == "analytics":
        path = (
            f"/v1/hosting/sites/{args.site_id}/analytics"
            if args.site_id
            else "/v1/hosting/analytics"
        )
        return api.request("GET", path, authenticated=True, params={"days": args.days})
    return api.request(
        "GET",
        "/v1/hosting/sites",
        authenticated=True,
        params={"limit": args.limit, **({"cursor": args.cursor} if args.cursor else {})},
    )


def main():
    args = parser().parse_args()
    server = args.server.rstrip("/")
    origin = urlparse(server)
    if args.command != "qr" and (
        origin.scheme != "https"
        or not origin.hostname
        or origin.username
        or origin.password
        or origin.path
        or origin.query
        or origin.fragment
    ):
        print(
            json.dumps({"error": {"code": "invalid_server", "message": "Use an HTTPS API origin"}}),
            file=sys.stderr,
        )
        raise SystemExit(1)
    api = None
    try:
        if args.command != "qr":
            store = credential_store(server, os.getenv("LITEPAGE_CONFIG_DIR", "~/.config/litepage"))
            api = LitePageAPI(server, store)
        result = execute(api, args)
        print(json.dumps(result, ensure_ascii=False))
    except APIError as exc:
        print(
            json.dumps(
                {"error": exc.error, **({"notice": exc.notice} if exc.notice else {})},
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        raise SystemExit(1) from None
    except (RuntimeError, OSError, ValueError) as exc:
        print(
            json.dumps(
                {"error": {"code": "litepage_error", "message": str(exc)}}, ensure_ascii=False
            ),
            file=sys.stderr,
        )
        raise SystemExit(1) from None
    finally:
        if api:
            api.close()


if __name__ == "__main__":
    main()
