"""Version of this installed skill artifact."""

SKILL_VERSION = '0.6.0'

LITEPAGE_SKILL_VERSION = '0.6.0'
