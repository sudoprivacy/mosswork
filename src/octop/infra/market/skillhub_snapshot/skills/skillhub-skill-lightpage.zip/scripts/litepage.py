#!/usr/bin/env python3

from echo_cli.litepage import main

if __name__ == "__main__":
    main()
