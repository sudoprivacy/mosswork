#!/usr/bin/env python3

from echo_cli.litepage_preview import main

if __name__ == "__main__":
    main()
