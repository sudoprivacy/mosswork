"""Decode bounded optional notices; unknown signals never invalidate the main result."""

import json
import uuid


def decode(value, maximum=2048):
    if not value:
        return None
    try:
        if isinstance(value, dict):
            if len(json.dumps(value, ensure_ascii=True)) > maximum:
                return None
            notice = value
        else:
            if len(value) > maximum:
                return None
            notice = json.loads(value)
        if not isinstance(notice, dict):
            return None
        result = {}
        mail = notice.get("mail")
        if (
            isinstance(mail, dict)
            and type(mail.get("unread")) is int
            and mail["unread"] > 0
            and isinstance(mail.get("revision"), str)
            and len(mail["revision"]) == 64
            and all(c in "0123456789abcdef" for c in mail["revision"])
        ):
            result["mail"] = {"unread": mail["unread"], "revision": mail["revision"]}
        items = notice.get("items")
        if (
            isinstance(items, list)
            and 1 <= len(items) <= 10
            and type(notice.get("has_more")) is bool
            and notice.get("api_path") == "/v1/notices"
        ):
            clean = []
            for item in items:
                if not isinstance(item, dict) or item.get("kind") not in {
                    "direct",
                    "reply",
                    "system",
                    "person_post",
                    "thread_reply",
                }:
                    continue
                try:
                    identifier = str(uuid.UUID(item["id"]))
                except (ValueError, TypeError, KeyError, AttributeError):
                    continue
                prefix = "mail" if item["kind"] in {"direct", "reply", "system"} else "posts"
                if item.get("api_path") != f"/v1/{prefix}/{identifier}":
                    continue
                clean.append({"id": identifier, "kind": item["kind"], "api_path": item["api_path"]})
            if clean:
                result.update(items=clean, has_more=notice["has_more"], api_path="/v1/notices")
        announcements = notice.get("announcements")
        if isinstance(announcements, list) and 1 <= len(announcements) <= 3:
            clean = []
            for item in announcements:
                if (
                    isinstance(item, dict)
                    and isinstance(item.get("id"), str)
                    and 1 <= len(item["id"]) <= 64
                    and all(ord(c) < 128 and (c.isalnum() or c in "_-") for c in item["id"])
                    and isinstance(item.get("message"), str)
                    and 1 <= len(item["message"]) <= 160
                ):
                    clean.append({"id": item["id"], "message": item["message"]})
            if clean:
                result["announcements"] = clean
        update = notice.get("skill_update")
        if isinstance(update, dict):
            version = update.get("latest_version")
            message = update.get("message")
            if (
                update.get("skill") in {"echo", "lightpage"}
                and isinstance(version, str)
                and len(version) <= 32
                and len(version.split(".")) == 3
                and all(
                    part and all(c in "0123456789" for c in part) for part in version.split(".")
                )
                and isinstance(message, str)
                and 1 <= len(message) <= 160
            ):
                result["skill_update"] = {
                    "skill": update["skill"],
                    "latest_version": version,
                    "message": message,
                }
        return result or None
    except (ValueError, TypeError, KeyError, AttributeError):
        return None
