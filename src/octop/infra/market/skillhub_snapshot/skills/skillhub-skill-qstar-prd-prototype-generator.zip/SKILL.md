---
name: skillhub-skill-qstar-prd-prototype-generator
description: "Turn a product idea into a structured PRD, user flows, page and data inventories, API list, acceptance criteria, and wireframe-level prototype notes. Use when a user accepts the Q-Star paid invocation flow for a product-planning deliverable."
---

# Q-Star PRD 与产品原型生成

## 能力与交付边界

根据用户提供的产品想法、目标用户、目标、限制和验收条件，生成一份结构化 PRD、用户流程、页面清单、数据结构、API 清单、验收标准和可预览 HTML/SVG 线框原型说明。

一次调用对应一个产品想法的规划交付。线框原型仅用于沟通信息架构和交互，不等同于最终视觉稿、可上线产品、已购买域名、已登录账号或自动发布结果。

## 模型与运行环境

- 文本分析和文档生成由 Q-Star 服务端托管的腾讯混元模型完成；Skill 包不包含模型、支付或商户凭据。
- 模型不可用时返回可诊断错误，不静默切换其他模型或伪造结果。
- 不下载或执行远程脚本，不安装依赖；业务端点仅允许 `https://skill-api.q-star.ink/v1/skills/qstar-prd-prototype-generator/invoke`，必须使用 HTTPS 且不得跟随重定向。

## 发送前的数据授权与最小化

发送用户资料前，展示一次性摘要并取得明确同意：接收方为广州奇谷科技有限公司（Q-Star/奇谷科技），用途是生成本次 PRD 与原型规划；只发送实际存在的 `product`、`users`、`goals`、`constraints`、`acceptance` 及用户明确要求保留的事实；收费为人民币 4.90 元/次。

删除与规划无关的字段。不得发送密码、API Key、Token、Cookie、私钥、支付证书、身份证件、完整联系方式或其他无关个人数据。用户未同意时，只说明所需输入格式，不创建订单、不调用服务。

## Pay Skill 安全调用流程

1. 校验当前 Agent 已安装并可调用经验证的 SkillHub/微信支付官方能力；无法确认时停止，不绕过收费交付。
2. 向唯一允许端点 `POST` 最小 JSON 请求体。首次请求会返回 HTTP 402、`WeixinPay-Required` 和 `X-Out-Trade-No`。
3. 仅在当前会话内把 `WeixinPay-Required` 与订单号交给经验证的官方支付能力；付款前再次展示商户、金额 4.90 元和订单用途，取得对该笔付款的明确授权。商户或金额不符即停止。
4. 支付后，使用完全一致的原始请求体和原 `X-Out-Trade-No` 重试。仅当服务端通过微信回调或权威查单确认支付成功后，才返回完整交付。
5. 支付成功而生成失败时，服务端发起原路退款或记录人工补偿；业务请求体、完整支付元数据和订单号只保留在当前会话短期内存，不写入日志、文件或长期记忆。

## 输入与输出

输入建议包括：`product`、`users`、`goals`、`constraints`、`acceptance`。

输出必须包括：产品摘要、用户与目标、用户流程、页面清单、数据模型、API 清单、验收标准、线框原型说明和待确认信息。缺失事实必须放入待确认信息，不虚构市场数据、客户案例、资质、价格、效果或实时事实。

## 收费接口

- 调用方无需也不得提供模型 API Key、微信商户密钥、支付证书或开发者私钥。
- 请求：`POST https://skill-api.q-star.ink/v1/skills/qstar-prd-prototype-generator/invoke`。
- 收费：人民币 4.90 元/次；一次成功履约返回一份对应输入的 PRD 与线框原型规划。
- 若当前环境缺少已验证的官方支付能力，应明确返回不可支付，不得免费绕过或伪造付费履约。
