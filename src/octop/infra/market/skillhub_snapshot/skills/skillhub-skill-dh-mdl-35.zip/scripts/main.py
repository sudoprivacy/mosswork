# -*- coding: utf-8 -*-
"""Token统计的优化清单（dh-mdl-35）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：Token统计的优化清单·锚定Settings→Models热生效、Provider ID永久不可改名、write-only凭据存.credentials.yaml、max_tokens=49152档位成品（热生效配置/凭据write-only口径）；成本测算表（按量/缓存/批处理三档）；监控指标与优化清单
建议输入（专业字段）：目标系统；审计范围；授权确认
"""
import json, os, re, sys, time

SLUG = "dh-mdl-35"
TITLE = "Token统计的优化清单"
PRICE_FEN = 1990
CATEGORY = "DSH工程"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['目标系统', True, ['系统', '对象系统', '审计对象'], '明确受审系统与业务承载关系'], ['审计范围', True, ['范围', '边界', '审计边界'], '范围不清的审计结论不具效力'], ['授权确认', True, ['授权', '授权文件', '许可'], '无书面授权不得展开任何探测动作'], ['版本/环境', False, ['版本', '环境', '配置版本'], '记录版本以便复现与比对'], ['配置样本', False, ['配置', '配置片段', '样本'], '基线核对的实际依据'], ['已知问题', False, ['已知缺陷', '历史问题'], '复测时需逐项确认状态']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'finds': [['管理接口对公网开放', '高', '外网可达的管理端口，缺少来源限制', '管理面暴露，凭据泄露即可被控制', '限制来源 IP 或改走内网/跳板访问'], ['TLS 允许弱协议与弱套件', '中', '协商可回落至低版本协议', '传输数据存在被降级风险', '禁用低版本协议与弱算法，仅保留现代套件'], ['特权账号未启用多因素认证', '高', '关键账号仅口令认证', '口令泄露即等同于系统失陷', '对特权账号强制多因素认证'], ['审计日志留存不足', '中', '关键操作日志未集中收集', '事件发生后无法回溯', '集中采集并满足留存期限要求'], ['镜像基础版本存在已知高危漏洞', '严重', '基础镜像版本落后多个补丁周期', '可被已知漏洞直接利用', '升级基础镜像并重建工作负载'], ['备份未做过恢复演练', '中', '仅有备份任务记录，无恢复验证', '真实故障时无法确认可恢复', '每季度做一次恢复演练并留档']]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['环境硬约束：Node ≥22.19 或 ≥24（package.json engines 写死）；Python SDK 需 Python 3.10+（Linux x64/arm64 或 macOS 14+ arm64）', '三路部署：npx @deepseek-ai/dsh web（127.0.0.1:3080）/ dsh --profile headless / 源码 pnpm install + pnpm run build', 'Cordis 插件内核「一切皆插件」：dsh-base 配置共 78 行，agent-loop 为第 76 行插件配置，可整行替换；dsh --profile web --dump-config 查看挂载', '四运行时模式：Standard（完整工具集）/ Code（SDK 编排）/ Minimal（双工具基准）/ Creator（运行时检查，仅开发环境）', '沙箱三档：read-only / workspace-write（默认）/ danger-full-access（仅限可丢弃环境）；后端 Linux 用 bwrap/Landlock、macOS 用 Seatbelt、Windows 用 ACL 受限令牌', '审批 fail-closed：结果封闭集合 allowed-once/rejected/cancelled/unavailable；审批方缺失即 unavailable；Headless/CI never 策略确定性 rejected', '会话工程：append-only 会话日志记录每次上下文注入；Trajectory 支持 resume/fork/replay；session_id 复用保留 Bash 进程与工作目录，独立任务用新 ID', '凭据安全：API Key write-only 存 $DSH_HOME/.credentials.yaml，界面仅显示脱敏描述符；Provider ID 创建后永久不可改名', '模型接入：Settings→Models 热生效无需重启；自定义提供方接受任意 OpenAI 兼容端点；max_tokens 档位 49152', '遥测默认仅本地，显式设 FULL 或 FEEDBACK_ONLY 才上传', '0.1.0-rc 开发者预览：官方明示存在破坏性变更（THERE WILL BE COMPATIBILITY-BREAKING CHANGES），升级须评估回归', '已知问题：Bash 空循环 bug（手动中断重发）、空闲会话内存占用偏高（预留余量）', '企业层口径（MOVO）：身份SSO/知识隔离/RAG/Token统计/审计日志/私有化部署（Docker），数据不出内网']
# 自检项（输入完备度）
CHECKS = [['Token统计的优化·版本与环境核查', ['Token统计的优化', 'Settings'], '先核对Node≥22.19、dsh版本与工作区状态'], ['Token统计的优化·配置与沙箱', ['Settings', 'Models'], '核对沙箱档位、审批策略与凭据管理的最小权限'], ['Token统计的优化·会话与留痕', ['Token统计的优化', '锚定→热生效'], 'session_id策略与append-only日志留痕明确'], ['Token统计的优化·验证与回滚', ['Models', 'Provider'], '给出验证命令、通过判据与回滚条件'], ['Token统计的优化·诚信红线', ['明文密钥', '全权限上生产'], '不得明文写密钥或建议全权限上生产，命中即终止']]
# 交付物构成
DELIVERABLES = ['Token统计的优化清单·锚定Settings→Models热生效、Provider ID永久不可改名、write-only凭据存.credentials.yaml、max_tokens=49152档位成品（热生效配置/凭据write-only口径）', '成本测算表（按量/缓存/批处理三档）', '监控指标与优化清单']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """技术审计交付物：范围授权 → 资产与基线 → 发现清单 → 优先级与验证 → 加固建议 → 复测"""
    P = ctx["spec"]["params"]; L = []
    sysname = ctx["fv"]("目标系统") or ctx["spec"]["title"]
    scope = ctx["fv"]("审计范围")
    auth = ctx["fv"]("授权确认")
    ver = ctx["fv"]("版本/环境")
    sample = ctx["fv"]("配置样本")
    known = ctx["fv"]("已知问题")
    finds = P.get("finds") or []         # [[发现, 严重度, 证据要点, 影响, 修复动作], ...]
    sev = {"严重": 0, "高": 0, "中": 0, "低": 0}
    for f in finds:
        if f[1] in sev:
            sev[f[1]] += 1

    L.append(("一、审计范围与授权确认", [
        "- 目标系统：%s" % brief(sysname, 50),
        "- 版本/环境：%s" % (brief(ver, 40) or "（未提供，须记录版本以便复现）"),
        "- 审计范围：%s" % (brief(scope, 60) or "（未提供，未界定范围的审计结论不具效力）"),
        "- 授权确认：%s" % (brief(auth, 40) or "（未提供，须先取得书面授权；无授权不展开任何探测动作）"),
        "",
        "> 审计只覆盖上述授权范围内的资产；范围外系统不在本次结论之内。",
    ]))

    _bl = [
        "| 核对项 | 基线要求 | 本次情况 | 结论 |", "|---|---|---|---|",
        "| 身份与权限 | 最小权限、特权账号受控、无共享账号 | %s | 待核实 |" % (brief(sample, 24) or "待补充"),
        "| 网络暴露面 | 仅开放必要端口，管理口不对外 | 待核实 | 待核实 |",
        "| 传输与存储加密 | 传输启用强套件，静态数据加密 | 待核实 | 待核实 |",
        "| 日志与留存 | 关键操作可审计、留存满足要求 | 待核实 | 待核实 |",
        "| 补丁与版本 | 无已知高危未修复版本 | %s | 待核实 |" % (brief(ver, 20) or "待补充"),
        "| 备份与恢复 | 定期备份并有恢复演练记录 | 待核实 | 待核实 |",
    ]
    if P.get("tools"):
        _bl += ["", "**只读核查命令示例**（请在授权环境执行，不改变系统状态）：", "", P["tools"]]
    L.append(("二、资产与配置基线核对", _bl))

    rows = ["| 编号 | 发现 | 严重度 | 证据要点 | 影响 | 修复动作 |", "|---|---|---|---|---|---|"]
    for i, f in enumerate(finds, 1):
        rows.append("| F%02d | %s | %s | %s | %s | %s |" % (i, f[0], f[1], f[2], f[3], f[4]))
    if not finds:
        rows.append("| F01 | 待按核对项展开 | 高 | 需提供配置样本与版本信息 | 无法评估 | 补充输入后重跑 |")
    L.append(("三、发现清单", rows))

    pri = ["| 优先级 | 范围 | 处理时限 | 验证方式 |", "|---|---|---|---|"]
    if sev["严重"]:
        pri.append("| P0 | 严重 %d 项 | 立即 | 修复后复测并留存证据 |" % sev["严重"])
    if sev["高"]:
        pri.append("| P1 | 高 %d 项 | 7 天内 | 复测 + 配置基线比对 |" % sev["高"])
    if sev["中"]:
        pri.append("| P2 | 中 %d 项 | 30 天内 | 抽样复核 |" % sev["中"])
    if sev["低"]:
        pri.append("| P3 | 低 %d 项 | 纳入版本迭代 | 例行巡检 |" % sev["低"])
    if len(pri) == 2:
        pri.append("| P1 | 待定级 | 补充证据后定级 | 复测 |")
    pri.append("| — | 排序依据 | 严重度 × 可达性（CVSS 基础分结合网络可达路径），可达性高的先修 | — |")
    L.append(("四、修复优先级与验证", pri))

    L.append(("五、加固建议", [
        "| 层面 | 建议动作 | 校验方式 |", "|---|---|---|",
        "| 访问控制 | 收敛权限至最小必要，特权操作双人复核并留痕 | 权限清单与实际比对 |",
        "| 网络 | 默认拒绝入站，仅放行必要端口；管理面隔离 | 策略与实测端口比对 |",
        "| 传输/存储 | 启用强加密套件，禁用弱协议与弱算法 | 扫描器与手工验证 |",
        "| 审计 | 关键操作日志集中收集，留存满足要求 | 抽样回溯一条操作链 |",
        "| 补丁 | 建立高危补丁 SLA（如 7 天内） | 版本台账与实际情况比对 |",
        "| 备份 | 定期恢复演练并留档 | 演练记录 |",
    ]))

    L.append(("六、复测与回归", [
        "- 复测范围：全部 P0/P1 项 + 受影响配置项回归。",
        "- 复测方式：同一工具与同一判定标准，出具前后对比证据。",
        "- 回归风险：加固可能影响业务，须在变更窗口执行并准备回滚步骤。",
        "- 已知问题（%s）应在复测时逐项确认状态。" % (brief(known, 40) or "未提供"),
        "",
        "> 本报告仅在授权范围内有效；修复与加固须在变更窗口内执行并留存前后对比证据，未获授权不得对生产系统实施变更或开展漏洞利用验证。",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
