# AgentKey Tool Reference

Use this reference after the skill triggers. AgentKey ecommerce endpoints can differ by marketplace; call `describe_tool` before `execute_tool` and follow the returned `execute_as` template.

## Marketplace Search

- `taobao/search-item-list_v1`
  - Purpose: Taobao/Tmall product search.
  - Known cost: 4.4 credits.
  - Required param: `keyword`.
  - Useful params: `page`, `sort`, `startPrice`, `endPrice`, `tmall`.

- `jd/search-item-list_v1`
  - Purpose: JD product search.
  - Known cost: 4.4 credits.
  - Required param: `keyword`.
  - Useful param: `page`.

- `amazon/search-products_v1`
  - Purpose: Amazon product search.
  - Known cost: 4.4 credits.
  - Required param: `keyword`.
  - Useful params: `country`, `page`, `sortBy`, `productCondition`, `isPrime`, `dealsAndDiscounts`.

- `1688/search-item-list_v1`
  - Purpose: wholesale/source price discovery.
  - Run `describe_tool` first.

- `douyin-ec/search-item-list_v1`
  - Purpose: Douyin ecommerce product search.
  - Run `describe_tool` first.

- `tiktok-shop/search-products_v1`
  - Purpose: TikTok Shop product search.
  - Run `describe_tool` first.

- `dewu/search-item-list_v1`, `xianyu/search-item-list_v1`
  - Purpose: vertical marketplace or second-hand comparison.
  - Run `describe_tool` first.

## Details, SKU, Reviews

Use marketplace-specific detail endpoints only for shortlisted candidates:

- `taobao/get-item-detail_*`, `taobao/get-item-comment_v3`
- `jd/get-item-detail_*`, `jd/get-item-comments_*`
- `amazon/get-product-detail_v1`, `amazon/get-product-top-reviews_v1`
- `douyin-ec/get-item-detail_v2`, `douyin-ec/get-item-sku-info_v1`, `douyin-ec/get-item-comments_v1`
- `tiktok-shop/get-product-detail_*`

Always verify params with `describe_tool`; many detail endpoints require marketplace-specific item IDs.

## Cost Plans

Quick compare: two marketplaces, one search call each, no detail calls.

Standard compare: 3-4 marketplace searches plus detail calls for top 3 candidates. Ask for confirmation first.

Deep compare: standard compare plus reviews, coupons, SKU, and second-hand/wholesale sources. Use only for high-value purchases or sourcing decisions.
