---
AIGC:
 ContentProducer: '001191110102MAD55U9H0F10002'
 ContentPropagator: '001191110102MAD55U9H0F10002'
 Label: '1'
---

# 律师助手 · 双轨授权协议（开源授权 ＋ 品牌保护）

**版权所有 © 刘士强（七邻八舍）。保留一切权利。**

本《双轨授权协议》（以下简称“本协议”）规范您对“律师助手”技能包（以下简称“本软件”，含程序脚本、技能文件、文档、模板、素材及一切附属资源）之使用与再分发。本软件采用**代码与内容分轨授权**：您下载、安装或使用本软件，即视为已阅读、理解并同意受本协议约束。

## 一、双轨授权总览

| 组成部分 | 范围 | 授权方式 |
|:---|:---|:---|
| **代码部分** | `scripts/` 下全部 Python 脚本 | **Apache License 2.0**（可商用、可修改、可再分发，须保留版权声明） |
| **内容部分** | 技能文件（`agents/`）、参考材料（`references/`）、模板（`templates/`）、说明书（`SKILL.md`、`README.md`、`FAQ.md`、`CHANGELOG.md`）及本软件全部文档 | **知识共享署名－非商业性使用－相同方式共享 4.0 国际（CC BY-NC-SA 4.0）** |
| **增值服务** | 授权人另行提供的深度引擎、开放接口（API）、托管服务、定制化部署及商业支持 | **保留权利**（不随本软件开源，须另行授权） |

## 二、代码部分授权（Apache License 2.0）

`scripts/` 目录下全部源代码按 **Apache License 2.0** 授权，允许复制、修改、分发及商业化使用，条件为：保留原始版权声明与本协议引用；修改后的版本须注明变更；不利用授权人名义作背书。Apache 2.0 全文见 <https://www.apache.org/licenses/LICENSE-2.0>，本协议引用其条款为组成部分。

## 三、内容部分授权（CC BY-NC-SA 4.0）

内容部分按 **知识共享署名－非商业性使用－相同方式共享 4.0 国际** 授权，您可复制、修改、再分发，条件为：

1. **署名（BY）**：注明原作者“刘士强（七邻八舍）”，并附本协议链接；
2. **非商业性使用（NC）**：不得将内容部分或其衍生作品用于商业目的——商业使用（含收费分发、内嵌商业产品、广告引流变现）须另行取得授权人书面许可；
3. **相同方式共享（SA）**：基于内容部分的衍生作品须以相同授权方式发布。

CC BY-NC-SA 4.0 全文见 <https://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh>，本协议引用其条款为组成部分。

## 四、品牌标识保护（强制条款，任何部分均适用）

1. **“律师助手”“Lawyer Assistant”“七邻八舍”“Qilinbashe”** 及相关名称、标识（含能力导航目录样式、视觉形象）之商标权归授权人所有，本协议不授予任何商标许可。
2. 任何复制、修改或再分发（无论代码部分还是内容部分），**不得使用上述品牌标识或近似标识**，不得暗示与授权人存在关联、支持、保证或背书。
3. 衍生作品须以**独立名称**发布，并显著标注“基于律师助手（刘士强、七邻八舍）修改，非原版”。
4. 平台分发（如 SkillHub）若允许修改与再分发，须同时满足：标注与原版的差异、不使用原版名称与标识、不暗示授权人背书、修改版按“现状”提供且授权人不承担责任。
5. **条款性质说明（v8.14.4 补）**：本条为商标与品牌使用限制，**独立于版权许可**，不构成对 Apache-2.0 第 4 条（再分发义务）与第 6 条（商标许可）的额外限制；删除本条品牌标识后，代码部分仍可依 Apache-2.0 自由再分发。

## 五、增值服务保留权利

本协议授权的仅为本软件本身。授权人**保留**以下权利，未经另行书面授权不得行使：

1. 深度分析引擎、进阶能力组件及任何收费功能的开发与提供；
2. 开放接口（API）、云服务、托管实例及数据服务的商业化运营；
3. 面向企业与机构的定制化部署、培训与技术支持；
4. 以本软件为基础的其他商业模式（OpenCore：开源核心＋增值服务）。

## 六、署名与声明

1. 任何合法的使用与再分发须保留本软件内全部版权声明、本协议文本及免责声明，不得移除、遮蔽或更改。
2. 作者署名统一为：**刘士强（七邻八舍）／ Liu Shiqiang (Qilinbashe)**。

## 七、免责声明与责任限制

1. 本软件按“现状”提供，不作任何明示或默示之担保，包括但不限于适销性、特定用途适用性及不侵权担保。
2. 本软件所生成之内容**不构成正式法律意见**；重大或涉诉事务须咨询执业律师。因使用本软件产生之一切直接或间接损失，授权人不承担责任。
3. 在任何情况下，授权人或版权所有者不对任何人因使用本软件引发之任何损失承担责任，不论因何种原因导致或基于何种法律理论。

## 八、其他

1. 本协议以中、英文双语表述，具有同等法律效力；如存在冲突，以中文版为准。
2. 授权人保留随时修改本协议之权利；修改后的协议自发布之日起生效。
3. 本协议未尽事宜，适用《中华人民共和国著作权法》《计算机软件保护条例》《反不正当竞争法》及知识共享、Apache 许可之相应规定。

---

## Lawyer Assistant · Dual License Agreement (Open Source + Brand Protection)

**Copyright © Liu Shiqiang (Qilinbashe). All rights reserved.**

This Dual License Agreement (this “Agreement”) governs your use and redistribution of the “Lawyer Assistant” skill package (the “Software”, including scripts, skill files, documentation, templates and all accompanying resources). The Software is licensed on a **component-based dual-track basis**. By downloading, installing, or using the Software, you acknowledge that you have read, understood, and agree to be bound by this Agreement.

### 1. Dual License Overview

| Component | Scope | License |
|:---|:---|:---|
| **Code** | All Python scripts under `scripts/` | **Apache License 2.0** (commercial use, modification and redistribution permitted, copyright notice must be retained) |
| **Content** | Skill files (`agents/`), references (`references/`), templates (`templates/`), manuals (`SKILL.md`, `README.md`, `FAQ.md`, `CHANGELOG.md`) and all documentation | **CC BY-NC-SA 4.0** (Attribution – NonCommercial – ShareAlike) |
| **Value-added services** | Deep analysis engines, APIs, hosted services, custom deployment and commercial support offered separately by the Licensor | **All rights reserved** (not open-sourced under this Agreement; separate authorization required) |

### 2. Code License (Apache License 2.0)

All source code under `scripts/` is licensed under the **Apache License 2.0**, permitting copy, modification, distribution and commercial use, provided that the original copyright notice and a reference to this Agreement are retained; modifications are marked as changed; and no endorsement by the Licensor is implied. Full text: <https://www.apache.org/licenses/LICENSE-2.0>, incorporated by reference.

### 3. Content License (CC BY-NC-SA 4.0)

The Content is licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International**, permitting copy, modification and redistribution subject to:

1. **Attribution (BY)**: credit the original author “Liu Shiqiang (Qilinbashe)” and link to this Agreement;
2. **NonCommercial (NC)**: no commercial use of the Content or derivative works — commercial use (including paid distribution, embedding in commercial products, ad-driven monetization) requires separate written permission;
3. **ShareAlike (SA)**: derivative works based on the Content must be released under the same license.

Full text: <https://creativecommons.org/licenses/by-nc-sa/4.0/>, incorporated by reference.

### 4. Brand Protection (mandatory, applies to all components)

1. The names and marks **“Lawyer Assistant”, “Qilinbashe”** and related logos (including the panorama visual style) are owned by the Licensor. No trademark license is granted under this Agreement.
2. Any copy, modification or redistribution (whether of the Code or the Content) **must not use the above brand marks or similar marks**, nor imply any affiliation, support, warranty or endorsement by the Licensor.
3. Derivative works must be published under a **distinct name**, prominently marked as “modified from Lawyer Assistant (Liu Shiqiang / Qilinbashe), not the original”.
4. Platform distribution (e.g., SkillHub) permitting modification and redistribution is subject to: marking differences from the original, not using the original name or marks, not implying endorsement, and providing the modified version “as is” with the Licensor assuming no liability.

### 5. Reserved Value-Added Services

This Agreement licenses the Software itself only. The Licensor **reserves** the following rights, exercisable only under separate written authorization:

1. development and provision of deep analysis engines, advanced capability components and any paid features;
2. commercial operation of APIs, cloud services, hosted instances and data services;
3. custom deployment, training and technical support for enterprises and institutions;
4. other business models based on the Software (OpenCore: open-source core plus value-added services).

### 6. Attribution and Notices

1. Any lawful use and redistribution must retain all copyright notices, this Agreement and the disclaimers contained in the Software; they may not be removed, obscured or altered.
2. The author is uniformly credited as: **刘士强（七邻八舍）／ Liu Shiqiang (Qilinbashe)**.

### 7. Disclaimer and Limitation of Liability

1. The Software is provided “as is”, without any express or implied warranty, including but not limited to warranties of merchantability, fitness for a particular purpose, and non-infringement.
2. Content generated by the Software **does not constitute formal legal advice**; for material or litigated matters, consult a practicing lawyer. The Licensor shall not be liable for any direct or indirect loss arising from the use of the Software.
3. In no event shall the Licensor or copyright owner be liable to any person for any loss arising from the use of the Software, under any theory of liability.

### 8. Miscellaneous

1. This Agreement is written in both Chinese and English, equally authentic; in case of conflict, the Chinese version prevails.
2. The Licensor reserves the right to amend this Agreement at any time; amendments take effect upon publication.
3. Matters not covered by this Agreement are governed by the Copyright Law of the People's Republic of China, the Regulations on Computer Software Protection, the Anti-Unfair Competition Law, and the applicable provisions of the Creative Commons and Apache licenses.

> AI生成
