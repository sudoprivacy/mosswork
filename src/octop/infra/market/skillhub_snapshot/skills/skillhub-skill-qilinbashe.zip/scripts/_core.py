# -*- coding: utf-8 -*-
"""checks 子包 —— doctor.py 自检共享核心（v8.10.8 P3 拆分）。

本模块集中 doctor.py 自检期与体检期共用的最小共享集：
  - 路径常量（PKG_ROOT/HERE/SCRIPTS_DIR）与依赖清单常量；
  - results/record/check_file（体检结果收集）；
  - read/read_tc（包内相对路径读取）；
  - 单一事实源文档渲染（sync_docs_main 及 _RENDER_TARGETS）；
  - walk_md 与 mask_* 脱敏纯字符串工具；
  - SelfCheck：自检断言计数器（替代 selfcheck_main 内的闭包 check）。

约束：本模块位于 scripts/ 本层（v8.13.14 起由 scripts/checks/ 拍平上提）——REG-072c 用 os.listdir(scripts) 非递归数
.py，子目录新增文件不改变“工具脚本数”断言；同时随 rebuild_zip 打包进提交包。
"""
import io
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))          # v8.13.14 前为 scripts/checks
SCRIPTS_DIR = HERE                                         # scripts（拍平后同级）
PKG_ROOT = os.path.dirname(SCRIPTS_DIR)                    # 技能包根目录

# 红队测试集总量源码端真值（REG-052 裸环境交叉验证用，v7.3.2a）
_RT_TOTAL_EXPECTED = 71
# 回归检查项源码端真值（REG-052b 裸环境交叉验证用）
_REG_CHECKS_EXPECTED = 15

# 核心依赖：文字咨询等核心功能零依赖，不再要求任何 pip 包（v4.4.2）
CORE_DEPS = []
# 可选依赖：缺失触发对应格式降级（退出码 2）
OPT_DEPS = [
    ("docx", "Word/docx 导出（python-docx）"),
    ("openai", "AI 接口调用（multimodal_ingest.py 视觉复核 VLM 用）"),
    ("easyocr", "图片、扫描件 OCR"),
    ("fitz", "PDF 文字层（PyMuPDF）"),
    ("pdfplumber", "PDF 文字层（备选）"),
    ("PyPDF2", "PDF 页级处理（备选，multimodal_ingest）"),
    ("whisper", "语音转写（openai-whisper）"),
    ("faster_whisper", "语音转写（faster-whisper，装机主路）"),
    ("ffmpeg", "视频抽音轨 / 音频转码（命令行）"),
    ("pptx", "PPT 解析"),
    ("openpyxl", "Excel 解析"),
    ("xlrd", "旧版 Excel .xls 解析"),
    ("docx2txt", "Word 解析（备选）"),
    ("bs4", "HTML 正文抽取"),
    ("PIL", "图片基础处理"),
    ("pillow_heif", "HEIC/HEIF 图片解码（转 PNG 后 OCR）"),
]
INSTALL_COMMANDS = [
    "python scripts/install_deps.py --word",
    "python scripts/install_deps.py --pdf",
    "python scripts/install_deps.py --ocr",
    "python scripts/install_deps.py --audio",
    "python scripts/install_deps.py --office",
    "python scripts/install_deps.py --all",
]

results = []  # (类别, 名称, 状态: OK|降级|FAIL, 说明)


def record(cat, name, status, note):
    results.append((cat, name, status, note))


def check_file(path, cat, name):
    if os.path.isfile(path):
        record(cat, name, "OK", path)
        return True
    record(cat, name, "FAIL", "缺失: %s" % path)
    return False


# ===== v4.10.2 评测复测：可执行验证（原 verify_selfcheck.py，合并入 doctor） =====
BS = chr(92)          # 反斜杠
S = BS + "s"          # \\s（版本号解析用）
Q = chr(34)           # 双引号


def read(rel):
    p = os.path.join(PKG_ROOT, rel)
    try:
        with io.open(p, encoding="utf-8") as f:
            return f.read()
    except (OSError, UnicodeDecodeError):
        return ""


def read_tc():
    """红队、回归测试集读取（v8.0.0 收尾修正：仅读包内，zip 自足）。

    历史：v4.16.0 红队样本外置铁律起，包内缺失时回退读 ~/.workbuddy/.../testcases.yaml。
    v8.0.0 收尾修正（P0-1 发布阻断）拆除该回退：包内无 testcases.yaml 即返回空
    （自检侧源码另有 testcases 目录，源码端行为不变）；裸环境断言数固定为与隔离环境一致。
    """
    pkg = read("testcases/testcases.yaml")
    if pkg:
        return pkg, "提交包内"
    return "", ""


# ---- 单一事实源文档渲染（v7.4.0 新增）----
# 根因：红队总量、回归项数等数字散落 SKILL.md / README.md / 自检证明 / 复验集多处，
# 手工维护必漏。v7.4.0 起这些“事实数字”由本函数从 testcases/testcases.yaml 计算真值后
# 直接渲染进文档，文档数字与测试集实物永不脱节。
# 维护规则：改 testcases.yaml 用例后运行 python scripts/doctor.py --sync-docs 即可全量对齐。
_RENDER_TARGETS = (
    ("SKILL.md", r"(红队安全测试\s*13\s*类\s*)\d+(\s*用例)", r"\g<1>%d\g<2>"),
    ("README.md", r"(红队安全测试集（13类[×x])\d+(条）)", r"\g<1>%d\g<2>"),
    ("references/自检证明与测试摘要.md", r"(红队安全测试集摘要（13类 × )\d+(条)", r"\g<1>%d\g<2>"),
    ("references/红队最小可复验集.md", r"(源码端完整测试集[^\n]*?13\s*类\s*[×x]\s*)\d+(\s*条)", r"\g<1>%d\g<2>"),
    ("references/红队最小可复验集.md", r"(testcases\.yaml`\s*13\s*类\s*)\d+(\s*条)", r"\g<1>%d\g<2>"),
    ("scripts/case_gate.py", r"(经\s*)\d+(\s*条红队用例验证)", r"\g<1>%d\g<2>"),
    # v7.5.0 同版本复核新增：FAQ 问数以 FAQ.md 实测唯一 Q 编号为准（防“手抄 30 问”漂移）
    ("SKILL.md", r"(FAQ\s*)\d+(\s*问)", r"\g<1>%d\g<2>"),
    ("README.md", r"(FAQ\s*)\d+(\s*问)", r"\g<1>%d\g<2>"),
    # v7.6.0 同版本补充修正新增：CHANGELOG 归档说明计数（版本标题总数，防“16 个版本块”手抄漂移）
    # v8.10.19：改为与实测文本同构（非捕获数字组），上界/总数/补充块数三值由 _changelog_archive_truth 渲染
    ("CHANGELOG.md", r"(本文件现保留 v[\d.]+ 起的版本条目（现存 v[\d.]+ ~ v)(?:\d+\.\d+\.\d+)( 共 )(?:\d+)( 个版本标题，其中同版本补充修正块 )(?:\d+)( 个）)",
     r"\g<1>%s\g<2>%d\g<3>%d\g<4>"),
)


def _faq_question_count():
    """FAQ.md 唯一 Q 编号计数（Q1~Q32 连续编号，唯一去重后即问题总数）。"""
    faq = read("FAQ.md")
    if not faq:
        return 0
    return len(set(re.findall(r"Q(\d+)", faq)))


def _changelog_archive_truth():
    """CHANGELOG 归档说明计数真值（v7.6.0 同版本补充修正新增）。
    返回 (上界版本字符串, 版本标题总数, 同版本补充修正块数)。"""
    cl = read("CHANGELOG.md")
    if not cl:
        return "", 0, 0
    # v8.10.19：改认 ## V／### v 两级标题（原仅认三级小写 v，致 v8.10.16/17/18 大写标题成守卫盲区）
    heads = re.findall(r"(?m)^#{2,3}\s*([vV]\d+\.\d+\.\d+[^\n]*)", cl)
    total = len(heads)
    supp = len(re.findall(r"(?m)^#{2,3}\s*[^\n]*同版本补充修正块", cl))
    main_heads = [h for h in heads if "同版本补充修正" not in h]
    m = re.match(r"[vV](\d+\.\d+\.\d+)", main_heads[0]) if main_heads else None
    return (("v" + m.group(1)) if m else ""), total, supp


def sync_docs_main():
    """--sync-docs：从 testcases.yaml 计算红队总量、回归项数，渲染文档数字段（单一事实源）。"""
    tc_text, tc_src = read_tc()
    if not tc_text:
        print("[FAIL] 未找到 testcases/testcases.yaml（提交包内与自检侧源码均缺失），无法计算真值")
        return 1
    try:
        import yaml
    except ImportError:
        print("[FAIL] 缺 PyYAML（--sync-docs 需解析 testcases.yaml）："
              "pip install pyyaml 或 python scripts/install_deps.py --all 安装后重试")
        return 1
    tc = yaml.safe_load(tc_text)
    n_cats = len((tc or {}).get("categories", []))
    n_cases = sum(len(cat.get("cases", [])) for cat in (tc or {}).get("categories", []))
    n_checks = len((tc or {}).get("checks", []))
    print("真值来源：%s → 红队 %d 类 %d 条 / 回归 %d 项 / FAQ %d 问 / CHANGELOG 归档计数 %s" % (
        tc_src, n_cats, n_cases, n_checks, _faq_question_count(),
        "/".join(str(x) for x in _changelog_archive_truth()) if _changelog_archive_truth()[0] else "缺失"))

    changed = []
    for rel, pattern, repl in _RENDER_TARGETS:
        p = os.path.join(PKG_ROOT, rel)
        if not os.path.isfile(p):
            continue
        t = io.open(p, encoding="utf-8").read()
        # FAQ 渲染目标用 FAQ 实测问数，CHANGELOG 归档计数用实测真值，其余用红队用例总量
        if "FAQ" in pattern:
            val = _faq_question_count()
        elif "版本标题" in pattern:
            _up, _tot, _sup = _changelog_archive_truth()
            val = (_up.lstrip("v"), _tot, _sup) if _up else None
        else:
            val = n_cases
        if val is None:
            continue
        nt, n = re.subn(pattern, repl % val, t)
        if n and nt != t:
            with io.open(p, "w", encoding="utf-8", newline="\n") as f:
                f.write(nt)
            changed.append("%s:%d处" % (rel, n))
    if changed:
        print("已渲染：%s" % "；".join(changed))
    else:
        print("（未找到可渲染数字段，或已是当前值）")
    return 0


def walk_md(rel_dir):
    """递归收集 md 文件相对路径（os.walk，含子目录），排除自检侧文档"""
    base = os.path.join(PKG_ROOT, rel_dir)
    out = []
    if not os.path.isdir(base):
        return out
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d not in (".git", "__pycache__")]
        for fn in files:
            if fn.endswith(".md"):
                out.append(os.path.relpath(os.path.join(root, fn), PKG_ROOT).replace(os.sep, "/"))
    SKIP = {"references/审核口径决策台账.md"}
    return [r for r in out if r not in SKIP]


def mask_digit_run(text, min_len, repl):
    """连续数字段达到 min_len 位即整体替换（纯字符串，无正则）"""
    out = []
    i, n = 0, len(text)
    while i < n:
        if text[i].isdigit():
            j = i
            while j < n and text[j].isdigit():
                j += 1
            out.append(repl if (j - i) >= min_len else text[i:j])
            i = j
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def mask_amount(text):
    """数字后紧跟'万' → 金额[范围]（纯字符串）"""
    out = []
    i, n = 0, len(text)
    while i < n:
        if text[i].isdigit():
            j = i
            while j < n and text[j].isdigit():
                j += 1
            if j < n and text[j] == "万":
                out.append("金额[范围]")
                i = j + 1
            else:
                out.append(text[i:j])
                i = j
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def mask_case_no(text):
    """案号（20xx）...数字...号 → 案号[脱敏]（纯字符串）"""
    marker = "（20"
    i = text.find(marker)
    if i < 0:
        return text
    j = text.find("号", i)
    if j < 0:
        return text
    return text[:i] + "案号[脱敏]" + text[j + 1:]


def mask_pii(text):
    """状态卡生成规则级脱敏（结构化PII：身份证、手机号、案号、金额）。
    注：姓名、住址等非结构化PII 由 LLM 层规则处理（见 references/自检证明与测试摘要.md 第七章）。"""
    t = mask_digit_run(text, 18, "****")
    t = mask_digit_run(t, 11, "****")
    t = mask_case_no(t)
    t = mask_amount(t)
    return t


class SelfCheck(object):
    """自检断言计数器（v8.10.8 P3 拆分）——替代 selfcheck_main 内的闭包 check。

    check(name, ok, detail) 语义与原闭包完全一致：ok 为真则 passes+1，否则记录 fails。
    """

    def __init__(self):
        self.passes = 0
        self.fails = []
        self.skips = []

    def skip(self, name, detail="", count=1):
        """设计性跳过（外置测试集、缺可选依赖等）——单列计数，不混入 PASS（v8.14.4，DB P3-01）。"""
        for _ in range(max(1, count)):
            self.skips.append(name)
        print("  [SKIP] %s%s" % (name, (" — " + detail) if detail else ""))

    def check(self, name, ok, detail=""):
        if ok:
            self.passes += 1
            print("  [PASS] %s%s" % (name, (" — " + detail) if detail else ""))
        else:
            self.fails.append(name)
            print("  [FAIL] %s%s" % (name, (" — " + detail) if detail else ""))
