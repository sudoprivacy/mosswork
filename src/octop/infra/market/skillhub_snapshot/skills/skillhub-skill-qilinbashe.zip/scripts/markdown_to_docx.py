# markdown_to_docx.py: 运行时依赖脚本（技能运行调用）
#!/usr/bin/env python3
"""
markdown_to_docx.py — 将技能产出的 Markdown 文件批量转换为 DOCX 并打包 ZIP。

用法：
  python3 scripts/markdown_to_docx.py <md_file_or_dir> [output_path]

参数：
  md_file_or_dir    单个 .md 文件，或包含多个 .md 文件的目录
  output_path       可选。输出路径，默认为用户主目录下的 legal-skills-export/（跨平台，自动适配 Windows/macOS/Linux）

输出：
  - 单个文件：生成同名的 .docx 文件
  - 目录：生成所有 .docx 文件并打包为 ZIP

示例：
  python3 scripts/markdown_to_docx.py /path/to/output.md
  python3 scripts/markdown_to_docx.py /path/to/analysis_dir/
"""

import os
import sys
import re
import zipfile
# ── 文档组件保护式导入（v5.8.1 开箱即用整改：缺组件时输出中文引导，不报错中断）──
try:
    from docx import Document
    from docx.shared import Pt, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn, nsdecls
    from docx.oxml import OxmlElement, parse_xml
    _DOCX_OK = True
except ImportError:
    _DOCX_OK = False
    _DOCX_GUIDE = (
        "缺少文档生成组件：请回复“安装”二字由系统自动安装，"
        "或手动运行 `python scripts/install_deps.py --word`。"
        "安装完成前，可先使用 Markdown 文本交付。"
    )
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except (AttributeError, ValueError):
    pass

# 兼容引导：确保本脚本目录进入 sys.path（嵌入式 Python 环境运行时脚本目录不自动入 path，
# pii_filter.py 同目录共享模块依赖此引导；v5.7.0 可移植性整改）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── PII 脱敏（v5.3.0 P1-3：统一为共享模块 pii_filter.py，消除复制粘贴口径不一致）──
from pii_filter import (pii_scan, pii_mask, pii_ctx_scan, pii_ctx_mask,  # noqa: E402  v8.10.1 增非结构化兜底
                        markdown_safe)


# ── 排版工具函数 ──

def set_cjk_font(run_or_style, cn_font='宋体', en_font='Times New Roman'):
    rPr = run_or_style.element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    rFonts.set(qn('w:eastAsia'), cn_font)
    rFonts.set(qn('w:ascii'), en_font)
    rFonts.set(qn('w:hAnsi'), en_font)


def clean_heading_style(style):
    style.font.color.rgb = RGBColor(0, 0, 0)
    rPr = style.element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is not None:
        for attr in ['w:asciiTheme', 'w:hAnsiTheme', 'w:eastAsiaTheme', 'w:cstheme']:
            if rFonts.get(qn(attr)):
                del rFonts.attrib[qn(attr)]
    pPr = style.element.find(qn('w:pPr'))
    if pPr is not None:
        pBdr = pPr.find(qn('w:pBdr'))
        if pBdr is not None:
            pPr.remove(pBdr)


def setup_document(doc, title_text=None):
    """政府标准行文格式（GB/T 9704-2012 党政机关公文格式）"""
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(3.7)      # 上3.7cm
    section.bottom_margin = Cm(3.5)   # 下3.5cm
    section.left_margin = Cm(2.8)     # 左2.8cm
    section.right_margin = Cm(2.6)    # 右2.6cm

    # 正文：仿宋_GB2312 三号(16pt)，1.5倍行距，首行缩进2字符
    normal = doc.styles['Normal']
    normal.font.size = Pt(16)         # 三号=16pt
    normal.paragraph_format.line_spacing = 1.5
    normal.paragraph_format.first_line_indent = Pt(32)  # 2字符缩进
    set_cjk_font(normal, '仿宋_GB2312', 'Times New Roman')

    # 标题样式
    for i in range(0, 4):
        h_style_name = 'Title' if i == 0 else f'Heading {i}'
        h_style = doc.styles[h_style_name]
        clean_heading_style(h_style)
        # 一级标题(##)：黑体 二号(22pt) 居中
        if i == 1:
            h_style.font.size = Pt(22)
            h_style.font.bold = True
            h_style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
            set_cjk_font(h_style, '黑体', 'Arial')
        # 二级标题(###)：黑体 三号(16pt) 加粗
        elif i == 2:
            h_style.font.size = Pt(16)
            h_style.font.bold = True
            set_cjk_font(h_style, '黑体', 'Arial')
        # 三级标题(####)：楷体 三号(16pt)
        elif i == 3:
            h_style.font.size = Pt(16)
            h_style.font.bold = False
            set_cjk_font(h_style, '楷体_GB2312', 'Arial')
        # 文档主标题（#）：黑体 小标宋 22pt 居中
        else:
            h_style.font.size = Pt(22)
            h_style.font.bold = True
            h_style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
            set_cjk_font(h_style, '黑体', 'Arial')
        h_style.paragraph_format.first_line_indent = Pt(0)

    # 页脚页码
    footer = section.footer
    footer.is_linked_to_previous = False
    footer_para = footer.paragraphs[0]
    footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer_para.add_run()
    run.font.size = Pt(14)  # 表格字号四号=14pt
    run._r.append(parse_xml(f'<w:fldChar {nsdecls("w")} w:fldCharType="begin"/>'))
    run = footer_para.add_run()
    run.font.size = Pt(14)  # 表格字号四号=14pt
    run._r.append(parse_xml(f'<w:instrText {nsdecls("w")} xml:space="preserve"> PAGE </w:instrText>'))
    run = footer_para.add_run()
    run.font.size = Pt(14)  # 表格字号四号=14pt
    run._r.append(parse_xml(f'<w:fldChar {nsdecls("w")} w:fldCharType="end"/>'))

    if title_text:
        title = doc.add_heading(title_text, level=0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    return doc


def _add_rich_text(paragraph, text):
    """添加富文本（处理 **加粗** 标记）"""
    parts = re.split(r'(\*\*.*?\*\*)', text)
    for part in parts:
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            run = paragraph.add_run(part[2:-2])
            run.bold = True
        else:
            paragraph.add_run(part)


def add_table_from_lines(doc, lines):
    rows_data = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith('|---') or line.startswith('|--'):
            continue
        if line.startswith('|') and line.endswith('|'):
            cells = [c.strip() for c in line.strip('|').split('|')]
            rows_data.append(cells)
    if not rows_data:
        return
    max_cols = max(len(r) for r in rows_data)
    table = doc.add_table(rows=len(rows_data), cols=max_cols, style='Table Grid')
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row_cells in enumerate(rows_data):
        for j in range(max_cols):
            cell = table.rows[i].cells[j]
            cell.text = row_cells[j] if j < len(row_cells) else ''
            for para in cell.paragraphs:
                para.style = doc.styles['Normal']
                para.paragraph_format.space_before = Pt(2)
                para.paragraph_format.space_after = Pt(2)
                for run in para.runs:
                    run.font.size = Pt(14)  # 表格字号四号=14pt
                if i == 0:
                    for run in para.runs:
                        run.bold = True
                    shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="D9E2F3"/>')
                    cell._tc.get_or_add_tcPr().append(shading)
    doc.add_paragraph()


def markdown_to_docx(md_path, docx_path, doc_title=None):
    if not _DOCX_OK:
        print(_DOCX_GUIDE)
        sys.exit(1)

    """将单个 .md 文件转换为 .docx"""
    with open(md_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # PII 二次检查（v4.19.0）：命中完整身份证、手机号、银行卡 → 警告并自动脱敏
    pii_hits = pii_scan(content)
    if pii_hits:
        print("[PII警告] 检测到完整个人信息（%s），已自动脱敏后导出" % "/".join(pii_hits), file=sys.stderr)
        content = pii_mask(content)  # v5.3.0: pii_mask 来源统一为 pii_filter.py
    # v8.10.1：非结构化 PII（姓名、住址、案号）上下文锚定兜底脱敏——原仅由 LLM 层规则处理，存在漏检风险
    ctx_hits = pii_ctx_scan(content)
    if ctx_hits:
        print("[PII警告] 检测到疑似非结构化个人信息（%s），已按上下文锚定规则脱敏后导出"
              % "/".join(ctx_hits), file=sys.stderr)
        content = pii_ctx_mask(content)
    if pii_hits or ctx_hits:
        content = markdown_safe(content)  # **** → ＊＊＊＊：防 markdown 粗体解析吞掉脱敏记号
    # v5.3.0 P2-D30：模板注入防护（脚本级强制过滤）
    INJECTION_RE = re.compile(r'(?:\{\{.*?\}\}|\{%.*?%\})', re.DOTALL)
    injection_hits = INJECTION_RE.findall(content)
    if injection_hits:
        print("[模板注入警告] 检测到 %d 处模板标记（{{...}}/{%...%}），已自动清除" % len(injection_hits), file=sys.stderr)
        content = INJECTION_RE.sub('', content)
    # 去掉 YAML frontmatter
    content = re.sub(r'^---\n.*?\n---\n', '', content, flags=re.DOTALL)

    doc = Document()
    setup_document(doc, doc_title)

    lines = content.split('\n')
    i = 0
    in_table = False
    table_lines = []
    in_code = False
    while i < len(lines):
        line = lines[i]
        if line.strip().startswith('```'):
            in_code = not in_code
            i += 1
            continue
        if in_code:
            i += 1
            continue

        s = line.strip()
        # 表格
        if s.startswith('|') and s.endswith('|'):
            in_table = True
            table_lines.append(line)
            i += 1
            continue
        else:
            if in_table and table_lines:
                add_table_from_lines(doc, table_lines)
                in_table = False
                table_lines = []

        # 标题
        if s.startswith('# ') and not s.startswith('## '):
            doc.add_heading(s[2:], level=1)
        elif s.startswith('## ') and not s.startswith('### '):
            doc.add_heading(s[3:], level=2)
        elif s.startswith('### '):
            doc.add_heading(s[4:], level=3)
        elif s.startswith('- [') or s.startswith('* ['):
            prefix = '☑ ' if '[x]' in s.lower() else '☐ '
            text = re.sub(r'^[-*]\s*\[\s*[xX]?\s*\]\s*', '', s)
            p = doc.add_paragraph(style='List Bullet')
            p.add_run(prefix + text)
        elif s.startswith('- ') or s.startswith('* '):
            p = doc.add_paragraph(style='List Bullet')
            _add_rich_text(p, s[2:])
        elif re.match(r'^\d+[\.\)]\s', s):
            p = doc.add_paragraph(style='List Number')
            _add_rich_text(p, re.sub(r'^\d+[\.\)]\s*', '', s))
        elif s.startswith('> '):
            text = s[2:]
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.74)  # 2字符缩进
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.first_line_indent = Pt(0)
            pPr = p._p.get_or_add_pPr()
            pBdr = OxmlElement('w:pBdr')
            left = OxmlElement('w:left')
            left.set(qn('w:val'), 'single')
            left.set(qn('w:sz'), '12')
            left.set(qn('w:space'), '6')
            left.set(qn('w:color'), '4472C4')
            pBdr.append(left)
            pPr.append(pBdr)
            _add_rich_text(p, text)
        elif s.startswith('---') and len(s) >= 3:
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(6)
            p.paragraph_format.space_after = Pt(6)
            pPr = p._p.get_or_add_pPr()
            pBdr = OxmlElement('w:pBdr')
            bottom = OxmlElement('w:bottom')
            bottom.set(qn('w:val'), 'single')
            bottom.set(qn('w:sz'), '6')
            bottom.set(qn('w:space'), '1')
            bottom.set(qn('w:color'), '999999')
            pBdr.append(bottom)
            pPr.append(pBdr)
        elif s:
            p = doc.add_paragraph()
            _add_rich_text(p, s)
        else:
            doc.add_paragraph()
        i += 1

    if in_table and table_lines:
        add_table_from_lines(doc, table_lines)

    os.makedirs(os.path.dirname(docx_path), exist_ok=True)
    doc.save(docx_path)
    return docx_path


def convert_and_zip(file_or_dir, output_base=None):
    if not _DOCX_OK:
        print(_DOCX_GUIDE)
        sys.exit(1)

    """
    主入口：将文件或目录中的 .md 转为 .docx 并可选打包 ZIP。

    参数:
        file_or_dir: 单个 .md 文件路径，或包含 .md 的目录路径
        output_base: 输出基础路径。为 None 时使用跨平台默认路径（用户主目录下的 legal-skills-export/）
    返回:
        (zip_path, file_count) 或 (docx_path, 1)
    """
    if output_base is None:
        output_base = os.path.join(os.path.expanduser("~"), "legal-skills-export")

    if os.path.isfile(file_or_dir) and file_or_dir.endswith('.md'):
        # 单个文件
        base = os.path.splitext(os.path.basename(file_or_dir))[0]
        docx_path = os.path.join(output_base, f'{base}.docx')
        markdown_to_docx(file_or_dir, docx_path, base)
        return docx_path, 1

    elif os.path.isdir(file_or_dir):
        # 目录 → 批量转换并打包 ZIP
        md_files = sorted([
            f for f in os.listdir(file_or_dir)
            if f.endswith('.md')
        ])
        if not md_files:
            print("未找到 .md 文件")
            return None, 0

        for fname in md_files:
            md_path = os.path.join(file_or_dir, fname)
            base = os.path.splitext(fname)[0]
            docx_path = os.path.join(output_base, 'docx', f'{base}.docx')
            title = base.replace('-', ' ').replace('_', ' ')
            markdown_to_docx(md_path, docx_path, title)
            print(f"  ✓ {fname} → {base}.docx")

        # 打包 ZIP
        zip_name = os.path.basename(os.path.normpath(file_or_dir))
        zip_path = os.path.join(output_base, f'{zip_name}.zip')
        os.makedirs(os.path.dirname(zip_path), exist_ok=True)
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            docx_dir = os.path.join(output_base, 'docx')
            for fname in os.listdir(docx_dir):
                if fname.endswith('.docx'):
                    fpath = os.path.join(docx_dir, fname)
                    zf.write(fpath, fname)

        print(f"\n已完成！共 {len(md_files)} 个文件")
        print(f"ZIP 包: {zip_path}")
        return zip_path, len(md_files)

    else:
        raise ValueError(f"路径无效或不是 .md 文件: {file_or_dir}")





# ============================================================
# 第二部分：Word 批注注入引擎（原 scripts/docx_comments.py，v5.8.0 并入）
# 用法：python scripts/markdown_to_docx.py <合同.docx> -c comments.json -o <输出.docx>
# ============================================================
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
markdown_to_docx.py 内含模块 — Word 批注注入引擎（批注式审查交付，v5.8.0 并入本文件）

借鉴 jicheng-contract-review 的批注模型：
- 只加批注，不改动合同原文与格式
- 批注锚定到搜索文本所在段落（commentRangeStart/End + commentReference）
- 风险等级以审阅者名编码（Word 侧边一眼可见）：🔴高 / 🟡中 / 🔵低
- 自动处理 comments.xml、document.xml.rels、[Content_Types].xml 三处注册
- 自带 verify() 校验与成功/失败计数；失败逐条定位（见"失败模式排查表"）

零依赖：仅用 Python 标准库（zipfile / re / shutil），无需 python-docx。

用法一（Python 调用）：
    from markdown_to_docx import DocxCommentEngine
    comments = [
        {"search": "违约方应支付", "comment": "【问题类型】违约金\\n【风险原因】比例过高可能被调减\\n【修订建议】改为X%并对不足部分另算", "risk_level": "high"},
    ]
    engine = DocxCommentEngine("合同.docx", comments)
    engine.run("合同_审核版.docx")
    print(engine.added, engine.failed)

用法二（命令行）：
    python markdown_to_docx.py 合同.docx -c comments.json -o 合同_审核版.docx
    comments.json 格式：[{"search": "...", "comment": "...", "risk_level": "high|medium|low"}]
"""

import json
import re
import shutil
import sys
import zipfile
from pathlib import Path

RISK_REVIEWER = {
    "high": "律师助手-🔴高",
    "medium": "律师助手-🟡中",
    "low": "律师助手-🔵低",
}
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
COMMENTS_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
)
COMMENTS_CONTENT_TYPE = (
    "application/vnd.openxmlformats.org-officeDocument.2006"  # placeholder, corrected below
)


class CommentError(Exception):
    """批注注入基础异常"""


class SearchTextNotFoundError(CommentError):
    """搜索文本未在正文中找到"""


def _escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


class DocxCommentEngine:
    def __init__(self, docx_path, comments, reviewer_prefix="律师助手"):
        self.src = Path(docx_path)
        if not self.src.exists():
            raise CommentError(f"文件不存在: {self.src}")
        self.comments = comments or []
        self.reviewer_prefix = reviewer_prefix
        self.added = []   # [(search, index)]
        self.failed = []  # [(search, reason)]

    # ---------- 主流程 ----------
    def run(self, output_path=None):
        if not _DOCX_OK:
            print(_DOCX_GUIDE)
            sys.exit(1)

        out = Path(output_path) if output_path else self.src.with_name(
            self.src.stem + "_审核版.docx"
        )
        shutil.copyfile(self.src, out)

        with zipfile.ZipFile(out, "r") as z:
            names = z.namelist()
            data = {n: z.read(n) for n in names}

        doc = data["word/document.xml"].decode("utf-8")
        rels = data.get("word/_rels/document.xml.rels", (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<Relationships xmlns="{REL_NS}"></Relationships>'
        )).decode("utf-8") if "word/_rels/document.xml.rels" in data else (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<Relationships xmlns="{REL_NS}"></Relationships>'
        )
        ctypes = data["[Content_Types].xml"].decode("utf-8")

        has_comments_part = "word/comments.xml" in names
        comments_xml = (
            data["word/comments.xml"].decode("utf-8") if has_comments_part else None
        )

        # 已有最大批注 id，避免冲突
        used_ids = [int(m) for m in re.findall(r'w:id="(\d+)"', doc + (comments_xml or ""))]
        next_id = (max(used_ids) + 1) if used_ids else 0

        new_comment_bodies = []
        for i, c in enumerate(self.comments):
            search = c.get("search", "")
            body = c.get("comment", "")
            risk = str(c.get("risk_level", "medium")).lower()
            reviewer = f"{self.reviewer_prefix}-{RISK_REVIEWER.get(risk, RISK_REVIEWER['medium']).split('-')[1]}"
            try:
                doc, cid = self._inject_anchor(doc, search, next_id)
                next_id = cid + 1
                new_comment_bodies.append(
                    self._comment_body_xml(cid, reviewer, body)
                )
                self.added.append((search, cid))
            except SearchTextNotFoundError:
                self.failed.append((search, "未在正文找到搜索文本"))
            except CommentError as e:
                self.failed.append((search, str(e)))

        # 注册 comments 部件
        if new_comment_bodies:
            if not has_comments_part:
                comments_xml = self._empty_comments_xml()
                rels = self._ensure_relationship(rels)
                ctypes = self._ensure_content_type(ctypes)
            comments_xml = self._append_comments(comments_xml, new_comment_bodies)
            data["word/comments.xml"] = comments_xml.encode("utf-8")
            data["word/_rels/document.xml.rels"] = rels.encode("utf-8")
            data["[Content_Types].xml"] = ctypes.encode("utf-8")

        data["word/document.xml"] = doc.encode("utf-8")
        self._repack(out, data, names)

        # 校验
        self.verify(out)
        return out

    # ---------- 锚点注入 ----------
    def _inject_anchor(self, doc: str, search: str, cid: int):
        """在搜索文本所在段落注入 commentRangeStart/End + commentReference。

        策略：先直接找纯文本；找不到再做“跨 run 拆字拼接”回退——
        把段落内 w:t 文本拼起来匹配，定位段落范围后整体加批注。
        """
        # 1) 纯文本直接命中（文本未被 run 拆开）
        idx = doc.find(_escape(search))
        if idx >= 0:
            end = idx + len(_escape(search))
            doc = (
                doc[:idx]
                + f'<w:commentRangeStart w:id="{cid}"/>'
                + doc[idx:end]
                + f'<w:commentRangeEnd w:id="{cid}"/>'
                + f'<w:r><w:commentReference w:id="{cid}"/></w:r>'
                + doc[end:]
            )
            return doc, cid

        # 2) 跨 run 回退：按段落扫描
        para_pat = re.compile(r"<w:p[ >].*?</w:p>", re.S)
        t_pat = re.compile(r"<w:t[^>]*>(.*?)</w:t>", re.S)
        for m in para_pat.finditer(doc):
            para = m.group(0)
            text = "".join(t_pat.findall(para))
            if search in text:
                # 在段落末尾（</w:p> 前）插入整段批注范围
                close = para.rfind("</w:p>")
                anchored = (
                    para[:close]
                    + f'<w:commentRangeStart w:id="{cid}"/>'
                    + f'<w:commentRangeEnd w:id="{cid}"/>'
                    + f'<w:r><w:commentReference w:id="{cid}"/></w:r>'
                    + para[close:]
                )
                doc = doc.replace(para, anchored, 1)
                return doc, cid
        raise SearchTextNotFoundError(search)

    # ---------- XML 构造 ----------
    def _comment_body_xml(self, cid, reviewer, body):
        lines = body.replace("\r\n", "\n").split("\n")
        ps = "".join(
            f'<w:p><w:r><w:t xml:space="preserve">{_escape(ln)}</w:t></w:r></w:p>'
            for ln in lines
        )
        initials = "LS"
        return (
            f'<w:comment w:id="{cid}" w:author="{_escape(reviewer)}" '
            f'w:initials="{initials}" w:date="2026-01-01T00:00:00Z">{ps}</w:comment>'
        )

    def _empty_comments_xml(self):
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<w:comments xmlns:w="{W_NS}"></w:comments>'
        )

    def _append_comments(self, comments_xml: str, bodies):
        return comments_xml.replace("</w:comments>", "".join(bodies) + "</w:comments>")

    def _ensure_relationship(self, rels: str) -> str:
        if "relationships/comments" in rels:
            return rels
        # v7.9.0：rid 生成改为确定性序号（旧版 abs(hash('c')) 是进程随机数，
        # 同一文件两次转换 rid 漂移，且 %9999 有碰撞风险）
        n = 1
        while f"rIdComments{n}" in rels:
            n += 1
        rid = f"rIdComments{n}"
        rel_tag = (
            f'<Relationship Id="{rid}" Type="{COMMENTS_REL_TYPE}" '
            'Target="comments.xml"/>'
        )
        if "</Relationships>" in rels:
            return rels.replace("</Relationships>", rel_tag + "</Relationships>")
        return rels + rel_tag + "</Relationships>"

    def _ensure_content_type(self, ctypes: str) -> str:
        if "wordprocessingml.comments+xml" in ctypes:
            return ctypes
        override = (
            '<Override PartName="/word/comments.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.'
            'wordprocessingml.comments+xml"/>'
        )
        return ctypes.replace("</Types>", override + "</Types>")

    # ---------- 打包与校验 ----------
    def _repack(self, out: Path, data: dict, order):
        tmp = out.with_suffix(".tmp.docx")
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
            for name in order:
                if name in data:
                    z.writestr(name, data[name])
            for name, blob in data.items():
                if name not in order:
                    z.writestr(name, blob)
        tmp.replace(out)

    def verify(self, docx_path):
        """校验批注是否注册完整；返回 (ok, problems)。"""
        problems = []
        with zipfile.ZipFile(docx_path, "r") as z:
            names = z.namelist()
            doc = z.read("word/document.xml").decode("utf-8")
            if "word/comments.xml" not in names:
                problems.append("缺 word/comments.xml")
            else:
                cx = z.read("word/comments.xml").decode("utf-8")
                if self.added and cx.count("<w:comment ") < len(self.added):
                    problems.append("comments.xml 中批注数量少于新增数")
            rels = z.read("word/_rels/document.xml.rels").decode("utf-8")
            if self.added and "relationships/comments" not in rels:
                problems.append("document.xml.rels 缺 comments 关系")
            ctypes = z.read("[Content_Types].xml").decode("utf-8")
            if self.added and "wordprocessingml.comments+xml" not in ctypes:
                problems.append("[Content_Types].xml 缺 comments Override")
            if self.added and "commentRangeStart" not in doc:
                problems.append("document.xml 缺 commentRangeStart")
        return (len(problems) == 0, problems)


def _cli():
    import argparse

    ap = argparse.ArgumentParser(description="Word 批注注入（不改原文）")
    ap.add_argument("docx", help="目标 docx")
    ap.add_argument("-c", "--comments", required=True, help="comments.json 路径")
    ap.add_argument("-o", "--output", default=None, help="输出路径")
    a = ap.parse_args()
    comments = json.loads(Path(a.comments).read_text(encoding="utf-8"))
    engine = DocxCommentEngine(a.docx, comments)
    out = engine.run(a.output)
    ok, problems = engine.verify(out)
    print(f"✓ 批注成功 {len(engine.added)} 条；失败 {len(engine.failed)} 条")
    for s, r in engine.failed:
        print(f"  ✗ {s[:30]}…：{r}")
    print(("✓ 校验通过" if ok else "✗ 校验问题： " + "; ".join(problems)))
    print(f"输出：{out}")


# 批注注入引擎已并入本文件（v5.8.0）；_cli() 供 markdown_to_docx 批注模式分派调用


if __name__ == '__main__':
    if any(a in ("-h", "--help") for a in sys.argv[1:]):
        print(__doc__)
        sys.exit(0)
    if not _DOCX_OK:
        print(_DOCX_GUIDE)
        sys.exit(1)

    # 批注注入模式（原 docx_comments.py CLI，v5.8.0 并入）：首参为 .docx 且含 -c 时进入批注引擎
    if len(sys.argv) >= 4 and sys.argv[1].lower().endswith('.docx') and '-c' in sys.argv:
        _cli()
    elif len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    else:
        source = sys.argv[1]
        output = sys.argv[2] if len(sys.argv) > 2 else None
        result, count = convert_and_zip(source, output)
        if result:
            print(f"输出: {result}")
        else:
            sys.exit(1)

