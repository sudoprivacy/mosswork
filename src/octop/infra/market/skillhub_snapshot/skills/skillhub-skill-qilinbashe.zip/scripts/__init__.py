# -*- coding: utf-8 -*-
"""scripts 包标记（原 checks 子包于 v8.13.14 拍平，共享核心合并至 scripts/_core.py）。"""
