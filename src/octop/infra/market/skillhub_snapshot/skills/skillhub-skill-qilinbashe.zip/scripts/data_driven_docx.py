#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
data_driven_docx.py —— 要素式起诉状数据驱动 DOCX 生成（三件套·生成端）
v8.3.0 新增（P1 借鉴点落地 · 自研实现）

定位：
  与 references/模板填写速查.md 附录（填充地图）+ examples/case-data-examples.json（样例数据）
  组成"模板 + 填充地图 + 数据"三件套的生成端：把结构化 JSON 字段
  确定性填充为民事起诉状 DOCX（字段完整、可机检、可审计）。

用法：
  python scripts/data_driven_docx.py <data.json> [output_dir]
  python scripts/data_driven_docx.py --case <案由名> [output_dir]
      # 从 examples/case-data-examples.json 取单个案由样例生成（案由名支持简写，如“民间借贷”）
  python scripts/data_driven_docx.py --selftest

JSON 字段键（与 模板填写速查.md 附录一致，doctor REG-064 校验）：
  case_type, court, plaintiff_name, plaintiff_id, plaintiff_addr,
  plaintiff_phone, defendant_name, defendant_id, defendant_addr,
  defendant_phone, claims[], facts, evidence[]({name,source,purpose}),
  statute_articles[], statute_baseline, risk_notes[], deliverable_check[]

输出：同目录 <case_type>_起诉状_YYYYMMDD.docx（默认输出到用户主目录 legal-skills-export/）。
--selftest：用内置样例生成到临时目录并自检字段，返回 OK/FAIL（doctor 冒烟用）。
"""
import json
import os
import sys
import tempfile
from datetime import date

# ── 中文 Windows 控制台编码兜底（v8.10.6）──
# GBK 控制台下 print emoji/非 GBK 字符（⚠️ 等）会抛 UnicodeEncodeError 直接崩溃；
# 与包内其它脚本同款入口重配置 stdout/stderr 为 utf-8、无法编码字符替换。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

# ── 文档组件保护式导入（缺组件时中文引导，不报错中断）──
try:
    from docx import Document
    from docx.shared import Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    _DOCX_OK = True
except ImportError:
    _DOCX_OK = False
    _DOCX_GUIDE = ("缺少文档生成组件：请回复“安装”二字由系统自动安装，"
                   "或手动运行 `python scripts/install_deps.py --word`。")

# ── 兼容引导：确保本脚本目录进入 sys.path（与 markdown_to_docx 同款可移植性整改）──
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pii_filter import (pii_scan, pii_mask, pii_ctx_scan, pii_ctx_mask)  # noqa: E402  统一脱敏口径（v8.10.1 增非结构化兜底；v8.10.4 清死导入 markdown_safe）

# 与 模板填写速查.md 附录 / examples/case-data-examples.json 对齐的字段键白名单（doctor REG-064 校验键集）
FIELD_KEYS = [
    "case_type", "court", "plaintiff", "defendant",
    "plaintiff_name", "plaintiff_id", "plaintiff_addr",
    "plaintiff_phone", "defendant_name", "defendant_id", "defendant_addr",
    "defendant_phone", "claims", "facts", "evidence", "statute_articles",
    "statute_baseline", "risk_notes", "deliverable_check",
]
REQUIRED_KEYS = ["case_type", "plaintiff_name", "defendant_name", "claims", "facts"]


def set_cjk_font(run, cn_font='宋体', en_font='Times New Roman'):
    rPr = run.element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    rFonts.set(qn('w:eastAsia'), cn_font)
    rFonts.set(qn('w:ascii'), en_font)
    rFonts.set(qn('w:hAnsi'), en_font)


def _add_para(doc, text, bold=False, align=None, size=12):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold
    run.font.size = Pt(size)
    set_cjk_font(run)
    if align == "center":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "right":
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    return p


def _party_block(doc, label, data):
    _add_para(doc, "%s：" % label, bold=True)
    name = data.get("name", "")
    pid = data.get("id", "")
    addr = data.get("addr", "")
    phone = data.get("phone", "")
    detail = "，".join(x for x in [pid, addr, phone] if x)
    _add_para(doc, "%s%s" % (name, ("（" + detail + "）") if detail else ""))


def build_docx(data, out_path):
    """按 JSON 字段生成起诉状 DOCX。返回生成路径。"""
    doc = Document()
    _add_para(doc, "民事起诉状", bold=True, align="center", size=16)
    _add_para(doc, "案由：%s" % data.get("case_type", ""), align="center")
    _add_para(doc, "")

    _party_block(doc, "原告", data.get("plaintiff", {}))
    _add_para(doc, "")
    _party_block(doc, "被告", data.get("defendant", {}))
    _add_para(doc, "")

    _add_para(doc, "诉讼请求：", bold=True)
    claims = data.get("claims", [])
    if isinstance(claims, list):
        for i, c in enumerate(claims, 1):
            _add_para(doc, "%d. %s" % (i, c))
    else:
        _add_para(doc, "1. %s" % claims)
    _add_para(doc, "")

    _add_para(doc, "事实与理由：", bold=True)
    _add_para(doc, data.get("facts", ""))

    ev = data.get("evidence", [])
    if ev:
        _add_para(doc, "证据和证据来源：", bold=True)
        table = doc.add_table(rows=1, cols=4)
        table.style = "Table Grid"
        hdr = table.rows[0].cells
        for j, htext in enumerate(["序号", "证据名称", "来源", "证明目的"]):
            hdr[j].text = htext
        for i, e in enumerate(ev, 1):
            row = table.add_row().cells
            row[0].text = str(i)
            row[1].text = e.get("name", "")
            row[2].text = e.get("source", "")
            row[3].text = e.get("purpose", "")
    _add_para(doc, "")

    arts = data.get("statute_articles", [])
    if arts:
        _add_para(doc, "法律依据：", bold=True)
        _add_para(doc, "；".join(arts) if isinstance(arts, list) else str(arts))
        _add_para(doc, "")

    _add_para(doc, "此致")
    _add_para(doc, "%s人民法院" % data.get("court", "＿＿＿＿"))
    _add_para(doc, "")
    _add_para(doc, "具状人：%s" % data.get("plaintiff", {}).get("name", ""), align="right")
    _add_para(doc, "%s年%s月%s日" % (date.today().year, date.today().month, date.today().day), align="right")

    doc.save(out_path)
    return out_path


def validate_fields(data):
    """字段完整性自检：返回 (ok, missing, extra)。doctor REG-064/065 用。

    数据结构：plaintiff/defendant 为嵌套对象；claims/facts 等为顶层字段。
    """
    missing = []
    for k in REQUIRED_KEYS:
        if k in ("plaintiff_name", "defendant_name"):
            v = (data.get("plaintiff") or {}).get("name") if k == "plaintiff_name" \
                else (data.get("defendant") or {}).get("name")
        else:
            v = data.get(k)
        if not v:
            missing.append(k)
    extra = [k for k in data if k not in FIELD_KEYS]
    return (not missing and not extra, missing, extra)


def load_case(name):
    """从整份 examples/case-data-examples.json 取单个案由样例。

    样例库外层结构为 {版本, 用途, 字段键, 样例:{案由名: {...data...}}}；整份 JSON 不能直接
    喂 validate_fields（会因多余外层键报“字段不完整…多余:[版本,用途,字段键,样例]”）。本函数按
    案由名（支持简写/模糊匹配，如“民间借贷”命中“民间借贷纠纷”）取出“样例”节下的单案由对象。
    返回 (data, rc)：命中 (dict, 0)，失败 (None, 非 0)。
    """
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "..", "examples", "case-data-examples.json")
    try:
        with open(path, encoding="utf-8") as f:
            bundle = json.load(f)
    except (OSError, ValueError) as exc:
        print("FAIL 读取样例库失败: %s" % exc)
        return None, 2
    cases = bundle.get("样例") if isinstance(bundle, dict) else None
    if not cases:
        print("FAIL 样例库缺“样例”节或为空：%s" % path)
        return None, 2
    key = name if name in cases else None
    if key is None:
        hits = [k for k in cases if name in k or k in name]
        if len(hits) == 1:
            key = hits[0]
        elif len(hits) > 1:
            print("FAIL 案由名不唯一：%s（匹配 %s）" % (name, "、".join(hits)))
            return None, 2
        else:
            print("FAIL 未找到案由：%s（可用：%s）" % (name, "、".join(cases)))
            return None, 2
    return cases[key], 0


def main(argv):
    if not _DOCX_OK:
        print(_DOCX_GUIDE)
        return 2
    if any(a in ("-h", "--help") for a in argv):
        print("用法：")
        print("  python scripts/data_driven_docx.py <data.json> [output_dir]")
        print("  python scripts/data_driven_docx.py --case <案由名> [output_dir]")
        print("  python scripts/data_driven_docx.py --selftest")
        print("说明：--case 从 examples/case-data-examples.json 取单个案由样例后生成；")
        print("      整份样例库（含“版本/用途/字段键/样例”外层键）不可直接作为 <data.json>。")
        return 0
    if argv and argv[0] == "--selftest":
        # 冒烟：内置最小样例 → 临时目录生成 → 字段自检
        sample = {
            "case_type": "民间借贷纠纷", "court": "被告住所地人民法院",
            "plaintiff": {"name": "张三", "id": "张三身份证号后四位XXXX", "addr": "示例地址", "phone": ""},
            "defendant": {"name": "李四", "id": "李四身份证号后四位XXXX", "addr": "示例地址", "phone": ""},
            "claims": ["请求判令被告偿还原告借款本金人民币 50,000 元；",
                       "请求判令被告支付逾期利息（按 LPR 计，暂计至起诉之日）；",
                       "请求判令被告承担本案诉讼费用。"],
            "facts": "示例事实：被告于 XXXX 年 XX 月 XX 日向原告借款并出具借条，到期未还。",
            "evidence": [{"name": "借条", "source": "原告持有", "purpose": "证明借贷关系成立"}],
            "statute_articles": ["《中华人民共和国民法典》第六百六十七条", "《中华人民共和国民法典》第六百七十九条"],
            "statute_baseline": "2026-09-29",
            "risk_notes": ["示例风险：诉讼时效 3 年，注意中断证据"],
            "deliverable_check": ["时效已核验", "管辖已核验"],
        }
        ok, missing, extra = validate_fields(sample)
        tmp = tempfile.gettempdir()
        out = os.path.join(tmp, "selftest_%s.docx" % date.today().strftime("%Y%m%d"))
        try:
            build_docx(sample, out)
        except Exception as exc:  # noqa: BLE001
            print("FAIL 生成异常: %s" % exc)
            return 1
        ok2 = os.path.exists(out) and os.path.getsize(out) > 5000
        print("OK 字段自检通过，样例生成 %s 字节" % os.path.getsize(out) if ok and ok2
              else "FAIL 字段缺失:%s 或生成失败" % missing)
        return 0 if ok and ok2 else 1

    out_dir = os.path.join(os.path.expanduser("~"), "legal-skills-export")
    if argv and argv[0] == "--case":
        if len(argv) < 2:
            print("FAIL --case 需指定案由名（如：--case 民间借贷）")
            return 1
        if len(argv) > 2:
            out_dir = argv[2]
        data, rc = load_case(argv[1])
        if data is None:
            return rc
    elif len(argv) >= 1:
        src = argv[0]
        if len(argv) > 1:
            out_dir = argv[1]
        try:
            with open(src, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError) as exc:
            print("FAIL 读取 JSON 失败: %s" % exc)
            return 2
    else:
        print(__doc__)
        return 1
    ok, missing, extra = validate_fields(data)
    if not ok:
        print("FAIL 字段不完整 缺失:%s 多余:%s（键集见 模板填写速查.md 附录）" % (missing, extra))
        return 2
    # 脱敏复核（与 markdown_to_docx 同口径）
    raw = json.dumps(data, ensure_ascii=False)
    if pii_scan(raw):
        masked = pii_mask(raw)
        print("⚠️ 检测到疑似敏感信息，已按脱敏口径提示（输出使用化名）")
        if masked != raw:
            print("  原始数据包含真实姓名、证件号等，请替换为化名后重试")
            return 2
    # v8.10.1：非结构化 PII（姓名、住址、案号）上下文锚定兜底——警告并按规则脱敏后写入输出
    ctx_hits = pii_ctx_scan(raw)
    if ctx_hits:
        print("⚠️ 检测到疑似非结构化个人信息（%s），已按上下文锚定规则脱敏（若要保留真实信息，请改用化名流程）"
              % "/".join(ctx_hits))
        # v8.10.3 修复：对照 markdown_to_docx.py:215，build_docx 落盘前实际执行掩码
        # （原仅打印日志、落盘 data 未掩码，日志与行为不一致）；pii_ctx_mask 作用于字符串，
        # 故对序列化后的 raw 掩码再反序列化回 dict 供 build_docx 消费，同时消除 L46 死导入。
        data = json.loads(pii_ctx_mask(raw))
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "%s_起诉状_%s.docx" % (
        data["case_type"], date.today().strftime("%Y%m%d")))
    build_docx(data, out)
    print("OK 已生成：%s" % out)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
