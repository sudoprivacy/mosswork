# multimodal_ingest.py: 运行时依赖脚本（技能运行调用）
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""多模态材料解析：图片/OCR、PDF、Office、压缩包、音视频、邮件 -> 结构化 Markdown。

律师助手“107-多模态材料解析”技能配套脚本（v4.3.0 扩展）。
输入单文件或目录，自动识别材料类型，抽取文本与关键信号，输出 Markdown 骨架，
供“87-案卷精读防漏技能”与“39-案件承接与委托”直接使用。

支持格式矩阵（12 类）：
  • PDF（.pdf）            —— fitz / pdfplumber 抽文字层；扫描件逐页 OCR
  • 图片（.png .jpg .jpeg .bmp .tiff .webp）—— easyocr
  • HEIC（.heic .heif）    —— pillow-heif 转 PNG 后 OCR
  • 文本（.txt .md .csv）  —— 编码探测后直读（零依赖）
  • Word（.docx）          —— python-docx（含表格），docx2txt 备选；.doc 提示另存为 .docx
  • Excel（.xlsx .xls）    —— openpyxl / xlrd，含 sheet 名与单元格
  • PPT（.pptx）           —— python-pptx，含文本框 / 表格 / 备注
  • HTML（.html .htm）     —— BeautifulSoup 抽取正文与表格
  • 音频（.mp3 .wav .m4a .ogg .flac）—— openai-whisper 转写
  • 视频（.mp4 .mov .avi .mkv）—— ffmpeg 抽音轨后 whisper 转写
  • 压缩包（.zip）         —— 安全解包（防 zip-slip）后递归解析支持类型
  • 邮件（.eml）           —— 标准库 email 提取正文与附件清单

依赖均为“可选”：缺失时对应类型降级并给出替代路径，不影响其他类型。
  easyocr / pillow-heif / fitz / pdfplumber / openai-whisper / ffmpeg /
  python-docx / docx2txt / openpyxl / xlrd / python-pptx / beautifulsoup4

用法：
  python multimodal_ingest.py <材料路径> [--out 输出.md] [--mask-names "真名=标签,..."]
                              [--lang ch_sim] [--max-size-mb 100]
  python multimodal_ingest.py --supported          # 输出支持格式矩阵
  python multimodal_ingest.py --self-test          # 生成样例并验证解析链路

隐私：脚本默认纯本地运行、不外发材料（仅显式 --vlm-check 时外发脱敏后手印图，须书面授权＋逐次确认＋审计留痕）；输入来源仅限本地文件；--mask-names 可对敏感人名做占位脱敏（PII 扫描覆盖身份证号、手机号等）；
仅当显式启用 --vlm-check 且通过运行时逐次确认（--yes-vlm 放行）后，手印疑似图片才发送至智谱视觉模型，全部外发/拒绝事件写入 ~/.legal-skills/vlm_audit.log 审计（v6.6.0 评测 V15 整改，范式对齐 realtime_transcribe）；
解析结果（含脱敏后文本）仅落盘本地临时目录（tempfile），结束后自动清理，不写入共享目录；OCR 页面 / 解包目录 / 抽音轨统一走 tempfile。
"""

import sys
import os
os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")  # v6.6.0 供应链注记：镜像仅用于 whisper 模型权重下载（hf-mirror 为 HF 官方社区镜像）；如需更强供应链保证，可自托管权重并按 SHA 校验后以环境变量覆盖 HF_ENDPOINT；本脚本不上传任何案件材料  # v6.2.0 国内网络：whisper 模型走 HF 国内镜像
import re
import argparse
import datetime
import tempfile
import zipfile
import shutil

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

# 兼容引导：确保本脚本目录进入 sys.path（嵌入式 Python 环境运行时脚本目录不自动入 path，
# pii_filter.py 同目录共享模块依赖此引导；v5.7.0 可移植性整改）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── PII 脱敏（v5.3.0 P1-3：统一为共享模块 pii_filter.py；v8.10.3 升级 pii_mask→pii_mask_all）──
from pii_filter import pii_scan, pii_count, pii_mask_all  # noqa: E402  # 覆盖姓名/住址/案号等非结构化 PII

# ── VLM 外发审计（v6.6.0 评测 V15 整改：外发、拒绝逐事件留痕，范式对齐 realtime_transcribe L54-87）──
VLM_AUDIT_LOG = os.path.join(os.path.expanduser("~"), ".legal-skills", "vlm_audit.log")
VLM_AUDIT_MAX_MB = 2
# v8.10.3：VLM 单图外发大小硬上限（MB），超过则不发送、降级纯本地规则层（与音频通道 MAX_UPLOAD_MB 同四要素）
VLM_MAX_UPLOAD_MB = 8


def vlm_audit(event, target, size_mb=None):
    """数据外发审计：智谱 VLM 外发与用户拒绝事件追加写入本地审计日志；写入失败仅告警不阻断。"""
    try:
        os.makedirs(os.path.dirname(VLM_AUDIT_LOG), exist_ok=True)
        if os.path.exists(VLM_AUDIT_LOG) and os.path.getsize(VLM_AUDIT_LOG) > VLM_AUDIT_MAX_MB * 1024 * 1024:
            try:
                os.replace(VLM_AUDIT_LOG, VLM_AUDIT_LOG + ".1")
            except OSError:
                try:
                    os.remove(VLM_AUDIT_LOG)
                except OSError:
                    pass
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if size_mb is None and target != "—" and os.path.isfile(target):
            size_mb = os.path.getsize(target) / 1024.0 / 1024.0
        size = ("%.1fMB" % size_mb) if size_mb is not None else "-"
        with open(VLM_AUDIT_LOG, "a", encoding="utf-8") as f:
            f.write("[%s] %s | 文件=%s | 大小=%s | 目标=智谱视觉模型(open.bigmodel.cn)\n"
                    % (ts, event, os.path.basename(str(target)), size))
    except Exception as e:
        print("[审计警告] VLM 审计写入失败：%s" % e, file=sys.stderr)

DEFAULT_MAX_SIZE_MB = 100

# ----------------------------------------------------------------------------
# 支持格式矩阵（--supported 与未知格式提示共用单一来源）
# ----------------------------------------------------------------------------
SUPPORTED = [
    ("PDF 文档", [".pdf"], "fitz / pdfplumber 抽文字层，扫描件逐页 OCR", "PyMuPDF / pdfplumber / easyocr"),
    ("图片 / 扫描件", [".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".webp"], "easyocr 抽取文字", "easyocr"),
    ("HEIC 图片", [".heic", ".heif"], "pillow-heif 转 PNG 后 OCR", "pillow-heif + easyocr"),
    ("纯文本 / CSV", [".txt", ".md", ".csv"], "编码探测后直读", "无"),
    ("Word 文档", [".docx", ".doc"], "python-docx 含表格（docx2txt 备选）；.doc 请先另存为 .docx", "python-docx / docx2txt"),
    ("Excel 表格", [".xlsx", ".xls"], "openpyxl / xlrd，含 sheet 名与单元格", "openpyxl / xlrd"),
    ("PPT 演示", [".pptx", ".ppt"], "python-pptx 抽取文本框 / 表格 / 备注；.ppt 请先另存为 .pptx", "python-pptx"),
    ("HTML 网页", [".html", ".htm"], "BeautifulSoup 抽取正文与表格", "beautifulsoup4"),
    ("音频材料", [".mp3", ".wav", ".m4a", ".ogg", ".flac"], "openai-whisper 转写文字稿", "openai-whisper + ffmpeg"),
    ("视频材料", [".mp4", ".mov", ".avi", ".mkv"], "ffmpeg 抽音轨后 whisper 转写", "ffmpeg + openai-whisper"),
    ("压缩包", [".zip"], "安全解包（防 zip-slip）后递归解析支持类型", "无（zipfile 标准库）"),
    ("邮件", [".eml"], "标准库 email 提取正文与附件清单", "无"),
]

EXT_MAP = {}
for _kind, _exts, _method, _deps in SUPPORTED:
    for _e in _exts:
        EXT_MAP[_e] = _kind

UNKNOWN_ADVICE = [
    "① 用 WPS / Office 将文件另存为 PDF 或 TXT 后重新上传；",
    "② 截图保存为图片（png/jpg）后上传（会自动 OCR）；",
    "③ 直接复制粘贴文件中的文字内容到对话框。",
]


def now_stamp():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M")


def mask_text(text, mask_map):
    """按 mask_map（真名->标签）替换，保护隐私。"""
    for real, label in mask_map.items():
        if real and real in text:
            text = text.replace(real, label)
    return text


# ── 非结构化 PII 提示（v5.3.0 D27：姓名、住址等不强制替换，仅提示走 LLM 层语义脱敏）──
# v5.3.0 P1-3：结构化 PII（身份证、手机号、银行账户）正则已统一至 pii_filter.py，
#             以下仅保留非结构化 PII 提示正则（此脚本专有，不进共享模块）。
NONSTRUCTURED_HINTS = [
    (r"[\u4e00-\u9fa5]{2,4}(?:先生|女士|大爷|大妈|大哥|大姐|师傅)", "姓名称呼"),
    (r"[\u4e00-\u9fa5]{2,10}(?:路|街|巷|小区|村|号院|公寓)", "住址"),
]

# v5.3.0 P2-D27：图片生物识别、裸图检测警告（轻量规则提示，不做像素级检测）
IMAGE_BIO_HINT = (
    "[生物识别警告] 图片材料可能含有人脸、指纹、裸露内容，"
    "本脚本不做像素级生物识别检测。如材料含敏感生物信息，"
    "请确保已取得当事人书面授权，并遵守《个人信息保护法》第28条敏感个人信息处理规则。"
)

def image_bio_warning(image_path):
    """图片生物识别、裸图检测警告（v5.3.0 P2-D27）。
    
    轻量级提示：不做像素级检测（避免重型依赖），仅在处理图片时打印警告，
    提醒用户注意生物识别合规与敏感个人信息保护。
    """
    print(IMAGE_BIO_HINT, file=sys.stderr)


# ─────────────────────────────────────────────────────────────
# 手印三态检测（v6.4.0 新增：证据材料捺印存在性辅助判断）
# 规则层：Pillow + numpy（easyocr 依赖链自带），纯本地零外发；
# 精判层（可选）：智谱 glm-4v-flash（国内主链路、免费模型），需 --vlm-check 且已配置 ZHIPU_API_KEY。
# 边界：仅判“有、无、疑似”三态存在性，不构成指纹司法鉴定；关键证据建议原件送检。
# ─────────────────────────────────────────────────────────────
FINGERPRINT_BOUNDARY = (
    "手印检测为捺印存在性的 AI 辅助判断（有、无、疑似三态），不构成指纹司法鉴定；"
    "涉及案件成败的关键证据，建议原件送鉴定机构检验。"
)


def _connected_components(mask):
    """二值图连通域标记（scipy 优先，纯 numpy BFS 降级）。返回 (标签图, 区域数)。"""
    import numpy as np
    try:
        from scipy import ndimage
        return ndimage.label(mask)
    except Exception:
        pass
    h, w = mask.shape
    lab = np.zeros_like(mask, dtype=np.int32)
    cur = 0
    for y in range(h):
        for x in range(w):
            if mask[y, x] and lab[y, x] == 0:
                cur += 1
                stack = [(y, x)]
                lab[y, x] = cur
                while stack:
                    cy, cx = stack.pop()
                    for dy in (-1, 0, 1):
                        for dx in (-1, 0, 1):
                            ny, nx = cy + dy, cx + dx
                            if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] and lab[ny, nx] == 0:
                                lab[ny, nx] = cur
                                stack.append((ny, nx))
    return lab, cur


def _ridge_consistency(gray, y0, y1, x0, x1):
    """纹线特征双度量：方向平滑度 ＋ 交叉块占比。

    - 方向平滑度：相邻小块主方向差小（脊线方向平滑变化）；
    - 交叉块占比：块内方向直方图呈双峰（横竖/多向并存）＝线条交叉。
      指纹脊线不相交（弓、箕、斗型均无交叉点），印章文字、网格线交叉多。
    返回 (smoothness, cross_ratio)。
    """
    import numpy as np
    region = gray[y0:y1, x0:x1].astype(np.float32)
    if region.size < 400:
        return 0.0, 1.0
    h, w = region.shape
    bs = 24
    dirs = []
    cross = 0
    total = 0
    grid_w = max(1, (w - bs) // bs + 1)
    for by in range(0, h - bs + 1, bs):
        for bx in range(0, w - bs + 1, bs):
            blk = region[by:by + bs, bx:bx + bs]
            gy, gx = np.gradient(blk)
            mag = np.hypot(gx, gy)
            if mag.sum() < 1e-6:
                continue
            strong = mag > np.percentile(mag, 60)
            if int(strong.sum()) < 20:
                continue
            th = np.arctan2(gy, gx)
            bins = np.floor((th[strong] + np.pi) / (np.pi / 4)).astype(int) % 8
            hist = np.bincount(bins, minlength=8).astype(float)
            hsum = hist.sum()
            if hsum < 1:
                continue
            hist /= hsum
            main_idx = int(np.argmax(hist))
            main_p = hist[main_idx]
            # 次峰：排除主峰相邻桶后找最大
            hist2 = hist.copy()
            hist2[(main_idx - 1) % 8] = 0
            hist2[(main_idx + 1) % 8] = 0
            hist2[main_idx] = 0
            second_p = float(hist2.max())
            dirs.append(float(main_idx))
            total += 1
            if second_p > 0.25 and second_p > main_p * 0.6:
                cross += 1
    if len(dirs) < 4 or total == 0:
        return 0.0, 1.0
    diffs = []
    for i in range(len(dirs)):
        for j in range(i + 1, len(dirs)):
            bi, bj = i // grid_w, i % grid_w
            ci, cj = j // grid_w, j % grid_w
            if abs(bi - ci) + abs(bj - cj) == 1:
                d = abs(dirs[i] - dirs[j])
                d = min(d, 8 - d)
                diffs.append(d)
    if not diffs:
        return 0.0, 1.0
    smoothness = float(1.0 - (sum(diffs) / len(diffs)) / 4.0)
    cross_ratio = float(cross / total)
    return smoothness, cross_ratio


def detect_fingerprint(image_path):
    """手印三态检测（规则层，纯本地）。

    判定逻辑：
      1) 红色印泥（R 显著高于 G/B）与墨色（深灰）色域分割；
      2) 连通域过滤：尺寸在指印典型范围（直径约为图像短边 5%~20%）、填充率 > 0.25；
      3) 纹线方向一致性 > 0.45（区分指纹纹线 vs 印章文字、污渍）；
      4) 综合：任一高置信区域 → “有”；仅疑似区域 → “疑似”；否则 → “无”。

    返回：(status, details, note)
    """
    try:
        from PIL import Image
        import numpy as np
    except ImportError:
        return "无", [], "（手印检测依赖 Pillow、numpy 未安装，跳过）"
    try:
        im = Image.open(image_path).convert("RGB")
    except Exception as e:
        return "无", [], "（图片读取失败：%s）" % e
    im.thumbnail((1600, 1600))
    arr = np.asarray(im)
    h, w, _ = arr.shape
    r = arr[..., 0].astype(np.int16)
    g = arr[..., 1].astype(np.int16)
    b = arr[..., 2].astype(np.int16)
    gray = (r * 0.299 + g * 0.587 + b * 0.114).astype(np.uint8)
    red_mask = (r > 130) & (r - g > 40) & (r - b > 40)   # 印泥红
    ink_mask = (gray < 90)                                 # 墨色
    mask = red_mask | ink_mask
    lab, n = _connected_components(mask)
    short_side = min(h, w)
    details = []
    for cid in range(1, n + 1):
        ys, xs = np.where(lab == cid)
        if len(ys) < 150:
            continue
        y0, y1 = int(ys.min()), int(ys.max()) + 1
        x0, x1 = int(xs.min()), int(xs.max()) + 1
        bh, bw = y1 - y0, x1 - x0
        area = len(ys)
        area_ratio = area / (h * w)
        bbox_area = bh * bw
        fill_ratio = area / bbox_area if bbox_area else 0.0
        diag = float(np.hypot(bh, bw))
        # 指印典型尺寸：直径约为图像短边 4%~25%（对应 1 至 2 厘米捺印，扫描分辨率不同有浮动）
        size_ok = 0.04 * short_side <= diag <= 0.25 * short_side
        if not size_ok:
            continue
        smooth, cross = _ridge_consistency(gray, max(0, y0 - 2), min(h, y1 + 2),
                                           max(0, x0 - 2), min(w, x1 + 2))
        # 规则层全部标记“疑似”：纯规则无法可靠区分指纹与印章文字、规则纹样
        # （脊线方向度量对两类相近），最终“有”由视觉模型复核或人工确认，
        # 避免把印章误报为手印；区域几何与纹理数据仍输出供复核定位。
        details.append({
            "位置": "左上(%d,%d) 宽%d 高%d" % (x0, y0, bw, bh),
            "面积占比": "%.1f%%" % (area_ratio * 100),
            "填充率": round(fill_ratio, 2),
            "纹线一致性": round(smooth, 2),
            "交叉块占比": round(cross, 2),
            "判定": "疑似",
        })
    if details:
        status = "疑似"   # 规则层两态：疑似（需 VLM 复核或人工确认）／无
    else:
        status = "无"
    return status, details, FINGERPRINT_BOUNDARY


def _desensitize_vlm_image(image_path, crop_box=None):
    """外发前图片脱敏预处理（v8.10.3）：
      · crop_box=(x0,y0,x1,y1) 给出疑似捺印区域 → 仅裁剪该区域（最小化外发内容，整图文字/人脸不外发）；
      · 无 crop_box 但 Pillow 可用 → 整图高斯模糊（图内文字、人脸等可读信息模糊不可辨）；
      · Pillow 不可用或图片处理异常（无脱敏能力）→ **拒绝外发**（返回 (None, 'refused:…')），
        由调用方告警并降级规则层结果——v8.10.20 起取消“整帧原始字节外发（fullframe）”回退路径，
        杜绝身份证/签名/人脸等像素级 PII 无掩码裸传。
    返回 (b64_str, mode)，mode ∈ {cropped, blurred}；不可脱敏时 b64 为 None。
    """
    import base64
    try:
        from PIL import Image, ImageFilter
        import io as _io
        im = Image.open(image_path).convert('RGB')
        if crop_box is not None:
            x0, y0, x1, y1 = crop_box
            pad = 8
            x0 = max(0, x0 - pad); y0 = max(0, y0 - pad)
            x1 = min(im.width, x1 + pad); y1 = min(im.height, y1 + pad)
            im = im.crop((x0, y0, x1, y1))
            mode = 'cropped'
        else:
            im = im.filter(ImageFilter.GaussianBlur(radius=25))
            mode = 'blurred'
        buf = _io.BytesIO()
        im.save(buf, format='JPEG', quality=70)
        return base64.b64encode(buf.getvalue()).decode(), mode
    except Exception as _e:
        # v8.10.20（P1-5 整改）：原实现回退“整帧原始字节外发”（mode='fullframe'，无像素掩码），
        # 存在身份证/签名/人脸像素级 PII 裸传路径；现改为**无脱敏能力即不外发**。
        return None, 'refused: %s' % type(_e).__name__


def vlm_fingerprint_check(image_path, api_key=None, crop_box=None):
    """可选 VLM 精判：智谱 glm-4v-flash（国内主链路、免费模型）复核规则结果。

    数据外发声明：图片将发送至智谱 AI 视觉模型用于捺印复核，
    调用方须已获当事人书面授权（与实时转写外发同合规框架）。
    ⚠️ 图片像素本身可能含**无法文字脱敏**的 PII（身份证件、手写签名、印章、人脸、表格内笔迹），
    v8.10.20 起：脱敏能力不可用（Pillow 缺失或图片处理异常）时**一律拒绝外发**、降级规则层结果；脱敏可用时按裁剪／整图模糊后的图像外发（不再有整帧裸传）。确认前仍须先本地核验图片内容，必要时对敏感区域先行打码（v8.10.14 图片PII告知）。
    未配置 ZHIPU_API_KEY / 依赖缺失 / 调用失败时返回 None（降级规则结果，不阻断）。
    """
    api_key = api_key or os.environ.get("ZHIPU_API_KEY")
    if not api_key:
        return None
    try:
        from openai import OpenAI
        import base64  # noqa: F401  (实际 base64 在 _desensitize_vlm_image 内)
    except ImportError:
        return None
    # v8.10.3：大小上限（MAX_UPLOAD）——超限不发送、降级规则层，与音频通道同口径
    size_mb = os.path.getsize(image_path) / (1024.0 * 1024.0)
    if size_mb > VLM_MAX_UPLOAD_MB:
        vlm_audit("拒绝外发：%.1fMB 超 VLM 上限 %dMB，未发送、降级规则层"
                  % (size_mb, VLM_MAX_UPLOAD_MB), image_path, size_mb)
        return None
    try:
        client = OpenAI(api_key=api_key, base_url="https://open.bigmodel.cn/api/paas/v4", timeout=30)
        b64, dmode = _desensitize_vlm_image(image_path, crop_box)
        if not b64:   # v8.10.20：无脱敏能力 → 拒绝外发，降级规则层
            vlm_audit("拒绝外发：无脱敏能力（Pillow 不可用或图片处理异常），未发送、降级规则层（%s）"
                      % dmode, image_path, size_mb)
            return None
        _dmode_txt = {"cropped": "裁剪捺印目标区域后", "blurred": "整图模糊后"}[dmode]
        vlm_audit("外发开始：%s base64 发送至智谱视觉模型（手印三态复核）" % _dmode_txt, image_path, size_mb)
        resp = client.chat.completions.create(
            model="glm-4v-flash",
            messages=[{
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + b64}},
                    {"type": "text", "text": "请检查这张证据图片的落款、签名附近是否有指纹捺印（手印）。只回答三态之一：有、无、疑似，并给出位置与依据。若图片无手印特征请明确回答无。"},
                ],
            }],
            max_tokens=200,
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        vlm_audit("外发失败（已降级规则结果）：%s" % type(e).__name__, image_path)
        return None


def extract_signals(text):
    """从抽取文本中识别对办案有用的关键信号（金额 / 日期 / 人名 / 案号 / 条款）。"""
    signals = {"金额": [], "日期": [], "案号": [], "关键条款": []}
    for m in re.finditer(r"[\d,]+(?:\.\d+)?\s*(?:元|万元|万|人民币|￥|RMB)", text):
        s = m.group(0).strip()
        if s not in signals["金额"]:
            signals["金额"].append(s)
    for m in re.finditer(r"\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日|\d{4}[-.]\d{1,2}[-.]\d{1,2}", text):
        s = m.group(0).strip()
        if s not in signals["日期"]:
            signals["日期"].append(s)
    for m in re.finditer(r"[（(]\d{4}[）)][\u4e00-\u9fa5]{2,8}\d+号", text):
        s = m.group(0).strip()
        if s not in signals["案号"]:
            signals["案号"].append(s)
    for m in re.finditer(r"第[一二三四五六七八九十百零\d]+条(?:第[一二三四五六七八九十\d]+款)?", text):
        s = m.group(0).strip()
        if s not in signals["关键条款"]:
            signals["关键条款"].append(s)
    return signals


def signals_to_md(signals):
    lines = []
    for k, v in signals.items():
        if v:
            lines.append(f"- **{k}**：" + "；".join(v[:20]))
    return "\n".join(lines) if lines else "- （未识别到明显金额 / 日期 / 案号信号）"


# ----------------------------------------------------------------------------
# 前置检查
# ----------------------------------------------------------------------------
def precheck(path, max_size_mb):
    """返回 (ok, 错误说明)。文件不存在 / 无权限 / 扩展名为空 / 超限均结构化报错。"""
    if not os.path.exists(path):
        return False, "文件不存在：%s" % path
    if not os.path.isfile(path):
        return False, "不是文件：%s" % path
    if not os.access(path, os.R_OK):
        return False, "无读取权限：%s" % path
    if not os.path.splitext(path)[1]:
        return False, "文件缺少扩展名，无法识别类型；请补齐扩展名或改传支持格式"
    size_mb = os.path.getsize(path) / (1024 * 1024)
    if size_mb > max_size_mb:
        return False, ("文件过大：%.1fMB 超过上限 %dMB；请压缩后上传或分段处理"
                       % (size_mb, max_size_mb))
    return True, ""


# ----------------------------------------------------------------------------
# 各类型解析器（延迟导入，缺依赖即降级）
# ----------------------------------------------------------------------------
def parse_pdf(path):
    """优先 fitz 抽文字层；无文字层则逐页 easyocr（临时页面走 tempfile）。"""
    text_parts = []
    method = "fitz(文字层)"
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(path)
        for i, page in enumerate(doc):
            txt = page.get_text().strip()
            if not txt:
                pix = page.get_pixmap(dpi=200)
                with tempfile.TemporaryDirectory(prefix="legal_ocr_") as td:
                    img_path = os.path.join(td, f"_tmp_page_{i}.png")
                    pix.save(img_path)
                    txt = ocr_image(img_path)
                method = "fitz+easyocr(扫描件)"
            text_parts.append(f"【第 {i+1} 页】\n{txt}")
        return "\n\n".join(text_parts), method
    except ImportError:
        pass
    try:
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            for i, page in enumerate(pdf.pages):
                text_parts.append(f"【第 {i+1} 页】\n{page.extract_text() or ''}")
        return "\n\n".join(text_parts), "pdfplumber"
    except ImportError:
        return "", "PDF解析依赖缺失（fitz/pdfplumber 均未安装）：pip install PyMuPDF"


def ocr_image(path):
    """用 easyocr 抽取图片文字。"""
    try:
        import easyocr  # 模型包国内网络受限时：手动下载 model text_image/ 与 detection/recognition 权重放入 ~/.EasyOCR/model 后重试
    except ImportError:
        return "（OCR 依赖 easyocr 未安装，无法识别图片文字；请安装后重试或上传文字稿）"
    # 中文、非 ASCII 路径兼容（v6.4.0 修正）：cv2.imread 不支持非 ASCII 路径，
    # 中文文件名（如“借条.png”）会读图失败——PIL 读取（支持中文路径）后转存 ASCII 临时路径再 OCR。
    ocr_path = path
    tmp = None
    try:
        path.encode("ascii")
    except UnicodeEncodeError:
        try:
            from PIL import Image
            import tempfile
            tmp = tempfile.NamedTemporaryFile(prefix="legal_ocr_", suffix=".png", delete=False)
            tmp.close()
            with Image.open(path) as im:
                im.save(tmp.name, "PNG")
            ocr_path = tmp.name
        except Exception:
            ocr_path = path  # 转换失败则按原路径尝试（可能仍失败，但保留报错信息）
    reader = easyocr.Reader(["ch_sim", "en"], gpu=False)
    try:
        result = reader.readtext(ocr_path, detail=0, paragraph=True)
        return "\n".join(result).strip()
    finally:
        if tmp is not None:
            try:
                os.unlink(tmp.name)
            except Exception:
                pass


def parse_image(path):
    return ocr_image(path), "easyocr"


def parse_heic(path):
    """pillow-heif 转 PNG（临时文件）后 OCR。"""
    try:
        from pillow_heif import register_heif_opener
        register_heif_opener()
        from PIL import Image
    except ImportError:
        return "", "HEIC 解析依赖缺失（pillow-heif / Pillow 未安装）：pip install pillow-heif"
    try:
        with tempfile.TemporaryDirectory(prefix="legal_heic_") as td:
            png_path = os.path.join(td, "conv.png")
            with Image.open(path) as im:
                im.save(png_path, "PNG")
            text = ocr_image(png_path)
        return text, "pillow-heif+easyocr"
    except Exception as e:
        return "", "HEIC 解析失败：%s（请先用手机、系统自带工具转成 jpg/png 后上传）" % e


def parse_text(path):
    """编码探测（utf-8 优先，gbk 兜底）后直读。"""
    for enc in ("utf-8-sig", "utf-8", "gbk"):
        try:
            with open(path, "r", encoding=enc) as f:
                return f.read(), "纯文本直读(%s)" % enc
        except (UnicodeDecodeError, OSError):
            continue
    return "", "文本解码失败（尝试 utf-8 / gbk 均失败），请转成 txt 后上传"


def parse_docx(path):
    """python-docx 抽取段落与表格；docx2txt 备选。.doc 老格式提示转换。"""
    if path.lower().endswith(".doc"):
        return "", "旧版 .doc 请先用 WPS / Office 另存为 .docx 后上传（解析更可靠）"
    try:
        import docx
    except ImportError:
        pass
    else:
        try:
            d = docx.Document(path)
            parts = []
            for p in d.paragraphs:
                if p.text.strip():
                    parts.append(p.text.strip())
            for t in d.tables:
                for row in t.rows:
                    cells = [c.text.strip().replace("\n", " ") for c in row.cells]
                    parts.append(" | ".join(cells))
            return "\n".join(parts), "python-docx(含表格)"
        except Exception as e:
            return "", "Word 解析失败：%s（文件可能损坏，请另存为 .docx 或 txt 后重试）" % e
    try:
        import docx2txt
        text = docx2txt.process(path)
        return text or "", "docx2txt"
    except ImportError:
        return "", "Word 解析依赖缺失（python-docx/docx2txt 均未安装）：pip install python-docx"


def parse_xlsx(path):
    """openpyxl（.xlsx）/ xlrd（.xls），含 sheet 名与单元格。"""
    parts = []
    method = ""
    if path.lower().endswith(".xls"):
        try:
            import xlrd
        except ImportError:
            return "", "Excel .xls 解析依赖缺失（xlrd 未安装）：pip install xlrd；或用 WPS 另存为 .xlsx"
        try:
            wb = xlrd.open_workbook(path)
            for sh in wb.sheets():
                parts.append("【工作表】%s" % sh.name)
                for r in range(min(sh.nrows, 2000)):
                    row = [str(sh.cell_value(r, c)).strip() for c in range(sh.ncols)]
                    parts.append(" | ".join(x for x in row if x))
            return "\n".join(parts), "xlrd(含sheet)"
        except Exception as e:
            return "", "Excel .xls 解析失败：%s" % e
    try:
        import openpyxl
    except ImportError:
        return "", "Excel 解析依赖缺失（openpyxl 未安装）：pip install openpyxl"
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        for ws in wb.worksheets:
            parts.append("【工作表】%s" % ws.title)
            for row in ws.iter_rows(values_only=True):
                cells = [str(c).strip() for c in row if c is not None and str(c).strip()]
                if cells:
                    parts.append(" | ".join(cells))
        return "\n".join(parts), "openpyxl(含sheet)"
    except Exception as e:
        return "", "Excel 解析失败：%s（文件可能损坏、加密，请检查后重试）" % e


def parse_pptx(path):
    """python-pptx 抽取文本框 / 表格 / 备注。"""
    if path.lower().endswith(".ppt"):
        return "", "旧版 .ppt 请先用 WPS / Office 另存为 .pptx 后上传（解析更可靠）"
    try:
        from pptx import Presentation
    except ImportError:
        return "", "PPT 解析依赖缺失（python-pptx 未安装）：pip install python-pptx"
    try:
        prs = Presentation(path)
        parts = []
        for i, slide in enumerate(prs.slides, 1):
            parts.append("【幻灯片 %d】" % i)
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        t = "".join(r.text for r in para.runs).strip()
                        if t:
                            parts.append(t)
                if getattr(shape, "has_table", False) and shape.has_table:
                    for row in shape.table.rows:
                        cells = [c.text.strip() for c in row.cells]
                        parts.append(" | ".join(cells))
            if slide.has_notes_slide:
                nt = slide.notes_slide.notes_text_frame.text.strip()
                if nt:
                    parts.append("【备注】%s" % nt)
        return "\n".join(parts), "python-pptx(含表格、备注)"
    except Exception as e:
        return "", "PPT 解析失败：%s（文件可能损坏，请另存为 .pptx 后重试）" % e


def parse_html(path):
    """BeautifulSoup 抽取正文与表格。"""
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        return "", "HTML 解析依赖缺失（beautifulsoup4 未安装）：pip install beautifulsoup4"
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            soup = BeautifulSoup(f.read(), "html.parser")
        parts = []
        for t in soup.find_all(["h1", "h2", "h3", "p", "li"]):
            s = t.get_text(strip=True)
            if s:
                parts.append(s)
        for tbl in soup.find_all("table"):
            for tr in tbl.find_all("tr"):
                cells = [td.get_text(strip=True) for td in tr.find_all(["td", "th"])]
                if cells:
                    parts.append(" | ".join(cells))
        return "\n".join(parts), "BeautifulSoup(正文+表格)"
    except Exception as e:
        return "", "HTML 解析失败：%s" % e


def _probe_whisper_backend():
    """统一探测可用的 whisper 后端（v8.10.7 复用 voice_transcribe.probe_whisper()，
    以 faster-whisper 为主路；跨模块导入不可用时本模块内联兜底，保证降级路径可达）。"""
    try:
        from voice_transcribe import probe_whisper
        return probe_whisper()
    except Exception:  # noqa: BLE001  # voice_transcribe 不可导入时内联兜底
        pass
    try:
        from faster_whisper import WhisperModel
        return "faster-whisper", WhisperModel
    except ImportError:
        pass
    try:
        import whisper
        return "openai-whisper", whisper
    except ImportError:
        return None, None


def _whisper_transcribe(backend, mod, path, lang="zh"):
    """按选定后端把音频转成纯文本（faster-whisper 主路 / openai-whisper 兼容）。"""
    if backend == "faster-whisper":
        model = mod("base", device="cpu", compute_type="int8")
        segments, _info = model.transcribe(path, beam_size=5)
        return "".join(seg.text for seg in segments).strip()
    model = mod.load_model("base")
    return model.transcribe(path, language=lang).get("text", "")


def parse_audio(path):
    """语音转写：复用 voice_transcribe 统一探测（faster-whisper 主路），缺依赖降级。"""
    backend, mod = _probe_whisper_backend()
    if not backend:
        return "", "语音转写依赖未安装（pip install faster-whisper，或 openai-whisper）：见 scripts/install_deps.py --audio"
    try:
        return _whisper_transcribe(backend, mod, path), "%s(base)" % backend
    except Exception as e:  # ffmpeg 缺失 / 模型下载失败等均降级
        return "", "语音转写失败：%s（多为 ffmpeg 缺失或模型未下载；请先用其他工具转文字稿后上传）" % e


def parse_video(path):
    """ffmpeg 抽音轨（临时 wav）后统一 whisper 转写（faster-whisper 主路）。"""
    if not shutil.which("ffmpeg"):
        return "", "视频解析依赖缺失（ffmpeg 未安装）；可先自行抽取音频转文字稿后上传"
    backend, mod = _probe_whisper_backend()
    if not backend:
        return "", "视频解析依赖缺失（faster-whisper / openai-whisper 未安装）：pip install faster-whisper"
    try:
        with tempfile.TemporaryDirectory(prefix="legal_video_") as td:
            wav = os.path.join(td, "audio.wav")
            r = shutil.which("ffmpeg")
            import subprocess
            subprocess.run([r, "-y", "-i", path, "-ar", "16000", "-ac", "1", wav],
                           capture_output=True, timeout=600)
            text = _whisper_transcribe(backend, mod, wav)
        return text, "ffmpeg抽音轨+%s" % backend
    except Exception as e:
        return "", "视频转写失败：%s（可自行转文字稿后上传）" % e


def parse_zip(path, mask_map, max_size_mb):
    """安全解包（防 zip-slip）后递归解析支持类型，结束后清理。"""
    try:
        import zipfile
        zf = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        return "", "压缩包损坏或不是 zip 文件，请重新压缩后上传"
    except RuntimeError as e:
        if "encrypted" in str(e).lower():
            return "", "压缩包已加密，无法解析；请先解压后上传内部文件"
        return "", "压缩包打开失败：%s" % e
    except Exception as e:
        return "", "压缩包打开失败：%s" % e

    blocks = []
    method = "zip安全解包"
    with tempfile.TemporaryDirectory(prefix="legal_zip_") as td:
        try:
            for info in zf.infolist():
                # zip-slip 防护：规范化后必须仍在目标目录内
                target = os.path.normpath(os.path.join(td, info.filename))
                if not target.startswith(os.path.normpath(td) + os.sep) and target != os.path.normpath(td):
                    return "", "压缩包包含不安全路径（zip-slip 风险），已拒绝解析"
            zf.extractall(td)
        except RuntimeError as e:
            if "encrypted" in str(e).lower():
                return "", "压缩包已加密，无法解析；请先解压后上传内部文件"
            return "", "解包失败：%s" % e
        except Exception as e:
            return "", "解包失败：%s" % e

        for root, _dirs, files in os.walk(td):
            for fn in sorted(files):
                fp = os.path.join(root, fn)
                ok, errmsg = precheck(fp, max_size_mb)
                if not ok:
                    blocks.append("【%s】%s" % (fn, errmsg))
                    continue
                md = ingest_one(fp, mask_map, max_size_mb, _from_zip=True)
                blocks.append("【%s】\n%s" % (fn, md))
    return "\n\n---\n\n".join(blocks), method


def parse_eml(path):
    """标准库 email 提取正文与附件清单。"""
    try:
        import email
        from email import policy
        with open(path, "rb") as f:
            msg = email.message_from_binary_file(f, policy=policy.default)
        parts = []
        if msg.get("From"):
            parts.append("发件人：%s" % msg.get("From"))
        if msg.get("To"):
            parts.append("收件人：%s" % msg.get("To"))
        if msg.get("Subject"):
            parts.append("主题：%s" % msg.get("Subject"))
        if msg.get("Date"):
            parts.append("时间：%s" % msg.get("Date"))
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                try:
                    body = part.get_content()
                    if body.strip():
                        parts.append(body.strip())
                except Exception:
                    pass
            if part.get_filename():
                parts.append("【附件】%s" % part.get_filename())
        return "\n".join(parts), "email标准库(正文+附件清单)"
    except Exception as e:
        return "", "邮件解析失败：%s" % e


# ----------------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------------
def ingest_one(path, mask_map, max_size_mb=DEFAULT_MAX_SIZE_MB, _from_zip=False, vlm_check=False):
    ok, errmsg = precheck(path, max_size_mb)
    if not ok:
        kind = "处理失败"
        method = errmsg
        text = ""
        fp_md = ""
    else:
        ext = os.path.splitext(path)[1].lower()
        kind = EXT_MAP.get(ext, "不支持类型")
        text, method = "", "未处理"
        fp_md = ""
        if ext == ".pdf":
            text, method = parse_pdf(path)
        elif ext in (".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".webp"):
            image_bio_warning(path)
            text, method = parse_image(path)
            fp_md = fingerprint_md(path, vlm_check)
        elif ext in (".heic", ".heif"):
            text, method = parse_heic(path)
        elif ext in (".txt", ".md", ".csv"):
            text, method = parse_text(path)
        elif ext in (".docx", ".doc"):
            text, method = parse_docx(path)
        elif ext in (".xlsx", ".xls"):
            text, method = parse_xlsx(path)
        elif ext in (".pptx", ".ppt"):
            text, method = parse_pptx(path)
        elif ext in (".html", ".htm"):
            text, method = parse_html(path)
        elif ext in (".mp3", ".wav", ".m4a", ".ogg", ".flac"):
            text, method = parse_audio(path)
        elif ext in (".mp4", ".mov", ".avi", ".mkv"):
            text, method = parse_video(path)
        elif ext == ".zip":
            text, method = parse_zip(path, mask_map, max_size_mb)
        elif ext == ".eml":
            text, method = parse_eml(path)
        else:
            kind = "不支持类型"
            method = ("扩展名 %s 暂不支持。支持：%s。可尝试：%s"
                      % (ext, " / ".join(sorted(EXT_MAP)), " ".join(UNKNOWN_ADVICE)))

    text = mask_text(text, mask_map)
    signals = extract_signals(text)
    md = f"""## 📎 多模态材料解析结果

- **材料类型**：{kind}
- **文件名**：{os.path.basename(path)}
- **解析方式**：{method}
- **解析时间**：{now_stamp()}

### 一、抽取文本

{text if text.strip() else '（未能抽取到文字内容，请检查材料或改传文字稿）'}

### 二、关键信号（自动抽取，供 87 案卷精读 / 39 案情承接使用）

{signals_to_md(signals)}
{fp_md}
### 三、下一步建议

- 若为证据材料：将上方文本粘贴或转交“87-案卷精读防漏技能”生成要件事实—证据矩阵；
- 若含案情陈述：将上方文本交“39-案件承接与委托”生成《案情确认书》；
- 敏感人名已按 --mask-names 脱敏，正式使用前请由承办律师核对原文。
"""
    return md


def fingerprint_md(image_path, vlm_check=False):
    """手印三态检测结果转 Markdown 节（图片材料专用，v6.4.0）。

    规则层输出两态（疑似／无）；开启 --vlm-check 且规则判“疑似”时，
    调智谱视觉模型复核，由模型给出最终三态（有／无／疑似）。
    """
    status, details, note = detect_fingerprint(image_path)
    vlm_line = ""
    final_status = status
    if vlm_check and status == "疑似":
        crop_box = None
        if details:
            _m = re.search(r"左上\((\d+),(\d+)\) 宽(\d+) 高(\d+)", details[0].get("位置", ""))
            if _m:
                _x0, _y0, _w, _h = (int(g) for g in _m.groups())
                crop_box = (_x0, _y0, _x0 + _w, _y0 + _h)
        vlm_res = vlm_fingerprint_check(image_path, crop_box=crop_box)
        if vlm_res:
            if "有" in vlm_res[:2] and "无" not in vlm_res[:4]:
                final_status = "有"
            elif "无" in vlm_res[:2]:
                final_status = "无"
            vlm_line = "\n- **视觉模型复核**（智谱视觉版，国内主链路）：%s" % vlm_res.strip()
    if not details:
        detail_line = "- 未检测到疑似指印区域。"
    else:
        rows = "；".join(
            "%s（%s，填充率 %s，纹线一致性 %s，交叉块 %s）" % (d["位置"], d["判定"], d["填充率"], d["纹线一致性"], d["交叉块占比"])
            for d in details)
        detail_line = "- 疑似区域：%s" % rows
    return f"""

### 四、手印捺印检测（v6.4.0，三态）

- **检测结果**：{final_status}{vlm_line}
{detail_line}
- **边界声明**：{note}"""


def print_supported():
    print("律师助手 · 多模态材料解析支持格式矩阵（--supported）")
    print("=" * 74)
    for kind, exts, method, deps in SUPPORTED:
        print("  %-12s %-32s %s" % (kind, " ".join(exts), method))
        print("  %-12s %-32s 依赖：%s" % ("", "", deps))
    print("=" * 74)
    print("未知格式提示：返回支持清单 + 三个可执行建议（转 PDF/截图、粘贴文字）。")
    print("缺依赖原则：不假装成功，明确提示安装命令或替代上传方式（--max-size-mb 默认 %dMB）。"
          % DEFAULT_MAX_SIZE_MB)


def self_test():
    """生成零依赖样例（txt/csv）+ 已装依赖样例（docx/xlsx），验证解析链路。"""
    import subprocess
    ok_all = True
    with tempfile.TemporaryDirectory(prefix="legal_selftest_") as td:
        samples = []
        # 零依赖样例
        txt = os.path.join(td, "样例.txt")
        with open(txt, "w", encoding="utf-8") as f:
            f.write("借款合同纠纷：张三于2024年3月1日向李四借款50000元，约定月息1%，2024年9月1日到期，欠款至今未还。")
        samples.append(txt)
        csv = os.path.join(td, "流水.csv")
        with open(csv, "w", encoding="utf-8") as f:
            f.write("日期,金额,备注\n2024-03-01,50000,借款\n2024-06-01,10000,利息\n")
        samples.append(csv)
        # 依赖样例（依赖存在才生成）
        try:
            import docx
            d = os.path.join(td, "样例.docx")
            doc = docx.Document()
            doc.add_paragraph("起诉状：原告张三，被告李四，诉讼请求：返还借款50000元。")
            doc.save(d)
            samples.append(d)
        except ImportError:
            pass
        try:
            import openpyxl
            x = os.path.join(td, "流水.xlsx")
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.append(["日期", "金额"])
            ws.append(["2024-03-01", 50000])
            wb.save(x)
            samples.append(x)
        except ImportError:
            pass

        for fp in samples:
            r = subprocess.run([sys.executable, __file__, fp, "--max-size-mb", "50"],
                               capture_output=True, text=True, encoding="utf-8", errors="replace",
                               timeout=120)
            if r.returncode != 0 or "处理失败" in r.stdout or "依赖缺失" in r.stdout:
                ok_all = False
                print("  ❌ %s" % os.path.basename(fp))
                print("     " + (r.stderr or r.stdout)[-200:].replace("\n", "\n     "))
            else:
                print("  ✅ %s 解析链路正常" % os.path.basename(fp))
    # v8.11.0（P1-5 守护）：无脱敏能力即拒绝外发——对不可解析图片须返回 (None, 'refused:…')，
    # 严禁回退整帧原始字节（原 fullframe 裸传路径已删除）。有无 Pillow 两种环境下均成立。
    try:
        _b, _m = _desensitize_vlm_image(os.path.join(td, "不存在的图片.png"), None)
        _refused_ok = (_b is None) and str(_m).startswith("refused")
    except Exception:
        _refused_ok = False
    if _refused_ok:
        print("  ✅ 无脱敏能力即拒绝外发（refused 分支，未回退整帧裸传）")
    else:
        ok_all = False
        print("  ❌ refused 拒发分支异常：未按 (None,'refused:…') 返回")
    # v8.11.12（HTML-D27 整改）：图片脱敏**三态逐态单测**（blurred／cropped／refused 各 1 条）。
    # refused 态已在上方以不可解析路径实测；此处补 blurred／cropped 两态——以合成图实测
    # 返回值与态名，闭合"三态仅判据留档、无逐态样例"的诚实缺口。缺 Pillow 时按依赖缺失 SKIP，
    # 不计失败（与上方 refused 分支同源的降级口径）。
    try:
        from PIL import Image as _Image3
        import tempfile as _tf3
        import shutil as _sh3
        _d3 = _tf3.mkdtemp(prefix="legal_selftest_vlm3_")
        try:
            _p3 = os.path.join(_d3, "三态单测合成图.png")
            _Image3.new("RGB", (120, 80), (230, 230, 230)).save(_p3)
            _b_blur, _m_blur = _desensitize_vlm_image(_p3, None)
            _b_crop, _m_crop = _desensitize_vlm_image(_p3, (10, 10, 60, 50))
        finally:
            _sh3.rmtree(_d3, ignore_errors=True)
        if (_b_blur is not None and _m_blur == "blurred") and (_b_crop is not None and _m_crop == "cropped"):
            print("  ✅ 三态单测：blurred／cropped 分支返回态正确（合成图实测，对应 UT-01／UT-02）")
        else:
            ok_all = False
            print("  ❌ 三态单测异常：blurred=%s／cropped=%s（期望 blurred／cropped）" % (_m_blur, _m_crop))
    except Exception:
        print("  [SKIP] 三态单测 blurred／cropped（缺 Pillow；refused 态已在上方实测）")
    print("self-test %s" % ("全部通过" if ok_all else "存在降级项（对应依赖缺失，按需安装）"))
    return 0 if ok_all else 2


def main():
    ap = argparse.ArgumentParser(description="多模态材料解析（图片/OCR/PDF/Office/音视频、压缩包、邮件 -> Markdown）")
    ap.add_argument("path", nargs="?", help="材料文件或目录")
    ap.add_argument("--out", help="输出 Markdown 路径（默认打印到 stdout）")
    ap.add_argument("--mask-names", default="",
                    help='脱敏映射，如 "赵振福=产权人甲,张三=甲方"')
    ap.add_argument("--lang", default="ch_sim", help="OCR 语言（默认 ch_sim）")
    ap.add_argument("--max-size-mb", type=int, default=DEFAULT_MAX_SIZE_MB,
                    help="单文件大小上限（MB）")
    ap.add_argument("--vlm-check", action="store_true",
                    help="手印检测启用视觉模型复核（需已配置 ZHIPU_API_KEY；图片将外发至智谱视觉模型，须已获当事人书面授权；默认拒绝，需交互确认或 --yes-vlm 放行）")
    ap.add_argument("--yes-vlm", action="store_true",
                    help="跳过 VLM 外发的交互确认（仅在已确认获得当事人书面授权时使用）")
    ap.add_argument("--supported", action="store_true", help="输出支持格式矩阵")
    ap.add_argument("--self-test", action="store_true", help="生成样例并验证解析链路")
    args = ap.parse_args()

    # v6.6.0 评测 V15 整改：VLM 外发运行时逐次确认门（范式对齐 realtime_transcribe 双确认）
    if args.vlm_check and not args.yes_vlm:
        try:
            from PIL import Image  # noqa: F401
            _desens_txt = "脱敏能力可用：将裁剪捺印目标区域或整图模糊后再外发（非整帧）"
        except ImportError:
            _desens_txt = "脱敏能力不可用：本次将【拒绝外发】、仅用规则层结果（不上传任何图片）"
        print("⚠️ 数据外发确认：--vlm-check 会把证据图片发送至智谱视觉模型（open.bigmodel.cn）用于手印复核，"
              "%s。图片可能含当事人个人信息，请确认已获当事人书面授权。" % _desens_txt, file=sys.stderr)
        try:
            if not sys.stdin.isatty():
                raise EOFError
            ans = input("确认发送？[y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            ans = ""
            print("（非交互环境默认拒绝外发；已获授权请加 --yes-vlm 重跑）", file=sys.stderr)
        if ans != "y":
            args.vlm_check = False
            vlm_audit("用户拒绝启用VLM外发（已降级纯本地规则层）", "—")
            print("已关闭视觉模型复核，继续纯本地规则层检测。", file=sys.stderr)

    if args.supported:
        print_supported()
        sys.exit(0)
    if args.self_test:
        sys.exit(self_test())
    if not args.path:
        ap.error("缺少必选参数 path（或使用 --supported / --self-test）")

    mask_map = {}
    for pair in [p for p in args.mask_names.split(",") if p]:
        if "=" in pair:
            k, v = pair.split("=", 1)
            mask_map[k.strip()] = v.strip()

    files = []
    if os.path.isdir(args.path):
        for f in sorted(os.listdir(args.path)):
            files.append(os.path.join(args.path, f))
    else:
        files.append(args.path)

    blocks = []
    for fp in files:
        if os.path.isfile(fp):
            blocks.append(ingest_one(fp, mask_map, args.max_size_mb, vlm_check=args.vlm_check))

    full = "\n\n---\n\n".join(blocks)
    # PII 自动扫描（v5.0.1 起）：输出、落盘前对全文做身份证、手机号、银行账户脱敏
    hits = sorted(set(pii_scan(full)))
    counts = pii_count(full)
    full = pii_mask_all(full)  # v8.10.3：结构化+姓名、住址、案号全量脱敏
    if hits:
        detail = "/".join("%s%d处" % (name, counts.get(name, 0)) for name in hits)
        print("[PII自动脱敏] 检测到完整个人信息（%s），已自动脱敏后输出、导出" % detail, file=sys.stderr)
    hints = [name for pat, name in NONSTRUCTURED_HINTS if re.search(pat, full)]
    if hints:
        print("[PII提示] 文本含非结构化敏感信息（%s），建议按108号语音证据处理脱敏声明执行LLM层语义脱敏" % "/".join(hints), file=sys.stderr)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(full)
        print(f"已写出：{args.out}（{len(blocks)} 份材料）")
    else:
        print(full)


if __name__ == "__main__":
    try:
        main()
    except FileNotFoundError as e:
        print(f"❌ 文件未找到：{e.filename}")
        print("💡 建议：检查路径，或将文件拖到对话框上传")
        sys.exit(1)
    except zipfile.BadZipFile:
        print("❌ 压缩包损坏")
        print("💡 建议：重新压缩或逐个上传文件")
        sys.exit(1)
    except MemoryError:
        print("❌ 文件过大，超出处理能力")
        print("💡 建议：压缩或分割后上传")
        sys.exit(1)
    except Exception as e:
        print("⚠️ 文件处理异常，已自动降级")
        print(f"💡 替代方案：截图上传 / 转PDF / 直接粘贴文字内容")
        print(f"📦 如需要完整功能：python scripts/install_deps.py --all")
        sys.exit(1)
