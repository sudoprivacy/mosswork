# pii_filter.py: 运行时依赖脚本（技能运行调用）
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pii_filter.py — PII 脱敏共享模块（v5.3.0 建立；v8.10.1 修双计 + 增上下文锚定脱敏）

本模块为 scripts/ 目录下所有脚本的唯一 PII 正则来源，消除复制粘贴导致的口径不一致。

结构化 PII 统一口径（v5.3.0）：
  - 身份证号：18 位（17 位数字 + 末位数字/X/x），前后无数字邻接
  - 手机号：1[3-9] 开头的 11 位数字，前后无数字邻接
  - 银行账户：16-19 位连续数字，前后无数字邻接
  - 脱敏替换：统一为 ****

v8.10.1 变更（第三方评测 P15 整改）：
  ① pii_count 双计修正——18 位身份证号同时满足“银行账户 16-19 位”模式，原实现双计为
     “身份证号 + 银行账户”。现按 PII_PATTERNS 顺序消费命中区间：同一串只计一次，
     优先归类为身份证号（身份证模式更具体）。pii_scan / pii_mask 语义不变（守卫与单测兼容）。
  ② 新增上下文锚定的非结构化 PII 兜底（PII_CTX_PATTERNS）：姓名 / 住址 / 案号。
     口径刻意收窄——只在“字段名或角色标签 + 值”形态上命中（如“原告：张三”“住址：…”），
     不做全文本宽松匹配，避免误伤法条、机构名与模板正文；代词与占位符（本人/双方/某某等）不掩码。
     输出侧统一入口 pii_mask_all()（结构化 + 上下文）。

使用方式（其他脚本 import）：
  from pii_filter import pii_scan, pii_mask, pii_count, PII_PATTERNS          # 结构化
  from pii_filter import pii_ctx_scan, pii_ctx_mask, pii_mask_all            # 非结构化（输出侧兜底）

  hits = pii_scan(text)             # 结构化命中类型列表
  counts = pii_count(text)          # {类型: 命中次数}（同串不双计）
  masked = pii_mask(text)           # 结构化脱敏
  masked_all = pii_mask_all(text)   # 结构化 + 姓名/住址/案号 全量脱敏

注：姓名、住址的**语义级**判断仍以 LLM 层规则为主（见 references/自检证明与测试摘要.md 第七章）；
本模块新增加的上下文锚定规则是**脚本级兜底**，用于输出前防漏检，不替代 LLM 层脱敏。
"""

import re

# ── 统一结构化 PII 正则（v5.3.0：6 个脚本共用此口径）──
# 口径来源：markdown_to_docx.py / multimodal_ingest.py 的 PII_PATTERNS（最严格版，
# 含前后断言 (?<![0-9]) / (?![0-9]) 防止误匹配长数字子串）
PII_PATTERNS = [
    (r"(?<![0-9])[0-9]{17}[0-9Xx](?![0-9])", "身份证号"),
    (r"(?<![0-9])1[3-9][0-9]{9}(?![0-9])", "手机号"),
    (r"(?<![0-9])[0-9]{16,19}(?![0-9])", "银行账户"),
    (r"(?<![0-9A-Za-z._%+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![0-9A-Za-z.-])", "邮箱"),
    (r"[\u4e00-\u9fff][A-HJ-NP-Z][A-HJ-NP-Z0-9]{4,5}[A-HJ-NP-Z0-9\u6302\u5b66\u8b66\u6e2f\u6fb3]", "车牌号"),
]

# 脱敏替换正则（与原 markdown_to_docx / voice_transcribe / realtime_transcribe 的 pii_mask 一致）
_MASK_RE = re.compile(r"(?<![0-9A-Za-z])(?:[0-9]{17}[0-9Xx]|[0-9]{11,})(?![0-9A-Za-z])")
# v8.11.2：邮箱与车牌号脱敏（与 PII_PATTERNS 新增两项同口径）
_MASK_RE2 = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"
                       r"|[\u4e00-\u9fff][A-HJ-NP-Z][A-HJ-NP-Z0-9]{4,5}[A-HJ-NP-Z0-9\u6302\u5b66\u8b66\u6e2f\u6fb3]")

# ── 上下文锚定非结构化 PII 正则（v8.10.1 新增：脚本级兜底，刻意收窄防误伤）──
_FIELD = r"(?:案号|案件编号|住址|住所地|住所|户籍地|户籍所在地|居住地|现住址|现住地址|" \
         r"姓名|当事人|原告|被告|第三人|申请人|被申请人|委托人|委托代理人|代理人|辩护人|" \
         r"证人|被害人|犯罪嫌疑人|被告人|上诉人|被上诉人|债权人|债务人|法定代表人|监护人)"
# 姓名类字段（角色标签）与住址类字段分开，避免字段表混用产生歧义匹配
_NAME_FIELD = r"(?:姓名|当事人|原告|被告|第三人|申请人|被申请人|委托人|委托代理人|代理人|辩护人|" \
              r"证人|被害人|犯罪嫌疑人|被告人|上诉人|被上诉人|债权人|债务人|法定代表人|监护人)"
_ADDR_FIELD = r"(?:住址|住所地|户籍地|户籍所在地|居住地|现住址|现住地址|送达地址)"
# 字段名与值之间允许 markdown 粗体星号，且**必须带冒号**（收窄口径，防误伤正文）
_SEP = r"(?P<b>\*{0,2})(?P<s>[：:])"
PII_CTX_PATTERNS = [
    # 案号：形如“（2026）鲁0691民初1234号”（年度＋法院代字＋法院序号＋案件类型＋序号）
    (r"(?P<v>[（(]\s*\d{4}\s*[）)][\u4e00-\u9fa5]{0,4}\d{0,6}[\u4e00-\u9fa5]{0,6}\d{1,6}号)", "案号"),
    # 住址：字段名锚定＋值须含地址标记词，遇标点即止（防把整句吞掉）
    (r"(?P<f>" + _ADDR_FIELD + r")" + _SEP +
     r"(?P<v>[\u4e00-\u9fa5\d]{2,30}(?:省|市|区|县|旗|路|街|巷|道|号|弄|栋|幢|楼|室|组|村|镇|小区|社区)"
     r"[\u4e00-\u9fa5\d]{0,15})(?=[，。；、\n]|$)", "住址"),
    # 姓名：字段名锚定＋2-4 字中文姓名，后接标点或行尾
    (r"(?P<f>" + _NAME_FIELD + r")" + _SEP +
     r"(?P<v>[\u4e00-\u9fa5]{2,4})(?=[\s，。；：、（）()*]|$)", "姓名"),
]
# 代词 / 占位符 / 非姓名词：命中不掩码（防把“本人”“双方”“某某”等当姓名）
_CTX_SKIP = {"本人", "双方", "对方", "本方", "他方", "无", "待定", "未知", "不明", "佚名",
             "某某", "若干", "多人", "一人", "全权", "特别", "一般", "见下", "同上", "如上",
             "以下简称", "以下同", "原告方", "被告方", "其他", "详见", "如附件"}


def pii_scan(text):
    """PII 扫描：命中完整个人信息返回命中类型列表；未命中返回空列表。"""
    return [name for pat, name in PII_PATTERNS if re.search(pat, text)]


def pii_count(text):
    """统计各类结构化 PII 命中次数（v5.3.0 D27：脱敏行为可见化，输出、导出前打印统计）。

    v8.10.1 修双计：按 PII_PATTERNS 顺序消费命中区间——同一串只计一次、优先归类为身份证号。
    （原实现用 findall 逐模式独立计数，18 位身份证号会被“银行账户 16-19 位”模式重复计入。）
    """
    rest = text
    out = {}
    for pat, name in PII_PATTERNS:
        hits = list(re.finditer(pat, rest))
        out[name] = len(hits)
        for m in reversed(hits):  # 自后向前等长空白占位：消除已计串，保持其余模式偏移有效
            rest = rest[:m.start()] + " " * (m.end() - m.start()) + rest[m.end():]
    return out


def pii_mask(text):
    """身份证（18 位）/ 手机号（11 位）/ 银行账户（16-19 位）整体替换为 ****。"""
    return _MASK_RE2.sub("****", _MASK_RE.sub("****", text))


def has_pii(text):
    """是否含结构化 PII（快捷判断，不统计类型）。"""
    return bool(pii_scan(text))


def pii_ctx_scan(text):
    """上下文锚定非结构化 PII 扫描：返回命中类型列表（案号、住址、姓名）。"""
    return sorted({name for pat, name in PII_CTX_PATTERNS if re.search(pat, text)})


def pii_ctx_count(text):
    """上下文锚定非结构化 PII 计数（跳过代词与占位符，与 pii_ctx_mask 同口径）。"""
    out = {}
    for pat, name in PII_CTX_PATTERNS:
        n = 0
        for m in re.finditer(pat, text):
            val = m.groupdict().get("v") or m.group(0)
            if name == "姓名" and val in _CTX_SKIP:
                continue
            n += 1
        out[name] = n
    return out


def pii_ctx_mask(text):
    """上下文锚定非结构化 PII 掩码：案号、住址、姓名 → ****（保留字段名前缀，代词与占位符不掩码）。"""
    out = text
    for pat, name in PII_CTX_PATTERNS:
        def _rep(m, _name=name):
            gd = m.groupdict()
            val = gd.get("v") or m.group(0)
            if _name == "姓名" and val in _CTX_SKIP:
                return m.group(0)
            return (gd.get("f") or "") + (gd.get("b") or "") + (gd.get("s") or "") + "****"
        out = re.sub(pat, _rep, out)
    return out


MASK_TOKEN = "****"            # 标准脱敏记号（数据层统一口径，v5.3.0）
MASK_TOKEN_MD = "＊＊＊＊"       # markdown 安全等价记号：半角 **** 会被 markdown 粗体解析吞掉
                               # （2026-09-26 端到端实测发现：docx 产物里 **** 消失、无法看出已脱敏）


def pii_mask_all(text):
    """输出侧统一脱敏入口：结构化 PII + 上下文锚定非结构化 PII（姓名、住址、案号）。"""
    return pii_ctx_mask(pii_mask(text))


def markdown_safe(text):
    """把脱敏记号转为 markdown 安全形态（供 md→docx 等 markdown 渲染路径调用）。

    保留可见记号：半角 **** 在 markdown 中是粗体定界符，渲染后会被吞掉（原 v5.3.0 口径
    在 docx 产物中即存在此现象）；全角 ＊＊＊＊ 不是 markdown 定界符，可原样显示。
    """
    return text.replace(MASK_TOKEN, MASK_TOKEN_MD)


if __name__ == "__main__":
    import sys
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except (AttributeError, ValueError):
        pass
    _sys = sys
    if any(a in ("-h", "--help") for a in _sys.argv[1:]):
        print("用法：pii_filter 为共享脱敏模块，供其他脚本 import 使用"
              "（pii_scan / pii_mask / pii_count / pii_ctx_scan / pii_ctx_mask / pii_mask_all / markdown_safe）；"
              "无独立命令行操作。")
        _sys.exit(0)
    print(__doc__)
