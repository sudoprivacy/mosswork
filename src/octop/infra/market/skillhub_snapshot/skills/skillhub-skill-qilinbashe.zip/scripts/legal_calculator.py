#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
legal_calculator.py —— 期限时效与利息确定性计算器（合并版）
v8.3.0 新增（P1 借鉴点落地 · 自研实现，仅标准库）

定位：
  76-期限与时效计算器 的脚本侧出口。确定性计算，杜绝模型心算误差。

子命令：
  limit     期限时效：python scripts/legal_calculator.py limit <起算日> --type <类型> [--interrupt]
            --type: ordinary/labor_arb/admin_suit/appeal15/appeal10/enforce/
                    guarantee/work_injury/wage/quality2/divorce_prop/bankruptcy_claim
                    （中文键：再审／复议／优先受偿／冷静期／撤销仲裁裁决／不予执行仲裁；共 18 键，与脚本 TYPES 一致）
  interest  借贷利息分段：python scripts/legal_calculator.py interest --principal 50000
            --intra-rate 0.06 --intra-start 2024-03-01 --intra-end 2024-09-01
            --overdue-rate lpr1|lpr4|<数值> --overdue-end 2026-09-07 --lpr 0.0345
            [--segments 0.0355:51,0.0345:315 逐段计息]
  selftest  固定用例断言（doctor REG-066 冒烟用）

口径（与 76 号文档一致，法条基线以 96 号核验为准）：
  普通诉讼时效 3 年（民法典 188 条）；劳动仲裁 1 年（调解仲裁法 27 条）；
  行政起诉 6 个月（行政诉讼法 46 条）；上诉期 15/10 日（民诉法 171 条）；
  申请执行 2 年（民诉法 250 条）；保证期间 6 个月（民法典 692 条）；
  工伤认定 1 年（工伤保险条例 17 条）；欠薪 1 年（劳动争议调解仲裁法第27条——劳动关系存续期间
  不受一年限制，终止的自劳动关系终止之日起一年内；《保障农民工工资支付条例》第16条为清偿义务规定，
  非时效依据）；
  质量异议期 2 年（民法典第621条第2款；对标的物有质量保证期的，适用质量保证期，不适用该二年规定）；离婚后财产 3 年（诉讼时效依民法典 188 条；
  隐藏／转移共同财产的少分不分、再次分割实体依据见民法典 1092 条）。
  期限届满日一律“按日历”计算（datetime 加年/月，届满日为对应日，跨闰年不偏一天），
  并在输出 basis 依据行写明起算日与届满日；上诉期等以“日”计的期间仍按自然日相加。
  中断/中止：--interrupt 视为中断重算（成立与否由律师依证据判断，民法典 195 条）；
  除斥／不变期间（保证期间、离婚冷静期、申请再审、上诉期、建设工程价款优先受偿、质量异议期、撤销仲裁裁决）
  不适用中止、
  中断、延长，脚本对该类到期项直出“不发生中止、中断、延长，逾期权利消灭”。
  利息：年利率默认 365 天换算；期内约定利率与逾期利率均以“合同成立时一年期 LPR 四倍”
  为上限，超出部分不予支持（期内约定利率见民间借贷司法解释第25条，逾期利率见第28条第1款），字符串与数值传入一律生效，
  并在 note 写明封顶后的利率与封顶依据；砍头息按实际出借金额认定（民法典 670 条）。
  LPR 值须由调用方/用户提供（行情以全国银行间同业拆借中心公布为准），脚本不做行情猜测。

输出：单行 JSON。退出码：0 正常；1 参数错误。
"""
import json
import sys
from calendar import monthrange
from datetime import date, datetime, timedelta
import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# ── limit 子命令：期限类型表（key: (中文名, (单位, 数量), 法条口径)）──
# 单位：d=日（自然日相加）；m=个月、y=年（均按日历，届满日为对应日，跨闰年不偏一天）
TYPES = {
    "bankruptcy_claim": ("债权确认之诉", ("d", 15), "企业破产法第58条＋法释〔2019〕3号第8条：十五日（债权人会议核查结束之日起）"),
    "撤销仲裁裁决":   ("撤销仲裁裁决申请", ("m", 3), "仲裁法〔2025修订〕第72条：三个月（收到裁决书之日起，不变期间）"),
    "不予执行仲裁":   ("不予执行仲裁裁决申请", ("d", 15), "法释〔2018〕5号第8条：十五日（收到执行通知书之日起）"),
    "再审":       ("申请再审期限", ("m", 6), "民诉法第216条：六个月"),
    "复议":       ("行政复议申请", ("d", 60), "行政复议法第20条：六十日"),
    "优先受偿":   ("建设工程价款优先受偿", ("m", 18), "建工解释一第41条：十八个月"),
    "冷静期":     ("离婚冷静期", ("d", 30), "民法典第1077条：三十日"),

    "ordinary":   ("普通诉讼时效", ("y", 3), "民法典第188条：3年"),
    "labor_arb":  ("劳动仲裁时效", ("y", 1), "劳动争议调解仲裁法第27条：1年"),
    "admin_suit": ("行政诉讼", ("m", 6), "行政诉讼法第46条：6个月"),
    "appeal15":   ("民事上诉期", ("d", 15), "民诉法第171条：判决15日"),
    "appeal10":   ("裁定上诉期", ("d", 10), "民诉法第171条：裁定10日"),
    "enforce":    ("申请执行期", ("y", 2), "民诉法第250条：2年"),
    "guarantee":  ("保证期间", ("m", 6), "民法典第692条：6个月（约定优先）"),
    "work_injury":("工伤认定申请", ("y", 1), "工伤保险条例第17条：1年"),
    "wage":       ("欠薪支付请求", ("y", 1), "劳动争议调解仲裁法第27条：1年（在职不受限，终止后一年内）"),
    "quality2":   ("质量异议期", ("y", 2), "民法典第621条第2款：2年（对标的物有质量保证期的，适用质量保证期，不适用该二年规定）"),
    "divorce_prop":("离婚后财产纠纷", ("y", 3),
                    "民法典第188条：3年（诉讼时效；少分不分实体依据见第1092条）"),
}

_DATE_FMT = "%Y-%m-%d"
DAYS_PER_YEAR = 365  # 利息默认；合同约定 360 天可传 --days-per-year 360

_UNIT_CN = {"d": "日", "m": "个月", "y": "年"}


def _parse(s):
    try:
        return datetime.strptime(s, _DATE_FMT).date()
    except ValueError:
        raise ValueError("日期格式须为 YYYY-MM-DD，当前值：%r（为空表示日期参数未传或传了空值；limit 子命令请传起算日，interest 子命令请检查 --intra-start／--intra-end／--overdue-end）" % s)


def _add_months(d, months):
    """按日历加月：月末对齐（如 1-31 加 1 月 → 2-28/2-29）。"""
    y = d.year + (d.month - 1 + months) // 12
    m = (d.month - 1 + months) % 12 + 1
    day = min(d.day, monthrange(y, m)[1])
    return date(y, m, day)


def _add_period(d, unit, n):
    """按日历加期间：日=自然日相加；月/年=对应日（跨闰年不偏一天）。"""
    if unit == "d":
        return d + timedelta(days=n)
    if unit == "m":
        return _add_months(d, n)
    if unit == "y":
        return _add_months(d, n * 12)
    raise ValueError("未知期间单位: %s" % unit)


# ── limit 子命令 ──

def calc_limit(start_date, type_key, today=None, interrupt=False):
    import holiday_cn  # 延迟导入：is_workday 判定届满日是否逢节假日需顺延
    if type_key not in TYPES:
        raise ValueError("未知期限类型: %s（可选: %s）" % (type_key, "/".join(TYPES)))
    name, (unit, n), law = TYPES[type_key]
    start = _parse(start_date)
    today = today or date.today()
    due = _add_period(start, unit, n)
    days_left = (due - today).days
    expired = days_left < 0
    if interrupt:
        note = ("已登记时效中断：本条仅登记中断事实，due 仍按原起算日推算，**须以中断成立之日"
                "（重新起算日）作为起算日重新调用本脚本取值**；中断成立与否由律师依证据判断（民法典第195条）")
    elif expired:
        # v8.10.19：除斥／不变期间不适用中止、中断，不得误导律师去检索中断事由
        if type_key in ("guarantee", "冷静期", "再审", "优先受偿", "quality2", "撤销仲裁裁决"):
            note = ("已过期 %d 天；该期间为除斥／不变期间，不发生中止、中断、延长，"
                    "逾期权利消灭（%s）" % (abs(days_left), law))
        elif type_key in ("appeal15", "appeal10"):
            # v8.11.0（同类扫描补正）：上诉期同属法定不变期间，原实现误挂“需核查中止、中断事由”
            note = ("已过期 %d 天；上诉期为法定不变期间，不发生中止、中断、延长"
                    "（届满日为法定休假日的顺延至休假日后的第一日；不可归责于己的耽误依法另行救济）（%s）"
                    % (abs(days_left), law))
        elif type_key == "bankruptcy_claim":
            # v8.11.2：债权确认之诉十五日系督促及时起诉的法定期间，非诉讼时效/除斥期间/起诉期限，不适用中止中断
            note = ("已逾期 %d 天；该十五日系督促及时起诉的法定期间，非诉讼时效、除斥期间或起诉期限，"
                    "超期不当然消灭诉权（%s）" % (abs(days_left), law))
        elif type_key in ("admin_suit", "work_injury", "复议", "不予执行仲裁"):
            # v8.11.4：起诉／申请期限非诉讼时效，不适用中止、中断，套用会误导律师去找不存在的中断事由
            note = ("已过期 %d 天；该期间为法定的起诉／申请期限，非诉讼时效，不适用中止、中断（%s）"
                    % (abs(days_left), law))
        else:
            note = "已过期 %d 天，需核查中止、中断事由" % abs(days_left)
    else:
        note = "剩余 %d 天" % days_left
    basis = "起算日 %s，按日历加 %d%s → 名义届满日 %s（跨闰年不偏一天）；%s；末日逢法定节假日须另行顺延，最终截止日以顺延后首个工作日为准（见 holiday_cn.py，deadline 字段＝名义届满日）" % (
        start.isoformat(), n, _UNIT_CN[unit], due.isoformat(), law)
    return {
        "ok": True, "type": name, "law": law, "start": start.isoformat(),
        "due": due.isoformat(), "deadline": due.isoformat(), "days_left": max(days_left, 0),
        "expired": expired, "interrupt": interrupt, "note": note,
        "needs_holiday_adjustment": (not holiday_cn.is_workday(due))
        if holiday_cn.coverage_level(due) == "exact" else None,
        "coverage": holiday_cn.coverage_level(due),
        "coverage_note": holiday_cn.coverage_note(due),
        "basis": basis,
    }


def _cmd_limit(argv):
    # v8.11.2：子命令级 --help（原 `limit --help` 会把 --help 当起算日解析报错）
    if any(a in ("-h", "--help") for a in argv):
        print(__doc__)
        return 0
    # v8.4.0 修复：start 应取 argv[0]（子命令已由 main 剥离）。原取 argv[1] 导致
    # 真实 CLI 调用 `limit <起算日> --type <类型>` 把 "--type" 当日期解析报错——
    # 函数级 selftest 直调 calc_limit 未覆盖 CLI 解析层，v8.4.0 正确性回归集首跑抓获。
    if len(argv) < 1:
        print(__doc__)
        return 1
    start = argv[0]
    # v8.13.2：limit 同 interest 加参数白名单（未知参数报错，不再静默忽略），并支持 --key=value
    _VALID = ("type", "today", "interrupt")
    type_key = None
    today_arg = None
    interrupt = False
    i = 1
    while i < len(argv):
        tok = argv[i]
        if not tok.startswith("-"):
            print(json.dumps({"ok": False, "error": "无法识别的参数：%s（应为 --key value 或 --key=value）" % tok}, ensure_ascii=False))
            return 1
        k = tok.lstrip("-")
        if "=" in tok:
            k, v = tok.split("=", 1)
            k = k.lstrip("-")
        elif k == "interrupt":
            v = "1"
        else:
            if i + 1 >= len(argv):
                print(json.dumps({"ok": False, "error": "参数 --%s 缺少值" % k}, ensure_ascii=False))
                return 1
            v = argv[i + 1]
            i += 1
        if k not in _VALID:
            print(json.dumps({"ok": False, "error": "未知参数 --%s（limit 支持：起算日位置参数，--type/--today/--interrupt）" % k}, ensure_ascii=False))
            return 1
        if k == "type":
            type_key = v
        elif k == "today":
            today_arg = v
        elif k == "interrupt":
            interrupt = True
        i += 1
    if not type_key:
        print(json.dumps({"ok": False, "error": "缺少 --type 期限类型"}, ensure_ascii=False))
        return 1
    try:
        res = calc_limit(start, type_key, today=_parse(today_arg) if today_arg else None,
                         interrupt=interrupt)
    except ValueError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        return 1
    print(json.dumps(res, ensure_ascii=False))
    return 0


# ── interest 子命令 ──

def calc_interest(principal, intra_rate, intra_start, intra_end,
                  overdue_rate, overdue_end, lpr, days_per_year=DAYS_PER_YEAR,
                  overdue_segments=None):
    """分段利息计算。overdue_rate: 'lpr1'|'lpr4'|数值年利率。
    overdue_segments: [(年利率小数, 天数), ...] 逐段计息（LPR 逐期变动场景），传入时忽略 overdue_rate，
    各段天数之和须等于逾期天数；每段各自执行四倍封顶校验。
    天数一律“含首含尾”：期内段＝起息日至到期日（含两端），逾期段＝到期日次日至清偿当日（含两端），两段无重叠、无缝隙、不丢日。

    利率上限（v8.10.6 修正为真生效）：期内约定利率与逾期利率均以“合同成立时一年期
    LPR 的四倍”为上限，超出部分不计息（期内约定利率见民间借贷司法解释第25条，逾期利率见第28条第1款）；字符串与数值传入
    一律生效，note 写明封顶后的利率与封顶依据。函数签名与返回字段保持不变。
    """
    if principal <= 0:
        raise ValueError("本金须大于 0")
    if not (0 <= intra_rate <= 1):
        raise ValueError("期内年利率须为 0-1 之间的小数（如 0.06 = 6%）")
    if not (0 <= lpr < 1):
        raise ValueError("一年期 LPR 须为 0-1 之间的小数（如 0.0345 即年利率百分之三点四五），"
                         "当前值 %r 疑似按百分数书写，请除以 100" % lpr)
    start = _parse(intra_start)
    end = _parse(intra_end)
    if end < start:
        raise ValueError("期内结束日早于开始日")
    end_date = _parse(overdue_end)
    if end_date < end:
        raise ValueError("逾期结束日早于期内结束日")

    def days(a, b):
        return (b - a).days

    lpr_cap = round(lpr * 4, 4)
    # v8.10.6：未提供一年期 LPR（或为 0）时不执行四倍封顶——否则 0×4 会把利息截为 0
    _cap_ok = lpr > 0
    note = []

    # 期内约定利率：以“合同成立时一年期 LPR 四倍”封顶，超出部分不计息
    eff_intra_rate = intra_rate
    if _cap_ok and eff_intra_rate > lpr_cap:
        eff_intra_rate = lpr_cap
        note.append("期内约定利率 %.2f%% 超过 LPR 四倍上限，已按 %.2f%%（=LPR %.2f%%×4）"
                    "封顶计息，超出部分不予支持（民间借贷司法解释第25条）"
                    % (intra_rate * 100, lpr_cap * 100, lpr * 100))

    intra_days = days(start, end) + 1  # 含首含尾：起息日至到期日（到期当日计入期内段，不与逾期段重叠、不丢日）
    intra_interest = round(principal * eff_intra_rate / days_per_year * intra_days, 2)

    overdue_start = end + timedelta(days=1)
    # v8.10.19：逾期段含首含尾（含清偿当日），与期内段同口径；原不含 end_date 致末端少算一天
    overdue_days = (days(overdue_start, end_date) + 1) if end_date >= overdue_start else 0
    # v8.11.4：逾期段取 lpr1/lpr4 但未提供 --lpr（或为 0）时，lpr_cap＝round(0*4,4)＝0 会把逾期
    #   利息静默算成 0（ok:true、note“无”）；期内段 v8.10.6 已有 _cap_ok 防护，本条补齐逾期段同一道门。
    if overdue_segments:
        if sum(int(_d) for _r, _d in overdue_segments) != overdue_days:
            raise ValueError("逾期分段天数合计 %d ≠ 逾期总天数 %d（可先跑一次不分段取总天数）" % (sum(int(_d) for _r, _d in overdue_segments), overdue_days))
        _parts = []
        for _r, _d in overdue_segments:
            _fr = float(_r)
            if not (0 <= _fr <= 1):
                raise ValueError("分段利率须为 0-1 之间的小数（0.0345 即年利率百分之三点四五），"
                                 "当前值 %r 疑似按百分数书写，请除以 100" % _r)
            _e = min(_fr, lpr_cap) if _cap_ok else _fr
            if _cap_ok and _fr > lpr_cap:
                note.append("分段利率超 LPR 四倍，已按 %.2f%% 封顶（民间借贷司法解释第28条第1款）" % (lpr_cap * 100))
            _parts.append(round(principal * _e / days_per_year * int(_d), 2))
        eff_rate = None
        overdue_interest = round(sum(_parts), 2)
    else:
        if isinstance(overdue_rate, str) and overdue_rate in ("lpr1", "lpr4") and lpr <= 0:
            raise ValueError("逾期利率取 lpr1/lpr4 时须先提供 --lpr（一年期 LPR），否则逾期段将被静默算成 0")
        if isinstance(overdue_rate, str):
            if overdue_rate == "lpr1":
                eff_rate = lpr
            elif overdue_rate == "lpr4":
                eff_rate = lpr_cap
            else:
                raise ValueError("未知逾期利率: %s（lpr1/lpr4/数值）" % overdue_rate)
        else:
            eff_rate = overdue_rate
            if not (0 <= eff_rate <= 1):
                raise ValueError("逾期年利率须为 0-1 之间的小数（如 0.06 即年利率百分之六），"
                                 "当前值 %r 疑似按百分数书写，请除以 100" % overdue_rate)
            if not _cap_ok and overdue_days:
                note.append("未提供一年期 LPR（--lpr），逾期段未执行四倍封顶校验")
        # 逾期利率同样以 LPR 四倍封顶（字符串 lpr4 本身等于上限，数值超限则封顶）
        if _cap_ok and eff_rate > lpr_cap:
            eff_rate = lpr_cap
            note.append("逾期利率超过 LPR 四倍上限，已按 %.2f%%（=LPR %.2f%%×4）封顶计息，"
                        "超出部分不予支持（民间借贷司法解释第28条第1款）"
                        % (lpr_cap * 100, lpr * 100))
        overdue_interest = round(principal * eff_rate / days_per_year * overdue_days, 2)
    total = round(intra_interest + overdue_interest, 2)
    if overdue_days == 0:
        note.append("逾期天数为 0（未逾期或同日到期）")
    return {
        "ok": True,
        "principal": principal,
        "intra_interest": intra_interest,
        "overdue_interest": overdue_interest,
        "total": total,
        "intra_days": intra_days,
        "overdue_days": overdue_days,
        "lpr_cap": lpr_cap,
        "note": "；".join(note) or "无",
    }


def _cmd_interest(argv):
    # v8.11.2：子命令级 --help（原 `interest --help` 直接报“本金须大于 0”）
    if any(a in ("-h", "--help") for a in argv):
        print(__doc__)
        return 0
    _VALID = {
        "principal", "intra-rate", "intra_rate",
        "intra-start", "intra_start", "intra-end", "intra_end",
        "overdue-rate", "overdue_rate", "overdue-end", "overdue_end",
        "lpr", "segments", "days-per-year", "days_per_year",
    }
    args = {}
    i = 0
    while i < len(argv):
        tok = argv[i]
        if not tok.startswith("-"):
            print(json.dumps({"ok": False, "error": "无法识别的参数：%s（应为 --key value 或 --key=value）" % tok}, ensure_ascii=False))
            return 1
        if "=" in tok:
            k, v = tok.lstrip("-").split("=", 1)
        else:
            k = tok.lstrip("-")
            if i + 1 >= len(argv):
                print(json.dumps({"ok": False, "error": "参数 --%s 缺少值" % k}, ensure_ascii=False))
                return 1
            v = argv[i + 1]
            i += 1
        if k not in _VALID:
            print(json.dumps({"ok": False, "error": "未知参数 --%s（interest 支持：--%s）"
                              % (k, " --".join(sorted(_VALID)))}, ensure_ascii=False))
            return 1
        args[k] = v
        i += 1
    try:
        overdue = args.get("overdue-rate", args.get("overdue_rate", "lpr1"))
        if overdue not in ("lpr1", "lpr4"):
            overdue = float(overdue)
        _seg = args.get("segments")
        segs = None
        if _seg:
            segs = []
            for _p in _seg.split(","):
                if ":" not in _p:
                    raise ValueError("段格式须为 利率:天数，如 0.04:90（当前段 %r 缺少冒号）" % _p)
                _r, _d = _p.split(":")
                segs.append((float(_r), int(_d)))
        res = calc_interest(
            float(args.get("principal", 0)),
            float(args.get("intra-rate", args.get("intra_rate", 0))),
            args.get("intra-start", args.get("intra_start", "")),
            args.get("intra-end", args.get("intra_end", "")),
            overdue,
            args.get("overdue-end", args.get("overdue_end", "")),
            float(args.get("lpr", 0)),
            days_per_year=int(args.get("days-per-year", args.get("days_per_year", DAYS_PER_YEAR))),
            overdue_segments=segs,
        )
    except (ValueError, KeyError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        return 1
    print(json.dumps(res, ensure_ascii=False))
    return 0


# ── selftest（doctor REG-066 冒烟）──

def selftest():
    """固定用例断言：时效 5 组（含日历口径）＋利息 5 组（含 LPR 四倍封顶与单位反例）。"""
    # 时效：起算 2024-03-01 普通 3 年 → 按日历到期 2027-03-01 未过期
    r1 = calc_limit("2024-03-01", "ordinary", today=date(2026, 9, 7))
    assert r1["due"] == "2027-03-01" and not r1["expired"], r1
    # 时效：2023-01-01 上诉 15 日 → 到期 2023-01-16 已过期
    r2 = calc_limit("2023-01-01", "appeal15", today=date(2026, 9, 7))
    assert r2["expired"] and r2["due"] == "2023-01-16", r2
    # 时效：中断重算
    r3 = calc_limit("2024-03-01", "ordinary", today=date(2026, 9, 7), interrupt=True)
    assert r3["interrupt"] and r3["due"] == "2027-03-01", r3
    # 日历口径：2022-12-31 起 3 年 → 2025-12-31（旧 365×3 得 2025-12-30，闰年多算一天）
    r5 = calc_limit("2022-12-31", "ordinary", today=date(2026, 9, 7))
    assert r5["due"] == "2025-12-31", r5
    assert "2025-12-31" in r5["basis"] and "2022-12-31" in r5["basis"], r5
    # 日历口径：2023-01-31 起 1 个月 → 2023-02-28（月末对齐）
    assert _add_period(date(2023, 1, 31), "m", 1) == date(2023, 2, 28)
    # 顺延标志（ST1 P1-1 真判断）：末日逢周末 → True；末日为工作日 → False
    _r6 = calc_limit("2026-01-23", "appeal15", today=date(2026, 1, 1))  # 届满 2026-02-07 周六
    assert _r6["needs_holiday_adjustment"] is True, _r6
    _r7 = calc_limit("2026-01-05", "appeal15", today=date(2026, 1, 1))  # 届满 2026-01-20 周二
    assert _r7["needs_holiday_adjustment"] is False, _r7
    # 利息：5 万、期内 6% 半年、逾期 LPR 一倍
    r4 = calc_interest(50000, 0.06, "2024-03-01", "2024-09-01", "lpr1", "2026-09-07", 0.0345)
    assert r4["intra_days"] == 185, r4
    assert r4["intra_interest"] == round(50000 * 0.06 / 365 * 185, 2), r4
    assert r4["overdue_days"] == (date(2026, 9, 7) - date(2024, 9, 2)).days + 1, r4
    assert r4["lpr_cap"] == 0.138, r4
    assert abs(r4["total"] - round(r4["intra_interest"] + r4["overdue_interest"], 2)) < 0.01, r4
    # LPR 四倍封顶生效：期内 24%、逾期数值 24% 均 > 上限 12%，一律按 12% 计
    r6 = calc_interest(100000, 0.24, "2024-03-01", "2024-09-01", 0.24, "2024-12-31", 0.03)
    assert r6["lpr_cap"] == 0.12, r6
    assert r6["intra_interest"] == round(100000 * 0.12 / 365 * r6["intra_days"], 2), r6
    assert r6["intra_interest"] < round(100000 * 0.24 / 365 * r6["intra_days"], 2), r6
    assert "封顶" in r6["note"] and "第25条" in r6["note"], r6
    # 对照：期内 12% ≤ 上限 13.8% → 不封顶
    r7 = calc_interest(100000, 0.12, "2024-03-01", "2024-09-01", "lpr4", "2026-09-07", 0.0345)
    assert r7["intra_interest"] == round(100000 * 0.12 / 365 * 185, 2), r7
    assert "封顶" not in r7["note"], r7
    # segments 逐段计息：8 万、逾期 203 天拆 100+103 两段，两段利率均 ≤ LPR 四倍，不封顶（v8.13.1 P1 补）
    seg_parts = [round(80000 * _r / 365 * _d, 2) for _r, _d in [(0.0345, 100), (0.0285, 103)]]
    r8 = calc_interest(80000, 0.0, "2023-12-31", "2023-12-31", "lpr1", "2024-07-21", 0.0345,
                       overdue_segments=[(0.0345, 100), (0.0285, 103)])
    assert r8["overdue_days"] == 203, r8
    assert r8["overdue_interest"] == round(sum(seg_parts), 2), r8
    assert "封顶" not in r8["note"], r8
    # 单位错误反例：分段利率写成百分数 3.45 应被拒绝（v8.13.1 P1 修复）
    try:
        calc_interest(80000, 0.0, "2023-12-31", "2023-12-31", "lpr1", "2024-07-21", 0.0345,
                      overdue_segments=[(3.45, 100), (0.0285, 103)])
        raise AssertionError("百分数形式分段利率 3.45 未触发拒绝")
    except ValueError:
        pass
    # v8.13.2 P1-2：--lpr 百分数形式（3.45）与 --overdue-rate 数值百分数形式（24.0）应被拒绝
    try:
        calc_interest(100000, 0.0, "2024-01-01", "2024-01-01", "lpr1", "2024-12-31", 3.45)
        raise AssertionError("百分数形式 LPR 3.45 未触发拒绝")
    except ValueError:
        pass
    try:
        calc_interest(100000, 0.0, "2024-01-01", "2024-01-01", 24.0, "2024-12-31", 0.0345)
        raise AssertionError("百分数形式逾期利率 24.0 未触发拒绝")
    except ValueError:
        pass
    # v8.13.4 P1-N2：CLI 层冒烟（参数白名单防回潮；百分数/单位校验由函数级反例覆盖）
    import subprocess as _sp, os as _os
    assert "未知参数" in _sp.run([sys.executable, _os.path.abspath(__file__), "limit", "2025-03-01", "--type", "ordinary", "--bogus", "x"], capture_output=True, text=True, encoding="utf-8", env=dict(_os.environ, PYTHONDONTWRITEBYTECODE="1")).stdout
    print("OK 计算器冒烟：时效 5 组（ordinary/appeal15/interrupt/日历 2）"
          "＋利息 5 组（分段/期内逾期封顶/未超不封顶/segments 逐段＋单位反例/LPR 与逾期利率单位反例）"
          "＋CLI 层 1 组（未知参数白名单）全过")
    return 0


def main(argv):
    if not argv:
        print(__doc__)
        return 1
    if argv[0] in ("-h", "--help"):
        print("用法：python scripts/legal_calculator.py <limit|interest|selftest> […]（子命令与参数见下方说明）")
        print(__doc__)
        return 0
    cmd, rest = argv[0], argv[1:]
    if cmd == "selftest":
        return selftest()
    if cmd == "limit":
        return _cmd_limit(rest)
    if cmd == "interest":
        return _cmd_interest(rest)
    print("未知子命令：%s（支持 limit / interest / selftest）" % cmd)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
