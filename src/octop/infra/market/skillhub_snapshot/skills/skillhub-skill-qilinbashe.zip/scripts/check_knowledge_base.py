# check_knowledge_base.py: 运行时依赖脚本（技能运行调用）
# -*- coding: utf-8 -*-
"""
check_knowledge_base.py —— 可选增强资料（法律法规知识库）注入状态查询

v6.1.0 输出改版（评测·运行稳定性优化）：
  - 知识库是"可选增强"，未注入是正常降级状态，不是错误——输出不再使用 ❌ 报错样式，
    不再罗列本机绝对路径（避免暴露个人信息、避免"看起来像故障"）；
  - 除 --kb-dir 指向的目录无效外，一律退出码 0（信息型输出）；
  - 新增 --self-test：离线自校验（不读用户环境），供包内自检做命令链冒烟。

用法：
    python scripts/check_knowledge_base.py [--kb-dir 知识库根目录]
    python scripts/check_knowledge_base.py --self-test
    python scripts/check_knowledge_base.py --deep-list          # 列出本地深挖库可取的件
    python scripts/check_knowledge_base.py --mount-deep "件名" [--out 目录]   # 默认取件到 ~/.legal-skills/.deep_workspace/<件名>/

自动探测（按顺序，静默）：<技能包>/知识库、<技能包>/../知识库、
~/.hermes/knowledge/legal（--kb-dir 显式指定优先）。
"""
import os
import sys
import time
import json

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except (AttributeError, ValueError):
    pass

# 5 部可选增强资料（核心功能不依赖它们，包内离线法条库已兜底）
KB_ITEMS = [
    {"name": "离线法条全集", "file": "离线法条精华.md", "min_size": 50_000,
     "impact": "进一步扩充离线兜底法条的覆盖广度（包内第十三章核心法条兜底不受影响）"},
    {"name": "省域司法指引全集", "file": "省域司法指引.md", "min_size": 30_000,
     "impact": "区域化裁判口径参考（未注入时按全国口径输出并标注）"},
    {"name": "案例库全集", "file": "案例库.md", "min_size": 30_000,
     "impact": "更多实操案例参考（未注入时用包内 30+ 节示例库）"},
    {"name": "使用手册全集", "file": "使用手册.md", "min_size": 20_000,
     "impact": "图文版上手教程（未注入时看 README 与 FAQ 即可）"},
    {"name": "相关法规汇编", "file": "相关法规汇编.md", "min_size": 50_000,
     "impact": "跨领域法规检索广度（未注入时核心法条经包内速查索引兜底）"},
]


def probe_kb_dirs(src_dir):
    """探测候选知识库目录（返回绝对路径列表；仅内部使用，不对外打印完整路径）。"""
    home = os.path.expanduser("~")
    candidates = [
        os.path.join(src_dir, "知识库"),
        os.path.join(src_dir, "..", "知识库"),
        os.path.join(home, ".hermes", "knowledge", "legal"),
    ]
    return [os.path.abspath(p) for p in candidates]


def self_test():
    """离线自校验：不访问用户环境，验证判定逻辑与输出格式。"""
    assert len(KB_ITEMS) == 5, "应为 5 部可选资料"
    assert all(k["file"].endswith(".md") and k["min_size"] > 0 for k in KB_ITEMS)
    sample = render_status_block(found_dir=None, results=[(True, 60_000), (False, 0), (True, 5_000), (False, 0), (True, 10_000)])
    text = "\n".join(sample)
    for kw in ("不影响", "核心功能", "不是包损坏"):
        assert kw in text, "输出缺少要素: " + kw
    assert "❌" not in text, "输出不应出现报错样式"
    print("知识库校验脚本自校验通过（5 部资料定义 + 人话输出模板）。")
    return 0


def render_status_block(found_dir, results):
    """把注入结果渲染成人话状态卡。results: [(present_and_enough, size), ...]"""
    lines = []
    ok = sum(1 for p, _ in results if p)
    if found_dir is None:
        lines.append("★ 几份补充参考资料还没放进来，这是正常的，不是包损坏。案情分析、文书初稿、赔偿计算、法条核对都不受影响，可以直接用。")
        lines.append("【补充参考资料·状态】5 份扩充资料（离线法条全集、省域司法指引、案例库全集、使用手册、相关法规汇编）还没放进来。")
        lines.append("这不影响任何核心功能——案情分析、文书初稿、赔偿计算、法条核对（内置核心法条库）、期限提醒均可直接使用。")
        lines.append("想导入时说一声\u201c知识库导入\u201d，或放置资料后重跑本命令确认；也可以一直不导入，安心用核心功能。")
        return lines
    lines.append("【可选增强资料·注入状态】已导入 %d/5 部（目录已找到，内容完整度如下）：" % ok)
    for item, (present, size) in zip(KB_ITEMS, results):
        if present:
            lines.append("  · %s：可用（%d KB）" % (item["name"], size // 1024))
        elif size > 0:
            lines.append("  · %s：文件偏小，可能不完整——对应参考能力暂用内置备用方式（%s）" % (item["name"], item["impact"]))
        else:
            lines.append("  · %s：未导入——该能力用内置备用方式（%s）" % (item["name"], item["impact"]))
    if ok == len(KB_ITEMS):
        lines.append("全部就绪，增强能力全量可用。")
    else:
        lines.append("未导入的部分不影响核心功能，需要时再补即可。")
    return lines


# ===== v8.14.1：本地深挖库取件（按案由命中后取件到工作区）=====
DEEP_LIB_NAME = "律师助手技能包"      # 本地深挖库约定目录名（可用环境变量 LEGAL_DEEP_HOME 覆盖）
WORK_DIR_NAME = ".deep_workspace"
WORK_DIR_DEFAULT = os.path.join(os.path.expanduser("~"), ".legal-skills")


def probe_deep_dirs(src):
    """候选深挖库目录：环境变量优先，其次约定目录（不写死绝对路径）。"""
    cands = []
    env = os.environ.get("LEGAL_DEEP_HOME", "").strip()
    if env:
        cands.append(os.path.expanduser(env))
    cands.append(os.path.join(os.path.expanduser("~"), "Desktop", DEEP_LIB_NAME))
    cands.append(os.path.join(os.path.dirname(src), DEEP_LIB_NAME))
    cands.append(os.path.join(os.path.expanduser("~"), DEEP_LIB_NAME))
    out = []
    for c in cands:
        if c and os.path.isdir(c) and c not in out:
            out.append(c)
    return out


def deep_list():
    """列出本地深挖库可取的件（只读，不回显绝对路径）。"""
    import json
    for d in probe_deep_dirs(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))):
        names = sorted(f[:-4] for f in os.listdir(d) if f.lower().endswith(".zip"))
        if names:
            print(json.dumps({"ok": True, "count": len(names), "items": names}, ensure_ascii=False))
            return 0
    print(json.dumps({"ok": False, "reason": "deep_lib_not_found",
                      "hint": "本地深挖库未挂载：按未装配降级输出，不臆造成品件编号或数值",
                      "env": "LEGAL_DEEP_HOME"}, ensure_ascii=False))
    return 0


def mount_deep(name):
    """按件名取件：解包到工作区 <cwd>/.deep_workspace/<件名>/，返回 JSON（不含绝对路径）。"""
    import json
    import zipfile
    src = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    name = (name or "").strip()
    if not name:
        print(json.dumps({"ok": False, "reason": "empty_name"}, ensure_ascii=False))
        return 2
    for d in probe_deep_dirs(src):
        zp = os.path.join(d, name + ".zip")
        if not os.path.exists(zp):
            continue
        out_dir = os.path.join(os.getcwd(), WORK_DIR_NAME, name)
        os.makedirs(out_dir, exist_ok=True)
        files = []
        try:
            with zipfile.ZipFile(zp) as zf:
                for info in zf.infolist():
                    if info.filename.endswith("/"):
                        continue
                    fn = os.path.basename(info.filename)
                    if not fn or fn.startswith("."):
                        continue
                    target = os.path.join(out_dir, fn)
                    with open(target, "wb") as f:
                        f.write(zf.read(info.filename))
                    files.append(fn)
        except (OSError, zipfile.BadZipFile) as exc:
            print(json.dumps({"ok": False, "reason": "unzip_failed", "detail": str(exc)}, ensure_ascii=False))
            return 2
        print(json.dumps({"ok": True, "name": name, "workspace": os.path.join(WORK_DIR_NAME, name),
                          "files": files, "next": "读该目录内的主文件，按件内成品表/卡/演算与交接卡执行"},
                         ensure_ascii=False))
        return 0
    print(json.dumps({"ok": False, "reason": "piece_not_found", "name": name,
                      "hint": "该件未在本地深挖库中找到：按未装配降级输出，不臆造成造品件编号或数值",
                      "env": "LEGAL_DEEP_HOME"}, ensure_ascii=False))
    return 0



def main():
    if any(a in ("-h", "--help") for a in sys.argv[1:]):
        print(__doc__)
        sys.exit(0)
    if "--self-test" in sys.argv:
        sys.exit(self_test())
    if "--deep-list" in sys.argv:
        sys.exit(deep_list())
    if "--log-gap" in sys.argv:
        _i = sys.argv.index("--log-gap")
        _name = sys.argv[_i + 1] if _i + 1 < len(sys.argv) else ""
        if "--dry-run" in sys.argv:
            print("[gap][dry-run] 只统计不写盘：%s" % (_name or "未命名"))
            sys.exit(0)
        _d = os.path.join(os.path.expanduser("~"), ".legal-skills")
        os.makedirs(_d, exist_ok=True)
        with open(os.path.join(_d, "deep_gap.jsonl"), "a", encoding="utf-8") as _f:
            _f.write(json.dumps({"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "件": _name},
                                ensure_ascii=False) + "\n")
        print("[gap] 已记录待补缺口：%s（用于补齐优先级）" % (_name or "未命名"))
        sys.exit(0)
    if "--mount-deep" in sys.argv:
        _i = sys.argv.index("--mount-deep")
        _name = sys.argv[_i + 1] if _i + 1 < len(sys.argv) else ""
        sys.exit(mount_deep(_name))

    src = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    kb_dir = None
    explicit = False
    if "--kb-dir" in sys.argv:
        idx = sys.argv.index("--kb-dir")
        if idx + 1 < len(sys.argv):
            kb_dir = os.path.abspath(sys.argv[idx + 1])
            explicit = True

    if kb_dir is None:
        for cand in probe_kb_dirs(src):
            if os.path.isdir(cand):
                kb_dir = cand
                break

    if kb_dir is not None and not os.path.isdir(kb_dir):
        # 唯一按错误处理的情形：用户显式指定了无效目录
        print("您指定的资料目录暂时打不开，请确认路径后重试：python scripts/check_knowledge_base.py --kb-dir <目录>")
        sys.exit(1)

    if kb_dir is None:
        results = [(False, 0)] * len(KB_ITEMS)
        out = render_status_block(None, results)
    else:
        results = []
        for item in KB_ITEMS:
            fp = os.path.join(kb_dir, item["file"])
            size = os.path.getsize(fp) if os.path.exists(fp) else 0
            results.append((size >= item["min_size"], size))
        out = render_status_block(kb_dir, results)

    print("\n".join(out))
    sys.exit(0)


if __name__ == "__main__":
    main()
