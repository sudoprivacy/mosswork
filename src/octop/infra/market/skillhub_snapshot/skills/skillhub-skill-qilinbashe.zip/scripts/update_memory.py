# update_memory.py: 运行时依赖脚本（技能运行调用）
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""长期记忆写入与校验脚本（只记方法，不记案情）。

用法：
  python scripts/update_memory.py --check
  python scripts/update_memory.py --category 办案流程 --entry "可复用步骤：..."
  python scripts/update_memory.py --category 证据补强 --entry "..." --dry-run
  python scripts/update_memory.py --stat-dim hit=41 --stat-dim followup=2 --stat-dim fallback=radar
    （v8.1.0：运行时维度统计——案由命中/追问轮数/降级触发，
     与写入主流程解耦，可单独调用；值会按维度分桶进 usage_stats.json，
     供 feedback_mine --monthly 月报读取）

规则：
  1. 禁止写入 PII（身份证、手机号、银行卡等）；
  2. 禁止写入可识别案情的案号、客户姓名、具体金额等事实；
  3. 每次写入后自动执行 --check，发现敏感内容则拒绝写入；
  4. v4.21.0：写入前经 fuzzify() 数字模糊化（金额→量级、日期→相对时点、
     姓名→关系标签），与 SKILL.md 声明对齐；v7.9.0 修复执行顺序倒置
     （先模糊化、再 PII/案情检查，姓名分支由死代码恢复为可达）；
  5. v4.21.0：MEMORY.md 容量上限 MAX_ENTRIES（默认 500 条），超出按 FIFO
     淘汰最旧条目。
"""

import argparse
import os
import re
import sys
from datetime import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

# 兼容引导：确保本脚本目录进入 sys.path（嵌入式 Python 环境运行时脚本目录不自动入 path，
# pii_filter.py 同目录共享模块依赖此引导；v5.7.0 可移植性整改）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── PII 脱敏（v5.3.0 P1-3：结构化 PII 正则统一为共享模块 pii_filter.py）──
from pii_filter import PII_PATTERNS  # noqa: E402

PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ── 长期记忆路径（v8.9.0 修复 P1：不得落在包目录内）──
# 原实现 MEMORY_PATH = PKG_ROOT/“MEMORY.md”。后果：114 号办案复盘技能运行一次，即在包根写入
# MEMORY.md，提交包由 180 文件变 181 文件，随即触发 selfcheck 五连 FAIL——包文件数 180 锚、
# README 三处计数锚、REG-059 正文内联文件数计数、REG-074 交付集 AIGC 水印（脚本生成的
# MEMORY.md 无 AIGC 头，被算进交付集判水印），并级联 REG-051 摘要宣称 PASS 数失配；等于
# “装好即用一次、自检必崩”。亦与 README“MEMORY.md 已另存 IMA、不进包”的宣告相矛盾。
# 现与同文件 STATS_PATH 统一到用户目录 ~/.legal-skills/（统计文件早已落盘此处），
# 包目录只读化；包内若存有历史 MEMORY.md（源码侧），首次读取时兼容迁移，但一律不写回包内。
MEMORY_DIR = os.path.join(os.path.expanduser("~"), ".legal-skills")
MEMORY_PATH = os.path.join(MEMORY_DIR, "MEMORY.md")
LEGACY_MEMORY_PATH = os.path.join(PKG_ROOT, "MEMORY.md")


def resolve_memory_path():
    """读取用路径：优先用户目录；用户目录缺失而包内存在历史文档时兼容读取（只读不写回）。"""
    if os.path.isfile(MEMORY_PATH):
        return MEMORY_PATH
    if os.path.isfile(LEGACY_MEMORY_PATH):
        return LEGACY_MEMORY_PATH
    return MEMORY_PATH


def ensure_memory_dir():
    d = os.path.dirname(MEMORY_PATH)
    if d:
        os.makedirs(d, exist_ok=True)
CATEGORIES = ("办案流程", "证据补强", "发问规则", "质量闸门", "低分项整改", "方法论")
MAX_ENTRIES = 500
SECTION_MARKER = "## 最新迭代"
BS = chr(92)
D = BS + "d"

# v5.3.0 P1-3：PII_PATTERNS 已统一至 pii_filter.py（身份证、手机号、银行账户），
# 以下为 update_memory 专有的“案情事实”检测正则（非 PII，不进共享模块）。
FACT_PATTERNS = [
    (r"案号\s*[:：]?\s*[（(]?\d", "疑似具体案号"),
    (r"身份证号\s*[:：]?\s*\d{6,}", "疑似身份证字段"),
    (r"手机号\s*[:：]?\s*1[3-9]\d{9}", "疑似手机字段"),
    (r"银行卡\s*[:：]?\s*\d{6,}", "疑似银行卡字段"),
    (r"住址\s*[:：]?\s*[\u4e00-\u9fa5]{2,}", "疑似住址字段"),
    (r"(张|李|王|刘|陈|杨|赵|黄|周|吴|徐|孙|马|朱|胡|郭|何|罗|高|林)某", "疑似客户化名"),
]


def violations(text):
    bad = []
    for pattern, label in PII_PATTERNS + FACT_PATTERNS:
        if re.search(pattern, text):
            bad.append(label)
    return bad


def fuzzify(text):
    """数字模糊化（v4.21.0，与 SKILL.md“沉淀前必过 PII 硬过滤与数字模糊化”声明对齐）。

    金额→量级（10万元→十万级）、日期→相对时点（2026-03-05→近期）、
    姓名→关系标签（张某某→当事人）。仅处理明确可识别的模式，不做激进替换。
    v7.9.0：万级换算修正（10000万=1亿，不再误标“千万元级”），
    并修复“先检查后模糊化”倒置——含“张某某”的条目以前会被
    FACT_PATTERNS 先拒绝、姓名分支永远不可达，现改为先模糊化再检查。
    """
    # 金额 → 量级（先归一为元数再判量级，万、亿双路径口径一致）
    def _amount(m):
        num = float(m.group(1))
        unit = m.group(2) or ""
        yuan = num * (100000000 if unit == "亿" else (10000 if unit == "万" else 1))
        if yuan >= 100000000:
            return "亿元级"
        if yuan >= 10000000:
            return "千万元级"
        if yuan >= 1000000:
            return "百万元级"
        if yuan >= 100000:
            return "十万级"
        if yuan >= 10000:
            return "万级"
        if yuan >= 1000:
            return "千元级"
        return "小额（千元以下）"

    text = re.sub(r"(" + D + r"+(?:\." + D + r"+)?)\s*(亿|万)?\s*元", _amount, text)
    # 日期 → 相对时点
    text = re.sub(r"20" + D + r"{2}[-/年]" + D + r"{1,2}[-/月]" + D + r"{1,2}日?", "近期（相对时点）", text)
    text = re.sub(r"20" + D + r"{2}[-/年]" + D + r"{1,2}[-/月]", "近期（相对时点）", text)
    text = re.sub(r"20" + D + r"{2}年", "近年", text)
    # 姓名 → 关系标签（明确化名、称谓模式）
    text = re.sub(r"(?:张|李|王|刘|陈|杨|赵|黄|周|吴|徐|孙|马|朱|胡|郭|何|罗|高|林)某+", "当事人", text)
    return text


def _enforce_capacity():
    """MEMORY.md 容量上限：超出 MAX_ENTRIES 按 FIFO 淘汰最旧条目（v4.21.0）。"""
    text = read_memory()
    if text is None:
        return 0
    lines = text.split("\n")
    try:
        idx = lines.index(SECTION_MARKER)
    except ValueError:
        return 0
    # 节尾 = 下一个 “## ” 标题行
    end = len(lines)
    for i in range(idx + 1, len(lines)):
        if lines[i].startswith("## ") and lines[i] != SECTION_MARKER:
            end = i
            break
    sec = lines[idx:end]
    entry_idx = [i for i, l in enumerate(sec) if re.match(r"^- 20" + D + r"{2}-" + D + r"{2}-" + D + r"{2} ", l)]
    removed = 0
    while len(entry_idx) > MAX_ENTRIES:
        j = entry_idx[-1]  # 最新条目在前，最旧条目在节尾 → FIFO
        del sec[j]
        entry_idx.pop()
        removed += 1
    if removed:
        lines[idx:end] = sec
        ensure_memory_dir()
        with open(MEMORY_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        print("[memory][OK] 容量上限触发，FIFO 淘汰最旧条目 %d 条" % removed)
    return removed


def read_memory():
    p = resolve_memory_path()
    if not os.path.isfile(p):
        return None
    with open(p, "r", encoding="utf-8") as f:
        return f.read()


def check_memory():
    text = read_memory()
    if text is None:
        print("[memory][X] MEMORY.md 缺失")
        return False
    bad = violations(text)
    if "只记“怎么办案”" not in text and "只记" not in text:
        bad.append("缺少长期记忆边界声明")
    if bad:
        print("[memory][X] 校验未通过：%s" % "、".join(sorted(set(bad))))
        return False
    print("[memory][OK] MEMORY.md 无 PII / 具体案情标识")
    return True


def append_entry(category, entry, dry_run=False):
    if category not in CATEGORIES:
        print("[memory][X] category 必须是：%s" % " / ".join(CATEGORIES), file=sys.stderr)
        return False
    entry = entry.strip()
    if len(entry) < 10:
        print("[memory][X] entry 太短，请写成可复用的完整方法", file=sys.stderr)
        return False
    # v7.9.0：先数字模糊化（金额→量级、日期→相对时点、姓名→关系标签），再过 PII/案情检查；
    # 修复倒置：旧序先检查后模糊化，含“张某某”等可模糊模式的条目被 FACT_PATTERNS 直接拒绝，
    # fuzzify 的姓名分支永远不可达，与“写入前模糊化”声明相悖。
    entry = fuzzify(entry)
    bad = violations(category + entry)
    if bad:
        print("[memory][X] 拒绝写入：%s" % "、".join(bad), file=sys.stderr)
        _bump_stat(category, "rejected")
        return False

    today = datetime.now().strftime("%Y-%m-%d")
    line = "- %s [%s] %s" % (today, category, entry)
    if dry_run:
        print("[memory][dry-run] 将追加：%s" % line)
        return True

    text = read_memory()
    if text is None:
        print("[memory][X] MEMORY.md 缺失，请先创建后再写入", file=sys.stderr)
        return False
    if line in text:
        print("[memory][OK] 该条目已存在，跳过")
        return True

    marker = "## 最新迭代"
    if marker in text:
        text = text.replace(marker, marker + "\n\n" + line, 1)
    else:
        text = text.rstrip() + "\n\n## 最新迭代\n\n" + line + "\n"
    ensure_memory_dir()
    with open(MEMORY_PATH, "w", encoding="utf-8") as f:
        f.write(text)

    # v4.21.0：容量上限 FIFO 淘汰
    _enforce_capacity()

    if not check_memory():
        print("[memory][X] 写入后校验失败，请检查内容", file=sys.stderr)
        return False
    _bump_stat(category, "write_ok")
    print("[memory][OK] 已写入长期记忆：%s" % line)
    return True


# ── 使用统计（v7.9.0 跃升五：落盘 ~/.legal-skills/usage_stats.json）──
STATS_PATH = os.path.join(os.path.expanduser("~"), ".legal-skills", "usage_stats.json")


def _bump_stat(category, result):
    """累计 update_memory 使用计数，供 doctor --health 报告读取。

    统计项：各分类写入成功数（write_ok）、拒绝数（rejected）、
    校验调用数（check）；写入失败不计入（脚本内部错误另有 stderr）。
    周期口径：按自然月分桶（"YYYY-MM"），doctor 健康度报告默认展示
    近三个月；本地文件不可写时静默跳过，不影响写入主流程。
    """
    month = datetime.now().strftime("%Y-%m")
    try:
        import json
        if os.path.isfile(STATS_PATH):
            with open(STATS_PATH, "r", encoding="utf-8") as f:
                stats = json.load(f)
        else:
            stats = {}
        bucket = stats.setdefault(month, {})
        bucket[result] = bucket.get(result, 0) + 1
        if category:
            cat_key = "cat_%s" % category
            bucket[cat_key] = bucket.get(cat_key, 0) + 1
        os.makedirs(os.path.dirname(STATS_PATH), exist_ok=True)
        with open(STATS_PATH, "w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=1)
    except (OSError, ValueError):
        pass  # 统计落盘失败不阻断主流程


def bump_dims(dim_pairs):
    """运行时维度统计（v8.1.0 路线四：反馈数据驱动）。

    支持三类维度（可同次调用多传）：
      hit=案由号   案由命中（如 hit=41），按维度值分桶 dim_hit_41 += 1
      followup=轮数 追问轮数（如 followup=2），按轮数分桶 dim_followup_2 += 1
      fallback=源   降级触发（如 fallback=radar），按来源分桶 dim_fallback_radar += 1
    与写入主流程解耦，单独调用不写 MEMORY.md；
    非法键（非 hit/followup/fallback）拒绝并返回 False。
    """
    allowed = ("hit", "followup", "fallback")
    month = datetime.now().strftime("%Y-%m")
    clean = []
    for k, v in dim_pairs:
        if k not in allowed or not re.match(r"^[\w\u4e00-\u9fa5-]{1,20}$", v):
            print("[memory][X] 维度非法：--stat-dim %s=%s（键限 %s，值限字符与数字）"
                  % (k, v, "/".join(allowed)), file=sys.stderr)
            return False
        clean.append((k, v))
    if not clean:
        print("[memory][X] --stat-dim 未提供任何键值对", file=sys.stderr)
        return False
    try:
        import json
        if os.path.isfile(STATS_PATH):
            with open(STATS_PATH, "r", encoding="utf-8") as f:
                stats = json.load(f)
        else:
            stats = {}
        bucket = stats.setdefault(month, {})
        for k, v in clean:
            key = "dim_%s_%s" % (k, v)
            bucket[key] = bucket.get(key, 0) + 1
        os.makedirs(os.path.dirname(STATS_PATH), exist_ok=True)
        with open(STATS_PATH, "w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=1)
        print("[memory][OK] 维度统计已记录：%s"
              % "、".join("%s=%s" % (k, v) for k, v in clean))
        return True
    except (OSError, ValueError):
        print("[memory][!] 统计落盘失败，不影响技能主流程", file=sys.stderr)
        return False


def purge_memory(yes=False):
    """清空 MEMORY.md 全部记忆条目（v5.1.0，数据删除权实现）。

    保留文件头部声明与“## 最新迭代”空节骨架，仅删除条目行；执行前须二次确认。
    """
    text = read_memory()
    if text is None:
        print("[memory][X] MEMORY.md 缺失，无需清除", file=sys.stderr)
        return False
    lines = text.split("\n")
    entry_rx = re.compile(r"^- 20" + D + r"{2}-" + D + r"{2}-" + D + r"{2} ")
    total = sum(1 for l in lines if entry_rx.match(l))
    if total == 0:
        print("[memory][OK] 当前无记忆条目，无需清除")
        return True
    if not yes:
        print("[memory][!] 将清空 %d 条记忆。确认请加 --yes 参数执行" % total, file=sys.stderr)
        return False
    kept = [l for l in lines if not entry_rx.match(l)]
    # 保留节标题骨架
    if SECTION_MARKER not in "\n".join(kept):
        kept += ["", SECTION_MARKER, ""]
    ensure_memory_dir()
    with open(MEMORY_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(kept))
    print("[memory][OK] 已清空 %d 条记忆条目（文件骨架保留）" % total)
    return True


def main():
    ap = argparse.ArgumentParser(description="律师助手长期记忆写入、校验")
    ap.add_argument("--check", action="store_true", help="校验 MEMORY.md")
    ap.add_argument("--category", choices=CATEGORIES, help="记忆分类")
    ap.add_argument("--entry", help="可复用的方法条目")
    ap.add_argument("--dry-run", action="store_true", help="仅预览，不写入")
    ap.add_argument("--purge", action="store_true", help="清空全部记忆条目（数据删除权）")
    ap.add_argument("--yes", action="store_true", help="--purge 时跳过二次确认")
    ap.add_argument("--stat-dim", action="append", default=[], metavar="K=V",
                    help="运行时维度统计（可多次）：hit=案由号 / followup=轮数 / fallback=来源")
    args = ap.parse_args()

    if args.stat_dim:
        pairs = []
        for item in args.stat_dim:
            if "=" not in item:
                print("[memory][X] --stat-dim 格式应为 K=V：%s" % item, file=sys.stderr)
                sys.exit(2)
            k, v = item.split("=", 1)
            pairs.append((k.strip(), v.strip()))
        sys.exit(0 if bump_dims(pairs) else 2)
    if args.check:
        _bump_stat(None, "check")
        sys.exit(0 if check_memory() else 1)
    if args.purge:
        sys.exit(0 if purge_memory(args.yes) else 1)
    if not args.category or not args.entry:
        ap.print_help()
        sys.exit(2)
    sys.exit(0 if append_entry(args.category, args.entry, args.dry_run) else 1)


if __name__ == "__main__":
    main()
