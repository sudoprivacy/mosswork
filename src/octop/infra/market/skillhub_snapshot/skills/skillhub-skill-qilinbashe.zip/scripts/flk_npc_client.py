#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
flk_npc_client.py —— 国家法律法规数据库（flk.npc.gov.cn）官方 API 直连客户端
v8.3.0 新增（P0 借鉴点落地 · 自研实现，仅标准库）

定位：
  律师助手"法条实时核验"链路的第三实时源 + 无条件降级源。
  当 MCP 双源（北大法宝/华宇元典）不可用时，用本客户端直连全国人大
  官方数据库取回条文原文，标注“已核验(flk API)”；官方源也不可达时
  才退回离线法条库 + “🔴 未核验·模型生成”。

接口契约（2026-09 实测 flk.npc.gov.cn 公开 API）：
  POST /law-search/search/list     搜索（body 含 searchContent/pageNum/pageSize 等）
  GET  /law-search/search/flfgDetails?bbbs=    法规详情（目录树，不含正文）
  GET  /law-search/download/pc?format=docx&bbbs=&fileId=   取签名下载 URL（约 1 小时有效）
  GET  /law-search/search/enumData              法规分类/时效枚举
  GET  /law-search/prompts/search?title=        法规名联想
  GET  /law-search/search/recommend?bbbs=       相关推荐
  条文正文：下载签名 URL 指向的 DOCX → 内存解析 word/document.xml 提取文本

用法：
  python scripts/flk_npc_client.py search "中华人民共和国民法典"
  python scripts/flk_npc_client.py article "中华人民共和国民法典" 577
  python scripts/flk_npc_client.py verify "中华人民共和国民法典" 577   # 核验引擎入口（JSON）
  python scripts/flk_npc_client.py --json search "民法典"   # 供上层脚本/doctor 断言消费

退出码：0 成功；1 参数错误；2 网络/解析失败（上层据此降级）。
"""
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

# v8.10.19：全包 18 个脚本中唯一缺此句者——中文 Windows（GBK 默认代码页）下 docstring 含 emoji、
# print 中文会抛 UnicodeEncodeError，且致 doctor REG-088 判别失败。
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

BASE_URL = "https://flk.npc.gov.cn"
TIMEOUT = float(os.environ.get("FLK_TIMEOUT", "12"))   # 单请求超时（秒），可用 FLK_TIMEOUT 覆盖（交付级建议 3）
RETRY = 2             # 失败重试次数
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
              "AppleWebKit/537.36 Chrome/120 Safari/537.36")

# 时效状态：官方 sxx 字段常见取值（0 现行有效、1 已废止、2 未生效、3 修改，
# 以官方返回为准；本常量仅用于结果展示与最保守过滤——明确“已废止(1)”即排除）
SXX_ABOLISHED = "1"
# v8.10.2：检索结果中的“修改、废止的决定”类目录条目与正式版本几乎同名，会抢在正式版本之前被选中，
# 导致正式版本的本条号取不到（实测《民诉法解释》第106条）。
DECISION_TITLE = re.compile(r"关于(修改|废止|修正).{0,30}的决定|修改、废止的决定")
FLXZ_FORMAL = ("法律", "行政法规", "司法解释")


class FlkApiError(Exception):
    """flk API 调用失败（网络 / 解析 / 业务错误统一封装）"""


def _request(method, path, params=None, body=None, retry=RETRY):
    url = BASE_URL + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    data_bytes = json.dumps(body or {}).encode("utf-8") if body is not None else None
    last_err = None
    for attempt in range(retry + 1):
        headers = {
            "User-Agent": USER_AGENT,
            "Referer": BASE_URL + "/",
            "Origin": BASE_URL,
        }
        if data_bytes is not None:
            headers["Content-Type"] = "application/json;charset=UTF-8"
        req = urllib.request.Request(url, data=data_bytes, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                raw = resp.read()
            ctype = ""
            try:
                data = json.loads(raw.decode("utf-8", errors="replace"))
            except ValueError:
                data = {"code": 500, "msg": "响应非JSON: " + raw[:80].decode("utf-8", "replace")}
            if isinstance(data, dict) and data.get("code") not in (None, 200):
                raise FlkApiError("业务错误(%s): %s" % (path, data.get("msg") or data.get("message")))
            return data
        except FlkApiError:
            raise
        except Exception as exc:  # noqa: BLE001 网络类异常统一重试
            last_err = exc
            if attempt < retry:
                time.sleep(0.8 * (attempt + 1))
    raise FlkApiError("请求失败(%s %s): %s" % (method, path, last_err))


def search(keyword, page_num=1, page_size=10, search_range=1, search_type=2, sxx=None):
    """法规、条文搜索。返回 {rows, total}，rows 每项含 bbbs/title/sxx/gbrq 等官方字段。

    search_range: 1=标题搜索, 2=正文搜索；search_type: 1=精确, 2=模糊；
    sxx: 时效过滤列表（[3]=现行有效, [1]=废止, [2]=修改, [4]=未生效；None/[]=全部）。
    """
    body = {
        "searchContent": keyword,
        "searchRange": search_range,
        "searchType": search_type,
        "flfgCodeId": [],
        "zdjgCodeId": [],
        "gbrqYear": [],
        "gbrq": [],
        "sxrq": [],
        "sxx": sxx or [],
        "xgzlSearch": False,
        "pageNum": page_num,
        "pageSize": page_size,
    }
    data = _request("POST", "/law-search/search/list", body=body)
    rows = data.get("rows") or data.get("data") or []
    if isinstance(rows, dict):
        rows = rows.get("rows") or rows.get("list") or []
    return {"rows": rows, "total": data.get("total", len(rows))}


def get_detail(bbbs):
    """法规详情（目录树）。返回官方 data 对象。"""
    data = _request("GET", "/law-search/search/flfgDetails", params={"bbbs": bbbs})
    inner = data.get("data", data)
    return inner if isinstance(inner, dict) else {}


def get_download_url(bbbs, fmt="docx"):
    """获取法规文件签名下载 URL（有效期约 1 小时）。失败返回空串。"""
    try:
        data = _request("GET", "/law-search/download/pc",
                        params={"format": fmt, "bbbs": bbbs, "fileId": ""})
    except FlkApiError:
        return ""
    inner = data.get("data", data)
    if isinstance(inner, dict):
        return inner.get("url") or ""
    return inner if isinstance(inner, str) else ""


def get_suggestions(keyword):
    """法规名联想。"""
    data = _request("GET", "/law-search/prompts/search", params={"title": keyword})
    inner = data.get("data", [])
    return inner if isinstance(inner, list) else []


def get_recommendations(bbbs):
    """相关推荐。"""
    data = _request("GET", "/law-search/search/recommend", params={"bbbs": bbbs})
    inner = data.get("data", [])
    return inner if isinstance(inner, list) else []


def get_enum_data():
    """分类、时效枚举（flfgfl 法规分类树等）。"""
    data = _request("GET", "/law-search/search/enumData")
    inner = data.get("data", data)
    return inner if isinstance(inner, dict) else {}


# v8.11.0 下载主机白名单；v8.11.1 加 scheme 断言。obs-bj2.cucloud.cn 系官方签名下载 URL 的
# 承载通道（flk 返回的 flkoss 域名），属信任官方签名 URL 的必要妥协，不承载任何本案材料上传。
ALLOWED_DL_HOSTS = ("flk.npc.gov.cn", "npc.gov.cn", "obs-bj2.cucloud.cn")


MAX_DL_BYTES = 20 * 1024 * 1024   # v8.11.2：DOCX 下载读取上限（20MB）


class _GuardedRedirect(urllib.request.HTTPRedirectHandler):
    """v8.11.2：重定向目标二次校验——跳转后仍须为 https 且主机在白名单内，防白名单绕过。"""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        from urllib.parse import urlsplit as _us
        _h = (_us(newurl).hostname or "").lower()
        if not newurl.lower().startswith("https://") or not any(
            _h == h or _h.endswith("." + h) for h in ALLOWED_DL_HOSTS
        ):
            raise FlkApiError("重定向目标不在白名单，已拒绝：%s" % newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _guarded_opener():
    return urllib.request.build_opener(_GuardedRedirect)

def _download_docx(url):
    """下载 DOCX 并解析正文文本（内存中完成，不落盘、不污染包目录）。

    v8.11.0：下载前校验主机后缀白名单（官方域），防被改链导致的 SSRF／外联越权。
    """
    try:
        from urllib.parse import urlsplit as _urlsplit
        _host = (_urlsplit(url).hostname or "").lower()
    except Exception:
        _host = ""
    if not url.lower().startswith("https://"):
        raise FlkApiError("下载链接非 https，已拒绝：%s" % url)   # v8.11.1：钉死 scheme，防降级
    if not any(_host == h or _host.endswith("." + h) for h in ALLOWED_DL_HOSTS):
        raise FlkApiError("下载主机不在白名单，已拒绝：%s" % url)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with _guarded_opener().open(req, timeout=TIMEOUT) as resp:
        raw = resp.read(MAX_DL_BYTES + 1)   # v8.11.2：读取上限，防超大响应
        if len(raw) > MAX_DL_BYTES:   # v8.11.3：超限显式报错，避免静默截断被误判为“文件损坏”
            raise FlkApiError("下载文件超过 %d MB 上限，未完整读取，已中止：%s" % (MAX_DL_BYTES // 1048576, url))
    if not raw:
        raise FlkApiError("下载空文档: %s" % url)
    import io
    import zipfile as _zipfile
    try:
        zf = _zipfile.ZipFile(io.BytesIO(raw))
        xml_bytes = zf.read("word/document.xml")
    except KeyError:
        raise FlkApiError("非 docx 容器: %s" % url)
    except _zipfile.BadZipFile:
        raise FlkApiError("下载内容损坏: %s" % url)
    root = ET.fromstring(xml_bytes)
    wns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    parts = []
    for para in root.iter(wns + "p"):
        line = "".join(t.text or "" for t in para.iter(wns + "t")).strip()
        if line:
            parts.append(line)
    return "\n".join(parts)


def _to_cn(num):
    """阿拉伯数字 → 中文数字（法律文本习惯写法；超范围原样返回）。

    v8.9.0 修复：原实现对 10~19 输出“一十七”，而法律文本一律写作“第十七条”（不带“一”），
    导致第 10~19 条**一律取不到**（静默返回空、按未定位处理）。现按法律文本习惯：首位为“一”
    且单位为“十”时省略该“一”（10→十、17→十七、110→一百一十、115→一百一十五）。
    """
    digits = "零一二三四五六七八九"
    units = ["", "十", "百", "千"]
    try:
        n = int(num)
    except (TypeError, ValueError):
        return str(num)
    if n == 0:
        return "零"
    if n < 10:
        return digits[n]
    out = ""
    ln = len(str(n))
    for i, ch in enumerate(str(n)):
        d = int(ch)
        if d == 0:
            if out and not out.endswith("零"):
                out += "零"
        else:
            if not (d == 1 and ln - 1 - i == 1 and out == ""):
                out += digits[d]
            out += units[ln - 1 - i]
    out = out.rstrip("零")
    return out if out else str(num)


ARTICLE_HEAD = r"(?m)^[ \t\u3000]*第(%s)条(?![^。；\n]{0,6}的规定)(?=[\u3000 \t、]|$)"


def extract_article(full, article_no):
    """从法规全文中按“条目标题”定位并截取条文（纯函数，可离线自检）。

    v8.9.0 修复（P0）：原实现用 `re.search("第N条", full)` 取**全文首次出现**，未锚定条目标题。
    后果——分则条文中的交叉引用会被抢先命中。实测《中华人民共和国刑法》全文 73,835 字中
    “第二百六十四条”出现 5 次，首次出现位于第 196 条第 3 款“盗窃信用卡并使用的，依照本法
    第二百六十四条的规定定罪处罚。”（第 31,776 字处），真正的第 264 条（盗窃罪）在第 43,682
    字处；旧实现会把交叉引用的残句当成第 264 条正文返回，**却仍标注“✅ 已核验(flk API)”**。
    第 266 条、第 382 条同受影响，凡分则交叉引用密集的法律（刑法最典型）均为重灾区，直接波及
    刑事类 agent 的法条核验结论。

    锚定规则：①条目标题须出现在**行首**（允许前置空白）；②条号后须为全角空格、普通空格、顿号
    或行尾；③排除“第N条…的规定／的行为／的情形”式交叉引用；④截取至下一个**行首同级条目标题**
    之前。

    返回 (条文文本, 起始偏移)；定位失败返回 ("", -1)。
    """
    forms = [str(article_no), _to_cn(article_no)]
    pat = ARTICLE_HEAD % "|".join(re.escape(f) for f in dict.fromkeys(forms))
    m = re.search(pat, full)
    if not m:
        return "", -1
    start = m.start()
    tail = full[m.end():]
    nxt = re.search(r"(?m)^[ \t\u3000]*第[0-9零一二三四五六七八九十百千万]+条(?=[\u3000 \t、]|$)", tail)
    end = m.end() + (nxt.start() if nxt else len(tail))
    return full[start:end].strip(), start


def get_article_text(bbbs, article_no=None):
    """取法规条文正文（下载 DOCX 解析）。

    article_no 给定：按条目标题定位并截取到下一同级条目前（含款、项），锚定规则见
    extract_article()。定位失败返回 ("", url) 由调用方降级。
    """
    url = get_download_url(bbbs, "docx")
    if not url:
        return "", ""
    full = _download_docx(url)
    if not article_no:
        return full, url
    text, _pos = extract_article(full, article_no)
    if not text:
        return "", url
    return text, url


def self_test():
    """离线自检：条目标题锚定正确性（不联网，供 doctor REG-088 调用）。

    v8.9.0 新增。夹具复现实测缺陷场景——**交叉引用先于条目标题出现**：
    《刑法》第 196 条第 3 款“……依照本法第二百六十四条的规定定罪处罚”中的
    “第二百六十四条”在全文中的位置，早于真正的第 264 条（盗窃罪）标题。
    旧实现取全文首次出现，会把交叉引用残句当第 264 条正文返回并标“已核验”。
    """
    U = "\u3000"
    CASE = (
        "第一百九十六条" + U + "有下列情形之一，进行信用卡诈骗活动，数额较大的，处五年以下有期徒刑或者拘役。\n"
        "（第三款）盗窃信用卡并使用的，依照本法第二百六十四条的规定定罪处罚。\n"
        "第二百六十三条" + U + "以暴力、胁迫或者其他方法抢劫公私财物的，处三年以上十年以下有期徒刑。\n"
        "第二百六十四条" + U + "盗窃公私财物，数额较大的，或者多次盗窃、入户盗窃、携带凶器盗窃、扒窃的，处三年以下有期徒刑、拘役或者管制，并处或者单处罚金。\n"
        "第二百六十五条" + U + "以牟利为目的，盗接他人通信线路、复制他人电信码号的，依照本法第二百六十四条的规定定罪处罚。\n"
    )
    checks = []

    t264, pos = extract_article(CASE, 264)
    checks.append(("第264条取到条目标题（盗窃罪）而非交叉引用残句",
                   t264.startswith("第二百六十四条" + U + "盗窃公私财物")))
    checks.append(("第264条正文不含“依照本法…的规定”交叉引用", "依照本法" not in t264))
    checks.append(("第264条截取止于下一条目标题（第265条）前", "第二百六十五条" not in t264))

    t_cn, _ = extract_article(CASE, "264")
    checks.append(("中文与阿拉伯数字条号结果一致", bool(t264) and t_cn == t264))

    t196, _ = extract_article(CASE, 196)
    checks.append(("第196条取到其条目标题行", t196.startswith("第一百九十六条" + U)))

    t_none, p_none = extract_article(CASE, 999)
    checks.append(("不存在的条款返回空且偏移为 -1", t_none == "" and p_none == -1))

    t265, _ = extract_article(CASE, 265)
    checks.append(("第265条取到自身标题（其后交叉引用不干扰）",
                   t265.startswith("第二百六十五条" + U)))

    # 中文数字习惯写法（v8.9.0 修复：10~19 应为“十X”而非“一十X”，否则第 10~19 条一律取不到）
    checks.append(("_to_cn(10) 为“十”", _to_cn(10) == "十"))
    checks.append(("_to_cn(17) 为“十七”（非“一十七”）", _to_cn(17) == "十七"))
    checks.append(("_to_cn(110) 为“一百一十”", _to_cn(110) == "一百一十"))
    checks.append(("_to_cn(115) 为“一百一十五”", _to_cn(115) == "一百一十五"))
    checks.append(("_to_cn(264) 为“二百六十四”", _to_cn(264) == "二百六十四"))
    CASE2 = ("第十四条" + U + "未成年人的父母是未成年人的监护人。\n"
             "第十七条" + U + "已满十六周岁的人犯罪，应当负刑事责任。\n"
             "第十八条" + U + "精神病人在不能辨认自己行为的时候造成危害结果，经法定程序鉴定确认的，不负刑事责任。\n")
    t17, _ = extract_article(CASE2, 17)
    checks.append(("第17条以“十X”写法可定位（原缺失）",
                   t17.startswith("第十七条" + U + "已满十六周岁")))
    t14, _ = extract_article(CASE2, 14)
    checks.append(("第14条以“十X”写法可定位（原缺失）",
                   t14.startswith("第十四条" + U + "未成年人的父母")))

    # 正文自身含“的行为”不得被误判为交叉引用
    # （v8.9.0 回归：原排除环视含“的行为、的情形”，误伤刑法第14条“明知自己的行为会发生…”，
    #   导致该条取不到；现收窄为仅排除“第N条……的规定”式交叉引用）
    CASE3 = ("第十四条" + U + "明知自己的行为会发生危害社会的结果，因而构成犯罪的，是故意犯罪。\n"
             "第十五条" + U + "应当预见自己的行为可能发生危害社会的结果，因为疏忽大意而没有预见。\n")
    t14b, _ = extract_article(CASE3, 14)
    checks.append(("正文含“的行为”不被误排（刑法第14条回归）",
                   t14b.startswith("第十四条" + U + "明知自己的行为")))
    checks.append(("交叉引用“第N条……的规定”仍被排除",
                   "的规定" not in (extract_article(CASE, 264)[0] or "")))

    # _pick_best 不得跨法兜底（v8.9.0 修复：原“无匹配则返回第一条未废止法规”会把别法条文当目标法）
    _rows = [{"title": "中华人民共和国宪法（2018年修正文本）", "sxx": 3, "bbbs": "x"}]
    checks.append(("无匹配时 _pick_best 返回 None（不跨法兜底）",
                   _pick_best(_rows, "中华人民共和国刑法") is None))
    checks.append(("核心词匹配可用（“刑法”命中带前缀标题）",
                   bool(_pick_best([{"title": "中华人民共和国刑法（2023年修正）", "sxx": 3}], "刑法"))))
    # 决定类条目抢位（v8.10.2 修复）：检索结果中“关于修改……的决定”与正式版本几近同名，
    # 旧实现会先选中决定类条目，使正式版本的本条号取不到（实测《民诉法解释》第106条）。
    _rows_d = [
        {"title": "最高人民法院关于修改《最高人民法院关于适用〈中华人民共和国民事诉讼法〉的解释》的决定",
         "sxx": None, "flxz": "修改、废止的决定"},
        {"title": "最高人民法院关于适用《中华人民共和国民事诉讼法》的解释", "sxx": 3, "flxz": "司法解释"},
    ]
    _picked_d = _pick_best(_rows_d, "最高人民法院关于适用《中华人民共和国民事诉讼法》的解释")
    checks.append(("决定类条目不抢位（正式司法解释版本优先，v8.10.2）",
                   bool(_picked_d) and "决定" not in (_picked_d.get("title") or "")))
    checks.append(("仅存在决定类条目时返回 None（宁缺勿错，v8.10.2）",
                   _pick_best([_rows_d[0]], "最高人民法院关于适用《中华人民共和国民事诉讼法》的解释") is None))

    # 换版窗口期（v8.10.20 新增 · P0-1 回归）：flk 对“修法已施行但官方库未合成现行文本”的法，
    # 只能命中换版前的正式版本；须能与更晚的“修改决定”条目比出差异并置降档警示。
    _rows_w = [
        {"title": "中华人民共和国律师法", "sxx": 3, "gbrq": "2017-09-01", "flxz": "法律", "bbbs": "old"},
        {"title": "关于修改《中华人民共和国律师法》的决定", "sxx": None,
         "gbrq": "2026-08-28", "flxz": "修改、废止的决定", "bbbs": "dec"},
    ]
    checks.append(("换版窗口期可检出（更晚的修改决定 → 置降档警示，v8.10.20）",
                    _amendment_pending(_rows_w, _pick_best(_rows_w, "中华人民共和国律师法")) == "20260828"))
    checks.append(("无更晚修改决定时不误报（v8.10.20）",
                    _amendment_pending([_rows_w[0]], _rows_w[0]) == ""))

    ok = all(v for _n, v in checks)
    for n, v in checks:
        print("  [%s] %s" % ("PASS" if v else "FAIL", n))
    print("flk 条目标题锚定自检：%d/%d %s"
          % (sum(1 for _n, v in checks if v), len(checks), "全部通过" if ok else "存在失败"))
    return 0 if ok else 1


def _strip_html(text):
    return re.sub(r"<[^>]+>", "", text or "")


def _pick_best(rows, title):
    """在搜索结果中挑标题最接近且未明示废止的一项。

    v8.9.0 修复（P0）：原实现末段为“无匹配则返回第一条未废止法规”，属**静默降级取错法**——
    当查询的法规实际未被检索到时，会从**另一部无关法律**中取第 N 条正文，并由 verify() 标注
    “✅ 已核验”+错误法名，与“取错条文仍标已核验”同属一类污染。现改为：核心词不匹配即
    返回 None，由 verify() 诚实报“未检索到法规”，不再跨法兜底。
    核心词＝去掉“中华人民共和国”“中国”前缀后的主体（如“刑法”“民法典”“民事诉讼法”）。
    """
    t0 = title.replace(" ", "")
    core = t0.replace("中华人民共和国", "").replace("中国", "").replace("最高人民法院关于", ""
                    ).replace("最高人民法院", "").strip()
    cand = []
    for row in rows:
        if str(row.get("sxx")) == SXX_ABOLISHED:
            continue
        t = _strip_html(row.get("title", "")).replace(" ", "")
        flxz = str(row.get("flxz") or "")
        # v8.10.2 修复（P2）：剔除“修改、废止的决定”类目录条目——其标题与正式版本几近同名，
        # 会抢在正式版本之前被选中，使正式版本的本条号“取不到”，并可能把决定类文本当条文返回。
        if "决定" in flxz or DECISION_TITLE.search(t):
            continue
        if t0 in t:
            cand.append((0, row))
        elif core and len(core) >= 2 and core in t:
            cand.append((1, row))
    if not cand:
        return None
    # 正式版本优先：法规性质为法律、行政法规、司法解释者排前；同优先级再按标题精确度。
    cand.sort(key=lambda x: (0 if any(k in str(x[1].get("flxz") or "") for k in FLXZ_FORMAL) else 1, x[0]))
    return cand[0][1]


def _ymd(s):
    """公布日归一为可比较的 YYYYMMDD 数字串（官方 gbrq 存在 '2026-08-28' / '20260828' 等形态）。"""
    return re.sub(r"[^0-9]", "", s or "")


def _amendment_pending(rows, picked):
    """换版窗口期检测（v8.10.20 新增 · P0-1 整改）。返回“更晚的修改/废止决定公布日”（无则空串）。

    背景：官方库对“修法已施行、但尚未合成修正后现行文本”的法（典型如 2026 修正《律师法》），
    只有换版**前**的正式版本条目可命中；_pick_best 按设计返回该旧正式版本，于是取到的条文
    早于现行版本，却仍带“现行有效”。此时若同批检索结果里存在**公布日更晚**的
    “修改/废止决定”类条目，即为换版窗口期的可检测信号。调用方据此降档，
    不得标“✅已核验(flk API)”，须改标“⚠️换版窗口期·以官方发布稿为准”。
    """
    if not picked:
        return ""
    pub = _ymd(picked.get("gbrq"))
    core = _strip_html(picked.get("title", "")).replace("中华人民共和国", "").replace("中国", "")[:4]
    latest = ""
    for r in (rows or []):
        rt = _strip_html(r.get("title", ""))
        rflxz = str(r.get("flxz") or "")
        if not (rflxz == "修改、废止的决定" or DECISION_TITLE.search(rt)):
            continue
        if core and core not in rt.replace("中华人民共和国", ""):
            continue
        rdate = _ymd(r.get("gbrq"))
        if rdate and pub and rdate > pub and rdate > latest:
            latest = rdate
    return latest


def cmd_search(keyword):
    res = search(keyword, page_size=10)
    rows = res["rows"]
    if not rows:
        print("未检索到结果：%s" % keyword)
        return 0
    for row in rows:
        print("- %s | 时效:%s | 公布:%s | bbbs=%s" % (
            row.get("title", ""), row.get("sxx", ""),
            row.get("gbrq", ""), str(row.get("bbbs", ""))[:40]))
    print("共 %s 条" % res["total"])
    return 0


def cmd_article(title, article_no):
    res = search(title, search_range=1, search_type=1, page_size=20)
    row = _pick_best(res["rows"], title)
    if not row:
        print("未检索到法规：%s" % title)
        return 2
    bbbs = row.get("bbbs") or row.get("id") or ""
    text, url = get_article_text(bbbs, article_no)
    if not text:
        print("法规：%s（bbbs=%s）未定位到第 %s 条，请核对条号" % (row.get("title"), bbbs, article_no))
        return 2
    print("法规：%s | 时效:%s | 公布:%s" % (_strip_html(row.get("title")), row.get("sxx"), row.get("gbrq")))
    print("正文：")
    print(text)
    print("来源：%s" % url)
    return 0


# ── verify 子命令（v8.3.0 核验引擎入口，单文件承载搜索+取文+时效标注）──

# 官方 sxx 字段 → 中文时效（字段取值以官方返回为准；未知值回退“未知”）
SXX_LABEL = {
    "0": "未知", "1": "已废止", "2": "已修改", "3": "现行有效", "4": "未生效",
}


def verify(law_title, article_no, page_size=20):
    """按 法名+条号 实时核验取文。返回结果 dict（永不抛异常）。"""
    try:
        res = search(law_title, search_range=1, search_type=1, page_size=page_size)
    except FlkApiError as exc:
        return {"ok": False, "error": "flk 搜索失败: %s" % exc}
    row = _pick_best(res["rows"], law_title)
    if not row:
        return {"ok": False, "error": "未检索到法规: %s" % law_title}
    bbbs = row.get("bbbs") or row.get("id") or ""
    try:
        text, url = get_article_text(bbbs, article_no)
    except FlkApiError as exc:
        return {"ok": False, "error": "取文失败: %s" % exc}
    if not text:
        return {
            "ok": False,
            "error": "未定位到第%s条（法规:%s），请核对条号或改用全文核验" % (article_no, _strip_html(row.get("title"))),
            "law": _strip_html(row.get("title")),
            "article": str(article_no),
            "source": "flk API",
        }
    sxx = str(row.get("sxx", ""))
    # v8.10.20（P0-1 整改）：回吐所取版本的公布日，并对“换版窗口期”fail-closed——
    # 检出更晚的修改/废止决定时 verified 置 False，上层不得标“✅已核验(flk API)”。
    _pub = str(row.get("gbrq") or "")
    _amd = _amendment_pending(res["rows"], row)
    _warn = ""
    if _amd:
        _warn = "⚠️换版窗口期：存在更晚的修改/废止决定（%s），本条为换版前旧文本，改标“⚠️换版窗口期”并双源复核。" % _amd
    elif sxx == "4":
        _warn = "⚠️未生效版本，不得作现行法依据，不得标“✅已核验(flk API)”。"
    elif sxx == "1":
        _warn = "⚠️已废止版本，不得作现行法依据，不得标“✅已核验(flk API)”。"
    return {
        "ok": True,
        "law": _strip_html(row.get("title")),
        "article": str(article_no),
        "status": SXX_LABEL.get(sxx, "未知"),
        "status_code": row.get("sxx"),
        "publish_date": _pub,
        "text": text,
        "source": "flk API",
        "verified": not bool(_amd) and sxx == "3",
        "version_warning": _warn,
        "url": url,
    }


def cmd_verify(law_title, article_no):
    """核验引擎入口：法名+条号 → 单行 JSON（96 号引擎降级链调用）"""
    art = re.sub(r"第|条", "", article_no)
    _res = verify(law_title, art)   # v8.10.20：原实现连调两次（各含一套检索＋下载＋解析），现复用同一结果
    print(json.dumps(_res, ensure_ascii=False))
    return 0 if _res.get("ok") else 2


# ===== v8.14.1：官方核验缓存与批量调度（交付级必经位的工程支撑）=====
CACHE_DIR = os.path.join(os.path.expanduser("~"), ".legal-skills", "flk_cache")
CACHE_TTL = int(os.environ.get("FLK_CACHE_TTL", str(7 * 24 * 3600)))
FLK_TIMEOUT = float(os.environ.get("FLK_TIMEOUT", "3"))


def _cache_path(law_title, article_no):
    import hashlib
    key = "%s|%s" % (law_title.strip(), str(article_no).strip())
    return os.path.join(CACHE_DIR, hashlib.sha256(key.encode("utf-8")).hexdigest()[:32] + ".json")


def verify_cached(law_title, article_no, use_cache=True):
    """带缓存的官方核验：命中未过期缓存则不发起网络请求；结果永不抛异常。"""
    art = re.sub(r"第|条", "", str(article_no))
    path = _cache_path(law_title, art)
    if use_cache:
        try:
            with open(path, encoding="utf-8") as f:
                hit = json.load(f)
            if time.time() - float(hit.get("_cached_at", 0)) < CACHE_TTL:
                hit["cached"] = True
                return hit
        except (OSError, ValueError):
            pass
    res = verify(law_title, art)
    if not res.get("ok"):
        snap = _snapshot_read(law_title, art)
        if snap:
            return snap
    if res.get("ok"):
        _snapshot_write(law_title, art, dict(res))
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            res["_cached_at"] = time.time()
            with open(path, "w", encoding="utf-8", newline=chr(10)) as f:
                json.dump(res, f, ensure_ascii=False)
        except OSError:
            pass
    res["cached"] = False
    return res


def cmd_batch(pairs):
    """批量核验：参数形如 "中华人民共和国民法典|577"；一次输出 JSON 数组供交付级文书汇总。"""
    out = []
    for item in pairs:
        if "|" not in item:
            out.append({"ok": False, "error": "参数须为 法名|条号：%s" % item})
            continue
        law, art = item.rsplit("|", 1)
        r = verify_cached(law, art)
        r["law_query"] = law
        out.append(r)
    print(json.dumps({"ok": all(x.get("ok") for x in out), "count": len(out),
                      "items": out}, ensure_ascii=False))
    return 0 if all(x.get("ok") for x in out) else 2


SNAPSHOT_DIR = os.path.join(os.path.expanduser("~"), ".legal-skills", "flk_snapshot")
SNAPSHOT_TTL = int(os.environ.get("FLK_SNAPSHOT_TTL", str(90 * 24 * 3600)))


def probe_contract():
    """契约探针：官方接口改版时给出可读提示，而不是一串超时。"""
    import json as _j
    import urllib.error
    import urllib.request
    res = {"ok": False, "base": BASE_URL, "endpoint": "/law-search/prompts/search", "latency_ms": None,
           "hint": ""}
    t0 = time.time()
    try:
        q = urllib.parse.urlencode({"title": "民法典"})
        req = urllib.request.Request(BASE_URL + "/law-search/prompts/search?" + q,
                                     headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            body = r.read(400).decode("utf-8", "replace")
            res["latency_ms"] = int((time.time() - t0) * 1000)
            res["status"] = getattr(r, "status", 200)
            res["ok"] = "title" in body or "[" in body or "{" in body
            res["hint"] = "契约正常" if res["ok"] else "返回体非预期，疑似官方改版：按五档降级处理"
    except (urllib.error.URLError, OSError, ValueError) as exc:
        res["latency_ms"] = int((time.time() - t0) * 1000)
        res["error"] = str(exc)
        res["hint"] = "官方接口不可达：按五档降级（双源→离线库），结论标注“官方源暂不可达”"
    print(_j.dumps(res, ensure_ascii=False))
    return 0


def _snapshot_write(law_title, art, res):
    import json as _j
    try:
        os.makedirs(SNAPSHOT_DIR, exist_ok=True)
        fp = os.path.join(SNAPSHOT_DIR, "%s_%s.json" % (re.sub(r"\W+", "_", law_title)[:40], art))
        res["_snapshot_at"] = time.time()
        with open(fp, "w", encoding="utf-8", newline=chr(10)) as f:
            _j.dump(res, f, ensure_ascii=False)
    except OSError:
        pass


def _snapshot_read(law_title, art):
    import json as _j
    fp = os.path.join(SNAPSHOT_DIR, "%s_%s.json" % (re.sub(r"\W+", "_", law_title)[:40], art))
    try:
        with open(fp, encoding="utf-8") as f:
            d = _j.load(f)
        if time.time() - float(d.get("_snapshot_at", 0)) < SNAPSHOT_TTL:
            d["stale"] = True
            d["snapshot_date"] = time.strftime("%Y-%m-%d", time.localtime(float(d.get("_snapshot_at", 0))))
            return d
    except (OSError, ValueError):
        pass
    return None


def main(argv):
    if not argv:
        print(__doc__)
        return 1
    if argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    if argv[0] == "--json":
        keyword = argv[2] if len(argv) > 2 else ""
        try:
            res = search(keyword, page_size=5)
        except FlkApiError as exc:
            print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
            return 2
        print(json.dumps({"ok": True, "count": len(res["rows"]),
                          "titles": [r.get("title") for r in res["rows"]],
                          "total": res["total"]}, ensure_ascii=False))
        return 0
    cmd = argv[0]
    if cmd == "--self-test":
        return self_test()
    if cmd == "search" and len(argv) >= 2:
        return cmd_search(" ".join(argv[1:]))
    if cmd == "article" and len(argv) >= 3:
        return cmd_article(argv[1], argv[2])
    if cmd == "verify" and len(argv) >= 3:
        return cmd_verify(argv[1], argv[2])
    if cmd == "--probe":
        return probe_contract()
    if cmd == "batch" and len(argv) >= 2:
        return cmd_batch(argv[1:])
    print("未知命令：%s（支持 search / article / verify / batch / --probe / --self-test / --json search）" % cmd)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
