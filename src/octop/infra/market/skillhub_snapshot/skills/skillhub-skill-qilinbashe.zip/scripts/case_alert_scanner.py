# case_alert_scanner.py: 运行时依赖脚本（技能运行调用）
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""案件提醒扫描器 — 律师助手技能包 v6.1.0（自 76 号内嵌代码内置化，路径不再要求"另存临时文件"）

用法：
    python scripts/case_alert_scanner.py "D:/案件/" [--output alerts.json] [--today YYYY-MM-DD]

扫描目录下 docx/pdf/md/txt 案件文档，按六类期限关键词（开庭/查封续封/举证/上诉/执行/时效）
＋日期正则提取期限，输出按剩余天数排序的分档提醒 JSON（red/amber/yellow/normal/black 五档；black＝已过期）。
隐私：全程本机执行，不外传文件内容；输出 JSON 建议按 `pii_filter.pii_mask` 脱敏后再分享。
降级：脚本不可用或无匹配时按 76 号"异常处理"表转人工录入模式。
"""
import os, re, json, sys, argparse
from datetime import datetime, date
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pii_filter import pii_mask  # noqa: E402  v6.6.0 统一共享口径
try:
    from holiday_cn import next_workday, is_workday, coverage_note
    _CN_CAL = True
except Exception:
    _CN_CAL = False

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

KEYWORDS = {
    "开庭": ["开庭", "庭审", "质证", "开庭日期", "庭审时间", "休庭", "宣判", "开庭通知"],
    "查封、续封": ["查封", "续封", "保全", "冻结", "扣押", "查封期限", "续封申请", "财产保全"],
    "举证": ["举证", "举证期限", "证据交换", "举证通知书", "举证责任"],
    "上诉": ["上诉", "上诉期", "上诉状", "答辩期", "答辩状"],
    "执行": ["执行", "执行期限", "申请执行", "强制执行", "执行通知书"],
    "时效": ["时效", "诉讼时效", "届满", "过期", "到期"],
}
DATE_PATTERNS = [
    re.compile(r'(20\d{2})[-./](\d{1,2})[-./](\d{1,2})'),
    re.compile(r'(20\d{2})年(\d{1,2})月(\d{1,2})日'),
    re.compile(r'(\d{1,2})月(\d{1,2})日'),
    re.compile(r'\b(\d{1,2})[-/](\d{1,2})\b'),
]

def get_level(days_left):
    # v8.10.19：补第 5 档 black（已过期），与 76 号／31 附属件／00 号“五档着色”口径统一
    if days_left < 0:
        return "black"
    if days_left <= 3:
        return "red"
    if days_left <= 7:
        return "amber"
    if days_left <= 15:
        return "yellow"
    return "normal"

def get_level_for(days_left, category=None):
    # v7.9.0 新增：台账口径分级（§39），查封、冻结类到期前 30 日即升 yellow（续封窗口）
    # 与 get_level 的差异：仅查封、续封类（含保全）在 16-30 天区间提前预警，其余档不变。
    # v8.10.19：补第 5 档 black（已过期）。
    if days_left < 0:
        return "black"
    if days_left <= 3:
        return "red"
    if days_left <= 7:
        return "amber"
    if days_left <= 15:
        return "yellow"
    if category == "查封、续封" and days_left <= 30:
        return "yellow"
    return "normal"

def parse_date(text):
    today = date.today()
    for pat in DATE_PATTERNS:
        m = pat.search(text)
        if m:
            g = m.groups()
            try:
                if len(g) == 3:
                    # 两组 3 元组正则均强制 20\d{2} 开头，年份数字化即可，
                    # 旧版 elif len(g)==3 分支（非“20”开头年份）永不可达，已删（v7.9.0）
                    y, mo, d = int(g[0]), int(g[1]), int(g[2])
                elif len(g) == 2:
                    y, mo, d = today.year, int(g[0]), int(g[1])
                else: continue
                return date(y, mo, d)
            except ValueError: continue
    return None

def read_txt(path):
    for enc in ["utf-8", "gbk", "gb2312", "latin-1"]:
        try:
            with open(path, "r", encoding=enc, errors="replace") as f: return f.read()
        except Exception: continue
    return ""

def read_docx(path):
    try:
        from docx import Document
        doc = Document(path)
        return "\n".join(p.text for p in doc.paragraphs)
    except Exception: pass
    try:
        import zipfile
        with zipfile.ZipFile(path, "r") as z:
            xml_files = [n for n in z.namelist() if n.startswith("word/document") and n.endswith(".xml")]
            if not xml_files: return ""
            xml_content = z.read(xml_files[0]).decode("utf-8", errors="replace")
            texts = re.findall(r'<w:t(?:\s[^>]*)?>([^<]*)</w:t>', xml_content)
            return "\n".join(texts)
    except Exception: return ""

def read_pdf(path):
    try:
        import pdfplumber
        parts = []
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                t = page.extract_text()
                if t: parts.append(t)
        return "\n".join(parts)
    except Exception: pass
    try:
        import PyPDF2
        parts = []
        with open(path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                t = page.extract_text()
                if t: parts.append(t)
        return "\n".join(parts)
    except Exception: pass
    return ""

def read_file(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".txt", ".md", ".markdown"): return read_txt(path)
    elif ext == ".docx": return read_docx(path)
    elif ext == ".pdf": return read_pdf(path)
    elif ext == ".doc":
        # v7.9.0：旧版直接 read_txt 乱读 OLE 二进制，产出乱码假命中；
        # 老版 .doc 无纯 Python 可靠解析，改为明确跳过并在结果中记录，
        # 不再产生噪音提醒（降级口径与 76 号“异常处理”表一致：无法可靠提取的不硬提）
        return ""
    return ""

def scan_file(path, today):
    alerts = []
    text = read_file(path)
    if not text: return alerts
    folder_name = os.path.basename(os.path.dirname(path))
    file_name = os.path.basename(path)
    for line in text.split("\n"):
        for category, words in KEYWORDS.items():
            for kw in words:
                kw_pos = line.find(kw)
                if kw_pos == -1: continue
                search_range = line[max(0, kw_pos - 7): kw_pos + len(kw) + 30]
                d = parse_date(search_range)
                if d:
                    days_left = (d - today).days
                    adj = d
                    rollover = ""
                    if _CN_CAL and category in ("上诉", "执行", "时效") and not is_workday(d):
                        adj = next_workday(d)
                        rollover = "名义届满日落休假日，按民诉法第85条顺延至 %s（%s）" % (adj.strftime("%Y-%m-%d"), coverage_note(d))
                    alert = {
                        "date": d.strftime("%Y-%m-%d"),
                        "actual_date": adj.strftime("%Y-%m-%d"),
                        "event": f"{folder_name} · {category}（{kw}）",
                        "days": f"剩{days_left}天" if days_left >= 0 else f"已过期{abs(days_left)}天",
                        "level": get_level(days_left),
                        "level_for": get_level_for(days_left, category),  # v7.9.0 台账口径（查封续封类提前 30 日预警）
                        "days_left": days_left,
                        "source": file_name,
                        "category": category,
                        "rollover": rollover,
                        "detail": pii_mask(line.strip())[:100],  # v6.6.0 P2-D21：JSON detail 出盘前统一脱敏
                    }
                    if not any(a["date"] == alert["date"] and a["category"] == category and a["source"] == file_name for a in alerts):
                        alerts.append(alert)
                    break
    return alerts

def scan_directory(root_path, today=None):
    if today is None: today = date.today()
    all_alerts, file_count, skip_count = [], 0, 0
    for dirpath, dirnames, filenames in os.walk(root_path):
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in (".docx", ".pdf", ".md", ".markdown", ".txt", ".doc"): continue
            fpath = os.path.join(dirpath, fname)
            try:
                if ext == ".doc":
                    # v7.9.0：.doc 老格式无可靠纯文本提取，跳过并计数，避免乱码假提醒
                    skip_count += 1
                    continue
                all_alerts.extend(scan_file(fpath, today))
                file_count += 1
            except Exception: skip_count += 1
    all_alerts.sort(key=lambda a: a["days_left"])
    return {"scan_date": today.strftime("%Y-%m-%d"), "root_path": root_path,
            "files_scanned": file_count, "files_skipped": skip_count,
            "total_alerts": len(all_alerts), "alerts": all_alerts}

def main():
    parser = argparse.ArgumentParser(description="案件提醒扫描器")
    parser.add_argument("path", help="案件根目录路径")
    parser.add_argument("--output", "-o", default=None, help="输出 JSON 文件路径")
    parser.add_argument("--today", default=None, help="指定今天日期（YYYY-MM-DD）")
    args = parser.parse_args()
    root = args.path.strip().strip('"').strip("'")
    if not os.path.isdir(root):
        print(f"错误：路径不存在 — {root}", file=sys.stderr); sys.exit(1)
    today = None
    if args.today:
        try: today = datetime.strptime(args.today, "%Y-%m-%d").date()
        except Exception: today = date.today()
    else: today = date.today()
    print(f"扫描中：{root}", file=sys.stderr)
    result = scan_directory(root, today)
    print(f"完成：扫描 {result['files_scanned']} 个文件，找到 {result['total_alerts']} 条提醒", file=sys.stderr)
    output_json = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f: f.write(output_json)
        print(f"结果已写入：{args.output}", file=sys.stderr)
    else: print(output_json)

if __name__ == "__main__":
    main()
