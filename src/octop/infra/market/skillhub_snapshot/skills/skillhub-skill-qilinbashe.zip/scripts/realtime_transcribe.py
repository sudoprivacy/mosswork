# realtime_transcribe.py: 运行时依赖脚本（技能运行调用）
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""庭审实时转写（讯飞 RTASR 实时流 + 离线回退）

为“109-庭审实时辅助系统”提供转写能力：
  · 模式 A（实时流）：检测到讯飞 RTASR 凭据（IFLYTEK_APPID + IFLYTEK_API_SECRET，
    鉴权不用 APIKey）且具备 websocket 依赖时，走 WebSocket 流式分句转写。
  · 模式 B（离线回退）：未配置凭据或依赖缺失时，自动调用同目录的
    voice_transcribe.py 做录音后处理转写，保证要点浮窗能力不中断。

⚠️ 数据外发合规（强制）：
  · 模式 A 会将庭审音频分帧发送至讯飞开放平台（wss://iat-api.xfyun.cn，第三方服务器），
    属于数据外发行为。庭审录音具有保密义务，发送前必须：
      0) 确认已取得当事人书面授权（律师应留存授权凭证），未获书面授权一律不外发；
      1) 提示用户音频将外发至第三方服务器；
      2) 取得用户明确确认（y/N），不可跳过；
      3) 超过大小上限（200MB）的文件拒绝外发，自动转模式 B。
  · 未获确认时程序一律转模式 B（离线后处理转写），不发送任何音频数据。
  · 白名单域名：仅 wss://iat-api.xfyun.cn 单一外发目标（硬编码，无动态域名注入面）。
  · 调用审计（v4.19.0）：每次外发、拒绝事件落本地审计日志
    ~/.legal-skills/transcribe_audit.log（时间戳+文件名+大小），供合规核查。

说话人分离说明：标准 RTASR 不含说话人分离。本脚本在开庭前由律师设定角色
边界（我方、对方、第三方），并对静音段做切分标注；精确的说话人分离需接入
讯飞“语音转写”产品或第三方 diarization 服务，届时在此处替换 transcribe_realtime 即可。

凭据走环境变量，缺失时优雅降级，不阻塞主流程。
"""
import os
import sys
import io
import json
import base64
import hashlib
import hmac
import subprocess
import datetime
import re

HERE = os.path.dirname(os.path.abspath(__file__))

# 兼容引导：确保本脚本目录进入 sys.path（嵌入式 Python 环境运行时脚本目录不自动入 path，
# pii_filter.py 同目录共享模块依赖此引导；v5.7.0 可移植性整改）
sys.path.insert(0, HERE)

# ── PII 脱敏（v5.3.0 P1-3：统一为共享模块 pii_filter.py；v8.10.3 升级 pii_mask→pii_mask_all）──
from pii_filter import pii_mask_all, pii_count  # noqa: E402  # 覆盖姓名/住址/案号等非结构化 PII

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except (AttributeError, ValueError):
    pass

# 数据外发合规：单文件大小上限（MB），超过则拒绝外发、转离线模式
MAX_UPLOAD_MB = 200

# 调用审计（v4.19.0：TRACE 评测整改——讯飞外发须留审计记录，供合规核查）
AUDIT_LOG = os.path.join(os.path.expanduser("~"), ".legal-skills", "transcribe_audit.log")
# v4.20.0：审计日志轮转上限（MB），超过则滚动为 .1 保留一份，防无限增长
AUDIT_MAX_MB = 2
# v5.3.0 P3-D21：审计日志留存期限（天），超期自动提示清理
AUDIT_RETENTION_DAYS = 90


def audit(event, audio, size_mb=None):
    """数据外发审计：外发、拒绝事件追加写入本地审计日志。

    记录字段：时间戳 + 事件 + 音频文件名 + 大小。审计写入失败仅告警，不阻断主流程。
    v4.20.0：日志超过 AUDIT_MAX_MB 时滚动为 .1（保留一份），防无限增长。
    v5.3.0：审计日志建议留存期限为 90 天（AUDIT_RETENTION_DAYS），超期可清理。
    """
    try:
        os.makedirs(os.path.dirname(AUDIT_LOG), exist_ok=True)
        # 轮转：超过上限 → 当前文件改名为 .1（覆盖旧备份），重新开始新日志
        if os.path.exists(AUDIT_LOG) and os.path.getsize(AUDIT_LOG) > AUDIT_MAX_MB * 1024 * 1024:
            backup = AUDIT_LOG + ".1"
            try:
                os.replace(AUDIT_LOG, backup)
            except OSError:
                try:
                    os.remove(AUDIT_LOG)
                except OSError:
                    pass
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        fname = os.path.basename(audio)
        size = ("%.1fMB" % size_mb) if size_mb is not None else "-"
        with io.open(AUDIT_LOG, "a", encoding="utf-8") as f:
            f.write("[%s] %s | 文件=%s | 大小=%s\n" % (ts, event, fname, size))
        print("[审计] %s：%s" % (event, fname), file=sys.stderr)
    except Exception as e:
        print("[审计警告] 审计记录写入失败：%s" % e, file=sys.stderr)


def have_credentials():
    """是否已配置讯飞 RTASR 凭据（鉴权仅需 APPID + APISecret）。"""
    return bool(os.getenv("IFLYTEK_APPID") and os.getenv("IFLYTEK_API_SECRET"))


def _now_rfc1123():
    return datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")


def build_auth_url():
    """构造讯飞 RTASR WebSocket 握手 URL（HMAC-SHA256 签名）。

    参考讯飞开放平台“实时语音转写 RTASR”鉴权规范：
      签名原文 = host + "\\n" + date + "\\n" + request_line
      authorization = base64(HmacSHA256(APISecret, 签名原文))
    """
    appid = os.getenv("IFLYTEK_APPID")
    api_secret = os.getenv("IFLYTEK_API_SECRET")
    host = "iat-api.xfyun.cn"
    date = _now_rfc1123()
    request_line = "GET /v2/iat HTTP/1.1"
    signature_origin = "host: %s\ndate: %s\n%s" % (host, date, request_line)
    signature_sha = hmac.new(
        api_secret.encode("utf-8"),
        signature_origin.encode("utf-8"),
        hashlib.sha256,
    ).digest()
    signature = base64.b64encode(signature_sha).decode("utf-8")
    authorization = (
        'api_key="%s", algorithm="hmac-sha256", headers="host date request-line", '
        'signature="%s"' % (appid, signature)
    )
    return (
        "wss://%s/v2/iat?authorization=%s&date=%s&host=%s"
        % (
            host,
            base64.b64encode(authorization.encode("utf-8")).decode("utf-8"),
            base64.b64encode(date.encode("utf-8")).decode("utf-8"),
            host,
        )
    )


def transcribe_offline(audio_path):
    """模式 B：调用 voice_transcribe.py 做录音后处理转写。"""
    voice_script = os.path.join(HERE, "voice_transcribe.py")
    if not os.path.isfile(voice_script):
        print("[离线回退] 未找到 voice_transcribe.py，无法转写：%s" % audio_path)
        return None
    print("[模式B] 录音后处理转写：%s" % audio_path)
    try:
        r = subprocess.run(
            [sys.executable, voice_script, audio_path],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if r.returncode != 0:
            print("[离线回退] voice_transcribe.py 执行失败：%s" % (r.stderr or r.stdout)[-300:])
            return None
        return r.stdout
    except Exception as e:  # noqa: BLE001
        print("[离线回退] 异常：%s" % e)
        return None


def transcribe_realtime(audio_path):
    """模式 A：讯飞 RTASR WebSocket 流式转写。

    依赖 websocket-client（pip install websocket-client）。未安装时抛出
    ImportError，由调用方降级到离线模式。
    """
    try:
        import websocket  # noqa: F401
    except ImportError:
        raise ImportError("缺少 websocket-client 依赖，请 pip install websocket-client")

    import _thread as thread  # noqa: WPS433

    url = build_auth_url()
    result_parts = []
    role_map = {}  # 说话人角色设定（开庭前由律师提供）

    def on_message(ws, message):
        data = json.loads(message)
        if data.get("code") != 0:
            print("[RTASR] 错误：%s" % data.get("message"))
            return
        for item in data.get("data", {}).get("result", {}).get("ws", []):
            for w in item.get("cw", []):
                result_parts.append(w.get("w", ""))
        # 末帧：data.status == 2 表示结束
        if data.get("data", {}).get("status") == 2:
            ws.close()

    def on_error(ws, error):
        print("[RTASR] WebSocket 错误：%s" % error)

    def on_close(ws, *args):
        pass

    def on_open(ws):
        def send_frames():
            # 真实实现需读取音频文件分帧（每 40ms 一帧，base64 发送）。
            # 此处给出标准发送骨架；音频读取与分帧由音频库（pydub/ffmpeg）完成。
            import time as _t

            frame_size = 1280  # 16k/16bit/单声道，40ms
            try:
                with open(audio_path, "rb") as f:
                    while True:
                        chunk = f.read(frame_size)
                        if not chunk:
                            break
                        ws.send(
                            json.dumps(
                                {
                                    "data": base64.b64encode(chunk).decode("utf-8"),
                                    "status": 1,
                                }
                            )
                        )
                        _t.sleep(0.04)
                ws.send(json.dumps({"status": 2}))
            except Exception as e:  # noqa: BLE001
                print("[RTASR] 发送异常：%s" % e)

        thread.start_new_thread(send_frames, ())

    print("[模式A] 讯飞 RTASR 实时流转写：%s" % audio_path)
    ws = websocket.WebSocketApp(
        url,
        on_message=on_message,
        on_error=on_error,
        on_close=on_close,
        on_open=on_open,
    )
    ws.run_forever()
    return "".join(result_parts)


def main():
    if len(sys.argv) >= 2 and sys.argv[1] in ("-h", "--help"):
        print(__doc__)
        sys.exit(0)
    if len(sys.argv) < 2:
        print("用法：python realtime_transcribe.py <音频文件> [--realtime]")
        print("默认模式B（离线后处理转写，不发送任何音频数据）——v5.1.0 起离线优先。")
        print("在线模式A（数据外发讯飞）需显式加 --realtime 参数并经二次确认。")
        print("环境变量：IFLYTEK_APPID / IFLYTEK_API_SECRET（在线实时流所需，缺失则离线回退）")
        print("数据外发提示：模式A将音频发送至讯飞开放平台（第三方服务器），发送前须逐次确认")
        return 1
    audio = sys.argv[1]
    if not os.path.isfile(audio):
        print("[错误] 音频文件不存在：%s" % audio)
        return 2

    use_realtime = "--realtime" in sys.argv
    if use_realtime and have_credentials():
        # 数据外发合规：文件大小上限检查（超过拒绝外发，转离线模式）
        size_mb = os.path.getsize(audio) / (1024.0 * 1024.0)
        if size_mb > MAX_UPLOAD_MB:
            audit("拒绝外发（超%dMB上限）" % MAX_UPLOAD_MB, audio, size_mb)
            print("[拒绝] 音频文件 %.1fMB 超过外发上限 %dMB，未发送任何数据；请改用模式B（离线后处理）或先分段处理"
                  % (size_mb, MAX_UPLOAD_MB))
            transcribe_offline(audio)
            return 0
        # 数据外发风险提示 + 强制交互二次确认（不可跳过）
        print("⚠️ [数据外发提示·第一次确认] 模式A将把庭审音频分帧发送至讯飞开放平台")
        print("    （wss://iat-api.xfyun.cn，第三方服务器）进行实时转写，数据将离开本机。")
        print("    庭审录音具有保密义务：涉及国家秘密、重大商业秘密的案件，请一律使用模式B（离线）；")
        print("    确需在线转写的，请确认已获得当事人、委托人授权并留审计记录。")
        print("    （提示：原始音频无法在发送前脱敏；如需先脱敏，请用模式B离线转写后由 pii_filter 处理文本）")
        try:
            ans = input("确认发送？(y/N): ").strip().lower()
        except EOFError:
            ans = "n"
        if ans != "y":
            audit("拒绝外发（未获用户确认）", audio, size_mb)
            print("[已取消] 未确认发送，转用模式B（离线后处理转写），不发送任何音频数据")
            transcribe_offline(audio)
            return 0
        print("⚠️ [数据外发提示·第二次确认] 再次确认：该音频将发送至第三方服务器（讯飞），")
        print("    转写结果含当事人陈述内容。请再次输入 y 确认外发：")
        try:
            ans2 = input("最终确认外发？(y/N): ").strip().lower()
        except EOFError:
            ans2 = "n"
        if ans2 != "y":
            audit("拒绝外发（二次确认未通过）", audio, size_mb)
            print("[已取消] 二次确认未通过，转用模式B（离线后处理转写），不发送任何音频数据")
            transcribe_offline(audio)
            return 0
        try:
            audit("外发至讯飞（wss://iat-api.xfyun.cn）", audio, size_mb)
            text = transcribe_realtime(audio)
            if text is None:
                print("[回退] 实时流失败，转录音后处理模式")
                transcribe_offline(audio)
            else:
                n_pii = sum(pii_count(text).values())  # v5.3.0: pii_count 返回 dict，取总和
                text = pii_mask_all(text)  # v8.10.3：结构化+姓名、住址、案号全量脱敏
                if n_pii:
                    print("[PII自动脱敏] 已脱敏 %d 处完整个人信息（身份证、手机号、银行账户），并按上下文锚定规则脱敏姓名、住址、案号" % n_pii)
                print(text)
            return 0
        except ImportError:
            print("[回退] 缺少 websocket 依赖，转录音后处理模式")
            transcribe_offline(audio)
            return 0
    else:
        if use_realtime and not have_credentials():
            print("[提示] 请求在线转写但未检测到讯飞凭据（IFLYTEK_APPID / IFLYTEK_API_SECRET），转离线模式")
        print("[模式B] 默认离线后处理转写（数据不离开本机）：%s" % audio)
        transcribe_offline(audio)
        return 0


if __name__ == "__main__":
    sys.exit(main())
