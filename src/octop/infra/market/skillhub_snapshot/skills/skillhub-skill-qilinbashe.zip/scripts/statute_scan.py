#!/usr/bin/env python3
"""律师助手·离线法条引用扫描器＋法规变更雷达（statute_scan.py）

对 agents/（及可选 templates/、references/）做离线静态扫描，提取全部
“《法名》第X条”引用清单，自动生成《法条引用扫描报告.md》，供发布前审计
与评测复测使用（对应评测 P2-03：无离线可运行的法条核验审计产物）。

用法：
  python scripts/statute_scan.py                 # 默认扫 agents/，报告输出到当前目录
  python scripts/statute_scan.py --out 报告.md   # 指定报告输出路径
  python scripts/statute_scan.py --all           # 扫 agents+templates+references
  python scripts/statute_scan.py --quiet         # 仅打印统计摘要
  python scripts/statute_scan.py --radar         # 法规变更雷达：联网比对官方源，输出候选清单（v7.5.0，每日首扫）

输出报告内容：
  1. 扫描范围与总引用数
  2. 按法名汇总表（法名 | 引用条数 | 涉及文件数）
  3. 条号明细（法名 → 条号 → 引用文件清单）
  4. 未带核验标注的引用清单（提示补核验）

说明：本脚本自 v7.5.0 起随包分发（法规变更雷达·每日首扫运行载体，31-总控路由
开场动作与 96-法条交叉核验引擎均调用 --radar），仅用标准库，无第三方运行时依赖。
"""
import os
import re
import sys
import json
import datetime
import urllib.request
import urllib.parse
import ssl

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except (AttributeError, ValueError):
    pass

# 中文数字 → 整数（正确处理“一百三十一=131”“X十Y”结构，禁止逐位累加）
CN_NUM = {'零': 0, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
          '六': 6, '七': 7, '八': 8, '九': 9}
CN_UNIT = {'十': 10, '百': 100, '千': 1000}


def cn2int(s):
    """中文数字转整数。例：一百三十一→131；二十→20；十五→15。"""
    if not s:
        return None
    # 全角数字 → 半角
    s = s.translate(str.maketrans('０１２３４５６７８９', '0123456789'))
    if s.isdigit():
        return int(s)
    total, section, num = 0, 0, 0
    for ch in s:
        if ch in CN_NUM:
            num = CN_NUM[ch]
        elif ch in CN_UNIT:
            unit = CN_UNIT[ch]
            if num == 0:
                num = 1
            if unit == 1000 or unit == 100:
                section = (section + num) * unit
                total += section
                section = 0
                num = 0
            else:  # 十
                section += num * unit
                num = 0
        else:
            return None
    total += section + num
    return total if total else None


# 条号匹配：半角、全角数字、中文数字；允许“第X条”“第X条第Y款”“第X条之Y”“第X条之Y第Z款”
# 法名：书名号《》可选（agent 正文常见“民法典第1079条”无书名号写法）；
#       贪婪匹配取最长法名（防“合同法”误吃“劳动合同法”子串，坑95）；
#       v7.9.0 修复《民法典》全量漏扫：法名主体下限由 2 字放宽到 1 字、
#       结尾词新增“法典”（旧式无法匹配以“典”结尾的法名，包内存量民法典
#       引用对雷达不可见——agents 实测 347 处/68 文件、含 references 合计
#       322 组/77 文件（组=按文件×条号去重），民法典恰是包内最高频引用，雷达
#       的“已引用法名”清单因此长期缺民法典，人大网出现民法典动态无法报 [CHK]；
#       本修复为可见性修复，未新增任何民法典条文内容）。
#       注意“法典”必须排在“法”前（交替序），防“民法典”被切成“民法”。
#       v8.0.0 修复两类残留盲区：①条号补“之N”尾（旧式把“第266条之一”记成
#       “第266条”，条号错位——两含义完全不同的条文在报告里撞键）；②法名补
#       司法解释序号后缀（“婚姻家庭编解释一”“建工解释（二）”类旧式漏扫，
#       实测含 references 合计新可见 40 处/20 法名）。修正案引法（“刑法修正案
#       （十一）”）仍不在 ART_PAT 范围——其本身无条号，适用时人肉比对原文。
ART_PAT = re.compile(
    r'《?((?:中华人民共和国)?[\u4e00-\u9fff]{1,16}(?:法典|法|条例|办法|规定|解释|规则|通则)'
    r'(?:（[一二三四五六七八九十\d]+）|[一二三四五六七八九十\d]+)?)》?\s*'
    r'第\s*([0-9０-９]+|[零一二三四五六七八九十百千]+)\s*条(之[一二三四五六七八九十]+)?'
    r'(?:\s*第\s*[0-9０-９零一二三四五六七八九十]+\s*款)?'
)

# 核验标注检测（引用所在行是否含核验语义）
VERIFY_HINT = re.compile(r'核验|已核验|未核验|MCP|现行|有效|时效|flk|法宝|元典|来源')

# 法名清洗：正则贪婪匹配会把“依据、根据、见、按”等引导词或先行文带进法名（v8.0.0），
# 分组计数前剥掉；包内法名不会以这些字开头，剥后不影响正文语义。
# 已知边界：无书名号行内长散文前缀（如“彩礼返还需满足解释一第X条”）无法穷举清洗，
# 仅影响报告分组外观；雷达比对为双向子串匹配，不受影响。
# v8.12.0（QW 第十二轮观察项）：“中华人民共和国”前缀未剥离，同一部法被拆成两组
#   （“民法典”与“中华人民共和国民法典”各占一行），“部数”因此虚高。本版把国名前缀
#   纳入清洗（并列同名法），使“部数”成为真实法名数——引用条数口径不受影响。
LAW_PREFIX_JUNK = re.compile(r'^(?:中华人民共和国|依据|根据|见|按|按如|依照|参酌|适用|及|或|和|与|、|，|,|；|;|的)')


# v8.12.2（DX 第二十轮 观察①）：法名别名归并——简称与全称归一，消除"民诉法/民事诉讼法"
#   分列双计，使"部数"成为语义去重后的真实法名数；**引用条数口径不变**（仍逐条计）。
#   已知边界：正则贪婪匹配带出的长句碎片（如"影响评估见个保法"）本轮未并入，登记为续挂观察项，
#   故部数仍偏保守（碎片只会抬高、不会掩盖真实法名）。
LAW_ALIAS = {
    "民诉法": "民事诉讼法", "刑诉法": "刑事诉讼法", "破产法": "企业破产法",
    "个保法": "个人信息保护法", "行诉法": "行政诉讼法", "道交法": "道路交通安全法",
    "复议法": "行政复议法", "消法": "消费者权益保护法", "消保法": "消费者权益保护法",
    "调解仲裁法": "劳动争议调解仲裁法", "民诉法解释": "民事诉讼法解释",
    "刑诉法解释": "刑事诉讼法解释", "新公司法": "公司法",
}


def norm_law(name):
    """clean_law 之后再做别名归一，返回用于分组计数的规范法名。"""
    return LAW_ALIAS.get(clean_law(name), clean_law(name))


# v8.12.3（DX 第二十一轮 观察①）：长句碎片归并——ART_PAT 贪婪匹配会把“合法性基础见个保法”
#   “如实回答义务见刑诉法”“尽早会见既是刑诉法”整串当前缀，凭空抬高“部数”。法名本身不含
#   “见／依／按／载于”这类连接词，故取最后一个分隔词之后的尾部；仅当尾部仍是合法法名
#   （≥2 字且含法名关键词）才采用，否则保留原值，防误切（“未成年人保护法”含“为”但不含本表词）。
_LAW_TAIL_SEP = re.compile(r"(?:分别为|载于|依据|根据|依照|按照|援引|回到|落入|满足|基础是|见|依|按)")
_LAW_TAIL_HEAD = re.compile(r"^(?:既是|即|系|为|属|应|可|须|的|了|现行)")
_LAW_NAME_TAIL = re.compile(r"(?:法典|法|条例|办法|规定|解释|规则|通则)")


def clean_law(name):
    """剥掉贪婪匹配带入法名首部的引导词、连接词，返回净化后的法名。"""
    prev = None
    while prev != name:
        prev = name
        name = LAW_PREFIX_JUNK.sub('', name)
    if _LAW_TAIL_SEP.search(name):
        _tail = _LAW_TAIL_HEAD.sub('', _LAW_TAIL_SEP.split(name)[-1])
        # 只接受“像法名”的尾部：≥3 字且含法名关键词；2 字的“同法／本法／解释／办法”
        # 是段落指代而非法名，宁保留原值也不制造新的低质分组。
        if len(_tail) >= 3 and _LAW_NAME_TAIL.search(_tail):
            name = _tail
            while prev != name:
                prev = name
                name = LAW_PREFIX_JUNK.sub('', name)
    return name


def scan_dir(src, rel_dir):
    """扫描目录下全部 .md，返回 [(rel_path, line_no, line)] 引用命中。"""
    hits = []
    base = os.path.join(src, rel_dir)
    if not os.path.isdir(base):
        return hits
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__']
        for fn in sorted(files):
            if not fn.endswith('.md'):
                continue
            p = os.path.join(root, fn)
            rel = os.path.relpath(p, src).replace(os.sep, '/')
            # v7.9.0：utf-8 失败回退 gbk 再试（旧版直接 continue，
            # GBK 存档的法条引用会静默漏扫，报告缺数）
            text = None
            try:
                text = open(p, 'r', encoding='utf-8').read()
            except (OSError, UnicodeDecodeError):
                try:
                    text = open(p, 'r', encoding='gbk', errors='replace').read()
                except OSError:
                    continue
            if text is None:
                continue
            lines = text.split('\n')
            in_code = False
            for i, line in enumerate(lines, 1):
                if line.strip().startswith('```'):
                    in_code = not in_code
                    continue
                if in_code:
                    continue
                for m in ART_PAT.finditer(line):
                    hits.append((rel, i, line.strip(), m))
    return hits


# ---- 法规变更雷达（v7.4.0 新增；v7.5.0 每日首扫自调度）----
# 根因：法条时效性是核心卖点，但新规跟进靠人工盯，司法所工作一忙就漏。
# 本模块联网抓取人大网立法工作页（npc.gov.cn，非 SPA、可达），解析最新
# 立法动态（修订、通过、施行），与包内已引用法名比对，输出“候选变更清单”，
# 人工拍板后再入包。flk.npc.gov.cn 国家法规库是 SPA（API 直抓只回 HTML 壳），
# 按“路径堵死快速切换”原则改用人大网立法页。
# 设计约束：零第三方依赖（urllib）、网络失败降级不阻塞、单次只抓列表页控制体积、
# 保守比对（法名命中即视为已覆盖，避免误报）。
# v7.5.0 每日首扫：状态存用户主目录 ~/.legal-skills/radar_state.json（不污染包体），
# 记录 last_scan_date；当天已首扫过则直接跳过（TeleAgent / workbuddy 等多平台
# 一天打开多次只扫第一次）。仅网络抓取成功（含“可达但无动态”）才写状态，
# 网络不可达不写，保留当日重试机会。v7.9.0 目录由 ~/.legal_skills 收敛为
# ~/.legal-skills，与审计日志同根。
_NPC_RADAR_URLS = (
    "https://www.npc.gov.cn/npc/c2/c30834/list.html",   # 立法工作
    "https://www.npc.gov.cn/npc/c30834/202608/list.html",  # 最新动态（日期前缀）
)
# 动态关键词：修订、通过、施行、发布、公布、审议
_RADAR_KW = re.compile(r"(修订|通过|施行|公布|审议|发布)")
# 法名特征词（标题含此即可能为立法动态）
_LAW_NAME_KW = re.compile(r"(法|条例|法典|办法|规定|解释|通则)")


def _extract_law_name(title):
    """从立法动态标题提取法名：优先书名号《》；否则剥离动态前缀后取"X法、条例"。

    标题多为"全国人大常委会表决通过新修订的国防动员法"式，
    剥离常见立法动态前缀词后剩余部分即法名本体；结果供人工复核候选用，
    名称颗粒度到"能看懂是哪部法"即可（雷达定位是提示，不是自动判据）。
    """
    m = re.search(r"《([^》]{2,30})》", title)
    if m:
        return m.group(1).replace("中华人民共和国", "").strip()
    t = title
    for pfx in ("全国人大常委会", "全国人大", "表决通过", "审议通过", "审议", "通过",
                "新修订的", "新修订", "修订后的", "修订", "公布", "发布", "施行", "印发"):
        t = t.replace(pfx, "")
    t = t.strip("，。 ")
    m = re.search(r"([\u4e00-\u9fff]{2,12}?(?:法|条例|法典|办法|规定|解释|通则))$", t)
    if m:
        return m.group(1)
    return ""


def _radar_state_path():
    """雷达状态文件路径：用户主目录 ~/.legal-skills/radar_state.json。

    放主目录而非包内：状态是"本机使用痕迹"，不进提交包、不占 184 文件数，
    多平台/多会话共享同一文件，天然实现"一天只扫一次"。
    v7.9.0：目录由 ~/.legal_skills（下划线）收敛为 ~/.legal-skills（连字符），
    与 vlm_audit.log / transcribe_audit.log 审计日志同一根目录，
    本机运行时痕迹统一一处管理；读取时兼容旧位置，命中即迁移。
    """
    home = os.path.expanduser("~")
    d = os.path.join(home, ".legal-skills")
    legacy = os.path.join(home, ".legal_skills", "radar_state.json")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    cur = os.path.join(d, "radar_state.json")
    if not os.path.exists(cur) and os.path.isfile(legacy):
        try:
            os.replace(legacy, cur)  # 旧状态迁移（仅本文件，不整目录搬动）
        except OSError:
            pass
    return cur


def _radar_load_state():
    """读状态文件，返回 dict（损坏、缺失返回空 dict，不阻塞）。"""
    try:
        with open(_radar_state_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _radar_save_state(today):
    """写状态：记录 last_scan_date=today。写失败不阻塞（下次重试即可）。"""
    try:
        with open(_radar_state_path(), "w", encoding="utf-8") as f:
            json.dump({"last_scan_date": today}, f, ensure_ascii=False, indent=2)
    except OSError as e:
        print("  [SKIP] 雷达状态写入失败（%s），下次重试" % type(e).__name__)


def _fetch_npc_radar():
    """抓取人大网立法动态页，返回 ([(标题, 链接)], ok)。

    ok=True 表示至少一页抓取成功（页面可达但无动态也算成功，当日首扫完成）；
    ok=False 表示全部源不可达（网络故障，不写状态、保留当日重试机会）。
    过滤规则：标题须含法名特征（法/条例/法典/办法/规定/解释/通则），
    或含立法动态关键词（修订/通过/施行等）——两个条件满足其一即收录。
    避免把"宪法和法律委员会""立法工作计划"这类导航标题当候选。
    """
    ctx = ssl.create_default_context()
    out = []
    ok = False
    for url in _NPC_RADAR_URLS:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=12, context=ctx) as r:
                html = r.read(1024 * 512).decode("utf-8", "replace")
            ok = True
            for m in re.finditer(r'<a[^>]*href="([^"]+)"[^>]*>(.{0,90}?)</a>', html, re.S):
                txt = re.sub(r"<[^>]+>", "", m.group(2)).strip()
                if not txt or "委员会" in txt or "工作计划" in txt or "工作报告" in txt:
                    continue
                if _LAW_NAME_KW.search(txt) or _RADAR_KW.search(txt):
                    out.append((txt, m.group(1)))
            if out:
                return out, True
        except Exception as e:  # noqa
            print("  [SKIP] 人大立法页抓取失败（%s）" % type(e).__name__)
    return out, ok


def _extract_laws_from_pkg(src):
    """扫描包内 agents+references+SKILL.md，提取已引用法名集合。"""
    laws = set()
    for rel_dir in ("agents", "references"):
        for rel, _ln, _line, m in scan_dir(src, rel_dir):
            laws.add(norm_law(m.group(1)))
    sk = os.path.join(src, "SKILL.md")
    try:
        for line in open(sk, encoding="utf-8"):
            for m in ART_PAT.finditer(line):
                laws.add(norm_law(m.group(1)))
    except (OSError, UnicodeDecodeError):
        pass
    return laws


def radar_main():
    if os.environ.get("LEGAL_SKILLS_DISABLE_RADAR") == "1":
        print("法规变更雷达已按 LEGAL_SKILLS_DISABLE_RADAR=1 关闭（离线策略）：未联网、未扫描、不计入首扫状态。")
        return 0
    """法规变更雷达：每日首扫比对人大网立法动态与包内收录，输出候选清单。

    v7.5.0 起带当日状态防重：本机当天首次扫描写入状态文件，
    同一天再次调用直接跳过（多平台/多次打开不重复扫）。
    """
    src = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    today = datetime.date.today().isoformat()
    print("== 法规变更雷达（v7.5.0）==")
    state = _radar_load_state()
    if state.get("last_scan_date") == today:
        print("[跳过] 今日（%s）已完成首次扫描，明日再自动扫描。" % today)
        return 0

    print("扫描包内已引用法名…")
    pkg_laws = _extract_laws_from_pkg(src)
    print("包内已收录法名：%d 部" % len(pkg_laws))

    items, ok = _fetch_npc_radar()
    if ok:
        _radar_save_state(today)
        print("[状态] 今日扫描已记录，同日再次调用将自动跳过。")
    if not items:
        if ok:
            print("[结论] 官方源可达但无匹配立法动态，本轮未生成候选。")
        else:
            print("[结论] 官方源不可达，本轮未生成候选（网络恢复后重跑即可）。")
        return 0

    print("人大网立法动态：%d 条\n" % len(items))

    # 法名归一：去掉书名号、“中华人民共和国”前缀、括号注后比对
    def norm(t):
        t = re.sub(r"《|》|中华人民共和国", "", t)
        return re.sub(r"（.{0,30}）|\(.{0,30}\)", "", t).strip()

    cand_new, cand_chk = [], []
    for txt, link in items:
        law = _extract_law_name(txt)
        if not law:
            continue
        n = norm(law)
        if not n:
            continue
        hit = any(n in l or l in n for l in pkg_laws)
        tag = "[CHK]" if hit else "[NEW]"
        if hit:
            cand_chk.append("%s %s（%s）→ 包内已引用，建议复核修订" % (tag, law, link))
        else:
            cand_new.append("%s %s（%s）" % (tag, law, link))

    print("-- 候选：可能需新增收录 --")
    for c in cand_new[:15]:
        print("  " + c)
    if not cand_new:
        print("  （无）")
    print("\n-- 候选：已收录，建议复核修订 --")
    for c in cand_chk[:15]:
        print("  " + c)
    if not cand_chk:
        print("  （无）")
    print("\n[结论] 人工复核候选后，更新 references/核心法条速查索引.md 或对应 agent 锚点")
    return 0


def main():
    src = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    args = sys.argv[1:]
    out = None
    targets = ['agents']
    quiet = False
    i = 0
    while i < len(args):
        if args[i] == '--out' and i + 1 < len(args):
            out = args[i + 1]
            i += 2
        elif args[i] == '--all':
            targets = ['agents', 'templates', 'references']
            i += 1
        elif args[i] == '--quiet':
            quiet = True
            i += 1
        elif args[i] in ('--no-radar', '--offline'):
            # v8.14.4：ST N-1／WB-01 高危修复——原分支只设环境变量、未推进下标，
            # 同参数在 while 内永久命中导致死循环（实测 --no-radar 进程挂死）。
            os.environ['LEGAL_SKILLS_DISABLE_RADAR'] = '1'
            i += 1
        elif args[i] == '--radar':
            return radar_main()
        else:
            i += 1

    all_hits = []
    for t in targets:
        all_hits.extend(scan_dir(src, t))
    all_hits.sort(key=lambda h: (h[0], h[1]))

    # 汇总：法名 → {条号: [文件]}
    stat = {}
    no_verify = []
    for rel, ln, line, m in all_hits:
        law, art = norm_law(m.group(1)), m.group(2)
        num = cn2int(art)
        art_key = str(num) if num is not None else art
        if m.group(3):  # “之N”并入条号键，防“第266条”与“第266条之一”撞键（v8.0.0）
            art_key += m.group(3)
        law_stat = stat.setdefault(law, {})
        art_files = law_stat.setdefault(art_key, set())
        art_files.add(rel)
        if not VERIFY_HINT.search(line):
            no_verify.append((rel, ln, law, art_key, line[:60]))

    total_refs = len(all_hits)
    total_laws = len(stat)

    # 生成报告
    lines = []
    lines.append('# 法条引用扫描报告（离线静态）')
    lines.append('')
    lines.append('> 由 scripts/statute_scan.py 自动生成，非人工手写。'
                 '扫描范围：%s；生成时间：%s。' % ('、'.join(targets),
                 datetime.datetime.now().strftime('%Y-%m-%d %H:%M')))
    lines.append('')
    lines.append('## 一、总览')
    lines.append('')
    lines.append('| 指标 | 数值 |')
    lines.append('|:-----|:-----|')
    lines.append('| 引用总条数 | %d |' % total_refs)
    lines.append('| 涉及法律、法规数 | %d |' % total_laws)
    lines.append('| 引用文件数 | %d |' % len(set(h[0] for h in all_hits)))
    lines.append('| 未带核验标注引用数 | %d |' % len(no_verify))
    lines.append('')
    lines.append('## 二、按法名汇总')
    lines.append('')
    lines.append('| 法律、法规 | 引用条数 | 涉及文件数 |')
    lines.append('|:----------|:--------:|:----------:|')
    for law in sorted(stat, key=lambda k: -sum(len(v) for v in stat[k].values())):
        arts = stat[law]
        lines.append('| %s | %d | %d |' % (law, sum(len(v) for v in arts.values()),
                                           len(set(f for v in arts.values() for f in v))))
    lines.append('')
    lines.append('## 三、条号明细')
    lines.append('')
    for law in sorted(stat):
        lines.append('### %s' % law)
        lines.append('')
        lines.append('| 条号 | 引用文件 |')
        lines.append('|:-----|:---------|')
        for art in sorted(stat[law], key=lambda a: (a.isdigit() and int(a), a)):
            files = sorted(stat[law][art])
            lines.append('| 第%s条 | %s |' % (art, '；'.join(files)))
        lines.append('')
    lines.append('## 四、未带核验标注的引用（发布前须人工抽查）')
    lines.append('')
    if no_verify:
        lines.append('| 文件 | 行号 | 引用 | 上下文 |')
        lines.append('|:-----|:-----|:-----|:-------|')
        for rel, ln, law, art, ctx in no_verify[:200]:
            lines.append('| %s | %d | 《%s》第%s条 | %s |' % (rel, ln, law, art, ctx))
        if len(no_verify) > 200:
            lines.append('| … | | 其余 %d 条略 | |' % (len(no_verify) - 200))
    else:
        lines.append('（无）')
    lines.append('')
    lines.append('> 说明：本报告为静态扫描产物，条号与内容的现行有效性须按 96-法条交叉核验引擎'
                 '真实调用 MCP 源核验；抽查 20 条与 flk.npc.gov.cn 官方文本比对。')
    report = '\n'.join(lines)

    if out:
        with open(out, 'w', encoding='utf-8') as f:
            f.write(report)
        if not quiet:
            print('报告已生成: %s' % out)
    elif not quiet:
        print(report)

    # v8.11.10：摘要恒打印——--quiet 仅打印统计摘要（与帮助文本“仅打印统计摘要”一致）
    print('[OK] 共 %d 条引用 / %d 部法规 / 未带核验标注 %d 条'
          % (total_refs, total_laws, len(no_verify)))
    return 0 if total_refs > 0 else 1


if __name__ == '__main__':
    sys.exit(main())
