# holiday_cn.py: 运行时依赖脚本（技能运行调用）
# -*- coding: utf-8 -*-
"""holiday_cn.py — 中国法定节假日/工作日与期限顺延计算（v6.2.0 国内适配）

法律依据：
  - 《民事诉讼法》第 85 条：期间届满的最后一日是法定休假日的，以法定休假日后的
    第一日为期间届满的日期；期间不包括在途时间，诉讼文书在期满前交邮的，不算过期。
  - 《民法典》第 203 条：期间的最后一日为法定休假日的，以法定休假日的次日为
    期间的最后一日。
  - 《全国年节及纪念日放假办法》（2024 修订）：法定节假日内含双休日之外的全体公民放假节日。

数据口径（如实披露，不装懂）：
  - 2025 年：按国务院办公厅 2025 年放假安排通知完整录入（含放假区间与调休补班日）。
  - 2026 年：按国办发明电〔2025〕7 号（2025-11-04 发布）完整录入（含放假区间与调休补班日）。
  - 2027 年：仅录入法定日近似区间，具体调休以国办通知为准。

用法：
  from holiday_cn import is_workday, next_workday, adjusted_expiry, coverage_note
  next_workday(date(2025,10,7))        -> date(2025,10,9)   # 末日逢休假日→顺延至假期后首个工作日
  adjusted_expiry(date(2025,10,7), 1)  -> (date(2025,10,8), date(2025,10,9), "按国办2025年放假安排完整录入（含调休）")
  adjusted_expiry(date(2025,1,1), 15) -> (date(2025,1,16), date(2025,1,16), "按国办2025年放假安排完整录入（含调休）")
  # start=期间开始之日（不计入）, days=期间长度；返回(名义届满日, 顺延后届满日, 披露语)。"""
from datetime import date, timedelta
import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# ── 2025 放假区间（国办通知）──
HOLIDAYS_2025 = [
    (date(2025, 1, 1), date(2025, 1, 1)),        # 元旦
    (date(2025, 1, 28), date(2025, 2, 4)),       # 春节（除夕至初七）
    (date(2025, 4, 4), date(2025, 4, 6)),        # 清明
    (date(2025, 5, 1), date(2025, 5, 5)),        # 劳动节
    (date(2025, 5, 31), date(2025, 6, 2)),       # 端午
    (date(2025, 10, 1), date(2025, 10, 8)),      # 国庆+中秋连休
]
WORKDAYS_2025 = {  # 调休补班的周六、周日
    date(2025, 1, 26), date(2025, 4, 27), date(2025, 9, 28), date(2025, 10, 11),
}

# ── 2026 已精确录入（含调休）；2027 未公布待填（法定日近似区间）──
HOLIDAYS_2026 = [
    (date(2026, 1, 1), date(2026, 1, 3)),        # 元旦（1/4 补班）
    (date(2026, 2, 15), date(2026, 2, 23)),      # 春节连休9天（2/14、2/28 补班）
    (date(2026, 4, 4), date(2026, 4, 6)),        # 清明
    (date(2026, 5, 1), date(2026, 5, 5)),        # 劳动节连休5天（5/9 补班）
    (date(2026, 6, 19), date(2026, 6, 21)),      # 端午（6/19 周五＋周末）
    (date(2026, 9, 25), date(2026, 9, 27)),      # 中秋（9/25 周五＋周末）
    (date(2026, 10, 1), date(2026, 10, 7)),      # 国庆连休7天（9/20、10/10 补班）
]
HOLIDAYS_2027 = [
    (date(2027, 1, 1), date(2027, 1, 1)),
    (date(2027, 2, 6), date(2027, 2, 12)),      # 春节（正月初一=2/6，连休近似区间）
    (date(2027, 4, 5), date(2027, 4, 5)),        # 清明（近似）
    (date(2027, 5, 1), date(2027, 5, 2)),
    (date(2027, 6, 9), date(2027, 6, 9)),        # 端午（近似）
    (date(2027, 9, 15), date(2027, 9, 15)),      # 中秋（近似）
    (date(2027, 10, 1), date(2027, 10, 3)),
]
_WORKDAYS = {
    2026: {date(2026, 1, 4), date(2026, 2, 14), date(2026, 2, 28),
           date(2026, 5, 9), date(2026, 9, 20), date(2026, 10, 10)},
}   # 2026 按国办发明电〔2025〕7 号录入；2027 未公布待填

BY_YEAR = {2025: HOLIDAYS_2025, 2026: HOLIDAYS_2026, 2027: HOLIDAYS_2027}
PRECISION = {
    2025: "按国办2025年放假安排完整录入（含调休）",
    2026: "按国办发明电〔2025〕7号完整录入（含调休）",
    2027: "法定日近似区间，未含调休，具体以国办通知为准",
}


def _in_ranges(d, ranges):
    return any(a <= d <= b for a, b in ranges)


def is_holiday(d):
    return _in_ranges(d, BY_YEAR.get(d.year, []))


def is_workday(d):
    """工作日 = 非节假日 且（非周末 或 周末调休补班）。"""
    if is_holiday(d):
        return False
    if d.weekday() >= 5:
        _wd = set(_WORKDAYS.get(d.year, set()))
        if d.year == 2025:
            _wd |= WORKDAYS_2025
        return d in _wd
    return True


def next_workday(d):
    """最后一日逢法定休假日、双休日 → 顺延至其后第一个工作日（民诉法第85条）。"""
    guard = 0
    while not is_workday(d) and guard < 30:
        d = d + timedelta(days=1)
        guard += 1
    return d


def coverage_level(d):
    """数据覆盖级别：exact＝2025／2026 含调休完整；approx＝2027 仅法定日近似；none＝超出覆盖。
    v8.14.5（ST N-6）：主计算器据此把 needs_holiday_adjustment 置空并提示人工核对，
    避免 2028 年国庆期间被误判为工作日。"""
    if d.year in (2025, 2026):
        return "exact"
    if d.year == 2027:
        return "approx"
    return "none"


def coverage_note(d):
    return PRECISION.get(d.year, "超出 2025-2027 节假日数据覆盖，按自然日推算，请人工核对国办通知")


def adjusted_expiry(start, days):
    """期间开始之日不计算在内（民诉法第85条第2款、民法典第201条）：自次日起算。
    返回 (名义届满日, 顺延后实际届满日, 披露语)。
    
    起算口径说明（v8.13.16 补注）：start 为期间开始之日（不计入），次日 start+1 为期间第 1 日，
    第 N 日为 start+N，届满日 = start+days。代码 start+timedelta(days=days) 与此一致。
    例：start=10月7日, days=1 → 次日10月8日为第1日即届满 → nominal=10月8日 ✓
        start=1月1日, days=15 → 次日1月2日为第1日, 第15日=1月16日届满 → nominal=1月16日 ✓
    v8.13.16 注：ST评测方误判此函数"把起算日算进第一天"，经实测验证 start+days 对自次日起算是正确的；
    已在 doctor.py 补显式起算日断言用例（REG-080 扩展）防止后续混淆。"""
    nominal = start + timedelta(days=days)
    return nominal, next_workday(nominal), coverage_note(nominal)


if __name__ == "__main__":
    import sys as _sys
    if any(a in ("-h", "--help") for a in _sys.argv[1:]):
        print(__doc__)
        print("用法：python scripts/holiday_cn.py [YYYY-MM-DD] [--days N]")
        print("  例：python scripts/holiday_cn.py 2026-02-14 --days 15")
        print("  无参：按内置示例日演示顺延；非法日期返回码 2。")
        _sys.exit(0)
    # v8.14.4（DB P3-03）：支持传入日期与天数；修复原版忽略命令行、固定输出 2025-10-07 示例的问题
    _d = date(2025, 10, 7)
    _days = None
    _rest = []
    _i = 0
    _args = _sys.argv[1:]
    while _i < len(_args):
        if _args[_i] in ("--days", "-n") and _i + 1 < len(_args):
            try:
                _days = int(_args[_i + 1])
            except ValueError:
                print("用法：python scripts/holiday_cn.py [YYYY-MM-DD] [--days N]")
                _sys.exit(2)
            _i += 2
            continue
        _rest.append(_args[_i])
        _i += 1
    if _rest:
        try:
            _d = date.fromisoformat(_rest[0])
        except ValueError:
            print("日期格式应为 YYYY-MM-DD，例：python scripts/holiday_cn.py 2026-02-14 --days 15")
            _sys.exit(2)
    if _days is None:
        print(_d, "->", next_workday(_d), coverage_note(_d))
    else:
        _nom, _adj, _note = adjusted_expiry(_d, _days)
        print("起算 %s ／ 期间 %d 日 ／ 名义届满 %s ／ 顺延后 %s ／ %s"
              % (_d, _days, _nom, _adj, _note))
