# install_deps.py: 运行时依赖脚本（技能运行调用）
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""install_deps.py — 律师助手按需依赖安装器（v4.4.2 新增，v4.10.0 授权加固）

用法：
  python scripts/install_deps.py --auto     # 智能检测：缺什么装什么（推荐，用户侧回复“安装”即触发）
  python scripts/install_deps.py --word     # Word导出
  python scripts/install_deps.py --pdf      # PDF解析
  python scripts/install_deps.py --ocr      # 图片OCR
  python scripts/install_deps.py --audio    # 语音转写
  python scripts/install_deps.py --office   # Office全家桶
  python scripts/install_deps.py --all      # 一键全装
  python scripts/install_deps.py --yes      # 跳过交互确认（须已获用户明确同意；agent 调用前必须先征得同意）

安全约束（v4.10.0 起）：
  1. 包名白名单：仅允许安装 PACKAGES 中声明的固定版本包，任何命令行传入、白名单外的包名直接拒绝；
  2. 版本锁定：每个包锁定固定版本（==），保证复测环境可复现；
  3. 安装前确认：默认逐组打印将安装的包名与版本并要求 y/N 确认；--yes 仅用于已获用户同意的自动场景；
  4. 审计日志：每次安装写入 ~/.workbuddy/logs/install_audit.log（时间、分组、包名、版本、结果），可追溯；
  5. 失败提示回滚：安装失败时给出回滚建议（pip uninstall 已装部分）。
  7. 哈希校验（v8.10.0）：按 allowed-tools.json 依赖登记段的 sha256 摘要校验构件，不符即拒绝安装，
     不使用哈希锁定文件时会在审计日志留痕；
  8. 装后验证（v8.10.0）：安装后回探组件是否真正就绪，pip 成功但探测不到时如实报告并留痕。
  6. 安装来源受控：默认仅从 PyPI 官方源拉取、版本持续锁定（==）；官方源网络不可达时自动经国内权威镜像（阿里云，白名单固定域名）重试一次——镜像仅作下载通道，包名/版本/审计口径不变，不做任何额外注入；任何安装动作均先展示清单（包名+版本+来源）并获用户确认后执行。

退出码：
  0 = 全部安装成功或已安装
  1 = 部分安装失败 / 用户取消 / 白名单拒绝
"""

# v5.3.0 P3-D23：依赖版本安全声明
# 所有锁定版本已对照 PyPI 已知 CVE 列表检查（2026-08-22）：
#   - python-docx==1.1.2：无已知 CVE
#   - pymupdf==1.24.9：无已知 CVE
#   - easyocr==1.7.2：无已知 CVE
#   - openai==1.40.0：无已知 CVE
#   - websocket-client==1.8.0：无已知 CVE
# 建议每季度复查 PyPI Safety DB，如有新 CVE 发布及时升级锁定版本。

import argparse
import importlib.util
import os
import subprocess
import sys
import time

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except (AttributeError, ValueError):
    pass

# 包名白名单 + 版本锁定（固定版本，禁止裸包名；升级须人工评估后同步更新本表与法源抽样核验台账）
PACKAGES = {
    "base":   ["PyYAML==6.0.2"],
    "word":   ["python-docx==1.1.2"],
    "pdf":    ["pymupdf==1.24.9", "pdfplumber==0.11.4", "PyPDF2==3.0.1", "beautifulsoup4==4.12.3"],
    "ocr":    ["easyocr==1.7.2", "Pillow==10.4.0", "pillow-heif==0.18.0"],
    "audio":  ["websocket-client==1.8.0", "faster-whisper==1.1.0"],
    "office": ["python-pptx==1.0.2", "openpyxl==3.1.5", "xlrd==2.0.1", "docx2txt==0.9"],
    "ai":     ["openai==1.40.0"],
    # 传递依赖说明（不单独锁定，避免与 easyocr/whisper 的解析约束冲突）：
    #   numpy——easyocr 与 faster-whisper 的传递依赖，随 easyocr 安装自动进入；
    #   scipy——easyocr 的传递依赖；torch／torchvision 同理由 easyocr 带入。
    # v8.10.6：补齐此前仅被 import、却未在安装清单声明的构件（PyPDF2／beautifulsoup4／pillow-heif／faster-whisper／docx2txt）。
    # v8.10.7：上述 5 件均已落到对应分组的 PACKAGES 清单（pdf/ocr/audio/office），且 PROBES
    #          已改为“组内全包探针”——装后验证与 --auto 探测一律按“组内模块全部齐备”判定，装完不再仍缺件。
}

# 白名单集合（install_group 断言用）：仅允许上表声明的 “包名==版本”
ALLOWED = set()
for _pkgs in PACKAGES.values():
    ALLOWED.update(_pkgs)

# 各分组检测探针（v8.10.7：改为“组内全包探针”——组内任一模块缺失，该组即判为未就绪，
# 避免原先“每组只探 1 个模块”导致 --auto 误判“组已就绪”而漏装）
PROBES = {
    "base":   ["yaml"],
    "word":   ["docx"],
    "pdf":    ["fitz", "pdfplumber", "PyPDF2", "bs4"],
    "ocr":    ["easyocr", "PIL", "pillow_heif"],
    "audio":  ["websocket", "faster_whisper"],
    "office": ["pptx", "openpyxl", "xlrd", "docx2txt"],
    "ai":     ["openai"],
}

# 审计日志位置（技能包外，避免污染提交包体）
AUDIT_LOG = os.path.join(os.path.expanduser("~"), ".workbuddy", "logs", "install_audit.log")


def audit(entry):
    """写入审计日志（时间、动作、包、结果），失败不阻断安装主流程"""
    try:
        os.makedirs(os.path.dirname(AUDIT_LOG), exist_ok=True)
        with open(AUDIT_LOG, "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), entry))
    except Exception as e:
        print("  ⚠️ 审计日志写入失败: %s" % e)


def check_installed(name):
    """探测指定分组是否已就绪（v8.10.7：组内全部模块齐备才算就绪，任一缺即返回 False）"""
    mods = PROBES.get(name)
    if not mods:
        return False
    return all(importlib.util.find_spec(m) is not None for m in mods)


PIP_INDEX_OFFICIAL = "https://pypi.org/simple"
PIP_INDEX_CN_MIRROR = "https://mirrors.aliyun.com/pypi/simple/"  # 国内权威镜像，仅作下载通道，锁定版本不变


ALLOWED_TOOLS_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "allowed-tools.json")
LOCK_SECTION_HINT = "allowed-tools.json · python_deps.locked（v8.10.0 起为依赖构件摘要唯一事实源）"


def _lock_subset(pkgs, tmpdir):
    """从 allowed-tools.json 的 python_deps.locked 生成本次安装的哈希锁定文件。
    哈希锁定（v8.10.0）：pip 在下载阶段即校验构件 sha256，与登记值不符则拒绝安装。"""
    import json as _json
    if not os.path.isfile(ALLOWED_TOOLS_PATH):
        return None
    try:
        _d = _json.load(open(ALLOWED_TOOLS_PATH, encoding="utf-8"))
    except Exception:
        return None
    want = set(p.split("==")[0].strip() for p in pkgs)
    rows = []
    for it in (_d.get("python_deps") or {}).get("locked") or []:
        if it.get("name") in want:
            rows.append(it)
    if not rows:
        return None
    out = []
    for it in rows:
        out.append("%s==%s \\" % (it["name"], it["version"]))
        hs = it.get("sha256") or []
        for k, h in enumerate(hs):
            out.append("    --hash=sha256:%s%s" % (h, " \\" if k < len(hs) - 1 else ""))
    fp = os.path.join(tmpdir, "lock_subset.txt")
    open(fp, "w", encoding="utf-8").write("\n".join(out) + "\n")
    return fp


# v8.11.13（CD-2026-10-13 供应链整改）：无哈希降级由“静默自动继续”改为“显式高风险确认”。
# 原实现：--require-hashes 失败即自动重试无哈希安装 / 登记缺失即直接无哈希安装——在严格供应链
# 评测中属未关闭风险（CD 建议②③：移除静默降级，或改为降级前的高风险显式确认）。
ALLOW_NO_HASH = False


def _confirm_no_hash(reason):
    """无哈希安装前的显式高风险确认。默认拒绝（fail-closed）。

    非交互（EOF/无输入）或未加 --allow-no-hash 时一律返回 False，不再静默降级；
    用户须在看到风险提示后输入 y（且命令行已显式 --allow-no-hash）方可继续，
    无论结果如何均写审计日志（NO-HASH-DENIED / NO-HASH-CONFIRMED）。
    """
    print("  🚨 高风险：%s" % reason)
    print("     无哈希安装 = 放弃下载期 sha256 摘要强校验，仅剩“版本号 + 官方源/镜像”约束。")
    print("     建议先在可信网络重试；确需继续则须显式确认（本项记入审计日志）。")
    if not ALLOW_NO_HASH:
        print("  ⛔ 已按默认拒绝（未加 --allow-no-hash）。如确需继续：")
        print("     python scripts/install_deps.py --allow-no-hash …  （并在下一步输入 y 确认）")
        audit("NO-HASH-DENIED %s（默认拒绝，未加 --allow-no-hash）" % reason)
        return False
    try:
        ans = input("     确认以“无哈希”方式继续安装？[y/N]: ").strip().lower()
    except EOFError:
        ans = ""
    if ans not in ("y", "yes"):
        print("  ⛔ 未确认，已取消无哈希安装（未安装任何包）。")
        audit("NO-HASH-DENIED %s（用户未确认）" % reason)
        return False
    audit("NO-HASH-CONFIRMED %s（用户显式确认）" % reason)
    return True


def _pip_with_mirror_fallback(pkgs):
    """官方源优先；网络失败自动降级国内镜像重试一次（版本锁定 == 不变，白名单与审计口径不变）。

    v8.11.13：哈希登记缺失 / --require-hashes 失败两条路径均须经 _confirm_no_hash 显式确认，
    未确认时直接返回失败（returncode!=0），不再静默无哈希安装。
    """
    import tempfile
    _td = tempfile.mkdtemp(prefix="legal_deps_")
    _lk = _lock_subset(pkgs, _td)
    if _lk:
        print("  🔐 哈希锁定：从 allowed-tools.json 依赖登记段校验 %d 个包的 sha256 摘要" % len(pkgs))
        _base = [sys.executable, "-m", "pip", "install", "--require-hashes", "-r", _lk]
    else:
        print("  ⚠️ 未找到 allowed-tools.json 依赖登记段或未覆盖本组包。")
        if not _confirm_no_hash("依赖摘要登记缺失（allowed-tools.json 未覆盖本组包）"):
            return subprocess.CompletedProcess(args=["pip", "install"], returncode=1)
        _base = [sys.executable, "-m", "pip", "install"] + pkgs
    r = subprocess.run(
        _base + ["--index-url", PIP_INDEX_OFFICIAL],
        capture_output=False, text=True, encoding="utf-8", errors="replace", timeout=300)
    if r.returncode != 0 and _lk:
        print("  ⚠️ 哈希校验安装未成功（依赖传递链哈希可能未全登记）。")
        if not _confirm_no_hash("--require-hashes 未覆盖传递依赖（传递链哈希待全登记）"):
            return subprocess.CompletedProcess(args=["pip", "install"], returncode=1)
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install"] + pkgs + ["--index-url", PIP_INDEX_OFFICIAL],
            capture_output=False, text=True, encoding="utf-8", errors="replace", timeout=300)
    if r.returncode != 0:
        print("  ⚠️ 官方源拉取未成功（多为国内网络原因），自动切换阿里云镜像重试一次（包与版本完全不变）...")
        audit("MIRROR-FALLBACK aliyun: %s" % " ".join(pkgs))
        r = subprocess.run(
            _base + ["--index-url", PIP_INDEX_CN_MIRROR],
            capture_output=False, text=True, encoding="utf-8", errors="replace", timeout=300)
        if r.returncode == 0:
            print("  ✅ 已经国内镜像完成安装（锁定版本与官方源一致）。")
    return r


def install_group(name, pkgs, yes=False):
    """安装单个依赖组：白名单断言 → 版本锁定 → （确认）→ 执行 → 审计"""
    # 白名单断言：命令行、配置无法引入白名单外的包
    for p in pkgs:
        if p not in ALLOWED:
            print("❌ 拒绝安装白名单外依赖: %s（仅允许 %d 个锁定包）" % (p, len(ALLOWED)))
            audit("REJECT %s (白名单外)" % p)
            return False

    print("\n📦 安装 %s 依赖: %s" % (name, " ".join(pkgs)))

    # 安装前确认（默认交互；--yes 表示已获用户同意）
    if not yes:
        try:
            ans = input("  将安装以上 %d 个锁定版本包，是否继续？[y/N]: " % len(pkgs)).strip().lower()
        except EOFError:
            ans = ""
        if ans not in ("y", "yes"):
            print("  ⏭️ 已取消（未安装任何包）。如需自动安装，请确认后使用 --yes。")
            audit("CANCEL %s (用户未确认)" % name)
            return False

    try:
        r = _pip_with_mirror_fallback(pkgs)
        if r.returncode == 0:
            print("✅ %s 安装完成" % name)
            # 装后验证（v8.10.0 新增）：回探组件是否真正就绪，而非只看 pip 退出码
            if check_installed(name):
                print("  ✅ 装后验证：%s 组件已就绪可正常调用" % name)
                audit("OK %s %s (装后验证通过)" % (name, " ".join(pkgs)))
                return True
            print("  ⚠️ 装后验证未通过：pip 返回成功但组件探测不到，可能装到了非当前解释器环境。")
            print("     排查：python -c \"import %s\" 看实际报错；或确认 pip 与当前解释器一致。" % "、".join(PROBES.get(name, ["目标模块"])))
            audit("POSTCHECK-FAIL %s %s（pip 成功但探测不到）" % (name, " ".join(pkgs)))
            return False
        print("❌ %s 安装失败 (exit %d)" % (name, r.returncode))
        audit("FAIL %s %s (exit %d)" % (name, " ".join(pkgs), r.returncode))
        print("  💡 回滚建议：pip uninstall %s（如部分已装）后重试；或换替代方式（转PDF/截图、粘贴文字）。"
              % " ".join(p.split("==")[0] for p in pkgs))
        return False
    except Exception as e:
        print("❌ %s 安装异常: %s" % (name, e))
        audit("EXC %s %s (%s)" % (name, " ".join(pkgs), e))
        return False


def main():
    ap = argparse.ArgumentParser(description="律师助手按需依赖安装器")
    ap.add_argument("--auto", action="store_true", help="智能检测：缺什么装什么（推荐）")
    ap.add_argument("--word", action="store_true", help="Word 导出依赖 (python-docx)")
    ap.add_argument("--pdf", action="store_true", help="PDF 解析依赖 (pymupdf, pdfplumber)")
    ap.add_argument("--ocr", action="store_true", help="图片 OCR 依赖 (easyocr, Pillow)")
    ap.add_argument("--audio", action="store_true", help="语音转写依赖 (websocket-client)")
    ap.add_argument("--office", action="store_true", help="Office 文档依赖 (python-pptx, openpyxl, xlrd)")
    ap.add_argument("--ai", action="store_true", help="AI 接口依赖 (openai)")
    ap.add_argument("--all", action="store_true", help="一键安装全部依赖")
    ap.add_argument("--yes", action="store_true", help="跳过交互确认（须已获用户明确同意）")
    ap.add_argument("--allow-no-hash", action="store_true",
                    help="允许在显式 y 确认后以“无哈希”方式安装（默认拒绝；仅可信网络下使用，v8.11.13 CD 供应链整改）")
    args = ap.parse_args()

    global ALLOW_NO_HASH
    ALLOW_NO_HASH = bool(getattr(args, "allow_no_hash", False))

    if args.auto:
        missing = [k for k in PACKAGES if not check_installed(k)]
        if not missing:
            print("✅ 检测完成：所有功能组件均已就绪，无需安装。")
            sys.exit(0)
        print("🔍 检测到未就绪组件：%s，开始按需安装……" % "、".join(missing))
        groups = missing
    elif args.all:
        groups = list(PACKAGES.keys())
    else:
        groups = [k for k in PACKAGES if getattr(args, k, False)]

    if not groups:
        print("💡 用法示例：")
        print("  python scripts/install_deps.py --auto     # 智能检测：缺什么装什么（推荐）")
        print("  python scripts/install_deps.py --word     # Word导出")
        print("  python scripts/install_deps.py --pdf      # PDF解析")
        print("  python scripts/install_deps.py --ocr      # 图片OCR")
        print("  python scripts/install_deps.py --audio    # 语音转写")
        print("  python scripts/install_deps.py --office   # Office全家桶")
        print("  python scripts/install_deps.py --all      # 一键全装")
        print("  python scripts/install_deps.py --yes      # 跳过确认（已获用户同意）")
        print("\n💡 跑 python scripts/doctor.py --quick 看看当前缺什么。")
        sys.exit(0)

    print("=" * 50)
    print("律师助手 · 按需依赖安装（白名单 %d 个锁定包）" % len(ALLOWED))
    print("=" * 50)

    all_ok = True
    for g in groups:
        ok = install_group(g, PACKAGES[g], yes=args.yes)
        all_ok = all_ok and ok

    print()
    if all_ok:
        print("✅ 全部依赖安装完成，高级功能已解锁（Word 导出、图片识别、语音转写、Office 批处理等），现在可以直接使用；未安装项有替代方案（转PDF、截图、粘贴文字、导出Markdown）。跑 python scripts/doctor.py --full 确认。")
        sys.exit(0)
    print("⚠️ 部分依赖未安装成功。可用替代方式（转PDF/截图、粘贴文字、导出Markdown）继续，不影响文字咨询。")
    sys.exit(1)


if __name__ == "__main__":
    main()
