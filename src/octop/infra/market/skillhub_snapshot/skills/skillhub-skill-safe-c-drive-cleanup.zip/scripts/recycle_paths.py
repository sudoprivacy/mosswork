import os, sys, ctypes
from ctypes import wintypes

class SHFILEOPSTRUCT(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("wFunc", wintypes.UINT),
        ("pFrom", ctypes.c_wchar_p),
        ("pTo", ctypes.c_wchar_p),
        ("fFlags", wintypes.UINT),
        ("fAnyOperationsAborted", wintypes.BOOL),
        ("hNameMappings", ctypes.c_void_p),
        ("lpszProgressTitle", ctypes.c_wchar_p),
    ]

FO_DELETE = 3
FOF_ALLOWUNDO = 0x40
FOF_NOCONFIRMATION = 0x10
FOF_SILENT = 0x0004
FOF_NOERRORUI = 0x0400

def recycle(path):
    op = SHFILEOPSTRUCT()
    op.hwnd = 0
    op.wFunc = FO_DELETE
    op.pFrom = path + "\0\0"
    op.pTo = None
    op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT
    res = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
    return res, bool(op.fAnyOperationsAborted)

def main():
    paths = sys.argv[1:]
    if not paths:
        print("usage: recycle_paths.py PATH1 [PATH2 ...]")
        sys.exit(2)
    for p in paths:
        if not os.path.exists(p):
            print(f"MISSING: {p}")
            continue
        res, ab = recycle(p)
        if res == 0 and not os.path.exists(p):
            print(f"RECYCLED: {p}")
        else:
            print(f"FAILED(code{res}): {p}")

if __name__ == "__main__":
    main()
