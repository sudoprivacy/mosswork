## Description: <br>
Helps agents prepare and submit PoYo GPT Image 2 generation and editing requests for `gpt-image-2` and `gpt-image-2-edit`, including text-to-image, reference-guided generation, multi-image editing, size, and resolution options. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to create PoYo GPT Image 2 payloads, submit them with curl or the bundled shell helper, and track task IDs for polling or webhook follow-up. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Prompts, image URLs, and callbacks are sent to PoYo's external API. <br>
Mitigation: Use only content appropriate for PoYo, and avoid secrets, private or internal image URLs, and sensitive prompt content unless that disclosure is approved. <br>
Risk: API keys can be exposed when passed directly as command-line arguments. <br>
Mitigation: Prefer the POYO_API_KEY environment variable and avoid placing bearer tokens in prompts, payloads, logs, or shell history. <br>
Risk: The skill can submit user-provided JSON to an external generation endpoint. <br>
Mitigation: Review payloads before execution and retain the returned task_id so status polling or webhook follow-up remains auditable. <br>


## Reference(s): <br>
- [PoYo GPT Image 2 API Reference](references/api.md) <br>
- [PoYo GPT Image 2 model page](https://poyo.ai/models/gpt-image-2) <br>
- [PoYo GPT Image 2 API docs](https://docs.poyo.ai/api-manual/image-series/gpt-image-2) <br>
- [PoYo GPT Image 2 OpenAPI JSON](https://docs.poyo.ai/api-manual/image-series/gpt-image-2.json) <br>
- [ClawHub skill page](https://clawhub.ai/coolhackboy/skills/poyo-gpt-image-2) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Markdown, Code, Shell commands, Configuration, API calls] <br>
**Output Format:** [Markdown guidance with JSON payloads and shell commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May submit requests to PoYo and return a task_id when a call is made; requires POYO_API_KEY.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
