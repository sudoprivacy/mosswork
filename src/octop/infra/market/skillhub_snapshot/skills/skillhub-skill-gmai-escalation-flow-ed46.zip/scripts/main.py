# -*- coding: utf-8 -*-
"""升级流程设计器（gmai-escalation-flow-ed46）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：升级流程方案（分级升级路径与时限）；升级触发条件与判定表；通知机制与责任分工要点
建议输入（专业字段）：机构类型；业务场景
"""
import json, os, re, sys, time

SLUG = "gmai-escalation-flow-ed46"
TITLE = "升级流程设计器"
PRICE_FEN = 290
CATEGORY = "客户支持与知识库"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['机构类型', True, ['机构', '单位类型', '场所'], '机构类型决定适用的管理规范'], ['业务场景', True, ['场景', '业务流程', '服务内容'], '界定流程与质控范围'], ['人员配置', False, ['人员', '岗位配置', ' staffing'], '角色缺位是流程失效的常见原因']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'flow': [['接入与识别', '识别客户与问题类型，按优先级标记'], ['首次响应', '在承诺时限内首次响应并给出处理计划'], ['处理与升级', '按流程处理，超出范围按升级路径转交'], ['确认与关闭', '与客户确认解决结果后关闭工单'], ['归档与沉淀', '将可复用解法沉淀进知识库并标注适用条件']], 'kpis': [['首次响应时长', '≤30 分钟', '首次响应时刻 − 受理时刻', '工单系统'], ['一次解决率', '≥75%', '一次解决工单 ÷ 工单总数', '工单系统'], ['工单超时率', '≤2%', '超时工单 ÷ 工单总数', '工单系统'], ['知识库命中率', '≥60%', '命中知识库的工单 ÷ 工单总数', '知识库访问日志'], ['满意度', '≥90%', '满意评价数 ÷ 有效评价数', '评价问卷']]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['医疗机构质量管理与患者安全目标的相关管理要求', '病历与记录书写规范：及时、准确、完整、可追溯', '医疗质量安全事件报告制度（按机构与监管要求上报）', '个人信息保护与患者信息保密要求（最小必要、限定用途）', '消毒隔离与操作规范要求（按业务类型适用）', '广告与宣传合规：不得发布未经审批的医疗宣传内容']
# 自检项（输入完备度）
CHECKS = [['升级流程设计·服务场景梳理', ['升级流程设计', '按等级设计升级路径与时限'], '先梳理咨询类型、渠道与优先级'], ['升级流程设计·流程与知识设计', ['按等级设计升级路径与时限', '升级流程设计器'], '按场景设计处理流程与知识库结构'], ['升级流程设计·指标与阈值设定', ['升级流程设计器', '升级流程设计'], '按效率与质量维度设定指标与阈值'], ['升级流程设计·合规红线', ['升级流程设计'], '识别泄露客户信息与虚假承诺情形，命中即终止'], ['升级流程设计·交付与培训清单', ['升级流程设计', '按等级设计升级路径与时限'], '输出话术文档与培训要点']]
# 交付物构成
DELIVERABLES = ['升级流程方案（分级升级路径与时限）', '升级触发条件与判定表', '通知机制与责任分工要点']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """医疗健康运营交付物：流程与角色 → 质控指标 → 合规边界 → 记录模板 → 改进措施"""
    P = ctx["spec"]["params"]; L = []
    org = ctx["fv"]("机构类型")
    scene = ctx["fv"]("业务场景") or ctx["spec"]["title"]
    kpis = P.get("kpis") or []      # [[指标, 目标值, 计算方式, 数据来源], ...]
    staff = ctx["fv"]("人员配置")
    flow = P.get("flow") or []

    L.append(("一、流程与角色", [
        "- 机构类型：%s" % (brief(org, 40) or "（未提供，机构类型决定适用的管理规范）"),
        "- 业务场景：%s" % (brief(scene, 50)),
        "- 人员配置：%s" % (brief(staff, 50) or "（未提供，角色缺位是流程失效的常见原因）"),
        "",
        "| 环节 | 执行角色 | 关键动作 | 留痕 |", "|---|---|---|---|",
    ] + (["| %d. %s | 待明确 | %s | 记录表单/系统留痕 |" % (i, f[0], f[1]) for i, f in enumerate(flow, 1)]
         if flow else ["| 1. 待补充环节 | 待明确 | 需按实际业务梳理 | — |"])))

    rows = ["| 指标 | 目标值 | 计算方式 | 数据来源 | 监测频次 |", "|---|---|---|---|---|"]
    for k in kpis:
        rows.append("| %s | %s | %s | %s | 月度 |" % (k[0], k[1], k[2], k[3]))
    if not kpis:
        rows.append("| 待补充指标 | — | — | — | — |")
    L.append(("二、质控与管理指标", rows))

    L.append(("三、合规边界", [
        "- 本技能输出为运营管理参考，**不构成医疗诊断、治疗建议或疗效评价**；涉及诊疗的判断由具备资质的医务人员作出。",
        "- 涉及患者信息处理的环节，须遵循个人信息保护与医疗数据管理的相关规定，做到最小必要、限定用途、可追溯。",
        "- 涉及药品、器械、诊疗科目与广告宣传的，须遵守相应监管要求；不得发布未经审批的医疗宣传内容。",
        "- 涉及不良事件或医疗质量安全事件的，按机构制度与监管要求上报，不得瞒报或延迟报告。",
    ]))

    L.append(("四、记录模板", [
        "| 记录 | 必填要素 | 保存要求 |", "|---|---|---|",
        "| 业务登记记录 | 时间、对象标识、事项、执行人、结果 | 按规定期限保存，可追溯 |",
        "| 质量检查记录 | 检查项、标准、结果、整改要求、复核人 | 留存备查 |",
        "| 异常/不良事件记录 | 发生经过、影响、处置、上报状态 | 按规定上报并留档 |",
        "| 培训与考核记录 | 内容、对象、时间、结果 | 留存备查 |",
        "",
        "记录设计原则：**谁执行谁记录、当班当次记录、修改留痕**。",
    ]))

    L.append(("五、改进措施", [
        "| 方向 | 措施 | 验证方式 |", "|---|---|---|",
        "| 流程标准化 | 把高频操作固化为标准流程与检查表 | 执行一致率抽样 |",
        "| 指标可视化 | 关键指标按月出图，异常自动提示 | 指标台账月度趋势 |",
        "| 角色补位 | 明确每个环节的执行与复核角色 | 岗位职责与实际相符 |",
        "| 培训闭环 | 培训—考核—上岗—复训形成闭环 | 考核记录 |",
        "| 反馈机制 | 建立对象反馈渠道并定期复盘 | 反馈处理率 |",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
