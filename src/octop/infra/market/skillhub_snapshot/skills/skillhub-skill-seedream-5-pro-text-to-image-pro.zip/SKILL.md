---
name: skillhub-skill-seedream-5-pro-text-to-image-pro
description: "当用户想根据中文描述生成海报、商品营销图、信息图、社交媒体配图、插画或写实场景图时使用。需要用户提供清晰的画面描述。"
---

# Seedream 5 Pro 文生图助手

根据中文或英文描述生成 1K JPEG 图片，适合中文海报、商品营销图、信息图、社交配图、写实人物和创意插画。

## 适用场景
- 生成带中文标题、卖点和排版要求的活动海报、商品宣传图和封面图。
- 根据描述制作人物、风景、产品、插画、信息图和广告创意。
- 按方图、横版或竖版规格生成小红书、公众号、短视频封面和电商视觉。
- 生成课程封面、品牌活动视觉、节日祝福图和旅行攻略配图。
- 为人物、宠物、家居、餐饮和科技产品生成创意场景图。

## 不适用场景
- 已有原图需要局部修改：使用 Gemini Nano Banana 2 图片编辑助手。
- 要精确替换原图中的文字或物品：使用专用图片编辑 Skill。
- 要生成透明底素材：使用人物商品抠图去背景助手。

## 输入与结果建议
- 必填 `prompt`：尽量写清主体、场景、风格、构图、颜色、光线和需出现的文字。
- 可选 `aspect_ratio`：仅支持 `1:1`、`16:9`、`9:16`；默认 `1:1`。
- 固定输出 1K JPEG 图片。中文文字、复杂表格和小字号内容可能出现误字，应在交付前人工复核。

## 支付前置检查
1. 默认携带正常、非空的浏览器 `User-Agent`；环境支持时携带真实 `Origin` 和 `Referer`，不得伪造来源。
2. 以 JSON `POST https://imcopilot.com/v1/image/paid-seedream-5-pro-generator-v100`，提交 `prompt` 和可选 `aspect_ratio`。
3. 收到 HTTP `402` 时，保存 `WeixinPay-Required` 与 `X-Out-Trade-No`，通过 `weixinpay_pay` 完成支付授权。
4. 支付后使用原 `prompt`、原 `aspect_ratio` 与原 `X-Out-Trade-No` 重试原请求；不得改内容或新建订单。
5. 收到 `202` 后，每隔 5 秒以 `GET /v1/orders/{out_trade_no}/job` 查询；`SUCCEEDED` 后以 `GET /v1/orders/{out_trade_no}/result` 下载结果，结果保留 5 天。

## Pay Skill 支付服务声明
服务端会按当前 Skill slug 与版本创建微信订单，并在未付款时返回 HTTP `402`、`WeixinPay-Required` 响应头和 `WeixinPay` 响应体。确认支付后才生成并交付结果；处理终态失败时发起原路退款。

## 效果复核
检查主体、中文文字、关键卖点、比例和画面风格是否符合提示词；若文字错误、排版偏差或主体不符，应修改提示词后重新生成新订单。

## 失败与退款
上游明确失败或任务超时，系统会标记为 `FAILED` 并发起原路退款。继续查询原订单的 `refund_status`，不要重复下单。
