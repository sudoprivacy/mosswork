---
name: skillhub-skill-aistockresearcher
description: "# 股票研究员 v14.0 — 真实数据 + 概率预测 + 研究闭环 + 可导出报告"
---

# 股票研究员 v14.0 — 真实数据 + 概率预测 + 研究闭环 + 可导出报告

> 🆕 v14 在 v13 之上补齐研究闭环：多标的批量研究出对比表并带数据质量门槛，两份简报可直接 diff 出评分/方向/概率/质量/因子的变化并判定是否实质性变化。同时修复了证据时间与数据截止被当前时间顶替、弃权仍展示占位概率、缓存清理只清内存不删磁盘等诚实性问题。v12 统一摄入/证据链与 v13 导出能力全部保留。

## 🔁 v14 研究闭环（新增）

```bash
python scripts/research_hub_cli.py batch --symbols "600519,hk:00700,AAPL" --format markdown
python scripts/research_hub_cli.py batch --symbols "600519,110022,RB2610" --min-quality derived --format both --out data/reports/group
python scripts/research_hub_cli.py diff --old reports/old.json --new reports/new.json --format markdown
```

- 批量研究：单标的失败只落一行错误，不中断整批；`--min-quality` 未达标退出码 5。Python API：`BatchResearcher(hub).run(symbols)` → `BatchResult`。
- 报告差异：评分/方向/置信度/质量/周期概率/因子/风险对比；`--fail-on-material` 在实质性变化（评分≥10 分、方向翻转、质量状态变化、概率≥10 个百分点）时退出码 4。

## 🧠 v12 研究智能中枢（新增）

### 它解决什么

| 旧流程 | v12 统一流程 |
|---|---|
| 行情、新闻、资金、财务各查各的 | 一个 `ResearchHub.analyze()` 并行获取并归一化 |
| 分析结论无法回溯 | 每条因子绑定 `evidence_id`，报告附来源/时间/质量 |
| 只给一个方向分 | 1d/5d/1M/3M/6M 概率、分位数、90% 区间、情景 |
| 预测像确定结论 | 输出样本量、Brier 技能分；样本不足/校准失败自动弃权 |
| 只能查实时接口 | 同时支持 CSV/TSV/JSON/JSONL/XLSX/PDF/TXT/MD 与受限 URL |
| 期货快照只有元数据 | 优先真实报价；无法取得时标记 `unavailable`，绝不伪造 |
| 新闻简单关键词计数 | 去重、来源可信度、事件类型、时间衰减、冲突保留 |
| 场外基金冒充实时 | 官方净值与盘中估值分栏，明确估值不等于净值 |

### 一键命令

```bash
# 离线能力自检（不联网）
python scripts/research_hub_cli.py doctor --offline

# 在线研究：行情 + 新闻 + 资金 + 基本面 + 预测 + 证据链
python scripts/research_hub_cli.py analyze --symbol 600519 --format markdown
python scripts/research_hub_cli.py analyze --symbol 110022 --asset-type fund --format both --out data/reports/fund_110022
python scripts/research_hub_cli.py analyze --symbol RB2610 --asset-type futures --contracts RB2610,RB2611,RB2701 --spot 3100

# 有界实时刷新（不启动常驻线程）
python scripts/research_hub_cli.py live --symbols 600519,510300,AU2502 --iterations 3 --interval 15

# 分析已有文件 / 已获取信息
python scripts/research_hub_cli.py file --path data/prices.csv --symbol 600519 --format json
python scripts/research_hub_cli.py file --path data/nav.xlsx --symbol 110022 --asset-type fund --mapping '{"close":"单位净值","date":"日期"}'
```

### Python API

```python
from stock_researcher import ResearchHub, quick_research, DatasetLoader

# 一键研究（在线）
report = ResearchHub().analyze("600519", question="当前风险收益比如何？")
print(report.direction, report.confidence, report.score)
print(report.executive_summary)
print(ResearchHub.to_markdown(report))   # 可审计 Markdown
print(report.to_json())                  # 结构化 JSON

# 已有 CSV/XLSX/PDF/文本 → 统一数据 → 分析
report = ResearchHub().analyze_dataset("data/prices.csv", symbol="600519")

# 已有信息：CollectedData(quote=..., history=..., news=...) 显式注入，不触网
# 概率预测：EmpiricalForecastEngine().forecast_multi(prices) 返回5周期分布与校准
```

### 新增 MCP 工具
- `research_brief`：一次调用完成行情 + 历史 + 新闻/公告 + 资金 + 基本面 + 多资产分析 + 概率预测 + 证据链，可返回 JSON/Markdown。
- `analyze_local_dataset`：分析本地 CSV/JSON/XLSX/PDF/文本文件，支持字段映射。

### 执行门禁（v12）

1. 先取数并记录 `as_of`、来源、时效、质量；未知就说未知。
2. 事实、推断、预测分开写；结论绑定证据 ID。
3. 预测必须给概率/区间/样本量/质量；样本不足或校准失败时明确弃权。
4. 新闻/公告必须去重、标注来源可信度；冲突证据并列，不强行合成。
5. 场外基金盘中估值不得写成官方净值；期货缺失报价写 `unavailable`。
6. 报告末尾附免责声明，不输出确定性买卖指令或收益保证。

## 🆕 v13 本轮变更（数据真实性 + 概率预测 + 报告导出）

- **数据层**：源返回空壳/0 价统一标 unavailable 并逐级降级；akshare 全市场大表按代码裁行（裁不到交给降级）；第三方调用加墙钟超时；路由表按真实条目统计。
- **预测层**：kNN 邻域分位与全局分位按有效样本量收缩融合；方向概率取经验分布 Φ(μ/σ)，上限 0.85；70% 区间用 Z=1.036σ；同桶历史命中校准需显式开启；弃权行与摘要不再打印占位概率。
- **期货口径**：到期日按交易所规则（CFFEX 股指/商品第 3 个周五、国债第 2 个周五、其他商品 15 日）；主力合约按持仓量确认（缺失时用成交量）。
- **报告导出**：纯标准库渲染与可选第三方引擎两条路都通，且同吃一棵格式中立 IR：

```python
from stock_researcher.research_export import export_bytes
docx = export_bytes(report, "docx", engine="auto")   # 内置 OOXML 或 python-docx
pptx = export_bytes(report, "pptx", engine="auto")
pdf  = export_bytes(report, "pdf",  engine="auto")    # 内置 CID 字体，不嵌字体文件
```

MCP 工具 `export_report(path, fmt, report_json=...)` 可直接把研究简报落盘成 Word/PPT/PDF/Markdown/JSON/纯文本。

- **安全开关**：`STOCK_RESEARCHER_DIRECT_CONNECT=1` 才改全局 opener；语音 SAPI 与外部 MCP 子进程分别需 `STOCK_RESEARCHER_ENABLE_VOICE=1` / `STOCK_RESEARCHER_ENABLE_EXTERNAL_MCP=1`。导入包不产生进程、全局副作用或网络请求；语音与外部 MCP 模块只留在源码树，口语指令解析保留在 `voice_command.py`。

> 纯 Python 标准库核心，零 pip 依赖。覆盖 12 个全球市场 + 股票/基金/指数/债券/商品/期货/货币基金/可转债；数据源：腾讯 + 东方财富 + akshare + 新浪 + 雪球 + 同花顺 + yfinance（均免费无 Key）。

## ⚠️ 支持范围与限制（重要，请先读）

### v11.0 数据源（12 个）

| 数据源 | 标识 | 覆盖 | Key |
|------|------|------|-----|
| 东方财富 API | `eastmoney_api` | A 股/指数/资金流 | ❌ |
| 新浪财经 | `sina` 🆕 | A 股/港股/美股/K线 | ❌ |
| 雪球 | `xueqiu` 🆕 | A 股行情+情绪 | ❌ |
| 同花顺 | `tonghuashun` 🆕 | A 股行情+资金流 | ❌ |
| 期货交易所 | `futures_exchange` 🆕 | 上期所/大商所/郑商所 | ❌ |
| akshare | `akshare` | A 股/基金/期货/宏观/可转债 | ❌ |
| yfinance | `yfinance` | 全球市场 | ❌ |
| Finnhub | `finnhub` | 美股深度 | ✅ 可选 |
| 腾讯 | `tencent` | A 股/港股/美股 | ❌ |
| 外部 MCP | `external_mcp` | 金融六日桥接（需显式授权；上架包不含该模块） | 视子 MCP |

### 限制

| 限制 | 说明 |
|------|------|
| 🔴 需国内直连 | 腾讯/东财/新浪/雪球/同花顺为国内接口，开代理反而失败。v13 起默认不改全局 opener，需要时设 `STOCK_RESEARCHER_DIRECT_CONNECT=1` |
| 🔴 非实时数据 | 国内接口延迟约 3~5 秒，非交易时段返回收盘价 |
| 🔴 评分≠盈利 | 概率来自历史相似条件下的经验分布（样本不足会弃权），不保证未来收益 |
| 🟡 不构成投资建议 | 仅供学习参考 |
| 🟡 akshare 可选 | 部分高级功能（基金净值/债券/可转债/宏观）需 `pip install akshare` |
| 🟡 金融六日 MCP | 配置 `STOCK_RESEARCHER_EXTERNAL_MCP_COMMAND` 环境变量启用 |
| 🟡 场外基金无实时净值 | 盘中估值仅作参考；申购赎回以基金公司确认净值为准 |
| 🟡 期货真实报价 | 优先新浪/东财公开接口；失败时明确标记 `unavailable`，不返回伪报价 |
| 🟢 v12 概率预测 | 输出分布、区间、样本量与 Brier 技能分；样本/校准不足会主动弃权 |

## ⚡ 快速上手

```bash
# v11.0 新增功能
python -c "from stock_researcher import predict_multi_horizon; print(predict_multi_horizon('600519').overall_signal)"
python -c "from stock_researcher import get_router; r=get_router(); print(r.query_money_flow('600519').source)"
python -c "from stock_researcher import analyze; print(analyze('futures_analysis', {'contract':'AU2502', ...}).content[:200])"

# v10.0 + v9.x（兼容）
python scripts/stock_predict.py 600519
python scripts/stock_predict.py --masters 600519
python scripts/stock_predict.py --topdown cn
```

## MCP Server 26 工具（v14）

```bash
# 配置 Claude Code mcpServers
{
  "mcpServers": {
    "stock-researcher": {
      "command": "python",
      "args": ["./mcp_server.py"],
      "env": {
        "DEEPSEEK_API_KEY": "sk-...",
        "PYTHONDONTWRITEBYTECODE": "1",
        # 可选：金融六日外部 MCP（需 STOCK_RESEARCHER_ENABLE_EXTERNAL_MCP=1）
        "STOCK_RESEARCHER_EXTERNAL_MCP_COMMAND": "python jinrong_liuri.py",
        "STOCK_RESEARCHER_EXTERNAL_MCP_NAME": "金融六日",
        "STOCK_RESEARCHER_EXTERNAL_MCP_ENV_TOKEN": "your_token"
      }
    }
  }
}
```

工具分类：

| 类别 | 工具数 | 工具 |
|------|--------|------|
| 数据查询 | 5 | get_stock_quote / get_fund_nav / get_macro_data / **get_futures_quote** 🆕 / list_data_sources |
| AI 分析 | 11 | ai_analyze_stock / ai_analyze_fund / ai_analyze_market_regime / ai_analyze_master_council / ai_analyze_macro_outlook / ai_analyze_risk_report / ai_analyze_sector_rotation / **ai_analyze_futures** 🆕 / **ai_analyze_money_flow** 🆕 / **ai_analyze_index_forecast** 🆕 / **ai_analyze_portfolio** 🆕 |
| 量化分析 | 3 | run_master_council / quick_predict / **predict_multi_horizon** |
| 统一研究 🆕 | 2 | **research_brief** / **analyze_local_dataset** |
| 报告导出 | 2 | export_report / list_export_formats |
| 研究闭环 🆕 | 2 | **research_batch** / **diff_research_reports** |
| 系统 | 1 | get_skill_status |

## 🆕 v11.0/v12 核心 API

```python
from stock_researcher import (predict_multi_horizon, get_router, DataCategory,
                              ResearchHub, EmpiricalForecastEngine, quick_research)
router = get_router()
quote = router.query_with_validation("cn", DataCategory.REALTIME_QUOTE,
                                      validate_field="price", code="600519")
report = ResearchHub().analyze("600519")     # 统一研究 + 证据链
forecasts = EmpiricalForecastEngine().forecast_multi(prices)
```

## 🆕 v11.0 AI 模板（11 类）

股票/基金/市场体制/大师圆桌/宏观/风险/板块轮动/期货/资金流/指数预测/组合诊断；字段与调用示例见 README 与 `ai_analysis_engine.py`。

## 🎯 期货 v11.0 专项

```python
# 期货交易所路由
from stock_researcher.data_multi_source import FuturesExchangeAdapter
ad = FuturesExchangeAdapter()
print(ad._resolve_exchange("AU2502"))   # shfe (上期所)
print(ad._resolve_exchange("M2501"))    # dce (大商所)
print(ad._resolve_exchange("SR2501"))   # czce (郑商所)

# AI 期货分析
from stock_researcher import analyze
result = analyze("futures_analysis", {
    "contract": "AU2502", "symbol": "AU", "exchange": "SHFE",
    "price": "500", "change_pct": "1.0",
    "open_interest": "100000", "volume": "50000",
    "basis": "5", "roll_yield": "3.5",
    "top5_long": "...", "top5_short": "...",
    "forecast_5d": "[495, 505]",
})
print(result.content)
```

## 🤖 预测算法 v11.0

```python
from stock_researcher.prediction_v1100 import (
    predict_horizon, predict_multi_horizon,
    detect_asset_type, calibrate_probability,
    HORIZON_DAYS, HORIZON_WEIGHTS,
)

# 资产类型自动识别
print(detect_asset_type("600519"))      # stock
print(detect_asset_type("110022"))      # fund
print(detect_asset_type("AU2502"))      # futures
print(detect_asset_type("idx:000300"))  # index

# 多周期预测（权重：1d 10% + 5d 20% + 1M 30% + 3M 25% + 6M 15%）
result = predict_multi_horizon("600519", prices=[100, 101, 102, ...])
print(f"综合: {result.overall_signal}, 置信度: {result.overall_confidence}")

# 单周期
from stock_researcher.prediction_v1100 import predict_horizon
pred = predict_horizon(prices, horizon="1M", regime="bullish")
print(pred.direction, pred.expected_return, pred.range_low, pred.range_high)

# 概率校准
cal = calibrate_probability(0.7, history=[(0.65, True), (0.7, False), ...])
print(f"校准: {cal.raw_probability} → {cal.calibrated_probability}")
```

## 🧠 AI 深度解读配置

```bash
# 设置环境变量启用 LLM（推荐 DeepSeek，国内直连友好）
export DEEPSEEK_API_KEY=sk-xxx

# 或在 config/settings.json 填写 llm.api_key（不推荐）
{
  "llm": {
    "provider": "deepseek",
    "model": "deepseek-chat",
    "temperature": 0.3,
    "max_tokens": 2000
  }
}
```

无 API Key 时自动降级到规则化模板输出。

## 📦 目录速查

```
stock_researcher/
├── data_multi_source.py        # v11 多源数据层（12 适配器 + 交叉验证 + 异常检测 + unavailable 标记）
├── ai_analysis_engine.py       # v11 AI 模板（11 类）
├── prediction_v1100.py         # 多周期预测器（经验分布 + 分位数 + 概率 + 校准）
├── research_hub.py             # v12 研究编排（数据 → 分析 → 预测 → 证据链）
├── research_analysis.py        # 条件分布与 kNN 邻域收缩
├── research_batch.py           # v14 批量研究 + 报告差异
├── report_ir.py                # v13 报告中间表示（格式中立 IR）
├── research_export.py          # v13 导出门面（docx/pptx/pdf/markdown/json/text）
├── export_docx.py              # v13 Word 渲染（纯 OOXML + 可选 python-docx）
├── export_pptx.py              # v13 PPT 渲染（纯 OOXML + 可选 python-pptx）
├── export_pdf.py               # v13 PDF 渲染（内置 CID 字体，不嵌字体文件）
├── voice_command.py            # 口语指令解析（纯文本，随包交付）
├── voice_interface.py          # 语音 SAPI 会话 —— 只在源码树，上架包不含
├── mcp_external_bridge.py      # 外部 MCP 桥 —— 只在源码树，上架包不含
├── data_*.py                   # 数据源（akshare/东方财富/新浪/雪球/同花顺/期货所）
├── quantitative_*.py           # 量化（指标/因子/组合优化/MC/回测/债券/货基/可转债）
├── fusion_*.py                 # 十维信号融合多周期预测
├── core_*.py                   # 分析器/预测引擎/技术/估值
├── value_investing_*.py        # DCF/护城河/财务健康/管理层/行业
├── funds.py / index_analysis_*.py / sector_analysis_*.py / agents_*/ ...
├── constants.py                # v14.0 VERSION="14.0.0"
```

## ❓ 常见问题

### Q1: 金融六日 MCP 怎么接入？
**A**: 设置环境变量：
```bash
export STOCK_RESEARCHER_EXTERNAL_MCP_COMMAND="python jinrong_liuri_mcp_server.py"
export STOCK_RESEARCHER_EXTERNAL_MCP_NAME="金融六日"  # 可选
export STOCK_RESEARCHER_EXTERNAL_MCP_ENV_TOKEN="xxx"  # 可选透传环境变量
```
然后调用 `bridge.auto_connect()` 或 `router.register_external_mcp(command, allow=True)`；没有显式授权时只登记命令、不启动任何进程。

### Q2: v11.0 数据获取更及时了吗？
**A**: 是的。v11.0 引入：
- ETag/If-Modified-Since 缓存（304 直接复用）
- 时效分级标签（数据获取时间戳 + freshness 字段）
- 多源交叉验证（同一字段多源比对）
- 3σ + IQR 二阶段异常值检测

### Q3: 新增数据源需要 Key 吗？
**A**: 新浪/雪球/同花顺/期货所都不需要 Key。Finnhub 需要 API Key。

### Q4: 预测评分 70 分是不是一定会涨？
**A**: **不是**。评分 70 只是综合打分，不等于 70% 的上涨概率；概率看报告里的概率字段（经验分布 + 可选校准），且不保证未来。

### Q5: 期货分析支持哪些交易所？
**A**: v11.0 支持上期所（SHFE）/ 大商所（DCE）/ 郑商所（CZCE）。中金所（CFFEX）可通过 akshare 补充。

### Q6: 如何使用多周期预测？
**A**: `predict_multi_horizon(code, prices=...)，返回 1d/5d/1M/3M/6M 五个周期的方向+概率+置信度+区间。`

## 免责声明

> ⚠️ **本工具仅供学习参考，不构成任何形式的投资建议。** 股市有风险，投资需谨慎。