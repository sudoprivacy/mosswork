# -*- coding: utf-8 -*-
"""v13.0 导出注册表（research_export）测试。

这里管的是"一个入口、六种格式"的契约：别名归一、按环境如实报告能力、失败必须
返回结构而不是抛异常、路径补齐不能把文件写到用户没点的地方。渲染细节在
test_v1300_export_{docx,pptx,pdf}.py 里各自验。
"""
import json
import os
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stock_researcher import research_export as rx
from stock_researcher.report_ir import (
    Bullets, Callout, Heading, MetricGrid, Paragraph, ReportDocument, Section, Table,
)

MARKERS = {
    "title": "贵州茅台 研究简报",
    "summary": "估值分位 68%，现金流 A 级。",
    "row": "+2.4%",
    "risk": "渠道库存去化不及预期",
    "note": "本报告仅供研究参考，不构成投资建议。",
}


def make_doc():
    return ReportDocument(
        title=MARKERS["title"],
        subtitle="综合方向 bullish｜置信度 62%",
        meta=[("标的", "600519（stock）"), ("数据截止", "2026-09-25")],
        sections=[
            Section("一、结论摘要", [
                Paragraph(MARKERS["summary"], "lead"),
                Heading("核心结论", 3),
                Bullets(["ROE 维持 18% 以上", "现金流 A 级"], ordered=False),
            ]),
            Section("二、多周期概率预测", [
                Table(header=["周期", "方向", "中位收益"],
                      rows=[["20日", "震荡", "+0.8%"], ["60日", "偏多", MARKERS["row"]]],
                      align=["left", "center", "right"]),
                Callout("概率来自历史条件样本的非参数估计。"),
            ]),
            Section("三、风险", [
                MetricGrid([("完整度", "92%"), ("质量分", "0.71")]),
                Bullets([MARKERS["risk"]], ordered=True),
            ]),
        ],
        disclaimer=MARKERS["note"])


def sample_payload():
    return {"symbol": "600519", "name": "贵州茅台", "run_id": "r-1",
            "executive_summary": MARKERS["summary"],
            "conclusions": ["ROE 维持 18% 以上"],
            "risks": [MARKERS["risk"]],
            "disclaimer": MARKERS["note"]}


class TestNormalizeFormat(unittest.TestCase):
    def test_every_alias_maps_to_a_real_format(self):
        for alias, want in [("word", "docx"), ("DOC", "docx"), ("Writer", "docx"),
                            ("ppt", "pptx"), ("PowerPoint", "pptx"), ("slides", "pptx"),
                            ("md", "markdown"), ("txt", "text"), ("pdf", "pdf"),
                            (".docx", "docx"), ("  pptx ", "pptx")]:
            self.assertEqual(rx.normalize_format(alias), want, alias)
        self.assertEqual(rx.normalize_format("json"), "json")

    def test_empty_or_none_is_not_silently_defaulted(self):
        for bad in ("", None, "xls", "keynote", "html"):
            with self.assertRaises(ValueError, msg=str(bad)):
                rx.normalize_format(bad)


class TestCapabilityReporting(unittest.TestCase):
    def test_text_formats_are_always_available(self):
        available = rx.available_formats()
        for fmt in rx.ALL_FORMATS:
            if fmt in ("markdown", "json", "text"):
                self.assertIn(fmt, available)

    def test_binary_formats_reported_iff_renderer_imports(self):
        available = rx.available_formats()
        for fmt in ("docx", "pptx", "pdf"):
            self.assertEqual(fmt in available, rx._renderer(fmt) is not None)

    def test_engines_for_text_format_is_empty(self):
        self.assertEqual(rx.engines_for("markdown"), [])
        self.assertEqual(rx.engines_for("json"), [])

    def test_engines_for_binary_format_lists_stdlib_first(self):
        for fmt in ("docx", "pptx", "pdf"):
            engines = rx.engines_for(fmt)
            if engines:
                self.assertEqual(engines[0], "stdlib", fmt)

    def test_unknown_format_engines_raises(self):
        with self.assertRaises(ValueError):
            rx.engines_for("exe")


class TestRenderBytesAndText(unittest.TestCase):
    def test_export_bytes_for_each_binary_format(self):
        for fmt in ("docx", "pptx", "pdf"):
            blob = rx.export_bytes(make_doc(), fmt)
            self.assertGreater(len(blob), 500, fmt)

    def test_export_bytes_rejects_text_formats(self):
        with self.assertRaises(rx.ExportError):
            rx.export_bytes(make_doc(), "markdown")

    def test_render_text_markdown_and_text_and_json(self):
        doc = make_doc()
        md = rx.render_text(doc, "md")
        self.assertIn("# " + MARKERS["title"], md)
        self.assertIn("| " + MARKERS["row"] + " |", md)
        self.assertIn(MARKERS["note"], md)
        self.assertEqual(rx.render_text(doc, "text"), doc.plain_text())
        parsed = json.loads(rx.render_text(doc, "json"))
        self.assertEqual(parsed["title"], MARKERS["title"])
        self.assertIn("ir_version", parsed)

    def test_render_text_rejects_binary(self):
        with self.assertRaises(rx.ExportError):
            rx.render_text(make_doc(), "docx")

    def test_dict_payload_and_ir_document_share_one_markdown_engine(self):
        """Markdown 只有一条生成链：dict 走 IR、IR 直接渲染，不能各写一版正文。"""
        from_dict = rx.render_text(sample_payload(), "markdown")
        from_doc = rx.render_text(make_doc(), "markdown")
        self.assertIn(MARKERS["summary"], from_dict)
        self.assertIn(MARKERS["risk"], from_dict)
        self.assertIn("## 一、结论摘要", from_doc)
        self.assertEqual(from_doc.count("# 贵州茅台"), 1)

    def test_json_of_ir_has_block_types(self):
        parsed = json.loads(rx.render_text(make_doc(), "json"))
        blocks = parsed["sections"][1]["blocks"]
        self.assertEqual(blocks[0]["type"], "Table")


class TestExportToFile(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_all_six_formats_write_and_report_size(self):
        for fmt in rx.ALL_FORMATS:
            target = self.dir / ("out_" + fmt)
            result = rx.export(make_doc(), fmt, target)
            self.assertTrue(result["success"], result)
            written = Path(result["path"])
            self.assertEqual(written.suffix, rx._SUFFIX[fmt], fmt)
            self.assertTrue(written.exists())
            self.assertEqual(written.stat().st_size, result["bytes"], fmt)
            self.assertGreater(result["bytes"], 0)
            self.assertEqual(result["format"], fmt)

    def test_text_export_writes_lf_so_bytes_match_disk(self):
        """文本模式在 Windows 上会把 \n 翻成 \r\n，返回字节数就和文件大小不符。"""
        result = rx.export(make_doc(), "markdown", self.dir / "nl.md")
        blob = Path(result["path"]).read_bytes()
        self.assertNotIn(b"\r\n", blob)
        self.assertEqual(len(blob), result["bytes"])
        self.assertEqual(blob.decode("utf-8"), rx.render_text(make_doc(), "md"))

    def test_binary_magic_matches_format(self):
        self.assertTrue(rx.export(make_doc(), "docx", self.dir / "a").get("success"))
        with zipfile.ZipFile(str(self.dir / "a.docx")) as z:
            self.assertIn("word/document.xml", z.namelist())
        self.assertTrue(rx.export(make_doc(), "pptx", self.dir / "b")["success"])
        with zipfile.ZipFile(str(self.dir / "b.pptx")) as z:
            self.assertTrue(any(n.startswith("ppt/slides/") for n in z.namelist()))
        rx.export(make_doc(), "pdf", self.dir / "c")
        self.assertEqual((self.dir / "c.pdf").read_bytes()[:5], b"%PDF-")

    def test_failure_returns_structure_and_never_raises(self):
        result = rx.export(make_doc(), "exe", self.dir / "bad")
        self.assertFalse(result["success"])
        self.assertIn("未知的导出格式", result["error"])
        for key in ("format", "engine", "path", "bytes", "error"):
            self.assertIn(key, result)

    def test_unrelated_payload_does_not_produce_a_blank_file(self):
        """传错对象时必须失败，而不是静默落一份排版精美、内容全空的报告。"""
        result = rx.export({"nothing": 1}, "pdf", self.dir / "ghost.pdf")
        self.assertFalse(result["success"])
        self.assertIn("报告字段", result["error"])
        self.assertFalse((self.dir / "ghost.pdf").exists())

    def test_bad_engine_reports_error_instead_of_degrading_silently(self):
        result = rx.export(make_doc(), "pdf", self.dir / "e.pdf", engine="Keynote")
        self.assertFalse(result["success"])
        self.assertIn("Keynote", result["error"])

    def test_directory_path_gets_default_filename(self):
        result = rx.export(make_doc(), "pdf", self.dir)
        self.assertTrue(result["success"])
        self.assertEqual(Path(result["path"]).name, "report.pdf")
        self.assertTrue(Path(result["path"]).exists())

    def test_wrong_extension_is_replaced_not_appended(self):
        result = rx.export(make_doc(), "docx", self.dir / "报告.txt")
        self.assertTrue(result["success"])
        self.assertEqual(Path(result["path"]).name, "报告.docx")
        self.assertFalse((self.dir / "报告.txt").exists())

    def test_missing_parent_directories_are_created(self):
        target = self.dir / "a" / "b" / "c" / "r.pdf"
        self.assertTrue(rx.export(make_doc(), "pdf", target)["success"])
        self.assertTrue(target.exists())

    def test_payload_dict_exports_to_word(self):
        result = rx.export(sample_payload(), "word", self.dir / "p.docx")
        self.assertTrue(result["success"], result["error"])
        text = zipfile.ZipFile(str(self.dir / "p.docx")).read("word/document.xml").decode("utf-8")
        self.assertIn(MARKERS["summary"], text)


class TestResolvePath(unittest.TestCase):
    def test_none_path_falls_back_to_default_name(self):
        self.assertEqual(rx._resolve_path(None, "pdf").name, "report.pdf")
        self.assertEqual(rx._resolve_path("   ", "markdown").name, "report.md")

    def test_expanduser_is_applied(self):
        self.assertNotIn("~", str(rx._resolve_path("~/x.pdf", "pdf")))


class TestSelfCheck(unittest.TestCase):
    def test_shape_and_numbers(self):
        check = rx.self_check()
        self.assertEqual(check["version"], "v" + rx.EXPORT_VERSION)
        self.assertEqual(check["formats"], list(rx.ALL_FORMATS))
        self.assertEqual(set(check["text_formats"]), {"markdown", "json", "text"})
        self.assertTrue(set(check["available"]).issubset(set(check["formats"])))
        self.assertEqual(set(check["engines"]), {"docx", "pptx", "pdf"})
        self.assertTrue(check["features"])

    def test_available_matches_renderer_importability(self):
        check = rx.self_check()
        for fmt in ("docx", "pptx", "pdf"):
            self.assertEqual(fmt in check["available"], bool(check["engines"][fmt]), fmt)

    def test_self_check_never_prints_to_stdout(self):
        """MCP stdio 下 stdout 是帧通道，自检一行都不能往外打。"""
        import io
        from contextlib import redirect_stdout

        buf = io.StringIO()
        with redirect_stdout(buf):
            rx.self_check()
            rx.render_text(make_doc(), "markdown")
        self.assertEqual(buf.getvalue(), "")


class TestRegistryHygiene(unittest.TestCase):
    def test_public_names_are_importable(self):
        for name in rx.__all__:
            self.assertTrue(hasattr(rx, name), name)

    def test_package_reexports_point_at_registry(self):
        import stock_researcher as sr

        self.assertIs(sr.export_report, rx.export)
        self.assertIs(sr.export_report_bytes, rx.export_bytes)
        self.assertIs(sr.report_export_status, rx.self_check)
        self.assertIs(sr.ExportError, rx.ExportError)
        self.assertEqual(sr.EXPORT_VERSION, rx.EXPORT_VERSION)


if __name__ == "__main__":
    unittest.main()
