﻿# -*- coding: utf-8 -*-
"""v12.0 多资产分析、新闻与概率预测测试。"""
import math
import os
import random
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stock_researcher.research_analysis import (
    EmpiricalForecastEngine, ResearchAnalyzer, _term_structure,
    build_scenarios, compute_technical_metrics,
)
from stock_researcher.research_contracts import (
    EvidenceLedger, FundSnapshot, FuturesContract, FuturesCurve, PriceSeries,
)


def make_series(n=180, drift=0.001, vol=0.012, seed=3, asset_type="stock"):
    random.seed(seed)
    prices = [100.0]
    for _ in range(n - 1):
        prices.append(prices[-1] * (1 + random.gauss(drift, vol)))
    return PriceSeries(
        symbol="TEST", asset_type=asset_type, closes=prices,
        opens=prices, highs=[x * 1.01 for x in prices],
        lows=[x * 0.99 for x in prices],
        volumes=[100000 + i * 13 for i in range(n)],
        source="unit_test", quality="actual",
    )


class TestTechnicalAnalysis(unittest.TestCase):
    def test_metrics_and_factors(self):
        ledger = EvidenceLedger()
        bundle = ResearchAnalyzer(ledger).technical(make_series())
        self.assertTrue(bundle.factors)
        self.assertGreater(bundle.metrics["sample_size"], 100)
        self.assertIn("max_drawdown_pct", bundle.metrics)
        self.assertIn("sharpe", bundle.metrics)
        self.assertTrue(all(f.evidence_ids for f in bundle.factors))
        self.assertGreaterEqual(len(ledger), len(bundle.factors))
        self.assertIn(bundle.quality, ("actual", "derived"))

    def test_short_history_refuses_signal(self):
        ledger = EvidenceLedger()
        s = PriceSeries("SHORT", closes=[100, 101, 102, 101, 100], source="unit")
        bundle = ResearchAnalyzer(ledger).technical(s)
        self.assertFalse(bundle.factors)
        self.assertEqual(bundle.quality, "insufficient")

    def test_flat_series_no_division_error(self):
        s = PriceSeries("FLAT", closes=[100.0] * 80, source="unit")
        metrics = compute_technical_metrics(s)
        self.assertEqual(metrics["max_drawdown_pct"], 0.0)
        self.assertTrue(metrics["available"])


class TestNewsAnalysis(unittest.TestCase):
    def test_dedup_event_and_conflict(self):
        ledger = EvidenceLedger()
        analyzer = ResearchAnalyzer(ledger)
        news = [
            {"title": "公司业绩预增，净利润大幅增长", "content": "订单增长，回购股份",
             "source": "证券时报", "public_date": "2026-09-20"},
            {"title": "公司业绩预增，净利润大幅增长", "content": "重复转载",
             "source": "东方财富", "public_date": "2026-09-20"},
            {"title": "公司被立案调查，涉嫌信息披露违规", "content": "监管处罚",
             "source": "证监会", "public_date": "2026-09-21"},
            {"title": "行业平稳运行", "content": "无重大变化",
             "source": "未知", "public_date": "2026-09-19"},
        ]
        bundle = analyzer.news(news, "600519")
        summary = bundle.specialized["summary"]
        self.assertEqual(summary["total_raw"], 4)
        self.assertEqual(summary["duplicates_removed"], 1)
        self.assertEqual(summary["deduped"], 3)
        self.assertTrue(bundle.factors)
        self.assertTrue(any("冲突" in x for x in bundle.conflicts))

    def test_empty_news(self):
        bundle = ResearchAnalyzer(EvidenceLedger()).news([], "X")
        self.assertFalse(bundle.factors)
        self.assertEqual(bundle.quality, "unavailable")


class TestFundAnalysis(unittest.TestCase):
    def test_fund_performance_and_premium(self):
        s = make_series(n=160, drift=0.0006, vol=0.008, seed=5, asset_type="fund")
        snap = FundSnapshot("510300", market_price=4.10, iopv=4.0,
                            official_nav=4.0, fund_type="etf",
                            source="unit", quality="actual")
        ledger = EvidenceLedger()
        bundle = ResearchAnalyzer(ledger).fund(snap, s)
        names = {f.name for f in bundle.factors}
        self.assertIn("基金绩效", names)
        self.assertIn("折溢价", names)
        self.assertIn("premium_pct", bundle.metrics)
        self.assertTrue(bundle.specialized["fund_snapshot"])

    def test_otc_warning(self):
        s = make_series(n=80, asset_type="fund")
        snap = FundSnapshot("110022", estimated_nav=1.5,
                            fund_type="otc", source="unit", quality="estimated")
        bundle = ResearchAnalyzer(EvidenceLedger()).fund(snap, s)
        self.assertTrue(any("无实时净值" in w for w in bundle.warnings))

class TestFuturesAnalysis(unittest.TestCase):
    def _curve(self, prices):
        contracts = [
            FuturesContract(contract=f"RB260{i+1}", product="RB", exchange="shfe",
                            price=p, open_interest=100000 - i * 1000,
                            days_to_expiry=10 + i * 30, source="unit",
                            quality="actual")
            for i, p in enumerate(prices)
        ]
        return FuturesCurve(product="RB", contracts=contracts, spot_price=95,
                            source="unit", quality="actual")

    def test_contango_term_structure(self):
        curve = self._curve([100, 105, 110])
        term = _term_structure(curve.contracts)
        self.assertEqual(term["structure"], "contango")
        self.assertGreater(term["slope_pct"], 0)
        self.assertLess(term["annualized_roll_pct"], 0)

    def test_backwardation_term_structure(self):
        curve = self._curve([110, 105, 100])
        term = _term_structure(curve.contracts)
        self.assertEqual(term["structure"], "backwardation")
        self.assertGreater(term["annualized_roll_pct"], 0)

    def test_futures_bundle_has_risk_warning(self):
        curve = self._curve([100, 105, 110])
        s = make_series(n=120, drift=0.0002, vol=0.01, seed=9, asset_type="futures")
        bundle = ResearchAnalyzer(EvidenceLedger()).futures(curve, s, spot_price=95)
        names = {f.name for f in bundle.factors}
        self.assertIn("期限结构/展期收益", names)
        self.assertIn("基差结构", names)
        self.assertTrue(any("杠杆" in r for r in bundle.risks))
        self.assertIn(bundle.metrics["structure"], ("contango", "backwardation", "flat"))


class TestProbabilityForecast(unittest.TestCase):
    def test_multi_horizon_distribution(self):
        prices = make_series(n=240, drift=0.0008, vol=0.012, seed=11).closes
        engine = EmpiricalForecastEngine()
        forecasts = engine.forecast_multi(prices)
        self.assertEqual(len(forecasts), 5)
        for f in forecasts:
            self.assertGreater(f.sample_size, 0)
            self.assertGreaterEqual(f.confidence, 0)
            self.assertLessEqual(f.confidence, 1)
            self.assertAlmostEqual(f.probability_up + f.probability_down + f.probability_flat,
                                   1.0, places=2)
            self.assertLessEqual(f.quantiles["p05"], f.quantiles["p50"])
            self.assertLessEqual(f.quantiles["p50"], f.quantiles["p95"])
            self.assertIn(f.direction, ("bullish", "bearish", "neutral"))
            self.assertIn(f.quality, ("insufficient", "estimated", "derived", "validated"))

    def test_short_history_abstains(self):
        engine = EmpiricalForecastEngine()
        f = engine.forecast_horizon([100 + i for i in range(30)], "1M", 21)
        self.assertTrue(f.abstain)
        self.assertEqual(f.quality, "insufficient")
        self.assertLessEqual(f.confidence, 0.3)

    def test_constant_prices_are_valid_distribution(self):
        engine = EmpiricalForecastEngine()
        f = engine.forecast_horizon([100.0] * 120, "5d", 5)
        self.assertAlmostEqual(f.probability_up + f.probability_down + f.probability_flat,
                               1.0, places=2)
        self.assertGreaterEqual(f.quantiles["p05"], -10)
        self.assertLessEqual(f.quantiles["p95"], 10)

    def test_oos_metrics_present_for_long_series(self):
        prices = make_series(n=260, drift=0.0005, vol=0.011, seed=13).closes
        f = EmpiricalForecastEngine().forecast_horizon(prices, "1d", 1)
        self.assertIsNotNone(f.brier_score)
        self.assertIsNotNone(f.baseline_brier)
        self.assertIsNotNone(f.skill_score)

    def test_scenarios_from_distribution(self):
        prices = make_series(n=220, seed=17).closes
        forecasts = EmpiricalForecastEngine().forecast_multi(prices)
        scenarios = build_scenarios(forecasts, current_price=120, horizon="1M")
        self.assertEqual(len(scenarios), 3)
        self.assertAlmostEqual(sum(s.probability for s in scenarios), 1.0)
        self.assertEqual(scenarios[0].name, "熊市情景")
        self.assertTrue(all(s.price_range[0] > 0 for s in scenarios))
