﻿# -*- coding: utf-8 -*-
"""v12.0 统一研究编排、证据链与 CLI 能力测试。"""
import json
import os
import random
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stock_researcher.research_contracts import (
    FundSnapshot, FuturesContract, FuturesCurve, MarketQuote, PriceSeries,
)
from stock_researcher.research_data import CollectedData
from stock_researcher.research_hub import ResearchHub


def make_prices(n=180, drift=0.0008, vol=0.011, seed=21):
    random.seed(seed)
    p = [100.0]
    for _ in range(n - 1):
        p.append(p[-1] * (1 + random.gauss(drift, vol)))
    return p


def make_series(prices, asset_type="stock"):
    return PriceSeries(symbol="TEST", asset_type=asset_type, closes=prices,
                       opens=prices, highs=[x * 1.01 for x in prices],
                       lows=[x * 0.99 for x in prices],
                       volumes=[1000 + i for i in range(len(prices))],
                       source="unit_test", quality="actual")


class TestStockReport(unittest.TestCase):
    def setUp(self):
        prices = make_prices()
        self.data = CollectedData(
            symbol="600519", asset_type="stock", market="cn",
            quote=MarketQuote("600519", name="测试公司", price=prices[-1],
                              prev_close=prices[-2], source="unit_test",
                              quality="actual", freshness="realtime"),
            history=make_series(prices),
            news=[
                {"title": "公司业绩预增，净利润增长", "content": "订单增长，回购股份",
                 "source": "证券时报", "public_date": "2026-09-20"},
                {"title": "行业政策出台，支持国产替代", "content": "政策支持",
                 "source": "新华社", "public_date": "2026-09-21"},
            ],
            money_flow={"main_net_flow": 1200, "flow_ratio": 0.2,
                        "trend": "inflow", "quality": "actual",
                        "source": "unit_flow"},
            fundamentals={"roe": 18, "revenue_yoy": 15, "profit_yoy": 20,
                          "gross_margin": 35, "debt_ratio": 40,
                          "pe_percentile": 35},
            sources=["unit_test", "unit_flow"],
        )
        self.report = ResearchHub().analyze("600519", data=self.data,
                                            question="是否值得关注？")

    def test_report_structure(self):
        r = self.report
        self.assertEqual(r.schema_version, "12.0")
        self.assertEqual(r.symbol, "600519")
        self.assertIn(r.direction, ("bullish", "bearish", "neutral"))
        self.assertTrue(r.executive_summary)
        self.assertEqual(len(r.forecasts), 5)
        self.assertEqual(len(r.scenarios), 3)
        self.assertTrue(r.evidence)
        self.assertTrue(r.asset_analysis.factors)

    def test_evidence_ids_resolve(self):
        ids = {e.evidence_id for e in self.report.evidence}
        for factor in self.report.asset_analysis.factors:
            for eid in factor.evidence_ids:
                self.assertIn(eid, ids)
        for eid in self.report.asset_analysis.evidence_ids:
            self.assertIn(eid, ids)

    def test_report_json_and_markdown(self):
        payload = self.report.to_dict()
        text = json.dumps(payload, ensure_ascii=False)
        self.assertIn("asset_analysis", text)
        md = ResearchHub.to_markdown(self.report)
        for section in ("结论摘要", "多周期概率预测", "因子与证据", "情景分析",
                        "证据链", "免责"):
            self.assertIn(section, md)

    def test_news_and_data_quality_are_visible(self):
        self.assertGreater(self.report.news_summary.get("deduped", 0), 0)
        self.assertIn("新闻/公告", self.report.data_quality.field_quality)
        self.assertIn(self.report.data_quality.status,
                      ("actual", "derived", "estimated", "insufficient"))


class TestFundAndFuturesReports(unittest.TestCase):
    def test_fund_otc_report_flags_estimate(self):
        prices = make_prices(n=160, drift=0.0005, vol=0.008, seed=22)
        data = CollectedData(
            symbol="110022", asset_type="fund", market="cn",
            fund_snapshot=FundSnapshot("110022", name="测试基金",
                                       official_nav=prices[-2],
                                       estimated_nav=prices[-1],
                                       estimate_pct=0.5, fund_type="otc",
                                       source="unit_fund", quality="estimated"),
            history=make_series(prices, asset_type="fund"),
        )
        report = ResearchHub().analyze("110022", data=data)
        self.assertEqual(report.asset_type, "fund")
        self.assertTrue(any("无实时净值" in w for w in report.warnings))
        self.assertIn("基金净值/估值", report.data_quality.field_quality)

    def test_futures_curve_report(self):
        prices = make_prices(n=140, drift=0.0002, vol=0.009, seed=23)
        contracts = [
            FuturesContract("RB2610", product="RB", exchange="shfe",
                            price=100, open_interest=100000,
                            days_to_expiry=20, source="unit", quality="actual"),
            FuturesContract("RB2611", product="RB", exchange="shfe",
                            price=105, open_interest=90000,
                            days_to_expiry=50, source="unit", quality="actual"),
        ]
        data = CollectedData(
            symbol="RB2610", asset_type="futures", market="cn",
            quote=MarketQuote("RB2610", price=100, source="unit",
                              quality="actual"),
            history=make_series(prices, asset_type="futures"),
            futures_curve=FuturesCurve("RB", contracts=contracts,
                                       spot_price=95, source="unit",
                                       quality="actual"),
        )
        report = ResearchHub().analyze("RB2610", data=data)
        self.assertEqual(report.asset_type, "futures")
        self.assertTrue(any("杠杆" in r for r in report.risks))
        self.assertIn("期货期限结构", report.data_quality.field_quality)


class TestDatasetAndRefresh(unittest.TestCase):
    def test_file_analysis_short_data_abstains(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "prices.csv"
            p.write_text("date,open,high,low,close,volume\n"
                         "2026-01-01,100,101,99,100,1000\n"
                         "2026-01-02,100,102,100,101,1100\n"
                         "2026-01-03,101,103,101,102,1200\n",
                         encoding="utf-8")
            report = ResearchHub().analyze_dataset(p, symbol="600519")
            self.assertEqual(report.data_quality.status, "insufficient")
            self.assertLessEqual(report.confidence, 0.20)
            self.assertTrue(all(f.abstain for f in report.forecasts))

    def test_refresh_quotes_with_stub_provider(self):
        class StubProvider:
            def get_quote(self, symbol, asset_type, market):
                return MarketQuote(symbol=symbol, asset_type=asset_type,
                                   market=market, price=100,
                                   source="stub", freshness="realtime",
                                   quality="actual")
        rows = ResearchHub(provider=StubProvider()).refresh_quotes(
            ["600519", "AU2502"], iterations=2, interval=0)
        self.assertEqual(len(rows), 4)
        self.assertTrue(all(r["success"] for r in rows))
        self.assertTrue(all(r["source"] == "stub" for r in rows))

    def test_hub_calls_provider_collect(self):
        prices = make_prices(n=90)
        payload = CollectedData(
            symbol="600519", asset_type="stock", market="cn",
            quote=MarketQuote("600519", price=prices[-1], source="stub"),
            history=make_series(prices),
        )
        class StubCollectProvider:
            def __init__(self):
                self.called = False
            def collect(self, *args, **kwargs):
                self.called = True
                return payload
        provider = StubCollectProvider()
        report = ResearchHub(provider=provider).analyze("600519")
        self.assertTrue(provider.called)
        self.assertEqual(report.symbol, "600519")

    def test_doctor_ok(self):
        result = ResearchHub().doctor(offline=True)
        self.assertEqual(result["status"], "ok")
        self.assertTrue(result["checks"]["forecast_engine"]["ok"])
        self.assertTrue(result["checks"]["factor_engine"]["ok"])

    def test_top_level_exports(self):
        import stock_researcher
        self.assertTrue(hasattr(stock_researcher, "ResearchHub"))
        self.assertTrue(hasattr(stock_researcher, "EmpiricalForecastEngine"))
        self.assertTrue(hasattr(stock_researcher, "DatasetLoader"))
