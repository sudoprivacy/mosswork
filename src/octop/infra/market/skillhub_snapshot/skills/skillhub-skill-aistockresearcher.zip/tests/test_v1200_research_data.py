﻿# -*- coding: utf-8 -*-
"""v12.0 Research Intelligence Hub — 数据契约与摄入测试。"""
import json
import math
import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stock_researcher.research_contracts import (
    DataQualityReport, EvidenceLedger, ForecastDistribution, FundSnapshot,
    MarketQuote, PriceSeries, ResearchReport, report_to_markdown,
)
from stock_researcher.research_data import (
    AnnouncementClient, DataAccessError, DatasetLoader, FundDataClient,
    FuturesDataClient, LiveDataProvider,
    _normalize_money_flow, _validate_public_url, infer_market,
    normalize_quote_data,
)


class TestContracts(unittest.TestCase):
    def test_forecast_probability_zero_is_preserved(self):
        f = ForecastDistribution("1d", 1, probability_up=1.0,
                                 probability_down=0.0, probability_flat=0.0)
        self.assertEqual(f.probability_up, 1.0)
        self.assertEqual(f.probability_down, 0.0)
        self.assertEqual(f.probability_flat, 0.0)

    def test_evidence_ledger_deduplicates(self):
        ledger = EvidenceLedger()
        a = ledger.add("quote", "价格", 100, source="test")
        b = ledger.add("quote", "价格", 100, source="test")
        c = ledger.add("quote", "价格", 101, source="test")
        self.assertEqual(a, b)
        self.assertNotEqual(a, c)
        self.assertEqual(len(ledger), 2)
        self.assertEqual(ledger.get(a).value, "100")

    def test_quote_derives_change_pct(self):
        q = MarketQuote("600519", price=110, prev_close=100, source="test")
        self.assertAlmostEqual(q.change_pct, 10.0)

    def test_price_series_alignment(self):
        s = PriceSeries("X", closes=[1, 2, 3], opens=[1], volumes=[1, 2, 3, 4])
        self.assertEqual(len(s.opens), 3)
        self.assertEqual(len(s.volumes), 3)
        self.assertIn("长度不一致", " ".join(s.warnings))

    def test_fund_snapshot_premium(self):
        f = FundSnapshot("510300", market_price=4.1, iopv=4.0,
                         fund_type="etf", quality="actual")
        self.assertAlmostEqual(f.premium_pct, 2.5)

    def test_markdown_has_required_sections(self):
        from stock_researcher.research_contracts import AssetAnalysis
        aa = AssetAnalysis("600519", "stock", name="测试",
                           price=100, score=12, direction="neutral",
                           confidence=0.4)
        report = ResearchReport(
            schema_version="12.0", run_id="r1", generated_at="2026-01-01T00:00:00+08:00",
            symbol="600519", asset_type="stock", name="测试",
            executive_summary="测试摘要", asset_analysis=aa,
            data_quality=DataQualityReport(status="derived", score=0.6,
                                           completeness=0.6, freshness="closing"),
        )
        md = report_to_markdown(report)
        for section in ("结论摘要", "多周期概率预测", "因子与证据", "情景分析",
                        "证据链", "方法与限制", "不构成"):
            self.assertIn(section, md)

class TestNormalization(unittest.TestCase):
    def test_eastmoney_nested_quote(self):
        raw = {"data": {"f43": 1880.0, "f58": "贵州茅台", "f60": 1870.0,
                        "f170": 0.53, "f47": 12345, "f48": 67890}}
        q = normalize_quote_data(raw, "600519", "stock", "cn", "eastmoney_api")
        self.assertTrue(q.valid)
        self.assertEqual(q.name, "贵州茅台")
        self.assertAlmostEqual(q.price, 1880.0)
        self.assertAlmostEqual(q.change_pct, 0.53)

    def test_scaled_eastmoney_price_marked_derived(self):
        raw = {"f43": 188000, "f58": "贵州茅台", "f60": 187000}
        q = normalize_quote_data(raw, "600519", "stock", "cn", "eastmoney_api")
        self.assertAlmostEqual(q.price, 1880.0)
        self.assertEqual(q.quality, "derived")

    def test_invalid_ohlc_suspect(self):
        q = normalize_quote_data({"price": 100, "high": 90, "low": 80},
                                 "X", "stock", "cn", "test")
        self.assertEqual(q.quality, "suspect")
        self.assertTrue(q.warnings)

    def test_money_flow_klines(self):
        raw = {"data": {"klines": [
            "2026-01-01,100,1,2,3,4",
            "2026-01-02,-50,1,2,3,4",
            "2026-01-03,80,1,2,3,4",
        ]}}
        flow = _normalize_money_flow(raw, "600519")
        self.assertEqual(flow["main_net"], 80.0)
        self.assertEqual(flow["trend"], "inflow")
        self.assertEqual(flow["quality"], "actual")

    def test_money_flow_empty(self):
        self.assertEqual(_normalize_money_flow(None, "X"), {})
        self.assertEqual(_normalize_money_flow({"foo": 1}, "X"), {})

    def test_multi_row_table_without_match_is_not_row_zero(self):
        """多行大表里找不到目标代码时不能返回第一行——那是别的证券的价格。"""
        raw = {"data": [
            {"code": "000001", "name": "平安银行", "price": 11.0},
            {"code": "300750", "name": "宁德时代", "price": 200.0},
        ]}
        q = normalize_quote_data(raw, "600519", "stock", "cn", "akshare")
        self.assertIsNone(q.price)
        self.assertEqual(q.quality, "unavailable")
        self.assertTrue(any("未匹配到" in w for w in q.warnings))

    def test_multi_row_table_with_match_picks_right_row(self):
        raw = {"data": [
            {"code": "000001", "name": "平安银行", "price": 11.0},
            {"code": "SH600519", "name": "贵州茅台", "price": 1880.0},
        ]}
        q = normalize_quote_data(raw, "600519", "stock", "cn", "akshare")
        self.assertAlmostEqual(q.price, 1880.0)
        self.assertEqual(q.name, "贵州茅台")

    def test_single_row_table_is_trusted(self):
        """单行结果本身就是按代码查出来的，没有可匹配的必要。"""
        raw = {"data": [{"price": 1880.0, "name": "贵州茅台"}]}
        q = normalize_quote_data(raw, "600519", "stock", "cn", "sina")
        self.assertAlmostEqual(q.price, 1880.0)
        self.assertEqual(q.quality, "actual")


class TestDatasetLoader(unittest.TestCase):
    def test_csv_chinese_headers(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "prices.csv"
            p.write_text("日期,开盘,最高,最低,收盘,成交量\n"
                         "2026-01-01,100,101,99,100.5,1000\n"
                         "2026-01-02,100.5,102,100,101.2,1200\n",
                         encoding="utf-8")
            ds = DatasetLoader.load(str(p))
            self.assertEqual(ds.row_count, 2)
            self.assertEqual(ds.mapping["close"], "收盘")
            series = DatasetLoader.to_price_series(ds, "600519")
            self.assertEqual(series.closes, [100.5, 101.2])
            self.assertEqual(series.quality, "actual")

    def test_json_records_and_sort(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "prices.json"
            p.write_text(json.dumps([
                {"date": "2026-01-03", "close": 103},
                {"date": "2026-01-01", "close": 101},
                {"date": "2026-01-02", "close": 102},
            ]), encoding="utf-8")
            ds = DatasetLoader.load(str(p))
            s = DatasetLoader.to_price_series(ds, "X")
            self.assertEqual(s.closes, [101, 102, 103])

    def test_bad_rows_rejected(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "prices.csv"
            p.write_text("date,close\n2026-01-01,100\n2026-01-02,-1\n"
                         "2026-01-03,abc\n2026-01-04,102\n", encoding="utf-8")
            ds = DatasetLoader.load(str(p))
            s = DatasetLoader.to_price_series(ds, "X")
            self.assertEqual(s.closes, [100, 102])
            self.assertEqual(len(ds.rejected_rows), 2)

    def test_missing_close_raises(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "bad.csv"
            p.write_text("date,value\n2026-01-01,100\n", encoding="utf-8")
            ds = DatasetLoader.load(str(p))
            with self.assertRaises(DataAccessError):
                DatasetLoader.to_price_series(ds, "X")

    def test_private_url_blocked(self):
        for url in ("file:///etc/passwd", "http://127.0.0.1/x",
                    "http://localhost/x", "ftp://example.com/x"):
            with self.assertRaises(DataAccessError):
                _validate_public_url(url)


class TestIdentifierHelpers(unittest.TestCase):
    def test_infer_market(self):
        self.assertEqual(infer_market("600519")[:2], ("cn", "600519"))
        self.assertEqual(infer_market("hk:00700")[:2], ("hk", "00700"))
        self.assertEqual(infer_market("us:AAPL")[:2], ("us", "AAPL"))
        self.assertEqual(infer_market("AU2502")[2], "futures")
        self.assertEqual(infer_market("110022")[2], "fund")

    def test_fund_type(self):
        self.assertEqual(FundDataClient.fund_type("510300"), "etf")
        self.assertEqual(FundDataClient.fund_type("159915"), "etf")
        self.assertEqual(FundDataClient.fund_type("110022"), "otc")

    def test_futures_product(self):
        self.assertEqual(FuturesDataClient.product("AU2502"), "AU")
        self.assertEqual(FuturesDataClient.product("IF2506"), "IF")


class TestAnnouncementClient(unittest.TestCase):
    def test_parse_announcement_list(self):
        payload = {"data": {"list": [
            {"title": "2026年半年度业绩预告", "art_code": "AN20260101",
             "notice_date": "2026-07-15 00:00:00"},
            {"title": "", "art_code": "bad"},
        ]}}
        rows = AnnouncementClient.parse(payload, "600519")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["source"], "东方财富公告")
        self.assertEqual(rows[0]["content"], rows[0]["title"])
        self.assertIn("AN20260101", rows[0]["url"])
        self.assertTrue(rows[0]["public_date"].startswith("2026-07-15"))

    def test_parse_empty(self):
        self.assertEqual(AnnouncementClient.parse(None), [])
        self.assertEqual(AnnouncementClient.parse({}, "600519"), [])

class TestLiveProviderComposition(unittest.TestCase):
    def test_announcements_prepend_to_news_without_network(self):
        class StubProvider(LiveDataProvider):
            def __init__(self):
                super().__init__(use_network=True, cache_ttl=0)
            def get_news(self, symbol, asset_type="stock", clean="", limit=30):
                return [{"title": "行业新闻", "content": "新闻正文", "source": "证券时报"}]
            def get_announcements(self, symbol, clean="", limit=20):
                return [{"title": "公司公告", "content": "公司公告", "source": "东方财富公告"}]
        provider = StubProvider()
        data = provider.collect(
            "600519", asset_type="stock",
            overrides={
                "quote": MarketQuote("600519", price=100, source="manual"),
                "history": PriceSeries("600519", closes=[100, 101, 102],
                                       source="manual"),
                "money_flow": {}, "fundamentals": {},
            },
        )
        self.assertEqual(len(data.news), 2)
        self.assertEqual(data.news[0]["source"], "东方财富公告")
        self.assertIn("东方财富公告", data.sources)

