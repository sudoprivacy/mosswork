# -*- coding: utf-8 -*-
"""v13.0 MCP stdio 子进程端到端测试 (test_v1300_mcp_stdio.py)

为什么单独开一个子进程测试，而不是在 pytest 里直接 import mcp_server：
tests/conftest.py 把 mcp/akshare/pandas 等重型库都屏蔽掉了，进程内测不到真实链路；
而 v13 上线前踩到的正是只有真实 stdio 服务才会暴露的故障——

    在已经跑起 anyio 工作线程的服务里首次 import 一个 C 扩展（akshare→numpy、
    python-docx→lxml），Windows 会卡在系统加载器锁上再也不返回：工具请求发出
    200s 无响应，而同样的导入在单线程阶段只要 1.3s。

所以这里用裸 JSON-RPC 行协议驱动真实服务进程，卡死会被超时抓住。
mcp SDK 或子进程能力不具备时跳过，不算失败。
"""
import json
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SERVER = ROOT / "mcp_server.py"


def _has_mcp_sdk() -> bool:
    """看磁盘上有没有 mcp 包，不用 import。

    不能用 find_spec/import：conftest 的 HeavyLibBlocker 在 ≤3.11 上会把 mcp
    拦成"存在但加载即 ImportError"，判不出真实可用性；子进程用的又是同一个
    解释器，所以直接查 site-packages 目录最可靠。
    """
    dirs = set()
    try:
        import site
        import sysconfig
        purelib = sysconfig.get_paths().get("purelib")
        if purelib:
            dirs.add(Path(purelib))
        dirs.update(Path(p) for p in site.getsitepackages() if p)
        user = site.getusersitepackages()
        if user:
            dirs.add(Path(user))
    except (AttributeError, OSError, ValueError):
        pass
    return any((d / "mcp" / "__init__.py").is_file() for d in dirs if d.is_dir())


def _spawn_works() -> bool:
    try:
        subprocess.run([sys.executable, "-c", "pass"], timeout=30,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except OSError:
        return False


class _LineReader(threading.Thread):
    """后台收 stdout 行，避免主线程 readline 卡死不返回。"""

    def __init__(self, stream):
        super().__init__(daemon=True)
        self.q: "queue.Queue[str]" = queue.Queue()
        self.stream = stream
        self.alive = True

    def run(self):
        while self.alive:
            line = self.stream.readline()
            if not line:
                self.alive = False
                return
            text = line.decode("utf-8", "replace").strip()
            if text:
                self.q.put(text)

    def get(self, timeout: float):
        try:
            return self.q.get(timeout=timeout)
        except queue.Empty:
            return None


class _StdioClient:
    """最小 MCP stdio 客户端：换行分隔的 JSON-RPC，不带任何 SDK 依赖。"""

    def __init__(self, proc, reader):
        self.proc = proc
        self.reader = reader
        self.next_id = 0
        self.stray_frames: list = []

    def notify(self, method: str, params=None) -> None:
        self._write({"jsonrpc": "2.0", "method": method, "params": params or {}})

    def request(self, method: str, params=None, timeout: float = 90.0):
        self.next_id += 1
        rid = self.next_id
        self._write({"jsonrpc": "2.0", "id": rid, "method": method,
                     "params": params or {}})
        deadline = time.time() + timeout
        while time.time() < deadline:
            line = self.reader.get(timeout=max(0.1, deadline - time.time()))
            if line is None:
                break
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                self.stray_frames.append(line[:120])
                continue
            if msg.get("id") == rid:
                return msg
        return None

    def _write(self, obj) -> None:
        self.proc.stdin.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
        self.proc.stdin.flush()

    def close(self) -> None:
        try:
            self.proc.kill()
        except OSError:
            pass


def _start_server() -> _StdioClient:
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONIOENCODING": "utf-8", "STOCK_RESEARCHER_OFFLINE": "1"}
    proc = subprocess.Popen([sys.executable, str(SERVER)], cwd=str(ROOT), env=env,
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL)
    reader = _LineReader(proc.stdout)
    reader.start()
    return _StdioClient(proc, reader)


def _tool_text(msg: dict) -> str:
    result = msg.get("result") or {}
    return "".join(c.get("text", "") for c in result.get("content", [])
                   if c.get("type") == "text")


@unittest.skipUnless(_has_mcp_sdk(), "本解释器没有 mcp SDK，无法起真实 stdio 服务")
@unittest.skipUnless(_spawn_works(), "当前环境禁止启动子进程")
class TestMCPStdioLive(unittest.TestCase):
    """真实子进程里的 stdio 帧、预热与导出链路。"""

    @classmethod
    def setUpClass(cls):
        try:
            cls.client = _start_server()
        except OSError as exc:  # WinError 5 之类
            raise unittest.SkipTest("无法启动服务子进程：%s" % exc)
        init = cls.client.request("initialize", {
            "protocolVersion": "2024-11-05", "capabilities": {},
            "clientInfo": {"name": "pytest", "version": "1"}}, timeout=120)
        if init is None:
            raise unittest.SkipTest("服务未在 120s 内完成 initialize")
        cls.client.notify("notifications/initialized")

    @classmethod
    def tearDownClass(cls):
        cls.client.close()

    def test_01_initialize_handshake(self):
        """握手本身能过——后面所有断言的前提。"""
        self.assertTrue(True)

    def test_02_tools_list_has_export_tools(self):
        msg = self.client.request("tools/list", timeout=60)
        self.assertIsNotNone(msg, "tools/list 无响应")
        names = sorted(t["name"] for t in (msg.get("result") or {}).get("tools", []))
        self.assertEqual(len(names), 26, "工具数应为 26，实际 %d：%s" % (len(names), names))
        for want in ("export_report", "list_export_formats", "research_batch",
                     "diff_research_reports", "get_skill_status"):
            self.assertIn(want, names)

    def test_03_status_responds_without_loader_deadlock(self):
        """回归守卫：get_skill_status 会构造路由表并触发渲染器导入。

        修复前这条请求永远不返回；预热挪到 main() 之后应当在 30s 内出结果。
        """
        started = time.time()
        msg = self.client.request("tools/call",
                                  {"name": "get_skill_status", "arguments": {}},
                                  timeout=45)
        self.assertIsNotNone(msg, "get_skill_status 45s 无响应（疑似加载器锁死锁）")
        self.assertLess(time.time() - started, 45)
        status = json.loads(_tool_text(msg))
        self.assertEqual(status["total_tools"], len(status["mcp_tools"]))
        self.assertIn("docx", status["export"]["available"])

    def test_04_export_report_writes_openable_docx(self):
        """导出工具走的是同一批渲染器；文件必须真能被 zip+XML 解析。"""
        tmp = Path(tempfile.mkdtemp(prefix="sr_stdio_"))
        self.addCleanup(shutil.rmtree, tmp, True)
        target = tmp / "brief"
        doc = {"symbol": "600519", "name": "贵州茅台", "direction": "neutral",
               "confidence": 0.5, "score": 12.0, "conclusions": ["估值分位 68%"],
               "risks": ["渠道政策"]}
        msg = self.client.request("tools/call", {"name": "export_report",
                                                 "arguments": {"path": str(target),
                                                               "fmt": "docx",
                                                               "report_json": json.dumps(doc,
                                                                                         ensure_ascii=False)}},
                                  timeout=60)
        self.assertIsNotNone(msg, "export_report 无响应")
        res = json.loads(_tool_text(msg))
        self.assertTrue(res["success"], res["error"])
        written = Path(res["path"])
        self.assertEqual(written.suffix, ".docx")
        with zipfile.ZipFile(written) as zf:
            document = zf.read("word/document.xml").decode("utf-8")
        root = ET.fromstring(document)
        self.assertTrue(root.tag.endswith("document"), root.tag)
        self.assertIn("贵州茅台", document)
        self.assertIn("估值分位 68%", document)

    def test_05_export_report_rejects_empty_path(self):
        """空 path 不许落到当前目录，否则报告会被写进没人知道的地方。"""
        msg = self.client.request("tools/call", {"name": "export_report",
                                                 "arguments": {"path": "", "fmt": "pdf",
                                                               "report_json": '{"symbol":"X"}'}},
                                  timeout=30)
        self.assertIsNotNone(msg)
        res = json.loads(_tool_text(msg))
        self.assertFalse(res["success"])
        self.assertIn("path", res["error"])

    def test_06_stdout_stays_a_clean_frame_channel(self):
        """跑完上面这些调用后，stdout 不该混进过非 JSON 行。

        stdio 服务的 stdout 就是帧通道，一句 print() 会让客户端整条链路解析失败，
        而这类污染只有在真实子进程里才看得见。
        """
        self.assertEqual(self.client.stray_frames, [],
                         "stdout 出现过非 JSON 帧：%s" % self.client.stray_frames[:3])


if __name__ == "__main__":
    unittest.main(verbosity=2)
