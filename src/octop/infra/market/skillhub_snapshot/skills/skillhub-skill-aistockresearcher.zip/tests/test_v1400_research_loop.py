# -*- coding: utf-8 -*-
"""v14.0 研究闭环：批量研究、报告差异、数据诚实性与缓存修复。"""
import contextlib
import importlib.util
import io
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from stock_researcher.research_batch import (
    MAX_BATCH_SYMBOLS, BatchResearcher, BatchResult, BatchRow,
    compare_report_files, diff_reports, load_report, meets_quality,
    parse_symbols, quality_rank, research_many,
)
from stock_researcher.research_contracts import (
    EvidenceLedger, ResearchReport, report_to_markdown,
)
from stock_researcher.research_hub import ResearchHub


def _report(symbol="AAA", score=20.0, direction="bullish", quality="actual",
            prob_up=0.60, median=2.0, abstain=False, factors=None,
            risks=None, evidence=None):
    return {
        "symbol": symbol, "name": "N" + symbol, "asset_type": "stock",
        "score": score, "direction": direction, "confidence": 0.6,
        "data_cutoff": "2026-11-05",
        "data_quality": {"status": quality, "score": 0.9, "freshness": "realtime"},
        "asset_analysis": {"price": 10.0, "factors": factors or []},
        "forecasts": [{"horizon": "1M", "probability_up": prob_up,
                       "median_return_pct": median, "abstain": abstain}],
        "risks": risks or [],
        "evidence": evidence or [],
    }


class _StubReport:
    def __init__(self, payload):
        self._payload = payload

    def to_dict(self):
        return self._payload


class _StubHub:
    def __init__(self, fail=()):
        self.fail = set(fail)
        self.calls = []

    def analyze(self, symbol, **kwargs):
        self.calls.append(symbol)
        if symbol in self.fail:
            raise RuntimeError("boom-%s" % symbol)
        score = 20.0 if symbol.upper().startswith("A") else -5.0
        quality = "actual" if score > 0 else "estimated"
        direction = "bullish" if score > 0 else "bearish"
        return _StubReport(_report(symbol, score=score, quality=quality,
                                   direction=direction))


class TestParseSymbols(unittest.TestCase):
    def test_mixed_separators(self):
        self.assertEqual(parse_symbols("600519, hk:00700\nAAPL;110022"),
                         ["600519", "hk:00700", "AAPL", "110022"])

    def test_list_and_chinese_comma(self):
        self.assertEqual(parse_symbols(["600519，000858", "AAPL"]),
                         ["600519", "000858", "AAPL"])

    def test_case_insensitive_dedupe_keeps_first(self):
        self.assertEqual(parse_symbols("US:AAPL, us:aapl, US:AAPL"),
                         ["US:AAPL"])

    def test_empty_inputs(self):
        self.assertEqual(parse_symbols(None), [])
        self.assertEqual(parse_symbols("  , ; "), [])


class TestQualityGate(unittest.TestCase):
    def test_rank_order(self):
        self.assertGreater(quality_rank("actual"), quality_rank("estimated"))
        self.assertEqual(quality_rank("unavailable"), quality_rank("insufficient"))
        self.assertEqual(quality_rank("whatever"), 0)

    def test_meets_quality(self):
        self.assertTrue(meets_quality("actual", ""))
        self.assertTrue(meets_quality("actual", "derived"))
        self.assertFalse(meets_quality("estimated", "derived"))
        self.assertFalse(meets_quality("", "estimated"))


class TestBatchResearcher(unittest.TestCase):
    def test_rows_keep_input_order(self):
        hub = _StubHub()
        result = BatchResearcher(hub=hub, max_workers=3).run(
            ["AAA", "BBB", "CCC"])
        self.assertIsInstance(result, BatchResult)
        self.assertEqual([r.symbol for r in result.rows], ["AAA", "BBB", "CCC"])

    def test_single_failure_does_not_break_batch(self):
        result = BatchResearcher(hub=_StubHub(fail={"BAD"})).run(
            "AAA,BAD,BBB")
        self.assertEqual(len(result.ok_rows), 2)
        self.assertEqual(len(result.failed_rows), 1)
        self.assertEqual(result.failed_rows[0].symbol, "BAD")
        self.assertIn("boom-BAD", result.failed_rows[0].error)

    def test_summary_and_gate(self):
        result = BatchResearcher(hub=_StubHub()).run(
            "AAA,BBB", min_quality="actual")
        summary = result.summary
        self.assertEqual(summary["total"], 2)
        self.assertEqual(summary["ok"], 2)
        self.assertEqual(summary["failed"], 0)
        self.assertEqual(summary["gate_failed"], ["BBB"])
        self.assertFalse(result.gate_passed)
        self.assertEqual(summary["direction_counts"]["bullish"], 1)
        self.assertEqual(summary["direction_counts"]["bearish"], 1)
        self.assertEqual(summary["top"]["symbol"], "AAA")
        self.assertEqual(summary["bottom"]["symbol"], "BBB")

    def test_gate_passes_when_all_meet(self):
        result = BatchResearcher(hub=_StubHub()).run("AAA", min_quality="actual")
        self.assertTrue(result.gate_passed)

    def test_markdown_contains_table_and_disclaimer(self):
        result = BatchResearcher(hub=_StubHub()).run("AAA,BBB", min_quality="actual")
        md = result.to_markdown()
        for text in ("批量研究简报", "对比表", "汇总", "未达质量门槛：BBB", "免责声明"):
            self.assertIn(text, md)

    def test_abstain_rendered_as_abstain(self):
        class AbstainHub:
            def analyze(self, symbol, **kwargs):
                return _StubReport(_report(symbol, prob_up=0.5, abstain=True))
        md = BatchResearcher(hub=AbstainHub()).run("AAA").to_markdown()
        self.assertIn("弃权", md)
        self.assertNotIn("50%", md)

    def test_validation_errors(self):
        runner = BatchResearcher(hub=_StubHub())
        with self.assertRaises(ValueError):
            runner.run("")
        with self.assertRaises(ValueError):
            runner.run(",".join("S%d" % i for i in range(MAX_BATCH_SYMBOLS + 1)))
        with self.assertRaises(ValueError):
            runner.run("AAA", min_quality="perfect")

    def test_convenience_entry_returns_serializable(self):
        payload = research_many("AAA,BBB", hub=_StubHub())
        self.assertIn("rows", payload)
        json.dumps(payload, ensure_ascii=False)


class TestLoadReport(unittest.TestCase):
    def test_missing_and_invalid(self):
        with tempfile.TemporaryDirectory() as td:
            missing = Path(td) / "none.json"
            with self.assertRaises(ValueError):
                load_report(missing)
            bad = Path(td) / "bad.json"
            bad.write_text("{not json", encoding="utf-8")
            with self.assertRaises(ValueError):
                load_report(bad)
            nosym = Path(td) / "nosym.json"
            nosym.write_text('{"score": 1}', encoding="utf-8")
            with self.assertRaises(ValueError):
                load_report(nosym)

    def test_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "r.json"
            path.write_text(json.dumps(_report("AAA")), encoding="utf-8")
            self.assertEqual(load_report(path)["symbol"], "AAA")


class TestDiffReports(unittest.TestCase):
    def test_material_change_detected(self):
        old = _report("AAA", score=20.0, direction="bullish", prob_up=0.60)
        new = _report("AAA", score=45.0, direction="bearish", quality="derived",
                      prob_up=0.35)
        diff = diff_reports(old, new)
        self.assertTrue(diff.material)
        self.assertIn("实质性变化", diff.verdict)
        keys = {f["key"] for f in diff.fields}
        self.assertTrue({"score", "direction", "quality_status"} <= keys)
        self.assertTrue(any(f["horizon"] == "1M" for f in diff.forecasts))
        md = diff.to_markdown()
        for text in ("研究简报差异", "核心字段", "周期预测", "实质性变化"):
            self.assertIn(text, md)

    def test_small_change_not_material(self):
        old = _report("AAA", score=20.0)
        new = _report("AAA", score=25.0)
        diff = diff_reports(old, new)
        self.assertFalse(diff.material)
        self.assertIn("未发生实质性变化", diff.verdict)

    def test_factor_and_risk_changes(self):
        old = _report("AAA", factors=[{"name": "动量", "score": 10},
                                      {"name": "估值", "score": 20}],
                      risks=["杠杆风险"])
        new = _report("AAA", factors=[{"name": "动量", "score": 15},
                                      {"name": "质量", "score": 30}],
                      risks=["流动性风险"])
        diff = diff_reports(old, new)
        self.assertEqual(diff.factors["added"], ["质量"])
        self.assertEqual(diff.factors["removed"], ["估值"])
        self.assertEqual([x["name"] for x in diff.factors["changed"]], ["动量"])
        self.assertEqual(diff.risks["added"], ["流动性风险"])
        self.assertEqual(diff.risks["removed"], ["杠杆风险"])

    def test_symbol_mismatch_is_noted(self):
        diff = diff_reports(_report("AAA"), _report("BBB"))
        self.assertTrue(any("标的不同" in n for n in diff.notes))

    def test_missing_symbol_raises(self):
        with self.assertRaises(ValueError):
            diff_reports({"score": 1}, _report("AAA"))

    def test_compare_report_files(self):
        with tempfile.TemporaryDirectory() as td:
            old = Path(td) / "old.json"
            new = Path(td) / "new.json"
            old.write_text(json.dumps(_report("AAA", score=20.0)), encoding="utf-8")
            new.write_text(json.dumps(_report("AAA", score=50.0)), encoding="utf-8")
            diff = compare_report_files(old, new)
            self.assertTrue(diff.material)


class TestHonestyFixes(unittest.TestCase):
    def test_evidence_without_timestamp_stays_empty(self):
        ledger = EvidenceLedger()
        ledger.add("price", "最新价", 10.0, source="unit")
        self.assertEqual(ledger._items[0].observed_at, "")

    def test_evidence_timestamp_is_kept(self):
        ledger = EvidenceLedger()
        ledger.add("price", "最新价", 10.0, source="unit",
                   observed_at="2026-11-05 15:00:00")
        self.assertIn("2026-11-05", ledger._items[0].observed_at)

    def test_markdown_renders_dash_for_missing_observed_at(self):
        ledger = EvidenceLedger()
        ledger.add("news", "无时间戳的证据", "内容", source="unit")
        report = ResearchReport(
            schema_version="12.0", run_id="R1", generated_at="2026-11-06",
            symbol="600519", asset_type="stock", name="测试",
            evidence=list(ledger._items),
        )
        md = report_to_markdown(report)
        self.assertIn("| 观测时间 |", md)
        self.assertIn("| E0001 | news | unit | — |", md)

    def test_abstained_forecast_has_no_placeholder_probability(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "prices.csv"
            path.write_text("date,open,high,low,close,volume\n"
                            "2026-01-01,100,101,99,100,1000\n"
                            "2026-01-02,100,102,100,101,1100\n"
                            "2026-01-03,101,103,101,102,1200\n",
                            encoding="utf-8")
            report = ResearchHub().analyze_dataset(path, symbol="600519")
            summary = report.executive_summary
            self.assertIn("已弃权", summary)
            self.assertNotIn("上涨概率 50%", summary)
            self.assertNotIn("上涨概率 45%", summary)
            md = ResearchHub.to_markdown(report)
            self.assertIn("| 1M | 弃权 | — | — | — |", md)


class TestCacheClear(unittest.TestCase):
    def test_cache_clear_removes_disk_files(self):
        from stock_researcher import data_cache

        with tempfile.TemporaryDirectory() as td:
            cache_dir = Path(td)
            with patch.object(data_cache, "_DISK_CACHE_DIR", cache_dir), \
                    patch.object(data_cache, "_MEM_CACHE", {}):
                calls = {"n": 0}

                @data_cache.cached(ttl=60, use_disk=True)
                def sample(x):
                    calls["n"] += 1
                    return {"value": x}

                sample(1)
                sample(1)
                self.assertEqual(calls["n"], 1)
                self.assertTrue(list(cache_dir.glob("*.json")))
                sample.cache_clear()
                self.assertEqual(list(cache_dir.glob("*.json")), [])
                self.assertEqual(data_cache._MEM_CACHE, {})


def _load_cli():
    path = ROOT / "scripts" / "research_hub_cli.py"
    spec = importlib.util.spec_from_file_location("research_hub_cli_v14", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TestCLIResearchLoop(unittest.TestCase):
    def test_parser_has_batch_and_diff(self):
        cli = _load_cli()
        help_text = cli.build_parser().format_help()
        for cmd in ("batch", "diff", "analyze"):
            self.assertIn(cmd, help_text)

    def test_batch_gate_exit_code_and_status(self):
        cli = _load_cli()
        cli.ResearchHub = lambda provider=None: _StubHub()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = cli.main(["batch", "--symbols", "AAA,BBB", "--offline",
                             "--min-quality", "actual", "--format", "json"])
        self.assertEqual(code, 5)
        payload = json.loads(buf.getvalue())
        self.assertEqual(payload["status"], "quality_gate_failed")
        self.assertFalse(payload["quality_gate"]["passed"])

    def test_batch_partial_failure_exit_code(self):
        cli = _load_cli()
        cli.ResearchHub = lambda provider=None: _StubHub(fail={"BAD"})
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = cli.main(["batch", "--symbols", "AAA,BAD", "--offline",
                             "--format", "json"])
        self.assertEqual(code, 4)
        self.assertEqual(json.loads(buf.getvalue())["status"], "partial")

    def test_diff_fail_on_material(self):
        cli = _load_cli()
        with tempfile.TemporaryDirectory() as td:
            old = Path(td) / "old.json"
            new = Path(td) / "new.json"
            old.write_text(json.dumps(_report("AAA", score=20.0)), encoding="utf-8")
            new.write_text(json.dumps(_report("AAA", score=50.0)), encoding="utf-8")
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                code = cli.main(["diff", "--old", str(old), "--new", str(new),
                                 "--fail-on-material"])
            self.assertEqual(code, 4)
            self.assertIn("实质性变化", buf.getvalue())

    def test_diff_allows_identical_reports(self):
        cli = _load_cli()
        with tempfile.TemporaryDirectory() as td:
            old = Path(td) / "old.json"
            new = Path(td) / "new.json"
            payload = json.dumps(_report("AAA"))
            old.write_text(payload, encoding="utf-8")
            new.write_text(payload, encoding="utf-8")
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                code = cli.main(["diff", "--old", str(old), "--new", str(new),
                                 "--fail-on-material", "--format", "json"])
            self.assertEqual(code, 0)
            self.assertFalse(json.loads(buf.getvalue())["material"])


if __name__ == "__main__":
    unittest.main()
