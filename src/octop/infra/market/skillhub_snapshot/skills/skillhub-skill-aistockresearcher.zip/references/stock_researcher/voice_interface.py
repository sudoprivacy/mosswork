# -*- coding: utf-8 -*-
"""v9.4.0 语音交互 — Windows 零依赖 TTS/STT + 语音会话编排。

设计要点（与项目既有模块一致：纯函数 + 可注入依赖，测试不发网络请求）：
  1. TTS：优先 pyttsx3（可选）→ Windows SAPI（经 PowerShell 5.1，
     因 pwsh 7 未预装 System.Speech，必须显式调用 5.1 路径）→ 静默降级。
  2. STT：优先 vosk（可选离线模型）→ Windows SAPI 听写 → 不可用时
     VoiceResearchChat.run() 自动降级为文本输入循环。
  3. 命令引擎在 voice_command.py（纯文本解析，本模块只做转发导入）；
     上架包剔除的正是本模块的 shell 支路，解析器照常交付。

v13.0 安全边界：起 PowerShell 子进程属于"从技能代码里拉起系统 shell"，市场沙箱和
宿主进程都不该在用户没要求的情况下发生。所以 SAPI 支路只在显式授权后走：
  - 环境变量 STOCK_RESEARCHER_ENABLE_VOICE=1（用户确实要用语音），或
  - 调用方把 engine 显式写成 "sapi"（参数即授权）。
两者都没有时 speak() 返回 False、listen_once() 返回 None，pyttsx3/vosk 这类正常
可选依赖不受影响，文本链路完全照旧。
"""
from __future__ import annotations

import os
import subprocess
import tempfile
from typing import Any, Callable, Dict, List, Optional

from stock_researcher.voice_command import parse_voice_command, summarize_for_speech

__all__ = [
    "speak", "listen_once", "stt_available", "summarize_for_speech",
    "parse_voice_command", "VoiceResearchChat", "shell_voice_allowed",
    "VOICE_ENV",
]

# PowerShell 5.1（Windows 自带，含 System.Speech 程序集；pwsh 7 无）
_PS51 = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

#: 语音子进程显式开关（详见模块 docstring 的 v13 安全边界）
VOICE_ENV = "STOCK_RESEARCHER_ENABLE_VOICE"
_TRUTHY = ("1", "true", "yes", "on", "y")


def shell_voice_allowed(engine: str = "auto") -> bool:
    """是否允许为语音起 PowerShell 子进程。

    engine="sapi" 视为调用方显式授权；engine="off" 永远禁止；其余（auto）只看
    环境变量。非 Windows 或缺 powershell.exe 时直接 False，不做无谓的 fork。
    """
    if engine == "off":
        return False
    if os.name != "nt" or not os.path.exists(_PS51):
        return False
    if engine == "sapi":
        return True
    return os.environ.get(VOICE_ENV, "").strip().lower() in _TRUTHY


# ─── TTS / STT ─────────────────────────────────────────────────────────────


def speak(text: str, engine: str = "auto", rate: int = 0) -> bool:
    """播报文本。engine: auto/pyttsx3/sapi/off。返回是否真实发声。"""
    if not text or engine == "off":
        return False
    if engine in ("auto", "pyttsx3"):
        try:
            import pyttsx3  # type: ignore
            eng = pyttsx3.init()
            if rate:
                try:
                    eng.setProperty("rate", max(80, min(300, 160 + rate * 20)))
                except Exception:
                    pass
            eng.say(text)
            eng.runAndWait()
            return True
        except Exception:
            if engine == "pyttsx3":
                return False
    # Windows SAPI 兜底（文本经临时文件传递，规避命令行转义问题）
    if shell_voice_allowed(engine):
        tmp = None
        try:
            fd, tmp = tempfile.mkstemp(suffix=".txt", prefix="sr_voice_")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(text)
            script = (
                "Add-Type -AssemblyName System.Speech; "
                f"$t = Get-Content -Raw -Encoding UTF8 '{tmp}'; "
                f"$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                f"$s.Rate = {max(-10, min(10, rate))}; $s.Speak($t)"
            )
            subprocess.run([_PS51, "-NoProfile", "-Command", script],
                           timeout=max(30, len(text) // 5), check=False,
                           capture_output=True)
            return True
        except Exception:
            return False
        finally:
            try:
                os.remove(tmp)
            except Exception:
                pass
    return False


def stt_available(engine: str = "auto") -> bool:
    """语音识别是否可用（vosk 或已授权的 Windows SAPI 听写）。"""
    try:
        import vosk  # noqa: F401
        return True
    except Exception:
        pass
    return shell_voice_allowed(engine)


def listen_once(timeout: int = 8, engine: str = "auto") -> Optional[str]:
    """录一次音并转文字；失败/静音返回 None。"""
    if engine in ("auto", "vosk"):
        try:
            import vosk  # type: ignore
            import queue
            import sounddevice  # type: ignore
            model_dir = os.environ.get("VOSK_MODEL_PATH", "")
            if model_dir and os.path.isdir(model_dir):
                q: "queue.Queue[bytes]" = queue.Queue()

                def _cb(indata, frames, time_info, status):
                    q.put(bytes(indata))

                with sounddevice.RawInputStream(samplerate=16000, blocksize=8000,
                                                dtype="int16", channels=1,
                                                callback=_cb):
                    rec = vosk.KaldiRecognizer(vosk.Model(model_dir), 16000)
                    import time as _t
                    end = _t.time() + timeout
                    while _t.time() < end:
                        data = q.get()
                        if rec.AcceptWaveform(data):
                            import json as _json
                            txt = _json.loads(rec.Result()).get("text", "").strip()
                            if txt:
                                return txt
        except Exception:
            if engine == "vosk":
                return None
    # SAPI 听写兜底（同样要显式授权才起子进程）
    if shell_voice_allowed(engine):
        try:
            script = (
                "Add-Type -AssemblyName System.Speech; "
                "$r = New-Object System.Speech.Recognition.SpeechRecognitionEngine; "
                "$r.SetInputToDefaultAudioDevice; "
                "$r.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar)); "
                f"$res = $r.Recognize([TimeSpan]::FromSeconds({int(timeout)})); "
                "if ($res) { $res.Text }"
            )
            out = subprocess.run([_PS51, "-NoProfile", "-Command", script],
                                 timeout=timeout + 15, check=False,
                                 capture_output=True, text=True)
            txt = (out.stdout or "").strip()
            return txt or None
        except Exception:
            return None
    return None


# ─── 语音会话 ───────────────────────────────────────────────────────────────


class VoiceResearchChat:
    """语音/文本交互会话。

    参数均可注入以便测试：
      listen    : (timeout) -> Optional[str]，默认 listen_once
      speak_fn  : (text) -> bool，默认 speak
      executor  : (cmd: Dict) -> str，命令执行器；默认走内置分发
                  （调用 stock_predict.predict 与 v9.0 命令底层模块）
      tts       : 是否播报（False 时仅打印）
    """

    def __init__(self, listen: Optional[Callable] = None,
                 speak_fn: Optional[Callable] = None,
                 executor: Optional[Callable] = None,
                 tts: bool = True, listen_timeout: int = 8):
        self.listen = listen or listen_once
        self.speak_fn = speak_fn or speak
        self.executor = executor or self._default_execute
        self.tts = tts
        self.listen_timeout = listen_timeout
        self.history: List[Dict[str, str]] = []

    # ---- 命令执行（默认实现，可被注入替换） ----

    def _default_execute(self, cmd: Dict[str, Any]) -> str:
        intent = cmd.get("intent")
        try:
            if intent == "exit":
                return "好的，已退出。"
            if intent == "help":
                return ("支持指令示例：预测茅台 / 分析600519 / 量化体检 / "
                        "A股板块排名 / 上证指数体制 / 情景分析 / 自上而下全景 / "
                        "大佬们怎么看茅台。")
            if intent == "predict" and cmd.get("code"):
                import sys
                from pathlib import Path
                _sp = str(Path(__file__).resolve().parents[1])
                if _sp not in sys.path:
                    sys.path.insert(0, _sp)
                from stock_predict import predict
                r = predict(cmd["code"], silent=True, quick_mode=True)
                if "error" in r:
                    return f"分析失败：{r['error']}"
                mc = r.get("monte_carlo", {}).get("5d", {})
                return (f"{r.get('name', cmd['code'])}当前价"
                        f"{r.get('price', {}).get('price', '未知')}，"
                        f"信号{r.get('signal', '未知')}，"
                        f"置信度{r.get('confidence', 0):.0%}，"
                        f"五日上涨概率{mc.get('up', 0):.0%}，"
                        f"综合评分{r.get('score', {}).get('total', 0):.0f}。")
            if intent == "sector_ranking":
                from stock_researcher.sector_analysis_relative_strength import rps_ranking, SectorRelativeStrength
                return SectorRelativeStrength.format_ranking(
                    rps_ranking(market=cmd.get("params", {}).get("market", "cn")),
                    market=cmd.get("params", {}).get("market", "cn"))
            if intent == "index_regime":
                from stock_researcher.index_analysis_market_regime import MarketRegimeClassifier
                return MarketRegimeClassifier.format(
                    MarketRegimeClassifier().classify(cmd.get("code") or "sh000001"))
            if intent == "scenario":
                from stock_researcher.quantitative_scenario_engine import MacroScenarioEngine
                eng = MacroScenarioEngine()
                return MacroScenarioEngine.format(eng.analyze(0.08, 0.20, None))
            if intent == "topdown":
                from stock_researcher.analysis_top_down import TopDownReport
                return TopDownReport.format(
                    TopDownReport().build(market=cmd.get("params", {}).get("market", "cn")))
            if intent == "quant_check" and cmd.get("code"):
                from stock_researcher.data_global_market import fetch_global_kline
                from stock_researcher import compute_quant_metrics, format_quant_metrics
                kline = fetch_global_kline(cmd["code"], days=120)
                closes = [float(k.get("close", 0)) for k in (kline or []) if k.get("close")]
                if len(closes) < 30:
                    return f"{cmd['code']} 历史数据不足，无法体检。"
                return format_quant_metrics(cmd["code"], compute_quant_metrics(closes))
            # v9.7 知识库交互：保存分析 / 检索 / 回读量化（不联网，v9.8 可指定适配器）
            if intent == "kb_save" and cmd.get("code"):
                import sys
                from pathlib import Path
                _sp = str(Path(__file__).resolve().parents[1])
                if _sp not in sys.path:
                    sys.path.insert(0, _sp)
                from stock_predict import predict, fetch_quote_kline
                from stock_researcher.knowledge_sync import save_analysis_to_kb
                r = predict(cmd["code"], silent=True, quick_mode=True)
                if "error" in r:
                    return f"分析失败，无法保存知识库：{r['error']}"
                _, kl = fetch_quote_kline(cmd["code"], silent=True, days=120)
                prices = [k["close"] for k in (kl or []) if k.get("close")]
                res = save_analysis_to_kb(
                    cmd["code"], r, prices,
                    target=cmd.get("params", {}).get("target"))
                if res.get("ok"):
                    return (f"已保存到知识库（{res.get('adapter')}）："
                            f"{res.get('title')}，状态 {res.get('status')}。")
                return f"保存知识库失败：{res.get('error')}"
            if intent == "kb_search":
                from stock_researcher.knowledge_sync import search_knowledge
                query = cmd.get("params", {}).get("query") or ""
                if not query:
                    return "请告诉我要在知识库里查什么，比如：查一下知识库里的茅台。"
                hits = search_knowledge(
                    query, target=cmd.get("params", {}).get("target"), limit=3)
                if not hits:
                    return f"知识库未找到与 “{query}” 相关的笔记。"
                lines = [f"知识库命中 {len(hits)} 条："]
                for h in hits:
                    lines.append(f"- {h.get('title', '')}："
                                 f"{(h.get('snippet') or '')[:80]}")
                return "\n".join(lines)
            if intent == "kb_quant":
                from stock_researcher.knowledge_sync import kb_quant_forecast
                query = cmd.get("params", {}).get("query") or ""
                if not query:
                    return "请告诉我要用哪条知识库数据做量化，比如：用知识库里的茅台数据体检。"
                rep = kb_quant_forecast(
                    query, target=cmd.get("params", {}).get("target"))
                if not rep.get("ok"):
                    return rep.get("error", "知识库量化失败。")
                m = rep["metrics"]
                pf = rep["pattern_forecast"]
                if pf.get("data_mode") == "ok":
                    fc = (f"未来5日预期"
                          f"{pf.get('predicted_pct', 0):+.2f}%，"
                          f"上涨概率{pf.get('prob_up', 0):.0f}%。")
                else:
                    fc = "历史形态匹配不足，未给出方向预测。"
                return (f"知识库回读 {rep.get('name') or rep.get('code')}"
                        f"（{rep.get('points')} 个价格点，存档于"
                        f"{rep.get('saved_at', '未知')}）："
                        f"总收益{m.get('total_return_pct', 0):+.2f}%，"
                        f"夏普{m.get('sharpe_ratio') or '—'}，"
                        f"最大回撤{m.get('max_drawdown_pct', 0):.2f}%。{fc}")
            if intent == "masters" and cmd.get("code"):
                import sys
                from pathlib import Path
                _sp = str(Path(__file__).resolve().parents[1])
                if _sp not in sys.path:
                    sys.path.insert(0, _sp)
                from stock_predict import fetch_quote_kline
                from stock_researcher.agents_master_input import MasterInput
                from stock_researcher.agents_master_council import MasterCouncil
                q, kl = fetch_quote_kline(cmd["code"], silent=True, days=250)
                if not q or "error" in q:
                    return f"圆桌失败：{(q or {}).get('error', '行情获取失败')}"
                inp = MasterInput.from_market(
                    code=q.get("code", cmd["code"]), name=q.get("name", ""),
                    price=q.get("price", 0), pe=q.get("pe", 0),
                    closes=[k["close"] for k in (kl or [])],
                )
                rep = MasterCouncil().analyze(inp)
                if rep.valid_count == 0:
                    return f"{cmd['code']} 数据不足，大佬们无法给出意见。"
                return MasterCouncil.format(rep)
            return cmd.get("echo") or "没听懂指令，说“帮助”可查看支持的功能。"
        except Exception as e:
            return f"执行失败：{e}"

    # ---- 会话 ----

    def handle_text(self, text: str) -> str:
        """处理一轮输入（文本或 STT 结果），返回回复文本。"""
        cmd = parse_voice_command(text)
        reply = self.executor(cmd)
        self.history.append({"user": text, "reply": reply})
        if self.tts:
            try:
                self.speak_fn(summarize_for_speech(reply))
            except Exception:
                pass
        return reply

    def run(self, max_turns: int = 0) -> None:
        """主循环。STT 不可用时降级为文本输入；max_turns>0 限制轮数。"""
        use_voice = stt_available() and self.listen is listen_once
        if not use_voice and self.listen is listen_once:
            print("ℹ️ 语音识别不可用，已降级为文本输入。")
        print("🎙️ 股票研究员语音交互（说“帮助”查看指令，“退出”结束）")
        turns = 0
        while True:
            try:
                if use_voice:
                    print("🎤 请说话…")
                    user = self.listen(timeout=self.listen_timeout)
                    if user:
                        print(f"🗣️ 识别：{user}")
                else:
                    user = input("📝 指令> ").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if not user:
                continue
            reply = self.handle_text(user)
            print(reply)
            turns += 1
            if parse_voice_command(user).get("intent") == "exit":
                break
            if max_turns and turns >= max_turns:
                break
