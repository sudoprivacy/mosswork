# -*- coding: utf-8 -*-
"""v13.0 PDF(.pdf) 导出器：把 IR 文档树渲染成 PDF 字节。

引擎：
  - ``stdlib``（主引擎）：只用 ``zlib`` + 标准库手写 PDF。中文走 Adobe 注册的
    CID 关键字体 ``STSong-Light`` + ``UniGB-UCS2-H``，**不嵌字体文件**，所以技能包
    能保持零二进制，市场沙箱里也没有任何 pip 依赖。
  - ``reportlab``（可选增强）：仅在该包可导入时启用；本机没装时 ``resolve_engine``
    直接抛 ``ExportError`` 说清缺什么，不返回半截产物，也不谎报成功。

同一份 doc 两次渲染字节完全一致：不写时间戳、``/ID`` 由内容派生，导出结果可 diff、
可复核。纯标准库顶层依赖；不联网、不起子进程、不向 stdout 打印（MCP stdio 会破坏帧）。
"""
from __future__ import annotations

import binascii
import hashlib
import logging
import os
import re
import zlib
from typing import Any, Dict, List, Optional, Sequence, Tuple

from stock_researcher import report_ir
from stock_researcher.report_ir import (
    Bullets, Callout, CodeBlock, Heading, MetricGrid, Paragraph,
    ReportDocument, Table,
)

FORMAT = "pdf"
MEDIA_TYPE = "application/pdf"
DEFAULT_FILENAME = "report.pdf"

PAGE_W, PAGE_H = 595.28, 841.89                    # A4，单位 pt
MARGIN_L, MARGIN_R = 54.0, 54.0
MARGIN_T, MARGIN_B = 58.0, 62.0
CONTENT_W = PAGE_W - MARGIN_L - MARGIN_R           # 487.28 pt 版心
CELL_PAD = 3.5                                    # 表格单元格左右内缩
LINE_H = 1.34                                     # 行高倍率
ASCENT = 0.82                                     # 基线相对行框顶边的比例

CID_BASE = "STSong-Light"                         # Adobe-GB1 注册名，无需字体文件
CID_REGISTRY, CID_ORDERING, CID_SUPPLEMENT = "Adobe", "GB1", 2
CID_ENCODING = "UniGB-UCS2-H"
MONO_BASE = "Courier"                             # 14 个标准字体之一，仅用于纯 ASCII

INK = (0.11, 0.13, 0.16)
MUTED = (0.42, 0.46, 0.51)
ACCENT = (0.13, 0.31, 0.55)
HAIRLINE = (0.70, 0.74, 0.79)
HEAD_FILL = (0.93, 0.95, 0.97)
NOTE_FILL = (0.95, 0.96, 0.98)
WARN_FILL = (0.99, 0.93, 0.93)
WARN_EDGE = (0.80, 0.34, 0.31)

PDF_DATE = b"(D:20260101000000+08'00')"           # 固定日期：字节可复现的前提
LOG = logging.getLogger("stock_researcher.export_pdf")


class ExportError(RuntimeError):
    """导出失败：输入不是报告、所选引擎不可用、或生成的 PDF 结构不合法。"""


# ------------------------------------------------------------------ 引擎选择

_ALIASES = {"stdlib": "stdlib", "std": "stdlib", "base": "stdlib",
            "reportlab": "reportlab", "rl": "reportlab", "lib": "reportlab"}
_RL_OK: Optional[bool] = None


def _has_reportlab() -> bool:
    global _RL_OK
    if _RL_OK is None:
        try:
            from importlib.util import find_spec
            _RL_OK = bool(find_spec("reportlab"))
        except Exception:                          # 被依赖屏蔽器拦下也算不可用
            _RL_OK = False
    return _RL_OK


def engines() -> List[str]:
    """当前环境可用的引擎，主引擎在前。"""
    return ["stdlib", "reportlab"] if _has_reportlab() else ["stdlib"]


def resolve_engine(engine: str = "auto") -> str:
    """把 auto/别名解析成实际引擎名；未知名字抛 ValueError，缺依赖抛 ExportError。"""
    key = str(engine or "auto").strip().lower()
    if key in ("", "auto", "default"):
        return engines()[0]
    name = _ALIASES.get(key)
    if name is None:
        raise ValueError("未知的 pdf 引擎 %r，可选：%s" % (engine, ", ".join(engines())))
    if name == "reportlab" and not _has_reportlab():
        raise ExportError("reportlab 不可用，请 pip install reportlab 或改用 stdlib 引擎")
    return name


# ------------------------------------------------------------------ 文本度量

_CONTROL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_OUT_OF_RANGE = re.compile("[\ud800-\udfff\U00010000-\U0010FFFF\ufffe\uffff]")


def _clean(text: Any) -> str:
    """压成 CID 字体安全的 BMP 文本：去控制字符，BMP 外码点换方块。"""
    s = text if isinstance(text, str) else ("" if text is None else str(text))
    s = s.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")
    return _OUT_OF_RANGE.sub("\u25a1", _CONTROL.sub("", s))


def _is_wide(ch: str) -> bool:
    return ord(ch) >= 0x2E80


def _dw(text: str) -> int:
    """显示宽度：中日韩全角按两格，其余按一格。"""
    return sum(2 if _is_wide(c) else 1 for c in text)


def _text_w(text: str, size: float, mono: bool = False) -> float:
    """行宽估算：全角按 1em，半角按 0.5em（CID）或 0.6em（Courier）。

    Courier 行里混进全角字时会退回 CID 字体，所以两种度量都得留出余量，
    宁可估宽也不能估窄——估窄了文字直接冲出右边界。
    """
    total = 0.0
    for ch in text:
        total += 1.0 if _is_wide(ch) else (0.6 if mono else 0.5)
    return size * total


def _tokens(text: str) -> List[str]:
    """切词：CJK 单字成词，拉丁/数字连续成词，空白丢弃。"""
    out: List[str] = []
    buf = ""
    for ch in text:
        if ch.isspace():
            if buf:
                out.append(buf)
                buf = ""
        elif _is_wide(ch):
            if buf:
                out.append(buf)
                buf = ""
            out.append(ch)
        else:
            buf += ch
    if buf:
        out.append(buf)
    return out


def _split_long(token: str, size: float, width: float, mono: bool) -> List[str]:
    """单个词就超版心时按字符硬切，避免长串冲出页面。"""
    chunks: List[str] = []
    cur = ""
    cur_w = 0.0
    for ch in token:
        w = _text_w(ch, size, mono)
        if cur and cur_w + w > width:
            chunks.append(cur)
            cur, cur_w = ch, w
        else:
            cur += ch
            cur_w += w
    if cur:
        chunks.append(cur)
    return chunks


def _wrap(text: Any, size: float, width: float, mono: bool = False) -> List[str]:
    raw = _tokens(_clean(text))
    toks: List[str] = []
    for t in raw:
        if _text_w(t, size, mono) > width:
            toks.extend(_split_long(t, size, width, mono))
        else:
            toks.append(t)
    if not toks:
        return [""]
    space = 0.6 * size if mono else size * 0.5
    lines: List[str] = []
    cur, cur_w = "", 0.0
    for t in toks:
        w = _text_w(t, size, mono)
        if cur:
            trial = cur_w + space + w
            if trial > width:
                lines.append(cur)
                cur, cur_w = t, w
                continue
            cur += " " + t
            cur_w = trial
        else:
            cur, cur_w = t, w
    if cur:
        lines.append(cur)
    return lines or [""]


# ------------------------------------------------------------------ 版面书写

Op = Tuple[Any, ...]


class _Sheet:
    """A4 版面：维护当前页与纵向光标，把 IR 块流排成带分页的绘制指令。"""

    def __init__(self) -> None:
        self.pages: List[List[Op]] = [[]]

    # --- 原子操作 ---------------------------------------------------------
    @property
    def ops(self) -> List[Op]:
        return self.pages[-1]

    def carry(self, y: float, need: float) -> Tuple[List[Op], float]:
        """需要 need 高度；放不下就翻页并回到页顶。"""
        if self.pages[-1] and y + need > PAGE_H - MARGIN_B:
            self.pages.append([])
            return self.pages[-1], MARGIN_T
        return self.pages[-1], y

    def text(self, ops: List[Op], y: float, x: float, size: float, s: str,
             color: Tuple[float, float, float] = INK, mono: bool = False,
             align: str = "left", box_w: float = 0.0) -> None:
        font_mono = mono and s.isascii()
        if align == "right":
            x = x + box_w - _text_w(s, size, font_mono)
        elif align == "center":
            x = x + (box_w - _text_w(s, size, font_mono)) / 2.0
        ops.append(("t", round(x, 2), round(y + size * ASCENT, 2), size, s, font_mono, color))

    def rect(self, ops: List[Op], y: float, x: float, w: float, h: float,
             fill: Optional[Tuple[float, float, float]] = None,
             edge: Optional[Tuple[float, float, float]] = None) -> None:
        ops.append(("r", round(x, 2), round(y, 2), round(w, 2), round(h, 2), fill, edge))

    def rule(self, ops: List[Op], y: float, x: float, w: float,
             color: Tuple[float, float, float] = HAIRLINE) -> None:
        ops.append(("l", round(x, 2), round(y, 2), round(x + w, 2), round(y, 2), color))

    # --- 段落级 -----------------------------------------------------------
    def para(self, y: float, text: Any, size: float, *, x: float = MARGIN_L,
             width: float = CONTENT_W, color: Tuple[float, float, float] = INK,
             mono: bool = False, gap: float = 0.0) -> float:
        for line in _wrap(text, size, width, mono):
            ops, y = self.carry(y, size * LINE_H)
            self.text(ops, y, x, size, line, color, mono)
            y += size * LINE_H
        return y + gap

    # --- 结构化块 ---------------------------------------------------------
    def heading(self, y: float, text: str, level: int) -> float:
        size = {1: 16.0, 2: 12.5}.get(level, 10.5)
        color = ACCENT if level <= 2 else INK
        ops, y = self.carry(y, size * LINE_H + 22.0)   # 标题下面至少留两行，防空头标题
        ops, y = self.carry(y, size * LINE_H)
        self.text(ops, y, MARGIN_L, size, _clean(text), color)
        y += size * LINE_H
        if level <= 2:
            ops, y = self.carry(y, 4.0)
            self.rule(ops, y, MARGIN_L, CONTENT_W)
            y += 4.0
        return y + 5.0

    def bullets(self, y: float, items: Sequence[str], ordered: bool) -> float:
        size = 9.2
        marker_w = 14.0
        for i, item in enumerate(items, 1):
            lines = _wrap(item, size, CONTENT_W - marker_w)
            for j, line in enumerate(lines):
                ops, y = self.carry(y, size * LINE_H)
                if j == 0:
                    if ordered:
                        self.text(ops, y, MARGIN_L, size, "%d." % i, ACCENT)
                    else:
                        # • 在 Adobe-GB1 里没有对应字形，部分阅读器直接画空；改成实心方块。
                        self.rect(ops, y + size * 0.42, MARGIN_L + 3.0,
                                  size * 0.20, size * 0.20, MUTED)
                self.text(ops, y, MARGIN_L + marker_w, size, line, INK)
                y += size * LINE_H
            y += 1.5
        return y + 4.0

    def metric_grid(self, y: float, items: Sequence[Tuple[str, str]]) -> float:
        size = 9.0
        key_w = 168.0
        for key, value in items:
            ops, y = self.carry(y, size * LINE_H + 1.0)
            self.text(ops, y, MARGIN_L, size, _clean(key), MUTED)
            self.text(ops, y, MARGIN_L + key_w, size, _clean(value), INK)
            y += size * LINE_H + 1.0
        return y + 5.0

    def code_block(self, y: float, text: str) -> float:
        size = 8.0
        line_h = size * 1.30
        lines: List[str] = []
        for raw in _clean(text).split("\n"):
            lines.extend(_wrap(raw, size, CONTENT_W - 16.0, True) if raw else [""])
        for line in lines:
            ops, y = self.carry(y, line_h)
            self.rect(ops, y, MARGIN_L, CONTENT_W, line_h, NOTE_FILL)
            self.text(ops, y, MARGIN_L + 8.0, size, line, (0.20, 0.22, 0.26), mono=True)
            y += line_h
        return y + 6.0

    def callout(self, y: float, text: str, kind: str) -> float:
        size = 9.0
        lines = _wrap(text, size, CONTENT_W - 22.0)
        height = len(lines) * size * LINE_H + 12.0
        ops, y = self.carry(y, min(height, PAGE_H - MARGIN_T - MARGIN_B))
        fill = WARN_FILL if kind == "warning" else NOTE_FILL
        edge = WARN_EDGE if kind == "warning" else ACCENT
        self.rect(ops, y, MARGIN_L, CONTENT_W, height, fill)
        self.rect(ops, y, MARGIN_L, 2.5, height, edge)
        y += 6.0
        for line in lines:
            self.text(ops, y, MARGIN_L + 12.0, size, line, INK)
            y += size * LINE_H
        return y + 8.0

    def table(self, y: float, header: Sequence[str], rows: Sequence[Sequence[str]],
              align: Sequence[str], caption: str) -> float:
        size = 8.4
        ncols = len(header) or (max((len(r) for r in rows), default=1))
        if ncols == 0:
            return y
        aligns = [align[i] if i < len(align) else "left" for i in range(ncols)]
        widths = self._col_widths(header, rows, ncols, size)
        if caption:
            y = self.para(y, caption, 8.2, color=MUTED, gap=2.0)

        def draw_head(ops: List[Op], yy: float) -> float:
            per_col = [_wrap(header[i] if i < len(header) else "", size,
                              widths[i] - 2 * CELL_PAD) for i in range(ncols)]
            height = max(len(c) for c in per_col) * size * LINE_H + 5.0
            self.rect(ops, yy, MARGIN_L, CONTENT_W, height, HEAD_FILL)
            x = MARGIN_L
            for i in range(ncols):
                ty = yy + 2.5
                for line in per_col[i]:
                    self.text(ops, ty, x, size, line, ACCENT,
                              align=aligns[i], box_w=widths[i] - 2 * CELL_PAD)
                    ty += size * LINE_H
                x += widths[i]
            return yy + height

        ops, y = self.carry(y, size * LINE_H + 10.0)
        y = draw_head(ops, y)
        self.rule(ops, y, MARGIN_L, CONTENT_W)
        y += 1.0

        for row in rows:
            cells = ["" if row is None else str(row[i] if i < len(row) else "")
                     for i in range(ncols)]
            per_col = [_wrap(cells[i], size, widths[i] - 2 * CELL_PAD) for i in range(ncols)]
            nlines = max((len(c) for c in per_col), default=1)
            height = nlines * size * LINE_H + 5.0
            ops, y = self.carry(y, height)
            x = MARGIN_L
            for i in range(ncols):
                lines = per_col[i]
                ty = y + 2.5
                for line in lines:
                    self.text(ops, ty, x, size, line, INK,
                              align=aligns[i], box_w=widths[i] - 2 * CELL_PAD)
                    ty += size * LINE_H
                x += widths[i]
            y += height
            self.rule(ops, y, MARGIN_L, CONTENT_W)
            y += 1.0
        return y + 6.0

    @staticmethod
    def _col_widths(header: Sequence[str], rows: Sequence[Sequence[str]],
                    ncols: int, size: float) -> List[float]:
        """按内容显示宽度分栏，再夹在 [42, 版心/栏数*2.4] 之间避免单列吃掉整版。"""
        raw: List[float] = []
        for i in range(ncols):
            cells = [str(header[i]) if i < len(header) else ""]
            cells += [str(r[i]) for r in rows if i < len(r)]
            widest = max((_dw(c) for c in cells), default=4)
            raw.append(float(min(max(widest, 6), 46)))
        total = sum(raw) or float(ncols)
        widths = [CONTENT_W * w / total for w in raw]
        cap = max(60.0, CONTENT_W / ncols * 2.4)
        widths = [min(w, cap) for w in widths]
        low = [w for w in widths if w < 42.0]
        if low:
            widths = [max(w, 42.0) for w in widths]
        scale = CONTENT_W / (sum(widths) or 1.0)
        return [w * scale for w in widths]

    # --- 整篇 -------------------------------------------------------------
    def render(self, doc: ReportDocument) -> None:
        y = MARGIN_T
        ops, y = self.carry(y, 40.0)
        y = self.para(y, doc.title, 18.0, color=ACCENT, gap=2.0)
        if doc.subtitle:
            y = self.para(y, doc.subtitle, 10.5, color=MUTED, gap=3.0)
        for key, value in doc.meta:
            y = self.para(y, "%s：%s" % (key, value), 8.6, color=MUTED, gap=0.5)
        ops = self.pages[-1]
        y += 2.0
        self.rule(ops, y, MARGIN_L, CONTENT_W, ACCENT)
        y += 10.0
        for section in doc.sections:
            y = self.heading(y, section.title, 2)
            y = self._blocks(section.blocks, y)
        if doc.disclaimer:
            y = self.heading(y, "免责声明", 2)
            y = self.para(y, doc.disclaimer, 8.4, color=MUTED, gap=0.0)
        self._footers()

    def _blocks(self, blocks: Sequence[Any], y: float) -> float:
        for block in blocks:
            if isinstance(block, Heading):
                y = self.heading(y, block.text, block.level)
            elif isinstance(block, Paragraph):
                size = {"lead": 11.0, "note": 8.6}.get(block.style, 9.4)
                color = MUTED if block.style == "note" else INK
                y = self.para(y, block.text, size, color=color, gap=5.0)
            elif isinstance(block, Bullets):
                y = self.bullets(y, block.items, block.ordered)
            elif isinstance(block, Table):
                y = self.table(y, block.header, block.rows, block.align, block.caption)
            elif isinstance(block, MetricGrid):
                y = self.metric_grid(y, block.items)
            elif isinstance(block, CodeBlock):
                y = self.code_block(y, block.text)
            elif isinstance(block, Callout):
                y = self.callout(y, block.text, block.kind)
        return y

    def _footers(self) -> None:
        total = len(self.pages)
        for idx, ops in enumerate(self.pages, 1):
            if not ops and total > 1 and idx > 1:
                continue
            label = "第 %d 页 / 共 %d 页" % (idx, total)
            w = _text_w(label, 8.0)
            ops.append(("t", round((PAGE_W - w) / 2.0, 2),
                        round(PAGE_H - MARGIN_B + 18.0, 2), 8.0, label, False, MUTED))


# ------------------------------------------------------------------ PDF 装配

def _hex_cid(text: str) -> bytes:
    return b"<" + binascii.hexlify(text.encode("utf-16-be")).upper() + b">"


def _literal(text: str) -> bytes:
    safe = text.encode("cp1252", "replace").decode("cp1252", "replace")
    escaped = safe.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    return b"(" + escaped.encode("cp1252", "replace") + b")"


def _color(triple: Tuple[float, float, float], op: str) -> bytes:
    return ("%.3f %.3f %.3f %s" % (triple[0], triple[1], triple[2], op)).encode("ascii")


def _content_stream(ops: Sequence[Op]) -> bytes:
    out: List[bytes] = []
    for op in ops:
        kind = op[0]
        if kind == "t":
            _, x, y, size, text, mono, color = op
            font = b"/F2" if mono else b"/F1"
            payload = _literal(text) if mono else _hex_cid(text)
            out.append(b"q " + _color(color, "rg") + b" BT " + font +
                       (" %.2f Tf" % size).encode("ascii") +
                       (" 1 0 0 1 %.2f %.2f Tm " % (x, PAGE_H - y)).encode("ascii") +
                       payload + b" Tj ET Q\n")
        elif kind == "r":
            _, x, y, w, h, fill, edge = op
            rect = (" %.2f %.2f %.2f %.2f re" % (x, PAGE_H - y - h, w, h)).encode("ascii")
            seg = [b"q"]
            if fill:
                seg.append(_color(fill, "rg"))
            if edge:
                seg.append(_color(edge, "RG"))
                seg.append(b"0.8 w")
            seg.append(rect)
            seg.append(b"B" if (fill and edge) else (b"f" if fill else b"S"))
            seg.append(b"Q\n")
            out.append(b" ".join(seg))
        elif kind == "l":
            _, x1, y1, x2, y2, color = op
            out.append(b"q " + _color(color, "RG") + b" 0.6 w" +
                       (" %.2f %.2f m %.2f %.2f l S Q\n" % (
                           x1, PAGE_H - y1, x2, PAGE_H - y2)).encode("ascii"))
    return b"".join(out)


def _obj(num: int, body: bytes) -> bytes:
    return b"%d 0 obj\n" % num + body + b"\nendobj\n"


def _stream_obj(data: bytes, extra: bytes = b"") -> bytes:
    packed = zlib.compress(data, 9)
    head = b"<< /Length %d%s >>\nstream\n" % (len(packed), extra)
    return head + packed + b"\nendstream"


def _build_pdf(doc: ReportDocument, pages: Sequence[Sequence[Op]]) -> bytes:
    n = len(pages)
    first_page = 6
    info_num = first_page + 2 * n
    kids = b" ".join(b"%d 0 R" % (first_page + 2 * i) for i in range(n))

    bodies: List[bytes] = []

    def push(body: bytes) -> None:
        bodies.append(body)

    # 1 Catalog
    push(b"<< /Type /Catalog /Pages 2 0 R >>")
    # 2 Pages
    push(b"<< /Type /Pages /Kids [%s] /Count %d /MediaBox [0 0 %.2f %.2f] "
         b"/Resources << /Font << /F1 3 0 R /F2 5 0 R >> >> >>"
         % (kids, n, PAGE_W, PAGE_H))
    # 3 Type0 父字体（中文）
    push(b"<< /Type /Font /Subtype /Type0 /BaseFont /" + CID_BASE.encode("ascii") +
         b" /Encoding /" + CID_ENCODING.encode("ascii") +
         b" /DescendantFonts [4 0 R] >>")
    # 4 CIDFontType0 后代（不嵌字体文件，靠阅读器按 Adobe 注册名替换字形）
    push(b"<< /Type /Font /Subtype /CIDFontType0 /BaseFont /%s "
         b"/CIDSystemInfo << /Registry (Adobe) /Ordering (%s) /Supplement %d >> "
         b"/CIDToGIDMap /Identity /DW 1000 /W [1 95 500] "
         b"/FontDescriptor << /Type /FontDescriptor /FontName /%s "
         b"/Flags 4 /FontBBox [-25 -254 1000 880] /ItalicAngle 0 /Ascent 880 "
         b"/Descent -120 /CapHeight 731 /StemV 58 >> >>"
         % (CID_BASE.encode("ascii"), CID_ORDERING.encode("ascii"),
            CID_SUPPLEMENT, CID_BASE.encode("ascii")))
    # 5 Courier（标准 14 号字体，只承载纯 ASCII 行）
    push(b"<< /Type /Font /Subtype /Type1 /BaseFont /" + MONO_BASE.encode("ascii") +
         b" /Encoding /WinAnsiEncoding >>")
    # 6.. 页面与内容流：页对象必须显式指向自己的 /Contents，否则阅读器画出空白页。
    # /Resources 也直接挂在页上，不只留在 Pages 节点——部分导入器不回溯属性继承。
    resources = b"<< /Font << /F1 3 0 R /F2 5 0 R >> >>"
    for i, ops in enumerate(pages):
        page_num = first_page + 2 * i
        push(b"<< /Type /Page /Parent 2 0 R /Contents %d 0 R /Resources %s >>"
             % (page_num + 1, resources))
        push(_stream_obj(_content_stream(ops), b" /Filter /FlateDecode"))
    # Info
    title = _pdf_string(doc.title)
    push(b"<< /Title %s /Producer (stock-researcher report_ir) /Subject "
         b"(research report) /CreationDate %s /ModDate %s >>" % (title, PDF_DATE, PDF_DATE))

    out = bytearray(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n")
    offsets: List[int] = []
    for i, body in enumerate(bodies, 1):
        offsets.append(len(out))
        out += _obj(i, body)
    xref_at = len(out)
    total = len(bodies) + 1
    out += b"xref\n0 %d\n" % total
    out += b"0000000000 65535 f \n"
    for off in offsets:
        out += b"%010d 00000 n \n" % off
    digest = hashlib.md5(bytes(out)).hexdigest().encode("ascii").upper()
    out += (b"trailer << /Size %d /Root 1 0 R /Info %d 0 R "
            b"/ID [<%s> <%s>] >>\nstartxref\n%d\n%%%%EOF\n"
            % (total, info_num, digest, digest, xref_at))
    return bytes(out)


def _pdf_string(text: str) -> bytes:
    """Info 字典里的文档标题：PDF 标准建议 UTF-16BE 十六进制串。"""
    cleaned = _OUT_OF_RANGE.sub("", _CONTROL.sub("", str(text or "")))
    if len(cleaned) > 200:
        cleaned = cleaned[:200]
    return b"<FEFF" + binascii.hexlify(cleaned.encode("utf-16-be")).upper() + b">"


# ------------------------------------------------------------------ 校验

def _validate(blob: bytes) -> None:
    """不依赖第三方库的结构校验：文件头、EOF、以及每个 xref 偏移真的指向对象。"""
    if not blob.startswith(b"%PDF-"):
        raise ExportError("产物不是合法 PDF 文件头")
    tail = blob.rstrip()
    if not tail.endswith(b"%%EOF"):
        raise ExportError("PDF 缺少 %%EOF 终止符")
    m = re.search(rb"startxref\s+(\d+)\s+%%EOF\s*$", tail)
    if not m:
        raise ExportError("PDF 缺少 startxref")
    start = int(m.group(1))
    if not (0 < start < len(blob)) or not blob[start:start + 4] == b"xref":
        raise ExportError("PDF xref 偏移无效")
    table = blob[start:]
    header = re.match(rb"xref\s+0\s+(\d+)\s+", table)
    if not header:
        raise ExportError("PDF xref 表头无法解析")
    size = int(header.group(1))
    entries = re.findall(rb"\n(\d{10}) (\d{5}) ([nf]) ", table)
    if len(entries) != size:
        raise ExportError("PDF xref 条目数 %d 与 /Size %d 不符" % (len(entries), size))
    for i, (off, _gen, flag) in enumerate(entries):   # 第 0 条是空闲槽位
        if flag != b"n":
            continue
        pos = int(off)
        expect = b"%d 0 obj" % i
        if blob[pos:pos + len(expect)] != expect:
            raise ExportError("PDF 第 %d 号对象偏移 %d 未指向对象头" % (i, pos))
    if not any(flag == b"n" for _o, _g, flag in entries):
        raise ExportError("PDF xref 表里没有任何在用对象")


def _validate_stdlib(blob: bytes) -> None:
    """自研写入器的加严校验：结构之外还要确认内容流真的在画东西。

    结构对了不代表画得出来——内容流算子写错，阅读器只会给一张空白页；
    这类错误 xref 检查看不出来，只有把流解压出来才能抓到。
    reportlab 的产物交给它自己负责，这里只跑 _validate。
    """
    _validate(blob)
    streams = re.findall(rb"stream\r?\n(.*?)\r?\nendstream", blob, re.S)
    if not streams:
        raise ExportError("PDF 没有任何内容流")
    for idx, raw in enumerate(streams, 1):
        try:
            text = zlib.decompress(raw)
        except zlib.error as exc:
            raise ExportError("PDF 第 %d 条内容流解压失败：%s" % (idx, exc)) from exc
        if b"Tj" not in text and b" re" not in text and b" m" not in text:
            raise ExportError("PDF 第 %d 条内容流里没有任何绘制算子" % idx)
        for seg in re.findall(rb"([0-9.\- ]+)Tm", text):
            # Tm 是六参数矩阵；只给两个会让整条流解析失败，页面直接空白。
            if len(seg.split()) != 6:
                raise ExportError(
                    "PDF 第 %d 条内容流的 Tm 只给了 %d 个操作数（需要 6 个）"
                    % (idx, len(seg.split())))


def _coerce(doc: Any) -> ReportDocument:
    """ReportDocument 直接用；ResearchReport / 其 dict 走 IR 编译。"""
    try:
        return report_ir.coerce_document(doc)
    except Exception as exc:
        raise ExportError("报告无法编译为 IR：%s" % exc) from exc


def _render_stdlib(document: ReportDocument) -> bytes:
    sheet = _Sheet()
    sheet.render(document)
    return _build_pdf(document, sheet.pages)


def _rl_esc(text: Any) -> str:
    """把 IR 文本转成 reportlab Paragraph 需要的 XML 片段。

    报告里出现 ``<`` 是常态（"估值 < 30%"、比较符），不转义会让 Paragraph 解析报错、
    整份 PDF 直接失败，所以这里必须转，而不是等调用方保证数据干净。
    """
    return (_clean(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _render_reportlab(document: ReportDocument) -> bytes:
    """可选增强：交给 reportlab 排同一棵 IR 树，由它嵌入真实字体。"""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.cidfonts import UnicodeCIDFont
        from reportlab.platypus import (BaseDocTemplate, Frame, ListFlowable,
                                        ListItem, PageTemplate, Paragraph as RlPara,
                                        Spacer as RlSpacer,
                                        Table as RlTable, TableStyle)
    except Exception as exc:  # pragma: no cover - 取决于本机是否安装
        raise ExportError("reportlab 不可用：%s" % exc) from exc
    import io

    # STSong-Light 是 Adobe 注册的 CID 字体，不需要字体文件，但要显式注册过才能用；
    # 没注册时 reportlab 会静默回退，中文全部变成黑方块，所以这里把它当硬前置。
    try:
        pdfmetrics.getFont(CID_BASE)
    except Exception:
        try:
            pdfmetrics.registerFont(UnicodeCIDFont(CID_BASE))
        except Exception as exc:
            raise ExportError("reportlab 缺少中文字体 %s（%s），请改用 stdlib 引擎"
                              % (CID_BASE, exc)) from exc

    styles = {
        1: ParagraphStyle("h1", fontName=CID_BASE, fontSize=16, leading=22),
        2: ParagraphStyle("h2", fontName=CID_BASE, fontSize=12, leading=18),
        3: ParagraphStyle("h3", fontName=CID_BASE, fontSize=10, leading=16),
        "body": ParagraphStyle("body", fontName=CID_BASE, fontSize=9, leading=14),
        "note": ParagraphStyle("note", fontName=CID_BASE, fontSize=8.5, leading=13,
                               leftIndent=6, textColor=MUTED),
        "code": ParagraphStyle("code", fontName=CID_BASE, fontSize=7.5, leading=11,
                               leftIndent=6),
    }
    buf = io.BytesIO()
    doc = BaseDocTemplate(buf, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
                          topMargin=20 * mm, bottomMargin=20 * mm,
                          title=document.title or "研究报告")
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="body")
    doc.addPageTemplates([PageTemplate(id="p", frames=[frame])])
    story: List[Any] = [RlPara(_rl_esc(document.title), styles[1])]
    if document.subtitle:
        story.append(RlPara(_rl_esc(document.subtitle), styles["body"]))
    for key, value in document.meta:
        story.append(RlPara("%s：%s" % (_rl_esc(key), _rl_esc(value)), styles["note"]))
    story.append(RlSpacer(1, 6 * mm))
    for section in document.sections:
        story.append(RlPara(_rl_esc(section.title), styles[2]))
        story.append(RlSpacer(1, 2 * mm))
        for block in section.blocks:
            story.extend(_rl_flow(block, styles, RlPara, RlSpacer, RlTable,
                                  TableStyle, ListFlowable, ListItem, mm))
    if document.disclaimer:
        story.append(RlPara("免责声明", styles[2]))
        story.append(RlPara(_rl_esc(document.disclaimer), styles["note"]))
    doc.build(story)
    return buf.getvalue()


def _rl_flow(block: Any, styles: Dict[str, Any], RlPara, RlSpacer, RlTable,
             TableStyle, ListFlowable, ListItem, mm) -> List[Any]:
    """把一个 IR 块转成 reportlab flowable 列表。

    形参名故意和 IR 的 ``Paragraph`` / ``Table`` 区分开：模块顶层这两个名字指的是
    IR 节点，isinstance 判断必须用它们，而构造产物要用 reportlab 的同名类。混用会
    把 IR 节点塞进 story，doc.build 报 'has no attribute wrap'。
    """
    if isinstance(block, Heading):
        style = styles.get(block.level, styles[3])
        return [RlSpacer(1, 2 * mm), RlPara(_rl_esc(block.text), style)]
    if isinstance(block, Paragraph):
        return [RlPara(_rl_esc(block.text), styles["body"])]
    if isinstance(block, Bullets):
        items = [ListItem(RlPara(_rl_esc(i), styles["body"])) for i in block.items]
        if not items:
            return []
        return [ListFlowable(items,
                             bulletType="1" if block.ordered else "bullet",
                             leftIndent=12)]
    if isinstance(block, Table):
        if not block.header and not block.rows:
            return []
        data = [[_rl_esc(c) for c in block.header]] if block.header else []
        data += [[_rl_esc(c) for c in row] for row in block.rows]
        return [_rl_table(data, RlTable, TableStyle, mm), RlSpacer(1, 3 * mm)]
    if isinstance(block, MetricGrid):
        data = [[_rl_esc(k), _rl_esc(v)] for k, v in block.items]
        if not data:
            return []
        tbl = RlTable(data, colWidths=[70 * mm, None])
        tbl.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), CID_BASE),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LINEBELOW", (0, 0), (-1, -2), 0.3, HAIRLINE),
        ]))
        return [tbl, RlSpacer(1, 3 * mm)]
    if isinstance(block, CodeBlock):
        body = _rl_esc(block.text).replace("\n", "<br/>")
        return [RlPara(body, styles["code"]), RlSpacer(1, 3 * mm)]
    if isinstance(block, Callout):
        return [RlPara(_rl_esc(block.text), styles["note"]), RlSpacer(1, 2 * mm)]
    return []


def _rl_table(data: List[List[str]], RlTable, TableStyle, mm):
    """带表头底纹和网格的数据表；列宽等分，超长文本由 reportlab 自行换行。

    IR 的行是宽容的（列数不齐、空行都可能出现在这里），reportlab 的 Table 不是，
    所以先把每行补齐到同一列数，缺列补空格。
    """
    cols = max((len(row) for row in data), default=0)
    rows = [(list(row) + [""] * cols)[:cols] for row in data]
    tbl = RlTable(rows, colWidths=[CONTENT_W / cols] * cols)
    tbl.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), CID_BASE),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.4, HAIRLINE),
        ("BACKGROUND", (0, 0), (-1, 0), HEAD_FILL),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return tbl


def render(doc: Any, engine: str = "auto") -> bytes:
    """渲染 PDF 字节；doc 可为 ReportDocument、ResearchReport 或其 dict。"""
    name = resolve_engine(engine)
    document = _coerce(doc)
    if name == "stdlib":
        blob = _render_stdlib(document)
        _validate_stdlib(blob)      # 自研写入器要自检到内容流一级
    else:
        blob = _render_reportlab(document)
        _validate(blob)             # reportlab 的产物结构由它自己负责
    return blob


def render_to_file(doc: Any, path: Any, engine: str = "auto") -> str:
    """落盘，返回写入的绝对路径。"""
    blob = render(doc, engine)
    target = os.path.abspath(str(path))
    parent = os.path.dirname(target)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    with open(target, "wb") as fh:
        fh.write(blob)
    LOG.debug("pdf 已写出 %s（%d 字节）", target, len(blob))
    return target


__all__ = ["FORMAT", "MEDIA_TYPE", "DEFAULT_FILENAME", "ExportError",
           "engines", "resolve_engine", "render", "render_to_file"]
