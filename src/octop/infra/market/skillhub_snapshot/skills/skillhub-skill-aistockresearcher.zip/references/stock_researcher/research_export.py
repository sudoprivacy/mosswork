# -*- coding: utf-8 -*-
"""v13.0 报告导出注册表：一个入口把研究报告落成 md / json / docx / pptx / pdf。

三个二进制渲染器（Word / PPT / PDF）都只吃 ``report_ir`` 那棵中间树，这里负责
按格式惰性挑模块、统一错误形状，并如实报告当前环境能出哪些格式。

渲染器全部纯标准库可选依赖：缺 python-docx / python-pptx / reportlab 时自动落回
``stdlib`` 引擎，不联网、不起子进程、不向 stdout 打印。
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from stock_researcher.report_ir import IR_VERSION, ReportDocument, coerce_document

LOG = logging.getLogger("stock_researcher.research_export")

EXPORT_VERSION = "13.0"

# 格式 → (渲染器模块名, 默认文件名)
_BINARY_FORMATS: Dict[str, str] = {
    "docx": "stock_researcher.export_docx",
    "pptx": "stock_researcher.export_pptx",
    "pdf": "stock_researcher.export_pdf",
}
_TEXT_FORMATS = ("markdown", "json", "text")
ALIASES = {
    "word": "docx", "doc": "docx", "writer": "docx",
    "ppt": "pptx", "powerpoint": "pptx", "slides": "pptx",
    "markdown": "markdown", "md": "markdown",
    "json": "json", "text": "text", "txt": "text", "pdf": "pdf",
    "docx": "docx", "pptx": "pptx",
}
ALL_FORMATS = ("markdown", "json", "text", "docx", "pptx", "pdf")


class ExportError(RuntimeError):
    """导出失败：格式未知、渲染器缺失，或渲染器拒绝这份报告。"""


def normalize_format(fmt: str) -> str:
    """把用户写法（word/ppt/md/…）归一到规范格式名；认不出抛 ValueError。"""
    key = str(fmt or "").strip().lower().lstrip(".")
    name = ALIASES.get(key)
    if name is None:
        raise ValueError("未知的导出格式 %r，可选：%s" % (fmt, ", ".join(ALL_FORMATS)))
    return name


def _renderer(fmt: str):
    module_name = _BINARY_FORMATS.get(fmt)
    if module_name is None:
        return None
    try:
        from importlib import import_module
        return import_module(module_name)
    except Exception as exc:  # 渲染器本身坏掉时也要能被上层看见
        LOG.warning("导入渲染器 %s 失败: %s", module_name, exc)
        return None


def available_formats() -> List[str]:
    """当前环境真正能导出的格式；文本类恒可用。"""
    out = [f for f in ALL_FORMATS if f in _TEXT_FORMATS]
    for fmt in ("docx", "pptx", "pdf"):
        if _renderer(fmt) is not None:
            out.append(fmt)
    return out


def engines_for(fmt: str) -> List[str]:
    """列出某个二进制格式在当前环境可用的渲染引擎。"""
    name = normalize_format(fmt)
    mod = _renderer(name)
    if mod is None:
        return []
    return list(mod.engines())


def export_bytes(report: Any, fmt: str = "docx", engine: str = "auto") -> bytes:
    """渲染成字节；只支持 docx/pptx/pdf 三种二进制格式。"""
    name = normalize_format(fmt)
    mod = _renderer(name)
    if mod is None:
        raise ExportError("格式 %s 没有可用的二进制渲染器" % name)
    return mod.render(report, engine)


def render_text(report: Any, fmt: str = "markdown") -> str:
    """渲染成 markdown/json/text 字符串，不落盘。

    CLI 在没有 ``--out`` 时用它把正文打到 stdout；二进制格式走 ``export_bytes``。
    """
    name = normalize_format(fmt)
    if name not in _TEXT_FORMATS:
        raise ExportError("格式 %s 是二进制，请用 export() 或 export_bytes()" % name)
    return _text_payload(report, name)


def _text_payload(report: Any, fmt: str) -> str:
    name = normalize_format(fmt)
    if isinstance(report, ReportDocument):
        if name == "text":
            return report.plain_text()
        # IR 树本身没有 to_json：早先 json 会掉进 _markdown_of 分支，
        # 于是导出 .json 得到的是 Markdown 正文，下游按 JSON 解析直接炸。
        if name == "json":
            return _json_of(report)
        return _markdown_of(report)
    if name == "markdown":
        return _markdown(report)
    if name == "json" and hasattr(report, "to_json"):
        return str(report.to_json())
    if name == "json":
        return _json_of(report)
    return coerce_document(report).plain_text()


def _markdown(report: Any) -> str:
    """Markdown 仍以 research_contracts 的渲染器为准，避免同一份结论出两版正文。"""
    from stock_researcher import research_contracts

    fn = getattr(research_contracts, "report_to_markdown", None)
    if fn is not None and isinstance(report, research_contracts.ResearchReport):
        return str(fn(report))
    return _markdown_of(coerce_document(report))


def _json_of(report: Any) -> str:
    """没有 to_json 时按 IR 树序列化，字段与 Word/PDF 版式同源。"""
    import json

    doc = coerce_document(report)
    return json.dumps({
        "title": doc.title,
        "subtitle": doc.subtitle,
        "meta": dict(doc.meta),
        "ir_version": doc.ir_version,
        "sections": [{"title": s.title,
                      "blocks": [{"type": type(b).__name__,
                                  **getattr(b, "__dict__", {})} for b in s.blocks]}
                     for s in doc.sections],
        "disclaimer": doc.disclaimer,
    }, ensure_ascii=False, indent=2, default=str)


def _markdown_of(doc: ReportDocument) -> str:
    """IR 树反推 Markdown：没有 ResearchReport 上下文时也能给出可读文本。"""
    lines: List[str] = ["# %s" % doc.title, ""]
    if doc.subtitle:
        lines += ["> %s" % doc.subtitle, ""]
    for key, value in doc.meta:
        lines.append("- **%s**：%s" % (key, value))
    if doc.meta:
        lines.append("")
    for section in doc.sections:
        lines += ["## %s" % section.title, ""]
        lines += _block_md(section.blocks)
    if doc.disclaimer:
        lines += ["---", "", "**免责声明**", "", doc.disclaimer, ""]
    return "\n".join(lines)


def _block_md(blocks) -> List[str]:
    from stock_researcher.report_ir import (Bullets, Callout, CodeBlock, Heading,
                                            MetricGrid, Paragraph, Table)
    out: List[str] = []
    for block in blocks:
        if isinstance(block, Heading):
            out += ["%s %s" % ("#" * min(max(block.level, 3), 6), block.text), ""]
        elif isinstance(block, Paragraph):
            out += [block.text, ""]
        elif isinstance(block, Bullets):
            out += ["%s %s" % (("%d." % (i + 1)) if block.ordered else "-", item)
                    for i, item in enumerate(block.items)]
            out.append("")
        elif isinstance(block, Table):
            if block.header:
                out += ["| " + " | ".join(block.header) + " |",
                        "|" + "|".join(["---"] * len(block.header)) + "|"]
            out += ["| " + " | ".join(row) + " |" for row in block.rows]
            out.append("")
        elif isinstance(block, MetricGrid):
            out += ["- **%s**：%s" % (k, v) for k, v in block.items]
            out.append("")
        elif isinstance(block, CodeBlock):
            out += ["```%s" % block.language, block.text, "```", ""]
        elif isinstance(block, Callout):
            out += ["> %s%s" % ("⚠️ " if block.kind == "warning" else "", block.text), ""]
    return out


def export(report: Any, fmt: str = "docx", path: Any = None,
           engine: str = "auto") -> Dict[str, Any]:
    """把报告导出成文件，返回统一结果字典（失败也返回结构，不抛异常）。

    Args:
        report: ResearchReport、其 dict，或已建好的 ReportDocument。
        fmt: markdown/json/text/docx/pptx/pdf，接受 word/ppt/md 等别名。
        path: 目标路径；省略时用该格式的默认文件名落在当前目录。
        engine: stdlib / python-docx / python-pptx / reportlab / auto。
    """
    result: Dict[str, Any] = {"success": False, "format": "", "engine": engine,
                              "path": "", "bytes": 0, "error": ""}
    try:
        name = normalize_format(fmt)
    except ValueError as exc:
        result["error"] = str(exc)
        return result
    result["format"] = name
    try:
        if name in _TEXT_FORMATS:
            payload = _text_payload(report, name)
            target = _resolve_path(path, name)
            # 写二进制而不是 write_text：文本模式在 Windows 上会把 \n 翻成 \r\n，
            # 于是同一份报告在不同平台字节不同，返回的 bytes 也和落盘大小不符。
            target.write_bytes(payload.encode("utf-8"))
            result.update(success=True, path=str(target),
                          bytes=target.stat().st_size)
            return result
        mod = _renderer(name)
        if mod is None:
            result["error"] = "格式 %s 的渲染器不可用" % name
            return result
        target = _resolve_path(path, name)
        written = mod.render_to_file(report, target, engine)
        result.update(success=True, path=str(Path(written).resolve()),
                      bytes=Path(written).stat().st_size,
                      engine=mod.resolve_engine(engine))
        return result
    except Exception as exc:
        result["error"] = "%s: %s" % (type(exc).__name__, str(exc)[:240])
        LOG.debug("导出 %s 失败: %s", name, exc)
        return result


_SUFFIX = {"markdown": ".md", "json": ".json", "text": ".txt",
           "docx": ".docx", "pptx": ".pptx", "pdf": ".pdf"}


def _resolve_path(path: Any, fmt: str) -> Path:
    """补齐扩展名并创建父目录；path 为空时用该格式的默认文件名。"""
    if path is None or str(path).strip() == "":
        return Path.cwd() / ("report" + _SUFFIX[fmt])
    target = Path(str(path)).expanduser()
    if target.is_dir():
        target = target / ("report" + _SUFFIX[fmt])
    elif target.suffix.lower() != _SUFFIX[fmt]:
        target = target.with_suffix(_SUFFIX[fmt])
    if target.parent and not target.parent.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
    return target


def self_check() -> Dict[str, Any]:
    """导出层自检：报告哪些格式现在就能出，缺什么。"""
    from stock_researcher import report_ir

    return {
        "version": "v" + EXPORT_VERSION,
        "ir_version": report_ir.IR_VERSION,
        "formats": list(ALL_FORMATS),
        "available": available_formats(),
        "engines": {fmt: engines_for(fmt) for fmt in ("docx", "pptx", "pdf")},
        "text_formats": list(_TEXT_FORMATS),
        "features": [
            "格式无关 IR 树（Word/PPT/PDF/Markdown 同源）",
            "纯标准库 OOXML 与 PDF 渲染器（零 pip 依赖）",
            "python-docx / python-pptx / reportlab 可选增强",
            "字节级可复现：固定 zip 时间戳与 PDF /ID",
        ],
    }


__all__ = ["EXPORT_VERSION", "ALL_FORMATS", "ExportError", "normalize_format",
           "available_formats", "engines_for", "export", "export_bytes",
           "render_text", "self_check"]
