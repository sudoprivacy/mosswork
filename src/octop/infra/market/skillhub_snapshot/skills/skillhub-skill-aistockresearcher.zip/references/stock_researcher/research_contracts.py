﻿# -*- coding: utf-8 -*-
"""v12.0 Research Intelligence Hub — 统一数据契约。

每条事实带 as_of / source / quality；分析结论可回溯到证据。
纯标准库；缺数据、估算值、过期值不会伪装成实际值。
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

SCHEMA_VERSION = "12.0"
DISCLAIMER = (
    "本报告仅用于研究与教育，不构成个性化投资建议、交易指令或收益保证。"
    "概率、区间与情景均为条件估计，会随数据更新而变化；历史表现不代表未来。"
)
CN_TZ = timezone(timedelta(hours=8))


def now_iso() -> str:
    return datetime.now(CN_TZ).isoformat(timespec="seconds")


def to_iso(value: Any = None) -> str:
    if value is None or value == "":
        return now_iso()
    if isinstance(value, datetime):
        dt = value
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=CN_TZ)
        return dt.astimezone(CN_TZ).isoformat(timespec="seconds")
    if isinstance(value, (int, float)):
        try:
            return datetime.fromtimestamp(float(value), CN_TZ).isoformat(timespec="seconds")
        except (ValueError, OSError):
            return now_iso()
    text = str(value).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
                "%Y/%m/%d %H:%M:%S", "%Y/%m/%d", "%Y%m%d",
                "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M"):
        try:
            dt = datetime.strptime(text, fmt).replace(tzinfo=CN_TZ)
            return dt.isoformat(timespec="seconds")
        except ValueError:
            continue
    return text


def parse_datetime(value: Any) -> Optional[datetime]:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=CN_TZ)
    if isinstance(value, (int, float)):
        try:
            return datetime.fromtimestamp(float(value), CN_TZ)
        except (ValueError, OSError):
            return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
        return dt if dt.tzinfo else dt.replace(tzinfo=CN_TZ)
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
                "%Y/%m/%d %H:%M:%S", "%Y/%m/%d", "%Y%m%d", "%H:%M:%S"):
        try:
            dt = datetime.strptime(text, fmt)
            if fmt == "%H:%M:%S":
                dt = datetime.combine(datetime.now(CN_TZ).date(), dt.time())
            return dt.replace(tzinfo=CN_TZ)
        except ValueError:
            continue
    return None

def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def safe_float(value: Any, default: Optional[float] = 0.0) -> Optional[float]:
    if value is None or value == "":
        return default
    try:
        out = float(str(value).replace(",", "").replace("%", "").strip())
        if math.isnan(out) or math.isinf(out):
            return default
        return out
    except (TypeError, ValueError):
        return default


def finite(values: Iterable[Any]) -> List[float]:
    out: List[float] = []
    for v in values:
        f = safe_float(v, None)
        if f is not None:
            out.append(float(f))
    return out


def pct(numerator: float, denominator: float, default: float = 0.0) -> float:
    if denominator is None or abs(denominator) < 1e-12:
        return default
    return numerator / denominator * 100.0


def percentile(values: List[float], q: float) -> Optional[float]:
    vals = sorted(float(v) for v in values if v is not None and math.isfinite(float(v)))
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    q = clamp(q, 0.0, 100.0) / 100.0
    pos = (len(vals) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return vals[lo]
    weight = pos - lo
    return vals[lo] * (1 - weight) + vals[hi] * weight


def stable_hash(*parts: Any, length: int = 16) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update(str(p).encode("utf-8", errors="replace"))
        h.update(b"\x1f")
    return h.hexdigest()[:length]


def make_run_id(prefix: str = "run") -> str:
    stamp = datetime.now(CN_TZ).strftime("%Y%m%dT%H%M%S")
    return f"{prefix}-{stamp}-{stable_hash(now_iso(), length=6)}"


def _fmt_pct(value: Any, digits: int = 2) -> str:
    v = safe_float(value, None)
    return "—" if v is None else f"{v:+.{digits}f}%"


def _fmt_num(value: Any, digits: int = 2) -> str:
    v = safe_float(value, None)
    return "—" if v is None else f"{v:.{digits}f}"

@dataclass
class Evidence:
    """一条可审计证据。"""
    evidence_id: str
    kind: str
    title: str
    value: str
    source: str = ""
    observed_at: str = ""
    published_at: str = ""
    url: str = ""
    quality: str = "actual"
    reliability: str = "medium"
    locator: str = ""
    snippet: str = ""
    content_hash: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class EvidenceLedger:
    """证据账本：去重、编号、可追溯。"""

    def __init__(self) -> None:
        self._items: List[Evidence] = []
        self._keys: Dict[str, str] = {}

    def add(self, kind: str, title: str, value: Any, source: str = "",
            quality: str = "actual", reliability: str = "medium",
            observed_at: Optional[str] = None, published_at: str = "",
            url: str = "", locator: str = "", snippet: str = "",
            metadata: Optional[Dict[str, Any]] = None) -> str:
        value_text = str(value)
        key = stable_hash(kind, title, value_text, source, locator)
        if key in self._keys:
            return self._keys[key]
        eid = f"E{len(self._items) + 1:04d}"
        item = Evidence(
            evidence_id=eid, kind=kind, title=title, value=value_text,
            source=source or "unknown",
            # 没给观测时间就留空：用"当前时间"顶替会让读者以为证据是刚采集的。
            observed_at=to_iso(observed_at) if observed_at else "",
            published_at=to_iso(published_at) if published_at else "",
            url=url, quality=quality, reliability=reliability,
            locator=locator, snippet=(snippet or value_text)[:280],
            content_hash=stable_hash(value_text, length=32),
            metadata=metadata or {},
        )
        self._items.append(item)
        self._keys[key] = eid
        return eid

    def get(self, evidence_id: str) -> Optional[Evidence]:
        for item in self._items:
            if item.evidence_id == evidence_id:
                return item
        return None

    def all(self) -> List[Evidence]:
        return list(self._items)

    def by_ids(self, ids: Iterable[str]) -> List[Evidence]:
        wanted = set(ids)
        return [x for x in self._items if x.evidence_id in wanted]

    def to_list(self) -> List[Dict[str, Any]]:
        return [x.to_dict() for x in self._items]

    def __len__(self) -> int:
        return len(self._items)


@dataclass
class DataQualityReport:
    status: str = "insufficient"
    score: float = 0.0
    completeness: float = 0.0
    freshness: str = "unknown"
    sources: List[str] = field(default_factory=list)
    missing: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    field_quality: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class MarketQuote:
    symbol: str
    name: str = ""
    asset_type: str = "stock"
    market: str = "cn"
    price: Optional[float] = None
    prev_close: Optional[float] = None
    open: Optional[float] = None
    high: Optional[float] = None
    low: Optional[float] = None
    volume: Optional[float] = None
    amount: Optional[float] = None
    change_pct: Optional[float] = None
    timestamp: str = ""
    source: str = ""
    freshness: str = "unknown"
    quality: str = "unavailable"
    warnings: List[str] = field(default_factory=list)
    raw: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for attr in ("price", "prev_close", "open", "high", "low",
                     "volume", "amount", "change_pct"):
            setattr(self, attr, safe_float(getattr(self, attr), None))
        if self.change_pct is None and self.price and self.prev_close:
            self.change_pct = pct(self.price - self.prev_close, self.prev_close)
        if self.price and self.price > 0 and self.quality == "unavailable":
            self.quality = "actual"

    @property
    def valid(self) -> bool:
        return bool(self.price and self.price > 0)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PriceSeries:
    symbol: str
    asset_type: str = "stock"
    market: str = "cn"
    dates: List[str] = field(default_factory=list)
    opens: List[float] = field(default_factory=list)
    highs: List[float] = field(default_factory=list)
    lows: List[float] = field(default_factory=list)
    closes: List[float] = field(default_factory=list)
    volumes: List[float] = field(default_factory=list)
    amounts: List[float] = field(default_factory=list)
    source: str = ""
    quality: str = "actual"
    as_of: str = ""
    warnings: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.closes = finite(self.closes)
        n = len(self.closes)

        def _align(seq: List[Any], label: str) -> List[float]:
            raw = list(seq or [])
            vals = finite(raw)
            if raw and len(raw) != n:
                self.warnings.append(f"{label}长度不一致（对比收盘价），已按尾部对齐/补零")
            if len(vals) == n:
                return vals
            if len(vals) > n:
                return vals[-n:]
            return vals + [0.0] * (n - len(vals)) if n else []

        self.opens = _align(self.opens, "开盘价")
        self.highs = _align(self.highs, "最高价")
        self.lows = _align(self.lows, "最低价")
        self.volumes = _align(self.volumes, "成交量")
        self.amounts = _align(self.amounts, "成交额")
        if self.dates and len(self.dates) != n:
            self.warnings.append("日期与价格长度不一致，已按尾部对齐")
            if len(self.dates) > n:
                self.dates = list(self.dates[-n:])
            else:
                self.dates = list(self.dates) + [""] * (n - len(self.dates))
        if not self.as_of:
            self.as_of = self.dates[-1] if self.dates else now_iso()

    @property
    def last(self) -> Optional[float]:
        return self.closes[-1] if self.closes else None

    @property
    def usable(self) -> bool:
        tail = self.closes[-min(len(self.closes), 10):]
        return len(self.closes) >= 2 and all(x > 0 for x in tail)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class FundSnapshot:
    code: str
    name: str = ""
    official_nav: Optional[float] = None
    nav_date: str = ""
    estimated_nav: Optional[float] = None
    estimate_pct: Optional[float] = None
    estimate_time: str = ""
    market_price: Optional[float] = None
    iopv: Optional[float] = None
    premium_pct: Optional[float] = None
    fund_type: str = ""
    source: str = ""
    quality: str = "unavailable"
    warnings: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        for attr in ("official_nav", "estimated_nav", "estimate_pct",
                     "market_price", "iopv", "premium_pct"):
            setattr(self, attr, safe_float(getattr(self, attr), None))
        if self.premium_pct is None and self.market_price and self.iopv:
            self.premium_pct = pct(self.market_price - self.iopv, self.iopv)
        has_price = bool(self.official_nav or self.estimated_nav or self.market_price)
        if self.quality == "unavailable" and has_price:
            self.quality = "estimated" if self.estimated_nav and not self.market_price else "actual"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class FuturesContract:
    contract: str
    product: str = ""
    exchange: str = ""
    price: Optional[float] = None
    prev_close: Optional[float] = None
    settlement: Optional[float] = None
    open_interest: Optional[float] = None
    volume: Optional[float] = None
    days_to_expiry: Optional[int] = None
    is_main: bool = False
    timestamp: str = ""
    source: str = ""
    quality: str = "unavailable"
    warnings: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        for attr in ("price", "prev_close", "settlement", "open_interest", "volume"):
            setattr(self, attr, safe_float(getattr(self, attr), None))
        if self.days_to_expiry is not None:
            try:
                self.days_to_expiry = int(self.days_to_expiry)
            except (TypeError, ValueError):
                self.days_to_expiry = None
        if self.quality == "unavailable" and self.price:
            self.quality = "actual"

    @property
    def valid(self) -> bool:
        return bool(self.price and self.price > 0)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class FuturesCurve:
    product: str
    as_of: str = ""
    contracts: List[FuturesContract] = field(default_factory=list)
    spot_price: Optional[float] = None
    source: str = ""
    quality: str = "unavailable"
    warnings: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.spot_price = safe_float(self.spot_price, None)
        self.contracts = sorted(
            [c for c in self.contracts if c and c.valid],
            key=lambda c: (c.days_to_expiry if c.days_to_expiry is not None else 99999,
                           c.contract),
        )
        if not self.as_of:
            self.as_of = now_iso()
        if self.contracts and self.quality == "unavailable":
            self.quality = "actual"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class NewsItem:
    title: str
    summary: str = ""
    published_at: str = ""
    source: str = "unknown"
    url: str = ""
    reliability: str = "medium"
    event_type: str = "other"
    direction: str = "neutral"
    strength: float = 0.0
    materiality: float = 0.0
    confidence: float = 0.0
    evidence_span: str = ""
    dedupe_key: str = ""
    related_symbols: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Factor:
    name: str
    category: str
    score: float
    weight: float = 1.0
    confidence: float = 0.5
    rationale: str = ""
    evidence_ids: List[str] = field(default_factory=list)
    quality: str = "actual"

    def __post_init__(self) -> None:
        score = safe_float(self.score, None)
        weight = safe_float(self.weight, None)
        confidence = safe_float(self.confidence, None)
        self.score = clamp(0.0 if score is None else score, -100.0, 100.0)
        self.weight = max(0.0, 1.0 if weight is None else weight)
        self.confidence = clamp(0.5 if confidence is None else confidence, 0.0, 1.0)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ForecastDistribution:
    horizon: str
    horizon_days: int
    direction: str = "neutral"
    probability_up: float = 0.5
    probability_down: float = 0.5
    probability_flat: float = 0.0
    median_return_pct: float = 0.0
    mean_return_pct: float = 0.0
    quantiles: Dict[str, float] = field(default_factory=dict)
    confidence: float = 0.0
    sample_size: int = 0
    effective_sample_size: float = 0.0
    method: str = "empirical_knn"
    brier_score: Optional[float] = None
    baseline_brier: Optional[float] = None
    skill_score: Optional[float] = None
    quality: str = "estimated"
    abstain: bool = False
    warnings: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        up = safe_float(self.probability_up, None)
        down = safe_float(self.probability_down, None)
        flat = safe_float(self.probability_flat, None)
        self.probability_up = clamp(0.5 if up is None else up, 0.0, 1.0)
        self.probability_down = clamp(0.5 if down is None else down, 0.0, 1.0)
        self.probability_flat = clamp(0.0 if flat is None else flat, 0.0, 1.0)
        total = self.probability_up + self.probability_down + self.probability_flat
        if total > 0:
            self.probability_up = round(self.probability_up / total, 4)
            self.probability_down = round(self.probability_down / total, 4)
            self.probability_flat = round(max(0.0, 1.0 - self.probability_up - self.probability_down), 4)
        self.confidence = clamp(safe_float(self.confidence, 0.0) or 0.0, 0.0, 1.0)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class AssetAnalysis:
    symbol: str
    asset_type: str
    market: str = "cn"
    name: str = ""
    as_of: str = ""
    price: Optional[float] = None
    score: float = 0.0
    direction: str = "neutral"
    confidence: float = 0.0
    factors: List[Factor] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    evidence_ids: List[str] = field(default_factory=list)
    conflicts: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    quality: str = "insufficient"
    specialized: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Scenario:
    name: str
    probability: float
    return_pct: float
    price_range: Tuple[float, float] = (0.0, 0.0)
    assumptions: List[str] = field(default_factory=list)
    triggers: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ResearchReport:
    schema_version: str
    run_id: str
    generated_at: str
    symbol: str
    asset_type: str
    name: str = ""
    question: str = ""
    as_of: str = ""
    data_cutoff: str = ""
    executive_summary: str = ""
    direction: str = "neutral"
    confidence: float = 0.0
    score: float = 0.0
    asset_analysis: Optional[AssetAnalysis] = None
    forecasts: List[ForecastDistribution] = field(default_factory=list)
    scenarios: List[Scenario] = field(default_factory=list)
    data_quality: DataQualityReport = field(default_factory=DataQualityReport)
    evidence: List[Evidence] = field(default_factory=list)
    news_summary: Dict[str, Any] = field(default_factory=dict)
    conclusions: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)
    counterpoints: List[str] = field(default_factory=list)
    methodology: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    disclaimer: str = DISCLAIMER

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "run_id": self.run_id,
            "generated_at": self.generated_at,
            "symbol": self.symbol,
            "asset_type": self.asset_type,
            "name": self.name,
            "question": self.question,
            "as_of": self.as_of,
            "data_cutoff": self.data_cutoff,
            "executive_summary": self.executive_summary,
            "direction": self.direction,
            "confidence": self.confidence,
            "score": self.score,
            "asset_analysis": self.asset_analysis.to_dict() if self.asset_analysis else None,
            "forecasts": [x.to_dict() for x in self.forecasts],
            "scenarios": [x.to_dict() for x in self.scenarios],
            "data_quality": self.data_quality.to_dict(),
            "evidence": [x.to_dict() for x in self.evidence],
            "news_summary": self.news_summary,
            "conclusions": self.conclusions,
            "risks": self.risks,
            "counterpoints": self.counterpoints,
            "methodology": self.methodology,
            "warnings": self.warnings,
            "disclaimer": self.disclaimer,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent, default=str)

def report_to_markdown(report: ResearchReport) -> str:
    """把结构化报告渲染为可审计的中文 Markdown。"""
    aa = report.asset_analysis
    lines: List[str] = []
    lines.append(f"# {report.name or report.symbol} 研究简报")
    lines.append("")
    lines.append(f"- 标的：`{report.symbol}`（{report.asset_type}）")
    lines.append(f"- 生成时间：{report.generated_at}")
    lines.append(f"- 数据截止：{report.data_cutoff or report.as_of}")
    lines.append(f"- 综合方向：**{report.direction}**｜置信度 {report.confidence:.0%}｜评分 {report.score:+.1f}/100")
    lines.append("")
    lines.append("## 一、结论摘要")
    lines.append(report.executive_summary or "数据不足，暂不形成方向性结论。")
    lines.append("")
    if report.conclusions:
        lines.append("### 核心结论")
        for item in report.conclusions:
            lines.append(f"- {item}")
        lines.append("")

    lines.append("## 二、多周期概率预测")
    if report.forecasts:
        lines.append("| 周期 | 方向 | 上涨概率 | 震荡概率 | 下跌概率 | 中位收益 | 90%区间 | 置信度 | 质量 |")
        lines.append("|---|---|---:|---:|---:|---:|---|---:|---|")
        for f in report.forecasts:
            q05 = f.quantiles.get("p05")
            q95 = f.quantiles.get("p95")
            interval = f"{_fmt_pct(q05)} ~ {_fmt_pct(q95)}" if q05 is not None and q95 is not None else "—"
            if f.abstain:
                # 弃权行不打印分布数值：读者会把默认 50/45 当成模型结论。
                lines.append(
                    f"| {f.horizon} | 弃权 | — | — | — | — | — | "
                    f"{f.confidence:.0%} | {f.quality} |"
                )
                continue
            lines.append(
                f"| {f.horizon} | {f.direction} | {f.probability_up:.0%} | "
                f"{f.probability_flat:.0%} | {f.probability_down:.0%} | "
                f"{_fmt_pct(f.median_return_pct)} | {interval} | {f.confidence:.0%} | {f.quality} |"
            )
        lines.append("")
        lines.append("> 概率来自历史条件样本的非参数估计；样本不足或校准不佳时会标记弃权，不强行给方向。")
        lines.append("")
    else:
        lines.append("数据不足，未生成概率预测。")
        lines.append("")

    lines.append("## 三、因子与证据")
    if aa and aa.factors:
        lines.append("| 因子 | 类别 | 方向分 | 权重 | 置信度 | 证据 | 说明 |")
        lines.append("|---|---|---:|---:|---:|---|---|")
        for f in aa.factors:
            lines.append(
                f"| {f.name} | {f.category} | {f.score:+.1f} | {f.weight:.2f} | "
                f"{f.confidence:.0%} | {', '.join(f.evidence_ids) or '—'} | {f.rationale} |"
            )
        lines.append("")
    if aa and aa.metrics:
        lines.append("### 关键指标")
        lines.append("```json")
        lines.append(json.dumps(aa.metrics, ensure_ascii=False, indent=2, default=str))
        lines.append("```")
        lines.append("")
    lines.append("## 四、情景分析")
    if report.scenarios:
        lines.append("| 情景 | 概率 | 收益假设 | 价格区间 | 主要假设 |")
        lines.append("|---|---:|---:|---|---|")
        for s in report.scenarios:
            low, high = s.price_range
            rng = f"{low:.2f} ~ {high:.2f}" if high else "—"
            assumptions = "；".join(s.assumptions)
            lines.append(f"| {s.name} | {s.probability:.0%} | {_fmt_pct(s.return_pct)} | {rng} | {assumptions} |")
        lines.append("")
    else:
        lines.append("未生成情景分析。")
        lines.append("")

    lines.append("## 五、风险、反方证据与数据质量")
    if report.risks:
        lines.append("### 主要风险")
        for risk in report.risks:
            lines.append(f"- {risk}")
        lines.append("")
    if report.counterpoints:
        lines.append("### 反方证据 / 冲突")
        for item in report.counterpoints:
            lines.append(f"- {item}")
        lines.append("")
    dq = report.data_quality
    lines.append(f"- 数据状态：{dq.status}｜完整度 {dq.completeness:.0%}｜质量分 {dq.score:.0%}｜时效 {dq.freshness}")
    if dq.sources:
        lines.append(f"- 数据来源：{', '.join(dq.sources)}")
    if dq.missing:
        lines.append(f"- 缺失项：{', '.join(dq.missing)}")
    for warning in dq.warnings + report.warnings:
        lines.append(f"- ⚠️ {warning}")
    lines.append("")

    lines.append("## 六、证据链")
    if report.evidence:
        lines.append("| ID | 类型 | 来源 | 观测时间 | 质量 | 证据 |")
        lines.append("|---|---|---|---|---|---|")
        for e in report.evidence:
            val = e.value.replace("|", "\\|")[:160]
            seen = e.observed_at or "—"
            lines.append(f"| {e.evidence_id} | {e.kind} | {e.source} | {seen} | {e.quality} | {val} |")
        lines.append("")
    else:
        lines.append("无可用证据。")
        lines.append("")

    lines.append("## 七、方法与限制")
    for method in report.methodology:
        lines.append(f"- {method}")
    lines.append("")
    lines.append("---")
    lines.append("## 免责声明")
    lines.append(f"> {report.disclaimer}")
    return "\n".join(lines)
