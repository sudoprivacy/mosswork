# -*- coding: utf-8 -*-
"""v13.0 幻灯片（.pptx）导出器。

主引擎 ``stdlib``：只用 zipfile + 标准库拼 DrawingML/OOXML 包，零第三方依赖、字节级
确定性，市场沙箱里必定可用。副引擎 ``python-pptx`` 仅在能导入时按需启用，两者共用同
一份分页后的"幻灯片计划"（``_plan``），字号、分页、表头重复语义一致。

版面取向：标题页 → 每章节至少一页（溢出则分页并重复表头）→ 免责声明页。
不联网、不写 stdout（本包跑在 MCP stdio 上，杂输出会破坏 JSON-RPC 帧）。
"""
from __future__ import annotations

import io
import math
import re
import zipfile
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from stock_researcher.report_ir import (
    Bullets, Callout, CodeBlock, Heading, MetricGrid, Paragraph,
    ReportDocument, Table, build_document,
)

FORMAT = "pptx"
MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
DEFAULT_FILENAME = "report.pptx"

EMU_PT, SLIDE_CX, SLIDE_CY = 12700, 12192000, 6858000     # 16:9
MARGIN_X, TITLE_Y, TITLE_H = 457200, 274320, 640080
BODY_TOP, BODY_BOTTOM, GAP = 1005840, SLIDE_CY - 320000, 91440
CONTENT_W = SLIDE_CX - 2 * MARGIN_X
CONTENT_H = BODY_BOTTOM - BODY_TOP                        # 单页正文高度预算
EA_FONT, LATIN, MONO = "微软雅黑", "Calibri", "Consolas"
INK, HEAD_BG, HEAD_FG, ALT_BG = "333333", "1F4E79", "FFFFFF", "F7F9FC"
TBL_STYLE = "{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"      # PPT 内建"中等样式 2 - 强调 1"
ZIP_STAMP = (2020, 1, 1, 0, 0, 0)                         # 固定时间戳 → 字节可复现
RT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
CTB = "application/vnd.openxmlformats-officedocument"
NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main"
# graphicData 的 uri 必须精确到 /2006/table：写成 main/table 时 PowerPoint
# 与 python-pptx 都不认这是表格（图形被静默丢弃），LibreOffice 却照样渲染
NS_TBL = "http://schemas.openxmlformats.org/drawingml/2006/table"
HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
# 样式名 → (起始字号, 加粗, 字色, 底色)
_STYLES = {"h2": (20, True, "1F3864", ""), "h3": (17, True, "2E5496", ""),
           "lead": (17, False, "404040", ""), "body": (15, False, INK, ""),
           "bullet": (15, False, INK, ""), "note": (12, False, "595959", ""),
           "code": (11, False, "24292E", "F5F5F5"), "warn": (13, True, "9C0006", "FDECEC"),
           "callout": (13, False, "1F3864", "EEF3FA"), "meta": (13, False, "595959", "")}
_TEXT_STEPS = (18, 16, 14, 12, 11)     # 正文字号阶梯：先缩字号，再分页，不裁内容
_TABLE_STEPS = (12, 11, 10, 9, 8)
# 子元素顺序按 CT_ 模式写死，错一处 PowerPoint 就弹"需要修复"
_TREE0 = ('<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
          '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
          '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>')
_TX = ('<a:lvl1pPr marL="0" indent="0"><a:defRPr sz="%d" b="%d"><a:solidFill>'
       '<a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="' + LATIN + '"/>'
       '<a:ea typeface="' + EA_FONT + '"/><a:cs typeface="' + LATIN + '"/></a:defRPr>'
       '</a:lvl1pPr>')


class ExportError(RuntimeError):
    """PPTX 导出失败：引擎不可用 / 文档无法归一 / 渲染异常。"""


# ---------------------------------------------------------------- 公共 API

def engines() -> List[str]:
    """可用引擎列表；stdlib 恒在，python-pptx 仅在可导入时追加。"""
    return ["stdlib"] + (["python-pptx"] if _pptx_available() else [])

def _pptx_available() -> bool:
    try:
        import pptx  # noqa: F401
        return True
    except Exception:
        return False

def resolve_engine(engine: str = "auto") -> str:
    """归一引擎名。auto 走 stdlib（零依赖 + 字节确定），增强引擎需显式指定。"""
    name = str(engine or "auto").strip().lower().replace("_", "-")
    if name in ("auto", "stdlib", "std", "zip", "default"):
        return "stdlib"
    if name in ("python-pptx", "python_pptx", "pptx-lib", "pptx"):
        if not _pptx_available():
            raise ExportError("python-pptx 未安装，请改用 engine='stdlib'")
        return "python-pptx"
    raise ExportError(f"未知的 PPTX 引擎：{engine!r}，可选：{engines()}")

def render(doc: Any, engine: str = "auto") -> bytes:
    """把 IR 文档（或 ResearchReport / 其 dict / 带 to_dict() 的对象）渲染成 .pptx 字节。"""
    plan = _plan(_as_document(doc))
    if resolve_engine(engine) == "python-pptx":
        try:
            return _render_pptx(plan)
        except ExportError:
            raise
        except Exception as exc:
            raise ExportError(f"python-pptx 渲染失败：{exc}") from exc
    return _render_stdlib(plan)

def render_to_file(doc: Any, path: Any, engine: str = "auto") -> str:
    """渲染并落盘，返回写入路径字符串。"""
    target = str(path or DEFAULT_FILENAME)
    with open(target, "wb") as fh:
        fh.write(render(doc, engine=engine))
    return target

def _as_document(doc: Any) -> ReportDocument:
    if isinstance(doc, ReportDocument):
        return doc
    if doc is None:
        raise ExportError("文档为空，无法导出 PPTX")
    try:
        return build_document(doc)
    except Exception as exc:
        raise ExportError(f"无法归一为报告文档：{exc}") from exc


# ---------------------------------------------------------------- 版面估算

_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]|[\U00010000-\U0010ffff]")

def _clean(value: Any) -> str:
    """剥掉 PowerPoint 拒收的控制码位与非 BMP 码位（emoji、扩充汉字）。"""
    return _CTRL.sub("", str("" if value is None else value)).strip()

def _esc(value: Any) -> str:
    return _clean(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def _em(text: str) -> float:
    """粗略排字宽度：CJK/全角按 1 em，拉丁数字按 0.55 em。"""
    return sum(1.0 if ord(c) >= 0x2E80 else 0.55 for c in text)

def _wrap(text: str, width_pt: float, size: int) -> int:
    return max(1, math.ceil(_em(text) / max(1.0, width_pt / max(size, 1))))

def _text_h(text: str, size: int, width_emu: int = CONTENT_W) -> int:
    return int(_wrap(text, width_emu / EMU_PT - 8, size) * size * 1.35 * EMU_PT + 70000)

def _el(style: str, text: str, **kw: Any) -> Dict[str, Any]:
    """文本元素；字号按阶梯回退到单页装得下为止（仍装不下的交给 _split 分页）。"""
    text = _clean(text)
    base, bold, color, fill = _STYLES.get(style, _STYLES["body"])
    size = base
    for cand in [s for s in _TEXT_STEPS if s <= base] or [base]:
        size = cand
        if _text_h(text, cand) <= CONTENT_H:
            break
    return {"t": "text", "text": text, "size": size, "bold": bold, "color": color,
            "fill": kw.get("fill", fill), "bullet": kw.get("bullet", ""),
            "align": kw.get("align", ""), "mono": style == "code", "h": _text_h(text, size)}

def _split(el: Dict[str, Any]) -> List[Dict[str, Any]]:
    """单页装不下的长段落按句子边界切块，内容不丢。"""
    if el["h"] <= CONTENT_H:
        return [el]
    size = el["size"]
    budget = max(4.0, (CONTENT_W / EMU_PT) / size) * max(
        1, int((CONTENT_H - 70000) / (size * 1.35 * EMU_PT)))
    text, out = el["text"], []
    while text:
        cut = _cut(text, budget)
        out.append(dict(el, text=text[:cut], h=_text_h(text[:cut], size)))
        text = text[cut:]
    return out

def _cut(text: str, budget: float) -> int:
    acc, pos = 0.0, len(text)
    for i, ch in enumerate(text, 1):
        acc += 1.0 if ord(ch) >= 0x2E80 else 0.55
        if acc >= budget:
            pos = i
            break
    for sep in ("。", "！", "？", "；", "，", " ", "、"):    # 优先在标点处断开
        k = text.rfind(sep, max(0, pos // 2), pos)
        if k >= 0:
            return k + 1
    return pos


# ---------------------------------------------------------------- 块 → 元素

def _metric_rows(grid: MetricGrid) -> List[List[str]]:
    return [[_clean(k), _clean(v)] for k, v in (grid.items or [])]

def _callout_el(block: Callout) -> Dict[str, Any]:
    warn = (block.kind or "note") == "warning"
    return _el("warn" if warn else "callout",
               ("风险提示：" if warn else "说明：") + _clean(block.text))

_BLOCKS: Tuple[Tuple[type, Any], ...] = (
    (Heading, lambda b: [_el("h2" if (b.level or 2) <= 2 else "h3", b.text)]),
    (Paragraph, lambda b: [_el({"lead": "lead", "note": "note"}.get(b.style, "body"), b.text)]),
    (Bullets, lambda b: [_el("bullet", i, bullet="num" if b.ordered else "char")
                         for i in (b.items or [])]),
    (Table, lambda b: _table_els(b)),
    (MetricGrid, lambda b: [_table_el(["指标", "数值"], _metric_rows(b), ["left", "left"])]),
    (CodeBlock, lambda b: [_el("code", line) for line in
                           (str(b.text or "").splitlines() or [""])]),
    (Callout, lambda b: [_callout_el(b)]),
)

def _block_els(block: Any) -> List[Dict[str, Any]]:
    for cls, fn in _BLOCKS:
        if isinstance(block, cls):
            return [x for x in fn(block) if x["t"] == "table" or x["text"]]
    if block is None:
        return []
    return [_el("body", getattr(block, "text", None) or block)]    # 未知块降级成文字

def _table_els(block: Table) -> List[Dict[str, Any]]:
    """幻灯片用 narrow() 窄版；裁剪到空则回退全列——宁可挤，不可丢。"""
    header, rows, align = block.narrow()
    if not header:
        header, rows, align = list(block.header), list(block.rows), list(block.align)
    out = [_el("note", block.caption)] if _clean(block.caption) else []
    if header:
        out.append(_table_el(header, rows, align))
    elif rows:
        out.extend(_el("body", "｜".join(_clean(c) for c in row)) for row in rows)
    return out

def _table_el(header: Sequence[str], rows: Sequence[Sequence[str]],
              align: Sequence[str]) -> Dict[str, Any]:
    """列宽按各列最长内容加权；字号缩到每格 3 行内为止，再靠分页兜底。"""
    n = max(1, len(header))
    head = [_clean(h) for h in header]
    cells = [[_clean(c) for c in (list(r) + [""] * n)[:n]] for r in rows]
    weights = [min(15.0, max(2.5, max([_em(c[i]) for c in cells] + [_em(head[i])]) / 3.0))
               for i in range(n)]
    widths = [int(CONTENT_W * w / (sum(weights) or 1.0)) for w in weights]
    widths[-1] += CONTENT_W - sum(widths)              # 取整误差补给末列
    widths = [max(365760, w) for w in widths]
    size = _TABLE_STEPS[-1]
    for cand in _TABLE_STEPS:
        size = cand
        if all(_wrap(c, w / EMU_PT - 14, cand) <= 3
               for row in [head] + cells for c, w in zip(row, widths)):
            break
    row_h = [_row_h(c, widths, size) for c in cells]
    hh = _row_h(head, widths, size, True)
    return {"t": "table", "header": head, "rows": cells, "align": list(align), "size": size,
            "widths": widths, "hh": hh, "row_h": row_h, "h": hh + sum(row_h)}

def _row_h(cells: Sequence[str], widths: List[int], size: int, header: bool = False) -> int:
    lines = max(_wrap(str(c), w / EMU_PT - 14, size) for c, w in zip(cells, widths))
    return int(lines * size * 1.30 * EMU_PT + (73152 if header else 64008))

def _stack(page: Dict[str, Any]) -> List[Tuple[str, int, int, Dict[str, Any]]]:
    """把一页元素排成 (kind, y, cy, el)，两引擎共用同一套几何。"""
    y = 2606040 if page["kind"] == "title" else BODY_TOP
    out: List[Tuple[str, int, int, Dict[str, Any]]] = []
    for el in page["els"]:
        out.append(("table" if el["t"] == "table" else "text", y, el["h"], el))
        y += el["h"] + GAP     # 预算内不该越界；真遇超页也照排，宁挤出版面也不丢研报行
    return out


# ---------------------------------------------------------------- 分页

class _Pager:
    """一个章节按高度预算装页；表格跨页重复表头，绝不丢行。"""

    def __init__(self, pages: List[Dict[str, Any]], title: str) -> None:
        self.pages, self.title = pages, title
        self.page: Dict[str, Any] = {"kind": "body", "title": title, "els": []}
        pages.append(self.page)
        self.used = 0

    def _new(self) -> None:
        self.page = {"kind": "body", "title": self.title + "（续）", "els": []}
        self.pages.append(self.page)
        self.used = 0

    def _push(self, el: Dict[str, Any], h: int) -> None:
        if self.page["els"] and self.used + h > CONTENT_H:
            self._new()
        self.page["els"].append(dict(el, h=h))
        self.used += h + GAP

    def add(self, el: Dict[str, Any]) -> None:
        if el["t"] != "table":
            for piece in _split(el):
                self._push(piece, piece["h"])
            return
        rows, hs, hh = el["rows"], el["row_h"], el["hh"]
        if not rows:
            return self._push(dict(el, rows=[], row_h=[]), hh)
        i = 0
        while i < len(rows):
            if self.used + hh + hs[i] > CONTENT_H:
                self._new()                             # 续页重复表头
            part, phs = [], []
            while i < len(rows) and self.used + hh + sum(phs) + hs[i] <= CONTENT_H:
                part.append(rows[i])
                phs.append(hs[i])
                i += 1
            if not part:                                # 单行比整页高：独占一页也不丢
                part, phs, i = [rows[i]], [hs[i]], i + 1
            self._push(dict(el, rows=part, row_h=phs), hh + sum(phs))

def _caveats(doc: ReportDocument) -> List[str]:
    """末页的数据质量提示：截止时间 + 窄版裁剪说明 + 正文里的 warning 标注。"""
    cutoff = next((str(v) for k, v in (doc.meta or [])
                   if v and ("截止" in str(k) or "时间" in str(k))), "")
    out = [f"数据截止：{_clean(cutoff)}，行情与公告可能已更新，引用前请复核。"] if cutoff else []
    out.append("幻灯片为窄版面，表格列按 narrow_drop 裁剪；完整列请看 Word/PDF 版。")
    out.extend(_clean(b.text) for s in (doc.sections or [])
               for b in (getattr(s, "blocks", None) or [])
               if isinstance(b, Callout) and (b.kind or "note") == "warning")
    return out

def _plan(doc: ReportDocument) -> List[Dict[str, Any]]:
    pages: List[Dict[str, Any]] = []
    page: Dict[str, Any] = {"kind": "title", "title": _clean(doc.title) or "研究报告", "els": []}
    if _clean(doc.subtitle):
        page["els"].append(_el("lead", doc.subtitle, align="ctr"))
    for key, value in (doc.meta or []):                  # meta 作为紧凑行块
        line = "：".join(x for x in (_clean(key), _clean(value)) if x)
        if line:
            page["els"].append(_el("meta", line, align="ctr"))
    pages.append(page)
    for section in (doc.sections or []):
        pager = _Pager(pages, _clean(getattr(section, "title", "")) or "未命名章节")
        for block in (getattr(section, "blocks", None) or []):
            for el in _block_els(block):
                pager.add(el)
        if not pager.page["els"]:
            pager.add(_el("note", "（本节无内容）"))
    pager = _Pager(pages, "免责声明与数据质量")
    pager.add(_el("warn", _clean(doc.disclaimer) or "本文档未附带免责声明文本。"))
    for item in _caveats(doc):
        pager.add(_el("bullet", item, bullet="char"))
    return pages


# ---------------------------------------------------------------- DrawingML 片段

def _para(text: str, size: int, bold: bool = False, color: str = INK, bullet: str = "",
          align: str = "", latin: str = LATIN, gap: int = 400,
          line_pct: int = 112000) -> str:
    """一个段落；每个 run 同时写 latin/ea/cs，中文才有正确字形。"""
    attrs = (' marL="228600" indent="-228600"' if bullet else "") + (
        ' algn="%s"' % {"left": "l", "right": "r", "center": "ctr"}.get(align, "l") if align else "")
    bu = ({"char": '<a:buFont typeface="Arial"/><a:buChar char="•"/>',
           "num": '<a:buFont typeface="Arial"/><a:buAutoNum type="arabicPeriod"/>'}.get(bullet, ""))
    sz = int(size * 100)
    return ('<a:p><a:pPr%s><a:lnSpc><a:spcPct val="%d"/></a:lnSpc><a:spcBef><a:spcPts val="%d"/></a:spcBef>%s</a:pPr>'
            '<a:r><a:rPr lang="zh-CN" altLang="en-US" sz="%d" b="%d" dirty="0"><a:solidFill>'
            '<a:srgbClr val="%s"/></a:solidFill><a:latin typeface="%s"/><a:ea typeface="%s"/>'
            '<a:cs typeface="%s"/></a:rPr><a:t>%s</a:t></a:r><a:endParaRPr lang="zh-CN" sz="%d"/></a:p>'
            % (attrs, line_pct, gap, bu, sz, 1 if bold else 0, color, latin, EA_FONT, latin,
               _esc(text) or " ", sz))

# 只挂 spAutoFit：不靠 normAutofit 缩放，LibreOffice 会直接忽略它
_BODY = ('<a:bodyPr wrap="square" lIns="45720" tIns="27432" rIns="45720" bIns="27432" '
         'rtlCol="0">%s</a:bodyPr>')

def _sp(shid: int, x: int, y: int, cx: int, cy: int, para: str, fill: str = "",
        ph: bool = False) -> str:
    """文本形状；ph=True 时是标题占位符（挂 <p:ph> 才与版式配对，PowerPoint 才认标题）。"""
    return ('<p:sp><p:nvSpPr><p:cNvPr id="%d" name="%s"/>%s<p:nvPr>%s</p:nvPr></p:nvSpPr>'
            '<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
            '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>%s</p:spPr><p:txBody>%s<a:lstStyle/>%s</p:txBody></p:sp>'
            % (shid, "标题" if ph else "正文",
               '<p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>' if ph else '<p:cNvSpPr txBox="1"/>',
               '<p:ph type="title"/>' if ph else "", x, y, cx, cy,
               '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>' % fill if fill else "<a:noFill/>",
               _BODY % ("<a:spAutoFit/>" if not ph else ""), para))

def _frame(shid: int, y: int, el: Dict[str, Any]) -> str:
    """表格图形框架；续页元素自带重复后的表头行。"""
    body = [(el["header"], el["hh"], True, 0)]
    body += [(row, h, False, ri) for ri, (row, h) in enumerate(zip(el["rows"], el["row_h"]))]
    trs = "".join('<a:tr h="%d">%s</a:tr>' % (rh, "".join(
        '<a:tc><a:txBody>%s<a:lstStyle/>%s</a:txBody><a:tcPr marL="45720" marR="45720" marT="18288" '
        'marB="18288" anchor="ctr"><a:solidFill><a:srgbClr val="%s"/></a:solidFill></a:tcPr></a:tc>'
        % (_BODY % "", _para(cell, el["size"], is_head, HEAD_FG if is_head else INK,
                             align=(el["align"][ci] if ci < len(el["align"]) else "left"),
                             gap=0, line_pct=100000),
           HEAD_BG if is_head else ("FFFFFF" if ri % 2 else ALT_BG))
        for ci, cell in enumerate(cells))) for cells, rh, is_head, ri in body)
    return ('<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="%d" name="表格"/><p:cNvGraphicFramePr>'
            '<a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr>'
            '<p:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></p:xfrm><a:graphic>'
            '<a:graphicData uri="%s"><a:tbl><a:tblPr firstRow="1" bandRow="0" rtl="0">'
            '<a:tableStyleId>%s</a:tableStyleId></a:tblPr><a:tblGrid>%s</a:tblGrid>%s</a:tbl>'
            '</a:graphicData></a:graphic></p:graphicFrame>'
            % (shid, MARGIN_X, y, CONTENT_W, el["h"], NS_TBL, TBL_STYLE,
               "".join('<a:gridCol w="%d"/>' % w for w in el["widths"]), trs))

def _slide_xml(page: Dict[str, Any]) -> str:
    is_title = page["kind"] == "title"
    shapes = [_sp(2, MARGIN_X, 1600200 if is_title else TITLE_Y, CONTENT_W,
                  900000 if is_title else TITLE_H,
                  _para(page["title"], 32 if is_title else 24, True, "1F3864",
                        align="ctr" if is_title else "", gap=0), ph=not is_title)]
    shid = 3
    for kind, y, cy, el in _stack(page):
        if kind == "table":
            shapes.append(_frame(shid, y, el))
        else:
            shapes.append(_sp(shid, MARGIN_X, y, CONTENT_W, cy, _para(
                el["text"], el["size"], el["bold"], el["color"], bullet=el["bullet"],
                align=el["align"], latin=MONO if el["mono"] else LATIN), fill=el["fill"]))
        shid += 1
    return (HEAD + '<p:sld xmlns:a="%s" xmlns:r="%s" xmlns:p="%s"><p:cSld><p:spTree>%s'
            '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'
            % (NS_A, RT, NS_P, _TREE0 + "".join(shapes)))


# ---------------------------------------------------------------- 包级部件

def _rels(rids: Iterable[Tuple[str, str, str]]) -> str:
    return (HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/'
            'relationships">%s</Relationships>'
            % "".join('<Relationship Id="%s" Type="%s/%s" Target="%s"/>'
                      % (rid, RT, kind, tgt) for rid, kind, tgt in rids))

_CT_SLIDE = CTB + ".presentationml.slide+xml"
_CT_STATIC = (("/ppt/presentation.xml", CTB + ".presentationml.presentation.main+xml"),
              ("/ppt/slideMasters/slideMaster1.xml", CTB + ".presentationml.slideMaster+xml"),
              ("/ppt/slideLayouts/slideLayout1.xml", CTB + ".presentationml.slideLayout+xml"),
              ("/ppt/theme/theme1.xml", CTB + ".theme+xml"),
              ("/ppt/tableStyles.xml", CTB + ".presentationml.tableStyles+xml"),
              ("/docProps/core.xml", "application/vnd.openxmlformats-package.core-properties+xml"),
              ("/docProps/app.xml", CTB + ".extended-properties+xml"))

def _content_types(n: int) -> str:
    overrides = list(_CT_STATIC) + [("/ppt/slides/slide%d.xml" % i, _CT_SLIDE)
                                    for i in range(1, n + 1)]
    return (HEAD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.'
            'relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>%s</Types>'
            % "".join('<Override PartName="%s" ContentType="%s"/>' % kv for kv in overrides))

def _presentation(n: int) -> Tuple[str, str]:
    """sldId 与 r:id 一一对应：rId1=母版，rId2..N+1=幻灯片，其后主题/表格样式。"""
    rels = [("rId1", "slideMaster", "slideMasters/slideMaster1.xml")]
    rels += [("rId%d" % (2 + i), "slide", "slides/slide%d.xml" % (i + 1)) for i in range(n)]
    rels += [("rId%d" % (2 + n), "theme", "theme/theme1.xml"),
             ("rId%d" % (3 + n), "tableStyles", "tableStyles.xml")]
    xml = (HEAD + '<p:presentation xmlns:a="%s" xmlns:r="%s" xmlns:p="%s" saveSubsetFonts="1">'
           '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
           '<p:sldIdLst>%s</p:sldIdLst><p:sldSz cx="%d" cy="%d"/><p:notesSz cx="6858000" '
           'cy="9144000"/></p:presentation>'
           % (NS_A, RT, NS_P, "".join('<p:sldId id="%d" r:id="rId%d"/>' % (256 + i, 2 + i)
                                      for i in range(n)), SLIDE_CX, SLIDE_CY))
    return xml, _rels(rels)

# 母版/版式/主题/表格样式/关系表都是静态部件，模块导入时拼一次
_MASTER = (HEAD + '<p:sldMaster xmlns:a="%s" xmlns:r="%s" xmlns:p="%s"><p:cSld><p:bg><p:bgPr>'
            '<a:solidFill><a:schemeClr val="bg1"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>'
            '<p:spTree>%s</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" '
            'accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" '
            'accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>'
            '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>'
            '<p:txStyles><p:titleStyle>%s</p:titleStyle><p:bodyStyle>%s</p:bodyStyle>'
            '<p:otherStyle>%s</p:otherStyle></p:txStyles></p:sldMaster>'
            % (NS_A, RT, NS_P, _TREE0, _TX % (3200, 1), _TX % (1800, 0), _TX % (1400, 0)))
_LAYOUT = (HEAD + '<p:sldLayout xmlns:a="%s" xmlns:r="%s" xmlns:p="%s" type="blank" preserve="1">'
           '<p:cSld name="研究空白版">%s%s</p:cSld><p:clrMapOvr><a:masterClrMapping/>'
           '</p:clrMapOvr></p:sldLayout>'          # blank 版式带标题占位符，与幻灯片 <p:ph> 配对
           % (NS_A, RT, NS_P, _TREE0, _sp(2, MARGIN_X, TITLE_Y, CONTENT_W, TITLE_H,
                                          _para("标题", 24, True, "1F3864", gap=0), ph=True)))
_PH = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
_LN = "".join('<a:ln w="%s" cap="flat">%s<a:prstDash val="solid"/></a:ln>' % (w, _PH)
              for w in ("6350", "12700", "19050"))
_THEME = (HEAD + '<a:theme xmlns:a="%s" name="研究报告"><a:themeElements><a:clrScheme name="研究报告">'
          '<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr '
          'val="window" lastClr="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="44546A"/></a:dk2>'
          '<a:lt2><a:srgbClr val="E7E6E6"/></a:lt2>%s<a:hlink><a:srgbClr val="0563C1"/></a:hlink>'
          '<a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme>'
          '<a:fontScheme name="研究报告"><a:majorFont><a:latin typeface="Calibri Light"/>'
          '<a:ea typeface="%s"/><a:cs typeface=""/><a:font script="Hans" typeface="%s"/></a:majorFont>'
          '<a:minorFont><a:latin typeface="%s"/><a:ea typeface="%s"/><a:cs typeface=""/>'
          '<a:font script="Hans" typeface="%s"/></a:minorFont></a:fontScheme><a:fmtScheme '
          'name="Office"><a:fillStyleLst>%s</a:fillStyleLst><a:lnStyleLst>%s</a:lnStyleLst>'
          '<a:effectStyleLst>%s</a:effectStyleLst><a:bgStyleLst><a:bgFillStyleLst>%s'
          '</a:bgFillStyleLst></a:bgStyleLst></a:fmtScheme></a:themeElements></a:theme>'
          % (NS_A, "".join('<a:accent%d><a:srgbClr val="%s"/></a:accent%d>' % (i, v, i)
                           for i, v in enumerate(["1F4E79", "2E75B6", "4EA72E", "BF8F00",
                                                  "C00000", "7030A0"], 1)),
             EA_FONT, EA_FONT, LATIN, EA_FONT, EA_FONT, _PH * 3, _LN,
             "<a:effectStyle><a:effectLst/></a:effectStyle>" * 3, _PH * 3))
_TABLE_STYLES = HEAD + '<a:tblStyleLst xmlns:a="%s" def="%s"/>' % (NS_A, TBL_STYLE)
_ROOT_RELS = _rels([("rId1", "officeDocument", "ppt/presentation.xml"),
                    ("rId2", "core-properties", "docProps/core.xml"),
                    ("rId3", "extended-properties", "docProps/app.xml")])
_MASTER_RELS = _rels([("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml"),
                      ("rId2", "theme", "../theme/theme1.xml")])
_LAYOUT_RELS = _rels([("rId1", "slideMaster", "../slideMasters/slideMaster1.xml")])
_SLIDE_RELS = _rels([("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml")])

def _core(title: str) -> str:
    # 刻意不写 dcterms:created / modified —— 带时间戳的 core.xml 破坏字节确定性
    return (HEAD + '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/'
            'metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms='
            '"http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            '<dc:title>%s</dc:title><dc:subject>研究报告幻灯片</dc:subject><dc:creator>'
            'stock-researcher</dc:creator><cp:keywords>pptx,report</cp:keywords><cp:lastModifiedBy>'
            'stock-researcher</cp:lastModifiedBy></cp:coreProperties>' % _esc(title))

def _app(n: int) -> str:
    return (HEAD + '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/'
            'extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/'
            'docPropsVT"><Application>stock-researcher export_pptx</Application><AppVersion>'
            '16.0000</AppVersion><Slides>%d</Slides><Notes>0</Notes><Company>stock-researcher'
            '</Company></Properties>' % n)

def _render_stdlib(plan: List[Dict[str, Any]]) -> bytes:
    n = len(plan)
    pres_xml, pres_rels = _presentation(n)
    deck = next((p["title"] for p in plan if p["kind"] == "title"), "研究报告")
    parts = [("[Content_Types].xml", _content_types(n)), ("_rels/.rels", _ROOT_RELS),
             ("docProps/core.xml", _core(deck)), ("docProps/app.xml", _app(n)),
             ("ppt/presentation.xml", pres_xml), ("ppt/_rels/presentation.xml.rels", pres_rels),
             ("ppt/theme/theme1.xml", _THEME), ("ppt/slideMasters/slideMaster1.xml", _MASTER),
             ("ppt/slideMasters/_rels/slideMaster1.xml.rels", _MASTER_RELS),
             ("ppt/slideLayouts/slideLayout1.xml", _LAYOUT),
             ("ppt/slideLayouts/_rels/slideLayout1.xml.rels", _LAYOUT_RELS),
             ("ppt/tableStyles.xml", _TABLE_STYLES)]
    for i, page in enumerate(plan, 1):
        parts.append(("ppt/slides/slide%d.xml" % i, _slide_xml(page)))
        parts.append(("ppt/slides/_rels/slide%d.xml.rels" % i, _SLIDE_RELS))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, xml in parts:                # 固定部件顺序 + 固定时间戳 + 固定属性
            info = zipfile.ZipInfo(name, date_time=ZIP_STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o600 << 16
            zf.writestr(info, xml.encode("utf-8"))
    return buf.getvalue()


# ---------------------------------------------------------------- python-pptx 引擎

def _render_pptx(plan: List[Dict[str, Any]]) -> bytes:
    """可选增强：用 python-pptx 装配同一份计划，几何同样来自 _stack。"""
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN
    from pptx.util import Emu, Pt
    from lxml import etree

    align_map = {"left": PP_ALIGN.LEFT, "right": PP_ALIGN.RIGHT,
                 "center": PP_ALIGN.CENTER, "": PP_ALIGN.LEFT}

    def style(para: Any, size: int, bold: bool, color: str, latin: str, text: str,
              align: str = "") -> None:
        """python-pptx 只写 a:latin，中文字形得自己补 a:ea / a:cs。"""
        run = para.add_run()
        run.text = _clean(text) or " "
        run.font.size, run.font.bold, run.font.name = Pt(size), bold, latin
        run.font.color.rgb = RGBColor.from_string(color)
        para.alignment = align_map.get(align, PP_ALIGN.LEFT)
        rPr = run._r.get_or_add_rPr()
        for tag, face in (("ea", EA_FONT), ("cs", latin)):
            node = rPr.find("{%s}%s" % (NS_A, tag))
            if node is None:
                node = etree.SubElement(rPr, "{%s}%s" % (NS_A, tag))
            node.set("typeface", face)

    prs = Presentation()
    prs.slide_width, prs.slide_height = Emu(SLIDE_CX), Emu(SLIDE_CY)
    layouts = prs.slide_layouts
    for page in plan:
        slide = prs.slides.add_slide(layouts[6] if len(layouts) > 6 else layouts[0])
        title = page["kind"] == "title"
        box = slide.shapes.add_textbox(Emu(MARGIN_X), Emu(1600200 if title else TITLE_Y),
                                       Emu(CONTENT_W), Emu(900000 if title else TITLE_H))
        style(box.text_frame.paragraphs[0], 32 if title else 24, True, "1F3864", LATIN,
              page["title"], "center" if title else "")
        for kind, y, cy, el in _stack(page):
            if kind != "table":
                box = slide.shapes.add_textbox(Emu(MARGIN_X), Emu(y), Emu(CONTENT_W),
                                               Emu(max(cy, 25400)))
                style(box.text_frame.paragraphs[0], el["size"], el["bold"], el["color"],
                      MONO if el["mono"] else LATIN, el["text"], el["align"])
                continue
            values = [el["header"]] + list(el["rows"])
            gt = slide.shapes.add_table(len(values), max(1, len(el["widths"])), Emu(MARGIN_X),
                                        Emu(y), Emu(CONTENT_W), Emu(max(cy, 373253))).table
            for i, w in enumerate(el["widths"]):
                if i < len(gt.columns):
                    gt.columns[i].width = Emu(w)
            gt.rows[0].height = Emu(el["hh"])
            for ri, hs in enumerate(el["row_h"], 1):
                if ri < len(gt.rows):
                    gt.rows[ri].height = Emu(hs)
            for ri, row in enumerate(values):
                for ci, cell in enumerate(row):
                    if ci < len(gt.columns):
                        style(gt.cell(ri, ci).text_frame.paragraphs[0], el["size"], ri == 0,
                              HEAD_FG if ri == 0 else INK, LATIN, cell,
                              el["align"][ci] if ci < len(el["align"]) else "left")
    buf = io.BytesIO()
    prs.save(buf)
    return buf.getvalue()
