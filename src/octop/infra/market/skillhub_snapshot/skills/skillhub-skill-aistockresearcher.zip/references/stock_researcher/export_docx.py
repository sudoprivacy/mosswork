# -*- coding: utf-8 -*-
"""v13.0 Word(.docx) 导出器：把 IR 文档树渲染成 .docx 字节。

  - ``stdlib``（主引擎）：只用 ``zipfile`` + 标准库手拼 OOXML，市场沙箱里一个
    pip 包都没有也能出文件。
  - ``python-docx``（可选增强）：仅在可导入时启用，样式更贴近 Word 默认模板。

两个引擎的产物都重过一遍 ``_zip_write``（固定条目顺序与 date_time），所以同一份
doc 两次渲染字节完全一致，导出结果可 diff、可复核。不联网、不起子进程、不向
stdout 打印（本包跑在 MCP stdio 上，杂散输出会破坏 JSON-RPC 帧）。
"""
from __future__ import annotations

import io
import logging
import os
import re
import xml.etree.ElementTree as ET
import zipfile
from typing import Any, Dict, List, Optional, Sequence, Tuple

from stock_researcher import report_ir
from stock_researcher.report_ir import (
    Bullets, Callout, CodeBlock, Heading, MetricGrid, Paragraph,
    ReportDocument, Table,
)

FORMAT = "docx"
MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
DEFAULT_FILENAME = "report.docx"

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
WDOC = "http://schemas.openxmlformats.org/officeDocument/2006"
WREL, PREL = WDOC + "/relationships", "http://schemas.openxmlformats.org/package/2006/relationships"
PKG = "http://schemas.openxmlformats.org/package/2006"
XML_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
ZIP_DATE = (2026, 1, 1, 0, 0, 0)            # 固定 zip 时间戳：字节可复现的前提
ASCII_FONT, BODY_EA_FONT = "Calibri", "宋体"   # 中文必须显式 eastAsia，否则 Word 自己换等宽字形
HEAD_EA_FONT, MONO_FONT = "等线", "Consolas"
PAGE_W, PAGE_H, MARGIN = 11906, 16838, 1440  # A4 与 1 英寸页边距（twips）
CONTENT_W = PAGE_W - 2 * MARGIN              # 版心宽 9026 twips，表格列宽按它分配
HEADER_FILL, NOTE_FILL, WARN_FILL = "EEF3F8", "F2F6FB", "FDECEC"
LOG = logging.getLogger("stock_researcher.export_docx")


class ExportError(RuntimeError):
    """导出失败：输入不是报告、所选引擎不可用、或生成的 OOXML 不合法。"""


# ------------------------------------------------------------------ 引擎选择

_ALIASES = {"stdlib": "stdlib", "std": "stdlib", "base": "stdlib",
            "python-docx": "python-docx", "python_docx": "python-docx",
            "docx": "python-docx", "lib": "python-docx"}
_DOCX_OK: Optional[bool] = None


def _has_python_docx() -> bool:
    """探测可选引擎：find_spec 只说明"找得到"，真导一次才算可用（屏蔽器拦的是 import）。"""
    global _DOCX_OK
    if _DOCX_OK is None:
        try:
            from importlib import import_module
            from importlib.util import find_spec
            _DOCX_OK = bool(find_spec("docx")) and import_module("docx") is not None
        except Exception:                       # 被依赖屏蔽器拦下也算不可用
            _DOCX_OK = False
    return _DOCX_OK


def engines() -> List[str]:
    """当前环境可用的引擎，主引擎在前。"""
    return ["stdlib", "python-docx"] if _has_python_docx() else ["stdlib"]


def resolve_engine(engine: str = "auto") -> str:
    """把 auto/别名解析成实际引擎名；未知名字抛 ValueError。"""
    key = str(engine or "auto").strip().lower()
    if key in ("", "auto", "default"):
        return engines()[0]
    name = _ALIASES.get(key)
    if name is None:
        raise ValueError("未知的 docx 引擎 %r，可选：%s" % (engine, ", ".join(engines())))
    if name == "python-docx" and not _has_python_docx():
        raise ExportError("python-docx 不可用，请改用 stdlib 引擎")
    return name


# ------------------------------------------------------------------ 文本清洗

_CONTROL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_OUT_OF_RANGE = re.compile("[\ud800-\udfff\U00010000-\U0010FFFF\ufffe\uffff]")
_ALIGN = {"left": "left", "right": "right", "center": "center", "justify": "both"}


def _clean(text: Any) -> str:
    """压成 Word 安全的 BMP 文本：去控制字符、代理对与 BMP 外码点（表情换方块）。"""
    s = text if isinstance(text, str) else ("" if text is None else str(text))
    s = s.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")
    return _OUT_OF_RANGE.sub("\u25a1", _CONTROL.sub("", s))


def _esc(text: Any) -> str:
    s = _clean(text)
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;"))


# ------------------------------------------------------------------ run / 段落

def _rfonts(ascii_font: str, ea_font: str) -> str:
    return ('<w:rFonts w:ascii="%s" w:hAnsi="%s" w:eastAsia="%s" w:cs="%s"/>'
            % (ascii_font, ascii_font, ea_font, ea_font))


_FONT_HEAD = _rfonts(ASCII_FONT, HEAD_EA_FONT)
_FONT_MONO = _rfonts(MONO_FONT, BODY_EA_FONT)


def _runs(text: Any, *, bold: bool = False, color: str = "", size: str = "",
          fonts: str = "") -> str:
    """整段同字体的一个 run；换行用 w:br，中西文混排交给 rFonts 分派。"""
    rpr = fonts + ("<w:b/><w:bCs/>" if bold else "")
    if color:
        rpr += '<w:color w:val="%s"/>' % color
    if size:
        rpr += '<w:sz w:val="%s"/><w:szCs w:val="%s"/>' % (size, size)
    body = "<w:br/>".join('<w:t xml:space="preserve">%s</w:t>' % _esc(line)
                          for line in _clean(text).split("\n"))
    return "<w:r>%s%s</w:r>" % ("<w:rPr>%s</w:rPr>" % rpr if rpr else "", body)


def _p(runs: str = "", *, style: str = "", ppr: str = "") -> str:
    head = ('<w:pStyle w:val="%s"/>' % style if style else "") + ppr
    return "<w:p>%s%s</w:p>" % ("<w:pPr>%s</w:pPr>" % head if head else "", runs)


def _borders(edges: Sequence[Tuple[str, str, str]]) -> str:
    """edges: (边名, sz, 颜色)。"""
    return "<w:tblBorders>" + "".join(
        '<w:%s w:val="single" w:sz="%s" w:space="0" w:color="%s"/>' % e
        for e in edges) + "</w:tblBorders>"


_TB_BORDERS = _borders([(e, "4", "9BB4CC") for e in ("top", "left", "bottom", "right")] +
                       [(e, "4", "C9D6E4") for e in ("insideH", "insideV")])


# ------------------------------------------------------------------ 表格

def _col_widths(header: Sequence[str], rows: Sequence[Sequence[str]],
                cols: int) -> List[int]:
    """按内容显示宽度分配列宽；中日韩按两格算，长文本只取样前若干字。"""
    def width(text: Any) -> int:
        return sum(2 if ord(c) > 0x2E7F else 1 for c in _clean(text))

    score = [max(3, min(20, width(str(c)))) for c in header] if header else [12] * cols
    score = (score + [12] * cols)[:cols]
    for row in rows:
        for i in range(cols):
            cell = str(row[i]) if i < len(row) else ""
            score[i] = max(score[i], min(34, width(cell[:26])))
    weight = [s ** 0.7 for s in score]
    widths = [max(600, int(CONTENT_W * w / (sum(weight) or 1.0))) for w in weight]
    widths = [int(w * CONTENT_W / sum(widths)) for w in widths]
    widths[-1] += CONTENT_W - sum(widths)          # 列宽之和必须等于版心宽
    return widths


def _cell(text: Any, width: int, align: str, *, bold: bool = False,
          fill: str = "", size: str = "") -> str:
    shd = '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % fill if fill else ""
    tcpr = '<w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s<w:vAlign w:val="top"/></w:tcPr>' % (width, shd)
    ppr = ('<w:spacing w:before="40" w:after="40" w:line="240" w:lineRule="auto"/>'
           '<w:jc w:val="%s"/>' % _ALIGN.get(str(align or "left").lower(), "left"))
    return "<w:tc>%s%s</w:tc>" % (tcpr, _p(_runs(text, bold=bold, size=size,
                                                 fonts=_FONT_HEAD if bold else ""), ppr=ppr))


def _table(header: Optional[Sequence[str]], rows: Sequence[Sequence[str]],
           align: Sequence[str] = (), *, widths: Optional[Sequence[int]] = None,
           borders: str = "", shade: str = "", key_col: bool = False,
           caption: str = "") -> str:
    """真 w:tbl：表头底色加粗且跨页重复，列宽固定，长文本在格内换行。"""
    cols = len(header) if header else (len(rows[0]) if rows else 0)
    if not cols:
        return ""
    aligns = list(align) + ["left"] * max(0, cols - len(align))
    w = list(widths) if widths else _col_widths(header or [], rows, cols)
    out = [_p(_runs("表：" + caption, size="18", color="7F7F7F"), style="Caption")] \
        if caption else []
    tblpr = ('<w:tblPr><w:tblW w:type="pct" w:w="5000"/><w:tblInd w:w="0" w:type="dxa"/>%s'
             '<w:tblLayout w:type="fixed"/>'
             '<w:tblCellMar><w:top w:w="30" w:type="dxa"/><w:left w:w="80" w:type="dxa"/>'
             '<w:bottom w:w="30" w:type="dxa"/><w:right w:w="80" w:type="dxa"/>'
             '</w:tblCellMar></w:tblPr>' % (borders or _TB_BORDERS))
    # OOXML 要求 w:tblGrid 的列数与每行单元格数一致，否则 Word 判为损坏
    out.append('<w:tbl>%s<w:tblGrid>%s</w:tblGrid>'
               % (tblpr, "".join('<w:gridCol w:w="%d"/>' % x for x in w)))
    if header:
        out.append('<w:tr><w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>%s</w:tr>'
                   % "".join(_cell(h, w[i], aligns[i], bold=True, fill=HEADER_FILL,
                                   size="19") for i, h in enumerate(header)))
    for row in rows:
        cells = []
        for i in range(cols):
            is_key = key_col and i == 0
            cells.append(_cell(str(row[i]) if i < len(row) else "", w[i], aligns[i],
                               bold=is_key, size="19" if is_key else "",
                               fill="F5F7FA" if is_key else shade))
        out.append("<w:tr>%s</w:tr>" % "".join(cells))
    out.append("</w:tbl><w:p/>")                   # 表后补空段，防相邻表粘连
    return "".join(out)


def _box(text: Any, kind: str) -> str:
    """Callout 画成单格底色框；warning 另加“注意”前缀与警示色。"""
    warning = str(kind or "").lower() == "warning"
    edge, label = ("C0504D", "注意") if warning else ("4A7EBB", "说明")
    body = _clean(text)
    body = body if body.startswith(label) else "%s：%s" % (label, body)
    return _table(None, [[body]], ["left"], widths=[CONTENT_W],
                  shade=WARN_FILL if warning else NOTE_FILL,
                  borders=_borders([("top", "4", edge), ("left", "24", edge),
                                    ("bottom", "4", edge), ("right", "4", edge)]))


# ------------------------------------------------------------------ 块 → XML

def _heading_style(level: Any) -> str:
    """IR 的 Heading.level → Word 的 Heading1/2/3（导航窗格按 outlineLvl 成树）。"""
    try:
        n = int(level)
    except (TypeError, ValueError):
        n = 2
    return "Heading1" if n <= 1 else ("Heading2" if n == 2 else "Heading3")


def _block_xml(block: Any) -> str:
    if isinstance(block, Heading):
        return _p(_runs(block.text, fonts=_FONT_HEAD), style=_heading_style(block.level))
    if isinstance(block, Paragraph):
        return _p(_runs(block.text), style={"lead": "Lead", "note": "Note"}
                  .get(str(block.style or "body"), ""))
    if isinstance(block, Bullets):
        return "".join(_p(_runs(("%d. " % (i + 1)) if block.ordered else "•")
                          + _runs(item), style="List")
                       for i, item in enumerate(block.items or []))
    if isinstance(block, Table):
        return _table(list(block.header or []), [list(r) for r in (block.rows or [])],
                      list(block.align or []), caption=block.caption or "")
    if isinstance(block, MetricGrid):
        first = int(CONTENT_W * 0.3)
        return _table(None, [[str(k), str(v)] for k, v in (block.items or [])],
                      ["left", "left"], key_col=True, widths=[first, CONTENT_W - first])
    if isinstance(block, CodeBlock):
        out = [_p(_runs(block.language, size="18", color="7F7F7F"), style="Caption")] \
            if block.language else []
        out += [_p(_runs(line or " ", fonts=_FONT_MONO, size="18"), style="Code")
                for line in _clean(block.text).split("\n")]
        return "".join(out) + "<w:p/>"
    if isinstance(block, Callout):
        return _box(block.text, block.kind)
    return _p(_runs(getattr(block, "text", block)))   # 未知块降级为段落


def _body_xml(doc: ReportDocument) -> str:
    parts = [_p(_runs(doc.title, bold=True, fonts=_FONT_HEAD), style="Title")]
    if doc.subtitle:
        parts.append(_p(_runs(doc.subtitle), style="Subtitle"))
    for key, value in doc.meta or []:
        parts.append(_p(_runs("%s：%s" % (key, value)), style="Meta"))
    parts.append(_p(ppr='<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="4" '
                         'w:color="B8CCE4"/></w:pBdr><w:spacing w:before="60" '
                         'w:after="200"/>'))
    for section in doc.sections or []:
        parts.append(_p(_runs(getattr(section, "title", ""), fonts=_FONT_HEAD),
                        style="Heading1"))
        for block in getattr(section, "blocks", []) or []:
            parts.append(_block_xml(block))
    if doc.disclaimer:
        parts.append(_p(_runs("免责声明", bold=True), style="Note"))
        parts.append(_p(_runs(doc.disclaimer), style="Note"))
    return "".join(parts)


def _sect_pr(footer_rid: str) -> str:
    return ('<w:sectPr><w:footerReference w:type="default" r:id="%s"/>'
            '<w:pgSz w:w="%d" w:h="%d"/>'
            '<w:pgMar w:top="%d" w:right="%d" w:bottom="%d" w:left="%d" '
            'w:header="851" w:footer="600" w:gutter="0"/>'
            '<w:cols w:space="425"/><w:docGrid w:type="lines" w:linePitch="312"/>'
            "</w:sectPr>" % (footer_rid, PAGE_W, PAGE_H, MARGIN, MARGIN, MARGIN, MARGIN))


# ------------------------------------------------------------------ 静态部件

def _heading_style_xml(level: int, size: str, color: str, before: str, after: str) -> str:
    return (f'<w:style w:type="paragraph" w:styleId="Heading{level}">'
            f'<w:name w:val="heading {level}"/><w:basedOn w:val="Normal"/>'
            f'<w:next w:val="Normal"/><w:uiPriority w:val="9"/><w:qFormat/>'
            f'<w:pPr><w:keepNext/><w:keepLines/>'
            f'<w:spacing w:before="{before}" w:after="{after}"/>'
            f'<w:outlineLvl w:val="{level - 1}"/></w:pPr>'
            f'<w:rPr>{_FONT_HEAD}<w:b/><w:color w:val="{color}"/>'
            f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/></w:rPr></w:style>')


def _styles_xml() -> str:
    # w:pPr / w:rPr / w:tblPr 的子元素顺序由 schema 固定（pBdr<shd<spacing<ind<jc、
    # b<color<sz<szCs；tblW<tblInd<tblBorders<tblLayout<tblCellMar）；
    # 顺序错了 Word 判文档损坏，LibreOffice 却照收，所以不能只靠 LO 验收。
    body = _rfonts(ASCII_FONT, BODY_EA_FONT)
    return XML_HEAD + f'''<w:styles xmlns:w="{W_NS}">
<w:docDefaults><w:rPrDefault><w:rPr>{body}<w:sz w:val="21"/><w:szCs w:val="21"/><w:lang w:val="en-US" w:eastAsia="zh-CN" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>
<w:pPrDefault><w:pPr><w:spacing w:after="140" w:line="288" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="120" w:after="60"/><w:jc w:val="center"/></w:pPr><w:rPr>{_FONT_HEAD}<w:b/><w:color w:val="1F3864"/><w:sz w:val="36"/><w:szCs w:val="36"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:after="80"/><w:jc w:val="center"/></w:pPr><w:rPr>{_FONT_HEAD}<w:color w:val="44546A"/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Meta"><w:name w:val="Report Meta"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="20"/><w:jc w:val="center"/></w:pPr><w:rPr><w:color w:val="404040"/><w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>
{_heading_style_xml(1, "30", "1F3864", "280", "80")}
{_heading_style_xml(2, "25", "2E5B8A", "220", "60")}
{_heading_style_xml(3, "22", "44546A", "180", "40")}
<w:style w:type="paragraph" w:styleId="Lead"><w:name w:val="Lead"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:pBdr><w:left w:val="single" w:sz="18" w:space="8" w:color="4A7EBB"/></w:pBdr><w:spacing w:after="160"/><w:ind w:left="160"/></w:pPr><w:rPr><w:b/><w:color w:val="1F3864"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Note"><w:name w:val="Note"/><w:basedOn w:val="Normal"/><w:rPr><w:color w:val="595959"/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="List"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="60"/><w:ind w:left="480" w:hanging="240"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Code"><w:name w:val="Code"/><w:basedOn w:val="Normal"/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="F5F5F5"/><w:spacing w:after="0" w:line="240" w:lineRule="auto"/><w:ind w:left="160"/></w:pPr><w:rPr>{_FONT_MONO}<w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Caption"><w:name w:val="caption"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="60" w:after="20"/></w:pPr><w:rPr><w:color w:val="7F7F7F"/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Footer"><w:name w:val="footer"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="0"/><w:jc w:val="center"/></w:pPr><w:rPr><w:color w:val="808080"/><w:sz w:val="16"/><w:szCs w:val="16"/></w:rPr></w:style>
<w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont"><w:name w:val="Default Paragraph Font"/></w:style>
<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="30" w:type="dxa"/><w:left w:w="80" w:type="dxa"/><w:bottom w:w="30" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>
<w:style w:type="numbering" w:default="1" w:styleId="NoList"><w:name w:val="No List"/></w:style>
</w:styles>'''


def _rels(items: Sequence[Tuple[str, str, str]]) -> str:
    return ('<Relationships xmlns="%s">' % PREL) + "".join(
        '<Relationship Id="%s" Type="%s" Target="%s"/>' % t for t in items) + "</Relationships>"


_ROOT_RELS = _rels([("rId1", WREL + "/officeDocument", "word/document.xml"),
                    ("rId2", PREL + "/metadata/core-properties", "docProps/core.xml"),
                    ("rId3", WREL + "/extended-properties", "docProps/app.xml")])
_DOC_RELS = _rels([("rId1", WREL + "/styles", "styles.xml"),
                   ("rId2", WREL + "/footer", "footer1.xml")])
_OD = "application/vnd.openxmlformats-officedocument"
_WML = _OD + ".wordprocessingml"
_CT_BASE = PKG + "/content-types"
# core.xml 不写 dcterms:created/modified：时间戳会让同一份 doc 产不出相同字节
_CONTENT_TYPES = (
    '<Types xmlns="%s"><Default Extension="rels" ContentType="application/vnd.openxmlformats-'
    'package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
    '<Override PartName="/word/document.xml" ContentType="%s.document.main+xml"/>'
    '<Override PartName="/word/styles.xml" ContentType="%s.styles+xml"/>'
    '<Override PartName="/word/footer1.xml" ContentType="%s.footer+xml"/>'
    '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-'
    'package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="%s'
    '.extended-properties+xml"/></Types>') % (_CT_BASE, _WML, _WML, _WML, _OD)
_CORE_XML = (
    '<cp:coreProperties xmlns:cp="%s/metadata/core-properties" xmlns:dc="http://'
    'purl.org/dc/elements/1.1/"><dc:title>%s</dc:title><dc:subject>研究报告</dc:subject>'
    '<dc:creator>stock-researcher</dc:creator><cp:lastModifiedBy>stock-researcher'
    '</cp:lastModifiedBy><cp:revision>1</cp:revision><cp:category>%s</cp:category>'
    '<dc:description>stock-researcher v13.0 docx 渲染器</dc:description></cp:coreProperties>')
_APP_XML = (
    '<Properties xmlns="%s/extended-properties"><Application>stock-researcher'
    '</Application><AppVersion>13.0000</AppVersion><DocSecurity>0</DocSecurity>'
    '<ScaleCrop>false</ScaleCrop><LinksUpToDate>false</LinksUpToDate><SharedDoc>false'
    '</SharedDoc><HyperlinksChanged>false</HyperlinksChanged></Properties>')


def _stdlib_parts(doc: ReportDocument) -> Dict[str, str]:
    document = (XML_HEAD + '<w:document xmlns:w="%s" xmlns:r="%s"><w:body>%s%s'
                "</w:body></w:document>" % (W_NS, WREL, _body_xml(doc), _sect_pr("rId2")))
    footer_text = doc.disclaimer or ("%s · stock-researcher" % doc.title)
    return {
        "[Content_Types].xml": _CONTENT_TYPES,
        "_rels/.rels": _ROOT_RELS,
        "word/document.xml": document,
        "word/styles.xml": _styles_xml(),
        "word/_rels/document.xml.rels": _DOC_RELS,
        "word/footer1.xml": XML_HEAD + '<w:ftr xmlns:w="%s">%s</w:ftr>' % (
            W_NS, _p(_runs(footer_text), style="Footer")),
        "docProps/core.xml": _CORE_XML % (PKG, _esc(doc.title), report_ir.IR_VERSION),
        "docProps/app.xml": _APP_XML % WDOC,
    }


# ------------------------------------------------------------------ python-docx

def _docx_lib_parts(doc: ReportDocument) -> Dict[str, bytes]:
    """可选增强引擎：排版交给 python-docx，产物拆回部件表后统一归一化。"""
    try:
        import docx                              # 延迟导入：模块顶层绝不依赖它
        from docx.enum.text import WD_ALIGN_PARAGRAPH as AL
        from docx.oxml import OxmlElement
        from docx.oxml.ns import qn
        from docx.shared import Mm, Pt, RGBColor
    except Exception as exc:                      # pragma: no cover - 环境相关
        raise ExportError("python-docx 不可用：%s" % exc)

    jc = {"left": AL.LEFT, "right": AL.RIGHT, "center": AL.CENTER, "justify": AL.JUSTIFY}
    heads = ("Title", "Subtitle", "Heading 1", "Heading 2", "Heading 3")
    lib = docx.Document()
    page = lib.sections[0]
    page.page_width, page.page_height = Mm(210), Mm(297)
    page.left_margin = page.right_margin = page.top_margin = page.bottom_margin = Mm(25.4)
    page.footer_distance = Mm(12)

    def _ea(owner, ea_font, ascii_font=ASCII_FONT):
        """python-docx 的 font.name 只写 ascii/hAnsi，中文得自己补 w:eastAsia。"""
        owner.font.name = ascii_font
        owner._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), ea_font)

    def _shade(pr, fill):
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:fill"), fill)
        pr.append(shd)                            # w:shd 在 pPr/tcPr 里追加即可

    attrs = {"Title": (18, "1F3864"), "Subtitle": (11, "44546A"), "Heading 1": (15, "1F3864"),
             "Heading 2": (13, "2E5B8A"), "Heading 3": (12, "44546A"),
             "Normal": (10.5, ""), "Footer": (8, "808080")}
    for style in lib.styles:                      # 样式级配好中文字体与字号，run 直接继承
        try:
            _ea(style, HEAD_EA_FONT if style.name in heads else BODY_EA_FONT)
            size, color = attrs.get(style.name, (None, ""))
            if size:
                style.font.size = Pt(size)
            if color:
                style.font.color.rgb = RGBColor.from_string(color)
        except Exception:                         # 个别模板样式不吃这些属性
            continue

    def _para(text, style=None, size=None, color="", bold=False, align=None):
        p = lib.add_paragraph()
        try:
            if style:
                p.style = lib.styles[style]
        except KeyError:
            pass
        run = p.add_run(_clean(text))
        run.bold = bold
        if size:
            run.font.size = Pt(size)
        if color:
            run.font.color.rgb = RGBColor.from_string(color)
        if align is not None:
            p.alignment = align
        return p

    def _tbl(header, rows, aligns):
        cols = len(header) if header else (len(rows[0]) if rows else 0)
        if not cols:
            return
        table = lib.add_table(rows=0, cols=cols)
        try:
            table.style = lib.styles["Table Grid"]   # 有现成网格样式，不必自己拼 tblBorders
        except Exception:                              # pragma: no cover - 模板缺样式
            pass
        table.autofit = False
        widths = _col_widths(header or [], rows, cols)
        seq = ([list(header)] if header else []) + [list(r) for r in rows]
        for ri, values in enumerate(seq):
            is_head = bool(header) and ri == 0
            for i, cell in enumerate(table.add_row().cells):
                cell.width = Mm(widths[i] * 0.0176389)   # twips → mm
                para = cell.paragraphs[0]
                run = para.add_run(_clean(values[i] if i < len(values) else ""))
                run.bold = is_head
                if is_head:
                    _shade(cell._tc.get_or_add_tcPr(), HEADER_FILL)
                elif i < len(aligns):
                    para.alignment = jc.get(aligns[i], AL.LEFT)
        if header:                    # 长表跨页重复表头，免得整页只剩看不懂的数据行
            table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))

    _para(doc.title, "Title", align=AL.CENTER)
    if doc.subtitle:
        _para(doc.subtitle, "Subtitle", align=AL.CENTER)
    for key, value in doc.meta or []:
        _para("%s：%s" % (key, value), size=9.5, color="404040", align=AL.CENTER)
    for section in doc.sections or []:
        _para(getattr(section, "title", ""), "Heading 1")
        for block in getattr(section, "blocks", []) or []:
            if isinstance(block, Heading):
                _para(block.text, "Heading %d" % min(3, max(1, int(block.level or 2))))
            elif isinstance(block, Paragraph):
                _para(block.text, size={"lead": 12}.get(block.style),
                      bold=block.style == "lead",
                      color={"lead": "1F3864", "note": "595959"}.get(block.style or ""))
            elif isinstance(block, Bullets):
                for item in block.items or []:
                    _para(item, "List Number" if block.ordered else "List Bullet")
            elif isinstance(block, Table):
                if block.caption:
                    _para("表：" + block.caption, size=9, color="7F7F7F")
                _tbl(list(block.header or []), [list(r) for r in (block.rows or [])],
                     list(block.align or []))
                lib.add_paragraph()
            elif isinstance(block, MetricGrid):
                _tbl(["指标", "取值"], [[str(k), str(v)] for k, v in (block.items or [])],
                     ["left", "left"])
                lib.add_paragraph()
            elif isinstance(block, CodeBlock):
                if block.language:
                    _para(block.language, size=9, color="7F7F7F")
                for line in _clean(block.text).split("\n"):
                    p = _para(line or " ", size=9)
                    _ea(p.runs[0], BODY_EA_FONT, MONO_FONT)
                    _shade(p._p.get_or_add_pPr(), "F5F5F5")
            elif isinstance(block, Callout):
                warn = str(block.kind or "").lower() == "warning"
                label = "注意" if warn else "说明"
                text = _clean(block.text)
                p = _para(text if text.startswith(label) else "%s：%s" % (label, text),
                          bold=warn, color="9C3B34" if warn else "1F3864")
                _shade(p._p.get_or_add_pPr(), WARN_FILL if warn else NOTE_FILL)
    if doc.disclaimer:
        _para("免责声明", size=9, color="595959", bold=True)
        _para(doc.disclaimer, size=9, color="595959")
    foot = page.footer
    fp = foot.paragraphs[0] if foot.paragraphs else foot.add_paragraph()
    fp.text = ""
    run = fp.add_run(_clean(doc.disclaimer or doc.title))
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor.from_string("808080")
    fp.alignment = AL.CENTER

    buf = io.BytesIO()
    lib.save(buf)
    with zipfile.ZipFile(io.BytesIO(buf.getvalue())) as zf:
        parts = {name: zf.read(name) for name in zf.namelist()}
    if "docProps/core.xml" in parts:      # 模板 core.xml 带着死时间戳，一并抹掉
        parts["docProps/core.xml"] = re.sub(
            rb"<dcterms:(created|modified)[^>]*>.*?</dcterms:\1>", b"",
            parts["docProps/core.xml"], flags=re.S)
    return parts


# ------------------------------------------------------------------ 组装 / 出口

def _as_bytes(blob: Any) -> bytes:
    return blob if isinstance(blob, bytes) else str(blob).encode("utf-8")


def _zip_write(parts: Dict[str, Any]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in sorted(parts):                    # 固定顺序 = 固定字节
            info = zipfile.ZipInfo(name, date_time=ZIP_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 0                    # 固定宿主位，跨平台产物一致
            info.external_attr = 0
            zf.writestr(info, _as_bytes(parts[name]))
    return buf.getvalue()


def _validate(parts: Dict[str, Any]) -> None:
    for name, blob in sorted(parts.items()):
        if not (name.endswith(".xml") or name.endswith(".rels")):
            continue
        try:
            ET.fromstring(_as_bytes(blob))
        except (ET.ParseError, ValueError) as exc:
            raise ExportError("生成的 %s 不是合法 OOXML：%s" % (name, exc))


def _coerce(doc: Any) -> ReportDocument:
    """ReportDocument 直接用；ResearchReport / 其 dict 走 IR 编译。"""
    try:
        return report_ir.coerce_document(doc)
    except Exception as exc:
        raise ExportError("报告无法编译为 IR：%s" % exc) from exc


def render(doc: Any, engine: str = "auto") -> bytes:
    """渲染 .docx 字节；doc 可为 ReportDocument、ResearchReport 或其 dict。"""
    name = resolve_engine(engine)
    document = _coerce(doc)
    parts = _stdlib_parts(document) if name == "stdlib" else _docx_lib_parts(document)
    _validate(parts)
    return _zip_write(parts)


def render_to_file(doc: Any, path: Any, engine: str = "auto") -> str:
    """落盘，返回写入的绝对路径（父目录自动创建）。"""
    blob = render(doc, engine)
    target = os.path.abspath(str(path))
    if os.path.dirname(target):
        os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "wb") as fh:
        fh.write(blob)
    LOG.debug("docx 已写出 %s（%d 字节）", target, len(blob))
    return target


__all__ = ["FORMAT", "MEDIA_TYPE", "DEFAULT_FILENAME", "ExportError",
           "engines", "resolve_engine", "render", "render_to_file"]
