﻿# -*- coding: utf-8 -*-
"""v12.0 Research Intelligence Hub — 统一研究编排与可审计报告。

流程：数据获取/摄入 → 归一化与质量标记 → 技术/资金/基本面/新闻/基金/期货因子
→ 历史条件概率预测与校准 → 冲突检测 → 证据链 → Markdown/JSON。
"""
from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from stock_researcher.constants import VERSION as APP_VERSION
from stock_researcher.research_analysis import (
    AnalysisBundle, EmpiricalForecastEngine, ResearchAnalyzer, build_scenarios,
    compute_technical_metrics,
)
from stock_researcher.research_contracts import (
    DISCLAIMER, SCHEMA_VERSION, AssetAnalysis, DataQualityReport, EvidenceLedger,
    ForecastDistribution, FundSnapshot, FuturesCurve, MarketQuote, PriceSeries,
    ResearchReport, Scenario, clamp, make_run_id, now_iso, report_to_markdown,
    safe_float,
)
from stock_researcher.research_data import (
    CollectedData, DataAccessError, Dataset, DatasetLoader, LiveDataProvider,
    infer_market,
)


def _merge_bundles(bundles: Sequence[AnalysisBundle]) -> AnalysisBundle:
    factors, warnings, risks, conflicts = [], [], [], []
    metrics: Dict[str, Any] = {}
    specialized: Dict[str, Any] = {}
    quality_rank = {"actual": 4, "derived": 3, "estimated": 2, "unavailable": 1, "insufficient": 0}
    quality = "insufficient"
    for bundle in bundles:
        if not bundle:
            continue
        factors.extend(bundle.factors)
        warnings.extend(bundle.warnings)
        risks.extend(bundle.risks)
        conflicts.extend(bundle.conflicts)
        metrics.update(bundle.metrics)
        specialized.update(bundle.specialized)
        if quality_rank.get(bundle.quality, 0) > quality_rank.get(quality, 0):
            quality = bundle.quality
    score, confidence = ResearchAnalyzer.weighted_score(factors)
    return AnalysisBundle(score=score, confidence=confidence, factors=factors,
                          metrics=metrics, warnings=_unique(warnings),
                          risks=_unique(risks), conflicts=_unique(conflicts),
                          specialized=specialized, quality=quality)


def _unique(items: Iterable[Any]) -> List[Any]:
    out, seen = [], set()
    for item in items:
        key = str(item)
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


def _direction_from_score(score: float, confidence: float = 1.0) -> str:
    if confidence < 0.28:
        return "neutral"
    if score >= 20:
        return "bullish"
    if score <= -20:
        return "bearish"
    return "neutral"

class ResearchHub:
    """一键研究编排器。"""

    def __init__(self, provider: Optional[LiveDataProvider] = None,
                 forecaster: Optional[EmpiricalForecastEngine] = None) -> None:
        self.provider = provider or LiveDataProvider()
        self.forecaster = forecaster or EmpiricalForecastEngine()

    def analyze(self, symbol: str, question: str = "",
                asset_type: Optional[str] = None, market: Optional[str] = None,
                history_days: int = 250, include_news: bool = True,
                include_flow: bool = True, include_fundamentals: bool = True,
                data: Optional[CollectedData] = None,
                benchmark: Optional[PriceSeries] = None,
                futures_contracts: Optional[Sequence[str]] = None,
                spot_price: Optional[float] = None,
                overrides: Optional[Dict[str, Any]] = None) -> ResearchReport:
        started = time.monotonic()
        if data is None:
            data = self.provider.collect(
                symbol, asset_type=asset_type, market=market,
                history_days=history_days, include_news=include_news,
                include_flow=include_flow, include_fundamentals=include_fundamentals,
                include_futures_curve=bool(futures_contracts),
                futures_contracts=futures_contracts, spot_price=spot_price,
                overrides=overrides,
            )
        ledger = EvidenceLedger()
        analyzer = ResearchAnalyzer(ledger)
        bundles: List[AnalysisBundle] = []
        technical = (analyzer.technical(data.history, data.asset_type)
                     if data.history and data.history.usable else
                     AnalysisBundle(warnings=["历史价格序列不可用或不足"],
                                    quality="insufficient"))
        specialized: AnalysisBundle
        if data.asset_type == "fund":
            specialized = analyzer.fund(data.fund_snapshot, data.history, benchmark) if data.history else AnalysisBundle()
            bundles.extend([specialized, technical])
        elif data.asset_type == "futures":
            oi_hist = None
            if data.extras:
                oi_hist = data.extras.get("open_interest_history")
            specialized = (analyzer.futures(data.futures_curve, data.history,
                                            spot_price=spot_price, open_interest_history=oi_hist)
                           if data.history else AnalysisBundle())
            bundles.extend([specialized, technical])
        else:
            bundles.append(technical)
            if data.money_flow:
                bundles.append(analyzer.money_flow(data.money_flow, symbol))
            if data.fundamentals:
                bundles.append(analyzer.fundamentals(data.fundamentals, symbol))
        news_bundle = analyzer.news(data.news, symbol, question=question) if data.news else None
        if news_bundle:
            bundles.append(news_bundle)
        combined = _merge_bundles(bundles)
        # 行情/历史/基金/期货快照也纳入证据链。
        extra_evidence: List[str] = []
        if data.quote and data.quote.valid:
            extra_evidence.append(ledger.add(
                "quote", "最新行情", {"price": data.quote.price,
                                    "change_pct": data.quote.change_pct,
                                    "source": data.quote.source},
                source=data.quote.source, quality=data.quote.quality,
                observed_at=data.quote.timestamp, reliability="high",
            ))
        if data.history and data.history.closes:
            h = data.history
            extra_evidence.append(ledger.add(
                "price_history", "历史价格序列",
                {"rows": len(h.closes), "first": h.closes[0], "last": h.closes[-1],
                 "as_of": h.as_of, "quality": h.quality},
                source=h.source, quality=h.quality, observed_at=h.as_of,
            ))
        if data.fund_snapshot:
            s = data.fund_snapshot
            extra_evidence.append(ledger.add(
                "fund_nav", "基金净值/估值",
                {"official_nav": s.official_nav, "nav_date": s.nav_date,
                 "estimated_nav": s.estimated_nav, "estimate_pct": s.estimate_pct,
                 "market_price": s.market_price, "premium_pct": s.premium_pct},
                source=s.source, quality=s.quality,
                observed_at=s.estimate_time or s.nav_date,
            ))
        if data.futures_curve:
            extra_evidence.append(ledger.add(
                "futures_curve", "期货期限结构",
                {"contracts": [c.to_dict() for c in data.futures_curve.contracts],
                 "spot_price": data.futures_curve.spot_price},
                source=data.futures_curve.source, quality=data.futures_curve.quality,
                observed_at=data.futures_curve.as_of,
            ))
        if news_bundle:
            for item in (news_bundle.specialized.get("news_items") or [])[:5]:
                extra_evidence.append(ledger.add(
                    "news", item.get("title", "新闻"), item.get("evidence_span", ""),
                    source=item.get("source", ""), quality="actual",
                    reliability=item.get("reliability", "medium"),
                    published_at=item.get("published_at", ""),
                    url=item.get("url", ""),
                ))
        forecasts = self._forecast(data.history)
        price = self._current_price(data)
        scenarios = build_scenarios(forecasts, price)
        quality = self._data_quality(data, combined, include_news=include_news,
                                     include_flow=include_flow,
                                     include_fundamentals=include_fundamentals)
        report = self._compose_report(
            symbol=symbol, question=question, data=data, combined=combined,
            forecasts=forecasts, scenarios=scenarios, quality=quality,
            ledger=ledger, price=price, extra_evidence=extra_evidence,
            news_bundle=news_bundle, started=started,
        )
        return report

    def _forecast(self, history: Optional[PriceSeries]) -> List[ForecastDistribution]:
        prices = list(history.closes) if history else []
        try:
            return self.forecaster.forecast_multi(prices)
        except Exception as exc:
            return [ForecastDistribution(
                horizon=label, horizon_days=days, quality="insufficient",
                abstain=True, confidence=0.0,
                warnings=[f"预测引擎异常: {str(exc)[:160]}"],
            ) for label, days in self.forecaster.horizons]

    @staticmethod
    def _current_price(data: CollectedData) -> Optional[float]:
        if data.quote and data.quote.valid:
            return data.quote.price
        if data.fund_snapshot:
            for value in (data.fund_snapshot.market_price,
                          data.fund_snapshot.estimated_nav,
                          data.fund_snapshot.official_nav):
                if value:
                    return value
        if data.futures_curve and data.futures_curve.contracts:
            return data.futures_curve.contracts[0].price
        if data.history and data.history.closes:
            return data.history.closes[-1]
        return None

    def _data_quality(self, data: CollectedData, combined: AnalysisBundle,
                      include_news: bool = True, include_flow: bool = True,
                      include_fundamentals: bool = True) -> DataQualityReport:
        missing, warnings = [], []
        earned = total = 0.0
        available = expected = 0
        field_quality: Dict[str, str] = {}

        def check(label: str, weight: float, ok: bool, quality: str = "actual",
                  earned_weight: Optional[float] = None) -> None:
            nonlocal earned, total, available, expected
            total += weight
            expected += 1
            if ok:
                available += 1
                earned += weight if earned_weight is None else earned_weight
                field_quality[label] = quality
            else:
                missing.append(label)
                field_quality[label] = "unavailable"

        q_ok = bool(data.quote and data.quote.valid)
        check("最新行情", 0.20, q_ok, data.quote.quality if data.quote else "unavailable")
        n_hist = len(data.history.closes) if data.history else 0
        hist_weight = 0.35 if n_hist >= 120 else 0.28 if n_hist >= 60 else 0.18 if n_hist >= 20 else 0.0
        # 少于 120 行仍算"有历史"，但只按实际覆盖度给分，而不是一票拿满 0.35。
        check("历史价格", 0.35, n_hist >= 20,
              "actual" if n_hist >= 120 else "derived" if n_hist >= 40 else "estimated",
              earned_weight=hist_weight)
        if data.asset_type == "fund":
            check("基金净值/估值", 0.20, bool(data.fund_snapshot), data.fund_snapshot.quality if data.fund_snapshot else "unavailable")
        elif data.asset_type == "futures":
            check("期货期限结构", 0.20, bool(data.futures_curve and data.futures_curve.contracts), data.futures_curve.quality if data.futures_curve else "unavailable")
        else:
            if include_flow:
                check("资金流", 0.10, bool(data.money_flow), "actual" if data.money_flow else "unavailable")
            if include_fundamentals:
                check("基本面", 0.10, bool(data.fundamentals), "actual" if data.fundamentals else "unavailable")
        if include_news:
            check("新闻/公告", 0.10, bool(data.news), "actual" if data.news else "unavailable")
        if data.history and data.history.warnings:
            warnings.extend(data.history.warnings)
        if data.quote and data.quote.warnings:
            warnings.extend(data.quote.warnings)
        warnings.extend(data.warnings)
        warnings.extend(data.errors)
        warnings.extend(combined.warnings)
        score = clamp(earned / total, 0.0, 1.0) if total else 0.0
        completeness = available / expected if expected else 0.0
        if n_hist < 20:
            status = "insufficient"
        elif n_hist < 60:
            status = "estimated"
        elif n_hist < 120 or data.errors:
            status = "derived"
        else:
            status = "actual"
        if data.asset_type == "fund" and data.fund_snapshot and data.fund_snapshot.quality == "estimated":
            status = "estimated"
        elif status == "actual" and (not q_ok or combined.quality == "estimated"):
            status = "derived"
        freshness = data.quote.freshness if data.quote else "unknown"
        sources = list(data.sources)
        for obj in (data.quote, data.history, data.fund_snapshot, data.futures_curve):
            if obj and getattr(obj, "source", ""):
                sources.append(obj.source)
        return DataQualityReport(
            status=status, score=round(score, 3), completeness=round(completeness, 3),
            freshness=freshness, sources=_unique([s for s in sources if s]),
            missing=_unique(missing), warnings=_unique(warnings),
            field_quality=field_quality,
        )

    def _compose_report(self, symbol: str, question: str, data: CollectedData,
                        combined: AnalysisBundle,
                        forecasts: Sequence[ForecastDistribution],
                        scenarios: Sequence[Scenario], quality: DataQualityReport,
                        ledger: EvidenceLedger, price: Optional[float],
                        extra_evidence: Sequence[str], news_bundle: Optional[AnalysisBundle],
                        started: float) -> ResearchReport:
        forecast_weights = {"1d": 0.10, "5d": 0.20, "1M": 0.35, "3M": 0.20, "6M": 0.15}
        usable = [f for f in forecasts if not f.abstain]
        if usable:
            w_sum = sum(forecast_weights.get(f.horizon, 0.1) for f in usable)
            forecast_score = sum((f.probability_up - f.probability_down) * 100
                                 * forecast_weights.get(f.horizon, 0.1) for f in usable) / w_sum
            forecast_conf = sum(f.confidence * forecast_weights.get(f.horizon, 0.1)
                                for f in usable) / w_sum
            overall_score = combined.score * 0.62 + forecast_score * 0.38
            overall_conf = (combined.confidence * 0.55 + forecast_conf * 0.30
                            + quality.score * 0.15)
        else:
            overall_score = combined.score
            forecast_conf = 0.0
            overall_conf = combined.confidence * 0.80 + quality.score * 0.20
        overall_score = round(clamp(overall_score, -100, 100), 1)
        overall_conf = round(clamp(overall_conf, 0.0, 0.95), 3)
        if quality.status == "insufficient":
            overall_conf = min(overall_conf, 0.20)
        elif quality.status == "estimated":
            overall_conf = min(overall_conf, 0.40)
        elif quality.status == "derived":
            overall_conf = min(overall_conf, 0.65)
        if combined.quality == "insufficient" and not usable:
            overall_conf = min(overall_conf, 0.20)
        direction = _direction_from_score(overall_score, overall_conf)
        name = (data.quote.name if data.quote and data.quote.name else
                data.fund_snapshot.name if data.fund_snapshot and data.fund_snapshot.name else
                symbol)
        evidence_ids = extra_evidence[:]
        for factor in combined.factors:
            evidence_ids.extend(factor.evidence_ids)
        evidence_ids = _unique(evidence_ids)
        asset = AssetAnalysis(
            symbol=symbol, asset_type=data.asset_type, market=data.market,
            name=name, as_of=(data.quote.timestamp
                              if data.quote and data.quote.valid and data.quote.timestamp
                              else data.history.as_of
                              if data.history and data.history.closes else ""),
            price=price, score=overall_score, direction=direction,
            confidence=overall_conf, factors=list(combined.factors),
            metrics=combined.metrics, evidence_ids=evidence_ids,
            conflicts=_unique(combined.conflicts),
            risks=_unique(combined.risks), warnings=_unique(combined.warnings),
            quality=combined.quality, specialized=combined.specialized,
        )
        top_factors = sorted(combined.factors,
                             key=lambda f: abs(f.score) * f.weight * max(0.1, f.confidence),
                             reverse=True)[:4]
        support = [f"{f.name} {f.score:+.0f}（{f.rationale}）" for f in top_factors if f.score > 5]
        drag = [f"{f.name} {f.score:+.0f}（{f.rationale}）" for f in top_factors if f.score < -5]
        chosen_forecast = next((f for f in forecasts if f.horizon == "1M"), None) or (forecasts[0] if forecasts else None)
        forecast_text = ""
        if chosen_forecast:
            if chosen_forecast.abstain:
                # 弃权时不再展示 50%/45% 这类占位概率，否则读者会把默认值当结论。
                reason = (chosen_forecast.warnings or ["样本或校准不足"])[0]
                forecast_text = (f"{chosen_forecast.horizon} 预测已弃权：{reason}；"
                                 f"不输出方向概率与区间。")
            else:
                q05, q95 = chosen_forecast.quantiles.get("p05"), chosen_forecast.quantiles.get("p95")
                interval = f"[{q05:+.1f}%, {q95:+.1f}%]" if q05 is not None and q95 is not None else "区间不可用"
                forecast_text = (f"{chosen_forecast.horizon} 上涨概率 {chosen_forecast.probability_up:.0%}，"
                                 f"震荡 {chosen_forecast.probability_flat:.0%}，下跌 {chosen_forecast.probability_down:.0%}，"
                                 f"中位收益 {chosen_forecast.median_return_pct:+.2f}%，90%区间 {interval}。")
        direction_cn = {"bullish": "偏多", "bearish": "偏空", "neutral": "中性"}.get(direction, direction)
        summary_parts = [f"{name}（{symbol}）综合评分 {overall_score:+.1f}/100，方向{direction_cn}，置信度 {overall_conf:.0%}。"]
        if support:
            summary_parts.append("主要支撑：" + "；".join(support[:2]) + "。")
        if drag:
            summary_parts.append("主要拖累：" + "；".join(drag[:2]) + "。")
        if forecast_text:
            summary_parts.append(forecast_text)
        summary_parts.append(f"数据状态 {quality.status}，完整度 {quality.completeness:.0%}，"
                             f"来源 {', '.join(quality.sources[:5]) or '—'}。")
        executive_summary = " ".join(summary_parts)
        conclusions: List[str] = []
        if top_factors:
            conclusions.append("核心因子：" + "；".join(
                f"{f.name}={f.score:+.0f}" for f in top_factors[:3]))
        if chosen_forecast:
            if chosen_forecast.abstain:
                conclusions.append(
                    f"概率预测：{chosen_forecast.horizon} 样本或校准不足，已弃权；"
                    "不给出方向概率与区间。")
            else:
                conclusions.append(
                    f"概率预测：{chosen_forecast.horizon} 上涨 {chosen_forecast.probability_up:.0%}、"
                    f"下跌 {chosen_forecast.probability_down:.0%}、中位 {chosen_forecast.median_return_pct:+.2f}%；"
                    f"方法 {chosen_forecast.method}，样本 {chosen_forecast.sample_size}，质量 {chosen_forecast.quality}。")
        conclusions.append(f"证据链共 {len(ledger)} 条；报告结论均由因子与证据 ID 支撑。")
        if quality.missing:
            conclusions.append("缺失项：" + "、".join(quality.missing) + "；相关结论已降权。")

        risks = list(combined.risks)
        for f in forecasts:
            if f.abstain and f.warnings:
                risks.extend(f.warnings[:1])
        if data.asset_type == "fund":
            risks.append("基金历史业绩不代表未来，需关注费率、规模变化、经理变更与跟踪误差")
            if data.fund_snapshot and data.fund_snapshot.fund_type == "otc":
                risks.append("场外基金按未知价申赎，盘中估值不能作为成交价")
        elif data.asset_type == "futures":
            risks.append("期货为保证金交易，杠杆、夜盘跳空、涨跌停与展期均可能放大损失")
        else:
            risks.append("需关注财报/公告、政策、流动性与市场风险偏好的变化")
        if quality.status in ("insufficient", "estimated"):
            risks.append("数据覆盖不足，报告置信度已下调，不应据此做集中决策")

        counterpoints = list(combined.conflicts)
        news_summary = (news_bundle.specialized.get("summary", {})
                        if news_bundle and news_bundle.specialized else {})
        if direction == "bullish" and news_summary:
            if (news_summary.get("negative", 0) or 0) > (news_summary.get("positive", 0) or 0):
                counterpoints.append("价格/因子偏多，但新闻事件整体偏负，存在预期差反转风险")
        if direction == "bullish" and data.money_flow:
            main_net = safe_float(data.money_flow.get("main_net_flow", data.money_flow.get("main_net")), None)
            if main_net is not None and main_net < 0:
                counterpoints.append("价格/因子偏多，但主力资金净流出，需警惕反弹缺乏资金确认")
        if chosen_forecast and chosen_forecast.probability_down >= 0.40:
            counterpoints.append(f"即使方向偏多，{chosen_forecast.horizon} 下跌概率仍达 "
                                 f"{chosen_forecast.probability_down:.0%}，并非单向行情")
        if direction == "bearish" and chosen_forecast and chosen_forecast.probability_up >= 0.40:
            counterpoints.append(f"即使方向偏空，{chosen_forecast.horizon} 上涨概率仍达 "
                                 f"{chosen_forecast.probability_up:.0%}，存在逼空/反弹风险")

        methodology = [
            "数据流：统一数据提供器 → 字段归一化 → 质量标记 → 因子/证据；缺失与估算值均显式标注。",
            "技术面：均线/MACD/RSI/ATR/布林带、动量、波动率、回撤、Sharpe/Sortino/VaR，按可用性加权。",
            "概率预测：以20日动量与实现波动率为条件特征，对未来同周期收益做历史近邻加权；"
            "向无条件分布收缩，并用样本外 Brier 与基准比较；样本不足或校准失败时弃权。",
            "新闻：标题/正文去重、来源可信度分层、事件类型与方向抽取、时间衰减；不把情绪直接等同于收益。",
            "情景：熊/基准/牛分别取分布 p05/p50/p95，概率 20%/60%/20% 表示情景覆盖权重，不是方向胜率。",
            "证据链：每条行情、财务、资金、新闻与因子均带来源、时间、质量、原文/数值摘要。",
            f"耗时约 {(time.monotonic() - started):.2f} 秒；本报告不使用未来数据构造特征。",
        ]
        warnings = _unique(list(quality.warnings) + list(combined.warnings)
                           + [w for f in forecasts for w in f.warnings] + list(data.errors))
        report = ResearchReport(
            schema_version=SCHEMA_VERSION, run_id=make_run_id("research"),
            generated_at=now_iso(), symbol=symbol, asset_type=data.asset_type,
            name=name, question=question,
            as_of=asset.as_of or "",
            data_cutoff=str(data.extras.get("data_cutoff") or asset.as_of or ""),
            executive_summary=executive_summary, direction=direction,
            confidence=overall_conf, score=overall_score, asset_analysis=asset,
            forecasts=list(forecasts), scenarios=list(scenarios),
            data_quality=quality, evidence=ledger.all(),
            news_summary=news_summary, conclusions=conclusions,
            risks=_unique(risks)[:10], counterpoints=_unique(counterpoints)[:8],
            methodology=methodology, warnings=warnings[:20], disclaimer=DISCLAIMER,
        )
        return report

    def analyze_dataset(self, path_or_dataset: Any, symbol: str = "",
                        asset_type: str = "", mapping: Optional[Dict[str, str]] = None,
                        question: str = "",
                        benchmark: Optional[PriceSeries] = None) -> ResearchReport:
        if isinstance(path_or_dataset, Dataset):
            dataset = path_or_dataset
        else:
            dataset = DatasetLoader.load(str(path_or_dataset))
        if not symbol:
            symbol = Path(dataset.name).stem
        inferred_market, clean, inferred_type = infer_market(symbol)
        asset_type = (asset_type or inferred_type).lower()
        if asset_type in ("etf", "lof"):
            asset_type = "fund"
        series = DatasetLoader.to_price_series(dataset, symbol, asset_type=asset_type,
                                               market=inferred_market, mapping=mapping)
        quote = MarketQuote(symbol=symbol, asset_type=asset_type, market=inferred_market,
                            price=series.last, timestamp=series.as_of, source=series.source,
                            freshness="closing", quality=series.quality,
                            warnings=["用户数据最后一条记录作为当前价格，非实时报价"])
        news: List[Dict[str, Any]] = []
        for rec in dataset.records[:50]:
            title = rec.get("title") or rec.get("headline") or rec.get("标题")
            content = rec.get("content") or rec.get("summary") or rec.get("正文") or rec.get("内容")
            if title or content:
                news.append({"title": title or "", "content": content or "",
                             "source": rec.get("source") or rec.get("来源") or dataset.name,
                             "public_date": rec.get("date") or rec.get("time") or ""})
        fund_snapshot = None
        if asset_type == "fund":
            fund_type = "otc"
            fund_snapshot = FundSnapshot(
                code=clean, official_nav=series.last, nav_date=series.as_of,
                fund_type=fund_type, source=series.source, quality="derived",
                warnings=["用户净值文件被视作官方净值的本地副本，需自行确认来源"],
            )
        futures_curve = None
        if asset_type == "futures":
            spot_mapping = (mapping or {}).get("spot") or dataset.mapping.get("spot")
            spot = None
            if spot_mapping:
                from stock_researcher.research_contracts import safe_float as _sf
                spot = _sf(dataset.records[-1].get(spot_mapping), None)
            from stock_researcher.research_contracts import FuturesContract
            from stock_researcher.research_data import FuturesDataClient
            futures_curve = FuturesCurve(
                product=FuturesDataClient.product(clean),
                contracts=[FuturesContract(
                    contract=clean, product=FuturesDataClient.product(clean),
                    price=series.last, days_to_expiry=FuturesDataClient.days_to_expiry(clean),
                    source=series.source, quality="derived")],
                spot_price=spot, source=series.source, quality="derived",
            )
        collected = CollectedData(
            symbol=symbol, asset_type=asset_type, market=inferred_market,
            quote=quote, history=series, fund_snapshot=fund_snapshot,
            futures_curve=futures_curve, news=news,
            sources=[series.source], warnings=list(series.warnings),
            extras={"data_cutoff": series.as_of, "dataset": dataset.to_dict(),
                    "clean_symbol": clean},
        )
        return self.analyze(symbol, question=question, asset_type=asset_type,
                            market=inferred_market, data=collected,
                            benchmark=benchmark)

    def refresh_quotes(self, symbols: Sequence[str], interval: float = 0.0,
                       iterations: int = 1) -> List[Dict[str, Any]]:
        """有界实时刷新（不启动常驻线程）；仅返回公开行情与质量标记。"""
        snapshots: List[Dict[str, Any]] = []
        previous: Dict[str, float] = {}
        for idx in range(max(1, int(iterations))):
            for symbol in symbols:
                market, clean, asset_type = infer_market(symbol)
                try:
                    quote = self.provider.get_quote(symbol, asset_type, market)
                except Exception as exc:
                    snapshots.append({"symbol": symbol, "success": False,
                                      "error": str(exc)[:160], "as_of": now_iso()})
                    continue
                prev = previous.get(symbol)
                tick_change = ((quote.price - prev) / prev * 100
                               if quote and quote.valid and prev else None)
                if quote and quote.valid:
                    previous[symbol] = quote.price
                snapshots.append({
                    "symbol": symbol, "success": bool(quote and quote.valid),
                    "name": quote.name if quote else "", "price": quote.price if quote else None,
                    "change_pct": quote.change_pct if quote else None,
                    "tick_change_pct": round(tick_change, 4) if tick_change is not None else None,
                    "source": quote.source if quote else "",
                    "timestamp": quote.timestamp if quote else now_iso(),
                    "freshness": quote.freshness if quote else "unavailable",
                    "quality": quote.quality if quote else "unavailable",
                    "error": "" if quote and quote.valid else "报价不可用",
                })
            if interval > 0 and idx < iterations - 1:
                time.sleep(interval)
        return snapshots

    def doctor(self, offline: bool = True) -> Dict[str, Any]:
        checks: Dict[str, Any] = {}
        checks["python"] = {"ok": True, "value": __import__("sys").version.split()[0]}
        optional = {}
        for name in ("numpy", "pandas", "openpyxl", "pypdf", "yfinance", "akshare", "mcp"):
            try:
                mod = __import__(name)
                optional[name] = {"available": True,
                                  "version": getattr(mod, "__version__", "unknown")}
            except Exception:
                optional[name] = {"available": False, "version": None}
        checks["optional_dependencies"] = optional
        try:
            prices = [100.0 * (1.0008 ** i) * (1 + 0.02 * math.sin(i / 5))
                      for i in range(200)]
            forecasts = self.forecaster.forecast_multi(prices)
            checks["forecast_engine"] = {"ok": len(forecasts) == 5,
                                         "horizons": [f.horizon for f in forecasts],
                                         "abstain": [f.horizon for f in forecasts if f.abstain]}
        except Exception as exc:
            checks["forecast_engine"] = {"ok": False, "error": str(exc)[:200]}
        try:
            from stock_researcher.research_contracts import EvidenceLedger, PriceSeries
            ledger = EvidenceLedger()
            series = PriceSeries(symbol="TEST", closes=[100 + i * 0.2 for i in range(130)],
                                 source="self_test")
            bundle = ResearchAnalyzer(ledger).technical(series)
            checks["factor_engine"] = {"ok": bool(bundle.factors),
                                       "factor_count": len(bundle.factors),
                                       "evidence_count": len(ledger)}
        except Exception as exc:
            checks["factor_engine"] = {"ok": False, "error": str(exc)[:200]}
        checks["dataset_loader"] = {"ok": True,
                                    "formats": list(DatasetLoader.SUPPORTED)}
        checks["network"] = {
            "checked": False,
            "note": "doctor 不发起网络请求；数据源实时可用性请用 list_data_sources 或 data_multi_source.self_check()",
        }
        hard_ok = checks["forecast_engine"].get("ok") and checks["factor_engine"].get("ok")
        return {"status": "ok" if hard_ok else "degraded",
                "version": APP_VERSION, "schema_version": SCHEMA_VERSION,
                "offline": bool(offline), "checks": checks,
                "disclaimer": DISCLAIMER}

    @staticmethod
    def to_markdown(report: ResearchReport) -> str:
        return report_to_markdown(report)

    @staticmethod
    def to_json(report: ResearchReport) -> str:
        return report.to_json()



def quick_research(symbol: str, question: str = "", asset_type: Optional[str] = None,
                   market: Optional[str] = None, history_days: int = 250,
                   include_news: bool = True, include_flow: bool = True,
                   include_fundamentals: bool = True,
                   overrides: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """便捷入口：返回可直接 JSON 序列化的研究结果。"""
    report = ResearchHub().analyze(
        symbol, question=question, asset_type=asset_type, market=market,
        history_days=history_days, include_news=include_news,
        include_flow=include_flow, include_fundamentals=include_fundamentals,
        overrides=overrides,
    )
    return report.to_dict()


def research_report(symbol: str, **kwargs: Any) -> ResearchReport:
    """返回完整 ResearchReport 对象。"""
    return ResearchHub().analyze(symbol, **kwargs)
