﻿# -*- coding: utf-8 -*-
"""v12.0 Research Analysis."""
from __future__ import annotations
import math
import re
import statistics
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from stock_researcher.research_contracts import (
    EvidenceLedger, Factor, ForecastDistribution, FundSnapshot, FuturesCurve,
    MarketQuote, NewsItem, PriceSeries, Scenario, clamp, finite, now_iso,
    pct, percentile, safe_float, stable_hash, to_iso,
)

HORIZON_LABELS: Tuple[Tuple[str, int], ...] = (
    ("1d", 1), ("5d", 5), ("1M", 21), ("3M", 63), ("6M", 126),
)

def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _stdev(values: Sequence[float]) -> float:
    return statistics.stdev(values) if len(values) >= 2 else 0.0


def _simple_returns(prices: Sequence[float]) -> List[float]:
    return [prices[i] / prices[i - 1] - 1.0 for i in range(1, len(prices))
            if prices[i - 1] and prices[i - 1] > 0]


def _log_returns(prices: Sequence[float]) -> List[float]:
    return [math.log(prices[i] / prices[i - 1]) for i in range(1, len(prices))
            if prices[i - 1] > 0 and prices[i] > 0]


def _ema(values: Sequence[float], span: int) -> List[float]:
    if not values:
        return []
    alpha = 2.0 / (span + 1.0)
    out = [float(values[0])]
    for value in values[1:]:
        out.append(alpha * float(value) + (1 - alpha) * out[-1])
    return out


def _sma(values: Sequence[float], window: int) -> Optional[float]:
    if len(values) < window or window <= 0:
        return None
    return sum(values[-window:]) / window


def _rsi(prices: Sequence[float], window: int = 14) -> Optional[float]:
    if len(prices) < window + 1:
        return None
    gains, losses = [], []
    for i in range(-window, 0):
        change = prices[i] - prices[i - 1]
        gains.append(max(0.0, change))
        losses.append(max(0.0, -change))
    avg_gain = sum(gains) / window
    avg_loss = sum(losses) / window
    if avg_loss <= 1e-12:
        return 100.0 if avg_gain > 0 else 50.0
    rs = avg_gain / avg_loss
    return 100.0 - 100.0 / (1.0 + rs)

def _atr(highs: Sequence[float], lows: Sequence[float], closes: Sequence[float],
         window: int = 14) -> Optional[float]:
    n = min(len(highs), len(lows), len(closes))
    if n < window + 1:
        return None
    trs = []
    for i in range(n - window, n):
        h, l, pc = highs[i], lows[i], closes[i - 1]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    return sum(trs) / len(trs) if trs else None


def _max_drawdown(prices: Sequence[float]) -> Tuple[float, int, bool]:
    if not prices:
        return 0.0, 0, False
    peak = prices[0]
    peak_idx = 0
    max_dd = 0.0
    max_days = 0
    trough_idx = 0
    for i, price in enumerate(prices):
        if price > peak:
            peak = price
            peak_idx = i
        dd = (price - peak) / peak * 100 if peak else 0.0
        if dd < max_dd:
            max_dd = dd
            max_days = i - peak_idx
            trough_idx = i
    recovered = prices[-1] >= peak if trough_idx < len(prices) - 1 else False
    return max_dd, max_days, recovered


def _annualized_return(prices: Sequence[float]) -> Optional[float]:
    if len(prices) < 2 or prices[0] <= 0:
        return None
    days = max(1, len(prices) - 1)
    return ((prices[-1] / prices[0]) ** (252.0 / days) - 1.0) * 100.0


def _annualized_vol(returns: Sequence[float], window: int = 20) -> Optional[float]:
    if len(returns) < 2:
        return None
    seg = returns[-window:] if len(returns) >= window else returns
    return _stdev(seg) * math.sqrt(252.0) * 100.0


def _sharpe(returns: Sequence[float], rf: float = 0.02) -> Optional[float]:
    if len(returns) < 5:
        return None
    mean = _mean(returns) * 252.0
    vol = _stdev(returns) * math.sqrt(252.0)
    return (mean - rf) / vol if vol > 1e-12 else None


def _sortino(returns: Sequence[float], rf: float = 0.02) -> Optional[float]:
    if len(returns) < 5:
        return None
    mean = _mean(returns) * 252.0
    downside = [min(0.0, r) for r in returns]
    dd = math.sqrt(sum(x * x for x in downside) / len(downside)) * math.sqrt(252.0)
    return (mean - rf) / dd if dd > 1e-12 else None

def _skew(values: Sequence[float]) -> Optional[float]:
    if len(values) < 3:
        return None
    m = _mean(values)
    sd = _stdev(values)
    if sd <= 1e-12:
        return 0.0
    return sum(((x - m) / sd) ** 3 for x in values) / len(values)


def _kurt(values: Sequence[float]) -> Optional[float]:
    if len(values) < 4:
        return None
    m = _mean(values)
    sd = _stdev(values)
    if sd <= 1e-12:
        return 0.0
    return sum(((x - m) / sd) ** 4 for x in values) / len(values) - 3.0


def _var(returns: Sequence[float], q: float = 5.0) -> Optional[float]:
    v = percentile(list(returns), q)
    if v is None:
        return None
    return max(0.0, -v * 100.0)


def _beta_alpha(asset_returns: Sequence[float],
                benchmark_returns: Sequence[float]) -> Tuple[Optional[float], Optional[float]]:
    n = min(len(asset_returns), len(benchmark_returns))
    if n < 10:
        return None, None
    a, b = asset_returns[-n:], benchmark_returns[-n:]
    ma, mb = _mean(a), _mean(b)
    cov = sum((x - ma) * (y - mb) for x, y in zip(a, b)) / (n - 1)
    var_b = sum((y - mb) ** 2 for y in b) / (n - 1)
    beta = cov / var_b if var_b > 1e-15 else None
    alpha = (ma - beta * mb) * 252 * 100 if beta is not None else None
    return beta, alpha


def compute_technical_metrics(series: PriceSeries) -> Dict[str, Any]:
    """计算技术/风险指标；缺失值保留 None，不填造。"""
    prices = list(series.closes)
    if len(prices) < 2:
        return {"available": False, "sample_size": len(prices),
                "warning": "价格序列不足"}
    returns = _simple_returns(prices)
    highs = series.highs if len(series.highs) == len(prices) else prices
    lows = series.lows if len(series.lows) == len(prices) else prices
    volumes = series.volumes if len(series.volumes) == len(prices) else []
    current = prices[-1]
    ma5, ma20, ma60 = _sma(prices, 5), _sma(prices, 20), _sma(prices, 60)
    ema12, ema26 = _ema(prices, 12), _ema(prices, 26)
    macd_line = ema12[-1] - ema26[-1] if ema12 and ema26 else None
    macd_series = [a - b for a, b in zip(ema12, ema26)] if ema12 and ema26 else []
    macd_signal = _ema(macd_series, 9)[-1] if len(macd_series) >= 9 else None
    macd_hist = macd_line - macd_signal if macd_line is not None and macd_signal is not None else None
    rsi14 = _rsi(prices, 14)
    atr14 = _atr(highs, lows, prices, 14)
    vol20 = _annualized_vol(returns, 20)
    vol60 = _annualized_vol(returns, 60)
    bb_window = 20
    if len(prices) >= bb_window:
        mid = sum(prices[-bb_window:]) / bb_window
        sd = _stdev(prices[-bb_window:])
        bb_upper, bb_lower = mid + 2 * sd, mid - 2 * sd
    else:
        mid = bb_upper = bb_lower = None
    max_dd, dd_days, recovered = _max_drawdown(prices)
    ann_ret = _annualized_return(prices)
    sharpe = _sharpe(returns)
    sortino = _sortino(returns)
    mom5 = pct(current - prices[-6], prices[-6]) if len(prices) >= 6 else None
    mom20 = pct(current - prices[-21], prices[-21]) if len(prices) >= 21 else None
    mom60 = pct(current - prices[-61], prices[-61]) if len(prices) >= 61 else None
    vol_ratio = None
    if len(volumes) >= 21:
        recent = sum(volumes[-5:]) / 5
        base = sum(volumes[-20:]) / 20
        vol_ratio = recent / base if base > 0 else None
    return {
        "available": True, "sample_size": len(prices), "current": current,
        "ma5": ma5, "ma20": ma20, "ma60": ma60,
        "macd": macd_line, "macd_signal": macd_signal, "macd_hist": macd_hist,
        "rsi14": rsi14, "atr14": atr14,
        "boll_mid": mid, "boll_upper": bb_upper, "boll_lower": bb_lower,
        "annual_return_pct": ann_ret,
        "annual_vol20_pct": vol20, "annual_vol60_pct": vol60,
        "sharpe": sharpe, "sortino": sortino,
        "max_drawdown_pct": max_dd, "max_drawdown_days": dd_days,
        "drawdown_recovered": recovered,
        "var95_pct": _var(returns, 5), "skewness": _skew(returns),
        "excess_kurtosis": _kurt(returns),
        "momentum_5d_pct": mom5, "momentum_20d_pct": mom20,
        "momentum_60d_pct": mom60, "volume_ratio_5_20": vol_ratio,
        "calmar": (ann_ret / abs(max_dd)) if ann_ret is not None and max_dd < 0 else None,
    }

@dataclass
class AnalysisBundle:
    score: float = 0.0
    confidence: float = 0.0
    factors: List[Factor] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)
    conflicts: List[str] = field(default_factory=list)
    specialized: Dict[str, Any] = field(default_factory=dict)
    quality: str = "insufficient"


class ResearchAnalyzer:
    """行情、资金、基本面、新闻、基金与期货的统一分析器。"""

    def __init__(self, ledger: EvidenceLedger) -> None:
        self.ledger = ledger

    def _factor(self, name: str, category: str, score: float, weight: float,
                confidence: float, rationale: str, evidence_title: str,
                evidence_value: Any, source: str, quality: str = "actual",
                reliability: str = "medium") -> Factor:
        eid = self.ledger.add(
            kind=category, title=evidence_title, value=evidence_value,
            source=source, quality=quality, reliability=reliability,
            observed_at=now_iso(),
        )
        return Factor(name=name, category=category, score=score, weight=weight,
                      confidence=confidence, rationale=rationale,
                      evidence_ids=[eid], quality=quality)

    @staticmethod
    def weighted_score(factors: Sequence[Factor]) -> Tuple[float, float]:
        if not factors:
            return 0.0, 0.0
        total_w = sum(max(0.0, f.weight) * max(0.1, f.confidence) for f in factors)
        if total_w <= 0:
            return 0.0, 0.0
        score = sum(f.score * f.weight * max(0.1, f.confidence) for f in factors) / total_w
        agreement = 1.0 - min(1.0, abs(sum(1 if f.score > 10 else -1 if f.score < -10 else 0
                                         for f in factors)) / max(1, len(factors)))
        confidence = clamp(0.35 + 0.45 * (sum(f.confidence for f in factors) / len(factors))
                           + 0.20 * (1.0 - agreement), 0.0, 0.95)
        return round(score, 1), round(confidence, 3)

    def technical(self, series: PriceSeries, asset_type: str = "stock") -> AnalysisBundle:
        metrics = compute_technical_metrics(series)
        if not metrics.get("available"):
            return AnalysisBundle(warnings=["价格序列不足，技术分析不可用"],
                                  quality="insufficient", metrics=metrics)
        if metrics.get("sample_size", 0) < 20:
            return AnalysisBundle(
                warnings=[f"价格样本仅 {metrics.get('sample_size', 0)} 条，技术因子不足以形成结论"],
                metrics=metrics, quality="insufficient",
                specialized={"minimum_history": 20},
            )
        factors: List[Factor] = []
        src = series.source or "price_series"
        n = metrics["sample_size"]
        current = metrics["current"]
        ma20, ma60 = metrics.get("ma20"), metrics.get("ma60")
        trend_score = 0.0
        if ma20:
            trend_score += 25 if current >= ma20 else -25
        if ma60:
            trend_score += 25 if current >= ma60 else -25
        if ma20 and ma60:
            trend_score += 25 if ma20 >= ma60 else -25
        if metrics.get("ma5") and ma20 and metrics["ma5"] >= ma20:
            trend_score += 15
        factors.append(self._factor(
            "趋势结构", "technical", clamp(trend_score, -100, 100), 0.28, 0.8,
            f"现价 {current:.2f}，MA20={ma20 or '—'}，MA60={ma60 or '—'}",
            "均线趋势", {"current": current, "ma20": ma20, "ma60": ma60},
            src, quality="actual" if n >= 60 else "derived",
        ))
        mom20 = metrics.get("momentum_20d_pct")
        if mom20 is not None:
            mom_score = clamp((mom20 or 0) * 4 + (metrics.get("momentum_5d_pct") or 0) * 1.2,
                              -100, 100)
            factors.append(self._factor(
                "动量", "technical", mom_score, 0.22, 0.75,
                f"20日动量 {mom20:+.2f}%，5日动量 {(metrics.get('momentum_5d_pct') or 0):+.2f}%",
                "价格动量", {"mom20": mom20, "mom5": metrics.get("momentum_5d_pct")},
                src, quality="derived",
            ))
        if metrics.get("macd_hist") is not None:
            hist = metrics["macd_hist"]
            macd_score = clamp(hist / max(1e-9, abs(current) * 0.01) * 25, -100, 100)
            factors.append(self._factor(
                "MACD", "technical", macd_score, 0.15, 0.65,
                f"MACD柱 {hist:+.4f}", "MACD", {"macd": metrics.get("macd"), "hist": hist},
                src, quality="derived",
            ))
        if metrics.get("rsi14") is not None:
            rsi = metrics["rsi14"]
            if rsi >= 80:
                rsi_score = -35.0
            elif rsi >= 55:
                rsi_score = 25.0
            elif rsi <= 20:
                rsi_score = 20.0
            elif rsi <= 35:
                rsi_score = -15.0
            else:
                rsi_score = 0.0
            factors.append(self._factor(
                "RSI", "technical", rsi_score, 0.10, 0.6,
                f"RSI14 {rsi:.1f}", "RSI", {"rsi14": rsi}, src, quality="derived",
            ))
        vol = metrics.get("annual_vol20_pct")
        if vol is not None:
            vol_score = clamp(30 - vol, -60, 30)
            factors.append(self._factor(
                "波动率", "risk", vol_score, 0.15, 0.7,
                f"年化波动率 {vol:.1f}%，95% VaR {metrics.get('var95_pct') or 0:.2f}%",
                "波动风险", {"annual_vol20_pct": vol, "var95_pct": metrics.get("var95_pct")},
                src, quality="derived",
            ))
        vol_ratio = metrics.get("volume_ratio_5_20")
        if vol_ratio is not None:
            direction = 1 if (mom20 or 0) >= 0 else -1
            factors.append(self._factor(
                "量价配合", "technical", clamp((vol_ratio - 1) * 70 * direction, -100, 100),
                0.10, 0.55, f"5/20日量比 {vol_ratio:.2f}",
                "成交量比率", {"volume_ratio_5_20": vol_ratio}, src, quality="derived",
            ))
        score, confidence = self.weighted_score(factors)
        quality = "actual" if n >= 120 and series.quality == "actual" else "derived" if n >= 60 else "estimated"
        risks = []
        if vol is not None and vol >= 35:
            risks.append(f"年化波动率较高({vol:.1f}%)，仓位应控制")
        if metrics.get("max_drawdown_pct", 0) <= -20:
            risks.append(f"历史最大回撤 {metrics['max_drawdown_pct']:.1f}%")
        if metrics.get("rsi14") and metrics["rsi14"] >= 80:
            risks.append("RSI 处于超买区，短期回撤风险上升")
        return AnalysisBundle(score=score, confidence=confidence, factors=factors,
                              metrics=metrics, warnings=list(series.warnings),
                              risks=risks, quality=quality,
                              specialized={"asset_type": asset_type})

    def news(self, raw_news: Sequence[Dict[str, Any]], symbol: str,
             question: str = "") -> AnalysisBundle:
        if not raw_news:
            return AnalysisBundle(warnings=["未获取到新闻/公告文本"], quality="unavailable",
                                  specialized={"news_items": [], "summary": {}})
        items: List[NewsItem] = []
        seen_titles: set = set()
        seen_shingles: List[set] = []
        duplicates = 0
        for raw in raw_news[:100]:
            if not isinstance(raw, dict):
                continue
            title = str(raw.get("title") or raw.get("headline") or "").strip()
            body = str(raw.get("content") or raw.get("summary") or raw.get("digest") or "")
            if not title and not body:
                continue
            norm = _normalize_title(title or body[:80])
            sh = _shingles(title or body[:200])
            if norm in seen_titles or any(_jaccard(sh, prev) >= 0.86 for prev in seen_shingles[-30:]):
                duplicates += 1
                continue
            seen_titles.add(norm)
            seen_shingles.append(sh)
            text = (title + " " + body).strip()
            source = str(raw.get("source") or raw.get("media") or "unknown")
            reliability, rel_weight = _source_reliability(source)
            event_type, pos_hits, neg_hits = "other", 0, 0
            for category, (pos_words, neg_words) in NEWS_KEYWORDS.items():
                p = sum(1 for kw in pos_words if kw in text and not _negated(text, text.find(kw)))
                n = sum(1 for kw in neg_words if kw in text and not _negated(text, text.find(kw)))
                if p + n > pos_hits + neg_hits:
                    event_type, pos_hits, neg_hits = category, p, n
            strength = clamp((pos_hits - neg_hits) / max(1, pos_hits + neg_hits), -1.0, 1.0)
            direction = "positive" if strength > 0.15 else "negative" if strength < -0.15 else "neutral"
            materiality = 0.2 + 0.12 * min(4, pos_hits + neg_hits)
            materiality += 0.12 * sum(1 for kw in HIGH_IMPACT if kw in text)
            if re.search(r"\d+(\.\d+)?\s*(亿|万|百万元|%)", text):
                materiality += 0.08
            materiality = clamp(materiality, 0.0, 1.0)
            published_raw = raw.get("public_date") or raw.get("time") or raw.get("published_at")
            published = to_iso(published_raw) if published_raw else ""
            item = NewsItem(
                title=title or body[:80], summary=body[:300], published_at=published,
                source=source, url=str(raw.get("url") or ""), reliability=reliability,
                event_type=event_type, direction=direction, strength=round(strength, 3),
                materiality=round(materiality, 3),
                confidence=round(clamp(0.35 + 0.15 * min(3, pos_hits + neg_hits)
                                       + (rel_weight - 0.5) * 0.3, 0, 0.95), 3),
                evidence_span=text[:220],
                dedupe_key=stable_hash(norm, length=16),
                related_symbols=[symbol],
            )
            items.append(item)
        if not items:
            return AnalysisBundle(warnings=["新闻均被去重或过滤，无有效文本"],
                                  specialized={"news_items": [], "summary": {}})
        # 按时间与重要性排序，同时按时间衰减汇总。
        items.sort(key=lambda x: (x.published_at, x.materiality), reverse=True)
        now = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
        weighted_num = weighted_den = 0.0
        for item in items[:30]:
            dt = __import__("stock_researcher.research_contracts", fromlist=["parse_datetime"]).parse_datetime(item.published_at)
            days = max(0.0, (now - dt.astimezone(__import__("datetime").timezone.utc)).total_seconds() / 86400) if dt else 3.0
            decay = math.exp(-days / 14.0)
            rel = {"official": 1.0, "high": 0.88, "medium": 0.72, "low": 0.45}.get(item.reliability, 0.6)
            w = max(0.02, item.materiality * rel * decay)
            weighted_num += item.strength * w
            weighted_den += w
        aggregate = weighted_num / weighted_den if weighted_den else 0.0
        positive = sum(1 for x in items if x.direction == "positive")
        negative = sum(1 for x in items if x.direction == "negative")
        confidence = clamp(0.3 + 0.08 * min(8, len(items))
                           + (0.15 if positive + negative >= 3 else 0.0), 0.0, 0.92)
        score = clamp(aggregate * 100, -100, 100)
        top = items[:5]
        evidence_value = " | ".join(f"{x.title}({x.direction},{x.materiality:.2f})" for x in top)
        factor = self._factor(
            "新闻/公告事件", "news", score, 0.15, confidence,
            f"有效文本 {len(items)} 条，正/负/中性={positive}/{negative}/{len(items)-positive-negative}，"
            f"去重 {duplicates} 条，加权情绪 {aggregate:+.2f}",
            "新闻事件汇总", evidence_value, ",".join(sorted({x.source for x in items})),
            quality="actual", reliability="medium",
        )
        conflicts = []
        if positive and negative and min(positive, negative) / max(positive, negative) >= 0.5:
            conflicts.append(f"新闻方向冲突：正面 {positive} 条，负面 {negative} 条")
        summary = {
            "total_raw": len(raw_news), "deduped": len(items),
            "duplicates_removed": duplicates, "positive": positive,
            "negative": negative, "neutral": len(items) - positive - negative,
            "weighted_sentiment": round(aggregate, 3),
            "top_events": [x.to_dict() for x in top],
            "sources": sorted({x.source for x in items}),
            "conflict": bool(conflicts),
        }
        risks = []
        if aggregate < -0.15:
            risks.append("新闻/公告整体偏负面，需核查事件是否已充分定价")
        if any(x.event_type == "风险" for x in items[:5]):
            risks.append("近期出现诉讼/违约/监管处罚等硬风险事件")
        return AnalysisBundle(score=score, confidence=confidence, factors=[factor],
                              risks=risks, conflicts=conflicts,
                              quality="actual" if len(items) >= 3 else "derived",
                              specialized={"news_items": [x.to_dict() for x in items[:30]],
                                           "summary": summary})

    def money_flow(self, flow: Dict[str, Any], symbol: str) -> AnalysisBundle:
        if not flow:
            return AnalysisBundle(warnings=["资金流数据不可用"], quality="unavailable")
        main_net = safe_float(flow.get("main_net_flow", flow.get("main_net")), None)
        ratio = safe_float(flow.get("flow_ratio"), None)
        trend = flow.get("trend")
        if ratio is not None:
            score = clamp(ratio * 18, -100, 100)
            confidence = 0.75
            rationale = f"主力净流入 {main_net if main_net is not None else '—'} 万元，净流入占比 {ratio:.3f}%"
        elif main_net is not None:
            score = 35.0 if main_net > 0 else -35.0 if main_net < 0 else 0.0
            if trend == "inflow":
                score += 15
            elif trend == "outflow":
                score -= 15
            confidence = 0.55
            rationale = f"主力净流入 {main_net:+.2f} 万元（未取得流通市值占比，置信度降级）"
        else:
            return AnalysisBundle(warnings=["资金流字段缺失"], quality="unavailable")
        quality = str(flow.get("quality") or "actual")
        factor = self._factor(
            "主力资金", "flow", score, 0.20, confidence, rationale,
            "资金流向", {k: flow.get(k) for k in
                       ("main_net_flow", "flow_ratio", "trend", "unit", "date")},
            str(flow.get("source") or "money_flow"),
            quality=quality if quality in ("actual", "derived", "estimated") else "derived",
        )
        risks = []
        if main_net is not None and main_net < 0:
            risks.append("主力资金呈净流出，反弹持续性需验证")
        return AnalysisBundle(score=score, confidence=confidence, factors=[factor],
                              metrics=dict(flow), risks=risks, quality=quality,
                              specialized={"money_flow": flow})

    def fundamentals(self, data: Dict[str, Any], symbol: str) -> AnalysisBundle:
        if not data:
            return AnalysisBundle(warnings=["基本面/财务数据不可用"], quality="unavailable")
        flat = _flatten_mapping(data)
        metrics = {
            "roe": _find_metric(flat, ("roe", "加权roe", "净资产收益率", "加权净资产收益率")),
            "revenue_yoy": _find_metric(flat, ("revenue_yoy", "营收同比", "营业收入同比增长", "营业收入同比")),
            "profit_yoy": _find_metric(flat, ("profit_yoy", "net_profit_yoy", "净利润同比", "归母净利润同比", "净利润同比增长")),
            "gross_margin": _find_metric(flat, ("gross_margin", "毛利率", "销售毛利率")),
            "debt_ratio": _find_metric(flat, ("debt_ratio", "资产负债率")),
            "pe": _find_metric(flat, ("pe", "pe_ttm", "市盈率", "市盈率ttm")),
            "pb": _find_metric(flat, ("pb", "市净率")),
            "pe_percentile": _find_metric(flat, ("pe_percentile", "pe分位", "市盈率分位", "估值分位")),
        }
        factors: List[Factor] = []
        if metrics["roe"] is not None or metrics["gross_margin"] is not None:
            roe_score = clamp(((metrics["roe"] or 0) - 8) * 4, -60, 80)
            margin_score = clamp(((metrics["gross_margin"] or 0) - 20) * 1.5, -40, 40)
            score = clamp(0.6 * roe_score + 0.4 * margin_score, -100, 100)
            factors.append(self._factor(
                "盈利能力", "fundamental", score, 0.25, 0.75,
                f"ROE={metrics['roe'] if metrics['roe'] is not None else '—'}%，"
                f"毛利率={metrics['gross_margin'] if metrics['gross_margin'] is not None else '—'}%",
                "盈利指标", {k: metrics[k] for k in ("roe", "gross_margin")},
                "financial_data", quality="actual",
            ))
        growth_vals = [v for v in (metrics["revenue_yoy"], metrics["profit_yoy"]) if v is not None]
        if growth_vals:
            avg_growth = _mean(growth_vals)
            factors.append(self._factor(
                "成长性", "fundamental", clamp(avg_growth * 2.5, -100, 100), 0.25, 0.7,
                f"营收/利润增速均值 {avg_growth:+.1f}%",
                "成长指标", {"revenue_yoy": metrics["revenue_yoy"], "profit_yoy": metrics["profit_yoy"]},
                "financial_data", quality="actual",
            ))
        if metrics["debt_ratio"] is not None:
            debt = metrics["debt_ratio"]
            factors.append(self._factor(
                "资产负债", "fundamental", clamp((55 - debt) * 2, -100, 70), 0.15, 0.65,
                f"资产负债率 {debt:.1f}%", "杠杆指标", {"debt_ratio": debt},
                "financial_data", quality="actual",
            ))
        if metrics["pe_percentile"] is not None:
            p = metrics["pe_percentile"]
            factors.append(self._factor(
                "估值分位", "valuation", clamp((50 - p) * 1.6, -100, 100), 0.25, 0.7,
                f"PE 历史分位 {p:.0f}%", "估值分位", {"pe_percentile": p, "pe": metrics["pe"]},
                "valuation_data", quality="derived",
            ))
        if not factors:
            return AnalysisBundle(warnings=["未识别到可用财务/估值字段"],
                                  metrics=metrics, quality="unavailable")
        score, confidence = self.weighted_score(factors)
        quality = "actual" if len(factors) >= 3 else "derived"
        risks = []
        if metrics["debt_ratio"] is not None and metrics["debt_ratio"] > 70:
            risks.append(f"资产负债率偏高({metrics['debt_ratio']:.1f}%)")
        if metrics["profit_yoy"] is not None and metrics["profit_yoy"] < 0:
            risks.append(f"净利润同比下滑({metrics['profit_yoy']:+.1f}%)")
        return AnalysisBundle(score=score, confidence=confidence, factors=factors,
                              metrics=metrics, risks=risks, quality=quality,
                              specialized={"fundamentals": metrics})

    def fund(self, snapshot: Optional[FundSnapshot], series: PriceSeries,
             benchmark: Optional[PriceSeries] = None) -> AnalysisBundle:
        metrics = compute_technical_metrics(series) if series and series.usable else {"available": False}
        factors: List[Factor] = []
        warnings: List[str] = []
        risks: List[str] = []
        fund_type = snapshot.fund_type if snapshot else ""
        if fund_type == "otc":
            warnings.append("场外基金无实时净值；盘中估值仅作参考，申购赎回以基金公司确认净值为准")
        if metrics.get("available"):
            score = clamp((metrics.get("sharpe") or 0) * 24
                          + (metrics.get("annual_return_pct") or 0) * 1.2
                          + (metrics.get("max_drawdown_pct") or 0) * 1.1,
                          -100, 100)
            factors.append(self._factor(
                "基金绩效", "fund", score, 0.45,
                0.75 if metrics.get("sample_size", 0) >= 120 else 0.55,
                f"年化收益 {metrics.get('annual_return_pct') or 0:+.1f}%，"
                f"Sharpe {metrics.get('sharpe') or 0:.2f}，最大回撤 {metrics.get('max_drawdown_pct') or 0:.1f}%",
                "基金绩效指标", {k: metrics.get(k) for k in
                             ("annual_return_pct", "sharpe", "sortino", "max_drawdown_pct")},
                series.source or "fund_nav", quality=series.quality,
            ))
            if metrics.get("max_drawdown_pct", 0) <= -20:
                risks.append(f"历史最大回撤 {metrics['max_drawdown_pct']:.1f}%，需匹配自身风险承受力")
        if benchmark and benchmark.usable and series and series.usable:
            ar = _simple_returns(series.closes)
            br = _simple_returns(benchmark.closes)
            n = min(len(ar), len(br))
            if n >= 10:
                active = [a - b for a, b in zip(ar[-n:], br[-n:])]
                te = _stdev(active) * math.sqrt(252) * 100
                info_ratio = _mean(active) / _stdev(active) * math.sqrt(252) if _stdev(active) > 1e-12 else None
                beta, alpha = _beta_alpha(ar, br)
                metrics.update({"tracking_error_pct": te, "information_ratio": info_ratio,
                                "beta": beta, "alpha_annual_pct": alpha,
                                "benchmark": benchmark.symbol})
                cross_score = clamp((info_ratio or 0) * 25 + (alpha or 0) * 1.5, -100, 100)
                factors.append(self._factor(
                    "相对基准", "fund", cross_score, 0.30, 0.7,
                    f"跟踪误差 {te:.2f}%，信息比率 {info_ratio if info_ratio is not None else '—'}，"
                    f"Alpha {alpha if alpha is not None else '—'}",
                    "基金相对基准", {"tracking_error_pct": te, "information_ratio": info_ratio,
                                   "beta": beta, "alpha_annual_pct": alpha},
                    benchmark.source or "benchmark", quality="derived",
                ))
        if snapshot and snapshot.premium_pct is not None:
            premium = snapshot.premium_pct
            metrics.update({"premium_pct": premium,
                            "market_price": snapshot.market_price,
                            "iopv": snapshot.iopv})
            factors.append(self._factor(
                "折溢价", "fund", clamp(-premium * 8, -70, 70), 0.20, 0.65,
                f"ETF 市价相对 IOPV 折溢价 {premium:+.2f}%",
                "ETF折溢价", {"premium_pct": premium, "market_price": snapshot.market_price,
                            "iopv": snapshot.iopv},
                snapshot.source or "fund_quote", quality="actual",
            ))
            if abs(premium) >= 2:
                risks.append("ETF 折溢价偏高，需关注流动性与跟踪误差")
        if not factors:
            return AnalysisBundle(warnings=warnings + ["基金净值/估值数据不足"],
                                  metrics=metrics, quality="insufficient",
                                  specialized={"fund_type": fund_type})
        score, confidence = self.weighted_score(factors)
        quality = "actual" if metrics.get("sample_size", 0) >= 120 and series.quality == "actual" else "derived"
        return AnalysisBundle(score=score, confidence=confidence, factors=factors,
                              metrics=metrics, warnings=warnings + list(series.warnings),
                              risks=risks, quality=quality,
                              specialized={"fund_type": fund_type,
                                           "fund_snapshot": snapshot.to_dict() if snapshot else None})

    def futures(self, curve: Optional[FuturesCurve], series: PriceSeries,
                spot_price: Optional[float] = None,
                open_interest_history: Optional[Sequence[float]] = None) -> AnalysisBundle:
        factors: List[Factor] = []
        metrics: Dict[str, Any] = {}
        warnings: List[str] = []
        risks: List[str] = []
        if curve and curve.contracts:
            term = _term_structure(curve.contracts)
            metrics.update(term)
            front = curve.contracts[0]
            metrics["front_contract"] = front.contract
            metrics["front_price"] = front.price
            metrics["open_interest"] = term.get("front_open_interest")
            if term.get("annualized_roll_pct") is not None:
                roll = term["annualized_roll_pct"]
                factors.append(self._factor(
                    "期限结构/展期收益", "futures", clamp(roll * 4, -100, 100), 0.35, 0.75,
                    f"{term.get('structure', 'unknown')}，年化展期收益 {roll:+.2f}%",
                    "期限结构", {k: term.get(k) for k in
                              ("structure", "slope_pct", "annualized_roll_pct", "curvature")},
                    curve.source or "futures_curve", quality=curve.quality,
                ))
            spot = safe_float(spot_price if spot_price is not None else curve.spot_price, None)
            if spot and front.price:
                basis = spot - front.price
                basis_pct = basis / spot * 100
                days = front.days_to_expiry or 30
                ann_basis = basis / front.price * 365 / max(1, days) * 100
                structure = "backwardation" if basis_pct > 0.1 else "contango" if basis_pct < -0.1 else "flat"
                metrics.update({"spot_price": spot, "basis": basis,
                                "basis_pct": basis_pct, "annualized_basis_pct": ann_basis,
                                "basis_structure": structure})
                factors.append(self._factor(
                    "基差结构", "futures", clamp(ann_basis * 3, -100, 100), 0.30, 0.7,
                    f"现货-期货基差 {basis:+.2f}（{basis_pct:+.2f}%），{structure}",
                    "现货基差", {"spot": spot, "futures": front.price, "basis": basis,
                               "basis_pct": basis_pct, "annualized_basis_pct": ann_basis},
                    curve.source or "futures_curve", quality="actual",
                ))
            oi = term.get("front_open_interest")
            if oi:
                metrics["open_interest"] = oi
                factors.append(self._factor(
                    "持仓规模", "futures", 0.0, 0.10, 0.35,
                    f"近月合约持仓量 {oi:.0f}（需结合历史变化判断增仓/减仓）",
                    "持仓量", {"open_interest": oi}, curve.source or "futures_curve",
                    quality="actual",
                ))
            dt = front.days_to_expiry
            if dt is not None and dt <= 20:
                risks.append(f"近月合约剩余约 {dt} 天，展期/交割风险上升")
            if curve.contracts and not any(c.is_main for c in curve.contracts):
                warnings.append("未确认主力合约标识；期限结构可能不是主力连续")
        if open_interest_history and len(open_interest_history) >= 5:
            oi_vals = finite(open_interest_history)
            if len(oi_vals) >= 5 and oi_vals[0] > 0:
                change = (oi_vals[-1] - oi_vals[0]) / oi_vals[0] * 100
                price_change = pct(series.closes[-1] - series.closes[-5], series.closes[-5]) if len(series.closes) >= 5 else 0
                score = 0.0
                if change > 2 and price_change > 0:
                    score = 60.0
                elif change > 2 and price_change < 0:
                    score = -50.0
                elif change < -2 and price_change < 0:
                    score = 25.0
                metrics.update({"oi_change_pct": change, "oi_price_change_5d_pct": price_change})
                factors.append(self._factor(
                    "持仓量变化", "futures", score, 0.20, 0.65,
                    f"持仓量变化 {change:+.2f}%，同期价格 {price_change:+.2f}%",
                    "持仓变化", {"oi_change_pct": change, "price_change_5d_pct": price_change},
                    series.source or "futures_history", quality="actual",
                ))
        # 复用现有期货趋势模型作为交叉检查。
        try:
            from stock_researcher.quantitative_futures_analyzer import FuturesAnalyzer
            signal = FuturesAnalyzer().analyze_contract(
                curve.contracts[0].contract if curve and curve.contracts else series.symbol,
                series.closes, open_interest=list(open_interest_history) if open_interest_history else None,
                spot_prices=[spot_price] if spot_price else None)
            cross = 0.0
            if signal.direction == "long":
                cross = signal.strength
            elif signal.direction == "short":
                cross = -signal.strength
            if signal.direction != "neutral" or signal.key_points:
                factors.append(self._factor(
                    "期货趋势交叉检查", "futures", clamp(cross, -100, 100), 0.20, 0.6,
                    f"方向 {signal.direction}，强度 {signal.strength:.0f}；"
                    + "；".join(signal.key_points[:3]),
                    "期货量化信号", {"direction": signal.direction, "strength": signal.strength,
                                   "trend": signal.trend, "volatility_regime": signal.volatility_regime},
                    "quantitative_futures_analyzer", quality="derived",
                ))
            metrics["futures_signal"] = {"direction": signal.direction,
                                         "strength": signal.strength,
                                         "trend": signal.trend,
                                         "volatility_regime": signal.volatility_regime}
        except Exception:
            warnings.append("期货趋势交叉检查不可用")
        if not factors:
            return AnalysisBundle(warnings=warnings + ["期限结构、基差与持仓数据不足"],
                                  metrics=metrics, quality="insufficient")
        score, confidence = self.weighted_score(factors)
        risks.extend(["期货为保证金交易，杠杆会放大亏损", "需关注夜盘跳空、涨跌停与流动性风险"])
        return AnalysisBundle(score=score, confidence=confidence, factors=factors,
                              metrics=metrics, warnings=warnings + list(series.warnings),
                              risks=risks, quality=curve.quality if curve else "derived",
                              specialized={"futures_curve": curve.to_dict() if curve else None})


NEWS_KEYWORDS: Dict[str, Tuple[Tuple[str, ...], Tuple[str, ...]]] = {
    "业绩": (("业绩预增", "扭亏", "净利润增长", "超预期", "营收增长", "订单增长"),
             ("业绩预减", "亏损", "净利润下降", "低于预期", "营收下滑")),
    "监管": (("获批", "通过审核", "解除处罚", "合规整改完成"),
             ("立案", "处罚", "问询", "警示函", "退市", "调查", "违规", "冻结")),
    "资本运作": (("回购", "增持", "并购", "重组", "分红", "股权激励"),
                 ("减持", "质押", "商誉减值", "配股", "定增破发")),
    "经营": (("中标", "签约", "投产", "扩产", "涨价", "技术突破", "国产替代"),
             ("停产", "降价", "产能过剩", "订单取消", "客户流失")),
    "风险": (("债务重组", "风险解除", "胜诉"),
             ("诉讼", "违约", "债务危机", "暴雷", "破产", "资金链断裂", "安全事故")),
    "政策": (("降准", "降息", "补贴", "政策支持", "关税下调", "出口放宽"),
             ("加息", "监管收紧", "关税上调", "出口管制", "政策收紧")),
}
HIGH_IMPACT = ("立案", "退市", "违约", "暴雷", "破产", "并购", "重组",
               "业绩预告", "分红", "回购", "减持", "增持", "重大合同")
NEGATIONS = ("不", "未", "无", "否认", "没有", "并非", "暂不")


def _news_text(item: Dict[str, Any]) -> str:
    return " ".join(str(item.get(k) or "") for k in
                    ("title", "content", "summary", "digest"))


def _source_reliability(source: str) -> Tuple[str, float]:
    s = str(source or "").lower()
    official = ("证监会", "交易所", "央行", "人民银行", "发改委", "统计局", "财政部",
                "巨潮", "cninfo", "公司公告", "上交所", "深交所", "北交所")
    high = ("新华社", "央视", "证券时报", "中国证券报", "东方财富公告", "交易所公告", "上海证券报", "经济日报", "路透", "彭博")
    low = ("股吧", "雪球", "微博", "论坛", "自媒体", "twitter", "x.com", "reddit")
    if any(k in s for k in official):
        return "official", 1.0
    if any(k in s for k in high):
        return "high", 0.88
    if any(k in s for k in low):
        return "low", 0.45
    return "medium", 0.72


def _negated(text: str, start: int) -> bool:
    prefix = text[max(0, start - 6):start]
    return any(neg in prefix for neg in NEGATIONS)


def _normalize_title(text: str) -> str:
    return re.sub(r"[\W_]+", "", str(text).lower(), flags=re.UNICODE)


def _shingles(text: str, size: int = 2) -> set:
    clean = _normalize_title(text)
    return {clean[i:i + size] for i in range(max(0, len(clean) - size + 1))}


def _jaccard(a: set, b: set) -> float:
    return len(a & b) / len(a | b) if a and b else 0.0

def _norm_key(key: str) -> str:
    return re.sub(r"[\s_\-（）()\[\]【】:：/]+", "", str(key).lower())


def _flatten_mapping(data: Any, prefix: str = "", depth: int = 0) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if depth > 3:
        return out
    if isinstance(data, dict):
        for key, value in data.items():
            full = f"{prefix}.{key}" if prefix else str(key)
            if isinstance(value, (dict, list, tuple)):
                out.update(_flatten_mapping(value, full, depth + 1))
            else:
                out[_norm_key(key)] = value
                out[_norm_key(full)] = value
    elif isinstance(data, (list, tuple)):
        if data and all(isinstance(x, (int, float, str)) for x in data[-5:]):
            out[_norm_key(prefix)] = data[-1]
        else:
            for idx, item in enumerate(data[:5]):
                out.update(_flatten_mapping(item, f"{prefix}[{idx}]", depth + 1))
    return out


def _find_metric(flat: Dict[str, Any], aliases: Sequence[str]) -> Optional[float]:
    normalized = [_norm_key(x) for x in aliases]
    for alias in normalized:
        if alias in flat:
            val = safe_float(flat[alias], None)
            if val is not None:
                return val
    for alias in normalized:
        if len(alias) < 2:
            continue
        for key, value in flat.items():
            # 仅允许后缀匹配，避免 pe 误命中 pe_percentile 之类字段。
            if key.endswith(alias):
                val = safe_float(value, None)
                if val is not None:
                    return val
    return None


def _term_structure(contracts: Sequence[Any]) -> Dict[str, Any]:
    valid = [c for c in contracts if getattr(c, "price", None)]
    if not valid:
        return {"available": False}
    front = valid[0]
    out: Dict[str, Any] = {
        "available": True, "contracts": len(valid),
        "front_contract": front.contract, "front_price": front.price,
        "front_open_interest": front.open_interest,
        "total_open_interest": sum(c.open_interest or 0 for c in valid),
        "total_volume": sum(c.volume or 0 for c in valid),
    }
    if len(valid) >= 2:
        nxt = valid[1]
        days = (nxt.days_to_expiry or 0) - (front.days_to_expiry or 0)
        if days <= 0:
            days = 30
        slope = (nxt.price / front.price - 1.0) * 100 if front.price else None
        annualized = (front.price / nxt.price - 1.0) * 100 * 365 / days if nxt.price else None
        structure = "contango" if (slope or 0) > 0.2 else "backwardation" if (slope or 0) < -0.2 else "flat"
        out.update({"next_contract": nxt.contract, "next_price": nxt.price,
                    "calendar_days": days, "slope_pct": slope,
                    "annualized_roll_pct": annualized, "structure": structure})
        if len(valid) >= 3:
            third = valid[2]
            try:
                curvature = ((third.price - nxt.price) / front.price
                             - (nxt.price - front.price) / front.price)
                out["curvature"] = curvature * 100
            except ZeroDivisionError:
                out["curvature"] = None
    return out


def build_scenarios(forecasts: Sequence[ForecastDistribution],
                    current_price: Optional[float] = None,
                    horizon: str = "1M") -> List[Scenario]:
    """由分布分位数生成熊/基准/牛三情景，概率为区间覆盖权重。"""
    chosen = next((f for f in forecasts if f.horizon == horizon), None)
    if chosen is None and forecasts:
        chosen = forecasts[0]
    if chosen is None:
        return []
    q05 = chosen.quantiles.get("p05")
    q25 = chosen.quantiles.get("p25", q05)
    q50 = chosen.quantiles.get("p50", chosen.median_return_pct)
    q75 = chosen.quantiles.get("p75", chosen.quantiles.get("p95"))
    q95 = chosen.quantiles.get("p95")
    if q05 is None or q95 is None:
        q05, q95 = chosen.median_return_pct - 5, chosen.median_return_pct + 5
    if q25 is None:
        q25 = q05
    if q75 is None:
        q75 = q95
    def rng(low_ret: float, high_ret: float) -> Tuple[float, float]:
        if not current_price:
            return (0.0, 0.0)
        return (current_price * (1 + low_ret / 100),
                current_price * (1 + high_ret / 100))
    return [
        Scenario(name="熊市情景", probability=0.20, return_pct=q05,
                 price_range=rng(q05, q25),
                 assumptions=["波动率维持或上升", "风险偏好下降", "无额外利好催化"],
                 triggers=["跌破关键支撑", "资金持续净流出", "负面事件发酵"]),
        Scenario(name="基准情景", probability=0.60, return_pct=q50,
                 price_range=rng(q25, q75),
                 assumptions=["宏观与行业环境基本延续", "估值与盈利预期不变"],
                 triggers=["价格围绕趋势中枢震荡", "成交量维持常态"]),
        Scenario(name="牛市情景", probability=0.20, return_pct=q95,
                 price_range=rng(q75, q95),
                 assumptions=["风险偏好改善", "盈利/政策催化超预期", "资金流入增强"],
                 triggers=["放量突破关键压力", "正面事件催化"]),
    ]


class EmpiricalForecastEngine:
    """经验条件近邻概率预测器。

    - 特征：20日动量、20日已实现波动率；
    - 目标：对应周期的未来收益；
    - 输出：方向概率、分位数、区间、样本量、OOS Brier 技能分；
    - 样本不足或校准失败时 abstain=True，而不是给确定性结论。
    """

    def __init__(self, horizons: Sequence[Tuple[str, int]] = HORIZON_LABELS,
                 lookback: int = 20, min_samples: int = 20) -> None:
        self.horizons = list(horizons)
        self.lookback = max(5, int(lookback))
        self.min_samples = max(8, int(min_samples))

    def _features(self, prices: Sequence[float], t: int) -> Optional[List[float]]:
        if t < self.lookback or t >= len(prices):
            return None
        base = prices[t - self.lookback]
        if base <= 0:
            return None
        mom = (prices[t] / base - 1.0) * 100
        rets = _log_returns(prices[t - self.lookback:t + 1])
        vol = _stdev(rets) * math.sqrt(252) * 100 if len(rets) >= 2 else 0.0
        return [mom, vol]

    def _samples(self, prices: Sequence[float], days: int) -> Tuple[List[List[float]], List[float], List[int]]:
        feats, targets, times = [], [], []
        for t in range(self.lookback, len(prices) - days):
            feat = self._features(prices, t)
            if feat is None or prices[t] <= 0:
                continue
            target = (prices[t + days] / prices[t] - 1.0) * 100
            feats.append(feat)
            targets.append(target)
            times.append(t)
        return feats, targets, times

    @staticmethod
    def _standardize(train: Sequence[Sequence[float]], current: Sequence[float]) -> Tuple[List[List[float]], List[float]]:
        if not train:
            return [], list(current)
        dims = len(train[0])
        means = [_mean([row[d] for row in train]) for d in range(dims)]
        stds = [_stdev([row[d] for row in train]) for d in range(dims)]
        def one(row):
            return [(row[d] - means[d]) / stds[d] if stds[d] > 1e-9 else 0.0
                    for d in range(dims)]
        return [one(row) for row in train], one(current)

    @staticmethod
    def _distances(train: Sequence[Sequence[float]], current: Sequence[float]) -> List[float]:
        out = []
        for row in train:
            d2 = sum((a - b) ** 2 for a, b in zip(row, current))
            out.append(math.sqrt(d2))
        return out

    @staticmethod
    def _weighted_quantile(values: Sequence[float], weights: Sequence[float], q: float) -> Optional[float]:
        pairs = sorted((v, max(1e-12, w)) for v, w in zip(values, weights))
        if not pairs:
            return None
        q = clamp(q, 0, 100) / 100.0
        total = sum(w for _, w in pairs)
        target = total * q
        acc = 0.0
        for value, weight in pairs:
            acc += weight
            if acc >= target:
                return value
        return pairs[-1][0]

    def _local_stats(self, train: Sequence[Sequence[float]], targets: Sequence[float],
                     current: Sequence[float]) -> Dict[str, Any]:
        if not train:
            return {"n_eff": 0.0, "weights": [], "distances": []}
        stand, cur_stand = self._standardize(train, current)
        distances = self._distances(stand, cur_stand)
        k = min(len(distances), max(self.min_samples, int(math.sqrt(len(distances)) * 6)))
        nearest = sorted(range(len(distances)), key=lambda i: distances[i])[:k]
        near_dist = [distances[i] for i in nearest]
        bandwidth = _median(near_dist) if near_dist else 1.0
        bandwidth = max(0.35, bandwidth or 0.35)
        weights = [math.exp(-0.5 * (distances[i] / bandwidth) ** 2) for i in nearest]
        wsum = sum(weights)
        if wsum <= 1e-12:
            weights = [1.0] * len(nearest)
            wsum = float(len(nearest))
        weights = [w / wsum for w in weights]
        vals = [targets[i] for i in nearest]
        n_eff = 1.0 / sum(w * w for w in weights) if weights else 0.0
        return {
            "n_eff": n_eff, "weights": weights, "values": vals,
            "mean": sum(v * w for v, w in zip(vals, weights)),
            "median": self._weighted_quantile(vals, weights, 50),
            "q05": self._weighted_quantile(vals, weights, 5),
            "q25": self._weighted_quantile(vals, weights, 25),
            "q50": self._weighted_quantile(vals, weights, 50),
            "q75": self._weighted_quantile(vals, weights, 75),
            "q95": self._weighted_quantile(vals, weights, 95),
            "p_up": sum(w for v, w in zip(vals, weights) if v > 0),
        }

    def forecast_horizon(self, prices: Sequence[float], label: str, days: int) -> ForecastDistribution:
        vals = [x for x in finite(prices) if x > 0]
        n = len(vals)
        rets = _log_returns(vals[-min(101, n):]) if n >= 2 else []
        daily_vol = _stdev(rets) if len(rets) >= 2 else 0.0
        period_sigma = max(0.05, daily_vol * math.sqrt(max(1, days)) * 100)
        flat_threshold = max(0.20, period_sigma * 0.25)
        feats, targets, times = self._samples(vals, days)
        if not targets:
            return ForecastDistribution(
                horizon=label, horizon_days=days, direction="neutral",
                probability_up=0.5, probability_down=0.45, probability_flat=0.05,
                median_return_pct=0.0, mean_return_pct=0.0,
                quantiles={"p05": -period_sigma, "p25": -period_sigma * 0.4,
                           "p50": 0.0, "p75": period_sigma * 0.4,
                           "p95": period_sigma},
                confidence=0.05, sample_size=0, method="empirical_knn",
                quality="insufficient", abstain=True,
                warnings=["历史样本不足，无法估计该周期分布"],
            )
        base_up = sum(1 for x in targets if x > 0) / len(targets)
        base_flat = sum(1 for x in targets if abs(x) <= flat_threshold) / len(targets)
        base_down = max(0.0, 1.0 - base_up - base_flat)
        global_q = {f"p{q:02d}": self._weighted_quantile(targets, [1.0] * len(targets), q)
                    for q in (5, 25, 50, 75, 95)}
        current = self._features(vals, n - 1)
        local = self._local_stats(feats, targets, current) if current else None
        n_eff = float(local["n_eff"]) if local else 0.0
        shrink = n_eff / (n_eff + 12.0) if n_eff else 0.0
        p_up_local = float(local.get("p_up", base_up)) if local else base_up
        p_flat_local = (sum(w for v, w in zip(local["values"], local["weights"])
                            if abs(v) <= flat_threshold) if local else base_flat)
        p_up = shrink * p_up_local + (1 - shrink) * base_up
        p_flat = shrink * p_flat_local + (1 - shrink) * base_flat
        p_down = max(0.0, 1.0 - p_up - p_flat)
        total = p_up + p_down + p_flat
        p_up, p_down, p_flat = p_up / total, p_down / total, p_flat / total
        # _local_stats 用 qNN、对外契约用 pNN；不映射的话 local.get("p05") 恒为 None，
        # 邻域分布会被静默丢弃，退化成纯全局分位数。
        local_q = {f"p{k[1:]}": v for k, v in local.items()
                   if k.startswith("q") and v is not None} if local else {}
        quantiles: Dict[str, float] = {}
        for key, gval in global_q.items():
            lval = local_q.get(key)
            quantiles[key] = round(shrink * lval + (1 - shrink) * gval, 4) if lval is not None else round(gval, 4)
        median_ret = shrink * float(local.get("median", global_q["p50"])) + (1 - shrink) * global_q["p50"] if local else global_q["p50"]
        mean_ret = shrink * float(local.get("mean", 0.0)) + (1 - shrink) * _mean(targets) if local else _mean(targets)
        # 防止极端样本导致零宽区间；最小宽度由已实现波动率给出并明确标记为 derived。
        min_half = max(0.35, period_sigma * 0.35)
        quantiles["p05"] = min(quantiles["p05"], median_ret - min_half)
        quantiles["p95"] = max(quantiles["p95"], median_ret + min_half)
        quantiles["p25"] = min(quantiles["p25"], median_ret - min_half * 0.35)
        quantiles["p75"] = max(quantiles["p75"], median_ret + min_half * 0.35)
        quantiles["p50"] = median_ret
        quantiles = {k: round(v, 4) for k, v in quantiles.items()}
        brier, baseline, skill, n_eval = self._oos_validation(vals, days, flat_threshold)
        sample_factor = min(1.0, len(targets) / 120.0)
        eff_factor = min(1.0, n_eff / 30.0) if n_eff else 0.0
        edge = abs(p_up - p_down)
        width = max(0.01, quantiles["p95"] - quantiles["p05"])
        tight = 1.0 / (1.0 + max(0.0, width / max(0.2, flat_threshold * 4) - 1.0) * 0.5)
        confidence = 0.20 + 0.28 * sample_factor + 0.20 * eff_factor + 0.17 * min(1.0, edge / 0.35) + 0.15 * tight
        if skill is not None:
            confidence *= clamp(0.80 + 0.20 * clamp(skill, -1.0, 1.0), 0.55, 1.0)
        else:
            confidence *= 0.78
        confidence = clamp(confidence, 0.0, 0.90)
        warnings: List[str] = []
        abstain = False
        if len(vals) < 60 or len(targets) < self.min_samples:
            abstain = True
            confidence = min(confidence, 0.30)
            warnings.append(f"样本不足（历史 {n}，条件样本 {len(targets)}），预测降级")
        if skill is not None and skill < -0.25 and n_eval >= 12:
            abstain = True
            confidence = min(confidence, 0.30)
            warnings.append("样本外校准未优于基准，模型主动弃权")
        if not current:
            abstain = True
            warnings.append("当前特征不足，无法进行条件匹配")
        if n < 120:
            warnings.append("历史窗口较短，区间与概率不确定性较高")
        quality = ("insufficient" if len(vals) < 60 or len(targets) < self.min_samples
                   else "validated" if skill is not None and skill > 0 and len(vals) >= 150 and n_eval >= 15
                   else "derived" if len(vals) >= 120 else "estimated")
        if quality == "estimated":
            confidence = min(confidence, 0.58)
        elif quality == "derived":
            confidence = min(confidence, 0.75)
        elif quality == "validated":
            confidence = min(confidence, 0.88)
        direction = "neutral"
        if not abstain:
            if p_up - p_down >= 0.08 and median_ret > flat_threshold * 0.25:
                direction = "bullish"
            elif p_down - p_up >= 0.08 and median_ret < -flat_threshold * 0.25:
                direction = "bearish"
        return ForecastDistribution(
            horizon=label, horizon_days=days, direction=direction,
            probability_up=round(p_up, 4), probability_down=round(p_down, 4),
            probability_flat=round(p_flat, 4), median_return_pct=round(median_ret, 3),
            mean_return_pct=round(mean_ret, 3), quantiles=quantiles,
            confidence=round(confidence, 3), sample_size=len(targets),
            effective_sample_size=round(n_eff, 2), method="empirical_knn_shrunk",
            brier_score=round(brier, 5) if brier is not None else None,
            baseline_brier=round(baseline, 5) if baseline is not None else None,
            skill_score=round(skill, 4) if skill is not None else None,
            quality=quality, abstain=abstain, warnings=warnings,
        )

    def _oos_validation(self, prices: Sequence[float], days: int,
                        flat_threshold: float) -> Tuple[Optional[float], Optional[float], Optional[float], int]:
        n = len(prices)
        if n < 80 or days >= n - self.lookback:
            return None, None, None, 0
        eval_count = min(20, max(8, n // 12))
        start = max(self.lookback + 25, n - days - eval_count)
        eval_times = list(range(start, n - days))
        briers, base_briers = [], []
        for t in eval_times:
            feats, targets, times = [], [], []
            for s in range(self.lookback, t - days + 1):
                feat = self._features(prices, s)
                if feat is None or prices[s] <= 0:
                    continue
                feats.append(feat)
                targets.append((prices[s + days] / prices[s] - 1.0) * 100)
                times.append(s)
            if len(targets) < 10:
                continue
            current = self._features(prices, t)
            if current is None:
                continue
            local = self._local_stats(feats, targets, current)
            n_eff = float(local.get("n_eff", 0.0))
            shrink = n_eff / (n_eff + 12.0) if n_eff else 0.0
            base_up = sum(1 for x in targets if x > 0) / len(targets)
            p_up = shrink * float(local.get("p_up", base_up)) + (1 - shrink) * base_up
            outcome = 1.0 if prices[t + days] > prices[t] else 0.0
            briers.append((p_up - outcome) ** 2)
            base_briers.append((base_up - outcome) ** 2)
        if len(briers) < 8:
            return None, None, None, len(briers)
        brier = _mean(briers)
        baseline = _mean(base_briers)
        skill = 1.0 - brier / baseline if baseline > 1e-9 else None
        return brier, baseline, skill, len(briers)

    def forecast_multi(self, prices: Sequence[float],
                       horizons: Optional[Sequence[Tuple[str, int]]] = None) -> List[ForecastDistribution]:
        return [self.forecast_horizon(prices, label, days)
                for label, days in (horizons or self.horizons)]


def _median(values: Sequence[float]) -> float:
    return statistics.median(values) if values else 0.0
