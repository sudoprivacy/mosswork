---
name: skillhub-skill-bili-main-douga
description: "当用户想按 B 站「动画」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：动画、B站分区、rid 1。"
---

# B 站分区 · 动画

- 一级分区 rid：`1`；网页路由：`/v/douga/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 95 条榜单条目，覆盖 7 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| MAD·AMV | 13 | 10 | 24 |
| MMD·3D | 2 | 6 | 25 |
| 动漫杂谈 | 14 | 10 | 253 |
| 同人·手书 | 33 | 9 | 47 |
| 模玩·周边 | 3 | 10 | — |
| 特摄 | 5 | 10 | 86 |
| 综合 | 25 | 10 | 27 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### MAD·AMV

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 洗脑神曲《𝑽𝒊𝒔𝒊𝒐𝒏 𝒑𝒕.𝑰𝑰》，无法超越的绝美画面！！ | 学姐圆 | [BV1AhZUYFEMT](https://www.bilibili.com/video/BV1AhZUYFEMT) | 86.0 万 |
| "待到春和景明，我们便会相逢" | 陌落雨 | [BV19tRBY6EH9](https://www.bilibili.com/video/BV19tRBY6EH9) | 73.1 万 |
| 【MADMAX/魔法少女小圆/叛逆的物语】蜘蛛之丝 | 永友i | [BV1a9ZZYNEGT](https://www.bilibili.com/video/BV1a9ZZYNEGT) | 137.8 万 |
| 打抠舞的动态也太难做了吧 ! _  spine2D动画 | 鬍渣阿哲 | [BV1U1dtY3ELh](https://www.bilibili.com/video/BV1U1dtY3ELh) | 122.3 万 |
| ⚡我自己剪的时候差点没绷住⚡ | -柠萌菌- | [BV1kdR9YiEXA](https://www.bilibili.com/video/BV1kdR9YiEXA) | 112.0 万 |

### MMD·3D

数据来源：二级分区 7 日榜，可用 6 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 牛牛生气了该怎么哄？ | 漾少侠 | [BV11afPYCEXm](https://www.bilibili.com/video/BV11afPYCEXm) | 113.0 万 |
| 服 务 器 新 人 肆 | 不风采的琴 | [BV1pCZ1YWEQa](https://www.bilibili.com/video/BV1pCZ1YWEQa) | 145.4 万 |
| 又又又被钓成翘嘴了！ | -路人亦ONE- | [BV1sRZQYgEDv](https://www.bilibili.com/video/BV1sRZQYgEDv) | 57.5 万 |
| 【鸣潮原创PV】潮眠 | 可靠de伏特加 | [BV1CZR9YNEP2](https://www.bilibili.com/video/BV1CZR9YNEP2) | 48.1 万 |
| 【少女前线2：追放】可露凯与米什缇的秘密任务【狄龙顾dillongoo】 | 狄龙顾 | [BV1KdR2YWEBc](https://www.bilibili.com/video/BV1KdR2YWEBc) | 39.7 万 |

### 动漫杂谈

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 不要抢走我的整活啊啊！2025年1月新番完结吐槽！【泛式】 | 泛式 | [BV1ksRqYXEvE](https://www.bilibili.com/video/BV1ksRqYXEvE) | 462.3 万 |
| 如何破局？大蛇丸给出了一个标准答案！ | 锅盖哒 | [BV18yZ9YRE9R](https://www.bilibili.com/video/BV18yZ9YRE9R) | 116.6 万 |
| 用坏掉的精灵少女当素材？制作幸福的药水？！！ | 贞叶 | [BV1YAR2YfE83](https://www.bilibili.com/video/BV1YAR2YfE83) | 110.3 万 |
| 炸裂战斗！B站国创巅峰一战！《凡人修仙传》137逐帧解析 | 利维坦mY | [BV1vuRRYoEBp](https://www.bilibili.com/video/BV1vuRRYoEBp) | 93.6 万 |
| 久违！名侦探柯南最新主线来袭！远古伏笔终于揭露？！ | 哀是麦子的球迷 | [BV1QNZdYFEWf](https://www.bilibili.com/video/BV1QNZdYFEWf) | 92.9 万 |

### 同人·手书

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【我的幽灵女友官方】#107.5 高 手 苏 茜 | dsand00 | [BV1qtZQYZEr6](https://www.bilibili.com/video/BV1qtZQYZEr6) | 499.8 万 |
| 新朋友来了！ | 锌之助吖 | [BV1JCRXYdEAu](https://www.bilibili.com/video/BV1JCRXYdEAu) | 238.8 万 |
| 法庭上禁止对嫌疑人用黑虎掏星啊！！！《时空独舞篇下》 | 芦苇十三少 | [BV1ueZmYTEBZ](https://www.bilibili.com/video/BV1ueZmYTEBZ) | 297.4 万 |
| “喜报！女老板终究熬成老板娘了！！” | 银色の猫先生 | [BV169ZiYRErK](https://www.bilibili.com/video/BV169ZiYRErK) | 202.6 万 |
| 穷人和富人的思维，是真的不一样 | cheems小电影 | [BV1v6RqYkEWe](https://www.bilibili.com/video/BV1v6RqYkEWe) | 417.4 万 |

### 模玩·周边

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【长尾夹】原创-卡布达巨人 | 机夹小翔 | [BV1VnZRYcELz](https://www.bilibili.com/video/BV1VnZRYcELz) | 408.6 万 |
| 4斤重钢铁の孤狼！CCSTOYS 铁魄 古铁 合金成品模型 机器人大战OG【评头论足】 | -评头论足- | [BV1W4RDYfEuQ](https://www.bilibili.com/video/BV1W4RDYfEuQ) | 98.1 万 |
| 建议法律禁止他玩变形金刚 | 凯歌凯之歌 | [BV1TsZUYPEqH](https://www.bilibili.com/video/BV1TsZUYPEqH) | 97.5 万 |
| 设计师：我终于拿出了还原的作品 可老板还是要打我 | 十六和钰哥 | [BV1KiR1YEEWE](https://www.bilibili.com/video/BV1KiR1YEEWE) | 141.2 万 |
| 敖丙海盐棒棒糖？孩子又出难题，伦堡沙真的玩出花了，我太难了 | 玩不累妈妈 | [BV1DidcYYEEK](https://www.bilibili.com/video/BV1DidcYYEEK) | 554.9 万 |

### 特摄

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 哪吒！整整哪吒版的熊出没吧 | 废人兄弟搞配音 | [BV14dZyY4EBV](https://www.bilibili.com/video/BV14dZyY4EBV) | 439.7 万 |
| 超级战队系列入驻B站！ | 超级战队中国官方 | [BV1AgZmYREeW](https://www.bilibili.com/video/BV1AgZmYREeW) | 131.8 万 |
| “真正的英雄，也许就在你的身边…” | 德心OnceDream | [BV1EvZ2YUELq](https://www.bilibili.com/video/BV1EvZ2YUELq) | 328.3 万 |
| “把反派骑士叫来，我让你把反派骑士给我叫来！” | 思瑞弟 | [BV1vxdcYgE1L](https://www.bilibili.com/video/BV1vxdcYgE1L) | 172.2 万 |
| 敢不敢跟我来一场牛仔对决！我猜你枪里没子弹！ | 陈信喆Txz | [BV123Z9Y7ERn](https://www.bilibili.com/video/BV123Z9Y7ERn) | 149.1 万 |

### 综合

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 战地の子 | 博麗霊夢え | [BV1DaRSYiEcE](https://www.bilibili.com/video/BV1DaRSYiEcE) | 264.2 万 |
| 纯路人根据一张图猜谁最年轻 | 隔路脑 | [BV1jGZXYZEGm](https://www.bilibili.com/video/BV1jGZXYZEGm) | 375.3 万 |
| ♿哈利路大旋风！！♿ | T_H_U_I | [BV1GKZdY8Eoy](https://www.bilibili.com/video/BV1GKZdY8Eoy) | 312.3 万 |
| 颜（Alter Ego）（TV动画「BanG Dream! Ave Mujica」#13 插曲） | MyGO_AveMujica | [BV1XNfTYfEky](https://www.bilibili.com/video/BV1XNfTYfEky) | 297.4 万 |
| “ 倒 反 天 罡 ！” | 汐汐不想睡大街 | [BV1NsZUYPE9D](https://www.bilibili.com/video/BV1NsZUYPE9D) | 158.3 万 |

## 名称差异与覆盖说明

- 接口出现但分区表未列或名称不同：模玩·周边。
- 分区表列出但本次榜单未返回条目：手办·模玩, 配音（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=1." https://api.bilibili.com/x/web-interface/ranking/v2?rid=1&type=all. Accessed 6 Nov. 2026.
