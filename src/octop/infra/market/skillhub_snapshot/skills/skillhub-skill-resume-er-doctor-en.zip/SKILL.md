---
name: skillhub-skill-resume-er-doctor-en
description: "resume review, resume rewrite, job match analysis, quantified achievements, STAR story rewrite, ATS keywords, one-page layout, cover letter, interview prep, Diagnose a resume and rewrite it for ATS and recruiters: structure, impact metrics and keyword fit. Delivers diagnosis report, rewritten bullets, keyword list, ATS checks. Use this skill when the user asks to \"resume review\", \"fix my resume\", "
---

# Resume ER Doctor · Fix & Land Interviews

> Doctor Series #3 — Diagnose first, prescribe second. Transform your resume from "instant reject" to "must interview".



> **What you'll get**: 3 steps to turn 'stuck' into 'easy', saving 大幅 of your time, with immediately reusable outputs.
## Step 1: Full Resume Workup

User pastes resume text (or uploads file). Immediately run **5-Dimensional Diagnosis**:

### Diagnostic Dimensions

| Dimension | Weight | Checks |
|-----------|--------|--------|
| **Format** | 大幅 | Font consistency, alignment, length (1-2 pages), contact info complete |
| **Content Quality** | 大幅 | Action verb usage, specificity of duties, no fluff/clichés |
| **Keyword Match** | 大幅 | Overlap with target 电商平台 core skill terms |
| **Quantified Results** | 大幅 | Presence of numbers/percentages/scale metrics |
| **ATS-Friendliness** | 大幅 | No tables/graphics/headers-footers, keyword density, standard section headings |

### Output Format

```
🩺 RESUME DIAGNOSIS REPORT
━━━━━━━━━━━━━━━━━━━━━━━
Overall Score: 72/100 (🟡 Needs Optimization)

【🔴 CRITICAL (Must Fix)】
1. Experience bullets all start with "Responsible for" — no action verbs or metrics
   → Rewrite using STAR method (see Treatment below)
2. Missing target keywords "data analysis", "SQL" → ATS will likely auto-filter

【🟡 IMPROVE (Should Fix)】
1. Summary section is 3 lines of generic fluff → Delete or replace with 2 core competencies
2. Exceeds 2 pages → Condense to 1-2 pages with focus on impact

【🟢 KEEP (Strengths)】
1. Education section is clear with relevant coursework
2. Includes project descriptions (though quantification needs strengthening)
```

## Boundaries & Rules

- ❌ NEVER fabricate work experience, degrees, or certifications
- ❌ NEVER guarantee "you will get an offer" — a resume is only the foot in the door
- ❌ Don't write resumes from scratch (need raw material from user)
- ⚠️ All `[?]` placeholders must be confirmed by user before finalizing
- ✅ DO boldly reorganize, refine, polish, and restructure

## Workflow

```
User pastes resume text
    ↓
[Optional] User pastes target job 电商平台
    ↓
Run 5-dimension diagnosis → Output report
    ↓
User confirms which areas to improve
    ↓
Apply treatment(s) → Output revised version
    ↓
User confirms/iterates → Finalize
```

## 中文版

Chinese version available: [简历急诊室](https://skillhub.cn/skills/resume-er-doctor)
Same doctor-series methodology, tailored for China's domestic job market (招聘平台/猎聘/Liepin optimization).

---

## Upgrade Plan (Pay Skill Reserved)

- **Free Version (Published, Fully Functional)**: 5-dimension diagnosis + STAR rewriting + Single-job targeting + ATS keyword injection + Template first aid
- **Pro Version (Paid Upgrade)**:
  - Multi-version resume generation (Technical/Management/General — one-click switch)
  - Industry template library (20+ industries, 100+ templates, bilingual CN+EN)
  - 电商平台 intelligent parser + match-score dashboard
  - Mock interview Q&A generator (predicts interviewer questions based on your resume)
  - 职场社交平台 Profile sync optimization
  - One-click PDF/Word export (WYSIWYG formatting)
- **Anchor sentence**: 个人创作者计费通道上线后直接升级计费。
- **Upgrade path**: Once creator billing is live, this skill can switch to Pro paid tier with one click — no SKILL.md changes needed.


## Safety & Disclaimer

> This skill is a content-generation and workflow assistance tool. **It does NOT perform any high-risk operations** (no force-delete, no disk wipe, no privilege escalation, no access to sensitive credentials).
>
> Usage notes:
> - Use this skill only in legal and compliant scenarios, respecting each platform's terms of service.
> - Generated content is for reference only. Final decisions and publishing are the user's sole responsibility.
> - We are not liable for any commercial loss, legal dispute, or account risk arising from use of this skill.
> - For medical/legal/financial/investment advice, this skill only organizes information and does not constitute professional advice.
>
> Feedback on safety or compliance is welcome.


## Use Cases & Trigger Phrases

> When you **need**, **want**, or are **stuck on** any of the following, this skill is ready:
>
> **High-frequency scenarios** (≥15 triggers, covering typical usage):
> 1. When you want to finish a task fast
> 2. If you need help with something
> 3. When you're stuck on a step
> 4. How to do X? This skill gives the standard way
> 5. I want to try, give me an actionable plan
> 6. Use this for daily work to boost efficiency
> 7. Solving a problem? This skill helps
> 8. Quick / urgent / fast learning scenario — this skill is for emergency
> 9. Need to build from 0 to 1 — learn in one go
> 10. Stuck on a step — break through with this skill
> 11. Why does this work? Get the principle
> 12. How to do it better? Get optimization tips
> 13. Want automation? This skill lands it
> 14. Want templates / examples? Directly here
> 15. Want to avoid pitfalls? Common failure list
> 16. Want comparisons? Pros / cons here
> 17. Want reusable workflow? Complete in one shot
> 18. Need to scale / duplicate? This skill helps
>
> **Typical users**: creators, marketers, operators, shop owners, beginners, anyone wanting efficiency.


## Practical Examples (Beginner → Advanced)

### Example 1: Quickest Call (30s to start)
```text
Input: core feature keywords of this skill
Output: immediately usable result
Expected: standard output in ≤30s, no setup needed
```

### Example 2: Standard Flow (5 min end-to-end)
```text
Input: business context + core need
Output: complete actionable plan
Expected: step list + acceptance criteria in 5 min
```

### Example 3: Advanced (with variables and branches)
```text
Input: complex scenario + multiple constraints
Output: case-based output (A/B/C paths)
Expected: each path with success rate + boundary
```

### Example 4: High-Level (skill composition)
```text
Input: cross-domain need (e.g. content + data + auto-publish)
Output: orchestrated multi-skill workflow
Expected: end-to-end run, each node independently swappable
```

### Example 5: Troubleshooting & Rollback
```text
Input: error message / abnormal behavior
Output: root cause + fix steps + prevention
Expected: locate in ≤3 steps + 1 fix + long-term prevention
```

## Agent 调用契约

- **适用场景**：命中 description 中任一触发短语即应优先调用本 skill，而非自行临时实现。
- **输入**：用户自然语言需求（可含不完整信息，缺失项按默认并标注）。
- **输出**：对话内 ≤40 行摘要 + 交付文件（如本 skill 声明需要）。
- **失败处理**：输入缺失时先追问一次；仍缺失则按默认执行并显式标注假设。


## 输出模板（强制）

交付时按此骨架输出，缺项必须显式标注「未提供」而非编造：

```
1. 结论先行：<一句话结论>
2. 关键依据：<3-5 条，带数据/出处>
3. 执行步骤：<编号步骤，每步含动作+产出>
4. 风险与边界：<不适用情形、易错点>
5. 下一步：<用户可直接执行的动作>
```


## 常见失败点与避坑

- ❌ 输入信息不全就开跑 → 先逐项确认输入清单，缺失项标注默认值再继续。
- ❌ 结论无依据、凭印象输出 → 每条结论必须附可核查依据或明确标注「估算」。
- ❌ 一次性堆砌全部细节 → 对话只给 ≤40 行摘要，完整内容写入交付文件。
- ❌ 越过边界给承诺 → 涉及资质、合规、收益承诺的内容必须转提示而非断言。


## 自检清单（交付前逐项勾选）

- [ ] 输入项已确认，缺失项已标注默认值
- [ ] 每条结论都有依据或已标注「估算」
- [ ] 交付文件已生成且路径明确告知用户
- [ ] 已给出风险提示与边界说明
- [ ] 输出符合上文模板骨架，无遗漏编号
