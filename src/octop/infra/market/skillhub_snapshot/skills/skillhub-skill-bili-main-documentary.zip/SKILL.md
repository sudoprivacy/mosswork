---
name: skillhub-skill-bili-main-documentary
description: "当用户想按 B 站「纪录片」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：纪录片、B站分区、rid 177。"
---

# B 站分区 · 纪录片

- 一级分区 rid：`177`；网页路由：`/v/documentary/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 73 条榜单条目，覆盖 4 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 人文·历史 | 25 | 4 | 37 |
| 军事 | 4 | 10 | 179 |
| 社会·美食·旅行 | 29 | 9 | 180 |
| 科学·探索·自然 | 15 | 7 | 178 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 人文·历史

数据来源：二级分区 7 日榜，可用 4 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【纪录片】但愿人长久 第8集 爱是无畏告别 | 哔哩哔哩纪录片 | [BV1ThZRYWESg](https://www.bilibili.com/video/BV1ThZRYWESg) | 34.2 万 |
| 外交部：若美方执意打关税战贸易战 中方奉陪到底 | 海客新闻 | [BV1RndHYPEZx](https://www.bilibili.com/video/BV1RndHYPEZx) | 3640 |
| 韩国政府初步计划6月3日举行新一届大选 | 海客新闻 | [BV1urRkY7ExQ](https://www.bilibili.com/video/BV1urRkY7ExQ) | 2620 |
| 英国行业组织敦促英政府不要向美国屈服 | 海客新闻 | [BV1ttdbYkEHs](https://www.bilibili.com/video/BV1ttdbYkEHs) | 1837 |

### 军事

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 马西西锐评拍拍熊爆了：他蛮聪明的，先威胁要爆，再和管理层谈条件，谈不好就把falcons丑事都爆出来 | 三幺哥 | [BV1gSdnYxE9G](https://www.bilibili.com/video/BV1gSdnYxE9G) | 4.5 万 |
| 危难见本色，俄乌黑土地上四处游荡的战争之神… | 聊天科研俱乐部 | [BV1m6ZmYPE3t](https://www.bilibili.com/video/BV1m6ZmYPE3t) | 2.6 万 |
| 王毅外长用一句话，给中美贸易战定下基调，越界掀桌不是开玩笑 | 一号哨所 | [BV1eKf3YyEy5](https://www.bilibili.com/video/BV1eKf3YyEy5) | 3.0 万 |
| Summer惊天1V5打崩VP！RA2:0拿下VP进入1-0组！马西西反复回看 | 三幺哥 | [BV1MzRBYAE23](https://www.bilibili.com/video/BV1MzRBYAE23) | 1.4 万 |
| 李肃：美国又在威胁再征50%，全球就中国不怕，下次武统台湾吧 | 一号哨所 | [BV1dEdHYvE3j](https://www.bilibili.com/video/BV1dEdHYvE3j) | 1.3 万 |

### 社会·美食·旅行

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【纪录片】你好，12315 第四集 真相只有一个 | 哔哩哔哩纪录片 | [BV1EXZ1Y7EQ8](https://www.bilibili.com/video/BV1EXZ1Y7EQ8) | 840.2 万 |
| 【纪录片】这就是中国 第278集 欧洲的“至暗时刻” | 哔哩哔哩纪录片 | [BV1E8R2Y3Ehf](https://www.bilibili.com/video/BV1E8R2Y3Ehf) | 28.5 万 |
| 【纪录片】可以跟着去你家吗 47 | 哔哩哔哩纪录片 | [BV1NBfKYEEbw](https://www.bilibili.com/video/BV1NBfKYEEbw) | 13.4 万 |
| 【纪录片】无穷之路4:一带一路 02 生命之源 | 哔哩哔哩纪录片 | [BV1s7R2YJEsb](https://www.bilibili.com/video/BV1s7R2YJEsb) | 26.5 万 |
| 【纪录片】吉米的居家速食宝典 03 | 哔哩哔哩纪录片 | [BV14JXPYcE8o](https://www.bilibili.com/video/BV14JXPYcE8o) | 11.0 万 |

### 科学·探索·自然

数据来源：二级分区 7 日榜，可用 7 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【纪录片】深海探秘 05 冰海巨兽 | 哔哩哔哩纪录片 | [BV1yBfKY7E6D](https://www.bilibili.com/video/BV1yBfKY7E6D) | 81.0 万 |
| 【纪录片】黑暗惊奇 08 | 哔哩哔哩纪录片 | [BV1dXKPeyEcU](https://www.bilibili.com/video/BV1dXKPeyEcU) | 30.1 万 |
| 【纪录片】宇宙03 银河探秘 | 哔哩哔哩纪录片 | [BV1WbokYVEiz](https://www.bilibili.com/video/BV1WbokYVEiz) | 28.5 万 |
| 【纪录片】荒野独居 第11季 08 饥饿 | 哔哩哔哩纪录片 | [BV1VdKPeCEqm](https://www.bilibili.com/video/BV1VdKPeCEqm) | 25.0 万 |
| 【纪录片】狂野之河 02 多瑙河 | 哔哩哔哩纪录片 | [BV1GkR2YAEJf](https://www.bilibili.com/video/BV1GkR2YAEJf) | 23.7 万 |

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=177." https://api.bilibili.com/x/web-interface/ranking/v2?rid=177&type=all. Accessed 6 Nov. 2026.
