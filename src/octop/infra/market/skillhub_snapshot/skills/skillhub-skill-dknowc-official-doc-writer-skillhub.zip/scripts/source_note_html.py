#!/usr/bin/env python3
"""把写作流程的结构化正文/素材 JSON 转成产出物 HTML（正文 / 溯源核验报告 / 知识专库 三页）。"""

from __future__ import annotations

import argparse
import concurrent.futures
import importlib.util
import json
import re
import sys
import unicodedata
import urllib.error
import urllib.request
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parent.parent
INPUT_DIR = SKILL_ROOT / "official-docs" / "input"
OUTPUT_DIR = SKILL_ROOT / "official-docs" / "output"
SEARCH_RESULTS_DIR = SKILL_ROOT / "official-docs" / "search-results"


def load_renderer():
    path = Path(__file__).with_name("render_trace_html.py")
    spec = importlib.util.spec_from_file_location("dknowc_trace_renderer", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载可信溯源报告模板: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def resolve_input(value: str) -> Path:
    raw = Path(value).expanduser()
    path = raw.resolve() if raw.is_absolute() else (INPUT_DIR / raw.name).resolve()
    if path.suffix.lower() != ".json":
        raise ValueError("输入文件必须是 JSON")
    try:
        path.relative_to(INPUT_DIR.resolve())
    except ValueError as exc:
        raise ValueError(f"输入文件必须位于 official-docs/input/: {value}") from exc
    if not path.exists():
        raise FileNotFoundError(f"输入文件不存在: {path}")
    return path


def safe_output(value: str, title: str) -> Path:
    if value:
        raw = Path(value).expanduser()
        path = raw.resolve() if raw.is_absolute() else (OUTPUT_DIR / raw.name).resolve()
    else:
        safe_title = "".join("_" if char in '\\/:*?"<>| ' else char for char in title).strip("_")
        # 产出物文件名＝用户需求（正文标题）确定的 XXX.html；兼容旧溯源 JSON 里
        # 已带 _溯源核验报告 后缀的标题，先剥掉再加 .html，避免 "_溯源核验报告.html"
        safe_title = re.sub(r"(_溯源核验报告)+$", "", safe_title)
        path = (OUTPUT_DIR / f"{safe_title[:80] or '文稿'}.html").resolve()
    if path.suffix.lower() not in {".html", ".htm"}:
        path = path.with_suffix(".html")
    try:
        path.relative_to(OUTPUT_DIR.resolve())
    except ValueError as exc:
        raise ValueError("输出文件必须位于 official-docs/output/") from exc
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def first_value(item: dict, *keys: str) -> str:
    for key in keys:
        value = item.get(key)
        if value not in (None, "", [], {}):
            return str(value)
    return ""


def normalize_title(value: str) -> str:
    """仅用于兼容旧结果的标题兜底匹配；新流程优先使用素材中的 source_url。"""
    text = unicodedata.normalize("NFKC", str(value or "")).lower()
    text = re.sub(r"[《》〈〉「」『』\[\]【】()（）]", "", text)
    text = re.sub(r"\s+", "", text)
    return text


def load_source_index() -> dict:
    """从本地搜索结果按文章标题建立原文 URL 索引，补齐上游整理时遗漏的字段。

    同时从同响应的 policyFiles 区提取发文字号（writtenText）并入索引——
    文号与检索文章分开展示在同一响应里，本地标题匹配即可拿到，无需接口改动；
    新闻/解读类不在 policyFiles 中（本就无文号），匹配不上则不显示。
    """
    index = {}
    if not SEARCH_RESULTS_DIR.exists():
        return index
    for path in SEARCH_RESULTS_DIR.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        # 顶层为数组的索引 JSON（all_materials_index.json 等）不是搜索结果，跳过。
        # 旧实现直接 data.get() 会抛 AttributeError: 'list' object has no
        # attribute 'get'，导致溯源报告生成中断（曾靠临时移走文件绕过）
        if not isinstance(data, dict):
            continue
        # 兼容两种落盘格式：--clean 白名单（顶层 articles）与接口原始响应（content.data）
        articles = data.get("articles") if isinstance(data.get("articles"), list) else None
        policy_files = []
        if articles is None:
            content = data.get("content", {})
            payload = content.get("data", {}) if isinstance(content, dict) else {}
            if isinstance(payload, dict):
                articles = payload.get("检索文章", []) if isinstance(payload.get("检索文章"), list) else []
                if isinstance(payload.get("policyFiles"), list):
                    policy_files = payload["policyFiles"]
        elif isinstance(data.get("policyFiles"), list):
            policy_files = data["policyFiles"]
        doc_numbers = {}
        for pf in policy_files:
            if not isinstance(pf, dict):
                continue
            doc_no = first_value(pf, "writtenText", "发文字号")
            title = first_value(pf, "title", "标题")
            if doc_no and title:
                doc_numbers.setdefault(normalize_title(title), doc_no)
        for article in articles:
            if not isinstance(article, dict):
                continue
            title = first_value(article, "文章标题", "title", "标题")
            if not title:
                continue
            source_url = first_value(article, "源网址", "原文链接", "sourceUrl", "source_url", "url")
            policy_url = first_value(article, "知识专库原文", "policyUrl", "policy_url")
            if source_url or policy_url:
                record = {"source_url": source_url, "policy_url": policy_url}
                index.setdefault(title, record)
                index.setdefault(normalize_title(title), record)
        for key, record in list(index.items()):
            if "doc_number" not in record:
                no = doc_numbers.get(key)
                if no:
                    record["doc_number"] = no
    return index


# 快照兜底开关：默认启用。verify_snapshots 仅做本地路径格式校验与 /A/ 层级补全
# （接口部分返回值曾缺该层级），不发起网络请求。
SNAPSHOT_ENABLED = True


# 2026-10-08：链接连通性检测已整体移除——接口返回的链接原样给出，不做任何网络探测。
# 原 404/410 + 软404 主动探测会把"暂时打不开"误判为死链并隐藏链接，造成"被引来源
# 没有任何可点链接、无法回看原文"。接口自带的 screenShotPath 快照仍作附加回看入口展示。


def normalize_snapshot_url(url: str) -> str:
    """快照路径容错：接口部分返回值缺 /A/ 层级（部分返回值缺少该层级，补全后即可访问），
    统一规范化为 https://attach.dknowc.cn/snapshot/A/<2位>/<2位>/<哈希>.jpg。"""
    u = (url or "").strip()
    if u.startswith("https://attach.dknowc.cn/snapshot/") and "/snapshot/A/" not in u:
        return u.replace("/snapshot/", "/snapshot/A/", 1)
    return u


def mark_dead_links(articles: list[dict]) -> int:
    """已废弃（不做连通性检测，链接原样给出）。保留空壳仅供旧调用兼容。"""
    return 0


def verify_snapshots(articles: list[dict]) -> int:
    """快照展示前的路径校验（纯本地检查，不发网络请求）：
    组装阶段已由 normalize_snapshot_url 补全 /A/ 层级；此处校验修订后的路径
    是否符合合法格式（https://attach.dknowc.cn/snapshot/A/…），不合法则弃用。

    不做网络可达检测：attach 前置雷池 WAF 的拦截与请求方 IP 风控相关
    （检测机高频请求会被拦而普通用户正常），可达性检测可能误杀可用快照；
    快照文件本身的存在性由可信搜索侧的数据质量保障。
    """
    dropped = 0
    for a in articles:
        u = (a.get("快照链接") or "").strip()
        if not u:
            continue
        if u.startswith("https://attach.dknowc.cn/snapshot/A/"):
            continue
        a["快照链接"] = ""
        dropped += 1
    return dropped


def to_trace_payload(data: dict) -> tuple[dict, str, str]:
    title = first_value(data, "title", "标题") or "可信溯源报告"
    answer = first_value(data, "document_content", "documentContent", "正文", "body", "answer", "content_markdown")
    if isinstance(data.get("document_content"), list):
        answer = "\n\n".join(first_value(item, "text", "content") for item in data["document_content"] if isinstance(item, dict))
    materials = data.get("materials") or data.get("素材使用情况") or []
    # 未引用召回材料：接口召回但正文未采用，同样进入材料面板（排在已引用材料之后）
    recalled = data.get("recalled_materials") or data.get("未引用素材") or []
    articles = []
    source_index = load_source_index()
    for used, group in ((True, materials), (False, recalled)):
        for index, item in enumerate(group, 1):
            if not isinstance(item, dict):
                continue
            material_name = first_value(item, "material_name", "材料名称", "title", "文章标题") or f"来源文章{index}"
            # 新结果必须直接携带 source_url；标题匹配仅兼容历史 JSON。
            matched = source_index.get(material_name) or source_index.get(normalize_title(material_name), {})
            source_url = first_value(item, "source_url", "sourceUrl", "源网址", "原文链接", "url") or matched.get("source_url", "")
            policy_url = first_value(item, "policyUrl", "policy_url", "knowledgeBase", "知识专库链接") or matched.get("policy_url", "")
            doc_number = (first_value(item, "发文字号", "doc_number", "文号")
                          or matched.get("doc_number", ""))
            articles.append({
                "文章标题": material_name,
                "文号": doc_number,
                "来源": first_value(item, "source", "来源", "publisher", "发布或实施机构"),
                "发布日期": first_value(item, "date", "发布日期", "time"),
                # 接口原始结构透传：发布日期可信度 + 段落（含段落标题，用于"原文位置"标题链）
                "发布日期可信度": first_value(item, "发布日期可信度", "可信度", "confidence"),
                "段落": item.get("段落") if isinstance(item.get("段落"), list) else [],
                "相关段落": first_value(item, "excerpt", "摘录", "支撑内容", "support"),
                "正文对应": first_value(item, "section", "正文对应"),
                "源网址": source_url,
                "知识专库原文": policy_url,
                # 快照链接（接口 screenShotPath）：原文 404 时的存档兜底，渲染层择一展示。
                # 接口数据可能不稳（部分快照 404/NoSuchKey），默认关闭，--enable-snapshot 打开。
                "快照链接": normalize_snapshot_url(first_value(item, "snapshot_url", "快照链接", "screenShotPath", "screenshot_path")) if SNAPSHOT_ENABLED else "",
                "policyUrl": first_value(item, "policyUrl", "policy_url"),
                "类型": first_value(item, "type", "素材类型") or "材料",
                # V2 新增文章级字段（D5 展示 / 追溯）
                "发文字号": first_value(item, "发文字号", "doc_number", "文号"),
                "生效日期": first_value(item, "生效日期", "effectiveDate"),
                "失效日期": first_value(item, "失效日期", "expiryDate"),
                "文章类型": first_value(item, "文章类型", "文章类别"),
                "发布或实施机构": first_value(item, "发布或实施机构", "发布机关"),
                "文件标签": first_value(item, "文件标签"),
                # 外部联网材料标记（联网检索/宿主 WebSearch 路）：渲染层打「非官方来源」徽标
                "非官方来源": True if item.get("非官方来源") else "",
                "数据权威性": first_value(item, "数据权威性", "authority"),
                "核验": first_value(item, "verification", "核验", "核验说明"),
                # 所属搜索条件（多路检索时按来源分组筛选）与引用状态
                "搜索条件": first_value(item, "search_key", "搜索条件"),
                # 检索通道（深知深度搜索 / 深知可信搜索）：报告据此区分接口来源
                "检索通道": first_value(item, "检索通道"),
                "已引用": used,
            })
    # 知识专库链接区已随 3.6.0 未引用召回全量展示移除：召回内容都在报告材料面板中，
    # JSON 中残留的 knowledge_bases 字段被忽略（兼容旧 JSON，不报错）。
    content = {"data": {"检索文章": articles}}
    payload = {"answer": answer, "question": title, "content": content}
    if isinstance(data.get("检索记录"), list):
        payload["检索记录"] = data.get("检索记录")
        # 渲染入口会 unwrap 到 content 层，必须同步放进 content（与 selfCheck 同处理）
        content["检索记录"] = data.get("检索记录")
    # 成稿自检结果（5 项）由生成流程写入溯源 JSON；未写入时渲染器如实显示"未记录"
    self_check = data.get("self_check") or data.get("selfCheck")
    if isinstance(self_check, dict):
        payload["selfCheck"] = self_check
        content["selfCheck"] = self_check
    # 生成流程写入的核验说明清单，用于报告底部核验方法说明
    verify_checks = data.get("verification_checks") or data.get("verificationChecks")
    if isinstance(verify_checks, list) and verify_checks:
        payload["verificationChecks"] = [str(x) for x in verify_checks]
        content["verificationChecks"] = [str(x) for x in verify_checks]
    return payload, title, answer


def main() -> None:
    parser = argparse.ArgumentParser(description="生成产出物 HTML（正文 / 溯源核验报告 / 知识专库 三页）")
    parser.add_argument("input", help="结构化可信溯源 JSON，必须位于 official-docs/input")
    parser.add_argument("--output", "-o", help="输出 HTML 文件名，默认写入 official-docs/output")
    parser.add_argument("--skip-link-check", action="store_true",
                        help="保留参数以兼容旧命令；当前版本不做链接连通性检测")
    parser.add_argument("--disable-snapshot", action="store_true",
                        help="关闭快照兜底展示（默认启用：原文 404 时以验证过的存档快照替换）")
    args = parser.parse_args()
    if args.disable_snapshot:
        global SNAPSHOT_ENABLED
        SNAPSHOT_ENABLED = False
    input_path = resolve_input(args.input)
    data = json.loads(input_path.read_text(encoding="utf-8"))
    payload, title, answer = to_trace_payload(data)
    articles = payload.get("content", {}).get("data", {}).get("检索文章", [])
    # 2026-10-08：链接连通性检测已移除——接口返回的链接原样进报告；
    # 快照仍作附加回看入口（verify_snapshots 仅做本地路径格式校验）。
    if SNAPSHOT_ENABLED:
        dropped = verify_snapshots(articles)
        total = sum(1 for a in articles if (a.get("快照链接") or "").strip())
        print(f"快照校验：{total} 条路径合法放行 / 弃用 {dropped} 条非法路径（已自动补全 /A/，不做网络检测）")
    # 生成前校验：有素材但正文无角标 = 无法建立核验对应，拒绝生成，要求先修 JSON
    materials_count = len(data.get("materials") or [])
    # 角标形态允许半角 [n] 与全角【n】（渲染层 normalize_citations 两者都支持）
    if materials_count and not re.search(r"[\[【]\s*\d+\s*[\]】]", answer):
        print(f"错误：materials 共 {materials_count} 条，但正文 document_content 没有任何 [n] 角标，无法生成核验对应。", file=sys.stderr)
        print("请修正溯源 JSON：在正文关键结论后标注 [1]、[2] 等角标并与 materials 一一对应，然后重新运行本脚本。", file=sys.stderr)
        raise SystemExit(1)
    output_path = safe_output(args.output, title)
    renderer = load_renderer()
    # 2026-10-08：溯源报告必须含"完整的原问题"才能独立使用。
    # 仅取溯源 JSON 顶层的 question（用户原话全文，由 build_trace_json --question 写入）；
    # 历史 JSON 未带该字段时传空（渲染端不显示该行）——不得用报告标题冒充原问题。
    question = str(data.get("question") or "").strip()
    rendered = renderer.render_html(payload, title, answer_override=answer, question_override=question)
    output_path.write_text(rendered, encoding="utf-8")
    print(f"产出物 HTML（正文/溯源核验报告/知识专库 三页）已生成: {output_path}")


if __name__ == "__main__":
    main()
