# CloudBase MCP Setup Reference

## Remote versus local

Both connect to the same tools; they differ in where the server runs and therefore in what it can reach.

| | Remote (Streamable HTTP) | Local (stdio, `npx`) |
|---|---|---|
| Login | OAuth in the browser, or `X-TencentCloud-SecretId` / `X-TencentCloud-SecretKey` | `auth` tool: device-code login, or `CLOUDBASE_API_KEY` |
| CloudBase API key | not supported | supported (`CLOUDBASE_API_KEY` + `CLOUDBASE_ENV_ID`) |
| Node.js on the machine | not needed | required (18.15+) |
| `manageStorage` local file upload/download, `downloadTemplate` | not registered | yes |
| Declarative `deployBuild` / `deployPlan` / `deployApply` | not registered — deploy through the two-step upload channel instead | yes |
| `manageHosting` upload / download | blocked | yes |
| Site selection | decided by the hostname | `TCB_SITE`, defaults to domestic |
| NoSQL tools on the international site | not available | available |

Pick remote by default. Switch to local when any one of these applies:

- the account signs in with a CloudBase API key (`CLOUDBASE_API_KEY`) — remote has no API-key path
- one session has to cover both the domestic and the international site — a remote URL is bound to a single site, while local switches with `TCB_SITE`
- the task needs a tool that remote does not register: `manageStorage` for uploading or downloading local files, `downloadTemplate`, `manageCloudRun`, or the declarative `deployBuild` / `deployPlan` / `deployApply` set

**Deploying functions or apps does not require local mode.** Remote deploys through the two-step upload — `queryFunctions(action="getFunctionUploadUrl")` or `queryApps(action="getUploadUrl")` → `PUT` the zip → `manageFunctions` with the `code` triple or `manageApps(action="deployApp", cosTimestamp=…)`. What remote lacks is the declarative `cloudbaserc` executor and a dry-run before applying.

The plugin installs both (`cloudbase-remote` and `cloudbase-local`) so either path stays reachable in the same session.

## Site: domestic or international (decide first)

CloudBase has two independent account systems — 国内站 (`cloud.tencent.com`) and 国际站 (`tencentcloud.com`). Env, console, API keys, and login state do not cross over, and a wrong-site login looks like *"logged in, but no environments"*. Confirm the site before configuring MCP. Ask the user if the console domain / envId does not make it obvious.

### International (国际站)

**Preferred: connect the international remote MCP endpoint directly.** One URL, no local Node, no keys on disk.

```json
{
  "mcpServers": {
    "cloudbase": {
      "type": "http",
      "url": "https://tcb-api.tencentcloud.com/mcp/v1"
    }
  }
}
```

OAuth-capable clients finish login in the browser (DCR → login → pick env → consent). For clients without OAuth, or for CI, use the static-credential form and add the international site's key pair:

```json
{
  "mcpServers": {
    "cloudbase": {
      "type": "http",
      "url": "https://tcb-api.tencentcloud.com/mcp/v1?env_id=<env_id>",
      "headers": {
        "X-TencentCloud-SecretId": "<intl Secret ID>",
        "X-TencentCloud-SecretKey": "<intl Secret Key>"
      }
    }
  }
}
```

If the user needs **local stdio** instead (local file access, offline), set the site explicitly — the local server cannot infer it from a hostname:

```json
{
  "mcpServers": {
    "cloudbase": {
      "command": "npx",
      "args": ["@cloudbase/cloudbase-mcp@latest"],
      "env": {
        "TCB_SITE": "intl",
        "TCB_REGION": "ap-singapore"
      }
    }
  }
}
```

### Domestic (国内站)

Same shape, different host — `https://tcb-api.cloud.tencent.com/mcp/v1`. Nothing site-specific to declare: `domestic` + `ap-shanghai` are the defaults for both remote and local mode.

```json
{
  "mcpServers": {
    "cloudbase": {
      "type": "http",
      "url": "https://tcb-api.cloud.tencent.com/mcp/v1"
    }
  }
}
```

OAuth-first applies here too: the URL alone is the configuration and the browser flow binds an environment. Add `env_id` plus the domestic `X-TencentCloud-SecretId` / `X-TencentCloud-SecretKey` pair **only** for a client without OAuth or for CI — never for an interactive IDE, where a key on disk is a secret that outlives the session for no benefit.

> ⚠️ **No `site` / `region` query parameter on the remote endpoint.** The host decides the site. A domestic environment located in `ap-singapore` still uses the domestic host — do not try to switch sites with a URL parameter.
>
> ⚠️ **International has no NoSQL / document-database tools.** Route document-DB work to the domestic site or to PostgreSQL instead.

> ℹ️ `TCB_SITE` is the **MCP** variable. The `tcb` CLI uses a different one (`TCB_IS_INTL`) — see `tooling-fallback.md`.

> ℹ️ **First run?** Follow `site-onboarding.md` — it settles the site with the CLI before MCP exists, persists it where the post-restart MCP session will read it (`.cloudbase/project.json`), and covers conflict arbitration + the MCP-down fallback.

---

## Preferred: Install CloudBase Plugin (global)

When the user asks to install CloudBase / the AI Toolkit / the plugin, **prefer the Open Plugin Spec CLI** over hand-writing MCP JSON. One install brings MCP + Skills + Hooks.

Default: `--scope user` (global).

```bash
npx plugins add TencentCloudBase/cloudbase-plugin -y --scope user

# Optional: Sites plugin
npx plugins add TencentCloudBase/cloudbase-sites-plugin -y --scope user
```

- Omit `--target` to install into all detected supported AI IDEs.
- After install, ask the user to restart / reload the target tool (e.g. Claude Code `/reload-plugins`).

### No git on the machine

`npx plugins add` with `owner/repo` or an `https://` URL runs `git clone`. A CNB URL is git too. When the command fails with `program not found`, download the tarball over HTTPS and install from the local directory:

```bash
# Plugin: download → extract → install from the local directory
curl -L https://codeload.github.com/TencentCloudBase/cloudbase-plugin/tar.gz/refs/heads/main -o cloudbase-plugin.tgz
tar xzf cloudbase-plugin.tgz
npx plugins add ./cloudbase-plugin-main -y --scope user --target <target>

# Skills: an archive URL is downloaded and unpacked, and does not need git
npx skills add https://codeload.github.com/TencentCloudBase/cloudbase-skills/tar.gz/refs/heads/main -y
```

Three differences from the git install:

- `--target` is required. With no detected client the CLI fails with `No supported targets detected`.
- The marketplace name is the directory name `cloudbase-plugin-main`.
- Auto-update is off, because there is no git repo behind the install. Updating means downloading and installing again.

Windows 10+ includes `curl` and `tar`. When Git can be installed, prefer [Git for Windows](https://git-scm.com/download/win) so later updates stay on the git install.

### Supported `npx plugins` targets (`--target`)

List live detection with `npx plugins targets`. Current supported target IDs:

| Target ID (`--target`) | AI IDE | Notes |
|------------------------|--------|--------|
| `claude-code` | Claude Code | Config under `~/.claude` |
| `cursor` | Cursor | Config under `~/.cursor` |
| `codex` | Codex | Config under `~/.codex` |
| `grok` | Grok Build | Config under `~/.grok`; per-user only |
| `kimi` | Kimi Code | Config under `~/.kimi-code`; per-user only |
| `github-copilot` | GitHub Copilot CLI | Config under `~/.copilot`; standalone `copilot` CLI, not `gh copilot` |
| `vscode` | Visual Studio Code | Agent plugins (Preview); per-user only |

Examples:

```bash
npx plugins add TencentCloudBase/cloudbase-plugin -y --scope user --target cursor

npx plugins targets
```

**Not supported by `npx plugins` yet** (use each product's native path): CodeBuddy, WorkBuddy, Kimi Code, Kimi Work, ZCode, WindSurf, and other IDEs without Open Plugin Spec. For those, use Approach A (native MCP) or Approach B (mcporter) below, plus Skills if needed.

**Do not double-install:** if Claude Code / Codex already has the plugin via marketplace (`claude plugin install` / `codex plugin add`), do **not** also run `npx plugins add` for the same tool.

---

## Approach A: IDE Native MCP

Configure via your IDE's MCP settings when Plugin install is unavailable:

```json
{
  "mcpServers": {
    "cloudbase": {
      "command": "npx",
      "args": ["@cloudbase/cloudbase-mcp@latest"]
    }
  }
}
```

**Config file locations:**

- **Cursor**: `.cursor/mcp.json`
- **Claude Code**: `.mcp.json`
- **Windsurf**: `~/.codeium/windsurf/mcp_config.json` (user-level, no project-level JSON config)
- **Cline**: Check Cline settings for project-level MCP configuration file location
- **GitHub Copilot Chat (VS Code)**: Check VS Code settings for MCP configuration file location
- **Continue**: Uses YAML format in `.continue/mcpServers/` folder:
  ```yaml
  name: CloudBase MCP
  version: 1.0.0
  schema: v1
  mcpServers:
    - uses: stdio
      command: npx
      args: ["@cloudbase/cloudbase-mcp@latest"]
  ```

---

## Approach B: mcporter CLI

When your IDE does not support native MCP or Plugin install, use **mcporter** as the CLI.

**Step 1 — Check**: `npx mcporter list | grep cloudbase`

**Step 2 — Configure** (if not found): create `config/mcporter.json` in the project root:
```json
{
  "mcpServers": {
    "cloudbase": {
      "command": "npx",
      "args": ["@cloudbase/cloudbase-mcp@latest"],
      "description": "CloudBase MCP",
      "lifecycle": "keep-alive"
    }
  }
}
```

**Step 3 — Verify**: `npx mcporter describe cloudbase`

---

## Quick Start (mcporter CLI)

- `npx mcporter list` — list configured servers
- **Required:** `npx mcporter describe cloudbase --all-parameters` — inspect CloudBase server config and get full tool schemas with all parameters (⚠️ **必须加 `--all-parameters` 才能获取完整参数信息**)
- `npx mcporter list cloudbase --schema` — get full JSON schema for all CloudBase tools
- `npx mcporter call cloudbase.help --output json` — discover available CloudBase tools and their schemas
- `npx mcporter call cloudbase.<tool> key=value` — call a CloudBase tool

---

## Call Examples (CloudBase auth)

- Check auth & env status:
  `npx mcporter call cloudbase.auth action=status --output json`
- Start device-flow login:
  `npx mcporter call cloudbase.auth action=start_auth authMode=device --output json`
- Resolve env alias to full EnvId:
  `npx mcporter call cloudbase.queryEnv action=list alias=demo aliasExact=true fields='["EnvId","Alias","Status","IsDefault"]' --output json`
- Bind environment after login:
  `npx mcporter call cloudbase.auth action=set_env envId=<full-env-id> --output json`
- Query app-side login config:
  `npx mcporter call cloudbase.queryAppAuth action=getLoginConfig --output json`
- Patch app-side login strategy:
  `npx mcporter call cloudbase.manageAppAuth action=patchLoginStrategy patch='{"usernamePassword":true}' --output json`
- Query publishable key:
  `npx mcporter call cloudbase.queryAppAuth action=getPublishableKey --output json`

---

## Environment Management Tools (manageEnv + auth + queryEnv)

Beyond authentication, CloudBase MCP provides several environment management tools.

### manageEnv — Full environment lifecycle

Query available plans, create environments, change plans, and renew:

- **List available packages**:
  `npx mcporter call cloudbase.manageEnv action=listPackages --output json`

- **Create a new environment**:
  ```
  npx mcporter call cloudbase.manageEnv action=create alias=my-env packageId=baas_personal resources='["storage","function","postgresql"]' duration=1 confirm=yes --output json
  ```

  Resources parameter values: `storage` (cloud storage), `function` (cloud functions), `postgresql` (PostgreSQL database). `flexdb` (document database) is **not** offered — new environments are created without a NoSQL tenant, and passing it is rejected by the schema. To find out whether an environment actually has NoSQL, read `queryEnv(action="info")` → `EnvInfo.RuntimeBackends` instead of assuming.
  Optional `region` (e.g. `region=ap-shanghai`) selects where the environment is created: it is sent as the **`X-TC-Region` request context** (same as CLI `tcb env create --region ap-shanghai`), never as a CreateEnv body field. Omit it to use the current session region (`cloudBaseOptions.region` → `TCB_REGION` → project config / rc binding → site default: `ap-shanghai` domestic, `ap-singapore` intl). If you pass `region`, repeat the same value on the confirming call (`confirm=yes`), otherwise the environment may be created in the session region instead.

- **Change plan** (use a `packageId` from `listPackages`):
  `npx mcporter call cloudbase.manageEnv action=modifyPlan envId=<envId> packageId=<packageId> confirm=yes --output json`

- **Renew environment**:
  `npx mcporter call cloudbase.manageEnv action=renew envId=<envId> duration=12 confirm=yes --output json`

### Auth — Environment binding & logout

- **Check status** (shows env candidates when multiple environments exist):
  `npx mcporter call cloudbase.auth action=status --output json`

- **Bind to a specific environment** (after login):
  `npx mcporter call cloudbase.auth action=set_env envId=<full-env-id> --output json`

- **Logout** (clears login state and cached env binding):
  `npx mcporter call cloudbase.auth action=logout confirm=yes --output json`

### queryEnv — Query environment details

- **List all environments**:
  `npx mcporter call cloudbase.queryEnv action=list --output json`

- **Get environment info** (runtime backends, storage, status):
  `npx mcporter call cloudbase.queryEnv action=info envId=<envId> --output json`

- **Resolve alias to EnvId**:
  `npx mcporter call cloudbase.queryEnv action=list alias=demo aliasExact=true fields='["EnvId","Alias","Status","IsDefault"]' --output json`

---

## No npm / npx

If `npm` / `npx` are missing, do **not** keep retrying `npx plugins` / `npx mcporter`:

1. Ask the user to install **Node.js LTS** (https://nodejs.org, or `brew install node` / `winget install OpenJS.NodeJS.LTS` / nvm / fnm), then re-check `node -v` and `npm -v`.
2. Meanwhile, prefer **IDE native plugin / marketplace / MCP UI** paths above (no hand-run `npx`), or Approach A hand-written MCP config once Node exists.
3. For login/deploy in this session without MCP tools, follow `tooling-fallback.md` (CLI via `cloudbase-cli` domain skills). Full decision tree includes the npm-missing branch.

## Important Rules

- **When MCP tools are available in this session**, prefer them for manage/deploy, and understand tool details first. Before calling any CloudBase MCP tool, run `npx mcporter describe cloudbase --all-parameters` (or `ToolSearch` in IDE) to inspect available tools and their parameters.
- **When MCP is not configured or tools are not yet loaded** (common on first session, or right after install before restart): complete the MCP setup steps above for the **next** session, then use `tcb` CLI for login/manage now. Follow `tooling-fallback.md` and the `cloudbase-cli` skill (domain references — **not** `tcb deploy`). Do not block the user waiting for a restart.
- You **do not need to hard-code Secret ID / Secret Key / Env ID** in the config. Prefer device-code login via MCP `auth` or `tcb login` instead of storing long-lived secrets in MCP JSON.
- When the environment identifier in the conversation is an alias, nickname, or other short form, **do not pass it directly** to `auth.set_env`, SDK init, console URLs, or generated config files. First resolve it to the canonical full `EnvId` with `queryEnv(action=list, alias=..., aliasExact=true)` when MCP is available; with CLI, confirm the full envId with the user (or `tcb env list` as a fallback) before `tcb env use`. If multiple environments match or no exact alias exists, stop and clarify with the user.
- Verify MCP availability with `npx mcporter list | grep cloudbase` or the IDE's MCP panel (skip the `npx` check when npm/npx is absent — use the IDE panel / native plugin instead). Missing MCP is a signal to **set up MCP + fall back to CLI**, not to stop the task.
