---
name: skillhub-skill-daily-astro
description: "Daily horoscope for all 12 zodiac signs — love, career & finance scores (1–5★), lucky color/number/direction, daily affirmation. Morning & evening push. Bilingual EN/CN."
---

# 西方星座运势

> 西方星座运势 — 12星座每日运程 · 爱情事业财运 · 幸运元素 · 中英双语

## 何时使用

- 用户说"今日星座""我的星座运势""白羊座今天怎么样"
- 用户想查爱情运/事业运/财运
- 用户说"horoscope""zodiac""星座配对"
- 用户说"今天适合表白吗""今天适合谈合同吗"

---

## 推送管理

```bash
node scripts/push-toggle.js on <userId>
node scripts/push-toggle.js on <userId> --morning 08:00 --evening 21:00 --channel feishu
node scripts/push-toggle.js off <userId>
node scripts/push-toggle.js status <userId>
```

支持渠道：`telegram` / `feishu` / `slack` / `discord`
