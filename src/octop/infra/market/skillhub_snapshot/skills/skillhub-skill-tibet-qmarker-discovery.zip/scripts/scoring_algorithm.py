#!/usr/bin/env python3
"""
tibet-qmarker-discovery: 藏药Q-marker综合赋分排序算法

本脚本实现了藏药质量标志物发现中的核心评分逻辑，
包括：有效性评分、特有性评分、可测性评分、安全性评分 及 综合加权排序。

使用方式（在 SKILL.md 工作流中引用）：
    python3 scripts/scoring_algorithm.py --input candidates.json --output ranking.csv
"""

import json
import csv
import argparse
from typing import Dict, List, Tuple


# ─── 权重配置 ───────────────────────────────────────────

WEIGHTS = {
    "effectiveness": 0.40,  # 有效性（多靶点网络药理学）
    "specificity": 0.25,    # 特有性（藏药特有成分）
    "detectability": 0.20,  # 可测性（色谱行为与检测可行性）
    "safety": 0.15,         # 安全性（毒性基团排除）
}

# ─── 辅助函数 ────────────────────────────────────────────


def normalize(values: List[float], max_val: float = None) -> List[float]:
    """Min-max 归一化到 0-10 分制"""
    if not values:
        return []
    if max_val is None:
        max_val = max(values)
    if max_val == 0:
        return [5.0] * len(values)
    return [round(v / max_val * 10, 2) for v in values]


# ─── 四个维度的评分函数 ────────────────────────────────


def score_effectiveness(
    degree: float,
    betweenness: float,
    target_disease_count: int,
    key_pathway_count: int,
    degree_max: float = None,
    betweenness_max: float = None,
) -> float:
    """
    有效性评分（0-10）
    
    参数:
        degree: 成分在"成分-靶点"网络中的度值
        betweenness: 介数中心性
        target_disease_count: 关联疾病靶点数量
        key_pathway_count: 富集关键通路数量
    
    权重分配:
        normalized_degree × 0.35
        normalized_betweenness × 0.15
        target_disease_count_norm × 0.25
        key_pathway_count_norm × 0.25
    """
    d_norm = min(degree / (degree_max or degree or 1), 1.0) * 10
    b_norm = min(betweenness / (betweenness_max or betweenness or 1), 1.0) * 10
    td_norm = min(target_disease_count / 10, 1.0) * 10
    kp_norm = min(key_pathway_count / 5, 1.0) * 10

    score = (
        d_norm * 0.35 +
        b_norm * 0.15 +
        td_norm * 0.25 +
        kp_norm * 0.25
    )
    return round(score, 2)


def score_specificity(
    frequency_in_tcm: int,
    total_tcm_count: int = 500,
) -> float:
    """
    特有性评分（0-10）

    参数:
        frequency_in_tcm: 该成分在常见中药库中出现的味数
        total_tcm_count: 中药库总味数（默认500+）
    
    规则:
        ≤2味出现（藏药特有）→ 10分
        3-10味共有 → 7分
        11-50味共有 → 4分
        >50味共有 → 1分
    """
    if frequency_in_tcm <= 2:
        return 10.0
    elif frequency_in_tcm <= 10:
        return 7.0
    elif frequency_in_tcm <= 50:
        return 4.0
    else:
        return 1.0


def score_detectability(
    molecular_weight: float,
    logp: float = None,
    has_uv_absorb: bool = True,
    has_ms_ionization: bool = True,
    has_lc_retention: bool = True,
) -> float:
    """
    可测性评分（0-10）

    参数:
        molecular_weight: 分子量（Da）
        logp: 脂水分配系数
        has_uv_absorb: 是否有紫外吸收
        has_ms_ionization: 是否可ESI电离
        has_lc_retention: 是否有液相手性保留

    规则:
        HPLC-MS/MS可同时检测，紫外吸收强 → 10分
        HPLC-MS/MS可检测，紫外吸收弱 → 7分
        仅HPLC-MS可检测 → 4分
        检测困难 → 1分
    """
    # 基础判定：分子量是否在LC-MS可测范围
    if not (100 < molecular_weight < 1000):
        return 1.0

    if has_lc_retention and has_ms_ionization and has_uv_absorb:
        return 10.0
    elif has_lc_retention and has_ms_ionization:
        return 7.0
    elif has_ms_ionization:
        return 4.0
    else:
        return 1.0


def score_safety(
    has_toxic_substructure: bool = False,
    ames_test_positive: bool = False,
    hepatotoxic: bool = False,
) -> float:
    """
    安全性评分（0-10）

    参数:
        has_toxic_substructure: 是否含有已知毒性基团
        ames_test_positive: Ames试验是否阳性
        hepatotoxic: 是否有肝毒性预测
    """
    if has_toxic_substructure or ames_test_positive or hepatotoxic:
        return 1.0
    return 9.0  # 默认安全，扣1分以体现保守原则


# ─── 综合评分与排序 ───────────────────────────────────


def compute_composite_score(
    effect: float,
    specificity: float,
    detectability: float,
    safety: float,
) -> float:
    """加权综合评分（满分100分制）"""
    return round(
        effect * WEIGHTS["effectiveness"] * 10 +
        specificity * WEIGHTS["specificity"] * 10 +
        detectability * WEIGHTS["detectability"] * 10 +
        safety * WEIGHTS["safety"] * 10,
        2
    )


def rank_candidates(
    candidates: List[Dict],
    effect_max: float = None,
    betweenness_max: float = None,
) -> List[Dict]:
    """
    对所有候选成分进行综合评分并排序
    
    参数:
        candidates: 候选成分列表，每个元素为字典，包含:
            - name: 成分名称
            - cas: CAS号
            - degree: 网络度值
            - betweenness: 介数
            - target_disease_count: 关联疾病靶点数
            - key_pathway_count: 关键通路数
            - frequency_in_tcm: 常见中药出现频次
            - molecular_weight: 分子量
            - has_uv_absorb: 紫外吸收
            - has_ms_ionization: MS电离
            - has_lc_retention: LC保留
            - has_toxic_substructure: 毒性基团
    """
    # 提取各维度原始值，计算归一化基准
    degrees = [c.get("degree", 0) for c in candidates]
    betweennesses = [c.get("betweenness", 0) for c in candidates]

    d_max = effect_max or (max(degrees) if degrees else 1)
    b_max = betweenness_max or (max(betweennesses) if betweennesses else 1)

    for c in candidates:
        effect = score_effectiveness(
            degree=c.get("degree", 0),
            betweenness=c.get("betweenness", 0),
            target_disease_count=c.get("target_disease_count", 0),
            key_pathway_count=c.get("key_pathway_count", 0),
            degree_max=d_max,
            betweenness_max=b_max,
        )
        spec = score_specificity(
            frequency_in_tcm=c.get("frequency_in_tcm", 50)
        )
        detect = score_detectability(
            molecular_weight=c.get("molecular_weight", 400),
            has_uv_absorb=c.get("has_uv_absorb", True),
            has_ms_ionization=c.get("has_ms_ionization", True),
            has_lc_retention=c.get("has_lc_retention", True),
        )
        safe = score_safety(
            has_toxic_substructure=c.get("has_toxic_substructure", False),
            ames_test_positive=c.get("ames_test_positive", False),
            hepatotoxic=c.get("hepatotoxic", False),
        )
        
        total = compute_composite_score(effect, spec, detect, safe)

        c["effectiveness_score"] = effect
        c["specificity_score"] = spec
        c["detectability_score"] = detect
        c["safety_score"] = safe
        c["composite_score"] = total

        # 推荐类型判定
        if total >= 80 and effect >= 8.0 and spec >= 7.0:
            c["recommendation_type"] = "单体标志物"
        elif total >= 60:
            c["recommendation_type"] = "组分簇候选"
        else:
            c["recommendation_type"] = "参考候选"

    # 按综合评分降序排列
    ranked = sorted(candidates, key=lambda x: x["composite_score"], reverse=True)
    return ranked


# ─── 输入输出 ──────────────────────────────────────────


def format_ranking_table(ranked: List[Dict], top_n: int = 10) -> str:
    """输出排名表格的 Markdown 文本"""
    lines = []
    lines.append(f"| 排名 | 成分名称 | CAS号 | 有效性(40%) | 特有性(25%) | 可测性(20%) | 安全性(15%) | 总分 | 推荐类型 |")
    lines.append(f"|------|---------|-------|:----------:|:----------:|:----------:|:----------:|:----:|:--------:|")
    
    for i, c in enumerate(ranked[:top_n], 1):
        lines.append(
            f"| {i} | {c.get('name', 'N/A')} "
            f"| {c.get('cas', 'N/A')} "
            f"| {c.get('effectiveness_score', 0):.1f} "
            f"| {c.get('specificity_score', 0):.1f} "
            f"| {c.get('detectability_score', 0):.1f} "
            f"| {c.get('safety_score', 0):.1f} "
            f"| {c.get('composite_score', 0):.1f} "
            f"| {c.get('recommendation_type', 'N/A')} |"
        )
    return "\n".join(lines)


def export_csv(ranked: List[Dict], filepath: str):
    """导出 CSV 格式的排名结果"""
    if not ranked:
        return
    fields = [
        "name", "cas", "effectiveness_score", "specificity_score",
        "detectability_score", "safety_score", "composite_score",
        "recommendation_type"
    ]
    with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(ranked)


# ─── CLI 入口 ──────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(description="藏药Q-marker综合赋分排序工具")
    parser.add_argument("--input", "-i", required=True, help="输入JSON文件路径（候选成分列表）")
    parser.add_argument("--output", "-o", default="qmarker_ranking.csv", help="输出CSV文件路径")
    parser.add_argument("--top", "-n", type=int, default=10, help="输出Top N结果")
    args = parser.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        candidates = json.load(f)

    ranked = rank_candidates(candidates)
    
    print(f"\n{'='*60}")
    print(f"藏药Q-marker综合评分排名 (Top {args.top})")
    print(f"{'='*60}\n")
    print(format_ranking_table(ranked, top_n=args.top))
    print()
    
    # 区分单体标志物与组分簇
    single_markers = [c for c in ranked if c.get("recommendation_type") == "单体标志物"]
    cluster_candidates = [c for c in ranked if c.get("recommendation_type") == "组分簇候选"]
    if single_markers:
        print(f"✓ 单体标志物候选: {', '.join(c['name'] for c in single_markers)}")
    if cluster_candidates:
        print(f"○ 组分簇候选: {', '.join(c['name'] for c in cluster_candidates)}")
    print()

    export_csv(ranked, args.output)
    print(f"结果已导出至: {args.output}")


if __name__ == "__main__":
    main()
