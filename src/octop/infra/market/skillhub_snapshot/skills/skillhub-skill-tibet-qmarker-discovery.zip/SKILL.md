---
name: skillhub-skill-tibet-qmarker-discovery
description: "# 藏药质量标志物（Q-marker）智能发现技能 v1.0"
---

# 藏药质量标志物（Q-marker）智能发现技能 v1.0

## 技能概述

本技能构建了一套**完整的中藏药质量标志物（Q-marker）智能发现工作流**，融合网络药理学、分子对接、ADME预测及多组学数据挖掘技术，遵循刘昌孝院士提出的Q-marker"五原则"理论框架（有效性、特有性、可测性、配伍环境、安全性），对藏药单味药或复方进行系统性Q-marker筛选与排序。

**核心价值：** 将传统的"湿实验"Q-marker发现流程数字化、智能化，减少盲目筛选成本，为藏药质量控制提供数据驱动的候选清单。

---

## 触发条件

当用户输入以下类型请求时，**必须触发**本技能：

1. **单味藏药分析：** "分析[藏药名]的Q-marker" / "找[藏药名]的质量标志物"
   - 示例红景天、诃子、佐太、藏茵陈、余甘子、波棱瓜、翼首草、绿绒蒿等
2. **复方分析：** "分析[藏药复方名]的Q-marker" / "找[复方名]的质量标志物"
   - 示例：二十五味珊瑚丸、仁青芒觉、七十味珍珠丸、坐珠达西等
3. **成分筛选：** "筛选[藏药名]的活性成分" / "评估[藏药名]的入血成分"

**拒绝触发条件：**
- 非藏药体系药材（如人参、黄芪、甘草等常见中药）→ 拒绝并提示："请提供藏药品种。本技能专用于藏药体系药材及复方质量标志物发现。"
- 非药材/复方类查询 → 拒绝并提示："请输入藏药单味药材或藏药复方名称。"

---

## 执行工作流（6大步骤）

### 步骤一：智能文献与数据库挖掘（输入端）

#### 1.1 自动检索数据库清单

| 数据库 | 用途 | 检索优先级 |
|--------|------|-----------|
| **TCMSP** (tcmsp-e.com) | 获取成分、OB、DL、靶点 | 首选 |
| **TCMID** (bidd.group/TCMID) | 补充藏药特有成分与靶点 | 高 |
| **PubChem** (pubchem.ncbi.nlm.nih.gov) | 获取分子结构、SMILES、理化性质 | 高 |
| **CNKI** (cnki.net) | 中文学术文献 | 中 |
| **PubMed** (pubmed.ncbi.nlm.nih.gov) | 英文学术文献 | 中 |
| **BATMAN-TCM** (bionet.ncpsb.org.cn/batman-tcm) | 成分-靶点关系挖掘 | 中 |
| **ETCM** (tcmip.cn/ETCM) | 中药成分与靶点补充 | 中 |
| **SwissTargetPrediction** | 基于结构的靶点预测 | 验证用 |
| **HERB** (herb.ac.cn) | 本草组鉴数据库 | 中 |

#### 1.2 藏药多基原处理规则

藏药普遍存在"多基原"现象（如藏茵陈包括川西獐牙菜、印度獐牙菜、抱茎獐牙菜、花锚等多个物种），处理规则：

1. **优先筛选藏区特有物种**成分（标注"西藏特有"或"青藏高原特有"）
2. 若数据库无明确物种标记，默认优先收录**藏药典收载品**
3. 记录每个成分的基原来源，最终分析时注明"多基原共有 / XX特有"

#### 1.3 知识图谱初始化

以目标药材/复方为根节点，构建初始"成分-靶点"知识图谱框架：
- 节点类型：药材、化合物、靶点蛋白、通路、疾病
- 关系类型：含有、作用于、参与、关联

---

### 步骤二："五原则"智能筛选引擎（核心分析层）

#### 2.1 特有性评估

**操作：** 将目标藏药的成分谱与《中国药典》收录的常见中药成分库进行比对。

```
算法逻辑（伪代码）：
input:  target_compounds  ← 目标藏药所有成分列表
       common_tcm_compounds ← 常见中药成分库（含500+味中药）

for each compound in target_compounds:
    frequency_in_tcm = count_occurrences(compound, common_tcm_compounds)
    specificity_score = 1 - (frequency_in_tcm / total_tcm_count)
    if specificity_score > 0.8:
        tag = "藏药高特有性成分（特有性频次<20%）"
    elif specificity_score > 0.5:
        tag = "藏药中等特有性成分（特有性频次20-50%）"
    else:
        tag = "常见中药共有成分"
```

**特有性打分（0-10）：**
- 仅在藏药报道（≤2味其他中药出现）→ 10分
- 3-10味其他中药共有 → 7分
- 11-50味共有 → 4分
- >50味共有 → 1分

#### 2.2 可测性评估

**操作：** 基于理化性质预测成分的色谱行为与检测可行性。

```
算法逻辑（伪代码）：
input: compound_list with SMILES

for each compound:
    MW = calculate_molecular_weight(SMILES)
    LogP = calculate_logP(SMILES)
    HBD = count_hydrogen_bond_donors(SMILES)
    HBA = count_hydrogen_bond_acceptors(SMILES)
    rotatable_bonds = count_rotatable_bonds(SMILES)

    # 液相可测性判定
    if 100 < MW < 1000:
        lc_detectable = True
    else:
        lc_detectable = False

    # UV吸收判定
    uv_absorbing = has_conjugated_system(SMILES)  # 含共轭体系
    # MS可电离性判定
    ms_ionizable = can_ionize_in_esi(SMILES)  # ESI正/负离子模式

    detectability_score = score(
        lc_detectable * 0.4 +
        uv_absorbing * 0.3 +
        ms_ionizable * 0.3
    )
```

**可测性打分（0-10）：**
- HPLC-MS/MS可同时检测，紫外吸收强 → 10分
- HPLC-MS/MS可检测，紫外吸收弱 → 7分
- 仅HPLC-MS可检测 → 4分
- 检测困难 → 1分

#### 2.3 有效性评估（网络药理学核心）

**操作：** 构建"成分-靶点-通路"网络，计算网络拓扑参数。

```
算法逻辑（伪代码）：
input: component_target_map, disease_targets

# 步骤1：构建成分-靶点网络
G = build_bipartite_network(components, targets)

# 步骤2：计算拓扑参数
for each node in G:
    degree = calculate_degree(G, node)
    betweenness = calculate_betweenness_centrality(G, node)

# 步骤3：靶点-疾病关联
for each target in targets:
    if target in disease_targets:
        disease_association = True
        disease_count = count_associated_diseases(target)

# 步骤4：通路富集分析（KEGG/GO）
pathways = enrich_kegg_pathways(targets, p_value < 0.05)
key_pathways = filter_by_relevance(pathways, target_disease)

# 步骤5：成分有效性综合打分
for each component C:
    effectiveness_score = (
        normalized_degree(C) * 0.35 +
        normalized_betweenness(C) * 0.15 +
        target_disease_count(C) * 0.25 +
        key_pathway_count(C) * 0.25
    )
```

**推荐靶点清单（默认用于通路分析）：**
- 炎症靶点：COX-2 (PTGS2), TNF-α, IL-6, IL-1β, NF-κB
- 血管新生靶点：VEGF, VEGFR2, HIF-1α
- 细胞增殖靶点：EGFR, AKT1, MAPK1/3, PI3K
- 氧化应激靶点：Nrf2, SOD, CAT, HO-1
- 神经保护靶点：BDNF, NGF, TrkB, GSK-3β

#### 2.4 配伍传递性评估（复方专用）

**操作：** 针对复方制剂，追踪君药成分的炮制加工及煎煮过程化学转化。

```
# 复方分析追加步骤
if input_type == "复方":
    君药 = identify_emperor_drug(formula)
    for each component in 君药.components:
        # 炮制影响评估
        processing_impact = assess_processing_effect(
            component,
            processing_method
        )
        # 煎煮含量迁移
        decoction_transfer = estimate_decoction_rate(
            component,
            water_solubility,
            thermal_stability
        )
        # 复方配伍稳定性
        compatibility_stability = assess_stability_in_matrix(
            component,
            other_herb_components
        )
        compatibility_score = score(
            processing_impact * 0.3 +
            decoction_transfer * 0.4 +
            compatibility_stability * 0.3
        )
```

#### 2.5 安全性评估

**操作：** 排除有明显毒性基团的成分。

```
toxicity_flags = [
    "吡咯里西啶生物碱（PAs）",
    "马兜铃酸", "乌头碱型二萜生物碱",
    "雷公藤甲素", "鬼臼毒素",
    "含氰苷结构", "强心苷", "蒽醌类（大黄型）高危"
]

for each compound:
    substructure_warning = detect_toxic_substructures(SMILES, toxicity_flags)
    if substructure_warning:
        safety_score = 1  # 极低，标记为高风险
        recommendation = "排除"
    else:
        safety_score = 8  # 默认安全
        # 进一步进行ADMET预测（步骤三细化）
```

---

### 步骤三：虚拟筛选与ADME评估（验证层）

#### 3.1 类药性评估

```
规则：Lipinski Ro5（类药五规则）
- 分子量（MW）≤ 500
- LogP ≤ 5
- 氢键供体（HBD）≤ 5
- 氢键受体（HBA）≤ 10

补充规则（Veber规则）：
- 可旋转键数 ≤ 10
- 极性表面积（PSA）≤ 140 Å²
```

**OB（口服生物利用度）打分：**
- OB ≥ 30% → 10分（高口服利用度）
- 30% > OB ≥ 10% → 6分（中等）
- OB < 10% → 2分（低）

**DL（类药性）打分：**
- DL ≥ 0.18 → 10分（类药性好）
- 0.18 > DL ≥ 0.10 → 6分（中等）
- DL < 0.10 → 2分（类药性差）

#### 3.2 分子对接模拟

**操作方法：** 指导用户使用AutoDock Vina/Discovery Studio/PyRx等工具进行对接，或基于经验数据直接评估。

```
default_target_panel = [
    {"target": "COX-2 (PTGS2)", "pdb_id": "5F19", "disease": "炎症"},
    {"target": "VEGF", "pdb_id": "2VPF", "disease": "血管新生"},
    {"target": "EGFR", "pdb_id": "1M17", "disease": "细胞增殖"},
    {"target": "NF-κB p50", "pdb_id": "1SVC", "disease": "炎症信号"},
    {"target": "AKT1", "pdb_id": "4GV1", "disease": "凋亡"},
]

binding_affinity_thresholds:
  strong: -9.0 kcal/mol  # 强结合（≤-9.0）
  moderate: -7.0 kcal/mol  # 中等结合（≤-7.0）
  weak: -5.0 kcal/mol  # 弱结合（≤-5.0）
```

**分子对接打分映射：**
- Affinity ≤ -9.0 kcal/mol → 10分
- -9.0 < Affinity ≤ -7.0 → 7分
- -7.0 < Affinity ≤ -5.0 → 4分
- Affinity > -5.0 → 1分

---

### 步骤四：综合赋分排序模型（输出层）

#### 4.1 加权评分卡

| 维度 | 权重 | 评分来源 | 计分范围 |
|------|------|----------|---------|
| 有效性（多靶点） | 40% | 网络药理学Degree+通路富集 | 0-10 |
| 特有性 | 25% | 中药成分交叉比对 | 0-10 |
| 可测性 | 20% | ADME预测+色谱行为 | 0-10 |
| 安全性 | 15% | 毒性基团检测+ADMET | 0-10 |

```
综合评分 = 有效性评分 * 0.40 + 特有性评分 * 0.25 + 
           可测性评分 * 0.20 + 安全性评分 * 0.15
```

#### 4.2 排序与输出规则

```
1. 对所有候选成分按综合评分降序排列
2. 输出 Top 10 ~ Top 20 候选Q-marker（成分≥20时取Top 20，否则全部列出）
3. 明确标注每个成分的打分明细（4个维度的单项分）
4. 区分两类输出：
   - 单体标志物（Single Marker）：综合评分≥8.0且各项评分均衡
   - 专属性药效组分簇（Q-marker Cluster）：需2-5个成分组合表征质量控制
```

#### 4.3 推荐理由生成

对Top 5候选成分，每一条需包含：
- **特有性依据：** 该成分在藏药体系的报道频次及分布特征
- **药理学依据：** 核心靶点及通路
- **可测性依据：** 推荐的检测方法（HPLC/UPLC-MS/MS等）
- **安全性结论：** 风险评估摘要

---

### 步骤五：可视化与报告生成（展示层）

#### 5.1 维恩图（Venn Diagram）描述

以文字形式描述筛选逻辑的交集关系：

```
[维恩图描述]
圈1 - 有效性筛选通过（Degree Top 30% + 通路富集P<0.05）
圈2 - 特有性筛选通过（特有性评分≥6分）
圈3 - 可测性筛选通过（LC-MS可测 + UV吸收或MS可电离）
圈4 - 安全性筛选通过（无已知毒性基团）

交集区域分析：
- 四圈交集成分为"核心候选Q-marker"（推荐优先关注）
- 三圈交集成分为"次级候选Q-marker"
- 两圈交集成分为"参考候选Q-marker"
```

#### 5.2 网络拓扑图（文字描述版）

以文字格式描述"成分-靶点-通路"网络的核心节点：

```
[网络拓扑摘要]
网络总节点数：XXX（成分XX个 + 靶点XX个）
网络总边数：XXX条

核心成分节点（Degree Top 5）：
1. [成分A] - Degree: XX, Betweenness: X.XX
2. [成分B] - Degree: XX, Betweenness: X.XX
...

关键靶点节点（Degree Top 5）：
1. [靶点A] - Degree: XX, 关联成分数: XX
2. [靶点B] - Degree: XX, 关联成分数: XX
...

富集通路TOP 5：
1. [通路名称] - P-value: X.XX×10^-X, 涉及成分: [XX个]
2. [通路名称] - P-value: X.XX×10^-X, 涉及成分: [XX个]
```

#### 5.3 雷达图（综合评分对比）

以文字+表格形式呈现Top 5候选成分的四维评分雷达对比：

```
        有效性(40%)
            ▲
            │
  安全性(15%)┼─────▶ 可测性(20%)
            │
            │
         特有性(25%)

Top 5候选成分评分对照表：
┌──────┬────────┬────────┬────────┬────────┬──────┐
│ 成分  │ 有效性 │ 特有性 │ 可测性 │ 安全性 │ 总分 │
│      │ (40%)  │ (25%)  │ (20%)  │ (15%)  │(100) │
├──────┼────────┼────────┼────────┼────────┼──────┤
│ 成分A │  9.0   │  8.5   │  9.0   │  9.0   │ 88.8 │
│ 成分B │  8.5   │  9.5   │  7.0   │  8.5   │ 84.3 │
│ ...   │  ...   │  ...   │  ...   │  ...   │ ...  │
└──────┴────────┴────────┴────────┴────────┴──────┘
```

#### 5.4 结论摘要（≤500字）

结论摘要必须包含：
1. **目标药材/复方简介**（1-2句）
2. **筛选池规模**（初始成分数 → 各步筛选后剩余数）
3. **Top 3候选Q-marker及推荐理由**（含单体/组分簇标注）
4. **检测建议**（推荐的分析方法与对照品建议）
5. **局限性声明**（哪些为in silico预测数据，需要实验验证）

---

### 步骤六：验证与更新（持续改进层）

每次执行完成后，记录以下信息用于技能迭代：

1. **数据库覆盖情况：** 哪些数据库成功返回数据，哪些无结果
2. **成分匹配率：** 目标药材在数据库中的成分覆盖率
3. **执行异常：** 是否有步骤因缺少数据而跳过
4. **用户反馈：** 分析结论是否得到确认

---

## 输出模板

### 完整分析报告模板

```markdown
# 藏药Q-marker智能发现报告

## 基本信息
- **分析目标：** [药材/复方名]
- **基原物种：** [拉丁学名]
- **数据库检索日期：** [YYYY-MM-DD]
- **总筛选成分数：** [XX个]

---

## 一、成分筛选流程概览（漏斗图）

步骤1 - 数据库挖掘: [XX] 个成分 ↘
步骤2 - 有效性筛选: [XX] 个成分 ↘
步骤3 - 特有性筛选: [XX] 个成分 ↘
步骤4 - 可测性筛选: [XX] 个成分 ↘
步骤5 - 安全性筛选: [XX] 个成分 ↘
**最终候选: [XX] 个成分**

---

## 二、Top 10 候选Q-marker排名

| 排名 | 成分名称 | CAS号 | 分子式 | 有效性(40%) | 特有性(25%) | 可测性(20%) | 安全性(15%) | 总分 | 推荐类型 |
|------|---------|-------|-------|:----------:|:----------:|:----------:|:----------:|:----:|:--------:|
| 1 | [成分A] | [CAS] | [MF] | X.X | X.X | X.X | X.X | XX.X | 单体标志物 |
| 2 | [成分B] | [CAS] | [MF] | X.X | X.X | X.X | X.X | XX.X | 单体标志物 |
| 3 | [成分C] | [CAS] | [MF] | X.X | X.X | X.X | X.X | XX.X | 组分簇 |
| ... | ... | ... | ... | ... | ... | ... | ... | ... | ... |

---

## 三、Top 5 候选成分详细分析

### 1. [成分A] — 综合评分: XX.X

**特有性依据：**
[内容]

**药理学依据：**
- 核心靶点：[靶点1]、[靶点2]、[靶点3]
- 关键通路：[通路1]、[通路2]
- Degree值：XX | Betweenness：X.XX

**可测性依据：**
- 推荐检测方法：HPLC-MS/MS (ESI+/−)
- m/z：[XX]→[XX]
- 紫外吸收λmax：[XX nm]

**安全性结论：**
[风险评估摘要]

[成分B、C、D、E 同样格式]

---

## 四、Q-marker Cluster 推荐（如适用）

| 组分簇 | 组成成分 | 簇特征 | 推荐质控指标 |
|--------|---------|--------|-------------|
| [簇名] | [成A+成B+成C] | [药效协同/谱效关联] | [HPLC指纹图谱峰面积比] |

---

## 五、结论摘要

[≤500字专业性结论]

---

## 六、数据来源与声明

- **数据库来源：** [列出实际检索到的数据库]
- **预测数据标注：** 标注有 *in silico* 的数据均为计算预测值
- **局限性：** 本报告基于公开数据库与计算模拟生成，Q-marker最终确认需结合
  血清药物化学、药代动力学及体内药效学实验验证。
```

---

## 关键约束与声明

1. **数据来源标注规则：** 所有成分信息必须注明来自哪个数据库。若为预测数据（如SwissTargetPrediction的靶点预测），必须标注 "(in silico)"。
2. **"干实验"优先方向：** 本版本侧重于计算筛选与网络药理学分析（干实验方向）。若用户需要"湿实验"方向（血清药物化学、谱效关系等），请在请求中说明。
3. **多基原处理：** 若目标药材存在多基原，必须在报告中明确说明分析的基原物种范围，并标注"多基原共有成分"与"XX物种特有成分"。
4. **否定结果输出：** 若某步骤未能筛选出成分（如数据库无返回结果），禁止跳过——必须在报告中明确说明"该步骤无数据"并分析原因。
5. **版本标识：** 每次分析报告自动包含版本号（tibet-qmarker-discovery v1.0）以备追溯。

---

## 附录：快速参考列表

### 常见藏药中英文对照

| 藏药名称 | 拉丁学名 | 科属 | 藏文名 |
|---------|---------|------|--------|
| 红景天 | Rhodiola rosea / R. crenulata | 景天科 | 索罗玛宝 |
| 诃子 | Terminalia chebula | 使君子科 | 阿如拉 |
| 余甘子 | Phyllanthus emblica | 大戟科 | 居如拉 |
| 藏茵陈 | Swertia spp. (多基原) | 龙胆科 | 蒂达 |
| 翼首草 | Pterocephalus hookeri | 川续断科 | 榜资多沃 |
| 绿绒蒿 | Meconopsis spp. | 罂粟科 | 欧贝 |
| 波棱瓜 | Herpetospermum pedunculosum | 葫芦科 | 色吉美多 |
| 佐太 | 炮制汞剂 | — | 佐太 |
| 麝香 | Moschus | 鹿科 | 拉孜 |
| 牛黄 | Calculus Bovis | — | 格旺 |

### 常用分子对接PDB ID速查

| 靶点 | PDB ID | 配体准备 |
|------|--------|---------|
| COX-2 | 5F19 | 去除原配体，加水加氢 |
| VEGFR2 | 4AG8 | 仅保留A链 |
| EGFR | 1M17 | 提取激酶域 |
| AKT1 | 4GV1 | pH 7.4离子化 |
| NF-κB | 1SVC | p50亚基 |
| TNF-α | 2AZ5 | 三聚体形式 |
| PPAR-γ | 2XRM | 配体结合域 |
| Nrf2-Keap1 | 2FLU | Keap1 Kelch域 |
