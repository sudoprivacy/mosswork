#!/usr/bin/env node
/**
 * UnityClaw Image (Premium 2) - CLI Generator
 */

import { existsSync, mkdirSync, statSync } from 'fs';
import { resolve } from 'path';
import { fileURLToPath } from 'url';
import { parseArgs } from 'util';

const SKILL_VERSION = '1.0.2';
const REQUIRED_SDK_VERSION = '2.0.1';
const DEFAULT_TIMEOUT_MS = 900000;
const DEFAULT_RETRIES = 1;
const SIZE_OPTIONS = ['1K', '2K', '4K'];
const ASPECT_RATIO_OPTIONS = ['1:1', '9:16', '16:9', '4:3', '3:4', '3:2', '2:3', '5:4', '4:5', '21:9', '1:4', '1:8', '4:1', '8:1'];

function printHelp() {
  console.log(`
UnityClaw Image (Premium 2) - CLI Generator v${SKILL_VERSION}

Usage:
  node scripts/generate.js --prompt "A cinematic mountain sunrise" --size "2K"
  node scripts/generate.js --prompt "Luxury perfume product shot" --attachment ./ref.png --aspect-ratio "4:5" --size "4K"

Parameters:
  --prompt, -p          Image generation prompt (required)
  --attachment, -a      Reference image URL or local path; repeat this option or use comma-separated values
  --aspect-ratio, -r    Aspect ratio
  --size, -s            Output resolution tier: 1K, 2K, 4K (default: "2K")
  --output-dir          Task output directory (default: "./tasks")
  --timeout             Request timeout in milliseconds (default: ${DEFAULT_TIMEOUT_MS})
  --retries             Retries for transient failures, from 0 to 3 (default: ${DEFAULT_RETRIES})
  --json                Print one machine-readable JSON result
  --help, -h            Show this help
`);
}

function parseInteger(value, name, minimum, maximum) {
  if (!/^\d+$/.test(value)) {
    throw new Error(`${name} must be an integer between ${minimum} and ${maximum}`);
  }
  const number = Number(value);
  if (number < minimum || number > maximum) {
    throw new Error(`${name} must be between ${minimum} and ${maximum}`);
  }
  return number;
}

function normalizeAttachments(inputs) {
  const values = inputs
    .flatMap((input) => String(input).split(','))
    .map((item) => item.trim())
    .filter(Boolean);

  return values.map((value) => {
    if (/^https?:\/\//i.test(value)) return { tmp_url: value };

    const path = resolve(value);
    if (!existsSync(path)) throw new Error(`Attachment not found: ${path}`);
    if (!statSync(path).isFile()) throw new Error(`Attachment is not a file: ${path}`);
    return { path };
  });
}

function errorText(value) {
  try {
    return typeof value === 'string' ? value : JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function isRetryable(value) {
  const text = errorText(value);
  return /ECONNRESET|ECONNABORTED|ETIMEDOUT|ENOTFOUND|EAI_AGAIN|socket hang up|network|timed?\s*out|\b429\b|\b502\b|\b503\b|\b504\b|temporar(?:y|ily) unavailable/i.test(text);
}

function getFailureMessage(result) {
  return result?.response?.msg
    || [...(result?.logs || [])].reverse().find((log) => log.level === 'error')?.message
    || 'Image generation failed';
}

function validateDownloadedFiles(items) {
  return items.map((item, index) => {
    if (!item.localPath) {
      throw new Error(`Generated image ${index + 1} has no localPath`);
    }

    const localPath = resolve(item.localPath);
    if (!existsSync(localPath)) {
      throw new Error(`Generated image ${index + 1} was not downloaded: ${localPath}`);
    }

    const stats = statSync(localPath);
    if (!stats.isFile()) {
      throw new Error(`Generated image ${index + 1} is not a file: ${localPath}`);
    }
    if (stats.size === 0) {
      throw new Error(`Generated image ${index + 1} is empty: ${localPath}`);
    }

    return {
      name: item.name,
      contentType: item.contentType,
      localPath,
      bytes: stats.size,
      temporaryUrl: item.content,
    };
  });
}

function sleep(milliseconds) {
  return new Promise((resolvePromise) => setTimeout(resolvePromise, milliseconds));
}

function emitFailure({ json, code, message, retryable = false, attempts = 0, outputDir, result }) {
  const payload = {
    success: false,
    error: { code, message, retryable },
    attempts,
    outputDir,
    taskId: result?.taskId,
    taskFolder: result?.taskFolder,
    logs: result?.logs,
  };

  if (json) {
    console.log(JSON.stringify(payload));
  } else {
    console.error(`\x1b[31mError: ${message}\x1b[0m`);
    if (result?.taskFolder) console.error(`Task Folder: ${result.taskFolder}`);
  }
  process.exitCode = 1;
}

async function main() {
  let values;
  try {
    ({ values } = parseArgs({
      options: {
        prompt: { type: 'string', short: 'p', default: '' },
        attachment: { type: 'string', short: 'a', multiple: true, default: [] },
        'aspect-ratio': { type: 'string', short: 'r', default: '' },
        size: { type: 'string', short: 's', default: '2K' },
        'output-dir': { type: 'string', default: './tasks' },
        timeout: { type: 'string', default: String(DEFAULT_TIMEOUT_MS) },
        retries: { type: 'string', default: String(DEFAULT_RETRIES) },
        json: { type: 'boolean', default: false },
        help: { type: 'boolean', short: 'h', default: false },
      },
      allowPositionals: false,
    }));
  } catch (error) {
    emitFailure({ json: process.argv.includes('--json'), code: 'INVALID_ARGUMENTS', message: error.message });
    return;
  }

  if (values.help) {
    printHelp();
    return;
  }

  const json = values.json;
  const prompt = values.prompt.trim();
  const aspectRatio = values['aspect-ratio'].trim();
  const rawOutputDir = values['output-dir'].trim();
  let timeout;
  let retries;
  let attachments;

  try {
    if (!prompt) throw new Error('--prompt is required and cannot be blank');
    if (!SIZE_OPTIONS.includes(values.size)) throw new Error(`Invalid size "${values.size}". Use: ${SIZE_OPTIONS.join(', ')}`);
    if (aspectRatio && !ASPECT_RATIO_OPTIONS.includes(aspectRatio)) {
      throw new Error(`Invalid aspect ratio "${aspectRatio}". Use: ${ASPECT_RATIO_OPTIONS.join(', ')}`);
    }
    if (!rawOutputDir) throw new Error('--output-dir cannot be blank');
    timeout = parseInteger(values.timeout, '--timeout', 1000, 3600000);
    retries = parseInteger(values.retries, '--retries', 0, 3);
    attachments = normalizeAttachments(values.attachment);
  } catch (error) {
    emitFailure({ json, code: 'VALIDATION_ERROR', message: error.message });
    return;
  }

  const outputDir = resolve(rawOutputDir);
  try {
    mkdirSync(outputDir, { recursive: true });
  } catch (error) {
    emitFailure({ json, code: 'OUTPUT_DIR_ERROR', message: `Cannot create output directory ${outputDir}: ${error.message}`, outputDir });
    return;
  }

  let UnityClawClient;
  let SDK_VERSION;
  try {
    const sdk = await import('fieldkit-sdk');
    UnityClawClient = sdk.UnityClawClient;
    SDK_VERSION = sdk.SDK_VERSION;
  } catch {
    emitFailure({
      json,
      code: 'SDK_NOT_FOUND',
      message: 'fieldkit-sdk is not installed. Run: npm install fieldkit-sdk@2.0.1',
      outputDir,
    });
    return;
  }

  if (SDK_VERSION !== REQUIRED_SDK_VERSION) {
    emitFailure({ json, code: 'SDK_VERSION_ERROR', message: `Installed SDK version ${SDK_VERSION} does not match required version ${REQUIRED_SDK_VERSION}. Install with: npm install fieldkit-sdk@${REQUIRED_SDK_VERSION}`, outputDir });
    return;
  }

  if (!json) {
    console.log(`\x1b[36mUnityClaw Image (Premium 2) v${SKILL_VERSION}\x1b[0m\n`);
    console.log(`\x1b[32m✓ SDK version ${SDK_VERSION} (required: ${REQUIRED_SDK_VERSION})\x1b[0m`);
    console.log('\x1b[36mParameters:\x1b[0m');
    console.log(`  Prompt: ${prompt}`);
    console.log(`  Size: ${values.size}`);
    if (aspectRatio) console.log(`  Aspect Ratio: ${aspectRatio}`);
    if (attachments.length) console.log(`  Attachments: ${attachments.length}`);
    console.log(`  Output Directory: ${outputDir}`);
    console.log(`  Timeout: ${timeout}ms`);
    console.log(`  Retries: ${retries}\n`);
  }

  // OAuth-first SDK client: a missing Key is reported, never authorized here.
  let client;
  try {
    client = new UnityClawClient({ taskDir: outputDir, timeout, source: "morning-wechat-official-account-course-enrollment-illustrated-post" });
  } catch (error) {
    if (error?.code === 'AUTH_REQUIRED') {
      emitFailure({ json, code: 'AUTH_REQUIRED', message: 'Authorization required. Ask the user for consent before running node scripts/authorize.js --authorize.', outputDir });
      process.exitCode = 2;
      return;
    }
    throw error;
  }
  const requestParams = {
    prompt,
    size: { value: values.size, label: values.size },
  };
  if (aspectRatio) requestParams.aspect_ratio = { value: aspectRatio, label: aspectRatio };
  if (attachments.length) requestParams.attachment = attachments;

  let lastResult;
  let lastError;
  const maximumAttempts = retries + 1;

  for (let attempt = 1; attempt <= maximumAttempts; attempt += 1) {
    if (!json) console.log(`\x1b[33mGenerating image (attempt ${attempt}/${maximumAttempts})...\x1b[0m`);
    try {
      const result = await client.image.aiImage2(requestParams);
      lastResult = result;

      if (result.success && Array.isArray(result.response?.data) && result.response.data.length > 0) {
        let files;
        try {
          files = validateDownloadedFiles(result.response.data);
        } catch (error) {
          emitFailure({
            json,
            code: 'OUTPUT_VALIDATION_ERROR',
            message: error.message,
            attempts: attempt,
            outputDir,
            result,
          });
          return;
        }
        const payload = {
          success: true,
          attempts: attempt,
          taskId: result.taskId,
          taskFolder: result.taskFolder,
          duration: result.duration,
          outputDir,
          files,
        };

        if (json) {
          console.log(JSON.stringify(payload));
        } else {
          console.log(`\n\x1b[36mTask ID: ${result.taskId}\x1b[0m`);
          console.log(`\x1b[36mTask Folder: ${result.taskFolder}\x1b[0m`);
          console.log(`\x1b[36mDuration: ${result.duration}ms\x1b[0m`);
          console.log(`\n\x1b[32m✓ Generated ${files.length} image(s):\x1b[0m`);
          files.forEach((file, index) => {
            console.log(`\n  Image ${index + 1}:`);
            console.log(`    Name: ${file.name}`);
            console.log(`    Type: ${file.contentType}`);
            console.log(`    Size: ${file.bytes} bytes`);
            console.log(`    \x1b[32mLocal Path: ${file.localPath}\x1b[0m`);
            if (file.temporaryUrl) console.log(`    \x1b[90mURL (temporary): ${file.temporaryUrl}\x1b[0m`);
          });
        }
        return;
      }

      lastError = new Error(getFailureMessage(result));
      lastError.details = result;
    } catch (error) {
      lastError = error;
    }

    const retryable = isRetryable(lastError) || isRetryable(lastResult);
    if (!retryable || attempt === maximumAttempts) {
      emitFailure({
        json,
        code: retryable ? 'TRANSIENT_ERROR' : 'GENERATION_ERROR',
        message: lastError?.message || 'Image generation failed',
        retryable,
        attempts: attempt,
        outputDir,
        result: lastResult,
      });
      return;
    }

    const delay = 1000 * attempt;
    if (!json) console.warn(`\x1b[33mTransient failure; retrying in ${delay}ms...\x1b[0m`);
    await sleep(delay);
  }
}

const isDirectExecution = process.argv[1]
  && resolve(process.argv[1]) === fileURLToPath(import.meta.url);

if (isDirectExecution) {
  main().catch((error) => {
    emitFailure({
      json: process.argv.includes('--json'),
      code: 'UNEXPECTED_ERROR',
      message: error.message,
      retryable: isRetryable(error),
    });
  });
}

export { validateDownloadedFiles };
