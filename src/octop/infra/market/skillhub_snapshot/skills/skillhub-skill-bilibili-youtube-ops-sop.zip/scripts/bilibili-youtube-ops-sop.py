#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""B站/YouTube运营SOP · 结构化方案生成器（纯标准库、离线、只读）。

用法：
    python3 bilibili-youtube-ops-sop.py "用户的简要需求"
    python3 bilibili-youtube-ops-sop.py --json "用户的简要需求"

只输出结构化方案与口径，不替代专业结论；数值类按标注口径由用户代入。
"""

import argparse
import json
import sys

DATA = json.loads(r'''{"name": "bilibili-youtube-ops-sop", "disp_zh": "B\u7ad9/YouTube\u8fd0\u8425SOP", "disp_en": "Bilibili Youtube Ops SOP", "track": "\u5185\u5bb9\u8fd0\u8425", "abilities": ["\u6d3b\u52a8\u7b56\u5212\u9aa8\u67b6\uff1a\u6309\u76ee\u6807\u62c6\u89e3\u73a9\u6cd5\u3001\u8282\u594f\u3001\u9884\u7b97\u3001\u590d\u76d8\u56db\u6bb5\uff0c\u7ed9\u65f6\u95f4\u7ebf\u4e0e\u8d23\u4efb\u5206\u5de5\u6a21\u677f", "\u7528\u6237\u5206\u5c42\u4e0e\u53ec\u56de\uff1a\u7528 RFM \u505a\u4ef7\u503c\u5206\u5c42\uff0c\u6309\u5c42\u7ed9\u53ec\u56de\u8bdd\u672f\u3001\u89e6\u8fbe\u8282\u594f\u4e0e\u4fc3\u6d3b\u52a8\u4f5c", "\u5e73\u53f0\u8fd0\u8425 SOP\uff1a\u4e2d\u957f\u89c6\u9891\u5e73\u53f0\u7684\u9009\u9898\u3001\u66f4\u65b0\u9891\u7387\u3001\u53d8\u73b0\u8def\u5f84\u4e0e\u6570\u636e\u590d\u76d8\u95ed\u73af", "\u4ea4\u4ed8\u7269\u6a21\u677f\uff1a\u6d3b\u52a8 briefing\u3001\u5206\u5c42\u770b\u677f\u3001\u8fd0\u8425\u5468\u62a5\u7684\u7ed3\u6784\u5316\u9aa8\u67b6"], "rules": ["\u5148\u5b9a\u76ee\u6807\u518d\u7ed9\u65b9\u6848\uff1a\u62c9\u65b0\u3001\u4fc3\u6d3b\u3001\u8f6c\u5316\u3001\u53d8\u73b0\u56db\u79cd\u76ee\u6807\u5bf9\u5e94\u4e0d\u540c\u73a9\u6cd5\u5e93", "\u5206\u5c42\u5fc5\u987b\u53ef\u64cd\u4f5c\uff1a\u6bcf\u4e00\u5c42\u90fd\u8981\u843d\u5230\u5177\u4f53\u52a8\u4f5c\u4e0e\u89e6\u8fbe\u9891\u6b21\uff0c\u4e0d\u5806\u6982\u5ff5", "\u9884\u7b97\u5355\u5217\uff1a\u4eba\u529b\u3001\u6295\u653e\u3001\u7269\u6599\u5206\u5f00\u4f30\u7b97\uff0c\u7ed9\u6d6e\u52a8\u533a\u95f4\u800c\u975e\u5355\u70b9\u503c", "\u590d\u76d8\u6709\u53e3\u5f84\uff1a\u6d3b\u52a8\u524d\u540e\u5b9a\u4e49\u540c\u4e00\u6279\u6307\u6807\uff0c\u907f\u514d\u7528\u4e0d\u540c\u53e3\u5f84\u5047\u88c5\u6709\u6548"], "boundary": "\u4e0d\u505a\u6295\u653e\u51fa\u4ef7\u4e0e\u7ade\u4ef7\u7b56\u7565\uff0c\u4e0d\u627f\u8bfa\u6da8\u7c89\u6216\u8f6c\u5316\u6570\u5b57\uff0c\u4e0d\u66ff\u4ee3\u5e73\u53f0\u5b98\u65b9\u8fd0\u8425\u89c4\u5219\uff1b\u76f8\u5173\u7ed3\u8bba\u4ee5\u5e73\u53f0\u73b0\u884c\u89c4\u8303\u4e3a\u51c6\u3002", "samples": ["\u4e2d\u957f\u89c6\u9891\u5e73\u53f0\u9009\u9898/\u66f4\u65b0/\u53d8\u73b0SOP", "\u573a\u666f\uff1a\u8981\u529e\u4e00\u573a\u6d3b\u52a8\u3001\u8981\u76d8\u7528\u6237\u505a\u53ec\u56de\u3001\u8981\u8d77\u53f7\u505a\u4e2d\u957f\u89c6\u9891\u8fd0\u8425\uff0c\u8bf7\u51fa\u4e00\u4efdB\u7ad9/YouTube\u8fd0\u8425SOP\u7684\u4ea4\u4ed8\u7269"], "calc_note": ""}''')


def build_plan(topic):
    d = DATA
    return {
        "topic": (topic or "").strip(),
        "skill": d["name"],
        "display_name": d["disp_zh"],
        "track": d["track"],
        "abilities": list(d["abilities"]),
        "rules": list(d["rules"]),
        "boundary": d["boundary"],
        "samples": list(d["samples"]),
        "calc_note": d.get("calc_note", ""),
    }


def render(plan):
    lines = []
    lines.append("需求：" + (plan["topic"] or "（未提供描述）"))
    lines.append("技能：" + plan["display_name"] + "（" + plan["skill"] + "）")
    lines.append("赛道：" + plan["track"])
    lines.append("")
    lines.append("执行要点：")
    for i, a in enumerate(plan["abilities"], 1):
        lines.append("  {}. {}".format(i, a))
    lines.append("铁律：")
    for i, r in enumerate(plan["rules"], 1):
        lines.append("  {}. {}".format(i, r))
    if plan["calc_note"]:
        lines.append("")
        lines.append("口径与公式：")
        for line in plan["calc_note"].split("\n"):
            lines.append("  " + line)
    lines.append("")
    lines.append("边界：" + plan["boundary"])
    lines.append("")
    lines.append("下一步：结合上述要点与你的具体参数填装交付物；数值类按标注口径代入，最终以官方或专业结论为准。")
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description=DATA["disp_zh"] + " 结构化方案生成器（离线）")
    ap.add_argument("topic", nargs="*", default=[], help="用户需求描述")
    ap.add_argument("--topic", dest="topic_opt", default=None, help="显式需求")
    ap.add_argument("--json", action="store_true", help="JSON 输出")
    ns = ap.parse_args(argv)
    topic = ns.topic_opt or " ".join(ns.topic)
    if not topic.strip():
        ap.error("请提供需求描述，例如：python3 bilibili-youtube-ops-sop.py \"你的需求\"")
    plan = build_plan(topic)
    if ns.json:
        print(json.dumps(plan, ensure_ascii=False, indent=2))
    else:
        print(render(plan))
    return 0


if __name__ == "__main__":
    sys.exit(main())
