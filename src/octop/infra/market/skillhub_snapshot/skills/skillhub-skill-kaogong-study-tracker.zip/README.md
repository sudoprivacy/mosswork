# 朱批录 · 考公备考追踪 Skill

```text
╭────────────────────────────────────────────────────╮
│                      朱 批 录                      │
│     K A O G O N G   S T U D Y   T R A C K E R      │
│                                                    │
│             一句话记进度，一张图存错题             │
│          记录  →  归档  →  复习  →  进步           │
╰────────────────────────────────────────────────────╯
```

通用 Agent 技能。把每天的套题截图或成绩发给你的 AI Agent，归档错题、分析弱项、安排复习；记录数据保存在自己的电脑上。

Node.js ≥ 18 · MIT 许可 · 文字记录 / 截图归档 / Excel 导出

## 本安装包

本包仅包含 UTF-8 文本文件：Skill 说明、运行脚本、配置示例和测试。不包含图片、Git 文件或宣传素材，README 横幅也由文字字符构成。截图识别和 Excel 导出功能仍然保留，所需图片由用户在使用时提供。

---

## 为什么做这个

备考行测、申论，每天刷套题是标准动作。但大多数人的复习路径是这样的：

> 做完一套卷子 → 对答案 → 叹口气 → 翻篇 → 明天继续

真正提分的部分——错题归类、原因分析、二刷追踪——因为太麻烦，往往被跳过。

朱批录想解决的就是这件事：**让"做完题之后的整理"变得几乎不需要努力**。你只需要把错题截图发出来，或者发一句"今天判断推理错了8道"，剩下的它来做。

---

## 它能做什么

### 错题自动识别与归档

发一张错题截图，朱批录调用你配置的多模态模型（qwen3-vl、kimi-k2.5、claude-sonnet-4-6 等），自动提取：

- 题目完整内容（包括图形推理的视觉描述、统计图的数据）
- 所属科目和题型
- 正确答案（如图片中可见）
- 错误原因推测（知识点不会 / 粗心 / 时间不够 / 概念混淆）
- 知识点标签

识别失败时，提示你把文字复制粘贴发过来，一样可以整理。

### 每日打卡与进度追踪

直接用自然语言汇报：

```
今天行测做完了，言语4错，判断8错，数量5错，资料3错
```

朱批录记录进度，统计各模块7日准确率，找出弱项。

### 晚间自动总结

每天21:00主动发一条消息，汇总当天成绩、指出最弱模块、给一条具体的明天建议。不需要你主动问。

### 导出 Excel 错题本

说"导出错题本"，生成一份包含两个 Sheet 的 `.xlsx` 文件：

- **错题本**：题目内容、图形视觉描述、错误原因、知识点标签、二刷状态，截图原图嵌入对应行
- **每日记录**：各科目错题数流水账

这份文件可以直接发给 Kimi、ChatGPT 或其他模型，让它帮你分析近期趋势、给出复习建议。

### 同步到飞书云文档（可选）

说"同步到飞书"，把还没同步过的错题（含截图原图）追加到飞书云文档，手机上直接查看，对图形推理题尤其有用。已同步的题不会重复写入。

配置步骤（大多数"同步失败"都是漏了第 3 或第 5 步）：

1. 在 [飞书开放平台](https://open.feishu.cn) 创建企业自建应用，记下 App ID 和 App Secret
2. 「权限管理」里开通 `docx:document` 和 `docs:document.media:upload`（或 `drive:drive`）；如果文档放在知识库里，再开通 `wiki:wiki:readonly`
3. 「版本管理与发布」→ 创建版本并发布，权限才会生效
4. 新建一篇飞书文档，把链接（`/docx/...` 或 `/wiki/...`）填到 `config.json` 的 `feishu_doc.doc_url`
5. 打开这篇文档 → 右上角「…」→「添加文档应用」，把你的应用加进来并给"可编辑"
6. 运行 `node scripts/feishu_doc.js --check`，看到"配置检查通过"就可以了

国际版 Lark 用户在配置里加 `"domain": "lark"`。旧版文档（链接是 `/docs/`）飞书 API 已不支持写入，需要新建新版文档。

---

## 设计原则

**对话即操作**——一切通过聊天完成，不需要打开任何 App、不需要编辑配置文件。

**本地优先**——错题数据（包括截图）默认存在你自己电脑的 `~/.kaogong-study-tracker/` 里。截图识别时图片会发给你的 agent 所使用的模型；同步飞书只在你主动要求时进行。

**失败软降级**——图片识别失败时给出明确提示，引导手动输入，不中断流程。

**不啰嗦**——每条回复控制在150字以内，只说最关键的一件事。

---

## 支持的考试类型

朱批录的科目映射默认覆盖国考/省考标准科目，也适用于：

| 考试类型 | 适配情况 |
|---------|---------|
| 国家公务员考试（国考） | 完整支持，行测5模块 + 申论 |
| 省级公务员考试（省考） | 支持，部分省份题型有差异可调整科目映射 |
| 事业单位联考（职测） | 支持，科目名称略有不同 |
| 军队文职考试 | 基本支持，部分模块名需手动映射 |
| 选调生考试 | 支持 |

---

## 支持的 Agent / 渠道

朱批录不是绑定某个平台的 App。只要你的 agent 能读 `SKILL.md`、执行命令（`node scripts/cli.js …`），就可以接入；能看图的 agent 还可以直接识别错题截图。

| 使用环境 | 说明 |
|---------|------|
| Claude Code / Codex / Cursor / Trae / opencode 等本地 agent | 按 `SKILL.md` 调用 `scripts/cli.js`，数据放本地 |
| OpenClaw | 仍可使用，`assets/workspace-example.yaml` 保留兼容示例 |
| 飞书 / Telegram / Discord / iMessage 等聊天渠道 | 由宿主 agent 接入渠道，朱批录只负责解析、归档、导出、提醒 |

---

## 快速安装

### 前置条件

- Node.js ≥ 18
- Python 3 + `openpyxl` + `Pillow`（用于导出 Excel；没有 Pillow 也能导出，但截图不会嵌入）
- 一个能调用多模态模型的 agent（截图识别需要；纯文字记录不需要）

### 安装步骤

1. 在 Skill 网站上传本 ZIP 包；如果网站要求选择文件，先解压，再上传 `kaogong-study-tracker` 文件夹中的文件，保留子目录结构。
2. 本地使用时，将解压后的 `kaogong-study-tracker` 文件夹放到 Agent 的 skills / tools 目录，或任意可访问目录。
3. 让 Agent 读取文件夹中的 `SKILL.md`。所有示例命令都在该文件夹内运行。

基础文字记录无需安装额外的 Node.js 依赖。需要导出 Excel 时安装 Python 依赖：

```bash
cd kaogong-study-tracker
python3 -m pip install openpyxl pillow     # Windows 用 py -m pip install openpyxl pillow

# 可选：存图前自动压缩截图
npm install sharp
```

运行环境需要支持执行 Node.js 命令和读写本地文件；截图识别还需要 Agent 具有看图能力。

如果你的 agent 支持定时任务，可以配置：

```bash
node scripts/cli.js summary    # 每天 21:00，晚间总结（输出 JSON，message 字段是文案）
node scripts/cli.js review     # 每隔一天 20:00，二刷抽题
```

导出时找不到 Python，可以设置 `KAOGONG_PYTHON` 指向 Python 可执行文件；日期默认按本机时区，服务器在海外时可以设置 `KAOGONG_TZ=Asia/Shanghai`。

OpenClaw 用户可以参考 [`assets/workspace-example.yaml`](assets/workspace-example.yaml)。

### 首次使用

安装后把 `SKILL.md` 交给你的 agent 读取。agent 会通过 `scripts/cli.js` 读写数据，你只需要正常聊天。也可以自己在终端试一下：

```bash
node scripts/cli.js log "今天判断推理错了8道"
node scripts/cli.js stats
```

图片识别由 agent 自己完成（要求见 `references/vision_prompt.md`）；agent 不能看图的话，把题目文字复制过来一样能整理。

---

## 数据结构

所有数据存储在本地：

```
~/.kaogong-study-tracker/data/
├── daily/
│   ├── 2026-03-15.json      ← 每天的套题成绩
│   ├── 2026-03-16.json
│   └── ...
├── wrong_questions.json     ← 所有错题（累积）
├── stats_cache.json         ← 7日模块准确率、连续打卡天数
└── exports/
    └── 备考记录_2026-03-17.xlsx
```

可以用环境变量改数据目录：

```bash
export KAOGONG_DATA_DIR="/path/to/your/kaogong-data"
```

飞书同步等可选配置默认读取项目根目录下的 `config.json`；也可以用 `KAOGONG_CONFIG_PATH` 指定。

错题记录的完整字段：

```json
{
  "id": "uuid",
  "date": "2026-03-17",
  "source": "image",
  "module": "判断推理",
  "subtype": "图形推理",
  "question_text": "3×3九宫格，箭头叠加规律……",
  "visual_description": "每行第3个图形等于第1、2个图形的箭头叠加，重复箭头消去……",
  "answer": "A",
  "user_annotation": "没看出规律",
  "error_reason": "知识点不会",
  "keywords": ["图形推理", "九宫格", "叠加规律"],
  "raw_image_b64": "...",
  "status": "待二刷"
}
```

---

## 文件结构

```
kaogong-study-tracker/
├── AGENTS.md                     ← 通用 agent 使用说明（Trae/Cursor/opencode/Hermes 等）
├── SKILL.md                       ← Agent 读取的主文件（含完整流程文档）
├── package.json
├── scripts/
│   ├── cli.js                     ← 命令行入口，agent 的所有读写都走这里
│   ├── onboarding.js              ← 首次欢迎语（JS 宿主用；命令行用 cli.js welcome）
│   ├── parse_input.js             ← 消息解析（文字成绩、快捷格式、导出指令）
│   ├── update_daily.js            ← 写入每日记录和统计缓存
│   ├── export_xlsx.js             ← 导出 Excel（筛选、截图嵌入）
│   ├── xlsx_writer.py             ← 实际写 xlsx 的 Python 脚本（openpyxl）
│   ├── feishu_doc.js              ← 同步到飞书云文档（可选）
│   ├── review_reminder.js         ← 二刷抽题 + 处理"记得/不记得"
│   ├── daily_summary.js           ← 定时晚间总结推送
│   ├── paths.js / util.js         ← 路径、本地日期、安全读写
├── test/smoke.js                  ← npm test 冒烟测试
├── references/
│   ├── vision_prompt.md           ← 截图识别要求和输出字段
│   ├── reply_templates.md         ← 5种回复模板（正常/情绪低/弱点分析等）
│   └── tone_guide.md              ← 语气规范：像朋友，不像 AI 助手
└── assets/
    ├── module_map.json            ← 科目别名映射（"逻辑"→"判断推理" 等）
    ├── config.example.json        ← 飞书云文档配置模板
    └── workspace-example.yaml    ← 飞书/Telegram 接入配置示例
```

---

## License

MIT © 2026
