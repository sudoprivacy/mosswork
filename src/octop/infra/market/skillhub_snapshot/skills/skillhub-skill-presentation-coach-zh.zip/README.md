# 演讲教练(中文场景)

中文演讲场景的全流程教练——开场 30 秒、主体节奏、Q&A 应答(含送命题)、控场技巧、PPT 与口播配合。覆盖技术分享、述职、路演、培训四种场景。

## 这是什么

`presentation-coach-zh` 是一个针对**中国本地场景**原创设计的 OpenClaw / SkillHub Agent Skill。
从问题定义、框架设计、示例都是为中国用户从零写的，不是任何已有项目的翻译或 fork。

## 触发场景

详见 `SKILL.md` 的 description 字段，AI 会自动判断何时调用。常见关键词：

- `演讲技巧`
- `Q&A 应答`
- `技术分享`
- `述职演讲`
- `路演`
- `控场`
- `脱稿`
- `送命题`

## 安装

### SkillHub（推荐）

通过 SkillHub Web 界面安装：https://skillhub.cloud.tencent.com/skills/presentation-coach-zh

### OpenClaw / Claude Code

```bash
mkdir -p ~/.claude/skills
cp -R presentation-coach-zh ~/.claude/skills/presentation-coach-zh
```

### Cursor

把整个文件夹放到项目的 `.cursor/skills/presentation-coach-zh/` 下，重启 Cursor 即可。

## 用法

直接用自然语言描述需求，AI 会自动加载本 skill。例如：

```
帮我用 演讲教练(中文场景) 来 ...
```

## License

MIT © 2026 ikun

## 反馈

- 觉得有用：在 SkillHub 给个 star
- 报 bug / 建议：SkillHub 评论区留言
