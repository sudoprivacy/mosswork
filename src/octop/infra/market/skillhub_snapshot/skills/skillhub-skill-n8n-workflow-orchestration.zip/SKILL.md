---
name: skillhub-skill-n8n-workflow-orchestration
description: "n8n 工作流编排"
---

# n8n 工作流编排

## 适用场景
> n8n 工作流编排

## 功能说明
> 把外部 API 调用统一交给 n8n Webhook，AI 自动化平台不直接持有业务密钥。

## 这个 Skill 能帮你做什么
- 凭证集中在 n8n Credential Store，减少 `.env` 泄露风险。
- 流程可视化，可在 n8n UI 里直接审查和调试每一步。
- 稳定子任务走工作流，减少不必要的 LLM 推理开销。

## 需要的工具/依赖
| 类型 | 工具/能力 | 用途 | 说明 |
|---|---|---|---|
| 内置 | `fetch` 或 `curl` | 调用 n8n Webhook | 内置能力 / 系统命令 |
| 外部（需安装） | `n8n` | 承载外部系统集成与凭证管理 | [n8n](https://n8n.io/) |
| 外部（可选） | Docker / Docker Compose | 一键拉起 AI 自动化平台+n8n 栈 | Docker |

## 快速体验版（先跑一轮）
```text
你是我的 AI 自动化助手。
请先帮我做“n8n 工作流编排”的一次预演：
1. 说明本工作流需要读取哪些信息入口。
2. 列出本轮会产出的结果。
3. 标记需要人工确认的动作。
4. 本轮只输出方案和检查清单，不执行高风险操作。
```

## 稳定自动版（可长期运行）
### 1) 预置栈（可选）

```bash
git clone https://github.com/caprihan/ai-workflow-n8n-stack.git
cd ai-workflow-n8n-stack
cp .env.template .env
docker-compose up -d
```

### 2) 手动模式下的集成规则（放入 `AGENTS.md`）

```text
## n8n Integration Pattern

When I need to interact with external APIs:

1. NEVER store API keys in my environment or skill files
2. Check if an n8n workflow already exists for this integration
3. If not, create one via n8n API with a webhook trigger
4. Notify the user to add credentials and lock the workflow
5. For all future calls, use the webhook URL with a JSON payload

Workflow naming: ai-workflow-{service}-{action}
Example: ai-workflow-slack-send-message

Webhook call format:
curl -X POST http://n8n:5678/webhook/{workflow-name} \
  -H "Content-Type: application/json" \
  -d '{"channel": "#general", "message": "Hello from AI 自动化平台"}'
```

### 3) 运行规则

- 流程固定后执行“build → test → lock”。
- 变更 API 逻辑时先改 n8n workflow，再由 AI 自动化平台调 webhook。
- 只把 webhook URL 暴露给代理，不传递真实密钥。

## 落地配置建议

- 先把“n8n 工作流编排”拆成一次性试跑和长期自动化两种模式。
- 先在测试环境验证命令和配置，再应用到正式环境。
- 建议保留运行日志、输入样例和最终输出，方便后续复盘和交付验收。

## 验收口径

- 能用真实或模拟数据完整跑通一次。
- 输出结果结构清晰，包含下一步动作或明确结论。
- 部署、回滚、日志和健康检查路径必须跑通。

## 注意事项

- 正式接入账号、数据源或自动操作前，先确认权限边界。
- 涉及生产环境的改动必须先备份并保留回滚方案。
- 高风险动作建议默认只生成建议或草稿，不直接执行。

## 质量等级

- 难度：高级
- 风险：高
- 自动化程度：半自动
- 适用对象：企业

## 成功标准
- AI 自动化平台侧不再持有第三方 API Key。
- 每个外部调用都有对应 n8n workflow 可视化记录。
- 关键 workflow 可锁定，避免被意外改写。
