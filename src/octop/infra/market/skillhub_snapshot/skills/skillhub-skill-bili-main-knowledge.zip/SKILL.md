---
name: skillhub-skill-bili-main-knowledge
description: "当用户想按 B 站「知识」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：知识、B站分区、rid 36。"
---

# B 站分区 · 知识

- 一级分区 rid：`36`；网页路由：`/v/knowledge/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 94 条榜单条目，覆盖 7 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 人文历史 | 34 | 9 | 228 |
| 校园学习 | 6 | 10 | 208 |
| 社科·法律·心理 | 17 | 10 | 124 |
| 科学科普 | 23 | 9 | 201 |
| 设计·创意 | 2 | 4 | 229 |
| 财经商业 | 8 | 9 | 207 |
| 野生技能协会 | 4 | 7 | — |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 人文历史

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 网友评论填补了死亡摇滚的空白 | 石匠旭哥 | [BV136R9YmEXD](https://www.bilibili.com/video/BV136R9YmEXD) | 460.0 万 |
| 又燃又疯！平克顿侦探社vs莫里亚蒂原型，逆转到最后一刻！ | 迷因水母 | [BV1iJZmYmEfK](https://www.bilibili.com/video/BV1iJZmYmEfK) | 270.7 万 |
| “甲亢哥”魔幻重庆奇遇记 | 人民日报 | [BV1AxZ2YREYk](https://www.bilibili.com/video/BV1AxZ2YREYk) | 181.9 万 |
| 1个半小时能产生多少个天命人？ | 糟糕的历史-听文知 | [BV1waZUYbEKc](https://www.bilibili.com/video/BV1waZUYbEKc) | 164.0 万 |
| 2亿人口非洲第一GDP超级民主大国，穷到全民摆烂【西非13丨尼日利亚】 | 小王Albert | [BV1stZUYwER9](https://www.bilibili.com/video/BV1stZUYwER9) | 230.1 万 |

### 校园学习

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 把老师的废话剪掉，老师也太好了吧！！ | 九零老师 | [BV189ZZYNEiE](https://www.bilibili.com/video/BV189ZZYNEiE) | 358.2 万 |
| 2025高考 最后十课发布会！ | 一数 | [BV1fuRoYvEYN](https://www.bilibili.com/video/BV1fuRoYvEYN) | 375.1 万 |
| 【高考化学】一轮总复习+二轮总复习\|长期更新\|拯救你的高中化学！ | 一化儿 | [BV1aComYMEms](https://www.bilibili.com/video/BV1aComYMEms) | 2127.6 万 |
| 托里拆利实验-测量大气压 | 瑾轩的物理小零食 | [BV1XzZQYnEWv](https://www.bilibili.com/video/BV1XzZQYnEWv) | 144.3 万 |
| 学会泰勒展开，数学直接开挂！！ 赵礼显-高考数学 | 赵礼显老师 | [BV141oXYGEqf](https://www.bilibili.com/video/BV141oXYGEqf) | 754.9 万 |

### 社科·法律·心理

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| “他们用推土机在救护人员的身上，碾了又碾” | 波士顿圆脸 | [BV1JmRoYzEjx](https://www.bilibili.com/video/BV1JmRoYzEjx) | 440.9 万 |
| 强硬反制！对原产于美国的所有进口商品再加征50%关税 | 央视新闻 | [BV1pEdNYaExa](https://www.bilibili.com/video/BV1pEdNYaExa) | 449.8 万 |
| 当精英开始逃离美国，特朗普的战争注定失败 | 麻薯波比呀 | [BV1vFdpYqEDE](https://www.bilibili.com/video/BV1vFdpYqEDE) | 351.6 万 |
| 1秒就睡着 | 俏佳人xxx | [BV1ZHZmYjEac](https://www.bilibili.com/video/BV1ZHZmYjEac) | 242.2 万 |
| 企鹅版“回答我”：怒了！最强“反制行动”开启 | 央视网 | [BV1yXdxYZEAN](https://www.bilibili.com/video/BV1yXdxYZEAN) | 214.0 万 |

### 科学科普

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 核辐射：染色体碎裂，全身融化，核事故到底有多恐怖？如何科学应对？ | 医学科普联盟 | [BV1zwRRYaESp](https://www.bilibili.com/video/BV1zwRRYaESp) | 460.4 万 |
| 【狗子剧医】深度解析硝子失聪医学真相，比电影更揪心！ | 狗子王Dogtor_Wang | [BV1RCZdYPEji](https://www.bilibili.com/video/BV1RCZdYPEji) | 237.3 万 |
| 小孩发热咳嗽，自行买药服用后死亡！法医尸检探真相 | 法医鉴定平台 | [BV1FSZRY3EZU](https://www.bilibili.com/video/BV1FSZRY3EZU) | 277.8 万 |
| 鉴定咬伤粉丝的毒蛇(19)网友假装被毒蛇咬伤找龙雅求助！突然删除好友说已经坏死了？ | 世界记忆大师龙雅 | [BV1nXdcYQEwm](https://www.bilibili.com/video/BV1nXdcYQEwm) | 202.3 万 |
| 冰块为什么能清理煎锅？ #科普 #解压 #涨知识 #物理 | 好奇万花筒 | [BV1wGdWYEE48](https://www.bilibili.com/video/BV1wGdWYEE48) | 1250.9 万 |

### 设计·创意

数据来源：二级分区 7 日榜，可用 4 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 这张照片为什么让人感到不安？“晚上出门时遇到的奇怪双子....”【阿怪的粉丝投稿分享69】 | 史蒂芬怪 | [BV1CqR1Y2ERj](https://www.bilibili.com/video/BV1CqR1Y2ERj) | 52.0 万 |
| 只用蒙版做出植物穿插海报 | Neo小海 | [BV1rkR1YVE1N](https://www.bilibili.com/video/BV1rkR1YVE1N) | 29.6 万 |
| 出片神器！我拥有了一整个春天！ | Madein發財 | [BV1ZvZ2YmExB](https://www.bilibili.com/video/BV1ZvZ2YmExB) | 6.8 万 |
| 扎到了谁的心巴上 | 大壮是个摄影师 | [BV1DpZ8YQEtP](https://www.bilibili.com/video/BV1DpZ8YQEtP) | 34.3 万 |

### 财经商业

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 世界级的经济动荡，就在眼前 | 汤山老王 | [BV1tgRyYjE3F](https://www.bilibili.com/video/BV1tgRyYjE3F) | 107.2 万 |
| 美股连续暴跌，国际油价大跌，黄金下跌，流动性危机风险，特朗普对等关税，搞乱全球金融市场 | 星话大白 | [BV1xpdwYwE2W](https://www.bilibili.com/video/BV1xpdwYwE2W) | 107.8 万 |
| 再这么丢人，秦始皇都要被气复活 | 珍大户 | [BV143RyY1END](https://www.bilibili.com/video/BV143RyY1END) | 69.4 万 |
| 【36氪】从年赚百万到清仓求生，一件衣服背后的工厂寒冬 | 36氪 | [BV1UhR1YDEgX](https://www.bilibili.com/video/BV1UhR1YDEgX) | 69.1 万 |
| 杀个人就像点外卖一样简单？暗网究竟是如何操控的？ | 大瑞真机灵 | [BV1EcZUYSEsK](https://www.bilibili.com/video/BV1EcZUYSEsK) | 593.7 万 |

### 野生技能协会

数据来源：二级分区 7 日榜，可用 7 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 睡前练练脑，听说这样打乱比较有说服力 | 魔方达人夏天 | [BV1MPZSYqE4L](https://www.bilibili.com/video/BV1MPZSYqE4L) | 918.0 万 |
| 【刘谦魔术课】他挥一挥衣袖，不带走一片云彩～却留下了许多魔术 | 刘谦 | [BV1hQZZYiEhJ](https://www.bilibili.com/video/BV1hQZZYiEhJ) | 49.5 万 |
| 搞懂流量底层逻辑，普通人照样拍出爆款视频 | Jackie兄 | [BV1U6RSYcELN](https://www.bilibili.com/video/BV1U6RSYcELN) | 146.2 万 |
| 手腕割伤大出血急救指南 | 犀牛救援RhinoRescue | [BV1bvZ1YfE55](https://www.bilibili.com/video/BV1bvZ1YfE55) | 141.5 万 |
| 二十年后，在看这照片，原来我以前还挺瘦！！！ | 左岸P图 | [BV139ZUY5Eaq](https://www.bilibili.com/video/BV139ZUY5Eaq) | 46.0 万 |

## 名称差异与覆盖说明

- 接口出现但分区表未列或名称不同：野生技能协会。
- 分区表列出但本次榜单未返回条目：职业职场, 野生技术协会（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=36." https://api.bilibili.com/x/web-interface/ranking/v2?rid=36&type=all. Accessed 6 Nov. 2026.
