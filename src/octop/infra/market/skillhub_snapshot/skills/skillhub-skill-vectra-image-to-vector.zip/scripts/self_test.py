#!/usr/bin/env python3
"""Exercise the real CLI with mocked HTTP responses and no network access."""

import base64
import contextlib
import io
import json
import tempfile
import unittest
from email.message import Message
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError

import vectorize


TEST_KEY = "vk_live_" + "x" * 43
TASK_ID = "6dd39862-bec8-44e4-b72e-50a40618ba6e"
SVG = b'<svg xmlns="http://www.w3.org/2000/svg">\r\n  <!-- keep bytes -->\r\n  <path d="M 0 0 L 1 1" />\r\n</svg>\r\n'
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aVxkAAAAASUVORK5CYII=")


class Response(io.BytesIO):
    def __init__(self, content, content_type):
        super().__init__(content)
        self.headers = Message()
        self.headers["Content-Type"] = content_type


class MockApi:
    def __init__(self):
        self.posts = []
        self.calls = []

    def open(self, request, timeout):
        assert 0 < timeout <= 35
        assert request.get_header("Authorization") == f"Bearer {TEST_KEY}"
        url = request.full_url
        assert url.startswith(vectorize.BASE_URL + "/")
        path = url.removeprefix(vectorize.BASE_URL)
        self.calls.append((request.get_method(), path))
        if path == "/capabilities":
            return Response(b'{"acceptsTasks": true}', "application/json")
        if path == "/tasks":
            idem = request.get_header("Idempotency-key")
            content_type = request.get_header("Content-type")
            self.posts.append((idem, request.data, content_type))
            if len(self.posts) == 1:
                headers = Message()
                headers["Retry-After"] = "1"
                raise HTTPError(url, 503, "test retry", headers, io.BytesIO(b'{"error":{"code":"SERVICE_UNAVAILABLE"}}'))
        elif path == f"/tasks/{TASK_ID}/result":
            return Response(SVG, "image/svg+xml; charset=utf-8")
        elif path != f"/tasks/{TASK_ID}":
            raise AssertionError(f"Unexpected request: {path}")
        return Response(json.dumps({"taskId": TASK_ID, "status": "succeeded"}).encode(), "application/json")


class SkillSelfTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.folder = Path(temp.name)
        self.mock_api = MockApi()
        for replacement in (
            patch.dict(vectorize.os.environ, {"VECTRA_API_KEY": TEST_KEY}),
            patch.object(vectorize, "build_opener", return_value=self.mock_api),
            patch.object(vectorize.time, "sleep"),
            contextlib.redirect_stdout(io.StringIO()),
            contextlib.redirect_stderr(io.StringIO()),
        ):
            replacement.__enter__()
            self.addCleanup(replacement.__exit__, None, None, None)

    def convert(self, source):
        output = self.folder / "result.svg"
        vectorize.main(["convert", str(source), "-o", str(output)])
        self.assertEqual(output.read_bytes(), SVG)
        self.assertEqual(len(self.mock_api.posts), 2)
        self.assertEqual(self.mock_api.posts[0], self.mock_api.posts[1])
        self.assertTrue(self.mock_api.posts[0][0])
        return self.mock_api.posts[0][1:]

    def test_local_image_and_original_svg(self):
        image = self.folder / "图片.png"
        image.write_bytes(PNG)
        body, content_type = self.convert(image)
        self.assertTrue(content_type.startswith("multipart/form-data; boundary="))
        self.assertIn(PNG, body)

    def test_https_image(self):
        url = "https://example.test/image.webp?token=a%2Fb"
        body, content_type = self.convert(url)
        self.assertEqual(content_type, "application/json")
        self.assertEqual(json.loads(body), {"imageUrl": url})

    def test_resume_and_protect_existing_file(self):
        output = self.folder / "result.svg"
        vectorize.main(["resume", TASK_ID, "-o", str(output)])
        self.assertEqual(output.read_bytes(), SVG)
        self.assertEqual(self.mock_api.calls, [("GET", f"/tasks/{TASK_ID}"), ("GET", f"/tasks/{TASK_ID}/result")])
        with self.assertRaisesRegex(ValueError, "尚未存在"):
            vectorize.main(["resume", TASK_ID, "-o", str(output)])
        self.assertEqual(output.read_bytes(), SVG)
        self.assertEqual(len(self.mock_api.calls), 2)

    def test_missing_key_stops_before_request(self):
        with patch.dict(vectorize.os.environ, {"VECTRA_API_KEY": ""}):
            with self.assertRaisesRegex(ValueError, r"VECTRA_API_KEY.*https://vectorizerai.cn/developer"):
                vectorize.main(["check"])
        self.assertFalse(self.mock_api.calls)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(SkillSelfTest)
    result = unittest.TextTestRunner().run(suite)
    if not result.wasSuccessful():
        raise SystemExit(1)
    print("本地模拟自检通过。未联网、未扣费；真实转换需要配置 API Key。")
