#!/usr/bin/env python3
"""Submit or resume one Vectra conversion using Python 3.9+ and its standard library."""

import argparse
import http.client
import json
import os
import re
import sys
import tempfile
import time
import uuid
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener


BASE_URL = "https://vectorizerai.cn/openapi/v1"
KEY_SETUP = "请在当前技能的执行环境配置 VECTRA_API_KEY。获取入口：https://vectorizerai.cn/developer"
MAX_IMAGE_BYTES = 10 * 1024 * 1024
PENDING = {"queued", "dispatching", "running", "reconciling", "cancel_requested"}
TERMINAL = {"succeeded", "failed", "cancelled", "expired"}
TRANSIENT = {429, 500, 502, 503, 504}


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def remaining(deadline):
    seconds = deadline - time.monotonic()
    if seconds <= 0:
        raise RuntimeError("等待超时，请用 resume 查询原任务。")
    return seconds


def wait(seconds, deadline):
    if seconds >= remaining(deadline):
        raise RuntimeError("等待超时，请用 resume 查询原任务。")
    time.sleep(seconds)


def json_object(data):
    value = json.loads(data)
    if not isinstance(value, dict):
        raise ValueError("响应不是 JSON 对象。")
    return value


class Api:
    def __init__(self, key):
        self.key = key
        self.opener = build_opener(NoRedirect())

    def request(self, path, *, body=None, content_type=None, idem=None, svg=False, deadline=float("inf")):
        headers = {"Authorization": f"Bearer {self.key}"}
        if body is not None:
            headers.update({"Content-Type": content_type, "Idempotency-Key": idem})
        request = Request(BASE_URL + path, data=body, headers=headers)
        for attempt in range(3):
            timeout = min(35, remaining(deadline))
            try:
                with self.opener.open(request, timeout=timeout) as response:
                    data = response.read()
                    if svg:
                        if response.headers.get_content_type() != "image/svg+xml" or not data:
                            raise RuntimeError("响应没有有效的 SVG 文件。")
                        return data
                    return json_object(data)
            except HTTPError as error:
                status = error.code
                try:
                    with error:
                        payload = json_object(error.read())
                except (ValueError, OSError, http.client.HTTPException):
                    payload = {}
                detail = payload.get("error")
                code = detail.get("code", "REQUEST_FAILED") if isinstance(detail, dict) else "REQUEST_FAILED"
                request_id = payload.get("requestId") or error.headers.get("X-Request-Id", "未返回")
                retry = error.headers.get("Retry-After", "")
                delay = 2 ** attempt
                if retry.isascii() and retry.isdecimal():
                    delay = int(retry) if len(retry) < 5 else float("inf")
                transient = status in TRANSIENT or (status == 409 and code == "IMAGE_FETCH_IN_PROGRESS")
                if transient and attempt < 2 and delay <= 300:
                    wait(max(delay, 1), deadline)
                    continue
                hint = ""
                if status == 401:
                    hint = "\n" + KEY_SETUP
                elif code == "SCOPE_REQUIRED":
                    hint = "\n请核对 API Key 的 tasks:write 和 tasks:read 权限。"
                raise RuntimeError(f"HTTP {status} / {code} / requestId={request_id}{hint}") from None
            except (URLError, OSError, ValueError, http.client.HTTPException):
                if attempt == 2:
                    raise RuntimeError("请求结果尚未确认。请核对网络，并用原幂等键或 taskId 恢复。") from None
                wait(2 ** attempt, deadline)


def image_body(source):
    if re.match(r"https?://", source, re.IGNORECASE):
        url = urlsplit(source)
        if url.scheme != "https" or not url.hostname or url.username is not None or url.password is not None:
            raise ValueError("请提供无需用户名和密码的公网 HTTPS 图片直链。")
        return json.dumps({"imageUrl": source}).encode("utf-8"), "application/json", "result"

    path = Path(source)
    if not path.is_file():
        raise ValueError("请选择可读取的本地图片文件或 HTTPS 图片直链。")
    with path.open("rb") as stream:
        data = stream.read(MAX_IMAGE_BYTES + 1)
    if not data or len(data) > MAX_IMAGE_BYTES:
        raise ValueError("请选择非空图片文件，最大 10 MiB。")
    boundary = "vectra-" + uuid.uuid4().hex
    prefix = (
        f"--{boundary}\r\n"
        'Content-Disposition: form-data; name="image"; filename="image"\r\n'
        "Content-Type: application/octet-stream\r\n\r\n"
    ).encode("ascii")
    return prefix + data + f"\r\n--{boundary}--\r\n".encode("ascii"), f"multipart/form-data; boundary={boundary}", path.stem


def validate_task_id(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", value):
        raise ValueError("未获得有效的任务 ID。")
    return value.lower()


def arguments(argv):
    parser = argparse.ArgumentParser(description="矢光 vectra 图片转 SVG")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("check", help="检查 API Key 和服务连接，不提交转换")
    convert = commands.add_parser("convert", help="转换一张本地图片或 HTTPS 图片直链")
    convert.add_argument("input", help="图片路径或 HTTPS 直链")
    convert.add_argument("--idempotency-key", help="提交结果不明时使用原键重试")
    resume = commands.add_parser("resume", help="继续查询原任务并下载 SVG")
    resume.add_argument("input", metavar="taskId")
    for command in (convert, resume):
        command.add_argument("-o", "--output", help="输出 SVG 路径")
        command.add_argument("--wait-seconds", type=int, default=600, help="查询等待时间，默认 600 秒")
    return parser.parse_args(argv)


def main(argv=None):
    args = arguments(argv)
    key = os.getenv("VECTRA_API_KEY", "")
    if not re.fullmatch(r"vk_live_[A-Za-z0-9_-]{43}", key):
        raise ValueError(KEY_SETUP)
    api = Api(key)
    if args.command == "check":
        capabilities = api.request("/capabilities")
        status = "可接收新任务" if capabilities.get("acceptsTasks") is True else "暂不接收新任务"
        print(f"API 连接成功，服务{status}。")
        return

    if not 1 <= args.wait_seconds <= 86400:
        raise ValueError("--wait-seconds 须为 1 到 86400 之间的整数。")
    converting = args.command == "convert"
    if converting:
        idem = args.idempotency_key
        if idem is not None and not re.fullmatch(r"[A-Za-z0-9:_-]{1,80}", idem):
            raise ValueError("无效的 --idempotency-key。")
        body, content_type, name = image_body(args.input)
    else:
        task_id = name = validate_task_id(args.input)
    output = Path(args.output or f"{name}.svg").absolute()
    if output.suffix.lower() != ".svg" or os.path.lexists(output):
        raise ValueError("请选择尚未存在、后缀为 .svg 的输出路径。")

    with tempfile.TemporaryDirectory(prefix=".vectra-", dir=output.parent) as stage:
        task = None
        if converting:
            if idem is None and api.request("/capabilities").get("acceptsTasks") is not True:
                raise RuntimeError("服务暂未接收新任务。已有任务可用 resume 查询。")
            idem = idem or str(uuid.uuid4())
            print(f"Idempotency-Key={idem}", file=sys.stderr, flush=True)
            task = api.request("/tasks", body=body, content_type=content_type, idem=idem)
            task_id = validate_task_id(task.get("taskId"))
        print(f"taskId={task_id}", file=sys.stderr, flush=True)
        path = f"/tasks/{task_id}"
        deadline = time.monotonic() + args.wait_seconds
        if task is None:
            task = api.request(path, deadline=deadline)
        while True:
            if validate_task_id(task.get("taskId")) != task_id:
                raise RuntimeError("返回的任务 ID 与请求不一致。")
            status = task.get("status")
            if not isinstance(status, str):
                raise RuntimeError("服务返回未知任务状态，请保留 taskId。")
            if status in TERMINAL:
                break
            if status not in PENDING:
                raise RuntimeError("服务返回未知任务状态，请保留 taskId。")
            wait(10 if status == "queued" else 3, deadline)
            task = api.request(path, deadline=deadline)
        if status != "succeeded":
            raise RuntimeError(f"转换未完成：{status} / {task.get('errorCode') or '无错误码'}")
        staged = Path(stage) / "result.svg"
        staged.write_bytes(api.request(path + "/result", svg=True))
        os.link(staged, output)
    print(f"SVG 已保存到 {output}")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, RuntimeError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
