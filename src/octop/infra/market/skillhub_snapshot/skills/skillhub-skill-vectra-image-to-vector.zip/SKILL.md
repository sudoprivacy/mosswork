---
name: skillhub-skill-vectra-image-to-vector
description: "使用矢光 vectra 将 PNG、JPEG（JPG）、WebP 图片或 HTTPS 图片直链转换为原始 SVG。适用于单张或多行图片逐张转换，以及凭原任务 ID 查询和领取 SVG。"
---

# 图片转矢量

转换服务由矢光 vectra 提供。可将 Logo、图标、插画和线稿转成 SVG 矢量路径，便于在不同尺寸下使用，或导入矢量编辑器继续调整。

支持本地 PNG、JPEG（`.jpg` / `.jpeg`）、WebP 静态图片及上述格式的公网 HTTPS 直链。输出为 `.svg` 文件。单张图片最多 10 MiB、2,000 万像素，服务按成功转换结算。

## 交付原始 SVG

直接交付 `scripts/vectorize.py` 保存的 `.svg` 文件。文件内容须与矢光 API 返回的原始 SVG 逐字节一致。跳过优化、压缩、格式化、重绘、重新导出等步骤，交付时禁止调用其他技能或工具改写 SVG。使用当前对话的文件附件或可打开的产物链接交付。

## 使用方法

可以对 Agent 说「把我上传的 PNG 标志转成 SVG，保存为 `logo.svg`」或「用这个任务 ID 继续查询并下载 SVG」。新任务会将用户指定的图片或直链交给矢光处理。缺少输入时，请用户提供图片、HTTPS 直链或已有任务 ID。

用 Python 3.9+ 执行包内（仅用标准库，无需安装依赖） `scripts/vectorize.py`。在有写入权限的工作区指定输出文件，并将示例中的路径或任务 ID 换为实际值。

```bash
python3 "/path/to/skill/scripts/vectorize.py" convert "./logo.png" -o "./logo.svg"
python3 "/path/to/skill/scripts/vectorize.py" resume "TASK_ID" -o "./logo.svg"
```

- 新任务使用 `convert`。已有 `taskId` 时用 `resume` 继续查询并下载原结果。
- 提交状态未知且未收到 `taskId` 时，用 `--idempotency-key` 加原幂等键及完全相同的输入重试。脚本会在提交前打印幂等键。
- 脚本确认写入成功后立即交付该张的原始 SVG。遇到失败、权限不足或结果过期时，告知实际状态并附上已有的任务 ID 或 `requestId`。

## 自检

运行 `python3 -B scripts/self_test.py` 离线检查请求构造、幂等重试和原始 SVG 落盘，无需 API Key，也不会创建真实任务。运行 `python3 scripts/vectorize.py check` 查询服务是否可接收新任务，需要配置 API Key，但不会提交图片。

## 多张图片逐张交付

1. 同一条消息有多张图片或多行文件路径、HTTPS 图片直链时，按输入顺序逐张编号并处理。每张单独运行一次 `convert`，为每张指定独立的 `.svg` 输出路径，遇到同名时加序号。
2. 每完成一张，立即在当前对话发出可见的阶段回复，附上该张的原始 SVG 文件或可打开的产物链接，再开始处理下一张。单张失败时说明状态并继续处理剩余图片。
3. 整批结束后按输入顺序汇总成功、失败或待恢复的结果。成功项引用已经交付的 SVG，失败或待恢复项附上原因和已有的任务 ID。

## 获取 API Key

首次使用请前往[矢光开发者入口](https://vectorizerai.cn/developer)登录并开通开发者，在 API 控制台的「API 密钥」中创建带 `tasks:write`、`tasks:read` 权限的 Key。将 Key 设置到脚本进程可读取的 `VECTRA_API_KEY` 环境变量。缺少凭证时，提供获取入口并提示用户在运行环境中配置。避免在对话里粘贴或回显 Key。
