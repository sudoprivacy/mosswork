#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
评论区增长全家桶 · 可执行政具：高赞评论五维自动分类器
========================================================
把粘贴的评论文本（一行一条，可选前缀「赞:123 」或「123赞」）自动：
  1. 按 痛点/情绪/争议/知识点/认同 五维打标签
  2. 统计各维度条数，给出主导维度
  3. 为每条匹配可套用的二创角度句式
  4. 标记可能越线的词（导流/引战/绝对化），供发布前自检

用法（无需联网、纯标准库）：
  python3.11 comment_classify.py comments.txt        # 读文件
  python3.11 comment_classify.py                      # 交互粘贴，Ctrl+D 结束
  cat comments.txt | python3.11 comment_classify.py   # 管道

输出为纯文本表格，可直接粘进选题表 / 发给 AI 继续深加工。
"""
import sys
import re

# ---------- 五维识别词典（关键词启发式，可直接扩写） ----------
DIMS = {
    "痛点": [
        "不行", "搞不定", "不知道怎么", "求", "烦", "翻车", "卡", "崩", "坑",
        "没用", "救", "焦虑", "学不会", "做不来", "总", "又", "累", "难", "慢",
        "找不到", "搞错", "失败", "劝退", "绕", "懵", "慌", "穷", "贵", "亏",
        "错", "怎么办", "咋整", "咋办", "求教", "整", "崩", "坑死", "崩溃", "抓狂",
    ],
    "情绪": [
        "+1", "太真实", "破防", "泪目", "沉默", "说的就是我", "我哭", "破大防",
        "绷不住", "破防了", "真实", "哭了", "扎心", "戳", "共鸣", "懂我", "心疼",
        "窒息", "emo", "破防", "绝了", "救命", "上头", "后劲",
    ],
    "争议": [
        "不对", "反对", "我觉", "但是", "然而", "其实", "未必", "凭什么", "扯",
        "不同意", "站", "两派", "吵", "杠", "洗", "双标", "压根", "明明",
    ],
    "知识点": [
        "补充", "其实", "原理", "数据", "公式", "标准", "依据", "研究", "实测",
        "科普", "纠正", "更正", "来源", "出处", "查证", "专业", "术语", "机制",
    ],
    "认同": [
        "收藏", "关注", "更多", "坐等", "催更", "求", "安排", "已关", "星标",
        "三连", "来了", "蹲", "催", "续集", "多来点", "懂我", "举手", "等更新",
    ],
}

# 红线词（命中需人工复核，不自动判违规）
RISK = {
    "导流": ["加我", "私我", "主页", "进群", "微信", "vx", "v信", "公众号", "二维码", "联系方式", "看我"],
    "引战": ["垃圾", "智障", "low", "无脑", "脑残", "喷", "黑子", "滚", "废物"],
    "绝对化": ["最", "第一", "绝对", "一定", " guaranteed", "包赚", "必", "100%", "肯定"],
}

ANGLE = {
    "痛点": "「针对大家说的____困扰，今天一次讲清」/「评论区高频翻车点，我整理__条」",
    "情绪": "「你不是一个人，____这件事很多人都绷着」/「如果此刻你正____，这期送给你」",
    "争议": "「关于____的两种看法，我摆出来你自己判断」/「评论区吵翻的____，我实测一遍」",
    "知识点": "「评论区补的知识点，我展开讲讲____」/「有朋友说____其实不对，真相是」",
    "认同": "「你们催的____续集，安排」/「既然大家爱看____，下期聊更狠的」",
}


def classify(text: str) -> list:
    """返回命中维度列表（按权重排序：命中关键词越多越靠前）。"""
    scores = {}
    low = text.lower()
    for dim, kws in DIMS.items():
        s = sum(1 for k in kws if k in text or k.lower() in low)
        if s:
            scores[dim] = s
    if not scores:
        return ["其他/中性"]
    ordered = sorted(scores.items(), key=lambda x: -x[1])
    return [d for d, _ in ordered]


def risk_scan(text: str) -> list:
    hits = []
    low = text.lower()
    for cat, kws in RISK.items():
        if any(k in text or k.lower() in low for k in kws):
            hits.append(cat)
    return hits


def parse_line(line: str):
    """解析单行：提取点赞量 + 评论正文。支持「赞:123 」「123赞 」「【123】」前缀。"""
    m = re.match(r"\s*(?:赞[:：]?\s*)?(\d+)\s*(?:赞|👍|♥)?\s*[:：.]?\s*(.*)", line)
    if m and re.match(r"^\d+$", m.group(1)) and m.group(2):
        return int(m.group(1)), m.group(2).strip()
    return None, line.strip()


def main():
    if len(sys.argv) > 1:
        with open(sys.argv[1], encoding="utf-8") as f:
            raw = f.read()
    else:
        if sys.stdin.isatty():
            print("粘贴评论，每行一条（可加「赞:123 」前缀），Ctrl+D 结束：")
        raw = sys.stdin.read()

    rows = []
    for ln in raw.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        like, body = parse_line(ln)
        if not body:
            continue
        dims = classify(body)
        risks = risk_scan(body)
        rows.append((like, body, dims, risks))

    if not rows:
        print("未解析到任何评论。")
        return

    # 计数
    from collections import Counter
    cnt = Counter()
    for _, _, dims, _ in rows:
        for d in dims:
            cnt[d] += 1

    print("=" * 60)
    print(f"共解析 {len(rows)} 条评论 | 维度分布：", end="")
    for d in ["痛点", "情绪", "争议", "知识点", "认同", "其他/中性"]:
        if cnt.get(d):
            print(f" {d}{cnt[d]}", end="")
    print()
    if cnt:
        top = max([d for d in cnt if d != "其他/中性"], key=lambda d: cnt[d], default="—")
        print(f"主导维度：{top}（优先做该维度的二创内容）")
    print("=" * 60)

    for i, (like, body, dims, risks) in enumerate(rows, 1):
        like_s = f"赞{like}" if like else "—"
        dim_s = "/".join(dims)
        risk_s = f"  ⚠越线:{','.join(risks)}" if risks else ""
        print(f"[{i}] ({like_s}) [{dim_s}] {body[:40]}{risk_s}")
        print(f"     二创角度 → {ANGLE.get(dims[0], '通用角度')}")

    print("-" * 60)
    print("说明：五维分类为关键词启发式，仅供参考；发布前请人工复核越线标记，")
    print("并结合 references/ 里的完整框架与红线清单做最终判断。")


if __name__ == "__main__":
    main()
