# SkillPay 商品说明（h3-reference-video-prompt）

## 定价
- **¥0.05 / 次**（一次完整：拆解参考视频 + 按用户策略输出可用的 MiniMax H3 prompt）
- 推荐售卖：**周期付费**（不交明文；不自动续费）。若控制台可填按次单价，直接填 0.05。

## 商品文案
- **名称**：H3 参考视频换皮 Prompt（MiniMax）
- **一句话**：上传参考视频 + 人物/产品图，保留运镜与动作，替换出镜主体，输出可直接用于 MiniMax H3 的英文 prompt。
- **能力**：Ref2VA / I2VA / FL2VA / L2VA / T2VA；visual_remix_locked 等分层策略；可选 JSON 拆解校验脚本。
- **买家自备**：参考视频、替换图、可用的视频理解/抽帧能力（如 ffmpeg）；本 Skill 不内含模型 API Key。
- **计费口径**：成功交付符合所选 H3 模式的完整 prompt = 1 次；缺素材导致无法开写不计费。

## 上架步骤
1. https://skillpay.alipay.com/ 扫码登录创作者
2. 签约 3 份协议：SkillPay、AI 按量付费、即刻收（页面显示 0/3）
3. 上架新商品 → 上传本包 → 价格 0.05 → 过安全检测后上架

## 包内容
- SKILL.md
- references/*（格式规范与样例）
- scripts/validate_*.py
