# 参考视频层级策略契约

## 四种策略

每个视频层级都单独选择策略，不再默认所有镜头必须锁定：

| 策略 | 含义 |
|---|---|
| `preserve` | 内容、顺序和功能都保持不变 |
| `adapt` | 保留功能、节奏或轨迹，允许按新素材调整表现 |
| `replace` | 使用用户的新内容重新设计 |
| `omit` | 用户明确要求删除 |

## 可控制的层

| 层级 | 包含内容 |
|---|---|
| `timeline` | 总时长、分段、镜头顺序、卡点 |
| `camera` | 景别、角度、机位、镜头运动 |
| `composition` | 主体位置、画面重心、前中后景关系 |
| `actions` | 动作顺序、方向、轨迹、速度、停顿 |
| `transitions` | 硬切、遮挡、蒙版、匹配剪辑、变形、定格 |
| `text` | 字幕内容、位置、动画和出现时机 |
| `audio_timing` | 音乐卡点、动作音效触发点 |
| `audio_style` | 音乐类型、音色、环境声和旁白风格 |
| `visuals` | 人物、妆发、服装、场景、光线、色彩和材质 |
| `props` | 道具的外观、数量、位置、轨迹和功能 |
| `product_brand` | 产品、包装、标签、品牌及收尾展示 |
| `narrative` | 信息顺序、冲突、卖点、情绪曲线和结尾作用 |

## 常用预设

### visual_remix_locked

适用于“镜头不变，只换人物、服装、背景和产品”：

- `timeline`、`camera`、`composition`、`actions`、`transitions`、`audio_timing`：`preserve`
- `props`：默认 `adapt`，运动与转场功能不变，外观可变
- `visuals`、`product_brand`、`text`、`audio_style`：`replace`
- `narrative`：`preserve`

### camera_and_rhythm_only

适用于“保留拍法和节奏，内容重新演”：

- `timeline`、`camera`、`composition`、`transitions`、`audio_timing`：`preserve`
- `actions`、`props`：`adapt` 或 `replace`
- `visuals`、`product_brand`、`text`、`audio_style`：`replace`
- `narrative`：按用户目标选择 `adapt` 或 `replace`

### narrative_structure_only

适用于“借用爆款结构，不复刻具体画面”：

- `narrative`：`preserve` 或 `adapt`
- `timeline`：`adapt`
- 其他层：`replace`

### free_rebuild

仅保留用户点名的锚点，其他层均可 `replace` 或 `omit`。用户没有明确允许时不得自行使用。

## 容易误判的内容

- 蒙版的出现、收拢和变形可设为 `preserve`，蒙版画成什么可放入 `visuals: replace`。
- 道具的挥动方向和遮挡功能可设为 `preserve`，道具外观可设为 `adapt`。
- 换装发生的时间可设为 `preserve`，每套服装可设为 `replace`。
- 字幕时机可设为 `preserve`，文字内容和字体视觉可设为 `replace`。
- 鼓点与动作触发点可设为 `preserve`，乐器与音色可设为 `replace`。
- “保持运镜”不等于“保持动作”；两者必须分别记录。

## remix-contract.json

```json
{
  "schema_version": 2,
  "mode": "selective_remix",
  "source": {
    "video": "reference-video.mp4",
    "prompt": "original-video-prompt.md",
    "evidence": "video"
  },
  "output": {
    "deconstruction": "video-deconstruction.json",
    "prompt": "video-prompt-final.md",
    "target_model": null
  },
  "policy": {
    "timeline": "preserve",
    "camera": "preserve",
    "composition": "preserve",
    "actions": "adapt",
    "transitions": "preserve",
    "text": "replace",
    "audio_timing": "preserve",
    "audio_style": "replace",
    "visuals": "replace",
    "props": "adapt",
    "product_brand": "replace",
    "narrative": "adapt"
  },
  "locked": {
    "timeline": ["0-2 秒", "2-4 秒", "4-6.5 秒"],
    "required_phrases": [
      "固定正面机位",
      "扫过画面",
      "产品轻微旋转后正面定格"
    ]
  },
  "validation": {
    "preserve_timeline": true,
    "direct_result_only": true
  },
  "limits": {
    "max_chars": 1600
  }
}
```

`locked` 只记录本次确实需要保留的内容。`required_phrases` 使用最短、最稳定的动作、机位或转场短语，不要混入将被替换的人物、服装、背景和产品名。
