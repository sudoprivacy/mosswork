# 参考视频拆解结构

## 分段原则

出现以下任一变化时新建镜头或连续段：

- 明显切镜或转场。
- 机位、景别、角度或运镜改变。
- 主体、主要动作或动作目的改变。
- 场景、时间、服装或产品展示阶段改变。
- 字幕、音效或叙事功能发生明显切换。

不要为了凑数量拆镜。连续长镜头可以按动作阶段分段，但要标记为同一镜头。

## Markdown 镜头表

给人阅读时使用：

| 时间 | 镜头与构图 | 主体动作 | 场景与视觉 | 转场/字幕/声音 | 功能 | 策略 |
|---|---|---|---|---|---|---|
| 0-2 秒 | 固定正面中景，人物居中 | 拿起产品、开盖 | 白色影棚，硬光 | 开瓶声，硬切 | 建立产品 | 运镜保留，视觉替换 |

表格后只补充真正影响复刻或重写的结构总结，不重复逐格内容。

## JSON 结构

```json
{
  "schema_version": 1,
  "source": {
    "type": "video",
    "path_or_url": "reference-video.mp4",
    "evidence": "video"
  },
  "goal": "保留镜头节奏，重做人物和产品广告内容",
  "duration_seconds": 15,
  "shots": [
    {
      "shot_id": "S01",
      "start_seconds": 0,
      "end_seconds": 2,
      "shot_size": "中景",
      "camera": {
        "angle": "正面平视",
        "position": "固定",
        "movement": "无"
      },
      "composition": "人物居中，产品位于胸前",
      "subject": "年轻女性与瓶装饮料",
      "action": "拿起产品，旋开瓶盖",
      "environment": "白色影棚",
      "lighting_palette": "硬光，黑白高反差",
      "props_product": "单瓶饮料",
      "transition_effects": "段尾硬切",
      "text": null,
      "audio": "开瓶声与气泡声落在动作点",
      "narrative_function": "快速建立人物与产品",
      "policy": {
        "camera": "preserve",
        "actions": "adapt",
        "visuals": "replace"
      },
      "confidence": "high"
    }
  ],
  "unknowns": []
}
```

## 取值规则

- `source.evidence` 只能是 `video`、`prompt_only`、`transcript_only` 或 `mixed`。
- 时间使用秒数，允许小数；镜头必须按时间顺序排列且结束时间大于开始时间。
- 看不清或无法确认的字段写 `null`，并加入 `unknowns`，不要凭经验补造。
- `confidence` 使用 `high`、`medium`、`low`。
- `policy` 只写该镜头与全局策略不同或需要强调的层。
- 仅有提示词时，拆解的是提示词结构，不得把推断写成视频实测事实。
