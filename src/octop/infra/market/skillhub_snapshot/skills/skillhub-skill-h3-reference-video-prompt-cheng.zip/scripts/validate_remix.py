#!/usr/bin/env python3
"""Validate a reference-video-derived generation prompt."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


TIME_RE = re.compile(
    r"(?<![\d.])(\d+(?:\.\d+)?)\s*[—–-]\s*(\d+(?:\.\d+)?)\s*秒"
)

META_PATTERNS = [
    re.compile(pattern)
    for pattern in (
        r"只允许替换",
        r"原人物.{0,12}替换",
        r"原服装.{0,12}替换",
        r"原场景.{0,12}替换",
        r"原道具.{0,12}(?:替换|改成)",
        r"如果与参考视频冲突",
        r"若本提示词.{0,20}冲突",
        r"道具可以更换外观",
    )
]


def read_text(path: str) -> str:
    return Path(path).read_text(encoding="utf-8").strip()


def timeline(text: str) -> list[str]:
    return [f"{start}-{end}" for start, end in TIME_RE.findall(text)]


def normalize_timeline(items: object) -> list[str]:
    if not isinstance(items, list):
        return []
    return [
        item.replace("—", "-").replace("–", "-").replace(" 秒", "").strip()
        for item in items
        if isinstance(item, str)
    ]


def flatten_required(value: object) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [item for item in value if isinstance(item, str)]
    if isinstance(value, dict):
        result: list[str] = []
        for item in value.values():
            result.extend(flatten_required(item))
        return result
    return []


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate preserved structure, required phrases, length, and wording."
    )
    parser.add_argument("--source", required=True, help="Source prompt path")
    parser.add_argument("--output", required=True, help="Final prompt path")
    parser.add_argument("--contract", help="Optional remix-contract.json")
    parser.add_argument("--max-chars", type=int, default=1600)
    parser.add_argument(
        "--require",
        action="append",
        default=[],
        help="Required phrase; may be repeated",
    )
    timeline_group = parser.add_mutually_exclusive_group()
    timeline_group.add_argument(
        "--preserve-timeline",
        dest="preserve_timeline",
        action="store_true",
        help="Require the output timeline to match the source",
    )
    timeline_group.add_argument(
        "--allow-timeline-change",
        dest="preserve_timeline",
        action="store_false",
        help="Do not compare source and output timelines",
    )
    wording_group = parser.add_mutually_exclusive_group()
    wording_group.add_argument(
        "--direct-result-only",
        dest="direct_result_only",
        action="store_true",
        help="Reject wording that explains the replacement process",
    )
    wording_group.add_argument(
        "--allow-process-wording",
        dest="direct_result_only",
        action="store_false",
        help="Allow process wording in analytical outputs",
    )
    parser.set_defaults(preserve_timeline=None, direct_result_only=None)
    args = parser.parse_args()

    source = read_text(args.source)
    output = read_text(args.output)
    source_timeline = timeline(source)
    output_timeline = timeline(output)
    required = list(args.require)
    max_chars = args.max_chars
    preserve_timeline = (
        True if args.preserve_timeline is None else args.preserve_timeline
    )
    direct_result_only = (
        True if args.direct_result_only is None else args.direct_result_only
    )

    if args.contract:
        contract = json.loads(read_text(args.contract))
        locked = contract.get("locked", {})
        required.extend(flatten_required(locked.get("required_phrases", [])))
        contract_timeline = normalize_timeline(locked.get("timeline"))
        if contract_timeline:
            source_timeline = contract_timeline
        validation = contract.get("validation", {})
        if args.preserve_timeline is None:
            preserve_timeline = validation.get("preserve_timeline", True)
        if args.direct_result_only is None:
            direct_result_only = validation.get("direct_result_only", True)
        max_chars = contract.get("limits", {}).get("max_chars", max_chars)

    errors: list[str] = []

    if preserve_timeline:
        if not source_timeline:
            errors.append("Source prompt has no recognizable time segments.")
        elif output_timeline != source_timeline:
            errors.append(
                f"Timeline changed: source={source_timeline}, output={output_timeline}"
            )

    for phrase in dict.fromkeys(required):
        if phrase and phrase not in output:
            errors.append(f"Missing required phrase: {phrase}")

    if len(output) > max_chars:
        errors.append(f"Output too long: {len(output)} > {max_chars} characters")

    if direct_result_only:
        for pattern in META_PATTERNS:
            match = pattern.search(output)
            if match:
                errors.append(f"Contains process wording: {match.group(0)}")

    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1

    print(
        "REFERENCE_PROMPT_OK "
        f"segments={len(output_timeline)} chars={len(output)} "
        f"required={len(set(required))} preserve_timeline={str(preserve_timeline).lower()} "
        f"direct_result_only={str(direct_result_only).lower()}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
