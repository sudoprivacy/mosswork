---
name: skillhub-skill-h3-reference-video-prompt-cheng
description: "Deconstruct a reference video (actions, camera, environment, timing, audio) and generate MiniMax H3 video-generation prompts that replace the on-screen person/product with user-supplied reference images while preserving shot structure. Use when: (1) user uploads a reference video + character image and says 'replace the person with this character', 'keep the actions/camera, change the visual', '复刻动"
---

# H3 Reference Video Prompt

Deconstruct a reference video, decide which layers to preserve or replace, and output a MiniMax H3-format prompt.

## Workflow

### Step 1 — Identify Inputs and H3 Mode

Determine what the user supplied and which H3 mode applies:

| Input combination                            | H3 mode                     | Output format                                                                                                                            |
| -------------------------------------------- | --------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| Reference video + character/product image(s) | **Ref2VA** (full-reference) | Six sections: `subject_definitions`, `summary`, `retention_analysis`, `detailed_description`, `overall_soundscape`, `non_diegetic_music` |
| Only a first-frame image                     | **I2VA**                    | Instruction line + `integrated_multimodal_description` + `overall_soundscape` + `non_diegetic_music`                                     |
| First + last frame images                    | **FL2VA**                   | Alignment line + three core fields                                                                                                       |
| Only a last-frame image                      | **L2VA**                    | Alignment line + three core fields                                                                                                       |
| No images, text only                         | **T2VA**                    | Three core fields directly                                                                                                               |

When the user says "replace the person in this video with the character in this image", the mode is **Ref2VA**. Read `references/ref-en.txt` for the exact six-section format, label rules, and complete examples. For base modes (T2VA/I2VA/FL2VA/L2VA), read `references/base-en.txt`.

### Step 2 — Deconstruct the Reference Video

Actually read the video before claiming you analyzed it. Extract frames (e.g. `ffmpeg -i input.mp4 -vf fps=3 frame_%03d.png`) and view them. Extract audio if needed for beat/tempo analysis.

Segment by: hard cuts, camera changes, subject action changes, scene changes, or audio cue changes. For each segment record:

- Start/end time and duration
- Shot size, angle, camera position, camera movement (type + amplitude + speed)
- Subject action: direction, path, speed, pauses, beat alignment
- Environment, lighting, color palette, costume, props
- Transitions (hard cut, wipe, match cut, etc.)
- On-screen text (verbatim)
- Audio: music tempo, SFX triggers, ambient sound, dialogue
- Narrative/emotional function of the shot

Do not invent shots or details you cannot see. Mark unknown fields as `null` or "unknown". For structured JSON output, follow `references/deconstruction-schema.md`.

### Step 3 — Set Layer Strategy

Choose a strategy per layer. Default to **visual_remix_locked** when the user says "keep the actions/camera, change the person":

| Layer                                      | visual_remix_locked                         | selective_remix (user-specified) |
| ------------------------------------------ | ------------------------------------------- | -------------------------------- |
| Timeline / shot order / beat timing        | `preserve`                                  | per user                         |
| Camera (shot size, angle, movement)        | `preserve`                                  | per user                         |
| Composition (subject position, framing)    | `preserve`                                  | per user                         |
| Actions (body movement, gestures, turns)   | `preserve`                                  | per user                         |
| Transitions                                | `preserve`                                  | per user                         |
| Audio timing (beat hits, SFX triggers)     | `preserve`                                  | per user                         |
| Character appearance (face, hair, costume) | `replace` with user image                   | per user                         |
| Environment / background / lighting        | `replace` or `adapt`                        | per user                         |
| Props / product appearance                 | `adapt` (function preserved, look replaced) | per user                         |
| Music style / audio texture                | `replace` or `adapt`                        | per user                         |

Read `references/layer-contract.md` for the full layer list and preset definitions.

### Step 4 — Write the H3 Ref2VA Prompt

Follow the six-section format from `references/ref-en.txt`:

1. **`subject_definitions`** — Define each referenced item with a stable label (`<Subject N>`, `<Picture N>`, `<Video N>`, `<Audio N>`). The replacement character from the user's image becomes a `<Subject N>` whose appearance comes from `<Picture N>`. The reference video's motion becomes `<Video N>` or an action `<Subject N>`.
2. **`summary`** — One paragraph starting with `[reference generation]` (or combined task types). State the target video, the main subject, and which references drive appearance vs. motion.
3. **`retention_analysis`** — One line per label with a relationship marker: `fully_preserved`, `partially_preserved`, `attribute_transfer`, or `weak_reference`.
4. **`detailed_description`** — The main body. Open with 1–2 style sentences, then describe each shot in playback order. For each shot: composition, subject appearance/position, environment/lighting, actions with timing, camera movement, diegetic sound, and where reference labels apply. Use `[Shot 1]` for the opening (no timestamp) and `[Shot N] At 00:MM.mmm, ...` for subsequent cuts. Target 350–500 English words for generation tasks.
5. **`overall_soundscape`** — 1–4 sentences on ambient sound, physical action sounds, non-verbal human sounds across the full video.
6. **`non_diegetic_music`** — 1–3 sentences on instrumentation, tempo, rhythm, dynamics. Use `N/A` if no background music.

**Critical rules:**

- Write all sections in English. Preserve dialogue, lyrics, and visible on-screen text in their original language inside `<d>[Language] ...</d>`.
- Keep reference labels consistent across all six sections.
- Match total duration to the requested video length (4–15 seconds for H3).
- Describe concrete visual and audio details, not abstract words like "cinematic" or "beautiful".
- Do NOT write process wording in the final prompt: no "replace the original person with", no "change the scene to", no "if conflicting with reference". Write the final scene directly.

### Step 5 — Validate (Optional)

For structured deconstruction JSON:

```bash
python scripts/validate_deconstruction.py --input deconstruction.json
```

For preserving timeline/structure in the final prompt:

```bash
python scripts/validate_remix.py --source original_prompt.txt --output final_prompt.txt --contract remix-contract.json
```

## Reference Files

| File                                  | When to read                                                                                                                                                                    |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `references/ref-en.txt`               | Always when outputting Ref2VA (video + image inputs). Contains six-section format, label rules, retention markers, speaker IDs, and a complete worked example.                  |
| `references/base-en.txt`              | When outputting T2VA / I2VA / FL2VA / L2VA. Contains the three-core-field format, keyframe alignment lines, camera-motion vocabulary, shot/cut rules, and four worked examples. |
| `references/deconstruction-schema.md` | When producing a structured JSON deconstruction. Defines the shot table format, required fields, and confidence levels.                                                         |
| `references/layer-contract.md`        | When deciding preserve/adapt/replace/omit per layer. Contains preset contracts for visual_remix_locked, camera_and_rhythm_only, narrative_structure_only, and free_rebuild.     |
| `references/eval-cases.json`          | Edge cases and expected behaviors for tricky requests (prop replacement, prompt-only evidence, free rebuild, etc.).                                                             |

## Quick Decision Guide

- User uploads video + character image, wants same actions with new character → **Ref2VA**, visual_remix_locked, output six sections.
- User uploads video only, asks "analyze this" → deconstruct_only, output shot table, no final prompt.
- User uploads video + says "rewrite this into a video prompt" → deconstruct_and_prompt, output shot table + H3 prompt.
- User says "keep camera and rhythm, everything else new" → selective_remix, preserve camera/timeline/audio_timing, replace visuals/actions.
- User provides only a first-frame image → I2VA, read `base-en.txt`.

## SkillPay commercial note

Listed at **¥0.05 per successful run** (deconstruct + H3 prompt delivered). Period billing does not auto-renew. Do not embed API keys or personal accounts in this package.
