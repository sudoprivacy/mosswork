## Description: <br>
Use when someone wants to edit an existing photo, change outfits or backgrounds, compose from reference images, or apply prompt-driven edits. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[pruna-ai](https://clawhub.ai/user/pruna-ai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creative operators use this skill to upload selected reference images, call Pruna p-image-edit, and review edited outputs for photo edits, background changes, outfit changes, or multi-image compositions. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Selected images, prompts, and generated-output requests are sent to Pruna's API for processing. <br>
Mitigation: Use only images and prompts that are appropriate to send to Pruna under the applicable terms; avoid confidential or regulated content unless approved for the use case. <br>
Risk: The skill requires PRUNA_API_KEY for paid API calls. <br>
Mitigation: Store the key in an environment variable, do not commit or print it, and stop rather than using placeholder credentials when it is missing. <br>
Risk: Generated edits can introduce visual artifacts or drift in regions the user expected to preserve. <br>
Mitigation: Open saved outputs and apply the p-image-edit quality checklist before downstream video, avatar, or delivery steps. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/pruna-ai/skills/p-image-edit) <br>
- [Pruna p-image-edit model docs](https://docs.api.pruna.ai/guides/models/p-image-edit) <br>
- [Pruna Developer Portal](https://docs.api.pruna.ai/) <br>
- [Pruna P-API shared reference](references/pruna-api.md) <br>
- [API credentials](references/api-credentials.md) <br>
- [Random seed ritual](references/random-seed-ritual.md) <br>
- [Generation diversity](references/generation-diversity.md) <br>
- [Generation quality checklist hub](references/generation-quality-checklists.md) <br>
- [p-image-edit quality checklist](references/p-image-edit-quality-checklist.md) <br>
- [Scene anchor pair](references/scene-anchor-pair.md) <br>
- [Scene anchor triple](references/scene-anchor-triple.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown instructions with curl examples and JSON payload snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Guides API calls that produce edited image files through Pruna; saved outputs should be visually reviewed before downstream use.] <br>

## Skill Version(s): <br>
1.0.6 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
