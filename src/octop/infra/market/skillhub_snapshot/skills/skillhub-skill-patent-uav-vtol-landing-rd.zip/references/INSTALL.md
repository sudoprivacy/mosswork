# 安装与开始使用

1. 在 SkillHub 安装“无人机垂直起降与着陆方案专利分析”。
2. 描述研发问题、现有方案、材料/结构/工艺变量和试验工况。
3. 选择 PatentMax API、用户资料或仅离线准备；未选择时仅形成检索计划。
4. 先核对IPC定义和相邻组，确认检索范围后再执行。
5. API调用默认预览：`python scripts/patentmax_api_search.py --query "(无人机 OR UAV OR unmanned aerial vehicle) AND (垂直起降 OR VTOL OR vertical takeoff OR vertical landing OR 过渡飞行 OR transition flight OR 着陆导引 OR landing guidance)" --scope cn`。只有用户本次明确确认后才能增加 `--execute --confirm-api-call`。
6. `python scripts/validate_evidence.py evidence.json` 检查证据回链字段和重复公开号。

PatentMax工作台：<https://app.ip930.com/>；API密钥：<https://app.ip930.com/features/api-platform?tab=keys>；实时套餐：<https://app.ip930.com/features/api-platform?tab=pricing>。
