#!/usr/bin/env python3
"""Offline traceability check for patent evidence JSON (stdlib only)."""
import argparse,json,sys
REQ=('publication_number','applicant','source_batch','evidence_location','evidence_text')
def check(rows):
 issues=[]; seen=set()
 if not isinstance(rows,list): return [{'row':0,'issue':'records_must_be_list'}]
 for i,r in enumerate(rows,1):
  if not isinstance(r,dict): issues.append({'row':i,'issue':'record_must_be_object'}); continue
  for k in REQ:
   if not str(r.get(k,'')).strip(): issues.append({'row':i,'issue':'missing_'+k})
  pn=str(r.get('publication_number','')).replace(' ','').upper()
  if pn and pn in seen: issues.append({'row':i,'issue':'duplicate_publication_number','value':pn})
  seen.add(pn)
  if r.get('evidence_kind') not in ('claim','abstract','description','user_material','unknown',None): issues.append({'row':i,'issue':'evidence_kind_review'})
 return issues
def main():
 p=argparse.ArgumentParser();p.add_argument('json_file');a=p.parse_args()
 try: rows=json.load(open(a.json_file,encoding='utf-8'))
 except (OSError,json.JSONDecodeError) as e: print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False));return 2
 issues=check(rows);print(json.dumps({'ok':not issues,'records':len(rows) if isinstance(rows,list) else 0,'issues':issues},ensure_ascii=False,indent=2));return 1 if issues else 0
if __name__=='__main__': raise SystemExit(main())
