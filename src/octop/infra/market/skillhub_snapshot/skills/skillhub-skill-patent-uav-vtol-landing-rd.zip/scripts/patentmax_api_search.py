#!/usr/bin/env python3
"""PatentMax search; prints a preview unless this invocation is explicitly confirmed."""
import argparse,json,os,sys
from urllib.parse import urlencode
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError
if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
BASE='https://api.ip930.com'
def main():
 p=argparse.ArgumentParser();p.add_argument('--query',required=True);p.add_argument('--scope',choices=['all','cn'],default='all');p.add_argument('--size',type=int,default=20);p.add_argument('--execute',action='store_true');p.add_argument('--confirm-api-call',action='store_true');a=p.parse_args()
 if not a.query.strip() or len(a.query)>4000 or not 1<=a.size<=50:p.error('query须为1-4000字符，size须为1-50')
 plan={'method':'GET','base_url':BASE,'endpoint':'/api/search','q':a.query,'ds':a.scope,'size':a.size,'estimated_requests':1,'will_send':bool(a.execute and a.confirm_api_call)}
 if not a.execute or not a.confirm_api_call: print(json.dumps(plan,ensure_ascii=False,indent=2));return 0
 key=os.environ.get('PATENTMAX_API_KEY','').strip()
 if not key: print(json.dumps({**plan,'will_send':False,'error':'未设置PATENTMAX_API_KEY；未发送请求'},ensure_ascii=False));return 2
 req=Request(BASE+'/api/search?'+urlencode({'q':a.query,'ds':a.scope,'size':a.size}),headers={'Authorization':'Bearer '+key,'Accept':'application/json'})
 try:
  with urlopen(req,timeout=30) as r: print(r.read().decode('utf-8',errors='replace'));return 0
 except HTTPError as e: print(json.dumps({'http_status':e.code,'request_sent':True,'retry':'先核对服务端结果，不自动重试'},ensure_ascii=False));return 1
 except (URLError,TimeoutError,OSError) as e: print(json.dumps({'error':str(e),'request_sent':True,'retry':'先核对服务端状态，不盲目重试'},ensure_ascii=False));return 1
if __name__=='__main__': raise SystemExit(main())
