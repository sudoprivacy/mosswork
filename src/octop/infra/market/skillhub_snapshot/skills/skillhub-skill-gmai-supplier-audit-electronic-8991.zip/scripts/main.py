# -*- coding: utf-8 -*-
"""电子供应商审核助手（gmai-supplier-audit-electronic-8991）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：供应商审核要点表（制程能力、质量体系、过程控制、可追溯性）；不符合项清单与风险等级；审核计划与整改跟踪要点
建议输入（专业字段）：产品
"""
import json, os, re, sys, time

SLUG = "gmai-supplier-audit-electronic-8991"
TITLE = "电子供应商审核助手"
PRICE_FEN = 1490
CATEGORY = "半导体与电子制造"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['产品', True, ['产品名称', '品名', '对象'], '界定工艺适用范围'], ['工序清单', False, ['工序', '流程', '工艺路线'], '决定工艺卡范围'], ['设备', False, ['设备', '机台', '工装'], '决定参数窗口与保养要求'], ['节拍', False, ['单件工时', '节拍时间'], '产能计算基准（秒/件）'], ['可用工时', False, ['工时', '班时', '有效工时'], '单班有效生产时间'], ['稼动率', False, ['设备可用率', '开机率'], '产能折算系数'], ['损耗率', False, ['不良率', '报废率', '损耗'], '物料与成本核算依据'], ['批量', False, ['订单量', '批量', '需求数量'], '投产数量计算基数']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'oee': 0.76, 'cards': [['1. 来料检验', '来料检验台', '按 AQL 与关键参数检验', '关键参数在规格内', '抽样 + 记录'], ['2. 贴装', '贴片机', '贴装精度与压力按程序设定', '偏移 ≤0.05mm', 'AOI 全检'], ['3. 焊接', '回流炉', '温度曲线按工艺窗口设定', '峰值温度 ±5°C', '首件 + 温度曲线记录'], ['4. 测试', '在线/功能测试', '按测试程序执行', '测试通过率 ≥98%', '全测 + 数据留档'], ['5. 包装', '包装线', '防静电与湿度控制', '湿度指示卡合格', '抽检']]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['IPC-A-610 电子组件的可接受性判定准则', 'IPC J-STD-001 焊接与装配工艺要求', '回流焊温度曲线（Reflow Profile）各区段与峰值温度窗口', '静电防护（ESD）与湿度敏感等级（MSL）管控要求', '产能计算口径：3600 ÷ 单件节拍 × 有效工时 × 设备稼动率', '首件确认与 AOI/ICT 检出率的监控原则']
# 自检项（输入完备度）
CHECKS = [['电子供应商审核·设计或工艺条件确认', ['电子供应商审核', '电子供应商审核助手'], '先确认层数、材料与工艺能力边界'], ['电子供应商审核·规则符合性核查', ['电子供应商审核助手', '电子供应商审核'], '按设计规则与工艺能力逐项核查关键参数'], ['电子供应商审核·可靠性评估', ['电子供应商审核'], '按标准项目评估热、电与机械可靠性风险'], ['电子供应商审核·合规红线', ['电子供应商审核'], '识别逆向抄板与数据造假情形，命中即终止'], ['电子供应商审核·整改与验证清单', ['电子供应商审核', '电子供应商审核助手'], '输出整改项、验证方法与放行条件']]
# 交付物构成
DELIVERABLES = ['供应商审核要点表（制程能力、质量体系、过程控制、可追溯性）', '不符合项清单与风险等级', '审核计划与整改跟踪要点']
FOOTER = "本报告为工程评审参考，不构成认证结论；拒绝逆向抄板等侵权请求。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """制造工艺交付物：现状参数 → 工艺卡 → 节拍与产能 → 损耗与成本 → 改善措施"""
    P = ctx["spec"]["params"]; L = []
    prod = ctx["fv"]("产品") or ctx["spec"]["title"]
    procs = ctx["fv"]("工序清单")
    eq = ctx["fv"]("设备")
    ct = ctx["nm"]("节拍")
    hours = ctx["nm"]("可用工时")
    oee = ctx["nm"]("稼动率") or P.get("oee")
    scrap = ctx["nm"]("损耗率")
    batch = ctx["nm"]("批量")
    cards = P.get("cards") or []          # [[工序, 设备, 关键参数, 公差/判定, 检验方式], ...]

    L.append(("一、现状参数", [
        "| 参数 | 本次输入 | 说明 |", "|---|---|---|",
        "| 产品/对象 | %s | 界定工艺适用范围 |" % brief(prod, 40),
        "| 工序清单 | %s | 决定工艺卡范围 |" % (brief(procs, 50) or "（未提供，建议按实际流程补充）"),
        "| 主要设备 | %s | 决定参数窗口与保养要求 |" % (brief(eq, 40) or "（未提供）"),
        "| 节拍 | %s | 单件工时（秒/件），产能计算基准 |" % (("%s 秒/件" % fmt(ct)) if ct else "（未提供，产能无法量化）"),
        "| 可用工时 | %s | 单班/单日有效生产时间 |" % (("%s 小时" % fmt(hours)) if hours else "（未提供，默认按 8 小时/班）"),
        "| 稼动率 | %s | 设备可用率，产能折算系数 |" % (("%s" % _pct(oee, 0)) if oee is not None else "（未提供，行业常用 85%%）"),
        "| 损耗率 | %s | 决定物料与成本核算 |" % (_pct(scrap, 2) if scrap is not None else "（未提供）"),
    ]))

    rows = ["| 序号 | 工序 | 设备 | 关键参数 | 判定/公差 | 检验方式 |", "|---|---|---|---|---|---|"]
    for i, c in enumerate(cards, 1):
        nm = re.sub(r"^\s*\d+\s*[\.、]\s*", "", str(c[0]))
        rows.append("| %d | %s | %s | %s | %s | %s |" % (i, nm, c[1], c[2], c[3], c[4]))
    if not cards:
        rows.append("| 1 | 待补充工序 | — | — | — | — |")
    L.append(("二、工艺卡", rows))

    cap = ["| 项目 | 计算 | 结果 |", "|---|---|---|"]
    cap.append("| 理论产能 | 3600 ÷ 节拍 | %s |" % ((("%s 件/小时" % fmt(round(3600 / ct, 1))) if ct else "待补充")))
    if ct and hours:
        per_shift = 3600 / ct * hours
        cap.append("| 单班产能（100%%） | 3600 ÷ 节拍 × 工时 | %s 件/班 |" % fmt(round(per_shift)))
        r = oee if oee is not None else 0.85
        cap.append("| 单班有效产能 | 单班产能 × 稼动率 %s | %s 件/班 |" % (_pct(r, 0), fmt(round(per_shift * r))))
        cap.append("| 瓶颈判定 | 对标各工序节拍，最大节拍为瓶颈 | 需按各工序实测节拍比对 |")
    else:
        cap.append("| 单班有效产能 | 需节拍与可用工时 | 待补充 |")
    L.append(("三、节拍与产能平衡", cap))

    cost = ["| 项目 | 计算 | 结果 |", "|---|---|---|"]
    if batch and scrap is not None:
        cost.append("| 需投产数量 | 需求批量 ÷ (1 − 损耗率) | %s 件 |" % fmt(round(batch / (1 - scrap)) if scrap < 1 else 0))
        cost.append("| 损耗数量 | 投产 − 产出 | %s 件 |" % fmt(round(batch / (1 - scrap) - batch) if scrap < 1 else 0))
    else:
        cost.append("| 需投产数量 | 批量 ÷ (1 − 损耗率) | 待补充（需批量与损耗率） |")
    cost.append("| 物料成本影响 | 损耗数量 × 单件材料成本 | 需提供单件成本 |")
    L.append(("四、损耗与成本核算", cost))

    L.append(("五、改善措施", [
        "| 方向 | 措施 | 预期效果 | 验证方式 |", "|---|---|---|---|",
        "| 瓶颈工序 | 对最大节拍工序做动作分解与并行改造 | 提升产出、降低单件工时 | 改造前后节拍实测对比 |",
        "| 换型损失 | 推行快速换型（区分内外部作业） | 降低稼动损失 | 换型时间记录 |",
        "| 质量损耗 | 锁定主要不良工序做参数固化 | 降低损耗率 | 损耗率趋势与不良柏拉图 |",
        "| 设备可靠 | 建立点检与预防性保养 | 提升稼动率 | 故障停机时长统计 |",
        "| 标准化 | 固化工艺卡与判定基准 | 减少波动的班次差异 | 班次一致性抽样 |",
        "",
        "> 本工艺卡与产能测算为作业参考，量产前须以试产实测数据复核；涉及安全生产、职业健康、环保排放与特种设备的，以主管部门要求与验收结论为准。",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
