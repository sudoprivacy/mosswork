## Description: <br>
Use APIDot for Veo 3.1 Official API workflows, including Google Veo 3.1 Official, veo3.1-fast-official, veo3.1-lite-official, veo3.1-quality-official, text-to-video API, image-to-video API, first frame and last frame control, reference video, native audio, async task submission, task_id handling, polling, task status, webhook integration, and APIDot docs routing. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[jiehao71727](https://clawhub.ai/user/jiehao71727) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to route APIDot Veo 3.1 Official integration questions to the right docs, model pages, async workflow notes, polling guidance, and webhook guidance. It supports planning text-to-video, image-guided video, first/last-frame, reference-guided, and native-audio workflows without bundling executable code. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: APIDot API keys, private prompts, media URLs, callback URLs, generated video URLs, or API keys could be exposed if copied into client code, logs, screenshots, repositories, or chat output. <br>
Mitigation: Keep APIDOT_API_KEY in a server-side secret store, avoid logging private workflow data, and review generated guidance before using it in an integration. <br>
Risk: Live APIDot calls made from an unsafe environment could expose credentials or private media workflow data. <br>
Mitigation: Make real API calls only when the user explicitly asks and provides a safe server-side environment. <br>
Risk: Model-specific request fields, availability, limits, or commercial terms may change outside the skill artifact. <br>
Mitigation: Use current APIDot docs and model pages as the source of truth before preparing request payloads or relying on product details. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/jiehao71727/skills/apidot-veo-3-1-official-api) <br>
- [APIDot Docs](https://apidot.ai/docs) <br>
- [APIDot Veo 3.1 Official Model Page](https://apidot.ai/models/veo-3-1-official) <br>
- [APIDot Veo 3.1 Official API Docs](https://apidot.ai/docs/veo-3-1-official) <br>
- [APIDot Quickstart](https://apidot.ai/docs/quickstart) <br>
- [APIDot Webhooks](https://apidot.ai/docs/webhooks) <br>
- [APIDot Examples](https://github.com/APIDotAI/apidot-examples) <br>
- [APIDot Veo 3.1 Official Reference](references/api.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, configuration, guidance] <br>
**Output Format:** [Markdown guidance with links, workflow notes, and integration planning details] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Documentation-only output; no executable files, automatic network calls, bundled clients, or stored credentials.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
