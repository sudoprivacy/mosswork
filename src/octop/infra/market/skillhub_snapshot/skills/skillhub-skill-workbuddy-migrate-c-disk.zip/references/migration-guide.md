# WorkBuddy 数据目录迁移 · 完整避坑指南

本文件是 `workbuddy-migrate-c-disk` 技能的深度参考。它来自一次真实迁移：在目标机器上反复失败 6 次后才跑通，记录每一步踩坑与修复。执行迁移时，请结合 SKILL.md 的精简流程一起看。

## 一、背景与前提

- WorkBuddy 的**程序本体**通常已经在非系统盘（如 `D:\xxx\workbuddy\WorkBuddy.exe`），C 盘占用主要来自：
  1. 数据目录 `C:\Users\<用户名>\.workbuddy`（含记忆 / 项目 / 技能 / Python·Node 运行环境等，常 1.5~2.5 GB）——迁移主角；
  2. 更新缓存 `C:\Users\<用户名>\AppData\Local\@genieworkbuddy-desktop-updater\installer.exe`（约 500 MB）。
- 迁移方法：把数据整体搬到目标盘，原位置改为**指向目标盘的目录联接（junction，`mklink /J`）**，软件完全无感。
- 早期用 `du` 估算 `.workbuddy` 只有 1.16 GB，是因为软件运行时部分文件被占用导致少算；真实大小约 2.0 GB。迁移能腾出约 2 GB + 更新缓存 500 MB ≈ 2.5 GB。

## 二、六条必避的坑（血泪教训）

### 坑 1：回收站 API 会挂死
- 现象：第 6 步用 `Microsoft.VisualBasic.FileIO.DeleteDirectory(..., SendToRecycleBin)` "送回收站"时，脚本**卡死、黑窗一闪、日志停在 VERIFY OK 之后无输出**。
- 原因：该调用在部分机器上**挂起不返回**（沙箱内 `Add-Type` 加载该 assembly 也被拦，印证此 API 不可靠）。
- 修复：第 6 步改为 `ren` **原地改名保留**——把 `C:\Users\<用户名>\workbuddy` 改名为 `.workbuddy.migrated.bak`（同盘 rename，秒级、不挂起、数据原样可恢复）。比回收站更稳，且满足"绝不彻底删除"。

### 坑 2：.bat 里 echo 带小括号会崩
- 现象：脚本只打印到第 1 步就停，第 2 步 `if/else` 两个分支一行日志都没写。
- 原因：第 2、3 步 `echo` 文本含**未加引号的小括号**（如 `Close it (Task Manager ...)`），在 `if/else` 代码块中被当成代码块括号，整段解析失败、脚本当场崩溃。与用户操作无关。
- 修复：整体改为 `goto` 标签跳转结构，且**所有 echo / 日志文本零括号**。

### 坑 3：校验要求字节完全相等
- 现象：要求 C/D 文件数 + 字节数完全一致，但 `app\session`/日志/缓存是运行时易变文件，永远对不齐 → 校验失败 → 放弃删除。
- 修复：校验标准改为 **"D 盘包含 C 盘全部文件且大小一致（D⊇S）"**。具体实现：用 PowerShell 建立 D 盘相对路径→大小的哈希，遍历 C 盘文件检查是否都存在且大小相等；任一缺失或大小不符才判失败。

### 坑 4：杀进程不彻底
- 现象：用户以为退干净了，但 bat 仍报告 `STILL_RUNNING` 中止。
- 原因：只 `taskkill /IM WorkBuddy.exe` 漏掉了 `WorkBuddy Helper` 等残留子进程，它们仍锁 `app\session` 下的文件。
- 修复：用 PowerShell 按 `$_.Name -match 'workbuddy'` 结束**所有**匹配进程，并做"杀 → 等 2 秒 → 复检"的循环（处理慢退子进程）；`STILL_RUNNING` 时打印残留进程名 + PID，引导用户去任务管理器结束。

### 坑 5：WorkBuddy 自身运行时做不了最后一步（死循环）
- 现象：用户每次打开 WorkBuddy 来对话，软件就在运行，C 盘目录一直被占用且持续写入，删源 + 建联接永远执行不了。
- 本质：只要对话窗口还开着，进程就在，bat 必然检测到而安全中止。
- 修复：WorkBuddy（你）**只负责准备好并验证好 bat**，然后告诉用户正确顺序——**彻底退出 WorkBuddy（含关闭对话窗口）→ 按 Win+E 打开资源管理器进目标盘目录 → 双击 bat → 看到 SUCCESS 重开 → 回"完成"让我核验**。不要在软件运行时尝试替用户跑最终删除。

### 坑 6：沙箱限制导致无法实测 .bat
- 现象：在 WorkBuddy 内置环境里，`cmd.exe` 直接执行 .bat 被安全策略拦截；`Add-Type` 也被拦截。
- 修复：验证 bat 算法时，用 PowerShell 在**临时空目录**把"robocopy 同步 → D⊇S 校验 → `ren` 改名 → `mklink /J` 建联接 → 经联接读到数据"原样跑一遍确认无误，再把真实 bat 交给用户点击。临时文件验证后务必清理。

## 三、最终验证可用的 bat 模板（见 SKILL.md 中的"迁移脚本"代码块）

SkillHub 禁止上传 `.bat` 可执行脚本，因此迁移脚本正文已嵌入 `SKILL.md`，由 WorkBuddy 在目标机器上本地生成后再交给用户双击执行。要点回顾：
- `SRC=%USERPROFILE%\.workbuddy`、`DST=D:\WorkBuddy\.workbuddy`、`BAK=%USERPROFILE%\.workbuddy.migrated.bak`，用环境变量避免硬编码用户名。
- 开头先 `fsutil reparsepoint query` 探测：已是联接则直接报 `ALREADY_DONE`，避免误删。
- `[1]` 关进程：`taskkill /F /IM WorkBuddy.exe` + PowerShell 杀全部 `workbuddy` 匹配进程 + `timeout /t 2`。
- `[2]` robocopy 同步：`/E /COPY:DAT /R:2 /W:1`。
- `[3]` D⊇S 校验（PowerShell 实现），失败跳 `VERIFY_FAIL` 且**不删任何东西**。
- 进程复检：若用户在同步期间重开 WorkBuddy，跳 `REOPENED` 中止。
- `[4]` `ren "%SRC%" ".workbuddy.migrated.bak"` 改名保留（若已存在旧 `.migrated.bak` 则跳 `BAK_EXISTS` 提示先删）；改名失败跳 `REN_FAIL`。
- `[5]` `mklink /J "%SRC%" "%DST%"` 建联接，`fsutil` 复检，失败跳 `LINK_FAIL`。
- 每步写日志到 `D:\WorkBuddy\finish_move.log`；末尾 `pause` 防止一闪而过。

## 四、独立核验是否成功的方法

用户回"完成"后，WorkBuddy 应执行：
- `fsutil reparsepoint query "C:\Users\<用户名>\.workbuddy"` → 应成功，且 `Print Name` 指向目标盘（如 `D:\WorkBuddy\.workbuddy`）。
- 确认 `C:\Users\<用户名>\.workbuddy.migrated.bak` 存在（可恢复备份）。
- 经 `C:\Users\<用户名>\.workbuddy` 读取文件数与目标盘一致。
以上三条满足即迁移成功。

## 五、收尾建议（迁移成功后告知用户）

- 可顺手删 `C:\Users\<用户名>\AppData\Local\@genieworkbuddy-desktop-updater\installer.exe`（约 500 MB 更新包，可安全删，重下即恢复）。
- `C:\Users\<用户名>\.workbuddy.migrated.bak` 先保留，确认软件长期运行正常后再手动送回收站（不删也行，它和 D 盘是同一份数据，不占额外空间）。
- 此后 WorkBuddy 不再持续占用 C 盘空间（数据读写都经联接走到目标盘）。
