# -*- coding: utf-8 -*-
"""
碳汇速算工具 carbon_calculator.py  (V2.2.1 数据安全版)
读取 Excel（列：树种, 胸径(cm), 树高(m), 数量, [城市]），通过数据接口获取 plant_core_1143种_v2.1.json 的 carbon_params，
按简化异速生长公式估算碳储量，输出新增列的新 Excel。

V2.2.1 变更：主库 JSON 不再随技能包分发，运行时调用数据接口获取 5 分钟过期预签名 URL 后下载。

公式（依 V2.1 数据底座）：
  单株生物量(t) = (π/4)·(胸径/100)²·树高·干形系数(0.45) · 木材密度(t/m³) · BEF(生物量扩展因子)
  单株碳储量(kg) = 单株生物量(t) · 含碳率 · 1000
  总碳储量(t)     = 单株生物量(t) · 含碳率 · 数量

城市规范匹配（V2.1.0 新增）：
  北京   → DB11/T 2468-2025 《城市绿地碳汇计量监测技术规范》
  上海   → DB31/T 1234-2020 《城市森林碳汇计量监测技术规程》
  深圳   → DB4403/T 534-2024 《城市森林碳储量与碳汇量评估技术规范》
  成都/四川 → DB51/T 3372-2026 《城市生态系统温室气体清除碳汇核算技术规范》
  其他/未匹配 → 全国通用（蒋有绪《中国森林植被碳储量》）
  注：本库 carbon_params 已统一 ref_source=全国通用-蒋有绪；各城市规范的"所用规范"列用于
      标注本次测算采用的规范口径，数值仍基于库内物种参数（异速生长估算）。如城市规范含
      专属参数表，须另行接入后替换计算。

⚠️ 免责声明：本结果为基于公开参数的估算值，仅供方案比选参考，不作为碳交易核算依据。
"""
import sys, os, json, math
import requests
from openpyxl import Workbook, load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
FORM = 0.45  # 干形系数（树干体积折算）

# ===== V2.2.1 数据安全版：主库不再随技能包分发，运行时通过数据接口获取预签名URL =====
# 数据接口地址（腾讯云SCF函数URL，GET请求返回5个文件的5分钟过期预签名URL）
# 部署后替换为实际函数URL；也可通过环境变量 DATA_API_URL 覆盖
DATA_API_URL = os.environ.get(
    "DATA_API_URL",
    "https://1459314605-i349xxfvo1.ap-guangzhou.tencentscf.com"
)

def _fetch_presigned_urls():
    """调用数据接口获取5个数据文件的预签名URL，返回 {文件名: URL} 字典。"""
    try:
        resp = requests.get(DATA_API_URL, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        # 兼容两种返回格式：直接返回 {"urls": {...}} 或 SCF包装的 {"body": "{...}"}
        if isinstance(data, dict) and "urls" in data:
            return data["urls"]
        if isinstance(data, dict) and "body" in data:
            body = data["body"]
            if isinstance(body, str):
                body = json.loads(body)
            return body.get("urls", {})
        return {}
    except Exception as e:
        print("[warn] 数据接口调用失败：", e)
        return {}

DISCLAIMER = ("本结果为基于公开参数的估算值，仅供方案比选参考，"
              "不作为碳交易核算依据。")

NO_CITY_MSG = ("未检测到城市列，将使用全国通用参数（蒋有绪《中国森林植被碳储量》）。"
               "补充城市列可启用按城市规范精准匹配。")

# 城市 → (规范编号, 规范名称)
CITY_SPEC = {
    "北京": ("DB11/T 2468-2025", "《城市绿地碳汇计量监测技术规范》"),
    "上海": ("DB31/T 1234-2020", "《城市森林碳汇计量监测技术规程》"),
    "深圳": ("DB4403/T 534-2024", "《城市森林碳储量与碳汇量评估技术规范》"),
    "成都": ("DB51/T 3372-2026", "《城市生态系统温室气体清除碳汇核算技术规范》"),
    "四川": ("DB51/T 3372-2026", "《城市生态系统温室气体清除碳汇核算技术规范》"),
}
NATIONWIDE = ("全国通用", "蒋有绪《中国森林植被碳储量》")

# V2.2.0：未收录物种不编假数字，返回"未收录"；城市未匹配时回退 NATIONWIDE（蒋有绪）

def load_params():
    """V2.2.1：通过数据接口获取预签名URL → 下载主库JSON → 解析 carbon_params。"""
    try:
        urls = _fetch_presigned_urls()
        json_url = urls.get("plant_core_1143种_v2.1.json")
        if not json_url:
            print("[warn] 未获取到主库 plant_core_1143种_v2.1.json 的预签名URL，将使用默认参数")
            return {}
        resp = requests.get(json_url, timeout=30)
        resp.raise_for_status()
        d = resp.json()
        return {p["中名"]: p.get("carbon_params", {}) for p in d["plants"]}
    except Exception as e:
        print("[warn] 未加载到 plant_core_1143种_v2.1.json：", e)
        return {}

PARAMS = load_params()

def match_params(name):
    """精确→子串→通配，返回 (params, matched_flag)；未收录返回 (None, "未收录")，不编假数字。"""
    if name in PARAMS and PARAMS[name]:
        return PARAMS[name], "精确匹配"
    for k, v in PARAMS.items():
        if v and (k in name or name in k):
            return v, "子串匹配:"+k
    return None, "未收录"

def is_herb(params):
    """草本/水生强校验：carbon_params 仅含 note（草本不适用乔木公式）即判定草本；
    或显式 applicable=false（如兰科地生兰春兰）标注不参与乔木碳汇核算，须自动跳过。
    对应'标签/生境'信号，草本/水生植物禁用乔木异速生长公式。"""
    if not isinstance(params, dict):
        return False
    if params.get("applicable") is False:
        return True
    return list(params.keys()) == ["note"] or "草本不适用乔木公式" in str(params.get("note", ""))

def spec_for(city):
    """返回 (规范编号, 规范名称)。
    城市名归一：去「市/省/自治区/特别行政区/辖区」后缀 + 常见拼音别名映射，
    避免因『北京市』『beijing』等写法不同漏匹配规范（V2.1.0 压力测试增强）。"""
    if not city:
        return NATIONWIDE
    c = str(city).strip()
    norm = c.rstrip("市辖区").rstrip("市").rstrip("省").rstrip("自治区").rstrip("特别行政区")
    if norm in CITY_SPEC:
        return CITY_SPEC[norm]
    low = c.lower()
    pin = {"beijing": "北京", "shanghai": "上海", "shenzhen": "深圳",
           "chengdu": "成都", "sichuan": "四川"}
    if low in pin and pin[low] in CITY_SPEC:
        return CITY_SPEC[pin[low]]
    if c in CITY_SPEC:
        return CITY_SPEC[c]
    return NATIONWIDE

def calc_one(dbh_cm, h_m, count, params):
    dbh_m = dbh_cm / 100.0
    stem_vol = (math.pi/4.0) * (dbh_m**2) * h_m * FORM          # m^3
    biomass_t = stem_vol * params["wood_density"] * params["biomass_factor"]
    carbon_t = biomass_t * params["carbon_content"]
    unit_kg = carbon_t * 1000.0
    total_t = carbon_t * count
    return round(unit_kg, 2), round(total_t, 4)

def process(input_xlsx, output_xlsx):
    wb = load_workbook(input_xlsx)
    ws = wb.active
    header = [c.value for c in ws[1]]
    col = {str(h).strip(): i for i, h in enumerate(header) if h}
    idx_name = col.get("树种"); idx_dbh = col.get("胸径(cm)"); idx_h = col.get("树高(m)"); idx_n = col.get("数量")
    if None in (idx_name, idx_dbh, idx_h, idx_n):
        raise SystemExit("表头需含：树种 / 胸径(cm) / 树高(m) / 数量（当前：%s）" % header)
    idx_city = col.get("城市")  # 可选列
    if idx_city is None:
        print("[info] " + NO_CITY_MSG)
    # 新增输出列
    ws.cell(row=1, column=ws.max_column+1, value="单株碳储量(kg)")
    ws.cell(row=1, column=ws.max_column+1, value="总碳储量(t)")
    ws.cell(row=1, column=ws.max_column+1, value="所用规范")
    ws.cell(row=1, column=ws.max_column+1, value="参数来源/匹配")
    c_unit = ws.max_column-3; c_total = ws.max_column-2; c_spec = ws.max_column-1; c_src = ws.max_column
    for r in range(2, ws.max_row+1):
        name = ws.cell(row=r, column=idx_name+1).value
        dbh = ws.cell(row=r, column=idx_dbh+1).value
        h = ws.cell(row=r, column=idx_h+1).value
        n = ws.cell(row=r, column=idx_n+1).value
        city = ws.cell(row=r, column=idx_city+1).value if idx_city is not None else None
        if not all([name, h, n]):
            continue
        try:
            dbh=float(dbh) if dbh not in (None,"") else 0.0
            h=float(h); n=float(n)
        except Exception:
            continue
        # 草本/低矮植物（胸径≈0）不适用乔木异速生长公式
        if dbh <= 0:
            ws.cell(row=r, column=c_unit, value="—")
            ws.cell(row=r, column=c_total, value="—")
            ws.cell(row=r, column=c_spec, value="—")
            ws.cell(row=r, column=c_src, value="草本/低矮植物，乔木胸径公式不适用")
            continue
        params, flag = match_params(str(name))
        # V2.2.0：未收录物种不编假数字，直接标注"未收录"
        if params is None:
            ws.cell(row=r, column=c_unit, value="未收录")
            ws.cell(row=r, column=c_total, value="未收录")
            ws.cell(row=r, column=c_spec, value="—")
            ws.cell(row=r, column=c_src, value="物种未收录，不估算碳储量")
            continue
        # 草本/水生强校验：标签/生境/身高三重判定
        if is_herb(params):
            ws.cell(row=r, column=c_unit, value="—")
            ws.cell(row=r, column=c_total, value="—")
            ws.cell(row=r, column=c_spec, value="—")
            ws.cell(row=r, column=c_src, value="草本/水生植物（标签判定），乔木胸径公式不适用，已自动跳过")
            continue
        if h < 0.5 and dbh <= 0:
            ws.cell(row=r, column=c_unit, value="—")
            ws.cell(row=r, column=c_total, value="—")
            ws.cell(row=r, column=c_spec, value="—")
            ws.cell(row=r, column=c_src, value="身高<0.5m 且无胸径，判定低矮/草本，乔木公式不适用")
            continue
        unit, total = calc_one(dbh, h, n, params)
        code, sname = spec_for(city)
        ws.cell(row=r, column=c_unit, value=unit)
        ws.cell(row=r, column=c_total, value=total)
        ws.cell(row=r, column=c_spec, value="%s %s" % (code, sname) if code!="全国通用" else "参考全国通用参数（蒋有绪）")
        ws.cell(row=r, column=c_src, value=params.get("ref_source","")[:30]+" | "+flag)
    end = ws.max_row + 2
    ws.cell(row=end, column=1, value="⚠️ "+DISCLAIMER)
    wb.save(output_xlsx)
    print("已生成：", output_xlsx)

def make_sample(path):
    wb = Workbook(); ws = wb.active
    ws.append(["树种","胸径(cm)","树高(m)","数量","城市"])
    sample = [("香樟",15,8,20,"北京"),("悬铃木",20,10,10,"上海"),("银杏",18,9,15,"深圳")]
    for row in sample: ws.append(list(row))
    wb.save(path)
    return path

if __name__ == "__main__":
    if len(sys.argv) >= 2:
        inp = sys.argv[1]
        out = sys.argv[2] if len(sys.argv) >= 3 else "carbon_result.xlsx"
    else:
        inp = os.path.join(HERE, "sample_input.xlsx")
        make_sample(inp)
        out = os.path.join(HERE, "carbon_result.xlsx")
        print("[demo] 已生成示例输入：", inp)
    process(inp, out)
    print("[done] 碳汇速算完成。", DISCLAIMER)
