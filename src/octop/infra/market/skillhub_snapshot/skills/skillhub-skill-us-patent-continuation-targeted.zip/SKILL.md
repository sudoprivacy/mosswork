---
name: skillhub-skill-us-patent-continuation-targeted
description: "Draft continuation claims targeting a specific competitor product. Use when the user wants to write continuation claims aimed at a particular product or company. 针对特定竞品起草延续案权利要求，只使用说明书原文词汇，并满足 35 U.S.C. 112 书面描述要求。"
---

# Continuation Claims - Targeted

Draft targeted continuation claims designed to cover a specific competitor product, using only vocabulary found verbatim in the patent specification and ensuring full written description support under 35 U.S.C. 112.

This skill benefits from **web search** to gather product details.

## Instructions

1. Read the instruction file at `${CLAUDE_SKILL_DIR}/references/prompt.md`
2. Ask the user for the required inputs if not already provided via `$ARGUMENTS`:
   - **Patent specification**
   - **Existing patent claims**
   - **Target product description**
   - **Web search results** (optional, or use web search tool if available)
3. Fill in the `{{PLACEHOLDER}}` values with the user's content
4. If web search is available, search for target product technical details
5. Execute the prompt to draft the claims
6. Present the output to the user

## Inputs

| Placeholder | What to put here |
|---|---|
| `{{PATENT_SPECIFICATION}}` | The full detailed description section of the patent specification |
| `{{CURRENT_CLAIMS}}` | The current claims of the patent (all claims, independent and dependent) |
| `{{COMPETITOR_PRODUCT_DESCRIPTION}}` | A description of the competitor product you want the claims to cover. Include technical details, features, and how it works. More detail yields better results. |
| `{{FAMILY_CLAIMS}}` | (Optional) Claims from related patents in the same family, to avoid overlap. Remove this section if not applicable. |
| `{{WEB_SEARCH_RESULTS}}` | Results from web searches about the competitor product (e.g., technical documentation, product pages, architecture details, API docs). If your LLM has built-in web search, you can leave this placeholder empty and instruct the model to search. |

## Attribution

Adapted from **arcprime-ip/patent-prompts** (MIT License) by ArcPrime — <https://github.com/arcprime-ip/patent-prompts>.
Original prompt text is reproduced with the license notice retained. Modifications: repackaged into a
standalone skill with `references/prompt.md`, bilingual description, and SkillHub metadata.

> This skill produces an analytical aid, not legal advice. Always have a qualified patent
> professional review any output before relying on it.

## Scope

Written for **US patent practice** — USPTO filing and prosecution, 35 U.S.C. §§ 101/102/103/112,
Alice/Mayo eligibility, Graham/KSR obviousness. For CNIPA or EPO practice, the statutory
frameworks differ and the analysis must be adapted.
