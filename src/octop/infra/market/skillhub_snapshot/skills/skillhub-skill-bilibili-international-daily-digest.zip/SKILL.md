---
name: skillhub-skill-bilibili-international-daily-digest
description: "B站国际每日摘要。抓取B站全球内容（多语言过滤），提取字幕转写并生成中英双语摘要卡片，站内推送。触发词：B站国际摘要、Bilibili digest、全球B站动态、B站多语言内容、Bilibili daily、B站海外内容。"
---

# B站国际每日摘要（全球版）

抓取B站全球范围的最新视频，支持多语言过滤（中文、英文、日文、韩文等），提取字幕转写，生成中英双语摘要卡片，站内推送。

## 依赖技能

本技能依赖以下已安装的 Skill：
- `bilibili-universal` — 抓取热门视频、关键词搜索、UP主更新
- `bilibili-video-summary`（bili-summary）— 视频字幕转写与摘要提取

请先安装这两个技能：
```bash
npx clawhub@latest install bilibili-universal
npx clawhub@latest install bilibili-video-summary
```

## 快速开始

### 模式一：全球热门视频

```text
帮我看看B站今天全球热门视频，过滤英文和日文内容，生成双语摘要。
```

### 模式二：多语言关键词监控

```text
每天搜索B站关于"artificial intelligence"和"AI"的最新视频，过滤非中英文内容，生成摘要。
```

### 模式三：特定区域UP主追踪

```text
追踪这些海外UP主的最新视频：
- 英文区：Kurzgesagt、Vsauce
- 日文区：まねきち

每天拉取他们最近发布的视频，生成中英双语摘要。
```

## 执行流程

### 第一步：环境检查

运行环境检查脚本：
```bash
python scripts/check_environment.py
```

- 返回 `ready` → 继续
- 返回 `needs_setup` → 按提示安装缺失依赖
- 返回 `partial` → 继续可用功能，标注降级项

### 第二步：抓取视频列表

**热门排行榜：**
```bash
export SKILL=<bilibili-universal路径>
.venv/bin/python $SKILL/bili-harvest.py hot --limit 15 --since <昨日日期>
```

**关键词搜索（支持多语言）：**
```bash
# 英文搜索
python3 $SKILL/bili-fetch.py search "AI artificial intelligence" --order pubdate --pages 2
# 日文搜索
python3 $SKILL/bili-fetch.py search "AI 人工知能" --order pubdate --pages 2
```

**UP主主页：**
```bash
python3 $SKILL/bili-fetch.py user <mid> --videos 20 --since <昨日日期>
```

### 第三步：字幕转写与摘要

对每个新视频调用 `bili-summary` 提取字幕并生成摘要：
```bash
cd <bilibili-video-summary路径>
python bili-transcript.py "<视频URL>"
cat ./bili-output/transcript.txt
```

### 第四步：生成双语摘要卡片

为每个视频生成如下格式的摘要卡片：

```markdown
## 今日B站国际摘要 — <日期>

### 1. <视频标题> / <English Title>
- **UP主**：@<用户名>
- **地区**：中国大陆 / 香港 / 台湾 / 日本 / 海外
- **语言**：中文 / English / 日本語
- **播放量**：<数字> | **弹幕数**：<数字> | **时长**：<MM:SS>
- **发布时间**：<YYYY-MM-DD>
- **核心要点（中文）**：
  - 要点1
  - 要点2
  - 要点3
- **Key Points (English)**：
  - Point 1
  - Point 2
  - Point 3
- **链接**：https://www.bilibili.com/video/<BV号>
```

### 第五步：站内推送

将摘要卡片直接输出到对话中，供用户查看。

## 配置说明

### 视频数量控制

| 参数 | 默认值 | 说明 |
|------|--------|------|
| 热门视频数 | 15条 | 最多展示15条热门 |
| 关键词搜索结果 | 20条 | 每语言最多2页 |
| UP主视频数 | 20条 | 每个UP主最多20条 |
| 最小播放量 | 5000 | 过滤低播放量内容 |

### 时间范围

- `--since` 参数使用格式 `YYYY-MM-DD`
- 推荐设为昨天日期，避免重复抓取的边界问题
- 首次运行时不指定，抓取最近7天

## 降级策略

| 功能 | 失败条件 | 降级方式 |
|------|----------|----------|
| 多语言搜索 | 非中文关键词搜索失败 | 回退到中文搜索相同主题 |
| 字幕转写 | 无CC字幕且无GPU | 仅使用视频标题+简介生成摘要 |
| 弹幕抓取 | .venv未安装bilibili-api | 跳过弹幕，仅抓取评论 |
| 单视频处理 | API超时 | 跳过该视频，继续处理其他视频 |
| 语言识别 | 无法判断视频语言 | 标记为"未知语言"，保留在结果中 |

## 国际化 Gotchas

1. **B站搜索接口偶发风控**：`code=-352` 时换 `--order` 参数重试，或等10分钟
2. **UP主空间SPA首次不渲染**：脚本已自动 reload+sleep，无需手动处理
3. **评论接口IP频控**：默认sleep 0.5s，大批量抓取建议轮换IP
4. **字幕优先顺序**：CC字幕 > GPU转写 > 仅标题简介，无字幕时降级为纯文本摘要
5. **BV号与aid转换**：`video` 接口需要aid但用户提供bvid，脚本自动转换
6. **跨区内容限制**：部分日本/韩国UP主内容可能需要特定区域访问权限
7. **多语言字幕**：同一视频可能有多个字幕语言，默认取第一个可用的字幕

## 输出验收标准

- [ ] 每个视频有标题（原文+翻译）、UP主、地区、语言标签
- [ ] 核心要点同时提供中文和英文版本
- [ ] 播放量、弹幕数、时长完整
- [ ] 链接可点击跳转
- [ ] 无重复视频（按BV号去重）
- [ ] 站内推送格式清晰可读

## 停止条件

- 所有视频处理完成，输出双语摘要卡片
- 遇到不可恢复的风控错误（连续3次失败），停止并提示用户稍后重试
- 用户要求中止时立即停止
