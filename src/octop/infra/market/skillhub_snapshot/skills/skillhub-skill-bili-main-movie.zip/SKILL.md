---
name: skillhub-skill-bili-main-movie
description: "当用户想按 B 站「电影」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：电影、B站分区、rid 23。"
---

# B 站分区 · 电影

- 一级分区 rid：`23`；网页路由：`/v/movie/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 62 条榜单条目，覆盖 3 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 国产电影 | 21 | 4 | — |
| 日本电影 | 7 | 2 | 146 |
| 欧美电影 | 34 | 1 | 145 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 国产电影

数据来源：二级分区 7 日榜，可用 4 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【破·地狱】殡仪题材港片！破心魔，解生死！ | 哔哩哔哩电影 | [BV13qZbYWE8t](https://www.bilibili.com/video/BV13qZbYWE8t) | 923.3 万 |
| 【破·地狱】普通话 | 哔哩哔哩电影 | [BV13qZbYWE8Y](https://www.bilibili.com/video/BV13qZbYWE8Y) | 301.1 万 |
| 【多想和你再见一面】此沙何超莲演绎教科书版异地恋 | 哔哩哔哩电影 | [BV1W5RyYCEL4](https://www.bilibili.com/video/BV1W5RyYCEL4) | 58.5 万 |
| 【我想静静】萌宠奇缘！戏痴余少群撞上甜心教主王心凌 | 哔哩哔哩电影 | [BV17sZbYaE87](https://www.bilibili.com/video/BV17sZbYaE87) | 2.6 万 |

### 日本电影

数据来源：二级分区 7 日榜，可用 2 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【蓦然回首】藤本树神作改编！献给创作者的情书~ | 哔哩哔哩电影 | [BV1xUQHY3EcX](https://www.bilibili.com/video/BV1xUQHY3EcX) | 536.0 万 |
| 【蓦然回首】中文版 | 哔哩哔哩电影 | [BV1EmQiYMEHY](https://www.bilibili.com/video/BV1EmQiYMEHY) | 258.9 万 |

### 欧美电影

数据来源：二级分区 7 日榜，可用 1 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【无主之地】凯特大魔王卷入外星夺宝冒险 | 哔哩哔哩电影 | [BV1W5RyYCEmV](https://www.bilibili.com/video/BV1W5RyYCEmV) | 203.0 万 |

## 名称差异与覆盖说明

- 接口出现但分区表未列或名称不同：国产电影。
- 分区表列出但本次榜单未返回条目：其他国家, 华语电影（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=23." https://api.bilibili.com/x/web-interface/ranking/v2?rid=23&type=all. Accessed 6 Nov. 2026.
