---
name: skillhub-skill-hteam
description: "# H-Team 五角色智能协作流水线"
---

# H-Team 五角色智能协作流水线

> **H**olistic **Team** —— 从需求到交付的闭环工程。

## When to Use

- 用户提出一个模糊需求、创新想法或商业点子，需要完整落地。
- 用户说 "帮我做个产品"、"把这个需求实现"、"启动团队"、"hteam"。
- 需要系统性地产出 PRD、设计文档、技术架构、前后端代码、E2E 测试报告。
- 任何涉及 "从 0 到 1" 或 "从需求到交付" 的项目。

## When NOT to Use

- 仅需单文件修改、简单 bugfix、或纯代码审查（用 `feature-dev` 或 `code-review`）。
- 无明确需求方向的纯头脑风暴（先让用户收敛需求）。

---

## Phase 0: 初始化与项目锁定

### 0.1 创建 `.hteam/` 骨架

如果项目根目录不存在 `.hteam/`，立即执行以下初始化：

```bash
#!/bin/bash
# hteam-init —— H-Team 项目初始化脚本
set -euo pipefail

ROOT="${1:-.}"
HT="$ROOT/.hteam"

mkdir -p "$HT"/{config,01-requirements,02-product,03-design,04-technical,05-development/{frontend,backend},06-testing/e2e}

cat > "$HT/config/team.yml" << 'YAML'
hteam:
  version: 1.0.0
  created_at: $(date -u +%Y-%m-%dT%H:%M:%SZ)
  status: initialized
  roles:
    - ra
    - pm
    - uiux
    - fs
    - qa
  stack:
    frontend:
      primary: ReactNative | Vue3
      state: Zustand | Pinia | Redux Toolkit
      style: TailwindCSS | StyledComponents
      router: ReactNavigation | VueRouter
    backend:
      primary: NestJS
      alternate:
        - Java Spring Boot
        - Python FastAPI
      orm: Prisma | TypeORM | Drizzle
      db: PostgreSQL | MySQL
    test:
      e2e: Playwright | Detox | Cypress
      unit: Vitest | Jest | Pytest
YAML

cat > "$HT/status.json" << 'JSON'
{
  "version": "1.0.0",
  "current_phase": "00-initialized",
  "locked": false,
  "roles": {
    "ra": { "status": "pending", "artifact": null, "signoff": false },
    "pm": { "status": "pending", "artifact": null, "signoff": false },
    "uiux": { "status": "pending", "artifact": null, "signoff": false },
    "fs": { "status": "pending", "artifact": null, "signoff": false },
    "qa": { "status": "pending", "artifact": null, "signoff": false }
  },
  "quality_gates": {
    "ra_to_pm": false,
    "pm_to_uiux": false,
    "uiux_to_fs": false,
    "fs_to_qa": false,
    "qa_release": false
  }
}
JSON

echo "✅ H-Team initialized at $HT"
```

> **执行方式**：直接在项目根目录运行上述 bash 代码块（通过 Bash 工具），或要求用户运行后确认。

### 0.2 需求捕获（用户输入）

在正式开始流水线前，向用户收集以下信息（必须项打钩，可选项星星）：

- [ ] **项目一句话描述**（电梯演讲）
- [ ] **目标用户画像**（B端/C端、行业、规模）
- [ ] **核心痛点 / 价值主张**
- [ ] **MVP 范围**（最小可用集，防止镀金）
- [ ] **技术偏好**（是否强制 React Native / Vue3 / NestJS？）
- [ ] **合规约束**（等保、GDPR、金融级？）
- [ ] **时间预期**（倒排 or 敏捷迭代？）
- [ ] **现有资产**（设计稿、API、数据库、旧代码？）

将结果写入 `.hteam/01-requirements/raw.md`。

---

## Phase 1: 需求分析师 (RA — Requirements Analyst)

### 职责
将模糊需求、创新点、抽象概念转化为**结构化、可度量、可验证**的需求资产。

### 执行方式
以独立 Agent 方式运行（`subagent_type: general-purpose`），prompt 如下：

```text
你是 H-Team 的需求分析师（RA）。你的任务是对以下原始需求进行深度分析，
输出一份《需求分析报告》。

原始需求：
{{.hteam/01-requirements/raw.md 的内容}}

分析维度（必须覆盖）：
1. 商业背景与目标（OKR 对齐）
2. 用户画像与场景地图（Persona + Journey Map）
3. 功能需求（Functional Requirements）—— 按 MoSCoW 分级
4. 非功能需求（NFR）—— 性能、安全、可用性、扩展性、合规
5. 风险与假设（Risk & Assumption Register）
6. 依赖与外部系统（Integration Matrix）
7. 数据实体初步识别（Entity Brainstorm）
8. 验收标准（Acceptance Criteria，Given-When-Then 格式）

约束：
- 禁止使用模糊形容词（"快速"、"友好"），必须量化（"首屏 < 1.5s"、"错误率 < 0.1%"）。
- 每个功能点必须映射到至少一个验收标准。
- 如果需求存在自相矛盾或无法落地之处，必须显式标红并提出澄清建议。

输出格式：Markdown，写入 .hteam/01-requirements/analysis.md
开头使用 YAML frontmatter：
---
role: ra
phase: 01-requirements
status: draft
reviewed: false
---
```

### 质量门禁（RA → PM）

`ra` 标记为 `completed` 前必须满足：
- [ ] `analysis.md` 文件存在且字数 > 1500 字。
- [ ] 包含至少 3 个用户场景地图。
- [ ] 所有功能需求使用 MoSCoW 分级。
- [ ] 所有 NFR 包含可度量指标。
- [ ] 无未解决的自相矛盾（若有，必须写入 `blockers` 列表）。

通过后将 `status.json` 中 `quality_gates.ra_to_pm` 设为 `true`。

---

## Phase 2: 产品经理 (PM — Product Manager)

### 职责
基于 RA 的分析报告，产出**产品需求文档（PRD）**与**迭代路线图**，并给出功能优先级与版本规划。

### 执行方式
以独立 Agent 运行，prompt 如下：

```text
你是 H-Team 的产品经理（PM）。你接收 RA 的《需求分析报告》，
产出两份核心文档：PRD 与 Roadmap。

输入：.hteam/01-requirements/analysis.md
输出：
1. .hteam/02-product/prd.md
2. .hteam/02-product/roadmap.md

PRD 必须包含：
1. 文档元信息（版本、作者、日期、变更日志）
2. 背景与目标（引用 RA 结论）
3. 功能架构图（用 Mermaid 语法描述）
4. 功能详述（每个功能：编号、名称、描述、用户故事、 acceptance criteria、优先级、预估故事点）
5. 权限矩阵（RBAC 表：角色 × 功能）
6. 页面/模块清单（Page Inventory）
7. 核心业务逻辑流程（Mermaid 流程图）
8. 数据埋点计划（Event Tracking）
9. 反需求（Explicit Non-Goals）—— 明确不做哪些事，防止范围蔓延
10. 附录：术语表、参考链接

Roadmap 必须包含：
1. 里程碑划分（MVP / V1.0 / V1.1 / V2.0）
2. 每个里程碑的交付物、成功指标、时间估算
3. 依赖甘特图（Mermaid gantt）

设计原则：
- 每个功能必须可追溯到 RA 的某个验收标准。
- 使用表格呈现复杂信息，拒绝大段无结构文本。
- 反需求列表必须与 MVP 范围同等详细。
```

### 质量门禁（PM → UI/UX）

- [ ] `prd.md` 存在，且包含 Mermaid 图 ≥ 2 张。
- [ ] 功能详述中每个功能都有 acceptance criteria（G-W-T）。
- [ ] 页面清单覆盖所有 PM 声明的页面，且每个页面有路由/路径建议。
- [ ] `roadmap.md` 的 gantt 图语法正确（可用 Mermaid 渲染）。

---

## Phase 3: UI/UE 设计师 (UI/UX)

### 职责
基于 PRD 进行**视觉风格定义**、**交互设计**、**设计令牌（Design Tokens）**输出。

### 执行方式
以独立 Agent 运行，prompt：

```text
你是 H-Team 的 UI/UE 设计师。你接收 PM 的 PRD，产出设计规范文档。

输入：.hteam/02-product/prd.md
输出：
1. .hteam/03-design/ui-spec.md        —— 视觉规范
2. .hteam/03-design/interaction.md    —— 交互文档
3. .hteam/03-design/design-tokens.md —— 设计令牌

ui-spec.md 必须包含：
1. 设计语言（Design Language）：理念、情绪板关键词、参考产品
2. 色彩系统：
   - Primary / Secondary / Error / Warning / Success / Info
   - 每种颜色给出 Hex、RGB、HSL、使用场景
   - 深色模式映射表
3. 字体系统：
   - 字体家族（中文 + 西文）
   - 字号阶梯（Display / H1-H6 / Body / Caption / Overline），含 line-height、letter-spacing、weight
4. 间距系统：4px / 8px 基网格，间距令牌表
5. 圆角与阴影：令牌表
6. 图标规范：风格（线性/面性）、描边、端点、尺寸阶梯
7. 布局栅格：移动端 375/414/768，桌面端 1440，列数、水槽、边距
8. 组件清单（Component Inventory）：
   对每个组件给出：名称、用途、变体、状态（default/hover/disabled/loading/error）、
   包含的 Design Tokens、对应的前端实现建议（React Native / Vue3 组件名）
9. 页面级线框描述（Wireframe Description）：
   对 PRD 中每个页面，用文字 + ASCII/文本框图描述布局结构、信息层级、操作热区。
   （因为无法出真实图片，所以用精确的文字坐标式描述：顶部栏 56px、内容区 safe-area 等）

interaction.md 必须包含：
1. 全局交互原则（手势、返回、键盘、焦点管理）
2. 页面转场定义（Transition Matrix）
3. 微交互清单（Micro-interactions）：加载、空态、错误、成功反馈
4. 表单交互规范：校验时机、错误提示方式、自动保存策略
5. 可访问性要求（WCAG 2.1 AA 或更高）
6. 动效参数：持续时间（ms）、缓动曲线（cubic-bezier）、性能约束（仅 transform/opacity）

design-tokens.md 必须包含机器可读的 YAML/JSON 块：
- colors
- typography
- spacing
- shadows
- borders
- z-index
- motion

约束：
- 所有尺寸使用 dp / px / rem，拒绝模糊描述。
- 每个交互必须给出触发条件、前置状态、后置状态、异常分支。
- 如果 PRD 中存在交互歧义，必须标注并提出设计决策建议。
```

### 质量门禁（UI/UX → FS）

- [ ] `design-tokens.md` 包含有效的 YAML/JSON 代码块。
- [ ] 组件清单覆盖 PRD 中 90% 以上的 UI 元素。
- [ ] 每个页面有线框描述。
- [ ] 色彩系统通过 WCAG 对比度检查（给出 AA/AAA 评级）。

---

## Phase 4: 全栈开发工程师 (FS — Full-Stack)

### 职责
技术架构设计、API 规范、前后端代码实现。技术能力对标 **P10**。

### 技术栈锁定（不可随意更改）

| 层级 | 首选 | 备选（需用户显式批准） |
|------|------|------------------------|
| 前端框架 | React Native (Expo) 或 Vue3 (Vite) | Flutter / Next.js |
| 状态管理 | Zustand (RN) / Pinia (Vue) | Redux Toolkit / Jotai |
| 样式 | NativeWind (RN) / TailwindCSS (Vue) | StyledComponents / UnoCSS |
| 后端框架 | NestJS (Node) | Java Spring Boot / Python FastAPI |
| ORM | Prisma | TypeORM / Drizzle |
| 数据库 | PostgreSQL | MySQL 8+ |
| API 风格 | REST + OpenAPI 3.1 | tRPC（仅限全 TypeScript 栈） |
| 认证 | JWT + Refresh Token + RBAC | OAuth2 / OIDC |
| 测试 | Vitest + Playwright / Detox | Jest + Cypress |
| CI/CD | GitHub Actions | GitLab CI |

### 执行方式
先启动 `code-architect` Agent 做架构，再启动 `feature-dev` 模式实现。

#### 4.1 技术架构与 API 规范 Agent

```text
你是 H-Team 的全栈架构师（FS-Architect）。基于 PRD 和设计文档，产出技术资产。

输入：.hteam/02-product/prd.md + .hteam/03-design/design-tokens.md
输出：
1. .hteam/04-technical/architecture.md
2. .hteam/04-technical/api-spec.md
3. .hteam/04-technical/stack.md

architecture.md 必须包含：
1. 技术选型决策录（ADR 格式）：每个关键技术选型给出 上下文/决策/后果/备选方案
2. C4 Model 图（Mermaid）：
   - Context：系统与外部交互
   - Container：应用、数据库、消息队列、CDN
   - Component：后端主要模块划分
3. 数据模型（ER 图 Mermaid + 详细表结构）：
   每个表：名称、用途、字段（名/类型/约束/索引/默认值/注释）、
   外键关系、软删除策略、分区策略（如需要）
4. 状态管理策略：前端全局状态、服务端状态、本地缓存、乐观更新策略
5. 安全设计：
   - 认证鉴权流程（Sequence Mermaid）
   - 敏感数据加密（传输 TLS 1.3 / 存储 AES-256-GCM）
   - 常见攻击防护（XSS、CSRF、SQLi、Rate Limiting）
6. 性能设计：
   - 接口响应时间目标（P50 < 100ms, P99 < 500ms）
   - 缓存策略（Redis 多级缓存、Cache-Aside、TTL）
   - 分页/游标/无限滚动策略
   - 图片/资源优化
7. 部署架构：Docker / K8s / Serverless 拓扑、环境划分（dev/staging/prod）、
   蓝绿/金丝雀发布策略、健康检查与优雅停机
8. 监控与可观测性：日志结构（JSON）、指标（RED/USE）、告警规则、链路追踪

api-spec.md 必须包含：
1. RESTful 资源命名规范
2. 通用请求/响应格式（Envelope、Error Code 规范、Pagination）
3. 认证方式（Header: Authorization: Bearer <token>）
4. 每个 API 端点：
   - Method + Path
   - Summary + Description
   - Tags
   - Request：Headers / Query / Body（JSON Schema）
   - Response：Status Code / Body（JSON Schema）/ Example
   - 错误码映射表
5. WebSocket / SSE / 推送机制（如有实时需求）
6. 版本化策略（URL / Header）

stack.md：机器可读的依赖锁定清单（package.json / build.gradle / requirements.txt 格式块）
```

#### 4.2 全栈实现（编码阶段）

一旦架构通过，进入编码。编码原则（P10 标准）：

1. **前端（React Native / Vue3）**
   - 使用 `feature-based` 目录结构：`src/features/{feature}/components|hooks|services|types|stores`
   - TypeScript：零 `any`，所有 API 响应必须定义 `zod` 或 `io-ts` 运行时校验模式
   - 错误边界（Error Boundary）覆盖到页面级和组件级
   - 所有用户输入在提交前经过校验，所有网络请求有 loading / error / retry 状态
   - 使用 React Query / TanStack Query 管理服务端状态（Vue 用 VueQuery）
   - UI 组件严格遵循 `.hteam/03-design/design-tokens.md`

2. **后端（NestJS）**
   - 模块化：Domain / Application / Infrastructure 分层（Clean Architecture）
   - DTO 使用 `class-validator` + `class-transformer`，所有入参自动校验
   - 统一异常过滤器，返回标准错误体 `{ code, message, details, traceId }`
   - 日志：使用 Pino，每个请求自动注入 `traceId`
   - 数据库：Prisma 迁移文件必须手写审查，复杂查询加 `EXPLAIN` 注释
   - 环境变量使用 `ConfigModule` + `.env.example`，禁止硬编码密钥

3. **接口契约**
   - 前后端共享类型（Monorepo 的 `packages/shared-types` 或 OpenAPI 生成）
   - API 变更必须同步更新 `.hteam/04-technical/api-spec.md`

### 质量门禁（FS → QA）

- [ ] `architecture.md` 包含 C4 图 ≥ 2 张。
- [ ] `api-spec.md` 覆盖 PRD 中所有服务端交互点。
- [ ] 核心功能代码已编写并通过 `tsc --noEmit` / `eslint` / `prettier --check`。
- [ ] 所有数据库变更脚本（migration）已生成并审查。
- [ ] 单元测试覆盖率 ≥ 60%（核心 service / util ≥ 80%）。
- [ ] 环境变量模板 `.env.example` 已提供。

---

## Phase 5: 测试工程师 (QA — Quality Assurance)

### 职责
制定测试策略、编写 E2E 测试用例、执行测试、出具测试报告，并驱动缺陷修复与回归。

### 执行方式

#### 5.1 测试规划 Agent

```text
你是 H-Team 的测试工程师（QA）。基于 PRD、设计文档、API 规范与代码，产出测试资产。

输入：.hteam/02-product/prd.md + .hteam/03-design/interaction.md + .hteam/04-technical/api-spec.md + 源代码
输出：
1. .hteam/06-testing/scope.md
2. .hteam/06-testing/plan.md
3. .hteam/06-testing/e2e/*.spec.ts
4. .hteam/06-testing/report.md

scope.md 必须包含：
1. 测试范围声明（In-Scope / Out-of-Scope）
2. 质量目标：缺陷密度、严重缺陷清零标准、覆盖率目标
3. 风险矩阵：高风险功能需重点标注
4. 测试类型组合：单元（开发负责）、集成、E2E、探索性、性能、安全扫描

plan.md 必须包含：
1. 测试环境拓扑（与生产环境差异声明）
2. 测试数据策略：脱敏、造数工具、数据库快照
3. E2E 用例清单（Test Case Register）：
   每个用例：ID、模块、标题、前置条件、步骤（编号）、预期结果、优先级、自动化状态、关联需求ID
4. 回归测试范围选择逻辑
5. 准入/准出标准（Entry / Exit Criteria）

e2e/*.spec.ts：
- 使用 Playwright（Web）或 Detox（RN）编写可执行测试代码。
- 每个 spec 文件对应一个业务场景或一个 PRD 用户故事。
- 必须包含：
  - 登录态前置（auth setup）
  - 页面/元素选择器基于 `data-testid`，禁止依赖 CSS class 或文本内容
  - 网络请求 mock / 等待策略（waitForResponse）
  - 截图断言（视觉回归）或关键元素可见性断言
  - 错误场景：无网络、超时、服务端 500
- 目录结构：`e2e/auth/login.spec.ts`、`e2e/order/place-order.spec.ts`

report.md 必须包含：
1. 执行摘要：通过率、阻塞问题数、严重缺陷分布
2. 缺陷清单（Defect Log）：
   每个缺陷：ID、标题、复现步骤、期望/实际、严重级、优先级、指派角色、状态、截图/日志链接
3. 风险评估：已知问题与上线决策建议（Go / No-Go / Go with Mitigation）
4. 测试度量：代码覆盖率、用例执行率、自动化率
5. 经验教训与下次改进点
```

#### 5.2 交互与闭环

QA 发现缺陷后：
1. 在 `.hteam/06-testing/report.md` 中记录缺陷。
2. 如果缺陷涉及需求理解偏差 → 将 `ra` 与 `pm` 标记为 `revisit`，触发回归。
3. 如果缺陷涉及设计实现不符 → 将 `uiux` 标记为 `revisit`。
4. 如果缺陷涉及代码实现 → 将 `fs` 标记为 `revisit`。
5. 修复后，QA 执行回归测试并更新报告状态。

### 质量门禁（QA → 发布）

- [ ] `report.md` 中无 P0/P1 未关闭缺陷。
- [ ] E2E 核心链路通过率 100%。
- [ ] 安全扫描无高危漏洞（SQLi、XSS、敏感信息泄露）。
- [ ] 性能基线通过（首屏 / TTFB / API P99）。
- [ ] 所有角色 `signoff` 为 `true`。

---

## 流水线控制脚本

以下脚本用于在 Claude Code 会话中快速流转状态。将其保存到 `.hteam/scripts/`（由 Claude 按需创建并执行）。

### 状态推进脚本

```bash
#!/bin/bash
# hteam-advance —— 手动或自动推进流水线阶段
HT=".hteam"
STATUS="$HT/status.json"

phase="$1"
role="$2"
artifact="$3"

if [ ! -f "$STATUS" ]; then
  echo "❌ status.json not found. Run hteam-init first."
  exit 1
fi

# 使用 Python 更新 JSON（保证跨平台）
python3 << PY
import json, sys
with open("$STATUS", "r+", encoding="utf-8") as f:
    data = json.load(f)
    data["current_phase"] = "$phase"
    if "$role" in data["roles"]:
        data["roles"]["$role"]["status"] = "completed"
        data["roles"]["$role"]["artifact"] = "$artifact"
        data["roles"]["$role"]["signoff"] = True
    f.seek(0)
    json.dump(data, f, indent=2, ensure_ascii=False)
    f.truncate()
print(f"✅ Advanced to $phase | $role → completed")
PY
```

### 目录健康检查脚本

```bash
#!/bin/bash
# hteam-health —— 检查 .hteam 目录结构完整性
HT=".hteam"
ERR=0

check_file() {
  if [ ! -f "$HT/$1" ]; then
    echo "❌ Missing: $HT/$1"
    ERR=1
  else
    echo "✅ Present: $HT/$1"
  fi
}

check_dir() {
  if [ ! -d "$HT/$1" ]; then
    echo "❌ Missing dir: $HT/$1"
    ERR=1
  else
    echo "✅ Present dir: $HT/$1"
  fi
}

echo "=== H-Team Health Check ==="
check_file "config/team.yml"
check_file "status.json"
check_file "01-requirements/raw.md"
check_file "01-requirements/analysis.md"
check_file "02-product/prd.md"
check_file "02-product/roadmap.md"
check_file "03-design/ui-spec.md"
check_file "03-design/interaction.md"
check_file "03-design/design-tokens.md"
check_file "04-technical/architecture.md"
check_file "04-technical/api-spec.md"
check_file "04-technical/stack.md"
check_file "06-testing/scope.md"
check_file "06-testing/plan.md"
check_file "06-testing/report.md"
check_dir "05-development/frontend"
check_dir "05-development/backend"
check_dir "06-testing/e2e"

exit $ERR
```

---

## 通用执行约束

1. **严格顺序**：RA → PM → UI/UX → FS → QA。不允许跳阶段，除非用户显式命令。
2. **单阶段单 Agent**：每个阶段启动一个独立 Agent（或并行子 Agent 用于探索/架构），主会话负责整合与推进。
3. **文档即契约**：任何角色之间的交付物必须是 `.hteam/` 中的 Markdown 文件，禁止口头传递。
4. **质量门禁**：每个阶段必须通过 Checklist 才能进入下一阶段。如果用户催促跳过，必须显式记录风险。
5. **状态持久化**：`status.json` 是单一直线来源，Claude 每次操作后必须更新它。
6. **版本化**：每次重大变更，在对应文档顶部追加变更日志（Changelog）。
7. **代码即文档**：所有代码必须自解释；复杂算法必须附设计决策注释（// ADR-003: 使用跳表优化...）。

---

## 快速启动模板（给用户的第一句话）

当用户触发 `hteam` 时，按以下话术响应：

> 🚀 **H-Team 流水线已启动**。我将带领 5 位专家（需求分析师、产品经理、UI/UE 设计师、全栈 P10 工程师、测试工程师）将您的需求完整落地。
>
> 首先，我会在项目根目录创建 `.hteam/` 工作区，并收集项目基础信息。
>
> **请用一句话描述您想做什么？**（例如：一个帮助驾考学员刷题的微信小程序）

---

## Limitations

- 本 skill 假设项目采用现代前后端分离架构。若用户要求纯静态网站、嵌入式固件、或大数据流水线，需先调整 `config/team.yml` 中的技术栈声明。
- UI/UE 阶段产出为**文字级设计规范**，不含真实图片。若需高保真设计稿，需与外部 Figma/Sketch 工作流衔接。
- E2E 测试代码由 Claude 生成，但仍需在真实环境中运行验证；Claude 不保证测试 100% 一次通过。
- 若项目涉及 AI/ML 模型训练、区块链智能合约、硬件驱动等非标准 Web/App 开发，FS 阶段的技术栈需人工校准。
