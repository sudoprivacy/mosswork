---
name: skillhub-skill-test-ext-047-10
description: "# 测试技能"
---

# 测试技能
这是一个测试技能
## 功能
- 功能1
- 功能2
- 功能3

## 使用说明
1. 步骤一
2. 步骤二
3. 步骤三

## 配置
{"key": "value"}
