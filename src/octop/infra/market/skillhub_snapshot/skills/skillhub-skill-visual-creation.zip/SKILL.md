---
name: skillhub-skill-visual-creation
description: "把一个画面想法做成视觉创作的一组成品：一张海报，以及和它同一主体、同一配色的静帧。视觉创作先排出每张画面画什么，再出海报和静帧。适合品牌视觉、系列海报和需要看起来是一套的画面。"
---

# 视觉创作

## 你会拿到

- 一份画面安排：海报画什么，每张配套静帧画什么。
- 一张海报。
- 你确认的静帧，和海报保持同一主体、同一配色、同一字形。
- 一段海报的短动态，配乐已经垫在里面。

## 怎么跑

- 海报、静帧和动态。默认。
- 只出安排。在卡上划掉画面。
- 海报和静帧。划掉动态。

要的是必须看起来像一家的一组图，再加一段能一起发的海报动态，就从这里开始。

## 范围和相邻路线

这条路线用于必须看起来像一家的一组图。带短片的商品上架图走商品素材。带口播和广告歌的活动物料走活动物料。

## 输入和默认

硬性输入是画面想法：主体，以及这一套的感觉。缺了只问这个。默认竖屏 3:4 海报、三张方形或 4:5 静帧、大约四秒的动态，以及一段器乐。字形、配色和主体在整套里保持一致。不要编造活动方案、店铺上架或审核意见。

## 黄金路径

1. 写出画面安排并展示。这段文字不收费。
2. 有参考图时用 `beatra.assets.upload` 上传。没有参考图时，海报是一次 `beatra.images.generate`，先调用 `beatra.models.list`，载荷 `{"capability": "text_to_image"}`。有参考图时，海报是一次 `beatra.images.transform`，载荷 `{"capability": "image_to_image"}`。把文件传进去。不要把参考图传给 `beatra.images.generate`。
3. 每张已确认的静帧是一次 `beatra.images.transform`，从已接受的海报出发。静帧离开了配色或主体时，一次 `beatra.images.edit`，载荷 `{"capability": "image_edit"}`。
4. 一次 `beatra.music.generate`，载荷 `{"capability": "text_to_music"}`，写出那段配乐。这些槽位在制作卡上。
5. 视频卡上，一次 `beatra.videos.animate`，载荷 `{"capability": "image_to_video"}`，从海报出发。然后一次 `beatra.videos.compose`，载荷 `{"capability": "video_compose"}`，同样列在这张视频卡上，把配乐垫进动态。用 `beatra.tasks.get` 轮询，交付这一套和 `billing.net_charged_credits`。

这个账号有的话，还能多用两个音乐工具（随包客户端的 `tools` 命令会列出 `beatra.music.edit` 和 `beatra.audio.process`）。这些步骤每一步都是一次付费调用，有自己的实时价格和 `client_request_id`：和配乐一起提出的裁剪、循环、淡入淡出、调整响度或转换格式，在制作卡上单独列一行；其他步骤各自一张卡。合成本来就会让配乐随动态一起结束，所以做视频用的短配乐不需要另外裁剪。

- `beatra.audio.process` 对一段配乐做裁剪、循环、淡入淡出、调整响度或转换格式，也能把歌曲拆成分轨，或提取人声。
- `beatra.music.edit` 修改 Beatra 做过的曲目，或为它制作额外文件（歌词时间轴、封面图、歌曲视频（MP4）、WAV 版本）。

参见音乐编辑与音频处理（references/music-editing-and-audio.md）。

## 需要确认的决定

规划和写出来的文字不收费，也不算批准。

每次付费调用之前，出示当前的制作卡并等待：

1. 做什么：用用户的话说出将要做出的东西，并说明这次是生成还是查询。
2. 积分：刚刚从模型卡读到的现价。不要沿用记得的数字。
3. 次数：每个槽位一次付费调用。制作卡可以列出海报、静帧和配乐；每个槽位有自己的 `client_request_id`。动态另等一张卡，这张卡还把合成单独列一行，写明 `video_compose` 的实时价格并带上它自己的 `client_request_id`；在这张卡之前报出的任何总价都要算上它。
4. 标识：每次调用一个新的不透明 `client_request_id`。提示词、文件、模型或控制项一变，就换一个新标识。
5. 停在这里：已经写出的文字仍然可用。
6. 余额不足：原样转达官方消息和其中的充值地址。用户说已经充值之前不要重试。

查询和生成是两张卡。已确认的图片和音乐不批准动态。所有远程 Beatra 工具只通过随包 `scripts/mcp_client.py` 调用。工具名是命令参数，JSON 参数走标准输入。不要配置、调用或使用宿主 Beatra Connector。不要使用 REST/OpenAPI 降级。

创建响应丢失时，只用逐字节相同的载荷和同一个 `client_request_id` 重试。任务标识丢失时，先调用 `beatra.tasks.list`，再调用 `beatra.tasks.get`，对照冻结的请求之后才做相同重试。只有用户要求取消时才调用 `beatra.tasks.cancel`，然后用 `beatra.tasks.get` 确认该任务。

用户问还剩多少积分时，调用 `beatra.wallet.get`。用户问扣了什么时，调用 `beatra.wallet.ledger`。

## 按任务阅读

载荷和一套做成的画面，读场景工作流（references/workflow.md）。
任务卡住、响应丢失、价格看起来不对，或静帧离开了这一家，读出错时怎么处理（references/faq.md）。
连接还没就绪时，读安装与认证（references/installation-and-auth.md）。
首次注册，读安装注册（references/installation-registration.md）。
调用在任务出现之前失败时，读随包 MCP Client 连接诊断（references/mcp-connection.md）。
任务在排队、运行或找不到时，读任务与结果（references/tasks-and-results.md）。
扣费、退款或丢失的响应需要共用规则时，读计费、错误与恢复（references/billing-errors-and-recovery.md）。
用户要停止并移除连接时，读卸载与断开（references/uninstall-and-disconnect.md）。

## 更新与安全

本 Skill 会自动更新。内置客户端每天最多一次从 Beatra 官网读取本渠道的版本信息
（中国大陆网络走 www.beatra.cn 与 cdn.beatra.cn）。有新版本时，它下载官方发布包，
逐个文件校验 SHA-256，再替换本 Skill 自己的文件；你放进这个目录的其他文件不会被
改动。替换过程中断时，下次运行会自动恢复到替换前的状态。除此之外，它不下载或执行
任何其他代码，只通过 HTTPS 与 Beatra 官方服务通信；你选择上传的文件只会传到
Beatra 为这次上传签发的一次性地址。

关闭自动更新：`python3 scripts/mcp_client.py update --auto off`。关闭后，客户端每天
最多提示一次在你安装它的商店里更新的命令。详见更新与安全（references/updates-and-security.md）。
