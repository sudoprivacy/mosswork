# Visual creation

The frame plan is free. The poster is the reference for every later still.

Upload a supplied picture and pass that artifact to `beatra.images.transform`. `beatra.images.generate` is only the poster when no reference exists.

Each still's prompt changes the crop or the scene and repeats the poster's subject, palette, and type. One `beatra.images.edit` pulls a drifted still back, then stop.

The sting is one instrumental `beatra.music.generate`. The motion is one `beatra.videos.animate` from the poster, about four seconds, no driving audio. `beatra.videos.compose` uses that one clip and the sting at `volume` 0.25, canvas `3:4` when the poster is 3:4.

## Worked set

Brief: a ceramic brand, warm clay and cream, quiet type. One 3:4 poster, three stills transformed from it (pack, table, hand), one four-second motion, one sting in the cut.
