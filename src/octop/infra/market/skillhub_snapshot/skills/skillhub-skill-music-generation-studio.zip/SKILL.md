---
name: skillhub-skill-music-generation-studio
description: "从一个主题、一句歌词、一段画面或参考音频开始，用 AI音乐生成和 AI作曲制作原创歌曲、歌词成曲、纯音乐、BGM、视频配乐、品牌音乐、广告歌、播客片头、游戏音乐和多语言歌曲。这个 AI写歌工作室会先确定曲风、情绪、结构、可唱歌词、人声和编曲方向，再使用 Suno 6 或你明确选择的其他模型生成可试听音频。适合 AI写歌词、文字生成音乐、背景音乐生成、中文歌、双语歌曲、男女对唱和参考音频改编；生成后试听演唱、发音、时长、循环点和编曲效果，再集中优化最好的版本。"
---

# 音乐生成工作室

把主题、场景、歌词片段、完整歌词、功能性音乐需求或参考录音发展成一个连贯的音乐方向；当用户需要音频时，再据此发起一次意图明确的生成请求。交付物可以是歌曲、纯音乐、BGM、配乐、广告歌、多语言作品或基于参考音频的新编曲。把歌手身份、发音、循环点、旋律延续和母带处理视为生成后需要审听的质量，而不是能够保证的属性。当这个账号有音乐工具时，时长是一项可设定的控制项（参见音乐编辑与音频处理（references/music-editing-and-audio.md））。

先锁定曲风、结构和人声或器乐路线再生成。“surprise me” 随机成曲不是本包默认。已有录音的翻唱或改编走 `ai-song-cover-studio`，礼物或场合歌走 `personalized-song-maker`，给画面用的短循环器乐走 `short-video-bgm-studio`。

硬输入是主题或歌词，加上用途。用途、曲风或人声路线为空时先收齐，不要用默认流行简报填空。

所有 Beatra 操作都只能通过随包 `scripts/mcp_client.py` 执行。不要配置或调用宿主 Beatra Connector，也不要使用 REST/OpenAPI 作为降级或回退方案。普通调用运行 `python3 scripts/mcp_client.py call <tool-name>`，并通过 stdin 传入一个 JSON 对象。本地文件只能使用下文所述的专用上传命令。仅当随包路径需要排查时，参见随包 MCP Client 连接诊断（references/mcp-connection.md）。

## 先确定创作方向

复用对话中所有已确定的选择。在安全的前提下，根据作品用途推断常规创作细节。只有缺失的信息会改变歌词、参考方向、人声或纯音乐路线、实际付费参数，或其他由用户决定且影响重大的选择时，才提问。

生成前，准备一张简洁的制作卡：

- 用途与听众；
- 标题、核心构想、情绪变化、主要曲风、速度感、乐器、结构、混音方向、结尾或循环方向，以及排除项；
- 人声或纯音乐路线；
- 作品含人声时的完整歌词、语言与语体，以及人声方向；
- 所选模型及其专属控制项；
- 涉及参考音频时的参考意图，以及应保留或改变的特征；以及
- 下一步操作会产生一次付费生成的事实。

制作纯音乐时省略歌词，并在创作方向中为对白或其他功能需求留出空间。制作人声音乐时，在生成前完成并展示重要的歌词修改。已有歌词时，先整理主歌、副歌和桥的段落标签再付费。不要把 BPM、调式或速度数字塞进风格 caption。歌词创作、创意策划、模型查询、提示词准备和评析都不需要付费音乐调用。参见意图与路线（references/intent-and-routing.md）、创作需求与风格（references/creative-brief-and-style.md）、歌词写作（references/lyrics-craft.md）和人声、语言与标签（references/vocal-language-and-tags.md）。

当需求使用某位艺人的简称来描述风格时，将其转化为可执行的曲风、年代、速度、乐器、和声、人声质感、乐句处理和混音特征。

## 选择并校验模型

本包的常规生成应设置 `model: "suno-6"`。绝不能省略模型，也不能静默使用 `auto`。每次出示制作卡之前，先用可复制的载荷调用 `beatra.models.list`：

```json
{"capability": "text_to_music"}
```

走参考音频路线时，再调用：

```json
{"capability": "reference_audio_to_music"}
```

读取所选模型条目的 `pricing`（用户未点名其他合格模型时为 `suno-6`），把积分按槽位和合计写在卡上。不要用记忆里的数字。用户另选模型或需要某个模型的专属能力时再查一次。不要静默替换模型。

时长：当这个账号有音乐工具时（随包客户端的 `tools` 命令会列出 `beatra.music.edit` 和 `beatra.audio.process`；参见音乐编辑与音频处理（references/music-editing-and-audio.md）），用户给出时长就发送 `duration_seconds`（不要与参考录音一起使用；参考引导的曲目，事后再用 `trim` 或 `loop` 调整时长）。带歌词的歌曲，`duration_seconds` 取不少于 30 秒、足够唱完歌词的值，并且不带 `duration_fit`：更短的目标或 `exact` 都会在目标处把演唱截断，所以只有用户接受丢掉结尾时，才事后用 `beatra.audio.process` 的 `trim` 裁剪。需要精确秒数的纯音乐加上 `duration_fit: "exact"`；需要更长或要循环的底乐（用不少于 30 秒的 `duration_seconds` 生成，不带 `duration_fit`；见共享参考资料）则用 `beatra.audio.process` 加长。背景音乐见创作需求与风格（references/creative-brief-and-style.md）。没有这些工具时，把时长作为方向写进提示词，不要添加时长参数。始终报告实际返回的时长。

只使用所选模型系列实际返回或文档中列出的控制项。Suno 与 MiniMax 的选项不能互换。通过模型路线（references/model-routing.md）校验准确参数，并把音乐方案（references/music-recipes.md）中的示例作为参考模式，而不是固定承诺。

## 使用参考音频

对于本地 FLAC、MP3 或 WAV 参考音频，只能运行：

```text
python3 scripts/mcp_client.py upload <path> --mime-type <type>
```

随包命令会获取并校验上传授权，逐字节上传该文件，并返回可用作 `reference_audio` 的产物。不要用宿主 HTTP、Connector、REST，或手写授权与 PUT 流程替代它。通用上传上限为 100 MB；所选音乐模型可能设置更低的文件大小或时长限制。

说明哪些特征应当保留，哪些特征应当改变。参考音频用于指导新的创作结果；生成后，应根据既定方向审听旋律、人声特征、能量、乐器和编曲。

## 只确认一次付费边界

即使是直接、规格完整的生成请求，也要先出示下面这张制作卡。批准完整制作卡即授权该次精确请求一次；不要再加第二次确认。估价、比较、歌词审阅、方向选择或“暂不生成”都不代表批准。

出示一张当前制作卡并等待：

1. 做什么 — 用用户的话说明本次生成，一次 `beatra.music.generate` 调用，外加用户随这次生成一起要求的任何后期步骤。
2. 积分 — 所选模型（默认为 `suno-6`）的实时价格（刚从 `beatra.models.list` 读到），分槽位列出并给出合计；每条后期步骤各占一行，按它的实时 `audio_process` 价格计，合计包含卡上的每一行。不要用记忆里的数字。
3. 几笔 — 这次生成一次付费调用，卡上每多一条后期步骤就再加一次。以后再改是另一个槽位。
4. 身份 — 卡片上列出的每一行各一个新的不透明 `client_request_id`。提示词、歌词、文件、模型或控制项变了就换新标识。
5. 若停在这里 — 制作卡和歌词仍然可用。
6. 若余额不足 — 原样转达官方说明和充值链接。翻译正文，保留链接。用户说已充值后才可重试。

黄金路径：先锁定结构与动态弧，写好可执行 caption 和带标签歌词，再确认一次付费请求、产出有限 take。审听后只修正需要修正的那个片段，或用音乐工具延长选定的歌曲（见“交付并审听音乐”）；不要整首自动重做。禁止自动延长或反复延长；每次调整都是一次单独确认的调用。

付费调用前，应清楚展示模型、标题、歌词或纯音乐状态、参考音频、重要控制项，以及这张卡列出的各次付费调用。仅在参数最终确定后，创建长度为 1 至 128 个字符且稳定的 `client_request_id`。对提示词、歌词、纯音乐标记、标题、模型、参考音频、模型选项，或当前及未来 MCP 生成 schema 接受的任何其他参数所做的任何修改，都构成新的付费请求，需要新的请求标识与确认。已发布的 MCP 生成 schema 之外的字段会被忽略，不会改变请求标识或任务。

让随包客户端自动执行缓存的、尽力而为且不计费的 `beatra.installations.register` 步骤。不要在创作流程中增加手动注册。

只提交一次 `beatra.music.generate`。保留返回的 `task_id`，并通过 `beatra.tasks.get` 轮询同一个任务。遵守返回的 `deadline_at`；如果未返回该值，则在主动轮询 30 分钟后停止，报告当前状态和恢复方法，并且不要重新提交。只有用户要求时，才通过 `beatra.tasks.cancel` 取消；如果取消与终态转换发生冲突，继续处理同一个任务。

如果提交结果不确定或任务 ID 丢失，使用 `beatra.tasks.list` 和匹配的音乐能力搜索近期任务。列表结果不包含完整请求：对每个可能匹配的任务调用 `beatra.tasks.get`，并将其 `task.input`、最终模型、参考音频和选项与保存的完整参数比较。只有参数完全相同的重试才能复用同一个 `client_request_id`。绝不能只因响应丢失或任务缓慢就创建新的付费任务。参见任务与结果（references/tasks-and-results.md）和计费、错误与恢复（references/billing-errors-and-recovery.md）。

## 交付并审听音乐

任务成功后，按返回顺序展示 `task.output.clips` 中的每个条目。返回内容包含标题和歌词时一并展示，并提供 `clip.audio.url`、产物 ID、时长、MIME 类型和大小。报告真实任务标识与 `billing.net_charged_credits`。当任务返回 `task.links.assets` 时，使用该准确地址管理资产；不要编造通用网址。

只有宿主确实能够播放音频时，才审听作曲、歌词、人声表现、发音、角色分配、编曲、结尾和制作效果。否则，即使仍应交付实际产物信息，也要明确说明尚未完成听感审查。保留成功的部分，并把最大的差距转化为一次聚焦且需要重新批准的步骤：重新生成一次；或者当这个账号有音乐工具时（见“选择并校验模型”），用 `beatra.music.edit` 配合 `operation: "replace_section"` 修正选定歌曲的某一部分，或配合 `operation: "extend"` 延长它。每一种都是单独的付费调用，有自己的制作卡、该步骤的实时价格和自己的 `client_request_id`；禁止自动延长或反复延长。遵循审听与迭代（references/review-and-iteration.md）。

用户问还剩多少积分时，调用 `beatra.wallet.get`。问扣了什么时，调用 `beatra.wallet.ledger`。两者只读。不要发明账户余额或充值工具。不要把 `wallet.get` 当成每次付费提交前的必做步骤。

## 按任务查阅资料

- 意图、歌词、纯音乐、多语言和参考音频路线：意图与路线（references/intent-and-routing.md）
- 创作需求、风格、歌词写作、人声方向和语言：创作需求与风格（references/creative-brief-and-style.md）、歌词写作（references/lyrics-craft.md）和人声、语言与标签（references/vocal-language-and-tags.md）
- 当前模型选择与准确参数控制：模型路线（references/model-routing.md）
- 时长、循环、修正歌曲的某一部分、延长歌曲与额外文件：音乐编辑与音频处理（references/music-editing-and-audio.md）
- 请求模式与聚焦的成品审听：音乐方案（references/music-recipes.md）和审听与迭代（references/review-and-iteration.md）
- 首次安装或授权过期：安装与授权（references/installation-and-auth.md）
- 随包命令语法与排查：随包 MCP Client 连接诊断（references/mcp-connection.md）
- 任务恢复、计费与返回结果：任务与结果（references/tasks-and-results.md）和计费、错误与恢复（references/billing-errors-and-recovery.md）
- 更新与安全：更新与安全（references/updates-and-security.md）
- 移除本包与共享凭证处理：卸载与断开连接（references/uninstall-and-disconnect.md）

## 移除

移除本包或清理凭证时，遵循卸载与断开连接（references/uninstall-and-disconnect.md）。
绝不能直接删除 `~/.beatra` 或共享凭证，因为其他 Beatra 包可能还在使用同一连接。

## 更新与安全

本 Skill 会自动更新。内置客户端每天最多一次从 Beatra 官网读取本渠道的版本信息
（中国大陆网络走 www.beatra.cn 与 cdn.beatra.cn）。有新版本时，它下载官方发布包，
逐个文件校验 SHA-256，再替换本 Skill 自己的文件；你放进这个目录的其他文件不会被
改动。替换过程中断时，下次运行会自动恢复到替换前的状态。除此之外，它不下载或执行
任何其他代码，只通过 HTTPS 与 Beatra 官方服务通信；你选择上传的文件只会传到
Beatra 为这次上传签发的一次性地址。

关闭自动更新：`python3 scripts/mcp_client.py update --auto off`。关闭后，客户端每天
最多提示一次在你安装它的商店里更新的命令。详见更新与安全（references/updates-and-security.md）。
