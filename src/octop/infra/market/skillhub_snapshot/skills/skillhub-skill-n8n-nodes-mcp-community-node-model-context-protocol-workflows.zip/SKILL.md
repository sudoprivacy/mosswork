---
name: skillhub-skill-n8n-nodes-mcp-community-node-model-context-protocol-workflows
description: "n8n-nodes-mcp 是一个真正的 n8n 社区节点，它使自托管的 n8n 实例能够连接到 Model Context Protocol 服务器。该技能涵盖了安装包、在 n8n 中配置 MCP 传输，以及在需要外部工具和结构化上下文交换的自动化工作流中使用该节点。"
---

# n8n-nodes-mcp Model Context Protocol 工作流的社区节点

n8n-nodes-mcp is a real n8n community node that lets self-hosted n8n instances connect to Model Context Protocol servers. This skill covers installing the package, configuring MCP transports inside n8n, and using the node in automation workflows that need external tools and structured context exchange.

## Prerequisites

Self-hosted n8n, npm, MCP-compatible server

## Installation

Use the upstream install or setup path that matches your environment:
- npx @modelcontextprotocol/server-example-streamable
- npx @modelcontextprotocol/server-example-sse
- npm install -g @modelcontextprotocol/server-brave-search

Requirements and caveats from upstream:
- This is an n8n community node that lets you interact with Model Context Protocol (MCP) servers in your n8n workflows.
- MCP is a protocol that enables AI models to interact with external tools and data sources in a standardized way. This node allows you to connect to MCP servers, access resources, execute tools, and use prompts.
- [![MCP Client Node Quickstart](/assets/mcp-n8n.png)](https://youtu.be/1t8DQL-jUJk)

Basic usage or getting-started notes:
- Official Quickstart Video:
- ### Community Videos
- [Is MCP the Future of N8N AI Agents? (Fully Tested!)](https://youtu.be/sb5hCcFYPIE)

- Source: https://github.com/1991513ccie-png/skills
- Extracted from upstream docs: https://raw.githubusercontent.com/nerding-io/n8n-nodes-mcp/HEAD/README.md

## Documentation

- https://docs.n8n.io/integrations/community-nodes/installation/
