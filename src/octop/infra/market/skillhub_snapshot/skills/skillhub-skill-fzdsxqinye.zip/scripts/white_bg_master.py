# -*- coding: utf-8 -*-
"""「把衣服放到白底图上」一站式工具（在 ImageGen 出白底图之后调用）

用途：把一张「背景是浅灰/近白的商品图」处理成真正的纯白底主图，并重排成电商常用尺寸。

流程：裁底部水印 -> 四边洪水填充把背景刷成纯白 255（阈值自动定，避免侵入服装）
      -> 测出服装包围盒 -> 等比居中排进 1:1 / 3:4 / 原比例画布

用法：
  python white_bg_master.py --src 生成图.png --out-dir ./out
  python white_bg_master.py --src 生成图.png --out-dir ./out --cut 120 --ratios 1.0,0.75,raw --margin 0.085

注意：
- 本脚本只处理「背景本来就是浅色」的图。原图背景是暖色室内/货架等实景时无效，
  必须先用 ImageGen 换成白底（提示词见 references/prompts.md），再跑本脚本收尾。
- 阈值自动取「边框最暗像素 - 50」，可稳定地把柔和投影也一并刷白；若服装自身有
  高光接近边框亮度，用 --threshold 手动压低到高光之下。
"""
import sys
sys.stdout.reconfigure(encoding="utf-8")
import os
import argparse
from collections import deque
from PIL import Image


def border_min_luma(im, step=4):
    px = im.load()
    w, h = im.size
    vals = []
    for x in range(0, w, step):
        vals += [min(px[x, 0]), min(px[x, h - 1])]
    for y in range(0, h, step):
        vals += [min(px[0, y]), min(px[w - 1, y])]
    return min(vals)


def whiten(im, th):
    w, h = im.size
    px = im.load()
    visited = bytearray(w * h)
    dq = deque()

    def push(x, y):
        i = y * w + x
        if not visited[i] and min(px[x, y]) >= th:
            visited[i] = 1
            dq.append((x, y))

    for x in range(w):
        push(x, 0)
        push(x, h - 1)
    for y in range(h):
        push(0, y)
        push(w - 1, y)

    while dq:
        x, y = dq.popleft()
        px[x, y] = (255, 255, 255)
        if x > 0:
            push(x - 1, y)
        if x < w - 1:
            push(x + 1, y)
        if y > 0:
            push(x, y - 1)
        if y < h - 1:
            push(x, y + 1)
    return im


def garment_box(im, th=235):
    """返回非白内容（服装本体+自身投影）的包围盒"""
    w, h = im.size
    px = im.load()
    x0, y0, x1, y1 = w, h, -1, -1
    for y in range(h):
        row = y * w
        for x in range(w):
            if min(px[x, y]) < th:
                if x < x0:
                    x0 = x
                if x > x1:
                    x1 = x
                if y < y0:
                    y0 = y
                if y > y1:
                    y1 = y
    if x1 < 0:
        raise SystemExit("未找到主体，请检查输入图")
    return x0, y0, x1, y1


def compose(sub, out, W, H, margin):
    iw, ih = int(W * (1 - 2 * margin)), int(H * (1 - 2 * margin))
    r = min(iw / sub.width, ih / sub.height)
    nw, nh = max(1, round(sub.width * r)), max(1, round(sub.height * r))
    canvas = Image.new("RGB", (W, H), (255, 255, 255))
    canvas.paste(sub.resize((nw, nh), Image.LANCZOS), ((W - nw) // 2, (H - nh) // 2))
    canvas.save(out)
    print(f"[out] {out}  {W}x{H}  主体 {nw}x{nh}  占高 {nh / H * 100:.0f}%")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--out-dir", default="./white_bg_out")
    ap.add_argument("--cut", type=int, default=120, help="裁掉底部像素(去水印)，0 表示不裁")
    ap.add_argument("--threshold", type=int, default=0, help="洪水填充亮度阈值，0=自动")
    ap.add_argument("--ratios", default="1.0,0.75,raw",
                    help="输出画布宽高比，逗号分隔；raw=保持原比例")
    ap.add_argument("--base", type=int, default=1200, help="画布短边像素")
    ap.add_argument("--margin", type=float, default=0.085, help="主体四边留白占比")
    a = ap.parse_args()

    os.makedirs(a.out_dir, exist_ok=True)
    im = Image.open(a.src).convert("RGB")
    if a.cut:
        im = im.crop((0, 0, im.width, im.height - a.cut))

    th = a.threshold or max(130, min(200, border_min_luma(im) - 50))
    whiten(im, th)
    x0, y0, x1, y1 = garment_box(im)
    pad = 8
    sub = im.crop((max(0, x0 - pad), max(0, y0 - pad),
                   min(im.width, x1 + pad), min(im.height, y1 + pad)))
    print(f"[white_bg_master] 阈值 {th}  主体盒 {x1 - x0 + 1}x{y1 - y0 + 1}")

    for r in [s.strip() for s in a.ratios.split(",") if s.strip()]:
        if r == "raw":
            compose(sub, os.path.join(a.out_dir, "白底_原比例.png"),
                    a.base, round(a.base * sub.height / sub.width), a.margin)
        else:
            ratio = float(r)
            W = a.base if ratio >= 1 else round(a.base * ratio)
            H = round(W / ratio)
            compose(sub, os.path.join(a.out_dir, f"白底_{W}x{H}.png"), W, H, a.margin)


if __name__ == "__main__":
    main()
