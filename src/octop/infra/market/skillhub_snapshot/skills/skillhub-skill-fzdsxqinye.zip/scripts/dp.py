# -*- coding: utf-8 -*-
"""服装电商详情页 · 后期处理命令行工具

子命令：
  crop    裁掉底部 AI 水印
  white   把近似白背景刷成纯白 255
  top     顶部居中标题版式（适合细节图/静物图）
  foot    衬纸页脚版式（适合模特图，页脚可盖住水印）
  corner  右上角右对齐标题版式（适合有干净墙面的模特图）
  patch   横向取材修补右下角水印（底部内容不能裁时用）
  list    标题 + 项目清单（洗护提示等）
  size    尺码表（纯代码绘制，数字零误差）

用法示例：
  python dp.py crop  --src a.png --out b.png
  python dp.py top   --src a.png --out b.png --title 领口细节 --sub "小立领一粒扣"
  python dp.py foot  --src a.png --out b.png --title 日常穿着 --cut 0
  python dp.py size  --config size.json
"""
import argparse
import json
import sys
from collections import deque

from PIL import Image, ImageDraw, ImageFilter, ImageFont

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# ---------- 字体 ----------
SONG = r"C:\Windows\Fonts\STZHONGS.TTF"     # 华文中宋：标题，中式雅致
SONG2 = r"C:\Windows\Fonts\STSONG.TTF"      # 华文宋体
KAI = r"C:\Windows\Fonts\STKAITI.TTF"       # 华文楷体：副标
MSYH = r"C:\Windows\Fonts\msyh.ttc"         # 微软雅黑：正文/数字
MSYHBD = r"C:\Windows\Fonts\msyhbd.ttc"     # 微软雅黑粗体

# ---------- 配色（中式雅致） ----------
WINE = (118, 40, 56)        # 酒红：主标题
GOLD = (172, 138, 102)      # 金：分隔线/描边
GOLD_L = (216, 196, 168)    # 浅金：细线
BROWN = (100, 82, 68)       # 深灰褐：副标
IVORY = (243, 237, 227)     # 象牙：页脚衬纸
GREY = (146, 132, 118)      # 灰：提示文字
INK = (72, 58, 48)          # 墨：正文

DEFAULT_CUT = 112           # ImageGen 1024x1536 竖图的水印高度


# ==================== 基础排版工具 ====================
def _widths(d, text, font):
    return [d.textbbox((0, 0), c, font=font)[2] - d.textbbox((0, 0), c, font=font)[0]
            for c in text]


def draw_center(d, cx, y, text, font, fill, spacing=0, stroke=0, stroke_fill=None):
    """带字间距的居中文本"""
    ws = _widths(d, text, font)
    total = sum(ws) + spacing * (len(text) - 1)
    x = cx - total / 2
    for c, cw in zip(text, ws):
        d.text((x, y), c, font=font, fill=fill,
               stroke_width=stroke, stroke_fill=stroke_fill)
        x += cw + spacing
    return total


def draw_right(d, rx, y, text, font, fill, spacing=0, stroke=0, stroke_fill=None):
    """带字间距的右对齐文本"""
    ws = _widths(d, text, font)
    total = sum(ws) + spacing * (len(text) - 1)
    x = rx - total
    for c, cw in zip(text, ws):
        d.text((x, y), c, font=font, fill=fill,
               stroke_width=stroke, stroke_fill=stroke_fill)
        x += cw + spacing
    return total


def hairline(d, cx, y, length, fill, thickness=3):
    d.rectangle([cx - length / 2, y, cx + length / 2, y + thickness], fill=fill)


def _open(src, cut=None):
    im = Image.open(src).convert("RGB")
    if cut is None:
        cut = DEFAULT_CUT
    if cut > 0:
        w, h = im.size
        im = im.crop((0, 0, w, h - cut))
    return im


# ==================== 子命令 ====================
def cmd_crop(a):
    """裁掉底部水印"""
    im = Image.open(a.src).convert("RGB")
    w, h = im.size
    im = im.crop((0, 0, w, h - a.cut))
    im.save(a.out)
    print(f"[crop] {a.src} {w}x{h} -> {a.out} {im.size}")


def cmd_white(a):
    """从四边洪水填充，把近似白背景刷成纯白 255"""
    im = Image.open(a.src).convert("RGB")
    w, h = im.size
    px = im.load()
    th = a.threshold
    visited = bytearray(w * h)
    dq = deque()

    def ok(x, y):
        r, g, b = px[x, y]
        return r >= th and g >= th and b >= th

    for x in range(w):
        for y in (0, h - 1):
            if ok(x, y) and not visited[y * w + x]:
                visited[y * w + x] = 1
                dq.append((x, y))
    for y in range(h):
        for x in (0, w - 1):
            if ok(x, y) and not visited[y * w + x]:
                visited[y * w + x] = 1
                dq.append((x, y))
    cnt = 0
    while dq:
        x, y = dq.popleft()
        px[x, y] = (255, 255, 255)
        cnt += 1
        for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= nx < w and 0 <= ny < h:
                i = ny * w + nx
                if not visited[i] and ok(nx, ny):
                    visited[i] = 1
                    dq.append((nx, ny))
    im.save(a.out)
    print(f"[white] filled {cnt} px -> {a.out}")


def cmd_top(a):
    """顶部居中标题 + 分隔线 + 副标（要求图片上方 24%~35% 是干净留白）"""
    im = _open(a.src, a.cut)
    d = ImageDraw.Draw(im)
    W = im.size[0]
    CX = W // 2
    f_t = ImageFont.truetype(SONG, a.title_size)
    col = tuple(int(x) for x in a.color.split(",")) if a.color else WINE
    draw_center(d, CX, a.title_y, a.title, f_t, col, spacing=a.title_spacing)
    hairline(d, CX, a.bar_y, a.bar_len, GOLD, 3)
    if a.sub:
        f_s = ImageFont.truetype(KAI, a.sub_size)
        draw_center(d, CX, a.sub_y, a.sub, f_s, BROWN, spacing=4)
    im.save(a.out)
    print(f"[top] -> {a.out} {im.size}")


def cmd_foot(a):
    """底部衬纸页脚：实心象牙色带 + 顶部金线，标题副标放带内。
    --cut 0 表示不裁切（页脚直接盖住水印），适合底部有裤脚/鞋子不能裁的图。"""
    im = _open(a.src, a.cut)
    d = ImageDraw.Draw(im)
    W, H = im.size
    y0 = H - a.band
    d.rectangle([0, y0, W, H], fill=IVORY)
    hairline(d, W // 2, y0, W, GOLD, 4)
    f_t = ImageFont.truetype(SONG, a.title_size)
    draw_center(d, W // 2, y0 + 40, a.title, f_t, WINE, spacing=12)
    hairline(d, W // 2, y0 + 40 + a.title_size + 26, 120, GOLD, 3)
    if a.sub:
        f_s = ImageFont.truetype(KAI, a.sub_size)
        draw_center(d, W // 2, y0 + 40 + a.title_size + 62, a.sub, f_s, BROWN, spacing=4)
    im.save(a.out)
    print(f"[foot] band={a.band} -> {a.out} {im.size}")


def cmd_corner(a):
    """右上角右对齐标题 + 象牙色描边（人物占满画面、有干净墙面时用）"""
    im = _open(a.src, a.cut)
    d = ImageDraw.Draw(im)
    W = im.size[0]
    rx = a.rx if a.rx else W - 52
    f_t = ImageFont.truetype(SONG, a.title_size)
    tw = draw_right(d, rx, a.title_y, a.title, f_t, WINE,
                    spacing=12, stroke=4, stroke_fill=(246, 241, 232))
    d.rectangle([rx - min(tw, 190), a.title_y + 82, rx, a.title_y + 85], fill=GOLD)
    if a.sub:
        f_s = ImageFont.truetype(KAI, a.sub_size)
        draw_right(d, rx, a.title_y + 106, a.sub, f_s, BROWN,
                   spacing=3, stroke=4, stroke_fill=(246, 241, 232))
    im.save(a.out)
    print(f"[corner] -> {a.out} {im.size}")


def cmd_patch(a):
    """从同一高度的左侧横向取材，羽化贴补右下角水印。"""
    im = Image.open(a.src).convert("RGB")
    W, H = im.size
    x0, y0 = a.x0, a.y0
    x1, y1 = a.right or W, a.bottom or H
    pw, ph = x1 - x0, y1 - y0
    patch = im.crop((x0 - (pw + a.gap), y0, x0 - a.gap, y1))
    mask = Image.new("L", (pw, ph), 255)
    md = ImageDraw.Draw(mask)
    F = a.feather
    for i in range(F):
        md.line([(i, 0), (i, ph)], fill=int(255 * i / F))
    for j in range(F):
        md.line([(0, j), (pw, j)], fill=int(255 * j / F))
    im.paste(patch, (x0, y0), mask.filter(ImageFilter.GaussianBlur(3)))
    im.save(a.out)
    print(f"[patch] region=({x0},{y0},{x1},{y1}) -> {a.out}")


def cmd_list(a):
    """标题 + 副标 + 项目清单（洗护提示等）。图片下半部需留干净留白。"""
    im = _open(a.src, a.cut)
    d = ImageDraw.Draw(im)
    W, H = im.size
    CX = W // 2
    f_t = ImageFont.truetype(SONG, a.title_size)
    draw_center(d, CX, a.title_y, a.title, f_t, WINE, spacing=12)
    hairline(d, CX, a.title_y + a.title_size + 20, 150, GOLD, 3)
    if a.sub:
        f_s = ImageFont.truetype(KAI, a.sub_size)
        draw_center(d, CX, a.title_y + a.title_size + 54, a.sub, f_s, BROWN, spacing=4)

    items = [s for s in a.items.split("|") if s.strip()]
    f_i = ImageFont.truetype(MSYH, a.item_size)
    BLOCK = 560
    x_dot = CX - BLOCK // 2
    x_txt = x_dot + 38
    y = a.list_y
    hairline(d, CX, y - 45, 90, GOLD, 3)
    for it in items:
        d.ellipse([x_dot, y + 15, x_dot + 11, y + 26], fill=GOLD)
        d.text((x_txt, y), it, font=f_i, fill=INK)
        y += a.line_h
    if a.note:
        f_n = ImageFont.truetype(MSYH, 21)
        draw_center(d, CX, y + 22, a.note, f_n, GREY, spacing=2)
    im.save(a.out)
    print(f"[list] {len(items)} items -> {a.out} {im.size}")


def cmd_size(a):
    """尺码表：纯代码绘制，保证数字零误差。参数从 JSON 读取。"""
    cfg = json.load(open(a.config, encoding="utf-8"))
    W, H = cfg.get("size", [1024, 1424])
    cols = cfg["columns"]
    rows = cfg["rows"]
    im = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(im)
    top, bot = (249, 245, 237), (235, 226, 212)
    for y in range(H):
        t = y / (H - 1)
        d.line([(0, y), (W, y)], fill=tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3)))
    CX = W // 2

    # 标题
    ty = cfg.get("title_y", 84)
    draw_center(d, CX, ty, cfg.get("title", "尺码参考"),
                ImageFont.truetype(SONG, cfg.get("title_size", 72)), WINE, spacing=12)
    d.rectangle([CX - 75, ty + 112, CX + 75, ty + 115], fill=GOLD)
    if cfg.get("subtitle"):
        draw_center(d, CX, ty + 144, cfg["subtitle"],
                    ImageFont.truetype(MSYH, 26), GREY, spacing=1)

    # 试穿信息条
    bar_y0 = cfg.get("bar_y", 306)
    bar_h = cfg.get("bar_h", 132)
    bar_x0, bar_x1 = cfg.get("bar_x", [92, 932])
    d.rounded_rectangle([bar_x0, bar_y0, bar_x1, bar_y0 + bar_h], radius=18,
                        fill=(252, 248, 241), outline=GOLD_L, width=2)
    pairs = [(cfg.get("try_on"), cfg.get("trial"))]
    pairs = [p for p in pairs[0] if p]
    if pairs:
        seg = (bar_x1 - bar_x0) / len(pairs)
        f_lab = ImageFont.truetype(MSYH, 24)
        f_val = ImageFont.truetype(MSYHBD, 44 if len(pairs) > 1 else 46)
        for i, p in enumerate(pairs):
            cx = int(bar_x0 + seg * (i + 0.5))
            if i:
                d.line([(int(bar_x0 + seg * i), bar_y0 + 30),
                        (int(bar_x0 + seg * i), bar_y0 + bar_h - 30)], fill=GOLD_L, width=2)
            draw_center(d, cx, bar_y0 + 24, p["label"], f_lab, GREY, spacing=2)
            draw_center(d, cx, bar_y0 + 62, p["value"], f_val, WINE, spacing=1)

    # 自动列宽
    f_th = ImageFont.truetype(MSYHBD, 28)
    f_td = ImageFont.truetype(MSYH, 33)
    widths = cfg.get("widths")
    if not widths:
        widths = []
        for j, name in enumerate(cols):
            m = d.textbbox((0, 0), name, font=f_th)[2]
            for r in rows:
                m = max(m, d.textbbox((0, 0), str(r[j]), font=f_td)[2])
            widths.append(m + 56)
        total = sum(widths)
        if total > W - 100:
            k = (W - 100) / total
            widths = [int(x * k) for x in widths]
            adj = (W - 100) - sum(widths)
            widths[1] += adj
    tw = sum(widths)
    TX0 = (W - tw) // 2
    TH, RH = cfg.get("header_h", 108), cfg.get("row_h", 112)
    TY0 = cfg.get("table_y", 530)

    d.rectangle([TX0, TY0, TX0 + tw, TY0 + TH], fill=WINE)
    x = TX0
    for j, name in enumerate(cols):
        bb = d.textbbox((0, 0), name, font=f_th)
        d.text((x + (widths[j] - (bb[2] - bb[0])) / 2, TY0 + (TH - (bb[3] - bb[1])) / 2 - bb[1]),
               name, font=f_th, fill=(250, 246, 240))
        x += widths[j]

    f_tdb = ImageFont.truetype(MSYHBD, 33)
    for i, row in enumerate(rows):
        ry = TY0 + TH + i * RH
        d.rectangle([TX0, ry, TX0 + tw, ry + RH],
                    fill=(252, 248, 241) if i % 2 == 0 else (243, 234, 222))
        x = TX0
        for j, val in enumerate(row):
            f = f_tdb if j in (0, len(cols) - 1) else f_td
            col = WINE if j == 0 else INK
            bb = d.textbbox((0, 0), str(val), font=f)
            d.text((x + (widths[j] - (bb[2] - bb[0])) / 2, ry + (RH - (bb[3] - bb[1])) / 2 - bb[1]),
                   str(val), font=f, fill=col)
            x += widths[j]
        if i < len(rows) - 1:
            d.line([(TX0, ry + RH), (TX0 + tw, ry + RH)], fill=GOLD_L, width=2)

    tb_end = TY0 + TH + len(rows) * RH
    d.rectangle([TX0, TY0, TX0 + tw, tb_end], outline=GOLD, width=3)
    x = TX0
    for j in range(len(cols) - 1):
        x += widths[j]
        d.line([(x, TY0), (x, tb_end)], fill=GOLD_L, width=2)

    if cfg.get("note"):
        draw_center(d, CX, tb_end + 58, cfg["note"], ImageFont.truetype(MSYH, 23), GREY, spacing=1)
    if cfg.get("keywords"):
        draw_center(d, CX, tb_end + 122, cfg["keywords"],
                    ImageFont.truetype(MSYH, 26), BROWN, spacing=1)

    im.save(cfg["out"])
    print(f"[size] {len(rows)} rows -> {cfg['out']} {im.size}")


# ==================== CLI ====================
def main():
    p = argparse.ArgumentParser(description="服装电商详情页后期处理工具")
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp, cut=True):
        sp.add_argument("--src", required=True)
        sp.add_argument("--out", required=True)
        if cut:
            sp.add_argument("--cut", type=int, default=DEFAULT_CUT)

    sp = sub.add_parser("crop"); common(sp)
    sp.set_defaults(f=cmd_crop)

    sp = sub.add_parser("white")
    sp.add_argument("--src", required=True); sp.add_argument("--out", required=True)
    sp.add_argument("--threshold", type=int, default=238)
    sp.set_defaults(f=cmd_white)

    sp = sub.add_parser("top"); common(sp)
    sp.add_argument("--title", required=True); sp.add_argument("--sub", default="")
    sp.add_argument("--title-size", type=int, default=84)
    sp.add_argument("--sub-size", type=int, default=36)
    sp.add_argument("--title-y", type=int, default=96)
    sp.add_argument("--bar-y", type=int, default=216)
    sp.add_argument("--bar-len", type=int, default=150)
    sp.add_argument("--sub-y", type=int, default=254)
    sp.add_argument("--title-spacing", type=int, default=14)
    sp.add_argument("--color", type=str, default="")
    sp.set_defaults(f=cmd_top)

    sp = sub.add_parser("foot"); common(sp)
    sp.add_argument("--title", required=True); sp.add_argument("--sub", default="")
    sp.add_argument("--band", type=int, default=238)
    sp.add_argument("--title-size", type=int, default=68)
    sp.add_argument("--sub-size", type=int, default=32)
    sp.set_defaults(f=cmd_foot)

    sp = sub.add_parser("corner"); common(sp)
    sp.add_argument("--title", required=True); sp.add_argument("--sub", default="")
    sp.add_argument("--title-size", type=int, default=62)
    sp.add_argument("--sub-size", type=int, default=28)
    sp.add_argument("--title-y", type=int, default=46)
    sp.add_argument("--rx", type=int, default=0)
    sp.set_defaults(f=cmd_corner)

    sp = sub.add_parser("patch")
    sp.add_argument("--src", required=True); sp.add_argument("--out", required=True)
    sp.add_argument("--x0", type=int, required=True); sp.add_argument("--y0", type=int, required=True)
    sp.add_argument("--right", type=int, default=0); sp.add_argument("--bottom", type=int, default=0)
    sp.add_argument("--gap", type=int, default=12); sp.add_argument("--feather", type=int, default=12)
    sp.set_defaults(f=cmd_patch)

    sp = sub.add_parser("list"); common(sp)
    sp.add_argument("--title", required=True); sp.add_argument("--sub", default="")
    sp.add_argument("--items", required=True, help="用 | 分隔")
    sp.add_argument("--note", default="")
    sp.add_argument("--title-size", type=int, default=72)
    sp.add_argument("--sub-size", type=int, default=32)
    sp.add_argument("--item-size", type=int, default=33)
    sp.add_argument("--title-y", type=int, default=64)
    sp.add_argument("--list-y", type=int, default=1040)
    sp.add_argument("--line-h", type=int, default=54)
    sp.set_defaults(f=cmd_list)

    sp = sub.add_parser("size")
    sp.add_argument("--config", required=True)
    sp.set_defaults(f=cmd_size)

    args = p.parse_args()
    args.f(args)


if __name__ == "__main__":
    main()
