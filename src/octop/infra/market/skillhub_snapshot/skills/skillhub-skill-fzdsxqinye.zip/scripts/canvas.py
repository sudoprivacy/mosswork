# -*- coding: utf-8 -*-
"""把图片放到纯白底画布上（等比缩放 + 居中留白）
用法:
  python white_canvas.py <图片路径> [输出路径] [--size 1200] [--ratio 1.0]
"""
import sys
sys.stdout.reconfigure(encoding="utf-8")
import argparse
from PIL import Image


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("out", nargs="?", default=None)
    ap.add_argument("--size", type=int, default=1200, help="画布短边像素")
    ap.add_argument("--ratio", type=float, default=1.0, help="画布宽高比 宽/高")
    ap.add_argument("--margin", type=float, default=0.09, help="四边留白占比")
    a = ap.parse_args()

    im = Image.open(a.src).convert("RGB")
    w = a.size
    h = int(round(w / a.ratio))
    inner_w = int(w * (1 - 2 * a.margin))
    inner_h = int(h * (1 - 2 * a.margin))

    r = min(inner_w / im.width, inner_h / im.height)
    nw, nh = max(1, int(im.width * r)), max(1, int(im.height * r))
    im2 = im.resize((nw, nh), Image.LANCZOS)

    canvas = Image.new("RGB", (w, h), (255, 255, 255))
    canvas.paste(im2, ((w - nw) // 2, (h - nh) // 2))
    out = a.out or (a.src.rsplit(".", 1)[0] + "_白底.png")
    canvas.save(out)
    print(f"[white_canvas] {im.size} -> {canvas.size} 主体{nw}x{nh} -> {out}")


if __name__ == "__main__":
    main()
