# ImageGen 提示词模板库

> 所有出图都走 **图生图**：`image1` = 用户的服装图，`input_fidelity: "high"`，`size: "1024x1536"`，`quality: "high"`。
> `{GARMENT}` 处替换为「产品一致性声明」，见文末。

## 通用约束（每条提示词都必须带）

**背景（中式雅致，默认风格）**

```
BACKGROUND: soft warm ivory and pale tea-beige handmade xuan paper surface with a subtle
vertical gradient, a few very faint low-opacity ink-wash bamboo leaves at the frame edges only.
Clean, calm, uncluttered. No furniture, no props that overlap the garment.
```

**留白（决定后期能不能排字，最关键的一段）**

```
COMPOSITION: the garment occupies roughly the middle 55-60% of the frame height, centred.
The upper 24% of the frame MUST stay completely clean and empty (plain ivory paper, no fabric,
no objects) so typography can be added later.
```

**光线**

```
LIGHTING: soft diffused daylight from the upper left, gentle realistic soft shadow, visible
silky satin sheen on the fabric, crisp high-detail texture, professional commercial
retouching quality.
```

**禁字（不写这段，AI 一定会画错别字）**

```
ABSOLUTELY NO TEXT of any kind: no Chinese characters, no letters, no numbers, no watermark,
no logo, no signature anywhere in the image.
```

---

## 8 张图的具体提示词

### 1. 主视觉图
> 素材：用户原图。构图：整体居中略偏下，上方留白最多。

```
Elegant e-commerce hero image, vertical 2:3. {GARMENT}
Present it as a clean ghost-mannequin product shot, front view, gently draped, centred in the
lower part of the frame, occupying 55-60% of the image height.
[通用背景] [留白 upper 35%] [光线] [禁字]
```

### 2. 整体版型图（正面 + 背面）
> 一张图里放两个视图，左右并排，同一个纸背景。

```
E-commerce detail page image, vertical 2:3. TWO ghost-mannequin views of the SAME garment
side by side on ONE continuous unified background. {GARMENT}
LEFT GARMENT: front view, exactly as in the input image.
RIGHT GARMENT: the SAME garment seen from the BACK — back of the collar (smooth, no button,
no placket), same shoulder line, same sleeves, same all-over print continuing across the back
panel, same hem. Identical scale, identical lighting, aligned at the shoulder line.
[通用背景] [留白 upper 25%] [光线] [禁字]
```

### 3. 细节图 A
- **上衣 → 领口面料**
- **裤子 → 裤腰**

```
上衣版：
E-commerce detail page macro close-up, vertical 2:3. FABRIC / CONSTRUCTION DETAIL.
Extreme close-up of the collar and neckline of the SAME garment. {GARMENT}
Focus on: the stand collar band, the button / placket closure, the keyhole notch, the soft
vertical gathers beside it, and the shoulder seam at the frame edge. The silk satin weave,
individual stitches and thread detail must be clearly visible. Very sharp focus on the collar,
shallow depth of field elsewhere. The garment fills most of the frame.
[留白 upper 24%] [光线] [禁字]

裤子版：
E-commerce detail page macro close-up, vertical 2:3. FABRIC / CONSTRUCTION DETAIL.
Extreme close-up of the WAISTBAND of the SAME trousers. {GARMENT}
Focus on: the wide waistband, the button closure and zip fly top, the belt loops with their
stitching, the waistband edge stitching and the front pleat or dart. The fabric weave,
individual stitches, the waistband interlining thickness and thread detail must be clearly
visible. Very sharp focus on the waistband, shallow depth of field elsewhere.
[留白 upper 24%] [光线] [禁字]
```

### 4. 细节图 B
- **上衣 → 袖口**
- **裤子 → 裤脚**

```
上衣版：
E-commerce detail page close-up, vertical 2:3. CONSTRUCTION DETAIL of one sleeve.
Show ONE complete sleeve seen from the side, running diagonally: the gathered shoulder /
sleeve head at the top, the flowing sleeve body in the middle, and the CUFF at the bottom
(the cuff band, its crisp stitched edge and the small slit). {GARMENT}
Real studio photograph look: visible satin weave, individual stitches along the cuff band and
shoulder seam, fabric folding softly with subtle colour gradients and a luxurious sheen.
[留白 upper 24%] [光线] [禁字]

裤子版：
E-commerce detail page close-up, vertical 2:3. CONSTRUCTION DETAIL of one leg opening.
Show the TROUSER HEM in close-up, viewing the leg from the side at a slight angle so both the
outside hem finish and the inseam are visible: the turned-and-stitched hem, the topstitching
line, and how the fabric falls and drapes at the hem. {GARMENT}
Real studio photograph look: visible fabric weave, individual hem stitches, the fabric edge
thickness, soft natural folds and drape, a subtle shadow inside the leg opening.
[留白 upper 24%] [光线] [禁字]
```

### 5. 细节图 C
- **上衣 → 面料 + 印花微距**
- **裤子 → 口袋**

```
上衣版：
E-commerce detail page macro photograph, vertical 2:3. FABRIC TEXTURE shot.
Extreme macro close-up of the fabric. The frame is filled with a gently draped swath of the
fabric showing soft natural folds. {GARMENT}
Macro requirements: the fine silk weave must be clearly visible (warp and weft threads), the
print must look ink-printed onto the fabric and follow the folds realistically, strong but soft
directional sheen where the fabric curves. Shallow depth of field: centre band tack sharp,
edges softly blurred. Must look like a real photograph, not a digital pattern fill.
[留白 upper 24%] [光线] [禁字]

裤子版：
E-commerce detail page macro close-up, vertical 2:3. POCKET CONSTRUCTION DETAIL.
Extreme close-up of the FRONT POCKET area of the SAME trousers. {GARMENT}
Focus on: the slanted pocket opening, the pocket bag edge, the bar-tack reinforcement stitches
at both ends of the pocket mouth, the topstitching line running down the side seam, and the
subtle shadow where the pocket opening sits. The fabric weave, thread detail and stitch
density must be clearly visible. Very sharp focus on the pocket mouth, shallow depth of field
elsewhere.
[留白 upper 24%] [光线] [禁字]
```

### 6. 模特穿着图（含搭配，一举两得）
> 关键：**年龄感约束必须写死**，否则 AI 会把客人画年轻。

```
Lifestyle model photograph, vertical 2:3, refined Chinese aesthetic.
THE MODEL: an elegant Chinese woman aged 52-58 with a natural, dignified, mature appearance.
Neatly styled hair with some grey strands, soft natural lines around the eyes, calm confident
expression. She must look genuinely and naturally middle-aged — NOT young, NOT heavily
retouched, NO flawless porcelain skin, no plastic or CGI look. Realistic skin texture with
pores and fine expression lines.
THE GARMENT (reproduce EXACTLY, do not change anything): {GARMENT}
She wears it with simple coordinating separates shown in full so the pairing is clear.
SCENE: a quiet refined Chinese-style tea room / sunlit courtyard. Warm wood furniture softly
blurred, a sheer linen curtain diffusing daylight, a faint ink-wash painting. Uncluttered.
FRAMING: three-quarter or full body, occupying the middle and lower 70% of the frame.
The upper 24% MUST be a calm, clean, softly out-of-focus background area for typography.
LIGHTING: soft natural window light, warm and even, 85mm lens, shallow depth of field.
[禁字]
```

### 7. 尺码参数图
> **不要用 ImageGen**。用 `dp.py size --config xxx.json` 纯代码绘制，保证数字零误差。

### 8. 洗护提示图
> 先出静物图（上半部有产品、下半部留大片干净纸面），再叠字。

```
E-commerce detail page still-life image, vertical 2:3, refined Chinese aesthetic.
SUBJECT: the SAME garment neatly FOLDED into a tidy rectangular stack, placed on a warm ivory
xuan paper surface beside a shallow dark walnut wooden tray and one small sprig of dried
flowers. {GARMENT}
*** COMPOSITION (very important) ***: the folded garment sits in the UPPER-MIDDLE area only,
roughly between the 22% and 56% lines of the frame height, horizontally centred.
The ENTIRE upper 20% MUST be clean, plain, empty ivory paper (for a title).
The ENTIRE bottom 36% MUST be clean, plain, smooth, empty ivory paper with NO objects and no
strong texture gradients (for a text list). Do not place the tray, flowers or any object there.
[光线] [禁字]
```

---

## {GARMENT} 一致性声明模板

出图前先把产品拆成要素，逐条写进每一条提示词。示例（上衣）：

```
GARMENT (take EXACTLY from the input image, do not change anything): a {主色} {材质} {品类}
with {图案描述}. Features that MUST stay identical: {领型}, {扣子数量与位置}, {开衩/门襟形式},
{袖型与袖口形式}, {下摆形式}. Same colour, same print pattern, same proportions, same fabric
sheen.
```

示例（裤子）：

```
GARMENT (take EXACTLY from the input image, do not change anything): a pair of {主色} {材质}
{裤型} trousers with {腰头形式}, {口袋形式}, {裤脚形式}. Features that MUST stay identical:
the waistband height and closure, the number and position of belt loops and pockets, the
leg shape and the hem finish. Same colour, same fabric weave, same drape and proportions.
```

**必须逐条列举的服装要素清单**

| 品类 | 必列要素 |
|---|---|
| 上衣 | 领型及领高、扣子数量与位置、开襟形式、袖型、袖口形式、下摆形式、图案与配色 |
| 裤子 | 腰头形式与高度、门襟（拉链/扣）、裤型（直筒/阔腿/锥形）、口袋数量与位置、裤脚形式、腰部是否有松紧或抽绳、图案与配色 |
