---
name: skillhub-skill-fzdsxqinye
description: "上传 1 张服装图片（上衣或裤子），先追问一轮参数，再自动产出 8 张适配抖音的电商详情页图片。用于：服装详情页、电商详情页、抖音详情页、服装主图、细节图、面料图、模特图、尺码表、洗护图，以及单图重做。上衣的细节图侧重领口与袖口的面料细节，裤子的细节图侧重裤腰、裤脚、口袋的面料细节。"
---

# 服装电商详情页

**一句话流程**：收 1 张服装图 → 追问一轮 → 生成 8 张图 → 裁水印 + 中文精准叠字 → 上传取直链交付。

---

## 零、必读：三条铁律

1. **中文文案绝不让 ImageGen 生成。** 提示词里强制写 `ABSOLUTELY NO TEXT of any kind`，并要求画面留白，文字一律用 Pillow 后期叠加。AI 写中文必出错别字/繁体，而详情页错字=投诉。
2. **尺码表、参数表绝不用 ImageGen。** 用 `dp.py size` 纯代码绘制，数字零误差。
3. **AI 出的服装图和用户原图必须逐项比对。** 颜色、图案、领型、扣子数量、口袋数量、裤型一旦漂移，只重做那一张。

---

## 一、环境（本机固定，不要试错）

| 项 | 值 |
|---|---|
| Python | `C:\Users\86151\.workbuddy\binaries\python\envs\default\Scripts\python.exe`（**必须用这个**，有 Pillow） |
| 工具脚本 | `...\skills\clothing-detail-page\scripts\dp.py`（版式/叠字/尺码表）／同目录 `canvas.py`（白底画布） |
| 提示词模板 | `C:\Users\86151\.workbuddy\skills\clothing-detail-page\references\prompts.md` |
| 中文字体 | 标题 华文中宋 `STZHONGS.TTF`／副标 华文楷体 `STKAITI.TTF`／正文 微软雅黑 `msyh.ttc` |

- `binaries\python\versions\3.13.12\python.exe` **没有 PIL**，不要用。
- `pip install numpy/scipy` 在本机会超时中断，**不要装**，需要像素运算时用纯 Python（`dp.py white` 里的 BFS 已实现）。
- 脚本里 `print` 用中文时，开头必须先 `sys.stdout.reconfigure(encoding="utf-8")`（`dp.py` 已处理）。

---

## 二、阶段一：接收素材 + 追问一轮

用户上传 1 张服装图（上衣或裤子）。**先看完图，再做判断，然后只问一轮。**

### 先做：产品身份档案

从图片里读出并逐项标记来源：

- `visual_fact` 图片可直接确认：品类、主色、图案、版型、领型/腰头、扣子与口袋数量、袖型/裤脚形式、面料光泽感
- `missing` 无法确认：**成分含量、尺码数据、克重、品牌、货号、价格、售后政策** —— 不得编造

**必须逐项列举**（后续每条出图提示词都要重复这些）：
- 上衣：领型及领高、扣子数量与位置、开襟形式、袖型、袖口形式、下摆形式、图案与配色
- 裤子：腰头形式与高度、门襟、裤型、口袋数量与位置、裤脚形式、是否松紧/抽绳、图案与配色

### 再问：一轮提问（用 AskUserQuestion，最多 4 题）

**必问的 4 题**：

1. **材质成分** —— 这题最关键。真丝／桑蚕丝／醋酸／聚酯纤维／棉／不明。决定文案能不能写"真丝"，写错是虚假宣传会被平台罚。
2. **尺码数据** —— 我来提供真实数据／用常规版型做参考表（须标"以实物为准"）／这版先不放尺码表。
3. **抖音风格** —— 中式雅致（米白宣纸+淡墨，稳重高级）／纯白极简（突出产品质感）／高饱和吸睛（红金配色+大字，抖音爆款感）／暖调家居（暖木色布艺，生活气息）。
4. **生成节奏** —— 8 张一次出完／先出前 3 张看效果（推荐，避免整批重做）。

**追问时顺手排除的坑**：
- 用户给的尺码表里出现明显不可能的值（例如"肩宽 145"），必须当场指出，按合理列名处理后列入待核验事项。
- 用户给的图只有正面 → 背面图属于推演，必须告知"建议实物补拍替换"。

**信息不足时按常见电商场景继续，不要反复追问。**

### 先判断原图是不是已经是白底图

取四角像素即可：四角都 ≈ `(255,255,255)`（或 250 以上）说明**原图本身就是干净的商品白底图**。

此时**跳过「换白底」这道工序** —— 不要再跑 ImageGen 白底提示词、也不要跑 `white_bg_master.py`，
直接把用户原图当 `image1` 出全部 8 张；提示词里写清目标背景（如中式雅致宣纸底）即可。

只有当原图背景有色或杂乱（模特实拍、货架、室内背景）时，才先走换白底那两步。

---

## 三、阶段二：规划与确认

### 固定 8 张结构（上衣/裤子通用骨架）

| # | 模块 | 上衣的细节侧重 | 裤子的细节侧重 |
|---|---|---|---|
| 1 | 主视觉图 | 整体正面，识别品类与定位 | 整体正面 |
| 2 | 整体版型图 | 正面 + 背面 | 正面 + 背面 |
| 3 | 细节图 A | **领口面料**（领型、扣、门襟、缝线） | **裤腰**（腰头、门襟、裤袢、缝线） |
| 4 | 细节图 B | **袖口面料**（袖山抽褶、袖口翻边、缝线） | **裤脚**（卷边、明线、垂坠感） |
| 5 | 细节图 C | 面料 + 印花微距 | **口袋**（口袋口、打枣、明线） |
| 6 | 模特穿着图 | 中老年模特穿着 + 搭配，全身 | 同左（穿整条裤子，露腰线与裤脚） |
| 7 | 尺码参数图 | 纯代码表格 | 纯代码表格 |
| 8 | 洗护提示图 | 折叠静物 + 护理清单 | 叠放静物 + 护理清单 |

> 细节图数量按品类自适应：上衣 3 张覆盖「领口 / 袖口 / 面料」，裤子 3 张覆盖「裤腰 / 裤脚 / 口袋」——**用户要求的细节全部落在 3、4、5 张**。

### 先出方案表，等确认

输出产品分析结论 + 逐张规划表（图片 / 模块 / 画面 / 核心卖点 / 拟用文案），并列出待确认事项，然后停下等用户确认。**用户说"跳过确认、直接生成"才可直接出图。**

---

## 四、阶段三：出图

### ImageGen 调用规范

```
image1         = 用户的服装原图（本地路径或 URL）
input_fidelity = "high"
size           = "1024x1536"
quality        = "high"
prompt         = references/prompts.md 里对应那张的模板
```

- **串行调用，一次一张**。并行可能因时间戳同秒导致文件名覆盖。
- `{GARMENT}` 处必须替换成逐条列举的产品一致性声明（模板见 prompts.md 文末）。
- 每条提示词都要有：`no text of any kind` + 明确留白区（`upper 24% clean and empty`）+ 光线描述。
- 模特图**必须写死年龄约束**（`aged 52-58, some grey strands, fine expression lines, NOT young, NOT flawless porcelain skin`），否则 AI 一定把客人画年轻。禁用 young / youthful / flawless 等词。

### 每张生成后立刻质检（Read 打开看）

1. 产品是否与原图一致（颜色／图案／结构／扣子与口袋数量）
2. 画面是否出现任何文字（有则重做）
3. 水印位置（照例在右下角）
4. 上方留白是否真的干净（AI 经常不听话，把主体画满 → 改用 foot 或 corner 版式补救）

> **已知局限**：ImageGen 对"把主体画小一点、留白多一点"这类构图约束执行力差，常常把主体画满。**不要靠 prompt 硬刚，直接在后期用页脚色带或裁切解决。**

---

## 五、阶段四：后期（`dp.py`）

统一先看水印怎么处理，再选版式。

### 纯白背景商品图（`white_bg_master.py`）——「把衣服放到白底上」走这条

用户说「把图片里的衣服放到白底图上／要纯白底主图」时，**先用 ImageGen 换成白底，再用本脚本收尾**。两步都做，缺一不可：

**第 1 步：ImageGen 图生图换白底**（`image1` = 用户原图，`input_fidelity: "high"`，`size: "1024x1536"`，`quality: "high"`）

提示词骨架（`{GARMENT}` 用一致性声明替换）：

```
Professional e-commerce product photograph on a pure white seamless background.
GARMENT (take EXACTLY from the input image, do not change anything): {GARMENT}
PRESENTATION: shown on an invisible ghost mannequin, front view, sleeves hanging naturally with
a slight angle so the cuff is visible, garment centred, occupying about 62% of the frame height,
clear white space on all four sides, full sleeve length inside the frame, nothing cropped.
No model, no person, no hands, no face, no handbag, no trousers, no other clothing, no props,
no hanger visible.
BACKGROUND: perfectly clean flat seamless pure white (#FFFFFF), no texture, no gradient,
no colour cast, no grey vignette; only one extremely soft subtle contact shadow beneath the garment.
LIGHTING: soft even studio light from the front-left, crisp fabric texture, commercial retouching.
ABSOLUTELY NO TEXT of any kind: no Chinese characters, no letters, no numbers, no watermark, no logo.
```

**第 2 步：`white_bg_master.py` 收白底 + 重排尺寸**

```bash
python white_bg_master.py --src 生成图.png --out-dir ./白底图
# 默认：裁底部 120px 水印 + 洪水填充刷纯白 + 输出 1:1、3:4、原比例 三版 1200px
python white_bg_master.py --src 生成图.png --out-dir ./白底图 --ratios 1.0 --base 1200
```

- 阈值自动取「边框最暗像素 − 50」（实测约 166~184）：既能吃掉 AI 留下的浅灰底和柔和投影，又远低于服装高光，不会咬进衣服。服装有极亮高光时用 `--threshold` 手动压低。
- 只对**背景本来就是浅色**的图有效。原图是暖色室内/货架实景时必须先过第 1 步。
- ImageGen 出的浅灰底（实测 234~249）**不是纯白**，四角也带灰，不做第 2 步就一定被平台判定"非白底"，别偷懒。
- 交付时提醒用户：AI 换底可能让印花位置、褶皱有细微漂移，**必须和原图逐项比对**，有偏差就重做。

### 白底画布（`canvas.py`）——只加白边，不抠图

用户说「加白边／白底画布／把整张图放进白底」时用这个。**别用 `dp.py white`** ——那个只把「本来就是近似白的背景」刷成纯白 255，对暖色/杂乱背景无效。

```bash
# 方版 1200×1200（淘宝/抖音主图）
python canvas.py --src 原图.jpg --out 白底_方版.png --size 1200 --ratio 1.0
# 竖版 3:4
python canvas.py --src 原图.jpg --out 白底_竖版.png --size 1200 --ratio 0.75
```

参数：`--size` 画布短边像素（默认 1200）、`--ratio` 宽高比 宽/高（默认 1.0）、`--margin` 四边留白占比（默认 0.09）。主体等比缩放后居中，不裁切、不重采样失真（LANCZOS）。

**必须向用户讲清**：这是「整图外扩白边」，**不含抠图**。原图背景本身有色（如暖色室内、货架）时，成品是「白边＋原背景」，不是纯白背景商品图。用户要纯白背景的商品图，得走 ImageGen 换背景（提示词见 prompts.md），且要提醒服装细节可能微漂移、建议逐项比对。

### 水印处理（三种，按优先级）

```bash
# 1) 优先：裁掉底部 112px（1024x1536 竖图的水印固定在 x814-1023, y1436-1535）
python dp.py crop --src a.png --out b.png

# 2) 底部有不能裁的内容（鞋子/裤脚）→ 用色带盖住，标题写进色带
python dp.py foot --src a.png --out b.png --title 一衣多搭 --sub "配西裤 · 配半裙" --cut 0

# 3) 底部内容必须保留且不能被色带盖 → 横向取材修补
python dp.py patch --src a.png --out b.png --x0 848 --y0 1462
```

### 版式选择（看主体在画面里的位置）

```bash
# A. 上方 24% 以上干净 → 顶部居中标题（细节图、静物图默认用这个）
python dp.py top --src a.png --out b.png --title 领口细节 --sub "小立领一粒扣 · 服帖不勒脖"

# B. 主体占满、顶部底部都脏 → 衬纸页脚（模特图默认用这个）
python dp.py foot --src a.png --out b.png --title 日常穿着 --sub "端得住场合 · 穿着自在" --cut 0

# C. 主体占满但有干净墙面 → 右上角右对齐 + 象牙色描边
python dp.py corner --src a.png --out b.png --title 一衣多搭 --sub "配西裤 · 配半裙 · 都体面"
```

**`top` 的 y 坐标必须按实际留白高度调**（AI 出的留白时宽时窄，用死值会压到衣服上）：

| 主体顶部在画面中的 y | title-y / bar-y / sub-y | 字号(title/sub) |
|---|---|---|
| ≥ 330px（留白充裕：主视觉、正背版型图） | 80 / 198 / 236 | 80 / 34 |
| ≈ 280px（常见） | 64 / 182 / 218 | 80 / 34 |
| ≈ 240px（留白偏窄：特写细节图） | 46 / 146 / 176 | 72 / 30 |

判据：**副标底边 = sub-y + sub-size，必须至少比主体顶部低 30px**。留白越窄，字号与间距一起收。
（用 Read 打开生成图目测主体顶部的 y 即可，不必写脚本测。）

文案规范：
- 标题 4-6 字，酒红 `(118,40,56)`，华文中宋 62-92px
- 副标 8-14 字，深灰褐 `(100,82,68)`，华文楷体 28-40px
- 分隔线 3px 金色 `(172,138,102)`；页脚象牙色 `(243,237,227)`
- **不用"首先/其次"、不用绝对化词**（100%、第一、顶级、永久、绝对、全网最低）

### 洗护提示图

```bash
python dp.py list --src 静物图.png --out 洗护提示.png \
  --title 洗护提示 --sub "桑蚕丝娇贵 · 请温柔以待" \
  --items "建议手洗，水温不超过 30℃|使用中性洗涤剂，避免漂白|避免长时间浸泡，轻柔挤压勿拧干|阴凉通风处平铺晾干，避免暴晒|如需熨烫，请垫布低温熨烫|建议与深色衣物分开洗涤" \
  --note "具体请以商品洗水标为准"
```

护理文案必须保守：手洗／中性洗涤剂／勿拧干／阴凉平晾／垫布低温熨烫。**不得声称防水、防污、抗皱、免烫。**

**静物图必须先量衣服的占据范围，再定 `--list-y`**（这一张最容易翻车）：

```bash
# 量出衣服的 y 范围（酒红像素扫描），再决定列表起点
python -c "
from PIL import Image
im=Image.open('静物图.png').convert('RGB'); W,H=im.size; px=im.load()
def isg(c):
    r,g,b=c; return r>60 and r<200 and r-g>35 and b<140
rows=[y for y in range(H) if any(isg(px[x,y]) for x in range(0,W,3))]
print('garment y', min(rows), max(rows), 'of', H)"
```

- 判据：**`--list-y` 必须 ≥ 衣服底部 y + 40**，且 6 项 × `line-h`(54) + note 不能超出图底。
- 衣服底部 y=813 时，`--list-y 990` 合适；若衣服底部超过 ≈1000，说明静物图不合格，**重出**。
- 重出时把约束写死，AI 才会听话：

```
*** CRITICAL COMPOSITION ***
- The folded garment must be SMALL: only about 40-45% of the frame WIDTH, sitting in the
  UPPER THIRD, roughly between the 14% and 40% lines of frame height, horizontally centred.
- The ENTIRE bottom 55% (from the 45% line to the bottom edge) MUST be empty plain ivory paper
  with no garment, no tray, no props.
- All props confined to the upper 40% of the frame.
```

**背景分区边界要靠扫描实测，别目测**：静物图常有一条"桌面边缘"横线，目测容易错 70px 以上。
用两侧背景像素逐行算平均亮度，找突变点：

```bash
python -c "
from PIL import Image
im=Image.open('静物图.png').convert('RGB'); W,H=im.size; px=im.load()
xs=list(range(0,160,4))+list(range(W-160,W,4))
prev=None
for y in range(0,400):
    v=sum(sum(px[x,y]) for x in xs)/len(xs)
    if prev is not None and abs(v-prev)>3: print('jump at y=%d %.1f->%.1f'%(y,prev,v))
    prev=v"
```

若这条线正好被衣服压住（观感等于桌沿），**保留即可，不要抹平**。


### 尺码参数图

写一个 JSON 配置再执行：

```json
{
  "out": "尺码参考.png",
  "title": "尺码参考",
  "subtitle": "上衣尺码表 · CLOTHES SIZE CHART",
  "try_on": { "label": "试穿尺码", "value": "XL" },
  "trial":  { "label": "试穿身高 / 体重", "value": "158cm / 45kg" },
  "columns": ["尺码", "建议体重", "衣长(cm)", "胸围(cm)", "肩宽(cm)"],
  "rows": [["XL","80-100斤","60","98","40"], ["2XL","100-120斤","61","102","41"]],
  "note": "温馨提示：以上为平铺手工测量数据，可能存在 2-3cm 误差，具体以实物为准。",
  "keywords": "宽松直筒版型      ·      立领一粒扣      ·      桑蚕丝缎面"
}
```

```bash
python dp.py size --config size.json
```

- `widths` 不给会自动按内容计算列宽。
- 裤子版的 columns 换成：`尺码 / 建议体重 / 裤长(cm) / 腰围(cm) / 臀围(cm) / 建议身高(cm)`。

---

## 六、阶段五：交付

1. 逐张保存为 `详情页_0N_模块名.png`。
2. 上传 freeimage.host 取直链：
   ```bash
   curl -s -X POST "https://freeimage.host/api/1/upload" \
     -F "key=6d207e02198a847aa98d0a2a901485a5" -F "action=upload" \
     -F "format=json" -F "source=@文件名.png"
   ```
   取返回 JSON 里的 `image.url`。（字段名必须是 `source`，用 `file` 会报 130）
3. **交付给用户时必须给文字直链**（用户在手机/微信端看图），同时输出一份交付清单，包含：图片编号与建议排列顺序、已使用的确认参数、待核验事项、单图修改入口、保存路径。
4. 用户要改单张时**只重做那一张**，不重做整套。

---

## 七、合规红线

- 材质没确认就写"真丝/桑蚕丝" = 虚假宣传；未确认的统一写"缎面垂顺面料"。
- 不得编造尺寸、重量、成分比例、认证、检测报告、保修、发货和售后承诺。
- 不得虚构图片中看不到的结构（背面缺图时按同款推演，并明确标注建议补拍）。
- 绝对化用语一律禁用。

---

## 八、单图修改对照表

| 用户指令 | 处理方式 |
|---|---|
| 只换背景 | 保留产品外观、颜色、结构、文字，只替换背景 |
| 只改文案 | 保留产品或画面，只替换指定文字（重跑对应 `dp.py` 版式命令） |
| 重做第 N 张 | 只重做该张，不影响已通过图片 |
| 删除某卖点 | 只删除对应文字，不重做整套 |
| 换风格 | 从第 3 张起改，主视觉最后定 |
