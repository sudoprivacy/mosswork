---
name: skillhub-skill-docx-skill-4-cn-paper
description: ">"
---

# docx-skill-4-cn-paper

本技能集合包含 1 个子技能文件。

## 兼容平台

- Claude Code
- Codex
- Hermes Agent
- OpenClaw
- QClaw
- WorkBuddy
