#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
img_tool.py — 图片改字辅助工具

三个模式:
  probe  探测图片尺寸/宽高比，给出 ImageGen 建议使用的 size 参数
  crop   裁剪目标区域并放大，作为图生图编辑的输入（小字/小目标必用）
  paste  把编辑好的局部图缩放并羽化贴回原图

用法:
  python img_tool.py probe <图片>
  python img_tool.py crop  <图片> --box x1,y1,x2,y2 --out _crop.png [--scale 3] [--max-dim 2048]
  python img_tool.py paste <原图> <局部图> --box x1,y1,x2,y2 --out out.png [--feather 3]

依赖:
  Pillow（pip install pillow）。probe 在缺少 Pillow 时会自动降级为读取文件头，仍可工作。
"""

import argparse
import os
import struct
import sys

# ImageGen 支持的尺寸候选（宽 x 高 : 宽高比）
SIZE_CANDIDATES = [
    ("1024x1024", 1.0),
    ("1536x1024", 1.5),
    ("1024x1536", 2.0 / 3.0),
]


# --------------------------------------------------------------------------
# 尺寸读取
# --------------------------------------------------------------------------
def _size_from_header(path):
    """不依赖 Pillow，直接从文件头解析常见格式尺寸。解析失败返回 (None, None)。"""
    try:
        with open(path, "rb") as f:
            head = f.read(32)

        if head[:8] == b"\x89PNG\r\n\x1a\n":
            w, h = struct.unpack(">II", head[16:24])
            return w, h

        if head[:6] in (b"GIF87a", b"GIF89a"):
            w, h = struct.unpack("<HH", head[6:10])
            return w, h

        if head[:2] == b"BM":
            w, h = struct.unpack("<ii", head[18:26])
            return abs(w), abs(h)

        if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
            fmt = head[12:16]
            if fmt == b"VP8X":
                w = int.from_bytes(head[24:27], "little") + 1
                h = int.from_bytes(head[27:30], "little") + 1
                return w, h
            # VP8 / VP8L 需要继续读，交给 Pillow 处理
            return None, None

        if head[:2] == b"\xff\xd8":  # JPEG
            with open(path, "rb") as f:
                data = f.read()
            i = 2
            n = len(data)
            while i < n - 9:
                if data[i] != 0xFF:
                    i += 1
                    continue
                marker = data[i + 1]
                if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
                    i += 2
                    continue
                seglen = struct.unpack(">H", data[i + 2:i + 4])[0]
                if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
                    h, w = struct.unpack(">HH", data[i + 5:i + 9])
                    return w, h
                i += 2 + seglen
            return None, None
    except Exception:
        return None, None
    return None, None


def get_size(path):
    """优先用 Pillow，失败则退回文件头解析。"""
    try:
        from PIL import Image  # noqa
        with Image.open(path) as im:
            return im.size
    except ImportError:
        return _size_from_header(path)
    except Exception:
        return _size_from_header(path)


def suggest_size(w, h):
    """按宽高比挑最接近的 ImageGen size 参数。"""
    ratio = w / float(h)
    best_label, best_val, best_diff = None, None, None
    for label, r in SIZE_CANDIDATES:
        diff = abs(ratio - r)
        if best_diff is None or diff < best_diff:
            best_label, best_val, best_diff = label, r, diff
    return best_label, ratio, best_diff


def cmd_probe(args):
    path = args.image
    if not os.path.isfile(path):
        print("[错误] 文件不存在: %s" % path)
        return 1

    w, h = get_size(path)
    if not w or not h:
        print("[错误] 无法解析图片尺寸，请确认文件是有效的 PNG/JPEG/WebP/GIF/BMP。")
        return 1

    label, ratio, diff = suggest_size(w, h)
    px = w * h
    size_kb = os.path.getsize(path) / 1024.0

    print("文件    : %s" % os.path.abspath(path))
    print("尺寸    : %d x %d  (%.2f MP)" % (w, h, px / 1_000_000.0))
    print("宽高比  : %.3f  (%s)" % (ratio, "横图" if ratio > 1.05 else ("竖图" if ratio < 0.95 else "近似方图")))
    print("体积    : %.1f KB" % size_kb)
    print("建议 size: %s" % label)
    if diff > 0.35:
        print("  ⚠ 原图比例与可选尺寸差异较大(%.2f)，生成后可能出现裁切。" % diff)
        print("    建议先裁剪原图到接近 1:1 / 3:2 / 2:3，或改用局部裁剪放大法。")
    if w < 800 or h < 600:
        print("  ⚠ 分辨率偏低，直接改字成功率会下降，建议使用 crop 局部放大后再编辑。")
    return 0


# --------------------------------------------------------------------------
# 坐标与裁剪
# --------------------------------------------------------------------------
def parse_box(box_str, w=None, h=None):
    try:
        parts = [int(float(p.strip())) for p in box_str.replace("，", ",").split(",")]
    except Exception:
        raise ValueError("--box 格式应为 x1,y1,x2,y2，例如 620,340,880,410")
    if len(parts) != 4:
        raise ValueError("--box 需要 4 个数字: x1,y1,x2,y2")
    x1, y1, x2, y2 = parts
    if x2 <= x1 or y2 <= y1:
        raise ValueError("--box 无效：需满足 x2 > x1 且 y2 > y1")
    if w and h:
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(w, x2), min(h, y2)
        if x2 <= x1 or y2 <= y1:
            raise ValueError("--box 超出图片范围")
    return (x1, y1, x2, y2)


def _require_pillow():
    try:
        from PIL import Image, ImageFilter  # noqa
        return True
    except ImportError:
        print("[错误] 该模式需要 Pillow。请安装后重试:")
        print("       python -m pip install pillow")
        return False


def cmd_crop(args):
    if not _require_pillow():
        return 1
    from PIL import Image

    if not os.path.isfile(args.image):
        print("[错误] 文件不存在: %s" % args.image)
        return 1

    with Image.open(args.image) as im:
        im.load()
    w, h = im.size
    box = parse_box(args.box, w, h)

    patch = im.crop(box)
    cw, ch = patch.size

    scale = args.scale
    if scale != 1.0:
        target = (max(1, int(round(cw * scale))), max(1, int(round(ch * scale))))
        longest = max(target)
        if longest > args.max_dim:
            k = args.max_dim / float(longest)
            target = (max(1, int(target[0] * k)), max(1, int(target[1] * k)))
            print("  ⚠ 放大后长边超过 %d，已自动缩放到 %dx%d" % (args.max_dim, target[0], target[1]))
        patch = patch.resize(target, Image.LANCZOS)
    else:
        target = (cw, ch)

    out = args.out or "_crop.png"
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    patch.save(out)

    print("源图    : %dx%d" % (w, h))
    print("裁剪框  : %s  →  %dx%d" % (box, cw, ch))
    print("输出    : %s  (%dx%d)" % (os.path.abspath(out), target[0], target[1]))
    print("")
    print("下一步: 用 ImageGen 编辑这张裁剪图，然后执行")
    print('  python img_tool.py paste "%s" "<编辑后的图>" --box %d,%d,%d,%d --out <结果>.png'
          % (args.image, box[0], box[1], box[2], box[3]))
    print("注意: paste 的 --box 必须与这里完全一致。")
    return 0


# --------------------------------------------------------------------------
# 羽化贴回
# --------------------------------------------------------------------------
def cmd_paste(args):
    if not _require_pillow():
        return 1
    from PIL import Image, ImageDraw, ImageFilter

    for p in (args.base, args.patch):
        if not os.path.isfile(p):
            print("[错误] 文件不存在: %s" % p)
            return 1

    base = Image.open(args.base)
    has_alpha = base.mode in ("RGBA", "LA") or (
        base.mode == "P" and "transparency" in base.info)
    base = base.convert("RGBA")
    patch = Image.open(args.patch).convert("RGBA")

    bw, bh = base.size
    box = parse_box(args.box, bw, bh)
    tw, th = box[2] - box[0], box[3] - box[1]

    pw, ph = patch.size
    if (pw, ph) != (tw, th):
        print("  局部图 %dx%d → 缩放到目标框 %dx%d" % (pw, ph, tw, th))
        patch = patch.resize((tw, th), Image.LANCZOS)

    feather = max(0, args.feather)
    if feather == 0:
        mask = Image.new("L", (tw, th), 255)
    else:
        mask = Image.new("L", (tw, th), 0)
        d = ImageDraw.Draw(mask)
        d.rectangle([feather, feather, max(feather, tw - feather), max(feather, th - feather)],
                    fill=255)
        mask = mask.filter(ImageFilter.GaussianBlur(radius=feather / 2.0))

    # 直接在原图副本上带遮罩混合。
    # 不要用"透明图层 + alpha_composite"：半透明遮罩下 PIL 会把 RGB 也乘上遮罩系数，
    # 在羽化边缘产生一圈约 255*(1-m) 的暗环（v2.0.0 的已知缺陷）。
    out_img = base.copy()
    out_img.paste(patch, (box[0], box[1]), mask)

    if not has_alpha:
        out_img = out_img.convert("RGB")

    out = args.out
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    out_img.save(out)

    print("底图    : %s (%dx%d)" % (args.base, bw, bh))
    print("局部图  : %s" % args.patch)
    print("贴回框  : %s  羽化: %d px" % (box, feather))
    print("输出    : %s" % os.path.abspath(out))
    print("")
    print("提示: 若贴回处有『补丁感』，增大 --feather (5-8)；若边缘发糊，减小到 1-2。")
    return 0


# --------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="图片改字辅助工具: probe / crop / paste",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__)
    sub = parser.add_subparsers(dest="cmd")

    p_probe = sub.add_parser("probe", help="探测尺寸并给出建议的 size 参数")
    p_probe.add_argument("image")
    p_probe.set_defaults(func=cmd_probe)

    p_crop = sub.add_parser("crop", help="裁剪区域并放大，作为编辑输入")
    p_crop.add_argument("image")
    p_crop.add_argument("--box", required=True, help="x1,y1,x2,y2（原图像素坐标）")
    p_crop.add_argument("--out", default="_crop.png")
    p_crop.add_argument("--scale", type=float, default=3.0)
    p_crop.add_argument("--max-dim", type=int, default=2048)
    p_crop.set_defaults(func=cmd_crop)

    p_paste = sub.add_parser("paste", help="把编辑后的局部图羽化贴回原图")
    p_paste.add_argument("base", help="原图")
    p_paste.add_argument("patch", help="编辑后的局部图")
    p_paste.add_argument("--box", required=True, help="必须与 crop 时完全一致")
    p_paste.add_argument("--out", required=True)
    p_paste.add_argument("--feather", type=int, default=3)
    p_paste.set_defaults(func=cmd_paste)

    if len(sys.argv) == 1:
        parser.print_help()
        return 0

    args = parser.parse_args()
    if not getattr(args, "func", None):
        parser.print_help()
        return 0
    try:
        return args.func(args)
    except ValueError as e:
        print("[错误] %s" % e)
        return 1


if __name__ == "__main__":
    sys.exit(main())
