# -*- coding: utf-8 -*-
"""run_pipeline —— NoiseLedger（噪音台账）主入口。

用法：
    python run_pipeline.py --input 01_cleaner/test_noise.txt
    python run_pipeline.py --input 01_cleaner/test_noise.txt --llm rules
    python run_pipeline.py --input 01_cleaner/test_noise.txt --output ./my_out

流程：读入 .txt -> 清洗废话 -> 提取任务 -> 终端打印 Markdown 表格 -> 导出 Excel。
纯本地处理，文本不上传任何服务器。
"""

import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
# 各模块已分目录，逐个加入 sys.path 才能 import 到
for _sub in ("01_cleaner", "02_extractor", "03_render"):
    sys.path.insert(0, os.path.join(HERE, _sub))

from input_cleaner import read_txt
from core_extractor import extract
from output_render import records_to_df, render_markdown, to_excel

DEFAULT_OUTPUT = os.path.join(HERE, "04_output")
EXCEL_NAME = "NoiseLedger_Result.xlsx"

_MODE_TXT = {"llm": "本地大模型", "rules": "离线规则引擎"}


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="NoiseLedger 噪音台账 —— 老板语音转任务台账（纯本地）"
    )
    parser.add_argument("--input", "-i", required=True,
                        help="输入的 .txt 语音转文字文件路径")
    parser.add_argument("--output", "-o", default=DEFAULT_OUTPUT,
                        help="输出目录，默认本 Skill 根目录下的 04_output/")
    parser.add_argument("--llm", choices=["auto", "rules", "llm"], default="auto",
                        help="提取方式：auto=自动(本地大模型优先，无则规则)；"
                             "rules=纯离线规则；llm=强制本地大模型")
    args = parser.parse_args(argv)

    try:
        print("=" * 62)
        print("NoiseLedger 噪音台账 —— 纯本地，保护公司隐私")
        print("=" * 62)

        # 1) 读入 + 清洗
        cleaned = read_txt(args.input)
        print(f"[1/3] 已读取并清洗：{args.input}（{len(cleaned)} 字）")

        # 2) 提取
        records, mode = extract(cleaned, use_llm=args.llm)
        mode_txt = _MODE_TXT.get(mode, mode)
        print(f"[2/3] 提取完成（模式：{mode_txt}），共 {len(records)} 条任务")

        # 3) 渲染 + 导出
        df = records_to_df(records)
        print()
        print(render_markdown(df))
        print()

        out_path = os.path.join(args.output, EXCEL_NAME)
        to_excel(df, out_path)
        print(f"[3/3] 已生成 Excel：{out_path}")
        print("完成。文本未上传任何服务器，隐私安全。")
        return 0

    except FileNotFoundError as e:
        print(f"错误：{e}", file=sys.stderr)
        return 1
    except UnicodeDecodeError as e:
        print(f"错误：{e}", file=sys.stderr)
        return 1
    except Exception as e:  # noqa: BLE001 —— 兜底，给用户友好提示而非 traceback
        print(f"运行失败：{e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
