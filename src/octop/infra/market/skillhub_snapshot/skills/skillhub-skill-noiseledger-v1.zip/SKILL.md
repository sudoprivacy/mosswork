---
name: skillhub-skill-noiseledger-v1
description: "把老板/同事的语音转文字或聊天记录，一键提取成任务台账。输入一段 .txt 文字，自动清洗废话（嗯、啊、那个、就是……）、提取其中的 任务 / 时间 / 人员 / 金额，终端打印 Markdown 表格，并在 04_output/ 目录生成 NoiseLedger_Result.xlsx。纯本地处理、完全免费、不上传任何服务器，保护公司隐私。当用户想从语音转文字、聊天记录、会议记录里提取待办任务、时间、人员、金额，或要做\"噪音台账\"、老板交代的任务清单、语音转 Excel 任务表时使用。"
---

# NoiseLedger（噪音台账）

**纯本地处理，保护公司隐私；只需粘贴老板语音文字，一键生成 Excel 台账。** 完全免费，无任何支付协议。

把一段啰嗦的语音转文字丢进来，自动：去废话 → 提取任务/时间/人员/金额 → 终端打印表格 → 生成 `NoiseLedger_Result.xlsx`。

## 铁律

1. **纯本地，绝不外发。** 全程只在本机读写文件；默认的离线规则模式完全不联网。
2. **只跑命令，不重写逻辑。** `run_pipeline.py` 一条命令即可，四个模块职责单一，别自己另写一套。
3. **产物只写 `04_output/`。** Excel 固定输出到本 Skill 根目录的 `04_output/` 下。
4. **不臆造数据。** 文本里没提的字段就填空（null），不要编。

## 运行约定（WorkBuddy 中使用）

- Skill 根目录 = 本 SKILL.md 所在文件夹，命令都在根目录执行。
- 用户粘贴的语音文字，先存成 `.txt` 再传入 `--input`；路径写完整。
- 目录分工：`01_cleaner/input_cleaner.py` 清洗、`02_extractor/core_extractor.py` 提取、`03_render/output_render.py` 渲染+导出、根目录 `run_pipeline.py` 总入口；`01_cleaner/test_noise.txt` 示例；`04_output/` 结果。

## AI 标准动作（对话式使用）

1. **拿文本**：用户给语音文字或 .txt 文件。若是直接粘贴的文字，先写到某个 `.txt`（例如 skill 根目录下临时文件）。
2. **跑**：`python run_pipeline.py --input "<文件路径>"`。
3. **汇报**：把终端打印的 Markdown 表格转述给用户，并给出 `04_output/NoiseLedger_Result.xlsx` 的路径。
4. 首次使用若缺依赖（pandas / tabulate / openpyxl），按 `requirements.txt` 用 pip 安装。

## 参数

| 参数 | 说明 |
|---|---|
| `--input` / `-i` | 输入的 .txt 语音文字路径（必填） |
| `--output` / `-o` | 输出目录，默认 skill 根目录 `04_output/` |
| `--llm` | 提取方式：`auto`（默认，本地大模型优先、无则规则）/ `rules`（纯离线规则）/ `llm`（强制本地大模型） |

退出码：0 成功；1 失败。

## 提取方式说明

- **离线规则模式（默认回退）**：完全离线、免费，正则识别"小X/老X/某总"、"明天下午三点之前"、"五千块钱/3万元"等人名、时间、金额，剩余为任务正文。零外部依赖。
- **本地大模型模式**：可把文本喂给本机 Ollama 或自定义 OpenAI 兼容端点，Prompt 强制输出纯 JSON 数组（`task/time/person/amount`，未提及填 null）。通过环境变量配置：
  - `NOISE_LEDGER_LLM_URL`：端点，默认 `http://localhost:11434/v1/chat/completions`
  - `NOISE_LEDGER_LLM_MODEL`：模型名，默认 `qwen2.5:7b`
  - `NOISE_LEDGER_LLM_API_KEY`：需要鉴权时填（Ollama 本地可留空）

## 项目结构

```
noise-ledger/
├── run_pipeline.py        # ★ 主入口（--input / --output / --llm）
├── SKILL.md               # 本文件（AI 使用说明）
├── README.md              # 用户上手指南
├── requirements.txt       # pandas / tabulate / openpyxl
├── _skillhub_meta.json    # ToolForce 生态元数据
├── _user_meta.json        # 本地注册标记
├── 01_cleaner/
│   ├── input_cleaner.py   # 读 .txt + 去废话（read_txt / clean_text）
│   └── test_noise.txt     # 示例：一段啰嗦的老板语音文字（3 个任务）
├── 02_extractor/
│   └── core_extractor.py  # 提取任务（extract / extract_with_rules / extract_with_llm）
├── 03_render/
│   └── output_render.py   # pandas 渲染 + 导出（records_to_df / render_markdown / to_excel）
└── 04_output/             # ★ 结果：NoiseLedger_Result.xlsx
```

## 输出字段

每一条任务四个字段：**任务 / 时间 / 人员 / 金额**，文本里没提的填空。

## 验证

```bash
python run_pipeline.py --input 01_cleaner/test_noise.txt
```

应看到：终端打印 3 行任务的 Markdown 表格，且 `04_output/NoiseLedger_Result.xlsx` 已生成。
