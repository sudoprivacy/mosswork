# -*- coding: utf-8 -*-
"""input_cleaner —— 读入 .txt 老板语音文字，去掉废话与多余换行。

纯本地处理：只在本机读写文件，不联网、不上传，保护公司隐私。
"""

import os
import re

# 语气词 / 叹词 / 句末语气助词 —— 几乎都是口头废话，直接删，不影响语义。
_PARTICLES = "啊哦呃嗯呐哪嘛诶哎呀哈哟咯嘞呗哩"

# 口头禅短语 —— 只在"独立出现"（前后不是汉字/字母/数字）时才删，
# 避免误删 "那个项目" "就是这个" 里真正有含义的用法。
_FILLER_PHRASES = [
    "就是说", "就是说嘛", "就是", "这个", "然后呢", "你知道吗",
    "对吧", "是吧", "好不好", "怎么说呢", "怎么说", "反正", "基本上",
    "基本上来说", "这样的话", "然后",
]

# 语气词：独立出现的短语（前后为非文字字符）整段删掉。
_FILLER_RE = re.compile(
    r"(?<![0-9A-Za-z\u4e00-\u9fa5])"
    r"(?:"
    + "|".join(re.escape(w) for w in _FILLER_PHRASES)
    + r")"
    r"(?![0-9A-Za-z\u4e00-\u9fa5])"
)

# 连续重复标点 -> 单个
_DUP_PUNCT_RE = re.compile(r"([，。！？；、,\.!?;])[，。！？；、,\.!?;]+")

# 多余的空白 / 全角空格
_MULTI_SPACE_RE = re.compile(r"[ \t\u3000]+")


def clean_text(text):
    """清洗一段语音转文字。

    做的事：
    1. 删除语气词 / 叹词（嗯、啊、哦……）与口头禅（那个、就是……）
    2. 合并连续标点
    3. 压缩多余空白、去掉空行
    4. 标点前后多余空格收紧

    返回清洗后的文本字符串。
    """
    if not text:
        return ""

    # 1) 叹词直接删
    text = re.sub("[" + _PARTICLES + "]", "", text)

    # 1.5) "那个" 在口语里几乎都是口头禅，直接删（"那个项目"->"项目"，不丢信息）
    text = text.replace("那个啥", "").replace("那个", "")

    # 2) 独立出现的口头禅短语删掉
    text = _FILLER_RE.sub("", text)

    # 3) 连续标点合并
    text = _DUP_PUNCT_RE.sub(r"\1", text)

    # 4) 压缩空白
    text = _MULTI_SPACE_RE.sub(" ", text)

    # 5) 逐行去首尾空白、删空行
    lines = [ln.strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]

    result = "\n".join(lines)

    # 6) 标点前后空格收紧
    result = re.sub(r"\s+([，。！？；、,.!?;])", r"\1", result)
    result = re.sub(r"([，。！？；、,.!?;])\s+", r"\1", result)
    # 句首残留的顿号/逗号
    result = re.sub(r"^[，、,;；\s]+", "", result)

    return result.strip()


def read_txt(path):
    """读取 .txt 文件（自动识别编码），返回清洗后的文本。

    编码依次尝试 UTF-8 / GB18030 / GBK，能识别哪个用哪个。
    文件不存在抛 FileNotFoundError；编码全失败抛 UnicodeDecodeError。
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"文件不存在：{path}")

    raw = None
    for enc in ("utf-8-sig", "utf-8", "gb18030", "gbk"):
        try:
            with open(path, "r", encoding=enc) as f:
                raw = f.read()
            break
        except UnicodeDecodeError:
            continue

    if raw is None:
        raise UnicodeDecodeError(
            "unknown", b"", 0, 1, f"无法识别文件编码（试过 UTF-8/GB18030/GBK）：{path}"
        )

    return clean_text(raw)


if __name__ == "__main__":
    import sys

    # 演示：优先读命令行传入的文件，否则读同目录的 test_noise.txt
    # 用 os.path.abspath(__file__) 定位，文件移动后路径依然正确。
    here = os.path.dirname(os.path.abspath(__file__))
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "test_noise.txt")

    if os.path.exists(path):
        print("清洗前：")
        with open(path, "r", encoding="utf-8") as f:
            print(f.read())
        print("\n清洗后：")
        print(read_txt(path))
    else:
        demo = "嗯，那个，小王啊，你明天下午三点之前，就是，把需求文档整理一下，预算大概五千块钱。"
        print("清洗前：", demo)
        print("清洗后：", clean_text(demo))
    sys.exit(0)
