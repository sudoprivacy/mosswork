# -*- coding: utf-8 -*-
"""core_extractor —— 把清洗后的文本提取成结构化任务清单。

输出统一为 JSON 数组，每个元素四个字段：
    task / time / person / amount（未提及的字段填 null）

两种提取模式：
1. 本地大模型模式（llm）：把文本喂给本机 Ollama / 自定义 OpenAI 兼容端点，
   Prompt 强制输出纯 JSON 数组。纯本地，不外发。
2. 离线规则模式（rules）：正则兜底，完全离线、零依赖、零成本。
   auto 模式下：配置了本地大模型就用大模型，否则自动回退到规则模式。

隐私承诺：两种模式都只在本机处理；规则模式完全不联网。
"""

import json
import os
import re
import urllib.request

# ---------------------------------------------------------------------------
# 公共常量
# ---------------------------------------------------------------------------

FIELDS = ["task", "time", "person", "amount"]

# 本地大模型默认端点（Ollama 的 OpenAI 兼容接口）
DEFAULT_LLM_URL = os.environ.get(
    "NOISE_LEDGER_LLM_URL", "http://localhost:11434/v1/chat/completions"
)
DEFAULT_LLM_MODEL = os.environ.get("NOISE_LEDGER_LLM_MODEL", "qwen2.5:7b")
DEFAULT_LLM_API_KEY = os.environ.get("NOISE_LEDGER_LLM_API_KEY", "")

# ---------------------------------------------------------------------------
# 中文数字 -> 阿拉伯数字
# ---------------------------------------------------------------------------

_CN_NUM = {
    "零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
    "五": 5, "六": 6, "七": 7, "八": 8, "九": 9,
}
_CN_UNIT = {"十": 10, "百": 100, "千": 1000, "万": 10000, "亿": 100000000}


def _cn_to_int(s):
    """把中文数字（如 五千、三万、十五）转成 int，失败返回 None。"""
    s = s.strip()
    if s.isdigit():
        return int(s)
    total, cur = 0, 0
    for ch in s:
        if ch in _CN_NUM:
            cur = _CN_NUM[ch]
        elif ch in _CN_UNIT:
            unit = _CN_UNIT[ch]
            if ch == "十":
                cur = (cur or 1) * unit
            else:
                cur = (cur or 1) * unit
            total += cur
            cur = 0
        else:
            return None
    return total + cur


# ---------------------------------------------------------------------------
# 规则模式：正则表达式
# ---------------------------------------------------------------------------

# 常见姓氏（用于识别 小王 / 老李 / 王总 / 李经理）
_SURNAMES = (
    "王李张刘陈杨赵黄周吴徐孙马朱胡郭何高林罗郑梁谢唐冯宋蒋韩曹许邓彭曾"
    "肖田董潘袁蔡余杜叶程苏魏吕丁任姚卢姜崔钟谭陆汪范金石廖贾夏韦傅方白"
    "邹孟秦邱江尹薛闫段雷侯龙史陶贺毛郝龚邵万钱严覃武戴莫孔向汤"
)

# 人名：小X / 老X，以及 X总 / X经理 / X工 等称谓
_PERSON_RE = re.compile(
    r"(?:小|老)[%s]|(?:[%s])(?:总|经理|主管|负责人|工|老师|主任|师傅|哥|姐|同学)"
    % (_SURNAMES, _SURNAMES)
)

# 时间短语
_TIME_WORD = r"今天|明天|后天|昨天|大后天"
_TIME_WEEK = r"周[一二三四五六日天]|星期[一二三四五六日天]|下周[一二三四五六日天]|下星期[一二三四五六日天]|本周[一二三四五六日天]|这周[一二三四五六日天]"
_TIME_MONTH = r"\d{1,2}月\d{1,2}[日号]|\d{4}年\d{1,2}月\d{1,2}[日号]?"
_TIME_TERM = r"月底|月初|月末|年中|年末|年底|年初|下个月|这个月|本月|下个季度|本季度|这季度|周末"
_TIME_PART = r"上午|下午|晚上|早上|中午|凌晨|傍晚|夜里|半夜"
_TIME_CLOCK = r"(?:\d{1,2}|[一二三四五六七八九十]{1,2})[点时:：](?:半|\d{1,2}|[一二三四五六七八九十]{1,2})?(?:分)?"
_TIME_BOUND = r"之前|以前|前|以内|为止|截止"

_TIME_RE = re.compile(
    r"(?:" + _TIME_WORD + "|" + _TIME_WEEK + "|" + _TIME_MONTH + "|" + _TIME_TERM + r")"
    r"(?:" + _TIME_PART + r")?"
    r"(?:" + _TIME_CLOCK + r")?"
    r"(?:" + _TIME_BOUND + r")?"
)

# 金额：阿拉伯数字 或 中文数字，可带 万/千/百/亿，结尾要带 块/元/人民币 等单位
_AMOUNT_RE = re.compile(
    r"(?P<num>(?:[0-9][0-9,]*(?:\.[0-9]+)?)|(?:[零一二两三四五六七八九十百千万]+))"
    r"(?P<unit>万|千|百|亿)?"
    r"(?:块钱|人民币|块|元|rmb)",
    re.IGNORECASE,
)

# 判断某句是否是"任务句"的动作词
_TASK_VERBS = (
    "把", "整理", "跟进", "提交", "准备", "负责", "联系", "发", "写", "做",
    "汇报", "安排", "处理", "完成", "确认", "统计", "汇总", "发送", "拜访",
    "回访", "催", "提醒", "通知", "协调", "沟通", "对接", "落实", "检查",
    "审核", "审批", "起草", "修改", "打印", "归档", "下单", "采购", "报销",
    "收款", "付款", "对账", "预定", "预约", "敲定", "谈", "签", "交付", "上线",
)

# 句子开头的序号 / 连接词（要从任务正文里去掉）
_SEQ_WORDS = (
    "第一件事", "第二件事", "第三件事", "第四件事", "第五件事",
    "另外还有", "再来一个", "另外", "还有", "最后", "其次", "再者",
    "第一", "第二", "第三", "第四", "第五",
)

# 金额相关残留词（金额被挖掉后，剩下的"预算/大概/金额"等也去掉；长的排前面）
_AMOUNT_CONTEXT = (
    "不需要花钱", "不用花钱", "不花钱", "没花钱", "免费",
    "项目金额", "金额", "预算", "大概是", "大概有", "大概",
    "约为", "约", "就是", "呢", "要花", "花费", "费用",
    "别超过", "别超了", "别超", "别超支",
)

# "这个就不用花钱了" 之类的无金额说明，整段去掉
_NO_MONEY_RE = re.compile(
    r"[，,、]?这个[就也]?(?:不用花钱|不花钱|免费|不需要花钱|没花钱)[了呀啊]?"
)

# 句尾的叮嘱（记得汇报 / 注意排版 / 别忘了……），从任务正文里去掉
_REMINDER_RE = re.compile(
    r"[，,、]?(?:记得|别忘了|别忘了|别忘|抓紧|注意|别|不要|切忌)[^，,、。]*$"
)


def _parse_amount(num, unit):
    """把金额的 (num, unit) 解析成数值，失败返回 None。"""
    num = num.strip().replace(",", "")
    if re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", num):
        val = float(num)
    else:
        val = _cn_to_int(num)
        if val is None:
            return None
    if unit:
        val *= _CN_UNIT.get(unit, 1)
    if float(val).is_integer():
        return int(val)
    return round(float(val), 2)


def _find_person(sent):
    m = _PERSON_RE.search(sent)
    return (m.group(0), m.span()) if m else (None, None)


def _find_time(sent):
    m = _TIME_RE.search(sent)
    return (m.group(0).strip(), m.span()) if m else (None, None)


def _find_amount(sent):
    m = _AMOUNT_RE.search(sent)
    if not m:
        return None, None
    val = _parse_amount(m.group("num"), m.group("unit"))
    if val is None:
        return None, None
    return f"{val}元", m.span()


def _looks_like_task(sent, person, amount):
    if person or amount:
        return True
    return any(v in sent for v in _TASK_VERBS)


def _remove_spans(text, spans):
    """按 (start, end) 区间从文本里挖掉片段。"""
    if not spans:
        return text
    parts, last = [], 0
    for s, e in sorted(spans):
        parts.append(text[last:s])
        last = e
    parts.append(text[last:])
    return "".join(parts)


def _build_task(sent, person, time_, amount):
    spans = [x[1] for x in (person, time_, amount) if x[0]]
    task = _remove_spans(sent, spans)

    for w in _SEQ_WORDS:
        task = task.replace(w, "")
    task = task.replace("那个", "")           # 口头禅兜底（cleaner 之外再保险一次）
    task = _NO_MONEY_RE.sub("", task)         # "这个就不用花钱了" 整段
    for w in _AMOUNT_CONTEXT:
        task = task.replace(w, "")
    task = re.sub(r"你", "", task)            # 名字后面的"你"

    # 去掉标点残留、收紧空白
    task = re.sub(r"\s+", "", task)
    task = re.sub(r"[,，、]{2,}", "，", task)  # 连续逗号合并
    task = _REMINDER_RE.sub("", task)          # 句尾叮嘱
    task = re.sub(r"^[，、,;；:：]+", "", task)
    task = re.sub(r"[，、,;；:：]+$", "", task)
    task = task.strip("。！？!? ")

    return task or sent


def extract_with_rules(cleaned_text):
    """离线规则提取：按句子切分，逐句抽出 person/time/amount，剩余为 task。"""
    records = []
    sentences = [s.strip() for s in re.split(r"[。！？!?\n；;]+", cleaned_text) if s.strip()]
    for sent in sentences:
        person = _find_person(sent)
        time_ = _find_time(sent)
        amount = _find_amount(sent)
        if not _looks_like_task(sent, person[0], amount[0]):
            continue
        records.append({
            "task": _build_task(sent, person, time_, amount),
            "time": time_[0],
            "person": person[0],
            "amount": amount[0],
        })
    return records


# ---------------------------------------------------------------------------
# 大模型模式
# ---------------------------------------------------------------------------

def _build_prompt(cleaned_text):
    return (
        "你是任务信息提取助手。从下面的语音转文字内容中，提取所有任务信息。\n\n"
        "严格要求：\n"
        "1. 只输出一个 JSON 数组，不要输出任何解释、前后缀或 Markdown 代码块。\n"
        "2. 数组每个元素是一个任务，必须且只能包含这四个字段：\n"
        '   "task"   —— 任务内容（字符串，简短概括）\n'
        '   "time"   —— 时间（字符串，如\"明天下午三点\"；未提及填 null）\n'
        '   "person" —— 责任人（字符串；未提及填 null）\n'
        '   "amount" —— 金额（字符串，保留单位，如\"5000元\"；未提及填 null）\n'
        "3. 未提及的字段一律填 null，严禁编造。\n"
        "4. 直接输出 JSON，不要用 ``` 包裹。\n\n"
        f"语音转文字内容：\n{cleaned_text}"
    )


def _parse_json(content):
    """从大模型返回文本里稳健地抠出 JSON 数组。"""
    content = (content or "").strip()
    # 去掉 ```json ... ``` 包裹
    m = re.search(r"```(?:json)?\s*(\[.*?\])\s*```", content, re.DOTALL)
    if m:
        content = m.group(1)
    start, end = content.find("["), content.rfind("]")
    if start == -1 or end == -1 or end <= start:
        raise ValueError(f"大模型未返回 JSON 数组，返回内容前 200 字：{content[:200]}")
    return json.loads(content[start:end + 1])


def _ollama_available(timeout=0.6):
    """快速探测本机 Ollama 是否在跑（不联网、只探 localhost）。"""
    try:
        req = urllib.request.Request("http://localhost:11434/api/tags")
        with urllib.request.urlopen(req, timeout=timeout):
            return True
    except Exception:
        return False


def extract_with_llm(cleaned_text):
    """调用本地大模型提取，返回记录列表。失败抛异常，由上层决定是否回退。"""
    url = DEFAULT_LLM_URL
    model = DEFAULT_LLM_MODEL
    api_key = DEFAULT_LLM_API_KEY

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "你是一个只输出 JSON 的任务信息提取器。"},
            {"role": "user", "content": _build_prompt(cleaned_text)},
        ],
        "temperature": 0,
        "stream": False,
    }

    req = urllib.request.Request(
        url, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    if api_key:
        req.add_header("Authorization", f"Bearer {api_key}")

    with urllib.request.urlopen(req, timeout=120) as resp:
        body = resp.read().decode("utf-8")

    data = json.loads(body)
    # 兼容 OpenAI 兼容接口（choices[0].message.content）与 Ollama 原生接口（message.content）
    if "choices" in data:
        content = data["choices"][0]["message"]["content"]
    elif "message" in data:
        content = data["message"]["content"]
    else:
        raise ValueError(f"无法解析大模型响应：{body[:200]}")

    return _parse_json(content)


# ---------------------------------------------------------------------------
# 统一入口
# ---------------------------------------------------------------------------

def extract(cleaned_text, use_llm="auto"):
    """提取入口。返回 (records, mode)。

    mode 取值：
      "llm"   —— 本地大模型
      "rules" —— 离线规则引擎
    """
    if use_llm == "rules":
        return extract_with_rules(cleaned_text), "rules"

    if use_llm == "llm":
        return extract_with_llm(cleaned_text), "llm"

    # auto：配置了本地大模型就优先用它，否则回退规则
    if DEFAULT_LLM_URL and os.environ.get("NOISE_LEDGER_LLM_URL"):
        return extract_with_llm(cleaned_text), "llm"
    if _ollama_available():
        try:
            return extract_with_llm(cleaned_text), "llm"
        except Exception:
            pass  # 大模型可用但调用失败，回退规则
    return extract_with_rules(cleaned_text), "rules"


if __name__ == "__main__":
    demo = "小王，你明天下午三点之前，把需求文档整理一下，预算大概五千块钱。"
    recs, mode = extract(demo, use_llm="rules")
    print("模式：", mode)
    print(json.dumps(recs, ensure_ascii=False, indent=2))
