# -*- coding: utf-8 -*-
"""output_render —— 用 pandas 读取任务 JSON，终端打印 Markdown 表格，并导出 Excel。

纯本地处理：Excel 直接写在本机 04_output/ 目录（路径由 run_pipeline.py 传入）。
"""

import json
import os

import pandas as pd

COLUMNS = ["任务", "时间", "人员", "金额"]
FIELDS = ["task", "time", "person", "amount"]


def records_to_df(records):
    """把 [{task,time,person,amount}] 转成列名为中文的 DataFrame。

    缺字段统一补 None；空列表也给一张表头齐全的空表。
    """
    rows = []
    for r in records or []:
        if isinstance(r, dict):
            rows.append([r.get(k) for k in FIELDS])
    if not rows:
        rows = [[None, None, None, None]]
    return pd.DataFrame(rows, columns=COLUMNS)


def render_markdown(df):
    """用 tabulate 把 DataFrame 渲染成 Markdown（pipe）表格。

    没有安装 tabulate 时，用内置极简实现兜底，保证一定出表格。
    """
    display = df.fillna("").astype(str)
    try:
        from tabulate import tabulate
        return tabulate(display, headers="keys", tablefmt="pipe", showindex=False)
    except ImportError:
        return _fallback_markdown(display)


def _fallback_markdown(display):
    header = "| " + " | ".join(str(c) for c in display.columns) + " |"
    sep = "|" + "|".join("---" for _ in display.columns) + "|"
    lines = [header, sep]
    for _, row in display.iterrows():
        lines.append("| " + " | ".join(str(v) for v in row) + " |")
    return "\n".join(lines)


def to_excel(df, out_path):
    """把 DataFrame 写到 Excel；自动创建目录。"""
    out_dir = os.path.dirname(out_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    df.to_excel(out_path, index=False)


if __name__ == "__main__":
    demo = pd.DataFrame(
        [
            ["整理需求文档", "明天下午三点", "小王", "5000元"],
            ["跟进华东区大客户", "周五之前", "老李", "30000元"],
            ["整理会议纪要", "下周一上午", "小张", None],
        ],
        columns=COLUMNS,
    )
    print(render_markdown(demo))
