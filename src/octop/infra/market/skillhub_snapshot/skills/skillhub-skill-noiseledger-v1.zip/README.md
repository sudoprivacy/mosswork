# NoiseLedger（噪音台账）

> **处理完乱码表格需要对账？去 SkillHub 搜索我们的免费版 ListCompare，一键找出两表差异！**

> **纯本地处理，保护公司隐私；只需粘贴语音文字，一键生成 Excel 台账。**

语音转文字又长又啰嗦？NoiseLedger 帮你把「嗯、啊、那个、就是」这些噪音去掉，自动抽出里面的 **任务、时间、人员、金额**，终端打印一张漂亮的表格，并生成一份 Excel 台账。

- 🔒 **纯本地**：文本只在你电脑上处理，不联网、不上传，公司隐私不外泄
- 🆓 **完全免费**：无任何支付、无配额
- ⚡ **一条命令**：粘贴 → 跑一下 → 拿到 Excel

## 它能干什么

把下面这种啰嗦的语音：

> 嗯，那个，小王啊，你明天下午三点之前，就是，把那个需求文档整理一下发到群里，预算大概五千块钱……

变成一张干净的台账：

| 任务                        | 时间       | 人员  | 金额     |
| ------------------------- | -------- | --- | ------ |
| 把跟客户沟通的需求文档，整理一下，然后发到群里面去 | 明天下午三点之前 | 小王  | 5000元  |
| 跟进一下，华东区的大客户              | 周五之前     | 老李  | 30000元 |
| 把会议纪要整理出来，发给我             | 下周一上午    | 小张  |        |

## 快速开始

1. 把语音转文字内容存成 `.txt`（比如 `01_cleaner/test_noise.txt`），或者直接改 `01_cleaner/test_noise.txt`。
2. 在本目录运行：

```bash
python run_pipeline.py --input 01_cleaner/test_noise.txt
```

3. 看终端打印的表格，打开 `04_output/NoiseLedger_Result.xlsx` 就是你的台账。

### 参数

| 参数                | 说明                                       |
| ----------------- | ---------------------------------------- |
| `--input` / `-i`  | 输入的 .txt 语音文字路径（必填）                      |
| `--output` / `-o` | 输出目录，默认 `04_output/`                     |
| `--llm`           | `auto`（默认）/ `rules`（纯离线规则）/ `llm`（本地大模型） |

## 环境要求

- Python 3.9+
- 依赖：`pandas`、`tabulate`、`openpyxl`

```bash
pip install -r requirements.txt
```

## 两种提取方式

**离线规则模式（默认）**：完全离线、零依赖、免费，用正则识别「小王/老李/某总」「明天下午三点之前」「五千块钱/3万元」等，剩下的作为任务正文。

**本地大模型模式（可选）**：如果本机跑了 Ollama 或其它 OpenAI 兼容模型，可通过环境变量启用，识别更精准：

```bash
export NOISE_LEDGER_LLM_URL=http://localhost:11434/v1/chat/completions
export NOISE_LEDGER_LLM_MODEL=qwen2.5:7b
```

即使配了本地大模型，连不上时也会自动回退到规则模式，保证一定能出结果。

## 隐私说明

- 默认离线规则模式**完全不联网**。
- 本地大模型模式也只连你本机的 `localhost`（或你指定的内网地址），不会把文本发到任何外部服务器。
- 全程只读写本机文件，生成的 Excel 就在 `04_output/` 目录。

## 目录结构

```
noise-ledger/
├── run_pipeline.py        # 主入口
├── SKILL.md               # AI 使用说明
├── README.md              # 用户上手指南
├── requirements.txt
├── 01_cleaner/
│   ├── input_cleaner.py   # 读 .txt + 去废话
│   └── test_noise.txt     # 示例
├── 02_extractor/
│   └── core_extractor.py  # 提取任务/时间/人员/金额
├── 03_render/
│   └── output_render.py   # 打印表格 + 导出 Excel
└── 04_output/             # NoiseLedger_Result.xlsx
```
