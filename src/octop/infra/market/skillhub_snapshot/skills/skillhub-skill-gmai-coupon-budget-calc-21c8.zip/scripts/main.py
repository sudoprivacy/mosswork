#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""果盟精选 0518（优惠券预算测算） —— 付费计算引擎（X402 fail-closed 闸门）

规则：无 --payment-proof 拒绝输出（退出码 3 / PAYMENT_REQUIRED）；凭证格式无效退出码 3；
缺必填字段退出码 2 并指明字段名；凭证有效时现场实算并输出报告到 output/。
"""
import argparse
import datetime
import json
import math
import os
import re
import sys

VERSION = "1.0.0"
SLUG = "gmai-coupon-budget-calc-21c8"
FEN = 490
FIELDS = [('budget', '券预算（元）', 10000), ('denom', '券面额（元）', 10), ('usage_pct', '核销率(0-1)', 0.25)]
ANCHORS = ['电子商务法第49条：用户提交订单成功合同成立，不得随意变更', '规范促销行为暂行规定：应明示优惠券使用条件']
PROOF_RE = re.compile(r"^X402-[A-Za-z0-9]{16,64}$")
BODY = '''
issuable=float(I['budget'])/float(I['denom'])
redeem=issuable*float(I['usage_pct'])
cac=float(I['budget'])/redeem if redeem else 0
details=[f"可发放 {m2(issuable)} 张","预计核销 "+m2(redeem)+" 张（核销率"+m2(float(I['usage_pct'])*100)+"%）",
         f"实际单券获客成本 {m2(cac)} 元"]
result=f"预算 {m2(float(I['budget']))} 元 → 核销 {m2(redeem)} 张，单券获客 {m2(cac)} 元"
verdict="核销率低于15%说明券面额或门槛设置需调整"
'''


def m2(x):
    return format(float(x), ",.2f")


def n0(x):
    return format(int(round(float(x))), ",")


def fail402(msg):
    print(json.dumps({"code": "PAYMENT_REQUIRED", "message": msg, "skill_slug": SLUG,
                      "price_fen": FEN, "currency": "CNY"}, ensure_ascii=False))
    return 3


def compute(data):
    details, result, verdict = [], "", ""
    g = {"I": data, "m2": m2, "n0": n0, "math": math,
         "details": details, "result": result, "verdict": verdict}
    exec(BODY, g)
    return g["details"], g["result"], g["verdict"]


def write_report(data, details, result, verdict, proof):
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, "deliverable_%s_%s.md" % (SLUG, ts))
    rows_in = "\n".join("| %s | %s |" % (lab, data.get(k, "")) for k, lab, _ in FIELDS)
    rows_calc = "\n".join("- %s" % d for d in details)
    rows_anchor = "\n".join("- %s" % a for a in ANCHORS)
    doc = """# 果盟精选 0518（优惠券预算测算） · 测算报告

- 生成时间：%s
- 技能：%s（%s）
- 支付凭证：已验（X402，尾号 %s）

## 一、输入回显

| 字段 | 值 |
|---|---|
%s

## 二、计算过程

%s

## 三、结果

**%s**

## 四、判定与建议

%s

## 五、计算口径与真实锚点

%s

## 六、复算说明

本报告全部数字由程序按上述口径实算；把输入数值代入对应公式即可复算验证。引擎版本 %s。
""" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "果盟精选 0518（优惠券预算测算）", SLUG,
       proof[-4:], rows_in, rows_calc, result, verdict, rows_anchor, VERSION)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(doc)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="")
    ap.add_argument("--payment-proof", default="")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()

    if a.selftest:
        assert not PROOF_RE.match(""), "无凭证必须不匹配"
        assert not PROOF_RE.match("X402-short"), "短凭证必须不匹配"
        assert PROOF_RE.match("X402-SELFTEST0000000000000000"), "合法凭证必须匹配"
        data = {k: d for k, _, d in FIELDS}
        details, result, verdict = compute(data)
        assert result and verdict and details, "默认输入必须可算出非空结果"
        print("selftest PASS: gate=ok calc=ok price_fen=%d version=%s" % (FEN, VERSION))
        return 0

    if not PROOF_RE.match(a.payment_proof or ""):
        return fail402("未检测到有效支付凭证（--payment-proof），拒绝交付。请先完成支付（HTTP 402）后带 X402-<订单号> 凭证重试。")
    if not a.input:
        print("缺少 --input 输入文件")
        return 2
    try:
        with open(a.input, encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print("输入文件不可读:", e)
        return 2
    missing = [lab for k, lab, _ in FIELDS if (k not in data) or (str(data[k]).strip() == "")]
    if missing:
        print("缺少必填字段:", "、".join(missing))
        return 2
    details, result, verdict = compute(data)
    path = write_report(data, details, result, verdict, a.payment_proof)
    print("PAYMENT_OK skill=%s price_fen=%d" % (SLUG, FEN))
    print("RESULT:", result)
    print("VERDICT:", verdict)
    print("REPORT:", path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
