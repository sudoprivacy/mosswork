# 执行细节文档

下文是专利生成各步骤的完整命令、参数和注意事项。

> `$DIR` 指本技能所在目录。

---

## 第 0 步：首次自举（仅一次）

### 写出 assemble.js

该脚本已预置在技能根目录，正常安装后无需任何操作。若 `$DIR/assemble.js` 确实缺失，说明安装不完整——从原始安装包重新复制，**不要凭记忆手写**。

### npm install（导出 DOCX 时必需）

仅在用户后续同意导出 DOCX 且 `$DIR/node_modules` 不存在时才需要：

```powershell
npm install --prefix "$DIR"
```

`package.json` 已在根目录，`@resvg/resvg-js` 和 `docx` 会自动安装。若提示 `npm` 不存在，说明 `node` 也不在 PATH——先按 SKILL.md「运行环境兼容性」找到 node 托管完整路径，npm 与 node 同目录。

> ⚠️ `@resvg/resvg-js` 是 native addon，Windows 上需 Visual Studio Build Tools（含 C++ 工具链）。若 `npm install` 报 node-gyp 错误，先安装 [Visual Studio Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)。

---

## 第 1 步：确认输入格式 & DOCX 自动转 PDF

上传接口**只接受 PDF**。若用户上传 DOCX/DOC，**自动静默转换**，无需提示。

**转换方法（按优先级尝试）：**

1. **LibreOffice**（推荐）：
   ```powershell
   soffice --headless --convert-to pdf --outdir "$DIR" "C:\绝对路径\交底材料.docx"
   ```

2. **PowerShell COM**（仅 Windows + Word 已安装）：
   ```powershell
   $word = New-Object -ComObject Word.Application
   $doc = $word.Documents.Open("C:\绝对路径\交底材料.docx")
   $doc.SaveAs([ref]"$DIR\temp_交底材料.pdf", [ref]17)
   $doc.Close(); $word.Quit()
   ```

3. **Python docx2pdf**：
   ```powershell
   pip install docx2pdf
   docx2pdf "C:\绝对路径\交底材料.docx" --output "$DIR\temp_交底材料.pdf"
   ```

> ⚠️ **不要在用户原始路径下产生临时文件**，PDF 输出到 `$DIR/` 目录下。
> 成功后用 PDF 继续，失败时才告知用户。

---

## 第 2 步：上传，取 documentId

```powershell
curl.exe -s -X POST "https://sage-ai.net/patent_draft/api/files/upload-document" `
  -F "file=@C:\绝对路径\交底材料.pdf"
```

> ⚠️ Windows 环境必须用 `curl.exe`（PowerShell 中 `curl` 是 `Invoke-WebRequest` 别名；找不到时用绝对路径 `C:/Windows/System32/curl.exe`）；macOS/Linux 环境直接用 `curl`。

从返回 JSON 的 `data` 取 `documentId`。`code != "200"` 时反馈 `message` 并停止。

---

## 第 3 步：生成并落盘（SSE 流式）

`assemble.js` 内部 spawn `curl.exe` 请求 SSE，实时解析流，绕开 PowerShell 管道编码问题。

**后台启动 + 轮询进度**（整条命令交给工具的「后台运行」能力（`run_in_background=true`）执行，后台化由运行能力负责）：

```bash
# 不需要 cd、不需要 rm：绝对路径 + > 覆盖即可，输出全部落到 gen.log
node "$DIR/assemble.js" "<documentId>" "-" "stdout" > "$DIR/gen.log" 2> "$DIR/gen.err"
```

> ⚠️ 不要写成 `cd "$DIR" && rm -f ... && node ...`：在 PATH 不完整的环境里 `rm` 会失败并静默中断整条 `&&` 链，导致 node 从未执行、日志文件根本不生成。

等价 PowerShell 写法：

```powershell
Remove-Item "$DIR/gen.log","$DIR/gen.err" -Force -ErrorAction SilentlyContinue
Start-Process -FilePath "node" `
  -ArgumentList "`"$DIR/assemble.js`"","`"<documentId>`"","`"-`"","`"stdout`"" `
  -RedirectStandardOutput "$DIR/gen.log" -RedirectStandardError "$DIR/gen.err" `
  -WindowStyle Hidden
```

第三个参数传 `"stdout"`，让全文以 JSON 形式输出到标准输出（被重定向进 `gen.log`）。

**轮询方式**：用 **Read 工具**读取 `$DIR/gen.log`（不要用 cat），每轮间隔 60-90 秒（等待用 `node -e "setTimeout(()=>process.exit(0),75000)"`，不要用 sleep 命令）。每当读到新的 `[进度]` 行时，**立即向用户发送一条简短进度消息**（参考 `references/progress-mapping.md` 的话术模板）；同一进度只发一次。

**捕获结果**：
- 进程结束后读取 `$DIR/gen.log` 的**最后一行**——`JSON.stringify` 会把换行转义，所以结果 JSON 必然占单行
- 对该行做 JSON 解析，取得 `content`（全文）和 `charCount`
- 若最后一行不是以 `{` 开头的合法 JSON，说明进程异常中断；检查 `$DIR/gen.err` 并原样转述报错

---

## 第 4 步：呈现结果

**不展示全文**，只汇报统计：

```
✅ 100% 专利申请文件生成完成
共 X,XXX 字，包含 X 张附图

是否需要导出为 .docx 格式（内嵌高清PNG附图）？
```

**统计方式**：
- 字数：`charCount`（JSON 字段）
- 附图数：统计 `content` 中 `<svg` 出现次数

> 期间若收到 `error` 事件，仅转述 `message`，不做原因猜测或建议。

---

## 第 5 步：征求同意 → 导出 DOCX

**用户同意后**执行：

```powershell
# 1. 写入临时 md 文件
$content | Out-File -FilePath "$DIR/临时专利文件.md" -Encoding UTF8

# 2. 转换为 docx（高清 PNG 内嵌 + 表格原生转换）
node "$DIR/svg-to-docx.js" "$DIR/临时专利文件.md" "专利申请文件.docx"

# 3. 删除临时 md 文件
Remove-Item "$DIR/临时专利文件.md" -Force
```

> 若 PowerShell 工具异常，按 SKILL.md 第 4 步的 node 兜底命令写入临时 md（同时完成 charCount/svg 统计），再执行上面的转换。

**用户不同意**：仅保留聊天文本，不生成文件。

转换器功能：
- 每个 `<svg>` → 按 3 倍率渲染高清 PNG，原位置居中内嵌
- Markdown 表格 → docx 原生表格（带边框、表头加粗）
- `权利要求书` / `说明书` 等标题 → 居中加粗
- `技术领域` / `背景技术` 等子标题 → 左对齐加粗
