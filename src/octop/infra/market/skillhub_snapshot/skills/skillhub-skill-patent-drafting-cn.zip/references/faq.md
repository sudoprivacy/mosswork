# 常见问题

| 现象 | 原因 / 处理 |
|------|------------|
| 请求报 SSL 错误 `SEC_E_UNTRUSTED_ROOT`（证书链不受信任），`curl -k` 跳过校验后路径返回 404 | API 域名写错成带 www 的 `www.sage-ai.net`。**必须使用不带 www 的 `sage-ai.net`**（2026-09-17 实测：`www` 主机证书不受信任且未部署本应用；裸域正常返回 SSE） |
| 上传返回 `FORMAT_ERROR` | 只支持 PDF，先转格式 |
| 收到 `error` 事件 | 按其 `message` 告知用户并停止 |
| `documentId` 失效 | 重新上传交底 PDF |
| 流提前断开（`curl 退出码: 28`） | 客户端总超时到了。`assemble.js` 的 `--max-time` 已从 900 改为 3600；若仍撞上，说明有更外层的超时（宿主的工具调用时限、代理），**别直接重跑** —— 先确认是不是只是跑得久 |
| 跑了十几二十分钟还没到 100% | **正常**，实测 12~39 分钟，附图多的更久。只要没有 `[错误]` 就继续轮询，**不要重新生成** |
| DOCX 转换报缺模块 | 在 `$DIR` 下 `npm install` |
| PowerShell `curl` 报错 | 必须用 `curl.exe`（PowerShell 的 `curl` 是 `Invoke-WebRequest` 别名） |
| Bash 中 `curl.exe: command not found` | Bash PATH 不完整。改用绝对路径 `C:/Windows/System32/curl.exe`（Windows 10 1803+ 系统自带） |
| SSE 管道中文乱码 | `assemble.js` 内部直接 spawn `curl.exe`，无需 PowerShell 管道 |
| npm install 报 node-gyp 错误 | 缺少 C++ 工具链，安装 Visual Studio Build Tools |
| 用户上传了非 PDF/DOCX 格式 | 告知用户只支持 PDF 或 DOCX |
| 生成结果内容不完整 | 检查网络连接，重试生成 |
