---
name: skillhub-skill-patent-drafting-cn
description: "当用户上传交底材料、研发报告、技术方案文档，并要求撰写专利、撰写初稿，或请专利代理师视角输出可申请的专利文件时触发。也涵盖如下说法：'帮我把这份交底写成专利''生成专利文件''生成初稿''专利撰写'等，无论是否明确说'生成专利文件'。"
---

# 专利申请初稿

## 概述

触发后调用专利生成接口完成全部生成。本 skill 不自己撰写专利内容，只负责：

1. 上传 PDF 交底材料，取 `documentId`
2. 调用生成接口，消费 SSE 流式返回并落盘
3. 生成完成后**征求用户同意**，把文中 SVG 图渲染为高清 PNG、原位内嵌，把文中 Markdown 表格转为 docx 原生表格（带边框、表头加粗），导出 `.docx`

## 执行步骤

### 运行环境兼容性（必读，适用于所有命令）

部分 WorkBuddy 环境的 Bash PATH 不完整：`cat`/`ls`/`sleep`/`rm`/`head`/`dirname` 等 Unix 工具可能报 `command not found`，PowerShell 工具也可能不回传 stdout。**为保证任何电脑都能跑通，硬性遵守：**

- ❌ 禁止使用 Unix 外部工具：`rm`/`cat`/`ls`/`sleep`/`head`/`tail`/`dirname`
- ❌ 禁止在 `&&` 链中使用 `cd`（任一环节失败会静默中断后续命令）
- ✅ 清日志 → 不需要清，`>` 重定向本身就会覆盖旧文件
- ✅ 路径 → 全部用绝对路径（`$DIR` 展开为完整路径），不依赖工作目录
- ✅ 轮询等待 → 用 Node 自身延时：`node -e "setTimeout(()=>process.exit(0),75000)"`
- ✅ 读日志/读结果 → 一律用 Read 工具读文件，不要用 cat
- ✅ `node` 不在 PATH 时 → 用托管完整路径（模式为 `~/.workbuddy/binaries/node/versions/<版本号>/node.exe`，先用 Glob 在 `~/.workbuddy/binaries/node/versions/` 下找到实际版本目录）；`npm` 与 node 同目录（Windows 下为 `npm.cmd`）。**本节及下文所有命令示例中的 `node` / `npm` 一律按此规则替换为完整路径**
- ✅ `curl.exe` 找不到时 → 用绝对路径 `C:/Windows/System32/curl.exe`（Windows 10 1803+ 系统自带）。若 PowerShell 工具不回传输出，直接用 Bash 工具执行上传命令，命令本体不变

### 第 0 步：首次自举（仅一次）

若 `$DIR/assemble.js` 不存在，说明安装不完整——重新从原始安装包复制该文件，**不要凭记忆手写**。

仅在用户同意导出 DOCX 且 `$DIR/node_modules` 不存在时才需要：

```powershell
npm install --prefix "$DIR"
```

> `package.json` 在根目录，`@resvg/resvg-js` 和 `docx` 会自动安装。若提示 `npm` 不存在，说明 `node` 也不在 PATH——先按「运行环境兼容性」找到 node 托管完整路径，npm 与 node 同目录。

### 第 1 步：确认输入格式 & DOCX → PDF（静默转换）

上传接口**只接受 PDF**。若用户上传 DOCX/DOC，**自动静默转换**，不提示用户。

转换方法（按优先级尝试）：

1. **LibreOffice**：
   ```powershell
   soffice --headless --convert-to pdf --outdir "$DIR" "C:\绝对路径\交底材料.docx"
   ```
2. **PowerShell COM**（仅 Windows + Word 已安装）：
   ```powershell
   $word = New-Object -ComObject Word.Application
   $doc = $word.Documents.Open("C:\绝对路径\交底材料.docx")
   $doc.SaveAs([ref]"$DIR\temp_交底材料.pdf", [ref]17)
   $doc.Close(); $word.Quit()
   ```
3. **Python docx2pdf**：
   ```powershell
   pip install docx2pdf
   docx2pdf "C:\绝对路径\交底材料.docx" --output "$DIR\temp_交底材料.pdf"
   ```

> ⚠️ **不要在用户原始路径下产生临时文件**，PDF 输出到 `$DIR/` 目录。

### 第 2 步：上传，取 documentId

```powershell
curl.exe -s -X POST "https://sage-ai.net/patent_draft/api/files/upload-document" -F "file=@C:\绝对路径\交底材料.pdf"
```

> ⚠️ Windows 环境必须用 `curl.exe`（PowerShell 中 `curl` 是 `Invoke-WebRequest` 别名；找不到时用绝对路径 `C:/Windows/System32/curl.exe`）；macOS/Linux 环境直接用 `curl`。

从返回 JSON 的 `data` 取 `documentId`。`code != "200"` 时反馈 `message` 并停止。

### 第 3 步：生成并落盘（SSE 流式）

#### 3a. 后台启动 assemble.js（输出重定向到 gen.log）

**必须后台启动**，把 stdout/stderr 重定向到日志文件，**不要同步等待它跑完**（否则会阻塞 12~40 分钟）。

**用工具的「后台运行」能力（`run_in_background=true`）执行下面这条命令**——命令保持前台形式、整条原样提交，后台化由运行能力负责：

```bash
# 不需要 cd、不需要 rm：绝对路径 + > 覆盖即可，输出全部落到 gen.log
node "$DIR/assemble.js" "<documentId>" "-" "stdout" > "$DIR/gen.log" 2> "$DIR/gen.err"
```

> ⚠️ 不要写成 `cd "$DIR" && rm -f ... && node ...`：在 PATH 不完整的环境里 `rm` 会失败并静默中断整条 `&&` 链，导致 node 从未执行、日志文件根本不生成——这是最容易踩的坑。

等价 PowerShell 写法：

```powershell
Remove-Item "$DIR/gen.log","$DIR/gen.err" -Force -ErrorAction SilentlyContinue
Start-Process -FilePath "node" `
  -ArgumentList "`"$DIR/assemble.js`"","`"<documentId>`"","`"-`"","`"stdout`"" `
  -RedirectStandardOutput "$DIR/gen.log" -RedirectStandardError "$DIR/gen.err" `
  -WindowStyle Hidden
```

> 启动后进度行 `[进度 X%] ...` 会实时追加到 `$DIR/gen.log`，最终结果 JSON 落在文件最后一行。

#### 3b. 持续轮询 gen.log 直到 100%（核心要求）

启动后，你**必须进入持续轮询循环**，具体步骤：

1. 用 **Read 工具**读取 `$DIR/gen.log`（不要用 cat），只关注新增的行
2. 每轮读取之间**间隔 60-90 秒**再读下一次（等待用 `node -e "setTimeout(()=>process.exit(0),75000)"`，不要用 sleep 命令；间隔不要短于 60 秒，否则白白消耗轮次；也不要超过 90 秒防止超时）
3. 读到包含 `[进度` 的行 → 按下方话术表**逐字照搬**发送给用户（同一进度只发一次，已发过的不重复发）
4. 读到 `[进度 100%]` → 发送完成话术后退出轮询
5. 这一轮没有新内容 → **继续下一轮，不要停止**
6. 读到 `[错误]` → 只转述错误消息，**终止流程**
7. **绝对不要在 100% 之前停止轮询**，不要中途结束对话

> ⚠️ **关键**：你必须持续轮询直到 `[进度 100%]` 出现。
>
> **整个过程通常 12~25 分钟，交底材料附图多时可能到 40 分钟。**
> **跑得比预期久不代表失败。** 只要 `gen.log` 里没有出现 `[错误]`，就必须继续轮询：
>
> - 某一轮读不到新内容 → 只是暂无进展，**继续下一轮**
> - 已经等了十几二十分钟还没到 100% → **正常，继续等**
> - **绝对不要**因为「超出预期时间」就判定失败、重新生成 —— 重新生成会让用户从头再等一遍，
>   而原来那一份其实还在正常跑。这是本 skill 最常见、代价最大的错误。

#### 3c. 进度话术（必须逐字照搬，禁止自由发挥）

当你读到某条 `[进度 X%]` 行时，从下表找到对应行，**整行复制发送，一个字都不要改，emoji 也不要换**：

```
读到 [进度 0%]   → 发送：🚀 0% 启动专利任务（剩余约 12~25 分钟）
读到 [进度 5%]   → 发送：📋 5% 校验交底材料中（剩余约 11~23 分钟）
读到 [进度 8%]   → 发送：✅ 8% 校验合格，开始生成（剩余约 10~22 分钟）
读到 [进度 15%]  → 发送：📝 15% 生成初稿中（剩余约 9~19 分钟）
读到 [进度 50%]  → 发送：📝 50% 初稿已生成，开始质检（剩余约 5~11 分钟）
读到 [进度 55%]  → 发送：🔍 55% 质检进行中（剩余约 4~10 分钟）
读到 [进度 70%]  → 发送：✅ 70% 质检完成，开始修复终稿（剩余约 3~6 分钟）
读到 [进度 75%]  → 发送：🔧 75% 修复终稿中（剩余约 2~4 分钟）
读到 [进度 100%] → 发送：✅ 100% 专利申请文件生成完成
```

> 每一行都是必须汇报的独立进度节点，一行都不能跳过。
>
> 取到 documentId 后立即汇报 0% 进度节点的消息。
>
> 8% 不是 5% 的附注，而是独立的里程碑——校验通过是重要节点，用户需要知道交底材料被接受了。
>
>  若日志中确实未出现 `[进度 8%]`，则如实跳过该节点，**绝对不得编造**。实际读到的节点集即为完整节点集。

**禁止事项：**

- ❌ 禁止自行组合 emoji 和百分比（如 🚀 5% 是错误的）
- ❌ 禁止修改任何文字（包括"剩余约XX分"的时间数字也不许改）
- ❌ 禁止添加表外内容
- ❌ 禁止跳过任何进度等级
- ❌ 禁止在 100% 之前停止轮询

#### 3d. 校验不合格处理

如果读到 `[进度 8%]` 后紧接着出现 `STEP_1_FAIL` 或 `[错误]`：
- **只转述接口返回的 error message**，不猜测原因
- **立即终止流程**

#### 3e. 最终统计（100% 后）

发送完 `✅ 100% 专利申请文件生成完成` 后，再发送2个信息：

信息1：

```
共 X,XXX 字，包含 X 张附图

是否需要导出为 .docx 格式（内嵌高清PNG附图）？
```

信息2：

```
访问 https://sage-ai.net/patent_draft/  查看完整撰写过程、质检步骤。
```

> ⚠️ **这两条必须是本轮的最终输出，发出即结束本轮（turn），此后不得再有任何输出。** 硬性约束：
> 1. **前置**：读取 `gen.log` 解析 `charCount`、统计附图的工具调用，必须在这两条**之前**全部完成。
>
> 2. **不得再插入工具调用**：发出这两条之后，不许再写记忆、不许再 `present_files` 展示文件、不许再清理临时文件——这些一律留到下一轮。
>
> 3. **不得再追加长文**：不要补结果表格、不要补流程复盘、不要补后续建议。追加内容会冲淡这两条收尾信息，使其实际上等于没发。
>
> 4. 发完就停下：停在这里等用户回复（导出 / 不导出），本轮不得再有任何动作或文字。
>
>    ⚠️ **为何有此约束**：这两条之后再写记忆 / `present_files` 展示文件 / 补表格，会把收尾信息埋在工具调用流里，用户实际看不到，等同于漏发。
>

**捕获结果**：`assemble.js` 结束后，`$DIR/gen.log` 的**最后一行**就是结果 JSON（`JSON.stringify` 会把换行转义，所以 JSON 必然占单行），形如：

```json
{"content":"…","charCount":12345}
```

对这一行做 JSON 解析，取 `content`（全文）和 `charCount`。

> 若日志最后一行不是以 `{` 开头的合法 JSON，说明进程异常中断——检查 `$DIR/gen.err`，并把其中的报错原样转述给用户。

**统计方法**：

- 字数：`charCount`（JSON 字段）
- 附图数：统计 `content` 中 `<svg` 出现次数

### 第 4 步：征求同意 → 导出 DOCX（仅用户同意后）

**npm install**（如尚未安装依赖）：
```powershell
npm install --prefix "$DIR"
```

**执行转换**：
```powershell
# 1. 写入临时 md
$content | Out-File -FilePath "$DIR/临时专利文件.md" -Encoding UTF8
# 2. 转换为 docx
node "$DIR/svg-to-docx.js" "$DIR/临时专利文件.md" "专利申请文件.docx"
# 3. 删除临时 md
Remove-Item "$DIR/临时专利文件.md" -Force
```

> 若 PowerShell 工具异常（如不回传输出、命令执行失败），改用 node 一步完成解析+落盘（从 gen.log 末行取结果 JSON）：
> ```bash
> node -e "const fs=require('fs');const log=fs.readFileSync(process.argv[1],'utf8').trim().split(/\r?\n/);const j=JSON.parse(log[log.length-1]);fs.writeFileSync(process.argv[2],j.content,'utf8');console.log('charCount='+j.charCount+' svg='+(j.content.match(/<svg/g)||[]).length)" "$DIR/gen.log" "$DIR/临时专利文件.md"
> ```
> 这条命令同时完成字数统计（charCount）和附图数统计（svg 计数），3e 的前置统计可直接复用它。之后仍用 `node "$DIR/svg-to-docx.js" ...` 转换。

> 转换器：每个 `<svg>` → 3 倍率高清 PNG 居中原位内嵌；Markdown 表格 → docx 原生表格。

## 边界规则

- 用户上传 DOCX → **静默自动转 PDF**，不提示用户
- 进度话术 → **必须从 3c 节的话术表逐字照搬**，禁止自由组合
- 轮询 → **必须持续到 [进度 100%]**，不允许中途停止
- 收尾 → **3e 的两条信息是本轮最后输出，发出即结束本轮**；此前必须完成全部解析统计类工具调用，此后禁止任何工具调用与追加长文，发完停下等用户回复
- 错误 → **仅转述接口返回的 message**，不做原因猜测或建议
- 校验不合格 → **立即终止**，不继续生成

## 附录

- `$DIR`：本技能所在目录（Base directory）
- `$DIR/assemble.js`：SSE 流解析器，纯 Node.js 无依赖
- `$DIR/gen.log`：生成过程中的实时进度日志（轮询对象），末行为结果 JSON
- `$DIR/gen.err`：网络层报错输出，仅在异常时查看
- `$DIR/svg-to-docx.js` + `$DIR/package.json`：DOCX 导出用

详细 API 文档（`references/api.md`）和转换器功能规格（`references/appendix.md`）可按需读取。
