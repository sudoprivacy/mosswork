# -*- coding: utf-8 -*-
"""DDI 筛查案例集 Word 文档生成器（数据驱动）

用法:
    python gen_case_docx.py                         # 默认读 ../assets/sample_cases.json，否则用内置样例
    python gen_case_docx.py --cases path.json --out out.docx

数据结构见各 skill 的 SKILL.md「CASES 数据结构」。每条案例字段:
    序号, 标题, 涉及药物, 相互作用机制, 风险等级,
    案例背景, 合并用药, 相互作用机制(详), 风险分级, 处置建议, 点评与启示
正文支持 **加粗** 标记（渲染为粗体）。
"""
import argparse
import json
import os
import re
import sys

from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ===================== 本 skill 专属配置 =====================
TITLE = '药物相互作用筛查案例集'
SUBTITLE = '按"案例背景→合并用药→相互作用机制→风险分级→处置建议→点评与启示"六段式输出'
SUMMARY_COLS = ['序号', '标题', '涉及药物', '相互作用机制', '风险等级']
COL_WIDTHS = [Cm(1.0), Cm(5.0), Cm(3.4), Cm(3.0), Cm(2.0)]
SECTIONS = ['案例背景', '合并用药', '相互作用机制', '风险分级', '处置建议', '点评与启示']
# ===========================================================

NAVY = (0x1F, 0x3B, 0x6E)
GRAY = (0x66, 0x66, 0x66)
DARK = (0x44, 0x44, 0x44)


def set_cell_border(cell, top=None, bottom=None, left=None, right=None):
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = OxmlElement('w:tcBorders')
    for edge, spec in (('top', top), ('left', left), ('bottom', bottom), ('right', right)):
        if spec is None:
            continue
        b = OxmlElement(f'w:{edge}')
        b.set(qn('w:val'), spec.get('val', 'single'))
        b.set(qn('w:sz'), str(spec.get('sz', 6)))
        b.set(qn('w:color'), spec.get('color', '000000'))
        tcBorders.append(b)
    tcPr.append(tcBorders)


def add_heading(doc, text, level=1):
    h = doc.add_paragraph()
    run = h.add_run(text)
    run.font.name = '黑体'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    run.font.size = Pt(18 if level == 0 else (14 if level == 1 else 12))
    run.font.bold = True
    run.font.color.rgb = RGBColor(*NAVY)
    h.alignment = WD_ALIGN_PARAGRAPH.LEFT if level > 0 else WD_ALIGN_PARAGRAPH.CENTER
    return h


def add_section_label(doc, label, body_text):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.3
    r1 = p.add_run(f'【{label}】')
    r1.font.bold = True
    r1.font.name = '黑体'
    r1._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    r1.font.size = Pt(10.5)
    r1.font.color.rgb = RGBColor(*NAVY)
    for part in re.split(r'(\*\*[^*]+\*\*)', body_text or ''):
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            r = p.add_run(part[2:-2]); r.font.bold = True; r.font.size = Pt(10.5)
        else:
            r = p.add_run(part); r.font.size = Pt(10.5)
    return p


def add_paragraph(doc, text, align='left', size=10.5, bold=False, italic=False, color=None):
    p = doc.add_paragraph()
    p.alignment = {'left': WD_ALIGN_PARAGRAPH.LEFT, 'center': WD_ALIGN_PARAGRAPH.CENTER,
                   'right': WD_ALIGN_PARAGRAPH.RIGHT}[align]
    p.paragraph_format.line_spacing = 1.3
    p.paragraph_format.space_after = Pt(4)
    for part in re.split(r'(\*\*[^*]+\*\*)', text or ''):
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            r = p.add_run(part[2:-2]); r.font.bold = True
        else:
            r = p.add_run(part)
        r.font.size = Pt(size)
        if italic:
            r.font.italic = True
        if color:
            r.font.color.rgb = RGBColor(*color)
    return p


def build_summary_table(doc, cases):
    rows = [SUMMARY_COLS]
    for c in cases:
        rows.append([str(c.get(col, '')) for col in SUMMARY_COLS])
    tbl = doc.add_table(rows=len(rows), cols=len(SUMMARY_COLS))
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = False
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = tbl.cell(i, j)
            cell.width = COL_WIDTHS[j] if j < len(COL_WIDTHS) else Cm(3)
            cell.text = ''
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if j == 0 else WD_ALIGN_PARAGRAPH.LEFT
            run = p.add_run(val)
            run.font.size = Pt(9)
            run.font.name = '宋体'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
            if i == 0:
                run.font.bold = True
                run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                shd = OxmlElement('w:shd')
                shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), '1F3B6E')
                cell._tc.get_or_add_tcPr().append(shd)
                set_cell_border(cell, top={'sz': 18}, bottom={'sz': 6})
            elif i == len(rows) - 1:
                set_cell_border(cell, bottom={'sz': 18})
            else:
                set_cell_border(cell)
    return tbl


def render(cases, out_path, title=TITLE, subtitle=SUBTITLE):
    doc = Document()
    style = doc.styles['Normal']
    style.font.name = '宋体'
    style.font.size = Pt(10.5)
    style._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

    add_heading(doc, title, level=0)
    if subtitle:
        add_paragraph(doc, subtitle, align='center', size=11, italic=True, color=GRAY)

    intro = ('本案例集依据 CYP450、P-糖蛋白、QTc、药效动力学及电解质相关相互作用机制与风险分级（禁忌/严重/中等/轻微）整理，'
             '供临床药师培训、审核与考核场景模拟使用。')
    add_paragraph(doc, intro, size=10.5, color=DARK)

    add_heading(doc, '一、案例选题汇总', level=1)
    build_summary_table(doc, cases)
    doc.add_paragraph()

    add_heading(doc, '二、案例详情', level=1)
    for c in cases:
        add_heading(doc, f"案例 {c.get('序号', '')}　{c.get('标题', '')}", level=2)
        for label in SECTIONS:
            if label in c and c[label]:
                add_section_label(doc, label, c[label])

    add_heading(doc, '三、统一免责声明', level=1)
    add_paragraph(doc,
        '本案例集为临床药师培训与药物相互作用审查场景模拟用资料，所有评价均依据药品说明书、'
        '权威数据库及循证证据整理，不替代临床医师或药师的个体化判断与法定责任。'
        '面对真实患者时，请结合具体病情综合判断，必要时建议线下就医并履行核对流程。**所有用药调整须由药师与处方医师共同确认。**',
        size=10, color=DARK)

    doc.save(out_path)
    return out_path


SAMPLE_CASES = [
    {
        "序号": 1,
        "标题": "华法林联用氟康唑致 INR 飙升出血",
        "涉及药物": "华法林 + 氟康唑",
        "相互作用机制": "CYP2C9 抑制",
        "风险等级": "严重",
        "案例背景": "女，71 岁，房颤长期服**华法林 3 mg qd**，INR 稳定在 2.3。因念珠菌性阴道炎加用**氟康唑 150 mg qd**，1 周后牙龈出血、皮下瘀斑，INR 升至 5.8。",
        "合并用药": "华法林 3 mg 每日；氟康唑 150 mg 每日（CYP2C9 强抑制剂）。",
        "相互作用机制": "氟康唑抑制 CYP2C9，减慢 S-华法林代谢，使抗凝强度显著增强，INR 升高、出血风险上升。",
        "风险分级": "**严重（C）**：治疗窗窄、出血后果重，需立即调整并监测。",
        "处置建议": "暂停华法林，监测 INR 至回落；氟康唑疗程结束后重启华法林并减量，起始 1.5–2 mg qd，2–3 天复查 INR；向患者强调出血征象就医。",
        "点评与启示": "唑类抗真菌药与华法林联用是经典高危组合，处方前须预警；可优先选局部抗真菌药规避全身相互作用。"
    },
    {
        "序号": 2,
        "标题": "胺碘酮联用索他洛尔的 QTc 延长风险",
        "涉及药物": "胺碘酮 + 索他洛尔",
        "相互作用机制": "QTc 延长叠加",
        "风险等级": "严重",
        "案例背景": "男，64 岁，室性早搏在用**索他洛尔 80 mg bid**；因房颤加用**胺碘酮 200 mg qd**，复查心电图 QTc 由 460 ms 延长至 580 ms。",
        "合并用药": "索他洛尔 80 mg 每日 2 次；胺碘酮 200 mg 每日。",
        "相互作用机制": "两药均延长 QT 间期并延长心肌复极，叠加显著升高尖端扭转型室速风险。",
        "风险分级": "**严重（C）**：可致致死性心律失常，原则上避免联用。",
        "处置建议": "建议停一种抗心律失常药，改单药或非负性频率依赖方案；联用期间持续心电监护、纠正电解质（钾镁），设定 QTc 干预阈值（>500 ms 停药）。",
        "点评与启示": "两类药物均属「QT 延长药」，叠加须启动心电与电解质监测；处方系统应设相互作用硬警示。"
    }
]


def main():
    parser = argparse.ArgumentParser(description='生成 DDI 筛查案例集 Word 文档')
    here = os.path.dirname(os.path.abspath(__file__))
    default_cases = os.path.join(here, '..', 'assets', 'sample_cases.json')
    parser.add_argument('--cases', default=default_cases, help='案例 JSON 数据路径')
    parser.add_argument('--out', default='DDI筛查案例集.docx', help='输出 docx 路径')
    parser.add_argument('--title', default=TITLE, help='文档标题')
    args = parser.parse_args()

    if os.path.exists(args.cases):
        with open(args.cases, encoding='utf-8') as f:
            data = json.load(f)
        cases = data.get('cases') if isinstance(data, dict) else data
    else:
        cases = SAMPLE_CASES
        print('[INFO] 未找到案例 JSON，使用内置样例。')

    out = os.path.abspath(args.out)
    render(cases, out, title=args.title)
    print('SAVED:', out)


if __name__ == '__main__':
    main()
