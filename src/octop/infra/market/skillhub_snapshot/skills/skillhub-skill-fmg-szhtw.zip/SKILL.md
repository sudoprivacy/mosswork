---
name: skillhub-skill-fmg-szhtw
description: "通用「公众号推文生成 + 套 w母板排版 + 提交草稿箱」技能。把任意主题（工具教程、案例复盘等）写成一篇带引言框标题卡、PART 章节、写在最后、且整篇左对齐的公众号推文并直接存进草稿箱。严格复刻信息疯神榜 w母板的翡翠绿视觉语言（标题卡 / 写在最后 / 绿框金句 / 关于作者 / 三连卡 / 往期回顾）。自包含：已内置 template_layout.py，无需额外安装 fmg-xxfsb。排版规则（v1.2.3 修复文章尾部 chrome）：**尾部完整保留「关于作者」简介块 + 「三连」提示卡 + 往期回顾挂件，三连卡保持居中排版并紧贴往期回顾**；PART 章节头为母板原版两行版式（左列 28px 翡翠绿大数字 + 8px 灰字「PART」，右列 17px 深灰主标题 + 11px 灰副标题）；标题卡外框不设 padding、内边距交给内容层，翡翠绿渐变底栏顶到方框左右两端并随"
---

# 公众号推文生成（套 w母板 + 存草稿箱 + 全文左对齐）

> 本 skill 沉淀自「班主任工作台」推文的实际产出流程，可复用于任意主题的公众号长文。当前版本（1.2.3）已适配 2026.08 更新的 w母板结构，累计修复「标题卡绿色底栏顶不到方框两头」「PART 章节头只有一行、样式不对」「文章尾部缺失关于作者 + 三连提示」「三连卡与往期回顾间隙过大」「往期回顾矩阵与后台回复提示图间隙过大」五个问题，开箱即用。

## 一、适用场景

- 用户想把某个主题（工具教程、实操案例、复盘）写成一篇**结构化公众号推文**，并直接存进草稿箱。
- 文章用到信息疯神榜 **w母板** 的视觉语言：
  - 引言上方一个**引言框同款标题卡**（翡翠绿描边 `rgb(102,158,73)` + 渐变底栏）
  - PART 编号章节头（**两行版式**：左列 28px 翡翠绿大数字 + 8px 灰字 `PART`；右列 17px 深色主标题 + 11px 灰副标题）
  - **写在最后**标题（w母板同款 `///` + `LAST` + 标题 + 副标题），内容不整段放框，仅金句放框
  - 翡翠绿配色体系
- 排版规则（当前正确版本，已全部内置）：
  - **标题卡绿色底栏顶到方框左右两端**（v1.2.1 修复）：外框 section **不设 padding**，内边距全部交给「内容层」，底栏作为外框的直接子级铺满整宽；外框 `overflow:hidden` + 底栏 `border-radius:0 0 9px 9px` 保证底部圆角与外框一致
  - **整篇文字左对齐**（含正文与页脚，修复了母板外层容器 `text-align:center` 继承导致的「看着像居中」的坑）
  - **正文 14px、行距 2**（默认 15px/1.9 已被覆盖）
  - **PART 章节头两行、颜色分层**（v1.2.2 修复）：左列 = `28px/900 翡翠绿 rgb(5,150,105)` 大数字 + `8px/700 灰 rgb(209,213,219)` 的「PART」小字（列内居中）；右列 = `17px/900 深灰 rgb(17,24,39)` 主标题 + `11px/600 灰 rgb(156,163,175)` 副标题。**不是**「绿底白字圆角徽章 + 单行标题」，也不要把副标题留空
  - **正文前不插任何装饰图**（早期那张红星星 gif 已移除）
  - **模板示例空白段已剔除**：正文区整体由 `build_middle` 替换，母板示例正文不会漏进正文前
  - **尾部 chrome 完整保留**（v1.2.3 修复）：文章收尾依次为 **关于作者简介块 → 三连提示卡（点赞 / 在看 / 转发 + THANKS FOR READING）→ 往期回顾矩阵 + 关注 CTA**
  - **三连卡保持居中排版并紧贴往期回顾**（v1.2.3 修复）：三连卡是居中卡片，必须排除在「全文左对齐」之外；其外框下外边距归零，避免与往期回顾之间出现过大空白带
  - **往期回顾矩阵卡片原样保留**（`data-mp-plugin="96weixin"` 动态挂件，卡片布局由平台渲染）；但矩阵**之后**到「后台回复」提示图之间的关注条区间距会被 `tighten_matrix` 定向收紧（v1.2.5）：`padding: 1em` / `margin: 10px 0px` / `padding: 10px` 归零，提示图 gif 的 `width: 578px` 改为与正文等宽
  - **结尾★区块移除**，原位置留**两空行**，供作者在草稿箱自行补充内容

## 二、前置条件

1. **微信凭证**：**必须**设置环境变量 `WX_APPID` 与 `WX_SECRET`（公众号后台「基本配置」获取）。脚本不内置任何凭证，**切勿把 AppSecret 写进文件后上传分享**。
2. **母板**：草稿箱里存在标题含「**w母板**」的草稿（顶部 banner + 公众号名片 + 引言标题卡 + 关于作者 + 三连卡 + 往期回顾挂件）。脚本用 `template_layout.split_template` 自动切分头尾 chrome：**头 = 首个 `data-pm-slice="0 0 []"` 之前；尾 = 「关于作者」所在顶层 section 起**（一次带回 关于作者 + 三连卡 + 往期回顾）。
3. **出口 IP**：运行机出口 IP 必须加进公众号后台「IP 白名单」，否则报 40164（注：微信日志里的 `::ffff:` 只是 IPv6 记法，本质就是白名单没填这个 IPv4）。
4. **运行环境**：Python 含 `requests` + `Pillow`。本机示例：`C:/Users/Administrator/.workbuddy/binaries/python/envs/default/Scripts/python.exe`。
5. **自包含**：本 skill 已自带 `scripts/template_layout.py`，**无需额外安装 fmg-xxfsb**。

## 三、工作流程

1. 用 `requests` 换 token，拉取草稿箱，定位「w母板」与待更新/新增的目标草稿。
2. 调用 `scripts/build_wechat_article.py`——**配置驱动**：改脚本顶部 `ARTICLE` 配置（标题卡、引言、各 PART、写在最后）即可。`LEFT_ALIGN=True` 控制全文左对齐；`XXFSBTW_TARGET` 环境变量控制原地更新的目标草稿（留空＝新增）。
3. 可选：用 ImageGen 生成封面，设环境变量 `XXFSBTW_COVER` 指定图源（脚本会另存全幅交付物，并自动裁切 **900×383** 上传为永久素材）；若主封面是 16:9，建议**同时**用 `XXFSBTW_THUMB` 指定一张宽幅专用图（直接缩放、不裁切，避免 2.35:1 裁掉封面上下内容）；都不填则回退母板封面。
4. 可选：正文插图走脚本顶部 `BODY_IMG_SPECS` 配置——每项 `{"env": "XXFSBTW_IMG_1", "part_no": "02", "caption": "..."}`，按 PART 编号自动插入。
5. `draft/add`（新增）或 `draft/update`（原地更新）提交，并回读校验。

## 四、关键格式（务必严格套用草稿箱真实结构）

| 部位 | 套用来源 | 要点 |
|---|---|---|
| 引言上方标题卡 | 草稿箱「引言框」文章 | 结构：外框 `border rgb(102,158,73)` + `border-radius:10px` + `overflow:hidden`，**外框不设 padding**；内容层 `padding:32px 28px 28px`（kicker+渐变线+日期、删除线、24px 大标题、底部标签行）；**翡翠绿渐变底栏贴外框左右**（`padding:12px 28px`、`border-radius:0 0 9px 9px`）。**日期默认自动取当前年月**，需固定时用 `intro_card.date`（如 `"2026.08"`）覆盖 |
| PART 章节 | w母板章节头 | flex 左编号右标题：**左列 28px 翡翠绿大数字 + 8px 灰字「PART」**（`text-align:center` 居中，外包 `data-keep-center="1"` 防左对齐清洗）；**右列 17px/900 主标题 + 11px/600 灰副标题**（两行、颜色分层）。副标题文案形如 `TWO ASSISTANTS · 分工与定位`。**必须给每个 part 配 `sub`** |
| 写在最后标题 | w母板 | flex 块：左 `///`+`LAST`，右「写在最后」17px/900 + 副标题（`WRAP-UP · …`） |
| 写在最后正文 | 用户要求 | **不要**整体放框；仅末句金句单独 `green_card`（内边距 12px） |
| 尾部·关于作者 | w母板 | 「关于作者」四字带翡翠绿下划线（`text-decoration-color: rgb(122,235,129)` + `text-underline-offset:5px`）+ 简介句，`line-height:2em`；随正文左对齐 |
| 尾部·三连卡 | w母板 | 圆角卡（`border-radius:16px` + 浅灰径向渐变底 + 1px 灰边）：`既然看到这里了…点赞、在看、转发三连吧` + 三个图标格（**转发格用翡翠绿高亮**）+ `THANKS FOR READING`。**居中排版，禁止左对齐清洗**；外框下外边距归零 |
| 尾部·往期回顾 | w母板 | `data-mp-plugin="96weixin"` 平台挂件（96编辑器矩阵 + 底部关注 CTA），**原样保留，不改 width/padding/text-align** |
| 结尾 | 已移除★区块 | 原位置留**两空行**（`ending_html`），由作者在草稿箱自行添加内容 |

## 五、关键坑（踩过的，已写入脚本内置处理）

- 微信接口 JSON **必须 `ensure_ascii=False` + `charset=utf-8`**，否则大段中文被静默丢弃。
- `draft/batchget` 返回键是 `item`（非 itemlist）。
- 字段字节限制：`title<=64` / `digest<=120` / `author<=8`（**是 8 个汉字字符，不是 8 字节**）。超了脚本会截断并加「…」。`冯萌刚` 仅 3 字，按字符直接发送，由回读校验落库值，避免本地字节截断把名字截成「冯萌」。
- `ARTICLE` 配置里凡调用 `T.b()/T.bd()/T.code()` 的字符串**必须是 f-string 且用单引号定界**（如 `f'…{T.b("x")}…'`）。用双引号定界会因内部 `T.b("…")` 的双引号冲突直接 SyntaxError；漏写 `f` 前缀则 `T.b` 会原样输出成文字。
- **正文里不要用英文半角双引号 `"…"`**：即使写在 `T.bd("…")` 的参数内部，也会提前闭合外层双引号导致 `SyntaxError`。中文引号一律用「」或""。
- 提交校验 `marker` **不能是会被改写掉的字面量**，用正文稳定金句（如「写在最后」）。
- **沙箱内 `urllib` 被拦截**，必须用 `requests`。
- 出口 IP 变化 → 40164，需重新加白名单。
- **整篇左对齐的真正坑（重点）**：`split_template` 把正文嵌进 w母板「`text-align:center`」外层 section，正文段落自身无 `text-align` 会**继承居中**；只替换正文字面 `center` 无效。脚本用「逐标签强写 `text-align:left`（`_force_left`）+ 正文/页脚各包一层 `text-align:left` section」双保险解决，且**不动母板 banner 本身**。
- **🆕 PART 章节头「只有一行、样式不对」（v1.2.2 修复，重点坑）**：旧版在 build 脚本顶部用 `T.part_header = _part_header` 覆盖了库函数，输出「绿底白字圆角徽章 + 单行标题」，与母板不一致（母板是数字列 + 「PART」小字 + 右侧两行主副标题）。修法：**删掉该 override，统一用 `template_layout.part_header`**，并确保 `ARTICLE["parts"][*]["sub"]` 有副标题文案（留空会导致右列只剩一行）。
- **`data-keep-center="1"` 必须保留**：PART / 写在最后的左侧编号列（`01`+`PART`、`///`+`LAST`）在母板里是列内居中的；全文左对齐清洗（`_left_align`）会先把该块整体 stash 起来再替换 `text-align:center`，最后回填。删掉这个属性会让「PART」跑到数字左侧。
- **🆕 标题卡底栏「顶不到方框两头」（v1.2.1 修复，重点坑）**：绿色渐变底栏是标题卡外框的**子元素**。只要外框带 `padding`，底栏就会被左右各顶进相应距离，视觉上像「没占满方框」。修法：外框 `padding:0` + `overflow:hidden`，内边距下放到内容层（`padding:32px 28px 28px`），底栏再补 `border-radius:0 0 9px 9px` 跟随外框圆角。**不要**给外框留 padding 再用负 margin 去补（微信编辑器对负 margin 的裁剪不可靠）。
- **不要在主流程做全局 `padding` 字符串替换**：旧版用 `middle.replace('padding:15px','padding:12px')` 统一卡片内边距，会顺手把标题卡等其它元素一起改掉。现改为在脚本顶部 `override T.green_card` 精确处理。
- **🆕 微信草稿缩略图是 2.35:1，16:9 主封面会被居中裁掉上下（v1.2.3 修复）**：1920×1080 主封面按 2.35:1 居中裁切后，上下各切掉约 131px——顶部小标签被削、底部绿色署名栏整条消失。修法：**做一张宽幅专用缩略图，用环境变量 `XXFSBTW_THUMB` 传入**（脚本直接缩放到 900×383，不再裁切）。两张图各自独立排版，才是正解。
- **🆕 正文插图源文件放在微信临时目录会失效**：从聊天记录里拷出来的图常在 `...\xwechat_files\<id>\temp\RWTemp\...`，微信会清理。上传前**先复制到工作目录**再交给脚本。
- **🆕 正文插图不要硬编码 PART 下标**：旧版把两张图写死进 `parts[1]` / `parts[2]` 并写死文案，换主题即失效。现用 `BODY_IMG_SPECS` 声明式配置，按 `part_no` 定位，未命中会告警而不是静默插错位置。
- **🆕 文章尾部「关于作者 + 三连提示」整段丢失（v1.2.3 修复，重点坑）**：症状是文章末尾只剩空白、正文与往期回顾之间出现一大片空隙。根因是尾部切分点被设在**往期回顾挂件**上（`data-mp-plugin="96weixin"`），而母板里紧挨它前面的「关于作者」简介块与「三连」提示卡就一起被当成母板示例正文丢掉了。修法：`split_template` 的尾部起点改回**「关于作者」所在顶层 section**，一次带回 关于作者 + 三连 + 往期回顾。副产品：三连卡是居中卡片，必须用 `split_footer` 单独切出来、**跳过左对齐清洗**，否则卡片会被拉歪；同时 `tighten_cta` 把卡片外框的 `margin-bottom:24px` 归零，消除它与往期回顾之间那条过大的空白带。
- **🆕 往期回顾矩阵与「后台回复」提示图之间空隙过大（v1.2.5 修复）**：母板挂件（`data-mp-plugin="96weixin"`）内部，矩阵之后到提示图之前夹着一个「关注条」区（锚点文案「再不关注将损失1个亿」），其容器层层叠加 `padding: 1em` + `margin: 10px 0px`×2 + `padding: 10px`，在手机端叠出约 100px 空白带；提示图 gif 又写死 `width: 578px`，与全文等宽策略不一致。修法 `template_layout.tighten_matrix()`：以关注条锚点定位区间起点（含 `padding: 1em` 的 section 再上爬一层拿到 width 容器），区间内三类间距归零、`width: 578px`→`width: 100%`；**矩阵卡片本身不动**（布局由平台渲染）。锚点找不到时原样返回，绝不瞎改。
- **🆕 母板副本编码错误会让中文关键词全部搜不到（v1.2.3 记录的教训）**：如果本地保存的母板 HTML 编码错了（mojibake，中文变成 `å…³äºŽä½œè€…` 之类），`content.find("关于作者")` 会返回 -1。**上一条 bug 就是这么来的**——当时误判「新母板已去掉『关于作者』文字」，才把尾部切分点改到了往期回顾挂件。**排查前先确认读文件的编码是 utf-8**；若怀疑编码错，可用 `s.encode("latin-1").decode("utf-8")` 试着还原后再搜关键词。
- **不要覆盖 `split_template`**：切分逻辑（头 = 首个 `data-pm-slice="0 0 []"` 之前；尾 = 「关于作者」起）统一由 `template_layout.split_template` 提供，**任何"顺手改一下切分点"都会连带丢掉整段页脚**。若母板改版导致尾部三块的位置变了，只调 `split_template` / `split_footer`，不要在 build 脚本里额外覆盖。
- **改完一定要跑离线自检**：`scripts/check_layout.py` 已把踩过的坑固化为 17 条断言（底栏贴边、PART 两行版式、防旧徽章样式、尾部 关于作者→三连→往期回顾 的顺序与居中不被污染等）。本地全绿再提交草稿（新增矩阵-提示图区间断言）箱，避免来回试错。
- AppSecret 等同密码，用后建议用户在公众号后台重置。

## 六、调用示例

```bash
# 1) 改 scripts/build_wechat_article.py 顶部 ARTICLE / 凭证
# 2) 运行（注意用含 requests+Pillow 的 venv）
"C:/Users/Administrator/.workbuddy/binaries/python/envs/default/Scripts/python.exe" \
  "C:/Users/Administrator/.workbuddy/skills/fmg-szhtw/scripts/build_wechat_article.py"
# 3) 离线版式自检（不联网，可选但推荐）：底栏贴边 / 金句卡 padding / 尾部 chrome 完整性
"C:/Users/Administrator/.workbuddy/binaries/python/envs/default/Scripts/python.exe" \
  "C:/Users/Administrator/.workbuddy/skills/fmg-szhtw/scripts/check_layout.py" \
  "C:/Users/Administrator/.workbuddy/skills/fmg-szhtw/scripts/preview.html"
```

脚本会写出本地预览 HTML（`scripts/preview.html`）、自动上传封面（若配置）、提交/更新草稿箱并打印校验结果。仅本地预览不提交时加环境变量 `XXFSBTW_DRY=1`。原地更新已有草稿：`XXFSBTW_TARGET="关键词"` 指定标题包含该关键词的草稿。

## 七、复用关系

- **自包含**：`scripts/template_layout.py` 已随本 skill 分发（仅依赖 requests/json/re/os），脚本优先用自带副本，无需额外安装 `fmg-xxfsb`。
- 视觉函数 `intro_title_card`（标题卡，含贴边底栏）/ `write_last_header` 在本 skill 脚本内独立实现（因需严格套用草稿箱真实结构）。
- `scripts/check_layout.py` 提供**离线版式断言**，改版后可先本地跑通再提交草稿箱，避免来回试错。
- **凭证安全**：AppID/AppSecret 仅从环境变量 `WX_APPID` / `WX_SECRET` 读取，脚本内不含任何真实凭证。
