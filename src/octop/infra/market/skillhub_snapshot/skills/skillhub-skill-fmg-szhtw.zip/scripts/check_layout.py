#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""check_layout.py —— 离线版式自检（不联网、不调微信接口）。

用法：
    python check_layout.py [html文件]        # 默认检查同目录 preview.html

断言项：
  1. 标题卡翡翠绿渐变底栏「贴边」：底栏祖先链中非零 padding 层数必须为 0；
  2. 绿框金句卡内边距为 12px；
  3. 页脚保留 w母板往期回顾挂件（data-mp-plugin="96weixin"）；
  4. 正文区存在「写在最后」章节头；
  4.1 尾部 chrome 完整：关于作者块 + 三连卡（点赞/在看/转发 + THANKS FOR READING），
      且顺序为「写在最后 → 关于作者 → 三连卡 → 往期回顾」；
  4.2 三连卡保持居中排版（不能被「全文左对齐」改写）；
  4.3 三连卡下外边距已归零（避免与往期回顾之间出现过大空白带）；
  4.4 往期回顾矩阵与「后台回复」提示图之间空隙已收紧（关注条区间距归零 + 提示图等宽）；
  5. PART 章节头版式对齐 w母板。

退出码：0 = 全部通过；1 = 有断言失败。
"""
import sys, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
BAR = 'linear-gradient(135deg, rgb(5,150,105), rgb(16,185,129)'


def _ancestors(html, idx):
    """返回 html[:idx] 中仍未闭合的 <section> 开标签栈（由外到内）。"""
    stack, pos = [], 0
    tag = re.compile(r'<section\b[^>]*>|</section>')
    while True:
        m = tag.search(html, pos, idx)
        if not m:
            break
        if m.group(0).startswith('</'):
            if stack:
                stack.pop()
        else:
            stack.append(m.group(0))
        pos = m.end()
    return stack


def _style(tag):
    m = re.search(r'style="([^"]*)"', tag)
    return m.group(1) if m else ''


def _pad_nonzero(tag):
    m = re.search(r'padding:\s*([^;]+)', _style(tag))
    if not m:
        return False
    v = m.group(1).strip()
    return not re.match(r'^0(\s|$|px)', v)


def check(path):
    html = open(path, encoding='utf-8').read()
    results = []

    # 1) 底栏贴边：从底栏往外的祖先链里，找到「绿色描边外框」那一层，
    #    两者之间不能再有带 padding 的层（否则底栏会被顶进留白）。
    i = html.find(BAR)
    if i < 0:
        results.append(('标题卡底栏存在', False, '未找到翡翠绿渐变底栏'))
    else:
        stack = _ancestors(html, i)
        green_idx = None
        for k in range(len(stack) - 1, -1, -1):
            if 'rgb(102,158,73)' in _style(stack[k]):
                green_idx = k
                break
        if green_idx is None:
            results.append(('找到绿色描边外框', False, '底栏祖先链中无 rgb(102,158,73) 边框层'))
        else:
            inner = stack[green_idx + 1:]
            bad = [t for t in inner if _pad_nonzero(t)]
            results.append(('标题卡底栏贴边（与绿框之间无非零 padding）', len(bad) == 0,
                            f'绿框内、底栏之上的 padding 层数 = {len(bad)}'))
            results.append(('外框为绿色描边容器', True, '外框样式: ' + _style(stack[green_idx])[:60]))

    # 2) 金句卡 padding
    m = re.search(r'border:1px solid rgb\(102,158,73\)[^>]*?padding:\s*([^;"]+)', html)
    gc = m.group(1).strip() if m else None
    results.append(('绿框金句卡内边距 = 12px', gc == '12px', f'实际 = {gc}'))

    # 3) 页脚挂件
    results.append(('页脚保留往期回顾挂件', 'data-mp-plugin="96weixin"' in html,
                    'data-mp-plugin="96weixin" 出现次数 = %d' % html.count('data-mp-plugin="96weixin"')))

    # 4) 写在最后
    results.append(('含「写在最后」章节头', '写在最后' in html, ''))

    # 4.1) 尾部 chrome：关于作者 + 三连卡 必须存在且顺序正确
    #      （历史 bug：尾部切分点误设到往期回顾挂件，把这两块整段丢掉 → 文章末尾空白）
    i_about = html.find('关于作者')
    i_cta = html.find('既然看到这里了')
    i_thanks = html.find('THANKS FOR READING')
    i_matrix = html.rfind('data-mp-plugin="96weixin"')
    results.append(('含「关于作者」简介块', i_about > 0, f'下标 = {i_about}'))
    results.append(('含「三连」提示卡（点赞/在看/转发 + THANKS FOR READING）',
                    i_cta > 0 and i_thanks > 0,
                    f'既然看到这里了 = {i_cta} / THANKS FOR READING = {i_thanks}'))
    ordered = all(x > 0 for x in (i_about, i_cta, i_thanks, i_matrix)) and \
        i_about < i_cta < i_thanks < i_matrix
    results.append(('顺序：关于作者 → 三连卡 → 往期回顾',
                    ordered,
                    f'{i_about} < {i_cta} < {i_thanks} < {i_matrix}'))

    # 4.2) 三连卡不能被「全文左对齐」污染（卡片本身居中排版）
    if i_cta > 0 and i_matrix > i_cta:
        cta = html[i_cta:i_matrix]
        results.append(('三连卡保持居中、未被左对齐改写',
                        'text-align: center' in cta and 'text-align:left' not in cta,
                        'text-align: center = %d 处 / text-align:left = %d 处'
                        % (cta.count('text-align: center'), cta.count('text-align:left'))))

    # 4.3) 三连卡下外边距归零（否则与往期回顾之间会有一条过大的空白带）
    if i_cta > 0:
        head = html[max(0, i_cta - 600):i_cta]
        results.append(('三连卡与往期回顾之间的空隙已收紧',
                        'margin: 0px 0px 24px;' not in head,
                        '卡片外框不应再带 margin-bottom: 24px'))

    # 4.4) 往期回顾矩阵与「后台回复」提示图之间的空隙已收紧
    #      （母板挂件内关注条区的 padding/margin 叠加 + 提示图写死 578px 所致）
    i_gap = html.find('再不关注将损失1个亿')
    if i_gap > 0:
        # 关注条容器（向上爬到含 width 的层）与提示图之间不应再有大间距
        seg = html[i_gap:i_gap + 6000]
        results.append(('矩阵-提示图区间：关注条容器间距已归零',
                        'padding: 1em' not in seg and 'margin: 10px 0px' not in seg
                        and 'padding: 10px' not in seg,
                        '区间内不应再出现 padding: 1em / margin: 10px 0px / padding: 10px'))
        # 提示图 gif 应与正文等宽（width: 100%），不再写死 578px
        tail = html[i_gap:]
        results.append(('提示图与正文等宽（无写死 width: 578px）',
                        tail.count('width: 578px') == 0,
                        f'区间内 width: 578px 残留 {tail.count("width: 578px")} 处'))
    else:
        results.append(('矩阵-提示图区间锚点存在', False, '未找到「再不关注将损失1个亿」，母板可能改版'))

    # 5) PART 章节头版式（严格对齐 w母板：28px 大数字 + PART 小字 + 17px 主标题 + 11px 副标题）
    n_part = html.count('>PART</span>')
    results.append(('PART 章节头数量 > 0', n_part > 0, f'PART 小字出现 {n_part} 次'))
    if n_part:
        k = html.find('>PART</span>')
        zone = html[max(0, k - 2200): k + 600]
        results.append(('左列：28px 翡翠绿大数字 + 8px PART 小字（居中对齐）',
                        'font-size:28px' in zone and 'font-size:8px' in zone and 'text-align:center' in zone,
                        '需同时含 font-size:28px / font-size:8px / text-align:center'))
        results.append(('右列：17px 主标题 + 11px 灰副标题',
                        'font-size:17px' in zone and 'font-size:11px' in zone,
                        '需同时含 font-size:17px 与 font-size:11px'))
        results.append(('未使用旧版「绿底白字徽章」样式',
                        'border-radius:7px' not in zone,
                        '出现 border-radius:7px 即为旧徽章样式'))

    print(f'[check] 检查文件：{path}')
    ok = True
    for name, passed, detail in results:
        print(f'  {"PASS" if passed else "FAIL"}  {name}' + (f'  ({detail})' if detail else ''))
        ok = ok and passed
    print('[check] 结果：' + ('全部通过 ✅' if ok else '存在失败项 ❌'))
    return 0 if ok else 1


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'preview.html')
    if not os.path.exists(path):
        print(f'[check] 文件不存在：{path}\n        先跑 build_wechat_article.py（可加 XXFSBTW_DRY=1 只生成本地预览）。')
        return 1
    return check(path)


if __name__ == '__main__':
    sys.exit(main())
