#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""通用公众号推文生成器：套 w母板 + 全文左对齐 + 提交草稿箱（配置驱动）。

用法：
  1) 改本文件顶部 凭证 / ARTICLE 配置（标题卡、引言、PART 章节、写在最后）。
  2) 运行：
     "C:/Users/Administrator/.workbuddy/binaries/python/envs/default/Scripts/python.exe" build_wechat_article.py
  3) 仅本地预览不提交：开头加环境变量  XXFSBTW_DRY=1

已沉淀的排版规则（当前正确版本）：
  - 整篇文字左对齐：因为 split_template 把正文嵌进 w母板「text-align:center」外层容器，
    正文段落自身无 text-align 会继承居中，所以必须「逐标签强写 text-align:left + 外层包
    一层 text-align:left section」双保险（见 _force_left / LEFT_ALIGN 处理）。
  - 正文前不插任何装饰图（早期那张红星星 gif 已移除）。
  - 结尾不插★区块，原位置留两空行，供作者在草稿箱自行补充内容。
  - 页脚（关于作者 + w母板超链接）一并拉成 100% 宽并左对齐，与正文等宽不再错位。

复用 fmg-xxfsb 的 template_layout.py（token / 草稿 / 母板切割 / 提交 / 校验）。
"""

import sys, os, glob, re, base64
import datetime as _dt

HERE = os.path.dirname(os.path.abspath(__file__))


def _find_template_layout():
    """定位 template_layout.py：优先用本 skill 自带副本（自包含，无需额外部装 fmg-xxfsb），
    找不到时再回退到用户已安装的 fmg-xxfsb。"""
    # 1) 本 skill 自带（打包发布时一并分发，保证自包含）
    if os.path.exists(os.path.join(HERE, "template_layout.py")):
        return HERE
    # 2) 回退：用户已安装的 fmg-xxfsb
    candidates = [
        r"C:\Users\Administrator\.workbuddy\skills\fmg-xxfsb\scripts",
        os.path.expanduser(r"~/.workbuddy/skills/fmg-xxfsb/scripts"),
    ]
    base = os.path.expanduser(r"~/.workbuddy/skills")
    for d in glob.glob(os.path.join(base, "fmg-xxfsb*", "scripts")):
        candidates.append(d)
    for c in candidates:
        if os.path.exists(os.path.join(c, "template_layout.py")):
            return c
    raise SystemExit("[前置依赖缺失] 未找到 template_layout.py（本 skill 应自带，或请安装 fmg-xxfsb skill）。")


sys.path.insert(0, _find_template_layout())
import template_layout as T
from PIL import Image

# ── 行间距覆盖：用户要求正文行间距设为 2（默认 1.9）。仅本脚本生效，不改动共享的 fmg-xxfsb 母板。
T.P_STYLE = T.P_STYLE.replace("line-height:1.9", "line-height:2")
# ── 正文字号覆盖：用户要求正文内容 14px（默认 15px）。仅本脚本生效，不改动共享库。
T.P_STYLE = T.P_STYLE.replace("font-size:15px", "font-size:14px")
_orig_card_p = T.card_p
def _card_p(text):
    return _orig_card_p(text).replace("line-height:1.9", "line-height:2")
T.card_p = _card_p

# 绿框金句卡：内边距统一收紧为 12px（用户既定偏好）。
# 用 override 函数实现，避免在主流程里对整个 middle 做全局字符串替换
# （旧做法 'padding:15px'→'padding:12px' 会误伤标题卡等其它元素）。
_orig_green_card = T.green_card
def _green_card(inner_html):
    return _orig_green_card(inner_html).replace("padding:15px", "padding:12px")
T.green_card = _green_card

# 注意：不要覆盖 part_header。
# 早期版本在这里用「绿底白字圆角徽章 + 只有主标题」的样式覆盖了库函数，导致生成的
# PART 小标题与 w母板不一致（母板是：28px 翡翠绿大数字 + 8px「PART」小字，
# 右侧 17px 主标题 + 11px 灰副标题）。统一使用 template_layout.part_header。

# 注意：不要在此覆盖 split_template。
# 新版 w母板（2026.08 起）正文区之后已经没有「关于作者」字样，页脚是
# data-mp-plugin="96weixin" 的往期回顾挂件。旧版基于「关于作者」定位的切分会
# 直接切掉整个页脚。切分逻辑统一由 template_layout.split_template 提供。


# ───────────────────────── 凭证与母板 ─────────────────────────
# 安全：凭证必须由环境变量注入（WX_APPID / WX_SECRET），脚本不内置任何真实凭证。
APPID = os.environ.get("WX_APPID", "")
SECRET = os.environ.get("WX_SECRET", "")
if not APPID or not SECRET:
    raise SystemExit("[凭证缺失] 请先设置环境变量 WX_APPID 与 WX_SECRET（公众号后台「基本配置」获取）；切勿把 Secret 写进文件后再上传分享。")
TPL_KW = "w母板"

# 封面：填生成好的图片绝对路径则自动裁切 900x383 并上传；留空/不存在则回退母板封面。
# 建议用 ImageGen 生成主题封面后通过环境变量 XXFSBTW_COVER 指定（默认留空＝复用母板封面）。
COVER_SRC = os.environ.get("XXFSBTW_COVER", "")
COVER_OUT = os.path.join(HERE, "cover_final.png")
# 可选：单独指定宽幅缩略图（900x383）。微信草稿缩略图是 2.35:1，若主封面是 16:9，
# 直接居中裁切会切掉封面上下内容；给一张宽幅专用图可避免信息丢失。
COVER_THUMB_SRC = os.environ.get("XXFSBTW_THUMB", "")

# 正文插图（配置驱动）：每项用环境变量指定本地路径，上传后按 part_no 插入对应 PART。
# 旧版把两张图硬编码进 parts[1] / parts[2] 并写死文案，换主题就没法复用；现改为声明式。
# 例：{"env": "XXFSBTW_IMG_1", "part_no": "02", "caption": "图片说明（可留空）"}
BODY_IMG_SPECS = [
    {"env": "XXFSBTW_IMG_1", "part_no": "02", "caption": "安装成功：管理页「技能 · 个人」里出现 Fmg Kxsy Kj，开关打开即启用"},
    {"env": "XXFSBTW_IMG_2", "part_no": "03", "caption": "上传安装入口：管理页右上角「+ 添加 → 上传技能」"},
    {"env": "XXFSBTW_IMG_3", "part_no": "03", "caption": "上传安装成功：三个自研技能已就位并全部启用"},
]

LEFT_ALIGN = True  # 整篇左对齐（含修复母板外层 center 继承 + 页脚）

# 定位已存在草稿的关键字（用于原地更新）；为空或找不到则新增一篇
TARGET_KW = os.environ.get("XXFSBTW_TARGET", "")  # 留空 → 新增；填标题关键字 → 原地更新匹配草稿

TITLE = "豆包也能装 WorkBuddy 技能了：SkillHub 一键安装 + ZIP 上传安装，技能插件伙伴用法全讲清"
AUTHOR = "冯萌刚"
DIGEST = "豆包也能装 WorkBuddy 技能：SkillHub 市场一键装和上传 ZIP 包两种方式，三张实图对照，再把豆包里技能、插件、伙伴三件套的用法一次讲清，照做即可上手。"

# 校验标志句（必须稳定存在于正文，勿用会被改写掉的字面量）
MARKER = "写在最后"


# ───────────────────────── 视觉函数（严格套用草稿箱真实结构） ─────────────────────────
def intro_title_card(kicker, strike, lines, tags, bar_left, bar_right, date=None):
    """引言框同款标题卡（复刻草稿箱「引言框」文章结构）。

    date 省略时自动取当前年月（YYYY.MM），避免历史硬编码日期被带到新文章里。
    """
    date = date or _dt.date.today().strftime("%Y.%m")
    title_html = "".join(
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:-11px 0 0;font-size:24px;font-weight:900;color:rgb(17,24,39);line-height:1.05;letter-spacing:-2px;text-indent:-3em;">'
        f'<span style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;">{ln}</span></p>'
        for ln in lines
    )
    # 关键：外框不设 padding（内边距全部交给「内容区」那一层），
    # 否则作为外框子元素的「翡翠绿渐变底栏」会被左右各顶进 padding 的距离，
    # 出现「绿色背景条顶不到方框两头」的问题（用户反馈的核心 bug）。
    # 外框 overflow:hidden 让贴边的底栏被裁剪成与外框一致的圆角。
    return (
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;border:1px solid rgb(102,158,73);border-radius:10px;margin-bottom:unset;overflow:hidden;">'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;">'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;padding:32px 28px 28px;">'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;display:flex;align-items:center;gap:8px;margin-bottom:28px;">'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:-11px 0 0;font-size:11px;font-weight:700;letter-spacing:3px;color:rgb(5,150,105);text-indent:-3em;"><span leaf="">{kicker}</span></p>'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;flex:1 1 0%;height:1px;overflow:hidden;background-image:linear-gradient(to right, rgba(5,150,105,0.118), transparent);background-position:initial;background-size:initial;background-repeat:initial;background-attachment:initial;background-origin:initial;background-clip:initial;"><span leaf=""><br /></span></section>'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:-11px 0 0;font-size:10px;color:rgb(209,213,219);font-weight:600;text-indent:-3em;"><span leaf="">{date}</span></p>'
        '</section>'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;">'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:-11px 0 0;font-size:15px;color:rgb(209,213,219);text-decoration:line-through;letter-spacing:.5px;text-indent:-3em;"><span leaf="">{strike}</span></p>'
        + title_html +
        '<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:-11px 0 0;font-size:13px;color:rgb(156,163,175);line-height:1.7;letter-spacing:.5px;text-indent:-3em;">'
        f'<span style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;font-size:12px;"><span leaf="">&nbsp;{tags}</span></span></p>'
        '</section></section>'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;background-image:linear-gradient(135deg, rgb(5,150,105), rgb(16,185,129));padding:12px 28px;border-radius:0 0 9px 9px;display:flex;align-items:center;justify-content:space-between;">'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0;font-size:13px;font-weight:700;color:rgb(255,255,255);letter-spacing:1px;"><span leaf="">{bar_left}</span></p>'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0;font-size:12px;color:rgba(255,255,255,0.85);letter-spacing:1px;"><span leaf="">{bar_right}</span></p>'
        '</section>'
        '</section></section>'
    )


def write_last_header(subtitle):
    """写在最后标题：统一走 template_layout.write_last_header（母板原版结构）。"""
    return T.write_last_header("写在最后", subtitle)


# ───────────────────────── 左对齐处理 ─────────────────────────
# 「居中保留」区块：章节头 / 写在最后标题里的编号列（01+PART、///+LAST）在母板里是
# 居中对齐的，左对齐清洗时必须整块跳过，否则 PART / LAST 会跑到数字左边。
_KEEP_CENTER = re.compile(r'<section[^>]*data-keep-center="1"[^>]*>.*?</section>', re.S)


def _left_align(s):
    """整段左对齐：把所有居中 / 两端对齐统一改为左对齐（含 data-align 标记）。

    注意：仅替换字面 text-align 仍可能因微信编辑器对「继承」处理不一致而失效，
    真正生效靠 _force_left + 外层 wrapper（见 main）。此函数作为第一道清洗保留。
    """
    kept = []

    def _stash(m):
        kept.append(m.group(0))
        return f'@@KEEPCENTER{len(kept) - 1}@@'

    s = _KEEP_CENTER.sub(_stash, s)
    s = (s
         .replace('text-align:center', 'text-align:left')
         .replace('text-align: center', 'text-align:left')
         .replace('text-align:justify', 'text-align:left')
         .replace('text-align: justify', 'text-align:left')
         .replace('data-align="title"', 'data-align="left"'))
    for i, blk in enumerate(kept):
        s = s.replace(f'@@KEEPCENTER{i}@@', blk)
    return s


def _force_left(s):
    """给 middle/ftr 内每个带 style 的块级标签显式注入 text-align:left。

    关键：split_template 把正文嵌进 w母板「text-align:center」外层 section，正文段落自身
    无 text-align 会继承居中。逐标签强制写入，确保每段文字都是左对齐（不依赖外层继承）。"""
    def repl(m):
        tag = m.group(0)
        if 'text-align' in tag:
            return tag
        return tag.replace('style="', 'style="text-align:left;', 1)
    return re.sub(r'<(p|section|div|li|h1|h2|h3)\b[^>]*\s+style="[^"]*"', repl, s)


def _center_about_image(s):
    """把「关于作者」简介句之后的作者图片 section 设为居中（覆盖左对齐处理）。
    在 _force_left 之后调用：先定位 bio 句之后第一个 <img，再取其所属 <section> 开标签，
    把其中的 text-align 改为 center。仅影响该图片，不动往期回顾挂件等其他块。"""
    bio = s.find("全国首届微课大赛学科顾问")
    if bio < 0:
        return s
    rest = s[bio:]
    img_m = re.search(r"<img\b", rest)
    if not img_m:
        return s
    sec_start = rest.rfind("<section", 0, img_m.start())
    if sec_start < 0:
        return s
    m = re.search(r"<section\b[^>]*>", rest[sec_start:])
    if not m:
        return s
    tag = m.group(0)
    new_tag = re.sub(r"text-align:\s*(left|center)", "text-align:center", tag)
    if "text-align" not in new_tag:
        if "style=" in new_tag:
            new_tag = new_tag.replace('style="', 'style="text-align:center;', 1)
        else:
            new_tag = new_tag[: len("<section")] + ' style="text-align:center;"' + new_tag[len("<section"):]
    return s[:bio] + rest[:sec_start] + new_tag + rest[sec_start + len(tag):]


# ───────────────────────── 文章配置（改这里即可复用） ─────────────────────────
ARTICLE = {
    "intro_card": {
        "kicker": "一线实践 · 数智化教学",
        "strike": "好技能只能锁在 WorkBuddy 里用？豆包同样装得上、跑得动",
        "lines": [
            "豆包也能装",
            "WorkBuddy 技能",
            "两种装法三件套讲清",
        ],
        "tags": "豆包 · WorkBuddy · SkillHub · 技能安装 · ZIP 上传 · 插件 · AI 伙伴 · 教师提效",
        "bar_left": "数智化教学大冯老师 · 实操教程",
        "bar_left_real": "",
        "bar_right": "教程 · 2026.09",
        "date": "2026.09",
    },
    "intro_text": [
        '我在 WorkBuddy 里攒了一批自己开发的技能——科学实验演示课件生成器、手势 AR 互动课件、3D 校园场景课件，用得正香，突然想到一个问题：这些技能，能不能装进我日常用得最多的豆包里去？答案是：能，而且有两种装法。',
        '这篇就把两种安装方式一步步讲清：一种是打开 SkillHub 技能市场一键安装（以我开发的「科学实验演示课件生成器」为例），一种是在管理页上传技能 ZIP 安装包。装完顺手把豆包里技能、插件、伙伴这三件套到底是什么、怎么用、怎么搭配，一次讲清楚。',
        '全程不写代码、不碰命令行，你在豆包界面上点几下就能完成，适合想把自己的 AI 工作流跨平台搬家的老师和效率党。',
    ],
    "intro_tip": '一句话：技能的本质是一份「说明书加脚本」，只要平台遵循同一套规范，WorkBuddy 的技能就能在豆包里接着用。',
    "parts": [
        {
            "no": "01", "title": "先搞懂：技能为什么能跨平台通用", "sub": "CONCEPT · 技能的本质",
            "paras": [
                f'{T.bd("技能不是黑盒，是一个文件夹")}：一个技能通常就是「一份 SKILL.md 说明书 + 若干脚本和素材」，里面写清这个技能叫什么、会什么、遇到需求按什么步骤干。AI 加载这份说明书，就知道什么时候出手、怎么出手。',
                f'{T.bd("跨平台的底气在规范")}：豆包和 WorkBuddy 都遵循同一套 Agent Skills 技能规范，对「怎么读技能、怎么调技能」的理解一致。所以同一个技能包，在这边能装，在那边也能装——就像同一份菜谱，换个厨房照样能炒出同一道菜。',
                f'{T.bd("入口在哪")}：豆包左侧「市场」进技能市场，「管理」页能看到三个标签：插件、技能、连接器，已安装的技能全列在这里。每个技能带一个开关，装了不开，等于没装。',
            ],
            "cards": ['技能的本质是「说明书加脚本」，规范通用，平台只是不同的安装入口——想通这一点，跨平台搬家就没有心理负担。'],
        },
        {
            "no": "02", "title": "方式一：SkillHub 市场一键安装", "sub": "SKILLHUB · 以科学课件生成器为例",
            "paras": [
                f'{T.bd("第一步 · 找到技能")}：打开豆包的技能市场，直接搜索技能名，或把 SkillHub 的技能页链接贴进去。本文以我开发的「科学实验演示课件生成器」为例，地址是 https://skillhub.cn/skills/user_73cb5b59/fmg-kxsy-kj ，它能一句话生成小学科学实验演示动画课件。',
                f'{T.bd("第二步 · 点安装")}：在技能页点「安装」，豆包会自动把技能拉进你的个人技能列表，全程几秒钟，不需要手动下载任何文件。',
                f'{T.bd("第三步 · 开开关验货")}：到「市场 → 管理」页看，个人列表里多出一个「Fmg Kxsy Kj」，把右侧开关打开（见下图）——亮着才算装好启用。',
                f'{T.bd("第四步 · 对话里点名使用")}：直接对豆包说「用科学实验演示课件生成器，做四年级科学第 4 课的演示课件」，它就会按技能里写好的流程出活，和 WorkBuddy 里的用法一致。',
            ],
            "cards": ['市场安装最省事：搜到、点装、开开关，三步完成——适合所有已经上架 SkillHub 的公开技能。'],
        },
        {
            "no": "03", "title": "方式二：上传技能 ZIP 安装包", "sub": "ZIP · 私有技能与离线分享",
            "paras": [
                f'{T.bd("什么时候用这招")}：技能还没上架市场、只在小范围分享，或者朋友直接发给你一个技能压缩包——这时就走「上传安装」的路子。',
                f'{T.bd("第一步 · 找到上传入口")}：在「市场 → 管理」页点右上角的「+ 添加」，菜单里选「上传技能」（见下图）；菜单里的「与豆包对话新建技能」是用来现场造新技能的，这篇先不展开。',
                f'{T.bd("第二步 · 选包上传")}：选中准备好的技能 ZIP 包上传。注意压缩包根目录要直接放着 SKILL.md，别多套一层文件夹——套错了豆包识别不到技能描述。',
                f'{T.bd("第三步 · 开关启用")}：上传成功后，技能同样出现在「个人」列表里。我这次一口气装了三个：科学实验演示课件生成器、手势 AR 互动课件（Fmg Arzhuaqu Kj）、基于 three.js 的 3D 校园场景课件（Fmg 3d Kj），三个开关全部打开（见下图）。',
            ],
            "cards": ['ZIP 上传装解决的是「市场化之前」和「私有定制」两个场景——包在手里，装上就能跑。'],
        },
        {
            "no": "04", "title": "技能、插件、伙伴：三件套到底怎么用", "sub": "TRIO · 分工与组合",
            "paras": [
                f'{T.bd("技能 · 会干活的方法论")}：技能管「怎么做一件事」，是写好的工作流。特点是不占对话、按需触发：你在对话里点名它，它才上场；管理页的开关决定它是否待命。适合把重复劳动固化下来，比如每次都按同一套流程出科学课件。',
                f'{T.bd("插件 · 连外部的接口")}：插件和连接器管「能不能连上外部世界」——查资料、读文档、连第三方服务都靠它们。我的插件和连接器目前还是 0，说明不装插件、纯靠技能也能干活：技能自带脚本办得到的事，不必依赖插件。',
                f'{T.bd("伙伴 · 人格化的封装")}：伙伴（智能体）是把「角色设定 + 技能 + 插件」打包成的固定专家形象，选中它就等于预设了身份和工具。技能是说明书，伙伴就是「拿着说明书的专业人士」——要稳定人设和固定输出风格，用伙伴；要灵活按需调用的能力，用技能。',
                f'{T.bd("组合拳怎么打")}：日常可以这么配：伙伴定角色（比如「数智化教学助手」），技能供能力（课件生成、AR 互动、3D 场景），插件补数据（需要联网查询、连接系统时再开）。三者不是三选一，而是分层叠加。',
            ],
            "cards": ['技能管方法，插件管连接，伙伴管人设——三层各司其职，用对了就是一条完整的 AI 工作流。'],
        },
        {
            "no": "05", "title": "避坑清单与教师场景推荐", "sub": "PLAYBOOK · 装完就用对",
            "paras": [
                f'{T.bd("四个坑提前踩掉")}：一是装完不开开关，对话里怎么点都没反应；二是 ZIP 包多套一层文件夹，导致识别不到技能；三是技能名多为拼音缩写（如 Fmg Kxsy Kj），认不准就看描述行；四是不明来源的技能包别乱装——说明书会指挥 AI 干活，来路不明的包有安全风险。',
                f'{T.bd("装完先验货")}：新技能装好，先让它自报家门：问一句「你有哪些技能、能做什么」，它把技能清单列出来，说明挂载成功，再正式派活。',
                f'{T.bd("教师场景三连")}：科学老师装「科学实验演示课件生成器」，一句话出实验演示动画；想上课互动装「手势 AR 互动课件」，捏合拖拽搭电路、挥手合闸；做综合实践装「3D 校园场景课件」，把学校做成可漫游的 3D 场景——三个都在 SkillHub 能直接找到。',
                f'{T.bd("跨平台的心得")}：同一套技能，WorkBuddy 里做深度工程，豆包里做轻量随取——工具跟着场景走，而不是人迁就工具。',
            ],
            "cards": ['装技能不是目的，把重复劳动交出去才是——装完第一件事，是把你最常做的那件事派给它。'],
        },
    ],
    "write_last": {
        "sub": "WRAP-UP · 让技能跟着你走",
        "paras": [
            '这次跨平台安装的全过程，就是「点安装、传包、开开关」几个动作，三张截图之外没有任何隐藏步骤。技能生态真正开始跨平台流动之后，你攒下的工作流资产才是真正跟着人走的。',
            '如果你也开发了自己的技能，建议同时走两条路：上架 SkillHub 让大家一键装，再留一个 ZIP 包应对私有场景——公开与私有两手抓，技能才有生命力。',
            '你在豆包里装技能踩过什么坑，或者想看我拆哪个技能的内部结构，欢迎留言，我看到会回。',
        ],
        "quote": f'{T.b("技能装到哪里不重要，重要的是你手里得先有一套值得带走的工作流。")}',
    },
}


# ───────────────────────── 组装正文 ─────────────────────────
def build_middle(a, ending_html):
    """组装正文区。ending_html 传入结尾两空行（★区块已移除，供作者自行补充）。"""
    h = []
    ic = a["intro_card"]
    h.append(intro_title_card(ic["kicker"], ic["strike"], ic["lines"], ic["tags"],
                              ic["bar_left"], ic["bar_right"], ic.get("date")))
    # 注：正文前的红星星装饰 gif（早期 intro_deco）已按需求移除，正文直接接标题卡。
    for t in a["intro_text"]:
        h.append(T.p(t))
    if a.get("intro_tip"):
        h.append(T.green_card(T.card_p(a["intro_tip"])))
    for p in a["parts"]:
        h.append(T.part_header(p["no"], p["title"], p["sub"]))
        for para in p.get("paras", []):
            h.append(T.p(para))
        for img in p.get("imgs", []):
            h.append(T.figure(img["url"], caption=img.get("caption")))
        for card in p.get("cards", []):
            h.append(T.green_card(T.card_p(card)))
    h.append('<p style="margin:0;"><br /></p>')
    h.append(write_last_header(a["write_last"]["sub"]))
    for para in a["write_last"]["paras"]:
        h.append(T.p(para))
    h.append(T.green_card(T.card_p(a["write_last"]["quote"])))
    # 结尾★区块已移除：原位置留两空行，供作者在草稿箱自行添加内容
    h.append(ending_html)
    return "".join(h)


# ───────────────────────── 封面 ─────────────────────────
def make_cover_thumb():
    """生成封面：保留 1920x1080 全幅（用户交付物），同时产出 900x383 供微信草稿箱缩略图。

    优先使用 XXFSBTW_THUMB 指定的宽幅专用图（直接缩放到 900x383，不裁切）；
    未指定时才按 2.35:1 居中裁切主封面。
    """
    if not COVER_SRC or not os.path.exists(COVER_SRC):
        return None
    with Image.open(COVER_SRC) as img:
        # 保存全幅 1920x1080 作为交付物
        img.save(COVER_OUT, "PNG", optimize=True)
        print(f"[cover] 全幅封面已保存 {COVER_OUT} ({img.size[0]}x{img.size[1]})")
        thumb_path = os.path.join(HERE, "cover_thumb_900x383.png")
        if COVER_THUMB_SRC and os.path.exists(COVER_THUMB_SRC):
            with Image.open(COVER_THUMB_SRC) as t:
                t.convert("RGB").resize((900, 383), Image.LANCZOS).save(
                    thumb_path, "PNG", optimize=True)
            print(f"[cover] 使用宽幅专用缩略图 {thumb_path} (900x383)")
            return thumb_path
        # 裁切 900x383 (2.35:1) 供微信缩略图上传
        w, h = img.size
        target_ratio = 900 / 383
        current_ratio = w / h
        if current_ratio > target_ratio:
            # 太宽，裁左右
            new_w = int(h * target_ratio)
            left = (w - new_w) // 2
            cropped = img.crop((left, 0, left + new_w, h))
        else:
            # 太高，裁上下
            new_h = int(w / target_ratio)
            top = (h - new_h) // 2
            cropped = img.crop((0, top, w, top + new_h))
        thumb_path = os.path.join(HERE, "cover_thumb_900x383.png")
        cropped = cropped.resize((900, 383), Image.LANCZOS)
        cropped.save(thumb_path, "PNG", optimize=True)
        print(f"[cover] 缩略图已裁切 {thumb_path} (900x383)")
        return thumb_path


# ───────────────────────── 主流程 ─────────────────────────
def main():
    DRY = os.environ.get("XXFSBTW_DRY") == "1"
    # 离线预览回退：DRY 模式下联网失败（断网/IP 白名单未配置）时，
    # 用空母板产出裸排本地预览，保证「仅核稿」永远可用；正式提交仍严格报错。
    OFFLINE_DRY = False
    tok = None
    tpl_content = None
    fallback_thumb = None
    my_id = None
    items = []
    try:
        tok = T.get_token(APPID, SECRET)
        items = T.fetch_all_drafts(tok)

        it_w, ni_w = T.find_draft(items, TPL_KW)
        if not it_w:
            raise SystemExit(f"[未找到母板] 草稿箱里没有标题含『{TPL_KW}』的草稿")
        tpl_content = ni_w["content"]
        fallback_thumb = ni_w.get("thumb_media_id")
        print(f"[ok] 已拉取母板：{ni_w.get('title')}（fallback_thumb={fallback_thumb}）")

        if TARGET_KW:
            for it in items:
                t = it["content"]["news_item"][0].get("title", "")
                if TARGET_KW in t:
                    my_id = it["media_id"]
                    print(f"[ok] 定位到待更新草稿：{t} ({my_id})")
                    break
    except SystemExit as e:
        # token 失败（IP 白名单未配置等）抛 SystemExit；DRY 模式下不应中断离线预览
        if not DRY or "token失败" not in str(e):
            raise
        OFFLINE_DRY = True
        print(f"[dry][offline] token 获取失败（{e}），改用离线裸排预览（无母板 chrome）")
    except Exception as e:
        if not DRY:
            raise
        OFFLINE_DRY = True
        print(f"[dry][offline] 联网失败（{e.__class__.__name__}），改用离线裸排预览（无母板 chrome）")

    # 上传正文插图并注入文章结构（按 BODY_IMG_SPECS 配置，env 指定的文件存在才处理）
    if not DRY:
        for spec in BODY_IMG_SPECS:
            url = T.upload_body_image(tok, os.environ.get(spec.get("env", ""), ""))
            if not url:
                continue
            idx = next((i for i, p in enumerate(ARTICLE["parts"])
                        if p.get("no") == spec.get("part_no")), None)
            if idx is None:
                print(f"[warn] 未找到 PART {spec.get('part_no')}，插图跳过")
                continue
            ARTICLE["parts"][idx].setdefault("imgs", []).append({
                "url": url,
                "caption": spec.get("caption", ""),
            })
            print(f"[ok] 正文插图上传成功 → PART {spec.get('part_no')}")

    if OFFLINE_DRY:
        tpl_content = ""  # 离线：空母板 → split_template/split_footer 自然产出空 chrome，正文裸排
    hdr, ftr = T.split_template(tpl_content)
    # 收紧正文左右边距（只改本次文章的 hdr 副本，不动 w母板草稿）：
    #   外层固定宽 578px→100%（消除桌面端大留白）；外层 padding 1em→0.5em
    hdr = hdr.replace('width: 578px', 'width: 100%').replace('padding: 1em', 'padding: 0.5em')

    # 尾部 chrome 三段拆分：关于作者区 / 三连卡 / 往期回顾矩阵。
    # 为什么要拆：
    #   - 三连卡是**居中排版**的 CTA 卡片，绝不能参与「全文左对齐」，否则卡片会被拉歪；
    #   - 往期回顾矩阵是平台挂件，布局由平台渲染，一律原样保留；
    #   - 只有关于作者区允许左对齐 + 收窄到与正文等宽。
    # 历史坑：曾把尾部切分点误设到「往期回顾挂件」，把「关于作者 + 三连卡」整段丢掉，
    # 文章末尾只剩空白（用户反馈的「红框位置空白 + 与往期回顾间隙太大」）。
    ftr_bio, ftr_cta, ftr_matrix = T.split_footer(ftr)
    if not OFFLINE_DRY and not ftr_bio and not ftr_cta:
        print('[warn] 未从母板尾部识别到「关于作者 / 三连卡」，请核对母板结构是否改版')

    # 仅关于作者区：收窄 + 左对齐（图文与正文等宽）；三连卡与往期回顾矩阵完全不处理。
    ftr_bio = ftr_bio.replace('width: 578px', 'width: 100%').replace('padding: 1em', 'padding: 0.5em')
    # 三连卡下外边距归零：消除「三连提示」与下方「往期回顾」之间那条过大的空白带
    ftr_cta = T.tighten_cta(ftr_cta)
    # 往期回顾矩阵区收紧：消除「矩阵」与下方「后台回复提示图」之间过大的空隙
    # （母板挂件内关注条区的 padding/margin 叠加 + 提示图写死 578px 所致）
    ftr_matrix = T.tighten_matrix(ftr_matrix)

    # 结尾★块已按需求移除：原位置留两个空行，供作者自行添加内容
    ending_html = '<p style="margin:0;"><br /></p><p style="margin:0;"><br /></p>'
    middle = build_middle(ARTICLE, ending_html)
    if LEFT_ALIGN:
        middle = _left_align(middle)
        ftr_bio = _left_align(ftr_bio)
        # 逐标签强制写入 text-align:left（双保险，不依赖外层继承）
        middle = _force_left(middle)
        ftr_bio = _force_left(ftr_bio)
        # 把「关于作者」简介句之后的作者图片重新居中（覆盖左对齐处理）
        ftr_bio = _center_about_image(ftr_bio)
        # 关键修复：split_template 把正文嵌在 w母板「text-align:center」外层 section 内，
        # 正文段落自身无 text-align 会继承居中。给 middle/ftr_bio 各包一层「text-align:left」
        # section，直接覆盖继承来的居中，且不改动母板 banner / 三连卡 / 往期回顾矩阵。
        middle = '<section style="text-align:left;">' + middle + '</section>'
        if ftr_bio:
            ftr_bio = '<section style="text-align:left;">' + ftr_bio + '</section>'
    # 重组页脚：关于作者区（已处理）+ 三连卡（原样，保持居中）+ 往期回顾矩阵（原样）
    ftr = ftr_bio + ftr_cta + ftr_matrix
    content = T.build_content(hdr, middle, ftr)

    title, author, digest = T.check_limits(TITLE, AUTHOR, DIGEST)
    # 作者字段微信限制为 8 个汉字（字符）而非 8 字节，「冯萌刚」仅 3 字，按字符发送，
    # 由回读校验实际落库值（避免本地字节截断把名字截成「冯萌」）。
    author = AUTHOR
    T.dry_check(content, marker=MARKER)
    print(f"[info] title={title!r} author={author!r} digest={digest!r}")

    out = os.path.join(HERE, "preview.html")
    open(out, "w", encoding="utf-8").write(content)
    print(f"[preview] 已写出本地预览：{out}")

    if DRY:
        print("[dry] XXFSBTW_DRY=1 → 跳过提交草稿箱")
        return

    cover_path = make_cover_thumb()
    thumb = T.upload_thumb(tok, cover_path) if cover_path else None
    if not thumb:
        thumb = fallback_thumb
        print(f"[warn] 封面上传失败，回退母板封面 thumb={thumb}")
    else:
        print(f"[ok] 封面上传成功 thumb={thumb}")

    article = {
        "title": title, "author": author, "digest": digest,
        "content": content, "thumb_media_id": thumb,
        "need_open_comment": 0, "only_fans_can_comment": 0, "article_type": "news",
    }
    if my_id:
        T.submit_update(tok, my_id, article, marker=MARKER)
    else:
        T.submit_add(tok, article, marker=MARKER)
    print("[安全提示] AppSecret 等同密码，建议用完到公众号后台重置一次。")


if __name__ == "__main__":
    main()
