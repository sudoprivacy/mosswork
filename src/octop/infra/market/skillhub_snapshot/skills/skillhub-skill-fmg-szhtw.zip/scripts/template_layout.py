#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""template_layout.py —— fmg-xxfsb 的微信草稿箱 / w母板 排版核心库（重建版）。

提供：
  - get_token / fetch_all_drafts / find_draft
  - split_template（把 w母板拆成 头chrome + 尾chrome，中间注入正文）
  - build_content / check_limits / dry_check
  - upload_thumb / upload_body_image
  - submit_add / submit_update
  - 视觉函数：p / part_header / green_card / card_p / figure / b / bd / code

注意：微信草稿接口 JSON 必须 ensure_ascii=False + utf-8 字节发送，否则中文被静默截断。
P_STYLE 默认 line-height:1.9，调用方（build_wechat_article.py）可替换为 2。
"""
import requests, json, re, os

API = "https://api.weixin.qq.com/cgi-bin"

# 行间距基准（build_wechat_article.py 会把它替换成 2）
P_STYLE = "line-height:1.9;color:rgb(55,65,81);font-size:15px;letter-spacing:.2px;"


# ───────────────────────── 鉴权 / 草稿 ─────────────────────────
def get_token(appid, secret):
    r = requests.get(f"{API}/token",
                      params={"grant_type": "client_credential", "appid": appid, "secret": secret},
                      timeout=30)
    r.encoding = "utf-8"
    j = r.json()
    if "access_token" not in j:
        raise SystemExit(f"[token失败] {j}")
    return j["access_token"]


def fetch_all_drafts(token):
    items = []
    offset = 0
    while True:
        r = requests.post(f"{API}/draft/batchget", params={"access_token": token},
                          json={"offset": offset, "count": 20, "no_content": 0}, timeout=30)
        r.encoding = "utf-8"
        d = r.json()
        if d.get("errcode"):
            # 40164 出口IP未加白名单；其他错误抛出
            raise SystemExit(f"[batchget失败] {d}")
        batch = d.get("item", [])
        if not batch:
            break
        items.extend(batch)
        if len(batch) < 20:
            break
        offset += 20
    return items


def find_draft(items, kw):
    for it in items:
        ni = it["content"]["news_item"][0]
        if kw in ni.get("title", ""):
            return it, ni
    return None, None


# ───────────────────────── w母板切割 ─────────────────────────
def _section_depth(s):
    """粗略校验 HTML section 标签是否配平（用于 split 自检）。"""
    opens = len(re.findall(r'<section\b', s))
    closes = len(re.findall(r'</section>', s))
    return opens - closes


_SECTION_TAG = re.compile(r"<section\b|</section>")


def _depth0_open(s, pos):
    """返回 s 中 pos 之前最近的「顶层 <section>」起始下标（找不到返回 None）。

    顶层 = 该 <section> 处于 section 嵌套深度 0，即与 s 的顶层块同级。
    用途：把切分点对齐到完整标签边界，避免把某个 section 拦腰截断
    （拦腰截断会让残留属性变成页面上的可见垃圾文本）。
    """
    depth, last = 0, None
    for m in _SECTION_TAG.finditer(s):
        if m.start() >= pos:
            break
        if m.group(0).startswith("</"):
            depth -= 1
        else:
            if depth == 0:
                last = m.start()
            depth += 1
    return last


def split_template(content):
    """把 w母板拆成 (头 chrome, 尾部 chrome)。

    母板结构（2026.08 实测，逐块按 section 深度核对过）：
      ① 头 chrome      banner gif + 加星标 + 公众号名片挂件
      ② 正文 demo 区    引言框 + PART 章节 + 写在最后 + ★扫码块（由调用方整体替换）
      ③ 尾部 chrome     **关于作者** → **三连卡** → 往期回顾矩阵 + 底部关注 CTA
      ④ 末尾          <p style="display:none"><mp-style-type data-value="3"/></p>

    分割策略：
      - hdr = content[:body_start]（body_start = 第一个 data-pm-slice="0 0 []"）
      - ftr = content[「关于作者」所在顶层 section 的起始:]

    ⚠️ 历史坑（务必保留这段注释）：
      本地母板副本曾因保存编码错误变成 mojibake，中文关键词全部搜不到，
      于是误判「新母板已去掉『关于作者』文字」，把尾部切分点改到
      最后一个 data-mp-plugin="96weixin"（往期回顾挂件）。后果是把
      「关于作者 + 三连卡」整段丢掉 → 文章末尾只剩空白，且正文与往期回顾
      之间出现一大段空隙。**用中文关键词定位前，先用 coding:utf-8 正确读取母板。**
    """
    # 正文起始：第一个 <section ... data-pm-slice="0 0 []">
    m = re.search(r'<section[^>]*data-pm-slice="0 0 \[\]"', content)
    body_start = m.start() if m else len(content) // 2
    hdr = content[:body_start]

    # 尾部起始：优先「关于作者」（含 关于作者 + 三连卡 + 往期回顾 完整收尾 chrome）
    ftr_start = None
    i_about = content.find("关于作者")
    if i_about > 0:
        ftr_start = _depth0_open(content, i_about)
    if ftr_start is None:
        # 兜底：母板里确实没有「关于作者」时，退回到往期回顾挂件
        # （此路径会丢掉 关于作者/三连卡，属降级方案）
        last_plugin = content.rfind('data-mp-plugin="96weixin"')
        if last_plugin > 0:
            ftr_start = _depth0_open(content, last_plugin)
    if ftr_start is None:
        ftr_start = int(len(content) * 0.9)
    if ftr_start < body_start:
        ftr_start = body_start

    return hdr, content[ftr_start:]


# 三连卡特征句 / 往期回顾挂件特征串
CTA_KW = "既然看到这里了"
MATRIX_KW = 'data-mp-plugin="96weixin"'


def split_footer(ftr):
    """把尾部 chrome 再拆成 (关于作者区, 三连卡, 往期回顾矩阵)。

    为什么必须拆：
      - 三连卡是**居中排版**的 CTA 卡片（卡片本身 + 三个图标格都靠 text-align:center
        居中）。若跟着正文一起做「全文左对齐」，卡片会被拉歪，所以必须跳过左对齐处理。
      - 往期回顾矩阵是平台挂件（96编辑器），布局由平台渲染，一律原样保留。
      - 只有「关于作者区」需要左对齐 / 收窄到与正文等宽。

    切分点同样用 _depth0_open 对齐到完整顶层 section，避免标签被截断。
    """
    i_cta = ftr.find(CTA_KW)
    cta_start = _depth0_open(ftr, i_cta) if i_cta > 0 else None
    i_wm = ftr.find(MATRIX_KW)
    wm_start = _depth0_open(ftr, i_wm) if i_wm > 0 else None

    if cta_start is None:
        bio_end = wm_start if wm_start is not None else len(ftr)
        return ftr[:bio_end], "", ftr[bio_end:]
    if wm_start is None or wm_start < cta_start:
        return ftr[:cta_start], ftr[cta_start:], ""
    return ftr[:cta_start], ftr[cta_start:wm_start], ftr[wm_start:]


def tighten_cta(cta):
    """收紧「三连卡」与下方「往期回顾」之间的空隙。

    母板里三连卡自带 `margin: 0px 0px 24px`，卡底还会再叠上 32px 内边距，
    下方往期回顾挂件又自带 1em 内边距，视觉上就是一条明显偏大的空白带。
    这里只把三连卡外框的下外边距归零（只改第一个开标签，不动卡片内部布局、
    也不碰往期回顾矩阵），让两块紧贴。
    """
    m = re.match(r"<section\b[^>]*>", cta or "")
    if not m:
        return cta or ""
    tag = m.group(0)
    new_tag = tag.replace("margin: 0px 0px 24px;", "margin: 0px;", 1)
    new_tag = new_tag.replace("margin:0px 0px 24px;", "margin:0px;", 1)
    return new_tag + cta[len(tag):]


# 「关注条」锚点：往期回顾矩阵之后、后台回复提示图之前的固定文案
MATRIX_GAP_KW = "再不关注将损失1个亿"


def tighten_matrix(matrix):
    """收紧「往期回顾矩阵」与下方「后台回复提示图」之间过大的空隙。

    母板挂件（data-mp-plugin="96weixin"）内部，矩阵之后到提示图之前夹着一个
    「关注条」区，其容器层层叠加 `padding: 1em` + `margin: 10px 0px` ×2 +
    `padding: 10px`，在手机端叠出约 100px 的空白带；提示图 gif 又写死
    `width: 578px`，与全文等宽策略不一致。视觉上就是「矩阵下面空一大片」。

    修法（只改「关注条」容器及其后，不动矩阵卡片本身，避免影响平台渲染）：
      1. 用 MATRIX_GAP_KW 定位关注条；向前找含 `padding: 1em` 的 <section>，
         再向上爬一层拿到 width:578px 外层容器，作为收紧区间起点；
      2. 区间内：padding: 1em / margin: 10px 0px / padding: 10px 全部归零，
         width: 578px → width: 100%（提示图 gif 与正文等宽）。
    找不到锚点（母板改版）时原样返回，绝不瞎改。
    """
    if not matrix:
        return matrix
    i = matrix.find(MATRIX_GAP_KW)
    if i < 0:
        return matrix
    # 区间起点：锚点之前最后一个「padding: 1em」所在的 <section>，再上爬一层
    pad_i = matrix.rfind("padding: 1em", 0, i)
    if pad_i < 0:
        pad_i = matrix.rfind("margin: 10px 0px", 0, i)
    if pad_i < 0:
        return matrix
    sec_start = matrix.rfind("<section", 0, pad_i)
    if sec_start < 0:
        return matrix
    outer = matrix.rfind("<section", 0, sec_start)
    if outer >= 0:
        sec_start = outer
    head, tail = matrix[:sec_start], matrix[sec_start:]
    tail = (tail
            .replace("padding: 1em", "padding: 0px")
            .replace("margin: 10px 0px", "margin: 0px")
            .replace("padding: 10px", "padding: 0px")
            .replace("width: 578px", "width: 100%"))
    return head + tail


def build_content(hdr, middle, ftr):
    return hdr + middle + ftr


# ───────────────────────── 字段限制 ─────────────────────────
def check_limits(title, author, digest):
    def clip(s, n):
        return s if len(s) <= n else s[: n - 1] + "…"
    return clip(title, 64), clip(author, 8), clip(digest, 120)


def dry_check(content, marker="写在最后"):
    if marker not in content:
        raise SystemExit(f"[dry_check失败] 正文缺少校验标志『{marker}』，可能模板切割出错")
    return True


# ───────────────────────── 素材上传 ─────────────────────────
def upload_thumb(token, path):
    if not path or not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        r = requests.post(f"{API}/material/add_material",
                          params={"access_token": token, "type": "image"},
                          files={"media": f}, timeout=60)
    r.encoding = "utf-8"
    j = r.json()
    return j.get("media_id")


def upload_body_image(token, path):
    if not path or not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        r = requests.post(f"{API}/media/uploadimg", params={"access_token": token},
                          files={"media": f}, timeout=60)
    r.encoding = "utf-8"
    j = r.json()
    return j.get("url")


# ───────────────────────── 提交 ─────────────────────────
def _post_json(url, obj):
    data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    return requests.post(url, data=data,
                         headers={"Content-Type": "application/json; charset=utf-8"}, timeout=60)


def submit_add(token, article, marker="写在最后"):
    obj = {"articles": [article]}
    r = _post_json(f"{API}/draft/add?access_token={token}", obj)
    r.encoding = "utf-8"
    j = r.json()
    if j.get("errcode"):
        raise SystemExit(f"[draft/add失败] {j}")
    media_id = j.get("media_id")
    print(f"[ok] draft/add 成功 media_id={media_id}")
    _verify(token, marker)
    return media_id


def submit_update(token, media_id, article, marker="写在最后"):
    obj = {"media_id": media_id, "index": 0, "articles": article}
    r = _post_json(f"{API}/draft/update?access_token={token}", obj)
    r.encoding = "utf-8"
    j = r.json()
    if j.get("errcode"):
        raise SystemExit(f"[draft/update失败] {j}")
    print(f"[ok] draft/update 成功 media_id={media_id}")
    _verify(token, marker)
    return media_id


def _verify(token, marker):
    items = fetch_all_drafts(token)
    hit = any(marker in it["content"]["news_item"][0].get("content", "")
              for it in items)
    print(f"[verify] 校验标志『{marker}』在草稿箱中存在: {hit}")


# ───────────────────────── 视觉函数（w母板绿系） ─────────────────────────
def p(text):
    return (f'<p style="margin:0 0 1.2em;{P_STYLE}">'
            f'<span style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;">{text}</span></p>')


def b(text):
    return f'<strong style="font-weight:800;color:rgb(5,150,105);">{text}</strong>'


def bd(text):
    return f'<strong style="font-weight:800;color:rgb(5,150,105);">{text}</strong>'


def code(text):
    return (f'<code style="background:rgb(243,244,246);color:rgb(220,38,38);'
            f'padding:2px 6px;border-radius:4px;font-family:Consolas,monospace;font-size:13px;'
            f'white-space:nowrap;">{text}</code>')


def part_header(no, title, sub=""):
    """PART 章节头（严格套用 w母板原版结构）。

    母板原版版式：
      - 左列（`text-align:center;flex-shrink:0`）：28px/900 翡翠绿大数字 + 8px 灰字「PART」
      - 右列：17px/900 主标题 + 11px 灰字副标题（如 `AI ERROR BOOK · 三大升级`）
    ⚠️ 不是「绿底白字圆角徽章」样式，也不要省略左列的「PART」小字与右列副标题。
    """
    sub_html = (
        '<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;'
        'min-height:1em;margin:0px;font-size:11px;font-weight:600;color:rgb(156,163,175);'
        f'letter-spacing:1.5px;"><span leaf="">{sub}</span></p>'
    ) if sub else ''
    return (
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;overflow:visible;" data-pm-slice="0 0 []">'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;display:flex;align-items:center;gap:16px;margin-bottom:24px;">'
        '<section data-keep-center="1" style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;text-align:center;flex-shrink:0;margin-bottom:unset;">'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0px;text-align:center;font-size:28px;font-weight:900;color:rgb(5,150,105);line-height:1;letter-spacing:-2px;"><span leaf="">{no}</span></p>'
        '<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0px;text-align:center;font-size:8px;font-weight:700;color:rgb(209,213,219);letter-spacing:2px;"><span leaf="">PART</span></p>'
        '</section>'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;margin-bottom:unset;">'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0px 0px 1px;font-size:17px;font-weight:900;color:rgb(17,24,39);letter-spacing:0.3px;"><span leaf="">{title}</span></p>'
        f'{sub_html}'
        '</section>'
        '</section></section>'
    )


def write_last_header(title="写在最后", subtitle="WRAP-UP · 一表看懂"):
    """写在最后标题（严格套用 w母板原版结构）。

    左列（居中对齐）：28px 翡翠绿 `///` + 8px 灰字 `LAST`
    右列：17px/900 「写在最后」 + 11px 灰副标题
    """
    return (
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;overflow:visible;" data-pm-slice="0 0 []">'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;display:flex;align-items:center;gap:16px;margin-bottom:24px;">'
        '<section data-keep-center="1" style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;text-align:center;flex-shrink:0;margin-bottom:unset;">'
        '<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0px;text-align:center;font-size:28px;font-weight:900;color:rgb(5,150,105);line-height:1;letter-spacing:-2px;"><span leaf="">///</span></p>'
        '<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0px;text-align:center;font-size:8px;font-weight:700;color:rgb(209,213,219);letter-spacing:2px;"><span leaf="">LAST</span></p>'
        '</section>'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;margin-bottom:unset;">'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0px 0px 1px;font-size:17px;font-weight:900;color:rgb(17,24,39);letter-spacing:0.3px;"><span leaf="">{title}</span></p>'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0px;font-size:11px;font-weight:600;color:rgb(156,163,175);letter-spacing:1.5px;"><span leaf="">{subtitle}</span></p>'
        '</section>'
        '</section></section>'
    )


def green_card(inner_html):
    """引言框（新版w母板样式）。

    结构：绿色边框 + 内部padding + 内容区
    """
    return (
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;margin:10px 0px;">'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;border:1px solid rgb(102,158,73);padding:15px;border-radius:10px;margin-bottom:unset;">'
        f'<span style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;">{inner_html}</span>'
        '</section></section>'
    )


def card_p(text):
    """卡片内段落（带行距2）。"""
    return (f'<p style="margin:0;line-height:2;color:rgb(31,41,55);font-size:14px;'
            f'letter-spacing:.2px;">'
            f'<span style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;">{text}</span></p>')


def ending_empty_lines(n=2):
    """结尾空行（供作者在草稿箱自行补充内容）。"""
    return '<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0px;"><span leaf=""><br /></span></p>' * n


def title_card(kicker, date, lines, tags, bottom_label):
    """标题卡（引言框上方的大标题卡）。

    结构：
    - 顶部：kicker（分类标签）+ 分割线 + date（日期）
    - 中间：删除线副标题 + 主标题（多行，部分绿色高亮）
    - 底部：翡翠绿渐变底栏 + 标签徽章
    """
    # 副标题（删除线）
    subtitle_lines = ''.join(f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:-11px 0px 6px;font-size:15px;color:rgb(209,213,219);text-decoration:line-through;letter-spacing:.5px;text-indent:-3em;"><span leaf="">&nbsp; {line}</span></p>' for line in lines[:-1])
    # 主标题（最后两行，部分绿色）
    main_line = lines[-1] if lines else ""
    # 简化处理：主标题整行输出，绿色部分由调用方控制
    main_html = f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:-11px 0px 0px;font-size:24px;font-weight:900;color:rgb(17,24,39);line-height:1.05;letter-spacing:-2px;text-indent:-3em;text-align:left;"><span leaf="">&nbsp; &nbsp; &nbsp; &nbsp;{main_line}</span></p>'

    # 标签徽章
    tags_html = ''.join(f'<span style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;background:rgba(255,255,255,0.2);padding:1px 6px;border-radius:3px;font-size:8px;color:rgb(255,255,255);font-weight:600;"><span leaf="">{tag}</span></span>' for tag in tags)

    return (
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;"><section data-support="96编辑器" data-style-id="44442" data-pm-slice="0 0 []" style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;">'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;margin:10px 0px;">'
        # 外框不设 padding（内边距交给内容区那一层），否则作为外框子元素的渐变底栏
        # 会被左右各顶进 padding 的距离，出现「绿色背景条顶不到方框两头」的问题。
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;border:1px solid rgb(102,158,73);border-radius:10px;margin-bottom:unset;overflow:hidden;">'
        '<section data-mpa-powered-by="yiban.io" style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;">'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;padding:32px 28px 28px;">'
        # 顶部：kicker + 分割线 + date
        f'<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;display:flex;align-items:center;gap:8px;margin-bottom:28px;">'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:-11px 0px 0px;font-size:11px;font-weight:700;letter-spacing:3px;color:rgb(5,150,105);text-indent:-3em;"><span leaf="">{kicker}</span></p>'
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;flex:1 1 0%;height:1px;overflow:hidden;background-image:linear-gradient(to right, rgba(5,150,105,0.118), transparent);"></section>'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:-11px 0px 0px;font-size:10px;color:rgb(209,213,219);font-weight:600;text-indent:-3em;"><span leaf="">{date}</span></p>'
        '</section>'
        # 中间：副标题 + 主标题
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;">'
        f'{subtitle_lines}'
        f'{main_html}'
        '</section>'
        # 底部：渐变底栏（贴外框左右，底部随外框圆角）
        '<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;background-image:linear-gradient(135deg, rgb(5,150,105), rgb(16,185,129));background-position:initial;background-size:initial;background-repeat:initial;background-attachment:initial;background-origin:initial;background-clip:initial;padding:12px 28px;border-radius:0 0 9px 9px;display:flex;align-items:center;justify-content:space-between;">'
        f'<p style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;clear:both;min-height:1em;margin:0px;font-size:12px;color:rgba(255,255,255,0.894);font-weight:600;letter-spacing:.5px;"><span leaf="">{bottom_label}</span></p>'
        f'<section style="max-width:100%;box-sizing:border-box;overflow-wrap:break-word;display:flex;gap:4px;">{tags_html}</section>'
        '</section>'
        '</section></section></section></section></section>'
    )


def figure(url, caption=""):
    cap = (f'<p style="margin:8px 0 0;font-size:12px;color:rgb(156,163,175);'
           f'text-align:center;letter-spacing:.3px;">{caption}</p>') if caption else ""
    return (f'<section style="margin:18px 0;box-sizing:border-box;overflow-wrap:break-word;">'
            f'<img src="{url}" style="width:100%;border-radius:8px;display:block;" />{cap}</section>')
