# w母板关键格式提取笔记（fmg-szhtw）

本 skill 严格套用草稿箱真实结构，避免凭记忆出错。当前版本 v1.2.3（全文左对齐、尾部 chrome 完整保留）的关键格式如下。

## 1. 引言框（标题卡）结构
- **来源**：草稿箱《引言框》文章 / w母板正文首屏。
- **结构（v1.2.1 正确版）**：
  - **外框**：`border:1px solid rgb(102,158,73)` + `border-radius:10px` + `overflow:hidden`，**不设 padding**（← 贴边的关键）
  - **内容层**：`padding:32px 28px 28px`，内含 flex 头（kicker 绿字 11px + 渐变线 + 日期 10px 灰）、删除线 15px、24px 大标题、13px 标签行
  - **底栏**：翡翠绿渐变 `linear-gradient(135deg, rgb(5,150,105), rgb(16,185,129))`，`padding:12px 28px` + `border-radius:0 0 9px 9px`，左右两端贴外框内边缘
- **实现**：脚本 `intro_title_card()`。`date` 默认 `today.strftime("%Y.%m")`，可经 `intro_card.date` 覆盖。
- **注意**：正文前**不插任何装饰图**（早期红星星 gif 已移除）。

## 2. PART 章节头结构（v1.2.2 修复）
- **来源**：w母板示例正文 01~06 章节头。
- **结构**（外层容器 + flex 行）：
  - 外层：`overflow: visible;` + `data-pm-slice="0 0 []"`
  - flex 行：`display:flex;align-items:center;gap:16px;margin-bottom:24px`
  - **左列**：`text-align:center;flex-shrink:0` + `data-keep-center="1"`
    - 编号：`28px / 900 / rgb(5,150,105)`，`line-height:1`，`letter-spacing:-2px`
    - 小字：`8px / 700 / rgb(209,213,219)`，`letter-spacing:2px`，内容固定为 `PART`
  - **右列**：`margin-bottom:unset`
    - 主标题：`17px / 900 / rgb(17,24,39)`，`letter-spacing:0.3px`，`margin:0 0 1px`
    - 副标题：`11px / 600 / rgb(156,163,175)`，`letter-spacing:1.5px`，形如 `TWO ASSISTANTS · 分工与定位`
- **实现**：`template_layout.part_header(no, title, sub)`；`ARTICLE["parts"][*]["sub"]` **必须填**，留空则右列只剩一行。
- **禁止**：在 build 脚本里用 `T.part_header = ...` 覆盖成「绿底白字圆角徽章 + 单行标题」（v1.1.x 的老写法，与母板不一致）。

## 3. 写在最后 标题
- **来源**：w母板示例正文。
- **结构**：与 PART 章节头同构 —— 左列 `///`(28px 绿) + `LAST`(8px 灰)（`data-keep-center="1"` 居中）；右列「写在最后」(17px/900) + 副标题(11px 灰，`WRAP-UP · …`)。
- **实现**：`template_layout.write_last_header()`；build 脚本里直接调用，不要再本地重写。
- **注意**：正文**不要整体放框**，仅末句金句用 `green_card` 单独包。

## 4. 文章尾部 chrome（v1.2.3 修复）
- **已移除**原 w母板「★扫码体验 WorkBuddy」结尾区块（含邀请链接与二维码），原位置改留**两个空行**（`ending_html`），由作者在草稿箱自行添加内容。
- **尾部三块必须完整带回**（顺序固定，缺一块就会出现「末尾空白 + 间隙过大」）：
  1. **关于作者块** — `<section style="line-height: 2em;">` 内：「关于作者」四字带翡翠绿下划线（`text-decoration-color: rgb(122,235,129)`、`text-underline-offset:5px`）+ 简介句。
  2. **三连提示卡** — 圆角卡 `border-radius:16px` + 浅灰径向渐变底 + `1px solid rgb(229,231,235)` 描边；内容为 `既然看到这里了…随手点个赞、在看、转发三连吧` + 三个 40×40 图标格（点赞 / 在看为灰，**转发为翡翠绿高亮 `rgb(5,150,105)`**）+ `THANKS FOR READING`。外框自带 `margin:0 0 24px;padding:32px 20px`，**居中排版**。
  3. **往期回顾挂件** — `<section data-role="outer" data-mp-plugin="96weixin" ...>`：96编辑器矩阵 + 底部「再不关注将损失1个亿」关注 CTA。
  4. 文件末尾另有 `<p style="display:none"><mp-style-type data-value="3"/></p>`。
- **处理规则**：
  - 只有「关于作者块」可以左对齐 / 收窄（`ftr_bio`）；
  - **三连卡（`ftr_cta`）必须跳过左对齐清洗**，否则卡片内的 `text-align:center` 被改成 left，卡片会歪；
  - 往期回顾矩阵（`ftr_matrix`）一律原样，不动 width / padding / text-align。
- **空隙收紧**：三连卡外框 `margin: 0px 0px 24px;` → `margin: 0px;`（`tighten_cta()`），消除它与往期回顾之间那条过大的空白带。

## 5. 整篇左对齐（关键坑）
- **根因**：`split_template` 切出的 `hdr` 末尾是未闭合的居中容器（含 `text-align:center`），正文被嵌在其中，**段落自身无 text-align 会继承居中**。
- **错误修法**：仅把正文字面 `text-align:center` 替换成 `left` 无效（继承依旧）。
- **正确修法**（脚本已内置）：
  1. `_left_align()`：先用 `_KEEP_CENTER` 正则把 `data-keep-center="1"` 的块 **stash** 起来，再替换字面 `text-align:center/justify`，最后回填 —— 保证 PART / LAST 编号列仍居中；
  2. `_force_left()`：给 middle/ftr_bio 内每个带 style 的块级标签（`p/section/div/li/h1-3`）显式注入 `text-align:left`；
  3. 再给 middle/ftr_bio 各包一层 `<section style="text-align:left;">` 外层兜底（**空段不包**，否则会留下空 wrapper）。
- 母板顶部 banner 装饰、三连卡、往期回顾矩阵都不动。

## 6. 母板 chrome 切分（v1.2.3 修正）
- 母板结构（逐块按 section 深度核对过）：
  - ① 头 chrome = banner gif + 加星标 + 公众号名片挂件
  - ② 正文 demo 区 = 引言框 + PART 章节 + 写在最后 + ★扫码块（由 `build_middle` 整体替换）
  - ③ 尾部 chrome = **关于作者** → **三连卡** → 往期回顾矩阵 + 关注 CTA
  - ④ 末尾 `<p style="display:none"><mp-style-type …/></p>`
- **切分规则**（`template_layout.split_template`）：
  - **头 hdr** = 首个 `<section ... data-pm-slice="0 0 []">` 之前
  - **尾 ftr** = **「关于作者」所在顶层 section 起**（用 `_depth0_open()` 把切分点对齐到完整标签边界，避免标签被拦腰截断产生可见垃圾文本）
  - 二级切分：`split_footer(ftr)` → `(关于作者区, 三连卡, 往期回顾矩阵)`
- **⚠️ 反面教材（务必别重犯）**：v1.2.0~v1.2.2 曾把尾部切分点设到最后一个 `data-mp-plugin="96weixin"`，理由是「新母板已无『关于作者』文字」。这个判断来自**编码错乱的本地母板副本（mojibake）**——中文全部搜不到，于是误判。后果是「关于作者 + 三连卡」整段丢失。**上一步是错的：英文属性名（`data-mp-plugin`）在 mojibake 文件里照样能搜到，中文则搜不到，这种"英文能搜、中文搜不到"的分裂现象就是编码错的信号。**
- 切分后自检：`ftr` 必须同时含 `关于作者` / `既然看到这里了` / `THANKS FOR READING` / `96weixin`，且四者顺序递增；`hdr + middle + ftr` 首屏应是「banner → 名片 → 标题卡」，不含母板示例正文。

## 7. 提交校验 marker 注意
- marker 必须用正文**稳定金句**（如「写在最后」），不要用会被改写掉的字面量（如代码里的 `RESOURCE_URLS`）。

## 8. 封面上传
- `make_cover_thumb()` 把 `XXFSBTW_COVER`（或脚本内 `COVER_SRC`）裁切为 900×383 上传永久素材作 thumb；未配置则回退母板封面 `thumb_media_id`。
- 上传失败仅 WARN 并回退，不影响正文提交。

## 9. 标题卡底栏「顶不到方框两头」（v1.2.1 修复）
- **现象**：生成的推文里，标题卡内绿色渐变底栏左右各有约 12px 留白，不像母板那样占满方框。
- **根因**：底栏是标题卡**外框的子元素**，而外框自身带了 `padding`（早先写的是 `padding:12px`），底栏因此被左右各顶进 12px。母板是把内边距放在「内容层」而不是外框上。
- **正确写法**：外框 `padding:0`；内容层 `padding:32px 28px 28px`；底栏 `padding:12px 28px` + `border-radius:0 0 9px 9px`；外框加 `overflow:hidden` 保证底部圆角。
- **不要**用负 margin 补偿（微信端裁剪不可靠）。

## 10. 往期回顾矩阵与「后台回复」提示图之间的空隙（v1.2.5 修复）

母板尾部挂件（`data-mp-plugin="96weixin"`，约 46k 字符）内部结构：

| 区间 | 内容 |
|---|---|
| 挂件开头 ~ 矩阵结束 | 细线 gif + 6 张矩阵卡（`width:32%` inline-block，卡间 `height:23px` spacer + `margin-bottom:-28px`） |
| 矩阵之后 | **关注条区**：锚点文案「再不关注将损失1个亿」，容器叠加 `padding: 1em` + `margin: 10px 0px`×2 + `padding: 10px`，提示图前还有 `height:25px` 条与 `height:5px` 双线 |
| 挂件末尾 | 「后台回复」提示图：jpg（data-w=1080，无 width，自适应）+ gif（data-w=596，**写死 `width: 578px`**） |

**症状**：手机端矩阵下出现约 100px 空白带，提示图还与正文不等宽。

**修法**（`template_layout.tighten_matrix()`）：
1. 以「再不关注将损失1个亿」定位关注条；向前找含 `padding: 1em` 的 `<section>`，再上爬一层拿到 `width: 578px` 外层容器，作为收紧区间起点；
2. 区间内 `padding: 1em` / `margin: 10px 0px` / `padding: 10px` → 全部归零；`width: 578px` → `width: 100%`（影响关注条容器 + 提示图 gif）；
3. **矩阵卡片区（含 spacer）完全不动**——布局由平台渲染，乱改会影响矩阵；
4. 锚点找不到（母板改版）时原样返回，不做任何替换。

**注意**：区间外的 `width: 578px`（挂件最外层容器）保留不动，与母版行为一致。

## 11. 离线自检
- `scripts/check_layout.py`：14 条断言 —— 底栏贴边 / 金句卡 padding=12px / 页脚挂件 / 写在最后 / **关于作者 + 三连卡存在且顺序为「关于作者 → 三连 → 往期回顾」** / **三连卡保持居中未被左对齐污染** / **三连卡下外边距已归零** / PART 两行版式（PART 小字 + 副标题 + 编号列居中）/ 无旧版徽章样式。
- 改版后先跑它，再提交草稿箱，避免来回试错（微信接口调用有 IP 白名单限制）。
