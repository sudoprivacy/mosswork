---
name: skillhub-skill-zzt
description: "妖股封单玄机判延续课程-每日集合竞价选股完整执行流程。含三时点快照(9:15/9:20/9:25)抓取机制、情绪闸门判定、最强题材锁定、题材情绪转强对比、Web选股系统启动维护。当用户要求\"集合竞价选股\"\"分时抓涨停\"\"按课程选股\"\"竞价抓涨停\"时使用。"
---

# 集合竞价抓涨停 · 每日选股执行流程

课程来源：《妖股-暗夜猎锋-第四课 封单玄机判延续》。核心：**判延续 = 竞价定主流 + 盘口定涨停**。七位一体体系：选→定→试→增→持→减→离。

## 一、课程三标准（严格按此执行，勿改）

| 步骤 | 标准 | 判定 |
|---|---|---|
| ① 情绪闸门 | 9:25 一字板(开盘即涨停)封单>5000万家数 | >5可开仓做短线；≥15=高潮炸板日，不开仓·减仓；<5观望 |
| ② 最强题材 | 一字板封单>5000万题材中，一字板家数最多 | 该题材=当日最强主线 |
| ③ 题材情绪转强 | **当日**9:15/9:20/9:25三时点题材家数变化 | 递增=转强✅；递减=转弱❌；集体涨停=炸板日 |
| ④ 盘口四步 | 开盘定势→检测合力→启动信号→介入点 | 拉升≥3%→小幅震荡+缩量+触黄线反弹→大单破前高→启动点/回踩点 |

⚠️ 题材情绪转强**必须是当日三时点对比**，禁止跨日对比。

## 二、数据源与路径

- **通达信（主数据源，当日实时）**: `stock-selector/tdx_data.py`（pytdx 连接行情服务器 + 本地 C:\new_tdx\vipdoc\lday 文件名作全市场代码清单）
  - 实时快照 get_security_quotes：price/last_close/open/bid_vol1(买一量=封单)/servertime（当日实时，解决T+1）
  - 涨停价 = 昨收×(1.1主板/1.2创业科创)；封单额 = bid_vol1(手)×100×price；一字板 = open≈涨停价
  - 服务器：115.238.56.198:7709 等；本地通达信 C:\new_tdx 需存在（代码清单来源）
- **westock-tool**（历史日期/T+1）: `D:\WPS Office永久激活版安装包\WorkBuddy\resources\app.asar.unpacked\resources\builtin-skills\westock-tool\scripts\index.js`
- **westock-data**（历史行情/名称补充）: `D:\WPS Office永久激活版安装包\WorkBuddy\resources\app.asar.unpacked\resources\builtin-skills\westock-data\scripts\index.js`
- **ifind**（概念归属）: `C:\Users\zmszm\.workbuddy\skills\ifind-finance-data\call-node.js`（密钥在 mcp_config.json）
- **node**: `C:\Users\zmszm\.workbuddy\binaries\node\versions\22.22.2\node.exe`
- **python**: `C:\Users\zmszm\.workbuddy\binaries\python\envs\default\Scripts\python.exe`（pytdx 已装）

## 三、核心数据计算

```js
// 通达信实时（当日主数据源）
封单金额 = bid_vol1(买一量,手) × 100 × price
涨停价 = round(昨收 × 1.10, 2)  // 主板；创业30/科创68 ×1.20；ST ×1.05(需名称)
一字板 = |open - 涨停价| < 0.011
// 名称：通达信快照无名称，用 westock quote 补（缓存 names_cache.json）

// westock 历史/收盘（历史日期）
封单金额 = LimitUpVolume × 100 × price   // price=该日涨停价（quote --date）

// 通用概念黑名单（过滤后剩真题材）
融资融券|深股通|沪股通|转融券|国企改革|一带一路|中证\d+|上证\d+|MSCI|专精特新|注册制次新股|高股息精选|ST股|创投|土地流转|京津冀一体化|人民币贬值受益...
```

## 四、完整执行流程

### A. 每日三时点快照抓取（9:15 / 9:20 / 9:25）
1. **竞价盘中（9:15-9:25）必须用东财实时涨停池**（见七、替代源）：`getTopicZTPool?date=YYYYMMDD` → `data.pool[]` 即当日实时涨停+封单；`westock ranking limitup_seal_volume` 盘中只返回昨日收盘数据，**不可用于当日时点快照**（仅收盘后回补历史可用）
2. 对涨停池每只 `quote <代码> --date YYYY-MM-DD --raw` → price / price_ceiling / open 校验一字板与行情
3. 封单金额取 `fund`（元）→ 筛选 >5000万 → 判一字板（fbt=92500 且 zbc=0）
4. `ifind get_stock_info` 查一字板封单>5000万股的所属概念（**每批≤5只**，query格式"简称+代码、...的所属概念板块"），过滤通用概念
5. 保存快照 `snapshots/{date}-{0915|0920|0925}.json`：
   ```json
   {"date":"YYYY-MM-DD","label":"0915","yzb_big_count":6,"big_count":42,
    "yzb_concept_groups":[{"name":"创新药","count":2}],
    "stocks":[{"code","name","seal_amount_yi"}]}
   ```

### B. 选股判定
1. 情绪闸门：一字板封单>5000万家数 → 5-15可开仓/≥15炸板日
2. 最强题材：一字板题材分布取家数最多
3. 三时点对比：读取当日 snapshots 的 0915/0920/0925 三份快照，题材家数变化（t3-t1）
4. 主线候选股：封单>5000万且概念命中主线关键词

## 五、Web 选股系统

- 位置：`stock-selector/server.js` + `public/index.html`（暗红#8B1A1A主色、老年友好大字版）
- 启动：`cd stock-selector && node server.js` → http://localhost:3210
- API：
  - `GET /api/select?date=YYYY-MM-DD` → 当日选股结果（含 time_series 三时点对比）
  - `GET /api/capture?date=YYYY-MM-DD&label=0915` → 抓取并保存时点快照
  - `GET /api/health`
- 快照目录：`stock-selector/snapshots/`

## 六、自动化任务（每交易日）

- **9:15** 抓快照 label=0915
- **9:20** 抓快照 label=0920
- **9:25** 抓快照 label=0925 + 输出当日选股报告（情绪闸门/最强题材/三时点对比/主线候选股）
- rrule：`FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR;BYHOUR=9;BYMINUTE=15|20|25`
- 历史日期时点快照**无法回补**（收盘后时点数据失效），三时点对比从抓取日起生效

## 七、已知限制

- 东方财富板块API（push2.eastmoney.com）在沙箱内 fetch 失败 → 用 ifind 概念分组降级最强题材
- ⚠️ **westock-tool `limitup_seal_volume` 是"收盘涨停封单量"指标（官方文档确认），竞价盘中（9:15-9:25）查询当日日期只返回上一交易日（TradeDate=昨日）的收盘数据，无法获得今日竞价实时封单。2026-08-13 实测三次（9:15:30/9:19/9:25:40）均返回 20260812**
- ✅ **今日竞价实时涨停数据的替代源：东方财富实时涨停池** `https://push2ex.eastmoney.com/getTopicZTPool?ut=7eea3edcaed734bea9cbfc24409ed989&dpt=wz.ztzt&Pageindex=0&pagesize=200&sort=fbt:asc&date=YYYYMMDD`（沙箱 fetch 可用）
  - 返回 `data.pool[]`：`c`=代码、`m`(0深/1沪)、`n`=名称、`p`=价格(×1000)、`fund`=封单资金(元)、`fbt`=首次封板时间(HHMMSS，92500=竞价一字板)、`lbt`、`lbc`=连板数、`zbc`=炸板次数、`hybk`=行业板块、`zttj.days`=连续涨停天数
  - 一字板判定 = `fbt≈92500`（竞价封板）且 `zbc=0`；封单金额直接用 `fund` 字段（元）
- 历史 9:15/9:20 时点封单无免费数据源，必须当日实时抓取（东财实时涨停池当日有效，收盘后时点数据失效）
- 盘口四步需盘中实时分时确认，快照仅覆盖竞价阶段

## 八、风险提示

课程观点仅供教学参考，不构成投资建议和买卖依据。涨停股存在炸板风险，需严控仓位与止损。
