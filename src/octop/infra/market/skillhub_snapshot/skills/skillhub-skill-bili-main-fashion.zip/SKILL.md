---
name: skillhub-skill-bili-main-fashion
description: "当用户想按 B 站「时尚」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：时尚、B站分区、rid 155。"
---

# B 站分区 · 时尚

- 一级分区 rid：`155`；网页路由：`/v/fashion/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 95 条榜单条目，覆盖 4 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 仿妆cos | 50 | 10 | 252 |
| 时尚潮流 | 8 | 10 | 159 |
| 穿搭 | 18 | 10 | 158 |
| 美妆护肤 | 19 | 10 | 157 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 仿妆cos

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 爸爸！我已经不是83岁的小孩啦… | 迷迷人鹿 | [BV1g2R2Y8EsH](https://www.bilibili.com/video/BV1g2R2Y8EsH) | 604.7 万 |
| 被全网催爆的不掉帧黑帮摇纯享版新鲜出炉！！ | 好吃不过生巧 | [BV1PpZ2YoEoS](https://www.bilibili.com/video/BV1PpZ2YoEoS) | 290.3 万 |
| 【初九】哪吒2角色 谁是你心中的top1 | 初九Haimon | [BV1SYRBYTES4](https://www.bilibili.com/video/BV1SYRBYTES4) | 1880.7 万 |
| 【kigurumi】给小人偶选错了家具的尺寸… | 恶毒可人儿 | [BV1reZ2YJE7y](https://www.bilibili.com/video/BV1reZ2YJE7y) | 321.6 万 |
| 哥几个又来看贴贴啦？ | 腥味猫罐 | [BV1EdZ1YLEYc](https://www.bilibili.com/video/BV1EdZ1YLEYc) | 159.4 万 |

### 时尚潮流

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 所以灰太狼你准备好了吗？ | 康康和爷爷 | [BV1b4RRYLEHP](https://www.bilibili.com/video/BV1b4RRYLEHP) | 204.8 万 |
| 经费爆表！什么婚纱连租都要上万啊？？？ | 爱吃Alice的糖醋里脊 | [BV19yZ2YrEgF](https://www.bilibili.com/video/BV19yZ2YrEgF) | 65.7 万 |
| 不忘来时路 回家代表广西巡游啦！ | 氧化菊 | [BV1XaZmYzEVm](https://www.bilibili.com/video/BV1XaZmYzEVm) | 114.4 万 |
| 这年头不懂点细节还真不好买衣服！！ | Tina面料测评 | [BV1acR2YcEft](https://www.bilibili.com/video/BV1acR2YcEft) | 65.5 万 |
| 我的灵魂一部分要泡在海盐柠檬味的盛夏里 | 夏洛特抓拍公主 | [BV1qpdWYrEp3](https://www.bilibili.com/video/BV1qpdWYrEp3) | 116.4 万 |

### 穿搭

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 花会沿路途盛开 以后的路也是 | 白昼小熊 | [BV1MeZRYHEP5](https://www.bilibili.com/video/BV1MeZRYHEP5) | 155.3 万 |
| 一个视频教你，普通人咱们素颜就可以穿得很出彩 | 谷梨梨本人账号 | [BV1ENZXYYEJF](https://www.bilibili.com/video/BV1ENZXYYEJF) | 160.4 万 |
| 主包主包 听说你们玩cos的宁可饿死也要。。。 | 小小的小兔团儿 | [BV1PKRBYdELe](https://www.bilibili.com/video/BV1PKRBYdELe) | 136.7 万 |
| 太好了不是吊带 粗胳膊有救了! 推荐一些有袖子的夏装 163cm54kg | 鹦鹉梨 | [BV1D3RqYaEvm](https://www.bilibili.com/video/BV1D3RqYaEvm) | 105.9 万 |
| 温柔姐姐 | 中国梨自救 | [BV1c7dxYXEZb](https://www.bilibili.com/video/BV1c7dxYXEZb) | 29.1 万 |

### 美妆护肤

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 最近很火的医用卫生巾到底怎么样… | 搞事明天吃什么 | [BV1EJZmYUEAz](https://www.bilibili.com/video/BV1EJZmYUEAz) | 38.4 万 |
| 挑战让tony自由发挥！没想到居然把“春天”染在了头发上… | 叫我22就好啦 | [BV1H2RoYgEw6](https://www.bilibili.com/video/BV1H2RoYgEw6) | 114.7 万 |
| 宁艺卓统治大屏！猫系妆容简直上镜的神 | 知日wit | [BV1UdZ2YPEv9](https://www.bilibili.com/video/BV1UdZ2YPEv9) | 38.1 万 |
| 大开眼界！！也没人告诉我化妆品要看说明书啊…… | 一盏登隆 | [BV1wsZdY7EYR](https://www.bilibili.com/video/BV1wsZdY7EYR) | 41.7 万 |
| 避雷！沉浸式卸再也不会画的妆！ | 聂小倩她老板 | [BV1D2RdYnEiV](https://www.bilibili.com/video/BV1D2RdYnEiV) | 47.8 万 |

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=155." https://api.bilibili.com/x/web-interface/ranking/v2?rid=155&type=all. Accessed 6 Nov. 2026.
