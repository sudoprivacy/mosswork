#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
鉴股八步法深度研究 - Word报告生成模板脚本
使用方法: Agent 修改下方 ═══ DATA SECTION ═══ 中的数据常量后运行此脚本
依赖: pip install python-docx matplotlib numpy
"""
import os, sys, math, datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib.ticker import FuncFormatter
import numpy as np

# ── matplotlib 中文与颜色设置 ──
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False
C_GREEN  = (46/255,125/255,50/255)   # 看多
C_RED    = (198/255,40/255,40/255)    # 看空
C_BLUE   = (21/255,101/255,192/255)   # 中性
C_GRAY   = (0.5,0.5,0.5)

# Agent 需修改输出目录为自己的工作目录
OUT_DIR = os.path.dirname(os.path.abspath(__file__))
CHART_DIR = os.path.join(OUT_DIR, "charts")
os.makedirs(CHART_DIR, exist_ok=True)

# ═══════════════════════════════════════════════════════════
# DATA SECTION — Agent 在此填入联网搜索采集的数据
# ═══════════════════════════════════════════════════════════

STOCK_NAME = "[填入股票名]"           # 例: "药明康德"
STOCK_CODE = "[填入代码]"             # 例: "603259.SH"
INDUSTRY_NAME = "[填入行业名]"         # 例: "CXO/医药外包"
ANALYSIS_DATE = "[填入日期]"           # 例: "2026-07-15"
CURRENT_PRICE = 0.0                   # 收盘价
TOTAL_MCAP = 0.0                      # 总市值(亿元)
PE_TTM = 0.0                          # PE(TTM)
PB = 0.0                              # PB
PS_TTM = 0.0                          # PS(TTM)
DIV_YIELD = 0.0                       # 股息率%
EV_EBITDA = 0.0                       # EV/EBITDA

# ── 历年财务数据(近5年) ──
FINANCIAL_YEARS = [2021, 2022, 2023, 2024, 2025]
FIN_REVENUE   = []  # 营收(亿)
FIN_NETPROFIT = []  # 归母净利(亿)
FIN_ADJ_NETPROFIT = []  # 扣非净利(亿)
FIN_GROSSMARGIN = []   # 毛利率%
FIN_NETMARGIN  = []    # 净利率%
FIN_ROE        = []    # ROE%(加权)
FIN_ROE_ADJ    = []    # 扣非ROE%
FIN_DEBT_RATIO = []    # 资产负债率%
FIN_OCF        = []    # 经营现金流(亿)
FIN_FCF        = []    # 自由现金流(亿)
FIN_INVENTORY_TURN = []  # 存货周转率
FIN_AR_TURN    = []    # 应收账款周转率
FIN_TOTAL_ASSET_TURN = []  # 总资产周转率
FIN_EQUITY_MULT = []  # 权益乘数

# ── 业务板块 ──
# 格式: {"板块名": {"revenue": X, "pct": X, "margin": X, "growth": X}}
BUSINESS_SEGMENTS = {}

# ── 同业对比 ──
# 格式: {"公司名": {"PE": X, "PB": X, "PS": X, "ROE": X, "MCAP": X, "REV_G": X}}
PEERS = {}

# ── 行业景气度评分(1-5) ──
INDUSTRY_SCORES = {"供需格局": 0, "价格趋势": 0, "政策环境": 0, "技术变革": 0, "库存周期": 0}
INDUSTRY_TOTAL_SCORE = sum(INDUSTRY_SCORES.values()) / 5

# ── 护城河评分 ──
MOAT_SCORES = {}  # {"维度": "强/中/弱"}
COMPETITIVENESS = {}  # {"维度(权重)": 分数1-10}
COMP_TOTAL = sum(v for v in COMPETITIVENESS.values()) / len(COMPETITIVENESS) if COMPETITIVENESS else 0

# ── 估值历史分位数 ──
PE_5Y_LOW = 0; PE_5Y_HIGH = 0; PE_5Y_MEDIAN = 0; PE_CURRENT_PCT = 0
PB_5Y_LOW = 0; PB_5Y_HIGH = 0; PB_5Y_MEDIAN = 0; PB_CURRENT_PCT = 0

# ── 近期行情数据(近7日) ──
RECENT_DATES = []
RECENT_CLOSE = []
RECENT_HIGH  = []
RECENT_LOW   = []
RECENT_VOL   = []  # 万手

# ── 斐波那契 ──
FIB_HIGH = 0.0   # 本轮行情高点
FIB_LOW  = 0.0   # 本轮行情低点(起点)

# ── 多周期技术评分 ──
TECH_SCORES = {}  # {"周期": {"score": X, "status": "描述"}}

BASIC_FUND_SCORE = 0  # 基本面综合评分(/100)

# ── 行业周期定位文字 ──
INDUSTRY_CYCLE_TEXT = "[填入:如'底部复苏→上行扩张']"
INDUSTRY_CYCLE_DIR = "[填入:↑上行/↓下行/→平稳]"
VALUATION_METHOD = "[填入:如'PE估值(盈利扩张期)']"

# ── 护城河结论文字 ──
MOAT_POSITION = "[填入:龙头/挑战者/追随者]"
MOAT_TYPE = "[填入:护城河类型]"

# ═══════════════════════════════════════════════════════════
# END DATA SECTION
# ═══════════════════════════════════════════════════════════

FIB_DIFF = FIB_HIGH - FIB_LOW

def fib_retract(high, low):
    """斐波那契回撤位计算（严格公式，带校验）"""
    diff = high - low
    levels = {
        "0.0%": high,
        "23.6%": high - 0.236 * diff,
        "38.2%": high - 0.382 * diff,
        "50.0%": high - 0.500 * diff,
        "61.8%": high - 0.618 * diff,
        "78.6%": high - 0.786 * diff,
        "100%": low,
    }
    vals = list(levels.values())
    for i in range(len(vals)-1):
        assert vals[i] > vals[i+1], f"回撤位计算错误: {vals[i]} <= {vals[i+1]}"
    assert levels["0.0%"] == high and levels["100%"] == low
    return levels

FIB_LEVELS = fib_retract(FIB_HIGH, FIB_LOW) if FIB_HIGH > FIB_LOW else {}
CURRENT_RETRACT_PCT = (FIB_HIGH - CURRENT_PRICE) / FIB_DIFF * 100 if FIB_DIFF > 0 else 0

# ═══════════════════════════════════════════════════════════
# 图表生成函数
# ═══════════════════════════════════════════════════════════

def save_chart(fig, name):
    path = os.path.join(CHART_DIR, name)
    fig.savefig(path, dpi=200, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    return path

# 图1: 近7日K线与成交量
def chart_kline():
    fig, (ax1, ax2) = plt.subplots(2, 1, height_ratios=[3,1], figsize=(10,5))
    fig.suptitle(f'{STOCK_NAME}({STOCK_CODE}) 近7日K线与成交量', fontsize=14, fontweight='bold')
    x = range(len(RECENT_DATES))
    for i in x:
        c = RECENT_CLOSE[i]; h = RECENT_HIGH[i]; l = RECENT_LOW[i]; o = l + (h-l)*0.3
        color = C_GREEN if c >= o else C_RED
        ax1.bar(i, c-o, bottom=o, width=0.6, color=color, alpha=0.8)
        ax1.plot([i,i], [l,h], color=color, linewidth=1.5)
    ax1.set_xticks(x); ax1.set_xticklabels(RECENT_DATES)
    ax1.set_ylabel('价格(元)'); ax1.grid(alpha=0.3)
    colors_vol = [C_GREEN if RECENT_CLOSE[i] > RECENT_LOW[i]+(RECENT_HIGH[i]-RECENT_LOW[i])*0.3 else C_RED for i in x]
    ax2.bar(x, RECENT_VOL, color=colors_vol, alpha=0.6, width=0.6)
    ax2.set_xticks(x); ax2.set_xticklabels(RECENT_DATES)
    ax2.set_ylabel('成交量(万手)'); ax2.grid(alpha=0.3)
    fig.tight_layout(rect=[0,0,1,0.95])
    return save_chart(fig, '01_kline.png')

# 图2: 行业景气度雷达图
def chart_radar():
    labels = list(INDUSTRY_SCORES.keys())
    values = list(INDUSTRY_SCORES.values())
    N = len(labels)
    angles = np.linspace(0, 2*np.pi, N, endpoint=False).tolist()
    values_plot = values + values[:1]
    angles_plot = angles + angles[:1]
    fig, ax = plt.subplots(figsize=(7,7), subplot_kw=dict(polar=True))
    ax.fill(angles_plot, values_plot, color=C_BLUE, alpha=0.25)
    ax.plot(angles_plot, values_plot, color=C_BLUE, linewidth=2)
    ax.set_ylim(0,5); ax.set_yticks([1,2,3,4,5])
    ax.set_xticks(angles); ax.set_xticklabels(labels, fontsize=11)
    ax.set_title(f'{INDUSTRY_NAME}行业景气度雷达图\n综合评分: {INDUSTRY_TOTAL_SCORE:.1f}/5.0', fontsize=14, fontweight='bold', pad=20)
    for angle, val, label in zip(angles, values, labels):
        ax.text(angle, val+0.3, f'{val}', ha='center', fontsize=10, color=C_RED, fontweight='bold')
    return save_chart(fig, '02_radar.png')

# 图3: 关键财务指标趋势图
def chart_financial():
    fig, axes = plt.subplots(2,2, figsize=(12,8))
    fig.suptitle(f'{STOCK_NAME} 关键财务指标趋势({FINANCIAL_YEARS[0]}-{FINANCIAL_YEARS[-1]})', fontsize=14, fontweight='bold')
    years = FINANCIAL_YEARS
    ax = axes[0,0]
    ax.bar(years, FIN_REVENUE, color=C_BLUE, alpha=0.7, label='营收')
    ax.bar(years, FIN_NETPROFIT, color=C_GREEN, alpha=0.7, label='归母净利')
    ax.set_title('营收与净利(亿元)'); ax.legend(); ax.grid(alpha=0.3)
    ax = axes[0,1]
    ax.plot(years, FIN_GROSSMARGIN, 'o-', color=C_GREEN, linewidth=2, label='毛利率')
    ax.plot(years, FIN_NETMARGIN, 's-', color=C_BLUE, linewidth=2, label='净利率')
    ax.plot(years, FIN_ROE_ADJ, '^-', color=C_RED, linewidth=2, label='扣非ROE')
    ax.set_title('利润率与ROE(%)'); ax.legend(); ax.grid(alpha=0.3)
    ax = axes[1,0]
    ax.bar(years, FIN_OCF, color=C_GREEN, alpha=0.7, label='经营现金流')
    ax.bar(years, FIN_FCF, color=C_BLUE, alpha=0.7, label='自由现金流')
    ax.set_title('现金流(亿元)'); ax.legend(); ax.grid(alpha=0.3)
    ax = axes[1,1]
    rev_g = [(FIN_REVENUE[i]-FIN_REVENUE[i-1])/FIN_REVENUE[i-1]*100 if i>0 else 0 for i in range(len(FIN_REVENUE))]
    np_g = [(FIN_NETPROFIT[i]-FIN_NETPROFIT[i-1])/FIN_NETPROFIT[i-1]*100 if i>0 else 0 for i in range(len(FIN_NETPROFIT))]
    ax.bar(years, rev_g, color=C_BLUE, alpha=0.6, label='营收增速')
    ax.bar(years, np_g, color=C_GREEN, alpha=0.6, label='净利增速')
    ax.set_title('增速(%)'); ax.legend(); ax.grid(alpha=0.3)
    fig.tight_layout(rect=[0,0,1,0.95])
    return save_chart(fig, '03_financial.png')

# 图4: 估值同业对比图
def chart_peers():
    fig, axes = plt.subplots(1,3, figsize=(14,5))
    fig.suptitle('估值同业对比', fontsize=14, fontweight='bold')
    names = list(PEERS.keys())
    pe_vals = [PEERS[n]["PE"] for n in names]
    pb_vals = [PEERS[n]["PB"] for n in names]
    ps_vals = [PEERS[n]["PS"] for n in names]
    colors = [C_GREEN if n==STOCK_NAME else C_BLUE for n in names]
    for idx, (vals, title, unit) in enumerate([(pe_vals, 'PE(TTM)', 'x'), (pb_vals, 'PB', 'x'), (ps_vals, 'PS(TTM)', 'x')]):
        ax = axes[idx]
        bars = ax.barh(names, vals, color=colors, alpha=0.7)
        ax.set_title(title); ax.set_xlabel(unit); ax.grid(alpha=0.3)
        for bar, val in zip(bars, vals):
            ax.text(val+0.5, bar.get_y()+bar.get_height()/2, f'{val:.1f}{unit}', va='center', fontsize=9)
    fig.tight_layout(rect=[0,0,1,0.95])
    return save_chart(fig, '04_peers.png')

# 图5: 斐波那契回撤全景图
def chart_fibonacci():
    fig, ax = plt.subplots(figsize=(10,6))
    fig.suptitle(f'{STOCK_NAME} 斐波那契回撤全景图', fontsize=14, fontweight='bold')
    n_pts = 60; t = np.linspace(0,1,n_pts)
    prices = FIB_LOW + (FIB_HIGH-FIB_LOW)*t + 5*np.sin(4*t)*t
    ax.plot(t, prices, color=C_BLUE, linewidth=1.5, label='模拟走势')
    for label, price in FIB_LEVELS.items():
        color = C_RED if label in ["50.0%", "61.8%"] else C_GRAY
        ax.axhline(price, color=color, linestyle='--', alpha=0.6)
        ax.text(0.02, price, f'{label} = {price:.2f}', fontsize=9, color=color, fontweight='bold' if label in ["50.0%","61.8%"] else 'normal')
    ax.axhline(CURRENT_PRICE, color=C_GREEN, linewidth=2)
    ax.text(0.85, CURRENT_PRICE+1, f'当前 {CURRENT_PRICE:.2f}', fontsize=10, color=C_GREEN, fontweight='bold')
    ax.set_xlabel('时间(模拟)'); ax.set_ylabel('价格(元)')
    ax.set_xlim(0,1); ax.set_ylim(FIB_LOW-5, FIB_HIGH+5); ax.grid(alpha=0.3); ax.legend()
    return save_chart(fig, '05_fibonacci.png')

# 图6: 关键价位地图 — Agent 需修改 levels_data
def chart_key_levels():
    # ⚠️ Agent 需根据分析结果修改下方价位数据
    levels_data = [
        ("第三压力位", CURRENT_PRICE * 1.05, C_RED, "前高区域"),
        ("第二压力位", CURRENT_PRICE * 1.02, C_RED, "近期高点"),
        ("第一压力位", CURRENT_PRICE * 0.97, C_RED, "近期阻力位"),
        ("当前价", CURRENT_PRICE, C_GREEN, f"收盘价 {CURRENT_PRICE}"),
        ("第一支撑位", CURRENT_PRICE * 0.90, C_BLUE, "支撑位"),
        ("第二支撑位", CURRENT_PRICE * 0.86, C_BLUE, "回调支撑"),
        ("第三支撑位", CURRENT_PRICE * 0.75, C_BLUE, "关键支撑"),
    ]
    fig, ax = plt.subplots(figsize=(8,6))
    fig.suptitle(f'{STOCK_NAME} 关键价位地图', fontsize=14, fontweight='bold')
    for i, (name, price, color, desc) in enumerate(levels_data):
        ax.barh(i, price, color=color, alpha=0.5, height=0.6)
        ax.text(price+2, i, f'{name}: {price:.2f}元 — {desc}', fontsize=9, va='center')
    ax.set_yticks(range(len(levels_data))); ax.set_yticklabels([d[0] for d in levels_data])
    ax.set_xlabel('价格(元)'); ax.invert_yaxis(); ax.grid(alpha=0.3)
    fig.tight_layout(rect=[0,0,1,0.95])
    return save_chart(fig, '06_key_levels.png')

# 图7: 多周期技术信号热力图
def chart_heatmap():
    periods = list(TECH_SCORES.keys())
    indicators = ["MACD", "KDJ", "BOLL", "RSI", "均线", "量能", "综合"]
    # Agent 需填入各周期各指标的实际信号强度(0=强空,50=中性,100=强多)
    data = np.array([[80,70,75,65,80,72,TECH_SCORES[p]["score"]] for p in periods])
    fig, ax = plt.subplots(figsize=(10,6))
    im = ax.imshow(data.T, cmap='RdYlGn', aspect='auto', vmin=0, vmax=100)
    ax.set_xticks(range(len(periods))); ax.set_xticklabels(periods, fontsize=9)
    ax.set_yticks(range(len(indicators))); ax.set_yticklabels(indicators, fontsize=9)
    ax.set_title(f'{STOCK_NAME} 多周期技术信号热力图', fontsize=14, fontweight='bold')
    for i in range(len(periods)):
        for j in range(len(indicators)):
            ax.text(i, j, f'{data[i,j]:.0f}', ha='center', va='center', fontsize=8, color='black' if data[i,j]>40 else 'white')
    fig.colorbar(im, ax=ax, label='信号强度(0=强空,100=强多)'); fig.tight_layout()
    return save_chart(fig, '07_heatmap.png')

# 图8: 杜邦分解对比图
def chart_dupont():
    fig, axes = plt.subplots(1,2, figsize=(12,5))
    fig.suptitle('杜邦分解: ROE = 净利率 × 总资产周转率 × 权益乘数', fontsize=13, fontweight='bold')
    years = FINANCIAL_YEARS
    ax = axes[0]
    ax.plot(years, FIN_ROE_ADJ, 'o-', color=C_RED, linewidth=2.5, label='扣非ROE(%)', markersize=8)
    ax.set_title('ROE趋势(扣非)'); ax.set_ylabel('%'); ax.grid(alpha=0.3)
    for y, v in zip(years, FIN_ROE_ADJ):
        ax.text(y, v+0.5, f'{v:.1f}%', ha='center', fontsize=9, color=C_RED)
    ax = axes[1]
    # 使用扣非净利率估算(如无则用净利率)
    net_margins = FIN_NETMARGIN[:len(years)]
    w = 0.25; x = np.arange(len(years))
    ax.bar(x-w, net_margins, width=w, color=C_GREEN, alpha=0.7, label='净利率(%)')
    ax.bar(x, [t*100 for t in FIN_TOTAL_ASSET_TURN], width=w, color=C_BLUE, alpha=0.7, label='资产周转率×100')
    ax.bar(x+w, [e*100 for e in FIN_EQUITY_MULT], width=w, color=C_RED, alpha=0.7, label='权益乘数×100')
    ax.set_xticks(x); ax.set_xticklabels(years)
    ax.set_title('ROE三因子分解'); ax.legend(); ax.grid(alpha=0.3)
    fig.tight_layout(rect=[0,0,1,0.95])
    return save_chart(fig, '08_dupont.png')

# 图9: 资金面+情绪面综合图 — Agent 需填入实际资金流和情绪数据
def chart_fund_emotion():
    # ⚠️ Agent 需修改下方资金流和情绪数据
    days = RECENT_DATES[-5:] if len(RECENT_DATES) >= 5 else RECENT_DATES
    main_flow = [0]*len(days)  # 主力净流入(亿)
    super_flow = [0]*len(days)  # 超大单(亿)
    north_flow = [0]*len(days)  # 北向(亿)
    emotion_items = ["换手率活跃度", "量比异常度", "涨跌幅偏离", "资金分歧度", "板块联动度"]
    emotion_vals = [50, 50, 50, 50, 50]  # 0-100
    fig, (ax1, ax2) = plt.subplots(1,2, figsize=(12,5))
    fig.suptitle(f'{STOCK_NAME} 资金面与情绪面综合分析', fontsize=14, fontweight='bold')
    ax1.bar(days, main_flow, color=[C_GREEN if v>0 else C_RED for v in main_flow], alpha=0.7, label='主力净流入')
    ax1.plot(days, super_flow, 's-', color=C_BLUE, linewidth=2, label='超大单')
    ax1.plot(days, north_flow, '^-', color='orange', linewidth=2, label='北向')
    ax1.set_title('资金流向(亿元)'); ax1.legend(); ax1.grid(alpha=0.3); ax1.axhline(0, color='black', linewidth=0.5)
    colors_em = [C_BLUE if v<60 else 'orange' if v<80 else C_RED for v in emotion_vals]
    bars = ax2.barh(emotion_items, emotion_vals, color=colors_em, alpha=0.7)
    ax2.set_xlim(0,100); ax2.axvline(50, color=C_GRAY, linestyle='--', alpha=0.5)
    ax2.set_title(f'情绪温度计(平均:{np.mean(emotion_vals):.0f}/100)')
    for bar, val in zip(bars, emotion_vals):
        ax2.text(val+2, bar.get_y()+bar.get_height()/2, f'{val}', va='center', fontsize=9)
    fig.tight_layout(rect=[0,0,1,0.95])
    return save_chart(fig, '09_fund_emotion.png')

# ── 生成所有图表 ──
print("正在生成9张分析图表...")
chart_paths = {}
chart_paths['kline'] = chart_kline()
chart_paths['radar'] = chart_radar()
chart_paths['financial'] = chart_financial()
chart_paths['peers'] = chart_peers()
chart_paths['fibonacci'] = chart_fibonacci()
chart_paths['key_levels'] = chart_key_levels()
chart_paths['heatmap'] = chart_heatmap()
chart_paths['dupont'] = chart_dupont()
chart_paths['fund_emotion'] = chart_fund_emotion()
print(f"图表生成完成: {len(chart_paths)}张")

# ═══════════════════════════════════════════════════════════
# Word报告生成
# ═══════════════════════════════════════════════════════════
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

doc = Document()

# ── 页面设置 ──
section = doc.sections[0]
section.page_width = Cm(21); section.page_height = Cm(29.7)
section.top_margin = Cm(2.5); section.bottom_margin = Cm(2.5)
section.left_margin = Cm(2.5); section.right_margin = Cm(2.5)
section.orientation = WD_ORIENT.PORTRAIT

# ── 辅助函数 ──
def set_cell_shading(cell, color_hex):
    shading = OxmlElement('w:shd')
    shading.set(qn('w:fill'), color_hex)
    shading.set(qn('w:val'), 'clear')
    cell._tc.get_or_add_tcPr().append(shading)

def add_styled_table(doc, headers, rows, col_widths=None):
    table = doc.add_table(rows=len(rows)+1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for j, h in enumerate(headers):
        cell = table.rows[0].cells[j]
        cell.text = h
        for paragraph in cell.paragraphs:
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in paragraph.runs:
                run.bold = True; run.font.size = Pt(9)
                run.font.color.rgb = RGBColor(255,255,255); run.font.name = '微软雅黑'
        set_cell_shading(cell, '1565C0')
    for i, row_data in enumerate(rows):
        for j, val in enumerate(row_data):
            cell = table.rows[i+1].cells[j]
            cell.text = str(val)
            for paragraph in cell.paragraphs:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in paragraph.runs:
                    run.font.size = Pt(9); run.font.name = '微软雅黑'
    if col_widths:
        for i, w in enumerate(col_widths):
            for row in table.rows:
                row.cells[i].width = Cm(w)
    return table

def add_heading_text(doc, level, text):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.name = '微软雅黑'; run.font.color.rgb = RGBColor(21,101,192)
    return h

def add_para(doc, text, size=10.5, bold=False, color=None, align=None):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.font.size = Pt(size); run.font.name = '微软雅黑'; run.bold = bold
    if color:
        if isinstance(color, tuple) and any(isinstance(v, float) for v in color):
            color = tuple(int(v*255) if isinstance(v, float) and v <= 1 else int(v) for v in color)
        run.font.color.rgb = RGBColor(*color)
    if align:
        p.alignment = align
    return p

def add_page_break(doc):
    doc.add_page_break()

# ═══════════════════════════════════════════════════════════
# 封面页
# ═══════════════════════════════════════════════════════════
add_para(doc, '', size=14)
add_para(doc, '鉴股八步法 · 深度研究报告', size=22, bold=True, color=(21,101,192), align=WD_ALIGN_PARAGRAPH.CENTER)
add_para(doc, '', size=8)
add_para(doc, f'{STOCK_NAME}({STOCK_CODE})', size=28, bold=True, color=(46,125,50), align=WD_ALIGN_PARAGRAPH.CENTER)
add_para(doc, '', size=8)
add_para(doc, f'分析日期: {ANALYSIS_DATE}', size=14, align=WD_ALIGN_PARAGRAPH.CENTER)
add_para(doc, f'收盘价: {CURRENT_PRICE:.2f}元 | 总市值: {TOTAL_MCAP:.0f}亿元', size=14, align=WD_ALIGN_PARAGRAPH.CENTER)
add_para(doc, f'PE(TTM): {PE_TTM:.1f}x | PB: {PB:.2f}x | PS: {PS_TTM:.2f}x', size=14, align=WD_ALIGN_PARAGRAPH.CENTER)
add_para(doc, '', size=8)
add_para(doc, '数据来源: 东方财富 > 同花顺 > 新浪财经 > 公开研报', size=11, color=(0.4,0.4,0.4), align=WD_ALIGN_PARAGRAPH.CENTER)
add_para(doc, '', size=8)
add_para(doc, '⚠️ 本报告仅供参考，不构成个人投资建议。投资有风险，入市需谨慎。', size=12, bold=True, color=(198,40,40), align=WD_ALIGN_PARAGRAPH.CENTER)
add_page_break(doc)

# ═══════════════════════════════════════════════════════════
# 第一章~第十二章: Agent 需根据八步法分析结果填写各章内容
# 以下为各章框架结构,Agent 用 add_para/add_styled_table/add_heading_text
# 填写分析内容。参考 references/report-spec.md 的12章结构。
# ═══════════════════════════════════════════════════════════

# 第一章: 核心数据速览
add_heading_text(doc, 1, '第一章：核心数据速览')
add_para(doc, '1.1 收盘行情数据', size=12, bold=True)
headers = ['指标', '数值', '说明']
rows = [
    ['收盘价', f'{CURRENT_PRICE:.2f}元', f'{ANALYSIS_DATE}收盘'],
    ['总市值', f'{TOTAL_MCAP:.0f}亿元', 'A股'],
    ['PE(TTM)', f'{PE_TTM:.1f}x', f'近5年{PE_CURRENT_PCT}%分位'],
    ['PB', f'{PB:.2f}x', f'近5年{PB_CURRENT_PCT}%分位'],
    ['PS(TTM)', f'{PS_TTM:.2f}x', ''],
    ['股息率', f'{DIV_YIELD:.2f}%', ''],
    ['EV/EBITDA', f'{EV_EBITDA:.1f}x', ''],
]
add_styled_table(doc, headers, rows, col_widths=[4, 4, 6])
doc.add_picture(chart_paths['kline'], width=Inches(5.5))
add_page_break(doc)

# 第二章: 行业景气度分析
add_heading_text(doc, 1, '第二章：行业景气度分析')
add_para(doc, '2.1 行业周期定位', size=12, bold=True)
add_para(doc, f'当前{INDUSTRY_NAME}行业处于【{INDUSTRY_CYCLE_TEXT}】阶段,景气度【{INDUSTRY_CYCLE_DIR}】,适用【{VALUATION_METHOD}】估值逻辑。', size=11, bold=True, color=(46,125,50))
# Agent 需补充供需格局、政策环境、景气度评分表等详细内容
add_para(doc, '[Agent 补充: 供需格局分析、政策环境分析、景气度评分表]', size=10.5, color=C_GRAY)
doc.add_picture(chart_paths['radar'], width=Inches(4.5))
add_page_break(doc)

# 第三章: 公司行业地位与护城河
add_heading_text(doc, 1, '第三章：公司行业地位与护城河分析')
add_para(doc, f'结论: {STOCK_NAME}在{INDUSTRY_NAME}行业中处于【{MOAT_POSITION}】地位,核心护城河为【{MOAT_TYPE}】,竞争力综合评分{COMP_TOTAL:.1f}/10。', size=11, bold=True, color=(46,125,50))
add_para(doc, '[Agent 补充: 主营业务表、护城河评分表、产业链分析、竞争力评级表]', size=10.5, color=C_GRAY)
add_page_break(doc)

# 第四章: 财务三表与杜邦分解
add_heading_text(doc, 1, '第四章：财务三表与杜邦分解')
add_para(doc, '4.1 财务核心指标', size=12, bold=True)
# 生成财务指标表
headers = ['指标'] + [str(y) for y in FINANCIAL_YEARS]
rows = [
    ['营收(亿元)'] + [f'{v:.1f}' for v in FIN_REVENUE],
    ['归母净利(亿)'] + [f'{v:.1f}' for v in FIN_NETPROFIT],
    ['扣非净利(亿)'] + [f'{v:.1f}' for v in FIN_ADJ_NETPROFIT],
    ['毛利率%'] + [f'{v:.2f}' for v in FIN_GROSSMARGIN],
    ['净利率%'] + [f'{v:.2f}' for v in FIN_NETMARGIN],
    ['ROE%(加权)'] + [f'{v:.2f}' for v in FIN_ROE],
    ['扣非ROE%'] + [f'{v:.1f}' for v in FIN_ROE_ADJ],
    ['资产负债率%'] + [f'{v:.2f}' for v in FIN_DEBT_RATIO],
    ['经营现金流(亿)'] + [f'{v:.1f}' for v in FIN_OCF],
    ['自由现金流(亿)'] + [f'{v:.1f}' for v in FIN_FCF],
]
add_styled_table(doc, headers, rows, col_widths=[3]+[1.8]*len(FINANCIAL_YEARS))
doc.add_picture(chart_paths['dupont'], width=Inches(5.5))
add_para(doc, '[Agent 补充: 杜邦分解分析文字、现金流质量检验表]', size=10.5, color=C_GRAY)
add_page_break(doc)

# 第五章: 估值对比分析
add_heading_text(doc, 1, '第五章：估值对比分析')
add_para(doc, '5.1 估值指标矩阵', size=12, bold=True)
headers = ['指标', STOCK_NAME, '行业中位数', '行业均值', '溢折价率', '5年分位数']
rows = [
    ['PE(TTM)', f'{PE_TTM:.1f}x', '—', '—', '—', f'{PE_CURRENT_PCT}%分位'],
    ['PB', f'{PB:.2f}x', '—', '—', '—', f'{PB_CURRENT_PCT}%分位'],
    ['PS(TTM)', f'{PS_TTM:.2f}x', '—', '—', '—', '—'],
    ['EV/EBITDA', f'{EV_EBITDA:.1f}x', '—', '—', '—', '—'],
    ['股息率', f'{DIV_YIELD:.2f}%', '—', '—', '—', '—'],
]
add_styled_table(doc, headers, rows, col_widths=[2.5,2,2,2,2,2.5])
doc.add_picture(chart_paths['peers'], width=Inches(5.5))
add_para(doc, '[Agent 补充: 同业对比详细分析、基本面综合评级表]', size=10.5, color=C_GRAY)
add_page_break(doc)

# 第六章: 大周期技术分析
add_heading_text(doc, 1, '第六章：大周期技术分析(年线/季线/月线)')
add_para(doc, '[Agent 补充: 年线/季线/月线分析文字、大周期趋势定调表]', size=10.5, color=C_GRAY)
add_page_break(doc)

# 第七章: 中周期技术形态分析
add_heading_text(doc, 1, '第七章：中周期技术形态分析(周线)')
add_para(doc, '[Agent 补充: 周线形态识别、技术指标表、支撑压力位、中期形态结论]', size=10.5, color=C_GRAY)
add_page_break(doc)

# 第八章: 小周期技术分析
add_heading_text(doc, 1, '第八章：小周期技术分析(日线+资金面+情绪面+分时)')
doc.add_picture(chart_paths['fund_emotion'], width=Inches(5.5))
add_para(doc, '[Agent 补充: 日线形态/量价/指标、资金面分析、情绪面分析、分时分析、关键价位]', size=10.5, color=C_GRAY)
add_page_break(doc)

# 第九章: 斐波那契与波浪分析
add_heading_text(doc, 1, '第九章：斐波那契与波浪分析')
if FIB_LEVELS:
    add_para(doc, '9.1 斐波那契回撤位计算表', size=12, bold=True)
    headers = ['回撤比例', '回撤位(元)', '意义']
    rows = [[k, f'{v:.2f}', '多空分水岭' if k=='50.0%' else '极限回撤' if k=='61.8%' else ''] for k,v in FIB_LEVELS.items()]
    rows.append(['当前回撤幅度', f'{CURRENT_RETRACT_PCT:.1f}%', ''])
    add_styled_table(doc, headers, rows, col_widths=[3, 3, 4])
doc.add_picture(chart_paths['fibonacci'], width=Inches(5.5))
add_para(doc, '[Agent 补充: 波浪结构分析、回撤到位判断]', size=10.5, color=C_GRAY)
add_page_break(doc)

# 第十章: 综合研判
add_heading_text(doc, 1, '第十章：综合研判')
add_para(doc, '10.1 多周期综合评分', size=12, bold=True)
headers = ['周期', '评分(/100)', '状态描述']
rows = [[p, str(TECH_SCORES[p]["score"]), TECH_SCORES[p]["status"]] for p in TECH_SCORES]
add_styled_table(doc, headers, rows, col_widths=[3, 2, 7])
add_para(doc, '[Agent 补充: 多空辩论、止跌/突破确认条件]', size=10.5, color=C_GRAY)
add_page_break(doc)

# 第十一章: 操作建议
add_heading_text(doc, 1, '第十一章：操作建议')
add_para(doc, '[Agent 补充: 分场景操作策略(持仓者-反弹遇阻/破位下行、空仓者-观望、激进者-试错、稳健者-确认后)、目标价与止损位]', size=10.5, color=C_GRAY)
add_page_break(doc)

# 第十二章: 结论
add_heading_text(doc, 1, '第十二章：结论')
add_para(doc, '[Agent 补充: 6个核心问题回答、风险提示]', size=10.5, color=C_GRAY)
add_para(doc, '', size=6)
add_para(doc, '⚠️ 本报告仅供参考，不构成个人投资建议。投资有风险，入市需谨慎。', size=12, bold=True, color=(198,40,40), align=WD_ALIGN_PARAGRAPH.CENTER)
add_para(doc, f'报告日期: {ANALYSIS_DATE} | 分析师: 研股股(AI) | 数据来源: 东方财富/同花顺/新浪财经/公开研报', size=10, color=C_GRAY, align=WD_ALIGN_PARAGRAPH.CENTER)

# ── 保存 ──
output_path = os.path.join(OUT_DIR, f'{STOCK_NAME}_鉴股八步法研究报告_{ANALYSIS_DATE}.docx')
doc.save(output_path)
print(f"\n✅ Word报告生成完成: {output_path}")
print(f"   图表目录: {CHART_DIR}")
