#!/usr/bin/env python3
"""保存知识卡片到对应目录，更新 processed 数据中的 output_status。

用法:
    python3 finalize_digest.py \
        --queue QUEUE_JSON \

        --cards-dir knowledge_cards/ \
        --data processed_kb_items_latest.json \
        --update-status \
        --mode {quick|deep}

注意：此脚本在 Phase 2（AI 逐条生成卡片）之后执行。
它扫描 cards-dir 中已生成的文件，与 queue 中的条目匹配，
然后更新 processed 数据中的 output_status。
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log


import json
import os
import sys
from datetime import datetime


def main():
    args = sys.argv[1:]
    queue_path = args[args.index("--queue") + 1]
    cards_dir = args[args.index("--cards-dir") + 1]
    data_path = args[args.index("--data") + 1]
    update = "--update-status" in args
    mode = args[args.index("--mode") + 1] if "--mode" in args else "quick"

    with open(queue_path, "r", encoding="utf-8") as f:
        queue = json.load(f)

    # 确保卡片目录存在
    os.makedirs(cards_dir, exist_ok=True)

    # 扫描已生成的卡片文件
    existing_cards = set()
    if os.path.exists(cards_dir):
        for fn in os.listdir(cards_dir):
            if fn.endswith(".md"):
                existing_cards.add(fn)

    # 匹配队列与卡片（按 idx 前缀匹配，避免中文截断导致的不匹配）
    digested = []
    pending = []
    for item in queue["items"]:
        prefix = f"digest_{item['idx']:03d}_"
        matched = [fn for fn in existing_cards if fn.startswith(prefix)]
        if matched:
            digested.append((item, matched[0]))
        else:
            pending.append(item)

    # 更新 processed 数据
    if update and digested:
        with open(data_path, "r", encoding="utf-8") as f:
            processed = json.load(f)

        new_status = "已提炼"
        updated = 0
        digested_titles = {d[0]["title"].strip() for d in digested}
        for item in processed:
            if item.get("output_status") == "已归档":
                continue
            if item["title"].strip() in digested_titles:
                old_status = item.get("output_status", item.get("status", ""))
                if old_status != new_status:
                    item["output_status"] = new_status
                    updated += 1

        with open(data_path, "w", encoding="utf-8") as f:
            json.dump(processed, f, ensure_ascii=False, indent=2)

        log.success(f"✅ 已更新 {updated} 条 → output_status: {new_status}")
    elif update:
        log.warning("⚠️ 未找到需要更新的条目（卡片尚未生成？）")

    # 输出摘要
    today = datetime.now().strftime("%Y-%m-%d")
    log.info(f"\n📊 消化批次摘要 [{today}]")
    log.info(f"   模式: {mode}")
    log.info(f"   已消化: {len(digested)} 条")
    log.info(f"   待处理: {len(pending)} 条")
    if pending:
        log.info(f"   未生成卡片的条目:")
        for p in pending:
            log.info(f"     - {p['title'][:60]}")

    # 生成批次摘要文件
    summary_path = os.path.join(cards_dir, "_batch_summary.md")
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"# 消化批次摘要 — {today}\n\n")
        f.write(f"- 模式：{mode}\n")
        f.write(f"- 已消化：{len(digested)} 条\n")
        f.write(f"- 卡��目录：{cards_dir}\n\n")
        f.write("## 已消化条目\n\n")
        for d, fn in digested:
            f.write(f"- [{d['kb_name']}] {d['title']} → `{fn}`\n")
        if pending:
            f.write("\n## 待处理（卡片未生成）\n\n")
            for p in pending:
                f.write(f"- [{p['kb_name']}] {p['title']}\n")

    log.info(f"\n📁 摘要文件: {summary_path}")


if __name__ == "__main__":
    main()
