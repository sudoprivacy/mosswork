#!/usr/bin/env python3
"""digest_item.py — 单条/批量资料自动化消化脚本

两阶段工作模式:
    --plan    : 读取队列 JSON，输出结构化 fetch 计划（告诉 AI 取什么）
    --build   : 接收队列条目 + 已获取的内容，按模板生成知识卡片


用法:
    # Phase A: 生成 fetch 计划
    python3 digest_item.py --plan --queue digest_queue.json [--cards-dir DIR]

    # Phase B: 生成卡片（内容通过 stdin 或 --content-file 传入）
    python3 digest_item.py --build \
        --item '{"idx":1,"title":"...",...}' \
        --depth quick|deep \
        --content-file /tmp/content.txt \
        --cards-dir knowledge_cards
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log


import json
import os
import re
import sys
from datetime import datetime


# ── 工具: 生成文件名 slug ──

def make_slug(title, max_len=60):
    """从标题生成文件安全名。"""
    # 去除非中英文数字的符号
    slug = re.sub(r'[^\w\u4e00-\u9fff]', '_', title)
    # 压缩连续下划线
    slug = re.sub(r'_+', '_', slug)
    # 截断
    if len(slug) > max_len:
        slug = slug[:max_len]
    return slug.strip('_')


# ── 卡片模板 ──

QUICK_TEMPLATE = """# 📝 {title}

**标签**：{primary_tag} / {secondary_tag} / {tertiary_tag}
**来源**：{kb_name} | {media_type} | [📄 在ima中查看]({source_link})
**深度**：速览

## 一句话总结
{one_liner}

## 核心观点
{core_points}

## 适合人群
{target_audience}

## 可转化方向
{convertible}

## 关键词
{keywords}
"""

DEEP_TEMPLATE = """# 📖 {title}

**标签**：{primary_tag} / {secondary_tag} / {tertiary_tag}
**来源**：{kb_name} | {media_type} | {source_link}
**消化日期**：{date}
**深度**：精读

---

## 一句话总结
{one_liner}

---

## 核心方法论
{methodology}

---

## 操作指南

| # | 步骤 | 详细说明 | 关键参数/工具 | 注意点 |
|---|------|---------|-------------|-------|
{steps_table}

---

## 工具与参数

| 工具/模型 | 用途 | 关键配置 |
|----------|------|---------|
{tools_table}

---

## 关键数据 / 案例
{cases}

---

## 我的理解与可应用场景
{understanding}

### 可迁移到我的场景
{scenarios}

---

## 可转化成果
{outputs}

---

## 关联资料（知识库内）
{related}

---

## 关键词
{keywords}
"""


# ── Phase A: 生成 fetch 计划 ──

def plan_fetches(queue_path, cards_dir):
    """读取消化队列，输出每条资料的 fetch 指令。"""
    with open(queue_path, "r", encoding="utf-8") as f:
        queue = json.load(f)

    items = queue.get("items", [])
    plan = {
        "mode": queue.get("mode", "new"),
        "label": queue.get("label", ""),
        "total_items": len(items),
        "cards_dir": cards_dir,
        "items": []
    }

    for item in items:
        idx = item["idx"]
        title = item["title"]
        media_id = item.get("media_id", "")
        media_type = item.get("media_type", "")
        url = item.get("url", "")
        kb_name = item.get("kb_name", "")
        theme = item.get("theme", "")

        slug = make_slug(title)
        card_path = os.path.join(cards_dir, f"digest_{idx:03d}_{slug}.md")

        # 确定 fetch 方式
        if url:
            fetch_type = "url"
            fetch_id = url
        elif media_id:
            # 根据 media_type 判断是否可导出
            if media_type in ("笔记", "markdown", "Markdown", "QA对话", "对话"):
                fetch_type = "note_id" if media_type == "笔记" else "media_id"
            else:
                fetch_type = "media_id"
            fetch_id = media_id
        else:
            fetch_type = None
            fetch_id = None

        plan["items"].append({
            "idx": idx,
            "title": title,
            "kb_name": kb_name,
            "theme": theme,
            "media_type": media_type,
            "fetch_type": fetch_type,
            "fetch_id": fetch_id,
            "card_path": card_path,
            "fetch_prompt": (
                f"提取以下内容的核心观点(3条)、方法论、操作步骤、工具参数、案例、适用人群、"
                f"可转化为的成果类型，以及{3}到{5}个关键词。"
            ),
        })

    return plan


def print_plan(plan):
    """以人类可读 + 机器可读格式输出 fetch 计划。"""
    log.info(f"\n{'='*60}")
    log.info(f"📋 消化计划: {plan['label']} | {plan['total_items']} 条")
    log.info(f"{'='*60}\n")

    for item in plan["items"]:
        log.info(f"\n{'─'*40}")
        log.info(f"  [{item['idx']}/{plan['total_items']}] {item['title'][:80]}")
        log.info(f"  知识库: {item['kb_name']} | 类型: {item['media_type']}")
        if item["fetch_type"]:
            log.info(f"  🔍 fetch(type=\"{item['fetch_type']}\", id=\"{item['fetch_id']}\", "
                  f"question=\"{item['fetch_prompt']}\")")
        else:
            log.warning(f"  ⚠️ 无可用的 fetch 标识（缺 media_id 和 url）")
        log.info(f"  📝 卡片路径: {item['card_path']}")
        log.info(f"{'─'*40}")

    # 同时输出 JSON 版本到 stdout（供脚本消费）
    log.info("\n\n--- JSON PLAN ---")
    print(json.dumps(plan, ensure_ascii=False, indent=2))


# ── Phase B: 生成卡片 ──

def assess_tags(item, theme=""):
    """基于 title 和 theme 自动推断三级标签。"""
    title = item.get("title", "")
    media_type = item.get("media_type", "")

    # 一级标签: 从 theme 映射
    THEME_TO_PRIMARY = {
        "AI工具与自动化": "AI工具",
        "AI视频与自媒体运营": "视频自媒体",
        "AI提示词工程": "AI提示词",
        "AI视觉与图像创作": "AI图像",
        "市场拓展与变现": "商业变现",
        "个人学习方法": "个人提升",
        "写作表达与公文材料": "写作公文",
    }
    primary = THEME_TO_PRIMARY.get(theme, "AI工具")

    # 二级标签: 从标题提取工具名
    TOOLS = [
        "Codex", "Seedance", "GPT-Image", "Gemini", "DeepSeek", "NotebookLM",
        "Claude", "OpenClaw", "MCP", "Sora", "Midjourney", "ComfyUI",
        "Stable Diffusion", "Flux", "即梦", "可灵", "剪映", "CapCut",
        "Obsidian", "PPT", "YouTube", "Nano Banana", "Trae",
    ]
    secondary = "通用"
    for tool in TOOLS:
        if tool.lower() in title.lower():
            secondary = tool
            break

    # 三级标签: 从标题提取资料性质
    NATURE_KEYWORDS = {
        "教程": ["教程", "入门", "保姆级", "手把手", "实操"],
        "指南": ["指南", "手册", "全攻略", "全流程", "从零"],
        "模板": ["模板", "Template", "格式", "框架"],
        "SOP": ["SOP", "工作流", "workflow", "流程"],
        "提示词": ["提示词", "Prompt", "prompt"],
        "案例": ["案例", "实测", "实战", "演示"],
        "评测": ["评测", "对比", "vs", "选哪个"],
        "工具推荐": ["推荐", "开源", "插件", "工具"],
    }
    tertiary = "参考"
    for nature, keywords in NATURE_KEYWORDS.items():
        for kw in keywords:
            if kw in title:
                tertiary = nature
                break
        if tertiary != "参考":
            break

    return primary, secondary, tertiary


def build_card(item, content, depth, cards_dir):
    """生成知识卡片并写入文件。"""
    title = item.get("title", "未命名")
    kb_name = item.get("kb_name", "")
    media_type = item.get("media_type", "")
    theme = item.get("theme", "")
    idx = item.get("idx", 0)
    url = item.get("url", "")
    media_id = item.get("media_id", "")
    kb_id = item.get("kb_id", "")
    # 构造 ima 知识库直链
    if kb_id and media_id:
        source_link = f"https://ima.qq.com/wiki/?shareId={kb_id}&mediaId={media_id}&action=openDetailDrawer"
    elif url:
        source_link = url
    else:
        source_link = ""

    primary_tag, secondary_tag, tertiary_tag = assess_tags(item, theme)
    slug = make_slug(title)
    card_path = os.path.join(cards_dir, f"digest_{idx:03d}_{slug}.md")
    today = datetime.now().strftime("%Y-%m-%d")

    if depth == "deep":
        content_preview = content[:3000]
        card = DEEP_TEMPLATE.format(
            title=title,
            primary_tag=primary_tag,
            secondary_tag=secondary_tag,
            tertiary_tag=tertiary_tag,
            kb_name=kb_name,
            media_type=media_type,
            source_link=source_link,
            date=today,
            one_liner="[待填充: 基于内容分析生成一句话总结]",
            methodology="[待填充: 提取 3 条核心方法论，每条含名称和详细说明]",
            steps_table=(
                "| 1 | [待填充] | [待填充] | [待填充] | [待填充] |\n"
                "| 2 | [待填充] | [待填充] | [待填充] | [待填充] |"
            ),
            tools_table=(
                "| [待填充] | [待填充] | [待填充] |"
            ),
            cases="[待填充: 提取关键案例或数据]",
            understanding="[待填充: 结合用户场景分析]",
            scenarios="1. [待填充]\n2. [待填充]",
            outputs="- [待填充]\n- [待填充]",
            related="- [待填充]",
            keywords="[待填充: 3-5个关键词]",
        )
    else:
        card = QUICK_TEMPLATE.format(
            title=title,
            primary_tag=primary_tag,
            secondary_tag=secondary_tag,
            tertiary_tag=tertiary_tag,
            kb_name=kb_name,
            media_type=media_type,
            source_link=source_link,
            one_liner="[待填充: 基于内容分析生成一句话总结]",
            core_points="1. [待填充]\n2. [待填充]\n3. [待填充]",
            target_audience="[待填充: 谁需要看这个]",
            convertible="- [待填充]\n- [待填充]",
            keywords="[待填充: 3-5个关键词]",
        )

    os.makedirs(cards_dir, exist_ok=True)
    with open(card_path, "w", encoding="utf-8") as f:
        f.write(card)

    return card_path, primary_tag, secondary_tag, tertiary_tag


# ── 主入口 ──

def main():
    args = sys.argv[1:]

    if "--plan" in args:
        queue_path = args[args.index("--queue") + 1]
        cards_dir_idx = args.index("--cards-dir") if "--cards-dir" in args else -1
        cards_dir = args[cards_dir_idx + 1] if cards_dir_idx >= 0 else "./knowledge_cards"

        plan = plan_fetches(queue_path, cards_dir)
        print_plan(plan)
        return

    if "--build" in args:
        item_raw = args[args.index("--item") + 1]
        depth = args[args.index("--depth") + 1] if "--depth" in args else "quick"
        cards_dir_idx = args.index("--cards-dir") if "--cards-dir" in args else -1
        cards_dir = args[cards_dir_idx + 1] if cards_dir_idx >= 0 else "./knowledge_cards"

        item = json.loads(item_raw)

        # 读取内容: 优先 --content-file，其次 stdin（限时读取防阻塞）
        import select
        content = ""
        if "--content-file" in args:
            cf_path = args[args.index("--content-file") + 1]
            with open(cf_path, "r", encoding="utf-8") as f:
                content = f.read()
        else:
            # 尝试从 stdin 读取（非阻塞，超时 0.5s）
            try:
                if select.select([sys.stdin], [], [], 0.5)[0]:
                    content = sys.stdin.read()
            except Exception:
                pass
        if not content.strip():
            log.warning("⚠️ 未提供内容（--content-file 或 stdin），将生成占位符卡片")

        card_path, p, s, t = build_card(item, content, depth, cards_dir)
        print(json.dumps({
            "status": "ok",
            "card_path": card_path,
            "tags": f"{p}/{s}/{t}",
            "has_content": bool(content.strip()),
        }, ensure_ascii=False))
        return

    log.error("用法: digest_item.py --plan | --build")
    sys.exit(1)


if __name__ == "__main__":
    main()
