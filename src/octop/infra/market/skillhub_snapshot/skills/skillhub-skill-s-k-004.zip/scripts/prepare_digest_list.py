#!/usr/bin/env python3
"""筛选资料，输出待消化队列。

用法:
    python3 prepare_digest_list.py --input ITEMS_JSON --output QUEUE_JSON
        [--mode {new,theme,all}] [--theme KEYWORD] [--top N] [--grade {A,B,C}]


模式:
    new   - 仅处理 output_status=未处理 的资料（默认）
    theme - 按关键词过滤主题/标题中的资料
    all   - 处理全部 指定等级资料
等级:
    --grade A  (默认) 仅 A 类
    --grade B  仅 B 类
    --grade C  仅 C 类
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log


import json
import sys


def main():
    args = sys.argv[1:]
    input_path = args[args.index("--input") + 1]
    output_path = args[args.index("--output") + 1]
    mode = args[args.index("--mode") + 1] if "--mode" in args else "new"
    theme_kw = args[args.index("--theme") + 1] if "--theme" in args else None
    top_n = int(args[args.index("--top") + 1]) if "--top" in args else None
    grade_filter = args[args.index("--grade") + 1] if "--grade" in args else "A"

    with open(input_path, "r", encoding="utf-8") as f:
        items = json.load(f)

    # 筛选等级
    grade_items = [i for i in items if i.get("grade") == grade_filter]

    if mode == "new":
        # 仅未处理的
        candidates = [i for i in grade_items
                      if i.get("output_status", i.get("status", "")) == "未处理"]
        label = f"新增未处理（{grade_filter}类）"
    elif mode == "theme" and theme_kw:
        candidates = [i for i in grade_items
                      if theme_kw in i.get("theme", "")
                      or theme_kw in i.get("title", "")]
        label = f"主题「{theme_kw}」（{grade_filter}类）"
    else:
        candidates = grade_items
        label = f"全部{grade_filter}类"

    # 去重（按 title）
    seen = set()
    unique = []
    for item in candidates:
        t = item["title"].strip()
        if t not in seen:
            seen.add(t)
            unique.append(item)
    candidates = unique

    # 截取 top N
    if top_n and len(candidates) > top_n:
        candidates = candidates[:top_n]

    # 构建输出
    queue = []
    for idx, item in enumerate(candidates, 1):
        entry = {
            "idx": idx,
            "title": item["title"],
            "kb_name": item.get("kb_name", ""),
            "kb_id": item.get("kb_id", ""),
            "media_id": item.get("media_id", ""),
            "media_type": item.get("media_type", ""),
            "theme": item.get("theme", ""),
            "grade": item.get("grade", "A"),
            "output_status": item.get("output_status", item.get("status", "未处理")),
            "value_snippet": item.get("value", ""),
            "output_target": item.get("output", ""),
        }
        # 保留 url 字段（如果存在）
        if item.get("url"):
            entry["url"] = item["url"]
        queue.append(entry)

    result = {
        "mode": mode,
        "grade_filter": grade_filter,
        "label": label,
        "total_grade": len(grade_items),
        "queued": len(queue),
        "items": queue,
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    log.info(f"待消化队列: {label} | {len(queue)} 条 (共 {len(grade_items)} 条{grade_filter}类)")
    for item in queue:
        title_short = item["title"][:60]
        log.info(f"  [{item['idx']}] {title_short} → {item['media_type']} ({item['kb_name']})")


if __name__ == "__main__":
    main()
