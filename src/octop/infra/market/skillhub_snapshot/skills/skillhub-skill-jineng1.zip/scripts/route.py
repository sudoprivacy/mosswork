# -*- coding: utf-8 -*-
"""第 1 步：定级与动手许可。CLI 或供 pipeline 调用。"""
from __future__ import annotations

import argparse
import json
import sys

from _common import dump_json, load_rules, now_iso, read_text

MATRIX = {
    "M1": {"name": "带数字事实稿（合同/申请/简历/报价/政策文件/成绩单说明）", "guard": "最强", "interrupt": True,
           "annotation": "全量逐处 + 保留项 + 事实核对表", "view": "自用", "level": "light"},
    "M2": {"name": "对外发布内容（公众号/朋友圈/商品介绍/自我介绍/求职信）", "guard": "强", "interrupt": True,
           "annotation": "全量 + 合规网关", "view": "团队脱敏", "level": "light"},
    "M3": {"name": "工作与学习文档（汇报/总结/邮件/培训稿/课程作业）", "guard": "中", "interrupt": False,
           "annotation": "逐处 + 改动率", "view": "双视图", "level": "light"},
    "M4": {"name": "散文日记", "guard": "中", "interrupt": False,
           "annotation": "保留项 + 有主性", "view": "自用", "level": "light"},
    "M5": {"name": "长文文件", "guard": "最强", "interrupt": True,
           "annotation": "章级摘要 + 抽样 3 处", "view": "双视图", "level": "light"},
    "M6": {"name": "日常短稿", "guard": "轻", "interrupt": False,
           "annotation": "规则卡 + 最小批注", "view": "自用", "level": "light"},
}

VALID = tuple(MATRIX)


def decide(material_type=None, chars=0, fmt="md", rules=None, text="", level=None):
    """未声明默认 M1；长文强制 M5；十类整齐文体只给诊断。"""
    rules = rules or load_rules()[0]
    th = rules["thresholds"]
    fallback = False
    t = (material_type or "M1").strip().upper()
    if t not in VALID:
        t, fallback = "M1", True
    forced_long = chars >= th["long_doc_chars"] and t != "M5"
    if forced_long:
        t = "M5"
    genre_hit = next((g for g in rules["no_edit_genres"] if g in text[:200]), None)
    redline = any(m in text for m in rules["redline_markers"])
    card = {
        "step": "route",
        "ts": now_iso(),
        "type": t,
        "type_name": MATRIX[t]["name"],
        "chars": chars,
        "format": fmt,
        "guard_level": MATRIX[t]["guard"],
        "interrupt_required": MATRIX[t]["interrupt"],
        "annotation_mode": MATRIX[t]["annotation"],
        "view": MATRIX[t]["view"],
        "level": level or MATRIX[t]["level"],
        "edit_permission": genre_hit is None,
        "genre_readonly_hit": genre_hit,
        "redline": redline,
        "team_forced": redline or MATRIX[t]["view"] == "团队脱敏",
        "long_doc": t == "M5" or chars >= th["long_doc_chars"],
        "default_applied": material_type is None or fallback,
        "forced_long": forced_long,
        "fallback": fallback,
        "note": "类型未声明或无法判定时按最严 M1；红线硬闸门全类型一致",
    }
    return card


def main():
    ap = argparse.ArgumentParser(description="去AI味把关台 · 第1步定级")
    ap.add_argument("--type", dest="material_type", default=None)
    ap.add_argument("--input", default=None, help="给了就算字数并扫红线/文体")
    ap.add_argument("--chars", type=int, default=0)
    ap.add_argument("--format", default="md")
    ap.add_argument("--level", default=None, choices=["light", "rewrite"])
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    rules = load_rules()[0]
    text = read_text(a.input) if a.input else ""
    card = decide(a.material_type, len(text) if a.input else a.chars,
                  a.format, rules, text, a.level)
    if a.out:
        dump_json(a.out, card)
    print(json.dumps(card, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
