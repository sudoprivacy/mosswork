# -*- coding: utf-8 -*-
"""第 4、6 步：事实守恒硬闸门、四项验收、程序化自检。"""
from __future__ import annotations

import argparse
import difflib
import json
import re
import sys
from pathlib import Path

from _common import (SKILL_ROOT, dump_json, fact_tokens, load_json, load_meta,
                     load_rules, read_text, sha256_text, now_iso)

# 拼接构造，避免自检脚本扫自身时命中
BANNED = ["ur" + "llib", "req" + "uests", "so" + "cket", "sub" + "process",
          "http" + "s?", "os." + "environ", "get" + "env"]
PATH_PATTERNS = [r"[A-Za-z]:[\\/]{1,2}Us" + "ers", r"[A-Za-z]:[\\/]{1,2}软件包",
                 "/c/Us" + "ers", "/d/软件" + "包"]


def change_ratio(original, final):
    sm = difflib.SequenceMatcher(None, original, final, autojunk=False)
    changed = sum(max(i2 - i1, j2 - j1)
                  for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag != "equal")
    return changed / max(1, len(original))


def authorial_score(text):
    """代理指标：不等同人工语感评分，只作返工触发线。"""
    s = 5
    if re.search(r"我|我们|本人", text):
        s += 2
    if re.search(r"[0-9]", text):
        s += 1
    if re.search(r"建议|认为|应当|需要|判断|复核", text):
        s += 1
    if len(text.splitlines()) >= 4:
        s += 1
    return min(10, s)


def check(original, final, annotations, route_card, rules, before, after, level="light"):
    th = rules["thresholds"]
    tokens_before = fact_tokens(original, rules["fact_token_patterns"])
    tokens_after = fact_tokens(final, rules["fact_token_patterns"])
    fact_diff = {
        "missing": dict((tokens_before - tokens_after)),
        "added": dict((tokens_after - tokens_before)),
    }
    fact_ok = not fact_diff["missing"] and not fact_diff["added"]
    if not fact_ok:
        for a in annotations:
            a["fact_ok"] = "fail"

    hard_hits = [w for w in rules["hard_words"] if w in original or w in final]
    rate = change_ratio(original, final)
    length_ratio = len(final) / max(1, len(original))
    deai = None if before == 0 else round(1 - after / before, 4)
    authorial = authorial_score(final)

    fail_reasons, rework_hints = [], []
    if not fact_ok:
        fail_reasons.append("F1 事实守恒：不可改 token 前后不一致")
    if hard_hits:
        fail_reasons.append("合规网关 HARD 命中：" + "、".join(hard_hits))
    if length_ratio < th["length_ratio_min"]:
        fail_reasons.append("篇幅低于 85% 回退线，疑似删过头")
    if level == "rewrite" and rate < th["change_rate_rewrite_min"]:
        fail_reasons.append("要求重写而改动率低于 15%")
    if level == "light" and rate > th["change_rate_light_max"]:
        fail_reasons.append("要求轻改而改动率高于 40%")

    if deai is not None and deai < th["deai_rate"][0]:
        rework_hints.append("去味率低于 70% 参考线；保守策略保留项偏多，回到第 5 步评估无损改写空间，本机不自动追加改动")
    if deai is not None and deai > th["deai_rate"][1]:
        rework_hints.append("去味率到顶格，反查是否把人味一起洗掉")
    if authorial < th["authorial_min"]:
        rework_hints.append("有主性低于 5，触发声音回填或标『本次仅做去痕』")

    return {
        "step": "guard",
        "ts": now_iso(),
        "verdict": "FAIL" if fail_reasons else "PASS",
        "fail_reasons": fail_reasons,
        "rework_hints": rework_hints,
        "four_checks": {
            "事实守恒": {"value": "全 pass" if fact_ok else "fail", "veto": True,
                     "detail": fact_diff},
            "改动率": {"value": round(rate, 4), "threshold": th["change_rate_light_max"] if level == "light" else th["change_rate_rewrite_min"]},
            "去味率": {"value": deai, "threshold": th["deai_rate"], "symptoms_before": before, "symptoms_after": after},
            "有主性": {"value": authorial, "threshold": th["authorial_min"], "proxy": True},
        },
        "length_ratio": round(length_ratio, 4),
        "hard_hits": hard_hits,
        "redline": route_card.get("redline", False),
        "level": level,
        "note": "有主性与症状密度为代理指标；结论只作返工触发线",
    }


def selfcheck():
    """D6 程序化自检：八项，任一不过退出码 1。"""
    results = []

    def add(name, ok, detail=""):
        results.append({"item": name, "ok": bool(ok), "detail": detail})

    skill = SKILL_ROOT / "SKILL.md"
    text = skill.read_text(encoding="utf-8")
    fm = text.split("---", 2)[1] if text.startswith("---") else ""
    fields = ["name", "description", "version", "agent_created", "display_name",
              "display_name_en", "description_zh", "description_en"]
    add("frontmatter 七字段+", all(re.search(rf"^{f}:", fm, re.M) for f in fields),
        "缺失：" + ",".join(f for f in fields if not re.search(rf"^{f}:", fm, re.M)))

    refs = set(re.findall(r"(?:references|scripts|state|examples)/[\w./-]+\.(?:md|py|json)", text))
    missing = sorted(p for p in refs if not (SKILL_ROOT / p).exists())
    add("引用完整性", not missing, "缺失：" + ",".join(missing) if missing else f"核对 {len(refs)} 条")

    meta = load_meta()
    m = re.search(r"^version:\s*(\S+)", fm, re.M)
    add("版本同步率 100%", bool(m and m.group(1) == meta["version"]),
        f"frontmatter={m.group(1) if m else '无'} / _meta={meta['version']}")

    try:
        rules, _, rp = load_rules()
        active_ver = re.search(r"rules-v([0-9.]+)\.md", str(rp))
        ok_rules = bool(active_ver and active_ver.group(1) == rules["version"])
        add("规则层 JSON 可解析且版本绑定", ok_rules,
            f"{rp.name} / json.version={rules['version']}")
    except Exception as e:
        add("规则层 JSON 可解析且版本绑定", False, str(e))

    path_hits, net_hits = [], []
    for p in sorted(SKILL_ROOT.rglob("*")):
        if p.is_dir() or p.suffix not in (".py", ".md", ".json"):
            continue
        body = p.read_text(encoding="utf-8", errors="replace")
        for pat in PATH_PATTERNS:
            if re.search(pat, body):
                path_hits.append(p.name)
        if p.suffix == ".py":
            for word in BANNED:
                if word in body:
                    net_hits.append(f"{p.name}:{word}")
    add("零硬编码本机绝对路径", not path_hits, ",".join(sorted(set(path_hits))))
    add("零网络/上传/环境变量/子进程关键字", not net_hits, ",".join(sorted(set(net_hits))))

    state = SKILL_ROOT / "state"
    add("state 目录存在且可写", state.is_dir() and all(
        (state / f).exists() for f in ("usage-log.md", "evolution-state.json", "ability-ledger.json")))

    # 外发脱敏校验（v0.1.1 新增三项）
    owner_pub = (meta.get("owner") or "").strip()
    add("外发元数据无个人/内部标识", (not owner_pub) or owner_pub in ("<使用者>", "团队共用", "匿名"),
        f"owner={owner_pub!r}")
    ledger_pub = load_json(state / "ability-ledger.json", {})
    sc_pub = ledger_pub.get("selfcheck", {})
    has_trace = bool(sc_pub.get("ts")) or bool(sc_pub.get("hashes"))
    add("state 无本机运行痕迹", not has_trace,
        "存在 ts/hashes 运行痕迹" if has_trace else "已重置为初始态")
    banned_ext = [r"_source[\\/]", r"AI味去除资料库", r"\.\.[\\/]", r"humaniz", r"qclaw", r"moways", r"shuorenhua"]
    bad_ext = []
    for p2 in sorted(SKILL_ROOT.rglob("*.md")):
        body2 = p2.read_text(encoding="utf-8", errors="replace")
        for bp2 in banned_ext:
            if re.search(bp2, body2):
                bad_ext.append(p2.name)
                break
    add("包内无包外私有资料库引用", not bad_ext, ",".join(sorted(set(bad_ext))))

    rp = SKILL_ROOT / meta["rules_active"]
    hashes = {"SKILL.md": sha256_text(text)[:16],
              "rules": sha256_text(rp.read_text(encoding="utf-8"))[:16] if rp.exists() else ""}
    ledger_path = state / "ability-ledger.json"
    ledger = load_json(ledger_path, {})
    ledger.setdefault("runs", [])
    ledger["selfcheck"] = {"ts": now_iso(), "hashes": hashes, "all_ok": all(r["ok"] for r in results)}
    dump_json(ledger_path, ledger)
    add("主文件与规则层哈希登记进账本", bool(ledger["selfcheck"]["hashes"]["SKILL.md"]))

    ok = all(r["ok"] for r in results)
    return {"step": "selfcheck", "verdict": "PASS" if ok else "FAIL",
            "items": results, "ts": now_iso()}


def main():
    ap = argparse.ArgumentParser(description="去AI味把关台 · 第4、6步把关")
    ap.add_argument("--original")
    ap.add_argument("--final")
    ap.add_argument("--annotations")
    ap.add_argument("--route-json")
    ap.add_argument("--symptoms-before", type=int, default=0)
    ap.add_argument("--symptoms-after", type=int, default=0)
    ap.add_argument("--level", default="light")
    ap.add_argument("--out")
    ap.add_argument("--selfcheck", action="store_true")
    a = ap.parse_args()
    if a.selfcheck:
        rep = selfcheck()
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return 0 if rep["verdict"] == "PASS" else 1
    if not (a.original and a.final and a.annotations):
        ap.error("需 --original --final --annotations，或使用 --selfcheck")
    rules = load_rules()[0]
    card = load_json(a.route_json, {}) if a.route_json else {}
    data = load_json(a.annotations, {})
    ann = data.get("annotations", data if isinstance(data, list) else [])
    rep = check(read_text(a.original), read_text(a.final), ann, card, rules,
                a.symptoms_before, a.symptoms_after, a.level)
    if a.out:
        dump_json(a.out, rep)
    print(json.dumps({"verdict": rep["verdict"], "four_checks": rep["four_checks"],
                      "rework_hints": rep["rework_hints"]}, ensure_ascii=False))
    return 0 if rep["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
