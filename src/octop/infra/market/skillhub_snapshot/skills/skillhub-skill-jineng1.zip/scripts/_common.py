# -*- coding: utf-8 -*-
"""共享工具。纯标准库；零网络、零上传、零环境变量读取、零子进程。"""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]


def now_iso():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def load_meta(root=None):
    root = Path(root or SKILL_ROOT)
    return json.loads((root / "_meta.json").read_text(encoding="utf-8"))


def save_meta(meta, root=None):
    root = Path(root or SKILL_ROOT)
    (root / "_meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def load_rules(root=None):
    """唯一机读规则源：_meta.json -> rules_active -> RULES_JSON 块。"""
    root = Path(root or SKILL_ROOT)
    meta = load_meta(root)
    rp = root / meta["rules_active"]
    text = rp.read_text(encoding="utf-8")
    body = text.split("<!-- RULES_JSON_BEGIN -->", 1)[1].split(
        "<!-- RULES_JSON_END -->", 1
    )[0]
    body = body.replace("```json", "").replace("```", "")
    return json.loads(body), meta, rp


def read_text(path):
    raw = Path(path).read_bytes()
    for enc in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    raise ValueError("无法识别文件编码，已停止，不猜测内容")


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def unique_path(outdir, filename):
    """绝不覆盖：同名自动加序号。"""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    p = outdir / filename
    if not p.exists():
        return p
    stem, suffix = Path(filename).stem, Path(filename).suffix
    i = 2
    while True:
        q = outdir / f"{stem}_{i}{suffix}"
        if not q.exists():
            return q
        i += 1


def fact_tokens(text, patterns):
    """抽取不可改 token：规则层定义的数字+单位/年份/编号，外加任意数字串兜底。
    归属与证据强度靠不改写整句策略。"""
    counter = Counter()
    for pattern in patterns:
        for match in re.findall(pattern, text):
            token = match if isinstance(match, str) else "".join(match)
            counter[token] += 1
    for num in re.findall(r"[0-9]+(?:[.][0-9]+)?[%％]?", text):
        counter["NUM:" + num] += 1
    return counter


def line_no(loc):
    m = re.search(r"L(\d+)", loc)
    return int(m.group(1)) if m else None


def dump_json(path, obj):
    Path(path).write_text(
        json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def load_json(path, default=None):
    p = Path(path)
    if not p.exists():
        return {} if default is None else default
    return json.loads(p.read_text(encoding="utf-8"))


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")
