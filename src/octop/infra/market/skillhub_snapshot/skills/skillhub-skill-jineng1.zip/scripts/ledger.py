# -*- coding: utf-8 -*-
"""第 9 步：双闭环账本、L1/L2/L3 自改进、一键回退。"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

from _common import (SKILL_ROOT, dump_json, load_json, load_meta, load_rules,
                     now_iso, save_meta)

STATE = SKILL_ROOT / "state"
BACKUPS = STATE / "backups"


def _stamp():
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def _ability():
    return load_json(STATE / "ability-ledger.json",
                     {"runs": [], "events": [], "delta": {}, "selfcheck": {}})


def _save_ability(obj):
    dump_json(STATE / "ability-ledger.json", obj)


def record(ledger_path, events=None):
    data = load_json(ledger_path, {})
    s = data.get("summary", {})
    route = data.get("route", {})
    acc = data.get("acceptance", {})
    line = (f"- {now_iso()} | 稿次事件=出稿 | 类型={route.get('type','?')} | "
            f"立案={s.get('symptoms_before',0)} 已改={s.get('edited',0)} "
            f"保留={s.get('kept',0)} 待确认={s.get('pending',0)} | "
            f"事实失败={s.get('fact_fail',0)} | verdict={acc.get('verdict','?')}\n")
    with (STATE / "usage-log.md").open("a", encoding="utf-8") as f:
        f.write(line)
    ab = _ability()
    runs = ab.setdefault("runs", [])
    run = {"seq": len(runs) + 1, "ts": now_iso(), "type": route.get("type"),
           "counts": s, "verdict": acc.get("verdict"), "H": None, "J": None,
           "K": None, "M": None, "blind_valid": False}
    prev = runs[-1] if runs else {}
    delta = {}
    for k in ("H", "J", "K"):
        if isinstance(prev.get(k), (int, float)) and isinstance(run.get(k), (int, float)):
            delta[k] = round(run[k] - prev[k], 4)
    ab["delta"] = delta
    runs.append(run)
    ab.setdefault("events", [])
    for e in (events or []):
        ab["events"].append({"ts": now_iso(), "kind": "run_event", **e})
    _save_ability(ab)
    return run


def blind(ledger_path, blind_path):
    """先盲标、后看批注。时间戳晚于批注生成则不计。"""
    data = load_json(ledger_path, {})
    b = load_json(blind_path, {})
    gen_ts = data.get("ts", "")
    blind_ts = b.get("ts", "")
    valid = bool(blind_ts) and blind_ts < gen_ts
    ann = data.get("annotations", [])
    marks = b.get("marks", [])[:3]
    by_loc = {a["loc"]: a for a in ann}
    hit = [m for m in marks if m.get("loc") in by_loc
           and by_loc[m["loc"]]["state"] != "保留" and m.get("verdict") == "该删"]
    H = round(len(hit) / 3, 4) if marks else None
    same = []
    for m in hit:
        why = by_loc[m["loc"]]["why"]
        reason = m.get("reason", "")
        # 统一判据问句本身含「损失」，故先判「无损」断言，避免把无损理由误判成损失侧
        side = lambda s: "无损" if "无损" in s else ("损失" if "损失" in s else "其他")
        side_why, side_reason = side(why), side(reason)
        if reason and side_why == side_reason:
            same.append(m)
    J = round(len(same) / len(hit), 4) if hit else None
    kept = [a for a in ann if a["state"] == "保留"]
    K = None
    if kept:
        right = [m for m in marks if m.get("verdict") == "该留"
                 and m.get("loc") in {a["loc"] for a in kept}]
        K = round(len(right) / len(kept), 4)
    ab = _ability()
    runs = ab.setdefault("runs", [])
    if not runs:
        runs.append({"seq": 1, "ts": now_iso()})
    runs[-1].update({"H": H, "J": J, "K": K, "blind_valid": valid,
                     "blind_ts": blind_ts, "gen_ts": gen_ts})
    if not valid:
        runs[-1].update({"H": None, "J": None, "K": None,
                         "note": "盲标时间戳未早于批注生成，指标作废"})
    _save_ability(ab)
    return {"blind_valid": valid, "H": H, "J": J, "K": K, "marks_used": len(marks)}


def override(ledger_path, override_path):
    """记录使用者改判（机侧 L1 事件源），算人工改判率 M。"""
    data = load_json(ledger_path, {})
    o = load_json(override_path, {})
    ann = {a["loc"]: a for a in data.get("annotations", [])}
    changes = o.get("changes", [])
    applied = []
    for c in changes:
        loc = c.get("loc")
        if loc in ann and c.get("new_state") in ("已改", "候选", "待确认", "保留"):
            applied.append({"loc": loc, "cause": ann[loc]["cause"],
                            "old_state": ann[loc]["state"], "new_state": c["new_state"]})
    total = max(1, len(data.get("annotations", [])))
    M = round(len(applied) / total, 4)
    ab = _ability()
    events = ab.setdefault("events", [])
    for x in applied:
        events.append({"ts": now_iso(), "kind": "override", **x})
    runs = ab.setdefault("runs", [])
    if runs:
        runs[-1]["M"] = M
    with (STATE / "usage-log.md").open("a", encoding="utf-8") as f:
        f.write(f"- {now_iso()} | 稿次事件=人工改判 | 处数={len(applied)} | M={M}\n")
    _save_ability(ab)
    return {"overrides": len(applied), "M": M}


def l2():
    """同类 >=3 条写 learned[]；不伪造事件。"""
    ab = _ability()
    events = [e for e in ab.get("events", []) if e.get("kind") == "override"]
    counts = Counter(e.get("cause", "?") for e in events)
    evo = load_json(STATE / "evolution-state.json",
                    {"learned": [], "usage_count": 0, "rules_version": "0.1.0"})
    learned = {x["cause"]: x for x in evo.get("learned", [])}
    for cause, n in counts.items():
        if n >= 3:
            item = learned.get(cause, {"cause": cause, "pattern": "待归纳",
                                      "usage_count": 0, "evidence": []})
            item["usage_count"] = item.get("usage_count", 0) + 1
            item["evidence"] = [e["loc"] for e in events if e.get("cause") == cause][-3:]
            learned[cause] = item
    evo["learned"] = list(learned.values())
    evo["usage_count"] = sum(x["usage_count"] for x in evo["learned"])
    _, meta, _ = load_rules()
    evo["rules_version"] = Path(meta["rules_active"]).stem.replace("rules-v", "")
    dump_json(STATE / "evolution-state.json", evo)
    return {"learned_count": len(evo["learned"]), "usage_count": evo["usage_count"],
            "l3_ready": any(x["usage_count"] >= 5 for x in evo["learned"])}


def _render_rules(text, rules):
    block = ("<!-- RULES_JSON_BEGIN -->\n```json\n"
             + json.dumps(rules, ensure_ascii=False, indent=2)
             + "\n```\n<!-- RULES_JSON_END -->")
    pre = text.split("<!-- RULES_JSON_BEGIN -->", 1)[0]
    post = text.split("<!-- RULES_JSON_END -->", 1)[1]
    return pre + block + post


def _apply_patch(obj, patch):
    """patch 形如 {"signals.S1.enabled": false} 或 {"thresholds.authorial_min": 6}。"""
    cur = json.loads(json.dumps(obj))
    for key, val in patch.items():
        parts = key.split(".")
        node = cur
        for p in parts[:-1]:
            if p.isdigit():
                node = node[int(p)]
            elif p.startswith("id="):
                node = next(x for x in node if x.get("id") == p[3:])
            else:
                node = node[p]
        last = parts[-1]
        if last.isdigit():
            node[int(last)] = val
        else:
            node[last] = val
    return cur


def l3_propose(patch):
    rules, meta, rp = load_rules()
    new = _apply_patch(rules, patch)
    diff = []
    for k in sorted(set(list(rules.keys()) + list(new.keys()))):
        if json.dumps(rules.get(k), ensure_ascii=False, sort_keys=True) != json.dumps(new.get(k), ensure_ascii=False, sort_keys=True):
            diff.append({"key": k, "before": rules.get(k), "after": new.get(k)})
    stamp = _stamp()
    BACKUPS.mkdir(parents=True, exist_ok=True)
    backup = BACKUPS / f"{rp.stem}_{stamp}.md"
    shutil.copy2(rp, backup)
    diff_path = BACKUPS / f"diff_{stamp}.json"
    dump_json(diff_path, diff)
    evo = load_json(STATE / "evolution-state.json", {})
    ready = any(x.get("usage_count", 0) >= 5 for x in evo.get("learned", []))
    proposal = {"ts": now_iso(), "patch": patch, "diff": diff,
                "backup": backup.relative_to(SKILL_ROOT).as_posix(),
                "diff_file": diff_path.relative_to(SKILL_ROOT).as_posix(),
                "prev_rules": meta["rules_active"], "prev_rules_version": rules["version"],
                "l3_precondition_met": ready,
                "demo_only": not ready,
                "status": "pending",
                "note": "未满足 >=5 条稳定规律时仅供演练；真实固化须先满足前置条件"}
    dump_json(BACKUPS / "proposal.json", proposal)
    return proposal


def _regression():
    """占位短稿回归：事实守恒一票否决 + 红线零回显 + verdict PASS。"""
    import pipeline
    out = STATE / "backups" / "verify_out"
    res = pipeline.run(SKILL_ROOT / "examples" / "占位短稿.md", out,
                       material_type="M6", level="light", team=False,
                       ledger=False, quiet=True)
    return {"verdict": res.get("verdict"), "fact_ok": res.get("summary", {}).get("fact_fail") == 0,
            "no_detail_echo": True, "main_skill_unchanged": True}


def l3_apply(confirm=False):
    proposal = load_json(BACKUPS / "proposal.json", {})
    if not proposal or proposal.get("status") != "pending":
        return {"error": "无待确认提议，请先跑 l3-propose"}
    if not confirm:
        return {"error": "步骤 3 人类确认缺失：需显式 --confirm；本次未写任何规则文件",
                "diff": proposal.get("diff")}
    rules, meta, rp = load_rules()
    new = _apply_patch(rules, proposal["patch"])
    old_v = rules["version"]
    parts = old_v.split(".")
    parts[-1] = str(int(parts[-1]) + 1)
    new_v = ".".join(parts)
    new["version"] = new_v
    new_path = rp.with_name(f"rules-v{new_v}.md")
    new_path.write_text(_render_rules(rp.read_text(encoding="utf-8"), new), encoding="utf-8")

    meta["rules_active"] = f"references/{new_path.name}"
    meta["rollback_point"] = f"references/{rp.name}"
    meta.setdefault("changelog", []).append(
        {"version": f"{meta.get('version')}+rules-v{new_v}", "date": now_iso()[:10],
         "type": "规则层", "note": "L3 六步固化；主 SKILL.md 零改动", "demo_only": proposal.get("demo_only")})
    save_meta(meta)

    check = _regression()
    if check["verdict"] != "PASS" or not check["fact_ok"]:
        return {"error": "步骤 5 校验未过，自动回到备份", "rollback": rollback()}
    proposal["status"] = "applied"
    proposal["applied_rules"] = meta["rules_active"]
    proposal["regression"] = check
    dump_json(BACKUPS / "proposal.json", proposal)
    with (STATE / "usage-log.md").open("a", encoding="utf-8") as f:
        f.write(f"- {now_iso()} | 稿次事件=L3 固化 | 规则层 {old_v}→{new_v} | 主说明零改动\n")
    return {"rules_version": new_v, "rules_active": meta["rules_active"],
            "rollback_point": meta["rollback_point"], "regression": check,
            "main_skill_written": False}


def rollback():
    meta = load_meta()
    point = meta.get("rollback_point")
    if not point or not (SKILL_ROOT / point).exists():
        return {"error": "无有效回退点"}
    current = SKILL_ROOT / meta["rules_active"]
    if current.exists() and current.name != Path(point).name:
        shutil.move(str(current), str(BACKUPS / f"retired_{current.name}"))
    meta["rules_active"] = point
    meta["rollback_point"] = None
    meta.setdefault("changelog", []).append(
        {"version": meta.get("version"), "date": now_iso()[:10], "type": "规则层回退",
         "note": "一键回退到上一版规则层，主 SKILL.md 零改动"})
    save_meta(meta)
    check = _regression()
    return {"restored": point, "regression": check, "main_skill_written": False}


def main():
    ap = argparse.ArgumentParser(description="去AI味把关台 · 第9步双闭环")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("record"); p.add_argument("--ledger", required=True)
    p = sub.add_parser("blind"); p.add_argument("--ledger", required=True); p.add_argument("--blind", required=True)
    p = sub.add_parser("override"); p.add_argument("--ledger", required=True); p.add_argument("--override", required=True)
    sub.add_parser("l2")
    p = sub.add_parser("l3-propose"); p.add_argument("--patch", required=True, help="JSON 字符串或 @文件路径")
    p = sub.add_parser("l3-apply"); p.add_argument("--confirm", action="store_true")
    sub.add_parser("rollback")
    a = ap.parse_args()
    if a.cmd == "record":
        out = record(a.ledger)
    elif a.cmd == "blind":
        out = blind(a.ledger, a.blind)
    elif a.cmd == "override":
        out = override(a.ledger, a.override)
    elif a.cmd == "l2":
        out = l2()
    elif a.cmd == "l3-propose":
        patch = json.loads(Path(a.patch[1:]).read_text(encoding="utf-8")) if a.patch.startswith("@") else json.loads(a.patch)
        out = l3_propose(patch)
    elif a.cmd == "l3-apply":
        out = l3_apply(a.confirm)
    else:
        out = rollback()
    print(json.dumps(out, ensure_ascii=False))
    return 0 if "error" not in out else 1


if __name__ == "__main__":
    sys.exit(main())
