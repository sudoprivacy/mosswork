# -*- coding: utf-8 -*-
"""统一入口：一次输入跑完定级 → 判据 → 守恒 → 改写 → 验收 → 四件交付 → 记账。"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import guard as guard_mod
import judge as judge_mod
import ledger as ledger_mod
import render as render_mod
import route as route_mod
from _common import load_rules, read_text, sha256_text


def run(input_path, outdir, material_type=None, level=None, team=False,
        blind=None, ledger=True, quiet=False):
    rules, meta, _ = load_rules()
    src = Path(input_path)
    original = read_text(src)
    original_hash = sha256_text(original)

    card = route_mod.decide(material_type, len(original), src.suffix or "md",
                            rules, original, level)
    annotations, before = judge_mod.scan(original, rules, card)
    if card["edit_permission"]:
        final = judge_mod.apply_edits(original, annotations)
    else:
        final = original
        for a in annotations:
            a["state"] = "候选"
            a["dst"] = "（不动，十类整齐文体只给诊断）"
    _, after = judge_mod.scan(final, rules, card)

    acceptance = guard_mod.check(original, final, annotations, card, rules,
                                 before, after, card["level"])
    if acceptance["verdict"] == "FAIL":
        result = {"verdict": "FAIL", "fail_reasons": acceptance["fail_reasons"],
                  "summary": {"symptoms_before": before, "fact_fail": sum(
                      1 for a in annotations if a["fact_ok"] == "fail")},
                  "diagnosis_only": True}
        if not quiet:
            print("verdict: FAIL")
            for r in result["fail_reasons"]:
                print("中止原因：" + r)
        return result

    res = render_mod.write_all(original, final, annotations, acceptance, card,
                               rules, outdir, src.name,
                               team or card["team_forced"], meta)
    if sha256_text(read_text(src)) != original_hash:
        raise RuntimeError("原文件哈希变化，已中止")

    if ledger:
        ledger_mod.record(res["ledger_path"])
    blind_result = ledger_mod.blind(res["ledger_path"], blind) if blind else None

    s = res["ledger"]["summary"]
    fc = acceptance["four_checks"]
    summary = {
        "洗前症状数": s["symptoms_before"],
        "改动处数": s["edited"],
        "保留项数": s["kept"],
        "待确认数": s["pending"],
        "fact_fail": s["fact_fail"],
        "改动率": fc["改动率"]["value"],
        "去味率": fc["去味率"]["value"],
        "verdict": acceptance["verdict"],
        "规则卡数": len(res["cards"]),
        "blinded": bool(blind_result and blind_result.get("blind_valid")),
    }
    if blind_result and blind_result.get("blind_valid"):
        summary.update({"H": blind_result["H"], "J": blind_result["J"], "K": blind_result["K"]})

    if not quiet:
        for k in ("clean", "annotated", "card", "acceptance"):
            print(res["paths"][k])
        print("汇总：" + " ".join(f"{k}={v}" for k, v in summary.items()))
    return {"verdict": acceptance["verdict"], "paths": res["paths"],
            "ledger_path": res["ledger_path"], "summary": summary,
            "rework_hints": acceptance["rework_hints"], "route": card}


def main():
    ap = argparse.ArgumentParser(description="去AI味把关台 · 统一入口")
    ap.add_argument("--input")
    ap.add_argument("--outdir")
    ap.add_argument("--type", dest="material_type", default=None)
    ap.add_argument("--level", default=None, choices=["light", "rewrite"])
    ap.add_argument("--team", action="store_true")
    ap.add_argument("--blind", default=None)
    ap.add_argument("--selfcheck", action="store_true")
    a = ap.parse_args()
    if a.selfcheck:
        rep = guard_mod.selfcheck()
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return 0 if rep["verdict"] == "PASS" else 1
    if not (a.input and a.outdir):
        ap.error("需 --input 与 --outdir（显式输出路径），或使用 --selfcheck")
    res = run(a.input, a.outdir, a.material_type, a.level, a.team, a.blind)
    return 0 if res.get("verdict") == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
