# -*- coding: utf-8 -*-
"""第 2–3、5 步：结构性症状立案、统一判据、无损改写。"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter

from _common import dump_json, line_no, load_json, load_rules, read_text

UNIFIED = "删掉它，信息或语气有损失吗？"


def _sentences(line):
    return [s.strip() for s in re.split(r"(?<=[。！？；])", line) if s.strip()]


def detect(sig, line, lines, ln, rules):
    kind = sig["kind"]
    if kind == "punct_run":
        return sum(line.count(p) for p in sig["puncts"]) >= sig["min_count"]
    if kind == "term_stack":
        return sum(line.count(t) for t in sig["terms"]) >= sig["min_count"]
    if kind == "pair_connector":
        has_lead = any(x in line for x in sig["lead"])
        has_partner = any(p in line for p in sig["partner"]) or "而非" in line
        return has_lead and has_partner
    if kind == "tail_upscale":
        is_tail = ln == len(lines) or not lines[ln].strip()
        return (is_tail and any(t in line for t in sig["terms"])
                and not re.search(r"[0-9]", line))
    if kind == "sentence_uniform":
        ss = _sentences(line)
        if len(ss) < sig["min_sentences"]:
            return False
        lens = [len(s) for s in ss]
        mean = sum(lens) / len(lens)
        std = (sum((x - mean) ** 2 for x in lens) / len(lens)) ** 0.5
        return std < sig["max_stdev"]
    if kind == "repeat_head":
        ss = _sentences(line)
        h = sig["head_chars"]
        return any(ss[i][:h] == ss[i + 1][:h] for i in range(len(ss) - 1))
    if kind == "term_density":
        return sum(line.count(t) for t in sig["terms"]) >= sig["min_count"]
    return False


def _tidy_punct(text):
    """删词后的标点整理：合并连续标点、去掉副词后孤立顿号、去句尾悬挂标点。"""
    text = re.sub(r"[、，；]{2,}", lambda m: m.group(0)[-1], text)
    text = re.sub(r"([也还均皆又])[、，；]", r"\1", text)
    text = re.sub(r"[、，；](?=[。！？]|$)", "", text)
    return text


def strip_hedge(line, terms, keep=1):
    """只删冗余限定词，保留首个；连其后的顿号一起删；不动数字、单位、年份、归属。"""
    pattern = re.compile("|".join(re.escape(t) for t in sorted(terms, key=len, reverse=True)))
    matches = list(pattern.finditer(line))
    if len(matches) < 2:
        return line
    spans = []
    for m in matches[keep:]:
        a, b = m.span()
        while b < len(line) and line[b] in "、，；":
            b += 1
        spans.append((a, b))
    out = line
    for a, b in reversed(spans):
        out = out[:a] + out[b:]
    return _tidy_punct(out)


def acceptable_rewrite(src, dst):
    """自动改写必须可被证明无损且读得通；否则降级为候选，交人工判断。"""
    if dst == src:
        return False
    if re.search(r"[、，；]{2,}", dst):
        return False
    if re.search(r"[也还均皆又][、，；]", dst):
        return False
    nums = lambda s: re.findall(r"[0-9]+(?:[.][0-9]+)?[%％]?", s)
    if nums(src) != nums(dst):
        return False
    return True


def scan(text, rules, route_card=None):
    """立案 → 唯一判据 → 8 字段批注。返回 (批注列表, 洗前症状数)。"""
    lines = text.splitlines()
    raw = []
    for ln, line in enumerate(lines, 1):
        if not line.strip():
            continue
        for sig in rules["signals"]:
            if sig.get("enabled", True) and detect(sig, line, lines, ln, rules):
                raw.append({"ln": ln, "sig": sig, "line": line})

    counts = Counter(x["sig"]["id"] for x in raw)
    tier2 = rules["density"]["tier2_short"]
    tier3 = rules["density"]["tier3_short"]
    keep = [x for x in raw if counts[x["sig"]["id"]] >= tier2 or len(raw) >= tier3]

    by_line = {}
    for x in keep:
        by_line.setdefault(x["ln"], []).append(x)

    annotations = []
    for ln in sorted(by_line):
        items = by_line[ln]
        sigs = [x["sig"] for x in items]
        line = items[0]["line"]
        editable = [s for s in sigs if s.get("editable")]
        pending = [s for s in sigs if s["action"] == "pending_sentence"]
        rule_ids = ",".join(s["id"] for s in sigs)
        cause = sigs[0]["cause"]

        if editable:
            candidate = strip_hedge(line, editable[0]["terms"], keep=1)
            if acceptable_rewrite(line, candidate):
                dst, state = candidate, "已改"
                why = "删掉冗余限定词，信息无损；保留一处限定以免语气全失。" + UNIFIED
            else:
                dst, state = "（不动）", "候选"
                why = "机检改写未通过标点整理与数字守恒检查，已降级为候选，交人工判断；" + UNIFIED
        elif pending:
            state, dst = "待确认", "（不动，等我点头）"
            why = "段尾安全升华，整句删除建议进待点头清单；本机不替使用者决定删除"
        elif any(s["kind"] in ("pair_connector", "repeat_head") for s in sigs):
            state, dst = "保留", "（不动）"
            why = "若删会损失对照信息或原句语境，按功能判据保留"
        else:
            state, dst = "候选", "（不动）"
            why = "机检只出候选；" + UNIFIED + "有损失则留"

        annotations.append({
            "loc": f"L{ln}",
            "src": line,
            "dst": dst,
            "rule": rule_ids,
            "cause": cause,
            "why": why,
            "state": state,
            "fact_ok": "pass",
        })
    # 症状数按「至少命中一个信号的位置」计数。密度门槛只决定要不要立案成批注，
    # 不参与症状计数；否则洗后残留会因总数低于门槛被清零，去味率虚高。
    symptom_positions = {x["ln"] for x in raw}
    return annotations, len(symptom_positions)


def apply_edits(text, annotations):
    """只落 state=已改 的无损改写；其余原样保留。"""
    lines = text.splitlines()
    for a in annotations:
        if a["state"] != "已改":
            continue
        n = line_no(a["loc"])
        if n and 1 <= n <= len(lines):
            lines[n - 1] = a["dst"]
    out = "\n".join(lines)
    if text.endswith("\n"):
        out += "\n"
    return out


def main():
    ap = argparse.ArgumentParser(description="去AI味把关台 · 第2-3、5步判据")
    ap.add_argument("--input", required=True)
    ap.add_argument("--route-json", default=None)
    ap.add_argument("--out", default=None, help="批注 json 输出路径")
    ap.add_argument("--text-out", default=None, help="改写后文本输出路径")
    a = ap.parse_args()
    rules = load_rules()[0]
    card = load_json(a.route_json, {}) if a.route_json else {}
    text = read_text(a.input)
    ann, before = scan(text, rules, card)
    final = apply_edits(text, ann) if card.get("edit_permission", True) else text
    if a.out:
        dump_json(a.out, {"annotations": ann, "symptoms_before": before})
    if a.text_out:
        from _common import write_text
        write_text(a.text_out, final)
    print(json.dumps({"symptoms_before": before, "annotations": len(ann),
                      "states": dict(Counter(x["state"] for x in ann))},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
