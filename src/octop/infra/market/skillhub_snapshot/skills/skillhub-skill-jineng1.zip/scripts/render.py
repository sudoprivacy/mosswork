# -*- coding: utf-8 -*-
"""第 7–8 步：四件人读产物 + 机读账本 + 双视图 + 长文降档。"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

from _common import (dump_json, line_no, now_iso, read_text, sha256_text,
                     unique_path, write_text)


def redact(text, rules):
    """团队视图：所有数值（含无单位数字）与红线主体一律打码；编号锚保留以维持可定位。"""
    holds = []

    def hold(m):
        holds.append(m.group(0))
        return f"__ANCHOR{chr(65 + len(holds) - 1)}__"

    text = re.sub(r"〔[0-9]+〕|L[0-9]+", hold, text)
    text = re.sub(r"(?:19|20)[0-9]{2}年?", "<数据>", text)
    text = re.sub(r"[0-9]+(?:[.][0-9]+)?[%％]?", "<数据>", text)
    for marker in rules["redline_markers"]:
        text = text.replace(marker, "<主体>")
    for i, value in enumerate(holds):
        text = text.replace(f"__ANCHOR{chr(65 + i)}__", value)
    return text


def why_for_team(why, rules):
    return redact(why, rules)


def build_rule_cards(annotations, rules):
    """按 cause 归纳，只取出现 >=2 次且跨 >=2 个 loc 的判据，最多 3 条。"""
    by_cause = {}
    for a in annotations:
        by_cause.setdefault(a["cause"], []).append(a)
    cards = []
    for cause, items in sorted(by_cause.items()):
        locs = {a["loc"] for a in items}
        if len(items) >= 2 and len(locs) >= 2:
            signals = sorted({a["rule"] for a in items})
            cards.append(f"看到 {cause} 类信号（{','.join(signals)}）→ 问「删掉它，信息或语气有损失吗？」→ 无损失才精简，有损失就留。")
    if not cards:
        cards.append("看到成串的模板腔信号 → 问「删掉它，信息或语气有损失吗？」→ 有损失就留，别按数量指标一刀切。")
    return cards[: rules["thresholds"]["rule_card_max"]]


def annotated_original(original, annotations):
    lines = original.splitlines()
    for i, a in enumerate(annotations, 1):
        n = line_no(a["loc"])
        if n and 1 <= n <= len(lines):
            lines[n - 1] = lines[n - 1].rstrip() + f"〔{i}〕"
    return "\n".join(lines)


def chapter_summary(original, annotations, rules):
    """长文降档：章级摘要 + 抽样 3 处，全量明细留 json。"""
    lines = original.splitlines()
    chapters, cur, start = [], [], 1
    for i, line in enumerate(lines, 1):
        if not line.strip():
            if cur:
                chapters.append((start, i - 1, cur))
                cur = []
            start = i + 1
        else:
            cur.append(i)
    if cur:
        chapters.append((start, len(lines), cur))
    out = ["| 章 | 行区间 | 立案处数 | 已改 | 保留 | 待确认 |", "|---|---|---|---|---|---|"]
    for idx, (s, e, nums) in enumerate(chapters, 1):
        items = [a for a in annotations if line_no(a["loc"]) in nums]
        c = Counter(a["state"] for a in items)
        out.append(f"| 第{idx}章 | L{s}–L{e} | {len(items)} | {c['已改']} | {c['保留']} | {c['待确认']} |")
    return "\n".join(out)


def make_annotation_md(original, annotations, cards, acceptance, route_card,
                       rules, team=False, ledger_rel=""):
    head = [
        "# 批注版" + ("（团队脱敏视图）" if team else "（自用视图）"),
        "",
        f"- 材料类型：{route_card.get('type')} {route_card.get('type_name','')}",
        f"- 视图：{'团队脱敏' if team else '自用全字段'}｜生成时间：{now_iso()}",
        f"- 机读账本：`{ledger_rel}`（本机，未回显对话）",
        "",
        "## 一、原文（完整保留，改动处挂编号锚）",
        "",
        "```text",
    ]
    body = annotated_original(original, annotations)
    if team:
        body = redact(body, rules)
    head += [body, "```", "", "## 二、逐处批注（8 字段）", "",
             "| # | loc | src | dst | rule | cause | why | state | fact_ok |",
             "|---|---|---|---|---|---|---|---|---|"]
    for i, a in enumerate(annotations, 1):
        row = [str(i), a["loc"], a["src"], a["dst"], a["rule"], a["cause"],
               a["why"], a["state"], a["fact_ok"]]
        if team:
            row[2], row[3], row[6] = redact(row[2], rules), redact(row[3], rules), why_for_team(row[6], rules)
        head.append("| " + " | ".join(x.replace("|", "\\|") for x in row) + " |")

    kept = [(i, a) for i, a in enumerate(annotations, 1) if a["state"] == "保留"]
    head += ["", f"## 三、我保留了哪些，以及为什么（{len(kept)} 处）", ""]
    if kept:
        for i, a in kept:
            head.append(f"- 〔{i}〕{a['loc']}：{a['why']}；若删会损失该句承担的信息或语气")
    else:
        head.append("- 本稿无保留项。")

    head += ["", "## 四、本次可迁移的判断（≤3 条）", ""]
    head += [f"{i}. {c}" for i, c in enumerate(cards, 1)]
    head += ["", "## 五、验收（四项一表出）", "",
             "| 项 | 值 | 判读线 | 一票否决 |", "|---|---|---|---|"]
    fc = acceptance["four_checks"]
    for key, val in fc.items():
        head.append(f"| {key} | {val.get('value')} | {val.get('threshold','全 pass')} | {'是' if val.get('veto') else '否'} |")
    head += ["", f"结论：`{acceptance['verdict']}`", ""]
    if route_card.get("long_doc"):
        head += ["## 六、长文章级摘要", "", chapter_summary(original, annotations, rules), ""]
    if team:
        head += ["## 团队可讲口径", "",
                 f"- 病因分布：{dict(Counter(a['cause'] for a in annotations))}",
                 f"- 保留项占比：{len(kept)}/{max(1,len(annotations))}",
                 "- 只讲判断方法，不讲改了哪一句、不出现实体值", ""]
    return "\n".join(head) + "\n"


def make_acceptance_md(acceptance, route_card, rules, cards, annotations, ledger_rel):
    fc = acceptance["four_checks"]
    states = Counter(a["state"] for a in annotations)
    lines = [
        "# 验收表", "", "## 高管一页纸", "",
        f"- 稿件类型与定级：{route_card.get('type')} / {route_card.get('guard_level')} 把关",
        f"- 一句话结论：`{acceptance['verdict']}`；事实守恒{'全通过' if fc['事实守恒']['value']=='全 pass' else '未通过'}",
        f"- 三个总数：洗前症状数 {fc['去味率']['symptoms_before']} ／ 改动处数 {states['已改']} ／ 事实核对通过数 {sum(1 for a in annotations if a['fact_ok']=='pass')}",
        f"- 一条最易踩红线：{'🔴 命中，本机生成、零回显' if route_card.get('redline') else '🟢 未命中红线标记'}",
        f"- 待点头事项数：{states['待确认']}", "",
        "## 四项验收与公式复算", "",
        "| 项 | 表达式 | 本次值 | 判读线 | 一票否决 |", "|---|---|---|---|---|",
        f"| 事实守恒 | token 种类与计数前后一致 | {fc['事实守恒']['value']} | 全 pass | 是 |",
        f"| 改动率 | 归一化改字符数 ÷ 总字符数 | {fc['改动率']['value']} | 轻改 >{fc['改动率']['threshold']} fail | 否 |",
        f"| 去味率 | 1 − 洗后症状数 ÷ 洗前症状数 | {fc['去味率']['value']} | {fc['去味率']['threshold']} | 否 |",
        f"| 有主性 | 1–10 代理分 | {fc['有主性']['value']} | ≥{fc['有主性']['threshold']} | 否 |",
        "", f"- 篇幅占比：{acceptance['length_ratio']}（回退线 {rules['thresholds']['length_ratio_min']}）",
        f"- 洗前 / 洗后症状数：{fc['去味率']['symptoms_before']} / {fc['去味率']['symptoms_after']}（按症状复扫单算，与 state 占比无映射）", "",
        "## 结论与返工提示", "", f"- verdict：`{acceptance['verdict']}`",
    ]
    for r in acceptance["fail_reasons"]:
        lines.append(f"- 中止原因：{r}")
    for r in acceptance["rework_hints"]:
        lines.append(f"- 返工建议（未自动执行，需人工判断）：{r}")
    lines += ["", "## 假设登记册", "",
              "| 假设 | owner | 复核日 | 来源置信 |", "|---|---|---|---|",
              "| 有主性与症状密度为代理指标，只作返工触发线 | 本技能 | 已声明 | 中（本机可复算，非人工评分） |",
              "| docx 页眉页脚脚注文本框未覆盖 | 本技能 | 已声明 | 高（能力边界显式声明） |", "",
              "## QA 自检清单", "",
              "| 维度 | 自检项 | 状态 |", "|---|---|---|",
              "| A 判据 | 统一判据与仲裁顺序生效 | 达标 |",
              "| B 事实 | 数字年份单位 token 前后一致 | 达标 |",
              "| B 事实 | 已用样稿验证 | 待执行（本轮仅占位短稿） |",
              "| C 授权 | 整句删除进待点头，主说明不动 | 达标 |",
              "| D 合规 | 红线零回显、本机生成、敏感词表已扫 | 达标 |",
              "| E 复用 | 规则层单一机读源可解析 | 达标 |",
              "| F 交付 | 四件人读产物 + 机读账本齐 | 达标 |",
              "| F 交付 | 本 QA 已逐项勾选 | 待执行 |", "",
              f"机读账本：`{ledger_rel}`", "",
              "> 对话回显白名单：4 条人读路径 + 汇总数字；原文片段、数字、客户名一律不回显。", ""]
    return "\n".join(lines)


def write_all(original, final, annotations, acceptance, route_card, rules,
              outdir, basename, team=False, meta=None):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    cards = build_rule_cards(annotations, rules)
    suffix = Path(basename).suffix if Path(basename).suffix in (".md", ".txt") else ".md"
    stem = Path(basename).stem

    p_clean = unique_path(outdir, f"{stem}_干净成稿{suffix}")
    p_anno = unique_path(outdir, f"{stem}_批注版{suffix}")
    p_card = unique_path(outdir, f"{stem}_判断卡{suffix}")
    p_acc = unique_path(outdir, f"{stem}_验收表{suffix}")
    p_json = unique_path(outdir, f"{stem}_批注.json")
    p_team = unique_path(outdir, f"{stem}_批注版_团队{suffix}") if team else None

    ledger_rel = p_json.name
    write_text(p_clean, final)
    write_text(p_anno, make_annotation_md(original, annotations, cards, acceptance,
                                          route_card, rules, False, ledger_rel))
    write_text(p_card, "# 判断卡（本次可迁移的判断，≤3 条）\n\n" +
               "\n".join(f"{i}. {c}" for i, c in enumerate(cards, 1)) + "\n")
    write_text(p_acc, make_acceptance_md(acceptance, route_card, rules, cards,
                                         annotations, ledger_rel))
    if p_team:
        write_text(p_team, make_annotation_md(original, annotations, cards, acceptance,
                                              route_card, rules, True, ledger_rel))

    ledger = {
        "schema": "去AI味把关台/批注账本 v1",
        "ts": now_iso(),
        "version": (meta or {}).get("version"),
        "rules_active": (meta or {}).get("rules_active"),
        "original_sha256": sha256_text(original),
        "route": route_card,
        "acceptance": acceptance,
        "rule_cards": cards,
        "annotations": annotations,
        "deliverables": {"clean": p_clean.name, "annotated": p_anno.name,
                         "card": p_card.name, "acceptance": p_acc.name,
                         "team": p_team.name if p_team else None},
        "summary": {
            "symptoms_before": acceptance["four_checks"]["去味率"]["symptoms_before"],
            "edited": sum(1 for a in annotations if a["state"] == "已改"),
            "kept": sum(1 for a in annotations if a["state"] == "保留"),
            "pending": sum(1 for a in annotations if a["state"] == "待确认"),
            "fact_fail": sum(1 for a in annotations if a["fact_ok"] == "fail"),
        },
    }
    dump_json(p_json, ledger)
    return {
        "paths": {"clean": str(p_clean), "annotated": str(p_anno),
                  "card": str(p_card), "acceptance": str(p_acc)},
        "ledger_path": str(p_json),
        "team_path": str(p_team) if p_team else None,
        "ledger": ledger,
        "cards": cards,
    }


def main():
    ap = argparse.ArgumentParser(description="去AI味把关台 · 第7-8步装配")
    ap.add_argument("--original", required=True)
    ap.add_argument("--final", required=True)
    ap.add_argument("--annotations", required=True)
    ap.add_argument("--acceptance", required=True)
    ap.add_argument("--route-json", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--basename", required=True)
    ap.add_argument("--team", action="store_true")
    a = ap.parse_args()
    from _common import load_json, load_meta, load_rules
    rules, meta, _ = load_rules()
    data = load_json(a.annotations, {})
    ann = data.get("annotations", [])
    acc = load_json(a.acceptance, {})
    card = load_json(a.route_json, {})
    res = write_all(read_text(a.original), read_text(a.final), ann, acc, card,
                    rules, a.outdir, a.basename, a.team, meta)
    print(json.dumps({"paths": res["paths"], "summary": res["ledger"]["summary"]},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
