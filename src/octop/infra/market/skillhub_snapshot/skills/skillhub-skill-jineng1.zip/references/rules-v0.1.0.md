# 规则层 v0.1.0（唯一机读规则源）

> **单一数据源声明**：本文件的人读部分不定义任何数值与规则。下方 `RULES_JSON` 块是 `judge.py` / `guard.py` 启动时唯一读取的规则源；信号开关、阈值、词锚、HARD 词表、红线标记全在这里。L3 自动升级只替换本块，主 `SKILL.md` 永不自动写。
> **版本绑定**：文件名带版本号；`_meta.json` 的 `rules_active` 指向本文件；回退点绑定版本号。
> **合规**：词锚为自研最小集，只作立案锚，判决一律回到 `criteria.md` 的唯一判据。未搬运任何现成技能包词表原文。

## 人读速览

| 组 | 内容 | 改这里会影响 |
|---|---|---|
| `signals` | 7 个结构性信号（S1–S7）的开关、参数与动作 | 哪些位置被立案、哪些可做无损改写 |
| `density` | Tier1/2/3 立案门槛 | 单词是否算病 |
| `thresholds` | 去味率、改动率、篇幅、有主性、长文、抽样、规则卡上限 | 验收返工线 |
| `hard_words` | 对外物料合规 HARD 词 | 出单闸门 |
| `redline_markers` | 🔴 类别标记 | 回显与脱敏强度 |
| `fact_token_patterns` | 不可改 token 的抽取式 | 事实守恒核对 |
| `upgrade` | L2/L3 阈值与写入目标 | 自改进通道 |

## 升级纪律

1. L1 / L2 只写 `state/` 账本，不动本文件。
2. L3 必须走六步：备份 → diff 供确认 → 人类确认 → 只写本块 → 占位短稿回归校验 → 留回退点。
3. 任一校验不过自动回到备份；`main_skill_writable=false` 为硬编码禁止项，L3 不得修改它。

<!-- RULES_JSON_BEGIN -->
```json
{
  "version": "0.1.0",
  "single_source": true,
  "unified_question": "删掉它，信息或语气有损失吗？",
  "arbitration": ["事实守恒", "功能判据", "类型强度", "使用者改判"],
  "causes": {
    "A": "铺垫大于直陈",
    "B": "按规则造节奏",
    "C": "夸饰与借权威",
    "D": "按规则排版",
    "E": "对话残留",
    "F": "写错读者"
  },
  "no_edit_genres": ["公文", "法规", "标准", "学术正文", "说明书", "批件", "会议决议", "数据表附注", "编号清单", "法定格式函件"],
  "density": {
    "tier1_ratio": [5, 20],
    "tier2_short": 2,
    "tier2_long": 3,
    "tier3_short": 3,
    "tier3_middle": 5,
    "tier3_long_ratio": 0.005
  },
  "signals": [
    {
      "id": "S1",
      "name": "三段式并列",
      "cause": "B",
      "kind": "punct_run",
      "min_count": 3,
      "puncts": ["、", "；"],
      "action": "candidate",
      "editable": false
    },
    {
      "id": "S2",
      "name": "模糊限定叠加",
      "cause": "F",
      "kind": "term_stack",
      "min_count": 2,
      "terms": ["可能", "或许", "在一定程度上", "一般来说", "某种程度上", "相对而言", "大体上"],
      "action": "strip_hedge",
      "editable": true
    },
    {
      "id": "S3",
      "name": "对称否定句式",
      "cause": "B",
      "kind": "pair_connector",
      "lead": ["不是", "并非", "而非"],
      "partner": ["而是"],
      "action": "candidate",
      "editable": false
    },
    {
      "id": "S4",
      "name": "段尾安全升华",
      "cause": "A",
      "kind": "tail_upscale",
      "terms": ["彰显", "赋能", "助力", "值得关注", "综上所述", "总而言之", "迈上新台阶", "谱写新篇章"],
      "action": "pending_sentence",
      "editable": false
    },
    {
      "id": "S5",
      "name": "句长高度均匀",
      "cause": "B",
      "kind": "sentence_uniform",
      "min_sentences": 4,
      "max_stdev": 3.0,
      "action": "hint",
      "editable": false
    },
    {
      "id": "S6",
      "name": "相邻句同头反复",
      "cause": "E",
      "kind": "repeat_head",
      "head_chars": 4,
      "action": "candidate",
      "editable": false
    },
    {
      "id": "S7",
      "name": "空泛大词密度",
      "cause": "C",
      "kind": "term_density",
      "min_count": 2,
      "terms": ["赋能", "助力", "彰显", "维度", "闭环", "生态", "抓手"],
      "action": "candidate",
      "editable": false
    }
  ],
  "thresholds": {
    "deai_rate": [0.70, 0.90],
    "change_rate_rewrite_min": 0.15,
    "change_rate_light_max": 0.40,
    "length_ratio_min": 0.85,
    "authorial_min": 5,
    "sample_detail_long": 3,
    "long_doc_chars": 3000,
    "rule_card_max": 3,
    "blind_max": 3
  },
  "hard_words": ["治疗", "治愈", "预防", "根治", "保证疗效", "绝对安全", "无副作用", "特效", "包治"],
  "redline_markers": ["合同", "价格", "代理", "客户", "预算", "成本", "未公开", "折扣", "返利", "结算价", "毛利"],
  "fact_token_patterns": [
    "[0-9]+(?:[.][0-9]+)?[%元万人片支盒件吨次年月日批号]",
    "(?:19|20)[0-9]{2}年?",
    "[A-Za-z]{1,6}[-]?[0-9]{2,}"
  ],
  "no_touch": ["数字", "单位", "年份", "归属", "责任主体", "证据强度"],
  "upgrade": {
    "l2_min": 3,
    "l3_min": 5,
    "write_target": "rules",
    "main_skill_writable": false
  }
}
```
<!-- RULES_JSON_END -->
