# 中间产物 Schema 详解

八模块通过 JSON 中间产物解耦交接。每个产物落盘到 `build/artifacts/`，命名规则 `NN_名称.json`（NN=模块序号），支持追溯与断点续跑。

## 01_spec.json — Requirement Spec（模块①输出）

```json
{
  "module": "m01",
  "scene": "business_report",
  "scene_label": "商业汇报",
  "audience": "ceo",
  "audience_label": "CEO / 高管（结论先行，少细节）",
  "constraints": {
    "page_range": [10, 12],
    "brand_color": null,
    "must_sections": ["目录"],
    "style_hint": null
  },
  "config": { "max_slides": 40, "max_iterations": 3, "p0_blocking": true, "...": "..." },
  "pending_clarify": [],
  "complete": true
}
```

## 02_content_graph.json — Content Graph（模块②输出）

```json
{
  "module": "m02",
  "blocks": [ { "text": "营收3200万", "relation": "sequence", "data": [{"value":"3200","offset":0}] } ],
  "block_count": 18,
  "data_count": 9,
  "relations": { "sequence": 5 }
}
```

`relation` 取值：`parallel`(并列) / `sequence`(递进) / `causal`(因果) / `contrast`(对比) / `hierarchy`(总分) / `timeline`(时间线)。

## 03_outline.json — Slide Outline（模块③输出）

```json
{
  "module": "m03",
  "slide_count": 9,
  "slides": [
    { "title": "我们解决的问题", "layout": "content", "points": ["..."], "relation": "causal", "chart": null }
  ],
  "narrative": ["cover","content","content","..."]
}
```

`layout` 取值：`cover/section/agenda/content/two_column/table/chart/timeline/quote/image/summary/contact`。

## 04_theme.json — Theme Token（模块④输出）

```json
{
  "module": "m04",
  "theme_key": "business_blue",
  "theme": { "name":"商业蓝", "primary":"1F4E79", "secondary":"2E75B6", "accent":"E8A33D", "...": "..." },
  "font_title": "微软雅黑",
  "aspect": "16:9"
}
```

## 05_visuals.json — Visual Spec（模块⑤输出）

```json
{
  "module": "m05",
  "chart_count": 1,
  "visuals": [
    { "title":"市场规模", "layout":"chart", "chart": {"type":"bar","categories":["项1"],"series":[{"name":"数据","values":["3200"]}]} }
  ]
}
```

## 06_binding.json — Template Binding（模块⑥输出）

```json
{
  "module": "m06",
  "slides": [
    { "index":0, "layout":"cover", "title":"...", "points":[], "chart":null, "editable":true }
  ]
}
```

## 07_qa_iterN.json — QA Report（模块⑦输出）

```json
{
  "module": "m07",
  "issues": [ {"level":"P0","page":0,"type":"overflow","msg":"要点过多"} ],
  "p0_count": 1, "p1_count": 0, "p2_count": 0,
  "blocked": true, "pass": false
}
```

`level` 取值：`P0`(阻断) / `P1`(重要) / `P2`(提示)。

## 08_result.json — 交付结果（模块⑧输出）

```json
{
  "module": "m08",
  "output_path": "build/report.pptx",
  "slide_count": 9,
  "iterations": 1,
  "qa": { "p0":0, "p1":0, "p2":0, "pass":true }
}
```

## 断点续跑约定

- 每个模块产物独立落盘，文件名含模块序号。
- 质检产物带 `iterN` 后缀，保留每次回写轮次的历史。
- 重新运行会覆盖同名产物；如需保留历史，改 `--out-dir`。
