"""模块⑤ 图文与图表编排 (Visual & Chart Composition)

职责：把每页内容转成"用哪种视觉 + 数据如何映射"，落实"少字多图"。
输入：Slide Outline + Theme Token。
输出：Visual Spec（每页的 chart/table/timeline 结构化描述）。

数据可视化规范：
- 柱状图按数值排序（非时间序列时）。
- 饼图 ≤6 切片。
- 折线 ≤4 条线。
"""

from __future__ import annotations

from . import contracts as C


def _sort_bar(chart: dict) -> dict:
    if chart["type"] != "bar":
        return chart
    series = chart["series"][0]
    pairs = sorted(zip(chart["categories"], series["values"]),
                   key=lambda x: _num(x[1]), reverse=True)
    chart["categories"] = [p[0] for p in pairs]
    series["values"] = [p[1] for p in pairs]
    return chart


def _num(v) -> float:
    try:
        return float(str(v).replace("%", "").replace("％", "").replace("亿", "").replace("万", ""))
    except ValueError:
        return 0.0


def run(spec: dict, outline: dict, token: dict) -> dict:
    visuals = []
    for s in outline["slides"]:
        v = {
            "title": s["title"],
            "layout": s["layout"],
            "points": s["points"],
            "relation": s["relation"],
            "chart": None,
            "table": None,
            "timeline": None,
            "quote": None,
        }
        if s["layout"] == "chart" and s["chart"]:
            v["chart"] = _sort_bar(s["chart"])
        elif s["layout"] == "chart" and not s["chart"] and s["points"]:
            vals = [_num(p) for p in s["points"] if _num(p) > 0]
            if vals:
                v["chart"] = {"type": "bar", "categories": [f"项{i+1}" for i in range(len(vals))],
                              "series": [{"name": "数据", "values": vals}]}
        elif s["layout"] == "table" and s["points"]:
            v["table"] = {"headers": ["要点"], "rows": [[p] for p in s["points"][:6]]}
        elif s["layout"] == "timeline" and s["points"]:
            v["timeline"] = [{"label": p[:10], "desc": p} for p in s["points"][:6]]
        elif s["layout"] == "quote" and s["points"]:
            v["quote"] = s["points"][0]
        visuals.append(v)

    return {
        "module": "m05",
        "visual_count": len(visuals),
        "chart_count": sum(1 for v in visuals if v["chart"]),
        "visuals": visuals,
    }
