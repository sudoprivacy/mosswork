"""联网内容检索引擎（模块②的可选内容补全能力）。

整合自 ppt-generator-skill「AI 内容检索与填充」流程：
当用户输入内容较少/不完整时，主动联网检索补充行业数据、趋势、案例。

设计原则：
- 作为 distill_engine 的 "web" 选项，与 "llm"/"regex" 并列。
- 本模块只负责"内容检索与补全"，把检索到的补充文本拼接到源文本后，
  再交给既有的提炼逻辑（LLM 或正则）生成 Content Graph，契约不变。
- 零外部 SDK：用 urllib 调 DuckDuckGo 免费检索（无需 API Key），失败静默降级。

环境变量：
- PPT_WEB_SEARCH=1  启用联网检索（配合 distill_engine=web 或 auto）

触发条件（整合自源 skill 的「内容缺口识别」）：
- 源文本长度过短（< 200 字）视为"内容缺口"。
- 或 distill_engine 显式为 "web"。
"""

from __future__ import annotations

import json
import os
import re
import urllib.parse
import urllib.request

_MAX_RESULTS = 8
_MIN_SOURCE_LEN = 200  # 源文本低于此长度视为内容缺口


def _is_enabled() -> bool:
    return os.environ.get("PPT_WEB_SEARCH") == "1"


def _has_content_gap(source_text: str) -> bool:
    return len(source_text.strip()) < _MIN_SOURCE_LEN


def _search_duckduckgo(query: str) -> list[str]:
    """DuckDuckGo 轻量检索，返回摘要文本列表（免费，无 Key）。"""
    url = "https://api.duckduckgo.com/?" + urllib.parse.urlencode({
        "q": query, "format": "json", "no_html": 1, "skip_disambig": 1,
    })
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return []
    snippets = []
    if data.get("AbstractText"):
        snippets.append(data["AbstractText"])
    for related in data.get("RelatedTopics", [])[: _MAX_RESULTS]:
        if isinstance(related, dict) and related.get("Text"):
            snippets.append(related["Text"])
        elif isinstance(related, str):
            snippets.append(related)
    return snippets


def _extract_facts(snippets: list[str]) -> list[str]:
    """从检索摘要中提取含数字/事实的句子。"""
    facts = []
    for s in snippets:
        for sent in re.split(r"[。；;\n]", s):
            sent = sent.strip()
            if 10 <= len(sent) <= 120 and re.search(r"\d", sent):
                facts.append(sent)
    return facts[: _MAX_RESULTS]


def enrich(topic: str, source_text: str) -> str:
    """检索主题相关信息，拼接到源文本后，返回增强后的文本。

    内容缺口过大时才启用；失败或未启用时原样返回（静默降级）。
    """
    if not _is_enabled():
        return source_text
    if not _has_content_gap(source_text) and not source_text.strip():
        return source_text
    # 主题提取：优先用 source_text 的首句，否则用传入 topic
    topic_clean = source_text.strip().split("\n")[0][:40] if source_text.strip() else topic
    if not topic_clean:
        return source_text
    snippets = _search_duckduckgo(topic_clean)
    facts = _extract_facts(snippets)
    if not facts:
        return source_text
    supplement = "\n".join(facts)
    return f"{source_text}\n{supplement}"


def is_available() -> bool:
    return _is_enabled()
