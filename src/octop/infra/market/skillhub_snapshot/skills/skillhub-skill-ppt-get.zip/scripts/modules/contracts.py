"""PPT 制作专家 · 数据契约与常量定义。

所有模块之间的交接靠本文件的中间产物 schema 与枚举常量，
实现"模块解耦、契约化交接"。这是复刻本专家的根基。
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# 场景枚举（模块① 输出）
# ---------------------------------------------------------------------------
SCENE_BIZ_REPORT = "business_report"    # 商业汇报 / 季度业绩 / 项目进展
SCENE_PRODUCT_LAUNCH = "product_launch"  # 产品发布 Launch Deck
SCENE_PITCH = "pitch"                    # 融资路演 Pitch Deck
SCENE_TRAINING = "training"              # 培训课件
SCENE_CONFERENCE = "conference"          # 大会主题演讲
SCENE_BATCH = "batch"                    # 模板化批量生成

SCENES = {
    SCENE_BIZ_REPORT: "商业汇报",
    SCENE_PRODUCT_LAUNCH: "产品发布",
    SCENE_PITCH: "融资路演",
    SCENE_TRAINING: "培训课件",
    SCENE_CONFERENCE: "大会演讲",
    SCENE_BATCH: "批量生成",
}

# ---------------------------------------------------------------------------
# 受众枚举
# ---------------------------------------------------------------------------
AUDIENCES = {
    "ceo": "CEO / 高管（结论先行，少细节）",
    "client": "客户（价值与案例导向）",
    "staff": "员工（培训/宣贯，逻辑完整）",
    "investor": "投资人（市场/团队/财务）",
    "public": "公众（通俗易懂）",
}

# ---------------------------------------------------------------------------
# 配色方案（模块④ 输出）
# 整合自 ppt-generator-skill：12 套专业配色 + 原有 5 套，共 17 套。
# 字段约定：primary 主色 / secondary 辅色 / accent 强调色 / neutral 中性背景 /
#          text 正文 / text_light 弱化文字 / bg 页面背景 / bg_dark 深色背景 /
#          font_title 标题字体 / font_body 正文字体 / fit 适用场景。
# ---------------------------------------------------------------------------
THEMES = {
    # ---- 原有 5 套（保留兼容）----
    "business_blue": {
        "name": "商业蓝",
        "primary": "1F4E79", "secondary": "2E75B6", "accent": "E8A33D",
        "neutral": "F2F2F2", "text": "333333", "text_light": "6B7280",
        "bg": "FFFFFF", "bg_dark": "1F4E79",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_BIZ_REPORT, SCENE_PRODUCT_LAUNCH],
    },
    "pitch_red": {
        "name": "路演红",
        "primary": "C0392B", "secondary": "E67E22", "accent": "2C3E50",
        "neutral": "FBF6F0", "text": "2C2C2C", "text_light": "6B7280",
        "bg": "FFFFFF", "bg_dark": "C0392B",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_PITCH],
    },
    "academic_white": {
        "name": "学术白",
        "primary": "2C3E50", "secondary": "5D6D7E", "accent": "1ABC9C",
        "neutral": "F4F6F7", "text": "2C3E50", "text_light": "7F8C8D",
        "bg": "FFFFFF", "bg_dark": "2C3E50",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_TRAINING, SCENE_CONFERENCE],
    },
    "tech_dark": {
        "name": "科技深",
        "primary": "0B132B", "secondary": "1C2541", "accent": "3A86FF",
        "neutral": "1C2541", "text": "EDF2F4", "text_light": "8B949E",
        "bg": "0B132B", "bg_dark": "0B132B",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_CONFERENCE, SCENE_PRODUCT_LAUNCH],
    },
    "minimal_gray": {
        "name": "极简灰",
        "primary": "34495E", "secondary": "7F8C8D", "accent": "16A085",
        "neutral": "F8F9F9", "text": "333333", "text_light": "8B949E",
        "bg": "FFFFFF", "bg_dark": "34495E",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_BIZ_REPORT, SCENE_BATCH],
    },

    # ---- 新增：整合自 ppt-generator-skill 配色方案.md ----
    "midnight-executive": {
        "name": "午夜商务",
        "primary": "1E2761", "secondary": "CADCFC", "accent": "FFFFFF",
        "neutral": "F5F7FA", "text": "1E2761", "text_light": "6B7280",
        "bg": "FFFFFF", "bg_dark": "1E2761",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_BIZ_REPORT, SCENE_PITCH],
    },
    "tech-deepspace": {
        "name": "科技深空",
        "primary": "0D1117", "secondary": "161B22", "accent": "58A6FF",
        "neutral": "21262D", "text": "F0F6FC", "text_light": "8B949E",
        "bg": "0D1117", "bg_dark": "0D1117",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_CONFERENCE, SCENE_PRODUCT_LAUNCH],
    },
    "coral-energy": {
        "name": "珊瑚活力",
        "primary": "F96167", "secondary": "F9E795", "accent": "2F3C7E",
        "neutral": "FFFFFF", "text": "1F2937", "text_light": "6B7280",
        "bg": "FFFFFF", "bg_dark": "F96167",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_PRODUCT_LAUNCH, SCENE_CONFERENCE],
    },
    "warm-terracotta": {
        "name": "暖陶简约",
        "primary": "B85042", "secondary": "E7E8D1", "accent": "A7BEAE",
        "neutral": "FDFBF7", "text": "3D3D3D", "text_light": "6B7280",
        "bg": "FDFBF7", "bg_dark": "B85042",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_TRAINING, SCENE_CONFERENCE],
    },
    "ocean-gradient": {
        "name": "海洋渐变",
        "primary": "065A82", "secondary": "1C7293", "accent": "21295C",
        "neutral": "F0F9FF", "text": "065A82", "text_light": "6B7280",
        "bg": "FFFFFF", "bg_dark": "065A82",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_BIZ_REPORT, SCENE_CONFERENCE],
    },
    "charcoal-minimal": {
        "name": "炭灰极简",
        "primary": "36454F", "secondary": "F2F2F2", "accent": "212121",
        "neutral": "FFFFFF", "text": "36454F", "text_light": "8B949E",
        "bg": "FFFFFF", "bg_dark": "36454F",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_BIZ_REPORT, SCENE_BATCH],
    },
    "teal-trust": {
        "name": "青绿信任",
        "primary": "028090", "secondary": "00A896", "accent": "02C39A",
        "neutral": "F0FDF4", "text": "065A60", "text_light": "374151",
        "bg": "FFFFFF", "bg_dark": "028090",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_BIZ_REPORT, SCENE_PRODUCT_LAUNCH],
    },
    "berry-cream": {
        "name": "莓果奶油",
        "primary": "6D2E46", "secondary": "A26769", "accent": "ECE2D0",
        "neutral": "FDFBF7", "text": "3D3D3D", "text_light": "6B7280",
        "bg": "FDFBF7", "bg_dark": "6D2E46",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_PRODUCT_LAUNCH],
    },
    "sage-calm": {
        "name": "鼠尾草静",
        "primary": "84B59F", "secondary": "69A297", "accent": "50808E",
        "neutral": "F5F9F8", "text": "3D4F4E", "text_light": "6B7280",
        "bg": "F5F9F8", "bg_dark": "84B59F",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_TRAINING],
    },
    "cherry-bold": {
        "name": "樱桃大胆",
        "primary": "990011", "secondary": "FCF6F5", "accent": "2F3C7E",
        "neutral": "FFFFFF", "text": "1F2937", "text_light": "6B7280",
        "bg": "FFFFFF", "bg_dark": "990011",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_PRODUCT_LAUNCH, SCENE_PITCH],
    },
    "gradient-tech": {
        "name": "渐变科技",
        "primary": "667EEA", "secondary": "764BA2", "accent": "F093FB",
        "neutral": "0F0F23", "text": "FFFFFF", "text_light": "A0AEC0",
        "bg": "0F0F23", "bg_dark": "0F0F23",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_CONFERENCE, SCENE_PRODUCT_LAUNCH],
    },
    "matcha-japanese": {
        "name": "抹茶日式",
        "primary": "5C7C4D", "secondary": "A8C686", "accent": "D4A574",
        "neutral": "F9F6F0", "text": "3D3D3D", "text_light": "6B7280",
        "bg": "F9F6F0", "bg_dark": "5C7C4D",
        "font_title": "微软雅黑", "font_body": "微软雅黑",
        "fit": [SCENE_TRAINING, SCENE_CONFERENCE],
    },
}

# ---------------------------------------------------------------------------
# 风格库（模块④ 可选：用户指定 style 时覆盖主题选择）
# 整合自 ppt-generator-skill 风格库，keyword 命中即选用对应风格。
# 每项：theme 关联的配色 key / keywords 触发词 / fit 适用场景 / note 说明。
# ---------------------------------------------------------------------------
STYLES = {
    "mbe": {
        "name": "MBE 插画", "theme": "minimal_gray", "primary_override": "FFFFFF",
        "accent_override": "FFD600",
        "keywords": ["mbe", "插画", "卡通", "校园", "新生", "开学", "年轻", "活泼", "z世代", "描边"],
        "note": "白底黑描边 + 高饱和撞色，Q 版卡通，左右分栏",
    },
    "retro-cartoon": {
        "name": "复古卡通", "theme": "warm-terracotta", "primary_override": "F9E79F",
        "accent_override": "2C2C2C",
        "keywords": ["复古", "手绘", "涂鸦", "molle", "猫咪", "手账", "治愈", "奶油黄", "复古杂志"],
        "note": "奶油黄主色 + 粗黑马克笔轮廓 + 卡片式大圆角布局",
    },
    "minimal-tech": {
        "name": "极简技术风", "theme": "tech-deepspace",
        "keywords": ["git", "技术", "程序员", "代码", "黑白蓝", "极简技术"],
        "note": "黑白蓝配色，技术分享/编程教学",
    },
    "neumorphism-tech": {
        "name": "拟态科技风", "theme": "tech-deepspace",
        "keywords": ["拟态", "发光", "科技蓝", "述职", "年终总结"],
        "note": "深色拟态 + 发光科技蓝，年终述职",
    },
    "handdrawn-simple": {
        "name": "手绘简笔风", "theme": "minimal_gray",
        "keywords": ["手绘", "可爱", "马卡龙", "个人介绍", "新人入职", "自我介绍"],
        "note": "手绘可爱马卡龙色，个人介绍",
    },
    "spray-graffiti": {
        "name": "喷绘涂鸦风", "theme": "coral-energy",
        "keywords": ["喷绘", "涂鸦", "作品集", "设计师"],
        "note": "喷绘粉涂鸦，设计师作品集",
    },
    "morandi-academic": {
        "name": "莫兰迪学术风", "theme": "sage-calm",
        "keywords": ["莫兰迪", "棕色", "植物", "学术", "答辩", "毕业"],
        "note": "莫兰迪棕色 + 植物元素，毕业答辩",
    },
    "milktea-business": {
        "name": "奶茶商务风", "theme": "warm-terracotta",
        "keywords": ["奶茶", "莫兰迪", "商务", "提案", "品牌策划"],
        "note": "奶茶莫兰迪色，商业提案",
    },
    "geometric-fashion": {
        "name": "几何服装风", "theme": "charcoal-minimal",
        "keywords": ["几何", "切割", "灰调", "服装", "竖版"],
        "note": "几何切割灰调，服装电商",
    },
    "grid-product": {
        "name": "网格产品风", "theme": "minimal_gray",
        "keywords": ["网格", "极简", "产品", "详情", "电商详情"],
        "note": "网格极简，产品介绍",
    },
    "handdrawn-kids": {
        "name": "手绘儿童风", "theme": "coral-energy",
        "keywords": ["手绘", "线条", "儿童", "竖版", "童趣", "早教"],
        "note": "手绘线条童趣，儿童产品",
    },
    "avocado-ins": {
        "name": "牛油果绿 ins 风", "theme": "sage-calm",
        "keywords": ["牛油果绿", "ins风", "莫兰迪绿", "竖版", "小红书", "家居好物"],
        "note": "牛油果绿 ins 风，家居好物",
    },
    "monochrome": {
        "name": "极简黑白灰", "theme": "charcoal-minimal",
        "keywords": ["黑白灰", "极简", "高级", "留白", "作品集"],
        "note": "黑白灰极简留白，商务/作品集",
    },
    "milky-yellow-cartoon": {
        "name": "奶黄卡通", "theme": "warm-terracotta",
        "keywords": ["奶黄", "卡通", "可爱", "治愈", "儿童", "校园汇报"],
        "note": "奶黄卡通可爱，儿童内容",
    },
    "cream-yellow-gradient": {
        "name": "奶油黄渐变", "theme": "warm-terracotta",
        "keywords": ["奶油黄", "渐变", "温柔", "月度总结", "个人分享", "轻商务"],
        "note": "奶油黄渐变温柔，个人分享",
    },
    "muji": {
        "name": "MUJI 无印良品", "theme": "charcoal-minimal",
        "keywords": ["无印良品", "muji", "酒红", "品牌", "招商"],
        "note": "MUJI 酒红品牌风，品牌介绍",
    },
    "trendy-creative": {
        "name": "潮流创意合集", "theme": "gradient-tech",
        "keywords": ["弥散", "孟菲斯", "酸性", "时尚", "自媒体", "创意分享"],
        "note": "弥散/孟菲斯/酸性，自媒体创意",
    },
    "morandi-green-block": {
        "name": "莫兰迪绿方块", "theme": "sage-calm",
        "keywords": ["莫兰迪绿", "方块", "极简", "作品集", "产品展示"],
        "note": "莫兰迪绿方块极简，产品展示",
    },
}

# ---------------------------------------------------------------------------
# 字体搭配规范（模块④ 可选：按风格/行业选择字体）
# 整合自 ppt-generator-skill 配色方案.md 字体搭配章节。
# ---------------------------------------------------------------------------
FONT_STYLES = {
    "business": {"title": "微软雅黑", "body": "微软雅黑", "en": "Montserrat",
                 "note": "商务稳重"},
    "tech": {"title": "微软雅黑", "body": "微软雅黑", "en": "SF Pro Display",
             "note": "科技感"},
    "elegant": {"title": "思源宋体", "body": "微软雅黑", "en": "Playfair Display",
                "note": "优雅文艺"},
    "cute": {"title": "站酷快乐体", "body": "微软雅黑", "en": "Nunito",
             "note": "可爱活泼"},
}

# ---------------------------------------------------------------------------
# 排版规范（模块⑦ 质检 + 模块⑧ 渲染 使用）
# 整合自 ppt-generator-skill 排版规则。
# ---------------------------------------------------------------------------
TYPOGRAPHY = {
    "title_size": 36,        # 页面标题 pt（范围 36-44）
    "section_size": 22,      # 章节标题 pt（范围 20-24）
    "body_size": 16,         # 正文 pt（范围 14-16，禁低于 14）
    "caption_size": 11,      # 注释 pt（范围 10-12）
    "min_body_pt": 14,       # 正文最小字号（禁止事项）
    "max_colors": 4,         # 一页最多颜色数
}

# 排版禁止事项（模块⑦ 质检规则）
LAYOUT_RULES = {
    "no_underline_title": "标题不加下划线",
    "no_pure_text_page": "不用纯文字页面（需视觉元素）",
    "no_default_blue": "不滥用默认蓝（除非商务场景）",
    "no_repeat_layout_over_3": "同一布局不重复超 3 次",
    "no_body_below_14pt": "正文不小于 14pt",
    "min_whitespace_30": "留白 30% 以上",
}

# ---------------------------------------------------------------------------
# 版式类型（模块③/④ 使用）
# ---------------------------------------------------------------------------
LAYOUTS = {
    "cover": "封面",
    "section": "章节过渡页",
    "agenda": "目录页",
    "content": "标题+正文",
    "two_column": "双栏对比",
    "big_number": "大数据展示",   # 新增：KPI 数据卡片（整合自 ppt-generator-skill）
    "matrix": "2x2 矩阵",          # 新增：四象限/SWOT 分析
    "table": "表格页",
    "chart": "图表页",
    "timeline": "时间线",
    "quote": "引用/强调",
    "image": "图片页",
    "summary": "总结页",
    "contact": "结尾页",
}

# ---------------------------------------------------------------------------
# 图表类型（模块⑤ 使用）
# ---------------------------------------------------------------------------
CHART_TYPES = ("bar", "line", "pie")

# ---------------------------------------------------------------------------
# 逻辑关系枚举（模块② 输出）
# ---------------------------------------------------------------------------
REL_PARALLEL = "parallel"      # 并列
REL_SEQUENCE = "sequence"      # 递进
REL_CAUSAL = "causal"          # 因果
REL_CONTRAST = "contrast"      # 对比
REL_HIERARCHY = "hierarchy"    # 总分
REL_TIMELINE = "timeline"      # 时间线

# ---------------------------------------------------------------------------
# QA 严重级别
# ---------------------------------------------------------------------------
QA_P0 = "P0"   # 阻断：必须修复，否则不导出
QA_P1 = "P1"   # 重要：建议修复
QA_P2 = "P2"   # 提示：可忽略

# ---------------------------------------------------------------------------
# 默认配置
# ---------------------------------------------------------------------------
DEFAULT_CONFIG = {
    "aspect": "16:9",
    "max_slides": 40,
    "page_numbers": True,
    "footer": "",
    "lang": "zh",
    "max_iterations": 3,        # 质检回写最大迭代次数
    "p0_blocking": True,        # 存在 P0 时是否阻断导出
    "editable": True,           # 是否保证可编辑（文字用真实文本框）
    "distill_engine": "auto",   # 内容提炼引擎：auto=按需(LLM>web>regex) / llm=强制LLM / web=联网检索补全 / regex=强制离线正则
}
