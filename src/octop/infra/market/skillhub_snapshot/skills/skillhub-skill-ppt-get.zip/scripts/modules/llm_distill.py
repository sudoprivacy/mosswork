"""LLM 语义提炼后端（模块②的可选强化引擎）。

设计原则：
- 契约不变：LLM 与离线正则产出完全相同的 Content Graph schema，
  因此替换本后端不影响下游 m03~m08 任何模块。
- 可插拔：通过环境变量 / 配置指定后端，未配置或不支持时由 m02 自动回退离线正则。
- 无需外部 SDK：优先用标准库 urllib 调用 OpenAI 兼容接口，零额外依赖。

支持的后端（通过环境变量指定）：
- PPT_LLM_API_BASE   ：OpenAI 兼容接口 base URL（如 https://api.openai.com/v1）
- PPT_LLM_API_KEY    ：API Key
- PPT_LLM_MODEL      ：模型名（默认 gpt-4o-mini）

若任一关键变量缺失，`is_available()` 返回 False，m02 回退离线基线。
"""

from __future__ import annotations

import json
import os
import urllib.request

from . import contracts as C

# 逻辑关系 → 中文说明（供 LLM 提示词使用）
_RELATION_HINT = {
    C.REL_PARALLEL: "并列（平铺罗列多个要点）",
    C.REL_SEQUENCE: "递进（按先后顺序推进）",
    C.REL_CAUSAL: "因果（有因有果）",
    C.REL_CONTRAST: "对比（正反对照/差异）",
    C.REL_HIERARCHY: "总分（先总后分/归纳分类）",
    C.REL_TIMELINE: "时间线（按时间/阶段演进）",
}

_SYSTEM_PROMPT = (
    "你是一名专业的演示文稿内容提炼引擎。你的任务是把原始素材提炼成结构化信息块，"
    "供后续 PPT 大纲生成使用。\n"
    "要求：\n"
    "1. 去噪：剔除口语、冗余、重复、客套话，只保留有信息量的观点/数据/事实。\n"
    "2. 拆分：把内容拆成简短的信息块（每个 10~40 字），保持语义完整。\n"
    "3. 归类逻辑关系：为每个信息块标注 relation，只能从以下取值中选择：\n"
    + "\n".join(f"   - {k}: {v}" for k, v in _RELATION_HINT.items())
    + "\n4. 抽取数据点：识别数字/比例/金额，填入 data 数组（value 保留原样含单位）。\n"
    "5. 严格输出 JSON，不要输出任何解释文字。JSON 结构如下：\n"
    '{"blocks": [{"text": "...", "relation": "parallel", "data": [{"value": "3200万"}]}]}'
)


def is_available() -> bool:
    """判断 LLM 后端是否可用（关键环境变量齐备）。"""
    return bool(os.environ.get("PPT_LLM_API_BASE") and os.environ.get("PPT_LLM_API_KEY"))


def _call_llm(source_text: str) -> list[dict]:
    base = os.environ["PPT_LLM_API_BASE"].rstrip("/")
    key = os.environ["PPT_LLM_API_KEY"]
    model = os.environ.get("PPT_LLM_MODEL", "gpt-4o-mini")

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": source_text},
        ],
        "temperature": 0.2,
        "response_format": {"type": "json_object"},
    }
    req = urllib.request.Request(
        f"{base}/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        body = json.loads(resp.read().decode("utf-8"))
    content = body["choices"][0]["message"]["content"]
    data = json.loads(content)
    return data.get("blocks", [])


def _normalize(blocks: list[dict]) -> list[dict]:
    """把 LLM 输出规范化为 Content Graph 的 block 结构（容错）。"""
    out = []
    valid_rel = set(C.REL_PARALLEL) | set(["parallel", "sequence", "causal",
                                            "contrast", "hierarchy", "timeline"])
    for b in blocks:
        text = str(b.get("text", "")).strip()
        if not text:
            continue
        rel = b.get("relation", C.REL_PARALLEL)
        if rel not in C.REL_PARALLEL:
            rel = C.REL_PARALLEL
        data = b.get("data") or []
        if not isinstance(data, list):
            data = []
        out.append({"text": text, "relation": rel, "data": data})
    return out


def distill(source_text: str) -> list[dict]:
    """调用 LLM 提炼，返回规范化 block 列表。异常时向上抛出，由 m02 捕获回退。"""
    raw = _call_llm(source_text)
    return _normalize(raw)
