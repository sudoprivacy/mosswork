"""模块③ 大纲与叙事结构生成层 (Outline & Narrative)

职责：逻辑先于视觉，产出整套 PPT 的骨架（页数 + Action Title + 要点）。
输入：Requirement Spec + Content Graph。
输出：Slide Outline（每页的 title / layout / points / relation）。

叙事框架（按场景套用）：
- pitch：Problem→Solution→Product→Market→BusinessModel→Traction→Competition→Team→Financials→Ask
- product_launch：Hook→Problem→Solution→Demo→Value→Market→Roadmap→CTA
- biz_report：Overview→Highlights→Drivers→Issues→Plan→Targets
- training：Intro→Concept→Example→Practice→Summary
- conference：Hook→Context→Insight1..N→Takeaway
"""

from __future__ import annotations

import re

from . import contracts as C
from . import content_gen

# 场景 → 叙事骨架（每项是 (layout, 默认标题)）
NARRATIVES = {
    C.SCENE_PITCH: [
        ("cover", "项目标题"), ("content", "我们解决的问题"), ("content", "我们的解决方案"),
        ("content", "产品是什么"), ("chart", "市场规模与机会"), ("content", "商业模式"),
        ("timeline", "业务进展与里程碑"), ("two_column", "竞争格局"), ("content", "团队"),
        ("chart", "财务预测"), ("summary", "本轮融资需求"),
    ],
    C.SCENE_PRODUCT_LAUNCH: [
        ("cover", "产品标题"), ("quote", "开场钩子"), ("content", "痛点"), ("content", "解决方案"),
        ("content", "产品演示"), ("content", "核心价值"), ("chart", "市场机会"),
        ("timeline", "路线图"), ("summary", "行动号召"),
    ],
    C.SCENE_BIZ_REPORT: [
        ("cover", "汇报标题"), ("agenda", "目录"), ("summary", "核心结论"),
        ("chart", "关键业绩"), ("content", "增长驱动"), ("content", "问题与挑战"),
        ("content", "下阶段计划"), ("summary", "目标与展望"),
    ],
    C.SCENE_TRAINING: [
        ("cover", "课程标题"), ("agenda", "课程目录"), ("content", "章节一"),
        ("content", "章节二"), ("content", "章节三"), ("content", "章节四"),
        ("content", "章节五"), ("content", "章节六"),
        ("summary", "总结与展望"),
    ],
    C.SCENE_CONFERENCE: [
        ("cover", "演讲标题"), ("quote", "开场"), ("content", "背景"),
        ("content", "洞察一"), ("content", "洞察二"), ("content", "洞察三"),
        ("summary", "核心启示"),
    ],
    C.SCENE_BATCH: [
        ("cover", "标题"), ("content", "要点"), ("summary", "总结"),
    ],
}


def _title_from_block(block: dict, idx: int) -> str:
    text = block["text"].strip()
    text = re.sub(r"[，。；：,.;:]$", "", text)
    if len(text) > 20:
        text = text[:20]
    return text or f"要点 {idx + 1}"


def _extract_cover_title(spec: dict) -> str:
    """从需求文本提取封面主题名（去掉场景/页数/受众等修饰）。"""
    raw = spec.get("raw_request", "")
    # 文档类型词：真正的终止边界（主题本身可含"汇报/路演/培训/课件"等修饰）
    doc_types = ["演示文稿", "幻灯片", "PPT", "ppt", "PowerPoint", "presentation"]
    # 常见结构：『面向XX的YY主题PPT』→ 取 YY
    m = re.search(r"的\s*([^，。；,\s][^，。；,]*?)\s*(?:" + "|".join(doc_types) + r")", raw)
    if m:
        t = m.group(1).strip()
        t = re.sub(r"^(一份|一个|一份关于|关于)\s*", "", t)
        # 去掉尾部冗余的"课件""培训"等（当主题已包含核心词时）
        t = re.sub(r"(课件|培训)\s*$", "", t)
        return t
    # 兜底：截取第一个逗号/句号前的主题片段，去掉动词前缀与文档类型词
    first = re.split(r"[，。；,]", raw)[0].strip()
    first = re.sub(r"^(帮我|请|做一份|生成|制作|我需要|我要|做一个)\s*", "", first)
    first = re.sub(r"(" + "|".join(doc_types) + r").*$", "", first)
    if 2 <= len(first) <= 24:
        return first
    return ""


def run(spec: dict, graph: dict) -> dict:
    scene = spec["scene"]
    skeleton = NARRATIVES.get(scene, NARRATIVES[C.SCENE_BIZ_REPORT])
    page_range = spec["constraints"]["page_range"]
    max_slides = spec["config"]["max_slides"]

    blocks = graph["blocks"]
    # 判定是否为「纯需求、无素材」场景：没有素材文件，且 blocks 里没有真正的内容
    # （此时需求文本本身会被 m02 当成唯一 block，不应作为正文使用）
    no_material = not spec.get("source_paths") and len(blocks) <= 2

    # 分离标题块（章节标题）与正文块
    heading_blocks = [b for b in blocks if b.get("heading_level", 0) >= 2]
    body_blocks = [b for b in blocks if b.get("heading_level", 0) == 0]
    if no_material:
        # 纯需求场景：忽略需求文本伪 block，全部交给内容生成器
        heading_blocks = []
        body_blocks = []

    cover_title = _extract_cover_title(spec)

    slides = []

    # 1. 铺叙事骨架
    for layout, default_title in skeleton:
        title = default_title
        # 封面标题用需求主题名填充
        if layout == "cover" and cover_title:
            title = cover_title
        slides.append({
            "title": title,
            "layout": layout,
            "points": [],
            "relation": C.REL_PARALLEL,
            "chart": None,
            "source_block": None,
        })

    # 2. 若素材有明确章节标题（## 级），用章节标题替换 content 骨架标题，并按 section 分组分配正文
    if heading_blocks:
        # 章节标题块（## 级）按出现顺序
        sections = [b["text"] for b in heading_blocks if b.get("heading_level") == 2]
        content_slots = [i for i, s in enumerate(slides) if s["layout"] == "content"]
        # 用章节标题填充前 N 个 content 槽位
        for hi, sec in enumerate(sections):
            if hi >= len(content_slots):
                break
            slides[content_slots[hi]]["title"] = _title_from_block({"text": sec}, hi)
        # 按 section 分组正文
        sec2slot = {sec: content_slots[hi] for hi, sec in enumerate(sections)
                    if hi < len(content_slots)}
        for b in body_blocks:
            sec = b.get("section", "")
            if sec in sec2slot:
                idx = sec2slot[sec]
                if len(slides[idx]["points"]) < 5:
                    slides[idx]["points"].append(b["text"])
                    slides[idx]["relation"] = b["relation"]
        # 无章节归属的正文，落到剩余 content 槽位
        unassigned = [b for b in body_blocks if b.get("section", "") not in sec2slot]
        fallback_slots = [i for i in content_slots if not slides[i]["points"]]
        fi = 0
        for b in unassigned:
            if fi >= len(fallback_slots):
                break
            while (len(slides[fallback_slots[fi]]["points"]) >= 5
                   and fi < len(fallback_slots) - 1):
                fi += 1
            slides[fallback_slots[fi]]["points"].append(b["text"])
            if slides[fallback_slots[fi]]["title"] in ("章节一", "章节二", "章节三", "章节四", "章节五", "章节六", "要点", "内容页", "核心概念", "示例演示", "背景与目标", "实操练习"):
                slides[fallback_slots[fi]]["title"] = _title_from_block(b, 0)
            fi += 1

    # 3. 剩余正文块（无章节标题时）分配到 content 类页面（贪心，每页 ≤5 要点）
    if not heading_blocks:
        content_slots = [i for i, s in enumerate(slides) if s["layout"] in ("content", "summary")]
        slot_i = 0
        for b in body_blocks:
            if slot_i >= len(content_slots):
                break
            while (len(slides[content_slots[slot_i]]["points"]) >= 5
                   and slot_i < len(content_slots) - 1):
                slot_i += 1
            idx = content_slots[slot_i]
            slides[idx]["points"].append(b["text"])
            if slides[idx]["title"] in ("要点", "内容页", "核心概念", "示例演示", "背景与目标", "实操练习") or \
               slides[idx]["title"] in [s[1] for s in skeleton if s[0] == "content"][:2]:
                slides[idx]["title"] = _title_from_block(b, len(slides[idx]["points"]) - 1)
            slides[idx]["relation"] = b["relation"]

    # 4. 清理空的占位章节页（有章节标题素材时，多余的空 content 槽位移除）
    if heading_blocks:
        placeholder_titles = {"章节一", "章节二", "章节三", "章节四", "章节五", "章节六",
                              "要点", "内容页", "背景与目标", "核心概念", "示例演示", "实操练习"}
        slides = [s for s in slides
                  if not (s["layout"] == "content" and not s["points"]
                          and s["title"] in placeholder_titles)]

    # 4.5 内容兜底：对仍然无要点的内容/特殊版式页，用内容生成器自动填充
    if no_material or content_gen.is_content_gap(blocks):
        fillable_layouts = ("content", "summary", "chart", "timeline",
                            "two_column", "quote")
        for s in slides:
            if s["layout"] in fillable_layouts and not s["points"]:
                gen = content_gen.generate_points(spec, s["title"])
                if gen:
                    s["points"] = gen
                    s["relation"] = C.REL_PARALLEL

    # 5. 数据块 → 图表页
    if graph["data_count"] >= 3:
        for i, s in enumerate(slides):
            if s["layout"] == "chart" and s["chart"] is None:
                vals = [d["value"] for d in graph["data_points"][:6]]
                labels = [f"项{i+1}" for i in range(len(vals))]
                s["chart"] = {"type": "bar", "categories": labels,
                              "series": [{"name": "数据", "values": vals}]}
                break

    # 5. 套用页数约束
    if len(slides) > max_slides:
        slides = slides[:max_slides]
    if page_range:
        low, high = page_range
        target = min(high, max(low, len(slides)))
        target = min(target, max_slides)
        slides = slides[:target]

    # 6. 追加封底
    if len(slides) < max_slides:
        slides.append({"title": "谢谢", "layout": "contact", "points": [], "relation": C.REL_PARALLEL,
                       "chart": None, "source_block": None})

    outline = {
        "module": "m03",
        "scene": scene,
        "slide_count": len(slides),
        "slides": slides,
        "narrative": [s[0] for s in skeleton],
        "exceeds_max": len(slides) > max_slides,
    }
    return outline
