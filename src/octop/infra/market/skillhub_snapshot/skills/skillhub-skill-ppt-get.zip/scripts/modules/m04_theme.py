"""模块④ 版式与配色设计 (Layout & Theme)

职责：确定整套 PPT 的视觉 token（配色 + 字体 + 版式映射 + 风格）。
输入：Requirement Spec + Slide Outline。
输出：Theme Token（配色方案 + 字体规范 + 风格 + 每页版式确认）。

判断逻辑（优先级从高到低）：
1. 用户显式指定 style（风格库命中）→ 用该风格的 theme + 覆盖色。
2. 有 brand_color → 注入为主色。
3. style_hint（简洁/高端）→ 直接指定主题。
4. 否则按场景 → 主题映射表匹配。
"""

from __future__ import annotations

from . import contracts as C


def _match_style(request_text: str) -> str | None:
    """根据关键词匹配风格库，返回 style key 或 None。

    匹配策略：统计每个风格命中的关键词数量，命中最多者胜出；
    数量相同时取关键词更精确（长度更长）的风格，避免"卡通"被 mbe 抢先匹配。
    """
    low = request_text.lower()
    best_key = None
    best_score = (0, 0)  # (命中数, 关键词总长度)
    for key, st in C.STYLES.items():
        hits = [k for k in st["keywords"] if k in low]
        if hits:
            score = (len(hits), sum(len(k) for k in hits))
            if score > best_score:
                best_score = score
                best_key = key
    return best_key


def _pick_theme(spec: dict) -> str:
    hint = spec["constraints"].get("style_hint")
    if hint == "minimal":
        return "minimal_gray"
    if hint == "tech":
        return "tech_dark"
    scene = spec["scene"]
    for key, theme in C.THEMES.items():
        if scene in theme["fit"]:
            return key
    return "business_blue"


def run(spec: dict, outline: dict) -> dict:
    # 1. 风格库匹配（最高优先级）
    style_key = spec["constraints"].get("style") or _match_style(spec.get("raw_request", ""))
    style = C.STYLES.get(style_key) if style_key else None

    if style:
        theme_key = style["theme"]
        theme = dict(C.THEMES[theme_key])
        # 风格覆盖色
        if style.get("primary_override"):
            theme["primary"] = style["primary_override"]
        if style.get("accent_override"):
            theme["accent"] = style["accent_override"]
    else:
        theme_key = _pick_theme(spec)
        theme = dict(C.THEMES[theme_key])

    # 2. 品牌色注入
    brand = spec["constraints"].get("brand_color")
    if brand:
        theme["primary"] = brand.lstrip("#")

    # 3. 字体规范：按风格/场景选字体
    font_key = spec["constraints"].get("font_style", "business")
    fonts = C.FONT_STYLES.get(font_key, C.FONT_STYLES["business"])
    theme["font_title"] = fonts["title"]
    theme["font_body"] = fonts["body"]

    token = {
        "module": "m04",
        "theme_key": theme_key,
        "theme": theme,
        "style": style_key,
        "style_label": style["name"] if style else None,
        "font_style": font_key,
        "font_title": fonts["title"],
        "font_body": fonts["body"],
        "aspect": spec["config"]["aspect"],
        "page_numbers": spec["config"]["page_numbers"],
        "footer": spec["config"]["footer"],
        "typography": C.TYPOGRAPHY,
        "layout_map": {s["layout"]: C.LAYOUTS.get(s["layout"], s["layout"])
                       for s in outline["slides"]},
    }
    return token
