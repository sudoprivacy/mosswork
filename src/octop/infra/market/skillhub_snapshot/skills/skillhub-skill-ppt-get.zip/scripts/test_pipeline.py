"""PPT 制作专家 · 单元测试回归脚本（固化验收门禁）。

用 Python 内置 unittest 覆盖八模块与编排器关键行为，无需 pytest。
运行：python3 scripts/test_pipeline.py

覆盖点：
- 模块① 场景/受众识别、缺口探测
- 模块② 双引擎切换与回退
- 模块③ 大纲生成与 max_slides 收敛
- 模块④ 主题选择与品牌色注入
- 模块⑤ 图表数据映射与柱状图排序
- 模块⑦ 质检门禁（P0 阻断 / P1 提示）
- 编排器 回写闭环 + 导出可编辑性
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules import contracts as C
from modules import (m01_understand, m02_distill, m03_outline,
                     m04_theme, m05_compose, m06_bind, m07_review)
from modules import llm_distill
from modules import gates


class TestM01Understand(unittest.TestCase):
    def test_scene_pitch(self):
        spec = m01_understand.run("融资路演，12页，目标投资人")
        self.assertEqual(spec["scene"], C.SCENE_PITCH)
        self.assertEqual(spec["audience"], "investor")

    def test_scene_training(self):
        spec = m01_understand.run("新员工培训课件")
        self.assertEqual(spec["scene"], C.SCENE_TRAINING)

    def test_scene_biz_report(self):
        spec = m01_understand.run("季度商业汇报")
        self.assertEqual(spec["scene"], C.SCENE_BIZ_REPORT)

    def test_page_range_extraction(self):
        spec = m01_understand.run("做一份10-12页的汇报PPT，给CEO看")
        self.assertEqual(spec["constraints"]["page_range"], (10, 12))

    def test_brand_color_extraction(self):
        spec = m01_understand.run("用 #1F4E79 作为主色，做汇报")
        self.assertEqual(spec["constraints"]["brand_color"], "#1F4E79")

    def test_pending_clarify(self):
        # 无场景/受众/页数信息 → 应探测到缺口
        spec = m01_understand.run("帮我做个东西")
        self.assertFalse(spec["complete"])
        self.assertTrue(len(spec["pending_clarify"]) > 0)


class TestM02Distill(unittest.TestCase):
    def setUp(self):
        os.environ.pop("PPT_LLM_API_BASE", None)
        os.environ.pop("PPT_LLM_API_KEY", None)

    def _spec(self, engine="auto"):
        return m01_understand.run("季度汇报", config={"distill_engine": engine})

    def test_regex_engine(self):
        g = m02_distill.run(self._spec("regex"), "营收3200万，同比增长32%。但是成本上涨15%。")
        self.assertEqual(g["engine"], "regex")
        self.assertFalse(g["fallback"])
        self.assertGreater(g["block_count"], 0)

    def test_data_extraction(self):
        g = m02_distill.run(self._spec("regex"), "营收3200万，同比增长32%。")
        self.assertGreaterEqual(g["data_count"], 2)

    def test_auto_without_env_falls_to_regex(self):
        self.assertFalse(llm_distill.is_available())
        g = m02_distill.run(self._spec("auto"), "营收3200万。")
        self.assertEqual(g["engine"], "regex")

    def test_llm_unreachable_falls_back(self):
        os.environ["PPT_LLM_API_BASE"] = "http://127.0.0.1:1/v1"
        os.environ["PPT_LLM_API_KEY"] = "fake"
        g = m02_distill.run(self._spec("llm"), "营收3200万，同比增长32%。")
        self.assertTrue(g["fallback"])
        self.assertEqual(g["engine"], "regex")
        self.assertIn("fallback_reason", g)

    def test_markdown_noise_stripped(self):
        g = m02_distill.run(self._spec("regex"), "## 增长驱动\n新签客户186家。")
        texts = [b["text"] for b in g["blocks"]]
        self.assertTrue(all(not t.startswith("#") for t in texts))
        self.assertTrue(any("增长驱动" in t for t in texts))

    def test_web_engine_no_gap_returns_regex(self):
        # 未开 PPT_WEB_SEARCH，且 auto 无 LLM → regex
        os.environ.pop("PPT_WEB_SEARCH", None)
        g = m02_distill.run(self._spec("auto"), "营收3200万，同比增长32%。")
        self.assertEqual(g["engine"], "regex")


class TestM03Outline(unittest.TestCase):
    def _spec(self, **cfg):
        return m01_understand.run("融资路演", config=cfg)

    def test_outline_has_cover_and_contact(self):
        g = m02_distill.run(self._spec(), "问题 方案 产品 市场")
        outline = m03_outline.run(self._spec(), g)
        layouts = [s["layout"] for s in outline["slides"]]
        self.assertIn("cover", layouts)
        self.assertIn("contact", layouts)

    def test_max_slides_enforced(self):
        g = m02_distill.run(self._spec(), "a b c d e f g h")
        outline = m03_outline.run(self._spec(max_slides=3), g)
        self.assertLessEqual(outline["slide_count"], 3)
        self.assertFalse(outline["exceeds_max"])

    def test_heading_sections_map_to_chapter_titles(self):
        """素材的 ## 章节标题应映射为章节页标题，正文按章节分组。"""
        spec = m01_understand.run("面向企业员工的AI基础培训课件PPT")
        src = "## AI 是什么\n人工智能是让计算机模拟人类智能。\n## 核心概念\n机器学习是让计算机从数据中总结规律。\n深度学习是机器学习进阶版。"
        g = m02_distill.run(spec, src)
        outline = m03_outline.run(spec, g)
        titles = [s["title"] for s in outline["slides"]]
        self.assertIn("AI 是什么", titles)
        self.assertIn("核心概念", titles)
        # 无残留"章节六"类占位符
        self.assertFalse(any(t.startswith("章节") for t in titles))

    def test_cover_title_extracted(self):
        """封面标题应从需求提取，而非占位符。"""
        spec = m01_understand.run("面向企业员工的AI基础培训课件PPT")
        g = m02_distill.run(spec, "人工智能")
        outline = m03_outline.run(spec, g)
        cover = outline["slides"][0]
        self.assertEqual(cover["layout"], "cover")
        self.assertNotEqual(cover["title"], "课程标题")
        self.assertIn("AI", cover["title"])

    def test_no_material_auto_generates_content(self):
        """无素材（只给一句话需求）时，每个内容页都应有自动生成的内容。"""
        spec = m01_understand.run("做一个季度商业汇报PPT，10页，给CEO看")
        g = m02_distill.run(spec, "做一个季度商业汇报PPT，10页，给CEO看")
        outline = m03_outline.run(spec, g)
        # 排除封面/目录/封底，其余页必须有要点
        for s in outline["slides"]:
            if s["layout"] in ("cover", "agenda", "contact"):
                continue
            self.assertTrue(len(s.get("points", [])) > 0,
                            f"页「{s['title']}」无内容")
        # 标题不应是需求原文（需求文本不应被当成章节标题）
        titles = [s["title"] for s in outline["slides"]]
        self.assertFalse(any("10页" in t or "给CEO" in t for t in titles))

    def test_no_material_pitch_every_page_filled(self):
        """融资路演场景无素材时，chart/timeline/two_column 等特殊版式也要有内容。"""
        spec = m01_understand.run("融资路演PPT，12页，目标投资人")
        g = m02_distill.run(spec, "融资路演PPT，12页，目标投资人")
        outline = m03_outline.run(spec, g)
        for s in outline["slides"]:
            if s["layout"] in ("cover", "contact"):
                continue
            self.assertTrue(len(s.get("points", [])) > 0,
                            f"页「{s['title']}」({s['layout']}) 无内容")


class TestM04Theme(unittest.TestCase):
    def _spec(self, text="季度商业汇报", **cfg):
        return m01_understand.run(text, config=cfg)

    def test_biz_report_picks_blue(self):
        g = m02_distill.run(self._spec(), "营收")
        outline = m03_outline.run(self._spec(), g)
        token = m04_theme.run(self._spec(), outline)
        self.assertEqual(token["theme_key"], "business_blue")

    def test_brand_color_injected(self):
        spec = m01_understand.run("用 #123456 做汇报")
        g = m02_distill.run(spec, "营收")
        outline = m03_outline.run(spec, g)
        token = m04_theme.run(spec, outline)
        self.assertEqual(token["theme"]["primary"], "123456")

    def test_minimal_hint(self):
        spec = m01_understand.run("做一份简洁风格的汇报")
        g = m02_distill.run(spec, "营收")
        outline = m03_outline.run(spec, g)
        token = m04_theme.run(spec, outline)
        self.assertEqual(token["theme_key"], "minimal_gray")

    def test_style_keyword_match(self):
        # 复古卡通关键词命中风格库
        spec = m01_understand.run("做一个复古卡通风格的猫咪主题PPT")
        g = m02_distill.run(spec, "猫咪")
        outline = m03_outline.run(spec, g)
        token = m04_theme.run(spec, outline)
        self.assertIsNotNone(token["style"])
        self.assertEqual(token["style"], "retro-cartoon")

    def test_mbe_style_match(self):
        spec = m01_understand.run("校园新生MBE插画风格PPT")
        g = m02_distill.run(spec, "开学")
        outline = m03_outline.run(spec, g)
        token = m04_theme.run(spec, outline)
        self.assertEqual(token["style"], "mbe")

    def test_theme_count_expanded(self):
        # 配色方案应从 5 套扩充到 17 套
        self.assertGreaterEqual(len(C.THEMES), 17)
        self.assertIn("midnight-executive", C.THEMES)
        self.assertIn("matcha-japanese", C.THEMES)


class TestM05Compose(unittest.TestCase):
    def test_bar_chart_sorted_desc(self):
        spec = m01_understand.run("季度汇报")
        g = m02_distill.run(spec, "营收")
        outline = m03_outline.run(spec, g)
        token = m04_theme.run(spec, outline)
        # 手动构造一个带图表的 outline
        outline["slides"] = [{
            "title": "数据", "layout": "chart", "points": [],
            "relation": "parallel",
            "chart": {"type": "bar", "categories": ["A", "B", "C"],
                      "series": [{"name": "s", "values": [1, 5, 3]}]},
        }]
        vs = m05_compose.run(spec, outline, token)
        chart = vs["visuals"][0]["chart"]
        self.assertEqual(chart["series"][0]["values"], [5, 3, 1])


class TestM07Review(unittest.TestCase):
    def _pipeline(self, **cfg):
        spec = m01_understand.run("季度汇报", config=cfg)
        g = m02_distill.run(spec, "营收3200万，同比增长32%。")
        outline = m03_outline.run(spec, g)
        token = m04_theme.run(spec, outline)
        visuals = m05_compose.run(spec, outline, token)
        binding = m06_bind.run(spec, visuals, token)
        return spec, outline, token, binding

    def test_pass_when_clean(self):
        spec, outline, token, binding = self._pipeline()
        qa = m07_review.run(spec, binding, outline, token)
        self.assertTrue(qa["pass"])
        self.assertEqual(qa["p0_count"], 0)

    def test_overflow_triggers_p0(self):
        spec, outline, token, binding = self._pipeline()
        binding["slides"][1]["points"] = ["x"] * 8  # 超载
        qa = m07_review.run(spec, binding, outline, token)
        self.assertGreaterEqual(qa["p0_count"], 1)
        self.assertTrue(qa["blocked"])

    def test_no_cover_triggers_p0(self):
        spec, outline, token, binding = self._pipeline()
        binding["slides"] = [s for s in binding["slides"] if s["layout"] != "cover"]
        qa = m07_review.run(spec, binding, outline, token)
        self.assertTrue(qa["blocked"])


class TestGates(unittest.TestCase):
    """三个判断分支点（J1 / J2 / J3）。"""

    def test_j1_detect_gaps_when_vague(self):
        """信息不足时 J1 应探测到缺口（场景/受众/篇幅/数据）。"""
        spec = m01_understand.run("帮我做个东西")
        gaps = gates.detect_gaps(spec, graph=None)
        fields = {g["field"] for g in gaps}
        self.assertIn("scene", fields)
        self.assertIn("audience", fields)
        self.assertIn("page_range", fields)
        self.assertIn("data", fields)

    def test_j1_no_gaps_when_fully_specified(self):
        """信息齐备时 J1 不应有缺口（数据维度在 m02 后判）。"""
        spec = m01_understand.run("融资路演，12页，目标投资人，带素材")
        spec["source_paths"] = ["x.txt"]
        gaps = gates.detect_gaps(spec, graph={"data_count": 5})
        self.assertEqual(len(gaps), 0)

    def test_j1_auto_fill_records_assumptions(self):
        """J1 无交互补全应写入 assumptions，并标注来源=用户信息不足。"""
        spec = m01_understand.run("帮我做个东西")
        gaps = gates.detect_gaps(spec, graph=None)
        spec = gates.auto_fill_assumptions(spec, gaps)
        self.assertTrue(spec["complete"])
        self.assertGreater(len(spec["assumptions"]), 0)
        for a in spec["assumptions"]:
            self.assertIn("用户信息不足", a["source"])
            self.assertTrue(a["encourage"])
        # 场景/受众/篇幅已回填默认值
        self.assertIsNotNone(spec["constraints"]["page_range"])

    def test_j2_complete_when_all_filled(self):
        """大纲完整（有封面/总结、内容页均有要点）时 J2 通过。"""
        outline = {"slides": [
            {"index": 0, "layout": "cover", "title": "封面", "points": ["副标题"]},
            {"index": 1, "layout": "content", "title": "正文", "points": ["要点1", "要点2"]},
            {"index": 2, "layout": "summary", "title": "总结", "points": ["结论"]},
        ]}
        j2 = gates.check_content_completeness(outline)
        self.assertTrue(j2["complete"])
        self.assertEqual(j2["gap_count"], 0)

    def test_j2_detects_empty_content_page(self):
        """大纲存在空内容页时 J2 应报缺口。"""
        outline = {"slides": [
            {"index": 0, "layout": "cover", "title": "封面", "points": []},
            {"index": 1, "layout": "content", "title": "空页", "points": []},
            {"index": 2, "layout": "summary", "title": "总结", "points": []},
        ]}
        j2 = gates.check_content_completeness(outline)
        self.assertFalse(j2["complete"])
        self.assertTrue(any(g["reason"] == "内容页无正文要点" for g in j2["gaps"]))

    def test_j3_route_structure_vs_visual(self):
        """J3 应根据 P0 问题类型路由到正确的回写方向。"""
        qa_structure = {"issues": [{"level": C.QA_P0, "type": "overflow", "msg": ""}]}
        self.assertEqual(gates.route_qafix(qa_structure)["direction"], "structure")

        qa_visual = {"issues": [{"level": C.QA_P0, "type": "no_theme", "msg": ""}]}
        self.assertEqual(gates.route_qafix(qa_visual)["direction"], "visual")

        qa_clean = {"issues": []}
        self.assertEqual(gates.route_qafix(qa_clean)["direction"], "none")

    def test_j3_both_when_mixed(self):
        """结构 + 视觉问题同时存在时 J3 应回写 both。"""
        qa = {"issues": [
            {"level": C.QA_P0, "type": "overflow", "msg": ""},
            {"level": C.QA_P0, "type": "no_theme", "msg": ""},
        ]}
        self.assertEqual(gates.route_qafix(qa)["direction"], "both")


class TestPipelineEndToEnd(unittest.TestCase):
    def test_full_run_exports_editable_pptx(self):
        import run as R
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "out.pptx")
            result = R.run_pipeline(
                "季度商业汇报，10-12页，给CEO", None, out, tmp,
                None, no_pause=True)
            self.assertFalse(result.get("blocked"))
            self.assertTrue(os.path.exists(out))
            from pptx import Presentation
            prs = Presentation(out)
            self.assertGreater(len(prs.slides), 0)
            # 封面可编辑文字存在
            first = prs.slides[0]
            texts = [sh.text_frame.text for sh in first.shapes
                     if sh.has_text_frame and sh.text_frame.text.strip()]
            self.assertTrue(texts)

    def test_vague_request_auto_fills_assumptions(self):
        """信息不足的请求应自动补充并标注 assumptions（不阻塞）。"""
        import run as R
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "out.pptx")
            result = R.run_pipeline(
                "帮我做个东西", None, out, tmp,
                None, no_pause=True)
            self.assertFalse(result.get("blocked"))
            # 结果应带 assumptions（来源=用户信息不足）
            self.assertIn("assumptions", result)
            self.assertGreater(len(result["assumptions"]), 0)
            # manifest 也应记录 assumptions
            manifest_path = result.get("manifest_path")
            self.assertTrue(os.path.exists(manifest_path))
            with open(manifest_path, "r", encoding="utf-8") as f:
                manifest = json.load(f)
            self.assertIn("assumptions", manifest)

    def test_blocking_when_p0_irreparable(self):
        # max_slides 极小但已收敛后仍可能触发其它 P0 的场景，验证阻断不会崩溃
        import run as R
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "out.pptx")
            result = R.run_pipeline(
                "融资路演", None, out, tmp,
                {"max_slides": 3}, no_pause=True)
            # 结果应正常（3页收敛）或阻断，但不会抛异常
            self.assertIn("qa", result)

    def test_big_number_and_matrix_render(self):
        # 直接验证 m08 的新版式函数不抛异常
        from modules import m08_export
        import pptx
        with tempfile.TemporaryDirectory() as tmp:
            prs = pptx.Presentation()
            prs.slide_width = 12192000
            prs.slide_height = 6858000
            theme = {"primary": "1E2761", "secondary": "CADCFC", "accent": "FFFFFF",
                     "text": "1E2761", "text_light": "6B7280", "neutral": "F5F7FA"}
            m08_export._add_big_number(prs, {
                "title": "关键数据", "points": [], "numbers": [("85%", "增长"), ("3.2倍", "效率"), ("200+", "客户")]}, theme)
            m08_export._add_matrix(prs, {
                "title": "SWOT", "points": [],
                "matrix": [{"label": "S 优势", "desc": "技术领先"}, {"label": "W 劣势", "desc": "成本高"},
                           {"label": "O 机会", "desc": "市场大"}, {"label": "T 威胁", "desc": "竞争"}]}, theme)
            self.assertEqual(len(prs.slides), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
