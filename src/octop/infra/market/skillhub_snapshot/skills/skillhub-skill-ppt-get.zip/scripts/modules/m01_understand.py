"""模块① 输入与需求理解层 (Input & Requirement Understanding)

职责：把用户意图 + 素材转化为可执行的 Requirement Spec。
输入：原始 user_request(str) + 可选素材素材路径列表 + 已有配置覆盖。
输出：Requirement Spec（dict），含场景/受众/风格/篇幅/硬约束/待澄清项。

判断逻辑：
- 场景识别：关键词匹配 → 若无法确定则归为 business_report 并置入 pending。
- 缺口探测：场景/受众/篇幅任一缺失 → 写入 pending_clarify，供编排器暂停提问。
"""

from __future__ import annotations

from . import contracts as C
from . import gates


def _detect_scene(text: str) -> str:
    t = text.lower()
    if any(k in t for k in ["融资", "路演", "pitch", "投资人", "b轮", "a轮", "vc"]):
        return C.SCENE_PITCH
    if any(k in t for k in ["培训", "课件", "教学", "新人", "教程", "tutorial"]):
        return C.SCENE_TRAINING
    if any(k in t for k in ["发布", "launch", "新品", "上市"]):
        return C.SCENE_PRODUCT_LAUNCH
    if any(k in t for k in ["大会", "演讲", "主题演讲", "keynote", "峰会"]):
        return C.SCENE_CONFERENCE
    if any(k in t for k in ["批量", "模板", "套用", "批量生成"]):
        return C.SCENE_BATCH
    return C.SCENE_BIZ_REPORT


def _detect_audience(text: str) -> str:
    t = text.lower()
    if any(k in t for k in ["投资人", "融资", "vc", "基金"]):
        return "investor"
    if any(k in t for k in ["ceo", "老板", "高管", "领导", "董事会"]):
        return "ceo"
    if any(k in t for k in ["客户", "甲方", "用户", "演示"]):
        return "client"
    if any(k in t for k in ["员工", "新人", "培训", "团队", "内部"]):
        return "staff"
    return "public"


def _extract_constraints(text: str) -> dict:
    c = {
        "page_range": None,
        "brand_color": None,
        "must_sections": [],
        "style_hint": None,
    }
    import re
    m = re.search(r"(\d+)\s*[-~到至]\s*(\d+)\s*页", text)
    if m:
        c["page_range"] = (int(m.group(1)), int(m.group(2)))
    else:
        m = re.search(r"(\d+)\s*页", text)
        if m:
            c["page_range"] = (int(m.group(1)), int(m.group(1)))
    m = re.search(r"#[0-9A-Fa-f]{6}", text)
    if m:
        c["brand_color"] = m.group(0)
    for s in ["目录", "总结", "团队", "财务", "时间线", "附录"]:
        if s in text:
            c["must_sections"].append(s)
    if "简洁" in text or "极简" in text:
        c["style_hint"] = "minimal"
    elif "高端" in text or "科技" in text:
        c["style_hint"] = "tech"
    # 显式风格指定：命中风格库关键词（按命中数+关键词长度选最精确者，与 m04 保持一致）
    low = text.lower()
    best_key = None
    best_score = (0, 0)
    for key, st in C.STYLES.items():
        hits = [k for k in st["keywords"] if k in low]
        if hits:
            score = (len(hits), sum(len(k) for k in hits))
            if score > best_score:
                best_score = score
                best_key = key
    if best_key:
        c["style"] = best_key
    return c


def run(user_request: str, config: dict | None = None,
        source_paths: list[str] | None = None) -> dict:
    cfg = dict(C.DEFAULT_CONFIG)
    if config:
        cfg.update(config)

    scene = _detect_scene(user_request)
    audience = _detect_audience(user_request)
    constraints = _extract_constraints(user_request)

    pending = []
    if scene == C.SCENE_BIZ_REPORT and "汇报" not in user_request and "报告" not in user_request:
        pending.append({"field": "scene", "question": "这份 PPT 的主要用途是什么？（商业汇报/产品发布/融资路演/培训/演讲）"})
    if audience == "public" and not any(k in user_request for k in ["通用", "公众", "大众"]):
        pending.append({"field": "audience", "question": "目标读者是谁？（CEO/客户/员工/投资人/公众）"})
    if not constraints["page_range"]:
        pending.append({"field": "page_range", "question": "期望的页数范围是多少？（例如 10-15 页）"})

    spec = {
        "module": "m01",
        "scene": scene,
        "scene_label": C.SCENES[scene],
        "audience": audience,
        "audience_label": C.AUDIENCES[audience],
        "constraints": constraints,
        "config": cfg,
        "source_paths": source_paths or [],
        "raw_request": user_request,
        "pending_clarify": pending,
        "complete": len(pending) == 0,
        "assumptions": [],   # J1 自动补全项（来源=用户信息不足）
    }
    return spec
