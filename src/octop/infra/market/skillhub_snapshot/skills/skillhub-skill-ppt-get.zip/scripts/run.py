"""PPT 制作专家 · 八模块编排器（入口脚本）。

串联八模块，实现：
- 顺序执行 ①→②→③→④⑤→⑥→⑦→⑧
- 判断点 J1（信息充足性）、J2（内容完整性）、J3（质量门禁）
- 回写闭环：⑦ 不合格 → 修正 → 再质检，最多 max_iterations 次
- 中间产物逐模块落盘（artifacts/），支持断点续跑与追溯

用法：
  python run.py --request "..." [--source xxx.txt] [--out out.pptx] [--no-pause]
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules import contracts as C
from modules import gates
from modules import (m01_understand, m02_distill, m03_outline,
                     m04_theme, m05_compose, m06_bind, m07_review, m08_export)


def _read_source(path: str) -> str:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"素材文件不存在：{path}")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _dump(artifacts_dir: str, name: str, data: dict):
    os.makedirs(artifacts_dir, exist_ok=True)
    p = os.path.join(artifacts_dir, name)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return p


def _ask_clarify(pending: list[dict]) -> dict:
    """判断点 J1：信息不足时向用户澄清（CLI 交互）。"""
    answers = {}
    print("\n[澄清] 以下信息缺失，请补充（直接回车跳过）：")
    for item in pending:
        ans = input(f"  - {item['question']}\n    > ").strip()
        if ans:
            answers[item["field"]] = ans
    return answers


def _apply_clarify(spec: dict, answers: dict) -> dict:
    if "scene" in answers:
        spec["scene"] = answers["scene"]
        spec["scene_label"] = answers["scene"]
    if "audience" in answers:
        spec["audience"] = answers["audience"]
    if "page_range" in answers:
        import re
        m = re.search(r"(\d+)\s*[-~到至]\s*(\d+)", answers["page_range"])
        if m:
            spec["constraints"]["page_range"] = (int(m.group(1)), int(m.group(2)))
    spec["pending_clarify"] = []
    spec["complete"] = True
    return spec


def run_pipeline(request: str, source_path: str | None, out_path: str,
                 out_dir: str, config: dict | None, no_pause: bool = False) -> dict:
    artifacts = os.path.join(out_dir, "artifacts")
    os.makedirs(out_dir, exist_ok=True)

    # ---------- 模块① 输入与需求理解 ----------
    spec = m01_understand.run(request, config=config,
                              source_paths=[source_path] if source_path else [])
    _dump(artifacts, "01_spec.json", spec)

    # ================= 判断点 J1：信息充足性（①→② 之间） =================
    # 探测缺口：场景 / 受众 / 篇幅 / 数据（数据维度需 m02 先粗跑一次判定）
    gaps = gates.detect_gaps(spec, graph=None)
    if gaps and not no_pause:
        # 暂停流程，向用户澄清提问
        answers = _ask_clarify(spec["pending_clarify"] or
                               [{"field": g["field"], "question": g["question"]} for g in gaps])
        if answers:
            spec = _apply_clarify(spec, answers)
            # 澄清后重新探测，仍未满足的缺口自动补全
            gaps = gates.detect_gaps(spec, graph=None)
            if gaps:
                spec = gates.auto_fill_assumptions(spec, gaps)
            _dump(artifacts, "01_spec.json", spec)
    elif gaps:
        # 无法交互（--no-pause）：自动补全默认值并标注
        spec = gates.auto_fill_assumptions(spec, gaps)
        _dump(artifacts, "01_spec.json", spec)

    # ---------- 模块② 内容提炼 ----------
    source_text = request
    if source_path:
        source_text = _read_source(source_path)
    graph = m02_distill.run(spec, source_text)
    _dump(artifacts, "02_content_graph.json", graph)

    # J1 补充：数据维度的缺口需在 m02 之后才能准确判定（是否有数据点）
    data_gaps = gates.detect_gaps(spec, graph=graph)
    if any(g["field"] == "data" for g in data_gaps):
        spec = gates.auto_fill_assumptions(spec, data_gaps)
        _dump(artifacts, "01_spec.json", spec)

    # ---------- 模块③ 大纲结构 ----------
    outline = m03_outline.run(spec, graph)
    _dump(artifacts, "03_outline.json", outline)

    # ================= 判断点 J2：内容完整性（③ 之后） =================
    j2 = gates.check_content_completeness(outline)
    _dump(artifacts, "03_j2_gate.json", j2)
    if not j2["complete"]:
        # 有遗漏：回写②——重新提炼（触发 content_gen 兜底填充空内容页）
        print(f"\n[判断J2] 大纲存在 {j2['gap_count']} 处内容遗漏，回写模块②补全。")
        # 重新生成大纲（m03 内部对无内容页已调用 content_gen 兜底；
        # 这里显式重跑一次，确保 J2 修复后产物一致）
        outline = m03_outline.run(spec, graph)
        _dump(artifacts, "03_outline.json", outline)
        j2 = gates.check_content_completeness(outline)
        _dump(artifacts, "03_j2_gate.json", j2)

    # ---------- 模块④⑤ 版式配色 + 图文图表 ----------
    token = m04_theme.run(spec, outline)
    _dump(artifacts, "04_theme.json", token)
    visuals = m05_compose.run(spec, outline, token)
    _dump(artifacts, "05_visuals.json", visuals)

    # ---------- 模块⑥ 模板适配 ----------
    binding = m06_bind.run(spec, visuals, token)
    _dump(artifacts, "06_binding.json", binding)

    # ================= 判断点 J3 + 模块⑦⑧：质检 + 回写闭环 =================
    max_iter = spec["config"]["max_iterations"]
    final_result = None
    for iteration in range(1, max_iter + 1):
        qa = m07_review.run(spec, binding, outline, token)
        _dump(artifacts, f"07_qa_iter{iteration}.json", qa)

        if qa["pass"]:
            # 判断点 J3 通过 → 导出
            result = m08_export.run(spec, binding, token, qa, out_path, out_dir)
            result["iterations"] = iteration
            result["qa"] = qa
            result["assumptions"] = spec.get("assumptions", [])
            _dump(artifacts, "08_result.json", result)
            final_result = result
            break
        else:
            route = gates.route_qafix(qa)
            print(f"\n[质检] 第 {iteration} 轮未通过：P0={qa['p0_count']}, P1={qa['p1_count']}")
            print(f"       回写方向：{route['direction']}（问题：{', '.join(route['fix_targets']) or '无'}）")
            # 回写：按问题类型定向修复
            if route["direction"] in ("structure", "both"):
                # 回写③重排结构（截断超载、补封面、空图表降级）
                _self_heal(binding, qa, spec)
            if route["direction"] in ("visual", "both"):
                # 回写④⑤重做视觉（重跑版式配色与图文图表）
                token = m04_theme.run(spec, outline)
                visuals = m05_compose.run(spec, outline, token)
                binding = m06_bind.run(spec, visuals, token)
                _dump(artifacts, "04_theme.json", token)
                _dump(artifacts, "05_visuals.json", visuals)
            _dump(artifacts, f"06_binding_iter{iteration}.json", binding)
            if iteration == max_iter:
                print("[质检] 达到最大迭代次数，仍存在 P0，阻断导出。")
                qa["pass"] = False
                final_result = {"module": "m08", "blocked": True, "qa": qa,
                                "iterations": iteration, "output_path": None,
                                "assumptions": spec.get("assumptions", [])}
                break

    return final_result


def _self_heal(binding: dict, qa: dict, spec: dict):
    """简单自纠：针对 P0 做最小修复，供演示回写闭环。"""
    p0_types = {i["type"] for i in qa["issues"] if i["level"] == C.QA_P0}
    for s in binding["slides"]:
        # 溢出：截断到 6 条
        if len(s.get("points", [])) > 6:
            s["points"] = s["points"][:6]
        # 空标题：补默认
        if not s.get("title", "").strip():
            s["title"] = "未命名页"
        # 空图表：移除 chart 标记，退回内容页
        if s.get("chart") and not s["chart"].get("series", [{}])[0].get("values"):
            s["chart"] = None
            s["layout"] = "content"
    # 缺封面：在最前插入
    if "no_cover" in p0_types:
        binding["slides"].insert(0, {"index": -1, "layout": "cover", "title": spec["raw_request"][:20] or "标题",
                                     "points": [], "chart": None, "table": None,
                                     "timeline": None, "quote": None, "relation": "parallel"})
        for i, s in enumerate(binding["slides"]):
            s["index"] = i


def main():
    ap = argparse.ArgumentParser(description="PPT 制作专家 · 八模块编排器")
    ap.add_argument("--request", required=True, help="需求描述文本")
    ap.add_argument("--source", default=None, help="素材文件路径（txt/md）")
    ap.add_argument("--out", default="output.pptx", help="输出 PPTX 路径")
    ap.add_argument("--out-dir", default="build", help="产物目录（含 artifacts）")
    ap.add_argument("--no-pause", action="store_true", help="缺信息时不交互，直接继续")
    ap.add_argument("--max-slides", type=int, default=None, help="最大页数")
    ap.add_argument("--footer", default="", help="页脚文字")
    args = ap.parse_args()

    config = {}
    if args.max_slides:
        config["max_slides"] = args.max_slides
    if args.footer:
        config["footer"] = args.footer

    try:
        result = run_pipeline(args.request, args.source, args.out, args.out_dir,
                              config or None, no_pause=args.no_pause)
    except FileNotFoundError as e:
        print(f"\n错误：{e}")
        print("请确认素材文件路径正确，或去掉 --source 参数。")
        return 1
    if result.get("blocked"):
        print("结果：质检未通过，已阻断导出。")
        print(f"  P0={result['qa']['p0_count']} P1={result['qa']['p1_count']} P2={result['qa']['p2_count']}")
    else:
        print("结果：生成成功")
        print(f"  输出文件：{result['output_path']}")
        print(f"  页数：{result['slide_count']}  迭代轮次：{result['iterations']}")
        print(f"  质检：P0={result['qa']['p0_count']} P1={result['qa']['p1_count']} P2={result['qa']['p2_count']}")
        assumptions = result.get("assumptions", [])
        if assumptions:
            print(f"  自动补充项：{len(assumptions)} 条（来源=用户信息不足）")
            for a in assumptions:
                print(f"    - [{a['label']}] 已采用「{a['adopted']}」→ {a['encourage']}")
        print(f"  备注：{result.get('notes_path')}")
        print(f"  归档：{result.get('manifest_path')}")
    print("=" * 50)


if __name__ == "__main__":
    sys.exit(main())
