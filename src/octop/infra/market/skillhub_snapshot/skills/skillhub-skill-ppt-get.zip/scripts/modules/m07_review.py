"""模块⑦ 审阅、质检与自纠 (Review & QA)

职责：质量闸门。检查排版/内容/一致性，产出 QA Report，驱动回写闭环。
输入：Template Binding + Outline + Theme Token。
输出：QA Report（问题清单 + 严重级别 + 是否阻断导出）。

检查项：
- P0：空标题、内容溢出（点数>6）、图表数据为空、页数超限、配色缺失。
- P1：标题非结论式（过长）、图表类型不当、缺目录/总结页。
- P2：要点冗余、可读性提示。
"""

from __future__ import annotations

from . import contracts as C


def _check_empty_title(slide: dict) -> list[dict]:
    if not slide.get("title") or not slide["title"].strip():
        return [{"level": C.QA_P0, "page": slide["index"], "type": "empty_title",
                 "msg": "标题为空"}]
    return []


def _check_overflow(slide: dict) -> list[dict]:
    pts = slide.get("points", [])
    if len(pts) > 6:
        return [{"level": C.QA_P0, "page": slide["index"], "type": "overflow",
                 "msg": f"要点过多({len(pts)})，超出单页承载，需拆分"}]
    return []


def _check_chart(slide: dict) -> list[dict]:
    if slide.get("chart"):
        ch = slide["chart"]
        vals = ch.get("series", [{}])[0].get("values", [])
        if not vals:
            return [{"level": C.QA_P0, "page": slide["index"], "type": "empty_chart",
                     "msg": "图表无数据"}]
        if ch["type"] == "pie" and len(vals) > 6:
            return [{"level": C.QA_P1, "page": slide["index"], "type": "pie_too_many",
                     "msg": "饼图切片超过 6 个"}]
    return []


def _check_title_style(slide: dict) -> list[dict]:
    t = slide.get("title", "")
    if len(t) > 20:
        return [{"level": C.QA_P1, "page": slide["index"], "type": "title_too_long",
                 "msg": f"标题过长({len(t)}字)，建议改为结论式短句"}]
    return []


def run(spec: dict, binding: dict, outline: dict, token: dict) -> dict:
    issues = []
    for s in binding["slides"]:
        issues += _check_empty_title(s)
        issues += _check_overflow(s)
        issues += _check_chart(s)
        issues += _check_title_style(s)

    # 结构检查
    layouts = [s["layout"] for s in binding["slides"]]
    if "cover" not in layouts:
        issues.append({"level": C.QA_P0, "page": None, "type": "no_cover", "msg": "缺少封面页"})
    if "agenda" not in layouts and spec["scene"] != C.SCENE_PITCH:
        issues.append({"level": C.QA_P1, "page": None, "type": "no_agenda", "msg": "建议增加目录页"})
    if "summary" not in layouts:
        issues.append({"level": C.QA_P1, "page": None, "type": "no_summary", "msg": "建议增加总结页"})

    if outline.get("exceeds_max"):
        issues.append({"level": C.QA_P0, "page": None, "type": "too_many_slides",
                       "msg": "页数超过上限"})

    if not token.get("theme"):
        issues.append({"level": C.QA_P0, "page": None, "type": "no_theme", "msg": "配色缺失"})

    p0 = [i for i in issues if i["level"] == C.QA_P0]
    p1 = [i for i in issues if i["level"] == C.QA_P1]
    p2 = [i for i in issues if i["level"] == C.QA_P2]

    blocked = bool(p0) and spec["config"]["p0_blocking"]
    return {
        "module": "m07",
        "issues": issues,
        "p0_count": len(p0),
        "p1_count": len(p1),
        "p2_count": len(p2),
        "blocked": blocked,
        "pass": not blocked,
    }
