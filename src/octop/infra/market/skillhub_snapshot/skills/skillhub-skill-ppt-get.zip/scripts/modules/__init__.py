"""PPT 制作专家 · 八模块编排引擎。

本包实现八模块调用链的纯函数模块，每模块职责单一、输入输出契约化，
由 orchestrator 统一编排，支持中间产物落盘、质检回写与断点续跑。
"""

__all__ = [
    "m01_understand", "m02_distill", "m03_outline", "m04_theme",
    "m05_compose", "m06_bind", "m07_review", "m08_export",
    "llm_distill", "web_distill",
]
