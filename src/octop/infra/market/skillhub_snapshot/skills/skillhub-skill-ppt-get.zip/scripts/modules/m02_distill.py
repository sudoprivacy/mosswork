"""模块② 内容提炼与语义理解层 (Content Distillation)

职责：把原始素材压榨成可讲故事的干货，识别事实/数据与逻辑关系。
输入：Requirement Spec（模块①输出）+ 素材文本内容。
输出：Content Graph（关键信息块 + 逻辑关系标签）。

三引擎策略：
- web：联网检索补全（内容缺口时主动检索行业数据），再走提炼。整合自 ppt-generator-skill。
- llm：LLM 语义提炼（见 llm_distill.py），去噪/拆分/归类/抽数据更准确。
- regex：离线正则规则（无需网络/密钥，可独立跑通）——默认降级基线。

选择逻辑：distill_engine ∈ {web, llm, regex, auto}。
  auto：有 LLM 用 LLM；否则若开启 web 且内容缺口则先补全；最后正则兜底。
契约不变：所有引擎产出完全相同的 Content Graph schema，下游零影响。
"""

from __future__ import annotations

import re

from . import contracts as C
from . import llm_distill
from . import web_distill


def _extract_data_points(text: str) -> list[dict]:
    points = []
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*(%|％|亿|万|元|个|家|人|倍|名次|排名)?", text):
        val = m.group(1)
        unit = m.group(2) or ""
        points.append({"value": val + unit, "offset": m.start()})
    return points


def _infer_relation(text: str) -> str:
    if any(k in text for k in ["因为", "由于", "导致", "因此", "所以", "从而", "结果"]):
        return C.REL_CAUSAL
    if any(k in text for k in ["但是", "然而", "相比", "对比", "不同", "差异", "vs", "VS"]):
        return C.REL_CONTRAST
    if any(k in text for k in ["首先", "然后", "其次", "接着", "最后", "逐步", "依次"]):
        return C.REL_SEQUENCE
    if any(k in text for k in ["分为", "包括", "包含", "主要", "核心", "包括以下几点", "如下"]):
        return C.REL_HIERARCHY
    if any(k in text for k in ["阶段", "时间线", "里程碑", "年", "季度", "月", "日"]):
        return C.REL_TIMELINE
    return C.REL_PARALLEL


def _split_lines(text: str) -> list[dict]:
    """按行切分，识别 Markdown 标题层级，并让正文块携带所属章节标题。"""
    lines = []
    current_section = ""  # 当前所属的 ## 章节标题
    for raw in text.split("\n"):
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            level = len(m.group(1))
            title = m.group(2).strip()
            if level == 2:
                current_section = title
            elif level == 1:
                current_section = ""  # 一级标题通常是文档标题，不归入章节
            lines.append({"text": title, "heading": level, "section": current_section})
            continue
        # 列表符号、引用符号去掉
        line = re.sub(r"^[-*+]\s+", "", line)
        line = re.sub(r"^>\s*", "", line)
        if len(line) >= 2:
            lines.append({"text": line, "heading": 0, "section": current_section})
    return lines


def _regex_distill(source_text: str) -> list[dict]:
    """离线正则降级引擎：按行切分 + 识别标题层级 + 记录章节归属 + 推断逻辑关系。"""
    lines = _split_lines(source_text)
    blocks = []
    for ln in lines:
        s = ln["text"]
        heading = ln["heading"]
        if heading:  # 标题行：作为独立 block，标记 heading_level
            blocks.append({"text": s, "relation": C.REL_HIERARCHY,
                           "data": [], "heading_level": heading,
                           "section": ln["section"]})
            continue
        # 正文：长句粗拆
        for sub in re.split(r"[。；;]", s):
            sub = sub.strip()
            if len(sub) >= 2:
                blocks.append({"text": sub, "relation": _infer_relation(sub),
                               "data": _extract_data_points(sub),
                               "heading_level": 0, "section": ln["section"]})
    return blocks


def run(spec: dict, source_text: str) -> dict:
    engine = (spec.get("config") or {}).get("distill_engine", "auto")

    # 阶段 0：联网内容补全（web 引擎或 auto 且内容缺口时）
    use_web = engine == "web" or (engine == "auto" and web_distill.is_available())
    web_enriched = False
    if use_web:
        topic = spec.get("raw_request", "")
        enriched = web_distill.enrich(topic, source_text)
        if enriched != source_text:
            source_text = enriched
            web_enriched = True

    use_llm = engine in ("llm", "auto") and llm_distill.is_available()

    blocks = None
    used_engine = "regex"
    fallback = False
    fallback_reason = None
    if use_llm:
        try:
            blocks = llm_distill.distill(source_text)
            used_engine = "llm"
        except Exception as e:  # LLM 失败 → 回退离线
            fallback = True
            fallback_reason = str(e)
            blocks = _regex_distill(source_text)
    if blocks is None:
        blocks = _regex_distill(source_text)

    # 若仅做了联网补全（未走 LLM），标记引擎为 web
    if web_enriched and used_engine == "regex":
        used_engine = "web"

    data_points = [d for b in blocks for d in b["data"]]
    relations = {r: sum(1 for b in blocks if b["relation"] == r)
                 for r in C.REL_PARALLEL if any(b["relation"] == r for b in blocks)}
    graph = {
        "module": "m02",
        "blocks": blocks,
        "block_count": len(blocks),
        "data_points": data_points,
        "data_count": len(data_points),
        "relations": relations,
        "source_length": len(source_text),
        "engine": used_engine,
        "fallback": fallback,
        "web_enriched": web_enriched,
    }
    if fallback_reason:
        graph["fallback_reason"] = fallback_reason
    return graph
