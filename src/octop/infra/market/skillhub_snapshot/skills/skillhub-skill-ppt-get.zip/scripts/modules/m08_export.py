"""模块⑧ 导出与交付层 (Export & Delivery)

职责：把 Template Binding 渲染为可编辑 .pptx，生成演讲者备注，写版本归档。
输入：Template Binding + Theme Token + QA Report + 输出路径。
输出：最终 .pptx 文件 + 备注 + 版本 manifest。

依赖 python-pptx。所有文字用真实文本框（可编辑），图表用原生 Chart 对象。
"""

from __future__ import annotations

import datetime
import json
import os

from . import contracts as C


def _emu(inches: float) -> int:
    from pptx.util import Inches
    return Inches(inches)


def _rgb(hex_color: str):
    from pptx.dml.color import RGBColor
    hex_color = hex_color.lstrip("#")
    return RGBColor(int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16))


def _add_cover(prs, slide, theme):
    from pptx.util import Pt
    from pptx.enum.shapes import MSO_SHAPE
    s = prs.slides.add_slide(prs.slide_layouts[6])  # blank
    # 主色背景条
    bar = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, _emu(1.4))
    bar.fill.solid()
    bar.fill.fore_color.rgb = _rgb(theme["primary"])
    bar.line.fill.background()
    # 装饰圆形（右上 + 左下，整合自 ppt-generator-skill）
    _add_decorator_circles(prs, s, theme)
    # 标题
    tb = s.shapes.add_textbox(_emu(0.8), _emu(2.0), prs.slide_width - _emu(1.6), _emu(1.2))
    tf = tb.text_frame
    tf.text = slide["title"]
    tf.paragraphs[0].font.size = Pt(40)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = _rgb(theme["text"])
    # 副标题（用第一个要点）
    if slide.get("points"):
        sub = s.shapes.add_textbox(_emu(0.8), _emu(3.2), prs.slide_width - _emu(1.6), _emu(0.8))
        stf = sub.text_frame
        stf.text = slide["points"][0]
        stf.paragraphs[0].font.size = Pt(18)
        stf.paragraphs[0].font.color.rgb = _rgb(theme["secondary"])


def _add_decorator_circles(prs, slide, theme):
    """装饰圆形（右上角 + 左下角），整合自 ppt-generator-skill 设计元素。"""
    from pptx.enum.shapes import MSO_SHAPE
    c1 = slide.shapes.add_shape(MSO_SHAPE.OVAL, _emu(10.5), _emu(-1.0), _emu(4), _emu(4))
    c1.fill.solid()
    c1.fill.fore_color.rgb = _rgb(theme.get("secondary", theme["primary"]))
    c1.line.fill.background()
    c2 = slide.shapes.add_shape(MSO_SHAPE.OVAL, _emu(-1.0), _emu(5.5), _emu(3), _emu(3))
    c2.fill.solid()
    c2.fill.fore_color.rgb = _rgb(theme.get("secondary", theme["primary"]))
    c2.line.fill.background()


def _add_big_number(prs, slide, theme):
    """大数据展示页（KPI 数据卡片），整合自 ppt-generator-skill create_big_number_slide。"""
    from pptx.util import Pt
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import PP_ALIGN
    s = prs.slides.add_slide(prs.slide_layouts[6])
    # 标题
    tb = s.shapes.add_textbox(_emu(0.6), _emu(0.4), prs.slide_width - _emu(1.2), _emu(0.9))
    tf = tb.text_frame
    tf.text = slide["title"]
    tf.paragraphs[0].font.size = Pt(32)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = _rgb(theme["primary"])
    # 数据卡片：从 numbers 字段取，或从 data_points 提取数值
    numbers = slide.get("numbers") or []
    if not numbers:
        # 兜底：从 points 提取 "数值 标签" 形式
        for p in slide.get("points", [])[:4]:
            numbers.append((p, p))
    n = len(numbers)
    if n == 0:
        return
    card_w = _emu(3.5)
    card_h = _emu(2.8)
    gap = _emu(0.5)
    start_x = _emu(0.8)
    start_y = _emu(2.2)
    for i, item in enumerate(numbers):
        if isinstance(item, (list, tuple)):
            value, label = item[0], item[1]
        else:
            value, label = str(item), ""
        x = start_x + i * (card_w + gap)
        card = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, start_y, card_w, card_h)
        card.fill.solid()
        card.fill.fore_color.rgb = _rgb(theme["primary"])
        card.line.fill.background()
        vb = s.shapes.add_textbox(x, start_y + _emu(0.6), card_w, _emu(1.2))
        vtf = vb.text_frame
        vtf.text = str(value)
        vtf.paragraphs[0].font.size = Pt(44)
        vtf.paragraphs[0].font.bold = True
        vtf.paragraphs[0].font.color.rgb = _rgb(theme["accent"])
        vtf.paragraphs[0].alignment = PP_ALIGN.CENTER
        lb = s.shapes.add_textbox(x, start_y + _emu(1.8), card_w, _emu(0.6))
        ltf = lb.text_frame
        ltf.text = str(label)
        ltf.paragraphs[0].font.size = Pt(15)
        ltf.paragraphs[0].font.color.rgb = _rgb(theme.get("secondary", theme["text"]))
        ltf.paragraphs[0].alignment = PP_ALIGN.CENTER


def _add_matrix(prs, slide, theme):
    """2x2 矩阵页（四象限/SWOT），整合自 ppt-generator-skill 2x2 布局。"""
    from pptx.util import Pt
    from pptx.enum.shapes import MSO_SHAPE
    s = prs.slides.add_slide(prs.slide_layouts[6])
    tb = s.shapes.add_textbox(_emu(0.6), _emu(0.4), prs.slide_width - _emu(1.2), _emu(0.9))
    tb.text_frame.text = slide["title"]
    tb.text_frame.paragraphs[0].font.size = Pt(32)
    tb.text_frame.paragraphs[0].font.bold = True
    tb.text_frame.paragraphs[0].font.color.rgb = _rgb(theme["primary"])
    cells = slide.get("matrix") or [{"label": p, "desc": ""} for p in slide.get("points", [])[:4]]
    cells = cells[:4]
    cell_w = (prs.slide_width - _emu(2.0)) // 2
    cell_h = _emu(2.2)
    origin_x = _emu(1.0)
    origin_y = _emu(1.7)
    for i, c in enumerate(cells):
        col = i % 2
        row = i // 2
        x = origin_x + col * cell_w
        y = origin_y + row * (cell_h + _emu(0.3))
        box = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, cell_w - _emu(0.2), cell_h)
        box.fill.solid()
        box.fill.fore_color.rgb = _rgb(theme.get("neutral", "FFFFFF"))
        box.line.color.rgb = _rgb(theme["secondary"])
        box.line.width = Pt(1)
        t = s.shapes.add_textbox(x + _emu(0.2), y + _emu(0.15), cell_w - _emu(0.6), cell_h - _emu(0.3))
        t.text_frame.word_wrap = True
        label = c.get("label", "") if isinstance(c, dict) else str(c)
        desc = c.get("desc", "") if isinstance(c, dict) else ""
        t.text_frame.text = label
        t.text_frame.paragraphs[0].font.size = Pt(16)
        t.text_frame.paragraphs[0].font.bold = True
        t.text_frame.paragraphs[0].font.color.rgb = _rgb(theme["primary"])
        if desc:
            p2 = t.text_frame.add_paragraph()
            p2.text = desc
            p2.font.size = Pt(12)
            p2.font.color.rgb = _rgb(theme.get("text_light", theme["text"]))


def _add_bullets(prs, slide, theme):
    from pptx.util import Pt
    s = prs.slides.add_slide(prs.slide_layouts[6])
    # 标题
    tb = s.shapes.add_textbox(_emu(0.6), _emu(0.4), prs.slide_width - _emu(1.2), _emu(0.9))
    tf = tb.text_frame
    tf.text = slide["title"]
    tf.paragraphs[0].font.size = Pt(28)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = _rgb(theme["primary"])
    # 要点
    body = s.shapes.add_textbox(_emu(0.8), _emu(1.6), prs.slide_width - _emu(1.6), _emu(5.0))
    btf = body.text_frame
    btf.word_wrap = True
    for i, p in enumerate(slide.get("points", [])):
        para = btf.paragraphs[0] if i == 0 else btf.add_paragraph()
        para.text = f"• {p}"
        para.font.size = Pt(16)
        para.font.color.rgb = _rgb(theme["text"])
        para.space_after = Pt(8)


def _add_chart_slide(prs, slide, theme):
    from pptx.util import Pt
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
    s = prs.slides.add_slide(prs.slide_layouts[6])
    tb = s.shapes.add_textbox(_emu(0.6), _emu(0.4), prs.slide_width - _emu(1.2), _emu(0.9))
    tf = tb.text_frame
    tf.text = slide["title"]
    tf.paragraphs[0].font.size = Pt(28)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = _rgb(theme["primary"])

    ch = slide.get("chart")
    if not ch:
        # 无图表数据时降级为「标题 + 要点」渲染，避免只留标题的空页
        from pptx.util import Pt as _Pt
        body = s.shapes.add_textbox(_emu(0.8), _emu(1.6),
                                    prs.slide_width - _emu(1.6), _emu(5.0))
        btf = body.text_frame
        btf.word_wrap = True
        for i, p in enumerate(slide.get("points", [])):
            para = btf.paragraphs[0] if i == 0 else btf.add_paragraph()
            para.text = f"• {p}"
            para.font.size = _Pt(16)
            para.font.color.rgb = _rgb(theme["text"])
            para.space_after = _Pt(8)
        return
    chart_data = CategoryChartData()
    chart_data.categories = ch["categories"]
    for ser in ch["series"]:
        chart_data.add_series(ser["name"], ser["values"])
    ctype = {"bar": XL_CHART_TYPE.COLUMN_CLUSTERED,
             "line": XL_CHART_TYPE.LINE,
             "pie": XL_CHART_TYPE.PIE}.get(ch["type"], XL_CHART_TYPE.COLUMN_CLUSTERED)
    gf = s.shapes.add_chart(ctype, _emu(0.8), _emu(1.5),
                            prs.slide_width - _emu(1.6), _emu(5.0), chart_data)
    chart = gf.chart
    chart.has_legend = ch["type"] != "pie"
    if ch["type"] != "pie":
        chart.legend.position = XL_LEGEND_POSITION.BOTTOM
        chart.legend.include_in_layout = False


def _add_section(prs, slide, theme):
    from pptx.util import Pt
    from pptx.enum.shapes import MSO_SHAPE
    s = prs.slides.add_slide(prs.slide_layouts[6])
    bg = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = _rgb(theme["primary"])
    bg.line.fill.background()
    tb = s.shapes.add_textbox(_emu(1.0), _emu(2.5), prs.slide_width - _emu(2.0), _emu(1.2))
    tf = tb.text_frame
    tf.text = slide["title"]
    tf.paragraphs[0].font.size = Pt(36)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = _rgb("FFFFFF")


def _add_two_column(prs, slide, theme):
    from pptx.util import Pt
    s = prs.slides.add_slide(prs.slide_layouts[6])
    tb = s.shapes.add_textbox(_emu(0.6), _emu(0.4), prs.slide_width - _emu(1.2), _emu(0.9))
    tb.text_frame.text = slide["title"]
    tb.text_frame.paragraphs[0].font.size = Pt(28)
    tb.text_frame.paragraphs[0].font.bold = True
    tb.text_frame.paragraphs[0].font.color.rgb = _rgb(theme["primary"])
    pts = slide.get("points", [])
    half = (len(pts) + 1) // 2
    left = s.shapes.add_textbox(_emu(0.8), _emu(1.6), _emu(5.5), _emu(5.0))
    right = s.shapes.add_textbox(_emu(6.6), _emu(1.6), _emu(5.5), _emu(5.0))
    for i, p in enumerate(pts[:half]):
        para = left.text_frame.paragraphs[0] if i == 0 else left.text_frame.add_paragraph()
        para.text = f"• {p}"
        para.font.size = Pt(16)
        para.font.color.rgb = _rgb(theme["text"])
    for i, p in enumerate(pts[half:]):
        para = right.text_frame.paragraphs[0] if i == 0 else right.text_frame.add_paragraph()
        para.text = f"• {p}"
        para.font.size = Pt(16)
        para.font.color.rgb = _rgb(theme["text"])


def _add_timeline(prs, slide, theme):
    from pptx.util import Pt
    from pptx.enum.shapes import MSO_SHAPE
    s = prs.slides.add_slide(prs.slide_layouts[6])
    tb = s.shapes.add_textbox(_emu(0.6), _emu(0.4), prs.slide_width - _emu(1.2), _emu(0.9))
    tb.text_frame.text = slide["title"]
    tb.text_frame.paragraphs[0].font.size = Pt(28)
    tb.text_frame.paragraphs[0].font.bold = True
    tb.text_frame.paragraphs[0].font.color.rgb = _rgb(theme["primary"])
    items = slide.get("timeline") or [{"label": p, "desc": p} for p in slide.get("points", [])]
    n = len(items)
    if n == 0:
        return
    step = (prs.slide_width - _emu(2.0)) // n
    y = _emu(2.5)
    for i, it in enumerate(items):
        x = _emu(1.0) + step * i
        dot = s.shapes.add_shape(MSO_SHAPE.OVAL, x, y, _emu(0.2), _emu(0.2))
        dot.fill.solid()
        dot.fill.fore_color.rgb = _rgb(theme["secondary"])
        dot.line.fill.background()
        lab = s.shapes.add_textbox(x - _emu(0.4), y + _emu(0.4), step, _emu(1.6))
        lab.text_frame.text = it["label"]
        lab.text_frame.paragraphs[0].font.size = Pt(14)
        lab.text_frame.paragraphs[0].font.bold = True
        lab.text_frame.paragraphs[0].font.color.rgb = _rgb(theme["text"])


def _add_quote(prs, slide, theme):
    from pptx.util import Pt
    from pptx.enum.shapes import MSO_SHAPE
    s = prs.slides.add_slide(prs.slide_layouts[6])
    q = slide.get("quote") or (slide.get("points") or [""])[0]
    box = s.shapes.add_textbox(_emu(1.5), _emu(2.5), prs.slide_width - _emu(3.0), _emu(2.0))
    box.text_frame.text = f"“{q}”"
    box.text_frame.paragraphs[0].font.size = Pt(28)
    box.text_frame.paragraphs[0].font.bold = True
    box.text_frame.paragraphs[0].font.color.rgb = _rgb(theme["secondary"])


def _add_contact(prs, slide, theme):
    from pptx.util import Pt
    s = prs.slides.add_slide(prs.slide_layouts[6])
    tb = s.shapes.add_textbox(_emu(1.0), _emu(2.8), prs.slide_width - _emu(2.0), _emu(1.2))
    tb.text_frame.text = slide.get("title", "谢谢")
    tb.text_frame.paragraphs[0].font.size = Pt(48)
    tb.text_frame.paragraphs[0].font.bold = True
    tb.text_frame.paragraphs[0].font.color.rgb = _rgb(theme["primary"])
    tb.text_frame.paragraphs[0].alignment = 1  # center


_RENDERERS = {
    "cover": _add_cover,
    "section": _add_section,
    "agenda": _add_bullets,
    "content": _add_bullets,
    "summary": _add_bullets,
    "two_column": _add_two_column,
    "big_number": _add_big_number,
    "matrix": _add_matrix,
    "table": _add_bullets,
    "chart": _add_chart_slide,
    "timeline": _add_timeline,
    "quote": _add_quote,
    "image": _add_bullets,
    "contact": _add_contact,
}


def run(spec: dict, binding: dict, token: dict, qa: dict,
        output_path: str, out_dir: str) -> dict:
    from pptx import Presentation
    from pptx.util import Pt

    theme = token["theme"]
    prs = Presentation()
    prs.slide_width = _emu(13.333)  # 16:9
    prs.slide_height = _emu(7.5)

    notes = []
    for slide in binding["slides"]:
        renderer = _RENDERERS.get(slide["layout"], _add_bullets)
        renderer(prs, slide, theme)
        notes.append({"page": slide["index"], "title": slide["title"],
                      "note": f"本页主题：{slide['title']}。" +
                              ("要点：" + "；".join(slide.get("points", [])) if slide.get("points") else "")})

    prs.save(output_path)

    # 演讲者备注（JSON 侧车文件）
    notes_path = os.path.join(out_dir, "speaker_notes.json")
    with open(notes_path, "w", encoding="utf-8") as f:
        json.dump(notes, f, ensure_ascii=False, indent=2)

    # 补充项标注（J1 自动补全，来源=用户信息不足）
    assumptions = spec.get("assumptions", [])

    # 版本归档 manifest
    manifest = {
        "generated_at": datetime.datetime.now().isoformat(),
        "output": os.path.basename(output_path),
        "slide_count": len(binding["slides"]),
        "theme": token["theme_key"],
        "scene": spec["scene"],
        "qa": {"p0": qa["p0_count"], "p1": qa["p1_count"], "p2": qa["p2_count"],
               "pass": qa["pass"]},
        "notes_file": os.path.basename(notes_path),
        "assumptions": assumptions,
    }
    manifest_path = os.path.join(out_dir, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    return {
        "module": "m08",
        "output_path": output_path,
        "notes_path": notes_path,
        "manifest_path": manifest_path,
        "slide_count": len(binding["slides"]),
        "assumptions": assumptions,
    }
