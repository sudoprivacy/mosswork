"""模块⑥ 模板适配与规则约束 (Template Adaptation)

职责：把内容绑定到母版/占位符，注入品牌规范，保证可编辑性。
输入：Visual Spec + Theme Token + 可选模板信息。
输出：Template Binding（内容→占位符映射，可直接驱动渲染器）。

可编辑性约束：文字用真实文本框、图表用原生可编辑对象，不图片化。
"""

from __future__ import annotations

from . import contracts as C


def run(spec: dict, visuals_spec: dict, token: dict,
        template: dict | None = None) -> dict:
    slides = []
    for i, v in enumerate(visuals_spec["visuals"]):
        binding = {
            "index": i,
            "layout": v["layout"],
            "title": v["title"],
            "title_placeholder": template.get("title_idx", 0) if template else None,
            "body_placeholder": template.get("body_idx", 1) if template else None,
            "points": v["points"],
            "chart": v["chart"],
            "table": v["table"],
            "timeline": v["timeline"],
            "quote": v["quote"],
            "relation": v["relation"],
            "editable": spec["config"]["editable"],
        }
        slides.append(binding)

    return {
        "module": "m06",
        "template": template,
        "slide_count": len(slides),
        "slides": slides,
        "brand": {
            "primary": token["theme"]["primary"],
            "footer": token.get("footer", ""),
            "page_numbers": token.get("page_numbers", True),
        },
    }
