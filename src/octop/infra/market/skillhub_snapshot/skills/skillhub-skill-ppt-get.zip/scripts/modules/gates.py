"""判断点模块（J1 / J2 / J3）——三个关键分支的集中承载。

三个判断点把流水线从「一条路走到黑」变成「条件驱动的有向图」，
确保每一步在获得充分信息与条件后才执行下一步。

- J1 信息充足性（①→② 之间）：场景/受众/篇幅/数据是否齐备。
  不足 → 暂停并澄清提问；无法交互（--no-pause）时自动补全默认值并记录为 assumption。
- J2 内容完整性（③ 之后）：检查大纲是否遗漏关键信息（空内容页、关键章节缺失）。
  有遗漏 → 回写 ② 重新提炼 / 触发内容兜底。
- J3 质量合格（⑦ 之后）：排版 / 内容 / 一致性是否达标。
  不达标 → 按问题类型回写 ③（重排结构）或 ④⑤（重做视觉）。

设计原则：
- 契约化：每个判断点返回统一结构，编排器据此决定下一步动作。
- 可追溯：所有「自动补全」都写入 spec["assumptions"]，标明来源是"用户信息不足"，
  并在最终产物（manifest + 备注 + 结果）中明确标注，鼓励用户补充。
"""

from __future__ import annotations

from . import contracts as C


# ---------------------------------------------------------------------------
# J1 信息充足性
# ---------------------------------------------------------------------------

# 关键字段 → (中文标签, 默认补全值, 澄清提问文案)
J1_FIELDS = {
    "scene": {
        "label": "场景",
        "default": C.SCENE_BIZ_REPORT,
        "default_label": C.SCENES[C.SCENE_BIZ_REPORT],
        "question": "这份 PPT 的主要用途是什么？（商业汇报/产品发布/融资路演/培训/演讲）",
    },
    "audience": {
        "label": "受众",
        "default": "public",
        "default_label": C.AUDIENCES["public"],
        "question": "目标读者是谁？（CEO/客户/员工/投资人/公众）",
    },
    "page_range": {
        "label": "篇幅",
        "default": (8, 12),
        "default_label": "8-12 页",
        "question": "期望的页数范围是多少？（例如 10-15 页）",
    },
    "data": {
        "label": "数据",
        "default": None,
        "default_label": "暂无（将生成结构化示例内容）",
        "question": "是否有具体数据/素材可提供？（文件路径或关键数字）",
    },
}


def detect_gaps(spec: dict, graph: dict | None = None) -> list[dict]:
    """J1 探测：返回信息缺口清单（field + question + label）。

    spec 来自 m01；graph 来自 m02（用于判断「数据」维度）。
    """
    gaps = []
    # 场景：无法识别（仍是默认 biz_report 且需求里没有明确汇报/报告意图）
    raw = spec.get("raw_request", "")
    if spec.get("scene") == C.SCENE_BIZ_REPORT and \
            not any(k in raw for k in ["汇报", "报告", "总结", "review", "report"]):
        gaps.append({"field": "scene", "label": "场景", "question": J1_FIELDS["scene"]["question"]})

    # 受众：仍是默认 public 且无明确通用意图
    if spec.get("audience") == "public" and \
            not any(k in raw for k in ["通用", "公众", "大众", "公开"]):
        gaps.append({"field": "audience", "label": "受众", "question": J1_FIELDS["audience"]["question"]})

    # 篇幅：无页数约束
    if not (spec.get("constraints") or {}).get("page_range"):
        gaps.append({"field": "page_range", "label": "篇幅", "question": J1_FIELDS["page_range"]["question"]})

    # 数据：无素材文件 且 提炼出的数据点不足（判定为数据不充分）
    no_material = not spec.get("source_paths")
    if graph is not None:
        data_count = graph.get("data_count", 0)
    else:
        data_count = 0
    if no_material and data_count < 3:
        gaps.append({"field": "data", "label": "数据", "question": J1_FIELDS["data"]["question"]})

    return gaps


def auto_fill_assumptions(spec: dict, gaps: list[dict]) -> dict:
    """J1 无交互补全：为每个缺口填入默认值，并写入 spec["assumptions"]。

    每条 assumption 记录：字段、标签、采用的默认值、来源（用户信息不足）、
    以及鼓励用户补充的提示。这是「自动补充 + 明确标注」的核心落点。
    """
    assumptions = list(spec.get("assumptions", []))
    constraints = spec.get("constraints", {})

    for g in gaps:
        field = g["field"]
        cfg = J1_FIELDS[field]
        if field == "scene":
            spec["scene"] = cfg["default"]
            spec["scene_label"] = cfg["default_label"]
            used = cfg["default_label"]
        elif field == "audience":
            spec["audience"] = cfg["default"]
            spec["audience_label"] = cfg["default_label"]
            used = cfg["default_label"]
        elif field == "page_range":
            constraints["page_range"] = cfg["default"]
            used = cfg["default_label"]
        elif field == "data":
            # 数据不补具体值，而是标记"将使用结构化示例内容"，
            # 由 content_gen 在后续兜底生成。
            used = cfg["default_label"]
        else:
            continue

        assumptions.append({
            "field": field,
            "label": cfg["label"],
            "adopted": used,
            "source": "用户信息不足，已自动补充",
            "encourage": "建议补充更多信息与要求，以产出更高质量、更符合预期的 PPT",
        })

    # 去重（同一字段只保留最新）
    seen = set()
    deduped = []
    for a in assumptions:
        if a["field"] not in seen:
            seen.add(a["field"])
            deduped.append(a)
    spec["assumptions"] = deduped
    spec["constraints"] = constraints
    spec["pending_clarify"] = []
    spec["complete"] = True
    return spec


# ---------------------------------------------------------------------------
# J2 内容完整性
# ---------------------------------------------------------------------------

# 关键信息类型（用于判断大纲是否遗漏）
KEY_INFO = {
    "cover": "封面",
    "agenda": "目录",
    "summary": "总结",
}


def check_content_completeness(outline: dict) -> dict:
    """J2 检查：大纲是否遗漏关键信息 / 存在空内容页。

    返回 {complete, gaps: [{page, title, layout, reason}]}
    """
    gaps = []
    slides = outline.get("slides", [])
    layouts = [s["layout"] for s in slides]

    # 1. 缺封面 / 缺总结（关键结构性信息）
    if "cover" not in layouts:
        gaps.append({"page": None, "title": "(封面)", "layout": "cover",
                     "reason": "缺少封面页"})
    if "summary" not in layouts:
        gaps.append({"page": None, "title": "(总结)", "layout": "summary",
                     "reason": "缺少总结页"})

    # 2. 空内容页（正文要点为空，且非封面/目录/封底）
    for s in slides:
        if s["layout"] in ("cover", "agenda", "contact"):
            continue
        if not s.get("points"):
            gaps.append({"page": s.get("index"), "title": s.get("title"),
                         "layout": s.get("layout"),
                         "reason": "内容页无正文要点"})

    return {
        "module": "gates",
        "gate": "J2",
        "complete": len(gaps) == 0,
        "gap_count": len(gaps),
        "gaps": gaps,
    }


# ---------------------------------------------------------------------------
# J3 质量合格
# ---------------------------------------------------------------------------

# P0 问题类型 → 回写方向（structure=回③重排结构 / visual=回④⑤重做视觉）
J3_ROUTING = {
    "empty_title": "structure",
    "overflow": "structure",
    "empty_chart": "visual",
    "no_cover": "structure",
    "too_many_slides": "structure",
    "no_theme": "visual",
}


def route_qafix(qa: dict) -> dict:
    """J3 路由：根据 QA 问题的类型，决定回写方向。

    返回 {direction, fix_targets}
    - direction: "structure"（回写③重排结构）/ "visual"（回写④⑤重做视觉）/ "none"
    """
    p0_types = {i["type"] for i in qa.get("issues", []) if i["level"] == C.QA_P0}
    if not p0_types:
        return {"direction": "none", "fix_targets": []}

    structure = [t for t in p0_types if J3_ROUTING.get(t) == "structure"]
    visual = [t for t in p0_types if J3_ROUTING.get(t) == "visual"]
    if structure and visual:
        direction = "both"
    elif structure:
        direction = "structure"
    elif visual:
        direction = "visual"
    else:
        direction = "structure"  # 未知 P0 默认按结构重排

    return {"direction": direction, "fix_targets": sorted(p0_types)}
