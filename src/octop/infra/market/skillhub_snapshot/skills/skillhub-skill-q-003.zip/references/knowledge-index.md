# 本地知识路由索引

只读取与当前主需求直接相关的1—3张卡，避免用资料堆砌替代判断。

| 需求信号 | 读取文件 | 主要用途 |
|---|---|---|
| 医保扣款、DRG/DIP、病案、成本、住院日、科室经营 | `references/course-drg-dip-operations.md` | 形成数据问题清单、病例复盘和运营小切口 |
| 学科、亚专业、患者外流、MDT、专病中心、转诊 | `references/course-oncology-discipline.md` | 设计病种—人才—流程—患者—品牌建设路径 |
| 医院战略、绩效、医共体、运营、品牌 | `references/course-hospital-high-quality.md` | 把诉求放入医院高质量发展和运营逻辑 |
| 科研、GCP、课题、病例、论文、真实世界研究 | `references/course-research.md` | 从临床/运营问题形成合规研究路径 |
| 信息化、AI、随访、病案质控、运营看板 | `references/course-ai-operations.md` | 选择低风险、高频、可见效的信息化试点 |
| 监管、市场打法、价值项目、患者价值 | `references/course-policy-market.md` | 从活动/产品转向合规、运营、学科和证据价值 |
| 产品、诊疗路径、指南证据、患者画像 | `references/course-guideline-decision.md` | 仅在产品闸门通过后设计核验清单，不作医学结论 |

通用项目目录在`references/project-resource-catalog.md`；匹配规则在`references/project-resource-matching.md`；项目内涵与价值转化在`references/project-mechanism-and-value.md`。课程卡给方法，项目目录给载体，价值卡解释作用机制，三者不能相互替代。

当输出A/B/C或推荐培训、进修、院际交流时，读取`references/course-learning-prescription.md`，把课程卡转成“谁学、学什么、带什么任务、如何应用、交付什么”的学习处方。

涉及捐赠、赞助、资助、基金会或新设公益项目时，必须读取`references/project-governance-and-foundation.md`。复评后需要继续挖掘需求时读取`references/next-need-exploration.md`。

需要核对包内知识来源和权限层级时读取`references/source-register.md`；不要把源文件名大段输出给业务用户。
