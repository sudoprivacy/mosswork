# 包内知识来源登记

## 使用说明

本技能包未内嵌原始PDF/DOCX，只收录面向业务任务的脱敏Markdown摘要，以便离线运行、降低体积和避免原文件元数据/敏感信息进入SkillHub。摘要不能替代原始文件、正式制度或当前项目通知。

| 知识域 | 本地来源 | 包内卡片 | 权限/权威层级 |
|---|---|---|---|
| 诊断表 | 《重点客户经营能力诊断表》及填写样例 | `references/diagnosis-form-schema.md`、`references/diagnostic-model.md`、`references/diagnosis-probes.md` | 内部工作工具；客户事实仅以本次输入为准 |
| 项目资源 | 《县域项目资源梳理—李欣遥7.5》、项目梳理及解读 | `references/project-resource-catalog.md`、`references/project-resource-matching.md` | 内部候选目录；当前状态须项目负责人确认 |
| 科研 | 《科研合作体系》 | `references/course-research.md` | 内部课程摘要；研究需伦理/合同/数据等正式审核 |
| 市场环境 | 《监管新时代下县域市场破局行动》 | `references/course-policy-market.md` | 内部课程摘要；不是法律/政策意见 |
| 高质量发展/北大课程 | 《医院高质量发展》《北京大学学习笔记》 | `references/course-hospital-high-quality.md`、`references/course-policy-market.md` | 内部课程摘要；政策以正式文件为准 |
| DRG/DIP | 《DRG:DIP医院运营》及北大课程相关内容 | `references/course-drg-dip-operations.md` | 内部课程摘要；当地规则由医院/统筹区核验 |
| 肿瘤学科 | 《县域肿瘤中心建设》 | `references/course-oncology-discipline.md` | 内部课程摘要；诊疗标准由医院/医学核验 |
| AI运营 | 《AI+医院运营》 | `references/course-ai-operations.md` | 内部课程摘要；实际系统需数据/安全/技术评估 |
| 指南决策 | 《齐鲁制药肿瘤指南决策中心》 | `references/course-guideline-decision.md` | 仅生成医学核验清单；不可直接作为推广或诊疗依据 |
| 项目价值转化 | 以上课程与项目解读的结构化归纳 | `references/project-mechanism-and-value.md` | 离线方法卡；具体项目仍按目录及当前审批核验 |
| 课程学习处方 | DRG/DIP、高质量发展、学科建设、科研等课程卡的任务化整合 | `references/course-learning-prescription.md` | 只生成建议学习模块；具体项目课表、师资与议程须负责人核验 |
| 项目治理与利益隔离 | 《中华人民共和国反不正当竞争法》（2025修订）、《中华人民共和国慈善法》（2023修正，2024施行）、市场监管总局《医药企业防范商业贿赂风险合规指引》（2025） | `references/project-governance-and-foundation.md`、`references/compliance-boundaries.md` | 截至2026-07-16的离线风险控制摘要；不替代公司法务/合规意见 |
| 复评与再探需求 | 诊断、跟进与代表训练规则的结构化归纳 | `references/next-need-exploration.md` | 内部工作方法；下一需求仍须客户证据验证 |

## 更新规则

- 项目状态、指南、医保和政策具有时效性；离线包输出必须标记“基于包内资料，当前状态待人工核验”。
- 更新原始资料后，应重新提炼对应知识卡、记录更新日期、运行张学剑等回归案例并重新打包。
- 不在发布包中放真实客户诊断表、患者病例、预算、劳务、供应商、个人联系方式或原始课程大文件。
- 法律、监管和公司制度变化时，优先更新项目治理、合规边界和项目目录，再进行案例回归；离线包不得把历史摘要当作最新法律意见。
