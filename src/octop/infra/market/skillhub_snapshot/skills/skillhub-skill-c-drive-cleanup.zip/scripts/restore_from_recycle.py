# -*- coding: utf-8 -*-
"""回收站元数据解析与误删恢复
用法:
    python restore_from_recycle.py --list              # 列出各盘回收站内容（原路径/大小/删除时间）
    python restore_from_recycle.py --list --find 关键词 # 按原路径关键词过滤
    python restore_from_recycle.py --restore $XXXXXXX  # 恢复指定 $I 标识的项到原路径

原理: 回收站位于 盘符\$RECYCLE.BIN\<SID>\，$I 开头为元数据（含原路径/大小/删除时间），
$I 之后数字相同的 $R 文件即被删内容。恢复 = 把 $R 内容移回原路径。
"""
import os
import sys
import struct
import shutil
import ctypes
from ctypes import wintypes
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')


def parse_i_file(path):
    """解析 $I 元数据文件（Vista+ 格式: 版本2, 头64字节+路径）"""
    try:
        size = os.path.getsize(path)
        with open(path, 'rb') as f:
            header = f.read(24)
            if len(header) < 24:
                return None
            version, _filesize = struct.unpack('<QQ', header[:16])
            ftime = struct.unpack('<Q', header[16:24])[0]
            if version == 1:
                n = struct.unpack('<I', f.read(4))[0]
                raw = f.read(n * 2)
            elif version == 2:
                n = struct.unpack('<I', f.read(4))[0]
                f.read(12)
                raw = f.read(n * 2)
            else:
                return None
        orig_path = raw.decode('utf-16-le', errors='replace').rstrip('\x00')
        # Windows FILETIME -> datetime
        ts = ftime / 10 ** 7 - 11644473600
        dt = datetime.fromtimestamp(ts) if 0 < ts < 4102444800 else None
        return {'path': orig_path, 'size': _filesize, 'deleted': dt}
    except OSError:
        return None


def recycle_items():
    """遍历所有盘的回收站，产出 (i_file, meta, r_path)"""
    for letter in 'CDEFGH':
        rb = f"{letter}:\\$RECYCLE.BIN"
        if not os.path.isdir(rb):
            continue
        for sid in os.listdir(rb):
            sid_path = os.path.join(rb, sid)
            if not os.path.isdir(sid_path):
                continue
            try:
                for name in os.listdir(sid_path):
                    if name.startswith('$I'):
                        i_path = os.path.join(sid_path, name)
                        meta = parse_i_file(i_path)
                        if meta:
                            r_path = os.path.join(sid_path, '$R' + name[2:])
                            yield i_path, meta, r_path
            except OSError:
                pass


def fmt_size(n):
    if n >= 1024 ** 3:
        return f"{n / 1024**3:.2f} GB"
    if n >= 1024 ** 2:
        return f"{n / 1024**2:.1f} MB"
    return f"{n / 1024:.1f} KB"


def list_items(keyword=None):
    print(f"{'标识':<14}{'大小':>10}  {'删除时间':<20}原路径")
    count = 0
    for i_path, meta, r_path in recycle_items():
        if keyword and keyword.lower() not in meta['path'].lower():
            continue
        dt = meta['deleted'].strftime('%Y-%m-%d %H:%M') if meta['deleted'] else '?'
        tag = os.path.basename(i_path)[2:]
        exists = '有' if os.path.exists(r_path) else '无'
        print(f"{tag:<14}{fmt_size(meta['size']):>10}  {dt:<20}{meta['path']} [内容{exists}]")
        count += 1
    print(f"共 {count} 项")


def restore(tag):
    """按 $I 标识恢复到原路径"""
    for i_path, meta, r_path in recycle_items():
        if os.path.basename(i_path)[2:] == tag:
            dst = meta['path']
            if not os.path.exists(r_path):
                print(f"❌ 对应内容文件缺失: {r_path}")
                return
            if os.path.exists(dst):
                print(f"❌ 原路径已存在，避免覆盖: {dst}")
                return
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if os.path.isdir(r_path):
                shutil.move(r_path, dst)
            else:
                shutil.move(r_path, dst)
            os.remove(i_path)
            print(f"✅ 已恢复到原路径: {dst}")
            return
    print(f"未找到标识 {tag}，用 --list 查看可用标识")


if __name__ == '__main__':
    args = sys.argv[1:]
    if not args or args[0] == '--list':
        kw = None
        if '--find' in args:
            kw = args[args.index('--find') + 1]
        list_items(kw)
    elif args[0] == '--restore' and len(args) >= 2:
        restore(args[1])
    else:
        print(__doc__)
