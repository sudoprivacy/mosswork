# -*- coding: utf-8 -*-
"""API 清空回收站（单次系统调用，不受批量删除保护限制）
用法: python empty_recycle_bin.py [盘符]   # 如 C 或 F，缺省清空所有盘
"""
import sys
import ctypes

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SHERB_NOCONFIRMATION = 0x1
SHERB_NOPROGRESSUI = 0x2
SHERB_NOSOUND = 0x4


def empty(drive=None):
    root = f"{drive}:\\\" if drive else None
    code = ctypes.windll.shell32.SHEmptyRecycleBinW(
        None, ctypes.c_wchar_p(root) if root else None,
        SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND)
    return code


if __name__ == '__main__':
    drive = sys.argv[1] if len(sys.argv) > 1 else None
    code = empty(drive)
    # 0=成功, -2147418113(0x8000FFFF)=回收站已空(视为成功), 其他=失败
    if code == 0:
        print("回收站已清空 ✅")
    elif code in (-2147418113, 0x8000FFFF):
        print("回收站本就为空 ✅")
    else:
        print(f"清空失败，返回码: {code}")
