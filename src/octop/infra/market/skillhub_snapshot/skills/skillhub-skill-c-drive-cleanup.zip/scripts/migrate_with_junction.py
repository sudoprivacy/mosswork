# -*- coding: utf-8 -*-
"""应用数据跨盘迁移 + junction 永久生效
用法: python migrate_with_junction.py <源目录> <目标目录> [--process 进程名1,进程名2]

流程:
  1. 结束占用进程（可选，--process 指定，如 msedge.exe,Weixin.exe,QQ.exe）
  2. 复制源目录全部内容到目标目录（跨盘 copy）
  3. 校验: 文件数 + 总字节数一致
  4. Shell API 删除源目录
  5. _winapi.CreateJunction(目标, 源) 创建目录链接
  6. 复验: 通过源路径可列出内容

适用: QQ 等路径配置存在加密数据库、无法直接改设置的应用。
junction 创建后应用按原路径读写，数据实际落在目标盘，永久生效。
"""
import os
import sys
import time
import shutil
import ctypes
import subprocess
from ctypes import wintypes

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

FO_DELETE = 3
FOF_SILENT = 0x0004
FOF_NOCONFIRMATION = 0x0010
FOF_ALLOWUNDO = 0x0040
FOF_NOERRORUI = 0x0400


class SHFILEOPSTRUCTW(ctypes.Structure):
    _fields_ = [
        ('hwnd', wintypes.HWND), ('wFunc', ctypes.c_uint),
        ('pFrom', wintypes.LPCWSTR), ('pTo', wintypes.LPCWSTR),
        ('fFlags', ctypes.c_ushort), ('fAnyOperationsAborted', wintypes.BOOL),
        ('hNameMappings', ctypes.c_void_p), ('lpszProgressTitle', wintypes.LPCWSTR),
    ]


def shell_delete(path, to_recycle_bin=True):
    op = SHFILEOPSTRUCTW()
    op.wFunc = FO_DELETE
    op.pFrom = path + '\x00\x00'
    flags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_NOERRORUI
    if to_recycle_bin:
        flags |= FOF_ALLOWUNDO
    op.fFlags = flags
    op.fAnyOperationsAborted = False
    return ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))


def kill_processes(names):
    for name in names:
        subprocess.run(['taskkill', '/im', name], capture_output=True)
    time.sleep(3)
    for name in names:
        subprocess.run(['taskkill', '/f', '/im', name], capture_output=True)
    time.sleep(2)


def tree_stats(path):
    files = size = 0
    stack = [path]
    while stack:
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            stack.append(e.path)
                        elif e.is_file(follow_symlinks=False):
                            files += 1
                            size += e.stat(follow_symlinks=False).st_size
                    except OSError:
                        pass
        except OSError:
            pass
    return files, size


def main():
    args = sys.argv[1:]
    processes = []
    if '--process' in args:
        i = args.index('--process')
        processes = [p.strip() for p in args[i + 1].split(',') if p.strip()]
        args = args[:i] + args[i + 2:]
    if len(args) != 2:
        print(__doc__)
        return
    src, dst = args

    if not os.path.isdir(src):
        print(f"源目录不存在: {src}")
        return
    if os.path.exists(dst):
        print(f"目标已存在，请先处理: {dst}")
        return

    if processes:
        print(f"结束进程: {processes}")
        kill_processes(processes)

    sf, ss = tree_stats(src)
    print(f"源: {sf} 文件 / {ss / 1024**2:.1f} MB")

    print("复制中（跨盘，大目录耗时较长）...")
    shutil.copytree(src, dst)

    df, ds = tree_stats(dst)
    print(f"目标: {df} 文件 / {ds / 1024**2:.1f} MB")
    if (df, ds) != (sf, ss):
        print("❌ 校验不一致！保留源目录，中止迁移，请人工核查")
        return
    print("✅ 校验一致")

    code = shell_delete(src)
    if os.path.exists(src):
        print(f"源目录删除未完成（码 {code}），尝试逐项 Shell 删除...")
        entries = [os.path.join(src, e) for e in os.listdir(src)]
        for i in range(0, len(entries), 20):
            shell_delete(entries[i:i + 20])
        if os.path.exists(src):
            # 空壳目录残留时 robocopy 兜底
            subprocess.run(['robocopy', src, dst, '/MOVE', '/E', '/R:1', '/W:1',
                            '/NFL', '/NDL', '/NP', '/NJH', '/NJS'], capture_output=True)
        if os.path.exists(src):
            print("❌ 源目录仍存在，无法创建 junction。数据已在目标盘完好，请手动处理后重跑本脚本（会跳过复制）")
            return

    try:
        _winapi.CreateJunction(dst, src)
    except Exception as e:
        print(f"junction 创建失败: {e}")
        return

    ok = os.path.isdir(src)
    items = os.listdir(src) if ok else []
    print(f"✅ 迁移完成: {src} -> {dst}（junction 已创建，经原路径可见 {len(items)} 项）")


if __name__ == '__main__':
    main()
