# 安装与使用指南

## 使用前提

1. 在 SkillHub 平台完成企业认证并绑定微信支付商户号
2. 本 Skill 已在 SkillHub 后台配置按次计费价格
3. 在支持微信 Agent Pay 的 Agent 环境中使用（WorkBuddy ≥ 5.5.2）

## 支付说明

本 Skill 为 SkillHub Pay Skill，按次计费，支付由 SkillHub + 微信支付 Agent Pay 体系在平台侧处理（云托管服务端完成微信下单与 X402 预下单）。本 Skill 包内不包含任何支付代码，无需本地支付配置。

## 安装

1. 在 SkillHub 平台获取本技能并按平台指引安装
2. 本地依赖：Python 3.8+（业务脚本为本地 Python 执行）
