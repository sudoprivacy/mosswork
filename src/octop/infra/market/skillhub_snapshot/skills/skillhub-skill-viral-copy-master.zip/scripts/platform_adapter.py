#!/usr/bin/env python3
"""
多平台适配模块
"""

import argparse
import json
import os


def adapt_copy(copy_data: dict, platform: str) -> dict:
    """适配不同平台"""

    # 平台规范
    specs = {
        "douyin": {"max_title": 30, "max_content": 200, "tags_limit": 5},
        "xiaohongshu": {"max_title": 20, "max_content": 300, "tags_limit": 8},
        "tiktok": {"max_title": 30, "max_content": 200, "tags_limit": 5},
        "kuaishou": {"max_title": 30, "max_content": 200, "tags_limit": 5}
    }

    spec = specs.get(platform, specs["douyin"])

    # 截断内容
    content = copy_data.get("content", "")
    if len(content) > spec["max_content"]:
        content = content[:spec["max_content"]] + "..."

    tags = copy_data.get("tags", [])
    if len(tags) > spec["tags_limit"]:
        tags = tags[:spec["tags_limit"]]

    return {
        "platform": platform,
        "title": copy_data.get("title", "")[:spec["max_title"]],
        "content": content,
        "tags": tags,
        "platform_spec": spec
    }


def main():
    parser = argparse.ArgumentParser(description="多平台适配")
    parser.add_argument("--input", required=True)
    parser.add_argument("--platform", required=True,
                       choices=["douyin", "xiaohongshu", "tiktok", "kuaishou"])
    parser.add_argument("--output", default="./output/")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    with open(args.input, 'r', encoding='utf-8') as f:
        data = json.load(f)

    result = adapt_copy(data, args.platform)

    output_path = os.path.join(args.output, f"adapted_{args.platform}.json")
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"   ✅ 适配完成: {args.platform}")
    print(f"\n📱 {args.platform} 版本:")
    print(f"   标题: {result['title']}")
    print(f"   正文: {result['content'][:100]}...")
    print(f"   标签: {' '.join(result['tags'])}")


if __name__ == "__main__":
    main()