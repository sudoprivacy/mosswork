#!/usr/bin/env python3
"""
爆款文案生成模块
基于7种爆款结构模板
"""

import argparse
import json
import os
import sys


def generate_copy(topic: str, platform: str, structure: str) -> dict:
    """生成爆款文案"""
    print(f"   ✍️ 生成中...")

    # 根据平台调整文案风格
    platform_names = {
        "douyin": "抖音",
        "xiaohongshu": "小红书",
        "tiktok": "TikTok",
        "kuaishou": "快手"
    }
    platform_name = platform_names.get(platform, "抖音")

    # 7种结构模板
    structures = {
        "观点结构": {
            "formula": "观点+危害+论据+结论",
            "template": "你想{目标}，就必须{行动}。否则你一定会{危害}。因为{论据}。所以记住：{结论}"
        },
        "悬疑结构": {
            "formula": "悬疑+描述+案例+总结",
            "template": "有个人{制造反差}，但他做了一个改变。结果{数据/变化}。如果你也想{目标}，记住这点：{结论}"
        },
        "挑战结构": {
            "formula": "挑战主题+情节+价值",
            "template": "我决定挑战{主题}。过程发生了{冲突/反转}。最后发现一个真相：{结论}"
        },
        "SCQA结构": {
            "formula": "情境+冲突+问题+答案",
            "template": "很多人都在{情境}。但问题是{冲突}。那到底该怎么办？答案是：{解决方案}"
        },
        "三步循环结构": {
            "formula": "提问+概念+解释",
            "template": "为什么{现象}？核心是一个概念：{概念}。它的意思是{解释+拆解}"
        },
        "多维关联结构": {
            "formula": "目标+必要条件",
            "template": "如果你想{目标}，你必须先做到{条件}。举例：{例子}"
        },
        "三把刀结构": {
            "formula": "多重提问+拆解+引导",
            "template": "为什么{现象1}？为什么{现象2}？为什么明明{现象3}？其实本质只有一个原因：{核心原因}。如果你听懂了，评论区告诉我"
        }
    }

    # 选择结构
    if structure and structure in structures:
        selected = structure
        template = structures[structure]["template"]
    else:
        # 根据主题自动选择
        selected = list(structures.keys())[0]
        template = structures[selected]["template"]

    # 生成文案
    title = f"{topic}的3个秘密，90%的人不知道"
    content = f"别划走！关于{topic}，你可能一直想错了。\n\n{template.replace('{目标}', topic).replace('{行动}', '立即行动').replace('{危害}', '错过机会').replace('{论据}', '数据证明').replace('{结论}', '立刻开始')}\n\n# {topic} # 干货分享 # 必看"
    tags = [f"#{topic}", "#干货", "#爆款"]

    return {
        "title": title,
        "content": content,
        "tags": tags,
        "structure": selected,
        "platform": platform,
        "generated_at": "2026-08-13T14:00:00"
    }


def main():
    parser = argparse.ArgumentParser(description="爆款文案生成")
    parser.add_argument("--topic", required=True)
    parser.add_argument("--platform", default="douyin")
    parser.add_argument("--structure", default="auto")
    parser.add_argument("--output", default="./output/")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    result = generate_copy(args.topic, args.platform, args.structure)

    output_path = os.path.join(args.output, "copy_content.json")
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"\n   ✅ 文案生成完成")
    print(f"\n📌 标题: {result['title']}")
    print(f"\n📝 正文:\n{result['content'][:200]}...")
    print(f"\n🏷️ 标签: {' '.join(result['tags'])}")
    print(f"\n📐 结构: {result['structure']}")
    print(f"\n📁 输出: {os.path.basename(output_path)}")


if __name__ == "__main__":
    main()