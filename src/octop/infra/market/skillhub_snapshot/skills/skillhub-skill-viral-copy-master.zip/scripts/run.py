#!/usr/bin/env python3
"""
爆款短视频文案创作大师 - 统一入口
"""

import argparse
import os
import sys
import subprocess
import json
from datetime import datetime


def generate_copy(topic: str, platform: str, structure: str, output_dir: str):
    """生成爆款文案"""
    print(f"✍️ 生成爆款文案")
    print(f"   📌 主题: {topic}")
    print(f"   📱 平台: {platform}")
    print(f"   📐 结构: {structure or '自动'}")

    # 调用文案生成脚本
    cmd = [
        sys.executable,
        "scripts/copy_generator.py",
        "--topic", topic,
        "--platform", platform,
        "--structure", structure or "auto",
        "--output", output_dir
    ]
    subprocess.run(cmd, check=True)


def remake_copy(url: str, platform: str, output_dir: str):
    """爆款复刻"""
    print(f"🔄 爆款复刻")
    print(f"   🔗 链接: {url}")

    cmd = [
        sys.executable,
        "scripts/copy_remaker.py",
        "--url", url,
        "--platform", platform,
        "--output", output_dir
    ]
    subprocess.run(cmd, check=True)


def generate_with_tts(topic: str, platform: str, voice: str, output_dir: str):
    """生成文案+配音"""
    print(f"🎤 生成文案+配音")
    print(f"   📌 主题: {topic}")
    print(f"   🎙️ 音色: {voice}")

    # 先生成文案
    generate_copy(topic, platform, None, output_dir)

    # 再生成配音
    copy_path = os.path.join(output_dir, "copy_content.json")
    cmd = [
        sys.executable,
        "scripts/tts_engine.py",
        "--input", copy_path,
        "--voice", voice,
        "--output", output_dir
    ]
    subprocess.run(cmd, check=True)


def batch_generate(topics: list, platform: str, output_dir: str):
    """批量生成"""
    print(f"📦 批量生成 {len(topics)} 条文案")
    for i, topic in enumerate(topics):
        print(f"   {i+1}. {topic}")
        cmd = [
            sys.executable,
            "scripts/copy_generator.py",
            "--topic", topic,
            "--platform", platform,
            "--output", os.path.join(output_dir, f"batch_{i+1}")
        ]
        subprocess.run(cmd, check=True)


def main():
    parser = argparse.ArgumentParser(description="爆款短视频文案创作大师")
    parser.add_argument("--action", required=True,
                       choices=["generate", "remake", "tts", "batch", "analyze"],
                       help="操作类型")
    parser.add_argument("--topic", help="文案主题")
    parser.add_argument("--platform", default="douyin",
                       choices=["douyin", "xiaohongshu", "tiktok", "kuaishou"],
                       help="目标平台")
    parser.add_argument("--structure", help="文案结构（7种之一）")
    parser.add_argument("--url", help="爆款链接（复刻用）")
    parser.add_argument("--voice", default="zh-CN-XiaoxiaoNeural", help="TTS音色")
    parser.add_argument("--topics", help="批量生成主题，逗号分隔")
    parser.add_argument("--output", default="./output/")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    print("=" * 60)
    print("🔥 爆款短视频文案创作大师 v1.0")
    print("=" * 60)
    print("💡 基于真实爆款文案结构复刻")
    print("💡 支持7种爆款结构 + Edge TTS配音")
    print("=" * 60)

    try:
        if args.action == "generate":
            if not args.topic:
                print("❌ 需要 --topic 参数")
                sys.exit(1)
            generate_copy(args.topic, args.platform, args.structure, args.output)

        elif args.action == "remake":
            if not args.url:
                print("❌ 需要 --url 参数")
                sys.exit(1)
            remake_copy(args.url, args.platform, args.output)

        elif args.action == "tts":
            if not args.topic:
                print("❌ 需要 --topic 参数")
                sys.exit(1)
            generate_with_tts(args.topic, args.platform, args.voice, args.output)

        elif args.action == "batch":
            if not args.topics:
                print("❌ 需要 --topics 参数")
                sys.exit(1)
            topics = [t.strip() for t in args.topics.split(",")]
            batch_generate(topics, args.platform, args.output)

        elif args.action == "analyze":
            print("📊 爆款结构分析")
            print("   支持7种结构: 观点/悬疑/挑战/SCQA/三步循环/多维关联/三把刀")
            print("   参考 assets/templates/structure_templates.json")

        print(f"\n✅ 完成！输出目录: {args.output}")

    except subprocess.CalledProcessError as e:
        print(f"❌ 执行失败: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n⚠️ 用户中断")
        sys.exit(0)


if __name__ == "__main__":
    main()