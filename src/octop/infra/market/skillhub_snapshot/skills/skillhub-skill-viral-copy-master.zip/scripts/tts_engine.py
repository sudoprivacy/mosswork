#!/usr/bin/env python3
"""
Edge TTS语音合成模块
免费，无需API Key[citation:5]
"""

import argparse
import asyncio
import json
import os
import sys


async def generate_tts(text: str, voice: str, output_path: str):
    """生成TTS音频"""
    import edge_tts

    print(f"   🎤 生成TTS配音...")
    print(f"   🎙️ 音色: {voice}")

    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(output_path)

    print(f"   ✅ TTS生成完成: {os.path.basename(output_path)}")
    return output_path


async def main_async():
    parser = argparse.ArgumentParser(description="TTS配音")
    parser.add_argument("--input", help="文案JSON文件")
    parser.add_argument("--text", help="直接输入文本")
    parser.add_argument("--voice", default="zh-CN-XiaoxiaoNeural")
    parser.add_argument("--output", default="./output/")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    # 读取文案
    if args.input and os.path.exists(args.input):
        with open(args.input, 'r', encoding='utf-8') as f:
            data = json.load(f)
            text = data.get("content", "")
    elif args.text:
        text = args.text
    else:
        print("❌ 需要 --input 或 --text 参数")
        sys.exit(1)

    if not text:
        print("❌ 文案内容为空")
        sys.exit(1)

    output_path = os.path.join(args.output, "audio.mp3")
    await generate_tts(text, args.voice, output_path)


if __name__ == "__main__":
    asyncio.run(main_async())