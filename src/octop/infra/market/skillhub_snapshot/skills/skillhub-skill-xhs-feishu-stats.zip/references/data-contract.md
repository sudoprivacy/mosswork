# 数据契约与接口细节

本文件记录技能依赖的真实数据结构（2026-11 在小红书 Web 与 lark-cli 1.0.98 上实测），排查问题或适配改版时加载。

## 1. 小红书链接

| 形态 | 示例 | 处理 |
|---|---|---|
| 标准笔记页 | `https://www.xiaohongshu.com/explore/<24位hex>?xsec_token=XXX&xsec_source=pc_feed` | 直接使用 |
| 旧版路径 | `/discovery/item/<24位hex>` | 同样按正则识别 |
| 短链 | `https://xhslink.com/a/xxxx` | 跟随 HTTP 重定向，取最终 URL（通常自带 xsec_token） |
| 无 token | `/explore/<id>` | 登录后直接访问常被重定向到 `/404?...error_code=300031`，会给出明确报错 |

笔记 ID 正则：`/(?:explore|discovery/item|item)/([0-9a-fA-F]{24})`。`xsec_token` 是与登录态/分享场景绑定的临时参数，过期就会 404。

## 2. 页面数据结构（登录态）

```js
window.__INITIAL_STATE__.note.noteDetailMap[noteId].note = {
  noteId, title, desc,
  user: { nickname / nickName, ... },
  interactInfo: {
    likedCount: "140",       // 字符串，也可能是 ""（低互动时页面显示「赞」）
    collectedCount: "33",
    commentCount: "18",
    shareCount: "118",
    niceCount: ""
  },
  ...
}
```

坑：

- `noteDetailMap` 常同时含 `"undefined"` 这个占位键，必须先按 URL 里的 noteId 精确取，再回退到「第一个有 interactInfo 的对象」。
- 页面底部有推荐流，全页 `span.count` 前十几个里混着别的笔记的数字（实测 `['140','107','6942','6397',...]`，只有第一个是主笔记）。**禁止全页盲抓**。
- DOM 兜底只锁 `.engage-bar`（class 为 `interactions engage-bar`），依次取 `.like-wrapper .count`、`.collect-wrapper .count`、`.chat-wrapper .count`。`.interaction-container` 是整篇笔记容器，里面评论区也有 `span.count`，不要用。
- 未登录时 SSR 返回的 `noteDetailMap` 是 `{}`，所以纯 HTTP 通道（`--http-first`）多数情况取不到数，Playwright 登录态才是主通道。
- 阅读量仅作者本人可见，公开页取不到，本技能不采集。

## 3. 数值归一

| 原始值 | 结果 |
|---|---|
| `"140"` / `140` | `140` |
| `"1,234"` | `1234` |
| `"1.2万"` / `"2.3w"` | `12000` / `23000` |
| `"1.5千"` / `"3k"` | `1500` / `3000` |
| `""` / `null` / `"赞"` / `"收藏"` | `None` → 记入 `need_check`，字段留空 |

状态：`ok`（三项齐全）/ `partial`（缺 1–2 项，只写取到的字段）/ `failed`（三项全缺，不写入）。

## 4. 抓取结果 JSON（`--out` / `--from-json`）

```json
{
  "captured_at": "2026-11-12 08:30:00",
  "rows": [{
    "note_id": "6ad2109c000000001500e815",
    "url": "https://www.xiaohongshu.com/explore/...?xsec_token=...",
    "title": "噜申克的救赎-第十七集",
    "author": "某作者",
    "likes": 140, "collects": 33, "comments": 18,
    "captured_at": "2026-11-12 08:30:00",
    "source": "initial_state | dom | http_ssr",
    "need_check": [], "status": "ok"
  }],
  "errors": [{ "url": "...", "error": "..." }],
  "summary": {
    "notes": 1, "total_likes": 140, "total_collects": 33, "total_comments": 18,
    "avg_likes": 140.0, "avg_collects": 33.0, "avg_comments": 18.0,
    "top_by_likes": [{ "title": "...", "likes": 140 }]
  }
}
```

`--from-json` 只需要 `rows`（`captured_at` / `summary` 可省，脚本会重算）。

## 5. 字段角色与别名

归一化规则：去括号内容、空白、`_ - / . ·`，小写。先精确匹配，再包含匹配；含「率/占比/比例/增长/增量/变化/差值/趋势/环比/同比/平均/总计/汇总/得分/评分/排名/是否/昨日/上周」的列排除。

| 角色 | 默认字段名（自动创建时） | 别名举例 |
|---|---|---|
| `likes` | 点赞（number） | 点赞、点赞数、点赞量、获赞、赞、赞数、likes、likeCount、likedCount |
| `collects` | 收藏（number） | 收藏、收藏数、收藏量、藏、collects、collectedCount |
| `comments` | 评论（number） | 评论、评论数、评论量、留言、comments、commentCount |
| `note_id` | 笔记ID（text） | 笔记ID、笔记编号、noteId、note_id |
| `link` | 笔记链接（text） | 笔记链接、小红书链接、笔记地址、链接、URL |
| `title` | 标题（text） | 标题、笔记标题、名称、选题、title、name |
| `author` | 作者（text） | 作者、博主、账号、昵称、author、nickname |
| `captured_at` | 采集时间（text） | 采集时间、统计时间、抓取时间、更新时间、日期 |
| `status` | 数据状态（text） | 数据状态、采集状态、备注、status |

表里**第一个未被占用的纯文本列**自动作为 `title`（飞书主字段不能空）。1.1.0 起不再只认 `fields[0]`：`+field-create` 可能把新列插到最前，只认第一列会导致主字段漂移、重复补建「标题」列。

字段类型 → CellValue：

- `number / currency / percent / rating` → `int`
- `text / url / phone / email` → `str`
- `datetime` → `"YYYY-MM-DD HH:MM"`；`date` → `"YYYY-MM-DD"`
- `formula / lookup / attachment / button / auto_number / checkbox / select / user / created_by / ...` → 跳过并提示（select 需先有选项，不擅自写）

## 6. 飞书链接与 lark-cli 命令

链接解析：`/base/<base_token>?table=<table_id>&view=<view_id>`；也支持 `/wiki/<token>` 与 `lark-cli base +url-resolve` 兜底。缺 `table=` 时脚本调用 `+table-list` 列出可用表后报错，不擅自选表。

| 动作 | 命令 |
|---|---|
| 列字段 | `base +field-list --base-token X --table-id Y --format json --as user` |
| 建字段 | `base +field-create --base-token X --table-id Y --json '[{"name":"点赞","type":"number"}]' --as user` |
| 查重 | `base +record-search --base-token X --table-id Y --keyword K --search-field F --field-id F --format json --limit 50 --as user` |
| 写记录 | `base +record-upsert --base-token X --table-id Y --json '{"标题":"...","点赞":140}' [--record-id recXXX] --as user` |

`+record-upsert` 不带 `--record-id` 是新增，带上是更新；**它不会按业务键自动 upsert**，查重由脚本完成，优先级 `note_id > title > link`（短值优先）。短值用 `+record-search`（模糊搜索 + 本地归一化精确比对）；`+record-search` 的 `--keyword` 上限 50 字符，超过 45 字符的值（典型是完整笔记链接）改走 `+record-list --field-id <列> --format json` 投影分页扫描后本地精确比对。

返回结构（实测）：

```json
// +field-list
{"ok":true,"data":{"fields":[{"id":"fldXXX","name":"点赞","type":"number"}]}}
// +record-search --format json（列式矩阵）
{"ok":true,"data":{"fields":["标题"],"data":[["某标题"]],"record_id_list":["recXXX"],"has_more":false}}
// 错误
{"ok":false,"error":{"code":800030104,"message":"not_found","hint":"..."}}
```

错误码：`91403` 应用未被加为表格协作者 / `99991679` 缺 scope / `1254005` 无资源权限 → 用用户身份或 `lark-cli auth login` 重新授权；`800030104` 表不存在 → 检查 `table=` 是否指向有效表。

身份统一用 `--as user`（与 `lark-base` skill 一致）；`auth status` 显示 `needs_refresh` 会在下一次 API 调用时自动刷新，不是故障。

## 7. 安全边界

- 写入前默认不修改表结构；`--ensure-fields` 才会 `+field-create`，且 `--dry-run` 下绝不调用。
- 单条链接失败不影响其它链接；失败明细进 `errors`。
- 运行时状态存放于 `~/.workbuddy/xhs-feishu-stats/`（结果 JSON）与 `~/.workbuddy/xhs-feishu-stats-profile/`（浏览器登录态），技能包内不含凭证、cookie 或用户数据。

## 8. 渲染页文本（`parse-rendered` 的输入）

风控 / 无登录态时，用 WorkBuddy 网页读取工具或内置浏览器导出页面文本（markdown 或纯文本），保存为 UTF-8 文件。可解析的结构（实测 2026-11 小红书 H5 笔记页）：

```text
![Image 3: 居小爆\(AI 版\)](avatar-url)
居小爆(AI 版)
关注
全网最全的视频反推提示词
……正文……
2条精选评论
……
说点什么...
**26**      ← 点赞
**30**      ← 收藏
**2**       ← 评论
```

- 互动栏定位：`说点什么` 所在行之后，连续 3 个「整行是数字」的行（允许 `**26**`、`1.2万`、`1,234`；也支持同一行 `26 30 2`），顺序固定为 点赞 / 收藏 / 评论。解析前先剥离 markdown 图片/链接，避免 base64、图片 URL 里的数字干扰。
- 作者 / 标题：`关注` 行往上最近一行短文本为作者，往下一行短文本为标题；作者也尝试从图片 alt 提取。
- 交叉核对线索写进 `row["evidence"]`（如 `{"featured_comments": 2}`），只记录、不参与数值推断。
- 解析不到就留 `None` → `need_check` / `partial`；三项全缺记 `failed`，不写入。**绝不臆造 0**。
- `--likes/--collects/--comments/--title/--author` 人工值优先于文本解析值；未提供文本文件但给了数值时也能生成标准 JSON。
- 输出结构与第 4 节完全一致（多了 `source: "rendered_page"` 与 `evidence`），可直接 `write --from-json`。
- 回归样例：`tests/rendered_note.md`。

## 9. lark-cli 参数安全（Windows 必读）

- Windows 的 `lark-cli.CMD` 内容形如 `... node.exe "...\@larksuite\cli\scripts\run.js" %*`，`%*` 经 cmd.exe 二次解析，参数里的 `&`（小红书链接必带）会被当成命令分隔符，导致 JSON 被截断、`record-search` 参数丢失。
- 1.1.0 起 `lark_command()` 检测到 `.CMD/.BAT` 且同目录存在 `node_modules/@larksuite/cli/scripts/run.js` 时，直接 `[node, run.js, *args]` 调用（node 取同目录 `node.exe` 或 PATH 中的 `node`），参数不再经过 cmd.exe。
- 无法直调 node 时，`shield_json_arguments()` 把 `--json` 的值写入 `tempfile.gettempdir()` 下的临时文件并改成 `@路径`，执行后删除。lark-cli 的 @file 允许根：cwd / 账户 temp / home 下的 `files` 目录，其它路径会报 `outside the built-in allowlist`。
- `--dry-run` 在脚本层与 CLI 层都是只读：脚本不会调用 `+field-create` 或 `+record-upsert`。
