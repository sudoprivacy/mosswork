# 排错手册

先跑 `python scripts/xhs_stats.py doctor`，它会指出缺的是飞书登录态、playwright、浏览器 profile，并显示 lark-cli 的**参数通道**（是否已绕开 cmd.exe）。

## 小红书侧

| 现象 | 原因 | 处理 |
|---|---|---|
| `小红书风控拦截（安全限制 300012）` / 页面显示「当前网络存在风险，请切换可靠网络后重试」 | 本机出口 IP / 浏览器环境被小红书判定风险，`__INITIAL_STATE__` 为空 | **走 SKILL.md「风控兜底 SOP」**：用 WorkBuddy 网页读取工具或内置浏览器打开同一完整链接 → 保存页面文本 → `parse-rendered ... --text-file ...` → `write --from-json`。不要反复重试或换 UA 硬刷 |
| `三项互动数都未取到` / `页面没有返回可识别的笔记数据` | 页面把低数值显示成「赞/收藏」文字、未登录、页面改版，或风控 | 错误里会直接打印兜底命令；按上一条走 C 通道，或用 `--likes/--collects/--comments` 传人工核对值。脚本不会臆造 0 |
| `笔记页返回 404` / `访问的页面不见了` | 链接缺 `xsec_token`、token 过期、笔记已删除 | 在**已登录**的浏览器里点开该笔记，从地址栏复制完整链接（含 `?xsec_token=...`）；或用分享短链让脚本自动展开 |
| `小红书登录态失效` | profile 里 cookie 过期 | `python scripts/xhs_stats.py login`（headed 扫码，一次即可）。默认复用 `xhs-feishu-publish-skill/.xhs_browser_profile`，也可用 `--profile` 指定 |
| 抓到的数字明显偏大 | 抓到推荐流里别的笔记 | 只从 `.engage-bar` 的 `.like-wrapper/.collect-wrapper/.chat-wrapper` 取数；优先 `__INITIAL_STATE__.note.noteDetailMap[noteId]`。见 data-contract.md |
| `短链解析失败` | 短链需要 App 打开或被拦截 | 直接用长链 |
| `启动 Chromium 失败` / profile 被占用 | 另一个浏览器正在用同一个 profile，或没装 Chromium | 关闭占用进程；`playwright install chromium`；必要时换 `--profile` |
| 页面结构变了 / `parse-rendered` 解析不到数字 | 小红书改版，互动栏文案或排版变化 | 用 `--likes/--collects/--comments` 直接传人工核对值；需要长期自动解析时改 `parse_rendered_text` 里的行匹配规则 |
| `parse-rendered` 提示「页面文本是风控拦截页」 | 保存下来的文本本身就是风控页 | 换一条渲染通道重新导出；服务端网页读取工具与本机浏览器出口不同，通常能拿到正常页 |
| 没有 playwright | 环境缺依赖 | doctor 会给出已装好依赖的解释器路径；也可完全跳过抓取，直接走 C 通道（`parse-rendered` + `write` 只用标准库） |

批量抓取被限流时把 `--delay` 调到 3–5 秒，不要并发多开浏览器。

## 飞书侧

| 现象 | 原因 | 处理 |
|---|---|---|
| `--json invalid JSON object ... unexpected end of JSON input` | Windows 上 `lark-cli.CMD` 用 `%*` 转发，笔记链接里的 `&` 被 cmd.exe 当成命令分隔符，JSON 被截断 | **1.1.0 已内置修复**：脚本自动直调 `node run.js` 绕开 cmd.exe；若同目录没有 run.js，则把 `--json` 改写成 `@临时文件`（放在账户 temp 目录，符合 lark-cli 的 @file allowlist）。旧版技能包请升级 |
| `record-search: --search-field is required unless --json is used` | 同一根因：长链接作 `--keyword` 时被 `&` 截断，后续参数丢失 | 1.1.0 已修复参数通道；同时长链接查重不再用 `record-search`，改走 `+record-list` 投影扫描 |
| `String must contain at most 50 character(s)` | `+record-search` 的 keyword 上限 50 字符，完整笔记链接远超限制 | 1.1.0 起查重顺序为 笔记ID > 标题 > 链接，且 >45 字符的值自动改用 `+record-list` 扫描后本地精确比对 |
| `--dry-run` 之后表里多了字段 | 1.0.0 的 bug：`--ensure-fields` 在预演时仍真的调用 `+field-create` | 1.1.0 已修复：`--dry-run` 完全无副作用，只返回虚拟字段用于预演。已多建的列可在飞书里手工删除，不影响数据 |
| 表里出现多余的「标题」列，原主字段空置 | 1.0.0 的 bug：`+field-create` 把新列插到最前，主字段兜底只认第一列，第二次预演又补建「标题」 | 1.1.0 已修复：主字段兜底取「第一个未被占用的纯文本列」，与列顺序无关。历史遗留列可保留或手工删除 |
| `找不到 lark-cli` | 飞书 Connector 未连接 / CLI 不在 PATH | 在 WorkBuddy 里连接「飞书」；命令行检查 `lark-cli --version` |
| `code=91403 / 99991679 / 1254005` | 权限或 scope 不足 | 用 `--as-identity user`（默认）；`lark-cli auth login` 重新授权；确认自己有该多维表格的编辑权限 |
| `auth status` 显示 `needs_refresh` | token 快过期 | 正常，下一次调用会自动刷新，不用处理 |
| `链接里没有 table= 参数` | 给的是 Base 首页链接 | 打开目标数据表，复制含 `?table=tblXXX` 的完整链接 |
| `code=800030104 not_found` | `table=` 指向的表已被删除 | 用 `fields` 子命令或 `lark-cli base +table-list` 找正确 table_id |
| 写入报字段类型错误 | 数字列是单选/复选框/公式 | 把列改成「数字」类型，或加 `--ensure-fields` 新建规范列；不要写公式/查找引用/附件列 |
| `表里未找到这些数值字段` | 字段叫法不在别名里 | 用 `--fields-map '{"likes":"点赞数","collects":"收藏数","comments":"评论数"}'` |
| 出现重复行 | 表里没有笔记ID/链接列，且标题重复或为空 | 加 `--ensure-fields` 建「笔记ID」列，之后 upsert 才会稳定去重 |
| 写入成功但表格里暂时没看到 | 多维表格部分更新是异步的 | 稍等刷新；以写入成功响应为准，不要立刻重复写入 |
| 表格里有多行空白记录 | 飞书建表时自带的空行 | 脚本不删除也不填充，按需在飞书里手工清理 |
| 想把每次统计留成历史 | 默认 upsert 会覆盖同一行 | 用 `--mode append`；配合 WorkBuddy 定时任务即可形成趋势表 |

## 环境与打包

- `write / fields / parse-rendered / doctor` 只用 Python 标准库 + `lark-cli`；`fetch / run / login` 才需要 `playwright`。
- 本机默认 Python 若没装 playwright，先跑 `doctor`，它会打印本机已装好依赖的解释器路径，用那个解释器执行抓取即可；写入用任意 Python 3.10+ 都行。
- 无 playwright / 被风控时的完整替代路径：WorkBuddy 网页读取工具或内置浏览器打开笔记 → 页面文本存文件 → `parse-rendered`（或按 data-contract.md 手工构造 JSON）→ `write --from-json`。
- 回归自测：`python -m unittest discover -s tests -v`，33 项纯函数测试，不联网、不写飞书。
- 技能包里不含 `~/.workbuddy/xhs-feishu-stats*` 下的运行时数据，可放心分享；对方需要自己的飞书登录态。
