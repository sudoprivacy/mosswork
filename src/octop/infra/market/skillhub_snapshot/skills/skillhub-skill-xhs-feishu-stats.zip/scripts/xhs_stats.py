#!/usr/bin/env python3
"""小红书笔记互动数据 → 指定飞书多维表格。

设计要点：
- 飞书写入只依赖已登录的 lark-cli（用户身份），不需要 app_secret，也不需要 Python 三方库。
- 小红书抓取优先用 Playwright 持久化登录态 + window.__INITIAL_STATE__，DOM 兜底锁定
  .engage-bar，绝不盲抓推荐流里的数字。
- 目标表格每次由链接指定（含 table=），字段按名称自动匹配，缺失字段可选自动创建。
- 只有抓取/登录子命令需要 playwright；write / fields / doctor 用标准库即可运行。

子命令：
  doctor                          环境体检
  login                           打开浏览器扫码登录小红书（只需做一次）
  fields <飞书表格链接>            只读：列出字段与自动识别到的角色
  fetch  <笔记链接...>             只抓取，产出 JSON，不写飞书
  parse-rendered <笔记链接...> --text-file <file>  风控兜底：解析渲染页文本产出 JSON
  write  <飞书表格链接> --from-json <file>   把 JSON 结果写入表格
  run    <飞书表格链接> <笔记链接...>        抓取 + 写入一步完成
"""
from __future__ import annotations

import argparse
import datetime as dt
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
STATE_HOME = Path.home() / ".workbuddy" / "xhs-feishu-stats"
DEFAULT_RESULT = STATE_HOME / "last_result.json"
OWN_PROFILE = Path.home() / ".workbuddy" / "xhs-feishu-stats-profile"
PUBLISHER_PROFILE = Path.home() / ".workbuddy" / "skills" / "xhs-feishu-publish-skill" / ".xhs_browser_profile"

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

NUMBER_ROLES = ("likes", "collects", "comments")
DEFAULT_FIELD_NAMES = {
    "title": "标题",
    "link": "笔记链接",
    "note_id": "笔记ID",
    "author": "作者",
    "likes": "点赞",
    "collects": "收藏",
    "comments": "评论",
    "captured_at": "采集时间",
    "status": "数据状态",
}
ROLE_ORDER = ("likes", "collects", "comments", "note_id", "link", "title", "author", "captured_at", "status")

# 字段名别名（小写、去分隔符后比对）
ROLE_ALIASES = {
    "likes": ("点赞", "点赞数", "点赞量", "获赞", "赞", "赞数", "likes", "likecount", "likedcount", "like"),
    "collects": ("收藏", "收藏数", "收藏量", "藏", "collects", "collectcount", "collectedcount", "favorites"),
    "comments": ("评论", "评论数", "评论量", "留言", "留言数", "comments", "commentcount"),
    "note_id": ("笔记id", "笔记编号", "笔记唯一标识", "noteid", "note_id"),
    "link": ("笔记链接", "小红书链接", "笔记地址", "原文链接", "链接", "地址", "url", "noteurl", "link"),
    "title": ("标题", "笔记标题", "笔记名称", "名称", "选题", "title", "name"),
    "author": ("作者", "博主", "账号", "昵称", "作者昵称", "author", "nickname"),
    "captured_at": ("采集时间", "统计时间", "抓取时间", "更新时间", "记录时间", "统计日期", "日期", "时间", "capturedat", "createdtime"),
    "status": ("数据状态", "采集状态", "抓取状态", "校验状态", "备注", "status", "remark"),
}
# 含这些词的字段是派生指标，不能当原始互动数写入
NEGATIVE_WORDS = ("率", "占比", "比例", "增长", "增量", "变化", "差值", "趋势", "环比", "同比", "平均", "总计", "汇总", "得分", "评分", "排名", "是否", "昨日", "上周")

WRITABLE_TYPES = {"text", "number", "currency", "percent", "rating", "datetime", "date", "url", "phone", "email"}
NUMBER_TYPES = {"number", "currency", "percent", "rating"}
DATETIME_TYPES = {"datetime", "date"}


class StatsError(RuntimeError):
    """可直接展示给用户的可预期错误。"""


# ────────────────────────── 通用工具 ──────────────────────────

def log(msg: str = "") -> None:
    print(msg, flush=True)


def norm_name(s: str) -> str:
    """字段名归一化：去空白/分隔符/括号内容，小写。"""
    s = re.sub(r"[（(\[].*?[）)\]]", "", str(s or ""))
    return re.sub(r"[\s_\-\u3000·/\\.]", "", s).strip().lower()


def cell_text(value) -> str:
    """把飞书单元格值（富文本数组 / dict / 数字）转成纯文本。"""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, dict):
        return cell_text(value.get("text") or value.get("name") or "")
    if isinstance(value, list):
        return "".join(cell_text(v) for v in value)
    return str(value)


def parse_count(value) -> int | None:
    """'1.2万'→12000, '1,234'→1234, ''/'赞'/None→None（不臆造数值）。"""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    t = str(value).strip().replace(",", "").replace(" ", "")
    if not t:
        return None
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([万wW千kK亿]?)", t)
    if not m:
        return None
    val = float(m.group(1))
    val *= {"万": 10000, "w": 10000, "千": 1000, "k": 1000, "亿": 100000000}.get(m.group(2).lower(), 1)
    return int(val)


def now_str() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ────────────────────────── URL 解析 ──────────────────────────

NOTE_ID_RE = re.compile(r"/(?:explore|discovery/item|item)/([0-9a-fA-F]{24})")
SHORT_HOSTS = ("xhslink.com", "xhslink.cn", "xhslink.com.cn", "xhs.cn")


def expand_short_url(url: str, timeout: int = 15) -> str:
    """短链跟随重定向得到真实笔记 URL（保留 xsec_token）。"""
    host = (urllib.parse.urlparse(url).hostname or "").lower()
    if not any(host == h or host.endswith("." + h) for h in SHORT_HOSTS):
        return url
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.geturl()
    except Exception as exc:  # noqa: BLE001
        raise StatsError(f"小红书短链解析失败（{exc}）。请改用浏览器地址栏里的完整笔记链接。")


def normalize_xhs_url(url: str) -> str:
    url = expand_short_url(url.strip().strip("'\"<>)"))
    parsed = urllib.parse.urlparse(url)
    if not NOTE_ID_RE.search(parsed.path):
        raise StatsError(f"不是可识别的小红书笔记链接：{url[:100]}")
    if "xsec_token" not in parsed.query:
        log(f"[warn] 链接缺少 xsec_token，小红书可能返回 404：{url[:100]}")
        log("       请从浏览器地址栏复制完整链接（含 ?xsec_token=...）。")
    return url


def note_id_of(url: str) -> str:
    m = NOTE_ID_RE.search(urllib.parse.urlparse(url).path)
    return m.group(1) if m else ""


def parse_feishu_url(url: str, identity: str = "user") -> dict:
    """从飞书多维表格链接解析 base_token / table_id；解析不出时交给 lark-cli。"""
    parsed = urllib.parse.urlparse(url.strip())
    qs = urllib.parse.parse_qs(parsed.query)
    base_token = ""
    m = re.search(r"/(?:base|wiki|bitable)/([A-Za-z0-9]{12,})", parsed.path)
    if m:
        base_token = m.group(1)
    table_id = (qs.get("table") or qs.get("table_id") or [""])[0]
    if not table_id:
        m2 = re.search(r"/(tbl[A-Za-z0-9]+)", parsed.path)
        if m2:
            table_id = m2.group(1)
    view_id = (qs.get("view") or qs.get("view_id") or [""])[0]

    if not base_token:
        data = cli_json(["base", "+url-resolve", "--url", url.strip()], identity)
        base_token = str(data.get("base_token") or "")
        table_id = table_id or str(
            data.get("table_id") or (data.get("block_id") if data.get("block_type") == "table" else "") or ""
        )
    if not base_token:
        raise StatsError(f"无法从链接解析出 base_token：{url[:120]}")
    if not table_id:
        tables = cli_json(["base", "+table-list", "--base-token", base_token], identity)
        items = _dig_list(tables)
        names = ", ".join(
            f"{it.get('table_id') or it.get('id')}({it.get('name') or it.get('table_name')})"
            for it in items if isinstance(it, dict)
        )
        raise StatsError(
            "链接里没有 table= 参数，无法确定写入哪张表。\n"
            f"可用数据表：{names or '（未取到）'}\n"
            "请在飞书里打开目标数据表，复制地址栏完整链接（形如 .../base/xxx?table=tblxxx&view=vewxxx）后重试。"
        )
    return {"base_token": base_token, "table_id": table_id, "view_id": view_id}


# ────────────────────────── lark-cli 层 ──────────────────────────

def _parse_cli_json(text: str):
    text = (text or "").strip()
    if not text:
        raise StatsError("lark-cli 无输出")
    try:
        return json.loads(text)
    except ValueError:
        pass
    starts = [i for i in (text.find("{"), text.find("[")) if i >= 0]
    if not starts:
        raise StatsError(f"lark-cli 输出无法解析：{text[:200]}")
    start = min(starts)
    for end in range(len(text), start, -1):
        try:
            return json.loads(text[start:end])
        except ValueError:
            continue
    raise StatsError(f"lark-cli 输出无法解析：{text[:200]}")


def lark_command(exe: str) -> tuple[list[str], bool]:
    """返回 (命令前缀, 是否已绕开 cmd.exe 二次解析)。

    Windows 上 lark-cli 通常是 `lark-cli.CMD`，批处理用 `%*` 转发参数；
    参数里的 `&`（小红书链接必带）会被 cmd.exe 当成命令分隔符截断，表现为
    `--json invalid JSON ... unexpected end of JSON input` 或
    `record-search: --search-field is required`。同目录带 node 入口时直接调
    `node run.js`，参数不再经过 cmd.exe，彻底避开该问题。
    """
    p = Path(exe)
    if p.suffix.lower() in (".cmd", ".bat"):
        run_js = p.parent / "node_modules" / "@larksuite" / "cli" / "scripts" / "run.js"
        local_node = p.parent / "node.exe"
        node_exe = str(local_node) if local_node.exists() else shutil.which("node")
        if run_js.exists() and node_exe:
            return [str(node_exe), str(run_js)], True
        return [exe], False
    return [exe], True


def shield_json_arguments(args: list[str], temp_files: list[str]) -> list[str]:
    """无法绕开 cmd.exe 时，把 --json 的值改写成 @临时文件，避免 `&` 截断。

    lark-cli 的 @file 只允许 cwd / 账户 temp / home 下的 files 目录；
    tempfile.gettempdir() 落在账户 temp 根下，属于允许范围。
    """
    out: list[str] = []
    i = 0
    while i < len(args):
        item = str(args[i])
        out.append(item)
        if item == "--json" and i + 1 < len(args) and not str(args[i + 1]).startswith("@"):
            fd, path = tempfile.mkstemp(prefix="xhs_lark_", suffix=".json")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(str(args[i + 1]))
            temp_files.append(path)
            out.append("@" + path)
            i += 1
        i += 1
    return out


def cli_json(args: list[str], identity: str = "user", timeout: int = 180) -> dict:
    """执行 lark-cli 并返回 data 段；失败时把飞书返回的可操作提示原样带出。"""
    exe = shutil.which("lark-cli")
    if not exe:
        raise StatsError("找不到 lark-cli。请在 WorkBuddy 里连接「飞书」Connector，或安装并登录 lark-cli 后重试。")
    env = os.environ.copy()
    env.setdefault("MSYS_NO_PATHCONV", "1")
    prefix, bypassed = lark_command(exe)
    temp_files: list[str] = []
    safe_args = list(args) if bypassed else shield_json_arguments(args, temp_files)
    cmd = [*prefix, *safe_args, "--as", identity]
    try:
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                                  errors="replace", env=env, timeout=timeout)
        except FileNotFoundError as exc:
            raise StatsError(f"无法启动 lark-cli：{exc}") from exc
        except subprocess.TimeoutExpired as exc:
            raise StatsError(f"lark-cli 执行超时：{' '.join(args[:2])}") from exc
    finally:
        for path in temp_files:
            try:
                os.unlink(path)
            except OSError:
                pass
    payload = _parse_cli_json(proc.stdout or proc.stderr)
    if proc.returncode != 0 or (isinstance(payload, dict) and payload.get("ok") is False):
        err = payload.get("error") if isinstance(payload, dict) else None
        if isinstance(err, dict):
            msg, hint, code = str(err.get("message") or ""), str(err.get("hint") or ""), err.get("code")
        else:
            msg, hint, code = str(err or ""), "", ""
        tail = (proc.stderr or "").strip()
        raise StatsError(
            f"lark-cli {' '.join(args[:2])} 失败：{msg or tail[:200]} (code={code})"
            + (f"\n  提示：{hint[:300]}" if hint else "")
            + ("\n  若提示权限不足，先运行 lark-cli auth login 重新授权。" if code in (91403, 99991679, 1254005) else "")
        )
    if isinstance(payload, dict):
        return payload.get("data") if isinstance(payload.get("data"), dict) else payload
    return {}


def _dig_list(payload, depth: int = 0) -> list:
    if depth > 6:
        return []
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("items", "records", "fields", "tables", "views", "data"):
            val = payload.get(key)
            if isinstance(val, list):
                return val
            if isinstance(val, dict):
                found = _dig_list(val, depth + 1)
                if found:
                    return found
    return []


def list_fields(base_token: str, table_id: str, identity: str = "user") -> list[dict]:
    data = cli_json(["base", "+field-list", "--base-token", base_token,
                     "--table-id", table_id, "--format", "json"], identity)
    fields = data.get("fields") or _dig_list(data)
    out = []
    for it in fields:
        if not isinstance(it, dict):
            continue
        out.append({
            "id": it.get("id") or it.get("field_id") or "",
            "name": it.get("name") or it.get("field_name") or "",
            "type": str(it.get("type") or "").lower(),
        })
    if not out:
        raise StatsError("未读到目标表字段。确认表格链接里的 table= 指向正确的数据表。")
    return out


def detect_roles(fields: list[dict]) -> dict[str, dict]:
    """把表里的真实字段映射到角色；精确匹配优先，再按包含匹配，排除派生指标。"""
    roles: dict[str, dict] = {}
    used: set[str] = set()
    for exact in (True, False):
        for role in ROLE_ORDER:
            if role in roles:
                continue
            aliases = tuple(norm_name(a) for a in ROLE_ALIASES[role])
            for f in fields:
                name = str(f.get("name") or "")
                n = norm_name(name)
                if not n or name in used or any(w in n for w in NEGATIVE_WORDS):
                    continue
                hit = n in aliases if exact else any(len(a) >= 2 and a in n for a in aliases)
                if hit:
                    roles[role] = f
                    used.add(name)
                    break
    # 主字段兜底：取第一个未被占用的纯文本列作为标题。
    # 不能只认 fields[0]：+field-create 可能把新列插到最前，导致真正的表格主字段
    # 漂移到第二列，进而让下一次 --ensure-fields 又建一个多余的「标题」列。
    if "title" not in roles:
        for f in fields:
            if (str(f.get("type") or "") in ("text", "url", "phone", "email")
                    and str(f.get("name") or "") not in used):
                roles["title"] = f
                break
    return roles


def ensure_fields(base_token: str, table_id: str, roles: dict[str, dict],
                  identity: str = "user", custom_names: dict | None = None,
                  dry_run: bool = False) -> dict[str, dict]:
    """补齐缺失字段（仅当用户显式加 --ensure-fields 时调用）。

    --dry-run 必须完全无副作用：只返回「虚拟字段」用于预演写入内容，
    绝不真的调用 +field-create。
    """
    names = dict(DEFAULT_FIELD_NAMES)
    names.update(custom_names or {})
    wanted = [r for r in ROLE_ORDER if r not in roles and r in names]
    if not wanted:
        return roles
    payload = [{"name": names[r], "type": "number" if r in NUMBER_ROLES else "text"} for r in wanted]
    if dry_run:
        log(f"[i] [dry-run] 将补建缺失字段（本次不改动表结构）：{', '.join(names[r] for r in wanted)}")
        virtual = dict(roles)
        for r, item in zip(wanted, payload):
            virtual[r] = {"id": "", "name": item["name"], "type": item["type"]}
        return virtual
    log(f"[i] 自动创建缺失字段：{', '.join(names[r] for r in wanted)}")
    cli_json(["base", "+field-create", "--base-token", base_token, "--table-id", table_id,
              "--json", json.dumps(payload, ensure_ascii=False)], identity)
    return detect_roles(list_fields(base_token, table_id, identity))


def search_record_id(base_token: str, table_id: str, field_name: str, keyword: str,
                     identity: str = "user") -> str | None:
    """按某字段查找已有记录；CLI 是模糊搜索，这里本地做精确比对。"""
    if not field_name or not keyword:
        return None
    data = cli_json(["base", "+record-search", "--base-token", base_token, "--table-id", table_id,
                     "--keyword", keyword, "--search-field", field_name,
                     "--field-id", field_name, "--format", "json", "--limit", "50"], identity)
    names = data.get("fields") or []
    rows = data.get("data") or []
    rids = data.get("record_id_list") or []
    target = norm_name(cell_text(keyword))
    pos = names.index(field_name) if field_name in names else 0
    for i, row in enumerate(rows):
        if not isinstance(row, list) or i >= len(rids):
            continue
        value = cell_text(row[pos]) if pos < len(row) else ""
        if norm_name(value) == target:
            return str(rids[i])
    return None


def scan_record_id(base_token: str, table_id: str, field_name: str, value: str,
                   identity: str = "user", max_pages: int = 5) -> str | None:
    """长值查重：+record-search 的 keyword 上限 50 字符，完整笔记链接会被拒。

    改用 +record-list 投影单列、分页拉回后本地做归一化精确比对。
    """
    if not field_name or not value:
        return None
    target = norm_name(cell_text(value))
    offset = 0
    for _ in range(max_pages):
        data = cli_json(["base", "+record-list", "--base-token", base_token, "--table-id", table_id,
                         "--field-id", field_name, "--format", "json", "--limit", "200",
                         "--offset", str(offset)], identity)
        names = data.get("fields") or []
        rows = data.get("data") or []
        rids = data.get("record_id_list") or []
        pos = names.index(field_name) if field_name in names else 0
        for i, row in enumerate(rows):
            if isinstance(row, list) and i < len(rids) and pos < len(row):
                if norm_name(cell_text(row[pos])) == target:
                    return str(rids[i])
        if not data.get("has_more") or not rows:
            break
        offset += len(rows)
    return None


def find_existing_record(base_token: str, table_id: str, roles: dict[str, dict],
                         row: dict, identity: str = "user") -> str | None:
    """去重优先级：笔记ID > 标题 > 笔记链接（短值优先，长链接走扫描）。"""
    for role, key in (("note_id", "note_id"), ("title", "title"), ("link", "url")):
        field = roles.get(role)
        value = row.get(key)
        if not field or not value:
            continue
        name, val = str(field["name"]), str(value)
        rid = (scan_record_id(base_token, table_id, name, val, identity)
               if len(val) > 45
               else search_record_id(base_token, table_id, name, val, identity))
        if rid:
            return rid
    return None


def build_fields_map(row: dict, roles: dict[str, dict], captured_at: str | None = None) -> tuple[dict, list[str]]:
    """按真实字段类型构造 CellValue；返回 (字段映射, 跳过的字段说明)。"""
    values = {
        "title": row.get("title"), "link": row.get("url"), "note_id": row.get("note_id"),
        "author": row.get("author"), "likes": row.get("likes"), "collects": row.get("collects"),
        "comments": row.get("comments"),
        "captured_at": captured_at or row.get("captured_at") or now_str(),
        "status": row.get("status") or "ok",
    }
    out: dict = {}
    skipped: list[str] = []
    for role, field in roles.items():
        name, ftype = str(field.get("name") or ""), str(field.get("type") or "")
        value = values.get(role)
        if not name or value is None or value == "":
            if role in NUMBER_ROLES and value is None:
                skipped.append(f"{name}(数值未取到，保留原值)")
            continue
        if ftype not in WRITABLE_TYPES:
            skipped.append(f"{name}(类型 {ftype} 不可直接写，已跳过)")
            continue
        if ftype in NUMBER_TYPES:
            out[name] = int(value) if isinstance(value, (int, float)) else parse_count(value)
            if out[name] is None:
                del out[name]
                skipped.append(f"{name}(值不是数字，已跳过)")
        elif ftype in DATETIME_TYPES:
            text = str(value)
            out[name] = text[:16] if ftype == "datetime" else text[:10]
        else:
            out[name] = str(value)
    return out, skipped


# ────────────────────────── 小红书抓取 ──────────────────────────

# 风控拦截页（本机 IP / 浏览器环境被判定风险）常见文案
RISK_MARKERS = ("安全限制", "网络存在风险", "300012")
RISK_HINT = (
    "小红书风控拦截（安全限制 300012）：本机浏览器/网络被判定风险，页面没有笔记数据。\n"
    "  兜底通道：用 WorkBuddy 的网页读取工具或内置浏览器打开同一链接，把页面文本存为 .txt，\n"
    "  再执行 parse-rendered '<笔记链接>' --text-file <页面文本.txt>，\n"
    "  最后 write '<飞书表格链接>' --from-json <结果.json>。详见 SKILL.md「风控兜底 SOP」。"
)
FALLBACK_HINT = (
    "三项互动数都未取到（页面把低数值显示成文字、未登录、页面改版或被风控）。\n"
    "  不要反复重试或猜测数值；走渲染页兜底：用 WorkBuddy 网页读取工具/内置浏览器打开同一链接，\n"
    "  把页面文本存为 .txt，执行 parse-rendered '<笔记链接>' --text-file <页面文本.txt>，\n"
    "  再 write '<飞书表格链接>' --from-json <结果.json>；也可用 --likes/--collects/--comments 传入人工核对值。"
)


def is_risk_page(title: str, body_text: str) -> bool:
    blob = f"{title or ''} {body_text or ''}"
    return any(marker in blob for marker in RISK_MARKERS)


EXTRACT_JS = r"""() => {
  const id = (location.pathname.match(/\/(?:explore|discovery\/item|item)\/([0-9a-f]{24})/) || [])[1] || '';
  const map = window.__INITIAL_STATE__?.note?.noteDetailMap || {};
  let n = map[id]?.note;
  if (!n || !n.interactInfo) {
    n = Object.values(map).map(v => v && v.note).find(x => x && (x.interactInfo || x.title)) || null;
  }
  const i = (n && n.interactInfo) || {};
  const domBar = document.querySelector('.engage-bar') || document.querySelector('[class*="engage-bar"]');
  const pick = sel => {
    const w = domBar && domBar.querySelector(sel);
    const c = w && (w.querySelector('span.count') || w);
    return c ? (c.textContent || '').trim() : null;
  };
  const filled = v => v !== undefined && v !== null && String(v).trim() !== '';
  const titleEl = document.querySelector('#detail-title') || document.querySelector('.note-content .title') || document.querySelector('h1');
  const title = (n && n.title) || (titleEl && titleEl.innerText.trim()) ||
                document.title.replace(/\s*[-–—]\s*小红书.*$/, '').trim();
  return {
    note_id: (n && n.noteId) || id || '',
    title: title || '',
    author: (n && n.user && (n.user.nickname || n.user.nickName || n.user.name)) || '',
    likes: filled(i.likedCount) ? i.likedCount : pick('.like-wrapper'),
    collects: filled(i.collectedCount) ? i.collectedCount : pick('.collect-wrapper'),
    comments: filled(i.commentCount) ? i.commentCount : pick('.chat-wrapper'),
    source: (n && n.interactInfo) ? 'initial_state' : 'dom'
  };
}"""

LOGIN_SELECTORS = ("text=扫码登录", "text=手机号登录", ".login-container", ".login-modal")


def is_login_page(page) -> bool:
    for sel in LOGIN_SELECTORS:
        try:
            loc = page.locator(sel)
            if loc.count() and loc.first.is_visible():
                return True
        except Exception:  # noqa: BLE001
            continue
    return False


def resolve_profile(explicit: str | None) -> Path:
    if explicit:
        return Path(explicit).expanduser()
    if (OWN_PROFILE / "Default").exists():
        return OWN_PROFILE
    if (PUBLISHER_PROFILE / "Default").exists():
        return PUBLISHER_PROFILE
    return OWN_PROFILE


def _interpreter_has_playwright(exe: Path) -> bool:
    try:
        proc = subprocess.run([str(exe), "-c", "import importlib.util;print(bool(importlib.util.find_spec('playwright')))"],
                              capture_output=True, text=True, timeout=20)
        return proc.returncode == 0 and "True" in proc.stdout
    except Exception:  # noqa: BLE001
        return False


def require_playwright() -> None:
    if importlib.util.find_spec("playwright") is None:
        home = Path.home()
        candidates = [
            home / ".workbuddy" / "binaries" / "python" / "envs" / "default" / "Scripts" / "python.exe",
            home / ".workbuddy" / "binaries" / "python" / "envs" / "default" / "bin" / "python",
            home / ".workbuddy" / "binaries" / "python" / "envs" / "default" / "python.exe",
        ]
        alt = next((p for p in candidates if p.exists() and _interpreter_has_playwright(p)), None)
        msg = (
            "当前 Python 缺少 playwright。\n"
            "  方案 A：pip install playwright && playwright install chromium\n"
            "  方案 B（免安装）：用 WorkBuddy 内置浏览器打开笔记读出点赞/收藏/评论，"
            "写成 JSON 后用 `write --from-json` 直接写飞书。"
        )
        if alt:
            msg += f"\n  本机已检测到装好依赖的解释器：{alt}\n  直接用 {alt} scripts/xhs_stats.py <子命令> 重新执行即可。"
        raise StatsError(msg)


def make_row(url: str, raw: dict) -> dict:
    row = {
        "note_id": str(raw.get("note_id") or note_id_of(url) or ""),
        "url": url,
        "title": str(raw.get("title") or "").strip(),
        "author": str(raw.get("author") or "").strip(),
        "captured_at": now_str(),
        "source": raw.get("source") or "unknown",
    }
    need_check = []
    for key in NUMBER_ROLES:
        value = parse_count(raw.get(key))
        row[key] = value
        if value is None:
            need_check.append(key)
    row["need_check"] = need_check
    row["status"] = "ok" if not need_check else ("failed" if len(need_check) == 3 else "partial")
    return row


def fetch_notes(urls: list[str], profile: Path, headless: bool = True,
                delay: float = 2.0, wait_login: int = 0, http_first: bool = False) -> dict:
    """抓取多个笔记；返回统一 JSON 结构。"""
    require_playwright()
    from playwright.sync_api import sync_playwright  # 延迟导入，写飞书不需要它

    rows: list[dict] = []
    errors: list[dict] = []
    with sync_playwright() as p:
        try:
            ctx = p.chromium.launch_persistent_context(
                user_data_dir=str(profile), headless=headless,
                args=["--disable-blink-features=AutomationControlled", "--start-maximized"],
                no_viewport=True,
            )
        except Exception as exc:  # noqa: BLE001
            raise StatsError(
                f"启动 Chromium 失败：{exc}\n"
                "  先运行 playwright install chromium；若 profile 被占用，关闭已打开的浏览器后重试。"
            ) from exc
        page = ctx.pages[0] if ctx.pages else ctx.new_page()

        for idx, url in enumerate(urls, 1):
            log(f"[{idx}/{len(urls)}] 抓取 {url[:110]}")
            try:
                if http_first:
                    raw = fetch_http_state(url)
                    if raw:
                        rows.append(make_row(url, raw))
                        continue
                page.goto(url, wait_until="domcontentloaded", timeout=60000)
                time.sleep(max(delay, 1.0))
                if is_login_page(page):
                    if wait_login > 0 and not headless:
                        log("[i] 检测到未登录，请在弹出的浏览器中扫码；登录成功后自动继续……")
                        deadline = time.time() + wait_login
                        while time.time() < deadline and is_login_page(page):
                            time.sleep(2)
                        if is_login_page(page):
                            raise StatsError("等待小红书扫码登录超时，请运行 `login` 子命令后重试。")
                        page.goto(url, wait_until="domcontentloaded", timeout=60000)
                        time.sleep(3)
                    else:
                        raise StatsError("小红书登录态失效。运行 `login` 子命令扫码登录（只需一次）后重试。")
                if "/404" in page.url or "访问的页面不见了" in page.title():
                    raise StatsError("笔记页返回 404：链接可能已失效，或缺少 xsec_token。请用浏览器地址栏的完整链接。")
                body_head = page.evaluate("() => (document.body.innerText || '').slice(0, 400)")
                if is_risk_page(page.title(), body_head):
                    raise StatsError(RISK_HINT)

                raw = None
                for _ in range(3):
                    raw = page.evaluate(EXTRACT_JS)
                    if raw and raw.get("source") == "initial_state":
                        break
                    page.evaluate("window.scrollTo(0, Math.min(600, document.body.scrollHeight))")
                    time.sleep(1.5)
                # 风控页常异步渲染，goto 后可能还没出文案，循环结束后再判一次
                if is_risk_page(page.title(),
                                page.evaluate("() => (document.body.innerText || '').slice(0, 400)")):
                    raise StatsError(RISK_HINT)
                if not raw:
                    raise StatsError(FALLBACK_HINT)
                row = make_row(url, raw)
                if row["status"] == "failed":
                    raise StatsError(FALLBACK_HINT)
                rows.append(row)
                log(f"      标题={row['title'][:28]!r} 赞={row['likes']} 藏={row['collects']} 评={row['comments']}"
                    + (f" 需核对={row['need_check']}" if row["need_check"] else ""))
            except Exception as exc:  # noqa: BLE001 - 单条失败不影响其他链接
                msg = str(exc)
                log(f"      [x] {msg[:400]}")
                errors.append({"url": url, "error": msg})
            if idx < len(urls):
                time.sleep(delay)
        ctx.close()
    return {"captured_at": now_str(), "rows": rows, "errors": errors, "summary": summarize(rows)}


def fetch_http_state(url: str, timeout: int = 20) -> dict | None:
    """可选快速通道：SSR 页面里若自带 noteDetailMap 互动数，就不必开浏览器。"""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            html = resp.read().decode("utf-8", "ignore")
    except Exception:  # noqa: BLE001
        return None
    m = re.search(r"window\.__INITIAL_STATE__\s*=\s*(\{.*?\})</script>", html, re.S)
    if not m:
        return None
    try:
        data = json.loads(m.group(1).replace("undefined", "null"))
    except ValueError:
        return None
    nid = note_id_of(url)
    notes = ((data.get("note") or {}).get("noteDetailMap") or {})
    note = (notes.get(nid) or {}).get("note") if isinstance(notes, dict) else None
    if not note or not note.get("interactInfo"):
        return None
    i = note["interactInfo"]
    user = note.get("user") or {}
    return {
        "note_id": note.get("noteId") or nid,
        "title": note.get("title") or "",
        "author": user.get("nickname") or user.get("nickName") or "",
        "likes": i.get("likedCount"), "collects": i.get("collectedCount"),
        "comments": i.get("commentCount"), "source": "http_ssr",
    }


# ───────────────────── 渲染页兜底（风控 / 无登录态） ─────────────────────

RENDERED_NUM = r"[0-9][0-9,\.]*[万wW千kK亿]?"


def parse_rendered_text(text: str, url: str, overrides: dict | None = None) -> dict:
    """把渲染后的页面文本解析成抓取 raw 字典。

    输入可以是 WorkBuddy 网页读取工具返回的 markdown，或内置浏览器导出的纯文本。
    只读取页面上真实出现的数字；解析不到的字段留 None（make_row 会标 need_check），
    绝不臆造 0。overrides 是人工核对后的 --likes/--collects/--comments/--title/--author。
    """
    over = {k: v for k, v in (overrides or {}).items() if v is not None and v != ""}
    raw_text = text or ""
    # 去掉 markdown 图片/链接，避免 base64、图片 URL 里的数字干扰互动栏取数
    clean = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", raw_text)
    clean = re.sub(r"\[[^\]]*\]\([^)]*\)", " ", clean)

    lines = [l.strip() for l in clean.splitlines()]
    nums: list[str] = []
    # 小红书 H5 笔记页底部互动栏：「说点什么...」之后紧跟 点赞/收藏/评论 三个数字
    start = next((i for i, l in enumerate(lines) if "说点什么" in l), None)
    if start is not None:
        for line in lines[start + 1: start + 30]:
            s = line.strip().strip("*").strip()
            if not s:
                continue
            parts = [p.strip().strip("*") for p in s.split()]
            if len(parts) >= 3 and all(re.fullmatch(RENDERED_NUM, p) for p in parts[:3]):
                nums = parts[:3]
                break
            if re.fullmatch(RENDERED_NUM, s):
                nums.append(s)
                if len(nums) == 3:
                    break
            elif nums:
                break
    likes, collects, comments = [parse_count(x) for x in (nums + ["", "", ""])[:3]]

    # 作者 / 标题：H5 页面通常为「作者名 → 关注 → 标题 → 正文」
    author, title = "", ""
    follow = next((i for i, l in enumerate(lines[:80]) if l == "关注"), None)
    if follow is not None:
        for line in reversed(lines[:follow]):
            if line and not line.startswith("!") and line != "关注" and len(line) <= 40:
                author = line
                break
        for line in lines[follow + 1: follow + 6]:
            if line and not line.startswith("!") and len(line) <= 120:
                title = line
                break
    if not author:
        m = re.search(r"!\[(?:Image\s*\d+\s*:\s*)?([^\]]{1,30})\]\(", raw_text)
        if m:
            author = m.group(1).strip().replace("\\", "")

    # 交叉核对线索：只记录，绝不拿它反推数值
    evidence = {}
    m = re.search(r"(\d+)\s*条精选评论", clean)
    if m:
        evidence["featured_comments"] = int(m.group(1))

    return {
        "note_id": note_id_of(url),
        "title": over.get("title") or title,
        "author": over.get("author") or author,
        "likes": over.get("likes", likes),
        "collects": over.get("collects", collects),
        "comments": over.get("comments", comments),
        "source": "rendered_page",
        "evidence": evidence,
    }


def make_row_from_rendered(url: str, text: str, overrides: dict | None = None) -> dict:
    raw = parse_rendered_text(text, url, overrides)
    row = make_row(url, raw)
    row["evidence"] = raw.get("evidence") or {}
    return row


def cmd_parse_rendered(args) -> None:
    """风控兜底入口：页面文本 → 标准结果 JSON → 再交给 write --from-json。"""
    urls = load_urls(args)
    texts = [Path(p).expanduser() for p in (args.text_file or [])]
    manual = any(v is not None for v in (args.likes, args.collects, args.comments))
    if not texts and not manual:
        raise StatsError(
            "请提供 --text-file <页面文本文件>（可重复，与链接一一对应），"
            "或用 --likes/--collects/--comments 传入人工核对的数值。"
        )
    if texts and len(texts) != len(urls):
        raise StatsError(f"--text-file 数量（{len(texts)}）必须与笔记链接数量（{len(urls)}）一致。")
    for path in texts:
        if not path.exists():
            raise StatsError(f"找不到页面文本文件：{path}")
    overrides = {
        "title": args.title, "author": args.author,
        "likes": args.likes, "collects": args.collects, "comments": args.comments,
    }
    rows: list[dict] = []
    errors: list[dict] = []
    for i, url in enumerate(urls, 1):
        text = texts[i - 1].read_text(encoding="utf-8", errors="replace") if texts else ""
        if text and is_risk_page("", text[:400]):
            errors.append({"url": url, "error": "页面文本是风控拦截页，不含笔记数据"})
            log(f"  [x] 第 {i} 篇是风控页，已跳过")
            continue
        row = make_row_from_rendered(url, text, overrides)
        log(f"  [{'ok' if row['status'] != 'failed' else 'x'}] {row['title'][:28]!r} "
            f"赞={row['likes']} 藏={row['collects']} 评={row['comments']}"
            + (f" 需核对={row['need_check']}" if row["need_check"] else ""))
        if row["status"] == "failed":
            errors.append({"url": url, "error": "页面文本未解析到互动数；请用 --likes/--collects/--comments 指定人工核对值"})
            continue
        rows.append(row)
    result = {"captured_at": now_str(), "rows": rows, "errors": errors, "summary": summarize(rows)}
    save_result(result, Path(args.out).expanduser() if args.out else DEFAULT_RESULT)
    print_summary(result)


def summarize(rows: list[dict]) -> dict:
    valid = [r for r in rows if r.get("status") in ("ok", "partial")]

    def total(key):
        return sum(int(r[key]) for r in valid if r.get(key) is not None)

    n = len(valid)
    return {
        "notes": n,
        "total_likes": total("likes"), "total_collects": total("collects"), "total_comments": total("comments"),
        "avg_likes": round(total("likes") / n, 1) if n else 0,
        "avg_collects": round(total("collects") / n, 1) if n else 0,
        "avg_comments": round(total("comments") / n, 1) if n else 0,
        "top_by_likes": [
            {"title": r.get("title", ""), "likes": r.get("likes")}
            for r in sorted(valid, key=lambda x: x.get("likes") or 0, reverse=True)[:3]
        ],
    }


# ────────────────────────── 写入与编排 ──────────────────────────

def save_result(result: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[ok] 抓取结果已保存：{path}")


def print_summary(result: dict) -> None:
    s = result.get("summary") or summarize(result.get("rows", []))
    log("\n========== 统计汇总 ==========")
    log(f"  有效笔记 : {s['notes']} 篇")
    log(f"  点赞合计 : {s['total_likes']}   篇均 {s['avg_likes']}")
    log(f"  收藏合计 : {s['total_collects']}   篇均 {s['avg_collects']}")
    log(f"  评论合计 : {s['total_comments']}   篇均 {s['avg_comments']}")
    if s["top_by_likes"]:
        log("  点赞 Top3: " + " | ".join(f"{t['title'][:16]}({t['likes']})" for t in s["top_by_likes"]))
    if result.get("errors"):
        log(f"  抓取失败 : {len(result['errors'])} 条（见 JSON 的 errors 段）")


def write_to_feishu(target: dict, result: dict, args) -> int:
    base_token, table_id = target["base_token"], target["table_id"]
    identity = args.as_identity
    fields = list_fields(base_token, table_id, identity)
    roles = detect_roles(fields)
    custom_names = {}
    if args.fields_map:
        try:
            custom_names = json.loads(args.fields_map)
        except ValueError as exc:
            raise StatsError(f"--fields-map 不是合法 JSON：{exc}") from exc
    if args.ensure_fields:
        roles = ensure_fields(base_token, table_id, roles, identity, custom_names,
                              dry_run=args.dry_run)
        if args.dry_run:
            # 虚拟字段只用于预演，不能回读表格；补进本地列表供 --fields-map 覆盖使用
            for field in roles.values():
                if field.get("id") == "" and not any(f["name"] == field["name"] for f in fields):
                    fields.append(field)
        else:
            fields = list_fields(base_token, table_id, identity)
            roles = detect_roles(fields)
    if custom_names:
        for role, name in custom_names.items():
            hit = next((f for f in fields if str(f.get("name")) == name), None)
            if hit:
                roles[role] = hit

    mapping_desc = ", ".join(f"{r}→{roles[r]['name']}" for r in ROLE_ORDER if r in roles)
    log(f"[i] 字段识别：{mapping_desc or '（无）'}")
    missing = [r for r in NUMBER_ROLES if r not in roles]
    if missing:
        log(f"[warn] 表里未找到这些数值字段：{', '.join(missing)}。"
            "加 --ensure-fields 自动补建，或用 --fields-map '{\"likes\":\"你的字段名\"}' 指定。")
    if not roles:
        raise StatsError("未识别到任何可写字段，已中止写入（避免写出空记录）。")

    writable_roles = {r: f for r, f in roles.items() if str(f["type"]) in WRITABLE_TYPES}
    if not any(r in writable_roles for r in NUMBER_ROLES):
        raise StatsError("目标表没有可写的点赞/收藏/评论数字字段，已中止。用 --ensure-fields 自动补建。")

    rows = [r for r in result.get("rows", []) if r.get("status") in ("ok", "partial")]
    if args.summary_row:
        s = result.get("summary") or summarize(rows)
        rows = rows + [{
            "note_id": "", "url": "", "title": f"【汇总】{result.get('captured_at') or now_str()}",
            "author": "", "likes": s["total_likes"], "collects": s["total_collects"],
            "comments": s["total_comments"], "status": "summary", "captured_at": now_str(),
        }]
    if not rows:
        log("[warn] 没有可写入的有效数据，未改动飞书表格。")
        return 0

    log(f"\n[i] 目标表 {table_id}，待写 {len(rows)} 行，模式={args.mode}"
        + ("（dry-run，只预演不写入）" if args.dry_run else ""))
    failures = 0
    for idx, row in enumerate(rows, 1):
        fields_map, skipped = build_fields_map(row, writable_roles, result.get("captured_at"))
        if skipped:
            log(f"  [warn] 第 {idx} 行跳过：{'; '.join(skipped[:4])}")
        if not fields_map:
            log(f"  [x] 第 {idx} 行没有可写字段，跳过")
            failures += 1
            continue
        record_id = None
        if args.mode == "upsert":
            try:
                record_id = find_existing_record(base_token, table_id, writable_roles, row, identity)
            except StatsError as exc:
                log(f"  [warn] 查重失败（{str(exc)[:120]}），按新增处理")
        cmd = ["base", "+record-upsert", "--base-token", base_token, "--table-id", table_id,
               "--json", json.dumps(fields_map, ensure_ascii=False)]
        if record_id:
            cmd += ["--record-id", record_id]
        if args.dry_run:
            log(f"  [dry-run] {'更新' if record_id else '新增'} {row.get('title', '')[:24]!r}: "
                + json.dumps(fields_map, ensure_ascii=False))
            if args.print_payload:
                log("    lark-cli " + " ".join(cmd + ["--as", identity]))
                log("    [i] Windows 下手工执行该命令时，链接里的 & 会被 cmd.exe 截断；"
                    "建议直接让脚本正式写入（已自动绕开 cmd.exe），或把 --json 内容存到账户 temp 目录改用 --json @文件。")
            continue
        try:
            cli_json(cmd, identity)
            log(f"  [ok] {'更新' if record_id else '新增'} {row.get('title', '')[:24]!r}")
        except StatsError as exc:
            failures += 1
            log(f"  [x] 写入失败 {row.get('title', '')[:24]!r}：{str(exc)[:260]}")
    if not args.dry_run:
        log(f"\n[i] 写入完成：成功 {len(rows) - failures}/{len(rows)} 行")
    return failures


# ────────────────────────── CLI ──────────────────────────

def load_urls(args) -> list[str]:
    urls = list(args.urls or [])
    if args.urls_file:
        path = Path(args.urls_file).expanduser()
        if not path.exists():
            raise StatsError(f"找不到链接文件：{path}")
        urls += [line.strip() for line in path.read_text(encoding="utf-8").splitlines()
                 if line.strip() and not line.strip().startswith("#")]
    if not urls:
        raise StatsError("请提供至少一个小红书笔记链接（或用 --urls-file 指定每行一个链接的文件）。")
    out = []
    for u in urls:
        try:
            out.append(normalize_xhs_url(u))
        except StatsError as exc:
            log(f"[warn] 跳过无效链接：{exc}")
    if not out:
        raise StatsError("没有可用的小红书笔记链接。")
    return out


def cmd_doctor(args) -> None:
    log("========== 环境体检 ==========")
    exe = shutil.which("lark-cli")
    log(f"  lark-cli      : {exe or '未安装/未连接'}")
    if exe:
        _, bypassed = lark_command(exe)
        log(f"  参数通道      : {'直调 node，已绕开 cmd.exe' if bypassed else '批处理转发，--json 自动改走 @临时文件'}")
        try:
            proc = subprocess.run([exe, "auth", "status", "--json"], capture_output=True,
                                  text=True, encoding="utf-8", errors="replace", timeout=60)
            info = _parse_cli_json(proc.stdout)
            ids = info.get("identities") or {}
            log(f"  飞书用户身份  : {'可用' if (ids.get('user') or {}).get('available') else '不可用（运行 lark-cli auth login）'}")
            log(f"  飞书应用身份  : {'可用' if (ids.get('bot') or {}).get('available') else '不可用'}")
        except Exception as exc:  # noqa: BLE001
            log(f"  飞书登录态    : 检查失败 {str(exc)[:120]}")
    log(f"  playwright    : {'已安装' if importlib.util.find_spec('playwright') else '未安装（抓取需要；写飞书不需要）'}")
    prof = resolve_profile(args.profile)
    log(f"  浏览器 profile: {prof} ({'已存在' if (prof / 'Default').exists() else '尚未登录'})")
    if not (prof / "Default").exists():
        log("  → 首次使用先运行：python scripts/xhs_stats.py login")
    log("  Python        : " + sys.version.split()[0])


def cmd_login(args) -> None:
    require_playwright()
    from playwright.sync_api import sync_playwright
    prof = resolve_profile(args.profile)
    prof.mkdir(parents=True, exist_ok=True)
    log(f"打开小红书登录页（浏览器 profile: {prof}）")
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            user_data_dir=str(prof), headless=False,
            args=["--disable-blink-features=AutomationControlled", "--start-maximized"], no_viewport=True,
        )
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto("https://www.xiaohongshu.com/explore", wait_until="domcontentloaded", timeout=60000)
        time.sleep(3)
        if is_login_page(page):
            log("请在浏览器里扫码登录；检测到登录完成后自动结束（最多 5 分钟）。")
            deadline = time.time() + 300
            while time.time() < deadline and is_login_page(page):
                time.sleep(2)
            log("[ok] 登录完成" if not is_login_page(page) else "[warn] 等待超时，可重试 login")
        else:
            log("[ok] 已是登录态，无需重复登录")
        time.sleep(2)
        ctx.close()


def cmd_fields(args) -> None:
    target = parse_feishu_url(args.feishu_url, args.as_identity)
    fields = list_fields(target["base_token"], target["table_id"], args.as_identity)
    roles = detect_roles(fields)
    log(f"表格 {target['base_token']} / {target['table_id']} 共 {len(fields)} 个字段：")
    for f in fields:
        role = next((r for r, x in roles.items() if x["name"] == f["name"]), "—")
        flag = "  (不可直接写)" if f["type"] not in WRITABLE_TYPES else ""
        log(f"  {f['name']:<16} type={f['type']:<12} 角色={role}{flag}")
    log("\n提示：数字字段必须是 number 类型；加 --ensure-fields 可自动补建缺失字段。")


def cmd_fetch(args) -> None:
    urls = load_urls(args)
    result = fetch_notes(urls, resolve_profile(args.profile), headless=not args.headed,
                         delay=args.delay, wait_login=args.wait_login, http_first=args.http_first)
    save_result(result, Path(args.out).expanduser() if args.out else DEFAULT_RESULT)
    print_summary(result)


def cmd_write(args) -> None:
    src = Path(args.from_json).expanduser() if args.from_json else DEFAULT_RESULT
    if not src.exists():
        raise StatsError(f"找不到数据文件 {src}；先跑 fetch/run，或用 --from-json 指定 JSON。")
    try:
        result = json.loads(src.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise StatsError(f"数据文件不是合法 JSON：{exc}") from exc
    target = parse_feishu_url(args.feishu_url, args.as_identity)
    failures = write_to_feishu(target, result, args)
    print_summary(result)
    if failures:
        raise StatsError(f"{failures} 行写入失败，详见上方错误。可修正后用同一份 JSON 重跑（upsert 不会重复建行）。")


def cmd_run(args) -> None:
    urls = load_urls(args)
    target = parse_feishu_url(args.feishu_url, args.as_identity)
    result = fetch_notes(urls, resolve_profile(args.profile), headless=not args.headed,
                         delay=args.delay, wait_login=args.wait_login, http_first=args.http_first)
    save_result(result, Path(args.out).expanduser() if args.out else DEFAULT_RESULT)
    print_summary(result)
    failures = write_to_feishu(target, result, args)
    if failures:
        raise StatsError(f"{failures} 行写入失败；抓取结果已保存，可用 write --from-json 重跑。")


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="小红书笔记点赞/收藏/评论 → 指定飞书多维表格",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="示例：python scripts/xhs_stats.py run '<飞书表格链接>' '<小红书笔记链接>' --dry-run",
    )
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p, with_feishu=False):
        if with_feishu:
            p.add_argument("feishu_url", help="飞书多维表格链接（必须含 table=...）")
            p.add_argument("--as-identity", dest="as_identity", choices=["user", "bot"], default="user",
                           help="飞书身份，默认 user（与 lark-base skill 一致）")
            p.add_argument("--mode", choices=["upsert", "append"], default="upsert",
                           help="upsert=按笔记ID/链接/标题去重更新；append=每次新增一行快照")
            p.add_argument("--ensure-fields", action="store_true", help="自动补建缺失的数值/文本字段")
            p.add_argument("--fields-map", default="", help='自定义字段名映射，如 \'{"likes":"点赞数"}\'')
            p.add_argument("--summary-row", action="store_true", help="额外写一行汇总记录")
        p.add_argument("--dry-run", action="store_true", help="只预演，不写飞书")
        p.add_argument("--print-payload", action="store_true", help="dry-run 时打印可直接执行的 lark-cli 命令")
        p.add_argument("--profile", default=None, help="Playwright 登录态目录")
        p.add_argument("--headed", action="store_true", help="显示浏览器窗口（调试用）")
        p.add_argument("--delay", type=float, default=2.0, help="每条笔记之间等待秒数，默认 2")
        p.add_argument("--wait-login", type=int, default=0, help="未登录时等待扫码秒数（配合 --headed）")
        p.add_argument("--http-first", action="store_true", help="先尝试 HTTP SSR 抓取，失败再用浏览器")
        p.add_argument("--out", default=None, help="抓取结果 JSON 输出路径")
        p.add_argument("urls", nargs="*", help="小红书笔记链接（可多个）")
        p.add_argument("--urls-file", default=None, help="每行一个链接的文本文件")

    common(sub.add_parser("doctor", help="环境体检"))
    common(sub.add_parser("login", help="扫码登录小红书（只需一次）"))
    common(sub.add_parser("fields", help="只读：列出表格字段与自动识别结果"), with_feishu=True)
    common(sub.add_parser("fetch", help="只抓取，产出 JSON"))
    p_render = sub.add_parser("parse-rendered", help="风控兜底：把渲染后的页面文本解析成标准 JSON")
    common(p_render, with_feishu=False)
    p_render.add_argument("--text-file", action="append", default=None,
                          help="页面文本文件（markdown/纯文本），可重复，与链接一一对应")
    p_render.add_argument("--title", default=None, help="人工核对后的笔记标题")
    p_render.add_argument("--author", default=None, help="人工核对后的作者")
    p_render.add_argument("--likes", type=int, default=None, help="人工核对后的点赞数")
    p_render.add_argument("--collects", type=int, default=None, help="人工核对后的收藏数")
    p_render.add_argument("--comments", type=int, default=None, help="人工核对后的评论数")
    p_write = sub.add_parser("write", help="把 JSON 结果写入飞书表格")
    common(p_write, with_feishu=True)
    p_write.add_argument("--from-json", default=None, help="数据来源 JSON；缺省用上次抓取结果")
    common(sub.add_parser("run", help="抓取 + 写入一步完成"), with_feishu=True)
    return ap


def main() -> int:
    args = build_parser().parse_args()
    handlers = {
        "doctor": cmd_doctor, "login": cmd_login, "fields": cmd_fields,
        "fetch": cmd_fetch, "parse-rendered": cmd_parse_rendered,
        "write": cmd_write, "run": cmd_run,
    }
    try:
        handlers[args.cmd](args)
        return 0
    except StatsError as exc:
        log(f"\n[x] {exc}")
        return 1
    except KeyboardInterrupt:
        log("\n[中断] 已停止")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
