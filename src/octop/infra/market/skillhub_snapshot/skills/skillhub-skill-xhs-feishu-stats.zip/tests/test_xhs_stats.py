#!/usr/bin/env python3
"""纯函数自测：不联网、不开浏览器、不写飞书。

运行：python -m unittest discover -s tests -v
"""
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

SCRIPT = Path(__file__).resolve().parent.parent / "scripts" / "xhs_stats.py"
spec = importlib.util.spec_from_file_location("xhs_stats", SCRIPT)
mod = importlib.util.module_from_spec(spec)
sys.modules["xhs_stats"] = mod
spec.loader.exec_module(mod)

NOTE = "https://www.xiaohongshu.com/explore/6ad2109c000000001500e815?xsec_token=ABtest&xsec_source=pc_feed"
FEISHU = "https://foo.feishu.cn/base/Rw1mbI9FVaBEVns9lmqcFPEQnb1?table=tblquGsIurcMTxJa&view=vewABC"


class TestUrls(unittest.TestCase):
    def test_normalize_xhs_url_keeps_token(self):
        self.assertEqual(mod.normalize_xhs_url("  " + NOTE + "  "), NOTE)

    def test_note_id(self):
        self.assertEqual(mod.note_id_of(NOTE), "6ad2109c000000001500e815")
        self.assertEqual(mod.note_id_of("https://www.xiaohongshu.com/discovery/item/6ad2109c000000001500e815"),
                         "6ad2109c000000001500e815")

    def test_reject_non_note(self):
        with self.assertRaises(mod.StatsError):
            mod.normalize_xhs_url("https://www.xiaohongshu.com/explore")

    def test_parse_feishu_url(self):
        self.assertEqual(mod.parse_feishu_url(FEISHU), {
            "base_token": "Rw1mbI9FVaBEVns9lmqcFPEQnb1",
            "table_id": "tblquGsIurcMTxJa", "view_id": "vewABC",
        })

    def test_parse_feishu_url_alias(self):
        got = mod.parse_feishu_url("https://foo.feishu.cn/wiki/AbcdEfgh1234?table_id=tblXYZ&view_id=vew1")
        self.assertEqual(got["table_id"], "tblXYZ")
        self.assertEqual(got["base_token"], "AbcdEfgh1234")


class TestNumbers(unittest.TestCase):
    def test_parse_count(self):
        cases = {
            "140": 140, 140: 140, "1,234": 1234, "1.2万": 12000, "2.3w": 23000,
            "1.5千": 1500, "3k": 3000, "1亿": 100000000,
            "": None, None: None, "赞": None, "收藏": None, "10+": None, "abc": None,
        }
        for raw, expected in cases.items():
            self.assertEqual(mod.parse_count(raw), expected, f"input={raw!r}")

    def test_make_row_partial(self):
        row = mod.make_row(NOTE, {"title": "T", "likes": "140", "collects": "", "comments": "赞"})
        self.assertEqual(row["status"], "partial")
        self.assertEqual(row["likes"], 140)
        self.assertIsNone(row["collects"])
        self.assertEqual(row["need_check"], ["collects", "comments"])

    def test_make_row_failed(self):
        row = mod.make_row(NOTE, {"title": "T"})
        self.assertEqual(row["status"], "failed")

    def test_summarize(self):
        rows = [
            {"status": "ok", "title": "A", "likes": 10, "collects": 2, "comments": 1},
            {"status": "partial", "title": "B", "likes": 30, "collects": None, "comments": 3},
            {"status": "failed", "title": "C", "likes": None, "collects": None, "comments": None},
        ]
        s = mod.summarize(rows)
        self.assertEqual(s["notes"], 2)
        self.assertEqual(s["total_likes"], 40)
        self.assertEqual(s["total_collects"], 2)
        self.assertEqual(s["total_comments"], 4)
        self.assertEqual(s["avg_likes"], 20.0)
        self.assertEqual(s["top_by_likes"][0]["title"], "B")


class TestFieldMapping(unittest.TestCase):
    def setUp(self):
        self.fields = [
            {"id": "f1", "name": "标题", "type": "text"},
            {"id": "f2", "name": "笔记ID", "type": "text"},
            {"id": "f3", "name": "笔记链接", "type": "text"},
            {"id": "f4", "name": "点赞", "type": "number"},
            {"id": "f5", "name": "收藏数", "type": "number"},
            {"id": "f6", "name": "评论数", "type": "number"},
            {"id": "f7", "name": "点赞率", "type": "number"},
            {"id": "f8", "name": "综合得分", "type": "formula"},
            {"id": "f9", "name": "图片", "type": "attachment"},
            {"id": "f10", "name": "采集时间", "type": "text"},
        ]

    def test_detect_roles(self):
        roles = mod.detect_roles(self.fields)
        self.assertEqual(roles["likes"]["name"], "点赞")
        self.assertEqual(roles["collects"]["name"], "收藏数")
        self.assertEqual(roles["comments"]["name"], "评论数")
        self.assertNotIn(next((r for r, f in roles.items() if f["name"] == "点赞率"), None),
                         ("likes", "collects", "comments"))
        self.assertNotIn("综合得分", [f["name"] for f in roles.values()])

    def test_english_aliases(self):
        fields = [{"id": "a", "name": "likes", "type": "number"},
                  {"id": "b", "name": "collectedCount", "type": "number"},
                  {"id": "c", "name": "comment_count", "type": "number"}]
        roles = mod.detect_roles(fields)
        self.assertEqual([roles[r]["name"] for r in ("likes", "collects", "comments")],
                         ["likes", "collectedCount", "comment_count"])

    def test_primary_field_fallback(self):
        fields = [{"id": "a", "name": "随便一个主字段", "type": "text"},
                  {"id": "b", "name": "点赞", "type": "number"}]
        roles = mod.detect_roles(fields)
        self.assertEqual(roles["title"]["name"], "随便一个主字段")

    def test_build_fields_map_types(self):
        roles = mod.detect_roles(self.fields)
        row = {
            "title": "标题A", "note_id": "abc123", "url": NOTE, "author": "某人",
            "likes": 140, "collects": 33, "comments": 18, "status": "ok",
        }
        out, skipped = mod.build_fields_map(row, roles, "2026-11-12 08:30:00")
        self.assertEqual(out["点赞"], 140)
        self.assertEqual(out["收藏数"], 33)
        self.assertEqual(out["笔记链接"], NOTE)
        self.assertEqual(out["采集时间"], "2026-11-12 08:30:00")
        self.assertNotIn("综合得分", out)
        self.assertNotIn("图片", out)

    def test_partial_row_does_not_overwrite(self):
        roles = mod.detect_roles(self.fields)
        row = {"title": "T", "likes": 5, "collects": None, "comments": 1, "status": "partial"}
        out, skipped = mod.build_fields_map(row, roles)
        self.assertNotIn("收藏数", out)
        self.assertTrue(any("收藏数" in s for s in skipped))

    def test_datetime_field(self):
        fields = [{"id": "x", "name": "采集时间", "type": "datetime"},
                  {"id": "y", "name": "点赞", "type": "number"}]
        roles = mod.detect_roles(fields)
        out, _ = mod.build_fields_map({"likes": 3}, roles, "2026-11-12 08:30:00")
        self.assertEqual(out["采集时间"], "2026-11-12 08:30")


class TestCliParsing(unittest.TestCase):
    def test_parse_cli_json_with_noise(self):
        text = "some notice line\n" + json.dumps({"ok": True, "data": {"fields": []}})
        self.assertEqual(mod._parse_cli_json(text)["data"], {"fields": []})

    def test_cell_text_rich_text(self):
        self.assertEqual(mod.cell_text([{"type": "text", "text": "ab"}, {"text": "cd"}]), "abcd")
        self.assertEqual(mod.cell_text(12), "12")

    def test_search_record_id_exact_match(self):
        payload = {"fields": ["笔记ID"], "data": [["abc123"], ["abc123456"]],
                   "record_id_list": ["recA", "recB"]}
        with mock.patch.object(mod, "cli_json", return_value=payload):
            rid = mod.search_record_id("base", "tbl", "笔记ID", "abc123", "user")
        self.assertEqual(rid, "recA")

    def test_norm_name(self):
        self.assertEqual(mod.norm_name(" 点赞数（最新） "), "点赞数")
        self.assertEqual(mod.norm_name("like_count"), "likecount")


class TestLarkCliTransport(unittest.TestCase):
    """Windows lark-cli.CMD 会把参数里的 & 截断，必须绕开 cmd.exe 或改走 @file。"""

    def test_cmd_bypassed_by_node(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            scripts = root / "node_modules" / "@larksuite" / "cli" / "scripts"
            scripts.mkdir(parents=True)
            (root / "node.exe").write_bytes(b"")
            (scripts / "run.js").write_text("// stub", encoding="utf-8")
            prefix, bypassed = mod.lark_command(str(root / "lark-cli.CMD"))
        self.assertTrue(bypassed)
        self.assertEqual(len(prefix), 2)
        self.assertIn("run.js", prefix[1])

    def test_cmd_without_runjs_falls_back_to_file_shield(self):
        with tempfile.TemporaryDirectory() as d:
            exe = str(Path(d) / "lark-cli.CMD")
            prefix, bypassed = mod.lark_command(exe)
        self.assertFalse(bypassed)
        self.assertEqual(prefix, [exe])

    def test_non_cmd_executable_is_safe(self):
        with tempfile.TemporaryDirectory() as d:
            exe = str(Path(d) / "lark-cli")
            prefix, bypassed = mod.lark_command(exe)
        self.assertTrue(bypassed)
        self.assertEqual(prefix, [exe])

    def test_shield_json_arguments_with_ampersand(self):
        payload = json.dumps({"笔记链接": NOTE}, ensure_ascii=False)
        temps = []
        try:
            out = mod.shield_json_arguments(
                ["base", "+record-upsert", "--json", payload, "--as", "user"], temps)
            written = out[out.index("--json") + 1]
            self.assertTrue(written.startswith("@"))
            self.assertEqual(Path(written[1:]).read_text(encoding="utf-8"), payload)
            self.assertEqual(len(temps), 1)
        finally:
            for p in temps:
                Path(p).unlink(missing_ok=True)


class TestDryRunSafety(unittest.TestCase):
    def test_ensure_fields_dry_run_never_changes_table(self):
        roles = {"title": {"id": "f1", "name": "文本", "type": "text"}}
        with mock.patch.object(mod, "cli_json") as cli, mock.patch.object(mod, "list_fields") as lf:
            got = mod.ensure_fields("base", "tbl", roles, "user", dry_run=True)
        cli.assert_not_called()
        lf.assert_not_called()
        self.assertIn("likes", got)
        self.assertEqual(got["likes"]["type"], "number")
        self.assertEqual(got["title"]["name"], "文本")

    def test_ensure_fields_real_run_creates_fields(self):
        roles = {"title": {"id": "f1", "name": "文本", "type": "text"}}
        new_fields = [{"id": "f1", "name": "文本", "type": "text"},
                      {"id": "f2", "name": "点赞", "type": "number"}]
        with mock.patch.object(mod, "cli_json") as cli, \
             mock.patch.object(mod, "list_fields", return_value=new_fields):
            got = mod.ensure_fields("base", "tbl", roles, "user", dry_run=False)
        self.assertEqual(cli.call_count, 1)
        self.assertIn("likes", got)


class TestPrimaryFieldDrift(unittest.TestCase):
    def test_primary_field_still_found_when_new_columns_inserted_first(self):
        fields = [
            {"id": "a", "name": "笔记链接", "type": "text"},
            {"id": "b", "name": "文本", "type": "text"},
            {"id": "c", "name": "点赞", "type": "number"},
        ]
        roles = mod.detect_roles(fields)
        self.assertEqual(roles["title"]["name"], "文本")
        wanted = [r for r in mod.ROLE_ORDER if r not in roles]
        self.assertNotIn("title", wanted)  # 不会重复补建「标题」列


class TestRenderedPageFallback(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.text = (Path(__file__).resolve().parent / "rendered_note.md").read_text(encoding="utf-8")

    def test_parse_interaction_numbers(self):
        raw = mod.parse_rendered_text(self.text, NOTE)
        self.assertEqual((raw["likes"], raw["collects"], raw["comments"]), (26, 30, 2))
        self.assertEqual(raw["title"], "全网最全的视频反推提示词")
        self.assertEqual(raw["author"], "居小爆(AI 版)")
        self.assertEqual(raw["evidence"]["featured_comments"], 2)
        self.assertEqual(raw["source"], "rendered_page")

    def test_make_row_ok(self):
        row = mod.make_row_from_rendered(NOTE, self.text)
        self.assertEqual(row["status"], "ok")
        self.assertEqual(row["need_check"], [])
        self.assertEqual(row["likes"], 26)

    def test_manual_overrides_win(self):
        row = mod.make_row_from_rendered(NOTE, self.text, {"likes": 99, "title": "人工标题"})
        self.assertEqual(row["likes"], 99)
        self.assertEqual(row["collects"], 30)
        self.assertEqual(row["title"], "人工标题")

    def test_no_numbers_is_failed_not_zero(self):
        row = mod.make_row_from_rendered(NOTE, "随便一段没有互动栏的文字")
        self.assertEqual(row["status"], "failed")
        self.assertIsNone(row["likes"])

    def test_partial_keeps_none(self):
        row = mod.make_row_from_rendered(NOTE, "说点什么...\n**26**\n文字")
        self.assertEqual(row["status"], "partial")
        self.assertEqual(row["likes"], 26)
        self.assertIsNone(row["collects"])

    def test_manual_numbers_without_text(self):
        row = mod.make_row_from_rendered(NOTE, "", {"likes": 12, "collects": 3, "comments": 1})
        self.assertEqual(row["status"], "ok")

    def test_risk_page_detected(self):
        self.assertTrue(mod.is_risk_page("安全限制", "当前网络存在风险，请切换可靠网络后重试 300012"))
        self.assertTrue(mod.is_risk_page("", "安全限制\n当前网络存在风险\n300012"))
        self.assertFalse(mod.is_risk_page("笔记标题", "正常笔记正文"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
