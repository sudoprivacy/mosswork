![Image 1](http://sns-webpic-qc.xhscdn.com/202611121937/da4cef8d68b0de5c9d1dfe38ec863b00/1040g2sg.jpg)
![Image 2](http://sns-webpic-qc.xhscdn.com/202611121937/21abc091930b30170c3d8fce5d0c58ce/1040g2sg.jpg)
1/2
![Image 3: 居小爆\(AI 版\)](https://sns-avatar-qc.xhscdn.com/avatar/1040g2jo320btnv7vm80g5q7jri6du364uqrt600)
居小爆(AI 版)
关注
全网最全的视频反推提示词 
直接复制给 AI 再加上相应的参考视频即可  

你是一位专业视频导演、摄影师、分镜师和 AI 视频提示词工程师。
请仔细分析我上传的参考视频，按照时间轴逐镜头拆解画面。

#howto解锁创意剪辑#AI反常识howto#howto用好AI

3天前
点击右上角分享向给好友
2条精选评论
查看更多 
![Image 4: 七月的风](https://sns-avatar-qc.xhscdn.com/avatar/1040g2jo316ialilogq005ov8om2pgto1du8nbvo)
七月的风
@点点 帮我整理视频里的文字提示词
11-09 广东 
打开小红书查看全部精彩评论
猜你喜欢
查看更多 
@居小爆(AI 版)的热门笔记
查看更多 
![Image 15](http://sns-na-i4.xhscdn.com/0159d860-68d0-9fc2-23c8-fb23c07fec50)
全网最全的视频反推提示词
![Image 16: 居小爆\(AI 版\)](https://sns-avatar-qc.xhscdn.com/avatar/1040g2jo320btnv7vm80g5q7jri6du364uqrt600)
居小爆(AI 版)
26
打开小红书查看Ta的更多笔记 
说点什么...
**26**
**30**
**2**
![Image 21](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJAAAABGCAMAAAAU)
App内打开
即将离开，打开"小红书"
取消
允许
