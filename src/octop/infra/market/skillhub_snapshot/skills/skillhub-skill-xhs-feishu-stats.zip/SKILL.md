---
name: skillhub-skill-xhs-feishu-stats
description: "把指定小红书笔记链接的点赞、收藏、评论数抓取并写入指定的飞书多维表格（Bitable）。支持一条或多条链接批量统计、汇总（合计/篇均/Top3）、字段自动识别与可选自动建字段、按笔记ID去重 upsert 或追加历史快照；本机被小红书风控（安全限制 300012）、无登录态或页面改版时，可用渲染页文本兜底取数（parse-rendered）。触发词：统计小红书点赞收藏评论、小红书数据回写飞书、把这些笔记数据写到多维表格、小红书互动数据台账、笔记数据同步、xhs stats、小红书数据看板、按链接统计笔记数据、批量统计笔记互动量、小红书安全限制/风控取数。仅做数据统计回写，不涉及发布笔记（发布用 xhs-feishu-publish-skill）。"
---

# 小红书互动数据 → 指定飞书多维表格

本技能把「小红书笔记链接」变成「飞书多维表格里的一行统计记录」：抓取每篇笔记的点赞 / 收藏 / 评论（附带标题、作者、笔记ID、链接、采集时间），按目标表格的真实字段自动映射后写入，并给出合计、篇均、点赞 Top3 汇总。

目标表格每次由链接指定，不需要改配置文件；飞书写入走已登录的 `lark-cli` 用户身份，不需要 app_secret。

**适用场景特例**：本机浏览器被小红书风控（页面显示「安全限制 / 当前网络存在风险 300012」）或没有 Playwright 登录态时，仍可用「渲染页文本兜底」取到公开互动数，见下方 SOP。这条路径不需要小红书登录、不需要代理，任何机器都能走。

## 何时使用

- 用户给出一条或多条小红书笔记链接，要求「统计点赞/收藏/评论」「把数据写到飞书表格」「同步到多维表格」「做数据台账/看板」
- 用户同时给出飞书多维表格链接（形如 `https://xxx.feishu.cn/base/XXX?table=tblYYY&view=vewZZZ`）和小红书链接
- 用户要求定期重复统计同一批笔记（配 `--mode append` 可累积历史快照；定时执行由 WorkBuddy 自动化负责，本技能不自行创建定时任务）
- 不适用：发布笔记、预填图文、回写发布状态 → 那些属于 `xhs-feishu-publish-skill`

## 三条取数通道（先读这个）

| 通道 | 做法 | 适用 | 失败时 |
|---|---|---|---|
| A. 登录态浏览器（默认） | `fetch` / `run` 用 Playwright 持久化 profile 读 `__INITIAL_STATE__` | 本机网络正常、已 `login` | 转 C，不要反复重试 |
| B. SSR 快速通道 | `--http-first` 直接解析页面内嵌 state | 未登录时多数返回空，命中率有限 | 自动回落到 A |
| C. 渲染页兜底（保底） | 用 WorkBuddy 网页读取工具 / 内置浏览器打开同一链接 → 保存页面文本 → `parse-rendered` → `write --from-json` | 风控 300012、无登录态、无 playwright、页面改版、三项数值取不到 | 用 `--likes/--collects/--comments` 传人工核对值 |

判定规则：**A/B 只要报「三项互动数都未取到」「安全限制」「页面没有返回可识别的笔记数据」中的任意一种，立刻走 C**。脚本现在会在这些错误里直接打印 C 的操作命令。绝不靠猜数字补齐。

为什么 C 能成功：本机浏览器与服务端网页读取通道的出口 IP / 浏览器指纹不同，一方被风控不代表另一方也被拦。

## 最短路径（最常用）

```bash
# 技能目录名可能是 xhs-feishu-stats 或 xhs-feishu-stats__skillhub，用通配定位
SKILL_DIR="$(ls -d ~/.workbuddy/skills/xhs-feishu-stats* 2>/dev/null | head -1)"
cd "$SKILL_DIR"

# 首次：体检 + 小红书扫码登录（只需一次；会自动复用 xhs-feishu-publish-skill 的登录态）
# doctor 若提示缺 playwright，会给出本机已装好依赖的解释器路径，用那个 python 重新执行即可
python scripts/xhs_stats.py doctor
python scripts/xhs_stats.py login

# 先看字段怎么映射、预演写入内容（--dry-run 完全无副作用：不写记录、不建字段）
python scripts/xhs_stats.py fields '<飞书表格链接>'
python scripts/xhs_stats.py run '<飞书表格链接>' '<小红书笔记链接>' --dry-run

# 确认无误后正式写入
python scripts/xhs_stats.py run '<飞书表格链接>' '<小红书笔记链接>'
```

多条链接直接往后接，或用 `--urls-file <每行一个链接的 txt>`：

```bash
python scripts/xhs_stats.py run '<飞书表格链接>' '<链接1>' '<链接2>' '<链接3>' --ensure-fields
python scripts/xhs_stats.py run '<飞书表格链接>' --urls-file notes.txt --mode append --summary-row
```

把「给链接 → 出结果」当作默认动作，不要先反问用户要表格结构：脚本会自己读字段并适配。只有正式写入（不带 `--dry-run`）才会改动表格。

## 命令一览

| 命令 | 作用 | 是否写飞书 |
|---|---|---|
| `doctor` | 检查 lark-cli 登录态、参数通道、playwright、浏览器 profile | 否 |
| `login` | 打开浏览器扫码登录小红书，持久化登录态 | 否 |
| `fields <飞书链接>` | 列出目标表字段及自动识别到的角色，检查类型 | 否（只读） |
| `fetch <小红书链接...>` | 只抓取，产出 JSON，不碰飞书 | 否 |
| `parse-rendered <小红书链接...> --text-file <页面文本>` | 风控兜底：把渲染页文本解析成标准 JSON | 否 |
| `write <飞书链接> --from-json <file>` | 把已有 JSON 写入表格 | 是 |
| `run <飞书链接> <小红书链接...>` | 抓取 + 写入一步完成 | 是 |

常用参数：

- `--dry-run`：只打印将要写入的字段与值，**完全无副作用**（1.1.0 起连 `--ensure-fields` 也不会真的建列）；配 `--print-payload` 可输出可直接执行的 `lark-cli` 命令
- `--ensure-fields`：表里缺「点赞/收藏/评论」等字段时自动补建（数值列建为 `number`，文本列建为 `text`）。默认关闭；只有正式写入时才会真的改表结构
- `--fields-map '{"likes":"点赞数","collects":"收藏数"}'`：字段名不规范时手动指定
- `--mode upsert`（默认）：按 笔记ID > 标题 > 笔记链接 查重，已存在则更新，不重复建行；`--mode append`：每次新增一行，适合做趋势快照
- `--summary-row`：额外写一行「【汇总】采集时间」记录（合计数据）
- `--headed` / `--wait-login 300`：显示浏览器并在未登录时等待扫码
- `--delay 2`：链接之间的间隔秒数；批量时不要调太小，避免触发风控
- `--http-first`：先试 SSR 通道
- `--from-json`：从指定 JSON 写入；缺省用 `~/.workbuddy/xhs-feishu-stats/last_result.json`
- `--out`：指定结果 JSON 输出路径（`parse-rendered` / `fetch` / `run` 均支持）
- `parse-rendered` 专用：`--text-file`（可重复，与链接一一对应）、`--title`、`--author`、`--likes`、`--collects`、`--comments`

## 风控兜底 SOP（人人可复现）

适用于本机 Playwright 被拦、没装 Playwright、没登录小红书、或页面结构改版导致三项数值取不到的情况。

**第 1 步｜拿到页面文本**
用 WorkBuddy 的网页读取工具（WebFetch）或内置浏览器打开**完整**笔记链接（必须含 `?xsec_token=...`），把返回内容原样保存为 UTF-8 文本文件，例如 `~/.workbuddy/xhs-feishu-stats/page.txt`。若是多篇文章，一篇一个文件。

**第 2 步｜人工核对三项数值（关键，不要跳过）**
小红书 H5 页面底部互动栏在「说点什么...」之后，从左到右依次是 **点赞 → 收藏 → 评论**。交叉核对线索：作者「热门笔记」卡片上同名笔记显示的数字通常是点赞数；「N 条精选评论」可与评论数互相印证。页面把数值显示成「赞」「收藏」等文字时，该字段视为未取到，**绝不写成 0**。

**第 3 步｜解析成标准 JSON**

```bash
# 最简写法：省略 --out，结果自动存到 ~/.workbuddy/xhs-feishu-stats/last_result.json
python scripts/xhs_stats.py parse-rendered '<小红书笔记链接>' --text-file '<页面文本.txt>'

# 多篇：文本文件数量与链接数量一一对应，可用 --out 单独留档
python scripts/xhs_stats.py parse-rendered '<链接1>' '<链接2>' \
  --text-file '<page1.txt>' --text-file '<page2.txt>' --out '<结果.json>'

# 页面文本解析不准时，直接传人工核对值（优先级高于文本解析；未指定的字段留空）
python scripts/xhs_stats.py parse-rendered '<小红书笔记链接>' \
  --likes 26 --collects 30 --comments 2 --title '笔记标题' --author '作者'
```

产物结构与其他通道完全一致，可直接被 `write --from-json` 消费。`parse-rendered` 会拒绝风控页文本，并对缺项标 `partial` / `need_check`。

**第 4 步｜写入飞书**

```bash
# 省略 --from-json 时，write 默认读上一步生成的 last_result.json
python scripts/xhs_stats.py write '<飞书表格链接>' --dry-run   # 先核对
python scripts/xhs_stats.py write '<飞书表格链接>'             # 正式写入

# 若第 3 步用了 --out，这里对应加 --from-json '<结果.json>'
```

`write` 只用 Python 标准库 + lark-cli，不需要 playwright、不需要小红书登录态。

## 执行流程（WorkBuddy 内部按此走）

1. 解析用户给的两类链接。飞书链接必须含 `table=`；缺 table 时脚本会列出该 Base 下的数据表并报错，此时让用户打开目标数据表复制完整地址栏链接。小红书短链（`xhslink.com/...`）会自动跟随重定向展开。
2. 抓取：优先 Playwright 持久化登录态读 `window.__INITIAL_STATE__.note.noteDetailMap[noteId].note.interactInfo` 的 `likedCount / collectedCount / commentCount`；缺失时回退到 `.engage-bar` 内 `.like-wrapper / .collect-wrapper / .chat-wrapper` 的 `span.count`（**必须锁定主笔记互动栏，不要盲抓全页 span.count，那会抓到推荐流里别的笔记**）。检测到「安全限制 / 300012」会直接给出 C 通道命令。
3. 数值归一：`1.2万`→12000、`1,234`→1234；低数值显示成「赞」等文字时记为 `need_check`，该字段留空并保留表格原值，**绝不臆造 0**。三项全取不到时该条记为 `failed`，不写入，并提示走 C。
4. 写入：读目标表字段 → 按名称自动映射角色 → 按字段类型转换 CellValue（数字列写 int，文本列写 str，公式/查找引用/附件/按钮等不可写列跳过）→ 查重 → `lark-cli base +record-upsert`。
5. 输出汇总：有效篇数、点赞/收藏/评论合计与篇均、点赞 Top3、失败链接清单。

## 字段自动识别

角色别名见 `references/data-contract.md`。要点：精确匹配优先（「点赞」「点赞数」「likes」…），再做包含匹配；含「率 / 增长 / 平均 / 环比 / 得分」等派生词的列会被排除，避免把「点赞率」当成点赞数写坏。表里第一个未被占用的纯文本列会自动作为标题列（1.1.0 起不再只认第一列，新建列插到最前也不会重复补建「标题」）。

数字列必须是 `number`（或 currency/percent/rating）类型。若用户表里是单选或文本列，脚本会按文本写入字符串；需要数字统计时先让用户把列改成数字类型，或用 `--ensure-fields` 新建规范列。

## 其它兜底路径

- **飞书 CLI 未登录 / 权限不足**：先 `lark-cli auth login`；仍不可用则改用 `lark-base` skill 的工具，把 `--dry-run --print-payload` 输出的字段 JSON 交给它写入。
- **Windows 上链接含 `&` 导致写入失败**：1.1.0 已内置修复（自动直调 `node run.js` 绕开 `lark-cli.CMD`；无法绕开时把 `--json` 改写成 `@临时文件`）。若使用旧版技能包，症状与手工解法见 `references/troubleshooting.md`。
- **表格里有空白行**：飞书新建表自带的空记录，脚本既不删除也不填充，按需在飞书里手工清理。

`--from-json` 的最小可用结构（可直接手工构造）：

```json
{
  "captured_at": "2026-11-12 08:30:00",
  "rows": [
    {
      "note_id": "6ad2109c000000001500e815",
      "url": "https://www.xiaohongshu.com/explore/6ad2109c...?xsec_token=...",
      "title": "笔记标题", "author": "作者",
      "likes": 140, "collects": 33, "comments": 18,
      "status": "ok", "need_check": []
    }
  ],
  "errors": []
}
```

## 约束与可信度

- 只读取页面上公开可见的互动数据；**阅读量仅本人可见，本技能不采集、不写入**。
- 小红书笔记链接通常需要 `?xsec_token=...`，缺失或过期会 404。让用户从浏览器地址栏复制完整链接，或在登录态首页点开笔记后复制。
- 不伪造数值、不把「赞」当成 0；`partial` 记录只写取到的字段，缺失字段保持表格原值。
- 批量抓取保持 `--delay` ≥ 2 秒；不对同一批链接高频轮询。
- 写入外部表格属于有副作用的操作：默认 `upsert`，`--ensure-fields` 会改表结构，`--mode append` 会持续增行。`--dry-run` 完全无副作用；首次运行先预演，并让用户确认目标表格链接没给错。
- 运行时产物与浏览器登录态放在 `~/.workbuddy/xhs-feishu-stats*` 下，不写进技能目录，技能包可安全分享（不含任何密钥或 cookie）。

## 文件结构

- `scripts/xhs_stats.py` — 全部逻辑（抓取、渲染页解析、字段映射、飞书写入、汇总、CLI）
- `references/data-contract.md` — 字段别名、JSON 结构、渲染页文本结构、lark-cli 命令与去重规则
- `references/troubleshooting.md` — 高频故障与解法
- `tests/test_xhs_stats.py` — 纯函数自测（URL/数值/字段映射/参数通道/dry-run 安全性/渲染页解析）
- `tests/rendered_note.md` — 渲染页文本样例，可直接用来试跑 `parse-rendered`

## 排错

先跑 `doctor`（会显示参数通道是否绕开 cmd.exe），再查 `references/troubleshooting.md`。最常见四个：小红书风控 300012（走风控兜底 SOP）、链接缺 `xsec_token`（404）、目标表没有数字字段（`--ensure-fields` 或改列类型）、飞书身份失效（`lark-cli auth login`）。

```bash
python -m unittest discover -s tests -v   # 回归自测，不联网、不写飞书
```

## 修订记录

- **1.1.0**：新增 `parse-rendered` 渲染页兜底通道与风控精准提示；修复 Windows `lark-cli.CMD` 把链接里 `&` 截断导致的写入/查重失败；修复 `--dry-run` 误建字段；修复新建列后主字段漂移导致重复补建「标题」列；长链接查重改走 `+record-list` 扫描（规避 keyword 50 字符上限）；补充 14 项回归测试与页面样例。
- **1.0.0**：首版，Playwright 抓取 + 字段自动映射 + upsert 写入。
