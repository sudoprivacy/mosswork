## Description: <br>
Use when someone wants one short video clip from text or images, such as B-roll, start/end frame animation, or a quick motion shot. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[pruna-ai](https://clawhub.ai/user/pruna-ai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creative operators use this skill to generate a single short Pruna p-video clip from a text prompt, image anchors, or optional uploaded audio. It helps prepare the request, call the Pruna API, poll the result, download the output, and review clip quality. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Using the skill can send images, portraits, narration, or music to Pruna or related providers for processing. <br>
Mitigation: Use only media the user has rights and consent to upload, and confirm that the user understands content leaves the local environment before the first upload or prediction. <br>
Risk: API credentials could be exposed if copied into prompts, manifests, logs, or saved files. <br>
Mitigation: Keep API keys in environment variables such as PRUNA_API_KEY, do not print or commit them, and stop if required credentials are missing. <br>
Risk: Downloaded outputs can overwrite local files. <br>
Mitigation: Confirm output paths before downloading generated media and avoid writing over unrelated files. <br>


## Reference(s): <br>
- [ClawHub p-video skill page](https://clawhub.ai/pruna-ai/skills/p-video) <br>
- [Pruna p-video model docs](https://docs.api.pruna.ai/guides/models/p-video) <br>
- [Replicate prunaai/p-video model page](https://replicate.com/prunaai/p-video) <br>
- [Pruna P-API shared reference](references/pruna-api.md) <br>
- [API credentials](references/api-credentials.md) <br>
- [Agent safety](references/agent-safety.md) <br>
- [p-video quality checklist](references/p-video-quality-checklist.md) <br>
- [Scene anchor pair](references/scene-anchor-pair.md) <br>
- [Scene anchor triple](references/scene-anchor-triple.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, configuration, code] <br>
**Output Format:** [Markdown guidance with curl commands and JSON request bodies] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces one Pruna p-video prediction workflow at a time, with API calls, polling, download steps, and quality-review guidance.] <br>

## Skill Version(s): <br>
1.0.6 (source: server release evidence and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
