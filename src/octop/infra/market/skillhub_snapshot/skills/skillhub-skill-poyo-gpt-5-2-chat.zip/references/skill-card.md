## Description: <br>
Provides guidance, payloads, and curl examples for using PoYo GPT-5.2 chat completions through the OpenAI-compatible chat completions endpoint. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to prepare PoYo GPT-5.2 chat completion requests, including chat payloads, streaming options, parameter choices, and response parsing notes for server-side integrations. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: PoYo API keys or authorization headers could be exposed in client code, logs, repositories, screenshots, or chat output. <br>
Mitigation: Keep POYO_API_KEY in server-side environment variables or a backend secret manager, and avoid emitting raw credentials. <br>
Risk: Live use sends message content to PoYo's API, which may include sensitive user or business data. <br>
Mitigation: Review payloads before submission and do not log private messages unless policy or the user explicitly allows it. <br>
Risk: An agent could make an unintended live API request while preparing examples or payloads. <br>
Mitigation: Only run the provided curl workflow when the user explicitly asks and a trusted server-side shell is available. <br>


## Reference(s): <br>
- [PoYo GPT-5.2 model page](https://poyo.ai/models/gpt-5-2) <br>
- [PoYo chat completions API docs](https://docs.poyo.ai/api-manual/chat-series/chat-completions) <br>
- [Skill API reference](references/api.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with JSON payloads and bash code blocks] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include synchronous or streaming response handling notes and server-side API key guidance.] <br>

## Skill Version(s): <br>
1.0.1 (source: release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
