#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
import argparse

# 常量定义
MCP_URL = "https://u8mcp.myu8.cn/"

# 不同客户端的服务节点 key 约定
YONWORK_SERVER_KEY = "u8智能体服务"      # YonWork: openclaw.json -> mcp.servers.u8智能体服务
WORKBUDDY_SERVER_KEY = "U8智能体服务"    # WorkBuddy: mcp.json -> mcpServers.U8智能体服务


def _load_json(json_file_path: str, create_if_missing: bool = False):
    """读取 JSON 文件。文件不存在时：create_if_missing=True 返回空 dict，否则打印错误并返回 None"""
    if not os.path.exists(json_file_path):
        if create_if_missing:
            return {}
        print(f"错误：文件 {json_file_path} 不存在！")
        return None

    try:
        with open(json_file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        print("错误：JSON文件格式损坏，无法解析！")
        return None


def _save_json(json_file_path: str, data) -> bool:
    """写回 JSON 文件"""
    try:
        # 确保父目录存在（例如 WorkBuddy 的 ~/.workbuddy 目录可能尚未创建）
        parent = os.path.dirname(os.path.abspath(json_file_path))
        if parent and not os.path.exists(parent):
            os.makedirs(parent, exist_ok=True)
        with open(json_file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        return True
    except OSError as e:
        print(f"错误：写入文件失败 {e}")
        return False


# 修改 u8智能体服务 efuid 的函数
def modify_u8_efuid(json_file_path: str, new_efuid: str, client: str = "yonwork"):
    data = _load_json(json_file_path, create_if_missing=False)
    if data is None:
        return False

    if client == "workbuddy":
        # WorkBuddy: mcp.json -> mcpServers.U8智能体服务.efuid
        if "mcpServers" not in data:
            print("错误：未找到 mcpServers 节点，请先执行添加服务操作！")
            return False
        servers = data["mcpServers"]
        target_key = WORKBUDDY_SERVER_KEY
        if target_key not in servers:
            print(f"错误：{target_key} 不存在，请先添加该服务！")
            return False
        # efuid 直接位于服务配置节点下
        servers[target_key]["efuid"] = new_efuid
    else:
        # YonWork: openclaw.json -> mcp.servers.u8智能体服务.headers.efuid
        if "mcp" not in data or "servers" not in data["mcp"]:
            print("错误：未找到 mcp.servers 节点，请先执行添加服务操作！")
            return False
        servers = data["mcp"]["servers"]
        target_key = YONWORK_SERVER_KEY
        if target_key not in servers:
            print(f"错误：{target_key} 不存在，请先添加该服务！")
            return False
        service_config = servers[target_key]
        if "headers" not in service_config:
            service_config["headers"] = {}
        service_config["headers"]["efuid"] = new_efuid

    if not _save_json(json_file_path, data):
        return False

    print(f"成功修改 {target_key} 的efuid为：{new_efuid}")
    return True


def add_u8_mcp_server(json_file_path: str, client: str = "yonwork"):
    if client == "workbuddy":
        # WorkBuddy: mcp.json -> mcpServers.U8智能体服务
        new_server = {
            WORKBUDDY_SERVER_KEY: {
                "efuid": "",
                "type": "streamableHttp",
                "url": MCP_URL,
                "timeout": 30000,
                "disabled": False
            }
        }
        # mcp.json 可能不存在，首次配置时自动创建
        data = _load_json(json_file_path, create_if_missing=True)
        if data is None:
            return False
        if "mcpServers" not in data:
            data["mcpServers"] = {}
        data["mcpServers"].update(new_server)
    else:
        # YonWork: openclaw.json -> mcp.servers.u8智能体服务
        new_server = {
            YONWORK_SERVER_KEY: {
                "name": "U8智能体服务",
                "url": MCP_URL,
                "transport": "streamable-http",
                "headers": {
                    "efuid": ""
                }
            }
        }
        data = _load_json(json_file_path, create_if_missing=False)
        if data is None:
            return False
        if "mcp" not in data:
            data["mcp"] = {}
        if "servers" not in data["mcp"]:
            data["mcp"]["servers"] = {}
        data["mcp"]["servers"].update(new_server)

    if not _save_json(json_file_path, data):
        return False

    print(f"操作完成！已成功添加 U8智能体服务 至 {json_file_path}")
    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="MCP配置管理：新增U8服务 / 修改efuid")
    parser.add_argument("--mcppath", required=True, help="JSON配置文件完整路径")
    parser.add_argument("--client", choices=["yonwork", "workbuddy"], default="yonwork",
                        help="客户端类型：yonwork=openclaw.json，workbuddy=mcp.json（默认 yonwork）")
    # 二选一参数
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--add", action="store_true", help="添加U8智能体服务配置")
    group.add_argument("--set-efuid", type=str, help="修改efuid值，传入目标字符串")

    args = parser.parse_args()

    if args.add:
        add_u8_mcp_server(args.mcppath, client=args.client)
    elif args.set_efuid is not None:
        modify_u8_efuid(args.mcppath, args.set_efuid, client=args.client)
