#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import webbrowser
import argparse
import sys
import os
import shutil
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse
import threading
import uuid
import time
import json

# 配置
STATE = str(uuid.uuid4())
PORT = 54321
login_result = None
timeout = 120
# 用 Event 通知主线程：回调已收到，可以退出了
done_event = threading.Event()
# 浏览器进程句柄，回调后直接 terminate
browser_proc = None
# 浏览器使用的独立配置目录（用于按命令行精确定位并关闭本脚本启动的浏览器）
PROFILE_DIR = os.path.join(os.path.expanduser('~'), '.u8login-browser-profile')


def find_browser():
    """查找 Chrome / Edge 可执行文件路径"""
    candidates = [
        shutil.which('chrome'),
        shutil.which('msedge'),
        shutil.which('chromium'),
        # Windows 常见安装路径
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
        r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
        r'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
    ]
    for p in candidates:
        if p and os.path.isfile(p):
            return p
    return None


def open_browser(url):
    """用固定 user-data-dir 启动独立浏览器进程，确保能关闭窗口"""
    global browser_proc
    path = find_browser()
    if path:
        browser_proc = subprocess.Popen([
            path, '--user-data-dir=' + PROFILE_DIR, '--new-window', '--start-maximized', url
        ])
        return True
    # 兜底：系统默认浏览器（无法自动关闭）
    webbrowser.open(url)
    return False


def _kill_pid_tree(pid):
    """按进程树强制结束（Windows 用 taskkill /T /F，其他平台用 kill）"""
    if not pid:
        return False
    try:
        if os.name == 'nt':
            subprocess.run(['taskkill', '/PID', str(pid), '/T', '/F'],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
        else:
            os.kill(pid, 9)
        return True
    except Exception:
        return False


def _pids_by_profile():
    """按独立配置目录定位本脚本启动的浏览器进程（不依赖 wmic，兼容新系统）"""
    if os.name != 'nt':
        return []
    ps = (
        "$ErrorActionPreference='SilentlyContinue';"
        "Get-CimInstance Win32_Process -Filter \"Name='msedge.exe' OR Name='chrome.exe'\" | "
        "Where-Object { $_.CommandLine -like '*u8login-browser-profile*' -and $_.CommandLine -notlike '*--type=*' } | "
        "ForEach-Object { $_.ProcessId }"
    )
    try:
        out = subprocess.run(
            ['powershell', '-NoProfile', '-NonInteractive', '-Command', ps],
            capture_output=True, text=True, timeout=30, errors='ignore')
        pids = []
        for line in (out.stdout or '').splitlines():
            line = line.strip()
            if line.isdigit():
                pids.append(int(line))
        return pids
    except Exception:
        return []


def close_browser():
    """登录完成后关闭本脚本启动的浏览器"""
    global browser_proc
    # 1) 先按进程树结束本次启动的进程
    if browser_proc is not None:
        try:
            _kill_pid_tree(browser_proc.pid)
        except Exception:
            pass
        try:
            browser_proc.terminate()
        except Exception:
            pass
    # 2) 按独立配置目录兜底：处理“启动器已退出、实际浏览器主进程仍存活”的情况
    for pid in _pids_by_profile():
        _kill_pid_tree(pid)
    # 3) 最后再试一次句柄
    if browser_proc is not None:
        try:
            browser_proc.kill()
        except Exception:
            pass


class AuthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        global login_result
        url = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(url.query)
        # 校验state
        if query.get("state", [""])[0] == STATE:
            login_result = {
                "success": True,
                "token": query.get("token", [""])[0]
            }

        # 返回 204 No Content，不显示任何页面
        self.send_response(204)
        self.end_headers()

        # 关闭本脚本启动的浏览器（按进程树 + 配置目录双重保障）
        close_browser()

        # 通知主线程可以退出了
        done_event.set()

def main(argv=None):
    # 启动http服务
    server = HTTPServer(("127.0.0.1", PORT), AuthHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    parser = argparse.ArgumentParser()
    parser.add_argument("--mcpurl", required=True, help="U8智能体服务 MCP 的 url地址")
    parser.add_argument("--efuid", required=True, help="服务识别码")
    parser.add_argument("--efserverid", required=True, help="账套号")
    parser.add_argument("--output", required=True, help="登录结果输出文件路径")
    args = parser.parse_args()

    # 打开浏览器（独立实例，支持自动关闭）
    redirect_uri = f"http://127.0.0.1:{PORT}"
    login_url = f"{args.mcpurl}/login.html?efuid={urllib.parse.quote(args.efuid)}&efserverid={urllib.parse.quote(args.efserverid)}&redirect_uri={urllib.parse.quote(redirect_uri, safe='')}&state={urllib.parse.quote(STATE)}"
    open_browser(login_url)

    # 阻塞等待回调 / 超时
    if done_event.wait(timeout=timeout):
        # 回调已收到，立即输出并退出
        result = json.dumps(login_result, ensure_ascii=False)
    else:
        # 超时：同样关闭残留浏览器，避免下次复用旧 state
        close_browser()
        result = json.dumps({"success": False, "token": ""}, ensure_ascii=False)

    # 将登录结果写入输出文件
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(result)

    # 在子线程中关闭 server，避免 shutdown() 阻塞主线程退出
    threading.Thread(target=server.shutdown, daemon=True).start()

    # 登录成功返回 0，失败返回 1
    return 0 if login_result else 1


if __name__ == "__main__":
    sys.exit(main())
