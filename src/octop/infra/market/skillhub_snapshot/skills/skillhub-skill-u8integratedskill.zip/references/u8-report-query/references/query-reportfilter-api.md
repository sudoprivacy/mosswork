# 查询报表过滤条件接口参考

## 请求报文模板
```JSON
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "U8Rep",
        "@token": "",
        "@proc": "query",
        "@request": "{\"actionname\":\"getQueryScheme\",\"params\":[{\"@id\":\"solutionId\",\"value\":\"C15D7FB5-7855-4B09-88DF-4F2FBD931A43\"}]}",
        "@efdebug":"1",
        "@version": "18.000",
        "@refcardnumber": "?"
    }
}
```
## 参数说明
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | U8服务识别码,从当前会话中获取|
| `@efserverid` | 是 | 账套标识标识,从当前会话中获取 |
| `@token` | 是 | 登录令牌token,从当前会话中获取 |
| `@request` | 是 | 查询参数 |

### @request节点Json参数说明
| 字段 | 必填 | 说明 |
|------|------|------|
| `actionname` | 是 | 报表操作，默认 getQueryScheme |
| `params` | 是 | 查询参数Json对象数组,示例： [{"@id":"solutionId","value":"C15D7FB5-7855-4B09-88DF-4F2FBD931A43"}] |

### params参数说明
| 字段 | 必填 | 说明 |
|------|------|------|
| `@id` | 是 | 参数名，默认 solutionId |
| `value` | 是 | 参数的值，此参数为从报表列表中匹配到的报表的solutionId字段的值 |


## 查询报表过滤条件返回的完整结果示例如下：
```json
{
    "ufinterface": {
        "@efserverid": "",
        "@eftype": "U8Rep",
        "@proc": "query",
        "@request": "{\"actionname\":\"getQueryScheme\",\"params\":[{\"@id\":\"solutionId\",\"value\":\"C15D7FB5-7855-4B09-88DF-4F2FBD931A43\"}]}",
        "@efdebug": "1",
        "@version": "18.000",
        "@refcardnumber": "?",
        "@runtimeb": "2026-07-23 11:38:19",
        "@succeed": "1",
        "@dsc": "U8Rep处理成功!",
        "@runtimee": "2026-07-23 11:38:20",
        "GetServiceMsgResult": {
            "resresult": {
                "flag": "0",
                "desc": "调用成功",
                "resdata": {
                    "referList": {
                        "refer": [
                            {
                                "id": "SNODEISDOTcInvCode",
                                "ref": "queryrow",
                                "title": "存货编码",
                                "type": "text",
                                "bindfield": "SNODEISDOTcInvCode",
                                "onclick": "openReference",
                                "controlname": "SNODEISDOTcInvCode",
                                "mapping": {
                                    "SNODEISDOTcInvCode_name": "name",
                                    "SNODEISDOTcInvCode": "code"
                                },
                                "reftitle": "存货基本参照",
                                "value": ""
                            },
                            {
                                "id": "SNODEISDOTcInvCCode_start",
                                "ref": "queryrow",
                                "title": "存货分类",
                                "type": "text",
                                "bindfield": "SNODEISDOTcInvCCode.start",
                                "onclick": "openReference",
                                "controlname": "SNODEISDOTcInvCCode",
                                "mapping": {
                                    "SNODEISDOTcInvCCode_codestart": "name",
                                    "SNODEISDOTcInvCCode.start": "code"
                                },
                                "reftitle": "存货分类基本参照",
                                "value": ""
                            },
                            {
                                "id": "SNODEISDOTcInvCCode_end",
                                "ref": "queryrow",
                                "title": "到",
                                "type": "text",
                                "bindfield": "SNODEISDOTcInvCCode.end",
                                "onclick": "openReference",
                                "controlname": "SNODEISDOTcInvCCode",
                                "mapping": {
                                    "SNODEISDOTcInvCCode_codeend": "name",
                                    "SNODEISDOTcInvCCode.end": "code"
                                },
                                "reftitle": "存货分类基本参照",
                                "value": ""
                            },
                            {
                                "id": "SNODEWSDOTcWhCode",
                                "ref": "queryrow",
                                "title": "仓库编码",
                                "type": "text",
                                "bindfield": "SNODEWSDOTcWhCode",
                                "onclick": "openReference",
                                "controlname": "SNODEWSDOTcWhCode",
                                "mapping": {
                                    "SNODEWSDOTcWhCode_name": "name",
                                    "SNODEWSDOTcWhCode": "code"
                                },
                                "reftitle": "仓库档案基本参照",
                                "value": ""
                            },
                            {
                                "id": "SNODEcInvDefine1_start",
                                "ref": "queryrow",
                                "title": "分光",
                                "type": "text",
                                "bindfield": "SNODEcInvDefine1.start",
                                "onclick": "openReference",
                                "controlname": "SNODEcInvDefine1",
                                "mapping": {
                                    "SNODEcInvDefine1_codestart": "name",
                                    "SNODEcInvDefine1.start": "code"
                                },
                                "reftitle": "分光",
                                "value": ""
                            },
                            {
                                "id": "SNODEcInvDefine1_end",
                                "ref": "queryrow",
                                "title": "到",
                                "type": "text",
                                "bindfield": "SNODEcInvDefine1.end",
                                "onclick": "openReference",
                                "controlname": "SNODEcInvDefine1",
                                "mapping": {
                                    "SNODEcInvDefine1_codeend": "name",
                                    "SNODEcInvDefine1.end": "code"
                                },
                                "reftitle": "分光",
                                "value": ""
                            },
                            {
                                "id": "SNODECSSDOTcFree9_start",
                                "ref": "queryrow",
                                "title": "颜色",
                                "type": "text",
                                "bindfield": "SNODECSSDOTcFree9.start",
                                "onclick": "openReference",
                                "controlname": "SNODECSSDOTcFree9",
                                "mapping": {
                                    "SNODECSSDOTcFree9_codestart": "name",
                                    "SNODECSSDOTcFree9.start": "code"
                                },
                                "reftitle": "颜色",
                                "value": ""
                            },
                            {
                                "id": "SNODECSSDOTcFree9_end",
                                "ref": "queryrow",
                                "title": "到",
                                "type": "text",
                                "bindfield": "SNODECSSDOTcFree9.end",
                                "onclick": "openReference",
                                "controlname": "SNODECSSDOTcFree9",
                                "mapping": {
                                    "SNODECSSDOTcFree9_codeend": "name",
                                    "SNODECSSDOTcFree9.end": "code"
                                },
                                "reftitle": "颜色",
                                "value": ""
                            }
                        ]
                    }
                }
            }
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "U8Rep处理成功!"
        }
    }
}
```