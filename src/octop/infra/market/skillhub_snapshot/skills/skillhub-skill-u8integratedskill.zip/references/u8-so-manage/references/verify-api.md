# 审核销售订单接口参考

## 请求报文模板
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "17",
        "@proc": "query",
        "@actions": "verify",
        "@efdebug": "1",
        "@efid": "1000000452"
    }
}
```

## 请求参数说明

| 字段 |  说明 |
|------|------|------|
| `@efuid` |  服务识别码，从当前会话中获取|
| `@efserverid` | 账套标识标识 |
| `@eftype` | 单据类型编号，固定值 17，表是销售订单   |
| `@proc` | 操作类型，固定值:query |
| `@actions` | 操作类型，默认：verify |
| `@efid` | 销售订单ID，默认传入创建销售订单时返回Json结果的@retid参数的值 |
| `@efdebug` | 展示字段描述信息，默认：0 |


## 返回结果的Json字段说明
- `actions` — 审核结果的信息对象

**actions**
| 参数名称 | 参数解释 |
| --- | --- |
| `@action_verify_succeed` |  审核是否成功，1：成功，0：审核失败 |
| `@action_verify_dsc` |  审核结果的描述信息 |
