
# U8 库龄分析


## 核心要点： @获取库龄分析数据 


### 请求报文模板
```json
{
  "ufinterface": {
    "@efuid": "",
    "@efserverid": "",
    "@token": "",
    "@eftype": "AiDataSource",
    "@proc": "st_inventoryage_forAI", 
    "@efdebug": "1",
    "@version": "20.000",
    "@pagesize":"20",
    "flts":{
        	"flt":[
        		{
        		"@dsp":"日期",
        		"@fld":"currentdate",
        		"@condition":"=",
        		"@value":""
        		},
        		{
        		"@dsp":"仓库编码",
        		"@fld":"cwhcode",
        		"@condition":"=",
        		"@value":""
        		},
        		{
        		"@dsp":"存货编码",
        		"@fld":"cinvcode",
        		"@condition":"=",
        		"@value":""
        		}
        		]
            }
      }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识：从当前会话中获取|
| `@eftype` | 是 | 固定为 `AiDataSource` |
| `@proc` | 是 |固定为 `st_inventoryage_forAI` |
| `@pagesize` | 否 | 页大小，缺省 200；本步示例 `20` |
| `@efdebug` | 是 | 调试开关，`1` 开启 |
| `@token` | 是 | 登录令牌，从当前会话中获取|
| `flt`下@dsp=日期 时|否|@value填写日期值,可以为空 |
| `flt`下@dsp=仓库编码 时|否|@value填写仓库编码,可以为空 |
| `flt`下@dsp=存货编码 时|否|@value填写存货编码,可以为空 |


**返回结果报文模版**
```json
{
    "ufinterface": {
        "@efserverid": "",
        "@token":"",
        "@eftype": "AiDataSource",
        "@proc": "st_inventoryage_forAI",
        "@efdebug": "1",
        "@version": "20.000",
        "@runtimeb": "2026-10-29 17:36:12",
        "@effunctionstr": "",
        "@succeed": "1",
        "@dsc": "AiDataSource处理成功!",
        "@runtimee": "2026-10-29 17:36:25",
        "voucher": {
            "@cardnumber": "EFSQL",
            "@ccardname": "",
            "@xmlns:z": "EF",
            "@pagesize": "200",
            "@pagenumer": "1",
            "@rownumbers": "179",
            "@pages": "1",
            "head": {
              "VoucherFieldDescription": {
               "@cinvcode": "存货编码",
               "@cinvname": "存货名称",
               "@cbatch": "批次",
               "@iqtty": "数量",
               "@iage": "库龄天数"           
               },
                "z:row": [                  
                    {
                        "@cinvcode": "存货编码",
                        "@cinvname": "存货名称",
                        "@cbatch": "批次",
                        "@iqtty": "数量",
                        "@iage": "库龄天数"
                    }
                ]
            },
            "body": null
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "AiDataSource处理成功!"
        }
    }
}
```
**返回结果展现**
- 如果没有输入区间，按返回结果明细直接展现,不需要交叉
- 如果输入了区间，按交叉表展现，如输入5,10,30则按小于5天，5-10天，10-30天，30天以上交叉展现

