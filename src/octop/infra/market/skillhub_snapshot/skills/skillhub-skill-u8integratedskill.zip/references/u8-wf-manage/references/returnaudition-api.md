# 驳回（Returnaudition）接口参考

实现方式为 调用  U8智能体服务 MCP  
参数格式如下

## 请求报文模板
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "AuditSrv",
        "@token": "",
        "@proc": "Returnaudition",
        "@succeed": "1",
        "@dsc": "AuditSrv处理成功!",
        "inf": {
            "@TaskID": "任务ID",
            "@cvouchertype": "单据类型  来源于任务列表 cvouchertype",
            "@opinion": "驳回意见",
            "@succeed": "0"
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "AuditSrv处理成功!"
        }
    }
}
```


## 请求参数说明
**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` |是 |  账套标识标识 |
| `@eftype` | 是 |固定值 AuditSrv |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@proc` | 是 | 操作类型，固定值:Returnaudition |
| `@TaskID` |是 | 驳回审核任务ID |
| `@cvouchertype` |否 |  单据类型  来源于任务列表 cvouchertype |
| `@opinion` | 否 | 驳回审核意见描述 |

## 返回的完整结果示例如下：
```json
{
    "ufinterface": {
        "@efserverid": "",
        "@eftype": "AuditSrv",
        "@userid": "demo",
        "@pass": "",
        "@proc": "Returnaudition",
        "@succeed": "1",
        "@dsc": "AuditSrv处理成功!",
        "inf": {
            "@TaskID": "360EF503-6FAA-4E6B-A7FD-DD6BEED82336",
            "@cvouchertype": "27",
            "@opinion": "不同意意见",
            "@succeed": "1",
            "@dsc": "不同意成功",
            "@errmsg": ""
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "AuditSrv处理成功!"
        }
    }
}
```