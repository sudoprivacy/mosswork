# 新建其他入库单接口参考

实现方式为 调用  U8智能体服务 MCP
参数格式如下

## 请求报文模板
```json
{
  "ufinterface": {
    "@efuid": "",
    "@efserverid": "",
    "@token": "",
    "@eftype": "0301",
    "@simulateinput": "cinvname,iquantity",
    "@refcardnumber": "defval",
    "@efdebug": "1",
    "@proc": "Add",
    "voucher": {
      "@xmlns:z": "EF",
      "head": {
        "z:row": {
          "@cwhcode": "仓库编码(必填)",
          "@crdcode": "入库类别编码(必填)",
          "@cbustype": "业务类型",
          "@cdepcode": "部门编码",
          "@cpersoncode": "业务员编码",
          "@cvencode": "供应商编码",
          "@csource": "单据来源",
          "@cbuscode": "业务号",
          "@ddate": "入库日期",
          "@cmemo": "备注  ",
          "@cvenabbname": "供应商",
          "@cvouchtype": "单据类型编码"
        }
      },
      "body": {
        "z:row": [
          {
            "@cinvcode": "存货编码(必填)",
            "@cinvname": "存货名称(必填)",
            "@cinvstd": "规格型号",
            "@iquantity": "数量(必填)",
            "@iunitcost": "单价",
            "@iprice": "金额",
            "@cbatch": "批号",
            "@cfree1": "自由项1",
            "@cposition": "货位编码",
            "@ipprice": "计划金额/售价金额"
          }
        ]
      }
    }
  }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 否 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | **单据类型编号：其他入库单 = `0301`** |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvname,iquantity |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |


**head 单据头字段说明（已依实时返回示例确认）**
| @ 参数 | 必填 | 中文含义 | 可见性 |
|------|------|------|------|
| `@bisstqc` | 否 | 库存期初标记 | 模板隐藏 |
| `@brdflag` | 否 | 收发标志 | 模板隐藏 |
| `@caccounter` | 否 | 记账人 | 模板隐藏 |
| `@cbuscode` | 否 | 业务号 | 模板可见 |
| `@cbustype` | 否 | 业务类型 | 模板可见 |
| `@cchkcode` | 否 | 检验单号 | 模板隐藏 |
| `@cchkperson` | 否 | 检验员 | 模板隐藏 |
| `@ccode` | 否 | 入库单号 | 模板可见 |
| `@cdefine1` | 否 | 业务负责人 | 模板隐藏 |
| `@cdefine10` | 否 | 自定义项10 | 模板隐藏 |
| `@cdefine11` | 否 | 发货信息 | 模板隐藏 |
| `@cdefine12` | 否 | 自定义项12 | 模板隐藏 |
| `@cdefine13` | 否 | 自定义项13 | 模板隐藏 |
| `@cdefine14` | 否 | 自定义项14 | 模板隐藏 |
| `@cdefine15` | 否 | 自定义项15 | 模板隐藏 |
| `@cdefine16` | 否 | 自定义项16 | 模板隐藏 |
| `@cdefine2` | 否 | 自定义项2 | 模板隐藏 |
| `@cdefine3` | 否 | 电商交易单号 | 模板隐藏 |
| `@cdefine4` | 否 | 自定义项4 | 模板隐藏 |
| `@cdefine5` | 否 | 自定义项5 | 模板隐藏 |
| `@cdefine6` | 否 | 自定义项6 | 模板隐藏 |
| `@cdefine7` | 否 | 自定义项7 | 模板隐藏 |
| `@cdefine8` | 否 | 自定义项8 | 模板隐藏 |
| `@cdefine9` | 否 | 自定义项9 | 模板隐藏 |
| `@cdepcode` | 否 | 部门编码 | 模板隐藏 |
| `@cdepname` | 否 | 部门     | 模板可见 |
| `@chandler` | 否 | 审核人   | 模板可见 |
| `@chdefine1` | 否 | 扩展自定义项1 | 模板隐藏 |
| `@chinvsn` | 否 | 序列号 | 模板隐藏 |
| `@cmaker` | 否 | 制单人   | 模板可见 |
| `@cmemo` | 否 | 备注   | 模板可见 |
| `@cmodifyperson` | 否 | 修改人 | 模板隐藏 |
| `@cpersoncode` | 否 | 业务员编码 | 模板隐藏 |
| `@cpersonname` | 否 | 业务员 | 模板隐藏 |
| `@crdcode` | 是 | 入库类别编码 | 模板隐藏 |
| `@crdname` | 否 | 入库类别 | 模板可见 |
| `@csource` | 否 | 单据来源 | 模板隐藏 |
| `@csourcecodels` | 否 | 零售来源单号 | 模板隐藏 |
| `@csourcels` | 否 | 单据来源 | 模板隐藏 |
| `@csysbarcode` | 否 | 单据条码 | 模板隐藏 |
| `@ctransflag` | 否 | 转换方式 | 模板隐藏 |
| `@cvenabbname` | 否 | 供应商 | 模板隐藏 |
| `@cvencode` | 否 | 供应商编码 | 模板隐藏 |
| `@cvouchname` | 否 | 单据类型 | 模板隐藏 |
| `@cvouchtype` | 否 | 单据类型编码 | 模板隐藏 |
| `@cwhcode` | 是 | 仓库编码 | 模板隐藏 |
| `@cwhname` | 否 | 仓库   | 模板可见 |
| `@dchkdate` | 否 | 检验日期 | 模板隐藏 |
| `@ddate` | 否 | 入库日期 | 模板可见 |
| `@dmodifydate` | 否 | 修改日期 | 模板隐藏 |
| `@dnmaketime` | 否 | 制单时间 | 模板隐藏 |
| `@dnmodifytime` | 否 | 修改时间 | 模板隐藏 |
| `@dnverifytime` | 否 | 审核时间 | 模板隐藏 |
| `@dveridate` | 否 | 审核日期 | 模板可见 |
| `@iavanum` | 否 | 可用件数 | 模板隐藏 |
| `@iavaquantity` | 否 | 可用量 | 模板隐藏 |
| `@id` | 否 | ID | 模板隐藏 |
| `@ilowsum` | 否 | 最低库存量 | 模板隐藏 |
| `@ipresent` | 否 | 现存量   | 模板可见 |
| `@ipresentnum` | 否 | 现存件数 | 模板隐藏 |
| `@ireturncount` | 否 | ireturncount | 模板隐藏 |
| `@isafesum` | 否 | 安全库存量 | 模板隐藏 |
| `@iswfcontrolled` | 否 | iswfcontrolled | 模板隐藏 |
| `@itopsum` | 否 | 最高库存量 | 模板隐藏 |
| `@iverifystate` | 否 | iverifystate | 模板隐藏 |
| `@ufts` | 否 | 时间戳 | 模板隐藏 |
| `@vt_id` | 否 | 模板号 | 模板隐藏 |


**body 单据体字段说明（已依实时返回示例确认）**
| @ 参数 | 必填 | 中文含义 | 可见性 |
|------|------|------|------|
| `@autoid` | 否 | 其他入库单编号 | 模板隐藏 |
| `@bcosting` | 否 | 是否核算 | 模板隐藏 |
| `@bvmiused` | 否 | 代管消耗标识 | 模板隐藏 |
| `@cassunit` | 否 | 库存单位码 | 模板可见 |
| `@cbaccounter` | 否 | 记账人 | 模板隐藏 |
| `@cbarcode` | 否 | 条形码 | 模板隐藏 |
| `@cbatch` | 否 | 批号 | 模板可见 |
| `@cbatchproperty1` | 否 | 属性1 | 模板隐藏 |
| `@cbatchproperty10` | 否 | 属性10 | 模板隐藏 |
| `@cbatchproperty2` | 否 | 属性2 | 模板隐藏 |
| `@cbatchproperty3` | 否 | 属性3 | 模板隐藏 |
| `@cbatchproperty4` | 否 | 属性4 | 模板隐藏 |
| `@cbatchproperty5` | 否 | 属性5 | 模板隐藏 |
| `@cbatchproperty6` | 否 | 属性6 | 模板隐藏 |
| `@cbatchproperty7` | 否 | 属性7 | 模板隐藏 |
| `@cbatchproperty8` | 否 | 属性8 | 模板隐藏 |
| `@cbatchproperty9` | 否 | 属性9 | 模板隐藏 |
| `@cbdefine7` | 否 | aaa7 | 模板隐藏 |
| `@cbinvsn` | 否 | 序列号 | 模板可见 |
| `@cbmemo` | 否 | 备注 | 模板隐藏 |
| `@cbserviceoid` | 否 | cbserviceoid | 模板隐藏 |
| `@cbsourcecodels` | 否 | 零售来源单号 | 模板隐藏 |
| `@cbsysbarcode` | 否 | 单据行条码 | 模板隐藏 |
| `@cbvencode` | 否 | 供应商编码 | 模板隐藏 |
| `@ccheckcode` | 否 | 检验单号 | 模板隐藏 |
| `@ccheckpersoncode` | 否 | 检验员编码 | 模板隐藏 |
| `@ccheckpersonname` | 否 | 检验员 | 模板隐藏 |
| `@cciqbookcode` | 否 | 手册号 | 模板隐藏 |
| `@ccrmvouchcode` | 否 | 服务来源单号 | 模板隐藏 |
| `@cdefine22` | 否 | 自定义项1 | 模板隐藏 |
| `@cdefine23` | 否 | 自定义项2 | 模板隐藏 |
| `@cdefine24` | 否 | 自定义项3 | 模板隐藏 |
| `@cdefine25` | 否 | 自定义项4 | 模板隐藏 |
| `@cdefine26` | 否 | 自定义项5 | 模板隐藏 |
| `@cdefine27` | 否 | 自定义项6 | 模板隐藏 |
| `@cdefine28` | 否 | 自定义项7 | 模板隐藏 |
| `@cdefine29` | 否 | 自定义项8 | 模板隐藏 |
| `@cdefine30` | 否 | 自定义项9 | 模板隐藏 |
| `@cdefine31` | 否 | 自定义项10 | 模板隐藏 |
| `@cdefine32` | 否 | 自定义项11 | 模板隐藏 |
| `@cdefine33` | 否 | 自定义项12 | 模板隐藏 |
| `@cdefine34` | 否 | 自定义项13 | 模板隐藏 |
| `@cdefine35` | 否 | 自定义项14 | 模板隐藏 |
| `@cdefine36` | 否 | 自定义项15 | 模板隐藏 |
| `@cdefine37` | 否 | 自定义项16 | 模板隐藏 |
| `@cdemandmemo` | 否 | 需求分类代号说明 | 模板隐藏 |
| `@cexpirationdate` | 否 | 有效期至 | 模板隐藏 |
| `@cfree1` | 否 | 自由项1 | 模板隐藏 |
| `@cfree10` | 否 | 内存 | 模板可见 |
| `@cfree2` | 否 | 自由项2 | 模板隐藏 |
| `@cfree3` | 否 | 自由项3 | 模板隐藏 |
| `@cfree4` | 否 | 自由项4 | 模板隐藏 |
| `@cfree5` | 否 | 自由项5 | 模板隐藏 |
| `@cfree6` | 否 | 自由项6 | 模板隐藏 |
| `@cfree7` | 否 | 自由项7 | 模板隐藏 |
| `@cfree8` | 否 | 自由项8 | 模板隐藏 |
| `@cfree9` | 否 | 颜色 | 模板可见 |
| `@cinva_unit` | 否 | 库存单位 | 模板可见 |
| `@cinvaddcode` | 否 | 存货代码 | 模板隐藏 |
| `@cinvcode` | 是 | 存货编码 | 模板可见 |
| `@cinvdefine1` | 否 | 分光 | 模板隐藏 |
| `@cinvdefine10` | 否 | 自定义项10 | 模板隐藏 |
| `@cinvdefine11` | 否 | 自定义项11 | 模板隐藏 |
| `@cinvdefine12` | 否 | 自定义项12 | 模板隐藏 |
| `@cinvdefine13` | 否 | 自定义项13 | 模板隐藏 |
| `@cinvdefine14` | 否 | 自定义项14 | 模板隐藏 |
| `@cinvdefine15` | 否 | 自定义项15 | 模板隐藏 |
| `@cinvdefine16` | 否 | 自定义项16 | 模板隐藏 |
| `@cinvdefine2` | 否 | 自定义项2 | 模板隐藏 |
| `@cinvdefine3` | 否 | 自定义项3 | 模板隐藏 |
| `@cinvdefine4` | 否 | 自定义项4 | 模板隐藏 |
| `@cinvdefine5` | 否 | 自定义项5 | 模板隐藏 |
| `@cinvdefine6` | 否 | 自定义项6 | 模板隐藏 |
| `@cinvdefine7` | 否 | 自定义项7 | 模板隐藏 |
| `@cinvdefine8` | 否 | 自定义项8 | 模板隐藏 |
| `@cinvdefine9` | 否 | 自定义项9 | 模板隐藏 |
| `@cinvm_unit` | 否 | 主计量单位 | 模板可见 |
| `@cinvname` | 是 | 存货名称 | 模板可见 |
| `@cinvouchcode` | 否 | 对应入库单号 | 模板隐藏 |
| `@cinvouchtype` | 否 | 对应入库单类型 | 模板隐藏 |
| `@cinvstd` | 否 | 规格型号 | 模板隐藏 |
| `@citem_class` | 否 | 项目大类编码 | 模板隐藏 |
| `@citemcname` | 否 | 项目大类名称 | 模板隐藏 |
| `@citemcode` | 否 | 项目编码 | 模板隐藏 |
| `@cmassunit` | 否 | 保质期单位 | 模板隐藏 |
| `@cname` | 否 | 项目 | 模板隐藏 |
| `@coritracktype` | 否 | 预留原始跟踪号类型 | 模板隐藏 |
| `@corufts` | 否 | 对应单据时间戳 | 模板隐藏 |
| `@cposition` | 否 | 货位编码 | 模板隐藏 |
| `@cposname` | 否 | 货位 | 模板隐藏 |
| `@crejectcode` | 否 | 不良品处理单号 | 模板隐藏 |
| `@creplaceitem` | 否 | 替换件 | 模板隐藏 |
| `@cserviceoid` | 否 | cserviceoid | 模板隐藏 |
| `@csocode` | 否 | 需求跟踪号 | 模板隐藏 |
| `@cvenname` | 否 | 供应商 | 模板隐藏 |
| `@cvmivencode` | 否 | 代管商代码 | 模板隐藏 |
| `@cvmivenname` | 否 | 代管商 | 模板隐藏 |
| `@cvouchcode` | 否 | 对应入库单id | 模板隐藏 |
| `@dexpirationdate` | 否 | 有效期计算项 | 模板隐藏 |
| `@dmadedate` | 否 | 生产日期 | 模板可见 |
| `@dvdate` | 否 | 失效日期 | 模板可见 |
| `@ibondedsumqty` | 否 | 累计保税处理抽取数量 | 模板隐藏 |
| `@icheckids` | 否 | 检验单子表ID | 模板隐藏 |
| `@icrmvouchids` | 否 | 服务单据子表ID | 模板隐藏 |
| `@id` | 否 | ID | 模板隐藏 |
| `@idebitchildids` | 否 | 借入借出单子表id | 模板隐藏 |
| `@idebitids` | 否 | 借入借出单子表id | 模板隐藏 |
| `@iexpiratdatecalcu` | 否 | 有效期推算方式 | 模板隐藏 |
| `@ifnum` | 否 | 实际件数 | 模板隐藏 |
| `@ifquantity` | 否 | 实际数量 | 模板隐藏 |
| `@igroupno` | 否 | 组号 | 模板隐藏 |
| `@iinvexchrate` | 否 | 换算率 | 模板隐藏 |
| `@imassdate` | 否 | 保质期 | 模板隐藏 |
| `@innum` | 否 | 应收件数 | 模板隐藏 |
| `@inquantity` | 否 | 应收数量 | 模板隐藏 |
| `@inum` | 否 | 件数 | 模板隐藏 |
| `@iposflag` | 否 | 已分配货位 | 模板隐藏 |
| `@ipprice` | 否 | 计划金额/售价金额 | 模板隐藏 |
| `@iprice` | 否 | 金额 | 模板可见 |
| `@ipunitcost` | 否 | 计划单价/售价 | 模板隐藏 |
| `@iquantity` | 是 | 数量 | 模板可见 |
| `@irejectids` | 否 | 不良品处理单子表id | 模板隐藏 |
| `@irowno` | 否 | 行号 | 模板隐藏 |
| `@isodid` | 否 | 销售订单子表ID | 模板隐藏 |
| `@isoseq` | 否 | 需求跟踪行号 | 模板隐藏 |
| `@isotype` | 否 | 需求跟踪方式 | 模板隐藏 |
| `@isoutnum` | 否 | 累计出库件数 | 模板隐藏 |
| `@isoutquantity` | 否 | 累计出库数量 | 模板隐藏 |
| `@itrids` | 否 | 其他业务AUTOID | 模板隐藏 |
| `@iunitcost` | 否 | 单价 | 模板可见 |
| `@ivmisettlenum` | 否 | 代管挂账确认单件数 | 模板隐藏 |
| `@ivmisettlequantity` | 否 | 代管挂账确认单数量 | 模板隐藏 |
| `@outcopiedquantity` | 否 | 已复制数量 | 模板隐藏 |
| `@strowguid` | 否 | rowguid | 模板隐藏 |
| `@taskguid` | 否 | taskguid | 模板隐藏 |

返回的结果如下（由 Query 示例派生，与下方查询示例自洽）
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "0301",
    "@simulateinput": "cinvname,iquantity",
    "@refcardnumber": "defval",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "0301处理成功!新增成功！",
    "@retid": "1000000408",
    "@retcode": "0000000000",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "0301",
      "@ccardname": "其他入库单",
      "head": {
        "z:row": {
          "@ccode": "0000000028",
          "@csysbarcode": "||st08|0000000028",
          "@cvouchtype": "08",
          "@cvouchname": "其他入库单",
          "@cbustype": "其他入库",
          "@crdcode": "19",
          "@crdname": "其他类型入库",
          "@cwhcode": "03",
          "@cwhname": "半成品库",
          "@csource": "库存",
          "@ddate": "2026-08-28T00:00:00",
          "@iverifystate": "0",
          "@id": "1000000408"
        }
      },
      "body": {
        "z:row": {
          "@cinvname": "硬盘-1000G",
          "@cinvcode": "01019002065",
          "@cinvstd": "希捷 1000G/7200RPM/32M/SATA2/企业级",
          "@iquantity": "10.0000000000",
          "@cinvm_unit": "PCS",
          "@autoid": "1000001242"
        }
      }
    }
  }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。

---
