# 查询凭证接口参考

## 请求报文模板
参数格式如下
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "GL01",
        "@proc": "Query",
        "@efdebug": "1",
        "@efid": "2026-06-记-1"
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@efid` | 是 | 单据ID，也就是凭证创建服务 返回的 @retid `@retid`，格式: `yyyy-mm-凭证类别字-凭证号` |


查询凭证服务 返回的完整结果示例如下：
```json
{
    "ufinterface": {
        "@efserverid": "",
        "@eftype": "GL01",
        "@proc": "query",
        "@efdebug": "1",
        "@efid": "2026-06-记-1",
        "@refcardnumber": "?",
        "@succeed": "1",
        "@dsc": "GL01处理成功!查询成功！",
        "@runtimeb": "2026-07-16 10:09:18",
        "@runtimee": "2026-07-16 10:09:19",
        "login": {
            "@serviceid": ""
        },
		"voucher": {
			"voucher_head": {
			  "voucher_type": "记",
			  "fiscal_year": "2015",
			  "accounting_period": "1",
			  "voucher_id": "5",
			  "attachment_number": "1",
			  "date": "2015/1/6",
			  "auditdate": "2015/1/6",
			  "enter": "demo",
			  "checker": "demo1"
			},
			"voucher_body": {
			  "entry": [
				{
				  "entry_id": "1",
				  "account_code": "100201",
				  "abstract": "收款单_收款单",
				  "settlement": "8",
				  "document_date": "2015/1/6",
				  "exchange_rate2": "0",
				  "debit_quantity": "0",
				  "primary_debit_amount": "0",
				  "natural_debit_currency": "49000",
				  "credit_quantity": "0",
				  "primary_credit_amount": "0",
				  "natural_credit_currency": "0",
				  "bill_type": "48",
				  "bill_id": "0000000025",
				  "bill_date": "2015/1/6",
				  "auxiliary_accounting": {
					"dept_id": "",
					"personnel_id": "",
					"cust_id": "",
					"supplier_id": "",
					"item_id": "",
					"item_class": "",
					"operator": ""
				  }
				},
				{
				  "entry_id": "2",
				  "account_code": "1122",
				  "abstract": "收款单_收款单",
				  "currency": "人民币",
				  "exchange_rate2": "0",
				  "debit_quantity": "0",
				  "primary_debit_amount": "0",
				  "natural_debit_currency": "0",
				  "credit_quantity": "0",
				  "primary_credit_amount": "0",
				  "natural_credit_currency": "49000",
				  "bill_type": "48",
				  "bill_id": "0000000025",
				  "bill_date": "2015/1/6",
				  "auxiliary_accounting": {
					"dept_id": "",
					"personnel_id": "",
					"cust_id": "",
					"supplier_id": "",
					"item_id": "",
					"item_class": "",
					"operator": ""
				  }
				}
			  ]
			}
		},
        "runafter": {
            "@succeed": "1",
            "@dsc": "17处理成功!查询成功！"
        }
    }
}
```
