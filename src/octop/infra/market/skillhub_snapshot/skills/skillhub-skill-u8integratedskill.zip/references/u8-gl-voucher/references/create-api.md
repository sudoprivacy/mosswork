# 创建凭证接口参考

## 请求报文模板
参数格式如下
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "GL01",
        "@refcardnumber": "defval",
        "@efdebug": "1",
        "@proc": "Add",
        "voucher": {
            "@xmlns:z": "EF",
            "voucher_head": {
                "date": "2014-12-01",
				"voucher_type": "记",
				"voucher_id": "1"
            },
            "voucher_body": {
                "entry": [{
                    "abstract": "摘要",
                    "account_code": "会计科目编码",
                    "natural_debit_currency":"100",
					"natural_credit_currency":"0",
					"auxiliary_accounting": {
						"item": [
							{
								"@name": "dept_id",
                                "#text": "部门编码"
							},
							{
								"@name": "personnel_id",
                                "#text": "人员编码"
							},
							{
								"@name": "cust_id",
                                "#text": "客户编码"
							},
							{
								"@name": "supplier_id",
                                "#text": "供应商编码"
							},
							{
								"@name": "item_id",
                                "#text": "项目编码"
							},
							{
								"@name": "item_class",
                                "#text": "项目大类编码"
							},
							{
								"@name": "operator",
                                "#text": "业务员"
							},
							{
								"@name": "self_define1",
                                "#text": "自定义项1"
							},
							{
								"@name": "self_define16",
                                "#text": "自定义项16"
							}
						]
					},
					"detail": {
						"cash_flow_statement": {
							"cash_flow": {
								"@cash_item": "现金流量项目编码",
								"@natural_debit_currency": "100",
								"@natural_credit_currency": "0"
							}
						}
					}
				}]
            }
        }
    }
}
```


### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号，默认 GL01   |
| `@proc` | 是 | 操作类型，默认：Add |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `voucher_head` | 是 | 凭证头信息 |
| `voucher_body` | 是 | 凭证分录信息 |

**voucher_head单据头信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `date` | 否 | 凭证日期 |
| `voucher_type` | 否 | 凭证类别 |
| `voucher_id` | 否 | 凭证编号 |

**voucher_body单据体信息说明**
- `entry` — 凭证分录对象数组

**entry凭证分录对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `abstract` | 是 | 摘要 |
| `account_code` | 是 | 会计科目编码 |
| `natural_debit_currency` | 是 | 借方金额 |
| `natural_credit_currency` | 是 | 贷方金额 |
| `auxiliary_accounting` | 否 | 辅助项对象 |

**auxiliary_accounting辅助项对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `dept_id` | 否 | 部门编码 |
| `personnel_id` | 否 | 人员编码 |
| `cust_id` | 否 | 客户编码 |
| `supplier_id` | 否 | 供应商编码 |
| `item_id` | 否 | 项目编码 |
| `item_class` | 否 | 项目大类编码 |
| `cust_id` | 否 | 客户编码 |
| `supplier_id` | 否 | 供应商编码 |
| `operator` | 否 | 业务员 |
| `self_define1` | 否 | 自定义项1 |
| `self_define16` | 否 | 自定义项16 |


返回的结果如下
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "GL01",
    "@refcardnumber": "defval",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "GL01处理成功!新增成功！",
    "@retid": "2026-06-记-1",
    "@retcode": "",
    "voucher": {
      "@xmlns:z": "EF",
      "voucher_head": {
        "date": "2026-06-01",
        "voucher_type": "记",
        "voucher_id": "1"
      },
      "voucher_body": {
        "entry": {
          "abstract": "报销交通费",
          "account_code": "100201",
          "natural_debit_currency": "0",
          "natural_credit_currency": "100.00",
          "detail": {
            "cash_flow_statement": {
              "cash_flow": {
                "@cash_item": "05",
                "@natural_debit_currency": "0.00",
                "@natural_credit_currency": "100.00",
                "@ccode": "100201",
                "@cdept_id": "",
                "@cperson_id": "",
                "@ccus_id": "",
                "@csup_id": "",
                "@citem_class": "",
                "@citem_id": "",
                "@cDefine1": "",
                "@cDefine2": "",
                "@cDefine3": "",
                "@cDefine4": "",
                "@cDefine5": "",
                "@cDefine6": "",
                "@cDefine7": "",
                "@cDefine8": "",
                "@cDefine9": "",
                "@cDefine10": "",
                "@cDefine11": "",
                "@cDefine12": "",
                "@cDefine13": "",
                "@cDefine14": "",
                "@cDefine15": "",
                "@cDefine16": ""
              }
            }
          }
        }
      }
    }
  }
}
```
其中@retid 是凭证ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。