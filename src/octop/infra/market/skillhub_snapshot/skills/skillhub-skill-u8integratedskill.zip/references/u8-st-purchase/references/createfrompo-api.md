---
name: createfrompo-api
description: 参照采购订单生成采购入库单（Purchase Inbound Receipt from PO）。当用户要"根据采购订单生成/参照采购订单做采购入库单"时使用此技能。仅覆盖参照生单核心：前置查询采购订单(eftype=88)获取参照来源、新建采购入库单(eftype=24)时用@refcardnumber=88+表体@ef_autoid(=采购订单@ID)建立参照关系。查询/展示/审核等环节见已拆分的标准「采购入库单」技能。
metadata: {"yonbip":{"version":"1.0.0"}}
---

# 参照采购订单生成采购入库单（参照生单专用）

## 第0步：查询采购订单（获取参照来源）
实现方式为 调用 U8智能体服务 MCP
参数格式如下
### 请求报文模板
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "88",
        "@proc": "Query",
        "@efdebug": "1",
        "@efid": "采购订单ID"
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号：采购订单 = `88` |
| `@proc` | 是 | 操作类型，默认：Query |
| `@efid` | 否 | 采购订单ID；不填则拉列表定位目标订单 |

**返回结果取数要点**
- 表头 `@ccode` → 采购订单号，回填入库单表头 `@cordercode`
- 表体每行 `@ID` → 子表订单id（=PO_Podetails.ID，**采购订单表体无 autoid 列**），回填入库单表体 `@ef_autoid` 与 `@iposid`
- 表体 `@cinvcode`(存货)、`@iquantity`(订单数量) 等作为入库单行建议值

## 新建采购入库单（参照采购订单）
实现方式为 调用 U8智能体服务 MCP
参数格式如下
### 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "24",
        "@simulateinput": "cinvname,iquantity,ioritaxcost",
        "@refcardnumber": "88",
        "@efdebug": "1",
        "@proc": "Add",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@cvencode": "01002",
                    "@cvenabbname": "深圳辰环手机配件有限公司",
                    "@cwhcode": "50",
                    "@crdcode": "11",
                    "@cbustype": "普通采购",
                    "@cordercode": "PO000001",
                    "@ipurorderid": "12345"
                }
            },
            "body": {
                "z:row": [{
                    "@cinvcode": "01019002065",
                    "@cinvname": "硬盘-1000G",
                    "@iquantity": "18.00",
                    "@ioritaxcost": "87.75",
                    "@iposid": "1000001234",
                    "@ef_autoid": "1000001234"
                }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号：采购入库单 = `24` |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvname,iquantity,ioritaxcost |
| `@refcardnumber` | 是 | 单据来源类型编号：无来源填 `defval`；参照采购订单填来源单据 `@eftype` = `88` |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |

**head单据头对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cvencode` | 是 | 供货单位编码（可取自采购订单表头） |
| `@cvenabbname` | 是 | 供货单位简称 |
| `@cwhcode` | 是 | 仓库编码 |
| `@crdcode` | 是 | 入库类别编码，如 `11` 采购入库 |
| `@cbustype` | 否 | 业务类型，如 普通采购 |
| `@cordercode` | 否* | 订单号（参照来源） = 采购订单 `@ccode` |
| `@ipurorderid` | 否 | 采购订单ID = 采购订单 `@poid` |

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@ef_autoid` | 是* | 来源单据子表ID（EAI 参照追踪） = 采购订单查询 `@ID`（PO_Podetails.ID，采购订单表体无 autoid 列）；建立参照关系、防重复生单 |
| `@iposid` | 否* | 订单子表ID（参照来源），同 `@ef_autoid`，填采购订单行 `@ID` |
| `@cinvcode` | 是 | 存货编码 |
| `@cinvname` | 否 | 存货名称（可模拟输入） |
| `@iquantity` | 是 | 本次入库数量，≤ 采购订单对应行未到货量 |
| `@ioritaxcost` | 否 | 原币含税单价 |

> `*` 必有订单模式或明确要求参照采购订单生成时，`@ef_autoid`/`@iposid` 承载来源关联，必须填写。

返回的结果如下
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "24",
    "@simulateinput": "cinvname,iquantity,ioritaxcost",
    "@refcardnumber": "88",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "24处理成功!新增成功！",
    "@retid": "1000000416",
    "@retcode": "0000000398",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "24",
      "@ccardname": "采购入库单",
      "head": {
        "z:row": {
          "@cvencode": "01002",
          "@ccode": "0000000336",
          "@crdcode": "11",
          "@cwhcode": "50",
          "@cmaker": "demo10",
          "@ddate": "2026-06-01",
          "@cordercode": "PO000001",
          "@id": "1000000336"
        }
      },
      "body": {
        "z:row": {
          "@cinvcode": "01019002065",
          "@cinvname": "硬盘-1000G",
          "@iquantity": "18.00",
          "@ioritaxcost": "87.75",
          "@iposid": "1000001234",
          "@ef_autoid": "1000001234",
          "@autoid": "1598"
        }
      }
    }
  }
}
```
其中 `@retid` 是新建成功的采购入库单ID（`@autoid` 为入库单自身行ID，与 `@ef_autoid` 不同）。

⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。
