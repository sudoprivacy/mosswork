# 新建调拨单接口参考

实现方式为 调用  U8智能体服务 MCP
参数格式如下

## 请求报文模板
```json
{
  "ufinterface": {
    "@efuid": "",
    "@efserverid": "",
    "@token": "",
    "@eftype": "0304",
    "@simulateinput": "cinvname,itvquantity",
    "@refcardnumber": "defval",
    "@efdebug": "1",
    "@proc": "Add",
    "voucher": {
      "@xmlns:z": "EF",
      "head": {
        "z:row": {
          "@ciwhcode": "转入仓库",
          "@cowhcode": "转出仓库"
        }
      },
      "body": {
        "z:row": [
          {
            "@cinvcode": "存货编码(必填)",
            "@cinvname": "存货名称(必填)",
            "@itvquantity": "数量(必填)"
          }
        ]
      }
    }
  }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 否 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | **单据类型编号：调拨单 = `0304`** |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvname,iquantity |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |


**head 单据头字段说明（已依实时返回示例确认）**
| @ 参数 | 必填 | 中文含义 | 可见性 |
|------|------|------|------|
| `@bomid` | 否 | bomid | 模板隐藏 |
| `@btransflag` | 否 | 是否传递 | 模板隐藏 |
| `@caccounter` | 否 | 记账人 | 模板隐藏 |
| `@cbustype` | 否 | 业务类型 | 模板隐藏 |
| `@cdefine1` | 否 | 业务负责人 | 模板隐藏 |
| `@cdefine10` | 否 | 自定义项10 | 模板隐藏 |
| `@cdefine11` | 否 | 发货信息 | 模板隐藏 |
| `@cdefine12` | 否 | 自定义项12 | 模板隐藏 |
| `@cdefine13` | 否 | 自定义项13 | 模板隐藏 |
| `@cdefine14` | 否 | 自定义项14 | 模板隐藏 |
| `@cdefine15` | 否 | 自定义项15 | 模板隐藏 |
| `@cdefine16` | 否 | 自定义项16 | 模板隐藏 |
| `@cdefine2` | 否 | 自定义项2 | 模板隐藏 |
| `@cdefine3` | 否 | 电商交易单号 | 模板隐藏 |
| `@cdefine4` | 否 | 自定义项4 | 模板隐藏 |
| `@cdefine5` | 否 | 自定义项5 | 模板隐藏 |
| `@cdefine6` | 否 | 自定义项6 | 模板隐藏 |
| `@cdefine7` | 否 | 自定义项7 | 模板隐藏 |
| `@cdefine8` | 否 | 自定义项8 | 模板隐藏 |
| `@cdefine9` | 否 | 自定义项9 | 模板隐藏 |
| `@cdepname` | 否 | 转入部门 | 模板可见 |
| `@cdepname_1` | 否 | 转出部门 | 模板可见 |
| `@cfree1` | 否 | 自由项1 | 模板隐藏 |
| `@cfree10` | 否 | 内存 | 模板可见 |
| `@cfree2` | 否 | 自由项2 | 模板隐藏 |
| `@cfree3` | 否 | 自由项3 | 模板隐藏 |
| `@cfree4` | 否 | 自由项4 | 模板隐藏 |
| `@cfree5` | 否 | 自由项5 | 模板隐藏 |
| `@cfree6` | 否 | 自由项6 | 模板隐藏 |
| `@cfree7` | 否 | 自由项7 | 模板隐藏 |
| `@cfree8` | 否 | 自由项8 | 模板隐藏 |
| `@cfree9` | 否 | 颜色 | 模板可见 |
| `@chdefine1` | 否 | 扩展自定义项1 | 模板隐藏 |
| `@chinvsn` | 否 | 序列号 | 模板隐藏 |
| `@cidepcode` | 否 | 转入部门编码 | 模板隐藏 |
| `@cinvname` | 否 | 产品名称 | 模板隐藏 |
| `@cirdcode` | 否 | 入库类别编码 | 模板隐藏 |
| `@ciwhcode` | 否 | 转入仓库编码 | 模板隐藏 |
| `@cmaker` | 否 | 制单人   | 模板可见 |
| `@cmodifyperson` | 否 | 修改人 | 模板隐藏 |
| `@cmpocode` | 否 | 订单号 | 模板隐藏 |
| `@codepcode` | 否 | 转出部门编码 | 模板隐藏 |
| `@cordcode` | 否 | 出库类别编码 | 模板隐藏 |
| `@cordertype` | 否 | 订单类型 | 模板隐藏 |
| `@cowhcode` | 否 | 转出仓库编码 | 模板隐藏 |
| `@cpersoncode` | 否 | 经手人编码 | 模板隐藏 |
| `@cpersonname` | 否 | 经手人   | 模板可见 |
| `@cpspcode` | 否 | 产品结构 | 模板隐藏 |
| `@crdname` | 否 | 入库类别     | 模板可见 |
| `@crdname_1` | 否 | 出库类别 | 模板可见 |
| `@csource` | 否 | 单据来源 | 模板隐藏 |
| `@csourcecodels` | 否 | 零售来源单号 | 模板隐藏 |
| `@csysbarcode` | 否 | 单据条码 | 模板隐藏 |
| `@ctranrequestcode` | 否 | 调拨申请单号 | 模板可见 |
| `@ctvcode` | 否 | 单据号   | 模板可见 |
| `@ctvmemo` | 否 | 备注         | 模板可见 |
| `@cverifyperson` | 否 | 审核人       | 模板可见 |
| `@cversion` | 否 | 版本号/替代标识 | 模板隐藏 |
| `@cwhname` | 否 | 转出仓库     | 模板可见 |
| `@cwhname_1` | 否 | 转入仓库 | 模板可见 |
| `@dmodifydate` | 否 | 修改日期 | 模板隐藏 |
| `@dnmaketime` | 否 | 制单时间 | 模板隐藏 |
| `@dnmodifytime` | 否 | 修改时间 | 模板隐藏 |
| `@dnverifytime` | 否 | 审核时间 | 模板隐藏 |
| `@dtvdate` | 否 | 日期     | 模板可见 |
| `@dverifydate` | 否 | 审核日期 | 模板可见 |
| `@iamount` | 否 | 现存量   | 模板可见 |
| `@iavanum` | 否 | 可用件数 | 模板隐藏 |
| `@iavaquantity` | 否 | 可用量 | 模板隐藏 |
| `@id` | 否 | 远程编号 | 模板隐藏 |
| `@ilowsum` | 否 | 最低库存量 | 模板隐藏 |
| `@ipresentnum` | 否 | 现存件数 | 模板隐藏 |
| `@iproorderid` | 否 | 生产订单ID | 模板隐藏 |
| `@iquantity` | 否 | 产量 | 模板隐藏 |
| `@ireturncount` | 否 | ireturncount | 模板隐藏 |
| `@isafesum` | 否 | 安全库存量 | 模板隐藏 |
| `@iswfcontrolled` | 否 | iswfcontrolled | 模板隐藏 |
| `@itopsum` | 否 | 最高库存量 | 模板隐藏 |
| `@itransflag` | 否 | 调拨方向 | 模板隐藏 |
| `@iverifystate` | 否 | iverifystate | 模板隐藏 |
| `@parentscrp` | 否 | 母件损耗率(%) | 模板隐藏 |
| `@ufts` | 否 | 时间戳 | 模板隐藏 |
| `@vt_id` | 否 | 模版号 | 模板隐藏 |


**body 单据体字段说明（已依实时返回示例确认）**
| @ 参数 | 必填 | 中文含义 | 可见性 |
|------|------|------|------|
| `@autoid` | 否 | 自动编号 | 模板隐藏 |
| `@bcosting` | 否 | 是否核算 | 模板隐藏 |
| `@cassunit` | 否 | 库存单位码 | 模板隐藏 |
| `@cbarcode` | 否 | 条形码 | 模板隐藏 |
| `@cbatchproperty1` | 否 | 属性1 | 模板隐藏 |
| `@cbatchproperty10` | 否 | 属性10 | 模板隐藏 |
| `@cbatchproperty2` | 否 | 属性2 | 模板隐藏 |
| `@cbatchproperty3` | 否 | 属性3 | 模板隐藏 |
| `@cbatchproperty4` | 否 | 属性4 | 模板隐藏 |
| `@cbatchproperty5` | 否 | 属性5 | 模板隐藏 |
| `@cbatchproperty6` | 否 | 属性6 | 模板隐藏 |
| `@cbatchproperty7` | 否 | 属性7 | 模板隐藏 |
| `@cbatchproperty8` | 否 | 属性8 | 模板隐藏 |
| `@cbatchproperty9` | 否 | 属性9 | 模板隐藏 |
| `@cbdefine7` | 否 | aaa7 | 模板隐藏 |
| `@cbinvsn` | 否 | 序列号 | 模板隐藏 |
| `@cbmemo` | 否 | 备注 | 模板隐藏 |
| `@cbsourcecodels` | 否 | 零售来源单号 | 模板隐藏 |
| `@cbsysbarcode` | 否 | 单据行条码 | 模板隐藏 |
| `@cbvencode` | 否 | 供应商编码 | 模板隐藏 |
| `@cciqbookcode` | 否 | 手册号 | 模板隐藏 |
| `@cddemandmemo` | 否 | 目标需求分类代号说明 | 模板隐藏 |
| `@cdefine22` | 否 | 自定义项1 | 模板隐藏 |
| `@cdefine23` | 否 | 自定义项2 | 模板隐藏 |
| `@cdefine24` | 否 | 自定义项3 | 模板隐藏 |
| `@cdefine25` | 否 | 自定义项4 | 模板隐藏 |
| `@cdefine26` | 否 | 自定义项5 | 模板隐藏 |
| `@cdefine27` | 否 | 自定义项6 | 模板隐藏 |
| `@cdefine28` | 否 | 自定义项7 | 模板隐藏 |
| `@cdefine29` | 否 | 自定义项8 | 模板隐藏 |
| `@cdefine30` | 否 | 自定义项9 | 模板隐藏 |
| `@cdefine31` | 否 | 自定义项10 | 模板隐藏 |
| `@cdefine32` | 否 | 自定义项11 | 模板隐藏 |
| `@cdefine33` | 否 | 自定义项12 | 模板隐藏 |
| `@cdefine34` | 否 | 自定义项13 | 模板隐藏 |
| `@cdefine35` | 否 | 自定义项14 | 模板隐藏 |
| `@cdefine36` | 否 | 自定义项15 | 模板隐藏 |
| `@cdefine37` | 否 | 自定义项16 | 模板隐藏 |
| `@cdsocode` | 否 | 目标需求跟踪号 | 模板隐藏 |
| `@cexpirationdate` | 否 | 有效期至 | 模板隐藏 |
| `@cfree1` | 否 | 自由项1 | 模板隐藏 |
| `@cfree10` | 否 | 内存 | 模板可见 |
| `@cfree2` | 否 | 自由项2 | 模板隐藏 |
| `@cfree3` | 否 | 自由项3 | 模板隐藏 |
| `@cfree4` | 否 | 自由项4 | 模板隐藏 |
| `@cfree5` | 否 | 自由项5 | 模板隐藏 |
| `@cfree6` | 否 | 自由项6 | 模板隐藏 |
| `@cfree7` | 否 | 自由项7 | 模板隐藏 |
| `@cfree8` | 否 | 自由项8 | 模板隐藏 |
| `@cfree9` | 否 | 颜色 | 模板可见 |
| `@cinposcode` | 否 | 调入货位编码 | 模板隐藏 |
| `@cinposname` | 否 | 调入货位 | 模板隐藏 |
| `@cinva_unit` | 否 | 库存单位 | 模板隐藏 |
| `@cinvaddcode` | 否 | 存货代码 | 模板隐藏 |
| `@cinvcode` | 是 | 存货编码 | 模板可见 |
| `@cinvdefine1` | 否 | 分光 | 模板隐藏 |
| `@cinvdefine10` | 否 | 自定义项10 | 模板隐藏 |
| `@cinvdefine11` | 否 | 自定义项11 | 模板隐藏 |
| `@cinvdefine12` | 否 | 自定义项12 | 模板隐藏 |
| `@cinvdefine13` | 否 | 自定义项13 | 模板隐藏 |
| `@cinvdefine14` | 否 | 自定义项14 | 模板隐藏 |
| `@cinvdefine15` | 否 | 自定义项15 | 模板隐藏 |
| `@cinvdefine16` | 否 | 自定义项16 | 模板隐藏 |
| `@cinvdefine2` | 否 | 自定义项2 | 模板隐藏 |
| `@cinvdefine3` | 否 | 自定义项3 | 模板隐藏 |
| `@cinvdefine4` | 否 | 自定义项4 | 模板隐藏 |
| `@cinvdefine5` | 否 | 自定义项5 | 模板隐藏 |
| `@cinvdefine6` | 否 | 自定义项6 | 模板隐藏 |
| `@cinvdefine7` | 否 | 自定义项7 | 模板隐藏 |
| `@cinvdefine8` | 否 | 自定义项8 | 模板隐藏 |
| `@cinvdefine9` | 否 | 自定义项9 | 模板隐藏 |
| `@cinvm_unit` | 否 | 主计量单位 | 模板可见 |
| `@cinvname` | 是 | 存货名称 | 模板可见 |
| `@cinvouchcode` | 否 | 对应入库单号 | 模板隐藏 |
| `@cinvouchercode` | 否 | 源单号 | 模板隐藏 |
| `@cinvoucherlineid` | 否 | 源单行ID | 模板隐藏 |
| `@cinvouchertype` | 否 | 源单类型 | 模板隐藏 |
| `@cinvouchtype` | 否 | 对应入库单类型 | 模板隐藏 |
| `@cinvstd` | 否 | 规格型号 | 模板可见 |
| `@citem_class` | 否 | 项目大类编码 | 模板隐藏 |
| `@citemcname` | 否 | 项目大类名称 | 模板隐藏 |
| `@citemcode` | 否 | 项目编码 | 模板隐藏 |
| `@cmassunit` | 否 | 保质期单位 | 模板隐藏 |
| `@cmocode` | 否 | 生产订单号 | 模板隐藏 |
| `@cmolotcode` | 否 | 生产批号 | 模板可见 |
| `@cname` | 否 | 项目 | 模板隐藏 |
| `@comcode` | 否 | 委外订单号 | 模板隐藏 |
| `@corufts` | 否 | 对应单据时间戳 | 模板隐藏 |
| `@coutposcode` | 否 | 调出货位编码 | 模板隐藏 |
| `@coutposname` | 否 | 调出货位 | 模板隐藏 |
| `@cposition` | 否 | 货位编码 | 模板隐藏 |
| `@creplaceitem` | 否 | 替换件 | 模板隐藏 |
| `@csdemandmemo` | 否 | 需求分类代号说明 | 模板隐藏 |
| `@csocode` | 否 | 需求跟踪号 | 模板隐藏 |
| `@ctvbatch` | 否 | 批号 | 模板隐藏 |
| `@ctvcode` | 否 | 单据号 | 模板隐藏 |
| `@cvenname` | 否 | 供应商 | 模板隐藏 |
| `@cvmivencode` | 否 | 代管商代码 | 模板隐藏 |
| `@cvmivenname` | 否 | 代管商 | 模板隐藏 |
| `@ddisdate` | 否 | 失效日期 | 模板隐藏 |
| `@dexpirationdate` | 否 | 有效期计算项 | 模板隐藏 |
| `@dmadedate` | 否 | 生产日期 | 模板隐藏 |
| `@fsalecost` | 否 | 零售单价 | 模板隐藏 |
| `@fsaleprice` | 否 | 零售金额 | 模板隐藏 |
| `@iavanum` | 否 | 可用件数 | 模板隐藏 |
| `@iavaquantity` | 否 | 可用量 | 模板隐藏 |
| `@idsodid` | 否 | 目标销售订单子表ID | 模板隐藏 |
| `@idsoseq` | 否 | 目标需求跟踪行号 | 模板隐藏 |
| `@idsotype` | 否 | 目标需求跟踪方式 | 模板隐藏 |
| `@iexpiratdatecalcu` | 否 | 有效期推算方式 | 模板隐藏 |
| `@igrossweight` | 否 | 毛重 | 模板隐藏 |
| `@iinvexchrate` | 否 | 换算率 | 模板隐藏 |
| `@imassdate` | 否 | 保质期 | 模板隐藏 |
| `@imoids` | 否 | imoids | 模板隐藏 |
| `@imoseq` | 否 | 生产订单行号 | 模板隐藏 |
| `@impoids` | 否 | 生产订单子表Id | 模板隐藏 |
| `@inetweight` | 否 | 净重 | 模板隐藏 |
| `@invcode` | 否 | 产品编码 | 模板隐藏 |
| `@invname` | 否 | 产品 | 模板隐藏 |
| `@iomids` | 否 | iomids | 模板隐藏 |
| `@ipresent` | 否 | 现存量 | 模板隐藏 |
| `@ipresentnum` | 否 | 现存件数 | 模板隐藏 |
| `@irowno` | 否 | 行号 | 模板隐藏 |
| `@isoseq` | 否 | 需求跟踪行号 | 模板隐藏 |
| `@issodid` | 否 | 销售订单子表ID | 模板隐藏 |
| `@issotype` | 否 | 需求跟踪方式 | 模板隐藏 |
| `@itrids` | 否 | 调拨申请单子表ID | 模板隐藏 |
| `@itvacost` | 否 | 单价 | 模板可见 |
| `@itvaprice` | 否 | 金额 | 模板可见 |
| `@itvnum` | 否 | 件数 | 模板隐藏 |
| `@itvpcost` | 否 | 计划单价/售价 | 模板隐藏 |
| `@itvpprice` | 否 | 计划金额/售价金额 | 模板隐藏 |
| `@itvquantity` | 否 | 数量 | 模板可见 |
| `@rdsid` | 否 | 对应入库单id | 模板隐藏 |
| `@strowguid` | 否 | rowguid | 模板隐藏 |
| `@taskguid` | 否 | taskguid | 模板隐藏 |

返回的结果如下（由 Query 示例派生，与下方查询示例自洽）
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "0304",
    "@simulateinput": "cinvname,iquantity",
    "@refcardnumber": "defval",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "0304处理成功!新增成功！",
    "@retid": "1000000005",
    "@retcode": "0000000000",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "0304",
      "@ccardname": "调拨单",
      "head": {
        "z:row": {
          "@csysbarcode": "||st12|0000000005",
          "@ciwhcode": "转入仓库",
          "@cowhcode": "转出仓库",
          "@cmaker": "demo",
          "@csource": "1",
          "@id": "1000000005"
        }
      },
      "body": {
        "z:row": {
          "@cinvname": "三星存储卡",
          "@cinvcode": "0340",
          "@cinvstd": "32G 70MB/S",
          "@cinvm_unit": "个",
          "@autoid": "1000000007"
        }
      }
    }
  }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。

---
