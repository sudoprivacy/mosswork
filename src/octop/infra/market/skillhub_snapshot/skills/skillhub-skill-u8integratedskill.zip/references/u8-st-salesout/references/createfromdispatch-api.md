---
name: createfromdispatch-api
description: 参照发货单生成销售出库单（Sales Outbound from Dispatch）。当用户要"根据发货单生成/参照发货单做出库单"时使用此技能。仅覆盖参照生单核心：前置查询发货单(eftype=01)获取参照来源、新建销售出库单(eftype=0303)时用@refcardnumber=01+表体@ef_autoid(=发货单@iDLsID)建立参照关系。查询/展示/审核等环节见已拆分的标准「销售出库单」技能。
metadata: {"yonbip":{"version":"1.0.0"}}
---

# 参照发货单生成销售出库单（参照生单专用）

## 第0步：查询发货单（获取参照来源）
实现方式为 调用 U8智能体服务 MCP
参数格式如下
### 请求报文模板
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "01",
        "@proc": "Query",
        "@efdebug": "1",
        "@efid": "发货单ID"
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号：发货单 = `01` |
| `@proc` | 是 | 操作类型，默认：Query |
| `@efid` | 否 | 发货单ID；不填则拉列表定位目标单据 |

**返回结果取数要点**
- 表头 `@cdlcode` → 发货单号，回填销售出库单表头 `@cordercode`
- 表头 `@id` → 发货单头ID（=DispatchList.DLID），回填销售出库单来源头ID
- **表体每行 `@iDLsID`** → 子表id（=DispatchLists.iDLsID，发货单表体行ID），回填销售出库单表体 `@ef_autoid` 与 `@iposid`
- 表体 `@cinvcode`(存货)、`@iquantity`(发货数量) 等作为出库单行建议值

## 新建销售出库单（参照发货单）
实现方式为 调用 U8智能体服务 MCP
参数格式如下
### 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "0303",
        "@simulateinput": "cinvname,iquantity",
        "@refcardnumber": "01",
        "@efdebug": "1",
        "@proc": "Add",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@ccuscode": "02001",
                    "@ccusabbname": "北京华信客户有限公司",
                    "@cwhcode": "01",
                    "@crdcode": "09",
                    "@cbustype": "普通销售",
                    "@cordercode": "XS000001"
                }
            },
            "body": {
                "z:row": [{
                    "@cinvcode": "01019002065",
                    "@cinvname": "硬盘-1000G",
                    "@iquantity": "18.00",
                    "@iposid": "1000001234",
                    "@ef_autoid": "1000001234"
                }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号：销售出库单 = `0303` |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvname,iquantity |
| `@refcardnumber` | 是 | 单据来源类型编号：无来源填 `defval`；参照发货单填来源单据 `@eftype` = `01` |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |

**head单据头对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@ccuscode` | 是 | 客户编码（可取自发货单表头） |
| `@ccusabbname` | 是 | 客户简称 |
| `@cwhcode` | 是 | 仓库编码 |
| `@crdcode` | 是 | 出库类别编码，如 `22` 销售出库 |
| `@cbustype` | 否 | 业务类型，如 普通销售 |
| `@cordercode` | 否* | 来源单号（参照来源） = 发货单 `@cdlcode` |

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@ef_autoid` | 是* | 来源单据子表ID（EAI 参照追踪） = 发货单查询 `@iDLsID`（DispatchLists.iDLsID）；建立参照关系、防重复生单 |
| `@iposid` | 否* | 来源子表ID（参照来源），同 `@ef_autoid`，填发货单行 `@iDLsID` |
| `@cinvcode` | 是 | 存货编码 |
| `@cinvname` | 否 | 存货名称（可模拟输入） |
| `@iquantity` | 是 | 本次出库数量，≤ 发货单对应行未出库量 |

> `*` 必有订单模式或明确要求参照发货单生成时，`@ef_autoid`/`@iposid` 承载来源关联，必须填写。

返回的结果如下
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "0303",
    "@simulateinput": "cinvname,iquantity",
    "@refcardnumber": "01",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "0303处理成功!新增成功！",
    "@retid": "1000000417",
    "@retcode": "0000000399",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "0303",
      "@ccardname": "销售出库单",
      "head": {
        "z:row": {
          "@ccuscode": "02001",
          "@ccode": "0000000337",
          "@crdcode": "09",
          "@cwhcode": "01",
          "@cmaker": "demo10",
          "@ddate": "2026-06-01",
          "@cordercode": "XS000001",
          "@id": "1000000337"
        }
      },
      "body": {
        "z:row": {
          "@cinvcode": "01019002065",
          "@cinvname": "硬盘-1000G",
          "@iquantity": "18.00",
          "@iposid": "1000001234",
          "@ef_autoid": "1000001234",
          "@autoid": "1599"
        }
      }
    }
  }
}
```
其中 `@retid` 是新建成功的销售出库单ID（`@autoid` 为出库单自身行ID，与 `@ef_autoid` 不同）。

⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。
