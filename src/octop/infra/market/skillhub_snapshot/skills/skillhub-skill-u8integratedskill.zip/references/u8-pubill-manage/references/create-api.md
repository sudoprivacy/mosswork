# 创建采购专用发票接口参考

实现方式为 调用  U8智能体服务 MCP 
参数格式如下
## 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "25",
        "@simulateinput": "cinvcode,ipbvquantity,iorimoney",
        "@refcardnumber": "defval",
        "@efdebug": "1",
        "@proc": "Add",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@cvencode": "01"
                    }
            },
            "body": {
                "z:row": [{
                    "@cinvcode": "01001",
                    "@ipbvquantity": "1.00",
                    "@iorimoney": "100.00"
                    }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号，默认 25   |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvcode,ipbvquantity,iorimoney |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |

**head单据头信息说明**
- `row` — 单据头对象

**head单据头row节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cvencode` | 是 | 供应商编码 |
| `@cbustype` | 是 | 默认值普通采购 |

**body单据体信息说明**
- `row` — 单据体对象数组

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cinvcode` | 是 | 存货编码 |
| `@ipbvquantity` | 是 | 数量 |
| `@iorimoney` | 是 | 金额或原币金额 |


返回的结果如下
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "25",
    "@simulateinput": "cinvname,ipbvquantity,iorimoney",
    "@refcardnumber": "defval",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "25处理成功!新增成功！",
    "@retid": "1000000416",
    "@retcode": "0000000398",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "25",
      "@ccardname": "专用发票",
      "head": {
        "z:row": {
            "@ivtid": "8163",
            "@ufts": "                      499.6765",
            "@csource": "采购",
            "@pbvid": "1000000001",
            "@cpbvbilltype": "01",
            "@cpbvcode": "0000000001",
            "@cptcode": "01",
            "@cptname": "采购类型01",
            "@dpbvdate": "2026-07-26T00:00:00",
            "@cvencode": "01001",
            "@cvenabbname": "供应商01001",
            "@cunitcode": "01001",
            "@cvenabbname_1": "供应商01001",
            "@cvenname": "供应商01001",
            "@cexch_name": "人民币",
            "@cexch_code": "RMB",
            "@cexchrate": "1",
            "@ipbvtaxrate": "13",
            "@cbustype": "普通采购",
            "@cpbvmaker": "demo",
            "@bnegative": "False",
            "@boriginal": "False",
            "@bfirst": "False",
            "@idiscounttaxtype": "0",
            "@dgatheringdate": "2026-07-26T00:00:00",
            "@bpayment": "0",
            "@bsettle": "0",
            "@bcredit": "0",
            "@iprintcount": "0",
            "@cmaketime": "2026-08-26T15:03:19.31",
            "@iswfcontrolled": "False",
            "@iverifystateex": "0",
            "@ireturncount": "0",
            "@csysbarcode": "||puzl|0000000001",
            "@bmerger": "0",
            "@editprop": ""
        }
      },
      "body": {
        "z:row": {
            "@id": "1000000001",
            "@pbvid": "1000000001",
            "@cinvcode": "01001",
            "@cinvname": "存货01001",
            "@cinvccode": "01",
            "@cunitid": "01002",
            "@cinvm_unit": "固定01主",
            "@igrouptype": "1",
            "@cgroupcode": "01",
            "@cbaccounter": "",
            "@cinva_unit": "固定01辅",
            "@bservice": "False",
            "@iinvexchrate": "10.00000000",
            "@binvbatch": "False",
            "@ipbvquantity": "12.0000000000",
            "@inum": "1.2000000000",
            "@ioricost": "110.2500000000",
            "@iorimoney": "1323",
            "@ioritaxprice": "171.99",
            "@iorisum": "1494.99",
            "@icost": "110.2500000000",
            "@imoney": "1323",
            "@itaxprice": "171.99",
            "@isum": "1494.99",
            "@ioritotal": "0",
            "@itotal": "0",
            "@bexbill": "False",
            "@binvtype": "False",
            "@itaxrate": "13.0000000000",
            "@ccomunitcode": "01001",
            "@ioritaxcost": "124.582500",
            "@isPayment": "0",
            "@isSettle": "0",
            "@bcosting": "False",
            "@btaxcost": "True",
            "@ivouchrowno": "1",
            "@cinvcname": "存货分类01",
            "@cbsysbarcode": "||puzl|0000000001|1",
            "@bgift": "0",
            "@editprop": ""
        }
      }
    }
  }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。
