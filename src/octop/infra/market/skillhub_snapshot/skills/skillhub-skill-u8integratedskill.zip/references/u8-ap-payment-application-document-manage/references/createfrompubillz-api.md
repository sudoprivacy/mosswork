# 根据采购专用发票生成付款申请单接口参考

## 请求报文模板
参数格式如下
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "AP40",
        "@simulateinput": "cDwCode",
        "@refcardnumber": "25",
        "@efdebug": "1",
        "@proc": "Add",
        "@refccode": "",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "row": {
                    "@cDwCode": "",
                    "@dVouchDate": ""
                    }
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号，付款申请单 的单据编号是 AP40   |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cDwCode |
| `@refcardnumber` | 是 | 开启模拟输入，默认：25 |
| `@refccode` | 否 | 非必输参数，采购发票单号（调用U8智能体服务 MCP提示“查到多张采购发票，请确认采购发票信息：”时，根据用户选择的采购发票号作为此参数输入）|
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |

**head单据头信息说明**
- `row` — 单据头对象

**head单据头row节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cDwCode` | 否 | 非必输参数，供应商编码 或者名称（采购发票单号refccode有值时该参数可以不用输入） |
| `@dVouchDate` | 是 | 日期 未指定日期时取系统当天日期 |


返回的结果如下
```json
{
         "ufinterface": {
        "@efserverid": "",
        "@eftype": "AP40",
        "@simulateinput": "cDwCode",
        "@refcardnumber": "25",
        "@refccode": "",
        "@proc": "Add",
        "@efdebug": "0",
        "@succeed": "1",
        "@dsc": "AP40处理成功!新增成功！",
        "@retid": "XXXXXXXXXX",
        "@retcode": "XXXXXXXXXX",
        "voucher": {
            "@cardnumber": "AP40",
            "@ccardname": "付款申请单",
            "@xmlns:z": "EF",
            "head": {
                "row": {
                    "@PID": "XXXXXXXXXX",
                    "@cVouchType": "AP40",
                    "@cTypeName": "付款申请单",
                    "@cVouchID": "XXXXXXXXXX",
                    "@dVouchDate": "2026-08-08T00:00:00",
                    "@cDwCode": "示例供应商编码",
                    "@cVenAbbName": "示例供应商简称",
                    "@cVenName": "示例供应商名称",
                    "@cDepCode": "示例部门编码",
                    "@cDepName": "示例部门名称",
                    "@cPerson": "示例业务员编码",
                    "@cPersonName": "示例业务员名称",
                    "@cSSCode": "1",
                    "@cSSName": "现金",
                    "@cCode": "",
                    "@cexch_name": "人民币",
                    "@iExchRate": "1",
                    "@cFlag": "AP",
                    "@cCheckMan": "示例审核人名称",
                    "@cOperator": "示例操作员名称",
                    "@cBank": "工行上地支行",
                    "@cBankAccount": "223355876",
                    "@VT_ID": "30978",
                    "@Ufts": "                      888.7616",
                    "@cDefine1": "",
                    "@dcreatesystime": "2026-08-11T15:04:51.473",
                    "@dverifysystime": "2026-08-11T15:04:07.97",
                    "@dmodifysystime": "2026-08-11T15:04:06.68",
                    "@cmodifier": "示例修改操作员名称",
                    "@dmoddate": "2026-08-08T00:00:00",
                    "@dverifydate": "2026-08-08T00:00:00",
                    "@ibg_overflag": "0",
                    "@iPayType": "0",
                    "@cPayType": "货款",
                    "@csysbarcode": "||ap40|XXXXXXXXXX",
                    "@cSubId": "AP",
                    "@keyextend_t_pid_ap_applypayvouch_extradefine_pid": "XXXXXXXXXX",
                    "@iAmount_B": "0",
                    "@ccode_name": ""
                }
            },
            "body": {
                "row": {
                    "@PID": "XXXXXXXXXX",
                    "@AutoID": "XXXXXXXXXX",
                    "@dPrePayDate": "2026-08-11T00:00:00",
                    "@dActPayDate": "2026-08-08T00:00:00",
                    "@cDepCode": "示例部门编码",
                    "@cDepName": "示例部门名称",
                    "@cPerson": "示例业务员编码",
                    "@cPersonName": "示例业务员名称",
                    "@iApplyAmt_f": "100",
                    "@iApplyAmt": "100",
                    "@iTaxRate": ".0000000000",
                    "@iNotRateApplyAmt_f": "100",
                    "@iNotRateApplyAmt": "100",
                    "@iAuditAmt_f": "100",
                    "@iAuditAmt": "100",
                    "@iDiscountTaxType": "0",
                    "@cbsysbarcode": "||ap40|XXXXXXXXXX|1",
                    "@editprop": ""
                }
            }
        }
    }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。接口调用说明：用户表示根据采购专用发票生成付款申请单时, 设置参数refcardnumber=25，在未提供采购发票号情况下，可以调用U8智能体服务 MCP，采购发票号不是必输项，系统会返回可申请的采购专用发票列表供用户选择。生单前需提示用户"采购专用发票生成付款申请单不支持部分金额申请，只能按整张发票的可申请金额申请。"
