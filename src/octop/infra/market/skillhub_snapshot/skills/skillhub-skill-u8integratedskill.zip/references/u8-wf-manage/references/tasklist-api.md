# 获取审批任务列表接口参考

## 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "AuditSrv",
        "@efdebug": "1",
        "@proc": "TaskList"
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 固定值 AuditSrv   |
| `@proc` | 是 | 操作类型，固定值 TaskList |



### 返回的结果如下
```json
{
    "ufinterface": {
        "@efserverid": "",
        "@eftype": "AuditSrv",
        "@proc": "TaskList",
        "@succeed": "1",
        "@dsc": "MaAuditSrv处理成功!",
        "voucher": {
            "@cardnumber": "EFSQL",
            "@ccardname": "",
            "@xmlns:z": "EF",
            "@pagesize": "200",
            "@pagenumer": "1",
            "@rownumbers": "4",
            "@pages": "1",
            "head": {
                "z:row": [
                    {
                        "@SenderTime": "2026-10-30 10:43:26.643000000",
                        "@TaskID": "D4120FB5-D883-4D97-9506-9544FC4DD6B8",
                        "@TaskName": "王铭 提交的请购单 0000000020 已进入审批流，等待您的审批！",
                        "@cvouchertype": "27",
                        "@cvoucherid": "1000000029",
                        "@ProcessInstanceID": "BC89CDE9-CE7D-4508-8D12-AD0D26C30731",
                        "@state": "未处理",
                        "@cuserid": "00001",
                        "@RowNumberForSplit": "1"
                    },
                    {
                        "@SenderTime": "2026-10-30 10:34:45.007000000",
                        "@TaskID": "360EF503-6FAA-4E6B-A7FD-DD6BEED82336",
                        "@TaskName": "王铭 提交的请购单 0000000019 已进入审批流，等待您的审批！",
                        "@cvouchertype": "27",
                        "@cvoucherid": "1000000028",
                        "@ProcessInstanceID": "F5F55EC8-5D68-42CD-878D-9C04D18FA79C",
                        "@state": "未处理",
                        "@cuserid": "00001",
                        "@RowNumberForSplit": "2"
                    },
                    {
                        "@SenderTime": "2015-01-05 15:33:29.107000000",
                        "@TaskID": "F8CC69C5-AC14-44CE-B7E3-E3F6A4E44991",
                        "@TaskName": "郭辉 提交的加班 JB2014122700025 已进入审批流，等待您的审批！",
                        "@cvouchertype": "HR.OverTimeResult",
                        "@cvoucherid": "0fa3bf8a-3ef3-4a00-87c8-d8abefc3811b",
                        "@ProcessInstanceID": "94D67B9F-0A01-435A-9E41-4E46533F1DF8",
                        "@state": "未处理",
                        "@cuserid": "00001",
                        "@RowNumberForSplit": "3"
                    },
                    {
                        "@SenderTime": "2014-12-31 15:16:24.390000000",
                        "@TaskID": "A4AC7704-E9D4-4A04-B131-25D22A91C214",
                        "@TaskName": "郭辉 提交的加班 JB2014122700026 已进入审批流，等待您的审批！",
                        "@cvouchertype": "HR.OverTimeResult",
                        "@cvoucherid": "1822f47b-1c73-4c8b-bb78-ca2cdb9ee819",
                        "@ProcessInstanceID": "131FC58D-957C-4DB3-A8F5-14FE8D31AC74",
                        "@state": "未处理",
                        "@cuserid": "00001",
                        "@RowNumberForSplit": "4"
                    }
                ]
            },
            "body": null
        },
        "inf": {
            "@succeed": "1",
            "@dsc": "OK",
            "@errmsg": "",
            "@cuserid": "demo",
            "@cuserpassword": "***",
            "@audited": "0 表示未处理, 1 表示包含已处理, 2 表示已处理"
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "MaAuditSrv处理成功!"
        }
    }
}
```
### 字段释义
| 字段 | 说明 |
|------|------|
| taskId | 审批任务ID |
| TaskName | 审批任务名称 |
| cvouchertype | 单据类型 |
| billNo | 单据编号 |
| ProcessInstanceID | 流程实例ID |
| state | 任务状态 |
| cuserid | 当前操作员id |

⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。
