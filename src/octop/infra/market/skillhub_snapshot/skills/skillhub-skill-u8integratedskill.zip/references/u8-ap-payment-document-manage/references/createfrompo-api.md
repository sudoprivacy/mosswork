# 根据采购订单生成付款单接口参考

## 请求报文模板
参数格式如下
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "AP49",
        "@simulateinput": "cDwCode",
        "@refcardnumber": "88",
        "@efdebug": "1",
        "@proc": "Add",
        "@refccode": "",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "row": {
                    "@cDwCode": "",
                    "@dVouchDate": "",
                    "@iAmount_f": ""
                    }
            },
            "body": {
                "row": [{
                    "@iType": "",
                    "@iAmt_f":"",
                    "@cCoVouchID": ""
                    }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号，付款单 的单据编号是 AP49   |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cDwCode |
| `@refcardnumber` | 是 | 来源单据类型，默认：88 |
| `@refccode` | 否 | 非必输参数，采购订单号（调用U8智能体服务 MCP提示“查到多张采购订单，请确认采购订单信息：”时，根据用户选择的采购订单号作为此参数输入） |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |

**head单据头信息说明**
- `row` — 单据头对象

**head单据头row节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cDwCode` | 否 | 非必输参数，供应商编码 或者名称（采购订单号refccode有值时该参数可以不用输入） |
| `@cSSCode` | 否 | 非必输参数，结算方式编码 或者名称（调用U8智能体服务 MCP提示“请确认结算方式信息：”时，根据用户选择的结算方式编号作为此参数输入） |
| `@dVouchDate` | 是 | 日期 未指定日期时取系统当天日期 |
| `@iAmount_f` | 否 | 非必输参数，金额 或 付款金额 |


**body单据体信息说明**
- `row` — 单据体对象数组

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@iType` | 是 | 款项类型，默认：0 (款项类型为"应付款"时，iType=0 ; 为"预付款"时，iType=1; 为"其他费用"时，iType=2; 为"手续费"时，iType=3; 为"利息"时，iType=4) |
| `@iAmt_f` | 否 | 非必输参数，金额 或 付款金额 |
| `@cCoVouchID` | 否 | 非必输参数，付款申请单号 |

返回的结果如下
```json
{
        "ufinterface": {
        "@efserverid": "",
        "@eftype": "AP49",
        "@simulateinput": "cDwCode",
        "@refcardnumber": "88",
        "@refccode": "",
        "@proc": "Add",
        "@efdebug": "0",
        "@succeed": "1",
        "@dsc": "AP49处理成功!新增成功！",
        "@retid": "XXXXXXXXXX",
        "@retcode": "XXXXXXXXXX",
        "voucher": {
            "@cardnumber": "AP49",
            "@ccardname": "应付付款单",
            "@xmlns:z": "EF",
            "head": {
                "row": {
                    "@iID": "XXXXXXXXXX",
                    "@cVouchType": "49",
                    "@cVouchID": "XXXXXXXXXX",
                    "@dVouchDate": "2015-01-01T00:00:00",
                    "@cDwCode": "示例供应商编码",
                    "@cSSCode": "1",
                    "@cDeptCode": "示例部门编码",
                    "@cBankAccount": "223355876",
                    "@cSSName": "现金",
                    "@iPeriod": "1",
                    "@cPerson": "示例业务员编码",
                    "@cPersonName": "示例业务员名称",
                    "@cexch_name": "人民币",
                    "@iExchRate": "1",
                    "@iAmount_f": "100",
                    "@iAmount": "100",
                    "@iNotRateAmount_f": "100",
                    "@iNotRateAmount": "100",
                    "@iRAmount_f": "100",
                    "@iRAmount": "100",
                    "@iAmount_s": "0",
                    "@cTypeName": "付款单",
                    "@cVenAbbName": "示例供应商简称",
                    "@cVenName": "示例供应商名称",
                    "@cDepName": "示例部门名称",
                    "@cFlag": "AP",
                    "@cOperator": "示例操作员名称",
                    "@iPayForOther": "False",
                    "@cBank": "工行上地支行",
                    "@bFromBank": "False",
                    "@bToBank": "False",
                    "@bSure": "False",
                    "@cCode": "",
                    "@bStartFlag": "False",
                    "@cCreditCode": "",
                    "@VT_ID": "8053",
                    "@Ufts": "                      888.7617",
                    "@cDefine1": "",
                    "@dcreatesystime": "2026-08-11T15:04:08.957",
                    "@cApplyCode": "XXXXXXXXXX",
                    "@cbg_itemcode": "",
                    "@cbg_itemname": "",
                    "@cbg_caliberkey1": "",
                    "@cbg_caliberkeyname1": "",
                    "@cbg_caliberkey2": "",
                    "@cbg_caliberkeyname2": "",
                    "@cbg_caliberkey3": "",
                    "@cbg_caliberkeyname3": "",
                    "@cbg_calibercode1": "",
                    "@cbg_calibername1": "",
                    "@cbg_calibercode2": "",
                    "@cbg_calibername2": "",
                    "@cbg_calibercode3": "",
                    "@cbg_calibername3": "",
                    "@cbg_caliberkey4": "",
                    "@cbg_caliberkeyname4": "",
                    "@cbg_caliberkey5": "",
                    "@cbg_caliberkeyname5": "",
                    "@cbg_caliberkey6": "",
                    "@cbg_caliberkeyname6": "",
                    "@cbg_calibercode4": "",
                    "@cbg_calibername4": "",
                    "@cbg_calibercode5": "",
                    "@cbg_calibername5": "",
                    "@cbg_calibercode6": "",
                    "@cbg_calibername6": "",
                    "@IsWfControlled": "False",
                    "@iPayType": "0",
                    "@cPayType": "0",
                    "@csysbarcode": "||ap49|XXXXXXXXXX",
                    "@keyextend_t_iid_ap_closebill_extradefine_iid": "XXXXXXXXXX",
                    "@iAmount_B": "0",
                    "@ccode_name": ""
                }
            },
            "body": {
                "row": {
                    "@iID": "XXXXXXXXXX",
                    "@ID": "XXXXXXXXXX",
                    "@bPrePay": "False",
                    "@iType": "0",
                    "@cType": "应付款",
                    "@cCoVouchID": "XXXXXXXXXX",
                    "@cVenAbbName": "示例供应商简称",
                    "@iAmt_f": "100",
                    "@iAmt": "100",
                    "@cKm": "",
                    "@cDepName": "示例部门名称",
                    "@cPersonName": "示例业务员名称",
                    "@iRAmt_f": "100",
                    "@iRAmt": "100",
                    "@cCusVen": "示例供应商编码",
                    "@iAmt_s": "0",
                    "@iRAmt_s": "0",
                    "@cDepCode": "示例部门编码",
                    "@cPersonCode": "示例业务员编码",
                    "@ifaresettled_f": "0",
                    "@editprop": "",
                    "@ccode_name": ""
                }
            }
        }
    }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。接口调用说明：用户表示根据采购订单生成付款单时，设置参数refcardnumber=88，在未提供采购订单号的情况下，可以调用U8智能体服务 MCP，采购订单号不是必输项，系统会返回可付款的采购订单列表供用户选择。
