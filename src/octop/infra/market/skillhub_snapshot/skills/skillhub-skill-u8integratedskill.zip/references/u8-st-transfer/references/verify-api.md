# 审核调拨单接口参考

实现方式为 调用  U8智能体服务 MCP  
参数格式如下

## 请求报文模板
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "0304",
        "@proc": "query",
        "@actions": "verify",
        "@efdebug": "1",
        "@efid": "调拨单ID"
    }
}
```


## 请求参数说明

| 字段 |  说明 |
|------|------|------|------|
| `@efuid` |  服务识别码，从当前会话中获取|
| `@efserverid` | 账套标识，从当前会话中获取 |
| `@eftype` | **单据类型编号：调拨单 = `0304`** |
| `@proc` | 操作类型，固定值:query |
| `@actions` | 操作类型，默认：verify |
| `@efid` | 调拨单ID，默认传入创建调拨单时返回Json结果的@retid参数的值 |
| `@efdebug` | 展示字段描述信息，默认：0 |

## 返回结果的Json字段说明
- `actions` — 审核结果的信息对象

**actions**
| 参数名称 | 参数解释 |
| --- | --- |
| `@action_verify_succeed` |  审核是否成功，1：成功，0：审核失败 |
| `@action_verify_dsc` |  审核结果的描述信息 |

## 调拨单根据返回数据集字段判断审核状态:"@cverifyperson"不为空时表示已审核,不要使用"@iverifystate"字段
