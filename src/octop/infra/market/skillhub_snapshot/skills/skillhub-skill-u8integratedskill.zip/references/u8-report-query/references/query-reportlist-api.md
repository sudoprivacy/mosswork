# 查询报表列表接口参考

## 请求报文模板
```JSON
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "U8Rep",
        "@token": "",
        "@proc": "query",
        "@request": "{\"actionname\": \"getreportlist\",  \"params\": [{\"value\": \"demo\", \"@id\": \"userid\"}]}",
        "@efdebug":"1",
        "@version": "18.000",
        "@refcardnumber": "?"
    }
}
```
## 参数说明
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | U8服务识别码,从当前会话中获取|
| `@efserverid` | 是 | 账套标识标识,从当前会话中获取 |
| `@token` | 是 | 登录令牌token,从当前会话中获取 |
| `@request` | 是 | 查询参数 |

## 返回结果：
```JSON
{
    "ufinterface": {
        "@efserverid": "",
        "@eftype": "U8Rep",
        "@proc": "query",
        "@request": "{\"actionname\": \"getreportlist\",  \"params\": [{\"value\": \"demo\", \"@id\": \"userid\"}]}",
        "@efdebug": "1",
        "@version": "18.000",
        "@refcardnumber": "?",
        "@runtimeb": "2026-07-23 11:30:36",
        "@succeed": "1",
        "@dsc": "U8Rep处理成功!",
        "@runtimee": "2026-07-23 11:30:37",
        "GetServiceMsgResult": {
            "resresult": {
                "flag": "0",
                "desc": "查询报表列表信息成功！",
                "resdata": {
                    "reportList": {
                        "report": [
                            {
                                "solutionId": "A04DCE85-1FA6-4649-B62A-6AC72D094013",
                                "subId": "PU",
                                "name": "采购订单执行统计表",
                                "scheme": "移动方案"
                            },
                            {
                                "solutionId": "171D4650-EADB-472F-BF05-6922C91DC10E",
                                "subId": "SA",
                                "name": "订单执行统计表",
                                "scheme": "移动方案"
                            },
                            {
                                "solutionId": "590F7351-CA8F-4ADE-A5D3-96EB0124AE21",
                                "subId": "SA",
                                "name": "发货统计表",
                                "scheme": "移动方案"
                            },
                            {
                                "solutionId": "56D597E4-EF70-4185-8643-3E29F2970E69",
                                "subId": "EB",
                                "name": "库存查询预警",
                                "scheme": "移动方案"
                            },
                            {
                                "solutionId": "1A6763C3-70A4-49BD-BB61-CE1D6E910F8D",
                                "subId": "PU",
                                "name": "未完成业务明细表",
                                "scheme": "移动方案"
                            },
                            {
                                "solutionId": "C15D7FB5-7855-4B09-88DF-4F2FBD931A43",
                                "subId": "ST",
                                "name": "现存量查询",
                                "scheme": "移动方案"
                            },
                            {
                                "solutionId": "B5BD33DA-27EF-4E93-AFDF-4CF6EC9A6A4D",
                                "subId": "EB",
                                "name": "销售利润统计表",
                                "scheme": "移动方案"
                            }
                        ]
                    }
                }
            }
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "U8Rep处理成功!"
        }
    }
}
```