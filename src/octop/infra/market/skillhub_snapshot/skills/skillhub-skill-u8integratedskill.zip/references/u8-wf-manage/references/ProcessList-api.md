# 执行查看审批进程（ProcessList）接口参考

## 请求报文模板
参数格式如下
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "AuditSrv",
        "@proc": "ProcessList",
        "@token": "",        
        "@succeed": "0",
        "inf": {
            "@cvouchertype": "",
            "@cvoucherid": "",
            "@cvouchercode": "",
            "@succeed": "0"
        },
        "runafter": {
            "@succeed": "0",
            "@dsc": ""
        }
    }
}
```
**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid`|是 | 账套标识，从当前会话中获取|
| `@eftype` | 是 | 固定值 AuditSrv |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@proc` | 是 | 固定值  ProcessList |
| `@cvouchertype` | 是 | 单据类型 |
| `@cvoucherid` | 否 | 单据ID |
| `@cvouchercode` | 否 | 单据编码 |
## 返回的完整结果示例如下：
```json
{
    "ufinterface": {
        "@efserverid": "AI999",
        "@eftype": "AuditSrv",
        "@userid": "demo",
        "@pass": "",
        "@proc": "ProcessList",
        "@succeed": "1",
        "@dsc": "AuditSrv处理成功!",
        "inf": {
            "@cvouchertype": "27",
            "@cvoucherid": "1000000048",
            "@cvouchercode": "0000000039",
            "@succeed": "0"
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "AuditSrv处理成功!"
        },
        "AuditItems": {
            "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            "@xmlns:xsd": "http://www.w3.org/2001/XMLSchema",
            "AuditItemInfo": [
                {
                    "bSignature": "false",
                    "Signatureid": null,
                    "TaskId": "dd01cf51-8bff-49b1-bdbb-6203c5988d7d",
                    "TaskName": "王铭 提交的请购单 0000000039 已进入审批流，等待您的审批！",
                    "VoucherId": "1000000048",
                    "VoucherType": "27",
                    "VoucherCode": "0000000039",
                    "FromUserId": null,
                    "FromUserName": null,
                    "OperatorName": "王铭",
                    "OriginalName": null,
                    "OriginalID": null,
                    "Id": "acb213b4-20f2-4e81-9f78-3e8aea029f68",
                    "ProcessId": "ff01f58c-798d-4017-b8ec-dfda4fb6eeb1",
                    "InstanceId": "ff01f58c-798d-4017-b8ec-dfda4fb6eeb1",
                    "ActivatyId": "56449eaf-4d28-426e-b62a-f6c722246bcf",
                    "Opinion": "同意",
                    "Attachment": null,
                    "Signature": "signature",
                    "Action": "1",
                    "AccountId": "999",
                    "AccountYear": "2026",
                    "OperatorId": "00001",
                    "OperationDate": "2026-11-02T15:43:40.817",
                    "BizEventId": "27.Audit",
                    "BizObjectId": "27",
                    "MessageId": null
                },
                {
                    "bSignature": "false",
                    "Signatureid": null,
                    "TaskId": null,
                    "TaskName": "提交审批",
                    "VoucherId": "1000000048",
                    "VoucherType": "27",
                    "VoucherCode": "0000000039",
                    "FromUserId": null,
                    "FromUserName": null,
                    "OperatorName": "王铭",
                    "OriginalName": null,
                    "OriginalID": null,
                    "Id": "2d7b91ac-ddae-4cf3-bc95-41f106c7ca50",
                    "ProcessId": "00000000-0000-0000-0000-000000000000",
                    "InstanceId": "00000000-0000-0000-0000-000000000000",
                    "ActivatyId": "00000000-0000-0000-0000-000000000000",
                    "Opinion": null,
                    "Attachment": null,
                    "Signature": "signature",
                    "Action": "0",
                    "AccountId": "999",
                    "AccountYear": "2026",
                    "OperatorId": "00001",
                    "OperationDate": "2026-11-02T15:23:28.647",
                    "BizEventId": "27.Submit",
                    "BizObjectId": "27",
                    "MessageId": null
                }
            ]
        }
    }
}
```
### 字段释义
| 字段 | 说明 | 是否显示 |
|------|------|
| TaskName | 审批任务名称 |是|
| VoucherId | 单据id |是|
| VoucherType | 单据类型 |是|
| VoucherCode | 单据编码 |是|
| Action | 审批动作 0 提交 1 同意 2 不同意 3 转签 4 打回 5  撤销 6 退回 7 弃审 8 打回后重新提交 12 会签同意 13 会签不同意 14 会签待审 |是|
| OperatorName | 操作员 |是|
| OperationDate | 操作时间 |是|
| Opinion | 审批意见 |是|

其它不显示

⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。