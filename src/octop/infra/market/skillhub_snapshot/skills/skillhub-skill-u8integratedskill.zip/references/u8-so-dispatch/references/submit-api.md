# 提交发货单接口参考

实现方式为 调用  U8智能体服务 MCP  
参数格式如下

## 请求报文模板
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "01",
        "@proc": "query",
        "@actions": "Submit",
        "@efdebug": "1",
        "@efid": "",
        "@efccode": ""
    }
}
```


## 请求参数说明

| 字段 |  说明 |
|------|------|------|------|
| `@efuid` |  服务识别码，从当前会话中获取|
| `@efserverid` | 账套标识标识 |
| `@eftype` | **单据类型编号：发货单 = `01`** |
| `@proc` | 操作类型，固定值:query |
| `@actions` | 操作类型，默认：Submit |
| `@efid` | 发货单ID，默认传入创建发货单时返回Json结果的@retid参数的值 |
| `@efccode` | 发货单单据号，默认传入创建发货单时返回Json结果的@retcode参数的值 |
| `@efdebug` | 展示字段描述信息，默认：0 |

## 返回结果的Json字段说明
- `actions` — 提交结果的信息对象

**actions**
| 参数名称 | 参数解释 |
| --- | --- |
| `@action_Submit_succeed` |  提交是否成功，1：成功，0：提交失败 |
| `@action_Submit_dsc` |  提交结果的描述信息 |
