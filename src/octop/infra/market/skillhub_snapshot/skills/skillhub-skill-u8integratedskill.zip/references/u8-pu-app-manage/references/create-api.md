# 创建采购请购单接口参考

## 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "27",
        "@token": "",
        "@simulateinput": "cinvcode,fquantity,funitprice",
        "@refcardnumber": "defval",
        "@proc": "add",
        "@efdebug": "1",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@cbustype": "普通采购",
                    "@ddate":"2014-12-13 00:00:00"
                }
            },
            "body": {
                "z:row": [{
                    "@fquantity": "20.000000",
                    "@funitprice":1,
                    "@cinvcode": "010211",
                    "@drequirdate": "2014-12-23 00:00:00",
                    "@darrivedate": "2014-12-13 00:00:00",
                    "@cfactorycode": "",
                    "@cexch_name": "人民币",
                    "@iexchrate": "1.0000000000",
                    "@cfactoryname": ""
                }]
            }
        }
    }
}
```
## 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | U8服务识别码，从当前会话中获取|
| `@efserverid` | 是 | 账套标识标识 |
| `@eftype` | 是 | 单据类型编号，默认 27   |
| `@token` | 是 | 登录令牌token |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvcode,iquantity,funitprice |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |

**head单据头信息说明**
- `row` — 单据头对象

**head单据头row节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@ddate` | 是 | 日期 |
| `@cbustype` | 否 | 业务类型，默认值：普通采购 |
| `@cdepname` | 否 | 请购部门 |
| `@ipresent` | 否 | 现存量 |
| `@cptname` | 否 | 采购类型 |
| `@cpersonname` | 否 | 请购人员 |


**body单据体信息说明**
- `row` — 单据体对象数组

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cinvcode` | 是 | 存货编码 |
| `@fquantity` |是 | 数量 |
| `@iexchrate` | 是 | 汇率 |
| `@drequirdate` |是 | 需求日期 |
| `@darrivedate` |是 | 建议订货日期 |
| `@cvencode` | 是 | 供应商编码 |
| `@cfactorycode` | 否 | 工厂编码编码或者名称 |
| `@funitprice` |否 | 本币单价或单价 |



## 返回的结果如下
```json
{
    "ufinterface": {
        "@efserverid": "",
        "@eftype": "27",
        "@simulateinput": "cinvcode,iquantity,funitprice",
        "@refcardnumber": "defval",
        "@proc": "add",
        "@efdebug": "1",
        "@runtimeb": "2026-07-30 09:26:33",
        "@succeed": "1",
        "@dsc": "27处理成功!",
        "@retid": "1000000048",
        "@retcode": "0000000038",
        "@runtimee": "2026-07-30 09:26:34",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@cbustype": "普通采购",
                    "@ddate": "2014-12-13 00:00:00"
                }
            },
            "body": {
                "z:row": {
                    "@fquantity": "20.000000",
                    "@cinvcode": "010211",
                    "@drequirdate": "2014-12-23 00:00:00",
                    "@darrivedate": "2014-12-13 00:00:00",
                    "@cfactorycode": "001",
                    "@cexch_name": "人民币",
                    "@iexchrate": "1.0000000000",
                    "@cfactoryname": "工厂一"
                }
            }
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "27处理成功!"
        }
    }
}
```
其中@retid 是单据ID

⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。
