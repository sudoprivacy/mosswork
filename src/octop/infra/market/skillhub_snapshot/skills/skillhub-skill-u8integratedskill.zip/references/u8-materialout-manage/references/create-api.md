# 创建材料出库单接口参考

实现方式为 调用  U8智能体服务 MCP 
参数格式如下
## 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "0412",
        "@simulateinput": "cinvname,iquantity",
        "@refcardnumber": "defval",
        "@efdebug": "1",
        "@proc": "Add",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@cwhcode": "01"
                    }
            },
            "body": {
                "z:row": [{
                    "@cinvname": "01001",
                    "@iquantity": "1.00"
                    }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号，默认 0412   |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvname,iquantity |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |

**head单据头信息说明**
- `row` — 单据头对象

**head单据头row节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cwhcode` | 是 | 仓库编码 |
| `@cbustype` | 是 | 默认值领料 |
| `@cmaker` | 是 | 默认值当前登录人 |

**body单据体信息说明**
- `row` — 单据体对象数组

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cinvname` | 是 | 存货编码或者名称 |
| `@iQuantity` | 是 | 数量 |


返回的结果如下
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "0412",
    "@simulateinput": "cinvname,iquantity",
    "@refcardnumber": "defval",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "0412处理成功!新增成功！",
    "@retid": "1000000416",
    "@retcode": "0000000398",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "0412",
      "@ccardname": "材料出库单",
      "head": {
        "z:row": {
          "@id": "1000000018",
                    "@brdflag": "0",
                    "@cvouchtype": "11",
                    "@csysbarcode": "||st11|0000000001",
                    "@cwhcode": "01",
                    "@ddate": "2026-08-25T00:00:00",
                    "@ccode": "0000000001",
                    "@crdcode": "2",
                    "@cmaker": "demo",
                    "@cwhname": "仓库01",
                    "@crdname": "发2",
                    "@csource": "库存",
                    "@cbustype": "领料",
                    "@bisstqc": "False",
                    "@vt_id": "65",
                    "@imquantity": "0",
                    "@bpufirst": "False",
                    "@biafirst": "False",
                    "@iproorderid": "0",
                    "@biscomplement": "0",
                    "@ireturncount": "0",
                    "@iverifystate": "0",
                    "@iswfcontrolled": "0",
                    "@ufts": "                      498.8552",
                    "@cmodifyperson": "",
                    "@dnmaketime": "2026-08-25T13:54:56.733",
                    "@bomfirst": "0",
                    "@bmotran": "0",
                    "@chinvsn": "",
                    "@isourcerowno": "",
                    "@bhyvouch": "False",
                    "@iPrintCount": "0",
                    "@cchecksignflag": "6D14ED3B3C2E7C1134F2A0DCE2ADB5FB",
                    "@editprop": ""
        }
      },
      "body": {
        "z:row": {
          "@autoid": "1000000034",
                    "@id": "1000000018",
                    "@cinvcode": "01001",
                    "@cinvname": "存货01001",
                    "@cinvccode": "01",
                    "@cinvm_unit": "固定01主",
                    "@cinva_unit": "固定01辅",
                    "@iinvexchrate": "10.00000000",
                    "@inum": "1.2000000000",
                    "@iquantity": "12.0000000000",
                    "@cassunit": "01002",
                    "@corufts": "",
                    "@isotype": "0",
                    "@cdemandmemo": "",
                    "@iordertype": "0",
                    "@bcosting": "True",
                    "@bvmiused": "False",
                    "@iexpiratdatecalcu": "0",
                    "@cbinvsn": "",
                    "@irowno": "1",
                    "@ipesotype": "0",
                    "@cbsysbarcode": "||st11|0000000001|1",
                    "@bcanreplace": "0",
                    "@boutmaterials": "0",
                    "@taskguid": "",
                    "@editprop": "",
                    "@strowguid": "C83627C7-9F3D-4B70-AFA2-666F233B94F1"
        }
      }
    }
  }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。
