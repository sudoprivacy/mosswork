# 新建发货单接口参考

实现方式为 调用  U8智能体服务 MCP
参数格式如下

## 请求报文模板
```json
{
  "ufinterface": {
    "@efuid": "",
    "@efserverid": "",
    "@token": "",
    "@eftype": "01",
    "@simulateinput": "cinvcode,cinvname,iquantity,iunitprice",
    "@refcardnumber": "defval",
    "@efdebug": "1",
    "@proc": "Add",
    "voucher": {
      "@xmlns:z": "EF",
      "head": {
        "z:row": {
          "@ccuscode": "客户编码(必填)",
          "@cdepcode": "部门编码",
          "@cpersoncode": "业务员编码",
          "@cstcode": "销售类型编码",
          "@ddate": "发货日期"
        }
      },
      "body": {
        "z:row": [
          {
            "@cinvcode": "存货编码(必填)",
            "@cinvname": "存货名称(必填)",
            "@iquantity": "数量(必填)",
            "@cwhcode": "仓库编码"
          }
        ]
      }
    }
  }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 否 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | **单据类型编号：发货单 = `01`** |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvname,iquantity |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |


**head 单据头字段说明（已依实时返回示例确认）**
| @ 参数 | 必填 | 中文含义 | 可见性 |
|------|------|------|------|
| `@baccswitchflag` | 否 | 存货核算切换选项 | 模板隐藏 |
| `@bcashsale` | 否 | 现款结算 | 模板隐藏 |
| `@bcontinue` | 否 | 是否继续 | 模板隐藏 |
| `@bcredit` | 否 | 是否为立账单据 | 模板隐藏 |
| `@bfirst` | 否 | 期初标志 | 模板隐藏 |
| `@bmustbook` | 否 | 必有定金 | 模板隐藏 |
| `@bnottogoldtax` | 否 |  | 模板隐藏 |
| `@brefdisp` | 否 | 单据来源 | 模板隐藏 |
| `@brequestsign` | 否 | 需要签回 | 模板隐藏 |
| `@breturnflag` | 否 | 退货标识 | 模板隐藏 |
| `@bsaleoutcreatebill` | 否 | 出库单开发票 | 模板隐藏 |
| `@bsigncreate` | 否 | 签回损失生成 | 模板隐藏 |
| `@caddcode` | 否 | 收货地址编码 | 模板隐藏 |
| `@cbaccount` | 否 | 银行账号 | 模板隐藏 |
| `@cbcode` | 否 | 本单位开户行账号编号 | 模板隐藏 |
| `@cbname` | 否 | 本单位开户银行 | 模板隐藏 |
| `@cbustype` | 否 | 业务类型 | 模板可见 |
| `@cchangememo` | 否 | 变更原因 | 模板隐藏 |
| `@cchanger` | 否 | 变更人 | 模板隐藏 |
| `@ccloser` | 否 | 关闭人 | 模板可见 |
| `@ccontactname` | 否 | 收货联系人 | 模板隐藏 |
| `@ccrechpname` | 否 | 信用审核人 | 模板隐藏 |
| `@ccrechppass` | 否 | 信用审核口令 | 模板隐藏 |
| `@ccreditcuscode` | 否 | 信用单位编码 | 模板隐藏 |
| `@ccreditcusname` | 否 | 信用单位名称 | 模板隐藏 |
| `@ccusabbname` | 否 | 客户简称 | 模板可见 |
| `@ccusaddress` | 否 | 客户地址 | 模板隐藏 |
| `@ccuscode` | 是 | 客户编码 | 模板隐藏 |
| `@ccusdefine1` | 否 | 自定义项1 | 模板隐藏 |
| `@ccusdefine10` | 否 | 自定义项10 | 模板隐藏 |
| `@ccusdefine11` | 否 | 自定义项11 | 模板隐藏 |
| `@ccusdefine12` | 否 | 自定义项12 | 模板隐藏 |
| `@ccusdefine13` | 否 | 自定义项13 | 模板隐藏 |
| `@ccusdefine14` | 否 | 自定义项14 | 模板隐藏 |
| `@ccusdefine15` | 否 | 自定义项15 | 模板隐藏 |
| `@ccusdefine16` | 否 | 自定义项16 | 模板隐藏 |
| `@ccusdefine2` | 否 | 自定义项2 | 模板隐藏 |
| `@ccusdefine3` | 否 | 自定义项3 | 模板隐藏 |
| `@ccusdefine4` | 否 | 自定义项4 | 模板隐藏 |
| `@ccusdefine5` | 否 | 自定义项5 | 模板隐藏 |
| `@ccusdefine6` | 否 | 自定义项6 | 模板隐藏 |
| `@ccusdefine7` | 否 | 自定义项7 | 模板隐藏 |
| `@ccusdefine8` | 否 | 自定义项8 | 模板隐藏 |
| `@ccusdefine9` | 否 | 自定义项9 | 模板隐藏 |
| `@ccushand` | 否 | 客户联系人手机 | 模板隐藏 |
| `@ccusname` | 否 | 客户名称 | 模板隐藏 |
| `@ccuspaycond` | 否 | 客户付款条件 | 模板隐藏 |
| `@ccusperson` | 否 | 联系人 | 模板隐藏 |
| `@ccuspersoncode` | 否 | 联系人编码 | 模板隐藏 |
| `@ccusphone` | 否 | 联系电话 | 模板隐藏 |
| `@ccuspostcode` | 否 | 邮政编码 | 模板隐藏 |
| `@cdefine1` | 否 | 业务负责人 | 模板隐藏 |
| `@cdefine10` | 否 | 自定义项10 | 模板隐藏 |
| `@cdefine11` | 否 | 发货信息 | 模板隐藏 |
| `@cdefine12` | 否 | 自定义项12 | 模板隐藏 |
| `@cdefine13` | 否 | 自定义项13 | 模板隐藏 |
| `@cdefine14` | 否 | 自定义项14 | 模板隐藏 |
| `@cdefine15` | 否 | 自定义项15 | 模板隐藏 |
| `@cdefine16` | 否 | 自定义项16 | 模板隐藏 |
| `@cdefine2` | 否 | 自定义项2 | 模板隐藏 |
| `@cdefine3` | 否 | 电商交易单号 | 模板隐藏 |
| `@cdefine4` | 否 | 自定义项4 | 模板隐藏 |
| `@cdefine5` | 否 | 自定义项5 | 模板隐藏 |
| `@cdefine6` | 否 | 自定义项6 | 模板隐藏 |
| `@cdefine7` | 否 | 自定义项7 | 模板隐藏 |
| `@cdefine8` | 否 | 自定义项8 | 模板隐藏 |
| `@cdefine9` | 否 | 自定义项9 | 模板隐藏 |
| `@cdeliverunit` | 否 | 收货单位 | 模板隐藏 |
| `@cdepcode` | 是 | 部门编码 | 模板隐藏 |
| `@cdepname` | 否 | 销售部门 | 模板可见 |
| `@cdlcode` | 否 | 发货单号 | 模板可见 |
| `@cebbuyer` | 否 | 买家留言 | 模板隐藏 |
| `@cebbuyernote` | 否 | 卖家备注 | 模板隐藏 |
| `@cebcity` | 否 | 收货人市 | 模板隐藏 |
| `@cebdistrict` | 否 | 收货人区 | 模板隐藏 |
| `@cebexpresscode` | 否 | 快递单号 | 模板隐藏 |
| `@cebprovince` | 否 | 收货人省 | 模板隐藏 |
| `@cebtrnumber` | 否 | 交易编号 | 模板隐藏 |
| `@cebweightunit` | 否 | 重量单位 | 模板隐藏 |
| `@cexch_name` | 否 | 币种     | 模板可见 |
| `@cexpressconame` | 否 | 物流公司名称 | 模板隐藏 |
| `@cflowname` | 否 | 流程分支描述 | 模板隐藏 |
| `@cgatheringplan` | 否 | 收付款协议编码 | 模板隐藏 |
| `@cgatheringplanname` | 否 | 收付款协议名称 | 模板隐藏 |
| `@cgathingcode` | 否 | 收款单号 | 模板隐藏 |
| `@cgcroutecode` | 否 | 协同路线编码 | 模板隐藏 |
| `@cgcroutename` | 否 | 协同路线 | 模板隐藏 |
| `@chdefine1` | 否 | 扩展自定义项1 | 模板隐藏 |
| `@chdefine2` | 否 | aaaa | 模板隐藏 |
| `@cinvoicecompany` | 否 | 开票单位编码 | 模板隐藏 |
| `@cinvoicecompanyabbname` | 否 | 开票单位简称 | 模板隐藏 |
| `@cinvoicecusname` | 否 | 发票抬头 | 模板隐藏 |
| `@clastcusname` | 否 | 原客户名称 | 模板隐藏 |
| `@clowpricepass` | 否 | 最低售价口令 | 模板隐藏 |
| `@cmaker` | 否 | 制单人 | 模板可见 |
| `@cmemo` | 否 | 备注     | 模板可见 |
| `@cmobilephone` | 否 | 收货联系人手机 | 模板隐藏 |
| `@cmodifier` | 否 | 修改人 | 模板隐藏 |
| `@cofficephone` | 否 | 收货联系电话 | 模板隐藏 |
| `@cpaycode` | 否 | 付款条件编码 | 模板隐藏 |
| `@cpayname` | 否 | 付款条件 | 模板可见 |
| `@cpersoncode` | 是 | 业务员编码 | 模板隐藏 |
| `@cpersonname` | 否 | 业务员   | 模板可见 |
| `@cpsnmobilephone` | 否 | 业务员手机 | 模板隐藏 |
| `@cpsnophone` | 否 | 业务员办公电话 | 模板隐藏 |
| `@csbvcode` | 否 | 发票号   | 模板可见 |
| `@csccode` | 否 | 发运方式编码 | 模板隐藏 |
| `@cscname` | 否 | 发运方式 | 模板可见 |
| `@cshipaddress` | 否 | 发货地址 | 模板可见 |
| `@csocode` | 否 | 订单号   | 模板可见 |
| `@csourcecode` | 否 | 来源单据号 | 模板隐藏 |
| `@csscode` | 否 | 结算方式编码 | 模板隐藏 |
| `@cssname` | 否 | 结算方式 | 模板隐藏 |
| `@cstcode` | 是 | 销售类型编码 | 模板隐藏 |
| `@cstname` | 否 | 销售类型 | 模板可见 |
| `@csvouchtype` | 否 |  | 模板隐藏 |
| `@csysbarcode` | 否 | 单据条码 | 模板隐藏 |
| `@cusfactorycode` | 否 | 工厂编码 | 模板隐藏 |
| `@cusfactoryname` | 否 | 工厂名称 | 模板隐藏 |
| `@cusproxywh` | 否 | 代管仓 | 模板隐藏 |
| `@cuswhcode` | 否 | 客户仓库编码 | 模板隐藏 |
| `@cuswhisaconmode` | 否 | 客户仓库销售可用量控制方式 | 模板隐藏 |
| `@cuswhname` | 否 | 客户仓库名称 | 模板隐藏 |
| `@cverifier` | 否 | 审核人 | 模板可见 |
| `@cvouchname` | 否 | 单据类型名称 | 模板隐藏 |
| `@cvouchtype` | 否 | 单据类型编码 | 模板隐藏 |
| `@cweighter` | 否 | 称重人 | 模板隐藏 |
| `@dcreatesystime` | 否 | 制单时间 | 模板隐藏 |
| `@dcreditstart` | 否 | 立账日 | 模板隐藏 |
| `@ddate` | 是 | 发货日期 | 模板可见 |
| `@dgatheringdate` | 否 | 到期日 | 模板隐藏 |
| `@dhclosedate` | 否 | 关闭日期 | 模板隐藏 |
| `@dhclosesystime` | 否 | 关闭时间 | 模板隐藏 |
| `@dlid` | 否 | autoid | 模板隐藏 |
| `@dmoddate` | 否 | 修改日期 | 模板隐藏 |
| `@dmodifysystime` | 否 | 修改时间 | 模板隐藏 |
| `@dsverifydate` | 否 | 来源单据审核日期 | 模板隐藏 |
| `@dverifydate` | 否 | 审核日期 | 模板隐藏 |
| `@dverifysystime` | 否 | 审核时间 | 模板隐藏 |
| `@dweighttime` | 否 | 称重时间 | 模板隐藏 |
| `@fcanusequan` | 否 | 可用数量 | 模板隐藏 |
| `@fcanusequano` | 否 | 可用件数 | 模板隐藏 |
| `@febweight` | 否 | 重量 | 模板隐藏 |
| `@fstockquan` | 否 | 现存数量 | 模板隐藏 |
| `@fstockquano` | 否 | 现存件数 | 模板隐藏 |
| `@iarmoney` | 否 | 客户应收余额 | 模板隐藏 |
| `@icreditdays` | 否 | 账期 | 模板隐藏 |
| `@icreditstate` | 否 | icreditstate | 模板隐藏 |
| `@icuscreline` | 否 | 用户信用度 | 模板隐藏 |
| `@icustaxrate` | 否 | 客户税率 | 模板隐藏 |
| `@iebexpresscoid` | 否 | 物流公司ID | 模板隐藏 |
| `@iexchrate` | 否 | 汇率     | 模板可见 |
| `@iflowid` | 否 | 流程id | 模板隐藏 |
| `@ireturncount` | 否 | ireturncount | 模板隐藏 |
| `@isale` | 否 | 是否先发货 | 模板隐藏 |
| `@isumdx` | 否 | 价税合计（大写） | 模板隐藏 |
| `@isumx` | 否 | 价税合计 | 模板隐藏 |
| `@iswfcontrolled` | 否 | iswfcontrolled | 模板隐藏 |
| `@itaxrate` | 否 | 税率     | 模板可见 |
| `@iverifystate` | 否 | iverifystate | 模板隐藏 |
| `@ivtid` | 否 | 单据模版号 | 模板隐藏 |
| `@sbvid` | 否 | 销售发票ID | 模板隐藏 |
| `@separateid` | 否 | 分拣号 | 模板隐藏 |
| `@ufts` | 否 | 时间戳 | 模板隐藏 |
| `@zdsum` | 否 | 整单合计 | 模板隐藏 |
| `@zdsumdx` | 否 | 整单合计（大写） | 模板隐藏 |


**body 单据体字段说明（已依实时返回示例确认）**
| @ 参数 | 必填 | 中文含义 | 可见性 |
|------|------|------|------|
| `@autoid` | 否 | 自动编号 | 模板隐藏 |
| `@autoid2` | 否 | 序列号行号 | 模板隐藏 |
| `@batomodel` | 否 | 是否ATO件 | 模板隐藏 |
| `@bbatchcreate` | 否 | 批次属性是否建档 | 模板隐藏 |
| `@bbatchproperty1` | 否 | 是否启用批次属性1 | 模板隐藏 |
| `@bbatchproperty10` | 否 | 是否启用批次属性10 | 模板隐藏 |
| `@bbatchproperty2` | 否 | 是否启用批次属性2 | 模板隐藏 |
| `@bbatchproperty3` | 否 | 是否启用批次属性3 | 模板隐藏 |
| `@bbatchproperty4` | 否 | 是否启用批次属性4 | 模板隐藏 |
| `@bbatchproperty5` | 否 | 是否启用批次属性5 | 模板隐藏 |
| `@bbatchproperty6` | 否 | 是否启用批次属性6 | 模板隐藏 |
| `@bbatchproperty7` | 否 | 是否启用批次属性7 | 模板隐藏 |
| `@bbatchproperty8` | 否 | 是否启用批次属性8 | 模板隐藏 |
| `@bbatchproperty9` | 否 | 是否启用批次属性9 | 模板隐藏 |
| `@bfree1` | 否 | 是否有自由项1 | 模板隐藏 |
| `@bfree10` | 否 | 是否有自由项10 | 模板隐藏 |
| `@bfree2` | 否 | 是否有自由项2 | 模板隐藏 |
| `@bfree3` | 否 | 是否有自由项3 | 模板隐藏 |
| `@bfree4` | 否 | 是否有自由项4 | 模板隐藏 |
| `@bfree5` | 否 | 是否有自由项5 | 模板隐藏 |
| `@bfree6` | 否 | 是否有自由项6 | 模板隐藏 |
| `@bfree7` | 否 | 是否有自由项7 | 模板隐藏 |
| `@bfree8` | 否 | 是否有自由项8 | 模板隐藏 |
| `@bfree9` | 否 | 是否有自由项9 | 模板隐藏 |
| `@bgift` | 否 | 赠品 | 模板隐藏 |
| `@bgsp` | 否 | 是否gsp检验 | 模板隐藏 |
| `@binvbatch` | 否 | 是否批次管理 | 模板隐藏 |
| `@binvmodel` | 否 | 是否模型件 | 模板隐藏 |
| `@binvquality` | 否 | 是否保质期管理 | 模板隐藏 |
| `@binvtype` | 否 | 存货类型 | 模板隐藏 |
| `@bisstqc` | 否 | 库存期初 | 模板隐藏 |
| `@bmpforderclosed` | 否 | 是否订单关闭 | 模板隐藏 |
| `@bneedloss` | 否 | 需要损失处理 | 模板可见 |
| `@bneedsign` | 否 | 需要签回 | 模板可见 |
| `@bproxywh` | 否 | 是否代管仓 | 模板隐藏 |
| `@bptomodel` | 否 | bptomodel | 模板隐藏 |
| `@bqachecked` | 否 | 是否报检 | 模板隐藏 |
| `@bqachecking` | 否 | 是否在检 | 模板隐藏 |
| `@bqaneedcheck` | 否 | 是否质量检验 | 模板隐藏 |
| `@bqaurgency` | 否 | 是否急料 | 模板隐藏 |
| `@bsaleprice` | 否 | 报价含税 | 模板隐藏 |
| `@bsalepricefree1` | 否 | 是否自由项定价1 | 模板隐藏 |
| `@bsalepricefree10` | 否 | 是否自由项定价10 | 模板隐藏 |
| `@bsalepricefree2` | 否 | 是否自由项定价2 | 模板隐藏 |
| `@bsalepricefree3` | 否 | 是否自由项定价3 | 模板隐藏 |
| `@bsalepricefree4` | 否 | 是否自由项定价4 | 模板隐藏 |
| `@bsalepricefree5` | 否 | 是否自由项定价5 | 模板隐藏 |
| `@bsalepricefree6` | 否 | 是否自由项定价6 | 模板隐藏 |
| `@bsalepricefree7` | 否 | 是否自由项定价7 | 模板隐藏 |
| `@bsalepricefree8` | 否 | 是否自由项定价8 | 模板隐藏 |
| `@bsalepricefree9` | 否 | 是否自由项定价9 | 模板隐藏 |
| `@bserial` | 否 | 序列号管理 | 模板隐藏 |
| `@bservice` | 否 | 是否应税劳务 | 模板隐藏 |
| `@bsettleall` | 否 | 结算标志 | 模板隐藏 |
| `@bsignover` | 否 | 发货签回完成 | 模板可见 |
| `@btrack` | 否 | 是否追踪 | 模板隐藏 |
| `@btracksalebill` | 否 | PE跟单 | 模板隐藏 |
| `@cbaccounter` | 否 | 记账人 | 模板隐藏 |
| `@cbatch` | 否 | 批号 | 模板可见 |
| `@cbatchproperty1` | 否 | 属性1 | 模板隐藏 |
| `@cbatchproperty10` | 否 | 属性10 | 模板隐藏 |
| `@cbatchproperty2` | 否 | 属性2 | 模板隐藏 |
| `@cbatchproperty3` | 否 | 属性3 | 模板隐藏 |
| `@cbatchproperty4` | 否 | 属性4 | 模板隐藏 |
| `@cbatchproperty5` | 否 | 属性5 | 模板隐藏 |
| `@cbatchproperty6` | 否 | 属性6 | 模板隐藏 |
| `@cbatchproperty7` | 否 | 属性7 | 模板隐藏 |
| `@cbatchproperty8` | 否 | 属性8 | 模板隐藏 |
| `@cbatchproperty9` | 否 | 属性9 | 模板隐藏 |
| `@cbsysbarcode` | 否 | 单据行条码 | 模板隐藏 |
| `@cchildcode` | 否 | 子节点编码 | 模板隐藏 |
| `@ccode` | 否 | 入库单号 | 模板隐藏 |
| `@cconfirmer` | 否 | 应收记账人 | 模板隐藏 |
| `@ccontractid` | 否 | 合同编码 | 模板隐藏 |
| `@ccontractrowguid` | 否 | 合同标的RowGuid | 模板隐藏 |
| `@ccontracttagcode` | 否 | 合同标的编码 | 模板隐藏 |
| `@ccusinvcode` | 否 | 客户存货编码 | 模板隐藏 |
| `@ccusinvname` | 否 | 客户存货名称 | 模板隐藏 |
| `@cdefine22` | 否 | 自定义项1 | 模板隐藏 |
| `@cdefine23` | 否 | 自定义项2 | 模板隐藏 |
| `@cdefine24` | 否 | 自定义项3 | 模板隐藏 |
| `@cdefine25` | 否 | 自定义项4 | 模板隐藏 |
| `@cdefine26` | 否 | 自定义项5 | 模板隐藏 |
| `@cdefine27` | 否 | 自定义项6 | 模板隐藏 |
| `@cdefine28` | 否 | 自定义项7 | 模板隐藏 |
| `@cdefine29` | 否 | 自定义项8 | 模板隐藏 |
| `@cdefine30` | 否 | 自定义项9 | 模板隐藏 |
| `@cdefine31` | 否 | 自定义项10 | 模板隐藏 |
| `@cdefine32` | 否 | 自定义项11 | 模板隐藏 |
| `@cdefine33` | 否 | 自定义项12 | 模板隐藏 |
| `@cdefine34` | 否 | 自定义项13 | 模板隐藏 |
| `@cdefine35` | 否 | 自定义项14 | 模板隐藏 |
| `@cdefine36` | 否 | 自定义项15 | 模板隐藏 |
| `@cdefine37` | 否 | 自定义项16 | 模板隐藏 |
| `@cdemandcode` | 否 | 需求跟踪号 | 模板隐藏 |
| `@cdemandid` | 否 | 需求跟踪id | 模板隐藏 |
| `@cdemandmemo` | 否 | 需求分类说明 | 模板隐藏 |
| `@cexpirationdate` | 否 | 有效期至 | 模板隐藏 |
| `@cfactorycode` | 否 | 工厂编码 | 模板可见 |
| `@cfactoryname` | 否 | 工厂名称 | 模板可见 |
| `@cfree1` | 否 | 自由项1 | 模板隐藏 |
| `@cfree10` | 否 | 内存 | 模板可见 |
| `@cfree2` | 否 | 自由项2 | 模板隐藏 |
| `@cfree3` | 否 | 自由项3 | 模板隐藏 |
| `@cfree4` | 否 | 自由项4 | 模板隐藏 |
| `@cfree5` | 否 | 自由项5 | 模板隐藏 |
| `@cfree6` | 否 | 自由项6 | 模板隐藏 |
| `@cfree7` | 否 | 自由项7 | 模板隐藏 |
| `@cfree8` | 否 | 自由项8 | 模板隐藏 |
| `@cfree9` | 否 | 颜色 | 模板可见 |
| `@cgroupcode` | 否 | 计量单位组 | 模板隐藏 |
| `@cinva_unit` | 否 | 销售单位 | 模板隐藏 |
| `@cinvaddcode` | 否 | 存货代码 | 模板隐藏 |
| `@cinvcode` | 是 | 存货编码 | 模板可见 |
| `@cinvdefine1` | 否 | 分光 | 模板隐藏 |
| `@cinvdefine10` | 否 | 自定义项10 | 模板隐藏 |
| `@cinvdefine11` | 否 | 自定义项11 | 模板隐藏 |
| `@cinvdefine12` | 否 | 自定义项12 | 模板隐藏 |
| `@cinvdefine13` | 否 | 自定义项13 | 模板隐藏 |
| `@cinvdefine14` | 否 | 自定义项14 | 模板隐藏 |
| `@cinvdefine15` | 否 | 自定义项15 | 模板隐藏 |
| `@cinvdefine16` | 否 | 自定义项16 | 模板隐藏 |
| `@cinvdefine2` | 否 | 自定义项2 | 模板隐藏 |
| `@cinvdefine3` | 否 | 自定义项3 | 模板隐藏 |
| `@cinvdefine4` | 否 | 自定义项4 | 模板隐藏 |
| `@cinvdefine5` | 否 | 自定义项5 | 模板隐藏 |
| `@cinvdefine6` | 否 | 自定义项6 | 模板隐藏 |
| `@cinvdefine7` | 否 | 自定义项7 | 模板隐藏 |
| `@cinvdefine8` | 否 | 自定义项8 | 模板隐藏 |
| `@cinvdefine9` | 否 | 自定义项9 | 模板隐藏 |
| `@cinvm_unit` | 否 | 主计量 | 模板可见 |
| `@cinvname` | 是 | 存货名称 | 模板可见 |
| `@cinvouchtype` | 否 |  | 模板隐藏 |
| `@cinvstd` | 否 | 规格型号 | 模板可见 |
| `@citem_class` | 否 | 项目大类编码 | 模板隐藏 |
| `@citem_cname` | 否 | 项目大类名称 | 模板隐藏 |
| `@citemcode` | 否 | 项目编码 | 模板隐藏 |
| `@citemname` | 否 | 项目名称 | 模板隐藏 |
| `@cmassunit` | 否 | 保质期单位 | 模板隐藏 |
| `@cmemo` | 否 | 备注 | 模板隐藏 |
| `@cordercode` | 否 | 订单号 | 模板隐藏 |
| `@corufts` | 否 | 对应单据时间戳 | 模板隐藏 |
| `@cparentcode` | 否 | 父节点编码 | 模板隐藏 |
| `@cposition` | 否 | 货位编码 | 模板隐藏 |
| `@cposname` | 否 | 货位 | 模板隐藏 |
| `@creasoncode` | 否 | 退货原因编码 | 模板隐藏 |
| `@creasonname` | 否 | 退货原因 | 模板隐藏 |
| `@crelacuscode` | 否 | 责任客户编码 | 模板隐藏 |
| `@crelacusname` | 否 | 责任客户名称 | 模板隐藏 |
| `@crtnappcode` | 否 | 退货申请单号 | 模板隐藏 |
| `@cscloser` | 否 | 行关闭人 | 模板隐藏 |
| `@csettleall` | 否 | 关闭标志 | 模板隐藏 |
| `@csocode` | 否 | 订单号 | 模板隐藏 |
| `@csrpolicy` | 否 | 供需政策 | 模板隐藏 |
| `@cunitid` | 否 | 销售单位编码 | 模板隐藏 |
| `@cvenabbname` | 否 | 产地 | 模板隐藏 |
| `@cvencode` | 否 | 入库单供应商编码 | 模板隐藏 |
| `@cvmivencode` | 否 | 供货商编码 | 模板隐藏 |
| `@cvmivenname` | 否 | 供货商名称 | 模板隐藏 |
| `@cwhcode` | 是 | 仓库编码 | 模板可见 |
| `@cwhname` | 否 | 仓库名称 | 模板可见 |
| `@dconfirmdate` | 否 | 业务应收确认日期 | 模板隐藏 |
| `@dexpirationdate` | 否 | 有效期计算项 | 模板隐藏 |
| `@dkeepdate` | 否 | 记账日期 | 模板隐藏 |
| `@dkl1` | 否 | 倒扣1（%） | 模板隐藏 |
| `@dkl2` | 否 | 倒扣2（%） | 模板隐藏 |
| `@dlid` | 否 | 发货单 38 | 模板隐藏 |
| `@dmdate` | 否 | 生产日期 | 模板隐藏 |
| `@dsclosedate` | 否 | 关闭日期 | 模板隐藏 |
| `@dsclosesystime` | 否 | 关闭时间 | 模板隐藏 |
| `@dvdate` | 否 | 失效日期 | 模板隐藏 |
| `@fappretwkpqty` | 否 | 未开票退货申请数量 | 模板隐藏 |
| `@fappretwkpsum` | 否 | 未开票退货申请金额 | 模板隐藏 |
| `@fappretykpqty` | 否 | 已开票退货申请数量 | 模板隐藏 |
| `@fappretykpsum` | 否 | 已开票退货申请金额 | 模板隐藏 |
| `@fcanusequan` | 否 | 可用量 | 模板隐藏 |
| `@fcanusequano` | 否 | 可用件数 | 模板隐藏 |
| `@fchildqty` | 否 | 使用数量 | 模板隐藏 |
| `@fchildrate` | 否 | 权重比例 | 模板隐藏 |
| `@fcusminprice` | 否 | 最低售价 | 模板可见 |
| `@flossrate` | 否 | 发货合理损耗率（%） | 模板隐藏 |
| `@foutnum` | 否 | 累计出库件数 | 模板隐藏 |
| `@foutquantity` | 否 | 累计出库数量 | 模板隐藏 |
| `@frlossqty` | 否 | 合理损耗数量 | 模板隐藏 |
| `@fsalecost` | 否 | 零售单价 | 模板隐藏 |
| `@fsaleprice` | 否 | 零售金额 | 模板隐藏 |
| `@fstockquan` | 否 | 现存量 | 模板隐藏 |
| `@fstockquano` | 否 | 现存件数 | 模板隐藏 |
| `@fsumpaymoney` | 否 | 费用分摊金额 | 模板隐藏 |
| `@fsumsignnum` | 否 | 累计签回件数 | 模板隐藏 |
| `@fsumsignquantity` | 否 | 累计签回数量 | 模板隐藏 |
| `@fulossqty` | 否 | 非合理损耗数量 | 模板隐藏 |
| `@funsignnum` | 否 | 可签收件数 | 模板隐藏 |
| `@funsignquantity` | 否 | 可签收数量 | 模板隐藏 |
| `@fxjnum` | 否 | 已拣货件数 | 模板隐藏 |
| `@fxjquantity` | 否 | 已拣货量 | 模板隐藏 |
| `@ibatch` | 否 | 批次 | 模板隐藏 |
| `@icalcstartingpoint` | 否 | 计算起点 | 模板隐藏 |
| `@icalctype` | 否 | 发货模式 | 模板隐藏 |
| `@icorid` | 否 | 原发货单ID | 模板隐藏 |
| `@idemandseq` | 否 | 需求跟踪行号 | 模板隐藏 |
| `@idemandtype` | 否 | 需求跟踪方式 | 模板隐藏 |
| `@idiscount` | 否 | 折扣额 | 模板可见 |
| `@idlsid` | 否 | 子表id | 模板隐藏 |
| `@iexchsum` | 否 | 累计原币收款金额 | 模板隐藏 |
| `@iexpiratdatecalcu` | 否 | 有效期推算方式 | 模板隐藏 |
| `@igrouptype` | 否 | 单位类型 | 模板隐藏 |
| `@iinvexchrate` | 否 | 换算率 | 模板隐藏 |
| `@iinvlscost` | 否 | 档案最低售价 | 模板隐藏 |
| `@iinvsncount` | 否 | 序列号个数 | 模板隐藏 |
| `@iinvweight` | 否 | 单位重量 | 模板隐藏 |
| `@imassdate` | 否 | 保质期 | 模板隐藏 |
| `@imoney` | 否 | 无税金额 | 模板可见 |
| `@imoneysum` | 否 | 累计本币收款金额 | 模板隐藏 |
| `@inatdiscount` | 否 | 本币折扣额 | 模板隐藏 |
| `@inatmoney` | 否 | 本币金额 | 模板隐藏 |
| `@inatsum` | 否 | 本币价税合计 | 模板隐藏 |
| `@inattax` | 否 | 本币税额 | 模板隐藏 |
| `@inatunitprice` | 否 | 本币单价 | 模板隐藏 |
| `@inufts` | 否 | 入库单时间戳 | 模板隐藏 |
| `@inum` | 否 | 件数 | 模板隐藏 |
| `@iorderrowno` | 否 | 订单行号 | 模板隐藏 |
| `@ippartid` | 否 | 母件物料ID | 模板隐藏 |
| `@ippartqty` | 否 | 母件数量 | 模板隐藏 |
| `@ippartseqid` | 否 | 选配序号 | 模板隐藏 |
| `@iqanum` | 否 | 检验合格件数 | 模板隐藏 |
| `@iqaquantity` | 否 | 检验合格数量 | 模板隐藏 |
| `@iquantity` | 是 | 数量 | 模板可见 |
| `@iquotedprice` | 否 | 报价 | 模板可见 |
| `@iretquantity` | 否 | 退货数量 | 模板隐藏 |
| `@irowno` | 否 | 行号 | 模板隐藏 |
| `@irtnappid` | 否 | 退货申请单id | 模板隐藏 |
| `@isaconmode` | 否 | 仓库销售可用量控制方式 | 模板隐藏 |
| `@isettlenum` | 否 | 开票金额 | 模板隐藏 |
| `@isettlequantity` | 否 | 开票数量 | 模板隐藏 |
| `@isettletype` | 否 | 责任承担处理 | 模板隐藏 |
| `@isosid` | 否 | 对应订单子表ID | 模板隐藏 |
| `@isum` | 否 | 价税合计 | 模板可见 |
| `@itax` | 否 | 税额 | 模板可见 |
| `@itaxrate` | 否 | 税率（%） | 模板可见 |
| `@itaxunitprice` | 否 | 含税单价 | 模板可见 |
| `@itb` | 否 | 退补标志 | 模板隐藏 |
| `@iunitprice` | 否 | 无税单价 | 模板可见 |
| `@kl` | 否 | 扣率（%） | 模板可见 |
| `@kl2` | 否 | 扣率2（%） | 模板可见 |
| `@snlist` | 否 | 序列号 | 模板隐藏 |
| `@taskguid` | 否 | 退货申请单id | 模板隐藏 |

返回的结果如下（由 Query 示例派生，与下方查询示例自洽）
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "01",
    "@simulateinput": "cinvcode,cinvname,iquantity,iunitprice",
    "@refcardnumber": "defval",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "01处理成功!新增成功！",
    "@retid": "1000000000",
    "@retcode": "0000000000",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "01",
      "@ccardname": "发货单",
      "head": {
        "z:row": {
          "@ccuscode": "000",
          "@cdepcode": "01",
          "@cstcode": "01",
          "@ddate": "2015-01-13",
          "@csysbarcode": "||SA01|0000000104",
          "@cmaker": "demo10"
        }
      },
      "body": {
        "z:row": {
          "@cinvcode": "a1",
          "@cinvname": "a1",
          "@iquantity": "5.0000000000",
          "@cwhcode": "03",
          "@cinvm_unit": "公斤",
          "@autoid": "236"
        }
      }
    }
  }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。

---
