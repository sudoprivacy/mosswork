# 新建采购入库单接口参考

实现方式为 调用  U8智能体服务 MCP
参数格式如下

## 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "24",
        "@simulateinput": "cinvcode,iquantity,ioricost,iorimoney",
        "@refcardnumber": "defval",
        "@efdebug": "1",
        "@proc": "Add",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@cvencode": "供货单位编码或名称(必填)",
                    "@cvenabbname": "供货单位简称",
                    "@cwhcode": "仓库编码或名称(必填)",
                    "@crdcode": "入库类别编码",
                    "@cbustype": "业务类型(如 普通采购)",
                    "@cptcode": "采购类型编码或名称",
                    "@cdepcode": "部门编码或名称",
                    "@cpersoncode": "业务员编码",
                    "@ddate": "入库日期"
                }
            },
            "body": {
                "z:row": [{
                    "@cinvcode": "存货编码或名称(必填)",
                    "@cinvstd": "规格型号",
                    "@iquantity": "数量(必填)",                    
                    "@ioricost": "原币单价",
                    "@ioritaxcost": "原币含税单价",
                    "@iorimoney": "原币金额",
                    "@itaxrate": "税率",
                    "@cbatch": "批号"
                }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 否 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | **单据类型编号：采购入库单 = `24`（销售订单为 `17`）** |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvname,iquantity,ioritaxcost |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |

**head 单据头字段说明**
| @ 参数 | 必填 | 中文含义 | 说明 |
|------|------|------|------|
| `@cvencode` | 是 | 供货单位编码 | 供应商编码 |
| `@cvenabbname` | 是 | 供货单位 | 供应商简称 |
| `@cvenfullname` | 否 | 供应商全称 | |
| `@cwhcode` | 是 | 仓库编码 | |
| `@cwhname` | 否 | 仓库 | |
| `@crdcode` | 是 | 入库类别编码 | |
| `@crdname` | 否 | 入库类别 | |
| `@cbustype` | 否 | 业务类型 | 如 普通采购 |
| `@cptcode` | 否 | 采购类型编码 | |
| `@cptname` | 否 | 采购类型 | |
| `@cdepcode` | 否 | 部门编码 | |
| `@cdepname` | 否 | 部门 | |
| `@cpersoncode` | 否 | 业务员编码 | |
| `@cpersonname` | 否 | 业务员 | |
| `@ddate` | 否 | 入库日期 | |
| `@cmaker` | 否 | 制单人 | |
| `@chandler` | 否 | 审核人 | |
| `@itaxrate` | 否 | 税率 | |
| `@cexch_name` | 否 | 币种 | |
| `@iexchrate` | 否 | 汇率 | |
| `@cmemo` | 否 | 备注 | |
| `@cdefine1`~`@cdefine16` | 否 | 单据头自定义项 | 注意前缀为 `cdefine`，非 `define` |

**body 单据体字段说明（已依返回示例确认）**
|  @ 参数 | 必填 | 中文含义 | 说明 |
|------|------|------|------|
| `@cinvcode` | 是 | 存货编码 | |
| `@cinvname` | 是 | 存货名称 | |
| `@cinvstd` | 否 | 规格型号 | |
| `@cinvm_unit` | 否 | 主计量单位 | |
| `@iquantity` | 是 | 数量 | |
| `@iunitcost` | 否 | 本币单价 | |
| `@iprice` | 否 | 本币金额 | |
| `@ioritaxcost` | 否 | 原币含税单价 | |
| `@ioricost` | 否 | 原币单价 | |
| `@iorimoney` | 否 | 原币金额 | |
| `@ioritaxprice` | 否 | 原币税额 | |
| `@itaxrate` | 否 | 税率 | |
| `@itaxprice` | 否 | 本币税额 | |
| `@isum` | 否 | 本币价税合计 | |
| `@iorisum` | 否 | 原币价税合计 | |
| `@cbatch` | 否 | 批号 | |
| `@cfree1`~`@cfree10` | 否 | 自由项 | |
| `@cposition` | 否 | 货位编码 | |
| `@cdefine22`~`@cdefine37` | 否 | 单据体自定义项 | 前缀 `cdefine` |

返回的结果如下
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "17",
    "@simulateinput": "cinvname,iquantity,iquotedprice",
    "@refcardnumber": "defval",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "24处理成功!新增成功！",
    "@retid": "1000000416",
    "@retcode": "0000000398",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "24",
      "@ccardname": "采购入库单",
      "head": {
        "z:row": {
          "@cvencode": "01002",
          "@ccode": "0000000336",
          "@csysbarcode": "||st01|0000000336",
          "@ivouchstate": "Opening",
          "@cvenfullname": "深圳辰环手机配件有限公司",
          "@ccusabbname": "辰环手机配件",
          "@cbustype": "普通采购",
          "@crdcode": "11",
          "@crdname": "采购入库",
          "@cdepcode": "0401",
          "@cdepname": "采购部",
          "@cwhcode": "50",
          "@cwhname": "电商总仓",
          "@cmaker": "demo10",
          "@ccrmpersonname": "",
          "@cexch_name": "人民币",
          "@iexchrate": "1",
          "@ddate": "2026-06-01",
          "@dpredatebt": "2026-08-15",
          "@iverifystate": "0",
          "@id": "1000000336"
        }
      },
      "body": {
        "z:row": {
          "@cinvname": "硬盘-1000G",
          "@cinvcode": "01019002065",
          "@cinvstd": "希捷 1000G/7200RPM/32M/SATA2/企业级",
          "@iquantity": "18.00",
          "@iquotedprice": "10",
          "@dpredate": "2026-08-15",
          "@cunitid": "0108",
          "@cinvm_unit": "PCS",
          "@autoid": "1598"
        }
      }
    }
  }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。

---
