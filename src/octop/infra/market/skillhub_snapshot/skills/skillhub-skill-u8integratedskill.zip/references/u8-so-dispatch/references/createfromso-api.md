---
name: createfromso-api
description: 参照销售订单生成销售发货单（Dispatch from Sales Order）。当用户要"根据销售订单生成/参照销售订单开发货单"时使用此技能。仅覆盖参照生单核心：前置查询销售订单(eftype=17)获取参照来源、新建销售发货单(eftype=01)时用@refcardnumber=17+表体@ef_autoid(=销售订单@isosid)建立参照关系。查询/展示/审核等环节见已拆分的标准「销售发货单」技能。
metadata: {"yonbip":{"version":"1.0.0"}}
---

# 参照销售订单生成销售发货单（参照生单专用）

## 第0步：查询销售订单（获取参照来源）
实现方式为 调用 U8智能体服务 MCP
参数格式如下
### 请求报文模板
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "17",
        "@proc": "Query",
        "@efdebug": "1",
        "@efid": "销售订单ID"
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号：销售订单 = `17` |
| `@proc` | 是 | 操作类型，默认：Query |
| `@efid` | 否 | 销售订单ID；不填则拉列表定位目标单据 |

**返回结果取数要点**
- 表头 `@csocode` → 销售订单号，回填销售发货单表头 `@csocode`
- 表头 `@id` → 销售订单头ID（=SO_SOMain.ID）
- **表体每行 `@isosid`** → 子表id（=SO_SODetails.iSOsID，含义"订单子表ID"，**注意非 `@autoid`**），回填销售发货单表体 `@ef_autoid` 与 `@isosid`
- 表体 `@cinvcode`(存货)、`@iquantity`(订单数量) 等作为发货单行建议值

## 新建销售发货单（参照销售订单）
实现方式为 调用 U8智能体服务 MCP
参数格式如下
### 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "01",
        "@simulateinput": "cinvname,iquantity",
        "@refcardnumber": "17",
        "@efdebug": "1",
        "@proc": "Add",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@ccuscode": "02001",
                    "@ccusabbname": "北京华信客户有限公司",
                    "@cstcode": "01",
                    "@cbustype": "普通销售",
                    "@cdepcode": "03",
                    "@cpersoncode": "0001",
                    "@csocode": "SO000001"
                }
            },
            "body": {
                "z:row": [{
                    "@cwhcode": "01",
                    "@cinvcode": "01019002065",
                    "@cinvname": "硬盘-1000G",
                    "@iquantity": "18.00",
                    "@isosid": "1000001234",
                    "@ef_autoid": "1000001234"
                }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号：销售发货单 = `01` |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvname,iquantity |
| `@refcardnumber` | 是 | 单据来源类型编号：无来源填 `defval`；参照销售订单填来源单据 `@eftype` = `17` |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |

**head单据头对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@ccuscode` | 是 | 客户编码（可取自销售订单表头） |
| `@ccusabbname` | 是 | 客户简称 |
| `@cstcode` | 是 | 销售类型编码，如 `01` |
| `@cbustype` | 否 | 业务类型，如 普通销售 |
| `@cdepcode` | 否 | 部门编码 |
| `@cpersoncode` | 否 | 业务员编码 |
| `@csocode` | 否* | 来源单号（参照来源） = 销售订单 `@csocode` |

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@isosid` | 是* | 对应订单子表ID（参照来源） = 销售订单查询 `@isosid`（SO_SODetails.iSOsID）；发货单原生承接销售订单子表id的字段 |
| `@ef_autoid` | 是* | 来源单据子表ID（EAI 参照追踪） = 销售订单查询 `@isosid`；建立参照关系、防重复生单（与 `@isosid` 同值） |
| `@cwhcode` | 是 | 仓库编码 |
| `@cinvcode` | 是 | 存货编码 |
| `@cinvname` | 否 | 存货名称（可模拟输入） |
| `@iquantity` | 是 | 本次发货数量，≤ 销售订单对应行未发货量 |

> `*` 必有订单模式或明确要求参照销售订单生成时，`@isosid`/`@ef_autoid` 承载来源关联，必须填写。

返回的结果如下
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "01",
    "@simulateinput": "cinvname,iquantity",
    "@refcardnumber": "17",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "01处理成功!新增成功！",
    "@retid": "1000000418",
    "@retcode": "0000000400",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "01",
      "@ccardname": "销售发货单",
      "head": {
        "z:row": {
          "@ccuscode": "02001",
          "@csocode": "SO000001",
          "@cdlcode": "0000000338",
          "@cstcode": "01",
          "@cbustype": "普通销售",
          "@cmaker": "demo10",
          "@ddate": "2026-06-01",
          "@id": "1000000338"
        }
      },
      "body": {
        "z:row": {
          "@cinvcode": "01019002065",
          "@cinvname": "硬盘-1000G",
          "@iquantity": "18.00",
          "@isosid": "1000001234",
          "@ef_autoid": "1000001234",
          "@idlsid": "1000002001",
          "@autoid": "1599"
        }
      }
    }
  }
}
```
其中 `@retid` 是新建成功的销售发货单ID（`@autoid`/`@idlsid` 为发货单自身行ID，与 `@ef_autoid` 不同）。

⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。
