# 创建销售订单接口参考

## 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "17",
        "@simulateinput": "cinvname,iquantity,iquotedprice",
        "@refcardnumber": "defval",
        "@efdebug": "1",
        "@proc": "Add",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@ccuscode": "00000002"
                    }
            },
            "body": {
                "z:row": [{
                    "@cinvname": "硬盘-1000G",
                    "@iquantity": "1.00",
                    "@iquotedprice":"1"
                    }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下
- 如果录入的客户是名称或者简称则先通过列表查询技能查询对应列表，从返回结果获取编码赋值给相应编码字段

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号，默认 17   |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvname,iquantity,iquotedprice |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |

**head单据头信息说明**
- `row` — 单据头对象

**head单据头row节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@ccuscode` | 是 | 客户编码 |


**body单据体信息说明**
- `row` — 单据体对象数组

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cinvname` | 是 | 存货编码或者名称 |
| `@iQuantity` | 是 | 数量 |
| `@iquotedprice` | 是 | 单价 |


### 返回的结果如下
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "17",
    "@simulateinput": "cinvname,iquantity,iquotedprice",
    "@refcardnumber": "defval",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "17处理成功!新增成功！",
    "@retid": "1000000416",
    "@retcode": "0000000398",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "17",
      "@ccardname": "销售订单",
      "head": {
        "z:row": {
          "@ccuscode": "00000001",
          "@csocode": "0000000337",
          "@csysbarcode": "||SA17|0000000337",
          "@ivouchstate": "Opening",
          "@ccusname": "世纪天华集团公司",
          "@ccusabbname": "世纪天华",
          "@cbustype": "普通销售",
          "@cstcode": "01",
          "@cstname": "普通销售",
          "@cdepcode": "0301",
          "@cdepname": "市场部",
          "@cmaker": "demo",
          "@ccrmpersonname": "王铭",
          "@cexch_name": "人民币",
          "@iexchrate": "1",
          "@ddate": "2026-06-01",
          "@dpredatebt": "2026-08-15",
          "@iverifystate": "0",
          "@id": "1000000354"
        }
      },
      "body": {
        "z:row": {
          "@cinvname": "硬盘-1000G",
          "@cinvcode": "01019002065",
          "@cinvstd": "希捷 1000G/7200RPM/32M/SATA2/企业级",
          "@iquantity": "18.00",
          "@iquotedprice": "99",
          "@dpredate": "2026-08-15",
          "@cunitid": "0108",
          "@cinvm_unit": "PCS",
          "@autoid": "1598"
        }
      }
    }
  }
}
```
其中@retid 是单据ID

⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。
