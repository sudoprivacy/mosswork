# 审批同意（Audit）接口参考

## 请求报文模板
参数格式如下
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "AuditSrv",
        "@token": "",
        "@proc": "Audit",
        "@succeed": "1",
        "@dsc": "AuditSrv处理成功!",
        "inf": {
            "@taskid": "",
            "@cvouchertype": "",
            "@action": "1",
            "@opinion": "审批意见描述",
            "@succeed": "0"
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "AuditSrv处理成功!"
        }
    }
}
```
**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid`| 是 |账套标识，从当前会话中获取 |
| `@eftype` | 是 | 固定值 AuditSrv |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@proc` | 是 | Audit |
| `@taskid` | 是 | 审批任务任务ID |
| `@opinion` | 否 | 审批意见描述 |
| `@action` | 否 | 固定值 1 |
| `@cvouchertype` | 否 | 单据类型 |
## 返回的完整结果示例如下：
```json
{
    "ufinterface": {
        "@efserverid": "",
        "@eftype": "AuditSrv",
        "@userid": "",
        "@pass": "",
        "@proc": "Audit",
        "@succeed": "1",
        "@dsc": "AuditSrv处理成功!",
        "inf": {
            "@taskid": "D4120FB5-D883-4D97-9506-9544FC4DD6B8",
            "@cvouchertype": "27",
            "@action": "1",
            "@opinion": "审批意见描述",
            "@succeed": "1",
            "@dsc": "审批成功",
            "@errmsg": ""
        },
        "runafter": {
            "@succeed": "1",
            "@dsc": "AuditSrv处理成功!"
        }
    }
}
```