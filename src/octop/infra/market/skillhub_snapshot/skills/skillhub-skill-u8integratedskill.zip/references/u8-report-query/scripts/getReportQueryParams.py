import json
import argparse
import sys
import os


# 将脚本所在目录加入 sys.path，确保能找到同目录下的 u8_requests.py
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def handle_request(efuid, serverid, solutionId, u8token, paramsPath, pageParams) -> str:
    """
    :param serverid: 账套标识 (int/str)
    :param request: 请求内容 (任意类型，会转为字符串处理)
    :return: 处理后的字符串
    """

    # 检查文件是否存在
    if not os.path.exists(paramsPath):
        raise FileNotFoundError(f"文件不存在：{paramsPath}")

    # 打开并读取文件（指定 utf-8 编码，避免中文乱码）
    with open(paramsPath, 'r', encoding='utf-8') as f:
        json_str = f.read()

    # 打开并读取文件（指定 utf-8 编码，避免中文乱码）
    if pageParams:
        with open(pageParams, 'r', encoding='utf-8') as f:
            page_json_str = f.read()

        add_list = json.loads(page_json_str)
    else:
        add_list =[]
    request={
		"actionname":"getReport",
		"params":[
			{"@id":"solutionId","value":solutionId},
			{"@id":"startline","value":1},
			{"@id":"count","value":25},
			{"@id":"queryParams","value":json_str}]
		}
    
    request["params"].extend(add_list)
    
    res = {
        "ufinterface": {
        "@efuid": efuid,
        "@efserverid": serverid,
        "@eftype": "U8Rep",
        "@proc": "query",
        "@token": u8token,
        "@request": json.dumps(request, ensure_ascii=False),  # ← @request 也是字符串
        "@efdebug": "1",
        "@version": "18.000",
        "@refcardnumber": "?"
        }
    }
    return json.dumps(res, ensure_ascii=False)

# 调用示例
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="调用handle_request测试")
    parser.add_argument("--efuid", default="", help="U8服务识别码")
    parser.add_argument("--serverid", default="", help="账套标识")
    parser.add_argument("--soulutionId", default="", help="方案ID")
    parser.add_argument("--u8token", default="", help="登录Token")
    parser.add_argument("--queryParams", default="", help="查询参数")
    parser.add_argument("--queryPageParams", default="", help="查询分页参数")
    args = parser.parse_args()
    res = handle_request(efuid=args.efuid, serverid=args.serverid, solutionId=args.soulutionId,u8token=args.u8token,paramsPath=args.queryParams,pageParams=args.queryPageParams)
    print(res)