# 创建采购到货单接口参考

实现方式为 调用  U8智能体服务 MCP 
参数格式如下
## 请求报文模板
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "26",
        "@simulateinput": "cinvcode,iquantity,iorimoney",
        "@refcardnumber": "defval",
        "@efdebug": "1",
        "@proc": "Add",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "z:row": {
                    "@cvencode": "01",
                    "@cdepcode": "01"
                    }
            },
            "body": {
                "z:row": [{
                    "@cinvcode": "01001",
                    "@iquantity": "1.00",
                    "@iorimoney": "100.00"
                    }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号，默认 26   |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cinvcode,iquantity,iorimoney |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |
| `body` | 是 | 单据体信息 |

**head单据头信息说明**
- `row` — 单据头对象

**head单据头row节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cvencode` | 是 | 供应商编码 |
| `@cbustype` | 是 | 默认值普通采购 |
| `@cdepcode` | 是 | 部门编码 |

**body单据体信息说明**
- `row` — 单据体对象数组

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cinvcode` | 是 | 存货编码 |
| `@iquantity` | 是 | 数量 |
| `@iorimoney` | 是 | 金额或原币金额 |


返回的结果如下
```json
{
  "ufinterface": {
    "@efserverid": "",
    "@eftype": "26",
    "@simulateinput": "cinvcode,iquantity,iorimoney",
    "@refcardnumber": "defval",
    "@proc": "Add",
    "@efdebug": "0",
    "@succeed": "1",
    "@dsc": "26处理成功!新增成功！",
    "@retid": "1000000416",
    "@retcode": "0000000398",
    "voucher": {
      "@xmlns:z": "EF",
      "@cardnumber": "26",
      "@ccardname": "到货单",
      "head": {
        "z:row": {
            "@ivtid": "8169",
            "@ufts": "                      500.3551",
            "@ddate": "2026-07-31T00:00:00",
            "@id": "1000000001",
            "@ccode": "0000000001",
            "@cptcode": "01",
            "@cptname": "采购类型01",
            "@cvencode": "01001",
            "@cvenabbname": "供应商01001",
            "@cvenname": "供应商01001",
            "@cdepcode": "1",
            "@cdepname": "部门1",
            "@cpocode": "0000000001",
            "@cexch_name": "人民币",
            "@cexch_code": "RMB",
            "@iexchrate": "1",
            "@cbustype": "普通采购",
            "@cmaker": "demo",
            "@bnegative": "0",
            "@idiscounttaxtype": "0",
            "@itaxrate": "13.000000",
            "@ibilltype": "0",
            "@cmaketime": "2026-08-27T08:57:52.84",
            "@cauditdate": "2026-07-31T00:00:00",
            "@caudittime": "2026-08-27T08:57:54.52",
            "@cverifier": "demo",
            "@iverifystateex": "2",
            "@iswfcontrolled": "False",
            "@cvoucherstate": "审核",
            "@iflowid": "0",
            "@bstoragearrivalorder": "1",
            "@iprintcount": "0",
            "@csysbarcode": "||pudh|0000000001",
            "@editprop": ""
        }
      },
      "body": {
        "z:row": {
            "@id": "1000000001",
            "@autoid": "1000000001",
            "@cinvcode": "01001",
            "@cinvname": "存货01001",
            "@cinvccode": "01",
            "@cunitid": "01002",
            "@ccomunitcode": "01001",
            "@cinvm_unit": "固定01主",
            "@igrouptype": "1",
            "@cgroupcode": "01",
            "@cinva_unit": "固定01辅",
            "@bservice": "False",
            "@iinvexchrate": "10.0000000000000000",
            "@binvbatch": "False",
            "@ioritaxcost": "12.000000",
            "@iquantity": "12.000000",
            "@inum": "1.200000",
            "@ioricost": "10.619167",
            "@iorimoney": "127.43",
            "@ioritaxprice": "16.57",
            "@iorisum": "144",
            "@icost": "10.619167",
            "@imoney": "127.43",
            "@itaxprice": "16.57",
            "@isum": "144",
            "@cbcloser": "",
            "@itaxrate": "13.000000",
            "@iposid": "1000000001",
            "@fvalidquantity": "12.000000",
            "@fvalidnum": "1.200000",
            "@fvalidinquan": ".000000",
            "@fvalidinnum": ".0000000000000000",
            "@finvalidinquan": ".000000",
            "@fretquantity": ".000000",
            "@frealquantity": "12.000000",
            "@frealnum": "1.200000",
            "@rejectsource": "False",
            "@bgsp": "0",
            "@btaxcost": "True",
            "@binspect": "0",
            "@sotype": "0",
            "@iordertype": "0",
            "@cordercode": "0000000001",
            "@bexigency": "0",
            "@vouchstate": "0",
            "@fininquantity": "12.000000",
            "@fininnum": "1.20000000000000",
            "@inspecexchrate": "10.0000000000000000",
            "@iexpiratdatecalcu": "0",
            "@ivouchrowno": "1",
            "@cbsysbarcode": "||pudh|0000000001|1",
            "@iproducttype": "0",
            "@bgift": "0",
            "@editprop": ""
        }
      }
    }
  }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。
