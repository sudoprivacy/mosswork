# 提交采购订单接口参考

实现方式为 调用  U8智能体服务 MCP  
参数格式如下

## 请求报文模板
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "88",
        "@proc": "query",
        "@actions": "Submit",
        "@efdebug": "1",
        "@efid": "采购订单ID",
        "@efccode": "采购订单单据号"
    }
}
```


## 请求参数说明

| 字段 |  说明 |
|------|------|------|------|
| `@efuid` |  服务识别码，从当前会话中获取|
| `@efserverid` | 账套标识标识 |
| `@eftype` | **单据类型编号：采购订单 = `88`** |
| `@proc` | 操作类型，固定值:query |
| `@actions` | 操作类型，默认：Submit |
| `@efid` | 采购订单ID，默认传入创建采购订单时返回Json结果的@retid参数的值 |
| `@efccode` | 采购订单单据号，默认传入创建采购订单时返回Json结果的@retcode参数的值 |
| `@efdebug` | 展示字段描述信息，默认：0 |

## 返回结果的Json字段说明
- `actions` — 提交结果的信息对象

**actions**
| 参数名称 | 参数解释 |
| --- | --- |
| `@action_DoSubmit_succeed` |  提交是否成功，1：成功，0：提交失败 |
| `@action_DoSubmit_dsc` |  提交结果的描述信息 |
