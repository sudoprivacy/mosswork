# 提交付款申请单接口参考

实现方式为 调用  U8智能体服务 MCP  
参数格式如下

## 请求报文模板
参数格式如下
```json
{
    "ufinterface": {
        "@efuid": "",
        "@efserverid": "",
        "@eftype": "AP40",
        "@proc": "query",
        "@actions": "DoSubmit",
        "@efdebug": "1",
        "@efid": "XXXXXXXXXX",
        "@efccode": "XXXXXXXXXX"
    }
}
```

## 请求参数说明

| 字段 |  说明 |
|------|------|
| `@efuid` |  服务识别码，从当前会话中获取 |
| `@efserverid` | 账套标识，从当前会话中获取 |
| `@eftype` | 单据类型编号，固定值 AP40 |
| `@proc` | 操作类型，固定值:query |
| `@actions` | 操作类型，默认：DoSubmit |
| `@efid` | 付款申请单ID，传入创建付款申请单时返回Json结果的@retid参数的值 |
| `@efccode` | 付款申请单号，传入创建付款申请单时返回Json结果的@retcode参数的值 |
| `@efdebug` | 展示字段描述信息，默认：0 |

## 返回结果的Json字段说明
- `actions` — 提交结果的信息对象

**actions**
| 参数名称 | 参数解释 |
| --- | --- |
| `@action_DoSubmit_succeed` |  提交是否成功，1：成功，0：提交失败 |
| `@action_DoSubmit_dsc` |  提交结果的描述信息 |


