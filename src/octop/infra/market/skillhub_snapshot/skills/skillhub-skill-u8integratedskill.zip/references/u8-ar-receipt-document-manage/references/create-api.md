# 创建收款单接口参考

## 请求报文模板
参数格式如下
```json
{
    "ufinterface": 
    {
        "@efuid": "",
        "@efserverid": "",
        "@token": "",
        "@eftype": "AR48",
        "@simulateinput": "cDwCode",
        "@refcardnumber": "defval",
        "@efdebug": "1",
        "@proc": "Add",
        "@refccode": "",
        "voucher": {
            "@xmlns:z": "EF",
            "head": {
                "row": {
                    "@cDwCode": "",
                    "@dVouchDate": "",
                    "@iAmount_f": ""
                    }
            },
            "body": {
                "row": [{
                    "@iType": "",
                    "@iAmt_f": ""
                    }]
            }
        }
    }
}
```

### 请求参数说明
- `ufinterface` — 接口根节点，所有请求参数均包含在此节点下

**ufinterface节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@efuid` | 是 | 服务识别码，从当前会话中获取 |
| `@efserverid` | 是 | 账套标识，从当前会话中获取 |
| `@token` | 是 | 登录令牌，从当前会话中获取 |
| `@eftype` | 是 | 单据类型编号，收款单 的单据编号是 AR48   |
| `@proc` | 是 | 操作类型，默认：Add |
| `@simulateinput` | 是 | 模拟输入字段，默认：cDwCode |
| `@refcardnumber` | 是 | 开启模拟输入，默认：defval |
| `voucher` | 是 | 提交的单据信息 |

**voucher单据信息说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@xmlns:z` | 是 | 默认值EF |
| `head` | 是 | 单据头信息 |

**head单据头信息说明**
- `row` — 单据头对象

**head单据头row节点说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@cDwCode` | 是 | 必输参数，客户编码 或者名称（调用U8智能体服务 MCP提示“查到多条客户，请确认客户信息：”时，根据用户选择的客户编号作为此参数输入） |
| `@cSSCode` | 否 | 非必输参数，结算方式编码 或者名称（调用U8智能体服务 MCP提示“请确认结算方式信息：”时，根据用户选择的结算方式编号作为此参数输入） |
| `@dVouchDate` | 是 | 日期 未指定日期时取系统当天日期 |
| `@iAmount_f` | 否 | 非必输参数，金额 或 收款金额 |


**body单据体信息说明**
- `row` — 单据体对象数组

**body单据体对象说明**
| 字段 | 必填 | 说明 |
|------|------|------|
| `@iType` | 是 | 款项类型，默认：0 (款项类型为"应收款"时，iType=0 ; 为"预收款"时，iType=1; 为"其他费用"时，iType=2; 为"手续费"时，iType=3; 为"利息"时，iType=4) |
| `@iAmt_f` | 否 | 非必输参数，金额 或 付款金额 |
| `@cCoVouchID` | 否 | 非必输参数，付款申请单号 |

返回的结果如下
```json
{
    "ufinterface": {
        "@efserverid": "",
        "@eftype": "AR48",
        "@simulateinput": "cDwCode",
        "@refcardnumber": "defval",
        "@refccode": "",
        "@proc": "Add",
        "@efdebug": "0",
        "@succeed": "1",
        "@dsc": "AR48处理成功!新增成功！",
        "@retid": "XXXXXXXXXX",
        "@retcode": "XXXXXXXXXX",
        "voucher": {
            "@cardnumber": "AR48",
            "@ccardname": "应收收款单",
            "@xmlns:z": "EF",
            "head": {
                "row": {
                    "@cDwCode": "示例客户编码",
                    "@iAmount_f": "34000",
                    "@iID": "XXXXXXXXXX",
                    "@cVouchType": "48",
                    "@cVouchID": "XXXXXXXXXX",
                    "@dVouchDate": "2026-08-06T00:00:00",
                    "@cSSCode": "1",
                    "@cDeptCode": "示例部门编码",
                    "@cSSName": "现金",
                    "@iPeriod": "8",
                    "@cAuthID": "示例客户编码",
                    "@cPerson": "示例业务员编码",
                    "@cPersonName": "示例业务员名称",
                    "@cexch_name": "人民币",
                    "@iExchRate": "1",
                    "@iAmount": "111",
                    "@iRAmount_f": "111",
                    "@iRAmount": "111",
                    "@iAmount_s": "0",
                    "@cTypeName": "收款单",
                    "@cCusAbbName": "示例客户简称",
                    "@cCusName": "示例客户名称",
                    "@cDepName": "示例部门名称",
                    "@cFlag": "AR",
                    "@cOperator": "示例操作员名称",
                    "@iPayForOther": "False",
                    "@bFromBank": "False",
                    "@bToBank": "False",
                    "@bSure": "False",
                    "@bStartFlag": "False",
                    "@VT_ID": "8052",
                    "@Ufts": "                     1160.6552",
                    "@cDefine1": "",
                    "@cCreditCode": "",
                    "@dcreatesystime": "2026-08-06T14:13:18.74",
                    "@IsWfControlled": "False",
                    "@iPayType": "0",
                    "@cPayType": "货款",
                    "@csysbarcode": "||ar48|XXXXXXXXXX",
                    "@keyextend_t_iid_ap_closebill_extradefine_iid": "XXXXXXXXXX",
                    "@iAmount_B": "0"
                }
            },
            "body": {
                "row": {
                    "@iAmt_f": "34000",
                    "@cCusVen": "示例客户编码",
                    "@iID": "XXXXXXXXXX",
                    "@ID": "XXXXXXXXXX",
                    "@bPrePay": "False",
                    "@iType": "0",
                    "@cType": "应收款",
                    "@cCusAbbName": "示例客户简称",
                    "@iAmt": "111",
                    "@cDepName": "示例部门名称",
                    "@cPersonName": "示例业务员名称",
                    "@iRAmt_f": "111",
                    "@iRAmt": "111",
                    "@iAmt_s": "0",
                    "@iRAmt_s": "0",
                    "@cDepCode": "示例部门编码",
                    "@cPersonCode": "示例业务员编码",
                    "@editprop": ""
                }
            }
        }
    }
}
```
其中@retid 是单据ID


⚠️ **重要：调用时必须显示完整的命令参数**，让用户可以清楚看到传了什么。