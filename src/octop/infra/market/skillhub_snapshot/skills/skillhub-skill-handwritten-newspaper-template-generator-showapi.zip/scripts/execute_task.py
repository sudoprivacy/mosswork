#!/usr/bin/env python3
"""
手抄报线稿模板生成 - 执行任务接口（真实调用时使用）
调用方式: python scripts/execute_task.py --theme "国庆节" --grade "低年级" --ratio "4:3" --async

仅使用 Python 标准库，无需安装第三方依赖。
appKey 获取：通过手机验证获取，详见 skill.md 前置准备。
"""

import argparse
import json
import os
import getpass
import urllib.request
import urllib.error
import urllib.parse


def execute_task(
    theme: str,
    grade: str = "低年级",
    ratio: str = "4:3",
    mode: str = "async"
) -> dict:
    """
    执行手抄报线稿模板生成任务

    Args:
        theme: 手抄报主题（必填），如国庆节、中秋节、植树节、消防日等
        grade: 年级段（必填），可选 低年级/中年级/高年级，决定排版复杂度与留白比例，默认低年级
        ratio: 画面宽高比，可选 4:3、3:4、16:9、1:1，默认4:3
        mode: 调用模式 async 或 sync（本技能强制异步执行，默认 async）

    Returns:
        dict: 包含 showapi_res_body、showapi_res_code 等字段的响应
    """
    # 1. 获取凭证：优先环境变量，无则交互式输入
    # appKey 获取方式：通过手机验证获取，详见 skill.md 前置准备
    app_key = os.environ.get("SHOWAPI_APP_KEY")
    if not app_key:
        print("未检测到环境变量 SHOWAPI_APP_KEY，请输入 AppKey：")
        print("（获取方式：通过手机验证获取，详见 skill.md 前置准备）")
        app_key = getpass.getpass(prompt="AppKey: ")

    if not app_key.strip():
        raise ValueError("AppKey 不能为空，请重新运行并输入有效凭证。")

    # 2. 入参校验与数据清洗
    if not theme or not str(theme).strip():
        raise ValueError("theme（手抄报主题）为必填项，请传入明确主题，如国庆节、中秋节、植树节、消防日等。")
    theme = str(theme).strip()

    if grade not in ("低年级", "中年级", "高年级"):
        raise ValueError("grade（年级段）仅支持：低年级、中年级、高年级。")

    if ratio not in ("4:3", "3:4", "16:9", "1:1"):
        raise ValueError("ratio（画面宽高比）仅支持：4:3、3:4、16:9、1:1。")

    # 3. 构建请求
    url = "https://route.showapi.com/flow/execute/6a72d0f03c51f2ec21019ee1"
    headers = {
        "Content-Type": "application/json"
    }

    # 构建请求体
    payload = {
        "theme": theme,
        "grade": grade,
        "ratio": ratio
    }

    # 4. 构建查询参数（包含 appKey）
    query_params = urllib.parse.urlencode({"appKey": app_key, "mode": mode})
    full_url = f"{url}?{query_params}"

    # 5. 发起请求
    req = urllib.request.Request(
        full_url,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            if response.status >= 400:
                raise Exception(f"HTTP请求失败: {response.status}")

            data = json.loads(response.read().decode("utf-8"))

            # 6. 业务错误处理
            if data.get("showapi_res_code", -1) != 0:
                error_msg = data.get("showapi_res_error", "未知错误")
                raise Exception(f"API错误: {error_msg}")

            return data

    except urllib.error.HTTPError as e:
        raise Exception(f"HTTP请求失败: {e.code}, {e.reason}")
    except urllib.error.URLError as e:
        raise Exception(f"请求失败: {str(e.reason)}")
    except Exception as e:
        raise Exception(f"请求异常: {str(e)}")


def main():
    parser = argparse.ArgumentParser(description="手抄报线稿模板生成 - 执行任务")
    parser.add_argument("--theme", "-t", required=True, help="手抄报主题（必填），如国庆节、中秋节、植树节、消防日等")
    parser.add_argument("--grade", "-g", default="低年级", choices=["低年级", "中年级", "高年级"], help="年级段，决定排版复杂度与留白比例，默认低年级")
    parser.add_argument("--ratio", "-r", default="4:3", choices=["4:3", "3:4", "16:9", "1:1"], help="画面宽高比，默认4:3")
    parser.add_argument("--async", dest="mode", action="store_const", const="async", default="async", help="使用异步模式（本技能强制异步执行，默认即为异步）")

    args = parser.parse_args()

    result = execute_task(
        theme=args.theme,
        grade=args.grade,
        ratio=args.ratio,
        mode=args.mode
    )

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()