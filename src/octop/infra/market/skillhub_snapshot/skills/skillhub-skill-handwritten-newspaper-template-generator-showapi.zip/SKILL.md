---
name: skillhub-skill-handwritten-newspaper-template-generator-showapi
description: "根据主题、年级与画面比例一键生成符合A4打印标准的手抄报黑白线稿模板；自动解析合规约束（如国庆节禁用国旗国徽）与年级排版策略，生成高清线稿图并适配A4打印尺寸，孩子只需涂色和填字即可完成；适用于家长辅导作业、教师课堂素材、节日主题手抄报创作、打印涂色模板场景"
---

# 手抄报线稿模板生成

## 任务目标
- 根据用户输入的手抄报主题（国庆节、中秋节、植树节、消防日等）、年级段与画面比例，自动生成符合A4打印标准的手抄报黑白线稿模板
- 具备合规校验优化、意图解析与排版策略生成、黑白线稿生图提示词构建、线稿图像生成、A4打印尺寸适配能力
- 触发场景：家长为孩子准备手抄报作业、教师制作课堂素材、节日主题手抄报创作、生成可打印涂色填字模板

## 能力组成

### 能力流程描述
本技能由6个环节串联组成，从输入到输出的完整链路如下：
1. **合规校验优化**：对用户输入的主题、年级进行合规校验与优化，拦截不安全内容，保障生成内容健康合规；
2. **手抄报意图解析与排版策略生成**：深度解析主题意图，结合年级段生成排版策略（文字区数量、整体排版描述）、标题文字方案（简体中文内容+艺术字风格），同时输出主题相关合规约束（如国庆节禁用国旗国徽及对应替换建议）；
3. **黑白线稿生图提示词生成**：基于排版策略、合规约束、装饰元素与标题文字，精准构建黑白线稿生图的正向/负向提示词；
4. **启动线稿图像生成任务**：按用户指定的画面宽高比（ratio）启动高清黑白线稿图像生成；
5. **轮询图像生成状态**：以5秒间隔轮询生成状态，超时上限1200秒，直至任务成功（SUCCEEDED）；
6. **A4打印尺寸适配缩放**：将生成线稿缩放至3200×2400的A4打印适配尺寸，输出最终模板图URL。

数据流转方式：上一环节输出通过变量引用自动传递给下一环节——意图解析产出的排版策略、合规约束、标题文字流入提示词构建环节；提示词与宽高比流入图像生成环节；生成的图像URL流入尺寸适配环节。人机协作节点：用户仅需在启动时提供主题（必填）、年级段（必填）与画面宽高比（选填），其余环节全自动执行，最终交付可直接打印的黑白线稿模板及配套排版、合规、标题信息，孩子只需涂色和填字即可完成。

### 技能能力组成流程图
```mermaid
flowchart TD
    A["用户输入<br/>theme 手抄报主题(必填)<br/>grade 年级段(必填,默认低年级)<br/>ratio 宽高比(选填,默认4:3)"] --> B["step_0 合规校验优化"]
    B --> C["step_1 手抄报意图解析与排版策略生成"]
    C --> C1["title_text 标题文字方案"]
    C --> C2["compliance_constraints 合规约束"]
    C --> C3["layout_strategy 排版策略"]
    C1 --> D["step_2 黑白线稿生图提示词生成"]
    C2 --> D
    C3 --> D
    D --> E["step_3 启动线稿图像生成任务<br/>按 ratio 指定宽高比"]
    E --> F{"step_4 轮询图像生成状态<br/>间隔5s / 超时1200s"}
    F -->|"SUCCEEDED"| G["step_5 A4打印尺寸适配缩放<br/>3200×2400"]
    F -->|"生成中"| F
    G --> H["最终输出<br/>template_image_url 模板图URL<br/>layout_strategy 排版策略<br/>compliance_constraints 合规约束<br/>title_text 标题文字"]
```

官方流程图参考：
![技能能力组成流程图](https://oss.showapi.com/workflow/6a13a91c9e64f2c7637a7564/6a72d0f03c51f2ec21019ee1/snapshot/flow_chart/7102ff0edb.jpg?t=1785910509)

## 前置准备
- 凭证：配置 ShowAPI AppKey，凭证名称：showapi_appkey
  - 脚本优先从环境变量 `SHOWAPI_APP_KEY` 读取；未设置时，运行脚本会交互式提示输入
- **鉴权配置**：
  本 Skill 调用需要 AppKey 鉴权。所有 API 请求的 URL 查询参数中需携带 `appKey={你的AppKey}`。

  ### 如何获取 AppKey
  如果你还没有 AppKey，请按以下步骤通过手机验证获取：
  1. 请用户提供手机号（中国大陆手机号）
  2. 调用发送验证码接口：
     ```
     POST https://www.showapi.com/auth/agent_sendCode
     Content-Type: application/x-www-form-urlencoded

     phone={手机号}
     ```
     成功响应：`{"flag":true,"remark":"发送成功"}`
  3. 请用户查看手机收到的6位验证码并告诉你
  4. 调用验证接口获取 AppKey：
     ```
     POST https://www.showapi.com/auth/agent_verify
     Content-Type: application/x-www-form-urlencoded

     phone={手机号}&code={验证码}
     ```
     成功响应：`{"flag":true,"app_key":"你的AppKey"}`
  5. 将获取到的 app_key 保存，后续所有 API 调用 URL 中携带 `appKey={app_key}` 参数

  ### 注意事项
  - 验证码5分钟有效，每分钟只能发送1次
  - 如果手机号已注册过易源数据平台账户，会直接返回该账户的 AppKey，不会重复注册
  - AppKey 获取后请妥善保存，避免重复验证
- 模拟体验：无 appKey 时，系统自动触发模拟调用，直接返回完整结果，快速预览生成效果
- 依赖：仅使用 Python 标准库，无需安装第三方包

## 操作步骤
### 模拟体验流程（无 appKey）
1. **自动触发模拟调用**
   系统检测到未配置 appKey 时，自动向 `https://www.showapi.com/_nuxt3/api/2405-105` 发送 POST 请求（body: `{"flow_id":"6a72d0f03c51f2ec21019ee1"}`），直接获取完整模拟生成结果。**此过程为一次性返回，不执行 execute_task.py 和 query_task.py。**

2. **可视化预览**
   将返回的 JSON 结果以 HTML 形式可视化展示，重点呈现手抄报线稿模板图片。

3. **引导真实调用**
   提示用户当前为无 appKey 的模拟运行结果。如需真实调用，请通过手机验证获取 AppKey（步骤见「前置准备-鉴权配置」），并在后续所有 API 调用 URL 中携带 `appKey={app_key}` 参数。

### 标准流程（有 appKey，强制异步执行）
1. **收集用户需求**
   明确手抄报主题（必填，如国庆节、中秋节、植树节、消防日等）、年级段（必填，可选 低年级/中年级/高年级，默认低年级）、画面宽高比（选填，可选 4:3/3:4/16:9/1:1，默认4:3）。

2. **异步提交生成任务**
   调用脚本异步执行手抄报黑白线稿模板生成任务，**仅返回唯一 task_id**，不阻塞等待。
   调用示例：
   ```bash
   python scripts/execute_task.py --theme "国庆节" --grade "低年级" --ratio "4:3" --async
   ```

3. **轮询查询任务结果（必选）**
   使用 task_id 循环查询任务状态，**每一轮轮询后，即时将当前返回的核心资料同步反馈给用户**，直至获取完整结果。
   调用示例：
   ```bash
   python scripts/query_task.py --task-id "返回的task_id值"
   ```

4. **等待结果完成**
   必须轮询直到完成（图像生成环节内部含最长1200秒的轮询等待，整体任务耗时可能较长，请耐心持续轮询）。

5. **结果解析与落地应用**
   提取手抄报模板图URL（可直接下载打印至A4纸）、排版策略（指导孩子在各留白区书写内容）、合规约束（涂色装饰时规避禁用元素）、标题文字（照标题区书写艺术字）；孩子涂色填字即可完成手抄报。

6. **生成html页面**
   生成一个简单的html页面来融合返回的主要信息，特别是手抄报线稿模板图片。

## 使用示例
### 示例1：国庆节主题手抄报（低年级）
- 输入：主题“国庆节”，年级“低年级”，宽高比 4:3
- 流程：异步提交任务 → 获取task_id → 轮询查询（每轮反馈进度/数据）
- 产出：A4打印适配的国庆节黑白线稿模板 + 标题艺术字方案 + 合规约束（禁用国旗国徽，附替换建议）+ 低年级大留白排版策略
- 配置要点：theme=国庆节，grade=低年级，ratio=4:3

### 示例2：中秋节主题手抄报（中年级）
- 输入：主题“中秋节”，年级“中年级”，宽高比 3:4
- 流程：异步提交任务 → 获取task_id → 轮询查询（每轮反馈进度/数据）
- 产出：中秋节黑白线稿模板（月亮、玉兔、桂花等线稿元素）+ 适中排版策略 + 标题艺术字方案
- 配置要点：grade=中年级，排版复杂度适中；ratio 可选 3:4 竖版

### 示例3：消防日主题手抄报（高年级）
- 输入：主题“消防日”，年级“高年级”，宽高比 16:9
- 流程：异步提交任务 → 获取task_id → 轮询查询（每轮反馈进度/数据）
- 产出：高年级复杂排版线稿模板（文字区更多、细节更丰富）+ 消防安全主题装饰元素
- 配置要点：grade=高年级，ratio 可选 16:9；主题需具体明确

## 生成效果示例
### 描述
技能运行完成后，输出一份可直接打印的手抄报黑白线稿模板（A4打印适配，3200×2400），核心交付4类信息：
1. **template_image_url（手抄报模板图URL）**：最终生成的黑白线稿模板图访问地址，画面为纯线稿（无填色），孩子涂色和填字即可完成；
2. **title_text（标题文字）**：模板中的标题文字信息，含标题内容（content）、艺术字风格（style）与语言（language），孩子可参照标题区书写艺术字；
3. **layout_strategy（排版策略）**：根据年级段生成的排版说明，含年级段（grade_segment）、文字区数量（text_area_count）与整体排版描述（overall_description），用于指导孩子在对应留白框内书写内容；
4. **compliance_constraints（合规约束）**：主题相关的合规提示，含禁用元素（prohibited_elements）与替换建议（replacement_suggestions），如国庆节主题禁用国旗国徽，建议以彩旗、五角星等装饰替代。

可视化呈现方式：模板图以图片形式直接展示并支持下载打印；结构化信息以 JSON 返回，便于程序化处理与归档。

### 输出案例
> 说明：若输出结果包含图片，**优先插入对应图片资源**，之后再输出 JSON / Markdown 格式的文本内容。

![手抄报线稿模板生成效果示例1](https://oss.showapi.com/workflow/6a13a91c9e64f2c7637a7564/6a72d0f03c51f2ec21019ee1/snapshot/caseImgs/3b7369168b.jpg?t=1785910434)

![手抄报线稿模板生成效果示例2](https://oss.showapi.com/workflow/6a13a91c9e64f2c7637a7564/6a72d0f03c51f2ec21019ee1/snapshot/caseImgs/81cbec1429.jpg?t=1785910435)

![手抄报线稿模板生成效果示例3](https://oss.showapi.com/workflow/6a13a91c9e64f2c7637a7564/6a72d0f03c51f2ec21019ee1/snapshot/caseImgs/d23f6852c3.jpg?t=1785910436)

接口返回的 JSON 数据实际形态如下：

```json
{
  "showapi_res_body": {
    "title_text": {
      "language": "简体中文",
      "style": "可爱卡通艺术字，笔画圆润、带粗描边留白",
      "content": "欢度国庆"
    },
    "compliance_constraints": {
      "theme": "国庆节",
      "prohibited_elements": ["国旗", "国徽"],
      "replacement_suggestions": ["飘扬的彩旗", "五角星装饰", "天安门简笔画轮廓"]
    },
    "template_image_url": "https://oss.showapi.com/xxx/guoqing_a4_template.png",
    "layout_strategy": {
      "grade_segment": "低年级",
      "text_area_count": 3,
      "overall_description": "整体采用大留白设计，顶部为横排艺术字标题区，中部设置3个大号文字书写框并配以彩旗、五角星、烟花等简单线稿插画，插画占比约30%，线条加粗，方便低年级孩子涂色与书写。"
    }
  },
  "showapi_res_code": 0,
  "showapi_fee_num": 1
}
```

## 资源索引
- [scripts/execute_task.py](scripts/execute_task.py)：异步提交手抄报线稿模板生成任务（真实调用时使用）
- [scripts/query_task.py](scripts/query_task.py)：轮询查询异步任务结果（真实调用时使用）

## 响应数据结构
### 1. 异步任务提交响应
```json
{
  "showapi_res_body": {
    "task_id": "唯一任务ID",
    "status": "pending",
    "msg": "任务已提交，正在异步处理中"
  },
  "showapi_res_code": 0,
  "showapi_fee_num": 1
}
```

### 2. 任务查询响应（单轮轮询返回数据，需实时同步给用户）
```json
{
  "showapi_res_body": {
    "title_text": {
      "language": "标题语言，如简体中文",
      "style": "艺术字风格描述",
      "content": "标题内容"
    },
    "compliance_constraints": {
      "theme": "手抄报主题",
      "prohibited_elements": ["禁用元素列表"],
      "replacement_suggestions": ["替换建议列表"]
    },
    "template_image_url": "最终生成的A4打印适配手抄报黑白线稿模板图URL",
    "layout_strategy": {
      "grade_segment": "年级段",
      "text_area_count": 3,
      "overall_description": "整体排版描述"
    }
  },
  "showapi_res_code": 0,
  "showapi_fee_num": 1
}
```

## 注意事项
1. theme 为必填项，需明确手抄报主题（如国庆节、中秋节、植树节、消防日等）；grade 为必填项，可选 低年级/中年级/高年级（默认低年级），直接影响排版复杂度与留白比例。
2. ratio 可选 4:3、3:4、16:9、1:1（默认4:3），最终输出统一缩放适配 A4 打印尺寸（3200×2400），可直接打印。
3. 涉及政治类主题（如国庆节）时，系统自动进行合规校验并禁用相关元素（如国旗、国徽），同时给出替换建议，请引导孩子按建议涂色装饰。
4. 所有任务**强制异步执行**，不支持同步模式。
5. 轮询查询过程中，**每次获取接口返回数据后，立即将主要内容反馈给用户**。
6. **模拟运行说明**：无 appKey 时系统自动触发模拟调用，一次性返回完整 JSON 结果，不经过 execute_task.py 和 query_task.py，结果仅作效果预览，非真实生成内容。如需真实调用，请通过手机验证获取 AppKey 并配置。