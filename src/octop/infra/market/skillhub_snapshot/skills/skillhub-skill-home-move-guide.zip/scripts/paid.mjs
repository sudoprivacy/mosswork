#!/usr/bin/env node
/**
 * home-move-guide · 付费调用客户端（微信支付 Agent Pay X402 协议）
 *
 * 协议（SkillHub 官方 X402）：
 *   ① 未付款 → 服务端返回 HTTP 402，响应头带支付触发标识：
 *        WeixinPay-Required : 支付凭证码 payment_code（一次性；仅系统与支付插件间传递，不落盘/不写日志/不向用户展示原始值）
 *        X-Out-Trade-No     : 商户订单号
 *      当前环境若已装微信 AI 支付插件（工具名含 weixinpay_），系统会识别该标识并拉起支付卡片。
 *   ② 已付款 → 原样携带上述两个请求头重新请求同一地址 → 200 交付完整内容。
 *
 * 用法：
 *   node scripts/paid.mjs            发起付费请求（402 → 拉起支付 → 自动取回）
 *   node scripts/paid.mjs deliver    已付款但中断时，凭本地保存的支付信息重新取回
 *   node scripts/paid.mjs qr         仅取回付款二维码（支付卡片不可用时的兜底）
 *   node scripts/paid.mjs status     查看当前进度
 *
 * 本脚本不接触任何密钥：签名鉴权、下单、查单核验全部在服务端完成。
 */
import fs from 'node:fs';
import path from 'node:path';
import https from 'node:https';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

const SLUG = 'home-move-guide';
const DISPLAY = 'home-move-guide';
const PRICE = '1';
const BASE = 'https://sanhaoyoung821208-d5dv139af0958c-1255559199.ap-shanghai.app.tcloudbase.com/payskill';
const RESOURCE_URL = BASE + '/skill/' + SLUG;

const __dirname_ = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname_, '..');

const argv = process.argv.slice(2);
const cmd = argv[0] || 'run';
function arg(name, fallback = '') {
  const i = argv.indexOf('--' + name);
  if (i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--')) return argv[i + 1];
  return fallback;
}
const resourceUrl = arg('resource-url', RESOURCE_URL);
const sessionId = arg('session-id', 'S' + Date.now());
/** 自动定位最近一次会话目录：deliver/status 续跑时必须复用上次的订单，否则会「找不到订单号」 */
function latestStateDir() {
  const base = path.resolve(ROOT, '.state');
  try {
    const dirs = fs.readdirSync(base)
      .map((n) => path.join(base, n))
      .filter((d) => { try { return fs.statSync(d).isDirectory() && fs.existsSync(path.join(d, 'state.json')); } catch { return false; } })
      .sort((a, b) => fs.statSync(path.join(b, 'state.json')).mtimeMs - fs.statSync(path.join(a, 'state.json')).mtimeMs);
    return dirs[0] || '';
  } catch (e) { return ''; }
}
const _autoDir = (cmd === 'deliver' || cmd === 'status') ? latestStateDir() : '';
const stateDir = path.resolve(ROOT, arg('state-dir', _autoDir || path.join('.state', sessionId)));

const f = (n) => path.join(stateDir, n);
const say = (...a) => console.log(...a);
const warn = (...a) => console.error(...a);
function ensureState() { fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 }); }
function readJson(p, d = null) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return d; } }
function writeJson(p, o) { ensureState(); fs.writeFileSync(p, JSON.stringify(o, null, 2), { encoding: 'utf8', mode: 0o600 }); }
function writeBytes(p, buf) { ensureState(); fs.writeFileSync(p, buf, { mode: 0o600 }); }
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

/** 请求：支付信息只走请求头，请求体不变（官方 X402 要求） */
async function reqGet(url, headers = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? https : http;
    // 流量真伪标识：付费客户端发的是「真人意图」的请求，必须带可识别特征，
    // 否则会被服务端「空 UA = 机器」的规则误判，导致真人订单被计入探测流量。
    const h = Object.assign({
      'User-Agent': 'PayskillClient/1.0 (real-purchase-intent; +https://skillhub.cn)',
      'X-Payskill-Client': 'paid-script/1.0',
      'Accept': 'application/json, text/plain, */*',
    }, headers);
    const r = lib.request({
      method: 'GET', hostname: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname + (u.search || ''), headers: h, timeout: 30000,
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks).toString('utf8') }));
    });
    r.on('timeout', () => r.destroy(new Error('request timeout')));
    r.on('error', reject);
    r.end();
  });
}

/** 402 里的支付触发标识：优先响应头，其次响应体（兼容只读 body 的智能体） */
function paymentFrom(res) {
  const h = res.headers || {};
  let body = {};
  try { body = JSON.parse(res.body); } catch { /* ignore */ }
  const wp = body.WeixinPay || {};
  return {
    weixinPayRequired: h['weixinpay-required'] || wp.payment_code || '',
    outTradeNo: h['x-out-trade-no'] || body.out_trade_no || '',
    amount: body.amount || PRICE,
  };
}

async function probe() {
  ensureState();
  say(`\n【1/3】请求付费资源：${resourceUrl}`);
  const res = await reqGet(resourceUrl);

  if (res.status === 200) {
    say('✅ 本次无需付费，内容如下：\n');
    say(res.body);
    writeJson(f('state.json'), { phase: 'free', at: new Date().toISOString() });
    return { done: true, code: 0 };
  }
  if (res.status !== 402) {
    warn(`❌ 资源请求返回 HTTP ${res.status}，预期 402（待支付）或 200（已支付）。`);
    warn(String(res.body).slice(0, 500));
    return { done: true, code: 1 };
  }

  const p = paymentFrom(res);
  if (!p.outTradeNo) { warn('❌ 收到 402，但缺少商户订单号 X-Out-Trade-No。'); return { done: true, code: 1 }; }

  // 凭据保护铁律：payment_code 属一次性敏感凭证，**不写入任何本地文件、不写日志**。
  // 跨轮次/断点续传时，靠订单号重新申领（订单在微信侧有效期内始终可重新换发凭据）。
  writeJson(f('state.json'), {
    phase: 'probed', slug: SLUG, amount: p.amount,
    out_trade_no: p.outTradeNo,
    created_ms: Date.now(),
    expires_ms: Date.now() + 9 * 60 * 1000,
    at: new Date().toISOString(),
  });

  say('');
  say('✅ 已取得账单，支付触发标识如下（由系统接管拉起微信支付卡片）：');
  say('   技能　：' + DISPLAY);
  say('   金额　：¥' + p.amount + ' CNY');
  say('   订单号：' + p.outTradeNo);
  say('');
  // 微信支付「工程化支付」：系统自动检测【工具返回】中的 WeixinPay-Required 字段并拉起支付卡片。
  // 因此必须把该字段原样输出到 stdout —— 这是支付卡片能被拉起的唯一途径。
  // 凭据仅经 stdout 交由系统接管：不写入任何文件、不落盘、不进日志、不向用户转述。
  if (p.weixinPayRequired) {
    say('WeixinPay-Required: ' + p.weixinPayRequired);
    say('X-Out-Trade-No: ' + p.outTradeNo);
    say('（以上两行为系统字段，用于自动拉起微信 AI 支付卡片；智能体请勿向用户转述其原始值。）');
  } else {
    say('⚠️ 未取得支付触发标识 WeixinPay-Required，请确认运行环境已安装微信 AI 支付插件。');
  }
  say('');
  say('   支付途径：请在弹出的微信 AI 支付卡片上确认付款（¥' + p.amount + '）。');
  say('   支付完成后本脚本会自动重新请求取回内容，无需其他操作。')
  return { done: false, code: 0, outTradeNo: p.outTradeNo, weixinPayRequired: p.weixinPayRequired };
}

/** 凭订单号重新申领支付凭据（服务端幂等重发，凭据全程不落盘） */
async function ensureCredential(outTradeNo) {
  try {
    const res = await reqGet(resourceUrl, {
      'X-Payskill-Rebind': '1',
      'X-Out-Trade-No': outTradeNo,
    });
    const p = paymentFrom(res);
    if (p.weixinPayRequired) return p.weixinPayRequired;
    return '';
  } catch (e) {
    return '';
  }
}

async function pollAndDeliver(outTradeNo, weixinPayRequired) {
  const st = readJson(f('state.json'), {});
  outTradeNo = outTradeNo || st.out_trade_no || '';
  // 凭据不落盘：跨轮次时凭订单号重新申领（见下方 ensureCredential）
  if (!outTradeNo) { warn('❌ 找不到订单号，请先运行：node scripts/paid.mjs'); return 1; }

  // 时效检查：凭据有效期 10 分钟；超过 9 分钟直接重建新单，避免拿过期凭据反复撞墙。
  const createdMs = st.created_ms || 0;
  if (createdMs && Date.now() - createdMs > 9 * 60 * 1000) {
    warn('\n⚠️ 本单凭据已接近过期（下单已超 9 分钟），重新发起下单…');
    const r = await run();
    return typeof r === 'number' ? r : 0;
  }

  // 凭据缺失（跨轮次执行 / 进程重启）→ 凭订单号重新申领，凭据全程不落盘。
  if (!weixinPayRequired) {
    say('\n（本次未持有支付凭据，凭订单号重新申领…）');
    const re = await ensureCredential(outTradeNo);
    if (re) { weixinPayRequired = re; }
    else { warn('⚠️ 凭据申领失败，重新发起下单…'); const r = await run(); return typeof r === 'number' ? r : 0; }
  }

  say('\n【2/3】等待支付完成（每 3 秒核验一次，最多 20 分钟）…');
  const deadline = Date.now() + 20 * 60 * 1000;
  let dots = 0;
  while (Date.now() < deadline) {
    // 第三步：支付成功后重新请求同一地址，原样携带两个请求头（请求体不变）
    const headers = { 'X-Out-Trade-No': outTradeNo };
    if (weixinPayRequired) headers['WeixinPay-Required'] = weixinPayRequired;
    const res = await reqGet(resourceUrl, headers);

    if (res.status === 200) {
      say('\n【3/3】✅ 支付核验通过，内容已交付：\n');
      say(res.body);
      const s = readJson(f('state.json'), {});
      s.phase = 'completed'; s.at = new Date().toISOString();
      writeJson(f('state.json'), s);
      return 0;
    }
    if (res.status === 402) {
      let b = {}; try { b = JSON.parse(res.body); } catch { /* ignore */ }
      if (b.error === 'payment_not_completed') {
        process.stdout.write('.'); if (++dots % 20 === 0) say('');
        await sleep(3000); continue;
      }
      if (b.error === 'payment_required' || b.error === 'bad_order_no') {
        warn('\n⚠️ 订单已失效，重新发起下单…');
        const r = await run();
        return typeof r === 'number' ? r : 0;
      }
      warn('\n⚠️ 服务端返回：' + JSON.stringify(b).slice(0, 200));
      await sleep(3000); continue;
    }
    warn('\n⚠️ 服务端返回 ' + res.status + '：' + String(res.body).slice(0, 200));
    await sleep(5000);
  }
  warn('\n⌛ 等待超时。若你已完成支付，请运行：node scripts/paid.mjs deliver');
  warn('   若尚未支付，请重新运行：node scripts/paid.mjs（会生成一张新的支付单）');
  return 2;
}

async function run() {
  const r = await probe();
  if (r.done) return r.code;
  return await pollAndDeliver(r.outTradeNo, r.weixinPayRequired);
}
async function deliver() { return await pollAndDeliver(''); }

function status() {
  say(`\n技能：${DISPLAY}  (${SLUG})`);
  say('资源：' + resourceUrl);
  say('单价：¥' + PRICE + '/次');
  say('协议：微信支付 Agent Pay X402（402 + WeixinPay-Required → 付款后带请求头重取）');
  const st = readJson(f('state.json'), null);
  say('状态：' + (st ? JSON.stringify(st, null, 2) : '（尚未发起）'));
  return 0;
}

const routes = { run, deliver, status };
const fn = routes[cmd] || run;
Promise.resolve(fn()).then((c) => process.exit(typeof c === 'number' ? c : 0))
  .catch((e) => { console.error('❌ 执行失败：', e && e.message ? e.message : e); process.exit(1); });
