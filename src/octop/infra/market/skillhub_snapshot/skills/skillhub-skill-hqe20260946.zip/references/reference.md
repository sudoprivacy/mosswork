# 参考

- 权限点挂在 commissionSnapshot 管理调整接口。
- 与代管自动改挂冲突时：以当前 `manageCommissionMode` 为准。
