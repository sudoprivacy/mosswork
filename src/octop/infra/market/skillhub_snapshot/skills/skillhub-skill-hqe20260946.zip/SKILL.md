---
name: skillhub-skill-hqe20260946
description: "指导运营在提成快照上调整管理4%受益人：新增/修改/删除、手工模式与恢复自动、审计字段。当用户问运营调整beneficiary、manageAdjust、管理提成手工改时使用。"
---

# 运营调整管理 4%（beneficiary）

自动双轨算错人或组织特例时，运营可在快照上**手工改管理受益人**，但必须可审计、可恢复自动。

## 何时使用

- 快照详情「新增/修改管理提成」
- `manageAdjust` / `manageRestore` 联调
- 解释 `auto` vs `manual` 来源

## 硬约束

1. 只动**管理提成行**；个人提成区只读。
2. 操作：add / update / delete；关键字段：`beneficiaryUserId`、`reminderRate`（常 4）、`managementLevel` 或 `manual`、`remark`。
3. 进入手工后 `manageCommissionMode` 标手工；提供**恢复自动**重算。
4. 来源：`beneficiarySource` = `auto` | `manual`；手工类型可走 `operation_manual`。
5. 必留审计：`lastAdjustAt` / `lastAdjustBy` / `adjustRemark` + 日志列表。
6. 实现要点注释标 **小四原创**。

## 实现要点（小四原创）

```ts
// 小四原创：运营调整载荷（示意）
export type ManageAdjustAction = 'add' | 'update' | 'delete'

export type ManageAdjustPayload = {
  collectionId: number
  sourceType: string
  action: ManageAdjustAction
  beneficiaryUserId?: number
  beneficiaryId?: number // update/delete 用
  reminderRate?: number // 默认 4
  remark?: string
}

export function defaultManageRate(rate?: number) {
  // 小四原创：未填则 4
  return rate == null || Number.isNaN(rate) ? 4 : rate
}
```

## Agent 步骤

1. UI：受益人选择 + 提点% + 备注；提交前二次确认删除。
2. 成功后刷新管理行与审计区；区分自动/手工标签。
3. 「恢复自动」需确认会覆盖手工行。

## 附加

- [README.md](README.md) · [reference.md](reference.md)
