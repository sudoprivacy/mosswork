# 四象限机会地图可视化生成指引

本文档提供使用 `show_widget` 工具渲染产品机会地图四象限 SVG 的详细指引与模板。

## 坐标系定义

```
Y轴（满意度）
  5 ┌──────────────────────────────┐
    │  ⚪ 过度服务区        🟢 竞争优势区  │
    │  (低重要+高满意)      (高重要+高满意) │
    │                              │
  3 │ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ │
    │                              │
    │  🟡 次要改进区        🔴 核心机会区  │
    │  (低重要+低满意)      (高重要+低满意) │
  1 └──────────────────────────────┘
    1        3        5
              X轴（重要性）
```

## show_widget 调用规范

### 前置步骤

在调用 `show_widget` 前，必须先调用 `read_me` 加载 `diagram` 模块：

```
read_me(modules: ["diagram"])
```

### SVG 模板

以下为标准四象限 SVG 模板，使用 `viewBox="0 0 680 480"`：

```xml
<svg viewBox="0 0 680 480" xmlns="http://www.w3.org/2000/svg">
  <!-- 背景 -->
  <rect width="680" height="480" fill="#0d1117"/>

  <!-- 标题 -->
  <text x="340" y="30" text-anchor="middle" font-size="18" font-weight="bold" fill="#e6edf3">
    产品机会地图（Product Opportunity Map）
  </text>

  <!-- 四象限底色 -->
  <!-- 左上：过度服务区 ⚪ -->
  <rect x="80" y="60" width="260" height="180" fill="#30363d" opacity="0.4" rx="4"/>
  <!-- 右上：竞争优势区 🟢 -->
  <rect x="340" y="60" width="260" height="180" fill="#1a7f37" opacity="0.25" rx="4"/>
  <!-- 左下：次要改进区 🟡 -->
  <rect x="80" y="240" width="260" height="180" fill="#9e6a03" opacity="0.25" rx="4"/>
  <!-- 右下：核心机会区 🔴 -->
  <rect x="340" y="240" width="260" height="180" fill="#da3633" opacity="0.25" rx="4"/>

  <!-- 象限标签 -->
  <text x="210" y="85" text-anchor="middle" font-size="13" font-weight="bold" fill="#8b949e">⚪ 过度服务区</text>
  <text x="470" y="85" text-anchor="middle" font-size="13" font-weight="bold" fill="#3fb950">🟢 竞争优势区</text>
  <text x="210" y="265" text-anchor="middle" font-size="13" font-weight="bold" fill="#d29922">🟡 次要改进区</text>
  <text x="470" y="265" text-anchor="middle" font-size="13" font-weight="bold" fill="#f85149">🔴 核心机会区</text>

  <!-- 象限说明（小字）-->
  <text x="210" y="100" text-anchor="middle" font-size="10" fill="#6e7681">低重要 + 高满意</text>
  <text x="470" y="100" text-anchor="middle" font-size="10" fill="#6e7681">高重要 + 高满意</text>
  <text x="210" y="280" text-anchor="middle" font-size="10" fill="#6e7681">低重要 + 低满意</text>
  <text x="470" y="280" text-anchor="middle" font-size="10" fill="#6e7681">高重要 + 低满意</text>

  <!-- 坐标轴 -->
  <line x1="80" y1="420" x2="600" y2="420" stroke="#484f58" stroke-width="1.5"/>
  <line x1="340" y1="60" x2="340" y2="420" stroke="#484f58" stroke-width="1.5" stroke-dasharray="4,4"/>

  <!-- X轴标签 -->
  <text x="340" y="450" text-anchor="middle" font-size="12" fill="#8b949e">用户重要性 →</text>
  <text x="100" y="440" font-size="10" fill="#6e7681">1</text>
  <text x="590" y="440" font-size="10" fill="#6e7681">5</text>

  <!-- Y轴标签 -->
  <text x="60" y="240" text-anchor="middle" font-size="12" fill="#8b949e" transform="rotate(-90 60 240)">当前满意度 →</text>
  <text x="70" y="425" font-size="10" fill="#6e7681">1</text>
  <text x="70" y="70" font-size="10" fill="#6e7681">5</text>

  <!-- 数据点（示例：根据实际分析结果替换）-->
  <!-- 圆点大小 = 综合热度(F×I)，最小 r=6，最大 r=18 -->
  <!-- P0 核心机会区数据点（红色实心）-->
  <circle cx="500" cy="340" r="14" fill="#f85149" stroke="#ffa198" stroke-width="1.5"/>
  <text x="520" y="345" font-size="11" fill="#e6edf3">数据导出</text>

  <circle cx="440" cy="370" r="10" fill="#f85149" stroke="#ffa198" stroke-width="1.5"/>
  <text x="460" y="375" font-size="11" fill="#e6edf3">批量操作</text>

  <!-- P1 竞争优势区数据点（绿色实心）-->
  <circle cx="500" cy="150" r="12" fill="#3fb950" stroke="#56d364" stroke-width="1.5"/>
  <text x="520" y="155" font-size="11" fill="#e6edf3">搜索精度</text>

  <!-- P2 次要改进区数据点（黄色实心）-->
  <circle cx="180" cy="350" r="8" fill="#d29922" stroke="#e3b341" stroke-width="1.5"/>
  <text x="200" y="355" font-size="11" fill="#e6edf3">皮肤主题</text>

  <!-- P3 过度服务区数据点（灰色实心）-->
  <circle cx="180" cy="140" r="7" fill="#8b949e" stroke="#afb8c1" stroke-width="1.5"/>
  <text x="200" y="145" font-size="11" fill="#e6edf3">高级筛选</text>

  <!-- 图例 -->
  <g transform="translate(80, 465)">
    <circle cx="8" cy="0" r="6" fill="#f85149"/>
    <text x="20" y="4" font-size="10" fill="#8b949e">P0 核心</text>
    <circle cx="78" cy="0" r="6" fill="#3fb950"/>
    <text x="90" y="4" font-size="10" fill="#8b949e">P1 优势</text>
    <circle cx="148" cy="0" r="6" fill="#d29922"/>
    <text x="160" y="4" font-size="10" fill="#8b949e">P2 次要</text>
    <circle cx="218" cy="0" r="6" fill="#8b949e"/>
    <text x="230" y="4" font-size="10" fill="#8b949e">P3 过度</text>
    <text x="300" y="4" font-size="10" fill="#6e7681">圆点大小 = 综合热度(频次×强度)</text>
  </g>
</svg>
```

## 数据点坐标映射规则

将评分（1-5）映射到 SVG 坐标：

**X 轴（重要性）→ SVG x 坐标**：
- 评分 1 → x ≈ 100
- 评分 2 → x ≈ 180
- 评分 3 → x ≈ 260（象限分界线 x=340 的左侧）
- 评分 4 → x ≈ 420
- 评分 5 → x ≈ 500

**Y 轴（满意度）→ SVG y 坐标**（注意 Y 轴翻转）：
- 评分 1 → y ≈ 400
- 评分 2 → y ≈ 340
- 评分 3 → y ≈ 260（象限分界线 y=240 附近）
- 评分 4 → y ≈ 160
- 评分 5 → y ≈ 100

**圆点半径（综合热度 F×I）**：
- F×I ≤ 5 → r = 6
- F×I 6-10 → r = 8
- F×I 11-15 → r = 10
- F×I 16-20 → r = 12
- F×I 21-30 → r = 14
- F×I > 30 → r = 18

## 配色规范（暗色主题）

| 元素 | 颜色 |
|------|------|
| 背景 | #0d1117 |
| 核心机会区底色 | #da3633 (opacity 0.25) |
| 竞争优势区底色 | #1a7f37 (opacity 0.25) |
| 次要改进区底色 | #9e6a03 (opacity 0.25) |
| 过度服务区底色 | #30363d (opacity 0.4) |
| P0 数据点 | #f85149 |
| P1 数据点 | #3fb950 |
| P2 数据点 | #d29922 |
| P3 数据点 | #8b949e |
| 主文字 | #e6edf3 |
| 次要文字 | #8b949e |
| 辅助文字 | #6e7681 |

## 亮色主题适配

当 IDE 为亮色主题时，调整以下颜色：
- 背景：#ffffff
- 主文字：#1f2328
- 次要文字：#59636e
- 象限底色透明度提升至 0.15
- 数据点颜色保持不变

## 注意事项

1. **数据点不重叠**：若多个功能点坐标接近，手动微调 y 坐标（±15px）避免标签遮挡
2. **标签可读性**：标签文字至少 11px，颜色与背景有足够对比度
3. **P0 点优先**：核心机会区的数据点应视觉最突出（最大圆点、最亮颜色）
4. **数量控制**：单张图最多展示 15 个数据点，超出时只展示 P0/P1，P2/P3 在清单中呈现
5. **loading_messages**：show_widget 调用时传入 loading_messages，如 `["正在构建机会地图", "计算象限定位", "渲染可视化"]`
