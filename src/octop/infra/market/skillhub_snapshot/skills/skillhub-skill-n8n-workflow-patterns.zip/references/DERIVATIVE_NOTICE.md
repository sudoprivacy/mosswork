# 衍生版本说明

- 原项目：[davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)
- 原文件：`cli-tool/components/skills/workflow-automation/n8n/n8n-workflow-patterns/SKILL.md`
- 固定提交：`4a985f8ce8b05597cc9f38216c24ce1846a0e134`
- 许可证：`MIT`，全文见 `LICENSE.md`
- 修改内容：语义化 slug、中文业务名称、发布接口元数据和帮助入口。
- 未删除原许可证义务，也未扩大原 Skill 的能力声明。
