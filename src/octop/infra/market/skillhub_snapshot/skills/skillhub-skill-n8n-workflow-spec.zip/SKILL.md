---
name: skillhub-skill-n8n-workflow-spec
description: "适用于把线下流程落到 n8n 前的设计评审；输入触发方式、数据口径与失败处理要求，输出节点级规格与测试用例，不代替实机测试，不把未验证的工作流标为可上线 / Use before committing a business"
---

<!-- unified-payment-template: 1.0.4 -->
## 支付依赖与恢复 / Payment runtime and recovery

运行时需要 Node.js 20+ 和宿主的支付宝官方 `alipay-payment-skill`、`alipay-bot`。宿主不同不代表钱包授权可以搬运。正常第一条支付宝业务命令是官方 buyer-pay 或原单查询，不能加通用 check-wallet 前检。

只有真实业务命令无法找到/执行 alipay-bot 时，才加载官方技能的 `references/command-recovery.md`：取得外部安装授权，核对指定版本 `@alipay/agent-payment@1.0.23` 的官方完整性后安装，再重试原命令一次。不能每次调用都安装 latest，不能把卖家部署工具当作买方依赖；已启动但业务失败时原样展示并停止。

English: Use the current host's official Alipay buyer runtime. Only an actual command-not-found failure enters the official pinned-version installation recovery. Do not reinstall on every call, precheck wallets generically, or install merchant tooling in the buyer path.

仅在上述恢复条件成立且已获外部安装授权时执行下列两步。先查询完整性，必须逐字符等于下面的指定值；不一致或查不到则停止，不能继续安装：

```text
npm view '@alipay/agent-payment@1.0.23' dist.integrity --registry 'https://registry.npmjs.org'
```

```text
sha512-7OGSHhPnuKsyENpivpY60NgE77ktKtWTP8UBtmizeB1Et44KHFFIjDcSRIFpitEdKAC7uMBx3Mp1Zg/wbYmYCQ==
```

核对一致后才执行安装，并仅重试原先无法执行的命令一次：

```text
npx -y --registry=https://registry.npmjs.org @alipay/agent-payment@1.0.23 install
```

这里的命令是依赖恢复说明，不是正常付款前置；官方技能版本更新时须重新对照其 command-recovery.md，不沿用过期完整性值。

## 本包现行支付流程 / Registered checkout

本包支付配置为 payment-contract.json：资源 `n8n-workflow-spec`、单价 ¥0.10 / CNY、支付宝服务 ID `API_FC3B91AF109D47C8`、完整服务地址 `https://fwskillpay-api.cn/v1/pay/skills/n8n-workflow-spec/invoke`。配置与 SKILL/助手哈希不符即停止。平台展示价须在提交后单独回读，不能从本包检查推定平台价已经一致。

1. 调用前披露输入范围、接收方、用途、留存及 ¥0.10，取得本次数据传输和该金额的付款授权。已有授权不再二次询问；价格一致也不能代替授权。
2. 在包外私有目录准备 payload.json，按本 Skill 的输入契约执行 probe。400、503、429、未知网络状态或未付款的 200 都停止，不能本地代做付费结果。
3. 只核对网关公开 JSON 摘要中的金额、币种、商户订单号、资源 ID、服务 ID 和有效期；任一字段缺失、类型错误、过期或与登记不符都停止，不进入 pay。不解码 Payment-Needed 或 amtPaymentLink，不自行验签；公开摘要不能证明签名、实际付款或到账。
4. 本次唯一非空 amtPaymentLink 优先，并原样交给官方 `--amt-payment-link`，不写付款材料文件；链接缺失才使用原值保存的 Payment-Needed 文件。空、多个或歧义链接停止，两种参数互斥，不能补造或从历史输出补齐。
5. 已有该金额授权时立即准备 pay，宿主在返回的 workingDirectory 实际用 executable 与参数数组运行官方 buyer-pay。参数 JSON 不算弹码。会话按下表取值，保持本次原请求与幂等键。
6. 原样输出当前官方对客文本一次，完整展示全部 MEDIA 图片；不复用旧图、不绘制替代二维码。链接生成、success:true、OPEN_LINK_CREATED 不代表付款或交付。
7. 宿主把刚执行的官方对客文本保存在包外私有文件，用本次 handoffId 执行 record-official。只从“订单号/查询单号/交易号”标签提取标识；拒绝原始 JSON、其他交接或冲突标识。观察分类由宿主依据真实输出选择，不是 helper 验付。
8. 用户表示付好或要求查询时，complete 按已绑定标识查询原单：有效 32 位、11–14 位为 8282 的查询号优先；否则用本次交易号。查询不附加 session-id、账单文件或付款链接。未绑定原单停止，不能猜测。
9. 只交付官方实际返回的非空验付后资源。成功交付、业务失败、资源为空、身份不符或查询失败后停止；仅命令超时/网络失败允许按官方规则重试原命令一次。不能从 success 字样认定收款。

English: Obtain data-transfer and price authorization before probe. Compare the public checkout summary while passing payment material unchanged to the official runtime. A unique amtPaymentLink takes priority over an opaque Payment-Needed file. Actually execute the returned argument array, show all current official media, then bind the current official customer-facing output to its handoff. Query only the bound original order. Deliver only actual nonempty official resources. Offline helper checks and host observations are not proof of payment or settlement.

### 当前会话 / Current session

取首个非空来源，高优先级不能被低优先级覆盖：

| 优先级 | 当前运行时来源 |
|---|---|
| 1 | sessionId / session_id 元数据 |
| 2 | threadId / thread_id / conversationId / conversation_id / agentContextId；Codex 使用 CODEX_THREAD_ID |
| 3 | 前两级都为空才用 AIPAY_SESSION_ID |

不能生成会话 ID，不能用订单号、交易号、用户/钱包 ID、URL、测试名或历史会话代替；陈旧环境变量不能覆盖当前显式会话。官方订单号形状（32 位数字且第 11–14 位为 8282）只用于查询，任何符合该形状的串都不是会话，宿主号码仍按逐级取值。全部为空则停止。The current runtime identity takes precedence over inherited environment values.

### 助手调用 / Helper calls

```text
node scripts/skill-paid.mjs probe --state-dir "<包外私有目录>" --payload-file "<包外私有目录>/payload.json" --confirm-data-transfer
node scripts/skill-paid.mjs pay --state-dir "<同一目录>" --session-id "<当前真实会话>" --intent-summary "原始请求：<本次业务目的摘要>" --confirm-payment
node scripts/skill-paid.mjs record-official --state-dir "<同一目录>" --handoff-id "<刚输出的交接ID>" --official-output-file "<刚执行的官方对客文本文件>" --confirm-current-output --outcome pending
node scripts/skill-paid.mjs complete --state-dir "<同一目录>"
```

链接分支 pay 额外带 `--amt-payment-link "<本次 probe 原样返回的值>"`；不能从扫码图片或用户操作链接取替代值。每次实际官方命令后都记录本次 handoff。官方资源文件只存私有目录；资源已交付时可记录 resource_delivered。ack_failed 还须同次真实输出明确回执失败、非空资源文件和已交付确认。无把握时记录 unknown 并停止。

### 大输入、中断及回执 / Large inputs and recovery

大载荷只走同域 /stage 短引用，失败停止，不把大 JSON 塞回命令行。原文恢复副本存在包外私有目录。只有绑定的本次官方输出明确报告引用过期，用户在后续要求恢复并同意再次传输时，才可 restage --confirm-ref-expired --confirm-data-transfer --confirm-recovery-requested 一次；核对原文 SHA-256，保留原订单和幂等键，之后只恢复原单。

正常官方资源交付会自动处理回执。独立 ACK 只恢复已绑定的同次回执失败，且用户后续要求恢复；不重新请求资源。助手使用单次交接标记和锁拒绝重复/并发 ACK。没有真实证据不填确认标志。

付款启动未知不能删状态、换幂等键或再付一笔。已付款但业务失败保留原单，联系运营者核对恢复或退款；退款没有公开命令时不能自行构造。需要官方反馈时加载 alipay-payment-skill 的 references/feedback.md，先向用户确认脱敏内容后提交，不自动发送。

Windows 的文件 mode 不能保证 ACL；宿主须使用当前用户私有目录并核对访问范围。付款材料、当前官方文本、业务原文、资源文件、Cookie 和钱包凭据都不进入发布包或跨宿主同步。


- Service URL：https://fwskillpay-api.cn/v1/pay/skills/n8n-workflow-spec/invoke
## 依赖技能 / Dependencies

中文：买方侧的 402 支付由**支付宝官方能力**处理。使用前先确认宿主是否已具备；缺少时通过宿主自带的官方 Skill 安装器补齐——**不要自行实现支付逻辑、不要手写 402 客户端、不要在本包内安装任何组件**：

- `alipay-payment-skill` —— 官方买家支付技能：发起请求、解析 402 账单、唤起支付宝付款、携 `Payment-Proof` 重试并完成履约
- `@alipay/agent-payment` —— 官方买家侧安装包，由宿主提供，用于得到上述官方能力（本包不含安装命令）
- `alipay-bot` —— 官方买方命令行工具，随官方买家侧安装包提供

旧版兼容名（宿主仍是旧版组件时使用，能力等价）：
- `alipay-pay-for-402-service` —— 解析账单、发起支付、携凭证重试、发送履约回执
- `alipay-authenticate-wallet` —— 钱包未授权时完成授权
- `alipay-payment-feedback` —— 支付流程异常时的兜底反馈

English: The buyer side of the 402 flow is handled by **Alipay's official capability**. Confirm the host already provides it; if not, the host's own official Skill installer supplies it — **never hand-roll payment logic or a 402 client, and never install components from inside this package**:

- `alipay-payment-skill` — the official buyer payment skill: send the request, parse the 402 bill, trigger the Alipay payment, retry with `Payment-Proof`, complete fulfillment
- `@alipay/agent-payment` — the official buyer-side package the host provides (no install command is shipped here)
- `alipay-bot` — the official buyer CLI, provided with the official buyer-side package

Legacy names (equivalent capability, for hosts still on older components):
- `alipay-pay-for-402-service` — parse the bill, pay, retry with proof, send the fulfillment receipt
- `alipay-authenticate-wallet` — authorize the wallet when required
- `alipay-payment-feedback` — fallback feedback when the payment flow fails

请不要把商户私钥、买家凭证或长期 Token 写入本 Skill；服务端验付也不得以「客户端是否安装组件」为前提。

Never embed merchant private keys, buyer credentials, or long-lived tokens in this skill; server-side verification must not depend on whether the client installed any component.

<!-- buyer-prerequisites v3 -->
## 前置检查 / Prerequisites

中文：本技能除编排示例 买方宿主的支付宝官方组件 外不分发其他可执行文件，且不含任何安装脚本与安装命令。调用前只做**能力确认**，不做本地安装动作：

1. 宿主须已具备官方支付宝买方支付能力（见「依赖技能 / Dependencies」列出的三个官方技能）；缺少时由宿主自身的官方 Skill 安装器补齐，本包不提供安装命令。
2. 钱包须处于已授权状态；未授权时先完成授权，再发起业务请求。
3. 若宿主既无法提供买方支付组件，也无法完成钱包授权，**在支付前停止**并如实向用户说明限制，不得改用本地生成结果。

English: Apart from the orchestration example 买方宿主的支付宝官方组件, this package ships no executables, install scripts, or install commands. Before calling, only confirm capability:

1. The host must already provide the official Alipay buyer-side payment capability (see *Dependencies*); if missing, the host's own official Skill installer supplies it — this package provides no install commands.
2. The wallet must be authorized; complete authorization first if it is not.
3. If the host can neither provide the buyer components nor authorize the wallet, **stop before payment** and tell the user the limitation honestly — never fall back to local generation.

<!-- payment-flow v2 -->
## 触发与调用摘要 / Triggers & usage summary

| 项 / Item | 说明 / Detail |
| --- | --- |
| **触发词 / Triggers** | 中文：当用户提出「n8n 工作流设计与交付规格」相关任务时触发（标识 `n8n-workflow-spec`）。 English: triggered when the user asks for "n8n Workflow Specification & Handoff" (identifier `n8n-workflow-spec`). |
| **输入参数 / Inputs** | 一次调用提交一份结构化请求：必填业务目标，加上所需资料与配置参数（见下方「购买前先看 / Read before purchase」的输入与输出）。输入不完整时先返回缺失项，不进入计费。<br>One call submits one structured request: the required goal plus the materials and configuration the task needs; incomplete input returns the missing fields and is never billed. |
| **单次价格 / Unit price** | ¥0.10 / 次（pay-per-call，按次独立计费；SkillHub 展示价、支付宝登记价与服务端账单金额三者一致）。<br>¥0.10 per call, billed independently; the SkillHub display price, the registered Alipay price, and the server-side bill must match. |
| **依赖安装 / Dependencies** | 买方侧使用宿主**自带的官方支付宝能力**（官方安装器 `@alipay/agent-payment`，提供买家支付技能 `alipay-payment-skill`）；本包不分发安装脚本、不提供安装命令、不含任何密钥或凭证。<br>The buyer side uses the host's **built-in official Alipay capability** (`@alipay/agent-payment`); this package ships no install script, no install command, and no keys or credentials. |
| **调用流程 / How to call** | `HTTP 402` 账单（`Payment-Needed`）→ 官方组件完成支付授权 → 携同一请求与原 `Payment-Proof` 重试 → `HTTP 200` + `Payment-Validation` 交付 → 官方履约确认（`alipay.aipay.agent.fulfillment.confirm`）。状态不明时先查原订单，不重复扣费。<br>`HTTP 402` bill → pay via the official component → retry with the same request and the original `Payment-Proof` → `HTTP 200` + `Payment-Validation` delivery → official fulfillment confirmation; when state is unclear, query the original order first and never charge twice. |


# n8n 工作流设计与交付规格 / n8n Workflow Specification & Handoff

## 一句话结果承诺 / Outcome promise

**中文**：把一句"帮我把这个流程自动化"，变成一份别人能照着搭出来的 n8n 工作流规格，附带失败用例和交接说明。
**English**: Turn "please automate this process" into an n8n specification someone else can actually build from, complete with failure cases and handoff notes.

## 输入示例 / Input example

**中文**
```text
流程：客户把 PDF 报价单发到邮箱 → 抽取字段 → 写入飞书多维表格 → 金额异常时通知销售
触发：邮箱收到带附件的新邮件（约 20 封/天）
数据口径：一行 = 一张报价单；金额字段必须与 PDF 中的价税合计一致
失败处理：解析失败要留底并通知，不能静默丢弃
约束：不允许无人值守地对外发送或修改客户数据
```

**English**
```text
Process: customer emails a PDF quote → extract fields → write to a Feishu Bitable → notify sales when the amount looks wrong
Trigger: new email with attachment (~20/day)
Data contract: one row = one quote; the amount must equal the PDF's tax-inclusive total
Failure handling: parse failures must be retained and reported, never silently dropped
Constraint: no unattended outbound sending or customer-data modification
```

## 处理步骤 / Processing steps

**中文**
1. 明确触发方式、输入结构、期望输出、执行频率、责任人与失败通知渠道。
2. 把流程画成阶段：接收、校验、转换、AI 步骤、人工复核、交付、留痕、重试。
3. 每个阶段指定 n8n 节点类型、必填字段、输入输出 JSON 形状、凭据与失败行为。
4. 重复操作（文件规范化、OCR、去重、通知、审计留痕）抽成子工作流复用。
5. 为下列情况补校验用例：空输入、文件损坏、记录重复、API 超时、部分成功、人工驳回。
6. 在宣称"可上线"之前，先定义一个小型测试数据集与期望结果。
7. 产出一份交接页：触发配置、客户需要提供的凭据、如何重试、哪些环节必须人工确认。

**English**
1. Define the trigger, input schema, expected output, frequency, owner, and failure notification channel.
2. Draw the process as stages: intake, validation, transformation, AI step, human review, delivery, logging, retry.
3. For each stage specify the n8n node type, required fields, input/output JSON shape, credentials, and failure behavior.
4. Reuse sub-workflows for repeated operations such as file normalization, OCR, deduplication, notification, and audit logging.
5. Add validation cases for empty input, malformed files, duplicate records, API timeout, partial success, and human rejection.
6. Define a small test dataset and expected result before calling the workflow production-ready.
7. Produce a handoff page explaining trigger setup, credentials the customer must provide, how to retry, and what requires manual review.

## 输出文件 / 字段示例 / Output example

**中文**：规格必须包含以下 8 项交付物。

```
1. 工作流名称与业务结果
2. 逐节点表（含节点类型、必填字段、连线关系）
3. 输入 / 输出示例（真实 JSON 片段）
4. 凭据清单（客户需自备哪些、哪些不得写入规格）
5. 校验与测试用例（覆盖上述 6 类失败）
6. 错误与重试策略
7. 人工审批点
8. 部署与交接说明
```

逐节点表示例：

| # | 节点 | 类型 | 输入 | 输出 | 失败行为 |
|---|---|---|---|---|---|
| 1 | 邮件触发 | IMAP Trigger | 新邮件 + 附件 | 二进制附件 | 连接失败 → 告警 |
| 2 | 附件校验 | IF | 附件 MIME / 大小 | 通过 / 隔离 | 非 PDF → 转人工队列 |
| 3 | 字段抽取 | HTTP Request | 附件引用 | 结构化字段 | 超时 → 重试 3 次后留底 |

**English**: The specification must contain these eight deliverables.

```
1. Workflow name and business outcome
2. Node-by-node table (node type, required fields, connections)
3. Input / output examples (real JSON fragments)
4. Credential checklist (which the customer supplies, which must never be written into the spec)
5. Validation and test cases (covering the six failure classes above)
6. Error and retry strategy
7. Human approval points
8. Deployment and handoff notes
```

## 成功验收标准 / Acceptance criteria

**中文**
- 8 项交付物全部产出，逐节点表覆盖流程的每一个阶段。
- 每类失败（空输入/损坏文件/重复记录/超时/部分成功/人工驳回）都有对应用例与期望行为。
- 规格中不出现任何真实密钥、Token 或密码；凭据一律写成"由客户在 n8n 凭据管理中自行配置"。
- 所有会产生副作用的节点（发送、发布、删除、付款）都位于显式人工审批节点之后，除非客户已单独授权无人值守。
- 明确写出尚未实机验证这一事实，不使用"已可上线"等表述。

**English**
- All eight deliverables are produced, and the node table covers every stage of the process.
- Every failure class (empty input, malformed file, duplicate record, timeout, partial success, human rejection) has a matching case and expected behaviour.
- No real key, token, or password appears in the specification; credentials are written as "configured by the customer in n8n's credential store".
- Any node with side effects (send, publish, delete, pay) sits behind an explicit human approval node unless the customer has separately authorised unattended execution.
- The document states plainly that it has not been validated on a live instance; phrases like "ready to go live" are not used.

## 适用场景与边界 / Scope and boundaries

**中文**
- **适用**：自动化需求评审、外包交付前的规格确认、内部流程改造设计。
- **不适用**：替代实机搭建与测试；替代客户侧的凭据与授权决策。
- 平台没有可靠 API、或依赖脆弱浏览器自动化时，明确指出该限制并给出人工确认版设计。

**English**
- **In scope**: automation requirement reviews, pre-handover specification sign-off, internal process redesign.
- **Out of scope**: replacing actual instance setup and testing; replacing the customer's credential and authorisation decisions.
- When a platform has no reliable API or the workflow hinges on fragile browser automation, state that limitation and offer a manual-confirmation design.

## 依赖、隐私与失败处理 / Dependencies, privacy, failure handling

**中文**
- **依赖**：无外部 API、无账号、无密钥；产出为设计文档，不执行任何工作流。
- **隐私**：不得在规格中内嵌客户密钥；示例数据须为脱敏样例。
- **失败处理**：需求信息不足时，列出缺失项并给出带假设的规格草案，而不是补全成看似完整的方案。
- **上线约束**：未经代表性数据测试的工作流，一律不得标注为可上线或直接激活。

**English**
- **Dependencies**: no external API, no account, no key; the output is a design document and runs nothing.
- **Privacy**: never embed a customer key in the specification; all example data must be redacted samples.
- **Failure handling**: when requirements are thin, list the gaps and provide an assumption-labelled draft rather than fabricating a complete-looking design.
- **Release constraint**: a workflow that has not been tested against representative data must never be marked ready-to-go-live or activated.

## 版本与更新时间 / Version and update

**中文**：v1.0.0。八项交付物结构与失败用例矩阵自发布起未变。
**English**: v1.0.0. Eight-deliverable structure and failure-case matrix unchanged since publication.

## 变更记录 / Changelog

### 1.0.0

- 首次发布：八项交付物 + 逐节点规格表 + 六类失败用例 + 人工审批约束 + 中英双语说明。

---

## 购买前先看 / Read before purchase

**一次调用交付 / One-call delivery**

- 中文：适用于把线下流程落到 n8n 前的设计评审；输入触发方式、数据口径与失败处理要求，输出节点级规格与测试用例，不代替实机测试，不把未验证的工作流标为可上线 / Use before committing a business process to n8n; accept the trigger, data contract, and failure requirements, and return a node-level specification with test cases — without substituting for real testing or marking an untested workflow production-ready.
- English: n8n Workflow Specification & Handoff
- 输入与输出 / Input and output：按本技能定义提供结构化输入；输出为可执行的结构化结果、清单与验收提示。 / Provide the structured input defined by this skill; the output is an executable structured result, checklist, and acceptance cues.
- 适合 / Best for：需要明确产出、可复核边界、且不想为多个小步骤重复付款的任务。 / Tasks that need a clear, reviewable deliverable without paying separately for every small step.
- 不适合 / Not for：缺失必要字段、要求读取服务器本地路径、要求执行任意脚本或要求绕过平台的请求。 / Requests missing required fields, asking to access server paths, asking to execute arbitrary scripts, or asking to bypass the platform.
- 交付标准 / Acceptance：成功响应返回结构化结果、处理摘要与复核提示；输入不完整时先返回缺失项，不虚构结果。 / A successful response returns structured results, a summary, and review cues; incomplete input returns missing fields instead of invented output.

**示例 / Example**

`POST /v1/pay/skills/n8n-workflow-spec/invoke`

`{"name": "订单入库同步", "trigger": "webhook", "steps": ["接收订单", "校验字段", "写入数据库", "失败告警"], "systems": ["Postgres", "企业微信"]}`

## 使用契约 / Usage contract

| 阶段 / Stage | 用户可见行为 / User-visible behavior |
|---|---|
| 了解 / Discover | 先展示输入、输出、依赖和单价，再开始调用。 |
| 选择 / Choose | 沿用同一请求参数和同一 `Idempotency-Key`。 |
| 支付 / Pay | 未付款时服务端只返回 HTTP 402 与 `Payment-Needed`，不会交付结果。 |
| 使用 / Use | 付款后携带原始 `Payment-Proof` 重试，成功响应带 `Payment-Validation`。 |
| 异常 / Recover | 履约确认失败时用同一凭证重试，不重复扣款或执行。 |

## 售后与满意度 / Satisfaction & recovery

- 只有服务端实现同一订单的 `retry_credit`、幂等和补偿记录时，才能提供一次不重复计费的修正重试。
- 如果尚未实现补偿，只提供问题反馈和人工处理路径，不承诺免费再次调用或自动退款。
- 免费预览、基础能力和付费完整结果必须区分资源或端点；成功交付后可提供自愿打赏，但打赏不影响访问、验收或售后。

A free correction retry is allowed only when the server implements `retry_credit`, idempotency, and compensation records for the same order. Otherwise, provide support feedback without promising a free call or automatic refund.

## 线上收费 API 范围 / Hosted paid API scope

线上范围：按结构化请求产出本技能定义的结果、清单或报告；线上不读取服务器本地路径、不处理买家二进制文件、不执行买家脚本。

The hosted scope returns the result, checklist, or report defined by this skill from a structured request. It does not read server-local paths, process buyer binaries, or execute buyer scripts.

---

## 本次更新 / Version 1.0.5 update

中文：新增可选买方编排示例 买方宿主的支付宝官方组件（probe/pay/complete/retry/status；只输出支付宝官方 CLI 参数，不实现支付、不安装组件、不含密钥），并新增「买方支付操作示例」一节；同步修正「不含任何脚本」的自相矛盾表述。服务地址、Service ID、¥0.10 计费契约与 402 流程保持不变。

English: Added the optional buyer-side orchestration example 买方宿主的支付宝官方组件 (probe/pay/complete/retry/status; it only emits arguments for Alipay's official CLI — no payment implementation, no installs, no keys) and a buyer payment walkthrough section; fixed the self-contradictory "contains no scripts" wording. Service URL, service ID, ¥0.10 billing contract, and the 402 flow are unchanged.

## 已核对的输入示例 / Registered input example

```json
{
  "name": "订单通知",
  "nodes": [
    {
      "type": "webhook",
      "name": "入口"
    },
    {
      "type": "httpRequest",
      "name": "查询订单"
    },
    {
      "type": "set",
      "name": "组装消息"
    }
  ]
}
```
