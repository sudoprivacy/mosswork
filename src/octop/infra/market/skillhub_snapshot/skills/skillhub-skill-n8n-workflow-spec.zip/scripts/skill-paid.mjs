#!/usr/bin/env node
/**
 * SkillPay unified buyer helper, template 1.0.4.
 * Only prepares the official Alipay commands; never pays, verifies a proof,
 * grants a result, installs a component or reads wallet credentials.
 * payment-contract.json binds this package to a verified build manifest.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { parseArgs } from 'node:util';
import { fileURLToPath } from 'node:url';

const ALIPAY_BOT = 'alipay-bot';
const FILE_REQUEST = 'request.json';
const FILE_BILL = 'payment-needed.txt';
const FILE_STATE = 'session.json';
const FILE_SOURCE_PAYLOAD = 'input-payload.json';
const PACKAGE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

class StopError extends Error {
  constructor(message, code = 1) {
    super(message);
    this.code = code;
  }
}

function stop(message, code = 1) {
  throw new StopError(message, code);
}

function parseFlags() {
  const { values, positionals } = parseArgs({
    allowPositionals: true,
    options: {
      url: { type: 'string' },
      'state-dir': { type: 'string' },
      'payload-file': { type: 'string' },
      'session-id': { type: 'string' },
      'intent-summary': { type: 'string' },
      'trade-no': { type: 'string' },
      'out-shake-no': { type: 'string' },
      'confirm-data-transfer': { type: 'boolean', default: false },
      'confirm-payment': { type: 'boolean', default: false },
      'amt-payment-link': { type: 'string' },
      'official-output-file': { type: 'string' },
      'handoff-id': { type: 'string' },
      outcome: { type: 'string' },
      'delivered-resource-file': { type: 'string' },
      'confirm-current-output': { type: 'boolean', default: false },
      'confirm-network-retry': { type: 'boolean', default: false },
      'confirm-ref-expired': { type: 'boolean', default: false },
      'confirm-resource-delivered': { type: 'boolean', default: false },
      'confirm-ack-failed': { type: 'boolean', default: false },
      'confirm-recovery-requested': { type: 'boolean', default: false },
      help: { type: 'boolean', default: false },
    },
  });
  return { command: positionals[0], flags: values };
}

function printUsage() {
  console.log(`SkillPay 买方付费编排（不安装组件、不实现支付、不保存凭证）

  probe     对登记的 HTTPS 服务发起一次原始请求，保存本轮 402 账单
            --state-dir <私有目录> --payload-file <JSON 文件> --confirm-data-transfer [--url <Service URL>]
  pay       用户明确同意后，生成交给宿主 Agent 的官方买方 CLI 参数
            --state-dir <私有目录> --session-id <宿主会话 ID>
            --intent-summary <原始请求：本次业务目的摘要> --confirm-payment
  complete  生成查询原订单并取回资源的官方 CLI 参数
            --state-dir <私有目录> (--trade-no <交易号> | --out-shake-no <查询号>)
  retry     再次生成原订单查询参数；不重新下单或付款
            --state-dir <私有目录> (--trade-no <交易号> | --out-shake-no <查询号>)
  restage   官方 CLI 明确报告引用过期后，为原订单重暂存完全相同的请求体
            --state-dir <私有目录> --confirm-ref-expired --confirm-data-transfer
  ack       仅在官方回执明确失败且用户后续要求恢复时使用
            --state-dir <私有目录> --trade-no <交易号> --confirm-resource-delivered --confirm-ack-failed --confirm-recovery-requested
  record-official  绑定本次实际官方命令对客输出；不验付、不写原文
            --state-dir <私有目录> --handoff-id <本次交接ID> --official-output-file <本次文本>
            --confirm-current-output --outcome <pending/业务观察分类>
  status    只显示脱敏状态，不打印请求体、账单或凭证
            --state-dir <私有目录>

状态目录含原请求与 Payment-Needed；请放在技能包目录之外的私有目录，勿上传或分享。
`);
}

function requireStateDir(flags) {
  if (!flags['state-dir']) stop('缺少 --state-dir；状态必须保存在技能包目录之外的私有目录。');
  const dir = path.resolve(flags['state-dir']);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const canonicalPackage = fs.realpathSync(PACKAGE_DIR);
  const canonicalDir = fs.realpathSync(dir);
  const relative = path.relative(canonicalPackage, canonicalDir);
  const insidePackage = relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
  if (insidePackage) stop('状态目录不能位于技能包内（包括目录链接），避免把请求或账单打进 ZIP。');
  if (process.platform !== 'win32') fs.chmodSync(canonicalDir, 0o700);
  return canonicalDir;
}

function writePrivate(file, data) {
  const temporary = `${file}.${crypto.randomUUID()}.tmp`;
  fs.writeFileSync(temporary, data, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
  try { fs.renameSync(temporary, file); } finally { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); }
}

function parsePayload(fileName) {
  if (!fileName) stop('缺少 --payload-file；请按输入契约准备包外 JSON 文件。', 2);
  const file = path.resolve(fileName);
  if (!fs.existsSync(file)) stop('请求文件不存在。', 2);
  const payload = fs.readFileSync(file, 'utf8');
  let value;
  try { value = JSON.parse(payload); } catch { stop('请求体不是有效 JSON。', 2); }
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length === 0) {
    stop('请求体必须是非空顶层 JSON 对象，按本技能输入章节填写；不使用其他技能的 goal/dataset 模板。', 2);
  }
  if (Object.hasOwn(value, '$ref')) stop('输入文件不能提供他人的暂存引用；仅助手自身生成短引用。', 2);
  // The registered server validates task-specific fields before issuing a bill.
  return payload;
}

let contractCache = null;
function registeredContract() {
  if (contractCache) return contractCache;
  const file = path.join(PACKAGE_DIR, 'payment-contract.json');
  if (!fs.existsSync(file)) stop('缺少本包经核对的 payment-contract.json；停止，不能猜测价格或服务 ID。', 2);
  let value;
  try { value = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { stop('登记支付配置无法解析。', 2); }
  if (value.schemaVersion !== 1 || value.templateVersion !== '1.0.4'
      || typeof value.slug !== 'string' || !/^[a-z0-9][a-z0-9_-]*$/.test(value.slug)
      || typeof value.resource !== 'string' || !/^[a-z0-9][a-z0-9_-]*$/.test(value.resource)
      || value.amount !== '0.10'
      || value.currency !== 'CNY' || typeof value.serviceId !== 'string'
      || !/^API_[A-Z0-9]{16}$/.test(value.serviceId) || typeof value.serviceUrl !== 'string'
      || typeof value.helperSha256 !== 'string' || !/^[a-f0-9]{64}$/.test(value.helperSha256)
      || typeof value.skillSha256 !== 'string' || !/^[a-f0-9]{64}$/.test(value.skillSha256)) stop('登记支付配置缺字段或类型错误；停止，不降级为仅核价。', 2);
  let url;
  try { url = new URL(value.serviceUrl); } catch { stop('登记地址无效。', 2); }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash
      || !/^\/v1\/pay\/(?:skills|tasks)\/[a-z0-9_-]+\/invoke$/.test(url.pathname)) stop('登记地址必须是无附加参数的 HTTPS 收费入口。', 2);
  const digest = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
  if (digest(fileURLToPath(import.meta.url)) !== value.helperSha256
      || digest(path.join(PACKAGE_DIR, 'SKILL.md')) !== value.skillSha256) stop('包文件与核对清单不一致；重新构建并验收，不得静默覆盖。', 2);
  const skill = fs.readFileSync(path.join(PACKAGE_DIR, 'SKILL.md'), 'utf8');
  if (!skill.includes(value.serviceUrl) || !skill.includes(value.serviceId)) stop('包内服务地址或服务 ID 与配置不一致。', 2);
  contractCache = value;return value;
}

function validateServiceUrl(raw, { recovery = false } = {}) {
  const registered = registeredContract();
  const requested = raw || process.env.SKILLPAY_RESOURCE_URL || registered.serviceUrl;
  let url;try { url = new URL(requested); } catch { stop('请求地址无效。', 2); }
  const historical = recovery && Array.isArray(registered.historicalServiceUrls)
    && registered.historicalServiceUrls.includes(url.href)
    && ['fwskillpay-api.cn','47-101-40-133.sslip.io'].includes(url.hostname)
    && url.pathname === new URL(registered.serviceUrl).pathname;
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash
      || url.href !== registered.serviceUrl && !historical) stop('只允许调用本包登记的完整 HTTPS 服务地址。', 2);
  return url.href;
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function writeJson(file, value) {
  writePrivate(file, JSON.stringify(value, null, 2));
}

function loadRequest(stateDir) {
  const file = path.join(stateDir, FILE_REQUEST);
  if (!fs.existsSync(file)) stop(`状态目录缺少 ${FILE_REQUEST}；请先取得本轮账单。`);
  return readJson(file);
}

function loadState(stateDir) {
  const file = path.join(stateDir, FILE_STATE);
  return fs.existsSync(file) ? readJson(file) : {};
}

function saveState(stateDir, state) {
  writeJson(path.join(stateDir, FILE_STATE), state);
}

async function fetchOnce(url, options) {
  return fetch(url, { ...options, signal: AbortSignal.timeout(15000), redirect: 'error' });
}


/**
 * 大载荷先暂存到服务端，换取短时效引用 $ref；之后 probe / pay / complete
 * 全程只传 {"$ref": "..."}（约 40 字节），绕开 Windows 命令行 argv 上限
 * （cmd.exe 约 8KB，CreateProcess 约 32KB）。原文不打印；恢复副本仅保存在包外私有状态目录。
 */
async function stageLargePayload(invokeUrl, payload) {
  const bytes = Buffer.byteLength(payload, 'utf8');
  // Reserve room for URL, headers and shell escaping below Windows cmd's limit.
  const inlineCap = 4096;
  const configured = Number(process.env.SKILLPAY_STAGE_THRESHOLD_BYTES);
  const threshold = Number.isFinite(configured) && configured > 0 ? Math.min(configured, inlineCap) : inlineCap;
  const serverCap = Math.min(Number(process.env.SKILLPAY_STAGE_MAX_BYTES) || 8 * 1024 * 1024, 8 * 1024 * 1024);
  if (bytes > serverCap) stop(`请求体 ${bytes} 字节，超过暂存上限 ${serverCap} 字节。`, 2);
  if (bytes <= threshold) return { payload, ref: null, bytes };
  if (process.env.SKILLPAY_DISABLE_STAGE === '1') {
    if (bytes > inlineCap) stop('大载荷需要同域暂存；暂存已禁用，停止，不能放宽环境变量绕过命令行上限。', 2);
    return { payload, ref: null, bytes };
  }
  const stageUrl = invokeUrl.replace(/\/invoke\/?$/, '/stage');
  if (stageUrl === invokeUrl) stop('服务地址没有同域暂存入口，不能发送大载荷到命令行。', 2);
  try {
    const response = await fetch(stageUrl, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: payload,
      signal: AbortSignal.timeout(60000), redirect: 'error',
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const ref = data && typeof data.$ref === 'string' ? data.$ref : null;
    if (!ref || !/^stg_[A-Za-z0-9_-]{16,64}$/.test(ref)) throw new Error('暂存响应没有有效的短引用');
    const compact = JSON.stringify({ $ref: ref });
    console.log(`大载荷已暂存：${bytes} 字节 → 短引用（CLI 传参 ${Buffer.byteLength(compact, 'utf8')} 字节）。`);
    if (data.expiresAt) console.log(`暂存有效期至 ${data.expiresAt}；过期后先核查原订单，付款后不得重新建单。`);
    return { payload: compact, ref, bytes };
  } catch (error) {
    // No fallback that could recreate WinError 206 or execute unpaid local work.
    stop(`同域暂存失败，停止付款参数生成：${String(error?.message || error)}。先核查暂存服务，再重试经修正的新请求。`, 2);
  }
}

function validateCheckoutSummary(value, requestUrl) {
  validateServiceUrl(requestUrl);
  const c = registeredContract();
  const required = {
    amount: 'string', currency: 'string', out_trade_no: 'string',
    resource_id: 'string', service_id: 'string', pay_before: 'string',
  };
  for (const [field, type] of Object.entries(required)) {
    if (!value || typeof value[field] !== type || !value[field].trim()) {
      stop(`公开结算摘要缺字段或类型错误：${field}（预期 ${type}）。不解码付款材料来补全。`, 2);
    }
  }
  if (value.amount !== c.amount || value.currency !== c.currency) stop('公开结算摘要金额或币种与登记不一致；停止，不付款。', 2);
  if (!/^[A-Za-z0-9_.-]{1,128}$/.test(value.out_trade_no)) stop('公开结算摘要商户订单号格式错误。', 2);
  if (value.resource_id !== c.resource) stop('公开结算摘要 resource_id 与登记不一致。', 2);
  if (value.service_id !== c.serviceId) stop('公开结算摘要 service_id 与登记不一致。', 2);
  const expires = value.pay_before;
  if (!Number.isFinite(Date.parse(expires)) || Date.parse(expires) <= Date.now()) stop('公开结算摘要有效期错误或已过期。', 2);
  return { amount: value.amount, currency: value.currency, merchantOrderNo: value.out_trade_no,
    resourceId: value.resource_id, serviceId: value.service_id,
    resourceChecked: true, serviceIdChecked: true, payBefore: expires,
    ...(typeof value.requestId === 'string' && /^[A-Za-z0-9_.-]{1,128}$/.test(value.requestId) ? { requestId: value.requestId } : {}) };
}

async function readCheckoutSummary(response) {
  const limit = 32768;
  let text = '';
  if (response.body?.getReader) {
    const reader = response.body.getReader(); let bytes = 0; const chunks = [];
    try {
      for (;;) { const item = await reader.read(); if (item.done) break;
        bytes += item.value.byteLength; if (bytes > limit) { await reader.cancel(); stop('公开结算摘要超过 32KB；停止。', 2); } chunks.push(Buffer.from(item.value)); }
      text = Buffer.concat(chunks).toString('utf8');
    } finally { reader.releaseLock(); }
  } else { text = await response.text(); if (Buffer.byteLength(text) > limit) stop('公开结算摘要超过 32KB；停止。', 2); }
  try { return JSON.parse(text); } catch { stop('402 缺少可核对的公开 JSON 结算摘要；停止，不解码账单或链接。', 2); }
}

function validOpaqueLink(value) {
  // A combined/repeated Header is ambiguous. Never split or decode it.
  if (typeof value !== 'string' || !value || Buffer.byteLength(value, 'utf8') > 8192 || /[\s,]/.test(value)) stop('amtPaymentLink 为空、过长或不唯一；停止，不能降级使用另一份账单。', 2);
  let url; try { url = new URL(value); } catch { stop('amtPaymentLink 格式错误。', 2); }
  if (url.protocol !== 'https:' || url.username || url.password) stop('amtPaymentLink 必须是无账户口令的 HTTPS 地址。', 2);
  return value;
}

function requestFingerprint(request) {
  return crypto.createHash('sha256').update(JSON.stringify([request.url, request.method, request.idemKey, request.originalPayloadSha256])).digest('hex');
}

function issueHandoff(stateDir, state, request, kind, args) {
  const handoff = { id: crypto.randomUUID(), kind, requestFingerprint: requestFingerprint(request), createdAt: new Date().toISOString() };
  saveState(stateDir, { ...state, lastOfficialHandoff: handoff });
  console.log(JSON.stringify({ executable: ALIPAY_BOT, workingDirectory: state.cliWorkingDirectory || stateDir,
    args, handoffId: handoff.id, paymentStatus: 'not_verified_by_this_helper',
    instruction: '宿主以参数数组实际执行官方 CLI，完整显示本次官方文本及全部 MEDIA；将本次对客文本保存到包外私有文件，再用 record-official 绑定本 handoffId。参数准备不代表付款、交付或到账。' }, null, 2));
}

function cmdRecordOfficial(flags) {
  if (!flags['confirm-current-output']) stop('只能记录宿主刚执行本次 handoff 的真实官方输出，不能用用户粘贴、旧日志或其他订单代替。', 2);
  const dir = requireStateDir(flags), request = loadRequest(dir), state = loadState(dir), h = state.lastOfficialHandoff;
  validateServiceUrl(request.url, { recovery: true });
  const networkRetry = flags['confirm-network-retry'] && state.officialObservation?.outcome === 'network_failed' && !h?.retryRecorded;
  if (!h || h.id !== flags['handoff-id'] || h.recordedAt && !networkRetry || h.requestFingerprint !== requestFingerprint(request)) stop('handoffId 缺失、过期、已记录或不属于本请求；停止。', 2);
  const file = flags['official-output-file'];
  if (!file || !fs.existsSync(file) || !fs.statSync(file).isFile() || fs.statSync(file).size > 512 * 1024) stop('需要本次官方对客文本文件（最多 512KB）。', 2);
  const canonicalOutput = fs.realpathSync(file);
  const outputRelative = path.relative(fs.realpathSync(PACKAGE_DIR), canonicalOutput);
  if (outputRelative === '' || !outputRelative.startsWith(`..${path.sep}`) && outputRelative !== '..' && !path.isAbsolute(outputRelative)) stop('官方对客文本须保存在包外私有目录。', 2);
  const raw = fs.readFileSync(file, 'utf8');
  if (!raw.trim() || raw.trim().startsWith('{') || raw.trim().startsWith('[')) stop('官方输出必须是本次对客文本，不能从原始 JSON 或诊断日志猜测订单。', 2);
  const labels = { outShakeNo: new Set(), tradeNo: new Set() };
  for (const line of raw.split(/\r?\n/)) {
    const normalized = line.trim().replace(/^[-*]\s+/, '').replace(/\*\*/g, '');
    const m = /^(订单号|查询单号|交易号)\s*[：:]\s*([A-Za-z0-9_.-]+)\s*$/.exec(normalized);
    if (!m) continue;
    if (m[1] === '交易号') {
      if (!/^[A-Za-z0-9_.-]{1,128}$/.test(m[2])) stop('官方交易号格式错误。', 2);
      labels.tradeNo.add(m[2]);
    } else if (/^\d{10}8282\d{18}$/.test(m[2])) labels.outShakeNo.add(m[2]);
  }
  if (labels.outShakeNo.size > 1 || labels.tradeNo.size > 1) stop('同次对客文本含多个不同订单标识；停止拼接。', 2);
  const outcome = flags.outcome || 'unknown';
  if (!['pending', 'resource_delivered', 'ack_failed', 'reference_expired', 'business_failed', 'network_failed', 'unknown', 'ack_finished'].includes(outcome)) stop('不支持的官方观察分类。', 2);
  const prior = state.officialObservation || {};
  const outShakeNo = [...labels.outShakeNo][0], tradeNo = [...labels.tradeNo][0];
  if (!outShakeNo && !tradeNo && !(h.kind !== 'pay' && (prior.outShakeNo || prior.tradeNo)) && outcome !== 'network_failed') stop('本次官方输出没有有效查询标识，不能建立原订单绑定。', 2);
  for (const [key, value] of [['outShakeNo', outShakeNo], ['tradeNo', tradeNo]]) {
    if (value && prior[key] && value !== prior[key]) stop('本次官方标识与已绑定原单冲突；停止。', 2);
  }
  const delivered = ['resource_delivered', 'ack_failed'].includes(outcome);
  let resourceSha256;
  if (delivered) {
    const resourceFile = flags['delivered-resource-file'];
    if (!flags['confirm-resource-delivered'] || !resourceFile || !fs.existsSync(resourceFile) || !fs.statSync(resourceFile).isFile() || fs.statSync(resourceFile).size > 8 * 1024 * 1024 || !fs.readFileSync(resourceFile).toString('utf8').trim()) stop('交付观察须有本次官方非空资源文件（最多 8MB），并确认已交付用户。', 2);
    const relative = path.relative(fs.realpathSync(PACKAGE_DIR), fs.realpathSync(resourceFile));
    if (relative === '' || !relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative)) stop('官方资源文件须保存在包外私有目录。', 2);
    resourceSha256 = crypto.createHash('sha256').update(fs.readFileSync(resourceFile)).digest('hex');
  }
  if (outcome === 'ack_failed' && (!flags['confirm-ack-failed'] || !(tradeNo || prior.tradeNo))) stop('回执失败须来自同次真实输出并有原交易号。', 2);
  if (h.kind === 'ack' && !['ack_finished', 'network_failed', 'unknown'].includes(outcome)) stop('回执输出不能当作新付款或资源观察。', 2);
  const at = new Date().toISOString();
  saveState(dir, { ...state, lastOfficialHandoff: { ...h, recordedAt: at, ...(networkRetry ? { retryRecorded: true } : {}) },
    officialObservation: { ...prior, ...(outShakeNo ? { outShakeNo } : {}), ...(tradeNo ? { tradeNo } : {}),
      outcome, sourceHandoffId: h.id, sourceCommand: h.kind, observedAt: at,
      outputSha256: crypto.createHash('sha256').update(raw).digest('hex'),
      ...(delivered ? { resourceDelivered: true, resourceSha256 } : {}), ackFailed: outcome === 'ack_failed' } });
  console.log('已绑定本次官方标识和输出摘要；分类为宿主观察，不是本助手的验付、履约或到账证明。');
}

async function cmdProbe(flags) {
  if (!flags['confirm-data-transfer']) stop('缺少 --confirm-data-transfer：须先向用户说明接收方、处理目的、输入范围、暂存期限与本地 CLI 数据边界，并取得明确同意。', 2);
  const stateDir = requireStateDir(flags);
  if (fs.existsSync(path.join(stateDir, FILE_REQUEST))) stop('该状态目录已记录原请求；不得再次 probe 或重新暂存。未付款异常先核查，付款后仅 complete/retry 查询原订单。', 2);
  try { fs.writeFileSync(path.join(stateDir, 'probe.lock'), new Date().toISOString(), { flag: 'wx', mode: 0o600 }); }
  catch { stop('本状态目录已有一次 probe 操作；停止并核对原请求，不能并发开单。', 2); }

  const url = validateServiceUrl(flags.url);
  if (registeredContract().businessReady !== true) stop('登记服务的业务交付尚未验证，暂不创建收费单。', 2);
  const originalPayload = parsePayload(flags['payload-file']);
  const originalPayloadSha256 = crypto.createHash('sha256').update(originalPayload, 'utf8').digest('hex');
  const stagedPayload = await stageLargePayload(url, originalPayload);
  const payload = stagedPayload.payload;
  if (stagedPayload.ref) writePrivate(path.join(stateDir, FILE_SOURCE_PAYLOAD), originalPayload);
  const method = 'POST';
  const requestFile = path.join(stateDir, FILE_REQUEST);
  const billFile = path.join(stateDir, FILE_BILL);
  const previousState = loadState(stateDir);
  let request;

  if (fs.existsSync(requestFile)) {
    request = loadRequest(stateDir);
    if (request.url !== url || request.method !== method || request.payload !== payload) {
      stop('该状态目录已绑定另一请求；每个订单请使用新的私有状态目录。');
    }
    if (fs.existsSync(billFile)) stop('本轮账单已保存；不要再次 probe。请继续 pay 或查询原订单。');
    if (previousState.probeStatus === 429) stop('此状态目录已记录 HTTP 429。停止本批次，不得再次 probe；请记录并等待平台恢复。', 2);
    if (previousState.probeStartedAt) stop('此状态目录已发起 probe；即使未收到响应，也不得重放或新建订单。先核查原请求状态。', 2);
    if (previousState.probeStatus !== undefined) stop(`此状态目录已收到 HTTP ${previousState.probeStatus}；不重复发起请求。按状态记录处理，必要时使用新的状态目录提交经修正的新请求。`, 2);
  } else {
    request = {
      url,
      method,
      idemKey: `${registeredContract().resource}-${crypto.randomUUID()}`,
      payload,
      originalPayloadSha256,
      createdAt: new Date().toISOString(),
    };
    writeJson(requestFile, request);
  }

  saveState(stateDir, { ...loadState(stateDir), probeStartedAt: new Date().toISOString() });
  let response;
  try {
    response = await fetchOnce(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Idempotency-Key': request.idemKey,
      },
      body: payload,
    });
  } catch (error) {
    saveState(stateDir, { ...loadState(stateDir), probeStatus: 'unknown', probeAt: new Date().toISOString() });
    stop(`网络请求结果未知：${error?.cause?.code || error?.message || 'network error'}。此状态目录已锁定，勿重复 probe；先检查原订单与服务端日志。`, 2);
  }

  if (response.status === 429) {
    saveState(stateDir, { ...loadState(stateDir), probeStatus: 429, probeAt: new Date().toISOString() });
    stop('服务返回 HTTP 429。立即停止，不自动重试；按平台要求记录并等待。', 2);
  }
  if (response.status !== 402) {
    saveState(stateDir, { ...loadState(stateDir), probeStatus: response.status, probeAt: new Date().toISOString() });
    if (response.status === 200) {
      // No payment proof was sent by probe; fail closed on an unexpected 200.
      stop('未付款 probe 意外返回 HTTP 200（未收到 402 账单）；按服务契约异常停止，不读取或展示响应体。用户拒绝付款或取消时停止付费服务，不进行本地代做或任何免费回退。', 2);
    }
    if (response.status === 400) stop('服务返回 HTTP 400；输入无效且不应创建账单，请修正请求后使用新的状态目录。', 2);
    stop(`服务返回 HTTP ${response.status}，未进入付款流程；不要重复付款或猜测结果。`, 2);
  }

  const link = response.headers.get('amtPaymentLink');
  const bill = response.headers.get('payment-needed');
  // Presence of an empty/ambiguous link also stops; never fall back to -f.
  if (link === null && !bill) stop('402 没有本次付款材料；停止。', 2);
  if (link !== null) validOpaqueLink(link);
  const checkout = validateCheckoutSummary(await readCheckoutSummary(response), request.url);
  const material = link !== null ? { kind: 'link', sha256: crypto.createHash('sha256').update(link).digest('hex') }
    : { kind: 'bill', sha256: crypto.createHash('sha256').update(bill).digest('hex') };
  if (link === null) writePrivate(billFile, bill); // opaque, never decoded or rewritten
  saveState(stateDir, { ...loadState(stateDir), stateVersion: '1.0.4', probeStatus: 402,
    checkoutSummary: checkout, paymentMaterial: material, billReceivedAt: new Date().toISOString() });
  console.log(JSON.stringify({ status: '402_received_not_paid', amount: checkout.amount, currency: checkout.currency,
    resourceId: checkout.resourceId, serviceId: checkout.serviceId, payBefore: checkout.payBefore,
    resourceChecked: checkout.resourceChecked, serviceIdChecked: checkout.serviceIdChecked,
    materialKind: material.kind, ...(link !== null ? { amtPaymentLink: link } : {}),
    next: '已有本次金额授权则立即准备并执行官方 buyer-pay；链接只在当前宿主内存中透传，不写付款材料文件。公开摘要不是账单验签结果。' }));
}

function commonResourceArgs(request) {
  if (Buffer.byteLength(request.payload, 'utf8') > 4096) stop('原请求尚未转换为短引用，不能交给官方 CLI；核查原订单，不得重复付款。', 2);
  return [
    '-r', request.url,
    '-m', request.method,
    '-d', request.payload,
    '-H', 'Content-Type:application/json',
    '-H', `Idempotency-Key:${request.idemKey}`,
  ];
}

async function cmdPay(flags) {
  const dir = requireStateDir(flags), request = loadRequest(dir), state = loadState(dir);
  validateServiceUrl(request.url);
  if (!flags['confirm-payment']) stop('需要已有的本次金额授权；该标志不是要求二次确认，也不能用金额一致代替授权。', 2);
  if (state.stateVersion !== '1.0.4' || state.probeStatus !== 402 || !state.checkoutSummary || !state.paymentMaterial) stop('缺少本版本次付款材料；旧单须按官方原单恢复，不能新付。', 2);
  if (state.payHandoffPreparedAt) stop('付款已交接且启动结果不可推断，只核对原单。', 2);
  const c = registeredContract();
  if (state.checkoutSummary.amount !== c.amount || state.checkoutSummary.currency !== c.currency) stop('公开价格与登记不一致。', 2);
  if (state.checkoutSummary.resourceId !== c.resource || state.checkoutSummary.serviceId !== c.serviceId) stop('本次摘要资源或服务 ID 与当前登记不一致；停止，不付款。', 2);
  if (state.checkoutSummary.payBefore && Date.parse(state.checkoutSummary.payBefore) <= Date.now()) stop('公开截止时间已过期，停止，不重发付款。', 2);
  const session = flags['session-id'];
  // Numeric runtime IDs are valid. Detect known order IDs by identity,
  // not by length alone; the host must use the official metadata priority.
  // Official order/query numbers are 32 digits with 8282 at positions 11-14
  // and are query-only, so that shape is never a legal sessionId even when
  // it belongs to another bill.
  const knownOrderIds = [state.checkoutSummary.merchantOrderNo, state.officialObservation?.tradeNo, state.officialObservation?.outShakeNo];
  if (!session || !session.trim() || session.length > 256 || /^https?:/.test(session)
      || /^\d{10}8282\d{18}$/.test(session) || knownOrderIds.includes(session)) stop('会话标识缺失或与本单已知订单/URL混用；按官方运行时优先级取值。', 2);
  const intent = flags['intent-summary']?.trim();
  if (!intent?.startsWith('原始请求：') || !intent.slice(5).trim() || intent.length > 1024) stop('须提供本次业务目标摘要，格式为原始请求：xxx，最多 1024 字符。', 2);
  let materialArgs;
  if (state.paymentMaterial.kind === 'link') {
    const link = validOpaqueLink(flags['amt-payment-link']);
    if (crypto.createHash('sha256').update(link).digest('hex') !== state.paymentMaterial.sha256) stop('付款链接与本次原值不一致。', 2);
    materialArgs = ['--amt-payment-link', link];
  } else {
    if (flags['amt-payment-link']) stop('本次为账单分支，不能混入付款链接。', 2);
    const file = path.join(dir, FILE_BILL);
    if (!fs.existsSync(file) || crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') !== state.paymentMaterial.sha256) stop('原账单缺失或发生变动；停止。', 2);
    materialArgs = ['-f', file];
  }
  const args = ['402-buyer-pay', '--session-id', session, ...materialArgs, ...commonResourceArgs(request), '--intent-summary', intent];
  fs.writeFileSync(path.join(dir, 'pay-handoff.lock'), new Date().toISOString(), { flag: 'wx', mode: 0o600 });
  const updated = { ...state, cliWorkingDirectory: fs.realpathSync(process.cwd()), payHandoffPreparedAt: new Date().toISOString() };
  issueHandoff(dir, updated, request, 'pay', args);
}

async function cmdRestage(flags) {
  if (!flags['confirm-ref-expired']) {
    stop('仅在本次官方 CLI 明确报告 STAGE_REF_NOT_FOUND / 引用已过期时重暂存；这会再次向同一服务发送原始请求体。', 2);
  }
  if (!flags['confirm-data-transfer']) {
    stop('重暂存会再次发送原始请求体；缺少 --confirm-data-transfer，停止。', 2);
  }
  const stateDir = requireStateDir(flags);
  const request = loadRequest(stateDir);
  validateServiceUrl(request.url, { recovery: true });
  const state = loadState(stateDir);
  if (!flags['confirm-recovery-requested'] || state.officialObservation?.outcome !== 'reference_expired') stop('须有已绑定的本次官方引用过期观察及用户后续恢复请求。', 2);
  if (state.probeStatus !== 402 || !state.payHandoffPreparedAt) {
    stop('仅已取得 402 且已准备原订单付款参数后，才允许恢复暂存引用；不会创建新账单。', 2);
  }
  if ((Number(state.stageRecoveryCount) || 0) >= 1) {
    stop('同一订单的暂存引用恢复次数已达上限；停止继续传输，请核查原订单或联系服务维护者。', 2);
  }
  try { fs.writeFileSync(path.join(stateDir, 'restage.lock'), new Date().toISOString(), { flag: 'wx', mode: 0o600 }); }
  catch { stop('本单已经尝试恢复暂存引用，不并发重传。', 2); }
  const sourceFile = path.join(stateDir, FILE_SOURCE_PAYLOAD);
  if (!fs.existsSync(sourceFile)) {
    stop('私有状态目录没有原始大载荷副本；停止，不能用占位引用或新请求替代原订单。', 2);
  }
  const originalPayload = fs.readFileSync(sourceFile, 'utf8');
  const digest = crypto.createHash('sha256').update(originalPayload, 'utf8').digest('hex');
  if (!request.originalPayloadSha256 || digest !== request.originalPayloadSha256) {
    stop('原始请求体校验不匹配；停止，不更改原订单。', 2);
  }
  const stagedPayload = await stageLargePayload(request.url, originalPayload);
  if (!stagedPayload.ref) stop('原始请求不需要暂存；停止，不更改订单。', 2);
  writeJson(path.join(stateDir, FILE_REQUEST), { ...request, payload: stagedPayload.payload });
  saveState(stateDir, {
    ...state,
    stageRecoveryAt: new Date().toISOString(),
    stageRecoveryCount: (state.stageRecoveryCount || 0) + 1,
    stageRecoveryStatus: 'new_ref_ready_same_payload_same_idempotency_key',
  });
  console.log('原始请求体 SHA-256 匹配，已为同一请求和原幂等键生成新引用。没有 probe、没有创建账单；接下来只查询/恢复原订单。');
}

async function queryOriginalOrder(flags, action) {
  const dir = requireStateDir(flags), request = loadRequest(dir), state = loadState(dir);
  validateServiceUrl(request.url, { recovery: true });
  const o = state.officialObservation;
  if (!o?.outputSha256 || !o.sourceHandoffId || state.lastOfficialHandoff?.recordedAt === undefined) stop('原单尚未绑定本次官方输出；先 record-official，不猜号码。', 2);
  if (!['pending', 'network_failed', 'reference_expired'].includes(o.outcome)) stop('官方观察要求停止：成功交付、业务失败、资源为空或未知状态不能继续查询。', 2);
  if (o.outcome === 'network_failed' && (state.networkQueryRetries || 0) >= 1) stop('网络失败查询已重试一次；停止。', 2);
  if (flags['out-shake-no'] && flags['trade-no']) stop('不能混用查询号和交易号。', 2);
  if (flags['out-shake-no'] && flags['out-shake-no'] !== o.outShakeNo || flags['trade-no'] && flags['trade-no'] !== o.tradeNo) stop('参数与已绑定原单不一致。', 2);
  // Official priority: a valid Shake identifier precedes trade-no.
  const identity = o.outShakeNo ? ['--out-shake-no', o.outShakeNo] : o.tradeNo ? ['-t', o.tradeNo] : null;
  if (!identity) stop('没有本次官方查询标识，不能自动恢复资源。', 2);
  const args = ['402-query-payment-status', ...identity, ...commonResourceArgs(request)];
  issueHandoff(dir, { ...state, ...(o.outcome === 'network_failed' ? { networkQueryRetries: (state.networkQueryRetries || 0) + 1 } : {}) }, request, action, args);
}

async function cmdComplete(flags) {
  return queryOriginalOrder(flags, 'complete');
}

async function cmdRetry(flags) {
  return queryOriginalOrder(flags, 'retry');
}

async function cmdAck(flags) {
  const dir = requireStateDir(flags), request = loadRequest(dir), state = loadState(dir), o = state.officialObservation;
  if (!flags['confirm-recovery-requested'] || !o?.ackFailed || !o.resourceDelivered || !o.resourceSha256 || !o.outputSha256 || !o.tradeNo || !['pay','complete','retry'].includes(o.sourceCommand)) stop('独立 ACK 仅限已绑定同次官方回执失败、非空资源已交付和用户后续恢复请求。', 2);
  if (flags['trade-no'] && flags['trade-no'] !== o.tradeNo) stop('ACK 交易号与原单不一致。', 2);
  if (state.fulfillmentAckHandoffIssuedAt) stop('本单已交接独立 ACK，不重复发出。', 2);
  fs.writeFileSync(path.join(dir, 'ack-handoff.lock'), new Date().toISOString(), { flag: 'wx', mode: 0o600 });
  issueHandoff(dir, { ...state, fulfillmentAckHandoffIssuedAt: new Date().toISOString() }, request, 'ack', ['402-buyer-fulfillment-ack', '-t', o.tradeNo]);
}

function cmdStatus(flags) {
  const stateDir = requireStateDir(flags);
  const requestFile = path.join(stateDir, FILE_REQUEST);
  if (!fs.existsSync(requestFile)) stop(`状态目录中还没有请求记录；请先运行 probe。`);
  const request = loadRequest(stateDir);
  const state = loadState(stateDir);
  console.log(`服务：${request.url}`);
  console.log(`方法：${request.method}`);
  console.log(`幂等键：${request.idemKey}`);
  console.log(`Payment-Needed：${fs.existsSync(path.join(stateDir, FILE_BILL)) ? '已保存（原值）' : '尚未保存'}`);
  console.log(`probe 状态：${state.probeStatus ?? '未知'}`);
  console.log(`付款参数已准备（待宿主执行官方 CLI）：${state.payHandoffPreparedAt ? '是' : '否'}${state.payResumeIssuedAt ? '；resume 参数已输出过一次' : ''}`);
  console.log(`付款 CLI 参数已交给宿主 Agent：${(state.payHandoffIssuedAt || state.payHandoffPreparedAt) ? '是；支付结果未知，查官方 CLI/原订单' : '否'}`);
  console.log(`最近查单参数交接：${state.completeHandoffIssuedAt || state.retryHandoffIssuedAt || '无'}`);
  console.log(`买方履约回执参数已交接：${state.fulfillmentAckHandoffIssuedAt ? '是；结果以官方 CLI 为准' : '否'}`);
  console.log('为保护隐私，状态回读不显示请求体、账单内容、会话 ID 或 Payment-Proof。');
}

export { registeredContract, validateServiceUrl, validateCheckoutSummary, parsePayload };

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
const { command, flags } = parseFlags();
if (flags.help || !command) {
  printUsage();
  process.exitCode = flags.help || command ? 0 : 1;
} else {
  const handlers = { probe: cmdProbe, pay: cmdPay, restage: cmdRestage, complete: cmdComplete, retry: cmdRetry, ack: cmdAck, status: cmdStatus, 'record-official': cmdRecordOfficial };
  const handler = handlers[command];
  if (!handler) {
    console.error(`错误：未知子命令 ${command}。可用：probe / pay / record-official / restage / complete / retry / ack / status`);
    process.exitCode = 1;
  } else {
    let operationLock;
    try {
      const dir = requireStateDir(flags); operationLock = path.join(dir, 'operation.lock');
      try { fs.writeFileSync(operationLock, String(process.pid), { flag: 'wx', mode: 0o600 }); } catch { operationLock = null; stop('本单已有并发操作；停止，不覆盖状态。', 2); }
      await handler(flags);
    } catch (error) {
      if (error instanceof StopError) {
        console.error(`停止：${error.message}`);
        process.exitCode = error.code;
      } else {
        console.error(`停止：${error?.message || 'unexpected error'}`);
        process.exitCode = 1;
      }
    } finally { if (operationLock && fs.existsSync(operationLock)) fs.unlinkSync(operationLock); }
  }
}
}
