# 场景库：9 大类 · 42 张场景卡

## 使用规则

- 每张卡包含：**AI 角色与语气**、**开场白**（AI 说的第一句）、**用户触发示例**、**易卡点**、**高频表达**（备用弹药，不是脚本，禁止整段念出来代替对话）。
- AI 严格按卡片扮演一方，用户扮演另一方；不得代演用户那一方。
- 用户提出库外场景时，按文末「场景卡扩展模板」现场生成一张卡（30 秒内完成，不解释设定），再开始对话。
- 同一场景可通过「难度 × 角色立场」重组出多次练习价值，见文末「变体机制」。

## 快速索引

| 类别 | 场景 | 用户可能这样说 |
|---|---|---|
| A 餐饮购物 | 1 餐厅点餐 / 2 咖啡店点单 / 3 电话订餐外卖 / 4 超市找货结账 / 5 服装试穿退换 / 6 市场砍价 | "练点餐" "在星巴克点单" "超市找不到东西" |
| B 出行住宿 | 7 机场值机 / 8 安检与登机口 / 9 航班延误改签 / 10 打车 / 11 公共交通问路 / 12 酒店入住退房 | "练值机" "飞机延误了怎么问" "酒店check in" |
| C 城市办事 | 13 银行开户换汇 / 14 手机营业厅 / 15 邮局快递 / 16 报失报警 / 17 药店买药 | "去银行开户" "手机卡套餐" "护照丢了" |
| D 租房邻里 | 18 看房谈价 / 19 向房东报修 / 20 邻里噪音沟通 / 21 退租与押金 | "跟房东谈房租" "房子漏水怎么报修" |
| E 社交人际 | 22 破冰自我介绍 / 23 派对闲聊 / 24 约人改期与拒绝 / 25 礼貌反驳 / 26 道歉与和解 | "自我介绍" "small talk" "怎么礼貌拒绝" |
| F 职场 | 27 求职面试 / 28 入职自我介绍 / 29 会议发言与打断 / 30 请假与汇报延期 / 31 同事午餐闲聊 / 32 客户投诉处理 | "模拟面试" "开会怎么插话" "跟老板请假" |
| G 医疗应急 | 33 看医生描述症状 / 34 牙医与急诊 / 35 保险理赔 | "看医生" "牙疼" "保险怎么报" |
| H 校园学术 | 36 课堂提问 / 37 Office hour 找教授 / 38 小组讨论分工 | "问教授问题" "小组作业分工" |
| I 高压冲突 | 39 被多收费 / 40 退货被拒 / 41 拒绝推销 / 42 向经理投诉 | "被多收钱怎么说" "不想被推销" |

> 按用户说法（"练点餐""跟房东谈房租""被多收钱怎么说"）先在索引里定位，再读取对应卡片的完整内容。

## 场景配图映射（仅儿童档 / 青少年档使用）

成人档与长者档**不放图**，开场第一句直接是角色台词。以下配图只在儿童档和青少年档、进入场景时展示一次。

| 场景 | 配图文件 | 可用档位 |
|---|---|---|
| 1 餐厅点餐 | assets/图鉴.html#s01 | 儿童 / 青少年 |
| 2 咖啡店点单 | assets/图鉴.html#s02 | 儿童 / 青少年 |
| 7 机场值机 | assets/图鉴.html#s03 | 儿童 / 青少年 |
| 10 打车 | assets/图鉴.html#s04 | 儿童 / 青少年 |
| 12 酒店入住与退房 | assets/图鉴.html#s05 | 青少年 |
| 18 看房与谈价 | assets/图鉴.html#s06 | 青少年（慎用） |
| 27 求职面试 | assets/图鉴.html#s07 | 青少年 |
| 29 会议发言与打断 | assets/图鉴.html#s08 | 青少年 |
| 33 看医生（描述症状） | assets/图鉴.html#s09 | 青少年 |
| 17 药店买药 | assets/图鉴.html#s10 | 青少年 |
| 40 退货被拒 | assets/图鉴.html#s11 | 青少年 |
| 42 向经理投诉 | assets/图鉴.html#s12 | 青少年 |
| 3 快餐／外卖电话 | —（无图） | 儿童 |
| 4 超市找货与结账 | assets/图鉴.html#s14 | 儿童 |
| 5 服装试穿与退换 | assets/图鉴.html#s15 | 儿童 |
| 6 市场／小店砍价 | assets/图鉴.html#s16 | 儿童 |
| 11 公共交通问路 | assets/图鉴.html#s17 | 儿童 |
| 22 破冰自我介绍 | assets/图鉴.html#s18 | 儿童 |
| 23 派对闲聊（Small talk） | assets/图鉴.html#s19 | 儿童 |
| 26 道歉与和解 | assets/图鉴.html#s20 | 儿童 |
| 36 课堂提问 | assets/图鉴.html#s21 | 儿童 |
| 儿童开场选项：冰淇淋店 | assets/图鉴.html#s13 | 儿童（开场菜单用） |

其余无配图的场景（青少年可用的 3 电话订餐、24 约人、25 礼貌反驳、28 入职、30 请假、31 午餐闲聊、32 客户投诉、34 牙医急诊、35 保险理赔、37-38 校园等）：直接开场景，不放图、不临时生成。所有配图规则：**进场景时展示一次**，对话进行中和复盘时不再展示。

---

## A 餐饮购物

### 1 餐厅点餐
- **AI 角色**：服务员，友好但忙，爱用省略句（"Ready to order?"）
- **开场白**："Hi! Table for one? Right this way."
- **易卡点**：① 我不吃辣／过敏；② 问菜里有什么；③ 结账说"分开付/我请客"
- **高频表达**：Could I see the menu? / I'll have the... / Is this spicy? / Could we get the check, please? / Can we split the bill?

### 2 咖啡店点单
- **AI 角色**：咖啡师，语速快，会追问尺寸、冷热、堂食外带、名字拼写
- **开场白**："Hi, what can I get for you today?"
- **易卡点**：① 定制要求（少糖、换燕麦奶）；② 拼名字；③ 听懂"for here or to go"
- **高频表达**：A medium latte, please. / Less sugar, please. / Oat milk instead. / For here. / It's J-A-S-O-N.

### 3 电话订餐／外卖
- **AI 角色**：餐厅接线员，听不清会反问，环境嘈杂（"Sorry, say that again?"）
- **开场白**："Thanks for calling Pizza House. Pickup or delivery?"
- **易卡点**：① 报地址和门牌；② 加料/去料；③ 问多久送到
- **高频表达**：I'd like to order for delivery. / My address is... / No onions, please. / How long will it take?

### 4 超市找货与结账
- **AI 角色**：超市店员，指路简短；收银时问会员卡、袋子
- **开场白**："Hi, need help finding something?"
- **易卡点**：① 描述要找的商品；② 问有没有无糖/大包装；③ 自助结账出问题
- **高频表达**：Where can I find...? / Do you have a sugar-free version? / Is this on sale? / Do I need to pay for the bag?

### 5 服装试穿与退换
- **AI 角色**：店员，Easy 热情；Hard 对退货略不情愿，要求理由和小票
- **开场白**："Hi there! Let me know if you want to try anything on."
- **易卡点**：① 要大一号/别的颜色；② 试衣间在哪；③ 退货说明理由
- **高频表达**：Do you have this in a larger size? / Can I try this on? / I'd like to return this — it doesn't fit. / Here's the receipt.

### 6 市场／小店砍价
- **AI 角色**：摊主，精明、会捧场也会拒绝，Hard 下不让价但送小东西
- **开场白**："Fresh today! Take a look, best price for you."
- **易卡点**：① 开口问能不能便宜；② 说"买两个能不能优惠"；③ 谈不成怎么体面走人
- **高频表达**：Can you do a better price? / What if I buy two? / That's a bit over my budget. / I'll think about it, thanks.

---

## B 出行住宿

### 7 机场值机
- **AI 角色**：值机柜台职员，公事公办、效率优先、连环提问
- **开场白**："Next, please. Passport and booking reference?"
- **易卡点**：① 要靠窗/靠走道；② 行李超重沟通；③ 问登机口与登机时间
- **高频表达**：A window seat, please. / Is my luggage overweight? / Which gate is it? / When does boarding start?

### 8 安检与登机口问询
- **AI 角色**：安检员/问询处staff，指令式短句（"Laptops out, please."）
- **开场白**："Please put your bag in the tray. Any liquids?"
- **易卡点**：① 听不懂指令请再说一次；② 问登机口怎么走；③ 问能否带某物品上机
- **高频表达**：Sorry, could you repeat that? / How do I get to gate B12? / Can I take this on board? / Do I need to take my shoes off?

### 9 航班延误／改签
- **AI 角色**：航空公司客服，礼貌但按规章办事，Hard 下只给标准答复
- **开场白**："Hi, how can I help you today?"
- **易卡点**：① 说清航班号和问题；② 要求改签/住宿；③ 追问赔偿
- **高频表达**：My flight has been delayed. / Can I be rebooked on the next flight? / Will you provide a hotel? / Am I entitled to compensation?

### 10 打车
- **AI 角色**：司机，话痨型，会问目的地、聊天气、推荐路线
- **开场白**："Where to, mate?"
- **易卡点**：① 报目的地并要求不绕路；② 请开慢点/调空调；③ 问车费、刷卡还是现金
- **高频表达**：Could you take me to...? / Please take the fastest route. / Could you turn the AC down? / How much is it? / Can I pay by card?

### 11 公共交通问路
- **AI 角色**：站务员或路人，只讲一次路线，用直走、换乘、对面等方位词
- **开场白**："Hi, you look lost — need a hand?"
- **易卡点**：① 问怎么换乘；② 确认方向和坐几站；③ 没听懂请对方说慢点
- **高频表达**：How do I get to the museum? / Which line should I take? / How many stops is it? / Could you say that more slowly?

### 12 酒店入住与退房
- **AI 角色**：前台，热情专业，会推销升级房型（Hard 下推销更强势）
- **开场白**："Good evening! Welcome. Checking in?"
- **易卡点**：① 报预订名/确认号；② 问早餐与押金；③ 请求延迟退房
- **高频表达**：I have a reservation under... / Is breakfast included? / How much is the deposit? / Could I have a late checkout?

---

## C 城市办事

### 13 银行开户与换汇
- **AI 角色**：银行柜员，流程化提问（证件、地址、用途），语速稳但问得多
- **开场白**："Good morning. How can I help you today?"
- **易卡点**：① 说明开户目的；② 提供地址和电话；③ 问手续费与汇率
- **高频表达**：I'd like to open a savings account. / I'm here to exchange currency. / What's the exchange rate today? / Is there a service fee?

### 14 手机营业厅办卡／套餐
- **AI 角色**：店员，推销套餐，Hard 下不断加推荐
- **开场白**："Hi! Looking for a new plan or a SIM card?"
- **易卡点**：① 说需求（流量多、能打国际）；② 拒绝附加服务；③ 问合约期与解约
- **高频表达**：I need a plan with more data. / I just need the SIM card, thanks. / Is there a contract? / What if I cancel early?

### 15 邮局寄件／快递取件
- **AI 角色**：邮政职员，问目的地、重量、时效
- **开场白**："Next in line — what are we sending today?"
- **易卡点**：① 说寄到哪、多快；② 问运费；③ 取件报单号
- **高频表达**：I'd like to send this to... / How long does express take? / How much is the postage? / I'm here to pick up a parcel. Here's the tracking number.

### 16 报失报警（护照／钱包）
- **AI 角色**：警局值班警员，冷静、按流程记录，语气公事但会安抚
- **开场白**："Take a seat. Tell me what happened."
- **易卡点**：① 说清丢什么、在哪丢的；② 要一份报警记录；③ 问下一步怎么办
- **高频表达**：My wallet was stolen. / I lost my passport near the station. / Could I get a police report? / What should I do next?

### 17 药店买药
- **AI 角色**：药剂师，会问症状和用药禁忌
- **开场白**："Hi, how can I help? Are you looking for something specific?"
- **易卡点**：① 描述症状；② 说"不要处方药/我在吃别的药"；③ 问用量
- **高频表达**：I need something for a sore throat. / Do I need a prescription? / I'm also taking... / How often should I take it?

---

## D 租房邻里

### 18 看房与谈价
- **AI 角色**：房东/中介，想尽快签约，对砍价有抵抗力，Hard 下抬价、造紧迫感
- **开场白**："Hi! You're here about the apartment, right? Come in."
- **易卡点**：① 问租金、押金、水电；② 问能否养宠/短租；③ 砍价
- **高频表达**：How much is the rent? / Are utilities included? / Is it possible to rent short-term? / Could you lower the rent if I sign for a year?

### 19 向房东报修
- **AI 角色**：房东，回应慢、爱拖（Hard 下推给"你自己找人修"）
- **开场白**："Hi, what's up?"
- **易卡点**：① 描述故障；② 要求尽快上门；③ 谁来付维修费
- **高频表达**：The heater isn't working. / The sink is leaking. / Could someone come and fix it this week? / Who covers the repair cost?

### 20 邻里噪音沟通
- **AI 角色**：邻居，Easy 立刻道歉；Hard 觉得你小题大做
- **开场白**："Oh hey — everything okay?"
- **易卡点**：① 委婉提出不满（不撕破脸）；② 给出具体时间诉求；③ 对方不配合时的升级说法
- **高频表达**：Sorry to bother you, but the music is a bit loud. / Could you keep it down after 10? / It's been happening a few nights. / I'd rather not involve the landlord.

### 21 退租与押金
- **AI 角色**：房东，找理由扣押金（"墙上有个印子"）
- **开场白**："So, you're moving out. Let's do the walk-through."
- **易卡点**：① 要求退全额押金；② 反驳不合理扣款；③ 问退款时间
- **高频表达**：When will I get my deposit back? / I don't think that's fair — the wall was already like that. / Could we go through the list together? / I'd like it in writing.

---

## E 社交人际

### 22 破冰自我介绍
- **AI 角色**：新同事/新同学，友善、好奇，会追问细节
- **开场白**："Hey, I'm Alex — you're new here, right?"
- **易卡点**：① 一句话介绍背景；② 说兴趣找共同点；③ 反问对方
- **高频表达**：I'm originally from... / I've been working in... for three years. / I'm into hiking, actually. / What about you?

### 23 派对闲聊（Small talk）
- **AI 角色**：派对上的陌生人，轻松、跳话题快
- **开场白**："So how do you know the host?"
- **易卡点**：① 接住话题不冷场；② 表达没听懂/没看过；③ 礼貌退出对话
- **高频表达**：How do you know each other? / I haven't seen that, actually — is it good? / That reminds me of... / I'm going to grab a drink, nice talking to you!

### 24 约人、改期与拒绝
- **AI 角色**：朋友/同事，Easy 好说话；Hard 会追问、有点失落
- **开场白**："Hey! Long time no see. Free this weekend?"
- **易卡点**：① 提出邀约；② 改期说得不伤人；③ 拒绝但不给假希望
- **高频表达**：Are you free on Saturday? / Something came up — could we push it to Sunday? / I'd love to, but I'm swamped this week. / Let's find another time.

### 25 礼貌反驳与表达不同意见
- **AI 角色**：会议里的同事/朋友，观点与你相反且坚持
- **开场白**："I really think we should go with my plan. Don't you agree?"
- **易卡点**：① 先认可再反驳；② 给理由而不是只说 no；③ 保留关系
- **高频表达**：I see your point, but... / I'd push back on that a little. / My concern is... / Can we look at the numbers first?

### 26 道歉与和解
- **AI 角色**：被你冒犯的人，Hard 下不轻易接受道歉
- **开场白**："You wanted to talk?"
- **易卡点**：① 明确道歉不找借口；② 说清会怎么改；③ 询问对方感受
- **高频表达**：I owe you an apology. / That was my fault — I shouldn't have said that. / I'll make sure it doesn't happen again. / How are you feeling about it now?

---

## F 职场

### 27 求职面试
- **AI 角色**：面试官，Normal 友好；Hard 严厉、连环追问细节
- **开场白**："Thanks for coming in. So, tell me about yourself."
- **易卡点**：① 自我介绍结构；② 离职原因；③ 谈期望薪资
- **高频表达**：I have three years of experience in... / My biggest strength is... / I'm looking for new challenges. / Could you tell me the salary range?

### 28 入职第一天自我介绍
- **AI 角色**：团队 leader，欢迎但会顺势介绍流程
- **开场白**："Everyone, this is our new teammate. Want to introduce yourself?"
- **易卡点**：① 30 秒版自我介绍；② 说清负责什么；③ 表达请多指教
- **高频表达**：Hi everyone, I'm... I'll be working on... / I'm still learning the ropes, so bear with me. / Happy to grab coffee with anyone.

### 29 会议发言与打断
- **AI 角色**：会议主持人/强势同事，语速快、话不落地
- **开场白**："Okay, next item. Any thoughts?"
- **易卡点**：① 礼貌插话；② 表达观点 30 秒讲完；③ 没听懂要求澄清
- **高频表达**：Sorry to jump in — / Can I add something here? / Just to make sure I follow, do you mean...? / I'll keep it brief.

### 30 请假与汇报延期
- **AI 角色**：直属上司，忙、要理由和方案，Hard 下会追问影响
- **开场白**："Hey, what did you want to talk about?"
- **易卡点**：① 提出请求并给理由；② 说清工作怎么补；③ 报延期并给新时间点
- **高频表达**：I'd like to take Friday off, if that works. / I'll hand over the tasks to... / I'm afraid I need a couple more days. / Here's my plan to catch up.

### 31 同事午餐闲聊
- **AI 角色**：同事，随意、八卦但友善
- **开场白**："Hey, lunch? I'm starving."
- **易卡点**：① 接住闲聊话题；② 抱怨工作但不过界；③ 结束对话回工位
- **高频表达**：I could eat. Where to? / How's your week going? / Same here — it's been crazy. / I'd better get back to it.

### 32 客户投诉处理
- **AI 角色**：愤怒的客户，要求退款/赔偿，Hard 下情绪更强、反复施压
- **开场白**："This is the third time I've called! My order still hasn't arrived."
- **易卡点**：① 安抚情绪不辩解；② 复述问题确认；③ 给方案和时间承诺
- **高频表达**：I'm really sorry about that. / Let me make sure I've got this right — / Here's what I can do for you. / You'll get a confirmation by Friday.

---

## G 医疗应急

### 33 看医生（描述症状）
- **AI 角色**：全科医生，冷静、问诊式追问
- **开场白**："Come in, have a seat. What seems to be the problem?"
- **易卡点**：① 说症状与部位；② 说持续多久；③ 确认用药与复诊
- **高频表达**：I've had a headache for two days. / It hurts when I... / I feel dizzy and tired. / How often should I take this?

### 34 牙医与急诊
- **AI 角色**：牙医（补牙/拔牙）/ 急诊护士（登记、分诊），节奏快
- **开场白**："Have a seat. Which tooth is bothering you?" / "What brings you in today?"
- **易卡点**：① 说具体疼痛位置和触发动作；② 说清紧急程度；③ 问费用与保险
- **高频表达**：It hurts when I bite down. / I think I chipped a tooth. / It's pretty urgent — I can't sleep. / Do you take this insurance?

### 35 保险理赔
- **AI 角色**：保险客服，按条款问，Hard 下强调"不在保障范围"
- **开场白**："Claims department, how can I help?"
- **易卡点**：① 说明事故与时间；② 问需要哪些材料；③ 反驳拒赔
- **高频表达**：I'd like to file a claim. / What documents do you need? / Could you point out which clause excludes this? / Could I speak to a supervisor?

---

## H 校园学术

### 36 课堂提问
- **AI 角色**：教授，时间紧，要求问题具体
- **开场白**："Any questions before we wrap up?"
- **易卡点**：① 一句话把问题问清；② 引用上节课内容；③ 没听懂时请重述
- **高频表达**：Could you go over the second part again? / I'm not sure I follow the example on slide 5. / Does that apply to... as well?

### 37 Office hour 找教授
- **AI 角色**：教授，友善但直接，Hard 下会反问你的思路
- **开场白**："Come in! What can I do for you?"
- **易卡点**：① 说明来意（作业/论文/推荐信）；② 说清自己已经试过什么；③ 请求延期
- **高频表达**：I wanted to ask about the essay. / I've tried..., but I'm stuck on... / Would it be possible to get an extension? / Could you write me a recommendation?

### 38 小组讨论分工
- **AI 角色**：组员，一个积极一个划水（可切换），会议节奏松散
- **开场白**："So, how should we split this up?"
- **易卡点**：① 主动认领任务；② 对不合理分工提出异议；③ 定 deadline 和跟进方式
- **高频表达**：I can take the research part. / I'm a bit worried about the timeline. / Can we set a check-in on Wednesday? / Let's put it in the shared doc.

---

## I 高压冲突

### 39 被多收费
- **AI 角色**：收银员/服务员，先坚持没收错（"The system says so."）
- **开场白**："Is there a problem with the bill?"
- **易卡点**：① 指出具体哪项不对；② 要求核对菜单/小票；③ 要求更正或退钱
- **高频表达**：I think I've been overcharged. / This item is listed as $12 on the menu. / Could you check it again? / I'd like a refund for the difference.

### 40 退货被拒
- **AI 角色**：店长，拿"超过 7 天/无小票"挡你，Hard 下态度强硬
- **开场白**："Sorry, we can't take this back."
- **易卡点**：① 陈述事实和政策；② 要求升级处理；③ 保留证据的说法
- **高频表达**：The policy says 30 days, and it's been 10. / Could you check with your manager? / I'd like this in writing. / I'll take it up with consumer services.

### 41 拒绝推销
- **AI 角色**：街头/电话推销员，话术密集、不让挂（Hard 下不断追问）
- **开场白**："Excuse me! Can I ask you a quick question?"
- **易卡点**：① 快速打断不解释；② 坚定重复拒绝；③ 结束对话离开
- **高频表达**：No thanks, I'm not interested. / I'm in a hurry, sorry. / I've already got one. / Have a good day.

### 42 向经理投诉
- **AI 角色**：餐厅经理，先道歉再解释，Hard 下推责任给员工
- **开场白**："I understand there was an issue. What happened?"
- **易卡点**：① 只说事实不带情绪；② 明确提出诉求；③ 不接受敷衍时怎么推进
- **高频表达**：I'd like to make a complaint. / We waited over an hour and nobody came. / What I'd like is... / I don't think that's an acceptable solution.

---

## 场景卡扩展模板

遇到库外场景（如"和室友分摊账单""参加婚礼""买二手车""和医生讨论手术方案"），按此结构现场生成：

```
- **AI 角色**：（身份 + 语气 + 一个性格标签）
- **开场白**：AI 说的第一句（一句，能立即把用户拉进场景）
- **易卡点**：3 个用户最容易卡住的具体点
- **高频表达**：3-5 句真正常用的表达（不是完整脚本）
- **难度提示**：Easy / Normal / Hard 各变一句话即可
```

生成后直接进场，不向用户解释卡片结构。

## 变体机制（复练价值）

同一场景可通过三个维度重组，避免"练一遍就废"：

1. **难度**：Easy（短句、慢、主动提示）→ Normal → Hard（地道表达、追问施压）
2. **角色立场**：友善 / 中立 / 不配合（同一张卡换立场，用户的应对策略完全不同）
3. **突发变量**：在场景中途加入一个意外（涨价、系统故障、对方误会），逼用户临场反应

用户说"再来一次"时，默认换其中 1-2 个维度重开，并在开场一句话里暗示变化（"这次店长心情不太好。"）。
