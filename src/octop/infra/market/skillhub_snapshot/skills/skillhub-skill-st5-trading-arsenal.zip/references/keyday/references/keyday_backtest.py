"""
关键日周期回测脚本 (keyday_backtest.py)
========================================
蒸馏自《短线交易五大绝技》第 7 章
作者: Jake Bernstein (2005)
蒸馏者注: 本脚本仅作方法论演示,生产环境需自己重做
使用: python keyday_backtest.py --csv data.csv --enter 2-26 --exit 3-5 --stop 3.5
数据格式: CSV 需含 date, open, high, low, close 列(date=YYYY-MM-DD)
"""
import argparse, csv, sys
from datetime import datetime, date
from collections import defaultdict

def load_csv(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        rd = csv.DictReader(f)
        for r in rd:
            try:
                rows.append({
                    "date": datetime.strptime(r["date"], "%Y-%m-%d").date(),
                    "open": float(r["open"]),
                    "high": float(r["high"]),
                    "low": float(r["low"]),
                    "close": float(r["close"]),
                })
            except (KeyError, ValueError):
                continue
    rows.sort(key=lambda x: x["date"])
    return rows

def nearest_on_or_after(target_d, rows, from_idx):
    """从 from_idx 开始找第一个 >= target_d 的交易日"""
    for i in range(from_idx, len(rows)):
        if rows[i]["date"] >= target_d:
            return i
    return None

def backtest(rows, enter_md, exit_md, stop_pct):
    """按"进入日收盘价进入,退出日收盘价退出,止损%贯穿持仓期"回测"""
    enter_m, enter_d = map(int, enter_md.split("-"))
    exit_m, exit_d = map(int, exit_md.split("-"))
    # 按年分组
    by_year = defaultdict(list)
    for r in rows:
        by_year[r["date"].year].append(r)
    trades = []
    for year in sorted(by_year.keys()):
        yr_rows = by_year[year]
        try:
            enter_target = date(year, enter_m, enter_d)
            exit_target = date(year, exit_m, exit_d)
        except ValueError:
            continue
        if exit_target <= enter_target:
            exit_target = date(year + 1, exit_m, exit_d)
        enter_idx = nearest_on_or_after(enter_target, yr_rows, 0)
        if enter_idx is None: continue
        exit_idx = nearest_on_or_after(exit_target, yr_rows, enter_idx + 1)
        if exit_idx is None: continue
        # 找最大回撤期间(在 enter 到 exit 之间)
        enter_price = yr_rows[enter_idx]["close"]
        # 贯穿 enter 到 exit 的止损检查
        stopped = False
        actual_exit_idx = exit_idx
        for j in range(enter_idx + 1, exit_idx + 1):
            # 当日最低价触发止损
            stop_price = enter_price * (1 - stop_pct / 100)
            if yr_rows[j]["low"] <= stop_price:
                stopped = True
                actual_exit_idx = j
                break
        exit_price = yr_rows[actual_exit_idx]["close"]
        ret = (exit_price - enter_price) / enter_price * 100
        trades.append({
            "year": year,
            "enter_date": yr_rows[enter_idx]["date"],
            "enter_price": round(enter_price, 2),
            "exit_date": yr_rows[actual_exit_idx]["date"],
            "exit_price": round(exit_price, 2),
            "stopped": stopped,
            "ret_pct": round(ret, 2),
        })
    return trades

def stats(trades):
    if not trades:
        return {"trades": 0}
    wins = [t for t in trades if t["ret_pct"] > 0]
    losses = [t for t in trades if t["ret_pct"] <= 0]
    avg_win = sum(t["ret_pct"] for t in wins) / len(wins) if wins else 0
    avg_loss = sum(t["ret_pct"] for t in losses) / len(losses) if losses else 0
    win_rate = len(wins) / len(trades) * 100
    pf = abs(avg_win / avg_loss) if avg_loss < 0 else float("inf")
    return {
        "trades": len(trades),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate_pct": round(win_rate, 2),
        "avg_win_pct": round(avg_win, 2),
        "avg_loss_pct": round(avg_loss, 2),
        "profit_factor": round(pf, 2) if pf != float("inf") else "inf",
    }

def pass_gate(s):
    """作者门槛:胜率>=70%, PF>=1.5, 交易数>=10"""
    if s["trades"] < 10: return False, f"样本不足 ({s['trades']} < 10)"
    if s["win_rate_pct"] < 70: return False, f"胜率不足 ({s['win_rate_pct']}% < 70%)"
    if isinstance(s["profit_factor"], (int, float)) and s["profit_factor"] < 1.5:
        return False, f"PF 不足 ({s['profit_factor']} < 1.5)"
    return True, "通过"

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="关键日周期回测 (Bernstein 第7章)")
    ap.add_argument("--csv", required=True, help="日线 CSV, 列: date,open,high,low,close")
    ap.add_argument("--enter", required=True, help="进入月日, 例: 2-26")
    ap.add_argument("--exit", required=True, help="退出月日, 例: 3-5")
    ap.add_argument("--stop", type=float, required=True, help="止损百分比, 例: 3.5")
    args = ap.parse_args()
    rows = load_csv(args.csv)
    trades = backtest(rows, args.enter, args.exit, args.stop)
    s = stats(trades)
    print("===== 关键日周期回测 =====")
    print(f"进入: {args.enter}  退出: {args.exit}  止损: {args.stop}%")
    print(f"样本数: {s['trades']} (胜 {s['wins']} / 负 {s['losses']})")
    print(f"胜率: {s['win_rate_pct']}%")
    print(f"平均盈利: {s['avg_win_pct']}%")
    print(f"平均亏损: {s['avg_loss_pct']}%")
    print(f"盈亏比 PF: {s['profit_factor']}")
    ok, reason = pass_gate(s)
    print(f"门槛: {'✅ 通过' if ok else '❌ ' + reason}")
    print("\n===== 交易明细 =====")
    for t in trades:
        flag = "🛑止损" if t["stopped"] else "持有"
        print(f"  {t['year']}: {t['enter_date']} @ {t['enter_price']} → {t['exit_date']} @ {t['exit_price']}  {t['ret_pct']:+.2f}%  {flag}")
