"""
星期形态回测脚本 (weekday_backtest.py)
========================================
蒸馏自《短线交易五大绝技》第 8 章
作者: Jake Bernstein (2005)
使用: python weekday_backtest.py --csv data.csv --buffer 0.5 --stop 2.0
数据格式: CSV 需含 date, open, high, low, close 列
说明: A 股 FPO 退出需结合 T+0 ETF(513100/513500 等)或改为"次日开盘"
"""
import argparse, csv, sys
from datetime import datetime, timedelta
from collections import defaultdict

def load_csv(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        rd = csv.DictReader(f)
        for r in rd:
            try:
                rows.append({
                    "date": datetime.strptime(r["date"], "%Y-%m-%d").date(),
                    "open": float(r["open"]),
                    "high": float(r["high"]),
                    "low": float(r["low"]),
                    "close": float(r["close"]),
                })
            except (KeyError, ValueError):
                continue
    rows.sort(key=lambda x: x["date"])
    return rows

def group_weeks(rows):
    """按 ISO 周(周一到周日)分组"""
    by_week = defaultdict(list)
    for r in rows:
        # ISO 周: 周一为第一天
        iso = r["date"].isocalendar()
        key = (iso[0], iso[1])
        by_week[key].append(r)
    return by_week

def find_friday(week_rows):
    """从一周的 K 线中找周五(若无则最后一天)"""
    for r in week_rows:
        if r["date"].weekday() == 4:
            return r
    return week_rows[-1] if week_rows else None

def find_monday(week_rows):
    for r in week_rows:
        if r["date"].weekday() == 0:
            return r
    return None

def backtest(rows, buffer_pct, stop_pct):
    by_week = group_weeks(rows)
    signals = []
    for week_key in sorted(by_week.keys()):
        week = by_week[week_key]
        if len(week) < 2: continue
        fri = find_friday(week)
        if not fri: continue
        mon = find_monday(week)
        if not mon: continue
        # 周五确立:收盘价接近/低于周内最低价(下行确立)
        week_low = min(r["low"] for r in week)
        week_high = max(r["high"] for r in week)
        # 形态 1: 周五收在最低附近 → 视为下行确立(美股做空信号)
        if fri["close"] <= week_low * (1 + buffer_pct / 100):
            signals.append({
                "week": week_key,
                "fri_close": fri["close"],
                "week_low": week_low,
                "mon_open": mon["open"],
                "pattern": "down_setup",
                # 美股做空:周一开盘卖, 止损 = 周内最高价 × (1+buffer)
                "stop_price": week_high * (1 + stop_pct / 100),
            })
        # 形态 2: 周五收在最高附近 → 视为上行确立
        elif fri["close"] >= week_high * (1 - buffer_pct / 100):
            signals.append({
                "week": week_key,
                "fri_close": fri["close"],
                "week_high": week_high,
                "mon_open": mon["open"],
                "pattern": "up_setup",
                # 做多:周一开盘买, 止损 = 周内最低价 × (1-buffer)
                "stop_price": week_low * (1 - stop_pct / 100),
            })
    return signals

def simulate(signals, by_week_rows, fpo=True):
    """简化模拟:做多信号 → 周一开盘买 → FPO(开盘获利即卖)或止损"""
    trades = []
    for sig in signals:
        if sig["pattern"] != "up_setup": continue  # A 股只做多
        # 找周一的 K 线 + 后续 K 线(用于 FPO/止损)
        week = by_week_rows.get(sig["week"], [])
        mon = next((r for r in week if r["date"].weekday() == 0), None)
        if not mon: continue
        # FPO: 开盘价 > 假设入场价(略高于周五收盘)即获利
        # 简化: 假设以周一开盘价成交, 若 open > fri_close 即获利
        entry = sig["fri_close"]  # 假设以周五收盘价(更接近 FPO 概念)
        fpo_hit = mon["open"] > entry
        if fpo_hit and fpo:
            ret = (mon["open"] - entry) / entry * 100
            trades.append({"week": sig["week"], "exit_type": "FPO", "ret_pct": round(ret, 2)})
        else:
            # 当日收盘退出
            ret = (mon["close"] - entry) / entry * 100
            trades.append({"week": sig["week"], "exit_type": "close", "ret_pct": round(ret, 2)})
    return trades

def stats(trades):
    if not trades: return {"n": 0}
    wins = [t for t in trades if t["ret_pct"] > 0]
    losses = [t for t in trades if t["ret_pct"] <= 0]
    avg_w = sum(t["ret_pct"] for t in wins) / len(wins) if wins else 0
    avg_l = sum(t["ret_pct"] for t in losses) / len(losses) if losses else 0
    return {
        "n": len(trades),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate_pct": round(len(wins) / len(trades) * 100, 2),
        "avg_win_pct": round(avg_w, 2),
        "avg_loss_pct": round(avg_l, 2),
        "pf": round(abs(avg_w / avg_l), 2) if avg_l < 0 else "inf",
    }

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="星期形态回测 (Bernstein 第8章)")
    ap.add_argument("--csv", required=True, help="日线 CSV")
    ap.add_argument("--buffer", type=float, default=0.5, help="周五收/最低 缓冲%")
    ap.add_argument("--stop", type=float, default=2.0, help="止损%")
    ap.add_argument("--no-fpo", action="store_true", help="禁用 FPO, 改为当日收盘退出")
    args = ap.parse_args()
    rows = load_csv(args.csv)
    sigs = backtest(rows, args.buffer, args.stop)
    by_week = group_weeks(rows)
    trades = simulate(sigs, by_week, fpo=not args.no_fpo)
    s = stats(trades)
    print("===== 星期形态回测(仅做多信号) =====")
    print(f"原始信号: {len(sigs)}  实际交易(A股做多): {s['n']}")
    print(f"胜率: {s['win_rate_pct']}%  胜: {s['wins']}  负: {s['losses']}")
    print(f"平均盈利: {s['avg_win_pct']}%  平均亏损: {s['avg_loss_pct']}%  PF: {s['pf']}")
    print("\n提示: 作者原书用美股 SPY/QQQ/DIA,A 股请用沪深300ETF/科创50ETF 等替代")
