# INDEX · 6 子技能关联索引

## 技能包
- **st5-trading-arsenal** (本包) — 短线交易五大绝技蒸馏集合

## 6 个子技能详细索引

| 子技能 | 类型 | 调用时机 | 依赖 | 实算 |
|---|---|---|---|---|
| `gim-general-investment-model` | 元框架 | 任何投资决策前 | 无 | ❌ |
| `stf-setup-trigger-followthrough` | 执行流程 | GIM 之后 | gim | ❌ |
| `st5-keyday-seasonal` | 纯规则短线 | 想用日历窗口 | stf | ✅ |
| `st5-weekday-patterns` | 纯规则短线 | 想用周内形态 | stf | ✅ |
| `st5-channel-mac` | 趋势跟踪 | 想用价格通道 | stf | ✅ |
| `st5-discipline-psychology` | 行为学补丁 | 知道却做不到 | 所有 | ❌ |

## 引用关系图(mermaid)

```mermaid
graph TD
    A[gim-general-investment-model<br/>GIM 三问自检] -->|通过三问| B[stf-setup-trigger-followthrough<br/>STF 执行流程]
    B -->|确立阶段用日历| C1[st5-keyday-seasonal<br/>关键日周期]
    B -->|验证阶段用星期| C2[st5-weekday-patterns<br/>星期形态]
    B -->|验证阶段用价格| C3[st5-channel-mac<br/>MAC 通道]
    C1 --> D[st5-discipline-psychology<br/>纪律+三十工具]
    C2 --> D
    C3 --> D
    B --> D
    A --> D
```

## 经典使用流程

1. 用户:"我想买 600519 茅台"
2. Agent 调 `gim-general-investment-model` → 输出三问自检清单
3. 用户填完后,Agent 调 `stf-setup-trigger-followthrough` → 给出确立-验证-坚持流程
4. 用户说"我已经分析了基本面, 想找个日历时机"
5. Agent 调 `st5-keyday-seasonal` → 跑 `keyday_backtest.py` 给历史胜率
6. 通过门槛后, Agent 给出具体日历窗口 + 入场/止损/出场规则
7. 用户犹豫要不要执行, Agent 调 `st5-discipline-psychology` → 调出工具 12(不犹豫)+ 工具 13(及时止损)
8. 用户执行后,Agent 调 `st5-discipline-psychology` 的三层次诊断记录结果

## 失败案例对照(STF 视角)

| 失败模式 | 应对子技能 | 关键规则 |
|---|---|---|
| 不知道该不该买 | gim | 三问自检 |
| 知道但没执行 | stf + discipline | 工具 12(不犹豫) |
| 执行了但没止损 | stf + discipline | 工具 13(及时止损) |
| 优化系统(过度优化) | discipline | "木匠多盖歪房子"警告 |
| 选错时机 | keyday / weekday / channel | 三选一+回测门槛 |
| 频繁交易 | discipline | 工具 8(少交易几次) |

## 跨包引用(与其他 skill 配合)

- **a-stock-data** (用户级): 提供 A 股日线数据 → keyday/weekday/channel 回测数据源
- **value-screen-1-0** (用户级): 帮 gim 选股(过滤危险标的)
- **china-stock-data** (用户级): 提供基础数据 + 实时行情
- **回测专业性体检** (用户级 skill): 对 3 个 Python 脚本跑出来的结果做 OOS/去幸存者化体检

## 资源

- 原作: Jake Bernstein《短线交易五大绝技》HOT STOCK MARKET STRATEGIES, McGraw Hill 2005
- 中文版: 中国青年出版社
- 蒸馏方法: 仓颉造技能(jifengmax-cangjie-creator)
- 蒸馏时间: 2026-08-23
