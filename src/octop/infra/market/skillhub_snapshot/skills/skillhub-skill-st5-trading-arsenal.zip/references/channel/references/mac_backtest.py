"""
MAC(移动平均线通道)回测脚本 (mac_backtest.py)
================================================
蒸馏自《短线交易五大绝技》第 9 章
作者: Jake Bernstein (2005)
规则:
  1. 上轨 = 10日最高价均线
  2. 下轨 = 8日最低价均线
  3. 连续 2 根 K 线最高价完全跳出上轨外 → 趋势从下降翻向上升
  4. 上升趋势中,收盘价 ≤ 下轨 × 1.02 → 回调买点
使用: python mac_backtest.py --csv data.csv --n-up 10 --n-low 8 --buffer 2.0
"""
import argparse, csv
from datetime import datetime
from collections import defaultdict

def load_csv(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        rd = csv.DictReader(f)
        for r in rd:
            try:
                rows.append({
                    "date": datetime.strptime(r["date"], "%Y-%m-%d").date(),
                    "open": float(r["open"]),
                    "high": float(r["high"]),
                    "low": float(r["low"]),
                    "close": float(r["close"]),
                })
            except (KeyError, ValueError):
                continue
    rows.sort(key=lambda x: x["date"])
    return rows

def mac_signals(rows, n_up=10, n_low=8, buffer_pct=2.0):
    """计算 MAC 上下轨 + 趋势翻转信号 + 回调买点"""
    n = len(rows)
    upper = [None] * n
    lower = [None] * n
    flip_up = [False] * n       # 趋势翻转(连续 2 根 K 线跳出上轨)
    pullback_buy = [False] * n  # 回调买点(上升趋势中接近下轨)
    for i in range(n):
        if i >= n_up - 1:
            upper[i] = sum(r["high"] for r in rows[i - n_up + 1: i + 1]) / n_up
        if i >= n_low - 1:
            lower[i] = sum([r["low"] for r in rows[i - n_low + 1: i + 1]]) / n_low
    # 趋势翻转: 连续 2 根 K 线 high > upper
    for i in range(1, n):
        if upper[i] is not None and upper[i - 1] is not None:
            flip_up[i] = rows[i]["high"] > upper[i] and rows[i - 1]["high"] > upper[i - 1]
    # 回调买点: 上升趋势中(flip_up 在最近 N 根内出现过) + close ≤ lower * 1.02
    for i in range(n):
        if lower[i] is None: continue
        # 简化: 任意时刻 close ≤ lower * 1.02 都算(作者说"上升趋势中",严格应只算 flip 之后)
        # 蒸馏者宽松处理: 任何下轨附近都算信号,标记 [未过滤趋势]
        pullback_buy[i] = rows[i]["close"] <= lower[i] * (1 + buffer_pct / 100)
    return upper, lower, flip_up, pullback_buy

def backtest(rows, upper, lower, flip_up, pullback_buy, hold_days=10):
    """简化回测: 回调买点入场,持有 N 日, 跌破下轨止损"""
    trades = []
    n = len(rows)
    in_trade = False
    entry_idx = None
    for i in range(n):
        if not in_trade and pullback_buy[i]:
            in_trade = True
            entry_idx = i
            continue
        if in_trade:
            # 检查止损: 收盘价跌破下轨
            if rows[i]["close"] < lower[i] * 0.98:
                ret = (rows[i]["close"] - rows[entry_idx]["close"]) / rows[entry_idx]["close"] * 100
                trades.append({"entry": rows[entry_idx]["date"], "exit": rows[i]["date"], "ret_pct": round(ret, 2), "reason": "stop"})
                in_trade = False
                continue
            # 持有到期
            if i - entry_idx >= hold_days:
                ret = (rows[i]["close"] - rows[entry_idx]["close"]) / rows[entry_idx]["close"] * 100
                trades.append({"entry": rows[entry_idx]["date"], "exit": rows[i]["date"], "ret_pct": round(ret, 2), "reason": "expire"})
                in_trade = False
    return trades

def stats(trades):
    if not trades: return {"n": 0}
    wins = [t for t in trades if t["ret_pct"] > 0]
    losses = [t for t in trades if t["ret_pct"] <= 0]
    avg_w = sum(t["ret_pct"] for t in wins) / len(wins) if wins else 0
    avg_l = sum(t["ret_pct"] for t in losses) / len(losses) if losses else 0
    return {
        "n": len(trades),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate_pct": round(len(wins) / len(trades) * 100, 2),
        "avg_win_pct": round(avg_w, 2),
        "avg_loss_pct": round(avg_l, 2),
        "pf": round(abs(avg_w / avg_l), 2) if avg_l < 0 else "inf",
    }

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="MAC 通道回测 (Bernstein 第9章)")
    ap.add_argument("--csv", required=True, help="日线 CSV")
    ap.add_argument("--n-up", type=int, default=10, help="上轨周期 (默认 10)")
    ap.add_argument("--n-low", type=int, default=8, help="下轨周期 (默认 8)")
    ap.add_argument("--buffer", type=float, default=2.0, help="回调买点缓冲% (默认 2)")
    ap.add_argument("--hold", type=int, default=10, help="持有天数 (默认 10)")
    args = ap.parse_args()
    rows = load_csv(args.csv)
    upper, lower, flip, pb = mac_signals(rows, args.n_up, args.n_low, args.buffer)
    trades = backtest(rows, upper, lower, flip, pb, args.hold)
    s = stats(trades)
    print("===== MAC 通道回测 =====")
    print(f"参数: 上轨 {args.n_up}日最高均价 / 下轨 {args.n_low}日最低均价 / 缓冲 {args.buffer}% / 持有 {args.hold}日")
    print(f"交易数: {s['n']}  胜: {s['wins']}  负: {s['losses']}")
    print(f"胜率: {s['win_rate_pct']}%  平均盈利: {s['avg_win_pct']}%  平均亏损: {s['avg_loss_pct']}%  PF: {s['pf']}")
    print("\n注意: 1) 原书 10/8 周期为美股优化, A 股建议重新优化")
    print("      2) 作者原规则要求只做'上升趋势中'(即 flip_up 之后)的回调, 本脚本宽松处理")
