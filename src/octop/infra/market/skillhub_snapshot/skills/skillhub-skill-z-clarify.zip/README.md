# z-clarify（需求澄清）

一句话：用结构化提问框架把模糊、宽泛或有分歧的需求，收敛成目标明确、边界清晰、可评审验收的需求说明 + 需求条目登记册。z-系列的中枢。

## 何时使用

说"需求澄清、需求评审、需求对齐、需求梳理、明确目标、梳理边界、定义需求"，或意图是先想清楚"做什么、不做什么"时触发。需求文档不完整、描述含糊、跨团队目标不一致、要明确验收范围时也触发。

## 用法速览

- 问法：「帮我澄清一下这个需求：……」；大需求先拆：「X 太大了，先拆解再澄清」；基线后变更：「线上项目要加 X 需求，澄清一下」
- 用法卡：聊天说 `z-clarify help`，ZCode 下 `/z-clarify-help` 直达
- 预期：3–4 轮选择题约 10 分钟，答"不知道"也算有效回答

## 核心机制

- **10 维度提问框架**：背景/目标/策略/干系人/现状/业务链/约束/数据/指标/边界，每维"结论+依据+未决项"三段式。
- **交互式向导**：典型 3–4 轮收敛；Gen UI 宿主默认双栏面板（本轮问题+报告实时状态），退化路径 AskUserQuestion 卡片 → 纯文本。
- **双产物**：需求澄清报告（含质量自评 10 分 rubric）+ 需求条目登记册（R-xxx 唯一 ID、MoSCoW 优先级、EARS 验证准则、来源必填无来源不入册）。
- **基线后（部署期）**：工程文档基线已存在时，变更澄清产物落 `docs/05-管理/变更/`，`00-立项/` 冻结不回写；新增条目接续编号，经变更流程同步 SRS。
- **轨道外问题**：一句话登记未决项并上报 z-flow-kickoff 停车场，不展开、不硬拒。

## 与 z-系列的关系

```
z-flow-kickoff（编排：开场协议→契约→横幅→交接→续跑）
   └─ z-pyramid(拆解) → z-clarify(本 skill：澄清→登记册) ⇄ z-chain(生态/干系人事实)
                              ↓
                       z-assess(四维+风险+假设 → Go/No-Go)
                              ↓ Go
                       z-init(工程文档基线化) → 下游 spec/开发（松耦合，AGENTS.md 契约）
```

上游：z-pyramid 供拆解（大需求）、z-chain 供维度 4/6 生态事实（先建图再定位）；下游：登记册供 z-assess 作评估证据、z-init 种子化 SRS 与跟踪矩阵。整链编排见 z-flow-kickoff；六技能相互独立、按需组合，联动方未安装时按各自文内退化规则执行。

## 安装

### ZCode（推荐：随系列整装，symlink 安装）

```bash
git clone https://github.com/zimy0033/z-skill-series.git ~/z-skill-series
bash ~/z-skill-series/install.sh
```

install.sh 把 `skills/*` 以 symlink 装入 `~/.zcode/skills/`（help 命令装入 `~/.zcode/commands/`）；更新只需 `git -C ~/z-skill-series pull`，无需重装。GitHub HTTPS 不稳时可改用 SSH。

### 单独安装（任一 agent）

把 `skills/z-clarify` 目录复制到目标 agent 的 skills 目录（ZCode 用户级 `~/.zcode/skills/`，项目级 `<项目>/.zcode/skills/`）。安装后重启会话生效。skills CLI 子路径安装已实测可用：`npx skills add zimy0033/z-skill-series/skills/z-clarify`。

## License

MIT
