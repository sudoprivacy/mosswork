#!/usr/bin/env python3
"""校验 OKR 文档是否满足格式与质量标准。

用法：
    python check_okr.py <okr.md> [--json]

输入：
    按 SKILL.md 输出模板生成的 Markdown 文件，UTF-8 编码。
    需包含 `## O1：<标题>` 形式的 Objective 章节，以及表头含
    Key Result、衡量指标、起始值、目标值、计算口径、截止时间、信心指数
    的表格，KR 行首列形如 `KR1.1`。

输出：
    默认输出人类可读报告；加 --json 输出单个 JSON 对象。

退出码：
    0 无错误（可能仍有警告或待补项）
    1 存在至少一个错误
    2 用法错误或输入文件不可读

行为：
    只读输入文件。不写文件、不联网、不启动子进程、不读取环境变量。

环境：
    Python 3.10 及以上，仅使用标准库。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

O_HEADING = re.compile(r"^##\s+O(\d+)\s*[：:]\s*(.+?)\s*$")
KR_ROW = re.compile(r"^\|\s*KR(\d+)(?:\.(\d+))?\s*\|")
QUANTIFIED = re.compile(r"[0-9０-９]|[%％]|万|亿|倍|元|美元")
PLACEHOLDER = re.compile(r"待补|待确认|TBD", re.IGNORECASE)
EMPTY_VALUE = re.compile(r"^[—–\-/\\]*$|^无$|^待定$")
DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TODO_SECTION = re.compile(r"^##\s*待补清单\s*$", re.MULTILINE)

REQUIRED_COLUMNS = (
    "Key Result",
    "衡量指标",
    "起始值",
    "目标值",
    "计算口径",
    "截止时间",
    "信心指数",
)

MIN_OBJECTIVES = 1
MAX_OBJECTIVES = 3
MIN_KRS = 2
MAX_KRS = 5
MAX_TITLE_CHARS = 40
HIGH_CONFIDENCE = 8.5
LOW_CONFIDENCE = 3.5


def split_row(line: str) -> list[str]:
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def parse(text: str) -> list[dict]:
    """解析出 Objective 列表，每个含标题、行号和 KR 行列表。"""
    objectives: list[dict] = []
    header: list[str] | None = None

    for line_no, raw in enumerate(text.splitlines(), start=1):
        line = raw.rstrip()

        heading = O_HEADING.match(line)
        if heading:
            objectives.append(
                {
                    "index": int(heading.group(1)),
                    "title": heading.group(2),
                    "line": line_no,
                    "krs": [],
                    "has_table": False,
                }
            )
            header = None
            continue

        if not line.lstrip().startswith("|"):
            continue

        cells = split_row(line)
        if not cells:
            continue

        if "Key Result" in cells and "信心指数" in cells:
            header = cells
            if objectives:
                objectives[-1]["has_table"] = True
            continue

        match = KR_ROW.match(line.lstrip())
        if header is not None and match and objectives:
            objectives[-1]["krs"].append(
                {
                    "id": cells[0],
                    "cells": {
                        name: cells[idx] if idx < len(cells) else ""
                        for idx, name in enumerate(header)
                    },
                    "line": line_no,
                }
            )

    return objectives


def check(objectives: list[dict], has_todo_section: bool) -> list[dict]:
    issues: list[dict] = []

    def add(code: str, level: str, message: str, location: str) -> None:
        issues.append(
            {"code": code, "level": level, "message": message, "location": location}
        )

    if not objectives:
        add("E001", "error", "未解析到任何 Objective 章节", "全文")
        return issues

    if not MIN_OBJECTIVES <= len(objectives) <= MAX_OBJECTIVES:
        add(
            "E002",
            "error",
            f"Objective 数量为 {len(objectives)}，允许范围 {MIN_OBJECTIVES}—{MAX_OBJECTIVES}",
            "全文",
        )

    all_scores: list[int] = []
    todo_items: list[str] = []

    for obj in objectives:
        tag = f"O{obj['index']}（第 {obj['line']} 行）"

        if QUANTIFIED.search(obj["title"]):
            add("E003", "error", f"标题含数字或量化表述：{obj['title']}", tag)

        if len(obj["title"]) > MAX_TITLE_CHARS:
            add(
                "E004",
                "error",
                f"标题 {len(obj['title'])} 字，超过 {MAX_TITLE_CHARS} 字上限",
                tag,
            )

        if not obj["has_table"]:
            add("E005", "error", "缺少 Key Result 表格", tag)
            continue

        if not MIN_KRS <= len(obj["krs"]) <= MAX_KRS:
            add(
                "E006",
                "error",
                f"KR 数量为 {len(obj['krs'])}，允许范围 {MIN_KRS}—{MAX_KRS}",
                tag,
            )

        for kr in obj["krs"]:
            kr_tag = f"{kr['id']}（第 {kr['line']} 行）"
            for column in REQUIRED_COLUMNS:
                if column not in kr["cells"]:
                    add("E007", "error", f"缺少必填列「{column}」", kr_tag)
                    continue
                if EMPTY_VALUE.match(kr["cells"][column].strip()):
                    add("E007", "error", f"必填列「{column}」为空", kr_tag)

            raw_score = kr["cells"].get("信心指数", "")
            if raw_score and re.fullmatch(r"\d+(\.\d+)?", raw_score):
                score = float(raw_score)
                if not 0 <= score <= 10:
                    add("E008", "error", f"信心指数 {raw_score} 超出 0—10", kr_tag)
                else:
                    all_scores.append(score)

            deadline = kr["cells"].get("截止时间", "")
            if deadline and not DATE.match(deadline):
                add("E009", "error", f"截止时间「{deadline}」不是 YYYY-MM-DD", kr_tag)

            for column in ("起始值", "目标值"):
                if PLACEHOLDER.search(kr["cells"].get(column, "")):
                    todo_items.append(f"{kr['id']} {column}")

        deadlines = {kr["cells"].get("截止时间", "") for kr in obj["krs"]}
        if len(obj["krs"]) >= 3 and len(deadlines) == 1 and "" not in deadlines:
            add(
                "W001",
                "warning",
                f"{len(obj['krs'])} 条 KR 截止日全部为 {next(iter(deadlines))}，缺少前置里程碑节奏",
                tag,
            )

        obj_scores = [
            float(kr["cells"]["信心指数"])
            for kr in obj["krs"]
            if re.fullmatch(r"\d+(\.\d+)?", kr["cells"].get("信心指数", ""))
            and 0 <= float(kr["cells"]["信心指数"]) <= 10
        ]
        if len(obj_scores) == len(obj["krs"]) and obj_scores:
            average = sum(obj_scores) / len(obj_scores)
            if average >= HIGH_CONFIDENCE:
                add(
                    "W002",
                    "warning",
                    f"平均信心指数 {average:.1f}，目标可能定得过保守",
                    tag,
                )
            elif average <= LOW_CONFIDENCE:
                add(
                    "W003",
                    "warning",
                    f"平均信心指数 {average:.1f}，路径或资源不足，优先补资源而非降目标",
                    tag,
                )

    if all_scores:
        overall = sum(all_scores) / len(all_scores)
        if overall >= HIGH_CONFIDENCE:
            add("W004", "warning", f"全文平均信心指数 {overall:.1f}，整体偏保守", "全文")
        elif overall <= LOW_CONFIDENCE:
            add("W005", "warning", f"全文平均信心指数 {overall:.1f}，整体资源和目标不匹配", "全文")

    for item in todo_items:
        add("I001", "info", f"{item} 标记为待补，需给出取数方法", "KR 行")

    if todo_items and not has_todo_section:
        add("I002", "info", "存在待补项但缺少「待补清单」章节", "全文")

    return issues


def render_text(path: Path, objectives: list[dict], issues: list[dict]) -> str:
    errors = [i for i in issues if i["level"] == "error"]
    warnings = [i for i in issues if i["level"] == "warning"]
    infos = [i for i in issues if i["level"] == "info"]

    lines = [
        f"OKR 校验报告：{path}",
        f"Objective：{len(objectives)} 个；Key Result：{sum(len(o['krs']) for o in objectives)} 条",
        "",
    ]

    for level, group in (("错误", errors), ("警告", warnings), ("待补", infos)):
        if not group:
            continue
        lines.append(f"【{level}】{len(group)} 项")
        for issue in group:
            lines.append(f"  {issue['code']}  {issue['location']}  {issue['message']}")
        lines.append("")

    lines.append(f"结论：{len(errors)} 个错误，{len(warnings)} 个警告，{len(infos)} 个待补项")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="校验 OKR 文档的格式与质量标准",
    )
    parser.add_argument("path", help="待校验的 OKR Markdown 文件")
    parser.add_argument("--json", action="store_true", help="输出 JSON")
    args = parser.parse_args()

    target = Path(args.path)
    try:
        if not target.is_file():
            raise OSError(f"不是可读文件：{target}")
        text = target.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        print(f"读取失败：{exc}", file=sys.stderr)
        return 2

    objectives = parse(text)
    issues = check(objectives, bool(TODO_SECTION.search(text)))

    if args.json:
        payload = {
            "path": str(target),
            "objectives": len(objectives),
            "key_results": sum(len(o["krs"]) for o in objectives),
            "issues": issues,
            "errors": sum(1 for i in issues if i["level"] == "error"),
            "warnings": sum(1 for i in issues if i["level"] == "warning"),
            "todos": sum(1 for i in issues if i["level"] == "info"),
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(render_text(target, objectives, issues))

    return 1 if any(i["level"] == "error" for i in issues) else 0


if __name__ == "__main__":
    sys.exit(main())
