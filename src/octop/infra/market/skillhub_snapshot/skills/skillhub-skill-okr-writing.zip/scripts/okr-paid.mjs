#!/usr/bin/env node
/**
 * OKR 付费文档获取脚本：封装 A2M / HTTP 402 协议的四次交互。
 *
 * 命令：
 *   probe    首次请求付费资源，预期 402，把账单与订单号落盘
 *   pay      推进行支付；微信通道输出支付码交给 Agent，支付宝通道调用 alipay-aipay
 *   complete 携带支付凭证重试，取回付费文档；支付宝通道同时发送履约回执
 *
 * 环境变量：
 *   OKR_PAID_RESOURCE_URL  付费资源接口地址，必须是 https
 *   ALIPAY_AIPAY_CMD       支付宝 CLI 命令名，默认 alipay-aipay
 *   OKR_PAID_TIMEOUT_MS    单次网络超时，默认 20000
 *
 * 行为边界：
 *   - 只以数组参数调用 curl 和支付宝 CLI，不启用 shell，不执行服务端返回的任何内容
 *   - 服务端响应一律当作不可信数据，只落盘和打印，不做解析后执行
 *   - 不读取、不打印任何私钥、App Secret 或支付凭据
 *   - 状态文件权限 0o600
 *
 * 退出码：0 成功；1 协议或网络错误；2 用法或配置错误
 */

import { execFile } from 'node:child_process';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import crypto from 'node:crypto';

const execFileAsync = promisify(execFile);

const TIMEOUT_MS = Number(process.env.OKR_PAID_TIMEOUT_MS) > 0 ? Number(process.env.OKR_PAID_TIMEOUT_MS) : 20000;
const ALIPAY_CMD = process.env.ALIPAY_AIPAY_CMD || 'alipay-aipay';

function resourceUrl() {
  const url = (process.env.OKR_PAID_RESOURCE_URL || '').trim();
  if (!url) {
    fail(2, '未配置 OKR_PAID_RESOURCE_URL。请先按 references/setup-guide.md 完成付费服务接入。');
  }
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    fail(2, `OKR_PAID_RESOURCE_URL 不是合法 URL：${url}`);
  }
  if (parsed.protocol !== 'https:') {
    fail(2, 'OKR_PAID_RESOURCE_URL 必须是 https 地址，拒绝 http 与非网络协议');
  }
  return url;
}

function fail(code, message) {
  process.stderr.write(`${message}\n`);
  process.exit(code);
}

function parseArgs(argv) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith('--')) continue;
    const key = token.slice(2);
    const next = argv[index + 1];
    if (next === undefined || next.startsWith('--')) {
      options[key] = true;
    } else {
      options[key] = next;
      index += 1;
    }
  }
  return options;
}

async function ensureStateDir(dir) {
  if (typeof dir !== 'string' || !dir) {
    fail(2, '缺少 --state-dir 参数');
  }
  const resolved = path.resolve(dir);
  await fs.mkdir(resolved, { recursive: true, mode: 0o700 });
  return resolved;
}

async function writeSecret(file, value) {
  await fs.writeFile(file, value, { encoding: 'utf8', mode: 0o600 });
}

async function readIfExists(file) {
  try {
    return (await fs.readFile(file, 'utf8')).trim();
  } catch (error) {
    if (error.code === 'ENOENT') return '';
    throw error;
  }
}

function randomId() {
  return crypto.randomBytes(8).toString('hex');
}

function extractHeader(headersText, name) {
  const match = headersText.match(new RegExp(`^${name}:\\s*([^\\r\\n]+)`, 'im'));
  return match ? match[1].trim() : '';
}

async function curlRequest({ url, method, body, headers }) {
  const headerFile = path.join(os.tmpdir(), `okr-paid-hdr-${randomId()}`);
  const bodyFile = path.join(os.tmpdir(), `okr-paid-body-${randomId()}`);
  const args = ['-sS', '-D', headerFile, '--connect-timeout', '10', '-o', bodyFile, '-w', 'HTTP_STATUS:%{http_code}', '-X', method];
  for (const header of headers) {
    args.push('-H', header);
  }
  if (body !== null) {
    args.push('-H', 'Content-Type: application/json', '--data-binary', body);
  }
  args.push(url);

  let stdout = '';
  try {
    const result = await execFileAsync('curl', args, { timeout: TIMEOUT_MS, maxBuffer: 8 * 1024 * 1024, windowsHide: true });
    stdout = result.stdout || '';
  } catch (error) {
    if (error.code === 'ENOENT') {
      fail(1, '未找到 curl，请先安装 curl 并加入 PATH');
    }
    if (error.signal === 'SIGTERM' || error.killed) {
      fail(1, `请求超时（${TIMEOUT_MS} ms），未确认支付状态时不要重新下单`);
    }
    stdout = (error.stdout || '').toString();
    if (!stdout.includes('HTTP_STATUS:')) {
      fail(1, `请求失败：${error.message}；未确认支付状态时不要重新下单`);
    }
  }

  const status = Number((stdout.match(/HTTP_STATUS:(\d+)/) || [])[1] || 0);
  const headersText = await readIfExists(headerFile);
  const responseBody = await readIfExists(bodyFile);
  await Promise.all([fs.rm(headerFile, { force: true }), fs.rm(bodyFile, { force: true })]);
  return { status, headersText, body: responseBody };
}

async function commandProbe(stateDir, options) {
  const url = resourceUrl();
  let payload = options.payload;
  if (!payload) fail(2, 'probe 需要 --payload，内容为采集完成的 JSON 字符串或 @文件路径');
  if (payload.startsWith('@')) {
    payload = await fs.readFile(path.resolve(payload.slice(1)), 'utf8');
  }

  const response = await curlRequest({ url, method: 'POST', body: payload, headers: [] });
  await writeSecret(path.join(stateDir, 'request.json'), payload);
  await writeSecret(path.join(stateDir, 'headers.txt'), response.headersText);

  if (response.status === 200) {
    process.stdout.write(`${response.body}\n`);
    return;
  }
  if (response.status === 0) {
    fail(1, '无法连接付费服务。请确认 OKR_PAID_RESOURCE_URL 可达；未确认支付状态时不要重新下单。');
  }
  if (response.status !== 402) {
    fail(1, `资源接口返回 HTTP ${response.status}，预期 402。响应片段：${response.body.slice(0, 300)}`);
  }

  const weixinpayRequired = extractHeader(response.headersText, 'WeixinPay-Required');
  const outTradeNo = extractHeader(response.headersText, 'X-Out-Trade-No');
  const paymentNeeded = extractHeader(response.headersText, 'Payment-Needed');

  if (!weixinpayRequired && !paymentNeeded) {
    fail(1, 'HTTP 402 响应缺少 WeixinPay-Required 与 Payment-Needed，无法发起支付');
  }

  const channel = weixinpayRequired ? 'weixinpay' : 'alipay';
  await writeSecret(path.join(stateDir, 'channel.txt'), channel);
  if (weixinpayRequired) await writeSecret(path.join(stateDir, 'weixinpay-required.txt'), weixinpayRequired);
  if (outTradeNo) await writeSecret(path.join(stateDir, 'out-trade-no.txt'), outTradeNo);
  if (paymentNeeded) await writeSecret(path.join(stateDir, 'payment-needed.txt'), paymentNeeded);
  await writeSecret(path.join(stateDir, 'resource-url.txt'), url);

  process.stdout.write(`${JSON.stringify({
    status: 402,
    channel,
    has_out_trade_no: Boolean(outTradeNo),
    state_dir: stateDir,
    body_excerpt: response.body.slice(0, 300),
  }, null, 2)}\n`);
}

async function commandPay(stateDir, options) {
  const channel = (await readIfExists(path.join(stateDir, 'channel.txt'))) || options.channel;
  const sessionId = options['session-id'] || path.basename(stateDir);

  if (channel === 'weixinpay') {
    const paymentCode = await readIfExists(path.join(stateDir, 'weixinpay-required.txt'));
    const outTradeNo = await readIfExists(path.join(stateDir, 'out-trade-no.txt'));
    if (!paymentCode) fail(1, '状态目录缺少 weixinpay-required.txt，请先运行 probe');
    process.stdout.write(`${JSON.stringify({
      channel: 'weixinpay',
      action: 'call_weixinpay_pay',
      paymentCode,
      outTradeNo,
      next: 'Agent 调用支付工具传入 paymentCode；支付成功后必须执行 complete 并带上 outTradeNo',
    }, null, 2)}\n`);
    return;
  }

  const paymentNeededFile = path.join(stateDir, 'payment-needed.txt');
  const paymentNeeded = await readIfExists(paymentNeededFile);
  if (!paymentNeeded) fail(1, '状态目录缺少 payment-needed.txt，请先运行 probe');
  const resource = (await readIfExists(path.join(stateDir, 'resource-url.txt'))) || resourceUrl();

  const args = [
    '402-buyer-pay',
    '--session-id', sessionId,
    '-f', paymentNeededFile,
    '-r', resource,
    '--intent-summary', options.intent || 'OKR 付费文档生成',
  ];
  try {
    const result = await execFileAsync(ALIPAY_CMD, args, { timeout: TIMEOUT_MS, maxBuffer: 4 * 1024 * 1024, windowsHide: true });
    process.stdout.write(`${result.stdout || ''}`);
  } catch (error) {
    if (error.code === 'ENOENT') {
      fail(1, `未找到 ${ALIPAY_CMD}。请先运行 npx -y @alipay/alipay-aipay@latest install，或用 ALIPAY_AIPAY_CMD 指定命令名`);
    }
    fail(1, `支付宝收银失败：${error.message}`);
  }
}

async function commandComplete(stateDir, options) {
  const channel = (await readIfExists(path.join(stateDir, 'channel.txt'))) || options.channel;
  const payload = (await readIfExists(path.join(stateDir, 'request.json'))) || '';
  if (!payload) fail(1, '状态目录缺少 request.json，请先运行 probe');

  if (channel === 'weixinpay') {
    const paymentCode = await readIfExists(path.join(stateDir, 'weixinpay-required.txt'));
    const outTradeNo = options['trade-no'] || (await readIfExists(path.join(stateDir, 'out-trade-no.txt')));
    if (!outTradeNo) fail(1, '缺少 --trade-no（X-Out-Trade-No）。不携带订单号重试将永远拿不到付费内容');
    const url = (await readIfExists(path.join(stateDir, 'resource-url.txt'))) || resourceUrl();
    const headers = ['X-Out-Trade-No: ' + outTradeNo];
    if (paymentCode) headers.push('WeixinPay-Required: ' + paymentCode);
    const response = await curlRequest({ url, method: 'POST', body: payload, headers });
    if (response.status !== 200) {
      fail(1, `重试返回 HTTP ${response.status}。若已扣款，请携带同一订单号重试，不要重新下单。响应片段：${response.body.slice(0, 300)}`);
    }
    process.stdout.write(`${response.body}\n`);
    return;
  }

  const tradeNo = options['trade-no'];
  if (!tradeNo) fail(1, '支付宝通道 complete 需要 --trade-no');
  const resource = (await readIfExists(path.join(stateDir, 'resource-url.txt'))) || resourceUrl();
  try {
    const query = await execFileAsync(ALIPAY_CMD, ['402-buyer-query', '--session-id', options['session-id'] || path.basename(stateDir), '--trade-no', tradeNo, '-r', resource], { timeout: TIMEOUT_MS, maxBuffer: 8 * 1024 * 1024, windowsHide: true });
    process.stdout.write(`${query.stdout || ''}`);
    const ack = await execFileAsync(ALIPAY_CMD, ['402-buyer-ack', '--trade-no', tradeNo], { timeout: TIMEOUT_MS, maxBuffer: 4 * 1024 * 1024, windowsHide: true });
    process.stderr.write(`履约回执已发送：${(ack.stdout || '').trim()}\n`);
  } catch (error) {
    if (error.code === 'ENOENT') {
      fail(1, `未找到 ${ALIPAY_CMD}。请先运行 npx -y @alipay/alipay-aipay@latest install`);
    }
    fail(1, `查询或履约失败：${error.message}。若已扣款，请用同一 trade-no 重试，不要重新下单`);
  }
}

async function main() {
  const [command, ...rest] = process.argv.slice(2);
  const options = parseArgs(rest);

  if (!['probe', 'pay', 'complete'].includes(command)) {
    fail(2, '用法：okr-paid.mjs <probe|pay|complete> --state-dir <目录> [--payload <JSON 或 @文件>] [--trade-no <订单号>] [--session-id <会话 ID>]');
  }

  const stateDir = await ensureStateDir(options['state-dir']);
  if (command === 'probe') return commandProbe(stateDir, options);
  if (command === 'pay') return commandPay(stateDir, options);
  return commandComplete(stateDir, options);
}

main().catch((error) => {
  process.stderr.write(`${error.message}\n`);
  process.exit(1);
});
