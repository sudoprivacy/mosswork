# SkillPay 接入配置指南

把本 Skill 变成能自动收款的 Pay Skill 需要三件事：一个公网 HTTPS 服务、一条 A2M 402 支付通道、一组本机环境变量。核验日期 2026-09-04，依据 SkillHub 官方教程与支付宝 AI 付官方文档。

## 依赖清单对照

`skill-dependencies.json` 中的依赖 ID 与本文章节的对应关系：

| 依赖 ID | 类型 | 必需 | 对应章节 |
|---|---|---|---|
| `paid-okr-service` | api | 是 | 二、付费资源服务 |
| `weixinpay-mcp` | mcp | 否 | 三、微信支付通道（企业） |
| `alipay-bot` | cli | 否 | 四、支付宝通道（个人） |
| `python-runtime` | runtime | 否 | 六、Python 运行环境 |

## 一、SkillPay 入驻

| 项目 | 内容 |
|---|---|
| 用途 | 获得发布 Pay Skill 并收款的资格 |
| 支持版本 | 个人：手机号验证码即可；企业：企业认证 + 微信商户号绑定 |
| 官方主页 | https://skillhub.cn |
| 官方文档 | https://skillhub.cn/tutorials#skillpay-overview |
| 登录网址 | https://skillhub.cn |
| 个人入驻路径 | 商户中心 → SkillPay 个人入驻 → 手机号验证码 |
| 企业入驻路径 | 商户中心 → 企业认证 → 商户入驻 → 前往微信商户平台绑定 |
| 凭据存储 | 入驻状态由 SkillHub 托管，本地不保存任何支付凭据 |
| 验证方式 | 商户中心显示入驻状态为「已入驻」 |
| 轮换与撤销 | 商户中心 → 入驻管理 → 解除绑定 |

个人不需要营业执照，不需要企业认证。当前个人渠道只开放支付宝，企业渠道走微信支付。

## 二、付费资源服务

Pay Skill 的核心是「付费内容由你的服务交付」，因此必须有一个公网 HTTPS 接口。本 Skill 约定接口为 `POST /okr/invoke`。

| 项目 | 内容 |
|---|---|
| 用途 | 接收采集结果，返回 402 账单或付费 OKR 文档 |
| 官方主页 | https://aipay.alipay.com |
| 官方文档 | https://aipay.alipay.com/open-flow/tech |
| 下载地址 | https://skillhub.cn/tutorials#personal-upgrade-install |
| 所需权限 | 支付宝：alipay.aipay.agent.payment.verify、alipay.aipay.agent.fulfillment.confirm |
| 凭据存储 | AIPAY_APP_ID、AIPAY_PRIVATE_KEY、AIPAY_ALIPAY_PUBLIC_KEY、AIPAY_SERVICE_ID 存于服务端环境变量或 KMS |
| 轮换与撤销 | 重新生成密钥对并上传新公钥；开放平台删除旧公钥即撤销 |

### 配置步骤

1. 准备公网 HTTPS 服务，暴露 `POST /okr/invoke`。请求体为本 Skill 采集结果 JSON，未付费时返回 `HTTP 402`。
2. 用支付宝官方 AI 付 Skill 生成 A2M 代码，不要手写：

   ```text
   npx -y @alipay/alipay-aipay@latest install
   ```

   安装后在 AI 编程工具中说「接入支付宝按量付费」，并指定 `/okr/invoke` 接口。Skill 会自动生成 402 逻辑并完成沙箱联调。
3. 沙箱联调通过后，在支付宝开放平台签约「AI 按量付费」，并用密钥工具生成 RSA2 应用公私钥，上传应用公钥换取支付宝公钥。
4. 在 AI 付站点注册服务，取得 `API_` 开头的 serviceId，**服务单价必须与 402 账单金额一致**，否则用户无法支付。单价范围 0.01—50 元/次。
5. 替换为生产密钥，部署到公网，配置服务端环境变量。
6. 本机配置 `OKR_PAID_RESOURCE_URL` 指向该接口的完整 HTTPS 地址。
7. 把 `skill-dependencies.json` 中 `service-reachable` 检查的 `url` 替换为同一地址，否则环境检查只能判断配置是否存在，无法判断服务是否在线。

### 验证方式

```text
curl -s -o /dev/null -w '%{http_code}' -X POST https://你的域名/okr/invoke -H 'Content-Type: application/json' -d '{"query":"probe"}'
```

返回 402 且响应头含 `Payment-Needed`（支付宝通道）或 `WeixinPay-Required`（微信通道）即为接入正确。

### 安全要求

- 服务端必须调用 `alipay.aipay.agent.payment.verify` 校验 Payment-Proof；无效或过期凭证一律拒绝。
- 资源交付后必须调用 `alipay.aipay.agent.fulfillment.confirm`，且保持幂等。
- 应用私钥只存服务端，禁止写入代码仓库、日志或发送给 Agent。Java 用 PKCS#8 格式，非 Java 用 PKCS#1 格式。
- 沙箱 serviceId `api_mock_service_id` 禁止用于生产。
- 生产环境必须校验本地订单、金额与资源的关系。

## 三、微信支付通道（企业）

| 项目 | 内容 |
|---|---|
| 用途 | Agent 拉起微信支付收银台 |
| 官方主页 | https://pay.weixin.qq.com |
| 官方文档 | https://skillhub.cn/tutorials#agent-pay-onboard |
| 登录网址 | https://pay.weixin.qq.com |
| 前置条件 | 企业认证通过 + 微信商户号已入驻 SkillHub |
| 凭据存储 | 由微信支付侧托管，本地不存储支付凭据 |
| 验证方式 | 对话中发起一次小额支付，能拉起二维码且付款后返回交易号 |
| 轮换与撤销 | 微信「我」-「服务」-「钱包」-「AI 专属卡」内解绑对应智能体 |

企业侧改造分四步：生成开发者密钥（`PUB_KEY_` 开头的 pub_key_id + RSA 2048 私钥）→ 微信支付下单拿 `code_url` → 调用 X402 AI 预下单换 `payment_code` → 通过 `WeixinPay-Required` 响应头返回给 Agent。

AI 预下单签名的两个高频坑：签名串固定 5 行且**最后一行也要带换行**；AI 预下单用 SkillHub 开发者密钥签名（SKILLHUB-SHA256-RSA2048），**不是**微信支付 API 证书。

## 四、支付宝通道（个人）

| 项目 | 内容 |
|---|---|
| 用途 | Agent 拉起支付宝收银台并完成验付、履约 |
| 官方主页 | https://open.alipay.com |
| 官方文档 | https://aipay.alipay.com/open-flow/tech |
| 下载地址 | https://open.alipay.com/develop/secret-key-tool |
| 登录网址 | https://open.alipay.com |
| Token/Key 入口 | https://open.alipay.com/develop/secret-key-tool |
| 登录后路径 | 我的应用 → 应用 ID；产品中心 → 签约「AI 按量付费」；AI 付站点 → 注册服务 |
| 所需权限 | alipay.aipay.agent.payment.verify、alipay.aipay.agent.fulfillment.confirm |

### 配置步骤

1. 在项目目录执行 `npx -y @alipay/alipay-aipay@latest install`，安装支付宝官方 AI 付 Skill。实际生成的可执行文件名为 `alipay-aipay`。
2. 对 Agent 说「接入支付宝按量付费」并指定 `/okr/invoke`，由 Skill 生成 402 逻辑并跑通沙箱。
3. 开放平台创建应用，签约「AI 按量付费」（个人账号，企业账号需走商家平台单独开通）。
4. 密钥工具生成 RSA2 应用公私钥，上传应用公钥换取支付宝公钥。
5. AI 付站点注册服务，取得 serviceId。
6. 配置环境变量：`AIPAY_APP_ID`、`AIPAY_PRIVATE_KEY`（或 `AIPAY_PRIVATE_PKCS_KEY`）、`AIPAY_PUBLIC_KEY`、`AIPAY_ALIPAY_PUBLIC_KEY`、`AIPAY_SERVICE_ID`。
7. 部署公网 HTTPS，用 0.01 元发起真实交易，在支付宝商家中心查到订单即完成线上验证。

## 五、本机环境变量

| 变量 | 必需 | 说明 |
|---|---|---|
| `OKR_PAID_RESOURCE_URL` | 是 | 付费接口完整 HTTPS 地址，本 Skill 只接受 https |
| `ALIPAY_AIPAY_CMD` | 否 | 支付宝 CLI 命令名，默认 `alipay-aipay` |
| `OKR_PAID_TIMEOUT_MS` | 否 | 单次网络超时，默认 20000 |

环境变量只在本机生效，不写入 Skill 包。私钥类变量属于服务端，不在本机配置。

## 六、Python 运行环境

| 项目 | 内容 |
|---|---|
| 用途 | 运行 scripts/check_okr.py 与 scripts/check_environment.py |
| 官方主页 | https://www.python.org |
| 官方文档 | https://docs.python.org/zh-cn/3/ |
| 下载地址 | https://www.python.org/downloads/ |
| 最低版本 | 3.10 |
| 凭据 | 不需要 |
| 配置步骤 | 安装 Python 3.10 及以上；确认 python 或 python3 可在终端直接执行 |
| 验证方式 | `python --version` 输出 3.10 及以上 |
| 轮换与撤销 | 卸载 Python 即移除该能力 |

两个脚本均为只读，仅用标准库：check_okr.py 只读取输入文件，不写文件、不联网、不启动子进程；check_environment.py 只在显式传入 `--network` 时执行匿名 HTTPS 健康探测。

## 七、通道选择

| 条件 | 建议通道 |
|---|---|
| 本智能体已内置名称含 `weixinpay_` 的支付工具 | 微信支付，无需额外安装 |
| 个人开发者、无营业执照 | 支付宝，手机号即可入驻 |
| 已有微信商户号的企业 | 微信支付 |

两个通道都不可用时，付费文档流程终止，只交付免费部分。
