---
name: skillhub-skill-xiongan-sushui-9-9-hm-to-xaiot
description: "读取温湿度传感器并通过HTTPS上传到雄安物联网统一开放平台。触发词：上传温湿度、传感器数据接入雄安云、上报温湿度、温湿度上云、数据上传平台等。"
---

# 雄安素水-温湿度数据接入雄安云

通过 Modbus RTU 读取温湿度传感器，以 HTTPS POST 将数据上传到雄安物联网统一开放平台。

## 传感器参数

| 参数 | 值 |
|------|-----|
| 设备地址 | 1 |
| 波特率 | 9600 |
| 校验位 | None（N） |
| 数据位 | 8 |
| 停止位 | 1 |
| 协议 | Modbus RTU |

## 寄存器定义

| 寄存器地址 | 含义 | 数据类型 |
|-----------|------|---------|
| 0 | 温度 × 10（整数） | 16-bit signed int |
| 1 | 湿度 × 10（整数） | 16-bit unsigned int |
| 2-3 | 温度（浮点大端） | 32-bit float（big-endian） |
| 4-5 | 湿度（浮点大端） | 32-bit float（big-endian） |

## 物联网平台参数

| 参数 | 值 |
|------|-----|
| 平台 | 雄安物联网统一开放平台 |
| 上传方式 | HTTPS POST |
| URL | `https://https.xaiotjr.cn:1667/thing/json/up` |
| Product ID | 1827 |
| 温度 pid | 37122 |
| 湿度 pid | 37124 |

### REPORT_TOKEN 说明

`REPORT_TOKEN` 由 `xaiot_token.py` 算法生成，基于设备 sign 密钥计算 HMAC-SHA1 签名。

示例（萍河-2设备，有效期至 2027-05-06）：
```
version=2018-10-31&res=products%2F1827%2Fdevices%2F88.190.000565%252F060000000000702&et=1809607137&method=sha1&sign=qqa%2F6IZiUUe6uiYsh11e%2B4Kmk6Q%3D
```

如果 token 过期，用 `xaiot_token.py`（位于 `E:\dev\MicroPython\雄安物联网\xaiot_token\xaiot_token.py`）重新生成：修改 `et` 为未来时间戳，运行脚本即可。

## 执行

本 skill 附带 batch JSON 文件 `scripts/upload_to_cloud.json`。

**严格按照以下格式调用 `run_tool_batch`，使用 `file_path` 加载文件执行。不要自行构造 `actions` 列表内联传入。**

`run_tool_batch` 的 `file_path` 需要**绝对路径**。你在读取本 SKILL.md 时看到的目录路径即为本 skill 的绝对目录，请用它拼接出完整的 `file_path`。

```
run_tool_batch(
  file_path="<本skill目录>/scripts/upload_to_cloud.json",
  args={
    "skill_dir": "<本skill目录>",
    "com_port": "COM19",
    "device_id": "1",
    "baudrate": "9600",
    "report_token": "version=2018-10-31&res=products%2F1827%2Fdevices%2F88.190.000565%252F060000000000702&et=1809607137&method=sha1&sign=qqa%2F6IZiUUe6uiYsh11e%2B4Kmk6Q%3D"
  }
)
```

### Batch 参数

逐项说明 `args` 中的每个参数：

* `skill_dir`：本 skill 的绝对目录路径。你在读取本 SKILL.md 时看到的目录路径。**必须传入实际路径。**
* `com_port`：CH340 串口号。默认 `COM19`。通过 `mode` 命令或设备管理器查看。
* `device_id`：Modbus 设备地址。默认 `1`。
* `baudrate`：波特率。默认 `9600`。通常不需要修改。
* `report_token`：雄安云设备上报 token。**必须传入完整的 token 字符串。** 示例值对应萍河-2设备（88.190.000565/060000000000702），有效期至 2027-05-06。如过期需重新生成。

### Batch 失败处理

如果 `run_tool_batch` 执行失败（返回 `ok: false` 或中途报错），请：

1. 检查所有参数是否已传入实际值，尤其 `skill_dir`、`com_port`、`report_token`。
2. 如果串口无法打开，检查 COM 口是否被占用，或尝试其他 CH340 端口。
3. 如果提示 `ModuleNotFoundError`，执行 `pip install pymodbus pyserial -q`。
4. 如果上传超时，说明当前网络无法访问 `https.xaiotjr.cn`（雄安专网），需切换到现场网络或连接 VPN。
5. 如果 token 过期，用 `xaiot_token.py` 重新生成。
6. 如果仍然失败，参照下方「分步参考」手动执行。

### 分步参考

以下是 batch 中每一步的详细说明，仅在需要调试或手动执行时参考：

1. **安装依赖**：`pip install pymodbus pyserial -q`
2. **检查串口**：`mode COM19` 确认 CH340 串口存在
3. **读取并上传**：调用 `python scripts/read_and_upload.py <COM> <设备地址> <波特率> <token>`，一次性完成传感器读取和数据上传
4. **查看结果**：成功返回 HTTP 200 和平台响应；超时说明网络不通

### 注意事项

- pymodbus 3.x 使用 `device_id`（非 `slave`/`unit`）、`bytesize`（非 `data_bits`）、`stopbits`（非 `stop_bits`）
- 上传忽略 SSL 证书验证（HaaS 设备通常用自签名证书）
- 服务器端口为 **1667**（非 8543）
- 网络环境要求：需能访问雄安 IoT 专网 `https.xaiotjr.cn`

**执行方式提醒**：触发本 skill 时，直接使用上方的 `run_tool_batch(file_path=..., args=...)` 调用即可完成全部流程。只有当 batch 执行失败时，才参照「Batch 失败处理」中的降级方案。