---
name: skillhub-skill-query-neo4j-graph-data-from-agent-workflows-through-mcp
description: "将MCP兼容代理连接到Neo4j，以便它们能够检查图模式、运行Cypher查询、管理图内存，并从聊天中操作Aura实例。"
---

# 通过MCP从代理工作流中查询Neo4j图数据

Connect MCP-compatible agents to Neo4j so they can inspect graph schemas, run Cypher queries, manage graph memory, and operate Aura instances from chat.

## Prerequisites

Neo4j database or Aura account, APOC for schema inspection, Python package or uvx, MCP-compatible client

## Installation

Requirements and caveats from upstream:
- **Requirement**: Requires the [APOC plugin](https://neo4j.com/docs/apoc/current/installation/) to be installed and enabled on the Neo4j instance for schema inspection.

Basic usage or getting-started notes:
- To run a server in HTTP mode, use the --transport http flag:

- Source: https://github.com/1991513ccie-png/skills
- Extracted from upstream docs: https://raw.githubusercontent.com/neo4j-contrib/mcp-neo4j/HEAD/README.md

## Documentation

- https://neo4j.com/developer/genai-ecosystem/model-context-protocol-mcp/
