#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
license_gate.py —— 授权闸门验证器（可安全分发）

本文件只内嵌【作者公钥】，只能验证签名、不能伪造令牌。
作者用 issue_license.py（配合本地私钥）签发令牌后，分发给核验过的银行客户。
客户部署的系统在启动时 / 每次请求前调用 verify_license()，校验：
  1) 签名有效（非作者私钥签发 → 拒绝）
  2) 未过期（exp）
  3) 授权域名匹配（aud，防止令牌被挪到别的站点）
  4) 可选：吊销清单（REVOKE_URL，作者可远程吊销失窃令牌）

依赖：cryptography（本项目的 Flask 后端已依赖，详见 requirements）
"""

import base64
import json
import os
import time

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization

# ──────────────────────────────────────────────────────────────
# 作者公钥（SAFE TO SHIP —— 仅用于验签，无法据此伪造令牌）
# 如需更换密钥对，用 issue_license.py gen_keypair 重新生成，并把新公钥粘贴到此。
# ──────────────────────────────────────────────────────────────
_AUTHOR_PUBLIC_PEM = b"""-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEABQgO4IClHQ+RvamhhRQObhPqeingh2rqyVfAAFde9QY=
-----END PUBLIC KEY-----
"""

# 可选吊销端点（作者自建，用于远程吊销令牌）。留空 = 不启用电话回家。
# 启用后请同时设置 REVOKE_FAIL_CLOSED：True=查不到/网络异常时拒绝服务（更严）；
#                                     False=网络异常时放行（避免作者服务宕机导致客户停摆）。
REVOKE_URL = ""            # 例： "https://license.<yourdomain>/revoke"
REVOKE_FAIL_CLOSED = True
_HTTP_TIMEOUT = 5


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _b64d(s: str) -> bytes:
    s += "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s)


def _load_public_key():
    return serialization.load_pem_public_key(_AUTHOR_PUBLIC_PEM)


def _is_revoked(lic_id: str) -> bool:
    """最佳努力的吊销检查；仅在 REVOKE_URL 非空时生效。

    端点语义：已吊销 -> HTTP 200 + body 首字节∈{1,Y,t}；未吊销 -> HTTP 404。
    注意：urlopen 遇 4xx/5xx 会抛 HTTPError，必须单独捕获——否则未吊销(404)
    会被宽泛 except 误判为“网络异常”而按 REVOKE_FAIL_CLOSED 返回吊销，导致
    所有带 REVOKE_URL 的验证都被错误拒绝。
    """
    if not REVOKE_URL:
        return False
    try:
        import urllib.request
        import urllib.error
        import urllib.parse
        url = REVOKE_URL if REVOKE_URL.endswith("/") else REVOKE_URL + "/"
        req = urllib.request.Request(
            url + urllib.parse.quote(lic_id),
            headers={"User-Agent": "license-gate/1.0"},
        )
        try:
            with urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT) as r:
                return r.status == 200 and r.read(1) in (b"1", b"Y", b"t")
        except urllib.error.HTTPError:
            # 4xx/5xx（典型 404 未知令牌）= 未被吊销
            return False
        except Exception:
            # 其他网络/服务异常时的策略由 REVOKE_FAIL_CLOSED 决定
            return REVOKE_FAIL_CLOSED
    except Exception:
        return REVOKE_FAIL_CLOSED


def verify_license(license_path: str, expected_aud: str = None):
    """
    返回 (ok: bool, info: dict|str)
    ok=False 时 info 为拒绝原因字符串；ok=True 时 info 为令牌载荷 dict。
    """
    if not os.path.exists(license_path):
        return False, "缺失授权文件 license.key（请联系作者获取）"

    raw = ""
    try:
        with open(license_path, "r", encoding="utf-8") as f:
            raw = f.read().strip()
        payload_b64, sig_b64 = raw.split(".")
    except ValueError:
        return False, "授权文件格式错误（应为 payload.signature）"
    except Exception as e:
        return False, "读取授权文件失败：%s" % e

    try:
        payload = json.loads(_b64d(payload_b64))
        sig = _b64d(sig_b64)
    except Exception:
        return False, "授权文件内容无法解析"

    # 1) 签名校验（核心：非作者私钥签发必失败）
    try:
        _load_public_key().verify(sig, payload_b64.encode("utf-8"))
    except InvalidSignature:
        return False, "签名无效（非授权颁发，疑似伪造）"
    except Exception:
        return False, "公钥加载/验签异常"

    # 2) 过期校验
    now = int(time.time())
    exp = payload.get("exp", 0)
    if exp and exp < now:
        return False, "授权已过期（到期 %s）" % time.strftime("%Y-%m-%d", time.localtime(exp))

    # 3) 域名绑定校验（防令牌挪作他用）
    aud = payload.get("aud")
    if expected_aud and aud != expected_aud:
        return False, "授权域名不匹配（令牌绑定 %s，当前 %s）" % (aud, expected_aud)

    # 4) 吊销校验（可选）
    if _is_revoked(payload.get("lic", "")):
        return False, "授权已被作者吊销"

    return True, payload


def license_status_text(license_path: str, expected_aud: str = None) -> str:
    """供 H5 / 看板展示的简短状态文本。"""
    ok, info = verify_license(license_path, expected_aud)
    if ok:
        p = info
        return "已授权 · 许可方 %s · 到期 %s" % (
            p.get("org", "-"),
            time.strftime("%Y-%m-%d", time.localtime(p.get("exp", 0))),
        )
    return "未授权：%s" % info


if __name__ == "__main__":
    import sys
    lp = sys.argv[1] if len(sys.argv) > 1 else "license.key"
    aud = sys.argv[2] if len(sys.argv) > 2 else None
    ok, info = verify_license(lp, aud)
    print("OK" if ok else "DENIED", "->", info)
    sys.exit(0 if ok else 1)
