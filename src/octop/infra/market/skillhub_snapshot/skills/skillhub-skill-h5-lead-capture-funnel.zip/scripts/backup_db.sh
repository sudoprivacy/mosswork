#!/bin/bash
# 加密备份脚本（脱敏模板）
# 每日 3:30 由 cron 调用：数据库全库 + 代码文件 + H5 前端 + TDE keyring，全部 openssl 加密。
#
# 替换项：
#   <DB_NAME>          数据库名（或留空备份全库）
#   <APP_DIR>          应用目录 /opt/<APP_DIR>
#   <H5_DIR>           前端目录 /www/wwwroot/h5_auth
#   <BACKUP_KEY>       备份加密密钥文件 /opt/<APP_DIR>/.backup_key
#   <DB_ROOT_PASSWORD> MySQL root 密码
#   <AUTH_API_USER>    应用库用户（用于 180 天清理）
#   <AUTH_API_PASSWORD> 应用库密码
#
set -u

BACKUP_DIR="/www/backup/database"
CODE_DIR="/www/backup/code"
DATE=$(date +%Y%m%d_%H%M%S)
export MYSQL_PWD="<DB_ROOT_PASSWORD>"
KEY_FILE="<BACKUP_KEY>"

mkdir -p "$BACKUP_DIR" "$CODE_DIR"

# 生成密钥（首次）
if [ ! -f "$KEY_FILE" ]; then
    openssl rand -base64 48 > "$KEY_FILE" 2>/dev/null
    chmod 600 "$KEY_FILE"
fi
chmod 600 "$KEY_FILE" 2>/dev/null

# PBKDF2 支持探测
if openssl enc -aes-256-cbc -pbkdf2 -help 2>&1 | grep -q "pbkdf2"; then
    PBKDF="-pbkdf2"
else
    PBKDF=""
fi

# 1. 数据库备份（加密）
for DB in $(mysql -uroot -N -B -e "SHOW DATABASES;" | grep -v -E "information_schema|performance_schema|mysql|sys"); do
    OUT="${BACKUP_DIR}/${DB}_${DATE}.sql.gz.enc"
    if mysqldump -uroot --single-transaction --routines --triggers --databases "$DB" 2>/dev/null \
        | gzip \
        | openssl enc -aes-256-cbc -salt $PBKDF -pass file:"$KEY_FILE" -out "$OUT" 2>/dev/null; then
        chmod 600 "$OUT"
    fi
done

# 1.5 TDE keyring 备份
KEYRING_SRC="/www/server/data/keyring"
if [ -f "$KEYRING_SRC" ]; then
    openssl enc -aes-256-cbc -salt $PBKDF -pass file:"$KEY_FILE" \
        -in "$KEYRING_SRC" -out "${BACKUP_DIR}/keyring_${DATE}.enc" 2>/dev/null \
        && chmod 600 "${BACKUP_DIR}/keyring_${DATE}.enc"
fi

# 2. 代码备份（加密）
for f in app.py db_cleanup.py notification.py; do
    SRC="/opt/<APP_DIR>/$f"
    [ -f "$SRC" ] || continue
    openssl enc -aes-256-cbc -salt $PBKDF -pass file:"$KEY_FILE" -in "$SRC" -out "${CODE_DIR}/${f}_${DATE}.enc" 2>/dev/null \
        && chmod 600 "${CODE_DIR}/${f}_${DATE}.enc"
done

# 2.5 H5 前端备份（加密）
H5_DIR="<H5_DIR>"
if [ -d "$H5_DIR" ]; then
    tar -czf - -C "$(dirname "$H5_DIR")" "$(basename "$H5_DIR")" 2>/dev/null \
        | openssl enc -aes-256-cbc -salt $PBKDF -pass file:"$KEY_FILE" -out "${CODE_DIR}/h5_auth_${DATE}.tar.gz.enc" 2>/dev/null \
        && chmod 600 "${CODE_DIR}/h5_auth_${DATE}.tar.gz.enc"
fi

# 3. 清理旧备份（30 天）
find "$BACKUP_DIR" -name "*.sql.gz.enc" -mtime +30 -delete
find "$CODE_DIR"   -type f -mtime +30 -delete

# 4. 日志
echo "[$(date)] Backup complete(encrypted)" >> /var/log/mysql_backup.log

# 5. 180 天访问日志清理（合规留存上限）
mysql -u <AUTH_API_USER> -p'<AUTH_API_PASSWORD>' <DB_NAME> \
    -e "DELETE FROM visitor_access_logs WHERE visit_time < DATE_SUB(NOW(), INTERVAL 180 DAY);"
