#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_regulated_banks.py —— 监管名单刷新 / 补全助手（本地运行）

用途：从国家金融监管总局官网重新抓取《银行业金融机构法人名单（截至2025年12月末）》
      并解析为 regulated_banks.json，补全 sandbox 中 PyPDF2 无法提取的 22 个图片页。

数据源（官方，合计 3619 家法人）：
  https://www.nfra.gov.cn/cn/view/pages/governmentDetail.html?docId=1268142

用法：
  python fetch_regulated_banks.py                 # 自动：抓详情页→定位PDF→下载→解析→合并
  python fetch_regulated_banks.py --pdf a.pdf    # 直接解析本地 PDF
  python fetch_regulated_banks.py --url https://...pdf   # 直接下载指定 PDF URL

  --out regulated_banks.json   # 输出路径（默认本脚本同目录）
  --no-ocr                     # 跳过 OCR（图片页将被记为 skipped，不报错）

解析策略：
  * 文本页：PyPDF2 提取 + 正则（机构编码 A0001H... + 中文机构名），sandbox 即可运行。
  * 图片页：若本地已装 pytesseract + pdf2image（需 poppler），则 OCR 后解析；否则跳过并报告。
  * 合并：以机构编码为主键，与已有 regulated_banks.json 合并（新覆盖旧、不丢已有）。

注意：本脚本仅生成「辅助校验」用的名单 JSON，真实准入闸门仍是 corpid 白名单，
      绝不以机构名称是否含『银行』等字眼作为准入依据。
"""

import os
import re
import sys
import json
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(HERE, "regulated_banks.json")
DETAIL_URL = "https://www.nfra.gov.cn/cn/view/pages/governmentDetail.html?docId=1268142"

NAME_RE = re.compile(r"^(\d+)\s+(.*)$")
CODE_RE = re.compile(r"[A-Z]\d{4}H\d{9}")
NOISE_RE = re.compile(r"\s+(无|NULL|None|—|-)$")


def parse_line(line):
    """从一行提取 {code, name}；非名单行返回 None。"""
    cm = CODE_RE.search(line)
    if not cm:
        return None
    code = cm.group(0)
    prefix = line[: cm.start()].strip()
    m = NAME_RE.match(prefix)
    if m:
        name = m.group(2).strip()
    else:
        segs = re.findall(r"[\u4e00-\u9fff]+", prefix)
        name = segs[-1] if segs else ""
    name = NOISE_RE.sub("", name).strip()
    if len(name) < 4:          # 过滤『无』等残次行
        return None
    return {"code": code, "name": name}


def parse_text(text):
    out = []
    for ln in text.splitlines():
        r = parse_line(ln)
        if r:
            out.append(r)
    return out


def extract_with_pypdf2(path):
    try:
        from PyPDF2 import PdfReader
    except ImportError:
        print("[warn] 未安装 PyPDF2，pip install PyPDF2")
        return {}, set()
    reader = PdfReader(path)
    by_code = {}
    skipped = set()
    for i, page in enumerate(reader.pages, 1):
        try:
            txt = page.extract_text() or ""
        except Exception:
            txt = ""
        rows = parse_text(txt)
        if not rows:
            skipped.add(i)
            continue
        for r in rows:
            by_code[r["code"]] = r
    return by_code, skipped


def ocr_page(pdf_path, page_no):
    """尝试 OCR 单页：返回 (rows, ok)。需 pytesseract + pdf2image + poppler。"""
    try:
        from pdf2image import convert_from_path
        import pytesseract
    except ImportError:
        return [], False
    try:
        imgs = convert_from_path(pdf_path, first_page=page_no, last_page=page_no, dpi=300)
        if not imgs:
            return [], False
        txt = pytesseract.image_to_string(imgs[0], lang="chi_sim")
        return parse_text(txt), True
    except Exception as e:
        print("  [ocr-error] page %d: %s" % (page_no, e))
        return [], False


def fetch_pdf_url():
    """从详情页定位 PDF 附件链接。"""
    import requests
    try:
        html = requests.get(DETAIL_URL, timeout=20).text
    except Exception as e:
        print("[error] 详情页抓取失败: %s" % e)
        return None
    urls = re.findall(r'href=["\']([^"\']+\.pdf[^"\']*)["\']', html, re.I)
    if not urls:
        print("[error] 详情页未找到 PDF 链接")
        return None
    u = urls[0]
    if u.startswith("//"):
        u = "https:" + u
    elif u.startswith("/"):
        u = "https://www.nfra.gov.cn" + u
    return u


def download(url, dest):
    import requests
    print("[download] %s" % url)
    with requests.get(url, timeout=60, stream=True) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for ch in r.iter_content(8192):
                f.write(ch)
    print("[download] saved -> %s" % dest)


def load_existing(out_path):
    if os.path.exists(out_path):
        try:
            d = json.load(open(out_path, encoding="utf-8"))
            return {b["code"]: b for b in d.get("banks", []) if b.get("code")}
        except Exception:
            pass
    return {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", help="直接解析本地 PDF 路径")
    ap.add_argument("--url", help="直接下载指定 PDF URL")
    ap.add_argument("--out", default=DEFAULT_OUT)
    ap.add_argument("--no-ocr", action="store_true", help="跳过 OCR（图片页记为 skipped）")
    args = ap.parse_args()

    tmp_pdf = os.path.join(HERE, "_nfra_list.pdf")

    if args.pdf:
        pdf_path = args.pdf
    else:
        url = args.url or fetch_pdf_url()
        if not url:
            sys.exit(1)
        download(url, tmp_pdf)
        pdf_path = tmp_pdf

    print("[parse] PyPDF2 解析中 ...")
    by_code, skipped = extract_with_pypdf2(pdf_path)
    print("[parse] 文本页解析得到 %d 家；空页 %d 页" % (len(by_code), len(skipped)))

    if skipped and not args.no_ocr:
        print("[ocr] 尝试补全 %d 个图片页 ..." % len(skipped))
        for p in sorted(skipped):
            rows, ok = ocr_page(pdf_path, p)
            if ok and rows:
                for r in rows:
                    by_code.setdefault(r["code"], r)
                skipped.discard(p)
        print("[ocr] 补全后剩余空页 %d 页" % len(skipped))

    # 合并已有
    existing = load_existing(args.out)
    merged = dict(existing)
    merged.update(by_code)
    print("[merge] 已有 %d + 本次 %d = 合并 %d 家" % (len(existing), len(by_code), len(merged)))

    out = {
        "source": "国家金融监督管理总局 银行业金融机构法人名单（截至2025-12-31，法人合计3619家）",
        "total_official": 3619,
        "count": len(merged),
        "skipped_image_pages": sorted(skipped),
        "banks": sorted(merged.values(), key=lambda x: x["code"]),
    }
    json.dump(out, open(args.out, "w", encoding="utf-8"),
              ensure_ascii=False, separators=(",", ":"))
    print("[done] 写出 -> %s (%d 家)" % (args.out, out["count"]))


if __name__ == "__main__":
    main()
