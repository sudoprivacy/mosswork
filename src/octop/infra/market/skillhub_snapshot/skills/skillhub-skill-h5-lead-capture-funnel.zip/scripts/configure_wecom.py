#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
configure_wecom.py —— 企业微信服务商凭据写入工具（作者/运维在服务器上运行）

用法（所有参数均为必填，从「企业微信服务商后台 / 应用管理」获取）：
  python3 configure_wecom.py \
    --provider-corpid 提供商的corpid \
    --provider-secret 提供商Secret \
    --suite-id 应用suite_id \
    --suite-secret 应用Secret \
    --agent-id 应用agentid \
    --callback-token 通讯录事件回调Token \
    --callback-aeskey 通讯录事件回调EncodingAESKey

写入 /opt/license_server/wecom.env（权限 600），随后重启服务使凭据生效：
  systemctl restart license-server license-poll
"""
import argparse
import os

ENV_PATH = "/opt/license_server/wecom.env"


def main():
    p = argparse.ArgumentParser(description="写入企业微信服务商凭据到 wecom.env")
    p.add_argument("--provider-corpid", required=True)
    p.add_argument("--provider-secret", required=True)
    p.add_argument("--suite-id", required=True)
    p.add_argument("--suite-secret", required=True)
    p.add_argument("--agent-id", required=True)
    p.add_argument("--callback-token", required=True)
    p.add_argument("--callback-aeskey", required=True)
    a = p.parse_args()

    vals = {
        "WECOM_PROVIDER_CORPID": a.provider_corpid,
        "WECOM_PROVIDER_SECRET": a.provider_secret,
        "WECOM_SUITE_ID": a.suite_id,
        "WECOM_SUITE_SECRET": a.suite_secret,
        "WECOM_AGENT_ID": a.agent_id,
        "WECOM_CALLBACK_TOKEN": a.callback_token,
        "WECOM_CALLBACK_AESKEY": a.callback_aeskey,
    }
    with open(ENV_PATH, "w") as f:
        f.write("# 企业微信服务商凭据（权限600，切勿外泄 / 不要进版本库）\n")
        for k, v in vals.items():
            f.write("%s=%s\n" % (k, v))
    os.chmod(ENV_PATH, 0o600)
    print("已写入 %s（权限 600）" % ENV_PATH)
    print("请执行：systemctl restart license-server license-poll")


if __name__ == "__main__":
    main()
