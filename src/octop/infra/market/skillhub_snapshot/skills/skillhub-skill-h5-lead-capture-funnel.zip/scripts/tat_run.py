#!/usr/bin/env python3
"""
TAT 远程执行助手（脱敏模板）

通过腾讯云自动化助手（TAT）在无 SSH 通道时远程执行命令 / 读文件 / 改配置 / 重启服务。
替换下方 <INSTANCE_ID> 与 <REGION> 即可使用。

依赖：本机已安装并配置 tccli（tccli configure），且具有 TAT 调用权限。

用法：
    python3 tat_run.py "<shell命令>" [超时秒数，默认60]

示例：
    python3 tat_run.py "systemctl restart <AUTH_API_SERVICE>" 60
    python3 tat_run.py "cat /opt/<APP_DIR>/app.py" 30
"""
import sys
import json
import subprocess
import time

# ===== 替换为你的实例信息 =====
INSTANCE_ID = "<INSTANCE_ID>"   # 如 lhins-xxxxxxxx
REGION = "<REGION>"             # 如 ap-beijing
# =============================

def run_tat(command, timeout=60):
    # 1. 下发命令
    inv = subprocess.run(
        ["tccli", "tat", "RunCommand",
         "--Region", REGION,
         "--InstanceIds", f'["{INSTANCE_ID}"]',
         "--CommandType", "SHELL",
         "--Content", command,
         "--Timeout", str(timeout)],
        capture_output=True, text=True
    )
    if inv.returncode != 0:
        return f"[下发失败] {inv.stderr}"

    try:
        inv_id = json.loads(inv.stdout)["Response"]["InvocationId"]
    except Exception as e:
        return f"[解析失败] {inv.stdout} | {e}"

    # 2. 轮询任务输出（异步）
    deadline = time.time() + max(timeout, 120) + 30
    while time.time() < deadline:
        time.sleep(3)
        task = subprocess.run(
            ["tccli", "tat", "DescribeInvocationTasks",
             "--Region", REGION,
             "--Filters", f'[{{"Name":"invocation-id","Values":["{inv_id}"]}}]'],
            capture_output=True, text=True
        )
        try:
            data = json.loads(task.stdout)
            # 注意：该接口返回无 Response 外层包装，直接是 {TotalCount, InvocationTaskSet}
            tasks = data.get("InvocationTaskSet", data.get("Response", {}).get("InvocationTaskSet", []))
            if tasks and tasks[0]["TaskStatus"] in ("SUCCESS", "FAILED"):
                t = tasks[0]
                out = t.get("TaskResult", {}).get("Output", "")
                # Output 是 base64，按需解码
                try:
                    import base64
                    out = base64.b64decode(out).decode("utf-8", "replace")
                except Exception:
                    pass
                status = t.get("TaskStatus")
                exit_code = t.get("TaskResult", {}).get("ExitCode")
                return f"[status={status} exit={exit_code}]\n{out}"
        except Exception as e:
            return f"[轮询异常] {task.stdout} | {e}"
    return "[超时未拿到结果]"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 tat_run.py \"<命令>\" [超时秒数]")
        sys.exit(1)
    cmd = sys.argv[1]
    to = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    print(run_tat(cmd, to))
