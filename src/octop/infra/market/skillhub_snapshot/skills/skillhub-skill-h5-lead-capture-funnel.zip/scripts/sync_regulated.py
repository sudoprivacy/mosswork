#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sync_regulated.py —— 每日夜间同步国家金融监管总局《银行业金融机构法人名单》

职责：
  1. 下载最新名单 PDF（直链由 NFRA_PDF_URL 指定，默认当前最新一期，截至2025-12月末）。
  2. PyPDF2 解析文本页，提取 {机构编码: 机构名}（机构编码为稳定主键）。
  3. 与现有 regulated_banks.json 按编码对比，及时剔除被 NFRA 移除的机构，纳入新增机构。
  4. 写回 regulated_banks.json + 写同步日志；调用 license-server 热重载端点使内存生效。
  5. 推送企业微信变更摘要（新增/移除）；异常时告警。

安全护栏：
  * 移除量超过阈值（max(50, 8%*现有量)）则中止写回并告警，防止下载到错误/不完整名单导致白名单被大规模误删。
  * 真实准入闸门仍是 corpid 白名单；本名单仅作辅助校验，绝不以机构名称字眼作为准入依据。

定时：由 regulated-sync.timer 每天 03:47 触发（错开 license-poll.timer 的 03:17）。
"""
import os
import re
import sys
import json
import time
import hashlib
import subprocess
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))

# ── 配置（优先环境变量，其次默认值）──────────────────────────────────────
def _env(key, default=""):
    # 从同目录 wecom.env 读取（简单 KEY=VALUE），再回退进程环境变量，再回退默认
    p = os.path.join(HERE, "wecom.env")
    if os.path.exists(p):
        try:
            for line in open(p, encoding="utf-8"):
                line = line.strip()
                if line.startswith(key + "="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
        except Exception:
            pass
    return os.environ.get(key, default)

PDF_URL = _env(
    "NFRA_PDF_URL",
    "https://www.nfra.gov.cn/chinese/docfile/2026/1dcdad9de86f4d9d889356bb64cb313e.pdf",
)
JSON_PATH = os.path.join(HERE, "regulated_banks.json")
LOG_PATH = os.path.join(HERE, "regulated_sync_log.json")
ADMIN_KEY = _env("LICENSE_ADMIN_KEY", "<LICENSE_ADMIN_KEY>")
RELOAD_URL = "http://127.0.0.1:8099/license-api/admin/api/reload-regulated"
WECOM_WEBHOOK_KEY = _env("WECOM_WEBHOOK_KEY", "<WECOM_WEBHOOK_KEY>")
WECOM_WEBHOOK = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=" + WECOM_WEBHOOK_KEY

UA = "Mozilla/5.0 (compatible; RegulatedSync/1.0; +license-server)"

NAME_RE = re.compile(r"^(\d+)\s+(.*)$")
CODE_RE = re.compile(r"[A-Z]\d{4}H\d{9}")
NOISE_RE = re.compile(r"\s+(无|NULL|None|—|-)$")


def parse_line(line):
    cm = CODE_RE.search(line)
    if not cm:
        return None
    code = cm.group(0)
    prefix = line[: cm.start()].strip()
    m = NAME_RE.match(prefix)
    if m:
        name = m.group(2).strip()
    else:
        segs = re.findall(r"[\u4e00-\u9fff]+", prefix)
        name = segs[-1] if segs else ""
    name = NOISE_RE.sub("", name).strip()
    if len(name) < 4:
        return None
    return {"code": code, "name": name}


def parse_text(text):
    out = {}
    for ln in text.splitlines():
        r = parse_line(ln)
        if r:
            out[r["code"]] = r["name"]
    return out


def extract_pdf(path):
    """优先 pdfplumber（文本提取更全），失败回退 PyPDF2。返回 ({code:name}, 空页列表)。"""
    try:
        from pdfplumber import open as pdfplumber_open
        with pdfplumber_open(path) as pdf:
            by_code = {}
            skipped = []
            for i, page in enumerate(pdf.pages, 1):
                txt = page.extract_text() or ""
                rows = parse_text(txt)
                if not rows:
                    skipped.append(i)
                    continue
                by_code.update(rows)
        return by_code, skipped
    except Exception as e:
        sys.stderr.write("pdfplumber failed (%s), fallback PyPDF2\n" % e)
        from PyPDF2 import PdfReader
        reader = PdfReader(path)
        by_code = {}
        skipped = []
        for i, page in enumerate(reader.pages, 1):
            try:
                txt = page.extract_text() or ""
            except Exception:
                txt = ""
            rows = parse_text(txt)
            if not rows:
                skipped.append(i)
                continue
            by_code.update(rows)
        return by_code, skipped


def download_pdf(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=90) as r:
        data = r.read()
    open(dest, "wb").write(data)
    return len(data)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for ch in iter(lambda: f.read(65536), b""):
            h.update(ch)
    return h.hexdigest()


def load_existing():
    if os.path.exists(JSON_PATH):
        try:
            d = json.load(open(JSON_PATH, encoding="utf-8"))
            return {b["code"]: b.get("name", "") for b in d.get("banks", []) if b.get("code")}, d
        except Exception:
            pass
    return {}, {}


def call_reload():
    try:
        req = urllib.request.Request(
            RELOAD_URL,
            headers={"X-API-Key": ADMIN_KEY, "Content-Type": "application/json"},
            data=b"{}",
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode())
    except Exception as e:
        return {"error": str(e)}


def push_wecom(markdown):
    try:
        req = urllib.request.Request(
            WECOM_WEBHOOK,
            data=json.dumps({"msgtype": "markdown", "markdown": {"content": markdown}}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.read().decode()
    except Exception as e:
        sys.stderr.write("wecom push error: %s\n" % e)
        return None


def write_log(rec):
    try:
        json.dump(rec, open(LOG_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception as e:
        sys.stderr.write("log error: %s\n" % e)


def main():
    iso = time.strftime("%Y-%m-%d %H:%M:%S")
    tmp = os.path.join(HERE, "_nfra_sync.pdf")
    rec = {"last_sync": iso, "status": "unknown", "pdf_url": PDF_URL}
    try:
        size = download_pdf(PDF_URL, tmp)
        rec["pdf_size"] = size
        rec["pdf_sha256"] = sha256_file(tmp)
        new_set, skipped = extract_pdf(tmp)
        rec["skipped_image_pages"] = skipped
        rec["parsed_count"] = len(new_set)
        if len(new_set) < 500:
            raise RuntimeError("解析机构数过少(%d)，疑似名单格式变更或下载异常" % len(new_set))

        old_set, old_doc = load_existing()
        existing_total = len(old_set)
        added = [c for c in new_set if c not in old_set]
        removed = [c for c in old_set if c not in new_set]

        threshold = max(50, int(existing_total * 0.08))
        if removed and len(removed) > threshold:
            rec["status"] = "aborted"
            rec["added"] = added
            rec["removed"] = removed
            rec["reason"] = "移除量 %d 超过阈值 %d，疑似下载到错误/不完整名单，已中止写回" % (len(removed), threshold)
            write_log(rec)
            push_wecom(
                "## ⚠️ 监管名单同步中止\n"
                "> 时间：%s\n"
                "> 原因：%s\n"
                "> 解析到 %d 家，移除 %d 家（阈值 %d）。已保留原名单未改动，请人工核查 NFRA_PDF_URL 是否为最新一期直链。\n"
                % (iso, rec["reason"], len(new_set), len(removed), threshold)
            )
            print("[aborted]", rec["reason"])
            return

        # 以最新官方名单（按编码）为权威，写回
        total_official = old_doc.get("total_official", 3619)
        m = re.search(r"合计\s*(\d+)\s*家", open(tmp, "rb").read().decode("utf-8", "replace"))
        if m:
            total_official = int(m.group(1))
        out = {
            "source": "国家金融监督管理总局 银行业金融机构法人名单（自动同步 %s，官方合计约 %d 家）" % (iso[:10], total_official),
            "total_official": total_official,
            "count": len(new_set),
            "last_synced_at": iso,
            "skipped_image_pages": skipped,
            "banks": sorted(
                [{"code": c, "name": n} for c, n in new_set.items()],
                key=lambda x: x["code"],
            ),
        }
        json.dump(out, open(JSON_PATH, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
        rec["total"] = len(new_set)
        rec["added"] = added
        rec["removed"] = removed

        reload_resp = call_reload()
        rec["reload"] = reload_resp

        if not added and not removed:
            rec["status"] = "no_change"
            push_wecom(
                "## ✅ 监管名单每日核对完成（无变化）\n"
                "> 时间：%s\n> 当前持牌机构白名单：%d 家（与 NFRA 最新一期一致）\n"
                % (iso, len(new_set))
            )
        else:
            rec["status"] = "updated"
            added_names = "、".join("%s(%s)" % (new_set[c], c) for c in added[:20])
            removed_names = "、".join("%s(%s)" % (old_set[c], c) for c in removed[:20])
            more = ""
            if len(added) > 20:
                more += "（新增另 %d 家）" % (len(added) - 20)
            if len(removed) > 20:
                more += "（移除另 %d 家）" % (len(removed) - 20)
            push_wecom(
                "## 🔄 监管名单同步完成\n"
                "> 时间：%s\n"
                "> 白名单现共 **%d** 家\n"
                "> 新增 **%d** 家：%s%s\n"
                "> 移除 **%d** 家（NFRA 已注销/合并）：%s%s\n"
                "> 已热重载，is_regulated_bank 即时生效。\n"
                % (iso, len(new_set), len(added), added_names, more, len(removed), removed_names, more)
            )
        write_log(rec)
        print("[done] status=%s total=%d added=%d removed=%d reload=%s"
              % (rec["status"], len(new_set), len(added), len(removed), reload_resp))
    except Exception as e:
        rec["status"] = "error"
        rec["error"] = str(e)
        write_log(rec)
        push_wecom("## ❌ 监管名单同步失败\n> 时间：%s\n> 错误：%s\n" % (iso, e))
        print("[error]", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
