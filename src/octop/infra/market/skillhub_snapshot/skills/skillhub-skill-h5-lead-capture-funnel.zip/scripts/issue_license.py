#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
issue_license.py —— 授权令牌签发器（作者专用 · 含私钥路径，切勿随技能包分发）

仅作者（你）使用：在核验对方为银行/持牌金融机构从业人员后，签发签名令牌。
令牌 = base64(payload) + "." + base64(Ed25519签名)，含：
  sub   持有者邮箱（用于身份追溯）
  org   机构名称
  aud   授权部署域名（绑定，防止令牌挪作他用）
  iat   签发时间
  exp   到期时间
  lic   许可证编号（用于远程吊销）
  scope 限定 "bank-only"

用法：
  # 首次生成密钥对（私钥存 ~/.workbuddy/secrets/license_private_key.pem）
  python3 issue_license.py gen_keypair

  # 签发（默认 365 天）
  python3 issue_license.py issue \
      --email zhangsan@bank.com --org "某银行XX分行" \
      --aud <YOUR_DOMAIN> --days 365 --lic LIC-2026-0001

  # 输出即为 license.key 内容，发送给客户，客户放到部署目录即可。
"""

import argparse
import base64
import json
import os
import time

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

PRIV_PATH = os.path.expanduser("~/.workbuddy/secrets/license_private_key.pem")


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def gen_keypair():
    k = Ed25519PrivateKey.generate()
    priv = k.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    pub = k.public_key().public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    os.makedirs(os.path.dirname(PRIV_PATH), exist_ok=True)
    with open(PRIV_PATH, "wb") as f:
        f.write(priv)
    os.chmod(PRIV_PATH, 0o600)
    print("私钥已保存（权限 600）：", PRIV_PATH)
    print("将下面这段【公钥】粘贴进 license_gate.py 的 _AUTHOR_PUBLIC_PEM：\n")
    print(pub.decode())


def _load_priv():
    if not os.path.exists(PRIV_PATH):
        raise SystemExit("未找到私钥 %s，请先运行 gen_keypair" % PRIV_PATH)
    with open(PRIV_PATH, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def issue(email, org, aud, days, lic_id):
    priv = _load_priv()
    now = int(time.time())
    payload = {
        "sub": email,
        "org": org,
        "aud": aud,
        "iat": now,
        "exp": now + int(days) * 86400,
        "lic": lic_id,
        "scope": "bank-only",
    }
    pb = _b64u(json.dumps(payload, ensure_ascii=False).encode("utf-8"))
    sig = _b64u(priv.sign(pb.encode("utf-8")))
    token = pb + "." + sig
    print("# ── 以下是 license.key 内容（发送给客户）──")
    print(token)
    print("# ──────────────────────────────────────────")
    print("# 持有者: %s | 机构: %s | 域名: %s | 到期: %s | 编号: %s" % (
        email, org, aud,
        time.strftime("%Y-%m-%d", time.localtime(payload["exp"])), lic_id,
    ))


def main():
    ap = argparse.ArgumentParser(description="授权令牌签发器（作者专用）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    g = sub.add_parser("gen_keypair", help="生成 Ed25519 密钥对")
    i = sub.add_parser("issue", help="签发授权令牌")
    i.add_argument("--email", required=True, help="持有者邮箱（银行/机构企业邮箱）")
    i.add_argument("--org", required=True, help="机构名称")
    i.add_argument("--aud", required=True, help="授权部署域名（绑定，防挪作他用）")
    i.add_argument("--days", default=365, type=int, help="有效期天数（默认 365）")
    i.add_argument("--lic", required=True, help="许可证编号，如 LIC-2026-0001")

    args = ap.parse_args()
    if args.cmd == "gen_keypair":
        gen_keypair()
    elif args.cmd == "issue":
        issue(args.email, args.org, args.aud, args.days, args.lic)


if __name__ == "__main__":
    main()
