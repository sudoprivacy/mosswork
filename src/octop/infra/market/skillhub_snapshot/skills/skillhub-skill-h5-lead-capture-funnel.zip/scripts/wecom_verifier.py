#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
wecom_verifier.py —— 企业微信核验 + 离职自动吊销模块（作者侧，配合 license_server 使用）

设计目标：
  把"是否为银行从业人员"的判定，从纯人工审批升级为
  「企业微信所属企业核验 + 每日轮巡 / 离职回调 + 自动吊销 + 异常转人工」的自动闭环。

核验模型（企业微信「服务商第三方应用」）：
  1) 每家合作银行在服务商后台授权安装本应用，作者拿到该企业的 permanent_code。
  2) 银行员工注册/绑定时，经企业微信网页授权拿到 (corpid, userid)；corpid 必须命中白名单。
  3) 已签发 License 与 (corpid, userid) 绑定入库。
  4) 每日轮巡：provider_token -> corp_token -> user/get；
     成员不存在(60111) 或 status∈{2禁用,5离职} -> 标记 LEFT -> 吊销 License。
  5) 离职回调（通讯录变更事件 delete_user / update_user 离职）-> 实时吊销（秒级）。
  6) FAIL-OPEN：任何网络/未知错误 -> 标记 error 并转人工，绝不自动吊销（防误杀在职员工）。

本模块不持有 license 私钥。吊销动作通过 license_server.revoke_license() 完成，
以保证与「手动吊销」走同一条、可被客户验证器电话回家的作废链路。

依赖：requests（线上需安装）、pycryptodome（仅通讯录事件回调解密需要，可选）。
"""

import os
import re
import time
import json
import enum
import base64
import hashlib
import struct
import threading
from datetime import datetime

WECOM_API = "https://qyapi.weixin.qq.com/cgi-bin"

try:
    import requests
except ImportError:
    requests = None

try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
except ImportError:
    AES = None


class MemberState(enum.Enum):
    ACTIVE = "active"    # 在职
    LEFT = "left"        # 离职 / 已禁用 / 不在企业
    UNKNOWN = "unknown"  # 无法识别（转人工）
    ERROR = "error"      # 接口异常（转人工，fail-open）


# ───────────────────────────── 配置 ─────────────────────────────
class WeComConfig:
    def __init__(self):
        self.provider_corpid = os.environ.get("WECOM_PROVIDER_CORPID", "")
        self.provider_secret = os.environ.get("WECOM_PROVIDER_SECRET", "")
        self.suite_id = os.environ.get("WECOM_SUITE_ID", "")
        self.suite_secret = os.environ.get("WECOM_SUITE_SECRET", "")
        self.agent_id = os.environ.get("WECOM_AGENT_ID", "")
        # 通讯录事件回调校验
        self.callback_token = os.environ.get("WECOM_CALLBACK_TOKEN", "")
        self.callback_aeskey = os.environ.get("WECOM_CALLBACK_AESKEY", "")
        # 是否启用真实调用（无凭据时置 False，poll 走 MockClient）
        self.enabled = bool(
            self.provider_corpid
            and (self.provider_secret or (self.suite_id and self.suite_secret))
        )

    def oauth_authorize_url(self, redirect_uri, state):
        """第三方应用网页授权链接（需按实际接入模型核对）。"""
        cid = self.suite_id or self.provider_corpid
        return (
            "https://open.weixin.qq.com/connect/oauth2/authorize?"
            "appid=%s&redirect_uri=%s&response_type=code&scope=snsapi_userinfo"
            "&state=%s&agentid=%s#wechat_redirect"
        ) % (cid, requests.utils.quote(redirect_uri, safe=""), state, self.agent_id)


# ───────────────────────────── Token 缓存 ─────────────────────────────
_token_cache = {}
_token_lock = threading.Lock()


def _cache_get(key):
    with _token_lock:
        v = _token_cache.get(key)
        if v and v[1] > int(time.time()) + 300:
            return v[0]
    return None


def _cache_put(key, token, expires_in):
    with _token_lock:
        _token_cache[key] = (token, int(time.time()) + int(expires_in or 7200))


# ───────────────────────────── 客户端 ─────────────────────────────
class WeComClient:
    def __init__(self, cfg: WeComConfig):
        self.cfg = cfg

    def _get(self, path, params, body=None, timeout=8):
        if requests is None:
            raise RuntimeError("requests 未安装")
        for _ in range(2):
            r = requests.post(
                WECOM_API + path,
                params=params,
                json=body,
                timeout=timeout,
            )
            d = r.json()
            if d.get("errcode") == 0:
                return d
            # token 失效则清空缓存重试一次
            if d.get("errcode") in (40014, 41001, 42001):
                continue
            return d
        return d

    # —— 获取 provider / suite access_token ——
    def get_provider_token(self):
        key = "prov:%s" % self.cfg.provider_corpid
        t = _cache_get(key)
        if t:
            return t
        d = self._get(
            "/service/get_provider_token",
            {},
            {"corpid": self.cfg.provider_corpid, "provider_secret": self.cfg.provider_secret},
        )
        if d.get("errcode") != 0:
            raise RuntimeError("get_provider_token 失败: %s" % d)
        _cache_put(key, d["provider_access_token"], d.get("expires_in", 7200))
        return d["provider_access_token"]

    def get_suite_token(self):
        key = "suite:%s" % self.cfg.suite_id
        t = _cache_get(key)
        if t:
            return t
        d = self._get(
            "/service/get_suite_token",
            {},
            {"suite_id": self.cfg.suite_id, "suite_secret": self.cfg.suite_secret},
        )
        if d.get("errcode") != 0:
            raise RuntimeError("get_suite_token 失败: %s" % d)
        _cache_put(key, d["suite_access_token"], d.get("expires_in", 7200))
        return d["suite_access_token"]

    def get_corp_token(self, corpid, permanent_code, provider_token=None):
        key = "corp:%s" % corpid
        t = _cache_get(key)
        if t:
            return t
        if not provider_token:
            provider_token = self.get_provider_token()
        d = self._get(
            "/service/get_corp_token",
            {},
            {"auth_corpid": corpid, "provider_access_token": provider_token,
             "permanent_code": permanent_code},
        )
        if d.get("errcode") != 0:
            raise RuntimeError("get_corp_token 失败(%s): %s" % (corpid, d))
        _cache_put(key, d["access_token"], d.get("expires_in", 7200))
        return d["access_token"]

    # —— 网页授权：code -> (corpid, userid) ——
    def getuserinfo(self, code):
        """第三方应用网页授权：code 换用户身份。返回 {corpid, userid} 或抛错。"""
        token = self.get_suite_token()
        d = self._get(
            "/service/user/getuserinfo",
            {"access_token": token, "code": code},
        )
        if d.get("errcode") != 0:
            raise RuntimeError("getuserinfo 失败: %s" % d)
        return {"corpid": d.get("corpid"), "userid": d.get("userid")}

    # —— 读取成员状态 ——
    def user_get(self, corpid, access_token, userid):
        """返回成员 dict；成员不存在抛 _MemberNotFound；其他错误抛 RuntimeError。"""
        d = self._get(
            "/user/get",
            {"access_token": access_token, "userid": userid},
        )
        errcode = d.get("errcode", 0)
        if errcode == 60111 or errcode == 41020 or errcode == 42003:
            raise _MemberNotFound(d)
        if errcode != 0:
            raise RuntimeError("user/get 错误(%s): %s" % (corpid, d))
        return d

    def evaluate_state(self, corpid, permanent_code, userid):
        """综合判断成员在职状态（含 status 判定）。"""
        try:
            token = self.get_corp_token(corpid, permanent_code)
            m = self.user_get(corpid, token, userid)
        except _MemberNotFound:
            return MemberState.LEFT
        except Exception:
            return MemberState.ERROR
        status = m.get("status")
        # status: 1 已关注 / 2 已禁用 / 4 未关注 / 5 已离职
        if status in (2, 5):
            return MemberState.LEFT
        return MemberState.ACTIVE


class _MemberNotFound(Exception):
    pass


# ───────────────────────────── 数据访问（懒导入 license_server 的 _db / revoke_license） ─────────────────────────────
def _db():
    from license_server import _db as d
    return d()


def _revoke(lic_id, reason, by):
    from license_server import revoke_license
    return revoke_license(lic_id, reason, by)


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


# ───────────────────────────── 白名单管理 ─────────────────────────────
def add_corp_whitelist(corpid, corp_name, by="admin"):
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "INSERT INTO wecom_corp_whitelist(corpid,corp_name,added_by) VALUES(%s,%s,%s) "
                "ON DUPLICATE KEY UPDATE corp_name=%s, verified=1",
                (corpid, corp_name, by, corp_name),
            )
    finally:
        c.close()


def list_corps():
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute("SELECT corpid,corp_name,verified,added_at FROM wecom_corp_whitelist ORDER BY added_at DESC")
            rows = cur.fetchall()
    finally:
        c.close()
    for r in rows:
        r["added_at"] = str(r["added_at"])
        r["verified"] = bool(r["verified"])
    return rows


def delete_corp(corpid):
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute("DELETE FROM wecom_corp_whitelist WHERE corpid=%s", (corpid,))
    finally:
        c.close()


def corpid_in_whitelist(corpid):
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute("SELECT 1 FROM wecom_corp_whitelist WHERE corpid=%s AND verified=1", (corpid,))
            return bool(cur.fetchone())
    finally:
        c.close()


def save_corp_auth(corpid, permanent_code, corp_name=""):
    """存储企业永久授权码（企业授权安装时写入）。"""
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "INSERT INTO wecom_corp_auth(corpid,permanent_code,corp_name) VALUES(%s,%s,%s) "
                "ON DUPLICATE KEY UPDATE permanent_code=%s, corp_name=%s",
                (corpid, permanent_code, corp_name, permanent_code, corp_name),
            )
    finally:
        c.close()


def get_corp_auth(corpid):
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute("SELECT permanent_code FROM wecom_corp_auth WHERE corpid=%s", (corpid,))
            row = cur.fetchone()
    finally:
        c.close()
    return row["permanent_code"] if row else None


# ───────────────────────────── 绑定管理 ─────────────────────────────
def create_pending_binding(corpid, userid):
    """注册 OAuth 成功后建立 pending 绑定，返回 bind_key，并快照执业资格状态。"""
    import secrets
    bind_key = secrets.token_hex(16)
    q, _ = check_qualification(corpid, userid)
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "INSERT INTO wecom_bindings(bind_key,corpid,userid,bind_status,qual_status) "
                "VALUES(%s,%s,%s,'pending',%s)",
                (bind_key, corpid, userid, q),
            )
    finally:
        c.close()
    return bind_key


def activate_binding(bind_key, lic_id):
    """审批通过后把 pending 绑定激活，关联 lic_id，并刷新资格快照。"""
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "SELECT corpid,userid FROM wecom_bindings WHERE bind_key=%s AND bind_status='pending'",
                (bind_key,),
            )
            row = cur.fetchone()
            if not row:
                return False
            q, _ = check_qualification(row["corpid"], row["userid"])
            cur.execute(
                "UPDATE wecom_bindings SET lic_id=%s, bind_status='active', qual_status=%s, last_checked=%s "
                "WHERE bind_key=%s AND bind_status='pending'",
                (lic_id, q, _now(), bind_key),
            )
            return cur.rowcount > 0
    finally:
        c.close()


def bind_license(lic_id, corpid, userid, by="admin"):
    """管理员手动绑定（OAuth 不可用时兜底）。要求 corpid 在白名单。"""
    if not corpid_in_whitelist(corpid):
        return False, "corpid 不在白名单"
    import secrets
    bind_key = secrets.token_hex(16)
    q, _ = check_qualification(corpid, userid)
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "INSERT INTO wecom_bindings(bind_key,lic_id,corpid,userid,bind_status,qual_status,last_checked) "
                "VALUES(%s,%s,%s,%s,'active',%s,%s) "
                "ON DUPLICATE KEY UPDATE lic_id=%s, corpid=%s, userid=%s, bind_status='active', "
                "qual_status=%s, last_checked=%s",
                (bind_key, lic_id, corpid, userid, q, _now(),
                 lic_id, corpid, userid, q, _now()),
            )
    finally:
        c.close()
    return True, "ok"


def list_bindings():
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "SELECT bind_key,lic_id,corpid,userid,bind_status,last_checked,last_event,created_at "
                "FROM wecom_bindings ORDER BY created_at DESC LIMIT 200"
            )
            rows = cur.fetchall()
    finally:
        c.close()
    for r in rows:
        for k in ("last_checked", "created_at"):
            r[k] = str(r[k]) if r[k] else None
    return rows


# ───────────────────────────── 执业资格二次校验（银行授权营销人员名单） ─────────────────────────────
def add_qualification(corpid, userid, name="", cert_no="", qual_status="qualified",
                      source="manual", expires_at=None, by="admin"):
    """维护「授权营销人员名单」：仅有营销执业资格者方可保留 License。这是 corpid 白名单之上的第二道闸。"""
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                """INSERT INTO wecom_qualifications
                   (corpid,userid,name,cert_no,qual_status,source,expires_at,added_by)
                   VALUES(%s,%s,%s,%s,%s,%s,%s,%s)
                   ON DUPLICATE KEY UPDATE name=%s,cert_no=%s,qual_status=%s,source=%s,expires_at=%s,added_at=NOW()""",
                (corpid, userid, name, cert_no, qual_status, source, expires_at, by,
                 name, cert_no, qual_status, source, expires_at),
            )
    finally:
        c.close()


def bulk_add_qualifications(rows):
    """批量导入：rows=[{corpid,userid,name,cert_no,expires_at}, ...]，返回成功条数。
    expires_at 为空串 / None 视为长期有效（存 NULL）。corpid/userid 缺失的行跳过。"""
    n = 0
    for r in rows:
        cid = (r.get("corpid") or "").strip()
        uid = (r.get("userid") or "").strip()
        if not cid or not uid:
            continue
        ea = (r.get("expires_at") or "").strip()
        ea = ea or None
        add_qualification(cid, uid, r.get("name", ""), r.get("cert_no", ""),
                          "qualified", "import", ea)
        n += 1
    return n


def list_qualifications(corpid=None):
    c = _db()
    try:
        with c.cursor() as cur:
            if corpid:
                cur.execute(
                    "SELECT * FROM wecom_qualifications WHERE corpid=%s ORDER BY added_at DESC", (corpid,))
            else:
                cur.execute(
                    "SELECT * FROM wecom_qualifications ORDER BY added_at DESC LIMIT 500")
            rows = cur.fetchall()
    finally:
        c.close()
    for r in rows:
        for k in ("added_at", "expires_at"):
            r[k] = str(r[k]) if r[k] else None
    return rows


def delete_qualification(corpid, userid):
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "DELETE FROM wecom_qualifications WHERE corpid=%s AND userid=%s", (corpid, userid))
    finally:
        c.close()


def check_qualification(corpid, userid, mock_state=None):
    """返回 (status, detail)。status: 'qualified' / 'unqualified' / 'unknown'(异常转人工)。"""
    if mock_state is not None:
        return (mock_state, "mock")
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "SELECT qual_status,expires_at FROM wecom_qualifications WHERE corpid=%s AND userid=%s",
                (corpid, userid))
            row = cur.fetchone()
    except Exception:
        return ("unknown", "查询资格名单异常，转人工")
    finally:
        c.close()
    if not row:
        return ("unqualified", "不在授权营销人员名单")
    if row["qual_status"] != "qualified":
        return ("unqualified", "资格状态=%s" % row["qual_status"])
    exp = row.get("expires_at")
    if exp and exp < datetime.now():
        return ("unqualified", "资格已过期")
    return ("qualified", "已确认营销执业资格")


# ───────────────────────────── 监管名单辅助校验（国家金融监管总局·银行业金融机构法人名单） ─────────────────────────────
# 数据源：银行业金融机构法人名单（截至2025年12月末），官方页 docId=1268142，合计 3619 家法人。
# 本名单仅作「辅助提示」：用于 add_corp 时提示该机构是否在持牌银行名录内。
# 关键：准入的真实闸门是 corpid 白名单 —— 自建企业微信无法伪造真实银行 corpid，
#       绝不以「机构名称含某字眼」作为准入依据（防止中介伪造名称蒙混，见 930 金融营销新规）。
_REGULATED_CACHE = None
_REGULATED_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "regulated_banks.json")


def load_regulated_list(force=False):
    """加载监管名单（进程内缓存）。返回 {'source':..., 'banks':[{code,name}]}。"""
    global _REGULATED_CACHE
    if _REGULATED_CACHE is not None and not force:
        return _REGULATED_CACHE
    try:
        with open(_REGULATED_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {"source": "", "banks": []}
    banks = []
    for b in data.get("banks", []):
        nm = (b.get("name") or "").strip()
        nm = re.sub(r"\s+(无|NULL|None|—|-)$", "", nm).strip()  # 清理 PDF 混入的尾部噪声
        if len(nm) < 4:        # 过滤解析残次/过短条目（如单字"司"），避免误判
            continue
        banks.append({"code": (b.get("code") or "").strip(), "name": nm})
    _REGULATED_CACHE = {"source": data.get("source", ""), "banks": banks}
    return _REGULATED_CACHE


def reload_regulated_list():
    """清空进程内缓存，下次调用 load_regulated_list 时重新从磁盘读取。\n    由每日同步脚本（sync_regulated.py）更新 JSON 后调用，使 is_regulated_bank 即时生效。"""
    global _REGULATED_CACHE
    _REGULATED_CACHE = None
    return load_regulated_list(force=True)


def is_regulated_bank(name):
    """模糊匹配：返回 (命中:bool, 命中全称:str|None)。
    双向子串匹配，容忍「股份有限公司」后缀与简称（如完整 corp_name『招商银行股份有限公司』命中列表）。
    注意：仅作辅助提示；真实闸门是 corpid 白名单，绝不以名称是否含『银行』等字眼作为准入依据。"""
    name = (name or "").strip()
    if len(name) < 4:          # 过短查询无意义，直接判否，避免 '司' 等单字误命中
        return (False, None)
    for b in load_regulated_list()["banks"]:
        bn = b["name"]
        if name == bn or name in bn or bn in name:
            return (True, bn)
    return (False, None)


# ───────────────────────────── 核心：状态判定 + 吊销 ─────────────────────────────
def evaluate_and_act(lic_id, state: MemberState, qual_status="unknown", reason=""):
    """更新绑定状态；仅 LEFT 或 资格失效(unqualified) 触发吊销（ERROR/UNKNOWN 不吊销，转人工）。"""
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "UPDATE wecom_bindings SET bind_status=%s, qual_status=%s, last_checked=%s WHERE lic_id=%s",
                (state.value, qual_status, _now(), lic_id),
            )
            if state == MemberState.LEFT:
                _revoke(lic_id, reason or "企业微信离职/禁用，自动吊销", "wecom")
            elif qual_status == "unqualified":
                _revoke(lic_id, reason or "营销执业资格未确认/已失效，自动吊销", "wecom-qual")
    finally:
        c.close()


def find_binding_by_user(corpid, userid):
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "SELECT lic_id FROM wecom_bindings WHERE corpid=%s AND userid=%s AND bind_status='active'",
                (corpid, userid),
            )
            row = cur.fetchone()
    finally:
        c.close()
    return row["lic_id"] if row else None


# ───────────────────────────── 轮巡（含 Mock 用于无凭据验证） ─────────────────────────────
def _mock_states():
    raw = os.environ.get("WECOM_MOCK_STATES", "")
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}


def _mock_qual():
    raw = os.environ.get("WECOM_MOCK_QUAL", "")
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}


def poll_all():
    """遍历所有 active 绑定：先判在职状态，再判营销执业资格；
    仅 LEFT（离职/禁用）或 资格失效(unqualified) 才吊销；ERROR/UNKNOWN 转人工，fail-open 不吊销。"""
    cfg = WeComConfig()
    client = WeComClient(cfg)
    mock = _mock_states()
    mock_qual = _mock_qual()
    summary = {"checked": 0, "left": 0, "error": 0, "active": 0,
               "qualified": 0, "unqualified": 0}
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "SELECT lic_id,corpid,userid FROM wecom_bindings WHERE bind_status='active' AND lic_id IS NOT NULL"
            )
            bindings = cur.fetchall()
    finally:
        c.close()

    for b in bindings:
        lic_id, corpid, userid = b["lic_id"], b["corpid"], b["userid"]
        summary["checked"] += 1
        key = "%s:%s" % (corpid, userid)
        # 1) 在职状态
        if mock:
            st = mock.get(key, "active")
            state = MemberState(st) if st in ("active", "left", "error") else MemberState.ERROR
        else:
            if not cfg.enabled:
                state = MemberState.ERROR          # 未配置凭据：转人工，不吊销
            else:
                permanent = get_corp_auth(corpid)
                if not permanent:
                    state = MemberState.ERROR      # 无永久授权码：转人工
                else:
                    state = client.evaluate_state(corpid, permanent, userid)
        # 2) 处理结果
        if state == MemberState.ERROR:
            summary["error"] += 1
            evaluate_and_act(lic_id, state, "unknown")
            continue
        if state == MemberState.LEFT:
            summary["left"] += 1
            evaluate_and_act(lic_id, state, "unknown", "企业微信轮巡检测到离职/禁用，自动吊销")
            continue
        summary["active"] += 1
        # 3) 执业资格二次校验（在职且资格有效才保留）
        if mock:
            q = mock_qual.get(key, "qualified")
        else:
            q, _ = check_qualification(corpid, userid)
        if q == "qualified":
            summary["qualified"] += 1
            evaluate_and_act(lic_id, state, "qualified")
        else:
            summary["unqualified"] += 1
            evaluate_and_act(lic_id, state, "unqualified",
                             "营销执业资格未确认/已失效（不在授权名单或已过期），自动吊销")
    return summary


# ───────────────────────────── 网页授权回调 ─────────────────────────────
def handle_oauth_callback(code, expected_state):
    """
    处理企业微信网页授权回调：code -> (corpid, userid)；校验白名单后建立 pending 绑定。
    返回 (bind_key, error)。无凭据/异常时 error 非空。
    """
    cfg = WeComConfig()
    if not cfg.enabled:
        return None, "企业微信未配置（WECOM_PROVIDER/Suite 凭据缺失）"
    client = WeComClient(cfg)
    try:
        info = client.getuserinfo(code)
    except Exception as e:
        return None, "getuserinfo 失败: %s" % e
    corpid, userid = info.get("corpid"), info.get("userid")
    if not corpid or not userid:
        return None, "未获取到企业微信身份"
    if not corpid_in_whitelist(corpid):
        return None, "该 corpid 不在银行白名单：%s" % corpid
    bind_key = create_pending_binding(corpid, userid)
    return bind_key, None


# ───────────────────────────── 通讯录变更事件回调（离职实时吊销） ─────────────────────────────
def verify_msg_signature(token, signature, timestamp, nonce, encrypt):
    s = hashlib.sha1()
    s.update("".join(sorted([token, timestamp, nonce, encrypt])).encode("utf-8"))
    return s.hexdigest() == signature


def decrypt_event(token, aeskey, msg_signature, timestamp, nonce, encrypt):
    """解密企业微信推送的 Encrypt 字段，返回明文 XML 字符串。"""
    if AES is None:
        raise RuntimeError("pycryptodome 未安装，无法解密事件")
    if not verify_msg_signature(token, msg_signature, timestamp, nonce, encrypt):
        raise RuntimeError("消息签名校验失败")
    key = base64.b64decode(aeskey + "=")
    iv = key[:16]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    plain = cipher.decrypt(base64.b64decode(encrypt))
    plain = unpad(plain, 16)
    content = plain[16:]
    msg_len = struct.unpack("!I", content[:4])[0]
    xml = content[4:4 + msg_len].decode("utf-8")
    return xml


def handle_contact_event(xml_text):
    """解析通讯录事件 XML，delete_user / update_user(离职) -> 吊销。"""
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring(xml_text)
        corpid = root.findtext("FromUserName")
        event = root.findtext("Event")
        userid = root.findtext("UserID")
        status = root.findtext("Status")
    except Exception:
        return "bad_xml"
    if not userid or not corpid:
        return "skip"
    # delete_user：成员被删除 -> 离职
    left = False
    if event == "delete_user":
        left = True
    elif event == "update_user" and status in ("2", "5"):  # 禁用 / 离职
        left = True
    if left:
        lic_id = find_binding_by_user(corpid, userid)
        if lic_id:
            evaluate_and_act(lic_id, MemberState.LEFT, "企业微信离职事件回调，实时吊销")
            return "revoked:%s" % lic_id
    return "skip"
