#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
license_server.py —— 作者侧授权令牌签发 / 吊销托管服务（作者专用）

部署位置：作者自己控制的服务器（与分发给他人的「验证器 license_gate.py」完全分离）。
本服务持有【私钥】，负责：
  1) 公开申请页：银行/持牌机构人员在线提交授权申请（邮箱/机构/域名/用途）
  2) 作者审核后台：列出待审、批准（自动签发）、拒绝、吊销
  3) 远程吊销查询端点：GET /revoke/<lic_id> —— 供客户的 license_gate.py 电话回家

安全要点：
  * 私钥路径由环境变量 LICENSE_PRIV_PATH 指定，绝不写入代码/镜像。
  * 审核接口与后台由 LICENSE_ADMIN_KEY（X-API-Key）保护。
  * 申请端点带内存限流 + honeypot 防机器人。

配置（环境变量，无默认值泄露真实信息）：
  LICENSE_ADMIN_KEY   审核后台/接口密钥（必填）
  LICENSE_PRIV_PATH   私钥 PEM 路径（默认 /opt/license_server/keys/license_private_key.pem）
  MYSQL_PWD           MySQL root 密码（本地 socket/127.0.0.1）
  MYSQL_DB            库名（默认 license_srv）
  LICENSE_BASE_URL    对外基址，用于回写链接（默认从请求推断）
  GUNICORN 端口固定 127.0.0.1:8099，由 nginx 反代 /license-api/

依赖：flask, pymysql, cryptography（与现有 auth-api 同机复用即可）
"""

import os
import sys
import json
import base64
import time
import hmac
import secrets
import ipaddress
from datetime import datetime

from flask import (
    Flask, request, jsonify, render_template_string, abort, redirect, url_for, send_file
)
from cryptography.hazmat.primitives import serialization

import pymysql
import wecom_verifier as wv

# ───────────────────────────── 配置 ─────────────────────────────
ADMIN_KEY = os.environ.get("LICENSE_ADMIN_KEY", "")
PRIV_PATH = os.environ.get(
    "LICENSE_PRIV_KEY",
    os.path.expanduser("/opt/license_server/keys/license_private_key.pem"),
)
MYSQL_PWD = os.environ.get("MYSQL_PWD", "")
DB_NAME = os.environ.get("MYSQL_DB", "license_srv")
# 作者企业微信二维码（机构通道人工审核时引导联系作者提交持牌证照）
ADMIN_WECOM_QR_URL = os.environ.get("ADMIN_WECOM_QR_URL", "")
ADMIN_WECOM_QR_PATH = os.environ.get("ADMIN_WECOM_QR_PATH", "")
app = Flask(__name__)

if not ADMIN_KEY:
    # 未在 systemd 注入时拒绝启动，避免无鉴权暴露审核接口
    raise SystemExit("FATAL: 必须设置环境变量 LICENSE_ADMIN_KEY")

# 内存限流（申请端点）：每 IP 每小时最多 10 次
_RATE = {}
_RATE_LIMIT = 10
_RATE_WINDOW = 3600


def _client_ip():
    fwd = request.headers.get("X-Forwarded-For", "")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.remote_addr or "unknown"


def _rate_ok():
    ip = _client_ip()
    now = time.time()
    hits = [t for t in _RATE.get(ip, []) if now - t < _RATE_WINDOW]
    hits.append(now)
    _RATE[ip] = hits
    return len(hits) <= _RATE_LIMIT


def _admin_wecom_qr():
    """解析作者企业微信二维码地址：优先完整 URL，其次本地文件经 /license-api/wecom/qr 提供。"""
    if ADMIN_WECOM_QR_URL:
        return ADMIN_WECOM_QR_URL
    if ADMIN_WECOM_QR_PATH:
        return "/license-api/wecom/qr"
    return ""


# ───────────────────────────── 数据库 ─────────────────────────────
def _db():
    return pymysql.connect(
        host="127.0.0.1",
        user="root",
        password=MYSQL_PWD,
        database=DB_NAME,
        charset="utf8mb4",
        autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )


def init_db():
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS license_requests (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    email VARCHAR(255) NOT NULL,
                    org VARCHAR(255) NOT NULL,
                    domain VARCHAR(255) NOT NULL,
                    contact VARCHAR(255),
                    use_case TEXT,
                    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
                    lic_id VARCHAR(64),
                    reviewer VARCHAR(128),
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    reviewed_at DATETIME
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """
            )
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS license_records (
                    lic_id VARCHAR(64) PRIMARY KEY,
                    email VARCHAR(255) NOT NULL,
                    org VARCHAR(255) NOT NULL,
                    domain VARCHAR(255) NOT NULL,
                    scope VARCHAR(32) NOT NULL DEFAULT 'bank-only',
                    token TEXT NOT NULL,
                    issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    expires_at DATETIME NOT NULL,
                    status ENUM('active','revoked') NOT NULL DEFAULT 'active'
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """
            )
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS license_revokes (
                    lic_id VARCHAR(64) PRIMARY KEY,
                    reason VARCHAR(255),
                    revoked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    revoked_by VARCHAR(128)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """
            )
            # ── 企业微信核验模块表 ──
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS wecom_corp_whitelist (
                    corpid VARCHAR(64) PRIMARY KEY,
                    corp_name VARCHAR(255),
                    verified TINYINT DEFAULT 1,
                    added_by VARCHAR(128),
                    added_at DATETIME DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """
            )
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS wecom_corp_auth (
                    corpid VARCHAR(64) PRIMARY KEY,
                    corp_name VARCHAR(255),
                    permanent_code VARCHAR(512),
                    token_cache VARCHAR(512),
                    token_exp BIGINT DEFAULT 0
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """
            )
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS wecom_bindings (
                    bind_key VARCHAR(64) PRIMARY KEY,
                    lic_id VARCHAR(64) NULL,
                    corpid VARCHAR(64) NOT NULL,
                    userid VARCHAR(128) NOT NULL,
                    bind_status ENUM('pending','active','left','unknown','error') DEFAULT 'pending',
                    last_checked DATETIME,
                    last_event VARCHAR(64),
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    KEY(lic_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """
            )
            # ── 执业资格二次校验表（授权营销人员名单）──
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS wecom_qualifications (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    corpid VARCHAR(64) NOT NULL,
                    userid VARCHAR(128) NOT NULL,
                    name VARCHAR(128),
                    cert_no VARCHAR(64),
                    qual_status ENUM('qualified','pending','revoked') DEFAULT 'qualified',
                    source VARCHAR(32) DEFAULT 'manual',
                    expires_at DATETIME NULL,
                    added_by VARCHAR(128),
                    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY(corpid, userid)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """
            )
            # wecom_bindings 增加 qual_status 快照列（安全 ALTER，重复忽略）
            try:
                cur.execute(
                    "ALTER TABLE wecom_bindings ADD COLUMN qual_status VARCHAR(16) DEFAULT 'unknown'"
                )
            except Exception:
                pass
            # license_requests 增加 wecom_bind_key（安全 ALTER，重复忽略）
            try:
                cur.execute(
                    "ALTER TABLE license_requests ADD COLUMN wecom_bind_key VARCHAR(64) NULL"
                )
            except Exception:
                pass
            # license_requests 增加 applicant_type（机构/个人双通道，安全 ALTER，重复忽略）
            try:
                cur.execute(
                    "ALTER TABLE license_requests ADD COLUMN applicant_type "
                    "ENUM('institution','individual') NOT NULL DEFAULT 'individual'"
                )
            except Exception:
                pass
    finally:
        c.close()


# ───────────────────────────── 签发 ─────────────────────────────
def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _load_priv():
    if not os.path.exists(PRIV_PATH):
        raise SystemExit("FATAL: 未找到私钥 %s" % PRIV_PATH)
    with open(PRIV_PATH, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def sign_token(email, org, aud, days, lic_id):
    """与 issue_license.py / license_gate.py 完全一致的格式。"""
    priv = _load_priv()
    now = int(time.time())
    payload = {
        "sub": email,
        "org": org,
        "aud": aud,
        "iat": now,
        "exp": now + int(days) * 86400,
        "lic": lic_id,
        "scope": "bank-only",
    }
    pb = _b64u(json.dumps(payload, ensure_ascii=False).encode("utf-8"))
    sig = _b64u(priv.sign(pb.encode("utf-8")))
    return pb + "." + sig


def _gen_lic_id():
    return "LIC-%s-%04d" % (
        datetime.now().strftime("%Y%m%d"),
        int(time.time()) % 10000,
    )


# ───────────────────────────── 鉴权 ─────────────────────────────
def _admin_ok():
    key = request.headers.get("X-API-Key", "") or request.args.get("key", "")
    return bool(key) and hmac.compare_digest(key, ADMIN_KEY)


def require_admin():
    if not _admin_ok():
        abort(401)


# ───────────────────────────── 页面模板 ─────────────────────────────
_APPLY_HTML = """<!doctype html><html lang="zh-CN"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>授权申请 · {{ title }}</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<div class="container py-5" style="max-width:760px">
  <div class="text-center mb-3">
    <h3 class="fw-bold">{{ title }}</h3>
    <p class="text-muted">仅面向银行及持牌金融机构从业人员 · 授权后用于部署本系统</p>
  </div>

  <!-- 双通道选择 -->
  <div class="btn-group w-100 mb-3" role="group">
    <input type="radio" class="btn-check" name="ch" id="ch_ind" autocomplete="off" checked onclick="showCh('individual')">
    <label class="btn btn-outline-primary" for="ch_ind">个人持证人（银行从业）</label>
    <input type="radio" class="btn-check" name="ch" id="ch_ins" autocomplete="off" onclick="showCh('institution')">
    <label class="btn btn-outline-primary" for="ch_ins">机构 / 法人（批量导入）</label>
  </div>

  {% if ok %}
  <div class="alert alert-success">申请已提交，我们将在核验身份后签发授权文件。请留意申请邮箱。</div>
  {% endif %}

  <!-- 通道一：个人持证人 -->
  <div id="sec_individual">
    <div class="d-grid mb-3">
      <a class="btn btn-outline-primary" href="/license-api/wecom/oauth/start">使用企业微信身份快捷申请（自动核验所属真实银行）</a>
    </div>
    {% if wecom_corpid %}
    <div class="alert alert-info">已通过企业微信核验：{{ wecom_corpid }}（提交后将自动绑定在职状态轮巡）</div>
    {% endif %}
    <form method="post" class="card shadow-sm p-4">
      <input type="hidden" name="applicant_type" value="individual">
      <input type="hidden" name="bind" value="{{ bind }}">
      <div class="mb-3"><label class="form-label">企业邮箱 *</label>
        <input type="email" name="email" class="form-control" required placeholder="name@yourbank.com"></div>
      <div class="mb-3"><label class="form-label">机构名称 *</label>
        <input name="org" class="form-control" required placeholder="某银行 XX 分行 / 某持牌机构"></div>
      <div class="mb-3"><label class="form-label">授权部署域名 *</label>
        <input name="domain" class="form-control" required placeholder="your-domain.com（令牌将绑定此域名）"></div>
      <div class="mb-3"><label class="form-label">联系电话</label>
        <input name="contact" class="form-control" placeholder="选填"></div>
      <div class="mb-3"><label class="form-label">用途说明 *</label>
        <textarea name="use_case" class="form-control" rows="3" required placeholder="如：网点客户理财意向采集、内部合规留痕"></textarea></div>
      <div style="position:absolute;left:-9999px" aria-hidden="true"><input name="company" tabindex="-1" autocomplete="off"></div>
      <button class="btn btn-primary w-100">提交申请</button>
    </form>
  </div>

  <!-- 通道二：机构 / 法人（批量导入，人工审核） -->
  <div id="sec_institution" style="display:none">
    <div class="alert alert-warning">
      <b>机构批量导入需人工审核。</b>请先备齐：① 机构持牌证照 ② 营业执照，并通过下方企业微信联系作者核验身份；
      审核通过后将为您开通 <b>corpid 白名单</b> 与 <b>批量导入权限</b>（按 930 金融营销新规，严禁中介冒充银行）。
    </div>
    {% if admin_wecom_qr_url %}
    <div class="text-center mb-3">
      <img src="{{ admin_wecom_qr_url }}" alt="作者企业微信" style="width:220px;max-width:100%;border:1px solid #ddd;border-radius:8px">
      <div class="small text-muted mt-1">扫码联系作者（银行从业者）提交持牌证照与营业执照</div>
    </div>
    {% else %}
    <div class="alert alert-secondary">作者企业微信二维码待配置（ADMIN_WECOM_QR_URL / ADMIN_WECOM_QR_PATH）。请通过其它渠道联系作者。</div>
    {% endif %}
    <form method="post" class="card shadow-sm p-4">
      <input type="hidden" name="applicant_type" value="institution">
      <div class="mb-3"><label class="form-label">机构名称（持牌主体）*</label>
        <input name="org" class="form-control" required placeholder="某银行 / 某持牌机构全称"></div>
      <div class="mb-3"><label class="form-label">授权部署域名 *</label>
        <input name="domain" class="form-control" required placeholder="yourbank.com（令牌将绑定此域名）"></div>
      <div class="mb-3"><label class="form-label">联系人 *</label>
        <input name="contact_name" class="form-control" required placeholder="姓名 / 职务"></div>
      <div class="mb-3"><label class="form-label">联系邮箱 *</label>
        <input type="email" name="email" class="form-control" required placeholder="name@yourbank.com"></div>
      <div class="mb-3"><label class="form-label">联系电话</label>
        <input name="contact" class="form-control" placeholder="选填"></div>
      <div class="mb-3"><label class="form-label">用途 / 持牌证照说明 *</label>
        <textarea name="use_case" class="form-control" rows="3" required placeholder="如：网点客户理财意向采集；已持牌机构编号 / 监管批复文号"></textarea></div>
      <div style="position:absolute;left:-9999px" aria-hidden="true"><input name="company" tabindex="-1" autocomplete="off"></div>
      <button class="btn btn-primary w-100">提交机构申请（进入人工审核）</button>
    </form>
  </div>

  <p class="text-center text-muted small mt-3">{{ copyright }}</p>
</div>
<script>
function showCh(t){
  document.getElementById('sec_individual').style.display = t==='individual'?'block':'none';
  document.getElementById('sec_institution').style.display = t==='institution'?'block':'none';
}
</script>
</body></html>"""

_ADMIN_HTML = """<!doctype html><html lang="zh-CN"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>授权审核后台</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<div class="container py-4">
  <h4 class="fw-bold mb-3">授权审核后台 <span class="badge bg-secondary">bank-only</span></h4>
  <ul class="nav nav-tabs mb-3" id="tabs">
    <li class="nav-item"><a id="tab_app" class="nav-link active" href="#" onclick="showTab('app')">待审 / 全部</a></li>
    <li class="nav-item"><a id="tab_wecom" class="nav-link" href="#" onclick="showTab('wecom')">企业微信核验</a></li>
    <li class="nav-item"><a id="tab_qual" class="nav-link" href="#" onclick="showTab('qual')">执业资格名单</a></li>
  </ul>
  <div id="app"></div>
  <div id="wecom" style="display:none">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h6 class="mb-0">银行 corpid 白名单（自建企业无法伪造真实 corpid）</h6>
      <button class="btn btn-sm btn-outline-secondary" onclick="wecomPoll()">立即轮巡</button>
    </div>
    <form class="row g-2 mb-3" onsubmit="return addCorp(event)">
      <div class="col-auto"><input id="c_corpid" class="form-control form-control-sm" placeholder="corpid" required></div>
      <div class="col-auto"><input id="c_name" class="form-control form-control-sm" placeholder="银行名称"></div>
      <div class="col-auto"><button class="btn btn-sm btn-primary">加入白名单</button></div>
    </form>
    <div id="corps" class="mb-4"></div>
    <h6>绑定与在职状态（每日轮巡 / 离职回调自动更新 · 含执业资格快照）</h6>
    <div id="bindings"></div>
  </div>
  <div id="qual" style="display:none">
    <h6 class="mb-2">授权营销人员名单（执业资格二次校验 · 仅名单内且状态有效者方可保留 License）</h6>
    <form class="row g-2 mb-2" onsubmit="return addQual(event)">
      <div class="col-auto"><input id="q_corpid" class="form-control form-control-sm" placeholder="corpid" required></div>
      <div class="col-auto"><input id="q_userid" class="form-control form-control-sm" placeholder="userid" required></div>
      <div class="col-auto"><input id="q_name" class="form-control form-control-sm" placeholder="姓名"></div>
      <div class="col-auto"><input id="q_cert" class="form-control form-control-sm" placeholder="执业登记编号"></div>
      <div class="col-auto"><button class="btn btn-sm btn-primary">加入名单</button></div>
    </form>
    <form class="mb-3" onsubmit="return importQual(event)">
      <label class="form-label small">批量导入（每行 corpid,userid,姓名,执业登记编号，可粘贴多行）</label>
      <textarea id="q_import" class="form-control form-control-sm" rows="3" placeholder="corp1,zhangsan,张三,A123456&#10;corp2,lisi,李四,B654321"></textarea>
      <button class="btn btn-sm btn-outline-primary mt-1">导入</button>
    </form>
    <div id="quals"></div>
  </div>
</div>
<script>
const KEY = new URLSearchParams(location.search).get('key')||'';
const H={'X-API-Key':KEY};
function showTab(t){
  ['app','wecom','qual'].forEach(id=>{
    document.getElementById(id).style.display = id===t?'block':'none';
  });
  document.getElementById('tab_app').classList.toggle('active', t==='app');
  document.getElementById('tab_wecom').classList.toggle('active', t==='wecom');
  document.getElementById('tab_qual').classList.toggle('active', t==='qual');
  if(t==='wecom'){ loadCorps(); loadBindings(); }
  if(t==='qual'){ loadQuals(); }
}
async function load(){
  const r=await fetch('/license-api/admin/api/requests',{headers:H});
  const d=await r.json();
  const rows=(d.requests||[]).map(x=>{
    const tlabel = x.applicant_type==='institution'?'机构':'个人';
    const ops = x.status==='pending'?`
        ${x.applicant_type==='institution'?`
          <button class=btn btn-sm btn-success onclick="actIns(${x.id})">通过并开通批量导入</button>
        `:`
          <button class=btn btn-sm btn-success onclick="act('approve',${x.id})">批准签发</button>
        `}
        <button class=btn btn-sm btn-outline-danger onclick="act('reject',${x.id})">拒绝</button>`:'';
    const rev = x.lic_id&&x.status==='approved'?`<button class=btn btn-sm btn-warning onclick="revoke('${x.lic_id}')">吊销</button>`:'';
    return `<tr>
      <td>${x.id}</td><td>${x.email}<br><small class=text-muted>${x.org}</small></td>
      <td>${x.domain}</td><td>${tlabel}</td><td>${x.status}</td><td>${x.created_at||''}</td>
      <td>${x.lic_id||'-'}</td>
      <td>${ops}${rev}</td></tr>`;
  }).join('');
  document.getElementById('app').innerHTML=`
   <table class="table table-sm table-bordered bg-white"><thead><tr>
     <th>#</th><th>申请人</th><th>域名</th><th>类型</th><th>状态</th><th>申请时间</th><th>许可号</th><th>操作</th>
   </tr></thead><tbody>${rows||'<tr><td colspan=8>暂无</td></tr>'}</tbody></table>`;
}
async function act(op,id){
  const r=await fetch('/license-api/admin/api/'+op+'/'+id,{method:'POST',headers:H});
  const d=await r.json();
  if(d.token){prompt('已签发，复制此 license.key 内容发给客户：',d.token);}
  else alert(d.detail||JSON.stringify(d));
  load();
}
async function revoke(lic){
  if(!confirm('确认吊销 '+lic+'？吊销后该部署将立即失效。'))return;
  const r=await fetch('/license-api/admin/api/revoke/'+lic,{method:'POST',headers:H});
  alert((await r.json()).detail||'');
  load();
}
async function actIns(id){
  const corpid=prompt('输入该机构经核验的真实企业微信 corpid（将加入白名单；自建企业无法伪造真实银行 corpid）：');
  if(corpid===null)return;
  const corp_name=prompt('输入该机构全称（用于在 NFRA 监管名单辅助核验）：', '');
  const r=await fetch('/license-api/admin/api/approve_institution/'+id,{method:'POST',headers:H,
    body:JSON.stringify({corpid:(corpid||'').trim(),corp_name:(corp_name||'').trim()})});
  const d=await r.json();
  if(d.token) prompt('已签发，复制此 license.key 发给客户：',d.token);
  else alert(d.detail||JSON.stringify(d));
  if(d.hint) alert(d.hint);
  load();
}
async function loadCorps(){
  const r=await fetch('/license-api/admin/api/corps',{headers:H});
  const d=await r.json();
  const rows=(d.corps||[]).map(x=>`
    <tr><td>${x.corpid}</td><td>${x.corp_name||''}</td>
    <td>${x.verified?'<span class=text-success>已核验</span>':'<span class=text-warning>未核验</span>'}</td>
    <td>${x.regulated?'<span class=text-success>监管名单✓</span>':'<span class=text-warning>未命中名单</span>'}</td>
    <td>${x.added_at||''}</td>
    <td><button class=btn btn-sm btn-outline-danger onclick="delCorp('${x.corpid}')">移除</button></td></tr>`).join('');
  document.getElementById('corps').innerHTML=`
   <table class="table table-sm table-bordered bg-white"><thead><tr>
     <th>corpid</th><th>银行名称</th><th>核验</th><th>监管名单</th><th>加入时间</th><th>操作</th>
   </tr></thead><tbody>${rows||'<tr><td colspan=6>暂无白名单</td></tr>'}</tbody></table>`;
}
async function addCorp(e){
  e.preventDefault();
  const corpid=document.getElementById('c_corpid').value.trim();
  const corp_name=document.getElementById('c_name').value.trim();
  const r=await fetch('/license-api/admin/api/corps',{method:'POST',headers:H,
    body:JSON.stringify({corpid,corp_name})});
  alert((await r.json()).detail||'已加入白名单');
  loadCorps();
}
async function delCorp(corpid){
  if(!confirm('移除 '+corpid+' 白名单？'))return;
  const r=await fetch('/license-api/admin/api/corps?corpid='+encodeURIComponent(corpid),{method:'DELETE',headers:H});
  alert((await r.json()).detail||'已移除');
  loadCorps();
}
async function loadBindings(){
  const r=await fetch('/license-api/admin/api/wecom/bindings',{headers:H});
  const d=await r.json();
  const rows=(d.bindings||[]).map(x=>`
    <tr><td>${x.bind_key}</td><td>${x.corpid}</td><td>${x.userid}</td>
    <td>${x.bind_status}</td><td>${x.qual_status||'-'}</td><td>${x.lic_id||'-'}</td><td>${x.last_checked||''}</td></tr>`).join('');
  document.getElementById('bindings').innerHTML=`
   <table class="table table-sm table-bordered bg-white"><thead><tr>
     <th>bind_key</th><th>corpid</th><th>userid</th><th>状态</th><th>资格</th><th>许可号</th><th>最近核查</th>
   </tr></thead><tbody>${rows||'<tr><td colspan=7>暂无绑定</td></tr>'}</tbody></table>`;
}
async function loadQuals(){
  const r=await fetch('/license-api/admin/api/wecom/qualifications',{headers:H});
  const d=await r.json();
  const rows=(d.qualifications||[]).map(x=>`
    <tr><td>${x.corpid}</td><td>${x.userid}</td><td>${x.name||''}</td>
    <td>${x.cert_no||''}</td><td>${x.qual_status}</td><td>${x.expires_at||'长期'}</td>
    <td>${x.added_at||''}</td>
    <td><button class=btn btn-sm btn-outline-danger onclick="delQual('${x.corpid}','${x.userid}')">移除</button></td></tr>`).join('');
  document.getElementById('quals').innerHTML=`
   <table class="table table-sm table-bordered bg-white"><thead><tr>
     <th>corpid</th><th>userid</th><th>姓名</th><th>执业登记编号</th><th>状态</th><th>有效期</th><th>加入时间</th><th>操作</th>
   </tr></thead><tbody>${rows||'<tr><td colspan=8>暂无授权名单</td></tr>'}</tbody></table>`;
}
async function addQual(e){
  e.preventDefault();
  const corpid=document.getElementById('q_corpid').value.trim();
  const userid=document.getElementById('q_userid').value.trim();
  const name=document.getElementById('q_name').value.trim();
  const cert=document.getElementById('q_cert').value.trim();
  const r=await fetch('/license-api/admin/api/wecom/qualifications',{method:'POST',headers:H,
    body:JSON.stringify({corpid,userid,name,cert_no:cert})});
  alert((await r.json()).detail||'已加入');
  loadQuals();
}
async function delQual(corpid,userid){
  if(!confirm('从授权名单移除 '+corpid+'/'+userid+'？移除后其 License 将在下次轮巡被吊销。'))return;
  const r=await fetch('/license-api/admin/api/wecom/qualifications?corpid='+encodeURIComponent(corpid)+'&userid='+encodeURIComponent(userid),{method:'DELETE',headers:H});
  alert((await r.json()).detail||'已移除');
  loadQuals();
}
async function importQual(e){
  e.preventDefault();
  const txt=document.getElementById('q_import').value.trim();
  const rows=txt.split('\n').map(l=>l.trim()).filter(Boolean).map(l=>{
    const p=l.split(',');
    return {corpid:p[0],userid:p[1],name:p[2]||'',cert_no:p[3]||'',expires_at:(p[4]||'').trim()};
  });
  const r=await fetch('/license-api/admin/api/wecom/qualifications/import',{method:'POST',headers:H,
    body:JSON.stringify({rows})});
  const d=await r.json();
  alert('已导入 '+(d.imported||0)+' 条');
  loadQuals();
}
async function wecomPoll(){
  if(!confirm('立即对所有绑定执行企业微信在职轮巡？离职/禁用将自动吊销。'))return;
  const r=await fetch('/license-api/admin/api/wecom/poll',{method:'POST',headers:H});
  const d=await r.json();
  alert('轮巡完成：'+JSON.stringify(d.summary||d));
  loadBindings();
}
load();
</script></body></html>"""


# ───────────────────────────── 路由 ─────────────────────────────
@app.route("/apply", methods=["GET", "POST"])
def apply():
    if request.method == "POST":
        if not _rate_ok():
            return jsonify({"error": "too_many_requests"}), 429
        # honeypot
        if request.form.get("company"):
            return jsonify({"error": "bot"}), 400
        applicant_type = (request.form.get("applicant_type") or "individual").strip()
        if applicant_type not in ("institution", "individual"):
            applicant_type = "individual"
        email = (request.form.get("email") or "").strip()
        org = (request.form.get("org") or "").strip()
        domain = (request.form.get("domain") or "").strip().lower()
        contact = (request.form.get("contact") or "").strip()
        contact_name = (request.form.get("contact_name") or "").strip()
        use_case = (request.form.get("use_case") or "").strip()
        bind = (request.form.get("bind") or "").strip()
        # 机构通道：联系人单独成列，拼接电话
        if applicant_type == "institution":
            contact = (contact_name + (" / " + contact if contact else "")).strip()
        if not (email and org and domain and use_case):
            return jsonify({"error": "missing_fields"}), 400
        if "@" not in email or "." not in domain:
            return jsonify({"error": "invalid"}), 400
        c = _db()
        try:
            with c.cursor() as cur:
                cur.execute(
                    "INSERT INTO license_requests(email,org,domain,contact,use_case,wecom_bind_key,applicant_type) "
                    "VALUES(%s,%s,%s,%s,%s,%s,%s)",
                    (email, org, domain, contact, use_case, bind, applicant_type),
                )
        finally:
            c.close()
        return render_template_string(
            _APPLY_HTML, ok=True, title="授权申请",
            admin_wecom_qr_url=_admin_wecom_qr(),
            copyright="© 授权管理系统 · 仅限持牌金融机构",
        )
    bind = (request.args.get("bind") or "").strip()
    wecom_corpid = ""
    if bind:
        c = _db()
        try:
            with c.cursor() as cur:
                cur.execute(
                    "SELECT corpid FROM wecom_bindings WHERE bind_key=%s AND bind_status='pending'",
                    (bind,),
                )
                row = cur.fetchone()
            wecom_corpid = row["corpid"] if row else ""
        finally:
            c.close()
    return render_template_string(
        _APPLY_HTML, ok=False, title="授权申请", bind=bind, wecom_corpid=wecom_corpid,
        admin_wecom_qr_url=_admin_wecom_qr(),
        copyright="© 授权管理系统 · 仅限持牌金融机构",
    )


@app.route("/admin")
def admin_page():
    require_admin()
    return render_template_string(_ADMIN_HTML)


@app.route("/admin/api/requests")
def api_requests():
    require_admin()
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "SELECT id,email,org,domain,status,lic_id,created_at,applicant_type FROM license_requests "
                "ORDER BY created_at DESC LIMIT 200"
            )
            rows = cur.fetchall()
    finally:
        c.close()
    for r in rows:
        r["created_at"] = str(r["created_at"])
    return jsonify({"requests": rows})


@app.route("/admin/api/approve/<int:req_id>", methods=["POST"])
def api_approve(req_id):
    require_admin()
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "SELECT id,email,org,domain,status,wecom_bind_key FROM license_requests WHERE id=%s", (req_id,)
            )
            row = cur.fetchone()
            if not row:
                return jsonify({"error": "not_found"}), 404
            if row["status"] != "pending":
                return jsonify({"error": "already_%s" % row["status"]}), 409
            days = int(request.json.get("days", 365)) if request.is_json else 365
            lic_id = _gen_lic_id()
            token = sign_token(row["email"], row["org"], row["domain"], days, lic_id)
            exp = datetime.fromtimestamp(int(time.time()) + days * 86400)
            cur.execute(
                "INSERT INTO license_records(lic_id,email,org,domain,scope,token,expires_at) "
                "VALUES(%s,%s,%s,%s,'bank-only',%s,%s)",
                (lic_id, row["email"], row["org"], row["domain"], token, exp),
            )
            cur.execute(
                "UPDATE license_requests SET status='approved',lic_id=%s,reviewer='admin',"
                "reviewed_at=NOW() WHERE id=%s",
                (lic_id, req_id),
            )
            if row.get("wecom_bind_key"):
                wv.activate_binding(row["wecom_bind_key"], lic_id)
    finally:
        c.close()
    return jsonify({"ok": True, "lic_id": lic_id, "token": token,
                    "detail": "已签发，请将 token 作为 license.key 发给客户"})


@app.route("/admin/api/reject/<int:req_id>", methods=["POST"])
def api_reject(req_id):
    require_admin()
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute("SELECT id,status FROM license_requests WHERE id=%s", (req_id,))
            row = cur.fetchone()
            if not row:
                return jsonify({"error": "not_found"}), 404
            cur.execute(
                "UPDATE license_requests SET status='rejected',reviewer='admin',reviewed_at=NOW() WHERE id=%s",
                (req_id,),
            )
    finally:
        c.close()
    return jsonify({"ok": True, "detail": "已拒绝"})


@app.route("/admin/api/approve_institution/<int:req_id>", methods=["POST"])
def api_approve_institution(req_id):
    """机构通道审批：签发令牌 + 将经核验的真实银行 corpid 加入白名单（开门批量导入）。

    反冒充要点：corpid 由腾讯企业微信全局唯一分配，中介自建企业无法伪造真实银行 corpid；
    本接口仅在人工核验持牌证照+营业执照后，由作者录入真实 corpid，绝不以机构名称字眼作为准入依据。
    """
    require_admin()
    d = request.get_json(force=True, silent=True) or {}
    corpid = (d.get("corpid") or "").strip()
    corp_name = (d.get("corp_name") or "").strip()
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "SELECT id,email,org,domain,status FROM license_requests WHERE id=%s", (req_id,)
            )
            row = cur.fetchone()
            if not row:
                return jsonify({"error": "not_found"}), 404
            if row["status"] != "pending":
                return jsonify({"error": "already_%s" % row["status"]}), 409
            days = int(d.get("days", 365))
            lic_id = _gen_lic_id()
            token = sign_token(row["email"], row["org"], row["domain"], days, lic_id)
            exp = datetime.fromtimestamp(int(time.time()) + days * 86400)
            cur.execute(
                "INSERT INTO license_records(lic_id,email,org,domain,scope,token,expires_at) "
                "VALUES(%s,%s,%s,%s,'bank-only',%s,%s)",
                (lic_id, row["email"], row["org"], row["domain"], token, exp),
            )
            cur.execute(
                "UPDATE license_requests SET status='approved',lic_id=%s,reviewer='admin',"
                "reviewed_at=NOW() WHERE id=%s",
                (lic_id, req_id),
            )
    finally:
        c.close()
    hint = ""
    if corpid:
        wv.add_corp_whitelist(corpid, corp_name or row["org"], "admin")
        ok, bn = wv.is_regulated_bank(corp_name or row["org"])
        hint = ("已在 NFRA 监管名单内（%s）" % bn) if ok else "注意：该机构全称未在 NFRA 监管名单内，请人工复核持牌证照"
    return jsonify({"ok": True, "lic_id": lic_id, "token": token,
                    "whitelist": bool(corpid), "hint": hint,
                    "detail": "已签发并开通批量导入（corpid 已入白名单）"})


def revoke_license(lic_id, reason="", by="admin"):
    """吊销核心：写入吊销表 + 置 license_records 失效。手动吊销与自动吊销共用。"""
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute(
                "INSERT INTO license_revokes(lic_id,reason,revoked_by) VALUES(%s,%s,%s) "
                "ON DUPLICATE KEY UPDATE reason=%s, revoked_at=NOW()",
                (lic_id, reason, by, reason),
            )
            cur.execute("UPDATE license_records SET status='revoked' WHERE lic_id=%s", (lic_id,))
    finally:
        c.close()
    return True


@app.route("/admin/api/revoke/<lic_id>", methods=["POST"])
def api_revoke(lic_id):
    require_admin()
    reason = (request.json or {}).get("reason", "") if request.is_json else ""
    revoke_license(lic_id, reason, "admin")
    return jsonify({"ok": True, "detail": "已吊销 %s，该部署将立即失效" % lic_id})


@app.route("/revoke/<lic_id>")
def revoke_check(lic_id):
    """供客户侧 license_gate.py 电话回家。已吊销→200+'1'；未吊销→404。"""
    c = _db()
    try:
        with c.cursor() as cur:
            cur.execute("SELECT lic_id FROM license_revokes WHERE lic_id=%s", (lic_id,))
            row = cur.fetchone()
    finally:
        c.close()
    if row:
        return "1", 200
    return "", 404


# ───────────────────────────── 企业微信核验路由 ─────────────────────────────
@app.route("/wecom/oauth/start")
def wecom_oauth_start():
    cfg = wv.WeComConfig()
    if not cfg.enabled:
        return jsonify({"error": "wecom_not_configured"}), 503
    proto = request.headers.get("X-Forwarded-Proto", "https")
    base = os.environ.get("LICENSE_BASE_URL") or "%s://%s" % (proto, request.host)
    redirect_uri = base.rstrip("/") + "/license-api/wecom/oauth/callback"
    state = secrets.token_hex(8)
    return redirect(cfg.oauth_authorize_url(redirect_uri, state))


@app.route("/wecom/oauth/callback")
def wecom_oauth_callback():
    code = request.args.get("code", "")
    if not code:
        return "授权失败：缺少 code", 400
    bind_key, err = wv.handle_oauth_callback(code, request.args.get("state", ""))
    if err:
        return "企业微信核验未通过：%s" % err, 403
    return redirect("/license-api/apply?bind=" + bind_key)


@app.route("/wecom/qr")
def wecom_qr():
    """作者企业微信二维码图片（机构通道人工审核时引导联系作者）。由 ADMIN_WECOM_QR_PATH 指定本地文件。"""
    p = os.environ.get("ADMIN_WECOM_QR_PATH", "")
    if not p or not os.path.exists(p):
        return "no qr configured", 404
    return send_file(p, mimetype="image/jpeg", max_age=86400)


@app.route("/license-api/admin/api/reload-regulated", methods=["POST"])
def api_reload_regulated():
    """热重载监管名单：每日同步脚本更新 regulated_banks.json 后调用，使内存缓存即时生效。"""
    require_admin()
    info = wv.reload_regulated_list()
    return jsonify({"ok": True, "banks": len(info.get("banks", [])), "source": info.get("source", "")})


@app.route("/wecom/callback", methods=["GET", "POST"])
def wecom_callback():
    """通讯录变更事件接收（离职实时吊销）。GET 用于 URL 校验回显 echostr。"""
    cfg = wv.WeComConfig()
    msg_signature = request.args.get("msg_signature", "")
    timestamp = request.args.get("timestamp", "")
    nonce = request.args.get("nonce", "")
    if request.method == "GET":
        echostr = request.args.get("echostr", "")
        try:
            return wv.decrypt_event(cfg.callback_token, cfg.callback_aeskey,
                                    msg_signature, timestamp, nonce, echostr)
        except Exception:
            return "verify fail", 403
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring(request.get_data(as_text=True))
        encrypt = root.findtext("Encrypt")
    except Exception:
        return "bad", 400
    try:
        xml_text = wv.decrypt_event(cfg.callback_token, cfg.callback_aeskey,
                                    msg_signature, timestamp, nonce, encrypt)
    except Exception:
        return "decrypt fail", 403
    wv.handle_contact_event(xml_text)
    return "success"


@app.route("/admin/api/corps", methods=["GET", "POST", "DELETE"])
def api_corps():
    require_admin()
    if request.method == "GET":
        corps = wv.list_corps()
        for x in corps:
            ok, bn = wv.is_regulated_bank(x.get("corp_name") or "")
            x["regulated"] = ok
            x["regulated_name"] = bn or ""
        return jsonify({"corps": corps})
    if request.method == "POST":
        d = request.get_json(force=True, silent=True) or {}
        corpid = (d.get("corpid") or "").strip()
        name = (d.get("corp_name") or "").strip()
        if not corpid:
            return jsonify({"error": "missing_corpid"}), 400
        wv.add_corp_whitelist(corpid, name)
        ok, bn = wv.is_regulated_bank(name)
        return jsonify({"ok": True, "regulated": ok, "regulated_name": bn or "",
                        "hint": ("已在 NFRA 监管名单内（%s）" % bn) if ok
                        else "未在 NFRA 监管名单内，请人工复核持牌证照"})
    corpid = request.args.get("corpid") or (request.get_json(force=True, silent=True) or {}).get("corpid", "")
    if not corpid:
        return jsonify({"error": "missing_corpid"}), 400
    wv.delete_corp(corpid)
    return jsonify({"ok": True})


@app.route("/admin/api/bind/<lic_id>", methods=["POST"])
def api_bind(lic_id):
    require_admin()
    d = request.get_json(force=True, silent=True) or {}
    corpid = (d.get("corpid") or "").strip()
    userid = (d.get("userid") or "").strip()
    if not corpid or not userid:
        return jsonify({"error": "missing"}), 400
    ok, msg = wv.bind_license(lic_id, corpid, userid)
    if not ok:
        return jsonify({"error": msg}), 400
    return jsonify({"ok": True, "detail": msg})


@app.route("/admin/api/wecom/bindings")
def api_bindings():
    require_admin()
    return jsonify({"bindings": wv.list_bindings()})


@app.route("/admin/api/wecom/poll", methods=["POST"])
def api_wecom_poll():
    require_admin()
    summary = wv.poll_all()
    return jsonify({"ok": True, "summary": summary})


@app.route("/admin/api/wecom/qualifications", methods=["GET", "POST", "DELETE"])
def api_qualifications():
    require_admin()
    if request.method == "GET":
        corpid = request.args.get("corpid")
        return jsonify({"qualifications": wv.list_qualifications(corpid)})
    if request.method == "POST":
        d = request.get_json(force=True, silent=True) or {}
        corpid = (d.get("corpid") or "").strip()
        userid = (d.get("userid") or "").strip()
        if not corpid or not userid:
            return jsonify({"error": "missing"}), 400
        wv.add_qualification(corpid, userid, d.get("name", ""), d.get("cert_no", ""),
                             "qualified", "manual", d.get("expires_at"), "admin")
        return jsonify({"ok": True, "detail": "已加入授权营销人员名单"})
    corpid = request.args.get("corpid") or (request.get_json(force=True, silent=True) or {}).get("corpid", "")
    userid = request.args.get("userid") or (request.get_json(force=True, silent=True) or {}).get("userid", "")
    if not corpid or not userid:
        return jsonify({"error": "missing"}), 400
    wv.delete_qualification(corpid, userid)
    return jsonify({"ok": True, "detail": "已移除"})


@app.route("/admin/api/wecom/qualifications/import", methods=["POST"])
def api_qualifications_import():
    require_admin()
    d = request.get_json(force=True, silent=True) or {}
    rows = d.get("rows", [])
    n = wv.bulk_add_qualifications(rows)
    return jsonify({"ok": True, "imported": n, "detail": "已导入 %d 条" % n})


@app.route("/healthz")
def healthz():
    return jsonify({"ok": True})


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "poll":
        init_db()
        print(json.dumps(wv.poll_all(), ensure_ascii=False))
        sys.exit(0)
    init_db()
    app.run(host="127.0.0.1", port=8099)
