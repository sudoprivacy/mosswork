#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
flask_license_guard.py —— 把授权闸门接入 Flask 后端的示例守卫

银行客户部署自己的 app.py 时，按下面三步接入即可实现「无有效令牌 → 拒绝服务」：
  1) 把本文件与 license_gate.py 放到 app.py 同目录
  2) 在 app.py 顶部：  from flask_license_guard import startup_check, require_license, LICENSE_STATUS
  3) 在 create_app() 里： startup_check(expected_aud="你的域名")   （失败会抛 RuntimeError 阻止启动）
     在需要保护的视图上： @require_license

无令牌 / 伪造 / 过期 / 域名不符 / 已吊销 → 公开接口与看板均返回 403，
H5 页面可调用 GET /api/license/status 展示授权状态横幅。

（本文件不含任何私钥，可随系统分发。）
"""

import functools

from license_gate import verify_license, license_status_text

# 授权文件默认位置：与 app.py 同目录下的 license.key
import os
LICENSE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "license.key")

LICENSE_OK = False
LICENSE_INFO = {}


def startup_check(expected_aud: str = None, license_path: str = None, strict: bool = True):
    """
    在应用启动时调用。strict=True 时校验不通过直接抛异常阻止启动；
    strict=False 时仅记录，由具体接口装饰器兜底拒绝。
    """
    global LICENSE_OK, LICENSE_INFO
    path = license_path or LICENSE_PATH
    ok, info = verify_license(path, expected_aud)
    LICENSE_OK = ok
    LICENSE_INFO = info if ok else {"reason": info}
    if not ok and strict:
        raise RuntimeError("授权校验未通过，系统拒绝启动：%s" % info)
    return ok, info


def require_license(view):
    """视图装饰器：未授权时返回 403。"""

    @functools.wraps(view)
    def wrapper(*args, **kwargs):
        if not LICENSE_OK:
            reason = LICENSE_INFO.get("reason", "未授权")
            from flask import jsonify
            return jsonify({"error": "unauthorized", "detail": reason}), 403
        return view(*args, **kwargs)

    return wrapper


def register_status_endpoint(app, expected_aud: str = None, license_path: str = None):
    """注册 GET /api/license/status，供 H5 / 看板展示授权横幅。"""

    @app.route("/api/license/status")
    def _license_status():
        from flask import jsonify
        path = license_path or LICENSE_PATH
        ok, info = verify_license(path, expected_aud)
        if ok:
            return jsonify({"authorized": True, "org": info.get("org"),
                            "exp": info.get("exp"), "lic": info.get("lic")})
        return jsonify({"authorized": False, "detail": info})


# 供模板直接 import 的便捷文本
def status_text(expected_aud: str = None, license_path: str = None) -> str:
    return license_status_text(license_path or LICENSE_PATH, expected_aud)
