#!/usr/bin/env python3
"""
字段加密工具（脱敏模板，R1 / D1 双模式）

- R1 随机化（Fernet）：用于不参与统计的字段（如 verification_code）
- D1 确定性（AES-GCM-SIV，固定 nonce）：用于需 GROUP BY 的统计字段
- 密文带前缀 R1: / D1: 以兼容遗留明文，解密失败原样返回

依赖：pip install cryptography
替换项：<FIELD_KEY_PATH> 字段加密密钥文件路径（600 权限，异地多份保存）

用法：
    from crypto_util import enc_det, dec_det, enc_rand, dec_rand, is_encrypted
"""
import os
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.ciphers.aead import AESGCMSIV

KEY_FILE = "<FIELD_KEY_PATH>"
_NONCE = b"\x00" * 12  # D1 固定 nonce，保证同值同密文


def _fernet():
    pem = open(KEY_FILE, "rb").read()
    return Fernet(pem)


def _aesgcm_siv():
    raw = open(KEY_FILE, "rb").read()
    return AESGCMSIV(raw)


def is_encrypted(value):
    if not isinstance(value, str):
        return False
    return value.startswith("R1:") or value.startswith("D1:")


def enc_rand(plain):
    """随机化加密（R1）。"""
    if plain is None:
        return None
    return "R1:" + _fernet().encrypt(str(plain).encode()).decode()


def dec_rand(cipher):
    """R1 解密。"""
    if not is_encrypted(cipher) or not cipher.startswith("R1:"):
        return cipher
    try:
        return _fernet().decrypt(cipher[3:].encode()).decode()
    except Exception:
        return cipher


def enc_det(plain):
    """确定性加密（D1），同值同密文。"""
    if plain is None:
        return None
    return "D1:" + _aesgcm_siv().encrypt(str(plain).encode(), None, _NONCE).hex()


def dec_det(cipher):
    """D1 解密。"""
    if not is_encrypted(cipher) or not cipher.startswith("D1:"):
        return cipher
    try:
        raw = bytes.fromhex(cipher[3:])
        return _aesgcm_siv().decrypt(raw, None, _NONCE).decode()
    except Exception:
        return cipher


if __name__ == "__main__":
    # 简单自测
    for fn, enc, dec in [("R1", enc_rand, dec_rand), ("D1", enc_det, dec_det)]:
        c = enc("test-value")
        print(fn, c, "->", dec(c))
