# 问卷设计指南（提炼自真实上线站点）

本指南的问卷结构、交互机制与字段映射，全部提炼自已上线运行的银行获客 H5。可直接照抄蓝本，也可按第六节定制到你的业务。

## 一、设计原则（先理解，再照抄）

1. **全部标注「可选」**：高意愿信号来自"客户愿意填"，强制填写反而造成流失。宁可少收，不可赶客。
2. **标签式点选，不让客户打字**：移动端最快 3 秒完成，转化率远高于输入框。
3. **教育内容前置**：先给客户讲清「标准普尔 4321」再问保险配置——客户理解了框架，才愿意填、且填得更准。
4. **静默保存 + 主动触发推送**（核心机制）：
   - 客户点选时 → 静默 `PATCH` 保存（**不带** `notify`），不打扰、不刷屏
   - 客户点「联系客户经理」或「我已添加企业微信」→ `PATCH` 带 `notify=true` → 企微推送**完整问卷数据**
   - `visibilitychange` 兜底：客户扫码切到微信时自动触发推送
5. **敏感字段加密落库**：`financial_needs` / `insurance_types` / `annual_premium` 走 R1/D1 加密，不明文。
6. **结束环节要明确**：底部绿色「理财建议完成」区 + 大按钮，给客户明确的完成感与下一步动作。

> 为什么这样设计？——**填了问卷 = 高意愿潜力理财客户**。这套机制让你既拿到结构化数据，又不错过任何一个高意愿信号的实时触达。

## 二、问卷蓝本（4 题，可直接照抄）

### Q1 您主要使用哪家银行？（单选）

> 引导语：若您关注到其他银行有值得关注的做法或活动，欢迎在企业微信中告知客户经理，便于后续为您推送相关信息

选项：农业银行 / 工商银行 / 建设银行 / 中国银行 / 招商银行 / 邮储银行 / 其他银行

- 字段：`selected_bank`
- 作用：了解客户主账户行，判断交叉营销空间

### Q2 金融需求（多选）

> 引导语：告诉我们您的日常需求，帮助客户经理了解您的需求方向

选项：`出差旅行` / `有车加油` / `日常消费` / `健康管理` / `家庭消费` / `境外海淘` / `科技AI` / `暂不需要`

- 字段：`financial_needs`（JSON 数组）
- **加密**：D1（确定性，需 GROUP BY 统计）

### Q3 保险配置参考（多选）— 前置教育内容

> 引导语：选择您的保险配置情况，客户经理可结合标准普尔模型帮您判断配置是否合理

**必须先放这段教育内容**（客户看懂了才填得准）：

- **标准普尔 4321 定律**：10% 要花的钱（日常开销，预留 3–6 个月生活费）／20% 保命的钱（意外险、医疗险、重疾险、定期寿险）／30% 生钱的钱（股票基金等投资增值）／40% 保本升值的钱（养老金、教育金等长期储蓄）
- **⚠️ 险种不能笼统归类**：意外险、医疗险、重疾险、定期寿险 → 属 20%「保命的钱」；年金险、两全险、终身寿险 → 属 40%「保本升值的钱」。所以前者保费参考占收入约 **5%–10%**，年金险另行规划。
- **不同年龄可微调**（幅度建议 ±5% 以内）：20–30 岁生钱的钱可略增；30–50 岁保命的钱需增加（定期寿险尤重要）；50 岁以上保本升值的钱应提高、生钱的钱降低。

选项：`重疾险` / `医疗险` / `意外险` / `定期寿险` / `年金险` / `两全险` / `终身寿险` / `暂无保障`

- 字段：`insurance_types`（JSON 数组）
- **加密**：D1

### Q4 您当前年交保费（单选）

> 引导语：实际每年交多少钱

选项：`5000元以下/年` / `5000-1万元/年` / `1-3万元/年` / `3-5万元/年` / `5万元以上/年` / `不确定`

- 字段：`annual_premium`（取单个值）
- **加密**：D1

### 配置合理性示例（放在 Q4 下方，增强说服力）

> 假设某家庭年收入 15 万元，当前意外险+医疗险+重疾险+定期寿险年交保费 3000 元。按标准普尔「保命的钱」占 20% 参考线（约 3 万元），其中这四类险种保费合理支出约 7500–1.5 万/年（占收入 5%–10%），当前仅占 2%，**保障明显不足**。若为 3 万则占收入 20%，**超出合理范围**，可能挤占其他必要支出。

## 三、字段映射与提交方式

| 问卷题 | 题型 | DB 字段 | 加密 | 提交方式 |
|--------|------|---------|------|----------|
| Q1 主要银行 | 单选 | `selected_bank` | 否 | `PATCH`（静默 / notify 两种） |
| Q2 金融需求 | 多选 | `financial_needs`（JSON） | **D1** | 同上 |
| Q3 保险类型 | 多选 | `insurance_types`（JSON） | **D1** | 同上 |
| Q4 年交保费 | 单选 | `annual_premium` | **D1** | 同上 |

提交载荷结构（同源 `PATCH`，标准 fetch）：

```js
var optionalData = {
  selected_bank:   selectedBank || null,
  financial_needs: financialNeeds.length  > 0 ? JSON.stringify(financialNeeds) : null,
  insurance_types: insuranceTypes.length  > 0 ? JSON.stringify(insuranceTypes) : null,
  annual_premium:  annualPremiumTags.length > 0 ? annualPremiumTags[0] : null
};
if (notify) { optionalData.notify = true; }   // 仅主动触发时才推送企微
```

## 四、可复制的前端片段

```html
<!-- Q2 多选示例：金融需求 -->
<div class="card">
  <div class="card-title"><span class="icon">💳</span> 金融需求（可选）</div>
  <p style="font-size:13px;color:#666;margin-bottom:8px;">告诉我们您的日常需求，帮助客户经理了解您的需求方向</p>
  <div class="tag-list" id="creditNeeds">
    <div class="tag" onclick="toggleNeed(this)" data-need="出差旅行">出差/旅行</div>
    <div class="tag" onclick="toggleNeed(this)" data-need="有车加油">有车/加油</div>
    <div class="tag" onclick="toggleNeed(this)" data-need="日常消费">日常消费</div>
    <div class="tag" onclick="toggleNeed(this)" data-need="健康管理">健康管理</div>
    <div class="tag" onclick="toggleNeed(this)" data-need="家庭消费">家庭消费</div>
    <div class="tag" onclick="toggleNeed(this)" data-need="境外海淘">境外/海淘</div>
    <div class="tag" onclick="toggleNeed(this)" data-need="科技AI">科技/AI</div>
    <div class="tag" onclick="toggleNeed(this)" data-need="暂不需要">暂不需要</div>
  </div>
</div>
```

```js
// 多选：点选即切换
function toggleNeed(el){ el.classList.toggle('selected'); autoSubmitOptional(false); }

// 单选：先清空同级，再选中
function selectSingle(el){
  el.parentNode.querySelectorAll('.tag').forEach(t => t.classList.remove('selected'));
  el.classList.add('selected');
  autoSubmitOptional(false);
}

// 静默保存（force=false 无数据不发；notify=true 才推企微）
function autoSubmitOptional(force, notify){
  var hasData = optionalData.selected_bank || optionalData.financial_needs ||
                optionalData.insurance_types || optionalData.annual_premium;
  if (!hasData && !force) return;
  if (notify) { optionalData.notify = true; }
  fetch('/api/public/authorizations/<CODE>', {
    method: 'PATCH',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(optionalData)
  });
}
```

## 五、结束环节（决定转化率的关键）

```html
<div style="font-size:18px;font-weight:700;color:#2e7d32;">🎉 理财建议参考已完成</div>
<div>以上为您的资产配置建议参考，请添加企业微信获取后续服务</div>
<div>📱 添加企业微信 / 联系客户经理</div>
<!-- 点此按钮：autoSubmitOptional(true, true) → 推完整问卷到企微 -->
```

配合 `visibilitychange` 监听兜底：客户点开二维码切到微信时自动补一次 `notify=true` 推送。

## 六、定制到你的业务

保留这套**「标签点选 + 静默保存 + 主动触发 + 加密落库」四件套**，只替换内容：

- **换行业**（教育/保险/汽车）：保留 4 题骨架，把选项文案换成你的业务维度（如课程类型、险种、车型偏好）。
- **换主体**：Q1 的银行列表换成你的机构与竞品列表。
- **风险评估前置提示**：蓝本中是「先前往农行掌银 APP 完成风险评估」，换成**你所在银行的 APP 名称与路径**（占位符 `<YOUR_BANK_APP>`）；未完成风险评估不得提供匹配风险等级的建议。
- **加密字段随题目调整**：新增的敏感多选题，一律加 D1 加密并纳入隐私声明披露。

## 七、合规注意（必读）

- 问卷项属个人信息，**须在 `privacy.html` 中按实际收集披露**，不得谎称不收集。
- **「暂不需要 / 暂无保障 / 不确定」必须保留**——这是给客户的拒绝权与退出选项。
- 风险评估前置：未完成风险评估的客户，**不得**提供匹配风险等级的理财建议。
- 所有问卷数据经企微推送时只在客户**主动点击**后推送，避免未经触发的批量外发。
