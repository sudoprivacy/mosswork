# 企业微信核验 + 离职自动吊销 技术设计文档

> 配套模块：`scripts/wecom_verifier.py` + `scripts/license_server.py`（已集成并部署验证）
> 适用场景：把"是否为银行从业人员"的判定，从纯人工审批升级为
> **「企业微信所属企业核验 + 每日轮巡 / 离职回调 + 自动吊销 + 异常转人工」** 的自动闭环。

---

## 1. 背景与目标

原授权闸门（`license_server`）依赖作者**人工审核**银行人员身份。人工审批存在时效缺口：
审批人不在 / 积压时，已离职员工可能数日内仍能使用系统。

本设计把"银行从业人员"判定**下沉到企业微信真实组织关系**：
- 员工经企业微信网页授权，系统拿到其 `(corpid, userid)`；
- `corpid` 必须命中**银行白名单**（自建企业无法伪造真实 corpid）；
- 已签发 License 与 `(corpid, userid)` 绑定；
- 每日轮巡或离职事件回调检测到"成员离职 / 禁用 / 不在企业" → **自动吊销** License；
- 任何接口异常 / 无法识别 → **转人工**（fail-open），绝不误杀在职员工。

合规上满足《个人信息保护法》第 24 条"自动化决策 + 人工干预/申诉"的强制要求。

---

## 2. 总体架构

```
银行员工（企业微信）
   │ 网页授权 code
   ▼
license_server /wecom/oauth/start → 企业微信授权页
   │ 回调 code
   ▼
/wecom/oauth/callback → getuserinfo → (corpid, userid)
   │ 校验 corpid ∈ 白名单 → 建立 pending 绑定
   ▼
申请页 /apply?bind=xxx → 作者审核 → approve → 激活绑定 + 签发 License
   │
   │  ┌─ 离职事件回调（秒级，优先）─┐
   │  │  /wecom/callback            │
   │  └────────────┬────────────────┘
   │               ▼
   │         handle_contact_event → find_binding_by_user → evaluate_and_act(LEFT) → revoke_license
   │
   └─ 每日轮巡（兜底，03:17）──┐
        license_server.py poll → poll_all() ─┘
              │ provider_token → corp_token → user/get
              │ status∈{2禁用,5离职} / 不存在(60111) → LEFT → 吊销
              │ 其他错误 → ERROR → 转人工（不吊销）
              ▼
        revoke_license(lic) → license_revokes 落表 + license_records.status='revoked'
              ▼
        客户侧 license_gate.py 电话回家 GET /revoke/<lic_id> → 返回 200+'1' → 部署失效
```

---

## 3. 企业微信接入模型（服务商第三方应用）

必须采用**服务商第三方应用**模式，而非自建应用：

| 模式 | 能否跨企业读成员 | 说明 |
|------|------------------|------|
| 自建应用 | ❌ 只能读本企业 | 无法验证"该员工属于哪家银行" |
| 服务商第三方应用 | ✅ 每家银行授权安装后可读其通讯录 | 满足"识别所属银行"诉求 |

流程：
1. 作者在服务商后台创建应用，拿到 `provider_corpid` / `provider_secret` / `suite_id` / `suite_secret` / `agent_id`。
2. 每家合作银行在服务商后台**授权安装**本应用，企业微信推送 `permanent_code`，存入 `wecom_corp_auth`。
3. 员工注册时走第三方网页授权 `snsapi_userinfo`，`code` → `getuserinfo` → `(corpid, userid)`。

> 真实调用所需的 `requests`、`pycryptodome`（事件回调解密）已在服务器安装；
> 未配置凭据时 `WeComConfig.enabled=False`，轮巡自动降级为"全部转人工"，不会误吊销。

---

## 4. corpid 白名单防伪造

"在某企业微信里"不等于"在真实银行里"——有人可自建同名企业蒙混。

解决办法：维护 **`wecom_corp_whitelist`（corpid, corp_name, verified）**。
- 白名单由作者从银行官方渠道获取真实 corpid 后手动加入（`/admin/api/corps` POST）；
- 网页授权拿到的 `corpid` **必须命中白名单**才建立绑定，否则拒绝（`handle_oauth_callback` 返回 403）；
- 自建企业无法伪造真实 corpid，因此伪造被天然阻断。

白名单管理接口（均需 `X-API-Key`）：
- `GET /admin/api/corps` 列表
- `POST /admin/api/corps` 加入（corpid, corp_name）
- `DELETE /admin/api/corps?corpid=...` 移除

---

## 5. 每日轮巡 vs 离职回调（事件优先）

| 手段 | 时效 | 角色 | 失败处理 |
|------|------|------|----------|
| 离职事件回调 `/wecom/callback` | 秒级 | 主链路 | 接口抖动不影响，由轮巡兜底 |
| 每日轮巡 `license_server.py poll` | ≤24h | 兜底 | 遗漏事件时仍能吊销 |

**事件优先**：订阅通讯录变更事件 `delete_user` / `update_user`（Status∈{2,5}）→ 实时吊销。
**轮巡兜底**：systemd `license-poll.timer` 每日 03:17 触发 `license_server.py poll`，
遍历所有 `bind_status='active'` 绑定，逐一对企业微信 `user/get` 判定在职状态。

---

## 6. FAIL-OPEN 原则（防误杀在职员工）

这是合规与安全的生命线：

- 仅当企业微信**明确返回**"成员不存在(60111) / 已禁用(2) / 已离职(5)"时，才判定 `LEFT` 并吊销；
- 任何网络超时、API 报错、无 permanent_code、未配置凭据 → 判定 `ERROR`，**仅标记 `bind_status='error'`，不吊销**，转入人工审核队列；
- 状态机：`active / left / unknown / error`，其中 `unknown`/`error` 一律**不自动吊销**。

代码印证（`wecom_verifier.evaluate_and_act`）：
```python
if state == MemberState.LEFT:
    _revoke(lic_id, reason, "wecom")   # 仅 LEFT 触发吊销
# ERROR / UNKNOWN 仅更新 bind_status，不调用 _revoke
```

---

## 7. 与 license_server / license_gate 的对接

- **吊销复用同一条链路**：`wecom_verifier._revoke()` → `license_server.revoke_license()`，
  与作者手动吊销（`/admin/api/revoke`）走完全相同的落表逻辑（`license_revokes` + `license_records.status='revoked'`），
  保证客户侧 `license_gate.py` 电话回家得到一致的作废结果。
- **绑定维度**：License 与 `(corpid, userid)` 通过 `wecom_bindings` 关联；审批通过时 `activate_binding(bind_key, lic_id)` 激活。
- **客户侧透明**：客户部署 `license_gate.py` 无需任何改动，仍按 `REVOKE_URL` 电话回家即可感知企业微信侧吊销。

---

## 8. 合规映射

| 法规/要求 | 本设计覆盖 |
|-----------|-----------|
| PIPL 第24条 自动化决策透明+公平+人工干预 | ✅ 自动吊销 + 异常转人工兜底 |
| 金融营销"销售人员实名 + 可回溯" | ⚠️ 解决"是否银行员工"，未解决"是否有营销执业资格" |
| 银行保险机构从业人员执业登记管理 | ❌ 需叠加**执业登记编号 / 授权营销人员名单**二次校验 |
| 审计留痕 / 监管检查 | ✅ 事件驱动 + `wecom_bindings.last_checked` 留痕 |
| 数据安全/最小化（corpid、userid 属关联身份） | ⚠️ 需隐私告知同意 + 加密存储 + 留存期限 |

**关键补足建议**：corpid 白名单仅证明"在这家银行"，银行内 IT/行政/HR 也在企业微信中但无权做互联网营销。
合规上应叠加**执业登记编号 / 银行内部"授权营销人员名单"**比对，形成"企业微信归属 + 执业资格"双因子，
并满足监管对销售人员互联网营销的专门规定（银保监 / 金融监管总局）。

**个人信息处理义务**：采集企业微信身份属个人信息处理，须有隐私告知与授权（注册页勾选同意），
且自动吊销后给当事人申诉/恢复入口（人工兜底节点即此）。

---

## 9. 部署与运维（已验证）

服务器已部署并端到端验证：

- 文件：`/opt/license_server/{license_server.py, wecom_verifier.py, keys/license_private_key.pem}`
- 数据库：`license_srv` 库新增 `wecom_corp_whitelist` / `wecom_corp_auth` / `wecom_bindings` 三张表
- 服务：`license-server.service`（gunicorn 8099），`license-poll.timer`（每日 03:17 轮巡）
- 依赖：`requests` + `pycryptodome` 已安装

验证结论：
- 轮巡识别 `LEFT` → `license_records.status='revoked'`、吊销表落行、`binding_status='left'` ✅
- 接口异常 `ERROR` → 不吊销、`binding_status='error'`、转人工 ✅（fail-open 生效）

管理后台（`/admin`，`?key=`）新增"企业微信核验"标签页：
白名单增删查、绑定与在职状态列表、立即轮巡按钮。

---

## 10. 风险与边界

- **非执业资格校验（已部分解决）**：第 11 章已叠加"执业资格二次校验"（授权营销人员名单双因子），解决"是否有营销资格"；但本设计仍不解决内容合规（话术审核、双录留痕），需另行建设。
- **fail-open 窗口**：ERROR 状态最长 24h 内由轮巡 + 人工兜底，不会无限期误杀，但也不会立即吊销——这是有意的安全取舍。
- **企业微信 API 依赖**：若企业微信接口长期不可达，所有绑定转为 `error` 并堆积人工队列，需监控告警。
- **司法边界**：以上为工程合规框架，正式上线前须经银行合规/法务确认"企业微信归属 + 执业编号"组合满足其监管口径。

---

## 11. 执业资格二次校验（双因子准入）

### 11.1 为什么必须
corpid 白名单仅证明"该成员属于某家银行"，但银行内 IT、行政、HR、风控等岗位同样在企业微信通讯录中，却无权从事互联网营销。监管（银保监 / 金融监管总局对销售人员互联网营销有专门规定）要求的是"销售人员实名 + 执业登记可回溯"。因此必须在"组织关系"之上叠加"执业资格"作为第二道闸。

### 11.2 数据模型
新增表 `wecom_qualifications`（授权营销人员名单）：
- `corpid` / `userid`：联合唯一键，定位到人
- `name` / `cert_no`：姓名 / 执业登记编号（或银行内部授权营销人员编号）
- `qual_status`：qualified / pending / revoked
- `source`：manual（后台添加）/ import（批量导入）
- `expires_at`：资格有效期（可选，过期即失效）
- `added_by` / `added_at`：审计留痕

`wecom_bindings` 增加 `qual_status` 快照列（绑定 / 审批 / 每次轮巡时刷新），后台可直接观测。

### 11.3 判定逻辑（轮巡）
对每个 `bind_status='active'` 的绑定：
1. **在职状态**：`LEFT`（离职 / 禁用 / 不存在 60111）→ 吊销（原因：企业微信离职）
2. **ERROR**（接口异常 / 无法识别）→ fail-open，标记 `error` 转人工，**不吊销**
3. **在职** → 查 `wecom_qualifications`：
   - `qualified` 且未过期 → 保留（标记 `qualified`）
   - 否则（不在名单 / 状态非 qualified / 已过期）→ **吊销（原因：营销执业资格未确认 / 已失效）**

即"组织关系 + 执业资格"双因子，**任一失效即吊销**；资质失效的吊销与离职吊销走同一 `revoke_license` 链路（客户侧电话回家即时失效）。

### 11.4 绑定 / 审批时的资格快照
- 网页授权 `create_pending_binding`、手动 `bind_license`、审批 `activate_binding` 时均调用 `check_qualification` 写 `qual_status` 快照。
- 即便审批人手动签发了不在名单中的人，下一次轮巡也会因此将其吊销——名单是强制闸。

### 11.5 管理接口（后台"执业资格名单"标签页）
- `GET  /admin/api/wecom/qualifications`：列表（可按 corpid 过滤）
- `POST /admin/api/wecom/qualifications`：单个加入 `{corpid,userid,name,cert_no}`
- `POST /admin/api/wecom/qualifications/import`：批量导入 `rows=[{corpid,userid,name,cert_no,expires_at}]`（每行 `corpid,userid,姓名,执业登记编号`）
- `DELETE /admin/api/wecom/qualifications?corpid=&userid=`：移除（移除后下次轮巡自动吊销其 License）

### 11.6 合规要点
- 名单来源应可追溯：建议由银行合规 / 人力按"授权互联网营销人员"口径提供，导入时记录 `source` 与 `added_by`。
- 名单与"企业微信归属"构成双因子，比单凭企业微信更接近监管对"销售人员实名 + 可回溯"的要求。
- 仍需银行合规 / 法务最终确认"企业微信归属 + 执业登记编号"组合是否满足其监管口径。

---

## 12. 服务商凭据配置与启用

### 12.1 需要哪些凭据（企业微信服务商后台 / 应用管理）
| 变量 | 含义 |
|---|---|
| `WECOM_PROVIDER_CORPID` | 服务商 corpid |
| `WECOM_PROVIDER_SECRET` | 服务商 Secret |
| `WECOM_SUITE_ID` | 第三方应用 suite_id |
| `WECOM_SUITE_SECRET` | 第三方应用 Secret |
| `WECOM_AGENT_ID` | 应用 agentid |
| `WECOM_CALLBACK_TOKEN` | 通讯录事件回调 Token |
| `WECOM_CALLBACK_AESKEY` | 通讯录事件回调 EncodingAESKey |

### 12.2 写入方式（已落地）
- 凭据不进代码 / 镜像，存于 `/opt/license_server/wecom.env`（权限 600）。
- 由 `license-server.service` 与 `license-poll.service` 通过 `EnvironmentFile=` 注入。
- 提供 `configure_wecom.py` 一键写入：
  `python3 /opt/license_server/configure_wecom.py --provider-corpid ... --provider-secret ... --suite-id ... --suite-secret ... --agent-id ... --callback-token ... --callback-aeskey ...`，随后 `systemctl restart license-server license-poll`。
- `WeComConfig.enabled` 在凭据齐全时为 `True`，否则为 `False`（此时轮巡走 mock / 转人工，不会误吊销）。

### 12.3 验证凭据已生效
- `systemctl restart license-server license-poll` 后，`python3 -c "import wecom_verifier as w; print(w.WeComConfig().enabled)"` 应为 `True`。
- 真实回调 / 授权即激活；未配置前系统以 Mock / 转人工安全运行。

### 12.4 安全
- `wecom.env` 权限 600，仅 root 可读；绝不进入版本库（技能包不含真实凭据）。
- 回调 `EncodingAESKey` / `Token` 用于校验企业微信推送签名，缺失则无法解密事件（实时吊销降级为轮巡兜底）。
