# 授权闸门（License Gate）—— 防抄袭商用 + 银行专用强制

## 一、为什么需要它

技能包是明文 Markdown，安装即拥有全文，**无法技术防拷贝**。前文「版权与授权限制」章节靠法律许可约束；本闸门则在**运行时**提供技术强制：

> 没有作者用私钥签发的、绑定域名且未过期的令牌，系统启动即拒绝服务。

它同时实现两个目标：
- **防抄袭商用**：抄走整套代码也跑不起来（缺令牌 / 伪造令牌被验签拒绝）。
- **银行专用**：作者**只向核验过的银行/持牌机构**签发令牌（`scope=bank-only`），非银行人员拿不到可用令牌。

## 二、原理（非对称签名，不可伪造）

```
作者私钥 (PRIVATE_KEY, 仅作者本地)  ──签名──►  license.key (payload.signature)
                                              │
客户系统启动 ──► license_gate.verify_license()
        │        ① 用内嵌【公钥】验签（伪造必败）
        │        ② 校验过期 exp
        │        ③ 校验域名绑定 aud（防挪作他用）
        │        ④ 可选：远程吊销 REVOKE_URL
        ▼
   通过 → 正常服务；任一失败 → 公开接口/看板返回 403，H5 显示未授权横幅
```

- 分发物只含**公钥**（`license_gate.py` 内嵌），只能验签，**不能据此伪造令牌**。
- 私钥（`issue_license.py` 读取的本地文件）**绝不进技能包 / zip**。

## 三、密钥生成（作者首次）

```bash
python3 scripts/issue_license.py gen_keypair
# → 生成 ~/.workbuddy/secrets/license_private_key.pem（权限 600）
# → 终端打印【公钥】，粘贴进 scripts/license_gate.py 的 _AUTHOR_PUBLIC_PEM
```

> 本项目已预置一对演示密钥（公钥已嵌入 `license_gate.py`）。作者应替换为自己的密钥对后再正式签发。

## 四、签发令牌（核验银行身份后）

先人工核验对方为银行/持牌金融机构从业人员（企业邮箱 `@bank` / 工号 / 内部推荐），再签发：

```bash
python3 scripts/issue_license.py issue \
    --email zhangsan@bank.com \
    --org "某银行XX分行" \
    --aud <YOUR_DOMAIN> \
    --days 365 \
    --lic LIC-2026-0001
# 输出即 license.key 内容，发送给客户放到部署目录即可
```

令牌字段：`sub`(邮箱) `org`(机构) `aud`(域名绑定) `iat` `exp` `lic`(编号) `scope=bank-only`。

## 五、客户接入（Flask 后端）

将 `license_gate.py` + `flask_license_guard.py` 放到 `app.py` 同目录，放好 `license.key`：

```python
# app.py
from flask_license_guard import startup_check, require_license, register_status_endpoint

def create_app():
    app = Flask(__name__)
    startup_check(expected_aud="你的域名")        # 不通过 → 抛异常阻止启动
    register_status_endpoint(app, expected_aud="你的域名")

@app.route("/api/public/authorizations", methods=["POST"])
@require_license                                   # 未授权 → 403
def create_auth(): ...
```

H5 页面可 `fetch('/api/license/status')` 显示授权横幅；未授权时引导联系 `913943661@qq.com`。

## 六、吊销（远程作废失窃令牌）

将 `license_gate.py` 的 `REVOKE_URL` 设为作者自建端点（传入 `lic` 编号，返回 `1` 表示吊销）。
作者侧维护吊销清单即可远程让某令牌失效，无需客户更新代码。
`REVOKE_FAIL_CLOSED=True`：作者服务不可达时**拒绝服务**（最严）；设为 `False` 则网络异常时放行（防作者服务宕机拖垮客户）。

## 七、残差风险（务必知悉）

1. **本地验证可被有意的客户绕过**：令牌校验在客户侧 Flask 内，懂技术的客户理论上可删掉 `require_license` 装饰器 / 注释 `startup_check`。这是所有"客户端授权"的共性局限——缓解靠法律许可条款 + 作者持续提供升级支持的价值绑定。
2. **真·不可绕过**需"服务端电话回家"校验（每次请求验令牌），但要求作者托管 7×24 服务，且客户离线即停摆。本项目默认用本地验签（零托管成本），吊销用可选电话回家。

## 八、与分发模式的配合

- 本闸门与「私有邀请制分发」互补：邀请制控制**谁拿到代码**，闸门控制**谁的代码能跑起来**。
- 即使未来改走公开货架，闸门仍是防止滥用的最后一道技术防线。

## 九、作者侧托管服务（签发 / 吊销自动化）

把"人工签发"升级为**在线申请 → 作者审核 → 自动签发 → 远程吊销**的托管服务，让"银行专用"从运营约束变成可规模化的技术强制。

### 组件（作者专用，不在公开分发范围外泄露私钥）

- `scripts/license_server.py` —— Flask 服务（全部配置走环境变量，无硬编码私钥）：
  - 公开 `GET/POST /apply`：银行人员在线填表申请（邮箱/机构/域名/用途），带内存限流 + honeypot 防机器人。
  - 作者后台 `GET /admin`（X-API-Key 保护）+ API `GET /admin/api/requests`、`POST /admin/api/approve/<id>`、`reject`、`revoke/<lic>`。
  - 公开吊销查询 `GET /revoke/<lic_id>`：供客户侧 `license_gate.py` 的 `REVOKE_URL` 电话回家（已吊销→200+`1`；未吊销→404）。
  - 签名函数与 `issue_license.py` 完全一致（同格式、同私钥），保证客户验证器可验过。
- 作者私钥：`LICENSE_PRIV_KEY` 指向的路径（与手动签发共用一把私钥）。

### 部署（作者自有服务器）

```bash
# 1) 放代码 + 私钥
mkdir -p /opt/license_server/keys
cp scripts/license_server.py /opt/license_server/
cp ~/.workbuddy/secrets/license_private_key.pem /opt/license_server/keys/   # 600
# 2) 建库（复用 MySQL，库名 license_srv；init_db() 自建三张表）
export MYSQL_PWD='<mysql_root密码>'
mysql -uroot -e "CREATE DATABASE IF NOT EXISTS license_srv CHARACTER SET utf8mb4;"
# 3) systemd（注入 ADMIN_KEY 与私钥路径；端口 127.0.0.1:8099）
cat > /etc/systemd/system/license-server.service <<'EOF'
[Unit]
Description=License issuance & revocation server
After=network.target mysql.service
[Service]
WorkingDirectory=/opt/license_server
Environment=PYTHONPATH=/opt/license_server
Environment=MYSQL_PWD=<mysql_root密码>
Environment=LICENSE_PRIV_KEY=/opt/license_server/keys/license_private_key.pem
Environment=LICENSE_ADMIN_KEY=<用 openssl rand -hex 24 生成并妥善保管>
ExecStart=/usr/bin/env python3 -m gunicorn -w 2 -b 127.0.0.1:8099 license_server:app
User=root
Restart=always
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload && systemctl enable --now license-server
# 4) nginx 反代（复用既有站点，路径 /license-api/ 剥离前缀转发到 8099）
#    location /license-api/ { proxy_pass http://127.0.0.1:8099/; ... }
# 5) 设置客户验证器 REVOKE_URL=https://<你的域名>/license-api/revoke
```

### 日常运营

1. 银行人员打开 `https://<你的域名>/license-api/apply` 填表。
2. 作者打开 `https://<你的域名>/license-api/admin?key=<ADMIN_KEY>`，点「批准签发」→ 复制 `license.key` 发给客户。
3. 失窃/违规 → 点「吊销」，该部署**立即失效**（客户验证器下次校验即拒）。

### 残差风险（补充）

- 托管服务本身是**高价值攻击面**：`ADMIN_KEY` 泄露=任何人可发牌；私钥泄露=可伪造令牌。务必：ADMIN_KEY 存密码管理器、`LICENSE_PRIV_KEY` 权限 600、服务器仅你控制、定期轮换密钥（轮换需同步更新验证器公钥）。
- 吊销端点是公开 URL，需配合 `REVOKE_FAIL_CLOSED=True`（作者服务宕机=拒绝，最严）；若担心误伤客户，可设为 `False`（网络异常时放行）。
- 与「七、残差风险」第 1 点叠加：客户端仍可绕过本地校验，托管服务只是把"银行专用"的**发放与作废**自动化、可审计，并未消除客户端绕过——后者仍靠法律条款 + 价值绑定约束。

---

## 十、企业微信核验 + 离职自动吊销（银行从业人员自动化准入）

> 完整方案见 `references/wecom-auto-revoke.md`；配套模块 `scripts/wecom_verifier.py`（已集成进 `license_server.py`）。

把"是否银行从业人员"从人工审批升级为**企业微信组织关系自动核验 + 自动吊销**：

### 核心思路
1. 银行员工经企业微信网页授权，系统拿到 `(corpid, userid)`；`corpid` 必须命中**银行白名单**（`wecom_corp_whitelist`，自建企业无法伪造真实 corpid）。
2. 已签发 License 与 `(corpid, userid)` 绑定（`wecom_bindings`）。
3. **离职事件回调** `/wecom/callback`（秒级）或**每日轮巡** `license_server.py poll`（兜底，≤24h）检测到 `status∈{2禁用,5离职}` 或成员不存在(60111) → 自动吊销。
4. **FAIL-OPEN**：任何接口异常/无法识别 → 标记 `error` 转人工，**绝不误杀在职员工**（仅 `LEFT` 才吊销）。

### 接入要点（服务商第三方应用）
- 采用服务商模式，每家银行授权安装后可读其通讯录；配置 `WECOM_PROVIDER_CORPID/SECRET`、`WECOM_SUITE_ID/SECRET`、`WECOM_AGENT_ID`、`WECOM_CALLBACK_TOKEN/AESKEY`。
- 网页授权：`/wecom/oauth/start` → 企业微信 → `/wecom/oauth/callback`（`getuserinfo` 拿身份）。
- 事件回调：`/wecom/callback`（GET 校验回显、POST 解密通讯录事件）。

### 部署验证（已在服务器落地）
- 表：`wecom_corp_whitelist` / `wecom_corp_auth` / `wecom_bindings`（init_db 自建）。
- 服务：`license-server.service`（8099）+ `license-poll.timer`（每日 03:17 轮巡）。
- 轮巡识别 `LEFT` → `license_records.status='revoked'`、吊销表落行 ✅；`ERROR` → 不吊销、转人工 ✅。
- 管理后台 `/admin` 新增"企业微信核验"标签页：白名单增删查、绑定状态、立即轮巡。

### 合规补足：执业资格二次校验（已实现）
corpid 白名单仅证明"在这家银行"，不证明"有营销执业资格"。已在 `wecom_qualifications`（授权营销人员名单）表实现二次校验：轮巡对每个在职绑定再查执业资格，不在名单 / 状态非 qualified / 已过期 → 自动吊销（与离职吊销同链路）。绑定 / 审批时写 `qual_status` 快照。详见 `references/wecom-auto-revoke.md` 第 11 章、设计文档合规映射。

### 服务商凭据配置（已落地）
凭据存于 `/opt/license_server/wecom.env`（600），由 `license-server.service` / `license-poll.service` 经 `EnvironmentFile=` 注入；`configure_wecom.py` 一键写入后 `systemctl restart` 生效。`WeComConfig.enabled` 凭据齐全才为 `True`（详见设计文档第 12 章）。
