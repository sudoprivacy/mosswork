# 运维手册（无 SSH 通道友好）

本手册覆盖日常运维的关键动作：TAT 远程执行、字段加密、备份与恢复、密钥管理、防火墙与应急。

## 1. TAT 通道（SSH 被挡时的首选）

当 SSH（22 / `<SSH_PORT>`）被云防火墙白名单挡住，或 VNC 不便使用时，用腾讯云自动化助手（TAT）远程执行命令。

`scripts/tat_run.py` 封装 `tccli tat RunCommand` + `DescribeInvocationTasks`（异步轮询拿输出）：

```bash
# 在本地（已配置 tccli + 凭证）运行
python3 tat_run.py "systemctl restart <AUTH_API_SERVICE>" 60
```

要点：
- 实例 ID `<INSTANCE_ID>`、地域 `<REGION>` 在脚本顶部替换。
- TAT 是异步的，脚本会轮询 `InvocationTaskSet` 直到完成再返回 stdout。
- **频率限制**：TAT 有调用频率上限，超限返回 `429`，需等重置（通常数分钟）后重试。
- 读文件：`tat_run.py "cat /opt/<APP_DIR>/app.py"`；改配置：传 Python 脚本经 base64 上传后执行（避免 sed 转义问题）。

## 2. 敏感字段加密（crypto_util.py）

双模式工具（见 `scripts/crypto_util.py`）：
- `enc_rand` / `dec_rand`（Fernet，用于 verification_code，不参与统计）
- `enc_det` / `dec_det`（AES-GCM-SIV 固定 nonce，用于需 `GROUP BY` 的统计字段）

迁移步骤：
1. 扩容字段长度（`annual_premium VARCHAR(32)→255` 等，密文更长）。
2. 全量加密现有明文，**先往返校验再写回**，确认明文残留为 0。
3. 应用读取出口统一解密；搜索改为应用层过滤（解密后过滤取 N 条）。

## 3. 备份与恢复

`scripts/backup_db.sh`（替换为实际路径 / 密码）每日 3:30 执行：
- 数据库全库 `mysqldump` → openssl aes-256-cbc -pbkdf2 加密 → `/www/backup/database/`
- 代码文件 + H5 前端整目录 → 加密 → `/www/backup/code/`
- TDE keyring → 加密备份
- 保留 30 天，落盘前校验可解密（失败保留明文告警）

解密：
```bash
openssl enc -d -aes-256-cbc -pbkdf2 -pass file:<KEY_FILE> \
    -in auth_records_<日期>.sql.gz.enc | gunzip > restore.sql
```

恢复包 `recovery_kit_<日期>.tar.gz` 含三把密钥 + 加密备份 + 配置 + 恢复说明；**恢复时必须先就位 keyring**，否则 TDE 表打不开。

## 4. 三把密钥（等同命脉）

| 密钥 | 用途 | 丢失后果 |
|------|------|----------|
| `.backup_key` | 解所有加密备份 | 备份全不可恢复 |
| `.field_key` | 解字段密文 | 字段数据永久解不开 |
| `keyring` | 解 MySQL 表空间 | 表打不开，数据全废 |

务必异地多份保存；恢复包与密钥不要长期同机存放（同机 = 单点风险）。

## 5. 防火墙与 SSH 应急

- 云防火墙（非服务器 iptables）才是 SSH 守门人：SSH 端口仅 ACCEPT 指定 IP/32，面板端口按需开放。
- 加白名单：`tccli lighthouse CreateFirewallRules --region <REGION> --InstanceId <INSTANCE_ID> --FirewallRules [...]`，加完即生效。
- 网页终端（如 OrcaTerm）出口 IP 会漂移，单 IP 加白后可能再变；应急流程：临时放开 0.0.0.0/0 + 服务器 `tail -f /var/log/secure` 抓源 IP 再加白（纯密钥登录，临时放开风险低）。
- 终极应急：云控制台 → VNC 登录（root 密码 `<SERVER_ROOT_PASSWORD>`）→ 临时放行。

## 6. 日常巡检清单

- [ ] `curl <API_BASE_URL>/api/health` 返回 ok
- [ ] 企微推送正常（提交测试授权验证）
- [ ] 看板数据更新（授权数 + 访问数）
- [ ] 备份文件存在且可解密（抽样）
- [ ] 磁盘 / 证书有效期 / 防火墙规则
