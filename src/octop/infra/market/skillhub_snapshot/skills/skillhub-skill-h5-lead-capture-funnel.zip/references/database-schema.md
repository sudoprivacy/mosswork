# 数据库 Schema

数据库 `<DB_NAME>`，建表用 root；应用账号 `<DB_USER>` 仅 DML 权限（SELECT/INSERT/UPDATE/DELETE，无 CREATE），建表与导表须用 root。

## customer_authorizations（授权 / 线索主表）

```sql
CREATE TABLE customer_authorizations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    authorization_code VARCHAR(64) NOT NULL UNIQUE,
    verification_code VARCHAR(255),          -- 应用层加密(R1)
    authorization_scope TEXT NOT NULL,
    validity_period INT DEFAULT 6,
    added_wechat BOOLEAN DEFAULT FALSE,
    selected_bank VARCHAR(32),
    financial_needs TEXT,                     -- 应用层加密(D1)，JSON 数组
    insurance_types TEXT,                     -- 应用层加密(D1)，JSON 数组
    annual_premium VARCHAR(255),              -- 应用层加密(D1)
    status ENUM('active','revoked') DEFAULT 'active',
    authorization_time DATETIME NOT NULL,
    expiry_date DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

## auth_operation_logs（操作日志）

记录授权创建 / 更新 / 推送等操作，含操作类型、记录 ID、时间、来源 IP，便于审计与排查。

```sql
CREATE TABLE auth_operation_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    auth_id INT,
    action VARCHAR(32),
    detail TEXT,
    source_ip VARCHAR(64),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (auth_id),
    INDEX (created_at)
);
```

## visitor_access_logs（访问基础数据，合规留存 180 天）

22 列，覆盖 ICP / 等保要求的访问日志要素：

```sql
CREATE TABLE visitor_access_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    visit_time DATETIME,
    session_id VARCHAR(64),
    auth_code VARCHAR(64),
    client_ip VARCHAR(64),
    x_forwarded_for VARCHAR(255),
    request_method VARCHAR(8),
    request_uri VARCHAR(512),
    referer VARCHAR(1024),
    user_agent VARCHAR(512),
    browser VARCHAR(64),
    os VARCHAR(64),
    device_type VARCHAR(32),
    screen_resolution VARCHAR(32),
    viewport_size VARCHAR(32),
    accept_language VARCHAR(128),
    page_title VARCHAR(256),
    visit_source VARCHAR(64),
    is_new_visitor BOOLEAN,
    duration_seconds INT,
    status_code INT,
    pushed BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (client_ip),
    INDEX (visit_time),
    INDEX (visit_source),
    INDEX (is_new_visitor)
);
```

每日定时清理 `visit_time < DATE_SUB(NOW(), INTERVAL 180 DAY)` 的行，满足留存上限。

## 加密约定

- 敏感字段写入前加密，读取出口统一解密；迁移期保留 `R1:` / `D1:` 前缀以兼容遗留明文。
- 解密失败（密钥缺失 / 数据损坏）时原样返回，避免整页崩溃。
- 三张表建议启用 MySQL TDE（`ENCRYPTION='Y'`），与字段加密构成双层保护。
