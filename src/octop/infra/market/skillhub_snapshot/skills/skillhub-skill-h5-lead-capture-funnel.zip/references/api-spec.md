# API 接口规范

所有接口部署在 `<API_BASE_URL>`（同源部署时 `API_BASE` 为空串，走相对路径）。公开接口无需 API Key 但做 IP 限频；管理接口需请求头 `X-API-Key: <API_KEY>`。

## 公开接口（H5 页面调用，无需 Key，IP 限频）

### POST /api/public/authorizations
提交授权凭证（凭证编号 + 验证码）。
请求体：
```json
{ "authorization_code": "PACT-xxxx", "verification_code": "..." }
```
响应：`{ "status": "ok", "id": 1 }`
副作用：触发企微推送凭证信息。

### PATCH /api/public/authorizations/<auth_code>
更新可选项（银行 / 理财需求 / 保险类型 / 年交保费）。
请求体：
```json
{ "selected_bank": "...", "financial_needs": ["..."], "insurance_types": ["..."], "annual_premium": "...", "notify": true }
```
`notify=true` 时触发整条线索推送。

### POST /api/public/visit
访问埋点上报（页面加载 / 离开）。
请求体：
```json
{ "auth_code": "...", "page_title": "...", "referer": "...", "visit_source": "..." }
```
新访客触发企微访问上下文推送（同 IP 30 分钟冷却）。

## 管理接口（需 X-API-Key）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/authorizations?page=1&page_size=20 | 授权记录列表（分页） |
| GET | /api/authorizations/<id> | 单条记录明细 |
| DELETE | /api/authorizations/<id> | 撤销（软删除，status=revoked） |
| GET | /api/dashboard/stats | 授权统计概览 |
| GET | /api/dashboard/recent | 最近记录 |
| GET | /api/dashboard/search?code=PACT-xxx | 按凭证号搜索 |
| GET | /api/dashboard/visit-stats | 访问基础数据统计（总量/今日/昨日/30天独立/新访客 + 设备/浏览器/来源/热门页/趋势） |
| POST | /api/dashboard/notify/<id> | 手动推送指定记录详情 |
| GET | /api/health | 健康检查，返回 `ok` |

## 加密字段约定

响应中的 `financial_needs` / `insurance_types` / `annual_premium` / `verification_code` 经应用层加密（R1 随机化 / D1 确定性），读取出口统一解密。统计字段用 D1 确定性密文以支持 `GROUP BY`，无需解密即可聚合。

## 安全建议

- 公开接口务必做 IP 限频（如 5 次/分钟），避免被刷。
- H5 是客户端 JS，绝不能内嵌 API Key；敏感操作放服务端。
- 管理接口强制校验 `X-API-Key`，错误返回 401。
