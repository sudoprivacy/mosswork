# 部署指南（同源方案 v10）

本指南描述如何搭建一套端到端可观察的 H5 获客引导系统。所有凭据用占位符，部署时自行替换。

## 前置条件

- 一台 Linux 服务器（推荐 2C2G+），已装 Nginx、MySQL 5.7+、Python 3.8+
- 一个已备案域名 `<H5_BASE_URL>`（建议国内服务器 + ICP 备案，便于合规对外）
- 宝塔 / 类似面板（可选，便于可视化运维）或纯命令行
- 企业微信机器人 Webhook key `<WECOM_WEBHOOK_KEY>`
- SSL 证书（Let's Encrypt 或商业证书）

## 1. 服务器与 API 服务

1. 创建部署目录 `/opt/<APP_DIR>/`，放置 `app.py`（Flask）、`notification.py`、`crypto_util.py`。
2. 用 systemd 管理 Gunicorn：`/etc/systemd/system/<AUTH_API_SERVICE>.service`，监听 `127.0.0.1:5000`，2 workers。
3. Nginx 配置：443 → 127.0.0.1:5000 反向代理；同时托管 H5 静态目录。
4. 启用 TLS 1.2/1.3 only + 5 个安全响应头（HSTS / X-Frame-Options / X-Content-Type-Options / X-XSS-Protection / Referrer-Policy）。
5. 开放 80/443/面板端口；SSH 仅 IP 白名单（云防火墙）。

## 2. 数据库

1. 创建数据库 `<DB_NAME>`，应用账号 `<DB_USER>`（最小权限：SELECT/INSERT/UPDATE/DELETE，无 CREATE）。
2. 建表 `customer_authorizations`、`auth_operation_logs`、`visitor_access_logs`（见 database-schema.md）。
3. `bind-address=127.0.0.1` 仅本地监听；启用 `local_infile=OFF`、`validate_password`。
4. 配置 `require_secure_transport=ON`，应用走 Unix socket 连库（绕过强制加密对本地连接的影响）。

## 3. 部署 H5 静态页（同源核心）

1. 页面放服务器本地 `/www/wwwroot/h5_auth/index.html`。
2. **前端 `API_BASE` 留空串**，所有请求走相对路径 `/api/...`（同源，规避 iOS 跨域）。
3. 二维码用真实 JPG 文件 `/www/wwwroot/h5_auth/qr.jpg`，Nginx 配 `location = /qr.jpg { root /www/wwwroot/h5_auth; }`，HTML 用 `<img src="qr.jpg">` 同源相对路径。
4. 注入访问追踪 JS（UA 解析 + 设备识别 + localStorage 新访客判定 + sendBeacon 上报停留时长）。

## 4. 企业微信推送

1. `notification.py` 读 `<WECOM_WEBHOOK_KEY>`，提供 `send_wecom` / `notify_new_authorization` / `notify_questionnaire_submitted` / `notify_visitor_access`。
2. 推送字段顺序与看板保持一致（访问路径 → 页面标题 → 来源分类 → 来源链接）。
3. 问卷选择静默保存，点击「联系客户经理 / 我已添加」时传 `notify=true` 触发整条线索推送。

## 5. 数据看板

1. `dashboard.html` 放同源静态目录，X-API-Key（`<API_KEY>`）登录。
2. 调用 `GET /api/dashboard/stats|recent|search` 拉取授权统计 + 访问基础数据（设备 / 浏览器 / 来源 / 热门页 / 30 天趋势 / 最近 20 条）。
3. 60 秒自动刷新，筛选状态在刷新后保留。

## 6. 访问埋点

1. 建表 `visitor_access_logs`（22 列，见 database-schema.md）。
2. 端点 `POST /api/public/visit`（同源公开，IP 限频）入库；新访客触发企微推送（同 IP 30 分钟冷却，`pushed` 标记防刷）。
3. `GET /api/dashboard/visit-stats` 返回统计与趋势。

## 7. 验证

- `curl <API_BASE_URL>/api/health` → `ok`
- 浏览器打开 `<H5_BASE_URL>/`，提交一次测试授权，确认：企微收到推送、看板出现记录、`visitor_access_logs` 有对应行。

## 常见坑

- iOS 18+ Safari 拦截跨域请求，同源是唯一稳定方案（CORS / JSONP / 代理等跨域尝试 v1–v9 均失败）。
- 二维码必须真实 JPG 文件，base64 `data:` URI 在 iOS Safari 长按识别无效。
- 宝塔面板终端粘贴 `sed` 命令时转义符会被吃掉，改用 Python 修改配置文件。
- `mysql` 与 `mysqldump` 勿混用，否则会出现空备份假象。

## 8. 授权闸门接入（防抄袭 + 银行专用强制）

> 非必须步骤，但强烈建议：让系统在**无作者签发的令牌时拒绝服务**，实现技术层面的版权保护与银行专用限制。

1. 将本技能 `scripts/` 下的 `license_gate.py`、`flask_license_guard.py` 复制到 `app.py` 同目录；把作者签发的 `license.key` 也放同目录（路径见 `flask_license_guard.LICENSE_PATH`）。
2. `app.py` 顶部引入：`from flask_license_guard import startup_check, require_license, register_status_endpoint`。
3. 在 `create_app()` 内调用 `startup_check(expected_aud="<H5_BASE_URL的域名>")`；校验不通过会抛异常**阻止启动**（也可 `strict=False` 仅记录，由装饰器兜底）。
4. 注册状态端点：`register_status_endpoint(app, expected_aud="...")`，H5 可 `fetch('/api/license/status')` 展示授权横幅。
5. 在需要保护的视图上加 `@require_license`（如 `POST /api/public/authorizations`、看板接口），未授权返回 403。
6. 令牌由作者用 `scripts/issue_license.py` 签发（核验银行身份后），含域名绑定与有效期；失窃可经 `license_gate.REVOKE_URL` 远程吊销。

详细设计、密钥生成与残差风险见 `references/license-gate.md`。

## 9. 作者侧托管服务（签发 / 吊销自动化）

把第 8 节的"手动签发"升级为在线服务，适合要**规模化向多家银行发放令牌**的作者。

1. 拷贝 `scripts/license_server.py` 到作者服务器 `/opt/license_server/`，私钥放 `/opt/license_server/keys/`（权限 600）。
2. 建库：`mysql -uroot -e "CREATE DATABASE IF NOT EXISTS license_srv"`，服务启动时 `init_db()` 自建三张表（申请 / 记录 / 吊销）。
3. 起 systemd（端口 `127.0.0.1:8099`，注入 `LICENSE_ADMIN_KEY` 与 `LICENSE_PRIV_KEY`、MySQL 密码），nginx 以 `location /license-api/ { proxy_pass http://127.0.0.1:8099/; }` 反代。
4. 客户侧 `license_gate.py` 设 `REVOKE_URL = "https://<你的域名>/license-api/revoke"`，实现失窃令牌远程即时作废。
5. 运营：银行打开 `/license-api/apply` 申请 → 作者 `/license-api/admin?key=<ADMIN_KEY>` 审核签发 / 吊销。

> 此服务持有私钥与 ADMIN_KEY，是**高价值攻击面**：ADMIN_KEY 存密码管理器、私钥权限 600、服务器仅作者控制、定期轮换密钥（轮换需同步更新验证器内嵌公钥）。完整部署与残差风险见 `references/license-gate.md` 第九章。
