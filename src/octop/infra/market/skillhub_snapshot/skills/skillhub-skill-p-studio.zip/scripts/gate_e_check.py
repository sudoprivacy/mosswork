# -*- coding: utf-8 -*-
"""GATE-E 三维度读者价值门禁 · 自动检查器（配合 SKILL.md 第 9.5 / 12 步强制执行）。

用法：
    python scripts/gate_e_check.py <正文.md> [--json]

设计要点（踩过的坑，别改回去）：
  - 🔴 只扫**正文区块**（## 一/二/三 标题到下一 ## 之间），不扫本文档/门禁说明区。
    否则规则自己写的示例词（"不用点个关注"）会被自己判违规 → 使用者白白返工。
  - 金句判定排除目录性粗体（准出/主用/备选/第一步能带走什么 等），只数真金句。
  - 迁移句按"这一步能带走什么"计数，正文版可退化为"换个领域也成立"。
退出码：0 = 全过；1 = 有硬门禁不过（必须返工）。
"""
import json
import re
import sys

BANNED = ["点个关注", "转发点赞", "记得收藏", "求关注", "点个赞", "关注我",
          "点赞支持", "转发给", "求个赞"]
BANNED_CTX = ["不用", "禁止", "零索取", "不许", "不出现", "不是要你"]
METALINE = ("准出", "主用", "备选", "这一步能带走什么", "换个领域也成立",
            "病因", "红线", "强制", "验收")


def body_only(text):
    """只保留三平台正文区块：## 一/二/三 标题起，到 ## 四（标题与钩子）之前的正文。

    🔴 为什么必须限定作用域（踩过两次的坑）：
      ① 门禁说明文档里写着自己禁止的词（"不用点个关注"）；
      ② 修正说明/自检表里记录着"我删掉了 XXX"（如"删掉这一步能带走什么字样"）。
      两者都会让全文件扫描产生误报 → 使用者白白返工。
      规则只能扫"读者真正会读到的正文"，说明区不属于正文。
    """
    m = re.search(r"^##\s*一、", text, re.M)
    if not m:
        return text
    body = text[m.start():]
    cut = re.search(r"^##\s*四、", body, re.M)
    if cut:
        body = body[:cut.start()]
    return body


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    path = sys.argv[1]
    raw = open(path, encoding="utf-8").read()
    body = body_only(raw)
    fails, warns = [], []

    # ① 索取式钩（只扫正文）
    hits = []
    for ln_no, ln in enumerate(body.splitlines(), 1):
        for b in BANNED:
            if b in ln and not any(c in ln for c in BANNED_CTX):
                hits.append((b, ln.strip()[:50]))
    if hits:
        fails.append("索取式钩命中：%s" % hits)

    # ② 金句 >=3（排除目录性粗体）
    qs = [q for q in dict.fromkeys(re.findall(r"\*\*([^*\n]{8,60})\*\*", body))
          if not any(q.startswith(x) or x in q for x in METALINE)]
    if len(qs) < 3:
        fails.append("金句仅 %d 条（需>=3）" % len(qs))

    # ③ 迁移句 >=3（方法论维度地基）
    # 🔴 认排版特征，不认固定词：v3 起正文刻意不用"这一步能带走什么"这类标签词
    #（老李要求"不要刻意，通过排版我们就可以实现"），迁移句改由独立引用块承载。
    # 若此处只认固定词，门禁会反过来逼人写标签词 = 门禁伤害内容，必须避免。
    mig = body.count("这一步能带走什么") + body.count("换个领域也成立")
    quote_blocks = len(re.findall(r"^>\s+\*\*", body, re.M))          # > ** 加粗金句块
    mig += quote_blocks
    if mig < 3:
        fails.append("迁移句仅 %d 处（需>=3，识别固定词+引用块排版）" % mig)

    # ④ 连载口吻（出现"我在做/下一步/还想"类未完成感信号）
    serial = any(k in body for k in ("下一步", "还在", "继续", "后面"))
    if not serial:
        warns.append("未检出连载/未完成感信号（维度三可能弱）")

    # ⑤ 三维度落点表存在（文档级检查）
    if "维度" not in raw:
        warns.append("未见三维度落点自检表")

    out = {"ok": not fails, "path": path,
           "quotes": len(qs), "migration_sentences": mig,
           "serial_signal": serial, "failures": fails, "warnings": warns}
    if "--json" in sys.argv:
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        print("GATE-E 读者价值门禁检查：%s" % path)
        print("  金句 %d 条 |迁移句 %d 处 | 连载信号 %s"
              % (len(qs), mig, "有" if serial else "无"))
        for f in fails:
            print("  [不过] %s" % f)
        for w in warns:
            print("  [提醒] %s" % w)
        print("  => %s" % ("PASS" if not fails else "FAIL 需返工"))
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())