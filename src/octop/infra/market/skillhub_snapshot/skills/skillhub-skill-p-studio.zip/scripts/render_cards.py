#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
render_cards.py — 图文卡片批量出图（干货配图 / 内页卡片）

把卡片定义 JSON 渲染为图文卡片（默认 3:4），并截图为 PNG。
截图通道自动回退：
  1) Playwright（pip install playwright && playwright install chromium）
  2) 系统自带 Edge / Chrome 的 headless 截图（Windows/macOS 通常免安装）
  3) 都不可用：保留 HTML，浏览器打开后手动截图

用法：
  python render_cards.py cards.json --outdir out
  python render_cards.py --init        # 生成示例 cards.json
"""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

CSS = """
*{box-sizing:border-box;margin:0;padding:0;}
body{display:flex;justify-content:center;font-family:'PingFang SC','Microsoft YaHei',sans-serif;}
.card{width:__W__px;height:__H__px;background:__PAPER__;border-radius:36px;padding:90px 80px;position:relative;overflow:hidden;display:flex;flex-direction:column;}
.card-inner{flex:1;display:flex;flex-direction:column;justify-content:center;}
.topbar{display:flex;align-items:center;gap:14px;margin-bottom:50px;}
.tag{background:__ACCENT__;color:#fff;font-size:26px;font-weight:700;padding:10px 22px;border-radius:999px;}
.kicker{font-size:26px;color:__SUB__;letter-spacing:3px;}
h1{font-size:88px;line-height:1.2;color:__INK__;font-weight:800;margin-bottom:30px;letter-spacing:-1px;}
.lead{font-size:30px;color:__SUB__;line-height:1.6;margin-bottom:50px;}
.items{display:flex;flex-direction:column;gap:44px;}
.item{display:flex;gap:32px;align-items:flex-start;}
.num{font-size:64px;font-weight:800;color:__ACCENT__;line-height:1;width:80px;flex:none;}
.item h2{font-size:40px;color:__INK__;margin-bottom:14px;font-weight:800;line-height:1.3;}
.item p{font-size:28px;color:__SUB__;line-height:1.6;}
.footer{display:flex;justify-content:space-between;align-items:center;margin-top:50px;font-size:26px;color:__SUB__;}
.brand{font-weight:700;color:__INK__;}
.page{background:__INK__;color:#fff;padding:8px 20px;border-radius:999px;font-size:24px;}
.cmp-bad{background:#fff;border:1px solid #e6e1d8;border-radius:24px;padding:40px 42px;}
.cmp-good{background:__ACCENT__;color:#fff;border-radius:24px;padding:40px 42px;}
.cmp-bad h3{font-size:32px;font-weight:800;color:#9a9aa0;margin-bottom:18px;}
.cmp-good h3{font-size:32px;font-weight:800;margin-bottom:18px;}
.cmp-bad p{font-size:28px;color:__SUB__;line-height:1.6;}
.cmp-good p{font-size:28px;color:#fbeee0;line-height:1.6;}
.quote-wrap{display:flex;align-items:center;justify-content:center;text-align:center;}
.quote{font-size:68px;font-weight:800;color:__INK__;line-height:1.4;letter-spacing:-1px;}
.quote em{color:__ACCENT__;font-style:normal;}
.essence-items{display:flex;flex-direction:column;gap:28px;}
.essence-item{display:flex;gap:28px;align-items:flex-start;}
.essence-icon{font-size:64px;line-height:1;width:80px;flex:none;text-align:center;}
.essence-text{font-size:32px;color:__INK__;line-height:1.5;font-weight:600;}
.essence-text b{color:__ACCENT__;font-weight:800;}
.essence-summary{margin-top:32px;text-align:center;background:__INK__;color:#fff;border-radius:20px;padding:28px 30px;font-size:36px;font-weight:800;letter-spacing:1px;}
.essence-summary em{color:__ACCENT__;font-style:normal;}
"""


def esc(s):
    return (str(s if s is not None else "")
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def br(s):
    return esc(s).replace("\n", "<br>")


def topbar_html(c):
    if c.get("tag") or c.get("kicker"):
        return ('<div class="topbar">{}{}</div>').format(
            '<span class="tag">{}</span>'.format(esc(c["tag"])) if c.get("tag") else "",
            '<span class="kicker">{}</span>'.format(esc(c["kicker"])) if c.get("kicker") else "",
        )
    return ""


def footer_html(c):
    return ('<div class="footer"><span class="brand">{brand}</span>'
            '<span class="page">{page}</span></div>').format(
        brand=esc(c.get("brand", "")), page=esc(c.get("page", "")))


def body_list(c):
    items = ""
    for i, it in enumerate(c.get("items", []), 1):
        items += (
            '<div class="item"><div class="num">{:02d}</div>'
            '<div><h2>{}</h2><p>{}</p></div></div>'
        ).format(i, esc(it.get("h", "")), esc(it.get("p", "")))
    lead = '<p class="lead">{}</p>'.format(esc(c["lead"])) if c.get("lead") else ""
    return topbar_html(c) + '<h1>{}</h1>'.format(br(c.get("title", ""))) + lead + \
        '<div class="items">{}</div>'.format(items)


def body_compare(c):
    body = (
        '<div class="items">'
        '<div class="cmp-bad"><h3>{}</h3><p>{}</p></div>'
        '<div class="cmp-good"><h3>{}</h3><p>{}</p></div>'
        '</div>'
    ).format(esc(c.get("bad_title", "❌ 别这样")), br(c.get("bad", "")),
             esc(c.get("good_title", "✅ 这样做")), br(c.get("good", "")))
    return topbar_html(c) + '<h1>{}</h1>'.format(br(c.get("title", ""))) + body


def body_quote(c):
    txt = br(c.get("title", ""))
    if c.get("accent_text"):
        txt += '<br><em>{}</em>'.format(br(c["accent_text"]))
    return topbar_html(c) + '<div class="quote-wrap"><div class="quote">{}</div></div>'.format(txt)


def body_essence(c):
    rows = ""
    for it in c.get("items", []):
        rows += (
            '<div class="essence-item"><div class="essence-icon">{}</div>'
            '<div class="essence-text">{}</div></div>'
        ).format(esc(it.get("icon", "")), br(it.get("text", "")))
    summary = ""
    if c.get("summary"):
        summary = '<div class="essence-summary">{}</div>'.format(br(c["summary"]))
    return topbar_html(c) + '<h1>{}</h1>'.format(br(c.get("title", ""))) + \
        '<div class="essence-items">{}</div>'.format(rows) + summary


def render(card, width, height):
    accent = card.get("accent", "#c8342b")
    css = (CSS.replace("__W__", str(width)).replace("__H__", str(height))
           .replace("__ACCENT__", accent)
           .replace("__INK__", card.get("ink", "#1d1d1f"))
           .replace("__SUB__", card.get("sub", "#6b6b70"))
           .replace("__PAPER__", card.get("paper", "#f7f5f0")))
    layout = card.get("layout", "list")
    fn = {"list": body_list, "compare": body_compare, "quote": body_quote,
          "essence": body_essence}.get(layout, body_list)
    inner = fn(card)
    body = '<div class="card-inner">{}</div>{}'.format(inner, footer_html(card))
    return ("<!DOCTYPE html><html><head><meta charset='utf-8'>"
            "<style>{}</style></head><body><div class='card'>{}</div></body></html>"
            ).format(css, body)


def shot_playwright(html_path, out_path, w, h):
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return False
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": w, "height": h})
        page.goto(html_path.as_uri())
        page.screenshot(path=str(out_path))
        browser.close()
    return True


def find_native_browser():
    candidates = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    for name in ("microsoft-edge", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
        p = shutil.which(name)
        if p:
            return p
    return None


def shot_native(html_path, out_path, w, h):
    exe = find_native_browser()
    if not exe:
        return False
    cmd = [exe, "--headless=new", "--disable-gpu", "--hide-scrollbars",
           "--window-size={},{}".format(w, h),
           "--screenshot={}".format(str(out_path)), html_path.as_uri()]
    subprocess.run(cmd, capture_output=True, text=True)
    return out_path.exists()


SAMPLE = {
    "width": 1080, "height": 1440, "accent": "#c8342b",
    "cards": [
        {"layout": "list", "tag": "避坑指南", "kicker": "昆明 · 咖啡探店",
         "title": "选咖啡馆\n看这 3 点就够了", "lead": "照着挑，基本不踩雷。",
         "items": [
             {"h": "看豆子", "p": "有没有自家烘焙或 SOE，风味更有保障。"},
             {"h": "看窗边", "p": "昆明的阳光是最好的滤镜，有窗光就出片。"},
             {"h": "看人流", "p": "本地人常去、复购高的店一般不会错。"}],
         "brand": "昆明慢生活指南", "page": "02 / 06"},
        {"layout": "quote", "kicker": "昆明 · 咖啡探店",
         "title": "好咖啡不必排队，", "accent_text": "昆明的慢，藏在窗边那束光里。",
         "brand": "昆明慢生活指南", "page": "06 / 06"},
    ],
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("jsonfile", nargs="?")
    ap.add_argument("--outdir", default="cards_out")
    ap.add_argument("--init", action="store_true")
    args = ap.parse_args()

    if args.init:
        Path("cards.example.json").write_text(
            json.dumps(SAMPLE, ensure_ascii=False, indent=2), encoding="utf-8")
        print("已生成示例 cards.example.json")
        return

    if not args.jsonfile:
        ap.print_help()
        sys.exit(1)

    data = json.loads(Path(args.jsonfile).read_text(encoding="utf-8"))
    w = int(data.get("width", 1080))
    h = int(data.get("height", 1440))
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    made = []
    for i, card in enumerate(data.get("cards", []), 1):
        card.setdefault("accent", data.get("accent", "#c8342b"))
        html = render(card, w, h)
        html_path = outdir / "card_{:02d}.html".format(i)
        html_path.write_text(html, encoding="utf-8")
        out_png = outdir / "card_{:02d}.png".format(i)
        ok = shot_playwright(html_path, out_png, w, h) or shot_native(html_path, out_png, w, h)
        if ok:
            made.append(str(out_png))
            print("[PNG] {}".format(out_png))
        else:
            print("[HTML] 未找到可用截图通道，请手动打开 {}".format(html_path))

    print("完成，共出图 {} 张，目录：{}".format(len(made), outdir))


if __name__ == "__main__":
    main()
