# -*- coding: utf-8 -*-
"""上架打包 · 生成干净的 skill 包（Pack Clean Skill）。

为什么必须存在（2026-10-14）：
  老李定：**skill 上架不能带图片**。但"上架"这件事过去**没有打包脚本**——
  靠手工挑文件、靠记性排除，必然出错（实测 skill 里曾混着 10 张图共 11MB、
  7 个 __pycache__ 编译缓存、.bak 备份文件）。
  **只写在文档里的"别带图片"，等于没有约束。** 本脚本把它变成可执行的一条命令。

2026-10-14 升级（按 WorkBuddy 开放平台上架规范）：
  - 强制校验 SKILL.md frontmatter 必填字段（name/description/description_zh/
    description_en/version/author）。
  - 二进制文件禁令（平台审核红线）：图片/编译产物/模型权重/可执行文件一律不得进包。
  - 体积红线：打包后 zip 不得超过 10MB。

用法：
    python scripts/pack_skill.py [--out ../poster-studio-skill.zip] [--check-only]

    --check-only  只检查、不打包（rc=1 = 包里有不该带的东西 / 字段缺失 / 超限）
"""
import argparse
import os
import re
import sys
import zipfile

IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".svg")
# 平台禁止进包的二进制（审核红线）：编译产物 / 模型权重 / 可执行 / 压缩包
BINARY_EXT = (".pyc", ".pyo", ".exe", ".dll", ".so", ".dylib", ".onnx",
              ".bin", ".pt", ".pth", ".ckpt", ".model", ".db", ".sqlite",
              ".zip", ".gz", ".tar", ".7z", ".whl", ".egg")
EXCLUDE_DIRS = ("__pycache__", "_cloud")
EXCLUDE_SUFFIX = (".bak",)
EXCLUDE_PATTERNS = ("_backup", ".bak-", "~", ".DS_Store")

# 开放平台 frontmatter 必填字段（name 虽官方标可选，但作为 slug 强制要求）
REQUIRED_FM = ("name", "description", "description_zh", "description_en",
               "version", "author")
MAX_ZIP_MB = 10.0


def is_excluded(rel):
    parts = rel.replace("\\", "/").split("/")
    if any(p in EXCLUDE_DIRS for p in parts[:-1]) or parts[-1] in EXCLUDE_DIRS:
        return True
    name = parts[-1].lower()
    if name.endswith(IMG_EXT) or name.endswith(BINARY_EXT) or name.endswith(EXCLUDE_SUFFIX):
        return True
    if any(pat in name for pat in EXCLUDE_PATTERNS):
        return True
    return False


def parse_frontmatter(root):
    """极简 YAML frontmatter 解析：取 --- 之间 key: value。返回 (dict, error)。"""
    path = os.path.join(root, "SKILL.md")
    if not os.path.isfile(path):
        return {}, "SKILL.md 不存在"
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    if not text.startswith("---"):
        return {}, "SKILL.md 缺少 frontmatter（首行非 ---）"
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.S)
    if not m:
        return {}, "frontmatter 未正确闭合（找不到第二个 ---）"
    block = m.group(1)
    fm = {}
    for line in block.split("\n"):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        fm[k.strip()] = v.strip().strip('"').strip("'")
    return fm, None


def check_flat_dirs(include):
    """平台硬性规则：所有目录仅允两级（根目录 / 二级目录 / 文件）。

    依据（2026-10-14 实测，教训）：平台对 zip 内【所有目录】执行两级校验，
    不只是 references/templates。scripts/qrcode/{compat,image/styles/moduledrawers}
    即使全是纯代码，也因最深 7 级嵌套被平台以「目录层级超限」拒收。
    正确结构：root/<二级目录>/<文件>，即路径按 / 切分后 parts 数 ≤ 3。
    返回 (ok, errors)。
    """
    errors = []
    for rel in include:
        parts = rel.replace("\\", "/").split("/")
        # parts[0]=根目录；合法最大深度 = 根 + 1 个二级目录 + 文件 = 3 段
        if len(parts) > 3:
            errors.append("目录层级超限（平台仅允两级 root/二级目录/文件）：%s" % rel)
    return (len(errors) == 0), errors


def check_frontmatter(root):
    fm, err = parse_frontmatter(root)
    if err:
        return False, [err]
    missing = [k for k in REQUIRED_FM if not fm.get(k)]
    if missing:
        return False, ["frontmatter 缺失必填字段：" + ", ".join(missing)]
    # 软提醒：category 推荐但非强制
    warns = []
    if not fm.get("category"):
        warns.append("提示：frontmatter 未设 category（推荐填写，影响市场分类）")
    if not fm.get("display_name"):
        warns.append("提示：frontmatter 未设 display_name（推荐填写，影响展示名）")
    return True, warns


def main():
    ap = argparse.ArgumentParser(description="上架打包（生成干净 skill 包）")
    ap.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    help="skill 根目录（默认脚本上一级）")
    ap.add_argument("--out", default="")
    ap.add_argument("--check-only", action="store_true")
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    if not os.path.isdir(root):
        print("根目录不存在：%s" % root)
        return 1

    # ---- 1. frontmatter 校验（硬性） ----
    fm_ok, fm_msgs = check_frontmatter(root)
    print("① frontmatter 校验：")
    if fm_ok:
        print("   ✓ 必填字段齐全（%s）" % ", ".join(REQUIRED_FM))
    else:
        print("   ✗ 失败：")
        for m in fm_msgs:
            print("     - " + m)
        return 1
    for w in fm_msgs:  # 软提醒
        print("   " + w)

    # ---- 2. 收集文件，排除不该带的 ----
    include, excluded = [], []
    for dp, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and d != "__pycache__"]
        for n in names:
            full = os.path.join(dp, n)
            rel = os.path.relpath(full, root)
            (excluded if is_excluded(rel) else include).append(rel)

    print("② 文件收集：打包 %d 个 / 排除 %d 个（不该上架）" % (len(include), len(excluded)))
    if excluded:
        for e in sorted(excluded)[:25]:
            print("     排除: %s" % e)
        if len(excluded) > 25:
            print("     … 其余 %d 个" % (len(excluded) - 25))

    # ---- 3. 目录层级校验（平台硬性：所有目录仅允两级 root/二级目录/文件）----
    depth_ok, depth_errs = check_flat_dirs(include)
    print("③ 目录层级校验（所有目录仅允两级 root/二级目录/文件）：")
    if depth_ok:
        print("   ✓ 全部路径 ≤ 两级目录（parts ≤ 3）")
    else:
        print("   ✗ 存在超两级目录（平台会拒收）：")
        for e in depth_errs:
            print("     - " + e)
        return 1

    # ---- 4. 硬性兜底：包内不得残留图片/二进制（即便上面逻辑漏了） ----
    bad = [r for r in include if r.lower().endswith(IMG_EXT + BINARY_EXT)]
    if bad:
        print("④ ✗ 包内仍残留图片/二进制：%s" % bad[:5])
        return 1
    print("④ ✓ 包内无图片、无二进制文件")

    # ---- 5. 预览体积（先算未压缩，再算压缩后） ----
    raw_bytes = sum(os.path.getsize(os.path.join(root, r)) for r in include)
    print("⑤ 未压缩体积：%.0f KB" % (raw_bytes / 1024))

    if args.check_only:
        # check-only 仍输出压缩体积估算需要真打包，这里只做结构校验
        print("判定：✅ 上架包结构干净（--check-only，未生成 zip）。"
              "请去掉 --check-only 正式打包以验证 10MB 限制。")
        return 0

    # ---- 6. 正式打包 + 10MB 红线 ----
    out = args.out or os.path.join(os.path.dirname(root), os.path.basename(root) + "-skill.zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        base = os.path.basename(root)
        for rel in include:
            z.write(os.path.join(root, rel), os.path.join(base, rel))
    size = os.path.getsize(out)
    size_mb = size / 1024.0 / 1024.0
    print("⑥ 已打包：%s" % out)
    print("   体积：%.2f MB（%.0f KB，%d 文件）" % (size_mb, size / 1024, len(include)))
    if size_mb > MAX_ZIP_MB:
        print("✗ 超过平台 10MB 红线，请删减重资源后重试！")
        return 1
    print("判定：✅ 上架包合规（结构干净 + 层级合规 + 无二进制 + ≤ 10MB）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
