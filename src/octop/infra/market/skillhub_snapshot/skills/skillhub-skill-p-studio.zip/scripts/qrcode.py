from __future__ import annotations
import types as _types


class _LazyNS:
    """惰性命名空间：属性访问时回到合并模块的全局名上，子命名空间用 _subs 嵌套。"""

    def __init__(self, **subs):
        self.__dict__["_subs"] = subs

    def __getattr__(self, name):
        subs = self.__dict__.get("_subs", {})
        if name in subs:
            return subs[name]
        return globals()[name]

    def __setattr__(self, name, val):
        if name == "_subs":
            self.__dict__["_subs"] = val
        else:
            globals()[name] = val


# 原包内模块前缀 -> 惰性命名空间（保留 base.rs_blocks / constants.X 等原写法）
constants = _LazyNS()
exceptions = _LazyNS()
LUT = _LazyNS()
base = _LazyNS()
util = _LazyNS()
svg_drawers = _LazyNS()
_image_base = _LazyNS()
_image = _LazyNS(image=_image_base)
qrcode = _LazyNS(image=_image)
# === merged from qrcode/constants.py ===
ERROR_CORRECT_L = 1
ERROR_CORRECT_M = 0
ERROR_CORRECT_Q = 3
ERROR_CORRECT_H = 2

# === merged from qrcode/exceptions.py ===
class DataOverflowError(Exception):
    pass

# === merged from qrcode/LUT.py ===
rsPoly_LUT = {7: [1, 127, 122, 154, 164, 11, 68, 117], 10: [1, 216, 194, 159, 111, 199, 94, 95, 113, 157, 193], 13: [1, 137, 73, 227, 17, 177, 17, 52, 13, 46, 43, 83, 132, 120], 15: [1, 29, 196, 111, 163, 112, 74, 10, 105, 105, 139, 132, 151, 32, 134, 26], 16: [1, 59, 13, 104, 189, 68, 209, 30, 8, 163, 65, 41, 229, 98, 50, 36, 59], 17: [1, 119, 66, 83, 120, 119, 22, 197, 83, 249, 41, 143, 134, 85, 53, 125, 99, 79], 18: [1, 239, 251, 183, 113, 149, 175, 199, 215, 240, 220, 73, 82, 173, 75, 32, 67, 217, 146], 20: [1, 152, 185, 240, 5, 111, 99, 6, 220, 112, 150, 69, 36, 187, 22, 228, 198, 121, 121, 165, 174], 22: [1, 89, 179, 131, 176, 182, 244, 19, 189, 69, 40, 28, 137, 29, 123, 67, 253, 86, 218, 230, 26, 145, 245], 24: [1, 122, 118, 169, 70, 178, 237, 216, 102, 115, 150, 229, 73, 130, 72, 61, 43, 206, 1, 237, 247, 127, 217, 144, 117], 26: [1, 246, 51, 183, 4, 136, 98, 199, 152, 77, 56, 206, 24, 145, 40, 209, 117, 233, 42, 135, 68, 70, 144, 146, 77, 43, 94], 28: [1, 252, 9, 28, 13, 18, 251, 208, 150, 103, 174, 100, 41, 167, 12, 247, 56, 117, 119, 233, 127, 181, 100, 121, 147, 176, 74, 58, 197], 30: [1, 212, 246, 77, 73, 195, 192, 75, 98, 5, 70, 103, 177, 22, 217, 138, 51, 181, 246, 72, 25, 18, 46, 228, 74, 216, 195, 11, 106, 130, 150]}

# === merged from qrcode/compat/etree.py ===
try:
    import lxml.etree as ET
except ImportError:
    import xml.etree.ElementTree as ET

# === merged from qrcode/compat/png.py ===
PngWriter = None
try:
    from png import Writer as PngWriter
except ImportError:
    pass

# === merged from qrcode/image/styles/moduledrawers/base.py ===
import abc
from typing import TYPE_CHECKING

class QRModuleDrawer(abc.ABC):
    """
    QRModuleDrawer exists to draw the modules of the QR Code onto images.

    For this, technically all that is necessary is a ``drawrect(self, box,
    is_active)`` function which takes in the box in which it is to draw,
    whether or not the box is "active" (a module exists there). If
    ``needs_neighbors`` is set to True, then the method should also accept a
    ``neighbors`` kwarg (the neighboring pixels).

    It is frequently necessary to also implement an "initialize" function to
    set up values that only the containing Image class knows about.

    For examples of what these look like, see doc/module_drawers.png
    """
    needs_neighbors = False

    def __init__(self, **kwargs):
        pass

    def initialize(self, img: 'BaseImage') -> None:
        self.img = img

    @abc.abstractmethod
    def drawrect(self, box, is_active) -> None:
        ...

# === merged from qrcode/base.py ===
from typing import NamedTuple
EXP_TABLE = list(range(256))
LOG_TABLE = list(range(256))
for i in range(8):
    EXP_TABLE[i] = 1 << i
for i in range(8, 256):
    EXP_TABLE[i] = EXP_TABLE[i - 4] ^ EXP_TABLE[i - 5] ^ EXP_TABLE[i - 6] ^ EXP_TABLE[i - 8]
for i in range(255):
    LOG_TABLE[EXP_TABLE[i]] = i
RS_BLOCK_OFFSET = {constants.ERROR_CORRECT_L: 0, constants.ERROR_CORRECT_M: 1, constants.ERROR_CORRECT_Q: 2, constants.ERROR_CORRECT_H: 3}
RS_BLOCK_TABLE = ((1, 26, 19), (1, 26, 16), (1, 26, 13), (1, 26, 9), (1, 44, 34), (1, 44, 28), (1, 44, 22), (1, 44, 16), (1, 70, 55), (1, 70, 44), (2, 35, 17), (2, 35, 13), (1, 100, 80), (2, 50, 32), (2, 50, 24), (4, 25, 9), (1, 134, 108), (2, 67, 43), (2, 33, 15, 2, 34, 16), (2, 33, 11, 2, 34, 12), (2, 86, 68), (4, 43, 27), (4, 43, 19), (4, 43, 15), (2, 98, 78), (4, 49, 31), (2, 32, 14, 4, 33, 15), (4, 39, 13, 1, 40, 14), (2, 121, 97), (2, 60, 38, 2, 61, 39), (4, 40, 18, 2, 41, 19), (4, 40, 14, 2, 41, 15), (2, 146, 116), (3, 58, 36, 2, 59, 37), (4, 36, 16, 4, 37, 17), (4, 36, 12, 4, 37, 13), (2, 86, 68, 2, 87, 69), (4, 69, 43, 1, 70, 44), (6, 43, 19, 2, 44, 20), (6, 43, 15, 2, 44, 16), (4, 101, 81), (1, 80, 50, 4, 81, 51), (4, 50, 22, 4, 51, 23), (3, 36, 12, 8, 37, 13), (2, 116, 92, 2, 117, 93), (6, 58, 36, 2, 59, 37), (4, 46, 20, 6, 47, 21), (7, 42, 14, 4, 43, 15), (4, 133, 107), (8, 59, 37, 1, 60, 38), (8, 44, 20, 4, 45, 21), (12, 33, 11, 4, 34, 12), (3, 145, 115, 1, 146, 116), (4, 64, 40, 5, 65, 41), (11, 36, 16, 5, 37, 17), (11, 36, 12, 5, 37, 13), (5, 109, 87, 1, 110, 88), (5, 65, 41, 5, 66, 42), (5, 54, 24, 7, 55, 25), (11, 36, 12, 7, 37, 13), (5, 122, 98, 1, 123, 99), (7, 73, 45, 3, 74, 46), (15, 43, 19, 2, 44, 20), (3, 45, 15, 13, 46, 16), (1, 135, 107, 5, 136, 108), (10, 74, 46, 1, 75, 47), (1, 50, 22, 15, 51, 23), (2, 42, 14, 17, 43, 15), (5, 150, 120, 1, 151, 121), (9, 69, 43, 4, 70, 44), (17, 50, 22, 1, 51, 23), (2, 42, 14, 19, 43, 15), (3, 141, 113, 4, 142, 114), (3, 70, 44, 11, 71, 45), (17, 47, 21, 4, 48, 22), (9, 39, 13, 16, 40, 14), (3, 135, 107, 5, 136, 108), (3, 67, 41, 13, 68, 42), (15, 54, 24, 5, 55, 25), (15, 43, 15, 10, 44, 16), (4, 144, 116, 4, 145, 117), (17, 68, 42), (17, 50, 22, 6, 51, 23), (19, 46, 16, 6, 47, 17), (2, 139, 111, 7, 140, 112), (17, 74, 46), (7, 54, 24, 16, 55, 25), (34, 37, 13), (4, 151, 121, 5, 152, 122), (4, 75, 47, 14, 76, 48), (11, 54, 24, 14, 55, 25), (16, 45, 15, 14, 46, 16), (6, 147, 117, 4, 148, 118), (6, 73, 45, 14, 74, 46), (11, 54, 24, 16, 55, 25), (30, 46, 16, 2, 47, 17), (8, 132, 106, 4, 133, 107), (8, 75, 47, 13, 76, 48), (7, 54, 24, 22, 55, 25), (22, 45, 15, 13, 46, 16), (10, 142, 114, 2, 143, 115), (19, 74, 46, 4, 75, 47), (28, 50, 22, 6, 51, 23), (33, 46, 16, 4, 47, 17), (8, 152, 122, 4, 153, 123), (22, 73, 45, 3, 74, 46), (8, 53, 23, 26, 54, 24), (12, 45, 15, 28, 46, 16), (3, 147, 117, 10, 148, 118), (3, 73, 45, 23, 74, 46), (4, 54, 24, 31, 55, 25), (11, 45, 15, 31, 46, 16), (7, 146, 116, 7, 147, 117), (21, 73, 45, 7, 74, 46), (1, 53, 23, 37, 54, 24), (19, 45, 15, 26, 46, 16), (5, 145, 115, 10, 146, 116), (19, 75, 47, 10, 76, 48), (15, 54, 24, 25, 55, 25), (23, 45, 15, 25, 46, 16), (13, 145, 115, 3, 146, 116), (2, 74, 46, 29, 75, 47), (42, 54, 24, 1, 55, 25), (23, 45, 15, 28, 46, 16), (17, 145, 115), (10, 74, 46, 23, 75, 47), (10, 54, 24, 35, 55, 25), (19, 45, 15, 35, 46, 16), (17, 145, 115, 1, 146, 116), (14, 74, 46, 21, 75, 47), (29, 54, 24, 19, 55, 25), (11, 45, 15, 46, 46, 16), (13, 145, 115, 6, 146, 116), (14, 74, 46, 23, 75, 47), (44, 54, 24, 7, 55, 25), (59, 46, 16, 1, 47, 17), (12, 151, 121, 7, 152, 122), (12, 75, 47, 26, 76, 48), (39, 54, 24, 14, 55, 25), (22, 45, 15, 41, 46, 16), (6, 151, 121, 14, 152, 122), (6, 75, 47, 34, 76, 48), (46, 54, 24, 10, 55, 25), (2, 45, 15, 64, 46, 16), (17, 152, 122, 4, 153, 123), (29, 74, 46, 14, 75, 47), (49, 54, 24, 10, 55, 25), (24, 45, 15, 46, 46, 16), (4, 152, 122, 18, 153, 123), (13, 74, 46, 32, 75, 47), (48, 54, 24, 14, 55, 25), (42, 45, 15, 32, 46, 16), (20, 147, 117, 4, 148, 118), (40, 75, 47, 7, 76, 48), (43, 54, 24, 22, 55, 25), (10, 45, 15, 67, 46, 16), (19, 148, 118, 6, 149, 119), (18, 75, 47, 31, 76, 48), (34, 54, 24, 34, 55, 25), (20, 45, 15, 61, 46, 16))

def glog(n):
    if n < 1:
        raise ValueError(f'glog({n})')
    return LOG_TABLE[n]

def gexp(n):
    return EXP_TABLE[n % 255]

class Polynomial:

    def __init__(self, num, shift):
        if not num:
            raise Exception(f'{len(num)}/{shift}')
        offset = 0
        for offset in range(len(num)):
            if num[offset] != 0:
                break
        self.num = num[offset:] + [0] * shift

    def __getitem__(self, index):
        return self.num[index]

    def __iter__(self):
        return iter(self.num)

    def __len__(self):
        return len(self.num)

    def __mul__(self, other):
        num = [0] * (len(self) + len(other) - 1)
        for i, item in enumerate(self):
            for j, other_item in enumerate(other):
                num[i + j] ^= gexp(glog(item) + glog(other_item))
        return Polynomial(num, 0)

    def __mod__(self, other):
        difference = len(self) - len(other)
        if difference < 0:
            return self
        ratio = glog(self[0]) - glog(other[0])
        num = [item ^ gexp(glog(other_item) + ratio) for item, other_item in zip(self, other)]
        if difference:
            num.extend(self[-difference:])
        return Polynomial(num, 0) % other

class RSBlock(NamedTuple):
    total_count: int
    data_count: int

def rs_blocks(version, error_correction):
    if error_correction not in RS_BLOCK_OFFSET:
        raise Exception('bad rs block @ version: %s / error_correction: %s' % (version, error_correction))
    offset = RS_BLOCK_OFFSET[error_correction]
    rs_block = RS_BLOCK_TABLE[(version - 1) * 4 + offset]
    blocks = []
    for i in range(0, len(rs_block), 3):
        count, total_count, data_count = rs_block[i:i + 3]
        for _ in range(count):
            blocks.append(RSBlock(total_count, data_count))
    return blocks

# === merged from qrcode/image/base.py ===
import abc
from typing import TYPE_CHECKING, Any, Optional, Union
DrawerAliases = dict[str, tuple[type[QRModuleDrawer], dict[str, Any]]]

class BaseImage:
    """
    Base QRCode image output class.
    """
    kind: Optional[str] = None
    allowed_kinds: Optional[tuple[str]] = None
    needs_context = False
    needs_processing = False
    needs_drawrect = True

    def __init__(self, border, width, box_size, *args, **kwargs):
        self.border = border
        self.width = width
        self.box_size = box_size
        self.pixel_size = (self.width + self.border * 2) * self.box_size
        self.modules = kwargs.pop('qrcode_modules')
        self._img = self.new_image(**kwargs)
        self.init_new_image()

    @abc.abstractmethod
    def drawrect(self, row, col):
        """
        Draw a single rectangle of the QR code.
        """

    def drawrect_context(self, row: int, col: int, qr: 'QRCode'):
        """
        Draw a single rectangle of the QR code given the surrounding context
        """
        raise NotImplementedError('BaseImage.drawrect_context')

    def process(self):
        """
        Processes QR code after completion
        """
        raise NotImplementedError('BaseImage.drawimage')

    @abc.abstractmethod
    def save(self, stream, kind=None):
        """
        Save the image file.
        """

    def pixel_box(self, row, col):
        """
        A helper method for pixel-based image generators that specifies the
        four pixel coordinates for a single rect.
        """
        x = (col + self.border) * self.box_size
        y = (row + self.border) * self.box_size
        return ((x, y), (x + self.box_size - 1, y + self.box_size - 1))

    @abc.abstractmethod
    def new_image(self, **kwargs) -> Any:
        """
        Build the image class. Subclasses should return the class created.
        """

    def init_new_image(self):
        pass

    def get_image(self, **kwargs):
        """
        Return the image class for further processing.
        """
        return self._img

    def check_kind(self, kind, transform=None):
        """
        Get the image type.
        """
        if kind is None:
            kind = self.kind
        allowed = not self.allowed_kinds or kind in self.allowed_kinds
        if transform:
            kind = transform(kind)
            if not allowed:
                allowed = kind in self.allowed_kinds
        if not allowed:
            raise ValueError(f'Cannot set {type(self).__name__} type to {kind}')
        return kind

    def is_eye(self, row: int, col: int):
        """
        Find whether the referenced module is in an eye.
        """
        return row < 7 and col < 7 or (row < 7 and self.width - col < 8) or (self.width - row < 8 and col < 7)

class BaseImageWithDrawer(BaseImage):
    default_drawer_class: type[QRModuleDrawer]
    drawer_aliases: DrawerAliases = {}

    def get_default_module_drawer(self) -> QRModuleDrawer:
        return self.default_drawer_class()

    def get_default_eye_drawer(self) -> QRModuleDrawer:
        return self.default_drawer_class()
    needs_context = True
    module_drawer: 'QRModuleDrawer'
    eye_drawer: 'QRModuleDrawer'

    def __init__(self, *args, module_drawer: Union[QRModuleDrawer, str, None]=None, eye_drawer: Union[QRModuleDrawer, str, None]=None, **kwargs):
        self.module_drawer = self.get_drawer(module_drawer) or self.get_default_module_drawer()
        self.eye_drawer = self.get_drawer(eye_drawer) or self.get_default_eye_drawer()
        super().__init__(*args, **kwargs)

    def get_drawer(self, drawer: Union[QRModuleDrawer, str, None]) -> Optional[QRModuleDrawer]:
        if not isinstance(drawer, str):
            return drawer
        drawer_cls, kwargs = self.drawer_aliases[drawer]
        return drawer_cls(**kwargs)

    def init_new_image(self):
        self.module_drawer.initialize(img=self)
        self.eye_drawer.initialize(img=self)
        return super().init_new_image()

    def drawrect_context(self, row: int, col: int, qr: 'QRCode'):
        box = self.pixel_box(row, col)
        drawer = self.eye_drawer if self.is_eye(row, col) else self.module_drawer
        is_active: Union[bool, ActiveWithNeighbors] = qr.active_with_neighbors(row, col) if drawer.needs_neighbors else bool(qr.modules[row][col])
        drawer.drawrect(box, is_active)

# === merged from qrcode/image/pure.py ===
from itertools import chain

class PyPNGImage(BaseImage):
    """
    pyPNG image builder.
    """
    kind = 'PNG'
    allowed_kinds = ('PNG',)
    needs_drawrect = False

    def new_image(self, **kwargs):
        if not PngWriter:
            raise ImportError('PyPNG library not installed.')
        return PngWriter(self.pixel_size, self.pixel_size, greyscale=True, bitdepth=1)

    def drawrect(self, row, col):
        """
        Not used.
        """

    def save(self, stream, kind=None):
        if isinstance(stream, str):
            stream = open(stream, 'wb')
        self._img.write(stream, self.rows_iter())

    def rows_iter(self):
        yield from self.border_rows_iter()
        border_col = [1] * (self.box_size * self.border)
        for module_row in self.modules:
            row = border_col + list(chain.from_iterable(([not point] * self.box_size for point in module_row))) + border_col
            for _ in range(self.box_size):
                yield row
        yield from self.border_rows_iter()

    def border_rows_iter(self):
        border_row = [1] * (self.box_size * (self.width + self.border * 2))
        for _ in range(self.border * self.box_size):
            yield border_row
PymagingImage = PyPNGImage

# === merged from qrcode/util.py ===
import math
import re
MODE_NUMBER = 1 << 0
MODE_ALPHA_NUM = 1 << 1
MODE_8BIT_BYTE = 1 << 2
MODE_KANJI = 1 << 3
MODE_SIZE_SMALL = {MODE_NUMBER: 10, MODE_ALPHA_NUM: 9, MODE_8BIT_BYTE: 8, MODE_KANJI: 8}
MODE_SIZE_MEDIUM = {MODE_NUMBER: 12, MODE_ALPHA_NUM: 11, MODE_8BIT_BYTE: 16, MODE_KANJI: 10}
MODE_SIZE_LARGE = {MODE_NUMBER: 14, MODE_ALPHA_NUM: 13, MODE_8BIT_BYTE: 16, MODE_KANJI: 12}
ALPHA_NUM = b'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:'
RE_ALPHA_NUM = re.compile(b'^[' + re.escape(ALPHA_NUM) + b']*\\Z')
NUMBER_LENGTH = {3: 10, 2: 7, 1: 4}
PATTERN_POSITION_TABLE = [[], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50], [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70], [6, 26, 50, 74], [6, 30, 54, 78], [6, 30, 56, 82], [6, 30, 58, 86], [6, 34, 62, 90], [6, 28, 50, 72, 94], [6, 26, 50, 74, 98], [6, 30, 54, 78, 102], [6, 28, 54, 80, 106], [6, 32, 58, 84, 110], [6, 30, 58, 86, 114], [6, 34, 62, 90, 118], [6, 26, 50, 74, 98, 122], [6, 30, 54, 78, 102, 126], [6, 26, 52, 78, 104, 130], [6, 30, 56, 82, 108, 134], [6, 34, 60, 86, 112, 138], [6, 30, 58, 86, 114, 142], [6, 34, 62, 90, 118, 146], [6, 30, 54, 78, 102, 126, 150], [6, 24, 50, 76, 102, 128, 154], [6, 28, 54, 80, 106, 132, 158], [6, 32, 58, 84, 110, 136, 162], [6, 26, 54, 82, 110, 138, 166], [6, 30, 58, 86, 114, 142, 170]]
G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0
G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0
G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1
PAD0 = 236
PAD1 = 17

def _data_count(block):
    return block.data_count
BIT_LIMIT_TABLE = [[0] + [8 * sum(map(_data_count, base.rs_blocks(version, error_correction))) for version in range(1, 41)] for error_correction in range(4)]

def BCH_type_info(data):
    d = data << 10
    while BCH_digit(d) - BCH_digit(G15) >= 0:
        d ^= G15 << BCH_digit(d) - BCH_digit(G15)
    return (data << 10 | d) ^ G15_MASK

def BCH_type_number(data):
    d = data << 12
    while BCH_digit(d) - BCH_digit(G18) >= 0:
        d ^= G18 << BCH_digit(d) - BCH_digit(G18)
    return data << 12 | d

def BCH_digit(data):
    digit = 0
    while data != 0:
        digit += 1
        data >>= 1
    return digit

def pattern_position(version):
    return PATTERN_POSITION_TABLE[version - 1]

def mask_func(pattern):
    """
    Return the mask function for the given mask pattern.
    """
    if pattern == 0:
        return lambda i, j: (i + j) % 2 == 0
    if pattern == 1:
        return lambda i, j: i % 2 == 0
    if pattern == 2:
        return lambda i, j: j % 3 == 0
    if pattern == 3:
        return lambda i, j: (i + j) % 3 == 0
    if pattern == 4:
        return lambda i, j: (math.floor(i / 2) + math.floor(j / 3)) % 2 == 0
    if pattern == 5:
        return lambda i, j: i * j % 2 + i * j % 3 == 0
    if pattern == 6:
        return lambda i, j: (i * j % 2 + i * j % 3) % 2 == 0
    if pattern == 7:
        return lambda i, j: (i * j % 3 + (i + j) % 2) % 2 == 0
    raise TypeError('Bad mask pattern: ' + pattern)

def mode_sizes_for_version(version):
    if version < 10:
        return MODE_SIZE_SMALL
    elif version < 27:
        return MODE_SIZE_MEDIUM
    else:
        return MODE_SIZE_LARGE

def length_in_bits(mode, version):
    if mode not in (MODE_NUMBER, MODE_ALPHA_NUM, MODE_8BIT_BYTE, MODE_KANJI):
        raise TypeError(f'Invalid mode ({mode})')
    check_version(version)
    return mode_sizes_for_version(version)[mode]

def check_version(version):
    if version < 1 or version > 40:
        raise ValueError(f'Invalid version (was {version}, expected 1 to 40)')

def lost_point(modules):
    modules_count = len(modules)
    lost_point = 0
    lost_point = _lost_point_level1(modules, modules_count)
    lost_point += _lost_point_level2(modules, modules_count)
    lost_point += _lost_point_level3(modules, modules_count)
    lost_point += _lost_point_level4(modules, modules_count)
    return lost_point

def _lost_point_level1(modules, modules_count):
    lost_point = 0
    modules_range = range(modules_count)
    container = [0] * (modules_count + 1)
    for row in modules_range:
        this_row = modules[row]
        previous_color = this_row[0]
        length = 0
        for col in modules_range:
            if this_row[col] == previous_color:
                length += 1
            else:
                if length >= 5:
                    container[length] += 1
                length = 1
                previous_color = this_row[col]
        if length >= 5:
            container[length] += 1
    for col in modules_range:
        previous_color = modules[0][col]
        length = 0
        for row in modules_range:
            if modules[row][col] == previous_color:
                length += 1
            else:
                if length >= 5:
                    container[length] += 1
                length = 1
                previous_color = modules[row][col]
        if length >= 5:
            container[length] += 1
    lost_point += sum((container[each_length] * (each_length - 2) for each_length in range(5, modules_count + 1)))
    return lost_point

def _lost_point_level2(modules, modules_count):
    lost_point = 0
    modules_range = range(modules_count - 1)
    for row in modules_range:
        this_row = modules[row]
        next_row = modules[row + 1]
        modules_range_iter = iter(modules_range)
        for col in modules_range_iter:
            top_right = this_row[col + 1]
            if top_right != next_row[col + 1]:
                next(modules_range_iter, None)
            elif top_right != this_row[col]:
                continue
            elif top_right != next_row[col]:
                continue
            else:
                lost_point += 3
    return lost_point

def _lost_point_level3(modules, modules_count):
    modules_range = range(modules_count)
    modules_range_short = range(modules_count - 10)
    lost_point = 0
    for row in modules_range:
        this_row = modules[row]
        modules_range_short_iter = iter(modules_range_short)
        col = 0
        for col in modules_range_short_iter:
            if not this_row[col + 1] and this_row[col + 4] and (not this_row[col + 5]) and this_row[col + 6] and (not this_row[col + 9]) and (this_row[col + 0] and this_row[col + 2] and this_row[col + 3] and (not this_row[col + 7]) and (not this_row[col + 8]) and (not this_row[col + 10]) or (not this_row[col + 0] and (not this_row[col + 2]) and (not this_row[col + 3]) and this_row[col + 7] and this_row[col + 8] and this_row[col + 10])):
                lost_point += 40
            if this_row[col + 10]:
                next(modules_range_short_iter, None)
    for col in modules_range:
        modules_range_short_iter = iter(modules_range_short)
        row = 0
        for row in modules_range_short_iter:
            if not modules[row + 1][col] and modules[row + 4][col] and (not modules[row + 5][col]) and modules[row + 6][col] and (not modules[row + 9][col]) and (modules[row + 0][col] and modules[row + 2][col] and modules[row + 3][col] and (not modules[row + 7][col]) and (not modules[row + 8][col]) and (not modules[row + 10][col]) or (not modules[row + 0][col] and (not modules[row + 2][col]) and (not modules[row + 3][col]) and modules[row + 7][col] and modules[row + 8][col] and modules[row + 10][col])):
                lost_point += 40
            if modules[row + 10][col]:
                next(modules_range_short_iter, None)
    return lost_point

def _lost_point_level4(modules, modules_count):
    dark_count = sum(map(sum, modules))
    percent = float(dark_count) / modules_count ** 2
    rating = int(abs(percent * 100 - 50) / 5)
    return rating * 10

def optimal_data_chunks(data, minimum=4):
    """
    An iterator returning QRData chunks optimized to the data content.

    :param minimum: The minimum number of bytes in a row to split as a chunk.
    """
    data = to_bytestring(data)
    num_pattern = b'\\d'
    alpha_pattern = b'[' + re.escape(ALPHA_NUM) + b']'
    if len(data) <= minimum:
        num_pattern = re.compile(b'^' + num_pattern + b'+$')
        alpha_pattern = re.compile(b'^' + alpha_pattern + b'+$')
    else:
        re_repeat = b'{' + str(minimum).encode('ascii') + b',}'
        num_pattern = re.compile(num_pattern + re_repeat)
        alpha_pattern = re.compile(alpha_pattern + re_repeat)
    num_bits = _optimal_split(data, num_pattern)
    for is_num, chunk in num_bits:
        if is_num:
            yield QRData(chunk, mode=MODE_NUMBER, check_data=False)
        else:
            for is_alpha, sub_chunk in _optimal_split(chunk, alpha_pattern):
                mode = MODE_ALPHA_NUM if is_alpha else MODE_8BIT_BYTE
                yield QRData(sub_chunk, mode=mode, check_data=False)

def _optimal_split(data, pattern):
    while data:
        match = re.search(pattern, data)
        if not match:
            break
        start, end = (match.start(), match.end())
        if start:
            yield (False, data[:start])
        yield (True, data[start:end])
        data = data[end:]
    if data:
        yield (False, data)

def to_bytestring(data):
    """
    Convert data to a (utf-8 encoded) byte-string if it isn't a byte-string
    already.
    """
    if not isinstance(data, bytes):
        data = str(data).encode('utf-8')
    return data

def optimal_mode(data):
    """
    Calculate the optimal mode for this chunk of data.
    """
    if data.isdigit():
        return MODE_NUMBER
    if RE_ALPHA_NUM.match(data):
        return MODE_ALPHA_NUM
    return MODE_8BIT_BYTE

class QRData:
    """
    Data held in a QR compatible format.

    Doesn't currently handle KANJI.
    """

    def __init__(self, data, mode=None, check_data=True):
        """
        If ``mode`` isn't provided, the most compact QR data type possible is
        chosen.
        """
        if check_data:
            data = to_bytestring(data)
        if mode is None:
            self.mode = optimal_mode(data)
        else:
            self.mode = mode
            if mode not in (MODE_NUMBER, MODE_ALPHA_NUM, MODE_8BIT_BYTE):
                raise TypeError(f'Invalid mode ({mode})')
            if check_data and mode < optimal_mode(data):
                raise ValueError(f'Provided data can not be represented in mode {mode}')
        self.data = data

    def __len__(self):
        return len(self.data)

    def write(self, buffer):
        if self.mode == MODE_NUMBER:
            for i in range(0, len(self.data), 3):
                chars = self.data[i:i + 3]
                bit_length = NUMBER_LENGTH[len(chars)]
                buffer.put(int(chars), bit_length)
        elif self.mode == MODE_ALPHA_NUM:
            for i in range(0, len(self.data), 2):
                chars = self.data[i:i + 2]
                if len(chars) > 1:
                    buffer.put(ALPHA_NUM.find(chars[0]) * 45 + ALPHA_NUM.find(chars[1]), 11)
                else:
                    buffer.put(ALPHA_NUM.find(chars), 6)
        else:
            data = self.data
            for c in data:
                buffer.put(c, 8)

    def __repr__(self):
        return repr(self.data)

class BitBuffer:

    def __init__(self):
        self.buffer: list[int] = []
        self.length = 0

    def __repr__(self):
        return '.'.join([str(n) for n in self.buffer])

    def get(self, index):
        buf_index = math.floor(index / 8)
        return self.buffer[buf_index] >> 7 - index % 8 & 1 == 1

    def put(self, num, length):
        for i in range(length):
            self.put_bit(num >> length - i - 1 & 1 == 1)

    def __len__(self):
        return self.length

    def put_bit(self, bit):
        buf_index = self.length // 8
        if len(self.buffer) <= buf_index:
            self.buffer.append(0)
        if bit:
            self.buffer[buf_index] |= 128 >> self.length % 8
        self.length += 1

def create_bytes(buffer: BitBuffer, rs_blocks: list[RSBlock]):
    offset = 0
    maxDcCount = 0
    maxEcCount = 0
    dcdata: list[list[int]] = []
    ecdata: list[list[int]] = []
    for rs_block in rs_blocks:
        dcCount = rs_block.data_count
        ecCount = rs_block.total_count - dcCount
        maxDcCount = max(maxDcCount, dcCount)
        maxEcCount = max(maxEcCount, ecCount)
        current_dc = [255 & buffer.buffer[i + offset] for i in range(dcCount)]
        offset += dcCount
        if ecCount in LUT.rsPoly_LUT:
            rsPoly = base.Polynomial(LUT.rsPoly_LUT[ecCount], 0)
        else:
            rsPoly = base.Polynomial([1], 0)
            for i in range(ecCount):
                rsPoly = rsPoly * base.Polynomial([1, base.gexp(i)], 0)
        rawPoly = base.Polynomial(current_dc, len(rsPoly) - 1)
        modPoly = rawPoly % rsPoly
        current_ec = []
        mod_offset = len(modPoly) - ecCount
        for i in range(ecCount):
            modIndex = i + mod_offset
            current_ec.append(modPoly[modIndex] if modIndex >= 0 else 0)
        dcdata.append(current_dc)
        ecdata.append(current_ec)
    data = []
    for i in range(maxDcCount):
        for dc in dcdata:
            if i < len(dc):
                data.append(dc[i])
    for i in range(maxEcCount):
        for ec in ecdata:
            if i < len(ec):
                data.append(ec[i])
    return data

def create_data(version, error_correction, data_list):
    buffer = BitBuffer()
    for data in data_list:
        buffer.put(data.mode, 4)
        buffer.put(len(data), length_in_bits(data.mode, version))
        data.write(buffer)
    rs_blocks = base.rs_blocks(version, error_correction)
    bit_limit = sum((block.data_count * 8 for block in rs_blocks))
    if len(buffer) > bit_limit:
        raise exceptions.DataOverflowError('Code length overflow. Data size (%s) > size available (%s)' % (len(buffer), bit_limit))
    for _ in range(min(bit_limit - len(buffer), 4)):
        buffer.put_bit(False)
    delimit = len(buffer) % 8
    if delimit:
        for _ in range(8 - delimit):
            buffer.put_bit(False)
    bytes_to_fill = (bit_limit - len(buffer)) // 8
    for i in range(bytes_to_fill):
        if i % 2 == 0:
            buffer.put(PAD0, 8)
        else:
            buffer.put(PAD1, 8)
    return create_bytes(buffer, rs_blocks)

# === merged from qrcode/image/styles/moduledrawers/svg.py ===
import abc
from decimal import Decimal
from typing import TYPE_CHECKING, NamedTuple
ANTIALIASING_FACTOR = 4

class Coords(NamedTuple):
    x0: Decimal
    y0: Decimal
    x1: Decimal
    y1: Decimal
    xh: Decimal
    yh: Decimal

class BaseSvgQRModuleDrawer(QRModuleDrawer):
    img: 'SvgFragmentImage'

    def __init__(self, *, size_ratio: Decimal=Decimal(1), **kwargs):
        self.size_ratio = size_ratio

    def initialize(self, *args, **kwargs) -> None:
        super().initialize(*args, **kwargs)
        self.box_delta = (1 - self.size_ratio) * self.img.box_size / 2
        self.box_size = Decimal(self.img.box_size) * self.size_ratio
        self.box_half = self.box_size / 2

    def coords(self, box) -> Coords:
        row, col = box[0]
        x = row + self.box_delta
        y = col + self.box_delta
        return Coords(x, y, x + self.box_size, y + self.box_size, x + self.box_half, y + self.box_half)

class SvgQRModuleDrawer(BaseSvgQRModuleDrawer):
    tag = 'rect'

    def initialize(self, *args, **kwargs) -> None:
        super().initialize(*args, **kwargs)
        self.tag_qname = ET.QName(self.img._SVG_namespace, self.tag)

    def drawrect(self, box, is_active: bool):
        if not is_active:
            return
        self.img._img.append(self.el(box))

    @abc.abstractmethod
    def el(self, box):
        ...

class SvgSquareDrawer(SvgQRModuleDrawer):

    def initialize(self, *args, **kwargs) -> None:
        super().initialize(*args, **kwargs)
        self.unit_size = self.img.units(self.box_size)

    def el(self, box):
        coords = self.coords(box)
        return ET.Element(self.tag_qname, x=self.img.units(coords.x0), y=self.img.units(coords.y0), width=self.unit_size, height=self.unit_size)

class SvgCircleDrawer(SvgQRModuleDrawer):
    tag = 'circle'

    def initialize(self, *args, **kwargs) -> None:
        super().initialize(*args, **kwargs)
        self.radius = self.img.units(self.box_half)

    def el(self, box):
        coords = self.coords(box)
        return ET.Element(self.tag_qname, cx=self.img.units(coords.xh), cy=self.img.units(coords.yh), r=self.radius)

class SvgPathQRModuleDrawer(BaseSvgQRModuleDrawer):
    img: 'SvgPathImage'

    def drawrect(self, box, is_active: bool):
        if not is_active:
            return
        self.img._subpaths.append(self.subpath(box))

    @abc.abstractmethod
    def subpath(self, box) -> str:
        ...

class SvgPathSquareDrawer(SvgPathQRModuleDrawer):

    def subpath(self, box) -> str:
        coords = self.coords(box)
        x0 = self.img.units(coords.x0, text=False)
        y0 = self.img.units(coords.y0, text=False)
        x1 = self.img.units(coords.x1, text=False)
        y1 = self.img.units(coords.y1, text=False)
        return f'M{x0},{y0}H{x1}V{y1}H{x0}z'

class SvgPathCircleDrawer(SvgPathQRModuleDrawer):

    def initialize(self, *args, **kwargs) -> None:
        super().initialize(*args, **kwargs)

    def subpath(self, box) -> str:
        coords = self.coords(box)
        x0 = self.img.units(coords.x0, text=False)
        yh = self.img.units(coords.yh, text=False)
        h = self.img.units(self.box_half - self.box_delta, text=False)
        x1 = self.img.units(coords.x1, text=False)
        return f'M{x0},{yh}A{h},{h} 0 0 0 {x1},{yh}A{h},{h} 0 0 0 {x0},{yh}z'

# === merged from qrcode/image/svg.py ===
import decimal
from decimal import Decimal
from typing import Optional, Union, overload, Literal

class SvgFragmentImage(qrcode.image.base.BaseImageWithDrawer):
    """
    SVG image builder

    Creates a QR-code image as a SVG document fragment.
    """
    _SVG_namespace = 'http://www.w3.org/2000/svg'
    kind = 'SVG'
    allowed_kinds = ('SVG',)
    default_drawer_class: type[QRModuleDrawer] = svg_drawers.SvgSquareDrawer

    def __init__(self, *args, **kwargs):
        ET.register_namespace('svg', self._SVG_namespace)
        super().__init__(*args, **kwargs)
        self.unit_size = self.units(self.box_size)

    @overload
    def units(self, pixels: Union[int, Decimal], text: Literal[False]) -> Decimal:
        ...

    @overload
    def units(self, pixels: Union[int, Decimal], text: Literal[True]=True) -> str:
        ...

    def units(self, pixels, text=True):
        """
        A box_size of 10 (default) equals 1mm.
        """
        units = Decimal(pixels) / 10
        if not text:
            return units
        units = units.quantize(Decimal('0.001'))
        context = decimal.Context(traps=[decimal.Inexact])
        try:
            for d in (Decimal('0.01'), Decimal('0.1'), Decimal('0')):
                units = units.quantize(d, context=context)
        except decimal.Inexact:
            pass
        return f'{units}mm'

    def save(self, stream, kind=None):
        self.check_kind(kind=kind)
        self._write(stream)

    def to_string(self, **kwargs):
        return ET.tostring(self._img, **kwargs)

    def new_image(self, **kwargs):
        return self._svg(**kwargs)

    def _svg(self, tag=None, version='1.1', **kwargs):
        if tag is None:
            tag = ET.QName(self._SVG_namespace, 'svg')
        dimension = self.units(self.pixel_size)
        return ET.Element(tag, width=dimension, height=dimension, version=version, **kwargs)

    def _write(self, stream):
        ET.ElementTree(self._img).write(stream, xml_declaration=False)

class SvgImage(SvgFragmentImage):
    """
    Standalone SVG image builder

    Creates a QR-code image as a standalone SVG document.
    """
    background: Optional[str] = None
    drawer_aliases: qrcode.image.base.DrawerAliases = {'circle': (svg_drawers.SvgCircleDrawer, {}), 'gapped-circle': (svg_drawers.SvgCircleDrawer, {'size_ratio': Decimal(0.8)}), 'gapped-square': (svg_drawers.SvgSquareDrawer, {'size_ratio': Decimal(0.8)})}

    def _svg(self, tag='svg', **kwargs):
        svg = super()._svg(tag=tag, **kwargs)
        svg.set('xmlns', self._SVG_namespace)
        if self.background:
            svg.append(ET.Element('rect', fill=self.background, x='0', y='0', width='100%', height='100%'))
        return svg

    def _write(self, stream):
        ET.ElementTree(self._img).write(stream, encoding='UTF-8', xml_declaration=True)

class SvgPathImage(SvgImage):
    """
    SVG image builder with one single <path> element (removes white spaces
    between individual QR points).
    """
    QR_PATH_STYLE = {'fill': '#000000', 'fill-opacity': '1', 'fill-rule': 'nonzero', 'stroke': 'none'}
    needs_processing = True
    path: Optional[ET.Element] = None
    default_drawer_class: type[QRModuleDrawer] = svg_drawers.SvgPathSquareDrawer
    drawer_aliases = {'circle': (svg_drawers.SvgPathCircleDrawer, {}), 'gapped-circle': (svg_drawers.SvgPathCircleDrawer, {'size_ratio': Decimal(0.8)}), 'gapped-square': (svg_drawers.SvgPathSquareDrawer, {'size_ratio': Decimal(0.8)})}

    def __init__(self, *args, **kwargs):
        self._subpaths: list[str] = []
        super().__init__(*args, **kwargs)

    def _svg(self, viewBox=None, **kwargs):
        if viewBox is None:
            dimension = self.units(self.pixel_size, text=False)
            viewBox = '0 0 {d} {d}'.format(d=dimension)
        return super()._svg(viewBox=viewBox, **kwargs)

    def process(self):
        self.path = ET.Element(ET.QName('path'), d=''.join(self._subpaths), id='qr-path', **self.QR_PATH_STYLE)
        self._subpaths = []
        self._img.append(self.path)

class SvgFillImage(SvgImage):
    """
    An SvgImage that fills the background to white.
    """
    background = 'white'

class SvgPathFillImage(SvgPathImage):
    """
    An SvgPathImage that fills the background to white.
    """
    background = 'white'

# === merged from qrcode/main.py ===
import sys
from bisect import bisect_left
from typing import Generic, NamedTuple, Optional, TypeVar, cast, overload, Literal
ModulesType = list[list[Optional[bool]]]
precomputed_qr_blanks: dict[int, ModulesType] = {}

def make(data=None, **kwargs):
    qr = QRCode(**kwargs)
    qr.add_data(data)
    return qr.make_image()

def _check_box_size(size):
    if int(size) <= 0:
        raise ValueError(f'Invalid box size (was {size}, expected larger than 0)')

def _check_border(size):
    if int(size) < 0:
        raise ValueError('Invalid border value (was %s, expected 0 or larger than that)' % size)

def _check_mask_pattern(mask_pattern):
    if mask_pattern is None:
        return
    if not isinstance(mask_pattern, int):
        raise TypeError(f'Invalid mask pattern (was {type(mask_pattern)}, expected int)')
    if mask_pattern < 0 or mask_pattern > 7:
        raise ValueError(f'Mask pattern should be in range(8) (got {mask_pattern})')

def copy_2d_array(x):
    return [row[:] for row in x]

class ActiveWithNeighbors(NamedTuple):
    NW: bool
    N: bool
    NE: bool
    W: bool
    me: bool
    E: bool
    SW: bool
    S: bool
    SE: bool

    def __bool__(self) -> bool:
        return self.me
GenericImage = TypeVar('GenericImage', bound=BaseImage)
GenericImageLocal = TypeVar('GenericImageLocal', bound=BaseImage)

class QRCode(Generic[GenericImage]):
    modules: ModulesType
    _version: Optional[int] = None

    def __init__(self, version=None, error_correction=constants.ERROR_CORRECT_M, box_size=10, border=4, image_factory: Optional[type[GenericImage]]=None, mask_pattern=None):
        _check_box_size(box_size)
        _check_border(border)
        self.version = version
        self.error_correction = int(error_correction)
        self.box_size = int(box_size)
        self.border = int(border)
        self.mask_pattern = mask_pattern
        self.image_factory = image_factory
        if image_factory is not None:
            assert issubclass(image_factory, BaseImage)
        self.clear()

    @property
    def version(self) -> int:
        if self._version is None:
            self.best_fit()
        return cast(int, self._version)

    @version.setter
    def version(self, value) -> None:
        if value is not None:
            value = int(value)
            util.check_version(value)
        self._version = value

    @property
    def mask_pattern(self):
        return self._mask_pattern

    @mask_pattern.setter
    def mask_pattern(self, pattern):
        _check_mask_pattern(pattern)
        self._mask_pattern = pattern

    def clear(self):
        """
        Reset the internal data.
        """
        self.modules = [[]]
        self.modules_count = 0
        self.data_cache = None
        self.data_list = []

    def add_data(self, data, optimize=20):
        """
        Add data to this QR Code.

        :param optimize: Data will be split into multiple chunks to optimize
            the QR size by finding to more compressed modes of at least this
            length. Set to ``0`` to avoid optimizing at all.
        """
        if isinstance(data, util.QRData):
            self.data_list.append(data)
        elif optimize:
            self.data_list.extend(util.optimal_data_chunks(data, minimum=optimize))
        else:
            self.data_list.append(util.QRData(data))
        self.data_cache = None

    def make(self, fit=True):
        """
        Compile the data into a QR Code array.

        :param fit: If ``True`` (or if a size has not been provided), find the
            best fit for the data to avoid data overflow errors.
        """
        if fit or self.version is None:
            self.best_fit(start=self.version)
        if self.mask_pattern is None:
            self.makeImpl(False, self.best_mask_pattern())
        else:
            self.makeImpl(False, self.mask_pattern)

    def makeImpl(self, test, mask_pattern):
        self.modules_count = self.version * 4 + 17
        if self.version in precomputed_qr_blanks:
            self.modules = copy_2d_array(precomputed_qr_blanks[self.version])
        else:
            self.modules = [[None] * self.modules_count for i in range(self.modules_count)]
            self.setup_position_probe_pattern(0, 0)
            self.setup_position_probe_pattern(self.modules_count - 7, 0)
            self.setup_position_probe_pattern(0, self.modules_count - 7)
            self.setup_position_adjust_pattern()
            self.setup_timing_pattern()
            precomputed_qr_blanks[self.version] = copy_2d_array(self.modules)
        self.setup_type_info(test, mask_pattern)
        if self.version >= 7:
            self.setup_type_number(test)
        if self.data_cache is None:
            self.data_cache = util.create_data(self.version, self.error_correction, self.data_list)
        self.map_data(self.data_cache, mask_pattern)

    def setup_position_probe_pattern(self, row, col):
        for r in range(-1, 8):
            if row + r <= -1 or self.modules_count <= row + r:
                continue
            for c in range(-1, 8):
                if col + c <= -1 or self.modules_count <= col + c:
                    continue
                if 0 <= r <= 6 and c in {0, 6} or (0 <= c <= 6 and r in {0, 6}) or (2 <= r <= 4 and 2 <= c <= 4):
                    self.modules[row + r][col + c] = True
                else:
                    self.modules[row + r][col + c] = False

    def best_fit(self, start=None):
        """
        Find the minimum size required to fit in the data.
        """
        if start is None:
            start = 1
        util.check_version(start)
        mode_sizes = util.mode_sizes_for_version(start)
        buffer = util.BitBuffer()
        for data in self.data_list:
            buffer.put(data.mode, 4)
            buffer.put(len(data), mode_sizes[data.mode])
            data.write(buffer)
        needed_bits = len(buffer)
        self.version = bisect_left(util.BIT_LIMIT_TABLE[self.error_correction], needed_bits, start)
        if self.version == 41:
            raise exceptions.DataOverflowError()
        if mode_sizes is not util.mode_sizes_for_version(self.version):
            self.best_fit(start=self.version)
        return self.version

    def best_mask_pattern(self):
        """
        Find the most efficient mask pattern.
        """
        min_lost_point = 0
        pattern = 0
        for i in range(8):
            self.makeImpl(True, i)
            lost_point = util.lost_point(self.modules)
            if i == 0 or min_lost_point > lost_point:
                min_lost_point = lost_point
                pattern = i
        return pattern

    def print_tty(self, out=None):
        """
        Output the QR Code only using TTY colors.

        If the data has not been compiled yet, make it first.
        """
        if out is None:
            import sys
            out = sys.stdout
        if not out.isatty():
            raise OSError('Not a tty')
        if self.data_cache is None:
            self.make()
        modcount = self.modules_count
        out.write('\x1b[1;47m' + ' ' * (modcount * 2 + 4) + '\x1b[0m\n')
        for r in range(modcount):
            out.write('\x1b[1;47m  \x1b[40m')
            for c in range(modcount):
                if self.modules[r][c]:
                    out.write('  ')
                else:
                    out.write('\x1b[1;47m  \x1b[40m')
            out.write('\x1b[1;47m  \x1b[0m\n')
        out.write('\x1b[1;47m' + ' ' * (modcount * 2 + 4) + '\x1b[0m\n')
        out.flush()

    def print_ascii(self, out=None, tty=False, invert=False):
        """
        Output the QR Code using ASCII characters.

        :param tty: use fixed TTY color codes (forces invert=True)
        :param invert: invert the ASCII characters (solid <-> transparent)
        """
        if out is None:
            out = sys.stdout
        if tty and (not out.isatty()):
            raise OSError('Not a tty')
        if self.data_cache is None:
            self.make()
        modcount = self.modules_count
        codes = [bytes((code,)).decode('cp437') for code in (255, 223, 220, 219)]
        if tty:
            invert = True
        if invert:
            codes.reverse()

        def get_module(x, y) -> int:
            if invert and self.border and (max(x, y) >= modcount + self.border):
                return 1
            if min(x, y) < 0 or max(x, y) >= modcount:
                return 0
            return cast(int, self.modules[x][y])
        for r in range(-self.border, modcount + self.border, 2):
            if tty:
                if not invert or r < modcount + self.border - 1:
                    out.write('\x1b[48;5;232m')
                out.write('\x1b[38;5;255m')
            for c in range(-self.border, modcount + self.border):
                pos = get_module(r, c) + (get_module(r + 1, c) << 1)
                out.write(codes[pos])
            if tty:
                out.write('\x1b[0m')
            out.write('\n')
        out.flush()

    @overload
    def make_image(self, image_factory: Literal[None]=None, **kwargs) -> GenericImage:
        ...

    @overload
    def make_image(self, image_factory: type[GenericImageLocal]=None, **kwargs) -> GenericImageLocal:
        ...

    def make_image(self, image_factory=None, **kwargs):
        """
        Make an image from the QR Code data.

        If the data has not been compiled yet, make it first.
        """
        if (kwargs.get('embedded_image_path') or kwargs.get('embedded_image') or kwargs.get('embeded_image_path') or kwargs.get('embeded_image')) and self.error_correction != constants.ERROR_CORRECT_H:
            raise ValueError('Error correction level must be ERROR_CORRECT_H if an embedded image is provided')
        _check_box_size(self.box_size)
        if self.data_cache is None:
            self.make()
        if image_factory is not None:
            assert issubclass(image_factory, BaseImage)
        else:
            image_factory = self.image_factory
            if image_factory is None:
                image_factory = PyPNGImage
        im = image_factory(self.border, self.modules_count, self.box_size, qrcode_modules=self.modules, **kwargs)
        if im.needs_drawrect:
            for r in range(self.modules_count):
                for c in range(self.modules_count):
                    if im.needs_context:
                        im.drawrect_context(r, c, qr=self)
                    elif self.modules[r][c]:
                        im.drawrect(r, c)
        if im.needs_processing:
            im.process()
        return im

    def is_constrained(self, row: int, col: int) -> bool:
        return row >= 0 and row < len(self.modules) and (col >= 0) and (col < len(self.modules[row]))

    def setup_timing_pattern(self):
        for r in range(8, self.modules_count - 8):
            if self.modules[r][6] is not None:
                continue
            self.modules[r][6] = r % 2 == 0
        for c in range(8, self.modules_count - 8):
            if self.modules[6][c] is not None:
                continue
            self.modules[6][c] = c % 2 == 0

    def setup_position_adjust_pattern(self):
        pos = util.pattern_position(self.version)
        for i in range(len(pos)):
            row = pos[i]
            for j in range(len(pos)):
                col = pos[j]
                if self.modules[row][col] is not None:
                    continue
                for r in range(-2, 3):
                    for c in range(-2, 3):
                        if r == -2 or r == 2 or c == -2 or (c == 2) or (r == 0 and c == 0):
                            self.modules[row + r][col + c] = True
                        else:
                            self.modules[row + r][col + c] = False

    def setup_type_number(self, test):
        bits = util.BCH_type_number(self.version)
        for i in range(18):
            mod = not test and bits >> i & 1 == 1
            self.modules[i // 3][i % 3 + self.modules_count - 8 - 3] = mod
        for i in range(18):
            mod = not test and bits >> i & 1 == 1
            self.modules[i % 3 + self.modules_count - 8 - 3][i // 3] = mod

    def setup_type_info(self, test, mask_pattern):
        data = self.error_correction << 3 | mask_pattern
        bits = util.BCH_type_info(data)
        for i in range(15):
            mod = not test and bits >> i & 1 == 1
            if i < 6:
                self.modules[i][8] = mod
            elif i < 8:
                self.modules[i + 1][8] = mod
            else:
                self.modules[self.modules_count - 15 + i][8] = mod
        for i in range(15):
            mod = not test and bits >> i & 1 == 1
            if i < 8:
                self.modules[8][self.modules_count - i - 1] = mod
            elif i < 9:
                self.modules[8][15 - i - 1 + 1] = mod
            else:
                self.modules[8][15 - i - 1] = mod
        self.modules[self.modules_count - 8][8] = not test

    def map_data(self, data, mask_pattern):
        inc = -1
        row = self.modules_count - 1
        bitIndex = 7
        byteIndex = 0
        mask_func = util.mask_func(mask_pattern)
        data_len = len(data)
        for col in range(self.modules_count - 1, 0, -2):
            if col <= 6:
                col -= 1
            col_range = (col, col - 1)
            while True:
                for c in col_range:
                    if self.modules[row][c] is None:
                        dark = False
                        if byteIndex < data_len:
                            dark = data[byteIndex] >> bitIndex & 1 == 1
                        if mask_func(row, c):
                            dark = not dark
                        self.modules[row][c] = dark
                        bitIndex -= 1
                        if bitIndex == -1:
                            byteIndex += 1
                            bitIndex = 7
                row += inc
                if row < 0 or self.modules_count <= row:
                    row -= inc
                    inc = -inc
                    break

    def get_matrix(self):
        """
        Return the QR Code as a multidimensional array, including the border.

        To return the array without a border, set ``self.border`` to 0 first.
        """
        if self.data_cache is None:
            self.make()
        if not self.border:
            return self.modules
        width = len(self.modules) + self.border * 2
        code = [[False] * width] * self.border
        x_border = [False] * self.border
        for module in self.modules:
            code.append(x_border + cast(list[bool], module) + x_border)
        code += [[False] * width] * self.border
        return code

    def active_with_neighbors(self, row: int, col: int) -> ActiveWithNeighbors:
        context: list[bool] = []
        for r in range(row - 1, row + 2):
            for c in range(col - 1, col + 2):
                context.append(self.is_constrained(r, c) and bool(self.modules[r][c]))
        return ActiveWithNeighbors(*context)
