# -*- coding: utf-8 -*-
"""好内容印社 · 交付门禁（Pre-Publish Gate）—— 一条命令，判定"这篇能不能交"。

为什么必须存在（2026-10-13 血泪教训）：
  这次post_05 写作过程里，AI 连续犯了 4 个错：公众号 2600 字（规格 800–1500）、
  杜撰"这坑我专门写过一篇…往后翻"（该文不存在）、标题丢了 AI 语义与搜索词、
  结尾塞了三个问题（规格要求单一动作）。
  🔴 四个错全部命中 skill 里已有的明文规定 → **问题不是缺规则，是规则没有强制力**。
  文档约束"知道"，不约束"做到"；多轮对话后必然漂移。这是所有用本skill 的创作者
  都会踩的坑，不是某个人或某篇的偶然。

本脚本把这些规格变成可执行判定：
  - 三平台字数（按 writing-styles §六：小红书 100–400 / 公众号 800–1500 / 贴图号 ≤300）
  - 账号语义 + 搜索词是否落在标题/正文前段（按 platform-traffic 第 43/211 行）
  - 索取式钩禁词（按 GATE-E）
  - 杜撰自引检测（声称"写过一篇/往后翻"但标注文档里没有对应篇目）
  - 结尾动作数（按 writing-styles §六 单一动作）

用法：
    python scripts/pre_publish_gate.py <文稿.md> [<标题.md> <视觉文案.md> ...] [--config config.json]

    🔴 2026-10-14 老李复盘抓出的真问题：旧版只读**一个**文件，而 skill 工作流里
      「正文 / 标题 / 视觉文案」是三个文件（Step9 / Step8 / Step10）→ 2b/2c/2e/2f/2g
      找不到标题和视觉文案，**全部静默"跳过"**——门禁形同虚设，"规则没有强制力"原样复发。
      现改为**可传多个文件、自动合并检测**（顺序自动排成"正文→其他→视觉文案"）。
      标准跑法（三文件全传，一个都不能少）：
        python scripts/pre_publish_gate.py \
          07-呈现/Step9-正文.md 07-呈现/Step8-标题.md 07-呈现/Step10-视觉文案.md

config.json 可选（按账号定制，缺省用中文 AI 小白默认档）：
    {
      "account_keywords": ["AI", "编程小白", "skill", "副业", "一人公司", "活成队伍"],
      "search_keywords": ["C盘清理", "AI", "skill", "副业"],
      "require_keywords_in_title": true
    }

退出码：0 = 全部通过可交；1 = 有 FAIL，必须返工（不能发布）。
⚠️ 本门禁判FAIL 不代表"文章一定不好"，只代表**没做到 skill 明文规定的事**。
"""
import argparse
import json
import os
import re
import sys

# ---------- skill 规格（数字来自 writing-styles.md §六 / platform-traffic.md，改文档必须改这里） ----------
LIMITS = {
    "公众号": (800, 1500),
    "小红书": (100, 400),
    "贴图号": (0, 300),
}
BANNED_HOOK = ["点个关注", "转发点赞", "记得收藏", "求关注", "点个赞", "关注我",
               "点赞支持", "转发给"]
BANNED_CTX = ["不用", "禁止", "零索取", "不许", "不出现", "不是要你", "已删", "改为"]
# 声称写过另一篇，但标注文档里没有 → 杜撰自引（老李 2026-10-13 抓出的真实事故）
FABRICATED_SELF_REF = ["往后翻", "专门写过一篇", "之前写过一篇", "上一篇提过",
                       "前文写过", "详见上篇"]
DEFAULT_CONFIG = {
    # 第 2 项用：账号语义词——标题 / 正文前段里必须出现，让读者认出"这是哪个号"。
    # 🔴 2026-10-14 审查修正：移除「一人公司 / 活成队伍」——它们是**封面大字禁区词**
    #    （已进 abstract_theme_words 黑名单）。同一批词既作"必须有"又作"不许有"= 打架。
    #    账号语义靠 "AI / 编程小白 / skill / 副业" 已足够识别。
    "account_keywords": ["AI", "编程小白", "skill", "副业"],
    "search_keywords": ["AI", "skill", "C盘清理", "副业"],
    "require_keywords_in_title": True,
    # ---- 2026-10-14 内容漏斗模型新增（content-funnel.md）----
    # 2e 用：标题前10字须含"赛道识别词"——让用户一眼认出这是 AI/自媒体赛道。
    # 作用域：标题前 10 字 / 封面大字。
    # 注意：track_keywords 不是案例词（C盘清理），也不是抽象母题词（活成队伍），
    # 而是"这个号属于哪个赛道"的识别词。
    "track_keywords": ["AI", "ai", "自媒体", "副业", "做号", "内容创作", "一个人做"],
    # 2f 用：账号主张信号——视觉文案区块（封面大字+卡片论点）整块里须出现至少一个，
    #        证明"视觉物料没脱离主线（账号主张）"。
    # 🔴 作用域：**视觉文案整块**（含卡片论点），与 2g 的"封面大字/标题"作用域不同。
    #    这里故意**不**放"放大器/许愿池"——它们在卡片正文里合法、在封面大字里违规，
    #    放进来会让两表在同一层级产生歧义。也**不**放泛化的"AI"（任何文案都有，门槛形同虚设）。
    #    只放"判断 / 执行"这类**账号主张可复现词**：视觉文案里出现它，才算真讲到主线。
    "soul_signals": ["判断", "执行", "一个人做", "交给自己", "交给 AI"],
    # 2g 用：抽象母题词——出现在封面大字/标题里但无具体人群/数字，即"打不到具体人"。
    # 作用域：**封面大字 / 标题**（不含卡片正文）。
    # 🔴 2026-10-14 补：必须收"老李亲手否过的完整口号"。"一个人"本身是合法人群信号词，
    #   但"一个人活成队伍/一支队伍"整句是抽象母题——只收"活成队伍"会被
    #   "扣掉母题后剩下的'一个人'还是人群信号"绕过（反向注入实测漏过）。
    "abstract_theme_words": ["一个人活成", "一人活成", "活成队伍", "一支队伍",
                             "放大器", "许愿池", "一人公司", "变万能"],
    # 2g 用：具体人群信号——能指认"这是说给谁听的"。
    "audience_signals": ["普通人", "新手", "小白", "一个人", "上班族", "打工人", "宝妈",
                         "学生", "做号", "自媒体", "创作者", "想副业", "想搞钱", "没基础"],
    # 2g 用：具体问题信号——能指认"解决哪件事"。
    "concrete_signals": ["怎么", "如何", "为什么", "多少", "几步", "第一步", "第几步",
                         "方法", "步骤", "卡在", "不会", "做不出"],
    # 2h 用：零翻译成本黑名单（humanize.md 二·五）——封面大字/标题/卡片里出现即 FAIL。
    # 这些是"我们内部熟、读者要翻译"的词，人的天性是能不动脑就不动脑。
    # ⚠️ 只扫"面向读者的视觉文案"（封面大字/标题/卡片），不扫正文与 skill 文档，
    #    避免误伤（"复盘/沉淀"等词在正文里是正常表述）。
    "translate_blacklist": ["认领", "预感", "产品形态", "赋能", "心智", "认知升级",
                            "颗粒度", "链路", "抓手", "闭环", "对齐", "心智模型"],
}



def section(text, start_pat, end_pat):
    m = re.search(start_pat, text, re.M)
    if not m:
        return None
    body = text[m.start():]
    e = re.search(end_pat, body, re.M)
    return body[:e.start()] if e else body


def body_text(text):
    """只取三平台正文（## 一/二/三）——说明区/自检表不算正文（踩过的坑）。"""
    m = re.search(r"^##\s*一、", text, re.M)
    if not m:
        return text
    body = text[m.start():]
    e = re.search(r"^##\s*四、", body, re.M)
    return body[:e.start()] if e else body


def plat_section(text, name):
    """按标题含平台名定位正文段（兼容 '## 三、' 与 '## C. 贴图号版' 两种命名）。"""
    lines = text.splitlines()
    start = None
    for i, ln in enumerate(lines):
        if re.match(r"^##\s", ln) and name in ln:
            start = i
            break
    if start is None:
        return None
    for j in range(start + 1, len(lines)):
        if re.match(r"^##\s", lines[j]):
            return "\n".join(lines[start:j])
    return "\n".join(lines[start:])


def count_chars(seg):
    seg = re.sub(r"^\s*[|#>\-\*].*$", "", seg, flags=re.M)      # 去 markdown 标记行
    seg = re.sub(r"\*\*[^*]*\*\*", "", seg)                    # 去加粗符号
    return len(re.sub(r"\s", "", seg))


def main():
    ap = argparse.ArgumentParser(description="好内容印社 · 交付门禁（跑不过不能交）")
    ap.add_argument("draft", nargs="+",
                    help="文稿文件，可传多个。正文/标题/视觉文案分开存时必须全传，"
                         "否则 2b/2c/2e/2f/2g 会因找不到标题而静默跳过")
    ap.add_argument("--config", default="")
    args = ap.parse_args()

    cfg = dict(DEFAULT_CONFIG)
    if args.config and os.path.isfile(args.config):
        cfg.update(json.load(open(args.config, encoding="utf-8")))

    # ---- 配置自检（2026-10-14 审查新增 · 防"白名单黑名单打架"复发）----
    # 病因：曾出现「一人公司 / 活成队伍」同时在 account_keywords(必须有) 与
    #       abstract_theme_words(不许有) —— 两个检查互相打架，行为不可预测。
    # 规则：凡是"同一作用域"（都作用于标题/封面大字）的词表，交集必须为空。
    _conflict = set(cfg["account_keywords"]) & set(cfg["abstract_theme_words"])
    if _conflict:
        print("!! 配置自检失败：account_keywords 与 abstract_theme_words 有交集 %s"
              % sorted(_conflict))
        print("!! 同一批词不能既'必须有'又'不许有'。请把抽象母题词从 account_keywords 移除。")
        return 1
    _soul_abs = set(cfg["soul_signals"]) & set(cfg["abstract_theme_words"])
    if _soul_abs:
        print("!! 注意：soul_signals 与 abstract_theme_words 交集 %s（作用域不同可接受，"
              "但请确认不会误导使用者）" % sorted(_soul_abs))

    # ---- 读文件（2026-10-14 修正：支持多文件合并）----
    # 病因：工作流里正文(Step9)/标题(Step8)/视觉文案(Step10)是三个文件，旧版只读一个
    #       → 2b/2c/2e/2f/2g 找不到标题和视觉文案，全部"跳过"，门禁白跑。
    # 修法：多文件合并成一份检测；顺序固定为「正文 → 其他 → 视觉文案」，
    #       保证 2f 的区间捕获（## 五、视觉文案 … 到下一个 ##）不会吞掉别的文件内容。
    texts = []
    for f in args.draft:
        if not os.path.isfile(f):
            print("文件不存在：%s" % f)
            return 1
        texts.append((f, open(f, encoding="utf-8").read()))

    def _rank(item):
        _name, t = item
        if re.search(r"^##\s*一、", t, re.M):
            return 0                      # 三平台正文段最先（字数/正文检查认它）
        if re.search(r"视觉文案|封面大字", t):
            return 2                      # 视觉文案垫后（守住 2f 的捕获边界）
        return 1
    texts.sort(key=_rank)                 # sort 稳定，同级的按传入顺序
    raw = "\n\n".join(t for _, t in texts)
    body = body_text(raw)
    fails, warns = [], []

    # ---- 1. 三平台字数（skill writing-styles §六）----
    print("== 1. 字数（skill §六：小红书 100-400 / 公众号 800-1500 / 贴图号 ≤300）==")
    for plat, pat_s, pat_e in (("公众号", r"^##\s*一、", r"^##\s*二、"),
                          ("小红书", r"^##\s*二、", r"^##\s*三、"),
                              ("贴图号", r"^##\s*三、", r"^##\s*四、")):
        seg = section(raw, pat_s, pat_e)
        if not seg:
            warns.append("%s 版未找到（若本篇不发该平台，忽略）" % plat)
            continue
        n = count_chars(seg)
        lo, hi = LIMITS[plat]
        ok = lo <= n <= hi
        print("   %s: %d 字（%d-%d）%s" % (plat, n, lo, hi, "PASS" if ok else "FAIL"))
        if not ok:
            fails.append("%s %d 字，超出 skill 规格 %d-%d" % (plat, n, lo, hi))

    # ---- 2. 账号语义 + 搜索词（skill platform-traffic 第 43/211 行）----
    print("== 2. 账号语义 / 搜索词（platform-traffic：搜索占 50-65%，标题前段须埋）==")
    head = body[:400]                      # 正文前段
    titles = re.findall(r"\*\*[^\n]*?标题[^\n]*?\*\*[：:]\s*([^\n]+)", raw)
    title_blob = " ".join(titles)
    acc_hit = [k for k in cfg["account_keywords"] if k in title_blob or k in head]
    sea_hit = [k for k in cfg["search_keywords"] if k in title_blob or k in head]
    print("   账号语义命中: %s" % (acc_hit or "无"))
    print("   搜索词命中  : %s" % (sea_hit or "无"))
    if not acc_hit:
        fails.append("标题/正文前段无任何账号语义词（账号定位丢失，读者看不出你做什么）")
    if not sea_hit:
        fails.append("标题/正文前段无搜索词（违反 platform-traffic 第43 行：搜索流量 50-65%）")

    # ---- 标题抓取器（2b/2c/2e/2g 共用 · 2026-10-14 收敛）----
    # 旧版 2b 认 "\*\*标题（20 字内）\*\*："、2e 认 "小红书主：「…」" 两套格式，
    # 而 Step8-标题.md 的定稿格式是 "**小红书主：「…」**（17字）" → 2b 抓不到、2e 抓得到，
    # 同一篇稿两个检查一个生效一个跳过。收敛成一个抓取器，四个检查同源。
    def _grab_xhs_title(text):
        m = re.search(r"小红书主[：:]?\s*[「\"]([^」\"\n]+)[」\"]", text)
        if m:
            return m.group(1).strip()
        m = re.search(r"\*\*标题（20 字内）\*\*[：:]\s*([^\n]+)", text)
        return m.group(1).strip().strip("`") if m else None

    def _grab_tie_title(text):
        m = re.search(r"贴图号主[：:]?\s*[「\"]([^」\"\n]+)[」\"]", text)
        if m:
            return m.group(1).strip()
        m = re.search(r"贴图号[^\n]*?[`「]([^`」\n]+)[`」]", text)
        return m.group(1).strip() if m else None

    xhs_t = _grab_xhs_title(raw)
    tie_t = _grab_tie_title(raw)

    # ---- 2b. 小红书标题 ≤20 字（老李 2026-10-13 明确的平台硬限制）----
    print("== 2b. 小红书标题 ≤20 字（平台硬限制）==")
    if xhs_t:
        main_t = xhs_t.strip()
        n = len(re.sub(r"[\s]", "", main_t))
        ok = n <= 20
        print("   主用标题「%s」%d 字 %s" % (main_t[:24], n, "PASS" if ok else "FAIL"))
        if not ok:
            fails.append("小红书主用标题 %d 字，超过平台 20 字上限（超 %d 字）" % (n, n - 20))
    else:
        warns.append("未找到小红书标题，无法校验字数")

    # ---- 2c. 贴图号标题 ≤20 字（老李 2026-10-13 平台硬限制）----
    print("== 2c. 贴图号标题 ≤20 字（平台硬限制）==")
    if tie_t:
        main_t = tie_t.strip()
        n = len(re.sub(r"[\s]", "", main_t))
        ok = n <= 20
        print("   主用标题「%s」%d 字 %s" % (main_t[:24], n, "PASS" if ok else "FAIL"))
        if not ok:
            fails.append("贴图号主用标题 %d 字，超过平台 20 字上限（超 %d 字）" % (n, n - 20))
    else:
        warns.append("未找到贴图号标题，无法校验字数")

    # ---- 2e. 标题主位须含赛道识别词（账号定位战略：案例词降位、母题统一防变杂）----
    # 老李 2026-10-14 战略修正：标题前10字(权重最高段)必须是"AI/自媒体赛道识别词"，
    # 案例词(如C盘清理)与抽象母题词(如活成队伍)都不得占主位。
    # 🔴 修正记录（2026-10-14 下午 · 老李复盘）：旧版 2e 检查"前10字含账号魂词"，
    #    而账号魂词表里含"活成队伍"这种抽象母题 → 门禁反而鼓励了老李反对的抽象口号。
    #    改为检查"赛道识别词"(track_keywords)，与 2g(具体性) 配套。
    print("== 2e. 标题主位含赛道识别词（前10字，防案例词/抽象词占主位）==")

    if xhs_t:
        t10 = re.sub(r"[\s]", "", xhs_t)[:10]
        has_track = any(k in t10 for k in cfg["track_keywords"])
        print("   小红书标题前10字「%s」赛道识别词%s" % (t10, "命中" if has_track else "缺失"))
        if not has_track:
            fails.append("小红书标题前10字无赛道识别词（前10字须让用户一眼认出这是 AI/自媒体赛道；案例词与抽象母题词均不得占主位）")
    else:
        warns.append("未检出小红书主标题，2e 跳过")
    if tie_t:
        t10 = re.sub(r"[\s]", "", tie_t)[:10]
        has_track = any(k in t10 for k in cfg["track_keywords"])
        print("   贴图号标题前10字「%s」赛道识别词%s" % (t10, "命中" if has_track else "缺失"))
        if not has_track:
            fails.append("贴图号标题前10字无赛道识别词（前10字须让用户认出这是 AI/自媒体赛道）")
    else:
        warns.append("未检出贴图号主标题，2e 跳过")

    # ---- 2d. 贴图号正文不可嵌图（老李 2026-10-13 硬规则）----    print("== 2d. 贴图号正文不可嵌图（硬规则）==")
    tie_seg = plat_section(raw, "贴图号")
    if tie_seg:
        md_img = re.findall(r"!\[[^\]]*\]\([^)]*\)", tie_seg)
        inline_fig = re.findall(r"图[1-9一二三四五六七八九十]", tie_seg)
        bad = md_img + inline_fig
        if bad:
            fails.append("贴图号正文出现图片/内联图注（%s），违反'正文不可嵌图'硬规则" % "/".join(sorted(set(bad))[:6]))
            print("   FAIL 检出 %s" % bad[:8])
        else:
            print("   PASS 正文无内联图/图注")
    else:
        warns.append("未找到贴图号正文，跳过嵌图检查")

    # ---- 2f. 主线一致性（视觉文案须含账号主张词、不脱离正文主线）----
    # 老李 2026-10-14：封面/配图是正文派生，不得脱离主线(账号主张)。本检查把"不脱离"
    # 变成可执行判据：若文稿含「视觉文案」区块(封面大字+卡片论点)，须含账号主张词。
    # 🔴 2026-10-14 审查修正两处：
    #   ① 旧版查 account_keywords（含"活成队伍/一人公司"抽象词）→ 与 2g 黑名单打架，
    #      且等于"逼视觉文案写抽象母题"。改用 soul_signals（判断/执行等可复现主张词）。
    #   ② 旧版表里有泛化的"AI"→ 视觉文案随便写个 AI 就过，门槛形同虚设。现已剔除。
    print("== 2f. 主线一致性（视觉文案须含账号主张词）==")
    vis = re.search(r"##\s*[三四五六]、?[^\n]*(视觉文案|封面|配图|卡片)[^\n]*\n(.*?)(?=^##\s|\Z)", raw, re.S | re.M)
    vis_text = vis.group(2).strip() if vis else ""
    if vis_text:
        vis_lines = [ln.strip() for ln in vis_text.splitlines()
                     if ln.strip() and not ln.strip().startswith("#")]
        blob = " ".join(vis_lines)
        has_soul = any(k in blob for k in cfg["soul_signals"])
        print("   视觉文案账号主张词%s（%d 句）" % ("命中" if has_soul else "缺失", len(vis_lines)))
        if not has_soul:
            fails.append("视觉文案(封面/卡片)未含账号主张词（%s），可能脱离主线（账号定位战略）"
                         % "/".join(cfg["soul_signals"][:3]))
    else:
        warns.append("未检出视觉文案区块（封面/卡片文案），2f 跳过；新篇目须建「视觉文案」段并通过本检查")

    # ---- 2g. 封面/标题具体性（治"打不到具体粉丝" · content-funnel.md 入口层）----
    # 老李 2026-10-14：封面/标题不得只写抽象母题(活成队伍/放大器)，必须打中某一类
    # 具体粉丝的具体问题。判据：若含抽象母题词却无任何"具体人群词/具体问题词/数字"
    # → 谁都装得进=谁都装不进 → FAIL。这是把"打不到人"从品味问题变成可判定问题。
    print("== 2g. 封面/标题具体性（不得只写抽象母题，须打中具体人群/问题）==")
    targets = []
    if xhs_t:
        targets.append(("小红书标题", xhs_t))
    if tie_t:
        targets.append(("贴图号标题", tie_t))
    m_cov = re.search(r"封面大字[：:]\s*([^\n]+)", raw)
    if m_cov:
        targets.append(("封面大字", m_cov.group(1)))
    if not targets:
        warns.append("未检出标题/封面大字，2g 跳过")
    for name, txt in targets:
        t = re.sub(r"[\s]", "", txt)
        hits_abs = [w for w in cfg["abstract_theme_words"] if w in t]
        has_abstract = bool(hits_abs)
        # 🔴 2026-10-14 反向注入测出的漏洞：旧版在整句里找具体信号，而
        #   "一个人活成队伍"里的"一个人"正是抽象母题"活成队伍"的自带成分
        #   → 抽象口号被判"含具体人群"放行（老李亲手否过的口号从门禁溜过去）。
        #   修法：**先把命中的抽象词从文本里扣掉，再找具体信号**。
        t_wo = t
        for w in hits_abs:
            t_wo = t_wo.replace(w, "")
        has_aud = any(w in t_wo for w in cfg["audience_signals"])
        has_conc = any(w in t_wo for w in cfg["concrete_signals"]) or bool(re.search(r"\d", t_wo))
        if has_abstract and not (has_aud or has_conc):
            print("   FAIL %s「%s」抽象母题+无具体人群/数字" % (name, txt[:26]))
            fails.append("%s 只写抽象母题、无具体人群或具体问题信号（打不到具体粉丝，违反 content-funnel 入口层）：%s"
                         % (name, txt[:26]))
        else:
            print("   PASS %s「%s」%s" % (name, txt[:26],
                  "含具体信号" if (has_aud or has_conc) else "未含抽象词"))

    # ---- 2h. 零翻译成本（humanize.md 二·五 · 2026-10-14 审查新增）----
    # 老李定：封面/标题/卡片必须一眼就懂，不能被逼着"翻译"（人的天性是能不动脑就不动脑）。
    # 病因：这条铁律 10-14 已写进 humanize.md，但**门禁一直没查**（纯文档、零强制）——
    #      正是"文档约束知道、不约束代码"的老毛病。这里把它变成可执行判定。
    # ⚠️ 作用域只限"面向读者的视觉文案"（标题/封面大字/卡片），不扫正文，避免误伤。
    print("== 2h. 零翻译成本（封面/标题/卡片不得出现需翻译的黑话）==")
    t_scope = [("小红书标题", xhs_t), ("贴图号标题", tie_t)]
    if m_cov:
        t_scope.append(("封面大字", m_cov.group(1)))
    if vis_text:
        t_scope.append(("视觉文案区块", vis_text))
    tl_hits = []
    for name, txt in t_scope:
        if not txt:
            continue
        for w in cfg["translate_blacklist"]:
            if w in txt:
                tl_hits.append("%s:「%s」" % (name, w))
    if tl_hits:
        print("   FAIL 检出需翻译词 %d 处：%s" % (len(tl_hits), "；".join(tl_hits[:6])))
        fails.append("视觉文案出现需读者翻译的黑话（违反零翻译成本铁律）：%s" % "；".join(tl_hits[:6]))
    else:
        print("   PASS 无黑话（%d 处文案已查）" % len([1 for _, t in t_scope if t]))

    # ---- 3. 索取式钩禁词（skill GATE-E）----
    print("== 3. 索取式钩禁词（GATE-E：关注是结果不是手段）==")
    hits = []
    for ln in body.splitlines():
        for b in BANNED_HOOK:
            if b in ln and not any(c in ln for c in BANNED_CTX):
                hits.append(b)
    print("   %s" % ("PASS 无违规" if not hits else "FAIL 命中 %s" % sorted(set(hits))))
    if hits:
        fails.append("索取式钩命中：%s" % sorted(set(hits)))

    # ---- 4. 杜撰自引（该文不存在却说往后翻）----
    print("== 4. 杜撰自引检测（禁编造铁律）==")
    fab = []
    for ln in body.splitlines():
        for k in FABRICATED_SELF_REF:
            if k in ln and not any(c in ln for c in BANNED_CTX):
                fab.append(ln.strip()[:40])
    print("   %s" % ("PASS" if not fab else "FAIL %s" % fab))
    if fab:
        fails.append("疑似杜撰自引（该篇可能并不存在）：%s" % fab)

    # ---- 5. 结尾动作数（skill §六：结尾单一动作，>1 即返工）----
    print("== 5. 结尾动作数（§六：单一动作，>1 即返工）==")
    # 🔴 踩坑第四版：三平台正文连在一起，只看"最后 500 字"会把不同平台的结尾混算
    # （公众号版结尾 + 小红书版结尾同时落进窗口 → 误判成 2 个动作）。
    # 修法：**按平台分段，各自只看自己那一版的结尾**。
    ACTION_LINES = ("评论区", "点个关注", "转发", "收藏一下", "加我", "私信")
    for plat, pat_s, pat_e in (("公众号", r"^##\s*一、", r"^##\s*二、"),
                          ("小红书", r"^##\s*二、", r"^##\s*三、"),
                              ("贴图号", r"^##\s*三、", r"^##\s*四、")):
        seg = section(raw, pat_s, pat_e)
        if not seg:
            continue
        tail = seg[-260:]
        lines = [ln for ln in tail.splitlines()
                 if any(k in ln for k in ACTION_LINES)
                 and not any(c in ln for c in BANNED_CTX)]
        ok = len(lines) <= 1
        print("   %s结尾动作 %d 处 %s" % (plat, len(lines), "PASS" if ok else "FAIL"))
        for ln in lines:
            print("      · %s" % ln.strip()[:50])
        if not ok:
            fails.append("%s 结尾有 %d 处动作指令（规格要求 1 处）" % (plat, len(lines)))

    # ---- 6. 干货方法论存在性（治"只有故事没有可抓的价值"）----
    print("== 6. 干货方法论（老李 2026-10-13：捡了芝麻丢了西瓜）==")
    # 🔴 2026-10-14 审查 B7 修正：**与 gate_e_check.py 统一标准，消除"双标准打架"**。
    #   旧版：本脚本只要"命中 2 类方法信号"（每类命中 1 次即可），
    #         gate_e_check 却要求"迁移句 ≥3 处" → 同一篇稿，一个说 PASS、一个说 FAIL。
    #   现统一：两者都按 **迁移句 ≥3**（标准源 = reader-value-gate.md 第55-57行）。
    #   识别方式也对齐 gate_e_check：固定词 + `> **` 引用块排版（不逼作者写标签词）。
    MIG_WORDS = ["这一步能带走什么", "换个领域也成立"]
    mig = sum(body.count(w) for w in MIG_WORDS) + len(re.findall(r"^>\s+\*\*", body, re.M))
    if mig >= 3:
        print("   PASS 检出迁移句 %d 处（≥3，与 gate_e_check 同标准）" % mig)
    else:
        print("   FAIL 迁移句仅 %d 处（需 ≥3，与 gate_e_check 同标准）" % mig)
        fails.append("可迁移方法论不足（迁移句 %d 处 < 3；标准源 reader-value-gate.md 第55-57行）"
                     "——读者收藏是因为方法论，不是因为故事" % mig)

    # ---- 判定 ----
    print("\n" + "=" * 52)
    for f in fails:
        print("FAIL  %s" % f)
    for w in warns:
        print("提醒  %s" % w)
    ok = not fails
    print("=" * 52)
    print("交付判定：%s" % ("✅ PASS 可交" if ok else "❌ FAIL 不能交，必须返工"))
    if not ok:
        print("提醒：FAIL 只代表没做到 skill 明文规定，不代表文章一定不好。")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())