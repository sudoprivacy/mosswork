# -*- coding: utf-8 -*-
"""remove_watermark.py — ImageGen 平台水印处理（poster-studio 出图链路标配）

背景：ImageGen（豆包/WorkBuddy 自带 Seedream）出图右下角带"AI生成"半透明角标，
正式发布不能带平台水印。本脚本三档方案，按优先级：

  1) crop   裁底：水印在右下边缘 → background-position 下移裁掉底部（合成时一行 CSS，零成本零风险）
  2) cover  遮盖：水印区被设计元素（边框/footer/留白区）覆盖
  3) lama   LaMa ONNX 局部修复：水印在画面中部、裁不掉也盖不住时的后备
            需要：onnxruntime + numpy + Pillow + lama_fp32.onnx（208MB，hf-mirror 下载）
            量化版（fp16/int8）已实测是死路，别用——见 skills/lama-onnx-watermark-removal/SKILL.md

用法：
  python remove_watermark.py input.png output.png --mode crop --crop-bottom 6%
  python remove_watermark.py input.png output.png --mode lama --box 88,93,99,98
"""
import argparse, sys, pathlib


def crop_bottom(src, dst, ratio=0.06):
    """裁掉底部 ratio（默认 6%，覆盖右下角标）。用 PIL，不碰 cv2。"""
    from PIL import Image
    im = Image.open(src).convert("RGB")
    w, h = im.size
    cut = int(h * ratio)
    out = im.crop((0, 0, w, h - cut))
    out.save(dst)
    print(f"[crop] {src} -> {dst}（裁底 {cut}px，剩余 {out.size}）")


def fix_lama(src, dst, box):
    """LaMa ONNX 局部修复。box=(x0%,y0%,x1%,y1%) 百分比。依赖缺失时明确报错，不静默。"""
    try:
        import numpy as np, onnxruntime as ort
        from PIL import Image
    except ImportError as e:
        sys.exit(f"[lama] 缺依赖：{e}。安装：pip install onnxruntime numpy pillow；"
                 f"模型（208MB）：https://hf-mirror.com/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx")
    cache = pathlib.Path.home() / ".cache" / "poster-studio" / "lama" / "lama_fp32.onnx"
    if not cache.exists():
        sys.exit(f"[lama] 模型不在 {cache}，请从 hf-mirror 下载后放入")
    im = Image.open(src).convert("RGB")
    W, H = im.size
    x0, y0, x1, y1 = box
    bx = (int(W * x0 / 100), int(H * y0 / 100), int(W * x1 / 100), int(H * y1 / 100))
    arr = np.array(im)
    mask = np.zeros((H, W), np.uint8)
    mask[bx[1]:bx[3], bx[0]:bx[2]] = 255
    pad = 60
    cy0, cy1 = max(0, bx[1] - pad), min(H, bx[3] + pad)
    cx0, cx1 = max(0, bx[0] - pad), min(W, bx[2] + pad)
    crop = arr[cy0:cy1, cx0:cx1]
    mcrop = mask[cy0:cy1, cx0:cx1]
    ch, cw = crop.shape[:2]
    from PIL import Image as P
    LAN = P.Resampling.LANCZOS; CUB = P.Resampling.BICUBIC; NEA = P.Resampling.NEAREST
    ci = P.fromarray(crop).resize((512, 512), LAN)
    mi = P.fromarray(mcrop).resize((512, 512), NEA)
    img_in = np.array(ci).astype(np.float32).transpose(2, 0, 1)[None] / 255.0
    mask_in = (np.array(mi) > 0).astype(np.float32)[None, None]
    sess = ort.InferenceSession(str(cache), providers=["CPUExecutionProvider"])
    out = sess.run(None, {"image": img_in, "mask": mask_in})[0][0].transpose(1, 2, 0)
    out = (out * 255).clip(0, 255).astype(np.uint8) if out.max() <= 2 else out.clip(0, 255).astype(np.uint8)
    arr[cy0:cy1, cx0:cx1] = np.array(P.fromarray(out).resize((cw, ch), CUB))
    P.fromarray(arr).save(dst)
    print(f"[lama] {src} -> {dst}（修复区 {bx}）")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("src"); ap.add_argument("dst")
    ap.add_argument("--mode", choices=["crop", "lama"], default="crop")
    ap.add_argument("--crop-bottom", default="6%")
    ap.add_argument("--box", default="88,93,99,98", help="lama 模式：x0,y0,x1,y1 百分比")
    a = ap.parse_args()
    if a.mode == "crop":
        r = float(a.crop_bottom.rstrip("%")) / 100
        crop_bottom(a.src, a.dst, r)
    else:
        fix_lama(a.src, a.dst, tuple(float(v) for v in a.box.split(",")))
