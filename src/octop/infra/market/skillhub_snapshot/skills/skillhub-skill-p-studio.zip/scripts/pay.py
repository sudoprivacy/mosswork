# -*- coding: utf-8 -*-
"""poster-studio 付费门控入口（CLI · 零密钥 · X402 主通道 · 订阅制）。

agent 侧调用方式（见 SKILL.md 第 11.5 步）：
  python pay.py check   --feature cover_trial [--consume]   # 档位/试用检查：够→exit 0；不够→exit 3
  python pay.py check   --feature card_generate             # 未订阅→exit 3（带三档方案）
  python pay.py order   --feature card_generate [--plan month|quarter|year]  # 下单+出二维码：exit 2（待付款）
  python pay.py poll    --out-trade-no XXX [--watch]        # 查单；paid 自动 unlock_local 落盘
  python pay.py poll    --code WX-XXXX-XXXX                 # 已持授权码：直接激活（activate）
  python pay.py activate WX-XXXX-XXXX                       # 手动授权码激活
  python pay.py status                                      # 当前档位/到期/试用余量/数据目录

价格机制（2026-10-13 老李定）：
  - 免费：选题方向预览（topic_preview）+ 封面试做 1 次（cover_trial，本地计数）
  - 订阅：月卡 ¥49.9 / 季卡 ¥99.9 / 年卡 ¥199.9（云端 poster_month/quarter/year → tier2）
  - 订阅含全部正式功能：封面/配图出图、14 步全流程、高清后端、全部版型

设计依据（_pay_system_integration.md）：
  - 复用 C盘清理同一套 license.py + skillhub_adapter.py（同服务器/同微信商户/同 SkillHub 商户）
  - 客户端零密钥：生产走 X402（/invoke），密钥全在云端 47.82.100.165
  - 🔴 二维码必须编码 code_url（weixin://wxpay/bizpayurl?...），不是 WeixinPay-Required(UUID)
  - 查单轮询必须能续跑：pending + network_error ≠ 失败，--watch 默认 2.5s 间隔、300s 超时
  - 授权数据目录已从 AI_PC_Butler 改为 PosterStudio（license.py 内改），不与 C盘清理抢 license.json
"""
import argparse
import json
import os
import sys
import time
import uuid

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import license  # noqa: E402
import skillhub_adapter as shub  # noqa: E402

# ---------------------------------------------------------------------------
# 订阅方案（product_id 必须与云端 auth_server.py PRODUCT_TIERS/PRODUCT_PRICES 一致）
# ---------------------------------------------------------------------------
PLANS = {
    "month":   {"product_id": "poster_month",   "cents": 4990,  "name": "好内容印社·月卡", "days": 30},
    "quarter": {"product_id": "poster_quarter", "cents": 9990,  "name": "好内容印社·季卡", "days": 90},
    "year":    {"product_id": "poster_year",    "cents": 19990, "name": "好内容印社·年卡", "days": 365},
}
DEFAULT_PLAN = "month"

# 免费试用：feature -> 免费次数（软计数：本地 trial.json，防误用不防刻意绕过；
# 硬闸门是订阅档位本身 —— 试用用完还想用，必须过云端支付拿到 tier2）
TRIAL_FREE_LIMIT = {
    "cover_trial": 1,   # 封面试做免费 1 次
}


def _plans_public():
    """三档方案的对外展示结构（分→元）。"""
    return {k: {"name": v["name"], "cents": v["cents"],
                "yuan": round(v["cents"] / 100.0, 2), "days": v["days"]}
            for k, v in PLANS.items()}


def _emit(obj, code):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()
    sys.exit(code)


# ---------------------------------------------------------------------------
# 订单台账（本地留痕）+ 续费叠加 + 救单（R2/R3 · 2026-10-14）
#
# R2 最好方案（对齐 C盘清理 rescue_orders）：本地维护 orders.json 台账，
#   ① 每次下单前先救单 —— 若已有「已付款但未解锁」的订单，先把它救活，避免重复付款；
#   ② 提供 rescue 命令，手动补救「付了钱没解锁」。
# R3 提前续费：已订阅不再拦截下单；续费时长按【叠加】计算（now + 剩余秒 + 本次时长秒），
#   而不是用服务端下发的 exp 直接覆盖，避免提前续费丢失剩余天数。
# ---------------------------------------------------------------------------
def _orders_path():
    return os.path.join(license.get_data_dir(), "orders.json")


def _load_orders():
    try:
        with open(_orders_path(), "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except Exception:
        return []


def _save_orders(rows):
    p = _orders_path()
    tmp = p + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
    except Exception:
        pass


def _mark_order_done(otn):
    rows = _load_orders()
    changed = False
    for r in rows:
        if r.get("out_trade_no") == otn and r.get("status") != "done":
            r["status"] = "done"
            r["unlocked_at"] = int(time.time())
            changed = True
    if changed:
        _save_orders(rows)


def _renewal_exp(server_exp, days=None):
    """续费/升级：在现有到期时间基础上叠加本次时长，避免提前续费丢失剩余天数。

    - 已过期或从未订阅：取本次履约到期时间（server_exp，= now + 本次时长）。
    - 仍有剩余 R 天：new_exp = now + R*86400 + 本次时长秒 → 叠加，不丢天数。
    - 不给 days（无法得知时长时）：退化为 max(现有, server_exp)。
    """
    server_exp = int(server_exp or 0)
    try:
        cur = int((license.read_license().get("exp", 0) or 0))
    except Exception:
        cur = 0
    if not days:
        return max(cur, server_exp) if (cur or server_exp) else server_exp
    dur = int(days) * 86400
    remaining = max(0, cur - int(time.time())) if cur else 0
    return int(time.time()) + remaining + dur


def _fulfill_unlock(otn, feature="", plan_days=None):
    """查单 + 解锁（续费叠加）。返回 dict：{ok, status, ...}。"""
    try:
        st = shub.x402_order_status(otn)
    except Exception as e:
        return {"ok": False, "status": "pending", "network_error": True, "error": str(e)}
    status = st.get("status")
    if status != "paid":
        return {"ok": False, "status": status or "pending"}
    code = st.get("code") or ""
    if not code:
        return {"ok": False, "status": "paid_no_code",
                "error": "已支付但未取到授权码，请联系客服"}
    try:
        prev_exp = int((license.read_license().get("exp", 0) or 0))
    except Exception:
        prev_exp = 0
    exp = _renewal_exp(st.get("exp") or 0, plan_days)
    res = license.unlock_local(
        code=code, tier=st.get("tier") or None,
        signature=st.get("signature") or "",
        bound_hwid=st.get("bound_hwid") or "",
        exp=exp)
    out = {"ok": bool(res.get("ok")), "status": "paid", "unlock": res}
    if feature:
        need = license.FEATURE_MIN_TIER.get(feature, license.STANDARD_TIER)
        out["feature_ok"] = license.current_tier() >= need
    out["exp"] = exp
    out["expires_in_days"] = round((exp - time.time()) / 86400.0, 1) if exp else 0
    out["prev_expires_in_days"] = round((prev_exp - time.time()) / 86400.0, 1) if prev_exp else 0
    return out


def _rescue_before_order(feat):
    """R2 最好方案：下单前先救单 —— 若已有「已付款但未解锁」的订单，先把它救活，
    避免让用户重复付款。救到则返回 True（调用方应跳过新下单）。"""
    try:
        for row in _load_orders():
            if row.get("status") == "done":
                continue
            otn = row.get("out_trade_no")
            if not otn:
                continue
            fu = _fulfill_unlock(otn, row.get("feature", ""), row.get("days"))
            if fu.get("ok"):
                _mark_order_done(otn)
                return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# 免费试用计数（数据目录 trial.json；与 license.json 同目录，隔离于 C盘清理）
# ---------------------------------------------------------------------------
def _trial_path():
    return os.path.join(license.get_data_dir(), "trial.json")


def _trial_get(feat):
    """该 feature 已用掉的免费次数；读不到按 0。"""
    try:
        with open(_trial_path(), "r", encoding="utf-8") as f:
            d = json.load(f)
        return int((d.get(feat, 0) or 0)) if isinstance(d, dict) else 0
    except Exception:
        return 0


def _trial_consume(feat, limit):
    """消耗 1 次免费试用（未超限才记）；返回消耗后的已用次数。写入失败不抛（软计数）。"""
    used = _trial_get(feat)
    if used >= limit:
        return used
    used += 1
    p = _trial_path()
    try:
        d = {}
        try:
            with open(p, "r", encoding="utf-8") as f:
                _old = json.load(f)
            if isinstance(_old, dict):
                d = _old
        except Exception:
            pass
        d[feat] = used
        d["updated_at"] = int(time.time())
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
    except Exception:
        pass
    return used


def _trial_status():
    out = {}
    for feat, lim in TRIAL_FREE_LIMIT.items():
        used = _trial_get(feat)
        out[feat] = {"used": used, "limit": lim, "remaining": max(0, lim - used)}
    return out


def _render_qr(code_url, out_dir):
    """code_url → SVG + PNG（qrcode  vendored 纯 Python SVG；PNG 走 Playwright，失败不阻断）。"""
    from qrcode import QRCode, ERROR_CORRECT_M, SvgImage
    os.makedirs(out_dir, exist_ok=True)
    svg_path = os.path.join(out_dir, "pay_qr.svg")
    qr = QRCode(error_correction=ERROR_CORRECT_M, border=2)
    qr.add_data(code_url)
    qr.make(fit=True)
    img = qr.make_image(image_factory=SvgImage)
    img.save(svg_path)
    png_path = os.path.join(out_dir, "pay_qr.png")
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_page(viewport={"width": 520, "height": 640})
            pg.goto("file://" + os.path.abspath(svg_path).replace("\\", "/"))
            pg.screenshot(path=png_path)
            pg.close()
            b.close()
    except Exception as e:
        png_path = ""
        sys.stderr.write("[pay] PNG 渲染不可用（仅 SVG）：%s\n" % e)
    return svg_path, png_path


def cmd_check(a):
    feat = a.feature
    need = license.FEATURE_MIN_TIER.get(feat, license.STANDARD_TIER)
    cur = license.current_tier()

    # ① 免费试用特性（cover_trial）：不占档位，按次数闸门，先于档位判断
    #    （它的 need 是 FREE_TIER，若走下面的档位比较会恒真，永远放行）
    if feat in TRIAL_FREE_LIMIT:
        limit = TRIAL_FREE_LIMIT[feat]
        used_before = _trial_get(feat)
        if used_before >= limit:
            _emit({"ok": False, "feature": feat, "tier": cur,
                   "trial_used": used_before, "trial_limit": limit,
                   "reason": "免费试用已用完",
                   "plans": _plans_public(),
                   "next": "python pay.py order --feature %s --plan month|quarter|year" % feat}, 3)
        used = _trial_consume(feat, limit) if a.consume else used_before
        _emit({"ok": True, "feature": feat, "tier": cur, "trial": True,
               "trial_used": used, "trial_limit": limit,
               "trial_remaining": limit - used}, 0)

    # ② 常规档位检查
    if cur >= need:
        _emit({"ok": True, "tier": cur, "tier_name": license.TIER_NAME.get(cur, "?"),
               "feature": feat}, 0)
    _emit({"ok": False, "tier": cur, "feature": feat, "need_tier": need,
           "need_tier_name": license.TIER_NAME.get(need, "?"),
           "reason": "需要订阅",
           "plans": _plans_public(),
           "next": "python pay.py order --feature %s --plan month|quarter|year" % feat}, 3)


def cmd_order(a):
    feat = a.feature
    need = license.FEATURE_MIN_TIER.get(feat, license.STANDARD_TIER)
    cur = license.current_tier()

    # R2 最好方案：下单前先救单，避免「已付款未解锁」被二次扣款
    if _rescue_before_order(feat):
        exp = int((license.read_license().get("exp", 0) or 0))
        out = {"ok": True, "paid": True, "rescued": True,
               "tier": cur, "tier_name": license.TIER_NAME.get(cur, "?"),
               "note": "检测到您此前已支付的订单，已自动解锁，无需重复付款",
               "next": "python pay.py status"}
        if exp:
            out["expires_in_days"] = round((exp - time.time()) / 86400.0, 1)
        _emit(out, 0)

    # 免费试用还剩：提示先用试用（不拦截订阅，仅提示）
    if feat in TRIAL_FREE_LIMIT:
        used = _trial_get(feat)
        if used < TRIAL_FREE_LIMIT[feat]:
            _emit({"ok": True, "trial": True, "paid": False,
                   "trial_remaining": TRIAL_FREE_LIMIT[feat] - used,
                   "note": "免费试用还剩 %d 次，无需下单（试用请配合 check --consume 计数）"
                           % (TRIAL_FREE_LIMIT[feat] - used)}, 0)

    plan_key = (a.plan or DEFAULT_PLAN).strip().lower()
    plan = PLANS.get(plan_key)
    if not plan:
        _emit({"ok": False, "stage": "order",
               "error": "未知订阅方案 %r，可选：%s" % (plan_key, "/".join(PLANS))}, 4)
    pid = plan["product_id"]
    hwid = license.get_hwid()
    order_id = uuid.uuid4().hex
    # product 里的 tier/fee_cents 只是展示提示；云端按 product_id 权威定价（PRODUCT_PRICES）
    product = {"tier": license.PRO_TIER, "fee_cents": plan["cents"],
               "name": plan["name"], "product_id": pid}
    try:
        od = shub.create_order(product, hwid, "https://localhost", order_id, product_id=pid)
    except Exception as e:
        _emit({"ok": False, "stage": "create_order", "error": str(e)}, 4)
    code_url = od.get("code_url") or ""
    out = {"ok": True, "stage": "order", "feature": feat, "plan": plan_key,
           "plan_name": plan["name"], "product_id": pid,
           "out_trade_no": od.get("out_trade_no"),
           "order_id": od.get("order_id"), "amount": od.get("amount"),
           "price_hint_cents": plan["cents"], "duration_days": plan["days"],
           "mode": od.get("mode")}
    # R3 提前续费：已订阅不再拦截，改为提示剩余天数（续费会叠加到现有到期之后）
    if feat not in TRIAL_FREE_LIMIT and cur >= need:
        exp = int((license.read_license().get("exp", 0) or 0))
        remain = round((exp - time.time()) / 86400.0, 1) if exp else 0
        out["renewal"] = True
        out["remaining_days_before"] = remain
        out["note"] = ("您当前已订阅（剩余约 %s 天）；本次为提前续费，时长将叠加到现有到期时间之后，"
                       "不丢剩余天数。" % remain)
    # 🔴 验收铁律：给用户扫的码必须是 code_url（weixin:// 开头）
    if code_url.startswith("weixin://"):
        out_dir = a.out or os.path.join(os.getcwd(), "pay_qr")
        svg_path, png_path = _render_qr(code_url, out_dir)
        out.update({"qr_svg": svg_path, "qr_png": png_path, "qr_is_code_url": True})
    else:
        # 商户未回 code_url：把对话内支付码（WeixinPay-Required）交回 agent 弹支付卡片
        out.update({"qr_is_code_url": False,
                    "payment_code": od.get("payment_code"),
                    "hint": "商户未返回 code_url，请用对话内 weixinpay_pay 工具弹支付卡片"})
    # 写入订单台账（R2：本地留痕，供救单/防重复付款）
    try:
        rows = _load_orders()
        rows.append({"out_trade_no": od.get("out_trade_no"), "order_id": order_id,
                     "product_id": pid, "plan": plan_key, "days": plan["days"],
                     "feature": feat, "created": int(time.time()), "status": "pending"})
        _save_orders(rows)
    except Exception:
        pass
    _emit(out, 2)


def cmd_poll(a):
    if a.code:
        res = license.activate(a.code)
        _emit({"stage": "activate", **res}, 0 if res.get("ok") else 5)
    otn = a.out_trade_no
    if not otn:
        _emit({"stage": "poll", "error": "缺 --out-trade-no（或 --code）"}, 4)
    # 从订单台账取本次方案时长，用于续费叠加
    plan_days = None
    for row in _load_orders():
        if row.get("out_trade_no") == otn and row.get("days"):
            plan_days = row["days"]
            break
    deadline = time.time() + (a.timeout if a.watch else 0)
    while True:
        fu = _fulfill_unlock(otn, a.feature, plan_days)
        if fu.get("ok"):
            _mark_order_done(otn)
            _emit({"stage": "poll", **fu}, 0)
        if fu.get("status") == "paid" and not fu.get("ok"):
            # 已付款但解锁失败（如签名不符）：不再空转，直接报错退出
            _emit({"stage": "poll", **fu,
                   "error": fu.get("error") or "已付款但解锁失败，请联系客服"}, 5)
        if not a.watch or time.time() >= deadline:
            _emit({"stage": "poll", "status": fu.get("status", "pending"),
                   "network_error": fu.get("network_error", False),
                   "error": fu.get("error", "")}, 6)
        time.sleep(2.5)


def cmd_activate(a):
    res = license.activate(a.code)
    _emit({"stage": "activate", **res}, 0 if res.get("ok") else 5)


def cmd_rescue(a):
    """救单（R2 最好方案）：把所有「未解锁」订单逐一拿去服务端确认，查到已付就当场解锁；
    续费时长按叠加规则计算（不丢剩余天数）。下单前也会自动跑这个。"""
    rows = [r for r in _load_orders() if r.get("status") != "done"]
    res = {"stage": "rescue", "checked": 0, "rescued": [], "still_pending": 0,
           "failed": []}
    for row in rows:
        res["checked"] += 1
        otn = row.get("out_trade_no")
        if not otn:
            res["failed"].append({"out_trade_no": otn, "error": "缺 out_trade_no"})
            continue
        try:
            fu = _fulfill_unlock(otn, row.get("feature", ""), row.get("days"))
        except Exception as e:
            res["failed"].append({"out_trade_no": otn, "error": str(e)})
            continue
        if fu.get("ok"):
            res["rescued"].append({"out_trade_no": otn,
                                   "product_id": row.get("product_id"),
                                   "expires_in_days": fu.get("expires_in_days")})
            _mark_order_done(otn)
        elif fu.get("status") == "paid_no_code":
            res["failed"].append({"out_trade_no": otn,
                                  "error": "已支付但未取到授权码，请联系客服"})
        elif fu.get("status") == "paid":
            res["failed"].append({"out_trade_no": otn,
                                  "error": fu.get("error") or "已付款但激活失败"})
        else:
            res["still_pending"] += 1
    res["ok"] = (res["checked"] == 0) or bool(res["rescued"]) or (not res["failed"])
    _emit(res, 0 if not res["failed"] else 5)


def cmd_status(a):
    cur = license.current_tier()
    d = license.read_license()
    out = {"stage": "status", "tier": cur, "tier_name": license.TIER_NAME.get(cur, "?"),
           "data_dir": license.get_data_dir(), "hwid": license.get_hwid(),
           "trials": _trial_status(), "plans": _plans_public()}
    exp = int(d.get("exp", 0) or 0)
    if exp:
        out["exp"] = exp
        out["expires_in_days"] = round((exp - time.time()) / 86400.0, 1)
        out["expired"] = bool(time.time() > exp)
    _emit(out, 0)


def main():
    ap = argparse.ArgumentParser(description="poster-studio 付费门控入口（订阅制）")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("check", help="档位/免费试用检查")
    sp.add_argument("--feature", required=True)
    sp.add_argument("--consume", action="store_true",
                    help="消耗 1 次免费试用（仅 cover_trial 等试用特性有意义）")
    sp = sub.add_parser("order", help="订阅下单+出二维码")
    sp.add_argument("--feature", required=True)
    sp.add_argument("--plan", default=DEFAULT_PLAN,
                    help="订阅方案：month(¥49.9)/quarter(¥99.9)/year(¥199.9)，默认 month")
    sp.add_argument("--out", default="", help="二维码输出目录（默认 ./pay_qr）")
    sp = sub.add_parser("poll", help="查单/激活")
    sp.add_argument("--out-trade-no", default="")
    sp.add_argument("--code", default="", help="已持授权码时直接激活（跳过查单）")
    sp.add_argument("--feature", default="", help="paid 后顺带校验该功能是否已解锁")
    sp.add_argument("--watch", action="store_true", help="持续轮询直到 paid/超时")
    sp.add_argument("--timeout", type=int, default=300)
    sp = sub.add_parser("activate", help="手动授权码激活")
    sp.add_argument("code")
    sub.add_parser("rescue", help="救单：解锁已付款但未解锁的订单")
    sub.add_parser("status", help="当前档位/到期/试用余量")
    a = ap.parse_args()
    {"check": cmd_check, "order": cmd_order, "poll": cmd_poll,
     "activate": cmd_activate, "rescue": cmd_rescue, "status": cmd_status}[a.cmd](a)


if __name__ == "__main__":
    main()
