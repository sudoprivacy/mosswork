# -*- coding: utf-8 -*-
"""强制产物清单检查 · 防跳过门禁（Pre-flight Artifact Check）。

为什么必须存在（2026-10-14 审查）：
  SKILL.md 防跳过铁律第 1 条写着"开始下一步前先确认上一步产物已存在"，
  第 12 步写着"对照强制产物清单核验"——**但这份清单过去根本不存在**（幽灵引用），
  且"确认产物存在"全靠人工，多轮之后必然漏。本脚本把"产物齐不齐"变成可执行判定。

配套文档：references/mandatory-artifacts.md

用法：
    python scripts/check_artifacts.py <任务工作目录> [--mode full|single]

    --mode full   （默认）内容号完整流水线（第 1–14 步）
    --mode single 单图渠道（电商/活动/影视），跳过标题/正文/配图

判据：按**文件名关键词模糊匹配**（不锁死目录编号——各次运行目录编号不统一）。
退出码：0 = 产物齐；1 = 有缺失，不许发布 / 不许进入下一步。
"""
import argparse
import os
import sys

IMG_EXT = (".png", ".jpg", ".jpeg", ".webp")

# (产物名, [关键词...任意命中即算存在], 是否图片)
FULL_REQUIRED = [
    ("需求简报",        ["需求简报", "需求"], False),
    ("选题研究卡",      ["选题研究卡", "选题研究"], False),
    ("事实台账",        ["事实台账", "台账"], False),
    ("找魂产物",        ["找魂"], False),
    ("策略/论点蓝图",   ["策略", "论点", "蓝图"], False),
    ("爆款对照表",      ["爆款", "对照", "压测"], False),
    ("标题定稿",        ["step8", "标题"], False),
    ("正文定稿",        ["step9", "正文"], False),
    ("GATE-E 自检表",   ["读者价值", "gate-e", "gate_e", "三维度", "落点"], False),
    ("封面成图",        ["cover", "封面"], True),
    ("配图卡片",        ["card"], True),
    ("质检报告",        ["质检"], False),
    ("发布清单",        ["发布清单", "发布"], False),
]

SINGLE_REQUIRED = [
    ("需求简报",        ["需求简报", "需求"], False),
    ("找魂产物",        ["找魂"], False),
    ("封面成图",        ["cover", "封面"], True),
    ("质检报告",        ["质检"], False),
    ("发布清单",        ["发布清单", "发布"], False),
]


def collect(root):
    files = []
    for dirpath, _dirs, names in os.walk(root):
        for n in names:
            files.append((n, os.path.join(dirpath, n)))
    return files


def main():
    ap = argparse.ArgumentParser(description="强制产物清单检查（跑不过不许发布）")
    ap.add_argument("workdir", help="任务工作目录（如 poster-studio-run-xxx）")
    ap.add_argument("--mode", choices=["full", "single"], default="full")
    args = ap.parse_args()

    if not os.path.isdir(args.workdir):
        print("目录不存在：%s" % args.workdir)
        return 1

    required = FULL_REQUIRED if args.mode == "full" else SINGLE_REQUIRED
    files = collect(args.workdir)
    print("强制产物检查：%s（mode=%s，共 %d 个文件）" % (args.workdir, args.mode, len(files)))
    print("-" * 56)

    missing = []
    for label, keys, need_img in required:
        hit = None
        for name, path in files:
            low = name.lower()
            if any(k.lower() in low for k in keys):
                if need_img and not low.endswith(IMG_EXT):
                    continue
                hit = path
                break
        if hit:
            print("  OK   %-14s %s" % (label, os.path.relpath(hit, args.workdir)))
        else:
            print("  缺失 %-14s （关键词：%s）" % (label, "/".join(keys)))
            missing.append(label)

    print("-" * 56)
    if missing:
        print("产物缺失 %d 项：%s" % (len(missing), "、".join(missing)))
        print("判定：❌ 产物不齐，不许进入下一步 / 不许发布（防跳过铁律第 1、3 条）")
        return 1
    print("判定：✅ 产物齐全")
    return 0


if __name__ == "__main__":
    sys.exit(main())
