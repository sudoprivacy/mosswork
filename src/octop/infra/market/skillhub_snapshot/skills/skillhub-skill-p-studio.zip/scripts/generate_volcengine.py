#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Poster Studio —— 火山引擎 Seedream 独立出图脚本（可商用后端）
普通电脑即可运行：无需 GPU、不依赖豆包环境，只发网络请求。

【准备】
  1) 安装依赖：   pip install openai
  2) 设置 API Key（火山方舟控制台获取）：
       PowerShell（仅当前窗口有效）：  $env:ARK_API_KEY="你的APIKey"
       CMD：                           set ARK_API_KEY=你的APIKey
       macOS/Linux：                   export ARK_API_KEY=你的APIKey
  3) 若模型 ID 不同，可设置环境变量 ARK_MODEL 覆盖默认值。

【用法示例】
  python generate_volcengine.py --scene ecommerce --prompt "……完整提示词……"
  python generate_volcengine.py --scene xiaohongshu --prompt-file prompt.txt --n 3
  python generate_volcengine.py --scene movie --prompt "……" --size 1664x2496

出图后请按 SKILL.md 的质量清单逐张核对文字；有错字用修正后的提示词重跑。
"""

import os
import sys
import argparse
import datetime
from urllib.request import urlopen

try:
    from openai import OpenAI
except ImportError:
    sys.exit("缺少依赖，请先运行：pip install openai")

# ===== 基础配置（一般无需修改）=====
BASE_URL = "https://ark.cn-beijing.volces.com/api/v3"
MODEL = os.getenv("ARK_MODEL", "doubao-seedream-5-0-260128")  # 以控制台“模型列表”实际 ID 为准

# 各场景推荐像素（2K，宽x高）
SCENE_SIZES = {
    "ecommerce": "2048x2048",    # 电商 1:1
    "event": "1728x2304",        # 活动 3:4
    "movie": "1664x2496",        # 影视 2:3
    "xiaohongshu": "1728x2304",  # 小红书 3:4
    "wechat": "2048x872",        # 公众号 2.35:1
}


def build_client():
    api_key = os.getenv("ARK_API_KEY")
    if not api_key:
        sys.exit("未找到 ARK_API_KEY，请按脚本顶部说明设置后重试。")
    return OpenAI(base_url=BASE_URL, api_key=api_key)


def generate_once(client, prompt, size):
    resp = client.images.generate(
        model=MODEL,
        prompt=prompt,
        size=size,
        output_format="png",
        response_format="url",
        extra_body={"watermark": False},
    )
    return resp.data[0].url


def save_image(url, out_dir, scene, idx):
    ts = datetime.datetime.now().strftime("%Y%m%d")
    path = os.path.join(out_dir, f"{scene}_{ts}_{idx}.png")
    with urlopen(url) as r, open(path, "wb") as f:
        f.write(r.read())
    return path


def main():
    ap = argparse.ArgumentParser(description="火山引擎 Seedream 海报独立出图（可商用）")
    ap.add_argument("--scene", required=True, choices=list(SCENE_SIZES), help="海报场景")
    ap.add_argument("--prompt", help="完整提示词（与 --prompt-file 二选一）")
    ap.add_argument("--prompt-file", help="从文本文件读取完整提示词（UTF-8）")
    ap.add_argument("--size", help="自定义像素，如 2048x2048，覆盖场景默认值")
    ap.add_argument("--n", type=int, default=2, help="候选数量，默认 2")
    ap.add_argument("--out", default="output", help="输出目录，默认 output")
    args = ap.parse_args()

    if args.prompt_file:
        with open(args.prompt_file, encoding="utf-8") as f:
            prompt = f.read().strip()
    elif args.prompt:
        prompt = args.prompt
    else:
        sys.exit("请用 --prompt 或 --prompt-file 提供完整提示词。")

    size = args.size or SCENE_SIZES[args.scene]
    os.makedirs(args.out, exist_ok=True)
    client = build_client()

    for i in range(1, args.n + 1):
        try:
            url = generate_once(client, prompt, size)
            path = save_image(url, args.out, args.scene, i)
            print(f"[OK]   第{i}张 -> {path}")
        except Exception as e:
            print(f"[FAIL] 第{i}张 出错：{e}")


if __name__ == "__main__":
    main()
