# -*- coding: utf-8 -*-
"""来源与数据核验 · 拦"编造"（Source & Data Verification）。

为什么必须存在（2026-10-14 审查 · C1/C2）：
  GATE-A 要求"每条结论附可点击来源 URL"，GATE-D 要求"3–5 个真实爆款 + 真实赞藏评 + 来源链接"，
  但**过去没有任何机器检查**——全靠 AI 自觉。而 AI 完全可以编 URL、编数据，没人能发现。
  实测：Post 03 的"爆款对照表"里**一条真实爆款数据都没有**（全换成了写作手法论述），
  却一路过了关——这就是"无检查"的后果。

本脚本把"来源与数据"变成可执行判定。

用法：
    python scripts/verify_sources.py <事实台账.md> [<爆款对照表.md> ...]
    python scripts/verify_sources.py <任务工作目录>        # 自动找上述两类文件
    选项：--check-url / --no-url （默认开 HTTP 抽检）  --timeout 8

判据：
  【硬 FAIL】
    1. 出现"来源"字样但该行没有 http 链接（= 说有来源却没给）；
    2. URL 格式非法（如 http:// 后面为空、域名无点）；
    3. GATE-D 爆款条数 < 3（要求 3–5）；
    4. GATE-D 没有任何赞/藏/评数字（= 空数据，禁止过关）；
    5. HTTP 抽检：URL ≥ 2 个但可达率 < 50%（大概率是编的）。
  【软提醒】（不判 FAIL，避免反爬误杀）
    - 单个 URL 不可达（可能是反爬/已失效），提示人工复核。

退出码：0 = 通过；1 = 有硬伤，不能过 GATE-A / GATE-D。
"""
import argparse
import os
import re
import sys
import urllib.request

URL_RE = re.compile(r"https?://[^\s\)\|，,、；;]+")
DOMAIN_OK = re.compile(r"^https?://[A-Za-z0-9.-]+\.[A-Za-z]{2,}(:\d+)?(/.*)?$")
# 裸域名（无 http 前缀）——不算"可点击 URL"（research-gate 要求可点击），单独提示
# 注意：TLD 列表不含 html/htm（否则会把 index.html 误判为域名）；路径里的 .html 由尾部捕获
BARE_DOMAIN_RE = re.compile(
    r"(?<![A-Za-z0-9./-])([A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.(?:com|cn|net|org|io|co|xyz|top|cc|me|tv)"
    r"(?:/[^\s\)\|，,、；;]*)?)")
# 爆款数据：赞/收藏/评论/转发 + 数字（支持 1.2w / 3千 / 3.4万）
NUM_SIGNALS = ["赞", "收藏", "评论", "转发", "藏", "评", "转"]
QMETRIC_RE = re.compile(r"(\d+(?:\.\d+)?)\s*[wW万kK千]?")
# 表头行特征（含列名，不是数据）——用于排除误判
HEADER_HINT = ("编号", "事实", "来源 URL", "可否入正文", "维度", "要求", "过？", "手法")


def find_files(workdir):
    """在目录里自动找事实台账 / 爆款对照表。"""
    ledger, bench = [], []
    for dp, _d, names in os.walk(workdir):
        for n in names:
            if not n.endswith(".md"):
                continue
            low = n.lower()
            if "台账" in n or "fact" in low:
                ledger.append(os.path.join(dp, n))
            if "爆款" in n or "benchmark" in low or "压测" in n:
                bench.append(os.path.join(dp, n))
    return ledger, bench


def check_urls(text, do_http, timeout):
    """返回 (urls, bad_format, unreachable)。"""
    urls = URL_RE.findall(text)
    bad_format = [u for u in urls if not DOMAIN_OK.match(u)]
    unreachable = []
    if do_http:
        for u in urls:
            if u in bad_format:
                continue
            try:
                req = urllib.request.Request(u, method="HEAD",
                                             headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=timeout):
                    pass
            except Exception as e:
                unreachable.append((u, str(e)[:60]))
    return urls, bad_format, unreachable


def count_bench_rows(text):
    """数"真实爆款数据行"。

    判据两层（2026-10-14 修：旧版只认"行内同时有赞+数字"，而**真实爆款表的表头写'赞/藏/评'、
    数据行只有纯数字** → 合规稿被误杀；同时 Post 03 那种"互动权重 赞1藏1评4"说明行会被算成数据）。
    ① 优先：定位表头含"赞"的表格 → 数它分隔行之后的数据行（有 ≥2 个数字即算一条）；
    ② 降级：无此类表头时，按"行内含赞/藏/评字样 + 数字"计（覆盖非表格写法）。
    """
    lines = text.splitlines()
    n = 0
    i = 0
    found_header = False
    while i < len(lines):
        ln = lines[i].strip()
        if ln.startswith("|") and "赞" in ln and ("藏" in ln or "评" in ln):
            found_header = True
            j = i + 1
            while j < len(lines) and re.match(r"^\|[\s\-:|]+\|$", lines[j].strip()):
                j += 1
            while j < len(lines) and lines[j].strip().startswith("|"):
                row = lines[j]
                nums = [x for x in QMETRIC_RE.findall(row) if x]
                if len(nums) >= 2:
                    n += 1
                j += 1
            i = j
            continue
        i += 1
    if found_header:
        return n
    # 降级
    for ln in lines:
        if any(k in ln for k in NUM_SIGNALS) and QMETRIC_RE.search(ln):
            if not any(h in ln for h in HEADER_HINT):
                n += 1
    return n


def main():
    ap = argparse.ArgumentParser(description="来源与数据核验（拦编造）")
    ap.add_argument("targets", nargs="+", help="文件或目录")
    ap.add_argument("--check-url", dest="url", action="store_true", default=True)
    ap.add_argument("--no-url", dest="url", action="store_false")
    ap.add_argument("--timeout", type=int, default=8)
    args = ap.parse_args()

    ledger_files, bench_files = [], []
    for t in args.targets:
        if os.path.isdir(t):
            l, b = find_files(t)
            ledger_files += l
            bench_files += b
        else:
            low = os.path.basename(t).lower()
            if "爆款" in t or "benchmark" in low or "压测" in t:
                bench_files.append(t)
            else:
                ledger_files.append(t)

    fails, warns = [], []
    print("来源与数据核验（拦编造）")
    print("=" * 56)

    # ---- A. 事实台账：来源 URL ----
    print("【A】GATE-A 事实台账 · 来源 URL")
    all_urls = []
    for f in ledger_files:
        text = open(f, encoding="utf-8").read()
        urls, bad, unreach = check_urls(text, args.url, args.timeout)
        all_urls += urls
        bare = [b for b in BARE_DOMAIN_RE.findall(text) if b not in urls]
        print("  %s：URL %d 个 | 裸域名 %d 个" % (os.path.basename(f), len(urls), len(bare)))
        if bad:
            fails.append("%s URL 格式非法：%s" % (os.path.basename(f), bad[:3]))
            print("     FAIL 格式非法：%s" % bad[:3])
        # 硬伤：可点击 URL 数为 0（无论有没有裸域名）
        if len(urls) == 0:
            if bare:
                fails.append("%s 无任何可点击 URL（只有裸域名 %s…）；research-gate 要求"
                             "'可点击来源 URL'，裸域名不算，请补 http(s):// 前缀"
                             % (os.path.basename(f), bare[:2]))
                print("     FAIL 只有裸域名、无可点击 URL：%s" % bare[:3])
            else:
                warns.append("%s 未检出来源 URL（GATE-A 产物应含可点击来源）" % os.path.basename(f))
        for u, err in unreach:
            warns.append("不可达（可能反爬/失效，请人工复核）：%s" % u)
    if not ledger_files:
        warns.append("未找到事实台账（GATE-A 产物），跳过 A 段")
        print("  （未找到台账文件）")

    # ---- B. 爆款对照表：真实数据 ----
    print("【B】GATE-D 爆款对照表 · 真实爆款与数据")
    if not bench_files:
        warns.append("未找到爆款对照表（GATE-D 产物），跳过 B 段")
        print("  （未找到爆款对照表）")
    for f in bench_files:
        text = open(f, encoding="utf-8").read()
        urls, _bad, _u = check_urls(text, False, args.timeout)
        all_urls += urls
        n_data = count_bench_rows(text)
        print("  %s：真实爆款数据行 %d，URL %d 个" % (os.path.basename(f), n_data, len(urls)))
        if n_data < 3:
            fails.append("%s 真实爆款数据不足（%d < 3）："
                         "GATE-D 要求 3–5 个真实爆款 + 真实赞藏评，空数据/编造不准过"
                         % (os.path.basename(f), n_data))
            print("     FAIL 真实爆款数据行不足 3（要求 3–5 个真实爆款）")
        if len(urls) == 0:
            fails.append("%s 无任何来源链接（GATE-D 要求附来源链接）" % os.path.basename(f))
            print("     FAIL 无来源链接")

    # ---- C. HTTP 抽检总评 ----
    print("【C】HTTP 可达性抽检（%s）" % ("开" if args.url else "关"))
    uniq = sorted(set(all_urls))
    if args.url and len(uniq) >= 2:
        ok, bad_urls = 0, []
        for u in uniq:
            if not DOMAIN_OK.match(u):
                continue
            try:
                req = urllib.request.Request(u, method="HEAD",
                                             headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=args.timeout):
                    ok += 1
            except Exception:
                bad_urls.append(u)
        total = len([u for u in uniq if DOMAIN_OK.match(u)])
        rate = (ok / total * 100) if total else 100
        print("  可达 %d/%d（%.0f%%）" % (ok, total, rate))
        if total and rate < 50:
            fails.append("来源 URL 可达率仅 %.0f%%（<50%%）：大概率编造，必须人工复核" % rate)
    elif args.url:
        print("  URL 少于 2 个，跳过成功率判定（已在 A/B 段各自校验）")

    # ---- 判定 ----
    print("=" * 56)
    for w in warns:
        print("提醒  %s" % w)
    for f in fails:
        print("FAIL  %s" % f)
    ok_all = not fails
    print("判定：%s" % ("✅ 来源与数据通过" if ok_all else "❌ 有编造风险，不能过 GATE-A / GATE-D"))
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
