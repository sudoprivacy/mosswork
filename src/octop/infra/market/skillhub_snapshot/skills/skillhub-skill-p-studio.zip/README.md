# Poster Studio · 商用海报与内容工坊

对标开源 PosterCraft（论文文字准确率 0.735）。核心理念：**审美是及格线，「找魂」才是分水岭**——Skill 主动采访引导创作者，在同质化方向上找到"放大你/找回你自己"的独到魂，再围绕魂备料、过爆款标准、最后呈现。采用**14 步关卡制（四道 GATE、每步强制准出产物、禁止跳步）**，普通电脑可运行、可商用。可产出**单张海报**，也可产出内容号的**完整内容（封面+配图+标题+正文+标签）**：封面靓、内容干、标题搜得到，并含多个真实哇喔时刻。

## 支持渠道（6 类）
- **单图视觉**：电商促销主图 · 活动/演出海报 · 影视感海报。
- **内容号（全套）**：小红书 · 微信贴图号（"小绿书"）· 公众号。

## 两种用法

### 起步就读这一份
`SKILL.md` 里有一节「阅读路径（分层）」——**不用读完 28 份 references**，
跟着 14 步走、每步读它点名的那 1–2 份即可。门禁脚本不读文档也会拦你，标准一分不少。

### 阶段 1：零配置（默认）
豆包环境中直接让 Agent 用内置 Seedream 出图/出内容，无需 Key、无需安装。

### 阶段 2：独立商用
1. 火山方舟控制台开通 Seedream 并创建 API Key。
2. `pip install openai`，设置环境变量 `ARK_API_KEY`。
3. 运行：
   ```
   python scripts/generate_volcengine.py --scene ecommerce --prompt "完整提示词" --n 3
   ```
   普通电脑即可、无需 GPU；生成内容按火山引擎服务协议使用。

## 目录
- `SKILL.md`：主入口与规则（先读它）。
- `references/creator-intake.md`：创作者引导引擎（Skill 主动采访）。
- `references/research-gate.md`：GATE-A 选题研究证据门禁（痛点时效性一票否决）。
- `references/topic-gating.md`：选题把关（评估·纠偏·替代选题）。
- `references/find-the-core.md`：GATE-C 找魂引擎（6镜头·魂三层·四尺子）。
- `references/strategy.md`：受众与内容策略。
- `references/content-depth.md`：挖底层弹药库（五层本质·哇喔）。
- `references/content-core.md`：GATE-B 围绕魂反推论点素材（空话检查·图序）。
- `references/benchmark-test.md`：GATE-D 爆款压力测试（市场标准对照）。
- `references/content-assembly.md`：四件套使命·标题·发布联动。
- `references/writing-styles.md`：正文写法库（选题×写法×留人矩阵）。
- `references/humanize.md`：人味引擎（去AI腔·六个开关·情感曲线）。
- `references/card-layouts.md`：配图排版版型库（层次·视觉引导）。
- `references/slogan-hooks.md`：钩子广告语引擎（金枪大叔方法论）。
- `references/aesthetics.md`：审美惊艳七要素。
- `references/brand-kit.md`：账号品牌资产；`compliance.md`：商用合规；`review-loop.md`：数据复盘闭环。
- `references/`：prompt-engineering、quality-gate（四维质检+合规）、workflow，及 ecommerce/wechat/xiaohongshu/tietu/movie/event 六类渠道规格、backend_base/doubao_builtin/volcengine_api/workbuddy_imagegen 四个出图后端。
- `scripts/`：火山 API 出图（generate_volcengine.py）、render_cards 图文卡片出图、支付与授权等。
- `templates/`：六类渠道模板 + `card-template.html` 图文卡片样板。
- ⚠️ **本 skill 不含图片文件**（上架要求）。需要参考标杆/样张时，用 `xhs-cover-survey` 运行时实采到任务工作目录，用完即弃（见 `references/reference-benchmarks.md`）。

## 安装为可复用 Skill
把整个 `poster-studio` 文件夹放到 Skill 根目录（如 `.user_skills/` 或 `DoubaoWork/skills/`），重启/刷新后即可被识别调用。

## 上架打包（`scripts/pack_skill.py`）
上架前跑一条命令生成干净包（**自动排除图片 / `__pycache__` / `_cloud/` 云端脚本 / `.bak` 备份**）：
```bash
python scripts/pack_skill.py                 # 打包到 ../poster-studio-skill.zip
python scripts/pack_skill.py --check-only    # 只检查包里有没有不该带的东西（rc=1 = 不干净）
```
⚠️ 硬约束：**上架包不含任何图片**（老李 2026-10-14 定）。需要参考标杆时**运行时实采到任务工作目录、用完即弃**，
见 `references/reference-benchmarks.md`。打包脚本把这条约束写进了代码，不靠记性。

## 商用合规提醒
- 正式商用建议走火山引擎 API，并以其最新服务协议中生成内容条款为准。
- 第三方字体、图库、Logo、肖像、商标需各自授权；价格/时间/活动名由客户提供并核实。
- 本 Skill 不使用 PosterCraft / FLUX.1-dev 的非商用权重。
