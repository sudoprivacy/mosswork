# 后端三：WorkBuddy ImageGen（惊艳底图 + 图生图精修）

## 说明

在 WorkBuddy 环境下，用内置 `ImageGen` 工具承担两件事：
1. **惊艳主视觉**（无字底图）：text-to-image，prompt 显式写 `no text, no typography`。
2. **图生图精修**：image-to-image，支持传入 1–3 张参考图（`image1`/`image2`/`image3`），用 `input_fidelity` 控制对原图的风格贴合度。

> 这是"惊艳超越架构"的强美术后端之一（也可换 Midjourney / FLUX / PosterOmni）。Seedream 管文字可靠，ImageGen 这类强美术模型管视觉惊艳，分工互补。

## 关键参数

- `prompt`：文字描述（出底图时含 `no text`；精修时含具体要求）。
- `size`：按 `references/`（六类渠道规格，如 xiaohongshu.md 的 1728×2304）速查表。
- `quality`：`high` 用于主视觉惊艳底图，`medium` 用于批量草稿。
- `style`：可选风格词。
- `image1`（必填，图生图）：原图 / 初稿。
- `image2`（可选）：参考图（标杆库样张）→ 做风格/布局重设计。
- `image3`（可选）：第二张参考图。
- `input_fidelity`：图生图时高值=更贴近原图；低值=更大改动力度。

## 用法示例

```text
# 1) 惊艳底图（无字）
ImageGen(prompt="a surreal concept visual for a mindfulness poster, a single glowing quiet bubble in a subway car, cinematic light, depth of field, no text, no typography, no watermark", size="1728x2304", quality="high")

# 2) 图生图重设计（初稿 + 标杆参考）
ImageGen(prompt="restyle layout and color grading to match reference, keep subject, no text", image1=<初稿>, image2=<标杆样张>, input_fidelity="0.6", size="1728x2304")

# 3) 局部精修（换文字/保光影 —— 参考 SenseNova 做法）
ImageGen(prompt="replace the sign text with 'MARKET', keep lighting and perspective", image1=<底图+旧字>, input_fidelity="0.85")
```

## 文字合成建议

底图出来后，**文字不要靠生图赌**：
- 优先程序排版：`scripts/render_cards.py` 或 `xhs-cover-finalizer` 叠字（100% 准）。
- 或 Seedream `image_edit` / ImageGen 图生图精修把字精确铺上（保住底图光影）。

## 接入位置

`SKILL.md` 第 10 步（封面图）与第 11 步（配图）。详见 `references/astonish-architecture.md`。
