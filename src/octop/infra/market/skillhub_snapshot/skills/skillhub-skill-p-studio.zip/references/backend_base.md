# 出图后端约定（Backend Contract）

本 Skill 的「出图」环节与「编排/校验」环节解耦，后端可插拔替换。

## 统一输入
无论哪个后端，都接收同一份出图参数：
- `prompt`：已增强的完整提示词（含逐字文字与禁止项）。
- `size` / `width` × `height`：目标尺寸或分辨率档位。
- `n`：候选数量（默认 2–4）。
- 可选 `reference_images`：图生图/编辑用的参考图 URL/路径。
- 可选 `output_format`（png/jpg）、`watermark=false`。

## 统一输出
- 图片（URL 或本地文件路径）+ 实际尺寸。
- 候选逐张返回，供质量闭环回读。
- 记录后端标识与单次成本（API 后端）。

## 后端选择原则
| 情况 | 选择 |
|---|---|
| 零配置验证、自用、在豆包环境内 | 豆包自带 Seedream（`doubao_builtin.md`） |
| 给客户交付、卖图、脱离豆包独立运行、需要清晰授权链 | 火山引擎 API（`volcengine_api.md`） |
| **出惊艳主视觉（无字底图）** | **强美术后端**：WorkBuddy `ImageGen`（图生图，见 `workbuddy_imagegen.md`）/ Midjourney / FLUX / PosterOmni |
| **底图换文字 / 局部精修 / 保光影** | **图生图后端**：ImageGen `image1`+`image2` / Seedream `image_edit` |
| 无网络/离线 | 本地可商用模型（见下，质量与中文较弱，仅兜底） |

## 离线兜底（可选）
- FLUX.1-schnell（Apache 2.0，可商用，1–4 步），量化后约 8GB 显存，CPU 很慢；中文文字弱。
- 仅在无法使用上述两后端时使用，且建议配合程序排版保证文字。

## 切换注意
- 换后端只改「如何把统一输入变成实际调用、如何取回图片」，提示词与质量闭环不变。
- 正式商用前确认所选后端的服务协议与生成内容使用条款。
