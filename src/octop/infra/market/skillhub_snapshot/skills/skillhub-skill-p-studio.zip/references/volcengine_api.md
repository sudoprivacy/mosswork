# 后端二：火山引擎 Seedream API（阶段 2，独立商用）

## 说明
通过火山方舟（Ark）调用 Seedream，使用 OpenAI 兼容接口。**不依赖豆包环境**，普通电脑 + Python 即可运行；付费 API，生成内容按火山引擎服务协议使用，适合正式商用与交付客户。

## 准备步骤
1. 注册并实名火山引擎，进入火山方舟控制台：https://console.volcengine.com/ark
2. 开通 Seedream 图像模型，创建 API Key：
   https://console.volcengine.com/ark/region:ark+cn-beijing/apikey
3. 配置环境变量 `ARK_API_KEY`。
4. 安装依赖：`pip install openai`（或 `pip install "volcengine-python-sdk[ark]"`）。
5. 运行 `scripts/generate_volcengine.py`。

## 关键参数
- Base URL：`https://ark.cn-beijing.volces.com/api/v3`
- Model（示例，以控制台"模型列表"实际 ID 为准）：
  - Seedream 5.0 lite：`doubao-seedream-5-0-260128`
  - 4.5 / 4.0 见模型列表。
- `size`：分辨率档位 `2K/3K/4K`，或具体像素如 `2048x2048`、`1728x2304`、`1664x2496`。
- `output_format="png"`、`response_format="url"`（或 `b64_json`）、`watermark=False`。

## 推荐像素（2K，宽×高）
- 1:1 `2048x2048`；3:4 `1728x2304`；2:3 `1664x2496`；
- 16:9 `2848x1600`；9:16 `1600x2848`；21:9 `3136x1344`。
- 公众号 2.35:1 用具体像素 `2048x872`。

## 成本（参考，以官网为准）
- Seedream 5.0 lite 约 0.22 元/张；套餐折算更低（如 100 元约 900 张）。
- 4.5 约 0.25 元/张；新客常有首单优惠。

## 商用注意
- 以火山引擎最新服务协议中关于生成内容知识产权的条款为准。
- 若画面叠加第三方字体、图库、Logo、人物肖像，需各自取得授权。
- 遵守内容合规与平台行业规范。
