## Description: <br>
Helps agents prepare and submit PoYo Veo 3.1 Official video generation jobs, including text-to-video, image-guided video, polling, and webhook follow-up. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and external users use this skill to configure PoYo Veo 3.1 Official model requests, prepare payloads for text-to-video or image-guided video generation, and manage async task submission, polling, or webhook follow-up. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: PoYo API keys could be exposed through logs, browser code, public repositories, screenshots, or chat output. <br>
Mitigation: Keep POYO_API_KEY in a server-side environment or secret manager and avoid displaying it in generated examples or responses. <br>
Risk: Prompts, source media URLs, reference videos, or callback URLs may contain confidential or sensitive information. <br>
Mitigation: Review payloads before submission and only send confidential content when the user trusts PoYo and any webhook receiver. <br>
Risk: The helper can submit live generation requests to the PoYo API. <br>
Mitigation: Make live API calls only when the user explicitly asks and provides a trusted shell environment with POYO_API_KEY configured. <br>


## Reference(s): <br>
- [PoYo Veo 3.1 Official API Reference](references/api.md) <br>
- [PoYo Veo 3.1 Official Model Page](https://poyo.ai/models/veo-3-1-official) <br>
- [PoYo Veo 3.1 Official API Docs](https://docs.poyo.ai/api-manual/video-series/veo-3-1-official) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Code, Shell commands, Configuration, Guidance] <br>
**Output Format:** [Markdown with JSON payload examples and inline bash commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include selected model id, request mode, payload summary, task_id after submission, and polling or webhook next steps.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
