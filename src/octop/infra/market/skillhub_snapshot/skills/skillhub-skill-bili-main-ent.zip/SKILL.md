---
name: skillhub-skill-bili-main-ent
description: "当用户想按 B 站「娱乐」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：娱乐、B站分区、rid 5。"
---

# B 站分区 · 娱乐

- 一级分区 rid：`5`；网页路由：`/v/ent/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 93 条榜单条目，覆盖 5 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 娱乐杂谈 | 35 | 9 | 241 |
| 娱乐粉丝创作 | 20 | 10 | 242 |
| 明星综合 | 30 | 10 | 137 |
| 综艺 | 7 | 6 | 71 |
| 颜值安利 | 1 | 1 | 263 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 娱乐杂谈

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 他们一开口，我就笑掉头！【近期“脑袋空空”盘点】 | 一只吐槽圆 | [BV1L8R9YsEGP](https://www.bilibili.com/video/BV1L8R9YsEGP) | 846.8 万 |
| 金秀贤记者会直播：人的脸皮怎么能厚成这样！ | 话很多的小姐姐们 | [BV126ZmYPEZU](https://www.bilibili.com/video/BV126ZmYPEZU) | 120.1 万 |
| 你有如此炸裂的成语故事进入中国 | 混饭达人 | [BV1c3dcYDEAM](https://www.bilibili.com/video/BV1c3dcYDEAM) | 63.8 万 |
| 内娱恨海情天录2：王珞丹白百何，她们的纯恨长达14年！ | 不八卦会死星人V | [BV1hGdpYbE8A](https://www.bilibili.com/video/BV1hGdpYbE8A) | 91.8 万 |
| 【小小的勇气reaction】赵露思和麦琳为什么令人不适——聊聊她们“强者语境下的弱者叙事” | 橘子三瓣儿皮 | [BV1HtRqYQE3H](https://www.bilibili.com/video/BV1HtRqYQE3H) | 24.7 万 |

### 娱乐粉丝创作

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 大船倾毁，我已无力挽留！NMIXX 'KNOW ABOUT ME'一键换装 | 九一zero | [BV1TBdHYXEp9](https://www.bilibili.com/video/BV1TBdHYXEp9) | 81.8 万 |
| #变装#又见秦王 | 郑国霖 | [BV1QaRSYiE1o](https://www.bilibili.com/video/BV1QaRSYiE1o) | 44.4 万 |
| 牢景被肘晕前的幻想罢了 | MAZE攻略组 | [BV1ftRdYYEWR](https://www.bilibili.com/video/BV1ftRdYYEWR) | 127.8 万 |
| 那些女团里的tomboy位和girly位（个人向） | 晚安晨佳 | [BV1JtRdYeEvm](https://www.bilibili.com/video/BV1JtRdYeEvm) | 21.9 万 |
| ⚡“特种兵，梦该醒了”⚡ | 牢陌不吃鱼 | [BV1c9ZoY7E6C](https://www.bilibili.com/video/BV1c9ZoY7E6C) | 51.2 万 |

### 明星综合

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【时代少年团】《非去不可》EP04：这个温泉不太温 | 时代少年团 | [BV1xYRRY3E5w](https://www.bilibili.com/video/BV1xYRRY3E5w) | 433.4 万 |
| 【TF家族练习生】3月考核实录 | TF家族 | [BV1uYRBYTE9K](https://www.bilibili.com/video/BV1uYRBYTE9K) | 205.1 万 |
| 【登陆少年】TOP ARE DANGEROUS之异次元大作战》 EP7: “成为自理型艺人” | 登陆少年组合 | [BV1N5RdYVEVz](https://www.bilibili.com/video/BV1N5RdYVEVz) | 312.0 万 |
| 不敢相信！新来的同事竟然是王嘉尔... | 中国BOY超级大猩猩 | [BV1dBRZYeEiV](https://www.bilibili.com/video/BV1dBRZYeEiV) | 167.1 万 |
| 【沈月】一个人走着走着变成了一群人 | 沈月本人 | [BV1nMdHYVEkN](https://www.bilibili.com/video/BV1nMdHYVEkN) | 180.0 万 |

### 综艺

数据来源：二级分区 7 日榜，可用 6 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 抓马选人？低情商迷惑发言？《浪姐6》二公选人小考全解说！ | 我是一只粽子啊 | [BV1XQZZYiE3Z](https://www.bilibili.com/video/BV1XQZZYiE3Z) | 177.8 万 |
| 最烦装X的人！场外瓜比节目精彩，情商低到让人生气！《无限超越班》解说01 | 郭本尼 | [BV1WNRBYxECF](https://www.bilibili.com/video/BV1WNRBYxECF) | 151.7 万 |
| 【浪！2】嘻嘻！我一定要在船上活下去 | 小索在取名 | [BV18DZdYbETJ](https://www.bilibili.com/video/BV18DZdYbETJ) | 55.8 万 |
| JIWOO回应“真人AI”称呼！粉丝们都太有梗啦 | pcyxjy | [BV1TXR2YxEkp](https://www.bilibili.com/video/BV1TXR2YxEkp) | 56.3 万 |
| 超越班3王星小考演哭所有人，这一次用演技说话，靠实力打动所有人 | 优酷综艺君 | [BV1shRRYkEQX](https://www.bilibili.com/video/BV1shRRYkEQX) | 24.5 万 |

### 颜值安利

数据来源：二级分区 7 日榜，可用 1 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| “傩戏生万鬼避 见傩者 百病消…” | 是扶光啊- | [BV1KCRBY8Eno](https://www.bilibili.com/video/BV1KCRBY8Eno) | 5.5 万 |

## 名称差异与覆盖说明

- 分区表列出但本次榜单未返回条目：CP安利, 娱乐资讯（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=5." https://api.bilibili.com/x/web-interface/ranking/v2?rid=5&type=all. Accessed 6 Nov. 2026.
