#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
requirement_extract.py —— To B 销售需求提取引擎（已调试，零第三方依赖）

功能：
    把一段混乱的销售场景 / 客户对话 / 线索描述（自然语言），结构化为可判断的字段，
    并做轻量 BANT 资质初评，输出"必须向客户确认的问题清单"。

算法：
    1) 词典信号抽取：内置 6 类关键词词典（预算 / 时间 / 痛点 / 决策 / 竞争 / 触发事件），
       对文本逐词匹配，按命中强度给信号等级（强/中/弱/无）。
    2) 规模抽取：正则抽取"员工数 / 营收 / 金额"等规模数字。
    3) 痛点抽取：从痛点词典 + 邻近否定/负面词定位客户痛点短语。
    4) BANT 启发式评分：四维各 0-25，合计 0-100；映射 qual_tier(A/B/C/D)。
    5) 缺口推导：对缺失/弱信号的关键字段，生成 confirm_questions（喂给话术引擎）。

用法：
    python requirement_extract.py --text "客户原话或场景描述..."
    python requirement_extract.py --input lead.json --md report.md
    cat lead.json | python requirement_extract.py            # 读 stdin
    python requirement_extract.py --selftest                  # 跑内置 3 案例自检

输入 JSON 字段（均可选）：
    company_hint, industry, region, scale, source, raw_text,
    contact_role, budget_signal, timeline, incumbent, objective
输出：JSON（含 qualification_score / qual_tier / 各 signal / missing_fields / confirm_questions）
"""
import argparse
import json
import re
import sys

# ----------------------------- 信号词典 -----------------------------
# 每类按强度分级；命中即累加强度。可随业务扩展。
BUDGET_DICT = {
    "强": ["已立项", "预算批了", "有预算", "采购计划", "招标", "招投标", "询价", "已批", "费用已批", "专项资金"],
    "中": ["预算", "报价", "多少钱", "费用", "采购", "想买", "计划上", "准备投"],
    "弱": ["了解一下", "看看", "对比", "咨询"],
}
TIMELINE_DICT = {
    "强": ["本月", "这个月", "月底", "下周", "马上", "立即", "紧急", "急", "尽快", "本周"],
    "中": ["季度", "q1", "q2", "q3", "q4", "年内", "今年", "上半年", "下半年", "月底之前", "年底", "年底之前"],
    "弱": ["到时候", "以后", "后续", "考虑中", "有空"],
}
PAIN_DICT = [
    "效率低", "成本高", "成本上升", "流失", "投诉", "延期", "出错", "人力不够", "人力紧张",
    "瓶颈", "产能不足", "良率", "返工", "浪费", "数据孤岛", "协同", "跟不上", "风险",
    "合规", "被罚", "超期", "库存", "缺人", "手工", "纸质", "重复", "加班", "客诉",
]
AUTHORITY_DICT = {
    "强": ["老板", "总经理", "总裁", "董事长", "创始人", "ceo", "决策", "拍板", "委员会", "班子"],
    "中": ["总监", "负责人", "主管", "厂长", "cto", "cfo", "cio", "总工", "副总"],
    "弱": ["采购", "对接人", "专员", "助理", "同事", "技术"],
}
COMPETITOR_DICT = [
    "竞品", "对手", "比价", "已经在用", "现有供应商", "在用", "用过", "其他家", "友商",
    "阿里", "华为", "用友", "金蝶", "SAP", "西门子", "选型中", "在比",
]
TRIGGER_DICT = {
    "强": ["融资", "上市", "新厂", "扩建", "并购", "被处罚", "客户要求", "投标门槛", "合规审查", "审计"],
    "中": ["扩张", "增长", "新产线", "出海", "转型", "数字化", "上系统", "年审", "认证"],
    "弱": ["优化", "提升", "想改善", "听到同行"],
}

# ----------------------------- 规模正则 -----------------------------
SCALE_PATTERNS = [
    (r"(\d+)\s*人", "员工数"),
    (r"(\d+)\s*万", "金额(万)"),
    (r"(\d+)\s*亿", "金额(亿)"),
    (r"年营收[^\d]*(\d+)", "年营收"),
    (r"营收[^\d]*(\d+)", "营收"),
    (r"规上", "规上企业"),
    (r"上市公司", "上市公司"),
    (r"国企", "国企"),
]


def _hit_level(text, dct):
    """返回 (level, count)。level: 强/中/弱/无。"""
    t = text.lower()
    for lvl in ("强", "中", "弱"):
        cnt = sum(1 for kw in dct[lvl] if kw.lower() in t)
        if cnt:
            return lvl, cnt
    return "无", 0


def _count_any(text, lst):
    t = text.lower()
    return sum(1 for kw in lst if kw.lower() in t)


def extract_scale(text):
    found = []
    for pat, label in SCALE_PATTERNS:
        for m in re.finditer(pat, text):
            found.append({"label": label, "match": m.group(0)})
    return found


def extract_pains(text):
    """抽取痛点短语：按逗号/句号等切分为短句，命中的短句整体作为痛点，避免拼接噪声。"""
    clauses = re.split(r"[，。；、！？\n:：]", text)
    pains = []
    for c in clauses:
        c = c.strip()
        if not c:
            continue
        for kw in PAIN_DICT:
            if kw in c:
                if c not in pains:
                    pains.append(c)
                break
    return pains[:8]


def score_bant(budget_lvl, authority_lvl, pain_cnt, timeline_lvl, trigger_cnt):
    """四维各 0-25，启发式。返回 (score, dims)。"""
    b_map = {"强": 25, "中": 15, "弱": 6, "无": 0}
    a_map = {"强": 25, "中": 15, "弱": 7, "无": 0}
    t_map = {"强": 25, "中": 15, "弱": 6, "无": 0}
    # Need：痛点数量 + 触发事件数量
    need = min(25, pain_cnt * 6 + trigger_cnt * 4)
    budget = b_map[budget_lvl]
    authority = a_map[authority_lvl]
    timeline = t_map[timeline_lvl]
    total = budget + authority + need + timeline
    tier = "A" if total >= 75 else "B" if total >= 55 else "C" if total >= 35 else "D"
    return total, {
        "Budget(预算)": budget,
        "Authority(决策权)": authority,
        "Need(需求)": need,
        "Timeline(时间)": timeline,
    }, tier


def build_confirm_questions(result):
    """根据弱/缺信号生成确认问题清单。"""
    q = []
    if result["budget_signal"] in ("无", "弱"):
        q.append("确认预算：'咱们这块今年有立项的预算吗？大概的采购节奏是怎么安排的？'（验证：是否有钱、何时花）")
    if result["authority_signal"] in ("无", "弱"):
        q.append("确认决策人：'这件事最终拍板的是哪位？除了您，还有谁要参与决策？'（验证：是否找对人）")
    if not result["pain_points"]:
        q.append("挖痛点：'目前这块最让您头疼的具体问题是什么？它大概造成了多少损失/成本？'（验证：真实痛点与代价）")
    if result["timeline_signal"] in ("无", "弱"):
        q.append("确认时间窗：'您期望大概什么时候解决这个问题？有没有Deadline（如审计/投标）？'（验证：紧迫性）")
    if not result["trigger_events"]:
        q.append("找触发事件：'是什么促使您现在开始看这个方向？是被动要求还是主动规划？'（验证：动机强弱）")
    if not result["competitors"]:
        q.append("摸竞争：'除了我们，您还在看哪些方案/厂家？现在用的什么？'（验证：竞争格局）")
    return q


def analyze(lead):
    raw = (lead.get("raw_text") or "").strip()
    # 若 raw_text 为空，用其它字段拼一段也能跑（信号偏弱）
    ctx = raw or " ".join(str(v) for v in lead.values() if isinstance(v, str))

    budget_lvl, _ = _hit_level(ctx, BUDGET_DICT)
    timeline_lvl, _ = _hit_level(ctx, TIMELINE_DICT)
    authority_lvl, _ = _hit_level(ctx, AUTHORITY_DICT)

    # 否定语境修正：预算/时间 附近出现"没/未/无/暂/不"，降为弱（未确认）
    if re.search(r"预算.{0,5}(没|未|无|暂|不|还)", ctx) or re.search(r"(没|未|无|暂).{0,5}预算", ctx):
        budget_lvl = "弱"
    if re.search(r"(没|未|无|暂|不|还).{0,5}(急|马上|立即|尽快|本月|月底|本周|年内|今年)", ctx):
        timeline_lvl = "弱" if timeline_lvl in ("中", "强") else timeline_lvl
    pain_cnt = _count_any(ctx, PAIN_DICT)
    competitor_cnt = _count_any(ctx, COMPETITOR_DICT)
    trigger_cnt = _count_trigger(ctx)

    pains = extract_pains(ctx)
    scales = extract_scale(ctx)
    score, dims, tier = score_bant(budget_lvl, authority_lvl, pain_cnt, timeline_lvl, trigger_cnt)

    # 显式预算/时间信号（用户直接给的）覆盖推断
    if lead.get("budget_signal"):
        budget_lvl = lead["budget_signal"] if lead["budget_signal"] in ("强", "中", "弱", "无") else budget_lvl
    if lead.get("timeline"):
        timeline_lvl = lead["timeline"] if lead["timeline"] in ("强", "中", "弱", "无") else timeline_lvl

    result = {
        "company_hint": lead.get("company_hint", ""),
        "industry": lead.get("industry", ""),
        "region": lead.get("region", ""),
        "scale_hint": scales,
        "pain_points": pains,
        "pain_count": pain_cnt,
        "budget_signal": budget_lvl,
        "authority_signal": authority_lvl,
        "need_signal": "强" if pain_cnt >= 2 or trigger_cnt >= 1 else ("中" if pain_cnt == 1 else "弱"),
        "timeline_signal": timeline_lvl,
        "trigger_events": _trigger_phrases(ctx),
        "competitors": _competitor_phrases(ctx) if competitor_cnt else [],
        "qualification_score": score,
        "qual_tier": tier,
        "bant_dims": dims,
    }
    result["missing_fields"] = _missing(lead, result)
    result["confirm_questions"] = build_confirm_questions(result)
    return result


def _count_trigger(ctx):
    cnt = 0
    for lvl in ("强", "中", "弱"):
        cnt += sum(1 for kw in TRIGGER_DICT[lvl] if kw.lower() in ctx.lower())
    return cnt


def _trigger_phrases(ctx):
    out = []
    for lvl in ("强", "中", "弱"):
        for kw in TRIGGER_DICT[lvl]:
            if kw.lower() in ctx.lower() and kw not in out:
                out.append(kw)
    return out[:6]


def _competitor_phrases(ctx):
    out = []
    for kw in COMPETITOR_DICT:
        if kw.lower() in ctx.lower() and kw not in out:
            out.append(kw)
    return out[:6]


def _missing(lead, result):
    miss = []
    if not lead.get("company_hint") and not lead.get("industry"):
        miss.append("company_hint/industry（客户是谁/什么行业）")
    if not result["pain_points"]:
        miss.append("pain_points（具体痛点）")
    if result["budget_signal"] == "无":
        miss.append("budget_signal（预算）")
    if result["authority_signal"] == "无":
        miss.append("contact_role/authority（决策人）")
    if result["timeline_signal"] == "无":
        miss.append("timeline（时间窗）")
    return miss


def to_markdown(r):
    lines = ["# 需求简报（自动提取）", ""]
    if r["company_hint"]:
        lines.append(f"- 客户：{r['company_hint']}")
    if r["industry"]:
        lines.append(f"- 行业：{r['industry']}")
    if r["region"]:
        lines.append(f"- 地区：{r['region']}")
    if r["scale_hint"]:
        lines.append(f"- 规模信号：{', '.join(s['match'] for s in r['scale_hint'])}")
    lines.append(f"- 资质初评：{r['qual_tier']} 级（{r['qualification_score']}/100）")
    lines.append("")
    lines.append("## BANT 四维")
    for k, v in r["bant_dims"].items():
        lines.append(f"- {k}：{v}")
    lines.append("")
    lines.append(f"- 预算信号：{r['budget_signal']}　决策信号：{r['authority_signal']}　需求信号：{r['need_signal']}　时间信号：{r['timeline_signal']}")
    if r["pain_points"]:
        lines.append("")
        lines.append("## 痛点")
        for p in r["pain_points"]:
            lines.append(f"- {p}")
    if r["trigger_events"]:
        lines.append("")
        lines.append("## 触发事件：" + "、".join(r["trigger_events"]))
    if r["competitors"]:
        lines.append("")
        lines.append("## 竞争信号：" + "、".join(r["competitors"]))
    if r["missing_fields"]:
        lines.append("")
        lines.append("## 待核实字段")
        for m in r["missing_fields"]:
            lines.append(f"- {m}")
    if r["confirm_questions"]:
        lines.append("")
        lines.append("## 必须向客户确认的问题")
        for q in r["confirm_questions"]:
            lines.append(f"- {q}")
    return "\n".join(lines)


def selftest():
    cases = [
        {
            "name": "案例A-制造业ERP",
            "lead": {
                "company_hint": "某精密制造", "industry": "汽车零部件", "region": "山东",
                "raw_text": "我们是规上企业，2000人，老板想上ERP但预算还没批，主要痛点是数据孤岛和库存不准，延期交付被客户投诉，年底想上线，目前在比用友和SAP。",
            },
        },
        {
            "name": "案例B-自动化设备",
            "lead": {
                "company_hint": "某食品厂", "industry": "食品加工",
                "raw_text": "最近新工艺导致良率下降返工多，厂长说想看看自动化产线，问问多少钱，但没说预算也没说谁拍板，后面再说。",
            },
        },
        {
            "name": "案例C-体系认证咨询",
            "lead": {
                "company_hint": "某物业", "industry": "物业服务",
                "raw_text": "客户要求我们有ISO三体系才能投标，总经理急了，本月要启动，已批了专项费用，之前没做过体系。",
            },
        },
    ]
    ok = True
    for c in cases:
        r = analyze(c["lead"])
        print(f"=== {c['name']} ===")
        print(f"  tier={r['qual_tier']} score={r['qualification_score']} budget={r['budget_signal']} auth={r['authority_signal']} need={r['need_signal']} time={r['timeline_signal']}")
        print(f"  pains={r['pain_points']}")
        print(f"  triggers={r['trigger_events']} competitors={r['competitors']}")
        print(f"  confirm_q={len(r['confirm_questions'])} 条")
        # 基本健全性：tier 与 score 自洽
        exp = "A" if r["qualification_score"] >= 75 else "B" if r["qualification_score"] >= 55 else "C" if r["qualification_score"] >= 35 else "D"
        if exp != r["qual_tier"]:
            ok = False
            print("  [FAIL] tier/score 不自洽")
    print("\nSELFTEST:", "PASS" if ok else "FAIL")
    return ok


def main():
    ap = argparse.ArgumentParser(description="To B 销售需求提取引擎")
    ap.add_argument("--input", help="输入 JSON 文件路径")
    ap.add_argument("--text", help="直接传入场景文本")
    ap.add_argument("--md", help="将 Markdown 简报写入该路径")
    ap.add_argument("--selftest", action="store_true", help="跑内置案例自检")
    args = ap.parse_args()

    if args.selftest:
        sys.exit(0 if selftest() else 1)

    lead = {}
    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            lead = json.load(f)
    elif args.text:
        lead = {"raw_text": args.text}
    else:
        # 读 stdin
        data = sys.stdin.read().strip()
        if data.startswith("{"):
            lead = json.loads(data)
        else:
            lead = {"raw_text": data}

    r = analyze(lead)
    print(json.dumps(r, ensure_ascii=False, indent=2))
    if args.md:
        with open(args.md, "w", encoding="utf-8") as f:
            f.write(to_markdown(r))
        print(f"\n[已写入 Markdown 简报] {args.md}")


if __name__ == "__main__":
    main()
