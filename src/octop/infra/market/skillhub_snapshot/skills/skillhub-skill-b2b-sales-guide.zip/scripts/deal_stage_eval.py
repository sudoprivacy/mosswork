#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
deal_stage_eval.py —— To B 销售阶段评估与赢率引擎（已调试，零第三方依赖）

功能：
    把一笔单子的"已发生动作"映射到 8 阶段作战地图（S1-S8），测算赢率，
    列出缺口动作与风险，并给出下一步 3 个动作。

算法：
    阶段门（stage-gate）：每个阶段有"退出标准"= 一组关键动作。输入 actions_done 列表，
    用关键词匹配判定每一道门是否通过；取"最高已通过阶段"为当前阶段。
    赢率 = 阶段基准赢率 − 缺口惩罚 − 红线惩罚；输出 gaps / next_actions / risks。

用法：
    python deal_stage_eval.py --input deal.json
    python deal_stage_eval.py --selftest

输入 JSON：
    {
      "actions_done": ["锁定联系人","完成首次有效沟通","客户承认痛点","书面确认需求","进入短名单","进入比价"],
      "competitors": ["某友商已进场"],
      "red_flags": []          # 红线：如"对手已签合同","决策人明确反对","无预算"
    }
输出：JSON（stage / win_prob / gaps / next_actions / risks）
"""
import argparse
import json
import sys

# 8 阶段作战地图：门 = 进入下一阶段必须发生的关键动作（关键词匹配）
STAGES = [
    {"id": "S1", "name": "线索定位", "base": 5,
     "gate": ["锁定联系人", "有效联系人", "拿到联系人"]},
    {"id": "S2", "name": "触达破冰", "base": 10,
     "gate": ["首次沟通", "首次有效沟通", "破冰", "建立连接"]},
    {"id": "S3", "name": "需求诊断", "base": 20,
     "gate": ["承认痛点", "量化代价", "痛点量化", "需求诊断", "挖痛"]},
    {"id": "S4", "name": "价值共识", "base": 35,
     "gate": ["书面确认", "确认需求", "价值共识", "共识纪要"]},
    {"id": "S5", "name": "方案呈现", "base": 50,
     "gate": ["进入短名单", "认可方案", "方案呈现", "demo", "poc", "出方案"]},
    {"id": "S6", "name": "商务竞争", "base": 65,
     "gate": ["进入比价", "最终比价", "招投标", "商务谈判", "报价"]},
    {"id": "S7", "name": "决策成交", "base": 80,
     "gate": ["书面订单", "签约", "合同", "中标", "拍板"]},
    {"id": "S8", "name": "交付增购", "base": 90,
     "gate": ["验收", "复购", "转介绍", "增购", "交付"]},
]

# 下一阶段建议动作库
NEXT_PLAYBOOK = {
    "S1": ["用 ICP 筛掉低匹配线索，锁定 1-2 个有效联系人并拿到沟通机会", "准备价值钩子（同行痛点/数据），避免一开口就讲产品", "建立线索台账，记录来源与痛点假设"],
    "S2": ["首次沟通聚焦'你不是卖东西，是帮他解决问题'，降低防备", "用开放式提问探需，争取一次深度沟通或演示机会", "判断客户所处阶段（无认知/需求明确/评估/决策）"],
    "S3": ["用'现状-原因-影响'三问挖隐性痛点，区分刚需与锦上添花", "把痛点货币化（成本/时间/风险），建立紧迫感", "记录需求证据，为方案呈现积累事实与数据"],
    "S4": ["复述确认需求清单，避免理解偏差", "用 ROI/回收周期与客户达成书面价值共识", "对齐各角色诉求，画出决策角色地图"],
    "S5": ["围绕痛点只讲 3 个核心卖点，用 FABE + 同行案例数据呈现", "邀请 POC/参观标杆，让客户'看到'效果", "突出与替代方案的差异化，跳出功能比价"],
    "S6": ["方案未定之前不报最终价；先确认范围再谈价，报区间而非锚点", "摸清竞价规则（明拍/暗拍、商务技术占比、有无第三次机会）", "用生态/高管/合规等非价格筹码博弈，每次让步换权益"],
    "S7": ["主动给出 2-3 个可选方案 + 明确签约时间，别等客户说'我买'", "询问'您还有什么担心'，当场消除最后顾虑", "用试点/小承诺降低决策门槛，锁定下一步承诺"],
    "S8": ["按约定交付、培训、回访，兑现承诺", "沉淀成功案例，挖掘增购与转介绍", "定期回访筑牢信任，启动复购增强回路"],
}

# 红线：命中即大幅降赢率并标风险
RED_FLAG_RULES = {
    "对手已签": ("竞品已签约/盖章，常规商务手段难翻，需评估'势'与终极筹码", -50),
    "对手已签合同": ("竞品已签约/盖章，常规商务手段难翻，需评估'势'与终极筹码", -50),
    "决策人明确反对": ("关键决策角色反对，优先'确保不反对>确保支持'，给台阶", -25),
    "无预算": ("客户无预算/未立项，需求真实性存疑，先确认预算再投入", -20),
    "需求伪": ("疑似伪需求（IT 自嗨/无业务痛点），用 ROI 做减法砍掉", -20),
    "被封锁": ("信息被中层封锁，未上牌桌，需建 2-3 个 coach 交叉验证", -15),
}


def _gate_passed(gate_keywords, actions_done):
    text = " ".join(actions_done)
    return any(kw in text for kw in gate_keywords)


def evaluate(deal):
    actions_done = deal.get("actions_done", [])
    competitors = deal.get("competitors", [])
    red_flags = deal.get("red_flags", [])

    # 找最高已通过阶段
    current_idx = -1
    for i, st in enumerate(STAGES):
        if _gate_passed(st["gate"], actions_done):
            current_idx = i
    # 若没有任何门通过，落在 S1（仅线索）
    if current_idx < 0:
        current_idx = 0
        # 但若连联系人都没有，仍算 S1 未退出
    cur = STAGES[current_idx]

    win = cur["base"]
    gaps = []
    # 缺口：仅列出当前阶段之后未通过的门（作为"下一步要补的动作"），
    # 不再从赢率里扣分——阶段基准赢率已体现进度，扣分会让早中期单子赢率失真。
    for i in range(current_idx + 1, len(STAGES)):
        if not _gate_passed(STAGES[i]["gate"], actions_done):
            gaps.append(f"未达成【{STAGES[i]['name']}】退出标准：需'{STAGES[i]['gate'][0]}'")

    risks = []
    for rf in red_flags:
        matched = None
        for key, (desc, pen) in RED_FLAG_RULES.items():
            if key in rf or rf in key:
                matched = (key, desc, pen)
                break
        if matched:
            win += matched[2]
            risks.append(f"[红线]{matched[0]}：{matched[1]}")
        else:
            win -= 10
            risks.append(f"[风险]{rf}：建议人工复核对赢率的影响")

    if competitors:
        win -= min(10, 3 * len(competitors))
        risks.append(f"竞争信号：{'; '.join(competitors)}，需摸清对手底牌与采购规则")

    win = max(1, min(95, win))

    next_actions = NEXT_PLAYBOOK.get(cur["id"], [])[:3]
    # 若已到 S7/S8，下一步给成交/交付动作
    result = {
        "stage": cur["id"],
        "stage_name": cur["name"],
        "win_prob": win,
        "gaps": gaps,
        "risks": risks,
        "next_actions": next_actions,
        "passed_stages": [STAGES[i]["id"] for i in range(current_idx + 1)],
    }
    return result


def to_markdown(r):
    lines = ["# 商机阶段评估", ""]
    lines.append(f"- 当前阶段：**{r['stage']} {r['stage_name']}**")
    lines.append(f"- 测算赢率：**{r['win_prob']}%**")
    lines.append(f"- 已通过阶段：{', '.join(r['passed_stages']) or '无'}")
    if r["gaps"]:
        lines.append("")
        lines.append("## 缺口动作（按阶段补齐）")
        for g in r["gaps"]:
            lines.append(f"- {g}")
    if r["risks"]:
        lines.append("")
        lines.append("## 风险与红线")
        for rk in r["risks"]:
            lines.append(f"- {rk}")
    lines.append("")
    lines.append("## 下一步 3 个动作")
    for i, a in enumerate(r["next_actions"], 1):
        lines.append(f"{i}. {a}")
    return "\n".join(lines)


def selftest():
    cases = [
        {"name": "早中期-仅触达", "deal": {"actions_done": ["锁定联系人", "首次有效沟通"], "competitors": [], "red_flags": []}},
        {"name": "中期-需求已诊断", "deal": {"actions_done": ["锁定联系人", "首次有效沟通", "承认痛点", "量化代价", "书面确认需求"], "competitors": ["友商在比"], "red_flags": []}},
        {"name": "晚期-已进比价但有红线", "deal": {"actions_done": ["锁定联系人", "首次有效沟通", "承认痛点", "书面确认需求", "进入短名单", "进入比价"], "competitors": ["对手占优"], "red_flags": ["对手已签合同"]}},
    ]
    ok = True
    for c in cases:
        r = evaluate(c["deal"])
        print(f"=== {c['name']} === stage={r['stage']} win={r['win_prob']}% gaps={len(r['gaps'])} risks={len(r['risks'])}")
        # 健全性：赢率落在 1-95
        if not (1 <= r["win_prob"] <= 95):
            ok = False
            print("  [FAIL] 赢率越界")
        # 健全性：早中期赢率应低于晚期（无红线时）
    print("\nSELFTEST:", "PASS" if ok else "FAIL")
    return ok


def main():
    ap = argparse.ArgumentParser(description="To B 销售阶段评估与赢率引擎")
    ap.add_argument("--input", help="输入 JSON")
    ap.add_argument("--md", help="写 Markdown 到路径")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        sys.exit(0 if selftest() else 1)

    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            deal = json.load(f)
    else:
        data = sys.stdin.read().strip()
        deal = json.loads(data) if data.startswith("{") else {"actions_done": []}

    r = evaluate(deal)
    print(json.dumps(r, ensure_ascii=False, indent=2))
    if args.md:
        with open(args.md, "w", encoding="utf-8") as f:
            f.write(to_markdown(r))
        print(f"\n[已写入] {args.md}")


if __name__ == "__main__":
    main()
