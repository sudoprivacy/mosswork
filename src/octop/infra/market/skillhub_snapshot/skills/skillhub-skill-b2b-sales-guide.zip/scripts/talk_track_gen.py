#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
talk_track_gen.py —— To B 销售话术生成引擎（已调试，零第三方依赖）

功能：
    按 目标(objective) × 渠道(channel) × 角色(role) × 阶段(stage) 上下文，从话术片段库
    组合出一段"可直接照着念"的话术包。每条片段绑定 checks（这一句在验证/推进什么）。

设计要点（来自实战框架，已内化）：
    - 决策链五角色（经济决策者/采购/技术选型/内部倡导者/终端使用者）→ 不同角色不同话术重心
    - 七阶段对话 SOP：初步接触→挖掘需求→产品介绍→价值呈现(FABE)→异议处理→促成成交→售后
    - 价值叙事四层级（L1工具/L2业务/L3战略/L4范式）：见什么人高一个层级讲
    - 异议五类（价格/效果/信任/需求/拖延）：先共情再给证据
    - 高层三页纸法则：越高层越简单

算法：分片模板填充（fragment templating）。
    - FRAGS 以 objective 为键，存片段列表；占位符 {role}/{industry}/{pain}/{value}/{me}
    - OPENERS 按 channel 给开场白；ROLE_FOCUS 按角色给"话术重心"提示
    - 输出按 objective 分组的 Markdown 话术包

用法：
    python talk_track_gen.py --input req.json
    python talk_track_gen.py --stage S3 --objective 挖痛点 --channel 电话 --role 厂长 --industry 食品
    python talk_track_gen.py --selftest

输入 JSON（均可选）：stage, objective, channel(电话/微信/邮件), role, industry, pain, value, company
"""
import argparse
import json
import sys

OPENERS = {
    "电话": "（接通）{role}您好，我是XX公司的{me}，耽误您两分钟，有个事想跟您请教下。",
    "微信": "{role}您好，我是XX公司的{me}～有个想法跟您碰一下。",
    "邮件": "主题：关于{industry}「{pain}」的一点思路\n{role}您好：",
}

# 决策链五角色的话术重心
ROLE_FOCUS = {
    "经济决策者": "少讲功能参数，多讲投入产出、同行标杆与风险可控",
    "老板": "少讲功能参数，多讲投入产出、同行标杆与风险可控",
    "总经理": "少讲功能参数，多讲投入产出、同行标杆与风险可控",
    "采购": "提前备好报价结构、付款方式、交付周期，用透明建立信任",
    "技术选型": "用白皮书/测试报告/实施案例说话，避免过度承诺",
    "技术": "用白皮书/测试报告/实施案例说话，避免过度承诺",
    "内部倡导者": "给他'内部汇报材料'，让他成为你推进的帮手",
    "终端使用者": "邀请试用、提供培训、收集反馈，让他愿意替你说话",
}

# 话术片段库：键=objective（含别名映射容错）
FRAGS = {
    "定位": [
        ("{industry}这一行，我们服务过不少和您规模相近的同行，他们普遍卡在{pain}上。", "用同体量背书破冰，降低防备"),
        ("方便的话，我先发一份行业常见做法给您参考，您看值不值得聊？", "低压力索要沟通许可"),
    ],
    "破冰约见": [
        ("我们不算最便宜的，但能帮您把{pain}这件事落地，很多{industry}客户是先聊一次再决定的。", "用价值钩子换见面，不卷价格"),
        ("这周四或下周一，您哪个时间段方便通个 20 分钟？我带着同行思路来。", "给二选一时间，逼出承诺"),
    ],
    "挖痛点": [
        ("您现在这块最头疼的具体问题是什么？能举一个最近的例子吗？", "开放式提问，让客户自己描述痛"),
        ("这个问题一般会造成多少成本/损失？是钱、时间、还是风险？", "把痛点货币化，建立紧迫感"),
        ("这个问题是谁最先感知到的？解决了它，对谁最有好处？", "定位真实痛点 owner 与影响面"),
    ],
    "确认预算": [
        ("咱们这块今年有立项的预算吗？还是先看方案、后面再走采购？", "区分'已立项有钱'与'先调研'"),
        ("如果方案确实能解决{pain}，您心里大概的投入区间是？", "探测预算水位，不先报价"),
    ],
    "价值共识": [
        ("我理解的诉求是：{pain}，目标是在{value}上看到改善，对吗？我复述一遍您看准不准。", "复述确认，避免理解偏差"),
        ("按同行经验，这事做成了大概能省/赚 {value}，我们先把这个共识写下来。", "量化价值，形成书面共识"),
    ],
    "方案呈现": [
        ("针对{pain}，我们建议分三步走，先解决最痛的那块，让您尽快看到效果。", "分阶段降低决策压力"),
        ("这是同行业案例，他们上线后{value}，您觉得这个路径可行吗？", "案例背书 + 征求认同"),
    ],
    "价值呈现FABE": [
        ("（F特点）这套方案用的是 XX 机制，响应比传统方式快不少。", "讲清'你有什么'"),
        ("（A优势）在{industry}的高频场景下更稳定，故障率更低。", "相对替代方案的独特价值"),
        ("（B利益）对您来说，停机减少、产能利用率提升，每年大约省 {value}。", "客户只为'他能得到'买单"),
        ("（E证据）同规模客户上线三个月后，效率提升、故障下降，数据都在案例里。", "用证据消除'有用吗'的疑问"),
    ],
    "异议-价格": [
        ("我理解，价格肯定要算得过账。咱们先把总价拆成'每天/每件'的成本看，其实比现在{pain}的代价低得多。", "共情 + 把总价拆成日成本，跳出比价"),
        ("另外报价我给您拆成'必须+可选'，您先上必须的，见效再加可选，风险可控。", "结构化报价，降低一试错成本"),
    ],
    "异议-效果": [
        ("'有用吗'是个好问题。我给您看同行业的真实数据和可量化结果，也可以先做个小范围试点。", "拿案例/数据 + 邀请试用"),
        ("您最关心的指标是哪个？我专门针对它给您做个对照。", "把抽象疑虑落到具体指标"),
    ],
    "异议-信任": [
        ("不了解我们很正常。我发您几份资质、标杆客户名单和第三方评价，您先核验。", "展示资质/标杆/第三方，建立信任"),
        ("也可以安排您去参观一家在用客户，眼见为实。", "用现场见证替代自夸"),
    ],
    "异议-需求": [
        ("您说'不需要'，我猜是现在还没到最痛的时候？我换个场景跟您聊——如果{pain}再恶化会怎样？", "深挖隐性需求，重构场景"),
        ("很多客户一开始也觉得不需要，直到一次{industry}事故让他们重新算账。", "用同行教训唤醒刚需"),
    ],
    "异议-拖延": [
        ("'再考虑'我完全理解，通常卡在三点：预算、决策人、还是效果顾虑？我帮您理一下。", "探寻拖延根源，不逼"),
        ("那我们先定个小动作：这周五我给您一份一页纸方案，您看完再决定，行吗？", "给明确下一步，避免石沉大海"),
    ],
    "引荐决策人": [
        ("这事要往前推，除了您，还需要哪位拍板？我准备一份给他的材料。", "礼貌要引荐，摸清决策链"),
        ("您觉得给总经理汇报，他最关心哪三点？我提前对齐。", "借力对接人，预判经济买家关切"),
    ],
    "推进决策": [
        ("刚才聊的几点，您看还有什么顾虑？我当场能解的当场解。", "临门一脚，逼出真实顾虑"),
        ("要不我们先走一个小范围试点，两个月看效果，成了再全面铺开？", "用小承诺替代大承诺，降门槛"),
    ],
    "消除风险": [
        ("您担心的交付风险，我们写进合同：达不到{value}按约定退/补。", "把风险变成书面承诺"),
        ("实施您不用单独抽人，我们派驻场，您这边只对接一个接口人。", "消除'落地没人'的顾虑"),
    ],
    "高层汇报": [
        ("（第一页·价值主张）一句话：我们帮您解决的根本问题是{pain}，方向是{value}。", "越高层越简单，讲方向不讲功能"),
        ("（第二页·为什么是我们）2-3 个不可替代的优势，用您的案例和数据说话。", "用客户案例/数据建信任"),
        ("（第三页·下一步）一个明确动作 + 一个明确时间节点，我建议本周五启动。", "给决策人'下一步'而非开放题"),
    ],
    "交付增购": [
        ("上线这段时间，哪个点让您觉得最值？我想把它固化成标准动作。", "兑现价值，铺垫增购"),
        ("您这事若方便，我想写个匿名案例，也帮您在同行业里露个脸。", "要案例/转介绍，顺带给客户曝光"),
    ],
}

OBJ_ALIAS = {
    "定位": "定位", "破冰": "破冰约见", "约见": "破冰约见", "挖需求": "挖痛点",
    "挖痛": "挖痛点", "挖痛点": "挖痛点", "确认预算": "确认预算", "预算": "确认预算",
    "价值": "价值共识", "共识": "价值共识", "方案": "方案呈现", "呈现": "方案呈现",
    "FABE": "价值呈现FABE", "价值呈现": "价值呈现FABE",
    "价格": "异议-价格", "异议价格": "异议-价格", "太贵": "异议-价格",
    "效果": "异议-效果", "异议效果": "异议-效果", "有用吗": "异议-效果",
    "信任": "异议-信任", "异议信任": "异议-信任", "不了解": "异议-信任",
    "需求异议": "异议-需求", "不需要": "异议-需求",
    "拖延": "异议-拖延", "再考虑": "异议-拖延",
    "引荐": "引荐决策人", "决策人": "引荐决策人",
    "推进": "推进决策", "成交": "推进决策", "决策": "推进决策",
    "风险": "消除风险", "交付": "交付增购", "增购": "交付增购", "转介绍": "交付增购",
    "高层": "高层汇报", "汇报": "高层汇报",
}


def resolve_obj(objective):
    if not objective:
        return "挖痛点"
    o = objective.strip()
    if o in FRAGS:
        return o
    return OBJ_ALIAS.get(o, "挖痛点")


def gen(req):
    stage = req.get("stage", "S3")
    objective = resolve_obj(req.get("objective"))
    channel = req.get("channel", "电话")
    role = req.get("role", "负责人")
    industry = req.get("industry", "咱们这行")
    pain = req.get("pain", "当前最痛的点")
    value = req.get("value", "效率/成本")
    company = req.get("company", "我们")

    frags = FRAGS.get(objective, FRAGS["挖痛点"])
    opener = OPENERS.get(channel, OPENERS["电话"]).format(
        role=role, industry=industry, pain=pain, me="顾问"
    )
    role_focus = ROLE_FOCUS.get(role, "")

    out = {"stage": stage, "objective": objective, "channel": channel,
           "role": role, "role_focus": role_focus, "lines": []}
    for tmpl, check in frags:
        line = tmpl.format(role=role, industry=industry, pain=pain, value=value, company=company, me="顾问")
        out["lines"].append({"line": line, "checks": check})
    return out, opener


def to_markdown(out, opener):
    lines = [f"# 话术包｜{out['stage']} · {out['objective']} · 渠道：{out['channel']}", ""]
    lines.append(f"**对象角色**：{out['role']}")
    if out["role_focus"]:
        lines.append(f"**话术重心**：{out['role_focus']}")
    lines.append("")
    lines.append("## 开场")
    lines.append(f"> {opener}")
    lines.append("")
    lines.append("## 主体话术（逐句 + 注解）")
    for i, item in enumerate(out["lines"], 1):
        lines.append(f"{i}. {item['line']}")
        lines.append(f"   ↳ 验证/推进：{item['checks']}")
    lines.append("")
    lines.append("> 提示：话术只给骨架，临场按客户反应删减；**不承诺具体价格/结果**，只确认价值与下一步。")
    return "\n".join(lines)


def selftest():
    tests = [
        {"stage": "S3", "objective": "挖痛点", "channel": "电话", "role": "厂长", "industry": "食品", "pain": "良率下降", "value": "返工成本"},
        {"stage": "S5", "objective": "价值呈现", "channel": "微信", "role": "技术", "industry": "汽车零部件"},
        {"stage": "S6", "objective": "异议-价格", "channel": "邮件", "role": "采购", "industry": "物业", "pain": "投标门槛", "value": "拿标"},
        {"stage": "S7", "objective": "高层汇报", "channel": "邮件", "role": "总经理", "industry": "制造", "pain": "数字化", "value": "行业地位"},
    ]
    ok = True
    for t in tests:
        out, opener = gen(t)
        if not out["lines"]:
            ok = False
            print(f"[FAIL] {t} 无话术产出")
        print(f"=== {t.get('stage')}/{t.get('objective')}/{t.get('channel')}/{t.get('role')} === 产出 {len(out['lines'])} 句")
        for item in out["lines"][:1]:
            print(f"  - {item['line'][:46]}… | {item['checks']}")
    print("\nSELFTEST:", "PASS" if ok else "FAIL")
    return ok


def main():
    ap = argparse.ArgumentParser(description="To B 销售话术生成引擎")
    ap.add_argument("--input", help="输入 JSON")
    ap.add_argument("--stage", help="阶段 S1-S8")
    ap.add_argument("--objective", help="目标（挖痛点/确认预算/价值呈现/异议-价格/引荐决策人/推进决策/高层汇报…）")
    ap.add_argument("--channel", help="电话/微信/邮件")
    ap.add_argument("--role", help="对接人角色（厂长/采购/技术/总经理…）")
    ap.add_argument("--industry", help="行业")
    ap.add_argument("--pain", help="痛点")
    ap.add_argument("--value", help="价值/收益")
    ap.add_argument("--md", help="写 Markdown 到路径")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        sys.exit(0 if selftest() else 1)

    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            req = json.load(f)
    else:
        req = {}
    for k in ("stage", "objective", "channel", "role", "industry", "pain", "value"):
        v = getattr(args, k)
        if v:
            req[k] = v

    out, opener = gen(req)
    md = to_markdown(out, opener)
    print(md)
    if args.md:
        with open(args.md, "w", encoding="utf-8") as f:
            f.write(md)
        print(f"\n[已写入] {args.md}")


if __name__ == "__main__":
    main()
