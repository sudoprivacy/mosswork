---
name: skillhub-skill-bilibili-fans-cleaner
description: "清理 B 站粉丝。Use when 分析或批量移除 bilibili 僵尸粉/营销号。"
---

# Bilibili 粉丝分析与清理

## 概览

识别 B 站粉丝中的低质量账号（默认昵称 `bili_xxx`、职业矩阵营销号），并用 `POST /x/relation/modify (act=7)` 批量移除。已验证：38/38 成功，1.2s 间隔无风控。

## 登录态获取（关键路径）

不要尝试 curl 匿名调 followers API——无 cookie 返回 `-352` 风控。可行路：

1. **首选：桌面端预览页登录态**。在预览面板打开 `https://api.bilibili.com/x/web-interface/nav` 确认 `isLogin:true`（用户扫码登录后 cookie 存在预览容器的 cookie 存储里）。
2. **提取 cookie 给脚本用**：从当前浏览器/预览容器的 cookie 数据库（SQLite，表 `cookies`）中读取 `.bilibili.com` 域下的三个关键项：`SESSDATA`、`bili_jct`（即 CSRF token）、`DedeUserID`。部分容器（如桌面端预览分区）为明文 `value` 列直接可读；若为加密存储则回退方案 3。
3. **兜底**：无法取 cookie 时，直接在已登录的预览页内用 JS fetch 发请求（浏览器自动带 cookie，无需提取）。
4. 脚本请求时带 header：`Cookie: SESSDATA=...; bili_jct=...; DedeUserID=...` + 正常 Chrome UA + `Referer: https://www.bilibili.com/`，即通。

## UI 模拟点击不可行（已踩坑）

粉丝页 `space.bilibili.com/<mid>/relation/fans` 的行内"⋯→移除粉丝"是悬停瞬时浮层：drive_preview 的 hover→click 两步之间浮层即消失，且浮层不注册进 elements inventory、各种 popper/dropdown 选择器全部抓空。**不要走 UI 路线，直接 API。**

## 粉丝分类规则

拉全量：`GET /x/relation/followers?vmid=<mid>&pn=<N>&ps=50` 翻页到空（ps>50 会被截断为 50；响应 list 含 uname/mid/mtime/face/sign），以 mid 去重。

- **默认昵称**（B站注册未改名）：正则 `^(bili_[0-9]{6,}|[0-9]{6,}_bili|Bili_[0-9]+)$`（忽略大小写）。特征叠加：`face` 为 `noface.jpg`、`sign` 空。
- **营销矩阵号**：昵称模板如 护士XX/空姐XX/幼教老师XX/瑜伽老师XX/大三XX/工厂XX直销。判据：mid 集中在新注册号段（3546xxx/3706-3707xxx 16 位）、mtime 同周扎堆、无简介。
- **注册时间线索**：16 位 mid 以 35/37 开头是最新号段；`mtime` 是关注你时间戳，扎堆涌入=互粉/任务号。
- 真人沉默粉（有正常昵称/有简介）不清理。

## 批量移除

```
POST https://api.bilibili.com/x/relation/modify
form: fid=<mid>&act=7&re_src=11&csrf=<bili_jct>
```

- act: 1=关注 2=取关 3=白名单 5=拉黑 **7=移除粉丝**（不是拉黑，对方可重新关注，可逆）。
- 每请求间隔 ≥1.2s；成功判据 `code==0`。38 连发无风控。
- 移除后**必须复验**：重拉 followers 全量，确认目标 uid 为 0 且 `relation/stat` 的 follower 计数下降吻合。

## 流程清单

1. nav API 确认登录；提取 cookie。
2. 拉全量粉丝 → 按规则分类 → 列出候选清单给用户过目（数量+构成），确认后再删。
3. 批量 act=7 → 复核 follower 计数 → 报告 removed/total 与误伤兜底（备份 uid 清单到 /tmp/fans_targets.json；移除可逆=对方重新关注即回）。

## 坑

- 网页粉丝列表每页 24 个、API ps 上限 50，两边计数别混用。
- 移除粉丝≠拉黑；想彻底封死用 act=5（拉黑），需向用户说明差别再选。
- SkillHub/GitHub 上无现成的"移除粉丝"skill（只有视频/字幕/投流类）；接口参考 bilibili-fans-remover-userscript 的 kickFan 实现。
