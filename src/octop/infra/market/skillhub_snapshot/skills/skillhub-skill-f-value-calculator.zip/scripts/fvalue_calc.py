#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
杀菌值计算器 fvalue_calc.py
覆盖从低酸性到高酸性产品的杀菌强度 F 值计算、热穿透积分、商业无菌保温判定。

用法：
  python3 fvalue_calc.py cfg [--key low_acid|acid_acidif|high_acid|very_high]
  python3 fvalue_calc.py calc --ph 4.2 --file 热穿透.csv [--method stepwise|simpson|trapezoid] [--report out.pdf]
  python3 fvalue_calc.py calc --key low_acid --temp-line "90,0;110,15;121,25;121,35;90,45"
  python3 fvalue_calc.py calc --key low_acid          # 从 stdin 粘贴 "温度,时间" 换行
  python3 fvalue_calc.py isobaric --D 0.21 --n 12
  python3 fvalue_calc.py validate --days 10 --temp 36 --ph 4.2 --swell no --pH-delta 0.3 --smear no
  python3 fvalue_calc.py dump --in 热穿透.csv
"""
import argparse, math, sys, os, csv, re, tempfile

# ───────────────────────── 四档参数表 ─────────────────────────
CATEGORIES = {
    "low_acid": dict(
        key="low_acid", name="低酸", pH_range=">4.6", category="低酸性食品",
        microbe="肉毒梭菌(C.botulinum) 12D / 嗜热脂肪芽孢(耐热上限)",
        D_val=0.21, D_temp=121.1, Z=10.0, Rt=121.1,
        F_target=3.0, F_ref="F0", F_units="min", start_T=90,
        standard="FDA 21CFR113 / GB 7098", typical="121℃杀菌釜 20-60min",
    ),
    "acid_acidif": dict(
        key="acid_acidif", name="中酸/酸化", pH_range="4.0~4.6", category="酸性/酸化食品",
        microbe="凝结芽孢杆菌(平酸)/多粘芽孢杆菌(胀包) 6D",
        D_val=0.07, D_temp=121.1, Z=8.89, Rt=93.3,
        F_target=2.5, F_ref="F(8.89/93.3)", F_units="min", start_T=70,
        standard="SN/T 040.6-2005", typical="95-98℃/20-30min",
    ),
    "high_acid": dict(
        key="high_acid", name="高酸", pH_range="3.5~<4.0", category="酸性食品(高酸)",
        microbe="酸土脂环酸芽孢杆菌(Alicyclobacillus)/酵母/霉菌",
        D_val=18.0, D_temp=90, Z=10.0, Rt=90,
        F_target=None, F_ref="F(90)", F_units="min", start_T=70,
        standard="GB 4789.26-2023(酸性)", typical="巴氏85-100℃/15s-2min+热灌装82-95℃",
    ),
    "very_high": dict(
        key="very_high", name="极高酸", pH_range="<3.5", category="高酸性食品(果汁等)",
        microbe="酵母/霉菌/非致病乳酸菌(营养体灭活)",
        D_val=0.75, D_temp=65, Z=8.5, Rt=85,
        F_target=None, F_ref="F(85)", F_units="s", start_T=60,
        standard="短时巴氏", typical="短时巴氏85-95℃/15-20s",
    ),
}
ORDER = ["low_acid", "acid_acidif", "high_acid", "very_high"]


def fdisplay(cat_key: str, f_min: float) -> "tuple[float, str]":
    """按档位把内部分钟值换算成显示单位。极高酸档用秒(s)，其余用分钟(min)。返回 (显示值, 单位)。"""
    if CATEGORIES[cat_key]["F_units"] == "s":
        return f_min * 60.0, "s"
    return f_min, CATEGORIES[cat_key]["F_units"]

CJK_FONT_PATH = "/System/Library/Fonts/STHeiti Light.ttc"


# ───────────────────────── 纯计算函数 ─────────────────────────
def lethal_rate(T: float, Rt: float, Z: float) -> float:
    """致死率 L = 10**((T-Rt)/Z)。"""
    return 10.0 ** ((T - Rt) / Z)


def parse_paste(text: str) -> "tuple[list[float], list[float]]":
    """把用户输入的 温度,时间 文本解析为 (ts, Ts)。
    兼容：'90,0;110,15;121,25'（; 分隔多组）、'时间,温度' 或 '温度,时间' 表头 CSV、stdin 粘贴换行。
    自动识别列序（表头名优先，其次按时间单调不减启发式）。
    同时间戳且同温度的去重；同时间戳不同温度（阶梯工艺跃变边界）两个点都保留。"""
    # 收集原始 (col0, col1) 数值单元
    head0 = head1 = ""
    units: list[tuple[float, float]] = []  # (col0, col1)
    for ln in text.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        for unit in re.split(r"[;；]+", ln):
            unit = unit.strip()
            if not unit:
                continue
            parts = re.split(r"[,，\s]+", unit)
            nums = [p for p in parts if _is_num(p)]
            if len(nums) >= 2:
                units.append((float(nums[0]), float(nums[1])))
            elif len(nums) == 1:
                raise ValueError(f"无法解析行，缺少时间或温度: {ln}")
            elif head0 == "" and parts and not parts[0][0].isdigit():
                head0, head1 = parts[0], (parts[1] if len(parts) > 1 else "")
    if not units:
        raise ValueError("未解析到任何 温度,时间 数据对")
    # 判断列序：col0 是时间(非温度) 则 (t,col1)=温度
    time_first = _is_header_time(head0)
    if time_first is None:  # 无表头 → 用启发式
        c0 = [u[0] for u in units]
        c1 = [u[1] for u in units]
        c0asc = all(b >= a for a, b in zip(c0, c0[1:]))
        c1asc = all(b >= a for a, b in zip(c1, c1[1:]))
        # 更稳健：时间列应有非零变化量(单调不减且不全相等)；常量列判定为温度。
        # 若两列都单调，取"变化量更大"的一方为时间(时间通常覆盖更宽范围)。
        span0 = max(c0) - min(c0)
        span1 = max(c1) - min(c1)
        if c0asc and not c1asc:
            time_first = True          # 仅 col0 单调 → col0 是时间
        elif c1asc and not c0asc:
            time_first = False         # 仅 col1 单调 → col1 是时间
        else:
            time_first = span0 > span1  # 都单调/都常量：变化量大者为时间(常量→温度)
    pairs = [(u[0], u[1]) if time_first else (u[1], u[0]) for u in units]  # (t, T)
    # 排序+去重。重要：同一时间戳若温度相同则去重；若温度不同则保留两个点
    # （阶梯工艺如 115℃结束→82℃起始 会共用一个时间戳，两温度都必须保留，
    #  否则前一温度段被抹掉导致 F 严重低估）。
    pairs.sort(key=lambda x: x[0])
    out = []
    for t, T in pairs:
        if out and abs(t - out[-1][0]) < 1e-9 and abs(T - out[-1][1]) < 1e-9:
            continue  # 同t同T → 去重
        out.append((t, T))
    ts = [p[0] for p in out]
    Ts = [p[1] for p in out]
    return ts, Ts


def _is_header_time(h: str) -> "bool | None":
    """由表头判断首列是否为时间：时间→True，温度→False，未知→None。"""
    if not h:
        return None
    hl = h.lower()
    if any(k in hl for k in ("时间", "min", "分钟", "t(", "历时", "time")):
        return True
    if any(k in hl for k in ("温度", "度", "℃", "°c", "temp", "tdeg")):
        return False
    return None


def _is_num(s: str) -> bool:
    try:
        float(s)
        return True
    except (ValueError, TypeError):
        return False


def trapezoid(ts: list, Ts: list, Rt: float, Z: float, start_T: float) -> float:
    """梯形积分 F=∫L dt，仅累计 T>=start_T 的区间。"""
    F = 0.0
    for i in range(1, len(ts)):
        l0 = lethal_rate(Ts[i - 1], Rt, Z) if Ts[i - 1] >= start_T else 0.0
        l1 = lethal_rate(Ts[i], Rt, Z) if Ts[i] >= start_T else 0.0
        F += (l0 + l1) / 2.0 * (ts[i] - ts[i - 1])
    return F


def simpson_integration(ts: list, Ts: list, Rt: float, Z: float, start_T: float) -> float:
    """辛普森 1/3 积分 F=∫L dt，仅累计 T>=start_T 的区间。
    辛普森要求偶数个区间（即奇数个点）。内部取 0..m（m 为偶数）做辛普森，
    余下最后一段用梯形补齐，规避点数奇偶不定问题。
    注意：仅对有*平滑连续*热穿透曲线的冷点数据使用；阶梯恒温工艺请用 stepwise_F。"""
    # 对每个采样点的致死率（低于 start_T 视为 0）
    L = [lethal_rate(T, Rt, Z) if T >= start_T else 0.0 for T in Ts]
    nn = len(L)
    if nn < 2:
        return 0.0
    # 等距采样假设下用辛普森；非等距退化为梯形
    h = ts[1] - ts[0]
    uniform = all(abs((ts[i + 1] - ts[i]) - h) < 1e-6 for i in range(nn - 1))
    if not uniform:
        return trapezoid(ts, Ts, Rt, Z, start_T)
    n = nn - 1                     # 区间数
    if n == 1:                     # 单区间(两 2 点)→梯形，(L0+L1)/2*h，避免反超计
        return (L[0] + L[1]) / 2.0 * h
    m = n if n % 2 == 0 else n - 1  # 偶数个区间做辛普森；奇数则留一段梯形
    F = (L[0] + L[m]) * h / 3.0
    for i in range(1, m):
        F += (4 if i % 2 == 1 else 2) * L[i] * h / 3.0
    if m < n:                     # 补最后一段梯形
        F += (L[m] + L[n]) / 2.0 * h
    return F


def stepwise_F(ts: list, Ts: list, Rt: float, Z: float, start_T: float) -> float:
    """逐段常量积分 F=Σ L(T段起点)×Δt。
    杀菌/巴氏工艺多为逐段恒温（如 96℃ 保持后跳 82℃），温度在每个区间[[t_i,t_{i+1}))
    内取左端点视为恒定，严格等于每条停留段的等值致死量之和。
    对阶梯两段 (0,115)(4/60,115)(4/60,82)(45+4/60,82) → L(115)×4/60 + L(82)×45。"""
    F = 0.0
    for i in range(1, len(ts)):
        if Ts[i - 1] >= start_T:
            F += lethal_rate(Ts[i - 1], Rt, Z) * (ts[i] - ts[i - 1])
    return F


def cold_spot_F(ts: list, Ts: list, cat_key: str, method: str = "stepwise") -> float:
    """按档位参数对整条冷点曲线做致死量积分。
    method: stepwise(默认,阶梯恒温工艺) / simpson / trapezoid(连续曲线)。"""
    c = CATEGORIES[cat_key]
    if method == "trapezoid":
        return trapezoid(ts, Ts, c["Rt"], c["Z"], c["start_T"])
    if method == "simpson":
        return simpson_integration(ts, Ts, c["Rt"], c["Z"], c["start_T"])
    return stepwise_F(ts, Ts, c["Rt"], c["Z"], c["start_T"])


def pick_category(ph: "float | None") -> str:
    """由 pH 自动选档。ph 为空时返回 None，提示手选。"""
    if ph is None:
        return ""
    ph = float(ph)
    if ph > 4.6:
        return "low_acid"
    if 4.0 <= ph <= 4.6:
        return "acid_acidif"
    if 3.5 <= ph < 4.0:
        return "high_acid"
    return "very_high"


def isobaric_F(D: float, n: float) -> float:
    """等温粗算 F = D × n（n 为 D 的倍数）。"""
    return D * n


def validate_commercial(days: int, temp: float, ph: float,
                        swell: bool, pH_delta: float, smear: bool) -> "tuple[bool, str]":
    """商业无菌保温判定（GB 4789.26-2023）。
    通过需：不胀罐(不漏) + pH差<0.5 + 无显著增殖(涂片阴性)。返回 (通过, 说明)。"""
    reasons = []
    ok = True
    if swell:
        ok = False
        reasons.append("胀罐/漏罐")
    if pH_delta >= 0.5:
        ok = False
        reasons.append("pH 差>=0.5 报警")
    if smear:
        ok = False
        reasons.append("涂片镜检有显著增殖")
    # 保温条件是否与产品类别匹配（提示，不强制失败）
    cat = pick_category(ph)
    note = f"产品归档:{CATEGORIES[cat]['name']}(pH {CATEGORIES[cat]['pH_range']})"
    if ok:
        return True, f"判定通过：保温 {temp:.0f}℃×{days}天 后不胀不漏、pH差{pH_delta}<0.5、涂片阴性。{note}"
    return False, f"判定不通过：{('、'.join(reasons))}。{note}"


# ───────────────────────── 输入读取 ─────────────────────────
def read_series(args) -> "tuple[list, list, str]":
    """按参数读取温度-时间序列。返回 (ts, Ts, 来源描述)。"""
    if args.temp_line:
        ts, Ts = parse_paste(args.temp_line)
        return ts, Ts, "内联参数 --temp-line"
    if args.file:
        with open(args.file, encoding="utf-8-sig") as f:
            ts, Ts = parse_paste(f.read())
        return ts, Ts, f"文件 {args.file}"
    # stdin
    if not sys.stdin.isatty():
        raw = sys.stdin.read()
        if raw.strip():
            ts, Ts = parse_paste(raw)
            return ts, Ts, "stdin 标准输入"
    raise SystemExit("错误：未提供温度-时间数据。请用 --temp-line、--file 或在管道中粘贴 '温度,时间'。")


# ───────────────────────── 报告 PDF ─────────────────────────
def _register_cjk_font():
    """注册中文字体用于 PDF。按候选顺序查找存在的字体文件；全缺失则回退内置字体并提示。"""
    import os
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    candidates = [
        ("STHeiti", "/System/Library/Fonts/STHeiti Light.ttc"),
        ("STHeiti", "/System/Library/Fonts/STHeiti Medium.ttc"),
        ("PingFangSC", "/System/Library/Fonts/PingFang.ttc"),
        ("HeitiSC", "/System/Library/Fonts/Hiragino Sans GB.ttc"),
        ("NotoSansCJKsc", "/System/Library/Fonts/NotoSansCJKsc-Regular.otf"),
    ]
    for name, path in candidates:
        if os.path.exists(path):
            try:
                pdfmetrics.registerFont(TTFont("CJK", path, subfontIndex=0))
                return "CJK", path
            except Exception:
                try:
                    pdfmetrics.registerFont(TTFont("CJK", path))
                    return "CJK", path
                except Exception:
                    continue
    return None, ""


def build_report(out_pdf: str, cat_key: str, f_val: "float|None", target: "float|None",
                 verdict: str, ts: list, Ts: list) -> None:
    """用 reportlab 生成可打印 PDF（含中文，自动探测系统 CJK 字体）。"""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                    Table, TableStyle)
    from reportlab.lib.styles import ParagraphStyle

    fname, fontpath = _register_cjk_font()
    if fname is None:
        print("⚠️ 未找到系统中文字体，PDF 中文可能显示为方块。可安装 STHeiti/PingFang 等字体后重试。")

    c = CATEGORIES[cat_key]
    doc = SimpleDocTemplate(out_pdf, pagesize=A4,
                            rightMargin=44, leftMargin=44, topMargin=44, bottomMargin=44)
    f1 = fname or "Helvetica"
    h1 = ParagraphStyle("h1", fontName=f1, fontSize=16, leading=22, spaceAfter=8)
    h2 = ParagraphStyle("h2", fontName=f1, fontSize=12, leading=16, spaceBefore=8, spaceAfter=4)
    base = ParagraphStyle("base", fontName=f1, fontSize=10, leading=14)
    cell = ParagraphStyle("cell", fontName=f1, fontSize=9, leading=12)
    cellb = ParagraphStyle("cellb", fontName=f1, fontSize=9, leading=12)

    disp_f, disp_unit = fdisplay(cat_key, f_val if f_val is not None else 0.0)
    if target is not None:
        disp_target, disp_unit = fdisplay(cat_key, float(target))

    el = []
    el.append(Paragraph("杀菌值（F 值）计算报告", h1))
    el.append(Paragraph(f"产品类别：{c['name']}（{c['category']}，平衡 pH {c['pH_range']}）", base))
    el.append(Paragraph(f"目标微生物：{c['microbe']}", base))
    el.append(Paragraph(f"F 体系：{c['F_ref']} ｜ Rt={c['Rt']}℃ ｜ Z={c['Z']}℃ ｜ 依据 {c['standard']}", base))
    el.append(Spacer(1, 8))

    rows = [["指标", "数值", "判定"]]
    if f_val is not None:
        rows.append([f"冷点致死量 {c['F_ref']}", f"{disp_f:.3f} {disp_unit}",
                     "达标" if f_val >= (target or 0) else "未达标"])
    if target is not None:
        rows.append(["目标 F 值", f"≥ {disp_target:.3f} {disp_unit}", "-"])
    rows.append(["综合判定", verdict, "-"])
    t = Table(rows, colWidths=[150, 150, 90])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dbeafe")),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#bfdbfe")),
        ("FONTNAME", (0, 0), (-1, -1), f1),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    el.append(t)
    el.append(Spacer(1, 12))

    el.append(Paragraph("冷点温度-时间采样（部分）", h2))
    data = [[Paragraph("时间(min)", cellb), Paragraph("温度(℃)", cellb)]]
    step = max(1, len(ts) // 20)
    for i in range(0, len(ts), step):
        data.append([Paragraph(f"{ts[i]:.1f}", cell), Paragraph(f"{Ts[i]:.1f}", cell)])
    tt = Table(data, colWidths=[150, 150])
    tt.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#e2e8f0")),
        ("FONTNAME", (0, 0), (-1, -1), f1),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    el.append(tt)
    el.append(Spacer(1, 10))
    el.append(Paragraph("说明：冷却段已计入；高酸/极高酸档无单一 F 目标，以保温+镜检+培养兜底。", base))
    doc.build(el)


# ───────────────────────── 子命令 ─────────────────────────
def cmd_cfg(args):
    keys = [args.key] if args.key else ORDER
    for k in keys:
        c = CATEGORIES[k]
        print(f"[{c['name']}] pH {c['pH_range']} ｜ {c['category']}")
        print(f"  目标菌 : {c['microbe']}")
        print(f"  F体系   : {c['F_ref']} ｜ Rt={c['Rt']}℃ ｜ Z={c['Z']}℃ ｜ 起点>={c['start_T']}℃")
        print(f"  参考D值 : D_{c['D_temp']:.0f}≈{c['D_val']} min")
        print(f"  F目标   : {'≥ '+str(c['F_target'])+' '+c['F_units'] if c['F_target'] is not None else '无单一F目标(保温+镜检兜底)'}")
        print(f"  依据    : {c['standard']} ｜ 典型: {c['typical']}")
        print()


def cmd_calc(args):
    ts, Ts, src = read_series(args)
    # 选档：--key 优先，其次 --ph，否则启发式
    if args.key:
        cat_key = args.key
    elif args.ph is not None:
        cat_key = pick_category(args.ph)
        if not cat_key:
            raise SystemExit("错误：无法由 ph 选档")
    else:
        maxT = max(Ts)
        cat_key = "low_acid" if maxT >= 110 else ("acid_acidif" if maxT >= 90 else "high_acid")
        print(f"提示：未给 --ph/--key，按最高温 {maxT:.0f}℃ 启发式选档 → {CATEGORIES[cat_key]['name']}（请人工确认）")

    # 反模式提示：pH 邻近低酸红线(4.6)时，产品可能在酸化/低酸间漂移，建议按低酸 F₀ 复核
    if args.ph is not None and args.key is None and 4.55 < float(args.ph) <= 4.6:
        print("⚠️ pH 邻近 4.6 低酸红线：现按中酸/酸化体系核算，但轻微波动即可能漂移为低酸食品，建议另按低酸 F₀ 复核一次。")

    c = CATEGORIES[cat_key]
    override = {}
    if args.Rt:
        override["Rt"] = args.Rt
    if args.Z:
        override["Z"] = args.Z
    Rt, Z = override.get("Rt", c["Rt"]), override.get("Z", c["Z"])

    def _integrate(tts, tTs, rRt, zZ, sT):
        if args.method == "trapezoid":
            return trapezoid(tts, tTs, rRt, zZ, sT)
        if args.method == "simpson":
            return simpson_integration(tts, tTs, rRt, zZ, sT)
        return stepwise_F(tts, tTs, rRt, zZ, sT)  # stepwise 默认

    # 若自定义 Rt/Z，则独立积分（起点用档位 start_T）；否则按档位体系
    if override:
        f_val = _integrate(ts, Ts, Rt, Z, c["start_T"])
        f_ref = f"F({Z:g}/{Rt:g})"
        target = None
    else:
        f_val = cold_spot_F(ts, Ts, cat_key, args.method)
        f_ref, target = c["F_ref"], c["F_target"]

    disp_f, disp_unit = fdisplay(cat_key, f_val)
    if target is not None:
        disp_target, _ = fdisplay(cat_key, float(target))

    print(f"来源: {src} ｜ 采样点 {len(ts)} ｜ 档位: {c['name']}({c['category']}, pH {c['pH_range']})")
    print(f"F体系: {f_ref} ｜ Rt={Rt}℃ ｜ Z={Z}℃ ｜ 方法={args.method}")
    print(f"冷点致死量 = {disp_f:.3f} {disp_unit}")

    if target is not None:
        diff_wrong = f_val - target  # 单位一致均为内部 min
        diff_disp, _ = fdisplay(cat_key, abs(diff_wrong))
        mark = "✅ 达标" if diff_wrong >= 0 else "❌ 未达标"
        sign = "+" if diff_wrong >= 0 else ""
        print(f"目标 F ≥ {disp_target:.3f} {disp_unit} ｜ {mark} ｜ 离目标 {sign}{diff_disp:.3f} {disp_unit}")
        if diff_wrong < 0:
            print("建议：工艺偏短或冷点温度偏低，请延长保温/升温至符合商业无菌；辅以保温试验验证。")
        else:
            print("建议：已达标；若远超目标（如低酸按酸性折算）注意过度杀菌对质构的影响。")
    else:
        print("本档无单一 F 目标：请以 GB 4789.26-2023 保温试验(不胀不漏+pH差<0.5+涂片阴性+培养阴性)为最终判据。")

    verdict = "达标" if (target is not None and f_val >= target) else "待保温/镜检确认"
    if args.report:
        build_report(args.report, cat_key, f_val, target, verdict, ts, Ts)
        print(f"报告已生成: {args.report}")


def cmd_isobaric(args):
    F = isobaric_F(args.D, args.n)
    print(f"等温粗算：F = D×n = {args.D} × {args.n} = {F:.3f} min")
    print("说明：用于快速估算特定温度下的杀菌强度；精确起见请用热穿透积分(calc)。")


def cmd_validate(args):
    ok, msg = validate_commercial(args.days, args.temp, args.ph,
                                  args.swell, args.pH_delta, args.smear)
    print(("✅ " if ok else "❌ ") + msg)


def cmd_dump(args):
    with open(args.infile, encoding="utf-8-sig") as f:
        ts, Ts = parse_paste(f.read())
    print(f"解析到 {len(ts)} 个采样点：")
    for t, T in zip(ts, Ts):
        print(f"  t={t:8.2f} min   T={T:6.2f}℃")


# ───────────────────────── main ─────────────────────────
def main():
    ap = argparse.ArgumentParser(prog="fvalue_calc.py",
                                 description="杀菌值计算器：低酸→高酸产品 F 值/热穿透/商业无菌")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_cfg = sub.add_parser("cfg", help="列出四档参数表")
    p_cfg.add_argument("--key", choices=ORDER)

    p_calc = sub.add_parser("calc", help="热穿透积分求 F 值(含冷却段)")
    p_calc.add_argument("--ph", type=float, help="产品平衡pH，用于自动选档")
    p_calc.add_argument("--key", choices=ORDER, help="手动选档")
    p_calc.add_argument("--file", help="CSV/txt 文件：每行 '温度,时间'")
    p_calc.add_argument("--temp-line", help="内联数据，如 '90,0;110,15;121,25;121,35;90,45'")
    p_calc.add_argument("--method", choices=["stepwise", "simpson", "trapezoid"],
                        default="stepwise", help="积分方法：stepwise逐段常量(默认,阶梯恒温工艺) / simpson / trapezoid(连续曲线)")
    p_calc.add_argument("--Rt", type=float, help="覆盖基准温度(℃)")
    p_calc.add_argument("--Z", type=float, help="覆盖 Z 值(℃)")
    p_calc.add_argument("--report", help="输出PDF报告路径")

    p_iso = sub.add_parser("isobaric", help="等温粗算 F=D×n")
    p_iso.add_argument("--D", type=float, required=True)
    p_iso.add_argument("--n", type=float, required=True)

    p_val = sub.add_parser("validate", help="商业无菌保温判定(GB4789.26-2023)")
    p_val.add_argument("--days", type=int, required=True)
    p_val.add_argument("--temp", type=float, required=True)
    p_val.add_argument("--ph", type=float, required=True)
    p_val.add_argument("--swell", action="store_true", help="出现胀罐/漏罐")
    p_val.add_argument("--pH-delta", type=float, default=0.0, help="保温前后 pH 差(报警阈值0.5)")
    p_val.add_argument("--smear", action="store_true", help="涂片镜检见显著增殖")

    p_dump = sub.add_parser("dump", help="打印解析后的温度-时间对")
    p_dump.add_argument("--in", dest="infile", required=True)

    args = ap.parse_args()
    {
        "cfg": cmd_cfg, "calc": cmd_calc,
        "isobaric": cmd_isobaric, "validate": cmd_validate,
        "dump": cmd_dump,
    }[args.cmd](args)


if __name__ == "__main__":
    main()
