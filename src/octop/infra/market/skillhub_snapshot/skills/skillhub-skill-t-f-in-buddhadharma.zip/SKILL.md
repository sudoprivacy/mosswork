---
name: skillhub-skill-t-f-in-buddhadharma
description: "当用户在佛法修行中遇到以下任一类情形时调用，按对应专题读取 references 下的详细内容后作答：魔境与圣境的判别（mojing-shengjing-panbie）；越分欲得防着魔（yuefen-yu-de-fang-zhaomo）；戒求感应神通（jie-qiu-ganying-shentong）；持名念佛指归净土（chiming-nianfo-zhigui-jingtu）；禅净正见防狂禅（chan-jing-zhengjian-fang-kuangchan）；辨外道邪法（bian-waidao-xiefa）；具择法眼防好高（ju-zefayan-fang-haogao）；楞严五十阴魔（lengyan-wushi-yinmo）；境界现前应对（jingjie-xianqian-yingdui）。不适用于：纯世俗决策、未涉及修行境界的话题、纯宗教学术考据。"
---

# 佛法修行止偏法要 · 总技能

## 概述
本技能将《佛法修行止偏法要》（印光大师《文钞》选编）蒸馏出的 9 个修行止偏专题整合为单一入口，覆盖修行中见境界、着魔、求感应神通、选法门、狂禅、外道、好高、五十阴魔、境界现前等情形的辨析与对治。

## 9 个专题索引
| 专题 | 触发场景（摘要） | 详细内容 |
|------|------------------|----------|
| 魔境与圣境的判别 | 当用户描述修行中\"见光、见佛、见境界、身心异相\"并问\"这是好是坏、是魔是圣\"时调用。 不适用 | references/mojing-shengjing-panbie.md |
| 越分欲得防着魔 | 当用户修行中\"急着想见佛、急得一心不乱、想速证、妄期圣证、刻期求往生、想即身成佛\"时调用。 不适 | references/yuefen-yu-de-fang-zhaomo.md |
| 戒求感应神通 | 当用户修行中\"求感通、求神通、想得道得先知、羡慕他人神异\"时调用。 不适用于：已得轻安却不起贪著 | references/jie-qiu-ganying-shentong.md |
| 持名念佛指归净土 | 当用户在\"选什么法门/要不要舍持名改观法/觉得念佛浅近/想禅净双修/好高务胜\"时调用。 不适用于 | references/chiming-nianfo-zhigui-jingtu.md |
| 禅净正见防狂禅 | 当用户出现\"我本是佛何必念佛/心净则土净何必求生/只要心好不必持斋/口头禅机锋/拨无因果/执理废事 | references/chan-jing-zhengjian-fang-kuangchan.md |
| 辨外道邪法 | 当用户遇到\"扶乩/扶鸾、炼丹运气、自称活佛/传人、密宗神通吸人、私相授受的秘密法\"并问\"这是不 | references/bian-waidao-xiefa.md |
| 具择法眼防好高 | 当用户\"想当通家/想学遍深经/好高骛远/妄效过量圣人/不知法门量力/被高人动摇净土信根\"时调用。 | references/ju-zefayan-fang-haogao.md |
| 楞严五十阴魔 | 当用户境界问题超出常识判别、需要\"权威标尺\"对照时调用；尤其当境界涉及\"见佛菩萨/身体异变/智 | references/lengyan-wushi-yinmo.md |
| 境界现前应对 | 当用户\"修行中境界已经现前（见善恶相/黑影/光明/身体震动），不知当下该怎么做\"时调用。 不适用 | references/jingjie-xianqian-yingdui.md |

## 使用方式
1. 识别用户问题属于上表哪个专题（参考各专题 description 中的触发词）。
2. 读取对应 `references/<slug>.md`。
3. 按其 RIA++ 结构（原文 R / 解读 I / 行动 A1 / 场景 A2 / 执行 E / 边界 B）组织回答，扎根原文、不臆造。

## 边界声明
本内容为修行参考，非诊断或医疗建议；涉及身心异常，请依止具德善知识并及时就医。
