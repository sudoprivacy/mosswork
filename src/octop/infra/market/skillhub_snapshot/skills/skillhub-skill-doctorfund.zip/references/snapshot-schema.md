# 快照结构

```json
{
  "schemaVersion": "1.0",
  "status": "live | snapshot | example",
  "asOf": "YYYY-MM-DD",
  "fund": {"code": "014841.OF", "name": "基金名称"},
  "sources": [{"name": "Wind", "asOf": "YYYY-MM-DD", "method": "get_fund_info"}],
  "modules": {
    "fundamentals": {"summary": "...", "facts": ["..."]},
    "returns": {"summary": "...", "facts": ["..."]},
    "drawdown": {"summary": "...", "facts": ["..."]},
    "sharpe": {"summary": "...", "facts": ["..."]},
    "consistency": {"summary": "...", "facts": ["..."]}
  }
}
```

所有事实应能回溯到 `sources`。缺失模块仍需保留键，并把 `summary` 写成“暂无可验证数据”。
