import json
import unittest
from pathlib import Path

from run_diagnosis import load_snapshot, render_markdown, validate_snapshot


ROOT = Path(__file__).resolve().parents[1]


class SnapshotTests(unittest.TestCase):
    def test_example_snapshot_validates_and_renders(self):
        data = load_snapshot(ROOT / "references" / "example-snapshot.json")
        rendered = render_markdown(data)
        self.assertIn("014841.OF", rendered)
        self.assertIn("数据状态：example", rendered)
        self.assertIn("不构成投资建议", rendered)

    def test_rejects_snapshot_without_sources(self):
        data = json.loads((ROOT / "references" / "example-snapshot.json").read_text(encoding="utf-8"))
        data["sources"] = []
        with self.assertRaisesRegex(ValueError, "sources"):
            validate_snapshot(data)

    def test_rejects_wrong_code(self):
        data = json.loads((ROOT / "references" / "example-snapshot.json").read_text(encoding="utf-8"))
        data["fund"]["code"] = "not-a-code"
        with self.assertRaisesRegex(ValueError, "fund.code"):
            validate_snapshot(data)


if __name__ == "__main__":
    unittest.main()
