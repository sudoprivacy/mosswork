#!/usr/bin/env python3
"""Validate and render a Fund Doctor snapshot. No network access."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


CODE_RE = re.compile(r"^\d{6}(?:\.(?:OF|SH|SZ))?$")
REQUIRED_MODULES = ("fundamentals", "returns", "drawdown", "sharpe", "consistency")


def load_snapshot(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    validate_snapshot(data)
    return data


def validate_snapshot(data: dict) -> None:
    if not isinstance(data, dict):
        raise ValueError("snapshot must be a JSON object")
    fund = data.get("fund")
    if not isinstance(fund, dict):
        raise ValueError("fund must be an object")
    code = fund.get("code", "")
    if not CODE_RE.fullmatch(code):
        raise ValueError("fund.code must be a 6-digit code with an optional OF/SH/SZ suffix")
    if not str(fund.get("name", "")).strip():
        raise ValueError("fund.name is required")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(data.get("asOf", ""))):
        raise ValueError("asOf must use YYYY-MM-DD")
    sources = data.get("sources")
    if not isinstance(sources, list) or not sources:
        raise ValueError("sources must be a non-empty list")
    for source in sources:
        if not isinstance(source, dict) or not source.get("name") or not source.get("asOf"):
            raise ValueError("each source requires name and asOf")
    modules = data.get("modules")
    if not isinstance(modules, dict):
        raise ValueError("modules must be an object")
    missing = [name for name in REQUIRED_MODULES if name not in modules]
    if missing:
        raise ValueError("missing modules: " + ", ".join(missing))


def render_markdown(data: dict) -> str:
    fund = data["fund"]
    lines = [
        f"# 基金五维诊断 · {fund['name']}（{fund['code']}）",
        "",
        f"> 数据状态：{data.get('status', 'snapshot')} · 截止日期：{data['asOf']}",
        "> 数据来源：" + "、".join(source["name"] for source in data["sources"]),
        "",
    ]
    titles = {
        "fundamentals": "① 基本面",
        "returns": "② 收益率",
        "drawdown": "③ 最大回撤",
        "sharpe": "④ 夏普比率",
        "consistency": "⑤ 知行合一",
    }
    for key in REQUIRED_MODULES:
        module = data["modules"][key]
        lines.extend((f"## {titles[key]}", ""))
        if isinstance(module, dict):
            lines.append(str(module.get("summary", "暂无可验证数据")))
            facts = module.get("facts", [])
            for fact in facts if isinstance(facts, list) else []:
                lines.append(f"- {fact}")
        else:
            lines.append(str(module))
        lines.append("")
    lines.append("以上内容仅作信息整理，不构成投资建议、收益预测或交易依据。")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="snapshot JSON path")
    parser.add_argument("--format", choices=("markdown", "json"), default="markdown")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        data = load_snapshot(args.input)
        rendered = json.dumps(data, ensure_ascii=False, indent=2) if args.format == "json" else render_markdown(data)
        if args.output:
            args.output.write_text(rendered + "\n", encoding="utf-8")
        else:
            print(rendered)
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as error:
        print(f"VALIDATION_ERROR: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
