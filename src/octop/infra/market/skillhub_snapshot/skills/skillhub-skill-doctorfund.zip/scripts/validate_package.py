#!/usr/bin/env python3
"""Validate the Fund Doctor package for SkillHub and Agent Skills."""

from __future__ import annotations

import re
import sys
from pathlib import Path


REQUIRED_FIELDS = {
    "slug",
    "displayName",
    "name",
    "description",
    "version",
    "summary",
    "license",
}
ALLOWED_TOP_LEVEL = {
    "slug",
    "displayName",
    "name",
    "description",
    "version",
    "summary",
    "license",
}


def parse_frontmatter(text: str) -> dict[str, str]:
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.DOTALL)
    if not match:
        raise ValueError("SKILL.md must start with YAML frontmatter")
    fields: dict[str, str] = {}
    for raw_line in match.group(1).splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            raise ValueError(f"invalid frontmatter line: {raw_line}")
        key, value = line.split(":", 1)
        fields[key.strip()] = value.strip()
    return fields


def validate(root: Path) -> None:
    skill_path = root / "SKILL.md"
    if not skill_path.is_file():
        raise ValueError("SKILL.md is missing from package root")
    text = skill_path.read_text(encoding="utf-8")
    fields = parse_frontmatter(text)
    missing = sorted(REQUIRED_FIELDS - fields.keys())
    if missing:
        raise ValueError("missing SkillHub fields: " + ", ".join(missing))
    unexpected = sorted(fields.keys() - ALLOWED_TOP_LEVEL)
    if unexpected:
        raise ValueError("unexpected frontmatter fields: " + ", ".join(unexpected))
    name = fields.get("name", "")
    if name and not re.fullmatch(r"[a-z0-9-]{1,64}", name):
        raise ValueError("name must use lowercase letters, digits, and hyphens")
    slug = fields.get("slug", "")
    if not re.fullmatch(r"[a-z0-9-]{3,80}", slug):
        raise ValueError("slug must use 3-80 lowercase letters, digits, and hyphens")
    if not re.fullmatch(r"\d+\.\d+\.\d+", fields["version"]):
        raise ValueError("version must use semantic versioning")
    for relative in re.findall(r"\]\((references/[^)]+)\)", text):
        if not (root / relative).is_file():
            raise ValueError(f"missing referenced file: {relative}")
    banned_suffixes = {".pyc", ".pyo", ".key", ".pem"}
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in banned_suffixes:
            raise ValueError(f"forbidden generated or sensitive file: {path.relative_to(root)}")


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    try:
        validate(root)
    except (OSError, ValueError) as error:
        print(f"PACKAGE_INVALID: {error}", file=sys.stderr)
        return 2
    print("PACKAGE_OK: SkillHub frontmatter, references, and file policy validated")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
