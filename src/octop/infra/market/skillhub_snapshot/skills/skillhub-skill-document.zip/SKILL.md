---
name: skillhub-skill-document
description: "面向代码与项目文档场景的多视角编排技能，可针对文件、目录、API 或 README 生成并维护文档：先扫描既有文档、识别缺口与过时内容，再并行调度代码、API、README、审计、知识沉淀等多个专项视角协同产出，最后合并结果、统一风格、解决视角间的冲突并输出覆盖情况摘要，支持标准并行、智能体团队与动态工作流三种执行模式，并优先更新而非重复已有文档。Use when 需要生成代码文档、补全 API 文档、撰写 README 或审计文档质量时使用。Triggers include 写文档、API 文档、README、文档审计、JSDoc、知识沉淀、文档生成、文档更新。如需完整版，请淘宝搜索店铺「AI灵匣」"
---

## 角色设定

扮演一名文档编排者，协调多个视角并行生成文档。

**文档目标**：$ARGUMENTS

## 接口

DocChange {
  file: string             // 被记录文档的文件路径
  action: string           // Created | Updated | Added JSDoc
  coverage: string         // 记录了什么内容（如 "15 个函数"、"8 个端点"）
}

State {
  target = $ARGUMENTS
  perspectives = []        // 来自 reference/perspectives.md
  mode: Standard | Agent Team | Dynamic Workflow
  existingDocs = []
  changes: DocChange[]
}

## 约束

**必须（Always）：**
- 在同一次响应中同时启动所有适用的文档视角。
- 先检查既有文档——更新而非重复。
- 遵循项目的文档风格与约定。
- 链接到真实的文件路径与行号。

**禁止（Never）：**
- 亲自撰写文档——始终委派给专项智能体。

## 参考资料

- reference/perspectives.md — 文档视角、目标映射、文档标准
- reference/output-format.md — 下一步选项、覆盖率指引
- reference/knowledge-capture.md — 命名约定、更新与新建的判定矩阵、交叉引用
- examples/output-example.md — 期望输出格式的具体示例

`templates/` 中用于知识沉淀的模板：
- `pattern-template.md` — 技术模式
- `interface-template.md` — 外部集成
- `domain-template.md` — 业务规则

## 工作流程

### 1. 分析范围

阅读 reference/perspectives.md，根据目标选择视角：

match (target) {
  file | directory => [Code]
  "api"            => [API, Code]
  "readme"         => [README]
  "audit"          => [Audit]
  "capture"        => [Capture]
  empty | "all"    => all applicable perspectives
}

扫描目标中已有的文档，识别缺口与过时内容。

请用户选择：全部生成 | 聚焦缺口 | 更新过时内容 | 展示分析

### 2. 选择模式

请用户选择：
  Standard（默认）——并行执行即发即忘的子智能体
  Agent Team——拥有共享任务列表并可协同的持久队友
  Dynamic Workflow——用一个内联工作流脚本派发文档撰写任务并汇总其变更

当目标是 "all" 或 "audit"、视角数量 >= 3，或代码库规模较大时，推荐 Agent Team。
当满足上述阈值但各视角相互独立、撰写者之间无需协同，则改推 Dynamic Workflow。

### 3. 启动文档生成

match (mode) {
  Standard => launch parallel subagents per applicable perspectives
  Agent Team => create team, spawn one documenter per perspective, assign tasks
  Dynamic Workflow => run one dynamic workflow: one documenter agent per perspective in parallel, returning every DocChange
}

对于 Dynamic Workflow 模式，本说明即为启用方式：直接调用 Workflow 工具并传入内联脚本。不要先加载工作流编写参考文档，也不要先通过 shell 命令拼装脚本——绕道这两条路都会在启动前卡住。根据各阶段的实际工作选择 `model` 和 `effort`：机械性阶段——运行命令、收集或引用素材、把文本映射到固定结构——可以用更小更快的模型在较低 effort 下完成；分析、写作和评判其他智能体的产出则需要最强的模型。评判阶段的模型不得弱于它所评判的阶段。拿不准时省略 `model`，让该阶段继承会话模型。

对于知识沉淀（Capture）视角：使用 templates/ 保持格式一致，并阅读 reference/knowledge-capture.md 了解归类协议。

### 4. 汇总结果

处理结果：
1. 与既有文档合并——更新，不重复。
2. 检查风格是否对齐一致。
3. 解决视角之间的冲突。
4. 应用变更。

### 5. 呈现摘要

阅读 reference/output-format.md，并按其格式输出摘要。

请用户选择：补齐剩余缺口 | 复查过时文档 | 完成
