---
name: skillhub-skill-ai-video-clipper
description: "# AI视频剪辑Skill"
---

# AI视频剪辑Skill

全自动化AI视频剪辑解决方案，实现从素材导入到成片导出的全流程无人干预。

## 核心能力

### 1. 素材智能处理
- **自动识别**：解析视频(mp4/mov/avi/mkv)、音频(mp3/wav)、图片(jpg/png)格式
- **内容分析**：识别场景、人物、动作、文字、音频类型
- **智能筛选**：自动剔除黑屏、模糊、杂音等无效素材

### 2. 剪辑逻辑自主决策
- **风格匹配**：根据内容自动确定剪辑风格（卡点/叙事/快节奏/慢节奏）
- **片段选取**：自动提取高光片段，智能排序确保流畅
- **转场添加**：根据场景切换自动匹配淡入淡出/叠化/闪白等转场
- **时长控制**：精准匹配预设时长（15秒/30秒/1分钟/5分钟等）

### 3. 音频智能优化
- **人声增强**：自动降噪、增强人声清晰度
- **背景音乐**：根据视频节奏自动匹配、卡点同步
- **音效添加**：识别关键动作自动添加对应音效

### 4. 字幕自动生成
- **语音转文字**：自动识别台词，支持中英双语
- **智能排版**：自动调整位置、字体、颜色
- **错误修正**：自动识别并修正错别字

### 5. 特效与优化
- **滤镜匹配**：根据场景（风景/人物/夜景）自动添加
- **画面优化**：自动调整亮度、对比度、饱和度
- **特效添加**：关键片段自动添加光晕/粒子/缩放特效

### 6. 全自动导出
- **智能参数**：根据素材自动设置分辨率/帧率/比特率
- **自动存储**：按"日期+主题+时长"命名，存储至预设路径
- **异常处理**：导出失败自动重试或记录日志

## 使用方式

### 基础剪辑命令
```
用户："帮我剪辑D:\电影下的搞笑片段，生成3-5分钟的搞笑集锦"
```

### 执行流程

#### Step 1: 素材准备
确认素材来源路径，使用 `scripts/analyze_media.py` 分析素材内容：
```bash
python scripts/analyze_media.py --input "D:\电影" --output "D:\AI视频剪辑\素材分析"
```

#### Step 2: 配置剪辑参数
根据用户需求设置：
- **目标时长**：15秒/30秒/1分钟/3分钟/5分钟
- **输出格式**：mp4（推荐）/mov
- **分辨率**：保持原分辨率或指定（如1080p）
- **存储路径**：金山文档同步目录或本地指定路径

#### Step 3: 执行自动剪辑
使用 `scripts/auto_clip.py` 执行全自动剪辑：
```bash
python scripts/auto_clip.py --config "配置文件路径"
```

#### Step 4: 字幕与特效
使用 `scripts/add_subtitles.py` 生成字幕：
```bash
python scripts/add_subtitles.py --input "成片路径" --output "带字幕版本"
```

#### Step 5: 最终导出
使用 `scripts/export_final.py` 导出成片：
```bash
python scripts/export_final.py --input "待导出视频" --preset "高质量/标准/压缩"
```

## 脚本说明

| 脚本 | 功能 | 输入 | 输出 |
|------|------|------|------|
| `analyze_media.py` | 素材分析 | 素材目录 | 分析报告JSON |
| `auto_clip.py` | 自动剪辑 | 分析报告+配置 | 中间视频文件 |
| `audio_process.py` | 音频处理 | 视频文件 | 处理后音频 |
| `add_subtitles.py` | 字幕生成 | 视频文件 | 带字幕视频 |
| `add_effects.py` | 特效添加 | 视频文件 | 添加特效后视频 |
| `export_final.py` | 最终导出 | 处理后视频 | 成片文件 |

## 配置模板

### 默认配置 (references/default_config.yaml)
```yaml
output:
  format: mp4
  resolution: "1920x1080"
  frame_rate: 30
  bitrate: "8M"
  
subtitle:
  enabled: true
  language: "zh-CN"
  position: "bottom_center"
  font_size: 36
  color: "white"
  
audio:
  bgm_volume: 0.3
  voice_volume: 1.0
  enhance_voice: true
  
style:
  transition: "fade"  # fade/ dissolve/ cut/ flash
  transition_duration: 0.5
  filter_preset: "auto"  # auto/ vivid/ vintage/ cool/ warm
  
export:
  storage_path: "D:\AI视频剪辑\成品"
  naming: "{date}_{theme}_{duration}"
```

## 适用场景

| 场景 | 推荐配置 | 预期时长 |
|------|----------|----------|
| 搞笑集锦 | 快节奏卡点+音效 | 3-5分钟 |
| 电影解说 | 叙事风格+字幕 | 5-15分钟 |
| 短视频 | 高潮片段+滤镜 | 15-60秒 |
| Vlog剪辑 | 自然过渡+BGM | 3-10分钟 |
| 教程视频 | 清晰叙事+标注 | 5-30分钟 |

## 技术依赖

- **FFmpeg**：视频处理核心引擎
- **Whisper**：语音识别与字幕生成
- **MoviePy**：Python视频编辑库
- **Pillow**：图像处理
- **NumPy**：数值计算

## 注意事项

1. **首次使用**：需要配置素材路径、输出路径等基础参数
2. **素材要求**：建议使用清晰、无严重抖动的高质量素材
3. **性能**：1-5分钟视频剪辑约需2-3分钟完成
4. **存储**：确保输出路径有足够空间

## 踩坑经验

- 素材路径包含中文时，FFmpeg命令需要使用UTF-8编码
- 字幕生成依赖Whisper模型，首次使用需下载模型文件
- 批量剪辑时建议使用队列管理，避免内存溢出
