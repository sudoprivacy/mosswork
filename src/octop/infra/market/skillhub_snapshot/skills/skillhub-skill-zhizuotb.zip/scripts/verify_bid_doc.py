#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify_bid_doc.py — 投标/响应文件提交前机械体检

四态判定（pass / hit / manual / na）+ 证据三元组（文件·页码·原文）+ 覆盖率。
机器判不了的项一律标 manual，绝不当成"没问题"。

用法:
    python verify_bid_doc.py --bid 商务册.docx [--bid 报价函.docx] \
        [--tender 采购文件.docx] [--info 公司信息.json] \
        [--deadline YYYY-MM-DD] [--max-price 800000] [--asof YYYY-MM-DD] \
        [-o 体检报告.md] [--json 结果.json]

退出码: 0 = 无 P0 命中; 1 = 有 P0 命中; 2 = 用法/文件错误
只依赖 python-docx。
"""

import argparse
import json
import re
import sys
import zipfile
from datetime import date, datetime
from pathlib import Path

try:
    from docx import Document
    from docx.text.paragraph import Paragraph
    from docx.table import Table
except ImportError:
    print("[错误] 缺少依赖：pip install python-docx")
    sys.exit(2)


# ─────────────────────────── 词表 ───────────────────────────

# 待填提示词：出现在括号里 = 模板没填净（致命/形式问题）
# 注意：「（大写）」「（小写）」「（￥）」是格式标签，不是待填提示词，不能放进来。
PROMPT_WORDS = {
    "项目名称", "采购项目名称", "招标项目名称", "供应商名称", "投标人名称",
    "公司名称", "单位名称", "姓名", "地址", "电话", "联系电话", "传真",
    "电子邮箱", "邮箱", "日期", "职务", "金额", "数量", "单价",
    "规格型号", "法定代表人", "被授权人", "委托代理人", "受托人",
    "项目编号", "采购编号", "招标编号", "职务/职称", "身份证号码", "身份证号",
    "邮编", "开户银行", "开户行", "银行账号", "账号",
}

# 保留位：打印后手签/盖章，机器不判，只校验位置存在
RESERVED_WORDS = {
    "盖章", "盖单位章", "盖公章", "公章", "签字", "签名", "手签", "小签",
    "法定代表人签字", "授权代表签字", "单位盖章", "盖章处", "签章",
}

RE_BRACKET = re.compile(r"[（(]([^（）()\n]{1,20})[）)]")
RE_COLON_BLANK = re.compile(r"[：:][ \u3000]{3,}(?=[ \u3000]*(?:$|\n))", re.M)
RE_UNDERLINE = re.compile(r"[_＿]{3,}")
RE_RESIDUAL_DATE = re.compile(r"(?<![\d\s])年[ \u3000]{0,8}月[ \u3000]{0,8}日")
RE_XX_DATE = re.compile(r"20?\s*[xX×]{2}\s*年|[xX×]{1,2}\s*月\s*[xX×]{1,2}\s*日")
RE_CN_DATE = re.compile(r"(20\d{2})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日")
RE_DATE_ONLY = re.compile(r"^[ \u3000]*(20\d{2})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日[ \u3000]*$")
RE_MONEY_LOWER = re.compile(r"[￥¥]\s*([\d,]+(?:\.\d{1,2})?)")
RE_CN_AMOUNT = re.compile(r"[壹贰叁肆伍陆柒捌玖零拾佰仟万亿元圆角分整]{4,}")

DIG = {"零": 0, "壹": 1, "贰": 2, "叁": 3, "肆": 4, "伍": 5,
       "陆": 6, "柒": 7, "捌": 8, "玖": 9}
UNIT = {"拾": 10, "佰": 100, "仟": 1000}
BIG = {"万": 10 ** 4, "亿": 10 ** 8}

# 政府采购 / 招标体系术语
TERM_ALIAS = {
    "投标文件": ["投标文件", "响应文件"],
    "投标人": ["投标人", "供应商"],
    "中标": ["中标", "成交"],
    "评标委员会": ["评标委员会", "询价小组", "磋商小组", "谈判小组"],
    "投标函": ["投标函", "报价函", "响应函"],
}


# ─────────────────────────── 基础工具 ───────────────────────────

def norm(s):
    """去掉空白与常见标点，用于包含判断"""
    if not s:
        return ""
    s = re.sub(r"[\s\u3000]+", "", s)
    return re.sub(r"[，。；：、（）()【】\[\]《》\"'’‘“”…—\-－_]", "", s)


def short(s, n=40):
    s = re.sub(r"[\s\u3000]+", " ", (s or "").strip())
    return s[:n] + ("…" if len(s) > n else "")


def cn_amount(s):
    """中文大写金额 → 数字；解析失败返回 None"""
    s = re.sub(r"[^\u4e00-\u9fa5]", "", s or "")
    s = s.replace("圆", "元")
    if "元" not in s:
        return None
    ip, _, fp = s.partition("元")
    total, section, num = 0, 0, 0
    for ch in ip:
        if ch in DIG:
            num = DIG[ch]
        elif ch in UNIT:
            section += (num if num else 1) * UNIT[ch]
            num = 0
        elif ch in BIG:
            section += num
            total += section * BIG[ch]
            section, num = 0, 0
    total += section + num
    if not total:
        return None
    jiao = fen = 0
    if "角" in fp:
        i = fp.index("角")
        jiao = DIG.get(fp[i - 1], 0) if i > 0 else 0
    if "分" in fp:
        i = fp.index("分")
        fen = DIG.get(fp[i - 1], 0) if i > 0 else 0
    return round(total + jiao / 10 + fen / 100, 2)


def to_num(s):
    """'￥1,234.50' / '1234.5元' → float"""
    if s is None:
        return None
    s = str(s).replace(",", "").replace("￥", "").replace("¥", "")
    s = s.replace("元", "").strip()
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    return float(m.group()) if m else None


def parse_date(y, m, d):
    try:
        return date(int(y), int(m), int(d))
    except Exception:
        return None


def parse_loose_date(s):
    """'2031.02.15' / '2031-02-15' / '2031年2月15日' → date"""
    if not s:
        return None
    s = str(s).strip()
    if s in ("长期", "长期有效", "无", "/", "evergreen"):
        return None
    m = re.search(r"(20\d{2})\s*[年\-\./]\s*(\d{1,2})\s*[月\-\./]\s*(\d{1,2})", s)
    if m:
        return parse_date(*m.groups())
    return None


def blocks_of(doc):
    """按 body 顺序返回 [('p', Paragraph) | ('t', Table)]"""
    out = []
    pmap = {p._element: p for p in doc.paragraphs}
    tmap = {t._element: t for t in doc.tables}
    for child in doc.element.body.iterchildren():
        tag = child.tag.split("}")[-1]
        if tag == "p" and child in pmap:
            out.append(("p", pmap[child]))
        elif tag == "tbl" and child in tmap:
            out.append(("t", tmap[child]))
    return out


def block_text(kind, obj):
    if kind == "p":
        return obj.text or ""
    parts = []
    for row in obj.rows:
        seen = set()
        for cell in row.cells:
            if id(cell._tc) in seen:
                continue
            seen.add(id(cell._tc))
            if cell.text.strip():
                parts.append(cell.text.strip())
    return " ".join(parts)


def build_pages(blocks):
    """按显式分页符切页（推定页码，非排版真实页码）

    关键：分页符常常"上一段末尾有 br、下一段又设了段前分页"，两种都算就会切出空页。
    因此用 pending 标记：只在遇到下一块内容时才真正开新页。
    """
    pages, cur, pending = [], [], False
    for kind, obj in blocks:
        xml = obj._p.xml if kind == "p" else obj._tbl.xml
        brk_before = kind == "p" and "pageBreakBefore" in xml
        if (pending or brk_before) and cur:
            pages.append(cur)
            cur = []
        pending = False
        cur.append((kind, obj))
        if 'w:type="page"' in xml:
            pending = True
    if cur:
        pages.append(cur)
    # 丢掉只有空段落的页
    pages = [p for p in pages if any(block_text(k, o).strip() or "<w:drawing" in
                                     (o._p.xml if k == "p" else o._tbl.xml) for k, o in p)] or pages
    return pages


def page_stats(page):
    chars, imgs = 0, 0
    for kind, obj in page:
        chars += len(block_text(kind, obj))
        xml = obj._p.xml if kind == "p" else obj._tbl.xml
        imgs += xml.count("<w:drawing")
    return chars, imgs


def table_rows(table):
    """去合并单元格重复后的行"""
    rows = []
    for row in table.rows:
        seen, cells = set(), []
        for cell in row.cells:
            if id(cell._tc) in seen:
                continue
            seen.add(id(cell._tc))
            cells.append(cell)
        rows.append(cells)
    return rows


def media_count(path):
    try:
        with zipfile.ZipFile(path) as z:
            return len([n for n in z.namelist() if n.startswith("word/media/") and not n.endswith("/")])
    except Exception:
        return -1


# ─────────────────────────── 上下文 ───────────────────────────

class Ctx:
    def __init__(self, args):
        self.args = args
        self.bid_files = [Path(p) for p in args.bid]
        self.docs, self.blocks, self.pages, self.media = {}, {}, {}, {}
        for p in self.bid_files:
            d = Document(str(p))
            self.docs[p] = d
            self.blocks[p] = blocks_of(d)
            self.pages[p] = build_pages(self.blocks[p])
            self.media[p] = media_count(p)
        self.bid_text = {}
        for p in self.bid_files:
            self.bid_text[p] = "\n".join(block_text(k, o) for k, o in self.blocks[p])
        self.bid_all_norm = norm("\n".join(self.bid_text.values()))

        self.tender_path = Path(args.tender) if args.tender else None
        self.tender_text = ""
        self.tender_doc = None
        if self.tender_path:
            self.tender_doc = Document(str(self.tender_path))
            self.tender_text = "\n".join(
                block_text(k, o) for k, o in blocks_of(self.tender_doc)
            )

        self.info = {}
        if args.info:
            self.info = json.loads(Path(args.info).read_text(encoding="utf-8"))

        self.deadline = parse_loose_date(args.deadline) if args.deadline else None
        self.asof = parse_loose_date(args.asof) if args.asof else date.today()
        self.max_price = args.max_price
        self.findings = []

    # 证据串
    def ev(self, path, page, snippet):
        return f"{path.name} p{page}｜{short(snippet, 50)}"

    def scan(self, patterns):
        """在全部投标文件中扫描，返回 [(path, page, snippet)]"""
        hits = []
        for p in self.bid_files:
            for pno, page in enumerate(self.pages[p], 1):
                for kind, obj in page:
                    text = block_text(kind, obj)
                    if not text:
                        continue
                    for pat in patterns:
                        if re.search(pat, text):
                            hits.append((p, pno, text))
                            break
        return hits


# ─────────────────────────── 检查注册 ───────────────────────────

CHECKS = []


def check(cid, stage, level, consequence, question):
    def deco(fn):
        CHECKS.append(dict(id=cid, stage=stage, level=level,
                           consequence=consequence, question=question, fn=fn))
        return fn
    return deco


def add(ctx, meta, status, evidence="", items=None):
    ctx.findings.append(dict(
        id=meta["id"], stage=meta["stage"], level=meta["level"],
        consequence=meta["consequence"], question=meta["question"],
        status=status, evidence=evidence, items=items or [],
    ))


# ── S1 资格性 ──────────────────────────────────────────────

@check("S1-1", "S1 资格性", "P0", "一票否决", "资质/证照是否在投标截止日仍有效？")
def chk_cert_expiry(ctx):
    certs = (ctx.info or {}).get("certs") or []
    if not certs:
        return add(ctx, META["S1-1"], "manual",
                   "未提供信息库（--info），无法判断证照有效期", [])
    ref = ctx.deadline or ctx.asof
    bad, unknown, ok = [], [], []
    for c in certs:
        name = c.get("name", "未命名")
        exp_raw = c.get("expire", "")
        exp = parse_loose_date(exp_raw)
        if exp_raw in ("长期", "长期有效", "evergreen", "无") or c.get("mode") == "evergreen":
            ok.append(f"{name}（长期）")
        elif exp is None:
            unknown.append(f"{name}（有效期未登记：{exp_raw or '空'}）")
        elif exp < ref:
            bad.append(f"{name} 于 {exp} 到期，早于 {ref}")
        else:
            ok.append(f"{name} 至 {exp}")
    if bad:
        return add(ctx, META["S1-1"], "hit",
                   f"参照日 {ref}：" + "；".join(bad), bad)
    if unknown:
        return add(ctx, META["S1-1"], "manual",
                   "以下证照有效期未登记，不得视为有效：" + "；".join(unknown), unknown)
    add(ctx, META["S1-1"], "pass", f"参照日 {ref}，{len(ok)} 项证照有效期覆盖：" + "；".join(ok[:6]))


@check("S1-2", "S1 资格性", "P1", "形式", "营业执照名称/住所是否逐字照抄（含括号内容）？")
def chk_license_text(ctx):
    info = ctx.info or {}
    name, addr = info.get("name"), info.get("address")
    if not name and not addr:
        return add(ctx, META["S1-2"], "manual", "信息库未登记公司名称/住所，无法比对")
    problems = []
    if name and norm(name) not in ctx.bid_all_norm:
        problems.append(f"投标文件未出现营业执照全称「{name}」")
    if addr:
        na = norm(addr)
        if na not in ctx.bid_all_norm:
            # 找出简写：去掉括号内容还剩多少
            core = re.sub(r"[（(][^）)]*[）)]", "", addr)
            problems.append(
                f"住所与执照不一致：「{addr}」未逐字出现"
                + (f"（疑似简写为「{core}」，漏掉括号内容）" if norm(core) in ctx.bid_all_norm else "")
            )
    if problems:
        return add(ctx, META["S1-2"], "hit", "；".join(problems), problems)
    add(ctx, META["S1-2"], "pass", "公司名称与住所均逐字出现")


# ── S2 符合性 ──────────────────────────────────────────────

@check("S2-1", "S2 符合性", "P0", "一票否决", "招标文件要求的格式页是否齐全（双向差集）？")
def chk_format_coverage(ctx):
    if not ctx.tender_text:
        return add(ctx, META["S2-1"], "manual", "未提供招标文件（--tender），无法做格式差集")
    RE_FMT = re.compile(
        r"^\s*(?:响应函格式|投标函格式|格式|附件)\s*([0-9一二三四五六七八九十]+(?:[-－—]\d+)?)"
        r"\s*[：:]\s*(.{2,50})$"
    )
    items, seen = [], set()
    for line in ctx.tender_text.split("\n"):
        m = RE_FMT.match(line.strip())
        if not m:
            continue
        num, name = m.group(1), m.group(2).strip()
        name = re.sub(r"[（(][^）)]*[）)]\s*$", "", name).strip()
        key = norm(name)
        if len(key) < 2 or key in seen:
            continue
        seen.add(key)
        items.append((num, name))
    if not items:
        return add(ctx, META["S2-1"], "manual",
                   "未识别到格式条目（0 条）。原因可能是：格式页标题未用「格式N：」形态、"
                   "格式条目在表格内、或该文件确无独立格式章节 —— 需人工核对，不能视为通过")

    # 判断本项目的三个开关（先去掉空格再匹配："本项目设 无 响应保证金" 这种写法很常见）
    flat = re.sub(r"[\s\u3000]+", "", ctx.tender_text)
    no_bond = bool(re.search(r"无(?:响应|投标)?保证金|不设(?:响应|投标)?保证金|免收(?:响应|投标)?保证金", flat))
    no_joint = bool(re.search(r"不接受联合体|不允许联合体|不接收联合体", flat))
    is_service = bool(re.search(r"(采购|招标)需求|服务采购|服务类", flat)) and not re.search(
        r"货物采购|工程采购|施工总承包", flat)

    # 名称匹配：整名 → 去通用后缀的核心词 → 常见同义名（成稿常把格式名改成文种正名）
    FORMAT_ALIASES = [
        (r"技术响应清单", ["技术响应清单", "供货清单", "技术参数", "响应清单"]),
        (r"偏离表", ["偏离表"]),
        (r"报价表", ["报价表", "分项报价", "报价明细"]),
        (r"报价函", ["报价函", "响应函", "投标函"]),
        (r"法定代表人身份证明", ["法定代表人身份证明", "法人身份证明"]),
        (r"授权委托书", ["授权委托书", "授权书"]),
        (r"服务方案", ["服务方案", "技术方案", "实施方案"]),
    ]

    def hit_bid(name):
        """返回匹配到的名称（None 表示未找到）"""
        if norm(name) in ctx.bid_all_norm:
            return name
        core = re.sub(r"(一览表|清单表|核对表|表|书|函)$", "", name)
        if len(core) >= 4 and norm(core) in ctx.bid_all_norm:
            return core
        for pat, alts in FORMAT_ALIASES:
            if re.search(pat, name):
                for a in alts:
                    if norm(a) in ctx.bid_all_norm:
                        return a
        return None

    missing, na_list, found = [], [], []
    for num, name in items:
        reason = None
        if "保证金" in name and no_bond:
            reason = "本项目无保证金"
        elif "联合体" in name and no_joint:
            reason = "本项目不接受联合体"
        elif is_service and re.search(r"运输|货运|工程|施工|监理", name):
            reason = "本项目为服务类，该格式为其他标型专用"
        if reason:
            na_list.append(f"格式{num} {name}（{reason}）")
            continue
        got = hit_bid(name)
        if got:
            found.append(f"格式{num} {name}" + ("" if got == name else f"（以「{got}」呈现）"))
        else:
            missing.append(f"格式{num} {name}")
    if missing:
        return add(ctx, META["S2-1"], "hit",
                   f"招标文件共 {len(items)} 个格式页，缺 {len(missing)} 个（已剔除不适用 {len(na_list)} 个）："
                   + "；".join(missing), missing)
    add(ctx, META["S2-1"], "pass",
        f"{len(found)}/{len(items) - len(na_list)} 个适用格式页均已出现；不适用 {len(na_list)} 个"
        + ("：" + "；".join(na_list) if na_list else ""))


@check("S2-2", "S2 符合性", "P1", "扣分", "委托期限的起止是否与落款日、响应有效期自洽？")
def chk_authorize_period(ctx):
    hits, notes = [], []
    RE_P = re.compile(
        r"委托期限[：:]?\s*((?:20)?\d{2}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日)"
        r"\s*(?:至|到|—|－|-)\s*((?:20)?\d{2}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日)"
    )
    for p in ctx.bid_files:
        for pno, page in enumerate(ctx.pages[p], 1):
            for kind, obj in page:
                text = block_text(kind, obj)
                for m in RE_P.finditer(text):
                    d1 = parse_loose_date(m.group(1))
                    d2 = parse_loose_date(m.group(2))
                    if not d1 or not d2:
                        continue
                    months = (d2.year - d1.year) * 12 + (d2.month - d1.month)
                    if d2 < d1:
                        hits.append(ctx.ev(p, pno, f"委托期限止早于起：{m.group(0)}"))
                    elif months < 3:
                        hits.append(ctx.ev(p, pno, f"委托期限仅 {months} 个月，可能短于响应有效期"))
                    elif d2.day != d1.day and not (d1.day >= 28 and d2.day >= 28):
                        # 按月计算时，止日应与起日同日；差一天是最常见的算错
                        hits.append(ctx.ev(
                            p, pno,
                            f"委托期限 {d1} 至 {d2}：止日 {d2.day} 号 ≠ 起日 {d1.day} 号，"
                            f"按月计算应同为 {d1.day} 号，需与「落款日 + 月数」重核"))
                    else:
                        notes.append(f"{d1} 至 {d2}（{months} 个月）")
    if not notes and not hits:
        return add(ctx, META["S2-2"], "manual", "未找到「委托期限」起止日期，需人工确认")
    if hits:
        return add(ctx, META["S2-2"], "hit", "；".join(hits), hits)
    return add(ctx, META["S2-2"], "manual",
               "已读出委托期限 " + "；".join(notes) +
               " —— 机器不能判断是否 ≥ 响应有效期，请对照前附表有效期人工确认", notes)


# ── S3 响应完整性 ──────────────────────────────────────────

@check("S3-1", "S3 响应完整性", "P0", "一票否决", "待填提示词是否残留（模板没填净）？")
def chk_prompt_residual(ctx):
    hits, reserved = [], []
    for p in ctx.bid_files:
        for pno, page in enumerate(ctx.pages[p], 1):
            for kind, obj in page:
                text = block_text(kind, obj)
                for m in RE_BRACKET.finditer(text):
                    inner = re.sub(r"[\s\u3000]", "", m.group(1))
                    if inner in RESERVED_WORDS:
                        reserved.append(ctx.ev(p, pno, m.group(0)))
                    elif inner in PROMPT_WORDS:
                        hits.append(ctx.ev(p, pno, f"{m.group(0)} → {short(text, 30)}"))
    if hits:
        return add(ctx, META["S3-1"], "hit",
                   f"{len(hits)} 处模板提示词未删除/未替换：" + "；".join(hits[:8])
                   + (f"（共 {len(hits)} 处）" if len(hits) > 8 else ""), hits)
    add(ctx, META["S3-1"], "pass",
        f"未发现待填提示词；保留位（盖章/签字）{len(reserved)} 处，打印后处理")


@check("S3-2", "S3 响应完整性", "P1", "扣分", "是否有冒号后留空的待填栏位？")
def chk_colon_blank(ctx):
    hard, soft = [], []
    for p in ctx.bid_files:
        for pno, page in enumerate(ctx.pages[p], 1):
            for kind, obj in page:
                text = block_text(kind, obj)
                for m in RE_COLON_BLANK.finditer(text):
                    s = max(0, m.start() - 18)
                    snippet = text[s:m.end() + 12].replace("\n", " ")
                    # 签字/盖章栏留白是正常保留位，不是"没填"
                    if re.search(r"签字|盖章|签名|签章", snippet):
                        continue
                    if re.search(r"报价|金额|总价|单价|合计|大写|小写", text):
                        hard.append(ctx.ev(p, pno, snippet))
                    else:
                        soft.append(ctx.ev(p, pno, snippet))
    if hard:
        return add(ctx, META["S3-2"], "hit",
                   f"金额类栏位留空 {len(hard)} 处：" + "；".join(hard[:6]), hard)
    if soft:
        return add(ctx, META["S3-2"], "manual",
                   f"{len(soft)} 处冒号后连续空格，可能是填空位也可能是排版，需目视："
                   + "；".join(soft[:6]), soft)
    add(ctx, META["S3-2"], "pass", "未发现冒号后留空")


@check("S3-3", "S3 响应完整性", "P1", "形式", "填了日期后是否残留「年 月 日」？")
def chk_date_residual(ctx):
    hits = []
    for p in ctx.bid_files:
        for pno, page in enumerate(ctx.pages[p], 1):
            for kind, obj in page:
                text = block_text(kind, obj)
                if RE_RESIDUAL_DATE.search(text) or RE_XX_DATE.search(text):
                    hits.append(ctx.ev(p, pno, text))
    if hits:
        return add(ctx, META["S3-3"], "hit",
                   f"{len(hits)} 处日期占位残留：" + "；".join(hits[:6]), hits)
    add(ctx, META["S3-3"], "pass", "未发现「年 月 日」空位或 xx 占位")


@check("S3-4", "S3 响应完整性", "P0", "一票否决", "技术/服务需求是否逐条响应？")
def chk_clause_response(ctx):
    if not ctx.tender_text:
        return add(ctx, META["S3-4"], "manual", "未提供招标文件，无法核对条款覆盖")

    blocks = blocks_of(ctx.tender_doc)
    start = end = None
    for i, (k, o) in enumerate(blocks):
        if k != "p":
            continue
        t = (o.text or "").strip()
        if re.match(r"^第[一二三四五六七八九十\d]+章", t) and re.search(
                r"采购需求|技术需求|服务需求|项目需求|采购内容|技术要求|采购清单|采购范围", t):
            start = i
            break
    if start is None:
        return add(ctx, META["S3-4"], "manual",
                   "未定位到采购需求章节（关键词：采购需求/技术需求/服务需求/采购内容）。"
                   "0 条不代表没有条款，需人工确认章节名称")
    for i in range(start + 1, len(blocks)):
        k, o = blocks[i]
        if k != "p":
            continue
        t = (o.text or "").strip()
        if len(t) > 40:
            continue
        if re.match(r"^第[一二三四五六七八九十\d]+章", t) or re.search(
                r"(响应|投标)文件格式$", t):
            end = i
            break
    end = end or len(blocks)

    # 条款有两种承载形态：编号段落 + 参数表。**只看段落会漏掉整张参数表。**
    numbered, tables = [], []
    for i in range(start + 1, end):
        k, o = blocks[i]
        if k == "p":
            t = (o.text or "").strip()
            if re.match(r"^\d+(?:\.\d+)+\s*\S", t) or re.match(r"^\d+[、．.]\s*\S{6,}", t):
                numbered.append(t)
        else:
            rows = table_rows(o)
            if len(rows) >= 8:
                head = " ".join(c.text for c in rows[0])
                tables.append((len(rows) - 1, head))

    table_rows_n = max([n for n, _ in tables], default=0)
    table_head = next((h for n, h in tables if n == table_rows_n), "")
    n_req = max(len(numbered), table_rows_n)

    if n_req < 15:
        return add(ctx, META["S3-4"], "na" if n_req == 0 else "manual",
                   f"需求章识别到条款 {len(numbered)} 条、参数表最多 {table_rows_n} 行，"
                   + ("未达逐条门槛（<15），可用模块概述" if n_req else
                      "均未识别到，需人工确认（可能条款在图片里或章名不同）"))

    # 投标文件里的响应表（偏离表不算逐条响应表：它只写有偏离的项）
    bid_rows, bid_head = 0, ""
    dev_rows = 0
    for p in ctx.bid_files:
        for t in ctx.docs[p].tables:
            rows = table_rows(t)
            if len(rows) < 2:
                continue
            head = norm(" ".join(c.text for c in rows[0]))
            if "偏离" in head:
                dev_rows = max(dev_rows, len(rows) - 1)
                continue
            if ("响应" in head or "应答" in head) and any(
                    k in head for k in ("条款", "序号", "参数", "技术", "服务", "名称", "要求")):
                if len(rows) - 1 > bid_rows:
                    bid_rows = len(rows) - 1
                    bid_head = " / ".join(c.text.strip()[:12] for c in rows[0][:5])

    basis = f"需求章共 {len(numbered)} 条编号条款、参数表 {table_rows_n} 行（表头：{short(table_head, 40)}）"
    if bid_rows == 0:
        tail = (f"；投标文件仅有偏离表 {dev_rows} 行，偏离表只列有偏离的项，不能替代逐条响应表"
                if dev_rows else "；投标文件未见任何「响应情况」类表格")
        return add(ctx, META["S3-4"], "hit",
                   basis + tail + "，符合性审查时可能被判未响应",
                   [short(x, 40) for x in numbered[:6]] or [f"参数表 {table_rows_n} 行"])
    if bid_rows < n_req * 0.8:
        return add(ctx, META["S3-4"], "hit",
                   basis + f"；投标响应表仅 {bid_rows} 行（{short(bid_head, 30)}），"
                   f"缺口 {n_req - bid_rows} 项，疑似整块未响应",
                   [f"需求 {n_req} 项 / 响应 {bid_rows} 行"])
    add(ctx, META["S3-4"], "pass", basis + f"；投标响应表 {bid_rows} 行，覆盖充分")


@check("S3-5", "S3 响应完整性", "P0", "一票否决", "响应栏是否照抄了要求栏？")
def chk_copy_paste(ctx):
    hits = []
    for p in ctx.bid_files:
        for t in ctx.docs[p].tables:
            rows = table_rows(t)
            if len(rows) < 2:
                continue
            header = [norm(c.text) for c in rows[0]]
            idx_req = next((i for i, h in enumerate(header)
                            if any(k in h for k in ("招标文件要求", "采购要求", "技术参数",
                                                    "参数要求", "服务要求", "招标要求", "要求"))), None)
            idx_resp = next((i for i, h in enumerate(header)
                             if any(k in h for k in ("响应情况", "响应内容", "投标响应", "应答", "响应"))), None)
            if idx_req is None or idx_resp is None or idx_req == idx_resp:
                continue
            for r in rows[1:]:
                if max(idx_req, idx_resp) >= len(r):
                    continue
                req, resp = norm(r[idx_req].text), norm(r[idx_resp].text)
                if not req or not resp or len(resp) < 6:
                    continue
                if resp == req or (len(req) >= 8 and req in resp) or (len(resp) >= 8 and resp in req):
                    hits.append(f"{p.name}｜照抄：{short(r[idx_resp].text, 40)}")
    if hits:
        return add(ctx, META["S3-5"], "hit",
                   f"{len(hits)} 行响应内容与要求栏相同（等于未填）：" + "；".join(hits[:6]), hits)
    add(ctx, META["S3-5"], "pass", "未发现响应栏整段照抄要求栏")


@check("S3-6", "S3 响应完整性", "P0", "一票否决", "是否有整栏空白（数据列 100% 为空）？")
def chk_empty_column(ctx):
    hits = []
    skip = ("备注", "说明", "序号", "注")
    for p in ctx.bid_files:
        for ti, t in enumerate(ctx.docs[p].tables):
            rows = table_rows(t)
            if len(rows) < 4 or len(rows[0]) < 2:
                continue
            ncol = len(rows[0])
            for ci in range(ncol):
                head = rows[0][ci].text.strip()
                if not head or any(k in head for k in skip):
                    continue
                col = [r[ci].text.strip() for r in rows[1:] if ci < len(r)]
                if col and all(not v for v in col):
                    others = sum(1 for cj in range(ncol)
                                 if cj != ci and any(r[cj].text.strip() for r in rows[1:] if cj < len(r)))
                    if others:
                        hits.append(f"{p.name}｜第{ti + 1}张表「{head}」整列为空（{len(col)} 行）")
    if hits:
        return add(ctx, META["S3-6"], "hit", "；".join(hits[:8]), hits)
    add(ctx, META["S3-6"], "pass", "未发现整栏空白的数据列")


@check("S3-7", "S3 响应完整性", "P2", "形式", "是否有「目录有、翻到是白页」？")
def chk_blank_page(ctx):
    susp = []
    for p in ctx.bid_files:
        for pno, page in enumerate(ctx.pages[p], 1):
            if pno <= 2:  # 封面/目录页本就字少
                continue
            chars, imgs = page_stats(page)
            if chars < 5 and imgs == 0:
                susp.append(f"{p.name} 推定第 {pno} 页（{chars} 字，无图）")
    if susp:
        return add(ctx, META["S3-7"], "manual",
                   f"{len(susp)} 页疑似白页（推定页码，须渲染成图确认；扫描件页会因无文本被误判）："
                   + "；".join(susp[:8]), susp)
    add(ctx, META["S3-7"], "pass", "各推定页均有正文内容")


@check("S3-8", "S3 响应完整性", "P1", "形式", "证照图片是否真正嵌入 docx？")
def chk_images(ctx):
    bad = []
    for p in ctx.bid_files:
        m = ctx.media[p]
        mentions = ctx.bid_text[p]
        needs = bool(re.search(r"身份证|营业执照|证书", mentions))
        if m == 0 and needs:
            bad.append(f"{p.name}：正文提到证照，但 word/media 为空（图片可能只是编辑器会话内链接，未落盘）")
        elif m < 0:
            bad.append(f"{p.name}：无法读取 media（文件可能损坏）")
    if bad:
        return add(ctx, META["S3-8"], "hit", "；".join(bad), bad)
    desc = "；".join(f"{p.name} 内嵌 {ctx.media[p]} 张图" for p in ctx.bid_files)
    add(ctx, META["S3-8"], "pass", desc)


# ── S4 报价 ────────────────────────────────────────────────

@check("S4-1", "S4 报价", "P0", "一票否决", "报价大小写是否一致？")
def chk_amount_case(ctx):
    uppers, lowers = [], []
    for p in ctx.bid_files:
        text = ctx.bid_text[p]
        for m in RE_CN_AMOUNT.finditer(text):
            v = cn_amount(m.group())
            if v and v >= 100:
                uppers.append((p, v, m.group()))
        for m in RE_MONEY_LOWER.finditer(text):
            v = to_num(m.group(1))
            if v and v >= 100:
                lowers.append((p, v, m.group()))
    if not uppers or not lowers:
        return add(ctx, META["S4-1"], "manual",
                   f"大写金额 {len(uppers)} 处、小写金额 {len(lowers)} 处，至少一侧未识别，需人工核对")
    uv = {round(v, 2) for _, v, _ in uppers}
    lv = {round(v, 2) for _, v, _ in lowers}
    # 大写末尾是否漏了"整"
    no_zheng = [s for _, _, s in uppers if re.search(r"元$", s) and not re.search(r"[整正]$", s)]
    if uv & lv:
        msg = "大小写一致：" + "、".join(f"{v:,.2f}" for v in sorted(uv & lv))
        if no_zheng:
            return add(ctx, META["S4-1"], "hit",
                       msg + f"；但 {len(no_zheng)} 处大写金额末尾缺「整」：{no_zheng[:3]}", no_zheng)
        return add(ctx, META["S4-1"], "pass", msg)
    return add(ctx, META["S4-1"], "hit",
               f"大写 {sorted(uv)} 与小写 {sorted(lv)} 无交集，疑似不一致",
               [f"大写：{s}" for _, _, s in uppers] + [f"小写：{s}" for _, _, s in lowers])


@check("S4-2", "S4 报价", "P0", "一票否决", "单价×数量=合价、Σ合价=合计？")
def chk_price_math(ctx):
    probs, checked = [], 0
    for p in ctx.bid_files:
        for ti, t in enumerate(ctx.docs[p].tables):
            rows = table_rows(t)
            if len(rows) < 3:
                continue
            header = [norm(c.text) for c in rows[0]]
            ip = next((i for i, h in enumerate(header) if "单价" in h), None)
            iq = next((i for i, h in enumerate(header) if "数量" in h), None)
            ia = next((i for i, h in enumerate(header)
                       if "合价" in h or "小计" in h or ("金额" in h and "大写" not in h)), None)
            if None in (ip, iq, ia) or len({ip, iq, ia}) < 3:
                continue
            sums = 0.0
            for r in rows[1:]:
                if max(ip, iq, ia) >= len(r):
                    continue
                first = "".join(c.text for c in r)
                if re.search(r"合计|总计|小计", first) and len(norm(first)) < 40:
                    tot = to_num(r[ia].text)
                    if tot is not None and sums and abs(tot - sums) > 1:
                        probs.append(f"{p.name}「{t.rows[0].cells[0].text.strip()[:8]}」"
                                     f"第{ti + 1}表：合计 {tot:,.2f} ≠ 逐行累加 {sums:,.2f}")
                    continue
                pr, qty, amt = to_num(r[ip].text), to_num(r[iq].text), to_num(r[ia].text)
                if None in (pr, qty, amt):
                    continue
                checked += 1
                sums += amt
                if abs(pr * qty - amt) > max(1.0, amt * 0.001):
                    probs.append(f"{p.name} 第{ti + 1}表：{pr}×{qty}={pr * qty:.2f}，表内写 {amt:.2f}")
    if probs:
        return add(ctx, META["S4-2"], "hit", "；".join(probs[:8]), probs)
    if checked == 0:
        return add(ctx, META["S4-2"], "manual",
                   "未识别到「单价+数量+合价」三列齐全的报价表，无法机算（0 条不代表没问题）")
    add(ctx, META["S4-2"], "pass", f"已核算 {checked} 行，单价×数量与合价一致，合计行相符")


@check("S4-3", "S4 报价", "P0", "一票否决", "报价是否超过最高限价？")
def chk_max_price(ctx):
    if not ctx.max_price:
        return add(ctx, META["S4-3"], "na", "未传入 --max-price 或本项目不设限价")
    vals = []
    for p in ctx.bid_files:
        for m in RE_MONEY_LOWER.finditer(ctx.bid_text[p]):
            v = to_num(m.group(1))
            if v:
                vals.append(v)
    if not vals:
        return add(ctx, META["S4-3"], "manual", "未识别到报价金额，需人工确认")
    over = [v for v in vals if v > ctx.max_price]
    if over:
        return add(ctx, META["S4-3"], "hit",
                   f"最高限价 {ctx.max_price:,.2f}，文件出现更高金额：{[f'{v:,.2f}' for v in over]}", over)
    add(ctx, META["S4-3"], "pass", f"最高限价 {ctx.max_price:,.2f}，文件中最高金额 {max(vals):,.2f}")


@check("S4-4", "S4 报价", "P1", "扣分", "「报价依据和说明」栏是否空着？")
def chk_price_basis(ctx):
    hits = []
    for p in ctx.bid_files:
        for t in ctx.docs[p].tables:
            for r in table_rows(t):
                text = "".join(c.text for c in r)
                if "报价依据" not in text:
                    continue
                # 两种形态：多格表（后续格全空）或合并成一格、以冒号结尾
                rest = "".join(c.text for c in r[1:]).strip()
                body = r[0].text.strip()
                blank = (len(r) >= 2 and not rest and not body.endswith(("：", ":"))) or \
                        (len(r) == 1 and body.endswith(("：", ":")))
                if blank:
                    hits.append(f"{p.name}｜「{short(body, 36)}」冒号后无内容")
    if hits:
        return add(ctx, META["S4-4"], "hit",
                   "报价依据说明栏未填写：" + "；".join(hits), hits)
    add(ctx, META["S4-4"], "pass", "报价依据栏已填或无此栏")


# ── S5 形式与签署 ──────────────────────────────────────────

@check("S5-1", "S5 形式与签署", "P1", "形式", "多处落款日期是否一致？")
def chk_sign_date(ctx):
    by_file = {}
    for p in ctx.bid_files:
        ds = []
        blocks = ctx.blocks[p]
        for i, (kind, obj) in enumerate(blocks):
            if kind != "p":
                continue
            text = (obj.text or "").strip()
            m = RE_DATE_ONLY.match(text)
            if m:
                d = parse_date(*m.groups())
                if d:
                    ds.append((d, text))
                continue
            if re.search(r"供应商|投标人|响应人", text) and re.search(r"盖章|公章", text):
                for j in range(i + 1, min(i + 4, len(blocks))):
                    k2, o2 = blocks[j]
                    if k2 != "p":
                        continue
                    m2 = RE_DATE_ONLY.match((o2.text or "").strip())
                    if m2:
                        d = parse_date(*m2.groups())
                        if d:
                            ds.append((d, text))
                        break
        if ds:
            by_file[p] = ds
    if not by_file:
        return add(ctx, META["S5-1"], "manual", "未识别到落款日期（可能为空或写法特殊）")
    distinct = {d for ds in by_file.values() for d, _ in ds}
    if len(distinct) > 1:
        detail = "；".join(f"{p.name}: " + "、".join(sorted({str(d) for d, _ in ds}))
                           for p, ds in by_file.items())
        return add(ctx, META["S5-1"], "hit", f"落款日期不一致：{detail}", [detail])
    add(ctx, META["S5-1"], "pass", f"落款日期一致：{sorted(distinct)[0]}")


@check("S5-2", "S5 形式与签署", "P2", "形式", "目录域是否需要更新？页脚是否有页码？")
def chk_pagenum_toc(ctx):
    no_page, has_toc, hides = [], False, False
    for p in ctx.bid_files:
        d = ctx.docs[p]
        if _has_toc_field(d):
            has_toc = True
            if _toc_hides_pagenum(d):
                hides = True
        ok = False
        for sec in d.sections:
            for part in (sec.footer, sec.first_page_footer, sec.even_page_footer):
                try:
                    if "PAGE" in part._element.xml:
                        ok = True
                except Exception:
                    pass
        if not ok:
            no_page.append(p.name)
    msg = []
    if no_page:
        # 招文明确"无需纸质件、仅电子上传"时，页脚页码只是可选形式项
        msg.append("无页脚页码：" + "、".join(no_page))
    toc_note = ""
    if has_toc:
        toc_note = ("目录域设了「不显示页码」，需要另行确认页脚页码"
                    if hides else "检测到目录域，打开后需全选按 F9 更新页码")
        msg.append(toc_note)
    if no_page:
        return add(ctx, META["S5-2"], "hit", "；".join(msg), msg)
    add(ctx, META["S5-2"], "pass", "页脚页码存在" + (f"；{toc_note}" if toc_note else ""))


@check("S5-3", "S5 形式与签署", "P1", "形式", "采购编号/项目名称是否与公告逐字一致？")
def chk_project_identity(ctx):
    if not ctx.tender_text:
        return add(ctx, META["S5-3"], "manual", "未提供招标文件，无法比对项目名称与编号")
    tid = re.search(r"(?:采购编号|项目编号|招标编号|采购计划编号)[：:]\s*([A-Za-z0-9\-—－]{5,30})",
                    ctx.tender_text)
    tname = re.search(r"(?:项目名称|采购项目名称)[：:]\s*([^\s，,。；;、]{4,60})", ctx.tender_text)
    probs, oks = [], []
    if tid:
        code = tid.group(1).strip()
        if norm(code) not in ctx.bid_all_norm:
            probs.append(f"采购编号「{code}」未在投标文件中出现")
        else:
            oks.append(f"编号 {code}")
    if tname:
        name = tname.group(1).strip()
        cnt = ctx.bid_all_norm.count(norm(name))
        if cnt == 0:
            probs.append(f"项目名称「{name}」未在投标文件中出现")
        elif cnt < 2:
            probs.append(f"项目名称仅出现 {cnt} 次，多处应写全称（编号粘连也是常见错法）")
        else:
            oks.append(f"项目名称出现 {cnt} 次")
    if probs:
        return add(ctx, META["S5-3"], "hit", "；".join(probs), probs)
    if not oks:
        return add(ctx, META["S5-3"], "manual", "招标文件未载明编号/项目名称，无法比对")
    add(ctx, META["S5-3"], "pass", "；".join(oks))


@check("S5-4", "S5 形式与签署", "P2", "形式", "称谓是否与本项目采购方式一致？")
def chk_terms(ctx):
    if not ctx.tender_text:
        return add(ctx, META["S5-4"], "manual", "未提供招标文件，无法判断采购方式")
    t = ctx.tender_text
    if "询价通知书" in t:
        kind, wrong = "询价", ["投标文件", "投标人", "中标"]
    elif "竞争性磋商" in t:
        kind, wrong = "竞争性磋商", ["投标文件", "投标人", "中标"]
    elif "竞争性谈判" in t:
        kind, wrong = "竞争性谈判", ["投标文件", "投标人", "中标"]
    elif "招标公告" in t or "投标邀请" in t:
        return add(ctx, META["S5-4"], "pass", "招标方式，使用「投标文件/投标人」正确")
    else:
        return add(ctx, META["S5-4"], "manual", "未能识别采购方式，需人工判断称谓")
    used = {w: ctx.bid_all_norm.count(w) for w in wrong}
    bad = {w: c for w, c in used.items() if c >= 3}
    if bad:
        return add(ctx, META["S5-4"], "manual",
                   f"本项目为{kind}，投标文件却大量使用：" +
                   "、".join(f"{w}×{c}" for w, c in bad.items()) +
                   "；应统一为「响应文件/供应商/成交」（同义但可能被判不规范）",
                   [f"{w} 出现 {c} 次" for w, c in bad.items()])
    add(ctx, META["S5-4"], "pass", f"{kind}项目，称谓一致")


# ── S6 交付与装订 ──────────────────────────────────────────

@check("S6-1", "S6 交付与装订", "P0", "一票否决", "纸质件的份数/密封/装订是否符合要求？")
def chk_hardcopy(ctx):
    if not ctx.tender_text:
        return add(ctx, META["S6-1"], "manual", "无招标文件，无法判断纸质件要求")
    if re.search(r"无需纸质|不需要纸质|不接受纸质|仅需.{0,6}电子", ctx.tender_text):
        return add(ctx, META["S6-1"], "na", "招标文件载明无需纸质件（电子递交）")
    return add(ctx, META["S6-1"], "manual",
               "招标文件涉及纸质件，份数/正副本/密封/装订/送达时间**机器无法判定**，必须人工逐项核对")


def _all_paragraphs(doc):
    """body 下所有段落，含 w:sdt（内容控件）内的。

    python-docx 的 doc.paragraphs 只返回 body 直属的 p，
    Word/WPS 生成的目录常被整体包在 w:sdt 里，用 doc.paragraphs 会整段看不见。
    """
    from docx.oxml.ns import qn
    from docx.text.paragraph import Paragraph
    return [Paragraph(el, doc) for el in doc.element.body.iter(qn("w:p"))]


def _heading_paras(doc, level=None):
    """正文里的标题段落；level=None 取全部，level=1 只取 Heading 1"""
    out = []
    for p in _all_paragraphs(doc):
        m = re.match(r"(?i)^heading\s*([1-9])$", (p.style.name or "").strip())
        if not m:
            continue
        if level is None or int(m.group(1)) == level:
            out.append(p)
    return out


def _has_toc_field(doc):
    """真正的目录域：instrText 以 TOC 开头。

    不能用 "TOC" in body.xml 判断——样式名（toc 1）、正文文字都可能含 TOC，
    会把普通文档误判成"有目录"。
    """
    return bool(re.search(r"<w:instrText[^>]*>\s*TOC\b", doc.element.body.xml))


def _toc_field_code(doc):
    """返回 TOC 域代码字符串（含开关），找不到返回空串"""
    from docx.oxml.ns import qn
    for it in doc.element.body.iter(qn("w:instrText")):
        t = (it.text or "").strip()
        if re.match(r"TOC\b", t):
            return t
    return ""


def _toc_hides_pagenum(doc):
    """域代码含 \\n = 主动不显示页码（Word「显示页码」取消勾选）。

    注意：WPS 的 \\z 是「Web 版式隐藏制表符和页码」，不等于关闭页码显示，
    不能当判据用；只有 \\n 才是真的把页码从条目里去掉。
    """
    return bool(re.search(r"\\n(?=\s|$)", _toc_field_code(doc)))


def _toc_entries(doc):
    """目录条目段落：样式名为 toc 1 / TOC 2 / 目录 1 等

    注意：不能靠 pStyle 的 val 判断——很多文档（尤其 WPS 另存过的）会把
    styleId 重写成 "000004" 这类数字串，样式名仍是 "toc 1"。
    所以以 style.name 为主，pStyle val 只作兜底。
    """
    from docx.oxml.ns import qn
    out = []
    for p in _all_paragraphs(doc):
        name = (p.style.name or "").strip()
        if re.match(r"(?i)^(toc|目录)\s*[1-9]$", name) and p.text.strip():
            out.append(p)
            continue
        pPr = p._p.find(qn("w:pPr"))
        if pPr is not None:
            st = pPr.find(qn("w:pStyle"))
            if st is not None and re.search(r"(?i)toc", st.get(qn("w:val")) or ""):
                if p.text.strip():
                    out.append(p)
    return out


def _strip_auto_num(s):
    """去掉开头自动编号前缀：第一章/第二节/一、/（一）/1./1.1 

    目录条目会带上自动编号（Word 生成时写入文字），而正文标题的 w:t 里
    通常不含编号（编号由 numPr 渲染）——直接比对会把每条都判成"不在目录中"。
    """
    s = re.sub(
        r"^[\s\u3000]*(?:第[一二三四五六七八九十百零〇\d]+[章节部分篇条]"
        r"|[（(][一二三四五六七八九十\d]+[）)]"
        r"|[一二三四五六七八九十]+[、．.]"
        r"|\d+(?:\.\d+)*[、．.]?)\s*",
        "", (s or "").strip())
    return s.strip()


def _same_title(a, b):
    """标题同一性：去编号后相等，或一方是另一方子串"""
    a, b = norm(_strip_auto_num(a)), norm(_strip_auto_num(b))
    if not a or not b:
        return False
    return a == b or a in b or b in a


def _comments_text(path):
    """从 word/comments*.xml 里粗提批注正文，用作证据"""
    try:
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                if re.match(r"word/comments[^/]*\.xml$", n):
                    xml = z.read(n).decode("utf-8", "ignore")
                    return "｜".join(re.findall(r"<w:t[^>]*>([^<]{2,60})</w:t>", xml)[:6])
    except Exception:
        pass
    return ""


@check("S5-5", "S5 形式与签署", "P2", "形式", "目录条目与正文标题是否一一对应、页码是否已刷新？")
def chk_toc_consistency(ctx):
    probs, oks = [], []
    for p in ctx.bid_files:
        d = ctx.docs[p]
        h1 = _heading_paras(d, 1)
        heads = _heading_paras(d)
        entries = _toc_entries(d)
        has_toc = _has_toc_field(d)
        file_probs = []

        if not heads:
            file_probs.append(f"{p.name}：未设任何标题层级（Heading 1-9），目录无法生成")
            probs.extend(file_probs)
            continue
        if not has_toc and not entries:
            file_probs.append(f"{p.name}：有 {len(heads)} 个标题但未见目录域（长文档应有目录）")
            probs.extend(file_probs)
            continue
        if has_toc and not entries:
            hint = ("；文档标题不足 3 个，建议直接删掉这个空域"
                    if len(heads) < 3 else "；需 F9 更新，否则交出去是个空目录")
            file_probs.append(
                f"{p.name}：有目录域但域内无条目（打开可能显示「未找到目录项」）{hint}")
            probs.extend(file_probs)
            continue

        # 目录可能只收一级，也可能收多级——命中任一即算条数对得上
        n = len(entries)
        if n == len(h1):
            body_heads = h1
        elif n == len(heads):
            body_heads = heads
        else:
            file_probs.append(
                f"{p.name}：目录 {n} 条 ≠ 标题 {len(h1)}（一级）/ {len(heads)}（全部）个"
                f"（常见原因：某格式页标题没挂样式，或目录标题被并进第一条）")
            probs.extend(file_probs)
            continue

        # 条目文字与正文标题做差集：抓「缺某页」「标题被吞进第一条」
        toc_texts = [re.sub(r"[\t\s]*\d*$", "", e.text.strip()) for e in entries]
        missing = [h.text.strip() for h in body_heads
                   if not any(_same_title(h.text.strip(), t) for t in toc_texts)]
        if missing:
            file_probs.append(
                f"{p.name}：{len(missing)} 个标题未出现在目录中："
                + "；".join(short(x, 24) for x in missing[:4]))
            probs.extend(file_probs)
            continue

        # 页码是否算过（主动不显示页码的，不算缺陷）
        if _toc_hides_pagenum(d):
            oks.append(
                f"{p.name}：目录 {n} 条与标题一一对应，域设 \\n 不显示页码"
                f"（需确认页脚页码是否另行添加）")
            probs.extend(file_probs)
            continue

        pages = []
        for e in entries:
            m = re.search(r"(\d+)\s*$", e.text.strip())
            pages.append(int(m.group(1)) if m else None)
        if all(x is None for x in pages):
            file_probs.append(f"{p.name}：目录条目末尾均无页码，域未计算（按 F9 或标 dirty 自动更新）")
        elif all(x == 0 for x in pages):
            file_probs.append(
                f"{p.name}：目录 {len(pages)} 条页码全为 0，域从未计算——交出去等于没有页码索引")
        elif len(set(pages)) == 1 and len(pages) > 2:
            file_probs.append(
                f"{p.name}：目录 {len(pages)} 条页码全为 {pages[0]}，疑似域未刷新")
        elif not file_probs:
            oks.append(f"{p.name}：目录 {n} 条与标题一一对应，页码已计算")

        probs.extend(file_probs)

    if probs:
        return add(ctx, META["S5-5"], "hit", "；".join(probs), probs)
    if oks:
        return add(ctx, META["S5-5"], "pass", "；".join(oks))
    add(ctx, META["S5-5"], "manual", "未能识别标题或目录结构，需目视确认")


@check("S6-2", "S6 交付与装订", "P0", "一票否决", "变量批注是否已清空（内部填写说明不能交出去）？")
def chk_comments_cleared(ctx):
    hits, notes = [], []
    for p in ctx.bid_files:
        try:
            with zipfile.ZipFile(p) as z:
                doc_xml = z.read("word/document.xml").decode("utf-8", "ignore")
                parts = [n for n in z.namelist() if re.match(r"word/comments", n)]
        except Exception as e:
            notes.append(f"{p.name}：解包失败 {type(e).__name__}，无法判定批注状态")
            continue
        refs = doc_xml.count("commentReference")
        anchors = doc_xml.count("commentRangeStart")
        if refs or anchors:
            sample = _comments_text(p)
            hits.append(
                f"{p.name}：残留批注锚点 {anchors} 处、引用 {refs} 处"
                + (f"；批注内容示例：{short(sample, 60)}" if sample else ""))
        elif parts:
            notes.append(
                f"{p.name}：正文已无批注锚点，但包内仍残留 {'、'.join(parts)}"
                f"（严格评标系统或解包检查仍可能读到）")
    if hits:
        return add(ctx, META["S6-2"], "hit", "；".join(hits), hits)
    if notes:
        return add(ctx, META["S6-2"], "manual", "；".join(notes), notes)
    add(ctx, META["S6-2"], "pass", "各文件均无批注残留")


META = {}


def run(ctx):
    for meta in CHECKS:
        META[meta["id"]] = meta
    for meta in CHECKS:
        try:
            meta["fn"](ctx)
        except Exception as e:
            add(ctx, meta, "manual",
                f"检查未完成：{type(e).__name__}: {e}（异常不等于通过）")


# ─────────────────────────── 报告 ───────────────────────────

STATUS_ICON = {"pass": "✅ 通过", "hit": "❌ 命中", "manual": "⚠️ 待人工", "na": "➖ 不适用"}
ORDER = {"P0": 0, "P1": 1, "P2": 2}


def render(ctx):
    f = ctx.findings
    total = len(f)
    cnt = {k: sum(1 for x in f if x["status"] == k) for k in STATUS_ICON}
    na = cnt["na"]
    applicable = total - na
    machine = [x for x in f if x["status"] in ("pass", "hit")]
    coverage = (len(machine) / applicable * 100) if applicable else 0.0

    L = []
    L.append("# 投标文件提交前体检报告")
    L.append("")
    L.append(f"- **生成时间**：{datetime.now():%Y-%m-%d %H:%M}")
    L.append(f"- **投标文件**：" + "、".join(p.name for p in ctx.bid_files))
    L.append(f"- **招标文件**：{ctx.tender_path.name if ctx.tender_path else '未提供（多项检查降级为待人工）'}")
    L.append(f"- **参照日**：{ctx.deadline or ctx.asof}（{'投标截止日' if ctx.deadline else '今天'}）")
    L.append("")
    L.append("## 一、总览")
    L.append("")
    L.append("| 状态 | 数量 | 含义 |")
    L.append("|---|---|---|")
    L.append(f"| ❌ 命中 | {cnt['hit']} | 已确认有问题，按 P0→P1→P2 处理 |")
    L.append(f"| ⚠️ 待人工 | {cnt['manual']} | **机器判不了，必须人看** |")
    L.append(f"| ✅ 通过 | {cnt['pass']} | 已查过且未发现问题 |")
    L.append(f"| ➖ 不适用 | {na} | 本项目不存在该情形（已从覆盖率分母剔除） |")
    L.append("")
    L.append(f"**机械判定覆盖率**：{len(machine)}/{applicable} = **{coverage:.0f}%**"
             f"（分母已剔除 {na} 项不适用；待人工 {cnt['manual']} 项不计入）")
    L.append("")
    if cnt["hit"] == 0:
        L.append("> 无命中项。但**待人工项仍可能致命**，请继续看第三节。")
    L.append("")

    for label, st in (("二、命中项（按严重程度）", "hit"), ("三、必须人工确认", "manual")):
        rows = [x for x in f if x["status"] == st]
        rows.sort(key=lambda x: (ORDER.get(x["level"], 9), x["id"]))
        L.append(f"## {label}")
        L.append("")
        if not rows:
            L.append("_无_")
            L.append("")
            continue
        L.append("| 编号 | 级别 | 后果 | 检查项 | 结论与证据 |")
        L.append("|---|---|---|---|---|")
        for x in rows:
            ev = x["evidence"].replace("|", "/").replace("\n", " ")
            L.append(f"| {x['id']} | {x['level']} | {x['consequence']} | {x['question']} | {short(ev, 160)} |")
        L.append("")
        if st == "hit":
            L.append("**逐项明细**")
            L.append("")
            for x in rows:
                L.append(f"- **[{x['id']}·{x['level']}] {x['question']}**（{x['consequence']}）")
                L.append(f"  - {x['evidence']}")
                for it in x["items"][:12]:
                    L.append(f"  - · {it}")
                if len(x["items"]) > 12:
                    L.append(f"  - · …另 {len(x['items']) - 12} 项")
            L.append("")

    na_rows = [x for x in f if x["status"] == "na"]
    if na_rows:
        L.append("## 四、本项目不适用")
        L.append("")
        for x in na_rows:
            L.append(f"- {x['id']}：{x['evidence']}")
        L.append("")

    L.append("## 五、已通过项（证明查过多深）")
    L.append("")
    L.append("| 编号 | 检查项 | 结论 |")
    L.append("|---|---|---|")
    for x in f:
        if x["status"] == "pass":
            L.append(f"| {x['id']} | {x['question']} | {short(x['evidence'], 90)} |")
    L.append("")
    L.append("## 六、可信边界（务必读完）")
    L.append("")
    L.append("- **页码是推定值**：按显式分页符切分，与排版后的真实页码可能有偏差；引用前请目视核对。")
    L.append("- **文本层为空不等于空白**：扫描件、图片、表单域里的字提取不到，标「待人工」的空白页必须开图确认。")
    L.append("- **机器判不了的项**：份数、密封、装订、实际送达时间、手签与实物盖章、评委裁量分，全部标 `manual`，未计入覆盖率。")
    L.append("- **不适用不等于通过**：`na` 只表示本项目不存在该情形，已从分母剔除。")
    L.append("- 本报告只做机械核验，**不替代人工逐条复核**，也不构成投标合规意见。")
    L.append("")
    return "\n".join(L), dict(total=total, **cnt, applicable=applicable, coverage=round(coverage, 1))


def main():
    ap = argparse.ArgumentParser(description="投标文件提交前体检（四态判定 + 证据 + 覆盖率）")
    ap.add_argument("--bid", action="append", required=True, help="投标/响应文件 .docx（可多次）")
    ap.add_argument("--tender", help="招标/采购文件 .docx")
    ap.add_argument("--info", help="投标人信息库 .json（公司名/住所/证照有效期）")
    ap.add_argument("--deadline", help="投标截止日，格式 YYYY-MM-DD")
    ap.add_argument("--asof", help="参照日，默认今天；用于预演未来失效")
    ap.add_argument("--max-price", type=float, help="最高限价；本项目不设限价则不传")
    ap.add_argument("-o", "--output", help="输出 Markdown 报告")
    ap.add_argument("--json", dest="json_out", help="输出 JSON 结果")
    args = ap.parse_args()

    for p in args.bid + ([args.tender] if args.tender else []):
        if not Path(p).exists():
            print(f"[错误] 文件不存在：{p}")
            return 2
        if Path(p).suffix.lower() != ".docx":
            print(f"[错误] 仅支持 .docx：{p}（.doc/.pdf 请先另存为 docx）")
            return 2

    ctx = Ctx(args)
    run(ctx)
    report, summary = render(ctx)

    print(report)
    if args.output:
        Path(args.output).write_text(report, encoding="utf-8")
        print(f"\n[已保存] {args.output}")
    if args.json_out:
        Path(args.json_out).write_text(
            json.dumps({"summary": summary, "findings": ctx.findings},
                       ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[已保存] {args.json_out}")

    p0 = [x for x in ctx.findings if x["status"] == "hit" and x["level"] == "P0"]
    return 1 if p0 else 0


if __name__ == "__main__":
    sys.exit(main())
