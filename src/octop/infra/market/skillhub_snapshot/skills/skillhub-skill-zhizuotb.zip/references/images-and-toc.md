# 章节结构、目录生成与图片嵌入

> 本文解决两件在标书里"看起来简单、做起来必翻车"的事：
> ① 让每个格式页成为可被目录收录的章节；
> ② 让身份证/营业执照等图片**真正写进 docx** 并正常显示。
> 所有结论来自真实标书实操，含失败现场。

---

## 〇、先分清三件事：层级 / 分页 / 外观

新手最大的误解是"把标题调大加粗了就算标题"。实际上这三层完全独立：

| 层 | 由什么决定 | 影响什么 | 设错的后果 |
|---|---|---|---|
| **① 层级** | 段落的 **大纲级别**（`w:outlineLvl`，0–8 对应 1–9 级） | 目录收不收这一条、导航窗格显示不显示 | 目录是空的、或漏掉某一页 |
| **② 分页** | 段落 **段前分页**（`w:pageBreakBefore`）或独立分页符 | 这一页是否从新页开始 | 两个格式页挤在同一页；或凭空多出白页 |
| **③ 外观** | 字号、加粗、居中、段前段后间距 | 只在纸面上好看 | 完全不影响目录 |

**结论：只有 ① 决定目录。** 把文字设成"宋体二号加粗居中"但没设大纲级别，目录里一条都不会有。

### 层级不是"样式"本身，样式只是载体

判定链条是这样的：

```
目录（TOC 域）
   └─ 收集「大纲级别 ≤ max_level」的段落
        └─ 大纲级别来自 w:pPr/w:outlineLvl
             ├─ 直接写在段落上（直排，优先）
             └─ 或继承自段落样式 pStyle 所引用样式里的 outlineLvl
                  └─ 内置 Heading 1~9 样式自带 outlineLvl = 0~8
```

所以有两条等效路径：

| 路径 | 做法 | 适用 |
|---|---|---|
| **A. 挂内置标题样式**（推荐） | 段落 `pStyle = Heading 1` | 想让这些标题**外观也统一**、后续好批量改字号 |
| **B. 只写大纲级别** | 段落 `outlineLvl = 0`，样式仍是正文 | 想保留原文字号字体，只要它进目录 |

标书场景推荐 **A**：格式页标题本来就是"章节标题"的语义，挂 Heading 1 后既能进目录，又能统一改外观，一举两得。若招标文件对这些标题的字号有硬性要求（如"三号黑体"），再改 Heading 1 样式定义，而不要逐段设直排格式。

> ⚠️ **反例（真实踩过）**：手工往 `w:pPr` 里 `append` 一个 `w:pStyle` 元素。
> `w:pPr` 的子元素**顺序是强制的**（见下），append 会把它放到 `spacing`/`jc`/`outlineLvl` 之后，
> WPS 解析时直接忽略整个不合规片段 —— 表现就是"样式明明设了，目录还是空的"。

### `w:pPr` 子元素法定顺序（只列常见的）

```
pStyle → keepNext → keepLines → pageBreakBefore → widowControl → numPr
→ pBdr → shd → tabs → spacing → ind → jc → outlineLvl → rPr → sectPr
```

**安全做法**：用官方 API（`p.style = ...`、`pf.page_break_before = True`），
python-docx 内部自带 `insert_element_before(successors)`，会插到正确位置。
**只有手工 `SubElement` / `append` 才会错序** —— 这也是唯一需要记的一条纪律。

---

## 一、章节与目录：六步 SOP

### 第 1 步 清理前置页（目录之前的一切）

格式章节原样抽取过来后，开头通常堆着三类东西，**成稿一律删**：

| 要删的 | 判据 | 注意 |
|---|---|---|
| 空白页 | 连续两个以上空段落 + 分页符 | 删段落，不要只删分页符 |
| 招标人写的"响应文件格式/目录"标题页 | 文字含「响应文件格式」「响应文件目录」但下面没有实际内容 | 应换成自己的「目　录」页 |
| 格式填写说明页（注1）—注5）、重要提示、盖章上传说明） | 文字含「注」「重要」「说明」「上传」「密封」等 | **删前先读一遍**：若其中有"不接受…""必须…"这类实质要求，改写成要求落实，而非直接丢弃 |

删除方式二选一：段落级删除（python-docx），或在编辑器里选中整段删除。
**删完立刻存一次盘**，再做下一步，避免坐标全部漂移。

### 第 2 步 给每个格式页标题设层级

**首选（引擎路径，会自动写对 pPr 顺序）**

```bash
# 1) 先拿结构，找到每个格式页标题段落的 begin/end（GCP 坐标）
python3 edsdk.py call doc_resolve_document_structure \
  --json '{"file_id":"<FILE_ID>"}' > structure.json

# 2) 逐段设成 Heading 1（heading_lvl=1 即 Heading 1 样式）
python3 edsdk.py call doc_modify_paragraph --json '{
  "file_id": "<FILE_ID>",
  "ranges": [{"begin": 1234, "end": 1268}],
  "heading_lvl": 1
}'

# 3) 读回验证（关键！设了不等于生效）
python3 edsdk.py call doc_get_paragraph_property \
  --json '{"file_id":"<FILE_ID>","idx":1234}'
# 期望：paragraph_style = "heading 1"，outline_level = 0，heading_level = 1
```

**兜底（离线 / 批量 / 引擎未开，python-docx）**

```python
import docx
d = docx.Document(PATH)

TARGETS = ["格式1-1", "格式1-2", "格式2", "格式3", "格式4-1", "格式4-2",
           "服务方案", "响应函", "格式7"]          # 用你的实际标题前缀

def is_target(t):
    t = t.strip()
    return any(t.startswith(k) for k in TARGETS) and len(t) < 60

n = 0
for p in d.paragraphs:
    if is_target(p.text):
        p.style = d.styles["Heading 1"]          # 官方 API，顺序安全
        n += 1
d.save(PATH)
print("设为标题1：", n)
```

要点：
- **用 `p.style =` 赋值，不要手工构造 `w:pStyle`**。
- 标题文字若自带编号（`一、`、`1.`），不要额外加自动编号，否则目录里会出现双编号。
- 若文档里没有 `Heading 1` 样式（被删过），先从模板文档复制样式，或改用路径 B 只写大纲级别：

```python
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
pPr = p._p.get_or_add_pPr()
lvl = pPr.find(qn("w:outlineLvl"))
if lvl is None:
    lvl = OxmlElement("w:outlineLvl")
    # 必须插在 jc 之后、rPr 之前，否则可能被忽略
    pPr.insert_element_before(lvl, "w:rPr", "w:sectPr", "w:pPrChange")
lvl.set(qn("w:val"), "0")
```

### 第 3 步 设分页（让每个格式页从新页开始）

两种手段，**只能选一种**，叠加就会多出白纸：

| 手段 | 做法 | 适用 |
|---|---|---|
| 段前分页 | `pf.page_break_before = True` | 推荐。跟着段落走，删段不会留孤立分页符 |
| 分页符 | 上一段末尾插 `w:br type="page"` | 原文已有分页符时沿用它，别再加段前分页 |

```python
for p in d.paragraphs:
    if p.style.name == "Heading 1":
        p.paragraph_format.page_break_before = True
```

**真实坑**：某个标题前本来就有分页符，又给它加了"段前分页"，
结果渲染出**一整张空白页**——分页符结束一页，段前分页又开一页，中间空出来的就是白纸。
排查口径：出现白页时，先看白页前一页末尾有没有 `w:br type="page"`，有就把该标题的 `page_break_before` 关掉。

> 首页（目录页）**不要**设段前分页，否则文档第一页会凭空多一张空白。

### 第 4 步 插目录

**引擎路径（推荐，生成的是可更新的真域）**

```bash
# idx 用目录该出现的位置：文档最开头用 -1
python3 edsdk.py call doc_insert_toc --json '{
  "file_id": "<FILE_ID>",
  "idx": -1,
  "max_level": 1,
  "hide_page_number": true
}'
python3 edsdk.py call save_file --json '{
  "file_id":"<FILE_ID>",
  "file_path":"D:\\...\\响应文件.docx"
}'
```

- `max_level: 1` → 只收一级标题（格式页都是平级，正合适）
- `max_level: 2` → 技术方案有二级标题时用
- `hide_page_number: true` → **目录不显示页码**（下面 4.1 详述何时该用）
- 插完**必须显式 `save_file` 并传 `file_path`**，否则只在编辑器里存在

### 4.1 目录要不要页码

页码不是必须的。三种口径，**开工前就要定，不要中途改**：

| 口径 | 做法 | 适用 |
|---|---|---|
| **带页码**（默认） | `hide_page_number: false`；F9 更新域后页码自动算 | 篇幅长、评委靠目录定位 |
| **不带页码** | `hide_page_number: true`（域加 `\n` 开关） | 页码统一放页脚、或排版外包、或用户明确说"页码我自己加" |
| 干脆不要目录 | 不插域；标题样式照设（导航窗格仍可用） | 单册 3–5 页的短件（如单独一份报价函） |

**为什么不带页码时要设 `\n` 而不是只删数字**：
只把条目里的数字删掉，域还活着，下次任何一次 F9 都会把页码算回来。
必须让**域本身**记住"不显示页码"——即域代码里带 `\n`（Word 里就是目录属性里"显示页码"复选框取消）。

**手工改法（已生成的目录要改成不显示页码）**：

```python
import re, docx
from docx.oxml.ns import qn

d = docx.Document(PATH)
body = d.element.body

# ① 给 TOC 域代码加 \n
for r in body.iter(qn("w:r")):
    it = r.find(qn("w:instrText"))
    t = (it.text or "") if it is not None else ""
    if re.match(r"^\s*TOC\b", t) and not re.search(r"\\n(?=\s|$)", t):
        it.text = t.rstrip() + " \\n "

# ② 删每条条目的 PAGEREF 组 + 标题 run 里的 <w:tab/> + 右对齐制表位
def fld(r):
    e = r.find(qn("w:fldChar"))
    return e.get(qn("w:fldCharType")) if e is not None else None

def instr(r):
    e = r.find(qn("w:instrText"))
    return (e.text or "") if e is not None else ""

for p_el in body.iter(qn("w:p")):
    pPr = p_el.find(qn("w:pPr"))
    sid = ""
    if pPr is not None and pPr.find(qn("w:pStyle")) is not None:
        sid = pPr.find(qn("w:pStyle")).get(qn("w:val")) or ""
    if sid != "000004":          # ← 换成你的 toc 样式 id
        continue
    runs = list(p_el.findall(qn("w:r")))
    pi = next((i for i, r in enumerate(runs) if "PAGEREF" in instr(r)), None)
    if pi is None:
        continue
    start = pi
    for j in range(pi - 1, -1, -1):
        if fld(runs[j]) == "begin":
            start = j
            break
    end = pi
    for j in range(pi + 1, len(runs)):
        if fld(runs[j]) == "end":
            end = j
            break
    for r in runs[start:end + 1]:
        p_el.remove(r)
    for r in p_el.findall(qn("w:r")):
        for tab in r.findall(qn("w:tab")):
            r.remove(tab)
    if pPr is not None and pPr.find(qn("w:tabs")) is not None:
        pPr.remove(pPr.find(qn("w:tabs")))
d.save(PATH)
```

> ⚠️ **实测踩过的坑，照抄会丢标题**：这种目录里，**标题文字和 `<w:tab/>` 在同一个 run 里**
> （`<w:r><w:t>一、xxx</w:t><w:tab/></w:r>`）。
> 如果"从含 tab 的 run 起整段删"，会把这个 run 连同标题文字一起删掉——
> 11 条目录全部变成空壳，且保存后才发现。正确做法是**只删 PAGEREF 那一组 run**，
> 标题 run 里单独 `remove` 那个 `<w:tab/>` 子元素。

**兜底（手写 TOC 域，不推荐）**：只有在没有编辑器可用时才手写
`TOC \o "1-1" \h \z \u` 域。缺点是页码不会自动算，打开后仍需 F9。

### 第 5 步 修两处目录结构问题（几乎必犯）

| 现象 | 原因 | 修法 |
|---|---|---|
| 「目　录」标题和第一条目录挤在同一段 | 插入位置落在标题段落**内部**（idx 取在段落中间），域代码把标题吞进了第一条 | 把这一段拆成两段：第一段只留标题文字（设为正文、居中、二号），从 `TOC` 域起始处另起一段 |
| 目录最后多一个空段 | 域结束后编辑器补了一个空 `Normal` 段 | 删掉该空段（判据：`style==Normal` 且 `text.strip()==""` 且紧跟在最后一条目录之后） |

拆段的可靠做法：定位含 `instrText` 且以 `TOC` 开头的那个 run，把它之前的文字（即被吞进来的标题）
移到新段落，再让原段落从该 run 开始。

### 第 6 步 让页码自动刷新

目录插入后页码是"待计算"状态。三种做法，任选其一：

1. **标 dirty**（打开时自动刷新，最省事）：给 `fldChar type="begin"` 加 `w:dirty="true"`
   ```python
   from docx.oxml.ns import qn
   for p in d.element.body.iterchildren():
       if not p.tag.endswith("}p"):
           continue
       runs = list(p)
       for i, ch in enumerate(runs):
           it = ch.find(qn("w:instrText")) if ch.tag == qn("w:r") else None
           if it is not None and (it.text or "").strip().startswith("TOC"):
               for j in range(i - 1, -1, -1):
                   fc = runs[j].find(qn("w:fldChar")) if runs[j].tag == qn("w:r") else None
                   if fc is not None and fc.get(qn("w:fldCharType")) == "begin":
                       fc.set(qn("w:dirty"), "true")
                       break
   ```
2. **打印前手动刷新**：打开后 `Ctrl+A` → `F9` → 选"只更新页码"（想连条目一起更新选"更新整个目录"）
3. **导出 PDF 时**：先在 WPS/Word 里 F9 一次，再转 PDF

> **实测教训**：给 TOC 域标了 `dirty="true"` 后保存，解包看目录条目仍是 `...\t0` ——
> 11 条页码全是 0。原因是 dirty 只是一个"下次打开请刷新"的标记，**页码不会因此被算出来写进文件**。
> 所以：标 dirty 只是免去手工 F9 的麻烦，**交付前必须在 WPS/Word 里真更新一次域并保存**。
> 判据：解包后目录条目末尾应是真实页码数字，不是 0。

> 交电子标前一定目视确认：目录里每条的页码，和实际翻到的页码一致。
> 只改过标题、没刷新域的文档，页码常常还是旧的（最典型：全篇都是"第 1 页"或全是 0）。

### 第 7 步 校验（脚本能查的部分）

`scripts/verify_bid_doc.py` 的 **S5-5** 查：目录条数与正文标题是否一一对应、
条目文字与标题是否匹配、页码是否算过（**域设了 `\n` 不显示页码的，不算缺陷**）；
**S5-2** 查有无目录域、页脚有无页码。

---

## 二、图片嵌入：唯一正确姿势

### 2.1 致命结论：编辑器里"看得见"≠"文件里有"

`doc_insert_image` 插入的是**会话内资源引用**，
在预览里显示正常，`save_file` 之后 **`word/media/` 里没有这张图**，别人打开就是空白框。

**判据（唯一可信）**：保存后解包数文件。

```python
import zipfile
with zipfile.ZipFile(PATH) as z:
    media = [n for n in z.namelist() if n.startswith("word/media/") and not n.endswith("/")]
print(len(media), [(n.split("/")[-1], z.getinfo(n).file_size) for n in media])
```

图片数没增加 = 没插进去。**不要靠肉眼在预览里看。**

### 2.2 用 python-docx 真正嵌入

```python
import docx, zipfile
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph

PATH = "响应文件.docx"
d = docx.Document(PATH)

# ── 工具：在某段之后插入新段落（python-docx 只提供 insert_paragraph_before）
def para_after(anchor):
    new_p = OxmlElement("w:p")
    anchor._p.addnext(new_p)
    return Paragraph(new_p, anchor._parent)

def add_picture_para(anchor, img_path, width_cm=15.0, caption=None):
    p = para_after(anchor)
    pf = p.paragraph_format
    pf.line_spacing = 1.0          # ★ 必须单倍行距，固定行距会把图裁掉
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    # 不要设 keep_together / 固定值行距
    p.add_run().add_picture(img_path, width=Cm(width_cm))
    return p

# ── 找锚点：某个格式页标题
anchor = None
for p in d.paragraphs:
    if p.text.strip().startswith("格式2"):     # 营业执照应放在这一页之后
        anchor = p
        break
assert anchor is not None, "锚点没找到，先确认标题文字"

add_picture_para(anchor, "营业执照.jpg", width_cm=14.5)
d.save(PATH)

# ── 立刻校验
with zipfile.ZipFile(PATH) as z:
    print("media 数量：", len([n for n in z.namelist() if n.startswith("word/media/")]))
```

### 2.3 图片不显示的三个根因（按出现频率）

| 根因 | 现象 | 修法 |
|---|---|---|
| **固定行距**（`line_spacing_rule = EXACTLY`） | 图占位存在但被裁成一条缝，看起来"没图" | 该段 `line_spacing = 1.0` 且 rule 改 auto（单倍） |
| **宽度超出正文宽度** | 图被缩到页外或压成 0 宽 | 宽度 ≤ 页宽 − 左右边距 − 2cm；A4 常规页边距 2.5cm 时用 14–15cm |
| **图片本身是空壳 drawing** | 段落里有 `w:drawing` 但没有 `a:blip` 的 embed | 重插；或直接整段删掉重做 |

> 一行代码自查全部图片段落是否有固定行距：
> ```python
> from docx.enum.text import WD_LINE_SPACING
> for p in d.paragraphs:
>     if "w:drawing" in p._p.xml and p.paragraph_format.line_spacing_rule == WD_LINE_SPACING.EXACTLY:
>         print("固定行距，会裁图：", p.text[:20])
> ```

### 2.4 表格单元格里插图（身份证正反并排、执照多页并排）

```python
cell = table.cell(0, 0)
p = cell.paragraphs[0]
p.paragraph_format.line_spacing = 1.0
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run().add_picture("身份证正面.jpg", width=Cm(7.6))
```

要点：
- 单元格里**每个图单独一个段落**，不要塞进同一段用空格隔开（会错位）
- 两图并排时，单元格总宽 ≈ 2×图宽 + 单元格左右边距（默认各 0.19cm）
- **不要为了塞图去新建表格行**。程序新建的 `w:tr/w:tc` 会丢边框和列宽，
  表现为"图片放进去了但表格线没了"。正解见下条。

### 2.5 表格格式丢失的唯一正解：整块复制源表 XML

需要"在原格式的表格里加一行"时，不要逐格写内容，而是把源文件里的整张表深拷贝过来替换：

```python
import copy
from docx import Document

src = Document("招标文件.docx")          # 提供"标准长相"的源文件
dst = Document("响应文件.docx")

def replace_table(dst, src_table, keep_text_rows=2):
    """把 dst 里某张空壳表换成 src 的原表，只保留前 keep_text_rows 行数据"""
    tbl = copy.deepcopy(src_table._tbl)   # 整块 XML，边框/列宽/底纹全带过来
    # ... 如需要裁剪数据行，在 tbl 上按 w:tr 增删，而不是重建
    return tbl
```

判据：替换后打开看**边框是否连续、列宽是否与原表一致**。
只要有一条竖线错位，就是又在程序里新建了 `tc`。

### 2.6 常见证件页的排布惯例

| 内容 | 排布 | 宽度 |
|---|---|---|
| 营业执照 | 单独一页，标题在上，图居中 | 14–15cm（竖版执照） |
| 法定代表人身份证 | 正反两张，同一表格两个单元格并排，或上下两段 | 每张 7–8cm |
| 授权代表身份证 | 同上，独立一页 | 每张 7–8cm |
| 资质证书 | 每证一页，标题写证书全名 | 13–15cm |

每个证件页都给它一个 **Heading 1 标题**（如「营业执照」），目录里就能直接翻到。

---

## 三、交付前必做：清除批注

第 4 步插的变量批注，**一条都不能带到交出去的稿子里**——
那等于把"这里该填什么、数据从哪来"的内部提示摊给评委看。

### 3.1 先枚举，别盲删

```bash
python3 edsdk.py call doc_get_comments --json '{"file_id":"<FILE_ID>"}'
# 返回 total + comments[]，每条含 id / range_begin / range_end / text / author
```

### 3.2 逐条删除

```bash
python3 edsdk.py call doc_delete_comment --json '{"file_id":"<FILE_ID>","id":"<COMMENT_ID>"}'
```

要点：
- **每删一条坐标就会变**，所以先一次性取全部 id，再逐条删；删完不要复用旧坐标
- 删除只移除批注本身，**不动被批注的正文**——正文里该填的值要提前填好
- 有回复线程的批注，要连回复一起删；只删首条可能留下孤儿回复

### 3.3 兜底：直接清 XML（批量、或编辑器不可用时）

```python
import docx
from docx.oxml.ns import qn

d = docx.Document(PATH)
body = d.element.body
for tag in ("w:commentRangeStart", "w:commentRangeEnd"):
    for el in body.findall(f".//{qn(tag)}"):
        el.getparent().remove(el)
for ref in body.findall(f".//{qn('w:commentReference')}"):
    run = ref.getparent()                     # w:r
    if run.tag == qn("w:r"):
        run.getparent().remove(run)
d.save(PATH)
```

⚠️ `comments.xml` 这个 part 本身不会因为上面几步被删除。
用 python-docx 保存后，`word/comments.xml` 仍可能存在但**已无任何引用**——
Word/WPS 打开时不会显示批注，但**严格的评标系统或解包检查仍可能看到残余文本**。
要求彻底干净时，解包后删 `word/comments*.xml`，并同步清 `[Content_Types].xml` 与
`word/_rels/document.xml.rels` 里对应的 Override/Relationship，再重新打包。
最稳的顺序仍是：**用 `doc_delete_comment` 删干净，再保存**，让引擎自己维护 rels。

### 3.4 校验

```python
import zipfile
with zipfile.ZipFile(PATH) as z:
    names = z.namelist()
    print("有 comments part：", [n for n in names if "comment" in n.lower()])
    xml = z.read("word/document.xml").decode("utf-8", "ignore")
    print("正文残留批注锚点：", xml.count("commentReference"), xml.count("commentRangeStart"))
```

两项都为 0 才算清干净。`verify_bid_doc.py` 的 **S6-2** 已把这步做成检查项。

---

## 四、一页纸检查表

| # | 检查 | 判据 | 不过怎么办 |
|---|---|---|---|
| 1 | 目录前无多余页 | 第一页就是「目　录」 | 删空段/说明页 |
| 2 | 每个格式页标题已设层级 | `doc_get_outline` 能列出全部标题 | 按第 2 步重设 |
| 3 | 目录条数 = 格式页数 | 数与实一致 | 漏的补设 Heading 1 |
| 4 | 每页从新页开始 | 逐页翻，无两页挤一页 | 补段前分页 |
| 5 | 无空白页 | 无"只有页眉页脚"的页 | 关掉重复的分页设置 |
| 6 | 目录页码已刷新 | 页码连续且与实页一致；**若定为不显示页码**，则条目末尾无数字且域带 `\n` | F9 后保存，或按 4.1 去掉页码 |
| 7 | 图片真嵌入 | `word/media/` 计数 = 应有张数 | 重插（2.2） |
| 8 | 图片正常显示 | 每张都能看到完整画面 | 改单倍行距（2.3） |
| 9 | 表格边框完好 | 竖线连续、列宽一致 | 整块替换表（2.5） |
| 10 | 批注已清空 | `doc_get_comments` 返回 total=0 | 逐条删（三节） |
| 11 | 页脚有页码 | 每页可见 | 插页码域 |
| 12 | 提示词已删净 | 全文搜不到「（供应商名称）」类括号 | 填值后删提示词 |

---

## 五、坑位速查

| 坑 | 现场表现 | 根因 | 一句话修法 |
|---|---|---|---|
| 目录是空的 | 插了目录但一条都没有 | 标题只调了字号，没设大纲级别 | 挂 Heading 1 |
| 样式设了不生效 | `p.style` 赋了值，WPS 还是正文 | 手工 append 了 `w:pStyle`，pPr 顺序错 | 改用官方 API |
| 目录标题被吞 | 「目　录」和第一条粘在一起 | idx 落在标题段内部 | 拆段 |
| 页码全是"第 1 页" | 目录没刷新 | 域未更新 | 标 dirty 或 F9 |
| 多出空白页 | 白页只有页眉页脚 | 分页符 + 段前分页叠加 | 关掉一个 |
| 图在预览里有、打开没有 | media 计数没变 | 用了 `doc_insert_image` 会话链接 | 改 python-docx 嵌入 |
| 图只显示一条缝 | 有占位但图被裁 | 段落固定行距 | 改单倍行距 |
| 表格线没了 | 图片进去了，边框消失 | 程序新建了 `w:tr/w:tc` | 整块拷源表 XML |
| 目录里出现双编号 | 「一、一、技术方案」 | 标题文字自带编号 + 自动编号 | 去掉自动编号 |
| 批注跟着交出去了 | 评委能看到内部说明 | 忘了清批注 | 逐条删 + 校验 |
| **目录"不存在"** | 脚本说没目录，打开却有 | 目录整体包在 `w:sdt` 内容控件里，`doc.paragraphs` 看不见 | 遍历 `body.iter(qn("w:p"))` |
| **目录条目比对全不匹配** | 每条都判"标题不在目录中" | 条目带自动编号（"第一章 xxx"），正文标题的 `w:t` 里没有编号 | 比对前去掉 `第X章`/`一、`/`1.` 前缀 |
| **目录页码全是 0** | 明明更新过域 | 只标了 `dirty`，没真正在软件里更新域 | F9 后保存；或按 4.1 改成不显示页码 |
