---
name: skillhub-skill-toxicity-structure-alert
description: "使用 `toxicity-structure-alert` 通过可重现的工作流程、明确的验证和结构化输出分析数据，生成可供审查的解读结果。"
---

# 毒性结构预警 (Skill ID: 141)

识别药物分子中潜在的毒性警示结构。

## 使用场景

- 当任务是扫描识别药物分子中潜在毒性警示结构时，请使用本技能。
- 当数据分析任务需要明确假设、有界范围和可重现输出格式时，请使用本技能。
- 当需要针对输入缺失、执行错误或部分证据提供有文档记录的回退路径时，请使用本技能。

## 主要功能

相关详情请参阅上方的 `## Features`。

- 以范围聚焦的工作流程，与以下目标对齐：使用 `toxicity-structure-alert` 通过可重现的工作流程、明确的验证和结构化输出分析数据，生成可供审查的解读结果。
- 可执行路径：`scripts/main.py`。
- 任务专属指南参考资料位于 `references/`。
- 结构化执行路径，旨在保持输出的一致性和可审查性。

## 依赖项

- Python 3.8+
- RDKit

## 使用示例

相关详情请参阅上方的 `## Usage`。

```bash
cd "20260318/scientific-skills/Data Analytics/toxicity-structure-alert"
python -m py_compile scripts/main.py
python scripts/main.py --help
```

示例运行计划：
1. 确认用户输入、输出路径以及所有必要的配置参数。
2. 如脚本使用固定设置，请编辑文件内的 `CONFIG` 块或文档化参数。
3. 使用已验证的输入运行 `python scripts/main.py`。
4. 检查生成的输出，并在明确说明所有假设的情况下返回最终结果。

## 实现细节

相关详情请参阅上方的 `## Workflow`。

- 执行模型：验证请求，选择封装的工作流程，生成有界交付物。
- 输入控制：在运行任何脚本之前，确认源文件、范围限制、输出格式和验收标准。
- 主要实现入口：`scripts/main.py`。
- 参考指南：`references/` 包含支持性规则、提示或检查清单。
- 需优先明确的参数：输入路径、输出路径、范围过滤器、阈值以及任何领域特定的约束条件。
- 输出规范：保持结果可重现，明确标识假设，避免未文档化的副作用。

## 快速检查

在深度执行前，使用此命令验证封装脚本入口点是否可正常解析。

```bash
python -m py_compile scripts/main.py
```

## 审计就绪命令

使用以下具体命令进行验证。这些命令经过精心设计，完全自包含，避免使用占位符路径。

```bash
python -m py_compile scripts/main.py
python scripts/main.py --help
python scripts/main.py --input "Audit validation sample with explicit symptoms, history, assessment, and next-step plan." --format json
```

## 工作流程

1. 在进行详细工作之前，确认用户目标、所需输入和不可协商的约束条件。
2. 验证请求是否与文档记录的范围匹配，若任务需要不支持的假设则提前终止。
3. 仅使用实际可用的输入，采用封装的脚本路径或文档记录的推理路径。
4. 返回结构化结果，分别列出假设、交付物、风险和未解决事项。
5. 若执行失败或输入不完整，切换至回退路径，并明确说明阻止完成的原因。

## 功能特性

- 扫描分子结构（SMILES/SMARTS）
- 识别已知毒性警示结构
- 评估潜在毒性风险等级
- 生成详细报告

## 支持的警示结构

| 警示结构 | 毒性类型 | 风险等级 |
|---------|---------|---------|
| Aromatic Nitro | 致突变性 | 高 |
| Aromatic Amine | 致癌性 | 高 |
| Epoxide | 烷基化剂 | 高 |
| Aldehyde | 反应性毒性 | 中 |
| Acyl Chloride | 反应性毒性 | 中 |
| Michael Acceptor | 亲电毒性 | 中 |
| Hydrazine | 肝毒性 | 高 |
| Haloalkyl | 烷基化剂 | 高 |
| Quinone | 氧化应激 | 中 |
| Thiol-Reactive Groups | 蛋白质结合 | 低-中 |

## 使用方法

```text
python -m py_compile scripts/main.py

# Example invocation: python scripts/main.py --input <smiles_string> [--format json|text]
```

### 参数

- `--input, -i`：输入 SMILES 字符串（必填）
- `--format, -f`：输出格式，可选 `json` 或 `text`（默认：text）
- `--detail, -d`：详细程度，可选 `basic`、`standard`、`full`（默认：standard）

### 示例

```text

# Basic text output
python scripts/main.py -i "O=[N+]([O-])c1ccccc1"

# JSON format output
python scripts/main.py -i "O=C1OC1c1ccccc1" -f json

# Detailed report
python scripts/main.py -i "c1ccc2c(c1)ccc1c3ccccc3ccc21" -d full
```

### Python API

```python
from scripts.main import ToxicityAlertScanner

scanner = ToxicityAlertScanner()
result = scanner.scan("O=[N+]([O-])c1ccccc1")
print(result.alerts)
```

## 输出格式

### JSON 输出

```json
{
  "input": "O=[N+]([O-])c1ccccc1",
  "mol_weight": 123.11,
  "alert_count": 1,
  "risk_score": 0.85,
  "risk_level": "HIGH",
  "alerts": [
    {
      "name": "Aromatic Nitro",
      "type": "mutagenic",
      "smarts": "[N+](=O)[O-]",
      "risk_level": "HIGH",
      "description": "May cause DNA damage and mutagenicity"
    }
  ],
  "recommendations": [
    "Recommend Ames test validation",
    "Consider structural optimization to reduce toxicity"
  ]
}
```

## 风险等级

- **HIGH**：已知显著毒性，强烈建议避免
- **MEDIUM**：潜在毒性，建议进一步评估
- **LOW**：轻微关注，可根据具体情况考虑

## 注意事项

1. 本工具基于已知警示结构，不能替代全面的毒理学评估
2. 可能同时存在假阳性和假阴性结果
3. 建议与其他 ADMET 预测工具配合使用

## 参考文献

- Ashby J., Tennant R.W. (1988) Chemical structure, Salmonella mutagenicity...
- Kazius J., McGuire R., Bursi R. (2005) Derivation and validation of toxicophores...
- Enoch S.J., Cronin M.T.D. (2010) A review of the electrophilic reaction chemistry...

## 风险评估

| 风险指标 | 评估 | 等级 |
|----------------|------------|-------|
| 代码执行 | Python/R 脚本在本地执行 | 中 |
| 网络访问 | 无外部 API 调用 | 低 |
| 文件系统访问 | 读取输入文件，写入输出文件 | 中 |
| 指令篡改 | 标准提示指南 | 低 |
| 数据暴露 | 输出文件保存至工作区 | 低 |

## 安全检查清单

- [ ] 无硬编码凭证或 API 密钥
- [ ] 无未授权文件系统访问（../）
- [ ] 输出不暴露敏感信息
- [ ] 已启用提示注入防护
- [ ] 输入文件路径已验证（无 ../ 路径遍历）
- [ ] 输出目录限制在工作区内
- [ ] 脚本在沙箱环境中执行
- [ ] 错误消息已净化（不暴露堆栈跟踪）
- [ ] 依赖项已审计

## 前置条件

```text

# Python dependencies
pip install -r requirements.txt
```

## 评估标准

### 成功指标
- [ ] 主要功能成功执行
- [ ] 输出满足质量标准
- [ ] 优雅处理边界情况
- [ ] 性能可接受

### 测试用例
1. **基本功能**：标准输入 → 预期输出
2. **边界情况**：无效输入 → 优雅错误处理
3. **性能**：大型数据集 → 可接受的处理时间

## 生命周期状态

- **当前阶段**：草稿
- **下次审查日期**：2026-03-06
- **已知问题**：无
- **计划改进**：
  - 性能优化
  - 支持更多功能

## 输出要求

每个最终响应在相关时应明确以下事项：

- 目标或请求的交付物
- 所用输入及引入的假设
- 工作流程或决策路径
- 核心结果、建议或工件
- 约束条件、风险、注意事项或验证需求
- 未解决事项和后续检查

## 错误处理

- 若缺少必需输入，请明确说明缺少哪些字段，并仅请求最少量的额外信息。
- 若任务超出文档记录的范围，请停止操作，而非猜测或悄然扩大任务范围。
- 若 `scripts/main.py` 失败，请报告失败点，总结仍可安全完成的内容，并提供手动回退方案。
- 不得伪造文件、引用、数据、搜索结果或执行结果。

## 输入验证

本技能接受与 `toxicity-structure-alert` 文档记录用途相匹配、且包含足够上下文以安全完成工作流程的请求。

当请求超出范围、缺少关键输入或需要不支持的假设时，不得继续工作流程。请改为回复：

> `toxicity-structure-alert` 仅处理其文档记录的工作流程。请提供缺少的必需输入，或切换至更适合的技能。

## 响应模板

对于非简单请求，请使用以下固定结构：

1. 目标
2. 已接收输入
3. 假设
4. 工作流程
5. 交付物
6. 风险与限制
7. 后续检查

若请求较为简单，可压缩结构，但当假设和限制影响正确性时，仍需明确列出。

## 待收集输入

- 必需输入：用户目标、主要数据或源文件以及请求的输出格式。
- 可选输入：输出目录、格式偏好和验证约束条件。
- 若必需输入不可用，请在继续之前返回简短的澄清请求。

## 输出契约

- 返回简短摘要、主要交付物以及任何实质性影响解读的假设。
- 若执行部分完成，请标注成功的部分、失败的部分以及下一个安全恢复步骤。
- 将最终答案保持在技能的文档记录范围内。

## 验证与安全规则

- 在执行之前，验证标识符、文件路径和用户提供的参数。
- 不得伪造结果、指标、引用或下游结论。
- 当依赖项、凭证或必需输入缺失时，使用安全的回退行为。
- 以简洁的诊断和恢复路径呈现任何执行失败。
