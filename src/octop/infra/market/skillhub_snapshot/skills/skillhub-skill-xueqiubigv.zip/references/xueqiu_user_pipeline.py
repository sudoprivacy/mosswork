# -*- coding: utf-8 -*-
"""
雪球用户跟踪 —— 确定性核心管线
================================
> © 版权声明 | 创作者/原创者：投资实战派Alpha hub 成员。本脚本受版权保护，引用或转载须保留此署名。

本文件是 references/xueqiu-user-crawler-prompt.md 的"确定性内核"：把规则里可计算、可复现的部分
（日期窗过滤、公司过滤 B、低研究价值过滤、内容质量/互动热度打分、近重复去重、CSV/审计/质量检查/
按帖子ID增量合并）代码化。LLM 只负责：① 爬取原始帖 → ② 运行本脚本 → ③ 补写观点摘要。

双模式（--mode，仅对过滤语义有影响）：
  A 全量（默认，不传 --company）：跟踪某人【全部】发言，移除主讨论对象硬门槛，质量分主导排序。
  B 公司过滤（传 --company 公司名）：在 A 的基础上，仅保留【提及该公司】的帖子（entity 词库命中），
            其余逻辑不变。即"先全量再按公司收窄"，B 是 A 的一个可选维度。

权重（质量优先）：质量(5000) > 相关性(3000) > 互动热度(对数)。用户模式下不强制主讨论对象。

用法：
  python xueqiu_user_pipeline.py --dry-run                      # 内置样本自测（A）
  python xueqiu_user_pipeline.py --input raw.json --out ./out  # A 全量
  python xueqiu_user_pipeline.py --input raw.json --out ./out --company 腾讯   # B 公司过滤
  python xueqiu_user_pipeline.py --input raw.json --out ./out --merge-with prev.csv  # 增量合并
"""

import argparse
import csv
import json
import math
import os
import re
import difflib
from datetime import datetime, timedelta

# ---------------------------------------------------------------------------
# 权重
# ---------------------------------------------------------------------------
W_REL, W_QUAL = 3000, 5000
QUAL_GATE = 15          # 用户模式质量门槛（比文章模式45大幅降低：个人发言多为短文/随想，不应被研究论文标准卡掉）
DETAIL_CAP = 120
PRICE_RE = re.compile(r"(上涨|下跌|涨超|跌超|报\s*[\d.]+|创历史新高|市值突破|普涨|普跌)")
SHORT_NEWS_SRC = ["财联社", "格隆汇", "智通"]


# ---------------------------------------------------------------------------
# 1. 词库
# ---------------------------------------------------------------------------
def build_lexicons(company_cn, aliases=None, industry_words=None):
    entity = [company_cn] + (aliases or [])
    intent = ["护城河", "竞争优势", "商业模式", "估值", "财报", "年报", "投资逻辑",
              "收入", "利润", "毛利率", "市场份额", "竞争对手", "风险", "监管",
              "产品路线", "学习笔记", "深度分析", "持仓", "仓位", "判断", "看好", "谨慎"]
    background_role = ["供应商", "认证", "进入供应链", "云服务", "采购", "交易系统", "供应方", "底层"]
    return {"entity": entity, "intent": intent, "industry": industry_words or [],
            "bg_role": background_role}


def has_any(text, words):
    return [w for w in words if w in text]


def count_hits(text, words):
    return sum(text.count(w) for w in words)


SUBJECT_SECTION_RE = re.compile(r"(专门|本文|一、|二、|三、|##|1\.|2\.|3\.).{0,10}"
                                r"(护城河|商业模式|财报|估值|竞争|收入|利润|风险|客户|订单|产品路线)")


# ---------------------------------------------------------------------------
# 2. 低研究价值过滤（用户模式下默认开启，但门槛更松，保留朴素高质量个人观点）
# ---------------------------------------------------------------------------
def low_value_filter(post, lex):
    title = post.get("title", "")
    body = post.get("body", "")
    intent_hit = bool(has_any(body, lex["intent"]))
    has_section = bool(SUBJECT_SECTION_RE.search(body))
    # 用户模式：互动量高的帖有阅读价值，不因短而剔除
    engagement = int(post.get("likes", 0)) + int(post.get("comments", 0)) + int(post.get("forwards", 0))
    high_engagement = engagement >= 10

    if PRICE_RE.search(title + body[:80]) and not intent_hit and len(body) < 200:
        return "纯行情播报/股价新闻（无研究含量）"
    if any(s in body for s in SHORT_NEWS_SRC) and len(body) < 250 and not intent_hit:
        return "低研究价值短新闻/快讯"
    if len(body) < 20 and not intent_hit:
        return "正文过短（近空帖/纯转发）"
    if has_any(title + body[:300], lex["bg_role"]) and not has_section and len(body) < 200 and not high_engagement:
        return "仅为供应链/客户采购事件背景"
    return None


# ---------------------------------------------------------------------------
# 3. 相关性分（在 B 公司过滤下，衡量与公司的贴合度）
# ---------------------------------------------------------------------------
def relevance_score(post, lex):
    title = post.get("title", "")
    body = post.get("body", "")
    s = 0
    if has_any(title, lex["entity"]):
        s += 20
    if has_any(title, lex["intent"]):
        s += 10
    if count_hits(body, lex["entity"]) >= 3:
        s += 15
    if len(has_any(body, lex["intent"])) >= 2:
        s += 15
    if SUBJECT_SECTION_RE.search(body):
        s += 20
    cats = ["业务", "商业模式", "竞争格局", "财务", "估值", "风险"]
    if len(has_any(body, cats)) >= 3:
        s += 20
    return max(0, min(100, s))


# ---------------------------------------------------------------------------
# 4. 内容质量分
# ---------------------------------------------------------------------------
def quality_score(post, lex):
    body = post.get("body", "")
    s = 0
    if len(body) >= 800:
        s += 10
    if re.search(r"(一、|二、|##|1\.|2\.)", body) or "：" in body:
        s += 15
    if has_any(body, ["营收", "净利", "毛利率", "EPS", "PE", "估值", "测算", "数据"]):
        s += 20
    if len(has_any(body, lex["entity"] + ["对手", "竞品"])) >= 2:
        s += 15
    if has_any(body, ["风险", "隐患", "挑战", "不确定性"]):
        s += 15
    if has_any(body, ["结论", "判断", "我认为", "看好", "谨慎"]):
        s += 15
    if not has_any(body, ["广告", "推广"]) and len(body) >= 300:
        s += 10
    # 用户模式专属：个人洞察/方法论/反思类帖有独立价值
    if has_any(body, ["洞察", "感悟", "发现", "反思", "特点", "本质", "规律", "逻辑",
                      "生意", "商业模式", "垄断", "护城河", "估值", "周期"]):
        s += 15
    # 高互动本身就是质量信号（用户模式）
    engagement = int(post.get("likes", 0)) + int(post.get("comments", 0)) + int(post.get("forwards", 0))
    if engagement >= 20:
        s += 10
    return max(0, min(100, s))


# ---------------------------------------------------------------------------
# 5. 互动热度分（自然对数）
# ---------------------------------------------------------------------------
def interaction_score(post):
    likes = int(post.get("likes", 0))
    comments = int(post.get("comments", 0))
    forwards = int(post.get("forwards", 0))
    return round(math.log(1 + likes) * 10 + math.log(1 + comments) * 15
                 + math.log(1 + forwards) * 10, 1)


def raw_interaction(post):
    return int(post.get("comments", 0)) * 3 + int(post.get("forwards", 0)) * 2 + int(post.get("likes", 0))


def high_engagement_bonus(post, passed_raw_list):
    if not passed_raw_list:
        return 0
    thr = sorted(passed_raw_list)[max(0, len(passed_raw_list) * 3 // 4 - 1)]
    return 300 if raw_interaction(post) >= thr else 0


def final_score(rel, qual, inter, bonus):
    return rel * W_REL + qual * W_QUAL + inter + bonus


# ---------------------------------------------------------------------------
# 6. 去重（按 id 精确 + 近重复 difflib）
# ---------------------------------------------------------------------------
def normalize_title(t):
    return re.sub(r"[\s\W]+", "", t)


def near_dup_group(posts):
    assigned, groups = {}, {}
    gid = 0
    for i, p in enumerate(posts):
        if p["id"] in assigned:
            continue
        gid += 1
        keep = p
        members = [p]
        for q in posts[i + 1:]:
            if q["id"] in assigned:
                continue
            t_sim = difflib.SequenceMatcher(None, normalize_title(p["title"]),
                                            normalize_title(q["title"])).ratio()
            b_sim = difflib.SequenceMatcher(None, p["body"][:1500], q["body"][:1500]).ratio()
            if t_sim >= 0.85 or b_sim >= 0.80:
                members.append(q)
                if q.get("_final", 0) > keep.get("_final", 0):
                    keep = q
        for m in members:
            assigned[m["id"]] = (gid, keep["id"])
        groups[gid] = (keep["id"], [m["id"] for m in members])
    return assigned, groups


# ---------------------------------------------------------------------------
# 7. 日期窗过滤
# ---------------------------------------------------------------------------
def in_window(post, days):
    t = post.get("time", "")
    try:
        dt = datetime.strptime(t, "%Y-%m-%d %H:%M")
    except ValueError:
        return True  # 解析失败则保留，交由人工判断
    return dt >= (datetime.now() - timedelta(days=days))


# ---------------------------------------------------------------------------
# 8. CSV 输出
# ---------------------------------------------------------------------------
CSV_COLS = ["排名", "标题", "作者", "发布时间", "评论数", "点赞数", "转发数", "链接",
            "雪球帖子ID", "正文观点摘要", "评论区主要争议点", "最热门的三条评论",
            "最终分", "相关性分", "内容质量分", "互动热度分", "高互动补充分",
            "原始互动热度", "命中关键词组", "召回来源", "抓取时间",
            "是否近重复", "近重复组ID", "保留帖子ID", "去重类型", "未入选原因"]


def write_csv(path, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CSV_COLS, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


# ---------------------------------------------------------------------------
# 9. 增量合并（按帖子 ID 主键；新帖追加，旧帖互动数据更新）
# ---------------------------------------------------------------------------
def merge_previous(prev_path, posts):
    if not prev_path or not os.path.exists(prev_path):
        return posts
    old = {}
    try:
        with open(prev_path, encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                old[row.get("雪球帖子ID", "")] = row
    except Exception:
        return posts
    merged = {}
    for p in posts:
        merged[p["id"]] = p
    added, updated = 0, 0
    for pid, row in old.items():
        if pid in merged:
            # 更新互动数据（取较大值）
            for k, fld in (("点赞数", "likes"), ("评论数", "comments"), ("转发数", "forwards")):
                try:
                    new_v = int(merged[pid].get(fld, 0))
                    old_v = int(row.get(k, 0) or 0)
                    merged[pid][fld] = max(new_v, old_v)
                except ValueError:
                    pass
            updated += 1
        else:
            # 旧帖保留（历史资产不丢）
            merged[pid] = {
                "id": pid, "title": row.get("标题", ""), "body": "",
                "author": row.get("作者", ""), "time": row.get("发布时间", ""),
                "likes": int(row.get("点赞数", 0) or 0),
                "comments": int(row.get("评论数", 0) or 0),
                "forwards": int(row.get("转发数", 0) or 0),
                "url": row.get("链接", ""), "recall": "historical",
                "_historical": True,
            }
            added += 1
    print("  增量合并：新增历史帖 %d，更新互动 %d" % (added, updated))
    return list(merged.values())


# ---------------------------------------------------------------------------
# 10. 主流程
# ---------------------------------------------------------------------------
def run(posts, lex, top_n=200, days=7, qual_gate=QUAL_GATE, company=None, lowvalue=True):
    # 日期窗
    posts = [p for p in posts if in_window(p, days)]
    # B 公司过滤（可选）
    if company:
        posts = [p for p in posts
                 if has_any(p.get("title", "") + p.get("body", ""), lex["entity"])]
    failed = []
    seen = {}
    for p in posts:
        if "id" not in p or "body" not in p:
            failed.append({"id": p.get("id", "?"), "stage": "输入校验",
                           "reason": "缺少 id 或 body 字段"})
            continue
        seen[p["id"]] = p
    candidates = list(seen.values())

    excluded, passed = [], []
    raw_list = []
    for p in candidates:
        try:
            lv = low_value_filter(p, lex) if lowvalue else None
            rel = relevance_score(p, lex)
            qual = quality_score(p, lex)
            inter = interaction_score(p)
            raw = raw_interaction(p)
        except Exception as e:
            failed.append({"id": p.get("id", "?"), "stage": "打分", "reason": str(e)})
            continue
        raw_list.append(raw)
        rec = {"id": p["id"], "title": p.get("title", ""), "author": p.get("author", ""),
               "time": p.get("time", ""), "comments": p.get("comments", 0),
               "likes": p.get("likes", 0), "forwards": p.get("forwards", 0),
               "url": p.get("url", ""), "rel": rel, "qual": qual, "inter": inter,
               "raw": raw, "recall": p.get("recall", "")}
        p["_rec"] = rec
        p["_rel"], p["_qual"], p["_inter"], p["_raw"] = rel, qual, inter, raw

        if lv:
            rec["reason"] = lv
            excluded.append(rec)
            continue
        if qual < qual_gate:
            rec["reason"] = "内容质量分低于最低门槛"
            excluded.append(rec)
            continue
        passed.append(p)

    passed_raw = [p["_raw"] for p in passed]
    for p in passed:
        p["_bonus"] = high_engagement_bonus(p, passed_raw)
        p["_final"] = final_score(p["_rel"], p["_qual"], p["_inter"], p["_bonus"])

    assigned, groups = near_dup_group(passed)
    keep_ids = {keep for (_, keep) in assigned.values()}
    near_dup_removed = []
    for p in passed:
        gid, keep = assigned[p["id"]]
        p["_gid"], p["_keep"] = gid, keep
        if p["id"] != keep:
            rec = p["_rec"].copy()
            rec["reason"] = "近重复内容，已保留帖子ID：%s" % keep
            near_dup_removed.append(rec)
    final_pass = [p for p in passed if p["id"] in keep_ids]
    final_pass.sort(key=lambda x: x["_final"], reverse=True)

    rows = []
    for rank, p in enumerate(final_pass[:top_n], 1):
        r = p["_rec"]
        rows.append({
            "排名": rank, "标题": r["title"], "作者": r["author"], "发布时间": r["time"],
            "评论数": r["comments"], "点赞数": r["likes"], "转发数": r["forwards"],
            "链接": r["url"], "雪球帖子ID": r["id"],
            "正文观点摘要": p.get("summary", ""), "评论区主要争议点": p.get("debate", ""),
            "最热门的三条评论": p.get("top_comments", ""),
            "最终分": p["_final"], "相关性分": r["rel"], "内容质量分": r["qual"],
            "互动热度分": r["inter"], "高互动补充分": p["_bonus"], "原始互动热度": r["raw"],
            "命中关键词组": ",".join(has_any(p.get("body", ""), lex["intent"])),
            "召回来源": r["recall"],
            "抓取时间": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "是否近重复": "否", "近重复组ID": p["_gid"], "保留帖子ID": p["_keep"],
            "去重类型": "非重复", "未入选原因": "",
        })

    excl_rows = []
    for r in excluded:
        excl_rows.append({"雪球帖子ID": r["id"], "标题": r["title"],
                          "未入选原因": r["reason"], "原始互动热度": r["raw"]})
    for r in near_dup_removed:
        excl_rows.append({"雪球帖子ID": r["id"], "标题": r["title"],
                          "未入选原因": r["reason"], "原始互动热度": r["raw"]})

    return rows, excl_rows, groups, failed


def quality_check(rows, excluded):
    checks = []
    def chk(name, cond):
        checks.append((name, "PASS" if cond else "FAIL"))
    chk("CSV 按最终分降序", all(rows[i]["最终分"] >= rows[i + 1]["最终分"]
                                for i in range(len(rows) - 1)) if rows else True)
    chk("高互动帖排序合理（Top1 互动不为0）",
        (rows[0]["原始互动热度"] > 0) if rows else True)
    chk("剔除明细可解释", all((r.get("未入选原因") or "") for r in excluded))
    return checks


# ---------------------------------------------------------------------------
# 11. 内置干跑样本（模拟 永庆好公司 风格，覆盖 A 全量）
# ---------------------------------------------------------------------------
def dry_run_sample():
    return [
        {"id": "U1", "title": "workbuddy 帮我整理文件夹", "author": "永庆好公司",
         "time": "2026-07-02 21:22", "likes": 25, "comments": 5, "forwards": 0,
         "recall": "user:永庆好公司",
         "body": "workbuddy 帮我整理文件夹，真的是赏心悦目、太满意了。AI 工具确实能提升投研效率。"},
        {"id": "U2", "title": "科技的一个特点", "author": "永庆好公司",
         "time": "2026-07-03 11:38", "likes": 22, "comments": 0, "forwards": 0,
         "recall": "user:永庆好公司",
         "body": "科技的一个特点是：当你真正理解了一件事，知道了它是怎么运作的、未来会怎么走的时候，"
                 "恰恰就是你该转向下一件事的时候了。你应该总是去寻找那些我们还不知道答案的安静角落。"},
        {"id": "U3", "title": "你为 AI 付了多少钱", "author": "永庆好公司",
         "time": "2026-07-06 09:29", "likes": 11, "comments": 10, "forwards": 0,
         "recall": "user:永庆好公司",
         "body": "你为ai付了多少钱？我付费的ai相关产品：claude 200美元被封了；workbuddy 年度会员1350；"
                 "腾讯文档部分因为ai；腾讯会议部分因为ai。结论：工具要服务于自己的工作流程。"},
        {"id": "U4", "title": "腾讯又回到400了", "author": "永庆好公司",
         "time": "2026-06-29 10:11", "likes": 14, "comments": 4, "forwards": 0,
         "recall": "user:永庆好公司",
         "body": "腾讯又回到400了……怎么说呢，只要时间够久，都会跌下来。投资腾讯要看长期现金流。"},
        {"id": "U5", "title": "美光：1.7倍PB到17倍PB", "author": "永庆好公司",
         "time": "2026-06-30 12:24", "likes": 9, "comments": 3, "forwards": 0,
         "recall": "user:永庆好公司",
         "body": "美光：1.7倍PB到17倍PB。周期股的估值波动之大，值得记录。"},
        {"id": "U6", "title": "某基金广告", "author": "推广号",
         "time": "2026-07-01 10:00", "likes": 1, "comments": 0, "forwards": 0,
         "recall": "user:推广号",
         "body": "广告：限时申购XX基金，把握牛市机会。推广"},
    ]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--input")
    ap.add_argument("--out", default="./out")
    ap.add_argument("--company", default="", help="B 公司过滤：仅保留提及该公司的帖子（留空=A全量）")
    ap.add_argument("--days", type=int, default=7, help="日期窗：仅保留最近 N 天")
    ap.add_argument("--top-n", type=int, default=200)
    ap.add_argument("--no-lowvalue", action="store_true", help="关闭低研究价值过滤")
    ap.add_argument("--merge-with", default="", help="增量合并：上一期 CSV 路径")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    if args.dry_run or not args.input:
        posts = dry_run_sample()
        print("[dry-run] 内置样本，共 %d 帖（模式: %s）" %
              (len(posts), "B(公司=%s)" % args.company if args.company else "A全量"))
    else:
        with open(args.input, encoding="utf-8") as f:
            posts = json.load(f)
        if args.merge_with:
            posts = merge_previous(args.merge_with, posts)

    mode_label = "B(公司过滤=%s)" % args.company if args.company else "A(全量)"
    lex = build_lexicons(args.company) if args.company else build_lexicons("__none__")
    rows, excl, groups, failed = run(
        posts, lex, top_n=args.top_n, days=args.days,
        company=args.company or None, lowvalue=not args.no_lowvalue)

    write_csv(os.path.join(args.out, "候选全集.csv"), [
        {"雪球帖子ID": p["id"], "标题": p.get("title", ""), "召回来源": p.get("recall", ""),
         "是否最终入选": "是" if p["id"] in {r["雪球帖子ID"] for r in rows} else "否"}
        for p in posts])
    write_csv(os.path.join(args.out, "总表.csv"), rows)
    write_csv(os.path.join(args.out, "剔除明细.csv"), excl)

    with open(os.path.join(args.out, "failed.log"), "w", encoding="utf-8") as f:
        if failed:
            for x in failed:
                f.write("%s\t%s\t%s\n" % (x["id"], x["stage"], x["reason"]))
        else:
            f.write("无失败项\n")
    with open(os.path.join(args.out, "质量检查.txt"), "w", encoding="utf-8") as f:
        for name, st in quality_check(rows, excl):
            f.write("[%s] %s\n" % (st, name))
    with open(os.path.join(args.out, "抓取说明.txt"), "w", encoding="utf-8") as f:
        f.write("模式: %s\n日期窗: 最近%d天\n候选总数: %d\n入选数: %d\n剔除数: %d\n"
                "近重复组: %d\n失败项: %d\n权重: 相关性*%d 质量*%d\n"
                % (mode_label, args.days, len(posts), len(rows), len(excl),
                   len(groups), len(failed), W_REL, W_QUAL))

    print("\n=== %s | 入选 Top %d ===" % (mode_label, len(rows)))
    for r in rows:
        print("  %2d. [相%3d|质%3d|互动%5.1f|分%9d] %s"
              % (r["排名"], r["相关性分"], r["内容质量分"], r["互动热度分"],
                 r["最终分"], r["标题"]))
    print("\n=== 剔除明细 ===")
    for r in excl:
        print("  - %s -> %s" % (r["标题"][:24], r["未入选原因"]))
    print("\n=== 质量检查 ===")
    for name, st in quality_check(rows, excl):
        print("  [%s] %s" % (st, name))


if __name__ == "__main__":
    main()
