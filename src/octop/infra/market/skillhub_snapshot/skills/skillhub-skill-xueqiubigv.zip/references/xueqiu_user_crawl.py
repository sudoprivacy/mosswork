# -*- coding: utf-8 -*-
"""
雪球用户跟踪 —— 用户时间线爬虫（轻量直连版）
=============================================
> © 版权声明 | 创作者/原创者：投资实战派Alpha hub 成员。本脚本受版权保护，引用或转载须保留此署名。

核心发现（2026-07 实测）：雪球 `user_timeline.json` 接口在**未登录**状态下也能直接返回
结构化 JSON（含时间/正文/转评赞藏）。因此本爬虫优先走「轻量直连 requests」，无需 CDP /
已登录浏览器，远比「搜索召回 + CDP 拦截」方案简单。仅在直连被 WAF 拦截时才需回退到
`雪球文章` skill 的 CDP 方案（见 SKILL.md）。

输入：
  --user-id   雪球数字用户 ID（从主页 xueqiu.com/u/XXXXXXXX 取，最可靠）
  --user-name 用户显示名（最佳努力解析；推荐直接给 --user-id）
  --days      仅保留最近 N 天（默认 7）
  --max       最多抓取帖子数（默认 200）
  --cookie    可选，登录态 cookie（直连被拦时填入可绕过 WAF）
  --out       输出 raw JSON 路径

输出：raw JSON 列表，字段与 雪球文章 管线完全兼容：
  id / title / body / author / time / likes / comments / forwards / views / url / recall

用法：
  python xueqiu_user_crawl.py --user-id 6865675576 --days 7 --out raw.json
  python xueqiu_user_crawl.py --user-id 1965894836 --days 30 --max 300 --out pauluw.json
"""

import argparse
import json
import math
import re
import sys
import time
from datetime import datetime, timedelta

try:
    import requests
except ImportError:
    requests = None

DEFAULT_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
             "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
BASE = "https://xueqiu.com"
TIMELINE = BASE + "/statuses/user_timeline.json"


def strip_html(text):
    if not text:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", text)
    text = re.sub(r"</p>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"&nbsp;", " ", text)
    text = re.sub(r"&amp;", "&", text)
    text = re.sub(r"&lt;", "<", text)
    text = re.sub(r"&gt;", ">", text)
    text = re.sub(r"\s*\n\s*\n\s*", "\n", text)
    return text.strip()


def parse_time(val):
    """把 API 返回的 created_at 解析为 ISO 字符串（%Y-%m-%d %H:%M）。"""
    if val is None:
        return ""
    # 数字：雪球雪花 id 高位含毫秒时间戳；也可能是 Unix 秒/毫秒
    if isinstance(val, (int, float)):
        # 兼容秒 / 毫秒
        if val > 1e12:
            dt = datetime.fromtimestamp(val / 1000)
        else:
            dt = datetime.fromtimestamp(val)
        return dt.strftime("%Y-%m-%d %H:%M")
    s = str(val).strip()
    # 形如 "Wed Jul 07 20:42:11 +0800 2026" 或 "2026-07-07 20:42:11"
    for fmt in ("%a %b %d %H:%M:%S %z %Y", "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d %H:%M")
        except ValueError:
            continue
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        return "%s-%s-%s 00:00" % (m.group(1), m.group(2), m.group(3))
    return s[:16]


def resolve_user_id(name, cookie=""):
    """最佳努力：用搜索接口把显示名解析成数字 user_id。失败返回空串。"""
    if not requests:
        return ""
    headers = {"User-Agent": DEFAULT_UA, "Referer": BASE + "/search"}
    if cookie:
        headers["Cookie"] = cookie
    try:
        r = requests.get(BASE + "/query/v1/search/user.json",
                         params={"q": name, "count": 5, "page": 1},
                         headers=headers, timeout=15)
        j = r.json()
        for u in (j.get("list") or []):
            if name in (u.get("screen_name") or ""):
                return str(u.get("id"))
        # 退而求其次：取第一条
        lst = j.get("list") or []
        if lst:
            return str(lst[0].get("id"))
    except Exception:
        pass
    return ""


def crawl(user_id, days=7, max_posts=200, cookie="", out="raw.json"):
    if not requests:
        print("ERROR: 缺少 requests 库，请先 `pip install requests`", file=sys.stderr)
        sys.exit(2)
    headers = {
        "User-Agent": DEFAULT_UA,
        "Referer": "%s/u/%s" % (BASE, user_id),
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json",
    }
    if cookie:
        headers["Cookie"] = cookie

    cutoff = datetime.now() - timedelta(days=days)
    posts, seen = [], set()
    page = 1
    reached_old = False

    print("[1] 抓取 user_timeline: uid=%s days=%d max=%d" % (user_id, days, max_posts))
    while len(posts) < max_posts and page <= 50 and not reached_old:
        try:
            r = requests.get(TIMELINE, params={
                "user_id": user_id, "page": page, "count": 20,
                "sort": 0, "type": 0,
            }, headers=headers, timeout=20)
            if r.status_code != 200 or "aliyun_waf" in r.text or "waf" in r.text.lower()[:200]:
                print("ERROR: 直连被 WAF 拦截（status=%s）。请填入 --cookie 登录态，"
                      "或回退到 雪球文章 skill 的 CDP 方案。" % r.status_code)
                sys.exit(4)
            j = r.json()
        except Exception as e:
            print("ERROR: 请求/解析失败: %s" % repr(e)[:200])
            if page == 1:
                sys.exit(5)
            break

        items = j.get("statuses") or j.get("list") or []
        if not items:
            print("  无更多数据，停止（page=%d）" % page)
            break

        for it in items:
            sid = str(it.get("id"))
            if sid in seen:
                continue
            seen.add(sid)
            uid = (it.get("user") or {}).get("id") or user_id
            screen = (it.get("user") or {}).get("screen_name", "")
            # 正文：优先外层 text（用户自己的评论），空则取被转发的原文
            text = strip_html(it.get("text") or it.get("description") or "")
            rt = it.get("retweet_status") or {}
            if not text and rt:
                text = strip_html(rt.get("text") or rt.get("description") or "")
            tiso = parse_time(it.get("created_at"))
            # 日期窗过滤
            try:
                dt = datetime.strptime(tiso, "%Y-%m-%d %H:%M")
            except ValueError:
                dt = None
            if dt and dt < cutoff:
                reached_old = True
                break
            if not text:
                continue
            posts.append({
                "id": sid,
                "title": re.sub(r"\s+", " ", text[:60]).strip(),
                "body": text,
                "author": screen,
                "time": tiso,
                "likes": int(it.get("like_count", 0) or 0),
                "comments": int(it.get("reply_count", 0) or 0),
                "forwards": int(it.get("retweet_count", 0) or 0),
                "views": int(it.get("view_count", 0) or 0),
                "url": "%s/%s/%s" % (BASE, uid, sid),
                "recall": "user:%s" % (screen or user_id),
            })
            if len(posts) >= max_posts:
                break
        page += 1
        time.sleep(0.6)  # 轻量节奏，降低被拦概率

    posts = posts[:max_posts]
    print("[保存] %d 帖 -> %s" % (len(posts), out))
    with open(out, "w", encoding="utf-8") as f:
        json.dump(posts, f, ensure_ascii=False, indent=1)
    print("DONE")
    return posts


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="雪球用户时间线爬虫（轻量直连 / 无需登录）")
    ap.add_argument("--user-id", default="")
    ap.add_argument("--user-name", default="")
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--max", type=int, default=200)
    ap.add_argument("--cookie", default="")
    ap.add_argument("--out", default="raw.json")
    args = ap.parse_args()

    uid = args.user_id
    if not uid and args.user_name:
        print("[解析] 显示名 -> user_id: %s" % args.user_name)
        uid = resolve_user_id(args.user_name, args.cookie)
        if not uid:
            print("ERROR: 无法解析 user_id，请直接通过主页 URL 取数字 ID 传入 --user-id")
            sys.exit(1)
        print("  解析结果: %s" % uid)
    if not uid:
        print("ERROR: 必须提供 --user-id 或 --user-name")
        sys.exit(1)

    crawl(uid, days=args.days, max_posts=args.max, cookie=args.cookie, out=args.out)
