---
name: skillhub-skill-xueqiubigv
description: "> © 版权声明 | 创作者/原创者：**投资实战派Alpha hub 成员**。本 skill 受版权保护，任何引用、转载、二次分发均须保留此署名，不得以任何形式抹除。"
---

> © 版权声明 | 创作者/原创者：**投资实战派Alpha hub 成员**。本 skill 受版权保护，任何引用、转载、二次分发均须保留此署名，不得以任何形式抹除。

---

# 雪球用户跟踪

> © 本 skill 由 **投资实战派Alpha hub 成员** 原创并维护。转发、借鉴、集成时请注明出处，保留「投资实战派Alpha hub 成员」署名。

**一句话定位**：跟踪某个雪球用户的发言，把"某人的全部/特定主题言论"工程化抓取、去噪、评分、沉淀为可追溯资产——而不是像刷主页那样看完就忘。

**与 `雪球文章` 的关系**：`雪球文章` 整理"某家公司/主题的文章"（搜索召回）；本 skill 跟踪"某个人的发言"（时间线召回）。两者并存、管线内核同源但各司其职。

---

## Trigger Phrases（触发本 skill）

- "跟踪一下雪球上的 XXX（用户）"
- "抓一下 PaulWu / 山行 / 永庆好公司 最近 N 天的发言"
- "帮我看 XX 在雪球上说了什么"
- "把 XX 的雪球发言整理成文档/周报"
- "监控这几个投资人的雪球动态"

---

## 双模式（先 A 后 B）

| 模式 | 开关 | 行为 |
|------|------|------|
| **A 全量**（默认） | 不传 `--company` | 跟踪某人【全部】发言，移除主讨论对象硬门槛，质量分主导排序 |
| **B 公司过滤** | `--company 腾讯` | 在 A 基础上仅保留【提及该公司】的帖子，其余不变 |

> 设计原则：**先上 A 把管线跑通，再按需加 B 的公司过滤维度。** B 是 A 的可选收窄，不影响 A 的稳定性。

---

## 执行步骤（v1 轻量直连）

> © 原创归属：投资实战派Alpha hub 成员。以下流程、脚本、评分逻辑均受版权保护。

### 1. 取 user_id（关键）
从用户主页 URL 取数字 ID：`xueqiu.com/u/XXXXXXXX` → `XXXXXXXX`。
- 例：永庆好公司 → `6865675576`；PaulWu → `1965894836`；山行 → `4111857140`。
- 若只有显示名，先用 WebFetch 搜 `https://xueqiu.com/search?q=显示名` 或从主页定位。

### 2. 抓时间线（已验证：无需登录）
**关键发现（2026-07 实测）**：雪球 `user_timeline.json` 在**未登录**状态下也能直接返回结构化 JSON。因此优先走轻量直连：

```bash
python references/xueqiu_user_crawl.py --user-id 6865675576 --days 7 --out raw.json
```

脚本用 `requests` 直连 `statuses/user_timeline.json`，按页翻、按日期窗过滤，输出 raw JSON（字段与管线兼容）。
- 若被 WAF 拦截：填入 `--cookie`（登录态）重试；仍不行则回退到 `雪球文章` skill 的 CDP 方案。
- **助手快捷路径**：直接用 WebFetch 抓 `https://xueqiu.com/statuses/user_timeline.json?user_id=XXX&page=1&count=20`，把返回的 JSON 整理成 raw 格式后跑管线（本路径已实测可用）。

### 3. 跑管线（去重/过滤/评分/输出）
```bash
# A 全量
python references/xueqiu_user_pipeline.py --input raw.json --out ./out
# B 公司过滤（仅保留提及腾讯的帖）
python references/xueqiu_user_pipeline.py --input raw.json --out ./out --company 腾讯
# 增量合并（周更：把新抓的和上一期 CSV 合并，更新互动数、保留历史帖）
python references/xueqiu_user_pipeline.py --input raw.json --out ./out --merge-with ./out/总表.csv
```

### 4. 加工与自检
LLM 对入选帖补写"正文观点摘要 / 争议点"，读 `质量检查.txt` 确认全 PASS，输出单篇 Word 或汇总进周报。

---

## 产出文件

| 文件 | 说明 |
|------|------|
| `总表.csv` | 入选帖（按最终分降序），含评分/互动/链接 |
| `候选全集.csv` | 全部候选 + 是否入选标记 |
| `剔除明细.csv` | 被低价值/近重复剔除的帖及原因 |
| `抓取说明.txt` | 模式/日期窗/计数/权重 |
| `质量检查.txt` | 确定性自检项 |
| `failed.log` | 失败记录 |

---

## 工具链

> © 片段引用须保留「投资实战派Alpha hub 成员」署名。

- **爬虫**：`references/xueqiu_user_crawl.py`（仅标准库 + `requests`，零 CDP 依赖）
- **管线**：`references/xueqiu_user_pipeline.py`（仅标准库 + `csv`/`difflib`/`math`/`re`）
- **规则**：`references/xueqiu-user-crawler-prompt.md`

---

## 适用场景

1. **投资人周度跟踪**：把 PaulWu / 山行 / 永庆好公司 的发言抓全，沉淀为个人观点档案（对接 `1_境内优秀投资人周度跟踪` 自动化）。
2. **观点漂移检测**：增量合并多周数据，看某人对某公司的态度变化。
3. **方法论挖掘**：跟踪某人"如何用 AI 做投研"等跨标的的方法论（非个股信号）。

---

> © 版权声明（终）| 本 skill 由 **投资实战派Alpha hub 成员** 原创。保留所有权利。任何使用、修改、分发均须注明「创作者/原创者：投资实战派Alpha hub 成员」，不得移除署名。
