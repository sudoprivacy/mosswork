---
name: skillhub-skill-codearts-cpp-config
description: "鸿蒙 PC（HarmonyOS aarch64）上华为 CodeArts IDE 的 C/C++ 工程配置与排障——多文件自动 target、运行/调试分离、断点不停、cin 无法输入、二进制签名、run.sh 交互入口。当用户提到 CodeArts、鸿蒙 C++ 编译、lldb 断点不停、preLaunchTask、runInTerminal、binary-sign-tool、compile_commands.json 时使用。"
---

# 鸿蒙PC上CodeArts C++配置

全部结论均在真机实测过（demo1 / demo2 工程，2026-09-26 跑通"运行 + 调试 + 交互输入"全套）。照抄即可，不要再重新推导。

## 0. 一分钟速查：症状 → 解法

| 症状 | 根因 | 直达 |
|---|---|---|
| 点虫子调试，断点不停、程序直接跑完 | preLaunchTask 指向了"构建+运行"任务 | [坑 1](#坑-1prelaunchtask-指向了带运行的任务) |
| 运行也变成 debug（停在 main 入口） | 残留 `stopAtEntry: true` | [坑 2](#坑-2stopatentry-污染运行按钮) |
| 调试跑的不是当前文件（A 打断点、B 跑完） | launch.json 有多条配置，选中了硬编码那条 | [坑 3](#坑-3多配置并存跑错二进制) |
| 控制台 `failed to set breakpoint site ... error: 9` | 软件断点写不进 `R E` 代码段 | [坑 4](#坑-4软件断点写不进-re-代码段) |
| `cin` 没地方输入，程序秒退 | console 模式下 stdin 是空管道 | [坑 5](#坑-5cin-无法输入需要真终端) |
| 敲 `run test.cpp` 报 `not an object file` | `run` 是 gdb 构件，不是运行命令 | [坑 6](#坑-6鸿蒙-pc-上的-run-不是运行命令) |
| `cout` 输出"看不见" | 末尾没 `endl`，被 shell 提示符粘住 | [坑 7](#坑-7cout-输出看不见缺-endl) |
| 二进制 `Operation not permitted` | 未签名 | `binary-sign-tool sign -inFile X -outFile X -selfSign "1"` |

## 1. 黄金配置（直接抄，改路径即可）

### CMakeLists.txt —— 多文件自动 target，每个含 main() 的 .cpp 独立可执行

```cmake
cmake_minimum_required(VERSION 3.20)
project(demo2)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR})

file(GLOB_RECURSE SRC_LIST CONFIGURE_DEPENDS
        "${CMAKE_CURRENT_SOURCE_DIR}/*.cpp"
        "${CMAKE_CURRENT_SOURCE_DIR}/*.cc")

set(MAIN_SRC "")
set(COMMON_SRC "")
foreach(src ${SRC_LIST})
    string(FIND "${src}" "CMakeFiles" _pos)          # 排除 CMake 探测文件
    if(NOT _pos EQUAL -1)
        continue()
    endif()
    string(FIND "${src}" "${CMAKE_BINARY_DIR}" _in_build)   # 排除构建目录
    if(NOT _in_build EQUAL -1)
        continue()
    endif()
    file(RELATIVE_PATH _rel "${CMAKE_CURRENT_SOURCE_DIR}" "${src}")
    if(_rel MATCHES "^[.]|/[.]")                     # 排除 .arts/.cache 等隐藏目录
        continue()
    endif()
    file(READ "${src}" _content)
    if(_content MATCHES "int[ \t\n\r]+main[ \t\n\r]*\\(")
        list(APPEND MAIN_SRC "${src}")
    else()
        list(APPEND COMMON_SRC "${src}")             # 无 main 的作为公共源
    endif()
endforeach()

foreach(src ${MAIN_SRC})
    get_filename_component(_name "${src}" NAME_WE)
    add_executable(${_name} "${src}" ${COMMON_SRC})
    message(STATUS "[auto] target: ${_name}")
endforeach()
```

target 名 = 文件名（无扩展名），刻意与 IDE 变量 `${fileBasenameNoExtension}` 对齐。

**已踩坑**：`list(FILTER ... EXCLUDE REGEX "^${CMAKE_BINARY_DIR}/")` **实测不生效**，必须用 `string(FIND "${src}" "CMakeFiles" ...)` 子串判断，否则会误建 `CMakeCXXCompilerId` target。

### launch.json —— configurations 只留这一条

```json
{
  "name": "auto：跟随当前文件",
  "preLaunchTask": "all",
  "type": "lldb",
  "request": "launch",
  "runInTerminal": true,
  "console": "integratedTerminal",
  "target": "/abs/path/<项目>/cmake-build-debug/${fileBasenameNoExtension}",
  "cwd": "/abs/path/<项目>/cmake-build-debug",
  "setupCommands": [
    { "text": "settings set target.require-hardware-breakpoint true", "ignoreFailures": true },
    { "text": "settings show target.require-hardware-breakpoint",     "ignoreFailures": true },
    { "text": "settings set target.disable-aslr true",                 "ignoreFailures": true },
    { "text": "version", "ignoreFailures": false }
  ],
  "env": { "LD_LIBRARY_PATH": "/abs/path/<项目>/cmake-build-debug", "configurationsType": "target" },
  "internalConsoleOptions": "neverOpen"
}
```

要点：

- **路径一律写绝对路径**。IDE 自生成文件里 `${workspaceRoot}`（tasks.json）与 `${workspaceFolder}`（settings.json）混用，不确定哪个被解析；写死路径可把变量依赖收敛到只剩 `${fileBasenameNoExtension}` 一个（该变量华为官方文档确认支持）。
- **`settings show` 那条是诊断回声**，能让你在调试控制台肉眼确认 setting 是否真的生效，别删。
- **IDE 每次 reload 都会按 CMake target 自动追加配置**（`hello` / `main` / `test` …，target 硬编码）。这是删不干净的；**务必在调试下拉里手动选 `auto：跟随当前文件`**。若用户报告"调试跑错文件"，第一件事就是确认选中的是哪条。

### tasks.json —— 不动 IDE 自带的，只追加一条交互运行

```json
{
  "label": "run：当前文件（可交互输入）",
  "type": "shell",
  "command": "cmake --build \"cmake-build-debug\" --config Debug --target all && cd cmake-build-debug && ./${fileBasenameNoExtension}",
  "configurationsType": "target"
}
```

**绝不能把这条当 preLaunchTask**（会把程序先跑完，回到坑 1）。

### run.sh —— 项目根放一个，交互输入的最省事入口

```sh
#!/bin/sh
set -e
cd "$(dirname "$0")"
BUILD=cmake-build-debug
if [ -z "$1" ]; then
	echo "可用程序："
	ls -1 "$BUILD" | grep -vE '\.(cmake|ninja|txt|json|log)$' | grep -vx 'CMakeFiles'
	echo ""; echo "用法: ./run.sh <程序名>     例: ./run.sh test"; exit 1
fi
cmake --build "$BUILD" --config Debug --target "$1"

echo "----- 运行 $1（下方光标处可直接输入）-----"
cd "$BUILD"

# 不用 exec：程序退出后补一个换行，避免末尾没写 endl 时输出被 shell 提示符粘住
code=0
"./$1" || code=$?
echo ""
exit "$code"
```

`chmod +x run.sh` 后 `./run.sh test`。不带参数会列出所有可执行 target（顺带验证 CMake 扫描是否生效）。`|| code=$?` 必须写——`set -e` 下程序非零退出会直接中断脚本，跳不到后面的 echo。

## 2. 环境事实（已实测，勿再猜）

- 开发机 HarmonyOS / HongMeng Kernel / aarch64。**不是 Linux**，别给 apt/brew/MinGW 方案。
- 项目目录 `~/IDEProjects/<项目>/`，IDE 配置在 `<项目>/.arts/`（launch.json / tasks.json / settings.json / compile_commands.json）。
- 工具链软链在 `/data/service/hnp/bin/` → `ohos-sdk_<ver>/ohos/native/llvm/bin/`：`clang++`（BiSheng LLVM，target `aarch64-unknown-linux-ohos`，**非 GCC**）、`lldb` / `lldb-vscode` / `lldb-server`、`clangd`、`cmake`、`ninja`、`llvm-readelf`、`binary-sign-tool`。
- **坑**：WorkBuddy 沙箱 PATH 探不到这些二进制，`which clang++` 为空属正常，**不代表没装**。用 `ls /data/service/hnp/bin/` 判断，或让用户在 CodeArts 自带终端验证。
- 新建工程（`文件 > 新建 > 工程` → C/C++ → Executable → Ninja）IDE 自动配好 CMake + Ninja，**零配置**。

## 3. 运行 / 调试分离：三条铁律

**关键事实：三角（运行）与虫子（调试）共用同一条 launch.json 配置**，差别只在是否挂调试器。
证据：给 demo1 加 `stopAtEntry`（launch.json 字段）后用户反馈"运行也变成只能 debug"——若运行走 tasks.json，不可能被 launch.json 字段影响。

1. `preLaunchTask` 只能指向**纯构建**任务，直接用 IDE 自带的 `all`。
2. `stopAtEntry: true` **只能作一次性诊断**，验证完必须删。
3. **不要新建或改 tasks.json 的 label**——会改变 IDE 顶部运行目标列表，挤掉原运行入口（已踩坑）。

## 4. 七个坑（按踩坑顺序）

### 坑 1：preLaunchTask 指向了带运行的任务

IDE 自动生成的 tasks.json 把「构建 + `./<bin>` 运行」塞在同一个 label 里。调试启动时程序先被跑完，lldb 面对已结束的进程，会话立即中止。

验证：`grep preLaunchTask .arts/launch.json`，再对照 tasks.json 该 label 的 command 是否含 `./`。
修复：改指 `all`（本就是纯构建，`cmake --build ... --target all`，**无需新建任务**）。

### 坑 2：stopAtEntry 污染运行按钮

它会让"运行"也停在 main 入口。用户主观感受是"运行功能坏了"。诊断完立刻删。

### 坑 3：多配置并存，跑错二进制

现象："运行有输出"但"调试不停、直接跑完"。判据：launch.json 存在多条配置，被选中那条的 target 是硬编码绝对路径（IDE 自动生成的都这样）。
修复：删到只留跟随当前文件那一条，并在下拉里手动选它。注意 IDE 会重新追加，需提醒用户每次确认选中项。

### 坑 4：软件断点写不进 `R E` 代码段

控制台出现：`warning: failed to set breakpoint site at 0x... for breakpoint 1.1: error: 9 sending the breakpoint request`

- **判读**：有具体地址、且连 `-1.1`/`-2.1` 这类 lldb 内部断点也失败 → target 正确、代码已加载 → 失败在**写内存**这一步。软件断点要把 BRK 写进 `R E` 只读代码段，鸿蒙不允许。
- **关键反证**：`stopAtEntry` 能让进程在入口停住（不依赖写内存），所以"曾经能停在 main"**不代表**软件断点能用。
- 已排除：无 yama ptrace 限制（`/proc/sys/kernel/yama/ptrace_scope` 文件不存在）；`llvm-readelf -l` 显示不同项目段布局完全同构 → **不是单项目特殊，是平台统一行为**。
- **首选修复**：硬件断点（ARM64 的 `NativeRegisterContextDBReg` 支持；x86 不支持）。
  **setting 名必须是 `target.require-hardware-breakpoint`**——写成 `target.breakpoints-use-hardware`（VS Code/旧版印象）在 lldb 21 里**根本不存在**，会被 `ignoreFailures: true` 静默吞掉，表现为"改了配置没效果"。已踩坑一次。
  自查：`lldb -b -o "settings list target" | grep -iE "hardware|aslr"`。凡是往 setupCommands 塞 setting，都要先验证名字存在，并补一条 `settings show` 回声。
- **备选**：换 gdb 后端（环境自带 `gdb` / `gdbserver`），`"type": "cppdbg"` + `"MIMode": "gdb"` + `"miDebuggerPath": "/data/service/hnp/bin/gdb"`。CodeArts 是否认该 type **未验证**。
- **已实测不可行，别再试**：`-Wl,-N`（omagic）确实能把代码段改成 `RWE`，但同时关闭页对齐（0x1000 → 0x40、LOAD 合并），加载器拒绝执行 `exec: Invalid argument`，体积 96KB → 6MB。

### 坑 5：cin 无法输入，需要真终端

默认 console 模式：stdout/stderr 进「调试控制台」（只读面板），**stdin 是空管道** → `cin` 立刻 EOF，程序秒退。

launch.json 加 `"runInTerminal": true`（`"console": "integratedTerminal"` 作双保险，无害）。原理：lldb-vscode 通过 DAP 的 RunInTerminal 反向请求把进程托管到集成终端。

**字段有效性已用 DAP 协议实测**（别靠猜或搜文档）：spawn `lldb-vscode`，按 Content-Length 帧发 `initialize` + `launch`，看是否回发 `runInTerminal` 反向请求。

| 字段 | 是否触发终端 |
|---|---|
| `runInTerminal: true` | ✅ 会（args 含 `--comm-file`、`--launch-target`） |
| `console: integratedTerminal / externalTerminal / internalConsole / integrated` | ❌ |
| `terminal: integrated` | ❌ |
| 不写（默认） | ❌ |

即 `console` / `terminal` 是 VS Code 侧字段，lldb-vscode 不认。官方《CodeArts IDE 用户指南》里那 6 处 `"console": "integratedTerminal"` 全是 **Python/Django 配置**（同段有 `"jinja": true`、`"python": ...`），**别套用到 C++**。

**已知未解决**：适配器支持，但实测 CodeArts 未真正把程序放进终端（用户在任务终端打字、终端随即关闭，程序仍在 console 模式跑完）→ IDE 未处理该反向请求，lldb **静默回退**为普通 launch（不报错，极易误判）。**此时走保底**：tasks.json 那条交互运行任务，或 `run.sh`，或直接开集成终端（`Shift+Esc` / `Alt+F12`）手动跑。

验证程序是否真的在等输入（离线可测）：`./<bin> < /dev/null` 秒退 = 确实在等 stdin；`printf '2 10\n' | ./<bin>` 出正确结果 = 逻辑没问题，纯属输入通道缺失。

### 坑 6：鸿蒙 PC 上的 `run` 不是运行命令

`/data/service/hnp/bin/run` 是 **gdb 16.3 的构件**（软链 → `../gdb.org/gdb_16.3/bin/run`），只能加载 ELF。喂源文件报 `run: "test.cpp" is not an object file: file format not recognized`。
排查"命令名不对"这类问题：`command -v run` + `ls -la $(command -v run)` 看软链指向，比猜快。

### 坑 7：cout 输出"看不见"，缺 endl

程序其实打印了，但没换行 → shell 提示符紧跟其后（形如 `4$ `），被当成没输出。
判据：`printf '输入\n' | ./bin; echo "|"` —— 竖线若紧贴结果说明缺换行。
解法：源码补 `endl`；run.sh 里再补一个换行兜底。

## 5. 其他常见问题

| 现象 | 原因 | 解法 |
|---|---|---|
| `Operation not permitted` | 二进制/.so 未签名 | `binary-sign-tool sign -inFile X -outFile X -selfSign "1"` |
| 对已签名 .so 再签名报 `.codesign section already exists` | 重复签名 | POST_BUILD 前加 `copy_if_different` |
| Ninja 增量构建跳过链接 → 签名没执行 | 链接未触发 POST_BUILD | tasks.json 命令前加 `rm -f <bin>` 强制重建 |
| IDE 里 `#include` 爆红但能编译 | clangd 的 compile_commands.json 缺 `-I` | 在 `.arts/compile_commands.json` 的 command 里补 `-I"<项目>/third_party/include"` |
| 链接报 `undefined reference to std::` | musl libc | 加 `-lc++` |
| 运行时找不到 .so | 动态库搜索路径 | `BUILD_RPATH $ORIGIN` + `LD_LIBRARY_PATH=.` |
| 三方库四件套 | 头文件+链接+拷贝+签名 | 见下方 CMake 片段 |

三方库标准写法：

```cmake
set(THIRD_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/third_party")
target_include_directories(<tgt> PRIVATE ${THIRD_ROOT}/include)
target_link_libraries(<tgt> PRIVATE ${THIRD_ROOT}/lib/libxxx.so)
add_custom_command(TARGET <tgt> POST_BUILD
  COMMAND ${CMAKE_COMMAND} -E copy_if_different ${THIRD_ROOT}/lib/libxxx.so $<TARGET_FILE_DIR:<tgt>>
  COMMAND binary-sign-tool sign -inFile $<TARGET_FILE_DIR:<tgt>>/libxxx.so
          -outFile $<TARGET_FILE_DIR:<tgt>>/libxxx.so -selfSign "1")
set_target_properties(<tgt> PROPERTIES BUILD_RPATH "$ORIGIN")
```

## 6. 离线验证工具箱（不依赖 IDE）

- CMake 配置是否正确：`cmake -S <项目> -B <临时目录> -G Ninja -DCMAKE_BUILD_TYPE=Debug`，再 `cmake --build <临时目录> --target all`。生效时 Ninja 打印 `Re-checking globbed directories`。
- 二进制是否含 DWARF / 已签名：用 python `struct` 解析 ELF section header string table，查 `.debug_info` / `.debug_line` / `.codesign`。
- DWARF 路径映射是否正确：`lldb -b -o "breakpoint set --file hello.cpp --line 8" -o "quit" <bin>`，若输出 `Breakpoint 1: where = hello`main + 48 at hello.cpp:8:14` 即路径/符号/行号全对 → 断点不停只可能是跑错二进制或没挂上调试器。
- 沙箱限制（别误判为用户环境问题）：
  - `lldb run` 报 `error: 'A' packet returned an error: 8`、gdb 报 `ptrace: Permission denied` → 沙箱限制，非平台问题。但沙箱**能直接执行**已签名二进制，可用它验证程序行为。
  - `/tmp` 不可写，临时目录须建在项目内；`rm -rf` 被 shim 拦截（`bad interpreter`），用 python `shutil.rmtree` 清理。
  - `/data/app/bin/ninja` 沙箱调不动 → run.sh 的构建步骤在本地必然失败，属已知限制。
- 官方《CodeArts IDE 用户指南》PDF（`~/.codearts/`）本机无任何 PDF 库可解析。可用 `zlib` 解压 FlateDecode 流后从 `/ActualText(...)` 取 Unicode 文本（需自己解析 PDF 字符串转义，UTF-16BE 带 BOM）→ 可还原约 12.6 万字正文用于检索。

## 7. 收尾检查

修改 `.arts/*.json` 后**必须 `json.load` 校验一次**再让用户重启调试。
