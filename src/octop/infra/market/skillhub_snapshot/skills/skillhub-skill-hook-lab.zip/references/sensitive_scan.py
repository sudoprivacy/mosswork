#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
前3秒钩子实验室 · 违禁词机检  v1.3.0
================================================
用途：对本 Skill 产出的钩子、开方单、口播开头做「防限流」机检。
开头是平台审核的第一站，HARD 命中必须改完才能交付。

一、三种用法
  echo "你的钩子" | python3 sensitive_scan.py
  python3 sensitive_scan.py 成稿.txt
  python3 sensitive_scan.py ./成稿目录

二、常用参数
  --hard-only        只看硬禁词（交付前卡点用这个）
  --json             输出 JSON（给程序/AI 解析）
  --fix              打印一版「替换建议稿」（人工确认后再用）
  --list             列出词表规模和抽样
  --words 路径       指定自定义词表（默认自动找同目录 sensitive-words.md）
  --no-evade         关闭「插入空格/符号」的规避写法检测
  -h / --help        帮助
  -v / --version     版本

三、退出码（脚本靠这个判断能不能交付）
  0 = 干净，可交付
  1 = 存在 HARD 违禁词，必须改
  2 = 用法错误 / 文件读不到（不是内容问题，别当成过检）

四、词表从哪来
  优先读同目录（或上级 references/）的 sensitive-words.md 里 `词||HARD||替换` 区块；
  读不到就用脚本内置的兜底词表（仍可正常工作，但少一批钩子领域专词）。
  词表放错位置不会报错，只会提示「已回退内置词表」——看到这句就说明你该挪文件了。
"""

import sys
import os
import re
import json
import time
import difflib

VERSION = "1.3.0"

# ============ 兜底词表（外部词表读不到时使用） ============
_FALLBACK_HARD = [
    ("必火", "改「要素更齐」表述"), ("必上热门", "改「要素更齐」表述"),
    ("稳上热门", "改「要素更齐」表述"), ("保完播", "改「结构更利于完播」表述"),
    ("完播率翻倍", "不承诺数据效果"), ("点赞过万", "不承诺数据效果"),
    ("涨粉过万", "不承诺数据效果"), ("关注过万", "不承诺数据效果"),
    ("必爆", "改「要素更齐」表述"), ("百分百", "改「有依据」表述"),
    ("100%", "改「有依据」表述"),
    ("史上最", "改可核实描述"), ("全网最低", "改可核实描述"), ("全网最", "改可核实描述"),
    ("宇宙第一", "改可核实描述"), ("绝对有效", "改「亲测有效（有依据）」"),
    ("销量第一", "有数据依据才可说"), ("全网第一", "有数据依据才可说"),
    ("第一品牌", "有数据依据才可说"),
    ("稳赚", "改「长期坚持才有概率优势」"), ("稳赚不赔", "改「任何投入都有风险」"),
    ("保本", "删除，或仅作观念举例"), ("无风险", "改「风险可控（有依据）」"),
    ("guaranteed", "删除"), ("一夜暴富", "改「长期积累、慢慢变好」"),
    ("快速致富", "改「长期积累、慢慢变好」"), ("躺赚", "改「可控的现金流习惯」"),
    ("躺赢", "改「踏实做事」"), ("轻松月入", "改「提升收入能力」"),
    ("月入过万", "真实数据+因人而异"), ("闭眼买", "改「适合多数人」"),
    ("闭眼入", "改「适合多数人」"), ("荐股", "只讲观念不荐标的"),
    ("带单", "删除"), ("短线稳", "删除"), ("收益保证", "删除"),
    ("包治百病", "删除"), ("药到病除", "删除"), ("根治", "改「改善、缓解」"),
    ("治愈率", "删除"), ("疗效第一", "删除"), ("神药", "删除"),
    ("不转不是", "删除"), ("转发到3个群", "删除"), ("转发到三个群", "删除"),
    ("分享到3个群", "删除"), ("不点赞别走", "改「觉得有用可以点个赞」"),
]
_FALLBACK_SOFT = [
    ("最好", "改「更优」"), ("最强", "改「较为出色」"), ("最快", "改「更快（有对比依据）」"),
    ("一定", "改「通常、有望」"), ("肯定", "改「通常」"), ("保证", "改「争取/尽量」"),
    ("彻底", "改「基本/大幅」"), ("完美", "改「完整」"), ("吊打", "改「明显优于」"),
    ("碾压", "改「明显领先」"), ("秒杀", "改「优于」"), ("无敌", "改「很强」"),
    ("封神", "改「顶级水准（有依据）」"), ("天花板", "改「第一梯队」"),
    ("yyds", "改「很强」"), ("永久", "改「长期」"), ("永远", "改「长期」"),
]

# 扫描目录时自动跳过的教材文件（它们本身必然含违禁词）
SELF_SKIP = {"sensitive-words.md", "sensitive_scan.py", "full-demo.md", "faq.md"}

# 规避写法检测：这些符号会被插入词中间来绕过机审
_SQUEEZE_PAT = re.compile(r"[\s\*\.\-_·|/\\、,，。~～`'\"“”‘’]+")


# ============ 词表 ============
def find_words_file(explicit=None):
    """按优先级找词表；找不到返回 (None, 提示语)。"""
    if explicit:
        if os.path.isfile(explicit):
            return explicit, ""
        return None, "你指定的词表不存在：%s" % explicit
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(here, "sensitive-words.md"),
        os.path.join(here, "references", "sensitive-words.md"),
        os.path.join(os.path.dirname(here), "references", "sensitive-words.md"),
        os.path.join(os.getcwd(), "references", "sensitive-words.md"),
        os.path.join(os.getcwd(), "sensitive-words.md"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c, ""
    return None, "没找到敏感词表 sensitive-words.md"


def parse_words(path):
    """解析 `词||HARD||替换` 行。返回 (hard, soft)；格式不对抛 ValueError。"""
    text = read_text(path)
    hard, soft = [], []
    for ln in text.splitlines():
        s = ln.strip()
        if not s or s.startswith("#") or s.startswith(">"):
            continue
        if "||" not in s:
            continue
        parts = [p.strip() for p in s.split("||")]
        if len(parts) < 2:
            continue
        word, level = parts[0], parts[1].upper()
        repl = parts[2] if len(parts) > 2 else ""
        if not word or level not in ("HARD", "SOFT"):
            continue
        (hard if level == "HARD" else soft).append([word, repl])
    if not hard and not soft:
        raise ValueError("词表里一条 `词||HARD||替换` 都没解析出来")
    return hard, soft


def load_dict(explicit=None):
    """返回 (hard, soft, info)。info 里有来源、是否回退、告警。"""
    path, msg = find_words_file(explicit)
    if path:
        for attempt in range(2):
            try:
                hard, soft = parse_words(path)
                return hard, soft, {"source": path, "fallback": False, "warn": ""}
            except Exception as e:
                if attempt == 0:
                    time.sleep(0.15)
                    continue
                return ([list(x) for x in _FALLBACK_HARD],
                        [list(x) for x in _FALLBACK_SOFT],
                        {"source": "内置兜底词表", "fallback": True,
                         "warn": "%s 解析失败（%s），已回退内置词表。检查文件是不是被改乱了格式。" % (path, e)})
    return ([list(x) for x in _FALLBACK_HARD],
            [list(x) for x in _FALLBACK_SOFT],
            {"source": "内置兜底词表", "fallback": True,
             "warn": "%s，已用内置词表（少一批钩子领域专词）。"
                     "把 sensitive-words.md 放到脚本同目录，或用 --words 指定路径。" % msg})


def dedup_sort(hard, soft):
    """去重（同词取 HARD），长词优先，避免短词抢先匹配。"""
    seen = {}
    for w, r in hard:
        seen[w] = ("HARD", r)
    for w, r in soft:
        if w not in seen:
            seen[w] = ("SOFT", r)
    h = [[w, v[1]] for w, v in seen.items() if v[0] == "HARD"]
    s = [[w, v[1]] for w, v in seen.items() if v[0] == "SOFT"]
    h.sort(key=lambda x: len(x[0]), reverse=True)
    s.sort(key=lambda x: len(x[0]), reverse=True)
    return h, s


# ============ 读文件（多编码 + 重试） ============
def read_text(path, attempts=2):
    last = None
    for i in range(attempts):
        try:
            raw = open(path, "rb").read()
        except PermissionError:
            raise PermissionError("没有读取权限：%s（试试 chmod +r）" % path)
        except FileNotFoundError:
            raise FileNotFoundError(path)
        except OSError as e:
            last = e
            time.sleep(0.15)
            continue
        for enc in ("utf-8-sig", "utf-8", "gb18030", "big5", "latin-1"):
            try:
                return raw.decode(enc)
            except UnicodeDecodeError:
                continue
        last = ValueError("四种编码都解不开，文件可能不是文本")
    raise last if last else OSError("未知读取错误")


# ============ 扫描 ============
def _line_of(text, idx):
    return text.count("\n", 0, idx) + 1


def _context(text, idx, wlen, pad=14):
    s = max(0, idx - pad)
    e = min(len(text), idx + wlen + pad)
    frag = text[s:e].replace("\n", " ").replace("\r", " ")
    return ("…" if s > 0 else "") + frag + ("…" if e < len(text) else "")


def scan_text(text, hard, soft, evade=True, only_level=None):
    """返回命中列表。每条含 word / level / repl / count / lines / ctx / evade。"""
    hits = []
    lowered = text.lower()
    squeezed = _SQUEEZE_PAT.sub("", text)
    squeezed_low = squeezed.lower()

    for group, level in ((hard, "HARD"), (soft, "SOFT")):
        if only_level and level != only_level:
            continue
        for word, repl in group:
            has_ascii = bool(re.search(r"[a-zA-Z]", word))
            needle = word.lower() if has_ascii else word
            hay = lowered if has_ascii else text
            positions = []
            start = 0
            while True:
                i = hay.find(needle, start)
                if i < 0:
                    break
                positions.append(i)
                start = i + len(needle)
                if len(positions) >= 50:
                    break
            if positions:
                hits.append({
                    "word": word, "level": level, "repl": repl,
                    "count": len(positions), "pos": positions[0],
                    "lines": sorted({_line_of(text, p) for p in positions})[:5],
                    "ctx": _context(text, positions[0], len(needle)),
                    "evade": False,
                })
                continue
            # 规避写法：把空格/符号去掉后再找一次
            if evade and level == "HARD":
                s_needle = _SQUEEZE_PAT.sub("", word).lower() if has_ascii else _SQUEEZE_PAT.sub("", word)
                if s_needle and len(s_needle) >= 2:
                    j = squeezed_low.find(s_needle.lower())
                    if j < 0 and not has_ascii:
                        j = squeezed.find(s_needle)
                    if j >= 0:
                        hits.append({
                            "word": word, "level": "HARD", "repl": repl,
                            "count": 1, "pos": 10 ** 9 + j, "lines": [],
                            "ctx": _context(squeezed, j, len(s_needle)),
                            "evade": True,
                        })
    hits = _drop_covered(hits)
    hits.sort(key=lambda h: (h["level"] != "HARD", h["pos"]))
    return hits


def _drop_covered(hits):
    """长词已命中时，去掉被它包住的短词（"稳赚不赔"命中就不再重复报"稳赚"）。"""
    out = []
    for h in hits:
        covered = 0
        for o in hits:
            if o is not h and o["level"] == h["level"] and h["word"] in o["word"]:
                covered += o["count"]
        left = h["count"] - covered
        if left > 0:
            if left != h["count"]:
                h = dict(h)
                h["count"] = left
            out.append(h)
    return out


# ============ 输出 ============
def _bar(title, info):
    return "%s  v%s\n词表：%s" % (title, VERSION, info["source"])


def render_text(hits, label, info, charset=None):
    hard_hits = [h for h in hits if h["level"] == "HARD"]
    soft_hits = [h for h in hits if h["level"] == "SOFT"]
    out = []
    head = "\n【%s】" % label
    if charset:
        head += " %d 字" % charset
    out.append(head)
    if not hits:
        out.append("  ✅ 没扫到违禁词，可以交付")
        return "\n".join(out)
    out.append("  ❌ HARD %d 项 / ⚠️ SOFT %d 项" % (len(hard_hits), len(soft_hits)))
    for h in hits:
        tag = "❌HARD" if h["level"] == "HARD" else "⚠️SOFT"
        evade = "（疑似插入符号/空格规避）" if h.get("evade") else ""
        loc = "行 %s" % ",".join(map(str, h["lines"])) if h["lines"] else "位置近似"
        out.append("    %s 「%s」×%d  %s%s" % (tag, h["word"], h["count"], loc, evade))
        out.append("        原文：%s" % h["ctx"])
        if h["repl"]:
            out.append("        改法：%s" % h["repl"])
    return "\n".join(out)


def build_fix(text, hits, hard_only=True):
    """生成一版替换建议稿。删除类建议直接去掉词，避免留下半句话。"""
    out = text
    for h in sorted(hits, key=lambda x: -len(x["word"])):
        if hard_only and h["level"] != "HARD":
            continue
        w, repl = h["word"], h["repl"]
        if not repl:
            continue
        if h.get("evade"):
            pat = r"[\s\*\.\-_·|/、,，]*".join(re.escape(ch) for ch in w)
            out = re.sub(pat, "" if repl.startswith("删除") else repl, out)
        elif repl.startswith("删除"):
            out = out.replace(w, "")
        else:
            out = out.replace(w, repl)
    return out


def main(argv):
    args = argv[1:]
    hard_only = False
    as_json = False
    do_fix = False
    do_list = False
    evade = True
    words_path = None
    paths = []

    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(__doc__)
            return 0
        elif a in ("-v", "--version"):
            print("sensitive_scan.py %s" % VERSION)
            return 0
        elif a == "--hard-only":
            hard_only = True
        elif a == "--json":
            as_json = True
        elif a == "--fix":
            do_fix = True
        elif a == "--list":
            do_list = True
        elif a == "--no-evade":
            evade = False
        elif a == "--words":
            i += 1
            if i >= len(args):
                print("❌ --words 后面要跟词表路径，例如：--words ./sensitive-words.md")
                return 2
            words_path = args[i]
        elif a.startswith("-") and a != "-":
            print("❌ 不认识的参数：%s" % a)
            print("   用 -h 看全部用法；常用的只有 --hard-only / --json / --fix / --list / --words")
            return 2
        else:
            paths.append(a)
        i += 1

    hard, soft, info = load_dict(words_path)
    hard, soft = dedup_sort(hard, soft)

    if info["warn"]:
        print("⚠️ %s\n" % info["warn"], file=sys.stderr)

    if do_list:
        print(_bar("前3秒钩子实验室 · 机检", info))
        print("HARD %d 条 / SOFT %d 条，合计 %d 条" % (len(hard), len(soft), len(hard) + len(soft)))
        print("HARD 抽样：" + "、".join(w for w, _ in hard[:20]))
        print("SOFT 抽样：" + "、".join(w for w, _ in soft[:10]))
        print("\n想看单条替换建议：直接跑一段文案，或打开 sensitive-words.md 第一节。")
        return 0

    # 统一成 [(label, text)] 待扫队列
    jobs = []
    if paths:
        for p in paths:
            if p == "-":
                jobs.append(("stdin", sys.stdin.read()))
                continue
            if not os.path.exists(p):
                print("❌ 找不到文件或目录：%s" % p)
                folder = os.path.dirname(os.path.abspath(p)) or "."
                if os.path.isdir(folder):
                    near = difflib.get_close_matches(os.path.basename(p), os.listdir(folder), n=2, cutoff=0.65)
                    if near:
                        print("   你是不是想扫：%s" % "、".join(near))
                print("   提示：路径含空格要加引号；也可以直接把文案管道喂进来：")
                print("   echo \"你的钩子\" | python3 sensitive_scan.py")
                return 2
            if os.path.isdir(p):
                for root, _, fs in os.walk(p):
                    for fn in sorted(fs):
                        if fn in SELF_SKIP or not fn.endswith((".md", ".txt", ".json", ".yaml", ".yml")):
                            continue
                        fp = os.path.join(root, fn)
                        try:
                            jobs.append((fp, read_text(fp)))
                        except Exception as e:
                            print("⚠️ 跳过 %s：%s" % (fp, e), file=sys.stderr)
                continue
            try:
                jobs.append((p, read_text(p)))
            except Exception as e:
                print("❌ 读不了 %s：%s" % (p, e))
                print("   检查文件是否被占用、编码是否正常；实在不行另存为 UTF-8 再试。")
                return 2
    else:
        # 无路径：优先读管道
        piped = ""
        if not sys.stdin.isatty():
            try:
                piped = sys.stdin.read()
            except Exception:
                piped = ""
        if piped.strip():
            jobs.append(("stdin", piped))
        else:
            print("❌ 没有收到内容。三种用法：")
            print("   1) echo \"你的钩子\" | python3 sensitive_scan.py")
            print("   2) python3 sensitive_scan.py 成稿.txt")
            print("   3) python3 sensitive_scan.py ./成稿目录")
            print("   想看词表规模：python3 sensitive_scan.py --list")
            return 2

    all_hits = []
    blocks = []
    for label, text in jobs:
        if not text.strip():
            blocks.append("\n【%s】\n  ⚠️ 文件是空的，没东西可扫（是不是保存失败了？）" % label)
            continue
        hits = scan_text(text, hard, soft, evade=evade)
        if hard_only:
            hits = [h for h in hits if h["level"] == "HARD"]
        all_hits.append((label, text, hits))
        blocks.append(render_text(hits, label, info, charset=len(text)))

    hard_total = sum(1 for _, _, hs in all_hits for h in hs if h["level"] == "HARD")
    soft_total = sum(1 for _, _, hs in all_hits for h in hs if h["level"] == "SOFT")

    if as_json:
        payload = {
            "version": VERSION,
            "words_source": info["source"],
            "words_fallback": info["fallback"],
            "words_count": {"hard": len(hard), "soft": len(soft)},
            "hard_total": hard_total,
            "soft_total": soft_total,
            "pass": hard_total == 0,
            "results": [
                {"target": label,
                 "hits": [{k: v for k, v in h.items() if k != "pos"} for h in hs]}
                for label, _, hs in all_hits
            ],
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(_bar("前3秒钩子实验室 · 机检", info))
        print("\n".join(blocks))
        print("\n--- 汇总 ---")
        print("HARD %d 项 / SOFT %d 项" % (hard_total, soft_total))
        if hard_total:
            print("❌ 不可交付：上面的 HARD 词必须先改。改完再扫一次，0 才发。")
            print("   要一版替换草稿：加 --fix（机器改的，发之前自己读一遍）。")
        else:
            print("✅ 可交付：HARD 违禁词 0 命中。")
            if soft_total:
                print("   SOFT 词看语境，能避就避；避不开就补一句风险提示。")

    if do_fix and hard_total:
        for label, text, hits in all_hits:
            fixed = build_fix(text, hits)
            print("\n=== 替换建议稿（%s）===" % label)
            print(fixed)
            print("=== 以上为机器替换版，语义需人工确认 ===")

    return 1 if hard_total else 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        print("\n已取消。")
        sys.exit(2)
    except Exception as e:  # 兜底，不让用户看到一屏英文 traceback
        print("❌ 扫描器出错：%s: %s" % (type(e).__name__, e))
        print("   这不是钩子文案的问题。把这段报错发我，或先用 --list 看词表能不能读。")
        sys.exit(2)
