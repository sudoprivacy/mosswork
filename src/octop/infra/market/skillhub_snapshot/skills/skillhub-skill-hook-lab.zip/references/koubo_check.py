#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
koubo_check.py — 口播开头自检打分器（口播前3秒｜留人话术 v2.0.0 配套工具）
用法:
  python3 koubo_check.py "你的开头原话"
  python3 koubo_check.py -f openings.txt     # 一行一条, 批量体检
  cat openings.txt | python3 koubo_check.py  # 管道输入
  python3 koubo_check.py -i                  # 交互模式, 逐条输入, 输入 q 退出
评分: 0-100。≥80 可拍; 60-79 改后可拍; <60 危重建议重写。
"""
import sys, re, argparse

# ── 词库 ──────────────────────────────────────────────
DEAD_OPENERS = ["大家好", "今天", "我是", "给大家", "分享", "聊一聊", "聊一下",
                "咱们今天", "最近很多", "有很多朋友", "今天这期"]
PROMISE_WORDS = ["接下来", "告诉你", "教你", "给你", "看完", "这30秒", "这 30 秒",
                 "一分钟", "三步", "几招", "一个动作", "直接上", "先说结论"]
HOOK_PATTERNS = {
    "反常识": ["90%", "九成", "都做错", "理解反", "别再", "其实不是", "根本不是", "真相", "反过来"],
    "痛点":   ["为什么你", "明明", "你是不是", "你是不是也", "没人看", "没效果", "焦虑", "卡在", "停在", "月光", "冷场"],
    "悬念":   ["结果", "没想到", "翻车", "结局", "偷偷", "试了", "直到", "差点", "反转", "意外"],
    "利益":   ["一个动作", "三个", "几个", "省", "快", "模板", "清单", "记住", "学会", "涨", "提升"],
    "身份":   ["上班的", "做", "的家长", "的老板", "刚入行", "想转行", "带娃", "自由职业", "带团队", "的注意", "听我说", "一族"],
    "冲突":   ["别再听", "别信", "不建议", "我偏", "我劝你", "偏说", "别跟风", " expert", "别再点", "别再买", "别再学", "被带偏", "我反对"],
}
REDLINE_WORDS = ["必看", "震惊", "惊呆", "看完删除", "速看", "删前", "绝密",
                 "稳赚", "包治", "根治", "百分百", "第一", "最强", "全网", "史上最"]
WEAK_TAIL = ["谢谢", "谢谢大家", "喜欢的话", "点个赞"]  # 开头不该出现的东西

SEC = 4.0  # 语速: 字/秒

def scan(line: str):
    line = line.strip()
    if not line:
        return None
    report, score = [], 100

    # 1. 废开场
    dead = [w for w in DEAD_OPENERS if w in line[:20]]
    if dead:
        cut = min(30, 10 * len(dead))
        score -= cut
        report.append(f"✗ 废开场: 命中 {'、'.join(dead)}（-{cut}）—— 第一句就自我介绍/客套, 用户没理由留")
    else:
        report.append("✓ 无废开场词")

    # 2. 钩子类型
    hooks = []
    for k, words in HOOK_PATTERNS.items():
        if any(w in line for w in words):
            hooks.append(k)
    if hooks:
        report.append(f"✓ 钩子类型: {'/'.join(hooks)}")
    else:
        score -= 25
        report.append("✗ 钩子类型: 未识别到任何类型（-25）—— 没有钩子=没有继续看的理由")

    # 3. 时长
    est = len(line) / SEC
    if est > 5:
        score -= 12
        report.append(f"✗ 时长: 约 {est:.1f} 秒（-12）—— 超过 5 秒才进正题, 大半人已划走; 砍到 3 秒内")
    elif est > 3:
        score -= 6
        report.append(f"△ 时长: 约 {est:.1f} 秒（-6）—— 卡线, 建议压到 3 秒内")
    else:
        report.append(f"✓ 时长: 约 {est:.1f} 秒, 达标")

    # 4. 承诺信号
    if any(w in line for w in PROMISE_WORDS):
        report.append("✓ 承诺信号: 检出, 用户知道继续看能得到什么")
    else:
        score -= 15
        report.append("✗ 承诺信号: 未检出（-15）—— 钩子后接『接下来X秒你拿到XX』")

    # 5. 红线初筛
    red = [w for w in REDLINE_WORDS if w in line]
    if red:
        score -= 20
        report.append(f"✗ 红线初筛: {'、'.join(red)}（-20）—— 惊悚/绝对化/虚假承诺风险, 平台可能限流")
    else:
        report.append("✓ 红线初筛: 未发现")

    # 6. 结尾词污染（把谢谢等放在开头是常见错误）
    tail = [w for w in WEAK_TAIL if w in line]
    if tail:
        score -= 10
        report.append(f"✗ 开头出现收尾词: {'、'.join(tail)}（-10）—— 别在开头说『谢谢/喜欢的话点赞』")

    score = max(0, min(100, score))
    if score >= 80: verdict = "可拍 ✓"
    elif score >= 60: verdict = "改后可拍 △"
    else: verdict = "危重, 建议重写 ✗"
    return line, score, verdict, report

def print_report(r):
    line, score, verdict, report = r
    print("=" * 46)
    print(f"原文: {line}")
    print(f"总评: {score}/100 —— {verdict}")
    for x in report:
        print(f"  {x}")
    if score < 80:
        print("  改写路径: 第六章挑钩子类型 → 第五章套三件套公式 → 复测到 ≥80")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("text", nargs="*", help="开头原话")
    ap.add_argument("-f", "--file", help="批量文件, 一行一条")
    ap.add_argument("-i", "--interactive", action="store_true", help="交互模式")
    args = ap.parse_args()

    lines = []
    if args.interactive:
        print("交互模式: 逐条粘贴开头, 回车打分; 输入 q 退出")
        while True:
            try:
                s = input("> ").strip()
            except EOFError:
                break
            if s.lower() == "q":
                break
            r = scan(s)
            if r: print_report(r)
        return
    if args.file:
        lines = [l.rstrip("\n") for l in open(args.file, encoding="utf-8")]
    elif args.text:
        lines = [" ".join(args.text)]
    else:
        lines = [l.rstrip("\n") for l in sys.stdin if l.strip()]

    ok = 0
    for l in lines:
        r = scan(l)
        if r:
            print_report(r)
            if r[1] >= 80: ok += 1
    if len(lines) > 1:
        print("=" * 46)
        print(f"批量体检: {len(lines)} 条中 {ok} 条过线(≥80)")

if __name__ == "__main__":
    main()
