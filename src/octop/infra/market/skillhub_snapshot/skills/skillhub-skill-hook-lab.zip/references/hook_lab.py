#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""前3秒钩子实验室 · 生成器与排序引擎（hook_lab）

干机器能干的活：按钩子七式批量生成 20+ 个开头钩子 → 每条附演绎提示与留人理由
→ 按前3秒三问（停下来的理由 / 跟我有什么关系 / 值不值得等下一秒）计分排序 → 出 Top3 与全清单。

用法：
  python3 hook_lab.py --topic "选题" --core "一句话结论" \
      [--audience "目标身份"] [--pain "痛点动作"] [--number "真实数字"] \
      [--original "原开头"] [--style "点名痛点"] [--out 开方单.md]
  python3 hook_lab.py --list        # 看七式都有哪些、每式模板长什么样
  python3 hook_lab.py --demo        # 内置样例完整跑一遍

参数：
  --topic    主题（这条视频讲什么；缺省时用 --core 顶上）
  --core     一句话结论（必填——钩子都是结论的变装）
  --audience 目标身份（缺省「想搞钱的普通人」）
  --pain     痛点动作（缺省「瞎忙」）
  --number   真实数字（缺省「三个月」；数字必须真，编数字不如不填）
  --original 原开头（可选，有则先诊断再开方）
  --style    只出某一式（如「点名痛点」；写错会列出来让你挑）
  --out      开方单保存路径（缺省「钩子开方单.md」）

铁律：模板出骨架、人工润色定稿；输出不含任何完播率/爆款效果承诺。
"""
import argparse
import os
import re
import sys

SPEED_MIN, SPEED_MAX = 5, 7  # 口播语速：字/秒

# 每式的演绎提示与留人理由（对齐 hooks-seven.md）
STYLE_META = {
    "反常识": {
        "why": "推翻观众默认做法，认知失衡必须停下来看个明白（停下来的理由）",
        "tone": "平静压低，像在说一个事实", "face": "认真直视镜头，不笑",
        "sub": "结论词大一号并变色",
    },
    "悬念缺口": {
        "why": "信息给一半留一半，大脑讨厌未完成（值得等下一秒）",
        "tone": "压低放慢，卖关子但不拖", "face": "身体微微前倾",
        "sub": "「接下来」单独一行再换行揭晓",
    },
    "点名痛点": {
        "why": "说中观众此刻正在做/正在忍的事，代入感瞬间拉满（跟我有关系）",
        "tone": "像跟朋友吐槽，口语化", "face": "苦笑点头",
        "sub": "痛点词变色，问号后停半拍",
    },
    "数字具体": {
        "why": "具体数字自带可信度与画面感，抽象形容没有（停下来的理由）",
        "tone": "干脆利落，不绕", "face": "比出数字手势",
        "sub": "数字大号居中，其余字幕小一号",
    },
    "身份代入": {
        "why": "点名身份，目标观众第一反应「说的就是我」（跟我有关系）",
        "tone": "点名感，像在人群里找人对视", "face": "认真，眼神聚焦",
        "sub": "身份词高亮",
    },
    "争议观点": {
        "why": "站一个会被反驳的立场，反方自己走进评论区（互动燃料）",
        "tone": "笃定，语速稳，不喊", "face": "挑眉，带一点笑",
        "sub": "立场词标红，结尾留白一秒",
    },
    "反差画面": {
        "why": "两个画面对撞，处理不一致时大脑卡顿——卡顿就是停留（停下来的理由）",
        "tone": "两段之间停顿半拍", "face": "眼神左右切换对应两段",
        "sub": "分屏字幕对撞，转折词变色",
    },
}

KEEP_WORDS = ["接下来", "第三", "真相", "差别", "别划走", "讲透", "更狠", "没人"]


def _fill(tpl, slots):
    out = tpl
    for k, v in slots.items():
        out = out.replace("{" + k + "}", v)
    return out.strip()


def gen_hooks(slots, styles=None):
    """七式 × 3 = 21 条。styles 指定则只出这些式。返回 [{style, text}]。"""
    T = {
        "反常识": [
            "别再{pain}了，{core}。",
            "很多人以为{pain}是出路，其实{core}。",
            "{pain}的尽头不是安稳，是原地打转——{core}。",
        ],
        "悬念缺口": [
            "关于{topic}，接下来这句可能得罪你：{core}",
            "{pain}的人都不知道，{core}，第三句更狠。",
            "我盯着{number}才看明白：{core}——原因没人明说。",
        ],
        "点名痛点": [
            "你是不是也{pain}？这条讲透。",
            "一到月底就慌的，先别划走——{core}。",
            "如果你正{pain}，这三分钟给你讲明白。",
        ],
        "数字具体": [
            "{number}，我亲测了一件事：{core}",
            "{number}，只做对了一步——今天全告诉你。",
            "我拿{number}验证了{topic}的真相。",
        ],
        "身份代入": [
            "如果你也是{audience}，这条别划走。",
            "{audience}注意了，{core}。",
            "这条只讲给{audience}，其他人不用看。",
        ],
        "争议观点": [
            "我劝你别再{pain}，不服评论区聊。",
            "说句得罪人的话：{core}——不同意的来评论区辩。",
            "大多数人都在{pain}，聪明人早就换了打法——差距就是这么拉的。",
        ],
        "反差画面": [
            "昨天还在{pain}，今天才明白：{core}",
            "同样是{topic}，有人{pain}，有人闷声干成了——差别在哪？",
            "表面上是{pain}，实际上是{core}。",
        ],
    }
    hooks = []
    for style, tpls in T.items():
        if styles and style not in styles:
            continue
        for tpl in tpls:
            hooks.append({"style": style, "text": _fill(tpl, slots)})
    return hooks


def list_styles():
    """列出七式与模板骨架，供 --list 使用。"""
    print("钩子七式 × 每式 3 条 = 21 条起步。选式：--style \"式名\"\n")
    for i, style in enumerate(STYLE_META, 1):
        m = STYLE_META[style]
        print("%d. %s —— %s" % (i, style, m["why"]))
    print("\n每条开方单附：为什么能留人 + 演绎提示（语气/表情/字幕）+ 三问分排序。")
    print("完整成品范例看 references/full-demo.md；常见问题看 references/faq.md。")


def score_hook(text):
    """前3秒三问计分：停下来(0-2) + 相关性(0-1) + 值得等(0-2)。"""
    stop, rel, wait, notes = 0, 0, 0, []
    if any(w in text for w in ["别再", "其实", "不是", "别划走"]):
        stop += 1; notes.append("反常识标记")
    if any(w in text for w in ["接下来", "得罪", "没人", "差别", "表面", "真相", "不知道"]):
        stop += 1; notes.append("悬念/冲突标记")
    if re.search(r"\d", text):
        stop += 1 if stop == 0 else 0; notes.append("具体数字")
    if any(w in text for w in ["你是不是", "如果你", "注意了", "讲给"]):
        rel += 1; notes.append("身份/痛点点名")
    if any(w in text for w in KEEP_WORDS):
        wait += 1; notes.append("留人词")
    n = len(text)
    if 15 <= n <= 21:
        wait += 1; notes.append("字数 %d（3 秒口播容量内）" % n)
    elif n > 25:
        notes.append("字数 %d 超容量，口播会赶" % n)
    elif n < 15:
        notes.append("字数 %d 偏短，信息量薄" % n)
    else:
        notes.append("字数 %d 略超，语速快可救" % n)
    return stop + rel + wait, {"停下来": stop, "有关系": rel, "值得等": wait, "notes": notes}


def diagnose_original(original):
    n = len(original or "")
    keep = [w for w in KEEP_WORDS if w in (original or "")]
    issues = []
    if n > 25:
        issues.append("原开头 %d 字，超过 3 秒口播容量（约 15-21 字）" % n)
    if not keep:
        issues.append("未检测到留人词——观众没有「等下一秒」的理由")
    if not issues:
        issues.append("原开头结构基本达标，问题可能在内容而非结构——逐条对比新钩子找差距")
    return issues


def build_report(topic, core, audience, pain, number, original, ranked, issues, out):
    lines = []
    lines.append("# 钩子开方单（前3秒钩子实验室）")
    lines.append("")
    lines.append("> 模板出骨架、人工润色定稿；本单不含任何完播率/爆款效果承诺——排序是机器算的，选择是人做的。")
    lines.append("")
    lines.append("## 病历")
    lines.append("")
    lines.append("- 主题：%s" % topic)
    lines.append("- 核心信息（结论）：%s" % core)
    lines.append("- 目标身份：%s ｜ 痛点动作：%s ｜ 数字：%s" % (audience, pain, number))
    if original:
        lines.append("- 原开头：%s" % original)
        lines.append("- 原开头诊断：%s" % "；".join(issues))
    else:
        lines.append("- 原开头：未提供（直接开方）")
    lines.append("")
    lines.append("## Top3（三问排序，按你的口播气质挑一条）")
    lines.append("")
    for i, h in enumerate(ranked[:3], 1):
        m = STYLE_META[h["style"]]
        s = h["score_detail"]
        lines.append("**%d. [%s] %s**（三问分 %d：停下来 %d / 有关系 %d / 值得等 %d）" %
                     (i, h["style"], h["text"], h["score"], s["停下来"], s["有关系"], s["值得等"]))
        lines.append("- 为什么能留人：%s" % m["why"])
        lines.append("- 演绎：语气%s；表情%s；字幕%s" % (m["tone"], m["face"], m["sub"]))
        lines.append("")
    lines.append("## 全清单（%d 条，按三问分排序）" % len(ranked))
    lines.append("")
    lines.append("| # | 式 | 钩子 | 分 | 信号 |")
    lines.append("|---|---|---|---|---|")
    for i, h in enumerate(ranked, 1):
        lines.append("| %d | %s | %s | %d | %s |" %
                     (i, h["style"], h["text"], h["score"], "、".join(h["score_detail"]["notes"])))
    lines.append("")
    lines.append("## 使用纪律")
    lines.append("")
    lines.append("1. 一次只换头不动身子——数据才归因得了；")
    lines.append("2. 选中的钩子用你自己的口气改一遍再上场——模板是骨架不是成衣；")
    lines.append("3. 换头后丢回「爆款预言机」复测——分数上去才算治好；")
    lines.append("4. 数字槽位只能填真实数据，编数字不如不填。")
    text = "\n".join(lines)
    out = out or "钩子开方单.md"
    try:
        with open(out, "w", encoding="utf-8") as f:
            f.write(text)
    except PermissionError:
        print("\n❌ 没有写入权限：%s。换个目录（如当前文件夹），或检查文件是不是被别的程序锁住了。" % out)
        print("   下面是开方单全文，可先手动复制保存：\n")
        print(text)
        sys.exit(2)
    except OSError as e:
        print("\n❌ 开方单写不进去（%s）：%s" % (type(e).__name__, e))
        print("   换个 --out 路径试试，例如：--out ./钩子开方单.md")
        print("   下面是开方单全文，可先手动复制保存：\n")
        print(text)
        sys.exit(2)
    print(text)
    print("\n[开方单已保存] %s" % out)


DEMO = {
    "topic": "普通人翻身",
    "core": "攒钱正在让你变穷",
    "audience": "月薪五千还想搞副业的上班族",
    "pain": "死攒工资",
    "number": "90天",
    "original": "大家好，今天想跟大家聊聊存钱这件事",
}


def demo(out=None):
    print("【演示模式】内置样例：财富赛道（原开头先诊断再开方）")
    print("原开头：%s" % DEMO["original"])
    print()
    d = dict(DEMO)
    d["out"] = out or "钩子开方单.md"
    run(d)


def run(d):
    styles = d.get("styles")
    slots = {"topic": d["topic"], "core": d["core"], "audience": d["audience"],
             "pain": d["pain"], "number": d["number"]}
    hooks = gen_hooks(slots, styles=styles)
    for h in hooks:
        h["score"], h["score_detail"] = score_hook(h["text"])
    ranked = sorted(hooks, key=lambda x: (-x["score"], x["style"]))
    issues = diagnose_original(d.get("original")) if d.get("original") else []
    build_report(d["topic"], d["core"], d["audience"], d["pain"], d["number"],
                 d.get("original"), ranked, issues, d.get("out"))


def main():
    ap = argparse.ArgumentParser(description="前3秒钩子实验室 · 开方器", add_help=False)
    ap.add_argument("-h", "--help", action="store_true")
    ap.add_argument("--topic")
    ap.add_argument("--core")
    ap.add_argument("--audience", default="想搞钱的普通人")
    ap.add_argument("--pain", default="瞎忙")
    ap.add_argument("--number", default="三个月")
    ap.add_argument("--original")
    ap.add_argument("--style")
    ap.add_argument("--out")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.help:
        print(__doc__)
        return
    if args.list:
        list_styles()
        return
    if args.demo:
        demo(out=args.out)
        return

    styles = None
    if args.style:
        valid = list(STYLE_META)
        if args.style not in valid:
            print("❌ 没有这一式：「%s」" % args.style)
            print("   七式是：%s" % "、".join(valid))
            print("   例：--style \"点名痛点\"；想看每式说明：--list")
            sys.exit(2)
        styles = [args.style]

    if not args.core:
        print("❌ 缺了必填的 --core（一句话结论）——钩子都是结论的变装。")
        print("   完整示例：")
        print("   python3 hook_lab.py --topic \"普通人翻身\" --core \"攒钱正在让你变穷\" \\")
        print("       --audience \"月薪五千的上班族\" --pain \"死攒工资\" --number \"90天\"")
        print("   不想填这么多？先看演示：python3 hook_lab.py --demo")
        sys.exit(1)
    if args.topic is None:
        print("ℹ️ 没给 --topic，用结论顶上：「%s」。想分开给：--topic 选题 --core 结论\n" % args.core)
    run({"topic": args.topic or args.core, "core": args.core, "audience": args.audience,
         "pain": args.pain, "number": args.number, "original": args.original,
         "out": args.out, "styles": styles})


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n已取消。")
        sys.exit(2)
