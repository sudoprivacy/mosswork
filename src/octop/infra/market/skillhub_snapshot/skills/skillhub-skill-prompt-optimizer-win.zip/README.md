# prompt-optimizer · AI视频生成提示词优化兼成本管理

`version 2.0.0` · 规范回查与修订日期 **2026-11-12（GMT+8）**

把 storyboarder 的平台中性分镜提示词翻成**即梦 / 可灵 / Vidu 可直接粘贴运行**的完整提示词，强制回查当期定价，输出**含重试系数的成本区间**、参数卡、最省方案与废片重跑策略；一键产出 **WorkBuddy 开放平台 + SkillHub 双平台上传包**。

**不负责**：剪辑、合成、上传发布、平台审核、账号注册与代付。不承诺一次出片、不承诺上架成功。

---

## 一、最快上手（一条命令出成品）

```bash
# 1) 先用示例跑通（示例 project_id=demo-001，非真实项目）
python scripts/run_pipeline.py --demo --outdir ./dist

# 2) 真实项目：复制模板改写后运行
cp templates/storyboard_input_template.json storyboard.json
python scripts/run_pipeline.py --input storyboard.json --outdir ./dist
```

**运行环境**：Python 3.9+（本机验证 3.13.14），**仅标准库，无需安装任何依赖**；所有文本 UTF-8 无 BOM。

一条命令完成 5 步：输入体检 → 三平台完整提示词 → 成本区间 → 合并回填主表 → 双平台 ZIP。产出清单见 `dist/DELIVERY_MANIFEST.md`。

| 主要产物 | 用途 |
| --- | --- |
| `full_prompts_<pid>.md` | 三平台**完整提示词全文**，可直接复制粘贴运行 |
| `prompt_variants_<pid>.csv` | 主表（提示词全文 + 已回填成本，无占位内容） |
| `prompt_variants_<pid>.json` | 机器可读，含 `variants[]` / `costs[]` / `rerun_rules[]` |
| `cost_summary_<pid>.md` | 成本总表副表、隐性成本、最省方案 |
| `parameter_cards_<pid>.md` | 参数卡汇总 |
| `workbuddy_upload_*.zip` | WorkBuddy 开放平台上传包（`prompt-optimizer/SKILL.md`） |
| `skillhub_upload_*.zip` | SkillHub 上传包（`SKILL.md` 在包根） |
| `manifest_*.json` | 逐文件 SHA-256 与包体自检结果 |
| `DELIVERY_MANIFEST.md` | 人话版交付清单与上传前必做事项 |

---

## 二、3 条触发示例（照着说就能调用）

1. **三平台变体**
   > 把这份 storyboarder 分镜表优化成即梦/可灵/Vidu 三平台可直接粘贴的提示词，角色档案库在附件里，720p、需要对口型。

2. **成本估算与最省方案**
   > 按 720p、需原生音频算一下 24 个镜头跑完要多少积分，给三平台对比和最省方案，预算上限 5000 积分。

3. **废片诊断与重跑**
   > 废片率超过 40% 了，帮我定位是提示词、参考图还是运动幅度的问题，补负向词、给重跑策略并升 prompt_id。

其他触发语：优化提示词 / 直接喂即梦 / 可灵怎么写 / 三平台变体 / 多少钱能跑完 / 成本估算 / 废片太多 / 重跑策略 / 积分怎么算。

---

## 三、安装方式

### 本地使用
把整个 `prompt-optimizer/` 目录复制到用户级 skills 目录后重启会话即可调用：

```
Windows:  C:\Users\<用户名>\.workbuddy\skills\prompt-optimizer\
macOS/Linux: ~/.workbuddy/skills/prompt-optimizer/
```

### 上传平台
见 `references/publishing-guide.md`（含完整目录结构、双平台差异、占位符清单、自检清单与上传步骤）。

**上传前必做**：替换 `REPLACE_WITH_YOUR_UNIQUE_SLUG` / `REPLACE_WITH_AUTHOR_OR_ORG` / `REPLACE_WITH_LICENSE` / `REPLACE_WITH_CATEGORY` 四个占位符，并重新联网回查定价。

---

## 四、脚本一览

| 脚本 | 作用 | 单独运行 |
| --- | --- | --- |
| `generate_variants.py` | 生成三平台完整提示词（消除占位内容） | `--demo` 或 `--input <json> --outdir <dir>` |
| `estimate_cost.py` | 成本区间、统计口径、三档对比、最省方案 | 同上 |
| `build_upload_package.py` | 一键构建双平台 ZIP + 哈希清单 | `--source <dir> --outdir <dir> --target both` |
| `doctor.py` | 人话诊断 + 自动修复 | `--skill-dir <dir> --fix`，退出码 0/1/2 |
| `validate_open_platform.py` | 双平台规范自检 | `--skill-dir <dir> --platform both --zip ... --zip-skillhub ...` |
| `run_pipeline.py` | 一键编排全流程（内置成本回填合并） | `--demo --outdir ./dist` |

全部脚本仅用标准库，出错时统一给 `[怎么了] / [怎么改]`，不静默吞错。

---

## 五、三条铁律与价格红线

1. 同一镜头跨平台可比：`shot_id`、外貌锚点、参考图编号、时长、seed 不变，只改语法层。
2. **价格必须当期回查**：禁止沿用历史价格；凡输出成本处必须附 `抓取日期 + 来源 URL`。
3. **估算给区间不给单点**：High 1.5 / Mid 1.3 / Low 1.2，输出 `[1.2, 1.5]` 区间。

**统计口径**：成本汇总只含「单价已核实」的镜头，未核实镜头整行标 `待核实` 且不计入 → 该数值是**下界、不是全量报价**；覆盖镜头数不同的列**不得直接比大小**。

> **当期实证**：即梦官方活动页仍挂「¥0.16/秒」，同页写明「活动时间 10月31日至11月5日 23:59」「限时优惠结束后恢复日常价格」——该价已过期、禁止使用。完整原文与来源见 `references/pricing-fields.md`。

---

## 六、文档导航（渐进式披露）

| 层级 | 文件 |
| --- | --- |
| L1 上手 | `SKILL.md` §0–2、本 README、`FAQ.md` |
| L2 执行 | `templates/storyboard_input_template.json`、`references/platform-syntax.md`、`references/pricing-fields.md` |
| L3 发布/维护 | `references/publishing-guide.md`、`references/open-platform-spec.md`、`references/skillhub-spec.md`、`CHANGELOG.md`、`MEMORY.md` |

- `FAQ.md`：集中常见问题清单（上手 / 输入 / 提示词 / 成本 / 打包上传 / 质检 / 报错速查）
- `CHANGELOG.md`：按 TRACE 维度逐条列出原评价、处理方式、对应文件与修订结果
- `MEMORY.md`：**长期记忆与维护说明**，正向结论 / 适用边界 / 约束 / 保护条件，明确「后续迭代不得削弱」
- `references/trace-evaluation.md`：TRACE 原评价逐字归档，供追溯

---

## 七、边界与免责

- 示例数据（含 `demo-001`）均为**示例占位**，非真实项目、非真实扣费记录。
- 标 `待核实` 的价格不得当作确定值；成本须输出区间并注明「未核实」。
- 包内不含任何 API Key、密码、Cookie、账号凭证、会员账号信息或真实用户数据。
- 只生成上传包与本地自检结果，**不代替平台审核、不承诺上架成功**；上传与提交审核由用户本人在平台侧完成。
