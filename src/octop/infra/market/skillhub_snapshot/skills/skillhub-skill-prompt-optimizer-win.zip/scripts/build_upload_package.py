#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_upload_package.py — 一键构建 WorkBuddy 开放平台 / SkillHub 双平台上传包
=============================================================================

对应 TRACE 扣分项
-----------------
R/功能完善性 4.0「自动打包…没有真正完成」
R/运行稳定性 4.3「复杂或特殊输入时，缺少自动恢复和完整验证保障」
E/开箱即用度 4.2「想直接拿到可用成品仍需补步骤」

两平台结构冲突（2026-11-12 回查结论，见 references/skillhub-spec.md）
---------------------------------------------------------------------
WorkBuddy 官方：ZIP 内为 `{skill-name}/SKILL.md`（一层包裹目录）
SkillHub 评测口径：SKILL.md 在 ZIP 包根，不能多套一层
→ 因此必须出**两个 ZIP**，不能用一个包同时满足。本脚本一次生成两个。

依赖：Python 3.9+，仅标准库。
运行：
    python build_upload_package.py --source ./prompt-optimizer --outdir ./dist \
        --project-id demo-001 --target both
    python build_upload_package.py --source ./prompt-optimizer --outdir ./dist --dry-run

输出：
    workbuddy_upload_prompt-optimizer_<project_id>_<date>.zip
    skillhub_upload_prompt-optimizer_<project_id>_<date>.zip
    manifest_<project_id>_<date>.json   （逐文件 SHA-256 与自检结果，不打包进 ZIP）
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from datetime import date
from pathlib import Path

# 占位符：用户未提供的值一律显式标注，绝不编造
PLACEHOLDERS = {
    "slug": "REPLACE_WITH_YOUR_UNIQUE_SLUG",
    "author": "REPLACE_WITH_AUTHOR_OR_ORG",
    "license": "REPLACE_WITH_LICENSE",
    "category": "REPLACE_WITH_CATEGORY",
}

# 包大小上限：均来自第三方口径，官方页未明示 → 标待核实，从严执行
LIMITS = {
    "workbuddy": 3 * 1024 * 1024,
    "skillhub": 10 * 1024 * 1024,
}
LIMIT_NOTICE = {
    "workbuddy": "3MB 为第三方实践文章口径，WorkBuddy 官方《技能》页未明示，标待核实",
    "skillhub": "10MB 为第三方公众号文章口径，SkillHub 官方文档未明示，标待核实",
}

SKILLHUB_FRONTMATTER = """---
name: prompt-optimizer
slug: {slug}
displayName: AI视频提示词优化与成本管理
display_name: AI视频提示词优化与成本管理
display_name_en: AI Video Prompt Optimizer and Cost Manager
description: >
  当用户要把提示词优化到可直接喂即梦/可灵/Vidu、要三平台变体、要算生成成本、
  要降低废片率时使用。触发词：优化提示词、直接喂即梦、可灵怎么写、三平台变体、
  多少钱能跑完、成本估算、废片太多、重跑策略、积分怎么算。
  输出三平台提示词变体表、成本估算、参数卡与重跑策略。不负责剪辑与上传。
description_zh: >-
  把平台中性分镜提示词翻成即梦/可灵/Vidu 可直接粘贴的原生语法，
  强制回查当期定价，输出含重试系数的成本区间、最省方案与废片重跑策略。
description_en: >-
  Convert platform-neutral storyboard prompts into paste-ready Jimeng, Kling and
  Vidu syntax; verify current pricing and output cost ranges with retry factors.
summary: AI视频生成提示词优化兼成本管理：三平台变体、当期定价回查、成本区间与重跑策略
version: {version}
author: "{author}"
license: "{license}"
category: "{category}"
platforms: [WorkBuddy, SkillHub]
allowed-tools: "Bash,Read,Write,WebFetch,WebSearch"
examples_zh:
  - "把这份 storyboarder 分镜表优化成即梦/可灵/Vidu 三平台可直接粘贴的提示词"
  - "按 720p、需要对口型，算一下 24 个镜头跑完要多少积分，并给最省方案"
  - "废片率超过 40% 了，帮我定位原因、补负向词并升 prompt_id"
examples_en:
  - "Turn this storyboard into paste-ready prompts for Jimeng, Kling and Vidu"
  - "Estimate credits for 24 shots at 720p with lip-sync and give the cheapest plan"
  - "Waste rate is above 40%: diagnose causes and propose rerun rules"
---
"""


def strip_frontmatter(text: str) -> str:
    """取回 SKILL.md 正文（去掉首个 YAML frontmatter 块）。"""
    m = re.match(r"^---\s*\n.*?\n---\s*\n", text, re.DOTALL)
    return text[m.end():] if m else text


def read_version(skill_md: str) -> str:
    m = re.search(r"^version:\s*[\"']?([\d.]+)[\"']?\s*$", skill_md, re.MULTILINE)
    return m.group(1) if m else "2.0.0"


# 运行时产物目录：绝不打进上传包（否则 dist 里的示例输出会污染技能内容）
EXCLUDE_DIRS = {"__pycache__", "dist", "out", "_scratch", "_test_out", ".git"}


def collect_files(src: Path) -> list[Path]:
    return sorted(p for p in src.rglob("*") if p.is_file()
                  and not (set(p.relative_to(src).parts) & EXCLUDE_DIRS)
                  and not p.name.endswith((".pyc", ".zip", ".log")))


def scan_secrets(files: list[Path]) -> list[str]:
    """凭证扫描：只查赋值形式，说明性文字不误报。"""
    import re as _re
    pats = [
        _re.compile(r"(?i)\b(api[_-]?key|access[_-]?token|secret[_-]?key|password|cookie|authorization)\b\s*[:=]\s*['\"]?[A-Za-z0-9_\-\.]{8,}"),
        _re.compile(r"\b(skh_[A-Za-z0-9]{16,}|sk-[A-Za-z0-9]{16,}|ghp_[A-Za-z0-9]{20,})\b"),
    ]
    whitelist = ("不得", "禁止", "清掉", "不含", "扫描", "检查", "- [ ]",
                 "re.compile", "PLACEHOLDERS", "api[_-]?key", "SECRET")
    hits = []
    for p in files:
        if p.suffix.lower() not in {".md", ".py", ".json", ".csv", ".txt", ".yaml", ".yml"}:
            continue
        try:
            lines = p.read_text(encoding="utf-8").splitlines()
        except (UnicodeDecodeError, OSError):
            continue
        for i, line in enumerate(lines, 1):
            if any(w in line for w in whitelist):
                continue
            if any(pat.search(line) for pat in pats):
                hits.append(f"{p.name}:{i}")
    return hits


def build_zip(src: Path, zp: Path, platform: str,
              skillhub_md: str | None) -> dict[str, Any]:
    files = collect_files(src)
    prefix = "prompt-optimizer/" if platform == "workbuddy" else ""
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            rel = p.relative_to(src).as_posix()
            if platform == "skillhub" and rel == "SKILL.md":
                z.writestr("SKILL.md", skillhub_md)
            else:
                z.write(p, prefix + rel)
    size = zp.stat().st_size
    with zipfile.ZipFile(zp) as z:
        names = z.namelist()
        has_skill_md = any(n == prefix + "SKILL.md" for n in names)
        tops = {n.split("/")[0] for n in names if "/" in n}
        max_depth = max((len(n.split("/")) for n in names), default=0)
        non_ascii = [n for n in names if any(ord(c) > 127 for c in n)]
    checks = {
        "has_skill_md_at_expected_place": has_skill_md,
        "size_bytes": size,
        "size_limit_bytes": LIMITS[platform],
        "size_ok": size <= LIMITS[platform],
        "size_limit_notice": LIMIT_NOTICE[platform],
        "top_level_dirs": sorted(tops),
        "max_path_depth": max_depth,
        "non_ascii_filenames": non_ascii,
        "utf8_filename_notice": ("包内文件名均为 ASCII；若后续加入中文文件名，"
                                 "zipfile 会自动置 UTF-8 标志，可在解压端复核"),
        "file_count": len(files),
    }
    return checks


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="构建双平台上传包")
    ap.add_argument("--source", required=True, help="skill 源目录")
    ap.add_argument("--outdir", default="./dist", help="输出目录")
    ap.add_argument("--project-id", default="demo-001", help="项目 ID（示例占位符 demo-001）")
    ap.add_argument("--target", choices=["workbuddy", "skillhub", "both"], default="both")
    ap.add_argument("--dry-run", action="store_true", help="只自检不产出 ZIP")
    args = ap.parse_args(argv)

    src = Path(args.source).resolve()
    if not (src / "SKILL.md").is_file():
        print("[怎么了] 源目录里没有 SKILL.md", file=sys.stderr)
        print("[怎么改] --source 应指向含 SKILL.md 的 skill 目录本身", file=sys.stderr)
        return 2

    files = collect_files(src)
    orig = (src / "SKILL.md").read_text(encoding="utf-8")
    version = read_version(orig)
    body = strip_frontmatter(orig)
    skillhub_md = SKILLHUB_FRONTMATTER.format(
        slug=PLACEHOLDERS["slug"], version=version,
        author=PLACEHOLDERS["author"], license=PLACEHOLDERS["license"],
        category=PLACEHOLDERS["category"]) + "\n" + body

    secrets = scan_secrets(files)
    if secrets:
        print("[怎么了] 检出疑似凭证赋值，已停止打包", file=sys.stderr)
        print(f"[怎么改] 清除以下位置的凭证后再打包：{', '.join(secrets[:10])}", file=sys.stderr)
        return 2

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    today = date.today().isoformat()
    targets = ["workbuddy", "skillhub"] if args.target == "both" else [args.target]
    manifest: dict[str, Any] = {
        "project_id": args.project_id,
        "build_date": today,
        "version": version,
        "source_dir": str(src),
        "placeholders_must_replace": {
            "slug": "SkillHub 全网唯一标识，kebab-case，2–128 字符；建议带上你的 handle",
            "author": "作者或机构名称",
            "license": "开源许可证，例如 MIT；按你的实际情况填写",
            "category": "SkillHub 分类；按平台当期可选分类填写",
            "project_id": "示例占位符 demo-001，正式交付时替换为真实项目 ID",
        },
        "spec_fetch_date": "2026-11-12",
        "spec_urls": {
            "workbuddy": "https://open.workbuddy.cn/docs/skill",
            "skillhub_tutorial": "https://www.skillhub.cn/tutorials",
            "skillhub_agent_release": "https://skillhub.cn/ai/release.md",
        },
        "secret_scan": {"passed": True, "hits": []},
        "files": [],
        "packages": {},
    }
    for p in files:
        manifest["files"].append({
            "path": p.relative_to(src).as_posix(),
            "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        })

    if args.dry_run:
        print(f"[预检] 源目录 {src}，文件 {len(files)} 个，版本 {version}")
        print("[预检] 凭证扫描通过；未写出 ZIP（--dry-run）")
        print("[预检] 待替换占位符：" + ", ".join(PLACEHOLDERS.values()))
        return 0

    for platform in targets:
        fname = f"{platform}_upload_prompt-optimizer_{args.project_id}_{today}.zip"
        zp = outdir / fname
        checks = build_zip(src, zp, platform,
                           skillhub_md if platform == "skillhub" else None)
        manifest["packages"][platform] = {"filename": fname, **checks}
        ok = checks["size_ok"] and checks["has_skill_md_at_expected_place"]
        print(f"[{'完成' if ok else '失败'}] {fname}  {checks['size_bytes']} 字节  "
              f"文件 {checks['file_count']} 个  SKILL.md位置="
              f"{'包根' if platform=='skillhub' else 'prompt-optimizer/'}")
        if not ok:
            return 2

    mp = outdir / f"manifest_{args.project_id}_{today}.json"
    mp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[完成] 清单：{mp}")
    print("[必做] 上传 SkillHub 前替换 SKILL.md 中的 slug / author / license / category 占位符")
    print("[提示] 随后运行 skillhub publish <解压目录> --dry-run 做平台侧预检（本脚本不代替平台审核）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
