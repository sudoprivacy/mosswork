#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
doctor.py — 直白诊断 + 自动修复
================================

对应 TRACE 扣分项
-----------------
R/异常处理 4.0「提示偏技术化，缺少更直白的修正步骤和自动修复方案」
R/运行稳定性 4.3「遇到复杂或特殊输入时，缺少自动恢复和完整验证保障」
C/反模式与FAQ 4.5「没有一份便于快速查询的常见问题清单」（配套 references/FAQ.md）

设计原则：**先说人话，再说怎么改，最后才给技术细节**。
每条问题固定三段式：
    [怎么了] 一句话说明现象
    [怎么改] 一条可直接照做的动作
    [已自动修复] 仅 --fix 时出现，说明改了什么

依赖：Python 3.9+，仅标准库。
运行：
    python doctor.py --skill-dir ./prompt-optimizer --json
    python doctor.py --skill-dir ./prompt-optimizer --fix
    python doctor.py --input storyboard.json --fix

退出码（对齐 SkillHub 评测官口径）：
    0 = 可传（无阻断项）
    1 = 有风险（WARN，建议修）
    2 = 会被拒（阻断项，必须先修）
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from pathlib import Path
from typing import Any

REQUIRED_WB = ["name", "display_name", "display_name_en", "description",
               "description_zh", "description_en", "version", "author"]
REQUIRED_SH = ["slug", "displayName", "version"]
RECOMMENDED_SH = ["summary", "description", "license", "tags", "homepage"]
PLACEHOLDER_PREFIX = "REPLACE_WITH_"

USER_MSG = {
    "no_skill_md": ("找不到 SKILL.md", "把 SKILL.md 放进 skill 目录的最外层；不要套在子文件夹里"),
    "bom": ("SKILL.md 开头带了隐藏的 BOM 字符，部分平台会解析失败",
            "运行 python scripts/doctor.py --skill-dir <目录> --fix，会自动去掉"),
    "bad_yaml": ("SKILL.md 开头不是标准的 --- 分隔块",
                 "确认第一行是 ---，字段写完后另起一行再写一个 ---"),
    "missing_field": ("frontmatter 缺字段 {field}", "在 --- 块内补一行 {field}: <内容>"),
    "name_mismatch": ("目录名和 name 对不上，平台会混淆",
                      "把目录名改成与 name 完全一致，或改 name 与目录一致"),
    "dir_too_deep": ("有文件埋得太深（超过 2 层目录）",
                     "把该文件移到 references/ 或 templates/ 下，不要建三级子目录"),
    "placeholder_left": ("还留着占位符 {token}，上传前必须换成真实值",
                         "打开 SKILL.md，把 {token} 改成你自己的值（slug 需全网唯一）"),
    "secret_found": ("包里疑似有密钥或凭证，安全审核会拒绝",
                     "删掉该行里的真实凭证，改用环境变量；本脚本不会自动删文件"),
    "input_json_bad": ("输入 JSON 读不出来：{detail}",
                       "用 UTF-8 无 BOM 重新保存；或复制 templates/storyboard_input_template.json 改写"),
    "input_missing": ("输入缺必填字段 {field}",
                      "在 JSON 顶层补 \"{field}\"；模板在 templates/storyboard_input_template.json"),
    "input_anchor": ("角色缺外貌锚点，三平台一致性会失守",
                     "给每个角色补 appearance_anchor，逐字复制角色档案库原文"),
    "outdir_missing": ("输出目录不存在", "不用担心，脚本会自动创建；也可手动新建该目录"),
    "structure_ok": ("结构检查已完成", "无需处理"),
}


class Finding:
    def __init__(self, level: str, code: str, **kw: Any) -> None:
        self.level = level          # BLOCK / WARN / OK
        self.code = code
        self.kw = kw
        self.fixed = False

    def render(self) -> str:
        msg, fix = USER_MSG.get(self.code, (self.code, "见 references/FAQ.md"))
        try:
            msg, fix = msg.format(**self.kw), fix.format(**self.kw)
        except (KeyError, IndexError):
            pass
        tag = {"BLOCK": "[会被拒]", "WARN": "[有风险]", "OK": "[通过]"}[self.level]
        out = [f"{tag} [怎么了] {msg}", f"       [怎么改] {fix}"]
        if self.fixed:
            out.append("       [已自动修复] 已按上面动作自动处理，无需手动操作")
        return "\n".join(out)

    def as_dict(self) -> dict[str, Any]:
        msg, fix = USER_MSG.get(self.code, (self.code, ""))
        try:
            msg, fix = msg.format(**self.kw), fix.format(**self.kw)
        except (KeyError, IndexError):
            pass
        return {"level": self.level, "code": self.code, "what": msg,
                "how_to_fix": fix, "auto_fixed": self.fixed, **self.kw}


def parse_frontmatter(text: str) -> dict[str, str]:
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return {}
    out = {}
    for line in m.group(1).splitlines():
        if line.startswith(("-", " ")) or not line.strip() or line.lstrip().startswith("#"):
            continue
        kv = re.match(r"^([A-Za-z][A-Za-z0-9_-]*)\s*:\s*(.*)$", line)
        if kv:
            out[kv.group(1)] = kv.group(2).strip().strip('"').strip("'")
    return out


def check_skill_dir(src: Path, platform: str, fix: bool) -> list[Finding]:
    findings: list[Finding] = []
    p = src / "SKILL.md"
    if not p.is_file():
        findings.append(Finding("BLOCK", "no_skill_md"))
        return findings
    raw = p.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        f = Finding("BLOCK", "bom")
        if fix:
            p.write_bytes(raw[3:])
            f.fixed = True
            f.level = "OK"
        findings.append(f)
        raw = p.read_bytes()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        findings.append(Finding("BLOCK", "input_json_bad", detail="SKILL.md 不是 UTF-8"))
        return findings
    fm = parse_frontmatter(text)
    if not fm:
        findings.append(Finding("BLOCK", "bad_yaml"))
        return findings

    required = REQUIRED_WB if platform == "workbuddy" else REQUIRED_SH
    for field in required:
        if field not in fm or not fm[field]:
            f = Finding("BLOCK", "missing_field", field=field)
            if fix:
                # 只补结构，值用清晰占位符，不编造真实信息
                token = f"{PLACEHOLDER_PREFIX}{field.upper()}"
                block = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
                if block:
                    new_fm = block.group(1) + f"\n{field}: {token}\n"
                    text = text.replace(block.group(0), f"---\n{new_fm}---", 1)
                    p.write_text(text, encoding="utf-8")
                    f.fixed = True
                    f.level = "WARN"   # 补成占位符仍需人工填内容
            findings.append(f)
    for field in RECOMMENDED_SH if platform == "skillhub" else []:
        if field not in fm:
            findings.append(Finding("WARN", "missing_field", field=field))

    if fm.get("name") and src.name != fm["name"]:
        findings.append(Finding("BLOCK", "name_mismatch"))
    for token in set(re.findall(r"REPLACE_WITH_[A-Z_]+", text)):
        findings.append(Finding("WARN", "placeholder_left", token=token))
    for f_ in src.rglob("*"):
        if f_.is_file() and len(f_.relative_to(src).parts) > 3:
            findings.append(Finding("BLOCK", "dir_too_deep"))
            break
    findings.append(Finding("OK", "structure_ok"))
    return findings


def check_input(path: Path, fix: bool) -> list[Finding]:
    findings: list[Finding] = []
    if not path.is_file():
        findings.append(Finding("BLOCK", "input_json_bad", detail="文件不存在"))
        return findings
    try:
        cfg = json.loads(path.read_text(encoding="utf-8-sig"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        findings.append(Finding("BLOCK", "input_json_bad", detail=str(e)))
        return findings
    touched = False
    for key in ("project_id", "shots", "characters"):
        if key not in cfg:
            f = Finding("BLOCK", "input_missing", field=key)
            if fix:
                defaults = {"project_id": "REPLACE_WITH_PROJECT_ID",
                            "shots": [], "characters": {}}
                cfg[key] = defaults[key]
                f.fixed = True
                f.level = "WARN"   # 补成占位符后仍需人工填真实内容
                touched = True
            findings.append(f)
    for rid, ch in (cfg.get("characters") or {}).items():
        if isinstance(ch, dict) and not ch.get("appearance_anchor"):
            findings.append(Finding("BLOCK", "input_anchor"))
    if touched:
        path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return findings


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="直白诊断 + 自动修复")
    ap.add_argument("--skill-dir", help="skill 目录")
    ap.add_argument("--input", help="storyboard 输入 JSON（可选）")
    ap.add_argument("--platform", choices=["workbuddy", "skillhub"], default="workbuddy")
    ap.add_argument("--fix", action="store_true", help="自动修复可修的问题")
    ap.add_argument("--json", action="store_true", help="输出 JSON（供 CI 使用）")
    args = ap.parse_args(argv)
    if not args.skill_dir and not args.input:
        ap.error("至少指定 --skill-dir 或 --input")

    findings: list[Finding] = []
    if args.skill_dir:
        findings += check_skill_dir(Path(args.skill_dir).resolve(), args.platform, args.fix)
    if args.input:
        findings += check_input(Path(args.input).resolve(), args.fix)

    if args.json:
        print(json.dumps({"results": [f.as_dict() for f in findings]},
                         ensure_ascii=False, indent=2))
    else:
        print("=" * 68)
        print("prompt-optimizer 体检（人话版）" + (" · 已启用自动修复" if args.fix else ""))
        print("=" * 68)
        real = [f for f in findings if f.code != "structure_ok"]
        if not real:
            print("[通过] [怎么了] 没有发现问题")
            print("       [怎么改] 无需处理，可以直接打包上传")
        for f in real:
            print(f.render())
        print("-" * 68)
        print(f"共 {len(real)} 项；自动修复 {sum(1 for f in real if f.fixed)} 项")

    if any(f.level == "BLOCK" for f in findings):
        return 2
    if any(f.level == "WARN" for f in findings):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
