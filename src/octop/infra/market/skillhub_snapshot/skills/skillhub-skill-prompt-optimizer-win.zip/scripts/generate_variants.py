#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_variants.py — 一键生成三平台「可直接粘贴运行」的完整提示词
=====================================================================

对应 TRACE 扣分项
-----------------
R/功能完善性 4.0「自动生成成品提示词与上传包没有真正完成」
C/文档质量 4.8「自动产物中的提示词内容不能直接使用」
E/内容完整度 4.5「自动产出仍有占位内容」
E/开箱即用度 4.2「想直接拿到可用成品仍需补步骤」

本脚本把上游 storyboarder 的分镜表 + 角色档案库，按三平台原生语法渲染成
**完整提示词全文**，不再输出「由 SKILL.md 第 2 步生成」之类的占位内容。

依赖：Python 3.9+，仅标准库。
运行：
    python generate_variants.py --input storyboard.json --outdir ./out
    python generate_variants.py --demo --outdir ./out

输入结构见 templates/storyboard_input_template.json。
输出：
    prompt_variants_<project_id>.csv   主表（含完整提示词全文）
    prompt_variants_<project_id>.json  variants[]（prompt_full_text 为全文）
    full_prompts_<project_id>.md       按镜头分节、可直接复制粘贴
    parameter_cards_<project_id>.md    参数卡汇总
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# 平台能力上限：取自用户规格，执行时须按当期后台实际可选项复核
# ---------------------------------------------------------------------------
PLATFORM_LIMITS: dict[str, dict[str, Any]] = {
    "即梦": {"max_seconds": 30, "max_ref_images": 30, "max_ref_videos": 10,
             "max_ref_audios": 10, "supports_timestamps": True,
             "limit_note": "最多30图/10视频/10音频，单次最长30s（规格值，需当期回查）"},
    "可灵": {"max_seconds": 15, "max_ref_images": 7, "max_ref_videos": 2,
             "max_ref_audios": 0, "supports_timestamps": False,
             "limit_note": "单段5–15s，长镜需拆段续接（规格值，需当期回查）"},
    "Vidu": {"max_seconds": 10, "max_ref_images": 7, "max_ref_videos": 0,
             "max_ref_audios": 0, "supports_timestamps": False,
             "limit_note": "最多7张参考图锁角色（规格值，需当期回查）"},
}

# 负向提示词基线（与 references/platform-syntax.md 保持一致）
NEGATIVE_BASE: dict[str, str] = {
    "即梦": "多余手指、肢体畸变、脸部崩坏、五官漂移、双瞳、文字水印、logo、字幕、画面抖动、"
            "突然变焦、人物换装、发型突变、背景人群穿模、口型与台词不符、切镜点前后人物不一致",
    "可灵": "大幅肢体动作、快速转身、脸部变形、身份漂移、多人脸融合、模糊、低分辨率、过曝、"
            "水印、文字、字幕、镜头剧烈晃动、肢体穿插、服装变化、口型不同步",
    "Vidu": "角色一致性丢失、参考图特征弱化、面部闪烁、多角色特征串扰、动作幅度过大、背景变形、"
            "水印、字幕文字、音画不同步、口型错位",
}

PLATFORM_TAG = {"即梦": "JM", "可灵": "KL", "Vidu": "VD"}


# ---------------------------------------------------------------------------
# 输入校验：出错给「人话 + 可直接照做的修正步骤」，不静默、不只抛技术异常
# ---------------------------------------------------------------------------
class InputProblem(Exception):
    def __init__(self, message: str, how_to_fix: str) -> None:
        super().__init__(message)
        self.message = message
        self.how_to_fix = how_to_fix


def validate_input(cfg: dict[str, Any]) -> None:
    if not isinstance(cfg, dict):
        raise InputProblem("输入不是 JSON 对象", "请确认文件首字符是 { ，可对照 templates/storyboard_input_template.json")
    for key in ("project_id", "shots", "characters"):
        if key not in cfg:
            raise InputProblem(f"缺少必填字段 {key}",
                               f"在 JSON 顶层补上 \"{key}\"，格式见 templates/storyboard_input_template.json")
    if not isinstance(cfg["shots"], list) or not cfg["shots"]:
        raise InputProblem("shots 为空或不是数组",
                           "shots 至少要有 1 个镜头；可直接复制 templates/storyboard_input_template.json 里的 shots[0] 改写")
    if not isinstance(cfg["characters"], dict) or not cfg["characters"]:
        raise InputProblem("characters 为空或不是对象",
                           "每个角色写成 \"R01\": {\"appearance_anchor\": \"...\", \"ref_images\": [...]}")
    seen: set[str] = set()
    for i, shot in enumerate(cfg["shots"]):
        sid = shot.get("shot_id")
        if not sid:
            raise InputProblem(f"第 {i+1} 个镜头缺 shot_id", "给它一个唯一编号，例如 \"S001\"")
        if sid in seen:
            raise InputProblem(f"shot_id 重复：{sid}", "同一分镜表内 shot_id 必须唯一")
        seen.add(sid)
        if not isinstance(shot.get("seconds"), (int, float)) or shot["seconds"] <= 0:
            raise InputProblem(f"{sid} 的 seconds 不是正数", "把 seconds 改成大于 0 的数字，例如 8")
        if shot.get("difficulty", "Mid") not in ("High", "Mid", "Low"):
            raise InputProblem(f"{sid} 的 difficulty 非法", "只能用 High / Mid / Low")
        for rid in shot.get("role_ids", []):
            if rid not in cfg["characters"]:
                raise InputProblem(f"{sid} 引用了未定义的角色 {rid}",
                                   f"在 characters 里补上 \"{rid}\"，或把 role_ids 里的 {rid} 改成已定义的角色")
        for rid, ch in cfg["characters"].items():
            if not ch.get("appearance_anchor"):
                raise InputProblem(f"角色 {rid} 缺 appearance_anchor",
                                   "外貌锚点必须逐字来自角色档案库，不能留空；这是跨平台一致性的护栏")
    for p in cfg.get("target_platforms", ["即梦", "可灵", "Vidu"]):
        if p not in PLATFORM_LIMITS:
            raise InputProblem(f"不支持的目标平台：{p}",
                               f"target_platforms 只能用 {list(PLATFORM_LIMITS)}；其他平台请先补语法适配")


def demo_config() -> dict[str, Any]:
    """内置示例，供 --demo 一键跑通；全部标注为示例数据。"""
    return {
        "project_id": "demo-001",
        "fetch_date": "2026-11-12",
        "is_example": True,
        "example_notice": "示例数据，非真实项目；project_id 为占位符",
        "target_platforms": ["即梦", "可灵", "Vidu"],
        "resolution": "720p",
        "seed": 20261112,
        "characters": {
            "R01": {"name": "林岚", "priority": 1,
                    "appearance_anchor": "齐肩黑发、圆框眼镜、米白色风衣、左耳一枚小银环",
                    "ref_images": ["REF-001"]},
            "R02": {"name": "周砚", "priority": 2,
                    "appearance_anchor": "短发、深色高领毛衣、眉骨处一道浅疤",
                    "ref_images": ["REF-003"]},
        },
        "shots": [
            {
                "shot_id": "S001", "seconds": 8, "difficulty": "High",
                "role_ids": ["R01", "R02"],
                "scene": "雨夜的中医药展厅走廊，冷白顶灯与玻璃展柜反光",
                "shot_size": "中景转近景", "camera": "缓慢推轨",
                "lighting": "冷白顶光+玻璃反光", "style": "冷调纪录感、浅景深",
                "action": "并肩行走后抬手指向展柜，单一动作",
                "beats": [
                    {"at": 0, "text": "两人自走廊尽头并肩入画"},
                    {"at": 4, "text": "切近景，林岚抬手指向展柜"},
                    {"at": 8, "text": "定格于对视"},
                ],
                "dialogue": "这批药材的溯源记录，今天必须归档。",
                "audio": True, "lip_sync": True, "motion": "small",
                "approved": False,
            },
            {
                "shot_id": "S002", "seconds": 5, "difficulty": "Mid",
                "role_ids": ["R01"],
                "scene": "同一展厅，展柜特写，暖色射灯",
                "shot_size": "特写", "camera": "固定机位",
                "lighting": "暖色射灯+玻璃倒影", "style": "暖调特写、玻璃倒影",
                "action": "手指轻触玻璃，单一动作",
                "beats": [
                    {"at": 0, "text": "手指轻触展柜玻璃"},
                    {"at": 5, "text": "玻璃倒影中的侧脸"},
                ],
                "dialogue": "", "audio": False, "lip_sync": False,
                "motion": "small", "approved": True,
            },
        ],
    }


# ---------------------------------------------------------------------------
# 一致性护栏：参考图裁剪与长镜拆段，绝不静默删内容
# ---------------------------------------------------------------------------
def resolve_assets(shot: dict[str, Any], characters: dict[str, Any],
                   platform: str) -> tuple[list[dict[str, Any]], list[str]]:
    """按角色优先级收集参考图；超上限时裁剪并把裁剪记录写进备注。"""
    lim = PLATFORM_LIMITS[platform]
    items: list[dict[str, Any]] = []
    for rid in shot.get("role_ids", []):
        ch = characters[rid]
        for ref in ch.get("ref_images", []):
            items.append({"role_id": rid, "ref": ref,
                          "anchor": ch["appearance_anchor"],
                          "priority": ch.get("priority", 99)})
    for ref in shot.get("extra_ref_images", []):
        items.append({"role_id": "ENV", "ref": ref, "anchor": "",
                      "priority": 90})
    items.sort(key=lambda x: x["priority"])
    notes: list[str] = []
    cap = lim["max_ref_images"]
    if len(items) > cap:
        dropped = items[cap:]
        items = items[:cap]
        notes.append(
            f"[裁剪] 平台={platform} 上限={cap}张 保留={','.join(i['ref'] for i in items)} "
            f"裁掉={','.join(i['ref'] for i in dropped)} 原因=参考图数量上限；"
            f"裁剪内容不删除，原始清单已存于本行 ref_images_all 字段")
    return items, notes


def resolve_duration(shot: dict[str, Any], platform: str) -> tuple[list[dict[str, Any]], list[str]]:
    """平台不支持长镜时拆段续接，返回分段清单与适配损失说明。"""
    lim = PLATFORM_LIMITS[platform]
    seconds = int(shot["seconds"])
    notes: list[str] = []
    if seconds <= lim["max_seconds"]:
        return [{"part": shot["shot_id"], "seconds": seconds, "index": 0}], notes
    n = (seconds + lim["max_seconds"] - 1) // lim["max_seconds"]
    parts = []
    for i in range(n):
        s = min(lim["max_seconds"], seconds - i * lim["max_seconds"])
        if s <= 0:
            break
        parts.append({"part": f"{shot['shot_id']}-{chr(97+i)}", "seconds": s, "index": i})
    notes.append(
        f"[拆段] 原{shot['shot_id']} 时长{seconds}s → "
        f"{', '.join(p['part'] + '(' + str(p['seconds']) + 's)' for p in parts)}；"
        f"续接点=上一段末帧构图与光影，seed 保持不变；"
        f"原因={platform} 单段上限 {lim['max_seconds']}s（{lim['limit_note']}）")
    return parts, notes


def weights_for(items: list[dict[str, Any]]) -> str:
    roles = [i for i in items if i["role_id"] != "ENV"]
    if not roles:
        return "ENV:1.0"
    if len(roles) == 1:
        return f"{roles[0]['role_id']}:1.0"
    # 主角色 0.6，其余按优先级均分剩余权重
    main = roles[0]["role_id"]
    rest = 0.4 / max(1, len(roles) - 1)
    seg = [f"{main}:0.6"] + [f"{r['role_id']}:{round(rest,2)}" for r in roles[1:]]
    return ",".join(seg)


# ---------------------------------------------------------------------------
# 三平台原生语法渲染：产出完整、可直接粘贴的提示词全文
# ---------------------------------------------------------------------------
def render_jimeng(shot: dict[str, Any], cfg: dict[str, Any], items, parts, weights) -> str:
    anchors = "；".join(i["anchor"] for i in items if i["anchor"])
    beats = "；".join(f"第{b['at']}秒…{b['text']}" for b in shot.get("beats", []))
    refs = "；".join(f"参考图：{i['ref']}→role_id={i['role_id']}" for i in items)
    vids = shot.get("ref_videos") or []
    auds = shot.get("ref_audios") or []
    if vids:
        refs += "；" + "；".join(f"参考视频：{v}" for v in vids)
    if auds:
        refs += "；" + "；".join(f"参考音频：{a}" for a in auds)
    audio_on = bool(shot.get("audio"))
    dialogue = shot.get("dialogue", "")
    audio_block = (f"【音频】配音=开；对口型=开；台词=\"{dialogue}\"。"
                   if audio_on and dialogue else
                   f"【音频】配音={'开' if audio_on else '关'}；对口型={'开' if shot.get('lip_sync') else '关'}。")
    total = shot["seconds"]
    return (
        f"【镜头 {shot['shot_id']}｜时长 {total}s】\n"
        f"{shot.get('scene','')}。\n"
        f"{anchors}。\n"
        f"{beats}。\n"
        f"【参考资产】{refs}。\n"
        f"{audio_block}\n"
        f"【参数】时长={total}s；分辨率={cfg.get('resolution','720p')}；"
        f"seed={cfg.get('seed','待核实')}；运动强度={shot.get('motion','small')}；"
        f"参考图权重={weights}。"
    )


def render_kling(shot: dict[str, Any], cfg: dict[str, Any], items, parts, weights) -> str:
    anchors = "；".join(f"role_id={i['role_id']}：{i['anchor']}" for i in items if i["anchor"])
    refs = "；".join(f"{i['ref']}→{i['role_id']}主体绑定" for i in items)
    vids = shot.get("ref_videos") or []
    if vids:
        refs += "；" + "；".join(f"{v}→运动参考" for v in vids)
    neg = NEGATIVE_BASE["可灵"]
    audio_on = "on" if shot.get("audio") else "off"
    duration_note = (f"；拆段={', '.join(p['part'] for p in parts)}"
                     if len(parts) > 1 else "")
    return (
        f"[景别] {shot.get('shot_size','中景')}｜[运镜] {shot.get('camera','固定机位')}｜"
        f"[光影] {shot.get('lighting','自然光')}\n"
        f"[主体] {anchors}\n"
        f"[动作] {shot.get('action','单一动作')}\n"
        f"[参考组] Elements：{refs}\n"
        f"[运动幅度] {'小' if shot.get('motion','small')=='small' else '中'}\n"
        f"[时长] {shot['seconds']}s（单段 ≤ {PLATFORM_LIMITS['可灵']['max_seconds']}s{duration_note}）\n"
        f"\n--负向提示--\n{neg}\n"
        f"\n--参数--\n"
        f"分辨率={cfg.get('resolution','720p')}；seed={cfg.get('seed','待核实')}；"
        f"运动强度={shot.get('motion','small')}；参考图权重={weights}；音频={audio_on}"
    )


def render_vidu(shot: dict[str, Any], cfg: dict[str, Any], items, parts, weights) -> str:
    refs = "；".join(f"{i['ref']}→role_id={i['role_id']} 权重="
                    f"{dict((s.split(':')[0], s.split(':')[1]) for s in weights.split(',')).get(i['role_id'],'0.3')}"
                    for i in items)
    audio_on = "on" if shot.get("audio") else "off"
    lip = "on" if shot.get("lip_sync") else "off"
    return (
        f"[主体参考] {refs}\n"
        f"[风格] {shot.get('style','写实纪录感')}\n"
        f"[运动] {shot.get('camera','固定机位')}，{shot.get('action','单一动作')}\n"
        f"[参数] 模型=Q2-turbo；时长={shot['seconds']}s；"
        f"分辨率={cfg.get('resolution','720p')}；seed={cfg.get('seed','待核实')}；"
        f"movement_amplitude={shot.get('motion','small')}\n"
        f"[音频] generate_audio={audio_on}；口型同步={lip}\n"
        f"\n--负向提示--\n{NEGATIVE_BASE['Vidu']}\n"
        f"\n--备注-- 外貌锚点由参考图锁定，正向提示不重复堆砌；"
        f"锚点原文存于参数卡，未改写。模型档位以当期后台可选为准。"
    )


RENDERERS = {"即梦": render_jimeng, "可灵": render_kling, "Vidu": render_vidu}


def build_variant(shot: dict[str, Any], cfg: dict[str, Any], platform: str) -> dict[str, Any]:
    items, notes = resolve_assets(shot, cfg["characters"], platform)
    parts, dnotes = resolve_duration(shot, platform)
    notes += dnotes
    weights = weights_for(items)
    prompt = RENDERERS[platform](shot, cfg, items, parts, weights)
    if len(parts) > 1 and platform == "即梦":
        notes.append("[切镜点] 长镜一次跑完，已在提示词中用「第N秒…」标清切镜点")
    params = {
        "duration": shot["seconds"], "resolution": cfg.get("resolution", "720p"),
        "seed": cfg.get("seed", "待核实"), "motion": shot.get("motion", "small"),
        "ref_weights": weights, "audio": bool(shot.get("audio")),
        "lip_sync": bool(shot.get("lip_sync")),
        "model": {"即梦": "Seedance 2.5", "可灵": "Kling 3.0", "Vidu": "Q2-turbo"}[platform],
        "negative_prompt": NEGATIVE_BASE[platform],
        "segments": parts,
    }
    return {
        "shot_id": shot["shot_id"], "platform": platform,
        "model": params["model"], "resolution": params["resolution"],
        "duration": params["duration"], "seed": params["seed"],
        "motion": params["motion"], "audio": params["audio"],
        "lip_sync": params["lip_sync"], "difficulty": shot.get("difficulty", "Mid"),
        "role_ids": shot.get("role_ids", []),
        "ref_images": [i["ref"] for i in items],
        "ref_images_all": [i["ref"] for i in
                           resolve_assets(shot, cfg["characters"], "即梦")[0]],
        "appearance_anchor": "；".join(
            cfg["characters"][r]["appearance_anchor"] for r in shot.get("role_ids", [])),
        "prompt_full_text": prompt,
        "negative_prompt": params["negative_prompt"],
        "parameter_card": params,
        "ref_weights": weights,
        "prompt_id": f"PO-{cfg['project_id']}-{shot['shot_id']}-{PLATFORM_TAG[platform]}-v1",
        "notes": " | ".join(notes) if notes else "无适配损失",
        "is_example": bool(cfg.get("is_example", False)),
        "paste_ready": True,
    }


# ---------------------------------------------------------------------------
# 输出
# ---------------------------------------------------------------------------
CSV_FIELDS = [
    "shot_id", "平台", "模型/档位", "提示词(全文，可直接粘贴)", "负向提示词",
    "参考图编号", "参数(时长/分辨率/seed/运动/音频)", "prompt_id",
    "单次成本(积分或元)", "单价来源URL", "抓取日期", "预估重试", "小计", "备注",
]


def param_brief(v: dict[str, Any]) -> str:
    return (f"{v['duration']}s / {v['resolution']} / {v['seed']} / {v['motion']} / "
            f"音频{'开' if v['audio'] else '关'}·口型{'开' if v['lip_sync'] else '关'}")


def write_outputs(variants: list[dict[str, Any]], cfg: dict[str, Any],
                  outdir: Path) -> list[Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    pid = cfg["project_id"]
    fetch_date = cfg.get("fetch_date", "待核实")
    out: list[Path] = []

    # 成本列由 estimate_cost.py 回填；此处保持「待回填」而非伪造数字
    csv_path = outdir / f"prompt_variants_{pid}.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        w.writeheader()
        for v in variants:
            w.writerow({
                "shot_id": v["shot_id"], "平台": v["platform"],
                "模型/档位": v["model"], "提示词(全文，可直接粘贴)": v["prompt_full_text"],
                "负向提示词": v["negative_prompt"],
                "参考图编号": ",".join(v["ref_images"]),
                "参数(时长/分辨率/seed/运动/音频)": param_brief(v),
                "prompt_id": v["prompt_id"],
                "单次成本(积分或元)": "待回填（由 estimate_cost.py 生成）",
                "单价来源URL": "待回填（见 references/pricing-fields.md）",
                "抓取日期": fetch_date, "预估重试": "1.2~1.5",
                "小计": "待回填（成本区间）", "备注": v["notes"],
            })
    out.append(csv_path)

    json_path = outdir / f"prompt_variants_{pid}.json"
    payload = {
        "summary": {
            "project_id": pid, "fetch_date": fetch_date,
            "is_example": bool(cfg.get("is_example", False)),
            "shot_count": len(cfg["shots"]),
            "variant_count": len(variants),
            "paste_ready": True,
            "placeholder_count": 0,
            "notice": "所有 prompt_full_text 均为完整可粘贴文本；成本列由 estimate_cost.py 回填",
        },
        "variants": variants,
    }
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    out.append(json_path)

    md_path = outdir / f"full_prompts_{pid}.md"
    lines = [
        f"# 三平台完整提示词（{pid}）", "",
        f"> 生成日期：{fetch_date}　生成方式：`scripts/generate_variants.py`",
        "> 以下提示词均为**完整文本，可直接复制粘贴到对应平台运行**，无占位内容。",
        "> 成本列请运行 `scripts/estimate_cost.py` 回填；单价须当期回查。",
    ]
    if cfg.get("is_example"):
        lines += ["> ⚠️ 本文件为**示例数据**，非真实项目；`demo-001` 为示例占位符。"]
    lines.append("")
    for shot in cfg["shots"]:
        lines += [f"## {shot['shot_id']}（{shot['seconds']}s，难度 {shot.get('difficulty','Mid')}）", ""]
        lines += [f"**外貌锚点（逐字来自角色档案库，禁止改写）**："
                  + "；".join(cfg["characters"][r]["appearance_anchor"]
                             for r in shot.get("role_ids", [])), ""]
        for v in [x for x in variants if x["shot_id"] == shot["shot_id"]]:
            lines += [f"### {v['platform']} · {v['model']} · `{v['prompt_id']}`", "",
                      "```text", v["prompt_full_text"], "```", "",
                      f"- **负向提示词**：{v['negative_prompt']}",
                      f"- **参数卡**：{param_brief(v)}；参考图权重={v['ref_weights']}",
                      f"- **参考图**：{', '.join(v['ref_images'])}",
                      f"- **备注**：{v['notes']}", ""]
        lines += ["---", ""]
    md_path.write_text("\n".join(lines), encoding="utf-8")
    out.append(md_path)

    card_path = outdir / f"parameter_cards_{pid}.md"
    cards = [f"# 参数卡汇总（{pid}）", "",
             "| shot_id | 平台 | 时长 | 分辨率 | seed | 运动 | 音频 | 口型 | 参考图权重 | prompt_id |",
             "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    for v in variants:
        cards.append(
            f"| {v['shot_id']} | {v['platform']} | {v['duration']}s | {v['resolution']} | "
            f"{v['seed']} | {v['motion']} | {'on' if v['audio'] else 'off'} | "
            f"{'on' if v['lip_sync'] else 'off'} | {v['ref_weights']} | `{v['prompt_id']}` |")
    card_path.write_text("\n".join(cards) + "\n", encoding="utf-8")
    out.append(card_path)
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="生成三平台可直接粘贴的完整提示词")
    ap.add_argument("--input", help="storyboard JSON 路径")
    ap.add_argument("--demo", action="store_true", help="用内置示例跑通")
    ap.add_argument("--outdir", default="./out", help="输出目录")
    args = ap.parse_args(argv)
    if not args.input and not args.demo:
        ap.error("需要 --input <file.json> 或 --demo")
    try:
        if args.demo:
            cfg = demo_config()
        else:
            p = Path(args.input)
            if not p.is_file():
                raise InputProblem(f"找不到输入文件：{p}",
                                   "确认路径是否正确；可直接用 --demo 先跑通看输出长什么样")
            cfg = json.loads(p.read_text(encoding="utf-8"))
        validate_input(cfg)
        platforms = cfg.get("target_platforms", list(PLATFORM_LIMITS))
        variants = [build_variant(s, cfg, p) for s in cfg["shots"] for p in platforms]
        paths = write_outputs(variants, cfg, Path(args.outdir))
    except InputProblem as e:
        print(f"[怎么了] {e.message}", file=sys.stderr)
        print(f"[怎么改] {e.how_to_fix}", file=sys.stderr)
        print("[提示] 可先运行 python scripts/doctor.py --input <你的文件> 自动定位并尝试修复", file=sys.stderr)
        return 2
    except (OSError, json.JSONDecodeError, KeyError, ValueError) as e:
        print(f"[怎么了] 读取或写出失败：{e}", file=sys.stderr)
        print("[怎么改] 确认 JSON 是 UTF-8 无 BOM、输出目录可写；再运行一次", file=sys.stderr)
        return 2

    print(f"[完成] project_id={cfg['project_id']} 镜头={len(cfg['shots'])} 变体={len(variants)}")
    print(f"[完成] 全部变体 paste_ready=True，提示词为完整文本，占位内容 0 处")
    for p in paths:
        print(f"       {p}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
