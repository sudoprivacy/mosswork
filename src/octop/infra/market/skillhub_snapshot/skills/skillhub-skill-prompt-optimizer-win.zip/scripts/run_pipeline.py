#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_pipeline.py — 一键跑完全流程，直接产出可上传的成品
=======================================================

对应 TRACE 扣分项
-----------------
E/开箱即用度 4.2「想直接拿到可用成品仍需补步骤和整理内容」
R/运行稳定性 4.3「缺少自动恢复和完整验证保障」
R/功能完善性 4.0「很多最终步骤仍要手工处理」

一条命令完成：输入校验 → 三平台完整提示词 → 成本区间 → 双平台 ZIP → 规范自检 → 交付清单。
任一步失败都会给出「怎么了 / 怎么改」，并保留已完成的中间产物，不必从头再来。

依赖：Python 3.9+，仅标准库。
运行：
    python run_pipeline.py --demo --outdir ./dist
    python run_pipeline.py --input storyboard.json --outdir ./dist

产物（全部落在 --outdir）：
    pipeline_input_<project_id>.json        合并后的输入（可复核）
    prompt_variants_<project_id>.csv/.json  三平台变体（提示词全文）
    full_prompts_<project_id>.md            可直接粘贴的提示词
    parameter_cards_<project_id>.md         参数卡汇总
    workbuddy_upload_*.zip / skillhub_upload_*.zip   双平台上传包
    manifest_*.json                        逐文件哈希清单
    DELIVERY_MANIFEST.md                   人话版交付清单
"""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL_DIR = HERE.parent


def merged_demo() -> dict:
    """把两个脚本的示例配置合成一份输入，保证一键跑通。"""
    sys.path.insert(0, str(HERE))
    import generate_variants as gv  # noqa: E402
    import estimate_cost as ec  # noqa: E402
    a, b = gv.demo_config(), ec.demo_config()
    a["rates"] = b["rates"]
    a["assumed_resolution_factors"] = b["assumed_resolution_factors"]
    a["assumed_factor_notice"] = b["assumed_factor_notice"]
    a["pipeline_notice"] = "由 run_pipeline.py --demo 合并生成，示例数据，非真实项目"
    return a


def run_step(name: str, script: str, argv: list[str], outdir: Path) -> tuple[bool, str]:
    cmd = [sys.executable, str(HERE / script)] + argv
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=120)
    except subprocess.TimeoutExpired:
        return False, "这一步超过 120 秒未结束"
    out = (r.stdout or "").strip()
    err = (r.stderr or "").strip()
    log = outdir / f"step_{script.replace('.py','')}.log"
    log.write_text(f"$ {' '.join(cmd)}\n\n[stdout]\n{out}\n\n[stderr]\n{err}\n",
                   encoding="utf-8")
    ok = r.returncode == 0
    return ok, (out if ok else (err or out or f"退出码 {r.returncode}"))


def merge_deliverables(outdir: Path, pid: str) -> tuple[bool, str]:
    """把成本结果回填进主表，产出「无占位内容」的最终交付物。"""
    pj = outdir / f"prompt_variants_{pid}.json"
    cj = outdir / f"cost_estimate_{pid}.json"
    csvp = outdir / f"prompt_variants_{pid}.csv"
    for f in (pj, cj, csvp):
        if not f.is_file():
            return False, f"缺少待合并文件 {f.name}"
    pv = json.loads(pj.read_text(encoding="utf-8"))
    ce = json.loads(cj.read_text(encoding="utf-8"))
    costs = ce["costs"]
    index = {(c["shot_id"], c["platform"]): c for c in costs}

    # 1) 合并机器可读 JSON：variants[] + costs[] + rerun_rules[]
    merged = {
        "summary": {**pv["summary"], **{
            k: ce["summary"][k] for k in ("scope_notice", "coverage",
                                          "comparison_warning", "is_lower_bound",
                                          "skipped_shots", "fallback",
                                          "no_single_point_guarantee")
            if k in ce["summary"]}},
        "variants": pv["variants"],
        "costs": costs,
        "rerun_rules": ce["rerun_rules"],
        "qc_items": ce["qc_items"],
        "three_way_comparison": ce["three_way_comparison"],
        "cheapest_plan": ce["cheapest_plan"],
        "hidden_costs": ce["hidden_costs"],
        "price_card": ce["price_card"],
    }
    merged["summary"]["placeholder_count"] = 0
    pj.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")

    # 2) 回填主表 CSV 的成本列
    with csvp.open("r", encoding="utf-8-sig", newline="") as f:
        rd = csv.DictReader(f)
        fields = rd.fieldnames or []
        rows = list(rd)
    for row in rows:
        c = index.get((row.get("shot_id", ""), row.get("平台", "")))
        if not c:
            continue
        sc = c["single_cost"]
        row["单次成本(积分或元)"] = (f"{sc} {c.get('unit','')}".strip()
                                    if isinstance(sc, (int, float)) else "待核实（未核实）")
        row["单价来源URL"] = c.get("source_url", "未找到可靠来源")
        row["抓取日期"] = c.get("fetch_date", "待核实")
        row["预估重试"] = "1.2~1.5"
        lo, hi = c.get("subtotal_low"), c.get("subtotal_high")
        row["小计"] = (f"{lo}~{hi} {c.get('unit','')}".strip()
                       if isinstance(lo, (int, float)) and isinstance(hi, (int, float))
                       else "待核实（未核实）")
        extra = f" | 口径={c.get('verify_status','')} | {c.get('note','')}".rstrip(" |")
        row["备注"] = (row.get("备注", "") + extra).strip(" |")
    with csvp.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

    # 3) 成本总表（副表）
    s = ce["summary"]
    lines = [f"# 成本总表 · {pid}", "",
             f"> 抓取日期：{s.get('fetch_date','待核实')}　口径：{s.get('coverage','')}",
             f"> {s.get('scope_notice','')}", "",
             "| 平台/档位 | 画质 | 基础成本 | 含重试成本(区间) | 覆盖 | 是否含音频 | 会员摊销 | 推荐度 |",
             "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for p, v in ce["three_way_comparison"]["by_platform"].items():
        if isinstance(v, dict) and isinstance(v.get("range"), list):
            lines.append(
                f"| {p} | 720p | {v['base_cost']} | [{v['range'][0]}, {v['range'][1]}] | "
                f"{v.get('coverage','')} | 见主表 | 待核实 | "
                f"{'高（口径完整）' if not v.get('is_lower_bound') else '中（含未核实行，数值为下界）'} |")
        else:
            lines.append(f"| {p} | 720p | 待核实 | 待核实（未核实） | 0 条已核实 | 见主表 | 待核实 | 暂不推荐 |")
    lines += ["", f"- 项目合计（仅已核实行）：{s.get('verified_base_cost','待核实')}；"
              f"含重试区间：{s.get('total_range','待核实')}",
              f"- {s.get('comparison_warning','')}", "",
              "## 隐性成本", ""]
    lines += [f"- {h['item']}：{h['note']}" for h in ce["hidden_costs"]]
    lines += ["", "## 最省方案", ""]
    for i, step in enumerate(ce["cheapest_plan"]["steps"], 1):
        lines.append(f"{i}. {step}")
    lines += ["", f"- 540p 试跑成本（假设系数）：{ce['cheapest_plan']['trial_540p_cost']}；"
              f"{ce['cheapest_plan']['trial_notice']}",
              f"- 过审镜头升级重跑：{ce['cheapest_plan']['approved_upgrade_cost']}；"
              f"全量重跑：{ce['cheapest_plan']['full_rerun_cost']}", ""]
    (outdir / f"cost_summary_{pid}.md").write_text("\n".join(lines), encoding="utf-8")
    return True, (f"已回填 {len(rows)} 行主表；合并 JSON 含 variants={len(pv['variants'])} "
                  f"costs={len(costs)} rerun_rules={len(ce['rerun_rules'])}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="一键产出双平台上传包与全套交付物")
    ap.add_argument("--input", help="storyboard JSON（含 rates）")
    ap.add_argument("--demo", action="store_true", help="用内置示例跑通全流程")
    ap.add_argument("--outdir", default="./dist", help="输出目录")
    ap.add_argument("--skip-package", action="store_true", help="只出提示词与成本，不打包")
    args = ap.parse_args(argv)
    if not args.input and not args.demo:
        ap.error("需要 --input <file.json> 或 --demo")

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    # 1) 准备输入
    if args.demo:
        cfg = merged_demo()
        input_path = outdir / f"pipeline_input_{cfg['project_id']}.json"
        input_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    else:
        input_path = Path(args.input).resolve()
        if not input_path.is_file():
            print(f"[怎么了] 找不到输入文件 {input_path}")
            print("[怎么改] 确认路径；或先用 --demo 跑通看输出长什么样")
            return 2
        try:
            cfg = json.loads(input_path.read_text(encoding="utf-8-sig"))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            print(f"[怎么了] 输入 JSON 读不出来：{e}")
            print("[怎么改] 用 UTF-8 无 BOM 重新保存；模板见 templates/storyboard_input_template.json")
            return 2
    pid = cfg.get("project_id", "unnamed")

    steps: list[tuple[str, str, list[str]]] = [
        ("输入体检", "doctor.py", ["--input", str(input_path), "--json"]),
        ("生成三平台完整提示词", "generate_variants.py",
         ["--input", str(input_path), "--outdir", str(outdir)]),
        ("估算成本区间", "estimate_cost.py",
         ["--input", str(input_path), "--outdir", str(outdir)]),
    ]
    results: list[tuple[str, bool, str]] = []
    print("=" * 68)
    print(f"prompt-optimizer 一键流水线 · project_id={pid}")
    print("=" * 68)
    for name, script, sargv in steps:
        ok, msg = run_step(name, script, sargv, outdir)
        results.append((name, ok, msg))
        print(f"[{'完成' if ok else '中断'}] {name}")
        for line in msg.splitlines()[:6]:
            print(f"        {line}")
        if not ok:
            print(f"[怎么了] 「{name}」没跑通，上面是原因")
            print(f"[怎么改] 看 {outdir / ('step_' + script.replace('.py','') + '.log')}；"
                  f"修好后可直接重跑本命令，已完成的产物会保留")
            return 2

    # 1.5) 把成本回填进主表，消除所有「待回填」占位内容
    ok, msg = merge_deliverables(outdir, pid)
    if not ok:
        print(f"[怎么了] 合并交付物失败：{msg}")
        print("[怎么改] 重跑本命令；若仍失败，看 step_generate_variants.log 与 step_estimate_cost.log")
        return 2
    results.append(("合并回填主表与成本总表", True, msg))
    print("[完成] 合并回填主表与成本总表")
    for line in msg.splitlines():
        print(f"        {line}")

    # 1.6) 最后才打包，确保包内是最终版文档，且不含运行时产物
    if not args.skip_package:
        name, script, sargv = (
            "构建双平台上传包", "build_upload_package.py",
            ["--source", str(SKILL_DIR), "--outdir", str(outdir),
             "--project-id", pid, "--target", "both"])
        ok, pmsg = run_step(name, script, sargv, outdir)
        results.append((name, ok, pmsg))
        print(f"[{'完成' if ok else '中断'}] {name}")
        for line in pmsg.splitlines()[:6]:
            print(f"        {line}")
        if not ok:
            print(f"[怎么了] 打包没跑完：{pmsg}")
            print("[怎么改] 看 step_build_upload_package.log；修好后重跑本命令")
            return 2

    # 2) 汇总交付清单
    today = date.today().isoformat()
    produced = sorted(p.name for p in outdir.iterdir() if p.is_file())
    lines = [
        f"# 交付清单 · {pid}", "",
        f"> 生成日期：{today}　生成方式：`scripts/run_pipeline.py`",
        "> 本清单中的提示词均为完整可粘贴文本；成本为含重试系数的区间，不是单点报价。", "",
        "## 已完成的步骤", "",
        "| 步骤 | 结果 |", "| --- | --- |",
    ]
    lines += [f"| {n} | {'完成' if ok else '失败'} |" for n, ok, _ in results]
    lines += ["", "## 产物文件", "", "| 文件 | 用途 |", "| --- | --- |"]
    usage = {
        "prompt_variants": "最终主表（提示词全文 + 已回填成本）/ 机器可读 JSON（variants+ costs+ rerun_rules）",
        "full_prompts": "按镜头分节、可直接复制粘贴的完整提示词",
        "parameter_cards": "参数卡汇总",
        "cost_rows": "逐镜逐平台成本明细（合并前）",
        "cost_estimate": "成本估算机器可读结果（含统计口径与三档对比）",
        "cost_summary": "成本总表副表（含隐性成本与最省方案）",
        "workbuddy_upload": "WorkBuddy 开放平台上传 ZIP（SKILL.md 在 prompt-optimizer/ 下）",
        "skillhub_upload": "SkillHub 上传 ZIP（SKILL.md 在包根）",
        "manifest": "逐文件 SHA-256 清单与包体自检结果",
        "pipeline_input": "合并后的输入，供复核",
        "DELIVERY_MANIFEST": "本清单",
        "step_": "各步骤原始日志",
    }
    for fn in produced:
        u = next((v for k, v in usage.items() if fn.startswith(k)), "辅助产物")
        lines.append(f"| `{fn}` | {u} |")
    lines += [
        "", "## 上传前必做", "",
        "1. 替换 SKILL.md 中的 `REPLACE_WITH_YOUR_UNIQUE_SLUG` / "
        "`REPLACE_WITH_AUTHOR_OR_ORG` / `REPLACE_WITH_LICENSE` / `REPLACE_WITH_CATEGORY`。",
        "2. 重新联网回查三平台当期定价，更新 `references/pricing-fields.md` 并标注新的抓取日期。",
        "3. SkillHub 侧先跑 `skillhub publish <解压目录> --dry-run`；WorkBuddy 侧在开放平台上传 ZIP。",
        "4. 平台审核由用户本人完成，本脚本不代替审核、不承诺上架成功。", "",
        "## 口径提醒", "",
        "- 成本汇总**仅含已核实费率的镜头**，未核实镜头整行标「待核实」且不计入，因此该数值是**下界**，不是全量报价。",
        "- 按画质三档对比使用工程假设系数，标「非官方、待核实」，只作敏感性分析，不作报价。",
    ]
    if cfg.get("is_example"):
        lines += ["", "> ⚠️ 本次为 `--demo` 示例数据，`demo-001` 为占位符，非真实项目、非真实扣费记录。"]
    (outdir / "DELIVERY_MANIFEST.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("-" * 68)
    print(f"[完成] 全部 {len(results)} 步通过；产物 {len(produced)+1} 个，位于 {outdir}")
    print(f"[完成] 交付清单：{outdir / 'DELIVERY_MANIFEST.md'}")
    print("[必做] 上传前替换占位符并重新回查定价（详见交付清单）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
