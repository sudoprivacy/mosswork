#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prompt-optimizer / 成本估算脚本
================================

用途
----
按「起步积分 + 每秒积分 × 秒数」逐镜估算三平台生成成本，输出含重试系数的
**成本区间**（不给单点）、三档对比、最省方案、隐性成本清单与机器可读结果。

依赖
----
Python 3.9+，仅使用标准库（argparse / csv / json / pathlib / datetime / typing）。
无第三方包、无网络请求、不读取任何账号凭证。

运行示例
--------
    # 1) 用内置示例数据跑通（示例 project_id=demo-001，非真实项目）
    python estimate_cost.py --demo --outdir ./out

    # 2) 用真实分镜与当期回查的单价配置
    python estimate_cost.py --input shots.json --outdir ./out

输入 JSON 结构（--input）
------------------------
{
  "project_id": "demo-001",
  "fetch_date": "2026-11-11",
  "assumed_resolution_factors": {"540p": 0.6, "720p": 1.0, "1080p": 1.8},
  "rates": [
    {
      "platform": "可灵", "model": "Kling 3.0", "resolution": "720p",
      "audio_mode": "native",              // none | native | voice
      "start_credits": 0.0,
      "per_second_credits": 9.0,           // 为 null 表示「待核实」
      "per_second_cny": null,              // 按时计价平台用；与积分二选一
      "audio_extra": 0.0,                  // null 表示「待核实」
      "resolution_factor": 1.0,
      "member_discount": 1.0,
      "source_url": "https://...",
      "fetch_date": "2026-11-11",
      "verify_status": "已核实-官方页文本快照",
      "note": "..."
    }
  ],
  "shots": [
    {
      "shot_id": "S001", "seconds": 8, "difficulty": "High",
      "resolution": "720p", "audio": true, "lip_sync": true,
      "approved": false,
      "role_ids": ["R01", "R02"], "ref_images": ["REF-001", "REF-003"],
      "seed": 20261111
    }
  ]
}

输出
----
    <outdir>/cost_rows_<project_id>.csv       逐镜逐平台成本行
    <outdir>/cost_estimate_<project_id>.json  costs[] / rerun_rules[] / summary
                                              / three_way_comparison / cheapest_plan
                                              / hidden_costs / price_card
    本脚本**不覆盖** generate_variants.py 的主表；两者由 run_pipeline.py 合并成
    最终的 prompt_variants_<project_id>.csv / .json（含完整提示词 + 成本区间）。

质量红线
--------
1. 任何 verify_status 含「待核实」「已过期」「未找到」的费率，成本一律输出
   字符串 "待核实"，不参与数值汇总，绝不折算成 0 或任何确定值。
2. 成本一律输出区间 [低系数, 高系数]，额外给「按难度加权参考值」但明确标注
   为参考、非单点报价。
3. 假设性分辨率系数（assumed_resolution_factors）只用于敏感性对比，输出中
   带 assumed=true 与「非官方，待核实」标记。
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import date
from pathlib import Path
from typing import Any

# 用户规格给定：High 1.5 / Mid 1.3 / Low 1.2
DIFFICULTY_FACTOR: dict[str, float] = {"High": 1.5, "Mid": 1.3, "Low": 1.2}
RANGE_LOW = 1.2   # 全量区间下界
RANGE_HIGH = 1.5  # 全量区间上界

UNVERIFIED = "待核实"
UNVERIFIED_MARKERS = ("待核实", "已过期", "未找到", "未核实")

# 对应 TRACE「输出准确性 4.6：少数成本比较方式容易让人误解，仍需注意统计口径」
SCOPE_NOTICE = (
    "统计口径：本数值只汇总「单价已核实」的镜头；单价待核实的镜头整行标「待核实」且不计入，"
    "因此该数值是下界而非全量报价。跨比较前必须先把两边口径补齐到同一覆盖范围，"
    "不得直接拿覆盖不同的两列数字比大小。"
)

# 质检五项
QC_ITEMS = ("人物一致性", "口型同步", "动作连贯", "光影合理", "无水印文字")

# 废片原因 → 重跑规则（与 references/platform-syntax.md 第六节一致）
RERUN_RULES: list[dict[str, str]] = [
    {"qc_item": "人物一致性", "cause": "参考图权重不足 / 外貌锚点被改写",
     "action": "核对锚点逐字一致；主角色权重上调；补负向词「身份漂移、脸部变形」",
     "param_change": "ref_weights 主角色 +0.1；motion 下调", "prompt_id": "升级"},
    {"qc_item": "口型同步", "cause": "未开音频/口型开关或台词过长",
     "action": "开启配音对口型；压缩单句台词；补负向词「口型不同步」",
     "param_change": "audio=on；lip_sync=on", "prompt_id": "升级"},
    {"qc_item": "动作连贯", "cause": "运动幅度过大 / 单段过长",
     "action": "下调运动幅度；拆短镜头续接；补负向词「大幅肢体动作、快速转身」",
     "param_change": "motion=small；duration 减半", "prompt_id": "升级"},
    {"qc_item": "光影合理", "cause": "光影描述缺失或多光源冲突",
     "action": "前置单一光影指令块", "param_change": "无", "prompt_id": "升级"},
    {"qc_item": "无水印文字", "cause": "负向词遗漏 / 会员去水印权益未生效",
     "action": "补负向词「水印、文字、字幕」；核对会员权益",
     "param_change": "检查会员档位", "prompt_id": "升级"},
]

HIDDEN_COSTS: list[dict[str, str]] = [
    {"item": "废片重跑", "note": "已含于 [1.2, 1.5] 重试区间"},
    {"item": "升分辨率重跑", "note": "仅过审镜头二次计费；见 cheapest_plan"},
    {"item": "会员月费摊销", "note": "按当月实际生成量分摊；会员折扣口径须当期回查，标待核实"},
    {"item": "人工筛选工时", "note": "五项质检打分 + 素材回看；工时单价须用户给定，标待核实"},
]


# ---------------------------------------------------------------------------
# 示例数据：仅在 --demo 时使用，全部标注为示例；价格取自 2026-11-11 回查
# ---------------------------------------------------------------------------
def demo_config() -> dict[str, Any]:
    return {
        "project_id": "demo-001",
        "fetch_date": "2026-11-11",
        "is_example": True,
        "example_notice": "示例数据，非真实项目、非真实扣费记录；project_id 为示例占位符",
        "assumed_resolution_factors": {"540p": 0.6, "720p": 1.0, "1080p": 1.8},
        "assumed_factor_notice": "工程假设系数，非官方数据，待核实；仅用于敏感性对比，不作报价",
        "rates": [
            {
                "platform": "即梦", "model": "Seedance 2.5", "resolution": "720p",
                "audio_mode": "native", "start_credits": None,
                "per_second_credits": None, "per_second_cny": None,
                "audio_extra": None, "resolution_factor": 1.0, "member_discount": 1.0,
                "source_url": "https://jimeng.jianying.com/tools/jimeng-seedance-price",
                "fetch_date": "2026-11-11",
                "verify_status": "待核实 / 已过期-禁止使用",
                "note": "活动 10月31日至11月5日 23:59 已截止，¥0.16/秒 不得作为当期价",
            },
            {
                "platform": "可灵", "model": "Kling 3.0", "resolution": "720p",
                "audio_mode": "none", "start_credits": 0.0,
                "per_second_credits": 6.0, "per_second_cny": None,
                "audio_extra": 0.0, "resolution_factor": 1.0, "member_discount": 1.0,
                "source_url": "https://klingai.com/quickstart/klingai-video-3-model-user-guide",
                "fetch_date": "2026-11-11",
                "verify_status": "已核实-官方页文本快照",
                "note": "3.0 Video-No Native Audio 720p = 6 Credits/s；以后台实扣为准",
            },
            {
                "platform": "可灵", "model": "Kling 3.0", "resolution": "720p",
                "audio_mode": "native", "start_credits": 0.0,
                "per_second_credits": 9.0, "per_second_cny": None,
                "audio_extra": 0.0, "resolution_factor": 1.0, "member_discount": 1.0,
                "source_url": "https://klingai.com/quickstart/klingai-video-3-model-user-guide",
                "fetch_date": "2026-11-11",
                "verify_status": "已核实-官方页文本快照",
                "note": "3.0 Video-Native Audio 720p = 9 Credits/s；音频加价已含在费率",
            },
            {
                "platform": "Vidu", "model": "Q2-turbo", "resolution": "720p",
                "audio_mode": "none", "start_credits": 15.0,
                "per_second_credits": 5.0, "per_second_cny": None,
                "audio_extra": 0.0, "resolution_factor": 1.0, "member_discount": 1.0,
                "source_url": "https://platform.vidu.cn/docs/overview/pricing",
                "fetch_date": "2026-11-11",
                "verify_status": "已核实-官方页文本快照",
                "note": "15积分起，每秒+5积分；音频加价待核实，本行按 0 计并标注",
            },
            {
                "platform": "Vidu", "model": "Q2-turbo", "resolution": "720p",
                "audio_mode": "native", "start_credits": 15.0,
                "per_second_credits": 5.0, "per_second_cny": None,
                "audio_extra": None, "resolution_factor": 1.0, "member_discount": 1.0,
                "source_url": "https://platform.vidu.cn/docs/overview/pricing",
                "fetch_date": "2026-11-11",
                "verify_status": "已核实-官方页文本快照",
                "note": "音频加价未在官方快照中取到，标待核实 → 该行成本整体输出待核实",
            },
        ],
        "shots": [
            {"shot_id": "S001", "seconds": 8, "difficulty": "High",
             "resolution": "720p", "audio": True, "lip_sync": True,
             "approved": False, "role_ids": ["R01", "R02"],
             "ref_images": ["REF-001", "REF-003"], "seed": 20261111},
            {"shot_id": "S002", "seconds": 5, "difficulty": "Mid",
             "resolution": "720p", "audio": False, "lip_sync": False,
             "approved": True, "role_ids": ["R01"],
             "ref_images": ["REF-001"], "seed": 20261111},
        ],
    }


def is_unverified(value: Any) -> bool:
    """判断费率/状态是否属于未核实，未核实一律不折算为数字。"""
    if value is None:
        return True
    if isinstance(value, str):
        return any(m in value for m in UNVERIFIED_MARKERS)
    return False


def audio_mode_of(shot: dict[str, Any]) -> str:
    return "native" if shot.get("audio") else "none"


def pick_rate(rates: list[dict[str, Any]], platform: str, resolution: str,
              mode: str) -> dict[str, Any] | None:
    """按 平台 + 分辨率 + 音频模式 精确匹配费率；找不到返回 None（视为待核实）。"""
    for r in rates:
        if (r.get("platform") == platform and r.get("resolution") == resolution
                and r.get("audio_mode") == mode):
            return r
    return None


def shot_cost(rate: dict[str, Any] | None, shot: dict[str, Any]) -> dict[str, Any]:
    """
    单镜成本。返回 {status, base, unit, note}。
    status == "ok" 时 base 为 float；否则 base 为字符串 "待核实"。
    """
    if rate is None:
        return {"status": "unverified", "base": UNVERIFIED, "unit": "",
                "note": "未找到匹配的当期费率，标待核实"}

    # 任一关键字段未核实 → 整行不折算
    for key in ("start_credits", "per_second_credits", "audio_extra", "resolution_factor"):
        if key in rate and is_unverified(rate[key]):
            return {"status": "unverified", "base": UNVERIFIED, "unit": "",
                    "note": f"字段 {key} 未核实，整行不折算为确定值"}
    if is_unverified(rate.get("verify_status")):
        return {"status": "unverified", "base": UNVERIFIED, "unit": "",
                "note": f"单价状态：{rate.get('verify_status')}"}

    seconds = float(shot["seconds"])
    if seconds <= 0:
        raise ValueError(f"shot {shot.get('shot_id')} 时长必须为正数，收到 {seconds}")

    unit = "Credits"
    if rate.get("per_second_credits") is not None:
        per_sec = float(rate["per_second_credits"])
        start = float(rate.get("start_credits") or 0.0)
        raw = start + per_sec * seconds
    elif rate.get("per_second_cny") is not None:
        per_sec = float(rate["per_second_cny"])
        raw = per_sec * seconds
        unit = "元"
    else:
        return {"status": "unverified", "base": UNVERIFIED, "unit": "",
                "note": "既无每秒积分也无每秒单价，标待核实"}

    factor = float(rate.get("resolution_factor") or 1.0)
    audio_extra = float(rate.get("audio_extra") or 0.0)
    discount = float(rate.get("member_discount") or 1.0)
    base = (raw * factor + audio_extra) * discount
    return {"status": "ok", "base": round(base, 4), "unit": unit,
            "note": rate.get("note", "")}


def compute(cfg: dict[str, Any]) -> dict[str, Any]:
    """主计算：逐镜逐平台 → 汇总区间 → 三档对比 → 最省方案。"""
    project_id = cfg.get("project_id") or "unnamed"
    rates = cfg.get("rates") or []
    shots = cfg.get("shots") or []
    if not rates:
        raise ValueError("输入缺少 rates（当期回查的单价配置）")
    if not shots:
        raise ValueError("输入缺少 shots（分镜表）")

    # 复杂/异常输入的自动恢复：跳过坏镜头并留痕，不让整批估算中断
    skipped_shots: list[str] = []
    valid_shots: list[dict[str, Any]] = []
    for s in shots:
        try:
            sec = float(s["seconds"])
            if sec <= 0:
                raise ValueError("时长非正数")
            if s.get("difficulty", "Mid") not in DIFFICULTY_FACTOR:
                raise ValueError("难度非法")
            # 与 generate_variants.py 共用输入：分辨率可以写在项目级，不必每镜重复
            s.setdefault("resolution", cfg.get("resolution", "720p"))
            valid_shots.append(s)
        except (KeyError, TypeError, ValueError) as e:
            skipped_shots.append(f"{s.get('shot_id', '<无编号>')}: {e}")
    shots = valid_shots
    if not shots:
        raise ValueError("没有任何可估算的镜头，请检查 shots 的 seconds 与 difficulty 字段")

    platforms = sorted({r["platform"] for r in rates})
    platforms = [p for p in platforms if p != "即梦"] + (["即梦"] if "即梦" in platforms else [])
    costs: list[dict[str, Any]] = []
    variants: list[dict[str, Any]] = []

    for shot in shots:
        diff = shot.get("difficulty", "Mid")
        if diff not in DIFFICULTY_FACTOR:
            raise ValueError(f"shot {shot.get('shot_id')} 难度 {diff} 非法，应为 High/Mid/Low")
        mode = audio_mode_of(shot)
        for platform in platforms:
            rate = pick_rate(rates, platform, shot["resolution"], mode)
            c = shot_cost(rate, shot)
            row: dict[str, Any] = {
                "project_id": project_id,
                "shot_id": shot["shot_id"],
                "platform": platform,
                "model": (rate or {}).get("model", UNVERIFIED),
                "resolution": shot["resolution"],
                "seconds": shot["seconds"],
                "difficulty": diff,
                "audio": bool(shot.get("audio")),
                "lip_sync": bool(shot.get("lip_sync")),
                "seed": shot.get("seed"),
                "ref_images": ",".join(shot.get("ref_images") or []),
                "role_ids": ",".join(shot.get("role_ids") or []),
                "start_credits": (rate or {}).get("start_credits"),
                "per_second_credits": (rate or {}).get("per_second_credits"),
                "resolution_factor": (rate or {}).get("resolution_factor"),
                "source_url": (rate or {}).get("source_url", "未找到可靠来源"),
                "fetch_date": (rate or {}).get("fetch_date", cfg.get("fetch_date")),
                "verify_status": (rate or {}).get("verify_status", UNVERIFIED),
                "single_cost": c["base"],
                "unit": c["unit"],
                "retry_low": RANGE_LOW,
                "retry_high": RANGE_HIGH,
                "difficulty_factor": DIFFICULTY_FACTOR[diff],
                "subtotal_low": (round(c["base"] * RANGE_LOW, 4)
                                 if c["status"] == "ok" else UNVERIFIED),
                "subtotal_high": (round(c["base"] * RANGE_HIGH, 4)
                                  if c["status"] == "ok" else UNVERIFIED),
                "subtotal_weighted": (round(c["base"] * DIFFICULTY_FACTOR[diff], 4)
                                      if c["status"] == "ok" else UNVERIFIED),
                "note": c["note"],
                "is_example": bool(cfg.get("is_example", False)),
            }
            costs.append(row)
            variants.append({
                "shot_id": shot["shot_id"], "platform": platform,
                "model": row["model"], "resolution": shot["resolution"],
                "duration": shot["seconds"], "seed": shot.get("seed"),
                "motion": "small", "audio": row["audio"], "lip_sync": row["lip_sync"],
                "ref_images": shot.get("ref_images") or [],
                "prompt_id": f"PO-{project_id}-{shot['shot_id']}-{platform}-v1",
                "prompt_full_text": "由 SKILL.md 工作流程第 2 步按三平台语法生成",
                "negative_prompt": "见 references/platform-syntax.md 各平台负向词基线",
            })

    # ---- 按平台汇总（只汇总 status=ok 的行） ----
    by_platform: dict[str, Any] = {}
    for p in platforms:
        rows = [r for r in costs if r["platform"] == p]
        ok = [r for r in rows if isinstance(r["single_cost"], (int, float))]
        unverified = len(rows) - len(ok)
        if not ok:
            by_platform[p] = {"base_cost": UNVERIFIED, "range": UNVERIFIED,
                              "unverified_rows": unverified,
                              "coverage": f"0/{len(rows)} 条已核实",
                              "scope_notice": SCOPE_NOTICE,
                              "status": "全部单价待核实，禁止给单点"}
            continue
        base = sum(r["single_cost"] for r in ok)
        by_platform[p] = {
            "base_cost": round(base, 4),
            "range": [round(base * RANGE_LOW, 4), round(base * RANGE_HIGH, 4)],
            "weighted_reference": round(sum(
                r["single_cost"] * r["difficulty_factor"] for r in ok), 4),
            "weighted_notice": "参考中值，非单点报价、非承诺值",
            "verified_rows": len(ok),
            "unverified_rows": unverified,
            "coverage": f"{len(ok)}/{len(rows)} 条已核实",
            "is_lower_bound": unverified > 0,
            "scope_notice": SCOPE_NOTICE,
            "partial_notice": (f"有 {unverified} 条因单价未核实而未计入；"
                               "本平台数值是下界，不可与其他平台直接比大小"
                               if unverified else "本平台全部镜头单价已核实"),
            "unit": ok[0]["unit"],
        }

    # ---- 三档对比：按平台 / 按画质 / 是否含音频 ----
    assumed = cfg.get("assumed_resolution_factors") or {}
    by_resolution: dict[str, Any] = {}
    for res, fac in assumed.items():
        ok = [r for r in costs if isinstance(r["single_cost"], (int, float))]
        if not ok:
            by_resolution[res] = UNVERIFIED
            continue
        # 以 720p 为基准折算：仅作敏感性对比，非报价
        base = sum(r["single_cost"] * float(fac) for r in ok)
        by_resolution[res] = {
            "base_cost": round(base, 4),
            "range": [round(base * RANGE_LOW, 4), round(base * RANGE_HIGH, 4)],
            "assumed": True,
            "factor": fac,
            "notice": cfg.get("assumed_factor_notice",
                              "工程假设系数，非官方数据，待核实；不作报价"),
            "scope_notice": SCOPE_NOTICE,
            "comparison_warning": "本列是同一批已核实行按假设系数折算的敏感性分析，"
                                  "不是该画质的官方报价，不可与按平台列混用比较",
        }

    by_audio: dict[str, Any] = {}
    for flag in (True, False):
        rows = [r for r in costs if r["audio"] is flag]
        ok = [r for r in rows if isinstance(r["single_cost"], (int, float))]
        key = "含原生音频" if flag else "不含原生音频"
        if not ok:
            by_audio[key] = UNVERIFIED
        else:
            base = sum(r["single_cost"] for r in ok)
            by_audio[key] = {
                "base_cost": round(base, 4),
                "range": [round(base * RANGE_LOW, 4), round(base * RANGE_HIGH, 4)],
                "unverified_rows": len(rows) - len(ok),
            }

    # ---- 最省方案：540p 全量试跑 + 仅过审镜头升目标画质重跑 ----
    approved = [s for s in shots if s.get("approved")]
    ok_all = [r for r in costs if isinstance(r["single_cost"], (int, float))]
    trial_factor = float(assumed.get("540p", 0.6))
    trial_cost = (round(sum(r["single_cost"] for r in ok_all) * trial_factor, 4)
                  if ok_all else UNVERIFIED)
    approved_base = 0.0
    for s in approved:
        for r in costs:
            if (r["shot_id"] == s["shot_id"]
                    and isinstance(r["single_cost"], (int, float))):
                approved_base += r["single_cost"]
                break  # 每镜只取一个平台，避免重复计费
    cheapest = {
        "strategy": "低分辨率试跑锁构图 → 只把过审镜头升到目标画质重跑",
        "steps": [
            "全部镜头以 540p / 短时长 / 静音试跑，只验构图与外貌锚点",
            "按五项质检打分，挑出过审镜头",
            "仅过审镜头升到目标画质并开启原生音频/口型重跑",
            "同一集只用同一平台，避免混剪撞脸",
        ],
        "trial_540p_cost": trial_cost,
        "trial_notice": "基于工程假设系数，非官方数据，待核实",
        "approved_shots": [s["shot_id"] for s in approved],
        "approved_upgrade_cost": round(approved_base, 4) if ok_all else UNVERIFIED,
        "full_rerun_cost": (round(sum(r["single_cost"] for r in ok_all), 4)
                            if ok_all else UNVERIFIED),
        "saving_notice": "试跑+升级的总成本需与全量重跑比较；含隐性成本后才是真实节省",
    }

    total_verified_base = (round(sum(r["single_cost"] for r in ok_all), 4)
                           if ok_all else UNVERIFIED)
    summary = {
        "project_id": project_id,
        "fetch_date": cfg.get("fetch_date") or date.today().isoformat(),
        "is_example": bool(cfg.get("is_example", False)),
        "shot_count": len(shots),
        "total_seconds": sum(float(s["seconds"]) for s in shots),
        "platform_count": len(platforms),
        "verified_base_cost": total_verified_base,
        "total_range": ([round(total_verified_base * RANGE_LOW, 4),
                         round(total_verified_base * RANGE_HIGH, 4)]
                        if isinstance(total_verified_base, (int, float)) else UNVERIFIED),
        "unverified_rows": sum(1 for r in costs
                               if not isinstance(r["single_cost"], (int, float))),
        "coverage": f"{sum(1 for r in costs if isinstance(r['single_cost'], (int, float)))}"
                    f"/{len(costs)} 条已核实",
        "is_lower_bound": any(not isinstance(r["single_cost"], (int, float))
                              for r in costs),
        "skipped_shots": skipped_shots,
        "scope_notice": SCOPE_NOTICE,
        "comparison_warning": "三档对比中，覆盖镜头数不同的列不得直接比大小；"
                              "按画质一列使用假设系数，只作敏感性分析，不作报价",
        "fallback": "定价页查不到时：跑一条 5 秒样片看后台扣减反推单价；成本列输出区间并注明「未核实」",
        "no_single_point_guarantee": True,
    }

    return {
        "summary": summary,
        "variants": variants,
        "costs": costs,
        "rerun_rules": RERUN_RULES,
        "qc_items": list(QC_ITEMS),
        "three_way_comparison": {
            "by_platform": by_platform,
            "by_resolution": by_resolution,
            "by_audio": by_audio,
        },
        "cheapest_plan": cheapest,
        "hidden_costs": HIDDEN_COSTS,
        "price_card": [
            {"platform": r["platform"], "model": r.get("model"),
             "resolution": r.get("resolution"), "audio_mode": r.get("audio_mode"),
             "start_credits": r.get("start_credits"),
             "per_second_credits": r.get("per_second_credits"),
             "source_url": r.get("source_url"), "fetch_date": r.get("fetch_date"),
             "verify_status": r.get("verify_status")}
            for r in rates
        ],
    }


CSV_FIELDS = [
    "project_id", "shot_id", "platform", "model", "resolution", "seconds",
    "difficulty", "audio", "lip_sync", "seed", "ref_images", "role_ids",
    "start_credits", "per_second_credits", "resolution_factor",
    "source_url", "fetch_date", "verify_status", "single_cost", "unit",
    "retry_low", "retry_high", "difficulty_factor",
    "subtotal_low", "subtotal_high", "subtotal_weighted", "note", "is_example",
]


def write_outputs(result: dict[str, Any], outdir: Path) -> tuple[Path, Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    pid = result["summary"]["project_id"]
    # 成本专用文件名：避免覆盖 generate_variants.py 的主表；
    # 由 run_pipeline.py 统一合并回填成最终 prompt_variants_<project_id>.*
    csv_path = outdir / f"cost_rows_{pid}.csv"
    json_path = outdir / f"cost_estimate_{pid}.json"

    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction="ignore")
        w.writeheader()
        for row in result["costs"]:
            w.writerow(row)

    with json_path.open("w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    return csv_path, json_path


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="AI 视频生成成本估算（区间，不给单点）")
    ap.add_argument("--input", help="输入 JSON 配置文件路径")
    ap.add_argument("--demo", action="store_true", help="使用内置示例数据（示例，非真实项目）")
    ap.add_argument("--outdir", default="./out", help="输出目录，默认 ./out")
    args = ap.parse_args(argv)

    if not args.input and not args.demo:
        ap.error("必须指定 --input <file.json> 或 --demo")
    try:
        if args.demo:
            cfg = demo_config()
        else:
            p = Path(args.input)
            if not p.is_file():
                raise FileNotFoundError(f"输入文件不存在：{p}")
            cfg = json.loads(p.read_text(encoding="utf-8"))
        result = compute(cfg)
        csv_path, json_path = write_outputs(result, Path(args.outdir))
    except FileNotFoundError as e:
        print(f"[怎么了] 找不到输入文件：{e}", file=sys.stderr)
        print("[怎么改] 确认 --input 路径；或先用 --demo 跑通看输出长什么样", file=sys.stderr)
        return 2
    except json.JSONDecodeError as e:
        print(f"[怎么了] 输入不是合法 JSON（第 {e.lineno} 行附近）", file=sys.stderr)
        print("[怎么改] 用 UTF-8 无 BOM 重新保存；或复制 templates/storyboard_input_template.json 改写", file=sys.stderr)
        return 2
    except (OSError, ValueError, KeyError, TypeError) as e:
        print(f"[怎么了] 估算没跑完：{e}", file=sys.stderr)
        print("[怎么改] 运行 python scripts/doctor.py --input <你的文件> --fix 自动定位并修复；"
              "已生成的中间文件会保留", file=sys.stderr)
        return 2

    s = result["summary"]
    print(f"[OK] project_id={s['project_id']}  镜头数={s['shot_count']}  总秒数={s['total_seconds']}")
    print(f"[OK] 已核实基础成本={s['verified_base_cost']}  含重试区间={s['total_range']}")
    print(f"[OK] 待核实行数={s['unverified_rows']}（这些行成本为「待核实」，未折算成确定值）")
    print(f"[OK] 统计口径={s['coverage']}；{'该数值是下界，不是全量报价' if s['is_lower_bound'] else '全部镜头已核实'}")
    if s["skipped_shots"]:
        print(f"[提示] 已自动跳过 {len(s['skipped_shots'])} 个异常镜头（未中断整批）："
              + "; ".join(s["skipped_shots"][:3]))
    print(f"[OK] CSV : {csv_path}")
    print(f"[OK] JSON: {json_path}")
    for p, v in result["three_way_comparison"]["by_platform"].items():
        extra = f"，覆盖 {v.get('coverage', '')}" if isinstance(v, dict) else ""
        print(f"     - {p}: {v.get('range', v)}{extra}")
    print("[提醒] 覆盖镜头数不同的列不要直接比大小；按画质一列用的是假设系数，只作敏感性分析。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
