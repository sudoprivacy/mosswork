#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prompt-optimizer / WorkBuddy 开放平台上传包自检脚本
====================================================

依据：WorkBuddy 开放平台《技能》当期规范（回查日期 2026-11-11）
      https://open.workbuddy.cn/docs/skill
补充：ZIP ≤ 3MB、目录 ≤ 2 层级（第三方实践文章口径，标「待核实」，从严执行）
      https://m.10100.com/article/152897587

⚠️ 不使用 skill-creator 自带的 quick_validate.py：该校验器属另一套规范
   （仅允许 name/description/license/allowed-tools/metadata），会把开放平台
   必填的 display_name、version、author 等误报为非法字段。

依赖：Python 3.9+，仅标准库。

运行示例：
    python validate_open_platform.py --skill-dir ./prompt-optimizer
    python validate_open_platform.py --skill-dir ./prompt-optimizer --zip ./workbuddy_upload_xxx.zip

退出码：0 = 全部通过（可有 WARN）；1 = 存在 FAIL（阻断上传）。
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

OFFICIAL_REQUIRED = [
    "name", "display_name", "display_name_en", "description",
    "description_zh", "description_en", "version", "author",
]
OFFICIAL_OPTIONAL = ["allowed-tools", "examples_zh", "examples_en"]
OFFICIAL_RESOURCE_DIRS = {"references", "scripts", "templates"}
# SkillHub：官方教程 5 字段 + Agent 发布指令 3 必填，取并集（见 skillhub-spec.md）
SKILLHUB_REQUIRED = ["slug", "displayName", "version", "summary", "license"]
SKILLHUB_RECOMMENDED = ["name", "description", "category", "platforms", "tags"]
SPEC_URL = "https://open.workbuddy.cn/docs/skill"
SPEC_URL_SKILLHUB = "https://www.skillhub.cn/tutorials"
SPEC_FETCH_DATE = "2026-11-12"
ZIP_LIMIT_BYTES = 3 * 1024 * 1024  # 3MB（第三方口径，标待核实，从严执行）

TRIGGER_WORDS = ["优化提示词", "三平台变体", "成本估算", "废片", "积分"]

# 敏感信息赋值模式（只匹配「键=值」形式，不匹配说明文字）
SECRET_PATTERNS = [
    re.compile(r"(?i)\b(api[_-]?key|access[_-]?token|secret[_-]?key|password|passwd|cookie|authorization|bearer)\b\s*[:=]\s*['\"]?[A-Za-z0-9_\-\.]{8,}"),
    re.compile(r"(?i)\b(sk-[A-Za-z0-9]{16,}|ghp_[A-Za-z0-9]{20,}|AKIA[A-Z0-9]{12,})\b"),
]
# 说明性语句白名单：这些行是在「提醒不要打包密钥」，不是密钥本身
SECRET_LINE_WHITELIST = ("不得", "禁止", "清掉", "不含", "扫描", "检查",
                         "- [ ]", "无 API", "无凭证", "SECRET_PATTERNS",
                         "regex", "re.compile", "api[_-]?key")

TEXT_SUFFIXES = {".md", ".csv", ".json", ".py", ".txt", ".yaml", ".yml", ".sh"}


class Report:
    def __init__(self) -> None:
        self.passed = 0
        self.warned = 0
        self.failed = 0

    def ok(self, msg: str) -> None:
        self.passed += 1
        print(f"[PASS] {msg}")

    def warn(self, msg: str) -> None:
        self.warned += 1
        print(f"[WARN] {msg}")

    def fail(self, msg: str) -> None:
        self.failed += 1
        print(f"[FAIL] {msg}")

    def finish(self) -> int:
        print("-" * 68)
        print(f"结果：PASS={self.passed}  WARN={self.warned}  FAIL={self.failed}")
        print(f"规范依据：{SPEC_URL} （回查日期 {SPEC_FETCH_DATE}）")
        if self.failed:
            print("结论：存在阻断项，禁止上传。请按上方 [FAIL] 逐项修正后重跑。")
            return 1
        print("结论：通过当期规范自检。上传与提交审核仍须由用户在开放平台侧完成。")
        return 0


def parse_frontmatter(text: str) -> dict[str, str]:
    """轻量解析顶层 frontmatter；支持 SkillHub 常用的 YAML 块标量 `>` / `>-`。"""
    if not text.startswith("---"):
        return {}
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return {}
    out: dict[str, str] = {}
    lines = m.group(1).splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.lstrip().startswith("#"):
            i += 1
            continue
        kv = re.match(r"^([A-Za-z][A-Za-z0-9_-]*)\s*:\s*(.*)$", line)
        if not kv:
            i += 1
            continue
        key, val = kv.group(1), kv.group(2).strip()
        if val in (">", ">-", ">+", "|", "|-", "|+"):
            buf: list[str] = []
            i += 1
            while i < len(lines) and (lines[i].startswith((" ", "\t")) or not lines[i].strip()):
                buf.append(lines[i].strip())
                i += 1
            out[key] = " ".join(x for x in buf if x)
            continue
        out[key] = val.strip('"').strip("'")
        i += 1
    return out


def check_skill_md(skill_dir: Path, r: Report,
                   platform: str = "workbuddy") -> dict[str, str]:
    required = SKILLHUB_REQUIRED if platform == "skillhub" else OFFICIAL_REQUIRED
    optional = SKILLHUB_RECOMMENDED if platform == "skillhub" else OFFICIAL_OPTIONAL
    p = skill_dir / "SKILL.md"
    if not p.is_file():
        r.fail("SKILL.md 不存在（官方规定为必须）")
        return {}
    raw = p.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        r.fail("SKILL.md 含 UTF-8 BOM，官方要求 UTF-8 无 BOM")
    else:
        r.ok("SKILL.md 为 UTF-8 无 BOM")
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as e:
        r.fail(f"SKILL.md 非 UTF-8 编码：{e}")
        return {}
    if not text.startswith("---"):
        r.fail("SKILL.md 缺少 YAML frontmatter（未以 --- 开头）")
        return {}
    r.ok("SKILL.md 以 YAML frontmatter 开头")

    fm = parse_frontmatter(text)
    missing = [k for k in required if k not in fm or not fm[k]]
    if missing:
        r.fail(f"{platform} 必填 frontmatter 缺失：{', '.join(missing)}")
    else:
        r.ok(f"{platform} 必填 frontmatter 齐全（{len(required)} 个）："
             + ", ".join(required))

    unknown = set(fm) - set(required) - set(optional) - set(OFFICIAL_REQUIRED)
    if unknown:
        r.warn(f"存在当期文档未列出的字段：{', '.join(sorted(unknown))}；"
               "建议写入字段映射说明")
    else:
        r.ok("frontmatter 无当期规范未列出的多余字段")

    name = fm.get("name", "")
    if name and skill_dir.name != name:
        r.fail(f"目录名 '{skill_dir.name}' 与 frontmatter name '{name}' 不一致")
    else:
        r.ok(f"目录名与 frontmatter name 一致：{name}")
    if name and not re.match(r"^[a-z0-9-]+$", name):
        r.fail(f"name '{name}' 不符合小写连字符命名规范")
    else:
        r.ok("name 符合小写连字符命名规范")

    desc = fm.get("description", "")
    if not any(w in desc for w in TRIGGER_WORDS):
        r.fail("description 内未检出触发词（官方要求「写清用途和触发词」）")
    else:
        r.ok("description 内含触发条件")
    if "<" in desc or ">" in desc:
        r.fail("description 含尖括号，可能导致解析失败")
    if len(desc) > 1024:
        r.warn(f"description 长度 {len(desc)} 超过 1024，建议精简")

    for k in ("description_zh", "description_en", "display_name",
              "display_name_en", "version", "author"):
        if fm.get(k):
            r.ok(f"{k} 已填写")
    return fm


def check_structure(skill_dir: Path, r: Report,
                    platform: str = "workbuddy") -> None:
    entries = [p for p in skill_dir.rglob("*") if p.is_file()]
    if not entries:
        r.fail("skill 目录为空")
        return
    for p in entries:
        depth = len(p.relative_to(skill_dir).parts) - 1  # 文件所在目录层数
        if depth > 2:
            r.fail(f"目录层级超过 2：{p.relative_to(skill_dir)}")
            break
    else:
        r.ok(f"目录层级 ≤ 2（共 {len(entries)} 个文件）")

    dirs = {p.name for p in skill_dir.iterdir() if p.is_dir()}
    missing = OFFICIAL_RESOURCE_DIRS - dirs
    if missing:
        r.warn(f"官方列出的可选资源目录未全建：{', '.join(sorted(missing))}（可选，不阻断）")
    else:
        r.ok("官方资源目录 references/ scripts/ templates/ 齐备")
    if "assets" in dirs:
        if platform == "workbuddy":
            r.warn("存在 assets/ 目录：官方《技能》当期文档未列出该目录，标「待确认格式」；"
                   "若平台解析失败，把其中文件平移到 references/ 后重打包（内容不删）")
        else:
            r.ok("assets/ 目录在 SkillHub 侧属宽容范围（第三方评测口径，标待核实）")

    total = sum(p.stat().st_size for p in entries)
    if total > ZIP_LIMIT_BYTES:
        r.fail(f"未压缩内容合计 {total} 字节 > 3MB 上限，需瘦身")
    else:
        r.ok(f"内容体积 {total} 字节 < 3MB（3MB 为第三方口径，标待核实，从严执行）")


def check_secrets(skill_dir: Path, r: Report) -> None:
    hits: list[str] = []
    for p in skill_dir.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES:
            continue
        try:
            lines = p.read_text(encoding="utf-8").splitlines()
        except (UnicodeDecodeError, OSError):
            continue
        for i, line in enumerate(lines, 1):
            if any(w in line for w in SECRET_LINE_WHITELIST):
                continue
            if any(pat.search(line) for pat in SECRET_PATTERNS):
                hits.append(f"{p.relative_to(skill_dir)}:{i}")
    if hits:
        r.fail(f"检出疑似凭证赋值，必须清除后再打包：{', '.join(hits[:10])}")
    else:
        r.ok("未检出 API Key / 密码 / Cookie / Token 等凭证赋值")


def check_pricing_markers(skill_dir: Path, r: Report) -> None:
    """确保『待核实』价格未被伪装成确定值；确保过期活动价被显式标记。"""
    pricing = skill_dir / "references" / "pricing-fields.md"
    examples = skill_dir / "references" / "example-deliverables.md"
    if not pricing.is_file():
        r.fail("缺少 references/pricing-fields.md（单价口径卡底稿）")
        return
    t = pricing.read_text(encoding="utf-8")
    if "待核实" not in t:
        r.fail("单价口径卡中未出现「待核实」标记，存在把未核实价格伪装成确定值的风险")
    else:
        r.ok("单价口径卡保留「待核实」标记")
    if "已过期-禁止使用" in t and "抓取日期" in t and "https://" in t:
        r.ok("过期活动价已标记，且含抓取日期与完整来源 URL")
    else:
        r.fail("过期价标记 / 抓取日期 / 来源 URL 有缺失")
    if examples.is_file():
        e = examples.read_text(encoding="utf-8")
        if "示例" in e and "非真实项目" in e:
            r.ok("示例输出已显式标注「示例，非真实项目」")
        else:
            r.fail("示例输出缺少「示例 / 非真实项目」标注")
        if "demo-001" in e:
            r.ok("示例 project_id=demo-001 已作为占位符出现")
    else:
        r.warn("未找到示例交付物文件（不阻断）")


def check_zip(zip_path: Path | None, r: Report,
              platform: str = "workbuddy") -> None:
    if zip_path is None:
        r.warn("未传 --zip，跳过 ZIP 包体积与层级实测（建议打包后重跑一次）")
        return
    if not zip_path.is_file():
        r.fail(f"ZIP 不存在：{zip_path}")
        return
    limit = 10 * 1024 * 1024 if platform == "skillhub" else ZIP_LIMIT_BYTES
    limit_label = "10MB（第三方口径，待核实）" if platform == "skillhub" else "3MB（第三方口径，待核实）"
    size = zip_path.stat().st_size
    if size > limit:
        r.fail(f"ZIP {size} 字节 > {limit_label} 上限")
    else:
        r.ok(f"ZIP {size} 字节 < {limit_label}（{zip_path.name}）")
    import zipfile
    expected = "SKILL.md" if platform == "skillhub" else "prompt-optimizer/SKILL.md"
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = z.namelist()
            if expected not in names:
                r.fail(f"ZIP 内未找到 {expected}；"
                       f"实际含 SKILL.md 的路径：{[n for n in names if n.endswith('SKILL.md')]}")
            else:
                r.ok(f"ZIP 内 SKILL.md 位置正确：{expected}")
            if platform == "workbuddy":
                top = {n.split("/")[0] for n in names if "/" in n}
                if len(top) > 1:
                    r.warn(f"ZIP 内存在多个顶层目录：{sorted(top)}；应只有一个 prompt-optimizer/")
                else:
                    r.ok(f"ZIP 单一顶层目录：{sorted(top)}")
            deep = [n for n in names if len(n.split("/")) > 3]
            if deep:
                r.fail(f"ZIP 内存在超过 2 层目录的路径：{deep[:5]}")
            else:
                r.ok("ZIP 内目录层级 ≤ 2")
    except zipfile.BadZipFile as e:
        r.fail(f"ZIP 无法解析：{e}")


def check_skillhub_zip_frontmatter(zip_path: Path | None, r: Report) -> None:
    """SkillHub 版 SKILL.md 由打包脚本动态生成，只存在于 ZIP 内，故直接读 ZIP 文本。"""
    if zip_path is None or not zip_path.is_file():
        r.warn("未提供 skillhub ZIP，跳过其 frontmatter 实测")
        return
    import zipfile
    try:
        with zipfile.ZipFile(zip_path) as z:
            text = z.read("SKILL.md").decode("utf-8")
    except (zipfile.BadZipFile, KeyError, UnicodeDecodeError) as e:
        r.fail(f"读不出 skillhub ZIP 内包根的 SKILL.md：{e}")
        return
    fm = parse_frontmatter(text)
    missing = [k for k in SKILLHUB_REQUIRED if k not in fm or not fm[k]]
    if missing:
        r.fail(f"skillhub ZIP 内 frontmatter 缺字段：{', '.join(missing)}")
    else:
        r.ok("skillhub ZIP 内必填字段齐全（含 YAML 块标量 description）")
    slug = fm.get("slug", "")
    if not re.match(r"^[a-z0-9][a-z0-9-]{1,127}$", slug):
        r.warn(f"slug='{slug}' 不是有效 kebab-case，或仍是占位符；上传前必须替换")
    tokens = sorted(set(re.findall(r"REPLACE_WITH_[A-Z_]+", text)))
    if tokens:
        r.warn(f"待替换占位符 {len(tokens)} 个：{', '.join(tokens)}（用户未提供，不编造）")
    else:
        r.ok("无遗留占位符")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="双平台 skill 上传包自检（按当期规范）")
    ap.add_argument("--skill-dir", required=True, help="skill 目录路径")
    ap.add_argument("--platform", choices=["workbuddy", "skillhub", "both"],
                    default="workbuddy", help="检查目标平台，默认 workbuddy")
    ap.add_argument("--zip", help="WorkBuddy ZIP 路径（可选）")
    ap.add_argument("--zip-skillhub", help="SkillHub ZIP 路径（可选）")
    ap.add_argument("--fix", action="store_true", help="先自动修复可修的结构问题")
    args = ap.parse_args(argv)

    skill_dir = Path(args.skill_dir).resolve()
    wb_zip = Path(args.zip).resolve() if args.zip else None
    sh_zip = Path(args.zip_skillhub).resolve() if args.zip_skillhub else None
    r = Report()
    print("=" * 68)
    print(f"双平台上传包自检 · 目标={args.platform} · 规范回查 {SPEC_FETCH_DATE}")
    print("=" * 68)
    if not skill_dir.is_dir():
        r.fail(f"skill 目录不存在：{skill_dir}")
        return r.finish()

    if args.fix:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import doctor
        target = "skillhub" if args.platform == "skillhub" else "workbuddy"
        fs = doctor.check_skill_dir(skill_dir, target, True)
        n = sum(1 for f in fs if f.fixed)
        if n:
            r.ok(f"自动修复 {n} 项；补出的占位符值仍需人工填写")
        else:
            r.ok("无需自动修复")

    if args.platform in ("workbuddy", "both"):
        check_skill_md(skill_dir, r, "workbuddy")
        check_structure(skill_dir, r, "workbuddy")
        check_secrets(skill_dir, r)
        check_pricing_markers(skill_dir, r)
        check_zip(wb_zip, r, "workbuddy")
    if args.platform in ("skillhub", "both"):
        check_skillhub_zip_frontmatter(sh_zip, r)
        check_zip(sh_zip, r, "skillhub")
    return r.finish()


if __name__ == "__main__":
    sys.exit(main())
