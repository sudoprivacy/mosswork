---
name: skillhub-skill-prompt-optimizer-win
description: ">"
---

# prompt-optimizer · AI视频生成提示词优化兼成本管理

## 0. 30 秒速查（先看这里）

**一句话**：把 storyboarder 的平台中性分镜，翻成即梦 / 可灵 / Vidu **可直接粘贴运行**的完整提示词，并给出可核对的成本区间与重跑策略。

**一键出成品**（无需手工拼接，产物无占位内容）：

```bash
python scripts/run_pipeline.py --demo --outdir ./dist                    # 先用示例跑通
python scripts/run_pipeline.py --input storyboard.json --outdir ./dist  # 真实项目
```

一条命令产出：三平台完整提示词、主表与成本总表、参数卡、机器可读 JSON/CSV、**WorkBuddy 与 SkillHub 两个上传 ZIP**、逐文件哈希清单、交付清单。

**不负责**：剪辑、合成、上传发布、平台审核、账号注册与代付。上传与提交审核由用户本人在平台侧完成。

**必读**：`MEMORY.md`（长期记忆与不得削弱清单）、`CHANGELOG.md`（按 TRACE 维度的变更说明）。

---

## 1. 触发语与输入

**触发语**：优化提示词 / 直接喂即梦 / 可灵怎么写 / 三平台变体 / 多少钱能跑完 / 成本估算 / 废片太多 / 重跑策略 / 积分怎么算。

| 类别 | 字段 |
| --- | --- |
| 必需 | storyboarder 分镜表 + 角色档案库（`shot_id`、外貌锚点、参考图编号、时长、生成难度）、目标平台（默认即梦/可灵/Vidu，可替换为海螺AI、Runway、Pika、Sora）、画质档位（540p/720p/1080p/4K）、是否需原生音频与口型同步、预算上限或镜头总数 |
| 可选 | 会员档位、历史废片原因、`prompt_id` 版本号、`project_id` |
| 输入模板 | `templates/storyboard_input_template.json`（含 `rates`，生成与估算共用一份输入） |

**缺项处理（不得削弱）**：缺 `project_id` 用占位符出包并显式标注「示例占位」；缺分镜表先输出模板并列出待补项，**不臆造镜头内容**；缺角色外貌锚点直接阻断并给出修正步骤。

---

## 2. 能力边界与保护条件（TRACE A 5.0 · 不得削弱）

| 能做 | 不能做 |
| --- | --- |
| 三平台原生语法适配、一致性护栏 | 剪辑、合成、成片输出 |
| 当期定价回查、成本区间、三档对比 | 提供单点报价、承诺「一次出片」 |
| 最省方案、隐性成本清单 | 代用户注册账号、代付、代上传 |
| 五项质检、废片原因回灌、`prompt_id` 升级 | 代替平台审核、承诺上架成功 |
| 双平台上传包生成与自检 | 替用户填 `slug`/作者/许可证等真实身份信息 |

**三条铁律**：
1. 同一镜头跨平台可比：`shot_id`、外貌锚点、参考图编号、时长、seed 不变，只改语法层。
2. **价格必须当期回查**：禁止沿用历史价格；凡输出成本处必须附 `抓取日期 + 来源 URL`。
3. **估算给区间不给单点**：总 `Σ镜头成本 × 重试系数`，High 1.5 / Mid 1.3 / Low 1.2，输出 `[1.2, 1.5]` 区间。

**保护条件（TRACE T 5.0 红线 · 不得削弱）**：
- 单价查不到标 `待核实`，整行不折算为确定值；给「跑 5 秒样片反推单价」兜底。
- 已过期的活动价标「已过期-禁止使用」，绝不作为当期成本依据。
- 包内不得含 API Key、密码、Cookie、账号凭证、会员账号信息或真实用户数据。
- 示例数据一律显式标注「示例，非真实项目」；用户未提供的元数据用 `REPLACE_WITH_` 占位符，不编造。

---

## 3. 工作流程（6 步）

| 步 | 做什么 | 脚本 / 参考 | 产出 |
| --- | --- | --- | --- |
| 1 | **拉取当期定价（强制第一步）** | `@references/pricing-fields.md` + 联网回查 + 截图存档 | 单价口径卡（URL + 抓取日期） |
| 2 | 语法适配，产出三平台变体 | `scripts/generate_variants.py`、`@references/platform-syntax.md` | 完整提示词全文（可直接粘贴） |
| 3 | 一致性护栏 | 同上（锚点逐字复制、参考图裁剪留痕、长镜拆段留痕） | 备注列 + 适配损失说明 |
| 4 | 成本估算 | `scripts/estimate_cost.py` | 成本区间、三档对比、最省方案、隐性成本 |
| 5 | 出片质检与回灌 | `@references/platform-syntax.md` 第六节、`FAQ.md` | 废片原因表、`prompt_id` 升级 |
| 6 | 输出与交接 | `scripts/run_pipeline.py`、`scripts/build_upload_package.py` | 主表、副表、参数卡、机器可读文件、双平台 ZIP |

### 第 1 步硬约束
记录 `平台/模型/分辨率/起步积分/每秒积分(或每秒单价)/会员折扣/URL/抓取日期`。积分与会员价会调整（即梦曾多次调整积分与折扣，Vidu 按模型+分辨率分档），禁止沿用历史价格。查不到标 `待核实`。

> **当期实证（2026-11-12 复核）**：即梦官方活动页仍挂「¥0.16/秒」，同页写明「活动时间 10月31日至11月5日 23:59」「限时优惠结束后恢复日常价格」——该价已过期，不得作为当期依据。详见 `@references/pricing-fields.md`。

### 第 2 步语法要点（细节见 `@references/platform-syntax.md`）
- **即梦**＝自然语言长提示，「第N秒…」时间戳切镜，显式列参考图编号与 `role_id` 绑定，开配音/对口型，长镜可一次跑 30s 但标清切镜点；
- **可灵**＝景别/运镜/光影前置成短指令块，Elements 参考组绑定主体，负向提示独立栏，写「运动幅度：小/中」，单段 ≤15s 长镜拆段续接；
- **Vidu**＝主体参考图 + 简洁风格/运动描述，写明时长、分辨率、原生音画同步与口型，多角色标参考图权重，按 Q2-turbo/Q2-pro 等当期模型档选参数。

每个变体附负向提示词与参数卡（时长/分辨率/seed/运动强度/参考图权重/音频开关）。

### 第 4 步口径（对应 TRACE「输出准确性」修订）
`单镜成本 = (起步积分 + 每秒积分×秒数) × 分辨率系数 + 音频加价`；按时计价平台用 `单价×秒数`。
**统计口径**：汇总只含「单价已核实」的镜头，未核实镜头整行标 `待核实` 且不计入 → 该数值是**下界、不是全量报价**；覆盖镜头数不同的列**不得直接比大小**；按画质一列使用工程假设系数，只作敏感性分析、不作报价。

---

## 4. 输出规范

**主表**（`prompt_variants_<project_id>.csv`，由流水线自动回填、无占位内容）：

| `shot_id` | 平台 | 模型/档位 | 提示词(全文，可直接粘贴) | 负向提示词 | 参考图编号 | 参数(时长/分辨率/seed/运动/音频) | `prompt_id` | 单次成本(积分或元) | 单价来源URL | 抓取日期 | 预估重试 | 小计 | 备注 |

**副表**：成本总表 `平台/画质/镜头数/总秒数/单价口径/抓取日期/基础成本/含重试成本(区间)/是否含音频/会员摊销/推荐度`。

**附**：单价口径卡、参数卡汇总、最省方案说明、隐性成本清单、废片原因→重跑建议映射表。

**机器可读**：`prompt_variants_<project_id>.json`（含 `variants[]`、`costs[]`、`rerun_rules[]`），schema 见 `templates/prompt_variants_schema.json`。

**上传包**：`workbuddy_upload_prompt-optimizer_<project_id>_<日期>.zip` 与 `skillhub_upload_prompt-optimizer_<project_id>_<日期>.zip`，随主交付物一并交付。平台规范与字段映射见 `@references/publishing-guide.md`、`@references/open-platform-spec.md`、`@references/skillhub-spec.md`。

---

## 5. 质量红线

- [ ] 每个价格附 `来源URL+抓取日期`，未写死历史价格
- [ ] 三平台变体的 `shot_id`、外貌锚点、参考图编号完全一致
- [ ] 每变体有负向提示词与参数卡，且 `paste_ready=True`（无占位内容）
- [ ] 成本给区间而非单点，已含重试系数、隐性成本与统计口径说明
- [ ] 已给出最省方案（试跑→升级重跑）
- [ ] 未承诺「一次出片」；废片原因已回灌负向词并升 `prompt_id`
- [ ] 已标注交接对象
- [ ] 双平台上传包已生成，目录/frontmatter/编码/包大小/凭证扫描均通过自检
- [ ] `MEMORY.md` 中「不得削弱」清单未被本次改动破坏

---

## 6. 上下游交接

| 方向 | 对象 | 交接物 |
| --- | --- | --- |
| 上游 | storyboarder | 分镜表 + 角色档案库 |
| 下游 | clip-director | 成片素材 + `shot_id` 映射 + 废片清单 |
| 下游 | submission-preparer | AI 生成提示词截图（版权 / AI 创作说明书证据） |
| 平台侧 | 用户本人 | 双平台上传 ZIP |

---

## 7. 失败与回退（人话版，详见 `FAQ.md`）

- 定价页查不到 → 标 `待核实`，跑 5 秒样片反推单价，成本列输出区间并注明「未核实」；
- 某平台不支持长镜/多参考 → 拆镜或裁参考图，输出「适配损失说明」，不静默删内容；
- 三平台风格差异大 → 建议同一集只用同一平台，避免混剪撞脸；
- 废片率 > 40% → 暂停批量跑，先做 3 条小样本 A/B 定位是提示词、参考图还是运动幅度问题；
- 输入异常 / 脚本中断 → `python scripts/doctor.py --skill-dir . --fix` 或 `--input storyboard.json --fix`；已完成的中间产物保留，修好直接重跑；
- 平台规范回查不到 → 按共识结构（ZIP + SKILL.md）出包并标 `待确认格式`，附字段映射说明，不臆造字段。

---

## 8. 分层阅读（渐进式披露）

| 层级 | 什么时候读 | 文件 |
| --- | --- | --- |
| L1 · 上手 | 只想跑通 / 第一次用 | 本文件第 0–2 节、`README.md`、`FAQ.md` |
| L2 · 执行 | 要出真实成品、算成本 | `templates/storyboard_input_template.json`、`@references/platform-syntax.md`、`@references/pricing-fields.md` |
| L3 · 发布 / 维护 | 要上传平台、要迭代版本 | `@references/publishing-guide.md`、`@references/open-platform-spec.md`、`@references/skillhub-spec.md`、`CHANGELOG.md`、`MEMORY.md` |

> 平台发布规范、字段对照、回查证据链已全部移到 `references/`，**不占用核心操作流程**（对应 TRACE「结构清晰 / 渐进式披露」修订）。

---

## 9. 随包资源索引

| 路径 | 用途 |
| --- | --- |
| `MEMORY.md` | 长期记忆与维护说明：正向结论、边界、约束、保护条件，标「不得削弱」 |
| `CHANGELOG.md` | 按 TRACE 维度列出原评价 / 处理方式 / 对应文件 / 修订结果 |
| `FAQ.md` | 集中常见问题清单（快速查询） |
| `@references/platform-syntax.md` | 三平台原生语法、负向词基线、一致性护栏、废片映射 |
| `@references/pricing-fields.md` | 定价字段字典 + 当期回查原文与状态 + 国内访问提示 |
| `@references/open-platform-spec.md` | WorkBuddy 规范回查与字段映射 |
| `@references/skillhub-spec.md` | SkillHub 规范回查与双平台差异 |
| `@references/publishing-guide.md` | 双平台打包、占位符、上传前自检与边界 |
| `@references/trace-evaluation.md` | TRACE 原评价逐项归档（追溯底稿） |
| `@references/example-deliverables.md` | 示例主表 / 副表 / 映射 / 质检与废片原因表 |
| `scripts/generate_variants.py` | 生成三平台完整提示词（消除占位内容） |
| `scripts/estimate_cost.py` | 成本区间、统计口径、三档对比、最省方案 |
| `scripts/build_upload_package.py` | 一键构建双平台 ZIP + 哈希清单 |
| `scripts/doctor.py` | 人话诊断 + `--fix` 自动修复 |
| `scripts/validate_open_platform.py` | 双平台规范自检（含 `--fix`） |
| `scripts/run_pipeline.py` | 一键编排全流程，内置成本回填合并 |
| `templates/*` | 输入模板、变体表模板、参数卡模板、JSON Schema |
| `assets/*` | 由脚本真实生成的示例产物（非占位） |
