# 变更说明 · v1.0.0 → v2.0.0

> 变更日期：2026-11-12（GMT+8）
> 触发来源：用户上传 SkillHub 后收到的 **TRACE 评测意见**（逐字归档见 `references/trace-evaluation.md`）
> 编制原则：**按 TRACE 维度逐条列出「原评价 → 处理方式 → 对应文件 → 修订结果」**，确保每一条正面评价与待改进点均可追溯。
> 长期记忆：`MEMORY.md`（正向结论 / 适用边界 / 约束 / 保护条件，标「后续迭代不得削弱」）。
> 结论：本次修订**未削弱任何一条正向评价**；所有扣分点均有对应文件与可验证结果。

---

## 0. 版本与范围

| 项 | v1.0.0 | v2.0.0 |
| --- | --- | --- |
| 版本 | 1.0.0 | **2.0.0** |
| 目标平台 | WorkBuddy 开放平台 | **WorkBuddy 开放平台 + SkillHub** |
| 交付形态 | 文档 + 2 个脚本 + 1 个 ZIP | 文档 + 6 个脚本 + 2 个 ZIP + 一键流水线 |
| 产物提示词 | 含占位内容，须人工补全 | **脚本生成完整全文，`paste_ready=True`** |
| 打包 | 需手工调用 | **一键生成双平台 ZIP + 哈希清单** |
| 文件数 | 13 | 26（详见 `references/publishing-guide.md` 目录树） |

**新增占位符**（用户未提供，不编造）：`REPLACE_WITH_YOUR_UNIQUE_SLUG`、`REPLACE_WITH_AUTHOR_OR_ORG`、`REPLACE_WITH_LICENSE`、`REPLACE_WITH_CATEGORY`、`REPLACE_WITH_PROJECT_ID`。清单见 `references/publishing-guide.md` 第 4 节。

---

## 1. T · Trust 可信任度（原 4.9/5）

| 子项 / 得分 | 原评价（原文） | 归类 | 处理方式 | 对应文件 | 修订结果 |
| --- | --- | --- | --- | --- | --- |
| 维度总评 4.9 | "双实验室交叉验证，无P0/P1级安全风险, 中文体验完整，国内主流平台基本覆盖，费用查询和生成流程较实用；少数海外资料在国内可能打开较慢或需要核实。" | 保留强化 + P2 增强 | 安全性结论写入长期记忆并设为最高优先级；末句另设国内访问提示 | `MEMORY.md` §1/§4、`references/pricing-fields.md` §五 | T 项列为红线；`MEMORY.md` §6 首条即「凭证扫描通过」 |
| 国内适配性 4.8 | "中文体验完整，国内主流平台基本覆盖，费用查询和生成流程较实用；少数海外资料在国内可能打开较慢或需要核实。" | **保留强化** | 保持全中文文档与即梦/可灵/Vidu 覆盖；新增「国内访问提示」小节，标注海外官方页可能较慢并给备用口径（标 `待核实`） | `SKILL.md`（全中文）、`README.md`、`FAQ.md`、`references/pricing-fields.md` §五 | 未削弱；新增 `references/pricing-fields.md`「五、国内访问提示与备用口径」 |
| 安全性扫描 5.0 | "双实验室交叉验证，无P0/P1级安全风险" | **保留强化 · 红线** | 保留并强化凭证扫描：`build_upload_package.py` 打包前扫描、`validate_open_platform.py` 自检扫描；示例数据标注、过期价标记、占位符策略全部保留 | `scripts/build_upload_package.py`、`scripts/validate_open_platform.py`、`MEMORY.md` §4 | 未削弱；新增两类校验，`doctor.py` 亦做敏感残留检查；`manifest_*.json` 记录 `secret_scan.passed=true` |

---

## 2. R · Reliability 可靠性（原 4.1/5 · 最低分维度）

| 子项 / 得分 | 原评价（原文） | 归类 | 处理方式 | 对应文件 | 修订结果 |
| --- | --- | --- | --- | --- | --- |
| 维度总评 4.1 | "常规估算和自检比较稳定，未知价格也会安全标注；但自动打包和完整提示词生成没有真正落地，复杂输入时排错指引仍有限。" | 前半保留 + 后半 P0/P1 修订 | 补 3 个核心脚本 + 1 个编排脚本 + 1 个诊断脚本 | 全 `scripts/` | 一键流水线 5 步全通过（见 §6） |
| 异常处理 4.0 | "出错时通常能说明原因，不会静默生成错误结果；但提示偏技术化，缺少更直白的修正步骤和自动修复方案。" | 前半**保留强化**；后半**需修订** | 全部脚本统一 `[怎么了] / [怎么改] / [已自动修复]` 三段式人话输出；新增 `--fix` 自动修复（补字段占位符、去 BOM、补缺失顶层键） | `scripts/doctor.py`（新增）、`scripts/generate_variants.py`、`scripts/estimate_cost.py`、`scripts/run_pipeline.py`、`FAQ.md` | 未削弱「不静默」；实测 `doctor.py --fix` 可修 BOM 与缺字段并报告；退出码 0/1/2 对齐评测口径 |
| 功能完善性 4.0 | "费用计算和检查功能较完整，但自动生成成品提示词与上传包没有真正完成，很多最终步骤仍要手工处理。" | 前半**保留强化**；后半**需修订 · P0** | ①新增 `generate_variants.py` 按三平台语法渲染完整提示词全文；②新增 `build_upload_package.py` 一键出双平台 ZIP；③`run_pipeline.py` 自动合并回填主表 | `scripts/generate_variants.py`、`scripts/build_upload_package.py`、`scripts/run_pipeline.py`、`templates/storyboard_input_template.json` | 示例实跑：6 条变体全部 `paste_ready=True`、`placeholder_count=0`；产出 `full_prompts_demo-001.md`（可直接粘贴）；双平台 ZIP 各 **26 个文件** |
| 运行稳定性 4.3 | "正常情况运行较稳，多次计算结果应一致；但遇到复杂或特殊输入时，缺少自动恢复和完整验证保障。" | 前半**保留强化**；后半**需修订** | ①坏镜头跳过并写入 `skipped_shots`，不中断整批；②输入校验前置且给修复步骤；③双平台 ZIP 结构/编码/大小自检；④`manifest_*.json` 逐文件 SHA-256；⑤流水线任一步失败保留已完成产物 | `scripts/estimate_cost.py`（`skipped_shots`）、`scripts/generate_variants.py`（`validate_input`）、`scripts/validate_open_platform.py`、`scripts/build_upload_package.py`、`scripts/run_pipeline.py` | 幂等性保持：同输入两次实跑 `142.0 / [170.4, 213.0]` 一致；manifest 含 18 个文件哈希；自检 PASS 项见 §6 |

---

## 3. A · Adaptability 适用性（原 5.0/5 · 满分维度）

| 子项 / 得分 | 原评价（原文） | 归类 | 处理方式 | 对应文件 | 修订结果 |
| --- | --- | --- | --- | --- | --- |
| 维度总评 5.0 | "这个 Skill 告诉得很清楚哪些问题能处理、哪些不能，也给出了很多自然的提问方式。缺少信息时会先列待补项，不会擅自编造内容，普通用户较容易上手。" | **全部保留强化 · 不得削弱** | 逐句写入长期记忆；`SKILL.md` 重构时把边界表前移到第 2 节（更醒目），并新增「缺项处理（不得削弱）」 | `MEMORY.md` §1/§2、`SKILL.md` §1/§2 | 未削弱；边界表由原「角色与边界」段落升级为独立「能做 / 不能做」表 |
| 能力边界定义 5.0 | "能做和不能做的范围写得很明白，缺资料、长镜头或价格不明时也交代了处理办法，不容易让人产生误解。" | **保留强化 · 满分** | 保持原文措辞不弱化；三条失败处理（缺资料 / 长镜头 / 价格不明）移入 `SKILL.md` §7 与 `FAQ.md`，并固化到 `MEMORY.md` §2 | `SKILL.md` §2/§7、`FAQ.md`、`MEMORY.md` §2 | 未削弱；`MEMORY.md` §2 明确「不得删减、不得弱化措辞」 |
| 触发方式 5.0 | "常用说法都容易命中，而且有三类完整提问范例；照着说就能调用，不需要先学习特殊操作。" | **保留强化 · 满分** | `description` 内触发词全部保留；`examples_zh` / `examples_en` 三类完整范例保留；SkillHub 版 frontmatter 同步注入 | `SKILL.md` frontmatter、`scripts/build_upload_package.py`（`SKILLHUB_FRONTMATTER`）、`README.md` §二 | 未削弱；双平台 frontmatter 均含触发词与三类中英文范例 |

---

## 4. C · Convention 规范性（原 4.7/5）

| 子项 / 得分 | 原评价（原文） | 归类 | 处理方式 | 对应文件 | 修订结果 |
| --- | --- | --- | --- | --- | --- |
| 维度总评 4.7 | "资料层次清楚、示例丰富，实际使用和失败处理都有交代。主要不足是内容较长、缺少集中常见问题解答，部分模板仍需人工补全。" | 前半保留 + 后半需修订 | 精简核心 + 新增 FAQ + 输入模板自动可跑 | `SKILL.md`、`FAQ.md`、`templates/storyboard_input_template.json` | `SKILL.md` 由大段规范复述改为 9 节速查式；模板含 `rates` 可直接跑 |
| 反模式与FAQ 4.5 | "常见踩坑和出错后的处理办法写得比较清楚，能避免多数明显错误；只是没有一份便于快速查询的常见问题清单。" | 前半**保留强化**；后半**需修订** | 新增集中式 `FAQ.md`：按「上手 / 输入 / 成本 / 打包上传 / 质检」分组，每条给「现象→原因→怎么做」 | `FAQ.md`（新增）、`scripts/doctor.py`（人话诊断与之对应） | 新增 20+ 条问答清单，可快速检索；原踩坑说明全部保留在 `references/platform-syntax.md` |
| 文档质量 4.8 | "案例从输入到交付展示得很完整，成本与重跑建议也很实用。唯一不足是自动产物中的提示词内容不能直接使用。" | 前半**保留强化**；后半**需修订 · P0** | 删除 JSON 中「由 SKILL.md 第 2 步生成」类占位串，改由 `generate_variants.py` 渲染真实全文，并输出 `full_prompts_<pid>.md` | `scripts/generate_variants.py`、`assets/example_full_prompts_demo-001.md`、`references/example-deliverables.md` | 示例产物中的 6 条提示词均为完整可粘贴文本；主表成本列由流水线自动回填，无「待回填」残留 |
| 渐进式披露 4.5 | "先看基本用法，再按需要查看价格和平台细节，查找路径较顺；不过一次读完整套资料仍会觉得信息偏多。" | 前半**保留强化**；后半**需修订** | 新增 §0「30 秒速查」与 §8「L1/L2/L3 分层阅读」；把发布规范、字段对照、回查证据链全部移到 `references/` | `SKILL.md` §0/§8、`references/publishing-guide.md`、`references/open-platform-spec.md`、`references/skillhub-spec.md` | 核心操作区不再出现平台发布资料；分层表明确每层读什么 |
| 结构清晰 4.8 | "内容分类直观，查找规则、样例和工具都较方便。主要小问题是部分平台发布资料混在核心操作中，浏览时容易分散注意力。" | 前半**保留强化**；后半**需修订** | 新增独立 `references/publishing-guide.md` 承载两平台发布流程；`SKILL.md` §9 保留完整资源索引 | `SKILL.md` §9、`references/publishing-guide.md`（新增） | 发布资料与核心流程物理分离；资源索引含每个文件的用途 |

---

## 5. E · Effectiveness 有效性（原 4.5/5）

| 子项 / 得分 | 原评价（原文） | 归类 | 处理方式 | 对应文件 | 修订结果 |
| --- | --- | --- | --- | --- | --- |
| 维度总评 4.5 | "整体质量较高，规则、价格依据和失败处理都很严谨，能明显减少误操作。主要不足是自动生成结果仍有占位内容，直接交付前还需要人工补全。" | 前半保留 + 后半 P0 修订 | 流水线末端自动合并回填，输出无占位最终表 | `scripts/run_pipeline.py`（`merge_deliverables`）、`DELIVERY_MANIFEST.md` | 实跑「已回填 6 行主表；合并 JSON 含 variants=6 costs=6 rerun_rules=5」 |
| 输出准确性 4.6 | "多数规则和价格处理准确可靠，但少数成本比较方式容易让人误解，仍需注意统计口径。" | 前半**保留强化**；后半**需修订** | 在成本输出中显式加入 `scope_notice`、`coverage`、`is_lower_bound`、`comparison_warning`；三档对比按画质一列标「假设系数、不作报价」；成本总表副表注明覆盖范围 | `scripts/estimate_cost.py`、`scripts/run_pipeline.py`（`cost_summary_<pid>.md`）、`references/pricing-fields.md` §一 | 实跑输出「统计口径=3/6 条已核实；该数值是下界，不是全量报价」+「覆盖镜头数不同的列不要直接比大小」 |
| 内容完整度 4.5 | "覆盖的场景很全面，连常见异常也有交代；但自动产出仍有占位内容，不能完全省去人工整理。" | 前半**保留强化**；后半**需修订 · P0** | `generate_variants.py` 输出完整提示词；`run_pipeline.py` 回填成本；`DELIVERY_MANIFEST.md` 汇总全部产物 | `scripts/generate_variants.py`、`scripts/run_pipeline.py`、`dist/DELIVERY_MANIFEST.md` | 示例产物 `placeholder_count=0`；异常场景（缺字段、坏镜头、超长镜、参考图超限）均有显式处理 |
| 创造力与增值 4.9 | "不只是改写文案，还提供省钱试跑、失败诊断和版本管理，能持续改善后续成片质量。" | **保留强化 · 近满分 · 不得削弱** | 三项能力逐条写入 `MEMORY.md` §1 并标「不得移除」；`cheapest_plan`、`rerun_rules`、`prompt_id` 升级规则保持并随流水线自动产出 | `MEMORY.md` §1/§6、`scripts/estimate_cost.py`、`scripts/generate_variants.py`、`references/platform-syntax.md` §六 | 未削弱；最省方案、失败诊断、版本管理均在一键流水线中自动生成 |
| 开箱即用度 4.2 | "操作说明清楚，脚本容易启动，但想直接拿到可用成品仍需补步骤和整理内容。" | 前半**保留强化**；后半**需修订** | 新增 `run_pipeline.py` 一条命令跑完 5 步；`README.md` 给「最快上手」；`templates/storyboard_input_template.json` 可直接改写 | `scripts/run_pipeline.py`、`README.md`、`templates/storyboard_input_template.json`、`dist/DELIVERY_MANIFEST.md` | 实跑 `python scripts/run_pipeline.py --demo --outdir ./dist` 一次通过，产出 17 个文件（含 2 个 ZIP） |

---

## 6. 修订结果验证（可复核）

| 验证项 | 命令 | 结果 |
| --- | --- | --- |
| 一键流水线 | `python scripts/run_pipeline.py --demo --outdir ./dist` | **5 步全通过**，产物 17 个（含 2 个 ZIP） |
| 完整提示词 | 检查 `full_prompts_demo-001.md` | 6 条变体 `paste_ready=True`，`placeholder_count=0` |
| 成本区间 | 检查 `cost_estimate_demo-001.json` | 已核实基础成本 **142.0**，含重试区间 **[170.4, 213.0]**，待核实行 **3**，覆盖 **3/6** |
| 统计口径 | 检查 `scope_notice` / `comparison_warning` | 均存在并写入成本总表 |
| 双平台 ZIP | `workbuddy_upload_...zip` / `skillhub_upload_...zip` | **均约 120 KB、各 26 个文件**（精确字节数以 `manifest_*.json` 实时记录为准）；前者 `SKILL.md` 在 `prompt-optimizer/`，后者在包根 |
| 规范自检 | `validate_open_platform.py --platform both` | **PASS=29 / WARN=3 / FAIL=0**；WorkBuddy 8 必填 + SkillHub 5 必填均齐；3 个 WARN 为 `assets/` 待确认格式与 4 类占位符提醒 |
| 人话体检 | `doctor.py --skill-dir .` | 仅 1 项 WARN：作者占位符待替换；无阻断项 |
| 幂等性 | 同输入重复跑 | `142.0 / [170.4, 213.0]` 两次一致 |
| 凭证扫描 | `manifest_*.json` → `secret_scan` | `passed=true`，`hits=[]` |

---

## 7. 待核实与未解决项（如实标注，不编造）

| 项 | 状态 | 说明 |
| --- | --- | --- |
| `slug` / `author` / `license` / `category` | **待用户填写** | 用户未提供，用占位符；SkillHub 上传前必须替换 |
| 即梦现行每秒积分 | **待核实** | 活动价 2026-11-05 已截止，官方页未给现行值；兜底为 5 秒样片反推 |
| Vidu 原生音频加价、Q2 主定价表 | **待核实** | 官方页为动态渲染，取回的是文本快照；相关镜头整行标「待核实」 |
| 可灵国内站口径、会员货币单位 | **待核实** | 国际站 `klingai.com` 文本快照；国内站未取到可靠来源 |
| WorkBuddy ZIP ≤3MB、目录 ≤2 层 | **待核实** | 第三方实践文章口径，官方《技能》页未明示；从严执行 |
| SkillHub ZIP ≤10MB、SKILL.md 须在包根 | **待核实** | 第三方文章与评测口径；官方教程表述为「Skill 文件夹根目录下的 SKILL.md」；已按更严格口径出包 |
| `assets/` 目录支持性 | **待确认格式** | WorkBuddy 官方当期文档未列出；若解析失败按降级方案平移到 `references/` |
| 平台审核结果 | **不由本 skill 负责** | 上传与提交审核由用户本人在平台侧完成，不承诺上架成功 |
