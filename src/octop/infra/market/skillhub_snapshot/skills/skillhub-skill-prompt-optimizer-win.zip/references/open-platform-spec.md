# WorkBuddy 开放平台规范回查记录与字段映射说明

> 回查日期：**2026-11-12（GMT+8）**（v1.0.0 曾于 2026-11-11 回查，本次为 v2.0.0 复核，结论一致）
> 本文件记录上传包第 1 步（强制规范回查）的完整证据链，供上传前自检与复核。
> **v2.0.0 新增 SkillHub 目标平台**，其规范回查与两平台冲突对照见 `skillhub-spec.md`；发布流程见 `publishing-guide.md`。

---

## 一、一手来源：官方《技能》文档

【结论】开放平台当期要求 `SKILL.md` 使用 YAML frontmatter + Markdown 正文，官方列出的 frontmatter 必填字段共 **8 个**。

【原文】"**字段****必填****说明** name 是 技能标识 / display_name 是 技能在市场上的中文展示名称 / display_name_en 是 技能在市场上的英文展示名称 / description 是 写清用途和触发词 / description_zh 是 简短中文介绍，在市场上展示在技能详情页 / description_en 是 简短英文介绍 / allowed-tools 否 工具白名单（逗号分隔） / version 是 版本号 / examples_zh 否 / examples_en 否 / author 是 合作方名称"（引自：WorkBuddy 开放平台《技能》，页面未标注发布日期，https://open.workbuddy.cn/docs/skill ，抓取日期 2026-11-12）

【结论】官方给出的技能基础结构为 `{skill-name}/SKILL.md` + 三个可选资源目录。

【原文】"{skill-name}/ ├── SKILL.md # ★ 技能定义（必须） ├── references/ # 参考资料（可选） ├── scripts/ # 可执行脚本（可选） └── templates/ # 模板文件（可选）"（引自：同上，https://open.workbuddy.cn/docs/skill ）

【结论】官方规定参考资料的引用方式为 `@references/xxx.md`。

【原文】"使用方式：在 SKILL.md 中通过 @references/xxx.md 引用。"（引自：同上，https://open.workbuddy.cn/docs/skill ）

【结论】官方英文版文档与中文版字段口径一致，可交叉验证。

【原文】"Field Required Description / name Yes Skill identifier / display_name Yes Chinese display name of the skill in the marketplace / description Yes State the purpose and trigger words / version Yes Version number / author Yes Partner name"（引自：WorkBuddy Open Platform《Skill》，https://open.workbuddy.cn/en/docs/skill ，抓取日期 2026-11-12）

【结论】发布需经平台审核，本 skill 只产出上传包，不承诺上架。

【原文】"开发者使用开放平台通常需要经过以下步骤：... 5. 提交平台审核 6. 审核通过后发布上线"（引自：WorkBuddy 开放平台《开放平台概述》，https://open.workbuddy.cn/docs ，抓取日期 2026-11-12）

---

## 二、二手来源：包大小上限与目录层级（标 `待核实`）

【结论】ZIP 包体积上限 3MB、目录最多两个层级、必填字段清单，来自第三方实践文章，**官方《技能》文档页未明示**，故标 `待核实`，并以平台后台实际校验为准。

【原文】"坑 1：体积。压缩包不能超过 3MB。"、"要点：目录最多两个层级；SKILL.md 用 YAML frontmatter + Markdown 正文，其中 description、description_zh、description_en、version、author 是必填。"、"坑 2：敏感信息。打包前请务必清掉 API Key、密码、Cookie 这类只属于你自己的东西——它们一旦被打进包里，上架后就等于公开了。"（引自：大数跨境《把自己做的 Skill 传上 WorkBuddy 商城：完整流程 + 三个最容易踩的坑》，作者「扣子」，2026-10-02，https://m.10100.com/article/152897587 ，抓取日期 2026-11-12）

【原文】"平台接收的是 ZIP 压缩包，大小不超过 3MB。"、"官方文档展示的目录结构是 skills/{skill-name}/SKILL.md，目录最多两个层级，参考资料、脚本和模板可以按需要放在 references/、scripts/、templates/ 里。"（引自：ima 知识库收录文章《@AI Coding（每日更新 ing）》，页面未标注发布日期，https://ima.qq.com/wiki/?shareId=b5e3d74f81582ce20077a9e684b3415cfa026eda4a6a8190753c7fc90d38f8c2 ，抓取日期 2026-11-12）

【我的判断】两篇第三方文章对 3MB 与「目录最多两个层级」表述一致，可作为工程约束采纳；但因非官方一手明示，本包按 **3MB / 两层级** 从严自检，同时在交付说明中标注 `待核实`，避免把二手口径冒充官方规范。

---

## 三、字段映射说明（两套规范冲突与取舍）

> **v2.0.0 补充**：本表原为「skill-creator 通用规范 vs WorkBuddy 开放平台」的对照。
> 新增 SkillHub 后变成**三套口径**，完整三列对照表与必填字段并集见 `skillhub-spec.md` 第三节。
> 结论不变：**一律以各平台当期官方文档为准**，禁止凭记忆写死或臆造字段。
> 另外，`assets/` 目录在 SkillHub 侧属宽容范围（第三方评测口径，标待核实），仅在 WorkBuddy 侧标「待确认格式」。

用户规格与 skill-creator 内置模板采用另一套（Claude/Anthropic 系）规范，与开放平台当期规范存在差异。**一律以当期官方开放平台文档为准。**

| 维度 | skill-creator / 通用规范 | WorkBuddy 开放平台（当期官方） | 本包取舍 |
| --- | --- | --- | --- |
| 必填 frontmatter | `name`、`description` | `name`、`display_name`、`display_name_en`、`description`、`description_zh`、`description_en`、`version`、`author` | **采用官方 8 字段** |
| 可选 frontmatter | `license`、`allowed-tools`、`metadata` | `allowed-tools`、`examples_zh`、`examples_en` | 采用官方，另加 3 条中英文示例 |
| 触发词位置 | description 内 | "description 是 写清用途和触发词" | 已写入 description |
| 资源目录 | `scripts/`、`references/`、`assets/` | `references/`、`scripts/`、`templates/` | 官方三目录全建；`assets/` 按用户规格保留并标 `待确认格式` |
| 校验器 | `quick_validate.py` 仅允许 `name/description/license/allowed-tools/metadata` | 无官方校验工具可公开调用 | 另写 `scripts/validate_open_platform.py`，**不用 quick_validate.py 作准** |
| 包格式 | 目录 | ZIP（第三方文章明示） | ZIP |

【结论】直接套用 skill-creator 自带校验器会误报。

【原文】"ALLOWED_PROPERTIES = {'name', 'description', 'license', 'allowed-tools', 'metadata'}"、"Unexpected key(s) in SKILL.md frontmatter"（引自：本地文件 `skill-creator/scripts/quick_validate.py`，路径 `C:\Users\winston\.workbuddy\plugins\cache\codebuddy-plugins-official\hotskills\1.0.0\skills\skill-creator\scripts\quick_validate.py`，抓取日期 2026-11-12）

【我的判断】若用该校验器校验本包，`display_name`、`display_name_en`、`description_zh`、`description_en`、`version`、`author`、`examples_zh`、`examples_en` 会被全部判为 "Unexpected key(s)"。该结果属**规范错配**，不是本包缺陷。已在 SKILL.md「校验器适配说明」中显式声明。

---

## 四、适配损失说明（不得静默删内容）

| 用户规格要求 | 当期官方支持情况 | 处置 |
| --- | --- | --- |
| `assets/`（示例输出） | 官方《技能》基础结构**未列出**该目录 | 保留目录，标 `待确认格式`；若上传解析失败，把 `assets/` 内文件平移到 `references/` 根目录后重打包，内容不删 |
| 目录内放主表/副表/口径卡/映射/质检表/字段映射说明/README | 官方仅列 `references/`、`scripts/`、`templates/` | 全部文件平铺在 `references/` 与包根，不建第三层目录，满足「最多两个层级」 |
| 包内附 `project_id` | 无真实项目输入 | 用 `demo-001` 作示例占位，所有示例数据显式标注「示例，非真实项目」 |
| 平台校验工具 | 官方未提供可公开调用的校验器 | 自带 `scripts/validate_open_platform.py` 按当期规范自检，输出逐项结果 |

---

## 五、上传前自检清单（对应 SKILL.md 产物导出第 5 步）

- [ ] 目录名为 `prompt-optimizer/`，与 frontmatter `name` 完全一致
- [ ] `SKILL.md` 存在，UTF-8 **无 BOM**，以 `---` 开头
- [ ] 8 个官方必填 frontmatter 字段齐全，`description` 内含触发词
- [ ] 目录层级 ≤ 2，无多余外层包裹目录
- [ ] ZIP 体积 < 3MB（`待核实` 上限，从严执行）
- [ ] 所有 `待核实` 价格保持原字样，未被伪装成确定值；过期活动价标注 `已过期-禁止使用`
- [ ] 包内无 API Key / 密码 / Cookie / 账号凭证 / 会员账号 / 真实用户数据（脚本正则扫描）
- [ ] 所有示例输出标注「示例」
- [ ] `scripts/validate_open_platform.py --platform both` 执行返回 `FAIL=0`
- [ ] 边界声明齐备：不代替平台审核、不承诺上架成功

---

## 六、v2.0.0 双平台补充自检

- [ ] 两个 ZIP 均已生成：`workbuddy_upload_*.zip`（`prompt-optimizer/SKILL.md`）与 `skillhub_upload_*.zip`（包根 `SKILL.md`）
- [ ] SkillHub 版 frontmatter 含 `slug` / `displayName` / `version` / `summary` / `license`，`description` 用块标量
- [ ] 4 类 `REPLACE_WITH_` 占位符已在 `CHANGELOG.md` / `publishing-guide.md` 明确列出，未被伪装成真实值
- [ ] `build_upload_package.py` 打包前凭证扫描通过，`manifest_*.json` 含逐文件 SHA-256
- [ ] `MEMORY.md` §6「不得削弱清单」逐项勾选，`CHANGELOG.md` 已声明未削弱
- [ ] `SKILL.md` 核心操作区不再混有平台发布资料（已剥离至 `publishing-guide.md`）

**失败与回退**：若平台规范回查不到 → 按共识结构（ZIP + SKILL.md）出包并标 `待确认格式`，附本字段映射说明，不臆造字段；若平台解析失败 → 按第四节降级（移除 `assets/`）后重打包，并在交付说明中列出具体缺失字段与修正版。
