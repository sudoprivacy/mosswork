# 发布与打包指南（L3 · 从核心流程剥离）

> 对应 TRACE「结构清晰 4.8：部分平台发布资料混在核心操作中」与「渐进式披露 4.5：一次读完整套资料仍会觉得信息偏多」。
> 本文件承载全部平台发布细节；`SKILL.md` 核心流程只留一个指向本文件的链接。
> 规范回查日期 **2026-11-12**；一手规范原文见 `open-platform-spec.md`（WorkBuddy）与 `skillhub-spec.md`（SkillHub）。

---

## 1. 完整目录结构（v2.0.0 · 26 个文件）

```
prompt-optimizer/
├── SKILL.md                              # ★ 技能定义（WorkBuddy 当期 8 必填字段 + 全部指令正文）
├── README.md                             # 中文说明：安装、最快上手、3 条触发示例、边界
├── CHANGELOG.md                          # ★ 按 TRACE 维度的变更说明（原评价/处理方式/文件/结果）
├── MEMORY.md                             # ★ 长期记忆与维护说明（不得削弱清单）
├── FAQ.md                                # ★ 集中常见问题清单（快速查询）
├── references/
│   ├── platform-syntax.md                # 三平台原生语法、负向词基线、一致性护栏、废片映射
│   ├── pricing-fields.md                 # 定价字段字典 + 当期回查原文与状态 + 国内访问提示
│   ├── open-platform-spec.md             # WorkBuddy 规范回查与字段映射
│   ├── skillhub-spec.md                  # SkillHub 规范回查与两平台差异
│   ├── publishing-guide.md               # 本文件
│   ├── trace-evaluation.md               # TRACE 原评价逐项归档（追溯底稿）
│   └── example-deliverables.md           # 示例主表/副表/单价口径卡/映射/质检与废片原因表
├── scripts/
│   ├── generate_variants.py              # 生成三平台完整提示词（paste_ready）
│   ├── estimate_cost.py                  # 成本区间、统计口径、三档对比、最省方案
│   ├── build_upload_package.py           # 一键构建双平台 ZIP + 哈希清单
│   ├── doctor.py                         # 人话诊断 + --fix 自动修复
│   ├── validate_open_platform.py         # 双平台规范自检（含 --fix）
│   └── run_pipeline.py                   # 一键编排全流程，内置成本回填合并
├── templates/
│   ├── storyboard_input_template.json    # 输入模板（含 rates，生成与估算共用）
│   ├── variant_table_template.csv        # 变体表模板
│   ├── parameter_card_template.md        # 参数卡模板
│   └── prompt_variants_schema.json       # 机器可读产出 JSON Schema
└── assets/
    ├── example_prompt_variants_demo-001.csv      # 由脚本真实生成的示例主表
    ├── example_prompt_variants_demo-001.json     # 示例机器可读结果（variants/costs/rerun_rules）
    ├── example_full_prompts_demo-001.md          # 示例三平台完整提示词全文
    └── example_cost_summary_demo-001.md          # 示例成本总表副表
```

**层级**：所有文件位于 `{skill-name}/` 或 `{skill-name}/<资源目录>/`，共 2 层，满足两平台「目录最多两个层级」的第三方口径（标 `待核实`）。

> **适配损失说明**：WorkBuddy 官方当期文档只列 `references/`、`scripts/`、`templates/`，**未列 `assets/`**。本包按用户规格保留 `assets/`，标 `待确认格式`；若平台解析失败，把 `assets/` 内 4 个文件平移到 `references/` 根目录后重新打包，**内容不删**。

---

## 2. 双平台包结构差异

| 项 | WorkBuddy ZIP | SkillHub ZIP |
| --- | --- | --- |
| 文件名 | `workbuddy_upload_prompt-optimizer_<project_id>_<日期>.zip` | `skillhub_upload_prompt-optimizer_<project_id>_<日期>.zip` |
| `SKILL.md` 位置 | `prompt-optimizer/SKILL.md` | `SKILL.md`（包根） |
| frontmatter | 官方 8 必填（蛇形）+ 可选 | 5 必填 + 兼容字段（含驼峰 `displayName`）+ WorkBuddy 字段 |
| `description` | 单行字符串（官方示例风格） | YAML 块标量 `description: >`（避免单行过长被拒） |
| 体积上限 | 3MB（第三方口径，待核实） | 10MB（第三方口径，待核实） |
| 结构依据 | 官方《技能》 https://open.workbuddy.cn/docs/skill | 官方教程 https://www.skillhub.cn/tutorials + 第三方评测口径 |

**为什么是两个包**：见 `skillhub-spec.md` 第四节——两平台对 `SKILL.md` 位置要求互斥，一个 ZIP 无法同时满足。

---

## 3. 一键构建与自检

```bash
# 一键跑完全流程（含打包）
python scripts/run_pipeline.py --demo --outdir ./dist
python scripts/run_pipeline.py --input storyboard.json --outdir ./dist

# 只打包（文档已就绪时）
python scripts/build_upload_package.py --source ./prompt-optimizer --outdir ./dist \
    --project-id demo-001 --target both
python scripts/build_upload_package.py --source ./prompt-optimizer --dry-run

# 双平台规范自检
python scripts/validate_open_platform.py --skill-dir ./prompt-optimizer --platform both \
    --zip ./dist/workbuddy_upload_prompt-optimizer_demo-001_2026-11-12.zip \
    --zip-skillhub ./dist/skillhub_upload_prompt-optimizer_demo-001_2026-11-12.zip

# 人话体检 + 自动修复
python scripts/doctor.py --skill-dir ./prompt-optimizer --fix
```

`manifest_<project_id>_<日期>.json` 记录：每个文件的路径、字节数、SHA-256，两个 ZIP 的结构/体积自检结果，以及 `secret_scan` 结果。**该清单不打包进 ZIP**，随交付物单独提供。

---

## 4. 必须替换的占位符（用户未提供，不编造）

| 占位符 | 含义 | 出现在 | 怎么填 |
| --- | --- | --- | --- |
| `REPLACE_WITH_YOUR_UNIQUE_SLUG` | SkillHub 全网唯一标识 | SkillHub ZIP 内 `SKILL.md` 的 `slug` | kebab-case、2–128 字符，建议带你的 handle；**发布后不得再改** |
| `REPLACE_WITH_AUTHOR_OR_ORG` | 作者 / 合作方名称 | 两个包的 `author` | 填你的姓名或机构名 |
| `REPLACE_WITH_LICENSE` | 开源许可证 | SkillHub 包 `license` | 按实际情况填，例如 `MIT`（仅为常见取值示例，非替你决定） |
| `REPLACE_WITH_CATEGORY` | SkillHub 分类 | SkillHub 包 `category` | 按平台当期可选分类填写，未回查到枚举值 |
| `REPLACE_WITH_PROJECT_ID` | 项目 ID | 输入模板 | 真实项目 ID；示例用 `demo-001` |
| `REPLACE_WITH_*`（模板内） | 角色名、外貌锚点、场景、台词 | `templates/storyboard_input_template.json` | 逐字来自角色档案库；**不得由 AI 编造** |

> `doctor.py` 与 `validate_open_platform.py` 会把未替换的占位符列为 WARN 并逐条提示，不会静默放行。

---

## 5. 上传步骤（用户在平台侧完成）

### WorkBuddy 开放平台
1. 登录 <https://open.workbuddy.cn/> → 发布管理 → 技能 → 创建；
2. 上传 `workbuddy_upload_*.zip`；平台自动解析后补全基本信息；
3. 提交审核。解析失败时按第 1 节「适配损失说明」降级重打包。

### SkillHub
1. 按第 4 节替换占位符（尤其 `slug`）；
2. 解压 `skillhub_upload_*.zip`，对解压后的文件夹跑：
   ```bash
   skillhub publish <解压目录> --dry-run
   ```
   看到 `Dry-run passed` 再执行 `skillhub publish <解压目录> --changelog "按 TRACE 评测修订 v2.0.0"`；
3. 更新版本时保持 `slug` 不变、递增 `version`。

**边界**：本 skill 只生成上传包与本地自检结果，**不代替平台审核、不承诺上架成功**；实名认证、API Token 创建、上传与提交审核均由用户本人完成。包内不含任何 API Key / Token / Cookie。

---

## 6. 上传前自检清单

- [ ] 目录名为 `prompt-optimizer`，与 `name` 一致
- [ ] `SKILL.md` UTF-8 无 BOM、以 `---` 开头
- [ ] WorkBuddy 8 个必填字段齐全，`description` 含触发词
- [ ] SkillHub 5 个必填字段齐全，`slug` 为有效 kebab-case
- [ ] 4 类占位符已替换（未替换则明确知道会 WARN）
- [ ] 目录层级 ≤ 2，两个 ZIP 体积均在上限内
- [ ] 凭证扫描通过，无真实用户数据
- [ ] `待核实` 价格保持原字样，过期活动价标「已过期-禁止使用」
- [ ] 示例产物标注「示例，非真实项目」
- [ ] `CHANGELOG.md` 与 `MEMORY.md` 已随包更新，§6「不得削弱清单」逐项勾选
- [ ] 重新联网回查定价，更新 `pricing-fields.md` 抓取日期
