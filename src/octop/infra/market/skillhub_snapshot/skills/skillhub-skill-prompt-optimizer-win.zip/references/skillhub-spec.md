# SkillHub 发布规范回查记录

> 回查日期：**2026-11-12（GMT+8）**
> 用途：支撑 v2.0.0 新增「可直接上传到 SkillHub」的文件包；所有结论附原文与完整 URL。
> 缺失信息一律标 `待核实` 或 `REPLACE_WITH_` 占位符，**不编造字段、不臆造上限**。
> 与 WorkBuddy 官方规范的字段/结构冲突对照见 `open-platform-spec.md`。

---

## 一、官方一手来源

### 1.1 官方《教程》frontmatter 必填字段

【结论】SkillHub 官方教程要求 Skill 文件夹根目录下的 `SKILL.md` 头部包含 5 个字段：`slug`、`displayName`、`version`、`summary`、`license`。

【原文】"接下来准备好你的 Skill 文件夹，确保根目录下的 `SKILL.md` 头部包含以下 frontmatter，即可进行发布："（引自：SkillHub《SkillHub 教程 - AI Skills 安装与使用指南》「第五步：准备 Skill 并发布」节，https://www.skillhub.cn/tutorials ，回查 2026-11-12）

【原文·代码块】"slug: hello-skillhub-zhangsan / displayName: Hello SkillHub / version: 1.0.0 / summary: 我的第一个 Skill / license: MIT"（引自：同上，https://www.skillhub.cn/tutorials ）

【原文·参数含义】"`slug` Skill 的唯一标识，全网唯一 / `displayName` Skill 的对外展示名称 / `version` Skill 的版本号 / `summary` Skill 的简介与概述 / `license` Skill 的开源许可证"（引自：同上，https://www.skillhub.cn/tutorials ）

### 1.2 slug 唯一性与不可修改

【结论】`slug` 必须全网唯一；发布后更新版本时保持 `slug` 不变，只递增 `version`。

【原文】"⚠️ `slug` 必须**全网唯一**。请把示例中的 `hello-skillhub-zhangsan` 改成你自己专属的名字（例如带上你的 handle），否则发布时会因冲突失败。"、"更新 Skill 与首次发布流程一致：准备好最新的 Skill 文件，保持 `slug` 不变，其他字段（如 `version`、`displayName`、`summary` 等）按需修改"（引自：同上，https://www.skillhub.cn/tutorials ）

### 1.3 dry-run 预检

【结论】正式发布前应跑 `--dry-run` 本地预检；通过标志为 `Dry-run passed`。

【原文】"正式发布前，建议先用 `--dry-run` 做本地预检。该指令不会真正发布，只检查格式，几秒钟出结果"、"看到 `✓ Dry-run passed: <slug>@1.0.0` 表示本地校验通过。如果出现 `Error: SKILL.md 缺少 ...`，请回去检查 frontmatter 字段是否漏填，补齐后重试。"（引自：同上，https://www.skillhub.cn/tutorials ）

### 1.4 Agent 发布指令（另一份官方口径）

【结论】`https://skillhub.cn/ai/release.md` 是面向 Agent 的发布任务指令，其中列 3 个必填 + 5 个建议字段，与教程 5 字段口径存在差异；本包取**并集**以同时满足。

【原文】"每个 Skill 需包含合法 `SKILL.md`"、"front matter 必填 `slug`、`version`、`displayName`"、"`slug` 需为 kebab-case，长度 2-128"、"`version` 需为合法 SemVer（如 `1.0.0`）"、"建议检查但不阻断发布：`summary`、`description`、`tags`、`license`、`homepage`"、"不泄露完整 API Key"（引自：SkillHub Agent 发布指令页，https://skillhub.cn/ai/release.md ，回查 2026-11-12）

【原文·预检命令】"`skillhub publish <skill-path> --host \"https://api.skillhub.cn\" --dry-run`"（引自：同上，https://skillhub.cn/ai/release.md ）

> 【取回方式说明】该页面返回的是「Agent 发布任务指令」而非完整规范文档，WebFetch 明确提示"未包含…规范文档本身"。上述条目为页面实际给出的校验要求，已按原文引用；未提及的 ZIP 结构、大小上限等标 `待核实`。

### 1.5 安全准入（对应评测「双实验室交叉验证」）

【结论】SkillHub 上架前有三线并行安全审核，其中两线为实验室扫描。

【原文】"平台对所有发布内容进行多维度自动审核，结合关键词过滤与 AI 语义理解，识别违规与低质内容"、"每个 Skill 上架前都必须通过三线并行的安全审核流水线——内容合规过滤、科恩实验室深度漏洞扫描、云鼎实验室 AI 模型安全评估——全部通过才能自动上架，任一不通即刻拒绝。"（引自：SkillHub 官网首页，https://skillhub.cn/ ，回查 2026-11-12）

【我的判断】用户 TRACE 评测中的「双实验室交叉验证，无P0/P1级安全风险」与上述「科恩实验室 + 云鼎实验室」表述对应；这是依据官方文案作出的推断，不是评测原文。该结论已作为 T 5.0 红线写入 `MEMORY.md` §4。

---

## 二、第三方口径（标 `待核实`，从严执行但不冒充官方）

| 项 | 原文 | 来源 | 状态 |
| --- | --- | --- | --- |
| 必填 5 字段（另一套） | "必填字段五个：字段作用 name 技能名，跟文件夹名一致 description 一句话说清能干嘛 version 版本号 category 分类 platforms 适用平台" | 微信公众号《一文讲透SkillHub发布全流程》，http://mp.weixin.qq.com/s?__biz=MzI3NTM3NDExOA==&mid=2247486112&idx=1&sn=eeb0c98cacf5bf2b0903908c32cb1a08 | `待核实`（第三方），本包仍补上 `category`/`platforms` |
| ZIP 结构 | "先查 zip 结构，SKILL.md 必须在压缩包根目录，不能套在文件夹里，大小还有限制，超 10MB 直接拒收" | 同上 | `待核实`（第三方），按包根出包、按 10MB 校验 |
| TRACE 五维 / T 红线 | "平台还有个 TRACE 评测体系，五个维度打分：可信度、可靠性、适用性、规范性、有效性。T 是红线维度，触碰直接淘汰" | 同上 | 作为 `MEMORY.md` 优先级依据 |
| 版本号递增 | "同一个技能更新版本，新版本号必须比当前高。2.0.0 之后传 1.5.0，被弹回" | 同上 | 采纳，v2.0.0 > v1.0.0 |
| 体检项 | "目录结构 SKILL.md 是否在包根 多套一层 → 平台解析失败"、"必备字段 6 字段是否在 frontmatter顶层"、"敏感残留 个人绝对路径 / 硬编码凭证 / 手机号"、"编码安全 zip 内中文名是否带 UTF-8 标志" | SkillHub 社区《技能评测官》页面文本快照，https://www.skillhub.cn/skills/user_57af6244/skill-doctor-pro | `待核实`（第三方 skill 页面，JS 渲染，取搜索引擎收录快照） |
| `--fix` 与退出码 | "一键补字段：加 --fix 会尽力补齐缺失的顶层字段"、"退出码：0 可传 / 1 有风险 / 2 会被拒" | 同上 | 采纳为 `doctor.py` 设计口径 |
| 块标量建议 | "description 别写成一整行超长字符串：部分 YAML 解析器会拒绝加载单行长 description。用块标量写成多行更稳" | SkillHub 社区《发布 Skill 到国内 SkillHub》页面文本快照，https://skillhub.cn/skills/user_4edac78e/publish-skill-to-skillhub | 采纳；SkillHub 版 frontmatter 用 `description: >` |

---

## 三、两平台字段对照（本包取并集）

| 字段 | WorkBuddy 官方 | SkillHub 官方教程 | SkillHub Agent 指令 | 第三方文章 | 本 v2.0.0 处理 |
| --- | --- | --- | --- | --- | --- |
| `name` | 必填 | — | — | 必填 | 两版都写 |
| `display_name` | 必填 | — | — | — | WorkBuddy 版写 |
| `display_name_en` | 必填 | — | — | — | WorkBuddy 版写 |
| `description` | 必填 | — | 建议 | 必填 | 两版都写；SkillHub 版用块标量 |
| `description_zh` / `description_en` | 必填 | — | — | — | 两版都写 |
| `version` | 必填 | 必填 | 必填 | 必填 | 两版都写 `2.0.0` |
| `author` | 必填 | — | — | — | 两版都写，值用占位符 |
| `slug` | — | 必填 | 必填 | — | SkillHub 版写，值用占位符 |
| `displayName` | — | 必填 | 必填 | 示例含 | SkillHub 版写 |
| `summary` | — | 必填 | 建议 | — | SkillHub 版写 |
| `license` | — | 必填 | 建议 | 示例含 | SkillHub 版写，值用占位符 |
| `category` | — | — | — | 必填 | SkillHub 版写，值用占位符 |
| `platforms` | — | — | — | 必填 | SkillHub 版写 `[WorkBuddy, SkillHub]`（依据用户明确要求的两个发布目标） |
| `allowed-tools` | 可选 | — | — | — | 两版都写 |
| `examples_zh` / `examples_en` | 可选 | — | — | — | 两版都写（保留 A 5.0 触发范例） |

---

## 四、结构冲突与处置（重要）

| 平台 | 要求 | 依据 |
| --- | --- | --- |
| WorkBuddy | ZIP 内 `prompt-optimizer/SKILL.md`（一层包裹目录），`references/` `scripts/` `templates/` | 官方《技能》 https://open.workbuddy.cn/docs/skill |
| SkillHub | 官方教程："Skill 文件夹根目录下的 `SKILL.md`"；第三方评测口径进一步要求 ZIP 包根 | https://www.skillhub.cn/tutorials ；https://www.skillhub.cn/skills/user_57af6244/skill-doctor-pro |

【我的判断】**一个 ZIP 无法同时满足两种结构**，因此 `build_upload_package.py` 一次生成两个 ZIP：WorkBuddy 版保留一层目录，SkillHub 版剥离顶层并把动态注入 frontmatter 的 `SKILL.md` 放在包根。这是工程取舍，不属平台官方明示规则，已标 `待核实`。

---

## 五、上传前自检与边界

```bash
# 本包自检（不等同平台审核）
python scripts/validate_open_platform.py --skill-dir . --platform both \
    --zip ./dist/workbuddy_upload_prompt-optimizer_demo-001_2026-11-12.zip \
    --zip-skillhub ./dist/skillhub_upload_prompt-optimizer_demo-001_2026-11-12.zip

# SkillHub 平台侧预检（需用户已安装并登录 CLI）
skillhub publish <解压后的 skill 文件夹> --dry-run
skillhub publish <解压后的 skill 文件夹> --changelog "按 TRACE 评测修订 v2.0.0"
```

**边界**：本 skill 只生成上传包与本地自检结果，**不代替平台审核、不承诺上架成功**；上传、实名认证、Token 创建与提交审核均由用户本人完成。包内不含任何 API Key / Token / Cookie。
