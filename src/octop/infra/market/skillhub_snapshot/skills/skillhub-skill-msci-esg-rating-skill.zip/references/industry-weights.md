# MSCI ESG全行业Key Issue权重表

数据版本：与MSCI ESG Ratings Model v5.0配套
覆盖范围：158个Sub-Industry

注：带CS标志的议题为Company-Specific Key Issue，不适用于子行业内所有公司。

---

# Communication Services

## Advertising

G=47.9% | E=5% | S=47.2%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 47.9 |  |
| S | Human Capital Development | 27.1 |  |
| S | Privacy & Data Security | 20.1 |  |
| E | Carbon Emissions | 5 |  |

## Alternative Carriers

G=42% | E=5% | S=53%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 42 |  |
| S | Privacy & Data Security | 29 |  |
| S | Labor Management | 24 |  |
| E | Carbon Emissions | 5 |  |

## Broadcasting

G=50.9% | E=5.2% | S=44%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 50.9 |  |
| S | Labor Management | 22 |  |
| S | Privacy & Data Security | 22 |  |
| E | Carbon Emissions | 5 |  |
| E | Raw Material Sourcing | 0.2 | CS |

## Cable & Satellite

G=51% | E=9% | S=44%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 51 |  |
| S | Labor Management | 22 |  |
| S | Privacy & Data Security | 22 |  |
| E | Carbon Emissions | 9 |  |

## Integrated Telecommunication Services

G=44.6% | E=5% | S=50.3%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 44.6 |  |
| S | Labor Management | 25.5 |  |
| S | Privacy & Data Security | 24.8 |  |
| E | Carbon Emissions | 5 |  |

## Interactive Home Entertainment

G=43.7% | E=5% | S=61.3%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 43.7 |  |
| S | Human Capital Development | 35.8 |  |
| S | Privacy & Data Security | 24.8 |  |
| E | Carbon Emissions | 5 |  |
| S | Supply Chain Labor Standards | 0.4 | CS |
| S | Product Safety & Quality | 0.3 | CS |

## Interactive Media & Services

G=41.8% | E=5.2% | S=53.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41.8 |  |
| S | Privacy & Data Security | 28.9 |  |
| S | Human Capital Development | 23.9 |  |
| E | Carbon Emissions | 5 |  |
| E | Opportunities in Clean Tech | 0.2 | CS |
| S | Access to Finance | 0.2 | CS |

## Movies & Entertainment

G=47% | E=6.0% | S=46.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 47 |  |
| S | Human Capital Development | 22.9 |  |
| S | Privacy & Data Security | 19.7 |  |
| E | Carbon Emissions | 4.9 |  |
| S | Labor Management | 3.5 | CS |
| E | Water Stress | 0.7 | CS |
| S | Supply Chain Labor Standards | 0.5 | CS |
| S | Product Safety & Quality | 0.3 | CS |
| E | Opportunities in Green Building | 0.2 | CS |
| E | Product Carbon Footprint | 0.2 | CS |

## Publishing

G=48% | E=5.0% | S=47%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 48 |  |
| S | Human Capital Development | 27 |  |
| S | Privacy & Data Security | 20 |  |
| E | Raw Material Sourcing | 4.4 |  |
| E | Carbon Emissions | 0.6 | CS |

## Wireless Telecommunication Services

G=41.9% | E=5% | S=53.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41.9 |  |
| S | Privacy & Data Security | 28.9 |  |
| S | Labor Management | 23.9 |  |
| E | Carbon Emissions | 5 |  |
| S | Access to Finance | 0.2 | CS |

# Consumer Discretionary

## Apparel Retail

G=34.2% | E=15.9% | S=49.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 34.2 |  |
| S | Privacy & Data Security | 18.2 |  |
| S | Labor Management | 17.9 |  |
| S | Supply Chain Labor Standards | 9.1 |  |
| E | Raw Material Sourcing | 7.8 |  |
| E | Product Carbon Footprint | 7.8 |  |
| S | Chemical Safety | 4.7 |  |
| E | Carbon Emissions | 0.3 | CS |

## Apparel, Accessories & Luxury Goods

G=35.7% | E=22.4% | S=42.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35.7 |  |
| S | Labor Management | 17 |  |
| E | Raw Material Sourcing | 12.2 |  |
| S | Chemical Safety | 12.1 |  |
| S | Supply Chain Labor Standards | 10.3 | CS |
| E | Product Carbon Footprint | 10.2 |  |
| S | Controversial Sourcing | 2.6 | CS |

## Automotive Parts & Equipment

G=40.8% | E=18.7% | S=40.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 40.8 |  |
| S | Product Safety & Quality | 22.6 |  |
| E | Opportunities in Clean Tech | 17.9 |  |
| S | Labor Management | 17.9 |  |
| E | Toxic Emissions & Waste | 0.8 | CS |
| S | Chemical Safety | 0.1 | CS |

## Automotive Retail

G=38.8% | E=22.5% | S=38.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 38.8 |  |
| S | Labor Management | 21.3 |  |
| S | Privacy & Data Security | 16.4 |  |
| E | Opportunities in Clean Tech | 11 |  |
| E | Product Carbon Footprint | 10.4 |  |
| E | Carbon Emissions | 0.7 | CS |
| S | Product Safety & Quality | 0.5 | CS |
| E | Toxic Emissions & Waste | 0.4 | CS |
| S | Health & Safety | 0.4 | CS |

## Broadline Retail

G=35.6% | E=15.2% | S=49.2%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35.6 |  |
| S | Privacy & Data Security | 23.9 |  |
| S | Labor Management | 16.6 |  |
| E | Product Carbon Footprint | 7.2 |  |
| E | Raw Material Sourcing | 7 |  |
| S | Supply Chain Labor Standards | 4.1 | CS |
| S | Human Capital Development | 2.5 | CS |
| E | Carbon Emissions | 1 | CS |
| S | Chemical Safety | 0.9 | CS |
| S | Consumer Financial Protection | 0.8 | CS |
| S | Product Safety & Quality | 0.4 | CS |

## Casinos & Gaming

G=37% | E=21.3% | S=41.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37 |  |
| S | Labor Management | 21 |  |
| S | Product Safety & Quality | 15.7 |  |
| E | Carbon Emissions | 10.8 |  |
| E | Water Stress | 10.5 |  |
| S | Privacy & Data Security | 5 | CS |

## Computer & Electronics Retail

G=39.9% | E=11.7% | S=48.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 39.9 |  |
| S | Labor Management | 23.3 |  |
| S | Privacy & Data Security | 22.4 |  |
| E | Product Carbon Footprint | 11.7 |  |
| S | Supply Chain Labor Standards | 2.7 | CS |

## Distributors

G=51.4% | E=15.5% | S=33.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 51.4 |  |
| S | Labor Management | 29.4 |  |
| E | Product Carbon Footprint | 14.3 |  |
| S | Privacy & Data Security | 2.9 | CS |
| E | Opportunities in Clean Tech | 1.2 | CS |
| S | Controversial Sourcing | 0.7 | CS |

## Education Services

G=33% | E=8% | S=62%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Product Safety & Quality | 24 |  |
| S | Human Capital Development | 19 |  |
| S | Privacy & Data Security | 19 |  |
| E | Carbon Emissions | 8 |  |

## Footwear

G=36.1% | E=21.5% | S=42.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 36.1 |  |
| S | Labor Management | 17.1 |  |
| S | Chemical Safety | 14.1 |  |
| S | Supply Chain Labor Standards | 11.3 | CS |
| E | Raw Material Sourcing | 11.2 |  |
| E | Product Carbon Footprint | 10.3 |  |

## Home Improvement Retail

G=33.2% | E=21.8% | S=45.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.2 |  |
| S | Labor Management | 21.9 |  |
| S | Privacy & Data Security | 16.9 |  |
| E | Raw Material Sourcing | 12.9 |  |
| E | Product Carbon Footprint | 8.9 |  |
| S | Chemical Safety | 5 |  |
| S | Supply Chain Labor Standards | 1.6 | CS |

## Homebuilding

G=35.5% | E=29.1% | S=35.3%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35.5 |  |
| E | Opportunities in Green Building | 28.2 |  |
| S | Health & Safety | 20 |  |
| S | Product Safety & Quality | 15.2 |  |
| E | Opportunities in Clean Tech | 0.5 | CS |
| E | Biodiversity & Land Use | 0.2 | CS |
| E | Carbon Emissions | 0.2 | CS |
| S | Privacy & Data Security | 0.1 | CS |

## Homefurnishing Retail

G=34.6% | E=17.7% | S=47.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 34.6 |  |
| S | Labor Management | 18.9 |  |
| S | Privacy & Data Security | 18.9 |  |
| E | Product Carbon Footprint | 9.2 |  |
| E | Raw Material Sourcing | 8.5 |  |
| S | Chemical Safety | 5 |  |
| S | Supply Chain Labor Standards | 4.7 | CS |

## Hotels, Resorts & Cruise Lines

G=37.8% | E=20.4% | S=41.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37.8 |  |
| S | Labor Management | 20.9 |  |
| S | Privacy & Data Security | 17.1 |  |
| E | Water Stress | 9.6 |  |
| E | Carbon Emissions | 9.1 |  |
| S | Product Safety & Quality | 3.2 | CS |
| E | Toxic Emissions & Waste | 1.5 | CS |
| S | Human Capital Development | 0.3 | CS |
| E | Opportunities in Green Building | 0.2 | CS |
| S | Health & Safety | 0.2 | CS |

## Household Appliances

G=48.2% | E=14.3% | S=37.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 48.2 |  |
| S | Supply Chain Labor Standards | 17 |  |
| E | Electronic Waste | 13.8 |  |
| S | Controversial Sourcing | 13.3 |  |
| S | Labor Management | 6.4 | CS |
| S | Chemical Safety | 0.7 | CS |
| E | Product Carbon Footprint | 0.5 | CS |

## Housewares & Specialties

G=48.5% | E=14% | S=37.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 48.5 |  |
| S | Chemical Safety | 20.5 |  |
| E | Carbon Emissions | 14 |  |
| S | Supply Chain Labor Standards | 10 |  |
| S | Labor Management | 7 | CS |

## Leisure Facilities

G=40.7% | E=29.7% | S=29.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 40.7 |  |
| S | Labor Management | 22.6 |  |
| E | Water Stress | 17.6 |  |
| E | Carbon Emissions | 12.1 |  |
| S | Product Safety & Quality | 7 | CS |

## Leisure Products

G=45.8% | E=9.3% | S=44.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 45.8 |  |
| S | Supply Chain Labor Standards | 17.9 |  |
| S | Product Safety & Quality | 14.9 |  |
| S | Chemical Safety | 11.7 |  |
| E | Toxic Emissions & Waste | 3.2 | CS |
| E | Carbon Emissions | 2.9 |  |
| E | Packaging Material & Waste | 2.3 | CS |
| E | Product Carbon Footprint | 0.6 | CS |
| S | Human Capital Development | 0.4 | CS |
| E | Raw Material Sourcing | 0.3 | CS |

## Other Specialty Retail

G=38.9% | E=13.1% | S=47.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 38.9 |  |
| S | Labor Management | 22 |  |
| S | Privacy & Data Security | 21.9 |  |
| E | Product Carbon Footprint | 11.1 |  |
| E | Raw Material Sourcing | 1.9 | CS |
| S | Supply Chain Labor Standards | 1.5 | CS |
| S | Controversial Sourcing | 1 | CS |
| S | Chemical Safety | 0.5 | CS |
| S | Human Capital Development | 0.5 | CS |
| S | Product Safety & Quality | 0.5 | CS |
| E | Carbon Emissions | 0.1 | CS |

## Restaurants

G=33% | E=18.9% | S=48.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Product Safety & Quality | 19.6 |  |
| S | Labor Management | 15.7 |  |
| E | Packaging Material & Waste | 11.7 |  |
| S | Opportunities in Nutrition & Health | 11.7 |  |
| E | Raw Material Sourcing | 7 |  |
| S | Supply Chain Labor Standards | 1.1 | CS |
| E | Water Stress | 0.2 | CS |

## Specialized Consumer Services

G=39.3% | E=5% | S=55.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 39.3 |  |
| S | Product Safety & Quality | 21.7 |  |
| S | Human Capital Development | 11.8 |  |
| S | Labor Management | 11.2 | CS |
| S | Privacy & Data Security | 10.1 | CS |
| E | Carbon Emissions | 5 |  |
| S | Chemical Safety | 1 | CS |

## Textiles

G=37.9% | E=25.0% | S=38.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37.9 |  |
| S | Labor Management | 20.1 |  |
| S | Chemical Safety | 15 |  |
| E | Product Carbon Footprint | 11 |  |
| E | Raw Material Sourcing | 10.6 |  |
| E | Toxic Emissions & Waste | 3.4 | CS |
| S | Supply Chain Labor Standards | 3 | CS |

# Consumer Staples

## Agricultural Products & Services

G=33% | E=38.9% | S=28.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Water Stress | 15 |  |
| E | Biodiversity & Land Use | 15 |  |
| S | Community Relations | 11.1 |  |
| S | Supply Chain Labor Standards | 10.6 |  |
| E | Carbon Emissions | 8.3 |  |
| S | Health & Safety | 5.5 |  |
| S | Human Capital Development | 0.8 | CS |
| E | Product Carbon Footprint | 0.3 | CS |
| E | Toxic Emissions & Waste | 0.3 | CS |

## Brewers

G=33% | E=40.0% | S=26.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Water Stress | 18.1 |  |
| S | Product Safety & Quality | 13.4 |  |
| E | Packaging Material & Waste | 12.4 |  |
| E | Product Carbon Footprint | 9.5 |  |
| S | Health & Safety | 9.2 |  |
| S | Opportunities in Nutrition & Health | 3.4 | CS |

## Consumer Staples Merchandise Retail

G=33% | E=12.9% | S=54.3%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Labor Management | 15 |  |
| S | Supply Chain Labor Standards | 12 |  |
| S | Privacy & Data Security | 12 |  |
| S | Product Safety & Quality | 9 |  |
| E | Product Carbon Footprint | 6.9 |  |
| E | Raw Material Sourcing | 6 |  |
| S | Opportunities in Nutrition & Health | 6 |  |
| S | Chemical Safety | 0.3 | CS |

## Distillers & Vintners

G=35% | E=40% | S=25%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35 |  |
| E | Water Stress | 20 |  |
| S | Product Safety & Quality | 15 |  |
| E | Packaging Material & Waste | 10 |  |
| E | Product Carbon Footprint | 10 |  |
| S | Health & Safety | 10 |  |

## Drug Retail

G=33% | E=10% | S=47%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Product Safety & Quality | 19 |  |
| S | Privacy & Data Security | 19 |  |
| E | Product Carbon Footprint | 10 |  |
| S | Labor Management | 9 |  |

## Food Distributors

G=41% | E=23.2% | S=36.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41 |  |
| S | Product Safety & Quality | 22.2 |  |
| E | Product Carbon Footprint | 12 |  |
| E | Raw Material Sourcing | 11.2 |  |
| S | Opportunities in Nutrition & Health | 10.3 |  |
| S | Supply Chain Labor Standards | 1.7 | CS |
| S | Chemical Safety | 1.1 | CS |
| S | Labor Management | 0.8 | CS |

## Food Retail

G=33% | E=14.5% | S=52.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Labor Management | 16.9 |  |
| S | Product Safety & Quality | 13.7 |  |
| S | Privacy & Data Security | 13.7 |  |
| E | Product Carbon Footprint | 7.7 |  |
| E | Raw Material Sourcing | 6.8 |  |
| S | Opportunities in Nutrition & Health | 6.8 |  |
| S | Supply Chain Labor Standards | 1.4 | CS |

## Household Products

G=37.4% | E=38.6% | S=20.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37.4 |  |
| E | Packaging Material & Waste | 20.9 |  |
| S | Chemical Safety | 15.4 |  |
| E | Product Carbon Footprint | 10.2 |  |
| E | Raw Material Sourcing | 5.5 |  |
| S | Product Safety & Quality | 3.3 | CS |
| S | Health & Safety | 0.9 | CS |
| E | Carbon Emissions | 0.7 | CS |
| E | Toxic Emissions & Waste | 0.7 | CS |
| E | Electronic Waste | 0.6 | CS |
| S | Supply Chain Labor Standards | 0.5 | CS |

## Packaged Foods & Meats

G=33% | E=37.5% | S=29.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Product Safety & Quality | 13.7 |  |
| E | Water Stress | 12.5 |  |
| S | Opportunities in Nutrition & Health | 12.4 |  |
| E | Packaging Material & Waste | 9.5 |  |
| E | Raw Material Sourcing | 8.7 |  |
| E | Product Carbon Footprint | 6.8 |  |
| S | Health & Safety | 1.5 | CS |
| S | Supply Chain Labor Standards | 1.3 | CS |
| S | Human Capital Development | 0.3 | CS |
| S | Labor Management | 0.2 | CS |

## Personal Care Products

G=37.9% | E=40.0% | S=22.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37.9 |  |
| E | Packaging Material & Waste | 19 |  |
| S | Chemical Safety | 16.2 |  |
| E | Product Carbon Footprint | 10.7 |  |
| E | Raw Material Sourcing | 9.6 |  |
| S | Product Safety & Quality | 3.9 | CS |
| S | Human Capital Development | 1.4 | CS |
| E | Water Stress | 0.7 | CS |
| S | Supply Chain Labor Standards | 0.3 | CS |
| S | Controversial Sourcing | 0.2 | CS |

## Soft Drinks & Non-alcoholic Beverages

G=33% | E=36.4% | S=30.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Packaging Material & Waste | 16.2 |  |
| E | Water Stress | 13.8 |  |
| S | Opportunities in Nutrition & Health | 13.7 |  |
| S | Product Safety & Quality | 9.3 |  |
| E | Product Carbon Footprint | 6.1 |  |
| S | Health & Safety | 6 |  |
| S | Supply Chain Labor Standards | 1.1 | CS |
| E | Raw Material Sourcing | 0.3 | CS |
| S | Labor Management | 0.3 | CS |

## Tobacco

G=34% | E=24.9% | S=39.2%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 34 |  |
| S | Product Safety & Quality | 17.8 |  |
| S | Supply Chain Labor Standards | 14 |  |
| E | Packaging Material & Waste | 13 |  |
| E | Water Stress | 10.8 |  |
| S | Chemical Safety | 6.3 |  |
| E | Product Carbon Footprint | 1.1 | CS |
| S | Labor Management | 1.1 | CS |

# Energy

## Coal & Consumable Fuels

G=33% | E=38% | S=29%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Carbon Emissions | 12 |  |
| S | Health & Safety | 12 |  |
| E | Water Stress | 9 |  |
| E | Biodiversity & Land Use | 9 |  |
| S | Community Relations | 9 |  |
| E | Toxic Emissions & Waste | 8 |  |
| S | Labor Management | 8 |  |

## Integrated Oil & Gas

G=33% | E=40.7% | S=26.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Carbon Emissions | 13.9 |  |
| E | Biodiversity & Land Use | 13.9 |  |
| E | Toxic Emissions & Waste | 12.9 |  |
| S | Community Relations | 12.9 |  |
| S | Health & Safety | 12.9 |  |
| S | Labor Management | 0.6 | CS |

## Oil & Gas Drilling

G=33% | E=39.4% | S=27.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Health & Safety | 18.3 |  |
| E | Carbon Emissions | 14.5 |  |
| E | Biodiversity & Land Use | 14.3 |  |
| E | Toxic Emissions & Waste | 10.6 |  |
| S | Community Relations | 8.3 |  |
| S | Human Capital Development | 0.5 | CS |

## Oil & Gas Equipment & Services

G=35.6% | E=47.9% | S=16.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35.6 |  |
| E | Carbon Emissions | 19.6 |  |
| E | Biodiversity & Land Use | 18.8 |  |
| S | Health & Safety | 13.6 |  |
| E | Toxic Emissions & Waste | 9.2 |  |
| S | Human Capital Development | 1.7 | CS |
| S | Privacy & Data Security | 0.9 | CS |
| E | Water Stress | 0.3 | CS |
| S | Chemical Safety | 0.3 | CS |

## Oil & Gas Exploration & Production

G=33.6% | E=42.0% | S=24.3%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.6 |  |
| E | Carbon Emissions | 19.5 |  |
| S | Community Relations | 12.2 |  |
| E | Toxic Emissions & Waste | 11.1 |  |
| E | Biodiversity & Land Use | 11.1 |  |
| S | Health & Safety | 11.1 |  |
| S | Human Capital Development | 1 | CS |
| E | Water Stress | 0.3 | CS |

## Oil & Gas Refining & Marketing

G=39.4% | E=41.5% | S=19.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 39.4 |  |
| E | Carbon Emissions | 20.2 |  |
| E | Toxic Emissions & Waste | 10.6 |  |
| E | Opportunities in Clean Tech | 10.4 |  |
| S | Health & Safety | 9.9 |  |
| S | Labor Management | 8.2 | CS |
| S | Community Relations | 0.7 | CS |
| E | Biodiversity & Land Use | 0.3 | CS |
| S | Privacy & Data Security | 0.3 | CS |

## Oil & Gas Storage & Transportation

G=33.3% | E=38.6% | S=28.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.3 |  |
| E | Carbon Emissions | 17.9 |  |
| E | Biodiversity & Land Use | 16.6 |  |
| S | Community Relations | 14.2 |  |
| S | Health & Safety | 13.9 |  |
| E | Toxic Emissions & Waste | 3.7 | CS |
| E | Water Stress | 0.4 | CS |

# Financials

## Asset Management & Custody Banks

G=42.2% | E=5% | S=52.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 42.2 |  |
| S | Human Capital Development | 23.8 |  |
| S | Responsible Investment | 17.1 |  |
| S | Privacy & Data Security | 11.8 |  |
| E | Carbon Emissions | 5 |  |
| S | Consumer Financial Protection | 0.1 | CS |

## Commercial & Residential Mortgage Finance

G=24.5% | E=8.4% | S=57.2%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 24.5 |  |
| S | Human Capital Development | 15.9 |  |
| S | Privacy & Data Security | 14.2 |  |
| S | Consumer Financial Protection | 13.1 |  |
| S | Access to Finance | 10.8 |  |
| E | Climate Change Vulnerability | 4.5 |  |
| E | Financing Environmental Impact | 3.4 |  |
| S | Responsible Investment | 3.2 | CS |
| E | Carbon Emissions | 0.5 | CS |

## Consumer Finance

G=33% | E=5.0% | S=61.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Consumer Financial Protection | 22.9 |  |
| S | Human Capital Development | 18 |  |
| S | Privacy & Data Security | 13 |  |
| S | Access to Finance | 8 |  |
| E | Carbon Emissions | 4.8 |  |
| E | Climate Change Vulnerability | 0.1 | CS |
| E | Product Carbon Footprint | 0.1 | CS |

## Diversified Banks

G=33% | E=12.9% | S=54.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Human Capital Development | 15 |  |
| S | Consumer Financial Protection | 14.7 |  |
| E | Financing Environmental Impact | 12.8 |  |
| S | Privacy & Data Security | 12 |  |
| S | Access to Finance | 12 |  |
| S | Responsible Investment | 0.3 | CS |
| E | Climate Change Vulnerability | 0.1 | CS |

## Diversified Capital Markets

G=35% | E=15% | S=50%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35 |  |
| S | Human Capital Development | 20 |  |
| E | Financing Environmental Impact | 15 |  |
| S | Privacy & Data Security | 15 |  |
| S | Responsible Investment | 15 |  |

## Diversified Financial Services

G=34% | E=5.6% | S=60.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 34 |  |
| S | Human Capital Development | 18.1 |  |
| S | Consumer Financial Protection | 16 |  |
| S | Access to Finance | 11.5 |  |
| S | Privacy & Data Security | 8.5 |  |
| S | Responsible Investment | 6.3 | CS |
| E | Financing Environmental Impact | 4.3 |  |
| E | Carbon Emissions | 0.7 | CS |
| E | Climate Change Vulnerability | 0.6 | CS |

## Financial Exchanges & Data

G=58% | E=5% | S=37.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 58 |  |
| S | Human Capital Development | 33.8 |  |
| E | Carbon Emissions | 5 |  |
| S | Privacy & Data Security | 3.2 | CS |

## Insurance Brokers

G=48% | E=5% | S=47%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 48 |  |
| S | Human Capital Development | 27 |  |
| S | Privacy & Data Security | 20 |  |
| E | Climate Change Vulnerability | 5 |  |

## Investment Banking & Brokerage

G=41% | E=9.7% | S=49.3%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41 |  |
| S | Human Capital Development | 23.3 |  |
| S | Responsible Investment | 14 |  |
| S | Privacy & Data Security | 12 | CS |
| E | Financing Environmental Impact | 8.4 |  |
| E | Carbon Emissions | 1.3 | CS |

## Life & Health Insurance

G=35% | E=5.0% | S=60.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35 |  |
| S | Human Capital Development | 20 |  |
| S | Responsible Investment | 15 |  |
| S | Privacy & Data Security | 15 |  |
| S | Access to Finance | 10 |  |
| E | Climate Change Vulnerability | 4.9 |  |
| E | Carbon Emissions | 0.1 | CS |
| S | Product Safety & Quality | 0.1 | CS |

## Mortgage REITs

G=51% | E=5% | S=44%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 51 |  |
| S | Human Capital Development | 29 |  |
| S | Responsible Investment | 15 |  |
| E | Carbon Emissions | 5 |  |

## Multi-Sector Holdings

G=50.4% | E=5.8% | S=43.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 50.4 |  |
| S | Human Capital Development | 28.5 |  |
| S | Responsible Investment | 14.9 |  |
| E | Carbon Emissions | 4.8 |  |
| E | Climate Change Vulnerability | 0.5 | CS |
| E | Toxic Emissions & Waste | 0.5 | CS |
| S | Labor Management | 0.5 | CS |

## Multi-line Insurance

G=33% | E=14.1% | S=52.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Human Capital Development | 17.8 |  |
| E | Climate Change Vulnerability | 13.9 |  |
| S | Privacy & Data Security | 13.9 |  |
| S | Responsible Investment | 12.9 |  |
| S | Access to Finance | 7.9 |  |
| S | Consumer Financial Protection | 0.4 | CS |
| E | Financing Environmental Impact | 0.2 | CS |

## Property & Casualty Insurance

G=34.1% | E=17.6% | S=48.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 34.1 |  |
| S | Human Capital Development | 19.5 |  |
| E | Climate Change Vulnerability | 17.6 |  |
| S | Privacy & Data Security | 14.5 |  |
| S | Responsible Investment | 14.1 |  |
| S | Access to Finance | 0.3 | CS |

## Regional Banks

G=33.1% | E=12.9% | S=54.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.1 |  |
| S | Consumer Financial Protection | 16.4 |  |
| S | Human Capital Development | 13.1 |  |
| E | Financing Environmental Impact | 12.9 |  |
| S | Privacy & Data Security | 12.2 |  |
| S | Access to Finance | 12.2 |  |
| S | Responsible Investment | 0.2 | CS |

## Reinsurance

G=36.5% | E=16.8% | S=46.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 36.5 |  |
| S | Human Capital Development | 20.9 |  |
| E | Climate Change Vulnerability | 16.8 |  |
| S | Responsible Investment | 15.4 |  |
| S | Privacy & Data Security | 10.4 |  |

## Specialized Finance

G=53.1% | E=6.2% | S=40.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 53.1 |  |
| S | Human Capital Development | 30.7 |  |
| S | Access to Finance | 5.7 | CS |
| E | Carbon Emissions | 4.4 |  |
| S | Privacy & Data Security | 3.5 | CS |
| E | Financing Environmental Impact | 1.8 | CS |
| S | Responsible Investment | 0.8 | CS |

## Transaction & Payment Processing Services

G=37% | E=5% | S=57.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37 |  |
| S | Human Capital Development | 26 |  |
| S | Privacy & Data Security | 20.9 |  |
| S | Access to Finance | 10.7 |  |
| E | Carbon Emissions | 5 |  |
| S | Consumer Financial Protection | 0.3 | CS |

# Health Care

## Biotechnology

G=35% | E=10.1% | S=58.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35 |  |
| S | Human Capital Development | 25 |  |
| S | Product Safety & Quality | 19 |  |
| S | Access to Health Care | 14.9 |  |
| E | Toxic Emissions & Waste | 10 |  |
| E | Packaging Material & Waste | 0.1 | CS |

## Health Care Distributors

G=47.3% | E=5% | S=47.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 47.3 |  |
| S | Labor Management | 26.6 |  |
| S | Product Safety & Quality | 19.8 |  |
| E | Carbon Emissions | 5 |  |
| S | Privacy & Data Security | 1.3 | CS |

## Health Care Equipment

G=38.9% | E=5.1% | S=56.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 38.9 |  |
| S | Product Safety & Quality | 33.7 |  |
| S | Human Capital Development | 22 |  |
| E | Carbon Emissions | 5 |  |
| S | Privacy & Data Security | 0.3 | CS |
| E | Toxic Emissions & Waste | 0.1 | CS |
| S | Chemical Safety | 0.1 | CS |

## Health Care Facilities

G=35% | E=5% | S=60%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35 |  |
| S | Privacy & Data Security | 20 |  |
| S | Product Safety & Quality | 20 |  |
| S | Labor Management | 20 |  |
| E | Carbon Emissions | 5 |  |

## Health Care Services

G=35.1% | E=4.7% | S=59.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35.1 |  |
| S | Product Safety & Quality | 24.6 |  |
| S | Labor Management | 19.6 |  |
| S | Privacy & Data Security | 15 |  |
| E | Carbon Emissions | 4.5 |  |
| S | Human Capital Development | 0.4 | CS |
| E | Toxic Emissions & Waste | 0.2 | CS |
| S | Consumer Financial Protection | 0.2 | CS |

## Health Care Supplies

G=46.5% | E=6.6% | S=47.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 46.5 |  |
| S | Labor Management | 25.7 |  |
| S | Product Safety & Quality | 19.4 |  |
| E | Carbon Emissions | 4.5 |  |
| E | Toxic Emissions & Waste | 1.8 | CS |
| S | Supply Chain Labor Standards | 0.6 | CS |
| S | Privacy & Data Security | 0.5 | CS |
| S | Human Capital Development | 0.5 | CS |
| E | Water Stress | 0.3 | CS |
| S | Health & Safety | 0.3 | CS |

## Health Care Technology

G=48% | E=5% | S=47%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 48 |  |
| S | Privacy & Data Security | 27 |  |
| S | Human Capital Development | 20 |  |
| E | Carbon Emissions | 5 |  |

## Life Sciences Tools & Services

G=54.7% | E=5.2% | S=40.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 54.7 |  |
| S | Human Capital Development | 23.9 |  |
| S | Product Safety & Quality | 15.9 |  |
| E | Carbon Emissions | 5 |  |
| S | Privacy & Data Security | 0.3 | CS |
| E | Toxic Emissions & Waste | 0.2 | CS |

## Managed Health Care

G=33% | E=5% | S=62%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Privacy & Data Security | 24 |  |
| S | Product Safety & Quality | 19 |  |
| S | Human Capital Development | 19 |  |
| E | Carbon Emissions | 5 |  |

## Pharmaceuticals

G=33.2% | E=9.2% | S=57.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.2 |  |
| S | Product Safety & Quality | 27 |  |
| S | Human Capital Development | 18.1 |  |
| S | Access to Health Care | 12.5 |  |
| E | Toxic Emissions & Waste | 8.9 |  |
| E | Water Stress | 0.2 | CS |
| E | Packaging Material & Waste | 0.1 | CS |
| S | Chemical Safety | 0.1 | CS |
| S | Privacy & Data Security | 0.1 | CS |

# Industrials

## Aerospace & Defense

G=46.8% | E=13% | S=40.2%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 46.8 |  |
| S | Product Safety & Quality | 19.6 |  |
| S | Labor Management | 18.8 |  |
| E | Opportunities in Clean Tech | 13 |  |
| S | Human Capital Development | 1.1 | CS |
| S | Health & Safety | 0.7 | CS |

## Agricultural & Farm Machinery

G=41% | E=24% | S=35%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41 |  |
| S | Labor Management | 18 |  |
| S | Health & Safety | 17 |  |
| E | Opportunities in Clean Tech | 12 |  |
| E | Toxic Emissions & Waste | 12 |  |

## Air Freight & Logistics

G=41.1% | E=19.1% | S=39.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41.1 |  |
| S | Labor Management | 23.4 |  |
| E | Carbon Emissions | 18.6 |  |
| S | Health & Safety | 16.3 | CS |
| E | Toxic Emissions & Waste | 0.5 | CS |

## Airport Services

G=44.3% | E=19.2% | S=35.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 44.3 |  |
| S | Health & Safety | 19.1 |  |
| E | Biodiversity & Land Use | 18.7 |  |
| S | Community Relations | 15.9 |  |
| E | Raw Material Sourcing | 0.5 | CS |
| S | Product Safety & Quality | 0.5 | CS |

## Building Products

G=34.8% | E=39.7% | S=25.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 34.8 |  |
| E | Carbon Emissions | 14.8 |  |
| E | Toxic Emissions & Waste | 14.7 |  |
| S | Labor Management | 14.6 |  |
| S | Health & Safety | 9.6 |  |
| E | Opportunities in Clean Tech | 9.1 |  |
| S | Chemical Safety | 1.3 | CS |
| E | Raw Material Sourcing | 1.1 | CS |

## Cargo Ground Transportation

G=41.9% | E=22% | S=36.2%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41.9 |  |
| S | Labor Management | 24.4 |  |
| E | Carbon Emissions | 22 |  |
| S | Health & Safety | 11.8 |  |

## Commercial Printing

G=52.6% | E=14.7% | S=32.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 52.6 |  |
| S | Labor Management | 30.2 |  |
| E | Raw Material Sourcing | 14.7 |  |
| S | Privacy & Data Security | 1.3 | CS |
| S | Access to Finance | 1.2 | CS |

## Construction & Engineering

G=56.6% | E=16.9% | S=26.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 56.6 |  |
| S | Health & Safety | 22.8 |  |
| E | Opportunities in Clean Tech | 16.4 |  |
| S | Human Capital Development | 2.7 | CS |
| S | Labor Management | 0.6 | CS |
| S | Community Relations | 0.3 | CS |
| E | Toxic Emissions & Waste | 0.2 | CS |
| E | Water Stress | 0.2 | CS |
| E | Biodiversity & Land Use | 0.1 | CS |

## Construction Machinery & Heavy Transportation Equipment

G=40.5% | E=23.6% | S=35.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 40.5 |  |
| S | Labor Management | 17.7 |  |
| S | Health & Safety | 16.7 |  |
| E | Toxic Emissions & Waste | 11.8 |  |
| E | Opportunities in Clean Tech | 11.8 |  |
| S | Product Safety & Quality | 1.5 | CS |

## Data Processing & Outsourced Services

G=41.5% | E=5% | S=53.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41.5 |  |
| S | Human Capital Development | 29.7 |  |
| S | Privacy & Data Security | 22.8 |  |
| E | Carbon Emissions | 5 |  |
| S | Access to Finance | 0.5 | CS |
| S | Consumer Financial Protection | 0.5 | CS |

## Diversified Support Services

G=59.6% | E=7.9% | S=32.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 59.6 |  |
| S | Labor Management | 24.7 |  |
| E | Carbon Emissions | 5 |  |
| S | Privacy & Data Security | 4.1 | CS |
| E | Raw Material Sourcing | 2.9 | CS |
| S | Product Safety & Quality | 1.2 | CS |
| S | Health & Safety | 1.1 | CS |
| S | Human Capital Development | 0.8 | CS |
| S | Supply Chain Labor Standards | 0.6 | CS |

## Electrical Components & Equipment

G=44% | E=31.6% | S=24.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 44 |  |
| S | Labor Management | 23.5 |  |
| E | Opportunities in Clean Tech | 18.9 |  |
| E | Toxic Emissions & Waste | 12.7 |  |
| S | Human Capital Development | 0.5 | CS |
| S | Product Safety & Quality | 0.2 | CS |
| S | Health & Safety | 0.2 | CS |

## Environmental & Facilities Services

G=43.9% | E=23.2% | S=33.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 43.9 |  |
| S | Labor Management | 17.8 |  |
| E | Toxic Emissions & Waste | 13.3 | CS |
| S | Health & Safety | 12.3 |  |
| E | Carbon Emissions | 8 |  |
| E | Opportunities in Clean Tech | 1.9 | CS |
| S | Human Capital Development | 1.5 | CS |
| S | Community Relations | 0.6 | CS |
| S | Chemical Safety | 0.5 | CS |
| S | Product Safety & Quality | 0.3 | CS |

## Heavy Electrical Equipment

G=41.3% | E=35.0% | S=23.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41.3 |  |
| E | Opportunities in Clean Tech | 23.9 |  |
| S | Labor Management | 20.6 |  |
| E | Toxic Emissions & Waste | 10.7 |  |
| S | Human Capital Development | 2.6 | CS |
| S | Health & Safety | 0.5 | CS |
| E | Biodiversity & Land Use | 0.4 | CS |

## Highways & Railtracks

G=43.5% | E=19.0% | S=37.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 43.5 |  |
| S | Health & Safety | 18.8 |  |
| E | Biodiversity & Land Use | 18.4 |  |
| S | Community Relations | 17.4 |  |
| S | Human Capital Development | 0.9 | CS |
| E | Carbon Emissions | 0.6 | CS |
| S | Labor Management | 0.6 | CS |

## Human Resource & Employment Services

G=44% | E=5% | S=51%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 44 |  |
| S | Human Capital Development | 26 |  |
| S | Privacy & Data Security | 25 |  |
| E | Carbon Emissions | 5 |  |

## Industrial Conglomerates

G=46.5% | E=21.7% | S=31.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 46.5 |  |
| S | Labor Management | 22.5 |  |
| E | Opportunities in Clean Tech | 14.4 |  |
| S | Human Capital Development | 3.1 | CS |
| E | Toxic Emissions & Waste | 2.8 | CS |
| S | Product Safety & Quality | 2.4 | CS |
| S | Health & Safety | 1.8 | CS |
| E | Opportunities in Green Building | 1.2 | CS |
| S | Responsible Investment | 1.2 | CS |
| E | Carbon Emissions | 1 | CS |
| E | Water Stress | 0.8 | CS |
| E | Packaging Material & Waste | 0.7 | CS |
| E | Raw Material Sourcing | 0.6 | CS |
| S | Chemical Safety | 0.3 | CS |
| S | Privacy & Data Security | 0.3 | CS |
| S | Consumer Financial Protection | 0.3 | CS |
| E | Biodiversity & Land Use | 0.2 | CS |

## Industrial Machinery & Supplies & Components

G=46.6% | E=32.8% | S=20.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 46.6 |  |
| E | Opportunities in Clean Tech | 19.9 |  |
| S | Labor Management | 19.9 |  |
| E | Toxic Emissions & Waste | 12.9 |  |
| S | Product Safety & Quality | 0.7 | CS |
| S | Chemical Safety | 0.1 | CS |

## Marine Ports & Services

G=49.3% | E=20.8% | S=29.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 49.3 |  |
| S | Health & Safety | 28.6 |  |
| E | Biodiversity & Land Use | 20.8 |  |
| S | Labor Management | 0.8 | CS |
| S | Community Relations | 0.5 | CS |

## Marine Transportation

G=37.2% | E=46.2% | S=16.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37.2 |  |
| E | Toxic Emissions & Waste | 24.3 |  |
| E | Carbon Emissions | 20.2 |  |
| S | Health & Safety | 15.2 |  |
| E | Biodiversity & Land Use | 1.7 | CS |
| S | Human Capital Development | 0.9 | CS |
| S | Labor Management | 0.5 | CS |

## Office Services & Supplies

G=51.9% | E=8.7% | S=39.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 51.9 |  |
| S | Labor Management | 30 |  |
| S | Chemical Safety | 9.4 | CS |
| E | Carbon Emissions | 4.7 |  |
| E | Raw Material Sourcing | 1.7 | CS |
| E | Toxic Emissions & Waste | 1.3 | CS |
| E | Product Carbon Footprint | 1 | CS |

## Passenger Airlines

G=33% | E=19% | S=48%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Carbon Emissions | 19 |  |
| S | Product Safety & Quality | 16 |  |
| S | Labor Management | 16 |  |
| S | Privacy & Data Security | 16 |  |

## Passenger Ground Transportation

G=46.9% | E=15.1% | S=37.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 46.9 |  |
| S | Labor Management | 26.8 |  |
| E | Carbon Emissions | 15.1 |  |
| S | Health & Safety | 6.1 |  |
| S | Privacy & Data Security | 3 | CS |
| S | Product Safety & Quality | 2 | CS |

## Rail Transportation

G=34.5% | E=24.8% | S=40.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 34.5 |  |
| E | Carbon Emissions | 19.1 |  |
| S | Labor Management | 18.7 |  |
| S | Health & Safety | 18.4 |  |
| E | Opportunities in Green Building | 5.7 | CS |
| S | Community Relations | 3.6 | CS |

## Research & Consulting Services

G=43.3% | E=5% | S=51.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 43.3 |  |
| S | Human Capital Development | 25.5 |  |
| S | Privacy & Data Security | 24.6 |  |
| E | Carbon Emissions | 5 |  |
| S | Consumer Financial Protection | 1.6 | CS |

## Security & Alarm Services

G=37.4% | E=5% | S=57.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37.4 |  |
| S | Labor Management | 26.6 |  |
| S | Health & Safety | 26.4 |  |
| E | Carbon Emissions | 5 |  |
| S | Community Relations | 3.1 | CS |
| S | Privacy & Data Security | 1.5 | CS |

## Trading Companies & Distributors

G=51.5% | E=23.1% | S=25.2%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 51.5 |  |
| S | Labor Management | 20.7 |  |
| E | Opportunities in Clean Tech | 18.7 |  |
| E | Raw Material Sourcing | 2.6 | CS |
| S | Chemical Safety | 1.6 | CS |
| S | Human Capital Development | 1.5 | CS |
| E | Carbon Emissions | 0.8 | CS |
| E | Toxic Emissions & Waste | 0.6 | CS |
| S | Product Safety & Quality | 0.5 | CS |
| S | Health & Safety | 0.4 | CS |
| S | Community Relations | 0.3 | CS |
| E | Water Stress | 0.2 | CS |
| E | Biodiversity & Land Use | 0.2 | CS |
| S | Privacy & Data Security | 0.2 | CS |

# Information Technology

## Application Software

G=38.1% | E=15.9% | S=46.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 38.1 |  |
| S | Human Capital Development | 25.8 |  |
| S | Privacy & Data Security | 20.1 |  |
| E | Opportunities in Clean Tech | 9.6 |  |
| E | Carbon Emissions | 6.3 |  |
| S | Supply Chain Labor Standards | 0.1 | CS |

## Communications Equipment

G=38.2% | E=15.8% | S=45.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 38.2 |  |
| S | Human Capital Development | 19.9 |  |
| E | Opportunities in Clean Tech | 15.5 |  |
| S | Supply Chain Labor Standards | 11.4 |  |
| S | Controversial Sourcing | 10.3 |  |
| S | Privacy & Data Security | 2 | CS |
| S | Labor Management | 1.9 | CS |
| E | Toxic Emissions & Waste | 0.3 | CS |
| S | Product Safety & Quality | 0.3 | CS |

## Electronic Components

G=40.4% | E=14.0% | S=45.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 40.4 |  |
| S | Labor Management | 23 |  |
| S | Chemical Safety | 11.8 |  |
| E | Opportunities in Clean Tech | 11.4 |  |
| S | Controversial Sourcing | 10 |  |
| E | Water Stress | 1.5 | CS |
| E | Toxic Emissions & Waste | 1.1 | CS |
| S | Human Capital Development | 0.5 | CS |
| S | Supply Chain Labor Standards | 0.3 | CS |

## Electronic Equipment & Instruments

G=38.5% | E=16.8% | S=44.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 38.5 |  |
| S | Labor Management | 19.3 |  |
| E | Opportunities in Clean Tech | 16.8 |  |
| S | Controversial Sourcing | 10.8 |  |
| S | Chemical Safety | 10.8 |  |
| S | Human Capital Development | 2.2 | CS |
| S | Product Safety & Quality | 1.5 | CS |

## Electronic Manufacturing Services

G=40.5% | E=12.3% | S=46.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 40.5 |  |
| S | Labor Management | 23.7 |  |
| E | Opportunities in Clean Tech | 11.8 |  |
| S | Chemical Safety | 11.8 |  |
| S | Controversial Sourcing | 10.5 |  |
| S | Supply Chain Labor Standards | 0.8 | CS |
| E | Water Stress | 0.5 | CS |

## IT Consulting & Other Services

G=37.2% | E=19.3% | S=47.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37.2 |  |
| S | Human Capital Development | 26.2 |  |
| S | Privacy & Data Security | 21.1 |  |
| E | Opportunities in Clean Tech | 10.3 |  |
| E | Carbon Emissions | 9 |  |
| S | Controversial Sourcing | 0.2 | CS |

## Internet Services & Infrastructure

G=38.8% | E=11.3% | S=49.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 38.8 |  |
| S | Human Capital Development | 27.4 |  |
| S | Privacy & Data Security | 21.6 |  |
| E | Opportunities in Clean Tech | 5.9 | CS |
| E | Carbon Emissions | 5.4 |  |
| S | Product Safety & Quality | 0.5 | CS |
| S | Access to Finance | 0.3 | CS |

## Semiconductor Materials & Equipment

G=51.2% | E=19.4% | S=29.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 51.2 |  |
| S | Human Capital Development | 28.7 |  |
| E | Opportunities in Clean Tech | 14.3 |  |
| E | Water Stress | 3.4 | CS |
| E | Toxic Emissions & Waste | 1.2 | CS |
| E | Carbon Emissions | 0.5 | CS |
| S | Labor Management | 0.5 | CS |
| S | Supply Chain Labor Standards | 0.2 | CS |

## Semiconductors

G=40% | E=20.8% | S=33.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 40 |  |
| S | Human Capital Development | 22.7 |  |
| E | Opportunities in Clean Tech | 10.5 |  |
| S | Controversial Sourcing | 10.3 |  |
| E | Water Stress | 10.1 |  |
| S | Supply Chain Labor Standards | 0.4 | CS |
| E | Toxic Emissions & Waste | 0.1 | CS |
| E | Carbon Emissions | 0.1 | CS |

## Systems Software

G=39.4% | E=10.9% | S=49.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 39.4 |  |
| S | Human Capital Development | 27.9 |  |
| S | Privacy & Data Security | 21.7 |  |
| E | Opportunities in Clean Tech | 5.9 |  |
| E | Carbon Emissions | 5 |  |

## Technology Distributors

G=50% | E=15% | S=35%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 50 |  |
| S | Human Capital Development | 21 |  |
| E | Opportunities in Clean Tech | 15 |  |
| S | Controversial Sourcing | 14 |  |

## Technology Hardware, Storage & Peripherals

G=36% | E=21.3% | S=42.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 36 |  |
| S | Human Capital Development | 18.4 |  |
| E | Opportunities in Clean Tech | 12.6 |  |
| S | Supply Chain Labor Standards | 11 |  |
| S | Controversial Sourcing | 9.6 |  |
| E | Electronic Waste | 7.8 |  |
| S | Privacy & Data Security | 2 | CS |
| S | Labor Management | 1.5 | CS |
| E | Toxic Emissions & Waste | 0.7 | CS |
| E | Water Stress | 0.2 | CS |
| S | Health & Safety | 0.2 | CS |
| S | Product Safety & Quality | 0.2 | CS |

# Materials

## Aluminum

G=33% | E=42.0% | S=24.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Carbon Emissions | 14.5 |  |
| E | Toxic Emissions & Waste | 14.2 |  |
| E | Water Stress | 11.4 |  |
| S | Health & Safety | 11.4 |  |
| S | Labor Management | 11.4 |  |
| E | Biodiversity & Land Use | 1.9 | CS |
| S | Community Relations | 1.9 | CS |

## Commodity Chemicals

G=33% | E=55.1% | S=11.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Carbon Emissions | 14.8 |  |
| E | Toxic Emissions & Waste | 14.7 |  |
| E | Water Stress | 14.7 |  |
| S | Chemical Safety | 10.9 |  |
| E | Opportunities in Clean Tech | 10.8 |  |
| S | Health & Safety | 0.7 | CS |
| S | Community Relations | 0.2 | CS |
| E | Raw Material Sourcing | 0.1 | CS |
| S | Product Safety & Quality | 0.1 | CS |

## Construction Materials

G=33% | E=38.2% | S=28.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Carbon Emissions | 17.3 |  |
| E | Toxic Emissions & Waste | 16.5 |  |
| S | Health & Safety | 12.6 |  |
| S | Labor Management | 12.6 |  |
| S | Community Relations | 3.4 | CS |
| E | Biodiversity & Land Use | 2.8 | CS |
| E | Water Stress | 1.6 | CS |
| S | Product Safety & Quality | 0.1 | CS |

## Copper

G=33% | E=39.2% | S=28.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Toxic Emissions & Waste | 12.2 |  |
| S | Health & Safety | 12.2 |  |
| E | Carbon Emissions | 9.2 |  |
| E | Water Stress | 9.2 |  |
| E | Biodiversity & Land Use | 8.6 |  |
| S | Community Relations | 8.6 |  |
| S | Labor Management | 7.2 |  |

## Diversified Chemicals

G=33% | E=52.6% | S=14.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Water Stress | 13.8 |  |
| E | Carbon Emissions | 13.8 |  |
| E | Toxic Emissions & Waste | 13.8 |  |
| S | Chemical Safety | 13.6 |  |
| E | Opportunities in Clean Tech | 10.8 |  |
| E | Biodiversity & Land Use | 0.4 | CS |
| S | Health & Safety | 0.4 | CS |
| S | Product Safety & Quality | 0.4 | CS |
| S | Labor Management | 0.2 | CS |

## Diversified Metals & Mining

G=33.2% | E=38.7% | S=28.1%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.2 |  |
| E | Toxic Emissions & Waste | 11.8 |  |
| S | Health & Safety | 11.8 |  |
| E | Biodiversity & Land Use | 9 |  |
| S | Community Relations | 9 |  |
| E | Water Stress | 8.9 |  |
| E | Carbon Emissions | 8.9 |  |
| S | Labor Management | 6.9 |  |
| S | Human Capital Development | 0.4 | CS |
| E | Opportunities in Renewable Energy | 0.1 | CS |

## Fertilizers & Agricultural Chemicals

G=33% | E=51.1% | S=15.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Carbon Emissions | 14.9 |  |
| E | Water Stress | 14.9 |  |
| E | Toxic Emissions & Waste | 14.9 |  |
| S | Chemical Safety | 11.2 |  |
| E | Opportunities in Clean Tech | 6.4 |  |
| S | Health & Safety | 4.3 | CS |
| S | Community Relations | 0.3 | CS |

## Forest Products

G=33% | E=49.0% | S=19%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Biodiversity & Land Use | 19 |  |
| S | Health & Safety | 19 |  |
| E | Raw Material Sourcing | 13.7 |  |
| E | Carbon Emissions | 13 |  |
| E | Toxic Emissions & Waste | 3.3 | CS |

## Gold

G=33.5% | E=35.8% | S=30.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.5 |  |
| E | Toxic Emissions & Waste | 13 |  |
| S | Health & Safety | 11.1 |  |
| E | Biodiversity & Land Use | 9.9 |  |
| S | Community Relations | 9.9 |  |
| E | Water Stress | 8.3 |  |
| S | Labor Management | 8.3 |  |
| E | Carbon Emissions | 4.6 |  |
| S | Human Capital Development | 1.3 | CS |

## Industrial Gases

G=33.5% | E=59.0% | S=7.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.5 |  |
| E | Carbon Emissions | 18.1 |  |
| E | Water Stress | 17.5 |  |
| E | Toxic Emissions & Waste | 13.9 |  |
| E | Opportunities in Clean Tech | 9.5 |  |
| S | Health & Safety | 5.6 |  |
| S | Labor Management | 1.9 | CS |

## Metal, Glass & Plastic Containers

G=35% | E=35.6% | S=29.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 35 |  |
| E | Carbon Emissions | 19.8 |  |
| S | Labor Management | 19.8 |  |
| E | Packaging Material & Waste | 14.2 |  |
| S | Chemical Safety | 9.6 |  |
| E | Raw Material Sourcing | 1.1 | CS |
| E | Water Stress | 0.5 | CS |

## Paper & Plastic Packaging Products & Materials

G=33.2% | E=53.4% | S=13.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.2 |  |
| E | Carbon Emissions | 16.8 |  |
| E | Water Stress | 15.4 |  |
| E | Packaging Material & Waste | 11.9 |  |
| S | Labor Management | 11.8 |  |
| E | Raw Material Sourcing | 8.5 |  |
| S | Chemical Safety | 1.6 | CS |
| E | Biodiversity & Land Use | 0.8 | CS |

## Paper Products

G=33% | E=55.6% | S=11.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Water Stress | 18.8 |  |
| E | Carbon Emissions | 15.1 |  |
| E | Toxic Emissions & Waste | 11.4 |  |
| S | Labor Management | 11.4 |  |
| E | Raw Material Sourcing | 6.7 |  |
| E | Biodiversity & Land Use | 3.6 | CS |

## Precious Metals & Minerals

G=33% | E=37% | S=30%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Toxic Emissions & Waste | 14 |  |
| S | Health & Safety | 12 |  |
| E | Biodiversity & Land Use | 9 |  |
| E | Water Stress | 9 |  |
| S | Labor Management | 9 |  |
| S | Community Relations | 9 |  |
| E | Carbon Emissions | 5 |  |

## Silver

G=33% | E=37% | S=30%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Toxic Emissions & Waste | 14 |  |
| S | Health & Safety | 12 |  |
| E | Biodiversity & Land Use | 9 |  |
| E | Water Stress | 9 |  |
| S | Labor Management | 9 |  |
| S | Community Relations | 9 |  |
| E | Carbon Emissions | 5 |  |

## Specialty Chemicals

G=33.5% | E=51.7% | S=14.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.5 |  |
| E | Carbon Emissions | 13.7 |  |
| S | Chemical Safety | 13.7 |  |
| E | Toxic Emissions & Waste | 13.6 |  |
| E | Water Stress | 13.6 |  |
| E | Opportunities in Clean Tech | 10.7 |  |
| S | Health & Safety | 0.7 | CS |
| S | Product Safety & Quality | 0.2 | CS |
| E | Biodiversity & Land Use | 0.1 | CS |
| S | Labor Management | 0.1 | CS |
| S | Supply Chain Labor Standards | 0.1 | CS |

## Steel

G=33.2% | E=41.0% | S=25.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33.2 |  |
| E | Carbon Emissions | 12.6 |  |
| E | Toxic Emissions & Waste | 12.6 |  |
| E | Water Stress | 12.6 |  |
| S | Health & Safety | 12.6 |  |
| S | Labor Management | 9.7 |  |
| E | Biodiversity & Land Use | 3.2 | CS |
| S | Community Relations | 3.1 | CS |
| S | Human Capital Development | 0.4 | CS |

# Real Estate

## Data Center REITs

G=33% | E=30% | S=37%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| S | Human Capital Development | 21 |  |
| E | Carbon Emissions | 17 |  |
| S | Privacy & Data Security | 16 |  |
| E | Opportunities in Clean Tech | 13 |  |

## Diversified REITs

G=42.8% | E=30.2% | S=27.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 42.8 |  |
| E | Opportunities in Green Building | 30.2 |  |
| S | Human Capital Development | 24.2 |  |
| S | Health & Safety | 2.1 | CS |
| S | Product Safety & Quality | 0.7 | CS |

## Diversified Real Estate Activities

G=42.5% | E=30.6% | S=27.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 42.5 |  |
| E | Opportunities in Green Building | 30.1 |  |
| S | Health & Safety | 18.3 |  |
| S | Product Safety & Quality | 7.5 | CS |
| S | Human Capital Development | 0.9 | CS |
| E | Water Stress | 0.5 | CS |
| S | Privacy & Data Security | 0.3 | CS |

## Health Care REITs

G=44% | E=31% | S=25%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 44 |  |
| E | Opportunities in Green Building | 31 |  |
| S | Human Capital Development | 25 |  |

## Hotel & Resort REITs

G=44% | E=31% | S=25%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 44 |  |
| E | Opportunities in Green Building | 31 |  |
| S | Human Capital Development | 25 |  |

## Industrial REITs

G=43.3% | E=30.5% | S=26.2%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 43.3 |  |
| E | Opportunities in Green Building | 30.5 |  |
| S | Human Capital Development | 23.5 |  |
| S | Health & Safety | 1.7 | CS |
| S | Labor Management | 1 | CS |

## Multi-Family Residential REITs

G=42.3% | E=29.8% | S=28.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 42.3 |  |
| E | Opportunities in Green Building | 29.8 |  |
| S | Human Capital Development | 23.8 |  |
| S | Health & Safety | 2.2 | CS |
| S | Product Safety & Quality | 2 | CS |

## Office REITs

G=43.2% | E=30.4% | S=26.5%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 43.2 |  |
| E | Opportunities in Green Building | 30.4 |  |
| S | Human Capital Development | 24.5 |  |
| S | Health & Safety | 1.3 | CS |
| S | Privacy & Data Security | 0.4 | CS |
| S | Product Safety & Quality | 0.3 | CS |

## Other Specialized REITs

G=45.3% | E=29% | S=25.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 45.3 |  |
| E | Opportunities in Green Building | 29 |  |
| S | Human Capital Development | 25.8 |  |

## Real Estate Development

G=40.1% | E=29.1% | S=30.7%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 40.1 |  |
| E | Opportunities in Green Building | 28.6 |  |
| S | Health & Safety | 17.1 |  |
| S | Product Safety & Quality | 12.5 |  |
| E | Water Stress | 0.5 | CS |
| S | Human Capital Development | 0.5 | CS |
| S | Labor Management | 0.5 | CS |
| S | Privacy & Data Security | 0.1 | CS |

## Real Estate Operating Companies

G=41.7% | E=29.3% | S=27.9%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 41.7 |  |
| E | Opportunities in Green Building | 29.3 |  |
| S | Human Capital Development | 22.6 |  |
| S | Health & Safety | 4.3 | CS |
| S | Product Safety & Quality | 0.9 | CS |
| S | Privacy & Data Security | 0.1 | CS |

## Real Estate Services

G=43.1% | E=12.1% | S=44.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 43.1 |  |
| S | Human Capital Development | 24.9 |  |
| S | Privacy & Data Security | 18.2 |  |
| E | Opportunities in Green Building | 11.8 |  |
| S | Product Safety & Quality | 0.6 | CS |
| S | Consumer Financial Protection | 0.6 | CS |
| S | Health & Safety | 0.5 | CS |
| E | Carbon Emissions | 0.3 | CS |

## Retail REITs

G=43.7% | E=30.8% | S=25.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 43.7 |  |
| E | Opportunities in Green Building | 30.8 |  |
| S | Human Capital Development | 24.8 |  |
| S | Health & Safety | 0.4 | CS |
| S | Product Safety & Quality | 0.4 | CS |

## Self-Storage REITs

G=44% | E=31% | S=25%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 44 |  |
| E | Opportunities in Green Building | 31 |  |
| S | Human Capital Development | 25 |  |

## Single-Family Residential REITs

G=42.2% | E=29.7% | S=28.2%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 42.2 |  |
| E | Opportunities in Green Building | 29.7 |  |
| S | Human Capital Development | 23.7 |  |
| S | Health & Safety | 2.3 | CS |
| S | Product Safety & Quality | 2.2 | CS |

## Telecom Tower REITs

G=60% | E=5% | S=35%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 60 |  |
| S | Labor Management | 35 |  |
| E | Carbon Emissions | 5 |  |

## Timber REITs

G=33% | E=46% | S=19%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Biodiversity & Land Use | 19 |  |
| S | Health & Safety | 19 |  |
| E | Raw Material Sourcing | 14 |  |
| E | Carbon Emissions | 13 |  |

# Utilities

## Electric Utilities

G=36% | E=46.7% | S=17.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 36 |  |
| S | Human Capital Development | 14.5 |  |
| E | Toxic Emissions & Waste | 13.4 |  |
| E | Opportunities in Renewable Energy | 12.3 |  |
| E | Carbon Emissions | 9.9 |  |
| E | Water Stress | 7.5 |  |
| E | Biodiversity & Land Use | 3.6 | CS |
| S | Community Relations | 2 | CS |
| S | Health & Safety | 0.2 | CS |
| S | Privacy & Data Security | 0.2 | CS |
| S | Chemical Safety | 0.1 | CS |

## Gas Utilities

G=46.7% | E=24.5% | S=28.8%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 46.7 |  |
| S | Health & Safety | 26.9 |  |
| E | Carbon Emissions | 19.7 |  |
| E | Biodiversity & Land Use | 4.8 | CS |
| S | Community Relations | 1.9 | CS |

## Independent Power Producers & Energy Traders

G=33% | E=52.0% | S=15.0%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 33 |  |
| E | Carbon Emissions | 13.5 |  |
| E | Water Stress | 13.3 |  |
| E | Toxic Emissions & Waste | 12.5 |  |
| E | Opportunities in Renewable Energy | 12.5 |  |
| S | Human Capital Development | 12.5 |  |
| S | Community Relations | 2.1 | CS |
| S | Health & Safety | 0.4 | CS |
| E | Biodiversity & Land Use | 0.2 | CS |

## Multi-Utilities

G=36.5% | E=46.8% | S=18.6%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 36.5 |  |
| S | Human Capital Development | 16.5 |  |
| E | Toxic Emissions & Waste | 14.3 |  |
| E | Opportunities in Renewable Energy | 12.8 |  |
| E | Carbon Emissions | 10.8 |  |
| E | Water Stress | 8.1 |  |
| E | Biodiversity & Land Use | 0.8 | CS |
| S | Privacy & Data Security | 0.7 | CS |
| S | Community Relations | 0.6 | CS |
| S | Health & Safety | 0.6 | CS |
| S | Product Safety & Quality | 0.2 | CS |

## Renewable Electricity

G=37.7% | E=41.9% | S=20.4%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 37.7 |  |
| E | Opportunities in Renewable Energy | 20.3 |  |
| S | Human Capital Development | 19.7 |  |
| E | Carbon Emissions | 10.1 |  |
| E | Water Stress | 5.6 | CS |
| E | Biodiversity & Land Use | 5.2 | CS |
| E | Toxic Emissions & Waste | 0.7 | CS |
| S | Community Relations | 0.5 | CS |
| S | Chemical Safety | 0.2 | CS |

## Water Utilities

G=34.8% | E=44.9% | S=20.3%

| 支柱 | Key Issue | 权重(%) | CS |
|---|---|---|---|
| G | Governance | 34.8 |  |
| E | Water Stress | 24.7 |  |
| S | Product Safety & Quality | 19.7 |  |
| E | Carbon Emissions | 9.9 |  |
| E | Biodiversity & Land Use | 9.8 |  |
| S | Health & Safety | 0.6 | CS |
| E | Toxic Emissions & Waste | 0.5 | CS |

