# 产出自检清单

> AI在交付诊断报告前，必须逐项确认以下检查。任何未通过的项目需要返回修正。

## 行业确认
- [ ] 选择的GICS子行业与公司主营业务匹配？（光伏/储能/电气设备→Electrical Components & Equipment；光伏组件/电池片→Semiconductors；大型发电设备→Heavy Electrical Equipment）
- [ ] 是否通过web_search验证了行业分类？
- [ ] 如有疑问，是否列出2-3个候选让用户确认？
- [ ] 权重数据是否从industry-weights.md中准确提取？

## 完整性
- [ ] 所有加权Key Issue（非CS议题）都已完成逐指标检索？
- [ ] G支柱是否按扣分制逐Key Metric列出（Board/Pay/Ownership & Control/Accounting/Business Ethics）？
- [ ] 每个Key Issue都有"下一步行动卡"？
- [ ] CS议题是否在附录中简要涉及？
- [ ] 是否执行了争议事件搜索？

## 不可外部估算的维度
- [ ] 是否避免了对以下维度给出具体数值？
  - Exposure Score（MSCI基于自有数据库独立评估）
  - Performance Score的行业相对排名（依赖全行业对比数据）
  - Industry Min/Max值
  - MSCI对目标积极性的独立评分（Aggressiveness of targets）
  - Clean Tech Involvement Score的精确值
- [ ] 遇到这些维度时，是否标注了[不可外部估算]？
- [ ] 是否仅做定性判断（如"Performance Score预计较高"）而非给出精确数字（如"Performance Score = 8.5"）？

## 防过度乐观校准（核心检查）
- [ ] 是否有指标被直接评为L1/TOP但未通过四项校准检查（趋势数据/未来目标/覆盖范围/第三方验证）？
- [ ] G支柱得分估算是否在5.5-7.0区间（中国企业典型范围）？如果高于7.0，需重新检查扣分项是否遗漏
- [ ] 是否将"公司自述"直接等同于"MSCI认定"？常见陷阱：
  - 公司说"ESG与薪酬挂钩" ≠ MSCI认定Pay Linked to Sustainability（需要实际薪酬调整的实证）
  - 公司说"100%清洁能源业务" ≠ Clean Tech Practices满分（Strategy和Targets分开评分）
  - 公司说"有员工福利" ≠ Non-compensation benefits达到TOP（需要结构化披露）
  - 公司说"100%培训覆盖率" ≠ Skills Training达到TOP（MSCI看的是"comprehensive succession planning"而非培训覆盖率数字）
- [ ] 是否存在"所有指标都是L1/TOP"的情况？如果某个Key Issue的所有指标都被评为最高级别，大概率存在过度乐观——即使是全球领先企业，通常也有2-3个指标存在改进空间

## 表达方式
- [ ] 是否避免了二元化判断（✅符合/❌不符合），改用"现状→差距→改善方向"的三段式表述？
- [ ] 差距描述是否具体到"做什么动作可以提升到下一级别"？
- [ ] 高估风险区域是否标注了⚠️校准提示？
- [ ] 语气是否建设性（"如果进一步做到XX，有望从L2提升至L1"）而非判定性（"不符合"）？

## 格式规范
- [ ] 所有推导估算标注了【推导估算】？
- [ ] 所有信息来源标注了报告名称和页码？
- [ ] 待确认项标注了[待确认]？
- [ ] 不可外部估算的维度标注了[不可外部估算]？
