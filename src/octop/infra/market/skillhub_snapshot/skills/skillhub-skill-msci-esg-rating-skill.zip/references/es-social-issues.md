# 社会支柱（S）Key Issue方法论参考

版本：MSCI ESG Ratings Model v5.0（March 2026）
指标来源：MSCI官方S支柱方法论文件。

**诊断执行要求**：同E支柱——每一条指标必须逐一检索，记录披露情况、评分级别和信息来源。

标注说明：【官方】= MSCI方法论明确列出的Sustainability Indicator；【补充】= 为全面分析而补充的冗余指标。

---

## Access to Finance（金融服务可及性）

**支柱**: Social | **Management Score构成**: Practices + Performance

### Sustainability Indicators

1. 【官方】Innovation in mobile/online distribution channels for financial services（金融服务移动/线上分销渠道的创新）
2. 【官方】Innovation in other alternative branchless distribution channels（其他替代无网点分销渠道的创新）
3. 【官方】Financial literacy initiatives for unbanked, underbanked, or underserved groups（面向无银行账户/服务不足群体的金融素养提升项目）
4. 【官方】Financial solutions targeting unbanked, underbanked, or underserved customers（面向无银行账户/服务不足客户的金融解决方案）
5. 【官方】Extent of involvement in microfinance/microinsurance（参与小额信贷/小额保险的程度）
6. 【官方】Assessment of lending to small and medium-size enterprises（对中小企业贷款的评估）
7. 【官方】Assessment of growth in lending to small and medium-size enterprises（中小企业贷款增长的评估）
8. 【补充】普惠金融产品和服务覆盖范围

### 争议事件检查
- Restricted or discriminatory access to products and services（限制性或歧视性的产品和服务准入）

---

## Access to Health Care（医疗可及性）

**支柱**: Social | **Management Score构成**: Practices

### Sustainability Indicators

1. 【官方】Number of relevant diseases addressed by commercialized products（商业化产品覆盖的相关疾病数量）
2. 【官方】Number of relevant diseases addressed by R&D pipeline（研发管线覆盖的相关疾病数量）
3. 【官方】Scope of expansion plans to low-income and middle-income countries（向低收入和中等收入国家扩展计划的范围）
4. 【官方】Assistance to local manufacturers to achieve international drug manufacturing quality standards（协助当地制造商达到国际药品制造质量标准）
5. 【官方】Supports pharmacovigilance in low- and middle-income countries（在中低收入国家支持药物警戒）
6. 【官方】Trains local healthcare workers in low- and middle-income countries（在中低收入国家培训当地医疗工作者）
7. 【官方】Improves availability of products through pharmaceutical supply chain improvements（通过改善药品供应链提高产品可及性）
8. 【官方】Involvement in public-private partnerships for improving local R&D（参与公私合营以改善当地研发）
9. 【官方】Capacity building of public health infrastructure（公共卫生基础设施能力建设）
10. 【官方】Number of non-exclusive voluntary licenses issued or received（发出或获得的非独占自愿许可数量）
11. 【官方】Extent of pricing policies based on affordability（基于可负担性的定价政策程度）
12. 【官方】Signed licensing agreements with the Medicines Patent Pool（与药品专利池签订许可协议）
13. 【官方】Pricing transparency in developed and developing markets（发达和发展中市场的定价透明度）
14. 【官方】Is the company conducting R&D to address antibiotic resistance（公司是否进行抗生素耐药性相关研发）

### 争议事件检查
- Restricted or discriminatory access controversies（限制性或歧视性准入争议）

---

## Chemical Safety（化学品安全）

**支柱**: Social | **Management Score构成**: Strategy + Programs & Initiatives

### Sustainability Indicators

1. 【官方】Scope of chemical phase-out plan（化学品淘汰计划的范围）
2. 【官方】Level of efforts to identify substances for regulatory risk（识别受监管风险物质的努力程度）
3. 【官方】Scope of disclosure of registration and use of regulated substances（受管制物质注册和使用的披露范围）
4. 【官方】Environmental and health standards in new product design（新产品设计中的环境和健康标准）
5. 【官方】Demonstrated track record of reducing reliance on substances of concern（减少对关注物质依赖的实绩记录）
6. 【官方】Demonstrated track record of phasing out and/or reformulating products with chemicals of concern（淘汰和/或重新配制含关注化学品产品的实绩记录）
7. 【官方】Initiatives to improve consumer awareness on product chemical content（提高消费者对产品化学成分认知的举措）
8. 【官方】Extent of substances or products that a company conducts hazard assessments（公司进行危害评估的物质或产品范围）
9. 【补充】GADSL/REACH/RoHS合规管理体系
10. 【补充】化学品相关事故数量

### 争议事件检查
- Chemical safety controversies（化学品安全争议）

---

## Community Relations（社区关系）

**支柱**: Social | **Management Score构成**: Practices

### Sustainability Indicators

1. 【官方】Commitment to refrain from operating in protected areas（承诺不在保护区运营）
2. 【官方】Conducts community impact assessment prior to settling in new areas（在新区域设立前进行社区影响评估）
3. 【官方】Indigenous people policy（原住民政策）
4. 【官方】Local community engagement approach（当地社区参与方式）
5. 【官方】Monitors the effectiveness of its human rights policy（监督其人权政策的有效性）
6. 【官方】Employee training on human rights protection（员工人权保护培训）
7. 【官方】Ethical conduct policy covers contract security providers（道德行为政策覆盖合同安保人员）
8. 【官方】Human rights policy（人权政策）
9. 【官方】Violence and conflict policy（暴力和冲突政策）
10. 【官方】Local procurement policy（本地采购政策）
11. 【官方】Programs to support local communities（支持当地社区的项目）
12. 【补充】社区投诉处理机制和数据
13. 【补充】社区投资金额和项目

### 争议事件检查
- Human rights controversies（人权争议）
- Community impact controversies（社区影响争议）
- Indigenous people's controversies（原住民争议）

---

## Consumer Financial Protection（消费者金融保护）

**支柱**: Social | **Management Score构成**: Practices + Performance

### Sustainability Indicators

1. 【官方】Scope of responsible lending policy（负责任贷款政策的范围）
2. 【官方】Scope of responsible marketing and sales practices（负责任营销和销售实践的范围）
3. 【官方】Scope of product suitability assessment（产品适当性评估的范围）
4. 【官方】Consumer complaint resolution mechanisms（消费者投诉解决机制）
5. 【官方】Consumer data protection measures（消费者数据保护措施）
6. 【补充】监管处罚记录
7. 【补充】产品定价透明度和公平性措施

### 争议事件检查
- Consumer financial protection controversies（消费者金融保护争议）

---

## Controversial Sourcing（争议性采购）

**支柱**: Social | **Management Score构成**: Practices + Targets

### Sustainability Indicators

1. 【官方】Commitments to address controversial sourcing practices（应对争议性采购实践的承诺）
2. 【官方】Extent of efforts to ensure compliance with controversial materials sourcing policy（确保遵守争议性材料采购政策的努力程度）
3. 【官方】Extent of supplier/material certification as conflict-free by external agencies（供应商/材料经外部机构认证为无冲突的程度）
4. 【官方】Extent of material traceability to place of origin（材料可追溯至原产地的程度）
5. 【官方】Targets for ensuring compliance with controversial materials sourcing policy（确保遵守争议性材料采购政策的目标）
6. 【补充】是否参与相关行业倡议（如RMI/RJC）

### 争议事件检查
- Controversial sourcing controversies（争议性采购争议）

---

## Health & Safety（健康与安全）

**支柱**: Social | **Management Score构成**: Strategy + Targets + Performance

### Sustainability Indicators

1. 【官方】Scope of health and safety policy（健康与安全政策的范围）
2. 【官方】Applicability of health and safety policy to contractors（健康与安全政策对承包商的适用性）
3. 【官方】Health and safety policy and practices are audited（健康与安全政策和实践是否接受审计）
4. 【官方】Health and safety performance is a factor in CEO compensation（健康与安全绩效是否为CEO薪酬的因素）
5. 【官方】Body responsible for health & safety strategy and performance（负责健康与安全战略和绩效的机构）
6. 【官方】Evaluation of health & safety certification（健康与安全认证的评估）
7. 【官方】Contractors included in disclosed health and safety metrics（披露的健康与安全指标是否包含承包商）
8. 【官方】Target to improve health and safety performance（改善健康与安全绩效的目标）
9. 【补充】安全管理体系是否通过ISO 45001认证及覆盖率
10. 【补充】因工死亡人数及连续零死亡年数

### Performance指标
- 【官方】Lost time incident rate - LTIR performance relative to peers（损工事件率绩效相对于同业表现）
- 【官方】Total recordable injury rate - TRIR performance relative to peers（总记录工伤率绩效相对于同业表现）
- 【官方】Fatality intensity performance relative to peers（死亡强度绩效相对于同业表现）

### 争议事件检查
- Health and safety controversies（健康与安全争议）

---

## Human Capital Development（人力资本发展）

**支柱**: Social | **Management Score构成**: Strategy + Programs & Initiatives + Performance

### Sustainability Indicators

1. 【官方】Extent of human resource-related grievance reporting or escalation procedures（人力资源相关申诉报告或上报程序的范围）
2. 【官方】Employee satisfaction survey frequency（员工满意度调查频率）
3. 【官方】Formal talent pipeline development strategy（正式的人才发展战略）
4. 【官方】Employee equity programs（员工股权计划）
5. 【官方】Variable performance-based component to pay（绩效浮动薪酬组成部分）
6. 【官方】Workforce eligible for paid parental leave policy（有资格享受带薪育儿假的员工范围）
7. 【官方】Regular performance appraisals and feedback processes（定期绩效评估和反馈流程）
8. 【官方】Skills and knowledge development training（技能和知识发展培训）
9. 【官方】Programs to increase workforce diversity（增加劳动力多样性的计划）
10. 【官方】Workforce diversity policy and management oversight（劳动力多元化政策和管理监督）
11. 【官方】Graduate traineeship/apprenticeship program（毕业生实习/学徒计划）
12. 【官方】Partners with educational institutions to develop joint training programs（与教育机构合作开展联合培训项目）
13. 【官方】Job-specific development training programs（针对性的业务培训项目）
14. 【补充】人均培训时长和培训投入金额
15. 【补充】员工多元化数据（性别/种族/年龄）
16. 【补充】核心人才保留率

### Performance指标
- 【官方】Employee turnover rate performance relative to peers（员工流失率绩效相对于同业表现）
- 【官方】External recognition as employer of choice in last three years（过去3年被外界认可为最佳雇主）

### 争议事件检查
- Labor management controversies（劳工管理争议）
- Collective bargaining controversies（集体谈判争议）
- Discrimination and workforce diversity controversies（歧视和劳动力多元化争议）

---

## Labor Management（劳工管理）

**支柱**: Social | **Management Score构成**: Strategy + Programs & Initiatives

### Sustainability Indicators

1. 【官方】Policies to address labor rights in core operations（保障核心业务中劳工权利的政策）
2. 【官方】Percentage of workforce covered by trade unions/collective agreements（工会/集体协议覆盖的劳动力百分比）
3. 【官方】Evidence of collective agreements（集体协议的证据）
4. 【官方】Scope of workforce eligibility for variable performance-based component to pay（有资格享受浮动绩效薪酬的员工范围）
5. 【官方】Evidence of Anti-Discrimination/Diversity and Inclusion policy（反歧视/多元化和包容性政策的证据）
6. 【官方】Evidence of child labor provision in the internal policy（内部政策中关于童工条款的证据）
7. 【官方】Evidence of forced labor provision in the internal policy（内部政策中关于强制劳工条款的证据）
8. 【官方】Evidence of freedom of association provision in the internal policy（内部政策中关于自由结社条款的证据）
9. 【官方】Restructuring policies and programs（重组的政策与计划）
10. 【官方】Support for degree programs or certifications for employees（为员工提供学位课程或认证支持）
11. 【官方】Scope of support for degree programs and certifications（学位课程和认证支持的范围）
12. 【官方】Skills and knowledge development training（技能和知识发展培训）
13. 【官方】Scope of skills and knowledge development training（技能和知识发展培训的范围）
14. 【官方】External recognition as employer of choice in last three years（过去3年被外界认可为最佳雇主）
15. 【官方】Company witnessed strikes/lock-outs in the last three years（公司在过去3年中发生罢工或闭厂事件）
16. 【官方】Collective bargaining negotiation expected in next 12 months（预计在未来12个月内进行集体谈判）
17. 【官方】Major Layoffs（大规模裁员）
18. 【官方】Employee equity programs（员工股权计划）
19. 【官方】Workforce eligible for non-pay benefits（有资格享受非工资福利的员工范围）
20. 【官方】Material non-pay benefits（实质性非工资福利）
21. 【官方】Employee satisfaction survey frequency（员工满意度调查频率）
22. 【官方】Employee engagement survey results（员工敬业度调查结果）
23. 【补充】员工总数、合同类型分布
24. 【补充】员工流失率（按年龄/性别/地域分类）
25. 【补充】员工申诉机制及处理数据
26. 【补充】人权政策是否独立发布

---

## Opportunities in Nutrition & Health（营养与健康机遇）

**支柱**: Social | **Management Score构成**: Strategy + Practices
**类型**: 机遇类Key Issue

### Sustainability Indicators

1. 【官方】In-house innovation capacity to develop healthier products（开发更健康产品的内部创新能力）
2. 【官方】Strategy to develop natural and healthy products（开发天然和健康产品的战略）
3. 【官方】Food & beverage nutrition enhancement programs score（食品和饮料营养提升项目评分）
4. 【补充】健康/营养产品线的收入占比和增长趋势
5. 【补充】产品配方改良（减糖/减盐/减脂）的进展

### 争议事件检查
- False marketing controversies（虚假营销争议）

---

## Privacy & Data Security（隐私与数据安全）

**支柱**: Social | **Management Score构成**: Practices

### Sustainability Indicators

1. 【官方】Scope of employee training on privacy and data security（员工隐私和数据安全培训的范围）
2. 【官方】Responsibility for privacy and data security（隐私和数据安全的负责人/机构）
3. 【官方】Measures to address data breaches（应对数据泄露的措施）
4. 【官方】Frequency of audits of information security system（信息安全系统审计频率）
5. 【官方】Rights provided to consumers regarding the control of their data（向消费者提供的数据控制权利）
6. 【官方】Scope of data protection policy（数据保护政策的范围）
7. 【官方】Scope of information security management system certifications（信息安全管理体系认证的范围）
8. 【官方】Privacy enhancing technologies and initiatives（隐私增强技术和举措）
9. 【官方】Consent policy for use of consumer data for secondary purposes（将消费者数据用于次要用途的同意政策）
10. 【官方】Data protection programs covering suppliers and business partners（覆盖供应商和商业伙伴的数据保护项目）
11. 【补充】数据泄露事件数量和影响范围
12. 【补充】ISO 27001/SOC 2认证情况
13. 【补充】数据保护官（DPO）任命及汇报线
14. 【补充】GDPR/CCPA等法规合规说明

### 争议事件检查
- Privacy and data security controversies（隐私和数据安全争议）

---

## Product Safety & Quality（产品安全与质量）

**支柱**: Social | **Management Score构成**: Practices + Performance

### Sustainability Indicators

1. 【官方】Quality management system scope and certification（质量管理体系范围和认证）
2. 【官方】Product recall mechanisms and procedures（产品召回机制和程序）
3. 【官方】Product safety testing and validation programs（产品安全测试和验证项目）
4. 【官方】Post-market surveillance systems（上市后监测系统）
5. 【官方】Customer complaint handling and resolution（客户投诉处理和解决）
6. 【官方】Supply chain quality management（供应链质量管理）
7. 【补充】质量管理体系认证覆盖率（ISO 9001/IATF 16949等）
8. 【补充】产品召回事件数量和原因
9. 【补充】客户投诉数量及处理效率
10. 【补充】产品安全相关量化指标（如缺陷率）

### 争议事件检查
- Product safety and quality controversies（产品安全和质量争议）

---

## Responsible Investment（负责任投资）

**支柱**: Social | **Management Score构成**: Practices

### Sustainability Indicators

1. 【官方】Dedicated ESG analysts responsible for analyzing ESG issues in investment processes（专职ESG分析师负责投资流程中的ESG问题分析）
2. 【官方】Responsible investment policy to incorporate ESG considerations（纳入ESG考量的负责任投资政策）
3. 【官方】Highest level of ESG factors incorporation in investment process across asset classes（在各资产类别投资流程中纳入ESG因素的最高水平）
4. 【官方】Dedicated staff responsible for ESG engagement（专职人员负责ESG参与/对话）
5. 【官方】Detailed engagement policy that addresses environmental, social and governance issues（涵盖环境、社会和治理问题的详细参与政策）
6. 【补充】投资组合碳足迹或ESG评分是否披露
7. 【补充】是否签署PRI等负责任投资倡议

### 争议事件检查
- Controversial investments（争议性投资）

---

## Supply Chain Labor Standards（供应链劳工标准）

**支柱**: Social | **Management Score构成**: Practices

### Sustainability Indicators

1. 【官方】Scope of supply chain labor standards policy（供应链劳工标准政策的范围）
2. 【官方】Supplier code of conduct covering core labor rights（覆盖核心劳工权利的供应商行为准则）
3. 【官方】Supplier auditing and monitoring programs（供应商审计和监控项目）
4. 【官方】Transparency of supplier audit results（供应商审计结果的透明度）
5. 【官方】Programs to address child labor in supply chain（解决供应链中童工问题的项目）
6. 【官方】Programs to address forced labor in supply chain（解决供应链中强制劳工问题的项目）
7. 【官方】Scope of supply chain labor standards to sub-tier suppliers（供应链劳工标准对下级供应商的覆盖范围）
8. 【补充】高风险供应商的识别和管理流程
9. 【补充】供应商审计覆盖率

### 争议事件检查
- Supply chain labor standards controversies（供应链劳工标准争议）
