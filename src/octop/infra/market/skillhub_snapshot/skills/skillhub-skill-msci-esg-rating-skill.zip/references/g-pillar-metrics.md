# G支柱全部Key Metric清单及典型扣分值

所有典型扣分数据均来自对应Key Issue方法论文件中标注的"Typical scoring deduction"值。

## 1. G支柱Key Metric交互效应

### Controlling Shareholder（≥30%投票权）连锁效应
本身扣0，但触发：Controlling Shareholder Concerns（扣1.0）、Related-Party Transactions加码（不披露从0.5→1.0）、Board Independence加码、Cumulative Voting评估。

### Board Entrenchment触发条件
>35%董事任期≥15年、>22%任期≥15年且>15%年龄≥70岁等。扣0.6-1.5。

## 2. Board Key Issue

| 类别 | Key Metric | 典型扣分 |
|---|---|---|
| Leadership | Independent Chair | 0.1 |
| Leadership | Combined CEO/Chair | 0.2 |
| Leadership | Leadership Concerns | 0.3 |
| Leadership | Chair Not Independent & No Lead Director | 0.1 |
| Independence | Board Majority Independent of Mgmt (<51%) | 0.2-1.0 |
| Independence | Board Majority Independent of Other Interest | 0.3-1.0 |
| Independence | Executives on Board (≥30%) | 0.2-0.5 |
| Independence | No Independent Directors | 0.5 |
| Independence | Related-Party Transactions | 0.05-3.4 |
| Effectiveness | Flagged Directors | 0.2-1.0 |
| Effectiveness | Overboarded Non-Exec (≥4家) | 0.5 |
| Effectiveness | Overboarded Exec (≥3家) | 0.5 |
| Effectiveness | Significant Votes Against (>10%) | 0.25-2.0 |
| Effectiveness | Oversized Board (≥20人) | 0.5 |
| Effectiveness | Undersized Board (≤4人) | 1.0 |
| Effectiveness | Board Attendance Failures (<75%) | 0.1 |
| Diversity | Entrenched Board | 0.6-1.5 |
| Diversity | No Female Directors | 0.2 |
| Diversity | Not 30% Female Directors | 0.1 |
| Diversity | Risk Management Expertise缺失 | 0.2 |
| Audit | Audit Committee Independence非100% | 0.1-0.8 |
| Audit | Audit Committee Financial Expert缺失 | 0.1 |
| Pay Oversight | Pay Committee Independence | 0.1-0.3 |
| Pay Oversight | No Pay Committee & Execs on Board | 0.6 |
| Nomination | No Nomination Committee | 0.3 |
| Nomination | Nomination Committee Chair Independence | 0.1 |

## 3. Pay Key Issue

| Key Metric | 典型扣分 |
|---|---|
| Executive Pay Disclosure（未披露CEO） | **1.2** |
| CEO Equity Policy | 0.2 |
| Pay Linked to Sustainability | 0.2 |
| Clawbacks & Malus | 0.2 |
| Golden Hellos | 0.0-1.0 |
| CEO Pay Total（同业top decile） | 0.2 |
| Internal Pay Equity（CEO>3倍中位数） | 0.2 |
| Golden Parachutes | 0.3 |

## 4. Ownership & Control Key Issue

| Key Metric | 典型扣分 |
|---|---|
| Controlling Shareholder | 0（触发连锁） |
| Controlling Shareholder Concerns | 1.0 |
| Variable Interest Entities | 0.5 |
| Multiple Equity Classes Different Voting | 0.2-0.6 |
| Poison Pill | 0.5 |
| Say-on-Pay Policy | 0.1 |

## 5. Accounting Key Issue

| Key Metric | 典型扣分 |
|---|---|
| Auditor Independence（非审计费>审计费） | 0.5 |
| Auditor Tenure（>20年） | 0.2 |
| Internal Controls（重大缺陷） | 0.2-0.4 |
| Restatements | 0.3-1.0 |
| Late Filings | 0.2 |

## 6. Business Ethics Key Issue

### 6.1 七项政策与实践指标（Policies & Practices）

每项政策按3级评分：最佳实践(扣0) → 部分披露(扣-0.7) → 无披露(扣-1.4)。7项全无披露 → raw points = 9.8。

| # | 政策项 | 最佳实践（扣0） | 部分披露（扣-0.7） |
|---|---|---|---|
| 1 | Oversight of Ethics Issues（道德问题监督） | 董事会级委员会或C-suite/执行委员会监督 | 特别工作组/风险官/CSR团队 |
| 2 | Bribery and Anti-corruption（反贿赂反腐败政策） | 详细的正式反贿赂反腐败政策 | 一般性承诺 |
| 3 | Anti-Corruption for Suppliers（供应商反腐败） | 全部供应商需有反腐败政策+合规验证 | 全部需有政策但无验证(-0.7)/仅覆盖部分(-1.0) |
| 4 | Whistleblower Protection（举报人保护） | 有反报复保护条款的举报政策 | — |
| 5 | Employee Training（员工道德培训） | 覆盖所有员工含兼职和承包商 | 仅全职(-0.7)/一般性声明(-1.0) |
| 6 | Regular Audits（定期道德审计） | 至少每3年对全部运营进行审计 | 对部分运营审计(-0.7)/有审计但无细节(-0.7) |
| 7 | Anti-Money Laundering（反洗钱政策） | 政策+实施策略 | 有政策但无实施策略(-0.7) |

### 6.2 额外审计细节指标

从MSCI评级指标表验证的审计相关子指标：
- Does the Company conduct audit of its anti-corruption policies?（公司是否对其反腐败政策进行审计？——内容维度）
- Regular Audits of Ethical Standards（关于道德标准的常规审计——频率维度）
- Does the Company state that it audits ALL operations?（公司是否声明对所有运营地进行审计？——范围维度）

即：审计类指标从内容、频率、范围三个维度交叉评估。

### 6.3 Corruption Risk Exposure Deduction（腐败风险暴露扣分）

| 中高腐败风险地区占比 | 高风险业务占比 | 政府持股≥20% | 政府持股<20% | 无政府持股 |
|---|---|---|---|---|
| ≥20% | ≥50% | -4.00 | -2.60 | -2.00 |
| ≥20% | <50% | -1.20 | -1.20 | -1.20 |
| <20% | ≥50% | -0.60 | -0.60 | -0.60 |
| <20% | <50% | 0.00 | 0.00 | 0.00 |

高风险业务类型包括：建筑/基建/电力/水务/通信、矿业/金属/石油天然气、房地产/物业、国防/军工等。
中高腐败风险地区的判定基于透明国际CPI指数和世界银行治理指标。

### 6.4 Business Ethics Controversies扣分
见`controversy-matrix.md`——Business Ethics争议使用Corporate Behavior Controversy矩阵（最高-7.0），与E&S争议矩阵不同。

## 7. Tax Transparency Key Issue

有税务争议+估算税差>10% → 扣2.0 → Score=0

## 8. MSCI独立性判定vs中国法规

| 情形 | MSCI标准 |
|---|---|
| 前任高管转任非执行董事 | 永远不独立 |
| 公司创始人 | 永远不独立 |
| ≥30%股东代表 | 不独立 |
