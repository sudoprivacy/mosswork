# MSCI ESG Ratings Model Version History

当前版本：**v5.0**（2026年3月23日生效）

## 当前版本核心变更（v5.0）

### 新引入的标准化Performance评分框架
对以下Key Issue引入基于intensity和trend的量化Performance评分：
Carbon Emissions、Water Stress、Toxic Emissions & Waste、Health & Safety、Human Capital Development、Biodiversity & Land Use、Product Safety & Quality、Opportunities in Renewable Energy、Product Carbon Footprint、Opportunities in Clean Tech

### 争议事件扣分方法论修订
引入severity（严重程度）、status（状态）和company role（公司角色）三维度交叉矩阵，适用于E&S Key Issue和Corporate Behavior Key Issue。

### 新引入的环境目标评估框架
对Carbon Emissions、Water Stress、Toxic Emissions & Waste引入标准化的环境可持续发展目标评估。

### 评级缓冲区
引入±0.1的buffer zone，在IAS映射到字母评级时应用。

### 其他v5.0变更
- 引入indicator-level权重和标准化聚合方式构建E&S Management Score
- 多个Key Issue的Exposure方法论更新（Business Segment、Geographic、Company-Specific）
- 第12次ESG Materiality Map年度更新

## 关键历史版本

### v4.0（2020年11月）
- G支柱从加权平均改为扣分制（从10分起扣）
- G支柱最低权重设为33%
- Tax Transparency成为加权Key Issue
- Corporate Behavior Theme改为0-10绝对评分
- 新增Community Relations Key Issue
- 移除Financial System Instability、Corruption & Instability、Anti-Competitive Practices等Key Issue

### v3.0（2015年1月）
- QuickScore被MSCI Governance Metrics替代
- G支柱权重从12%提升至22%
- 引入0-10绝对评分（从满分起扣）

### v2.0（2012年1月）
- 建立10 Theme + 33 Key Issue结构
- 引入ISS GRId作为公司治理数据源

### Industry Min/Max更新频率
从v4.0.1开始，MSCI会不定期对特定行业的Industry Min/Max进行中期更新。近期更新频率约为每3-6个月一次，每次涉及5-20个行业。
