# 环境支柱（E）Key Issue方法论参考

版本：MSCI ESG Ratings Model v5.0（March 2026）
指标来源：MSCI官方E支柱方法论文件。

**诊断执行要求**：每一条指标必须在ESG报告和年报中逐一检索。每个指标记录：（a）是否有对应披露（b）披露对应哪个评分级别（c）信息来源（文件名+页码）。不得遗漏。

标注说明：【官方】= MSCI方法论明确列出的Sustainability Indicator；【补充】= 为全面分析而补充的冗余指标。

---

## Biodiversity & Land Use（生物多样性与土地使用）

**支柱**: Environmental | **Management Score构成**: Practices

### Sustainability Indicators

1. 【官方】Involvement with external stakeholder groups to address biodiversity impacts（参与外部利益相关方团体以应对生物多样性影响）
2. 【官方】Scope of third-party engagement or standard to address biodiversity impacts（第三方参与或标准的范围以应对生物多样性影响）
3. 【官方】Commitment to minimize disturbances on biodiversity（减少生物多样性干扰的承诺）
4. 【官方】Commitment to reclaim habitat on disturbed land（在受干扰土地上恢复栖息地的承诺）
5. 【官方】Scope of biodiversity and land reclamation policy（生物多样性和土地复垦政策的范围）
6. 【官方】Extent of programs to protect ecosystems（保护生态系统项目的范围）
7. 【官方】Conducts biodiversity impact assessments（是否进行生物多样性影响评估）
8. 【补充】是否有无净损失/净正面影响（No Net Loss/Net Positive Impact）目标
9. 【补充】运营是否涉及生物多样性敏感区域（保护区、关键生物多样性区域）
10. 【补充】土地使用变化和复垦情况的量化数据是否披露

### Performance指标
- 【官方】Oil spills performance relative to peers（漏油绩效相对于同业表现）

### 争议事件检查
- Biodiversity & land use controversies（生物多样性与土地使用争议）
- Oil spills（漏油事件）
- Toxic releases to water/land controversies（向水体/土地排放有毒物质争议）

---

## Carbon Emissions（碳排放）

**支柱**: Environmental | **Management Score构成**: Practices + Targets + Performance

### Sustainability Indicators

1. 【官方】Use of cleaner sources of energy（使用更清洁的能源）
2. 【官方】Efforts to capture GHG emissions（捕获温室气体排放的努力）
3. 【官方】Energy Consumption Management & Operational Efficiency（能源消耗管理和运营效率）
4. 【官方】Efforts to reduce customer energy consumption - demand-side management（减少客户能源消耗的努力——需求侧管理）
5. 【官方】Other efforts to reduce carbon emissions（其他减少碳排放的努力）
6. 【补充】Scope 1、2、3排放数据是否完整披露
7. 【补充】碳强度（tCO2e/百万美元收入）是否逐年下降
8. 【补充】是否参与CDP气候变化问卷及评分等级
9. 【补充】可再生能源使用比例及目标

### 目标类指标
- 【官方】Carbon emissions target comprehensiveness（碳排放目标的全面性）
- 【官方】Carbon emissions target progress（碳排放目标的进展）
- 【补充】是否设定经SBTi验证的科学碳目标

### Performance指标
- 【官方】Carbon emissions performance relative to peers（碳排放绩效相对于同业表现）

---

## Climate Change Vulnerability（气候变化脆弱性）

**支柱**: Environmental | **Management Score构成**: Practices + Performance

### Sustainability Indicators

1. 【官方】Recognition that physical risk of climate change may increase underwriting risks（认识到气候变化物理风险可能增加承保风险）
2. 【官方】Research or exercise to quantify the impact of physical risk on insurance underwriting（量化物理风险对保险承保影响的研究或演练）
3. 【官方】Evidence of using climate change models（使用气候变化模型的证据）
4. 【补充】TCFD框架下的情景分析是否披露
5. 【补充】气候韧性投资和适应策略

### Performance指标
- 【官方】Underwriting performance based on combined ratio（基于综合费率的承保绩效）

---

## Electronic Waste（电子废弃物）

**支柱**: Environmental | **Management Score构成**: Practices + Operations

### Sustainability Indicators

1. 【官方】Scope of the electronic waste take-back program by product type（按产品类型划分的电子废弃物回收计划范围）
2. 【官方】Scope of the electronic waste take-back program by location（按地域划分的电子废弃物回收计划范围）
3. 【官方】Scope of electronic waste take-back programs（电子废弃物回收计划的范围）
4. 【官方】Explicit ban on electronic waste exports to non-OECD countries（明确禁止向非OECD国家出口电子废弃物）
5. 【官方】End of life electronic waste recycling（产品生命终期的电子废弃物回收）
6. 【补充】产品设计中是否考虑可回收性和延长使用寿命
7. 【补充】电子废弃物回收量和回收率的量化数据

### 争议事件检查
- Electronic waste controversies（电子废弃物争议）

---

## Financing Environmental Impact（融资环境影响）

**支柱**: Environmental | **Management Score构成**: Practices

### Sustainability Indicators

1. 【官方】Involvement of group credit risk in ESG due diligence（集团信用风险在ESG尽职调查中的参与）
2. 【官方】ESG due diligence triggers and risk-escalation process clearly defined（ESG尽职调查触发条件和风险升级流程明确定义）
3. 【官方】Oversight of ESG risk management in financing activities（融资活动中ESG风险管理的监督）
4. 【官方】Conducts climate-related risk analysis（进行气候相关风险分析）
5. 【官方】Environmental credit policy score（环境信贷政策评分）
6. 【官方】Involvement in green financing and securities（参与绿色融资和证券）
7. 【官方】Sustainability-related financial product development（可持续发展相关金融产品开发）
8. 【官方】Financing environmental impact practices score for covered bonds issuers（担保债券发行人的融资环境影响实践评分）
9. 【补充】贷款组合的气候风险暴露分析是否开展
10. 【补充】对化石燃料行业的融资政策和金额

### 争议事件检查
- Controversial investment controversies（争议性投资争议）

---

## Opportunities in Clean Tech（清洁技术机遇）

**支柱**: Environmental | **Management Score构成**: Strategy + Programs & Initiatives + Performance
**类型**: 机遇类Key Issue

### Sustainability Indicators

1. 【官方】Strategic focus on clean technology development（以发展清洁技术为战略重点）
2. 【官方】Targets to increase investment in clean tech（加大清洁技术投资的目标）
3. 【官方】Research and development intensity as percentage of sales（研发强度占营收比例）
4. 【官方】Number of patent families（专利族数量）
5. 【官方】Clean tech revenue score（清洁技术收入评分）
6. 【补充】清洁技术/可再生能源相关收入占比
7. 【补充】帮助客户减排的量化贡献（avoided emissions）

---

## Opportunities in Green Building（绿色建筑机遇）

**支柱**: Environmental | **Management Score构成**: Practices + Targets + Performance
**类型**: 机遇类Key Issue

### Sustainability Indicators

1. 【官方】Extent of green building certification commitments in portfolio or development pipeline（组合或开发管道中绿色建筑认证承诺的程度）
2. 【官方】Extent of commercial arrangements to improve or maintain property environmental performance（改善或维护物业环境绩效的商业安排程度）
3. 【官方】Use of green or triple-net leases（使用绿色租约或三净租约）
4. 【官方】Green certification commitments related to greenfield developments（与新建项目相关的绿色认证承诺）
5. 【官方】Evidence of flexible or mixed-use properties in portfolio（组合中灵活或混合用途物业的证据）
6. 【官方】Evidence of urban revitalization developments（城市更新开发的证据）
7. 【官方】Green building commitment extends to existing buildings in portfolio（绿色建筑承诺延伸至组合中的现有建筑）

### 目标类指标
- 【官方】Green building certification score（绿色建筑认证评分）

### Performance指标
- 【官方】Carbon emissions performance relative to peers（碳排放绩效相对于同业表现）

---

## Opportunities in Renewable Energy（可再生能源机遇）

**支柱**: Environmental | **Management Score构成**: Strategy + Programs & Initiatives + Targets + Performance
**类型**: 机遇类Key Issue

### Sustainability Indicators

1. 【官方】Targets to increase renewable capacity（增加可再生能源产能的目标）
2. 【官方】Internal structures to develop renewable capacity（开发可再生能源产能的内部组织结构）
3. 【官方】Investments to increase connection of renewable power to electric grid（增加可再生能源电力接入电网的投资）
4. 【官方】Score of planned additional renewable electricity generation relative to current capacity（计划新增可再生能源发电量相对于现有产能的评分）
5. 【官方】Commercializes renewable power equipment（商业化可再生能源设备）
6. 【官方】Offers customers a green power option（为客户提供绿色电力选项）

### Performance指标
- 【官方】Renewable power capacity performance relative to peers（可再生能源产能绩效相对于同业表现）

---

## Packaging Material & Waste（包装材料与废弃物）

**支柱**: Environmental | **Management Score构成**: Strategy + Practices + Targets

### Sustainability Indicators

1. 【官方】Disclosure of packaging material mix（包装材料组成的披露）
2. 【官方】Scope of consumer programs to reduce waste（减少废弃物的消费者项目范围）
3. 【官方】Scope of recycling programs where not mandated by law（非法律强制要求的回收项目范围）
4. 【官方】Strategy to reduce the environmental impact of packaging（减少包装环境影响的战略）
5. 【官方】Scope of environmental improvements in packaging（包装环保改进的范围）
6. 【官方】Scope of product or packaging recovery（产品或包装回收的范围）
7. 【补充】包装材料中可回收/可降解比例是否披露
8. 【补充】包装减量化目标和进展

### 目标类指标
- 【官方】Targets related to packaging content（与包装内容物相关的目标）
- 【官方】Targets related to packaging material circularity or waste elimination（与包装材料循环利用或废弃物消除相关的目标）

### 争议事件检查
- Packaging waste controversies（包装废弃物争议）

---

## Product Carbon Footprint（产品碳足迹）

**支柱**: Environmental | **Management Score构成**: Practices + Targets + Performance

### Sustainability Indicators

1. 【官方】Assessment of energy consumption and/or carbon emissions of suppliers（对供应商能源消耗和/或碳排放的评估）
2. 【官方】Extent of product carbon footprint assessments（产品碳足迹评估的范围）
3. 【官方】Energy consumption or carbon emissions assessment of distribution and store operations（分销和门店运营的能源消耗或碳排放评估）
4. 【官方】Energy consumption or carbon emissions assessment of manufacturing operations（制造运营的能源消耗或碳排放评估）
5. 【官方】Energy consumption or carbon emissions assessment of raw materials sourcing（原材料采购的能源消耗或碳排放评估）
6. 【官方】Energy consumption or carbon emissions assessment of transportation and logistics（运输和物流的能源消耗或碳排放评估）
7. 【官方】Extent of reduction programs in distribution/manufacturing/raw materials/transportation（分销/制造/原材料/运输环节的减排项目范围——共4个子指标）
8. 【补充】产品生命周期碳足迹评估（LCA）是否开展
9. 【补充】低碳产品线的收入占比和增长趋势

### 目标类指标
- 【官方】Targets to reduce Scope 3 upstream carbon emissions（减少范围3上游碳排放的目标）
- 【官方】Carbon emissions target comprehensiveness（碳排放目标的全面性）
- 【官方】Carbon emissions target progress（碳排放目标的进展）
- 【官方】Carbon emissions target verification（碳排放目标的核查）

### Performance指标
- 【官方】Tailpipe fleet emission performance relative to peers（尾气排放车队绩效相对于同业表现）

---

## Raw Material Sourcing（原材料采购）

**支柱**: Environmental | **Management Score构成**: Practices

**注意**: 对牛肉/乳制品、棉花、皮革、棕榈油、海鲜、木材/纸张等各类原材料，分别使用相同的指标集评估。

### Sustainability Indicators（每类材料均适用）

1. 【官方】Percentage of [material] third-party certified to an environmental sustainability standard（[材料]通过第三方环境可持续性标准认证的百分比）
2. 【官方】Extent of [material] certification against the most stringent sustainable criteria（[材料]符合最严格可持续性标准认证的程度）
3. 【官方】Extent of [material] traceability to place of origin（[材料]可追溯至原产地的程度）
4. 【官方】Extent of supply chain initiatives to address impacts of [material] production（应对[材料]生产影响的供应链举措的范围）
5. 【官方】Future targets for [material] sourcing（[材料]采购的未来目标）
6. 【官方】Commitments towards responsible [material] sourcing（负责任[材料]采购的承诺）
7. 【补充】再生材料使用比例

### 争议事件检查
- Environmental issues in the supply chain controversies（供应链中的环境问题争议）

---

## Toxic Emissions & Waste（有毒排放与废弃物）

**支柱**: Environmental | **Management Score构成**: Governance and Strategy + Targets + Performance

### Sustainability Indicators

1. 【官方】Scope of policies to address environmental impact - air emissions, water discharges and waste（解决环境影响的政策范围——大气排放、污水排放和废弃物）
2. 【官方】Evidence of an Environmental Management System - EMS（环境管理体系的证据）
3. 【官方】Percentage of sites with EMS certified to ISO 14001 or similar（通过ISO 14001或类似认证的工厂百分比）
4. 【官方】Extent of programs to reduce toxic release footprint associated with supply chain（减少供应链有毒物质排放足迹的计划范围）
5. 【官方】Regular audits of environmental impact of its operations（定期审计公司运营的环境影响）
6. 【官方】Evidence of audits across all locations of operations（环境审计覆盖所有业务地点的证据）
7. 【官方】Evidence of annual environmental impact audits（年度环境影响审计的证据）
8. 【官方】Executive body responsible for environmental management strategy and performance（负责环境管理战略和绩效的执行机构）
9. 【官方】Environmental performance as a factor in executive compensation（将环境绩效纳入影响高管薪酬的因素）
10. 【官方】Programs to reduce toxic emissions and waste in core operations（在核心业务中开展有毒物质和废弃物减排的计划）
11. 【补充】危险废物和非危险废物的产生量、处置方式是否分类披露
12. 【补充】废物循环利用率是否计算并逐年改善
13. 【补充】环保投入金额
14. 【补充】环境违规处罚记录

### 目标类指标
- 【官方】Aggressiveness of toxic emissions and waste reduction target（有毒排放和废物减少目标的积极性）
- 【官方】Track record of achieving toxic emissions targets（实现自身有毒物质排放目标的追踪记录）
- 【官方】Evidence of ongoing/future target(s) to reduce toxic emissions and waste（减少有毒排放与废弃物的目前/未来目标的证据）
- 【官方】Toxic Emissions and Waste Reduction Targets（有毒排放物和废弃物的减排目标）
- 【官方】Fine and Legal Settlements（罚款和法律和解/赔偿）

### Performance指标
- 【官方】NOx emissions performance relative to peers（NOx排放绩效相对于同业表现）
- 【官方】SOx emissions performance relative to peers（SOx排放绩效相对于同业表现）
- 【官方】VOC emissions performance relative to peers（VOC排放绩效相对于同业表现）
- 【官方】Particulate matter emissions performance relative to peers（颗粒物排放绩效相对于同业表现）
- 【官方】Hazardous waste performance relative to peers（危险废物绩效相对于同业表现）
- 【官方】Non-hazardous waste performance relative to peers（非危险废物绩效相对于同业表现）

### 争议事件检查
- Toxic emissions and spills controversies（有毒排放和泄漏争议）

---

## Water Stress（水资源压力）

**支柱**: Environmental | **Management Score构成**: Strategy + Targets + Performance

### Sustainability Indicators

1. 【官方】Use of alternative water（替代水源的使用）
2. 【官方】Scope of water reduction programs at own operations（自有运营中水资源减少计划的范围）
3. 【官方】Programs to reduce water use in value chains（减少价值链用水的计划）
4. 【官方】Water recycling rate score（水循环利用率评分）
5. 【官方】Executive body responsible for water management strategy and performance（负责水资源管理战略和绩效的执行机构）
6. 【补充】取水量、排水量的量化数据及趋势
7. 【补充】高水压力地区的运营占比是否识别和披露

### 目标类指标
- 【官方】Water stress target comprehensiveness（水资源压力目标的全面性）
- 【官方】Water stress target progress（水资源压力目标的进展）

### Performance指标
- 【官方】Freshwater consumption performance relative to peers（淡水消耗绩效相对于同业表现）
- 【官方】Freshwater withdrawal performance relative to peers（淡水取水绩效相对于同业表现）
- 【官方】Water leakage performance relative to peers（水泄漏绩效相对于同业表现）

### 争议事件检查
- Water conflicts controversies（水资源冲突争议）
