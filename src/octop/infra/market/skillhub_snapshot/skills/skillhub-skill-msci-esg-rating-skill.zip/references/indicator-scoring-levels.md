# Sustainability Indicator多级评分参考

本文件基于MSCI官方方法论中的管理实践评估框架。诊断时将企业披露内容与对应类型的评分级别匹配，从最高级别开始向下匹配。【方法论+策略建议】

---

## 1. 政策范围类（Policy Scope）
适用：各类ESG政策的覆盖范围和深度

🟢 L1: Comprehensive policies in all key areas（全面的政策覆盖所有关键领域）
🟡 L2: Significant commitments in key areas（在关键领域有重要承诺）
🟠 L3: Standard statements or commitments（标准声明或承诺）
🔴 L4: Limited policies（有限的政策）
⚫ L5: No evidence（无证据）


⚠️ **常见高估陷阱**：公司有"全面政策"但仅以一般性语言表述（如"我们致力于环境保护"），缺少具体的管控措施、量化目标和责任分工。MSCI区分"Comprehensive policies"和"Standard statements"的关键在于是否有具体的管理程序和责任机制，而非仅有承诺性表述。

## 2. 认证覆盖类（Certification Coverage）
适用：ISO 14001/45001/9001/27001等管理体系认证

🟢 L1: Certified across all relevant operations（所有相关运营通过认证）
🟡 L2: Certified across selected operations（选定运营通过认证）
🟠 L3: General statements on certification（有认证的一般说明，未具体到运营点）
⚫ L4: No evidence（无证据）


⚠️ **常见高估陷阱**：公司以总部/母公司名义获得认证，但未说明具体覆盖了哪些生产基地。MSCI要求"all relevant operations"级别的认证必须覆盖所有实质性运营点，以公司主体名义说明而未具体到运营点通常只能评为L3。

## 3. 审计频率与范围类（Audit Frequency & Scope）
适用：环境审计、道德审计、供应商审计等

🟢 L1: External independent audits of all relevant operations, at least once every 3 years（至少每3年对所有运营进行外部独立审计）
🟡 L2: External independent audits of selected operations（对选定运营进行外部独立审计）
🟠 L3: Internal audits of all relevant operations at least once every 3 years（至少每3年对所有运营进行内部审计）
🟠 L4: Internal audits of selected operations（对选定运营进行内部审计）
🔴 L5: Evidence of audits but no specific details / not on regular schedule（有审计证据但无具体细节/未按常规计划）
⚫ L6: No evidence（无证据）


⚠️ **常见高估陷阱**：混淆"ISO体系年审"与"环境影响独立审计"。ISO认证维护审核是认证机构的例行工作，MSCI关注的是公司是否主动委托独立机构对环境影响进行实质性审计，且覆盖全部运营点。此外，审计的内容、频率、范围三个维度分别评估。

## 4. 管理项目/减排计划类（Programs & Initiatives）
适用：各类环境/社会管理项目的覆盖范围

🟢 L1: Programs across all operations（所有运营覆盖的项目）
🟡 L2: Programs across selected operations（选定运营覆盖的项目）
🟠 L3: General statement on programs（有项目的一般声明）
🔴 L4: Minimum practices based on domestic norms（以国内规范为基础的最低标准）
⚫ L5: No evidence（无证据）


⚠️ **常见高估陷阱**：公司声称"在所有基地实施减排项目"，但缺少量化的减排效果数据或项目覆盖证据。L1要求的是有证据表明项目覆盖了所有相关运营，而非笼统声明。

## 5. 治理架构/管理层级类（Oversight Level）
适用：负责某议题的最高管理层级

🟢 L1: Board-level committee（董事会级别委员会）
🟡 L2: Executive committee / C-suite（执行委员会/高管层）
🟠 L3: Special task force or risk officer（专门工作组或风险官）
🔴 L4: CSR/Sustainability team（企业社会责任/可持续发展团队）
⚫ L5: No evidence（无证据）


⚠️ **常见高估陷阱**：ESG委员会名义上设在董事会层级，但实际上由管理层运作且董事会不直接参与决策。MSCI看的是实质性监督而非名义架构。

## 6. 绩效与薪酬挂钩类（Compensation Linkage）
适用：环境/安全/ESG绩效与高管薪酬挂钩程度

🟢 L1: Compensation reduction due to decline in performance（因绩效下降导致薪酬减少的实证）
🟡 L2: Performance linked to compensation with specific metrics（绩效与薪酬挂钩并有具体指标）
🟠 L3: General statement on linking performance to compensation（有挂钩的一般声明）
⚫ L4: No evidence（无证据）


⚠️ **常见高估陷阱**：公司声称"ESG绩效与薪酬挂钩"，但未说明具体挂钩的ESG指标、权重和奖惩机制。"一般声明"（L3）和"有具体指标的挂钩"（L2）以及"因绩效下降实际导致薪酬减少的实证"（L1）之间差距很大。Strategy和Targets是分开评分的——战略可以是TOP但目标仍可能是LOW。

## 7. 目标达成追踪类（Target Progress）
适用：减排目标、安全目标等的达成记录

🟢 L1: Met or exceeded previous targets（已达成或超额完成先前目标）
🟡 L2: On track to meet targets（正在达成目标的轨道上）
🟠 L3: Mixed record of meeting targets（达成记录好坏参半）
🔴 L4: Largely failed to meet targets（基本未达成目标）
⚫ L5: No previous targets（未设定目标）


⚠️ **常见高估陷阱**：公司设定的目标已提前达成，看似优秀，但如果未设定新的更高目标（next-generation targets），MSCI可能认为目标缺乏前瞻性。此外，目标的"积极性"（aggressiveness）和"达成记录"是分开评估的。

## 8. 供应链管理类（Supply Chain Management）
适用：供应商在某议题上的管理程度

🟢 L1: Suppliers subject to performance screening and audits（供应商接受绩效筛查与审核）
🟡 L2: A few initiatives with suppliers（针对供应商的部分举措）
🟠 L3: General statements on supplier management（供应商管理的一般声明）
⚫ L4: No evidence（无证据）


⚠️ **常见高估陷阱**：有供应商行为准则但缺少实际的审核和绩效筛查证据。MSCI区分"有政策要求"和"有实际执行和审核"——仅有准则但无审核记录通常评为L2而非L1。

## 9. 战略聚焦类（Strategic Focus）
适用：清洁技术、可再生能源等机遇类议题的战略定位

🟢 L1: Core strategy with dedicated resources and investment（核心战略并配备专门资源和投入）
🟡 L2: Among key strategic objectives（主要战略目标之一）
🟠 L3: Some initiatives（一些行动举措）
⚫ L4: Not disclosed（未披露）


⚠️ **常见高估陷阱**：公司声称"清洁技术是核心战略"（满足L1），但缺少明确的投资增长目标。MSCI将"Strategy"和"Targets"分开评分——Strategy可以是TOP，但Targets仍可能是LOW。此时整体Practices Score会被拉低。

## 10. 行业相对绩效类（Performance Relative to Peers）
适用：所有Performance Score下的量化指标

🟢 L1: Top quartile relative to industry peers（行业同业前25%）
🟡 L2: Above average relative to peers（高于行业平均）
🟠 L3: Average relative to peers（行业平均水平）
🔴 L4: Below average relative to peers（低于行业平均）
⚫ L5: Bottom quartile or no data（行业末25%或无数据）

**注意**：Performance指标基于行业相对排名评分（0-10），因无法获取行业平均水平，本诊断无法精确确定企业在同业中的绩效位置。以下评估基于披露充分性，实际得分需以MSCI评级结果为准。

## 11. 劳工政策类（Labor Policy）
适用：劳工权利政策的覆盖深度

🟢 L1: Policy covers ILO core conventions plus additional standards（政策覆盖ILO核心公约及更多标准）
🟡 L2: Formal policy referencing ILO core conventions（正式政策引用ILO核心公约）
🟠 L3: General commitment to labor rights（劳工权利一般承诺）
⚫ L4: Limited or no policy（有限的或无政策）

## 12. 范围/程度类（Scope/Extent）
适用：项目、承诺、评估的覆盖范围程度

🟢 L1: Comprehensive scope covering all relevant areas/operations（全面覆盖所有相关领域/运营）
🟡 L2: Significant scope covering most areas（覆盖大部分领域）
🟠 L3: Moderate scope covering selected areas（覆盖选定领域）
🔴 L4: Limited scope（有限范围）
⚫ L5: No evidence（无证据）

## 13. 量化披露类（Quantitative Disclosure）
适用：需要披露具体百分比、数值的指标

🟢 L1: Comprehensive data disclosed with trend (3+ years)（全面数据披露并有趋势，3年以上）
🟡 L2: Data disclosed for current year（披露当年数据）
🟠 L3: Partial data or estimates（部分数据或估算值）
⚫ L4: Not disclosed（未披露）

## 14. 利益相关方参与类（Stakeholder Engagement）
适用：社区参与、外部合作等

🟢 L1: Formal structured engagement with multiple stakeholder groups（与多个利益相关方群体的正式结构化参与）
🟡 L2: Engagement with selected stakeholders（与选定利益相关方参与）
🟠 L3: General statements on engagement（参与的一般声明）
⚫ L4: No evidence（无证据）

## 15. 业务参与度类（Business Involvement Level）
适用：清洁技术、可再生能源等机遇类议题的业务参与程度

🟢 L1: Pure play - revenues >50%（单一业务，营收超50%）
🟡 L2: Core business - revenues 20-50%（核心业务，营收20-50%）
🟠 L3: Non-core involvement - revenues <20%（非核心参与，营收<20%）
🔴 L4: R&D underway / exploring opportunities（正在进行研发/探索机遇）
⚫ L5: No involvement（无涉及）


⚠️ **常见高估陷阱**：公司将所有"绿色相关"业务都归入清洁技术收入，但MSCI对清洁技术产品线有严格的分类定义（如Alternative Energy、Energy Efficiency等细分品类），非核心参与的业务线应归入更低级别。MSCI通过自有的清洁技术收入估算模型独立评估，企业自述的收入占比可能与MSCI估算不一致。

## 16. 培训范围类（Training Scope）
适用：员工培训的覆盖范围

🟢 L1: Programs covering all employees including part-time and contractors（覆盖所有员工含兼职和承包商）
🟡 L2: Programs covering all full-time employees（覆盖所有全职员工）
🟠 L3: Programs covering selected employees or general statement（覆盖部分员工或一般声明）
⚫ L4: No evidence（无证据）

## 17. 数据安全应对类（Data Security Response）
适用：数据泄露应对和信息安全管理

🟢 L1: Comprehensive response plan with regular testing and drills（全面应对计划含定期测试演练）
🟡 L2: Documented response plan（有文档化的应对计划）
🟠 L3: General statements on security measures（安全措施的一般声明）
⚫ L4: No evidence（无证据）

## 18. 员工福利类（Employee Benefits）
适用：员工福利和薪酬实践

🟢 L1: All employees eligible（所有员工享有资格）
🟡 L2: Majority of workforce eligible（大部分员工享有资格）
🟠 L3: Selected employees eligible（部分员工享有资格）
⚫ L4: Not disclosed（未披露）
