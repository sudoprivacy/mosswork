# 争议事件扣分矩阵与管理规则

## 1. E&S Key Issue的Controversy Deduction

| 严重程度 | Direct+Ongoing | Direct+Partial | Direct+Concluded | Indirect+Ongoing | Indirect+Partial | Indirect+Concluded |
|---|---|---|---|---|---|---|
| Very Severe | -5.0 | -4.0 | -3.0 | -3.0 | -2.0 | -1.0 |
| Severe | -3.6 | -2.8 | -2.4 | -2.4 | -1.6 | -0.8 |
| Moderate | -1.8 | -1.6 | -1.2 | -1.2 | -0.8 | -0.4 |
| Minor | -0.6 | -0.2 | 0.0 | 0.0 | 0.0 | 0.0 |

同一KI多个争议取单一最高扣分（不累加）。

## 2. Business Ethics的Corporate Behavior Controversy Deduction（最高-7.0）

| 严重程度 | Direct+Ongoing | Direct+Partial | Direct+Concluded | Indirect+Ongoing |
|---|---|---|---|---|
| Very Severe | -7.0 | -5.6 | -4.2 | -4.2 |
| Severe | -3.6 | -2.8 | -2.4 | -2.4 |
| Moderate | -1.8 | -1.6 | -1.2 | -1.2 |

## 3. 严重程度评估（Nature × Scale）

| | Very Serious Nature | Serious | Medium | Minimal |
|---|---|---|---|---|
| Extremely Widespread | Very Severe | Severe | Severe | Moderate |
| Extensive | Very Severe | Severe | Moderate | Moderate |
| Limited | Severe | Moderate | Minor | Minor |
| Low | Moderate | Moderate | Minor | Minor |

## 4. 结案条件

自然结案时间（无新公开批评）：Moderate=1年, Severe=2年, Very Severe=3年。
结案后1年归档。

## 5. 推动结案的策略

| 当前→目标 | Severe Direct扣分变化 | 行动要点 |
|---|---|---|
| Ongoing → Partially Concluded | -3.6 → -2.8 | 发布公开补救措施 |
| Partially → Concluded | -2.8 → -2.4 | 完成整改+无新负面报道 |
| Concluded → 归档 | -2.4 → 0 | 结案后1年自动 |
