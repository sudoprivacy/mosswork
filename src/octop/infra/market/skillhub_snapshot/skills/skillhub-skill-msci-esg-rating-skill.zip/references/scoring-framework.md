# MSCI ESG评级核心评分框架

## 1. 评级计算链路

各Key Issue: Exposure Score + Management Score → Key Issue Score (KI Score) → 加权平均 → WAKIS → 行业标准化 → IAS → 字母评级

## 2. IAS与字母评级

IAS = 10 × (WAKIS - industry_min) / (industry_max - industry_min)

| 评级 | IAS区间 |
|---|---|
| AAA | 8.571 - 10.0 |
| AA | 7.143 - 8.571 |
| A | 5.714 - 7.143 |
| BBB | 4.286 - 5.714 |
| BB | 2.857 - 4.286 |
| B | 1.429 - 2.857 |
| CCC | 0 - 1.429 |

**Rating Band Buffer**：评级档位边界设±0.1分缓冲区。

## 3. E&S Key Issue评分

### 3.1 风险类Key Issue
**KI = 7 - (max(Exp, 2) - Mgmt)**

| Exposure Score | Mgmt需达多少才KI≥7（A级）？ | Mgmt需达多少才KI≥5（BBB底线）？ |
|---|---|---|
| 2（低） | 2 | 0 |
| 4（中低） | 4 | 2 |
| 6（中高） | 6 | 4 |
| 8（高） | 8 | 6 |
| 10（极高） | 10（不可达） | 8 |

### 3.2 机遇类Key Issue
高Exposure时Management好→得分远超5，Management差→远低于5。低Exposure时得分被约束在5附近。

## 4. Management Score构成

**Management Score = Practices × 权重 + Performance × 权重 - Controversy Deduction**

### 4.1 Practices组件
评估：组织架构与管理承诺、政策范围与强度、项目/倡议/目标的完善程度。

**关键提醒**：Management Score不是Practices各指标的简单平均。MSCI有内部的组件权重和聚合方式（v5.0引入了indicator-level weighting和standardized aggregation）。通常Practices在Management Score中的权重为60-70%（有Performance数据时），Performance为30-40%。但当Performance数据缺失时，Practices权重可能接近100%。

**重要特征**：单个LOW指标可能产生不成比例的拖累效应——例如一个Key Issue下有5个Practices指标，4个为TOP但1个为LOW，整体Practices Score不会是8/10而可能是6-7/10。AI在推导时应采用**保守中值**而非乐观上限。

### 4.2 Performance组件（v5.0标准化框架）
- **Intensity Score**（当前水平，权重75-100%）：基于3年平均值，行业相对排名标准化（0-10）
- **Trend Score**（变化趋势，权重0-25%）：需至少2年数据

**关键规则**：
- 未披露Performance数据时赋予"低于行业平均"的默认分数，通常为3/10
- Performance是行业**相对**排名，即使企业绝对值改善，如果同业改善更快，相对排名可能不变甚至下降
- Performance Score对最终KI Score的影响取决于Exposure水平——高Exposure行业中Performance的影响更大

v5.0标准化Performance评分适用于：Carbon Emissions、Water Stress、Toxic Emissions & Waste、Health & Safety、Human Capital Development、Biodiversity & Land Use、Product Safety & Quality、Opportunities in Renewable Energy、Product Carbon Footprint、Opportunities in Clean Tech。

### 4.3 Controversy Deduction
见controversy-matrix.md。同一KI有多个争议时，取单一最高扣分（不累加）。

**关键提醒**：一个Severe级Direct+Ongoing的争议扣3.6分，可以直接将一个原本7分的Management Score拉到3.4分。争议管理是ESG评级的"防守端"，一次重大争议可以抵消多年的管理实践积累。

## 5. G支柱评分逻辑

### 5.1 扣分制
从10分起扣。**Score = 10 - (10 × Points / Maximum Value)**

Maximum Value：Governance Pillar=128, Corporate Governance Theme=100, Corporate Behavior Theme=50

### 5.2 G支柱的Key Issue构成
- Board / Pay / Ownership & Control / Accounting → Corporate Governance Theme
- Business Ethics / Tax Transparency → Corporate Behavior Theme
- Securities Violations和Executive Misconduct的Points计入Business Ethics

## 6. 三条提分路径

**路径1：G支柱**——权重≥33%，扣分制意味着改善一个Key Metric立即减少扣分。
**路径2：高权重E/S Key Issue的Management Score**——Practices见效快，Performance需数据积累。
**路径3：争议事件管理**——一个Very Severe争议可扣5分（E&S）或7分（BE）。

## 7. 评级更新时机

- 年度复审：至少每年一次
- 数据驱动：大变动~3个月，小变动~6个月
- 事件驱动：争议升降级、GICS重分类、重大并购
- Industry Min/Max中期更新：约每3-6个月，每次5-20个行业
