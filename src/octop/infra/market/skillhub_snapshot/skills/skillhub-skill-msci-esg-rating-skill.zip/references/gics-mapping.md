# GICS Sub-Industry Classification Map (2025)

Total: 170 sub-industries.

## 行业选择指引

**行业选择是诊断的基础**——选错行业会导致所有权重偏差。如果对行业归属有疑问，应列出2-3个候选让用户确认。

**判定优先级**：
1. 如有MSCI报告，直接读取报告中的"Industry"标注
2. 如无MSCI报告，按公司主营业务收入占比最大的业务线匹配下方的典型业务描述
3. 如仍不确定，查看MSCI同行业已评级企业（可在MSCI ESG Ratings Search中搜索）

## 主要子行业业务描述参考

| 子行业 | 典型业务 | 代表性企业 |
|---|---|---|
| Electrical Components & Equipment | 光伏逆变器、储能系统、低压电器、电气连接器、断路器、配电设备、LED照明、电力电子转换设备 | 阳光电源、正泰电器、施耐德电气、ABB |
| Heavy Electrical Equipment | **大型**发电设备（汽轮机/燃气轮机）、高压输变电成套设备（500kV+）、核电主设备、大型电力变压器 | 东方电气、哈尔滨电气、斗山重工、GE Vernova |
| Semiconductors | 芯片设计与制造、晶圆代工、存储芯片、模拟IC、GPU/CPU、**光伏硅片/电池片/组件制造** | 台积电、英伟达、中芯国际、**隆基绿能、晶科能源** |
| Semiconductor Materials & Equipment | 光刻机、刻蚀设备、硅片、光掩膜、电子特气 | ASML、应用材料、沪硅产业 |
| Electronic Equipment, Instruments & Components | 工业电子仪器、测试测量设备、电子制造服务（EMS） | 富士康、海康威视、安捷伦 |
| Electronic Components | 被动元件（电容/电阻/电感）、PCB、连接器、继电器 | 村田、三环集团、鹏鼎控股 |
| Commodity Chemicals | 基础化工（乙烯、丙烯、PVC、烧碱）、大宗化学品 | 万华化学、中国石化化工板块 |
| Specialty Chemicals | 精细化工、涂料、粘合剂、催化剂、电子化学品 | 新和成、阿克苏诺贝尔 |
| Construction & Engineering | 工程建设（EPC）、基础设施建设、工业工程 | 中国建筑、中国中铁 |
| Construction Materials | 水泥、混凝土、砖瓦、骨料、预制构件 | 海螺水泥、中国建材 |
| Steel | 钢铁冶炼、钢材加工、特种钢 | 宝钢、河钢 |
| Aluminum | 电解铝、铝加工、氧化铝 | 中国铝业、南山铝业 |
| Automotive Parts & Equipment | 汽车零部件（制动、转向、车灯、座椅）、动力电池、汽车电子 | 宁德时代、福耀玻璃、博世 |
| Automobile Manufacturers | 整车制造（乘用车/商用车） | 比亚迪、丰田、特斯拉 |
| Electric Utilities | 发电和输配电（以火电/水电/核电为主） | 华能国际、国电投、Enel |
| Renewable Electricity | 风力发电、光伏发电、**发电运营商**（非设备制造商） | 龙源电力、协鑫新能源、NextEra |
| Independent Power Producers & Energy Traders | 独立发电商、电力交易商 | 华润电力 |
| Diversified Banks | 综合性商业银行 | 工商银行、招商银行 |
| Regional Banks | 区域性/城市商业银行 | 北京银行、宁波银行 |
| Pharmaceuticals | 制药（化学药、生物药、仿制药） | 恒瑞医药、辉瑞 |
| Biotechnology | 生物技术（基因治疗、抗体药物、疫苗） | 百济神州、药明生物 |
| Application Software | 应用软件（ERP、CRM、SaaS） | 用友网络、Salesforce |
| Systems Software | 系统软件（操作系统、数据库、网络安全） | 微软、Oracle、奇安信 |
| Interactive Media & Services | 互联网平台（搜索、社交、在线广告） | 腾讯、Meta、字节跳动 |
| Packaged Foods & Meats | 包装食品（乳制品、肉制品、方便食品） | 伊利、海天、雀巢 |
| Personal Care Products | 日化（护肤品、洗护用品、化妆品） | 珀莱雅、欧莱雅 |
| Household Appliances | 家用电器（冰箱、洗衣机、空调、小家电） | 美的、海尔、格力 |
| Industrial Machinery & Supplies & Components | 通用机械、工业自动化设备、轴承、阀门 | 汇川技术、三一重工（泵送设备） |
| Construction Machinery & Heavy Transportation Equipment | 挖掘机、起重机、推土机、重型运输设备 | 三一重工（挖机）、中联重科 |
| Property & Casualty Insurance | 财产保险（车险、企财险、责任险） | 中国平安（财险）、人保财险 |
| Life & Health Insurance | 人寿和健康保险 | 中国人寿、友邦保险 |
| Diversified REITs | 多元化房地产投资信托基金 | — |
| Marine Transportation | 远洋货运、油轮、干散货运输 | 中远海控、招商轮船 |
| Passenger Airlines | 客运航空公司 | 中国国航、南方航空 |

## 常见混淆辨析

以下行业对在实际分类中容易混淆，MSCI的分类依据是**主营业务收入来源**而非产品应用场景：

### ⚠️ Electrical Components & Equipment vs Heavy Electrical Equipment

| 判断维度 | Electrical Components & Equipment（20104010） | Heavy Electrical Equipment（20104020） |
|---|---|---|
| 典型产品 | 光伏逆变器、储能系统、低压电器、变频器、电力电子设备 | 大型汽轮机/燃气轮机、高压输变电成套设备（500kV+）、核电岛主设备 |
| 产品特征 | 中小型、模块化、批量生产 | 大型、定制化、项目制交付 |
| **快速判断**：如果公司的主要产品**不需要在客户现场进行大规模土建安装**，通常属于Electrical Components & Equipment |

> 💡 阳光电源、正泰电器、施耐德电气 → Electrical Components & Equipment
> 东方电气、哈尔滨电气、GE Vernova → Heavy Electrical Equipment

### ⚠️ Renewable Electricity vs Electrical Components & Equipment

| 判断维度 | Renewable Electricity（55103020） | Electrical Components & Equipment（20104010） |
|---|---|---|
| 核心业务 | **运营**风电场/光伏电站，**卖电**获取收入 | **制造**光伏逆变器/风电变流器等设备，**卖设备**获取收入 |
| **快速判断**：收入主要来自售电 → Renewable Electricity；收入主要来自设备销售 → Electrical Components & Equipment |

### ⚠️ Automotive Parts & Equipment vs Automobile Manufacturers

| 判断维度 | Automotive Parts（25101010） | Automobile Manufacturers（25102010） |
|---|---|---|
| 核心业务 | 制造零部件供应给整车厂 | 制造整车直接面向消费者 |
| **快速判断**：宁德时代（电池）→ Automotive Parts；比亚迪（整车）→ Automobile Manufacturers |

### ⚠️ Semiconductors vs Electrical Components & Equipment vs Renewable Electricity（光伏产业链）

光伏产业链上中下游在MSCI中属于**三个完全不同的行业**，Key Issue权重差异很大：

| 产业链环节 | GICS子行业 | MSCI评级行业 | 判断依据 |
|---|---|---|---|
| 硅片/电池片/组件**制造** | Semiconductors（45301020） | Semiconductors & Semiconductor Equipment | 光伏电池是半导体器件（硅基PN结），收入来自卖组件/电池 |
| 逆变器/储能/BOS**设备** | Electrical Components & Equipment（20104010） | Electrical Equipment | 电力电子转换设备，收入来自卖设备 |
| 光伏电站**运营/发电** | Renewable Electricity（55103020） | Utilities | 收入来自卖电 |

> 💡 隆基、晶科、天合、晶澳 → **Semiconductors**（非Electrical Equipment）
> 阳光电源、正泰电器 → **Electrical Equipment**
> 龙源电力、协鑫新能源 → **Renewable Electricity**

**常见错误**：把光伏组件制造商误分到Electrical Equipment。虽然光伏组件是"电气设备"，但GICS按产品的技术本质（半导体器件）而非应用场景（发电）分类。

### ⚠️ Commodity Chemicals vs Specialty Chemicals

| 判断维度 | Commodity Chemicals（15101010） | Specialty Chemicals（15101030） |
|---|---|---|
| 产品特征 | 大宗标准化产品，按吨定价 | 高附加值配方产品，按功能/性能定价 |
| **快速判断**：产品有公开大宗商品报价 → Commodity；产品需要技术服务/定制配方 → Specialty |

## 10 Energy

| Code | Sub-Industry | Industry |
|---|---|---|
| 10101010 | Oil & Gas Drilling | Energy Equipment & Services |
| 10101020 | Oil & Gas Equipment & Services | Energy Equipment & Services |
| 10102010 | Integrated Oil & Gas | Oil, Gas & Consumable Fuels |
| 10102020 | Oil & Gas Exploration & Production | Oil, Gas & Consumable Fuels |
| 10102030 | Oil & Gas Refining & Marketing | Oil, Gas & Consumable Fuels |
| 10102040 | Oil & Gas Storage & Transportation | Oil, Gas & Consumable Fuels |
| 10102050 | Coal & Consumable Fuels | Oil, Gas & Consumable Fuels |

## 15 Materials

| Code | Sub-Industry | Industry |
|---|---|---|
| 15101010 | Commodity Chemicals | Chemicals |
| 15101020 | Diversified Chemicals | Chemicals |
| 15101030 | Fertilizers & Agricultural Chemicals | Chemicals |
| 15101040 | Industrial Gases | Chemicals |
| 15101050 | Specialty Chemicals | Chemicals |
| 15102010 | Construction Materials | Construction Materials |
| 15103010 | Metal, Glass & Plastic Containers  (New Name) | Containers & Packaging |
| 15103020 | Paper & Plastic Packaging Products & Materials (New Name) | Containers & Packaging |
| 15104010 | Aluminum | Metals & Mining |
| 15104020 | Diversified Metals & Mining | Metals & Mining |
| 15104025 | Copper | Metals & Mining |
| 15104030 | Gold | Metals & Mining |
| 15104040 | Precious Metals & Minerals | Metals & Mining |
| 15104045 | Silver | Metals & Mining |
| 15104050 | Steel | Metals & Mining |
| 15105010 | Forest Products | Paper & Forest Products |
| 15105020 | Paper Products | Paper & Forest Products |

## 20 Industrials

| Code | Sub-Industry | Industry |
|---|---|---|
| 20101010 | Aerospace & Defense | Aerospace & Defense |
| 20102010 | Building Products | Building Products |
| 20103010 | Construction & Engineering | Construction & Engineering |
| 20104010 | Electrical Components & Equipment | Electrical Equipment |
| 20104020 | Heavy Electrical Equipment | Electrical Equipment |
| 20105010 | Industrial Conglomerates | Industrial Conglomerates |
| 20106010 | Construction Machinery & Heavy Transportation Equipment (New Name) | Machinery |
| 20106015 | Agricultural & Farm Machinery | Machinery |
| 20106020 | Industrial Machinery & Supplies & Components (New Name) | Machinery |
| 20107010 | Trading Companies & Distributors | Trading Companies & Distributors |
| 20201010 | Commercial Printing | Commercial Services & Supplies |
| 20201050 | Environmental & Facilities Services | Commercial Services & Supplies |
| 20201060 | Office Services & Supplies | Commercial Services & Supplies |
| 20201070 | Diversified Support Services | Commercial Services & Supplies |
| 20201080 | Security & Alarm Services | Commercial Services & Supplies |
| 20202010 | Human Resource & Employment Services (Definition Update) | Professional Services |
| 20202020 | Research & Consulting Services | Professional Services |
| 20202030 | Data Processing & Outsourced Services (Sector Change, New Code & Definition Update) | Professional Services |
| 20301010 | Air Freight & Logistics | Air Freight & Logistics |
| 20302010 | Passenger Airlines (New name) | Passenger Airlines (New name) |
| 20303010 | Marine Transportation (New Name) | Marine Transportation (New Name) |
| 20304010 | Rail Transportation (New Name) | Ground Transportation (New Name) |
| 20304020 | Trucking (Discontinued) | Ground Transportation (New Name) |
| 20304030 | Cargo Ground Transportation (New) | Ground Transportation (New Name) |
| 20304040 | Passenger Ground Transportation (New) | Ground Transportation (New Name) |
| 20305010 | Airport Services | Transportation Infrastructure |
| 20305020 | Highways & Railtracks | Transportation Infrastructure |
| 20305030 | Marine Ports & Services | Transportation Infrastructure |

## 25 Consumer Discretionary

| Code | Sub-Industry | Industry |
|---|---|---|
| 25101010 | Automotive Parts & Equipment (New Name) | Automobile Components (New Name) |
| 25101020 | Tires & Rubber | Automobile Components (New Name) |
| 25102010 | Automobile Manufacturers | Automobiles |
| 25102020 | Motorcycle Manufacturers | Automobiles |
| 25201010 | Consumer Electronics | Household Durables |
| 25201020 | Home Furnishings | Household Durables |
| 25201030 | Homebuilding | Household Durables |
| 25201040 | Household Appliances | Household Durables |
| 25201050 | Housewares & Specialties | Household Durables |
| 25202010 | Leisure Products | Leisure Products |
| 25203010 | Apparel, Accessories & Luxury Goods | Textiles, Apparel & Luxury Goods |
| 25203020 | Footwear | Textiles, Apparel & Luxury Goods |
| 25203030 | Textiles | Textiles, Apparel & Luxury Goods |
| 25301010 | Casinos & Gaming | Hotels, Restaurants & Leisure |
| 25301020 | Hotels, Resorts & Cruise Lines | Hotels, Restaurants & Leisure |
| 25301030 | Leisure Facilities | Hotels, Restaurants & Leisure |
| 25301040 | Restaurants | Hotels, Restaurants & Leisure |
| 25302010 | Education Services | Diversified Consumer Services |
| 25302020 | Specialized Consumer Services | Diversified Consumer Services |
| 25501010 | Distributors | Distributors |
| 25502020 | Internet & Direct Marketing Retail (Discontinued) | Internet & Direct Marketing Retail (Discontinued) |
| 25503010 | Department Stores (Discontinued) | Broadline Retail (New Name) |
| 25503020 | General Merchandise Stores (Discontinued) | Broadline Retail (New Name) |
| 25503030 | Broadline Retail (New) | Broadline Retail (New Name) |
| 25504010 | Apparel Retail | Specialty Retail |
| 25504020 | Computer & Electronics Retail | Specialty Retail |
| 25504030 | Home Improvement Retail | Specialty Retail |
| 25504040 | Other Specialty Retail (New Name) | Specialty Retail |
| 25504050 | Automotive Retail | Specialty Retail |
| 25504060 | Homefurnishing Retail | Specialty Retail |

## 30 Consumer Staples

| Code | Sub-Industry | Industry |
|---|---|---|
| 30101010 | Drug Retail | Consumer Staples Distribution & Retail (New Name) |
| 30101020 | Food Distributors | Consumer Staples Distribution & Retail (New Name) |
| 30101030 | Food Retail | Consumer Staples Distribution & Retail (New Name) |
| 30101040 | Consumer Staples Merchandise Retail (New Name & Definition Update) | Consumer Staples Distribution & Retail (New Name) |
| 30201010 | Brewers | Beverages |
| 30201020 | Distillers & Vintners | Beverages |
| 30201030 | Soft Drinks & Non-alcoholic Beverages (New Name) | Beverages |
| 30202010 | Agricultural Products & Services (New Name) | Food Products |
| 30202030 | Packaged Foods & Meats | Food Products |
| 30203010 | Tobacco | Tobacco |
| 30301010 | Household Products | Household Products |
| 30302010 | Personal Care Products (New Name) | Personal Care Products (New Name) |

## 35 Health Care

| Code | Sub-Industry | Industry |
|---|---|---|
| 35101010 | Health Care Equipment | Health Care Equipment & Supplies |
| 35101020 | Health Care Supplies | Health Care Equipment & Supplies |
| 35102010 | Health Care Distributors | Health Care Providers & Services |
| 35102015 | Health Care Services | Health Care Providers & Services |
| 35102020 | Health Care Facilities | Health Care Providers & Services |
| 35102030 | Managed Health Care | Health Care Providers & Services |
| 35103010 | Health Care Technology | Health Care Technology |
| 35201010 | Biotechnology | Biotechnology |
| 35202010 | Pharmaceuticals | Pharmaceuticals |
| 35203010 | Life Sciences Tools & Services | Life Sciences Tools & Services |

## 40 Financials

| Code | Sub-Industry | Industry |
|---|---|---|
| 40101010 | Diversified Banks | Banks |
| 40101015 | Regional Banks (Definition Update) | Banks |
| 40102010 | Thrifts & Mortgage Finance (Discontinued) | Thrifts & Mortgage Finance (Discontinued) |
| 40201020 | Diversified Financial Services (New Name) | Financial Services (New Name) |
| 40201030 | Multi-Sector Holdings | Financial Services (New Name) |
| 40201040 | Specialized Finance | Financial Services (New Name) |
| 40201050 | Commercial & Residential Mortgage Finance (New) | Financial Services (New Name) |
| 40201060 | Transaction & Payment Processing Services (New) | Financial Services (New Name) |
| 40202010 | Consumer Finance | Consumer Finance |
| 40203010 | Asset Management & Custody Banks | Capital Markets |
| 40203020 | Investment Banking & Brokerage | Capital Markets |
| 40203030 | Diversified Capital Markets | Capital Markets |
| 40203040 | Financial Exchanges & Data | Capital Markets |
| 40204010 | Mortgage REITs* | Mortgage Real Estate Investment
Trusts (REITs) |
| 40301010 | Insurance Brokers | Insurance |
| 40301020 | Life & Health Insurance | Insurance |
| 40301030 | Multi-line Insurance | Insurance |
| 40301040 | Property & Casualty Insurance | Insurance |
| 40301050 | Reinsurance | Insurance |

## 45 Information Technology

| Code | Sub-Industry | Industry |
|---|---|---|
| 45102010 | IT Consulting & Other Services | IT Services |
| 45102020 | Data Processing & Outsourced Services (Discontinued) | IT Services |
| 45102030 | Internet Services & Infrastructure | IT Services |
| 45103010 | Application Software | Software |
| 45103020 | Systems Software | Software |
| 45201020 | Communications Equipment | Communications Equipment |
| 45202030 | Technology Hardware, Storage & Peripherals | Technology Hardware, Storage & Peripherals |
| 45203010 | Electronic Equipment & Instruments | Electronic Equipment, Instruments & Components |
| 45203015 | Electronic Components | Electronic Equipment, Instruments & Components |
| 45203020 | Electronic Manufacturing Services | Electronic Equipment, Instruments & Components |
| 45203030 | Technology Distributors | Electronic Equipment, Instruments & Components |
| 45301010 | Semiconductor Materials & Equipment (New Name) | Semiconductors & Semiconductor Equipment |
| 45301020 | Semiconductors | Semiconductors & Semiconductor Equipment |

## 50 Communication Services

| Code | Sub-Industry | Industry |
|---|---|---|
| 50101010 | Alternative Carriers | Diversified Telecommunication Services |
| 50101020 | Integrated Telecommunication Services | Diversified Telecommunication Services |
| 50102010 | Wireless Telecommunication Services | Wireless Telecommunication Services |
| 50201010 | Advertising | Media |
| 50201020 | Broadcasting | Media |
| 50201030 | Cable & Satellite | Media |
| 50201040 | Publishing | Media |
| 50202010 | Movies & Entertainment | Entertainment |
| 50202020 | Interactive Home Entertainment | Entertainment |
| 50203010 | Interactive Media & Services | Interactive Media & Services |

## 55 Utilities

| Code | Sub-Industry | Industry |
|---|---|---|
| 55101010 | Electric Utilities | Electric Utilities |
| 55102010 | Gas Utilities | Gas Utilities |
| 55103010 | Multi-Utilities | Multi-Utilities |
| 55104010 | Water Utilities | Water Utilities |
| 55105010 | Independent Power Producers & Energy Traders | Independent Power and Renewable Electricity Producers |
| 55105020 | Renewable Electricity | Independent Power and Renewable Electricity Producers |

## 60 Real Estate

| Code | Sub-Industry | Industry |
|---|---|---|
| 60101010 | Diversified REITs* | Diversified REITs (New Name) |
| 60102510 | Industrial REITs* (New Code) | Industrial REITs (New) |
| 60103010 | Hotel & Resort REITs* (New Code) | Hotel & Resort REITs (New) |
| 60104010 | Office REITs* (New Code) | Office REITs (New) |
| 60105010 | Health Care REITs* (New Code) | Health Care REITs (New) |
| 60101060 | Residential REITs (Discontinued) | Health Care REITs (New) |
| 60106010 | Multi-Family Residential REITs* (New) | Residential REITs (New) |
| 60106020 | Single-Family Residential REITs* (New) | Residential REITs (New) |
| 60107010 | Retail REITs* (New Code) | Retail REITs (New) |
| 60108010 | Other Specialized REITs* (New Name/ New Code/Definition Update) | Specialized REITs (New) |
| 60108020 | Self-Storage REITs* (New) | Specialized REITs (New) |
| 60108030 | Telecom Tower REITs* (New) | Specialized REITs (New) |
| 60108040 | Timber REITs* (New) | Specialized REITs (New) |
| 60108050 | Data Center REITs* (New) | Specialized REITs (New) |
| 60201010 | Diversified Real Estate Activities (New Code) | Real Estate Management & Development (New Code) |
| 60201020 | Real Estate Operating Companies (New Code) | Real Estate Management & Development (New Code) |
| 60201030 | Real Estate Development (New Code) | Real Estate Management & Development (New Code) |
| 60201040 | Real Estate Services (New Code) | Real Estate Management & Development (New Code) |
