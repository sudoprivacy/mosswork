# MSCI ESG Rating Diagnostic Skill

一个基于 MSCI ESG Ratings 方法论（v5.0）的 Claude Skill，帮助企业逐指标诊断 ESG 管理差距，并生成按优先级排列的改善行动建议。

## 这个 Skill 能做什么

| 场景 | 说明 |
|---|---|
| **ESG 管理差距诊断** | 对照 MSCI 方法论，逐指标分析企业 ESG 报告和年报，找出披露和管理实践中的改进空间 |
| **评级达标条件推导** | 基于行业权重和评分公式，推导各评级档位所需的得分组合 |
| **行业速查卡编制** | 生成特定行业的 Key Issue 权重、评分要点和常见失分项速查 |

**注意**：这是一个诊断工具，不是评级预测工具。核心价值是"告诉你哪里还能做得更好、具体怎么做"，而非猜测评级结果。

## 快速开始

1. 下载本仓库的全部文件（或 clone 仓库）
2. 在 Claude 中创建一个 Project，将 `msci-esg-rating/` 文件夹下的所有文件上传到 Project Knowledge
3. 开始对话，上传目标企业的 **ESG 报告**和**年度报告**，即可触发诊断

> **为什么需要两份报告？** ESG 报告覆盖 E&S 支柱的大部分指标，但 G 支柱（在多数行业中权重最高，约 44%）的诊断依赖年报中的董事会结构、关联交易、薪酬明细等信息。只上传 ESG 报告也可以用，但 G 支柱诊断会不完整。

## 文件结构

```
msci-esg-rating/
├── SKILL.md                          # 核心工作流程和指令
├── references/
│   ├── scoring-framework.md          # 评分公式和计算逻辑
│   ├── g-pillar-metrics.md           # G 支柱全部扣分指标
│   ├── controversy-matrix.md         # 争议事件扣分矩阵
│   ├── es-environmental-issues.md    # 13 个 E 类 Key Issue 指标清单
│   ├── es-social-issues.md           # 14 个 S 类 Key Issue 指标清单
│   ├── indicator-scoring-levels.md   # 18 类指标的多级评分参考
│   ├── industry-weights.md           # 158 个子行业的 Key Issue 权重
│   ├── gics-mapping.md               # GICS 行业分类映射
│   ├── industry-card-template.md     # 行业速查卡模板
│   └── model-version-history.md      # 方法论版本演进
├── examples/
│   └── diagnostic_example.md         # 完整诊断报告样例（虚构通用案例）
└── evals/
    └── self-check.md                 # 产出质量自检清单
```

## 产出示例

诊断报告包含以下核心模块：

- **行业 Key Issue 权重总览** — 确认行业分类和各议题权重
- **加权 Key Issue 逐项诊断** — 每个指标的"披露现状 → MSCI 最佳实践 → 差距 → 改善方向"
- **G 支柱诊断** — 逐 Key Metric 的扣分分析（扣分制）
- **下一步行动卡** — 按优先级（🔴高/🟡中/🟢低）排列的改善动作
- **评级韧性分析** — 当前支撑因素、风险因素、争议事件预判
- **Data Feedback 策略建议** — "公司已做但 MSCI 可能未收录"的反馈机会

详见 `examples/diagnostic_example.md`。

## 方法论版本

当前基于 **MSCI ESG Ratings Model v5.0**（2026 年 3 月 23 日生效）。

## 局限性

- 部分维度依赖 MSCI 内部数据（如 Exposure Score、Industry Min/Max），AI 无法给出精确数值，报告中会标注 `[不可外部估算]`
- 诊断质量取决于输入报告的完整性和时效性
- 本工具基于公开方法论框架编写，不代表 MSCI 官方立场

## License

本项目采用 [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/) 协议。你可以自由分享和修改，但不得用于商业用途，且需注明出处。
