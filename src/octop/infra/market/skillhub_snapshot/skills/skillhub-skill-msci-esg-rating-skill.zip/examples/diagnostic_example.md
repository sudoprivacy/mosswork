# [示例公司] MSCI ESG评级管理诊断报告

> **本文件用途**：作为msci-esg-rating Skill的`examples/`样例，展示完整诊断报告应有的深度、语气、校准方式和行动导向。
>
> **阅读说明**：本样例为虚构案例，基于Electrical Equipment行业的典型中国上市企业特征编写。所有数据均为示意性数据，旨在演示诊断方法和表达规范，而非反映任何真实企业。实际诊断时应根据用户提供的报告内容逐指标检索分析。
>
> **学习要点**：关注以下几个维度的表达规范——
> - 如何区分TOP/MID/LOW评估并给出依据
> - 如何在校准提示中解释"为什么直觉判断可能偏高"
> - 如何标注[不可外部估算]维度而不编造数值
> - 如何设计优先级分明、可落地的行动卡

---

## 基本信息

| 项目 | 内容 |
|---|---|
| 公司名称 | [示例公司]（虚构） |
| GICS子行业 | Electrical Components & Equipment（20104010） |
| 分析依据 | [示例公司]20XX年年度报告 + 20XX年可持续发展报告 |
| 方法论版本 | MSCI ESG Ratings Model v5.0 |

> 💡 **行业分类说明**：[示例说明] 行业分类是诊断的基石。实际诊断时，必须通过搜索验证MSCI对该企业的行业归类（参见SKILL.md Step 1b）。常见陷阱包括：光伏组件制造商属Semiconductors而非Electrical Equipment，汽车零部件属Auto Components而非Automobiles等。本样例假定行业已确认为Electrical Components & Equipment。

---

## 行业Key Issue权重总览

**Electrical Equipment** — E=32% | S=24% | G=44%

| Key Issue | 支柱 | 权重 | 类型 | 诊断位置 |
|---|---|---|---|---|
| Governance | G | 44% | 标准 | §G支柱诊断 |
| Labor Management | S | 24% | 标准 | §加权Key Issue诊断 |
| Opportunities in Clean Tech | E | 19% | 标准 | §加权Key Issue诊断 |
| Toxic Emissions & Waste | E | 13% | 标准 | §加权Key Issue诊断 |
| Human Capital Development | S | CS | 公司特定 | §附录 |
| Health & Safety | S | CS | 公司特定 | §附录 |
| Biodiversity & Land Use | E | CS | 公司特定 | §附录 |

---

## 加权Key Issue逐项诊断

### 1. Opportunities in Clean Tech（清洁技术机遇）— 权重19%

**类型**：机遇类Key Issue。高Exposure + 强Management → 高分。

#### Sustainability Indicator差距分析

| # | 指标 | 公司披露现状 | MSCI最佳实践（L1） | 评估 | 差距与改善方向 | 出处 |
|---|---|---|---|---|---|---|
| 1 | Strategic focus on clean technology | 公司战略聚焦清洁能源领域，产品线涵盖多个清洁技术方向 | 清洁技术创新是核心战略 | **TOP** | 无差距——战略定位清晰 | ESG Pxx |
| 2 | Targets to increase investment in clean tech | 研发投入金额和人员比例有披露，但**未见"未来N年研发投入增长X%"的量化承诺目标** | 有明确的投资增长目标 | **LOW** ⚠️ | [示例关键差距] 有大量现状数据但缺前瞻性增长目标。MSCI将Strategy和Targets分开评分——Strategy达TOP但Targets仍可能LOW | 年报Pxx |
| 3 | Number of patent families | 累计专利数据有披露。注意：MSCI通过自有数据库独立统计patent families，口径可能与企业自述不同 | 量化数据 | 数据型 | MSCI独立统计，不取企业自述数字 | ESG Pxx |
| 4 | R&D / Sales ratio | 近三年呈上升趋势（如2.5%→3.2%→4.0%） | 量化数据 | 数据型 | 绝对值在行业中的相对位置需结合行业数据判断 | 年报Pxx |
| 5 | Clean Tech revenue involvement | [根据实际业务线比例分析] | MSCI独立估算各业务线分类 | 视情况 | MSCI按自有分类体系评估，部分业务线可能被归为Non-core involvement | 年报·主营 |

#### ⚠️ 校准提示

**[示例：Strategy vs Targets的区分]**
这是一个常见的"直觉偏差"案例：企业战略方向明确（Strategy = TOP），但如果没有设定未来投资增长的量化目标（Targets = LOW），Practices Score会被拖低。根据MSCI的Management Score聚合逻辑（Practices权重60-70%，Performance权重30-40%），单个LOW指标会不成比例地拖累整体。

**为什么与直觉不同**：一家清洁能源企业直觉上Clean Tech应高分。但MSCI评分中，"你是什么"（Performance）和"你怎么管理"（Practices）是分开的。Pure Play清洁能源企业如果不主动设定投资增长目标，Practices仍然会被拉低。

**综合预判**：[应基于具体指标评估结果给出区间估算，标注【推导估算】]

#### 🎯 下一步行动卡

| 优先级 | 改善动作 | 预期效果 | 实施建议 |
|---|---|---|---|
| 🔴 高 | **设定"未来3-5年清洁技术研发投入年增长率≥X%"的量化目标** | Targets从LOW→TOP，Practices Score预计提升1-2分 | 在ESG报告战略章节增加明确表述，例如"公司承诺未来三年研发投入年均增长不低于X%，持续加大清洁技术创新投资" |
| 🟡 中 | 在ESG报告中增加R&D投入的3-5年趋势表格 | 强化MSCI对创新趋势的正面评估 | 当前趋势数据分散于不同报告，建议集中展示 |
| 🟢 低 | 对avoided emissions引入第三方核查 | 强化"气候贡献"叙事可信度 | 当前数据基于估算模型，建议引入独立验证 |

---

### 2. Labor Management（劳工管理）— 权重24%

**类型**：风险类Key Issue。劳工密集度越高（Exposure越高），Management需要越强。

#### Sustainability Indicator差距分析

| # | 指标 | 公司披露现状 | MSCI最佳实践（L1） | 评估 | 差距与改善方向 | 出处 |
|---|---|---|---|---|---|---|
| 1 | Policies to address labor rights | 制定人权政策，引用ILO核心公约，覆盖全体员工 | 政策覆盖ILO核心公约及额外保护 | **TOP** | 已达最佳实践水平 | ESG Pxx |
| 2 | Trade union / collective agreement coverage | 集体谈判协议覆盖率有披露（如100%） | 报告覆盖率百分比 | **TOP** | 覆盖率高且有量化披露 | ESG Pxx |
| 3 | Evidence of collective agreements | 有集体合同签订记录和相关制度 | 有集体协议证据 | **TOP** | 已有明确制度和实践 | ESG Pxx |
| 4 | Variable performance-based pay | 绩效薪酬覆盖全员 | 全员覆盖的强绩效薪酬结构 | **TOP** | 覆盖范围达标 | ESG Pxx |
| 5 | Anti-Discrimination / DEI policy | 有正式的多元化与包容政策 | 有政策 | **TOP** | 已有正式政策 | ESG Pxx |
| 6 | Child labor provision | 人权政策中有明确禁止条款 | 有内部政策条款 | **TOP** | 已有 | ESG Pxx |
| 7 | Forced labor provision | 有反强迫劳动政策和控制程序 | 有内部政策条款 | **TOP** | 已有 | ESG Pxx |
| 8 | Freedom of association provision | 政策中引用ILO结社自由公约 | 有内部政策条款 | **TOP** | 已有 | ESG Pxx |
| 9 | Restructuring policies | **未见明确的"重组/裁员支持计划"专项政策** | 遣散费+再就业支持+再培训证据 | **MID** | [示例差距] 有内部转岗机制但未见正式的重组应对政策。许多中国企业在此项失分 | ESG Pxx |
| 10 | Support for degree programs | 支持员工参与证书考取与继续教育 | 覆盖全员的学位/证书支持计划 | **TOP** | 已达较高覆盖范围 | ESG Pxx |
| 11 | Skills and knowledge development training | 有完善的培训架构和人均培训时数 | 全面的继任规划与发展项目 | **TOP** | 培训体系完善 | ESG Pxx |
| 12 | External recognition as employer of choice | 有最佳雇主类外部认可 | 近3年获最佳雇主认可 | **TOP** | 有国际认可 | ESG Pxx |
| 13 | Strikes / lock-outs | 近三年无罢工/闭厂记录 | 无 | 无扣分 | 无负面事件 | [待确认] |
| 14 | Employee equity programs | 股权激励计划仅覆盖核心骨干员工 | 行业领先的ESOP/ESPP覆盖范围 | **MID** | [示例差距] 仅覆盖核心骨干，非全员覆盖。从MID到TOP需扩大覆盖范围 | 年报·股权激励 |
| 15 | Non-compensation benefits | 报告提及多项福利项目，但**未见结构化的福利清单披露** | 福利覆盖全体员工 | **LOW** ⚠️ | [示例关键失分点] MSCI可能因未见结构化披露而评为"No evidence"。这是一个容易被忽略但影响显著的失分点——企业实际有做但报告形式不符合MSCI期望 | ESG Pxx |
| 16 | Employee satisfaction survey | 有满意度/敬业度调查数据 | 有满意度调查结果 | **TOP** | 有持续追踪和量化数据 | ESG Pxx |
| 17 | Employee turnover | 自愿离职率有量化披露 | 量化数据 | 数据型 | 趋势和绝对值决定评价 | ESG Pxx |

#### ⚠️ 校准提示

**[示例：多数TOP但仍有拖累项]**
Labor Management通常是中国制造业企业的相对优势议题，但需警惕以下常见失分点：
- **Non-compensation benefits**：最容易被忽略的"形式陷阱"——企业实际提供了完善的福利，但报告中未以结构化方式呈现，MSCI可能评为"No evidence"
- **Employee equity programs**：仅覆盖核心骨干（MID）是中国企业的常见状态
- **Restructuring policies**：中国企业较少制定专门的重组支持政策

**整体校准规则**：如果你对某个Key Issue的所有指标都评为TOP，大概率存在过度乐观——即使是全球领先企业，通常也有2-3个指标存在改进空间。

#### 🎯 下一步行动卡

| 优先级 | 改善动作 | 预期效果 | 实施建议 |
|---|---|---|---|
| 🔴 高 | **在ESG报告中增加结构化的Non-compensation benefits清单** | 避免该指标被评为LOW，保护整体Practices Score | 在"员工福利"章节增加包含福利项目名称、覆盖范围、投入金额的表格 |
| 🟡 中 | 制定正式的重组/裁员支持政策 | 将Restructuring policies从MID提升 | 包含遣散方案、再就业支持和再培训等内容 |
| 🟢 低 | 扩大员工股权计划覆盖范围 | 将Employee equity从MID提升至TOP | 从核心骨干扩展至更广泛的员工群体 |

---

### 3. Toxic Emissions & Waste（有毒排放与废弃物）— 权重13%

**类型**：风险类Key Issue。

#### Sustainability Indicator差距分析

| # | 指标 | 公司披露现状 | MSCI最佳实践（L1） | 评估 | 差距与改善方向 | 出处 |
|---|---|---|---|---|---|---|
| 1 | Scope of environmental policies | 有环境管理政策，覆盖主要污染领域 | 所有关键领域的全面政策 | **TOP** | 政策覆盖完整 | ESG Pxx |
| 2 | Evidence of EMS | ISO 14001覆盖所有运营点 | EMS覆盖所有相关运营 | **TOP** | 满覆盖 | ESG Pxx |
| 3 | % sites ISO 14001 certified | 100% | 披露覆盖率百分比 | **TOP** | 满覆盖 | ESG Pxx |
| 4 | Programs to reduce supply chain toxic footprint | 供应商ESG审核有开展，供应商环境认证率有披露 | 供应商绩效筛查和审核 | **TOP** | 有体系 | ESG Pxx |
| 5 | Regular environmental audits | 运营点有外部审核 | 全部运营点的外部独立年度审计 | **TOP** | 已达标 | ESG Pxx |
| 6 | Audits across all locations | 是 | 全部运营点覆盖 | **TOP** | 满覆盖 | ESG Pxx |
| 7 | Annual environmental audits | 是 | 年度审计 | **TOP** | 已有 | ESG Pxx |
| 8 | Aggressiveness of targets | 设定了减排目标 | 量化 | [不可外部估算] | MSCI对目标积极性有独立的1-10评分，外部无法获取 | ESG Pxx |
| 9 | Track record of achieving targets | 已完成先前减排目标。但MSCI**可能未收录**这些达成记录 | 已实现先前目标 | **TOP或LOW** ⚠️ | [示例关键风险] 企业实际已达标，但MSCI数据库可能标注为"No previous targets"——这是典型的Data Feedback机会 | ESG Pxx |
| 10 | Executive body for environmental management | 有董事会级别的可持续发展委员会 | 董事会级别委员会 | **TOP或LOW** ⚠️ | MSCI对"实质性监督vs名义架构"的判定标准可能更严格 | ESG Pxx |
| 11 | Environmental performance linked to compensation | 声明将环保指标纳入考核，但未见"因绩效下降实际导致薪酬减少"的实证 | 因绩效下降导致薪酬减少的实证 | **LOW** ⚠️ | [示例重要区分] 声明性披露≠实证性披露。这是MSCI评分中最常被高估的指标之一 | ESG Pxx |
| 12 | Programs to reduce toxic emissions | 各运营点实施减排项目 | 全部运营覆盖的减排项目 | **MID-TOP** | 有项目和数据，覆盖范围需确认 | ESG Pxx |

**绩效数据**（Performance Score相关——行业相对排名[不可外部估算]）：

| 指标 | Y-2 | Y-1 | Y0 | 趋势 |
|---|---|---|---|---|
| 有毒排放物排放量 | XX | XX | XX | [描述趋势] |
| 排放强度 | XX | XX | XX | [描述趋势] |
| 废弃物总产生量 | XX | XX | XX | [描述趋势] |
| 废弃物资源利用率 | XX% | XX% | XX% | [描述趋势] |
| 环境处罚 | 0 | 0 | 0 | ✅ |

#### ⚠️ 校准提示

**[示例：声明性vs实证性披露的区分]**
"Environmental performance linked to compensation"是最常被高估的指标。企业说"将环保指标纳入考核"（声明性披露），但MSCI对L1的要求是"因绩效下降实际导致薪酬减少的实证"（实证性披露）。这两者之间差距很大。

**Track record指标**：企业实际已完成减排目标但MSCI未收录的情况很常见——应主动通过Data Feedback提交。

**Performance Score注意**：绝对排放量因产能扩张而增加是正常的，MSCI评的是排放强度（单位产出的排放量）。但即使强度在下降，最终Performance Score取决于在行业中的相对排名，[不可外部估算]。

#### 🎯 下一步行动卡

| 优先级 | 改善动作 | 预期效果 | 实施建议 |
|---|---|---|---|
| 🔴 高 | **通过Data Feedback主动提交减排目标达成记录** | 将Track record从LOW→TOP | 提供ESG报告中战略目标进展表格的明确引用 |
| 🔴 高 | **设定新一轮中长期减排目标** | 提升目标积极性评分 | 旧目标到期后需及时设定下一轮更积极的目标 |
| 🟡 中 | 强化ESG与薪酬挂钩的实证披露 | 从声明性披露升级为实证性披露 | 增加"因环境绩效变动导致薪酬调整"的具体案例 |
| 🟡 中 | 如有排放强度反弹，在报告中主动说明原因 | 防止Performance Score误判 | 如因新产能投产导致短期波动，应在报告中披露说明 |

---

## G支柱诊断

G支柱采用扣分制：Score = 10 - (10 × Points / Maximum Value)

### Corporate Governance — Board

| Key Metric | 典型中国企业情况 | 是否flagged | 典型扣分 | 诊断说明 |
|---|---|---|---|---|
| Board Majority Independent | 独立董事占比约33-37%（未过半数）。MSCI判定中，执行董事和前高管均不视为独立 | ⚠️ Flagged | **-0.20** | 中国上市公司独立董事比例普遍在1/3左右，远低于过半数要求 |
| Executives on Board | 多名执行董事在董事会中 | ⚠️ Flagged | **-0.30** | 执行董事占比越高扣分越重 |
| Combined CEO/Chair | CEO与董事长同一人 | ⚠️ Flagged | **-0.20** | 中国民营企业中非常普遍 |
| Independent Chair | 董事长非独立 | ⚠️ Flagged | **-0.10** | — |
| Chair not Independent & No Lead Independent Director | 未设独立首席董事 | ⚠️ Flagged | **-0.10** | CEO/Chair合一时应设Lead Independent Director缓解 |
| Related Party Transactions | 与控股股东存在关联交易 | ⚠️ Flagged | **-0.51** | 金额占比虽低，但MSCI仍因存在控股股东关联交易而flagged |
| Not 30% Female Directors | 女性董事比例低于30% | ⚠️ Flagged | **-0.10** | 中国上市公司普遍未达标 |
| Risk Management Expertise | 未见风险管理专业背景的董事 | ⚠️ 可能Flagged | **-0.20** | 需确认董事专业背景 |
| Audit Committee Industry Expert | 审计委员会有财务专家但可能缺行业专家 | ⚠️ 可能Flagged | **-0.10** | 取决于MSCI判定标准 |
| Pay Committee Independence | 薪酬委员会含CEO/董事长（非独立成员） | ⚠️ Flagged | **-0.10** | CEO参与自身薪酬决策 |
| Executives on Pay Committee | 有Active CEO参与 | ⚠️ Flagged | **-0.10** | — |

**Board小计**：约 **-1.6至-2.0**【推导估算】

### Corporate Governance — Pay

| Key Metric | 典型中国企业情况 | 是否flagged | 典型扣分 |
|---|---|---|---|
| Executive Pay Disclosure | 中国年报按监管要求披露高管薪酬总额，但**未逐人分项披露固定薪酬/短期激励/长期激励/养老金/福利** | ⚠️ Flagged | **-1.20** |
| Clawbacks & Malus | 未见薪酬追回条款 | ⚠️ Flagged | **-0.20** |
| Director Equity Policy | 未见有效的董事持股指引 | ⚠️ Flagged | **-0.10** |
| Pay Linked to Sustainability | 有"ESG与薪酬挂钩"的声明，但未见实证 | ⚠️ 需关注 | 0至-0.20 |

**Pay小计**：约 **-1.5至-1.7**【推导估算】

> **[示例：薪酬披露是最大单项改善空间]** Executive Pay Disclosure的-1.20是G支柱中单项扣分最大的指标之一。但改善方式相对简单——在ESG报告中逐人分项披露薪酬结构即可，无需改变薪酬体系本身。

### Corporate Governance — Ownership & Control

| Key Metric | 典型中国企业情况 | 是否flagged | 典型扣分 |
|---|---|---|---|
| Controlling Shareholder | 创始人/控股股东持股≥30% | ⚠️ Flagged | **0.00**（flagged但扣分为0，主要通过Board交互效应体现） |
| Annual Director Elections | 每3年换届（非年度选举） | ⚠️ Flagged | **-0.10** |
| Say on Pay Policy | 中国市场无此机制 | ⚠️ Flagged | **-0.10** |

**Ownership & Control小计**：约 **-0.20**

### Corporate Governance — Accounting

| Key Metric | 情况 | 是否flagged | 典型扣分 |
|---|---|---|---|
| Auditor Independence | 非审计费占比低或为零 | ✅ 未flagged | **0.00** |
| Auditor Tenure | 合理任期范围内 | ✅ 未flagged | **0.00** |
| Accounting flags | 标准无保留审计意见 | ✅ 未flagged | **0.00** |

**Accounting小计**：**0.00**

> **[示例说明]** Accounting通常是中国企业G支柱中少数不扣分的板块。如果企业Accounting板块出现扣分，需要特别关注。

### Corporate Behavior — Business Ethics

| Key Metric | 情况 | 评估 | 典型扣分 |
|---|---|---|---|
| Responsibility for ethics issues | 审计委员会监督 | ✅ 最佳实践 | 0.00 |
| Policy against bribery and corruption | 有反贿赂反腐败政策 | ✅ 最佳实践 | 0.00 |
| Regular audits of ethical standards | 定期合规审计 | ✅ 最佳实践 | 0.00 |
| Whistleblower protection | 有举报保护机制 | ✅ 最佳实践 | 0.00 |
| Employee training on ethical standards | 全员合规培训 | ✅ 最佳实践 | 0.00 |
| Anti-corruption for suppliers | 供应商廉洁协议 | ✅ 需确认 | 0.00 |
| Anti-money laundering policy | [待确认]是否有专项反洗钱政策 | ⚠️ 可能缺失 | 0至-0.20 |
| **Corruption Risk Exposure** | 大量运营在中国（中等腐败风险地区），部分业务涉及基建/电力（可能为高风险业务类型） | ⚠️ 系统性扣分 | **-1.20**【推导估算】 |

**Business Ethics小计**：约 **-0.5至-1.4**【推导估算】

> **[示例：不可控的结构性扣分]** Corruption Risk Exposure是基于运营国家和业务类型的系统性扣分，企业无法通过改善管理来消除。但Business Ethics的政策实践指标（如反腐败政策、举报机制、合规培训等）可以有效对冲——7项政策实践全部达标时，总扣分可控制在较低水平。

### Corporate Behavior — Tax Transparency

| Key Metric | 情况 | 评估 |
|---|---|---|
| 有效税率 | 享受高新技术企业税收优惠，有效税率低于法定税率 |
| 法定税率 | 25% |
| 税差 | 有差距，但无涉税争议 |
| Tax Transparency Score | **不因高税差扣分**（前提是无税务争议） |

### G支柱汇总【推导估算】

| 主题 | 扣分估算 |
|---|---|
| Board | -1.6 至 -2.0 |
| Pay | -1.5 至 -1.7 |
| Ownership & Control | -0.2 |
| Accounting | 0.0 |
| Business Ethics | -0.5 至 -1.4 |
| Tax Transparency | 0.0 |
| **G Pillar总扣分** | **-3.8 至 -5.3** |
| **G Pillar Score** | **约5.5-6.5** |

> **中国企业G支柱结构性参考**：CEO/Chair合一（-0.40）、独立董事比例不足（-0.20~0.50）、薪酬披露不充分（-1.20）、Corruption Risk Exposure（-1.20）是中国上市企业的系统性失分项，合计约-3.0至-4.0。如果你的G Score估算高于7.0，请重新检查扣分项是否遗漏。

### G支柱行动卡

| 优先级 | 改善动作 | 预期效果 | 实施建议 |
|---|---|---|---|
| 🔴 高 | **增强CEO薪酬披露详细程度**：按固定薪酬/年度奖金/长期激励/福利分项逐人披露 | 减少Executive Pay Disclosure扣分（**最大单项改善空间，最高减1.2分**） | 可在ESG报告薪酬章节增加CEO薪酬分项表格，无需改变薪酬结构本身 |
| 🔴 高 | **ESG与薪酬挂钩的实证强化** | 避免Pay Linked to Sustainability被flagged | 展示"因ESG绩效变动导致薪酬实际调整"的案例或机制 |
| 🟡 中 | **建立薪酬追回（Clawback）条款** | 减少Clawbacks & Malus扣分（-0.2） | 纳入公司治理制度中 |
| 🟡 中 | **设立Lead Independent Director** | 缓解CEO/Chair合一相关扣分（约-0.1至-0.2） | 特别适合有海外上市计划的企业 |
| 🟢 低 | 提升女性董事占比 | 减少Not 30% Female Directors扣分（-0.1），同步改善独立性占比 | 每增加1名女性独立董事可同时改善两项指标 |

---

## 评级达标条件推导【推导估算】

基于Electrical Equipment行业权重：

| Key Issue | 权重 | KI Score估算 | 加权贡献 |
|---|---|---|---|
| Governance | 44% | [A-B] | [加权值] |
| Labor Management | 24% | [A-B] | [加权值] |
| Clean Tech | 19% | [A-B] | [加权值] |
| Toxic Emissions | 13% | [A-B] | [加权值] |
| **WAKIS** | **100%** | — | **[X-Y]** |

**IAS转换**：IAS = 10 × (WAKIS - industry_min) / (industry_max - industry_min)

Industry Min和Max为MSCI内部参数，[不可外部估算]。WAKIS的绝对值不直接决定评级档位——最终评级取决于公司在行业中的相对位置。

**[示例说明]**：实际诊断时，应结合具体企业的业务特征做定性判断——例如，Pure Play清洁能源企业在Electrical Equipment行业中的Clean Tech Performance通常领先，但传统电气设备制造商可能在Toxic Emissions管理上更成熟。

---

## 评级韧性分析

### 当前主要评级支撑因素

[示例结构——实际诊断时根据具体企业特征填写]

1. **业务定位优势**：如核心业务与行业关键机遇类议题高度相关，Performance Score可获得天然优势
2. **管理体系完善度**：如多数Practices指标达到TOP，整体Management Score有较好基础
3. **合规体系健全**：如Business Ethics政策实践全面，可有效对冲G支柱结构性扣分
4. **Accounting零扣分**：审计独立性良好是基础保障

### 当前主要风险因素

1. **G支柱结构性约束**：中国企业G支柱系统性失分约3-4分，难以通过管理改善完全消除
2. **Practices与Performance的错位**：业务定位优势不等于管理体系优势——Strategy和Targets分开评分
3. **"形式性失分"**：如Non-compensation benefits、薪酬分项披露等，企业实际有做但报告形式不符MSCI期望

### 潜在争议事件影响预判

| 争议类型 | 影响评估 | 监控建议 |
|---|---|---|
| 供应链劳工标准 | 如被评为Very Severe且判定为Direct+Ongoing，扣分可达3.6分，直接威胁评级 | 加强供应商人权审核，扩大ESG现场审核覆盖率 |
| 产品安全事故 | 可触发Product Safety争议 | 持续强化相关安全认证 |
| 环境违规（新兴市场） | 全球化扩张中的合规风险 | 确保海外运营ISO 14001覆盖 |

---

## Data Feedback策略建议

[仅对已有MSCI评级记录的企业输出]

以下是常见的"公司实际已做、但MSCI可能未收录"情况：

| 指标 | 常见情况 | 建议反馈方式 |
|---|---|---|
| Track record of achieving targets | 企业已完成先前减排/节能目标但MSCI未更新 | 提供ESG报告中目标进展表的精确引用 |
| Non-compensation benefits | 福利制度完善但报告未结构化呈现 | 先在公开报告中增加结构化清单，再通过Data Feedback提交 |
| ESG与薪酬挂钩 | 有挂钩机制但缺乏实证案例 | 提供具体ESG考核指标、权重和实际奖惩案例 |
| Clean Tech Targets | 研发投入连续增长但未明确设定未来目标 | 先在报告中设定明确的前瞻性目标，再反馈 |

> **[示例提醒]** Data Feedback的前提是"公开报告中已有信息但MSCI未收录"。如果报告中确实缺失某项信息，应先改善披露，再做Data Feedback——顺序不能反。

---

## 附录：CS议题简评

### Human Capital Development（公司特定CS议题）

| 维度 | 评估要点 |
|---|---|
| 培训覆盖率 | 查看是否覆盖全员、人均培训时数 |
| 培训投入 | 有无量化数据 |
| 学位/证书支持 | 覆盖范围和投入金额 |
| 最佳雇主认可 | 近3年内的外部认可 |
| **评估方法** | 综合以上维度，参照indicator-scoring-levels.md进行评估 |

### Health & Safety（公司特定CS议题）

| 维度 | 评估要点 |
|---|---|
| ISO 45001覆盖率 | 是否达100%。未达100%是常见扣分点 |
| LTIFR | 百万工时损失事件率，关注趋势 |
| 安全投入 | 有无量化数据 |
| 死亡事故 | 任何死亡事故都是重大扣分 |
| **评估方法** | ISO 45001覆盖率是硬性指标，LTIFR需与行业均值对比 |

### Biodiversity & Land Use（公司特定CS议题）

| 维度 | 评估要点 |
|---|---|
| 政策制度 | 是否有生物多样性专项政策 |
| 合作项目 | 与保护组织的合作 |
| 运营点风险 | 是否有运营点位于生态敏感区域 |
| **评估方法** | 该议题对制造业企业通常影响较小，但如有运营点在保护区内则需重点关注 |

---

*本样例基于MSCI ESG Ratings Model v5.0方法论框架编写，使用虚构数据演示诊断方法和表达规范。实际诊断时，所有评估须基于用户提供的真实报告内容，所有得分标注【推导估算】，标注为[不可外部估算]的维度依赖MSCI内部数据，AI不应尝试给出具体数值。*
