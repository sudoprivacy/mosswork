---
name: skillhub-skill-happier-yun
description: "Builds a zero-login 3D Chinese courtyard H5 where strangers sit in silence together. Invoke for immersive oriental web experiences, Three.js cinematic pages, or Tencent CloudBase H5 deploys."
---

# 云栖 Yunqi · 沉浸式东方庭院

一个「不必说话，也算来过」的 3D 东方庭院。用户匿名进入，与陌生人安静共处，
只靠六种无声动作（煮茶 / 焚香 / 抚琴 / 听雨 / 观鱼 / 摇扇）互相陪伴。

**它不是社交产品，是「在场感」产品。** 零注册、零聊天、零 UGC、零个人信息。

## 何时使用

- 用户要做「东方美学 / 治愈 / 孤独经济 / 陪伴感」的 H5 或落地页；
- 用户要一个 Three.js 程序化生成、不依赖外部 3D 模型的沉浸式场景；
- 用户要把一个前端 + WebSocket 的小型沉浸空间部署到腾讯云云托管 / 微信云托管；
- 用户明确提到「云栖」「赛博寺庙的中国版本」「一个人也能待着的数字空间」。

## 交付物

| 产物 | 说明 |
| --- | --- |
| 可运行工程 | `assets/template/`，Vite + Three.js 前端 + Express/ws 后端，所有素材程序生成 |
| 部署包 | 容器化后可直接上传腾讯云云托管，自动获得 HTTPS 域名 + wss |
| PRD | `references/yunqi-prd.html`，7 章完整产品需求文档 |
| 形象设计规范 | `references/yunqi-design.html`，角色三视图 / 六态动作卡 / 八色汉服池 / 名字池 |
| 项目架构 | `references/yunqi-architecture.html`，技术选型 / 模块职责 / 数据流 / 部署路线图 |
| 竞品拆解 | `references/sansatemple-deep-dive.html`，韩国 Sansatemple 底层框架全角度复盘 |

## 快速开始

```bash
# 1. 复制模板到目标目录
bash scripts/scaffold.sh /path/to/my-courtyard

# 2. 安装依赖并构建前端
cd /path/to/my-courtyard
npm install
npm run build:frontend

# 3. 启动后端（同时托管 dist）
npm start
# 打开 http://localhost:3000

# 4. 一键自检（构建 + 健康检查 + WS 握手）
bash scripts/verify.sh /path/to/my-courtyard
```

> 前端独立开发：`cd frontend && npx vite`（默认 5173）。
> 生产环境前端会自动连接同域 `/ws`，无需配置域名。

## 工程结构

```
frontend/
  index.html          # 加载页 / 五幕字幕 / HUD / 动作栏 / 光爆层
  src/
    main.js           # 编排：相机、入庭、动作、多人、动画循环
    scene.js          # 庭院：青石板、池塘、亭台、竹林、月洞门
    atmosphere.js     # 星空、月亮、远山、流萤、花瓣、天灯、涟漪
    avatar.js         # 程序化汉服人物 + 六态动作 + 指数补间
    audio.js          # Web Audio 实时合成声景（无音频文件）
    cinematic.js      # 电影演出：五幕字幕、黑边、诗句、千灯
    lighting.js       # 月光 + 灯笼点光 + 环境光
    presence.js       # WebSocket 多人同在
    design-tokens.js  # 色板、名字池、动作枚举
backend/
  src/server.js       # Express 静态托管 + /ws + /health
  src/room.js         # 内存房间，50 人软上限，空房回收
```

## 核心技术要点

1. **零素材**：所有几何用 `LatheGeometry / CapsuleGeometry / TorusGeometry / ShapeGeometry`
   程序生成；所有声音用 Web Audio 振荡器 + 噪声 + 卷积混响实时合成。无模型、无音频、无字体外链。
2. **帧率无关补间**：`pose[k] += (target[k] - pose[k]) * (1 - Math.exp(-delta * 8))`，
   低端机和高刷屏动作速度一致。
3. **同域 WebSocket**：生产构建自动拼 `wss://<host>/ws`，HTTPS 下不会混合内容报错。
4. **情绪峰值**：第 52 秒触发「千灯」——全屏暖光射线 + 52 盏天灯升空 + 镜头轻震 + 诗句。
5. **降级策略**：没有后端时自动生成 3–5 个「幽灵邻居」，保证单人打开也不空场。

## 定制指引

- **换房间名**：`main.js` 中 `this.roomName`，同时改 `index.html` 的 `#room-name`。
- **换开场文案**：`cinematic.js` 的 `playIntro()` 五幕与 `_startTimeline()` 时间轴。
- **换色板**：`design-tokens.js` 的 `COLOR` / `AVATAR_COLORS`，CSS 变量在 `index.html` 的 `:root`。
- **加动作**：`avatar.js` 的 `POSES` 增加一组关节角，再在 `index.html` 动作栏加按钮、
  `main.js` 快捷键映射里加一行。
- **换场景**：`scene.js` 返回 `{ courtyard, fishes, lanternLights, pond }`，
  `main.js` 只依赖这四个字段。

## 部署

```bash
# 在工程根目录
npm run build:frontend
# 将 frontend/dist 作为静态目录，node 后端监听 80 端口，容器化后上传云托管
```

完整步骤见 `references/deploy-tencent.md`。

## 合规红线（务必保留）

- 无登录、无注册、不采集手机号 / 微信身份 / 位置；
- 无公开聊天、无 UGC、无打赏支付；
- 无宗教符号、宗教叙事、供奉与功德体系；
- 所有素材程序生成，不引入第三方版权资源。

改动以上任一条，请在交付说明中明确标注风险。
