/**
 * 云栖 · 生成式声景
 * 不加载任何音频文件：风声、水声、低频铺底、五声音阶古琴、动作音效全部实时合成。
 * 必须在用户手势（点击"入庭"）后启动，符合浏览器自动播放策略。
 */

const PENTATONIC = [196.0, 220.0, 261.63, 293.66, 329.63, 392.0, 440.0, 523.25];

export class Soundscape {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.enabled = false;
    this._pluckTimer = null;
    this._dripTimer = null;
  }

  async start() {
    if (this.ctx) {
      await this.ctx.resume();
      this.setEnabled(true);
      return;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;

    const ctx = new AC();
    this.ctx = ctx;

    this.master = ctx.createGain();
    this.master.gain.value = 0.0001;
    this.master.connect(ctx.destination);

    const noise = this._noiseBuffer(3);

    // ---- 风：低通噪声 + 缓慢起伏 ----
    const wind = ctx.createBufferSource();
    wind.buffer = noise;
    wind.loop = true;
    const windFilter = ctx.createBiquadFilter();
    windFilter.type = 'lowpass';
    windFilter.frequency.value = 420;
    windFilter.Q.value = 0.6;
    const windGain = ctx.createGain();
    windGain.gain.value = 0.06;
    wind.connect(windFilter).connect(windGain).connect(this.master);
    wind.start();

    // 风的呼吸
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.07;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 180;
    lfo.connect(lfoGain).connect(windFilter.frequency);
    lfo.start();

    // ---- 水：带通噪声 ----
    const water = ctx.createBufferSource();
    water.buffer = noise;
    water.loop = true;
    const waterFilter = ctx.createBiquadFilter();
    waterFilter.type = 'bandpass';
    waterFilter.frequency.value = 1300;
    waterFilter.Q.value = 0.9;
    const waterGain = ctx.createGain();
    waterGain.gain.value = 0.022;
    water.connect(waterFilter).connect(waterGain).connect(this.master);
    water.start();

    // ---- 低频铺底 ----
    [55, 82.5, 110].forEach((f, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = f;
      const g = ctx.createGain();
      g.gain.value = i === 0 ? 0.028 : 0.012;
      osc.connect(g).connect(this.master);
      osc.start();
    });

    // ---- 混响（生成脉冲响应）----
    this.reverb = ctx.createConvolver();
    this.reverb.buffer = this._impulse(2.6, 2.2);
    this.reverbGain = ctx.createGain();
    this.reverbGain.gain.value = 0.32;
    this.reverb.connect(this.reverbGain).connect(this.master);

    this.setEnabled(true);
    this._schedulePluck();
    this._scheduleDrip();
  }

  _noiseBuffer(seconds) {
    const ctx = this.ctx;
    const len = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02; // 轻微粉红化
      data[i] = last * 3.2;
    }
    return buf;
  }

  _impulse(seconds, decay) {
    const ctx = this.ctx;
    const len = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const data = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
      }
    }
    return buf;
  }

  setEnabled(on) {
    this.enabled = on;
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(t);
    this.master.gain.setValueAtTime(Math.max(0.0001, this.master.gain.value), t);
    this.master.gain.exponentialRampToValueAtTime(on ? 0.75 : 0.0001, t + 1.2);
  }

  toggle() {
    if (!this.ctx) {
      this.start();
      return true;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    this.setEnabled(!this.enabled);
    return this.enabled;
  }

  // ---- 古琴单音（三角波 + 慢衰减 + 混响）----
  pluck(freq = PENTATONIC[0], gain = 0.14) {
    if (!this.ctx || !this.enabled) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, t);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.998, t + 1.8);

    const body = ctx.createGain();
    body.gain.setValueAtTime(0.0001, t);
    body.gain.exponentialRampToValueAtTime(gain, t + 0.008);
    body.gain.exponentialRampToValueAtTime(0.0001, t + 2.6);

    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(2800, t);
    lp.frequency.exponentialRampToValueAtTime(900, t + 2.2);

    osc.connect(body).connect(lp);
    lp.connect(this.master);
    lp.connect(this.reverb);

    osc.start(t);
    osc.stop(t + 2.7);
  }

  bell(freq = 392) {
    if (!this.ctx || !this.enabled) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    [freq, freq * 1.5, freq * 2.02].forEach((f, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = f;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.075 / (i + 1), t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 3.4);
      osc.connect(g);
      g.connect(this.master);
      g.connect(this.reverb);
      osc.start(t);
      osc.stop(t + 3.5);
    });
  }

  droplet() {
    if (!this.ctx || !this.enabled) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, t);
    osc.frequency.exponentialRampToValueAtTime(320, t + 0.16);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.05, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
    osc.connect(g);
    g.connect(this.master);
    g.connect(this.reverb);
    osc.start(t);
    osc.stop(t + 0.4);
  }

  whoosh() {
    if (!this.ctx || !this.enabled) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this._noiseBuffer(1);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(500, t);
    bp.frequency.exponentialRampToValueAtTime(2200, t + 0.35);
    bp.Q.value = 1.2;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.05, t + 0.12);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
    src.connect(bp).connect(g);
    g.connect(this.master);
    src.start(t);
  }

  playAction(action) {
    if (!this.enabled) return;
    switch (action) {
      case 'tea': this.pluck(392, 0.12); this.droplet(); break;
      case 'incense': this.bell(440); break;
      case 'qin': this.pluck(PENTATONIC[Math.floor(Math.random() * PENTATONIC.length)], 0.15); break;
      case 'rain': this.whoosh(); break;
      case 'fish': this.droplet(); break;
      case 'fan': this.whoosh(); break;
      default: break;
    }
  }

  /** 远处一声猫叫（极弱 + 长混响，像从巷口飘进来） */
  cat() {
    if (!this.ctx || !this.enabled) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    [0, 0.9].forEach((dt) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(280, t + dt);
      osc.frequency.exponentialRampToValueAtTime(420, t + dt + 0.25);
      osc.frequency.exponentialRampToValueAtTime(260, t + dt + 0.6);

      const saw = ctx.createOscillator();
      saw.type = 'sawtooth';
      saw.frequency.setValueAtTime(270, t + dt);
      saw.frequency.exponentialRampToValueAtTime(410, t + dt + 0.25);
      saw.frequency.exponentialRampToValueAtTime(250, t + dt + 0.6);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t + dt);
      g.gain.exponentialRampToValueAtTime(0.006, t + dt + 0.08);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dt + 0.85);

      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 900;

      osc.connect(lp);
      saw.connect(lp);
      lp.connect(g);
      g.connect(this.reverb);
      g.connect(this.master);

      osc.start(t + dt); saw.start(t + dt);
      osc.stop(t + dt + 0.95); saw.stop(t + dt + 0.95);
    });
  }

  _schedulePluck() {
    clearTimeout(this._pluckTimer);
    this._pluckTimer = setTimeout(() => {
      if (this.enabled) this.pluck(PENTATONIC[Math.floor(Math.random() * PENTATONIC.length)], 0.1);
      this._schedulePluck();
    }, 7000 + Math.random() * 9000);
  }

  _scheduleDrip() {
    clearTimeout(this._dripTimer);
    this._dripTimer = setTimeout(() => {
      if (this.enabled && Math.random() < 0.6) this.droplet();
      this._scheduleDrip();
    }, 5000 + Math.random() * 7000);
  }
}
