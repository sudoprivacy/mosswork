/**
 * 云栖 · 设计 Token（唯一色彩 / 尺寸 / 命名来源）
 * 前端所有模块从这里取值，避免颜色与尺寸散落在各处。
 */

// ============ 色彩 ============
export const COLOR = {
  // 夜景庭院
  night: 0x1a1f1d,
  nightHex: '#1a1f1d',
  ground: 0x3a403c,
  stone: 0x4a4540,

  // 品牌三色
  gold: 0xc9a96e,      // 金：灯、字、宝顶
  bamboo: 0x5a8a6a,    // 竹绿：主强调
  ochre: 0xa0674a,     // 赭石：次强调、印章

  // 人物
  skin: 0xefd8bc,
  skinShade: 0xe3c6a4,
  hair: 0x17181a,
  ink: 0x1a1a1a,
  cream: 0xf2ebdc,     // 交领 / 袖口 / 内衬
  jade: 0x7fa88f,      // 玉佩
};

// 汉服色池：低饱和、偏矿物颜料，避免荧光色
export const AVATAR_COLORS = [
  0x5a8a6a, // 竹青
  0x8a6d5a, // 褐
  0x6a7a8a, // 黛蓝
  0xa0674a, // 赭石
  0x7a6a8a, // 藕紫
  0x5a7a8a, // 靛青
  0x8a7a5a, // 秋香
  0x6a5a8a, // 暮山紫
];

// 每个汉服色对应的深色滚边（自动派生）
export function shadeOf(color, k = 0.72) {
  const c = color instanceof Object && color.getHex ? color.getHex() : color;
  const r = ((c >> 16) & 255) * k;
  const g = ((c >> 8) & 255) * k;
  const b = (c & 255) * k;
  return (Math.round(r) << 16) | (Math.round(g) << 8) | Math.round(b);
}

// ============ 尺寸（世界单位，1 ≈ 1 米） ============
export const AVATAR = {
  height: 1.72,        // 角色总高
  headRadius: 0.155,   // 头部半径
  shoulderY: 1.02,     // 肩关节高度
  shoulderX: 0.27,     // 肩关节左右偏移
  waistY: 0.62,        // 腰带高度
  hemRadius: 0.46,     // 裙摆半径
  walkSpeed: 0.06,     // 每秒移动（沿用旧值，便于手感一致）
  turnLerp: 0.18,      // 转身平滑系数
};

// ============ 名字系统（可控词库，零 UGC） ============
export const NAME_PREFIX = [
  '听竹', '听雨', '观鱼', '赏月', '寻梅', '踏雪',
  '抚琴', '煮茶', '焚香', '摇扇', '问松', '望云',
];

export const NAME_SUFFIX = [
  '客', '人', '居士', '生', '友', '者', '山人', '子',
];

export function randomName() {
  const p = NAME_PREFIX[Math.floor(Math.random() * NAME_PREFIX.length)];
  const s = NAME_SUFFIX[Math.floor(Math.random() * NAME_SUFFIX.length)];
  return p + s;
}

// ============ 动作枚举（前后端共用语义） ============
export const ACTIONS = ['tea', 'incense', 'qin', 'rain', 'fish', 'fan'];

export const ACTION_LABELS = {
  tea: '煮茶',
  incense: '焚香',
  qin: '抚琴',
  rain: '听雨',
  fish: '观鱼',
  fan: '摇扇',
};
