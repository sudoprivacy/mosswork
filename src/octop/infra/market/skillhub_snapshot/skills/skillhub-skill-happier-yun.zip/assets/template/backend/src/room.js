// 房间管理 — 每个房间一个 Room 实例，内存存储所有连接
class Room {
  constructor(roomId) {
    this.roomId = roomId;
    this.clients = new Map();   // peerId → { ws, name, joinedAt }
    this.limit = 50;            // 每房间软上限
  }

  join(peerId, name, ws) {
    if (this.clients.size >= this.limit) return false;
    this.clients.set(peerId, { ws, name, joinedAt: Date.now() });

    // 告诉新人当前房间有谁
    const existing = Array.from(this.clients.entries())
      .filter(([id]) => id !== peerId)
      .map(([id, c]) => ({ peerId: id, name: c.name }));
    ws.send(JSON.stringify({ type: 'init', peers: existing }));

    // 广播有人加入
    this.broadcast({ type: 'join', peerId, name }, peerId);
    return true;
  }

  // 广播给房间内所有人（可排除自己）
  broadcast(msg, excludeId = null) {
    const data = JSON.stringify(msg);
    for (const [id, c] of this.clients) {
      if (id !== excludeId && c.ws.readyState === 1) {
        try { c.ws.send(data); } catch (e) {}
      }
    }
  }

  leave(peerId) {
    this.clients.delete(peerId);
    this.broadcast({ type: 'leave', peerId });
  }

  get size() {
    return this.clients.size;
  }
}

module.exports = Room;
