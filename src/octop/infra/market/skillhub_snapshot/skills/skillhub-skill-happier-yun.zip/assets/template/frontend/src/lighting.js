import * as THREE from 'three';

/**
 * 云栖光照 — 东方庭院夜景氛围
 * 以月光（冷蓝）+ 灯笼暖光 + 环境光为主，营造静谧感
 */
export function setupLighting(scene) {
  // 环境光（很暗，夜的基调）
  const ambient = new THREE.AmbientLight(0x3a4050, 0.5);
  scene.add(ambient);

  // 月光（冷色调方向光）
  const moon = new THREE.DirectionalLight(0x9fb4d4, 0.7);
  moon.position.set(-15, 25, -10);
  moon.castShadow = true;
  moon.shadow.mapSize.set(1024, 1024);
  moon.shadow.camera.left = -20;
  moon.shadow.camera.right = 20;
  moon.shadow.camera.top = 20;
  moon.shadow.camera.bottom = -20;
  moon.shadow.camera.near = 0.5;
  moon.shadow.camera.far = 60;
  scene.add(moon);

  // 亭内暖光（品茗阁的主光源）
  const pavilionGlow = new THREE.PointLight(0xffd4a0, 1.2, 12);
  pavilionGlow.position.set(0, 2.5, -6);
  scene.add(pavilionGlow);

  // 池塘反光（微弱冷光）
  const pondReflect = new THREE.PointLight(0x5a8aaa, 0.4, 8);
  pondReflect.position.set(0, 0.5, 4);
  scene.add(pondReflect);

  // 半球光（模拟天空漫反射）
  const hemi = new THREE.HemisphereLight(0x8fa8c8, 0x3a3020, 0.3);
  scene.add(hemi);
}
