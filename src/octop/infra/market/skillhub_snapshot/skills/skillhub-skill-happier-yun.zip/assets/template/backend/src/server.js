const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const Room = require('./room');
const path = require('path');

const PORT = process.env.PORT || 3000;

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

// 房间存储（内存）
const rooms = new Map();   // roomId → Room

function getRoom(roomId) {
  let room = rooms.get(roomId);
  if (!room) {
    room = new Room(roomId);
    rooms.set(roomId, room);
  }
  return room;
}

// WebSocket 连接处理
wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const roomId = url.searchParams.get('room') || 'default';
  const peerId = url.searchParams.get('peerId') || Math.random().toString(36).slice(2, 10);
  const name = decodeURIComponent(url.searchParams.get('name') || '无名客');

  const room = getRoom(roomId);
  const ok = room.join(peerId, name, ws);

  if (!ok) {
    ws.send(JSON.stringify({ type: 'error', message: '房间已满' }));
    ws.close();
    return;
  }

  console.log(`[云栖] ${name} 进入「${roomId}」(在线 ${room.size})`);

  // 心跳
  const heartbeat = setInterval(() => {
    if (ws.readyState === 1) ws.ping();
  }, 30000);

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());
      // 只允许 state / action 两种消息
      if (msg.type === 'state' || msg.type === 'action') {
        room.broadcast({ ...msg, peerId }, peerId);
      }
    } catch (e) {
      // 忽略坏消息
    }
  });

  ws.on('close', () => {
    clearInterval(heartbeat);
    room.leave(peerId);
    console.log(`[云栖] ${name} 离开「${roomId}」(在线 ${room.size})`);
    // 房间空了就清理
    if (room.size === 0) {
      rooms.delete(roomId);
    }
  });

  ws.on('error', () => {
    clearInterval(heartbeat);
    room.leave(peerId);
  });
});

// HTTP API
app.get('/api/rooms', (req, res) => {
  const list = Array.from(rooms.entries()).map(([id, room]) => ({
    roomId: id,
    online: room.size,
  }));
  res.json({ rooms: list, total: list.length });
});

app.get('/health', (req, res) => {
  res.json({ ok: true, time: Date.now(), rooms: rooms.size });
});

// 静态文件：默认读取本地构建产物，云托管可通过 PUBLIC_DIR 指定
const PUBLIC_DIR = process.env.PUBLIC_DIR || path.join(__dirname, '../../frontend/dist');
app.use(express.static(PUBLIC_DIR, {
  maxAge: '7d',
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
  },
}));

server.listen(PORT, () => {
  console.log(`\n  云栖 Yunqi 服务已启动`);
  console.log(`  HTTP:  http://localhost:${PORT}`);
  console.log(`  WS:    ws://localhost:${PORT}/ws?room=品茗阁&peerId=xxx&name=xxx`);
  console.log(`  健康:  http://localhost:${PORT}/health\n`);
});
