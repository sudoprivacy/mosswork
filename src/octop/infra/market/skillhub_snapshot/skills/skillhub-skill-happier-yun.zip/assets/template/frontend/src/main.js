import * as THREE from 'three';
import { createAvatar, setAvatarAction, updateAvatar, setAvatarLookAt } from './avatar.js';
import { buildCourtyard } from './scene.js';
import { setupLighting } from './lighting.js';
import { RoomPresence } from './presence.js';
import { buildAtmosphere } from './atmosphere.js';
import { Soundscape } from './audio.js';
import { Director } from './cinematic.js';
import { AVATAR, AVATAR_COLORS, randomName } from './design-tokens.js';


class YunqiApp {
  constructor() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x1a1f1d);
    this.scene.fog = new THREE.Fog(0x1a1f1d, 18, 55);

    this.camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 220);
    this.camera.position.set(0, 16, 30);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    document.getElementById('app').appendChild(this.renderer.domElement);

    // 状态
    this.avatars = new Map();   // peerId → { mesh, name }
    this.myPeerId = 'u_' + Math.random().toString(36).slice(2, 9);
    this.myName = randomName();
    this.myColor = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];
    this.roomName = '品茗阁';
    this.keys = {};
    this.mouse = { x: 0, y: 0 };
    this.isDragging = false;
    this.clock = new THREE.Clock();
    this.audioOn = false;
    this.fishes = [];
    this.entered = false;
    this.shake = 0;

    document.getElementById('my-name').textContent = this.myName;
    document.getElementById('room-name').textContent = this.roomName;

    this.init();
  }

  init() {
    setupLighting(this.scene);
    const built = buildCourtyard(this.scene);
    this.fishes = built.fishes;

    // 氛围层：星空 / 月亮 / 远山 / 天灯 / 流萤 / 花瓣 / 雾
    this.atmosphere = buildAtmosphere(this.scene);

    // 我的 Avatar
    this.me = createAvatar(this.myColor);
    this.me.position.set(0, 0, 6);
    this.scene.add(this.me);

    // 远程 Avatar 容器
    this.remoteContainer = new THREE.Group();
    this.scene.add(this.remoteContainer);

    // 声景与电影演出
    this.sound = new Soundscape();
    this.director = new Director({
      onLanterns: () => {
        this.atmosphere.triggerThousandLanterns();
        this.shake = 0.9;
      },
      onBloom: () => {
        this.shake = 0.5;
      },
    });

    // 连接多人
    this.connectPresence();

    // 控制
    this.setupControls();
    this.setupActionButtons();
    this.setupAudioToggle();
    this.setupEntry();
    window.addEventListener('resize', () => this.onResize());

    // 启动循环
    requestAnimationFrame(() => this.animate());

    // 资源就绪，点亮"入庭"
    setTimeout(() => this.director.ready(), 600);

    // 6 秒未点击则自动入庭（无音频）
    setTimeout(() => {
      if (!this.entered) this.enterExperience(false);
    }, 6500);
  }

  setupEntry() {
    const btn = document.getElementById('enter-btn');
    if (btn) {
      btn.addEventListener('click', () => this.enterExperience(true));
    }
    // 入庭 15 秒后轻轻说一句话，让用户感到被在意
    setTimeout(() => {
      if (this.entered && this.director) {
        this.director.showLine('已经 15 秒了。没事的。不用急着走。', 'YOUR TIME IS YOURS', 6000);
      }
    }, 15000);
    // 每 90 秒进一次"夜更深"的氛围，12 秒后回来
    setInterval(() => {
      if (!this.entered) return;
      this.atmosphere.setDeepNight(1);
      this.director.flash('夜');
      this.sound && this.sound.cat && this.sound.cat();  // 远处一声猫叫
      setTimeout(() => this.atmosphere.setDeepNight(0), 12000);
    }, 90000);
  }

  enterExperience(withSound = true) {
    if (this.entered) return;
    this.entered = true;
    document.body.classList.add('entered');
    this.director.playIntro();
    this.director.showSkip();
    if (withSound) {
      this.sound.start()
        .then(() => {
          this.setAudioUI(true);
          // 入庭第一声：远处钟声，把城市的噪音按下去
          this.sound.bell(196.0);
          setTimeout(() => this.sound.bell(146.83), 900);
        })
        .catch(() => {});
    }
    // 入庭的一圈墨色涟漪
    this.atmosphere.triggerRipple(this.me.position.x, this.me.position.z, this.myColor);
  }

  setAudioUI(on) {
    this.audioOn = on;
    const btn = document.getElementById('audio-toggle');
    if (!btn) return;
    btn.classList.toggle('on', on);
    btn.textContent = on ? '声' : '静';
    btn.title = on ? '声景已开启' : '声景已静音';
  }

  connectPresence() {
    // 优先读环境变量；生产构建默认走同域 WebSocket
    const envUrl = import.meta.env.VITE_WS_URL;
    const workerUrl = envUrl || (import.meta.env.PROD
      ? `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}`
      : null);

    if (workerUrl) {
      const wsUrl = `${workerUrl}/ws?room=${encodeURIComponent(this.roomName)}&peerId=${this.myPeerId}&name=${encodeURIComponent(this.myName)}`;
      this.presence = new RoomPresence(wsUrl, {
        onInit: (peers) => peers.forEach(p => this.addRemoteAvatar(p.peerId, p.name)),
        onJoin: (p) => this.addRemoteAvatar(p.peerId, p.name),
        onLeave: (p) => this.removeRemoteAvatar(p.peerId),
        onUpdate: (p) => this.updateRemoteAvatar(p),
        onError: () => this.startSimulatedPeers(),
      });
    } else {
      // 无后端时：模拟 3-5 个幽灵用户
      this.startSimulatedPeers();
    }
    this.updatePeerCount();
  }

  startSimulatedPeers() {
    const names = ['听雨人', '煮茶客', '抚琴生', '观鱼者', '寻梅友'];
    const count = 3 + Math.floor(Math.random() * 3);
    for (let i = 0; i < count; i++) {
      const peerId = 'ghost_' + i;
      const color = AVATAR_COLORS[(i + 1) % AVATAR_COLORS.length];
      this.addRemoteAvatar(peerId, names[i % names.length], color);
      // 随机位置
      const angle = (Math.PI * 2 / count) * i + Math.random() * 0.4;
      const r = 3 + Math.random() * 3;
      this.avatars.get(peerId).mesh.position.set(
        Math.sin(angle) * r, 0, Math.cos(angle) * r + 2
      );
    }
    this.updatePeerCount();

    // 幽灵随机走动
    setInterval(() => {
      this.avatars.forEach((entry, peerId) => {
        if (peerId.startsWith('ghost_')) {
          const m = entry.mesh;
          m.position.x += (Math.random() - 0.5) * 0.08;
          m.position.z += (Math.random() - 0.5) * 0.08;
          m.position.x = Math.max(-10, Math.min(10, m.position.x));
          m.position.z = Math.max(-4, Math.min(10, m.position.z));
        }
      });
    }, 120);

    // 幽灵偶尔做动作，让庭院"活"起来
    const ghostActions = ['tea', 'incense', 'qin', 'fan'];
    setInterval(() => {
      const ghosts = Array.from(this.avatars.entries()).filter(([id]) => id.startsWith('ghost_'));
      if (!ghosts.length) return;
      const [id, entry] = ghosts[Math.floor(Math.random() * ghosts.length)];
      if (entry.mesh.userData.action) return;
      const act = ghostActions[Math.floor(Math.random() * ghostActions.length)];
      setAvatarAction(entry.mesh, act);
      this.atmosphere.spawnActionTrail(entry.mesh.position.x, entry.mesh.position.z, act);
      // 其他幽灵转头看它
      ghosts.forEach(([__, other]) => {
        if (other.mesh !== entry.mesh) {
          setAvatarLookAt(other.mesh, entry.mesh.position, 1600);
        }
      });
    }, 6000);
  }

  addRemoteAvatar(peerId, name, color) {
    if (this.avatars.has(peerId)) return;
    const c = color || AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];
    const mesh = createAvatar(c);
    mesh.position.set(
      (Math.random() - 0.5) * 10, 0, Math.random() * 8 - 1
    );

    // 名字标签
    const canvas = document.createElement('canvas');
    canvas.width = 256; canvas.height = 72;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = 'rgba(26,31,29,0.7)';
    roundRect(ctx, 0, 0, 256, 72, 8);
    ctx.fill();
    ctx.fillStyle = '#c9a96e';
    ctx.font = 'bold 26px "PingFang SC", serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(name || '无名客', 128, 36);
    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;
    const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false }));
    label.scale.set(2, 0.56, 1);
    label.position.y = 1.85;
    label.renderOrder = 999;
    mesh.add(label);

    this.remoteContainer.add(mesh);
    this.avatars.set(peerId, { mesh, name });
    this.atmosphere.triggerRipple(mesh.position.x, mesh.position.z, c);
    this.updatePeerCount();
  }

  removeRemoteAvatar(peerId) {
    const entry = this.avatars.get(peerId);
    if (entry) {
      this.remoteContainer.remove(entry.mesh);
      this.avatars.delete(peerId);
    }
    this.updatePeerCount();
  }

  updateRemoteAvatar({ peerId, position, action }) {
    const entry = this.avatars.get(peerId);
    if (!entry) return;
    if (position) {
      entry.mesh.position.lerp(new THREE.Vector3(position.x, 0, position.z), 0.25);
    }
    if (action) {
      setAvatarAction(entry.mesh, action);
      // 远程角色做动作时，其他所有人转头看它 + 它自己生成余韵
      this.atmosphere.spawnActionTrail(entry.mesh.position.x, entry.mesh.position.z, action);
      this._allLookAt(entry.mesh.position);
    }
  }

  updatePeerCount() {
    document.getElementById('peer-count').textContent = this.avatars.size + 1;
  }

  setupControls() {
    window.addEventListener('keydown', (e) => {
      this.keys[e.key.toLowerCase()] = true;
      if (e.key === '1') this.triggerAction('tea');
      if (e.key === '2') this.triggerAction('incense');
      if (e.key === '3') this.triggerAction('qin');
      if (e.key === '4') this.triggerAction('rain');
      if (e.key === '5') this.triggerAction('fish');
      if (e.key === '6') this.triggerAction('fan');
      if (e.code === 'Space') { e.preventDefault(); this.triggerAction(null); }
    });
    window.addEventListener('keyup', (e) => { this.keys[e.key.toLowerCase()] = false; });

    // 鼠标视角
    this.renderer.domElement.addEventListener('mousedown', () => { this.isDragging = true; });
    window.addEventListener('mouseup', () => { this.isDragging = false; });
    this.renderer.domElement.addEventListener('mousemove', (e) => {
      if (this.isDragging) {
        this.mouse.x += e.movementX * 0.004;
        this.mouse.y -= e.movementY * 0.004;
        this.mouse.y = Math.max(-0.4, Math.min(0.4, this.mouse.y));
      }
    });
  }

  setupActionButtons() {
    document.querySelectorAll('.action-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.action;
        const isActive = btn.classList.contains('active');
        // 清除其他激活
        document.querySelectorAll('.action-btn').forEach(b => b.classList.remove('active'));
        if (!isActive) btn.classList.add('active');
        this.triggerAction(isActive ? null : action);
      });
    });
  }

  setupAudioToggle() {
    const btn = document.getElementById('audio-toggle');
    btn.addEventListener('click', async () => {
      if (!this.sound.ctx) {
        await this.sound.start();
        this.setAudioUI(true);
      } else {
        this.setAudioUI(this.sound.toggle());
      }
    });
  }

  triggerAction(action) {
    setAvatarAction(this.me, action);
    if (action) {
      this.sound.playAction(action);
      this.atmosphere.triggerRipple(this.me.position.x, this.me.position.z, this.myColor);
      // 动作余韵（茶汽 / 香烟 / 泛音光点 / 纸扇风）
      this.atmosphere.spawnActionTrail(this.me.position.x, this.me.position.z, action);
      // 庭院里所有人，都悄悄转头看你
      this._allLookAt(this.me.position);
    }
    if (this.presence) {
      this.presence.send({ type: 'action', action });
    }
  }

  /** 让所有人（不含自己）的头 1.4 秒内缓慢转向 target */
  _allLookAt(targetPos) {
    // 自己也跟着转：动作那一刻自己也"看一眼"自己做的事
    setAvatarLookAt(this.me, targetPos, 1100);
    this.avatars.forEach((entry) => {
      setAvatarLookAt(entry.mesh, targetPos, 1400);
    });
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    const delta = this.clock.getDelta();
    const time = this.clock.elapsedTime;

    // WASD 移动
    const speed = AVATAR.walkSpeed;
    if (this.keys['w']) this.me.position.z -= speed;
    if (this.keys['s']) this.me.position.z += speed;
    if (this.keys['a']) this.me.position.x -= speed;
    if (this.keys['d']) this.me.position.x += speed;

    // 边界
    this.me.position.x = Math.max(-14, Math.min(14, this.me.position.x));
    this.me.position.z = Math.max(-10, Math.min(12, this.me.position.z));

    // 角色朝向移动方向
    const moving = this.keys['w'] || this.keys['s'] || this.keys['a'] || this.keys['d'];
    if (moving) {
      const targetAngle = Math.atan2(
        (this.keys['a'] ? -1 : 0) + (this.keys['d'] ? 1 : 0),
        (this.keys['w'] ? -1 : 0) + (this.keys['s'] ? 1 : 0)
      );
      if (targetAngle !== 0 || this.keys['w']) {
        this.me.rotation.y = targetAngle;
      }
    }

    // 角色动画（补间 + 呼吸 + 行走摆臂）
    this.me.userData.moving = moving;
    updateAvatar(this.me, delta, time);
    this.avatars.forEach((entry) => updateAvatar(entry.mesh, delta, time));

    // 氛围层（星空 / 天灯 / 流萤 / 花瓣 / 雾 / 涟漪）
    this.atmosphere.update(delta, time);

    // 深夜氛围：每帧柔和过渡背景色与雾密度
    const dn = this.atmosphere.deepNight;
    const bgFrom = new THREE.Color(0x1a1f1d);
    const bgTo = new THREE.Color(0x0b0f14);
    const bgCur = bgFrom.clone().lerp(bgTo, dn);
    this.scene.background.lerp(bgCur, 0.06);
    this.scene.fog.near = THREE.MathUtils.lerp(this.scene.fog.near, 18 - dn * 6, 0.04);
    this.scene.fog.far  = THREE.MathUtils.lerp(this.scene.fog.far, 55 + dn * 10, 0.04);

    // 摄像机（入庭前缓慢推近，入庭后第三人称跟随）
    const camOffset = new THREE.Vector3(Math.sin(this.mouse.x) * 8, 4.5, Math.cos(this.mouse.x) * 8);
    const targetPos = this.me.position.clone().add(camOffset);
    this.camera.position.lerp(targetPos, this.entered ? 0.08 : 0.02);
    if (this.shake > 0.001) {
      this.camera.position.x += (Math.random() - 0.5) * this.shake * 0.35;
      this.camera.position.y += (Math.random() - 0.5) * this.shake * 0.22;
      this.shake *= 0.93;
    }
    this.camera.lookAt(this.me.position.x, this.me.position.y + 1.2, this.me.position.z);

    // 鱼游动
    this.fishes.forEach(f => {
      f.angle += f.speed * delta;
      f.mesh.position.x = Math.cos(f.angle) * f.radius;
      f.mesh.position.z = 4 + Math.sin(f.angle) * f.radius;
      f.mesh.rotation.y = f.angle + Math.PI / 2;
    });

    // 广播位置（~10Hz）
    if (Math.random() < 0.12 && this.presence) {
      this.presence.send({
        type: 'state',
        position: { x: this.me.position.x, z: this.me.position.z },
      });
    }

    this.renderer.render(this.scene, this.camera);
  }

  onResize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }
}

// 圆角矩形辅助函数
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

new YunqiApp();
