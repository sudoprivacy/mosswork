import * as THREE from 'three';

/**
 * 云栖 · 氛围层
 * 星空 / 山影 / 月亮 / 天灯 / 流萤 / 花瓣 / 雾 / 墨色涟漪
 * 纯程序化生成，不加载任何贴图文件。
 */

function radialTexture(inner = 'rgba(255,255,255,1)', outer = 'rgba(255,255,255,0)') {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, inner);
  g.addColorStop(0.45, inner.replace(/[\d.]+\)$/, '0.55)'));
  g.addColorStop(1, outer);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 64, 64);
  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}

function petalTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 32;
  const ctx = c.getContext('2d');
  ctx.fillStyle = 'rgba(255,255,255,1)';
  ctx.beginPath();
  ctx.ellipse(16, 16, 7, 12, Math.PI / 5, 0, Math.PI * 2);
  ctx.fill();
  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}

function ridge(points, color, z, y, opacity) {
  const shape = new THREE.Shape();
  shape.moveTo(-80, -10);
  points.forEach(([x, h]) => shape.lineTo(x, h));
  shape.lineTo(80, -10);
  shape.closePath();
  const mesh = new THREE.Mesh(
    new THREE.ShapeGeometry(shape),
    new THREE.MeshBasicMaterial({
      color, transparent: true, opacity, depthWrite: false, fog: false,
    })
  );
  mesh.position.set(0, y, z);
  return mesh;
}

export function buildAtmosphere(scene) {
  const group = new THREE.Group();
  group.name = 'atmosphere';
  scene.add(group);

  let time = 0;

  const glowTex = radialTexture('rgba(255,230,180,1)', 'rgba(255,180,90,0)');
  const starTex = radialTexture('rgba(230,240,255,1)', 'rgba(180,200,255,0)');

  // ============ 星空 ============
  const starCount = 1100;
  const starPos = new Float32Array(starCount * 3);
  for (let i = 0; i < starCount; i++) {
    const r = 70 + Math.random() * 40;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.46; // 只铺上半球
    starPos[i * 3] = Math.cos(theta) * Math.sin(phi) * r;
    starPos[i * 3 + 1] = Math.cos(phi) * r * 0.75 + 6;
    starPos[i * 3 + 2] = Math.sin(theta) * Math.sin(phi) * r;
  }
  const starGeo = new THREE.BufferGeometry();
  starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({
    color: 0xdbe4f2, size: 0.55, map: starTex, transparent: true, opacity: 0.75,
    depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true, fog: false,
  }));
  group.add(stars);

  // ============ 月亮 ============
  const moon = new THREE.Mesh(
    new THREE.CircleGeometry(5.2, 48),
    new THREE.MeshBasicMaterial({ color: 0xf6e7c4, transparent: true, opacity: 0.95, fog: false })
  );
  moon.position.set(-26, 30, -78);
  group.add(moon);

  const halo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: glowTex, color: 0xffe0a8, transparent: true, opacity: 0.4,
    blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
  }));
  halo.scale.set(42, 42, 1);
  halo.position.copy(moon.position);
  group.add(halo);

  // ============ 远山三重 ============
  group.add(ridge([
    [-80, -2], [-62, 9], [-48, 3], [-32, 14], [-16, 5], [0, 17],
    [16, 7], [32, 13], [48, 4], [62, 10], [80, -2],
  ], 0x1d2926, -92, 6, 0.55));
  group.add(ridge([
    [-80, -4], [-60, 7], [-44, 1], [-28, 11], [-10, 3], [8, 13],
    [26, 5], [44, 10], [62, 2], [80, -4],
  ], 0x17211f, -70, 3, 0.7));
  group.add(ridge([
    [-80, -6], [-58, 4], [-38, 0], [-18, 8], [2, 1], [22, 9],
    [42, 2], [62, 6], [80, -6],
  ], 0x111917, -52, 0, 0.85));

  // ============ 低雾 ============
  const mistTex = radialTexture('rgba(200,220,220,0.55)', 'rgba(160,190,190,0)');
  const mists = [];
  const mistSpecs = [
    { w: 70, h: 16, x: 0, y: 2.2, z: -30, ry: 0, op: 0.16, speed: 0.05 },
    { w: 60, h: 14, x: 8, y: 1.6, z: -22, ry: 0, op: 0.12, speed: -0.04 },
    { w: 50, h: 40, x: 0, y: 0.7, z: 4, ry: -Math.PI / 2, op: 0.1, speed: 0.03 },
  ];
  mistSpecs.forEach((s) => {
    const m = new THREE.Mesh(
      new THREE.PlaneGeometry(s.w, s.h),
      new THREE.MeshBasicMaterial({
        map: mistTex, color: 0xa8c0c0, transparent: true, opacity: s.op,
        depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
      })
    );
    m.position.set(s.x, s.y, s.z);
    m.rotation.x = s.ry;
    m.userData.speed = s.speed;
    m.userData.baseX = s.x;
    m.userData.phase = Math.random() * 10;
    group.add(m);
    mists.push(m);
  });

  // ============ 流萤 ============
  const flyCount = 110;
  const flyPos = new Float32Array(flyCount * 3);
  const flyBase = [];
  for (let i = 0; i < flyCount; i++) {
    const x = (Math.random() - 0.5) * 30;
    const z = -8 + Math.random() * 24;
    const y = 0.5 + Math.random() * 3.2;
    flyBase.push({ x, y, z, p: Math.random() * 10, s: 0.4 + Math.random() * 0.8 });
    flyPos[i * 3] = x;
    flyPos[i * 3 + 1] = y;
    flyPos[i * 3 + 2] = z;
  }
  const flyGeo = new THREE.BufferGeometry();
  flyGeo.setAttribute('position', new THREE.BufferAttribute(flyPos, 3));
  const flies = new THREE.Points(flyGeo, new THREE.PointsMaterial({
    color: 0xffd98a, size: 0.42, map: glowTex, transparent: true, opacity: 0.9,
    depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true, fog: false,
  }));
  group.add(flies);

  // ============ 花瓣 ============
  const petalCount = 90;
  const petalPos = new Float32Array(petalCount * 3);
  const petalBase = [];
  for (let i = 0; i < petalCount; i++) {
    const x = (Math.random() - 0.5) * 34;
    const y = Math.random() * 12;
    const z = -10 + Math.random() * 28;
    petalBase.push({ x, y, z, sp: 0.25 + Math.random() * 0.55, p: Math.random() * 10 });
    petalPos[i * 3] = x;
    petalPos[i * 3 + 1] = y;
    petalPos[i * 3 + 2] = z;
  }
  const petalGeo = new THREE.BufferGeometry();
  petalGeo.setAttribute('position', new THREE.BufferAttribute(petalPos, 3));
  const petals = new THREE.Points(petalGeo, new THREE.PointsMaterial({
    color: 0xe6c4b2, size: 0.18, map: petalTexture(), transparent: true, opacity: 0.65,
    depthWrite: false, sizeAttenuation: true, fog: false,
  }));
  group.add(petals);

  // ============ 天灯 ============
  const lanterns = [];

  function makeLantern() {
    const g = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.CylinderGeometry(0.2, 0.16, 0.32, 8, 1, true),
      new THREE.MeshBasicMaterial({
        color: 0xffb066, transparent: true, opacity: 0.9,
        side: THREE.DoubleSide, fog: false,
      })
    );
    g.add(body);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTex, color: 0xff9a4a, transparent: true, opacity: 0.6,
      blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
    }));
    glow.scale.set(1.8, 1.8, 1);
    g.add(glow);
    const base = new THREE.Mesh(
      new THREE.CylinderGeometry(0.13, 0.13, 0.035, 8),
      new THREE.MeshBasicMaterial({ color: 0x3a2a20, fog: false })
    );
    base.position.y = -0.17;
    g.add(base);
    return g;
  }

  function spawnLantern(x, z, y, speed, expire) {
    const mesh = makeLantern();
    mesh.position.set(x, y, z);
    group.add(mesh);
    const item = {
      mesh, x, z, speed, phase: Math.random() * 10,
      born: time, expire,
    };
    lanterns.push(item);
    return item;
  }

  // 常驻天灯：缓慢升空，循环
  for (let i = 0; i < 14; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = 6 + Math.random() * 14;
    spawnLantern(
      Math.cos(a) * r, -8 + Math.sin(a) * r, 2 + Math.random() * 14,
      0.15 + Math.random() * 0.25, 0
    );
  }

  // ============ 墨色涟漪 ============
  const ripples = [];

  function triggerRipple(x, z, color = 0xc9a96e) {
    const geo = new THREE.RingGeometry(0.18, 0.24, 40);
    const mat = new THREE.MeshBasicMaterial({
      color, transparent: true, opacity: 0.85,
      side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(x, 0.04, z);
    group.add(mesh);
    ripples.push({ mesh, age: 0, life: 1.8 });
  }

  // ============ 动作余韵：茶汽 / 香烟 / 泛音光点 / 纸扇风 ============
  const trails = [];

  function spawnTrail(x, y, z, kind) {
    const confs = {
      steam:     { count: 10, life: 2.5, speed: 0.85, drift: 0.35, color: 0xf0f0e8, size: 0.18, fade: true },
      smoke:     { count: 14, life: 3.6, speed: 0.5,  drift: 0.85, color: 0x4a4540, size: 0.32, fade: true },
      harmonics: { count: 24, life: 2.8, speed: 0.08, drift: 0.5,  color: 0xffd98a, size: 0.16, fade: true, additive: true },
      fans:      { count: 8,  life: 1.2, speed: 1.2,  drift: 0.3,  color: 0xfff0d4, size: 0.24, fade: true, additive: true },
    };
    const c = confs[kind] || confs.steam;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(c.count * 3);
    const ages = new Float32Array(c.count);
    const dirs = new Float32Array(c.count * 3);
    for (let i = 0; i < c.count; i++) {
      pos[i * 3] = x;
      pos[i * 3 + 1] = y;
      pos[i * 3 + 2] = z;
      ages[i] = Math.random() * c.life * 0.5;
      dirs[i * 3]     = (Math.random() - 0.5) * c.drift + (kind === 'steam' ? 0 : (Math.random() - 0.5) * 0.3);
      dirs[i * 3 + 1] = c.speed * (kind === 'fans' ? (Math.random() - 0.5) : 1) + (kind === 'steam' ? 0.15 : 0);
      dirs[i * 3 + 2] = (Math.random() - 0.5) * c.drift;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({
      color: c.color, size: c.size, transparent: true, opacity: 0.85,
      depthWrite: false, sizeAttenuation: true, fog: false,
      blending: c.additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    });
    const points = new THREE.Points(geo, mat);
    group.add(points);
    trails.push({ kind, points, pos, ages, dirs, conf: c, age: 0, life: c.life + 1.2 });
  }

  /** 主入口：根据动作类型在角色头顶生成对应余韵 */
  function spawnActionTrail(x, z, action) {
    const trailY = 1.15;
    switch (action) {
      case 'tea':     spawnTrail(x, trailY + 0.1, z, 'steam');     break;
      case 'incense': spawnTrail(x, trailY + 0.5, z, 'smoke');     break;
      case 'qin':     spawnTrail(x, trailY + 0.05, z, 'harmonics'); break;
      case 'fan':     spawnTrail(x, trailY + 0.25, z, 'fans');     break;
    }
  }

  // ============ 个人点灯（单人版"千灯"） ============
  function spawnPersonalLantern(x, z) {
    // 在头顶生成 1 盏，0.6 秒后升空
    const mesh = makeLantern();
    mesh.position.set(x, 1.2, z);
    group.add(mesh);
    lanterns.push({
      mesh, x, z, speed: 0.22, phase: Math.random() * 10,
      born: time, expire: time + 40,
    });
    triggerRipple(x, z, 0xffcf8a);
  }

  // ============ 深夜深 / 氛围控制 ============
  // main.js animate() 每帧读这个状态来 lerp scene.fog / 灯笼亮度等
  let deepNight = 0;       // 0 = 正常，1 = 夜深
  function setDeepNight(v) { deepNight = Math.max(0, Math.min(1, v)); }

  // ============ 千灯事件 ============
  function triggerThousandLanterns() {
    for (let i = 0; i < 52; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = 3 + Math.random() * 17;
      spawnLantern(
        Math.cos(a) * r,
        -6 + Math.sin(a) * r,
        0.4 + Math.random() * 2.4,
        0.45 + Math.random() * 0.55,
        time + 45
      );
    }
  }

  function update(delta, t) {
    time = t;
    stars.rotation.y = t * 0.004;
    halo.material.opacity = 0.34 + Math.sin(t * 0.5) * 0.05;

    // 流萤
    const fp = flies.geometry.attributes.position.array;
    for (let i = 0; i < flyCount; i++) {
      const b = flyBase[i];
      fp[i * 3] = b.x + Math.sin(t * 0.55 * b.s + b.p) * 1.4;
      fp[i * 3 + 1] = b.y + Math.sin(t * 0.9 * b.s + b.p * 1.7) * 0.5;
      fp[i * 3 + 2] = b.z + Math.cos(t * 0.45 * b.s + b.p) * 1.4;
    }
    flies.geometry.attributes.position.needsUpdate = true;

    // 花瓣
    const pp = petals.geometry.attributes.position.array;
    for (let i = 0; i < petalCount; i++) {
      const b = petalBase[i];
      b.y -= b.sp * delta;
      if (b.y < 0.1) b.y = 11 + Math.random() * 2;
      pp[i * 3] = b.x + Math.sin(t * 0.6 + b.p) * 0.7;
      pp[i * 3 + 1] = b.y;
      pp[i * 3 + 2] = b.z + Math.cos(t * 0.4 + b.p) * 0.5;
    }
    petals.geometry.attributes.position.needsUpdate = true;

    // 雾
    mists.forEach((m) => {
      m.position.x = m.userData.baseX + Math.sin(t * m.userData.speed + m.userData.phase) * 4;
      m.material.opacity += (0.1 + Math.sin(t * 0.2 + m.userData.phase) * 0.03 - m.material.opacity) * 0.02;
    });

    // 天灯
    for (let i = lanterns.length - 1; i >= 0; i--) {
      const L = lanterns[i];
      L.mesh.position.y += L.speed * delta;
      L.mesh.position.x = L.x + Math.sin(t * 0.3 + L.phase) * 0.7;
      L.mesh.position.z = L.z + Math.cos(t * 0.24 + L.phase) * 0.6;

      // 淡入 / 淡出
      const age = t - L.born;
      let scale = Math.min(1, age / 1.6);
      if (L.expire) {
        if (t > L.expire) {
          group.remove(L.mesh);
          lanterns.splice(i, 1);
          continue;
        }
        if (t > L.expire - 4) scale *= Math.max(0, (L.expire - t) / 4);
      }
      L.mesh.scale.setScalar(scale);

      if (L.mesh.position.y > 20) {
        if (L.expire) {
          group.remove(L.mesh);
          lanterns.splice(i, 1);
        } else {
          L.mesh.position.y = 1.2;
          const a = Math.random() * Math.PI * 2;
          const r = 6 + Math.random() * 14;
          L.x = Math.cos(a) * r;
          L.z = -8 + Math.sin(a) * r;
        }
      }
    }

    // 涟漪
    for (let i = ripples.length - 1; i >= 0; i--) {
      const R = ripples[i];
      R.age += delta;
      const k = R.age / R.life;
      R.mesh.scale.setScalar(1 + k * 8);
      R.mesh.material.opacity = Math.max(0, 0.85 * (1 - k));
      if (k >= 1) {
        group.remove(R.mesh);
        R.mesh.geometry.dispose();
        R.mesh.material.dispose();
        ripples.splice(i, 1);
      }
    }

    // 动作余韵：逐粒子更新位置 + 淡出
    for (let i = trails.length - 1; i >= 0; i--) {
      const tr = trails[i];
      tr.age += delta;
      const lifeT = tr.age / tr.life;
      const fade = Math.max(0, 1 - lifeT * 1.2);
      const pos = tr.points.geometry.attributes.position.array;
      for (let j = 0; j < tr.conf.count; j++) {
        tr.ages[j] += delta;
        pos[j * 3]     += tr.dirs[j * 3]     * delta + (Math.random() - 0.5) * 0.02;
        pos[j * 3 + 1] += tr.dirs[j * 3 + 1] * delta;
        pos[j * 3 + 2] += tr.dirs[j * 3 + 2] * delta;
      }
      tr.points.geometry.attributes.position.needsUpdate = true;
      tr.points.material.opacity = 0.85 * fade;
      if (lifeT >= 1) {
        group.remove(tr.points);
        tr.points.geometry.dispose();
        tr.points.material.dispose();
        trails.splice(i, 1);
      }
    }
  }

  return {
    group, update, triggerRipple, triggerThousandLanterns,
    spawnActionTrail, spawnPersonalLantern,
    get deepNight() { return deepNight; }, setDeepNight,
  };
}
