/**
 * 云栖 WebSocket 多人同在客户端
 */
export class RoomPresence {
  constructor(url, callbacks = {}) {
    this.url = url;
    this.ws = null;
    this.callbacks = callbacks;
    this.reconnectDelay = 1000;
    this.maxReconnectDelay = 15000;
    this.connect();
  }

  connect() {
    try {
      this.ws = new WebSocket(this.url);

      this.ws.onopen = () => {
        console.log('[云栖] 已连接到庭院');
        this.reconnectDelay = 1000;
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          this.handleMessage(msg);
        } catch (e) {
          // 忽略坏消息
        }
      };

      this.ws.onclose = () => {
        console.log('[云栖] 连接断开，' + this.reconnectDelay + 'ms 后重连');
        setTimeout(() => this.connect(), this.reconnectDelay);
        this.reconnectDelay = Math.min(this.reconnectDelay * 2, this.maxReconnectDelay);
      };

      this.ws.onerror = () => {
        if (this.callbacks.onError) this.callbacks.onError();
      };
    } catch (e) {
      if (this.callbacks.onError) this.callbacks.onError(e);
    }
  }

  handleMessage(msg) {
    switch (msg.type) {
      case 'init':
        this.callbacks.onInit?.(msg.peers || []);
        break;
      case 'join':
        this.callbacks.onJoin?.(msg);
        break;
      case 'leave':
        this.callbacks.onLeave?.(msg);
        break;
      case 'state':
      case 'action':
        this.callbacks.onUpdate?.({ ...msg });
        break;
    }
  }

  send(data) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    }
  }

  close() {
    this.ws?.close();
  }
}
