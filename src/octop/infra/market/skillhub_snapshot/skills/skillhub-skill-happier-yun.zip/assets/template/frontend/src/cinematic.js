/**
 * 云栖 · 电影感演出
 * 入庭五幕字幕 / 黑边 / 光爆 / 诗句 / 千灯事件提示
 * 仅操作 DOM，不依赖 Three.js。
 */
export class Director {
  constructor({ onLanterns, onBloom } = {}) {
    this.onLanterns = onLanterns || (() => {});
    this.onBloom = onBloom || (() => {});
    this.entered = false;
    this.introDone = false;
    this._timers = new Map();
    this._lineTimer = null;
    this.el = {
      loading: document.getElementById('loading'),
      enterBtn: document.getElementById('enter-btn'),
      intro: document.getElementById('intro'),
      introLine: document.getElementById('intro-line'),
      introSub: document.getElementById('intro-sub'),
      skip: document.getElementById('skip'),
      lbTop: document.getElementById('letterbox-top'),
      lbBottom: document.getElementById('letterbox-bottom'),
      poem: document.getElementById('poem'),
      poemText: document.getElementById('poem-text'),
      poemSub: document.getElementById('poem-sub'),
      flash: document.getElementById('flash'),
      flashText: document.getElementById('flash-text'),
      bloom: document.getElementById('bloom'),
    };

    if (this.el.skip) {
      this.el.skip.addEventListener('click', () => this.finishIntro());
    }
  }

  /** 资源就绪：点亮"入庭"按钮 */
  ready() {
    if (this.el.enterBtn) this.el.enterBtn.classList.add('ready');
    if (this.el.loading) this.el.loading.classList.add('loaded');
  }

  hideLoading() {
    if (!this.el.loading) return;
    this.el.loading.classList.add('fade-out');
    setTimeout(() => {
      if (this.el.loading && this.el.loading.parentNode) this.el.loading.remove();
    }, 900);
  }

  _wait(ms) {
    return new Promise((resolve) => {
      const id = setTimeout(() => {
        this._timers.delete(id);
        resolve();
      }, ms);
      this._timers.set(id, resolve);
    });
  }

  _skipAll() {
    this._timers.forEach((resolve, id) => {
      clearTimeout(id);
      resolve();
    });
    this._timers.clear();
  }

  async _say(text, sub, hold = 2400) {
    if (this.introDone) return;
    this.el.introLine.textContent = text;
    this.el.introSub.textContent = sub;
    this.el.intro.classList.add('show');
    await this._wait(hold);
    if (this.introDone) return;
    this.el.intro.classList.remove('show');
    await this._wait(460);
  }

  async playIntro() {
    if (this.entered) return;
    this.entered = true;
    this.hideLoading();
    this.boom();

    this.el.lbTop.classList.add('on');
    this.el.lbBottom.classList.add('on');

    await this._wait(620);
    await this._say('你已经，很久没有真正安静过了。', 'TOO LONG. WE KNOW.', 2600);
    await this._say('在这里，不用介绍自己。', 'NO NAMES. NO RESUMES.', 2400);
    await this._say('也不用，假装今天很好。', 'NO SMILING REQUIRED.', 2500);
    await this._say('坐下吧。让一盏灯，替你把话说完。', 'LET THE LIGHT SPEAK.', 2700);
    await this._say('今夜，你不必一个人。', 'YOU ARE NOT ALONE.', 3000);

    this.finishIntro();
  }

  finishIntro() {
    if (this.introDone) return;
    this.introDone = true;
    this._skipAll();
    if (this.el.intro) this.el.intro.classList.remove('show');
    if (this.el.lbTop) this.el.lbTop.classList.remove('on');
    if (this.el.lbBottom) this.el.lbBottom.classList.remove('on');
    if (this.el.skip) this.el.skip.classList.remove('show');

    setTimeout(() => {
      this.showLine('今夜，云栖。', 'YOU ARE NOT ALONE', 6600);
      this._startTimeline();
    }, 780);
  }

  _startTimeline() {
    const lines = [
      { at: 22000, text: '风过竹林。像有人，轻轻替你叹了口气。', sub: 'LISTEN' },
      { at: 46000, text: '你看。灯，一盏一盏亮起来了。', sub: 'LOOK UP' },
      { at: 78000, text: '夜还长。你可以，再坐一会儿。', sub: 'STAY A WHILE' },
      { at: 104000, text: '好在这世上的山高水长，总有人和你一样。', sub: 'SOMEONE, SOMEWHERE' },
    ];
    lines.forEach((l) => {
      setTimeout(() => this.showLine(l.text, l.sub, 7600), l.at);
    });

    // 千灯：本场最强烈的一次情绪峰值
    setTimeout(() => {
      this.flash('千 灯');
      this.onLanterns();
      setTimeout(() => this.showLine('看。这一千盏，是为你点的。', 'A THOUSAND LANTERNS', 9000), 900);
    }, 52000);
  }

  showLine(text, sub = '', hold = 6000) {
    if (!this.el.poem) return;
    clearTimeout(this._lineTimer);
    this.el.poemText.textContent = text;
    this.el.poemSub.textContent = sub;
    this.el.poem.classList.add('show');
    this._lineTimer = setTimeout(() => {
      this.el.poem.classList.remove('show');
    }, hold);
  }

  /** 入庭光爆：整屏暖光炸开，再缓缓退去 */
  boom() {
    if (this.el.bloom) {
      this.el.bloom.classList.remove('on');
      void this.el.bloom.offsetWidth;
      this.el.bloom.classList.add('on');
      setTimeout(() => this.el.bloom && this.el.bloom.classList.remove('on'), 2400);
    }
    this.onBloom();
  }

  flash(text = '') {
    if (!this.el.flash) return;
    if (this.el.flashText) this.el.flashText.textContent = text;
    this.el.flash.classList.remove('on');
    // 强制重排，保证连续触发也能重新播放动画
    void this.el.flash.offsetWidth;
    this.el.flash.classList.add('on');
    setTimeout(() => this.el.flash.classList.remove('on'), 1800);
  }

  showSkip() {
    if (this.el.skip) this.el.skip.classList.add('show');
  }
}
