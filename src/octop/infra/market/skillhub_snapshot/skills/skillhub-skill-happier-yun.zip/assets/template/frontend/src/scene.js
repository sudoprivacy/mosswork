import * as THREE from 'three';

/**
 * 云栖庭院场景 — 纯程序生成，无外部模型依赖
 * 包含：池塘、亭台、竹林、石头、灯笼、路径
 */
export function buildCourtyard(scene) {
  const courtyard = new THREE.Group();
  courtyard.name = 'courtyard';

  // ============ 地面（青石板） ============
  const groundGeom = new THREE.PlaneGeometry(60, 60, 20, 20);
  const groundMat = new THREE.MeshStandardMaterial({
    color: 0x3a403c, roughness: 0.95, metalness: 0.05,
  });
  const ground = new THREE.Mesh(groundGeom, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  courtyard.add(ground);

  // 石板缝隙（用细线条模拟）
  for (let i = -10; i <= 10; i += 2) {
    const line = new THREE.Mesh(
      new THREE.PlaneGeometry(60, 0.05),
      new THREE.MeshBasicMaterial({ color: 0x2a302c })
    );
    line.rotation.x = -Math.PI / 2;
    line.position.set(0, 0.01, i);
    courtyard.add(line);
  }

  // ============ 中央池塘 ============
  const pondGeom = new THREE.CircleGeometry(5, 48);
  const pondMat = new THREE.MeshStandardMaterial({
    color: 0x2a3a4a, roughness: 0.2, metalness: 0.6, transparent: true, opacity: 0.85,
  });
  const pond = new THREE.Mesh(pondGeom, pondMat);
  pond.rotation.x = -Math.PI / 2;
  pond.position.set(0, 0.02, 4);
  courtyard.add(pond);

  // 池塘边框（石头）
  const rimGeom = new THREE.RingGeometry(4.9, 5.2, 48);
  const rimMat = new THREE.MeshStandardMaterial({ color: 0x555048, roughness: 0.9 });
  const rim = new THREE.Mesh(rimGeom, rimMat);
  rim.rotation.x = -Math.PI / 2;
  rim.position.set(0, 0.03, 4);
  courtyard.add(rim);

  // 池塘里的鱼（几个游动的小色块）
  const fishes = [];
  for (let i = 0; i < 6; i++) {
    const fish = new THREE.Mesh(
      new THREE.ConeGeometry(0.15, 0.4, 4),
      new THREE.MeshStandardMaterial({ color: new THREE.Color().setHSL(0.05 + Math.random() * 0.05, 0.6, 0.5) })
    );
    const angle = Math.random() * Math.PI * 2;
    fish.position.set(Math.cos(angle) * 3, 0.08, 4 + Math.sin(angle) * 3);
    fish.rotation.y = Math.random() * Math.PI;
    courtyard.add(fish);
    fishes.push({ mesh: fish, angle, radius: 2 + Math.random() * 2, speed: 0.3 + Math.random() * 0.4 });
  }

  // ============ 亭台（品茗阁） ============
  const pavilion = new THREE.Group();
  pavilion.position.set(0, 0, -6);

  // 亭子基座
  const baseGeom = new THREE.BoxGeometry(8, 0.4, 8);
  const baseMat = new THREE.MeshStandardMaterial({ color: 0x4a4540, roughness: 0.85 });
  const base = new THREE.Mesh(baseGeom, baseMat);
  base.position.y = 0.2;
  base.castShadow = true; base.receiveShadow = true;
  pavilion.add(base);

  // 四根柱子
  const pillarGeom = new THREE.CylinderGeometry(0.18, 0.2, 3.5, 8);
  const pillarMat = new THREE.MeshStandardMaterial({ color: 0x8a3a2a, roughness: 0.7 });
  const pillarPositions = [
    [-3.2, 2.15, -3.2], [3.2, 2.15, -3.2],
    [-3.2, 2.15, 3.2], [3.2, 2.15, 3.2],
  ];
  pillarPositions.forEach(([x, y, z]) => {
    const pillar = new THREE.Mesh(pillarGeom, pillarMat);
    pillar.position.set(x, y, z);
    pillar.castShadow = true;
    pavilion.add(pillar);
  });

  // 亭顶（四角攒尖）
  const roofGeom = new THREE.ConeGeometry(4.5, 2.2, 4);
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x3a2a20, roughness: 0.75 });
  const roof = new THREE.Mesh(roofGeom, roofMat);
  roof.position.y = 4.8;
  roof.rotation.y = Math.PI / 4;
  roof.castShadow = true;
  pavilion.add(roof);

  // 宝顶
  const finial = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 12, 8),
    new THREE.MeshStandardMaterial({ color: 0xc9a96e, metalness: 0.8, roughness: 0.3 })
  );
  finial.position.y = 6.1;
  pavilion.add(finial);

  // 亭内桌椅（茶桌）
  const table = new THREE.Mesh(
    new THREE.BoxGeometry(2, 0.1, 1),
    new THREE.MeshStandardMaterial({ color: 0x6a4030, roughness: 0.6 })
  );
  table.position.set(0, 0.7, 0);
  table.castShadow = true;
  pavilion.add(table);
  // 桌腿
  for (const [dx, dz] of [[-0.8, -0.4], [0.8, -0.4], [-0.8, 0.4], [0.8, 0.4]]) {
    const leg = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.7, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x5a3525 })
    );
    leg.position.set(dx, 0.35, dz);
    pavilion.add(leg);
  }

  courtyard.add(pavilion);

  // ============ 竹林 ============
  function createBamboo(x, z, height = 4) {
    const bamboo = new THREE.Group();
    const segments = Math.floor(height / 0.8);
    for (let i = 0; i < segments; i++) {
      const seg = new THREE.Mesh(
        new THREE.CylinderGeometry(0.06, 0.07, 0.75, 6),
        new THREE.MeshStandardMaterial({ color: 0x4a6a3a, roughness: 0.7 })
      );
      seg.position.y = i * 0.8 + 0.4;
      seg.castShadow = true;
      bamboo.add(seg);
      // 竹节
      const node = new THREE.Mesh(
        new THREE.TorusGeometry(0.07, 0.015, 6, 12),
        new THREE.MeshStandardMaterial({ color: 0x3a5a2a })
      );
      node.position.y = i * 0.8 + 0.02;
      node.rotation.x = Math.PI / 2;
      bamboo.add(node);
    }
    // 竹叶（几个小绿片）
    for (let i = 0; i < 5; i++) {
      const leaf = new THREE.Mesh(
        new THREE.PlaneGeometry(0.4, 0.12),
        new THREE.MeshStandardMaterial({ color: 0x5a7a4a, side: THREE.DoubleSide, roughness: 0.8 })
      );
      const y = height - 0.5 - i * 0.5;
      leaf.position.set((Math.random() - 0.5) * 0.3, y, (Math.random() - 0.5) * 0.3);
      leaf.rotation.set(Math.random() * 0.5, Math.random() * Math.PI, Math.random() * 0.5 - 0.25);
      bamboo.add(leaf);
    }
    bamboo.position.set(x, 0, z);
    return bamboo;
  }

  // 两侧竹林
  for (let i = 0; i < 8; i++) {
    courtyard.add(createBamboo(-12 - Math.random() * 2, -8 + i * 2.5, 3.5 + Math.random() * 2));
    courtyard.add(createBamboo(12 + Math.random() * 2, -8 + i * 2.5, 3.5 + Math.random() * 2));
  }

  // ============ 月洞门（背景视觉锚点） ============
  const gateShape = new THREE.Shape();
  gateShape.moveTo(-10, 0);
  gateShape.lineTo(10, 0);
  gateShape.lineTo(10, 6.4);
  gateShape.lineTo(-10, 6.4);
  gateShape.closePath();
  const gateHole = new THREE.Path();
  gateHole.absarc(0, 2.7, 2.15, 0, Math.PI * 2, true);
  gateShape.holes.push(gateHole);

  const gateWall = new THREE.Mesh(
    new THREE.ShapeGeometry(gateShape, 40),
    new THREE.MeshStandardMaterial({ color: 0x2f3835, roughness: 0.95, side: THREE.DoubleSide })
  );
  gateWall.position.set(0, 0, -17);
  gateWall.receiveShadow = true;
  courtyard.add(gateWall);

  const gateRim = new THREE.Mesh(
    new THREE.TorusGeometry(2.15, 0.14, 8, 48),
    new THREE.MeshStandardMaterial({ color: 0x6a6154, roughness: 0.85 })
  );
  gateRim.position.set(0, 2.7, -16.9);
  courtyard.add(gateRim);

  // 门后暖光，像院里还有一盏未灭的灯
  const gateGlow = new THREE.Mesh(
    new THREE.CircleGeometry(2.0, 48),
    new THREE.MeshBasicMaterial({
      color: 0xffcf8a, transparent: true, opacity: 0.16,
      blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
    })
  );
  gateGlow.position.set(0, 2.7, -17.4);
  courtyard.add(gateGlow);

  // 池塘里的月影
  const moonReflection = new THREE.Mesh(
    new THREE.CircleGeometry(1.5, 32),
    new THREE.MeshBasicMaterial({
      color: 0xf6e7c4, transparent: true, opacity: 0.1,
      blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
    })
  );
  moonReflection.rotation.x = -Math.PI / 2;
  moonReflection.scale.set(1.5, 0.7, 1);
  moonReflection.position.set(-1.2, 0.035, 3.4);
  courtyard.add(moonReflection);

  // ============ 灯笼 ============
  const lanternPositions = [
    [-3, 0, -3], [3, 0, -3], [-3, 0, 3], [3, 0, 3],
    [-6, 0, 0], [6, 0, 0],
  ];
  const lanternLights = [];
  lanternPositions.forEach(([x, y, z]) => {
    // 灯笼杆
    const pole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.03, 0.03, 2.5, 6),
      new THREE.MeshStandardMaterial({ color: 0x3a2a1a })
    );
    pole.position.set(x, 1.25, z);
    courtyard.add(pole);
    // 灯笼
    const lantern = new THREE.Mesh(
      new THREE.SphereGeometry(0.28, 12, 8),
      new THREE.MeshStandardMaterial({
        color: 0xff6644, emissive: 0xff3311, emissiveIntensity: 0.7,
        transparent: true, opacity: 0.92,
      })
    );
    lantern.position.set(x, 2.7, z);
    courtyard.add(lantern);
    // 点光源
    const light = new THREE.PointLight(0xff7744, 0.8, 8);
    light.position.set(x, 2.7, z);
    courtyard.add(light);
    lanternLights.push(light);
  });

  // ============ 石头（庭院装饰） ============
  for (let i = 0; i < 12; i++) {
    const rock = new THREE.Mesh(
      new THREE.DodecahedronGeometry(0.2 + Math.random() * 0.3, 0),
      new THREE.MeshStandardMaterial({ color: 0x555550, roughness: 0.95, flatShading: true })
    );
    const angle = Math.random() * Math.PI * 2;
    const dist = 7 + Math.random() * 8;
    rock.position.set(Math.cos(angle) * dist, 0.1, Math.sin(angle) * dist);
    rock.rotation.set(Math.random(), Math.random(), Math.random());
    rock.castShadow = true; rock.receiveShadow = true;
    courtyard.add(rock);
  }

  // ============ 石板路径 ============
  for (let i = 0; i < 10; i++) {
    const slab = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 0.06, 1.2),
      new THREE.MeshStandardMaterial({ color: 0x4a4540, roughness: 0.9 })
    );
    slab.position.set(0, 0.04, -1 + i * 1.3);
    slab.receiveShadow = true;
    courtyard.add(slab);
  }

  scene.add(courtyard);
  return { courtyard, fishes, lanternLights, pond };
}
