import * as THREE from 'three';
import { COLOR, AVATAR, AVATAR_COLORS, shadeOf } from './design-tokens.js';

/**
 * 云栖 Avatar · 水墨汉服人物（纯程序生成，无外部模型）
 *
 * 设计约束：
 *  - 交领右衽、广袖、束发、玉佩：一眼可辨的中式服饰
 *  - 低多边形 + 平涂色块：远看像水墨剪影，近看有细节
 *  - 无宗教符号（无佛珠、无袈裟、无合十礼）
 *  - 动作采用补间（lerp）而非瞬切，避免"机器人感"
 *
 * 兼容接口：
 *  - createAvatar(color?) → THREE.Group
 *  - setAvatarAction(avatar, action)  action: tea|incense|qin|rain|fish|fan|null
 *  - updateAvatar(avatar, delta, time)  由主渲染循环每帧调用
 */

// ---------- 基础姿态（所有动作的基准值） ----------
const BASE_POSE = {
  bodyTiltX: 0,   // 前倾
  bodyTiltZ: 0,   // 侧倾
  headX: 0,       // 低头/抬头
  headY: 0,       // 转头
  lax: 0, lay: 0, laz: -0.08,   // 左臂 rotation
  rax: 0, ray: 0, raz: 0.08,    // 右臂 rotation
};

// ---------- 六态动作目标姿态 ----------
const POSES = {
  // 煮茶：双臂前伸，双手虚捧茶盏，微微低头
  tea: { lax: -1.02, lay: 0.10, laz: 0.24, rax: -1.02, ray: -0.10, raz: -0.24, headX: 0.14 },
  // 焚香：双手收于胸前，垂目
  incense: { lax: -1.34, lay: 0.06, laz: 0.58, rax: -1.34, ray: -0.06, raz: -0.58, headX: 0.2 },
  // 抚琴：双臂平抬，手落琴面
  qin: { lax: -0.9, lay: 0.02, laz: 0.38, rax: -0.9, ray: -0.02, raz: -0.38, headX: 0.16 },
  // 听雨：微微仰头，右手抬起接雨（持续态）
  rain: { headX: -0.24, headY: 0.12, rax: -1.12, ray: 0.02, raz: -0.58 },
  // 观鱼：身体前倾，双手背在身后（持续态）
  fish: { bodyTiltX: 0.24, lax: 0.86, laz: 0.46, rax: 0.86, raz: -0.46, headX: 0.1 },
  // 摇扇：右手举扇，头略偏
  fan: { rax: -1.2, ray: -0.18, raz: -0.62, headY: 0.14 },
};

const TRANSIENT = new Set(['tea', 'incense', 'qin', 'fan']); // 会自动结束的动作
const ACTION_DURATION = 2800;

/** 能让别的角色转头看过来 */
export function setAvatarLookAt(avatar, targetXZ, duration = 1400) {
  if (!avatar || !avatar.userData) return;
  avatar.userData.lookAt = {
    target: { x: targetXZ.x, z: targetXZ.z },
    startedAt: performance.now(),
    duration,
  };
}

const skinMat = () => new THREE.MeshStandardMaterial({ color: COLOR.skin, roughness: 0.72, metalness: 0 });
const inkMat = () => new THREE.MeshBasicMaterial({ color: COLOR.ink });
const creamMat = () => new THREE.MeshStandardMaterial({ color: COLOR.cream, roughness: 0.9, side: THREE.DoubleSide });
const goldMat = () => new THREE.MeshStandardMaterial({ color: COLOR.gold, roughness: 0.35, metalness: 0.65 });

/** 广袖手臂：肩关节为原点，旋转整条手臂 */
function createArm(side, robeColor, darkColor) {
  const arm = new THREE.Group();
  arm.name = side < 0 ? 'left_arm' : 'right_arm';
  // 肩关节位置
  arm.position.set(side * AVATAR.shoulderX, AVATAR.shoulderY, 0);

  // 上臂（藏在袖中，只露出肩线）
  const upper = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.05, 0.18, 4, 8),
    new THREE.MeshStandardMaterial({ color: robeColor, roughness: 0.86 })
  );
  upper.position.y = -0.13;
  arm.add(upper);

  // 广袖：上窄下阔，开口
  const sleeve = new THREE.Mesh(
    new THREE.CylinderGeometry(0.078, 0.19, 0.42, 14, 1, true),
    new THREE.MeshStandardMaterial({
      color: robeColor, roughness: 0.88, side: THREE.DoubleSide,
    })
  );
  sleeve.position.y = -0.43;
  sleeve.castShadow = true;
  arm.add(sleeve);

  // 袖口滚边
  const cuff = new THREE.Mesh(new THREE.TorusGeometry(0.188, 0.014, 6, 18), creamMat());
  cuff.rotation.x = Math.PI / 2;
  cuff.position.y = -0.63;
  arm.add(cuff);

  // 袖身暗纹（一道深色细线，增加层次）
  const seam = new THREE.Mesh(
    new THREE.TorusGeometry(0.157, 0.006, 4, 18),
    new THREE.MeshBasicMaterial({ color: darkColor })
  );
  seam.rotation.x = Math.PI / 2;
  seam.position.y = -0.5;
  arm.add(seam);

  // 手
  const hand = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), skinMat());
  hand.name = side < 0 ? 'left_hand' : 'right_hand';
  hand.scale.set(0.85, 1.25, 0.72);
  hand.position.y = -0.67;
  arm.add(hand);

  return arm;
}

/** 茶盏（煮茶时出现在右手） */
function createCup() {
  const g = new THREE.Group();
  g.name = 'cup';
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.026, 0.055, 12), creamMat());
  g.add(cup);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.034, 0.004, 5, 14), goldMat());
  rim.rotation.x = Math.PI / 2;
  rim.position.y = 0.028;
  g.add(rim);
  g.position.set(0.02, -0.73, 0.09);
  g.visible = false;
  return g;
}

/** 线香（焚香时出现在右手） */
function createIncense() {
  const g = new THREE.Group();
  g.name = 'incense';
  const stick = new THREE.Mesh(
    new THREE.CylinderGeometry(0.0045, 0.0045, 0.22, 5),
    new THREE.MeshStandardMaterial({ color: 0x6b4a38, roughness: 0.9 })
  );
  stick.position.y = 0.07;
  g.add(stick);
  const ember = new THREE.Mesh(
    new THREE.SphereGeometry(0.009, 8, 6),
    new THREE.MeshBasicMaterial({ color: 0xff7a3c })
  );
  ember.position.y = 0.18;
  g.add(ember);
  g.position.set(0, -0.7, 0.08);
  g.visible = false;
  return g;
}

/** 团扇（摇扇时出现在右手） */
function createFan() {
  const g = new THREE.Group();
  g.name = 'fan';
  const face = new THREE.Mesh(
    new THREE.CircleGeometry(0.15, 20, 0, Math.PI),
    new THREE.MeshStandardMaterial({
      color: COLOR.cream, roughness: 0.9, side: THREE.DoubleSide,
    })
  );
  g.add(face);
  const rim = new THREE.Mesh(
    new THREE.RingGeometry(0.142, 0.152, 20, 1, 0, Math.PI),
    new THREE.MeshBasicMaterial({ color: COLOR.gold, side: THREE.DoubleSide })
  );
  rim.position.z = 0.001;
  g.add(rim);
  // 扇骨
  for (let i = 0; i < 3; i++) {
    const a = (Math.PI / 4) * (i - 1);
    const rib = new THREE.Mesh(
      new THREE.BoxGeometry(0.004, 0.14, 0.003),
      new THREE.MeshBasicMaterial({ color: COLOR.ochre })
    );
    rib.position.set(Math.sin(a) * 0.07, Math.cos(a) * 0.07, 0.002);
    rib.rotation.z = -a;
    g.add(rib);
  }
  g.position.set(0.02, -0.7, 0.09);
  g.rotation.z = -0.2;
  g.visible = false;
  return g;
}

export function createAvatar(color = AVATAR_COLORS[0]) {
  const robeColor = color;
  const darkColor = shadeOf(color, 0.66);

  const avatar = new THREE.Group();
  avatar.name = 'avatar';

  // visual：整体呼吸起伏 / 行走上下
  const visual = new THREE.Group();
  visual.name = 'visual';
  avatar.add(visual);

  // lean：上半身前倾 / 侧倾的支点（在脚踝附近）
  const lean = new THREE.Group();
  lean.name = 'lean';
  visual.add(lean);

  // ============ 袍身（Lathe 旋转成形，收腰放摆） ============
  const profile = [
    [0.001, 0.0], [0.46, 0.0], [0.47, 0.035], [0.43, 0.12],
    [0.395, 0.30], [0.355, 0.50], [0.325, 0.70], [0.305, 0.88],
    [0.285, 0.99], [0.24, 1.06], [0.165, 1.10],
  ].map(([x, y]) => new THREE.Vector2(x, y));

  const robe = new THREE.Mesh(
    new THREE.LatheGeometry(profile, 24),
    new THREE.MeshStandardMaterial({
      color: robeColor, roughness: 0.9, metalness: 0.02, side: THREE.DoubleSide,
    })
  );
  robe.name = 'robe';
  robe.castShadow = true;
  robe.receiveShadow = true;
  lean.add(robe);

  // 裙摆内衬（稍暗，避免下摆穿帮）
  const lining = new THREE.Mesh(
    new THREE.CylinderGeometry(0.435, 0.45, 0.09, 24, 1, true),
    new THREE.MeshStandardMaterial({ color: darkColor, roughness: 0.95, side: THREE.DoubleSide })
  );
  lining.position.y = 0.045;
  lean.add(lining);

  // 下摆压边
  const hem = new THREE.Mesh(
    new THREE.TorusGeometry(0.472, 0.012, 5, 32),
    new THREE.MeshStandardMaterial({ color: COLOR.cream, roughness: 0.9 })
  );
  hem.rotation.x = Math.PI / 2;
  hem.position.y = 0.012;
  lean.add(hem);

  // ============ 交领右衽（两片斜襟在胸前交叠） ============
  const lapelA = new THREE.Mesh(new THREE.BoxGeometry(0.105, 0.44, 0.016), creamMat());
  lapelA.position.set(-0.055, 0.86, 0.305);
  lapelA.rotation.set(-0.32, 0, 0.6);
  lean.add(lapelA);

  const lapelB = new THREE.Mesh(new THREE.BoxGeometry(0.105, 0.42, 0.016), creamMat());
  lapelB.position.set(0.06, 0.85, 0.31);
  lapelB.rotation.set(-0.32, 0, -0.6);
  lean.add(lapelB);

  // 领缘（护住脖颈）
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.098, 0.017, 6, 18), creamMat());
  collar.rotation.x = Math.PI / 2;
  collar.position.y = 1.075;
  lean.add(collar);

  // ============ 腰带 + 绦带 + 玉佩 ============
  const belt = new THREE.Mesh(
    new THREE.CylinderGeometry(0.352, 0.358, 0.1, 20, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x6b4a38, roughness: 0.75, side: THREE.DoubleSide })
  );
  belt.position.y = AVATAR.waistY;
  lean.add(belt);

  const beltLine = new THREE.Mesh(new THREE.TorusGeometry(0.358, 0.008, 4, 28), goldMat());
  beltLine.rotation.x = Math.PI / 2;
  beltLine.position.y = AVATAR.waistY + 0.045;
  lean.add(beltLine);

  // 腰结
  const knot = new THREE.Mesh(
    new THREE.BoxGeometry(0.085, 0.06, 0.035),
    new THREE.MeshStandardMaterial({ color: COLOR.ochre, roughness: 0.8 })
  );
  knot.position.set(0, AVATAR.waistY - 0.01, 0.35);
  lean.add(knot);

  // 两条飘带
  [-0.032, 0.032].forEach((x, i) => {
    const ribbon = new THREE.Mesh(
      new THREE.BoxGeometry(0.042, 0.3, 0.012),
      new THREE.MeshStandardMaterial({ color: COLOR.ochre, roughness: 0.85 })
    );
    ribbon.position.set(x, 0.44, 0.352);
    ribbon.rotation.z = i === 0 ? 0.04 : -0.04;
    lean.add(ribbon);
  });

  // 玉佩（左腰）
  const pendant = new THREE.Mesh(
    new THREE.TorusGeometry(0.032, 0.011, 6, 14),
    new THREE.MeshStandardMaterial({ color: COLOR.jade, roughness: 0.45, metalness: 0.05 })
  );
  pendant.position.set(-0.19, 0.5, 0.3);
  pendant.rotation.y = 0.4;
  lean.add(pendant);
  const tassel = new THREE.Mesh(
    new THREE.CylinderGeometry(0.006, 0.004, 0.08, 5),
    new THREE.MeshStandardMaterial({ color: COLOR.ochre, roughness: 0.9 })
  );
  tassel.position.set(-0.19, 0.435, 0.3);
  lean.add(tassel);

  // ============ 头部 ============
  const head = new THREE.Group();
  head.name = 'head';
  head.position.y = 1.10;
  lean.add(head);

  // 脖颈
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.058, 0.1, 10), skinMat());
  neck.position.y = 0.015;
  head.add(neck);

  const headMesh = new THREE.Mesh(new THREE.SphereGeometry(AVATAR.headRadius, 20, 16), skinMat());
  headMesh.position.y = 0.16;
  headMesh.scale.set(0.94, 1.06, 0.92);
  headMesh.castShadow = true;
  head.add(headMesh);

  // 耳朵
  [-1, 1].forEach((s) => {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 6), skinMat());
    ear.scale.set(0.6, 1, 0.7);
    ear.position.set(s * 0.145, 0.15, 0.01);
    head.add(ear);
  });

  // 发：头顶发盖
  const hairMat = new THREE.MeshStandardMaterial({ color: COLOR.hair, roughness: 0.55 });
  const hairCap = new THREE.Mesh(
    new THREE.SphereGeometry(0.169, 20, 14, 0, Math.PI * 2, 0, Math.PI * 0.44),
    hairMat
  );
  hairCap.position.y = 0.165;
  head.add(hairCap);

  // 发：后脑长发
  const backHair = new THREE.Mesh(new THREE.SphereGeometry(0.152, 18, 14), hairMat);
  backHair.position.set(0, 0.115, -0.06);
  backHair.scale.set(1.0, 1.18, 0.72);
  head.add(backHair);

  // 鬓发（两缕）
  [-1, 1].forEach((s) => {
    const lock = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.2, 0.022), hairMat);
    lock.position.set(s * 0.143, 0.04, 0.035);
    lock.rotation.z = s * -0.03;
    head.add(lock);
  });

  // 发髻
  const bun = new THREE.Mesh(new THREE.SphereGeometry(0.075, 14, 10), hairMat);
  bun.position.set(0, 0.325, -0.05);
  bun.scale.set(1, 0.92, 1);
  head.add(bun);

  // 发带
  const bunBand = new THREE.Mesh(new THREE.TorusGeometry(0.064, 0.01, 5, 16), creamMat());
  bunBand.rotation.x = Math.PI / 2;
  bunBand.position.set(0, 0.318, -0.05);
  head.add(bunBand);

  // 发簪（横穿发髻）
  const pin = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.25, 6), goldMat());
  pin.rotation.z = Math.PI / 2;
  pin.position.set(0.02, 0.335, -0.05);
  head.add(pin);
  const pinBead = new THREE.Mesh(new THREE.SphereGeometry(0.014, 8, 6), goldMat());
  pinBead.position.set(0.14, 0.335, -0.05);
  head.add(pinBead);

  // ============ 眉目（水墨线） ============
  const browGeom = new THREE.BoxGeometry(0.055, 0.006, 0.008);
  [-1, 1].forEach((s) => {
    const brow = new THREE.Mesh(browGeom, inkMat());
    brow.position.set(s * 0.062, 0.207, 0.139);
    brow.rotation.z = s * 0.12;
    head.add(brow);
  });

  // 眼睛：半圆弧（闭目感，安静）
  [-1, 1].forEach((s) => {
    const eye = new THREE.Mesh(
      new THREE.TorusGeometry(0.024, 0.0035, 5, 12, Math.PI),
      inkMat()
    );
    eye.position.set(s * 0.061, 0.158, 0.141);
    eye.scale.set(1, 0.62, 1);
    head.add(eye);
  });

  // 鼻
  const nose = new THREE.Mesh(
    new THREE.BoxGeometry(0.008, 0.02, 0.008),
    new THREE.MeshStandardMaterial({ color: COLOR.skinShade, roughness: 0.8 })
  );
  nose.position.set(0, 0.114, 0.146);
  head.add(nose);

  // 唇
  const mouth = new THREE.Mesh(
    new THREE.BoxGeometry(0.027, 0.005, 0.006),
    new THREE.MeshBasicMaterial({ color: COLOR.ochre })
  );
  mouth.position.set(0, 0.072, 0.144);
  head.add(mouth);

  // 腮红（极淡）
  [-1, 1].forEach((s) => {
    const blush = new THREE.Mesh(
      new THREE.CircleGeometry(0.021, 12),
      new THREE.MeshBasicMaterial({ color: COLOR.ochre, transparent: true, opacity: 0.16 })
    );
    blush.position.set(s * 0.095, 0.108, 0.138);
    head.add(blush);
  });

  // 花钿（额间一点金）
  const huadian = new THREE.Mesh(new THREE.BoxGeometry(0.013, 0.013, 0.004), goldMat());
  huadian.position.set(0, 0.235, 0.143);
  huadian.rotation.z = Math.PI / 4;
  head.add(huadian);

  // ============ 手臂 ============
  const leftArm = createArm(-1, robeColor, darkColor);
  const rightArm = createArm(1, robeColor, darkColor);
  lean.add(leftArm, rightArm);

  // 手中道具（均挂在右手）
  rightArm.add(createCup());
  rightArm.add(createIncense());
  rightArm.add(createFan());

  // ============ 足 ============
  [-1, 1].forEach((s) => {
    const foot = new THREE.Mesh(
      new THREE.BoxGeometry(0.085, 0.05, 0.17),
      new THREE.MeshStandardMaterial({ color: 0x2a2622, roughness: 0.9 })
    );
    foot.position.set(s * 0.088, 0.026, 0.42);
    visual.add(foot);
  });

  // ============ 运行时数据 ============
  avatar.userData = {
    nodes: { visual, lean, head, leftArm, rightArm },
    pose: { ...BASE_POSE },
    target: { ...BASE_POSE },
    action: null,
    moving: false,
    _timer: null,
    _acc: Math.random() * 10, // 相位错开，避免所有人同步呼吸
  };

  return avatar;
}

/**
 * 设置动作（只改目标姿态，由 updateAvatar 补间过去）
 */
export function setAvatarAction(avatar, action) {
  if (!avatar || !avatar.userData) return;
  const data = avatar.userData;

  clearTimeout(data._timer);
  data.action = action || null;

  // 合并目标姿态
  data.target = { ...BASE_POSE, ...(POSES[action] || {}) };

  // 道具显隐
  const nodes = data.nodes;
  const find = (root, name) => root.getObjectByName(name);
  const cup = find(nodes.rightArm, 'cup');
  const incense = find(nodes.rightArm, 'incense');
  const fan = find(nodes.rightArm, 'fan');
  if (cup) cup.visible = action === 'tea';
  if (incense) incense.visible = action === 'incense';
  if (fan) fan.visible = action === 'fan';

  // 瞬时动作自动收势
  if (TRANSIENT.has(action)) {
    data._timer = setTimeout(() => setAvatarAction(avatar, null), ACTION_DURATION);
  }
}

/**
 * 每帧更新：补间 + 呼吸 + 行走摆臂 + 动作细节
 */
export function updateAvatar(avatar, delta = 0.016, time = 0) {
  if (!avatar || !avatar.userData) return;
  const data = avatar.userData;
  const { pose, target, nodes, action } = data;

  // 帧率无关的平滑（越大越快）
  const k = 1 - Math.exp(-delta * 8);
  for (const key in target) {
    pose[key] += (target[key] - pose[key]) * k;
  }

  const t = time + data._acc;

  // ----- 转头（让角色能被"叫住"） -----
  let lookOffset = 0;
  if (data.lookAt) {
    const elapsed = performance.now() - data.lookAt.startedAt;
    const p = Math.min(1, elapsed / data.lookAt.duration);
    // 缓入缓出
    const ease = p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
    const dx = data.lookAt.target.x - avatar.position.x;
    const dz = data.lookAt.target.z - avatar.position.z;
    const worldHeadAngle = Math.atan2(dx, dz);  // 0 = 朝 +Z
    const localHeadAngle = worldHeadAngle - avatar.rotation.y;
    lookOffset = localHeadAngle * ease;
    if (p >= 1) data.lookAt = null;
  }

  // 基础姿态
  let bodyTiltX = pose.bodyTiltX;
  let bodyTiltZ = pose.bodyTiltZ;
  let lax = pose.lax;
  let lay = pose.lay;
  let laz = pose.laz;
  let rax = pose.rax;
  let ray = pose.ray;
  let raz = pose.raz;
  let headX = pose.headX;
  let headY = pose.headY + lookOffset;
  let bob = Math.sin(t * 1.7) * 0.006;

  // 行走：摆臂 + 上下起伏
  if (data.moving) {
    const swing = Math.sin(t * 7.5) * 0.34;
    lax += swing;
    rax -= swing;
    bob += Math.abs(Math.sin(t * 7.5)) * 0.028;
    bodyTiltZ += Math.sin(t * 7.5) * 0.012;
  } else if (!action) {
    // 静立时的细微转头
    headY += Math.sin(t * 0.32) * 0.1;
  }

  // 动作细节
  if (action === 'qin') {
    rax += Math.sin(t * 9) * 0.07;   // 拨弦
    headX += Math.sin(t * 2) * 0.01;
  } else if (action === 'fan') {
    raz += Math.sin(t * 4) * 0.16;   // 摇扇
  } else if (action === 'rain') {
    headX += Math.sin(t * 1.1) * 0.012;
  } else if (action === 'fish') {
    bodyTiltZ += Math.sin(t * 0.9) * 0.015;
  } else if (action === 'tea') {
    headX += Math.sin(t * 1.6) * 0.008;
  }

  // 应用
  nodes.visual.position.y = bob;
  nodes.lean.rotation.x = bodyTiltX;
  nodes.lean.rotation.z = bodyTiltZ;
  nodes.head.rotation.x = headX;
  nodes.head.rotation.y = headY;
  nodes.leftArm.rotation.set(lax, lay, laz);
  nodes.rightArm.rotation.set(rax, ray, raz);
}
