#!/usr/bin/env bash
# 云栖 · 工程自检：语法 → 构建 → 启动 → HTTP 健康 → WebSocket 握手
set -euo pipefail

PROJECT="${1:-$PWD}"
PORT="${PORT:-8899}"
cd "$PROJECT"

echo "▶ 检查环境"
command -v node >/dev/null || { echo "✗ 未安装 Node.js"; exit 1; }
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
[ "$NODE_MAJOR" -ge 18 ] || { echo "✗ 需要 Node.js >= 18，当前 $(node -v)"; exit 1; }
echo "  node $(node -v)"

echo "▶ 语法检查"
find frontend/src backend/src -name '*.js' -print0 | while IFS= read -r -d '' f; do
  node --check "$f" || { echo "✗ 语法错误：$f"; exit 1; }
done
echo "  ✓ 全部 JS 通过"

echo "▶ 安装依赖"
npm install --no-audit --no-fund --loglevel=error
(cd backend && npm install --no-audit --no-fund --loglevel=error)

echo "▶ 构建前端"
npm run build:frontend

echo "▶ 启动后端"
PORT="$PORT" PUBLIC_DIR="$PROJECT/frontend/dist" node backend/src/server.js > /tmp/yunqi-verify.log 2>&1 &
PID=$!
trap 'kill $PID 2>/dev/null || true' EXIT

for i in $(seq 1 40); do
  if curl -sf "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then break; fi
  sleep 0.25
done

echo "▶ HTTP 健康检查"
HEALTH="$(curl -sf "http://127.0.0.1:$PORT/health" || true)"
[ -n "$HEALTH" ] || { echo "✗ /health 无响应"; cat /tmp/yunqi-verify.log; exit 1; }
echo "  $HEALTH"

echo "▶ 静态资源检查"
curl -sf "http://127.0.0.1:$PORT/" | grep -q "云栖" || { echo "✗ 首页内容异常"; exit 1; }
echo "  ✓ 首页可访问"

echo "▶ WebSocket 握手"
node -e '
const WebSocket = require(process.argv[1]);
const ws = new WebSocket("ws://127.0.0.1:" + process.argv[2] + "/ws?room=verify&peerId=t1&name=verify");
const timer = setTimeout(() => { console.log("✗ WS 超时"); process.exit(1); }, 5000);
ws.on("message", (d) => {
  const m = JSON.parse(d.toString());
  if (m.type === "init") { clearTimeout(timer); console.log("  ✓ WS init 正常，房间内 " + m.peers.length + " 人"); ws.close(); }
});
ws.on("error", (e) => { clearTimeout(timer); console.log("✗ WS 错误：" + e.message); process.exit(1); });
' "$PROJECT/backend/node_modules/ws" "$PORT"

echo ""
echo "✓ 自检通过：$PROJECT 可以部署"
