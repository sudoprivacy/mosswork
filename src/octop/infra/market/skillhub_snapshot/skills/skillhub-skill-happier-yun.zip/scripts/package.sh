#!/usr/bin/env bash
# 云栖 · 打包成可上传云托管的 zip（不含 node_modules / dist）
set -euo pipefail

PROJECT="${1:-$PWD}"
OUT="${2:-$PROJECT/../yunqi-cloudbase.zip}"
cd "$PROJECT"

echo "▶ 构建前端"
npm run build:frontend

echo "▶ 生成 Dockerfile（若不存在）"
if [ ! -f Dockerfile ]; then
  cat > Dockerfile <<'EOF'
FROM node:20-alpine
WORKDIR /app
COPY package.json ./
RUN npm install --omit=dev --no-audit --no-fund
COPY backend ./backend
COPY frontend/dist ./public
ENV NODE_ENV=production
ENV PORT=80
ENV PUBLIC_DIR=/app/public
EXPOSE 80
CMD ["node", "backend/src/server.js"]
EOF
fi

echo "▶ 打包"
rm -f "$OUT"
zip -rq "$OUT" . \
  -x "node_modules/*" "*/node_modules/*" "frontend/dist/*" ".git/*" "*.zip" ".DS_Store"

echo "✓ 已生成：$OUT"
du -h "$OUT"
