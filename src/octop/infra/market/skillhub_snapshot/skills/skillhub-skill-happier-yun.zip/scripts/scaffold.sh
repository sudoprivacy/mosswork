#!/usr/bin/env bash
# 云栖 · 从模板生成一个新工程
set -euo pipefail

TARGET="${1:-./yunqi-courtyard}"
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ -d "$TARGET" ] && [ -n "$(ls -A "$TARGET" 2>/dev/null || true)" ]; then
  echo "✗ 目标目录已存在且非空：$TARGET"
  echo "  换一个路径，或先清空该目录。"
  exit 1
fi

mkdir -p "$TARGET"
cp -R "$SKILL_DIR/assets/template/." "$TARGET/"

echo "✓ 已生成工程：$TARGET"
echo ""
echo "下一步："
echo "  cd $TARGET"
echo "  npm install"
echo "  npm run build:frontend"
echo "  npm start"
echo ""
echo "  浏览器打开 http://localhost:3000"
