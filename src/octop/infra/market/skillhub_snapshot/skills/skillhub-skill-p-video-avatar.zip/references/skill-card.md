## Description: <br>
Use when someone wants a person on camera speaking a script - lip-synced host, spokesperson, or narrated avatar from a portrait photo. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[pruna-ai](https://clawhub.ai/user/pruna-ai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creative operators use this skill to prepare talking-avatar video generations through Pruna's remote API from a portrait image plus a script or uploaded audio. It guides prompt setup, API calls, user confirmations, and quality checks for lip-synced host, spokesperson, and narrated avatar clips. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Selected portraits, scripts, audio, and generated media are sent to Pruna's remote API for processing. <br>
Mitigation: Confirm the user is comfortable with remote processing before uploads or paid prediction calls, and follow the provider's terms. <br>
Risk: Avatar generation may involve real-person likenesses, voices, or copyrighted material. <br>
Mitigation: Confirm rights and consent for any real person's likeness or voice before use. <br>
Risk: API keys could be exposed if copied into prompts, logs, manifests, or shared task text. <br>
Mitigation: Keep credentials in environment variables and never embed keys in prompts, chat, manifests, plan JSON, logs, or subagent briefs. <br>
Risk: Downloaded outputs can overwrite local files. <br>
Mitigation: Review output paths before downloads and confirm paths with the user before writing generated media. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/pruna-ai/skills/p-video-avatar) <br>
- [P-Video-Avatar Pruna docs](https://docs.pruna.ai/en/stable/docs_pruna_endpoints/performance_models/p-video-avatar.html) <br>
- [Pruna API quickstart](https://docs.api.pruna.ai/guides/quickstart) <br>
- [Pruna API reference](references/pruna-api.md) <br>
- [Agent safety](references/agent-safety.md) <br>
- [API credentials](references/api-credentials.md) <br>
- [Generation diversity](references/generation-diversity.md) <br>
- [P-video-avatar quality checklist](references/p-video-avatar-quality-checklist.md) <br>
- [Realistic persona showcase](references/realistic-persona-showcase.md) <br>
- [Scene anchor triple](references/scene-anchor-triple.md) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, API calls] <br>
**Output Format:** [Markdown guidance with JSON and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires user confirmation before remote media upload or paid prediction calls; outputs may include local file paths for downloaded generated media.] <br>

## Skill Version(s): <br>
1.0.6 (source: server release metadata and skill frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
