#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
文档脱敏 自动化测试套件
用法:   python test_desensitize.py
        python test_desensitize.py -v   （详细输出）
零依赖: 纯标准库
"""
import os, io, sys, re, zipfile, tempfile, shutil

# Windows GBK 终端兼容：强制 UTF-8 输出
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import desensitize as ds

# ── 全局状态 ──
TESTS = []
PASS = FAIL = SKIP = 0
VERBOSE = '-v' in sys.argv or '--verbose' in sys.argv


def test(name):
    def deco(fn):
        TESTS.append((name, fn))
        return fn
    return deco


# ════════════════════════════
# 夹具生成器
# ════════════════════════════

def _enc(s):
    """zipfile.writestr 在 Windows 上默认 cp437，强制 utf-8"""
    return s.encode('utf-8')


def _make_docx(document_xml, core_props_xml=None):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', _enc(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Override PartName="/word/document.xml"'
            ' ContentType="application/vnd.openxmlformats.wordprocessingml.document.main+xml"/>'
            '<Override PartName="/docProps/core.xml"'
            ' ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            '</Types>'))
        z.writestr('_rels/.rels', _enc(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" Target="docProps/core.xml"/>'
            '</Relationships>'))
        z.writestr('word/_rels/document.xml.rels', _enc(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'))
        z.writestr('word/document.xml', _enc(document_xml))
        if core_props_xml:
            z.writestr('docProps/core.xml', _enc(core_props_xml))
    buf.seek(0)
    return buf


def _make_xlsx(sheet_xml, shared_strings_xml=None, core_props_xml=None):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', _enc(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Override PartName="/xl/workbook.xml"'
            ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml"'
            ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            '<Override PartName="/xl/sharedStrings.xml"'
            ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
            '<Override PartName="/docProps/core.xml"'
            ' ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            '</Types>'))
        z.writestr('_rels/.rels', _enc(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" Target="docProps/core.xml"/>'
            '</Relationships>'))
        z.writestr('xl/workbook.xml', _enc(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets>'
            '</workbook>'))
        z.writestr('xl/_rels/workbook.xml.rels', _enc(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'
            '</Relationships>'))
        z.writestr('xl/worksheets/sheet1.xml', _enc(sheet_xml))
        z.writestr('xl/sharedStrings.xml', _enc(shared_strings_xml or
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"/>'))
        if core_props_xml:
            z.writestr('docProps/core.xml', _enc(core_props_xml))
    buf.seek(0)
    return buf


def _read_docx_xml(path):
    """读取 docx 中 word/document.xml 和 docProps/core.xml 的文本拼接"""
    parts = []
    with zipfile.ZipFile(path, 'r') as z:
        for name in sorted(z.namelist()):
            if (name.startswith('word/') or name.startswith('docProps/')) and name.endswith('.xml'):
                parts.append(z.read(name).decode('utf-8'))
    return '\n'.join(parts)


def _read_xlsx_xml(path):
    """读取 xlsx 中所有 xl/ 和 docProps/ XML 文本拼接"""
    parts = []
    with zipfile.ZipFile(path, 'r') as z:
        for name in sorted(z.namelist()):
            if (name.startswith('xl/') or name.startswith('docProps/')) and name.endswith('.xml'):
                parts.append(z.read(name).decode('utf-8'))
    return '\n'.join(parts)


def docx_out(path):
    """等待脱敏输出路径，然后读取其 XML"""
    return _read_docx_xml(path)


# ════════════════════════════
# 测试用例
# ════════════════════════════

@test('手机号脱敏')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t xml:space="preserve">请致电 13800138000 咨询</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        assert r, '应生成输出文件'
        data = _read_docx_xml(r)
        assert '13800138000' not in data, '手机号未被脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('身份证脱敏')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>证件号 110101199001011234</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        assert r, '应生成输出文件'
        data = _read_docx_xml(r)
        assert '110101199001011234' not in data, '身份证未被脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('XML结构完整性')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
        ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<w:body><w:p><w:r><w:t>请联系 北京大学 招生办，电话 13800138000</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        data = _read_docx_xml(r)
        assert '<w:document' in data, 'XML 根元素丢失'
        assert 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"' in data, '命名空间被破坏'
        assert '*****http' not in data, '星号打到了命名空间 URL'
        assert '13800138000' not in data
    finally:
        shutil.rmtree(tmpdir)


@test('跨run断裂合并')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p>'
        '<w:r><w:t>汇报单位：</w:t></w:r>'
        '<w:r><w:t>电子科技</w:t></w:r>'
        '<w:r><w:t>大学</w:t></w:r>'
        '</w:p></w:body></w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        data = _read_docx_xml(r)
        assert '电子科技' not in data, '拆分后的学校名未脱敏'
        assert '汇报单位' in data, '正常文本不应被破坏'
    finally:
        shutil.rmtree(tmpdir)


@test('修订模式delText')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r>'
        '<w:delText xml:space="preserve">旧单位：电子科技大学</w:delText>'
        '</w:r></w:p></w:body></w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        data = _read_docx_xml(r)
        # w:delText 的内容可能在返回的 XML 中保留（因为 ET 解析可能不规范），
        # 只需确认若存在 w:delText 则其内容已脱敏
        assert '电子科技' not in data, '修订模式中的学校名未脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('绘图文字a:t')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
        ' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<w:body><w:p><w:r>'
        '<w:drawing><wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">'
        '<a:graphic><a:graphicData>'
        '<wps:wsp xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape">'
        '<wps:txbx><w:txbxContent><w:p><w:r><a:t>北京大学</a:t></w:r></w:p></w:txbxContent></wps:txbx>'
        '</wps:wsp>'
        '</a:graphicData></a:graphic>'
        '</wp:inline></w:drawing>'
        '</w:r></w:p></w:body></w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        data = _read_docx_xml(r)
        assert '北京' not in data, '绘图文字中的地名未脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('域代码instrText')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p>'
        '<w:r><w:fldChar w:fldCharType="begin"/></w:r>'
        '<w:r><w:instrText xml:space="preserve"> TOC 北京大学招生简章</w:instrText></w:r>'
        '<w:r><w:fldChar w:fldCharType="separate"/></w:r>'
        '<w:r><w:t>目录</w:t></w:r>'
        '<w:r><w:fldChar w:fldCharType="end"/></w:r>'
        '</w:p></w:body></w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        data = _read_docx_xml(r)
        assert '北京' not in data, '域代码中的地名未脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('docProps脱敏')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>正文内容</w:t></w:r></w:p></w:body></w:document>',
        core_props_xml=
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"'
        ' xmlns:dc="http://purl.org/dc/elements/1.1/">'
        '<dc:creator>北京大学招生办</dc:creator>'
        '<cp:lastModifiedBy>电子科技大学</cp:lastModifiedBy>'
        '</cp:coreProperties>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        data = _read_docx_xml(r)
        assert '北京大学' not in data, 'docProps 学校名未脱敏'
        assert '电子科技' not in data, 'docProps 学校名未脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('空白文档不崩溃')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t xml:space="preserve">   </w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        assert r is None, '空白文档不应生成输出'
    finally:
        shutil.rmtree(tmpdir)


@test('已脱敏文件跳过')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>13800138000</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        fpath = os.path.join(tmpdir, 'a_脱敏.docx')
        with open(fpath, 'wb') as f: f.write(doc.read())
        r, s = ds.process_path(fpath)
        assert r is None, '已脱敏文件应被跳过'
    finally:
        shutil.rmtree(tmpdir)


@test('输出目录自动创建')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>13800138000</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        nonexist = os.path.join(tmpdir, 'new_subdir', 'out.docx')
        r, s = ds.process_path(src, nonexist)
        assert r is not None, '应成功生成到不存在的目录'
        assert os.path.exists(nonexist)
    finally:
        shutil.rmtree(tmpdir)


@test('覆盖警告')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>13800138000</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        out = os.path.join(tmpdir, 'o.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        with open(out, 'wb') as f: f.write(b'x')
        logs = []
        r, s = ds.process_path(src, out, log_func=logs.append)
        assert any('覆盖' in l for l in logs), '覆盖警告未触发'
    finally:
        shutil.rmtree(tmpdir)


@test('dry-run预览模式')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>电话 13800138000，联系 北京大学</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_path(src, dry_run=True)
        assert r is None, 'dry-run 不应生成文件'
        # 检查没有脱敏文件生成
        assert not os.path.exists(os.path.join(tmpdir, 's_脱敏.docx')), 'dry-run 不应生成脱敏文件'
    finally:
        shutil.rmtree(tmpdir)


@test('规则过滤phone')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>电话 13800138000，就读 北京大学 信息学院</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src, rules='phone')
        data = _read_docx_xml(r)
        assert '13800138000' not in data, '手机号未脱敏'
        assert '北京大学' in data, '学校名不应被脱敏（只启用phone规则）'
    finally:
        shutil.rmtree(tmpdir)


@test('非法规则名警告')
def _():
    logs = []
    r = ds._parse_rules('phone,fake_rule,id_card', log_func=logs.append)
    assert r and 'phone' in r, '合法规则未识别'
    assert 'id_card' in r
    assert any('fake_rule' in l for l in logs), '非法规则未警告'


@test('xlsx文本单元格')
def _():
    xls = _make_xlsx(
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
        ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row></sheetData>'
        '</worksheet>',
        '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="2">'
        '<si><t>手机号</t></si><si><t>13800138000</t></si></sst>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.xlsx')
        with open(src, 'wb') as f: f.write(xls.read())
        r, s = ds.process_xlsx(src)
        assert r, 'xlsx 未生成输出'
        data = _read_xlsx_xml(r)
        assert '13800138000' not in data, 'xlsx 手机号未脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('xlsx数值格v标签')
def _():
    xls = _make_xlsx(
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetData><row r="1"><c r="A1"><v>110101199001011234</v></c></row></sheetData>'
        '</worksheet>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.xlsx')
        with open(src, 'wb') as f: f.write(xls.read())
        r, s = ds.process_xlsx(src)
        assert r, 'xlsx 未生成输出'
        data = _read_xlsx_xml(r)
        assert '110101199001011234' not in data, 'xlsx 数值格身份证未脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('xlsx科学记数法')
def _():
    xls = _make_xlsx(
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetData><row r="1"><c r="A1"><v>1.10101E+17</v></c></row></sheetData>'
        '</worksheet>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.xlsx')
        with open(src, 'wb') as f: f.write(xls.read())
        logs = []
        r, s = ds.process_xlsx(src, log_func=logs.append)
        found = any('科学记数' in l for l in logs)
        assert found or r is None, '科学记数法未检测到'
    finally:
        shutil.rmtree(tmpdir)


@test('xlsx docProps')
def _():
    xls = _make_xlsx(
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData/></worksheet>',
        core_props_xml=
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"'
        ' xmlns:dc="http://purl.org/dc/elements/1.1/">'
        '<dc:creator>北京大学</dc:creator></cp:coreProperties>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.xlsx')
        with open(src, 'wb') as f: f.write(xls.read())
        r, s = ds.process_xlsx(src)
        assert r, 'xlsx 未生成输出'
        data = _read_xlsx_xml(r)
        assert '北京大学' not in data, 'xlsx docProps 学校名未脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('递归文件夹')
def _():
    doc_raw = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>13800138000</w:t></w:r></w:p></w:body>'
        '</w:document>').read()
    doc2_raw = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>13900139000</w:t></w:r></w:p></w:body>'
        '</w:document>').read()
    tmpdir = tempfile.mkdtemp()
    try:
        with open(os.path.join(tmpdir, 'a.docx'), 'wb') as f: f.write(doc_raw)
        os.makedirs(os.path.join(tmpdir, 'sub'))
        with open(os.path.join(tmpdir, 'sub', 'b.docx'), 'wb') as f: f.write(doc2_raw)
        os.makedirs(os.path.join(tmpdir, 'sub', 'subsub'))
        with open(os.path.join(tmpdir, 'sub', 'subsub', 'c.docx'), 'wb') as f: f.write(doc_raw)

        outdir = os.path.join(tmpdir, 'output')
        results, stats = ds.process_path(tmpdir, outdir)
        assert len(results) == 3, f'应处理3个文件，实际{len(results)}'
        assert os.path.exists(os.path.join(outdir, 'a_脱敏.docx'))
        assert os.path.exists(os.path.join(outdir, 'sub', 'b_脱敏.docx'))
        assert os.path.exists(os.path.join(outdir, 'sub', 'subsub', 'c_脱敏.docx'))
    finally:
        shutil.rmtree(tmpdir)


@test('不支持的格式跳过')
def _():
    tmpdir = tempfile.mkdtemp()
    try:
        logs = []
        with open(os.path.join(tmpdir, 'x.txt'), 'w') as f: f.write('x')
        r, s = ds.process_path(tmpdir, log_func=logs.append)
        assert any('支持的文档' in l or '不支持' in l for l in logs), '不支持格式应有提示'
    finally:
        shutil.rmtree(tmpdir)


@test('加密文件不崩溃')
def _():
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(b'this is not a valid zip file')
        r, s = ds.process_docx(src)
        assert r is None, '损坏文件应返回 None'
    finally:
        shutil.rmtree(tmpdir)


@test('非docx/xlsx文件原样复制')
def _():
    tmpdir = tempfile.mkdtemp()
    outdir = os.path.join(tmpdir, 'out')
    try:
        # 混合文件：1个docx(含手机号) + 1个txt + 1个pdf(假) + 子目录里1个jpg
        subdir = os.path.join(tmpdir, 'sub')
        os.makedirs(subdir)
        # 创建一个含手机号的 docx（确保会被脱敏）
        doc_path = os.path.join(tmpdir, 'test.docx')
        doc_buf = _make_docx(
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            '<w:body><w:p><w:r><w:t>手机号13812345678</w:t></w:r></w:p></w:body></w:document>')
        with open(doc_path, 'wb') as f: f.write(doc_buf.getvalue())
        # 非 docx/xlsx 文件
        txt_path = os.path.join(tmpdir, 'readme.txt')
        with open(txt_path, 'w') as f: f.write('hello world')
        pdf_path = os.path.join(tmpdir, 'fake.pdf')
        with open(pdf_path, 'wb') as f: f.write(b'not a real pdf')
        jpg_path = os.path.join(subdir, 'photo.jpg')
        with open(jpg_path, 'wb') as f: f.write(b'not a real jpg')

        ds.process_path(tmpdir, outdir, log_func=lambda _: None)

        # 输出目录应包含所有文件
        assert os.path.exists(os.path.join(outdir, 'readme.txt')), 'txt 应被复制'
        assert os.path.exists(os.path.join(outdir, 'fake.pdf')), 'pdf 应被复制'
        assert os.path.exists(os.path.join(outdir, 'sub', 'photo.jpg')), '子目录 jpg 应被复制'
        # 内容不变
        with open(os.path.join(outdir, 'readme.txt')) as f:
            assert f.read() == 'hello world', 'txt 内容应不变'
        # docx 应已脱敏（带_脱敏后缀）
        assert os.path.exists(os.path.join(outdir, 'test_脱敏.docx')), 'docx 应已脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('地址合并')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body>'
        '<w:p><w:r><w:t>北京市朝阳区</w:t></w:r></w:p>'
        '<w:p><w:r><w:t>望京街道</w:t></w:r></w:p>'
        '</w:body></w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        data = _read_docx_xml(r)
        assert '朝阳区' not in data, '地址碎片合并后地名未脱敏'
    finally:
        shutil.rmtree(tmpdir)


@test('统计报告正常')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>手机19912345678，邮箱test@qq.com</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, stats = ds.process_docx(src)
        assert stats, '应有脱敏统计'
        # 至少应检测到手机号
        assert "phone" in stats or stats.get("phone", 0) > 0 or stats.get("landline", 0) > 0, \
            f'应检测到号码类脱敏，实际: {list(stats.keys())} {stats}'
    finally:
        shutil.rmtree(tmpdir)


@test('原文件不被修改')
def _():
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:p><w:r><w:t>学校北京大学，电话13800138000</w:t></w:r></w:p></w:body>'
        '</w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        with open(src, 'rb') as f: original = f.read()
        r, s = ds.process_docx(src)
        with open(src, 'rb') as f: after = f.read()
        assert original == after, '原文件被修改！'
    finally:
        shutil.rmtree(tmpdir)


# ════════════════════════════
# 运行器
# ════════════════════════════

@test('表格标签/值分离单元格脱敏')
def _():
    # 登记表典型结构：标签与值分处两个 <w:tc>
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:tbl>'
        '<w:tr>'
        '<w:tc><w:p><w:r><w:t xml:space="preserve">姓名：</w:t></w:r></w:p></w:tc>'
        '<w:tc><w:p><w:r><w:t>韩梅梅</w:t></w:r></w:p></w:tc>'
        '</w:tr>'
        '<w:tr>'
        '<w:tc><w:p><w:r><w:t xml:space="preserve">手机号：</w:t></w:r></w:p></w:tc>'
        '<w:tc><w:p><w:r><w:t>13800138000</w:t></w:r></w:p></w:tc>'
        '</w:tr>'
        '<w:tr>'
        '<w:tc><w:p><w:r><w:t xml:space="preserve">就诊医院：</w:t></w:r></w:p></w:tc>'
        '<w:tc><w:p><w:r><w:t>北京协和医院</w:t></w:r></w:p></w:tc>'
        '</w:tr>'
        '</w:tbl></w:body></w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        assert r, '含敏感信息的表格应生成输出文件'
        data = _read_docx_xml(r)
        # 值应被脱敏
        assert '韩梅梅' not in data, '表格中姓名值漏脱敏'
        assert '13800138000' not in data, '表格中手机号值漏脱敏'
        assert '北京协和医院' not in data, '表格中医院值漏脱敏'
        # 标签应保留
        assert '姓名' in data, '标签前缀被误遮'
        assert '手机号' in data, '标签前缀被误遮'
        assert '就诊医院' in data, '标签前缀被误遮'
    finally:
        shutil.rmtree(tmpdir)


@test('表格非标签相邻单元格不误遮')
def _():
    # 相邻两格并非「标签：值」结构，不应被配对遮蔽
    doc = _make_docx(
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body><w:tbl><w:tr>'
        '<w:tc><w:p><w:r><w:t>北京市</w:t></w:r></w:p></w:tc>'
        '<w:tc><w:p><w:r><w:t>朝阳区建国路88号</w:t></w:r></w:p></w:tc>'
        '</w:tr></w:tbl></w:body></w:document>')
    tmpdir = tempfile.mkdtemp()
    try:
        src = os.path.join(tmpdir, 's.docx')
        with open(src, 'wb') as f: f.write(doc.read())
        r, s = ds.process_docx(src)
        # 地址类默认开启，原逻辑会各自脱敏（北京市/朝阳区/建国路/88号），这里只验证不出现跨格误拼
        data = _read_docx_xml(r) if r else ''
        # 不应出现把两格拼起来当整体遮蔽的残缺结果（如保留「北京市」却把后半整体变星）
        assert '北京市朝阳区建国路88号' not in data, '相邻地址碎片被跨格拼成整体，违反预期'
    finally:
        shutil.rmtree(tmpdir)


def run():
    global PASS, FAIL, SKIP
    print('=' * 56)
    print('  文档脱敏 自动化测试')
    print('=' * 56)
    for i, (name, fn) in enumerate(TESTS, 1):
        try:
            fn()
            PASS += 1
            status = '✅ PASS'
        except AssertionError as e:
            FAIL += 1
            status = f'❌ FAIL — {e}'
        except Exception as e:
            FAIL += 1
            status = f'💥 CRASH — {type(e).__name__}: {e}'
        if VERBOSE or 'FAIL' in status:
            print(f'  [{i:02d}] {name:<24s} {status}')
        else:
            print(f'  [{i:02d}] {name:<24s} ✅ PASS')
    print('─' * 56)
    print(f'  {PASS} pass / {FAIL} fail / {SKIP} skip (共 {len(TESTS)} 项)')
    print('=' * 56)
    if FAIL:
        print('\n  ⚠️ 有测试未通过，请先修复再上传技能！')
        sys.exit(1)
    else:
        print('\n  🎉 全部通过！技能可以安全上传。')


if __name__ == '__main__':
    run()
