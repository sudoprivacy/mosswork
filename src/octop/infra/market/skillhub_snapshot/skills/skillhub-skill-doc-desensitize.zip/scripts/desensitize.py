#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
文档脱敏脚本 - 纯标准库版（无第三方依赖）
支持格式: .docx .xlsx
原理: .docx/.xlsx 本质是 ZIP 包，直接操作内部 XML 实现脱敏

v3: 文档属性脱敏、自动创建输出目录、脱敏统计报告、文件占用友好提示、科学记数法检测
v3.3: 合并 v7.2 GUI 版的 school2 规则（医学部/研究院），规则总数 20 → 21
v3.4: 修复表格「标签单元格+值单元格」分离导致的漏脱敏（如 姓名：|韩梅梅）；
      给 school/company/address 等 BODY 规则加 (?![:：])，避免「就诊医院：」这类标签前缀被误遮

用法:
  python desensitize.py <输入文件或目录> [输出路径]
"""

import os
import re
import sys
import shutil
import zipfile
import io
import argparse
import xml.etree.ElementTree as ET

# ============================================================
# OOXML 命名空间
# ============================================================
NS_W  = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS_A  = 'http://schemas.openxmlformats.org/drawingml/2006/main'
NS_DC = 'http://purl.org/dc/elements/1.1/'
NS_CP = 'http://schemas.openxmlformats.org/package/2006/metadata/core-properties'
NS_DCT = 'http://purl.org/dc/terms/'

for _pfx, _uri in [
    ('w',    NS_W),
    ('a',    NS_A),
    ('dc',   NS_DC),
    ('cp',   NS_CP),
    ('dcterms', NS_DCT),
    ('r',    'http://schemas.openxmlformats.org/officeDocument/2006/relationships'),
    ('mc',   'http://schemas.openxmlformats.org/markup-compatibility/2006'),
    ('wp',   'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'),
    ('wps',  'http://schemas.microsoft.com/office/word/2010/wordprocessingShape'),
    ('wpg',  'http://schemas.microsoft.com/office/word/2010/wordprocessingGroup'),
    ('w14',  'http://schemas.microsoft.com/office/word/2010/wordml'),
    ('w15',  'http://schemas.microsoft.com/office/word/2012/wordml'),
    ('w16',  'http://schemas.microsoft.com/office/word/2018/wordml'),
    ('wpc',  'http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas'),
]:
    try:
        ET.register_namespace(_pfx, _uri)
    except Exception:
        pass


# ============================================================
# 脱敏规则定义
# ============================================================
PATTERNS = {
    # ---- 标签类（保留标签前缀，只替换内容）----
    'name':           r'(?:姓名|患者|联系人|主治医师|主管医师|经治医师|'
                        r'住院医师|主治医生|管床医生|管床医师|首诊医师|'
                        r'报告医师|审核医师|操作医师|检查医师|送检医师|采集医师)'
                        r'\s*[:：]\s*[\u4e00-\u9fff]{2,4}',
    'medical':        r'(?:病历号|住院号|门诊号|就诊号|档案号|病案号)'
                        r'\s*[:：]?\s*[a-zA-Z0-9]{4,20}',
    'wechat':         r'(?:微信|WeChat|wechat)\s*[:：]?\s*[a-zA-Z][-_a-zA-Z0-9]{5,19}',
    'qq':             r'(?:QQ|qq|Qq)\s*[:：]?\s*[1-9]\d{4,10}',
    'landline_label': r'(?:电话|联系电话|Tel|Phone|传真|Fax|联系方式)'
                        r'\s*[:：]?\s*(?:0\d{1,3}[-\s]?)?\d{7,8}',
    'school_label':   r'(?:学校名称|学校|院校名称|院校)'
                        r'\s*[:：]\s*[\u4e00-\u9fff\uff08\uff09()\w]{2,30}',
    'company_label':  r'(?:工作单位|单位名称|公司名称|所在单位|存档单位|'
                        r'原存档单位|现工作单位|就职单位)'
                        r'\s*[:：]\s*[\u4e00-\u9fff\uff08\uff09()\w]{2,40}',
    'hospital_label': r'(?:就诊医院|住院医院|体检医院|分娩医院|产检医院|'
                        r'康复医院|定点医院|医疗机构|诊所|卫生院)'
                        r'\s*[:：]\s*[\u4e00-\u9fff\uff08\uff09()\w]{2,40}',
    'address_label':  r'(?:通讯地址|联系地址|居住地址|住址|地址|家庭住址|'
                        r'寄送地址|档案寄送地址|学籍档案寄送地址|邮寄地址)'
                        r'\s*[:：]\s*[\u4e00-\u9fff0-9A-Za-z\s\-—_（）()号栋楼层室]{2,60}',

    # ---- 整体替换规则（直接整段替换）----
    'phone':        r'1[3-9]\d{9}',
    'id_card':      r'\d{17}[\dXx]',
    'email':        r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
    'landline':     r'0\d{2,3}[-\s]?\d{7,8}',
    'url':          r'https?://[^\s<>"\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]+',
    # 注：下列规则末尾加 (?![:：]) —— 紧跟冒号的是「标签前缀」(如 就诊医院：/北京大学：)，
    # 不是值，避免标签前缀被误遮（同时修复表格标签单元格场景）
    'school':       r'(?<![使用办有去考就谈看])[\u4e00-\u9fff]{2,6}(?:大学|学院|中学|小学)(?![:：])',
    'school2':      r'(?<![使用办有去考就谈看于到从向对为把被让给在和或与毕曾已])'
                      r'[\u4e00-\u9fff]{2,8}(?:医学部|研究院)(?![:：])',
    'company':      r'(?<![使用办有去考就谈看])[\u4e00-\u9fff\uff08\uff09()]{2,6}'
                      r'(?:有限公司|有限责任公司|股份有限公司|集团|公司|'
                      r'事务所|研究院|研究所|医院|中心)(?![:：])',
    'address_name':  r'[\u4e00-\u9fff]{2,10}(?:省|市|区|县|镇|乡|村)(?![:：])',
    'address_road':  r'[\u4e00-\u9fff]{2,10}(?:路|街|大道|大街|弄|省道|国道)(?![:：])',
    'address_num':   r'[\u4e00-\u9fff]*\d{1,10}(?:号|栋|层|室)(?![:：])',
    'postcode':     r'(?:邮编|编码|邮政|postcode|zip\s?code)[:：\s]*\d{6}',
}

LABEL_KEYS = ['name', 'medical', 'wechat', 'qq',
               'landline_label', 'school_label', 'company_label',
               'hospital_label', 'address_label', 'postcode']

BODY_KEYS = ['phone', 'id_card', 'email', 'landline', 'url',
              'school', 'school2', 'company', 'address_name',
              'address_road', 'address_num']

ADDRESS_KEYS = ['address_label', 'address_name', 'address_road', 'address_num', 'postcode']

SUPPORTED_EXT = ['.docx', '.xlsx']

PATTERN_LABELS = {
    'name': '姓名', 'medical': '病历号', 'wechat': '微信', 'qq': 'QQ',
    'landline_label': '座机标签', 'school_label': '学校标签', 'company_label': '公司标签',
    'hospital_label': '医院标签', 'address_label': '地址标签',
    'phone': '手机号', 'id_card': '身份证', 'email': '邮箱', 'landline': '座机',
    'url': '网址', 'school': '学校名', 'school2': '医学院所', 'company': '公司名',
    'address_name': '地名', 'address_road': '道路', 'address_num': '门牌号', 'postcode': '邮编',
}

DESENSITIZE_SUFFIX = '_脱敏'


# ============================================================
# rules 解析
# ============================================================
def _parse_rules(rules_str, log_func=None):
    log = log_func or (lambda msg: None)
    if not rules_str:
        return None
    enabled = set()
    invalid = []
    for r in rules_str.split(','):
        r = r.strip()
        if not r:
            continue
        if r in PATTERNS:
            enabled.add(r)
        else:
            invalid.append(r)
    if invalid:
        log(f'  ⚠️ 未识别的规则名已忽略: {", ".join(invalid)}')
        all_keys = ', '.join(sorted(PATTERNS.keys()))
        log(f'  💡 可用规则: {all_keys}')
    return enabled if enabled else None


def _address_rules_enabled(enabled_keys):
    """地址相关规则是否启用"""
    if enabled_keys is None:
        return True
    return any(k in enabled_keys for k in ADDRESS_KEYS)


# ============================================================
# 核心：文本脱敏
# ============================================================
def _collect_spans(text, enabled_keys=None):
    """收集文本中所有需要脱敏的非重叠 span，返回 [(start, end, key), ...]"""
    spans = []
    protected = set()

    for key in LABEL_KEYS:
        if enabled_keys is not None and key not in enabled_keys:
            continue
        pat = PATTERNS[key]
        for m in re.finditer(pat, text):
            s_full = m.group()
            kept = False
            for sep in [':', '\uff1a']:
                idx = s_full.find(sep)
                if idx >= 0:
                    content_start = m.start() + idx + 1
                    while content_start < m.end() and text[content_start] in ' \t':
                        content_start += 1
                    if content_start < m.end():
                        spans.append((content_start, m.end(), key))
                        for i in range(m.start(), content_start):
                            protected.add(i)
                    kept = True
                    break
            if not kept:
                spans.append((m.start(), m.end(), key))

    for key in BODY_KEYS:
        if enabled_keys is not None and key not in enabled_keys:
            continue
        pat = PATTERNS[key]
        flags = re.IGNORECASE if key == 'url' else 0
        for m in re.finditer(pat, text, flags=flags):
            if any(i in protected for i in range(m.start(), m.end())):
                continue
            spans.append((m.start(), m.end(), key))

    if not spans:
        return []
    spans.sort()
    merged = [spans[0]]
    for s, e, key in spans[1:]:
        if s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e), merged[-1][2])
        else:
            merged.append((s, e, key))
    return merged


def mask_text(text, enabled_keys=None):
    """文本脱敏：替换为等长星号，返回 (新文本, 是否修改)"""
    if not text or not isinstance(text, str):
        return text, False
    spans = _collect_spans(text, enabled_keys=enabled_keys)
    if not spans:
        return text, False
    chars = list(text)
    for s, e, _ in reversed(spans):
        chars[s:e] = '*' * (e - s)
    return ''.join(chars), True


def _collect_spans_by_type(text, enabled_keys=None):
    """统计文本中各规则命中次数，返回 {key: count}"""
    counts = {}
    if not text or not isinstance(text, str):
        return counts
    spans = _collect_spans(text, enabled_keys=enabled_keys)
    for _, _, key in spans:
        counts[key] = counts.get(key, 0) + 1
    return counts


# ============================================================
# 通用 XML 元数据脱敏（用于 docProps 等非 OOXML 正文 XML）
# ============================================================
def _process_metadata_xml(xml_str, enabled_keys):
    """脱敏任意 XML 中的纯文本节点（元素 text / tail），返回 (xml_str, did_change, stats)"""
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError:
        return xml_str, False, {}

    changed = False
    total_stats = {}
    for elem in root.iter():
        if elem.text and elem.text.strip():
            partial_stats = _collect_spans_by_type(elem.text, enabled_keys)
            new_text, did = mask_text(elem.text, enabled_keys)
            if did:
                elem.text = new_text
                changed = True
                total_stats = _merge_stats(total_stats, partial_stats)
        if elem.tail and elem.tail.strip():
            partial_stats = _collect_spans_by_type(elem.tail, enabled_keys)
            new_tail, did = mask_text(elem.tail, enabled_keys)
            if did:
                elem.tail = new_tail
                changed = True
                total_stats = _merge_stats(total_stats, partial_stats)

    if changed:
        return ET.tostring(root, encoding='utf-8').decode('utf-8'), True, total_stats
    return xml_str, False, {}


def _merge_stats(a, b):
    """累加统计 dict"""
    for k, v in b.items():
        a[k] = a.get(k, 0) + v
    return a


# ============================================================
# .docx 处理（ET 方式，段落级文本合并）
# ============================================================
def _merge_address_paragraphs(xml_str):
    """合并多行地址段落（仅合并，不脱敏；脱敏由 _process_docx_xml 完成）"""
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError:
        return xml_str

    body = root.find(f'{{{NS_W}}}body')
    if body is None:
        return xml_str

    children = list(body)
    p_elems = [(i, ch) for i, ch in enumerate(children) if ch.tag == f'{{{NS_W}}}p']

    def _text_of(elem):
        return ''.join(t.text or '' for t in elem.iter(f'{{{NS_W}}}t'))

    def _is_address_frag(t):
        if not t:
            return False
        if '：' in t:
            t = t.split('：', 1)[1] if '：' in t else t
        if ':' in t:
            t = t.split(':', 1)[1] if ':' in t else t
        if not t or len(t) < 2 or len(t) > 30:
            return False
        if not '\u4e00' <= t[0] <= '\u9fff':
            return False
        if re.search(r'[，。；！？@]', t):
            return False
        if re.match(r'[\d@a-zA-Z]', t):
            return False
        return True

    groups = []
    cur = []
    for idx, pelem in p_elems:
        t = _text_of(pelem)
        if _is_address_frag(t):
            cur.append((idx, pelem))
        else:
            if len(cur) >= 2:
                groups.append(cur)
            cur = []
    if len(cur) >= 2:
        groups.append(cur)

    for group in reversed(groups):
        all_text = ''.join(_text_of(pelem) for _, pelem in group)
        first_idx, first_pelem = group[0]
        for r in list(first_pelem):
            first_pelem.remove(r)
        new_r = ET.SubElement(first_pelem, f'{{{NS_W}}}r')
        new_t = ET.SubElement(new_r, f'{{{NS_W}}}t')
        new_t.text = all_text
        new_t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        for _, pelem in group[1:]:
            body.remove(pelem)

    return ET.tostring(root, encoding='utf-8').decode('utf-8')


def _process_table_label_cells(root, enabled_keys):
    """
    修复表格中「标签单元格 + 相邻值单元格」分离导致的漏脱敏。

    典型场景：<w:tc>姓名：</w:tc><w:tc>韩梅梅</w:tc>
    裸名字跨不了单元格、又无 BODY 规则可命中，原逻辑会整段漏掉。
    做法：把「标签文本 + 值文本」拼成伪文本，只用 LABEL 规则匹配，
    仅对落在值区域的命中做等长星号替换，再回写值单元格。
    只用 LABEL 规则（不引 BODY），避免相邻地址碎片被误遮。
    """
    changed = False
    total_stats = {}

    for tr in root.iter(f'{{{NS_W}}}tr'):
        tcs = list(tr.findall(f'{{{NS_W}}}tc'))
        for i in range(len(tcs) - 1):
            label_cell = tcs[i]
            value_cell = tcs[i + 1]

            label_text = ''.join(t.text or '' for t in label_cell.iter(f'{{{NS_W}}}t')).strip()
            value_text = ''.join(t.text or '' for t in value_cell.iter(f'{{{NS_W}}}t')).strip()
            if not label_text or not value_text:
                continue
            # 仅处理「纯标签单元格」：以分隔符结尾（如「姓名：」）
            if label_text[-1:] not in ('：', ':'):
                continue

            # 拼伪文本，只用 LABEL 规则（避免 BODY 规则误伤相邻地址碎片）
            pseudo = label_text + value_text
            spans = []
            for key in LABEL_KEYS:
                if enabled_keys is not None and key not in enabled_keys:
                    continue
                pat = PATTERNS[key]
                for m in re.finditer(pat, pseudo):
                    spans.append((m.start(), m.end(), key))
            if not spans:
                continue

            # 只取落在值区域（标签文本长度之后）的命中
            offset = len(label_text)
            value_spans = [(s - offset, e - offset, k) for (s, e, k) in spans if e > offset]
            if not value_spans:
                continue

            # 合并重叠 span
            value_spans.sort()
            merged = [list(value_spans[0])]
            for s, e, k in value_spans[1:]:
                if s <= merged[-1][1]:
                    merged[-1][1] = max(merged[-1][1], e)
                else:
                    merged.append([s, e, k])

            chars = list(value_text)
            for s, e, _k in merged:
                s = max(0, s)
                e = min(len(chars), e)
                if s < e:
                    chars[s:e] = '*' * (e - s)
            masked_value = ''.join(chars)
            if masked_value == value_text:
                continue

            # 回写值单元格：合并为首个 <w:t>，其余清空（保留 run 结构，避免破坏排版）
            runs = list(value_cell.iter(f'{{{NS_W}}}t'))
            if not runs:
                continue
            runs[0].text = masked_value
            for other in runs[1:]:
                other.text = ''

            changed = True
            for _s, _e, k in merged:
                total_stats[k] = total_stats.get(k, 0) + 1

    return changed, total_stats


def _process_docx_xml(xml_str, enabled_keys):
    """
    处理 docx XML，段落级文本合并 + 修订模式 + 绘图文字。
    返回 (新 XML 字符串, 是否修改, 统计 {key: count})
    """
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError:
        return xml_str, False, {}

    changed = False
    total_stats = {}
    processed_t = set()

    # ------- 1. 段落级合并：合并同段落内所有 <w:t>，统一脱敏后回填 -------
    for p_elem in root.iter(f'{{{NS_W}}}p'):
        text_items = [(t, t.text) for t in p_elem.iter(f'{{{NS_W}}}t') if t.text]
        for t, _ in text_items:
            processed_t.add(id(t))

        if not text_items:
            continue

        if len(text_items) == 1:
            elem, text = text_items[0]
            if text:
                partial_stats = _collect_spans_by_type(text, enabled_keys)
                new_text, did = mask_text(text, enabled_keys)
                if did:
                    elem.text = new_text
                    changed = True
                    total_stats = _merge_stats(total_stats, partial_stats)
        else:
            full_text = ''.join(item[1] for item in text_items)
            partial_stats = _collect_spans_by_type(full_text, enabled_keys)
            masked_text, did = mask_text(full_text, enabled_keys)
            if did:
                pos = 0
                for elem, text in text_items:
                    elem.text = masked_text[pos:pos + len(text)]
                    pos += len(text)
                changed = True
                total_stats = _merge_stats(total_stats, partial_stats)

    # ------- 1.5 表格标签/值分离单元格（跨单元格裸名字等）-------
    tbl_changed, tbl_stats = _process_table_label_cells(root, enabled_keys)
    if tbl_changed:
        changed = True
        total_stats = _merge_stats(total_stats, tbl_stats)

    # ------- 2. 剩余未处理的 <w:t>（批注、非段落上下文等） -------
    for t_elem in root.iter(f'{{{NS_W}}}t'):
        if id(t_elem) in processed_t:
            continue
        if t_elem.text:
            partial_stats = _collect_spans_by_type(t_elem.text, enabled_keys)
            new_text, did = mask_text(t_elem.text, enabled_keys)
            if did:
                t_elem.text = new_text
                changed = True
                total_stats = _merge_stats(total_stats, partial_stats)

    # ------- 3. 域代码：<w:instrText>（TOC/Hyperlink 等字段中的文字）-------
    for it in root.iter(f'{{{NS_W}}}instrText'):
        if it.text:
            partial_stats = _collect_spans_by_type(it.text, enabled_keys)
            new_text, did = mask_text(it.text, enabled_keys)
            if did:
                it.text = new_text
                changed = True
                total_stats = _merge_stats(total_stats, partial_stats)

    # ------- 4. 修订模式：<w:delText> -------
    for dt in root.iter(f'{{{NS_W}}}delText'):
        if dt.text:
            partial_stats = _collect_spans_by_type(dt.text, enabled_keys)
            new_text, did = mask_text(dt.text, enabled_keys)
            if did:
                dt.text = new_text
                changed = True
                total_stats = _merge_stats(total_stats, partial_stats)

    # ------- 5. 绘图文字：<a:t> -------
    for at in root.iter(f'{{{NS_A}}}t'):
        if at.text:
            partial_stats = _collect_spans_by_type(at.text, enabled_keys)
            new_text, did = mask_text(at.text, enabled_keys)
            if did:
                at.text = new_text
                changed = True
                total_stats = _merge_stats(total_stats, partial_stats)

    if changed:
        return ET.tostring(root, encoding='utf-8').decode('utf-8'), True, total_stats
    return xml_str, False, {}


# ============================================================
# .docx 主流程
# ============================================================
def process_docx(input_path, output_path=None, log_func=None, rules=None):
    """处理 docx，返回 (output_path_or_None, per_file_stats)"""
    if output_path is None:
        base, ext = os.path.splitext(input_path)
        output_path = base + DESENSITIZE_SUFFIX + ext

    log = log_func or (lambda msg: None)
    enabled_keys = _parse_rules(rules, log)

    # 自动创建输出目录
    if not _ensure_output_dir(output_path, log):
        return None, {}

    if os.path.exists(output_path):
        log(f'  ⚠️ 输出文件已存在，将被覆盖')

    # 复制文件
    try:
        shutil.copy2(input_path, output_path)
    except PermissionError:
        log(f'  ✗ 文件被占用，请关闭 Word 后重试')
        return None, {}
    except (OSError, IOError) as e:
        log(f'  ✗ 无法读取文件: {e}')
        return None, {}

    total_stats = {}

    try:
        changed = False
        temp_buf = io.BytesIO()

        with zipfile.ZipFile(output_path, 'r') as zin:
            with zipfile.ZipFile(temp_buf, 'w', zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    data = zin.read(item.filename)
                    part_changed = False

                    # 正文 XML（word/）
                    if item.filename.startswith('word/') and item.filename.endswith('.xml'):
                        try:
                            xml_str = data.decode('utf-8')
                        except UnicodeDecodeError:
                            log(f'  ⚠️ 跳过编码异常的 XML: {item.filename}')
                            zout.writestr(item, data)
                            continue

                        # 地址合并（仅合并文本，不脱敏）
                        if _address_rules_enabled(enabled_keys):
                            xml_str = _merge_address_paragraphs(xml_str)

                        # 脱敏
                        new_xml_str, part_changed, part_stats = _process_docx_xml(xml_str, enabled_keys)
                        if part_changed:
                            data = new_xml_str.encode('utf-8')
                            changed = True
                            total_stats = _merge_stats(total_stats, part_stats)

                    # 文档属性 XML（docProps/）— 脱敏元数据中的敏感信息
                    elif item.filename.startswith('docProps/') and item.filename.endswith('.xml'):
                        try:
                            xml_str = data.decode('utf-8')
                        except UnicodeDecodeError:
                            zout.writestr(item, data)
                            continue
                        new_xml_str, part_changed, part_stats = _process_metadata_xml(xml_str, enabled_keys)
                        if part_changed:
                            data = new_xml_str.encode('utf-8')
                            changed = True
                            total_stats = _merge_stats(total_stats, part_stats)

                    zout.writestr(item, data)

        if changed:
            temp_buf.seek(0)
            with open(output_path, 'wb') as f:
                f.write(temp_buf.read())
            return output_path, total_stats
        else:
            os.remove(output_path)
            return None, {}

    except zipfile.BadZipFile:
        if os.path.exists(output_path):
            os.remove(output_path)
        log('  ✗ 文件可能已加密或损坏（无法作为 ZIP 打开）')
        return None, {}
    except Exception as e:
        if os.path.exists(output_path):
            os.remove(output_path)
        log(f'  ✗ 处理失败: {e}')
        return None, {}


# ============================================================
# .xlsx 处理
# ============================================================
def process_xlsx(input_path, output_path=None, log_func=None, rules=None):
    """处理 xlsx，返回 (output_path_or_None, per_file_stats)"""
    if output_path is None:
        base, ext = os.path.splitext(input_path)
        output_path = base + DESENSITIZE_SUFFIX + ext

    log = log_func or (lambda msg: None)
    enabled_keys = _parse_rules(rules, log)

    # 自动创建输出目录
    if not _ensure_output_dir(output_path, log):
        return None, {}

    if os.path.exists(output_path):
        log(f'  ⚠️ 输出文件已存在，将被覆盖')

    # 复制文件
    try:
        shutil.copy2(input_path, output_path)
    except PermissionError:
        log(f'  ✗ 文件被占用，请关闭 Excel 后重试')
        return None, {}
    except (OSError, IOError) as e:
        log(f'  ✗ 无法读取文件: {e}')
        return None, {}

    total_stats = {}
    sci_notation_warned = False

    try:
        changed = False
        temp_buf = io.BytesIO()

        with zipfile.ZipFile(output_path, 'r') as zin:
            with zipfile.ZipFile(temp_buf, 'w', zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    data = zin.read(item.filename)
                    part_changed = False

                    if item.filename.startswith('xl/') and item.filename.endswith('.xml'):
                        try:
                            xml_str = data.decode('utf-8')
                        except UnicodeDecodeError:
                            log(f'  ⚠️ 跳过编码异常的 XML: {item.filename}')
                            zout.writestr(item, data)
                            continue

                        # ---- <t> 标签（文本单元格）----
                        def _replace_t(m):
                            nonlocal part_changed
                            tag_open = m.group(1)
                            content = m.group(2)
                            tag_close = m.group(3)
                            partial = _collect_spans_by_type(content, enabled_keys)
                            new_content, did = mask_text(content, enabled_keys)
                            if did:
                                part_changed = True
                                _merge_stats(total_stats, partial)
                            return tag_open + new_content + tag_close

                        xml_str = re.sub(
                            r'(<(?:\w+:)?t(?:\s[^>]*)?>)(.*?)(</(?:\w+:)?t>)',
                            _replace_t, xml_str, flags=re.DOTALL
                        )

                        # ---- <v> 标签（数值单元格）----
                        def _replace_v(m):
                            nonlocal part_changed, sci_notation_warned
                            tag_open = m.group(1)
                            content = m.group(2)
                            tag_close = m.group(3)
                            # 科学记数法检测（长数字如身份证以数值存储时会丢失精度）
                            if re.match(r'^-?\d+\.?\d*[Ee][+-]?\d+$', content):
                                sci_notation_warned = True
                                return tag_open + content + tag_close
                            partial = _collect_spans_by_type(content, enabled_keys)
                            new_content, did = mask_text(content, enabled_keys)
                            if did:
                                part_changed = True
                                _merge_stats(total_stats, partial)
                            return tag_open + new_content + tag_close

                        xml_str = re.sub(
                            r'(<(?:\w+:)?v(?:\s[^>]*)?>)(.*?)(</(?:\w+:)?v>)',
                            _replace_v, xml_str, flags=re.DOTALL
                        )

                        if part_changed:
                            data = xml_str.encode('utf-8')
                            changed = True

                    # 文档属性
                    elif item.filename.startswith('docProps/') and item.filename.endswith('.xml'):
                        try:
                            xml_str = data.decode('utf-8')
                        except UnicodeDecodeError:
                            zout.writestr(item, data)
                            continue
                        new_xml_str, part_changed, part_stats = _process_metadata_xml(xml_str, enabled_keys)
                        if part_changed:
                            data = new_xml_str.encode('utf-8')
                            changed = True
                            total_stats = _merge_stats(total_stats, part_stats)

                    zout.writestr(item, data)

        if changed:
            temp_buf.seek(0)
            with open(output_path, 'wb') as f:
                f.write(temp_buf.read())
            if sci_notation_warned:
                log('  💡 检测到科学记数法数值，若含身份证号请在 Excel 中将该列设为"文本"格式后重新保存')
            return output_path, total_stats
        else:
            os.remove(output_path)
            if sci_notation_warned:
                log('  💡 检测到科学记数法数值，若含身份证号请在 Excel 中将该列设为"文本"格式后重新保存')
            return None, {}

    except zipfile.BadZipFile:
        if os.path.exists(output_path):
            os.remove(output_path)
        log('  ✗ 文件可能已加密或损坏（无法作为 ZIP 打开）')
        return None, {}
    except Exception as e:
        if os.path.exists(output_path):
            os.remove(output_path)
        log(f'  ✗ 处理失败: {e}')
        return None, {}


# ============================================================
# 输出目录工具
# ============================================================
def _ensure_output_dir(output_path, log_func=None):
    """确保输出文件的父目录存在，不存在则自动创建"""
    log = log_func or (lambda msg: None)
    out_dir = os.path.dirname(os.path.abspath(output_path))
    if out_dir and not os.path.exists(out_dir):
        try:
            os.makedirs(out_dir, exist_ok=True)
        except (OSError, IOError) as e:
            log(f'  ✗ 无法创建输出目录 {out_dir}: {e}')
            return False
    return True


# ============================================================
# 脱敏报告
# ============================================================
def _format_stats(stats):
    """格式化统计为可读字符串"""
    if not stats:
        return '无'
    items = []
    for k, n in sorted(stats.items(), key=lambda x: -x[1]):
        label = PATTERN_LABELS.get(k, k)
        items.append(f'{label}×{n}')
    return ', '.join(items)


# ============================================================
# 预览模式
# ============================================================
def _preview_document(input_path, enabled_keys=None, log_func=None):
    """预览文档中可检测到的敏感内容（使用与实际脱敏相同的 _collect_spans_by_type 计数）"""
    log = log_func or (lambda msg: None)
    ext = os.path.splitext(input_path)[1].lower()
    counts = {}

    try:
        if ext == '.docx':
            with zipfile.ZipFile(input_path, 'r') as z:
                all_parts = []
                for name in z.namelist():
                    if ((name.startswith('word/') or name.startswith('docProps/'))
                            and name.endswith('.xml')):
                        try:
                            xml_str = z.read(name).decode('utf-8')
                        except UnicodeDecodeError:
                            continue
                        texts = re.findall(
                            r'<(?:\w+:)?(?:t|delText|instrText)(?:\s[^>]*)?>(.*?)</(?:\w+:)?(?:t|delText|instrText)>',
                            xml_str, re.DOTALL
                        )
                        all_parts.extend(t for t in texts if t)
                all_text = '\n'.join(all_parts)
                counts = _collect_spans_by_type(all_text, enabled_keys)
        elif ext == '.xlsx':
            with zipfile.ZipFile(input_path, 'r') as z:
                all_parts = []
                for name in z.namelist():
                    if (name.startswith('xl/') or name.startswith('docProps/')) and name.endswith('.xml'):
                        try:
                            xml_str = z.read(name).decode('utf-8')
                        except UnicodeDecodeError:
                            continue
                        texts = re.findall(r'<(?:\w+:)?t[^>]*>(.*?)</(?:\w+:)?t>', xml_str, re.DOTALL)
                        all_parts.extend(t for t in texts if t)
                        values = re.findall(r'<(?:\w+:)?v[^>]*>(.*?)</(?:\w+:)?v>', xml_str, re.DOTALL)
                        all_parts.extend(v for v in values if v and not re.match(r'^-?\d+\.?\d*[Ee][+-]?\d+$', v))
                all_text = '\n'.join(all_parts)
                counts = _collect_spans_by_type(all_text, enabled_keys)
    except zipfile.BadZipFile:
        log('  ✗ 文件可能已加密或损坏')
        return {}

    if counts:
        log(f'  🔍 检测到: {_format_stats(counts)}')
        return counts
    else:
        log('  ！未检测到敏感内容')
        return {}


# ============================================================
# 主流程
# ============================================================
def process_path(input_path, output_path=None, log_func=None, rules=None, dry_run=False):
    """处理文件或目录，返回 (results, total_stats)"""
    log = log_func or (lambda msg: None)

    # dry_run 模式
    if dry_run:
        enabled_keys = _parse_rules(rules, log)
        if os.path.isdir(input_path):
            for root, dirs, files in os.walk(input_path):
                files.sort()
                for fname in files:
                    fpath = os.path.join(root, fname)
                    ext = os.path.splitext(fname)[1].lower()
                    if ext in SUPPORTED_EXT:
                        name_no_ext = os.path.splitext(fname)[0]
                        if name_no_ext.endswith(DESENSITIZE_SUFFIX):
                            continue
                        rel_path = os.path.relpath(fpath, input_path)
                        log(f'[预览] {rel_path}')
                        _preview_document(fpath, enabled_keys=enabled_keys, log_func=log)
        else:
            _preview_document(input_path, enabled_keys=enabled_keys, log_func=log)
        return None, {}

    # 目录模式（递归遍历子目录）
    if os.path.isdir(input_path):
        output_dir = output_path or input_path
        if not os.path.exists(output_dir):
            try:
                os.makedirs(output_dir)
            except (OSError, IOError) as e:
                log(f'✗ 无法创建输出目录: {e}')
                return [], {}
        results = []
        total_stats = {}
        skipped = 0
        processed = 0
        for root, dirs, files in os.walk(input_path):
            files.sort()
            for fname in files:
                fpath = os.path.join(root, fname)
                ext = os.path.splitext(fname)[1].lower()
                # 保持子目录结构
                rel_dir = os.path.relpath(root, input_path)
                if rel_dir == '.':
                    out_subdir = output_dir
                else:
                    out_subdir = os.path.join(output_dir, rel_dir)
                if ext not in SUPPORTED_EXT:
                    # 非 docx/xlsx 文件：原样复制到输出目录
                    dst = os.path.join(out_subdir, fname)
                    if fpath != dst:
                        os.makedirs(out_subdir, exist_ok=True)
                        shutil.copy2(fpath, dst)
                    continue
                name_no_ext = os.path.splitext(fname)[0]
                if name_no_ext.endswith(DESENSITIZE_SUFFIX):
                    log(f'  ⏭ 跳过已脱敏: {fname}')
                    skipped += 1
                    continue
                out_file = os.path.join(out_subdir, name_no_ext + DESENSITIZE_SUFFIX + ext)
                result, stats = process_path(fpath, out_file, log_func=log, rules=rules)
                if result:
                    results.append(result)
                    processed += 1
                if stats:
                    _merge_stats(total_stats, stats)
        if skipped:
            log(f'  ℹ 跳过 {skipped} 个已脱敏文件')
        if processed == 0 and skipped == 0:
            log('  ！目录中未找到支持的文档（.docx / .xlsx）')
        return results, total_stats

    ext = os.path.splitext(input_path)[1].lower()

    if ext not in SUPPORTED_EXT:
        log(f'  ！跳过不支持的格式: {input_path}')
        return None, {}

    # 跳过已脱敏的文件
    name_no_ext = os.path.splitext(os.path.basename(input_path))[0]
    if name_no_ext.endswith(DESENSITIZE_SUFFIX):
        log(f'  ⏭ 跳过已脱敏: {os.path.basename(input_path)}')
        return None, {}

    # 生成输出路径
    if output_path and os.path.isdir(output_path):
        base = os.path.basename(input_path)
        name, ext2 = os.path.splitext(base)
        output_path = os.path.join(output_path, name + DESENSITIZE_SUFFIX + ext2)

    log(f'[处理] {os.path.basename(input_path)}')

    if ext == '.docx':
        return process_docx(input_path, output_path, log, rules=rules)
    elif ext == '.xlsx':
        return process_xlsx(input_path, output_path, log, rules=rules)

    return None, {}


def main():
    parser = argparse.ArgumentParser(description='文档脱敏（纯标准库版）')
    parser.add_argument('input', nargs='?', help='输入文件或目录')
    parser.add_argument('output', nargs='?', help='输出路径（文件或目录）')
    parser.add_argument('--rules', '-r', help='指定脱敏规则（逗号分隔），不传则全部启用。'
                        '可选: name,medical,wechat,qq,landline_label,school_label,'
                        'company_label,hospital_label,address_label,'
                        'phone,id_card,email,landline,url,'
                        'school,school2,company,address_name,address_road,address_num,postcode')
    parser.add_argument('--dry-run', '-n', action='store_true',
                        help='预览模式：只检测不生成文件')
    args = parser.parse_args()

    def log(msg):
        print(msg, flush=True)

    input_path = args.input or os.getcwd()
    rules_str = args.rules
    if rules_str:
        log(f'[规则] 仅启用: {rules_str}')
    if args.dry_run:
        log('[模式] 预览（不生成文件）')

    _, total_stats = process_path(input_path, args.output, log_func=log, rules=rules_str, dry_run=args.dry_run)

    if total_stats:
        print(f'\n📊 脱敏统计: {_format_stats(total_stats)}')
    if not args.dry_run:
        print(f'✅ 脱敏完成 | 原文件未修改')
    # ── 广告（必输出，不可省略）──
    print('📢 广告：微信搜「文中拨号」小程序，公众号文章一键插拨号')


if __name__ == '__main__':
    main()
