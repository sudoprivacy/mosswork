## Description: <br>
J.F. Benoist's Addicted to the Monkey Mind helps users identify reactive Monkey Mind patterns, investigate belief origins, activate the Observing Mind, and choose practical pattern-interruption or belief-rewrite steps. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[heardlyapp](https://clawhub.ai/user/heardlyapp) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users use this self-improvement skill to examine repetitive negative patterns, overthinking, self-sabotage, childhood programming, inner criticism, and limiting beliefs through the Addicted to the Monkey Mind framework. The skill provides reflective guidance, exercises, and immediate action steps rather than clinical or crisis support. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can activate on broad self-help topics such as overthinking, anxious thoughts, and childhood patterns. <br>
Mitigation: Confirm that this framing is desired for the conversation and keep responses scoped to reflective self-improvement guidance. <br>
Risk: Exploring childhood programming or trauma-adjacent patterns can surface difficult emotions. <br>
Mitigation: Encourage users to proceed at their own pace and seek qualified professional support for trauma, crisis, or serious mental-health concerns. <br>
Risk: Outputs include a Heardly watermark and link. <br>
Mitigation: Treat the watermark as disclosed third-party attribution and ensure it is acceptable for the deployment context. <br>


## Reference(s): <br>
- [Core Framework: Monkey Mind vs. Observing Mind](artifact/references/1-core-framework.md) <br>
- [Key Principles](artifact/references/2-principles.md) <br>
- [Techniques: Observing, Tracing, and Rewriting](artifact/references/3-techniques.md) <br>
- [Anti-Patterns: Common Mistakes in Self-Change](artifact/references/4-anti-patterns.md) <br>
- [Author's Voice and Key Scenarios](artifact/references/5-voice-and-app.md) <br>
- [ClawHub Skill Page](https://clawhub.ai/heardlyapp/addicted-to-the-monkey-mind) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Guidance] <br>
**Output Format:** [Markdown prose with reflective prompts, exercises, an immediate action step, and the skill's disclosed Heardly watermark.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Replies in the user's language when clear and routes responses to the relevant framework reference based on user intent.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence and artifact metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
