"""
配置常量：精灵图尺寸、动画状态、方向注视等。
"""

# 精灵图规格
CELL_WIDTH = 192
CELL_HEIGHT = 208
COLS = 8
ROWS = 11
ATLAS_WIDTH = CELL_WIDTH * COLS   # 1536
ATLAS_HEIGHT = CELL_HEIGHT * ROWS  # 2288

# 宠物配置
SPRITE_VERSION_NUMBER = 2
DEFAULT_FPS = 6
DEFAULT_FRAME_COUNT = 8

# 通用桌面模式
CODEC_COMPAT = True  # True=Codex 格式, False=通用格式

# 9 个标准动画状态行（对应精灵图行索引 0-8）
ANIMATION_STATES = [
    {"name": "idle",          "row": 0, "label": "待机",     "repeat": True,  "fps": 4},
    {"name": "running-right", "row": 1, "label": "向右跑",    "repeat": True,  "fps": 8},
    {"name": "running-left",  "row": 2, "label": "向左跑",    "repeat": True,  "fps": 8},
    {"name": "waving",        "row": 3, "label": "挥手",     "repeat": True,  "fps": 6},
    {"name": "jumping",       "row": 4, "label": "跳跃",     "repeat": False, "fps": 6},
    {"name": "failed",        "row": 5, "label": "失败",     "repeat": False, "fps": 4},
    {"name": "waiting",       "row": 6, "label": "等待",     "repeat": True,  "fps": 4},
    {"name": "running",       "row": 7, "label": "工作中",    "repeat": True,  "fps": 6},
    {"name": "review",        "row": 8, "label": "审阅",     "repeat": True,  "fps": 6},
]

# 额外的 16 方向注视（行索引 9-10，列索引 0-7 每行各 8 个方向）
GAZE_DIRECTIONS = [
    # 行 9: 索引 0-7
    {"name": "gaze-000",     "row": 9,  "col": 0, "angle": 0.0,   "label": "up"},
    {"name": "gaze-022.5",   "row": 9,  "col": 1, "angle": 22.5,  "label": "up-right"},
    {"name": "gaze-045",     "row": 9,  "col": 2, "angle": 45.0,  "label": "up-right"},
    {"name": "gaze-067.5",   "row": 9,  "col": 3, "angle": 67.5,  "label": "up-right"},
    {"name": "gaze-090",     "row": 9,  "col": 4, "angle": 90.0,  "label": "right"},
    {"name": "gaze-112.5",   "row": 9,  "col": 5, "angle": 112.5, "label": "down-right"},
    {"name": "gaze-135",     "row": 9,  "col": 6, "angle": 135.0, "label": "down-right"},
    {"name": "gaze-157.5",   "row": 9,  "col": 7, "angle": 157.5, "label": "down-right"},
    # 行 10: 索引 0-7
    {"name": "gaze-180",     "row": 10, "col": 0, "angle": 180.0, "label": "down"},
    {"name": "gaze-202.5",   "row": 10, "col": 1, "angle": 202.5, "label": "down-left"},
    {"name": "gaze-225",     "row": 10, "col": 2, "angle": 225.0, "label": "down-left"},
    {"name": "gaze-247.5",   "row": 10, "col": 3, "angle": 247.5, "label": "down-left"},
    {"name": "gaze-270",     "row": 10, "col": 4, "angle": 270.0, "label": "left"},
    {"name": "gaze-292.5",   "row": 10, "col": 5, "angle": 292.5, "label": "up-left"},
    {"name": "gaze-315",     "row": 10, "col": 6, "angle": 315.0, "label": "up-left"},
    {"name": "gaze-337.5",   "row": 10, "col": 7, "angle": 337.5, "label": "up-left"},
]
