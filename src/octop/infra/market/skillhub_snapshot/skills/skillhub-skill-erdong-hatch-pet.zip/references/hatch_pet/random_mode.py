"""
Random Mode — 随机行为模式

宠物自主行为系统：随机切换动画、随机移动、随机互动效果。
支持多模式组合（调皮/悠闲/好奇/活跃），可配置触发间隔和概率。
"""

import logging
import math
import random
import time
from typing import Optional, Callable

from .config import ANIMATION_STATES

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════
#  行为模式预设
# ═══════════════════════════════════════════

BEHAVIOR_PRESETS = {
    "playful": {
        "name": "调皮模式",
        "description": "频繁跑动、跳跃、挥手",
        "anim_weights": {
            "idle": 15,
            "running-right": 25,
            "running-left": 25,
            "waving": 15,
            "jumping": 20,
            "failed": 0,
            "waiting": 0,
            "running": 0,
            "review": 0,
        },
        "move_probability": 0.4,
        "jump_probability": 0.15,
        "interaction_interval": (5, 20),
    },
    "relaxed": {
        "name": "悠闲模式",
        "description": "主要是待机，偶尔挥手看看",
        "anim_weights": {
            "idle": 50,
            "running-right": 5,
            "running-left": 5,
            "waving": 15,
            "jumping": 5,
            "failed": 0,
            "waiting": 10,
            "running": 5,
            "review": 5,
        },
        "move_probability": 0.1,
        "jump_probability": 0.03,
        "interaction_interval": (15, 60),
    },
    "curious": {
        "name": "好奇模式",
        "description": "到处探索，看向各个方向",
        "anim_weights": {
            "idle": 10,
            "running-right": 30,
            "running-left": 30,
            "waving": 10,
            "jumping": 10,
            "failed": 0,
            "waiting": 5,
            "running": 5,
            "review": 0,
        },
        "move_probability": 0.6,
        "jump_probability": 0.1,
        "interaction_interval": (3, 12),
    },
    "active": {
        "name": "活跃模式",
        "description": "忙碌工作、审阅、不断活动",
        "anim_weights": {
            "idle": 5,
            "running-right": 15,
            "running-left": 15,
            "waving": 10,
            "jumping": 10,
            "failed": 5,
            "waiting": 5,
            "running": 20,
            "review": 15,
        },
        "move_probability": 0.35,
        "jump_probability": 0.12,
        "interaction_interval": (3, 10),
    },
}


# ═══════════════════════════════════════════
#  随机行为引擎
# ═══════════════════════════════════════════

class RandomBehaviorEngine:
    """随机行为引擎：管理宠物的自主行为。

    可以：
    - 定时随机切换动画
    - 在屏幕范围内随机移动
    - 随机触发特效（跳跃、粒子等）
    """

    def __init__(self,
                 preset: str = "playful",
                 screen_width: int = 1920,
                 screen_height: int = 1080,
                 pet_width: int = 192,
                 pet_height: int = 208,
                 on_anim_change: Optional[Callable] = None,
                 on_move: Optional[Callable] = None):
        """
        Args:
            preset: 行为预设名称
            screen_width/height: 屏幕尺寸
            pet_width/height: 宠物尺寸
            on_anim_change: 动画切换回调 (anim_name)
            on_move: 移动回调 (x, y)
            on_effect: 特效回调 (effect_type)
        """
        self.set_preset(preset)
        self.screen_w = screen_width
        self.screen_h = screen_height
        self.pet_w = pet_width
        self.pet_h = pet_height

        self.on_anim_change = on_anim_change
        self.on_move = on_move

        # 当前状态
        self.current_anim = "idle"
        self.current_x = screen_width // 2
        self.current_y = screen_height // 2
        self.target_x = self.current_x
        self.target_y = self.current_y

        # 计时器
        self._last_action_time = time.time()
        self._next_action_time = 0
        self._last_move_time = time.time()
        self._move_target_time = 0
        self._schedule_next_action()

        # 动画状态持续时间
        self._anim_elapsed = 0
        self._anim_duration = 3.0

        # 走路状态
        self._walking = False
        self._walk_start = (self.current_x, self.current_y)
        self._walk_target = (self.current_x, self.current_y)
        self._walk_duration = 0
        self._walk_elapsed = 0

        # 闲逛路径
        self._wander_path: list[tuple[int, int]] = []
        self._wander_index = 0

        # 是否启用
        self.enabled = False

    def set_preset(self, preset: str):
        """切换行为预设。"""
        if preset not in BEHAVIOR_PRESETS:
            logger.warning(f"未知行为预设 '{preset}'，使用 'playful'")
            preset = "playful"
        self.preset_name = preset
        self.preset = BEHAVIOR_PRESETS[preset]
        logger.info(f"行为预设切换为: {self.preset['name']}")

    def _schedule_next_action(self):
        """安排下一次动作时间。"""
        low, high = self.preset["interaction_interval"]
        interval = random.uniform(low, high)
        self._next_action_time = time.time() + interval

    def update(self, dt: float = 1.0):
        """每帧调用，更新随机行为。

        Args:
            dt: 距离上次更新的秒数（通常约 0.05-0.1）
        """
        if not self.enabled:
            return

        now = time.time()

        # ── 处理行走 ──
        if self._walking:
            self._walk_elapsed += dt
            progress = min(self._walk_elapsed / self._walk_duration, 1.0)

            # 缓动插值
            from .animation_engine import interpolate
            t = interpolate(0, 1, progress, "ease_out")

            sx, sy = self._walk_start
            tx, ty = self._walk_target
            self.current_x = sx + (tx - sx) * t
            self.current_y = sy + (ty - sy) * t

            if self.on_move:
                self.on_move(int(self.current_x), int(self.current_y))

            if progress >= 1.0:
                self._walking = False
                # 到达后切回idle
                self._switch_anim("idle")
                self._schedule_next_action()

        # ── 定时动作 ──
        if now >= self._next_action_time and not self._walking:
            self._perform_random_action()
            self._schedule_next_action()

        # ── 动画持续时间到期 ──
        self._anim_elapsed += dt
        if self._anim_elapsed >= self._anim_duration and not self._walking:
            self._switch_anim("idle")

    def _perform_random_action(self):
        """执行一次随机动作。"""
        action = random.random()

        # 是否移动
        if action < self.preset["move_probability"]:
            self._random_move()
        # 是否跳跃
        elif action < self.preset["move_probability"] + self.preset["jump_probability"]:
            self._random_jump()
        # 随机动画
        else:
            self._random_anim()

    def _random_anim(self):
        """随机切换动画。"""
        weights = self.preset["anim_weights"]
        anims = list(weights.keys())
        w = [weights[a] for a in anims]

        chosen = random.choices(anims, weights=w, k=1)[0]
        self._switch_anim(chosen)

    def _random_move(self):
        """随机移动到屏幕某处。"""
        # 生成目标位置（保持一定边距）
        margin = 50
        tx = random.randint(margin, self.screen_w - self.pet_w - margin)
        ty = random.randint(margin, self.screen_h - self.pet_h - margin - 40)

        self._start_walk(tx, ty)

    def _random_jump(self):
        """随机跳跃效果。"""
        self._switch_anim("jumping")
        self._anim_duration = 2.0
        self._anim_elapsed = 0

    def _start_walk(self, tx: int, ty: int):
        """开始走到目标位置。"""
        dx = tx - self.current_x
        dy = ty - self.current_y
        dist = math.sqrt(dx * dx + dy * dy)

        if dist < 20:
            return

        # 根据方向切换动画
        if abs(dx) > abs(dy):
            self._switch_anim("running-right" if dx > 0 else "running-left")
        else:
            self._switch_anim("running-right" if dx > 0 else "running-left")

        # 计算行走时间（速度约 200px/s）
        speed = 200.0
        self._walk_start = (self.current_x, self.current_y)
        self._walk_target = (tx, ty)
        self._walk_duration = max(dist / speed, 0.5)
        self._walk_elapsed = 0
        self._walking = True

    def _switch_anim(self, anim_name: str):
        """切换动画状态。"""
        if anim_name == self.current_anim:
            return

        self.current_anim = anim_name
        self._anim_elapsed = 0
        self._anim_duration = random.uniform(1.5, 5.0)

        if self.on_anim_change:
            self.on_anim_change(anim_name)

    def generate_wander_path(self, segments: int = 5):
        """生成随机闲逛路径（贝塞尔曲线方式简化）。"""
        margin = 50
        path = [(self.current_x, self.current_y)]

        for _ in range(segments):
            tx = random.randint(margin, self.screen_w - self.pet_w - margin)
            ty = random.randint(margin, self.screen_h - self.pet_h - margin - 40)
            path.append((tx, ty))

        self._wander_path = path
        self._wander_index = 1

    def wander_next(self):
        """闲逛下一步（沿路径走）。"""
        if self._wander_index >= len(self._wander_path):
            return

        tx, ty = self._wander_path[self._wander_index]
        self._start_walk(tx, ty)
        self._wander_index += 1

    def get_next_action_hint(self) -> Optional[dict]:
        """获取下一个即将发生的动作提示（用于UI展示）。"""
        if not self.enabled:
            return None

        remaining = max(0, self._next_action_time - time.time())
        return {
            "next_in": round(remaining, 1),
            "current_anim": self.current_anim,
            "walking": self._walking,
            "preset": self.preset["name"],
        }

    def stop(self):
        """停止随机行为。"""
        self.enabled = False
        self._walking = False


# ═══════════════════════════════════════════
#  随机表情/特效触发器
# ═══════════════════════════════════════════

class RandomEffectTrigger:
    """随机特效触发器。"""

    def __init__(self):
        self.cooldowns: dict[str, float] = {}
        self.last_effect_time: dict[str, float] = {}

    def can_trigger(self, effect_name: str, cooldown: float = 5.0) -> bool:
        """检查特效是否可以触发。"""
        now = time.time()
        last = self.last_effect_time.get(effect_name, 0)
        return (now - last) >= cooldown

    def trigger(self, effect_name: str):
        """记录触发时间。"""
        self.last_effect_time[effect_name] = time.time()

    def random_effect(self, x: int, y: int) -> Optional[str]:
        """随机触发一个特效，返回特效名称。"""
        effects = ["sparkle", "heart", "bounce", None]  # None = 无特效
        weights = [0.15, 0.1, 0.1, 0.65]

        chosen = random.choices(effects, weights=weights, k=1)[0]

        if chosen and self.can_trigger(chosen, cooldown=8.0):
            self.trigger(chosen)
            return chosen

        return None
