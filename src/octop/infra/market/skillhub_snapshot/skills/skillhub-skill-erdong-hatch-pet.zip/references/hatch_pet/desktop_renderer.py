"""
Desktop Pet Renderer — 增强版桌面宠物渲染器

跨平台桌面宠物窗口（Windows + macOS + Linux）。
特性：
- 平滑动画（缓动函数 + 帧间过渡）
- 粒子特效
- 随机行为模式（调皮/悠闲/好奇/活跃）
- 系统托盘图标与菜单
- 拖拽移动 + 右键菜单
- 观察模式 + 跟随模式
- 窗口始终置顶 + 透明背景
"""

import json
import logging
import math
import random
import sys
import threading
import time
from pathlib import Path
from typing import Optional

# tkinter 仅在桌面模式下按需导入（无头服务器可能不可用）
tk = None
ImageTk = None

from PIL import Image

from .config import (
    CELL_WIDTH, CELL_HEIGHT, COLS, ROWS,
    ANIMATION_STATES, GAZE_DIRECTIONS,
)
from .animation_engine import (
    SpringAnimation, TransitionAnimator,
    interpolate,
)
from .random_mode import (
    RandomBehaviorEngine, RandomEffectTrigger,
    BEHAVIOR_PRESETS,
)
from .status_watcher import StatusWatcher, create_watcher

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════
#  平台检测
# ═══════════════════════════════════════════

def get_platform() -> str:
    """检测当前操作系统。"""
    if sys.platform == "win32":
        return "windows"
    elif sys.platform == "darwin":
        return "macos"
    else:
        return "linux"


PLATFORM = get_platform()

# Windows 特有导入
if PLATFORM == "windows":
    try:
        import ctypes
        from ctypes import wintypes
        HAS_WIN32 = True
    except ImportError:
        HAS_WIN32 = False
else:
    HAS_WIN32 = False


# ═══════════════════════════════════════════
#  气泡配色与动画参数
# ═══════════════════════════════════════════

_BUBBLE_THEMES = {
    "error":      {"bg": "#FFF5F5", "border": "#FF8787", "text": "#C92A2A"},
    "done":       {"bg": "#EBFBEE", "border": "#69DB7C", "text": "#2B8A3E"},
    "happy":      {"bg": "#EBFBEE", "border": "#69DB7C", "text": "#2B8A3E"},
    "greet":      {"bg": "#E7F5FF", "border": "#74C0FC", "text": "#1864AB"},
    "working":    {"bg": "#FFF9DB", "border": "#FFE066", "text": "#866A04"},
    "thinking":   {"bg": "#E7F5FF", "border": "#74C0FC", "text": "#1864AB"},
    "needsinput": {"bg": "#FFF4E6", "border": "#FFA94D", "text": "#A04A00"},
    "waiting":    {"bg": "#FFF4E6", "border": "#FFA94D", "text": "#A04A00"},
    "juggling":   {"bg": "#F3F0FF", "border": "#9775FA", "text": "#5F3DC4"},
    "loafing":    {"bg": "#FFF5F5", "border": "#FFA8A8", "text": "#C92A2A"},
    "sleeping":   {"bg": "#F8F9FA", "border": "#CED4DA", "text": "#495057"},
}
_BUBBLE_DEFAULT_THEME = {"bg": "#FFFFFF", "border": "#DEE2E6", "text": "#343A40"}
_BUBBLE_TRANSPARENT = "#F0F0F0"
_BUBBLE_FADE_STEPS = 5
_BUBBLE_FADE_INTERVAL = 30  # ms


# ═══════════════════════════════════════════
#  桌面宠物主类
# ═══════════════════════════════════════════

class DesktopPet:
    """增强版桌面宠物主窗口。"""

    def __init__(self,
                 spritesheet_path: str,
                 config_path: str,
                 random_preset: str = "playful",
                 start_x: int = 100,
                 start_y: int = 100,
                 scale: float = 1.0,
                 enable_tray: bool = True,
                 enable_watcher: bool = False,
                 status_path: str = "~/.hatch-pet/status.json",
                 events_path: str = "~/.hatch-pet/events.jsonl"):
        global tk, ImageTk
        import tkinter as _tk
        from PIL.ImageTk import PhotoImage as _ImageTk
        tk = _tk
        ImageTk = _ImageTk
        """
        Args:
            spritesheet_path: 精灵图路径
            config_path: pet.json 路径
            random_preset: 随机行为预设
            start_x/start_y: 初始位置
            scale: 缩放比例
            enable_tray: 是否启用系统托盘
            enable_watcher: 是否启用 AI agent 状态监听
            status_path: 状态文件路径（enable_watcher=True 时生效）
            events_path: 事件流文件路径（enable_watcher=True 时生效）
        """
        self.root = tk.Tk()
        self.root.title("Desktop Pet")
        self.scale = scale

        # ── 窗口尺寸 ──
        self.win_w = int(CELL_WIDTH * scale)
        self.win_h = int(CELL_HEIGHT * scale)

        # ── 实现透明窗口 ──
        self._setup_transparent_window()

        # ── 加载资源 ──
        self.config = self._load_config(config_path)
        self.gif_dir = None
        self.gif_groups: dict[str, list[list]] = {}  # 多 GIF 分组（用于随机切换）
        self._anim_gif_config: dict[str, list[str]] = {}  # 动画名→GIF 文件名列表，按需加载用
        self._anim_fps: dict[str, int] = {}  # 动画名→从 GIF 帧延迟计算的 fps
        if self.config.get("gifMode"):
            # GIF 模式：从 GIF 文件加载帧，窗口自适应
            self.frames, self.gaze_frames, gif_size = self._load_gif_frames()
            if gif_size:
                self.win_w = int(gif_size[0] * scale)
                self.win_h = int(gif_size[1] * scale)
        else:
            # 精灵图模式：从 spritesheet 裁剪帧
            self.frames, self.gaze_frames = self._load_spritesheet(spritesheet_path)

        # ── 动画状态 ──
        self.current_anim = "idle"
        self.current_frame = 0
        self.animating = True
        self.anim_counter = 0
        self._anim_accumulator = 0.0  # 帧前进时间累积器
        self._anim_start_time = time.time()
        self._pool_rotate_s = 60.0  # 持续状态 GIF 轮换周期（对齐 LLMPET POOL_ROTATE_MS）
        self._rotateable_states = {"working", "thinking", "loafing"}  # 定时轮换的状态

        # ── 动画引擎 ──
        self.spring_x = SpringAnimation(stiffness=0.12, damping=0.65)
        self.spring_y = SpringAnimation(stiffness=0.12, damping=0.65)
        self.transition = TransitionAnimator()

        # ── 模式开关 ──
        self.follow_mode = False
        self.watch_mode = False
        self.follow_target_x: Optional[int] = None
        self.follow_target_y: Optional[int] = None
        self.current_gaze: Optional[str] = None

        # ── 拖拽 ──
        self.dragging = False
        self.drag_start_x = 0
        self.drag_start_y = 0
        self.drag_offset_x = 0
        self.drag_offset_y = 0

        # ── 随机行为 ──
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        self.random_engine = RandomBehaviorEngine(
            preset=random_preset,
            screen_width=screen_w,
            screen_height=screen_h,
            pet_width=self.win_w,
            pet_height=self.win_h,
            on_anim_change=self._on_random_anim_change,
            on_move=self._on_random_move,
        )
        self.effect_trigger = RandomEffectTrigger()

        # ── AI Agent 状态监听 ──
        self.watcher: Optional[StatusWatcher] = None
        self._events_path = events_path
        if enable_watcher:
            self._start_watcher(status_path, events_path)

        # ── 气泡 ──
        self._bubble_active = False
        self._bubble_text_id = None
        self._bubble_bg_id = None
        self._bubble_timer = None
        self._bubble_win = None
        self._bubble_alpha = 0.0

        # ── 右键菜单（懒构建、复用，避免每次右键都重建 Tk 菜单对象） ──
        self._ctx_menu: Optional["tk.Menu"] = None
        self._ctx_menu_preset: Optional["tk.Menu"] = None
        self._idx_follow: int = 0
        self._idx_watch: int = 0
        self._idx_random: int = 0

        # ── 设置初始位置 ──
        self.root.geometry(f"{self.win_w}x{self.win_h}+{start_x}+{start_y}")
        self.spring_x.reset(start_x)
        self.spring_y.reset(start_y)

        # ── 画布 ──
        self.canvas = tk.Canvas(
            self.root,
            width=self.win_w,
            height=self.win_h,
            bg="magenta",
            highlightthickness=0,
        )
        self.canvas.pack()
        self.image_id = self.canvas.create_image(
            self.win_w // 2, self.win_h // 2, anchor="center",
        )

        # ── 事件绑定 ──
        # 左键：短按弹动画列表，拖拽移动窗口（4px 阈值区分）
        self.canvas.bind("<ButtonPress-1>", self._on_drag_start)
        self.canvas.bind("<B1-Motion>", self._on_drag_move)
        self.canvas.bind("<ButtonRelease-1>", self._on_drag_end)
        # 右键：radial 扇形菜单（参考 LLMPET 设计）
        self.canvas.bind("<Button-3>", self._on_right_click)
        if PLATFORM == "darwin":
            self.canvas.bind("<Button-2>", self._on_right_click)  # macOS Ctrl+Click
        # 全局快捷键：Ctrl+Shift+Alt+P 恢复隐藏窗口
        self.root.bind("<Control-Shift-Alt-Key-P>", lambda e: self._restore_from_hidden())

        # ── 系统托盘 ──
        self.tray_icon = None
        if enable_tray:
            self._setup_tray()

        # ── 窗口关闭协议 ──
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        # ── FPS 计数器 ──
        self._frame_count = 0
        self._fps_timer = 0
        self._fps = 0

        # ── 启动 ──
        self.root.after(16, self._game_loop)  # ~60fps

    # ═══════════════════════════════════════
    #  窗口设置
    # ═══════════════════════════════════════

    def _setup_transparent_window(self):
        """设置透明无边框置顶窗口。"""
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg="magenta")

        # 透明色
        self.root.attributes("-transparentcolor", "magenta")

        # Windows 额外设置
        if PLATFORM == "windows" and HAS_WIN32:
            try:
                hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
                # WS_EX_LAYERED + WS_EX_TOOLWINDOW
                # 注意：不要加 WS_EX_TRANSPARENT，它会让整个窗口对所有点击穿透，
                # 包括非透明像素区域，导致右键/拖拽都无法触发。
                # -transparentcolor=magenta 已经实现了"magenta 像素穿透、
                # 非 magenta 像素可点击"的效果，无需额外标志。
                GWL_EXSTYLE = -20
                WS_EX_LAYERED = 0x00080000
                WS_EX_TOOLWINDOW = 0x00000080
                ex_style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
                ctypes.windll.user32.SetWindowLongW(
                    hwnd, GWL_EXSTYLE,
                    ex_style | WS_EX_LAYERED | WS_EX_TOOLWINDOW,
                )
            except Exception:
                pass

    def _setup_tray(self):
        """尝试设置系统托盘图标。"""
        try:
            self._setup_tray_pystray()
        except ImportError:
            logger = __import__('logging').getLogger(__name__)
            logger.info("pystray 未安装，跳过系统托盘设置。可执行 pip install pystray")

    def _setup_tray_pystray(self):
        """使用 pystray 设置系统托盘。"""
        try:
            import pystray
            from PIL import Image as PILImage, ImageDraw as PILImageDraw

            # 创建简单托盘图标
            icon_img = PILImage.new("RGBA", (64, 64), (0, 0, 0, 0))
            draw = PILImageDraw.Draw(icon_img)
            draw.ellipse([8, 8, 56, 56], fill=(120, 160, 220, 255))
            draw.ellipse([20, 18, 44, 42], fill=(255, 255, 255, 255))
            draw.ellipse([24, 22, 34, 34], fill=(40, 40, 40, 255))
            draw.ellipse([36, 22, 46, 34], fill=(40, 40, 40, 255))

            menu = pystray.Menu(
                pystray.MenuItem("显示/隐藏", self._toggle_visibility, default=True),
                pystray.MenuItem("模式切换", pystray.Menu(
                    pystray.MenuItem("调皮模式", lambda: self._set_random_preset("playful")),
                    pystray.MenuItem("悠闲模式", lambda: self._set_random_preset("relaxed")),
                    pystray.MenuItem("好奇模式", lambda: self._set_random_preset("curious")),
                    pystray.MenuItem("活跃模式", lambda: self._set_random_preset("active")),
                )),
                pystray.MenuItem("跟随模式", self._toggle_follow_tray,
                                 checked=lambda item: self.follow_mode),
                pystray.MenuItem("观察模式", self._toggle_watch_tray,
                                 checked=lambda item: self.watch_mode),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("退出", self._quit_from_tray),
            )

            self._tray = pystray.Icon(
                "DesktopPet", icon_img, "Desktop Pet", menu,
            )
            # 在独立线程中运行托盘
            threading.Thread(target=self._tray.run, daemon=True).start()
        except Exception:
            pass

    def _toggle_visibility(self, icon=None, item=None):
        """切换窗口可见性。"""
        if self.root.state() == "withdrawn":
            self.root.deiconify()
            self.animating = True
            self.root.after(16, self._game_loop)  # 重启动画循环
        else:
            self.root.withdraw()
            self.animating = False

    def _set_random_preset(self, preset: str):
        """从托盘切换随机模式。"""
        self.random_engine.set_preset(preset)

    def _toggle_follow_tray(self, icon, item):
        self._toggle_follow()

    def _toggle_watch_tray(self, icon, item):
        self._toggle_watch()

    def _quit_from_tray(self, icon=None, item=None):
        """从托盘退出。"""
        self._quit()

    def _on_close(self):
        """窗口关闭时处理。"""
        self._quit()

    def _quit(self):
        """统一退出：停止托盘、停止动画、销毁窗口。"""
        self.animating = False
        # 停止系统托盘图标（在独立线程中运行）
        tray = getattr(self, "_tray", None)
        if tray is not None:
            try:
                tray.stop()
            except Exception:
                pass
        try:
            self.root.destroy()
        except Exception:
            pass

    # ═══════════════════════════════════════
    #  资源加载
    # ═══════════════════════════════════════

    def _load_config(self, path: str) -> dict:
        """加载 pet.json。"""
        path = Path(path)
        if not path.exists():
            return {
                "animations": [
                    {"name": s["name"], "row": s["row"],
                     "frameCount": 8, "fps": s.get("fps", 6),
                     "repeat": s.get("repeat", True)}
                    for s in ANIMATION_STATES
                ],
                "gazes": GAZE_DIRECTIONS,
            }
        with open(path, encoding="utf-8") as f:
            return json.load(f)

    def _load_spritesheet(self, path: str):
        """加载精灵图，支持缩放。"""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"精灵图未找到: {path}")

        sheet = Image.open(path).convert("RGBA")
        anim_frames = {}
        gaze_frames = {}

        anims = self.config.get("animations", [])
        for anim in anims:
            name = anim.get("name", "idle")
            row = anim.get("row", 0)
            count = anim.get("frameCount", 8)
            frame_list = []
            for col in range(min(count, COLS)):
                x = col * CELL_WIDTH
                y = row * CELL_HEIGHT
                cell = sheet.crop((x, y, x + CELL_WIDTH, y + CELL_HEIGHT))
                if self.scale != 1.0:
                    cell = cell.resize(
                        (self.win_w, self.win_h), Image.LANCZOS
                    )
                frame_list.append(ImageTk(cell))
            anim_frames[name] = frame_list

        gazes = self.config.get("gazes", [])
        for gaze in gazes:
            name = gaze.get("name")
            row = gaze.get("row", 9)
            col = gaze.get("col", 0)
            x = col * CELL_WIDTH
            y = row * CELL_HEIGHT
            cell = sheet.crop((x, y, x + CELL_WIDTH, y + CELL_HEIGHT))
            if self.scale != 1.0:
                cell = cell.resize((self.win_w, self.win_h), Image.LANCZOS)
            gaze_frames[name] = ImageTk(cell)

        return anim_frames, gaze_frames

    # ═══════════════════════════════════════
    #  GIF 加载模式
    # ═══════════════════════════════════════

    def _load_gif_frames(self):
        """从 pet.json 配置的 GIF 文件加载帧（按需：启动只加载 idle）。

        其他动画的 GIF 帧在 `_switch_anim` 切换时按需加载，
        避免启动时一次性加载所有 GIF 导致卡顿。

        Returns:
            (anim_frames, gaze_frames, gif_size)  — gif_size 为 (width, height) 或 None
        """
        from PIL import Image as PILImage

        config = self.config
        gif_dir = Path(config.get("gifDir", "."))
        if not gif_dir.is_absolute():
            gif_dir = Path.cwd() / gif_dir
        self.gif_dir = gif_dir

        # 保存所有动画的 GIF 配置，用于按需加载
        self._anim_gif_config = {}
        for anim in config.get("animations", []):
            name = anim.get("name", "idle")
            gif_names = anim.get("gif")
            if not gif_names:
                continue
            if isinstance(gif_names, str):
                gif_names = [gif_names]
            self._anim_gif_config[name] = gif_names

        anim_frames = {}
        gif_size = None
        target_size = None

        # 启动只加载 idle（默认显示的动画）
        idle_gif_names = self._anim_gif_config.get("idle", [])
        for gif_name in idle_gif_names:
            gif_path = gif_dir / gif_name
            if not gif_path.exists():
                logger.warning(f"GIF 文件不存在: {gif_path}")
                continue

            try:
                img = PILImage.open(gif_path)
                if gif_size is None:
                    gif_size = img.size
                    target_size = (
                        int(gif_size[0] * self.scale),
                        int(gif_size[1] * self.scale),
                    )

                total = 0
                try:
                    while True:
                        img.seek(total)
                        total += 1
                except EOFError:
                    pass

                if total == 0:
                    continue

                group_frames = []
                for i in range(total):
                    img.seek(i)
                    frame = img.convert("RGBA")
                    if target_size and frame.size != target_size:
                        frame = frame.resize(target_size, PILImage.LANCZOS)
                    tk_frame = self._frame_to_tk(frame)
                    group_frames.append(tk_frame)

                # 从帧延迟计算真实 fps
                self._anim_fps["idle"] = self._calc_gif_fps(gif_path)

                self.gif_groups["idle"] = [group_frames]
                anim_frames["idle"] = group_frames
                logger.info(f"  加载 idle GIF: {gif_name} ({total} 帧)")

            except Exception as e:
                logger.warning(f"加载 idle GIF 失败 {gif_path}: {e}")

        # 如果 idle 加载失败，用其他动画确定窗口尺寸
        if gif_size is None:
            for name, gif_names in self._anim_gif_config.items():
                if name == "idle":
                    continue
                for gif_name in gif_names:
                    gif_path = gif_dir / gif_name
                    if gif_path.exists():
                        try:
                            img = PILImage.open(gif_path)
                            gif_size = img.size
                            target_size = (
                                int(gif_size[0] * self.scale),
                                int(gif_size[1] * self.scale),
                            )
                            break
                        except Exception:
                            continue
                if gif_size:
                    break

        # 注视帧：留空
        gaze_frames = {}

        return anim_frames, gaze_frames, gif_size

    @staticmethod
    def _calc_gif_fps(gif_path) -> int:
        """从 GIF 文件的帧延迟计算真实 fps。"""
        from PIL import Image as PILImage
        try:
            img = PILImage.open(gif_path)
            total = 0
            durations = []
            try:
                while True:
                    img.seek(total)
                    durations.append(img.info.get("duration", 100))
                    total += 1
            except EOFError:
                pass
            if total > 0 and durations:
                avg = sum(durations) / len(durations)
                return max(1, round(1000 / avg)) if avg > 0 else 6
        except Exception:
            pass
        return 6

    def _frame_to_tk(self, frame):
        """将 PIL RGBA 帧转换为 tkinter PhotoImage，透明像素映射为 magenta（配合窗口透明色）。"""
        from PIL import Image as PILImage
        r, g, b, a = frame.split()
        magenta_bg = PILImage.new("RGB", frame.size, (255, 0, 255))
        rgb = PILImage.merge("RGB", (r, g, b))
        composite = PILImage.composite(rgb, magenta_bg, a)
        return ImageTk(composite)

    def _load_single_gif(self, name: str):
        """按需加载单个动画的 GIF 帧（启动时不加载，切换时触发）。"""
        from PIL import Image as PILImage

        gif_names = self._anim_gif_config.get(name)
        if not gif_names:
            logger.warning(f"按需加载失败: 未知动画 '{name}'")
            return

        gif_dir = self.gif_dir
        target_size = (self.win_w, self.win_h)
        all_frames = []
        groups = []

        for gif_name in gif_names:
            gif_path = gif_dir / gif_name
            if not gif_path.exists():
                logger.warning(f"GIF 文件不存在: {gif_path}")
                continue

            try:
                img = PILImage.open(gif_path)

                total = 0
                try:
                    while True:
                        img.seek(total)
                        total += 1
                except EOFError:
                    pass

                if total == 0:
                    continue

                group_frames = []
                for i in range(total):
                    img.seek(i)
                    frame = img.convert("RGBA")
                    if frame.size != target_size:
                        frame = frame.resize(target_size, PILImage.LANCZOS)
                    tk_frame = self._frame_to_tk(frame)
                    group_frames.append(tk_frame)
                    all_frames.append(tk_frame)

                # 从帧延迟计算真实 fps
                self._anim_fps[name] = self._calc_gif_fps(gif_path)

                groups.append(group_frames)
                logger.info(f"  按需加载 '{name}': {gif_name} ({total} 帧)")

            except Exception as e:
                logger.warning(f"加载 GIF 失败 {gif_path}: {e}")

        if all_frames:
            if len(groups) > 1:
                self.gif_groups[name] = groups
            self.frames[name] = groups[0] if groups else all_frames
            logger.info(f"  → '{name}' 总计 {len(all_frames)} 帧，{len(groups)} 组")

    # ═══════════════════════════════════════
    #  主循环 (~60fps)
    # ═══════════════════════════════════════

    def _game_loop(self):
        if not self.animating:
            return

        dt = 0.016  # 约 16ms

        # ── 更新弹性位置 ──
        if not self.dragging:
            sx = self.spring_x.update(dt * 2)
            sy = self.spring_y.update(dt * 2)
            if not self.spring_x.is_settled or not self.spring_y.is_settled:
                self.root.geometry(f"+{int(sx)}+{int(sy)}")

        # ── 更新随机行为 ──
        self.random_engine.update(dt)

        # ── 观察模式 ──
        if self.watch_mode:
            self._update_watch()

        # ── 跟随模式 ──
        if self.follow_mode:
            self._update_follow(dt)

        # ── 渲染帧 ──
        self._render_frame()

        # ── 持续状态 GIF 定时轮换 ──
        if (self.current_anim in self._rotateable_states
                and self.current_anim in self.gif_groups
                and time.time() - self._anim_start_time >= self._pool_rotate_s):
            self._rotate_gif()

        # ── 气泡跟随宠物 ──
        if self._bubble_win:
            try:
                px = self.root.winfo_x()
                py = self.root.winfo_y()
                bw = self._bubble_win.winfo_width()
                bh = self._bubble_win.winfo_height()
                bx = px + (self.win_w - bw) // 2
                by = py - bh - 2
                if by < 0:
                    by = py + self.win_h + 2
                self._bubble_win.geometry(f"+{bx}+{by}")
            except Exception:
                pass

        # ── FPS ──
        self._frame_count += 1
        self._fps_timer += dt

        self.root.after(16, self._game_loop)

    def _rotate_gif(self):
        """持续状态中定时轮换到下一组 GIF（不触发状态切换动画）。"""
        groups = self.gif_groups.get(self.current_anim)
        if not groups or len(groups) < 2:
            return
        current = self.frames.get(self.current_anim)
        if current in groups:
            idx = (groups.index(current) + 1) % len(groups)
        else:
            idx = 0
        self.frames[self.current_anim] = groups[idx]
        self.current_frame = 0
        self.anim_counter = 0
        self._anim_start_time = time.time()
        logger.debug(f"GIF 轮换 '{self.current_anim}': 第 {idx + 1}/{len(groups)} 组")

    def _render_frame(self):
        """渲染当前帧。"""
        # 观察模式：显示注视帧
        if self.watch_mode and self.current_gaze:
            frame = self.gaze_frames.get(self.current_gaze)
            if frame:
                self.canvas.itemconfig(self.image_id, image=frame)
                return

        # 正常动画
        anim = self.frames.get(self.current_anim)
        if not anim:
            return

        frame = anim[self.current_frame]
        self.canvas.itemconfig(self.image_id, image=frame)

        # 帧前进（基于时间累积，精确匹配 GIF 帧延迟）
        fps = self._get_current_fps()
        frame_interval = 1.0 / fps
        self._anim_accumulator += 0.016  # 约 16ms/帧
        while self._anim_accumulator >= frame_interval:
            self._anim_accumulator -= frame_interval
            self.current_frame += 1
            if self.current_frame >= len(anim):
                self.current_frame = 0

    def _get_current_fps(self) -> int:
        """获取当前动画状态的FPS（优先使用从 GIF 帧延迟计算的真实 fps）。"""
        if self.current_anim in self._anim_fps:
            return self._anim_fps[self.current_anim]
        for a in self.config.get("animations", []):
            if a.get("name") == self.current_anim:
                return a.get("fps", 6)
        return 6

    # ═══════════════════════════════════════
    #  跟随模式
    # ═══════════════════════════════════════

    def _update_follow(self, dt: float):
        """平滑跟随鼠标。

        让宠物中心略偏上于鼠标位置（像被牵着走），
        而非整体飘在鼠标上方很远。
        """
        mx = self.root.winfo_pointerx()
        my = self.root.winfo_pointery()

        # x: 窗口中心对齐鼠标 x
        tx = mx - self.win_w // 2
        # y: 让宠物中心略偏上于鼠标（上移半个身位 + 少量间距），
        # 这样宠物就在鼠标附近而不是高高飘在上方
        ty = my - self.win_h // 2 - 10

        self.follow_target_x = tx
        self.follow_target_y = ty

        self.spring_x.set_target(tx)
        self.spring_y.set_target(ty)

        # 根据方向切换动画
        cx = self.root.winfo_x()
        dx = tx - cx
        if abs(dx) > 15:
            self._switch_anim("running-right" if dx > 0 else "running-left")
        else:
            if self.current_anim in ("running-right", "running-left"):
                self._switch_anim("idle")

    def _update_watch(self):
        """眼睛跟随鼠标方向。"""
        mx = self.root.winfo_pointerx()
        my = self.root.winfo_pointery()
        cx = self.root.winfo_x() + self.win_w // 2
        cy = self.root.winfo_y() + self.win_h // 2

        angle = math.degrees(math.atan2(mx - cx, cy - my))
        if angle < 0:
            angle += 360

        best_gaze = None
        best_diff = 999
        for gaze in self.config.get("gazes", []):
            g_angle = gaze.get("angle", 0)
            diff = abs(angle - g_angle)
            if diff > 180:
                diff = 360 - diff
            if diff < best_diff:
                best_diff = diff
                best_gaze = gaze.get("name")

        if best_gaze and best_gaze != self.current_gaze:
            self.current_gaze = best_gaze

    # ═══════════════════════════════════════
    #  鼠标事件
    # ═══════════════════════════════════════

    def _on_drag_start(self, event):
        """按下：记录起点，暂不进入拖拽。是否拖拽由移动阈值判定。"""
        self._press_x = event.x_root
        self._press_y = event.y_root
        self._press_win_x = self.root.winfo_x()
        self._press_win_y = self.root.winfo_y()
        self._moved = False
        # 拖拽时禁用跟随模式
        if self.follow_mode:
            self.follow_mode = False

    def _on_drag_move(self, event):
        """移动：超过 4px 阈值才算拖拽，避免短按误判。"""
        dx = event.x_root - self._press_x
        dy = event.y_root - self._press_y
        if not self._moved and (abs(dx) + abs(dy) > 4):
            self._moved = True
            self.dragging = True
        if self._moved:
            new_x = self._press_win_x + dx
            new_y = self._press_win_y + dy
            self.root.geometry(f"+{new_x}+{new_y}")
            self.spring_x.reset(new_x)
            self.spring_y.reset(new_y)
            self.random_engine.current_x = new_x
            self.random_engine.current_y = new_y

    def _on_drag_end(self, event):
        """释放：没移动过 = 短按 → 弹出列表；移动过 = 落地。"""
        if self._moved:
            self.dragging = False
            self._switch_anim("idle")
            return
        # 左键短按：弹出状态/动画列表（参考 LLMPET 左键弹 HUD 的设计）
        self._show_left_menu(event)

    def _show_left_menu(self, event):
        """左键短按弹出的功能菜单（来自 pet.json 配置）。"""
        menu = tk.Menu(self.root, tearoff=0)
        for anim in self.config.get("animations", []):
            name = anim.get("name", "")
            label = anim.get("label", name)
            menu.add_command(
                label=label,
                command=lambda n=name: self._switch_anim(n, force=True),
            )
        menu.add_separator()
        menu.add_command(label="退出", command=self._quit)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _hide_to_tray(self):
        """隐藏到托盘（有托盘图标），无托盘则隐藏窗口（可通过快捷键恢复）。"""
        self.animating = False
        self.root.withdraw()
        if getattr(self, "_tray", None) is None:
            logger.info("窗口已隐藏，按 Ctrl+Shift+Alt+P 恢复")

    def _restore_from_hidden(self):
        """从隐藏状态恢复窗口（全局快捷键 Ctrl+Shift+Alt+P）。"""
        if self.root.state() == "withdrawn":
            self.root.deiconify()
            self.animating = True
            self.root.after(16, self._game_loop)
            logger.info("窗口已恢复")

    def _on_right_click(self, event):
        """右键：弹出 radial 扇形菜单（参考 LLMPET 设计）。

        在宠物头顶上方画一段弧形排列的圆形按钮，点击图标触发对应操作。
        点空白处或按 Esc 关闭。
        """
        if getattr(self, "_radial_win", None) and self._radial_win.winfo_exists():
            self._close_radial()
            return

        # 菜单项：icon(emoji), label, action
        items = [
            {"icon": "🎯", "label": "跟随", "act": self._toggle_follow},
        ]
        # GIF 模式没有注视帧，不显示观察模式
        if not self.config.get("gifMode"):
            items.append({"icon": "👀", "label": "观察", "act": self._toggle_watch})
        items += [
            {"icon": "🎲", "label": "活动", "act": self._cycle_behavior},
            {"icon": "🌙", "label": "隐藏", "act": self._hide_to_tray},
            {"icon": "🚪", "label": "退出", "act": self._quit},
        ]
        n = len(items)
        radius = 70
        btn_r = 22
        # 弧形：头顶上方的半弧 (180°~360°，即上半圆)
        start_a, end_a = 180, 360
        cx = self.win_w // 2
        cy = -radius // 2  # 弧心在窗口上方

        win_size = (radius + btn_r) * 2 + 10
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.configure(bg="magenta")
        try:
            win.attributes("-transparentcolor", "magenta")
        except tk.TclError:
            pass  # 非 Windows 平台不支持，退化为不透明背景
        # 窗口左上角定位：让弧心位于宠物窗口顶部中央上方
        px = self.root.winfo_x()
        py = self.root.winfo_y()
        win_x = px + cx - win_size // 2
        win_y = py - radius - btn_r - 5
        win.geometry(f"{win_size}x{win_size}+{win_x}+{win_y}")

        cv = tk.Canvas(win, width=win_size, height=win_size,
                       bg="magenta", highlightthickness=0)
        cv.pack()

        # 局部坐标：弧心放在画布中央偏下
        local_cx = win_size // 2
        local_cy = win_size - btn_r - 5

        for i, it in enumerate(items):
            a = math.radians(start_a + (end_a - start_a) * (i / (n - 1) if n > 1 else 0.5))
            bx = local_cx + radius * math.cos(a)
            by = local_cy + radius * math.sin(a)
            # 圆形按钮
            cv.create_oval(bx - btn_r, by - btn_r, bx + btn_r, by + btn_r,
                           fill="#FFFFFF", outline="#888888", width=2,
                           tags=f"btn{i}")
            cv.create_text(bx, by - 4, text=it["icon"], font=("Segoe UI Emoji", 14),
                           tags=f"btn{i}")
            cv.create_text(bx, by + btn_r - 6, text=it["label"],
                           font=("Microsoft YaHei", 8), fill="#444444",
                           tags=f"btn{i}")
            cv.tag_bind(f"btn{i}", "<Button-1>",
                        lambda e, act=it["act"]: self._radial_click(act))

        self._radial_win = win
        self._radial_canvas = cv
        # 点画布空白处关闭；Esc 关闭
        cv.bind("<Button-1>", lambda e: self._close_radial() if not self._radial_hit_btn(e) else None)
        win.bind("<Escape>", lambda e: self._close_radial())
        win.bind("<FocusOut>", lambda e: self._close_radial())
        win.focus_set()

    def _radial_hit_btn(self, event):
        """判断点击是否落在某个按钮上（用于点击空白处关闭）。"""
        cv = self._radial_canvas
        return "current" in cv.gettags(cv.find_closest(event.x, event.y))

    def _radial_click(self, act):
        """radial 菜单项点击：执行动作后关闭。"""
        logger.info(f"radial 点击: {getattr(act, '__name__', act)}")
        self._close_radial()
        try:
            act()
        except Exception as e:
            logger.exception(f"radial 菜单项执行失败: {e}")

    def _close_radial(self):
        """关闭 radial 菜单。"""
        win = getattr(self, "_radial_win", None)
        if win and win.winfo_exists():
            try:
                win.destroy()
            except Exception:
                pass
        self._radial_win = None
        self._radial_canvas = None

    # ═══════════════════════════════════════
    #  模式切换
    # ═══════════════════════════════════════

    def _toggle_follow(self):
        self.follow_mode = not self.follow_mode
        if self.follow_mode:
            self.watch_mode = False

    def _toggle_watch(self):
        self.watch_mode = not self.watch_mode
        if self.watch_mode:
            self.follow_mode = False
        if not self.watch_mode:
            self.current_gaze = None

    def _cycle_behavior(self):
        """循环切换：关闭 → 调皮 → 悠闲 → 好奇 → 活跃 → 关闭"""
        if not self.random_engine.enabled:
            self.random_engine.enabled = True
            self.random_engine.set_preset("playful")
            self._show_bubble("活动: 调皮模式", "idle")
        else:
            presets = ["playful", "relaxed", "curious", "active"]
            current = self.random_engine.preset_name
            idx = presets.index(current) if current in presets else 0
            if idx + 1 >= len(presets):
                # 最后一个预设 → 关闭
                self.random_engine.enabled = False
                self._show_bubble("活动: 已关闭", "idle")
            else:
                next_preset = presets[(idx + 1) % len(presets)]
                self.random_engine.set_preset(next_preset)
                self._show_bubble(f"活动: {self.random_engine.preset['name']}", "idle")

    def _set_random_preset(self, preset: str):
        self.random_engine.set_preset(preset)

    def _switch_anim(self, name: str, force: bool = False):
        """切换动画（支持过渡）。

        Args:
            name: 目标动画名
            force: 强制切换（即使已经是该动画），用于用户手动点击菜单
        """
        if not force and name == self.current_anim:
            return
        old = self.current_anim
        self.current_anim = name
        self.current_frame = 0
        self.anim_counter = 0
        self._anim_start_time = time.time()

        # 确保帧已加载（按需加载）；GIF 模式下跳过来自随机引擎的精灵图动画
        if name not in self.frames:
            if name not in self._anim_gif_config:
                self.current_anim = old  # 不回退，保持原动画
                return
            self._load_single_gif(name)

        # 多 GIF 随机切：如果该动画有分组，随机选一组作为当前帧
        if name in self.gif_groups:
            groups = self.gif_groups[name]
            chosen = random.choice(groups)
            self.frames[name] = chosen
            logger.debug(f"随机切换 '{name}': 选第 {groups.index(chosen) + 1}/{len(groups)} 组 ({len(chosen)} 帧)")

        # 强制更新 Canvas 显示
        self._render_frame()

    # ═══════════════════════════════════════
    #  随机行为回调
    # ═══════════════════════════════════════

    def _on_random_anim_change(self, anim_name: str):
        """随机引擎触发的动画切换。"""
        # GIF 模式下：随机引擎的精灵图动画名无效，从已有 GIF 状态中随机选
        if self.config.get("gifMode") and anim_name not in self._anim_gif_config:
            gif_states = list(self._anim_gif_config.keys())
            anim_name = random.choice(gif_states) if gif_states else "idle"
        self._switch_anim(anim_name)

    def _on_random_move(self, x: int, y: int):
        """随机引擎触发的位置移动。"""
        self.spring_x.set_target(x)
        self.spring_y.set_target(y)

    # ═══════════════════════════════════════
    #  AI Agent 状态监听
    # ═══════════════════════════════════════

    def _start_watcher(self, status_path: str, events_path: str = "~/.hatch-pet/events.jsonl"):
        """启动 AI agent 状态监听（v2: 状态快照 + 事件流双轨）。"""
        self.watcher = create_watcher(
            status_path=status_path,
            events_path=events_path,
            pet=self,
            auto_start=True,
        )
        logger.info(f"AI Agent 状态监听已启动: status={status_path}, events={events_path}")

    # ═══════════════════════════════════════
    #  气泡消息
    # ═══════════════════════════════════════

    def _show_bubble(self, msg, state=""):
        """调度气泡显示到主线程。"""
        self.root.after(0, self._do_show_bubble, msg, state)

    def _do_show_bubble(self, msg, state=""):
        try:
            self._hide_bubble_immediate()
        except Exception as e:
            self.root.title(f"BubbleErr: {e}")
        if self._bubble_timer:
            self.root.after_cancel(self._bubble_timer)
            self._bubble_timer = None

        if len(msg) > 60:
            msg = msg[:57] + "\u2026"

        # 状态配色
        theme = _BUBBLE_THEMES.get(state, _BUBBLE_DEFAULT_THEME)
        bg_color = theme["bg"]
        border_color = theme["border"]
        text_color = theme["text"]

        max_w = 260
        pad_x = 16
        pad_y = 10
        radius = 10
        arrow_w = 14
        arrow_h = 7

        import tkinter.font as _tf
        font = _tf.Font(family="Microsoft YaHei", size=10)
        line_h = font.metrics("linespace")

        # 自动换行
        remain = msg
        lines = []
        while remain:
            for i in range(len(remain), 0, -1):
                if font.measure(remain[:i]) <= max_w - pad_x * 2:
                    lines.append(remain[:i])
                    remain = remain[i:]
                    break
            else:
                lines.append(remain)
                remain = ""

        text_w = max(font.measure(l) for l in lines) if lines else 0
        text_h = len(lines) * line_h
        bw = min(max(text_w + pad_x * 2, 50), max_w)
        bh = max(text_h + pad_y * 2, 32)

        # 阴影偏移空间
        shadow_dx, shadow_dy = 2, 3
        total_w = bw + shadow_dx + 4
        total_h = bh + arrow_h + shadow_dy + 4

        # 独立气泡窗口（透明背景，用 transparentcolor 实现）
        px = self.root.winfo_x()
        py = self.root.winfo_y()
        bubble_x = px + (self.win_w - total_w) // 2
        bubble_y = py - total_h - 2

        if bubble_y < 0:
            bubble_y = py + self.win_h + 2

        bubble_win = tk.Toplevel(self.root)
        bubble_win.overrideredirect(True)
        bubble_win.attributes("-topmost", True)
        try:
            bubble_win.attributes("-transparentcolor", _BUBBLE_TRANSPARENT)
        except Exception:
            pass  # 非 Windows 平台不支持
        bubble_win.configure(bg=_BUBBLE_TRANSPARENT)
        bubble_win.geometry(f"{total_w}x{total_h}+{bubble_x}+{bubble_y}")
        bubble_win.lift()
        try:
            bubble_win.attributes("-alpha", 0.0)
        except Exception:
            pass

        canvas = tk.Canvas(bubble_win, width=total_w, height=total_h,
                           bg=_BUBBLE_TRANSPARENT, highlightthickness=0)
        canvas.pack()

        # 气泡主体坐标（留出阴影空间）
        bx1, by1 = 2, 2
        bx2, by2 = bx1 + bw - 1, by1 + bh - 1
        arrow_cx = (bx1 + bx2) // 2

        bubble_pts = self._bubble_polygon(bx1, by1, bx2, by2, radius, arrow_w, arrow_h, arrow_cx)

        # 阴影层（多层偏移模拟模糊）
        for dx, dy, sc in [(3, 4, "#E0E0E0"), (2, 3, "#D5D5D5"), (1, 1, "#C8C8C8")]:
            shadow_pts = self._offset_pts(bubble_pts, dx, dy)
            canvas.create_polygon(shadow_pts, fill=sc, outline="")

        # 气泡主体
        canvas.create_polygon(bubble_pts, fill=bg_color, outline=border_color, width=1.5)

        # 文字
        for i, line in enumerate(lines):
            canvas.create_text(
                (bx1 + bx2) // 2,
                by1 + pad_y + i * line_h + line_h // 2,
                text=line, anchor="center", fill=text_color,
                font=("Microsoft YaHei", 10, "normal")
            )

        self._bubble_win = bubble_win
        self._bubble_alpha = 0.0

        # 淡入动画
        self._bubble_fade_in(0)

        # 定时自动隐藏
        self._bubble_timer = self.root.after(3000, self._hide_bubble)

    @staticmethod
    def _bubble_polygon(x1, y1, x2, y2, r, aw, ah, ax):
        """生成圆角气泡（含底部箭头）的多边形坐标列表。"""
        pts = []
        # 左上圆角 180° → 270°
        for a in range(180, 271, 15):
            rad = math.radians(a)
            pts.append(x1 + r + r * math.cos(rad))
            pts.append(y1 + r + r * math.sin(rad))
        # 上边
        pts.append(x2 - r)
        pts.append(y1)
        # 右上圆角 270° → 360°
        for a in range(270, 361, 15):
            rad = math.radians(a)
            pts.append(x2 - r + r * math.cos(rad))
            pts.append(y1 + r + r * math.sin(rad))
        # 右边
        pts.append(x2)
        pts.append(y2 - r)
        # 右下圆角 0° → 90°
        for a in range(0, 91, 15):
            rad = math.radians(a)
            pts.append(x2 - r + r * math.cos(rad))
            pts.append(y2 - r + r * math.sin(rad))
        # 底边右段 → 箭头尖 → 底边左段
        aw2 = aw // 2
        pts.extend([ax + aw2, y2, ax, y2 + ah, ax - aw2, y2])
        # 左下圆角 90° → 180°
        for a in range(90, 181, 15):
            rad = math.radians(a)
            pts.append(x1 + r + r * math.cos(rad))
            pts.append(y2 - r + r * math.sin(rad))
        return pts

    @staticmethod
    def _offset_pts(pts, dx, dy):
        """偏移多边形所有点。"""
        result = []
        for i in range(0, len(pts), 2):
            result.append(pts[i] + dx)
            result.append(pts[i + 1] + dy)
        return result

    def _bubble_fade_in(self, step):
        """气泡淡入动画。"""
        if not self._bubble_win:
            return
        if step >= _BUBBLE_FADE_STEPS:
            try:
                self._bubble_win.attributes("-alpha", 1.0)
            except Exception:
                pass
            self._bubble_alpha = 1.0
            return
        alpha = (step + 1) / _BUBBLE_FADE_STEPS
        try:
            self._bubble_win.attributes("-alpha", alpha)
        except Exception:
            pass
        self._bubble_alpha = alpha
        self.root.after(_BUBBLE_FADE_INTERVAL, self._bubble_fade_in, step + 1)

    def _bubble_fade_out(self, step):
        """气泡淡出动画。"""
        if not self._bubble_win:
            return
        if step >= _BUBBLE_FADE_STEPS:
            self._hide_bubble_immediate()
            return
        alpha = 1.0 - (step + 1) / _BUBBLE_FADE_STEPS
        try:
            self._bubble_win.attributes("-alpha", alpha)
        except Exception:
            pass
        self.root.after(_BUBBLE_FADE_INTERVAL, self._bubble_fade_out, step + 1)

    def _hide_bubble(self):
        """触发淡出。"""
        self._bubble_timer = None
        if self._bubble_win:
            self._bubble_fade_out(0)
        self._bubble_active = False

    def _hide_bubble_immediate(self):
        if self._bubble_win:
            try:
                self._bubble_win.destroy()
            except Exception:
                pass
            self._bubble_win = None
        if self._bubble_timer:
            try:
                self.root.after_cancel(self._bubble_timer)
            except Exception:
                pass
            self._bubble_timer = None

    def run(self):
        """启动桌面宠物。"""
        # 延迟显示上线气泡（确保 tkinter 主循环已启动）
        if hasattr(self, "watcher") and self.watcher is not None:
            self.root.after(500, lambda: self._show_bubble("🐱 DesktopBuddy 上线，开始盯任务啦！", "greet"))
        self.root.mainloop()


# ═══════════════════════════════════════════
#  便捷启动函数
# ═══════════════════════════════════════════

def run_desktop(
    spritesheet: str = "output/spritesheet.webp",
    config: str = "output/pet.json",
    gif_path: Optional[str] = None,
    random_preset: str = "playful",
    scale: float = 1.0,
    enable_tray: bool = True,
    enable_watcher: bool = False,
    status_path: str = "~/.hatch-pet/status.json",
    events_path: str = "~/.hatch-pet/events.jsonl",
    start_x: Optional[int] = None,
    start_y: Optional[int] = None,
):
    """
    启动桌面宠物。

    Args:
        spritesheet: 精灵图路径
        config: 配置文件路径
        gif_path: 直接加载 GIF 文件路径（优先于 spritesheet/config）
        random_preset: 随机行为预设 (playful/relaxed/curious/active)
        scale: 缩放比例
        enable_tray: 是否启用系统托盘
        enable_watcher: 是否启用 AI agent 状态监听
        status_path: 状态文件路径
        events_path: 事件流文件路径
        start_x/start_y: 初始位置（None则随机）
    """
    global tk
    import tkinter as _tk
    tk = _tk

    # 创建临时根窗口获取屏幕尺寸
    temp = tk.Tk()
    temp.withdraw()
    if start_x is None:
        start_x = random.randint(50, temp.winfo_screenwidth() - 250)
    if start_y is None:
        start_y = random.randint(50, temp.winfo_screenheight() - 300)
    temp.destroy()

    # 如果指定了 gif_path，构造一个 gifMode 配置，不依赖 pet.json
    if gif_path:
        from pathlib import Path as _Path
        import re as _re
        gif_abs = _Path(gif_path).resolve()

        if gif_abs.is_dir():
            # ── 目录模式：扫描所有 GIF，按文件名推断状态名 ──
            gif_files = sorted(gif_abs.glob("*.gif"))
            if not gif_files:
                logger.error(f"目录中没有 GIF 文件: {gif_path}")
                return

            anim_groups: dict[str, list[str]] = {}
            for f in gif_files:
                stem = f.stem
                # 去掉 cat- 前缀（月薪喵命名风格）
                name = stem[4:] if stem.startswith("cat-") else stem
                # 去掉末尾数字后缀（如 -2, -3）
                state = _re.sub(r'-\d+$', '', name) if _re.search(r'-\d+$', name) else name
                anim_groups.setdefault(state, []).append(f.name)

            animations = []
            for state, files in anim_groups.items():
                gif_val = files[0] if len(files) == 1 else files
                animations.append({"name": state, "gif": gif_val, "fps": 6, "repeat": True})

            gif_config = {
                "gifMode": True,
                "gifDir": str(gif_abs),
                "animations": animations,
                "gazes": GAZE_DIRECTIONS,
            }
            logger.info(f"目录模式: 发现 {len(gif_files)} 个 GIF，{len(animations)} 个状态")
        else:
            # ── 单文件模式 ──
            gif_config = {
                "gifMode": True,
                "gifDir": str(gif_abs.parent),
                "animations": [
                    {
                        "name": "idle",
                        "gif": gif_abs.name,
                        "fps": 6,
                        "repeat": True,
                    }
                ],
                "gazes": GAZE_DIRECTIONS,
            }

        # 写临时 pet.json 到父目录，_load_gif_frames 依赖 pet.json 路径定位 gifDir
        gif_parent = gif_abs if gif_abs.is_dir() else gif_abs.parent
        tmp_config = gif_parent / ".desktop-pet-tmp.json"
        with open(tmp_config, "w", encoding="utf-8") as f:
            json.dump(gif_config, f, ensure_ascii=False)
        config = str(tmp_config)

    pet = DesktopPet(
        spritesheet_path=spritesheet,
        config_path=config,
        random_preset=random_preset,
        start_x=start_x,
        start_y=start_y,
        scale=scale,
        enable_tray=enable_tray,
        enable_watcher=enable_watcher,
        status_path=status_path,
        events_path=events_path,
    )
    pet.run()
