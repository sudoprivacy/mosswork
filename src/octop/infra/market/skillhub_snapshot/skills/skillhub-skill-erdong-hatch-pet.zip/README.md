# Hatch Pet - Q版卡通桌面宠物生成器 🐱

一键将人物参考图转化为 **桌面宠物** 的完整工具链，内置月薪喵 15 种动画状态，开箱即用。

🖥️ 支持 **Windows** / **macOS** / **Linux** 三大平台。
🤖 支持 **AI Agent 状态监听**：灵识/Reasonix 等 AI 助手在工具调用前后自动切换宠物动画。
🎞️ 15 种动画状态 + **空闲链降级** + **GIF 定时轮换**，桌面宠物生动不单调。

## ✨ 特性

- 🎨 **Q版卡通风格**：保留人物核心特征（发型、脸型、服装、配饰）
- 🖼️ **用户图片转Q版**：上传任意图片自动生成 Q 版宠物 (`qpet` 命令)
- 🎬 **9 个动画状态**：idle / running / waving / jumping / failed / waiting / working / review
- 👀 **16 方向注视**：360° 全方位注视方向
- 📐 **标准精灵图**：8列×11行, 1536×2288 像素, 单格 192×208
- ✅ **内置校验**：validate_atlas.py 严格校验所有规格
- 📦 **一键打包**：输出 pet.json + spritesheet.webp
- 🎭 **随机行为模式**：调皮/悠闲/好奇/活跃，宠物自主活动
- ✨ **粒子特效**：烟花、爱心、闪光等视觉特效
- 🎯 **跟随鼠标模式**：宠物跟着光标跑
- 👀 **观察模式**：宠物眼睛跟着鼠标转
- 📌 **系统托盘**：最小化到托盘，右击菜单控制
- 🖱️ **拖拽移动**：随意拖动宠物到桌面任意位置
- 🏗️ **跨平台**：Windows + macOS + Linux 原生 tkinter
- 🔄 **空闲链降级**：idle → loafing(60s) → roam(180s) → sleeping(300s) 渐进变化
- 🎞️ **GIF 定时轮换**：持续状态中每 60s 自动轮换 GIF 组

## 📋 精灵图规格

| 参数 | 值 |
|------|-----|
| 列数 × 行数 | 8 × 11 |
| 单格尺寸 | 192 × 208 px |
| 总尺寸 | 1536 × 2288 px |
| 格式 | WebP (RGBA, 透明背景) |
| 动画行 | 9 行（idle, running-right, running-left, waving, jumping, failed, waiting, running, review） |
| 注视行 | 2 行（16 方向：up, up-right(×3), right, down-right(×3), down, down-left(×3), left, up-left(×3)） |
| 配置文件 | pet.json (spriteVersionNumber: 2) |

## 🚀 快速开始

### 安装

```bash
# 基础安装
pip install -e .

# 完整安装（含系统托盘支持）
pip install -e ".[full]"
```

### 月薪喵桌面宠物（GIF 模式，开箱即用）

仓库自带月薪喵 15 种动画素材，安装后直接启动：

```bash
# 一键启动（GIF 模式 + AI 状态监听）
python -m hatch_pet desktop --config output/cat-pet-gif/pet.json --watch

# 或双击仓库里的 Hatch Pet 桌面宠物.bat
```

### 自带素材生成精灵图

```bash
# 生成占位帧精灵图（适合测试）
python -m hatch_pet generate --name "MyPet" --output ./my-pet/

# 桌面显示
python -m hatch_pet desktop --spritesheet ./my-pet/spritesheet.webp --config ./my-pet/pet.json
```

```bash
# 经典Q版风格
python -m hatch_pet qpet --image photo.jpg --name "MyPet" --style chibi_classic

# 萌系Q版（大头大眼）
python -m hatch_pet qpet --image photo.jpg --name "MyPet" --style chibi_cute

# 可用风格: chibi_classic / chibi_cute / chibi_minimal / chibi_pixel / chibi_watercolor
```

### 在桌面显示宠物（AI Agent 状态监听模式）

```bash
# 月薪喵 GIF 模式 + AI 状态监听
python -m hatch_pet desktop --config output/cat-pet-gif/pet.json --watch

# 自定义 GIF 素材
python -m hatch_pet desktop --config your-pet.json --watch

# 精灵图模式 + AI 状态监听
python -m hatch_pet desktop --spritesheet output/spritesheet.webp --config output/pet.json --watch
```

`--watch` 模式会监听 `~/.hatch-pet/status.json` 文件，AI agent（如灵识/Reasonix）在工具调用前后写入该文件，宠物自动切换 15 种动画状态并弹气泡。

**状态映射：**
| 状态 | 动画 | 触发时机 |
|------|------|---------|
| 状态 | 动画 | 触发时机 |
|------|------|---------|
| idle | 待机 🪑 | 空闲 |
| loafing | 摸鱼 🍦 | idle 超过 60s → 自动降级 |
| roam | 闲逛 🚶 | idle 超过 180s → 自动降级 |
| sleeping | 睡觉 😴 | idle 超过 300s → 自动降级 |
| thinking | 思考中 🤔 | 收到消息（2 个 GIF 轮换） |
| working | 工作中 🛠️ | 工具调用（4 个 GIF 轮换） |
| done | 庆祝 🎉 | 工具完成 |
| error | 出错 💥 | 报错 |
| waiting | 等待授权 ✋ | 需要授权 |
| ... | 共 15 种 | |

> 💡 working/thinking/sleeping/loafing 等持续状态中，每 60s 自动轮换到下一组 GIF，避免视觉单调。

### 从图片生成Q版宠物

### 一键生成精灵图

```bash
# 生成桌面宠物（含占位帧，适合测试管线）
python -m hatch_pet generate --name "MyCat" --output ./my-pet/

# 使用参考图（需要 AI 生图支持）
python -m hatch_pet generate --ref reference.png --name "MyCat" --output ./my-pet/
```

### 从帧图片构建

```bash
# 目录结构：
# frames/
#   idle/
#     frame-01.png
#     frame-02.png
#     ...
#   running-right/
#     frame-01.png
#     ...

python -m hatch_pet build --frames-dir ./frames/ --output ./output/
```

### 校验

```bash
# 使用内置校验工具
python validate_atlas.py --image output/spritesheet.webp --config output/pet.json

# 或通过模块
python -m hatch_pet validate --image output/spritesheet.webp --config output/pet.json
```

## 🖥️ 桌面宠物操作指南

| 操作 | 效果 |
|------|------|
| **右键点击** | 打开菜单：切换动画 / 行为模式 / 模式开关 / 特效 / 退出 |
| **左键拖拽** | 移动宠物到桌面任意位置 |
| **双击** | 烟花特效后隐藏到系统托盘 |
| **托盘图标** | 显示/隐藏、切换模式、退出 |

### 行为模式说明

| 模式 | 特点 | 适合 |
|------|------|------|
| 🎭 **调皮模式 (playful)** | 频繁跑动、跳跃、挥手 | 想宠物活跃一点 |
| 😴 **悠闲模式 (relaxed)** | 主要是待机，偶尔挥手 | 不想太打扰工作 |
| 🔍 **好奇模式 (curious)** | 到处探索、频繁移动 | 让宠物探索桌面 |
| ⚡ **活跃模式 (active)** | 忙碌工作、审阅、不停活动 | 想要热闹的感觉 |

### 高级模式

- **跟随鼠标**：右键菜单 → "跟随鼠标"，宠物跟着光标移动
- **观察模式**：右键菜单 → "观察模式"，宠物眼睛跟着鼠标转
- **烟花特效**：右键菜单 → "放烟花"
- **爱心特效**：右键菜单 → "爱心特效"

## 📁 项目结构

```
DesktopBuddy/
├── hatch_pet/                  # 核心包
│   ├── __init__.py              # 包入口 (v2.5.0)
│   ├── __main__.py              # CLI 主入口 (generate/qpet/desktop/validate/build)
│   ├── config.py                # 配置常量（尺寸、动画状态、方向）
│   ├── pet_config.py            # pet.json 生成与校验
│   ├── sprite_builder.py        # 精灵图拼接构建器
│   ├── frame_generator.py       # 占位帧生成器
│   ├── desktop_renderer.py      # 桌面渲染器（增强版，支持 GIF 模式）
│   ├── animation_engine.py      # 动画引擎（缓动、过渡、粒子）
│   ├── q_pet_converter.py       # 图片转Q版宠物
│   ├── random_mode.py           # 随机行为引擎
│   └── status_watcher.py        # AI Agent 状态监听
├── assets/                      # 素材
│   ├── cat/                     # 月薪喵 GIF 素材（15 种状态，24 个文件）
│   │   ├── cat-idle.gif
│   │   ├── CREDITS.md           # 版权声明（勿商业，二创需@月薪喵）
│   │   └── ...
│   ├── cat-icon.ico             # 月薪喵桌面图标
│   └── icon.ico                 # LLMPET 图标
├── output/
│   └── cat-pet-gif/
│       └── pet.json             # 月薪喵 15 状态配置（GIF 模式）
├── scripts/
│   └── convert_cat_to_spritesheet.py  # GIF→精灵图转换工具
├── launch_pet.py                # 桌面快捷方式启动器
├── Hatch Pet 桌面宠物.bat       # Windows 启动脚本
├── validate_atlas.py            # 精灵图校验工具
├── pyproject.toml               # 项目配置
├── requirements.txt             # 依赖
└── README.md                    # 本文件
```

## 🔧 开发

```bash
# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest tests/ -v
```

## 📝 输出文件

- `pet.json` — Codex 宠物配置文件
- `spritesheet.webp` — 精灵图（8列×11行）
- `{name}-hatch-pet.zip` — 打包文件（可直接安装）

## 🎨 Q版风格一览

| 风格 | 描述 |
|------|------|
| `chibi_classic` | 经典Q版 - 平衡的头身比和配色 |
| `chibi_cute` | 萌系Q版 - 超大头部、超大眼、鲜艳配色 |
| `chibi_minimal` | 简约Q版 - 干净利落的线条和色彩 |
| `chibi_pixel` | 像素Q版 - 复古像素风 |
| `chibi_watercolor` | 水彩Q版 - 柔和的水彩画风格 |

## 📄 License

MIT
