# SkillHub 发布流程

## 快速发布

```bash
# 1. 登录（只需一次）
skillhub login --key skh_...

# 2. 确保 SKILL.md frontmatter 包含：
#    - name（必须）
#    - slug（必须，与 name 一致即可）
#    - displayName（必须，中文显示名）
#    - description（必须）
#    - version（推荐）

# 3. 预检
skillhub publish <path> --dry-run

# 4. 发布
skillhub publish <path> --changelog "vX.X.X: 变更说明"
```

## 常见错误

| 错误 | 原因 | 修复 |
|------|------|------|
| `缺少 slug` | frontmatter 没有 slug 字段 | 添加 `slug: xxx` |
| `缺少 displayName` | frontmatter 没有 displayName 字段 | 添加 `displayName: 中文显示名` |
| `登录失败` | 未登录或 token 过期 | `skillhub login --key skh_...` |

## 安装 CLI

```bash
curl -fsSL https://skillhub.cn/install/install.sh | bash -s -- --cli-only
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
```
