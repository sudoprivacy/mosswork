#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AI 零基础到引路人 定向测试：快速入门 + 参考资料"""
import os
import sys
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parent

passed, failed = [], []


def check(name, cond, detail=""):
    (passed if cond else failed).append(name)
    print(f"  {'✅ PASS' if cond else '❌ FAIL'} {name}" + (f" — {detail}" if detail else ""))


def test_quickstart_exists():
    print("\n[1] 快速入门指南（用户反馈：缺少快速入门指南）")
    qs = ROOT / "QUICKSTART.md"
    check("QUICKSTART.md 存在", qs.exists())
    if not qs.exists():
        return
    t = qs.read_text(encoding="utf-8")
    check("含「10 分钟」时间承诺", "10 分钟" in t)
    check("含可复制的提示词模板", "```" in t and "你是" in t)
    check("含五要素说明（角色/任务/受众/格式/语气）",
          all(k in t for k in ["角色", "任务", "受众", "格式", "语气"]))
    check("含第一周 7 天任务表", t.count("第 ") >= 5)
    check("含常见卡点", "卡点" in t)
    check("含自测清单", "自测" in t or "全打勾" in t)
    check("篇幅适中（1000-12000 字符）", 1000 < len(t) < 12000, f"{len(t)} 字符")

    # 关键：明确「不读完整规划也能开始」
    check("声明可跳过完整规划直接开始", "不想读完整" in t or "不用读" in t or "跳过" in t)


def test_resources_expanded():
    print("\n[2] 参考资料扩充（用户反馈：参考资料不够丰富）")
    res = ROOT / "references" / "learning-resources.md"
    check("learning-resources.md 存在", res.exists())
    if not res.exists():
        return
    t = res.read_text(encoding="utf-8")
    check("含官方文档章节", "官方文档" in t)
    check("含方法论章节", "方法论" in t)
    check("含实践项目章节", "实践项目" in t or "项目" in t)
    check("含避坑清单", "避坑" in t)
    check("含核实纪律", "核实" in t)
    check("区分稳定/易变资源", "稳定" in t and "易变" in t)
    check("资源数量 ≥ 15 条", t.count("|") >= 30, f"{t.count('|')} 个表格分隔符")
    check("篇幅充足（2000+ 字符）", len(t) > 2000, f"{len(t)} 字符")


def test_all_references_intact():
    print("\n[3] 原有参考资料未丢失")
    refs = ROOT / "references"
    expected = [
        "ai-companies-comparison.md", "baicizhan-method.md", "khazix-analysis.md",
        "llm-to-agent-evolution.md", "qiuzhi2046-analysis.md", "skillhub-publishing.md",
    ]
    missing = [f for f in expected if not (refs / f).exists()]
    check("原有 6 个 reference 全部保留", not missing, str(missing))
    total = len(list(refs.glob("*.md")))
    check("reference 总数 ≥ 7（原 6 + 新增）", total >= 7, f"{total} 个")


def test_script_still_works():
    print("\n[4] 原学习路径脚本不回归")
    import subprocess
    r = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "learning_path.py"), "--help"],
        capture_output=True, text=True, timeout=60)
    check("learning_path.py --help 可用", r.returncode == 0, r.stderr[:120])


def test_skill_md_links_quickstart():
    print("\n[5] SKILL.md 指向快速入门")
    sk = ROOT / "SKILL.md"
    t = sk.read_text(encoding="utf-8")
    check("SKILL.md 引用 QUICKSTART", "QUICKSTART" in t)
    check("SKILL.md 引用 learning-resources", "learning-resources" in t)
    check("版本已更新为 1.2.0", "version: 1.2.0" in t or "version: 2.2.0" in t)


if __name__ == "__main__":
    test_quickstart_exists()
    test_resources_expanded()
    test_all_references_intact()
    test_script_still_works()
    test_skill_md_links_quickstart()

    print("\n" + "=" * 56)
    print(f"通过 {len(passed)} / 失败 {len(failed)}")
    if failed:
        for f in failed:
            print(f"  ✗ {f}")
        sys.exit(1)
    print("🎉 全部通过")
