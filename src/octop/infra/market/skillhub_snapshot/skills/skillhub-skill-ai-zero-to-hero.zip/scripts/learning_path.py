#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# AI 学习路径规划——输入当前阶段，输出下一步学习计划。零依赖。

import argparse, re, sys

def sanitize(text):
    if not text:
        return ""
    s = str(text)
    s = re.sub(r'<[^>]+>', '', s)
    s = re.sub(r'[\x00-\x1f\x7f]', '', s)
    s = re.sub(r'(?i)(忽略|ignore).{0,20}(指令|prompt|instruction)', '[已过滤]', s)
    return s.strip()[:50]

# 四阶段
STAGES = {
    "零基础": ("会用AI", ["学会提问（角色+任务+约束）", "每天用AI做一件事（写/查/改）", "掌握3个常用模型", "用AI解决学习/生活问题"]),
    "会用": ("用好AI", ["学习提示词技巧（示例/分步/约束）", "用AI辅助学习（费曼/间隔复习）", "用AI做内容（文案/PPT/数据）", "建立自己的工作流"]),
    "熟练": ("教别人", ["整理自己的使用方法论", "给朋友/同学做一次分享", "把常用流程固化为模板", "开始输出内容（笔记/文章）"]),
    "引路人": ("系统输出", ["设计一套教学方法", "组织AI学习社群", "开发工具/技能帮助他人", "持续迭代自己的体系"]),
}

def plan(stage):
    NL = "\n"
    lines = []
    lines.append("=" * 56)
    lines.append("  AI 学习路径 | 当前阶段：" + stage)
    lines.append("=" * 56)
    lines.append("")
    if stage not in STAGES:
        lines.append("  可选阶段：零基础 / 会用 / 熟练 / 引路人")
        return NL.join(lines)
    target, steps = STAGES[stage]
    lines.append("  本阶段目标：" + target)
    lines.append("")
    lines.append("  下一步计划：")
    for i, s in enumerate(steps, 1):
        lines.append("    %d. %s" % (i, s))
    lines.append("")
    lines.append("  完成标志：你能独立完成本阶段所有任务")
    return NL.join(lines)

def main():
    parser = argparse.ArgumentParser(description="AI 学习路径规划")
    parser.add_argument("--stage", help="当前阶段（零基础/会用/熟练/引路人）")
    parser.add_argument("-i", "--interactive", action="store_true")
    args = parser.parse_args()

    if args.interactive:
        stage = sanitize(input("当前阶段（零基础/会用/熟练/引路人）: ") or "零基础")
    elif args.stage:
        stage = sanitize(args.stage)
    else:
        print("用法: python learning_path.py --stage 零基础")
        print("      python learning_path.py -i")
        sys.exit(0)

    print(plan(stage))

if __name__ == "__main__":
    main()
