# -*- coding: utf-8 -*-
r"""
C 盘清理 / 数据迁移工具（双击即用）v1.14 安全版

一、一键清理（均为可再生缓存/残留，不含任何文档/账号数据）：
  1. WorkBuddy 自身更新残留（更新器 installer.exe / Setup 解压目录 / 旧备份）
  2. TEMP 临时目录（跳过 30 分钟内新建、正被占用的文件）
  3. WPS 缓存与备份（backup/cache/log/addons/download）
  4. VS / Edge / 系统可再生缓存（ComponentModelCache、Edge 网页缓存、Explorer 缩略图缓存）
  5. 开发缓存：pip cache + npm-cache（可重建）
  6. 固定临时目录 F:\WorkBuddy\AgentTemp

二、软件卸载残留：扫描常见软件，若本体已卸载则清理其在 AppData 的遗留目录。
   v1.7 起：安装检测新增注册表卸载项反查（装在 D/E 盘自定义路径也能识别），
   且聊天记录类路径（Tencent Files / WeChat Files / xwechat_files）删除前强制二次确认。

三、软件更新残留：清理常见软件更新后遗留的安装包 / 下载缓存目录。
   v1.7 起：含 QMDownload 等可能存放接收文件的目录，删除前二次确认。

四、数据转移（弹框选目标盘）：把聊天记录 / 网盘 / 开发工具等大目录搬到目标盘，
   删除 C 盘原件，并在原位置建立 junction 链接 —— 软件仍能按原路径正常读写，同时腾出 C 盘空间。
   v1.8 加固：①迁移前真检测微信/QQ/企微等进程；②robocopy 加 /XJ，不跟随源目录里的 junction
   （否则会把已迁走的微信数据又复制一份），复制后在目标盘原样重建这些内部链接；
   ③完整性校验改为「文件数 + 大小」双对比，缺一个文件就中止，绝不删原件
   （原逻辑要差 200MB 才拦，少量丢失检测不到，删完原件就永久没了）。
   v1.11 起流程改为「复制 → 校验 → 原子改名 → 建链接 → 删旧数据（善后）」：
   先改名腾空原位、立刻建链接让软件可用，**删除降级为可失败的善后步骤**，
   彻底杜绝"原件被 rmtree 删掉一半、链接又没建成"导致的数据损毁。

五、WorkBuddy 数据迁移：把 %USERPROFILE%\.workbuddy（AI 助手运行时数据：模型、插件、会话等）
   搬到其它盘并在原位建 junction。需先完全退出 WorkBuddy，工具会检测进程并弹框拦截。

六、数据恢复：功能 4 / 5 迁移后若软件读不到数据（如微信聊天记录没了），
   用这项把目标盘副本复制回原位置。全程只复制、绝不删除。

命令行非交互模式（供 skill/agent 调用，不带参数则进交互菜单）：
  c_cleaner.py clean | uninstall | update | migrate | wb | restore | all
  （也可用菜单编号 1~7；all = clean + uninstall + update，不含需要交互的迁移/恢复项）

版本历史：
  v1.14 后台进程自动杀，别再问用户了（同事故 2.0："我同事没开QQ啊"）：
        现象：同事恢复后再次迁移，弹框检测到 QQProtect.exe 仍在运行，
              同事点"是"放行，结果改名仍被锁 (WinError 5)，整个迁移中止。
              同事原话："他并没有打开qq啊" —— 实际是 QQProtect 等无窗口后台服务。
        旧设计的问题：弹框问"要杀吗？仍要继续吗？"让用户选 —— 用户根本看不到
              这些后台服务、不知道该不该杀，让他们选 = 折磨。两个弹框（同事故
              同事 7GB 等了 10 分钟）就为问一个"你确认我帮你杀吗？"，毫无意义。
        修复：① 进程检测 → 弹框"是否开始迁移？" → **用户点 是 就直接 taskkill /T /F
                全部结束**（/T 带子进程防拉起），不再二次询问；
              ② 杀不掉（带驱动保护的系统服务）才弹框说"请重启电脑"；
              ③ 改名失败时**再杀一轮 + 重试一次**，给最后一个机会；
              ④ MIGRATE_BLOCK_PROCESSES 从 18 个补到 27 个
                （新增 TencentProtect / QQSafeTray / QQMicroGameBox / TXAssist /
                QQFileTransfer / qmext / QQWeChat / QQBrowser 等常见的腾讯家进程）；
              ⑤ do_migrate 开场提示语改为"没关也没关系，工具会自动清"，降低同事的紧张感。
        设计原则：**杀后台服务不该问用户**。这些进程是用户看不见也管不了的，
              工具能力范围内就该自动处理。问用户 = 把工具的职责甩给用户。
  v1.13 恢复功能去个性化（用户质疑"是不是按我同事那个错误固定了路径"）：
        核查结论：核心修复（v1.11 改名优先）是纯逻辑改动、与路径无关；
                  原位一律由 %APPDATA% / %LOCALAPPDATA% / %USERPROFILE% 派生，
                  全脚本 0 处硬编码用户名或盘符（"D:\appdata" 只出现在举例文字里）。
        但确实有两处「覆盖面窄」，已扩宽：
          ① 盘符：原为写死的 "DEFGHIJKLMN" → 改为 _logical_drives() 动态枚举
             所有可用盘符（C~Z，跳过 A/B 软驱防卡），U 盘 / 移动硬盘也能扫到；
          ② 落点：原只扫 <盘>:\appdata\<名字> —— "appdata" 其实来自同事那台的目录名，
             现扩到 RESTORE_SUBDIR_HINTS（appdata/AppData/backup/数据/备份/Data/
             MigrationData/WorkBuddyData/migrate 等）+ 各盘根目录直放；
          ③ **新增扫 <原位>.__cc_moving**：v1.11 改名成功但清理失败时，
             数据就在这个残留目录里 —— 这是本工具自己造成的最可能落点，原先漏了。
        设计原则：自动扫描只做"尽力推断"，**永远保留手动选择兜底**，
                  这样任何人的目录习惯都能覆盖。
  v1.12 数据恢复合并进主菜单（用户指出"这就是你工具自己造成的问题，为什么分开"）：
        原本把恢复功能做成独立 exe「微信数据恢复助手」，用户一句话点醒：
        问题是本工具造成的，恢复就该是它自己的一个功能；分开反而多一个拿错 exe 的风险
        （同事此前正是拿错了旧版 exe 才出事）。现合并为主菜单 [6]「数据恢复」，
        一个 exe 全搞定，独立 exe 不再分发。
        实现：`do_restore()` 复用已有 `_count_files` / `_size_of` / `_browse_for_folder` /
        `_read_junction_target`，自动扫描所有盘符的「根目录直放 / 常见子目录 /
        v1.11 改名残留 .__cc_moving」三类位置找出副本（扫不到可手动选），
        列出「原位 ← 副本」并标注状态（原位空 / 文件数少于副本 / 已是链接），
        用户选一项即可恢复；也支持手动指定。**只复制绝不删除**
        （robocopy `/E /XJ`，不带 /MIR、不带 /PURGE）。
        菜单编号重排：[6] 数据恢复、[7] 全部清理；CLI 新增 `restore`（`all` 改为 7）。
  v1.11 【重大安全修复】迁移失败导致原件被毁（同事微信聊天记录丢失，实锤事故）：
        现象：同事跑功能 4，最后一步提示"[失败] 原目录删除失败"，
              随后发现微信登录上去聊天记录全没了 —— 数据去了 D 盘，但原位没建成链接。
        根因：旧流程是「复制 → 校验 → 直接删原件 → 建链接」。
              删除用的是 shutil.rmtree，它是**边删边走**的：能删的先删掉，
              遇到被占用文件由 _rmtree_onexc 吞掉异常继续删下一个，
              最后因残留几个占用文件导致 os.path.exists(src) 为真 → 判定"删除失败"→ 不建链接。
              **但此时原目录已经被删掉一大半了！**
              此前"迁移失败也保证安全"只保住了目标盘副本，没保住 C 盘原件 —— 设计缺陷。
        修复：改为「复制 → 校验 → **原子改名** → 建链接 → 删旧数据（善后）」：
              ① os.rename(src, src+".__cc_moving")：NTFS 同卷改名瞬时完成、几乎不可能失败；
              ② 改名成功即腾空原位置，立刻建 junction —— 软件**毫秒级**恢复可用；
              ③ 删除旧目录降级为「事后清理」，失败也只影响 C 盘空间，**绝不再毁数据**；
              ④ 建链接万一失败 → rename 回滚，一个字节都没丢；
              ⑤ 若发现上次留下的 .__cc_moving 残骸，先弹框说明再决定是否清理，绝不盲删。
        教训（通用）：**任何"先删再建"的流程都是错的**。
              正确顺序永远是「先让新路径可用，再清理旧路径」，
              且清理必须是可失败、可重试、不影响功能的善后步骤。
              同理，绝不要用 rmtree 做"能否删除"的试探 —— 它失败时已经删掉一部分了。
  v1.10 后台进程占用修复（同事实锤："我都退出了 app，还是转移失败"）：
        现象：robocopy 复制成功、完整性校验通过，最后一步「删除 C 盘原目录」失败，
              界面停在"[失败] 原目录删除失败（可能被占用）"，C 盘没腾出空间。
        根因：用户只关了「有窗口的主程序」（WeChat.exe / QQ.exe / WXWork.exe），
              腾讯系还有一批无窗口的后台服务仍在写文件：
              QQProtect / QQPCRTP / TXPlatform / QQMail / QQMicroGameBoxTray /
              WeChatUpdate / WeChatAppEx / WeChatPlayer / WXWorkWorkbench /
              QQExternal / QQAppLauncher。
              且 v1.9 只在 do_migrate() 开头查一次进程 —— 7GB 复制要 5~10 分钟，
              开头查干净不代表删的时候还干净，后台服务中途会重新握把柄。
        修复：①MIGRATE_BLOCK_PROCESSES 从 7 个补全到 18 个（含全部后台服务）；
              ②新增 _ensure_no_locks()：在「删原件之前」重新检测进程，
                命中就列出具体进程名，提供一键 taskkill（弹框询问），
                结束后 sleep 2s 等系统释放句柄，再复查一次；
              ③新增 _remove_with_retry()：删除失败重试 3 次（每次 3 秒），
                扛住 Defender 实时扫描 / explorer 缩略图这类「瞬时占用」；
                （原来一次失败就放弃，用户白等 10 分钟复制）
              ④失败提示改为可操作指引："重启电脑后重跑，选同一目标文件夹即可续完"。
        教训：Windows 上"关掉软件"≠"文件句柄已释放"，凡是要删别人正在写的目录，
              都必须列全后台服务名 + 在删除动作前（而不是流程开头）再查一次。
  v1.9 弹窗置顶（用户反馈"按了 Alt+Tab 才转移"后修复）：
        _msgbox / _msgbox_yesno / _browse_for_folder 三个弹窗全部改用
        GetConsoleWindow() 拿到 cmd 窗口句柄作为父窗口，加 MB_SETFOREGROUND +
        MB_TOPMOST 标志，并在弹窗前先 SetForegroundWindow(控制台)，
        保证弹窗出现在前台且不会被其它窗口盖住。
  v1.8 数据转移加固（同事反馈"图片丢了、7 天以上无法重下"后专项排查）：
        修复：robocopy 未加 /XJ，会跟随源目录里的 junction（如 Tencent\xwechat -> E 盘）
              把已迁移走的数据整份再复制一遍到目标盘（空间浪费 + 预检误判）。
              现改为 /XJ 跳过，复制后用 _rebuild_inner_junctions() 在目标盘原样重建，
              避免删掉原件后链接断裂、软件找不到数据。
        修复：完整性校验原为「差 >200MB 且 <95%」才拦截，少量丢失（多半是被占用的缓存/配置）
              检测不到，删掉原件后那部分就永久没了。现改为 _count_files() 文件数对比，
              缺一个文件就中止；大小差 >10MB 同样中止，绝不删原件。
        新增：迁移前用 tasklist 真检测微信/QQ/企微/百度网盘/PyCharm 进程并弹框拦截
              （原来只有文字提示，用户没关也不知道）。
        新增：_size_of() 跳过 junction，口径与 /XJ、_try_remove 一致（防止重复计入）。
  v1.7 安全加固（同事反馈"会不会删掉 QQ 聊天记录图片"后专项修复）：
        修复：_is_app_installed() 只扫 4 个固定程序目录，装在 D/E 盘或自定义路径的软件会被
              误判为"已卸载"，进而删除其 Documents 下的聊天记录。现新增注册表卸载项反查兜底，
              并为各软件补中文名（注册表 DisplayName 多为中文）。
        新增：DANGEROUS_HINTS 高危路径清单 + _confirm_dangerous() 二次确认。
              命中 Tencent Files / WeChat Files / xwechat_files / QMDownload / FileRecv 时，
              删除前弹框明确告知"这可能是聊天记录、图片或接收的文件，删除后无法恢复"。
        原则：宁可漏清残留，绝不误删用户数据。
  v1.6 新增：功能 5「WorkBuddy 数据迁移」（独立菜单，进程检测 + 三重确认 + 已迁移自动识别）。
            修复：_migrate_dir() 函数级加入重解析点预检——此前仅 do_migrate() 循环层有跳过，
            单独调用会穿透 junction 把目标盘真实数据重复复制成套娃目录。
            修复：补齐命令行非交互模式（clean/uninstall/update/migrate/wb/all）。此前 SKILL.md
            已声明支持但代码未实现 sys.argv 分发，带参数运行会掉进交互菜单、input() 遇 EOF 静默退出，
            实际一个字节都没清理。
  v1.5 加固：数据转移——删除原目录前先校验目标副本完整性（大小对比）；删除原目录失败时保留目标副本（原 v1.4 会删副本，若原目录已删一半则可能丢数据）。
  v1.4 修复：功能 4 在 64 位系统选完路径闪退（ctypes 未声明 restype 致 PIDL 指针截断）；_is_reparse_point 对不存在路径误报；新增迁移前空间预检（统计总大小 + 目标盘剩余空间弹框）。
  v1.3 新增：菜单交互、pip/npm 缓存清理、软件卸载残留清理、软件更新残留清理、数据转移（ctypes 原生弹框 + robocopy + junction）。
  v1.2.1 修复：只读文件/目录无法删除（重试前自动去只读属性）。
  v1.2 新增：WorkBuddy 更新残留清理。
  v1.1 移除：Windows 更新下载缓存（曾致同事电脑蓝屏，系统级目录不碰）。
"""
import os
import stat
import sys
import time
import shutil
import ctypes
import subprocess
from ctypes import wintypes

AGENT_TEMP = r"F:\WorkBuddy\AgentTemp"   # 固定可清理目录（写死进 exe）

APPDATA = os.environ.get("APPDATA", "")
LOCALAPP = os.environ.get("LOCALAPPDATA", "")
USERPROFILE = os.environ.get("USERPROFILE", "")
WINDIR = os.environ.get("WINDIR", r"C:\Windows")
ROBOCOPY = os.path.join(WINDIR, "System32", "robocopy.exe")

_stats = {"bytes": 0, "files": 0, "skipped": 0}


# ---------------------------------------------------------------------------
# 原生 Windows 弹框（ctypes，不引入 tkinter/PySide6，保持 exe 轻量）
# ---------------------------------------------------------------------------
# 弹框置顶相关标志
MB_SETFOREGROUND = 0x00010000   # 强制切到前台
MB_TOPMOST = 0x00040000         # 窗口置顶，不会被其它窗口盖住


def _console_hwnd():
    """取当前控制台窗口句柄。弹框挂到它身上，就不会躲到 cmd 后面找不着"""
    try:
        return ctypes.windll.kernel32.GetConsoleWindow()
    except Exception:
        return 0


def _bring_console_front():
    """弹框前先把控制台提到前台，保证用户能看到上下文"""
    try:
        h = _console_hwnd()
        if h:
            ctypes.windll.user32.SetForegroundWindow(h)
    except Exception:
        pass


def _browse_for_folder(title="请选择目标文件夹"):
    """弹文件夹选择框，返回所选路径或 None"""
    try:
        shell32 = ctypes.windll.shell32
        ole32 = ctypes.windll.ole32

        class BROWSEINFO(ctypes.Structure):
            _fields_ = [
                ("hwndOwner", wintypes.HWND),
                ("pidlRoot", ctypes.c_void_p),
                ("pszDisplayName", ctypes.c_wchar_p),
                ("lpszTitle", ctypes.c_wchar_p),
                ("ulFlags", ctypes.c_uint),
                ("lpfn", ctypes.c_void_p),
                ("lParam", ctypes.c_void_p),
                ("iImage", ctypes.c_int),
            ]

        disp = ctypes.create_unicode_buffer(260)
        bi = BROWSEINFO()
        bi.hwndOwner = _console_hwnd()  # 绑控制台窗口，弹框就显示在 cmd 附近，不会跑丢
        bi.pidlRoot = None
        bi.pszDisplayName = ctypes.cast(disp, ctypes.c_wchar_p)
        bi.lpszTitle = title
        bi.ulFlags = 0x0001 | 0x0040 | 0x0010  # 只显示文件夹 | 新样式 | 可输入路径

        # 关键修复：必须声明 64 位指针返回类型。ctypes 默认 restype 是 32 位 int，
        # 64 位系统上 SHBrowseForFolderW 返回的 PIDL 指针会被截断，
        # 导致 SHGetPathFromIDListW 收到坏指针（崩溃或取路径失败，选完路径就退出）
        shell32.SHBrowseForFolderW.restype = ctypes.c_void_p
        shell32.SHBrowseForFolderW.argtypes = [ctypes.POINTER(BROWSEINFO)]
        shell32.SHGetPathFromIDListW.restype = wintypes.BOOL
        shell32.SHGetPathFromIDListW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
        ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]

        pidl = shell32.SHBrowseForFolderW(ctypes.byref(bi))
        if not pidl:
            return None
        buf = ctypes.create_unicode_buffer(260)
        ok = shell32.SHGetPathFromIDListW(pidl, buf)
        ole32.CoTaskMemFree(pidl)
        return buf.value if ok else None
    except Exception:
        return None


def _msgbox(title, text, flags=0x40):
    """信息框（默认 MB_ICONINFORMATION | MB_OK）。绑控制台 + 置顶，避免被 cmd 窗口盖住"""
    _bring_console_front()
    try:
        ctypes.windll.user32.MessageBoxW(_console_hwnd(), text, title,
                                         flags | MB_SETFOREGROUND | MB_TOPMOST)
    except Exception:
        pass


def _msgbox_yesno(title, text):
    """是/否 确认框，返回 True=是。绑控制台 + 置顶"""
    _bring_console_front()
    try:
        MB_YESNO = 0x04
        MB_ICONQUESTION = 0x20
        r = ctypes.windll.user32.MessageBoxW(_console_hwnd(), text, title,
                                              MB_YESNO | MB_ICONQUESTION
                                              | MB_SETFOREGROUND | MB_TOPMOST)
        return r == 6  # IDYES
    except Exception:
        return False


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------
def _rmtree_onexc(func, path, excinfo):
    """shutil.rmtree 回调：遇到只读文件时去掉只读属性再重试"""
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except OSError:
        pass


def _try_remove(path):
    """删除单个文件/目录，跳过被占用的；遇到只读文件会先去掉只读属性。
    关键安全点：遇到 symlink/junction（重解析点）只删链接点本身，绝不递归删除目标数据。"""
    try:
        # 链接（symlink / junction）：只删链接点，绝不动目标真实数据
        if os.path.islink(path) or _is_reparse_point(path):
            try:
                os.remove(path)
            except OSError:
                os.rmdir(path)
            return not os.path.exists(path)
        if os.path.isfile(path):
            os.chmod(path, stat.S_IWRITE)
            os.remove(path)
            return True
        if os.path.isdir(path):
            shutil.rmtree(path, onexc=_rmtree_onexc)
            return not os.path.exists(path)
    except OSError:
        pass
    return False


def _size_of(path):
    """统计大小。跳过 junction/symlink 的内容——与 robocopy /XJ 不复制链接内容、
    _try_remove 只删链接点的行为口径一致，否则会把别处已迁移的数据重复计入。"""
    if _is_reparse_point(path):
        return 0
    total = 0
    if os.path.isfile(path):
        try:
            return os.path.getsize(path)
        except OSError:
            return 0
    for root, dirs, files in os.walk(path, onerror=lambda e: None):
        dirs[:] = [d for d in dirs if not _is_reparse_point(os.path.join(root, d))]
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def _count_files(path):
    """统计文件数（同样跳过 junction），用于迁移后的完整性校验"""
    n = 0
    for root, dirs, files in os.walk(path, onerror=lambda e: None):
        dirs[:] = [d for d in dirs if not _is_reparse_point(os.path.join(root, d))]
        n += len(files)
    return n


def clean_dir_contents(dirpath, label):
    """清空目录内容（保留目录本身）"""
    freed = 0
    count = 0
    if not os.path.isdir(dirpath):
        return freed, count, 0
    for name in os.listdir(dirpath):
        p = os.path.join(dirpath, name)
        before = _size_of(p)
        if _try_remove(p):
            freed += before
            count += 1
        else:
            _stats["skipped"] += 1
    print("  [OK] %-42s 释放 %8.1f MB" % (label, freed / 1024**2))
    return freed, count, 0


def clean_dir_fully(dirpath, label):
    """整个目录删除（连同目录）"""
    if not os.path.exists(dirpath):
        return 0
    before = _size_of(dirpath)
    if _try_remove(dirpath):
        print("  [OK] %-42s 释放 %8.1f MB" % (label, before / 1024**2))
        return before
    else:
        print("  [跳过] %-40s (占用中或被安全策略拦截)" % label)
        _stats["skipped"] += 1
    return 0


def _is_reparse_point(path):
    """检测路径是否为 junction/symlink（重解析点）"""
    try:
        attrs = ctypes.windll.kernel32.GetFileAttributesW(path)
        # ctypes 默认按有符号 int 返回，路径不存在时是 0xFFFFFFFF（即 -1），两种形式都要排除，
        # 否则 -1 & 0x400 != 0 会误报成"是链接"导致目录被错误跳过
        if attrs == 0xFFFFFFFF or attrs == -1:
            return False
        return bool(attrs & 0x400)  # FILE_ATTRIBUTE_REPARSE_POINT
    except Exception:
        return False


def _make_junction(link_path, target_path):
    """用内置 _winapi.CreateJunction 建 junction（无需管理员权限，不依赖外部命令）
    参数顺序：CreateJunction(目标真实目录, 要创建的链接路径)。"""
    try:
        import _winapi
        _winapi.CreateJunction(target_path, link_path)  # (目标, 链接)
        return os.path.isdir(link_path) and _is_reparse_point(link_path)
    except Exception:
        return False


def _read_junction_target(link_path):
    """读 junction 指向的真实路径（去掉 \\\\?\\ 前缀）；失败返回 ''"""
    try:
        t = os.readlink(link_path)
        return t[4:] if t.startswith("\\\\?\\") else t
    except Exception:
        return ""


def _rebuild_inner_junctions(src, dst):
    """robocopy /XJ 会跳过源目录里的 junction，复制后在目标盘原样重建，
    否则删掉原件后软件会找不到已迁移走的数据（链接断裂）"""
    made = 0
    try:
        names = os.listdir(src)
    except OSError:
        return 0
    for name in names:
        sp = os.path.join(src, name)
        if not (os.path.isdir(sp) and _is_reparse_point(sp)):
            continue
        dp = os.path.join(dst, name)
        if os.path.exists(dp):
            continue
        tgt = _read_junction_target(sp)
        if tgt and os.path.isdir(tgt):
            if _make_junction(dp, tgt):
                made += 1
                print("      重建内部链接：%s -> %s" % (name, tgt))
    return made


def _running_processes(names):
    """检测给定进程名是否有在运行，返回正在运行的进程名列表"""
    running = []
    try:
        out = subprocess.run(["tasklist"], capture_output=True, timeout=60)
        txt = (out.stdout or b"").decode("gbk", errors="ignore").lower()
        for n in names:
            if n.lower() in txt:
                running.append(n)
    except Exception:
        pass
    return running


def _kill_processes(names, kill_tree=False):
    """强制结束给定进程，返回成功结束的进程名列表。

    kill_tree=True 时加 /T 参数，连子进程一起杀（防止 QQProtect 拉起 QQPCRTP 等）。
    taskkill 语法必须是 `taskkill /F [/T] /IM <name>` 或 `taskkill /F /IM <name> /T`，
    /T 夹在 /IM 中间是无效的。
    """
    killed = []
    for n in names:
        try:
            if kill_tree:
                cmd = ["taskkill", "/F", "/T", "/IM", n]
            else:
                cmd = ["taskkill", "/F", "/IM", n]
            r = subprocess.run(cmd, capture_output=True, timeout=30)
            if r.returncode == 0:
                killed.append(n)
        except Exception:
            pass
    return killed


# 迁移前最好先退出的软件（运行中会导致文件被占用、复制不完整）
# v1.10 关键修复：用户只关了「有窗口的主程序」，下面这些没窗口的后台服务
#   仍在写文件 —— 同事实锤场景："我都退出了 app，还是转移失败"，
#   最后一步删原目录时 QQProtect / TXPlatform / WeChatUpdate 等仍握着文件句柄。
# v1.14：继续扩。同事迁移 Tencent 时即便已确认关闭所有有窗口的程序，
#   改名依然被锁 (WinError 5) —— 我们列出的 18 个还不够全。再补齐一截。
MIGRATE_BLOCK_PROCESSES = [
    # ---- 主程序（有窗口，用户一般会主动关）----
    "WeChat.exe", "Weixin.exe", "QQ.exe", "QQNT.exe",
    "WXWork.exe", "baidunetdisk.exe", "pycharm64.exe",
    "QQBrowser.exe",                      # v1.14 新增：QQ 浏览器独立产品
    # ---- 腾讯系后台服务（无窗口，用户看不见也关不掉）v1.10 / v1.14 持续补齐 ----
    "QQProtect.exe",           # QQ 安全保护进程，常驻
    "TencentProtect.exe",      # v1.14 新增：新版腾讯保护（有些机器是这个名字）
    "QQPCRTP.exe",             # QQ 电脑管家 / 防护进程
    "QQSafeTray.exe",          # v1.14 新增：QQ 安全托盘
    "TXPlatform.exe",          # 腾讯平台服务
    "QQMail.exe",              # QQ 邮箱客户端，后台常驻
    "QQMicroGameBoxTray.exe",  # QQ 游戏盒子托盘
    "QQMicroGameBox.exe",      # v1.14 新增：不带 Tray 的版本
    "WeChatUpdate.exe",        # 微信更新服务
    "WeChatAppEx.exe",         # 微信小程序 / 内置浏览器
    "WeChatPlayer.exe",        # 微信内置播放器
    "WXWorkWorkbench.exe",     # 企业微信工作台
    "QQExternal.exe",          # QQ 外部进程
    "QQAppLauncher.exe",       # QQ 应用启动器
    "TXAssist.exe",            # v1.14 新增：腾讯助手
    "QQFileTransfer.exe",      # v1.14 新增：QQ 文件传输服务
    "qmext.exe",               # v1.14 新增：QQ 小程序引擎
    "QQWeChat.exe",            # v1.14 新增：QQ 内部微信桥
]


def _ensure_no_locks(src, dst):
    """改名/删除前确保没有进程占着文件。

    v1.14 行为重做：**自动杀，不再询问**。
      之前是弹框「要杀吗？」让用户选 —— 用户其实根本看不见这些后台服务、
      也不知道该不该杀，让他们选 = 折磨。同事原话：「我同事没开 QQ 啊」
      —— 实际是 QQProtect 等无窗口后台服务在跑。
    现在的策略：直接杀，最多两轮；杀不掉再弹框说「请重启电脑」。
    """
    for attempt in (1, 2):
        running = _running_processes(MIGRATE_BLOCK_PROCESSES)
        if not running:
            return True
        if attempt == 1:
            print("  [自动结束] 检测到 %d 个后台进程（无窗口服务），正在自动结束..." 
                  % len(running))
        else:
            print("  [再次清理] 仍有 %d 个进程在运行：" % len(running))
        for n in running:
            print("           - %s" % n)
        # 用 /T 顺带杀子进程，防止 QQProtect 拉起 QQPCRTP 之类
        killed = _kill_processes(running, kill_tree=True)
        if killed:
            print("           已结束：%s" % "、".join(killed))
        time.sleep(2)  # 等系统真正释放文件句柄

    still = _running_processes(MIGRATE_BLOCK_PROCESSES)
    if still:
        print("  [中止] 这些进程无法结束（多半是带驱动保护的系统服务，taskkill 杀不掉）：")
        for n in still:
            print("           - %s" % n)
        print("         请重启电脑后重跑 —— 数据未动，目标副本也保留。")
        return False
    return True


def _remove_with_retry(path, tries=3, wait=3):
    """删除目录，失败重试。

    v1.10：Defender 实时扫描 / explorer 缩略图缓存只是「瞬时占用」，
    等几秒再试往往就成了 —— 原来一次失败就放弃，用户白等 10 分钟复制。
    """
    for i in range(tries):
        if _try_remove(path):
            return True
        if i < tries - 1:
            print("      删除未成功，%d 秒后重试（%d/%d）..." % (wait, i + 1, tries))
            time.sleep(wait)
    return False


# ---------------------------------------------------------------------------
# 一、一键清理（缓存/残留）
# ---------------------------------------------------------------------------
def clean_workbuddy():
    print("\n[1/6] 清理 WorkBuddy（本 AI 助手）更新残留")
    freed = 0
    tmp = os.environ.get("TEMP", "")
    targets = [
        (os.path.join(LOCALAPP, "@genieworkbuddy-desktop-updater"), "更新器残留 installer.exe"),
        (os.path.join(tmp, "workbuddy-update-x64"), "更新解压目录 Setup.exe"),
        (os.path.join(USERPROFILE, ".workbuddy_old_backup"), "旧版冻结备份 .workbuddy_old_backup"),
    ]
    for path, label in targets:
        if os.path.isdir(path):
            freed += clean_dir_fully(path, label)
    return freed


def clean_temp():
    print("\n[2/6] 清理 TEMP 临时目录")
    tmp = os.path.join(LOCALAPP, "Temp")
    freed = 0
    if os.path.isdir(tmp):
        now = time.time()
        for name in os.listdir(tmp):
            p = os.path.join(tmp, name)
            try:
                if os.path.getmtime(p) > now - 1800:
                    _stats["skipped"] += 1
                    continue
            except OSError:
                pass
            before = _size_of(p)
            if _try_remove(p):
                freed += before
        print("  [OK] %-42s 释放 %8.1f MB" % (tmp, freed / 1024**2))
    return freed


def clean_wps():
    print("\n[3/6] 清理 WPS 缓存与备份（不含文档、账号、配置）")
    freed = 0
    kf = os.path.join(APPDATA, "kingsoft")
    targets = [
        (os.path.join(kf, "office6", "backup"), "WPS 自动备份 backup"),
        (os.path.join(kf, "office6", "cache"), "WPS 缓存 cache"),
        (os.path.join(kf, "office6", "log"), "WPS 日志 log"),
        (os.path.join(kf, "wps", "addons", "pool"), "WPS 云组件缓存 addons/pool"),
        (os.path.join(kf, "wps", "addons", "data"), "WPS 云组件数据 addons/data"),
        (os.path.join(kf, "wps", "download"), "WPS 下载缓存 download"),
    ]
    for path, label in targets:
        if os.path.exists(path):
            freed += clean_dir_fully(path, label)
    return freed


def clean_vs_office():
    print("\n[4/6] 清理 VS / Edge / 系统可再生缓存")
    freed = 0
    vs_root = os.path.join(LOCALAPP, "Microsoft", "VisualStudio")
    if os.path.isdir(vs_root):
        for ver in os.listdir(vs_root):
            ccm = os.path.join(vs_root, ver, "ComponentModelCache")
            if os.path.isdir(ccm):
                freed += clean_dir_fully(ccm, "VS " + ver + " ComponentModelCache")
    edge_cache = os.path.join(LOCALAPP, "Microsoft", "Edge", "User Data", "Default", "Cache")
    if os.path.isdir(edge_cache):
        f, _, _ = clean_dir_contents(edge_cache, "Edge 浏览器缓存")
        freed += f
    exp = os.path.join(LOCALAPP, "Microsoft", "Windows", "Explorer")
    if os.path.isdir(exp):
        sub = 0
        for name in os.listdir(exp):
            if name.startswith("thumbcache_") or name.startswith("iconcache_"):
                p = os.path.join(exp, name)
                before = _size_of(p)
                if _try_remove(p):
                    sub += before
        print("  [OK] %-42s 释放 %8.1f MB" % ("Explorer 缩略图缓存", sub / 1024**2))
        freed += sub
    return freed


def clean_dev_caches():
    print("\n[5/6] 清理 pip / npm 缓存（可重建）")
    freed = 0
    pip_cache = os.path.join(LOCALAPP, "pip", "cache")
    npm_cache = os.path.join(LOCALAPP, "npm-cache")
    if os.path.isdir(pip_cache):
        freed += clean_dir_fully(pip_cache, "pip 缓存")
    if os.path.isdir(npm_cache):
        freed += clean_dir_fully(npm_cache, "npm 缓存")
    return freed


def clean_agent_temp():
    print("\n[6/6] 清理固定临时目录 F:\\WorkBuddy\\AgentTemp")
    freed = 0
    if os.path.isdir(AGENT_TEMP):
        own_dir = os.path.dirname(os.path.abspath(__file__))
        for name in os.listdir(AGENT_TEMP):
            p = os.path.join(AGENT_TEMP, name)
            if os.path.abspath(p) == own_dir:
                continue
            before = _size_of(p)
            if _try_remove(p):
                freed += before
        print("  [OK] %-42s 释放 %8.1f MB" % ("AgentTemp（AI 临时文件区）", freed / 1024**2))
    return freed


def run_clean_all():
    """一键清理：WorkBuddy残留 + TEMP + WPS + VS/Edge + pip/npm + AgentTemp"""
    total = 0
    total += clean_workbuddy()
    total += clean_temp()
    total += clean_wps()
    total += clean_vs_office()
    total += clean_dev_caches()
    total += clean_agent_temp()
    return total


# ---------------------------------------------------------------------------
# 二、软件卸载残留
# ---------------------------------------------------------------------------
def _program_dirs():
    dirs = []
    for env in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432"):
        v = os.environ.get(env)
        if v and os.path.isdir(v):
            dirs.append(v)
    if LOCALAPP:
        p = os.path.join(LOCALAPP, "Programs")
        if os.path.isdir(p):
            dirs.append(p)
    return dirs


_REG_CACHE = None


def _registry_installed():
    """从注册表卸载项收集 (DisplayName, InstallLocation)，结果缓存。
    程序目录扫描漏掉的自定义路径（如装在 D/E 盘）靠这里兜底。"""
    global _REG_CACHE
    if _REG_CACHE is not None:
        return _REG_CACHE
    items = []
    try:
        import winreg
    except ImportError:
        _REG_CACHE = items
        return items
    roots = [
        (winreg.HKEY_LOCAL_MACHINE,
         r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE,
         r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER,
         r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]
    for hive, path in roots:
        try:
            key = winreg.OpenKey(hive, path)
        except OSError:
            continue
        i = 0
        while True:
            try:
                sub = winreg.EnumKey(key, i)
                i += 1
            except OSError:
                break
            try:
                k = winreg.OpenKey(key, sub)
                try:
                    name, _ = winreg.QueryValueEx(k, "DisplayName")
                except OSError:
                    continue
                loc = ""
                try:
                    loc, _ = winreg.QueryValueEx(k, "InstallLocation")
                except OSError:
                    pass
                items.append((str(name), str(loc)))
            except OSError:
                continue
    _REG_CACHE = items
    return items


def _is_app_installed(install_names):
    """判定软件是否仍安装。程序目录扫描 + 注册表卸载项反查，任一命中即视为已安装。
    原则：宁可漏清残留，也绝不误删仍在使用的软件数据。"""
    # 1) 常见程序目录（含一层子目录）
    for pd in _program_dirs():
        try:
            for top in os.listdir(pd):
                tp = os.path.join(pd, top)
                if not os.path.isdir(tp):
                    continue
                for n in install_names:
                    if top.lower() == n.lower():
                        return True
                    try:
                        for sub in os.listdir(tp):
                            if sub.lower() == n.lower():
                                return True
                    except OSError:
                        pass
        except OSError:
            pass

    # 2) 注册表卸载项反查：DisplayName 精确/前缀匹配，或 InstallLocation 末级目录名匹配
    try:
        for name, loc in _registry_installed():
            nm = name.lower().strip()
            loc_last = os.path.basename(loc.rstrip("\\/")).lower() if loc else ""
            for n in install_names:
                nl = n.lower()
                if nm == nl or nm.startswith(nl + " ") or loc_last == nl:
                    return True
    except Exception:
        pass
    return False


# 这些路径可能是用户真实数据（聊天记录/接收的文件），删除前必须单独弹框确认
DANGEROUS_HINTS = [
    ("Tencent Files", "QQ 聊天记录与接收的文件（含图片）"),
    ("WeChat Files", "微信聊天记录与接收的文件（含图片）"),
    ("QMDownload", "QQ 下载目录，可能含你接收的文件"),
    ("FileRecv", "QQ/微信 接收的文件"),
    ("Xwechat_files", "微信接收的文件（含图片）"),
]


def _danger_hint(path):
    """路径命中用户数据关键字则返回提示文案，否则 None"""
    low = path.lower()
    for key, hint in DANGEROUS_HINTS:
        if key.lower() in low:
            return hint
    return None


def _confirm_dangerous(path, label):
    """高危路径删除前二次确认；返回 True 才允许删"""
    hint = _danger_hint(path)
    if not hint:
        return True
    return _msgbox_yesno(
        "高危确认：可能是你的个人数据",
        "即将删除：\n%s\n\n说明：%s\n\n这可能是聊天记录、图片或你接收的文件，删除后无法恢复！\n"
        "如果不是你主动想清掉的，请点「否」。\n\n确定删除吗？" % (path, hint))


# (软件名, 安装目录名列表, [(残留路径, 描述), ...])
UNINSTALL_RESIDUE = [
    ("微信 WeChat", ["WeChat", "微信"], [
        (os.path.join(APPDATA, "Tencent", "WeChat"), "微信聊天记录残留"),
        (os.path.join(USERPROFILE, "Documents", "WeChat Files"), "微信文件残留"),
        (os.path.join(USERPROFILE, "Documents", "xwechat_files"), "微信接收文件残留"),
    ]),
    ("QQ", ["QQ", "QQNT", "腾讯QQ"], [
        (os.path.join(APPDATA, "Tencent", "QQ"), "QQ 数据残留"),
        (os.path.join(APPDATA, "Tencent", "QQNT"), "QQNT 数据残留"),
        (os.path.join(USERPROFILE, "Documents", "Tencent Files"), "QQ 文件残留"),
    ]),
    ("企业微信", ["WXWork", "企业微信"], [
        (os.path.join(APPDATA, "Tencent", "WXWork"), "企业微信残留"),
    ]),
    ("钉钉", ["DingTalk", "DingDing", "钉钉"], [
        (os.path.join(APPDATA, "DingTalk"), "钉钉残留"),
    ]),
    ("网易云音乐", ["CloudMusic", "Netease", "网易云音乐"], [
        (os.path.join(LOCALAPP, "Netease"), "网易云残留"),
        (os.path.join(APPDATA, "NetEase"), "网易云残留"),
    ]),
    ("迅雷", ["Thunder", "Thunder Network", "迅雷"], [
        (os.path.join(APPDATA, "Thunder"), "迅雷残留"),
        (os.path.join(APPDATA, "thunder"), "迅雷残留"),
    ]),
    ("百度网盘", ["BaiduNetdisk", "baidunetdisk", "百度网盘"], [
        (os.path.join(APPDATA, "baidunetdisk"), "百度网盘残留"),
    ]),
    ("搜狗输入法", ["SogouInput", "搜狗输入法"], [
        (os.path.join(LOCALAPP, "SogouPY"), "搜狗输入法残留"),
    ]),
    ("有道词典", ["Youdao", "Dict", "有道词典"], [
        (os.path.join(LOCALAPP, "Yodao"), "有道残留"),
    ]),
    ("爱奇艺", ["IQIYI", "爱奇艺"], [
        (os.path.join(APPDATA, "iqiyi"), "爱奇艺残留"),
    ]),
    ("优酷", ["Youku", "优酷"], [
        (os.path.join(APPDATA, "youku"), "优酷残留"),
    ]),
]


def clean_uninstall_residue():
    print("\n===== 扫描软件卸载残留 =====")
    freed = 0
    found = 0
    for app_name, install_names, residues in UNINSTALL_RESIDUE:
        if _is_app_installed(install_names):
            continue  # 软件还在，不清
        existing = [(p, l) for p, l in residues if os.path.exists(p)]
        if not existing:
            continue
        found += 1
        print("  发现已卸载软件「%s」的残留：" % app_name)
        for p, l in existing:
            if not _confirm_dangerous(p, l):
                print("  [保留] %s（高危，已按你的选择保留）" % l)
                continue
            freed += clean_dir_fully(p, l)
    if found == 0:
        print("  未发现已卸载软件的残留。")
    return freed


# ---------------------------------------------------------------------------
# 三、软件更新残留（安装包 / 下载缓存）
# ---------------------------------------------------------------------------
UPDATE_RESIDUE = [
    (os.path.join(APPDATA, "Tencent", "QQTempSys"), "腾讯 QQ 临时文件"),
    (os.path.join(APPDATA, "Tencent", "Tencentdl"), "腾讯下载缓存"),
    (os.path.join(APPDATA, "Tencent", "TenioDL"), "腾讯 TenioDL 下载缓存"),
    (os.path.join(APPDATA, "Tencent", "DeskUpdate"), "腾讯桌面更新缓存"),
    (os.path.join(APPDATA, "Tencent", "QMDownload"), "QQ 下载缓存"),
    (os.path.join(APPDATA, "Tencent", "OMGCACHE"), "腾讯缓存"),
    (os.path.join(LOCALAPP, "Microsoft", "Edge", "User Data", "Default", "Service Worker", "CacheStorage"), "Edge Service Worker 缓存"),
]


def clean_update_residue():
    print("\n===== 清理软件更新残留（安装包/下载缓存）=====")
    freed = 0
    for path, label in UPDATE_RESIDUE:
        if os.path.isdir(path):
            if not _confirm_dangerous(path, label):
                print("  [保留] %s（高危，已按你的选择保留）" % label)
                continue
            freed += clean_dir_fully(path, label)
    return freed


# ---------------------------------------------------------------------------
# 四、数据转移（移动 + junction 链接）
# ---------------------------------------------------------------------------
MIGRATE_CANDIDATES = [
    (os.path.join(APPDATA, "Tencent"), "腾讯系（微信/QQ/企业微信等）"),
    (os.path.join(APPDATA, "QQ"), "QQ 数据"),
    (os.path.join(APPDATA, "QQEX"), "QQEX 数据"),
    (os.path.join(APPDATA, "baidunetdisk"), "百度网盘文件"),
    (os.path.join(LOCALAPP, "JetBrains"), "PyCharm / JetBrains 开发工具"),
]


def _migrate_dir(src, dst_root):
    """把 src 目录移动到 dst_root 下，原位置建 junction；失败则保留原数据"""
    # 函数级防护：src 已是 junction/symlink 说明此前迁移过，
    # 若不拦截，robocopy 会穿透链接把目标盘真实数据再复制一份（套娃），且空间预检会误判
    if _is_reparse_point(src):
        print("  [跳过] %s（已是目录链接，数据已在别处，无需再次转移）" % src)
        return False

    name = os.path.basename(src.rstrip("\\/"))
    dst = os.path.join(dst_root, name)
    src_size = _size_of(src)
    print("  正在转移「%s」(%.1f MB)，请耐心等待（大目录可能需几分钟）..."
          % (name, src_size / 1024**2))

    # 目标盘空间检查
    drive = os.path.splitdrive(dst_root)[0] or os.path.splitdrive(src)[0]
    try:
        free = shutil.disk_usage(drive + "\\").free
        if free < src_size + 200 * 1024 * 1024:
            print("  [失败] 目标盘空间不足（需 %.1f MB，仅剩 %.1f MB）"
                  % (src_size / 1024**2, free / 1024**2))
            return False
    except OSError:
        pass

    # 1. robocopy 复制。/XJ = 不跟随 junction，
    #    否则会把源目录里已迁移走的链接（如 xwechat -> E 盘）整份内容又复制一遍
    try:
        rc = subprocess.run(
            [ROBOCOPY, src, dst, "/E", "/XJ", "/COPY:DAT", "/DCOPY:DAT",
             "/R:2", "/W:2", "/NFL", "/NDL", "/NP"],
            capture_output=True, timeout=3600
        )
        if rc.returncode >= 8:
            print("  [失败] 复制失败（robocopy 返回码 %d），原数据保留" % rc.returncode)
            _try_remove(dst)
            return False
        if rc.returncode > 0:
            print("  [注意] robocopy 返回码 %d（有文件未完全同步），稍后做严格校验" % rc.returncode)
    except Exception as e:
        print("  [失败] 复制异常：%s，原数据保留" % e)
        _try_remove(dst)
        return False

    if not os.path.isdir(dst):
        print("  [失败] 复制后目标目录不存在，原数据保留")
        return False

    # 1.2 /XJ 跳过了源里的 junction，这里在目标盘原样重建，
    #     否则删掉原件后软件会找不到已迁移走的数据（链接断裂）
    rebuilt = _rebuild_inner_junctions(src, dst)
    if rebuilt:
        print("      共重建 %d 个内部链接" % rebuilt)

    # 1.5 严格校验：文件数 + 总大小双对比。
    #     原逻辑只有「差 >200MB 且 <95%」才拦截，少量丢失根本检测不到，
    #     结果删掉原件后那部分就永久没了（多半是被占用的缓存/配置文件）
    src_n = _count_files(src)
    dst_n = _count_files(dst)
    if dst_n < src_n:
        print("  [中止] 文件数不一致（源 %d 个 / 目标 %d 个，缺 %d 个）。" % (src_n, dst_n, src_n - dst_n))
        print("         多半是文件被占用没能复制过去。原数据完整保留，请关闭相关软件后重试。")
        return False  # 保留 src 与 dst，绝不删原件

    dst_size = _size_of(dst)
    if src_size > 0 and (src_size - dst_size) > 10 * 1024 ** 2:
        print("  [中止] 目标副本偏小（源 %.1f MB / 目标 %.1f MB，差 %.1f MB）。"
              % (src_size / 1024**2, dst_size / 1024**2, (src_size - dst_size) / 1024**2))
        print("         原数据完整保留，请重试。")
        return False

    # ==== 2. 原子改名（v1.11 核心修复，本次事故的根源）====
    # 旧做法：直接 _try_remove(src) → shutil.rmtree 边删边走。
    #   rmtree 遇到被占用文件时只是跳过（_rmtree_onexc 吞掉异常后继续删其它文件），
    #   等删完能删的，还剩几个占用文件导致 os.path.exists(src) 为真
    #   → 工具判定"删除失败"→ 不建链接 → 直接返回。
    #   **但此时原目录已经被删掉一大半了！** 副本在目标盘，原件却烂了，链接又没建，
    #   软件按原路径读 → 什么都读不到。同事实锤：微信登录上去聊天记录全没了。
    #   （此前"迁移失败也保证安全"的说法只保住了副本，没保住原件 —— 这是设计缺陷。）
    # 新做法：先原子改名。NTFS 同卷改名是瞬时的、几乎不可能失败：
    #   ① 改名成功 → 原位置立刻腾空 → 马上建 junction → 软件立刻恢复正常；
    #   ② 删除旧目录降级成"事后清理"，就算删不掉也**不影响任何功能**；
    #   ③ 建链接万一失败 → 改名回滚，一个字节都没丢。
    src_bak = src + ".__cc_moving"

    # 进程检测（v1.10）：仍建议先结束后台进程，这样第 4 步清理旧数据才能一次成功。
    # 但 v1.11 起它降级为「建议」—— 就算你选择不结束，改名 + 建链接依然安全，
    # 顶多是旧数据暂时清不掉（不影响使用）。
    if not _ensure_no_locks(src, dst):
        print("  [继续] 仍将尝试迁移。进程占用只影响善后清理，不影响数据安全。")

    if os.path.exists(src_bak):
        # 上次失败留下的残骸：它才是真数据，先提示，不要盲删
        print("  [发现残留] 上次迁移留下的目录 %s" % src_bak)
        if not _msgbox_yesno("发现上次迁移残留",
                             "发现上次迁移留下的目录：\n  %s\n\n"
                             "它可能含有尚未清理的原始数据（约 %.1f MB）。\n"
                             "目标盘 %s 已有完整副本，确认这份残留可以删除吗？\n\n"
                             "（选「否」会中止本次迁移，你的数据不会被改动）"
                             % (src_bak, _size_of(src_bak) / 1024**2, dst)):
            print("  [中止] 请先自行确认 %s 的内容后再重试。" % src_bak)
            return False
        _remove_with_retry(src_bak, tries=1)

    # v1.14：改名失败时（多半是漏掉的后台服务仍占着）—— 再杀一轮、重试一次。
    #   真正杀不掉（驱动保护）才放弃。整个过程数据分毫不动。
    renamed = False
    for attempt in (1, 2):
        try:
            os.rename(src, src_bak)
            renamed = True
            break
        except OSError as e:
            if attempt == 1:
                # 再查一次，再杀一轮
                running = _running_processes(MIGRATE_BLOCK_PROCESSES)
                if running:
                    print("  [改名被锁] 仍有 %d 个进程在占用，再杀一次..." % len(running))
                    for n in running:
                        print("              - %s" % n)
                    _kill_processes(running, kill_tree=True)
                    time.sleep(3)
                    continue
            # 第二轮仍失败 或 没检测到进程但还是失败 —— 退出
            print("  [中止] 无法改名（原目录被占用）：%s" % e)
            print("         原数据一个字节都没动，目标副本在 %s。" % dst)
            print("         请重启电脑后重跑，选同一个目标文件夹即可续完。")
            return False
    if not renamed:
        return False    # 防御性，正常走不到
    print("      已腾空原位置（旧数据暂存在 %s）" % os.path.basename(src_bak))

    # ==== 3. 在原位置建 junction（此时路径已腾空，一定建得上）====
    if not _make_junction(src, dst):
        # 回滚：改回原名，数据完好无损
        try:
            os.rename(src_bak, src)
            print("  [回滚] 建链接失败，已还原 %s（数据完好）" % src)
        except OSError as e:
            print("  [严重] 建链接失败且回滚失败：%s" % e)
            print("         数据在 %s 和 %s，请手动处理！" % (src_bak, dst))
        return False
    print("  [OK] %s -> %s（已建链接，软件立刻可用）" % (src, dst))

    # ==== 4. 清理旧数据（纯善后，失败也无所谓）====
    #     关键：此时链接已生效，软件已经能正常读写目标盘了。
    #     这一步删不掉顶多是"旧数据还占着 C 盘"，绝不会再毁任何东西。
    print("      正在清理旧数据（这一步失败也不影响使用）...")
    if _remove_with_retry(src_bak, tries=3, wait=3):
        print("      旧数据已清理。")
    else:
        print("  [提示] 旧数据未能完全清除（部分文件被占用）。")
        print("         不影响使用 —— 软件已通过链接读目标盘。")
        print("         残留位置：%s" % src_bak)
        print("         重启电脑后手动删除即可（也可留着，重启后重跑本工具会自动清）。")
    return True


def do_migrate():
    print("\n===== 转移聊天记录 / 网盘 / 开发工具到其他盘 =====")
    print("说明：把下列大目录搬到目标盘，删除 C 盘原件并在原位置建立链接，")
    print("      微信/QQ/PyCharm 等软件仍能按原路径读取，同时腾出 C 盘空间。")
    print("")

    _msgbox("数据转移",
            "即将转移腾讯系(微信/QQ/企业微信)、百度网盘、PyCharm 等数据。\n\n"
            "请先关闭以下软件，否则文件被占用会导致转移不完整：\n"
            "  微信、QQ、企业微信、百度网盘、PyCharm\n\n"
            "没关也没关系 —— 工具会在开始时自动检测并结束\n"
            "QQProtect / TXPlatform / WeChatUpdate 等后台服务，\n"
            "（这些都是没窗口的进程，你看不到但会被自动清掉）。\n\n"
            "确认后点确定继续。")

    # 真检测进程。v1.14：用户选「是」**直接杀**，不再只是放行。
    #   之前"建议先关闭再迁移。仍要继续吗？"= 弹了等于没弹，用户点啥都救不了。
    #   同事原话"我同事没开QQ啊" —— 实际是 QQProtect 等无窗口后台服务，
    #   用户看不见也没法关。工具必须自动处理才有意义。
    running = _running_processes(MIGRATE_BLOCK_PROCESSES)
    if running:
        names_str = "、".join(running)
        if not _msgbox_yesno("检测到后台进程",
                             "检测到以下进程仍在运行：\n  " + names_str +
                             "\n\n这些多是无窗口的后台服务（QQ 安全保护、微信更新等），"
                             "你看不到也关不掉。\n\n"
                             "工具会自动结束它们（不影响账号和数据），"
                             "然后再开始迁移。\n\n继续吗？"):
            print("已取消（请关闭相关软件后重试）。")
            return
        print("  [自动结束] 正在结束后台进程...")
        killed = _kill_processes(running, kill_tree=True)
        print("           已结束：%s" % ("、".join(killed) if killed else "无"))
        time.sleep(2)
        still = _running_processes(MIGRATE_BLOCK_PROCESSES)
        if still:
            print("  [仍有占用] 这些进程无法结束：%s" % "、".join(still))
            if not _msgbox_yesno("仍有进程占用",
                                 "以下进程无法结束：\n  " + "、".join(still) +
                                 "\n\n多半是带系统服务或驱动保护，taskkill 杀不掉。\n"
                                 "建议重启电脑后再跑（数据未动）。\n\n仍要继续尝试吗？"):
                print("已取消。")
                return

    target = _browse_for_folder("请选择转移目标文件夹（例如 F:\\ 或新建一个文件夹）")
    if not target:
        print("已取消（未选择目标文件夹）。")
        return

    if target.lower().startswith("c:"):
        if not _msgbox_yesno("确认", "你选择的目标仍在 C 盘，转移后腾不出空间。\n确定继续吗？"):
            print("已取消。")
            return

    print("目标位置：%s" % target)

    # ---- 先统计待迁移目录总大小，并预检目标盘空间 ----
    print("\n正在统计待迁移数据大小（大目录可能需十几秒，请稍候）...")
    pending = []
    total_size = 0
    for src, label in MIGRATE_CANDIDATES:
        if not os.path.isdir(src):
            continue
        if _is_reparse_point(src):
            print("  [跳过] %s（已是链接，无需再次转移）" % label)
            continue
        sz = _size_of(src)
        print("  %-34s %10.1f MB" % (label, sz / 1024**2))
        total_size += sz
        pending.append((src, label, sz))
    print("  合计：%d 个目录，共 %.2f GB" % (len(pending), total_size / 1024**3))

    if not pending:
        print("\n没有可转移的目录。")
        return

    drive = os.path.splitdrive(target)[0] or "C:"
    try:
        free = shutil.disk_usage(drive + "\\").free
    except OSError:
        free = None

    if free is not None:
        enough = free >= total_size + 500 * 1024 * 1024  # 预留 500MB 余量
        space_tip = ("待转移目录共 %d 个，合计 %.2f GB。\n\n"
                     "目标盘 %s 剩余空间：%.2f GB。"
                     % (len(pending), total_size / 1024**3, drive, free / 1024**3))
        if enough:
            _msgbox("空间检查通过", space_tip +
                    "\n\n空间充足，点击确定开始逐项确认转移。")
        else:
            if not _msgbox_yesno("警告：目标盘空间不足",
                                 space_tip +
                                 "\n\n空间不足（建议预留 500 MB 余量），继续可能导致转移中途失败！\n"
                                 "仍要继续吗？"):
                print("已取消（目标盘空间不足）。")
                return
    # ---- 预检结束 ----

    print("")
    total_moved = 0
    moved_any = False
    for src, label, sz in pending:
        if not _msgbox_yesno("确认转移",
                             "是否转移「%s」？\n\n大小：%.1f MB\n目标：%s\n\n"
                             "转移后原 C 盘位置会建立链接，软件不受影响。"
                             % (label, sz / 1024**2, target)):
            print("  [跳过] %s（你选择不转移）" % label)
            continue
        if _migrate_dir(src, target):
            total_moved += sz
            moved_any = True

    if moved_any:
        print("\n转移完成！共腾出 %.1f MB（%.2f GB）" % (total_moved / 1024**2, total_moved / 1024**3))
    else:
        print("\n本次未转移任何目录。")


# ---------------------------------------------------------------------------
# 五、WorkBuddy 数据迁移（需先退出 WorkBuddy）
# ---------------------------------------------------------------------------
WB_DIRNAME = ".workbuddy"
WB_DIR = os.path.join(USERPROFILE, WB_DIRNAME) if USERPROFILE else ""
WB_PROCESS = "WorkBuddy.exe"


def _is_wb_running():
    """检测 WorkBuddy 是否正在运行（迁移其数据目录前必须退出）"""
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq " + WB_PROCESS],
                             capture_output=True, timeout=30)
        txt = (out.stdout or b"").decode("gbk", errors="ignore")
        return WB_PROCESS.lower() in txt.lower()
    except Exception:
        return False  # 检测失败不阻塞，后续弹框仍会提醒用户手动确认


def migrate_workbuddy():
    """把 .workbuddy 搬到其它盘，原位建 junction。
    独立于 do_migrate：这是 AI 助手的运行时目录，必须单独确认退出后才可动。"""
    print("\n===== 迁移 WorkBuddy 数据到其他盘 =====")
    src = WB_DIR
    if not src or not os.path.exists(src):
        print("  未找到 %s，本机可能未安装 WorkBuddy，跳过。" % src)
        _msgbox("无需迁移", "未找到 WorkBuddy 数据目录：\n%s\n\n本机可能未安装 WorkBuddy。" % src)
        return

    if _is_reparse_point(src):
        print("  %s 已是目录链接，此前已迁移过，无需重复操作。" % src)
        _msgbox("已迁移过",
                "%s\n\n该目录已是目录链接（junction），数据实际已存放在其他盘，\n"
                "WorkBuddy 读写正常。无需再次迁移。" % src)
        return

    size = _size_of(src)
    print("  数据目录：%s" % src)
    print("  当前大小：%.1f MB" % (size / 1024**2))

    notice = ("本操作把 WorkBuddy 的数据目录（%s）搬到其它盘，\n"
              "原位置建立目录链接（junction），WorkBuddy 之后仍能正常读写。\n\n"
              "【必须先完全退出 WorkBuddy】，否则文件被占用会导致迁移失败。\n"
              "请先保存好对话内容，再从系统托盘退出 WorkBuddy。" % WB_DIRNAME)

    if _is_wb_running():
        if not _msgbox_yesno("警告：WorkBuddy 正在运行",
                             "检测到 WorkBuddy 正在运行！\n\n" + notice +
                             "\n\n现在继续大概率失败（数据被占用）。\n仍要继续吗？"):
            print("  已取消（请先退出 WorkBuddy 后重试）。")
            return
    else:
        if not _msgbox_yesno("迁移 WorkBuddy 数据", notice + "\n\n确认已退出后点「是」继续。"):
            print("  已取消。")
            return

    target = _browse_for_folder("请选择 WorkBuddy 数据存放位置（例如 F:\\ 或 F:\\WorkBuddy）")
    if not target:
        print("  已取消（未选择目标）。")
        return

    if target.lower().startswith("c:"):
        if not _msgbox_yesno("确认", "你选择的目标仍在 C 盘，迁移后腾不出空间。\n确定继续吗？"):
            print("  已取消。")
            return

    dst_root = os.path.join(target, "WorkBuddyData")
    dst_real = os.path.join(dst_root, WB_DIRNAME)

    if os.path.exists(dst_real):
        _msgbox("目标已存在",
                "目标位置已存在同名目录：\n%s\n\n为避免覆盖已有数据，请换一个目标位置后重试。" % dst_real)
        print("  目标已存在，取消：%s" % dst_real)
        return

    if not _msgbox_yesno("最后确认",
                         "源目录：%s\n大小：%.1f MB\n迁移到：%s\n\n"
                         "迁移期间请勿启动 WorkBuddy。\n确定开始吗？"
                         % (src, size / 1024**2, dst_real)):
        print("  已取消。")
        return

    if _migrate_dir(src, dst_root):
        print("\n  WorkBuddy 数据迁移完成，现在可以重新启动 WorkBuddy 了。")
        _msgbox("迁移完成",
                "WorkBuddy 数据已迁移到：\n%s\n\n"
                "原位置已建立链接，WorkBuddy 可正常启动使用。\n\n"
                "注意：目标盘被拔掉或盘符变化后，原路径会失效，\n"
                "届时把数据拷回 %s 即可恢复。" % (dst_real, src))
    else:
        _msgbox("迁移未完成",
                "本次未能完成迁移，WorkBuddy 数据仍在原位：\n%s\n\n"
                "请确认已完全退出 WorkBuddy 后重试。" % src)


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def _show_disk():
    for drive in ("C:\\", "F:\\", "D:\\", "E:\\"):
        try:
            u = shutil.disk_usage(drive)
            print("  %s 盘剩余 %.1f GB / 共 %.1f GB" % (drive[0], u.free / 1024**3, u.total / 1024**3))
        except OSError:
            pass


# ---------------------------------------------------------------------------
# 六、数据恢复（功能 4 / 5 出问题时的后悔药）
# ---------------------------------------------------------------------------
# v1.12：原为独立 exe「微信数据恢复助手」，用户指出"这就是你工具自己造成的问题，
#        为什么分开" —— 说得对，分开反而多一个拿错 exe 的风险（同事就曾拿错旧版）。
#        现合并进主菜单 [6]，一个 exe 全搞定。
# 副本常见落点的子目录名。注意：不写死任何具体路径 —— 别人的习惯可能完全不同，
# 这里只是"最可能的几个名字"，扫不到还有手动选择兜底。
RESTORE_SUBDIR_HINTS = [
    "appdata", "AppData", "backup", "Backup", "数据", "备份",
    "Data", "MigrationData", "WorkBuddyData", "migrate",
]


def _logical_drives():
    """枚举本机所有可用盘符。不写死 D~N —— 别人的盘符可能更靠后（O/Z 等），
    也可能插着 U 盘/移动硬盘（副本很可能就在上面）。"""
    out = []
    # 从 C 开始枚举（跳过 A/B 软驱，访问不存在的软驱会卡住几秒）
    for c in "CDEFGHIJKLMNOPQRSTUVWXYZ":
        root = c + ":\\"
        try:
            if os.path.isdir(root):
                out.append(root)
        except OSError:
            pass
    return out


def _find_backups_for(name, src=""):
    """找 name 目录的副本。

    扫描三类位置（全部是"推断 + 兜底"，不含任何写死的绝对路径）：
      ① 各盘根目录直放：<盘>:\\Tencent
      ② 各盘常见子目录：<盘>:\\appdata\\Tencent、<盘>:\\备份\\Tencent ...
      ③ v1.11 改名残留：<原位>.__cc_moving —— 改名成功但清理失败时，
         数据其实就在这里。这是**本工具自己造成的最可能落点**，必须扫到。
    """
    found = []
    if src:
        leftover = src + ".__cc_moving"
        if os.path.isdir(leftover) and not _is_reparse_point(leftover):
            found.append(leftover)

    for root in _logical_drives():
        cands = [os.path.join(root, name)]
        cands += [os.path.join(root, sub, name) for sub in RESTORE_SUBDIR_HINTS]
        for cand in cands:
            if os.path.isdir(cand) and not _is_reparse_point(cand):
                found.append(cand)

    # 去重保序
    seen, uniq = set(), []
    for f in found:
        k = os.path.normcase(os.path.abspath(f))
        if k not in seen:
            seen.add(k)
            uniq.append(f)
    return uniq


def _restore_candidates():
    """扫描出所有「原位 ← 副本」组合（功能 4 各项 + 功能 5 WorkBuddy）"""
    out = []
    for src, label in MIGRATE_CANDIDATES:
        name = os.path.basename(src.rstrip("\\/"))
        for b in _find_backups_for(name, src):
            out.append((src, b, label))
    if WB_DIR:
        for b in _find_backups_for(WB_DIRNAME, WB_DIR):
            out.append((WB_DIR, b, "WorkBuddy 数据"))
    return out


def _human(b):
    return "%.1f MB" % (b / 1024 ** 2) if b < 1024 ** 3 else "%.2f GB" % (b / 1024 ** 3)


def do_restore():
    """把迁移走的副本拷回原位。只复制，绝不删除任何文件。"""
    print("\n===== 数据恢复（迁移出问题时把数据拷回原位）=====")
    print("说明：功能 4 / 5 迁移后若软件读不到数据")
    print("      （比如微信登录上去聊天记录没了），用这项把副本复制回原位置。")
    print("      ★ 全程只复制，绝不删除你的任何文件。")
    print("")

    src = backup = None
    cands = _restore_candidates()

    if cands:
        print("扫描到 %d 组「原位 ← 副本」：" % len(cands))
        for i, (s, b, lb) in enumerate(cands, 1):
            sn, bn = _count_files(s), _count_files(b)
            if _is_reparse_point(s):
                flag = "[原位已是链接]"
            elif sn == 0:
                flag = "[原位空的/不存在 → 建议恢复]"
            elif sn < bn:
                flag = "[原位比副本少 %d 个 → 可能被删过]" % (bn - sn)
            else:
                flag = "[看起来正常]"
            print("  [%d] %-20s %6d 个文件 ← %s（%d 个）%s"
                  % (i, lb, sn, b, bn, flag))
        print("")
        try:
            sel = input("输入编号并回车开始恢复；直接回车=手动指定：").strip()
        except EOFError:
            sel = ""
        if sel.isdigit() and 1 <= int(sel) <= len(cands):
            src, backup, _ = cands[int(sel) - 1]

    if not src:
        opts = list(MIGRATE_CANDIDATES) + ([(WB_DIR, "WorkBuddy 数据")] if WB_DIR else [])
        print("手动指定 —— 请选择要恢复到的「原位置」：")
        for i, (s, lb) in enumerate(opts, 1):
            print("    [%d] %-20s %s" % (i, lb, s))
        print("    [0] 自己选文件夹")
        try:
            s2 = input("编号：").strip()
        except EOFError:
            s2 = "0"
        if s2.isdigit() and 1 <= int(s2) <= len(opts):
            src = opts[int(s2) - 1][0]
        else:
            src = _browse_for_folder("请选择要恢复到的原位置")
    if not src:
        print("已取消。")
        return

    if not backup:
        backup = _browse_for_folder("请选择副本所在目录（当时转移到的那个文件夹，"
                                    "要选到 Tencent 这一层）")
    if not backup:
        print("已取消。")
        return

    if os.path.abspath(src) == os.path.abspath(backup):
        _msgbox("选择有误", "原位和副本不能是同一个目录。")
        return
    if not os.path.isdir(backup):
        _msgbox("副本不存在", "副本目录不存在：\n%s" % backup)
        return

    bn, bb = _count_files(backup), _size_of(backup)
    if bn == 0:
        _msgbox("副本是空的",
                "副本目录里没有文件：\n  %s\n\n"
                "请确认选对了文件夹（要选到 Tencent 这一层）。" % backup)
        return

    sn = _count_files(src) if os.path.isdir(src) else 0
    sb = _size_of(src) if os.path.isdir(src) else 0

    if _is_reparse_point(src):
        tgt = _read_junction_target(src)
        _msgbox("原位已经是链接",
                "原位已经是一个目录链接了：\n  %s\n  指向：%s\n\n"
                "说明链接建成功了。请先打开软件看看；\n"
                "若确实读不到数据，再检查上面那个指向位置。" % (src, tgt or "(读取失败)"))
        if not _msgbox_yesno("仍要继续？",
                             "仍要把副本复制一份到链接指向的位置吗？\n\n"
                             "  %s\n  → %s\n\n（只复制，不删除）" % (backup, tgt or src)):
            print("已取消。")
            return

    tip = ("即将把副本复制回原位（只复制，不删除任何东西）：\n\n"
           "  从：%s\n      %d 个文件，%s\n\n"
           "  到：%s\n      现有 %d 个文件，%s\n\n"
           "原位缺失的文件会被补齐。确定开始吗？"
           % (backup, bn, _human(bb), src, sn, _human(sb)))
    if not _msgbox_yesno("确认恢复", tip):
        print("已取消。")
        return

    print("\n开始恢复（大目录可能要几分钟，请耐心等待）...")
    try:
        os.makedirs(src, exist_ok=True)
    except OSError as e:
        print("[失败] 无法创建原位目录：%s" % e)
        return

    try:
        rc = subprocess.run(
            [ROBOCOPY, backup, src, "/E", "/XJ", "/COPY:DAT",
             "/R:2", "/W:2", "/NFL", "/NDL", "/NP"], timeout=3600)
        code = rc.returncode
    except Exception as e:
        print("[失败] %s" % e)
        return

    if code >= 8:
        print("\n[失败] robocopy 返回码 %d，恢复未完成。" % code)
        _msgbox("恢复未成功",
                "复制过程出错（robocopy 返回码 %d）。\n"
                "建议关闭相关软件后重新运行本功能。" % code)
        return

    an, ab = _count_files(src), _size_of(src)
    print("\n恢复完成。原位现有 %d 个文件，%s（恢复前 %d 个，%s）"
          % (an, _human(ab), sn, _human(sb)))
    if an >= bn:
        print("[OK] 文件数已达到副本水平，应该恢复完整了。")
        _msgbox("恢复完成",
                "恢复完成！\n\n原位现有 %d 个文件（%s）。\n\n"
                "请打开微信 / QQ 查看聊天记录。\n"
                "如果还看不到，关闭软件后重新运行本功能再恢复一次。"
                % (an, _human(ab)))
    else:
        print("[提示] 原位 %d 个 < 副本 %d 个，可能有文件被占用没能拷贝。" % (an, bn))
        print("       建议关闭微信/QQ 后重新运行本功能再恢复一次。")
        _msgbox("部分未恢复",
                "原位现有 %d 个文件，副本有 %d 个 —— 少 %d 个。\n\n"
                "多半是文件被软件占用没能拷贝。\n"
                "请关闭微信/QQ 后重新运行本功能再恢复一次。" % (an, bn, bn - an))


def _run_cli(arg):
    """命令行非交互模式（供 skill / agent 调用）：
    clean | uninstall | update | migrate | wb | restore | all"""
    mapping = {
        "1": "clean", "clean": "clean",
        "2": "uninstall", "uninstall": "uninstall",
        "3": "update", "update": "update",
        "4": "migrate", "migrate": "migrate",
        "5": "wb", "wb": "wb", "workbuddy": "wb",
        # v1.12 起 [6] 是数据恢复、[7] 才是全部清理（恢复紧挨迁移功能，逻辑更顺）
        "6": "restore", "restore": "restore", "recover": "restore",
        "7": "all", "all": "all",
    }
    key = mapping.get(arg.strip().lower())
    if not key:
        print("未知命令：%s" % arg)
        print("可用命令：clean | uninstall | update | migrate | wb | restore | all")
        return 2

    t0 = time.time()
    if key == "clean":
        total = run_clean_all()
        print("\n清理完成！共释放 %.2f GB，跳过占用文件 %d 个，用时 %.1f 秒"
              % (total / 1024**3, _stats["skipped"], time.time() - t0))
    elif key == "uninstall":
        clean_uninstall_residue()
        print("\n卸载残留清理完成，用时 %.1f 秒" % (time.time() - t0))
    elif key == "update":
        clean_update_residue()
        print("\n更新残留清理完成，用时 %.1f 秒" % (time.time() - t0))
    elif key == "migrate":
        print("提示：数据转移需弹出文件夹选择框，请由用户亲手选择目标盘。")
        do_migrate()
    elif key == "wb":
        print("提示：WorkBuddy 迁移需先退出 WorkBuddy，并弹出确认框与文件夹选择框。")
        migrate_workbuddy()
    elif key == "restore":
        print("提示：数据恢复需你确认原位与副本，会弹出确认框。")
        do_restore()
    elif key == "all":
        total = run_clean_all()
        total += clean_uninstall_residue()
        total += clean_update_residue()
        print("\n全部清理完成！共释放 %.2f GB，用时 %.1f 秒"
              % (total / 1024**3, time.time() - t0))
    return 0


def main():
    while True:
        print("=" * 62)
        print("          C 盘清理 / 数据迁移工具 v1.14")
        print("=" * 62)
        _show_disk()
        print("-" * 62)
        print("  [1] 一键清理缓存（TEMP/WPS/Edge/pip/npm/更新残留）")
        print("  [2] 清理软件卸载残留")
        print("  [3] 清理软件更新残留（安装包/下载缓存）")
        print("  [4] 转移聊天记录/网盘/开发工具到其他盘（弹框选路径）")
        print("  [5] 迁移 WorkBuddy 数据到其他盘（需先退出 WorkBuddy）")
        print("  [6] 数据恢复（4/5 出问题时，把副本拷回原位）")
        print("  [7] 全部清理（1+2+3）")
        print("  [0] 退出")
        print("=" * 62)
        try:
            sel = input("请输入编号：").strip()
        except EOFError:
            break

        t0 = time.time()
        if sel == "1":
            total = run_clean_all()
            print("\n清理完成！共释放 %.2f GB，跳过占用文件 %d 个，用时 %.1f 秒"
                  % (total / 1024**3, _stats["skipped"], time.time() - t0))
        elif sel == "2":
            clean_uninstall_residue()
            print("\n卸载残留清理完成，用时 %.1f 秒" % (time.time() - t0))
        elif sel == "3":
            clean_update_residue()
            print("\n更新残留清理完成，用时 %.1f 秒" % (time.time() - t0))
        elif sel == "4":
            do_migrate()
        elif sel == "5":
            migrate_workbuddy()
        elif sel == "6":
            do_restore()
        elif sel == "7":
            total = run_clean_all()
            total += clean_uninstall_residue()
            total += clean_update_residue()
            print("\n全部清理完成！共释放 %.2f GB，用时 %.1f 秒"
                  % (total / 1024**3, time.time() - t0))
        elif sel == "0":
            break
        else:
            print("无效输入，请重新选择。")
        print("")

    print("已退出。感谢使用！")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        sys.exit(_run_cli(sys.argv[1]))
    main()
