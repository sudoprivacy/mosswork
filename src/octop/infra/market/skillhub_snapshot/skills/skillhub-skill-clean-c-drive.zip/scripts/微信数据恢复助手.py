# -*- coding: utf-8 -*-
r"""
微信/QQ 数据恢复助手 v1.0

用途：C 盘清理工具「功能 4 数据转移」失败后，
      把目标盘上的副本（例如 D:\appdata\Tencent）拷回 C 盘原位置，
      让微信/QQ 重新读到聊天记录。

安全保证（这个脚本只做加法）：
  * 全程只复制，**从不删除任何文件**（robocopy 不带 /MIR、不带 /PURGE）
  * 原位已有的文件如果和副本一样就直接跳过，不一样的用副本补齐
  * 开始前会把两边的状态打印出来，让你确认无误再动手

用法：双击运行，按提示操作。
"""
import os
import sys
import ctypes
import subprocess
import shutil
from ctypes import wintypes

MB_SETFOREGROUND = 0x00010000
MB_TOPMOST = 0x00040000

APPDATA = os.environ.get("APPDATA", "")
USERPROFILE = os.environ.get("USERPROFILE", "")
WINDIR = os.environ.get("WINDIR", r"C:\Windows")
ROBOCOPY = os.path.join(WINDIR, "System32", "robocopy.exe")

ORIGINAL = os.path.join(APPDATA, "Tencent") if APPDATA else ""


def _console_hwnd():
    try:
        return ctypes.windll.kernel32.GetConsoleWindow()
    except Exception:
        return 0


def _bring_front():
    try:
        h = _console_hwnd()
        if h:
            ctypes.windll.user32.SetForegroundWindow(h)
    except Exception:
        pass


def msgbox(title, text, flags=0x40):
    _bring_front()
    try:
        ctypes.windll.user32.MessageBoxW(_console_hwnd(), text, title,
                                         flags | MB_SETFOREGROUND | MB_TOPMOST)
    except Exception:
        pass


def yesno(title, text):
    _bring_front()
    try:
        r = ctypes.windll.user32.MessageBoxW(
            _console_hwnd(), text, title,
            0x04 | 0x20 | MB_SETFOREGROUND | MB_TOPMOST)
        return r == 6
    except Exception:
        return False


def browse(title):
    """弹文件夹选择框（带新建文件夹按钮 + 可粘贴路径）"""
    try:
        shell32 = ctypes.windll.shell32
        ole32 = ctypes.windll.ole32

        class BROWSEINFO(ctypes.Structure):
            _fields_ = [("hwndOwner", wintypes.HWND),
                        ("pidlRoot", ctypes.c_void_p),
                        ("pszDisplayName", ctypes.c_wchar_p),
                        ("lpszTitle", ctypes.c_wchar_p),
                        ("ulFlags", ctypes.c_uint),
                        ("lpfn", ctypes.c_void_p),
                        ("lParam", ctypes.c_void_p),
                        ("iImage", ctypes.c_int)]

        disp = ctypes.create_unicode_buffer(260)
        bi = BROWSEINFO()
        bi.hwndOwner = _console_hwnd()
        bi.pidlRoot = None
        bi.pszDisplayName = ctypes.cast(disp, ctypes.c_wchar_p)
        bi.lpszTitle = title
        bi.ulFlags = 0x0001 | 0x0040 | 0x0010

        shell32.SHBrowseForFolderW.restype = ctypes.c_void_p
        shell32.SHBrowseForFolderW.argtypes = [ctypes.POINTER(BROWSEINFO)]
        shell32.SHGetPathFromIDListW.restype = wintypes.BOOL
        shell32.SHGetPathFromIDListW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
        ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]

        pidl = shell32.SHBrowseForFolderW(ctypes.byref(bi))
        if not pidl:
            return None
        buf = ctypes.create_unicode_buffer(260)
        ok = shell32.SHGetPathFromIDListW(pidl, buf)
        ole32.CoTaskMemFree(pidl)
        return buf.value if ok else None
    except Exception:
        return None


def is_link(p):
    try:
        a = ctypes.windll.kernel32.GetFileAttributesW(str(p))
        return a != 0xFFFFFFFF and a != -1 and bool(a & 0x400)
    except Exception:
        return False


def stat_dir(p):
    """返回 (文件数, 字节数, 是否链接)。跳过内部 junction 的内容。"""
    if not os.path.isdir(p):
        return (0, 0, False)
    if is_link(p):
        return (0, 0, True)
    n = 0
    b = 0
    for root, dirs, files in os.walk(p, onerror=lambda e: None):
        dirs[:] = [d for d in dirs if not is_link(os.path.join(root, d))]
        n += len(files)
        for f in files:
            try:
                b += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return (n, b, False)


def human(b):
    return "%.1f MB" % (b / 1024 ** 2) if b < 1024 ** 3 else "%.2f GB" % (b / 1024 ** 3)


def find_backups():
    """在各盘根目录下找可能的副本（名字叫 Tencent 的目录）"""
    found = []
    for drv in "DEFGHIJKLMN":
        root = drv + ":\\"
        if not os.path.isdir(root):
            continue
        for cand in (os.path.join(root, "appdata", "Tencent"),
                     os.path.join(root, "Tencent")):
            if os.path.isdir(cand) and not is_link(cand):
                found.append(cand)
    return found


def main():
    print("=" * 64)
    print("          微信 / QQ 数据恢复助手 v1.0")
    print("=" * 64)
    print("")
    print("本工具只做「复制」，不会删除你的任何文件。")
    print("")

    if not ORIGINAL:
        print("[错误] 取不到 APPDATA 环境变量，无法定位原位。")
        input("\n按回车退出...")
        return 1

    print("原位（C 盘）：%s" % ORIGINAL)
    on, ob, olink = stat_dir(ORIGINAL)
    if olink:
        print("  状态：**已经是一个链接**（指向别处）")
    elif os.path.isdir(ORIGINAL):
        print("  状态：目录存在，%d 个文件，%s" % (on, human(ob)))
        if on == 0:
            print("  ！目录是空的 —— 数据很可能已被删掉，需要从副本恢复。")
    else:
        print("  状态：**目录不存在** —— 需要恢复。")
    print("")

    # ---- 找副本 ----
    print("正在查找目标盘上的副本...")
    cands = find_backups()
    if cands:
        print("  找到 %d 处可能的副本：" % len(cands))
        for c in cands:
            n, b, lk = stat_dir(c)
            print("    [%d] %s  (%d 个文件，%s%s)"
                  % (cands.index(c) + 1, c, n, human(b), "，是链接" if lk else ""))
    else:
        print("  没自动找到。")

    backup = None
    if cands:
        msgbox("找到副本", "自动找到 %d 处副本：\n\n  %s\n\n"
                          "下一步请你确认用哪一个。"
               % (len(cands), "\n  ".join(cands)))
        idx = input("请输入序号（直接回车=手动选文件夹）：").strip()
        if idx.isdigit() and 1 <= int(idx) <= len(cands):
            backup = cands[int(idx) - 1]

    if not backup:
        msgbox("选择副本位置",
               "请选择当时转移到的目标文件夹。\n\n"
               "例如：D:\\appdata\\Tencent\n"
               "（要选到 Tencent 这一层）")
        backup = browse("请选择副本目录（例如 D:\\appdata\\Tencent）")

    if not backup:
        print("\n未选择副本，已取消。")
        input("\n按回车退出...")
        return 1

    if not os.path.isdir(backup):
        print("\n[错误] 目录不存在：%s" % backup)
        input("\n按回车退出...")
        return 1

    bn, bb, blink = stat_dir(backup)
    print("\n副本：%s" % backup)
    print("  %d 个文件，%s%s" % (bn, human(bb), "（是链接）" if blink else ""))

    if bn == 0:
        msgbox("副本是空的",
               "副本目录里没有文件：\n  %s\n\n"
               "请确认选对了文件夹（要选到 Tencent 这一层）。" % backup)
        return 1

    # ---- 同名保护 ----
    if os.path.abspath(backup) == os.path.abspath(ORIGINAL):
        msgbox("选择有误", "副本和原位不能是同一个目录。")
        return 1

    if olink:
        msgbox("原位已是链接",
               "原位已经是一个目录链接了：\n  %s\n\n"
               "这说明链接其实建成功了。请先打开微信看看；\n"
               "若确实没记录，再手动检查该链接指向的位置。" % ORIGINAL)
        return 1

    # ---- 确认 ----
    tip = ("即将把副本复制回原位（只复制，不删除任何东西）：\n\n"
           "  从：%s\n      %d 个文件，%s\n\n"
           "  到：%s\n      现有 %d 个文件，%s\n\n"
           "原位缺失的文件会被补齐；两边都有的文件以副本为准覆盖。\n"
           "确定开始吗？" % (backup, bn, human(bb), ORIGINAL, on, human(ob)))
    if not yesno("确认恢复", tip):
        print("\n已取消。")
        input("\n按回车退出...")
        return 1

    # ---- 恢复 ----
    print("\n开始恢复（大目录可能要几分钟，请耐心等待）...")
    os.makedirs(ORIGINAL, exist_ok=True)
    try:
        rc = subprocess.run(
            [ROBOCOPY, backup, ORIGINAL, "/E", "/XJ", "/COPY:DAT",
             "/R:2", "/W:2", "/NFL", "/NDL", "/NP"],
            timeout=3600)
        code = rc.returncode
    except Exception as e:
        print("[失败] %s" % e)
        input("\n按回车退出...")
        return 1

    if code >= 8:
        print("\n[失败] robocopy 返回码 %d，恢复未完成。" % code)
        msgbox("恢复未成功",
               "复制过程出错（robocopy 返回码 %d）。\n"
               "建议重启电脑后重新运行本工具。" % code)
        return 1

    an, ab, _ = stat_dir(ORIGINAL)
    print("\n恢复完成。")
    print("  原位现有 %d 个文件，%s（恢复前 %d 个，%s）"
          % (an, human(ab), on, human(ob)))

    if an >= bn:
        print("\n[OK] 文件数已达到副本水平，应该恢复完整了。")
    else:
        print("\n[提示] 原位 %d 个 < 副本 %d 个，可能有部分文件被占用没能拷贝。" % (an, bn))
        print("       建议关闭微信/QQ 后重新运行本工具再恢复一次。")

    msgbox("恢复完成",
           "恢复完成！\n\n"
           "原位现有 %d 个文件（%s）。\n\n"
           "请现在打开微信 / QQ 查看聊天记录。\n"
           "如果还看不到，请关闭微信后重新运行本工具再试一次。"
           % (an, human(ab)))
    print("\n请打开微信 / QQ 确认。")
    input("\n按回车退出...")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print("\n[异常] %s" % e)
        input("\n按回车退出...")
        sys.exit(1)
