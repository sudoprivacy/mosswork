---
name: skillhub-skill-clean-c-drive
description: "C 盘清理 / 数据迁移工具（双击即用 exe 的 skill 封装）。一键清理 Windows C 盘可再生缓存与残留——WorkBuddy 更新残留、TEMP 临时目录、WPS 缓存与备份、VS/Edge/Explorer 缩略图缓存、pip/npm 缓存、固定临时目录；清理已卸载软件的 AppData 残留（11 个常见软件，本体还在则跳过）；清理软件更新残留（安装包/下载缓存）；数据转移——弹框选目标盘，把微信/QQ/企业微信/百度网盘/PyCharm 等大目录 robocopy 复制到目标盘后删 C 盘原件并在原位置建 junction（软件仍按原路径读写）；WorkBuddy 数据迁移——把 %USERPROFILE%\\.workbuddy 搬到其它盘并建 junction（需先退出 WorkBuddy，自动检测进程并拦截，已迁移则自动识别跳过）。v1.7 安全加固：安装检测新"
---

# C 盘清理 / 数据迁移 Skill

把本机 C 盘清理工具封装为 skill，用户说"清理c盘"即可触发。脚本为纯标准库（os/shutil/ctypes/subprocess），无需任何第三方依赖。

## 使用方法（环境无关）

> 运行此 skill 的 agent 自带 `binary_context`，其中给出**本机** managed python 的绝对路径（形如 `…\binaries\python\versions\3.x.x\python.exe`）。下文以 `<PY>` 代指该路径——**切勿写死任何用户名或绝对路径**，换台机器就跑不了。

脚本已支持**命令行非交互模式**，agent 直接调用：

```
<PY> <本skill目录>/scripts/c_cleaner.py <命令>
```

| 命令 | 等价菜单 | 作用 | 是否破坏性 |
|---|---|---|---|
| `clean`（或 `1`） | [1] 一键清理缓存 | WorkBuddy残留 + TEMP + WPS + Edge/VS + pip/npm + AgentTemp | 只清可再生缓存，**安全，可自动执行** |
| `uninstall`（或 `2`） | [2] 卸载残留 | 已卸载软件的 AppData 遗留（本体还在则跳过） | 破坏性，执行前先告知 |
| `update`（或 `3`） | [3] 更新残留 | 软件更新遗留的安装包/下载缓存 | 破坏性，执行前先告知 |
| `migrate`（或 `4`） | [4] 数据转移 | 大目录搬到其他盘 + 建 junction（弹框选路径） | **迁移+删原件，必须用户确认** |
| `wb`（或 `5`） | [5] WorkBuddy 迁移 | `.workbuddy` 搬到其它盘 + 建 junction | **必须先退出 WorkBuddy，且用户确认** |
| `restore`（或 `6`） | [6] **数据恢复** | 把副本拷回原位（只复制，绝不删除） | **安全的补救操作**，可放心建议用户跑 |
| `all`（或 `7`） | [7] 全部清理 | clean + uninstall + update（不含迁移/恢复项） | 破坏性，执行前先告知 |

不带参数运行 = 交互式菜单（双击 / 手动跑给用户看）。菜单编号与命令字等价，数字请按上表。
**编号沿革**（易错）：v1.12 起 [6] 是**数据恢复**、[7] 才是全部清理（恢复紧挨迁移功能，逻辑更顺）；
v1.6~v1.11 时 [6] 是全部清理。改菜单编号时**必须同步** `_run_cli` 的 mapping 与 `main()` 的 elif 分支，
三者不一致会让 agent 调错功能（历史坑）。

## 数据恢复（迁移失败 / 聊天记录丢失时）— 已集成进主工具 [6]

若用户报告"迁移失败后微信/QQ 聊天记录没了"，直接让他跑主工具的 **[6] 数据恢复**，
agent 可用 `restore` 命令调起：

```
<PY> <本skill目录>/scripts/c_cleaner.py restore
```

- 原理：把目标盘副本（如 `D:\appdata\Tencent`）**拷回**原位置，**只复制、绝不删除**
  （robocopy `/E /XJ`，不带 `/MIR`、不带 `/PURGE`）
- 自动扫描**所有可用盘符**（`_logical_drives()` 动态枚举 C~Z，跳过 A/B 软驱）的三类落点找出副本：
  `<盘>:\<名字>` 根目录直放 / `<盘>:\<常见子目录>\<名字>`（appdata、AppData、backup、
  数据、备份、Data、MigrationData、WorkBuddyData、migrate）/
  **`<原位>.__cc_moving`**（v1.11 改名成功但清理失败时数据就在这里，最容易漏）
  —— 扫不到可手动选。
  **注意：自动扫描只做"尽力推断"，必须永远保留手动选择兜底**，否则别人目录习惯不同就用不了。
- 原位已是 junction 时先读链接目标并提示，**不盲目覆盖**
- 恢复完提示打开微信/QQ 验证；若文件数仍少于副本，建议关掉软件再恢复一次
- **v1.12 起不再分发独立的「微信数据恢复助手.exe」** —— 用户一句话点醒：
  问题是本工具造成的，恢复就该是它自己的一个功能；分开反而多一个拿错 exe 的风险
  （同事此前正是拿错旧版 exe 才出事）。`scripts/微信数据恢复助手.py` 保留作参考实现。

## 触发词 → 动作映射

- **"清理c盘" / "清理C盘" / "清缓存"** → 默认执行 `clean`（一键清理缓存，最安全），执行后把"释放 XX GB"汇报给用户。
- **"清理c盘全部" / "全部清理"** → 执行 `all`（clean+uninstall+update）。
- **"转移微信/QQ/聊天记录到其他盘"** → 执行 `migrate`，**必须**先向用户确认（涉及移动聊天记录、删原件、建链接，且会弹框选路径，需用户亲自操作）。
- **"迁移 WorkBuddy / 把 workbuddy 搬到其他盘 / .workbuddy 太大"** → 执行 `wb`。**必须先让用户完全退出 WorkBuddy**（脚本会 `tasklist` 检测 `WorkBuddy.exe` 并弹框拦截），再确认后弹框选目标盘。若 `.workbuddy` 已是 junction，脚本会自动识别并提示"已迁移过"，不重复操作。

## 安全边界（务必遵守）

1. **功能 1 `clean` 是唯一可无确认自动执行的**：它只清可再生缓存（TEMP、WPS 缓存、浏览器缓存、pip/npm 缓存等），不含任何文档、账号、聊天记录。
2. **`uninstall` / `update` / `all` 是删除操作**：执行前先用一句话告知用户"将清理哪些类目"，得到确认再跑。
   v1.7 起：命中高危路径（`Tencent Files` / `WeChat Files` / `xwechat_files` / `QMDownload` / `FileRecv`）时程序会自己弹二次确认框，
   文案明确写"这可能是聊天记录、图片或你接收的文件，删除后无法恢复"。**agent 绝不能替用户点，也不要用任何方式跳过这步。**
3. **`migrate`（数据转移）绝不自动执行**：它会把微信/QQ 数据搬到别的盘并删除 C 盘原件（改建 junction）。必须先让用户确认，且程序会弹 Windows 原生文件夹选择框，需用户亲手选目标盘——agent 不要替用户跳过这步。
4. 清理脚本**从不碰系统级目录**（Windows/Program Files），只动用户态缓存，无蓝屏风险。

## 关于脚本内置的固定路径

脚本里 `AGENT_TEMP = F:\WorkBuddy\AgentTemp` 是作者本机约定（AI 临时产物区）。在**没有该路径的机器上，`os.path.isdir` 判断为假会自动跳过**，不影响其余清理项，无需修改。其余清理目标全部由 `%APPDATA%`/`%LOCALAPPDATA%`/`%USERPROFILE%` 环境变量派生，跨机器通用。

## 打包成 exe（给没装 Python 的同事双击用）

**必须用专用打包环境** `F:\WorkBuddy\build_env\venv_pyinstaller`（PyInstaller 6.22.2）：

```bat
set TEMP=F:\WorkBuddy\tmp
set TMP=F:\WorkBuddy\tmp
F:\WorkBuddy\build_env\venv_pyinstaller\Scripts\pyinstaller.exe --onefile --console --noconfirm ^
  --name "C盘清理工具_v1.10_最新版" ^
  --distpath F:\WorkBuddy\cc_dist --workpath F:\WorkBuddy\cc_build --specpath F:\WorkBuddy\cc_spec ^
  scripts/c_cleaner.py
```

- **环境只建一次**：`<managed python> -m venv F:\WorkBuddy\build_env\venv_pyinstaller`
  然后 `Scripts\python.exe -m pip install pyinstaller`（约 3 分钟）
- 选址理由：不在 `AgentTemp`（工具功能 1 会清）、不在 `workbuddy_data`（WorkBuddy 运行时）、在 F 盘不占 C 盘
- 产物在 `F:\WorkBuddy\cc_dist\`，拷到工作空间 `C:\Users\25080\Desktop\办公小工具\`
- **版本策略**：保留最早基线 `C盘清理工具.exe`（v1.6）做对比，其余中间版本一律删掉，
  只留一个 `C盘清理工具_vX.X_最新版.exe`。**（v1.10 起）同事曾错拿了 v1.8 跑出 bug，
  多版本并存 = 拿错风险，除基线外不留中间版。**
- 双击 exe = 交互式菜单；命令行 `C盘清理工具_v1.10_最新版.exe clean` 也能一键清理
- 冒烟必做：`<exe> zzz` 应输出"未知命令"且 rc=2；不带参数应渲染出正确版本号菜单

## 关键坑（血泪经验）

1. **ctypes 调 Win32 API 必须声明 `restype`**：`SHBrowseForFolderW` 等返回指针/句柄的 API，若不显式 `restype = ctypes.c_void_p`，64 位系统上 PIDL 指针被截断为 32 位 → 选完文件夹就闪退。本机测试可能不炸，同事电脑现形。
2. **`_is_reparse_point` 对不存在路径要排除 -1 和 0xFFFFFFFF 两种形式**：`GetFileAttributesW` 路径不存在时 ctypes 有符号解释为 -1，只排 0xFFFFFFFF 会漏 → 误报成链接导致目录被跳过。
3. **迁移类"删除源"环节绝不连目标副本一起删**：删除原目录失败时（`rmtree` 遇占用文件删剩一部分返回 False），必须保留目标盘完整副本，否则"原目录删一半 + 副本被删"= 真丢数据。宁可留双份冗余也不能丢数据。
4. **junction 用纯内置 `_winapi.CreateJunction(目标, 链接)`**：第一参=真实目录、第二参=要创建的链接；不依赖 PowerShell/cmd（cmd mklink 常被安全策略禁止）。
5. **`_try_remove` 遇重解析点只删链接点本身**：`os.path.islink()` 对 junction 返回 False，必须靠 `_is_reparse_point` 防护，否则会把已迁移目录当残留 `rmtree` 递归删掉目标盘真实数据。
6. **数据转移前必须关闭微信/QQ/企业微信/百度网盘/PyCharm**：文件被占用会导致 robocopy 复制不完整或原目录删不干净。
7. **重解析点预检要放在 `_migrate_dir()` 函数级，不能只放在调用它的循环里**：只对源目录做一次 `os.path.isdir` 判断就进 robocopy，会穿透 junction 把目标盘真实数据再复制一份（套娃 `F:\...\Tencent\Tencent`），空间预检还会误判不足。任何复用 `_migrate_dir` 的新功能都自动继承该防护。
9. **安装检测不能只扫 Program Files**（v1.7 修复的真实事故）：很多人把软件装在 D/E 盘或自定义目录，
   只扫 4 个固定位置会把**仍在使用的软件**误判为"已卸载"，进而删掉 `Documents\WeChat Files` / `Tencent Files`
   里的聊天记录和图片。本机实锤：微信装在 `E:\WeChatRunning\WeChat`，v1.6 判定"已安装 = False"，
   若聊天目录存在就会被整个删掉。修复=注册表卸载项反查兜底（`HKLM\SOFTWARE\WOW6432Node\...\Uninstall`
   读 DisplayName + InstallLocation），并给每个软件补中文名（注册表里 DisplayName 多为中文）。
10. **注册表匹配要用精确/前缀，别用子串**：`install_names` 含 `QQ` 时若用子串匹配，`QQ音乐` 会被误判成 QQ 已安装
    （漏清残留）。现用 `nm == nl or nm.startswith(nl + " ")`，`QQ音乐` 不会匹配 `QQ`。
12. **robocopy 必须加 `/XJ`**（v1.8 修复）：源目录里若含 junction（如 `Tencent\xwechat` 已迁到 E 盘），
    默认 robocopy 会**跟随链接把 E 盘真实数据整份再复制一遍**到目标盘 —— 空间浪费 + 预检误判。
    但加了 `/XJ` 后这些链接不会被复制，删掉原件就会**链接断裂、软件找不到数据**，
    所以必须配合 `_rebuild_inner_junctions()`：复制后用 `os.readlink()` 读出原链接目标，在目标盘原样重建。
    `os.readlink()` 返回 `\\?\E:\xxx` 形式，要去掉前 4 个字符。
13. **完整性校验别用「大小百分比 + 大阈值」**：原逻辑 `dst < src*0.95 且 差>200MB` 才拦截，
    少量丢失（多半是被占用的缓存/配置文件）根本检测不到，删掉原件后那部分**永久丢失**。
    改为 `_count_files()` 文件数对比（缺一个就中止）+ 大小差 >10MB 中止。
    **注意 `_size_of`/`_count_files` 都要跳过 junction**，否则口径与 `/XJ` 不一致会误判。
14. **进度提示不能代替真检测**：功能 4 原本只是文字提示"请先关闭微信/QQ"，
    用户没关照样往下跑。v1.8 加了 `tasklist` 真检测（`_running_processes`）并弹框拦截。
    凡是"请先关闭 XX"的场景，都应该真的去查进程。
15. **弹窗必须绑控制台窗口 + 置顶**（v1.9 修复）：`MessageBoxW(0, ...)` 不带父窗口时，
    弹框会出现在屏幕中央或别的窗口后面，用户以为"卡了"其实在等他点。
    修正：`GetConsoleWindow()` 取 cmd 窗口句柄，传给 `MessageBoxW(hwnd, ...)`，
    加 `MB_SETFOREGROUND | MB_TOPMOST` 标志，弹窗前先 `SetForegroundWindow(控制台)`。
    `SHBrowseForFolderW` 的 `BROWSEINFO.hwndOwner` 同理要传控制台句柄。
16. **Windows 上"关掉软件"≠"文件句柄已释放"**（v1.10 修复，同事实锤事故）：
    同事关掉所有有窗口的 app 后跑功能 4，robocopy 复制成功、完整性校验通过，
    最后一步「删除 C 盘原目录」仍失败 —— 因为腾讯系有一批**无窗口的后台服务**
    还在写文件：`QQProtect` / `QQPCRTP` / `TXPlatform` / `QQMail` /
    `QQMicroGameBoxTray` / `WeChatUpdate` / `WeChatAppEx` / `WeChatPlayer` /
    `WXWorkWorkbench` / `QQExternal` / `QQAppLauncher`。
    **两条硬规则**：
    ① 进程名单必须列到后台服务层，主程序名单（WeChat.exe 等）远远不够；
    ② **进程检测要放在"删除动作之前"，不是流程开头**。7GB 复制要 5~10 分钟，
       开头查干净不代表删的时候还干净，后台服务中途会重新握把柄。
       实现：`_ensure_no_locks(src, dst)` 在删原件前重查一次，
       命中就列出具体进程名 + 弹框询问，用户同意后 `taskkill /F /IM` 逐个结束，
       `sleep 2` 等系统释放句柄，再复查一次才放行。
    ③ 配套 `_remove_with_retry()`：删除失败重试 3 次（每次 3 秒），
       扛住 Defender 实时扫描 / explorer 缩略图这类**瞬时占用**。
       原来一次失败就放弃，用户白等 10 分钟复制。

17. **【最严重】绝不能用 `shutil.rmtree` 直接删原件 —— 它失败时已经删掉一半了**（v1.11 修复，已造成真实数据丢失）：
    事故：同事跑功能 4，最后一步提示"[失败] 原目录删除失败（可能被占用）"，
          随后微信登录上去**聊天记录全没了** —— 数据去了 D 盘，但原位没建成链接。
    根因：`rmtree` 是**边删边走**的。遇到被占用文件由 `_rmtree_onexc` 吞掉异常后
          **继续删其它文件**，等删完能删的，还剩几个占用文件使 `os.path.exists(src)` 为真
          → 工具判定"删除失败" → 不建链接 → 直接返回。
          **但此时原目录已经被删掉一大半了！**
          此前"迁移失败也保证安全"只保住了目标盘副本，**没保住 C 盘原件** —— 这是设计缺陷。
    **通用铁律：任何"先删再建"的流程都是错的。**
          正确顺序永远是「先让新路径可用，再清理旧路径」，
          且清理必须是**可失败、可重试、不影响功能**的善后步骤。
    **正确实现（rename-before-delete，v1.11 采用）**：
      ```python
      src_bak = src + ".__cc_moving"
      os.rename(src, src_bak)          # ① NTFS 同卷改名，瞬时、几乎不可能失败
      if not _make_junction(src, dst): # ② 路径已腾空，立刻建链接，软件毫秒级恢复
          os.rename(src_bak, src)      #    建链接失败 → 改名回滚，零损失
          return False
      _remove_with_retry(src_bak)      # ③ 删旧数据降级为善后；失败也只影响 C 盘空间
      return True                      #    清理失败照样返回 True！
      ```
      效果：清理失败 → 链接照样建成、数据照样能读、返回照样成功。
    **配套**：发现上次残留的 `.__cc_moving` 时必须**先弹框说明再决定是否清理，绝不盲删**
           （那里面可能就是用户唯一的数据）。

18. **写测试脚本时，`os.environ.setdefault("APPDATA", ...)` 是陷阱**：
    若 shell 里 `APPDATA` 已存在，`setdefault` 不生效 → 测试会指向**真实的**
    `C:\Users\<你>\AppData\Roaming\Tencent`，数据会被写进真目录（本次差点发生）。
    **必须用 `os.environ["APPDATA"] = <临时路径>` 强制覆盖**，不要用 setdefault。
    任何脚本只要在模块级读 `APPDATA`/`LOCALAPPDATA`/`USERPROFILE` 派生路径，
    测试时都得这么处理。
