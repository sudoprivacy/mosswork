---
name: skillhub-skill-tri-sales
description: "B2B 销售使能与收入运营方法论知识包（横向型方法论领域入口 skill）——把「机会资质审查（MEDDPICC）、销售发现与信息传递、售前与技术赢标、管道与预测经营、增长与商机获取」五条方法轴整理为可检索可执行的规则集，支持独立安装，含上游依赖检测两态逻辑。当用户说「怎么评估/管理一笔销售机会」「怎么做销售发现与信息传递」「售前 Demo/POC 与投标怎么写」「怎么管 Pipeline 与 Forecast」「怎么获客触达」时激活；也供下游 skill（tri-pm 等）引用方法论规则时参考。"
---

# 销售使能与收入运营（tri-sales · 横向型方法论领域入口 skill）

> 本 skill 是**横向型方法论知识包**：由用户显式调用或下游 skill 引用激活，**不由 tri-intent 依 L2 直接路由**。
> **对照基准**：对照基准档 §4.1.2（立项规格）+ 对照基准档（阶段一全量分析报告，2026-09-20）。本包每条方法论规则 MUST 标注基准锚点（对照基准档 § 章节锚点）；**NEVER 引入基准外能力断言**（一致性红线，用户任务硬约束）。
> 用户心智：把 AI 当「销售方法论检索器与应用器」——问一条销售打法，拿到范式原文 + 基准锚点 + 应用方式；给一个"怎么评估单子/怎么管 Pipeline/怎么打这场仗"的问题，给出方法论指导。

## 强制执行契约（Execution Contract · 最高优先级）

> 本节定义 skill「被激活后必须做什么」，优先级高于 Agent 的通用默认行为。**用户命中触发语或下游 skill 引用本包规则即视为激活本工作流**，不得仅将其当作参考文档。

0. **版本检查前置硬门（第零步）**：MUST 先通过 §版本检查与更新机制（运行 `scripts/check_update.py`，按 `references/version-check-spec.md` 四态判定处置；非最新版自动升级，升级通道不可用则降级继续）——此为执行流程第零步，优先于后续所有步骤。版本检查完成前 NEVER 进入后续步骤。本条目优先级高于所有其他强制前置条目。
1. **教训预载**：版本检查后 MUST 优先读取 `.tribro/sales/lessons.md`（历史执行沉淀的经验教训）；目录或文件不存在时静默跳过——NEVER 报错、NEVER 阻断、NEVER 追问。
2. **一致性红线（本 skill 第一性规则）**：输出的每一条销售方法论规则 MUST 与对照基准一致并标注基准锚点（对照基准档 §4.1.2 / 分析档 § 章节锚点）；基准未记载的行为细节 MUST 显式标注「基准未展开，细节以原角色文件为准」（置信度标注降为推断）；**NEVER 编造方法论未记载的打法或规则**。
3. **内容外部引用（版权与一致性红线）**：销售角色正文为外部内容资产，MUST 保持为外部引用源（NEVER 逐字内嵌），**NEVER 将角色正文逐字内嵌本包**；本包只承载"方法论、范式、打法规则"。
4. **结论置信标注**：本 skill 产出的每一个结论性表达 MUST 附三要素：① 置信度（高/中/低）；② 依据类型六选一（`事实 known`/`计算 computed`/`推断 inferred`/`常识 common`/`框架 iframe`/`猜测 guess`）；③ 可验证来源（URL 或 `file:line` 或显式「无外部来源」）。`guess` 类标低置信并提示人工验证。
5. **自检**：作答前用一句话声明「本次操作=<方法检索/流程指导/对照校准>，触发源=<用户显式/下游引用>，已读取<方法论索引/教训=<N 条/无文件>>」，若与上述规则冲突则停止并纠正。
6. **MUST/NEVER 大写**：契约与关键规则一律大写祈使；描述性文字不受限。

## 触发时机

**激活分支**（由用户显式调用 / 下游 skill 委派激活，不由 tri-intent 依 L2 直接路由）：

| 触发分支 | 典型信号 | 模式 |
|---|---|---|
| 用户显式调用 | 「怎么评估/管理一笔销售机会」「怎么约个有效的 Discovery」「售前 Demo/POC 怎么写」「怎么管 Pipeline 与 Forecast」「怎么获客触达」 | 模式 A/B |
| 下游 skill 引用 | tri-pm 等需要销售侧方法论佐证（产品卖点→销售价值叙事） | 模式 C |
| 方法检索 | 「本包里怎么说 MEDDPICC/Challenger/Pipeline」「某类销售单子怎么打」 | 模式 A |

**不由本 skill 处理**（命中以下信号 MUST 指向对应 skill，NEVER 在本工作流内代办）：

| 信号 | 归属 |
|---|---|
| 意图识别与路由 | tri-intent |
| 通用对象/方法论整理为 skill | tri-god |
| skill 生成与补全 | 家族内部工具 |
| 产品管理（PRD/路线图/需求，交付产品成果物） | tri-pm |
| 防御性安全 / 进攻性安全 | tri-security / tri-reverse |
| 通用内容生产（非销售叙事） | tri-content / tri-article |

## 输入契约

| 字段 | 用途 | 默认值 |
|---|---|---|
| `mode` | 方法检索 / 流程指导 / 对照校准 | 由触发信号推断 |
| `target` | 任务描述、问题、或待检索的销售打法/环节 | 必填（缺失时从对话上下文提取；仍缺失则列方法论索引供用户选择） |
| `context` | 当前销售阶段/单子规模/团队/约束（用于规则的具象化建议） | 可选 |

## 职责边界

- **本 skill 负责**：机会资质审查（MEDDPICC）、销售发现与信息传递、售前技术赢标、管道与预测经营、增长与商机获取五条方法轴的检索（模式 A）、流程指导（模式 B）、为下游 skill 提供销售侧方法论佐证（模式 C）；全部输出锚定对照基准。
- **不负责**：意图识别（tri-intent）、通用整理（tri-god）、skill 生成（家族内部工具）、产品管理（tri-pm）、安全生产业（tri-security/tri-reverse）、通用内容生产（tri-content/tri-article）。
- **关键边界**：本包是「销售方法论 + 应用指导」，不是「角色内容库本身」——不搬运 9 个销售角色正文；具体话术模板、CRM 配置、单子明细属于销售团队运营，方法论可给、正文不搬。
- **不触发场景（Not-Trigger）**：本 skill 不接手「意图识别」（转 tri-intent）；不接手「通用对象/方法论整理」造 skill（属 tri-god）；不接手「skill 生成」（属 家族内部工具）；不接手「产品管理与产品交付」（属 tri-pm，以交付对象是产品成果物还是销售落单区分）；不接手「安全方法论」（属 tri-security/tri-reverse）；不接手「专家 Persona 定义范式/角色库」（外部引用，对应模块已移除）。

## tri-sales 方法论（可扩展）

> 核心内容为「一张方法轴地图 + 三条核心设计决策 + 五篇规则集」。地图常驻本文件；规则集按需加载 references/。

### 方法轴地图（对照基准：对照基准档 §4.1.2；置信度：高；依据：事实 known + 框架 iframe）

| 方法轴 | 核心规则 | 来源角色 | 对应 references |
|---|---|---|---|
| 机会资质审查 | MEDDPICC 八要素逐项打分 + 资质记分 / 风险暴露 + Pipeline Review / 杀死单子的危险信号 | sales-deal-strategist | meddpicc-qualification.md |
| 销售发现与信息传递 | Discovery 诊断（问题设计/现状诊断/差距量化）+ Challenger 6 步 Commercial Teaching + Command of the Message 价值支柱 | sales-deal-strategist、sales-discovery-coach | discovery-message.md |
| 售前与技术赢标 | 技术 Discovery / Demo 设计 / POC 执行 + 竞争技术定位 + 投标赢标叙事与执行摘要 | sales-engineer、sales-proposal-strategist | presales-bid.md |
| 管道与预测经营 | Pipeline 健康诊断 + 单子速度分析 + Forecast 准确度 + 数据驱动销售辅导 | sales-pipeline-analyst、sales-coach | pipeline-forecast.md |
| 增长与商机获取 | Outbound 信号触达 + ICP + 多渠道序列 + Land-and-Expand + Offer/Lead Magnet | sales-outbound-strategist、sales-account-strategist、sales-offer-lead-gen-strategist | gtm-engagement.md |

### 核心设计决策三条（对照基准档，置信度：高；依据：事实 known + 推断 inferred）

1. **资质重于人脉**：把每笔单子当作战略问题而非人情工程；资质缺口（MEDDPICC 任一项缺失）越早暴露，输单越早注定——全框架评估才能把真实 Pipeline 和水分分开（来源 sales-deal-strategist 身份段）。
2. **只求真实的 Forecast**：Forecast 不乐观、不保守、只求真实——把水分和风险在变成丢掉的季度之前就暴露出来，单子级检查让 Forecast 有据可查（来源 sales-deal-strategist / sales-pipeline-analyst）。
3. **先改变认知再谈产品**（Challenger）：信息传递用颠覆性洞察引领 Commercial Teaching——在呈现方案前先改变客户对自身问题的认知，产品应是水到渠成的结论而非销售推介（来源 sales-deal-strategist Challenger 段）。

补充：**用户显式指令优先于方法论规则**（保留人工否决权；话术可因地制宜，方法论内核不变）。

### 知识装配顺序（约束 25 · Prompt Layering）

| 层 | 载体 | 加载时机 |
|---|---|---|
| ① 常驻层 | 本文件（SKILL.md：方法轴地图/决策/流程） | 每次激活 |
| ② 方法论层 | references/ 五篇方法论文档（按 mode/target 命中加载；version-check-spec.md 不在此层） | 模式判定后按需 |
| ③ 用户指定层 | 用户点名某方法轴/某场单子细节时加载对应篇 | 显式要求 |
| ④ 外部覆盖层 | 无——本包自包含；外部角色正文仅为内容引用源，NEVER 覆盖本包结论（以对照基准为准） | — |

装配去重：同名规则只取 references/ 一处（本文件地图仅留指针）。

**grep 检索模式（MUST 用轴锚点，NEVER 用裸关键词）**：每篇 references 首行之后带机器可读轴锚 `<!-- axis: <轴名> -->`，定位方法轴时 MUST 用

```bash
grep -l "<!-- axis: meddpicc -->" references/*.md    # 轴名：meddpicc/discovery/presales/pipeline/gtm
```

> 为什么不用裸关键词：跨篇联动指针（如「联动 meddpicc 的 Metrics/Pain」）会把索引词扩散到其余篇——实测 16 个索引关键词中 8 个不唯一命中，`MEDDPICC` 更是五篇全中（置信度：高；依据：计算 computed）。**轴锚点是唯一可靠的定位方式**。
> 关键词仅用于锚定篇内小节：`grep -n "Economic Buyer" references/meddpicc-qualification.md`。

## 处理流程（三模式）

```
激活（用户显式 / 下游引用）
  │
  ▼
第零步 版本检查 → 教训预载 → 自检句声明
  │
  ▼
模式判定
  ├── A 方法检索：定位方法轴地图行 → 加载对应 references 篇 → 输出范式原文摘要 + 基准锚点 + 应用建议
  ├── B 流程指导：按「评估单子 / 做 Discovery / 打售前 / 管 Pipeline / 做获客」定位用户所处环节 → 给环节 MUST 规则 + Red Flags 反模式 + 下一步动作
  └── C 对照校准：下游 skill 引用销售方法论时 → 给出规则原文 + 锚 + 对当前争论的裁决建议
  │
  ▼
输出（每条结论附置信标注三要素）→ 教训追加写入 .tribro/sales/lessons.md
```

- **模式 A 输出格式**：方法名 / 方法内容（压缩自对照基准）/ 基准锚点 / 置信三要素 / 一句应用建议。
- **模式 B 输出格式**：当前环节定位 → 该环节 MUST 规则（≤5 件）→ Red Flags 反模式 → 下一环节。
- **模式 C 输出格式**：被引规则原文 + 基准锚点 + 对当前争论的裁决建议。

## 交付产物机制

| 产物 | 载体 | 内容 |
|---|---|---|
| 方法卡片 | 对话输出 | 单条销售打法：内容+锚+置信+应用建议（模式 A/C） |
| 流程指导 | 对话输出 | 环节规则清单+反模式+下一步（模式 B） |
| 单子/场景诊断 | 对话输出 | 给出该单子的评估维度核对清单 + 危险信号扫描（应需给出） |
| 教训记录 | `.tribro/sales/lessons.md` | 本次执行的情境化教训（追加式，空泛内容禁写入） |

> 本 skill 为知识包，无独立文件交付物；对话输出即产物。若用户要求把某次方法论应用固化为文档，落盘至用户指定路径（不落 `.tribro/sales/` 以外的包内路径）。

## 质量标准

| 维度 | 标准 | 验证方式 |
|---|---|---|
| 一致性 | 每条规则可回溯对照基准锚点（审计 § / 角色来源）；无基准外能力断言；不内嵌销售角色正文 | 抽查任一输出，锚点可在对照基准/角色文件 grep 到 |
| 置信标注 | 结论性表达 100% 附三要素；guess ≤10% | grep 输出「置信度」 |
| 规则可检索 | references/ 每篇带轴锚 `<!-- axis: -->`；地图行均有指针 | `grep -l "<!-- axis: X -->" references/*.md` 唯一命中 |
| 记分确定性 | 资质记分 MUST 由 `scripts/meddpicc_score.py` 产出，NEVER prompt 层心算 | `python scripts/meddpicc_score.py --selfcheck` 全过 |
| 置信标注 | 结论性表达 100% 附三要素；guess ≤10% | `python scripts/conf_lint.py` 退出码 0 |
| 规模合规 | SKILL.md ≤500 行；references/ 单篇无膨胀（纯规则，无脚本内联） | `wc -l` |
| 版本一致 | SKILL==CHANGELOG==_meta==tests==README 版本号 | grep 版本串 |

## 落盘规则

- 本包自身：`.tribro/skills/tri-sales/`（生成物指定落盘位置，门③已执行；不经 install_skill.py，用户选定仅落盘）。
- 教训文件：`.tribro/sales/lessons.md`（启动读取；结束 MUST 追加写入；目录或文件不存在时创建；写入失败 MUST 提示用户但不阻断交付）。
- NEVER 生成 `LICENSE` 或 `.gitignore`——许可证仅由 frontmatter `license: MIT` 声明。

## 版本检查与更新机制（强制技术约束 · 硬红线）

> 家族级强制技术约束，优先级与「强制执行契约」同级。skill 任一执行入口启动后的**第零步**，先于核心执行阶段。
> **细则唯一真源**：`references/version-check-spec.md`（家族规范源，由家族规范维护）。**可执行实现**：本包 `scripts/check_update.py`（按 `--slug` 自适应）。
> **铁律**：版本比较、升级执行、回退、四态判定 MUST 由脚本完成；prompt 层 ONLY「调用脚本 + 解析 JSON + 按 state 处置」，NEVER 在 prompt 内联推断版本或拼接升级命令。

**执行方式（MUST）**

1. 启动后、核心执行前运行：`python scripts/check_update.py --slug tri-sales --json`
2. 解析 `state` 字段：`A`/`B`/`C`/`D` → 一律放行（据 warnings/notes 标注口径）；`BLOCK` → 绝对禁止执行，按 `block_code` 输出结构化恢复指引。
3. 退出码语义：`<20` 放行，`>=20` 阻断；脚本自身异常时兜底降级放行，NEVER 因版本门自身故障阻断 skill 启动。
4. 节流：24h 内仅校验一次；`--force` 强制重查；`--dry-run` 只判定不真升级。完整细则见 `references/version-check-spec.md`（本章节 NEVER 内联）。

## 目录结构

```
tri-sales/
├── SKILL.md                              # 本文件（方法轴地图 + 决策 + 流程，≤500 行）
├── README.md
├── CHANGELOG.md
├── _meta.json
├── scripts/
│   ├── check_update.py                   # 版本检查（第零步硬门，家族共用同一份逻辑）
│   ├── meddpicc_score.py                 # MEDDPICC 资质记分（权重/证据分档/危险信号否决，确定性真源）
│   └── conf_lint.py                      # 结论三要素校验（契约第 4 条门禁，A/B 分类）
├── references/
│   ├── meddpicc-qualification.md         # 机会资质审查（MEDDPICC 八要素 + 记分 + Deal Review）
│   ├── discovery-message.md              # 销售发现与信息传递（Discovery + Challenger + Value）
│   ├── presales-bid.md                   # 售前与技术赢标（Demo/POC + 竞争技术定位 + 投标叙事）
│   ├── pipeline-forecast.md              # 管道与预测经营（Pipeline + 单子速度 + Forecast + 辅导）
│   ├── gtm-engagement.md                 # 增长与商机获取（Outbound + Land-and-Expand + Offer）
│   └── version-check-spec.md             # 版本门细则（STUB 指向，NEVER 内联）
└── tests/
    └── tri-sales-full-testcases.md
```

## 完成判据（外化 · 可机械校验）

一次执行的「结束态」MUST 同时满足以下全部判据（缺一为「停车态」——继续执行直至满足或按规则标注受阻原因后交还用户）：

1. 输出含自检句（本次操作=<模式>，触发源=<来源>，已读取教训=<N 条/无文件>）；
2. 输出中每条结论性表达附置信三要素（grep「置信度」可命中）；
3. 每条方法论规则附对照基准锚点（对照基准档 § 章节锚点）或「基准未展开」降级标注，且不内嵌销售角色正文；
4. 教训文件已追加写入（或写入失败已提示用户）。

## 进化契约（自进化三要素 + 教训文件读写闭环）

1. **反馈接收点**：用户对某条销售方法论的偏差修正（如「MEDDPICC 不是这个意思」）→ 视为对照基准缺口，回写教训文件并在下次输出中降级该规则的置信标注；重大偏差 MUST 提示用户「对照基准需修订」。
2. **经验沉淀位**：`.tribro/sales/lessons.md`（追加式；每次执行结束 MUST 写入可操作的规避动作，空泛内容 NEVER 写入，无新增写「无新增」占位留痕）。
3. **自我修订触发条件**：① 对照基准更新（如对照基准档修订）→ 本包 bump MINOR 并全量校对规则锚点；② 同类教训连续出现 ≥3 次 → 将规避动作固化为 SKILL.md 规则条目（bump PATCH）；③ 版本联动：任何修订 MUST 同步 SKILL/CHANGELOG/README/_meta/tests 五处版本号。