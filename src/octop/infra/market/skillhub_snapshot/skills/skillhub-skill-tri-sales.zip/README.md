# tri-sales · 销售运营（RevOps）

> `tri-sales`（v1.0.0）是 tri-xxx 家族**横向型方法论领域入口 skill**：把「机会资质审查、销售发现与信息传递、售前与技术赢标、管道与预测经营、增长与商机获取」五条方法轴整理为可检索、可执行的**B2B 销售方法论规则集**。

## 这是什么

- **不是**「销售角色内容库」——角色正文为外部内容资产，保持外部引用（内容版权与一致性红线）。
- **是**「销售方法论的检索器与应用器」：机会资质审查（MEDDPICC）、销售发现与信息传递、售前与技术赢标、管道与预测经营、增长与商机获取五条方法轴。
- 每条方法论规则锚定对照基准档章节锚点，零基准外断言。

## 由用户显式调用 / 下游引用激活

| 场景 | 你会得到 |
|---|---|
| 「怎么评估/管理一笔销售机会」 | MEDDPICC 八要素记分 + Deal Review 探查问题 + 杀死单子的危险信号 |
| 「怎么做有效的 Discovery / 信息传递」 | Discovery 诊断 + Challenger 6 步 Commercial Teaching + 价值表达三支柱 |
| 「售前 Demo/POC 与投标怎么写」 | 技术赢标三步走 + 赢标叙事 + 结论先行执行摘要 |
| 「怎么管 Pipeline 与 Forecast」 | 管道健康诊断 + 单子速度 + 只求真实的 Forecast + 数据驱动辅导 |
| 「怎么获客触达」 | Outbound 信号触达 + ICP + Offer/Lead Magnet + Land-and-Expand + NRR |

## 开头要了解的三点

1. **资质重于人脉**：把每笔单子当作战略问题而非人情工程——资质缺口越早暴露，输单越早注定。
2. **只求真实的 Forecast**：Forecast 不乐观、不保守、只求真实——证据支撑，把水分在变成丢掉的季度前暴露。
3. **先改变认知再谈产品**（Challenger）：在呈现方案前先改变客户对自身问题的认知——产品是水到渠成的结论而非销售推介。

## 安装与使用

- 本包落盘于 `.tribro/skills/tri-sales/`，并已按家族硬约束（约束 21）经 `家族安装脚本` 安装到 **workbuddy + trae_cn** 双平台（junction 单源同步，冒烟激活通过）。
- 独立重装：`python 家族安装脚本 --skill .tribro/skills/tri-sales --force`。
- 首次使用：`python scripts/check_update.py --slug tri-sales --json` 执行第零步版本门。

## 目录结构

```
tri-sales/
├── SKILL.md                             # 方法轴地图 + 决策 + 流程
├── README.md
├── CHANGELOG.md
├── _meta.json
├── scripts/
│   ├── check_update.py                  # 版本检查（第零步硬门）
│   ├── meddpicc_score.py                # MEDDPICC 资质记分（权重/证据分档/危险信号否决）
│   └── conf_lint.py                     # 结论三要素校验（契约第 4 条门禁）
├── references/
│   ├── meddpicc-qualification.md        # 机会资质审查
│   ├── discovery-message.md             # 销售发现与信息传递
│   ├── presales-bid.md                  # 售前与技术赢标
│   ├── pipeline-forecast.md             # 管道与预测经营
│   └── gtm-engagement.md                # 增长与商机获取
└── tests/
    └── tri-sales-full-testcases.md
```

## 可执行口径（机械校验）

```bash
python scripts/check_update.py --slug tri-sales --json   # 第零步版本门
python scripts/meddpicc_score.py --selfcheck             # 八要素记分回归（7 例）
python scripts/conf_lint.py                              # 结论三要素覆盖率门禁
grep -l "<!-- axis: meddpicc -->" references/*.md        # 按方法轴定位篇
```

记分口径（权重、证据三档、危险信号一票否决）以 `scripts/meddpicc_score.py` 为唯一真源，
`references/meddpicc-qualification.md`「记分口径」小节只做指针——NEVER 在对话里心算记分。

## 版本

当前版本：**1.0.0**（2026-09-20 首发）。按家族「版本号发布时点铁律」，本包尚未发布到 skillhub，本地变更记入 CHANGELOG `[未发布]` 条目，发布时再合并升版。版本演进见 [CHANGELOG.md](CHANGELOG.md)。

## 责任边界说明

本 skill 只管「销售五条方法轴的范式检索、流程指导、对照校准」；不接手意图识别（tri-intent）、通用整理（tri-god）、skill 生成（家族内部工具）、产品管理（tri-pm，以交付对象是产品成果物还是销售落单区分）、安全生产业（tri-security/tri-reverse）、通用内容生产（tri-content/tri-article）、专家 Persona 库（外部引用，对应模块已移除）。