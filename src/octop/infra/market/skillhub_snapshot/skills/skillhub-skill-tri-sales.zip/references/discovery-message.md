# 销售发现与信息传递（Discovery 诊断 + Challenger Commercial Teaching + Command of the Message）
<!-- axis: discovery -->

> 锚定对照基准：对照基准档 §4.1.2（M1 Discovery 诊断：问题设计 / 现状诊断 / 差距量化 / 通话结构）。
> 基准角色文件未展开的细节以原仓库 `sales-discovery-coach.md` 为准（置信度：中；依据：推断 inferred）。

## 一、Discovery 诊断（挖掘购买动机）

目标：挖出客户真正的购买动机，而不是完成一次"同质化对话"。核心能力：问题设计、现状诊断、差距量化、通话结构（来源 sales-discovery-coach 描述段）。（置信度：高；依据：框架 iframe；来源：sales-discovery-coach / sales-deal-strategist 对应段）

- **问题设计**：问能暴露现状与目标差距的问题；NEVER 用"什么让你夜不能寐"这类把控制权完全交给客户的标准开场。（置信度：高；依据：框架 iframe；来源：sales-discovery-coach / sales-deal-strategist 对应段）
- **现状诊断**：弄清当前怎么做、代价是什么、谁负责指标。（置信度：高；依据：框架 iframe；来源：sales-discovery-coach / sales-deal-strategist 对应段）
- **差距量化**：把从现状到目标的差距翻译成可量化业务后果（联动 MEDDPICC 的 Metrics/Pain）。
- **通话结构**：一次发现通话 MUST 有明确的开场/主议程/下一步，结尾产出"已确认的事实 + 待补的缺口"，不留模糊带。（置信度：高；依据：框架 iframe；来源：sales-discovery-coach / sales-deal-strategist 对应段）

## 二、Challenger 信息传递——Commercial Teaching

**Teaching Pitch 结构**：挑战者方法论把传统 Discovery 颠倒过来——先抛出客户没想到的颠覆性洞察，再关联到一个他们不知道存在（或不知怎么解决）的问题（来源 sales-deal-strategist Challenger 段）。

**6 步 Commercial Teaching 序列**：

1. **暖场**：展示对其环境/行业/客户群常见挑战的理解，建立可信度——是模式识别，不是恭维。
2. **重新定义**：引入挑战当前假设的洞察（"多数公司用传统方法，数据显示它在规模化时会崩溃"）。
3. **理性冲击**：量化维持现状的代价——堆叠证据（基准数据/客户案例/行业报告）直到现有方案变得不可接受。
4. **情感共鸣**：让代价个人化——谁的团队每天承受这个痛点？负责指标的 VP 会面临什么？用理性论证、用情感驱动。
5. **新路径**：呈现替代方案——先不是你的产品，而是一种以不同方式解决问题的框架/方法论。
6. **你的方案**：把产品与新路径关联——产品应像水到渠成的结论，而不是销售推介。

## 三、Command of the Message——价值表达三支柱

每段价值的构建围绕三个支柱（来源 sales-deal-strategist Message 段）：

1. **我们解决什么问题？**——针对客户的具体场景；泛泛价值主张 = 没做过 Discovery。
2. **我们如何不同地解决？**——差异化必须可证明且相关（"我们的 ML 模型把误报率降 74%，因为我们基于你的历史数据训练"才是差异化；"我们有 AI"不是）。
3. **客户获得什么可衡量的成果？**——证据而非承诺；引用他们行业、他们规模的客户的量化结果。

## 四、六步序列的落地注意

- 六步是"序列"，NEVER 跳步或把每一步做长自我介绍；暖场→重新定义要用最短时间建立"我需要重新评估"的认知落差。（置信度：高；依据：框架 iframe；来源：sales-discovery-coach / sales-deal-strategist 对应段）
- 情感共鸣不强求对每个决策人都有效，但对"负责指标的 VP"这一角色常是关键（联动 Champion 动机识别）。（置信度：高；依据：框架 iframe；来源：sales-discovery-coach / sales-deal-strategist 对应段）
- 新路径（步 5）与你的方案（步 6）分离，避免过早暴露产品导致的"销售推介感"。

## grep 检索模式
- `grep -l "Discovery\|现状诊断\|差距量化\|通话结构\|问题设计" <dir>/*.md` → 定位发现诊断。
- `grep -l "Challenger\|Commercial Teaching\|颠覆性洞察\|暖场\|重新定义\|理性冲击" <dir>/*.md` → 定位六步教学序列。
- `grep -l "Command of the Message\|解决什么问题\|如何不同\|可衡量成果" <dir>/*.md` → 定位价值表达三支柱。