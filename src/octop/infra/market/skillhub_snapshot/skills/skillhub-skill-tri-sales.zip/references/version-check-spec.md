# 版本检查与更新规范

> 本文件是 tri-* 家族版本检查的**唯一事实源**（本副本为自包含同源拷贝）。
> 所有 tri-* 家族 skill 的版本检查与更新操作均须遵循本规范。

---

## 一、执行方式

```bash
python scripts/check_update.py --slug <slug> [--cache-dir <路径>] [--dry-run] [--force] [--json]
```

- `<slug>`：skill 标识，如 `tri-prompt-optimizer`（缺省自动读 SKILL.md frontmatter / 上级目录名）
- `--cache-dir`：缓存/备份目录覆盖（默认 `~/.cache/<slug>`），仅测试隔离用
- `--dry-run`：只判定不真正执行升级
- `--force`：强制重查，忽略 24h 节流缓存
- `--json`：输出 JSON 供 Agent 解析（版本门推荐形态；`state` 字段为 A/B/C/D/BLOCK）

> 完整参数与测试注入见 `check_update.py --help`（脚本为执行真值，本节摘要与之对齐）。

**退出码语义**（与 `check_update.py` 的 `EXIT_CODE` 严格对齐；BLOCK 统一为 20，细分原因见 `block_code`）：

| 退出码 | 状态 | 含义 |
|--------|------|------|
| 0 | A · 通过 | 版本检查通过（最新或缓存有效），放行 |
| 10 | B · 无网络 | 离线降级：无网络，取缓存态放行（缓存过期则降级放行） |
| 11 | C · 通道降级 | 远端通道不可达但有缓存，返回缓存态放行 |
| 12 | D · 版本陈旧 | 版本陈旧且缓存过期，尝试升级；升级失败则降级放行 |
| 20 | BLOCK · 阻断 | 阻断。`block_code` 细分：`ENV`（SKILL.md/slug 缺失）、`P2`（签名不一致）、`P3`（回滚失败）、`P4`（升级后校验失败） |

> 退出码 `<20` 一律放行（含 A/B/C/D 四态）；`>=20`（BLOCK）绝对禁止执行并按 `block_code` 输出恢复指引。脚本自身异常兜底降级放行（NEVER 因版本门故障阻断启动）。

---

## 二、执行要点

1. **先读本地**：从 SKILL.md frontmatter 读取当前版本
2. **节流缓存**：24h 内已查过且缓存有效 → 直接返回缓存态
3. **网络查询**：请求远端最新版本号
4. **版本比较**：逐段整数比较（避免 `1.10.0 < 1.9.0` 的字典序陷阱）
5. **四态判定**（与脚本 `STATE_*` 对齐）：
   - **A 态（通过）**：版本最新或缓存有效 → 直接放行（退出码 0）
   - **B 态（无网络）**：无网络 → 取缓存态放行（缓存过期则降级放行，退出码 10）
   - **C 态（通道降级）**：远端通道不可达但有缓存 → 返回缓存态放行（退出码 11）
   - **D 态（版本陈旧）**：版本陈旧且缓存已过期 → 尝试升级（退出码 12）；升级失败则降级放行
6. **升级流程**（仅 D 态触发）：
   - 备份当前 SKILL.md → 下载新版本 → 校验签名 → 验证 frontmatter 版本号
   - 签名不一致(P2) 或 回滚失败(P3) → 阻断（退出码 20，`block_code` 细分）
   - 其余降级场景 → 放行（退出码 12）
7. **兜底容错**：脚本自身异常 → 降级放行（退出码 11=C 态），NEVER 因版本门自身故障阻断 skill 启动

---

## 三、测试注入

通过 `--simulate-*` 参数注入模拟场景，验证四态判定逻辑：

| 注入参数 | 模拟场景 | 预期退出码 | 预期状态 |
|----------|----------|-----------|----------|
| `--simulate-net` | 无网络 | 10 | B 态 |
| `--simulate-latest` | 版本陈旧（缓存中） | 11 | C 态 |
| `--simulate-upgrade` | 版本陈旧（最新），触发升级 | 12 | D 态 |
| `--simulate-fetch-ok` | 中断模拟 | 0 | A 态 |

---

## 四、版本比较算法

```python
def compare_versions(v1: str, v2: str) -> int:
    """比较两个 SemVer 版本号。返回 -1/0/1 表示 v1<v2/v1==v2/v1>v2"""
    parts1 = [int(x) for x in v1.split('.')]
    parts2 = [int(x) for x in v2.split('.')]
    # 补齐长度
    while len(parts1) < len(parts2):
        parts1.append(0)
    while len(parts2) < len(parts1):
        parts2.append(0)
    for a, b in zip(parts1, parts2):
        if a < b:
            return -1
        if a > b:
            return 1
    return 0
```

---

## 五、节流缓存机制

- 缓存文件：`<cache-dir>/.version_cache.json`
- 缓存内容：`{"timestamp": <unix>, "state": "<A/B/C/D>", "remote_version": "<ver>"}`
- 节流窗口：24 小时（86400 秒）
- `--force` 参数可强制绕过缓存

---

## 六、生成物版本检查章节规范

所有 tri-* 家族 skill 的 SKILL.md 中，版本检查章节必须为**瘦指针 STUB**：

- **行数上限**：≤30 行
- **必须内容**：执行方式 + 指向本文件（`references/version-check-spec.md`）的指针
- **禁止内容**：内联四态判定细则、内联升级流程、内联版本比较算法
- **原因**：避免散文描述算法让模型复现导致漂移；所有版本检查逻辑集中在本规范文件中
