# 增长与商机获取（Outbound 信号触达 + ICP + Land-and-Expand + Offer/Lead Gen）
<!-- axis: gtm -->

> 锚定对照基准：对照基准档 §4.1.2（M1 Outbound 基于信号触达：信号触达 / 多渠道序列 / ICP / 干系人图谱）。
> 基准角色文件未展开的细节以原仓库对应角色文件为准（置信度：中；依据：推断 inferred）。

## 一、Outbound 信号触达（不靠量取胜，靠精准）

- **ICP 定义**：先定义 Ideal Customer Profile（理想客户画像），所有触达围绕 ICP，NEVER 无差别群发。（置信度：高；依据：框架 iframe；来源：sales-outbound-strategist / sales-account-strategist / sales-offer-lead-gen-strategist 对应段）
- **基于信号的触达**：以客户侧真实事件/意图信号（融资、高管更迭、产品发布、规模扩张、岗位招聘）为触发点发起触达，而非随机扫量。
- **多渠道序列**：设计多渠道触达序列（邮件/社交/电话/事件），每步给换一个理由、一次价值，NEVER 只换渠道不换内容。（置信度：高；依据：框架 iframe；来源：sales-outbound-strategist / sales-account-strategist / sales-offer-lead-gen-strategist 对应段）
- **调研驱动的个性化**：每条外呼前做客户调研，用调研证据撑起个性化开场，NEVER 用模板化"亲爱的客户"。（置信度：高；依据：框架 iframe；来源：sales-outbound-strategist / sales-account-strategist / sales-offer-lead-gen-strategist 对应段）

## 二、Offer 与 Lead Gen（漏斗顶端）

- **价值方程式 offer 构建**：设计无法抗拒的 offer 是把"预期价值 - 感知成本 - 决策摩擦"调到正值；offer 要有明确价值主张与零门槛获取路径。（置信度：高；依据：框架 iframe；来源：sales-outbound-strategist / sales-account-strategist / sales-offer-lead-gen-strategist 对应段）
- **Lead Magnet 类型学**：按目标买家所处认知阶段选 magnet（清单/报告/webinar/评测工具）——用内容换取联络信息，内容须与 ICP 问题直接相关。
- **多渠道 lead generation**：规模化吸引高质量买家的通道组合（自有内容/付费/转介绍）。
- **复利式触达**：通过客户、员工、代理机构、联盟（affiliate）四类放大器实现复利式触达边际，而非只靠一次性投放。
- **净化漏斗**：lead magnet 引来的流量 MUST 回灌到 ICP 过滤与 qualify（联动 meddpicc），杜绝高量低质。（置信度：高；依据：框架 iframe；来源：sales-outbound-strategist / sales-account-strategist / sales-offer-lead-gen-strategist 对应段）

## 三、Land-and-Expand（成交客户扩展为长期平台）

- **Land-and-Expand 执行**：先攻入一个明确价值切入点（Land），再系统化为更大平台/多团队扩展（Expand），NEVER 把首单当作终点。（置信度：高；依据：框架 iframe；来源：sales-outbound-strategist / sales-account-strategist / sales-offer-lead-gen-strategist 对应段）
- **干系人关系图谱**：画出成交客户内外部干系人、权力与影响力关系；扩展开单前先确认多线程关系（联动 meddpicc 危险信号「只有一条线程，对接的人还不是经济决策人」）。（置信度：高；依据：框架 iframe；来源：sales-outbound-strategist / sales-account-strategist / sales-offer-lead-gen-strategist 对应段）
- **QBR 策划**：以季度业务复盘（QBR）为制度化抓手，汇报价值、暴露风险、推动下一扩展单。
- **净收入留存率（NRR）管理**：把扩展与留存视为收入运营的核心杠杆——NRR>100% 说明在平台化路上；降低流失与扩展加权并重。

## 四、契约要点

- **结论性原则**：获客的质检是"精准 ICP + 真实信号 + 调研证据"，NEVER 以量论成败。（置信度：高；依据：框架 iframe；来源：sales-outbound-strategist / sales-account-strategist / sales-offer-lead-gen-strategist 对应段）
- **可维护性原则**：Offer / Lead Magnet 与 Outbound 共用 ICP 与信号口径，漏斗顶到底（MQL→Qualified）回灌 meddpicc 资质，避免断层。（置信度：高；依据：框架 iframe；来源：sales-outbound-strategist / sales-account-strategist / sales-offer-lead-gen-strategist 对应段）
- **协作边界**：内容生产（magnet 的落地内容）走 tri-content/tri-article；营销投放细节不在本方法轴内。

## grep 检索模式
- `grep -l "Outbound\|信号触达\|ICP\|多渠道序列\|个性化" <dir>/*.md` → 定位外呼触达。
- `grep -l "Offer\|价值方程式\|Lead Magnet\|复利\|agent\|联盟" <dir>/*.md` → 定位漏斗顶 offer/lead。
- `grep -l "Land-and-Expand\|干系人\|QBR\|净收入留存\|NRR" <dir>/*.md` → 定位成交后扩展。