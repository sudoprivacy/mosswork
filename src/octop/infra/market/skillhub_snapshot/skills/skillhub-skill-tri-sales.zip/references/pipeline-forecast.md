# 管道与预测经营（Pipeline 健康诊断 + 单子速度 + Forecast 准确度 + 数据驱动辅导）
<!-- axis: pipeline -->

> 锚定对照基准：对照基准档 §4.1.2（M1 管道分析与 Forecast 准确度）。
> 基准角色文件未展开的细节以原仓库 `sales-pipeline-analyst.md`、`sales-coach.md` 为准（置信度：中；依据：推断 inferred）。

## 一、Pipeline 健康诊断

目标：把 CRM 数据转化为可行动的 Pipeline 情报，在风险变成丢掉的季度之前暴露它（来源 sales-pipeline-analyst 描述段）。

- **水分与真实区分**：用加权/资质记分（联动 meddpicc）把真实 Pipeline 和水分分开；识别停滞单子（last-touch 久远 / qualified 却无近期推进）。
- **健康维度**：覆盖率（够不够下一季度）、加权后价值、阶段分布、单龄分布、危险单（缺失资质的"乐观单"）。
- **暴露驱动动作**：诊断 MUST 产出可行动项（催办/重新资质/降级/放弃），NEVER 只为出图。（置信度：高；依据：框架 iframe；来源：sales-pipeline-analyst / sales-coach 对应段）

## 二、单子速度分析（Velocity）

- 追踪单子在各阶段停留时间与整体周期；识别"卡点阶段"（停留超常的环节）。
- 速度数据用于校准时间线真实性（联动 meddpicc Decision Process / Paper Process 的时间约束真实性）。

## 三、Forecast 准确度

- **只求真实**：不乐观、不保守、只求真实（来源 sales-deal-strategist / sales-pipeline-analyst）。Forecast 有据可查——每笔在 Forecast 里的单子 MUST 能被"动作+证据"支撑（最近触达/EB 确认/Champion 反馈/走单已启动）。（置信度：高；依据：框架 iframe；来源：sales-pipeline-analyst / sales-coach 对应段）
- 单子级检查：把"在逃风险"（乐观、缺资质、缺 Compelling Event）标出来，调整置信区间。
- Forecast 复盘：比对预测与结果，识别系统性乐观/保守偏差，回写销售辅导（见下）。

## 四、数据驱动的销售辅导（Coaching）

- **Pipeline Review**：以单子级检查（联动 meddpicc Deal Review 问题）为素材做辅导，而非泛泛"多打电话"。
- **通话辅导**：基于真实通话/录音的行为反馈——聚焦可复现的改进（问题设计、价值表达、下一步约定），NEVER 只给评价不给动作。（置信度：高；依据：框架 iframe；来源：sales-pipeline-analyst / sales-coach 对应段）
- **Forecast 准确度管理**：教练通过预测复盘抓系统性偏差（乐观偏向 / 过度承诺），把偏差修正固化为团队习惯。

## 五、契约要点

- **结论性原则**：管道/预测的产出是"行动信号"——暴露风险、催办、降级，NEVER 只是呈现数字。（置信度：高；依据：框架 iframe；来源：sales-pipeline-analyst / sales-coach 对应段）
- **可维护性原则**：Forecast 判据（证据支撑）与 meddpicc 资质记分共用一套"单子真实性"口径，避免两套标准打架。（置信度：高；依据：框架 iframe；来源：sales-pipeline-analyst / sales-coach 对应段）
- **协作边界**：单子策略（资质/竞争）走 meddpicc 与 discovery-message；本方法轴负责管道/预测/辅导的运营维度。

## grep 检索模式
- `grep -l "Pipeline\|管道\|健康诊断\|覆盖\|单龄" <dir>/*.md` → 定位管道健康。
- `grep -l "速度\|Velocity\|卡点阶段" <dir>/*.md` → 定位单子速度。
- `grep -l "Forecast\|预测\|只求真实\|超标偏差\|复盘" <dir>/*.md` → 定位预测准确度。
- `grep -l "辅导\|Coaching\|通话辅导\|Pipeline Review" <dir>/*.md` → 定位数据驱动辅导。