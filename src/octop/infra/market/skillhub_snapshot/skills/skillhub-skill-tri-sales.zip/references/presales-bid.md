# 售前与技术赢标（技术 Discovery / Demo / POC + 竞争技术定位 + 投标叙事）
<!-- axis: presales -->

> 锚定对照基准：对照基准档 §4.1.2（M1 售前 Demo/POC、赢单叙事与投标策略）。
> 基准角色文件未展开的细节以原仓库 `sales-engineer.md`、`sales-proposal-strategist.md` 为准（置信度：中；依据：推断 inferred）。

## 一、售前技术定位（在进入采购流程前赢下技术决策）

目标：把产品能力转化为业务成果，在单子进入采购流程之前先赢下技术决策（来源 sales-engineer 描述段）。

- **技术 Discovery**：弄清技术现状、集成约束、成败技术标准、评估方技术角色；与技术决策人确认"证明什么才算赢"。
- **Demo 设计**：围绕客户业务场景而非产品功能罗列——演示"解决他们的问题"，NEVER 演示"我们的功能列表"；为关键评估标准设计可被记住的差异点。（置信度：高；依据：框架 iframe；来源：sales-engineer / sales-proposal-strategist 对应段）
- **POC 执行**：把 POC 目标、范围、验收标准、时间线与客户技术方对齐并文档化；POC 天然消耗进度——NEVER 让 POC 周期超出决策周期未受约束（联动 meddpicc Decision Process / Paper Process）。（置信度：高；依据：框架 iframe；来源：sales-engineer / sales-proposal-strategist 对应段）
- **竞争技术定位**：在技术层面对齐 meddpicc 的竞争三区（赢区放大、胶着区引向相邻因素、输区重新定位标准重要性）。

## 二、投标策略（把 RFP/机会变成赢标叙事）

目标：把 RFP 与销售机会转化为有说服力的赢标叙事——构建能打动评审的方案，而非仅仅合规的方案（来源 sales-proposal-strategist 描述段）。

- **赢标主题提炼**：提炼贯穿全文的"为什么我们赢"的单一主题——一个可被评审记住的叙事主线，不是功能清单。（置信度：高；依据：框架 iframe；来源：sales-engineer / sales-proposal-strategist 对应段）
- **竞争定位**：在方案中显式对齐竞争态势——针对赢区放大、输区用"规模化后 Y 比 X 更重要"式重新定位（联动 tri-sales meddpicc 竞争三区）。
- **执行摘要**：把执行摘要写成"结论先行"的赢标主张——评审先读摘要，摘要必须先给出"为什么选我们"的答案与核心差异化证据；NEVER 把摘要写成目录式概述。（置信度：高；依据：框架 iframe；来源：sales-engineer / sales-proposal-strategist 对应段）
- **合规性 vs 打动性并重**：先满足 RFP 硬性合规条目（被判不合规直接出局），再在合规之上叠加叙事与差异化；合规是门票，叙事是加分。（置信度：高；依据：框架 iframe；来源：sales-engineer / sales-proposal-strategist 对应段）

## 三、三步走流程

1. **技术赢面**：技术 Discovery → Demo/POC 围绕业务成果设计 → 记录技术决策标准。
2. **竞争对齐**：画出赢区/胶着区/输区 → 技术定位放大赢区、软化输区。
3. **叙事沉淀**：提炼赢标主题 → 写结论先行的执行摘要 → 全案对齐主题与证据。

## 四、契约要点

- **结论性原则**：售前输出的每一页（Demo/POC/投标）都要回答"为什么是我们"——证据化差异化而非功能罗列。（置信度：高；依据：框架 iframe；来源：sales-engineer / sales-proposal-strategist 对应段）
- **可维护性原则**：竞争定位与投标叙事复用 meddpicc 的竞争三区与决策标准，避免各写一套。（置信度：高；依据：框架 iframe；来源：sales-engineer / sales-proposal-strategist 对应段）
- **协作边界**：售前技术侧可与 tri-coding/tri-frontend-design 联动（Demo/POC 技术搭建）；商务侧（价格/条款）不在本方法轴内。

## grep 检索模式
- `grep -l "售前\|技术 Discovery\|Demo\|POC\|竞争技术定位" <dir>/*.md` → 定位售前技术赢标。
- `grep -l "投标\|赢标主题\|执行摘要\|叙事\|让评审记住" <dir>/*.md` → 定位投标叙事。