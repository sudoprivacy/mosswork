---
name: tri-sales-full-testcases
description: tri-sales v1.0.0 全场景测试用例——能力清单分组全覆盖。
基于 tri-sales v1.0.0
---

# tri-sales 全场景测试用例（v1.0.0）

- 用例总数：28 · 生成时间：2026-09-20 · 审计方式：对照 SKILL.md 全文逐能力点提取 + 27 条硬约束核对。
- 验证约定：T0/T1/T2/T3/T4/T5 等静态用例可离线机械执行；T6 行为用例需真机会话（设计边界，非缺陷）。

## 零、版本门（T0）

| 用例 | 操作 | 期望 |
|---|---|---|
| T0-1 | `python scripts/check_update.py --slug tri-sales --json` | 退出码 <20；输出合法 JSON 且 `state` ∈ {A,B,C,D} |
| T0-2 | grep SKILL.md「版本检查前置硬门（第零步）」 | 命中（约束 22 第零步契约条目） |
| T0-3 | `## 版本检查与更新机制` 章节行数 ≤30 且含 `version-check-spec.md` 指针、无内联四态细则、无 version-gate 引用 | 命中（约束 22 瘦指针） |

## 一、结构与合规（T1）

| 用例 | 操作 | 期望 |
|---|---|---|
| T1-1 | frontmatter 八字段（name/slug/version/displayName/description/summary/tags/license） | 齐全；name==slug==tri-sales；license: MIT |
| T1-2 | grep description「支持独立安装，含上游依赖检测两态逻辑」 | 命中（约束 2，两态：方法论横向型匹配） |
| T1-3 | `## 强制执行契约（Execution Contract · 最高优先级）` 为首个 `##` 正文章节且含激活语义 | 命中（约束 3） |
| T1-4 | `wc -l SKILL.md` | ≤500 行（约束 13） |
| T1-5 | 目录扫描 | 无 LICENSE、无 .gitignore（约束 11） |
| T1-6 | `## 质量标准` 为独立 `##` 二级标题 | 命中（约束 16） |
| T1-7 | grep 硬编码家族计数 `\d+ 个 (下游|tri-\*|路由型|横向型)` | 无命中（约束 17） |

## 二、版本强一致（T2）

| 用例 | 操作 | 期望 |
|---|---|---|
| T2-1 | grep 五处版本：SKILL.md frontmatter / CHANGELOG 置顶 / _meta.json / tests frontmatter「基于」 / README | 全部 == 1.0.0（约束 10/12/14） |
| T2-2 | `## 目录结构` 树与磁盘 `ls -R` diff | 完全一致（约束 15） |

## 三、一致性（T3 · 本 skill 核心域）

| 用例 | 操作 | 期望 |
|---|---|---|
| T3-1 | 任取 SKILL.md/references 一条方法论规则 | 附对照基准档章节锚点（如 §4.1.2）或「基准未展开」降级标注（一致性红线） |
| T3-2 | grep references 五篇「置信度」 | 每篇至少一处置信标注 |
| T3-3 | grep SKILL.md/README「外部引用」「不内嵌」「内容资产」 | 命中（内容外部引用红线，不搬运销售角色正文） |
| T3-4 | grep「资质重于人脉」「只求真实的 Forecast」「先改变认知再谈产品」 | 三大核心设计决策在 SKILL.md 均可检索 |
| T3-5 | 按对照基准档 §4.1.2（MEDDPICC/Outbound/Discovery/售前/管道）核对 references 五篇主题 | 一一对应无遗漏（meddpicc/discovery/presales/pipeline/gtm） |

## 四、知识装配与检索（T4）

| 用例 | 操作 | 期望 |
|---|---|---|
| T4-1 | SKILL.md 含「知识装配顺序」分层表（常驻/方法论/用户指定/外部覆盖） | 命中（约束 25） |
| T4-2 | 按装配顺序表 grep 关键词（MEDDPICC/Champion→meddpicc、Discovery/Challenger→discovery、Demo/POC/RFP→presales、Pipeline/Forecast→pipeline、Outbound/ICP→gtm） | 每关键词命中对应 references 篇 |
| T4-3 | 每篇 references 含「grep 检索模式」小节 | 命中（约束 19） |

## 五、进化契约与教训闭环（T5）

| 用例 | 操作 | 期望 |
|---|---|---|
| T5-1 | grep「进化契约」 | 命中，且含反馈接收点 + 经验沉淀位 + 自我修订触发条件三要素（约束 23） |
| T5-2 | grep`\.tribro/sales/lessons\.md` | 命中且含启动读取 + 缺失静默跳过 + 结束追加写入三动作 |
| T5-3 | 无 lessons.md 时激活 | 静默跳过，不报错不阻断不追问 |

## 六、完成判据外化（T6）

| 用例 | 操作 | 期望 |
|---|---|---|
| T6-1 | grep「完成判据（外化」 | 命中（约束 24），且判据可机械校验、区分停车态/结束态 |

## 七、行为用例（T7 · 需真机会话）

| 用例 | 场景 | 期望 |
|---|---|---|
| T7-1 | 用户显式调用「怎么评估/管理一笔销售机会」 | 输出 MEDDPICC 八要素 + 记分 + Pipeline Review 探查 + 危险信号 + 基准锚 + 置信三要素 |
| T7-2 | 用户问「怎么做有效的 Discovery / 信息传递」 | 输出 Discovery 诊断 + Challenger 6 步 + 价值表达三支柱 |
| T7-3 | 用户问「售前 Demo/POC 与投标怎么写」 | 输出技术赢标三步走 + 赢标叙事 + 结论先行执行摘要 |
| T7-4 | 用户问「怎么管 Pipeline 与 Forecast」 | 输出管道健康 + 单子速度 + 只求真实 Forecast + 数据驱动辅导 |
| T7-5 | 用户问「怎么获客触达」 | 输出 Outbound 信号触达 + ICP + Offer/Lead Magnet + Land-and-Expand + NRR |
| T7-6 | 用户要求写产品 PRD / 路线图 | 输出 MUST 指向 tri-pm，NEVER 在本工作流内代办（Not-Trigger，成果物边界） |
| T7-7 | 用户要求内嵌某销售角色正文 | 输出 MUST 指向外部引用源并拒绝逐字内嵌（内容红线） |
| T7-8 | 用户要求造一个新 skill（整理） | 输出 MUST 指向 tri-god，NEVER 在本工作流内代办（Not-Trigger） |
## 八、可执行口径回归（T8 · 机械校验）

| 用例 | 操作 | 期望 |
|---|---|---|
| T8-1 | `python scripts/meddpicc_score.py --selfcheck` | 7/7 PASS、exit 0；其中 D2（八项全有但五条危险信号全中）判定=出局，NEVER 判推进 |
| T8-2 | `python scripts/meddpicc_score.py --selfcheck` D6 用例 | 八项全有但 1 条危险信号 → 补发现议程（exit 1） |
| T8-3 | `python scripts/conf_lint.py` | A 类结论句三要素覆盖率 100%、exit 0 |
| T8-4 | `grep -l "<!-- axis: meddpicc -->" references/*.md` | 唯一命中 meddpicc-qualification.md（五轴各一，NEVER 多篇命中） |
| T8-5 | grep「记分口径」于 references/meddpicc-qualification.md | 命中，且含权重表 + 证据分档 + 阈值 + 一票否决四项，并指向 scripts/meddpicc_score.py |
| T8-6 | grep「补齐三问」于 references/meddpicc-qualification.md | 命中，且七问+三问对八要素覆盖 8/8 |
