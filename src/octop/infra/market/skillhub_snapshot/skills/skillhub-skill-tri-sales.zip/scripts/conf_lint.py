#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""结论三要素校验（确定性 · 零第三方依赖）

契约第 4 条要求：本 skill 产出的每一个结论性表达 MUST 附三要素
（置信度 / 依据类型 / 可验证来源）。质量标准写「结论性表达 100% 附三要素」。

本脚本把这条要求变成可机械校验的门禁，并做一件原文没做的事：
区分「方法论断言（A 类，MUST 附三要素）」与「结构/流程描述（B 类，免附）」，
避免把「本节讲什么」这类结构性句子也算成漏标而淹没真问题。

用法：
  python scripts/conf_lint.py                 # 扫 references/（默认）
  python scripts/conf_lint.py --path SKILL.md
  python scripts/conf_lint.py --json

退出码：0 = 全通过；1 = 存在 A 类漏标；3 = 路径错误
"""
import argparse
import glob
import json
import os
import re
import sys

# 三要素
RE_CONF = re.compile(r"置信度")
RE_BASIS = re.compile(r"依据")
RE_SRC = re.compile(r"来源|file:line|http")

# B 类：结构性/流程性描述，不要求三要素
B_PATTERNS = [
    re.compile(r"^\|"),                     # 表格行
    re.compile(r"^#{1,6}\s"),               # 标题
    re.compile(r"^>\s"),                    # 引用块
    re.compile(r"^<!--"),                   # 锚点注释
    re.compile(r"^-\s+`grep"),              # grep 段
    re.compile(r"^`grep"),
    re.compile(r"^\d+\.\s+\*\*"),           # 编号条目（结构）
]
# A 类判据：含规范性动词或断言词的陈述句
A_MARKERS = ["MUST", "NEVER", "应", "不应", "必须", "前提", "结论", "原则",
             "决定", "意味着", "根因", "因此", "故", "而是", "不是", "是"]
# 明确的结论性动词（含这些即 A 类）
A_STRONG = ["MUST", "NEVER", "意味着", "根因", "结论", "前提", "决定"]


def classify(line):
    """返回 'B'（免附）/ 'A'（需附）/ None（跳过）"""
    s = line.strip()
    if not s:
        return None
    for p in B_PATTERNS:
        if p.match(s):
            return "B"
    plain = re.sub(r"`[^`]*`", "", s)
    if "。" not in plain and not plain.endswith("。"):
        return None
    if any(k in plain for k in A_STRONG):
        return "A"
    if any(k in plain for k in A_MARKERS):
        return "A"
    return "B"     # 纯描述句归 B


def has3(line):
    n = sum(1 for r in (RE_CONF, RE_BASIS, RE_SRC) if r.search(line))
    return n >= 2


def scan(paths):
    total_a = miss = 0
    details = []
    for p in paths:
        try:
            text = open(p, encoding="utf-8").read()
        except OSError as e:
            print("读取失败: %s (%s)" % (p, e), file=sys.stderr)
            continue
        in_code = False
        a_n = m_n = 0
        for i, ln in enumerate(text.splitlines(), 1):
            if ln.strip().startswith("```"):
                in_code = not in_code
                continue
            if in_code:
                continue
            c = classify(ln)
            if c != "A":
                continue
            a_n += 1
            if not has3(ln):
                m_n += 1
                details.append({"file": os.path.basename(p), "line": i,
                                "text": ln.strip()[:70]})
        total_a += a_n
        miss += m_n
        print("  %-32s A类=%3d  漏标=%3d" % (os.path.basename(p), a_n, m_n))
    return total_a, miss, details


def main():
    ap = argparse.ArgumentParser(description="结论三要素校验")
    ap.add_argument("--path", nargs="*", help="目标文件（默认 references/*.md）")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--show", type=int, default=8, help="展示漏标条数")
    a = ap.parse_args()

    if a.path:
        paths = a.path
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        paths = sorted(glob.glob(os.path.join(base, "references", "*.md")))
    if not paths:
        print("未找到目标文件", file=sys.stderr)
        return 3

    total, miss, details = scan(paths)
    rate = (100.0 * (total - miss) / total) if total else 100.0
    print("\nA 类结论句 %d 条，已附三要素 %d 条，覆盖率 %.1f%%" % (
        total, total - miss, rate))
    if a.json:
        print(json.dumps({"total": total, "missing": miss, "rate": round(rate, 2),
                          "samples": details[:a.show]}, ensure_ascii=False, indent=2))
    elif miss:
        print("漏标样例（前 %d 条）：" % a.show)
        for d in details[:a.show]:
            print("   %s:%d  %s" % (d["file"], d["line"], d["text"]))
    return 0 if miss == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
