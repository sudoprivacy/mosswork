#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MEDDPICC 资质记分（确定性实现 · 零第三方依赖）

把 references/meddpicc-qualification.md 的「加权评分模型」落成可执行口径，
补齐原文缺失的三件东西：

  1. 权重表（原文只说「加权」，无权重定义）
  2. 证据分档（原文只说「逐要素打分」，未定义 0/1 之间如何取值）
  3. 危险信号与记分的联动（原文把危险信号放第三节，与第二节记分无引用关系）

设计约束（沿用本包既有约束）：
  - 零第三方依赖，纯标准库
  - 确定性优先：同输入恒同输出，无随机、无网络
  - 非破坏性：只新增记分口径，不改八要素与危险信号的既有定义

用法：
  python scripts/meddpicc_score.py --selfcheck
  python scripts/meddpicc_score.py --deal deal.json [--json]
  echo '{"M":{"evidence":1}}' | python scripts/meddpicc_score.py --stdin

退出码：0 = 推进；1 = 补发现议程；2 = 出局；3 = 输入错误
"""
import argparse
import json
import sys

# ---------------------------------------------------------------- 八要素权重
# 依据：赢单取决于「价值是否成立 + 谁点头 + 谁在推」，流程类要素决定时间线风险，
# 因此权重低于价值/权力类，但缺失同样致命（由危险信号与阈值共同兜底）。
WEIGHTS = {
    "M": 1.5,              # Metrics 可量化指标
    "E": 2.0,              # Economic Buyer 经济决策人
    "D_criteria": 1.0,     # Decision Criteria 决策标准
    "D_process": 1.0,      # Decision Process 决策流程
    "P": 1.0,              # Paper Process 走单流程
    "I": 1.5,              # Identify Pain 识别痛点
    "C_champion": 1.5,     # Champion 内部支持者
    "C_competition": 1.0,  # Competition 竞争态势
}
LABEL = {
    "M": "可量化指标", "E": "经济决策人", "D_criteria": "决策标准",
    "D_process": "决策流程", "P": "走单流程", "I": "识别痛点",
    "C_champion": "内部支持者", "C_competition": "竞争态势",
}
MAX_SCORE = sum(WEIGHTS.values())  # 10.0

# 证据分档：原文未定义 0/1 之间如何取值，这里补三档
EVIDENCE_LEVELS = {
    0: "无答案 / 未验证",
    1: "单方口头（未经第二来源确认）",
    2: "文档化或双源确认",
}
EVIDENCE_FACTOR = {0: 0.0, 1: 0.5, 2: 1.0}

# 杀死单子的危险信号（五条，沿用 references 第三节原文）
KILLERS = [
    "只有一条线程，对接的人还不是经济决策人",
    "没有 Compelling Event 或受迫性事件缺失",
    "Champion 失联 / 无法安排决策人会面",
    "决策标准非文档化、你在猜标准",
    "走单流程/POC 周期未被计入时间线",
]

# 阈值
PUSH_MIN = 0.60       # 加权得分率 ≥0.60 且零危险信号 → 推进
DISCOVER_MIN = 0.30   # ≥0.30 或 1-2 条危险信号 → 补发现议程
KILLER_VETO = 3       # 危险信号 ≥3 条 → 一票否决，直接出局


def score_deal(deal):
    """对一笔单子记分。deal = {"name":..., "answers":{"M":0|1|2,...}, "killers":[0,2]}"""
    ans = deal.get("answers", {}) or {}
    killers = deal.get("killers", []) or []

    for k in ans:
        if k not in WEIGHTS:
            raise ValueError("未知要素: %s" % k)
        if ans[k] not in EVIDENCE_FACTOR:
            raise ValueError("证据档位必须是 0/1/2，收到 %r（要素 %s）" % (ans[k], k))
    for k in killers:
        if not isinstance(k, int) or not (0 <= k < len(KILLERS)):
            raise ValueError("危险信号下标越界: %r" % (k,))

    detail = {}
    raw = 0.0
    for k, w in WEIGHTS.items():
        lv = int(ans.get(k, 0))
        f = EVIDENCE_FACTOR[lv]
        raw += w * f
        detail[k] = {"label": LABEL[k], "weight": w, "evidence": lv,
                     "evidence_desc": EVIDENCE_LEVELS[lv], "score": round(w * f, 3)}
    rate = raw / MAX_SCORE

    if len(killers) >= KILLER_VETO:
        verdict, code = "出局", 2
        reason = "危险信号 %d 条 ≥ %d，触发一票否决" % (len(killers), KILLER_VETO)
    elif killers:
        verdict, code = "补发现议程", 1
        reason = "存在 %d 条危险信号，先止血再谈推进" % len(killers)
    elif rate >= PUSH_MIN:
        verdict, code = "推进", 0
        reason = "加权得分率 %.2f ≥ %.2f 且零危险信号" % (rate, PUSH_MIN)
    elif rate >= DISCOVER_MIN:
        verdict, code = "补发现议程", 1
        reason = "加权得分率 %.2f 落在 [%.2f, %.2f)" % (rate, DISCOVER_MIN, PUSH_MIN)
    else:
        verdict, code = "出局", 2
        reason = "加权得分率 %.2f < %.2f" % (rate, DISCOVER_MIN)

    gaps = [LABEL[k] for k, v in detail.items() if v["evidence"] == 0]
    weak = [LABEL[k] for k, v in detail.items() if v["evidence"] == 1]
    return {
        "name": deal.get("name", ""),
        "weighted_score": round(raw, 3),
        "max_score": MAX_SCORE,
        "rate": round(rate, 4),
        "killer_count": len(killers),
        "killer_detail": [KILLERS[i] for i in killers],
        "verdict": verdict, "exit_code": code, "reason": reason,
        "gaps": gaps, "oral_only": weak, "detail": detail,
    }


# ------------------------------------------------------------ 自检回归用例
# 六例沿用 tri-sales 首轮实测的单子集（D1-D6），固化修复后的期望结论。
SELFCHECK = [
    {"name": "D1 八项全有·且都有证据", "expect": "推进",
     "answers": {k: 2 for k in WEIGHTS}, "killers": []},
    {"name": "D2 八项全有·但全是口头推测（只有一条线程）", "expect": "出局",
     "answers": {k: 1 for k in WEIGHTS}, "killers": [0, 1, 2, 3, 4]},
    {"name": "D3 六项扎实·缺 Metrics 与 Paper Process", "expect": "推进",
     "answers": {k: (0 if k in ("M", "P") else 2) for k in WEIGHTS}, "killers": []},
    {"name": "D4 只有三项·但每项都是硬证据", "expect": "补发现议程",
     "answers": {k: (2 if k in ("E", "I", "C_champion") else 0) for k in WEIGHTS},
     "killers": []},
    {"name": "D5 七项·唯一缺 Competition（视野盲区）", "expect": "推进",
     "answers": {k: (0 if k == "C_competition" else 2) for k in WEIGHTS}, "killers": []},
    {"name": "D6 八项全有·危险信号只中 1 条", "expect": "补发现议程",
     "answers": {k: 2 for k in WEIGHTS}, "killers": [3]},
    {"name": "D7 零答案·空单子", "expect": "出局",
     "answers": {}, "killers": []},
]


def run_selfcheck(verbose=True):
    passed, failed = 0, []
    for case in SELFCHECK:
        r = score_deal(case)
        ok = r["verdict"] == case["expect"]
        passed += ok
        if not ok:
            failed.append({"name": case["name"], "expect": case["expect"],
                           "got": r["verdict"], "rate": r["rate"]})
        if verbose:
            print("  [%s] %-38s %5.2f/%4.1f  危险%d  → %s   (期望 %s)" % (
                "PASS" if ok else "FAIL", case["name"], r["weighted_score"],
                r["max_score"], r["killer_count"], r["verdict"], case["expect"]))
    if verbose:
        print("\nselfcheck: %d/%d passed, failed=%s" % (passed, len(SELFCHECK), failed))
    return passed == len(SELFCHECK)


def main():
    ap = argparse.ArgumentParser(description="MEDDPICC 资质记分（确定性）")
    ap.add_argument("--selfcheck", action="store_true", help="跑内置回归")
    ap.add_argument("--deal", help="单子 JSON 文件")
    ap.add_argument("--stdin", action="store_true", help="从 stdin 读单子 JSON")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    a = ap.parse_args()

    if a.selfcheck:
        ok = run_selfcheck()
        return 0 if ok else 1

    if a.deal:
        deal = json.load(open(a.deal, encoding="utf-8"))
    elif a.stdin:
        deal = json.loads(sys.stdin.read())
    else:
        ap.error("需要 --selfcheck / --deal / --stdin 之一")
        return 3

    try:
        r = score_deal(deal)
    except ValueError as e:
        print("输入错误: %s" % e, file=sys.stderr)
        return 3

    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print("%s  → %s（%.2f/%.1f，危险信号 %d）" % (
            r["name"], r["verdict"], r["weighted_score"], r["max_score"],
            r["killer_count"]))
        print("  判据：%s" % r["reason"])
        if r["gaps"]:
            print("  缺口：%s" % "、".join(r["gaps"]))
        if r["oral_only"]:
            print("  仅口头：%s" % "、".join(r["oral_only"]))
    return r["exit_code"]


if __name__ == "__main__":
    sys.exit(main())
