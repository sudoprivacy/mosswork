# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [未发布]

> 版本说明：本包尚未发布到 skillhub（`check_update.py` 返回 `latest: null` / state=C）。按家族「版本号发布时点铁律」，未发布 skill 版本恒为 **1.0.0**，本地变更记入本节，发布时合并进对应版本号。

### 修复

- **F1 记分口径落地（原本只有「加权评分模型」措辞，无权重/阈值/证据分档）**：新增 `scripts/meddpicc_score.py`（零第三方依赖、确定性），补齐八要素权重表（E 2.0 / M·I·Champion 各 1.5 / 其余各 1.0，满分 10.5）、证据三档（无答案 0 / 单方口头 0.5 / 文档化或双源 1.0）、判定阈值（≥0.60 且零危险信号→推进；≥0.30 或 1–2 条危险信号→补发现议程；<0.30 或危险信号 ≥3 条→出局），并写入 `references/meddpicc-qualification.md` 新增「记分口径」小节作指针。
- **F2 危险信号未接进记分链路（八要素第二节与危险信号第三节无引用关系，导致八项全中的必死单子得满分判「推进」）**：危险信号改为一票否决（≥3 条直接出局、1–2 条降级补发现议程），由 `meddpicc_score.py` 强制执行。
- **F3 Deal Review 七问只覆盖八要素中 5 个（62.5%，缺 Metrics / Decision Criteria / Decision Process）**：七问逐条标注映射要素，并新增「补齐三问」覆盖三个零覆盖要素，合起来 8/8。
- **F4 关键词索引 16 词中 8 个不唯一命中（MEDDPICC 因跨篇联动指针污染五篇全中）**：五篇 references 首行后加机器可读轴锚 `<!-- axis: meddpicc|discovery|presales|pipeline|gtm -->`，SKILL.md 检索模式改为 `grep -l "<!-- axis: X -->"`，裸关键词降级为篇内小节定位。
- **F5 置信三要素覆盖率 1/80（1.25%，契约第 4 条要求 100%）**：新增 `scripts/conf_lint.py`（A 类方法论断言 MUST 附三要素 / B 类结构描述免附），并对五篇 references 的 32 条 A 类漏标句补齐三要素标注；复测覆盖率 **100%**、退出码 0。
- **F6 跨篇指针指向不存在的锚点**：`gtm-engagement.md` 的「联动 meddpicc Multi-thread」改为「联动 meddpicc 危险信号『只有一条线程』」（八要素表中无 Multi-thread 要素名）；`presales-bid.md` 的「meddpicc Deck Decision Process」去掉多余的 Deck。
- **F7 不可核验数值未降级**：`meddpicc-qualification.md` 的「赢单率高 18%、平均单价大 24%」置信度由高降为中，并显式标注「基准原文为外部引用、包内不可核验，引用时 MUST 标注该降级说明」。
- **F8 移除对已下架模块 tri-expert 的边界引用**：SKILL.md 路由表与 Not-Trigger 条款、README 责任边界、本条 MECE 边界中「专家 Persona 库属 tri-expert」均已改为「外部引用，对应模块已移除」，避免发布后指向不存在的模块（版本号依发布时点铁律保持 1.0.0，仅记日志）。

### 新增

- `scripts/meddpicc_score.py --selfcheck`：7 例回归（含 D2 八项全中但危险信号全中→出局、D6 八项全中但 1 条危险信号→补发现议程）。
- `scripts/conf_lint.py`：结论三要素门禁，A/B 分类，退出码 0/1/3。

## [未发布]

### 修复

- **去标识化清理（家族去痕迹铁律）**：全量移除 SKILL/README/CHANGELOG/references/tests 中的来源标识与过程性叙述（外部项目名与仓库地址、来源角色文件路径与文件名、以及生成流程相关词面），共 155 处替换。改为自洽表述：只描述本包五条方法轴，锚点统一收敛为「对照基准档 § 章节锚点」，references 头部锚定行重写为纯基准锚点。
- **版本检查规范改为本地副本**：版本检查细则的引用指针由外部包路径改为本包 `references/version-check-spec.md`（已落地副本），同步目录结构装配说明。

## [1.0.0] - 2026-09-20

### 新增

- 首版发布（横向型方法论领域入口 skill，不经 tri-intent 路由，不进下游注册，仅登记横向层口径）。
- **对照基准**：对照基准档 §4.1.2（立项规格）+ 对照基准档（阶段一全量分析报告）。
- **SKILL.md**：方法轴地图（机会资质审查 / 销售发现与信息传递 / 售前与技术赢标 / 管道与预测经营 / 增长与商机获取五轴）+ 三条核心设计决策（资质重于人脉 / 只求真实 Forecast / 先改变认知再谈产品）+ 三模式处理流程（方法检索/流程指导/对照校准）+ 内容外部引用红线（销售角色正文不内嵌）+ 知识装配顺序（约束 25）+ 完成判据外化（约束 24）+ 进化契约与教训读写闭环 `.tribro/sales/lessons.md`（约束 23）+ 版本检查第零步 STUB（约束 22）+ 结论置信标注内置（约束 27）。
- **references/ 五篇**：meddpicc-qualification（MEDDPICC 八要素 + 资质记分 + Pipeline Review 探查与危险信号）/ discovery-message（Discovery 诊断 + Challenger 6 步 Commercial Teaching + Command of the Message 价值三支柱）/ presales-bid（技术 Discovery/Demo/POC + 竞争技术定位 + 投标赢标叙事与执行摘要）/ pipeline-forecast（Pipeline 健康诊断 + 单子速度 + 只求真实 Forecast + 数据驱动辅导）/ gtm-engagement（Outbound 信号触达 + ICP + Offer/Lead Gen + Land-and-Expand + NRR）。
- **工程配套**：scripts/check_update.py（家族共用同一份逻辑，按 --slug 自适应）；README/CHANGELOG/tests/_meta 四件套版本强一致 1.0.0；无 LICENSE/.gitignore（约束 11）；SKILL/README/CHANGELOG=CRLF。
- **取舍**（对照审计 §4.1.2）：必整理「MEDDPICC 资质 + Outbound 信号触达 + Discovery 诊断 + 售前 Demo/POC + 赢单叙事 + 管道分析」；明确不整理「销售角色正文（外部内容资产，保持外部引用、不内嵌）」「外部工具链/商业生态」。MECE 边界：产品侧（交付产品成果物）转 tri-pm；安全生产业转 tri-security/tri-reverse；专家 persona 库（外部引用，对应模块已移除）。