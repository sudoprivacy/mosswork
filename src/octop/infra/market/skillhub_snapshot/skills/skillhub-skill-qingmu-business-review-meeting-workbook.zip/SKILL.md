---
name: skillhub-skill-qingmu-business-review-meeting-workbook
description: "基于客户已有报表或 Q28 报告，形成会前资料清单、议程、讨论问题、决议和行动责任表。"
---

# 月度经营分析会方案

本技能按次收费，单次价格 ¥0.99。本次主交付：基于客户已有报表或 Q28 报告，形成会前资料清单、议程、讨论问题、决议和行动责任表。

适用输入：经营分析结果、拟讨论问题、参会角色、会议时长和上次行动完成情况。

范围边界：允许客户自带分析材料，不强制购买 Q28；本次只覆盖一场经营分析会。


## 使用前说明

本文件安装在用户自己的智能体中，只负责说明使用流程、收集本次资料、调用青木企业管理咨询服务，并呈现服务返回的结果。私有方法和付费结果留在青木服务端，不包含在下载包内。安装不等于已支付，也不能凭本文件独立获得付费交付。

本次自愿提供的业务资料会发送到青木服务端，并转发至 DeepSeek 模型接口生成结果；订单信息用于支付核验、交付和退款处理。请使用匿名部门、岗位和虚构代号，不提交员工个人信息、历史客户原件、商业秘密或无权提供的资料。

先确认当前智能体运行环境可使用微信 AI 支付能力。插件可能自动接管 HTTP 402，不必然显示为 `weixinpay_` 工具；无法确认可用时，先停止，不要让用户填完资料后才发现不能付款。

## 收集资料与预检查

仅依据用户本次输入整理下面的 JSON。未知项用空字符串或空数组，不补造事实。`facts` 写可观察事实，`constraints` 写范围和限制。



```json
{
  "schema_version": "1.0",
  "query": "本次要完成的专项任务、适用范围和期望结果",
  "organization": {"industry": "行业或业务类型", "business_model": "业务如何运作", "size_band": "规模区间"},
  "facts": ["已核实的现状或数据口径", "一件具体业务事件或现有做法"],
  "constraints": ["本次不能改变的条件"],
  "time_horizon": "对应的周期"
}
```

以完全相同的 JSON `POST https://qingmuzx.com/skillhub/v1/skills/qingmu-business-review-meeting-workbook/precheck`，设置 `Content-Type: application/json`。只有 HTTP 200 且响应明确为 `ready: true` 才继续；`ready: false` 时按 `missing` 追问，绝不先收款。404、网络错误、不可解析或缺 `ready` 均表示服务暂不可用，不得自行推断通过。

## 支付与交付

将预检查使用的同一个 JSON `POST https://qingmuzx.com/skillhub/v1/skills/qingmu-business-review-meeting-workbook/invoke`。若为 HTTP 402，读取 `WeixinPay-Required` 和 `X-Out-Trade-No`，并核对显示金额为 ¥0.99。金额不符即停止。向用户解释本次交付，由用户授权微信支付。

支付后使用**同一个 JSON Body**、同一个 `X-Out-Trade-No` 和 `WeixinPay-Required` 原值重试 `invoke`；不得另建订单。只有服务端查单成功并返回 HTTP 200、包含本技能结果时才展示青木付费交付。`PAYMENT_PENDING` 用原订单稍后重试；`PAYMENT_NOT_READY`、退款中、已退款或其他错误均不得假装已交付。若微信支付能力、服务端或模型缺席，说明原因并停止。普通智能体可另行回答一般问题，但不得冒称本技能付费成果，也不得用于付费案例展示。

呈现时区分用户事实、待验证假设、专项建议及需企业决策的事项。交付内容供管理团队讨论，不直接作为人事、薪酬、合同或制度决定。
