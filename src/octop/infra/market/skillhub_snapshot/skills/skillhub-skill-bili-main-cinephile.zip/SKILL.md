---
name: skillhub-skill-bili-main-cinephile
description: "当用户想按 B 站「影视」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：影视、B站分区、rid 181。"
---

# B 站分区 · 影视

- 一级分区 rid：`181`；网页路由：`/v/cinephile/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 91 条榜单条目，覆盖 6 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 小剧场 | 30 | 9 | 85 |
| 影视剪辑 | 12 | 10 | 183 |
| 影视杂谈 | 36 | 9 | 182 |
| 影视综合 | 1 | 1 | 261 |
| 短片 | 10 | 8 | 256 |
| 预告·资讯 | 2 | 4 | 184 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 小剧场

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 一位自称能听见植物声音的小镇诗人和上海来的催稿编辑 | 煎饼果仔呀 | [BV1oBZdYqE6R](https://www.bilibili.com/video/BV1oBZdYqE6R) | 779.9 万 |
| 另一个世界的你在干什么？ | 脱缰凯Kk | [BV1abZmYrERK](https://www.bilibili.com/video/BV1abZmYrERK) | 419.1 万 |
| 拒绝紫薯恶魔我做不到啊 | 哒哒boy-杂活铺 | [BV1bYZ1YcETz](https://www.bilibili.com/video/BV1bYZ1YcETz) | 254.4 万 |
| 陈翔六点半: “孔布”故事，搞笑来袭 | 陈翔六点半 | [BV1D3RqYaErW](https://www.bilibili.com/video/BV1D3RqYaErW) | 1069.4 万 |
| 鱼心中的成见是一座大山！ | 校校马上火了 | [BV1yJZdYSEMP](https://www.bilibili.com/video/BV1yJZdYSEMP) | 128.1 万 |

### 影视剪辑

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【影史上100句“我爱你”的台词】“或许你我终将落俗，但浪漫至死不渝。” | 白日妄想家 | [BV11dRdY5Ekd](https://www.bilibili.com/video/BV11dRdY5Ekd) | 204.8 万 |
| 即将消失的传统美食，现在只剩几个老人在做了 | 江寻千 | [BV1iXRCYZE8Y](https://www.bilibili.com/video/BV1iXRCYZE8Y) | 746.1 万 |
| “我将跨越，最后的界限” | 光昊Max | [BV17FZUYnExr](https://www.bilibili.com/video/BV17FZUYnExr) | 109.6 万 |
| “你也在看吗？” | Re1剪辑 | [BV1zGRBYDEXD](https://www.bilibili.com/video/BV1zGRBYDEXD) | 308.2 万 |
| “阿加莎女王的本格推理神作，只能使用一次的诡计”——《东方快车谋杀案》 | 留念影剪 | [BV1uhZoYwESR](https://www.bilibili.com/video/BV1uhZoYwESR) | 301.3 万 |

### 影视杂谈

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 真人狼人杀？《迷失》2.0！最新悬疑力作《墨西哥太平间的九具尸体》上 | 小片片说大片 | [BV1CwZ1YHERw](https://www.bilibili.com/video/BV1CwZ1YHERw) | 774.6 万 |
| 警惕此类二番男主流入古偶市场：吐槽辛云来【铁柱】 | 铁铁铁柱_ | [BV1iBZdYqEYZ](https://www.bilibili.com/video/BV1iBZdYqEYZ) | 220.7 万 |
| 史上最还原漫改电影！逼格拉满的暴力美学，8.4分《罪恶之城》 | 培根悖论唠唠嗑 | [BV1nJRkYaEeH](https://www.bilibili.com/video/BV1nJRkYaEeH) | 180.8 万 |
| 横店变竖店，短剧赛道越来越卷，值得看的有哪些《十大短剧》 | low君热剧 | [BV1yqR1Y2EVM](https://www.bilibili.com/video/BV1yqR1Y2EVM) | 492.9 万 |
| 首播破亿！最疯女主，逆袭复仇，师徒反目，爽到飞起！深度解读2025上头韩剧《狂医魔徒》①！ | 竖了个三 | [BV13wZ9YsEyD](https://www.bilibili.com/video/BV13wZ9YsEyD) | 248.2 万 |

### 影视综合

数据来源：二级分区 7 日榜，可用 1 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 人格性别倾向测试！你的先天人格、真实人格、信仰人格是怎样的？会是男or女？人or非人？最像《凸变英雄X》里的谁？ | 不愧是姐姐大人 | [BV18eZmYMEq5](https://www.bilibili.com/video/BV18eZmYMEq5) | 118.6 万 |

### 短片

数据来源：二级分区 7 日榜，可用 8 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 只有八根手指的类人文明 | 虚构柠檬 | [BV1BGRfY3ExL](https://www.bilibili.com/video/BV1BGRfY3ExL) | 508.9 万 |
| 它朝我做鬼脸！ | IKITA_ | [BV17wdwY1EN9](https://www.bilibili.com/video/BV17wdwY1EN9) | 331.7 万 |
| 有的霸总一张嘴全是知识点 | 是西西不嘻嘻耶 | [BV1YaZmYzEKv](https://www.bilibili.com/video/BV1YaZmYzEKv) | 315.1 万 |
| 坏了，还不如一个老外 | 有个同事叫亚当 | [BV1xndnYLEEZ](https://www.bilibili.com/video/BV1xndnYLEEZ) | 269.3 万 |
| 这才是漫改！《刺客伍六七》纯享版！ | Hello吖小志 | [BV1abZmYrEnR](https://www.bilibili.com/video/BV1abZmYrEnR) | 251.4 万 |

### 预告·资讯

数据来源：二级分区 7 日榜，可用 4 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 一起解锁《滤镜》研讨会上檀健次的更多发言~ | 中国电影报道 | [BV1PUdWY9Emv](https://www.bilibili.com/video/BV1PUdWY9Emv) | 20.2 万 |
| 期待和大家见面！ | 松重丰 | [BV12YR1YJEcX](https://www.bilibili.com/video/BV12YR1YJEcX) | 26.9 万 |
| 【IGN】电影《碟中谍8：最终清算》全新预告 | IGN中国 | [BV18uRUYYE2R](https://www.bilibili.com/video/BV18uRUYYE2R) | 30.5 万 |
| 原来孙燕姿的情歌背后是他们 · 直播内容精选【趁热聊聊 \| 李伟菘Paul x 李偲菘 x HOPICO】 | 热门情报局 | [BV1uioDY6EK6](https://www.bilibili.com/video/BV1uioDY6EK6) | 61.3 万 |

## 名称差异与覆盖说明

- 分区表列出但本次榜单未返回条目：AI影像, 影视整活（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=181." https://api.bilibili.com/x/web-interface/ranking/v2?rid=181&type=all. Accessed 6 Nov. 2026.
