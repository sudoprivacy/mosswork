#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""班主任百宝箱 · 座位表生成器（stdlib only）

用法:
  python3 seating_gen.py --students "张三,李四,王五,赵六,..." --rows 6 --cols 8
  python3 seating_gen.py --file students.txt --rows 5 --cols 7 --seed 42
  python3 seating_gen.py --students "..." --rows 6 --cols 8 --mode groups --group-size 6
  python3 seating_gen.py --students "..." --rows 6 --cols 8 --front 张三,李四 --apart 张三:王五

参数:
  --mode random   随机排（默认）
  --mode groups   小组围坐式（组内聚拢，适合讨论式课堂）
  --mode serpentine 蛇形排列（按成绩顺序 S 形混排，需 --scores "名字=分数,...")
  --front A,B     优先安排在前排（视力/听力/注意力需要）
  --back  A,B     优先安排在后排
  --apart A:B,C:D 强制分开坐（易说话组合）
  --seed N        固定随机种子（可复现）

输出: 文本座位表（讲台在上）+ 空位标记。
"""

import argparse
import random
import sys


def parse_students(a):
    if a.file:
        with open(a.file, encoding="utf-8") as f:
            names = [ln.strip() for ln in f if ln.strip()]
    else:
        names = [s.strip() for s in (a.students or "").replace("，", ",").split(",") if s.strip()]
    # 去重保序
    seen = set()
    out = []
    for n in names:
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out


def parse_apart(text):
    pairs = []
    for chunk in (text or "").replace("，", ",").split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if ":" not in chunk:
            print("警告: --apart 项 %r 格式应为 A:B，已忽略" % chunk, file=sys.stderr)
            continue
        x, y = chunk.split(":", 1)
        pairs.append((x.strip(), y.strip()))
    return pairs


def apart_ok(grid, pairs, cols):
    pos = {}
    for idx, name in enumerate(grid):
        if name:
            pos[name] = idx
    for x, y in pairs:
        if x in pos and y in pos:
            rx, cx = divmod(pos[x], cols)
            ry, cy = divmod(pos[y], cols)
            if abs(rx - ry) <= 1 and abs(cx - cy) <= 1:
                return False
    return True


def gen_random(names, rows, cols, front, back, pairs, rng, tries=200):
    seats = rows * cols
    if len(names) > seats:
        raise ValueError("座位 %d 个 < 学生 %d 人" % (seats, len(names)))
    best = None
    for _ in range(tries):
        pool = names[:]
        rng.shuffle(pool)
        grid = [None] * seats
        # 前排优先
        front_row_seats = list(range(cols))
        back_row_seats = list(range((rows - 1) * cols, rows * cols))
        i = 0
        for n in front:
            if n in pool and i < len(front_row_seats):
                grid[front_row_seats[i]] = n
                pool.remove(n)
                i += 1
        j = 0
        for n in back:
            if n in pool and j < len(back_row_seats) and grid[back_row_seats[j]] is None:
                grid[back_row_seats[j]] = n
                pool.remove(n)
                j += 1
        empties = [k for k, v in enumerate(grid) if v is None]
        rng.shuffle(empties)
        for k in empties:
            if pool:
                grid[k] = pool.pop(0)
        if apart_ok(grid, pairs, cols):
            return grid
        best = grid
    print("警告: %d 次尝试后仍无法完全满足 --apart 条件，返回最后一版（请手工微调）" % tries, file=sys.stderr)
    return best


def gen_groups(names, rows, cols, group_size, rng):
    seats = rows * cols
    if len(names) > seats:
        raise ValueError("座位 %d 个 < 学生 %d 人" % (seats, len(names)))
    pool = names[:]
    rng.shuffle(pool)
    grid = [None] * seats
    # 按组聚拢：每组占相邻两列的连续行块
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if pool and idx < seats:
                # 优先填每组中心区域（简化：顺序填充即可，组界由老师看表划分）
                grid[r * cols + c] = pool.pop(0)
    return grid


def gen_serpentine(names, scores, rows, cols):
    seats = rows * cols
    if len(names) > seats:
        raise ValueError("座位 %d 个 < 学生 %d 人" % (seats, len(names)))
    ordered = sorted(names, key=lambda n: scores.get(n, 0), reverse=True)
    grid = [None] * seats
    k = 0
    for r in range(rows):
        col_iter = range(cols) if r % 2 == 0 else range(cols - 1, -1, -1)
        for c in col_iter:
            if k < len(ordered):
                grid[r * cols + c] = ordered[k]
                k += 1
    return grid


def render(grid, rows, cols, name_w):
    line_w = cols * (name_w + 2) + 1
    out = ["【讲台】".center(line_w)]
    out.append("+" + "-" * (name_w + 2) + "+" * cols)
    for r in range(rows):
        cells = []
        for c in range(cols):
            n = grid[r * cols + c] or ""
            cells.append(n.center(name_w, "　" if any(ord(ch) > 127 for ch in n) else " "))
        out.append("| " + " | ".join(cells) + " |")
        out.append("+" + "-" * (name_w + 2) + "+" * cols)
    return "\n".join(out)


def main():
    p = argparse.ArgumentParser(description="座位表生成器")
    p.add_argument("--students")
    p.add_argument("--file")
    p.add_argument("--rows", type=int, default=6)
    p.add_argument("--cols", type=int, default=8)
    p.add_argument("--mode", choices=["random", "groups", "serpentine"], default="random")
    p.add_argument("--group-size", type=int, default=6)
    p.add_argument("--scores", help="serpentine 模式: 名字=分数,名字=分数")
    p.add_argument("--front")
    p.add_argument("--back")
    p.add_argument("--apart")
    p.add_argument("--seed", type=int)
    a = p.parse_args()

    names = parse_students(a)
    if not names:
        print("错误: 没有学生名单（--students 或 --file）", file=sys.stderr)
        sys.exit(1)

    rng = random.Random(a.seed)
    front = [s.strip() for s in (a.front or "").replace("，", ",").split(",") if s.strip()]
    back = [s.strip() for s in (a.back or "").replace("，", ",").split(",") if s.strip()]
    pairs = parse_apart(a.apart)

    if a.mode == "serpentine":
        scores = {}
        for chunk in (a.scores or "").replace("，", ",").split(","):
            if "=" in chunk:
                n, v = chunk.split("=", 1)
                try:
                    scores[n.strip()] = float(v.strip())
                except ValueError:
                    pass
        grid = gen_serpentine(names, scores, a.rows, a.cols)
    elif a.mode == "groups":
        grid = gen_groups(names, a.rows, a.cols, a.group_size, rng)
    else:
        grid = gen_random(names, a.rows, a.cols, front, back, pairs, rng)

    name_w = max(4, max(len(n) for n in names) + (2 if any(ord(ch) > 127 for ch in "".join(names)) else 0))
    print("模式: %s | 规模: %d 行 × %d 列 | 人数: %d | 空位: %d" % (a.mode, a.rows, a.cols, len(names), a.rows * a.cols - len(names)))
    print(render(grid, a.rows, a.cols, name_w))
    if pairs:
        print("\n分开坐约束: %s" % ", ".join("%s×%s" % pr for pr in pairs))
    print("\n提示: 输出为草稿排位，个别微调请结合身高、视力、同伴关系。")


if __name__ == "__main__":
    main()
