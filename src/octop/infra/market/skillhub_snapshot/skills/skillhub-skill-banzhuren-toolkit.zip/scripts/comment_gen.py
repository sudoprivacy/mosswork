#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""班主任百宝箱 · 期末评语生成器（stdlib only）

用法:
  python3 comment_gen.py --list                     列出学生类型骨架
  python3 comment_gen.py --type 航型 --name 小明 \\
      --strengths "数学思维强,乐于助人" --improve "上课爱插嘴" \\
      --events "科技节机器人比赛获奖" --tone warm
  python3 comment_gen.py --batch students.csv       批量生成（CSV: name,type,strengths,improve,events,tone）

设计原则（assets/comment-library.md 同源）:
  三明治结构：肯定亮点 → 一个改进点 → 表达期待。
  每条评语必须嵌入至少 1 个具体事件，杜绝全员通用话。
  生成结果是【草稿】，请人工润色后使用——避免千人一面。
"""

import argparse
import csv
import sys

# ---------- 学生类型骨架 ----------
SKELETONS = {
    "领航型": {
        "desc": "成绩优异、能力强、是班级骨干",
        "tpl": "你是班级里{strengths}的代表。{event}，让老师看到了你的实力与担当。"
               "如果说还有什么可以更进一步，那就是{improve}。"
               "期待你在保持优秀的同时，{expect}，成为真正的领航者。",
        "expect": "多带动身边的同学一起进步，把优秀变成一种影响力",
    },
    "潜力型": {
        "desc": "聪明但未完全发力，波动较大",
        "tpl": "老师一直记得{event}时你的样子——{strengths}，这是你最亮的底色。"
               "关于{improve}，如果能做些调整，就是你和'更好的自己'之间最后一点距离。"
               "新学期，期待你{expect}，让大家看到你真正的实力。",
        "expect": "把目标拆成每天的小行动，稳稳地坚持下来",
    },
    "稳定型": {
        "desc": "踏实认真、不冒尖但很少出错",
        "tpl": "{strengths}，这是你最让老师放心的品质。{event}，是全班都看在眼里的。"
               "如果能在{improve}上再大胆一些，就更好了。"
               "愿你在新学期{expect}，你的努力值得被更多人看见。",
        "expect": "更大胆地表达自己，去争取那些你本就配得上的机会",
    },
    "成长型": {
        "desc": "基础较弱或问题较多，但在进步",
        "tpl": "这学期，老师一直在悄悄为你高兴：{event}。"
               "{strengths}，是你的闪光点，也许你自己还没完全发现。"
               "关于{improve}，我们一起努力。老师相信，只要坚持，{expect}。",
        "expect": "每天进步一点点，积攒起来就是了不起的蜕变",
    },
}

TONES = {
    "warm": {"open": "", "close": ""},
    "formal": {"open": "该生", "close": "望继续努力。"},
    "young": {"open": "亲爱的{name}同学：", "close": "加油，老师看好你！"},
}

DEFAULT_EXPECT = {
    "领航型": "多带动身边的同学一起进步",
    "潜力型": "把目标拆成每天的小行动",
    "稳定型": "更大胆地展示自己",
    "成长型": "每天进步一点点",
}


def normalize(text):
    return [t.strip() for t in (text or "").replace("，", ",").replace("、", ",").split(",") if t.strip()]


def fmt_list(items):
    if not items:
        return ""
    return "、".join(items)


def generate(name, stype, strengths, improve, events, tone="warm"):
    if stype not in SKELETONS:
        raise ValueError("未知学生类型: %s（可用: %s）" % (stype, "/".join(SKELETONS)))
    sk = SKELETONS[stype]
    s_list = normalize(strengths)
    e_list = normalize(events)
    improve_list = normalize(improve)

    if not s_list:
        raise ValueError("strengths 不能为空——评语必须有具体优点")
    if not e_list:
        raise ValueError("events 不能为空——评语必须嵌入至少 1 个具体事件")

    ctx = {
        "name": name,
        "strengths": fmt_list(s_list),
        "event": e_list[0],
        "improve": fmt_list(improve_list) if improve_list else "保持现在的节奏",
        "expect": sk["expect"],
    }
    body = sk["tpl"].format(**ctx)

    t = TONES.get(tone, TONES["warm"])
    parts = []
    if t["open"]:
        parts.append(t["open"].format(name=name))
    parts.append(body)
    if t["close"]:
        parts.append(t["close"])
    return "".join(parts)


def main():
    p = argparse.ArgumentParser(description="期末评语生成器（草稿）")
    p.add_argument("--list", action="store_true", help="列出学生类型骨架")
    p.add_argument("--name", default="同学")
    p.add_argument("--type", dest="stype", default="稳定型", help="领航型/潜力型/稳定型/成长型")
    p.add_argument("--strengths", default="", help="优点，逗号分隔")
    p.add_argument("--improve", default="", help="改进点，逗号分隔")
    p.add_argument("--events", default="", help="具体事件，逗号分隔（至少 1 个）")
    p.add_argument("--tone", default="warm", help="warm/formal/young")
    p.add_argument("--batch", help="CSV 文件批量: name,type,strengths,improve,events,tone")
    a = p.parse_args()

    if a.list:
        for k, v in SKELETONS.items():
            print("%s\t%s" % (k, v["desc"]))
        return

    if a.batch:
        with open(a.batch, encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        for i, r in enumerate(rows, 1):
            try:
                c = generate(
                    r.get("name", "同学"),
                    r.get("type", "稳定型"),
                    r.get("strengths", ""),
                    r.get("improve", ""),
                    r.get("events", ""),
                    r.get("tone", "warm"),
                )
                print("--- %d. %s ---" % (i, r.get("name", "")))
                print(c)
                print()
            except ValueError as e:
                print("--- %d. %s ---\n[跳过] %s\n" % (i, r.get("name", ""), e), file=sys.stderr)
        print("（以上为草稿，请人工润色后再使用）")
        return

    try:
        c = generate(a.name, a.stype, a.strengths, a.improve, a.events, a.tone)
    except ValueError as e:
        print("错误: %s" % e, file=sys.stderr)
        sys.exit(1)
    print("=== %s 的评语草稿 ===" % a.name)
    print(c)
    print()
    print("（草稿仅供润色参考，请加入只有你和学生知道的细节）")


if __name__ == "__main__":
    main()
