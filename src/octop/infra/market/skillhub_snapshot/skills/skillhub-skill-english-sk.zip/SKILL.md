---
name: skillhub-skill-english-sk
description: "# CET-6 English Proficiency"
---

# CET-6 English Proficiency

## Overview

This skill represents a **CET-6 (College English Test Band 6)** level English competency — the highest national standardized English proficiency benchmark for non-English major college students in China. It is designed for users who need to leverage English as a working language in academic research, international business, cross-cultural communication, and professional documentation.

It is not a test-preparation skill. It is a **production-level language capability** that aligns with the CET-6 syllabus requirements and practical application scenarios.

---

## Capability Map

| Domain | Proficiency | Description |
|---|---|---|
| Reading Comprehension | Advanced | Understand complex academic and professional texts |
| Chinese→English Translation | Professional | Accurate, idiomatic written translation |
| English→Chinese Translation | Professional | Faithful, fluent translation with register awareness |
| Formal Writing (Business) | Independent | Emails, proposals, reports, meeting minutes |
| Formal Writing (Academic) | Independent | Essays, abstracts, literature reviews, statements |
| Vocabulary & Register | 5,500+ words | Active command of core CET-6 lexicon and collocations |

---

## Detailed Capabilities

### 1. Professional Reading & Comprehension

- Parse complex academic papers, technical documentation, and industry reports written in English
- Identify nuanced argument structures, implicit logic, hedging language, and rhetorical devices
- Extract key information from dense prose efficiently (skimming, scanning, and critical reading)
- Handle specialized terminology across domains including science & technology, economics & finance, law & policy, social sciences, and humanities
- Understand idiomatic expressions, phrasal verbs, and collocations at the CET-6 level

**Typical source materials:**
- Peer-reviewed journal articles and conference proceedings
- Technical whitepapers and product documentation
- International news analysis and editorial commentary (The Economist, Nature, Financial Times, etc.)
- Legal and regulatory documents (contracts, policies, standards)
- Academic textbooks and reference works

### 2. Chinese–English Written Translation (中英互译)

#### Chinese → English

- Produce idiomatic English from Chinese source texts while preserving original meaning and tone
- Apply appropriate English sentence structures (subordination, participial phrases, relative clauses) to avoid translationese
- Resolve culture-specific concepts, four-character idioms, and rhetorical parallelism through functional equivalence
- Maintain consistent terminology and register throughout the target text

#### English → Chinese

- Render English texts into natural, fluent Chinese with proper word choice and collocation
- Handle long, nested English sentences by restructuring into Chinese paratactic flow
- Convert abstract English nominalizations into idiomatic Chinese verb-predicate constructions
- Preserve the original text's style, register, and pragmatic intent

**Quality standards:**
- Accuracy: no mistranslation, omission, or unwarranted addition
- Fluency: target text reads as naturally as native composition
- Terminology: domain-consistent and context-appropriate
- Style: register-matched to genre (formal, neutral, or informal as required)

### 3. Formal English Writing

#### Business Correspondence

- **Emails:** Inquiries, replies, confirmations, follow-ups, apologies, requests, scheduling, and status updates — with appropriate salutations, closings, and tone calibration
- **Proposals & Reports:** Structured business proposals, project status reports, meeting minutes, and executive summaries
- **Negotiation & Persuasion:** Letters of offer, counter-offer, complaint, adjustment, and recommendation

#### Academic & Administrative Documents

- **Essays & Theses:** Well-structured argumentative essays with clear thesis statements, coherent paragraph development, and proper citation conventions (APA, MLA, IEEE, Chicago)
- **Abstracts & Summaries:** Concise and accurate English abstracts for Chinese-language papers
- **Statements:** Personal statements, statements of purpose, letters of recommendation, and research proposals
- **Official Correspondence:** Notices, announcements, memos, and inter-institutional letters

#### Writing Quality Benchmarks

| Criterion | Standard |
|---|---|
| Grammar & Syntax | Error-free; correct tense, number, modality, and subordination |
| Lexical Range | Precise word choice; appropriate use of CET-6 vocabulary |
| Cohesion | Effective use of discourse markers, reference, substitution, and lexical cohesion |
| Register | Tone, formality level, and style consistently matched to genre and audience |
| Organization | Clear information structure with logical progression |
| Rhetorical Effectiveness | Achieves intended communicative purpose |

### 4. Cross-Modal Language Support

- **Polishing & Revision:** Refine drafts written by non-native speakers into natural, publication-ready English
- **Summarization:** Condense lengthy English or Chinese texts into concise English summaries
- **Paraphrasing:** Rewrite sentences or passages to improve clarity or avoid plagiarism
- **Contrastive Analysis:** Explain differences between Chinese and English expression patterns to deepen the user's language awareness

---

## Register & Style Guide

The skill operates across three registers depending on the task and audience:

| Register | Audience / Genre | Characteristics |
|---|---|---|
| Formal | Academic papers, official correspondence, legal docs | Full word forms (no contractions); Latinate vocabulary; complex sentence structures; impersonal constructions |
| Semi-formal | Business emails, reports, proposals, memos | Moderate use of contractions; standard vocabulary; clear, straightforward sentences; first-person acceptable |
| Neutral | General communication, cross-cultural exchange | Balanced lexicon; plain syntax; clarity prioritized over stylistic ornament |

---

## Interaction Guidelines

1. **Translation tasks** — always state the direction (zh→en or en→zh) and the target register; the skill will output the translation followed by a brief rationale for key lexical or structural choices when requested.
2. **Writing tasks** — specify the genre (email, proposal, abstract, etc.), target audience, and tone preference; the skill will compose the full text and optionally provide a revision log on demand.
3. **Reading tasks** — paste or describe the material; the skill can produce a summary, a critical analysis, a keyword extraction, or answer specific comprehension questions.
4. **Mixed-language input** — the skill tolerates code-switching (e.g., a Chinese message with embedded English terms) and responds in the appropriate language for the task.

---

## Limitations

- This skill is **not** an IELTS/TOEFL test simulator — it does not generate test-style questions or scoring rubrics
- This skill does **not** provide spoken English / pronunciation coaching (it is text-only)
- Domain-specific terminology in highly specialized fields (e.g., advanced medical research, quantum physics) may require supplementary glossaries for optimal accuracy
- Translation of classical Chinese (文言文) or heavily literary texts may prioritize communicative accuracy over aesthetic preservation

---

## Version History

| Version | Date | Changes |
|---|---|---|
| 1.0.0 | 2026-05-17 | Initial release — core CET-6 aligned reading, translation, and writing capabilities |

---

## Related Skills

- `ielts-academic-writing` — for test-specific academic writing preparation
- `business-english-communication` — for specialized business negotiation and presentation skills
- `chinese-english-conference-interpreting` — for simultaneous/consecutive interpretation needs
