#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""字体解析器 · 跨平台自动找可用中文字体（Linux / Windows / macOS）
用法：
    from font_resolver import ensure
    FONT_SANS = ensure("sans_bold")
    FONT_SERIF = ensure("serif_bold")
找不到时 raise RuntimeError，报错文案自带三步安装指引。
"""
import os

_CANDIDATES = {
    "sans_bold": [
        # Linux（Noto / 文泉驿）
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/noto-cjk/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/wenquanyi/wqy-microhei/wqy-microhei.ttc",
        # Windows
        "C:/Windows/Fonts/msyhbd.ttc",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/Deng.ttf",
        # macOS
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
    ],
    "serif_bold": [
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc",
        "/usr/share/fonts/noto-cjk/NotoSerifCJK-Bold.ttc",
        "C:/Windows/Fonts/simsun.ttc",
        "C:/Windows/Fonts/STZHONGS.TTF",
        "C:/Windows/Fonts/msyhbd.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "/System/Library/Fonts/Supplemental/Songti.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
    ],
    "sans_regular": [
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "/System/Library/Fonts/PingFang.ttc",
    ],
}

_GUIDE = (
    "本机没找到可用的中文字体。三步解决：\n"
    "  1. 下载思源黑体/宋体（Noto CJK）：https://github.com/notofonts/noto-cjk/releases\n"
    "  2. 把 NotoSansCJK-Bold.ttc / NotoSerifCJK-Bold.ttc 放到任意目录；\n"
    "  3. 在本脚本顶部 _CANDIDATES 里把你的路径加进对应列表（或设环境变量 CJK_FONT_DIR 指向该目录）。\n"
    "Windows 用户一般已有 msyh/simhei，无需下载。"
)

def _extra_dirs():
    env = os.environ.get("CJK_FONT_DIR")
    return [env] if env else []

def find(kind):
    """返回第一个存在的字体路径；kind: sans_bold / serif_bold / sans_regular"""
    paths = list(_CANDIDATES.get(kind, []))
    for d in _extra_dirs():
        if os.path.isdir(d):
            for f in sorted(os.listdir(d)):
                if f.lower().endswith((".ttc", ".ttf", ".otf")):
                    paths.append(os.path.join(d, f))
    for p in paths:
        if p and os.path.exists(p):
            return p
    return None

def ensure(kind):
    p = find(kind)
    if not p:
        raise RuntimeError(_GUIDE)
    return p

if __name__ == "__main__":
    for k in ("sans_bold", "serif_bold", "sans_regular"):
        print(k, "->", find(k) or "未找到")
