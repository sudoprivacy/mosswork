#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""环境自检 · 一键体检（不联网、不改系统，只读）
用法：python3 scripts/check_env.py
结论分三档：全绿=出图出片全功能 / 黄=部分增强功能不可用 / 红=需装字体。
对话功能（拆书/四问/话术/机检）永远可用，不依赖任何安装项。
"""
import importlib, shutil, sys, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from font_resolver import find

OK, MISS = "✅", "❌"
rows = []

def check(name, fn, hint, affects):
    try:
        detail = fn()
        rows.append((OK, name, detail, ""))
    except Exception as e:
        rows.append((MISS, name, str(e), affects))

def py_ver():
    v = sys.version_info
    assert v >= (3, 8), f"{v.major}.{v.minor}.{v.micro}（需 ≥3.8）"
    return f"{v.major}.{v.minor}.{v.micro}"

def mod(name):
    def _f():
        m = importlib.import_module(name)
        return getattr(m, "__version__", "已安装")
    return _f

def font(kind):
    def _f():
        p = find(kind)
        assert p, "未找到"
        return p
    return _f

def ffmpeg():
    p = shutil.which("ffmpeg")
    assert p, "未找到"
    return p

check("Python ≥3.8", py_ver, "", "脚本无法运行；对话功能不受影响")
check("Pillow（出图核心）", mod("PIL"), "", "pip install pillow")
check("字体·黑体", font("sans_bold"), "", "见下方字体指引")
check("字体·宋体", font("serif_bold"), "", "见下方字体指引（无宋体自动用黑体顶替）")
check("ffmpeg（出视频）", ffmpeg, "", "出视频不可用；海报/卡片不受影响。安装：apt install ffmpeg / brew install ffmpeg / https://ffmpeg.org")

print("=" * 56)
print("环境自检报告（对话功能永远可用，以下只影响出图出片）")
print("=" * 56)
for mark, name, detail, hint in rows:
    print(f"{mark} {name} {detail}")
    if mark == MISS and hint:
        print(f"   └─ 解法：{hint}")

bad = [r for r in rows if r[0] == MISS]
print("-" * 56)
if not bad:
    print("结论：全绿。海报、卡片、视频全部可用。")
elif all("字体" not in r[1] for r in bad):
    print("结论：核心可用。缺的只是增强项（见上），对话与机检不受影响。")
else:
    print("结论：需处理字体（见字体指引）——出图出片依赖它，对话功能不受影响。")
sys.exit(0)
