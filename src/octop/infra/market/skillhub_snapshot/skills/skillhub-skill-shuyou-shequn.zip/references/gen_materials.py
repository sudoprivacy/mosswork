#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""书友·读书社群运营物料工具箱：群公告卡（竖版）+ 每日打卡卡（方图）· 书院制式（墨绿金）
用法：
  python3 gen_materials.py poster --group "共读会·心理" --line "上班族每周共读一本心理书，下班后30分钟，读完就聊" \
      --rules "打卡为本;不刷广告;对书不对人" --rhythm "周一话题 / 周三打卡 / 周六领读夜" --out 群公告.png
  python3 gen_materials.py card --day 5 --book "蛤蟆先生去看心理医生" \
      --topic "书里你最不认同的一句" --name "共读会·心理"
跨平台字体：自动解析 Windows/macOS/Linux 中文字体（详见 环境自检卡）。
"""
import argparse, math, sys, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

def _resolve_font():
    """跨平台中文字体解析：优先宋体（书院制式），找不到落黑体"""
    here = os.path.dirname(os.path.abspath(__file__))
    cands = []
    env = os.environ.get("CJK_FONT_DIR")
    if env:
        cands += [env]
    cands += [
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        os.path.expanduser("~/.fonts"), "/usr/share/fonts",
        "C:/Windows/Fonts", "/System/Library/Fonts", "/Library/Fonts",
    ]
    names = ["NotoSerifCJK-Bold.ttc", "NotoSansCJK-Bold.ttc",
             "simsun.ttc", "msyh.ttc", "msyhbd.ttc", "simhei.ttf",
             "Songti.ttc", "STSong.ttf", "PingFang.ttc"]
    import glob
    for base in cands:
        for n in names:
            p = os.path.join(base, n) if not n.startswith("/") else n
            for hit in glob.glob(p):
                if os.path.isfile(hit):
                    return hit
    return FONT

FONT = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc"  # index=2 → SC 铁律
try:
    ImageFont.truetype(FONT, 20, index=2)
except Exception:
    FONT = _resolve_font()

GOLD = (222, 186, 118)
GOLD_DIM = (196, 158, 96)
CREAM = (240, 232, 212)

def f(size):
    return ImageFont.truetype(FONT, size, index=2)

def base_canvas(w, h):
    """墨绿径向渐变底 + 金双框（书院制式）"""
    img = Image.new("RGB", (w, h))
    px = img.load()
    cx, cy = w/2, h*0.38
    inner, outer = (46, 94, 82), (13, 33, 28)
    maxd = math.hypot(w/2, h/2)
    for y in range(h):
        for x in range(w):
            d = math.hypot(x-cx, y-cy) / maxd
            t = min(1.0, d) ** 1.4
            px[x, y] = tuple(int(inner[i] + (outer[i]-inner[i])*t) for i in range(3))
    dr = ImageDraw.Draw(img, "RGBA")
    m = 20
    dr.rectangle([m, m, w-m, h-m], outline=GOLD_DIM + (255,), width=3)
    m2 = 30
    dr.rectangle([m2, m2, w-m2, h-m2], outline=(222, 186, 118, 90), width=1)
    return img, dr

def fit_font(dr, text, max_w, start):
    s = start
    while s > 24:
        fo = f(s)
        if dr.textlength(text, font=fo) <= max_w:
            return fo
        s -= 4
    return f(24)

def center(dr, W, text, fo, y, fill=GOLD, shadow=(10, 30, 24), soff=(4, 5)):
    tw = dr.textlength(text, font=fo)
    x = (W - tw) / 2
    if shadow:
        dr.text((x+soff[0], y+soff[1]), text, font=fo, fill=shadow)
    dr.text((x, y), text, font=fo, fill=fill)
    return y

def _wrap(dr, text, fo, max_w):
    lines, cur = [], ""
    for ch in text:
        if dr.textlength(cur + ch, font=fo) > max_w:
            lines.append(cur); cur = ch
        else:
            cur += ch
    lines.append(cur)
    return lines

def open_book(dr, cx, by, half_w=150, page_h=66):
    for side in (-1, 1):
        pts = [(cx, by-8), (cx+side*half_w, by-8-page_h*0.30),
               (cx+side*half_w, by-8-page_h*0.30+page_h), (cx, by-8+page_h)]
        dr.polygon(pts, fill=CREAM + (255,), outline=GOLD_DIM)
        for i in range(1, 4):
            t = i / 4
            x0 = cx + side*half_w*t
            y0 = by - 8 - page_h*0.30*t + 14
            dr.line([(x0, y0), (x0, y0+page_h*0.60)], fill=(180, 168, 140), width=3)
    dr.line([(cx, by-8), (cx, by-8+page_h)], fill=(120, 105, 80), width=4)

def gen_poster(a):
    """群公告卡：群名 + 定位一句话 + 三条群规 + 每周节奏"""
    W, H = 1080, 1440
    img, dr = base_canvas(W, H)
    y = 110
    # 群名（大金字，自动缩号）
    fo_g = fit_font(dr, a.group, W*0.78, 120)
    y = center(dr, W, a.group, fo_g, y) + fo_g.size + 24
    y = center(dr, W, "共 读 会 · 群 公 告", f(36), y, fill=GOLD_DIM) + 50
    dr.line([(W*0.3, y), (W*0.7, y)], fill=GOLD_DIM, width=3)
    y += 56
    # 定位一句话（自动换行，奶白）
    fo_l = fit_font(dr, a.line, W*0.74, 52)
    for line in _wrap(dr, a.line, fo_l, W*0.74):
        y = center(dr, W, line, fo_l, y, fill=CREAM, shadow=None) + (fo_l.size + 20)
    y += 64
    # 群规三条
    y = center(dr, W, "群 规 三 条", f(40), y, fill=GOLD) + 56
    for i, rule in enumerate(a.rules.split(";"), 1):
        rule = rule.strip()
        fo_r = fit_font(dr, rule, W*0.62, 48)
        dr.text((W*0.16, y), f"{i}", font=f(44), fill=GOLD_DIM)
        for line in _wrap(dr, rule, fo_r, W*0.66):
            dr.text((W*0.24, y), line, font=fo_r, fill=CREAM)
            y += fo_r.size + 16
        y += 26
    y += 30
    # 每周节奏
    y = center(dr, W, f"每周节奏｜{a.rhythm}", f(42), y, fill=GOLD_DIM) + 60
    open_book(dr, W/2, min(y + 30, H - 320), half_w=120, page_h=52)
    center(dr, W, "打卡三行 · 说真话就行", f(36), H-220, fill=GOLD)
    center(dr, W, "才赋书院 · 书友社群物料", f(28), H-145, fill=GOLD_DIM)
    img.save(a.out)
    print("saved", a.out)

def gen_card(a):
    """每日打卡卡：第 N 天 + 本周共读 + 今日话题 + 三行模板提示"""
    W, H = 1080, 1080
    img, dr = base_canvas(W, H)
    y = H*0.12
    y = center(dr, W, f"共 读 第 {a.day} 天", f(88), y) + 88 + 34
    y = center(dr, W, f"本周共读《{a.book}》", f(46), y, fill=CREAM, shadow=None) + 46 + 56
    dr.line([(W*0.3, y), (W*0.7, y)], fill=GOLD_DIM, width=3)
    y += 64
    y = center(dr, W, "今 日 话 题", f(38), y, fill=GOLD_DIM) + 38 + 30
    fo_t = fit_font(dr, a.topic, W*0.74, 76)
    for line in _wrap(dr, a.topic, fo_t, W*0.74):
        y = center(dr, W, line, fo_t, y, fill=GOLD, shadow=None) + (fo_t.size + 24)
    y += 56
    # 三行模板提示
    fo_m = f(40)
    for line in ["我读到：P__", "最触动：＿＿＿＿", "我想说：＿＿＿＿"]:
        y = center(dr, W, line, fo_m, y, fill=CREAM, shadow=None) + (fo_m.size + 16)
    open_book(dr, W/2, H*0.82, half_w=110, page_h=50)
    center(dr, W, a.name, f(34), H-140, fill=GOLD_DIM)
    img.save(a.out)
    print("saved", a.out)

def main():
    p = argparse.ArgumentParser(description="书友社群物料生成（群公告卡/每日打卡卡）")
    sub = p.add_subparsers(dest="cmd", required=True)

    pp = sub.add_parser("poster", help="群公告卡 1080x1440")
    pp.add_argument("--group", required=True, help="群名，如 共读会·心理")
    pp.add_argument("--line", required=True, help="群定位一句话")
    pp.add_argument("--rules", required=True, help="三条群规，用分号隔开")
    pp.add_argument("--rhythm", required=True, help="每周节奏，如 周一话题/周三打卡/周六领读")
    pp.add_argument("--out", default="群公告卡.png")

    pc = sub.add_parser("card", help="每日打卡卡 1080x1080")
    pc.add_argument("--day", type=int, required=True, help="共读第几天")
    pc.add_argument("--book", required=True, help="本周共读书名")
    pc.add_argument("--topic", required=True, help="今日话题")
    pc.add_argument("--name", required=True, help="群名/署名")
    pc.add_argument("--out", default="打卡卡.png")

    a = p.parse_args()
    (gen_poster if a.cmd == "poster" else gen_card)(a)

if __name__ == "__main__":
    main()
