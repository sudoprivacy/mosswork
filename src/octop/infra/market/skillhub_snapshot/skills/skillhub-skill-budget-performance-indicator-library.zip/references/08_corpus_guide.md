# 08 · 万条级指标语料库使用说明

本库在「239 条专家精编样本（见 `03_indicator_library.md`）」之外，额外提供一份**万条级指标语料库**（存储于 `assets/corpus_by_domain/`，按 16 个领域分文件），用于检索候选指标、覆盖更多业务场景、快速搭出项目初稿。两者定位不同，按需在 SKILL.md 工作流第 3 步组合使用。

> **短代码说明**：source_url／note／target_value_ref／source_doc／tolerance_hint／valuation_method／data_source／evidence 八列存短代码（如 V1、D3、M1），完整文本见 `assets/corpus_legend.csv`；`search_indicators.py` 自动解码展示，手工解析时请先加载图例。

> **读取提示**：语料库为 UTF-8 无 BOM 编码、RFC 4180 格式。程序读取用 `encoding="utf-8"`；Excel 请用「数据 → 从文本导入」选 UTF-8，直接双击可能中文乱码。语料库按 16 个领域分文件存储（每文件 322–2,227 行，行数与 SHA256 见 `corpus_manifest.json`，合计恒等于 10,800 条），任意单文件都可整读，不存在截断问题。公开收录条目的 direction／valuation_method／data_source／evidence 为统一默认值（诚实标注须本地化），不是缺失。

## 1. 语料库规模与构成

| 项目 | 数量 |
|---|---|
| 总条目 | **10,800** 条 |
| 公开收录（PUBLIC_COLLECTED） | 9,183 条 |
| 结构化派生（STRUCTURED_DERIVED） | 1,617 条 |
| 覆盖领域 | 16 个支出功能领域（最少领域 322 条，最多领域 2,227 条） |
| 一级指标 | 成本 1,183 / 产出 5,941 / 效益 2,619 / 满意度 1,057 |

字段（**23 列**，UTF-8 无 BOM 编码）：`id, name, level1, level2, domain, domain_name, project_type, unit, direction, sign, formula_or_definition, value_source_type, target_value_ref, tolerance_hint, valuation_method, data_source, evidence, source_level, source_doc, source_url, scope, derived_rule, note`。

### 1.1 紧凑编码列与图例表

为控制文件体积（公开来源的 URL、提示语、依据文件名在数千行里整段重复），以下 5 列存**短代码**而非完整文本，完整文本集中登记在 `assets/corpus_legend.csv`（`field,code,value`，编码事实来源为 `scripts/corpus_codes.py` 的 `CODES`）：

| 列 | 代码示例 | 含义 |
|---|---|---|
| `source_url` | U1 | 同仁市财政局指标库通知链接（含出处说明） |
| `note` | N1／N2／N3 | 公开抽取／派生警示／公开抽取＋层级规范化须复核 |
| `target_value_ref` | V1／V2 | 公开文件参照写法／派生候选须自测目标值 |
| `source_doc` | D1–D5 | 共性／分行业分领域／分部门／中央直达资金四册＋派生层 |
| `tolerance_hint` | T1 | 「按 02_schema_fields.md 第 4 节复核」（其余短值如 0、±2个百分点 原样存储） |

`search_indicators.py` 输出前会按图例自动还原完整文本，直接使用无需手工解码；手工处理 CSV 时用图例表对照即可。`assets/public_indicators.csv` 的 `source_doc` 列同样使用 D 代码。新增条目若引入未登记的长文本值，`build_indicator_corpus.py` 会直接报错阻止，须先在 `CODES` 登记后再生成。

## 2. 两类来源的真实性与使用纪律

语料库**不冒充国家标准**，逐条标注来源层级：

- **公开收录（PUBLIC_COLLECTED）**：从财政部门公开发布的绩效指标库文件中逐条抽取。当前收录来源为**同仁市财政局《关于印发同仁市预算项目绩效指标库的通知》（2026-09-01，含共性／分行业分领域／分部门／中央直达资金四册）**，链接见每行 `source_url`。抽取字段包括指标名称、一级／二级分类、度量单位、指标解释（公式定义）、价值来源类型、目标值参照写法、依据出处。
  - **使用纪律**：公开条目仍须核对**本级财政部门当期口径**（字段、允差、标准值以本地为准），并对目标值、口径与适用性本地化；不要直接照抄外地标准值当作本项目的达标线。
- **结构化派生（STRUCTURED_DERIVED）**：以公开收录条目为骨架，按「领域 × 业务对象 × 度量形式」结构化扩充的**候选指标**，用于覆盖未收录的具体业务场景。派生条目在 `derived_rule` 列记录生成规则，**不是官方指标**，使用前必须补齐可核验依据、确定取值来源并完成本地化，否则不得进入正式申报表。

无论哪类，检索结果**仅为候选**；正式编报须回到 SKILL.md 核心规则与 `references/02_schema_fields.md` 的 25 字段结构，逐条补全依据、目标值与允值后再出表。

## 3. 检索方法

使用 `scripts/search_indicators.py`（纯标准库，无需第三方依赖）：

```bash
# 统计语料库整体分布
python scripts/search_indicators.py --stats

# 按领域 + 关键词检索（产出 Markdown 候选表）
python scripts/search_indicators.py --domain EDU,HEA --keyword 资助 --limit 30

# 按一级/二级指标 + 来源层级过滤，导出 CSV
python scripts/search_indicators.py --level1 成本指标 --source-level PUBLIC_COLLECTED --format csv --out cost_pub.csv

# 仅看某二级指标在某领域的数量
python scripts/search_indicators.py --domain ENV --level2 生态效益指标 --stats
```

筛选项：`--domain`（领域码，逗号分隔）、`--level1`、`--level2`、`--keyword`（匹配名称+解释+适用范围）、`--unit`、`--source-level`、`--limit`、`--format md|csv`、`--out 路径`、`--stats`。

## 4. 与精编样本的衔接

- 先跑 `search_indicators.py` 捞候选 → 按本项目画像筛选 8–15 条 → 用 `03_indicator_library.md` 的精编样本校对措辞与结构 → 按 `02_schema_fields.md` 的 12 项要素逐条补全 → 跑 `validate_indicators.py` → 跑 `build_indicator_table.py` 出表。
- 派生条目若被采纳，补完依据后建议回写到 `03_indicator_library.md` 或本地指标表，避免每次重新派生。

## 5. 重新生成语料库（可选）

如需调整规模或扩充领域，运行 `scripts/build_indicator_corpus.py`（纯标准库）：

```bash
python scripts/build_indicator_corpus.py --target 10800
```

该脚本以公开收录条目为基底，按领域均衡轮转 + 结构化派生补足至目标条数，写出主文件后由 `export_corpus.py` 定稿为分领域文件（主文件随即删除）。生成结果同样遵守第 2 节的来源标注纪律。
