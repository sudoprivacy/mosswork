#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检索万条级指标语料库（assets/indicator_corpus.csv）。

用法：
  python search_indicators.py --domain EDU,HEA --keyword 资助 --limit 30
  python search_indicators.py --level1 成本指标 --source-level PUBLIC_COLLECTED --format csv --out result.csv
  python search_indicators.py --stats

纯标准库。检索结果仅为候选，正式编报须按 SKILL.md 与 references/08 核验依据并本地化。
"""
from __future__ import annotations

import argparse
import csv
import io
import sys
from collections import Counter
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

CORPUS_DIR = Path(__file__).resolve().parents[1] / "assets" / "corpus_by_domain"
LEGACY_MASTER = Path(__file__).resolve().parents[1] / "assets" / "indicator_corpus.csv"
SHOW = ["id", "name", "level1", "level2", "domain", "unit", "direction",
        "formula_or_definition", "value_source_type", "target_value_ref",
        "tolerance_hint", "source_level", "source_doc", "note"]
# 这些列在语料库中存的是短代码，展示与导出前按图例还原完整文本
CODED_FIELDS = ("source_url", "note", "target_value_ref", "source_doc",
                "tolerance_hint", "valuation_method", "data_source", "evidence")

from corpus_codes import load_legend  # noqa: E402
LEGEND = load_legend()


def dec(field: str, value: str) -> str:
    return LEGEND.get(field, {}).get(value, value) if value else value


def load():
    files = sorted(CORPUS_DIR.glob("corpus_*.csv"))
    if not files and LEGACY_MASTER.exists():  # 兼容旧布局
        files = [LEGACY_MASTER]
    rows = []
    for f in files:
        # utf-8-sig 解码器对无 BOM 文件同样正常
        with f.open(encoding="utf-8-sig", newline="") as fh:
            rows.extend(csv.DictReader(fh))
    return rows


def main() -> int:
    ap = argparse.ArgumentParser(description="检索预算绩效指标语料库")
    ap.add_argument("--domain", default="", help="领域码，多个用逗号分隔，如 EDU,HEA")
    ap.add_argument("--level1", default="")
    ap.add_argument("--level2", default="")
    ap.add_argument("--keyword", default="", help="在指标名称与解释中模糊匹配")
    ap.add_argument("--unit", default="")
    ap.add_argument("--source-level", default="",
                    choices=["", "PUBLIC_COLLECTED", "STRUCTURED_DERIVED"])
    ap.add_argument("--limit", type=int, default=30)
    ap.add_argument("--format", choices=["md", "csv"], default="md")
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument("--stats", action="store_true", help="仅输出语料库统计")
    args = ap.parse_args()

    rows = load()
    if args.stats:
        print(f"语料库总数：{len(rows)}")
        print("来源层级：", dict(Counter(r["source_level"] for r in rows)))
        print("一级指标：", dict(Counter(r["level1"] for r in rows)))
        print("领域分布：", dict(Counter(r["domain"] for r in rows)))
        return 0

    doms = {d.strip().upper() for d in args.domain.split(",") if d.strip()}
    kw = args.keyword.strip()
    hit = []
    for r in rows:
        if doms and r["domain"] not in doms:
            continue
        if args.level1 and args.level1 not in r["level1"]:
            continue
        if args.level2 and args.level2 not in r["level2"]:
            continue
        if args.unit and args.unit != r["unit"]:
            continue
        if args.source_level and r["source_level"] != args.source_level:
            continue
        if kw and kw not in (r["name"] + r["formula_or_definition"] + r["scope"]):
            continue
        hit.append(r)

    shown = [{k: dec(k, v) if k in CODED_FIELDS else v for k, v in r.items()}
             for r in hit[:args.limit]]
    if args.format == "csv":
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=SHOW, extrasaction="ignore", lineterminator="\n")
        w.writeheader()
        w.writerows(shown)
        text = buf.getvalue()
    else:
        head = "| " + " | ".join(SHOW[:8]) + " | 来源层级 | 依据提示 |"
        lines = [f"检索命中 {len(hit)} 条，显示前 {len(shown)} 条", "", head,
                 "| " + " | ".join(["---"] * 10) + " |"]
        for r in shown:
            cells = [str(r[k]).replace("|", "｜").replace("\n", " ")[:60] for k in SHOW[:8]]
            cells += [r["source_level"], r["target_value_ref"][:50]]
            lines.append("| " + " | ".join(cells) + " |")
        lines += ["", "> 检索结果仅为候选。公开收录条目须核对本级口径；结构化派生条目不是官方指标，"
                  "使用前必须补齐依据并本地化目标值。"]
        text = "\n".join(lines) + "\n"

    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8-sig" if args.format == "csv" else "utf-8")
        print(f"命中 {len(hit)} 条，已写入 {args.out}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
