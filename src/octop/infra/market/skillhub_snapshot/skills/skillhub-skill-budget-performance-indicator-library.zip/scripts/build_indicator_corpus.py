#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""构建「预算绩效管理指标库」万条级指标语料。

数据来源分两层，逐条用 source_level 标明，禁止混称：
  PUBLIC_COLLECTED   —— 从公开发布的预算绩效指标库文件逐条抽取（见 references/08）
  STRUCTURED_DERIVED —— 依据公开条目的句式与业务对象，按规则结构化派生的候选指标
                        （不是官方指标，编报前须按本级依据核验与本地化）

输入：assets/public_indicators.csv（公开层）
输出：assets/indicator_corpus.csv（公开层 + 派生层，≥10000 条）
用法：python build_indicator_corpus.py [--target 10800]
纯标准库，可重复运行、结果确定。
"""
from __future__ import annotations

import argparse
import csv
import re
from collections import Counter, defaultdict
from pathlib import Path

ASSETS = Path(__file__).resolve().parents[1] / "assets"

DOMAINS = {
    "CMN": "共性（所有项目）", "GPS": "一般公共服务与政务运行", "EDU": "教育",
    "SCI": "科学技术", "CUL": "文化旅游体育与传媒", "SOC": "社会保障和就业",
    "HEA": "卫生健康", "ENV": "节能环保", "URB": "城乡社区与住房保障",
    "AGR": "农林水", "TRA": "交通运输", "IND": "产业与信息化",
    "COM": "商业服务业与消费促进", "NAT": "自然资源与林草气象",
    "EMG": "应急管理与公共安全", "OTH": "储备债务基金与其他",
}

# 领域关键词（用于把公开条目映射到领域；顺序即优先级）
DOMAIN_KEYWORDS = [
    ("EDU", "学校|学生|教师|学位|教学|幼儿园|义务教育|课程|招生|校舍|教材|高校|职业教育|助学|入园|在校生|班级|学科|培训学员"),
    ("HEA", "医疗|卫生|医院|患者|疫苗|疾控|签约|诊疗|床位|药品|公共卫生|筛查|慢病|家庭医生|接种|门诊|护理|急救|妇幼"),
    ("SOC", "社保|养老|就业|低保|救助|补贴|残疾|儿童福利|失业|保险|优抚|殡葬|社区服务|困难群众|特困|孤儿|退役"),
    ("AGR", "农田|农业|灌溉|农机|农技|种植|养殖|林业|水利|河湖|防汛|饮水|高标准|化肥|农药|种子|渔|畜牧|灌区|水土保持"),
    ("TRA", "公路|道路|桥梁|公交|运输|养护|航道|客运|车辆|里程|危桥|隧道|路网|码头|客运站|超限"),
    ("ENV", "污染|环保|减排|水质|空气|垃圾|节能|生态|监测|绿化|噪声|COD|氨氮|排污|固废|土壤|碳排放|河流断面"),
    ("URB", "小区|市政|路灯|排水|污水|住房|保障房|物业|城管|公园|燃气|供水管网|老旧|棚户|公厕|环卫"),
    ("IND", "企业|产业|园区|信息化|系统|数据|技改|中小企业|研发|软件|数字化|平台|接口|云资源|智能制造|专精特新"),
    ("CUL", "文化|文物|图书|场馆|旅游|体育|赛事|演出|展览|传媒|非遗|古籍|博物馆|广播|群众文化|艺术"),
    ("SCI", "科研|课题|成果|专利|论文|科普|实验室|技术标准|研发人员|仪器共享|学术|转化"),
    ("NAT", "国土|耕地|矿产|森林|造林|地质|气象|测绘|自然资源|规划编制|土地|草原|湿地|不动产"),
    ("EMG", "应急|消防|隐患|演练|救灾|储备|安全生产|预警|物资|事故|防灾|救援|值守"),
    ("COM", "商贸|消费|展会|外贸|市场|流通|电商|促消费|招商|口岸|批发|零售|老字号"),
    ("OTH", "债务|基金|PPP|直达资金|贴息|转移支付|储备粮|轮换|专项债|主权|国有资本"),
    ("GPS", "会议|培训|政务|执法|监管|档案|统计|办公|政策研究|宣传|督查|办件|审批|人大|政协|考核|调研"),
]

# 各领域业务对象（用于结构化派生；非官方分类，仅作检索与编报起点）
OBJECTS = {
    "GPS": ["政务服务事项", "行政执法案件", "政策研究课题", "会议培训活动", "政务公开信息", "档案归集", "督查交办事项", "统计数据产品", "窗口办件", "公文流转", "人大代表建议", "宣传报道", "信息化建设任务", "部门预算项目"],
    "EDU": ["义务教育学位", "学前教育资源", "在校学生", "专任教师", "校舍修缮", "教学设备", "学生资助", "课程资源", "课后服务", "职业教育实训", "特殊教育服务", "教师培训", "教材供应", "校园安全设施"],
    "SCI": ["科研课题", "科技成果", "专利产出", "研发平台", "科普活动", "实验室仪器", "技术标准", "学术交流", "成果转化项目", "科研人才", "科技文献", "试验数据"],
    "CUL": ["公共文化场馆", "群众文化活动", "文物保护单位", "图书藏量", "全民健身设施", "体育赛事", "旅游推广活动", "非遗项目", "展演场次", "文化服务点", "广播电视节目", "文化志愿者"],
    "SOC": ["养老保险待遇", "社会救助对象", "就业培训", "公益性岗位", "养老服务床位", "困境儿童保障", "残疾人服务", "低保家庭", "失业保险待遇", "社区服务项目", "补贴发放批次", "社会组织培育", "零就业家庭帮扶", "退役军人服务"],
    "HEA": ["基本公共卫生服务", "家庭医生签约", "疫苗接种", "慢病规范管理", "医疗设备", "基层医疗机构", "重点人群筛查", "院感防控", "急救响应", "妇幼健康服务", "健康档案", "药品供应保障", "卫生人才培训", "传染病监测"],
    "ENV": ["污染物减排", "水质监测断面", "空气质量监测", "垃圾分类处理", "节能改造", "生态修复面积", "绿化养护", "环境执法检查", "噪声监测点", "环保设施运行", "排污许可", "土壤污染治理", "环保宣传", "碳排放核算"],
    "URB": ["老旧小区改造", "保障性住房", "市政道路养护", "路灯照明", "排水管网", "污水处理设施", "生活垃圾清运", "物业管理服务", "城市公园", "公厕维护", "燃气安全", "无障碍设施", "城市体检", "背街小巷整治"],
    "AGR": ["高标准农田", "灌溉设施", "农村饮水工程", "农机作业", "农技推广", "粮食播种", "畜禽养殖", "河湖管护", "防汛设施", "水土保持", "农产品检测", "集体经济项目", "化肥农药减量", "林业有害生物防治"],
    "TRA": ["公路养护里程", "危桥改造", "公交线路", "客运场站", "路面技术状况", "交通执法", "道路运输许可", "安防设施", "渡口渡船", "治超检测", "交通信号灯", "慢行系统", "应急运输保障", "桥梁检测"],
    "IND": ["政策兑现企业", "产业奖补资金", "信息化系统", "云资源", "数据共享接口", "中小企业服务", "技术改造项目", "园区基础设施", "工业互联网平台", "软件正版化", "网络安全测评", "运维工单", "数字化改造", "产业链配套"],
    "COM": ["促消费活动", "参展商户", "消费券核销", "商贸流通项目", "外贸服务", "电商主体", "市场监测", "展会组织", "招商项目", "老字号培育", "夜间经济", "供应链服务"],
    "NAT": ["耕地保护", "国土调查图斑", "造林绿化", "森林抚育", "地质灾害隐患", "气象预警", "测绘成果", "不动产登记", "矿山修复", "湿地保护", "规划编制成果", "自然资源执法", "草原修复", "确权登记"],
    "EMG": ["应急预案", "应急演练", "物资储备", "隐患整改", "消防站点", "监测预警点位", "救援队伍", "安全培训", "救灾资金", "值班值守", "事故处置", "风险普查", "避难场所", "应急通信"],
    "OTH": ["政府投资基金", "专项债项目", "储备粮轮换", "直达资金", "财政贴息", "PPP 项目", "国有资产", "债务监测", "转移支付", "预算调剂", "结余资金", "绩效评价结果应用"],
    "CMN": ["项目任务清单", "预算执行", "资金使用", "采购合同", "验收交付物", "服务对象", "制度文件", "资产台账", "业务台账", "信息报送", "整改事项", "佐证资料"],
}

# 指标句式模板（提炼自公开指标库的高频指标类型）
# (模板, 一级, 二级, 单位, 方向, 适用对象类别, 计算口径模板, 来源类型, 允值建议, 取值方式)
TEMPLATES = [
    ("{o}数量", "产出指标", "数量", "个", "正向", "all", "直接计数：报告期内完成的{o}数量", "PROJECT_DOC", "±3%", "情况统计法"),
    ("{o}完成率", "产出指标", "数量", "%", "正向", "all", "已完成{o}数/计划{o}数×100%", "PROJECT_DOC", "±3个百分点", "情况统计法"),
    ("{o}覆盖率", "效益指标", "社会效益", "%", "正向", "all", "已覆盖{o}数/应覆盖{o}数×100%", "OFFICIAL_STAT", "±2个百分点", "情况统计法"),
    ("{o}达标率", "产出指标", "质量", "%", "正向", "all", "达标{o}数/抽检{o}数×100%", "NATIONAL_STD", "0", "情况统计法"),
    ("{o}合格率", "产出指标", "质量", "%", "正向", "all", "验收合格{o}数/送验{o}数×100%", "NATIONAL_STD", "0", "直接证明法"),
    ("{o}准确率", "产出指标", "质量", "%", "正向", "all", "核对无误{o}数/抽查{o}数×100%", "POLICY_PLAN", "0", "情况统计法"),
    ("{o}及时率", "产出指标", "时效", "%", "正向", "all", "按时完成{o}数/应完成{o}数×100%", "PROJECT_DOC", "0", "情况统计法"),
    ("{o}按期完成率", "产出指标", "时效", "%", "正向", "all", "按期完成{o}数/计划{o}数×100%", "PROJECT_DOC", "±3个百分点", "情况统计法"),
    ("{o}总成本", "成本指标", "经济成本", "万元", "逆向", "all", "直接计数：{o}相关全部分项成本合计", "PROJECT_DOC", "+0/-5%", "情况统计法"),
    ("单位{o}成本", "成本指标", "经济成本", "元每单位", "逆向", "all", "{o}总成本/产出的单位数量", "BUDGET_STD", "+0/-5%", "情况统计法"),
    ("{o}人均成本", "成本指标", "经济成本", "元每人", "逆向", "service", "{o}总成本/受益人数", "BUDGET_STD", "+0/-5%", "情况统计法"),
    ("{o}利用率", "效益指标", "可持续影响", "%", "正向", "facility", "实际使用{o}量/可用{o}量×100%", "HISTORY", "±5个百分点", "情况统计法"),
    ("{o}完好率", "效益指标", "可持续影响", "%", "正向", "facility", "完好{o}数/交付{o}数×100%", "HISTORY", "±2个百分点", "情况统计法"),
    ("{o}增长率", "效益指标", "经济效益", "%", "正向", "all", "(报告期{o}−基线{o})/基线{o}×100%", "OFFICIAL_STAT", "±3个百分点", "情况统计法"),
    ("{o}减少量", "效益指标", "生态效益", "吨", "正向", "env", "基线{o}−报告期{o}（按核定口径）", "OFFICIAL_STAT", "±5%", "趋势判断法"),
    ("{o}受益人数", "效益指标", "社会效益", "人", "正向", "service", "直接计数：因{o}受益的人数（去重口径）", "PROJECT_DOC", "±3%", "情况统计法"),
    ("{o}满意度", "满意度指标", "服务对象满意度", "%", "正向", "service", "满意及非常满意样本/有效样本×100%", "SURVEY", "±2个百分点", "问卷调查法"),
    ("{o}投诉件数", "成本指标", "社会成本", "件", "逆向", "service", "经核实的{o}相关有效投诉件数", "PROJECT_DOC", "0", "情况统计法"),
    ("{o}响应时长", "产出指标", "时效", "小时", "逆向", "all", "接报至完成{o}响应的时长（中位数）", "PUBLIC_SERVICE_STD", "0", "情况统计法"),
    ("{o}验收合格率", "产出指标", "质量", "%", "正向", "all", "一次验收合格{o}数/送验{o}数×100%", "NATIONAL_STD", "0", "直接证明法"),
    ("{o}资金拨付及时率", "产出指标", "时效", "%", "正向", "all", "按时拨付{o}金额/应拨付金额×100%", "POLICY_PLAN", "0", "情况统计法"),
    ("{o}档案归集完整率", "效益指标", "可持续影响", "%", "正向", "all", "已归集{o}档案/应归集档案×100%", "PROJECT_DOC", "±2个百分点", "情况统计法"),
    ("{o}制度建成数", "效益指标", "可持续影响", "项", "正向", "all", "直接计数：围绕{o}新订或修订并印发的制度数", "PROJECT_DOC", "0", "直接证明法"),
    ("{o}复核差错率", "产出指标", "质量", "%", "逆向", "all", "复核发现差错{o}数/抽查{o}数×100%", "POLICY_PLAN", "0", "情况统计法"),
]

FACILITY_WORDS = ("设备", "设施", "系统", "平台", "场馆", "管网", "道路", "桥梁", "校舍",
                  "站点", "仪器", "资产", "台账", "档案", "接口", "点位", "场所", "工具")
SERVICE_WORDS = ("服务", "保障", "救助", "资助", "培训", "活动", "补贴", "对象", "群众",
                 "学生", "患者", "居民", "企业", "商户", "人员", "待遇", "项目", "事项")
ENV_WORDS = ("污染", "减排", "垃圾", "节能", "生态", "碳", "水土", "绿化", "修复", "噪声")

FIELDS = ["id", "name", "level1", "level2", "domain", "domain_name", "project_type",
          "unit", "direction", "sign", "formula_or_definition", "value_source_type",
          "target_value_ref", "tolerance_hint", "valuation_method", "data_source",
          "evidence", "source_level", "source_doc", "source_url", "scope",
          "derived_rule", "note"]

SOURCE_URL = ("https://www.hntongren.gov.cn/html/5671/433343.html"
              "（同仁市财政局关于印发同仁市预算项目绩效指标库的通知，2026-09-01）")

# 低基数长文本列紧凑编码（图例见 assets/corpus_legend.csv，事实来源为 corpus_codes.CODES）
from corpus_codes import encode_cell, write_legend  # noqa: E402

# 二级指标受控词表与层级规范化（公开 PDF 存在合并单元格残留、简称与列错位，须统一）
VALID_L1 = {"成本指标", "产出指标", "效益指标", "满意度指标"}
L2_CANON = {
    "数量": "数量指标", "质量": "质量指标", "时效": "时效指标",
    "经济成本": "经济成本指标", "社会成本": "社会成本指标",
    "生态环境成本": "生态环境成本指标", "成本": "经济成本指标",
    "经济效益": "经济效益指标", "社会效益": "社会效益指标",
    "生态效益": "生态效益指标", "可持续影响": "可持续影响指标",
    "服务对象满意度": "服务对象满意度指标", "满意度": "服务对象满意度指标",
}
VALID_L2 = set(L2_CANON.values())
L2_TO_L1 = {
    "数量指标": "产出指标", "质量指标": "产出指标", "时效指标": "产出指标",
    "经济成本指标": "成本指标", "社会成本指标": "成本指标",
    "生态环境成本指标": "成本指标",
    "经济效益指标": "效益指标", "社会效益指标": "效益指标",
    "生态效益指标": "效益指标", "可持续影响指标": "效益指标",
    "服务对象满意度指标": "满意度指标",
}
DEFAULT_L2 = {"成本指标": "经济成本指标", "产出指标": "数量指标",
              "效益指标": "社会效益指标", "满意度指标": "服务对象满意度指标"}
NOISE_NAMES = {"定性", "定量", "是", "否", "=", "≥", "≤", "XX", "—", "-", "无", "其他"}


def canon_l2(value: str):
    v = (value or "").strip()
    if v in VALID_L2:
        return v
    if v in L2_CANON:
        return L2_CANON[v]
    if v.endswith("指标") and v[:-2] in L2_CANON:
        return L2_CANON[v[:-2]]
    return None


def normalize_levels(l1: str, l2: str):
    c2 = canon_l2(l2)
    if c2:
        return L2_TO_L1[c2], c2, ""
    base = l1 if l1 in VALID_L1 else "产出指标"
    return base, DEFAULT_L2[base], "层级按技能受控词表规范化，须复核"


def classify(name: str, scope: str) -> tuple[str, str]:
    blob = (name + " " + scope)
    hits = [code for code, pattern in DOMAIN_KEYWORDS if re.search(pattern, blob)]
    if not hits:
        return "CMN", "CMN"
    return hits[0], "|".join(hits)


def object_kind(obj: str) -> str:
    if any(w in obj for w in ENV_WORDS):
        return "env"
    if any(w in obj for w in FACILITY_WORDS):
        return "facility"
    if any(w in obj for w in SERVICE_WORDS):
        return "service"
    return "all"


def allowed(template_kind: str, obj_kind: str) -> bool:
    if template_kind == "all":
        return True
    if template_kind == "env":
        return obj_kind == "env"
    if template_kind == "facility":
        return obj_kind in ("facility", "env")
    if template_kind == "service":
        return obj_kind in ("service", "all")
    return True


def load_public() -> list[dict]:
    path = ASSETS / "public_indicators.csv"
    with path.open(encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", type=int, default=10800)
    args = ap.parse_args()

    public = load_public()
    seen = {r["name"] for r in public}
    rows: list[dict] = []
    for i, r in enumerate((x for x in public
                           if x["name"].strip() not in NOISE_NAMES
                           and len(x["name"].strip()) >= 3
                           and re.search(r"[\u4e00-\u9fff]", x["name"])), start=1):
        l1, l2, norm_note = normalize_levels(r["level1"], r["level2"])
        rows.append({
            "id": f"PUB-{i:05d}", "name": r["name"].strip(), "level1": l1,
            "level2": l2, "domain": r["domain"], "domain_name": DOMAINS.get(r["domain"], ""),
            "project_type": "", "unit": r["unit"], "direction": "",
            "sign": r["sign"], "formula_or_definition": r["explanation"],
            "value_source_type": "PUBLIC_INDICATOR_LIBRARY",
            "target_value_ref": encode_cell("target_value_ref", "见公开文件「计划标准/历史标准/参考指标值」栏；示例值须按本级依据替换"),
            "tolerance_hint": encode_cell("tolerance_hint", "按 02_schema_fields.md 第 4 节复核"), "valuation_method": "",
            "data_source": "", "evidence": "", "source_level": "PUBLIC_COLLECTED",
            "source_doc": r["source_doc"], "source_url": encode_cell("source_url", SOURCE_URL), "scope": r["scope"],
            "derived_rule": "",
            "note": encode_cell("note", "公开发布文件逐条抽取；目标值、口径与适用性须按本级文件复核"
                     + ("；" + norm_note if norm_note else "")),
        })

    # 按领域轮转生成派生条目，保证各领域均衡覆盖
    combos: dict[str, list[tuple[str, int, str]]] = defaultdict(list)
    for dom, objs in OBJECTS.items():
        for obj in objs:
            kind = object_kind(obj)
            for ti, tpl in enumerate(TEMPLATES):
                if not allowed(tpl[5], kind):
                    continue
                name = tpl[0].format(o=obj)
                if name in seen:
                    continue
                combos[dom].append((name, ti, obj))

    need = max(0, args.target - len(rows))
    dom_codes = [d for d in OBJECTS if combos[d]]
    derived: list[tuple[str, str, int, str]] = []
    idx = {d: 0 for d in dom_codes}
    public_by_dom = Counter(r["domain"] for r in rows)
    MIN_PER_DOMAIN = 260

    def take(d: str) -> bool:
        while idx[d] < len(combos[d]):
            name, ti, obj = combos[d][idx[d]]
            idx[d] += 1
            if name in seen:
                continue
            seen.add(name)
            derived.append((d, name, ti, obj))
            public_by_dom[d] += 1
            return True
        return False

    # 第一阶段：公开层薄弱领域优先补足到最低配额，保证「涵盖各领域」
    for d in sorted(dom_codes, key=lambda x: public_by_dom[x]):
        while len(derived) < need and public_by_dom[d] < MIN_PER_DOMAIN and take(d):
            pass
    # 第二阶段：按领域轮转补齐总目标
    while len(derived) < need:
        progressed = False
        for d in sorted(dom_codes, key=lambda x: public_by_dom[x]):
            if len(derived) >= need:
                break
            if take(d):
                progressed = True
        if not progressed:
            break

    for j, (dom, name, ti, obj) in enumerate(derived, start=1):
        tpl = TEMPLATES[ti]
        rows.append({
            "id": f"DER-{j:05d}", "name": name, "level1": tpl[1],
            "level2": canon_l2(tpl[2]) or tpl[2],
            "domain": dom, "domain_name": DOMAINS[dom], "project_type": "",
            "unit": tpl[3], "direction": tpl[4],
            "sign": "≥" if tpl[4] == "正向" else "≤",
            "formula_or_definition": tpl[6].format(o=obj),
            "value_source_type": tpl[7],
            "target_value_ref": encode_cell("target_value_ref", "结构化派生候选：无预设目标值，须按本级政策/定额/历史数据/采购实价测算"),
            "tolerance_hint": encode_cell("tolerance_hint", tpl[8]), "valuation_method": tpl[9],
            "data_source": "部门业务统计（具体台账按项目确定）",
            "evidence": "工作资料：业务台账、验收或统计报表",
            "source_level": "STRUCTURED_DERIVED", "source_doc": encode_cell("source_doc", "本技能语料库派生层"),
            "source_url": "", "scope": f"{DOMAINS[dom]} · {obj}",
            "derived_rule": f"TPL-{ti:02d} × OBJ-{obj}",
            "note": encode_cell("note", "非官方指标；仅作检索与编报起点，使用前须核对本级口径、补齐依据并本地化目标值"),
        })

    out = ASSETS / "indicator_corpus.csv"
    with out.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)

    write_legend()

    by_dom = Counter(r["domain"] for r in rows)
    by_level = Counter(r["source_level"] for r in rows)
    by_l1 = Counter(r["level1"] for r in rows)
    print(f"语料库总数：{len(rows)}（公开收录 {by_level['PUBLIC_COLLECTED']}，结构化派生 {by_level['STRUCTURED_DERIVED']}）")
    print("领域分布：" + "，".join(f"{d}={by_dom[d]}" for d in DOMAINS))
    print("一级指标分布：" + "，".join(f"{k}={v}" for k, v in by_l1.items()))
    print(f"已生成 {out}")


if __name__ == "__main__":
    main()
