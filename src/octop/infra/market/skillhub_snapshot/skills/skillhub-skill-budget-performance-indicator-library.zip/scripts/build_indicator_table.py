#!/usr/bin/env python3
"""把结构化指标表生成可直接报送的绩效目标申报表。

用法：
    python build_indicator_table.py <指标表.csv|指标表.json> \
        [--outdir 输出目录] [--formats md,csv,xlsx] [--title 项目名称] [--force]

默认先执行 validate_indicators.py；存在 ERROR 时拒绝出表（--force 可强制）。
输出：
    <项目名>_绩效目标申报表.md    （报送视图 + 取值佐证明细，Markdown）
    <项目名>_绩效目标申报表.csv   （完整 25 字段，utf-8-sig，Excel 可直接打开）
    <项目名>_绩效目标申报表.xlsx  （需 openpyxl，未安装则跳过）
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

from validate_indicators import FIELDS, load_records, validate  # noqa: E402

CN_HEADERS = {
    "id": "指标编号", "level1": "一级指标", "level2": "二级指标",
    "indicator_name": "三级指标", "definition": "指标解释", "formula": "计算公式",
    "unit": "度量单位", "direction": "指标方向", "target_value": "目标值",
    "target_operator": "目标值符号", "value_source_type": "来源类型",
    "value_source_ref": "指标值依据出处", "source_date": "取数时点",
    "tolerance": "允许偏差（允值）", "tolerance_basis": "允值依据",
    "baseline_value": "基线值", "valuation_method": "完成值取值方式",
    "data_source": "完成值数据来源", "evidence": "佐证材料", "weight": "权重",
    "scoring_rule": "赋分规则", "cost_chain": "成本测算链",
    "project_type": "项目类型", "domain": "适用领域", "note": "备注",
}
SOURCE_CN = {
    "POLICY_PLAN": "政策/规划/计划标准", "NATIONAL_STD": "国家/行业/地方标准",
    "PUBLIC_SERVICE_STD": "基本公共服务标准", "BUDGET_STD": "预算支出标准/成本定额",
    "OFFICIAL_STAT": "官方统计/统计年鉴", "HISTORY": "历史标准",
    "BENCHMARK": "标杆/横向对标", "PROJECT_DOC": "项目批复/实施方案/合同",
    "PROCUREMENT": "政府采购成交价/框架协议", "SUPPLIER_QUOTE": "供应商书面报价",
    "MARKET_PRICE": "市场价/造价信息价", "PROFESSIONAL_MEASURE": "专业测算",
    "EXPERT": "专家论证", "SURVEY": "社会调查基线",
    "SOCIAL_RANKING": "社会机构评比/媒体", "OTHER": "其他",
}
LEVEL1_ORDER = ["成本指标", "产出指标", "效益指标", "满意度指标", "预算执行率指标"]
PROJECT_CN = {
    "name": "项目名称", "budget_wan": "年度预算（万元）", "period": "预算期间",
    "domain": "适用领域", "project_type": "项目类型", "disclaimer": "使用声明",
}
NO_SPACE_UNITS = {"%", "个百分点", "分", "‰", "倍"}


def esc(text: str) -> str:
    """转义 Markdown 表格中的竖线与换行。"""
    return str(text).replace("|", "｜").replace("\n", " ").replace("\r", " ")


def target_text(rec: dict) -> str:
    op, val, unit = rec.get("target_operator", ""), rec.get("target_value", ""), rec.get("unit", "")
    sep = "" if unit in NO_SPACE_UNITS else " "
    if op == "区间":
        return f"区间 {val}{sep}{unit}".strip()
    return f"{op}{val}{sep}{unit}".strip()


def source_text(rec: dict) -> str:
    code = rec.get("value_source_type", "")
    cn = SOURCE_CN.get(code, code)
    ref = rec.get("value_source_ref", "")
    date = rec.get("source_date", "")
    return f"{cn}｜{ref}｜{date}".strip("｜")


def table(headers: list[str], rows: list[list[str]]) -> str:
    out = ["| " + " | ".join(headers) + " |",
           "| " + " | ".join(["---"] * len(headers)) + " |"]
    for row in rows:
        out.append("| " + " | ".join(esc(cell) for cell in row) + " |")
    return "\n".join(out)


def build_markdown(records: list[dict], project: dict, title: str) -> str:
    lines = [f"# {title} 绩效目标申报表", ""]
    if project:
        lines += ["## 项目信息", "",
                  table(["项目", "内容"], [[PROJECT_CN.get(k, k), v] for k, v in project.items()]), ""]
    lines += ["> 报送前须核对本级预算管理一体化系统栏位口径；标注「示例值/待本地化」的数值与出处不得直接提交。", ""]

    lines += ["## 一、绩效指标（报送视图）", ""]
    headers = ["一级指标", "二级指标", "三级指标", "指标值", "方向", "权重",
               "指标值设定依据（类型｜出处｜取数时点）", "允许偏差", "允值依据"]
    rows = []
    weights: Counter = Counter()
    grouped: dict[str, list[dict]] = {}
    for rec in records:
        grouped.setdefault(rec.get("level1", ""), []).append(rec)
    for l1 in LEVEL1_ORDER + [k for k in grouped if k not in LEVEL1_ORDER]:
        for rec in grouped.get(l1, []):
            rows.append([
                rec.get("level1", ""), rec.get("level2", ""), rec.get("indicator_name", ""),
                target_text(rec), rec.get("direction", ""), rec.get("weight", ""),
                source_text(rec), rec.get("tolerance", ""), rec.get("tolerance_basis", ""),
            ])
            try:
                weights[rec.get("level1", "")] += float(rec.get("weight", 0))
            except ValueError:
                pass
    lines += [table(headers, rows), ""]
    lines += ["**一级指标权重小计**：" + "；".join(
        f"{k} {v:g}" for k, v in weights.items()) + f"；合计 {sum(weights.values()):g}", ""]

    lines += ["## 二、指标取值与佐证明细", ""]
    headers2 = ["编号", "三级指标", "指标解释", "计算公式", "基线值",
                "取值方式", "数据来源", "佐证材料", "赋分规则", "成本测算链"]
    rows2 = [[rec.get("id", ""), rec.get("indicator_name", ""), rec.get("definition", ""),
              rec.get("formula", ""), rec.get("baseline_value", ""),
              rec.get("valuation_method", ""), rec.get("data_source", ""),
              rec.get("evidence", ""), rec.get("scoring_rule", ""),
              rec.get("cost_chain", "")] for rec in records]
    lines += [table(headers2, rows2), ""]

    lines += ["## 三、编报提示", "",
              "1. 目标值来源、允值依据、成本单价须逐条附上可核验证据（文号、公告号、合同号、报价单、测算表）。",
              "2. 效益指标写明基线、观察期与归因边界；观察性结果只表述为「与…相关」。",
              "3. 绩效运行监控按本表取数时点与允值设预警；自评按赋分规则计分并归集佐证。",
              "4. 编制预算阶段预算执行率指标按本级口径可暂不设置，自评时补入。", ""]
    return "\n".join(lines)


def write_csv(records: list[dict], path: Path) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow([CN_HEADERS[f] for f in FIELDS])
        for rec in records:
            writer.writerow([rec.get(f, "") for f in FIELDS])


def write_xlsx(records: list[dict], path: Path) -> bool:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font
        from openpyxl.utils import get_column_letter
    except ImportError:
        return False
    wb = Workbook()
    ws = wb.active
    ws.title = "绩效目标申报表"
    ws.append([CN_HEADERS[f] for f in FIELDS])
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    for rec in records:
        ws.append([rec.get(f, "") for f in FIELDS])
    widths = {1: 16, 2: 14, 3: 14, 4: 22, 5: 40, 6: 34, 7: 14, 8: 12,
              9: 14, 10: 12, 11: 22, 12: 48, 13: 14, 14: 18, 15: 36,
              16: 14, 17: 18, 18: 32, 19: 32, 20: 10, 21: 36, 22: 46,
              23: 12, 24: 12, 25: 40}
    for col, width in widths.items():
        ws.column_dimensions[get_column_letter(col)].width = width
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.freeze_panes = "E2"
    wb.save(path)
    return True


def main() -> int:
    ap = argparse.ArgumentParser(description="生成预算绩效目标申报表")
    ap.add_argument("input", type=Path, help="指标表 .csv 或 .json")
    ap.add_argument("--outdir", type=Path, default=None, help="输出目录，默认与输入文件同目录")
    ap.add_argument("--formats", default="md,csv", help="输出格式，逗号分隔：md,csv,xlsx")
    ap.add_argument("--title", default=None, help="项目名称，默认取文件/JSON 中的项目名")
    ap.add_argument("--force", action="store_true", help="存在 ERROR 时仍强制出表")
    args = ap.parse_args()

    try:
        records = load_records(args.input)
    except Exception as exc:
        print(f"[ERROR] 读取失败：{exc}", file=sys.stderr)
        return 2

    check = validate(records)
    s = check["summary"]
    print(f"出表前校验：ERROR {s['error']}｜WARN {s['warn']}｜权重合计 {s['weight_sum']}")
    for item in check["issues"]:
        if item["level"] == "ERROR":
            print(f"[ERROR] {item['code']}：{item['message']}")
    if s["error"] and not args.force:
        print("存在 ERROR，已拒绝出表。修正后重试，或显式使用 --force。")
        return 1

    project = {}
    if args.input.suffix.lower() == ".json":
        raw = json.loads(args.input.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            project = raw.get("project", {})
    title = args.title or project.get("name") or args.input.stem
    title = str(title).replace("示例：", "").strip()
    outdir = args.outdir or args.input.parent
    outdir.mkdir(parents=True, exist_ok=True)
    safe = "".join(c for c in title if c not in r'\/:*?"<>|').strip() or "绩效目标"
    stem = f"{safe}_绩效目标申报表"

    formats = {f.strip().lower() for f in args.formats.split(",") if f.strip()}
    made = []
    if "md" in formats:
        p = outdir / f"{stem}.md"
        p.write_text(build_markdown(records, project, title), encoding="utf-8")
        made.append(p)
    if "csv" in formats:
        p = outdir / f"{stem}.csv"
        write_csv(records, p)
        made.append(p)
    if "xlsx" in formats:
        p = outdir / f"{stem}.xlsx"
        if write_xlsx(records, p):
            made.append(p)
        else:
            print("[WARN] 未安装 openpyxl，已跳过 xlsx 输出（md/csv 正常生成）")

    for p in made:
        print(f"已生成：{p}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
