#!/usr/bin/env python3
"""预算绩效指标表校验器。

用法：
    python validate_indicators.py <指标表.csv|指标表.json> [--json] [--strict]

校验内容：必填字段、受控词表、编号唯一、目标值可量化、目标值符号与方向匹配、
来源类型与时效、允值规则、成本测算链、效益量化率、满意度问卷方案、
权重合计、指标条数、来源多样性、赋分与佐证。

退出码：0 = 无 ERROR；1 = 存在 ERROR（--strict 时 WARN 也会导致 1）。
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from collections import Counter
from datetime import date, datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# ---------- 受控词表（与 references/01、02 保持一致） ----------

FIELDS = [
    "id", "level1", "level2", "indicator_name", "definition", "formula",
    "unit", "direction", "target_value", "target_operator",
    "value_source_type", "value_source_ref", "source_date", "tolerance",
    "tolerance_basis", "baseline_value", "valuation_method", "data_source",
    "evidence", "weight", "scoring_rule", "cost_chain", "project_type",
    "domain", "note",
]

REQUIRED = [
    "id", "level1", "level2", "indicator_name", "definition", "formula",
    "unit", "direction", "target_value", "target_operator",
    "value_source_type", "value_source_ref", "source_date", "tolerance",
    "tolerance_basis", "baseline_value", "valuation_method", "data_source",
    "evidence", "weight", "scoring_rule",
]

LEVEL2_MAP = {
    "成本指标": {"经济成本", "社会成本", "生态环境成本"},
    "产出指标": {"数量", "质量", "时效"},
    "效益指标": {"经济效益", "社会效益", "生态效益", "可持续影响"},
    "满意度指标": {"服务对象满意度"},
    "预算执行率指标": {"预算执行率"},
}

SOURCE_TYPES = {
    "POLICY_PLAN", "NATIONAL_STD", "PUBLIC_SERVICE_STD", "BUDGET_STD",
    "OFFICIAL_STAT", "HISTORY", "BENCHMARK", "PROJECT_DOC", "PROCUREMENT",
    "SUPPLIER_QUOTE", "MARKET_PRICE", "PROFESSIONAL_MEASURE", "EXPERT",
    "SURVEY", "SOCIAL_RANKING", "OTHER",
}
WEAK_SOURCES = {"SUPPLIER_QUOTE", "EXPERT", "SOCIAL_RANKING", "OTHER"}
PRICE_SOURCES = {"PROCUREMENT", "SUPPLIER_QUOTE", "MARKET_PRICE", "HISTORY"}

DIRECTIONS = {"正向", "逆向", "区间", "约束"}
OPERATOR_BY_DIRECTION = {
    "正向": {"≥", "=", "区间"},
    "逆向": {"≤", "=", "区间"},
    "区间": {"区间"},
    "约束": {"=", "≥"},
}
VALUATION_METHODS = {
    "直接证明法", "情况统计法", "情况说明法", "问卷调查法", "趋势判断法",
}
DATA_SOURCE_KEYS = [
    "统计部门统计数据", "权威机构调查", "部门统计年鉴", "部门业务统计",
    "部门业务记录", "部门业务评判", "问卷调查报告", "媒体舆论", "其他",
]
EVIDENCE_KEYS = ["正式资料", "工作资料", "原始凭证", "说明材料"]
SCORING_KEYS = ["直接赋分", "按完成比例赋分", "按评判等级赋分", "区间赋分"]

VAGUE_WORDS = [
    "约", "左右", "力争", "显著", "明显", "大幅", "基本实现", "基本完成",
    "若干", "尽量", "尽可能", "逐步", "不断提升", "进一步提高",
    "明显改善", "有效提升", "大幅提升",
]
ID_PATTERN = re.compile(r"^IND-[A-Z0-9]{3}-\d{3}L?$")
DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")
NUMBER_PATTERN = re.compile(r"^-?\d+(?:\.\d+)?$")
RANGE_PATTERN = re.compile(r"^-?\d+(?:\.\d+)?\s*[-~至]\s*-?\d+(?:\.\d+)?$")


def load_records(path: Path) -> list[dict]:
    """读取 CSV 或 JSON 指标表，统一返回字典列表。"""
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path}")
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            records = data.get("indicators", [])
        elif isinstance(data, list):
            records = data
        else:
            raise ValueError("JSON 顶层应为对象（含 indicators）或数组")
    elif path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as fh:
            records = list(csv.DictReader(fh))
    else:
        raise ValueError("仅支持 .csv 与 .json")
    return [{k: ("" if v is None else str(v).strip()) for k, v in rec.items()}
            for rec in records]


def is_quantified(value: str) -> bool:
    return bool(NUMBER_PATTERN.match(value) or RANGE_PATTERN.match(value))


def validate(records: list[dict]) -> dict:
    issues: list[dict] = []

    def add(level: str, idx: int, code: str, message: str) -> None:
        issues.append({"level": level, "row": idx, "code": code, "message": message})

    if not records:
        add("ERROR", 0, "EMPTY", "指标表为空")
        return {"issues": issues, "summary": {}}

    ids = Counter()
    names = Counter()
    source_types: set[str] = set()
    sample_refs = 0
    total_weight = 0.0
    benefit_total = 0
    benefit_quantified = 0
    level1_weight: Counter = Counter()

    for idx, rec in enumerate(records, start=1):
        tag = f"第{idx}条 {rec.get('id') or rec.get('indicator_name') or ''}"

        # 1. 必填
        for key in REQUIRED:
            if not rec.get(key):
                add("ERROR", idx, "MISSING_FIELD", f"{tag} 缺必填字段 `{key}`")

        # 2. 编号与名称唯一
        rid = rec.get("id", "")
        if rid:
            ids[rid] += 1
            if not ID_PATTERN.match(rid):
                add("WARN", idx, "ID_FORMAT", f"{tag} 编号不符合 IND-XXX-NNN(L) 规则")
        name = rec.get("indicator_name", "")
        if name:
            names[name] += 1

        # 3. 一级/二级
        l1, l2 = rec.get("level1", ""), rec.get("level2", "")
        if l1 not in LEVEL2_MAP:
            add("ERROR", idx, "LEVEL1", f"{tag} 一级指标 `{l1}` 不在受控词表")
        elif l2 not in LEVEL2_MAP[l1]:
            add("ERROR", idx, "LEVEL2", f"{tag} 二级指标 `{l2}` 不属于 `{l1}`")

        # 4. 方向与符号
        direction = rec.get("direction", "")
        operator = rec.get("target_operator", "")
        if direction and direction not in DIRECTIONS:
            add("ERROR", idx, "DIRECTION", f"{tag} 指标方向 `{direction}` 非法")
        elif direction and operator and operator not in OPERATOR_BY_DIRECTION[direction]:
            add("ERROR", idx, "OPERATOR",
                f"{tag} 方向 `{direction}` 与目标值符号 `{operator}` 不匹配")

        # 5. 目标值可量化
        tv = rec.get("target_value", "")
        if tv:
            if any(w in tv for w in VAGUE_WORDS):
                add("ERROR", idx, "VAGUE_TARGET", f"{tag} 目标值含模糊表述：`{tv}`")
            elif not is_quantified(tv):
                scoring = rec.get("scoring_rule", "")
                if "按评判等级赋分" not in scoring:
                    add("WARN", idx, "NON_NUMERIC_TARGET",
                        f"{tag} 目标值非数值/区间；定性指标须配「按评判等级赋分」与可判定等级")
        if l1 == "效益指标":
            benefit_total += 1
            if is_quantified(tv):
                benefit_quantified += 1

        # 6. 来源
        st = rec.get("value_source_type", "")
        if st:
            source_types.add(st)
            if st not in SOURCE_TYPES:
                add("ERROR", idx, "SOURCE_TYPE", f"{tag} 来源类型 `{st}` 不在受控词表")
            if st in WEAK_SOURCES and l1 == "成本指标":
                add("WARN", idx, "WEAK_COST_SOURCE",
                    f"{tag} 成本指标使用 C 级来源 `{st}`，须交叉验证或升级为定额/成交价")
        ref = rec.get("value_source_ref", "")
        if "示例值" in ref or "待本地化" in ref:
            sample_refs += 1
        elif ref and ("待补" in ref or len(ref) < 6):
            add("WARN", idx, "SOURCE_REF", f"{tag} 依据出处过于笼统或含占位，须补文号/链接/条款")

        sd = rec.get("source_date", "")
        if sd:
            if not DATE_PATTERN.match(sd):
                add("ERROR", idx, "DATE_FORMAT", f"{tag} source_date 须为 YYYY-MM-DD")
            else:
                try:
                    days = (date.today() - datetime.strptime(sd, "%Y-%m-%d").date()).days
                    if days > 365 and st in PRICE_SOURCES:
                        add("WARN", idx, "STALE_PRICE",
                            f"{tag} 价格类来源距取价日已 {days} 天，须重取或做价格指数修正")
                    if days < -1:
                        add("WARN", idx, "FUTURE_DATE", f"{tag} 取数日期晚于当前日期")
                except ValueError:
                    add("ERROR", idx, "DATE_INVALID", f"{tag} source_date 日期无效")

        # 7. 允值
        tol = rec.get("tolerance", "")
        scoring = rec.get("scoring_rule", "")
        strict_zero = direction == "约束" or "直接赋分" in scoring
        if strict_zero and tol and tol.strip() != "0":
            add("ERROR", idx, "TOLERANCE_ZERO",
                f"{tag} 约束类/直接赋分指标允值必须为 0，当前为 `{tol}`")
        if tol and "百分点" in tol and "%" not in rec.get("unit", ""):
            add("WARN", idx, "TOLERANCE_UNIT", f"{tag} 允值用「百分点」但单位不是百分比")
        if "±" in tol and direction == "逆向":
            add("WARN", idx, "TOLERANCE_DIRECTION",
                f"{tag} 逆向指标设了双向容差，通常应写 `+0/-x%`（只许向好）")

        # 8. 成本测算链
        if l1 == "成本指标":
            chain = rec.get("cost_chain", "")
            if not chain or chain == "-":
                add("ERROR", idx, "COST_CHAIN",
                    f"{tag} 成本指标缺测算链，须填 单价×数量=分项成本 与单价出处")
            elif not any(op in chain for op in ("×", "*", "÷", "/", "+", "=")):
                add("WARN", idx, "COST_CHAIN_WEAK", f"{tag} 测算链未见计算式")

        # 9. 满意度问卷
        if l1 == "满意度指标":
            if rec.get("valuation_method") != "问卷调查法":
                add("ERROR", idx, "SAT_METHOD", f"{tag} 满意度指标取值方式应为「问卷调查法」")
            blob = rec.get("data_source", "") + rec.get("evidence", "")
            if not any(k in blob for k in ("问卷", "调查")):
                add("WARN", idx, "SAT_EVIDENCE", f"{tag} 满意度指标须明确问卷/调查报告与样本量")

        # 10. 取值方式、数据来源、佐证、赋分
        vm = rec.get("valuation_method", "")
        if vm and vm not in VALUATION_METHODS:
            add("ERROR", idx, "VALUATION_METHOD", f"{tag} 取值方式 `{vm}` 不在五法之内")
        ds = rec.get("data_source", "")
        if ds and not any(k in ds for k in DATA_SOURCE_KEYS):
            add("WARN", idx, "DATA_SOURCE", f"{tag} 数据来源未归入九类，须写明台账名称")
        ev = rec.get("evidence", "")
        if ev and not any(k in ev for k in EVIDENCE_KEYS):
            add("WARN", idx, "EVIDENCE", f"{tag} 佐证材料未归入四类，自评时可能无据可依")
        if scoring and not any(k in scoring for k in SCORING_KEYS):
            add("WARN", idx, "SCORING_RULE", f"{tag} 赋分规则未归入四类")
        if "按完成比例赋分" in scoring and "及格" not in scoring and "60%" not in scoring:
            add("WARN", idx, "PASS_THRESHOLD", f"{tag} 按完成比例赋分须写明及格门槛")

        # 11. 权重
        w = rec.get("weight", "")
        try:
            fw = float(w)
            total_weight += fw
            level1_weight[l1] += fw
            if fw <= 0 or fw > 100:
                add("ERROR", idx, "WEIGHT_RANGE", f"{tag} 权重 `{w}` 超出 0–100")
        except (ValueError, TypeError):
            add("ERROR", idx, "WEIGHT_NUMBER", f"{tag} 权重 `{w}` 不是数值")

    for rid, cnt in ids.items():
        if cnt > 1:
            add("ERROR", 0, "DUP_ID", f"编号 `{rid}` 重复 {cnt} 次")
    for nm, cnt in names.items():
        if cnt > 1:
            add("WARN", 0, "DUP_NAME", f"指标名称 `{nm}` 重复 {cnt} 次，须核对是否为不同口径")

    # 项目级检查
    present = {r.get("level1", "") for r in records}
    for need in ("成本指标", "产出指标", "效益指标"):
        if need not in present:
            add("ERROR", 0, "MISSING_LEVEL1", f"缺少一级指标「{need}」")
    if "满意度指标" not in present:
        add("INFO", 0, "NO_SAT", "未设置满意度指标（仅直接面向公众/受益群体的项目必设）")

    if abs(total_weight - 100) > 0.01:
        add("ERROR", 0, "WEIGHT_SUM", f"权重合计 {total_weight:g}，应为 100")

    if not 8 <= len(records) <= 15:
        add("WARN", 0, "COUNT", f"共 {len(records)} 条指标，建议单项目 8–15 条（实践建议）")

    if benefit_total and benefit_quantified / benefit_total < 0.8:
        add("WARN", 0, "BENEFIT_QUANT",
            f"效益指标量化率 {benefit_quantified}/{benefit_total} 低于 80%，须改写为可测变量")

    if len(source_types) < 2:
        add("WARN", 0, "SOURCE_DIVERSITY",
            f"来源类型仅 {len(source_types)} 种，参考类型应多样（政策/标准 + 实证数据 + 成本测算）")

    if sample_refs:
        add("WARN", 0, "SAMPLE_VALUES",
            f"有 {sample_refs} 条依据标注「示例值/待本地化」，正式编报前须替换为本级可核验出处")

    levels = Counter(i["level"] for i in issues)
    score = max(0, 100 - 10 * levels["ERROR"] - 2 * levels["WARN"])
    summary = {
        "rows": len(records),
        "error": levels["ERROR"],
        "warn": levels["WARN"],
        "info": levels["INFO"],
        "score": score,
        "weight_sum": round(total_weight, 2),
        "level1_weight": dict(level1_weight),
        "source_types": sorted(source_types),
        "benefit_quantified": f"{benefit_quantified}/{benefit_total}",
    }
    return {"issues": issues, "summary": summary}


def main() -> int:
    ap = argparse.ArgumentParser(description="预算绩效指标表校验器")
    ap.add_argument("input", type=Path, help="指标表 .csv 或 .json")
    ap.add_argument("--json", action="store_true", help="以 JSON 输出校验结果")
    ap.add_argument("--strict", action="store_true", help="存在 WARN 时也返回非零退出码")
    args = ap.parse_args()

    try:
        records = load_records(args.input)
    except Exception as exc:
        print(f"[ERROR] 读取失败：{exc}", file=sys.stderr)
        return 2

    result = validate(records)

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        s = result["summary"]
        print(f"指标表校验：{args.input}")
        print(f"指标 {s['rows']} 条｜ERROR {s['error']}｜WARN {s['warn']}｜INFO {s['info']}｜质量分 {s['score']}")
        print(f"权重合计 {s['weight_sum']}｜效益量化 {s['benefit_quantified']}｜来源类型 {', '.join(s['source_types'])}")
        if s["level1_weight"]:
            print("一级指标权重：" + "，".join(f"{k} {v:g}" for k, v in s["level1_weight"].items()))
        print("-" * 72)
        for item in result["issues"]:
            loc = f"第{item['row']}条" if item["row"] else "项目级"
            print(f"[{item['level']}] {loc} {item['code']}：{item['message']}")
        if not result["issues"]:
            print("全部检查通过，可生成绩效目标申报表。")

    failed = result["summary"]["error"] > 0 or (args.strict and result["summary"]["warn"] > 0)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
