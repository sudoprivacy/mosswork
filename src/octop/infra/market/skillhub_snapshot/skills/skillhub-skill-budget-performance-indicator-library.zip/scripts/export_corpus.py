#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""语料库定稿导出：修复 TRACE 评测与平台体积限制问题。

1. 去除 UTF-8 BOM（评测器/普通解码器读 utf-8-sig BOM 会把表头首格变成 \\ufeffxx，表现为「乱码」）。
2. 公开收录条目的 direction / valuation_method / data_source / evidence 统一补默认值（诚实标注，不编造）。
3. 低基数长文本列统一转短代码（图例 assets/corpus_legend.csv，事实来源 corpus_codes.CODES）。
4. 语料库只以 16 个分领域小 CSV 存储（不再保留主文件：既避免 7.9MB 大文件被截断读取，
   又让包内容积满足平台 10MB 解压上限）。每个文件几百到两千余行，可整文件读入。
5. 生成 corpus_README.md 与 corpus_manifest.json（行数、SHA256、编码说明），规模可机器核验。
"""
from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from corpus_codes import encode_row, write_legend  # noqa: E402

MASTER = ROOT / "assets" / "indicator_corpus.csv"
OUT_DIR = ROOT / "assets" / "corpus_by_domain"

DEFAULTS = {
    "valuation_method": "完成值按公开文件口径取自部门填报数据与佐证材料；使用前须按本级取数规则复核",
    "data_source": "本级预算管理一体化系统／部门业务台账（公开条目未指定，须本地化确认）",
    "evidence": "见 source_doc 所列公开文件及本级佐证材料要求",
}


def direction_for(rec: dict) -> str:
    if rec.get("sign") == "≤":
        return "逆向"
    if rec.get("sign") == "≥":
        return "正向"
    return "逆向" if rec["level1"] == "成本指标" else "正向"


def main() -> int:
    if MASTER.exists():
        with MASTER.open(encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            header = list(reader.fieldnames or [])
            rows = list(reader)
        src = "主文件"
    else:
        rows, header = [], None
        for f in sorted(OUT_DIR.glob("corpus_*.csv")):
            with f.open(encoding="utf-8-sig", newline="") as fh:
                reader = csv.DictReader(fh)
                header = header or list(reader.fieldnames or [])
                rows.extend(reader)
        src = "分领域文件"
    n_cols = len(header)
    print(f"从{src}读取：{len(rows)} 条 × {n_cols} 列")

    filled = Counter()
    for r in rows:
        if not (r.get("direction") or "").strip():
            r["direction"] = direction_for(r)
            filled["direction"] += 1
        for col, val in DEFAULTS.items():
            if not (r.get(col) or "").strip():
                r[col] = val if r["source_level"] == "PUBLIC_COLLECTED" else val + "（派生候选，须本地化后确认）"
                filled[col] += 1
        if not (r.get("unit") or "").strip():
            r["unit"] = "待定（须按本级口径确认）"
            filled["unit"] += 1
    print("默认值补齐：", dict(filled))

    # 长文本列转短代码（未登记的长文本会在此报错，防止写出口径外内容）
    rows = [encode_row(r) for r in rows]
    write_legend()
    print("长文本列已编码，图例已写回 assets/corpus_legend.csv")

    # 写分领域文件（UTF-8 无 BOM，RFC 4180 CRLF）；直接覆盖同名文件，沙箱内不依赖删除操作
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    manifest = {
        "total_rows": len(rows),
        "columns": n_cols,
        "encoding": "UTF-8 (no BOM), RFC 4180, CRLF",
        "storage": "仅按领域存储于 assets/corpus_by_domain/（无主文件，避免大文件截断与解压体积超限）",
        "coded_fields": "source_url/note/target_value_ref/source_doc/tolerance_hint/valuation_method/data_source/evidence 存短代码，完整文本见 assets/corpus_legend.csv",
        "files": [],
    }
    by_dom = {}
    for r in rows:
        by_dom.setdefault(r["domain"], []).append(r)
    for dom in sorted(by_dom):
        recs = by_dom[dom]
        fname = f"corpus_{dom}.csv"
        fpath = OUT_DIR / fname
        with fpath.open("w", encoding="utf-8", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=header, lineterminator="\r\n")
            w.writeheader()
            w.writerows(recs)
        data = fpath.read_bytes()
        manifest["files"].append({
            "file": f"assets/corpus_by_domain/{fname}",
            "domain": dom,
            "domain_name": recs[0].get("domain_name", ""),
            "rows": len(recs),
            "sha256": hashlib.sha256(data).hexdigest(),
        })
    total_check = sum(f["rows"] for f in manifest["files"])
    assert total_check == len(rows), f"拆分行数不一致 {total_check} != {len(rows)}"
    if MASTER.exists():
        try:
            MASTER.unlink()
            print("已删除主文件（分领域文件为唯一存储）")
        except OSError:
            print("警告：主文件删除被环境拦截，请手动删除 assets/indicator_corpus.csv（分领域文件为唯一存储）")

    (OUT_DIR / "corpus_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"已拆分 {len(manifest['files'])} 个领域文件，合计 {total_check} 条（校验一致）")

    lines = [
        "# 语料库分领域文件说明",
        "",
        f"- 总条目 **{len(rows)}** 条 × **{n_cols}** 列，按领域分文件存储，逐文件可整读，合计即全量。",
        "- **编码：UTF-8（无 BOM）**，RFC 4180，CRLF 行尾。Excel 直接双击打开中文可能乱码，请用「数据 → 从文本导入」选 UTF-8；程序读取用 `encoding='utf-8'`（`utf-8-sig` 亦兼容）。",
        "- **短代码列**：source_url／note／target_value_ref／source_doc／tolerance_hint／valuation_method／data_source／evidence 存短代码（如 V1、D3），完整文本见 `assets/corpus_legend.csv`；`scripts/search_indicators.py` 会自动解码展示。",
        "- 每个文件 `corpus_<领域码>.csv` 只含一个领域，行数与 SHA256 见 `corpus_manifest.json`，合计必须等于总条目数（脚本已断言校验）。",
        "- 公开收录（PUBLIC_COLLECTED）条目的 direction／valuation_method／data_source／evidence 为**统一默认值**（诚实标注、非编造），本地化时须替换为本级口径；派生（STRUCTURED_DERIVED）条目为按业务属性预填的取值方式。",
        "",
        "| 文件 | 领域 | 领域名称 | 行数 |",
        "|---|---|---|---|",
    ]
    for f in manifest["files"]:
        lines.append(f"| {Path(f['file']).name} | {f['domain']} | {f['domain_name']} | {f['rows']} |")
    lines.append(f"| **合计** | {len(manifest['files'])} 个领域 |  | **{total_check}** |")
    (OUT_DIR / "corpus_README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("README 已生成")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
