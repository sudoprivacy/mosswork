#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""语料库低基数长文本列的紧凑编码（code ↔ value）。

背景：语料库中若干列（来源 URL、提示语、依据文件名等）在数千行里整段重复，
未压缩总体积超过上传上限。本模块把这些列改存短代码，完整文本集中在
assets/corpus_legend.csv（field,code,value）图例表中，一行一条不丢信息。

使用：
  from corpus_codes import encode_cell, decode_cell, load_legend, write_legend
纯标准库。CODES 是唯一事实来源；新增长文本值必须在此登记后才能写入语料库。
"""
from __future__ import annotations

import csv
from pathlib import Path

ASSETS = Path(__file__).resolve().parents[1] / "assets"
LEGEND = ASSETS / "corpus_legend.csv"

# 公开收录唯一来源 URL（含出处说明）
SOURCE_URL = ("https://www.hntongren.gov.cn/html/5671/433343.html"
              "（同仁市财政局关于印发同仁市预算项目绩效指标库的通知，2026-09-01）")

CODES: dict[str, dict[str, str]] = {
    "source_url": {
        "U1": SOURCE_URL,
    },
    "note": {
        "N1": "公开发布文件逐条抽取；目标值、口径与适用性须按本级文件复核",
        "N2": "非官方指标；仅作检索与编报起点，使用前须核对本级口径、补齐依据并本地化目标值",
        "N3": "公开发布文件逐条抽取；目标值、口径与适用性须按本级文件复核；层级按技能受控词表规范化，须复核",
    },
    "target_value_ref": {
        "V1": "见公开文件「计划标准/历史标准/参考指标值」栏；示例值须按本级依据替换",
        "V2": "结构化派生候选：无预设目标值，须按本级政策/定额/历史数据/采购实价测算",
    },
    "source_doc": {
        "D1": "共性项目绩效指标库（试行）",
        "D2": "分行业分领域绩效指标库（试行）",
        "D3": "分部门项目支出绩效指标库（试行）",
        "D4": "中央直达资金项目绩效指标库（部分）",
        "D5": "本技能语料库派生层",
    },
    "tolerance_hint": {
        "T1": "按 02_schema_fields.md 第 4 节复核",
    },
    "valuation_method": {
        "M1": "完成值按公开文件口径取自部门填报数据与佐证材料；使用前须按本级取数规则复核",
        "M2": "情况统计法",
        "M3": "直接证明法",
        "M4": "趋势判断法",
        "M5": "问卷调查法",
    },
    "data_source": {
        "S1": "本级预算管理一体化系统／部门业务台账（公开条目未指定，须本地化确认）",
        "S2": "部门业务统计（具体台账按项目确定）",
    },
    "evidence": {
        "E1": "工作资料：业务台账、验收或统计报表",
        "E2": "见 source_doc 所列公开文件及本级佐证材料要求",
    },
}

# 逐列生成 code→value 与 value→code 视图
_CODE2VAL = {f: dict(m) for f, m in CODES.items()}
_VAL2CODE = {f: {v: k for k, v in m.items()} for f, m in CODES.items()}


def encode_cell(field: str, value: str) -> str:
    """长文本转短代码；短值原样保留；未登记的长文本直接报错，防止写出口径外内容。"""
    if not value:
        return ""
    rev = _VAL2CODE.get(field)
    if rev is None:
        return value
    if value in rev:
        return rev[value]
    if len(value) <= 12:  # 短值（如 0、±2个百分点）不值得编码
        return value
    raise ValueError(f"字段 {field} 出现未登记的长文本值，请先在 corpus_codes.CODES 登记：{value!r}")


def decode_cell(field: str, value: str) -> str:
    if not value:
        return ""
    m = _CODE2VAL.get(field)
    return m.get(value, value) if m else value


def load_legend() -> dict[str, dict[str, str]]:
    """从图例表加载 code→value 映射（检索脚本运行时用，与 CODES 解耦）。"""
    if not LEGEND.exists():
        return {f: dict(m) for f, m in CODES.items()}
    out: dict[str, dict[str, str]] = {}
    with LEGEND.open(encoding="utf-8-sig", newline="") as fh:
        for row in csv.DictReader(fh):
            out.setdefault(row["field"], {})[row["code"]] = row["value"]
    return out


def write_legend() -> None:
    with LEGEND.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["field", "code", "value"])
        for field, mapping in CODES.items():
            for code, value in sorted(mapping.items()):
                w.writerow([field, code, value])


def encode_row(row: dict, fields: tuple[str, ...] = ("source_url", "note",
                 "target_value_ref", "source_doc", "tolerance_hint",
                 "valuation_method", "data_source", "evidence")) -> dict:
    return {k: (encode_cell(k, v) if k in fields else v) for k, v in row.items()}


def decode_row(row: dict, legend: dict[str, dict[str, str]]) -> dict:
    return {k: (legend.get(k, {}).get(v, v) if v else v) for k, v in row.items()}
