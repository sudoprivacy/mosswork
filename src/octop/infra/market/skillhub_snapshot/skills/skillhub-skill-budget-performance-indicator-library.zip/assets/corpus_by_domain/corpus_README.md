# 语料库分领域文件说明

- 总条目 **10800** 条 × **23** 列，按领域分文件存储，逐文件可整读，合计即全量。
- **编码：UTF-8（无 BOM）**，RFC 4180，CRLF 行尾。Excel 直接双击打开中文可能乱码，请用「数据 → 从文本导入」选 UTF-8；程序读取用 `encoding='utf-8'`（`utf-8-sig` 亦兼容）。
- **短代码列**：source_url／note／target_value_ref／source_doc／tolerance_hint／valuation_method／data_source／evidence 存短代码（如 V1、D3），完整文本见 `assets/corpus_legend.csv`；`scripts/search_indicators.py` 会自动解码展示。
- 每个文件 `corpus_<领域码>.csv` 只含一个领域，行数与 SHA256 见 `corpus_manifest.json`，合计必须等于总条目数（脚本已断言校验）。
- 公开收录（PUBLIC_COLLECTED）条目的 direction／valuation_method／data_source／evidence 为**统一默认值**（诚实标注、非编造），本地化时须替换为本级口径；派生（STRUCTURED_DERIVED）条目为按业务属性预填的取值方式。

| 文件 | 领域 | 领域名称 | 行数 |
|---|---|---|---|
| corpus_AGR.csv | AGR | 农林水 | 573 |
| corpus_CMN.csv | CMN | 共性（所有项目） | 2227 |
| corpus_COM.csv | COM | 商业服务业与消费促进 | 327 |
| corpus_CUL.csv | CUL | 文化旅游体育与传媒 | 637 |
| corpus_EDU.csv | EDU | 教育 | 418 |
| corpus_EMG.csv | EMG | 应急管理与公共安全 | 408 |
| corpus_ENV.csv | ENV | 节能环保 | 442 |
| corpus_GPS.csv | GPS | 一般公共服务与政务运行 | 1002 |
| corpus_HEA.csv | HEA | 卫生健康 | 1045 |
| corpus_IND.csv | IND | 产业与信息化 | 662 |
| corpus_NAT.csv | NAT | 自然资源与林草气象 | 327 |
| corpus_OTH.csv | OTH | 储备债务基金与其他 | 322 |
| corpus_SCI.csv | SCI | 科学技术 | 327 |
| corpus_SOC.csv | SOC | 社会保障和就业 | 1166 |
| corpus_TRA.csv | TRA | 交通运输 | 571 |
| corpus_URB.csv | URB | 城乡社区与住房保障 | 346 |
| **合计** | 16 个领域 |  | **10800** |
