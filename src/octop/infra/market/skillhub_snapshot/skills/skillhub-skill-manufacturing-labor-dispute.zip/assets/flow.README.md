flow.md 文件说明

=== 节点图例 ===
- 圆角矩形（stadium）= 入口/出口
- 矩形 = 处理节点
- 菱形 = 决策点
- 红色填充 = 常见风险点

=== 渲染方法 ===
- Mermaid 在线编辑器：https://mermaid.live/
- VS Code：安装 "Markdown Preview Mermaid Support" 插件
- Markdown 中以 ```mermaid 代码块嵌入
- 在 WorkBuddy 中用 show_widget 也可以渲染（需加载 mermaid CDN）

=== 注意事项 ===
- 修改本流程图只需编辑 flow.md，所有引用此文件的位置保持一致
- 节点 ID 规则：分支 A（工伤）= A*；分支 B（违法解除）= B*，BR*；分支 C（工资）= C*，CR*
- 含 <br/> 或特殊字符的标签必须用双引号包裹
- 风险节点标签用虚线箭头 ".-.->" 与上游节点连接

=== 已知兼容问题 ===
- mermaid.ink 在线服务对含 %% 注释的版本解析异常，本文件已删除所有内联注释
- 如需添加注释，请使用 %{ ... }% 块注释（部分版本支持），或在末尾用单独 .md 文件说明
