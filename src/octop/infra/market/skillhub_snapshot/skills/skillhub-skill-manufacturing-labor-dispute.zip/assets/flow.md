flowchart TD
    Start(["常见员工诉求的调查与<br/>收集证据要点"]):::startNode

    Start --> A1["发放工伤待遇"]
    Start --> B1["主动要求解除"]
    Start --> C1["劳动报酬未足额发放"]

    A1 --> A2{"是否缴纳 / 足额<br/>缴纳工伤保险"}:::decision

    A2 -- "已足额缴纳" --> A3["公司仅支付：停工留薪期待遇、<br/>一次性伤残就业补助金等<br/>仅需公司承担的部分"]
    A2 -- "未缴纳 / 未足额缴纳" --> A4["未缴纳：公司承担社保承担部分<br/>未足额缴纳：公司补足差额"]

    A3 --> A5(["评估工伤待遇<br/>是否完整支付"]):::endNode

    B1 --> B2["解除劳动关系相关"]
    B2 --> B3["主张公司违法解除，<br/>索要经济赔偿金（2N）"]
    B3 --> B4["此时为公司主动解除，<br/>关注公司处罚事由<br/>是否符合法律规定<br/>与公司制度"]

    B4 -.-> BR1["常见风险1：<br/>未足额支付工资"]:::risk
    B4 -.-> BR2["常见风险2：<br/>公司违法调岗，安排员工做<br/>与岗位职责不一致的工作，<br/>此风险普遍存在"]:::risk
    B4 -.-> BR3["常见风险3：<br/>公司普遍存在超时加班，<br/>部分地区将成为被迫解除事由，<br/>公司未留存员工主动加班的证据"]:::risk

    C1 --> CR1["常见风险1：<br/>年终奖、异地支援补贴等未发放：<br/>相应规章制度未公示与让员工签收，<br/>将被认为是正常工资的一部分"]:::risk
    C1 --> CR2["常见风险2：<br/>公司违法调岗，安排员工做<br/>与岗位职责不一致的工作，<br/>此风险普遍存在"]:::risk
    C1 --> CR3["常见风险3：<br/>不胜任解除，<br/>不胜任所依据的考核缺乏客观标准，<br/>主要取决于考评人主观判断"]:::risk

    classDef startNode fill:#ffeaa7,stroke:#fdcb6e,stroke-width:2px,color:#2d3436
    classDef endNode   fill:#55efc4,stroke:#00b894,stroke-width:2px,color:#2d3436
    classDef decision  fill:#fab1a0,stroke:#e17055,stroke-width:2px,color:#2d3436
    classDef risk      fill:#ff7675,stroke:#d63031,stroke-width:1px,color:#ffffff
