/*
 * verify_static.js — 工作台铁律静态检查器（通用，对任意 workbench HTML 可用）
 * 用法: node verify_static.js <path-to-html>
 * 检查不依赖 DOM 渲染的硬性铁律：内联/零外链/SVG/移动适配/wb_前缀/关键文案。
 */
var fs = require("fs");
var path = require("path");

function loadHtml(p){
  if(!fs.existsSync(p)){ console.error("文件不存在:", p); process.exit(2); }
  return fs.readFileSync(p, "utf-8");
}

function check(html, name){
  var R = {};
  // 铁律3: 全内联零外链
  R.L3_noScriptSrc = !/<script[^>]+src=/.test(html);
  R.L3_noLinkCss   = !/<link[^>]+stylesheet/i.test(html);
  R.L3_noHttpExternal = !/https?:\/\//.test(html);
  R.L3_hasInlineSvg = /<svg/.test(html);
  // 铁律4: 移动适配
  R.L4_mediaQuery = /@media\s*\([^)]*max-width/.test(html) || /@media\s*\([^)]*max-width/.test(html);
  R.L4_btn44 = /min-height:\s*44px/.test(html) || /min-height:44px/.test(html);
  R.L4_input16 = /font-size:\s*16px/.test(html) || /font-size:16px/.test(html) || /font-size: 16px/.test(html);
  R.L4_safeArea = /safe-area-inset-bottom/.test(html);
  R.L4_viewportCover = /viewport-fit=cover/.test(html);
  // 铁律1: localStorage wb_ 前缀
  R.L1_wbPrefix = /wb_/.test(html);
  // 铁律2: 关键按钮文案
  R.L2_export = /导出\s*JSON|导出JSON/.test(html);
  R.L2_import = /导入恢复|导入/.test(html);
  R.L2_clearConfirm = /confirm\(/.test(html);
  R.L2_30tip = /30/.test(html);
  R.L2_csv = /导出\s*CSV|导出CSV/.test(html);
  // 铁律5: 今天要处理
  R.L5_today = /今天要处理/.test(html);
  // 铁律6: 清空示例
  R.L6_clearSeed = /清空示例/.test(html);

  return R;
}

function report(name, R){
  console.log("\n=== 静态铁律检查: " + name + " ===");
  var keys = Object.keys(R);
  var pass = 0;
  keys.forEach(function(k){
    var ok = R[k];
    console.log((ok ? "  ✅ " : "  ❌ ") + k);
    if(ok) pass++;
  });
  console.log("  通过 " + pass + "/" + keys.length);
  return pass === keys.length;
}

if(require.main === module){
  var p = process.argv[2];
  if(!p){ console.error("用法: node verify_static.js <html路径>"); process.exit(2); }
  var html = loadHtml(p);
  var R = check(html, path.basename(p));
  var ok = report(path.basename(p), R);
  process.exit(ok ? 0 : 1);
}

module.exports = { check: check, report: report };
