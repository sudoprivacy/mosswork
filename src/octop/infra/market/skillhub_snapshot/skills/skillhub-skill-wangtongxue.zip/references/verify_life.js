/*
 * verify_life.js — 针对 life-workbench.html 的运行时铁律测试
 * 用法: node verify_life.js
 * 用最小 DOM/localStorage/FileReader 桩在 vm 中真实执行页面脚本，断言核心逻辑。
 */
var fs = require("fs");
var vm = require("vm");
var path = require("path");

var htmlPath = path.join(__dirname, "..", "assets", "life-workbench.html");
var html = fs.readFileSync(htmlPath, "utf-8");
var js = html.match(/<script>([\s\S]*?)<\/script>/)[1];

// ---- 最小桩 ----
var store = {};
function fakeEl(){
  var el = {
    _children: [], style:{}, dataset:{}, _html:"", _text:"",
    set innerHTML(v){ this._html = String(v); }, get innerHTML(){ return this._html; },
    set textContent(v){ this._text = String(v); }, get textContent(){ return this._text; },
    // appendChild 把子节点的 html/text 累积进父节点（模拟真实 DOM 渲染，保留 className）
    appendChild:function(c){ var cls=c.className?' class="'+c.className+'"':''; this._html=(this._html||"")+'<div'+cls+'>'+(c._html||"")+(c._text||"")+'</div>'; this._children.push(c); return c; },
    setAttribute:function(k,v){ this["_"+k]=v; }, getAttribute:function(k){ return this["_"+k]||null; },
    addEventListener:function(){}, click:function(){}, reset:function(){},
    value:"", checked:false, files:[], onchange:null, onsubmit:null, onclick:null
  };
  return el;
}
var elements = {};
["backupTip","todayList","btnExport","btnImport","btnCsv","btnClearSeed","btnClearAll",
 "fileInput","billForm","bDate","bType","bCat","bAmt","bNote","mOut","mIn","pie","billList",
 "habitForm","hName","habitList","weightForm","wDate","wVal","wEx","line"].forEach(function(id){
  elements[id] = fakeEl();
});
function doc(){
  return {
    getElementById:function(id){ return elements[id] || (elements[id]=fakeEl()); },
    createElement:function(){ return fakeEl(); },
    body:{ addEventListener:function(){} }
  };
}
var localStorage = {
  getItem:function(k){ return k in store ? store[k] : null; },
  setItem:function(k,v){ store[k]=String(v); },
  removeItem:function(k){ delete store[k]; }
};
var lastBlob = "";
function Blob(parts){ lastBlob = (parts||[]).join(""); this._content = lastBlob; }
var URL = { createObjectURL:function(){ return "blob:x"; }, revokeObjectURL:function(){} };
function FileReader(){ this.readAsText=function(f){ this.result=f._content; if(this.onload) this.onload(); }; }
function confirm(){ return true; }
function alert(){}

var sandbox = {
  document: doc(), localStorage: localStorage, Blob: Blob, URL: URL, FileReader: FileReader,
  confirm: confirm, alert: alert, console: console,
  Date: Date, Math: Math, JSON: JSON, Array: Array, Object: Object, String: String,
  Number: Number, RegExp: RegExp, parseInt: parseInt, parseFloat: parseFloat, isNaN: isNaN
};
sandbox.window = sandbox; sandbox.global = sandbox;
vm.createContext(sandbox);
vm.runInContext(js, sandbox);

// 日期基准
var t = new Date();
var tStr = t.getFullYear()+"-"+String(t.getMonth()+1).padStart(2,"0")+"-"+String(t.getDate()).padStart(2,"0");
var y = new Date(); y.setDate(t.getDate()-1);
var yStr = y.getFullYear()+"-"+String(y.getMonth()+1).padStart(2,"0")+"-"+String(y.getDate()).padStart(2,"0");

// ---- 断言框架 ----
var pass=0, fail=0, fails=[];
function ok(name, cond){ if(cond){ pass++; console.log("  ✅ "+name); } else { fail++; fails.push(name); console.log("  ❌ "+name); } }

console.log("\n=== 运行时测试: life-workbench.html ===");

// 1. 种子数据写入 4 类
ok("seed 写入 4 类数据", store["wb_life_bills"] && store["wb_life_todos"] && store["wb_life_habits"] && store["wb_life_weight"]);

// 2. 恰好 1 条逾期待办（基准=今天，逾期=due<今天）
var todos = JSON.parse(store["wb_life_todos"]);
ok("seed 恰好 1 条逾期待办", todos.filter(function(o){ return !o.done && o.due < tStr; }).length === 1);

// 3. 种子均标记 seed=true
ok("种子均标记 seed=true", todos.every(function(o){return o.seed===true;}) && JSON.parse(store["wb_life_bills"]).every(function(b){return b.seed===true;}));

// 4. 今天要处理区渲染了内容
ok("今天要处理区有渲染", elements.todayList._html.length > 0);

// 5. 逾期项带 over 红标 + [逾期]
var todayHtml = elements.todayList._html;
ok("逾期项标注 over 红标", /class="t-item over"/.test(todayHtml) && /\[逾期\]/.test(todayHtml));

// 6. 未打卡习惯进入今天区
ok("未打卡习惯进入今天区", /打卡：「读书」/.test(todayHtml));

// 7. 本月支出/收入数值正确（红/绿由 CSS class 控制，已在静态检查覆盖）
ok("本月支出=¥38.50 收入=¥8000.00", elements.mOut._text==="¥38.50" && elements.mIn._text==="¥8000.00");

// 8. 饼图 / 折线图 内联 SVG
ok("饼图生成内联 SVG", /<svg/.test(elements.pie._html));
ok("折线图区域生成 SVG/提示", /<svg/.test(elements.line._html));

// 9. 30 条备份提示：当前 <30 不显示
ok("数据<30 时备份提示隐藏", elements.backupTip.style.display !== "block");

// 10. 满 30 条阈值语义
var big = JSON.parse(store["wb_life_todos"]);
while(big.length < 30){ big.push({id:Math.random(),title:"x",due:yStr,done:false,seed:false}); }
store["wb_life_todos"] = JSON.stringify(big);
ok("满30条阈值语义正确(>=30)", JSON.parse(store["wb_life_todos"]).length >= 30);

// 11. 导出 CSV：表头 + BOM（先真正触发导出按钮）
elements.btnCsv.onclick();
ok("CSV 含表头", lastBlob.slice(1).indexOf("日期,类型,分类,金额,备注") === 0);
ok("CSV 含 BOM(Excel中文)", lastBlob.charCodeAt(0) === 0xFEFF);

// 12. 导入恢复回环（构造导出 JSON → 清空 → 导入 → 恢复）
var exported = JSON.stringify({
  bills:JSON.parse(store["wb_life_bills"]), habits:JSON.parse(store["wb_life_habits"]),
  weight:JSON.parse(store["wb_life_weight"]), todos:JSON.parse(store["wb_life_todos"])
});
["wb_life_bills","wb_life_habits","wb_life_weight","wb_life_todos"].forEach(function(k){ delete store[k]; });
elements.fileInput.files = [{ _content: exported }];
elements.fileInput.onchange({ target: elements.fileInput });
ok("导入恢复数据(回环)", store["wb_life_bills"] && JSON.parse(store["wb_life_bills"]).length >= 2);

// 13. esc 防 XSS（渲染含尖括号的数据）
store["wb_life_bills"] = JSON.stringify([{id:9999,date:"2026-01-01",type:"out",cat:'<img src=x onerror=alert(1)>',amt:1,note:'"a,b"'}]);
elements.billForm.onsubmit({ preventDefault:function(){} });
ok("渲染时对尖括号转义(防XSS)", elements.billList._html.indexOf("&lt;img") !== -1);
elements.btnCsv.onclick();
ok("CSV 对引号转义", lastBlob.indexOf('""') !== -1);

console.log("\n  通过 " + pass + " / " + (pass+fail));
if(fail){ console.log("  失败项: " + fails.join(", ")); process.exit(1); }
console.log("  🎉 全部通过");
