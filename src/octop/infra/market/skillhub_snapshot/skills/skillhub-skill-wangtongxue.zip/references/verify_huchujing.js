// 针对 hu-chujing-workbench.html (8 模块导航版) 的运行时铁律测试
// 用最小 DOM / localStorage / Blob / FileReader 桩，在 vm 沙箱中真实执行页面脚本并断言关键逻辑。
const fs = require("fs");
const vm = require("vm");
const path = require("path");

const htmlPath = path.join(__dirname, "..", "assets", "hu-chujing-workbench.html");
const html = fs.readFileSync(htmlPath, "utf8");
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (!m) { console.error("找不到 <script> 块"); process.exit(1); }
const code = m[1];

// ---- 最小 DOM 桩 ----
const store = {};
function fakeEl(id) {
  return {
    id: id || "", _html: "", value: "", textContent: "", checked: false,
    className: "", style: {}, _children: [],
    set innerHTML(v) { this._html = v; }, get innerHTML() { return this._html; },
    appendChild(c) { this._html += (c && (c._html || c.textContent || "")); this._children.push(c); return c; },
    querySelectorAll() { return []; },
    getAttribute(k) { return this["_attr_" + k] || ""; },
    setAttribute(k, v) { this["_attr_" + k] = v; },
    click() {}, reset() {}, addEventListener() {}, removeChild() {},
    focus() {}, onsubmit: null, onclick: null, onchange: null
  };
}
const elements = {};
const document = {
  getElementById(id) { if (!elements[id]) elements[id] = fakeEl(id); return elements[id]; },
  createElement() { return fakeEl(""); },
  querySelectorAll() { return []; },
  addEventListener() {},
  body: { appendChild() {}, removeChild() {} }
};
const localStorage = {
  getItem(k) { return k in store ? store[k] : null; },
  setItem(k, v) { store[k] = String(v); },
  removeItem(k) { delete store[k]; }
};
let lastBlob = "";
function Blob(parts) { lastBlob = (parts || []).join(""); }
const URL = { createObjectURL() { return "blob:x"; }, revokeObjectURL() {} };
function FileReader() {}
FileReader.prototype.readAsText = function (f) { this.result = f && f._content; if (this.onload) this.onload(); };
function alert() {} function confirm() { return true; }

const sandbox = {
  document, localStorage, Blob, URL, FileReader, alert, confirm,
  console, Date, Math, JSON, Array, Object, String, Number, RegExp,
  parseInt, parseFloat, isNaN
};
sandbox.global = sandbox;
vm.createContext(sandbox);

let pass = 0, fail = 0;
function ok(name, cond) {
  if (cond) { pass++; console.log("  PASS  " + name); }
  else { fail++; console.log("  FAIL  " + name); }
}

vm.runInContext(code, sandbox);
const WB = sandbox.WB;

// ===== 1. 种子数据：恰好 1 条逾期 =====
(function () {
  function todayISO() { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  const realOverdue = WB.state.todos.filter(function (o) { return !o.done && o.due < todayISO(); }).length;
  ok("种子恰好 1 条逾期待办", realOverdue === 1);
  ok("种子含已完成项(演示划线)", WB.state.todos.some(function (o) { return o.done; }));
  ok("种子均标记 seed=true", WB.state.todos.concat(WB.state.notes, WB.state.projects, WB.state.jobs, WB.state.english, WB.state.invest, WB.state.hobbies).every(function (x) { return x.seed === true; }));
})();

// ===== 2. 今天要处理：聚合 + 逾期红标 =====
(function () {
  WB.renderToday();
  const h = document.getElementById("todayBox")._html;
  ok("今天区含逾期徽章[逾期]", h.indexOf("逾期") !== -1);
  ok("今天区含项目跟进提醒", h.indexOf("项目进行中") !== -1);
  ok("今天区含学英语提醒(今天未学)", h.indexOf("今天还没学英语") !== -1);
  ok("今天区含每日兴趣打卡提醒", h.indexOf("每日打卡待办") !== -1);
  // 逾期项带 over 样式
  ok("逾期项带红标 class=over", /class="t-item over"/.test(h));
})();

// ===== 3. 各模块 CRUD =====
(function () {
  const before = WB.state.jobs.length;
  document.getElementById("jobCompany").value = "测试公司";
  document.getElementById("jobPosition").value = "测试岗";
  document.getElementById("jobStatus").value = "已投";
  WB.addJob();
  ok("找工作 新增生效", WB.state.jobs.length === before + 1);

  const eb = WB.state.english.length;
  document.getElementById("englishType").value = "口语";
  document.getElementById("englishDuration").value = "10";
  WB.addEnglish();
  ok("学英语 新增生效", WB.state.english.length === eb + 1);

  const ib = WB.state.invest.length;
  document.getElementById("investTopic").value = "可转债";
  WB.addInvest();
  ok("投资理财 新增生效", WB.state.invest.length === ib + 1);

  const hb = WB.state.hobbies.length;
  document.getElementById("hobbyName").value = "读书";
  document.getElementById("hobbyFreq").value = "每天";
  WB.addHobby();
  ok("兴趣爱好 新增生效", WB.state.hobbies.length === hb + 1);

  // 兴趣打卡
  const hid = WB.state.hobbies[WB.state.hobbies.length - 1].id;
  WB.stampHobby(hid);
  ok("兴趣爱好 打卡更新 last", WB.state.hobbies.find(function (x) { return x.id === hid; }).last === (function () { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); })());

  // 待办完成 toggle
  const tid = WB.state.todos.find(function (o) { return !o.done; }).id;
  WB.toggleTodo(tid);
  ok("待办 完成切换 done=true", WB.state.todos.find(function (o) { return o.id === tid; }).done === true);
})();

// ===== 4. 满 30 条备份提示 =====
(function () {
  // 重置状态后灌入 30 条
  ["todos", "notes", "projects", "jobs", "english", "invest", "hobbies"].forEach(function (k) { WB.state[k] = []; });
  for (let i = 0; i < 30; i++) WB.state.todos.push({ id: "x" + i, text: "t" + i, prio: "P2", due: "2099-01-01", done: false, doneDate: null, seed: false });
  WB.renderAll();
  ok("满 30 条显示备份提示", document.getElementById("backupTip").style.display === "block");
  WB.state.todos = []; WB.renderAll();
  ok("不足 30 条隐藏备份提示", document.getElementById("backupTip").style.display === "none");
})();

// ===== 5. 导入→导出 回环一致 =====
(function () {
  // 恢复种子态
  ["todos", "notes", "projects", "jobs", "english", "invest", "hobbies"].forEach(function (k) { WB.state[k] = []; });
  WB.init(); // 重新 seed
  const before = JSON.stringify({ t: WB.state.todos, n: WB.state.notes, p: WB.state.projects, j: WB.state.jobs, e: WB.state.english, i: WB.state.invest, h: WB.state.hobbies });
  WB.exportData();
  // 篡改 state
  WB.state.todos.push({ id: "zzz", text: "篡改", prio: "P2", due: "2099-01-01", done: false, doneDate: null, seed: false });
  WB.importData(lastBlob);
  const after = JSON.stringify({ t: WB.state.todos, n: WB.state.notes, p: WB.state.projects, j: WB.state.jobs, e: WB.state.english, i: WB.state.invest, h: WB.state.hobbies });
  ok("导入导出回环一致(含BOM兼容)", before === after);
})();

// ===== 6. CSV 表头 + BOM =====
(function () {
  WB.exportCsv();
  ok("CSV 含 BOM", lastBlob.charCodeAt(0) === 0xFEFF);
  ok("CSV 含表头(引号包裹·Excel安全)", lastBlob.indexOf('"截止日期","优先级","内容","状态"') === 1);
})();

// ===== 7. 渲染防 XSS =====
(function () {
  WB.state.todos.push({ id: "9999", text: "<img src=x onerror=alert(1)>", prio: "P2", due: "2099-01-01", done: false, doneDate: null, seed: false });
  WB.renderTodos();
  ok("渲染时对尖括号转义(防XSS)", document.getElementById("todoList")._html.indexOf("&lt;img") !== -1);
})();

// ===== 8. 复盘 SVG 图表 =====
(function () {
  WB.renderReview();
  ok("复盘中心含内联 SVG 柱状图", document.getElementById("reviewChart")._html.indexOf("<svg") !== -1);
})();

console.log("\n运行结果：" + pass + " 通过, " + fail + " 失败");
process.exit(fail === 0 ? 0 : 1);
