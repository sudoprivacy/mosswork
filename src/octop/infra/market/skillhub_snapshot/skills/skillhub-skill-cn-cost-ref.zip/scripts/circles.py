#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CAD 圆弧图元 → 端点串环 → 最小二乘圆拟合（精确圆心/半径），取代粗糙聚类"""
import sys, json, math, argparse

# ⚠ 修复（v20260930-16K）：早期版本在模块顶层裸导入 fitz / numpy，
#   任一缺失即导入期崩溃 —— 连 `--help` 都跑不出来，回归门禁 G1 直接红，
#   且报错是纯 traceback，用户看不出"缺什么、怎么装"。
#   现改为与 find_coord2.py 一致的降级写法：缺失时给出安装指引与可操作提示。
try:
    import fitz
except ImportError:
    try:
        import pymupdf as fitz          # 新版包名
    except ImportError:
        fitz = None

try:
    import numpy as np
except ImportError:
    np = None

_MISSING = [n for n, m in (("PyMuPDF(fitz)", fitz), ("numpy", np)) if m is None]
if _MISSING:
    _HINT = ("缺少依赖：" + "、".join(_MISSING)
             + "\n安装：pip install " + " ".join(
                 "pymupdf" if "fitz" in n else "numpy" for n in _MISSING)
             + "\n说明：本脚本用于 CAD 圆弧精确圆心/半径拟合，缺依赖时无法运行；"
               "其余算量能力不受影响。")


def collect_arcs(pg):
    arcs = []
    for d in pg.get_drawings():
        for it in d["items"]:
            if it[0] != "c":
                continue
            p1, p2, p3, p4 = it[1], it[2], it[3], it[4]
            xs = [p.x for p in (p1, p2, p3, p4)]
            ys = [p.y for p in (p1, p2, p3, p4)]
            arcs.append({
                "p1": (p1.x, p1.y), "p4": (p4.x, p4.y),
                "w": max(xs) - min(xs), "h": max(ys) - min(ys),
            })
    return arcs


def bez(p1, p2, p3, p4, t):
    mt = 1 - t
    return (mt**3*p1[0] + 3*mt*mt*t*p2[0] + 3*mt*t*t*p3[0] + t**3*p4[0],
            mt**3*p1[1] + 3*mt*mt*t*p2[1] + 3*mt*t*t*p3[1] + t**3*p4[1])


def fit_circle(pts):
    P = np.asarray(pts, dtype=float)
    if len(P) < 3:
        return None
    x, y = P[:, 0], P[:, 1]
    A = np.column_stack([x, y, np.ones(len(P))])
    b = -(x * x + y * y)
    try:
        sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    except Exception:
        return None
    D, E, F = sol
    cx, cy = -D / 2.0, -E / 2.0
    r2 = cx * cx + cy * cy - F
    if r2 <= 0:
        return None
    r = math.sqrt(r2)
    dd = np.hypot(x - cx, y - cy)
    return dict(cx=float(cx), cy=float(cy), r=float(r),
                resid=float(np.std(dd)), npts=int(len(P)),
                rmin=float(dd.min()), rmax=float(dd.max()))


class UF:
    def __init__(s): s.p = {}
    def f(s, a):
        s.p.setdefault(a, a)
        while s.p[a] != a:
            s.p[a] = s.p[s.p[a]]; a = s.p[a]
        return a
    def u(s, a, b):
        ra, rb = s.f(a), s.f(b)
        if ra != rb: s.p[ra] = rb


def build(pg, node_tol=0.35, verbose=False):
    arcs = collect_arcs(pg)
    # 1) 端点聚类成节点
    nodes = []   # [(x,y)]
    nidx = {}    # id -> (x,y)
    def add_node(p):
        for i, q in enumerate(nodes):
            if math.dist(p, q) < node_tol:
                return i
        nodes.append(p); return len(nodes) - 1
    edges = []
    for a in arcs:
        i1 = add_node(a["p1"]); i2 = add_node(a["p4"])
        if i1 != i2:
            edges.append((i1, i2, a))
    # 2) 连通分量
    uf = UF()
    for i in range(len(nodes)): uf.f(i)
    for i, j, _ in edges: uf.u(i, j)
    comp = {}
    for i in range(len(nodes)):
        comp.setdefault(uf.f(i), []).append(i)
    # 3) 每个分量：度、边数判定闭合环
    out = []
    for root, ns in comp.items():
        es = [e for e in edges if uf.f(e[0]) == root]
        deg = {i: 0 for i in ns}
        for i, j, _ in es:
            deg[i] += 1; deg[j] += 1
        closed = (len(es) == len(ns)) and all(d == 2 for d in deg.values()) and len(ns) >= 3
        if not closed:
            continue
        pts = [nodes[i] for i in ns]
        f = fit_circle(pts)
        if f is None:
            continue
        f.update(narc=len(es), nnode=len(ns), closed=True,
                 sq=max(max(abs(nodes[i][0] - f["cx"]) for i in ns),
                        max(abs(nodes[i][1] - f["cy"]) for i in ns)) / max(f["r"], 1e-9))
        out.append(f)
    # 4) 去重（多 drawing 重复绘制）
    ded = []
    for c in sorted(out, key=lambda c: (-c["narc"], c["resid"])):
        dup = False
        for d in ded:
            if math.dist((c["cx"], c["cy"]), (d["cx"], d["cy"])) < 0.6 and abs(c["r"] - d["r"]) < 0.6:
                dup = True; break
        if not dup:
            ded.append(c)
    return arcs, ded


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf"); ap.add_argument("page", type=int)
    ap.add_argument("--near", nargs=3, type=float, default=None, metavar=("X", "Y", "RAD"))
    ap.add_argument("--rmin", type=float, default=0.0)
    ap.add_argument("--rmax", type=float, default=1e9)
    ap.add_argument("--max-resid", type=float, default=0.30)
    ap.add_argument("--save", default=None)
    ap.add_argument("--top", type=int, default=20)
    a = ap.parse_args()

    if _MISSING:                       # 缺依赖：给安装指引，不甩 traceback
        print(_HINT)
        return 1

    doc = fitz.open(a.pdf); pg = doc[a.page]
    arcs, circles = build(pg)
    circles = [c for c in circles if a.rmin <= c["r"] <= a.rmax and c["resid"] <= a.max_resid]
    print(f"弧图元 {len(arcs)} 条 → 闭合圆 {len(circles)} 个（去重后）")
    if a.save:
        json.dump(circles, open(a.save, "w"), ensure_ascii=False)
        print(f"已保存 {a.save}")
    if a.near:
        x, y, rad = a.near
        hit = [(math.dist((c["cx"], c["cy"]), (x, y)), c) for c in circles]
        hit = [h for h in hit if h[0] <= rad]
        hit.sort(key=lambda t: t[0])
        print(f"\n== 视觉({x},{y}) 半径 {rad}pt 内闭合圆（按距离）:")
        for d, c in hit[:a.top]:
            print(f"   d={d:6.2f}pt center=({c['cx']:8.2f},{c['cy']:8.2f}) r={c['r']:6.3f}pt "
                  f"narc={c['narc']} resid={c['resid']:.4f}")
        if not hit:
            print("   （无）")


if __name__ == "__main__":
    sys.exit(main() or 0)
