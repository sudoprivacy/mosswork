#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""造价稽核官 · 广东省建设工程价格指数查询与调差计算

数据：scripts/data/gd_price_index.json（省标定站月度发布，2026-03/05/06/07）
规则：粤标定函〔2022〕117号（人工/台班指数）、〔2022〕208号（造价/材料指数）、
      粤标定函〔2025〕22号 第六条（编制期价格调整）、粤标定函〔2025〕24号 五·2（调价不调管理费和利润）

用法：
    python3 price_index_lookup.py latest
    python3 price_index_lookup.py get 房屋建筑工程
    python3 price_index_lookup.py get 房屋建筑工程 --period 2026-07
    python3 price_index_lookup.py trend 房屋建筑工程 人工价格指数
    python3 price_index_lookup.py adjust --category 房屋建筑工程 \
        --base 2026-03 --to 2026-07 --labor 93700 --machine 50000 --aux 20000
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "data", "gd_price_index.json")
GRN = "\033[92m"; YEL = "\033[93m"; RED = "\033[91m"; DIM = "\033[2m"; RST = "\033[0m"


def load():
    if not os.path.exists(DB):
        print("✗ 未找到指数库:", DB)
        sys.exit(1)
    return json.load(open(DB, encoding="utf-8"))


def get_val(d, period, category, name):
    for s in d["series"]:
        if s["period"] != period:
            continue
        for it in s["items"]:
            if it["category"] == category and it["name"] == name:
                return it
    return None


def periods(d):
    return [s["period"] for s in d["series"]]


def main():
    ap = argparse.ArgumentParser(description="广东价格指数查询与调差计算")
    sub = ap.add_subparsers(dest="cmd")

    sub.add_parser("latest", help="最新一期")
    p = sub.add_parser("get", help="查某期某类别指数")
    p.add_argument("category", nargs="?", default="房屋建筑工程")
    p.add_argument("--period", default="")
    p = sub.add_parser("trend", help="某指数的时间序列")
    p.add_argument("category", nargs="?", default="房屋建筑工程")
    p.add_argument("name", nargs="?", default="人工价格指数")
    p = sub.add_parser("adjust", help="调差计算")
    p.add_argument("--category", default="房屋建筑工程")
    p.add_argument("--base", required=True, help="基期（如 2026-03）")
    p.add_argument("--to", required=True, help="目标期（如 2026-07）")
    p.add_argument("--labor", type=float, default=0, help="基期人工费（定额人工费）")
    p.add_argument("--machine", type=float, default=0, help="基期施工机具使用费")
    p.add_argument("--aux", type=float, default=0, help="基期辅助材料费")
    p.add_argument("--main-mat", type=float, default=0,
                   help="主要材料费（按编制期价格直接计入，不乘指数）")

    a = ap.parse_args()
    d = load()
    ps = periods(d)

    if a.cmd == "latest":
        s = d["series"][-1]
        print(f"\n■ 最新一期：{s['period']}（{s['publish_date']} 发布，{s['doc_no']}）{s['note']}")
        cat = None
        for it in s["items"]:
            if it["category"] != cat:
                cat = it["category"]
                print(f"\n  {cat}")
            print(f"    {it['name']:<12} {it['value']:>8}   环比 {it['mom']}")
        print(f"\n{YEL}⚠ 指数按月发布，用前确认当期；库内现有期号：{'、'.join(ps)}"
              f"（缺 {'、'.join(d['meta']['missing'])}）{RST}")
        return

    if a.cmd == "get":
        p = a.period or d["meta"]["latest_period"]
        if p not in ps:
            print(f"✗ 无 {p} 期；现有：{'、'.join(ps)}")
            return
        print(f"\n■ {p} 期 · {a.category}")
        s = [x for x in d["series"] if x["period"] == p][0]
        found = False
        for it in s["items"]:
            if it["category"] == a.category:
                print(f"    {it['name']:<12} {it['value']:>8}   环比 {it['mom']}")
                found = True
        if not found:
            print(f"  ✗ 无此类别；可选：{'、'.join({i['category'] for i in s['items']})}")
        return

    if a.cmd == "trend":
        print(f"\n■ {a.category} · {a.name}")
        prev = None
        for p in ps:
            it = get_val(d, p, a.category, a.name)
            if not it:
                print(f"    {p}  —")
                continue
            delta = "" if prev is None else f"   较上期 {it['value'] - prev:+.2f}"
            print(f"    {p}  {it['value']:>8}  环比 {it['mom']}{delta}")
            prev = it["value"]
        return

    if a.cmd == "adjust":
        base, to = a.base, a.to
        if base not in ps or to not in ps:
            print(f"✗ 期号不存在；现有：{'、'.join(ps)}")
            return
        print(f"\n■ 调差计算：{a.category}  {base} → {to}")
        print(f"  依据：粤标定函〔2025〕22号 第六条 + 〔2022〕117号（指数）"
              f" + 粤标定函〔2025〕24号 五·2（不调管理费和利润）\n")
        total_delta = 0.0
        rows = []
        for label, key, amt, idx_name in (
                ("人工费", "labor", a.labor, "人工价格指数"),
                ("施工机具使用费", "machine", a.machine, "台班价格指数"),
                ("辅助材料费", "aux", a.aux, "材料价格指数")):
            if not amt:
                continue
            b = get_val(d, base, a.category, idx_name)
            t = get_val(d, to, a.category, idx_name)
            if not b or not t:
                print(f"  ⚠ {label}：{a.category} 无「{idx_name}」，跳过")
                continue
            ratio = t["value"] / b["value"]
            delta = amt * (ratio - 1)
            total_delta += delta
            rows.append((label, amt, b["value"], t["value"], ratio, delta))
        print(f"  {'项目':<14}{'基期金额':>12}{'基期指数':>10}{'目标指数':>10}{'比值':>9}{'调差额':>12}")
        for label, amt, bv, tv, ratio, delta in rows:
            print(f"  {label:<14}{amt:>12,.2f}{bv:>10}{tv:>10}{ratio:>9.4f}{delta:>12,.2f}")
        if a.main_mat:
            print(f"\n  主要材料费 {a.main_mat:,.2f} —— 按编制期价格**直接计入**定额，"
                  f"不乘指数（粤标定函〔2025〕22号 六·二）")
        print(f"\n  {GRN}要素调差合计：{total_delta:,.2f} 元{RST}")
        print(f"\n{YEL}⚠ 三条硬约束：")
        print(f"  1) 台班价格指数已含机上人工与燃料动力，机具费调了台班指数后"
              f"**不得再按人工/材料指数重复调整**；")
        print(f"  2) 物价变化调价**仅限分部分项人材机要素价，管理费和利润不参与调差**"
              f"（粤标定函〔2025〕24号 五·2）；")
        print(f"  3) 管理费和利润的计算基础（人工费+施工机具费）须用**调整后**的值"
              f"（粤标定函〔2025〕22号 六·三）。{RST}")
        return

    ap.print_help()


if __name__ == "__main__":
    main()
