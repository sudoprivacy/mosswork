#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gbt_2024_search.py — 2024 版四本国标（扫描件 OCR 稿）定位检索器

数据源: scripts/data/gbt_2024_nav.json（四本全文 OCR 稿 + 章节导航）
  GB/T 50500-2024 建设工程工程量清单计价标准        (95页)
  GB/T 50854-2024 房屋建筑与装饰工程工程量计算标准  (108页)
  GB/T 50856-2024 通用安装工程工程量计算标准        (195页)
  GB/T 50857-2024 市政工程工程量计算标准            (90页)

★ 反幻觉纪律（务必遵守）:
  四本原件为**扫描图片版PDF（无文本层）**，库内文字是 Tesseract chi_sim OCR 稿，
  存在识字误差（实测如「提供→提痊」「其他签证→其他闫证」「其他规定→基;他<规症」「依据→依狼」）。
  因此本库 **只用于「某条款在哪一页、大概说什么」的定位与线索**，
  **严禁把 OCR 文本当条款原文引用**——对外出具意见、核减依据、争议答复时，
  必须按本工具给出的页码回原件 PDF 核对后再落笔。

子命令:
  meta                                      四本信息与效力声明
  search <kw> [--std GB/T 50500-2024] [--limit 20] [--ctx 60]
                                            全文检索，返回页码+上下文片段
  open <std 简写> <页码>                     打印该页 OCR 全文（如 open 50500 43）
  toc <std 简写> [--limit 60]                列出该本章节导航（编号/标题/页码）
  stats                                     库统计

std 简写: 50500 / 50854 / 50856 / 50857（也可用完整编号）
"""
import json, os, re, sys, argparse

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'gbt_2024_nav.json')
ALIAS = {'50500': 'GB/T 50500-2024', '50854': 'GB/T 50854-2024',
         '50856': 'GB/T 50856-2024', '50857': 'GB/T 50857-2024'}
WARN = ("⚠ 本库为扫描件OCR稿，识字有误差；仅作定位线索，条款原文请按页码回原件PDF核对。")

def load():
    with open(DATA, encoding='utf-8') as f:
        return json.load(f)

def resolve(std):
    if std in ALIAS: return ALIAS[std]
    for k in load().keys():
        if std.replace('GB/T', '').strip() in k: return k
    return None

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)
    sub.add_parser('meta')
    p = sub.add_parser('search'); p.add_argument('kw'); p.add_argument('--std'); p.add_argument('--limit', type=int, default=15); p.add_argument('--ctx', type=int, default=70)
    p = sub.add_parser('open'); p.add_argument('std'); p.add_argument('page', type=int)
    p = sub.add_parser('toc'); p.add_argument('std'); p.add_argument('--limit', type=int, default=60)
    sub.add_parser('stats')
    a = ap.parse_args()
    db = load()

    if a.cmd == 'meta':
        for std, bk in db.items():
            print(f"■ {std} 《{bk['title']}》  {bk['pages']}页  章节导航 {len(bk['toc'])}条")
        print(f"\n生效: GB 50500-2013 已废止，GB/T 50500-2024 自 2025-09-01 施行（强制性→推荐性）")
        print(WARN)
        return

    if a.cmd == 'search':
        stds = [resolve(a.std)] if a.std else list(db.keys())
        stds = [s for s in stds if s]
        total, shown = 0, 0
        for std in stds:
            bk = db[std]
            for pg in bk['pages_text']:
                t = pg['text']
                if a.kw.lower() in t.lower():
                    total += 1
                    if shown >= a.limit: continue
                    shown += 1
                    idx = t.lower().find(a.kw.lower())
                    s = max(0, idx - a.ctx // 2)
                    frag = t[s: idx + a.ctx].replace('\n', ' ')
                    print(f"● {std} P{pg['p']}: …{frag}…")
        print(f"\n共命中 {total} 页（显示 {shown}）")
        print(WARN)
        return

    if a.cmd == 'open':
        std = resolve(a.std)
        if not std: print(f"未知标准简写 {a.std}（可选 50500/50854/50856/50857）"); return
        for pg in db[std]['pages_text']:
            if pg['p'] == a.page:
                print(f"=== {std} P{a.page} (OCR稿) ===")
                print(pg['text'])
                print(f"\n{WARN}")
                return
        print(f"{std} 无第 {a.page} 页（共 {db[std]['pages']} 页）")
        return

    if a.cmd == 'toc':
        std = resolve(a.std)
        if not std: print(f"未知标准简写 {a.std}"); return
        bk = db[std]
        print(f"=== {std} 《{bk['title']}》章节导航 {len(bk['toc'])} 条 ===")
        for t in bk['toc'][:a.limit]:
            print(f"  {t['no']:8s} {t['title'][:28]:30s} P{t['page']}")
        if len(bk['toc']) > a.limit: print(f"  …其余 {len(bk['toc'])-a.limit} 条加 --limit")
        return

    if a.cmd == 'stats':
        for std, bk in db.items():
            chars = sum(len(p['text']) for p in bk['pages_text'])
            print(f"{std}: {bk['pages']}页 / OCR {chars}字 / 导航 {len(bk['toc'])}条")
        print(WARN)

if __name__ == '__main__':
    main()
