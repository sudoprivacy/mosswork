#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testing_fee_parser.py — 检测收费指导价 PDF → 结构化 JSON 解析器（可复现通道）

用途：当拿到新版/其他省份的检测收费指导价 PDF 时，用本脚本重新生成
      scripts/data/*.json，配合 testing_fee_lookup.py 检索。

原目标文件：《广东省房屋建筑和市政工程质量安全检测收费指导价》87 页
Tables 布局为 7 列：
    列0 序号(1 / 1.1)   列1 名称(大类 / 二级组)
    列2 序号(1.1.1)     列3 参数名称
    列4 计费单位        列5 单价（元）       列6 备注

关键经验（本文件实战沉淀）：
  - find_tables() 识别稳定（87/87 页全部命中），但单元格内换行会把词组切碎，
    须清除"斜杠断词"和"中文之间的空格"，否则搜不到"防水涂料"（原为"防水涂 料"）。
  - 层级判断：列0 为纯整数=大类；x.y=二级组；列2 为 x.y.z=条目。
    ⚠️ 二级组行常与首条数据同行（列0=4.1 且列2=4.1.1），解析更新 grp 后**不能 continue**。
  - 表格跨页：fitz 逐页解析，继承式 status（cur_cat / cur_grp）天然跨页。
  - 共享计价：同一二级组内单价为空的续行，价格继承自上一条（标 inherit=true），
    这是审计防重复计费的关键标记（如"承载力+变形参数"按一组收费）。

依赖：pip install pymupdf
用法：
    python3 testing_fee_parser.py 收费表.pdf --out data/gd2015_fee.json
    python3 testing_fee_parser.py 收费表.pdf --out out.json --title "XXX省检测收费指导价"
"""
import argparse, json, os, re, sys

try:
    import fitz
except ImportError:
    sys.exit('[x] 需要 pymupdf：pip install pymupdf')

CJK = r'[\u4e00-\u9fa5]'
INT = re.compile(r'^\d{1,2}$')
SUB = re.compile(r'^\d{1,2}\.\d{1,2}$')
ITEM = re.compile(r'^\d{1,2}\.\d{1,2}\.\d{1,3}$')

# 业务板块标签（可按需扩充，用于 ——tag 过滤）
TAG = {
    '防水': ['防水涂料', '防水卷材', '嵌缝密封材料', '止水', '灌浆材料', '密封胶',
             '胶粘剂与密封材料', '遇水膨胀', '排水板'],
    '装饰装修': ['陶瓷砖', '石材', '建筑涂料', '木地板', '铝合金型材', '门窗',
                 '幕墙', '玻璃', '龙骨', '石膏'],
    '节能绿建': ['保温', '围护结构节能', '绿色建筑', '建筑能效', '热工', '玻璃光学'],
    '结构检测': ['混凝土', '钢筋', '钢结构', '饰面砖', '结构', '构件', '载荷',
                 '后锚固件', '预应力'],
    '机电设备': ['电气', '管道', '空调', '冷水', '风机', '照明', '给水排水', '阀门', '防火'],
    '室内环境': ['室内空气', '有害物质', '放射性', '土壤'],
    '市政交通': ['路基', '路面', '桥梁', '隧道', '沥青', '土工', '管片', '支座', '井盖'],
}


def clean(c):
    """清洗单元格：换行→空格、断词斜杠、中文间空格"""
    if c is None:
        return None
    s = c.replace('\n', ' ').replace('\r', ' ')
    s = re.sub(r'\s+', ' ', s).strip()
    s = re.sub(r'(?<=[\u4e00-\u9fa5A-Za-z）\)])\s*/\s*(?=[\u4e00-\u9fa5A-Za-z])', '', s)
    s = re.sub(rf'(?<={CJK})\s+(?={CJK})', '', s)
    s = re.sub(rf'(?<={CJK})\s+(?=[A-Za-z0-9（(])', '', s)
    s = re.sub(rf'(?<=[A-Za-z0-9）)])\s+(?={CJK})', '', s)
    return re.sub(r'\s+', ' ', s).strip() or None


def parse(pdf_path):
    doc = fitz.open(pdf_path)
    recs, cat, grp = [], ('', ''), ('', '')
    pages_tbl = 0
    for pno in range(doc.page_count):
        tbs = doc[pno].find_tables().tables
        if not tbs:
            continue
        pages_tbl += 1
        for tb in tbs:
            for raw in tb.extract():
                rw = ([clean(c) for c in raw] + [None] * 8)[:7]
                joined = ' | '.join(x or '' for x in rw)
                if '单价（元）' in joined or ('计费' in joined and '序号' in joined):
                    continue  # 表头
                c0, c1, c2, c3, c4, c5, c6 = rw
                if c0 and INT.match(c0) and c1:
                    cat = (c0, c1)
                elif c0 and SUB.match(c0) and c1:
                    grp = (c0, c1)          # ⚠️ 不 continue：本行可能同时是首条数据
                no = name = None
                if c2 and ITEM.match(c2) and c3:
                    no, name = c2, c3
                elif c3 and (c4 or c5):
                    no, name = None, c3
                if name:
                    recs.append(dict(page=pno + 1, cat_no=cat[0], cat=cat[1],
                                     grp_no=grp[0], grp=grp[1], item_no=no or '',
                                     item=name, unit=c4, price=c5, note=c6))
    doc.close()
    return recs, pages_tbl


def enrich(recs):
    """补 tags / pyuan / inherit（共享计价标记）"""
    prev = None
    for r in recs:
        src = (r.get('grp') or '') + (r.get('item') or '')
        r['tags'] = [k for k, v in TAG.items() if any(x in src for x in v)]
        m = re.match(r'^(\d+(?:\.\d+)?)$', (r.get('price') or '').strip())
        r['pyuan'] = float(m.group(1)) if m else None
        r['inherit'] = False
        if not r.get('price') and prev and prev['grp'] == r['grp']:
            r['price'] = prev['price']
            r['unit'] = r['unit'] or prev['unit']
            r['inherit'] = True
        if r.get('price'):
            prev = r
    return recs


def main():
    ap = argparse.ArgumentParser(description='检测收费指导价PDF解析器')
    ap.add_argument('pdf')
    ap.add_argument('--out', default='data/gd2015_fee.json')
    ap.add_argument('--title', default='检测收费指导价')
    ap.add_argument('--doc-no', default='（未标注文号）')
    a = ap.parse_args()

    recs, pages = parse(a.pdf)
    recs = enrich(recs)
    data = dict(
        meta=dict(title=a.title, doc_no=a.doc_no,
                  source_file=os.path.basename(a.pdf), pages=pages, items=len(recs),
                  groups=len({r['grp'] for r in recs if r['grp']}),
                  status='使用前须核实该文件是否已被后续文件废止',
                  note='结构化解析结果，仅作比价基准，须核实现行效力',
                  parser='cn-cost-ref/scripts/testing_fee_parser.py'),
        categories=sorted({(int(r['cat_no']), r['cat']) for r in recs
                           if r['cat_no'].isdigit()}),
        items=recs)
    os.makedirs(os.path.dirname(a.out) or '.', exist_ok=True)
    json.dump(data, open(a.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'[√] 解析完成：{len(recs)} 条 / {data["meta"]["groups"]} 组 / {pages} 页')
    print(f'    共享型 inherit: {sum(1 for r in recs if r["inherit"])} 条')
    print(f'    缺单价: {sum(1 for r in recs if not r["price"])} 条')
    print(f'    → {a.out}')


if __name__ == '__main__':
    main()
