#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""项目数据隐私扫描器 —— 发布前门禁（配套 references/data-privacy-policy.md）。

三级分档：
  L3 客户原件（.dwg/.pdf/.xlsx… 出现在技能目录） → 阻断
  L2 可识别主体（项目名/标段名/房号/手机/身份证/邮箱） → 阻断
  L1 脱敏数值（金额、单价、费率） → 默认放行，--strict 计入，--redact 可扰动

用法：
  python3 privacy_scan.py                    # 扫描，L2/L3 命中则 exit 1
  python3 privacy_scan.py --strict           # 同时报告 L1 数值密度
  python3 privacy_scan.py --json             # 机器可读输出
  python3 privacy_scan.py --add "某某花园"     # 新项目名入库并立即扫描
  python3 privacy_scan.py --redact [outdir]  # 导出 L1 数值扰动后的对外副本

注意：
  --redact 按固定系数缩放金额，仅用于**阻止数值被反向对号入座**，
  不保证算术自洽（如 明细合计==小计 之类等式会漂移）。
  若需要一个"能跑 demo"的对外版，请改用手工剥离样例数据。
"""
import argparse
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
TERMS_PATH = os.path.join(HERE, "data", "privacy_terms.json")

# 扫描范围 = 会被打进发布包的内容（与 release.sh 的 zip 范围一致）
SCAN_DIRS = ["references", "scripts", "bridge", "cost_auditor_pay", "publish"]
SCAN_FILES = ["SKILL.md"]
SCAN_EXT = (".md", ".py", ".json", ".sh")
# 运行时状态/元数据，非内容资产，跳过
SKIP_NAMES = {"a402_orders.json", "_user_meta.json"}
# 隐私词库自身是"检测语料"，不应被当成泄漏内容反扫（否则 redacted 台账词会自我命中）
SKIP_NAMES.add("privacy_terms.json")


def load_terms():
    with open(TERMS_PATH, encoding="utf-8") as f:
        return json.load(f)


def iter_files():
    for d in SCAN_DIRS:
        base = os.path.join(ROOT, d)
        if not os.path.isdir(base):
            continue
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [x for x in dirnames if x != "__pycache__"]
            for fn in filenames:
                if fn in SKIP_NAMES or not fn.endswith(SCAN_EXT):
                    continue
                yield os.path.join(dirpath, fn)
    for fn in SCAN_FILES:
        p = os.path.join(ROOT, fn)
        if os.path.isfile(p):
            yield p


def rel(p):
    return os.path.relpath(p, ROOT)


def scan(terms, strict=False):
    hits = {"L3": [], "L2": [], "L1": []}

    # ---- L3a 客户原件 ----
    raw = terms["raw_file_ext"]
    for d in raw["scan_dirs"]:
        base = os.path.join(ROOT, d)
        if not os.path.isdir(base):
            continue
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [x for x in dirnames if x != "__pycache__"]
            for fn in filenames:
                if os.path.splitext(fn)[1].lower() in raw["ext"]:
                    hits["L3"].append({"file": rel(os.path.join(dirpath, fn)),
                                       "kind": "客户原件扩展名", "term": fn,
                                       "line": 0, "text": fn})

    # 治理文档豁免（自身需引用反例做教学对照）
    exempt = set(terms.get("exempt_files", {}).get("files", []))

    names = terms["project_names"]
    active = names.get("active", [])
    redacted = names.get("redacted", [])
    rules = terms["regex_rules"]
    l1 = terms["l1_amount"]

    for p in iter_files():
        rp = rel(p)
        if rp in exempt:
            continue
        try:
            text = open(p, encoding="utf-8").read()
        except Exception:
            continue
        lines = text.split("\n")

        # ---- L2a 项目名（active 阻断；redacted 仅审计提示） ----
        for i, ln in enumerate(lines, 1):
            for t in active:
                if t and t in ln:
                    hits["L2"].append({"file": rel(p), "kind": "项目名(新入库)",
                                       "term": t, "line": i, "text": ln.strip()[:120]})
            for r in redacted:
                t = r["term"]
                if t and t in ln and ("案件码" not in ln) and (r["case"] not in ln):
                    hits["L2"].append({"file": rel(p), "kind": "项目名(应已脱敏残留)",
                                       "term": t, "line": i, "text": ln.strip()[:120]})

        # ---- L2b/L3b 正则 ----
        for r in rules:
            pat = re.compile(r["pattern"])
            allow = set(r.get("allow", []))
            for i, ln in enumerate(lines, 1):
                for m in pat.finditer(ln):
                    v = m.group(0)
                    if any(a in v for a in allow):
                        continue
                    # 数字类规则：排除长数字串内部误匹配（如 automation-178xxxxxxx）
                    if r["id"] in ("mobile", "bankcard"):
                        s, e = m.span()
                        if (s > 0 and ln[s - 1].isdigit()) or (e < len(ln) and ln[e].isdigit()):
                            continue
                    hits[r["level"]].append({"file": rel(p), "kind": r["desc"],
                                             "term": v, "line": i, "text": ln.strip()[:120]})

        # ---- L1 大额数值 ----
        if strict:
            pat = re.compile(l1["pattern"])
            n = len(pat.findall(text))
            if n:
                hits["L1"].append({"file": rel(p), "kind": "L1 数值(金额/单价)",
                                   "term": "-", "line": 0, "text": f"{n} 处"})
    return hits


REDACT_K = 0.937  # 固定扰动系数：非 1、非整数比，避免一眼看穿

# frontmatter 中**不得扰动**的元数据键：它们是标识符而非金额。
# 事故记录（v20260930-16F）：原实现对全文套 `[0-9]{6,}` 无差别缩放，
# 导致对外副本 version 被改成 "18984491.41-16F"、fingerprint 被插成
# "e620b8386eb38688265.25f7ba..."、provenance 里 automation-1787251361079
# 被改成 automation-1674654525331.02 —— 副本会被自己的反篡改条款判为非法。
_PROTECT_KEYS = ("version", "fingerprint_sha256", "total_lines", "total_files",
                 "last_maintenance", "skill_id", "provenance", "license",
                 "slug", "name", "displayName", "edition", "payment")


def _is_protected(text: str, start: int, end: int) -> bool:
    """判断一处数字命中是否为「标识符/元数据」而非金额；是则不扰动。

    四道判据：
      ① frontmatter 区块（文件首 `---` 到下一个 `---`）整体保护；
      ② 所在行是注释（`#` 开头）或以受保护键开头；
      ③ 令牌级：向两侧扩展到非「字母数字/_/-」边界，若扩展出的令牌含字母
         （如 `20260930-16F`、`GZJS202603`、`automation-1787251361079`）则保护；
      ④ 扩展令牌不等于原命中串，说明该数字只是长标识符的一段，同样保护。
    """
    # ① frontmatter
    if text.startswith("---\n"):
        fm_end = text.find("\n---", 4)
        if fm_end != -1 and start < fm_end:
            return True
    # ② 注释行 / 受保护键
    ls = text.rfind("\n", 0, start) + 1
    le = text.find("\n", end)
    line = text[ls: le if le != -1 else len(text)]
    stripped = line.lstrip()
    if stripped.startswith("#"):
        return True
    for k in _PROTECT_KEYS:
        if stripped.startswith(k + ":"):
            return True
    # ③④ 令牌级扩展
    i, j = start, end
    while i > 0 and (text[i - 1].isalnum() or text[i - 1] in "_-"):
        i -= 1
    while j < len(text) and (text[j].isalnum() or text[j] in "_-"):
        j += 1
    token = text[i:j]
    if any(c.isalpha() for c in token):
        return True
    return token != text[start:end]


def redact_amount(m, text=None):
    """把金额字符串按固定系数缩放（保留千分位与小数位数形态）。

    ⚠ 保护守卫：`re.sub` 的可调用对象只收一个 match 参数，故用闭包绑定原文，
       避免把 text 一路传下去导致签名不匹配。
    """
    s = m.group(0)
    if text is not None and _is_protected(text, m.start(), m.end()):
        return s
    if "," in s:  # 千分位形态
        try:
            v = float(s.replace(",", ""))
        except ValueError:
            return s
        new = round(v * REDACT_K, 2)
        return f"{new:,.0f}" if new == int(new) else f"{new:,.2f}"
    try:
        v = float(s)
    except ValueError:
        return s
    if v < 10000:      # 小额（含量/系数/页码）不动，避免破坏算法常量
        return s
    new = round(v * REDACT_K, 2)
    return f"{new:.0f}" if new == int(new) else f"{new:.2f}"


def do_redact(outdir):
    terms = load_terms()
    pat = re.compile(terms["l1_amount"]["pattern"])
    if os.path.exists(outdir):
        shutil.rmtree(outdir)
    os.makedirs(outdir)
    changed = 0
    for p in iter_files():
        dst = os.path.join(outdir, rel(p))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        try:
            s = open(p, encoding="utf-8").read()
        except Exception:
            shutil.copy2(p, dst)
            continue
        s2, n = pat.subn(lambda m: redact_amount(m, s), s)
        if n:
            changed += 1
        open(dst, "w", encoding="utf-8").write(s2)
    # 同步脱敏词库：★清空 redacted 审计台账（原词→案件码映射本身即可识别，对外副本不带）
    dst_terms = os.path.join(outdir, "scripts", "data", "privacy_terms.json")
    os.makedirs(os.path.dirname(dst_terms), exist_ok=True)
    t = load_terms()
    t["project_names"]["redacted"] = []
    t["project_names"]["_note"] = (
        "对外副本已清空 redacted 审计台账（原词->案件码映射本身即可识别）；"
        "内部主副本保留台账用于按案件码定位与删除。")
    with open(dst_terms, "w", encoding="utf-8") as f:
        json.dump(t, f, ensure_ascii=False, indent=2)
    notice = os.path.join(outdir, "REDACTED-NOTICE.md")
    with open(notice, "w", encoding="utf-8") as f:
        f.write("# 对外分享版说明（L1 数值已扰动）\n\n"
                f"- 生成方式：`python3 scripts/privacy_scan.py --redact`\n"
                f"- 处理方式：6 位及以上金额按固定系数 {REDACT_K} 缩放；"
                "小于 10000 的含量/系数/页码类常量保持不变。\n"
                "- 🛡 **元数据与标识符不受扰动**：frontmatter（version / fingerprint / "
                "total_* / last_maintenance / skill_id / provenance）、注释行、"
                "以及任何字母邻接的长标识符（版本号 `20260930-16F`、批次码 `GZJS202603`、"
                "automation ID、SHA-256 指纹）一律原样保留——它们是标识符不是金额，"
                "扰动会让副本被自己的反篡改条款判为非法。\n"
                "- 🔏 **指纹已重算**：数值扰动改变了文件内容，故对外副本的 "
                "`fingerprint_sha256` 由本脚本重新计算并自校验通过，"
                "与内部主副本指纹**不同且不冲突**（各自自洽即可）。\n"
                "- ⚠ **不保证算术自洽**：明细合计、小计、总额之间的等式会漂移，\n"
                "  本副本仅供阅读方法论，**不可用于任何核对或演示运行**。\n"
                "- 案件名仍为脱敏案件码（CASE-A/B/C），房号门牌已泛化。\n"
                "- 敏感词库 `scripts/data/privacy_terms.json` 已清空 `redacted` 审计台账：\n"
                "  原词→案件码的映射本身即可识别，对外副本不带（内部主副本保留以便按案件码定位删除）。\n")

    # ---- 对外副本重算内容指纹 + 改写 provenance ----
    # 数值扰动改变了 SKILL.md 内容，若沿用主副本指纹，会被 SKILL.md 里的
    # 「指纹不符即视为未授权篡改或抄袭」条款判为非法。故就地重算并自校验。
    # 同时 provenance 原文写的是「未对外发布、禁止二次分发」，与「对外分享版」
    # 自相矛盾，须一并改写，否则副本既说禁止分发又摆在分发包里。
    dst_skill = os.path.join(outdir, "SKILL.md")
    if os.path.exists(dst_skill):
        _mark_public_provenance(dst_skill)
        recompute_fingerprint(dst_skill)
    return changed, outdir


def _mark_public_provenance(path):
    """把对外副本的 provenance 改写为与「可公开分享」一致的口径。"""
    s = open(path, encoding="utf-8").read()
    lines = s.split("\n")
    for i, ln in enumerate(lines):
        if ln.startswith("provenance:"):
            lines[i] = ("provenance: 对外分享版（由 `scripts/privacy_scan.py --redact` "
                        "自内部私有主本生成：真实项目名已隐去、L1 金额按固定系数扰动、"
                        "指纹已重算且自洽）。内容为实战方法论与可运行脚本，"
                        "MIT 许可，允许自由使用与再分发，但请保留本声明与 SKILL.md "
                        "「反幻觉红线」各条——方法论可用，结论值须自行核验后采信。")
            break
    open(path, "w", encoding="utf-8").write("\n".join(lines))


def recompute_fingerprint(path):
    """清零 fingerprint 行 → SHA-256 → 写回 → 自校验。返回是否成功。"""
    import hashlib
    s = open(path, encoding="utf-8").read()
    if "fingerprint_sha256:" not in s:
        return False
    cleared = re.sub(r"^fingerprint_sha256:\s*\S+", "fingerprint_sha256:", s,
                     count=1, flags=re.M)
    fp = hashlib.sha256(cleared.encode("utf-8")).hexdigest()
    s = re.sub(r"^fingerprint_sha256:\s*\S+", "fingerprint_sha256: " + fp, s,
               count=1, flags=re.M)
    open(path, "w", encoding="utf-8").write(s)
    # 自校验
    s2 = open(path, encoding="utf-8").read()
    stored = re.search(r"^fingerprint_sha256:\s*(\S+)", s2, flags=re.M)
    if not stored:
        return False
    cleared2 = re.sub(r"^fingerprint_sha256:\s*\S+", "fingerprint_sha256:", s2,
                      count=1, flags=re.M)
    return hashlib.sha256(cleared2.encode("utf-8")).hexdigest() == stored.group(1)


def main():
    ap = argparse.ArgumentParser(description="项目数据隐私扫描器（发布前门禁）")
    ap.add_argument("--strict", action="store_true", help="同时报告 L1 数值密度")
    ap.add_argument("--json", action="store_true", help="JSON 输出")
    ap.add_argument("--add", metavar="TERM", help="新项目名加入敏感词库")
    ap.add_argument("--redact", nargs="?", const="/workspace/CostAuditor-public",
                    metavar="OUTDIR", help="导出 L1 数值扰动的对外副本")
    args = ap.parse_args()

    if args.add:
        terms = load_terms()
        act = terms["project_names"].setdefault("active", [])
        if args.add not in act:
            act.append(args.add)
            with open(TERMS_PATH, "w", encoding="utf-8") as f:
                json.dump(terms, f, ensure_ascii=False, indent=2)
            print(f"✓ 已入库敏感词：{args.add}")

    if args.redact:
        changed, out = do_redact(args.redact)
        print(f"✓ 对外副本已生成：{out}（{changed} 个文件做了数值扰动）")
        print("  ⚠ 不保证算术自洽，仅供阅读方法论，不可用于核对/演示。")
        return

    terms = load_terms()
    hits = scan(terms, strict=args.strict)

    if args.json:
        print(json.dumps(hits, ensure_ascii=False, indent=2))
        sys.exit(1 if (hits["L2"] or hits["L3"]) else 0)

    print("════ 项目数据隐私扫描 ════")
    # 横幅由 SCAN_DIRS 动态生成——曾因写死旧文案，实际已扩到 cost_auditor_pay/publish
    # 却仍打印「references/ scripts/ bridge/」，误导审计以为新目录未纳入扫描。
    banner = " ".join(f"{d}/" for d in SCAN_DIRS)
    print(f"范围：{banner} SKILL.md（= 发布包内容范围，共 {len(SCAN_DIRS)} 目录）\n")
    blocking = False
    for lv, title in (("L3", "L3 客户原件（严禁入库）"),
                      ("L2", "L2 可识别主体（须脱敏为案件码）")):
        h = hits[lv]
        flag = "❌ 阻断" if h else "✅ 通过"
        print(f"{title}: {flag}（{len(h)} 处）")
        for x in h[:20]:
            print(f"   - {x['file']}:{x['line']}  [{x['kind']}]  「{x['term']}」")
            print(f"     {x['text']}")
        if h:
            blocking = True
        print()

    if args.strict:
        h = hits["L1"]
        print(f"L1 数值（放行，对外分享前建议 --redact）：{len(h)} 个文件含金额类数值")
        for x in h[:15]:
            print(f"   - {x['file']}  {x['text']}")
        print()

    if blocking:
        print("❌ 存在 L2/L3 命中，禁止打包发布。")
        print("   处置：把项目名/标段名/房号替换为案件码+中性业态（见 data-privacy-policy.md §2.2），")
        print("         客户原件移出技能目录。改完重跑本命令。")
        sys.exit(1)
    print("✅ 隐私门禁通过（无 L2/L3 命中）。")
    print("   提示：包内仍含 L1 样例数值，对外分享前请跑 --redact 或直接给方法论口径。")
    sys.exit(0)


if __name__ == "__main__":
    main()
