#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
limit_price_verify.py · 招标最高投标限价汇总表勾稽与计税基数验算

**这个脚本是被真实数据逼出来的**：2026-10 用一份真实施工招标公告的最高投标限价汇总表
做验算，发现「增值税 ÷ 税前工程造价 = 8.6373%」而非法定 9%，逐项追查后确认——
**增值税计税基数 = 税前工程造价 − 专业工程暂估价**（专业工程暂估价不计税）。
若按全额计税，该项目会多计增值税 90,948.97.59 元。技能此前只写「按计税基数计」，
从未给出基数公式，属可被审计钻口的模糊表述。

本脚本做四件事：
  ① 分部分项各子项合计 → 分部分项工程费        勾稽
  ② 分部分项 + 措施 + 其他 → 税前工程造价        勾稽
  ③ 税前工程造价 + 增值税 → 合计                勾稽
  ④ **反算计税基数**：在 (税前工程造价) 与 (税前工程造价 − 专业工程暂估价) 两个候选中
     判定哪个能精确复现公告税额，并给出「若按全额计税会多计多少」

子命令：check（勾稽+计税基数） · selftest（自证机制） · demo（真实回归样本）
输入：JSON（--file）或命令行参数；金额单位元，保留 2 位小数。
"""
import argparse
import json
import sys

TOL = 0.02   # 勾稽容差（元）。公告金额均 2 位小数，取 0.02 避免浮点误报。

# GB/T 50500-2024 一般计税法定税率
VAT_RATE_GENERAL = 0.09
VAT_RATE_SIMPLE = 0.03


# --------------------------------------------------------------------------- 核心
def verify(d):
    """d: dict，键名见 build_demo()。返回结构化验算结果。"""
    out = {"checks": [], "info": {}, "risk": []}

    def ck(name, ok, detail=""):
        out["checks"].append({"name": name, "ok": bool(ok), "detail": str(detail)})

    sub_items = d.get("sub_items") or {}          # 分部分项各子项 {名称: 金额}
    sub_t = d.get("sub_total")                    # 分部分项工程费
    measure = d.get("measure")                    # 措施项目费
    safety = d.get("safety")                      # 其中：安全生产措施费
    other = d.get("other")                        # 其他项目费
    prov = d.get("provisional")                   # 暂列金额
    est = d.get("provisional_est")                # 专业工程暂估价
    pre = d.get("pre_tax")                        # 税前工程造价
    vat = d.get("vat")                            # 增值税
    total = d.get("total")                        # 合计

    # ① 分部分项子项合计
    if sub_items and sub_t is not None:
        s = sum(sub_items.values())
        ck("① 分部分项各子项合计 = 分部分项工程费", abs(s - sub_t) <= TOL,
           f"子项合计 {s:,.2f} vs 公告 {sub_t:,.2f} 差 {s - sub_t:+,.2f}")
        for k, v in sorted(sub_items.items(), key=lambda x: -x[1]):
            out["info"].setdefault("sub_breakdown", []).append(
                {"item": k, "amount": v, "pct_of_sub": round(v / sub_t * 100, 2) if sub_t else None})
    else:
        ck("① 分部分项各子项合计", False, "缺 sub_items 或 sub_total")

    # ② 分部分项 + 措施 + 其他 = 税前工程造价
    if None not in (sub_t, measure, other, pre):
        s = sub_t + measure + other
        ck("② 分项+措施+其他 = 税前工程造价", abs(s - pre) <= TOL,
           f"{s:,.2f} vs {pre:,.2f} 差 {s - pre:+,.2f}")
    else:
        ck("② 分项+措施+其他 = 税前工程造价", False, "缺 sub_total/measure/other/pre_tax")

    # ③ 税前 + 增值税 = 合计
    if None not in (pre, vat, total):
        s = pre + vat
        ck("③ 税前工程造价 + 增值税 = 合计", abs(s - total) <= TOL,
           f"{s:,.2f} vs {total:,.2f} 差 {s - total:+,.2f}")
    else:
        ck("③ 税前工程造价 + 增值税 = 合计", False, "缺 pre_tax/vat/total")

    # 其他项目费内部：暂列金额 + 专业工程暂估价 ≤ 其他项目费
    if None not in (other, prov, est):
        s = prov + est
        ck("④ 暂列金额+专业工程暂估价 ≤ 其他项目费", s <= other + TOL,
           f"{s:,.2f} vs {other:,.2f}（其他项目费还可含计日工/总承包服务费等）")
    if None not in (safety, measure):
        ck("⑤ 安全生产措施费 ≤ 措施项目费", safety <= measure + TOL,
           f"占比 {safety / measure * 100:.2f}%" if measure else "")

    # ★⑥ 计税基数反算（本脚本的核心价值）
    if None not in (pre, vat):
        r_naive = vat / pre
        out["info"]["implied_rate_naive"] = round(r_naive * 100, 4)
        ck("⑥a 全额计税时隐含税率 ≈ 法定 9%", abs(r_naive - VAT_RATE_GENERAL) <= 0.001,
           f"隐含 {r_naive * 100:.4f}%（法定 {VAT_RATE_GENERAL * 100:.0f}%）")
        if abs(r_naive - VAT_RATE_GENERAL) > 0.001 and est:
            base2 = pre - est
            r2 = vat / base2
            out["info"]["implied_rate_excl_est"] = round(r2 * 100, 4)
            out["info"]["tax_base"] = round(base2, 2)
            ck("⑥b 剔除专业工程暂估价后隐含税率 = 法定 9%", abs(r2 - VAT_RATE_GENERAL) <= 0.0005,
               f"基数 {base2:,.2f} → 隐含 {r2 * 100:.4f}%")
            over = pre * VAT_RATE_GENERAL - vat
            out["info"]["over_tax_if_naive"] = round(over, 2)
            out["info"]["over_tax_pct_of_vat"] = round(over / vat * 100, 2) if vat else None
            ck("⑥c 结论：专业工程暂估价不计税", abs(r2 - VAT_RATE_GENERAL) <= 0.0005,
               f"★若误按全额 {pre:,.2f}×9% 计税，将多计增值税 {over:,.2f} 元"
               f"（占公告税额 {over / vat * 100:.2f}%）")
            out["risk"].append({
                "level": "高",
                "title": "增值税计税基数应剔除专业工程暂估价",
                "detail": f"公告税额 {vat:,.2f} ÷ 全额 {pre:,.2f} = {r_naive * 100:.4f}%，"
                          f"非法定 9%；扣除专业工程暂估价 {est:,.2f} 后 = {r2 * 100:.4f}%。"
                          f"说明该公告按「税前工程造价 − 专业工程暂估价」计税。"
                          f"审核时若按全额计税，将多计 {over:,.2f} 元。",
                "basis": "GB/T 50500—2024 清单计价标准 + 该项目招标文件约定（个案口径，须以招标文件为准）",
            })
        elif abs(r_naive - VAT_RATE_GENERAL) > 0.001:
            out["risk"].append({
                "level": "中",
                "title": "隐含税率与法定 9% 不符且无暂估价可解释",
                "detail": f"隐含 {r_naive * 100:.4f}%，既不等于一般计税 9% 也不等于简易计税 3%，"
                          f"且未提供专业工程暂估价。应回查招标文件是否另有计税约定"
                          f"（如价内税、扣除项、以审定建安预算为基数等）。",
                "basis": "需人工回查招标文件，本工具不下结论",
            })
    return out


# --------------------------------------------------------------------------- 真实回归样本
def build_demo():
    """真实回归样本：某 2026-07 广东市政配套基础设施项目最高投标限价汇总表（原文数字）。

    ⚠ 样本仅保留**金额结构**用于算法回归，已隐去项目名称、招标人、代理机构
       （见 references/data-privacy-policy.md 案件码制度；金额为公开公告数据）。
    """
    return {
        "sub_items": {"土方工程": 12271632.39, "市政工程": 5079977.11,
                      "园林工程": 162211.99, "市政安装": 3626124.46},
        "sub_total": 21139945.95,
        "measure": 1022836.86,
        "safety": 375821.42,
        "other": 2913145.42,
        "provisional": 1902595.13,
        "provisional_est": 1010550.28,
        "pre_tax": 25075928.23,
        "vat": 2165884.02,
        "total": 27241812.25,
    }


# --------------------------------------------------------------------------- 自证
def selftest():
    res = []
    def ck(n, c, d=""):
        res.append((n, bool(c), d))

    # T1 真实样本：5 项勾稽全对
    r = verify(build_demo())
    names = {c["name"][:2] for c in r["checks"] if c["ok"]}
    ck("T1.1 真实样本 ①②③ 勾稽全通过",
       all(c["ok"] for c in r["checks"] if c["name"][:1] in "①②③"),
       ";".join(c["name"][:1] for c in r["checks"] if not c["ok"]) or "全过")
    ck("T1.2 ④⑤ 结构校验通过",
       all(c["ok"] for c in r["checks"] if c["name"][:1] in "④⑤"))

    # T2 计税基数核心：真实样本必判出「剔除专业工程暂估价」
    ck("T2.1 真实样本反算出 8.6373%（非 9%）",
       abs(r["info"]["implied_rate_naive"] - 8.6373) < 0.001,
       f"{r['info']['implied_rate_naive']}%")
    ck("T2.2 剔除暂估价后隐含税率 = 9.0000%",
       abs(r["info"]["implied_rate_excl_est"] - 9.0) < 0.001,
       f"{r['info']['implied_rate_excl_est']}%")
    ck("T2.3 计税基数 = 24,065,377.66.31",
       abs(r["info"]["tax_base"] - 24065377.95) < 0.02, f"{r['info']['tax_base']:,.2f}")
    ck("T2.4 误按全额计税多计 90,948.97.59 元",
       abs(r["info"]["over_tax_if_naive"] - 97064.59) < 0.02,
       f"{r['info']['over_tax_if_naive']:,.2f}")
    ck("T2.5 输出高风险提示", any(x["level"] == "高" for x in r["risk"]))

    # T3 反向样本：全额计税的普通房建，不应误报暂估价
    d2 = build_demo()
    d2["vat"] = round(d2["pre_tax"] * 0.09, 2)
    d2["total"] = round(d2["pre_tax"] + d2["vat"], 2)
    d2["provisional_est"] = 0.0
    r2 = verify(d2)
    ck("T3.1 全额计税样本反算 = 9%", abs(r2["info"]["implied_rate_naive"] - 9.0) < 0.0005,
       f"{r2['info']['implied_rate_naive']}%")
    ck("T3.2 无暂估时不报「剔除暂估价」结论",
       "implied_rate_excl_est" not in r2["info"])
    ck("T3.3 无暂估且全额计税时无高风险提示",
       not any(x["level"] == "高" for x in r2["risk"]))

    # T4 故意做坏的汇总表必须被抓出
    d3 = build_demo()
    d3["pre_tax"] = round(d3["pre_tax"] + 1000.0, 2)   # ② 破坏 1000 元
    r3 = verify(d3)
    ck("T4.1 人为破坏 ② 勾稽被抓出",
       any((not c["ok"]) and c["name"].startswith("②") for c in r3["checks"]))
    d4 = build_demo()
    d4["sub_items"]["土方工程"] = 12271632.40          # 破坏子项 0.01
    r4 = verify(d4)
    ck("T4.2 0.01 元子项误差被抓出（容差 0.02 内应为通过）",
       all(c["ok"] for c in r4["checks"] if c["name"].startswith("①")))
    d5 = build_demo()
    d5["sub_items"]["土方工程"] = 12271632.45          # 破坏 0.06 超容差
    r5 = verify(d5)
    ck("T4.3 超容差子项误差被抓出",
       any((not c["ok"]) and c["name"].startswith("①") for c in r5["checks"]))

    print("=" * 62)
    print("limit_price_verify · selftest")
    print("=" * 62)
    for n, ok, det in res:
        print(f"[{'PASS' if ok else 'FAIL'}] {n}" + (f"  · {det}" if det else ""))
    p = sum(1 for _, ok, _ in res if ok)
    print("-" * 62)
    print(f"{p}/{len(res)} 通过")
    print("=" * 62)
    sys.exit(0 if p == len(res) else 1)


# --------------------------------------------------------------------------- 渲染
def render(d, r):
    L = [f"# 最高投标限价汇总表验算（{' '.join(x['name'] for x in r['checks'] if x['ok'])}）",
         "",
         "## 一、勾稽与结构校验", "",
         "| 项 | 结论 | 说明 |", "|:--|:--|:--|"]
    for c in r["checks"]:
        if c["name"].startswith("⑥"):
            continue
        L.append(f"| {c['name']} | {'✅' if c['ok'] else '❌'} | {c['detail']} |")

    if r.get("info", {}).get("sub_breakdown"):
        L += ["", "## 二、分部分项构成", "",
              "| 子项 | 金额（元） | 占比 |", "|:--|--:|--:|"]
        for x in r["info"]["sub_breakdown"]:
            L.append(f"| {x['item']} | {x['amount']:,.2f} | {x['pct_of_sub']}% |")

    i = r.get("info", {})
    if "implied_rate_naive" in i:
        L += ["", "## 三、★ 增值税计税基数反算", "",
              f"- 按**全额**税前工程造价反算隐含税率：**{i['implied_rate_naive']}%**",
              f"（法定一般计税 {VAT_RATE_GENERAL*100:.0f}%）"]
        if "implied_rate_excl_est" in i:
            L += [f"- 剔除专业工程暂估价后反算：**{i['implied_rate_excl_est']}%** ✔ 与法定一致",
                  f"- 推定计税基数 = **{i['tax_base']:,.2f} 元** = 税前工程造价 − 专业工程暂估价",
                  f"- **若误按全额计税，将多计增值税 {i['over_tax_if_naive']:,.2f} 元**"
                  f"（占公告税额 {i['over_tax_pct_of_vat']}%）"]
        L += ["", "> 依据：GB/T 50500—2024 清单计价标准 + 该项目招标文件约定。",
              "> ⚠ 计税基数口径属**个案约定**，审核时须回查本项目招标文件，不得当作通例套用。"]

    if r["risk"]:
        L += ["", "## 四、风险提示", ""]
        for x in r["risk"]:
            L += [f"### [{x['level']}] {x['title']}", "", x["detail"], "",
                  f"*依据：{x['basis']}*", ""]
    return "\n".join(L)


# --------------------------------------------------------------------------- CLI
def main():
    p = argparse.ArgumentParser(description="招标最高投标限价汇总表勾稽与计税基数验算")
    sub = p.add_subparsers(dest="cmd")
    c = sub.add_parser("check", help="验算汇总表")
    c.add_argument("--file", help="汇总表 JSON；不给则用内置真实回归样本")
    sub.add_parser("demo", help="跑真实回归样本")
    sub.add_parser("selftest", help="自证机制")
    a = p.parse_args()

    if a.cmd == "selftest":
        selftest()
        return
    if a.cmd == "demo":
        d, r = build_demo(), verify(build_demo())
        print(render(d, r))
        return
    if not a.cmd:
        p.print_help()
        return

    d = json.load(open(a.file, encoding="utf-8")) if a.file else build_demo()
    r = verify(d)
    out = render(d, r)
    if getattr(a, "json", False):
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print(out)
    sys.exit(0 if all(c["ok"] for c in r["checks"]) else 1)


if __name__ == "__main__":
    main()
