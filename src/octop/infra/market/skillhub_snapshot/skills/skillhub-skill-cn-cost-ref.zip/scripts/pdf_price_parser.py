#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pdf_price_parser.py — 工程预算 PDF 综合单价分析表 / 分部分项清单计价表 通用解析器

背景：造价审核时常收到 .pdf 预算书（综合单价分析表 + 分部分项清单计价表 + 汇总表），
需程序化抽取"人·材·机·管·利"五费构成、材料含量×单价、工程量，供钩稽校验与重新组价。

能力：
  1) parse_analysis_table()  解析"分部分项工程项目清单综合单价分析表"
       → 每项 {code,name,unit, comp:{人工,材料,机具,小计,管理,利润,综合}, subs:[子项含量], fee_rate:{管理费,利润}}
  2) parse_boq_pricing()     解析"分部分项工程项目清单计价表"
       → 每项 {code,name,unit,qty,price,total}   (工程量×综合单价×合价)
  3) verify_hook()           钩稽校验 人工+材料+机械+管理+利润 ≈ 综合单价
  4) 反推取费费率            reverse_fee_rate()

关键经验（CASE-A 实战沉淀）：
  - 预算 PDF 通常三段：①汇总表 ②分部分项清单计价表(带工程量) ③综合单价分析表(带人材机)
    三者页码可定位；分析表页码区间在文档中段，计价表在其前。
  - 10列布局识别（fitz find_tables）: 列0=序号 1=费用项目/名称 3=单位 4=数量 5=计算基础 7=费率 8=单价 9=合价
  - 跨页数字会断裂（如 17812.85 被拆成 "17812.8" + "5"），须合并换行符后 to_float。
  - 同一 12 位编码可重复出现（如"余方弃置""变形缝"在不同部位各一条），不可按 code 去重丢项，须保留全部。
  - "综合单价" 行的值在靠后非空数值列；"管理费/利润"等标题行值在第9列。
  - 子项中"含量即金额"（单价=1且单位=元）与"含量×单价"要区分。
依赖：pip install pymupdf  （fitz）
用法：
  python3 pdf_price_parser.py <预算.pdf> --analysis 5 75 --boq 2 6 --out result.json
"""
import fitz, re, json, sys

def _to_float(v):
    if v is None: return None
    s = str(v).replace('\n', '').replace(',', '').strip()
    if s in ('', '-', '—', 'None'): return None
    try: return float(s)
    except: return None

def _clean_row(row):
    return [str(c).strip() if c is not None else '' for c in row]

def _is_code(x):
    return isinstance(x, str) and bool(re.fullmatch(r'\d{12}', x))

# ----------------------------------------------------------------------------
# 1) 综合单价分析表
# ----------------------------------------------------------------------------
def parse_analysis_table(pdf_path, page_start, page_end):
    """page_start/end 为综合单价分析表所在页区间（含页码，end不包含）。
    若不确定页码，可传 auto=True 自动定位；否则给页范围。"""
    doc = fitz.open(pdf_path)
    items = []
    cur = None
    for i in range(page_start, page_end):
        try:
            tables = doc[i].find_tables().tables
        except Exception:
            continue
        for t in tables:
            for row in t.extract():
                f = _clean_row(row)
                code = f[1] if len(f) > 1 and _is_code(f[1]) else ''
                if code:
                    if cur: items.append(cur)
                    # name 常见于列4或列2（两种表头布局都兼容）
                    name = f[4] if len(f) > 4 and f[4] else (f[2] if len(f) > 2 else '')
                    cur = {'code': code, 'name': name, 'rows': []}
                    continue
                if cur is not None and f[0] in ('1', '2', '3', '4', '5', '6', '综合单价'):
                    cur['rows'].append(f)
    if cur: items.append(cur)
    return _normalize_analysis(items)

def _normalize_analysis(raw_items):
    out = []
    for it in raw_items:
        rec = {'code': it['code'], 'name': it['name'],
               'comp': {'人工': 0, '材料': 0, '机具': 0, '小计': 0, '管理': 0, '利润': 0, '综合': 0},
               'subs': [], 'fee_rate': {'管理费': None, '利润': None}, 'unit': ''}
        cur_cat = None
        for r in it['rows']:
            tag = r[1] if len(r) > 1 else ''
            cat = None
            if r[0] == '1' and tag == '人工费': cat = '人工'
            elif r[0] == '2' and tag == '材料费': cat = '材料'
            elif r[0] == '3' and tag == '施工机具使用费': cat = '机具'
            if cat:  # 标题行：值在第9列
                rec['comp'][cat] = _to_float(r[9]) or 0
                cur_cat = cat
                continue
            if r[0] == '4' and '小计' in tag:
                rec['comp']['小计'] = _to_float(r[9]) or 0; continue
            if r[0] == '5' and tag == '管理费':
                rec['comp']['管理'] = _to_float(r[9]) or 0; continue
            if r[0] == '6' and tag == '利润':
                rec['comp']['利润'] = _to_float(r[9]) or 0; continue
            if r[0] == '综合单价':
                # 值在靠后非空数值列
                vals = [_to_float(x) for x in r[6:] if _to_float(x) is not None]
                rec['comp']['综合'] = vals[-1] if vals else 0
                continue
            # 子项：形如 1.1/2.3 的小数序号
            if re.fullmatch(r'\d+\.\d+', r[0]) and len(r) > 7:
                price = _to_float(r[8]); qty = _to_float(r[4]); unit = r[3]
                # 含量即金额（单价1且单位元）→ 合价=含量
                amt = qty if (price == 1.0 and unit == '元') else ((qty or 0) * (price or 0))
                rec['subs'].append({'cat': cur_cat, 'name': tag, 'unit': unit,
                                    'qty': qty, 'price': price, 'total': round(amt, 2)})
        # 反推费率：基数=人工+机具（广东口径）；若为0则退回单取人工
        base = rec['comp']['人工'] + rec['comp']['机具']
        if base > 0:
            rec['fee_rate']['管理费'] = round(rec['comp']['管理'] / base * 100, 2)
            rec['fee_rate']['利润'] = round(rec['comp']['利润'] / base * 100, 2)
        out.append(rec)
    return out

# ----------------------------------------------------------------------------
# 2) 分部分项清单计价表（含工程量）
# ----------------------------------------------------------------------------
def parse_boq_pricing(pdf_path, page_start, page_end):
    """列结构：0序号 1编码 2名称 4特征 5单位 6工程量 8综合单价 9合价"""
    doc = fitz.open(pdf_path)
    items = []
    for i in range(page_start, page_end):
        try:
            tables = doc[i].find_tables().tables
        except Exception:
            continue
        for t in tables:
            for row in t.extract():
                f = _clean_row(row)
                code = f[1] if len(f) > 1 and _is_code(f[1]) else ''
                if code:
                    items.append({
                        'code': code,
                        'name': f[2] if len(f) > 2 else '',
                        'unit': f[5] if len(f) > 5 else '',
                        'qty': _to_float(f[6]) if len(f) > 6 else 0,
                        'price': _to_float(f[8]) if len(f) > 8 else 0,
                        'total': _to_float(f[9]) if len(f) > 9 else 0,
                    })
    return items

# ----------------------------------------------------------------------------
# 3) 钩稽校验
# ----------------------------------------------------------------------------
def verify_hook(analysis, tol=0.5):
    """人+材+机+管+利 ≈ 综合单价。返回不符清单。"""
    bad = []
    for it in analysis:
        c = it['comp']
        s = c['人工'] + c['材料'] + c['机具'] + c['管理'] + c['利润']
        if abs(s - c['综合']) > tol:
            bad.append({'code': it['code'], 'sum': round(s, 2), 'total': c['综合']})
    return bad

# ----------------------------------------------------------------------------
# 辅助：自动定位页码
# ----------------------------------------------------------------------------
def locate_sections(pdf_path):
    """返回 {'boq_start','boq_end','analysis_start','analysis_end'}，按表头文本定位。"""
    doc = fitz.open(pdf_path)
    n = len(doc)
    a_start = a_end = b_start = None
    for i in range(n):
        text = doc[i].get_text()
        if a_start is None and '综合单价分析表' in text and '简版' not in text:
            a_start = i
        elif a_start is not None and a_end is None and '简版' in text:
            a_end = i
        if b_start is None and '分部分项工程项目清单计价表' in text:
            b_start = i
    return {'boq_start': b_start, 'analysis_start': a_start,
            'analysis_end': a_end or (a_start + 65 if a_start else None)}

# ----------------------------------------------------------------------------
def _main():
    """带参数校验与友好异常处理的主入口（实际契约：python3 pdf_price_parser.py <预算.pdf> [--auto] [out.json]）。"""
    import os
    # ① 无参数：给用法提示，不抛裸 Traceback
    if len(sys.argv) < 2:
        print('用法: python3 pdf_price_parser.py <预算.pdf> [--auto] [out.json]')
        print('  <预算.pdf>  待解析的预算PDF（综合单价分析表+分部分项清单计价表）')
        print('  --auto      自动定位分析表/计价表页码范围（推荐，需文本层可检索）')
        print('  [out.json]  输出JSON路径，缺省为 pdf_price_out.json')
        print('依赖: pip install pymupdf')
        sys.exit(1)
    # ①b --help / -h：打印用法后正常退出（原实现会把 "--help" 当成 PDF 文件名报 rc=2）
    if sys.argv[1] in ('-h', '--help'):
        print('用法: python3 pdf_price_parser.py <预算.pdf> [--auto] [out.json]')
        print('  <预算.pdf>  待解析的预算PDF（综合单价分析表+分部分项清单计价表）')
        print('  --auto      自动定位分析表/计价表页码范围（推荐，需文本层可检索）')
        print('  [out.json]  输出JSON路径，缺省为 pdf_price_out.json')
        print('依赖: pip install pymupdf')
        sys.exit(0)
    pdf = sys.argv[1]
    auto = '--auto' in sys.argv
    # ② 文件不存在 / 非PDF：友好提示
    if not os.path.isfile(pdf):
        print(f'[错误] 找不到预算PDF文件: {pdf}')
        print('请确认路径正确。用法: python3 pdf_price_parser.py <预算.pdf> [--auto] [out.json]')
        sys.exit(2)
    if not pdf.lower().endswith('.pdf'):
        print(f'[警告] 输入文件后缀不是 .pdf: {pdf}（可能无法按PDF解析）')
    # ③ 解析主体：捕获打开失败(损坏/非PDF)与解析异常，给可读信息而非裸堆栈
    try:
        if auto:
            sec = locate_sections(pdf)
            print('自动定位:', sec)
            analysis = parse_analysis_table(pdf, sec['analysis_start'], sec['analysis_end']) \
                       if sec['analysis_start'] is not None else []
            boq = parse_boq_pricing(pdf, sec['boq_start'], sec['analysis_start']) \
                  if sec['boq_start'] is not None else []
        else:
            analysis = parse_analysis_table(pdf, 11, 75)
            boq = parse_boq_pricing(pdf, 2, 11)
        print(f'综合单价分析表解析 {len(analysis)} 项；清单计价表解析 {len(boq)} 项')
        bad = verify_hook(analysis)
        print(f'钩稽不符 {len(bad)} 项: {bad[:8]}')
        # 反推费率分布
        from collections import Counter
        mg = Counter(it['fee_rate']['管理费'] for it in analysis if it['fee_rate']['管理费'] is not None)
        lr = Counter(it['fee_rate']['利润'] for it in analysis if it['fee_rate']['利润'] is not None)
        print('反推管理费率分布:', dict(mg))
        print('反推利润率分布:', dict(lr))
        out = json.dumps({'analysis': analysis, 'boq': boq}, ensure_ascii=False, indent=1)
        fn = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith('--') else 'pdf_price_out.json'
        with open(fn, 'w', encoding='utf-8') as f:
            f.write(out)
        print('已保存:', fn)
    except Exception as e:
        msg = str(e)
        # 区分可读错误与内部错误
        low = msg.lower()
        if 'cannot open' in low or 'no such file' in low or 'could not' in low or 'invalid' in low or 'not a pdf' in low:
            print(f'[错误] 无法打开/解析该PDF: {pdf}')
            print(f'  原因: {msg}')
            print('  可能: 文件已损坏 / 不是有效PDF / 是扫描件无文本层。扫描件请先OCR或确认含文字层。')
        else:
            print(f'[错误] 解析过程中出现异常（可能PDF无文字层或版式特殊）:')
            print(f'  {msg}')
            print('  建议: 若为扫描件请先加OCR文字层，或手动指定 --auto 重试；仍有问题请提供样本排查。')
        sys.exit(3)


if __name__ == '__main__':
    _main()
