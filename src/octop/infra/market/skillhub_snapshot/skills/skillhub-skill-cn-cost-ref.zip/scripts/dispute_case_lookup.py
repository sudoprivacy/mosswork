#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""造价稽核官 · 广东计价争议判例库检索

数据：scripts/data/gd_dispute_cases.json（公开月刊「争议案例分享」栏目结构化，38 例）
用法：
    python3 dispute_case_lookup.py stats
    python3 dispute_case_lookup.py search 消纳费
    python3 dispute_case_lookup.py search 措施项目 --topic 措施项目 --limit 5
    python3 dispute_case_lookup.py get 534
    python3 dispute_case_lookup.py topic 变更与新增工程
    python3 dispute_case_lookup.py list [--period 2026-06]
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "data", "gd_dispute_cases.json")

RED = "\033[91m"; GRN = "\033[92m"; YEL = "\033[93m"; DIM = "\033[2m"; RST = "\033[0m"


def load():
    if not os.path.exists(DB):
        print("✗ 未找到判例库:", DB)
        sys.exit(1)
    return json.load(open(DB, encoding="utf-8"))


def hit(c, kw):
    if not kw:
        return True
    blob = " ".join([c["title"], c.get("gist", ""), c["background"],
                     c["views"], c["ruling"], " ".join(c.get("refs", []))])
    return kw in blob


def brief(c, kw=None, w=68):
    print(f"\n  {GRN}■ 第 {c['case_no']} 号{RST} {c['title']}")
    print(f"    {DIM}主题 {'/'.join(c['topics'])} ｜ 出处 {c['source']}{RST}")
    if c.get("gist"):
        print(f"    口径：{c['gist']}")
    if c.get("refs"):
        print(f"    {DIM}依据：{'；'.join(c['refs'][:4])}{RST}")


def full(c):
    print(f"\n{'=' * 72}")
    print(f"第 {c['case_no']} 号 ｜ {c['title']}")
    print(f"主题：{'/'.join(c['topics'])}   出处：{c['source']}（{c['period']}）")
    print("=" * 72)
    for label, key in (("一、争议事项", "background"),
                       ("二、双方观点", "views"),
                       ("三、我站观点", "ruling")):
        v = c.get(key, "")
        if not v:
            continue
        print(f"\n{label}")
        for i in range(0, len(v), 62):
            print("   " + v[i:i + 62])
    if c.get("refs"):
        print(f"\n援引文件：{'；'.join(c['refs'])}")
    print(f"\n{YEL}⚠ 原文为 OCR 转写，正式援引前须回出处 PDF 核对；"
          f"本观点仅适用于该个案，引用须说明案情差异。{RST}")


def main():
    ap = argparse.ArgumentParser(description="广东计价争议判例库检索")
    sub = ap.add_subparsers(dest="cmd")

    sub.add_parser("stats", help="库概况")
    p = sub.add_parser("search", help="全文检索")
    p.add_argument("kw", nargs="?", default="", help="关键词")
    p.add_argument("--topic", default="", help="限定主题")
    p.add_argument("--limit", type=int, default=8)
    p = sub.add_parser("get", help="查看某例全文")
    p.add_argument("no", type=int)
    p = sub.add_parser("topic", help="按主题列出")
    p.add_argument("name", nargs="?", default="")
    p.add_argument("--limit", type=int, default=20)
    p = sub.add_parser("list", help="列表")
    p.add_argument("--period", default="")

    a = ap.parse_args()
    d = load()
    cases = d["cases"]

    if a.cmd == "stats":
        m = d["meta"]
        print(f"\n■ 广东计价争议判例库")
        print(f"  案例数 {m['total']} ｜ 编号区间 {m['case_range'][0]} ~ {m['case_range'][1]}")
        print(f"  覆盖期号 {'、'.join(m['periods'])}")
        print(f"  来源：{m['source_note']}")
        import collections
        cnt = collections.Counter(t for c in cases for t in c["topics"])
        print("\n  主题分布：")
        for t, n in cnt.most_common():
            print(f"    {t:<14} {n:>3} 例")
        return

    if a.cmd == "search":
        res = [c for c in cases if hit(c, a.kw)
               and (not a.topic or a.topic in c["topics"])]
        print(f"\n命中 {len(res)} 例（关键词「{a.kw}」"
              + (f" · 主题「{a.topic}」" if a.topic else "") + "）")
        for c in res[:a.limit]:
            brief(c)
        if len(res) > a.limit:
            print(f"\n  …另有 {len(res) - a.limit} 例，加 --limit 查看")
        print(f"\n{YEL}⚠ 摘录自公开月刊（OCR 转写），援引前回原文核对；个案观点不当然适用他案。{RST}")
        return

    if a.cmd == "get":
        for c in cases:
            if c["case_no"] == a.no:
                full(c)
                return
        print(f"✗ 未找到第 {a.no} 号案例")
        return

    if a.cmd == "topic":
        import collections
        if not a.name:
            cnt = collections.Counter(t for c in cases for t in c["topics"])
            for t, n in cnt.most_common():
                print(f"  {t:<16} {n:>3} 例")
            return
        res = [c for c in cases if a.name in c["topics"]]
        print(f"\n主题「{a.name}」共 {len(res)} 例：")
        for c in res[:a.limit]:
            brief(c)
        return

    if a.cmd == "list":
        res = [c for c in cases if not a.period or c["period"] == a.period]
        for c in res:
            print(f"  {c['case_no']:>4}  {c['title']}")
        print(f"\n共 {len(res)} 例")
        return

    ap.print_help()


if __name__ == "__main__":
    main()
