#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
audit_triple_source.py — 三源比价审计脚本（报价单 → 价库 + 检测库 + 政策口径 → 虚高/存疑标记）

定位：把"审价单看单价虚不虚高"从凭经验，固化成一条命令——
输入报价行(项目/数量/单价/单位/类别)，自动调三源交叉核并输出逐行判定：
  源1 材料价库  material_prices.json(信息价/市场价/实战核价 + source_id 来源链 + 效力)
  源2 检测费库  gd2015_fee.json(粤建检协2015-8 历史指导价 → 已废止警示,现行市场调节)
  源3 政策口径  policy_files.json(计价/取费文件现行效力基线,守反幻觉不引废止文件)

判定口径(对齐检测费"单价合理性三源比价"方法论 + repricing-audit 六步法第④步):
  - 材料类: 有当期可核可比价 → 报价>可核上限 ⇒「虚高(建议核减到X)」; 落区间内 ⇒「可核」;
            价库缺当期同口径价 ⇒「缺当期可比源(先 material_price_update 补当期)」。
  - 检测类: 命中历史指导价 → 标「仅历史参考(8号文已废止,现行市场调节),建议取市场询价三单佐证」,
            不把废止价当强制核减基准; 未命中 ⇒「检测项库无此条(走市场询价三源交叉)」。
  - 政策口径: 逐行给取费/计价依据效力提示; 无法核实的明确标「待补权威原文核对」。

⚠️ 纪律(守反幻觉):
  - 报价单单位/口径与价库不同 ⇒ 不硬比,标「口径/单位不一致,请先统一再核」;
  - 只做"虚高/存疑/可核"三种判定,不做无依据的精确"应为多少"断言;
  - 涉税/涉规费/涉监管,一律以当时有效政策原文为准,不代税法/规章。

输入格式: 三源比价逐行判定。可直接命令行传单行,或用 --file 传 csv(项目名,数量,单价,单位,类别[材料|检测|其他])
用法:
    python3 audit_triple_source.py audit <材料名> <单价> <单位> [--cat 材料] [--qty 1] [--region 广州]
    python3 audit_triple_source.py audit-file <报价单.csv> [--region 广州]
    python3 audit_triple_source.py explain <判定词>        # 解释三档判定口径
"""
import json, os, sys, csv, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_MAT = os.path.join(HERE, 'data', 'material_prices.json')
DATA_FEE = os.path.join(HERE, 'data', 'gd2015_fee.json')
DATA_POL = os.path.join(HERE, 'data', 'policy_files.json')

# 虚高判定阈值：报价超可比源合理上限的比例(报价 > 可比价*(1+ALLOW) 视为虚高)
# 材料价格有地区/批次波动,允许 8% 内视为"市场波动可核",超出即虚高嫌疑。
ALLOW_MAT = 0.08
# 检测类历史指导价已被废止,仅作参考:允许 ±25% 内不作强判(因为现行市场调节),超出也仅"建议核"不"必核"
ALLOW_FEE = 0.25


def load_json(path, required=True):
    if not os.path.exists(path):
        if required:
            sys.exit(f'[x] 文件缺失: {path}')
        return None
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def flatten_mat(d):
    out = []
    for cat, catinfo in d['materials'].items():
        for spec, sinfo in (catinfo.get('specs') or {}).items():
            unit = sinfo.get('单元', '')
            for p in sinfo.get('periods', []):
                out.append(dict(cat=cat, spec=spec, unit=unit,
                                name=f"{cat}·{spec}", **p))
    return out


def hit_mat(r, kw):
    k = (kw or '').lower()
    if not k:
        return False
    fields = [r['cat'], r['spec'], r['name'], str(r.get('来源', ''))]
    field_text = ' '.join(str(x).lower() for x in fields)
    # ① 原整串子串匹配（兼容精确写法）
    if k in field_text:
        return True
    # ② 规格词 token 匹配：处理"HRB400E螺纹钢"等俗称→库名"钢筋·HRB400E Φ12-25"
    #    英文/数字连片 或 中文≥2字 作为有效 token，任一命中即算匹配
    import re
    toks = re.findall(r'[a-z0-9]+|[一-鿿]{2,}', k)
    for t in toks:
        if len(t) >= 2 and t in field_text:
            return True
    return False


def hit_fee(r, kw):
    k = (kw or '').lower()
    fields = [r.get('item', ''), r.get('grp', ''), r.get('cat', ''),
              r.get('note', '') or '', r.get('item_no', ''), r.get('grp_no', '')]
    return any(k in str(x).lower() for x in fields)


def best_material_ref(rows, region=None, period=None):
    """取该材料在(地区)的当期最佳可比参考:
    优先取与目标期号同期的 可核 信息价; 否则最新一期任意来源; 返回 (ref_price, source_id, 置信度, 口径, 期号, 效力)."""
    rows = [r for r in rows if not region or r.get('计价地区') == region]
    if not rows:
        return None
    # 排序: 可核>市场核>待补, 同档内期号新优先
    order = {'可核': 0, '市场核': 1, '经验估': 2, '待补': 3}
    rows.sort(key=lambda x: (order.get(x.get('置信度'), 3), -int(str(x.get('期号', '0')).replace('-', ''))))
    b = rows[0]
    batches = load_json(DATA_MAT).get('meta', {}).get('source_batches', {})
    sid = b.get('source_id')
    batch = (batches or {}).get(sid)
    return dict(price=b['价格'], unit=b.get('unit', ''), sid=sid,
                confidence=b.get('置信度'), caliber=b.get('口径'), period=b.get('期号'),
                issuer=(batch or {}).get('issuer'))


def audit_material(kw, quote_price, quote_unit, region=None, qty=1):
    """材料类三源比价: 价库当期可比 → 判定虚高/可核/缺源"""
    d = load_json(DATA_MAT)
    rows = [r for r in flatten_mat(d) if hit_mat(r, kw)]
    ref = best_material_ref(rows, region)
    line = {'kw': kw, 'quote': quote_price, 'qty': qty, 'cat': '材料'}
    if not ref:
        line.update(verdict='缺当期可比源',
                    note='价库未命中该材料/该地区，先 material_price_update 补当期可比价再核，勿臆断',
                    source='—')
        return line
    # 单位口径核对
    if quote_unit and ref['unit'] and quote_unit != ref['unit']:
        line.update(verdict='口径/单位不一致',
                    note=f"报价单位{quote_unit} 与价库可比单位{ref['unit']} 不同，先统一口径再比价(见 material_price_lookup)",
                    ref_price=ref['price'], ref_unit=ref['unit'],
                    source=f"{ref['sid']}@{ref['issuer']} {ref['period']} {ref['caliber']}")
        return line
    ratio = quote_price / ref['price'] if ref['price'] else None
    if ratio is not None and ratio > (1 + ALLOW_MAT):
        cut_to = ref['price'] * (1 + ALLOW_MAT)
        line.update(verdict='虚高(建议核减)',
                    note=f"报价{quote_price} 为可核可比价{ref['price']:.2f} 的 {ratio:.2f} 倍，超上限({(1+ALLOW_MAT):.0%}×参考){(ratio-(1+ALLOW_MAT))*100:.1f}%，建议核到≈{cut_to:.2f}(信息价口径)并要对方三单佐证",
                    ref_price=ref['price'], ref_unit=ref['unit'], ratio=round(ratio, 3),
                    source=f"{ref['sid']}@{ref['issuer']} {ref['period']} {ref['caliber']}({ref['confidence']})")
    elif ref['confidence'] == '可核':
        line.update(verdict='可核',
                    note=f"报价{quote_price} 落于可核信息价{ref['price']:.2f}允许波动内，与权威源一致(同口径)",
                    ref_price=ref['price'], ref_unit=ref['unit'], ratio=round(ratio, 3),
                    source=f"{ref['sid']}@{ref['issuer']} {ref['period']} {ref['caliber']}({ref['confidence']})")
    else:
        line.update(verdict='存疑(市场核参考)',
                    note=f"报价{quote_price} 比对市场核参考{ref['price']:.2f}({ratio:.2f}倍)，仅市场资讯/区间口径非权威，若作核减须与对方交叉印证",
                    ref_price=ref['price'], ref_unit=ref['unit'], ratio=round(ratio, 3),
                    source=f"{ref['sid']}@{ref['issuer']} {ref['period']} {ref['caliber']}({ref['confidence']})")
    return line


def audit_testing(kw, quote_price, quote_unit=None, qty=1):
    """检测类三源比价: 检测库历史指导价(效力警示) → 判定"""
    d = load_json(DATA_FEE)
    rows = [r for r in d.get('items', []) if hit_fee(r, kw)]
    fee_meta = d.get('meta', {})
    line = {'kw': kw, 'quote': quote_price, 'qty': qty, 'cat': '检测'}
    if not rows:
        line.update(verdict='库无此检测项',
                    note='gd2015_fee 未收录该项，走市场询价三单交叉佐证(勿引废止8号文当强制价)',
                    source=fee_meta.get('doc_no'))
        return line
    # 取第一条的指导价文本
    r = rows[0]
    line['fee_item'] = r.get('item', kw)
    line['fee_no'] = r.get('item_no', '')
    line['fee_unit'] = r.get('unit')
    # ⚠️ 历史指导价已废止,只能参考不能强制
    line.update(verdict='仅历史参考(效力警示)',
                note=f"报价{quote_price} 命中检测库历史条目[{r.get('item_no')}] {r.get('item')}(指导价{r.get('price')})——{fee_meta.get('status')}，历史价仅作比价参考、不作强制核减基准，现行按市场调节价以三单佐证",
                source=fee_meta.get('doc_no'))
    return line


def audit_policy(brief_verdict, cat='材料'):
    """政策口径: 依类别给出应引用的现行依据/效力提示(联动 policy_files.json)。
    cat: 材料 / 检测 / 其他 —— 显式传类别,不靠 verdict 关键字猜测(检测类 verdict 不带'检测'字样会误判)。"""
    d = load_json(DATA_POL, required=False)
    if not d:
        return {'hint': '政策效力库缺失,无法给效力提示(请先核 policy_files.json)'}
    rel = [p for p in d.get('policies', []) if p.get('status', '').startswith('现行')]
    text = []
    for p in rel:
        title = p.get('title', '')
        if cat == '检测' and ('检测' in title or '放开' in title or '服务价格' in title):
            text.append(f"现行依据: {p.get('doc_no')} {p.get('title')} — {p.get('status')}")
        elif cat != '检测' and any(x in title for x in ['清单', '计量', '费用', '计价']):
            text.append(f"计价口径: {p.get('doc_no')} {p.get('title')} — {p.get('status')}")
    if not text:
        text.append('本行属市场/实战口径,无强制文件号捆绑;若需引规范取费,先过 policy-basis 效力闸核对现行版')
    return {'hint': '；'.join(text)}


# ------------------------------------------------- 展示
def show_line(line):
    print(f"\n  ■ [{line.get('cat')}] {line.get('kw')}  报价 {line.get('quote'):.2f} × {line.get('qty', 1)}")
    if 'fee_item' in line:
        print(f"     命中检测条目[{line.get('fee_no')}]{line.get('fee_item')}  单位={line.get('fee_unit')}  报价单位={line.get('quote_unit','?')}")
    print(f"     判定: {line.get('verdict')}")
    print(f"     {line.get('note')}")
    if line.get('ref_price') is not None:
        print(f"     可比参考: {line['ref_price']:,.2f} 元/{line.get('ref_unit','')}"
              + (f"  (报价/参考={line.get('ratio')})" if line.get('ratio') else ""))
    print(f"     来源: {line.get('source','—')}")


def cmd_audit(a):
    print('=' * 70)
    print('三源比价 · 单行判定')
    print('=' * 70)
    cat = (a.cat or '材料').strip()
    if cat == '检测':
        line = audit_testing(a.kw, a.price, a.unit, a.qty)
    elif cat == '材料':
        line = audit_material(a.kw, a.price, a.unit, a.region, a.qty)
    else:
        line = {'kw': a.kw, 'quote': a.price, 'qty': a.qty, 'cat': cat,
                'verdict': '待人工核对', 'note': '非材料/非检测类,三源脚本不自动判;请转对应专项库或人工', 'source': '—'}
    show_line(line)
    pol = audit_policy(line.get('verdict', ''), cat)
    print(f"\n  政策口径: {pol.get('hint')}")
    print('\n  ⚠ 本工具只做"虚高/存疑/可核"三档判定,不替代正式审核;涉税/涉规费以当时有效政策原文为准。')


def cmd_audit_file(a):
    print('=' * 70)
    print(f'三源比价 · 报价单({a.file})')
    print('=' * 70)
    rows = []
    with open(a.file, encoding='utf-8-sig') as f:
        raw = list(csv.reader(f))
    # 表头容错：首行含已知列名(中/英)视为表头，否则按位置 项目名,数量,单价,单位,类别 解析
    # （避免真实清单 CSV 无表头时，csv.DictReader 把首行数据当表头、整份读空）
    HEADER = {'项目名', 'kw', 'name', '数量', 'qty', '单价', 'price',
              '单位', 'unit', '类别', 'cat', 'category'}
    if raw and set(raw[0]) & HEADER:
        fmap = {h: i for i, h in enumerate(raw[0])}
        def _get(r, *keys):
            for key in keys:
                if key in fmap and fmap[key] < len(r):
                    return r[fmap[key]].strip()
            return ''
        for r in raw[1:]:
            if not r or len(r) < 2:
                continue
            rows.append({
                '项目名': _get(r, '项目名', 'kw', 'name'),
                '数量': _get(r, '数量', 'qty'),
                '单价': _get(r, '单价', 'price'),
                '单位': _get(r, '单位', 'unit'),
                '类别': _get(r, '类别', 'cat', 'category') or '材料',
            })
    else:
        for r in raw:
            if not r or len(r) < 3:
                continue
            rows.append({
                '项目名': r[0].strip(),
                '数量': r[1].strip(),
                '单价': r[2].strip(),
                '单位': r[3].strip() if len(r) > 3 else '',
                '类别': r[4].strip() if len(r) > 4 else '材料',
            })
    results = []
    for r in rows:
        kw = (r.get('项目名') or r.get('kw') or '').strip()
        cat = (r.get('类别') or '材料').strip()
        try:
            price = float(r.get('单价') or r.get('price') or 0)
            qty = float(r.get('数量') or r.get('qty') or 1)
        except ValueError:
            print(f"\n  ⚠ 跳过无法解析单价/数量的行: {r}")
            continue
        unit = (r.get('单位') or r.get('unit') or '').strip()
        if cat == '检测':
            line = audit_testing(kw, price, unit, qty)
        else:
            line = audit_material(kw, price, unit, a.region, qty)
        results.append(line)
        show_line(line)
        pol = audit_policy(line.get('verdict', ''), cat)
        print(f"  政策口径: {pol.get('hint')}")
    # 汇总
    from collections import Counter
    cnt = Counter(x['verdict'] for x in results)
    print(f"\n  —— 汇总: 共 {len(results)} 行 → " + ' | '.join(f"{k}={v}" for k, v in cnt.items()))
    print('  ⚠ 虚高行仍需人工复核数量真实性与费用归属后再定核减，工具只给单价合理性初判。')


def cmd_explain(_):
    print("""
=== 三档判定口径 ===
  可核             报价落于可核信息价允许波动内(≤ +8%),同口径可比,证据力高。
  存疑(市场核参考)  只命中市场资讯/区间价(非权威信息价),作核减须与对方交叉印证。
  虚高(建议核减)    报价超可核可比价上限,建议核到信息价口径并要对方三单佐证。
  缺当期可比源      价库缺当期/该地区可比价,先 update 当期再核,勿臆断。
  (检测类另加) 仅历史参考  — 命中已废止 8 号文历史指导价,不作强制核减基准。
""")


def main():
    p = argparse.ArgumentParser(description='造价稽核官·三源比价(价库+检测库+政策口径)审计脚本')
    sub = p.add_subparsers(dest='cmd')
    a2 = sub.add_parser('audit', help='单行判定')
    a2.add_argument('kw', help='材料/检测项目名关键词')
    a2.add_argument('price', type=float, help='报价单价')
    a2.add_argument('unit', help='报价单位,如 t/m3/项(与价库单位不一致会提示先统一)')
    a2.add_argument('--cat', default='材料', choices=['材料', '检测', '其他'])
    a2.add_argument('--qty', type=float, default=1)
    a2.add_argument('--region', default=None, help='地区,如 广州')
    af = sub.add_parser('audit-file', help='报价单 csv 批量(列:项目名,数量,单价,单位,类别)')
    af.add_argument('file')
    af.add_argument('--region', default=None)
    sub.add_parser('explain', help='解释判定口径')
    a = p.parse_args()
    if not a.cmd:
        p.print_help(); return
    {'audit': cmd_audit, 'audit-file': cmd_audit_file,
     'explain': cmd_explain}[a.cmd](a)


if __name__ == '__main__':
    main()
