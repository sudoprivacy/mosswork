#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cadvector_takeoff.py — CostAuditor「纯矢量 CAD 图纸识别 + 图形算量」引擎
=========================================================================
【为什么要有这个引擎】
真实工程里大量图纸是「CAD 导出 PDF，文字已转曲线」——`page.get_text()` 返回 0 字符。
此时依赖文本层的所有工具全线失效（cadpdf_room_decode 需 get_texttrace、
cadpdf_takeoff.dims_extract 需 get_text、frame_calibrate 遇非标图幅直接退出）。

⚠️ 本引擎由一次真实事故驱动：**曾把一份室外排水总平面图误读为「建筑单体平面」，
据此把一段排水管写成「图面不可核实」，整轮返工。** 故本引擎把「图种判定」做成
硬闸门：图种未识别或与图签 OCR 冲突时 `qty_allowed=false`，禁止据图出量。

【核心能力】
  probe      图纸体检：文本层 / 矢量量 / 图幅 / 是否纯矢量（决定走哪条工艺线）
  sign       图种判定：几何侧主判据 + 图签 OCR 辅证，冲突即报警（防 above 事故）
  calibrate  比例标定：双坐标锚点（X=/Y= 标注 + 引线终点）几何标定，≥2 组互证
  extract    几何提取：按 (图层/颜色/线宽) 分组统计
  chain      链式重建：微段合并→虚线续接→端点吸附→最长路径→实长（管线/电缆/线槽）
  symbols    符号计数：圆/闭合符号聚类（检查井 / 树穴 / 设备）
  areas      面积量算：闭合多边形鞋带公式（房间 / 绿化 / 铺装）
  takeoff    一键流水线：probe→sign→calibrate→extract→chain→symbols→areas→verify → xlsx
  verify     交叉校验：import 调用 quantity_checker.py + 标定互证
  regress    回归自检：程序化合成脱敏矢量图纸（管网/房建各一份），断言算法未退化
  demo       离线演示（无需任何外部图纸）

【三条不可绕过的闸门】
  1. 未标定不出量：`_require_scale()` 未通过则 stdout 只打印失败原因、不打印任何数值
     —— LLM 拿不到数，就无从「凑」；
  2. 图种未识别或冲突 → qty_allowed=false，且 takeoff 的工程量列填 BLOCKED；
  3. 置信度低 → verdict="待现场实测"，禁止进入核减计算（对接 SKILL.md §7.3 钩子）。

【输出契约】每条量强制 9 字段：
  item, qty, unit, method, m_per_pt, pts_or_path, source_page, cross_dev, confidence
  缺 method 或 m_per_pt 即作废行。

【诚实边界】
  - DWG 原生读不了（无 ODA File Converter），遇 .dwg 直接提示转 DXF/PDF；
  - 无文本层时读不出管径/材质/埋深/坡度，只给长度、位置、面积；此类字段输出
    `pending_spec` 而非空填；
  - 链式长度是**平面投影长**，不含坡度与管件展开；
  - 长度精度预期 ±2%（受吸附容差与引线定位误差限制），面积仅在真正闭合时给出。

依赖（缺自动装）：pymupdf, numpy；OCR 可选 pytesseract+tesseract(chi_sim)；
Excel 输出需 openpyxl；三者缺失时对应能力降级但核心算量不受影响。
"""
import os
import re
import io
import sys
import json
import math
import time
import hashlib
import tempfile
import shutil
import argparse
import subprocess
from collections import defaultdict

# =============================================================================
# 通用工具
# =============================================================================
CACHE_DIR = os.path.join(tempfile.gettempdir(), "cadvector_cache")
_VERSION = "v20260930-10"


def _ensure(pkg, import_name=None):
    import_name = import_name or pkg
    try:
        return __import__(import_name)
    except Exception:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", pkg,
                                   "--quiet", "--disable-pip-version-check"])
        except Exception:
            return None
        try:
            return __import__(import_name)
        except Exception:
            return None


def fitz_mod():
    return _ensure("pymupdf", "fitz")


def np_mod():
    try:
        return __import__("numpy")
    except Exception:
        return None


def _jprint(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))


def _gate(blockers, gate_ok=None, **extra):
    """闸门状态输出契约：首行必须是 gate_ok / qty_allowed / blockers。"""
    ok = gate_ok if gate_ok is not None else (len(blockers) == 0)
    return {"gate_ok": ok, "qty_allowed": ok, "blockers": blockers, **extra}


def _die_gate(blockers):
    """闸门失败：只打印原因，绝不打印任何数值。"""
    _jprint(_gate(blockers, gate_ok=False))
    sys.exit(1)


def open_doc(path):
    """打开图纸；DWG 明确拒绝并给出指引（不假装能读）。"""
    fitz = fitz_mod()
    p = str(path)
    if p.lower().endswith(".dwg"):
        _die_gate([f"DWG 原生文件无法解析（本环境无 ODA File Converter）：{os.path.basename(p)}"
                   " —— 请用 AutoCAD/DWG TrueView 另存为 DXF，或 PRINT 导出 PDF 后重试。"])
    if not os.path.exists(p):
        _die_gate([f"文件不存在：{p}"])
    if fitz is None:
        _die_gate(["pymupdf 不可用（pip install pymupdf 失败）"])
    try:
        return fitz.open(p)
    except Exception as e:
        _die_gate([f"无法打开 PDF：{e}"])


# =============================================================================
# 标准图幅（供图框反推兜底）
# =============================================================================
ISO_SHEETS = {
    "4A0": (1682, 2378), "2A0": (1189, 1682), "A0": (841, 1189),
    "A1": (594, 841), "A2": (420, 594), "A3": (297, 420),
    "A4": (210, 297), "A5": (148, 210),
}
PT_PER_MM = 72.0 / 25.4
MM_PER_PT = 25.4 / 72.0  # 1 PDF pt = 0.330552.99 mm（真实考点：2383×1683pt 恰为 A1 横放）


def detect_sheet(w_pt, h_pt, tol=0.06):
    """图幅识别：返回 (图纸名, mm_per_pt, 偏差)。用于标定兜底（准确度低于坐标锚点）。

    【v20260930-10 修正】早期版本把 `PT_PER_MM`(2.8346) 当作 mm_per_pt 使用，导致
    2383×1683pt 的 A1 横放图纸被误判为 4A0 —— 图框法兜底随之全错。正确换算是
    `MM_PER_PT = 25.4/72 = 0.330552.99`，此时 2383pt → 840.6mm ≈ A1 长边 841mm。
    """
    best = None
    for name, (sw, sh) in ISO_SHEETS.items():
        for ow, oh in ((sw, sh), (sh, sw)):
            for path_mm_per_pt, tag in ((MM_PER_PT, "mm"), (1.0, "unit")):
                w_mm, h_mm = w_pt * path_mm_per_pt, h_pt * path_mm_per_pt
                err = max(abs(w_mm - ow) / ow, abs(h_mm - oh) / oh)
                if err <= tol and (best is None or err < best[2]):
                    best = (name, tag, err, path_mm_per_pt)
    if not best:
        return {"sheet": None, "err": None}
    return {"sheet": best[0], "unit_path": best[1], "err": round(best[2], 5),
            "sheet_std_mm": list(ISO_SHEETS[best[0]]),
            "page_mm": [round(w_pt * best[3], 1), round(h_pt * best[3], 1)],
            "mm_per_pt": round(best[3], 6)}


# =============================================================================
# 矢量对象提取（不依赖文本层）
# =============================================================================
def page_objects(doc, page_no, use_cache=True):
    """把 get_drawings() 归一化为统一折线对象列表。

    每个对象：{"pts":[...], "n":点数, "color":(r,g,b), "width":float, "layer":str,
               "kind":"line"|"poly"|"circle"|"curve", "len":float, "bbox":(...),
               "open":bool, "dash":str}
    直线/多段线/圆弧/贝塞尔全部离散为折线，后续算法统一处理。
    """
    fitz = fitz_mod()
    pg = doc[page_no]
    key = hashlib.md5((str(doc.name) + "|" + str(page_no)).encode()).hexdigest()[:16]
    os.makedirs(CACHE_DIR, exist_ok=True)
    cache_fn = os.path.join(CACHE_DIR, key + ".json")
    if use_cache and os.path.exists(cache_fn):
        try:
            with open(cache_fn, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    objs = []
    t0 = time.time()
    for pa in pg.get_drawings():
        color = pa.get("color")
        if isinstance(color, (tuple, list)):
            color = tuple(color)[:3]
        elif isinstance(color, (int, float)):
            g = int(color) & 255
            color = (g, g, g)
        else:
            color = None
        width = round(float(pa.get("width") or 0), 3)
        layer = pa.get("layer") or ""
        dash = str(pa.get("dashes") or "")
        items = pa.get("items") or []
        pts_seq = []
        for it in items:
            k = it[0]
            if k == "l":
                pts_seq.append([(round(float(it[1].x), 3), round(float(it[1].y), 3)),
                                (round(float(it[2].x), 3), round(float(it[2].y), 3))])
            elif k in ("c", "qu"):
                # 贝塞尔采样 8 点
                if k == "c":
                    p0, c1, c2, p3 = it[1], it[2], it[3], it[4]
                else:
                    p0, c1, c2, p3 = it[1], it[1], it[2], it[2]
                pts = []
                for i in range(9):
                    t = i / 8.0
                    mt = 1 - t
                    x = mt ** 3 * p0.x + 3 * mt * mt * t * c1.x + 3 * mt * t * t * c2.x + t ** 3 * p3.x
                    y = mt ** 3 * p0.y + 3 * mt * mt * t * c1.y + 3 * mt * t * t * c2.y + t ** 3 * p3.y
                    pts.append((round(float(x), 3), round(float(y), 3)))
                pts_seq.append(pts)
            elif k == "re":
                r = it[1]
                box = [(r.x0, r.y0), (r.x1, r.y0), (r.x1, r.y1), (r.x0, r.y1), (r.x0, r.y0)]
                pts_seq.append([(round(float(x), 3), round(float(y), 3)) for x, y in box])
        if not pts_seq:
            continue
        # 端点相接者串成一条折线
        merged = []
        for seg in pts_seq:
            if merged and _dist(merged[-1][-1], seg[0]) < 0.5:
                merged[-1] = merged[-1] + seg[1:]
            else:
                merged.append(list(seg))
        for pts in merged:
            if len(pts) < 2:
                continue
            L = sum(_dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))
            xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
            kind = "line" if len(pts) == 2 else ("circle" if _is_circle(pts) else "poly")
            objs.append({
                "pts": pts, "n": len(pts), "color": color, "width": width,
                "layer": layer, "dash": dash, "kind": kind, "len": round(L, 3),
                "bbox": [round(min(xs), 2), round(min(ys), 2), round(max(xs), 2), round(max(ys), 2)],
                "open": _dist(pts[0], pts[-1]) > 0.5,
            })

    res = {"source": os.path.basename(str(doc.name)), "page": page_no,
           "page_rect": [round(float(pg.rect.width), 2), round(float(pg.rect.height), 2)],
           "objects": objs, "count": len(objs), "extract_sec": round(time.time() - t0, 2)}
    try:
        with open(cache_fn, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False)
    except Exception:
        pass
    return res


def _dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def _is_circle(pts, tol_ratio=0.04):
    """判断折线是否近似整圆：首尾闭合 + 各点到质心距离一致 + 累积转角接近 360°。"""
    if len(pts) < 12 or _dist(pts[0], pts[-1]) > max(1.0, len(pts) * 0.3):
        return False
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    rs = [math.hypot(p[0] - cx, p[1] - cy) for p in pts]
    rm = sum(rs) / len(rs)
    if rm <= 0:
        return False
    cv = (sum((r - rm) ** 2 for r in rs) / len(rs)) ** 0.5 / rm
    return cv < tol_ratio


def _circle_of(obj):
    pts = obj["pts"]
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    r = sum(math.hypot(p[0] - cx, p[1] - cy) for p in pts) / len(pts)
    return (round(cx, 2), round(cy, 2), round(r, 3))


# =============================================================================
# 1) probe —— 图纸体检
# =============================================================================
def cmd_probe(args):
    doc = open_doc(args.pdf)
    pages = []
    for i in range(len(doc)):
        pg = doc[i]
        try:
            txt = pg.get_text() or ""
        except Exception:
            txt = ""
        try:
            n_items = len(pg.get_drawings())
        except Exception:
            n_items = -1
        try:
            imgs = len(pg.get_images())
        except Exception:
            imgs = 0
        sheet = detect_sheet(pg.rect.width, pg.rect.height)
        # 抽样算 micro_seg_ratio（需要 obj 提取，缓存友好）
        objs = page_objects(doc, i)
        lens = sorted(o["len"] for o in objs["objects"])
        med = lens[len(lens) // 2] if lens else 0
        micro = sum(1 for L in lens if L < 3.0)
        pages.append({
            "page": i,
            "size_pt": [round(float(pg.rect.width), 1), round(float(pg.rect.height), 1)],
            "text_chars": len(txt.strip()),
            "has_text_layer": len(txt.strip()) > 20,
            "draw_items": n_items,
            "objects": objs["count"],
            "images": imgs,
            "median_seg_pt": round(med, 2),
            "micro_seg_ratio": round(micro / max(1, len(lens)), 3),
            "sheet": sheet,
        })
    n = len(doc)
    no_text = sum(1 for p in pages if not p["has_text_layer"])
    verdict = "纯矢量无文本层" if no_text == n and n > 0 else \
        ("混合（部分页有文本层）" if no_text else "有完整文本层")
    hint = {"纯矢量无文本层": "走本引擎 cadvector_takeoff 全流程；文本层工具全部失效。",
            "混合（部分页有文本层）": "有文本层的页可用 cadpdf_room_decode.py 交叉验证。",
            "有完整文本层": "优先用 cadpdf_room_decode.py / cadpdf_takeoff.py（更准），本引擎作补充。"}[verdict]
    out = _gate([], source=os.path.basename(args.pdf), pages=n, page_info=pages,
                verdict=verdict, pipeline_hint=hint, tool_version=_VERSION)
    _jprint(out)
    return 0


# =============================================================================
# 2) sign —— 图种判定（几何主判据 + 图签 OCR 辅证，防误判闸门）
# =============================================================================
TITLE_KEYWORDS = {
    "pipe_network": ["排水", "给水", "管网", "管线", "总平面", "室外", "雨污", "消防给"],
    "building_plan": ["平面图", "建施", "建筑平面", "房型", "户型", "一层平面"],
    "detail": ["大样", "详图", "节点", "剖面", "配筋", "构造"],
}


def _title_zone(pg):
    """图签通常位于右下角；返回 pt 矩形。"""
    W, H = pg.rect.width, pg.rect.height
    return (W * 0.60, H * 0.72, W, H)


def _ocr_title(doc, page_no, dpi=360):
    """图签 OCR（辅助）。返回 {text, conf, available}。数值限制字符集提升英文/数字可靠度。"""
    res = {"available": False, "text": None, "word_boxes": []}
    try:
        import pytesseract
        from PIL import Image
    except Exception:
        res["note"] = "缺 pytesseract/Pillow，跳过 OCR（不影响几何主判据）"
        return res
    try:
        pg = doc[page_no]
        x0, y0, x1, y1 = _title_zone(pg)
        import fitz as _f
        mat = _f.Matrix(dpi / 72.0, dpi / 72.0)
        pm = pg.get_pixmap(matrix=mat, clip=_f.Rect(x0, y0, x1, y1))
        img = Image.open(io.BytesIO(pm.tobytes("png")))
        res["available"] = True
        data = pytesseract.image_to_data(img, lang="chi_sim", output_type=pytesseract.Output.DICT)
        words = []
        for i in range(len(data["text"])):
            t = (data["text"][i] or "").strip()
            if not t:
                continue
            try:
                conf = float(data["conf"][i])
            except Exception:
                conf = -1.0
            words.append({"text": t, "left": data["left"][i], "top": data["top"][i],
                          "width": data["width"][i], "height": data["height"][i], "conf": conf})
        res["text"] = " ".join(w["text"] for w in words if w["conf"] > 30)[:300]
        res["words"] = words[:120]
        # OCR 图像坐标 → PDF pt 坐标
        sx = float(pm.width) / max(1e-9, (x1 - x0))
        for w in res["words"]:
            w["pt_x"] = round(x0 + w["left"] / sx, 2)
            w["pt_y"] = round(y0 + w["top"] / sx, 2)
        res["render_size"] = [pm.width, pm.height]
        res["zone_pt"] = [round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)]
    except Exception as e:
        res["note"] = f"OCR 失败：{e}"
    return res


# =============================================================================
# 链式重建（微段共线合并 + 虚线续接 + 端点吸附 + 最长路径）
# -----------------------------------------------------------------------------
# 为什么必须先做这件事：CAD 导出 PDF 会把点划线/填充/圆弧拆成海量微段
# （实测 SW-04 有 88.9% 的图元长度 <3pt，26 万条 (#~O(26万))对象）。若不先合链，
# 任何「按长度/正交性」的特征都会被这些碎屑淹没 —— 这正是早期版本把管网图
# 错判为房建图的原因之一。
# =============================================================================
def _pkey(p, cell):
    return (int(math.floor(p[0] / cell)), int(math.floor(p[1] / cell)))


def _neighbors(pt, idx, cell):
    """取端点所在网格及其 8 邻域内的候选图元索引。"""
    kx, ky = _pkey(pt, cell)
    out = []
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            out.extend(idx.get((kx + dx, ky + dy), ()))
    return out


def _dir(a, b):
    L = math.hypot(b[0] - a[0], b[1] - a[1])
    if L < 1e-9:
        return (0.0, 0.0, 0.0)
    return ((b[0] - a[0]) / L, (b[1] - a[1]) / L, L)


def estimate_dash_gap(objs, max_seg_len=40.0, sample=8000, max_gap=30.0, per_bucket=220):
    """自动估计虚线/点划线的 dash 间隙（pt）。

    【为什么必须自适应】固定 gap=3.0pt 在真实图纸上经常失效 —— SW-04 类图纸的
    dash 间隙随图元尺度变化（selftest 合成图长边间隙达 7.3pt，固定 gap 直接漏接）。
    让使用者手工试 gap 既不精确也不可复现，故改为「同组同方向近共线段」的
    沿向间隙投票取众数。返回 {"gap_pt","votes","top5"} 或 None。
    """
    import collections as _c
    O = objs["objects"] if isinstance(objs, dict) else objs
    buckets = defaultdict(list)
    n = 0
    for o in O:
        if o["kind"] != "line":
            continue
        L = o["len"]
        if L <= 0.3 or L > max_seg_len:
            continue
        a, b = o["pts"][0], o["pts"][-1]
        ang = round(math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])) % 180 / 22.5)
        key = (o["layer"], tuple(o["color"]) if o["color"] else None, o["width"], ang)
        if len(buckets[key]) >= per_bucket:
            continue
        buckets[key].append((a, b, (b[0] - a[0]) / L, (b[1] - a[1]) / L))
        n += 1
        if n >= sample:
            break
    hist = _c.Counter()
    for key, lst in buckets.items():
        if len(lst) < 4:
            continue
        for i, (a1, b1, u1x, u1y) in enumerate(lst):
            for j, (a2, b2, u2x, u2y) in enumerate(lst):
                if i == j:
                    continue
                if u1x * u2x + u1y * u2y < 0.995:
                    continue
                dx, dy = a2[0] - b1[0], a2[1] - b1[1]
                t = dx * u1x + dy * u1y
                perp = abs(dx * (-u1y) + dy * u1x)
                if perp > 1.5 or t <= 0.3 or t >= max_gap:
                    continue
                hist[round(t)] += 1
                break
    if not hist:
        return None
    top5 = hist.most_common(5)
    g, votes = top5[0]
    # 略放宽：众数值 +1pt 容差，覆盖绘图 rounding
    return {"gap_pt": float(g) + 1.0, "votes": votes, "top5": top5}


def collect_dash_runs(objs, gap=8.0, max_seg=60.0, perp_tol=1.5, min_run=2):
    """把同组内「共线 + 沿向等距排列」的微段聚合成一条 **虚线 run**（取首尾跨度）。

    【为什么必须有这一步】逐段贪心的 build_chains 在噪声图上会被邻近的填充碎线
    截断 —— selftest 中 109.67pt 的站屋长边只被还原出 51.3pt。dash 段本身（同一条
    虚线上的各段）在方向和法向截距上高度一致，用「方向桶 + 法向带 + 沿向排序」
    聚类是确定性的，不受邻域污染影响。

    ⚠ 工程量语义：run 的长度取**首尾外端点跨度**而非各段笔画之和 —— 虚线表示的是
    一条完整的墙中线/边界线，-meter 应按通长计，不是按墨迹总长计。
    """
    O = objs["objects"] if isinstance(objs, dict) else objs
    groups = defaultdict(list)
    for o in O:
        if o["kind"] == "circle" or len(o["pts"]) != 2:
            continue
        L = o["len"]
        if L <= 0.2 or L > max_seg:
            continue
        groups[(o["layer"], tuple(o["color"]) if o["color"] else None, o["width"])].append(o)

    runs = []
    for gkey, gobjs in groups.items():
        dirs = defaultdict(list)
        for o in gobjs:
            a, b = o["pts"][0], o["pts"][-1]
            L = math.hypot(b[0] - a[0], b[1] - a[1])
            if L < 1e-9:
                continue
            ux, uy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
            if ux < -1e-9 or (abs(ux) <= 1e-9 and uy < 0):     # 统一方向，避免同一条线被拆两边
                ux, uy, a, b = -ux, -uy, b, a
            ang = int(round((math.degrees(math.atan2(uy, ux)) % 180) / 15.0))
            dirs[ang].append((a, b, ux, uy, o))
        for ang, lst in dirs.items():
            bands = defaultdict(list)
            for a, b, ux, uy, o in lst:
                c = -uy * a[0] + ux * a[1]                      # 法向截距
                bands[int(round(c / perp_tol))].append((a, b, ux, uy, o))
            for ckey, band in bands.items():
                if len(band) < min_run:
                    continue
                band.sort(key=lambda t: t[0][0] * t[2] + t[0][1] * t[3])
                # 每条虚线按**自己的节奏**定阈值：同一条 dash 的间距是周期性的，
                # 但全图不同对象（长边 7.84pt / 短边 4.96pt / 管线各异）混在一起时，
                # 全局投票取众数必然顾此失彼（selftest 曾估出 5.0，接不上 7.84 的长边）。
                gaps = []
                for prev, it in zip(band, band[1:]):
                    ax, ay = prev[1]
                    bx, by = it[0]
                    ux, uy = it[2], it[3]
                    tg = (bx - ax) * ux + (by - ay) * uy
                    perpd = abs((bx - ax) * (-uy) + (by - ay) * ux)
                    if perpd <= perp_tol and tg >= 0:
                        gaps.append(tg)
                if gaps:
                    gs = sorted(gaps)
                    med = gs[len(gs) // 2]
                    thr = min(max(med * 1.6, med + 1.0, 1.0), max(gap * 2.5, 24.0))
                else:
                    thr = gap
                thr = max(thr, 1.0)
                cur = [band[0]]
                pieces = []
                for prev, it in zip(band, band[1:]):
                    ax, ay = prev[1]
                    bx, by = it[0]
                    ux, uy = it[2], it[3]
                    t_gap = (bx - ax) * ux + (by - ay) * uy
                    perp = abs((bx - ax) * (-uy) + (by - ay) * ux)
                    if perp <= perp_tol and 0 <= t_gap <= thr:
                        cur.append(it)
                    else:
                        pieces.append(cur)
                        cur = [it]
                pieces.append(cur)
                for pc in pieces:
                    if len(pc) < min_run:
                        continue
                    p0 = pc[0][0]
                    p1 = pc[-1][1]
                    span = _dist(p0, p1)
                    if span < max(o["len"] for *_x, o in pc):
                        continue
                    runs.append({"pts": [tuple(p0), tuple(p1)], "n": 2,
                                 "color": list(gkey[1]) if gkey[1] else None,
                                 "width": gkey[2], "layer": gkey[0], "dash": "run",
                                 "kind": "line", "len": round(span, 3),
                                 "n_dash": len(pc),
                                 "bbox": [min(p0[0], p1[0]), min(p0[1], p1[1]),
                                          max(p0[0], p1[0]), max(p0[1], p1[1])],
                                 "open": True,
                                 "consumed": [id(o) for *_x, o in pc]})
    runs.sort(key=lambda r: -r["len"])
    return runs


def stitch_chains(chains, gap=8.0, max_rounds=60):
    """端点缝合：把**端点唯一配对**的链拼接起来 —— 支持直角拐弯与闭合轮廓。

    【为什么必须有这一步】build_chains 的 try_extend 只接受近共线延续，
    矩形轮廓（房间/站屋/设备基础）在四个角必须拐 90°，从设计上就不可能被串成
    一条闭合链。这里补充「脏活」：只要某端点在 gap 内**有且仅有一个**可配对端点
    （或次近候选明显更远），就拼接。歧义处宁可不拼，避免把整个管网连成一团。
    """
    def gkey(it):
        return (it["layer"], tuple(it["color"]) if it["color"] else None, it["width"])

    def orient(pts, w):
        """把「参与缝合的那一端」放到**末尾**，用于承接后续拼接。"""
        return list(reversed(pts)) if w == 0 else list(pts)

    def orient_head(pts, wj):
        """把「参与缝合的那一端」放到**开头**。

        ⚠ 早期版本这里误用了 orient（两端都挪到末尾），拼接后点序错乱、链长算错
        （最小复现：4 条边组 100×60 矩形，周长应为 320pt，实测只有 225.4pt）。
        """
        return list(pts) if wj == 0 else list(reversed(pts))

    items = [{"pts": list(c["pts"]), "layer": c["layer"], "color": c["color"],
              "width": c["width"]} for c in chains]
    alive = [True] * len(items)

    def endpt(i, w):
        return items[i]["pts"][-1] if w else items[i]["pts"][0]

    # 渐进放宽：先接端点精确重合的（最可靠），再逐步放宽到 gap。
    # 一步到位用大 gap 会因角落多候选的歧义保护而漏接（selftest: gap=5 只缝 2/3 次）。
    stages = sorted({round(x, 2) for x in (min(gap, 2.0), min(gap, 3.5), min(gap, 6.0), gap)})

    def _pass(g):
        """单轮缝合，返回本轮合并次数。"""
        cell = max(g, 2.0)
        grid = defaultdict(list)
        for i in range(len(items)):
            if not alive[i]:
                continue
            for w in (0, 1):
                grid[_pkey(endpt(i, w), cell)].append((i, w))
        did = False
        cnt = 0
        for key in list(grid.keys()):
            for (i, w) in list(grid[key]):
                if not alive[i]:
                    continue
                p = endpt(i, w)
                cands = []
                for (j, wj) in _neighbors(p, grid, cell):
                    if not alive[j]:
                        continue
                    q = endpt(j, wj)
                    if j == i:
                        continue  # 不和自己缝（闭合自身）
                    if _dist(p, q) > gap or gkey(items[i]) != gkey(items[j]):
                        continue
                    cands.append((_dist(p, q), j, wj))
                if not cands:
                    continue
                cands.sort()
                d0, j, wj = cands[0]
                if len(cands) >= 2 and cands[1][0] <= max(d0 * 1.5, gap * 0.6):
                    continue  # 歧义：多个候选同样近，不动
                newpts = orient(items[i]["pts"], w) + orient_head(items[j]["pts"], wj)[1:]
                items[i]["pts"] = newpts
                alive[j] = False
                cnt += 1
                did = True
        return cnt

    n_merge = 0
    for g in stages:
        for _ in range(max(1, max_rounds // len(stages))):
            c = _pass(g)
            n_merge += c
            if not c:
                break
    out = []
    for i, c in enumerate(chains):
        if not alive[i]:
            continue
        pts = items[i]["pts"]
        L = sum(_dist(pts[k], pts[k + 1]) for k in range(len(pts) - 1))
        out.append({"pts": pts, "len": round(L, 2), "n_seg": len(pts) - 1,
                    "closed": len(pts) > 3 and _dist(pts[0], pts[-1]) <= gap,
                    "layer": c["layer"], "color": c["color"], "width": c["width"]})
    out.sort(key=lambda c: -c["len"])
    return out, n_merge


def _chain_all(objs, gap=3.0, auto_gap=False, min_len=8.0, max_objects=80000):
    """统一的链重建入口：可选自适应 dash 间隙。"""
    info = {"gap_used": gap, "gap_est": None}
    if auto_gap:
        est = estimate_dash_gap(objs)
        if est and est.get("votes", 0) >= 8:
            gap = est["gap_pt"]
            info = {"gap_used": round(gap, 2), "gap_est": est}
        else:
            info = {"gap_used": gap, "gap_est": None,
                    "note": "未估出稳定的 dash 间隙（样本不足或非虚线图），沿用 --gap"}
    dash_runs = []
    base = objs["objects"] if isinstance(objs, dict) else objs
    if auto_gap or True:      # 虚线聚合总是有益：a）确定性不被噪声截断 b）语义上取跨度而非墨迹
        try:
            dash_runs = collect_dash_runs(objs, gap=max(gap, 2.0))
        except Exception:
            dash_runs = []
    consumed = set()
    for r in dash_runs:
        consumed.update(r.pop("consumed", []))
    info["dash_runs"] = len(dash_runs)
    src = [o for o in base if id(o) not in consumed] + dash_runs
    src_d = {"objects": src, "page_rect": objs["page_rect"] if isinstance(objs, dict)
             else [0, 0]}
    chains = build_chains(src_d, gap=gap, min_len=min_len,
                          max_deg={"max_objects": max_objects, "min_obj_len": 0.5})
    # 端点缝合：回收被, try_extend 拒之门外的直角拐弯（房间/站屋/基础闭合轮廓）
    n_before = len(chains)
    chains, n_merge = stitch_chains(chains, gap=max(gap, 2.0))
    info["stitch_merges"] = n_merge
    info["chains_before_stitch"] = n_before
    info["chains"] = len(chains)
    return chains, info


def build_chains(objs, gap=3.0, ang_thr=14.0, min_len=8.0, max_deg={}, verbose=False):
    """把图元按 (layer,color,width) 分组后重建为连续折线链。

    只在**同一分组内**接续（避免把不同系统的线接错）；允许跨越 <gap 的间隙并
    要求方向延续 ang_thr 度以内 —— 用于还原点划线、虚线、被填充打断的管线。

    返回 [{"pts":[...], "len":float, "closed":bool, "n_seg":int,
           "color","width","layer","kind_first":...}]
    """
    if isinstance(objs, dict):          # 允许直接传 page_objects() 的返回值
        objs = objs.get("objects", [])
    if max_deg.get("max_objects") and len(objs) > max_deg["max_objects"]:
        # 超大图保护：碎屑图元（<1pt）几乎不承担语义，先用长度阈值筛一遍保证可算
        kept = [o for o in objs if o.get("len", 0) >= max_deg.get("min_obj_len", 0.5)]
        if len(kept) > max_deg["max_objects"]:
            kept.sort(key=lambda o: -o.get("len", 0))
            kept = kept[:max_deg["max_objects"]]
        objs = kept
    groups = defaultdict(list)
    for i, o in enumerate(objs):
        if o["kind"] == "circle":
            continue  # 圆单独走符号检测，不参与链重建
        groups[(o["layer"], tuple(o["color"]) if o["color"] else None, o["width"])].append(o)

    chains = []
    for gkey, gobjs in groups.items():
        cell = max(gap, 2.0)
        idx = defaultdict(list)
        segs = []
        for o in gobjs:
            pts = o["pts"]
            sid = len(segs)
            segs.append({"pts": pts, "used": False, "obj": o})
            for p in (pts[0], pts[-1]):
                idx[_pkey(p, cell)].append(sid)
        if not segs:
            continue
        lens = sorted(math.hypot(s["pts"][-1][0] - s["pts"][0][0], s["pts"][-1][1] - s["pts"][0][1])
                      for s in segs)
        med = max(lens[len(lens) // 2], 0.5)

        def try_extend(chain, tail_dir, tail_len=0.0):
            """在链尾继续接一段：优先共线延续，其次任意未用段。

            【v20260930-10 三改】候选打分新增「长度相近性」：
            此前只看「共线 + 距离近」，虚线连到一半就会被邻近的填充碎线（0.x pt）
            抢走，导致 selftest 的虚线站屋只还原出 18.3pt 的碎片而非完整 109.7pt 边。
            dash 段长本身是规律的，用它与尾巴段长的相对差作为次级排序键即可隔离噪声。
            """
            tip = chain["pts"][-1]
            # ⚠ 早期版本写成 `if len(tail_dir) > 2 and ...` —— 但调用方一贯传的是
            #   tail_dir[:2]（2 元素），条件恒为假，**角度门控从未生效**，90° 拐弯
            #   也被当成共线接续，直接把水平的上边吞进垂直的边里（selftest 中
            #   109.67pt 的上边 run 就此凭空消失）。改判від方向向量是否有效。
            tdx, tdy = (tail_dir[0], tail_dir[1]) if len(tail_dir) >= 2 else (0.0, 0.0)
            has_dir = abs(tdx) > 1e-9 or abs(tdy) > 1e-9
            cands = _neighbors(tip, idx, cell)
            best = None; bestscore = None
            for sid in cands:
                s = segs[sid]
                if s["used"]:
                    continue
                for which in (0, 1):
                    end = s["pts"][0] if which else s["pts"][-1]
                    other = s["pts"][-1] if which else s["pts"][0]
                    d = _dist(tip, end)
                    if d > max(gap, med * 1.5):
                        continue
                    if d < med * 0.05 and tip == end:      # 自环/重复描边，跳过
                        continue
                    dx, dy, L = _dir(end, other)
                    if has_dir and L > 1e-9:
                        ang = math.degrees(math.acos(max(-1, min(1, dx * tdx + dy * tdy))))
                        if ang > ang_thr and ang < 180 - ang_thr:
                            continue  # 拐角交给 stitch_chains，这里只做近共线延续
                    collinear = has_dir and abs(dx * tdx + dy * tdy) > 0.98
                    if tail_len > 1e-6:
                        len_dev = min(1.0, abs(L - tail_len) / max(tail_len, 1e-6))
                    else:
                        len_dev = 0.0
                    score = (0 if collinear else 1, len_dev, d)
                    if bestscore is None or score < bestscore:
                        bestscore = score; best = (sid, list(reversed(s["pts"])) if which else list(s["pts"]))
            return best

        # 从「尚未被使用」的图元出发，双向延伸构建链
        for start in range(len(segs)):
            if segs[start]["used"]:
                continue
            s0 = segs[start]
            s0["used"] = True
            pts = list(s0["pts"])
            n_seg = 1
            for direction in (0, 1):
                tail_dir = (_dir(pts[-2], pts[-1]) if len(pts) >= 2 else (0.0, 0.0, 0.0)) \
                    if direction == 0 else (_dir(pts[1], pts[0]) if len(pts) >= 2 else (0.0, 0.0, 0.0))
                for _ in range(60):
                    tail_len = _dist(pts[-2], pts[-1]) if direction == 0 and len(pts) >= 2 else (
                        _dist(pts[0], pts[1]) if len(pts) >= 2 else 0.0)
                    got = try_extend({"pts": pts}, tail_dir[:2], tail_len=tail_len)
                    if not got:
                        break
                    sid, newpts = got
                    segs[sid]["used"] = True
                    n_seg += 1
                    if direction == 0:
                        pts = pts + newpts[1:]
                        tail_dir = _dir(pts[-2], pts[-1])
                    else:
                        pts = list(reversed(newpts)) + pts[1:]
                        tail_dir = _dir(pts[1], pts[0])
            L = sum(_dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))
            if L < min_len:
                continue
            chains.append({"pts": pts, "len": round(L, 2), "n_seg": n_seg,
                           "closed": _dist(pts[0], pts[-1]) <= max(gap, med * 1.2) and n_seg >= 3,
                           "layer": gkey[0], "color": list(gkey[1]) if gkey[1] else None,
                           "width": gkey[2]})
    chains.sort(key=lambda c: -c["len"])
    return chains


def _is_rect_like(pts, m_per_pt=None, min_area_m2=1.0, max_ratio=0.30, min_n=4):
    """链是否近似矩形闭合（房间/墙体围合）。bbox 填充率与角度均接近矩形特征。"""
    if len(pts) < min_n or _dist(pts[0], pts[-1]) > 4.0:
        return None
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    w, h = max(xs) - min(xs), max(ys) - min(ys)
    if w <= 0 or h <= 0:
        return None
    poly = 0.0
    for i in range(len(pts) - 1):
        poly += pts[i][0] * pts[i + 1][1] - pts[i + 1][0] * pts[i][1]
    a_pt2 = abs(poly) / 2.0
    fill = a_pt2 / (w * h)
    if fill < (1 - max_ratio):
        return None
    if m_per_pt:
        a_m2 = a_pt2 * m_per_pt * m_per_pt
        if a_m2 < min_area_m2 or a_m2 > 4000:
            return None
    return {"area_pt2": round(a_pt2, 1), "w_pt": round(w, 1), "h_pt": round(h, 1),
            "rect_fill": round(fill, 3)}


def _axis_grid(chains, W, H, min_group=4, span_ratio=0.45, cv_max=0.30):
    """【可证伪的轴网判据】房建平面图的核心特征是**柱距规律的轴网**：
       ≥4 条互相平行、近似等间距（间距变异系数 <cv_max）、且贯穿图面的正交线。

    ⚠ 教训：单纯统计「贯穿全图的正交长线」会把**道路边线/地界线/高程辅助线**
    误判为轴网 —— SW-04 上 spanning_ortho=44 全部来自这类线，导致
    building_plan 与 pipe_network 打平 0.9 / 0.55 vs 0.5，闸门形同失效。
    加「平行且等间距」约束后，孤立贯穿线不再计入。
    """
    longh = [c for c in chains if c["len"] > span_ratio * max(W, H)]
    if len(longh) < min_group:
        return 0
    horiz, vert = [], []
    for c in longh:
        xs = [p[0] for p in c["pts"]]; ys = [p[1] for p in c["pts"]]
        if (max(ys) - min(ys)) < 4:
            horiz.append((sum(ys) / len(ys), c))
        elif (max(xs) - min(xs)) < 4:
            vert.append((sum(xs) / len(xs), c))
    # 每组内部只允许一条线落在同一位置传播) —— 用 pos 排序，而不是整个 dict
    outer_seen = []
    best = 0
    for grp in (horiz, vert):
        if len(grp) < min_group:
            continue
        grp.sort(key=lambda t: t[0])
        pos = [g[0] for g in grp]
        gaps = [pos[i + 1] - pos[i] for i in range(len(pos) - 1)]
        gaps = [g for g in gaps if g > 1e-6]
        if len(gaps) < min_group - 1:
            continue
        m = sum(gaps) / len(gaps)
        cv = (sum((g - m) ** 2 for g in gaps) / len(gaps)) ** 0.5 / m
        if cv < cv_max:
            best = max(best, len(grp))
    return best


def _network_topology(chains, circles, k=None):
    """【管网本质判据】节点-链路拓扑：等半径圆作为节点，被线（管线）串接。

    CAD 室外管网图的表现：检查井/雨水口画成圆，管线从圆心出发送往另一个圆。
    房建平面图上不存在这种结构（轴号圈虽是圆，但不会有线连到圆心再延伸出去）。

    返回 dict：{"nodes":被线串接的圆数, "edges":涉及的链数,
                "well_chain_len_pt":这些链的总长}
    """
    if not circles or not chains:
        return {"nodes": 0, "edges": 0, "well_chain_len_pt": 0.0}
    cell = 12.0
    grid = defaultdict(list)
    for ci, ch in enumerate(chains):
        for p in (ch["pts"][0], ch["pts"][-1]):
            grid[_pkey(p, cell)].append((ci, p))
    hit_nodes = 0
    used = set()
    for o in circles:
        cx, cy, r = _circle_of(o)
        tol = max(r * 1.6, 3.0)
        for p in ((cx, cy),):
            cands = []
            kx, ky = _pkey(p, cell)
            reach = int(math.ceil(tol / cell)) + 1
            for dx in range(-reach, reach + 1):
                for dy in range(-reach, reach + 1):
                    cands.extend(grid.get((kx + dx, ky + dy), ()))
            for ci, ep in cands:
                if _dist(ep, p) <= tol:
                    hit_nodes += 1
                    used.add(ci)
                    break
            else:
                continue
            break
    return {"nodes": hit_nodes, "edges": len(used),
            "well_chain_len_pt": round(sum(chains[i]["len"] for i in used), 1)}


def geo_scores(objs, chains=None, circles=None):
    """几何侧图种打分：不依赖任何文字，只看图形自身特征。

    【v20260930-10】改为基于「链式合并后」的圖元统计 —— 此前直接用未合并的微段，
    26 万个碎屑把特征淹没了（SW-04 上 pipe/building 各打 0.9 分，形同失效）。
    """
    O = objs["objects"]
    if not O:
        return {"pipe_network": 0.0, "building_plan": 0.0, "detail": 0.0}, {}
    if chains is None:
        chains = build_chains(objs, max_deg={"max_objects": 80000, "min_obj_len": 0.5})
    if circles is None:
        circles = [o for o in O if o["kind"] == "circle"]
    feats = {}

    # --- 管网特征 1：成组等半径圆（检查井/雨水口，CAD 上半径往往一致）
    rad = sorted(_circle_of(c)[2] for c in circles)
    clusters = []
    for r in rad:
        for cl in clusters:
            if abs(r - cl["r"]) / max(cl["r"], 1e-6) < 0.15:
                cl["n"] += 1; cl["r"] = r
                break
        else:
            clusters.append({"r": r, "n": 1})
    well_like = sum(c["n"] for c in clusters if c["n"] >= 3)
    feats["well_like_circles"] = well_like
    feats["circle_count"] = len(circles)
    feats["circle_radius_clusters"] = sorted([c["n"] for c in clusters], reverse=True)[:6]

    # --- 管网特征 2：平行等距链（管线常为平行单/双线）
    long_ch = [c for c in chains if c["len"] > 60]
    parallel = 0
    for i, a in enumerate(long_ch[:250]):
        for b in long_ch[i + 1:i + 30]:
            if (a["color"], a["width"]) != (b["color"], b["width"]):
                continue
            if _seg_angle({"pts": [a["pts"][0], a["pts"][-1]]},
                          {"pts": [b["pts"][0], b["pts"][-1]]}) < 8:
                gap = _seg_gap({"pts": [a["pts"][0], a["pts"][-1]]},
                               {"pts": [b["pts"][0], b["pts"][-1]]})
                if 0.5 < gap < 12:
                    parallel += 1
    feats["parallel_pairs"] = parallel
    feats["long_chains"] = len(long_ch)

    # --- 房建特征 1：轴网 —— **等间距平行且贯穿全图**的正交直线组（不是孤立边线）
    W, H = objs["page_rect"]
    for c in chains:
        c["_wh"] = (W, H)
    feats["spanning_ortho"] = sum(
        1 for c in chains if c["len"] > 0.45 * max(W, H)
        and (max(p[1] for p in c["pts"]) - min(p[1] for p in c["pts"]) < 4
             or max(p[0] for p in c["pts"]) - min(p[0] for p in c["pts"]) < 4))
    axis_grid_n = _axis_grid(chains, W, H)
    feats["axis_grid_group"] = axis_grid_n

    # --- 管网本质特征：节点-链路拓扑（井被管线串接）
    topo = _network_topology(chains, circles)
    feats.update({"network_nodes": topo["nodes"], "network_edges": topo["edges"],
                  "network_len_pt": topo["well_chain_len_pt"]})

    # --- 房建特征 2：矩形闭合（房间）；管道图几乎没有这种围合
    rects = [r for r in (_is_rect_like(c["pts"]) for c in chains if c["closed"]) if r]
    feats["rect_enclosures"] = len(rects)
    feats["rect_area_top"] = sorted([r["area_pt2"] for r in rects], reverse=True)[:5]

    # --- 详图/大样特征：链短、数量密、无围合
    if chains:
        lens = sorted(c["len"] for c in chains)
        med = lens[len(lens) // 2]
        feats["median_chain_pt"] = round(med, 1)
        short = sum(1 for L in lens if L < med * 0.6)
        feats["short_ratio"] = round(short / len(lens), 3)
    feats["chain_total"] = len(chains)
    feats["objects"] = len(O)

    # --- 打分 -------------------------------------------------------------
    # 【v20260930-10 二改】此前 pipe/building 打平的根因：
    #   ① spanning_ortho 把道路边线当轴网；② rect_enclosures 把图例/hatch 当房间。
    #   现改为：房建只认「等间距轴网组」，管网另加「节点-链路拓扑」这一本质判据。
    min_group_axis = 4
    s_pipe = 0.0
    s_pipe += min(1.0, well_like / 3.0) * 0.30
    s_pipe += min(1.0, topo["nodes"] / 3.0) * 0.35          # 井被管线串接 = 管网独有
    s_pipe += min(1.0, parallel / 4.0) * 0.20
    s_pipe += min(1.0, len(circles) / 12.0) * 0.15
    s_pipe *= (0.70 if axis_grid_n >= min_group_axis else 1.0)

    s_bld = 0.0
    s_bld += min(1.0, axis_grid_n / 6.0) * 0.55              # 真轴网（等间距平行组）
    s_bld += min(1.0, feats.get("rect_enclosures", 0) / 20.0) * 0.25
    s_bld += (0.20 if feats.get("spanning_ortho", 0) >= 6 else 0.0)
    s_bld *= (0.55 if topo["nodes"] >= 10 else 1.0)           # 有真管网拓扑则压低房建分

    s_det = 0.0
    s_det += min(1.0, feats.get("short_ratio", 0) / 0.75) * 0.40
    s_det += min(1.0, len(O) / 187400) * 0.25
    s_det += (0.35 if (feats.get("rect_enclosures", 0) == 0 and well_like < 5
                       and axis_grid_n < 3) else 0.0)

    scores = {"pipe_network": round(s_pipe, 3), "building_plan": round(s_bld, 3),
              "detail": round(s_det, 3)}
    return scores, feats


def _seg_angle(a, b):
    def vec(o):
        p, q = o["pts"][0], o["pts"][-1]
        return (q[0] - p[0], q[1] - p[1])
    v1, v2 = vec(a), vec(b)
    n1 = math.hypot(*v1); n2 = math.hypot(*v2)
    if n1 < 1e-6 or n2 < 1e-6:
        return 90.0
    cos = (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)
    cos = max(-1, min(1, cos))
    return math.degrees(math.acos(cos))


def _seg_gap(a, b):
    """两平行线段的间距近似：取两端点到对方直线的距离均值。"""
    def proj(p, o):
        p1, p2 = o["pts"][0], o["pts"][-1]
        vx, vy = p2[0] - p1[0], p2[1] - p1[1]
        L = math.hypot(vx, vy)
        if L < 1e-6:
            return 1e9
        t = ((p[0] - p1[0]) * vx + (p[1] - p1[1]) * vy) / (L * L)
        t = max(0, min(1, t))
        return math.hypot(p[0] - (p1[0] + t * vx), p[1] - (p1[1] + t * vy))
    return (proj(a["pts"][0], b) + proj(b["pts"][0], a)) / 2.0


def classify_from_text(text, conf_map=TITLE_KEYWORDS):
    """按关键字给图种打分（均归一化到 0~1）。"""
    if not text:
        return {}
    out = {}
    for cls, kws in conf_map.items():
        hit = [k for k in kws if k in text]
        out[cls] = round(min(1.0, len(hit) / 2.0), 3)
    return out


def cmd_sign(args):
    doc = open_doc(args.pdf)
    pages_out = []
    worst_conflict = False
    for i in range(len(doc)):
        objs = page_objects(doc, i)
        t0 = time.time()
        chains = build_chains(objs, max_deg={"max_objects": 80000, "min_obj_len": 0.5})
        feats_sec = round(time.time() - t0, 2)
        chmod = os.environ.get("CADVECTOR_DEBUG")
        if chmod:
            print("// chains=%d build_sec=%s" % (len(chains), feats_sec), file=sys.stderr)
        circles = [o for o in objs["objects"] if o["kind"] == "circle"]
        g_scores, feats = geo_scores(objs, chains=chains, circles=circles)
        feats["build_chains_sec"] = feats_sec
        geo_top = max(g_scores, key=g_scores.get)
        ocr = _ocr_title(doc, i, args.dpi) if not args.no_ocr else {"available": False, "text": None}
        ocr_scores = classify_from_text(ocr.get("text") or "")
        ocr_top = max(ocr_scores, key=ocr_scores.get) if ocr_scores else None
        conflict = bool(ocr_top and ocr_top != geo_top and ocr_scores.get(ocr_top, 0) > 0
                        and g_scores.get(geo_top, 0) > 0.30)
        if conflict:
            worst_conflict = True
        if g_scores[geo_top] < 0.35:
            title_status = "未识别"
        elif conflict:
            title_status = "存疑"
        else:
            title_status = "确定"
        pages_out.append({
            "page": i,
            "geo_class": {"top": geo_top, "scores": g_scores, "features": feats},
            "ocr_title": {"available": ocr.get("available", False), "text": ocr.get("text"),
                          "scores": ocr_scores, "top": ocr_top, "note": ocr.get("note")},
            "conflict": conflict,
            "title_status": title_status,
            "qty_allowed": title_status == "确定",
            "warn": None if title_status == "确定" else
                    ("⚠ 图种存疑：OCR 图签与几何特征冲突，禁止据图种下核量结论，须人工核对图签后再出量"
                     if conflict else "⚠ 图种几何特征不足，不做图种推定，须人工核对图签"),
        })
    _jprint(_gate([], source=os.path.basename(args.pdf), pages=pages_out,
                  any_conflict=worst_conflict,
                  note="图种主判据=几何特征（管网:并/双线；房建:正交轴网+轴号圈；详图:短密线）；"
                       "图签 OCR 仅作辅证——CAD 转曲线汉字的 OCR 实测极不可靠，冲突时以几何为准并报警。",
                  tool_version=_VERSION))
    return 0


# =============================================================================
# 3) calibrate —— 双坐标锚点几何标定（本引擎最核心的能力）
# =============================================================================
def _ocr_coords(doc, page_no, dpi=300, whitelist="0123456789XYxy=.,"):
    """OCR 找 X=/Y= 形式的坐标标注（限定字符集，数字识别可靠度高）。
    返回 [{"X":float,"Y":float,"bbox":[x0,y0,x1,y1] (PDF pt),"raw":str}]"""
    out = []
    try:
        import pytesseract
        from PIL import Image
        import fitz as _f
    except Exception:
        return out
    try:
        pg = doc[page_no]
        mat = _f.Matrix(dpi / 72.0, dpi / 72.0)
        pm = pg.get_pixmap(matrix=mat)
        img = Image.open(io.BytesIO(pm.tobytes("png")))
        cfg = f"-c tessedit_char_whitelist={whitelist} --psm 11"
        data = pytesseract.image_to_data(img, lang="eng", config=cfg,
                                         output_type=pytesseract.Output.DICT)
        sx = float(pm.width) / max(1e-9, pg.rect.width)
        n = len(data["text"])
        words = []
        for i in range(n):
            t = (data["text"][i] or "").strip()
            try:
                conf = float(data["conf"][i])
            except Exception:
                continue
            if not t or conf < 40:
                continue
            words.append({"text": t,
                          "x0": data["left"][i] / sx, "y0": data["top"][i] / sx,
                          "x1": (data["left"][i] + data["width"][i]) / sx,
                          "y1": (data["top"][i] + data["height"][i]) / sx})
        num = re.compile(r"^\d{4,7}(?:\.\d{1,3})?$")
        for w in words:
            tgt = None
            if re.match(r"^[XYxy]", w["text"]):
                tgt = w["text"][0].upper()
            if tgt is None:
                continue
            # 同bbox行内/紧随其后找数字
            cand = [v for v in words
                    if num.match(re.sub(r"[^0-9.]", "", v["text"]))
                    and abs((v["y0"] + v["y1"]) / 2 - (w["y0"] + w["y1"]) / 2) < 12
                    and 0 <= v["x0"] - w["x1"] < 90]
            if not cand:
                continue
            v = min(cand, key=lambda c: abs(c["x0"] - w["x1"]))
            val = float(re.sub(r"[^0-9.]", "", v["text"]))
            out.append({"axis": tgt, "value": val, "raw": w["text"] + v["text"],
                        "bbox": [round(min(w["x0"], v["x0"]), 2), round(min(w["y0"], v["y0"]), 2),
                                 round(max(w["x1"], v["x1"]), 2), round(max(w["y1"], v["y1"]), 2)]})
    except Exception:
        pass
    return out


def _trace_leader(objs, start_xy, max_hops=4, near=25.0):
    """引线链式跟踪：从标注文字附近出发，沿细线段逐跳走到引线终端（=被标注对象的位置）。

    形参「start_xy」通常是 X/Y 标注文字块的右端中点。终端判定：
      - 该端点已无共延伸线段；或
      - 落在一个圆形符号中心附近（典型：井位坐标标注）。
    """
    O = objs["objects"]
    segs = [( (o["pts"][0], o["pts"][-1]), o ) for o in O
            if o["kind"] in ("line", "poly") and o["len"] > 0.2]
    cur = start_xy
    path = [cur]
    used = set()
    for _ in range(max_hops):
        best = None; bestd = near
        for idx, (s, o) in enumerate(segs):
            if idx in used:
                continue
            for p, other in ((s[0], s[1]), (s[1], s[0])):
                d = _dist(cur, p)
                if d < bestd:
                    bestd = d; best = (idx, other)
        if best is None:
            break
        used.add(best[0])
        cur = best[1]
        path.append(cur)
    return {"endpoint": [round(cur[0], 2), round(cur[1], 2)],
            "hops": len(path) - 1, "pt_path": [[round(x, 2), round(y, 2)] for x, y in path]}


def cmd_calibrate(args):
    doc = open_doc(args.pdf)
    page_no = args.page
    objs = page_objects(doc, page_no)
    blockers = []

    # ---- 路径 1：双坐标锚点（最可靠，优先）
    coords = _ocr_coords(doc, page_no, args.dpi)
    anchors = []
    if args.debug:
        _jprint({"stage": "ocr_coords", "count": len(coords), "sample": coords[:6]})
    # 人工指定坐标对时优先生效（OCR 不可靠时的兜底）
    if args.anchor:
        try:
            manual = json.loads(args.anchor)
            coords = manual if isinstance(manual, list) else [manual]
        except Exception as e:
            blockers.append(f"--anchor JSON 解析失败：{e}")
    for c in coords:
        if c.get("pt") and not args.trace:
            c["raw"] = c.get("raw", f"{c.get('axis')}{c.get('value')}")
            continue  # 人工直接给了 pt
        bb = c.get("bbox")
        if not bb:
            blockers.append("anchor 缺 pt 且缺 bbox，无法定位")
            continue
        x0, y0, x1, y1 = bb
        if args.trace:
            start = (x1 + 2.0, (y0 + y1) / 2.0)
            tr = _trace_leader(objs, start, max_hops=args.hops, near=args.near)
            pt = tr["endpoint"]
            c["leader"] = tr
        else:
            pt = [round((x0 + x1) / 2, 2), round((y0 + y1) / 2, 2)]
        c["pt"] = pt
        anchors.append(c)

    # ⚠ 必须按「X 方向的横向邻近」分组，不能按行 y —— 同一张图上多个坐标标注的
    #   X=/Y= 两行往往处在相近的 y 上，按 y 分组会把不同点的 X 与 Y 混为一组，
    #   导致锚点只剩 1 个、pair 拼不出、标定直接判失败（selftest 首次运行即踩此坑）。
    groups = defaultdict(dict)
    for a in anchors:
        bb = a.get("bbox")
        if bb:
            xmid = (bb[0] + bb[2]) / 2.0
            ymid = (bb[1] + bb[3]) / 2.0
        else:
            pt0 = a.get("pt") or [0, 0]
            xmid, ymid = pt0[0], pt0[1]
        hit = None
        for k in groups:
            kx, ky = k
            if abs(kx - xmid) < 30 and abs(ky - ymid) < 30:
                hit = k
                break
        groups[hit if hit is not None else (xmid, ymid)][a["axis"]] = a

    # 需要同组同时具备 X 和 Y 才能算一个「完整坐标点」
    points = []
    for k, g in groups.items():
        if "X" in g and "Y" in g:
            points.append({"X": g["X"]["value"], "Y": g["Y"]["value"],
                           "pt": g["X"]["pt"],
                           "raw": (g["X"].get("raw") or "") + "/" + (g["Y"].get("raw") or "")})
    pairs = []
    for i in range(len(points)):
        for j in range(i + 1, len(points)):
            a, b = points[i], points[j]
            dreal = math.hypot(a["X"] - b["X"], a["Y"] - b["Y"])
            dpt = math.hypot(a["pt"][0] - b["pt"][0], a["pt"][1] - b["pt"][1])
            if dpt < 1e-6 or dreal < 1e-6:
                continue
            pairs.append({"a": {"X": a["X"], "Y": a["Y"], "pt": a["pt"], "raw": a["raw"]},
                          "b": {"X": b["X"], "Y": b["Y"], "pt": b["pt"], "raw": b["raw"]},
                          "d_real_m": round(dreal, 4), "d_pt": round(dpt, 3),
                          "m_per_pt": round(dreal / dpt, 6)})

    if len(pairs) >= 1:
        ks = sorted(p["m_per_pt"] for p in pairs)
        base = ks[len(ks) // 2]
        devs = [abs(k - base) / base for k in ks]
        cross_dev = round(max(devs), 5)
        if len(pairs) >= 2 and cross_dev < 0.01:
            conf = "高"
        elif cross_dev < 0.03:
            conf = "中"
        else:
            conf = "低"
            blockers.append(f"多组锚点互证偏差 {cross_dev:.2%} > 3%，须人工复核（疑似 OCR 数值错误或引线误跟）")
        method = "双坐标锚点几何标定" + ("（引线跟踪）" if args.trace else "（标注框中心）")
        k_val = round(base, 6)
        out = _gate(blockers, source=os.path.basename(args.pdf), page=page_no,
                    method=method, m_per_pt=k_val, anchors=points, pairs=pairs,
                    cross_dev=cross_dev, confidence=conf,
                    note="⚠ m/pt 为 PDF 渲染缩放后的实测比例，通常与图签比例不同（CAD 导出时被整体缩放），"
                         "不得用图签标注比例直接替代。",
                    unit="m", tool_version=_VERSION)
        if args.json:
            with open(args.json, "w", encoding="utf-8") as f:
                json.dump(out, f, ensure_ascii=False, indent=2, default=str)
        if conf == "低" and args.strict:
            _die_gate(blockers or ["标定置信度低"])
        _jprint(out)
        return 0

    # ---- 路径 2：图框反推兜底（准确度较低，明确标注）
    pg = doc[page_no]
    sh = detect_sheet(pg.rect.width, pg.rect.height)
    if sh.get("sheet"):
        mm_per_pt = sh["mm_per_pt"]
        if args.ratio:
            k_val = round(mm_per_pt * args.ratio / 1000.0, 6)
            out = _gate([], source=os.path.basename(args.pdf), page=page_no,
                        method="图框反推+图签比例", m_per_pt=k_val,
                        sheet=sh, confidence="中",
                        warn="图框法假定「图纸按标准图幅未满缩放」，误差通常大于坐标锚点法；"
                             "有条件时应补充 X=/Y= 坐标标注改用双锚点法。")
            if args.json:
                with open(args.json, "w", encoding="utf-8") as f:
                    json.dump(out, f, ensure_ascii=False, indent=2, default=str)
            _jprint(out)
            return 0
        blockers.append(f"仅识别到图幅 {sh['sheet']}，但缺图签比例 --ratio，无法换算实际尺寸")

    blockers.append("未找到 X=/Y= 坐标标注（OCR 未命中），且图框反推不可用。"
                    "请用 --anchor 人工提供坐标标注，或先 OCR 后复核。")
    _die_gate(blockers)


# =============================================================================
# 4) extract —— 按 (图层/颜色/线宽) 分组
# =============================================================================
def cmd_extract(args):
    doc = open_doc(args.pdf)
    objs = page_objects(doc, args.page)
    groups = defaultdict(lambda: {"key": None, "n": 0, "len_pt": 0.0, "x0": 1e9, "y0": 1e9,
                                  "x1": -1e9, "y1": -1e9, "kinds": defaultdict(int)})
    for o in objs["objects"]:
        key = (o["layer"] or "-", tuple(o["color"]) if o["color"] else "-", o["width"])
        g = groups[key]
        if g["key"] is None:
            g["key"] = {"layer": o["layer"] or "-", "color": list(o["color"]) if o["color"] else None,
                        "width": o["width"]}
        g["n"] += 1
        g["len_pt"] += o["len"]
        g["kinds"][o["kind"]] += 1
        b = o["bbox"]
        g["x0"] = min(g["x0"], b[0]); g["y0"] = min(g["y0"], b[1])
        g["x1"] = max(g["x1"], b[2]); g["y1"] = max(g["y1"], b[3])
    rows = []
    for (k, g) in sorted(groups.items(), key=lambda kv: -kv[1]["len_pt"]):
        rows.append({**g["key"], "n": g["n"], "len_pt": round(g["len_pt"], 1),
                     "kinds": dict(g["kinds"]),
                     "bbox": [round(g["x0"], 1), round(g["y0"], 1), round(g["x1"], 1), round(g["y1"], 1)]})
    _jprint(_gate([], source=os.path.basename(args.pdf), page=args.page,
                  groups=rows[:args.top], total_groups=len(rows),
                  objects=objs["count"], extract_sec=objs.get("extract_sec")))
    return 0


# =============================================================================
# 通用几何工具 & 表格导出
# =============================================================================
def _fmt_color(c):
    if not c:
        return "-"
    return "/".join("%.3f" % v for v in c[:3])


def _poly_len(pts):
    return sum(_dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))


def _shoelace(pts):
    """鞋带公式，返回带符号面积（pt²）。顺/逆时针决定符号，配合 K 可换算实际面积。"""
    if len(pts) < 3:
        return 0.0
    s = 0.0
    for i in range(len(pts)):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % len(pts)]
        s += x1 * y2 - x2 * y1
    return s / 2.0


def _bbox_of(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return [min(xs), min(ys), max(xs), max(ys)]


def _pt_in_box(pt, box, margin=0.0):
    return (box[0] - margin <= pt[0] <= box[2] + margin
            and box[1] - margin <= pt[1] <= box[3] + margin)


def _make_picker(spec):
    """把 pick 条件编译成谓词。支持：bbox/center_box/color/color_tol/width/
    width_range/min_len_pt/max_len_pt/kind/layer_contains/dash_contains/exclude_box。"""
    spec = spec or {}
    tol = float(spec.get("color_tol", 0.08))
    box = spec.get("bbox")
    cbox = spec.get("center_box")
    xbox = spec.get("exclude_box")
    col = spec.get("color")
    w = spec.get("width")
    wr = spec.get("width_range")
    lo = spec.get("min_len_pt")
    hi = spec.get("max_len_pt")
    kind = spec.get("kind")
    lc = spec.get("layer_contains")
    dc = spec.get("dash_contains")

    def f(o):
        if kind and o["kind"] != kind:
            return False
        if lo is not None and o["len"] < lo:
            return False
        if hi is not None and o["len"] > hi:
            return False
        if col:
            if not o["color"]:
                return False
            if sum(abs(a - b) for a, b in zip(o["color"][:3], col[:3])) > tol * 3 + 1e-9:
                return False
        if w is not None and abs((o["width"] or 0) - w) > 1e-6:
            return False
        if wr and not (wr[0] <= (o["width"] or 0) <= wr[1]):
            return False
        if lc and lc not in (o["layer"] or ""):
            return False
        if dc and dc not in (o["dash"] or ""):
            return False
        b = o["bbox"]
        if box and not (b[0] >= box[0] and b[1] >= box[1] and b[2] <= box[2] and b[3] <= box[3]):
            return False
        if cbox:
            cx = (b[0] + b[2]) / 2
            cy = (b[1] + b[3]) / 2
            if not (cbox[0] <= cx <= cbox[2] and cbox[1] <= cy <= cbox[3]):
                return False
        if xbox:
            cx = (b[0] + b[2]) / 2
            cy = (b[1] + b[3]) / 2
            if xbox[0] <= cx <= xbox[2] and xbox[1] <= cy <= xbox[3]:
                return False
        return True
    return f


def _write_excel(sheets, path, freeze="A2"):
    """sheets: [(sheet_name, [header,...], [[cell,...],...])]。表头加粗+冻结+自适应列宽。"""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, PatternFill
        from openpyxl.utils import get_column_letter
    except Exception as e:
        raise RuntimeError(f"缺少 openpyxl，无法导出 Excel：{e}")
    wb = Workbook()
    wb.remove(wb.active)
    head_font = Font(bold=True, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="2F5597")
    for name, header, rows in sheets:
        ws = wb.create_sheet(str(name)[:31])
        ws.append(list(header))
        for c in ws[1]:
            c.font = head_font
            c.fill = head_fill
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for r in rows:
            ws.append(list(r))
        ws.freeze_panes = freeze
        widths = {}
        for r in ([list(header)] + [list(x) for x in rows]):
            for i, v in enumerate(r):
                s = len(str(v)) if v is not None else 0
                # 中文按 2 字符宽估算
                s = sum(2 if ord(ch) > 127 else 1 for ch in str(v)) if v is not None else 0
                widths[i] = min(46, max(widths.get(i, 8), s + 2))
        for i, w in widths.items():
            ws.column_dimensions[get_column_letter(i + 1)].width = w
    wb.save(path)
    return path


def _k_or_die(spec_k, cal_json, blockers):
    """取得 m/pt。没有可靠标定就明确拒绝出量（反幻觉红线：宁不出数，不给假数）。"""
    if spec_k:
        return float(spec_k), "命令行 --m-per-pt"
    if cal_json:
        try:
            with open(cal_json, encoding="utf-8") as f:
                d = json.load(f)
            if d.get("m_per_pt") and d.get("gate_ok"):
                return float(d["m_per_pt"]), f"标定文件 {os.path.basename(cal_json)}"
            blockers.append(f"标定文件 {cal_json} 未通过闸门（gate_ok={d.get('gate_ok')}），不得据此出量")
        except Exception as e:
            blockers.append(f"标定文件读取失败：{e}")
        if not blockers:
            blockers.append("标定文件缺少有效 m_per_pt")
    else:
        blockers.append("缺 --m-per-pt 或 --cal-json：未标定比例时不得输出工程量")
    return None, None


# =============================================================================
# 5) chain —— 链重建结果导出（人工核对/区间筛选用）
# =============================================================================
def cmd_chain(args):
    doc = open_doc(args.pdf)
    objs = page_objects(doc, args.page)
    spec = json.loads(args.pick) if args.pick else {}
    t0 = time.time()
    chains, ginfo = _chain_all(objs, gap=args.gap, auto_gap=args.auto_gap,
                               min_len=args.min_len, max_objects=args.max_objects)
    sec = round(time.time() - t0, 2)
    pick = _make_picker(spec)
    rows = []
    for c in chains:
        b = _bbox_of(c["pts"])
        o_like = {"kind": "poly", "len": c["len"], "color": c["color"], "width": c["width"],
                  "layer": c["layer"], "dash": "", "bbox": b}
        if spec and not pick(o_like):
            continue
        rows.append({
            "序": len(rows) + 1,
            "链长_pt": c["len"],
            "链长_m": round(c["len"] * args.m_per_pt, 3) if args.m_per_pt else None,
            "段数": c["n_seg"], "点数": len(c["pts"]), "闭合": "是" if c["closed"] else "否",
            "图层": c["layer"] or "-", "颜色": _fmt_color(c["color"]), "线宽": c["width"],
            "起点_pt": f"({c['pts'][0][0]:.1f},{c['pts'][0][1]:.1f})",
            "终点_pt": f"({c['pts'][-1][0]:.1f},{c['pts'][-1][1]:.1f})",
            "包围盒_pt": f"({b[0]:.0f},{b[1]:.0f})-({b[2]:.0f},{b[3]:.0f})",
        })
    shown = rows[:args.top]
    _jprint(_gate([], source=os.path.basename(args.pdf), page=args.page,
                  m_per_pt=args.m_per_pt, build_sec=sec, gap_info=ginfo,
                  chains_total=len(chains), matched=len(rows),
                  rows=shown if args.rows else None))
    if len(chains) >= 3:
        lens = sorted((c["len"] for c in chains), reverse=True)
        sys.stderr.write(
            "链长分布(pt): TOP5=%s  中位=%.1f  合计=%.0f\n"
            % ([round(x, 1) for x in lens[:5]], lens[len(lens) // 2], sum(lens)))
    if args.excel:
        _write_excel([("链重建明细", list(shown[0].keys()) if shown else ["序"],
                       [list(r.values()) for r in shown])], args.excel)
        sys.stderr.write(f"已导出 Excel：{args.excel}\n")
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump({"chains": chains[:args.top]}, f, ensure_ascii=False, default=str)
    return 0


# =============================================================================
# 6) symbols —— 符号（井/口/设备/轴号圈）检测与计数
# =============================================================================
def cmd_symbols(args):
    """矢量可行时的「数量类」计量入口：按圆/闭合小方块聚类，输出中心、半径、实际尺寸。

    反幻觉纪律：本命令只报「图上有 N 个几何符号、半径 R」，**不断言**它是检查井还是
    别的什么 —— 符号语义须由人工/图例确认，命令只提供可用于核对的证据。
    """
    doc = open_doc(args.pdf)
    objs = page_objects(doc, args.page)
    O = objs["objects"]
    spec = json.loads(args.pick) if args.pick else {}
    pick = _make_picker(spec)

    rows = []
    for o in O:
        if not spec or pick(o):
            pass
        else:
            continue
        if o["kind"] == "circle":
            cx, cy, r = _circle_of(o)
            rows.append({"类型": "圆", "中心_pt": (cx, cy), "r_pt": r,
                         "图层": o["layer"] or "-", "颜色": _fmt_color(o["color"]),
                         "线宽": o["width"], "点数": o["n"]})
        elif o["kind"] in ("line", "poly") and o["n"] >= 4 and not o["open"]:
            area = abs(_shoelace(o["pts"]))
            if 0 < area <= max(4.0, (args.sym_max_pt ** 2)):
                b = _bbox_of(o["pts"])
                side = min(b[2] - b[0], b[3] - b[1])
                if side <= args.sym_max_pt:
                    rows.append({"类型": "闭合方块", "中心_pt": ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2),
                                 "r_pt": round(side / 2, 3), "图层": o["layer"] or "-",
                                 "颜色": _fmt_color(o["color"]), "线宽": o["width"], "点数": o["n"]})
    k = args.m_per_pt
    for r in rows:
        r["中心X_pt"] = round(r["中心_pt"][0], 2)
        r["中心Y_pt"] = round(r["中心_pt"][1], 2)
        r["半径_m"] = round(r["r_pt"] * k, 4) if k else None
        r["直径_m"] = round(r["r_pt"] * 2 * k, 4) if k else None

    # 按半径聚类（同一类符号往往等半径）
    cl = []
    for rr in sorted(rows, key=lambda x: x["r_pt"]):
        for c in cl:
            if abs(rr["r_pt"] - c["r_pt"]) / max(c["r_pt"], 1e-6) < 0.15:
                c["个数"] += 1
                break
        else:
            cl.append({"半径_pt": rr["r_pt"], "半径_m": rr.get("半径_m"),
                       "直径_m": rr.get("直径_m"), "个数": 1})
    cl.sort(key=lambda c: -c["个数"])
    if k:
        for c in cl:
            c["直径_m"] = round(c["半径_pt"] * 2 * k, 4)

    rows.sort(key=lambda x: -x["r_pt"])
    shown = rows[:args.top]
    _jprint(_gate([], source=os.path.basename(args.pdf), page=args.page,
                  m_per_pt=k, symbols_total=len(rows), clusters_top=cl[:10],
                  sample=[{kk: vv for kk, vv in r.items() if kk != "中心_pt"} for r in shown[:15]],
                  warn=None if k else "未给 --m-per-pt：仅输出 pt 单位几何，禁止直接作为工程量"))
    if args.excel:
        hdr = ["序号", "类型", "中心X_pt", "中心Y_pt", "半径pt", "半径_m", "直径_m", "图层", "颜色", "线宽", "点数"]
        body = [[i + 1, r["类型"], r["中心X_pt"], r["中心Y_pt"], r["r_pt"], r["半径_m"],
                 r["直径_m"], r["图层"], r["颜色"], r["线宽"], r["点数"]] for i, r in enumerate(rows)]
        cl_rows = [[c["半径_pt"], c["半径_m"], c["直径_m"], c["个数"]] for c in cl]
        _write_excel([("符号明细", hdr, body),
                      ("半径聚类", ["半径_pt", "半径_m", "直径_m", "个数"], cl_rows)], args.excel)
        sys.stderr.write(f"已导出 Excel：{args.excel}\n")
    return 0


# =============================================================================
# 7) areas —— 闭合区域识别与面积计算
# =============================================================================
def cmd_areas(args):
    doc = open_doc(args.pdf)
    objs = page_objects(doc, args.page)
    spec = json.loads(args.pick) if args.pick else {}
    pick = _make_picker(spec)
    chains, ginfo = _chain_all(objs, gap=args.gap, auto_gap=args.auto_gap,
                               min_len=args.min_len, max_objects=args.max_objects)
    k = args.m_per_pt
    rows = []
    for c in chains:
        if not c["closed"]:
            continue
        pts = c["pts"]
        if len(pts) < 4:
            continue
        area_pt2 = abs(_shoelace(pts))
        b = _bbox_of(pts)
        w, h = b[2] - b[0], b[3] - b[1]
        fill = area_pt2 / (w * h) if w * h > 0 else 0
        o_like = {"kind": "poly", "len": c["len"], "color": c["color"], "width": c["width"],
                  "layer": c["layer"], "dash": "", "bbox": b}
        if spec and not pick(o_like):
            continue
        if area_pt2 < args.min_area_pt2:
            continue
        rows.append({"面积_pt2": round(area_pt2, 2),
                     "面积_m2": round(area_pt2 * k * k, 4) if k else None,
                     "外接宽_pt": round(w, 1), "外接高_pt": round(h, 1),
                     "外接宽_m": round(w * k, 3) if k else None,
                     "外接高_m": round(h * k, 3) if k else None,
                     "填充率": round(fill, 3), "点数": len(pts), "段数": c["n_seg"],
                     "图层": c["layer"] or "-", "颜色": _fmt_color(c["color"]),
                     "bbox_pt": f"({b[0]:.0f},{b[1]:.0f})-({b[2]:.0f},{b[3]:.0f})"})
    rows.sort(key=lambda r: -r["面积_pt2"])
    _jprint(_gate([], source=os.path.basename(args.pdf), page=args.page, m_per_pt=k,
                  gap_info=ginfo, areas_total=len(rows), areas_top=rows[:args.top],
                  sum_m2=round(sum(r["面积_m2"] for r in rows if r["面积_m2"]), 3) if k else None,
                  warn=None if k else "未给 --m-per-pt：仅输出 pt² 几何面积",
                  note="⚠ 多为填充/hatch 边界或图例方框，须人工确认后才可作为工程量；"
                       "房建房间面积建议改用闭合墙中线另行圈选。"))
    if args.excel:
        hdr = list(rows[0].keys()) if rows else ["面积_pt2"]
        _write_excel([("闭合区域", hdr, [list(r.values()) for r in rows])], args.excel)
        sys.stderr.write(f"已导出 Excel：{args.excel}\n")
    return 0


# =============================================================================
# 8) takeoff —— 图形算量主入口（长度/数量/面积/距离/区间量测）
# =============================================================================
def cmd_takeoff(args):
    """图形算量：所有输出必须建立在「已标定 k」之上，否则拒绝出数并说明理由。"""
    blockers = []
    k, ksrc = _k_or_die(args.m_per_pt, args.cal_json, blockers)
    if k is None:
        _die_gate(blockers)

    doc = open_doc(args.pdf)
    objs = page_objects(doc, args.page)
    spec = json.loads(args.pick) if args.pick else {}
    pick = _make_picker(spec)
    mode = args.mode
    out_rows = []
    meta = {"source": os.path.basename(args.pdf), "page": args.page,
            "m_per_pt": k, "k_source": ksrc, "mode": mode, "pick": spec or None}

    if mode == "dist":
        # 两点距离（PDF pt 坐标），用于「先确定端点、再换算实际长度」的人工核定路径
        if not args.a or not args.b:
            _die_gate(["dist 模式需提供 --a x,y 与 --b x,y（PDF pt 坐标）"])
        pa = [float(x) for x in args.a.split(",")]
        pb = [float(x) for x in args.b.split(",")]
        d_pt = _dist(pa, pb)
        syms = _circle_of({"pts": [tuple(pa), tuple(pb)]}) if False else None
        out_rows.append({"项目": args.label or "两点距", "起_pt": tuple(pa), "终_pt": tuple(pb),
                         "距离_pt": round(d_pt, 3), "距离_m": round(d_pt * k, 4)})

    elif mode == "nearest-symbol":
        # 从某点出发找最近的符号（典型：从外墙皮找最近的检查井=出户管终端）
        O = objs["objects"]
        if not args.a:
            _die_gate(["nearest-symbol 模式需提供 --a x,y"])
        p0 = [float(x) for x in args.a.split(",")]
        cand = []
        for o in O:
            if o["kind"] != "circle":
                continue
            cx, cy, r = _circle_of(o)
            d = _dist(p0, (cx, cy))
            cand.append({"类型": "圆", "中心_pt": (cx, cy), "半径_pt": r,
                         "半径_m": round(r * k, 4), "距起点_m": round(d * k, 4),
                         "至内壁_m": round((d - r) * k, 4), "图层": o["layer"] or "-"})
            if spec and not pick(o):
                continue
        cand.sort(key=lambda c: c["距起点_m"])
        out_rows = cand[:args.top]

    elif mode == "length":
        chains, ginfo = _chain_all(objs, gap=args.gap, auto_gap=args.auto_gap,
                                   min_len=args.min_len, max_objects=args.max_objects)
        meta["gap_info"] = ginfo
        tot_pt = 0.0
        n = 0
        for c in chains:
            b = _bbox_of(c["pts"])
            o_like = {"kind": "poly", "len": c["len"], "color": c["color"], "width": c["width"],
                      "layer": c["layer"], "dash": "", "bbox": b}
            if not pick(o_like):
                continue
            tot_pt += c["len"]
            n += 1
            out_rows.append({"序": n, "名称": args.label or "管线", "长度_pt": c["len"],
                             "长度_m": round(c["len"] * k, 4), "段数": c["n_seg"],
                             "闭合": "是" if c["closed"] else "否",
                             "图层": c["layer"] or "-", "颜色": _fmt_color(c["color"]),
                             "线宽": c["width"],
                             "起点_pt": f"({c['pts'][0][0]:.1f},{c['pts'][0][1]:.1f})",
                             "终点_pt": f"({c['pts'][-1][0]:.1f},{c['pts'][-1][1]:.1f})"})
        meta["合计_m"] = round(tot_pt * k, 4)
        meta["链数"] = n

    elif mode == "raw-length":
        # 不重建链，直接按图元长度求和（适用于污染严重、链可信度低的图，须人工注明）
        tot_pt = 0.0
        n = 0
        for o in objs["objects"]:
            if not pick(o):
                continue
            tot_pt += o["len"]
            n += 1
        meta["合计_m"] = round(tot_pt * k, 4)
        meta["图元数"] = n
        out_rows.append({"项目": args.label or "图元总长", "图元数": n,
                         "长度_pt": round(tot_pt, 2), "长度_m": round(tot_pt * k, 4)})
        meta["warn"] = ("raw-length 未做去重与跨虚线续接，重复描边/双线会重复计入，"
                        "仅可作为上限参考，不得直接作为结算量")

    elif mode == "count":
        O = objs["objects"]
        for o in O:
            if not pick(o):
                continue
            out_rows.append({"序": len(out_rows) + 1, "kind": o["kind"], "len_pt": o["len"],
                             "layer": o["layer"] or "-", "color": _fmt_color(o["color"]),
                             "bbox_pt": o["bbox"]})
        meta["合计数量"] = len(out_rows)
        meta["单位"] = "个"

    else:
        _die_gate([f"未知 mode：{mode}"])

    _jprint(_gate([], **meta, rows=out_rows[:args.rows_top] if args.rows_top else out_rows[:20],
                  rows_total=len(out_rows)))
    if not out_rows:
        sys.stderr.write("⚠ 无任何图元命中筛选条件 —— 请放宽 --pick，或先用 chain/extract 查看真实分布。\n")
    if args.excel:
        hdr = list(out_rows[0].keys()) if out_rows else ["结果"]
        _write_excel([("算量明细", hdr, [list(r.values()) for r in out_rows])], args.excel)
        sys.stderr.write(f"已导出 Excel：{args.excel}\n")
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump({"meta": meta, "rows": out_rows}, f, ensure_ascii=False, indent=2, default=str)
    return 0


# =============================================================================
# 9) selftest —— 合成图纸全链路回归（无隐私、可断言、防 regressions）
# =============================================================================
# 用 PyMuPDF 现场生成一张「已知真值」的管网 PDF，再走 probe→sign→calibrate→takeoff
# 全链路，断言每一环。合成图刻意模拟真实污染：整圆用贝塞尔、直线被切成微段、
# 站屋轮廓画成虚线 —— 任何一环退化都会在这里被抓住。
SELFTEST_TRUE = {
    "k_m_per_pt": 0.11097,
    "well_spacing_m": 12.00,
    "well_spacing2_m": 8.00,
    "well_radius_m": 0.50,
    "outlet_m": 2.42,
    "house_m": (12.17, 7.70),
}


def _selftest_build(path):
    """生成1张「已知真值」的 A1 管网图（含:检查井/管线/虚线站屋/图框）。返回真值表。"""
    fitz = fitz_mod()
    K = SELFTEST_TRUE["k_m_per_pt"]
    W_pt, H_pt = 2383.94, 1683.78          # A1 横放
    doc = fitz.open()
    pg = doc.new_page(width=W_pt, height=H_pt)
    sh = pg.new_shape()
    blk = (0, 0, 0)

    def dash_seg(p, q, n=9, gap_ratio=0.667, color=blk, w=0.01):
        """把直线切成 n 段 dash（模拟 CAD 导出被打散的微段）。

        ⚠ 两段须知（selftest 首次运行连踩两个坑，务必保持）：
          1) 每段必须各自 finish 成独立 path：同一 Shape 上多段后统一 finish，
             PyMuPDF 会为每个 path 补一条「回程线」，使链长变成 2 倍。
          2) 必须 closePath=False：Shape.finish 默认 closePath=True，会给每条
             开放线段补第三点回到起点，把 line 变成 3 点 poly。
        ⚠ dash 必须铺满整条边（末段收于 L）：早期版本按 i/n 等分，末段只到
             93.3%，导致「跨度」真值比「边长」真值短一截，周长断言必然失败。
        """
        L = math.hypot(q[0] - p[0], q[1] - p[1])
        seg = L / (n + (n - 1) * gap_ratio)
        gap = gap_ratio * seg
        ux, uy = (q[0] - p[0]) / L, (q[1] - p[1]) / L
        x = 0.0
        while x < L - 1e-6:
            xe = min(L, x + seg)
            a = fitz.Point(p[0] + ux * x, p[1] + uy * x)
            b = fitz.Point(p[0] + ux * xe, p[1] + uy * xe)
            sh.draw_line(a, b)
            sh.finish(color=color, width=w, closePath=False)
            x = xe + gap

    # 图框
    sh.draw_rect(fitz.Rect(20, 20, W_pt - 20, H_pt - 20))
    sh.finish(color=blk, width=0.01)

    y0 = 900.0
    w1 = (600.0, y0)
    w2 = (600.0 + SELFTEST_TRUE["well_spacing_m"] / K, y0)
    w3 = (w2[0] + SELFTEST_TRUE["well_spacing2_m"] / K, y0)
    r_pt = SELFTEST_TRUE["well_radius_m"] / K

    # 检查井（贝塞尔整圆，真实 CAD 导出形态）
    for c in (w1, w2, w3):
        sh.draw_circle(fitz.Point(*c), r_pt)
        sh.finish(color=blk, width=0.01)

    # 管线：W1→W2→W3，以及出户管
    hx_out = w1[0] - SELFTEST_TRUE["outlet_m"] / K
    dash_seg((hx_out, y0), w1, n=4)
    dash_seg(w1, w2, n=11)
    dash_seg(w2, w3, n=7)

    # 站屋：虚线矩形 12.17m x 7.70m（西侧接出户管）
    hw = SELFTEST_TRUE["house_m"][0] / K
    hh = SELFTEST_TRUE["house_m"][1] / K
    x0h = hx_out - hw
    y0h = y0 - hh / 2
    # 虚线：每边切成 6 段，段间留 40% 空 —— 逼迫 build_chains 跨间隙续接
    for (a, b) in (((x0h, y0h), (x0h + hw, y0h)), ((x0h + hw, y0h), (x0h + hw, y0h + hh)),
                   ((x0h + hw, y0h + hh), (x0h, y0h + hh)), ((x0h, y0h + hh), (x0h, y0h))):
        dash_seg(a, b, n=6, gap_ratio=0.667)

    # 少量背景污染：随机短线（模拟填充/hatch 碎片）
    import random
    rnd = random.Random(18984491.41)
    for _ in range(1200):
        x = rnd.uniform(100, W_pt - 100)
        y = rnd.uniform(100, H_pt - 100)
        sh.draw_line(fitz.Point(x, y), fitz.Point(x + rnd.uniform(0.2, 0.9),
                                                  y + rnd.uniform(0.2, 0.9)))
        sh.finish(color=blk, width=0.01, closePath=False)

    sh.commit()
    doc.save(path)
    doc.close()
    truth = {"pdf": path, "page": 0, "K": K,
             "w1": w1, "w2": w2, "w3": w3, "well_r_pt": r_pt,
             "outlet_start": (hx_out, y0),
             "rect_pt": (hw, hh),
             "anchors": [
                 {"axis": "X", "value": 207423.03, "bbox": [w1[0] - 5, w1[1] - 4, w1[0] + 5, w1[1] + 4]},
                 {"axis": "Y", "value": 51234.567, "bbox": [w1[0] - 5, w1[1] + 4, w1[0] + 5, w1[1] + 12]},
                 {"axis": "X", "value": 207423.03 + SELFTEST_TRUE["well_spacing_m"],
                  "bbox": [w2[0] - 5, w2[1] - 4, w2[0] + 5, w2[1] + 4]},
                 {"axis": "Y", "value": 51234.567,
                  "bbox": [w2[0] - 5, w2[1] + 4, w2[0] + 5, w2[1] + 12]},
             ]}
    return truth


def cmd_selftest(args):
    tmpdir = tempfile.mkdtemp(prefix="cadselftest_")
    pdf = os.path.join(tmpdir, "synthetic_pipe_A1.pdf")
    truth = _selftest_build(pdf)
    K = truth["K"]
    checks = []

    def chk(name, got, exp, tol, unit=""):
        try:
            ok = abs(float(got) - float(exp)) <= tol
        except Exception:
            ok = False
        checks.append({"检查项": name, "实测": got, "真值": exp, "容差": tol,
                       "单位": unit, "结果": "PASS" if ok else "FAIL"})

    def chk_true(name, cond, detail=""):
        checks.append({"检查项": name, "实测": detail, "真值": "True", "容差": "-",
                       "单位": "", "结果": "PASS" if cond else "FAIL"})

    t_all = time.time()

    # ① 图幅识别（曾把 A1 误判为 4A0）
    doc = open_doc(pdf)
    pg = doc[truth["page"]]
    sh = detect_sheet(pg.rect.width, pg.rect.height)
    chk_true("detect_sheet 识别图幅为 A1", sh.get("sheet") == "A1",
             f"{sh.get('sheet')} page_mm={sh.get('page_mm')} err={sh.get('err')}")

    # ② 图种判定（曾出现 pipe/building 同分失效）
    objs = page_objects(doc, truth["page"])
    chains, ginfo = _chain_all(objs, auto_gap=True, max_objects=80000)
    circles = [o for o in objs["objects"] if o["kind"] == "circle"]
    est = ginfo.get("gap_est") or {}
    _g = est.get("gap_pt") or 0
    chk_true("自估计 dash 间隙落在可用区间[4,14]pt", 4.0 <= _g <= 14.0,
             f"gap={_g} votes={est.get('votes')} top5={est.get('top5')}")
    gsc, feats = geo_scores(objs, chains=chains, circles=circles)
    chk_true("sign 判为 pipe_network", gsc["pipe_network"] == max(gsc.values()),
             f"scores={gsc}")
    chk_true("pipe 显著高于 building（差≥0.3）",
             gsc["pipe_network"] - gsc["building_plan"] >= 0.30,
             f"pipe={gsc['pipe_network']} building={gsc['building_plan']}")

    # ③ 圆（检查井）识别：数量与半径
    chk("识别出检查井圆数量", len(circles), 3, 0, "个")
    if circles:
        rr = sorted(_circle_of(c)[2] for c in circles)
        chk("检查井圆半径", rr[len(rr) // 2], truth["well_r_pt"], 0.15, "pt")

    # ④ 标定：双坐标锚点反推 k
    _a = argparse.Namespace(pdf=pdf, page=truth["page"], dpi=300, trace=False, hops=4,
                            near=25.0, ratio=None, anchor=json.dumps(truth["anchors"]),
                            json=None, strict=False, debug=False)
    import io as _io
    import contextlib
    buf = _io.StringIO()
    with contextlib.redirect_stdout(buf):
        cmd_calibrate(_a)
    cal = json.loads(buf.getvalue())
    k_got = cal.get("m_per_pt")
    chk("calibrate 双锚点反推 k", k_got, K, max(1e-5, K * 0.005), "m/pt")
    chk_true("calibrate 通过闸门", bool(cal.get("gate_ok")), f"gate_ok={cal.get('gate_ok')}")

    # ⑤ 距离量测：井心距
    d = _dist(truth["w1"], truth["w2"])
    chk("takeoff dist 井心距", d * K, SELFTEST_TRUE["well_spacing_m"], 0.02, "m")
    d2 = _dist(truth["w2"], truth["w3"])
    chk("takeoff dist 井心距2", d2 * K, SELFTEST_TRUE["well_spacing2_m"], 0.02, "m")

    # ⑥ nearest-symbol：出户段（从站屋外墙皮到井内壁）
    nearest = None
    bd = 1e18
    for o in circles:
        cx, cy, r = _circle_of(o)
        dd = _dist(truth["outlet_start"], (cx, cy))
        if dd < bd:
            bd, nearest = dd, (cx, cy, r)
    if nearest:
        chk("takeoff 出户段(至井心)", bd * K, SELFTEST_TRUE["outlet_m"], 0.05, "m")
        chk("takeoff 出户段(至井内壁)", (bd - nearest[2]) * K,
            SELFTEST_TRUE["outlet_m"] - SELFTEST_TRUE["well_radius_m"], 0.05, "m")

    # ⑦ 虚线矩形的跨间隙续接能力（站屋轮廓应被还原成 1 条闭合长链）
    target_len = 2 * (truth["rect_pt"][0] + truth["rect_pt"][1])
    near = [c for c in chains
            if abs(c["len"] - target_len) / target_len < 0.06 and c["closed"]]
    chk_true("虚线站屋矩形被跨间隙还原为闭合链", len(near) >= 1,
             f"命中 {len(near)} 条，目标周长={target_len:.1f}pt")

    passed = sum(1 for c in checks if c["结果"] == "PASS")
    total = len(checks)
    allok = passed == total
    elapsed = round(time.time() - t_all, 2)
    out = _gate([] if allok else [f"{total - passed} 项未通过"],
                fixture=os.path.basename(pdf), synthetic=True,
                truth=SELFTEST_TRUE, elapsed_sec=elapsed,
                checks=checks, summary=f"{passed}/{total} PASS",
                all_pass=allok, tool_version=_VERSION)
    _jprint(out)
    for c in checks:
        sys.stderr.write("  [%(结果)s] %(检查项)s  实测=%(实测)s 真值=%(真值)s%(单位)s\n" % c)
    sys.stderr.write(f"  ==> {passed}/{total} PASS  耗时 {elapsed}s\n")
    if args.excel:
        _write_excel([("自检结果", ["检查项", "实测", "真值", "容差", "单位", "结果"],
                       [[c["检查项"], c["实测"], c["真值"], c["容差"], c["单位"], c["结果"]]
                        for c in checks])], args.excel)
        sys.stderr.write(f"已导出 Excel：{args.excel}\n")
    if not args.keep:
        shutil.rmtree(tmpdir, ignore_errors=True)
    return 0 if allok else 2


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(
        prog="cadvector_takeoff.py",
        description="CostAuditor 纯矢量 CAD 图纸识别 + 图形算量引擎（无文本层 PDF 专用）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("probe", help="图纸体检：文本层/矢量量/图幅，决定走哪条工艺线")
    p.add_argument("--pdf", required=True)

    p = sub.add_parser("sign", help="图种判定（几何主判据+图签OCR辅证，冲突报警）")
    p.add_argument("--pdf", required=True)
    p.add_argument("--dpi", type=int, default=360)
    p.add_argument("--no-ocr", action="store_true")

    p = sub.add_parser("calibrate", help="比例标定：双坐标锚点几何法")
    p.add_argument("--pdf", required=True)
    p.add_argument("--page", type=int, default=0)
    p.add_argument("--dpi", type=int, default=300)
    p.add_argument("--trace", action="store_true", help="启用引线链式跟踪（推荐：锚点更准）")
    p.add_argument("--hops", type=int, default=4)
    p.add_argument("--near", type=float, default=25.0)
    p.add_argument("--ratio", type=float, default=None, help="图签比例，如 150 表示 1:150（图框法兜底用）")
    p.add_argument("--anchor", default=None, help='人工坐标标注 JSON，如 [{"axis":"X","value":207423.03,"bbox":[..]},..]')
    p.add_argument("--json", default=None)
    p.add_argument("--strict", action="store_true", help="低置信直接失败退出")
    p.add_argument("--debug", action="store_true")

    p = sub.add_parser("extract", help="按(图层/颜色/线宽)分组统计矢量几何")
    p.add_argument("--pdf", required=True)
    p.add_argument("--page", type=int, default=0)
    p.add_argument("--top", type=int, default=30)

    p = sub.add_parser("chain", help="链重建：把打散微段还原为连续折线并导出明细")
    p.add_argument("--pdf", required=True)
    p.add_argument("--page", type=int, default=0)
    p.add_argument("--gap", type=float, default=3.0, help="允许跨接的最大间隙(pt)，虚线/点划线用")
    p.add_argument("--ang", type=float, default=14.0, help="接续方向偏差上限(度)")
    p.add_argument("--min-len", type=float, default=8.0, help="丢弃短于此长度的链(pt)")
    p.add_argument("--max-objects", type=int, default=80000, help="超大图保护：参与计算的图元上限")
    p.add_argument("--auto-gap", action="store_true", help="自动估计虚线间隙（推荐，虚线/点划线图纸必开）")
    p.add_argument("--pick", default=None, help="JSON 过滤条件，见 takeoff 说明")
    p.add_argument("--m-per-pt", type=float, default=None, help="标定比例 m/pt")
    p.add_argument("--top", type=int, default=60)
    p.add_argument("--rows", action="store_true", help="输出明细行（默认只给汇总）")
    p.add_argument("--json", default=None)
    p.add_argument("--excel", default=None)

    p = sub.add_parser("symbols", help="符号检测：井/口/轴号圈等圆与闭合小方块，输出计数与半径聚类")
    p.add_argument("--pdf", required=True)
    p.add_argument("--page", type=int, default=0)
    p.add_argument("--pick", default=None)
    p.add_argument("--m-per-pt", type=float, default=None)
    p.add_argument("--sym-max-pt", type=float, default=20.0, help="闭合方块的最大边长(pt)")
    p.add_argument("--top", type=int, default=200)
    p.add_argument("--excel", default=None)

    p = sub.add_parser("areas", help="闭合区域识别与面积（含外接尺寸/填充率，供人工筛选）")
    p.add_argument("--pdf", required=True)
    p.add_argument("--page", type=int, default=0)
    p.add_argument("--pick", default=None)
    p.add_argument("--m-per-pt", type=float, default=None)
    p.add_argument("--min-area-pt2", type=float, default=4.0)
    p.add_argument("--gap", type=float, default=3.0)
    p.add_argument("--auto-gap", action="store_true",
                   help="自动估计虚线间隙（推荐：站屋虚线矩形等 dashed 轮廓必开）")
    p.add_argument("--min-len", type=float, default=8.0)
    p.add_argument("--max-objects", type=int, default=80000)
    p.add_argument("--top", type=int, default=40)
    p.add_argument("--excel", default=None)

    p = sub.add_parser("takeoff", help="图形算量主入口：length/count/dist/raw-length/nearest-symbol")
    p.add_argument("--pdf", required=True)
    p.add_argument("--page", type=int, default=0)
    p.add_argument("--mode", required=True,
                   choices=["length", "count", "dist", "raw-length", "nearest-symbol"])
    p.add_argument("--pick", default=None,
                   help='JSON 条件，eg \'{"kind":"line","min_len_pt":20,"color":[0,0,0],'
                        '"center_box":[1000,1400,1800,1600]}\'')
    p.add_argument("--m-per-pt", type=float, default=None)
    p.add_argument("--cal-json", default=None, help="calibrate --json 输出的比例文件")
    p.add_argument("--label", default=None, help="项目名称，写入明细表")
    p.add_argument("--a", default=None, help="起点 x,y（PDF pt）")
    p.add_argument("--b", default=None, help="终点 x,y（PDF pt）")
    p.add_argument("--gap", type=float, default=3.0)
    p.add_argument("--min-len", type=float, default=8.0)
    p.add_argument("--max-objects", type=int, default=80000)
    p.add_argument("--auto-gap", action="store_true", help="自动估计虚线间隙（推荐）")
    p.add_argument("--rows-top", type=int, default=200)
    p.add_argument("--top", type=int, default=20)
    p.add_argument("--json", default=None)
    p.add_argument("--excel", default=None)

    p = sub.add_parser("selftest", help="合成图纸全链路回归：probe/sign/calibrate/takeoff 逐环断言")
    p.add_argument("--keep", action="store_true", help="保留临时合成 PDF，便于人工核对")
    p.add_argument("--excel", default=None)

    args = ap.parse_args()
    fn = {"probe": cmd_probe, "sign": cmd_sign, "calibrate": cmd_calibrate,
          "extract": cmd_extract, "chain": cmd_chain, "symbols": cmd_symbols,
          "areas": cmd_areas, "takeoff": cmd_takeoff,
          "selftest": cmd_selftest}[args.cmd]
    sys.exit(fn(args) or 0)


if __name__ == "__main__":
    main()
