#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""细粒度 X=/Y= 坐标搜索（TILE=800, dpi 170/230/300, psm 11）

依赖：PyMuPDF(fitz) / pytesseract / Pillow / tesseract 可执行文件，均为可选依赖。
⚠ 曾有教训：顶层裸 import 会让缺依赖的用户看到 ModuleNotFoundError 堆栈而不是可执行的
   处置指引，无从判断"装什么、怎么装"。改为 try/except 捕获后给出明确安装命令与降级路径。
"""
import sys, os, re, io, json

_MISSING = []
try:
    import fitz
except ImportError:
    fitz = None
    _MISSING.append("PyMuPDF(fitz)")
try:
    import pytesseract
except ImportError:
    pytesseract = None
    _MISSING.append("pytesseract")
try:
    from PIL import Image
except ImportError:
    Image = None
    _MISSING.append("Pillow")

if _MISSING:
    sys.stderr.write(
        "✗ 缺少可选依赖：%s\n"
        "  安装：pip install %s\n"
        "  另需系统级 tesseract 可执行文件（含 chi_sim 中文模型）：\n"
        "    Windows  → 装 UB Mannheim Tesseract OCR 并勾选中文；\n"
        "    Debian/Ubuntu → apt install tesseract-ocr tesseract-ocr-chi-sim；\n"
        "    macOS    → brew install tesseract tesseract-lang\n"
        "  说明：本脚本属图纸坐标搜索的增强路径，缺失不影响技能主流程，"
        "  可改用 scripts/cadvector_takeoff.py（纯矢量、仅需 PyMuPDF）完成标定与算量。\n"
        % ("、".join(_MISSING), " ".join(
            {"PyMuPDF(fitz)": "pymupdf", "pytesseract": "pytesseract",
             "Pillow": "Pillow"}[m] for m in _MISSING))
    )
    sys.exit(2)

PDF = sys.argv[1]
PAGE = int(sys.argv[2])
OUTD = sys.argv[3]
os.makedirs(OUTD, exist_ok=True)

doc = fitz.open(PDF)
pg = doc[PAGE]
W, H = pg.rect.width, pg.rect.height

PAT_X = re.compile(r"[Xx×][=＝:：]\s*(\d{5,7}[.,]\d{1,4})")
PAT_Y = re.compile(r"[Yy][=＝:：]\s*(\d{4,7}[.,]\d{1,4})")

hits = []
seen = set()
for dpi in (170, 230, 300):
    zoom = dpi / 72.0
    pm = pg.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
    img = Image.open(io.BytesIO(pm.tobytes("png"))).convert("RGB")
    iw, ih = img.size
    TILE = 800
    nx = (iw + TILE - 1) // TILE
    ny = (ih + TILE - 1) // TILE
    for ty in range(ny):
        for tx in range(nx):
            box = (tx * TILE, ty * TILE, min((tx + 1) * TILE, iw), min((ty + 1) * TILE, ih))
            key = (dpi, tx, ty)
            sub = img.crop(box)
            try:
                txt = pytesseract.image_to_string(sub, lang="chi_sim+eng",
                                                  config="--psm 11 -c tessedit_char_whitelist=115679011.29.XxYy=.:, ")
            except Exception:
                continue
            mx = PAT_X.search(txt)
            my = PAT_Y.search(txt)
            if not (mx or my):
                continue
            cx = (box[0] + box[2]) / 2.0 / zoom
            cy = (box[1] + box[3]) / 2.0 / zoom
            hits.append({"dpi": dpi, "tile": [tx, ty],
                         "xv": mx.group(1) if mx else None,
                         "yv": my.group(1) if my else None,
                         "cx_pt": round(cx, 1), "cy_pt": round(cy, 1),
                         "tile_pt": [round(box[0] / zoom, 1), round(box[1] / zoom, 1),
                                     round(box[2] / zoom, 1), round(box[3] / zoom, 1)],
                         "raw": txt.replace("\n", " ")[:160]})
    print(f"[dpi={dpi}] 累计 {len(hits)}", flush=True)

json.dump({"page": PAGE, "size_pt": [W, H], "hits": hits},
          open(os.path.join(OUTD, "coord_hits2.json"), "w"), ensure_ascii=False, indent=1)
print("TOTAL", len(hits))
