#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
takeoff_toolkit.py — cn-cost-ref「工具驱动精准算量」工具箱
==========================================================
依赖（缺失时自动 pip install）：ezdxf, pymupdf, Pillow, numpy

子命令：
  dxf      从 DXF 提取几何工程量（线长 / 多段线面积 / 圆面积 / 图块计数），按图层分类
  pdf      将 PDF 图纸集逐页渲染为高清 PNG（供 image 视觉工具识别）
  pdftext  提取 PDF 文本与疑似尺寸标注（正则）
  scale    图像比例尺标定（已知尺寸法 / `--bar` 比例尺条法），输出 scale.json
  measure  在已标定图像上量测长度 / 多边形面积
  boq      汇总各来源工程量并输出 CSV / JSON
  check    调用 quantity_checker.py 做交叉校验（锚固 / 含量 / 指标）

【v20260930-10 欠账清偿】
  - `check` / `boq` 此前未注册子解析器、无法调用（SKILL.md §6.7 承诺悬空），现已接线；
  - `dxf_extract` 此前对 INSERT 仅计数不展开（图块内几何全部漏量），现用 `virtual_entities()`
    递归展开；并补 TEXT / MTEXT / DIMENSION 实体抽取（此前无文本层则完全无法判定）；
  - `scale_calibrate` 增 `--bar` 比例尺条法（此前只有"已知尺寸法"一种）。

设计原则：
  - 只量化"几何"，不判断"是否计入清单"；计入规则由模块四/五/七把控。
  - 所有量测必须带比例尺标定；未标定则拒绝输出工程量（防单位错误）。
  - 与模块六 6.7 校验、模块七规则库联动：程序化结果须与视觉/经验交叉验证。
  - 【v20260930-10】图块展开按 `MAX_INSERT_DEPTH` 限深，避免自引用块死循环；展开产物单独并入
    宿主图层统计，避免与顶层实体重复计数（见 unit_note）。
  ⚠ 注意：DWG 原生文件本环境无法解析（无 ODA File Converter），请先另存 DXF 或导出 PDF。
"""
import os
import re
import sys
import json
import csv
import math
import argparse
import warnings
import subprocess

warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))
_QC = os.path.join(HERE, "quantity_checker.py")


# ----------------------------------------------------------------------------
# 依赖懒加载（缺则自动安装）
# ----------------------------------------------------------------------------
def _ensure(pkg, import_name=None):
    import_name = import_name or pkg
    try:
        return __import__(import_name)
    except Exception:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", pkg, "--quiet", "--disable-pip-version-check"]
        )
        return __import__(import_name)


# ----------------------------------------------------------------------------
# DXF 几何提取（ezdxf）
# ----------------------------------------------------------------------------
MAX_INSERT_DEPTH = 8  # 图块递归展开限深，防止自引用块死循环

_DIM_TEXT_RE = re.compile(r"\d+(?:\.\d+)?")


def dxf_extract(path, out_json=None, expand_blocks=True):
    """从 DXF 提取几何工程量，按图层分类。

    【v20260930-10】修正两处漏量：
      1. INSERT 此前仅 `inserts += 1`，块内 LINE/CIRCLE/LWPOLYLINE 全部漏计 —— 现用
         `virtual_entities()` 递归展开（限深 MAX_INSERT_DEPTH），展开产物计入
         `insert_expanded` 并归入**宿主图层**统计，不与顶层实体重复计数；
      2. 此前完全不读 TEXT / MTEXT / DIMENSION —— 现抽取文本内容，DIMENSION 若含可用
         几何点则给出 `approx_span`（近似跨度，标注 unreliable，仅供交叉参考）。
    """
    ezdxf = _ensure("ezdxf")
    doc = ezdxf.readfile(path)
    msp = doc.modelspace()

    layers_stat = {}  # layer -> {line_len, poly_len, area, circles, inserts, insert_expanded, ents}
    texts = []        # {"layer","kind","text"}  —— TEXT/MTEXT/DIMENSION 抽取结果

    def stat(layer):
        return layers_stat.setdefault(layer, {
            "layer": layer, "line_len": 0.0, "poly_len": 0.0,
            "area": 0.0, "circles": 0, "inserts": 0, "ents": 0,
            "insert_expanded": 0, "insert_expand_errors": 0,
        })

    def handle_poly(points, closed, s):
        pts = [(p[0], p[1]) for p in points]
        if len(pts) < 2:
            return
        per = sum(math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
                  for i in range(len(pts) - 1))
        if closed:
            per += math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1])
        s["poly_len"] += per
        if closed and len(pts) >= 3:
            a = 0.0
            n = len(pts)
            for i in range(n):
                x1, y1 = pts[i]
                x2, y2 = pts[(i + 1) % n]
                a += x1 * y2 - x2 * y1
            s["area"] += abs(a) / 2.0

    def txt_of_text(e, dxft):
        """TEXT / MTEXT 文本抽取，尽量多条路径兜底。"""
        try:
            if dxft == "TEXT":
                return str(getattr(e.dxf, "text", "") or "")
            return str(e.text if hasattr(e, "text") else (e.plain_text() if hasattr(e, "plain_text") else ""))
        except Exception:
            return ""

    def txt_of_dim(e):
        """DIMENSION 标注文本：`dxf.text` 为空时（<> 占位/无关联）返回空串。"""
        try:
            t = str(e.dxf.get("text", "") or "")
        except Exception:
            t = ""
        return "" if "<" in t else t

    def dim_span(e):
        """DIMENSION 近似跨度：defpoint→text_midpoint/defpoint2 的距离，标 unreliable。"""
        try:
            p = e.dxf.defpoint
            for attr in ("text_midpoint", "defpoint2", "defpoint3"):
                q = e.dxf.get(attr, None)
                if q is not None:
                    return math.hypot(q[0] - p[0], q[1] - p[1])
        except Exception:
            pass
        return None

    def handle_ent(e, host_layer, depth=0):
        """递归处理实体；INSERT 展开后的子实体沿用宿主图层。"""
        dxft = e.dxftype()
        s = stat(host_layer)
        if depth == 0:
            s["ents"] += 1
        if dxft == "LINE":
            p1, p2 = e.dxf.start, e.dxf.end
            s["line_len"] += math.hypot(p2[0] - p1[0], p2[1] - p1[1])
        elif dxft in ("LWPOLYLINE", "POLYLINE"):
            pts = e.get_points("xy") if dxft == "LWPOLYLINE" else [v[:2] for v in e.points()]
            handle_poly(pts, bool(e.dxf.flags & 1), s)
        elif dxft == "CIRCLE":
            r = e.dxf.radius
            s["area"] += math.pi * r * r
            s["circles"] += 1
        elif dxft == "ARC":
            s["poly_len"] += 2 * math.pi * e.dxf.radius * (e.dxf.end_angle - e.dxf.start_angle) / 360.0
        elif dxft in ("TEXT", "MTEXT"):
            t = txt_of_text(e, dxft)
            if t.strip():
                texts.append({"layer": host_layer, "kind": dxft, "text": t.strip()})
        elif dxft == "DIMENSION":
            t = txt_of_dim(e)
            rec = {"layer": host_layer, "kind": "DIMENSION", "text": t}
            sp = dim_span(e)
            if sp is not None:
                rec["approx_span"] = round(sp, 2)
                rec["approx_span_note"] = "unreliable：几何点间距，非真实标注值，仅供交叉参考"
            texts.append(rec)
        elif dxft == "INSERT":
            s["inserts"] += 1
            if expand_blocks and depth >= MAX_INSERT_DEPTH:
                s["insert_expand_errors"] += 1
                return
            if expand_blocks:
                try:
                    for v in e.virtual_entities():
                        s["insert_expanded"] += 1
                        handle_ent(v, host_layer, depth + 1)
                except Exception:
                    s["insert_expand_errors"] += 1

    for e in msp:
        handle_ent(e, e.dxf.layer, 0)

    result = {
        "source": os.path.basename(path),
        "unit_note": "DXF 内单位为图形单位，须按图框比例换算为 m；本工具只输出图形几何，不直接判定清单工程量。"
                     "INSERT 已按 virtual_entities() 递归展开（限深 %d），展开几何计入宿主图层统计，"
                     "不与顶层实体重复计数。" % MAX_INSERT_DEPTH,
        "expand_blocks": expand_blocks,
        "text_count": len(texts),
        "texts": texts[:500],  # 防超大图纸刷屏
        "layers": sorted(layers_stat.values(), key=lambda x: -x["area"]),
    }
    if out_json:
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
    return result


# ----------------------------------------------------------------------------
# PDF 渲染 / 文本（pymupdf）
# ----------------------------------------------------------------------------
def pdf_to_images(path, out_dir, dpi=200):
    pymupdf = _ensure("pymupdf")
    os.makedirs(out_dir, exist_ok=True)
    doc = pymupdf.open(path)
    out = []
    for i, page in enumerate(doc):
        pix = page.get_pixmap(dpi=dpi)
        fn = os.path.join(out_dir, f"page_{i + 1:03d}.png")
        pix.save(fn)
        out.append(fn)
    return {"pages": len(doc), "images": out}


def pdf_text(path, dim_only=False):
    pymupf = _ensure("pymupdf")
    doc = pymupf.open(path)
    dim_re = re.compile(r"(\d+(?:\.\d+)?)\s*(?:×|x|X|\*)\s*(\d+(?:\.\d+)?)\s*(mm|m|cm)|(\d+(?:\.\d+)?)\s*(mm|m|cm)")
    full, dims = [], []
    for page in doc:
        t = page.get_text()
        full.append(t)
        dims += dim_re.findall(t)
    return {"text": "\n".join(full) if not dim_only else None,
            "dims_found": dims}


# ----------------------------------------------------------------------------
# 比例尺标定与图像量测（Pillow + numpy）
# ----------------------------------------------------------------------------
def scale_calibrate(known_pixels, known_real, unit="m", out_json="scale.json"):
    """已知：图像上 known_pixels 个像素 = known_real 个 unit 真实长度。"""
    scale = known_real / known_pixels  # 真实单位 / 像素
    data = {"pixels": known_pixels, "real": known_real, "unit": unit, "units_per_pixel": scale}
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return data


def _imread_any(path):
    """兼容中文路径的 imread。"""
    cv2 = _ensure("opencv-python", "cv2")
    try:
        np_ = _ensure("numpy")
        buf = np_.fromfile(path, dtype=np_.uint8)
        img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
        if img is not None:
            return img
    except Exception:
        pass
    return cv2.imread(path)


def bar_calibrate(image, step_m=None, band=None, unit="m", out_json="scale.json", try_ocr=True):
    """【v20260930-10 新增】比例尺条法：在图像中自动找黑白（或明暗）交替的等距刻度段。

    算法：
      1. 灰度 → OTSU 二值化；
      2. 逐行扫描像素跳变位置，筛「跳变次数 ≥6 且相邻间距变异系数 CV<0.25」的行 —— 这是
         图形比例尺条的特征（等距交替矩形）；
      3. 取最佳行的相邻间距中位数作为「一格 = N 像素」；
      4. `units_per_pixel = step_m / median_px`。

    参数：
      image    PNG/JPG 路径（建议整经图：含比例尺条）
      step_m   一格代表的真实长度（米）。**必填或可 OCR**：不填时尝试读尺条末端数字作候选，
               仍失败则返回 `status=need_input` 而不是硬猜 —— 守"低置信不凑数"红线。
      band     JSON [y0,y1]：限定扫描的像素行范围，用于图中存在多个类似痕迹时降噪。
    """
    cv2 = _ensure("opencv-python", "cv2")
    np_ = _ensure("numpy")
    img = _imread_any(image)
    if img is None:
        return {"status": "error", "error": f"无法读取图像 {image}"}
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    H, W = bw.shape
    y0, y1 = (int(band[0]), int(band[1])) if band else (0, H)
    y0, y1 = max(0, y0), min(H, y1)

    best = None
    for y in range(y0, y1):
        row = bw[y]
        flips = np_.flatnonzero(np_.diff(row.astype(int)) != 0)
        if len(flips) < 6:
            continue
        gaps = np_.diff(flips).astype(float)
        gaps = gaps[gaps > 0]
        if len(gaps) < 5:
            continue
        med = float(np_.median(gaps))
        cv = float(np_.std(gaps) / med) if med else 9.9
        if med <= 0 or cv >= 0.25:
            continue
        cand = {"row": int(y), "segments": int(len(gaps)), "median_px": med, "cv": round(cv, 4)}
        # 选段数适中、更规整（CV 小）的行；过多段多为文字干扰
        score = (cand["segments"] if cand["segments"] <= 40 else 40) - cv * 20
        if best is None or score > best[0]:
            best = (score, cand)

    if not best:
        return {"status": "need_input", "note": "未找到等距交替的比例尺条；请用已知尺寸法或人工指定 --pixels/--real。"}

    cand = best[1]
    cand["status"] = "ok"
    if step_m:
        cand["real"] = float(step_m)
        cand["unit"] = unit
        cand["units_per_pixel"] = float(step_m) / cand["median_px"]
        cand["method"] = "bar(graphic scale)"
        cand["pixels"] = cand["median_px"]
        if out_json:
            with open(out_json, "w", encoding="utf-8") as f:
                json.dump(cand, f, ensure_ascii=False, indent=2)
        return cand

    # step_m 未提供：尝试 OCR 尺条末端数字
    ocr_val = None
    if try_ocr:
        try:
            import pytesseract
            from PIL import Image
            pil = Image.open(image)
            sub = pil.crop((0, max(0, cand["row"] - 60), pil.width, min(pil.height, cand["row"] + 60)))
            txt = pytesseract.image_to_string(sub, config="--psm 7")
            nums = re.findall(r"\d+(?:\.\d+)?", txt)
            if nums:
                ocr_val = float(nums[-1])
        except Exception:
            ocr_val = None
    if ocr_val:
        cand["real"] = ocr_val
        cand["unit"] = unit
        cand["units_per_pixel"] = ocr_val / cand["median_px"]
        cand["method"] = "bar+OCR"
        cand["step_source"] = "OCR（抽样请人工核对）"
        if out_json:
            with open(out_json, "w", encoding="utf-8") as f:
                json.dump(cand, f, ensure_ascii=False, indent=2)
        return cand

    cand["status"] = "need_input"
    cand["note"] = ("已定位比例尺条（%d 段、中位 %.1f px），但缺「一格代表多少米」："
                    % (cand["segments"], cand["median_px"])) + "请补 --step-m，OCR 未能可靠读出。"
    return cand


def measure(scale_json, points, kind="length"):
    """points: 长度=[(x1,y1),(x2,y2)]；面积=[[x,y],...] 闭合多边形（像素坐标）。
    返回真实单位下的量。"""
    with open(scale_json, encoding="utf-8") as f:
        sc = json.load(f)
    sp = sc["units_per_pixel"]
    np_ = _ensure("numpy")
    pts = np_.array(points, dtype=float)
    if kind == "length":
        d = float(np_.linalg.norm(pts[1] - pts[0]))
        return {"kind": "length", "pixels": d, "real": d * sp, "unit": sc["unit"]}
    # 面积：鞋带公式
    x = pts[:, 0]; y = pts[:, 1]
    a_px = 0.5 * abs(sum(x[i] * y[(i + 1) % len(x)] - x[(i + 1) % len(x)] * y[i] for i in range(len(x))))
    a_real = a_px * sp * sp
    return {"kind": "area", "pixels_sq": a_px, "real": a_real, "unit": sc["unit"] + "2"}


# ----------------------------------------------------------------------------
# BOQ 汇总
# ----------------------------------------------------------------------------
def boq(rows, out_csv="boq.csv", out_json=None):
    """rows: list of dict(item, unit, qty, source, confidence)

    【v20260930-10】此前该函数无调用路径（未注册 CLI），现经 `boq` 子命令可达。
    `qty` 为空/None 的行不会静默写 0 —— 写出空值并提示，守"不凑数"原则。
    """
    fields = ["item", "unit", "qty", "source", "confidence"]
    warned = []
    with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            if r.get("qty") is None or r.get("qty") == "":
                warned.append(str(r.get("item", "?")))
            w.writerow({k: ("" if r.get(k) is None else r.get(k)) for k in fields})
    out = {"csv": out_csv, "rows": len(rows), "rows_without_qty": warned}
    if out_json:
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump({"rows": rows, **out}, f, ensure_ascii=False, indent=2)
        out["json"] = out_json
    if warned:
        out["note"] = "以下项缺 qty（已写空值未补 0，须补够量据后再汇总）：" + "、".join(warned)
    return out


# ----------------------------------------------------------------------------
# 交叉校验（调用 quantity_checker.py）
# ----------------------------------------------------------------------------
def cross_check(args):
    if not os.path.exists(_QC):
        return {"error": f"未找到 {_QC}"}
    cmd = [sys.executable, _QC] + args
    r = subprocess.run(cmd, capture_output=True, text=True)
    return {"returncode": r.returncode, "stdout": r.stdout[-2000:], "stderr": r.stderr[-500:]}


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="cn-cost-ref 工具驱动算量工具箱")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("dxf"); p.add_argument("path"); p.add_argument("--json", default=None); p.add_argument("--no-expand", action="store_true", help="不展开 INSERT 图块（回退到 v20260930-9 及以前仅计数的行为，仅用于对比核查）")
    p = sub.add_parser("pdf"); p.add_argument("path"); p.add_argument("--out", default="pdf_pages"); p.add_argument("--dpi", type=int, default=200)
    p = sub.add_parser("pdftext"); p.add_argument("path"); p.add_argument("--dim", action="store_true")
    p = sub.add_parser("scale"); p.add_argument("--pixels", type=float, required=True); p.add_argument("--real", type=float, required=True); p.add_argument("--unit", default="m"); p.add_argument("--out", default="scale.json")
    p = sub.add_parser("measure"); p.add_argument("--scale", default="scale.json"); p.add_argument("--kind", choices=["length", "area"], default="length"); p.add_argument("--points", required=True, help='JSON 数组，如 [[x1,y1],[x2,y2]]')
    # 【v20260930-10 欠账清偿】以下三个子命令此前缺失或为空壳
    p = sub.add_parser("bar"); p.add_argument("image"); p.add_argument("--step-m", type=float, default=None, help="比例尺条一格代表的真实长度(m)"); p.add_argument("--unit", default="m"); p.add_argument("--band", default=None, help='JSON [y0,y1] 限制扫描行范围'); p.add_argument("--out", default="scale.json")
    p = sub.add_parser("boq"); p.add_argument("--rows", required=True, help='JSON 数组 [{item,unit,qty,source,confidence}]'); p.add_argument("--csv", default="boq.csv"); p.add_argument("--json-out", default=None)
    p = sub.add_parser("check"); p.add_argument("--args", default=None, help='JSON 数组，如 ["anchorage","--diameter","20","--concrete","C30"]')

    args = ap.parse_args()
    if args.cmd == "dxf":
        r = dxf_extract(args.path, args.json, expand_blocks=not args.no_expand)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.cmd == "pdf":
        r = pdf_to_images(args.path, args.out, args.dpi)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.cmd == "pdftext":
        r = pdf_text(args.path, args.dim)
        print(json.dumps(r, ensure_ascii=False, indent=2)[:4000])
    elif args.cmd == "scale":
        r = scale_calibrate(args.pixels, args.real, args.unit, args.out)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.cmd == "bar":
        band = json.loads(args.band) if args.band else None
        r = bar_calibrate(args.image, args.step_m, band, args.unit, args.out)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.cmd == "measure":
        r = measure(args.scale, json.loads(args.points), args.kind)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.cmd == "boq":
        r = boq(json.loads(args.rows), args.csv, args.json_out)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.cmd == "check":
        if not args.args:
            print(json.dumps({"error": "缺 --args，示例：[\"anchorage\",\"--diameter\",\"20\",\"--concrete\",\"C30\"]",
                              "可用规则": ["rebar", "stirrup", "anchorage", "rebar-content",
                                          "concrete-content", "beam-section", "price"]},
                             ensure_ascii=False, indent=2))
            sys.exit(2)
        r = cross_check(json.loads(args.args))
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.cmd == "help":
        ap.print_help()
    else:
        ap.print_help()


if __name__ == "__main__":
    main()
