#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工程量清单模板生成器 (BOQ Builder)
===================================
根据项目基本信息（结构类型/层数/面积），生成标准清单框架（分部分项清单+措施项目清单），
并输出 Excel 工作簿（.xlsx），供造价工程师填充具体数据。

内置三类清单模板：
  框架结构 / 框剪结构 / 剪力墙结构

内置数据：
  - 各结构类型的典型单方指标（钢筋/混凝土/模板/砌体 kg/m²、m³/m² 等）
  - 分部分项清单标准章节划分（GB/T 50500-2024 附录E）
  - 措施项目清单标准分类（一般/安全/总价）

作者: cn-cost-ref skill
版本: 1.0 | 更新: 2026-08-23
"""

import argparse
import sys
import json
import math
from datetime import datetime
from typing import List, Dict, Optional

try:
    import openpyxl
    from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                                  numbers)
    from openpyxl.utils import get_column_letter
except ImportError:
    openpyxl = None

# ============================================================================
# 模块级共用样式
# ⚠ 修复（v20260930-16K）：早期版本在 openpyxl 缺失时仍无条件调用 PatternFill/Font/Side
#   构造样式常量，导入期即 NameError —— 表现为 `--help` 都跑不起来、回归门禁 G1 直接红。
#   函数内其实已有 `openpyxl is None` 守卫（返回明确错误提示），唯独这里漏了。
#   现改为：缺依赖时样式常量一律置 None，`.xlsx` 子命令由函数内守卫给出安装指引；
#   `json` / `estimate` 等纯文本子命令不受影响，仍可正常使用。
# ============================================================================
if openpyxl is None:
    HEADER_FILL = HEADER_FONT = None
    SECTION_FILL = SECTION_FONT = None
    ITEM_FILL = EST_FILL = THIN = None
else:
    HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
    HEADER_FONT = Font(bold=True, color="FFFFFF", size=11)
    SECTION_FILL = PatternFill("solid", fgColor="2E75B6")
    SECTION_FONT = Font(bold=True, color="FFFFFF", size=10)
    ITEM_FILL = PatternFill("solid", fgColor="DDEEFF")
    EST_FILL = PatternFill("solid", fgColor="FFF2CC")
    THIN = Side(style="thin", color="AAAAAA")
THIN_BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN) if THIN is not None else None


def style_header(cell, fill=HEADER_FILL, font=HEADER_FONT, align="center"):
    cell.fill = fill
    cell.font = font
    cell.alignment = Alignment(horizontal=align, vertical="center", wrap_text=True)
    cell.border = THIN_BORDER


def style_cell(cell, fill=None, bold=False, align="left"):
    if fill:
        cell.fill = fill
    cell.font = Font(bold=bold, size=10)
    cell.alignment = Alignment(horizontal=align, vertical="center")
    cell.border = THIN_BORDER


# ============================================================================
# 内置清单模板数据
# ============================================================================

# 分部分项清单章节结构（GB/T 50500-2024 附录E）
BOQ_SECTIONS = [
    {"code": "01", "name": "土石方工程", "items": [
        {"code": "0101", "name": "土方工程", "unit": "m³"},
        {"code": "0102", "name": "石方工程", "unit": "m³"},
        {"code": "0103", "name": "回填方及土石方运输", "unit": "m³"},
    ]},
    {"code": "02", "name": "地基处理与桩基工程", "items": [
        {"code": "0201", "name": "地基处理", "unit": "m³/m²"},
        {"code": "0202", "name": "桩基", "unit": "m/根"},
    ]},
    {"code": "03", "name": "主体结构工程", "items": [
        {"code": "0301", "name": "现浇混凝土结构", "unit": "m³"},
        {"code": "0302", "name": "预制混凝土构件", "unit": "m³/件"},
        {"code": "0303", "name": "钢结构工程", "unit": "t"},
        {"code": "0304", "name": "钢筋工程", "unit": "t"},
        {"code": "0305", "name": "模板工程", "unit": "m²"},
        {"code": "0306", "name": "砌体工程", "unit": "m³"},
    ]},
    {"code": "04", "name": "屋面及防水工程", "items": [
        {"code": "0401", "name": "屋面防水", "unit": "m²"},
        {"code": "0402", "name": "厨卫防水", "unit": "m²"},
        {"code": "0403", "name": "外墙防水", "unit": "m²"},
    ]},
    {"code": "05", "name": "保温隔热工程", "items": [
        {"code": "0501", "name": "外墙保温", "unit": "m²"},
        {"code": "0502", "name": "屋面保温", "unit": "m²"},
    ]},
    {"code": "06", "name": "装饰工程", "items": [
        {"code": "0601", "name": "楼地面装饰", "unit": "m²"},
        {"code": "0602", "name": "墙面装饰", "unit": "m²"},
        {"code": "0603", "name": "天棚装饰", "unit": "m²"},
        {"code": "0604", "name": "门窗工程", "unit": "樘/m²"},
    ]},
    {"code": "07", "name": "安装工程", "items": [
        {"code": "0701", "name": "电气工程", "unit": "m²/系统"},
        {"code": "0702", "name": "给排水工程", "unit": "m²/系统"},
        {"code": "0703", "name": "暖通工程", "unit": "m²/系统"},
    ]},
]

# 措施项目清单（一般措施项目 + 安全文明施工费 + 总价措施）
MEASURES_ITEMS = [
    {"code": "M01", "name": "安全文明施工费", "type": "总价", "note": "按省规定费率计取，不可竞争"},
    {"code": "M02", "name": "夜间施工增加费", "type": "一般", "note": "按费率或实测"},
    {"code": "M03", "name": "二次搬运费", "type": "一般", "note": "按费率或实测"},
    {"code": "M04", "name": "冬雨季施工增加费", "type": "一般", "note": "按费率"},
    {"code": "M05", "name": "大型机械设备进出场及安拆费", "type": "一般", "note": "按台次或费率"},
    {"code": "M06", "name": "施工排水费", "type": "一般", "note": "按费率或实测"},
    {"code": "M07", "name": "施工降水费", "type": "一般", "note": "按费率或实测"},
    {"code": "M08", "name": "地上地下设施、建筑物的临时保护设施费", "type": "一般", "note": "按费率或实测"},
    {"code": "M09", "name": "已完工程及设备保护费", "type": "一般", "note": "按费率或实测"},
    {"code": "M10", "name": "混凝土模板及支架费", "type": "一般", "note": "按模板接触面积或含模量"},
    {"code": "M11", "name": "垂直运输机械费", "type": "一般", "note": "按建筑面积"},
    {"code": "M12", "name": "装配式建筑安装增加费", "type": "一般", "note": "仅装配式建筑计取"},
]

# 结构类型单方指标参考（钢筋 kg/m²建筑面积、混凝土 m³/m²、模板 m²/m²）
STRUCTURE_INDICATORS = {
    "框架结构": {
        "description": "梁板柱体系，适用于办公/商业/住宅",
        "钢筋": (45, 65),    # (下限, 上限) kg/m²建筑面积
        "混凝土": (0.32, 0.45),
        "模板": (2.2, 3.0),
        "砌体": (0.25, 0.40),
    },
    "框剪结构": {
        "description": "框架+剪力墙，刚度大，适用于高层住宅/办公楼",
        "钢筋": (50, 75),
        "混凝土": (0.38, 0.52),
        "模板": (2.5, 3.5),
        "砌体": (0.15, 0.25),
    },
    "剪力墙结构": {
        "description": "全剪力墙，适用于高层住宅",
        "钢筋": (55, 80),
        "混凝土": (0.42, 0.58),
        "模板": (2.8, 4.0),
        "砌体": (0.05, 0.15),
    },
    "砖混结构": {
        "description": "砌体+构造柱圈梁，适用于农村住宅/宿舍",
        "钢筋": (20, 35),
        "混凝土": (0.18, 0.28),
        "模板": (1.5, 2.2),
        "砌体": (0.60, 0.90),
    },
    "钢结构": {
        "description": "钢框架+压型钢板组合楼盖，适用于大跨/工业/超高层",
        "钢筋": (35, 55),
        "混凝土": (0.15, 0.25),  # 楼板混凝土（压型钢板组合楼盖）
        "模板": (0.8, 1.2),
        "砌体": (0.20, 0.35),
        "钢结构": (0.04, 0.08),  # t/m²建筑面积
    },
}


# ============================================================================
# 模板估算（基于单方指标推算总工程量）
# ============================================================================

def estimate_quantities(structure_type: str, building_area: float, floors: int) -> Dict:
    """基于单方指标估算各分部分项工程量。"""
    ind = STRUCTURE_INDICATORS.get(structure_type, STRUCTURE_INDICATORS["框架结构"])
    lower, upper = ind["钢筋"]

    est = {}
    # 主体结构（钢筋+混凝土+模板）
    concrete_lower = ind["混凝土"][0] * building_area
    concrete_upper = ind["混凝土"][1] * building_area
    est["钢筋总重量(t)"] = {
        "lower": round(lower * building_area / 1000, 1),
        "upper": round(upper * building_area / 1000, 1),
        "unit": "t",
        "note": "按%.0f~%.0f kg/m²建筑面积估算" % (lower, upper),
    }
    est["混凝土总体积(m³)"] = {
        "lower": round(concrete_lower, 1),
        "upper": round(concrete_upper, 1),
        "unit": "m³",
        "note": "按%.2f~%.2f m³/m²估算" % (ind["混凝土"][0], ind["混凝土"][1]),
    }
    template_lower = ind["模板"][0] * building_area
    template_upper = ind["模板"][1] * building_area
    est["模板面积(m²)"] = {
        "lower": round(template_lower, 1),
        "upper": round(template_upper, 1),
        "unit": "m²",
        "note": "按%.1f~%.1f m²/m²估算" % (ind["模板"][0], ind["模板"][1]),
    }

    # 砌体（地上面积估算）
    masonary_area = building_area * 0.6  # 粗估
    est["砌体体积(m³)"] = {
        "lower": round(ind["砌体"][0] * masonary_area, 1),
        "upper": round(ind["砌体"][1] * masonary_area, 1),
        "unit": "m³",
        "note": "仅地上部分，按%.2f~%.2f m³/m²估算" % (ind["砌体"][0], ind["砌体"][1]),
    }

    # 防水（屋面+厨卫+外墙）
    roof_area = building_area / floors if floors > 0 else building_area * 0.25
    est["屋面防水(m²)"] = {
        "lower": round(roof_area * 0.95, 1),
        "upper": round(roof_area * 1.05, 1),
        "unit": "m²",
        "note": "按层面积×1.0估算",
    }
    bathroom_area = building_area * 0.15
    est["厨卫防水(m²)"] = {
        "lower": round(bathroom_area * 0.9, 1),
        "upper": round(bathroom_area * 1.1, 1),
        "unit": "m²",
        "note": "按建筑面积×15%估算厨卫范围",
    }
    # 外墙防水
    perimeter = math.sqrt(building_area / floors) * 4 if floors > 0 else 0
    height = floors * 3.0
    est["外墙防水(m²)"] = {
        "lower": round(perimeter * height * 0.85, 1),
        "upper": round(perimeter * height * 1.1, 1),
        "unit": "m²",
        "note": "按外周长×层高估算，含窗洞口10~15%",
    }

    # 保温
    est["外墙保温(m²)"] = est["外墙防水(m²)"].copy()
    est["屋面保温(m²)"] = est["屋面防水(m²)"].copy()

    # 装饰
    wall_area = building_area * 2.8  # 内墙面积粗估
    est["楼地面(m²)"] = {
        "lower": round(building_area * 0.92, 1),
        "upper": round(building_area * 0.98, 1),
        "unit": "m²",
        "note": "按建筑面积×(0.92~0.98)",
    }
    est["墙面装饰(m²)"] = {
        "lower": round(wall_area * 0.85, 1),
        "upper": round(wall_area * 1.1, 1),
        "unit": "m²",
        "note": "按内墙面积×(0.85~1.1)，含柱面",
    }
    est["天棚装饰(m²)"] = est["楼地面(m²)"].copy()

    # 钢结构专项（仅钢结构）
    if structure_type == "钢结构":
        steel_t = ind["钢结构"]
        est["钢结构用钢量(t)"] = {
            "lower": round(steel_t[0] * building_area, 1),
            "upper": round(steel_t[1] * building_area, 1),
            "unit": "t",
            "note": "按%.2f~%.2f t/m²估算" % (steel_t[0], steel_t[1]),
        }
        est["压型钢板楼板(m²)"] = {
            "lower": round(building_area * 0.9, 1),
            "upper": round(building_area * 1.0, 1),
            "unit": "m²",
            "note": "按建筑面积×(0.9~1.0)",
        }

    return est


# ============================================================================
# Excel 生成
# ============================================================================

def generate_boq_excel(
    project_name: str,
    structure_type: str,
    building_area: float,
    floors: int,
    output_path: str,
) -> str:
    """生成 Excel 清单模板文件。"""
    if openpyxl is None:
        return "ERROR: openpyxl 未安装，请先运行: pip install openpyxl"

    wb = openpyxl.Workbook()

    # =========================================================================
    # Sheet 1: 分部分项清单
    # =========================================================================
    ws1 = wb.active
    ws1.title = "分部分项清单"

    # 标题行
    ws1.merge_cells("A1:H1")
    title_cell = ws1["A1"]
    title_cell.value = f"{project_name} — 分部分项工程量清单"
    title_cell.fill = HEADER_FILL
    title_cell.font = Font(bold=True, color="FFFFFF", size=13)
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws1.row_dimensions[1].height = 28

    # 列标题
    headers = ["序号", "项目编码", "项目名称", "项目特征", "计量单位", "工程量", "综合单价(元)", "合价(元)"]
    ws1.append(headers)
    for col, h in enumerate(headers, 1):
        style_header(ws1.cell(2, col))
    ws1.row_dimensions[2].height = 22

    row = 3
    seq = 1
    for section in BOQ_SECTIONS:
        # 节标题行
        ws1.merge_cells(f"A{row}:H{row}")
        sec_cell = ws1.cell(row, 1)
        sec_cell.value = f"{section['code']} {section['name']}"
        style_header(sec_cell, fill=SECTION_FILL, font=SECTION_FONT, align="left")
        ws1.row_dimensions[row].height = 18
        row += 1

        for item in section["items"]:
            values = [
                seq,
                f"{section['code']}{item['code']}001",
                item["name"],
                "（按设计图纸描述）",
                item["unit"],
                "",  # 工程量留空
                "",  # 综合单价留空
                f"=F{row}*G{row}",  # 合价公式
            ]
            ws1.append(values)
            for col in range(1, 9):
                if col == 7:
                    style_cell(ws1.cell(row, col), fill=EST_FILL, align="right")
                elif col == 8:
                    style_cell(ws1.cell(row, col), align="right")
                elif col == 1:
                    style_cell(ws1.cell(row, col), align="center")
                else:
                    style_cell(ws1.cell(row, col), fill=ITEM_FILL)
            ws1.cell(row, 3).font = Font(size=10)
            seq += 1
            row += 1

    # 列宽
    widths = [6, 14, 22, 30, 8, 12, 14, 14]
    for i, w in enumerate(widths, 1):
        ws1.column_dimensions[get_column_letter(i)].width = w

    # =========================================================================
    # Sheet 2: 措施项目清单
    # =========================================================================
    ws2 = wb.create_sheet("措施项目清单")
    ws2.merge_cells("A1:F1")
    ws2["A1"].value = f"{project_name} — 措施项目清单"
    ws2["A1"].fill = HEADER_FILL
    ws2["A1"].font = Font(bold=True, color="FFFFFF", size=13)
    ws2["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws2.row_dimensions[1].height = 28

    m_headers = ["序号", "项目编码", "项目名称", "计量单位", "工程量", "金额(元)"]
    ws2.append(m_headers)
    for col, h in enumerate(m_headers, 1):
        style_header(ws2.cell(2, col))
    ws2.row_dimensions[2].height = 22

    m_seq = 1
    for item in MEASURES_ITEMS:
        type_fill = PatternFill("solid", fgColor="E2EFDA") if item["type"] == "总价" else ITEM_FILL
        values = [
            m_seq,
            item["code"],
            item["name"],
            "（项）",
            "",
            f"=F{row}",  # 总价项目=1
        ]
        ws2.append(values)
        for col in range(1, 7):
            style_cell(ws2.cell(row, col), fill=type_fill)
        ws2.cell(row, 3).value = f"{item['name']}  【{item['note']}】"
        m_seq += 1
        row += 1

    m_widths = [6, 10, 35, 10, 10, 14]
    for i, w in enumerate(m_widths, 1):
        ws2.column_dimensions[get_column_letter(i)].width = w

    # =========================================================================
    # Sheet 3: 工程量估算参考（基于单方指标）
    # =========================================================================
    ws3 = wb.create_sheet("工程量估算参考")
    ws3.merge_cells("A1:E1")
    ws3["A1"].value = f"工程量估算参考表 — {structure_type}（建筑面积 {building_area:.1f} m²，共 {floors} 层）"
    ws3["A1"].fill = HEADER_FILL
    ws3["A1"].font = Font(bold=True, color="FFFFFF", size=12)
    ws3["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws3.row_dimensions[1].height = 26

    e3_headers = ["序号", "项目名称", "估算工程量（下限）", "估算工程量（上限）", "参考依据"]
    ws3.append(e3_headers)
    for col, h in enumerate(e3_headers, 1):
        style_header(ws3.cell(2, col))
    ws3.row_dimensions[2].height = 20

    estimates = estimate_quantities(structure_type, building_area, floors)
    e_seq = 1
    for name, data in estimates.items():
        ws3.append([
            e_seq,
            name,
            data["lower"],
            data["upper"],
            data.get("note", ""),
        ])
        for col in range(1, 6):
            style_cell(ws3.cell(e_seq + 2, col), fill=EST_FILL,
                      align="right" if col in (3, 4) else "left")
        e_seq += 1

    e3_widths = [6, 28, 22, 22, 40]
    for i, w in enumerate(e3_widths, 1):
        ws3.column_dimensions[get_column_letter(i)].width = w

    # 警告行
    warn_row = e_seq + 3
    ws3.merge_cells(f"A{warn_row}:E{warn_row}")
    ws3[f"A{warn_row}"].value = (
        "⚠️  以上为基于单方指标的参考估算值，实际工程量须按施工图计算！"
        "本表仅供参考，不作为正式清单编制依据。"
    )
    ws3[f"A{warn_row}"].fill = PatternFill("solid", fgColor="FFE0CC")
    ws3[f"A{warn_row}"].font = Font(size=9, color="C00000")
    ws3[f"A{warn_row}"].alignment = Alignment(wrap_text=True)
    ws3.row_dimensions[warn_row].height = 30

    wb.save(output_path)
    return output_path


# ============================================================================
# JSON 导出
# ============================================================================

def export_json(
    project_name: str,
    structure_type: str,
    building_area: float,
    floors: int,
    output_path: str,
) -> str:
    """导出纯 JSON 格式的清单框架。"""
    estimates = estimate_quantities(structure_type, building_area, floors)
    payload = {
        "project": project_name,
        "structure_type": structure_type,
        "building_area_m2": building_area,
        "floors": floors,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "boq_sections": BOQ_SECTIONS,
        "measures_items": MEASURES_ITEMS,
        "estimates": estimates,
        "structure_indicators": STRUCTURE_INDICATORS.get(structure_type),
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return output_path


# ============================================================================
# 清单模式工作簿生成（GB/T 50500-2024 五类清单 + 12位编码 + 综合单价分析）
# ============================================================================

# 装饰装修工程附录默认骨架（12位码，前9位严格按 GB/T 50854-2024 装饰附录）
DECOR_DEFAULT_SECTIONS = [
    {"code": "0110", "name": "楼地面装饰工程", "items": [
        {"code": "10402576811.94", "name": "块料楼地面（石材）", "feature": "结合层+750×1500莱姆石铺贴、勾缝、成品保护", "unit": "m2"},
        {"code": "10402576812.87", "name": "块料楼地面（瓷砖）", "feature": "水泥砂浆+600×1200瓷砖铺贴、勾缝", "unit": "m2"},
        {"code": "10405390622.94", "name": "金属踢脚线", "feature": "80mm高黑色喷砂不锈钢踢脚线", "unit": "m"},
        {"code": "10406322937.94", "name": "石材零星项目（门槛石）", "feature": "米黄色大理石门槛石加工安装", "unit": "m2"},
    ]},
    {"code": "0111", "name": "墙柱面装饰与隔断、幕墙工程", "items": [
        {"code": "10495337937.94", "name": "墙面一般抹灰", "feature": "抹灰找平、刮腻子三道、打磨", "unit": "m2"},
        {"code": "10498148937.94", "name": "石材墙面（干挂）", "feature": "热镀锌钢骨架+干挂石材", "unit": "m2"},
        {"code": "10499085937.94", "name": "墙面装饰板（木饰面/玻镁板）", "feature": "轻钢龙骨基层+玻镁板铝木饰面板", "unit": "m2"},
        {"code": "10503772811.94", "name": "玻璃隔断", "feature": "不锈钢边框+12mm防火钢化玻璃", "unit": "m2"},
        {"code": "10504707937.94", "name": "柱面装饰板", "feature": "柱面龙骨+饰面板", "unit": "m2"},
    ]},
    {"code": "0112", "name": "天棚工程", "items": [
        {"code": "10589974937.94", "name": "天棚吊顶（石膏板）", "feature": "U50轻钢龙骨+9.5mm纸面石膏板+白色无机涂料", "unit": "m2"},
        {"code": "10589974938.87", "name": "天棚吊顶（双层硅钙板）", "feature": "轻钢龙骨+双层8mm硅钙板+白色无机涂料", "unit": "m2"},
        {"code": "10591848937.94", "name": "灯带（槽）", "feature": "双层硅钙板灯槽+LED灯带", "unit": "m"},
        {"code": "10592785937.94", "name": "天棚喷刷涂料", "feature": "原顶基层+腻子+白色无机涂料", "unit": "m2"},
    ]},
    {"code": "0113", "name": "门窗工程", "items": [
        {"code": "10682737937.94", "name": "木质门", "feature": "实木复合门含门套、五金、油漆", "unit": "樘"},
        {"code": "10683674937.94", "name": "金属门（玻璃门）", "feature": "不锈钢框+12mm钢化玻璃+地弹簧", "unit": "樘"},
        {"code": "10688359937.94", "name": "门窗套", "feature": "木基层+饰面板+油漆", "unit": "m"},
    ]},
    {"code": "0114", "name": "油漆、涂料、裱糊工程", "items": [
        {"code": "10686485937.94", "name": "木材面油漆", "feature": "硝基清漆/聚脂漆4-5道", "unit": "m2"},
        {"code": "10687422937.94", "name": "金属面油漆", "feature": "防锈漆+面漆", "unit": "m2"},
        {"code": "10689296937.94", "name": "喷刷涂料（墙面）", "feature": "一底两面乳胶漆/白色无机涂料", "unit": "m2"},
    ]},
    {"code": "0115", "name": "其他装饰工程", "items": [
        {"code": "10776437937.94", "name": "柜类（水吧/储物柜）", "feature": "现场制作固定柜体含基层饰面", "unit": "m"},
        {"code": "10782996937.94", "name": "招牌/标识", "feature": "吊挂广告灯箱、发光字、导视标识", "unit": "项"},
    ]},
]


def _style_title(ws, cell, text, ncols, size=13):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(1, 1, text)
    c.fill = HEADER_FILL
    c.font = Font(bold=True, color="FFFFFF", size=size)
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28


def _style_header_row(ws, row, ncols):
    for col in range(1, ncols + 1):
        style_header(ws.cell(row, col))


def generate_standard_workbook(project: str, data: dict, out: str) -> str:
    """生成 GB/T 50500-2024 清单模式工作簿（五类清单+12位码+综合单价分析+三级汇总）。

    data 结构（可选，缺省用装饰附录骨架）：
      {
        "purpose": "内部投标报价测算",
        "scope_in":  ["红线内计入项..."],
        "scope_out": ["红线外排除项..."],
        "sections": [{"code","name","items":[{"code","name","feature","unit","qty","price"}]}],
        "measures": [{"name","type","unit","qty","amount","note"}],
        "others":   [{"name","unit","amount","note"}],
        "fees":     [{"name","base","rate","amount"}],   # 规费/税金
        "analysis": [{"code","name","feature","unit","qty","labor","material","machine","mgr","profit","risk"}]
      }
    """
    if openpyxl is None:
        return "ERROR: openpyxl 未安装，请先运行: pip install openpyxl"

    wb = openpyxl.Workbook()

    # ---------- Sheet 1: 编制说明及设计范围红线分析 ----------
    ws = wb.active
    ws.title = "编制说明及红线"
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 95
    ws.merge_cells('A1:B1')
    ws['A1'] = f"{project} — 工程量清单计价标准清单模式（编制说明及设计范围红线分析）"
    ws['A1'].fill = HEADER_FILL
    ws['A1'].font = Font(bold=True, color="FFFFFF", size=13)
    ws['A1'].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    purpose = (data.get("purpose") or "内部投标报价测算（清单模式）")
    scope_in = data.get("scope_in") or ["（见设计图纸，本次装饰装修承包范围内全部空间与做法）"]
    scope_out = data.get("scope_out") or ["（土建主体、原结构防水、消防/空调一次系统、甲供材/设备、可移动家具按红线排除）"]
    notes = [
        ("编制用途", purpose + "。综合单价含人工+辅材+机械+企业管理费+利润+风险费；规费、税金在汇总阶段按费率/计税基数单列，不进入综合单价；不含甲供材。"),
        ("编制依据", "GB/T 50500-2024《建设工程工程量清单计价标准》、GB/T 50854-2024《房屋建筑与装饰工程工程量计算规范》、广东省2018装饰装修工程综合定额（参考）。"),
        ("红线内·计入范围（设计范围基线）", "\n".join(f"• {x}" for x in scope_in)),
        ("红线外·排除项（一律不计入）", "\n".join(f"• {x}" for x in scope_out)),
        ("算量方法", "按图纸标注数字及比例尺估算；房间面积优先采用图上标注净面积，公共区按平面比例估算；施工图注明“切勿以比例量度此图，一切以现场实际度量为准”，故本清单工程量为估算值。"),
        ("价格说明", "综合单价为广州地区参考市场价（含管理费利润），供投标/预算初稿；正式报价前须按当期信息价、劳务行情及供应商询价调整。"),
        ("未含项目", "甲供可移动家具/电竞设备、消防/空调一次系统（仅计二次装修末端配合）、甲供材（不计材料费）。"),
        ("风险提醒", "结算应以现场实测及双方签证为准；范围不清时已先问后算，未将红线外/其他专业内容计入本清单。"),
        ("置信度", "房间数量/面积（高）、公共区面积（中）、材料做法（高）、单价（中）、机电配合项（中低）。"),
    ]
    r = 3
    for k, v in notes:
        ws.cell(r, 1, k).font = Font(bold=True)
        ws.cell(r, 1).alignment = Alignment(horizontal="left", vertical="top")
        ws.cell(r, 2, v).alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
        ws.row_dimensions[r].height = 60 if "\n" in v else 42
        r += 1

    # ---------- Sheet 2: 单位工程费汇总表 ----------
    ws2 = wb.create_sheet("单位工程费汇总表")
    _style_title(ws2, None, f"{project} — 单位工程费汇总表", 4, 13)
    hdr = ["序号", "名称", "金额(元)", "备注"]
    for i, h in enumerate(hdr, 1):
        ws2.cell(2, i, h)
    _style_header_row(ws2, 2, 4)
    summary = [
        ("一", "分部分项工程费", "=分部分项工程量清单!H{last}", "∑分部分项合价"),
        ("二", "措施项目费", "=措施项目清单!E{last}", "∑措施金额"),
        ("三", "其他项目费", "=其他项目清单!D{last}", "暂列+暂估+计日工+总包服务费"),
        ("四", "规费", "=规费税金!E2", "按当地规定"),
        ("五", "税金", "=规费税金!E3", "增值税（一般计税9%）"),
        ("", "投标报价总价", "=C3+C4+C5+C6+C7", "单位工程报价合计"),
    ]
    for idx, (no, name, formula, note) in enumerate(summary, 3):
        ws2.cell(idx, 1, no)
        ws2.cell(idx, 2, name)
        ws2.cell(idx, 3, formula).alignment = Alignment(horizontal="right")
        ws2.cell(idx, 4, note)
        for col in range(1, 5):
            style_cell(ws2.cell(idx, col), fill=(EST_FILL if name in ("投标报价总价",) else None),
                       bold=(name == "投标报价总价"))
    ws2.column_dimensions['A'].width = 8
    ws2.column_dimensions['B'].width = 24
    ws2.column_dimensions['C'].width = 18
    ws2.column_dimensions['D'].width = 40

    # ---------- Sheet 3: 分部分项工程量清单 ----------
    ws3 = wb.create_sheet("分部分项工程量清单")
    _style_title(ws3, None, f"{project} — 分部分项工程量清单", 8, 13)
    dhdr = ["序号", "项目编码", "项目名称", "项目特征描述", "计量单位", "工程量", "综合单价(元)", "合价(元)"]
    for i, h in enumerate(dhdr, 1):
        ws3.cell(2, i, h)
    _style_header_row(ws3, 2, 8)
    sections = data.get("sections") or DECOR_DEFAULT_SECTIONS
    row = 3
    seq = 1
    for sec in sections:
        ws3.merge_cells(start_row=row, start_column=1, end_row=row, end_column=8)
        sc = ws3.cell(row, 1, f"{sec['code']} {sec['name']}")
        style_header(sc, fill=SECTION_FILL, font=SECTION_FONT, align="left")
        row += 1
        for it in sec["items"]:
            qty = it.get("qty", "")
            price = it.get("price", "")
            vals = [seq, it["code"], it["name"], it.get("feature", "（按设计图纸描述）"),
                    it["unit"], qty, price, (f"=F{row}*G{row}" if (qty != "" and price != "") else "")]
            for col, v in enumerate(vals, 1):
                cell = ws3.cell(row, col, v)
                style_cell(cell)
            ws3.cell(row, 4).alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            seq += 1
            row += 1
    last_detail = row - 1
    widths = [6, 16, 26, 44, 9, 12, 16, 16]
    for i, w in enumerate(widths, 1):
        ws3.column_dimensions[get_column_letter(i)].width = w
    ws3.freeze_panes = "A3"

    # ---------- Sheet 4: 措施项目清单 ----------
    ws4 = wb.create_sheet("措施项目清单")
    _style_title(ws4, None, f"{project} — 措施项目清单", 6, 13)
    mhdr = ["序号", "项目名称", "计量单位", "工程量", "金额(元)", "备注"]
    for i, h in enumerate(mhdr, 1):
        ws4.cell(2, i, h)
    _style_header_row(ws4, 2, 6)
    measures = data.get("measures") or [
        {"name": "安全文明施工费", "type": "总价", "unit": "项", "qty": 1, "amount": "", "note": "按省规定费率计取，不可竞争"},
        {"name": "脚手架工程", "type": "单价", "unit": "项", "qty": 1, "amount": "", "note": "装饰脚手架"},
        {"name": "垂直运输机械费", "type": "总价", "unit": "项", "qty": 1, "amount": "", "note": "按建筑面积"},
        {"name": "成品保护及清洁开荒", "type": "总价", "unit": "m2", "qty": 1000, "amount": 12, "note": "按总面积"},
    ]
    mrow = 3
    for i, m in enumerate(measures, 1):
        amt = m.get("amount", "")
        qty = m.get("qty", 1)
        formula = f"=D{mrow}*E{mrow}" if (amt != "" and qty != "") else ""
        vals = [i, f"{m['name']}【{m.get('note','')}】", m.get("unit", "项"), qty, amt if amt != "" else formula, m.get("note", "")]
        for col, v in enumerate(vals, 1):
            style_cell(ws4.cell(mrow, col, v),
                       fill=(PatternFill("solid", fgColor="E2EFDA") if m.get("type") == "总价" else ITEM_FILL))
        mrow += 1
    last_measure = mrow - 1
    for i, w in enumerate([6, 42, 10, 12, 16, 30], 1):
        ws4.column_dimensions[get_column_letter(i)].width = w

    # ---------- Sheet 5: 其他项目清单 ----------
    ws5 = wb.create_sheet("其他项目清单")
    _style_title(ws5, None, f"{project} — 其他项目清单", 4, 13)
    ohdr = ["序号", "项目名称", "计量单位", "金额(元)", "备注"]
    for i, h in enumerate(ohdr, 1):
        ws5.cell(2, i, h)
    _style_header_row(ws5, 2, 5)
    others = data.get("others") or [
        {"name": "暂列金额", "unit": "元", "amount": "", "note": "招标人列，按给定金额填报（一般≤分部分项10%~15%）"},
        {"name": "材料/工程设备暂估价", "unit": "元", "amount": "", "note": "招标人列，按给定填报"},
        {"name": "专业工程暂估价", "unit": "元", "amount": "", "note": "招标人列，由分包实施"},
        {"name": "计日工", "unit": "元", "amount": "", "note": "招标人列数量，投标人填单价"},
        {"name": "总承包服务费", "unit": "元", "amount": "", "note": "投标人按分包/甲供服务报价"},
    ]
    orow = 3
    for i, o in enumerate(others, 1):
        vals = [i, o["name"], o.get("unit", "元"), o.get("amount", ""), o.get("note", "")]
        for col, v in enumerate(vals, 1):
            style_cell(ws5.cell(orow, col, v))
        orow += 1
    last_other = orow - 1
    for i, w in enumerate([6, 28, 10, 16, 50], 1):
        ws5.column_dimensions[get_column_letter(i)].width = w

    # ---------- Sheet 6: 规费税金项目清单 ----------
    ws6 = wb.create_sheet("规费税金")
    _style_title(ws6, None, f"{project} — 规费、税金项目清单", 5, 13)
    fhdr = ["序号", "项目名称", "计算基础", "费率", "金额(元)"]
    for i, h in enumerate(fhdr, 1):
        ws6.cell(2, i, h)
    _style_header_row(ws6, 2, 5)
    fees = data.get("fees") or [
        {"name": "规费", "base": "按当地规定", "rate": "", "amount": ""},
        {"name": "增值税（一般计税）", "base": "分部分项+措施+其他+规费", "rate": "9%",
         "amount": "=ROUND((单位工程费汇总表!C3+单位工程费汇总表!C4+单位工程费汇总表!C5+单位工程费汇总表!C6)*0.09,2)"},
    ]
    frow = 3
    for i, f in enumerate(fees, 1):
        amt = f.get("amount", "")
        if amt == "" and f.get("rate") not in (None, ""):
            # 规费若仅给费率，金额留空待填
            pass
        vals = [i, f["name"], f.get("base", ""), f.get("rate", ""), amt]
        for col, v in enumerate(vals, 1):
            style_cell(ws6.cell(frow, col, v))
        frow += 1
    for i, w in enumerate([6, 24, 30, 10, 16], 1):
        ws6.column_dimensions[get_column_letter(i)].width = w

    # 回填汇总表公式中的 last 行号
    for s in (ws2,):
        for rr in range(3, 9):
            c = s.cell(rr, 3)
            if isinstance(c.value, str) and "{last}" in c.value:
                if "分部分项" in c.value:
                    c.value = c.value.format(last=last_detail)
                elif "措施" in c.value:
                    c.value = c.value.format(last=last_measure)
                elif "其他" in c.value:
                    c.value = c.value.format(last=last_other)

    # ---------- Sheet 7: 综合单价分析表 ----------
    ws7 = wb.create_sheet("综合单价分析表")
    _style_title(ws7, None, f"{project} — 综合单价分析表（与分部分项逐项对应）", 13, 13)
    ahdr = ["项目编码", "项目名称", "项目特征", "单位", "清单量", "人工费", "材料费",
            "施工机具费", "小计(人+材+机)", "企业管理费", "利润", "风险费", "综合单价"]
    for i, h in enumerate(ahdr, 1):
        ws7.cell(2, i, h)
    _style_header_row(ws7, 2, 13)
    analyses = data.get("analysis") or []
    arow = 3
    for a in analyses:
        lab = a.get("labor", 0); mat = a.get("material", 0); mac = a.get("machine", 0)
        sub = round(lab + mat + mac, 2)
        mgr = a.get("mgr", round((lab + mac) * 0.12, 2))
        profit = a.get("profit", round((lab + mac) * 0.07, 2))
        risk = a.get("risk", 0)
        comp = round(sub + mgr + profit + risk, 2)
        vals = [a.get("code", ""), a.get("name", ""), a.get("feature", ""), a.get("unit", ""),
                a.get("qty", ""), lab, mat, mac, sub, mgr, profit, risk, comp]
        for col, v in enumerate(vals, 1):
            style_cell(ws7.cell(arow, col, v))
        arow += 1
    if arow == 3:
        ws7.cell(3, 1, "（本表为综合单价分析模板，须与分部分项清单逐项对应填写；评标澄清时单价须与投标综合单价吻合）")
    for i, w in enumerate([16, 24, 36, 6, 10, 10, 10, 10, 12, 10, 8, 8, 12], 1):
        ws7.column_dimensions[get_column_letter(i)].width = w

    wb.save(out)
    return out


def generate_standard_from_json(project: str, json_path: str, out: str) -> str:
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return generate_standard_workbook(project, data, out)


# ============================================================================
# CLI
# ============================================================================

def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    parser = argparse.ArgumentParser(
        description="工程量清单模板生成器 — 生成 .xlsx / .json 清单框架",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 生成框架结构清单模板
  python boq_builder.py xlsx --project "某商业综合体" \\
      --type "框架结构" --area 12000 --floors 8 --out boq_template.xlsx

  # 导出 JSON 框架（无 openpyxl 时可用）
  python boq_builder.py json --project "某住宅小区" \\
      --type "框剪结构" --area 25000 --floors 26 --out boq_template.json

  # 纯文本估算（无任何依赖）
  python boq_builder.py estimate --type "剪力墙结构" --area 18000 --floors 32
        """
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("xlsx", help="生成 Excel 清单模板（.xlsx）")
    p.add_argument("--project", default="工程项目", help="项目名称")
    p.add_argument("--type", required=True,
                   choices=list(STRUCTURE_INDICATORS.keys()),
                   help="结构类型")
    p.add_argument("--area", type=float, required=True, help="建筑面积（m²）")
    p.add_argument("--floors", type=int, required=True, help="层数")
    p.add_argument("--out", default="boq_template.xlsx", help="输出路径")

    p = sub.add_parser("json", help="导出 JSON 清单框架")
    p.add_argument("--project", default="工程项目", help="项目名称")
    p.add_argument("--type", required=True,
                   choices=list(STRUCTURE_INDICATORS.keys()))
    p.add_argument("--area", type=float, required=True)
    p.add_argument("--floors", type=int, required=True)
    p.add_argument("--out", default="boq_template.json")

    p = sub.add_parser("estimate", help="仅输出工程量估算参考（纯文本）")
    p.add_argument("--type", required=True, choices=list(STRUCTURE_INDICATORS.keys()))
    p.add_argument("--area", type=float, required=True)
    p.add_argument("--floors", type=int, required=True)

    p = sub.add_parser("standard", help="生成 GB/T 50500-2024 清单模式工作簿（五类清单+12位码+综合单价分析+三级汇总）")
    p.add_argument("--project", default="装饰装修工程", help="项目名称")
    p.add_argument("--data", default=None, help="清单数据 JSON 路径（含分部分项/措施/其他/规费税金/分析/红线）；缺省用装饰附录骨架")
    p.add_argument("--out", default="boq_standard.xlsx", help="输出路径")

    p = sub.add_parser("decor", help="standard 的别名：装饰装修清单模式工作簿")
    p.add_argument("--project", default="装饰装修工程", help="项目名称")
    p.add_argument("--data", default=None, help="清单数据 JSON 路径（含分部分项/措施/其他/规费税金/分析/红线）；缺省用装饰附录骨架")
    p.add_argument("--out", default="boq_standard.xlsx", help="输出路径")

    args = parser.parse_args()

    if args.cmd == "xlsx":
        path = generate_boq_excel(
            args.project, args.type, args.area, args.floors, args.out
        )
        if path.startswith("ERROR"):
            print(path)
        else:
            print(f"✅ Excel 清单模板已生成: {path}")

    elif args.cmd == "json":
        path = export_json(
            args.project, args.type, args.area, args.floors, args.out
        )
        print(f"✅ JSON 清单框架已导出: {path}")

    elif args.cmd in ("standard", "decor"):
        if args.data:
            path = generate_standard_from_json(args.project, args.data, args.out)
        else:
            path = generate_standard_workbook(args.project, {}, args.out)
        if isinstance(path, str) and path.startswith("ERROR"):
            print(path)
        else:
            print(f"✅ 清单模式工作簿已生成: {path}")

    elif args.cmd == "estimate":
        est = estimate_quantities(args.type, args.area, args.floors)
        print(f"\n{'='*55}")
        print(f"工程量估算参考  [{args.type}]  建筑面积 {args.area:.0f} m²  共 {args.floors} 层")
        print(f"{'='*55}")
        print(f"  {'项目':<28} {'下限':>10} {'上限':>10}")
        print(f"  {'-'*50}")
        for name, data in est.items():
            print(f"  {name:<28} {data['lower']!s:>10} {data['upper']!s:>10}")
        print(f"\n  注：{STRUCTURE_INDICATORS[args.type]['description']}")
        print(f"  ⚠️  以上为估算参考，实际工程量须按施工图计算。")


if __name__ == "__main__":
    main()
