#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从文字 bbox 边缘追踪引线折线 → 终点（坐标标注点）"""
import sys, math
import fitz

PDF, PAGE = sys.argv[1], int(sys.argv[2])
BX0, BY0, BX1, BY1 = map(float, sys.argv[3:7])   # 文字 bbox
MAXLEN = float(sys.argv[7]) if len(sys.argv) > 7 else 400

doc = fitz.open(PDF); pg = doc[PAGE]
segs = []
for d in pg.get_drawings():
    for it in d["items"]:
        if it[0] != "l":
            continue
        p1, p2 = it[1], it[2]
        segs.append(((p1.x, p1.y), (p2.x, p2.y)))

def near_pt(p, q, tol):
    return math.dist(p, q) <= tol

# 1) 找与文字 bbox 相交/贴边的线段（引线起点）
starts = []
for (a, b) in segs:
    for p, q in ((a, b), (b, a)):
        if BX0 - 6 <= p[0] <= BX1 + 6 and BY0 - 6 <= p[1] <= BY1 + 6:
            if not (BX0 <= p[0] <= BX1 and BY0 <= p[1] <= BY1):
                starts.append((p, q))
                break
print(f"候选引线起点 {len(starts)} 个")

# 2) 链式追踪
used = set()
def trace(start_seg):
    chain = [start_seg[0], start_seg[1]]
    used.add(id(start_seg))
    cur = start_seg[1]
    total = math.dist(start_seg[0], start_seg[1])
    while total < MAXLEN:
        hit = None
        for i, (a, b) in enumerate(segs):
            if id(i) in used or i in used:
                continue
            if near_pt(cur, a, 0.6) and math.dist(a, b) < MAXLEN:
                hit = (i, b); break
            if near_pt(cur, b, 0.6) and math.dist(a, b) < MAXLEN:
                hit = (i, a); break
        if not hit:
            break
        i, nxt = hit
        used.add(i)
        chain.append(nxt)
        total += math.dist(cur, nxt)
        cur = nxt
    return chain, total

seen_end = []
for s in starts[:40]:
    if id(s) in used:
        continue
    chain, total = trace(s)
    end = chain[-1]
    seen_end.append((round(total, 1), round(end[0], 2), round(end[1], 2), len(chain)))
for e in sorted(set(seen_end)):
    print("链长 %6.1fpt → 终点 (%.2f, %.2f)  折点 %d" % e)
