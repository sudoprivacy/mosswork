#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一次性升级：给材料价库每条价加 source_id 来源批次，meta 增加 source_batches 批次表。
保持与原库(期号/口径/计价地区/价格/来源/置信度/备注)兼容，不破坏 material_price_update.py 四要素契约。
"""
import json, os, copy

PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "material_prices.json")
d = json.load(open(PATH, encoding="utf-8"))

# 来源批次表（按现有真实来源归类，不臆造）
batches = {
    "GZJS202603": {
        "source_type": "造价站信息价",
        "issuer": "广州市建设工程造价信息(造价站)",
        "period": "2026-03",
        "region": "广州",
        "caliber": "税前综合价",
        "reliability": "可核",
        "desc": "广州造价站2026-03 22种常用材料税前综合价格",
        "source_note": "公开信息价(造价站发布)",
    },
    "BNJZ202608": {
        "source_type": "市场报价",
        "issuer": "百年建筑(市场资讯)",
        "period": "2026-08",
        "region": "广州",
        "caliber": "含税市场批发价区间",
        "reliability": "市场核",
        "desc": "百年建筑2026-08 广州建材市场价区间",
        "source_note": "市场资讯区间价,取区间代表值",
    },
    "WBFS202607": {
        "source_type": "实战核价",
        "issuer": "CASE-A 防渗堵漏组价实战(repricing-audit)",
        "period": "2026-07",
        "region": "广东",
        "caliber": "市场主流区间核价",
        "reliability": "市场核",
        "desc": "防水堵漏专用材经repricing-audit §5.3实战核价的主流区间值",
        "source_note": "来自技能内部实战审核已核单价,非外采报价",
    },
}

# 已知批次别名（历史硬编码，保留以兼容旧写法；新批次一律走下方数据驱动匹配）
ALIAS = [
    (("广州市建设工程价格信息",), "2026-03", "GZJS202603"),
    (("百年建筑",), "2026-08", "BNJZ202608"),
    (("CASE-A 防渗堵漏", "repricing-audit", "防水堵漏组价实战"), None, "WBFS202607"),
]


def detect_batch(source: str, caliber: str, region: str, reliability: str, period: str = ""):
    """数据驱动：按(期号, 来源文字)在 meta.source_batches 中匹配批次，不再硬编码新批次。
    匹配顺序：① 历史别名 → ② 同 issuer 且同 period → ③ 仅同 issuer → ④ 仅同 period 且来源互含。
    无匹配时按 material_price_update.ensure_batch 的规则自动登记，不产生 UNKNOWN_待补批次。"""
    import hashlib
    batches = d.get("meta", {}).get("source_batches", {})
    s = (source or "").strip()

    # ① 历史别名
    for keys, per, bid in ALIAS:
        if bid in batches and (per is None or per == period) and any(k in s for k in keys):
            return bid
    # ② 同 issuer 且同 period（最精确）
    for bid, b in batches.items():
        if period and b.get("period") == period:
            iss = str(b.get("issuer", ""))
            if s and (iss == s or s in iss or iss in s):
                return bid
    # ③ 仅同 issuer
    for bid, b in batches.items():
        iss = str(b.get("issuer", ""))
        if s and iss and (iss == s or s in iss or iss in s):
            return bid
    # ④ 仅同 period
    if period:
        for bid, b in batches.items():
            if b.get("period") == period:
                return bid
    # ⑤ 无匹配 → 自动登记（与 material_price_update 同规则，保证可复现）
    suffix = hashlib.md5(f'{s}|{period}'.encode("utf-8")).hexdigest()[:6].upper()
    bid = f"X{suffix}"
    if bid in batches:
        bid = "X" + hashlib.md5(f'{s}|{period}'.encode("utf-8")).hexdigest()[:10].upper()
    batches[bid] = {
        "source_type": {"信息价税前": "造价站信息价", "信息价含税": "造价站信息价",
                        "市场价": "市场询价", "合同暂估": "厂家报价(暂估)"}.get(caliber, "市场询价"),
        "issuer": s or "（未注明来源）",
        "period": period, "region": region, "caliber": caliber,
        "reliability": reliability or "经验估",
        "desc": f'{s} {period} {region} {caliber}',
        "source_note": "由 upgrade_source_trace 回填时自动登记；须与实际来源核对",
        "auto_generated": True,
    }
    return bid


m = d["materials"]
changed = 0
for cat, info in m.items():
    specs = info.get("specs", {}) if isinstance(info, dict) else {}
    for spec, smap in specs.items():
        per = smap.get("periods", []) if isinstance(smap, dict) else []
        if not isinstance(per, list):
            continue
        for rec in per:
            if not isinstance(rec, dict):
                continue
            sid = rec.get("source_id")
            batches_now = d.get("meta", {}).get("source_batches", {})
            # 需要回填的三种情况：无 source_id / 占位 / 指向未登记批次
            need = (not sid) or sid == "UNKNOWN_待补批次" or sid not in batches_now
            if need:
                rec["source_id"] = detect_batch(
                    rec.get("来源", ""), rec.get("口径", ""),
                    rec.get("计价地区", ""), rec.get("置信度", ""),
                    rec.get("期号", ""))
                # 保留原始"来源"描述文字,仅供可读; source_id 用于机器溯源
                changed += 1

# meta 合并 source_batches：只补种子批次，绝不覆盖既有批次（含自动登记批次）
meta = d.setdefault("meta", {})
exist = meta.setdefault("source_batches", {})
added_seed = 0
for bid, b in batches.items():
    if bid not in exist:
        exist[bid] = b
        added_seed += 1
if "价记录带 source_id 关联 meta.source_batches" not in meta.get("note", ""):
    meta["note"] = meta.get("note", "") + " 价记录带 source_id 关联 meta.source_batches 来源批次,可机器溯源(见 price_trace.py)。"
# schema 升版本
if d.get("schema_version") != "1.1":
    d["schema_version"] = "1.1"
# changelog 记一笔
log = meta.setdefault("changelog", [])
log.append({"date": "2026-09-14", "action": "upgrade_source_trace",
            "note": f"溯源回填(数据驱动): 回填/修正 {changed} 条 source_id, 补种子批次 {added_seed} 个, "
                    f"批次表现有 {len(exist)} 个; 新批次自动登记,不再落 UNKNOWN_待补批次"})

# 原子写回
tmp = PATH + ".tmp"
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
os.replace(tmp, PATH)

print(f"完成: 升级 {changed} 条价记录的 source_id, meta 增 source_batches, schema->1.1")
