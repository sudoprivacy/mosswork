#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
payment_gate.py — 造价稽核官 · 平台 Pay Skill（PAYSKILL）付费闸口（agent/client 侧）

作用：把本技能接入平台"付费技能"调度契约，让平台调度层能对本技能执行
      probe → pay → complete → ack 流程，实现"按次付费、未付不放行"。

PAYSKILL 契约（平台调度层解析，脚本本地只处理三件事：402 / 验签 / 持久化）：
  1) probe（探测）：平台调用技能前先探测是否已持有本技能的支付宝有效订阅 / 付费凭证。
     已付费 → 直接放行；未付费 → 脚本向标准输出返回 HTTP 402 + Payment-Needed 标记，
     平台据此唤起付费页。
  2) pay / complete：用户在支付宝完成扣费后，平台下发 Payment-Proof（付费凭证）。
  3) ack（验签放行）：平台携带 Payment-Proof 重试本次调用；本脚本验签该凭证，确认有效后放行主流程。
  订阅持久化与幂等：付费状态缓存在本地 .pay_cache/state.json，避免每次调用重复付费；
     同一 Payment-Proof 在 24h 幂等窗口内仅生效一次，避免重复扣费。

真实验付后端：本闸口复用同目录 `alipay_payment_gateway.py`（支付宝官方 A2M 单路径资源接口）
  - 构建 402 账单：调 `build_bill()` 产出 protocol(8字段)+method(6字段)+RSA2 商家签名；
  - 验签 Payment-Proof：调 `verify_payment_flow()`（有 AIPAY_* 密钥走支付宝 SDK 真实验付，
    无密钥只走【明示模拟】并打 _mock=True，绝不伪造"已通过支付宝验付/已收款"）。
  （如改用云端计费服务，可设 PAYSKILL_CLOUD_URL，由云端点统一做 A2M 服务端。）

用法：
  python3 payment_gate.py probe  --slug cost-auditor --resource UNIT_PRICE_AUDIT [--amount 2.99]
  python3 payment_gate.py ack    --proof <base64url> --resource UNIT_PRICE_AUDIT [--slug cost-auditor]
  python3 payment_gate.py status
  python3 payment_gate.py reset                # 开发期清空本地缓存（仅清空 .pay_cache）

约定：
  - 退出码 0 = 已付费/放行；402 = 需付费（未放行）；非 0 = 错误。
  - Payment-Proof 除 --proof 外，也可经环境变量 PAYMENT_PROOF 传入（兼容平台透传）。
  - 资源定价见 alipay_payment_gateway.DEFAULT_RESOURCES（BOQ_REVIEW_ONCE/UNIT_PRICE_AUDIT/SETTLEMENT_QUERY）。
"""

import json
import os
import sys
import time
import uuid
from datetime import datetime, timedelta, timezone

# 让本脚本可在 scripts/ 内直接 import 同目录网关
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

SKILL_ROOT = os.path.dirname(_HERE)
PAY_CACHE_DIR = os.path.join(SKILL_ROOT, ".pay_cache")
PAY_CACHE_FILE = os.path.join(PAY_CACHE_DIR, "state.json")
IDEMPOTENT_TTL_HOURS = 24  # 同一 Payment-Proof 幂等窗口


# ---------------------------------------------------------------------------
# 一、依赖门控：复用同目录 A2M 网关（账单构建 + 验签后端）
# ---------------------------------------------------------------------------
def _gw():
    """惰性导入 alipay_payment_gateway（仅标准库顶层依赖，导入安全）。"""
    import alipay_payment_gateway as gw  # noqa: WPS433 (本地模块)
    return gw


def is_real_config():
    """是否具备真实验付密钥（委托网关判断）。"""
    try:
        return _gw().is_real_config()
    except Exception:
        return False


# ---------------------------------------------------------------------------
# 二、.pay_cache 本地订阅持久化（PAYSKILL 客户端缓存，24h 幂等）
# ---------------------------------------------------------------------------
def _now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat()


def _load_cache():
    if os.path.exists(PAY_CACHE_FILE):
        try:
            with open(PAY_CACHE_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"entries": {}}
    return {"entries": {}}


def _save_cache(cache):
    os.makedirs(PAY_CACHE_DIR, exist_ok=True)
    tmp = PAY_CACHE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)
    os.replace(tmp, PAY_CACHE_FILE)


def _cache_key(slug, resource_id):
    return f"{slug or 'default'}|{resource_id}"


def _is_valid(entry):
    """幂等窗口内（24h）且已验证通过，才算有效订阅。"""
    if not entry:
        return False
    exp = entry.get("expire_at")
    if not exp:
        return False
    try:
        return datetime.fromisoformat(exp).timestamp() > time.time()
    except (TypeError, ValueError):
        return False


def cache_get(slug, resource_id):
    cache = _load_cache()
    return cache.get("entries", {}).get(_cache_key(slug, resource_id))


def cache_put(slug, resource_id, proof, trade_no, amount, goods_name, mock):
    cache = _load_cache()
    k = _cache_key(slug, resource_id)
    now = _now_iso()
    entry = {
        "slug": slug,
        "resource_id": resource_id,
        "proof": proof,
        "trade_no": trade_no,
        "amount": amount,
        "goods_name": goods_name,
        "mock": mock,
        "paid_at": now,
        "expire_at": (datetime.now(timezone.utc).astimezone()
                      + timedelta(hours=IDEMPOTENT_TTL_HOURS)).isoformat(),
    }
    cache.setdefault("entries", {})[k] = entry
    _save_cache(cache)
    return entry


def cache_reset():
    cache = _load_cache()
    cache["entries"] = {}
    _save_cache(cache)


# ---------------------------------------------------------------------------
# 三、probe：探测是否已付费；未付则下发 402 + Payment-Needed
# ---------------------------------------------------------------------------
# 形态开关：CAP_EDITION=free（默认）→ 完全不收费，probe 直接放行。
# 想切回按次付费：export CAP_EDITION=pay（并恢复 SKILL.md frontmatter 的 pay: 块）。
EDITION = (os.environ.get("CAP_EDITION", "free") or "free").strip().lower()
FREE_MODE = EDITION != "pay"

FREE_BODY = {
    "status": "FREE",
    "paid": True,
    "message": "免费形态（CAP_EDITION=free）：不收取任何费用，直接放行主流程",
    "edition": "free",
    "switch_back": "export CAP_EDITION=pay",
}


def probe(resource_id, slug=None, amount=None, goods_name=None):
    """返回 (paid: bool, status_code, payment_needed_or_None, body_dict)。

    免费形态（默认）：直接返回 (True, 200, None, FREE_BODY)，不建单、不返 402。
    付费形态：先查 .pay_cache（PAYSKILL 客户端 24h 持久化），有效则放行；
    否则委托 A2M 网关 handle_resource_request 建 PENDING 订单并下发 402 + Payment-Needed。
    """
    if FREE_MODE:
        return True, 200, None, dict(FREE_BODY, resource_id=resource_id)
    cached = cache_get(slug, resource_id)
    if _is_valid(cached):
        return True, 200, None, {
            "status": "PAID", "message": "已持有有效付费凭证，直接放行",
            "resource_id": resource_id, "trade_no": cached.get("trade_no"),
            "mock": cached.get("mock", False),
        }
    gw = _gw()
    amt = amount or gw.DEFAULT_RESOURCES.get(resource_id, ("按量资源", "0.99"))[1]
    gn = goods_name or gw.DEFAULT_RESOURCES.get(resource_id, ("按量资源", ""))[0]
    status, body, payment_needed = gw.handle_resource_request(
        resource_id, amount=amt, goods_name=gn)
    body.setdefault("_mock_note", None if is_real_config() else "占位(RSA2未配置密钥)")
    return False, status, payment_needed, body


def emit_probe(resource_id, slug=None, amount=None, goods_name=None):
    """向标准输出下发 402 + Payment-Needed（平台据此唤起付费页）。"""
    paid, code, pn, body = probe(resource_id, slug, amount, goods_name)
    if paid:
        print("HTTP 200 OK")
        print(json.dumps(body, ensure_ascii=False))
        return 0
    print("HTTP 402 Payment Required")
    print(f"Payment-Needed: {pn}")
    print(f"X-Pay-Resource: {resource_id}")
    print(f"X-Pay-Amount: {body['amount']}")
    print(f"X-Pay-Currency: CNY")
    print(json.dumps(body, ensure_ascii=False))
    return 402


# ---------------------------------------------------------------------------
# 四、ack：验签 Payment-Proof 并持久化（放行主流程）
# ---------------------------------------------------------------------------
def ack(proof, resource_id, slug=None, amount=None):
    """验签 Payment-Proof：委托 A2M 网关 handle_resource_request 做验付/履约；
    成功则写入 .pay_cache（24h 幂等）并返回 (ok, body, code)。

    免费形态（默认）：无需 Proof，直接放行（写入免费标记，不落 .pay_cache）。
    """
    if FREE_MODE:
        return True, dict(FREE_BODY, resource_id=resource_id,
                          note="免费形态下 Payment-Proof 非必需，也未做任何验签"), 200
    if not proof or not proof.strip():
        return False, {"status": "rejected", "message": "缺少 Payment-Proof"}, 402
    gw = _gw()
    amt = amount or gw.DEFAULT_RESOURCES.get(resource_id, ("按量资源", "0.99"))[1]
    status, body, _ = gw.handle_resource_request(
        resource_id, payment_proof=proof, amount=amt)
    if status != 200:
        return False, {"status": "rejected", "message": "Payment-Proof 验签未通过",
                       "detail": body}, 402
    # 验签通过 → 持久化（24h 幂等，避免每次调用重复付费）
    cached = cache_get(slug, resource_id)
    is_mock = not is_real_config()
    if _is_valid(cached):
        return True, {"status": "PAID", "message": "凭证已在缓存期内，幂等放行（不重复扣费）",
                      "resource_id": resource_id, "trade_no": cached.get("trade_no"),
                      "mock": cached.get("mock", is_mock)}, 200
    entry = cache_put(slug, resource_id, proof, body.get("trade_no"), amt,
                      gw.DEFAULT_RESOURCES.get(resource_id, ("按量资源", ""))[0],
                      is_mock)
    return True, {"status": "PAID", "message": "验签通过，已放行主流程",
                  "resource_id": resource_id, "trade_no": entry.get("trade_no"),
                  "mock": entry.get("mock", False)}, 200


def emit_ack(proof, resource_id, slug=None, amount=None):
    ok, body, code = ack(proof, resource_id, slug, amount)
    print(f"HTTP {code} {'OK' if code == 200 else 'Payment Required'}")
    print(json.dumps(body, ensure_ascii=False))
    return 0 if ok else 402


# ---------------------------------------------------------------------------
# 五、库函数：技能主流程调用此函数做"付费门禁"
# ---------------------------------------------------------------------------
def require_paid(resource_id, slug=None, proof=None, amount=None):
    """技能主流程入口：已付费返回 (True, info)；未付返回 (False, 402信息, payment_needed)。"""
    if proof and proof.strip():
        ok, body, _ = ack(proof, resource_id, slug, amount)
        if ok:
            return True, body
    paid, code, pn, body = probe(resource_id, slug, amount)
    if paid:
        return True, body
    return False, {"status": code, "payment_needed": pn, "body": body}


# ---------------------------------------------------------------------------
# 六、命令行入口
# ---------------------------------------------------------------------------
def main():
    import argparse
    p = argparse.ArgumentParser(description="造价稽核官 · Pay Skill（PAYSKILL）付费闸口")
    sub = p.add_subparsers(dest="cmd")
    pr = sub.add_parser("probe", help="探测是否已付费；未付下发 402+Payment-Needed")
    pr.add_argument("--slug", default="cost-auditor")
    pr.add_argument("--resource", required=True)
    pr.add_argument("--amount")
    pr.add_argument("--goods-name")
    ac = sub.add_parser("ack", help="验签 Payment-Proof 并放行")
    ac.add_argument("--proof", required=False)
    ac.add_argument("--resource", required=True)
    ac.add_argument("--slug", default="cost-auditor")
    ac.add_argument("--amount")
    st = sub.add_parser("status", help="查看本地订阅缓存")
    rs = sub.add_parser("reset", help="清空本地 .pay_cache（开发期）")
    md = sub.add_parser("mode", help="查看当前形态（免费 / 需付费）")
    a = p.parse_args()

    if not a.cmd:
        p.print_help()
        return
    if a.cmd == "mode":
        print(json.dumps({
            "edition": EDITION,
            "free_mode": FREE_MODE,
            "payment_required": not FREE_MODE,
            "real_pay_configured": is_real_config(),
            "note": ("免费形态：probe/ack 直接放行，不收费、不需要任何密钥"
                     if FREE_MODE else
                     "付费形态：未付返 402 + Payment-Needed，ack 需验签 Payment-Proof"),
            "switch_back": "export CAP_EDITION=pay",
        }, ensure_ascii=False, indent=2))
        return 0
    if a.cmd == "probe":
        return emit_probe(a.resource, a.slug, a.amount, getattr(a, "goods_name", None))
    if a.cmd == "ack":
        proof = a.proof or os.environ.get("PAYMENT_PROOF") or ""
        return emit_ack(proof, a.resource, a.slug, a.amount)
    if a.cmd == "status":
        cache = _load_cache()
        print(json.dumps(cache, ensure_ascii=False, indent=2))
        return 0
    if a.cmd == "reset":
        cache_reset()
        print("已清空 .pay_cache/state.json")
        return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
