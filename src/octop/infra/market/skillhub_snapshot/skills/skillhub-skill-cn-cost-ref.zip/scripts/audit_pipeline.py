#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
audit_pipeline.py — 审价流水线编排器（一条命令审一份报价/预算）

把技能已有脚本串成一条端到端审价命令：给一份报价单(或预算抽出的价目)，自动
  ① 定位可比价/证据(price_trace 溯源 + material_price_lookup 检索)
  ② 三源比价判虚高(audit_triple_source)
  ③ 汇总输出一份结构化审价报告(虚高项 + 证据链 + 效力口径 + 建议)

复用现有模块(不重复造轮子)：
  - audit_triple_source.audit_material / audit_testing / audit_policy
  - price_trace 的 效力评级/来源链 逻辑（经 material_prices.json + policy_files.json）

输入(任选其一)：
  A) --quote 报价单.csv（列: 项目名,数量,单价,单位,类别[材料|检测|其他]，同 audit-file）
  B) --items 命令行直接给 "材料名 单价 单位 [类别]" 可多次(适合临时一两行)
输出：
  --out report.md (默认 stdout) / --json out.json（结构给上层/学习系统/A402资源绑定消费）

用法：
  python3 audit_pipeline.py --quote 报价.csv --region 广州 --out 审价报告.md
  python3 audit_pipeline.py --items "HRB400E 3500 t 材料" "回弹法 800 构件 检测" --region 广州
  python3 audit_pipeline.py --json audit.json --quote 报价.csv
"""
import json, os, sys, csv, argparse
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

try:
    from audit_triple_source import audit_material, audit_testing, audit_policy
except Exception as e:  # noqa: BLE001
    sys.exit(f'[x] 无法导入 audit_triple_source 模块: {e}')


# 判定优先级（供汇总/报告排序：先把最该核的放前面）
ORDER = {'虚高(建议核减)': 0, '仅历史参考(效力警示)': 1, '存疑(市场核参考)': 2,
         '可核': 3, '口径/单位不一致': 4, '缺当期可比源': 5, '待人工核对': 6, '库无此检测项': 6}


def parse_csv_rows(path):
    rows = []
    with open(path, encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            rows.append(r)
    out = []
    for r in rows:
        kw = (r.get('项目名') or r.get('kw') or '').strip()
        cat = (r.get('类别') or '材料').strip()
        try:
            price = float(r.get('单价') or r.get('price') or 0)
            qty = float(r.get('数量') or r.get('qty') or 1)
        except ValueError:
            print(f'  ⚠ 跳过无法解析数量/单价的行: {r}')
            continue
        unit = (r.get('单位') or r.get('unit') or '').strip()
        out.append({'kw': kw, 'price': price, 'qty': qty, 'unit': unit, 'cat': cat})
    return out


def parse_items_args(items):
    out = []
    for it in items:
        parts = it.split()
        if len(parts) < 3:
            print(f'  ⚠ 忽略无法解析的项: {it}（格式: 名称 单价 单位 [类别]）')
            continue
        kw = parts[0]
        try:
            price = float(parts[1])
        except ValueError:
            print(f'  ⚠ 忽略单价非数字: {it}')
            continue
        unit = parts[2]
        cat = parts[3] if len(parts) > 3 else '材料'
        out.append({'kw': kw, 'price': price, 'qty': 1, 'unit': unit, 'cat': cat})
    return out


def run_one(line, region):
    """对一行执行审计，返回 {判定+来源+效力}。失败不中断，标 待人工核对。"""
    cat = line.get('cat') or '材料'
    try:
        if cat == '检测':
            l = audit_testing(line['kw'], line['price'], line['unit'], line['qty'])
        elif cat == '材料':
            l = audit_material(line['kw'], line['price'], line['unit'], region, line['qty'])
        else:
            l = {'kw': line['kw'], 'quote': line['price'], 'qty': line['qty'], 'cat': cat,
                 'verdict': '待人工核对',
                 'note': '非材料/非检测类，三源脚本不自动判', 'source': '—'}
        l['pol'] = audit_policy(l.get('verdict', ''), '检测' if cat == '检测' else '材料').get('hint', '')
        l['unit'] = line['unit']  # 透传报价单位进报告
        return l
    except Exception as e:  # noqa: BLE001
        return {'kw': line['kw'], 'quote': line['price'], 'qty': line['qty'], 'cat': cat,
                'verdict': '待人工核对', 'note': f'审计脚本异常: {e}', 'source': '—', 'pol': '',
                'unit': line.get('unit', '')}


def render_md(rows, region, src_desc):
    lines = ['# 审价流水线报告', '']
    lines.append(f'> 输入：{src_desc}  地区：{region or "不限"}  生成：流水线编排(audit_pipeline)')
    lines.append('> 结论为单价合理性初判，虚高项仍需人工复核数量真实性与费用归属后再定核减。\n')
    lines.append('| # | 类别 | 项目 | 报价 | 单位 | 判定 | 可比参考 | 来源 |')
    lines.append('|---|---|---|---|---|---|---:|---|')
    ordered = sorted(rows, key=lambda r: ORDER.get(r['verdict'], 9))
    for i, r in enumerate(ordered, 1):
        ref = f"{r.get('ref_price','')} {r.get('ref_unit','')}" if r.get('ref_price') is not None else '—'
        src = (r.get('source') or '—')
        lines.append(f"| {i} | {r.get('cat')} | {r['kw']} | {r.get('quote')} | {r.get('unit','?')} | "
                     f"**{r.get('verdict')}** | {ref} | {src} |")
    lines.append('')
    cnt = Counter(r['verdict'] for r in rows)
    lines.append('## 汇总')
    lines.append('| 判定 | 数量 |')
    lines.append('|---|---:|')
    for k, v in cnt.most_common():
        lines.append(f'| {k} | {v} |')
    lines.append('')
    # 每条备注与效力
    lines.append('## 逐项说明与效力')
    for i, r in enumerate(ordered, 1):
        lines.append(f'\n**{i}. {r["kw"]}** ({r.get("cat")})  → {r.get("verdict")}')
        if r.get('note'):
            lines.append(f'   - {r["note"]}')
        if r.get('pol'):
            lines.append(f'   - 效力口径：{r["pol"]}')
    lines.append('\n> ⚠ 仅"可核"(权威信息价)可直接作核减基准；市场核须取区间合理值并与对方交叉印证；涉检测费注意效力警示。')
    return '\n'.join(lines)


def main():
    p = argparse.ArgumentParser(description='造价稽核官·审价流水线(一条命令审报价)')
    p.add_argument('--quote', default=None, help='报价单 csv(项目名,数量,单价,单位,类别)')
    p.add_argument('--items', nargs='*', default=[], help='命令行直接给 名称 单价 单位 [类别]，可多个')
    p.add_argument('--region', default=None, help='地区,如 广州')
    p.add_argument('--out', default=None, help='写报告 .md')
    p.add_argument('--json', default=None, help='写结构化结果 .json')
    a = p.parse_args()

    if not a.quote and not a.items:
        p.print_help()
        return
    lines = []
    if a.quote:
        lines += parse_csv_rows(a.quote)
    lines += parse_items_args(a.items)
    if not lines:
        sys.exit('[x] 没有可审计的行(输入为空或全部无法解析)')

    results = []
    for ln in lines:
        results.append(run_one(ln, a.region))

    src_desc = a.quote or ('命令行 ' + str(len(lines)) + ' 项')
    md = render_md(results, a.region, src_desc)
    if a.out:
        open(a.out, 'w', encoding='utf-8').write(md)
        print(f'→ 审价报告已写: {a.out}')
    else:
        print(md)

    if a.json:
        json.dump({'region': a.region, 'rows': results, 'summary': dict(Counter(r['verdict'] for r in results))},
                  open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        print(f'→ JSON 已写: {a.json}')

    # 简报
    cnt = Counter(r['verdict'] for r in results)
    print('\n[简报] ' + ' | '.join(f'{k}={v}' for k, v in cnt.items()))


if __name__ == '__main__':
    main()
