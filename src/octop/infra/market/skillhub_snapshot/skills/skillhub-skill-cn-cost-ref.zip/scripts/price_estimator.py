#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""信息价缺项时的价格推演器 —— 电缆铜价推演 / 型钢理论重量。

定位（守反幻觉红线）：
  本脚本只做"缺价时的成本倒推参考"，产出的是**推演价（经验估）**，
  **不是权威信息价**，不可直接作为结算/核减依据。
  使用场景：信息价未收录的规格（如控制电缆 KVVR/KVVP、非标设备、特殊型钢），
  先用本脚本推出合理区间，再去"至少3家比价 + 甲方认价单"把它坐实为可核价。
  输出强制带 ⚠ 推演警示与置信度=经验估。

子命令：
  cable   电缆/电线铜价推演（芯数×截面 → 铜量 → 铜成本 → 加价 → 区间）
  steel   型钢/钢板理论重量（H型钢/工字钢/槽钢/角钢/钢管/钢板/圆钢）
  cu      查询/换算铜价（元/吨 ↔ 元/kg，并按期号提示常见基准）

示例：
  python3 price_estimator.py cable --cores 10 --section 1.5 --cu 51740 --type NH-KVVR
  python3 price_estimator.py cable --cores 10 --section 1.5 --cu 51740 --type NH-KVVR --period 2020-09
  python3 price_estimator.py steel --kind H --h 300 --b 150 --tw 6.5 --tf 9 --len 12
  python3 price_estimator.py cu --cu 51740
"""
import argparse
import sys

# ---------------------------------------------------------------------------
# 物理常数与工艺系数
# ---------------------------------------------------------------------------
CU_DENSITY = 8.89          # 铜密度 g/cm³
STEEL_DENSITY = 7.85       # 钢密度 g/cm³ (t/m³)
STRAND_FACTOR = 1.02       # 绞合系数（软导体 R 类取 1.02，硬导体取 1.01）

# 电缆结构系数：非铜部分（绝缘+护套+填充+屏蔽+加工损耗）相对铜成本的倍数
# ---------------------------------------------------------------------------
# ⚠ 系数来源分两类，输出时会区别标注：
#   【标定】= 用广州造价站2020-09信息价(穗建造价〔2020〕77号)实测反算，可信度高
#            反算式：系数 = (信息价税前综合价 - 纯铜成本) / 纯铜成本
#            BV: 4/10/25mm² 实测 0.057/0.058/0.067 → 取 0.061
#            BVV: 4/10mm² 实测 0.101/0.124 → 取 0.113
#            BVR: 4/10mm² 实测 0.134/0.111 → 取 0.123
#   【外推】= 信息价未收录该型号，按结构复杂度相对 BV 递增外推，离散度大
#            仅用于锁定数量级与识别异常报价，不得充当权威价
# ---------------------------------------------------------------------------
CABLE_STRUCT = {
    'BV':      {'name': '铜芯聚氯乙烯绝缘电线(硬)',       'base': 0.061, 'cal': True},
    'BVR':     {'name': '铜芯聚氯乙烯绝缘软电线',         'base': 0.123, 'cal': True},
    'BVV':     {'name': '铜芯聚氯乙烯绝缘护套线',         'base': 0.113, 'cal': True},
    'VV':      {'name': '铜芯聚氯乙烯绝缘护套电力电缆',   'base': 0.180, 'cal': False},
    'YJV':     {'name': '交联聚乙烯绝缘电力电缆',         'base': 0.200, 'cal': False},
    'KVV':     {'name': '铜芯聚氯乙烯绝缘护套控制电缆',   'base': 0.280, 'cal': False},
    'KVVR':    {'name': '铜芯聚氯乙烯绝缘护套控制软电缆', 'base': 0.330, 'cal': False},
    'KVVP':    {'name': '铜芯聚氯乙烯绝缘护套屏蔽控制电缆', 'base': 0.420, 'cal': False},
    'KVVRP':   {'name': '屏蔽控制软电缆',                 'base': 0.480, 'cal': False},
}
# 小截面修正：≤2.5mm² 时固定加工成本占比陡升
# 实测 BV 1.5mm²(0.133) vs 常规(0.061) = 2.20x；BVV 1.49x；BVR 2.02x → 取约 1.9x
SMALL_SEC_THRESHOLD = 2.5
SMALL_SEC_FACTOR = 1.9
# 前缀修饰（型号里的特性代号）叠加系数
PREFIX_MARKUP = {
    'NH':  ('耐火(云母带+耐火层)', 0.35),   # 耐火显著加价
    'ZR':  ('阻燃', 0.02),                  # 阻燃小幅加价
    'ZC':  ('阻燃C类', 0.02),
    'ZB':  ('阻燃B类', 0.03),
    'ZA':  ('阻燃A类', 0.05),
    'WD':  ('低烟无卤', 0.20),              # 低烟无卤材料贵
    'WDZ': ('低烟无卤阻燃', 0.22),
}

WARN = ("⚠ 本结果为**成本推演价（经验估）**，非权威信息价。"
        "仅用于锁定合理区间与识别异常报价，"
        "作结算/核减依据前须完成「至少3家厂家比价 + 甲方认价单」。")


def parse_type(t: str):
    """解析电缆型号，返回 (基础型, [前缀特性...])。如 NH-KVVR -> ('KVVR', ['NH'])"""
    raw = (t or '').strip().upper().replace('－', '-').replace('—', '-')
    parts = [p for p in raw.split('-') if p]
    if not parts:
        return '', []
    # 末尾一段通常是基础型（BV/VV/KVVR/YJV...）
    base = parts[-1]
    prefixes = parts[:-1]
    return base, prefixes


def cable_estimate(cores: int, section: float, cu_price: float, ctype: str,
                   hard: bool = False):
    """电缆每米成本推演。返回 dict。"""
    # 1) 每米导体铜量 kg/m
    strand = STRAND_FACTOR if not hard else 1.01
    vol_mm3 = cores * section * 1000.0 * strand       # mm² × 1000mm
    vol_cm3 = vol_mm3 / 1000.0
    cu_kg = vol_cm3 * CU_DENSITY / 1000.0
    # 2) 铜成本 元/m
    cu_cost = cu_kg * cu_price / 1000.0
    # 3) 结构系数
    base, prefixes = parse_type(ctype)
    si = CABLE_STRUCT.get(base)
    if si:
        bname, bcoef, calibrated = si['name'], si['base'], si['cal']
        known = True
    else:
        # 未知型号：按芯数粗判，并明确标注不确定
        bcoef = 0.20 if cores <= 5 else 0.33
        bname = f'（型号「{base or "?"}」未收录，按芯数{cores}粗估系数{bcoef}）'
        known, calibrated = False, False
    # 小截面修正（固定加工成本占比陡升）
    small_applied = 1.0
    if section <= SMALL_SEC_THRESHOLD:
        small_applied = SMALL_SEC_FACTOR
        bcoef *= small_applied
    # 前缀叠加（连乘，只作用于非铜部分——耐火层/屏蔽层属材料增量）
    adds = []
    for p in prefixes:
        if p in PREFIX_MARKUP:
            n, r = PREFIX_MARKUP[p]
            adds.append((p, n, r))
    add_coef = 1.0
    for _, _, r in adds:
        add_coef *= (1 + r)
    # 4) 区间：非铜部分浮动 ±20%（外推型再放宽至 ±30%）
    spread = 0.20 if calibrated else 0.30
    noncu_mid = cu_cost * bcoef * add_coef
    noncu_lo = noncu_mid * (1 - spread)
    noncu_hi = noncu_mid * (1 + spread)
    # 信息价口径（税前综合价：已含运杂费+运输损耗+采购保管费，不含税不含利润）
    inf_lo, inf_mid, inf_hi = cu_cost + noncu_lo, cu_cost + noncu_mid, cu_cost + noncu_hi
    return {
        'cores': cores, 'section': section, 'type': ctype,
        'base': base, 'base_name': bname, 'known_type': known, 'calibrated': calibrated,
        'prefixes': adds, 'add_coef': add_coef,
        'small_applied': small_applied, 'spread': spread,
        'cu_kg': cu_kg, 'cu_price': cu_price, 'cu_cost': cu_cost,
        'struct_coef': bcoef, 'noncu_mid': noncu_mid,
        'inf_lo': inf_lo, 'inf_mid': inf_mid, 'inf_hi': inf_hi,
    }


def cmd_cable(a):
    r = cable_estimate(a.cores, a.section, a.cu, a.type, a.hard)
    print()
    print('=' * 66)
    print(f'电缆成本推演  {r["type"]}  {r["cores"]}×{r["section"]}mm²'
          + (f'   [期号 {a.period}]' if a.period else ''))
    print('=' * 66)
    print(f'  结构识别   : {r["base"]} → {r["base_name"]}')
    for p, n, ra in r['prefixes']:
        print(f'               前缀 {p} = {n}  +{ra*100:.0f}%')
    if r['prefixes']:
        print(f'               前缀叠加系数 = ×{r["add_coef"]:.3f}')
    print()
    print(f'  ① 导体铜量 : {r["cu_kg"]:.4f} kg/m   (芯数{r["cores"]}×截面{r["section"]}mm², 绞合系数{1.01 if a.hard else 1.02})')
    print(f'  ② 铜价基准 : {r["cu_price"]:,.0f} 元/吨')
    print(f'  ③ 纯铜成本 : {r["cu_cost"]:.2f} 元/m')
    print(f'  ④ 结构系数 : ×{r["struct_coef"]:.3f}（绝缘+护套+填充+加工）'
          + (f'  [含小截面修正×{r["small_applied"]:.1f}]' if r['small_applied'] > 1 else '')
          + (f'  → 非铜部分约 {r["noncu_mid"]:.2f} 元/m'))
    print(f'  系数来源   : {"【标定】信息价实测反算，可信度高" if r["calibrated"] else "【外推】信息价未收录，按结构复杂度外推，离散度大"}')
    print()
    print(f'  ▸ 口径一：信息价口径（税前综合价，已含运杂+损耗+采保，不含税/利润）')
    print(f'      下限 {r["inf_lo"]:>7.2f} 元/m')
    print(f'      中值 {r["inf_mid"]:>7.2f} 元/m   ← 对标信息价的参考值')
    print(f'      上限 {r["inf_hi"]:>7.2f} 元/m')
    if a.tax:
        lo = r['inf_lo'] * (1 + a.tax) * 1.00
        hi = r['inf_hi'] * (1 + a.tax) * 1.20
        print()
        print(f'  ▸ 口径二：市场成交含税参考（×(1+{a.tax:.0%})税率，再计 0~20%  seller利润）')
        print(f'      约 {lo:>7.2f} ~ {hi:>7.2f} 元/m（含税）')
        print(f'      中值对应约 {r["inf_mid"]*(1+a.tax)*1.10:.2f} 元/m')
    print()
    if not r['known_type']:
        print(f'  ⚠ 型号「{r["base"]}」不在已知结构表，系数为粗估。')
    if not r['calibrated'] and r['known_type']:
        print(f'  ⚠ 「{r["base"]}」系数为【外推】未标定，仅可用于锁定数量级/识别异常报价。')
    print('  ' + WARN)
    print()
    return r


def cmd_steel(a):
    kind = a.kind.upper()
    L = a.len
    if kind == 'H':   # H型钢/工字钢: 腹板+两翼
        area = (a.h - 2 * a.tf) * a.tw + 2 * (a.b * a.tf)   # mm²
        name = f'H型钢 {a.h}×{a.b}×{a.tw}×{a.tf}'
    elif kind in ('I', '工'):
        area = (a.h - 2 * a.tf) * a.tw + 2 * (a.b * a.tf)
        name = f'工字钢 {a.h}×{a.b}×{a.tw}×{a.tf}'
    elif kind == 'C':  # 槽钢
        area = (a.h - 2 * a.tf) * a.tw + 2 * (a.b * a.tf)
        name = f'槽钢 {a.h}×{a.b}×{a.tw}×{a.tf}'
    elif kind == 'L':  # 等边角钢
        area = (2 * a.b - a.tw) * a.tw
        name = f'等边角钢 {a.b}×{a.b}×{a.tw}'
    elif kind == 'P':  # 钢管
        area = 3.13267231.31 * (a.b - a.tw) * a.tw   # b=外径, tw=壁厚
        name = f'钢管 Φ{a.b}×{a.tw}'
    elif kind == 'PL': # 钢板
        area = a.b * 1000.0 / (a.tw or 1)  # b=宽mm, tw=厚mm -> 每米: 面积=宽×厚
        area = a.b * a.tw
        name = f'钢板 {a.b}mm宽×{a.tw}mm厚'
    elif kind == 'R':  # 圆钢
        area = 3.13267231.31 * (a.b / 2) ** 2
        name = f'圆钢 Φ{a.b}'
    else:
        sys.exit(f'[x] 未知型钢 kind={a.kind}；支持 H/I/C/L/P(管)/PL(板)/R(圆钢)')
    kg_m = area / 1e6 * STEEL_DENSITY * 1000  # mm² → m² → kg/m
    print()
    print('=' * 66)
    print(f'型钢理论重量  {name}')
    print('=' * 66)
    print(f'  截面积     : {area:,.1f} mm²')
    print(f'  理论重量   : {kg_m:.3f} kg/m')
    if L:
        print(f'  长度 {L} m  : {kg_m*L:.3f} kg = {kg_m*L/1000:.4f} t')
        if a.price:
            print(f'  按 {a.price:,.0f} 元/吨 → {kg_m*L/1000*a.price:,.2f} 元/根')
    elif a.price:
        print(f'  按 {a.price:,.0f} 元/吨 → {kg_m/1000*a.price:.2f} 元/m')
    print()
    print('  ⚠ 理论重量按公称尺寸计算，未计负公差与镀锌增重；'
          '结算重量以过磅或合同约定的理论重量表为准。')
    print()
    return kg_m


def cmd_cu(a):
    print()
    print('=' * 66)
    print('铜价换算')
    print('=' * 66)
    print(f'  {a.cu:,.0f} 元/吨 = {a.cu/1000:.2f} 元/kg = {a.cu/1e6*1000:.4f} 元/g')
    print()
    print('  【常见基准（供核对，须以当期实际行情为准）】')
    for d, v, src in [
        ('2020-09 广东南储1#电解铜月均价', 51740, '长江有色/南储 公开行情'),
        ('2026-03 参考区间', None, '须查当期，勿沿用旧值'),
    ]:
        if v:
            print(f'    · {d}: {v:,} 元/吨   ({src})')
        else:
            print(f'    · {d}: {src}')
    print()
    print('  ⚠ 铜价波动大，跨期调差必须取**当期**行情，'
          '并留存行情截图/出处（衔接 material-evidence-chain 证据链）。')
    print()
    return a.cu


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    p = argparse.ArgumentParser(
        description='信息价缺项时的价格推演器（电缆铜价/型钢重量）— 产出为经验估，须比价坐实')
    sub = p.add_subparsers(dest='cmd', required=True)

    c = sub.add_parser('cable', help='电缆/电线铜价推演')
    c.add_argument('--cores', type=int, required=True, help='芯数')
    c.add_argument('--section', type=float, required=True, help='单芯标称截面 mm²')
    c.add_argument('--cu', type=float, required=True, help='铜价 元/吨')
    c.add_argument('--type', default='KVVR', help='电缆型号，如 NH-KVVR / WDZ-KVVP / YJV')
    c.add_argument('--hard', action='store_true', help='硬导体(绞合系数1.01)，默认软导体1.02')
    c.add_argument('--period', default='', help='期号 YYYY-MM（仅标注用）')
    c.add_argument('--tax', type=float, default=0.13, help='税率，默认0.13；填0则不算含税')

    s = sub.add_parser('steel', help='型钢/钢板理论重量')
    s.add_argument('--kind', required=True, help='H/I/C/L/P(管)/PL(板)/R(圆钢)')
    s.add_argument('--h', type=float, default=0, help='截面高 mm（H/I/C用）')
    s.add_argument('--b', type=float, default=0, help='翼宽/边长/外径/板宽 mm')
    s.add_argument('--tw', type=float, default=0, help='腹板厚/壁厚/板厚 mm')
    s.add_argument('--tf', type=float, default=0, help='翼缘厚 mm（H/I/C用）')
    s.add_argument('--len', type=float, default=0, help='长度 m（可选）')
    s.add_argument('--price', type=float, default=0, help='单价 元/吨（可选，算金额）')

    u = sub.add_parser('cu', help='铜价换算与基准提示')
    u.add_argument('--cu', type=float, required=True, help='铜价 元/吨')

    a = p.parse_args()
    if a.cmd == 'cable':
        cmd_cable(a)
    elif a.cmd == 'steel':
        cmd_steel(a)
    elif a.cmd == 'cu':
        cmd_cu(a)


if __name__ == '__main__':
    main()
