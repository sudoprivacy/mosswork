#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
labor_settlement_audit.py — 清工/包人工（劳务分包）结算审核器
================================================================
填补本技能空白：settlement-audit.md 是按「包工包料」写的，核减点清单
（虚方当实方/主材单价/定额损耗叠加/材料价调差）在**只包人工**的合同里全部失效。
本脚本固化「清工结算」八大特有核减点与三层级核对法。

适用合同类型：包清工 / 包工不包料 / 劳务分包 / 点工（计时工）
识别特征：合同写「承包方式：清工（只包人工）」「乙方只负责做工，不包料」，
          单价为**元/㎡、元/m、元/个**的**纯人工单**，无主材、无综合单价、无取费。

八大清工特有核减点（对应 SKILL.md 模块七 §7.9）：
  P1 单面/双面计量   墙板按墙面计算时是否把墙两侧都算了（比值≈2 即中招）
  P2 展开/投影计量   造型天花/跌级/弧形按展开还是水平投影
  P3 图纸查无项      单据房号在图纸上不存在（未见变更签证者不列）
  P4 未进小计项      明细写了但小计没加（反向敞口，须书面定性）
  P5 算术错误        明细相加 ≠ 小计（以明细为准）
  P6 重复计量        同一部位在不同页/不同房号重复出现
  P7 单价无书面依据  合同正文与补注均无此单价
  P8 合同优惠/让价   合同约定的一次性让价未扣减

三层级核对法：明细逐条 量×单价 → 房间小计 → 页小计（三层必须闭合）

反幻觉纪律：
  - 每一条核减必须能指向具体证据（合同条款/图纸页号/单据页号），否则不列。
  - 「待核实」项不产生核减额，只列入问询清单，不预扣。

依赖：标准库（无第三方依赖）

子命令：
  check     对一份结算明细做三层级核对（读 JSON）
  crosspage 跨页重复计量检测（比对多个页小计中的相同房号/部位）
  audit     综合审核：八大核减点逐项判定并汇总
  demo      内置样例自检（用本技能实战案例数据）
"""
import os
import sys
import json
import argparse


# ----------------------------------------------------------------------------
# 八大核减点定义（供 audit 与报告输出使用）
# ----------------------------------------------------------------------------
AUDIT_POINTS = [
    ("P1", "单面/双面计量", "★★★",
     "墙面类按『墙面积』计量时，是否把墙体两侧都计了。判据：报量 ÷ (图纸墙长×层高) ≈ 2.0",
     "要求乙方书面确认计量口径；无约定时按 GB/T 50854-2024 装饰墙面按『实贴（饰面）面积』单面计量"),
    ("P2", "展开/投影计量", "★★★",
     "造型/跌级/弧形/艺术天棚按展开面积还是水平投影面积。判据：见 decorative-drawings §4.3",
     "有约定从约定；无约定按计量规则——跌级≤300mm并入平面、300~600mm展开1.5倍跌级高度、>600mm全展开"),
    ("P3", "图纸查无项", "★★★",
     "单据所列房号/部位在图纸上不存在。判据：房号清册比对",
     "未见设计变更单/现场签证者不予列入（反幻觉红线2：无证据的主张不成立）"),
    ("P4", "未进小计项", "★★",
     "明细页写了金额但未计入小计。判据：页内明细之和 vs 页小计",
     "★反向敞口——对甲方有利，但必须书面定性『是否主张』，防止事后补报"),
    ("P5", "算术错误", "★★",
     "明细相加 ≠ 小计；或 量×单价 ≠ 金额。判据：逐条重算",
     "以明细相加为准（重算值），修正后的差额计入核减"),
    ("P6", "重复计量", "★★",
     "同一部位在不同页/不同房号重复出现。判据：跨页比对部位名+数量",
     "只计一次；重复部分核减"),
    ("P7", "单价无书面依据", "★★★",
     "合同正文、补注、附件均未约定该单价。判据：合同单价表逐条检索",
     "无书面依据的单价不予认可，按合同已有相近单价或另行协商（须留书面）"),
    ("P8", "合同优惠/让价", "★",
     "合同约定的一次性让价/优惠未在结算中扣减。判据：合同价款条款",
     "按合同约定扣减"),
]


# ----------------------------------------------------------------------------
# 三层级核对
# ----------------------------------------------------------------------------
def three_level_check(rooms):
    """三层级核对：明细 → 房间小计 → 页小计。

    rooms: [{"room":"男标SPA间1","page":"img10",
             "items":[{"desc":"吊顶","qty":12.56,"price":60,"amount":753.6}, ...],
             "stated_room_subtotal": 1832.0,      # 单据写的房间小计（可空）
             "stated_page_subtotal": None}, ...]  # 单据写的页小计（可空）
    """
    out = []
    for r in rooms:
        calc_items = []
        for it in r["items"]:
            calc = round(it["qty"] * it["price"], 2)
            calc_items.append({**it, "calc_amount": calc,
                               "diff": round(calc - it.get("amount", calc), 2)})
        calc_room = round(sum(i["calc_amount"] for i in calc_items), 2)
        stated_room = r.get("stated_room_subtotal")
        row = {
            "room": r["room"], "page": r.get("page", ""),
            "calc_room_subtotal": calc_room,
            "stated_room_subtotal": stated_room,
            "room_diff": None if stated_room is None else round(calc_room - stated_room, 2),
            "item_errors": [i for i in calc_items if i["diff"] != 0],
        }
        out.append(row)
    return out


def crosspage_dupe(pages):
    """跨页重复计量检测。

    pages: [{"page":"img12","rows":[{"room":"男豪华6房","qty":16.8}, ...]}, ...]
    返回同名同量的重复项（qty 相近视为重复）。
    """
    seen = {}
    dupes = []
    for p in pages:
        for row in p["rows"]:
            key = row["room"]
            if key in seen:
                prev = seen[key]
                if abs(prev["qty"] - row["qty"]) < 1e-6 or (
                        prev["qty"] and abs(prev["qty"] - row["qty"]) / prev["qty"] < 0.02):
                    dupes.append({
                        "room": key,
                        "page_a": prev["page"], "qty_a": prev["qty"],
                        "page_b": p["page"], "qty_b": row["qty"],
                        "note": "同名同量，疑似重复计量；需核实是否为不同房间误用同名",
                    })
            else:
                seen[key] = {"page": p["page"], "qty": row["qty"]}
    return dupes


# ----------------------------------------------------------------------------
# 综合审核
# ----------------------------------------------------------------------------
def audit(case):
    """case: {
        "project": "...",
        "contract": {"type":"清工","labor_only":true,"discount":500,...},
        "reported_total": 154310.78,
        "rooms": [...],                       # 走三层级核对
        "prices_in_contract": [60,45,40,...], # 合同已有单价
        "qty_checks": [                       # 总量守恒（对接 cadpdf_takeoff）
           {"item":"墙面碳晶板","reported":850.2,"capacity":495.6,"unit":"m2","basis":"..."}],
        "drawing_rooms": ["男标SPA间1",...],  # 图纸房号清册
        "reported_rooms": ["男标SPA间1",...], # 单据房号
        "void_items": [{"name":"...","amount":3200,"reason":"..."}],
        "unsummed_items": [{"name":"...","amount":11987,"basis":"img18"}],
        "discount": 500,
    }
    """
    findings = []
    reduce_total = 0.0
    pending_total = 0.0

    # --- P1/P2 总量守恒 ---
    # 注意：双面计量只对【面积类】(m2) 成立。线长类(m)比值≈2 只说明
    #   ① 计量口径不同（如踢脚线按双侧计）或 ② 图纸墙长取的是净长而非展开长。
    #   故按单位分流判定，避免把所有比值≈2 的项目都误判成"单面报双面"。
    for q in case.get("qty_checks", []):
        cap = q["capacity"]
        if cap <= 0:
            continue
        ratio = q["reported"] / cap
        unit = q.get("unit", "m2")
        area_like = unit.lower() in ("m2", "㎡", "m²", "平方米")
        if area_like and 1.5 <= ratio <= 2.5:
            findings.append({"point": "P1", "item": q["item"], "level": "★★★",
                             "detail": f"报量 {q['reported']}{unit} ÷ 图纸上限 {cap}{unit} = {ratio:.3f}",
                             "judgement": "面积类，落在双面计量区间，须乙方书面确认单面/双面",
                             "amount": None, "basis": q.get("basis", "")})
        elif area_like and ratio > 2.5:
            findings.append({"point": "P2", "item": q["item"], "level": "★★★",
                             "detail": f"报量 {q['reported']}{unit} ÷ 图纸上限 {cap}{unit} = {ratio:.3f}",
                             "judgement": "面积类，超出可容纳量，落在展开/投影或重复计量区间",
                             "amount": None, "basis": q.get("basis", "")})
        elif not area_like and ratio > 1.3:
            findings.append({"point": "P1", "item": q["item"], "level": "★★",
                             "detail": f"报量 {q['reported']}{unit} ÷ 图纸墙长上限 {cap}{unit} = {ratio:.3f}",
                             "judgement": f"线长类，超出图纸墙长上限 {ratio:.2f} 倍，"
                                          f"须核实是否含图纸未标注的墙垛/二次结构或计量口径不同",
                             "amount": None, "basis": q.get("basis", "")})

    # --- P3 图纸查无 ---
    dr = set(case.get("drawing_rooms", []))
    for room in case.get("reported_rooms", []):
        if dr and room not in dr:
            findings.append({"point": "P3", "item": room, "level": "★★★",
                             "detail": "单据房号在图纸房号清册中查无",
                             "judgement": "未见变更/签证者不予列入", "amount": None,
                             "basis": "图纸房号清册比对"})

    # --- P4 未进小计（反向敞口，只提示不核减）---
    for it in case.get("unsummed_items", []):
        findings.append({"point": "P4", "item": it["name"], "level": "★★",
                         "detail": f"明细已写明但未计入小计：{it['amount']}元",
                         "judgement": "★反向敞口：对甲方有利，须书面定性是否主张，防事后补报",
                         "amount": None, "basis": it.get("basis", "")})

    # --- P5 算术错误 ---
    rows = three_level_check(case.get("rooms", []))
    for r in rows:
        for e in r["item_errors"]:
            if e["diff"] != 0:
                findings.append({"point": "P5", "item": f"{r['room']} - {e['desc']}",
                                 "level": "★★",
                                 "detail": f"{e['qty']}×{e['price']}={e['calc_amount']}，单据写 {e.get('amount')}，差 {e['diff']}",
                                 "judgement": "以重算值为准", "amount": abs(e["diff"]),
                                 "basis": r["page"]})
                if e["diff"] < 0:
                    reduce_total += abs(e["diff"])
        if r["room_diff"] and r["room_diff"] < 0:
            findings.append({"point": "P5", "item": f"{r['room']} 房间小计", "level": "★★",
                             "detail": f"明细相加 {r['calc_room_subtotal']}，单据小计 {r['stated_room_subtotal']}，差 {r['room_diff']}",
                             "judgement": "以明细相加为准", "amount": abs(r["room_diff"]),
                             "basis": r["page"]})
            reduce_total += abs(r["room_diff"])

    # --- P6 重复计量 ---
    for d in crosspage_dupe(case.get("pages", [])):
        findings.append({"point": "P6", "item": d["room"], "level": "★★",
                         "detail": f"{d['page_a']}({d['qty_a']}) 与 {d['page_b']}({d['qty_b']}) 同名同量",
                         "judgement": "疑似重复，只计一次", "amount": None, "basis": ""})

    # --- P7 单价无依据 ---
    known = set(case.get("prices_in_contract", []))
    for p in case.get("used_prices", []):
        if p["price"] not in known:
            findings.append({"point": "P7", "item": p["name"], "level": "★★★",
                             "detail": f"单价 {p['price']}元/{p.get('unit','')} 未见于合同",
                             "judgement": "无书面依据不予认可", "amount": None,
                             "basis": p.get("basis", "合同单价表")})

    # --- P8 合同优惠 ---
    # 兼容两种写法：case["discount"] 或 case["contract"]["discount"]
    disc = case.get("discount") or case.get("contract", {}).get("discount", 0)
    if disc:
        findings.append({"point": "P8", "item": "合同最终优惠", "level": "★",
                         "detail": f"合同约定让价 {disc} 元",
                         "judgement": "应予扣减", "amount": disc, "basis": "合同价款条款"})
        reduce_total += disc

    # --- 汇总 ---
    reported = case.get("reported_total", 0)
    return {
        "project": case.get("project", ""),
        "contract_type": case.get("contract", {}).get("type", ""),
        "labor_only": case.get("contract", {}).get("labor_only", True),
        "reported_total": reported,
        "hard_reduction": round(reduce_total, 2),
        "hard_reduction_rate": round(reduce_total / reported, 4) if reported else 0,
        "pending_items": [f for f in findings if f["amount"] is None],
        "confirmed_items": [f for f in findings if f["amount"] is not None],
        "findings": findings,
        "after_hard_reduction": round(reported - reduce_total, 2),
        "note": "hard_reduction 为『证据铁定、可立即扣减』项；"
                "pending_items 为需乙方答复口径/现场核实后才定金额的项，"
                "**不预先扣减**（守反幻觉红线：无证据的主张不成立，也不得凭空核减）",
    }


# ----------------------------------------------------------------------------
# demo
# ----------------------------------------------------------------------------
def demo():
    """内置自检样例。

    ⚠ 数据分级说明（见 references/data-privacy-policy.md）：
    本样例的案件名已脱敏为案件码 CASE-B，房名已泛化（不含真实房号/门牌）。
    所引数值（送审总额、面积、单价）为**方法论回归用样例值**，用于验证八大核减点
    与三层级钩稽链路的行为，**不得对外引用为任何具体项目的结论**。
    如需对外分享本技能包，请先执行 `python3 scripts/privacy_scan.py --redact`
    对 L1 数值做扰动。
    """
    print("── demo：清工结算审核（脱敏样例 CASE-B，非真实项目数据）──\n")
    case = {
        "project": "SPA会所清工结算〔案件码 CASE-B · 脱敏样例〕",
        "contract": {"type": "清工（只包人工）", "labor_only": True, "discount": 500},
        "reported_total": 154310.78,
        "prices_in_contract": [60, 45, 40, 28, 105, 30, 5, 20, 90, 120, 70],
        "qty_checks": [
            {"item": "墙面碳晶板", "reported": 850.2, "capacity": round(177 * 2.8, 1),
             "unit": "m2", "basis": "图纸墙长上限177m × 层高2.8m"},
            {"item": "地脚线", "reported": 305.6, "capacity": 177,
             "unit": "m", "basis": "图纸墙长上限177m"},
        ],
        "drawing_rooms": ["男标SPA间1", "男标SPA间2", "男标SPA间3", "男标SPA间4", "男标SPA间5",
                          "男VIP豪华SPA间1", "男VIP豪华SPA间2", "男VIP豪华SPA间3",
                          "男VIP豪华SPA间4", "男VIP豪华SPA间5"],
        "reported_rooms": ["男标SPA间1", "男标SPA间6", "男标SPA间7", "男VIP豪华SPA间6"],
        "rooms": [
            {"room": "男标SPA间1", "page": "img10",
             "items": [{"desc": "吊顶", "qty": 12.56, "price": 60, "amount": 753.6},
                       {"desc": "毛坯墙板", "qty": 20.0, "price": 28, "amount": 560.0}],
             "stated_room_subtotal": 1313.6},   # 应为 1313.6 → 无差
            {"room": "女宾SPA间8", "page": "img20",
             "items": [{"desc": "吊顶", "qty": 10.0, "price": 60, "amount": 600.0}],
             "stated_room_subtotal": 680.0},    # 虚增 80
        ],
        "used_prices": [
            {"name": "造型天花", "price": 88, "unit": "m2"},
            {"name": "包柱子", "price": 75, "unit": "m"},
        ],
        "unsummed_items": [{"name": "公区墙贴碳晶板+大堂地脚线", "amount": 11987, "basis": "img18"}],
    }
    r = audit(case)
    print(f"项目        : {r['project']}")
    print(f"合同类型    : {r['contract_type']}（只包人工={r['labor_only']}）")
    print(f"送审总额    : {r['reported_total']:,.0f} 元")
    print(f"可即扣减    : {r['hard_reduction']:,.0f} 元（核减率 {r['hard_reduction_rate']:.2%}）")
    print(f"硬性核减后  : {r['after_hard_reduction']:,.0f} 元\n")
    print(f"{'点':<4}{'项目':<20}{'级':<6}{'金额':>10}  判定")
    print("-" * 92)
    for f in r["findings"]:
        amt = f"{f['amount']:,.0f}" if f["amount"] is not None else "待定"
        print(f"{f['point']:<4}{f['item'][:18]:<20}{f['level']:<6}{amt:>10}  {f['judgement'][:34]}")
    print(f"\n  待定项 {len(r['pending_items'])} 条 ｜ 已定项 {len(r['confirmed_items'])} 条")
    print("\n✅ demo 通过 —— 八大核减点与三层级核对链路可用。")


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="清工/包人工（劳务分包）结算审核器")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("check", help="三层级核对")
    p.add_argument("--json", required=True, help="rooms 数组 JSON")

    p = sub.add_parser("crosspage", help="跨页重复计量检测")
    p.add_argument("--json", required=True)

    p = sub.add_parser("audit", help="综合审核（八大核减点）")
    p.add_argument("--case", required=True, help="完整 case JSON")
    p.add_argument("--out", default=None)

    p = sub.add_parser("points", help="打印八大核减点定义")
    sub.add_parser("demo", help="内置样例自检")

    args = ap.parse_args()
    if args.cmd == "check":
        print(json.dumps(three_level_check(json.load(open(args.json, encoding="utf-8"))),
                         ensure_ascii=False, indent=2))
    elif args.cmd == "crosspage":
        print(json.dumps(crosspage_dupe(json.load(open(args.json, encoding="utf-8"))),
                         ensure_ascii=False, indent=2))
    elif args.cmd == "audit":
        r = audit(json.load(open(args.case, encoding="utf-8")))
        if args.out:
            json.dump(r, open(args.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.cmd == "points":
        for code, name, lv, judge, action in AUDIT_POINTS:
            print(f"[{code}] {name} {lv}\n    判据：{judge}\n    处理：{action}\n")
    elif args.cmd == "demo":
        demo()


if __name__ == "__main__":
    main()
