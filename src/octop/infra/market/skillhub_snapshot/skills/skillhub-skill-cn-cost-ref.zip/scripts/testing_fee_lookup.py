#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
testing_fee_lookup.py — 广东省工程质量安全检测收费指导价（粤建检协〔2015〕8号）结构化检索器

背景：造价审计中频繁需要核定"检测费报得贵不贵"。原文件 87 页无法快速翻查，
本脚本把已解析的 1,843.08 条结构化数据做即时检索/浏览/导出。

⚠️ 效力提醒：源文件《粤建检协〔2015〕8号》已被粤建检协〔2023〕1号(2023-01-06)废止，
现行按发改价格〔2015〕299号实行市场调节价。本数据仅作历史比价基准，不作现行强制依据。

数据源：scripts/data/gd2015_fee.json
用法：
    python3 testing_fee_lookup.py meta                  查看数据概览与效力状态
    python3 testing_fee_lookup.py search <关键词> [--top N] [--cat 2]
    python3 testing_fee_lookup.py get <条目号>          如 get 2.4.1
    python3 testing_fee_lookup.py list <大类号>         列出该大类全部条目
    python3 testing_fee_lookup.py groups <大类号>       列出该大类下二级组及条目数
    python3 testing_fee_lookup.py tags                  业务板块统计
    python3 testing_fee_lookup.py export <关键词> [--md out.md] [--json out.json]
    python3 testing_fee_lookup.py share                 列出所有"共享型"(inherit)条目 —— 防重复计费核对清单
"""
import json, os, sys, re, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data', 'gd2015_fee.json')


# ---------------------------------------------------------------- 数据加载
def load():
    if not os.path.exists(DATA):
        sys.exit(f'[x] 数据文件缺失: {DATA}\n    需先由 "scripts/testing_fee_parser.py" 解析原 PDF 生成')
    with open(DATA, encoding='utf-8') as f:
        return json.load(f)


def rows(d):
    return d['items']


def hit(r, kw):
    """关键词命中：条目名/二级组/大类/备注/编号（大小写不敏感）"""
    k = kw.lower()
    fields = [r.get('item', ''), r.get('grp', ''), r.get('cat', ''),
              r.get('note', '') or '', r.get('item_no', ''), r.get('grp_no', '')]
    return any(k in str(x).lower() for x in fields)


def short(s, n=48):
    s = re.sub(r'\s+', ' ', str(s or '')).strip()
    return s[:n] + ('…' if len(s) > n else '')


def money(r):
    p = r.get('price')
    if not p:
        return '—'
    return short(p, 46)


def to_md(rs, title='查询结果'):
    out = [f'# {title}\n', '| 编号 | 检测项目 | 二级组 | 单位 | 单价(元) | 页码 | 共享 |',
           '|---|---|---|---|---|:---:|:---:|']
    for r in rs:
        out.append(f"| {r.get('item_no','')} | {r.get('item','')} | {r.get('grp','')} | "
                   f"{r.get('unit') or '—'} | {money(r)} | P{r.get('page','')} | "
                   f"{'✔' if r.get('inherit') else ''} |")
    return '\n'.join(out)


# ---------------------------------------------------------------- 命令
def cmd_meta(d, a):
    m = d['meta']
    print('\n=== 数据概览 ===')
    for k in ('title', 'doc_no', 'source_file', 'pages', 'items', 'groups', 'parsed_at'):
        print(f'  {k:<12}: {m.get(k)}')
    print(f"\n  ⚠ 效力状态: {m.get('status')}")
    print(f"  ⚠ 使用限制: {m.get('note')}\n")
    print('=== 大类索引 ===')
    print('| 序号 | 大类 |')
    print('|---|---|')
    for no, nm in d.get('categories', []):
        print(f'| {no} | {nm} |')


def cmd_search(d, a):
    rs = [r for r in rows(d) if hit(r, a.kw)]
    if a.cat:
        rs = [r for r in rs if r.get('cat_no') == a.cat]
    if a.tag:
        rs = [r for r in rs if a.tag in (r.get('tags') or [])]
    rs.sort(key=lambda x: (x.get('page', 0), x.get('item_no', '')))
    print(f'\n命中 {len(rs)} 条（关键词「{a.kw}」）')
    for r in rs[:a.top]:
        print(f"  [{r.get('item_no') or '—':<8}] {short(r.get('item',''),26):<28}"
              f"{r.get('unit') or '—':<6}{money(r):<34}P{r.get('page','')}"
              f"{'  ⇠共享' if r.get('inherit') else ''}")
    if len(rs) > a.top:
        print(f'  ... 还有 {len(rs)-a.top} 条，用 --top 调整')
    if a.md:
        open(a.md, 'w', encoding='utf-8').write(to_md(rs, f'「{a.kw}」检测收费查询'))
        print(f'\n  → Markdown 已导出: {a.md}')
    if a.json:
        json.dump(rs, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(f'  → JSON 已导出: {a.json}')


def cmd_get(d, a):
    rs = [r for r in rows(d) if r.get('item_no') == a.no]
    if not rs:
        sys.exit(f'[x] 未找到条目号 {a.no}（试试 search 命令）')
    for r in rs:
        print(f"\n【{r.get('item_no')}】{r.get('item')}")
        print(f"  大类   : [{r.get('cat_no')}] {r.get('cat')}")
        print(f"  二级组 : [{r.get('grp_no')}] {r.get('grp')}")
        print(f"  计费单位: {r.get('unit') or '—'}")
        print(f"  单价   : {r.get('price') or '—'}")
        if r.get('note'):
            print(f"  备注   : {r.get('note')}")
        print(f"  源页码 : P{r.get('page')}   共享型: {'是（不得单独重复计费）' if r.get('inherit') else '否'}")
        print(f"  板块   : {', '.join(r.get('tags') or []) or '—'}")


def cmd_list(d, a):
    rs = [r for r in rows(d) if r.get('cat_no') == a.cat]
    rs.sort(key=lambda x: (x.get('page', 0), x.get('grp_no', '')))
    print(f'\n第 {a.cat} 大类共 {len(rs)} 条：')
    cur = None
    for r in rs[:a.top]:
        if r.get('grp') != cur:
            cur = r.get('grp')
            print(f"\n── [{r.get('grp_no')}] {cur} ──")
        print(f"   {r.get('item_no') or '—':<9}{short(r.get('item',''),24):<26}"
              f"{r.get('unit') or '—':<6}{money(r)}")


def cmd_groups(d, a):
    seen = {}
    for r in rows(d):
        if r.get('cat_no') != a.cat:
            continue
        k = (r.get('grp_no'), r.get('grp'))
        seen.setdefault(k, [0, r.get('page')])
        seen[k][0] += 1
    print(f'\n第 {a.cat} 大类下二级组 {len(seen)} 个：')
    for (no, nm), (cnt, pg) in sorted(seen.items(), key=lambda x: natural(x[0][0])):
        print(f'  [{no:<6}] {nm:<28} {cnt:>4}项  P{pg}')


def cmd_tags(d, a):
    tc = {}
    for r in rows(d):
        for t in (r.get('tags') or ['(未标记)']):
            tc[t] = tc.get(t, 0) + 1
    print('\n=== 业务板块统计 ===')
    for k, v in sorted(tc.items(), key=lambda x: -x[1]):
        print(f'  {k:<10} {v:>5} 项')


def cmd_share(d, a):
    rs = [r for r in rows(d) if r.get('inherit')]
    print(f'\n=== 共享型（inherit）条目 {len(rs)} 条 —— 计费时不得重复 ===')
    for r in rs[:a.top]:
        print(f"  [{r.get('grp_no')}]{short(r.get('grp',''),16):<18}"
              f"{short(r.get('item',''),20):<22}{money(r)}")
    if len(rs) > a.top:
        print(f'  ... 共 {len(rs)} 条')


def cmd_export(d, a):
    rs = [r for r in rows(d) if hit(r, a.kw)]
    rs.sort(key=lambda x: (x.get('page', 0), x.get('item_no', '')))
    if a.json:
        json.dump(rs, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(f'  → JSON 已导出 {len(rs)} 条: {a.json}')
    md = a.md or (os.path.splitext(a.json)[0] + '.md' if a.json else 'export.md')
    open(md, 'w', encoding='utf-8').write(to_md(rs, f'检测收费查询「{a.kw}」（{len(rs)}条）'))
    print(f'  → Markdown 已导出 {len(rs)} 条: {md}')


def natural(s):
    try:
        return [int(x) if x.isdigit() else x for x in re.split(r'(\d+)', str(s))]
    except Exception:
        return [s]


# ---------------------------------------------------------------- CLI
def main():
    p = argparse.ArgumentParser(description='广东检测收费指导价(粤建检协2015-8)检索器')
    sub = p.add_subparsers(dest='cmd')

    sub.add_parser('meta', help='数据概览与效力状态')

    s = sub.add_parser('search', help='关键词检索')
    s.add_argument('kw'); s.add_argument('--top', type=int, default=25)
    s.add_argument('--cat', default=None, help='限定大类号 如 2')
    s.add_argument('--tag', default=None, help='限定板块 如 防水')
    s.add_argument('--md', default=None); s.add_argument('--json', default=None)

    g = sub.add_parser('get', help='按条目号查询'); g.add_argument('no')
    l = sub.add_parser('list', help='列出大类条目')
    l.add_argument('cat'); l.add_argument('--top', type=int, default=200)
    gr = sub.add_parser('groups', help='列出大类下二级组'); gr.add_argument('cat')
    sub.add_parser('tags', help='业务板块统计')
    sh = sub.add_parser('share', help='共享型条目清单'); sh.add_argument('--top', type=int, default=40)
    e = sub.add_parser('export', help='按关键词导出')
    e.add_argument('kw'); e.add_argument('--md', default=None); e.add_argument('--json', default=None)

    a = p.parse_args()
    if not a.cmd:
        p.print_help(); return
    d = load()
    {'meta': cmd_meta, 'search': cmd_search, 'get': cmd_get, 'list': cmd_list,
     'groups': cmd_groups, 'tags': cmd_tags, 'share': cmd_share,
     'export': cmd_export}[a.cmd](d, a)


if __name__ == '__main__':
    main()
