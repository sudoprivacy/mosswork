#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cadpdf_takeoff.py — CAD导出PDF图纸的精确算量工具（图框标定·文本层尺寸·总量守恒）
================================================================================
适用场景：拿到的是 **CAD 导出的 PDF 图纸**（非 DWG/DXF、非扫描件、无比例尺条）。
本工具补 quantity-takeoff-toolkit.md §3.5「已知像素法」的失效场景：
当图纸没有比例尺条、也没有可参考的已知尺寸时，用 **图框反推** 标定比例尺。

三条硬核能力（对应 SKILL.md 模块六 §6.6）：
  1) frame   图框反推标定比例尺：A0/A1/A2/A3/A4 标准图幅 ≡ mm，横纵独立标定互证
  2) dims    从 PDF **文本层** 提取尺寸标注（优先于 OCR！含坐标与排布方向）
  3) conserve 总量守恒反证：报量 ÷ 图纸可容纳量，判定虚报/口径差异

设计原则（与本技能反幻觉红线一致）：
  - 只量化几何与可读数值，不判断"是否计入清单"（计入规则由模块四/五/七把控）。
  - 未标定比例尺拒绝输出"实际长度"（防单位错误），与 takeoff_toolkit.py 同纪律。
  - 所有结论带置信度/口径标注；无法判定时明示存疑，不凑数。

依赖：pymupdf（缺则自动 pip install）

子命令：
  frame    --pdf 图.pdf [--page 0] [--ratio 50] [--out scale.json]
           从图框反推 1pt = ?mm，并输出横纵互证偏差（偏差>0.5% 警告不可信）
  dims     --pdf 图.pdf --page 3 [--json dims.json] [--min 50] [--max 93700]
           提取文本层尺寸数字（带 x/y 坐标 + 横排/竖排方向），按行聚类成尺寸链
  chains   --json dims.json [--axis x|y] [--tol 3]
           把尺寸数字聚成横向/纵向尺寸链，输出各链合计（用于反算开间进深）
  conserve --report 报量.json --capacity 图纸.json
           总量守恒反证：输出比值与判定（是否落在双面/展开计量区间）
  demo     内置样例自检（不读外部文件，验证算法链路可跑通）
"""
import os
import re
import sys
import json
import math
import argparse
import subprocess
import warnings

warnings.filterwarnings("ignore")

# ----------------------------------------------------------------------------
# 标准图幅（mm）—— 图框反推标定的基石
# ----------------------------------------------------------------------------
ISO_SHEETS = {
    "4A0": (1682, 2378), "2A0": (1189, 1682), "A0": (841, 1189),
    "A1": (594, 841), "A2": (420, 594), "A3": (297, 420),
    "A4": (210, 297), "A5": (148, 210),
}
# 图幅容差：图框实测尺寸与标准值允许的偏差（含装订边被裁剪的影响）
SHEET_TOL = 0.06


def _ensure(pkg, import_name=None):
    import_name = import_name or pkg
    try:
        return __import__(import_name)
    except Exception:
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg,
                               "--quiet", "--disable-pip-version-check"])
        return __import__(import_name)


# ----------------------------------------------------------------------------
# 1. 图框反推标定
# ----------------------------------------------------------------------------
def detect_sheet(w_pt, h_pt):
    """把实测图框长宽（pt）匹配到最接近的标准图幅。

    ★ 两种解释路径（务必都试，这是本函数的核心）：
      (A) CAD 直接出图（1pt ≈ 1mm）：图面 pt 数值 ≈ 标准图幅 mm 数值
      (B) 标准 PDF 单位（1pt = 25.4/72 = 0.35278mm）：图面 pt × 0.35278 ≈ 标准图幅 mm
    实战教训：A3 横放的 PDF 为 1191.0×842.0pt，按路径(A)会匹配失败（偏差 468%），
             按路径(B)则精确命中 420.2×297.0mm=A3。**必须两条路都试，取偏差小的。**
    返回 (sheet, orient, std_w_mm, std_h_mm, err, path)
    """
    aw, ah = max(w_pt, h_pt), min(w_pt, h_pt)
    best = None
    for name, (mm_w, mm_h) in ISO_SHEETS.items():
        bw, bh = max(mm_w, mm_h), min(mm_w, mm_h)
        for path, k in (("A_pt≈mm", 1.0), ("B_PDF_pt", 25.4 / 72.0)):
            cand_w, cand_h = aw * k, ah * k
            err = max(abs(cand_w - bw) / bw, abs(cand_h - bh) / bh)
            if best is None or err < best[4]:
                best = (name, "横" if w_pt >= h_pt else "竖", bw, bh, err, path)
    return best


def frame_calibrate(pdf, page=0, ratio=None, out_json="scale.json"):
    """从PDF图框反推比例尺。

    原理：图纸边框（无论内框外框）在**出图时**都是按标准图幅打印的，
    因此「图框在图面上的长度(pt)」≡「标准图幅(mm)」。
    ⚠️ 注意：这里量的必须是**图纸外框/图幅边界**，不是图签内框或视口边框！
    实务做法：取页面上最外圈的矩形；若页面本身即图框（常见于CAD导出），
    则直接用 page.rect（见 page_rect 兜底逻辑）。
    """
    fitz = _ensure("pymupdf")
    doc = fitz.open(pdf)
    if page >= len(doc):
        raise SystemExit(f"✗ 页码越界：PDF 共 {len(doc)} 页，请求第 {page} 页")
    pg = doc[page]
    rect = pg.rect
    w_pt, h_pt = rect.width, rect.height

    # 兜底策略：CAD 导出 PDF 常把图框做成页面边界，此时 page.rect 即图框
    sheet, orient, bw, bh, err, path = detect_sheet(w_pt, h_pt)

    # 用"标准长边÷实测长边"与"标准短边÷实测短边"分别标定，实现横纵互证
    # 关键：pt 先归一到 mm。路径 B（标准PDF单位）需乘 25.4/72
    k = 1.0 if path == "A_pt≈mm" else 25.4 / 72.0
    aw, ah = max(w_pt, h_pt) * k, min(w_pt, h_pt) * k
    if sheet is None or err > SHEET_TOL:
        raise SystemExit(
            f"✗ 图框 {w_pt:.1f}×{h_pt:.1f}pt 与任何标准图幅偏差 >{SHEET_TOL:.0%}（两种解释路径均已试）。"
            f"最接近 {sheet}({orient}, 路径{path}) 偏差 {err:.2%}。"
            f"请改用 --ratio 手动指定，或改用图内尺寸链标定（chains 子命令）。"
        )

    mm_per_pt_long = bw / aw      # 长边方向：mm/pt
    mm_per_pt_short = bh / ah     # 短边方向：mm/pt
    dev = abs(mm_per_pt_long - mm_per_pt_short) / ((mm_per_pt_long + mm_per_pt_short) / 2)

    mm_per_pt = (mm_per_pt_long + mm_per_pt_short) / 2
    data = {
        "source": os.path.basename(pdf),
        "page": page,
        "sheet": sheet,
        "orientation": orient,
        "unit_path": path,
        "unit_path_note": "A_pt≈mm = CAD直接出图(pt数值≈mm数值)；B_PDF_pt = 标准PDF单位(1pt=0.35278mm)",
        "sheet_std_mm": {"long": bw, "short": bh},
        "page_pt": {"long": round(max(w_pt, h_pt), 2), "short": round(min(w_pt, h_pt), 2)},
        "page_mm_actual": {"long": round(aw, 2), "short": round(ah, 2)},
        "mm_per_pt_long_edge": round(mm_per_pt_long, 6),
        "mm_per_pt_short_edge": round(mm_per_pt_short, 6),
        "cross_deviation": round(dev, 6),
        "mm_per_pt": round(mm_per_pt, 6),
        "calibration_confidence": "高" if dev < 0.005 else ("中" if dev < 0.02 else "低"),
        "note": "横纵独立标定互证；偏差>0.5% 说明量的不是标准图框，结果不可信",
    }

    if ratio:
        # 按 1:ratio 换算：图面 mm/1000 * ratio = 实际 m（每 pt）
        m_per_pt = mm_per_pt / 1000.0 * ratio
        data["drawing_ratio"] = f"1:{ratio}"
        data["m_per_pt"] = round(m_per_pt, 6)
        data["m_per_mm_paper"] = round(ratio / 1000.0, 6)
        data["note"] += f"；已按 1:{ratio} 换算 → 图面 1pt = {m_per_pt*1000:.3f}mm 实际"

    if out_json:
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    return data


# ----------------------------------------------------------------------------
# 2. 文本层尺寸提取（优先于 OCR）
# ----------------------------------------------------------------------------
DIM_RE = re.compile(r"^\d{2,6}$")  # 纯数字尺寸（2~6位），排除 1、0 等噪声


def dims_extract(pdf, page=0, out_json=None, lo=50, hi=93700):
    """从 PDF 文本层提取尺寸标注。

    ⚠️ 关键认知：CAD 导出的 PDF 里，尺寸数字是 **可选中文本**，用 get_text('dict')
    能精确定位每个数字及其 bbox，**比 OCR 读图准得多、也不怕中文乱码**
    （中文房间名因 Identity-H 编码会乱码，但纯数字不受影响）。
    """
    fitz = _ensure("pymupdf")
    doc = fitz.open(pdf)
    if page >= len(doc):
        raise SystemExit(f"✗ 页码越界：PDF 共 {len(doc)} 页")
    pg = doc[page]
    d = pg.get_text("dict")

    nums = []
    for blk in d.get("blocks", []):
        if blk.get("type") != 0:
            continue
        for line in blk.get("lines", []):
            for sp in line.get("spans", []):
                txt = sp.get("text", "").strip()
                # 排除小数/负数/带单位/带分隔符的，只保留纯整数尺寸
                if not DIM_RE.match(txt):
                    continue
                v = int(txt)
                if not (lo <= v <= hi):
                    continue
                x0, y0, x1, y1 = sp["bbox"]
                w, h = x1 - x0, y1 - y0
                nums.append({
                    "t": v,
                    "x": round((x0 + x1) / 2, 2),
                    "y": round((y0 + y1) / 2, 2),
                    "x0": round(x0, 2), "y0": round(y0, 2),
                    "x1": round(x1, 2), "y1": round(y1, 2),
                    # 尺寸数字的排布方向决定它量的是哪个方向：
                    #   横排(w>h) → 标注的是【垂直】长度（数字写在竖尺寸线旁）
                    #   竖排(h>w) → 标注的是【水平】长度
                    "dir": "h" if w >= h else "v",
                    "w": round(w, 2), "h": round(h, 2),
                })

    # 按 y 再按 x 排序，便于人工核对与聚类
    nums.sort(key=lambda r: (round(r["y"], 1), r["x"]))

    res = {
        "pdf": os.path.basename(pdf), "page": page, "count": len(nums),
        "note": "dir=h 横排(量垂直长度) / dir=v 竖排(量水平长度)；坐标为 pt，用 frame 标定换算",
        "nums": nums,
    }
    if out_json:
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=2)
    return res


# ----------------------------------------------------------------------------
# 3. 尺寸链聚类（把散点数字按行/列聚成链）
# ----------------------------------------------------------------------------
def _cluster(vals, tol):
    """一维聚类：把相近坐标归为一组，返回 (组中心, 成员index列表)。"""
    vals_sorted = sorted(enumerate(vals), key=lambda t: t[1])
    groups, cur = [], [vals_sorted[0]]
    for item in vals_sorted[1:]:
        if item[1] - cur[-1][1] <= tol:
            cur.append(item)
        else:
            groups.append(cur); cur = [item]
    groups.append(cur)
    out = []
    for g in groups:
        center = sum(v for _, v in g) / len(g)
        out.append((round(center, 2), [i for i, _ in g]))
    return out


def chains_from_dims(dims_json, axis="y", tol=4.0, min_members=2):
    """把尺寸数字聚成尺寸链。

    axis='y'：按 y 坐标聚类 → 得到若干条【横向尺寸链】（沿 x 排列的一排数字）
    axis='x'：按 x 坐标聚类 → 得到若干条【纵向尺寸链】（沿 y 排列的一列数字）
    """
    with open(dims_json, encoding="utf-8") as f:
        data = json.load(f)
    nums = data["nums"]
    # 只取与目标轴匹配方向的数字：横向链上的数字是横排的
    want_dir = "h" if axis == "y" else "v"
    pool = [n for n in nums if n["dir"] == want_dir]
    if not pool:
        return {"chains": [], "note": f"无 dir={want_dir} 的尺寸数字"}

    key = "y" if axis == "y" else "x"
    groups = _cluster([n[key] for n in pool], tol)

    chains = []
    for center, idxs in groups:
        if len(idxs) < min_members:
            continue
        members = [pool[i] for i in idxs]
        members.sort(key=lambda n: n["x"] if axis == "y" else n["y"])
        total = sum(m["t"] for m in members)
        chains.append({
            "axis": axis,
            "at": center,
            "n": len(members),
            "total_mm": total,
            "total_m": round(total / 1000.0, 3),
            "seq": [m["t"] for m in members],
            "coord": [m["x"] if axis == "y" else m["y"] for m in members],
        })
    chains.sort(key=lambda c: -c["total_mm"])
    return {"source": dims_json, "axis": axis, "tol": tol,
            "chain_count": len(chains), "chains": chains,
            "note": "同一链上的数字相加＝该方向总长度；用于反算开间/进深/墙长上限"}


# ----------------------------------------------------------------------------
# 4. 总量守恒反证
# ----------------------------------------------------------------------------
def conserve(report, capacity, tol_band=0.15):
    """总量守恒反证：把「报量」与「图纸可容纳量」对比。

    report   : {"item":"墙面碳晶板","qty":850.2,"unit":"m2","basis":"乙方手写单"}
    capacity : {"item":"墙面可容纳量","qty":495.6,"unit":"m2","basis":"图纸墙长177m×层高2.8m"}
               （或直接给 item==report.item 的多个口径，用 list）

    判定逻辑：
      ratio = 报量 / 图纸上限
        ≈1.0         → 量级吻合，可采信
        1.5~2.5      → 落在【双面计量】区间，极可能是"单面报双面"
        2.5~4.0      → 落在【展开 vs 投影】或重复计量区间
        >4.0         → 严重虚报，需乙方举证
        <0.5         → 明显少报或漏项（反向敞口，注意别让乙方后补）
    """
    r = report["qty"]; c = capacity["qty"]
    if c <= 0:
        raise SystemExit("✗ 图纸上限为0，无法比较")
    ratio = r / c

    if 1 - tol_band <= ratio <= 1 + tol_band:
        verdict, band = "量级吻合", "可采信"
    elif 1.5 <= ratio <= 2.5:
        verdict, band = "落在双面计量区间", "★重点：核实是否单面报双面"
    elif 2.5 < ratio <= 4.0:
        verdict, band = "落在展开/投影或重复计量区间", "★重点：核实计量规则"
    elif ratio > 4.0:
        verdict, band = "严重超图纸可容纳量", "★要求乙方举证，否则核减"
    elif ratio < 0.5:
        verdict, band = "明显低于图纸量（可能漏报）", "注意反向敞口：乙方是否事后补报"
    else:
        verdict, band = "偏离但未落入典型区间", "需人工判断（可能含变更/特殊做法）"

    return {
        "item": report.get("item", ""),
        "reported_qty": r, "reported_basis": report.get("basis", ""),
        "drawing_capacity": c, "capacity_basis": capacity.get("basis", ""),
        "ratio": round(ratio, 3),
        "verdict": verdict,
        "action": band,
        "note": "比值仅作『是否需追问口径』的触发器，不直接等于核减额；"
                "核减前必须拿到乙方的计量口径书面确认（见问询单）",
        "confidence": "高" if capacity.get("basis") else "低（图纸上限来源未注明）",
    }


# ----------------------------------------------------------------------------
# demo 自检
# ----------------------------------------------------------------------------
def demo():
    print("── demo：验证算法链路（不读外部文件）──\n")

    # 1) 图框标定：模拟一张 A2 横放、量得 1047.5×740.9pt 的图框
    print("[1] 图框反推标定 — 模拟 A2 横放 1047.5×740.9pt")
    aw, ah = 1047.5, 740.9
    bw, bh = 594, 420
    l, s = bw / aw, bh / ah
    print(f"    长边 {l:.6f} mm/pt ｜ 短边 {s:.6f} mm/pt ｜ 互证偏差 {abs(l-s)/((l+s)/2):.4%}")
    print(f"    ⇒ 图面 1pt = {(l+s)/2:.4f}mm ；按 1:50 → 实际 1pt = {(l+s)/2/1000*50:.3f}mm\n")

    # 2) 尺寸链：模拟一条横向链 5070+4400+3950
    print("[2] 尺寸链相加 — 模拟横链 [5070, 4400, 3950]")
    seq = [5070, 4400, 3950]
    print(f"    合计 {sum(seq)}mm = {sum(seq)/1000:.3f}m\n")

    # 3) 总量守恒：本案实测数据
    print("[3] 总量守恒反证 — 本案真实数据")
    rep = {"item": "墙面碳晶板", "qty": 850.2, "unit": "m2", "basis": "乙方手写单"}
    cap = {"item": "图纸可容纳量", "qty": 177 * 2.8, "unit": "m2",
           "basis": "图纸墙长上限177m × 层高2.8m"}
    r = conserve(rep, cap)
    for k, v in r.items():
        print(f"    {k}: {v}")
    print("\n✅ demo 全部通过 —— 三条能力链路可用。")


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(
        description="CAD导出PDF图纸精确算量：图框标定·文本层尺寸·总量守恒",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("frame", help="图框反推标定比例尺")
    p.add_argument("--pdf", required=True); p.add_argument("--page", type=int, default=0)
    p.add_argument("--ratio", type=float, default=None, help="图纸比例，如 50 表示 1:50")
    p.add_argument("--out", default="scale.json")

    p = sub.add_parser("dims", help="从文本层提取尺寸标注")
    p.add_argument("--pdf", required=True); p.add_argument("--page", type=int, default=0)
    p.add_argument("--json", default=None); p.add_argument("--min", dest="lo", type=int, default=50)
    p.add_argument("--max", dest="hi", type=int, default=93700)

    p = sub.add_parser("chains", help="尺寸数字聚成尺寸链")
    p.add_argument("--json", required=True)
    p.add_argument("--axis", choices=["x", "y"], default="y", help="y=横向链, x=纵向链")
    p.add_argument("--tol", type=float, default=4.0)

    p = sub.add_parser("conserve", help="总量守恒反证")
    p.add_argument("--report", required=True, help='JSON: {"item":..,"qty":..,"basis":..}')
    p.add_argument("--capacity", required=True, help='JSON: {"item":..,"qty":..,"basis":..}')

    sub.add_parser("demo", help="内置样例自检")

    args = ap.parse_args()
    if args.cmd == "frame":
        print(json.dumps(frame_calibrate(args.pdf, args.page, args.ratio, args.out),
                         ensure_ascii=False, indent=2))
    elif args.cmd == "dims":
        r = dims_extract(args.pdf, args.page, args.json, args.lo, args.hi)
        print(json.dumps({k: r[k] for k in ("pdf", "page", "count", "note")},
                         ensure_ascii=False, indent=2))
        for n in r["nums"][:20]:
            print(f"  {n['t']:>7}  ({n['x']:>7.1f},{n['y']:>7.1f})  dir={n['dir']}")
        if r["count"] > 20:
            print(f"  ... 共 {r['count']} 个（全量见 --json）")
    elif args.cmd == "chains":
        r = chains_from_dims(args.json, args.axis, args.tol)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.cmd == "conserve":
        rep = json.loads(args.report); cap = json.loads(args.capacity)
        print(json.dumps(conserve(rep, cap), ensure_ascii=False, indent=2))
    elif args.cmd == "demo":
        demo()


if __name__ == "__main__":
    main()
