#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bid_clean_check.py —— 智能清标与围串标线索扫描器（造价稽核官 CostAuditor）

定位（合规红线，务必遵守）：
    依据《发改法规〔2026〕195 号》第 17 条，围串标识别坚持**辅助性定位**，
    本脚本输出的全部条目均为「**线索 / 疑点**」，**不构成定性结论，不替代法定责任**，
    不得直接作为否决投标或行政处罚的依据，须由评标委员会 / 行政监督部门复核确认。

判据来源（真实可核，非臆造）：
    ① 《发改法规〔2026〕195 号》17 条：对投标文件、工程量清单、报价清单深度扫描；
       商务标关键报价特征比对；技术方案语义相似性分析；"主体+行为"综合预警。
    ② 商丘市公共资源交易平台《关于进一步加强围串标识别应用的通知》（2026-07-24 起施行）
       投标文件雷同情形新增 3 项：报价呈等差数列、报价差额呈等差数列、规律性百分比。
    ③ 威海市审计局《人工智能技术在招投标审计中的实践路径初探》：
       多家企业固定比例报价、报价接近控制价却从未中标（陪标特征）、
       首位数频率分布异常（单价首数字"5"频率 15% vs 标准值约 8%，据此查出结算换价）。
    ④ 不平衡报价阈值 ±15% 与本技能 bid_selfcheck（cost_adjuster.py）口径保持一致。

依赖：纯标准库（csv/json/math/statistics），无第三方依赖，缺库不会崩溃。

用法：
    python3 bid_clean_check.py check      --boq boq.csv --bids bids.csv [--base control|mean] [--md]
    python3 bid_clean_check.py unbalance  --boq boq.csv --bids bids.csv [--md]
    python3 bid_clean_check.py collusion  --boq boq.csv --bids bids.csv [--md]
    python3 bid_clean_check.py report     --boq boq.csv --bids bids.csv [--md] [--out f.md]

输入格式（CSV，UTF-8，首行为表头）：
    boq.csv  列：code,name,unit,qty,control_price
    bids.csv 列：bidder,code,unit_price
"""

import argparse
import csv
import json
import math
import os
import statistics
import sys
from collections import defaultdict

# ---------------------------------------------------------------- 阈值（可覆盖）
T = {
    "deviation_high": 15.0,      # 偏差 > +15% → 虚高预警（★缺省值，非规定值，见下）
    "deviation_low": -15.0,      # 偏差 < -15% → 压低预警
    # ⚠⚠ 真实招标文件会**自行约定**不平衡报价认定阈值，实测广东 2026-07 某施工招标
    #   公告约定为 **±20%**（原文：「若投标清单项目综合单价相较于招标控制价
    #   《分部分项工程和单价措施项目清单与计价表》对应子目综合单价偏差超出±20%，
    #   该清单项目认定为不平衡报价项目」，并给出完整修正公式与修正后总额校核规则）。
    #   15% 实为**工程量偏差**的常见约定（超 15% 部分下调/上调 3%）被移植过来，
    #   不是不平衡报价的规定值。故此处改为可用 --dev-high/--dev-low 覆盖，
    #   并在每条线索上提示「实际以招标文件约定为准」。
    #   详见 references/unbalanced-bid-correction.md。
    "near_identical_rel": 0.02,  # 两家单价相对差 < 2% → 视作"同向微调/差异极小"
    "near_identical_cover": 0.60,# 上述情形覆盖 ≥60% 清单项 → 报价趋同线索
    "corr_threshold": 0.98,      # 归一化相关 ≥0.98 → 报价模式相似（弱线索，非定性）
    "corr_strong": 0.999,        # ≥0.999 才算"近乎完全同步"，可与 (b) 并用升级为强线索
    "arith_tol": 1e-6,           # 等差数列判定容差（相对）
    "arith_cover": 0.80,         # 等差特征覆盖比例阈值
    "ratio_spread_rel": 0.005,   # 相邻报价比值的相对离散度 <0.5% → 视作"固定比例"
    "ratio_min_spacing": 0.003,  # 相邻报价间距须 >0.3%，否则属"正常竞争价差"而非规律性
    "benford_mad_note": 0.012,   # MAD >0.012 提示关注；>0.015 显著偏离
    "control_near": 0.02,        # 报价与控制价相差 ≤2% → "贴近控制价"
    "min_items_for_benford": 30, # 样本 <30 条不做本福特检验（统计无意义）
    "min_items_for_corr": 10,    # 样本 <10 条不做相关性判定（小样本 r 极不稳定，易伪阳）
}

DISCLAIMER = ("本结果为**辅助性线索**，依据发改法规〔2026〕195 号坚持辅助性定位，"
              "不构成定性结论、不替代法定责任；须经评标委员会或行政监督部门复核确认后使用。")


# ---------------------------------------------------------------- 数据装载
def _read_csv(path, required):
    if not os.path.isfile(path):
        raise FileNotFoundError(f"找不到输入文件: {path}")
    rows = []
    with open(path, encoding="utf-8-sig") as f:
        r = csv.DictReader(f)
        missing = [c for c in required if c not in (r.fieldnames or [])]
        if missing:
            raise ValueError(f"{path} 缺少必需列 {missing}；实际列={r.fieldnames}")
        for row in r:
            rows.append({k: (v.strip() if isinstance(v, str) else v) for k, v in row.items()})
    return rows


def load_boq(path):
    """招标清单：code,name,unit,qty,control_price"""
    items = {}
    for row in _read_csv(path, ["code", "name", "unit", "qty", "control_price"]):
        code = row["code"]
        if not code:
            continue
        try:
            qty = float(row["qty"])
            ctrl = float(row["control_price"])
        except (TypeError, ValueError):
            continue
        items[code] = {"code": code, "name": row["name"], "unit": row["unit"],
                       "qty": qty, "control_price": ctrl}
    return items


def load_bids(path):
    """投标报价：bidder,code,unit_price → {bidder: {code: price}}"""
    bids = defaultdict(dict)
    for row in _read_csv(path, ["bidder", "code", "unit_price"]):
        b, code = row["bidder"], row["code"]
        if not b or not code:
            continue
        try:
            bids[b][code] = float(row["unit_price"])
        except (TypeError, ValueError):
            continue
    return dict(bids)


# ---------------------------------------------------------------- 通用量
def _rel(a, b):
    """相对差；基准为 0 时退化为绝对差。"""
    if b == 0:
        return abs(a - b)
    return (a - b) / b


def totals(boq, bids):
    """各投标人总报价（按招标工程量汇总）。"""
    out = {}
    for b, prices in bids.items():
        s = 0.0
        for code, it in boq.items():
            s += prices.get(code, 0.0) * it["qty"]
        out[b] = s
    return out


def deviation_rows(boq, bids, base="control"):
    """逐投标人、逐清单项的偏差率（%）。base=control 用控制价，mean 用各家均价。"""
    mean_price = {}
    if base == "mean":
        for code in boq:
            vals = [p.get(code) for p in bids.values() if p.get(code) is not None]
            if vals:
                mean_price[code] = statistics.fmean(vals)
    rows = []
    for b, prices in bids.items():
        for code, it in boq.items():
            up = prices.get(code)
            if up is None:
                continue
            if base == "control":
                ref = it["control_price"]
            else:
                ref = mean_price.get(code)
            if ref is None:
                continue
            dev = _rel(up, ref) * 100.0
            rows.append({"bidder": b, "code": code, "name": it["name"],
                         "unit": it["unit"], "qty": it["qty"],
                         "unit_price": up, "ref_price": ref, "deviation_pct": dev,
                         "amount": up * it["qty"]})
    return rows


# ---------------------------------------------------------------- ① 符合性检查
def check_compliance(boq, bids):
    findings = []
    codes = set(boq)
    for b, prices in bids.items():
        miss = sorted(codes - set(prices))          # 漏报项
        extra = sorted(set(prices) - codes)         # 多报项（不在招标清单）
        if miss:
            findings.append({"type": "清单漏项", "bidder": b, "severity": "高",
                             "count": len(miss), "detail": miss[:10],
                             "note": "投标报价未填报招标清单中的项目，属重大偏差，通常按否决投标处理（须复核招标文件规定）"})
        if extra:
            findings.append({"type": "清单多项", "bidder": b, "severity": "中",
                             "count": len(extra), "detail": extra[:10],
                             "note": "出现招标清单外项目，须核对是否为变更/补充项或录入错误"})
        # 零报价 / 负报价
        zero = sorted([c for c, v in prices.items() if c in codes and v <= 0])
        if zero:
            findings.append({"type": "零/负单价", "bidder": b, "severity": "高",
                             "count": len(zero), "detail": zero[:10],
                             "note": "单价为 0 或负，可能是漏报、赠予式报价或数据错误，须复核"})
    return findings


# ---------------------------------------------------------------- ② 偏差矩阵
def check_deviation(boq, bids, base="control"):
    rows = deviation_rows(boq, bids, base)
    findings = []
    by_bidder = defaultdict(list)
    for r in rows:
        by_bidder[r["bidder"]].append(r)
    for b, rs in by_bidder.items():
        high = [r for r in rs if r["deviation_pct"] > T["deviation_high"]]
        low = [r for r in rs if r["deviation_pct"] < T["deviation_low"]]
        if high:
            findings.append({"type": "单价虚高", "bidder": b, "severity": "中",
                             "count": len(high),
                             "top": sorted(high, key=lambda x: -x["deviation_pct"])[:5],
                             "note": f"偏差 > +{T['deviation_high']}%（缺省阈值，**实际以招标文件"
                                     f"「不平衡报价」条款约定为准**，可用 --dev-high 覆盖），"
                                     f"属不平衡报价的抬高侧"})
        if low:
            findings.append({"type": "单价压低", "bidder": b, "severity": "中",
                             "count": len(low),
                             "top": sorted(low, key=lambda x: x["deviation_pct"])[:5],
                             "note": f"偏差 < {T['deviation_low']}%（缺省阈值，**实际以招标文件"
                                     f"约定为准**），属不平衡报价的压低侧，"
                                     "若对应工程量后续调增将损害发包人利益"})
    return findings, rows


# ---------------------------------------------------------------- ③ 不平衡报价
def check_unbalance(boq, bids, base="control"):
    _, rows = check_deviation(boq, bids, base)
    findings = []
    by_bidder = defaultdict(list)
    for r in rows:
        by_bidder[r["bidder"]].append(r)
    for b, rs in by_bidder.items():
        total_amt = sum(r["amount"] for r in rs) or 1.0
        # 抬高侧：偏差 >+15% 且该项金额占比较大 → 若工程量调增则发包人受损
        raise_items = [r for r in rs if r["deviation_pct"] > T["deviation_high"]]
        press_items = [r for r in rs if r["deviation_pct"] < T["deviation_low"]]
        if raise_items or press_items:
            exposed = sum(r["amount"] for r in raise_items)
            findings.append({
                "type": "不平衡报价", "bidder": b, "severity": "中",
                "raise_count": len(raise_items), "press_count": len(press_items),
                "exposed_amount": round(exposed, 2),
                "exposed_ratio_pct": round(exposed / total_amt * 100.0, 2),
                "worst": sorted(raise_items, key=lambda x: -(x["deviation_pct"] * x["amount"]))[:3],
                "note": "抬高项金额占比越高、且该类工程量在履约中可能调增，则发包人风险越大；"
                        "处置口径见 GB/T 50500-2024 变更单价三阶梯（有约定从约定→类似套用→重新组价）",
            })
    return findings


# ---------------------------------------------------------------- ④ 围串标线索
def _is_arith(seq, tol=T["arith_tol"]):
    """判断升序序列是否近似等差数列（公差相对一致）。"""
    if len(seq) < 3:
        return False, None
    diffs = [seq[i + 1] - seq[i] for i in range(len(seq) - 1)]
    if all(abs(d) < 1e-9 for d in diffs):
        return True, 0.0
    m = statistics.fmean(diffs)
    if abs(m) < 1e-9:
        return False, None
    return all(abs(d - m) <= tol * abs(m) + 1e-9 for d in diffs), m


def benford_check(prices):
    """首位数频率分布与本福特定律的偏离（MAD）。样本 <30 条不做（统计无意义）。"""
    digits = []
    for p in prices:
        if p is None or p <= 0:
            continue
        s = f"{abs(p):.10f}".lstrip("0").replace(".", "")
        if s and s[0] != "0":
            digits.append(int(s[0]))
    n = len(digits)
    if n < T["min_items_for_benford"]:
        return None
    obs = {d: digits.count(d) / n for d in range(1, 10)}
    exp = {d: math.log10(1 + 1 / d) for d in range(1, 10)}
    mad = statistics.fmean(abs(obs[d] - exp[d]) for d in range(1, 10))
    worst = max(range(1, 10), key=lambda d: abs(obs[d] - exp[d]))
    return {"n": n, "mad": round(mad, 4),
            "observed": {d: round(obs[d], 4) for d in range(1, 10)},
            "expected": {d: round(exp[d], 4) for d in range(1, 10)},
            "worst_digit": worst,
            "worst_observed_pct": round(obs[worst] * 100, 2),
            "worst_expected_pct": round(exp[worst] * 100, 2)}


def check_collusion(boq, bids):
    findings = []
    bidders = sorted(bids)
    if len(bidders) < 2:
        return findings

    # (a) 总报价等差数列 / 规律性百分比 —— 商丘雷同情形第 3 项
    tt = totals(boq, bids)
    seq = sorted(tt[b] for b in bidders)
    ok, d = _is_arith(seq)
    if ok and len(seq) >= 3:
        findings.append({"type": "报价呈等差数列", "severity": "高", "confidence": "HIGH",
                         "detail": {"sorted_totals": [round(x, 2) for x in seq], "common_diff": round(d, 2)},
                         "note": "多家总报价呈等差数列——商丘市《投标文件雷同情形》明确的雷同预警情形，须复核"})
    # 差额本身呈等差数列
    diffs = [seq[i + 1] - seq[i] for i in range(len(seq) - 1)]
    ok2, _ = _is_arith(sorted(diffs))
    if ok2 and len(diffs) >= 3:
        findings.append({"type": "报价差额呈等差数列", "severity": "高", "confidence": "HIGH",
                         "detail": {"diffs": [round(x, 2) for x in sorted(diffs)]},
                         "note": "报价差额本身呈等差数列，属雷同预警情形"})
    # 规律性百分比（固定比例递升）
    # ⚠ 修正：早期判据用「比值极差 <0.02」的绝对口径，会被正常竞争击穿——
    #    竞争性招标中各家总价本就只差千分之几，比值天然都在 1.00x，
    #    极差自然 <0.02，导致"任意一场正常开标"都被判成规律性百分比。
    #    改为双重条件：① 比值的【相对】离散度够小；② 平均间距显著 >1
    #    （即确实是"每家按固定比例抬高"，而非"大家报价都很接近"）。
    if len(seq) >= 3 and seq[0] > 0:
        ratios = [seq[i + 1] / seq[i] for i in range(len(seq) - 1)]
        r_mean = statistics.fmean(ratios)
        spread = (max(ratios) - min(ratios)) / r_mean if r_mean else 1.0
        if spread < T["ratio_spread_rel"] and (r_mean - 1.0) > T["ratio_min_spacing"]:
            findings.append({"type": "报价呈规律性百分比", "severity": "高", "confidence": "HIGH",
                             "detail": {"ratios": [round(r, 4) for r in ratios],
                                        "mean_ratio": round(r_mean, 4),
                                        "relative_spread": round(spread, 5)},
                             "note": f"相邻报价按约 {(r_mean-1)*100:.2f}% 的固定比例递升，比值相对离散度"
                                     f"仅 {spread*100:.2f}%——商丘市《投标文件雷同情形》明确的雷同预警情形"})

    # (b) 逐清单项单价"差异极小 / 同向微调"覆盖度 —— 政和县案例特征
    common = [c for c in boq if all(c in bids[b] for b in bidders)]
    if common:
        pairs = []
        for i in range(len(bidders)):
            for j in range(i + 1, len(bidders)):
                b1, b2 = bidders[i], bidders[j]
                same = 0
                for c in common:
                    p1, p2 = bids[b1][c], bids[b2][c]
                    if p2 != 0 and abs(_rel(p1, p2)) < T["near_identical_rel"]:
                        same += 1
                cover = same / len(common)
                if cover >= T["near_identical_cover"]:
                    pairs.append({"pair": [b1, b2], "coverage_pct": round(cover * 100, 1),
                                  "items": len(common)})
        for p in pairs:
            findings.append({"type": "报价高度趋同（同向微调）", "severity": "高", "confidence": "MEDIUM",
                             "detail": p,
                             "note": f"两家在 {p['coverage_pct']}% 的清单项上单价相对差 <"
                                     f"{T['near_identical_rel']*100}%，非独立编制特征明显（政和县案例同类特征）"})

        # (c) 报价策略向量相关性（弱线索，仅作佐证）
        # ⚠ 两处坑，均已修正：
        #   坑一：不能直接对原始单价求相关——清单项量级差异极大（钢筋 5000 vs 土方 45），
        #        量级会主导相关系数，导致任意两家都 ≈1.0 的伪阳。必须先按「清单项均价」归一。
        #   坑二（更难察觉）：即使归一后，正常市场竞争也会产生高相关。所有投标人面对同一
        #        控制价与同一份清单，普遍做法高度雷同（主材不敢压、竞争项压到底），
        #        于是策略向量天然趋同，r 轻易 ≥0.98。实测：4 家独立报价、6 个清单项下，
        #        无关的两家也跑出 r=0.9925。
        #    处置：① 样本门槛提到 10 项（小样本 r 极不稳定）；
        #          ② 判定降级为「弱线索」（severity 中 / confidence LOW），
        #             仅当 r≥0.999 或与 (b)「逐项差异极小」同时命中同一对时，才升为强线索；
        #          ③ note 明示该指标的局限，禁止单独据此定性。
        mean_by_item = {c: statistics.fmean([bids[b][c] for b in bidders]) for c in common}
        near_pairs = {tuple(p["pair"]) for p in pairs}
        if len(common) >= T["min_items_for_corr"]:
            for i in range(len(bidders)):
                for j in range(i + 1, len(bidders)):
                    b1, b2 = bidders[i], bidders[j]
                    v1 = [bids[b1][c] / mean_by_item[c] for c in common]
                    v2 = [bids[b2][c] / mean_by_item[c] for c in common]
                    m1, m2 = statistics.fmean(v1), statistics.fmean(v2)
                    num = sum((x - m1) * (y - m2) for x, y in zip(v1, v2))
                    den = math.sqrt(sum((x - m1) ** 2 for x in v1) * sum((y - m2) ** 2 for y in v2))
                    if den <= 0:
                        continue
                    r = num / den
                    if r < T["corr_threshold"]:
                        continue
                    also_near = (b1, b2) in near_pairs
                    strong = r >= T["corr_strong"] or also_near
                    findings.append({
                        "type": "报价策略高度趋同（归一化相关）",
                        "severity": "高" if strong else "中",
                        "confidence": "MEDIUM" if strong else "LOW",
                        "detail": {"pair": [b1, b2], "pearson_r": round(r, 4),
                                   "items": len(common),
                                   "also_near_identical": also_near},
                        "note": ("剔除量级影响后两家报价模式仍近乎完全同步"
                                 f"（r={r:.4f}≥{T['corr_strong']}），且/或同时命中『逐项差异极小』，"
                                 "可作为强线索提交复核"
                                 if strong else
                                 f"剔除量级影响后两家报价模式相似（r={r:.4f}）。"
                                 "⚠ 该指标区分能力有限：同一控制价下的正常竞争也会产生高相关，"
                                 "单独不足以指向串通，须与『逐项差异极小』『规律性百分比』等证据并用，"
                                 "并经评标委员会复核"),
                    })

    # (d) 本福特定律偏离 —— 威海审计局实践路径
    for b in bidders:
        bf = benford_check([bids[b].get(c) for c in boq])
        if bf and bf["mad"] > T["benford_mad_note"]:
            findings.append({"type": "首位数频率分布异常", "bidder": b,
                             "severity": "中" if bf["mad"] <= 0.015 else "高",
                             "confidence": "LOW",
                             "detail": bf,
                             "note": f"MAD={bf['mad']}；首数字 {bf['worst_digit']} 实测 "
                                     f"{bf['worst_observed_pct']}% vs 理论 {bf['worst_expected_pct']}%。"
                                     "威海审计局曾据此查出结算阶段更换材料单价套取差价。"
                                     "⚠ 仅为统计线索，样本量小或行业性定价习惯也会造成偏离，必须人工复核"})

    # (e) 陪标特征：报价贴近控制价且非最低价
    ctrl_total = sum(it["control_price"] * it["qty"] for it in boq.values())
    lowest = min(tt, key=lambda b: tt[b]) if tt else None
    for b in bidders:
        if b == lowest:
            continue
        if ctrl_total > 0 and abs(_rel(tt[b], ctrl_total)) <= T["control_near"]:
            findings.append({"type": "陪标特征（贴近控制价且非最低价）", "bidder": b,
                             "severity": "中", "confidence": "LOW",
                             "detail": {"total": round(tt[b], 2), "control_total": round(ctrl_total, 2),
                                        "deviation_pct": round(_rel(tt[b], ctrl_total) * 100, 2)},
                             "note": "威海审计局列举的异常行为之一：某企业投标报价接近控制价、"
                                     "从未中标却持续参与。单项目证据弱，须跨项目累计观察"})
    return findings


# ---------------------------------------------------------------- 输出
def render_md(boq, bids, compliance, dev_findings, unbal, coll, base):
    tt = totals(boq, bids)
    L = []
    L.append("# 智能清标与围串标线索扫描报告\n")
    L.append(f"> 基准口径：{ '控制价' if base=='control' else '各家均价' }；"
             f"投标人 {len(bids)} 家；清单项 {len(boq)} 条\n")
    L.append(f"> ⚠ {DISCLAIMER}\n")

    L.append("\n## 一、报价概览\n")
    L.append("| 投标人 | 总报价 | 与控制价偏差 |")
    L.append("|---|---:|---:|")
    ctrl_total = sum(it["control_price"] * it["qty"] for it in boq.values())
    for b in sorted(tt, key=lambda x: tt[x]):
        dev = _rel(tt[b], ctrl_total) * 100 if ctrl_total else 0
        L.append(f"| {b} | {tt[b]:,.2f} | {dev:+.2f}% |")

    def dump(title, items):
        L.append(f"\n## {title}\n")
        if not items:
            L.append("✅ 未发现该类线索。\n")
            return
        for f in items:
            sev = f.get("severity", "?")
            who = f" · {f['bidder']}" if f.get("bidder") else ""
            L.append(f"- **[{sev}] {f['type']}**{who}"
                     + (f"（{f['count']} 项）" if f.get("count") else ""))
            if f.get("detail"):
                L.append(f"  - 明细：{json.dumps(f['detail'], ensure_ascii=False)}")
            if f.get("top"):
                for t in f["top"]:
                    L.append(f"  - `{t['code']}` {t['name']} 单价 {t['unit_price']} vs 基准 "
                             f"{round(t['ref_price'],2)} → 偏差 {t['deviation_pct']:+.2f}%")
            if f.get("worst"):
                for t in f["worst"]:
                    L.append(f"  - `{t['code']}` {t['name']} 偏差 {t['deviation_pct']:+.2f}%"
                             f"，金额 {t['amount']:,.2f}")
            L.append(f"  - 判据/处置：{f.get('note','')}")

    dump("二、符合性检查", compliance)
    dump("三、单价偏差（不平衡报价的抬高/压低侧）", dev_findings)
    dump("四、不平衡报价风险", unbal)
    dump("五、围串标线索", coll)
    L.append(f"\n---\n\n> ⚠ {DISCLAIMER}\n")
    return "\n".join(L)


# ---------------------------------------------------------------- selftest
def _selftest():
    """自证机制：植入已知真值的样本，断言判据行为符合预期（含**伪阳回归**）。

    设计原则（吸取此前两次假阳教训）：
      必须同时准备「植入信号样本」与「独立对照样本」。只跑植入样本会漏掉
      「正常竞争也被判高危」这类伪阳——本引擎曾两次栽在这上面。
    失败非零退出，供 scripts/selftest_all.py 汇总。
    """
    import csv as _csv
    import tempfile

    results = []

    def ck(name, cond, detail=""):
        results.append((name, bool(cond), detail))

    BOQ = [
        ("A01", "土方开挖", "m3", 1200, 45), ("A02", "C30混凝土", "m3", 800, 620),
        ("A03", "钢筋HRB400", "t", 150, 5000), ("A04", "外墙涂料", "m2", 3000, 38),
        ("A05", "铝合金窗", "m2", 600, 480), ("A06", "地砖铺贴", "m2", 2000, 95),
        ("A07", "内墙抹灰", "m2", 5000, 22), ("A08", "防水卷材", "m2", 1500, 58),
        ("A09", "镀锌钢管", "m", 900, 42), ("A10", "电缆敷设", "m", 2400, 76),
        ("A11", "脚手架", "m2", 4000, 18), ("A12", "模板", "m2", 6000, 65),
    ]
    # 各家相对控制价的折扣系数（12 项，>min_items_for_corr=10）
    DISC = {
        "甲公司": [.989, .997, .996, .987, .996, .989, .995, .993, .988, .997, .985, .998],
        "乙公司": [.911, .952, .970, 1.300, .948, .926, .940, .955, .930, .962, .915, .950],
        "丁公司": [.960, .976, .990, .947, .979, .974, .982, .965, .978, .988, .955, .991],
    }
    rows = []
    for nm, ds in DISC.items():
        for (code, _n, _u, _q, cp), d in zip(BOQ, ds):
            rows.append({"bidder": nm, "code": code, "unit_price": round(cp * d, 4)})
    # 丙 = 乙 × 1.001 —— 植入围串标信号（逐项差异极小 + 归一化 r=1.0）
    for (code, _n, _u, _q, _cp) in BOQ:
        v = next(r["unit_price"] for r in rows
                 if r["bidder"] == "乙公司" and r["code"] == code)
        rows.append({"bidder": "丙公司", "code": code, "unit_price": round(v * 1.001, 4)})

    tmpd = tempfile.mkdtemp(prefix="bidclean_selftest_")
    boqp = os.path.join(tmpd, "boq.csv")
    bidp = os.path.join(tmpd, "bids.csv")
    with open(boqp, "w", encoding="utf-8", newline="") as f:
        w = _csv.DictWriter(f, fieldnames=["code", "name", "unit", "qty", "control_price"])
        w.writeheader()
        for c, n, u, q, cp in BOQ:
            w.writerow({"code": c, "name": n, "unit": u, "qty": q, "control_price": cp})
    with open(bidp, "w", encoding="utf-8", newline="") as f:
        w = _csv.DictWriter(f, fieldnames=["bidder", "code", "unit_price"])
        w.writeheader()
        w.writerows(rows)

    try:
        boq = load_boq(boqp)
        bids = load_bids(bidp)
        ck("S1.1 清单载入 12 项", len(boq) == 12, f"got {len(boq)}")
        ck("S1.2 报价载入 4 家", len(bids) == 4, f"got {len(bids)}")

        tt = totals(boq, bids)
        ck("S1.3 总价键数=4", len(tt) == 4, str(list(tt)))

        dev, _ = check_deviation(boq, bids, "control")
        dev_pairs = {(d["bidder"], t["code"]) for d in dev for t in d["top"]}
        ck("S2.1 抓到植入的 +30% 虚高（乙·A04）", ("乙公司", "A04") in dev_pairs,
           str(sorted(dev_pairs)))
        ck("S2.2 未误报正常项（甲·A01 不在偏差表）", ("甲公司", "A01") not in dev_pairs)

        unbal = check_unbalance(boq, bids, "control")
        ub = {u["bidder"] for u in unbal}
        ck("S2.3 不平衡报价识别到乙/丙", {"乙公司", "丙公司"} <= ub, str(sorted(ub)))
        ck("S2.4 甲（全项贴近基准）不判不平衡", "甲公司" not in ub, str(sorted(ub)))

        coll = check_collusion(boq, bids)
        # S3 植入信号必须被判高危
        strong = [c for c in coll if c["severity"] == "高"]
        pair_strong = {tuple(c["detail"]["pair"]) for c in strong
                       if "pair" in (c.get("detail") or {})}
        ck("S3.1 植入串标对（乙/丙）判为高危", ("乙公司", "丙公司") in pair_strong
           or ("丙公司", "乙公司") in pair_strong, str(sorted(pair_strong)))
        # S4 伪阳回归：独立对照对（丁/甲）不得判高危
        ck("S4.1 独立对照对（丁/甲）不判高危（伪阳回归）",
           ("丁公司", "甲公司") not in pair_strong
           and ("甲公司", "丁公司") not in pair_strong, str(sorted(pair_strong)))
        # S5 规律性百分比不得在正常竞争下误报
        types = {c["type"] for c in coll}
        ck("S5.1 正常竞争不误报『规律性百分比』", "报价呈规律性百分比" not in types,
           str(sorted(types)))
        # S6 小样本不启用相关性判据（自由度不足）
        small = [c for c in load_collusion_small() if "归一化相关" in c.get("type", "")]
        ck("S6.1 清单项 <10 时不做相关性判定", not small, f"got {len(small)}")

        # S7 输出契约：辅助性定位声明必须随结果返回（红线：不构成定性结论）
        ck("S7.1 DISCLAIMER 含发改法规〔2026〕195 号依据", "195" in DISCLAIMER,
           DISCLAIMER[:40])
        ck("S7.2 DISCLAIMER 明示不构成定性结论",
           "不构成定性结论" in DISCLAIMER and "辅助性线索" in DISCLAIMER)
        ck("S7.3 每条围串标线索均带 note（可溯源处置口径）",
           all(c.get("note") for c in coll), f"{sum(1 for c in coll if c.get('note'))}/{len(coll)}")
        ck("S7.4 每条线索均带 severity 分级",
           all(c.get("severity") in ("高", "中", "低") for c in coll),
           str(sorted({c.get("severity") for c in coll})))

        # S8 阈值可配置（真实招标文件自定标准，实测广东 2026-07 某项目约定 ±20%）
        #    同一个 +18% 偏差：缺省 15% 报警，按该项目约定的 20% 不报。
        #    若此断言失败，说明阈值被写死或覆盖失效，会对该项目产生误报。
        saved_h, saved_l = T["deviation_high"], T["deviation_low"]
        try:
            dev18, _ = check_deviation(boq, bids, "control")
            T["deviation_high"], T["deviation_low"] = 15.0, -15.0
            d15, _ = check_deviation(boq, bids, "control")
            T["deviation_high"], T["deviation_low"] = 20.0, -20.0
            d20, _ = check_deviation(boq, bids, "control")
        finally:
            T["deviation_high"], T["deviation_low"] = saved_h, saved_l
        ck("S8.1 缺省 15% 下 +30% 植入项被识别", len(d15) >= 1, f"{len(d15)} 条")
        ck("S8.2 阈值放宽到 20% 后 +30% 仍被识别（未失效）", len(d20) >= 1, f"{len(d20)} 条")
        # 构造纯净样本：12 项清单，仅一家把 A01 抬到 +18%（介于 15 与 20 的分水岭），
        # 其余全部恰好等于控制价。⚠ 不能复用上面的样本——它含 +30% 植入项，
        #    在 20% 阈值下本就该继续报警，会把「阈值是否生效」与「植入项是否存在」两个
        #    变量混在一起而测不准（这正是我第一版断言写错的地方）。
        boq18 = {f"C{i}": {"code": f"C{i}", "name": f"项{i}", "unit": "m2",
                           "qty": 100.0, "control_price": 100.0 + i}
                 for i in range(1, 13)}
        bids18 = {"甲公司": {f"C{i}": 100.0 + i for i in range(1, 13)}}
        bids18["乙公司"] = dict(bids18["甲公司"])
        bids18["乙公司"]["C1"] = 118.0          # +18%
        try:
            T["deviation_high"], T["deviation_low"] = 15.0, -15.0
            a15, _ = check_deviation(boq18, bids18, "control")
            T["deviation_high"], T["deviation_low"] = 20.0, -20.0
            a20, _ = check_deviation(boq18, bids18, "control")
            T["deviation_high"], T["deviation_low"] = 18.0, -18.0
            a18, _ = check_deviation(boq18, bids18, "control")
        finally:
            T["deviation_high"], T["deviation_low"] = saved_h, saved_l
        ck("S8.3 分水岭：+18% 在缺省 15% 下报警", len(a15) >= 1, f"{len(a15)} 条")
        ck("S8.4 分水岭：+18% 在招标文件 20% 下不报警（防误报）", len(a20) == 0,
           f"{len(a20)} 条")
        ck("S8.5 阈值等于 18% 时按『超出』判定为不报（边界不含等号）", len(a18) == 0,
           f"{len(a18)} 条")
        ck("S8.6 线索 note 含「以招标文件约定为准」提示",
           all("招标文件" in x.get("note", "") for x in d15) if d15 else False)
    finally:
        for f_ in (boqp, bidp):
            try:
                os.remove(f_)
            except OSError:
                pass
        try:
            os.rmdir(tmpd)
        except OSError:
            pass

    print("=" * 60)
    print("bid_clean_check · selftest")
    print("=" * 60)
    for name, ok, detail in results:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"  · {detail}" if detail else ""))
    passed = sum(1 for _, ok, _ in results if ok)
    total = len(results)
    print("-" * 60)
    print(f"{passed}/{total} 通过")
    print("=" * 60)
    sys.exit(0 if passed == total else 1)


def load_collusion_small():
    """构造 5 项小清单，验证相关性判据的样本门槛（<10 项不启用）。

    ⚠ boq 必须是 dict（load_boq 的返回形态 {code: {...}}），传 list 会让
    totals()/check_collusion() 报 'list' object has no attribute 'items'。
    """
    boq = {f"B{i}": {"code": f"B{i}", "name": f"项{i}", "unit": "m2",
                     "qty": 100.0, "control_price": float(100 + i)}
           for i in range(1, 6)}
    bids = {"甲公司": {f"B{i}": (100 + i) * 0.99 for i in range(1, 6)},
            "乙公司": {f"B{i}": (100 + i) * 0.91 for i in range(1, 6)}}
    return check_collusion(boq, bids)


# ---------------------------------------------------------------- CLI
def main():
    p = argparse.ArgumentParser(description="智能清标与围串标线索扫描器（辅助性定位）")
    sub = p.add_subparsers(dest="cmd")

    sub.add_parser("selftest", help="自证机制：植入信号 + 伪阳回归，失败非零退出")

    def common(sp):
        sp.add_argument("--boq", required=True, help="招标清单 CSV: code,name,unit,qty,control_price")
        sp.add_argument("--bids", required=True, help="投标报价 CSV: bidder,code,unit_price")
        sp.add_argument("--base", choices=["control", "mean"], default="control")
        sp.add_argument("--dev-high", type=float,
                        help="不平衡报价抬高侧阈值%%（缺省 15）。★务必按招标文件"
                             "「不平衡报价」条款填：实测广东 2026-07 某施工招标约定为 20%%")
        sp.add_argument("--dev-low", type=float,
                        help="不平衡报价压低侧阈值%%（缺省 -15），同上以招标文件为准")
        sp.add_argument("--md", action="store_true", help="强制输出 Markdown")
        sp.add_argument("--json", action="store_true", help="强制输出 JSON（供程序解析）")
        sp.add_argument("--out", help="写入文件（默认打印到标准输出）")

    for name, help_ in (("check", "符合性检查 + 单价偏差矩阵"),
                        ("unbalance", "不平衡报价识别"),
                        ("collusion", "围串标线索扫描"),
                        ("report", "全流程一键出报告")):
        common(sub.add_parser(name, help=help_))

    a = p.parse_args()
    if not a.cmd:
        p.print_help()
        return
    if a.cmd == "selftest":
        _selftest()
        return

    # 阈值以招标文件为准：命令行覆盖优先，其次环境变量，最后缺省 15
    if getattr(a, "dev_high", None) is not None:
        T["deviation_high"] = float(a.dev_high)
    elif os.environ.get("BID_DEV_HIGH"):
        T["deviation_high"] = float(os.environ["BID_DEV_HIGH"])
    if getattr(a, "dev_low", None) is not None:
        T["deviation_low"] = float(a.dev_low)
    elif os.environ.get("BID_DEV_LOW"):
        T["deviation_low"] = float(os.environ["BID_DEV_LOW"])
    if T["deviation_high"] != 15.0 or T["deviation_low"] != -15.0:
        print(f"※ 不平衡报价阈值已按外部约定覆盖：抬高 > +{T['deviation_high']}%、"
              f"压低 < {T['deviation_low']}%（来自招标文件约定）", file=sys.stderr)

    boq = load_boq(a.boq)
    bids = load_bids(a.bids)
    if not boq or not bids:
        print(json.dumps({"error": "清单或投标数据为空", "boq_items": len(boq),
                          "bidders": len(bids)}, ensure_ascii=False))
        sys.exit(2)

    compliance = check_compliance(boq, bids)
    dev_findings, _ = check_deviation(boq, bids, a.base)
    unbal = check_unbalance(boq, bids, a.base)
    coll = check_collusion(boq, bids)

    if a.cmd == "check":
        payload = {"compliance": compliance, "deviation": dev_findings, "disclaimer": DISCLAIMER}
    elif a.cmd == "unbalance":
        payload = {"unbalance": unbal, "disclaimer": DISCLAIMER}
    elif a.cmd == "collusion":
        payload = {"collusion": coll, "totals": totals(boq, bids), "disclaimer": DISCLAIMER}
    else:
        payload = {"totals": totals(boq, bids), "compliance": compliance,
                   "deviation": dev_findings, "unbalance": unbal, "collusion": coll,
                   "disclaimer": DISCLAIMER}

    # 输出形态：--json 显式优先；否则 report 出 Markdown（人读），其余出 JSON（机读）
    if a.json:
        text = json.dumps(payload, ensure_ascii=False, indent=2)
    elif a.md or (a.cmd == "report" and not a.out):
        text = render_md(boq, bids, compliance, dev_findings, unbal, coll, a.base)
    else:
        text = json.dumps(payload, ensure_ascii=False, indent=2)

    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"✓ 已写入 {a.out}")
    else:
        print(text)


if __name__ == "__main__":
    main()
