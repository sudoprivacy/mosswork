#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
capability_demo.py · 九项能力「一键自证」演示器（纯标准库，无第三方依赖）

为什么要有这个脚本
------------------
外部评测者/初次接触者最容易下的结论是：「技能是空壳、能力是占位符」。
本脚本用真实样例把九项能力各跑一遍，逐项打印「真实引擎是否执行 + 关键数字」，
一条命令即可自证：能力不是桩，是接了真实算法的。

用法
----
    python scripts/capability_demo.py                    # 跑全部九项
    python scripts/capability_demo.py --only reprice,price_query
    python scripts/capability_demo.py selftest           # 回归模式（任一失败退出码非 0）
    python scripts/capability_demo.py --selftest         # 同上（两种写法均可）
    python scripts/capability_demo.py --json             # 机器可读输出
    python scripts/capability_demo.py --pdf a.pdf        # 给 cad_takeoff 一份图纸做真跑

纪律（与技能反幻觉红线一致）
----------------------------
1. 全部用例走 execute_real:true，跑的是 scripts/ 下的真实算法引擎，不是模拟数据。
2. 引擎未产出结果时如实标 FAIL / SKIP，**绝不补一个假数字凑数**。
3. cad_takeoff 需要图纸：未给 --pdf 时演示其「诚实拒绝」行为（宁不出数、不给假数），
   并另跑该引擎自带 selftest 作为「引擎真实存在且可用」的证据。
"""
import argparse
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT = os.path.dirname(HERE)
PAY_DIR = os.path.join(SKILL_ROOT, "cost_auditor_pay")

if PAY_DIR not in sys.path:
    sys.path.insert(0, PAY_DIR)

try:
    from capabilities import run_capability, CAPABILITY_FUNCS  # noqa: E402
except Exception as e:  # noqa: BLE001
    print(f"[FATAL] 无法导入能力层：{e}")
    print(f"        期望位置：{os.path.join(PAY_DIR, 'capabilities.py')}")
    sys.exit(2)


# --------------------------------------------------------------------------- #
# 小工具
# --------------------------------------------------------------------------- #
def _first_num(text, pattern):
    m = re.search(pattern, text or "")
    return m.group(1) if m else None


def _lines(text, n=1):
    """取前 n 行有效文本（剔除分隔线，避免把 ===== 当首行展示）。"""
    ls = [l.strip() for l in (text or "").splitlines()
          if l.strip() and not re.fullmatch(r"[=_\-*#\s]+", l.strip())]
    return ls[:n]


def _engine_of(resp):
    """能力返回的 engine 段（各能力字段名一致，quantity 引擎另取）。"""
    return (resp or {}).get("engine") or {}


# --------------------------------------------------------------------------- #
# 九项能力演示用例
# 每个用例：params 为真跑入参；probe(resp, ctx) → (ok, [关键数字...], 说明)
# --------------------------------------------------------------------------- #
CASES = []


def case(key, title, params, probe):
    CASES.append({"key": key, "title": title, "params": params, "probe": probe})


# 1) reprice —— price_estimator.py（型钢理论重量 / 电缆铜价 / 铜价换算）
case(
    "reprice", "综合单价重算·核减",
    {"execute_real": True,
     "items": [{"name": "H型钢 400×200×8×13", "kind": "H",
                "h": 400, "b": 200, "tw": 8, "tf": 13, "len": 6, "price": 4200}]},
    lambda r, c: (
        _engine_of(r).get("engine_ran") is True,
        ["引擎=price_estimator.py",
         f"子命令={' '.join((_engine_of(r).get('engine_argv') or ['?'])[:1])}",
         f"理论重量={_first_num(_engine_of(r).get('raw_output', ''), r'理论重量\s*:\s*([\d,\.]+)')} kg/m",
         f"根重={_first_num(_engine_of(r).get('raw_output', ''), r'=\s*([\d,\.]+)\s*t')} t",
         f"金额={_first_num(_engine_of(r).get('raw_output', ''), r'→\s*([\d,\.]+)\s*元')} 元/根"],
        "型钢理论重量按公称尺寸算，非估算值"))


# 2) settle_review —— audit_triple_source.py 三源比价
case(
    "settle_review", "结算争议核减分析",
    {"execute_real": True,
     "claims": [{"kw": "钢筋", "qty": 186, "price": 3600, "unit": "t", "cat": "材料"},
                {"kw": "混凝土·C30", "qty": 120, "price": 500, "unit": "m3", "cat": "材料"}]},
    lambda r, c: (
        _engine_of(r).get("engine_ran") is True,
        ["引擎=audit_triple_source.py", "子命令=audit-file",
         f"送审条目={(r.get('result') or {}).get('claim_count')}",
         f"输出={len((_engine_of(r).get('raw_output') or '').splitlines())} 行",
         f"首行={(_lines(_engine_of(r).get('raw_output'), 1) or [''])[0][:40]}"],
        "三源交叉核：价库 + 检测库 + 政策效力闸"))


# 3) cad_takeoff —— cadvector_takeoff.py（需图纸；未给图纸演示诚实拒绝 + 引擎自检）
def _probe_cad(r, ctx):
    eng = _engine_of(r)
    pdf = ctx.get("pdf")
    if pdf:
        return (eng.get("engine_ran") is True,
                ["引擎=cadvector_takeoff.py", f"图纸={os.path.basename(pdf)}",
                 f"阶段={(r.get('result') or {}).get('stage')}",
                 f"输出={len((eng.get('raw_output') or '').splitlines())} 行"],
                "给了图纸即真跑；未标定只做图元提取、不出工程量")
    # 未给图纸：必须诚实拒绝，且不得编造工程量
    refused = (eng.get("engine_ran") is not True) and (
        "argv_incomplete" in str(eng.get("error") or "") or "拒绝" in str(eng.get("note") or ""))
    # 引擎真实性证据：跑引擎自带 selftest
    proof = "未跑"
    proof_ok = False
    try:
        p = subprocess.run([sys.executable, os.path.join(HERE, "cadvector_takeoff.py"), "selftest"],
                           capture_output=True, text=True, timeout=180, cwd=HERE)
        m = re.search(r'"summary"\s*:\s*"(\d+/\d+ PASS)"', p.stdout or "")
        if m:
            proof = m.group(1)
            proof_ok = "13/13" in proof or p.returncode == 0
    except Exception as e:  # noqa: BLE001
        proof = f"运行失败: {str(e)[:60]}"
    return (refused and proof_ok,
            ["引擎=cadvector_takeoff.py",
             f"无图纸→诚实拒绝={'是' if refused else '否'}",
             f"是否输出工程量={(r.get('result') or {}).get('measured')}",
             f"引擎自带自检={proof}"],
            "守红线第 11 条：未标定不得输出工程量。给 --pdf 可演示真跑")


case("cad_takeoff", "工程量图纸核对·CAD算量", {"execute_real": True}, _probe_cad)


# 4) bid_selfcheck —— cost_adjuster.py（不平衡报价 / 虚高预警）
case(
    "bid_selfcheck", "投标报价经济性自检",
    {"execute_real": True,
     "quotes": [{"name": "混凝土·C30", "price": 500, "qty": 100, "unit": "m3"}]},
    lambda r, c: (
        _engine_of(r).get("engine_ran") is True
        and (r.get("result") or {}).get("computed_count", 0) >= 1,
        ["引擎=cost_adjuster.py",
         f"已算条目={(r.get('result') or {}).get('computed_count')}",
         f"偏差={((r.get('result') or {}).get('items') or [{}])[0].get('deviation_pct')}%",
         f"判定={((r.get('result') or {}).get('items') or [{}])[0].get('flag')}",
         f"基准价来源={((r.get('result') or {}).get('items') or [{}])[0].get('benchmark_source')}"],
        "基准价取自日更价库；缺失即不判、不评分"))


# 5) claim_report —— claim_drafter.py（索赔意向通知）
case(
    "claim_report", "索赔报告生成",
    {"execute_real": True,
     "project": "CASE-C 某大厦装饰工程",
     "contract": "GF-2017-0201",
     "type": "费用索赔",
     "event": "发包人提供图纸延迟致窝工 5 天",
     "contractor": "某装饰工程有限公司",
     "contact": "项目经理"},
    lambda r, c: (
        _engine_of(r).get("engine_ran") is True,
        ["引擎=claim_drafter.py", "子命令=notice",
         f"生成正文={len((_engine_of(r).get('raw_output') or ''))} 字",
         f"首行={(_lines(_engine_of(r).get('raw_output'), 2) or ['', ''])[-1][:40]}"],
        "成果走临时文件→读回响应→立即删除，不落盘技能目录"))


# 6) price_query —— 日更价库实时读 + material_price_lookup.py 兜底
case(
    "price_query", "材料价格查询",
    {"kw": "钢筋"},
    lambda r, c: (
        ((r.get("result") or {}).get("hit_count", 0) >= 1
         and (r.get("price_db") or {}).get("ok") is True),
        ["数据源=material_prices.json(live)",
         f"命中={(r.get('result') or {}).get('hit_count')} 条",
         f"首条={(((r.get('result') or {}).get('prices') or [{}])[0]).get('name')}",
         f"价={(((r.get('result') or {}).get('prices') or [{}])[0]).get('price')}"
         f" 期号={(((r.get('result') or {}).get('prices') or [{}])[0]).get('period')}",
         f"置信度={(r.get('confidence'))}"],
        "价库由 material_price_update.py 日更维护；本能力只读不写"))


# 7) index_compare —— price_index_lookup.py（造价指数调差）
case(
    "index_compare", "造价指标·调差对比",
    {"execute_real": True, "category": "房屋建筑工程",
     "base": "2026-03", "to": "2026-07",
     "labor": 93700, "machine": 50000, "aux": 20000, "main_mat": 468500},
    lambda r, c: (
        _engine_of(r).get("engine_ran") is True,
        ["引擎=price_index_lookup.py", "子命令=adjust",
         "基期=2026-03 → 目标期=2026-07",
         f"要素调差合计={_first_num(_engine_of(r).get('raw_output', ''), r'要素调差合计：(-?[\d,\.]+)')} 元",
         "主要材料费=按编制期价直接计入，不乘指数"],
        "台班指数已含机上人工与燃料，不得重复调；不调管理费和利润"))


# 8) clear_tender —— bid_clean_check.py（清标 + 围串标线索）
_BOQ = [{"code": "10401639811.94", "name": "水泥砂浆楼地面", "unit": "m2", "qty": 100, "control_price": 45},
        {"code": "10495337937.94", "name": "墙面一般抹灰", "unit": "m2", "qty": 200, "control_price": 32},
        {"code": "10589974937.94", "name": "天棚吊顶", "unit": "m2", "qty": 150, "control_price": 120}]
_BIDS = [{"bidder": "投标人A", "code": "10401639811.94", "unit_price": 45},
         {"bidder": "投标人A", "code": "10495337937.94", "unit_price": 32},
         {"bidder": "投标人A", "code": "10589974937.94", "unit_price": 120},
         {"bidder": "投标人B", "code": "10401639811.94", "unit_price": 55},
         {"bidder": "投标人B", "code": "10495337937.94", "unit_price": 30},
         {"bidder": "投标人B", "code": "10589974937.94", "unit_price": 118}]
case(
    "clear_tender", "招投标清标·围串标线索扫描",
    {"execute_real": True, "boq": _BOQ, "bids": _BIDS, "base": "control"},
    lambda r, c: (
        _engine_of(r).get("engine_ran") is True,
        ["引擎=bid_clean_check.py", "子命令=report --json",
         f"清单项={len(_BOQ)} 报价行={len(_BIDS)}",
         f"偏差线索={(r.get('result') or {}).get('deviation_clue_count')} 条",
         f"围串标线索={(r.get('result') or {}).get('collusion_clue_count')} 条",
         f"各投标人总价={json.dumps(((r.get('result') or {}).get('totals') or {}), ensure_ascii=False)[:70]}"],
        "围串标一律为『线索/疑点』，不给定性结论；阈值以招标文件为准"))


# 9) health_check —— audit_triple_source + quantity_checker 双引擎
case(
    "health_check", "成果质量体检",
    {"execute_real": True,
     "items": [{"kw": "钢筋", "qty": 186, "price": 3600, "unit": "t", "cat": "材料"},
               {"kw": "钢筋Φ16", "diameter": 16, "count": 10, "length": 6}]},
    lambda r, c: (
        _engine_of(r).get("engine_ran") is True
        and (r.get("quantity_engine") or {}).get("engine_ran") is True,
        ["引擎A=audit_triple_source.py(单价三源核对)",
         "引擎B=quantity_checker.py(工程量比对·rebar)",
         f"体检条目={(r.get('result') or {}).get('checked')}",
         f"钢筋重量={_first_num((r.get('quantity_engine') or {}).get('raw_output', ''), r'([\d,\.]+)\s*(?:kg|t)')}",
         f"体检输出={len((_engine_of(r).get('raw_output') or '').splitlines())} 行"],
        "双引擎都真跑：此前 quantity_checker 只写在 docstring 里从未调用，已修"))


# --------------------------------------------------------------------------- #
# 反幻觉反向用例（只跑在 --selftest）：证明"缺数据时不编数"
# --------------------------------------------------------------------------- #
def negative_checks():
    """反向断言：无数据/未入库 → 必须不给数、不评分。"""
    out = []
    r = run_capability("bid_selfcheck",
                       {"execute_real": True,
                        "quotes": [{"name": "未入库材料XYZ", "price": 100, "qty": 1, "unit": "t"}]},
                       "demo")
    # 注意：result 里没有 unresolved_count 键，未解析条目在 unresolved 列表中；
    # 早期实现误用 len(items) 兜底，items 在缺基准价时为空 → 会显示 0，与"没算出来"矛盾。
    unresolved = len((r.get("result") or {}).get("unresolved") or [])
    out.append(("N1 未入库材料不评分",
                (r.get("result") or {}).get("computed_count", 0) == 0,
                f"computed={(r.get('result') or {}).get('computed_count')}, unresolved={unresolved}"))

    r2 = run_capability("price_query", {"kw": "绝无此材料ZZZQQQ"}, "demo")
    out.append(("N2 价库无命中不给价",
                (r2.get("result") or {}).get("hit_count", -1) == 0,
                f"hit={(r2.get('result') or {}).get('hit_count')}, conf={r2.get('confidence')}"))

    r3 = run_capability("cad_takeoff", {"execute_real": True}, "demo")
    out.append(("N3 无图纸不出工程量",
                (r3.get("result") or {}).get("measured") == [],
                f"measured={(r3.get('result') or {}).get('measured')}"))
    return out


# --------------------------------------------------------------------------- #
# 执行与输出
# --------------------------------------------------------------------------- #
def run_all(only=None, pdf=None):
    ctx = {"pdf": pdf}
    results = []
    for c in CASES:
        if only and c["key"] not in only:
            continue
        params = dict(c["params"])
        if c["key"] == "cad_takeoff" and pdf:
            params.update({"pdf_path": pdf, "page": 0})
        try:
            resp = run_capability(c["key"], params, "demo_user")
            ok, facts, why = c["probe"](resp, ctx)
            err = ""
        except Exception as e:  # noqa: BLE001
            resp, ok, facts, why, err = {}, False, [], "能力调用异常", str(e)[:200]
        results.append({"capability": c["key"], "title": c["title"], "ok": ok,
                        "facts": facts, "why": why, "error": err})
    return results


def main():
    ap = argparse.ArgumentParser(description="九项能力一键自证演示器")
    ap.add_argument("--only", help="只跑指定能力，逗号分隔")
    ap.add_argument("--pdf", help="给 cad_takeoff 指定图纸以演示真跑")
    ap.add_argument("--json", action="store_true", help="机器可读输出")
    ap.add_argument("--selftest", action="store_true", help="回归模式：含反向用例，失败退出码 1")
    # 位置参数形态：回归测试台统一以 `python <script> selftest` 调用（与其余引擎一致）
    ap.add_argument("subcommand", nargs="?", default="",
                    help="selftest：等同于 --selftest")
    a = ap.parse_args()
    if a.subcommand == "selftest":
        a.selftest = True

    only = [s.strip() for s in (a.only or "").split(",") if s.strip()] or None
    results = run_all(only, a.pdf)

    if a.json:
        print(json.dumps({"results": results}, ensure_ascii=False, indent=2))
    else:
        print("=" * 74)
        print("造价稽核官 CostAuditor · 九项能力一键自证（真实引擎，非模拟数据）")
        print("=" * 74)
        for r in results:
            mark = "PASS" if r["ok"] else "FAIL"
            print(f"\n[{mark}] {r['capability']} —— {r['title']}")
            for f in r["facts"]:
                print(f"        · {f}")
            print(f"        说明：{r['why']}")
            if r["error"]:
                print(f"        异常：{r['error']}")

    passed = sum(1 for r in results if r["ok"])
    total = len(results)
    neg = []
    if a.selftest:
        neg = negative_checks()
        if not a.json:
            print("\n" + "-" * 74)
            print("反向用例（证明缺数据时不编数）")
            for name, ok, detail in neg:
                print(f"[{'PASS' if ok else 'FAIL'}] {name} —— {detail}")

    ok_all = passed == total and all(o for _, o, _ in neg)
    if not a.json:
        print("\n" + "=" * 74)
        print(f"结果：{passed}/{total} 项通过"
              + (f"，反向 {sum(1 for _, o, _ in neg if o)}/{len(neg)}" if neg else ""))
        print("=" * 74)
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
