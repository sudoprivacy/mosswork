#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gz_estimate_lookup.py — 广州市市政工程主要项目概算指标及编制指引(2025) 检索器

数据源: scripts/data/gz_municipal_2025.json
  - indicators: 510 条（综合指标 1.1~1.6 + 分项指标 2.1~2.8，含四段式编号 2.3.1.x）
  - other_fees: 102 条（工程建设其他费用科目编码表，含计算方法与文件依据）

出处: 穗建造价〔2026〕17 号印发，广州市建设工程造价管理站 2026-03-09 发布；
      价格期 2025 年 6 月；配套《广东省建设工程概算编制办法》(2014)、
      《广东省市政工程综合定额(2018)》、《广州市市政工程补充综合定额(2019)》。

子命令:
  meta                          库信息与来源声明
  search <kw> [--section 2.5] [--part 分项指标] [--limit 20]
                                关键词搜索指标（名称/工作内容/备注/表标题）
  get <编号>                     精确取指标（如 2.1.1 / 2.3.1.5）或其他费科目（如 18836513.81）
  sections                      章节统计（各章节条数）
  section <编号>                 列出某章节全部指标（如 1.1 / 2.5）
  fee <kw>                      工程建设其他费用科目搜索
  stats                         全库统计

纪律（与 references/gz-municipal-estimate-2025.md §7 一致）:
  1. 综合指标是"区间值"（min～max），不是单价；概算评审引用时必须说明取值理由。
  2. 综合指标含工程建设其他费(12%)与基本预备费(5%)；分项指标仅含建安工程费。
  3. 价格期 2025-06，跨期使用必须调差，不得直接套用。
  4. 指标用途是方案比选/限额设计/概算控制参考，不能替代清单计价与定额组价。
"""
import json, os, re, sys, argparse

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'gz_municipal_2025.json')
META = {
    'title': '广州市市政工程主要项目概算指标及编制指引（2025）',
    'issuer': '广州市建设工程造价管理站',
    'doc_no': '穗建造价〔2026〕17 号',
    'issue_date': '2026-03-09',
    'price_period': '广州地区 2025 年 6 月（人工/材料/机械台班）',
    'basis': ['广东省建设工程概算编制办法(2014)', '广东省市政工程综合定额(2018)',
              '广州市市政工程补充综合定额(2019)', '广东省通用安装工程综合定额(2018)',
              '广东省园林绿化工程综合定额(2018)'],
    'structure': '综合指标(1.1-1.6，含其他费12%+预备费5%) / 分项指标(2.1-2.8，仅建安) / 概算编制指引(3.1-3.5)',
    'pages': 124,
}

def load():
    with open(DATA, encoding='utf-8') as f:
        return json.load(f)

def rec_text(r):
    parts = [r.get('name',''), r.get('work',''), r.get('note',''), r.get('table_title',''),
             r.get('section_name',''), r.get('unit','')]
    return ' '.join(str(p) for p in parts)

def show_ind(r):
    print(f"■ [{r.get('code') or r.get('seq','?')}] {r.get('name','?')}")
    loc = f"{r.get('part','')} {r.get('section','')} {r.get('section_name','')}".strip()
    if r.get('table_title'): loc += f" ｜ {r['table_title']}"
    print(f"  归属   : {loc} ｜ 原文P{r.get('page')}")
    if r.get('code'):
        if r.get('unit'): print(f"  单位   : {r['unit']}")
        print(f"  建安费 : {r.get('cost','—')} 元" + (f"（主材扣税 {r['main_material']}）" if r.get('main_material') else ''))
        if r.get('unit_price'): print(f"  综合单价: {r['unit_price']}")
        if r.get('work'): print(f"  工作内容: {r['work']}")
    else:
        if r.get('unit'): print(f"  单位   : {r.get('unit','').replace(' ','')}")
        if r.get('rule'): print(f"  计算规则: {r['rule']}")
        if r.get('cost_excl'): print(f"  建安(不含暂列): {r['cost_excl']}")
        if r.get('cost_incl'): print(f"  建安(含10%暂列): {r.get('cost_incl','—')}")
        if r.get('other'): print(f"  其他费(12%): {r['other']}")
        if r.get('reserve'): print(f"  预备费(5%): {r['reserve']}")
        if r.get('budget'): print(f"  概算价 : {r['budget']}")
        for i, alt in enumerate(r.get('alt', []) or []):
            print(f"  └ 副单位行: 单位={alt.get('unit','')} 概算价={alt.get('budget','—')}")
    if r.get('note'): print(f"  备注   : {r['note']}")

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)
    sub.add_parser('meta')
    p = sub.add_parser('search'); p.add_argument('kw'); p.add_argument('--section'); p.add_argument('--part'); p.add_argument('--limit', type=int, default=20)
    p = sub.add_parser('get'); p.add_argument('code')
    sub.add_parser('sections')
    p = sub.add_parser('section'); p.add_argument('sec')
    p = sub.add_parser('fee'); p.add_argument('kw')
    sub.add_parser('stats')
    a = ap.parse_args()
    db = load()

    if a.cmd == 'meta':
        for k, v in META.items(): print(f"{k:14s}: {v}")
        print(f"indicators    : {len(db['indicators'])} 条 | other_fees: {len(db['other_fees'])} 条")
        print("效力          : 概算编制依据（穗建造价〔2026〕17号）；指标本身为参考区间，引用须说明取值")
        return

    if a.cmd == 'search':
        kw = a.kw
        hits = [r for r in db['indicators'] if kw.lower() in rec_text(r).lower()]
        if a.section: hits = [r for r in hits if r.get('section') == a.section or r.get('section','').startswith(a.section)]
        if a.part: hits = [r for r in hits if a.part in r.get('part','')]
        print(f"命中 {len(hits)} 条（关键词「{kw}」）")
        for r in hits[:a.limit]:
            tag = r.get('code') or f"seq{r.get('seq','')}"
            print(f"  [{tag}] ({r.get('section','')} {r.get('section_name','')}|P{r.get('page')}) {r.get('name','')} "
                  f"→ {r.get('cost') or r.get('budget') or r.get('cost_excl','—')}")
        if len(hits) > a.limit: print(f"  ... 其余 {len(hits)-a.limit} 条请加 --limit 或细化关键词")
        return

    if a.cmd == 'get':
        code = a.code
        inds = [r for r in db['indicators'] if r.get('code') == code]
        seqs = [r for r in db['indicators'] if r.get('seq') == code]
        fees = [f for f in db['other_fees'] if f.get('code') == code]
        if inds:
            for r in inds: show_ind(r)
        elif seqs:
            for r in seqs: show_ind(r)
        elif fees:
            for f in fees:
                print(f"■ 其他费科目 [{f['code']}] {f['name']}" + ("（分组标题）" if f['is_group'] else ""))
                print(f"  原文P{f['page']}")
                if f.get('method'): print(f"  计算方法: {f['method']}")
        else:
            print(f"未找到编号 {code}（指标编号形如 2.1.1 / 2.3.1.5；其他费科目形如 18836513.81；综合指标用 section+seq 查）")
        return

    if a.cmd == 'sections':
        agg = {}
        for r in db['indicators']:
            k = (r.get('part','?'), r.get('section') or '—', r.get('section_name',''))
            agg[k] = agg.get(k, 0) + 1
        for (part, sec, name), n in sorted(agg.items()):
            print(f"  {part[:6]:6s} | {sec:4s} {name:14s} | {n} 条")
        return

    if a.cmd == 'section':
        hits = [r for r in db['indicators'] if r.get('section') == a.sec or r.get('section','').startswith(a.sec + '.')]
        # 排除四段子项? 保留，用户可用 search 细查
        print(f"章节 {a.sec} 共 {len(hits)} 条")
        for r in hits:
            tag = r.get('code') or f"seq{r.get('seq','')}"
            v = r.get('cost') or r.get('budget') or r.get('cost_excl','—')
            print(f"  [{tag}] {r.get('name','')}({r.get('unit','').replace(' ','') or '?'}) → {v}")
        return

    if a.cmd == 'fee':
        hits = [f for f in db['other_fees'] if a.kw.lower() in (f['name'] + f.get('method','')).lower()]
        print(f"其他费科目命中 {len(hits)} 条（关键词「{a.kw}」）")
        for f in hits[:25]:
            print(f"  [{f['code']}] {f['name']}" + ("（分组）" if f['is_group'] else f" ｜P{f['page']}"))
            if f.get('method') and not f['is_group']:
                print(f"      {f['method'][:90]}{'…' if len(f['method'])>90 else ''}")
        return

    if a.cmd == 'stats':
        inds = db['indicators']; fees = db['other_fees']
        coded = [r for r in inds if r.get('code')]
        vert = [r for r in inds if not r.get('code')]
        print(f"指标记录 {len(inds)} 条：分项编号型 {len(coded)} 条（含四段式 {sum(1 for r in coded if r['code'].count('.')==3)}），综合区间型 {len(vert)} 条")
        print(f"其他费科目 {len(fees)} 条")
        parts = {}
        for r in inds: parts[r.get('part','?')] = parts.get(r.get('part','?'), 0) + 1
        for k, v in parts.items(): print(f"  {k}: {v}")
        print("价格期: 2025-06 广州 ｜ 发布: 穗建造价〔2026〕17号 (2026-03-09)")

if __name__ == '__main__':
    main()
