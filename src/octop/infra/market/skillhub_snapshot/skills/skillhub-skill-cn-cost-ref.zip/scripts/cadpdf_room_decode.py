#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cadpdf_room_decode.py —— CAD 导出 PDF「房名解码 + 逐间算量」（v2 · gid 真值版）

解决两个实战痛点：
  痛点1：图纸中文是 Identity-H 无 ToUnicode 字体，提取出来是乱码
         （如 "⭧ḷ63$䰤1 A・䶒"），导致「图纸上到底有没有这个房间」判不出来。
         → 解码字母数字（63$→SPA、9,3→VIP、A/B/C/D、尺寸数字）。
  痛点2：只知道图纸总尺寸，算不出「逐间」工程量，无法与结算报量对账。
         → 按每间 A/B/C/D 四个立面 + 天花图，提取开间/进深/层高，逐间出量。

★ v2 核心改造（CASE-B 实测教训）：
  1. 数据源改用 get_texttrace()：无 ToUnicode 的 Type0 字体，texttrace 字符
     uni=U+FFFD、gid=真CID（dict 模式把 CID 当码点显示，干净/乱码难分辨）。
     → span 内出现 U+FFFD 即「乱码 span」，在 gid 空间做偏移解码；
       无 U+FFFD 的干净 span（标题栏 2026.6、图号 L-01、尺寸 2800）绝不偏移。
  2. 偏移按「字体」各自探测，且同一文档各嵌入字体的偏移可以不同：
     CASE-B 立面图实测 NSimSun=+29（GID19='0'）、MicrosoftYaHei=+26
     （GID22='0'）——两个都是真值！禁止用「全文统一偏移」假设互相对表。
  3. 探测判据 = 关键词命中（SPA/VIP/SCALE、1:50 形态）为主导，
     证据不足时老实返回 shift=0（按乱码保留），不得硬猜；
     可用 render 子命令渲染原图人工核验后 --force-shift。

★ 纪律（血泪教训，见 references/cad-pdf-room-takeoff.md §5）：
   房名判不出来时，禁止直接下「图纸查无」结论去核减。
   先用本脚本解码；解码失败则标注「待现场核实」，不得作为核减依据。
   （反面案例：某案误判 3 间房图纸查无，核减 11,857.74 元，解码后证实全部存在）

能力边界：乱码字体的 CJK 部分无法从文本层还原（无 ToUnicode 且嵌入字体
  cmap/post 被剥离）；房名主体靠 SPA/VIP + 编号 + A/B/C/D 立面字母识别，
  中文名由图纸文件名/人工对照补齐。

子命令：
  fonts     字体普查，识别乱码字体并探测各自偏移
  decode    解码指定页文本
  rooms     统计房间清单（房名 + 所在页 + 立面）
  dims      提取指定页的尺寸数字（横排=宽/竖排=高）
  takeoff   按房间页组规格逐间算量并汇总
  render    截取匹配文本的原图区域（人工核验解码是否正确）
  demo      内置样例自检（不依赖外部 PDF）

依赖：pymupdf（fitz）
"""
import argparse, json, math, os, re, sys
from collections import defaultdict, Counter

try:
    import fitz
except ImportError:
    print("✗ 需要 pymupdf：pip install pymupdf", file=sys.stderr)
    sys.exit(2)

FFFD = 0xFFFD

# ---------------------------------------------------------------- 编码偏移

def is_weird_char(o):
    """异常区段：既不是常用 ASCII、也不是 CJK/中文标点/全角 —— CID 子集重排的典型产物"""
    if o < 0x20:                      return True   # 控制字符
    if 0x20 <= o <= 0x7E:             return False  # 常规 ASCII
    if 0x4E00 <= o <= 0x9FFF:         return False  # CJK 基本区
    if 0x3000 <= o <= 0x303F:         return False  # 中文标点
    if 0xFF00 <= o <= 0xFFEF:         return False  # 全角
    if 0x3400 <= o <= 0x4DBF:         return False  # CJK 扩展A
    return True                                     # 其余（梵/藏/缅/泰/格鲁吉亚…）一律异常


def weird_ratio(s):
    if not s: return 0.0
    return sum(1 for c in s if is_weird_char(ord(c))) / len(s)


# 关键词：SPA/VIP 是房名锚点；SCALE 几乎每张图框都有，是通用锚点
DETECT_KEYWORDS = ("SPA", "VIP", "SCALE")


def _score(s, shift):
    """评分 = 关键词命中×50 + 解码后落入字母/数字的数量 + 1:50 形态×25"""
    d = "".join(chr(ord(c) + shift) if 0x20 <= ord(c) + shift <= 0x7E else c for c in s)
    n = 0
    for k in DETECT_KEYWORDS:
        n += d.count(k) * 50
    n += len(re.findall(r"\d:\d\d", d)) * 25
    for src, out in zip(s, d):
        if ("A" <= out <= "Z") or ("0" <= out <= "9"):
            n += 1
    return n, d


def detect_shift(text, min_weird=0.25, min_gain=3):
    """
    自动探测编码偏移。返回 (shift, 置信度, 说明)。
    ★ 只对「乱码字符样本」（gid 空间）调用。
    ★ 判据以关键词命中为主导；无关键词命中 = 证据不足，老实返回 0，
      不得硬猜（MSYH 标题栏样本 26/29 评分打平，无关键词时不可判）。
    """
    if not text: return 0, 0.0, "空文本"
    if weird_ratio(text) < min_weird:
        return 0, 0.0, "异常字符比例 %.0f%% < %.0f%%，判为常规字体" % (weird_ratio(text)*100, min_weird*100)
    base, _ = _score(text, 0)
    best = (0, base, 0)
    for sh in range(1, 128):
        sc, d = _score(text, sh)
        if sc > best[1]:
            kw = sum(d.count(k) for k in DETECT_KEYWORDS)
            best = (sh, sc, kw)
    sh, sc, kw = best
    if kw < 1:
        return 0, 0.0, ("解码后无关键词命中（SPA/VIP/SCALE），偏移证据不足——按乱码保留；"
                        "可 render 人工核验后 --force-shift")
    if sc - base < min_gain:
        return 0, 0.0, "增益 %d < %d，不可靠，按原样输出（汉字部分仍乱码）" % (sc - base, min_gain)
    conf = min(1.0, 0.6 + 0.4 * kw / max(1, len(DETECT_KEYWORDS)))
    return sh, round(conf, 2), "偏移 +%d(0x%02X)：关键词命中 %d，字母数字质量 %d→%d" % (sh, sh, kw, base, sc)


def decode(s, shift):
    if not shift: return s
    out = []
    for ch in s:
        v = ord(ch) + shift
        out.append(chr(v) if 0x20 <= v <= 0x7E else ch)
    return "".join(out)


# ---------------------------------------------------------------- texttrace 取层

def page_spans(pg, shiftmap):
    """按 shiftmap 把 texttrace span 还原为文本。"""
    out = []
    for sp in pg.get_texttrace():
        chars = sp.get("chars") or []
        if not chars: continue
        fn = sp.get("font", "?")
        sh = shiftmap.get(fn, 0)
        parts = []
        garbled = False
        for uni, gid, _origin, _bb in chars:
            if uni == FFFD:
                garbled = True
                v = gid + sh if sh else gid
                parts.append(chr(v) if 0x20 <= v <= 0x7E else chr(gid))
            else:
                parts.append(chr(uni))
        x0, y0, x1, y1 = sp["bbox"]
        dx, dy = sp.get("dir", (1.0, 0.0))
        out.append(dict(font=fn, text="".join(parts), garbled=garbled,
                        bbox=sp["bbox"], x=(x0+x1)/2, y=(y0+y1)/2,
                        vert=abs(dy) > 0.5, size=sp.get("size", 10)))
    return out


def page_lines_decoded(pg, shiftmap):
    """texttrace span 按基线 y 聚类成行 → [行文本]"""
    spans = page_spans(pg, shiftmap)
    lines = []
    for s in sorted(spans, key=lambda z: (z["y"], z["x"])):
        tol = max(2.0, 0.5 * s["size"])
        hit = None
        for ln in lines:
            if abs(ln["y"] - s["y"]) <= tol:
                hit = ln; break
        if hit is None:
            hit = dict(y=s["y"], parts=[])
            lines.append(hit)
        hit["parts"].append(s)
    out = []
    for ln in sorted(lines, key=lambda z: z["y"]):
        txt = "".join(p["text"] for p in sorted(ln["parts"], key=lambda z: z["x"])).strip()
        if txt: out.append(txt)
    return out


# ---------------------------------------------------------------- 字体普查

def font_survey(doc, max_pages=15):
    """按字体名聚合「乱码字符」（gid 空间）样本，逐字体探测各自偏移。"""
    sample = {}; spans_n = Counter(); garbled_n = Counter()
    for pno in range(min(max_pages, len(doc))):
        for sp in doc[pno].get_texttrace():
            chars = sp.get("chars") or []
            if not chars: continue
            fn = sp.get("font", "?")
            spans_n[fn] += 1
            g = "".join(chr(gid) for uni, gid, _o, _b in chars if uni == FFFD)
            if g:
                sample.setdefault(fn, "")
                sample[fn] += g
                garbled_n[fn] += len(g)
    out = []
    for fn, c in spans_n.most_common():
        g = sample.get(fn, "")
        wr = weird_ratio(g) if g else 0.0
        if garbled_n[fn] == 0:
            sh, conf, note = 0, 0.0, "无乱码字符（干净字体）"
        elif wr < 0.25:
            sh, conf, note = 0, 0.0, "乱码样本异常字符比例 %.0f%% 过低，证据不足" % (wr*100)
        else:
            sh, conf, note = detect_shift(g)
        out.append(dict(font=fn, spans=c, garbled_chars=garbled_n[fn],
                        sample=g[:40], weird_ratio=round(wr, 3),
                        shift=sh, confidence=conf, note=note))
    return out


def bad_fonts(survey):
    return set(f["font"] for f in survey if f["shift"] > 0)


# ---------------------------------------------------------------- 尺寸提取

NUM_RE = re.compile(r"^\d{2,6}$")

def page_dims(pg, shiftmap=None, minv=50, maxv=60000):
    """文本层取尺寸数字（含乱码字体 gid 解码后的数字）。
       横排 dir=h（量宽度）/ 竖排 dir=v（量高度）"""
    shiftmap = shiftmap or {}
    nums = []
    for sp in page_spans(pg, shiftmap):
        t = sp["text"].strip()
        if not NUM_RE.match(t): continue
        v = int(t)
        if not (minv <= v <= maxv): continue
        nums.append(dict(t=v, x=sp["x"], y=sp["y"], dir="v" if sp["vert"] else "h"))
    return nums


def est_width(nums, tol=4.0):
    """
    由横排尺寸链推定该立面宽度。
    ★ 两种标注形态必须分开处理（否则系统性高估/低估）：
      形态A『分段 + 总值』：最大段 ≈ 其余各段之和 → 最大段就是总值，取 M
      形态B『仅分段』    ：无总值元素 → 取链总和 V
    ★ 二段链（n=2）数学上不可区分（[2600,1240]可能是两段，[3020,1240]可能是
      总值+细部），一律按形态B取和 —— 宁大勿小（低估图纸量会导致错误核减）。
      实测教训：[2600,1240] 真值 3840（和），若误取 2600 将低估 1240。
    ★ 本函数只考察总尺寸最大的链（其余链是更细的子层级）。
    """
    hs = [n for n in nums if n["dir"] == "h"]
    if not hs: return 0, "无横排尺寸"
    g = defaultdict(list)
    for n in hs: g[round(n["y"]/tol)].append(n)
    cands = []
    for _, v in g.items():
        seq = [n["t"] for n in sorted(v, key=lambda z: z["x"])]
        cands.append(dict(n=len(seq), seq=seq, total=sum(seq), mx=max(seq)))
    cands.sort(key=lambda c: -c["total"])
    c = cands[0]
    V, M, n = c["total"], c["mx"], c["n"]
    rest = V - M
    if n >= 3 and abs(M - rest) <= max(0.05 * M, 60):
        return M, "形态A 总值+细部：链%d段 总%d(最大%d≈其余%d) → 取总值%d" % (n, V, M, rest, M)
    return V, "形态B 仅分段/歧义：链%d段 → 宁大勿小取和%d" % (n, V)


def est_height(nums):
    vs = [n["t"] for n in nums if n["dir"] == "v"]
    return max(vs) if vs else 0


# ---------------------------------------------------------------- 房间清单

ROOM_HINT = re.compile(r"(SPA|VIP|间|房|室|厅|区|道|堂)")

def _canon_room(core, keywords=("SPA", "VIP")):
    """房间键规范化：截掉关键词前的图框噪声、截掉编号后的天花图后缀。
       例：'1⭧ḷSPA䰤1' / '1⭧ḷSPA䰤1 ཙ㣡བྷṧമ 1⭧ḷSPA䰤1…' → 'SPA䰤1'
       ★ 关键词并存时（如『VIP SPA间1』）取先出现者，保证同页组归同一间。
       ★ CJK 乱码无法跨字体归一（不同字体 CID 不同），尽力而为；
         takeoff 的页组以 rooms 输出的页号为准。"""
    hits = [(core.find(kw), kw) for kw in keywords if core.find(kw) >= 0]
    if hits:
        i, _kw = min(hits)
        if i > 0:
            core = core[i:]
    m = re.search(r"\d+", core)
    if m:
        core = core[:m.end()]
    return core.strip()


def collect_rooms(doc, shiftmap, keywords=("SPA", "VIP")):
    """返回 OrderedDict: 房名 -> [页号...]"""
    seen = {}
    for pno in range(len(doc)):
        lines = page_lines_decoded(doc[pno], shiftmap)
        hits = []
        for ln in lines:
            if not any(k in ln for k in keywords): continue
            if not ROOM_HINT.search(ln): continue
            # 去掉立面后缀，取房间主体
            core = re.split(r"[ABCD]\s*[・·.、]", ln)[0].strip()
            core = re.sub(r"[・·].*$", "", core).strip()
            if not core: continue
            hits.append(_canon_room(core, keywords))
        for h in dict.fromkeys(hits):
            if not h: continue
            if h not in seen or pno + 1 not in seen[h]:
                seen.setdefault(h, []).append(pno + 1)
    return seen


# ---------------------------------------------------------------- 逐间算量

def room_takeoff(doc, groups, shiftmap, h_net=2.80, h_all=3.10, door_area=1.89, door_w=0.9):
    """
    groups: [(房名, [A页,B页,C页,D页]), ...]  1-based 页号
    开间 = max(A宽, C宽)；进深 = max(B宽, D宽)
    """
    rows = []
    for name, pages in groups:
        ws, notes, H = [], [], 0
        for p in pages:
            if p is None or p < 1 or p > len(doc):
                ws.append(0); notes.append("页缺失"); continue
            nums = page_dims(doc[p-1], shiftmap)
            w, note = est_width(nums)
            ws.append(w); notes.append(note)
            H = max(H, est_height(nums))
        w = max(ws[0], ws[2]) if len(ws) >= 3 else max(ws)
        d = max(ws[1], ws[3]) if len(ws) >= 4 else (ws[1] if len(ws) > 1 else 0)
        area = w * d / 1e6
        peri = 2 * (w + d) / 1000
        rows.append(dict(room=name, pages=pages, w_mm=w, d_mm=d, H_mm=H,
                         area=round(area, 2), perim=round(peri, 2),
                         wall_net=round(peri * h_net - door_area, 2),
                         wall_all=round(peri * h_all - door_area, 2),
                         ceiling=round(area, 2),
                         base=round(peri - door_w, 2),
                         notes=notes))
    return rows


def summarize(rows):
    return dict(
        rooms=len(rows),
        area=round(sum(r["area"] for r in rows), 2),
        perim=round(sum(r["perim"] for r in rows), 2),
        wall_net=round(sum(r["wall_net"] for r in rows), 2),
        wall_all=round(sum(r["wall_all"] for r in rows), 2),
        ceiling=round(sum(r["ceiling"] for r in rows), 2),
        base=round(sum(r["base"] for r in rows), 2),
    )


# ---------------------------------------------------------------- CLI

def build_shiftmap(doc, force=None):
    sv = font_survey(doc)
    sm = {f["font"]: f["shift"] for f in sv}
    if force:
        for f in sv:
            if f["garbled_chars"] > 0:
                sm[f["font"]] = force
    return sm, sv


def cmd_fonts(a):
    doc = fitz.open(a.pdf)
    sv = font_survey(doc, a.max_pages)
    print(json.dumps(dict(pdf=os.path.basename(a.pdf), pages=len(doc), fonts=sv),
                     ensure_ascii=False, indent=1))
    print("\n判定：乱码且已解码字体 → %s；有乱码但证据不足 → %s"
          % (sorted(bad_fonts(sv)) or "无",
             sorted(f["font"] for f in sv if f["garbled_chars"] and f["shift"] == 0) or "无"),
          file=sys.stderr)


def cmd_decode(a):
    doc = fitz.open(a.pdf)
    sm, _ = build_shiftmap(doc, a.force_shift)
    for pno in a.pages:
        if pno > len(doc): continue
        print("—— P%d ——" % pno)
        for ln in page_lines_decoded(doc[pno-1], sm):
            print("   " + ln)


def cmd_rooms(a):
    doc = fitz.open(a.pdf)
    sm, sv = build_shiftmap(doc, a.force_shift)
    kw = tuple(a.keywords.split(",")) if a.keywords else ("SPA", "VIP")
    r = collect_rooms(doc, sm, kw)
    print("=" * 66)
    print("%s：共 %d 页，识别独立房间 %d 个" % (os.path.basename(a.pdf), len(doc), len(r)))
    for k, v in sorted(r.items()):
        print("   %-30s %2d页  %s" % (k, len(v), v[:12]))
    if a.json:
        json.dump({k: v for k, v in r.items()}, open(a.json, "w"), ensure_ascii=False, indent=1)


def cmd_dims(a):
    doc = fitz.open(a.pdf)
    sm, _ = build_shiftmap(doc, a.force_shift)
    for pno in a.pages:
        if pno > len(doc): continue
        nums = page_dims(doc[pno-1], sm)
        w, note = est_width(nums)
        print("P%-4d 宽=%-6d (%s)  高=%d" % (pno, w, note, est_height(nums)))


def cmd_takeoff(a):
    doc = fitz.open(a.pdf)
    sm, _ = build_shiftmap(doc, a.force_shift)
    groups = []
    for seg in a.spec.split(";"):
        seg = seg.strip()
        if not seg: continue
        name, _, ps = seg.partition(":")
        pages = [int(x) if x.strip() and x.strip() != "-" else None
                 for x in ps.split(",")]
        groups.append((name.strip(), pages))
    rows = room_takeoff(doc, groups, sm, a.h_net, a.h_all, a.door_area, a.door_w)
    print("=" * 100)
    print("%-12s %8s %8s %8s %8s %9s %9s %8s %8s" %
          ("房名", "开间mm", "进深mm", "层高mm", "面积㎡", "周长m", "墙面㎡净", "天花㎡", "地脚线m"))
    for r in rows:
        print("%-12s %8d %8d %8d %8.2f %9.2f %9.2f %8.2f %8.2f" %
              (r["room"], r["w_mm"], r["d_mm"], r["H_mm"], r["area"], r["perim"],
               r["wall_net"], r["ceiling"], r["base"]))
    s = summarize(rows)
    print("-" * 100)
    print("合计：房间 %d 间 | 面积 %.2f㎡ | 周长 %.2fm | 墙面(净高) %.2f㎡ | 墙面(到顶) %.2f㎡ | 天花 %.2f㎡ | 地脚线 %.2fm"
          % (s["rooms"], s["area"], s["perim"], s["wall_net"], s["wall_all"], s["ceiling"], s["base"]))
    if a.json:
        json.dump(dict(rows=rows, summary=s), open(a.json, "w"), ensure_ascii=False, indent=1)
        print("→ 已写 %s" % a.json)


def cmd_render(a):
    """截取匹配文本的原图区域（人工核验解码是否正确：解码猜得对不对，渲染一看便知）"""
    doc = fitz.open(a.pdf)
    sm, _ = build_shiftmap(doc, a.force_shift)
    os.makedirs(a.out, exist_ok=True)
    n = 0
    for pno in a.pages:
        if pno > len(doc): continue
        for sp in page_spans(doc[pno-1], sm):
            if a.match in sp["text"]:
                r = fitz.Rect(sp["bbox"]) + (-24, -18, 24, 18)
                fp = os.path.join(a.out, "P%03d_%02d.png" % (pno, n))
                doc[pno-1].get_pixmap(clip=r, dpi=360).save(fp)
                print("%s  ← %r" % (fp, sp["text"][:40]))
                n += 1
                if n >= a.limit: return


def cmd_demo(a):
    print("=" * 72)
    print("cadpdf_room_decode 自检（内置样例，不依赖外部 PDF）")
    print("=" * 72)

    # 1) 偏移探测：真实乱码样本（CASE-B 立面图 NSimSun gid 空间样本片段）
    raw = ("⭧ḷ63$䰤\x14 $・䶒　⭧ḷ63$䰤\x15 %・䶒　"
           "    6&$/(    ∄ֻ    \x14\x1d\x18\x13　"
           "ྣᇮ9,3 63$䰤\x14 $・䶒　䰤\x19ཙ㣡བྷṧമ")
    sh, conf, note = detect_shift(raw)
    ok1 = (sh == 29)
    print("\n[1] 偏移探测（有关键词样本）")
    print("    探测 : shift=%d (0x%02X) 置信度=%.2f  %s" % (sh, sh, conf, note))
    print("    解码 : %s" % decode(raw, sh))
    print("    %s 期望 29；63$→SPA、9,3→VIP、6&$/(→SCALE、\\x14\\x1d\\x18\\x13→1:50" % ("✅" if ok1 else "❌"))

    # 2) 无关键词样本 → 老实拒绝（MSYH 标题栏 26/29 打平，不可判）
    msyh = "ЅԨڴ厲ם⨝'\u05c8\x1aك\x03" * 6      # 真实乱码样本（脱敏：某大厦A塔4层，案件码 CASE-A）
    sh2, conf2, note2 = detect_shift(msyh)
    ok2 = (sh2 == 0)
    print("\n[2] 无关键词样本拒绝硬猜  %s（shift 应为 0；26/29 评分打平，不可判）" % ("✅" if ok2 else "❌"))
    print("    说明 : %s" % note2)

    # 3) 干净 span 免疫：字体有偏移，但 texttrace 无 U+FFFD 的 span 不动
    clean_chars = [(ord(c), (ord(c) + 5) % 30000, (0, 0), (0, 0, 0, 0)) for c in "2026.6L-01"]
    parts = []
    for uni, gid, _o, _b in clean_chars:
        v = gid + 29 if uni == FFFD else None
        parts.append(chr(v) if v is not None and 0x20 <= v <= 0x7E else chr(uni))
    ok3 = ("".join(parts) == "2026.6L-01")
    print("\n[3] 干净 span 免疫（uni≠FFFD 按原字符，gid 噪声不参与）  %s" % ("✅" if ok3 else "❌"))

    # 4) 尺寸链两种形态（含 CASE-B 真实回归样例）
    cases = [
        ("仅二段(真实P10)", [dict(t=2600, x=10, y=5, dir="h"), dict(t=1240, x=90, y=5, dir="h")], 3840),
        ("仅三段(真实P12)", [dict(t=2740, x=10, y=5, dir="h"), dict(t=600, x=90, y=5, dir="h"),
                            dict(t=600, x=170, y=5, dir="h")], 3940),
        ("分段+总值", [dict(t=1500, x=10, y=5, dir="h"), dict(t=1520, x=90, y=5, dir="h"),
                      dict(t=3020, x=50, y=5, dir="h")], 3020),
        ("二段近似歧义", [dict(t=1500, x=10, y=5, dir="h"), dict(t=1520, x=90, y=5, dir="h")], 3020),
    ]
    ok4 = True
    print("\n[4] 尺寸链形态判别")
    for tag, nums, exp in cases:
        w, n1 = est_width(nums)
        flag = "✅" if w == exp else "❌"
        ok4 &= (w == exp)
        print("    %-12s → %-6d 期望%-6d %s (%s)" % (tag, w, exp, flag, n1[:36]))
    print("    ★ 二段链一律取和（宁大勿小）：低估图纸量会导致错误核减")

    # 5) 逐间算量：模拟 3 间房
    print("\n[5] 逐间算量逻辑（模拟 3 间，非真实图纸）")
    mock = [("模拟房A", [3490, 3370, 3100]), ("模拟房B", [3020, 2600, 3100]),
            ("模拟房C", [4225, 2820, 3100])]
    tot_area = tot_peri = tot_wall = 0.0
    for nm, (w, d, H) in mock:
        area = w*d/1e6; peri = 2*(w+d)/1000; wall = peri*2.8 - 1.89
        tot_area += area; tot_peri += peri; tot_wall += wall
        print("    %-8s %5dx%-5d 面积%6.2f㎡ 周长%6.2fm 墙面(净高)%7.2f㎡" % (nm, w, d, area, peri, wall))
    print("    合计 面积 %.2f㎡ 周长 %.2fm 墙面 %.2f㎡" % (tot_area, tot_peri, tot_wall))
    ok5 = abs(tot_wall - (tot_peri*2.8 - 1.89*3)) < 0.01

    # 6) 教训自检
    print("\n[6] ★ 纪律自检")
    print("    ① 房名解码失败时，禁止直接判『图纸查无』并核减 —— 必须标注待现场核实。")
    print("      （反面案例：某案误判 3 间房图纸查无，核减 11,857.74 元，解码后证实全部存在）")
    print("    ② 同一文档各嵌入字体偏移可不同（实测 NSimSun=29、MicrosoftYaHei=26 皆真值），")
    print("       禁止用『全文统一偏移』假设互相对表；证据不足按乱码保留，render 人工核验。")

    allok = ok1 and ok2 and ok3 and ok4 and ok5
    print("\n" + ("✅ demo 全部通过" if allok else "❌ demo 存在失败项"))
    return 0 if allok else 1


def main():
    p = argparse.ArgumentParser(description="CAD导出PDF 房名解码 + 逐间算量（gid真值版）")
    sub = p.add_subparsers(dest="cmd", required=True)

    f = sub.add_parser("fonts", help="字体普查与偏移探测")
    f.add_argument("--pdf", required=True); f.add_argument("--max-pages", type=int, default=15)
    f.set_defaults(func=cmd_fonts)

    d = sub.add_parser("decode", help="解码指定页")
    d.add_argument("--pdf", required=True)
    d.add_argument("--pages", type=int, nargs="+", required=True)
    d.add_argument("--force-shift", type=int, default=0)
    d.set_defaults(func=cmd_decode)

    r = sub.add_parser("rooms", help="房间清单统计")
    r.add_argument("--pdf", required=True)
    r.add_argument("--keywords", default="SPA,VIP")
    r.add_argument("--force-shift", type=int, default=0)
    r.add_argument("--json")
    r.set_defaults(func=cmd_rooms)

    m = sub.add_parser("dims", help="提取尺寸")
    m.add_argument("--pdf", required=True); m.add_argument("--pages", type=int, nargs="+", required=True)
    m.add_argument("--force-shift", type=int, default=0)
    m.set_defaults(func=cmd_dims)

    t = sub.add_parser("takeoff", help="逐间算量")
    t.add_argument("--pdf", required=True)
    t.add_argument("--spec", required=True,
                   help='房名:A页,B页,C页,D页;房名2:...  例 "SPA间1:9,10,11,12;SPA间2:15,16,17,18"')
    t.add_argument("--h-net", type=float, default=2.80)
    t.add_argument("--h-all", type=float, default=3.10)
    t.add_argument("--door-area", type=float, default=1.89)
    t.add_argument("--door-w", type=float, default=0.9)
    t.add_argument("--force-shift", type=int, default=0)
    t.add_argument("--json")
    t.set_defaults(func=cmd_takeoff)

    rr = sub.add_parser("render", help="截取匹配文本原图（人工核验解码）")
    rr.add_argument("--pdf", required=True)
    rr.add_argument("--pages", type=int, nargs="+", required=True)
    rr.add_argument("--match", required=True, help="解码后文本包含即截取")
    rr.add_argument("--out", default="render_out")
    rr.add_argument("--limit", type=int, default=6)
    rr.add_argument("--force-shift", type=int, default=0)
    rr.set_defaults(func=cmd_render)

    z = sub.add_parser("demo", help="内置样例自检"); z.set_defaults(func=cmd_demo)

    a = p.parse_args()
    sys.exit(a.func(a) or 0)


if __name__ == "__main__":
    main()
