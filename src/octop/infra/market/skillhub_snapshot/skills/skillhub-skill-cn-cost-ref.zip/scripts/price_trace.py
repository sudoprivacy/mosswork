#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
price_trace.py — 价格溯源脚本（材料价格 → 来源链 + 置信度 + 效力）

定位：material_price_lookup.py 解决"查到价"；本脚本解决"查到的价凭什么信"——
在审单价核减、应对二次审核、报价取价依据时，把一条价格还原成
「价格本身 + 来源链(可溯源批次) + 置信度 + 效力评级 + 证据建议」，
并联动 policy-basis 的效力基线(policy_files.json)，守住反幻觉纪律。

与六层证据效力衔接(material-evidence-chain.md)：
  信息价税前(S级上) > 市场资讯区间(证据力约D询价级,须标注区间) > 内部实战核价(内部参考,非外部三单)
本脚本把价库每条的 置信度 映射到六级证据档，供审计取用。

⚠️ 数据纪律：
  - 每条价须带 source_id 关联 meta.source_batches，才能展开来源链；缺 source_id 只标 待补溯源；
  - 效力评级分三档：可核 / 市场核 / 待补；凡"经验估/拿不准"一律落 待补，不冒充权威；
  - 涉及检测费等受政策基线约束的价格，联动 policy_files.json 提示"该依据现行状态"。

数据源：scripts/data/material_prices.json、scripts/data/policy_files.json(可选)
用法：
    python3 price_trace.py trace <材料|类别|规格> [--period 2026-03] [--region 广州]
        → 打印每条命中价的 价格/口径/置信度/来源链/source_id/效力评级/证据档
    python3 price_trace.py source <批次ID>        → 展开某个来源批次(如 GZJS202603) 完整元信息
    python3 price_trace.py batches                 → 列出全部来源批次(meta.source_batches)
    python3 price_trace.py evidence <材料> [--region 广州]
        → 汇总该材料各期在"证据力"维度的最佳可用证据与建议(是否可直接作核减依据)
"""
import json, os, sys, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data', 'material_prices.json')
POLICY = os.path.join(HERE, 'data', 'policy_files.json')

# 置信度 → 六层证据档 映射（对齐 material-evidence-chain.md 的 S~E 六级）
#   可核(S~A级权威信息价) / 市场核(D级市场询价,需标区间) / 其余落 待补
EVIDENCE_LEVEL = {
    '可核':   {'档': 'S-A', 'level': 'A', 'label': '权威信息价(可作核减依据,证据力高)',
               'usable': '可直接作为当期信息价核减依据(同口径可比时)'},
    '市场核': {'档': 'D',   'level': 'D', 'label': '市场资讯/询价区间(证据力中,须标注为区间)',
               'usable': '作为市场询价参考,与信息价交叉印证;若作核减须取区间合理值与对方争议'},
    '经验估': {'档': 'E',   'level': 'E', 'label': '经验估算(证据力弱,仅内部估算)',
               'usable': '只能内部估算参考,对外作核减/报价须先补齐来源证据'},
    '待补':   {'档': '—',   'level': 'X', 'label': '缺来源/待补溯源(证据力未知)',
               'usable': '不可直接作为依据,先走 material_price_update 补齐四要素来源再取用'},
}

# 来源批次 → 关联政策基线关键词（用于联动 policy_files.json 提示效力）
POLICY_HINT = {
    '造价站信息价': ['GB/T 50500—2024', 'GB/T 50854—2024', '建标〔2013〕44号'],
    '市场报价':     [],
    '实战核价':     [],
}


def load_json(path, required=True):
    if not os.path.exists(path):
        if required:
            sys.exit(f'[x] 文件缺失: {path}')
        return None
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def flatten(d):
    out = []
    for cat, catinfo in d['materials'].items():
        for spec, sinfo in (catinfo.get('specs') or {}).items():
            unit = sinfo.get('单元', '')
            for p in sinfo.get('periods', []):
                out.append(dict(cat=cat, spec=spec, unit=unit,
                                name=f"{cat}·{spec}", **p))
    return out


def hit(r, kw, region=None):
    k = kw.lower()
    fields = [r['cat'], r['spec'], r['name'], str(r.get('来源', ''))]
    if region and r.get('计价地区', '') != region:
        return False
    return any(k in str(x).lower() for x in fields)


# ------------------------------------------------- 效力评级
def rate(r, batches):
    """给单条价记录评级：返回 (效力档, source_id, batch元信息 或 None)"""
    sid = r.get('source_id')
    if not sid or sid.startswith('UNKNOWN') or '待补' in str(sid):
        return '待补', sid, None
    batch = (batches or {}).get(sid)
    if not batch:
        # source_id 指向未登记批次 → 溯源断裂
        return '待补', sid, None
    rel = batch.get('reliability')
    if rel == '可核':
        return '可核', sid, batch
    if rel == '市场核':
        return '市场核', sid, batch
    return '待补', sid, batch


def evidence_brief(level):
    ev = EVIDENCE_LEVEL.get(level, EVIDENCE_LEVEL['待补'])
    return ev


def policy_linked(batch):
    """根据来源批次类型提示关联政策基线(存在则给效力,否则为空)"""
    st = (batch or {}).get('source_type', '')
    hints = POLICY_HINT.get(st, [])
    pol = load_json(POLICY, required=False)
    if not pol or not hints:
        return []
    by = {p.get('doc_no'): p for p in pol.get('policies', [])}
    out = []
    for h in hints:
        if h in by:
            out.append(by[h])
    return out


# ------------------------------------------------- 命令
def cmd_batches(d, a):
    batches = d.get('meta', {}).get('source_batches', {})
    if not batches:
        print('\n（meta 尚无 source_batches——价库未做来源规范化，请先跑 upgrade_source_trace.py）')
        return
    print('\n=== 价库来源批次（meta.source_batches）===')
    for sid, b in batches.items():
        print(f"\n  [{sid}] {b.get('desc','')}")
        print(f"     source_type={b.get('source_type')}  issuer={b.get('issuer')}")
        print(f"     期号={b.get('period')} 地区={b.get('region')} 口径={b.get('caliber')}")
        print(f"     reliability={b.get('reliability')}  {b.get('source_note','')}")


def cmd_source(d, a):
    batches = d.get('meta', {}).get('source_batches', {})
    b = batches.get(a.sid)
    if not b:
        print(f'\n[x] 未登记来源批次: {a.sid}（可选: {"、".join(batches.keys()) if batches else "无"}）')
        return
    print(f"\n=== 来源批次 [{a.sid}] ===")
    for k, v in b.items():
        print(f"  {k:<14}: {v}")
    # 归属价记录
    flat = [r for r in flatten(d) if r.get('source_id') == a.sid]
    print(f"\n  归属价记录 {len(flat)} 条：")
    for r in sorted(flat, key=lambda x: (x['cat'], x['spec'], x.get('期号',''))):
        print(f"    · {r['name']}  {r.get('期号')}  {r['价格']:>10,.2f} 元/{r.get('unit','')}")


def _print_trace(r, batches):
    cat, spec = r['cat'], r['spec']
    unit = r.get('unit', '')
    price = r['价格']
    lvl, sid, batch = rate(r, batches)
    ev = evidence_brief(lvl)
    print(f"\n  ■ {cat}·{spec}（{unit}） 期号 {r.get('期号')}  地区 {r.get('计价地区')}")
    print(f"     价格     : {price:,.2f} 元/{unit}  [口径 {r.get('口径')}]")
    print(f"     置信度   : {r.get('置信度')}")
    print(f"     效力评级 : {lvl}  ← {ev['label']}")
    print(f"     证据档   : 第{ev['档']}级 | 建议: {ev['usable']}")
    if sid and batch:
        print(f"     来源链   : source_id={sid} → {batch.get('desc','')}")
        print(f"               issuer={batch.get('issuer')}  reliability={batch.get('reliability')}")
        print(f"               备注: {batch.get('source_note','')}")
    else:
        print(f"     来源链   : ⚠ 无有效 source_id / 批次断裂（{sid or '缺失'}）→ 标 待补溯源，先补来源再取用")
    # 政策基线联动
    linked = policy_linked(batch)
    if linked:
        for p in linked:
            flag = '✅' if p.get('status') == '现行' else ('⚠️' if '废止' in str(p.get('status')) else '❓')
            print(f"     效力闸   : {flag} {p.get('doc_no')} {p.get('title')} — {p.get('status')}")
    else:
        print(f"     效力闸   : (本来源无直接绑定政策基线，属市场/实战口径，不与文件号捆绑)")


def cmd_trace(d, a):
    rows = [r for r in flatten(d) if hit(r, a.kw, a.region)]
    if a.period:
        rows = [r for r in rows if r.get('期号') == a.period]
    batches = d.get('meta', {}).get('source_batches', {})
    rows.sort(key=lambda x: (x['cat'], x['spec'], x.get('期号', '')))
    print(f'\n价格溯源「{a.kw}」命中 {len(rows)} 条')
    if not rows:
        print('  （未命中。请换关键词/类别/规格，或用 meta 看类别清单）')
        return
    for r in rows:
        _print_trace(r, batches)


def cmd_evidence(d, a):
    """汇总某材料在证据维度的最佳可用证据（供审价核减判断）"""
    rows = [r for r in flatten(d) if hit(r, a.kw, a.region)]
    if not rows:
        print(f'\n「{a.kw}」未命中，无法给证据汇总。')
        return
    batches = d.get('meta', {}).get('source_batches', {})
    best = {}
    for r in rows:
        key = r['name']
        lvl, _, batch = rate(r, batches)
        # 证据优先序: 可核 > 市场核 > 待补
        order = {'可核': 0, '市场核': 1, '经验估': 2, '待补': 3}
        if key not in best or order.get(lvl, 3) < order.get(best[key][0], 3):
            best[key] = (lvl, r, batch)
    print(f'\n=== 「{a.kw}」审价核减证据汇总 ===')
    for name, (lvl, r, batch) in sorted(best.items()):
        ev = evidence_brief(lvl)
        period = r.get('期号')
        print(f"\n  {name}  最佳可用证据（{period} {r.get('计价地区')} {r.get('口径')}）")
        print(f"     价格 {r['价格']:,.2f} 元/{r.get('unit','')} | 效力={lvl}(第{ev['档']}级) | {ev['label']}")
        print(f"     建议: {ev['usable']}")
    print('\n  提示：')
    print('    · 仅"可核"(权威信息价)可直接作审价核减基准；市场核须取区间合理值并与对方争议；')
    print('    · 若需对外核减/报价，证据链还应落到材料价证据链六级(material-evidence-chain.md)；')
    print('    · 涉检测费/计价规范取费依据时，先过 policy-basis 效力闸，别引废止文件。')


def main():
    p = argparse.ArgumentParser(description='材料价格溯源：价格 → 来源链+置信度+效力评级（联动政策效力基线）')
    sub = p.add_subparsers(dest='cmd')
    sub.add_parser('batches', help='列出全部来源批次')
    s2 = sub.add_parser('source', help='展开某来源批次元信息'); s2.add_argument('sid')
    t = sub.add_parser('trace', help='价格溯源（材料+期号）')
    t.add_argument('kw'); t.add_argument('--period', default=None); t.add_argument('--region', default=None)
    e = sub.add_parser('evidence', help='审价核减证据汇总')
    e.add_argument('kw'); e.add_argument('--region', default=None)

    a = p.parse_args()
    if not a.cmd:
        p.print_help(); return
    d = load_json(DATA)
    {'batches': cmd_batches, 'source': cmd_source,
     'trace': cmd_trace, 'evidence': cmd_evidence}[a.cmd](d, a)


if __name__ == '__main__':
    main()
