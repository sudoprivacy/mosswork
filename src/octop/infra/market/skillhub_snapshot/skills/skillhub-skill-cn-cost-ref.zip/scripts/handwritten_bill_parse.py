#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
handwritten_bill_parse.py — 手写结算单/量单 结构化与交叉校验
==============================================================================
适用场景：承包人交来的是**手写**结算单（照片/扫描件），需要先变成结构化数据
再核算。本脚本解决三件事：
  1) 手写OCR结果的清洗与结构化（把 OCR 的坐标框文本，按行/列还原成表格）
  2) 三层级钩稽：明细 量×单价 = 金额 → 房间小计 → 页小计，逐层找出断裂
  3) 争议数字定位：标出置信度低/算术不闭合的位置，供人工放大复核

⚠️ 重要纪律（反幻觉）：
  - 手写单 **仅为承包人自行统计，不得作为计量依据**（须以图纸/竣工图为准）。
    本脚本的产出是「乙方主张值」，用于与图纸算量结果**交叉校验**，不是核定值。
  - OCR 置信度低的数字一律标注，**不得默认为真**，须放大复核后再用。
  - 算术闭合 ≠ 数据真实。闭合只说明"内部自洽"，不代表工程量正确。

依赖：标准库（无第三方依赖；OCR 由外部 RapidOCR/其他引擎产出 JSON 后喂入）

子命令：
  ingest   把手写OCR结果按坐标还原成结构化表格
  tie      三层级钩稽（明细→小计→页小计），列出所有不闭合处
  review   汇总需人工复核的争议数字（低置信度 + 不闭合）
  demo     内置样例自检
"""
import os
import re
import sys
import json
import argparse
from collections import defaultdict


# ----------------------------------------------------------------------------
# 1. ingest —— OCR 坐标框 → 结构化表格
# ----------------------------------------------------------------------------
NUM_RE = re.compile(r"^\d+(?:\.\d+)?$")


def _norm_num(s):
    """把OCR常见的噪声字符清掉，尝试转数字。失败返回 None。"""
    if s is None:
        return None
    t = str(s).strip()
    t = t.replace("O", "0").replace("o", "0").replace("l", "1").replace("I", "1")
    t = t.replace("，", "").replace(",", "").replace(" ", "")
    t = t.replace("元", "").replace("㎡", "").replace("m2", "")
    try:
        return float(t)
    except ValueError:
        return None


def ingest(ocr, row_tol=8.0, min_conf=0.5):
    """把 OCR 结果还原成结构化行。

    ocr: [{"t":"文本","s":0.98,"x":123.4,"y":56.7}, ...]   # x/y 为文本框中心
    返回 rows: [{"y":行中心, "cells":[{"t":..,"x":..,"s":..}], "texts":[..]}]
    """
    items = []
    for it in ocr:
        t = str(it.get("t", "")).strip()
        if not t:
            continue
        s = float(it.get("s", 1.0))
        if s < min_conf:
            continue
        items.append({"t": t, "s": s, "x": float(it["x"]), "y": float(it["y"])})
    if not items:
        return []

    # 按 y 聚类成行
    items.sort(key=lambda r: r["y"])
    rows, cur = [], [items[0]]
    for r in items[1:]:
        if r["y"] - cur[-1]["y"] <= row_tol:
            cur.append(r)
        else:
            rows.append(cur); cur = [r]
    rows.append(cur)

    out = []
    for g in rows:
        g.sort(key=lambda r: r["x"])
        out.append({
            "y": round(sum(r["y"] for r in g) / len(g), 2),
            "cells": [{"t": r["t"], "x": round(r["x"], 2), "s": round(r["s"], 3)} for r in g],
            "texts": [r["t"] for r in g],
        })
    return out


def rows_to_records(rows, mode="auto"):
    """从结构化行里抽出「名称 + 数量 + 单价 + 金额」的候选记录。

    ★ 两种形态（实战教训，务必区分）：
      (1) **分列表格式**（机打/表格）：一行有多个**独立数字格** → 按出现顺序解读
          为 [数量, 单价, 金额]。
      (2) **行内算式体**（手写单最常见）：一行是**整串文本**，形如
          「执天：17.43×120元=2088元」「T槽：9.6米×40元=384元」
          → 必须用**正则解析算式**，不能按列切分（OCR 把手写整行识别成一串）。
    本函数 mode="auto" 时自动判别：行内出现 '=' 或 '×'/'X'/'x' 即走算式解析。
    """
    recs = []
    for r in rows:
        # ---- 优先尝试"行内算式"解析 ----
        whole = " ".join(c["t"] for c in r["cells"])
        low_conf = [c["t"] for c in r["cells"] if c["s"] < 0.75]
        eq = _parse_equation(whole)
        if eq:
            eq.update({"y": r["y"], "low_conf": low_conf, "raw_line": whole})
            recs.append(eq)
            continue

        # ---- 回退：分列表格式 ----
        nums, names = [], []
        for c in r["cells"]:
            v = _norm_num(c["t"])
            if v is not None and NUM_RE.match(c["t"].replace("O", "0").replace("o", "0")):
                nums.append({"v": v, "x": c["x"], "s": c["s"], "raw": c["t"]})
            elif len(c["t"]) >= 2:
                names.append(c["t"])
        if len(nums) < 2:
            continue
        name = max(names, key=len) if names else ""
        qty = nums[0]["v"]
        price = nums[1]["v"] if len(nums) >= 2 else None
        amount = nums[2]["v"] if len(nums) >= 3 else None
        recs.append({
            "y": r["y"], "name": name, "qty": qty, "price": price, "amount": amount,
            "calc": (round(qty * price, 2) if price is not None else None),
            "closed": (None if (amount is None or price is None)
                       else abs(round(qty * price, 2) - amount) < 0.01),
            "low_conf": low_conf,
            "raw_nums": [n["raw"] for n in nums],
            "raw_line": whole,
        })
    return recs


# 行内算式解析：形如「执天：17.43×120元=2088元」「T槽：9.6米×40元=384元」
# 兼容 OCR 常见误读：× 被读成 X/x/又/×、= 被读成 =/二/一
_EQ_RE = re.compile(
    r"(?P<name>[^\d\s]{0,12})"          # 名称（算式前的非数字内容）
    r"[:：]?\s*"
    r"(?P<qty>\d+(?:\.\d+)?)\s*[米㎡mM]?\s*"
    r"[×xX*又]\s*"
    r"(?P<price>\d+(?:\.\d+)?)\s*元?\s*"
    r"[=＝二]\s*"
    r"(?P<amount>\d+(?:\.\d+)?)\s*元?"
)


def _parse_equation(text):
    """解析行内算式「数量×单价=金额」。返回 None 表示不是算式行。"""
    if not re.search(r"[=＝]|[×xX\*又]", text):
        return None
    m = _EQ_RE.search(text)
    if not m:
        return None
    name = (m.group("name") or "").strip(" :：")
    qty = float(m.group("qty"))
    price = float(m.group("price"))
    amount = float(m.group("amount"))
    calc = round(qty * price, 2)
    return {
        "name": name, "qty": qty, "price": price, "amount": amount,
        "calc": calc,
        # 手写单价常取整（如 70 元），量含小数时算式本身可能"不闭合"，
        # 容差放到 1 元（手写四舍五入的常见幅度）
        "closed": abs(calc - amount) < 1.0,
        "raw_nums": [m.group("qty"), m.group("price"), m.group("amount")],
    }


# ----------------------------------------------------------------------------
# 2. tie —— 三层级钩稽
# ----------------------------------------------------------------------------
def three_level_tie(pages):
    """三层级钩稽：明细 → 房间小计 → 页小计。

    pages: [{"page":"img10",
             "details":[{"room":"男标SPA间1","amount":753.6}, ...],
             "room_subtotals":{"男标SPA间1":1313.6},
             "page_subtotal":1832.0}]
    """
    report = []
    for p in pages:
        pg = p["page"]
        detail_by_room = defaultdict(float)
        for d in p.get("details", []):
            detail_by_room[d.get("room", "_")] += float(d.get("amount") or 0)

        issues = []
        # L1: 房间小计 vs 明细相加
        for room, stated in (p.get("room_subtotals") or {}).items():
            calc = round(detail_by_room.get(room, 0.0), 2)
            stated = float(stated)
            if abs(calc - stated) >= 0.01:
                issues.append({
                    "level": "L1 房间小计", "room": room,
                    "calc": calc, "stated": stated,
                    "diff": round(calc - stated, 2),
                    "meaning": "明细相加≠小计；差额为正=小计虚增（应核减），为负=小计少计",
                })
        # L2: 页小计 vs 房间小计之和
        stated_page = p.get("page_subtotal")
        if stated_page is not None:
            sum_rooms = round(sum(float(v) for v in (p.get("room_subtotals") or {}).values()), 2)
            if not p.get("room_subtotals"):
                sum_rooms = round(sum(detail_by_room.values()), 2)
            stated_page = float(stated_page)
            if abs(sum_rooms - stated_page) >= 0.01:
                issues.append({
                    "level": "L2 页小计", "room": "（整页）",
                    "calc": sum_rooms, "stated": stated_page,
                    "diff": round(sum_rooms - stated_page, 2),
                    "meaning": "房间小计之和≠页小计，或存在未进页小计的明细项（反向敞口）",
                })
        report.append({"page": pg, "detail_sum": round(sum(detail_by_room.values()), 2),
                       "room_count": len(p.get("room_subtotals") or {}),
                       "issues": issues})
    return report


# ----------------------------------------------------------------------------
# 3. review —— 汇总需人工复核项
# ----------------------------------------------------------------------------
def review(recs, tie_report, conf_threshold=0.75):
    low = [{"name": r["name"], "raw_nums": r["raw_nums"], "low_conf": r["low_conf"],
            "y": r["y"]} for r in recs if r["low_conf"]]
    unclosed = [{"name": r["name"], "qty": r["qty"], "price": r["price"],
                 "amount": r["amount"], "calc": r["calc"], "y": r["y"]}
                for r in recs if r["closed"] is False]
    tie_issues = []
    for p in tie_report:
        for i in p["issues"]:
            tie_issues.append({"page": p["page"], **i})

    # diff = 重算值 - 单据值：
    #   diff < 0 → 单据写多了（小计虚增）→ 应核减
    #   diff > 0 → 单据写少了（少计）→ 对甲方无不利，但须书面定性防事后补报
    total_gap = sum(-i["diff"] for i in tie_issues if i["diff"] < 0)
    return {
        "low_confidence_digits": low,
        "unclosed_lines": unclosed,
        "tie_issues": tie_issues,
        "summary": {
            "低置信度数字": len(low),
            "行内不闭合": len(unclosed),
            "三层级不闭合": len(tie_issues),
            "小计虚增合计": round(total_gap, 2),
        },
        "discipline": "手写单仅为承包人自行主张；上述复核项须回原图放大确认，"
                      "不得直接作为核定值。计量一律以图纸/竣工图为准。",
    }


# ----------------------------------------------------------------------------
# demo
# ----------------------------------------------------------------------------
def demo():
    print("── demo：手写单结构化与三层级钩稽 ──\n")

    # 模拟 OCR 输出（含一个低置信度数字与一处不闭合）
    ocr = [
        {"t": "男标SPA间1", "s": 0.97, "x": 40, "y": 100},
        {"t": "吊顶", "s": 0.95, "x": 120, "y": 100},
        {"t": "12.56", "s": 0.93, "x": 220, "y": 100},
        {"t": "60", "s": 0.96, "x": 280, "y": 100},
        {"t": "753.6", "s": 0.91, "x": 340, "y": 100},
        {"t": "毛坯墙板", "s": 0.94, "x": 120, "y": 118},
        {"t": "20.00", "s": 0.68, "x": 220, "y": 118},   # 低置信度
        {"t": "28", "s": 0.95, "x": 280, "y": 118},
        {"t": "560.0", "s": 0.90, "x": 340, "y": 118},
    ]
    rows = ingest(ocr)
    recs = rows_to_records(rows)
    print(f"[1] ingest：{len(ocr)} 个文本框 → {len(rows)} 行 → {len(recs)} 条记录")
    for r in recs:
        flag = "⚠低置信" if r["low_conf"] else ""
        print(f"    {r['name']:<10} {r['qty']}×{r['price']}={r['calc']}  "
              f"单据{r['amount']} 闭合={r['closed']} {flag}")

    tie = three_level_tie([{
        "page": "img10",
        "details": [{"room": "男标SPA间1", "amount": 753.6},
                    {"room": "男标SPA间1", "amount": 560.0}],
        "room_subtotals": {"男标SPA间1": 1313.6},
        "page_subtotal": 1313.6,
    }, {
        "page": "img20",
        "details": [{"room": "女宾SPA间8", "amount": 600.0}],
        "room_subtotals": {"女宾SPA间8": 680.0},   # 虚增 80
        "page_subtotal": 680.0,
    }])
    print(f"\n[2] tie：{len(tie)} 页钩稽")
    for p in tie:
        tag = "✅闭合" if not p["issues"] else f"❌{len(p['issues'])}处不闭合"
        print(f"    {p['page']}  明细合计 {p['detail_sum']}  {tag}")
        for i in p["issues"]:
            print(f"       └ {i['level']} {i['room']}: 重算 {i['calc']} vs 单据 {i['stated']} "
                  f"→ 差 {i['diff']}")

    rv = review(recs, tie)
    print(f"\n[3] review：{rv['summary']}")
    print(f"\n✅ demo 通过 —— 结构化/钩稽/复核链路可用。")


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="手写结算单结构化与三层级钩稽")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("ingest", help="OCR结果→结构化表格")
    p.add_argument("--ocr", required=True, help="OCR JSON")
    p.add_argument("--out", default=None)
    p.add_argument("--row-tol", type=float, default=8.0)
    p.add_argument("--min-conf", type=float, default=0.5)

    p = sub.add_parser("tie", help="三层级钩稽")
    p.add_argument("--pages", required=True)

    p = sub.add_parser("review", help="汇总人工复核项")
    p.add_argument("--ocr", required=True)
    p.add_argument("--pages", required=True)

    sub.add_parser("demo", help="内置样例自检")

    args = ap.parse_args()
    if args.cmd == "ingest":
        ocr = json.load(open(args.ocr, encoding="utf-8"))
        rows = ingest(ocr, args.row_tol, args.min_conf)
        recs = rows_to_records(rows)
        res = {"rows": len(rows), "records": recs}
        if args.out:
            json.dump(res, open(args.out, "w", encoding="utf-8"),
                      ensure_ascii=False, indent=2)
        print(json.dumps(res, ensure_ascii=False, indent=2)[:3000])
    elif args.cmd == "tie":
        print(json.dumps(three_level_tie(json.load(open(args.pages, encoding="utf-8"))),
                         ensure_ascii=False, indent=2))
    elif args.cmd == "review":
        ocr = json.load(open(args.ocr, encoding="utf-8"))
        pages = json.load(open(args.pages, encoding="utf-8"))
        recs = rows_to_records(ingest(ocr))
        print(json.dumps(review(recs, three_level_tie(pages)),
                         ensure_ascii=False, indent=2))
    elif args.cmd == "demo":
        demo()


if __name__ == "__main__":
    main()
