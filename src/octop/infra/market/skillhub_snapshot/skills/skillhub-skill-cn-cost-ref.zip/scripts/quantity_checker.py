#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
算量校验辅助工具 (Quantity Checker)
=====================================
用于造价工程师在提取CAD图纸数据后，快速校验算量结果的合理性。

作者: QClaw Assistant
版本: 1.0.0
更新: 2026-08-15

功能模块：
1. 钢筋理论重量计算
2. 箍筋根数计算
3. 锚固/搭接长度校验
4. 钢筋含量校验
5. 混凝土含量校验
6. 混凝土截面合理性校验
7. 综合单价反算
8. Excel/CSV数据导入校验
9. 报告输出
"""

import argparse
import sys
import math
import json
from typing import Dict, List, Tuple, Optional, Union
from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime

# ============================================================================
# 内置数据表 - 所有数据硬编码在代码中，不从外部文件读取
# ============================================================================

# 钢筋理论重量表 (kg/m)
# 数据来源：GB/T 1499.2-2018
# 格式：{直径: 重量}
REBAR_WEIGHT_TABLE = {
    6: 0.222,
    8: 0.395,
    10: 0.617,
    12: 0.888,
    14: 1.210,
    16: 1.580,
    18: 2.000,
    20: 2.470,
    22: 2.980,
    25: 3.850,
    28: 4.830,
    32: 6.310,
}

# 钢筋基本锚固长度计算参数
# 数据来源：GB/T 50010-2010(2024年版)《混凝土结构设计标准》8.3.1条 + 22G101-1
# 公式：lab = α × (fy / ft) × d
#   α：光面钢筋0.16，带肋钢筋0.14
#   fy：钢筋抗拉强度设计值(N/mm²)
#   ft：混凝土轴心抗拉强度设计值(N/mm²)
REBAR_ANCHORAGE_ALPHA = {
    'HPB300': 0.16,   # 光面钢筋
    'HRB400': 0.14,   # 带肋钢筋
    'HRB500': 0.14,   # 带肋钢筋
}

REBAR_FY = {  # 钢筋抗拉强度设计值(N/mm²)
    'HPB300': 270,
    'HRB400': 360,
    'HRB500': 435,
}

CONCRETE_FT = {  # 混凝土轴心抗拉强度设计值(N/mm²)
    'C20': 1.10, 'C25': 1.27, 'C30': 1.43, 'C35': 1.57, 'C40': 1.71,
    'C45': 1.80, 'C50': 1.89, 'C55': 1.96, 'C60': 2.04,
}

# 抗震锚固修正系数
# 数据来源：GB 55008-2021
SEISMIC_ANCHORAGE_FACTOR = {
    '一级': 1.15,
    '二级': 1.15,
    '三级': 1.05,
    '四级': 1.00,
    '非抗震': 1.00,
}

# 钢筋含量经验指标表 (kg/m²)
# 数据来源：references/cost-indicators.md 表1.1（住宅类，含粗装）
REBAR_CONTENT_INDEX = {
    '框架结构': {'min': 45, 'max': 60, 'avg': 52},
    '框剪结构': {'min': 55, 'max': 70, 'avg': 62},
    '剪力墙结构': {'min': 65, 'max': 80, 'avg': 72},
    '框支转换结构': {'min': 70, 'max': 90, 'avg': 80},
    '砖混结构': {'min': 20, 'max': 35, 'avg': 27},
}

# 混凝土含量经验指标表 (m³/m²)
# 数据来源：references/cost-indicators.md 表1.1（住宅类，含粗装）
CONCRETE_CONTENT_INDEX = {
    '框架结构': {'min': 0.35, 'max': 0.45, 'avg': 0.40},
    '框剪结构': {'min': 0.45, 'max': 0.55, 'avg': 0.50},
    '剪力墙结构': {'min': 0.50, 'max': 0.65, 'avg': 0.57},
    '框支转换结构': {'min': 0.55, 'max': 0.70, 'avg': 0.62},
    '砖混结构': {'min': 0.20, 'max': 0.30, 'avg': 0.25},
}

# 综合单价费率表（典型值，可调整）
# 单位：%
PRICE_DECOMPOSITION_RATE = {
    '管理费': 10.0,    # 占人材机合计的比例
    '利润': 7.0,       # 占人材机合计的比例
    '人工费占比': 15.0,  # 占不含税单价的比例（示例）
    '材料费占比': 70.0,  # 占不含税单价的比例（示例）
    '机械费占比': 5.0,   # 占不含税单价的比例（示例）
}

# ============================================================================
# 数据类定义
# ============================================================================

@dataclass
class ValidationResult:
    """校验结果数据类"""
    is_valid: bool  # 是否合规
    message: str    # 结果消息
    details: Dict   # 详细数据
    warning: Optional[str] = None  # 警告信息

@dataclass
class CheckReport:
    """校验报告数据类"""
    title: str
    timestamp: str
    results: List[Dict] = field(default_factory=list)
    
    def add_result(self, category: str, result: ValidationResult):
        """添加校验结果到报告"""
        self.results.append({
            'category': category,
            'is_valid': result.is_valid,
            'message': result.message,
            'warning': result.warning,
            'details': result.details
        })

# ============================================================================
# 核心功能函数
# ============================================================================

def calculate_rebar_weight(
    diameter: int,
    count: int,
    length: float,
    wastage_rate: float = 0.025
) -> ValidationResult:
    """
    计算钢筋理论重量
    
    参数:
        diameter: 钢筋直径(mm)，支持d6~d32
        count: 钢筋根数
        length: 单根长度(m)
        wastage_rate: 损耗率，默认2.5%
    
    返回:
        ValidationResult对象，包含总重量、损耗后重量等信息
    """
    # 检查直径是否在支持范围内
    if diameter not in REBAR_WEIGHT_TABLE:
        return ValidationResult(
            is_valid=False,
            message=f"不支持的钢筋直径: d{diameter}，支持范围d6~d32",
            details={'supported_diameters': list(REBAR_WEIGHT_TABLE.keys())}
        )
    
    # 从理论重量表查表
    unit_weight = REBAR_WEIGHT_TABLE[diameter]
    
    # 计算总重量（kg）
    total_weight = unit_weight * count * length
    
    # 加损耗后的重量
    weight_with_wastage = total_weight * (1 + wastage_rate)
    
    return ValidationResult(
        is_valid=True,
        message=f"钢筋重量计算完成: d{diameter}×{count}根×{length}m",
        details={
            '钢筋直径': f'd{diameter}',
            '根数': count,
            '单根长度': f'{length}m',
            '理论重量': f'{unit_weight}kg/m',
            '总重量': f'{total_weight:.2f}kg',
            '损耗率': f'{wastage_rate*100}%',
            '损耗后重量': f'{weight_with_wastage:.2f}kg'
        }
    )

def calculate_stirrup_count(
    beam_clear_length: float,
    encrypted_zone_length: float,
    stirrup_spacing: int,
    encrypted_spacing: int = 100
) -> ValidationResult:
    """
    计算箍筋根数
    
    参数:
        beam_clear_length: 梁净长(m)
        encrypted_zone_length: 加密区长度(m)
        stirrup_spacing: 非加密区箍筋间距(mm)
        encrypted_spacing: 加密区箍筋间距(mm)，默认100mm
    
    返回:
        ValidationResult对象，包含总根数、加密区根数、非加密区根数
    """
    # 加密区根数（两端各有加密区）
    # 公式：向上取整(加密区长度/间距) + 1
    encrypted_count_single = math.ceil(encrypted_zone_length * 1000 / encrypted_spacing) + 1
    encrypted_count_total = encrypted_count_single * 2  # 两端加密区
    
    # 非加密区长度
    non_encrypted_length = beam_clear_length - encrypted_zone_length * 2
    
    if non_encrypted_length < 0:
        return ValidationResult(
            is_valid=False,
            message="加密区长度之和超过梁净长，请检查输入",
            details={
                '梁净长': f'{beam_clear_length}m',
                '单端加密区长度': f'{encrypted_zone_length}m'
            }
        )
    
    # 非加密区根数
    non_encrypted_count = math.ceil(non_encrypted_length * 1000 / stirrup_spacing) - 1
    
    # 总根数
    total_count = encrypted_count_total + max(0, non_encrypted_count)
    
    return ValidationResult(
        is_valid=True,
        message=f"箍筋根数计算完成，共{total_count}根",
        details={
            '梁净长': f'{beam_clear_length}m',
            '单端加密区长度': f'{encrypted_zone_length}m',
            '加密区间距': f'{encrypted_spacing}mm',
            '非加密区间距': f'{stirrup_spacing}mm',
            '单端加密区根数': encrypted_count_single,
            '加密区总根数': encrypted_count_total,
            '非加密区根数': max(0, non_encrypted_count),
            '总根数': total_count
        }
    )

def check_anchorage_length(
    diameter: int,
    concrete_grade: str,
    rebar_grade: str,
    seismic_grade: str = '非抗震'
) -> ValidationResult:
    """
    校验锚固/搭接长度
    
    参数:
        diameter: 钢筋直径(mm)
        concrete_grade: 混凝土等级(如'C30')
        rebar_grade: 钢筋级别('HPB300'/'HRB400'/'HRB500')
        seismic_grade: 抗震等级('一级'/'二级'/'三级'/'四级'/'非抗震')
    
    返回:
        ValidationResult对象，包含La、LaE及合规判断
    """
    # 钢筋级别转换
    grade_map = {'HPB300': 1, 'HRB400': 2, 'HRB500': 3}
    grade_code = grade_map.get(rebar_grade)
    
    if not grade_code:
        return ValidationResult(
            is_valid=False,
            message=f"不支持的钢筋级别: {rebar_grade}",
            details={'支持级别': list(grade_map.keys())}
        )
    
    # 检查抗震等级
    if seismic_grade not in SEISMIC_ANCHORAGE_FACTOR:
        return ValidationResult(
            is_valid=False,
            message=f"不支持的抗震等级: {seismic_grade}",
            details={'支持等级': list(SEISMIC_ANCHORAGE_FACTOR.keys())}
        )
    
    # 计算基本锚固长度 lab = α × (fy / ft) × d
    # 依据：GB/T 50010-2010(2024年版)《混凝土结构设计标准》8.3.1条 / 22G101-1
    if concrete_grade not in CONCRETE_FT:
        return ValidationResult(
            is_valid=False,
            message=f"不支持的混凝土等级: {concrete_grade}，或组合不存在",
            details={'支持等级': list(CONCRETE_FT.keys())}
        )

    alpha = REBAR_ANCHORAGE_ALPHA[rebar_grade]
    fy = REBAR_FY[rebar_grade]
    ft = CONCRETE_FT[concrete_grade]
    lab_d = round(alpha * fy / ft)  # 基本锚固长度倍数（d的倍数，四舍五入取整）
    La = lab_d * diameter

    # 抗震锚固长度 LaE = ξaE × lab
    seismic_factor = SEISMIC_ANCHORAGE_FACTOR[seismic_grade]
    laE_d = round(seismic_factor * lab_d)
    LaE = laE_d * diameter

    # 合规判断（LaE 应在 15d~60d 合理范围内）
    is_reasonable = 15 * diameter <= LaE <= 60 * diameter

    warning = None
    if not is_reasonable:
        warning = "锚固长度可能偏大或偏小，请核对设计图纸和规范要求"

    return ValidationResult(
        is_valid=True,
        message=f"锚固长度计算完成: lab={La:.0f}mm, laE={LaE:.0f}mm",
        warning=warning,
        details={
            '钢筋直径': f'd{diameter}',
            '钢筋级别': rebar_grade,
            '混凝土等级': concrete_grade,
            '抗震等级': seismic_grade,
            '计算公式': 'lab=α×(fy/ft)×d，α=带肋0.14/光圆0.16',
            '基本锚固长度lab': f'{lab_d}d = {La:.0f}mm',
            '抗震修正系数ξaE': f'{seismic_factor}',
            '抗震锚固长度laE': f'{laE_d}d = {LaE:.0f}mm',
            '建议搭接长度': f'{round(1.2 * laE_d)}d = {1.2 * LaE:.0f}mm',
            '搭接说明': '搭接长度LlE=ζl×laE，ζl按搭接面积百分率取1.2(≤25%)/1.4(50%)/1.6(100%)',
            '最小锚固': '受拉钢筋锚固长度不应小于200mm，且lab不应小于15d量级',
        }
    )

def check_rebar_content(
    total_weight: float,
    building_area: float,
    structure_type: str
) -> ValidationResult:
    """
    校验钢筋含量指标
    
    参数:
        total_weight: 总钢筋重量(kg)
        building_area: 建筑总面积(m²)
        structure_type: 结构类型('框架结构'/'框剪结构'/'剪力墙结构'/'框支转换结构'/'砖混结构')
    
    返回:
        ValidationResult对象，包含kg/m²指标及是否在经验范围内
    """
    # 检查结构类型
    if structure_type not in REBAR_CONTENT_INDEX:
        return ValidationResult(
            is_valid=False,
            message=f"不支持的结构类型: {structure_type}",
            details={'支持类型': list(REBAR_CONTENT_INDEX.keys())}
        )
    
    # 计算钢筋含量指标
    content_index = total_weight / building_area  # kg/m²
    
    # 获取经验指标范围
    index_range = REBAR_CONTENT_INDEX[structure_type]
    min_val = index_range['min']
    max_val = index_range['max']
    avg_val = index_range['avg']
    
    # 判断是否在经验范围内（±20%波动）
    lower_bound = min_val * 0.8
    upper_bound = max_val * 1.2
    
    is_in_range = lower_bound <= content_index <= upper_bound
    
    warning = None
    if not is_in_range:
        if content_index < lower_bound:
            warning = f"钢筋含量偏低({content_index:.1f}kg/m²)，低于经验范围下限({lower_bound:.1f}kg/m²)，请核对图纸数据"
        else:
            warning = f"钢筋含量偏高({content_index:.1f}kg/m²)，超出经验范围上限({upper_bound:.1f}kg/m²)，请核对图纸数据"
    
    # 判断是否在正常范围内
    is_normal = min_val <= content_index <= max_val
    
    return ValidationResult(
        is_valid=is_in_range,
        message=f"钢筋含量指标: {content_index:.1f}kg/m²，{'在' if is_normal else '超出'}经验范围内",
        warning=warning,
        details={
            '总钢筋重量': f'{total_weight}kg',
            '建筑总面积': f'{building_area}m²',
            '结构类型': structure_type,
            '含量指标': f'{content_index:.1f}kg/m²',
            '经验范围': f'{min_val}~{max_val}kg/m²',
            '经验平均值': f'{avg_val}kg/m²',
            '判断范围(±20%)': f'{lower_bound:.1f}~{upper_bound:.1f}kg/m²',
            '是否在经验范围': '是' if is_normal else '否'
        }
    )

def check_concrete_content(
    total_volume: float,
    building_area: float,
    structure_type: str
) -> ValidationResult:
    """
    校验混凝土含量指标
    
    参数:
        total_volume: 总混凝土方量(m³)
        building_area: 建筑总面积(m²)
        structure_type: 结构类型('框架结构'/'框剪结构'/'剪力墙结构'/'框支转换结构'/'砖混结构')
    
    返回:
        ValidationResult对象，包含m³/m²指标及是否在经验范围内
    """
    # 检查结构类型
    if structure_type not in CONCRETE_CONTENT_INDEX:
        return ValidationResult(
            is_valid=False,
            message=f"不支持的结构类型: {structure_type}",
            details={'支持类型': list(CONCRETE_CONTENT_INDEX.keys())}
        )
    
    # 计算混凝土含量指标
    content_index = total_volume / building_area  # m³/m²
    
    # 获取经验指标范围
    index_range = CONCRETE_CONTENT_INDEX[structure_type]
    min_val = index_range['min']
    max_val = index_range['max']
    avg_val = index_range['avg']
    
    # 判断是否在经验范围内
    is_normal = min_val <= content_index <= max_val
    
    warning = None
    if not is_normal:
        if content_index < min_val:
            warning = f"混凝土含量偏低({content_index:.3f}m³/m²)，低于经验范围({min_val}~{max_val}m³/m²)"
        else:
            warning = f"混凝土含量偏高({content_index:.3f}m³/m²)，超出经验范围({min_val}~{max_val}m³/m²)"
    
    return ValidationResult(
        is_valid=is_normal,
        message=f"混凝土含量指标: {content_index:.3f}m³/m²，{'在' if is_normal else '超出'}经验范围内",
        warning=warning,
        details={
            '总混凝土方量': f'{total_volume}m³',
            '建筑总面积': f'{building_area}m²',
            '结构类型': structure_type,
            '含量指标': f'{content_index:.3f}m³/m²',
            '经验范围': f'{min_val}~{max_val}m³/m²',
            '经验平均值': f'{avg_val}m³/m²'
        }
    )

def check_beam_section(
    beam_width: int,
    beam_height: int,
    span: float
) -> ValidationResult:
    """
    校验梁截面合理性
    
    参数:
        beam_width: 梁宽(mm)
        beam_height: 梁高(mm)
        span: 梁跨度(m)
    
    返回:
        ValidationResult对象，包含高跨比及判断
    """
    # 计算高跨比
    span_mm = span * 1000
    height_span_ratio = beam_height / span_mm
    
    # 高跨比正常范围：1/10 ~ 1/15，即 0.067 ~ 0.100
    lower_bound = 1 / 15  # 0.067
    upper_bound = 1 / 10  # 0.100
    
    is_reasonable = lower_bound <= height_span_ratio <= upper_bound
    
    warning = None
    if not is_reasonable:
        if height_span_ratio < lower_bound:
            warning = f"梁高偏小，高跨比{height_span_ratio:.3f}小于{lower_bound:.3f}(1/15)，可能刚度不足"
        else:
            warning = f"梁高偏大，高跨比{height_span_ratio:.3f}大于{upper_bound:.3f}(1/10)，可能造成浪费"
    
    return ValidationResult(
        is_valid=is_reasonable,
        message=f"梁截面{beam_width}×{beam_height}，跨度{span}m，高跨比{height_span_ratio:.3f}",
        warning=warning,
        details={
            '梁截面': f'{beam_width}×{beam_height}mm',
            '梁跨度': f'{span}m',
            '梁高': f'{beam_height}mm',
            '高跨比': f'{height_span_ratio:.3f} (1/{1/height_span_ratio:.0f})',
            '正常范围': '1/10~1/15 (0.067~0.100)',
            '判断': '合理' if is_reasonable else '异常'
        }
    )

def decompose_unit_price(
    tax_inclusive_price: float,
    tax_rate: float = 0.09,
    management_fee_rate: float = 10.0,
    profit_rate: float = 7.0
) -> ValidationResult:
    """
    综合单价反算分解
    
    参数:
        tax_inclusive_price: 含税综合单价(元)
        tax_rate: 税率，默认9%
        management_fee_rate: 管理费率(%)，默认10%
        profit_rate: 利润率(%)，默认7%
    
    返回:
        ValidationResult对象，包含不含税单价及人材机管利分解
    """
    # 计算不含税单价
    tax_exclusive_price = tax_inclusive_price / (1 + tax_rate)
    
    # 人材机合计（扣除管理费和利润前的基数）
    # 假设综合单价 = 人材机 + 管理费 + 利润
    # 其中管理费 = 人材机 × 管理费率
    # 利润 = 人材机 × 利润率
    # 综合 = 人材机 × (1 + 管理费率 + 利润率)
    
    base_factor = 1 + management_fee_rate / 100 + profit_rate / 100
    base_amount = tax_exclusive_price / base_factor
    
    management_fee = base_amount * management_fee_rate / 100
    profit = base_amount * profit_rate / 100
    
    # 按典型占比分解人材机
    labor_ratio = PRICE_DECOMPOSITION_RATE['人工费占比']
    material_ratio = PRICE_DECOMPOSITION_RATE['材料费占比']
    machine_ratio = PRICE_DECOMPOSITION_RATE['机械费占比']
    
    labor_cost = tax_exclusive_price * labor_ratio / 100
    material_cost = tax_exclusive_price * material_ratio / 100
    machine_cost = tax_exclusive_price * machine_ratio / 100
    
    return ValidationResult(
        is_valid=True,
        message=f"综合单价分解完成",
        details={
            '含税综合单价': f'{tax_inclusive_price:.2f}元',
            '税率': f'{tax_rate*100}%',
            '不含税单价': f'{tax_exclusive_price:.2f}元',
            '人材机合计': f'{base_amount:.2f}元',
            '人工费': f'{labor_cost:.2f}元 ({labor_ratio}%)',
            '材料费': f'{material_cost:.2f}元 ({material_ratio}%)',
            '机械费': f'{machine_cost:.2f}元 ({machine_ratio}%)',
            '管理费': f'{management_fee:.2f}元 ({management_fee_rate}%)',
            '利润': f'{profit:.2f}元 ({profit_rate}%)',
            '备注': '人材机占比为典型值，实际项目可能不同'
        }
    )

def check_excel_csv_file(
    file_path: str
) -> ValidationResult:
    """
    Excel/CSV数据导入校验
    
    参数:
        file_path: Excel或CSV文件路径
    
    返回:
        ValidationResult对象，包含读取结果摘要和数值校验
    """
    path = Path(file_path)
    
    # 检查文件是否存在
    if not path.exists():
        return ValidationResult(
            is_valid=False,
            message=f"文件不存在: {file_path}",
            details={}
        )
    
    # 检查文件格式
    suffix = path.suffix.lower()
    if suffix not in ['.xlsx', '.csv']:
        return ValidationResult(
            is_valid=False,
            message=f"不支持的文件格式: {suffix}，仅支持.xlsx和.csv",
            details={}
        )
    
    # 尝试读取文件
    try:
        if suffix == '.csv':
            # 使用csv模块读取
            import csv
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.reader(f)
                rows = list(reader)
        else:
            # 使用openpyxl读取xlsx
            try:
                from openpyxl import load_workbook
                wb = load_workbook(file_path, read_only=True, data_only=True)
                ws = wb.active
                
                rows = []
                for row in ws.iter_rows(values_only=True):
                    rows.append(list(row))
                
                wb.close()
            except ImportError:
                return ValidationResult(
                    is_valid=False,
                    message="未安装openpyxl库，无法读取xlsx文件。请运行: pip install openpyxl",
                    details={'安装命令': 'pip install openpyxl'}
                )
        
        # 检查是否有数据
        if len(rows) < 2:
            return ValidationResult(
                is_valid=False,
                message="文件数据不足，至少需要标题行和数据行",
                details={'总行数': len(rows)}
            )
        
        # 提取标题行
        headers = rows[0]
        data_rows = rows[1:]
        
        # 统计信息
        stats = {
            '文件名': path.name,
            '文件格式': suffix,
            '总行数': len(rows),
            '数据行数': len(data_rows),
            '总列数': len(headers),
            '列名': headers
        }
        
        # 识别关键列（钢筋、混凝土、模板等）
        keywords = ['钢筋', '混凝土', '模板', '工程量', '数量', '长度', '面积', '体积']
        keyword_columns = {}
        for i, header in enumerate(headers):
            if header:
                for keyword in keywords:
                    if keyword in str(header):
                        keyword_columns[header] = i
                        break
        
        stats['关键词列'] = list(keyword_columns.keys())
        
        # 数值列统计
        numeric_stats = {}
        for col_name, col_idx in keyword_columns.items():
            values = []
            for row in data_rows:
                if col_idx < len(row):
                    try:
                        val = float(row[col_idx])
                        values.append(val)
                    except (ValueError, TypeError):
                        pass
            
            if values:
                numeric_stats[col_name] = {
                    '最小值': min(values),
                    '最大值': max(values),
                    '平均值': sum(values) / len(values),
                    '数据个数': len(values)
                }
                
                # 异常值检测（简单规则：负数或超过平均值3倍标准差）
                avg = sum(values) / len(values)
                if len(values) > 1:
                    std = math.sqrt(sum((x - avg) ** 2 for x in values) / len(values))
                    outliers = [x for x in values if abs(x - avg) > 3 * std]
                    if outliers:
                        numeric_stats[col_name]['异常值'] = outliers
        
        stats['数值列统计'] = numeric_stats
        
        return ValidationResult(
            is_valid=True,
            message=f"文件读取成功，共{len(data_rows)}行数据",
            details=stats
        )
        
    except Exception as e:
        return ValidationResult(
            is_valid=False,
            message=f"文件读取失败: {str(e)}",
            details={'错误': str(e)}
        )

# ============================================================================
# 报告生成
# ============================================================================

def generate_markdown_report(report: CheckReport) -> str:
    """
    生成Markdown格式报告
    
    参数:
        report: CheckReport对象
    
    返回:
        Markdown格式的报告字符串
    """
    lines = [
        f"# {report.title}",
        "",
        f"**生成时间:** {report.timestamp}",
        "",
        "---",
        ""
    ]
    
    for i, result in enumerate(report.results, 1):
        # 添加分类标题
        lines.append(f"## {i}. {result['category']}")
        lines.append("")
        
        # 添加状态标识
        status = "[合规]" if result['is_valid'] else "[异常]"
        lines.append(f"**状态:** {status}")
        lines.append("")
        
        # 添加消息
        lines.append(f"**结果:** {result['message']}")
        lines.append("")
        
        # 添加警告（如果有）
        if result['warning']:
            lines.append(f"[警告] **注意:** {result['warning']}")
            lines.append("")
        
        # 添加详细数据
        if result['details']:
            lines.append("**详细数据:**")
            lines.append("")
            lines.append("| 项目 | 数值 |")
            lines.append("|------|------|")
            for key, value in result['details'].items():
                # 处理字典类型的值
                if isinstance(value, dict):
                    value_str = json.dumps(value, ensure_ascii=False)
                elif isinstance(value, list):
                    value_str = ', '.join(str(v) for v in value)
                else:
                    value_str = str(value)
                lines.append(f"| {key} | {value_str} |")
            lines.append("")
        
        lines.append("---")
        lines.append("")
    
    return '\n'.join(lines)

# ============================================================================
# 命令行接口
# ============================================================================

def create_parser() -> argparse.ArgumentParser:
    """创建命令行参数解析器"""
    parser = argparse.ArgumentParser(
        prog='quantity_checker',
        description='算量校验辅助工具 - 用于造价工程师校验算量结果',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  # 计算钢筋重量
  python quantity_checker.py rebar --diameter 16 --count 10 --length 6
  
  # 计算箍筋根数
  python quantity_checker.py stirrup --beam-length 6 --encrypted-length 1 --spacing 200
  
  # 校验锚固长度
  python quantity_checker.py anchorage --diameter 20 --concrete C30 --rebar HRB400 --seismic 二级
  
  # 校验钢筋含量
  python quantity_checker.py rebar-content --weight 50000 --area 1000 --type 框架结构
  
  # 校验混凝土含量
  python quantity_checker.py concrete-content --volume 400 --area 1000 --type 框架结构
  
  # 校验梁截面
  python quantity_checker.py beam-section --width 300 --height 600 --span 6
  
  # 综合单价分解
  python quantity_checker.py price --price 1000 --tax 0.09
  
  # 导入Excel/CSV校验
  python quantity_checker.py import --file data.xlsx
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='功能模块')
    
    # 1. 钢筋重量计算
    rebar_parser = subparsers.add_parser('rebar', help='钢筋理论重量计算')
    rebar_parser.add_argument('--diameter', type=int, required=True, help='钢筋直径(mm)')
    rebar_parser.add_argument('--count', type=int, required=True, help='根数')
    rebar_parser.add_argument('--length', type=float, required=True, help='单根长度(m)')
    rebar_parser.add_argument('--wastage', type=float, default=0.025, help='损耗率(默认0.025)')
    
    # 2. 箍筋根数计算
    stirrup_parser = subparsers.add_parser('stirrup', help='箍筋根数计算')
    stirrup_parser.add_argument('--beam-length', type=float, required=True, help='梁净长(m)')
    stirrup_parser.add_argument('--encrypted-length', type=float, required=True, help='加密区长度(m)')
    stirrup_parser.add_argument('--spacing', type=int, required=True, help='非加密区间距(mm)')
    stirrup_parser.add_argument('--encrypted-spacing', type=int, default=100, help='加密区间距(mm)')
    
    # 3. 锚固长度校验
    anchorage_parser = subparsers.add_parser('anchorage', help='锚固/搭接长度校验')
    anchorage_parser.add_argument('--diameter', type=int, required=True, help='钢筋直径(mm)')
    anchorage_parser.add_argument('--concrete', type=str, required=True, help='混凝土等级(如C30)')
    anchorage_parser.add_argument('--rebar', type=str, required=True, help='钢筋级别(HPB300/HRB400/HRB500)')
    anchorage_parser.add_argument('--seismic', type=str, default='非抗震', help='抗震等级(一级/二级/三级/四级/非抗震)')
    
    # 4. 钢筋含量校验
    rebar_content_parser = subparsers.add_parser('rebar-content', help='钢筋含量指标校验')
    rebar_content_parser.add_argument('--weight', type=float, required=True, help='总钢筋重量(kg)')
    rebar_content_parser.add_argument('--area', type=float, required=True, help='建筑总面积(m²)')
    rebar_content_parser.add_argument('--type', type=str, required=True, help='结构类型(框架结构/框剪结构/剪力墙结构/框支转换结构/砖混结构)')
    
    # 5. 混凝土含量校验
    concrete_content_parser = subparsers.add_parser('concrete-content', help='混凝土含量指标校验')
    concrete_content_parser.add_argument('--volume', type=float, required=True, help='总混凝土方量(m³)')
    concrete_content_parser.add_argument('--area', type=float, required=True, help='建筑总面积(m²)')
    concrete_content_parser.add_argument('--type', type=str, required=True, help='结构类型(框架结构/框剪结构/剪力墙结构/框支转换结构/砖混结构)')
    
    # 6. 梁截面校验
    beam_parser = subparsers.add_parser('beam-section', help='梁截面合理性校验')
    beam_parser.add_argument('--width', type=int, required=True, help='梁宽(mm)')
    beam_parser.add_argument('--height', type=int, required=True, help='梁高(mm)')
    beam_parser.add_argument('--span', type=float, required=True, help='跨度(m)')
    
    # 7. 综合单价分解
    price_parser = subparsers.add_parser('price', help='综合单价反算分解')
    price_parser.add_argument('--price', type=float, required=True, help='含税综合单价(元)')
    price_parser.add_argument('--tax', type=float, default=0.09, help='税率(默认0.09)')
    price_parser.add_argument('--management', type=float, default=10.0, help='管理费率(默认10%)')
    price_parser.add_argument('--profit', type=float, default=7.0, help='利润率(默认7%)')
    
    # 8. 文件导入校验
    import_parser = subparsers.add_parser('import', help='Excel/CSV数据导入校验')
    import_parser.add_argument('--file', type=str, required=True, help='Excel或CSV文件路径')
    
    # 9. 批量校验（演示）
    demo_parser = subparsers.add_parser('demo', help='运行演示案例')
    
    return parser

def run_demo() -> CheckReport:
    """运行演示案例，展示所有功能"""
    report = CheckReport(
        title='算量校验演示报告',
        timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    )
    
    # 1. 钢筋重量计算演示
    result1 = calculate_rebar_weight(diameter=16, count=100, length=6.0)
    report.add_result('钢筋理论重量计算', result1)
    
    # 2. 箍筋根数计算演示
    result2 = calculate_stirrup_count(beam_clear_length=6.0, encrypted_zone_length=1.0, stirrup_spacing=200)
    report.add_result('箍筋根数计算', result2)
    
    # 3. 锚固长度校验演示
    result3 = check_anchorage_length(diameter=20, concrete_grade='C30', rebar_grade='HRB400', seismic_grade='二级')
    report.add_result('锚固/搭接长度校验', result3)
    
    # 4. 钢筋含量校验演示
    result4 = check_rebar_content(total_weight=50000, building_area=1000, structure_type='框架结构')
    report.add_result('钢筋含量指标校验', result4)
    
    # 5. 混凝土含量校验演示
    result5 = check_concrete_content(total_volume=400, building_area=1000, structure_type='框架结构')
    report.add_result('混凝土含量指标校验', result5)
    
    # 6. 梁截面校验演示
    result6 = check_beam_section(beam_width=300, beam_height=600, span=6.0)
    report.add_result('梁截面合理性校验', result6)
    
    # 7. 综合单价分解演示
    result7 = decompose_unit_price(tax_inclusive_price=1000.0)
    report.add_result('综合单价反算分解', result7)
    
    return report

def main():
    """主函数"""
    parser = create_parser()
    args = parser.parse_args()
    
    # 无命令时显示帮助
    if not args.command:
        parser.print_help()
        return
    
    # 创建报告对象
    report = CheckReport(
        title='算量校验报告',
        timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    )
    
    # 根据命令执行对应功能
    if args.command == 'rebar':
        result = calculate_rebar_weight(
            diameter=args.diameter,
            count=args.count,
            length=args.length,
            wastage_rate=args.wastage
        )
        report.add_result('钢筋理论重量计算', result)
    
    elif args.command == 'stirrup':
        result = calculate_stirrup_count(
            beam_clear_length=args.beam_length,
            encrypted_zone_length=args.encrypted_length,
            stirrup_spacing=args.spacing,
            encrypted_spacing=args.encrypted_spacing
        )
        report.add_result('箍筋根数计算', result)
    
    elif args.command == 'anchorage':
        result = check_anchorage_length(
            diameter=args.diameter,
            concrete_grade=args.concrete,
            rebar_grade=args.rebar,
            seismic_grade=args.seismic
        )
        report.add_result('锚固/搭接长度校验', result)
    
    elif args.command == 'rebar-content':
        result = check_rebar_content(
            total_weight=args.weight,
            building_area=args.area,
            structure_type=args.type
        )
        report.add_result('钢筋含量指标校验', result)
    
    elif args.command == 'concrete-content':
        result = check_concrete_content(
            total_volume=args.volume,
            building_area=args.area,
            structure_type=args.type
        )
        report.add_result('混凝土含量指标校验', result)
    
    elif args.command == 'beam-section':
        result = check_beam_section(
            beam_width=args.width,
            beam_height=args.height,
            span=args.span
        )
        report.add_result('梁截面合理性校验', result)
    
    elif args.command == 'price':
        result = decompose_unit_price(
            tax_inclusive_price=args.price,
            tax_rate=args.tax,
            management_fee_rate=args.management,
            profit_rate=args.profit
        )
        report.add_result('综合单价反算分解', result)
    
    elif args.command == 'import':
        result = check_excel_csv_file(file_path=args.file)
        report.add_result('Excel/CSV数据导入校验', result)
    
    elif args.command == 'demo':
        report = run_demo()
    
    # 输出报告
    markdown_report = generate_markdown_report(report)
    # Windows控制台使用UTF-8编码输出
    sys.stdout.reconfigure(encoding='utf-8')
    print(markdown_report)

if __name__ == '__main__':
    main()
