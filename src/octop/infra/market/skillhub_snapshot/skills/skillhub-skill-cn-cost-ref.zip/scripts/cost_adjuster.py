#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
材料价格调差计算器 (Cost Adjuster)
===================================
依据 GB/T 50500-2024《建设工程工程量清单计价标准》第11章物价波动条款，
执行公式法调差：ΔP = P₀ × [A + Σ(Bᵢ × Ftᵢ/F₀ᵢ) − 1]

场景一：输入「材料类别」+「基准期价格」+「当期价格」+「权重」→ 输出调差金额
场景二：输入「基准清单单价」+「综合调差系数」→ 输出调整后清单单价
场景三：输入「基准期信息价」+「当期信息价」→ 输出单规格调差

作者: cn-cost-ref skill
版本: 1.0 | 更新: 2026-08-23
"""

import argparse
import sys
import math
import json
import csv
from datetime import datetime
from typing import List, Dict, Optional

# ============================================================================
# 材料价格来源（重要）
# ============================================================================
# 本脚本自身不内置价格表（历史 DEFAULT_PRICE_INDEX 已移除）。
# 当期/基准材料价请从本地材料价库取，命令：
#     python3 material_price_lookup.py to-adjuster --ft 2026-08 --f0 2026-03 \
#             --region 广州 --json price_input.json
# 产出 {"ft":{材料名:价格},"f0":{材料名:价格}}，再把 ft/f0 值喂给下方 index 命令。
# 见 references/material-price-guide.md。口径须一致（同为信息价 或 同为市场价含税）。


# ============================================================================
# 核心调差公式
# ============================================================================

def cost_adjustment_index_method(
    p0: float,
    a: float,
    b_weights: List[tuple],   # [(材料名, B_i), ...]
    ft_dict: Dict[str, float],  # {材料名: 当期价格}
    f0_dict: Dict[str, float],  # {材料名: 基准期价格}
) -> Dict:
    """
    公式法调差：ΔP = P₀ × [A + Σ(Bᵢ × Ftᵢ/F₀ᵢ) − 1]

    参数:
        p0       : 基准期综合单价（元/m³ / 元/t 等）
        a        : 定值权重 A（如 0.15，表示人工/管理费不调部分）
        b_weights: 可调因子权重列表 [(材料名, B_i), ...]，ΣBᵢ = 1 − A
        ft_dict  : {材料名: 当期价格}
        f0_dict  : {材料名: 基准期价格}

    返回:
        dict，含调整前后单价、调差金额、调差系数、各因子贡献
    """
    if abs(a + sum(b for _, b in b_weights) - 1.0) > 0.001:
        return {"error": "A + ΣBᵢ 必须等于 1.0"}

    sigma_term = sum(bi * (ft_dict[name] / f0_dict[name])
                    for name, bi in b_weights if name in ft_dict and name in f0_dict and f0_dict[name] != 0)

    adj_factor = a + sigma_term
    adjusted_price = p0 * adj_factor
    delta_p = adjusted_price - p0

    factor_breakdown = {}
    for name, bi in b_weights:
        if name in ft_dict and name in f0_dict and f0_dict[name] != 0:
            ratio = ft_dict[name] / f0_dict[name]
            contribution = p0 * bi * (ratio - 1)
            factor_breakdown[name] = {
                "B_i": bi,
                "基准价格": f0_dict[name],
                "当期价格": ft_dict[name],
                "价格指数": round(ratio, 4),
                "贡献调差": round(contribution, 2),
            }

    return {
        "基准单价": p0,
        "定值权重A": a,
        "可调因子数": len(b_weights),
        "综合调差系数": round(adj_factor, 6),
        "调整后单价": round(adjusted_price, 4),
        "调差金额ΔP": round(delta_p, 4),
        "调差幅度%": round((delta_p / p0 * 100), 3) if p0 != 0 else 0,
        "各因子贡献": factor_breakdown,
        "公式": "ΔP = P₀ × [A + Σ(Bᵢ × Ftᵢ/F₀ᵢ) − 1]",
    }


def single_material_adjustment(
    base_price: float,
    current_price: float,
    quantity: float,
    unit: str = "t",
) -> Dict:
    """
    单规格材料调差（无综合单价分解）。
    ΔP = P₀ × (Ft/F₀ − 1) × Q
    """
    if base_price <= 0:
        return {"error": "基准价格必须 > 0"}
    ratio = current_price / base_price
    delta_unit = base_price * (ratio - 1)
    delta_total = delta_unit * quantity
    return {
        "基准价格": base_price,
        "当期价格": current_price,
        "价格指数": round(ratio, 4),
        "单价调差": round(delta_unit, 4),
        "工程量": quantity,
        "单位": unit,
        "合计调差金额": round(delta_total, 2),
        "调差幅度%": round((ratio - 1) * 100, 3),
    }


def contract_price_adjustment(
    contract_price: float,
    adj_factor: float,
    quantity: float,
) -> Dict:
    """
    合同调差：竣工结算时按调差系数直接调整合同单价。
    适用于合同已约定综合调差系数的场景。
    """
    adjusted = contract_price * adj_factor
    delta = adjusted - contract_price
    return {
        "合同单价": contract_price,
        "调差系数": adj_factor,
        "调整后单价": round(adjusted, 4),
        "工程量": quantity,
        "合同合价": round(contract_price * quantity, 2),
        "调整后合价": round(adjusted * quantity, 2),
        "调差合价": round(delta * quantity, 2),
    }


# ============================================================================
# 报告生成
# ============================================================================

def generate_report(result: Dict, title: str = "") -> str:
    lines = [
        "=" * 60,
        f"材料价格调差计算报告  {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "=" * 60,
    ]
    if title:
        lines.append(f"项目: {title}")
    lines.append("")

    if "error" in result:
        lines.append(f"错误: {result['error']}")
        return "\n".join(lines)

    for key, val in result.items():
        if key == "各因子贡献":
            lines.append(f"{key}:")
            for mat, detail in val.items():
                lines.append(f"  └ {mat}:  权重={detail['B_i']}  "
                            f"基准={detail['基准价格']}  当期={detail['当期价格']}  "
                            f"指数={detail['价格指数']}  贡献=¥{detail['贡献调差']}")
        elif key == "公式":
            lines.append(f"{key}: {val}")
        elif isinstance(val, float):
            lines.append(f"  {key}: {val:,.4f}")
        else:
            lines.append(f"  {key}: {val}")

    lines.append("")
    lines.append("⚠️  提示：基准期/当期价格须使用当地造价站发布的同期信息价；"
                 "本工具计算结果为参考值，结算时须合同约定及双方确认。")
    lines.append("=" * 60)
    return "\n".join(lines)


# ============================================================================
# CLI
# ============================================================================

def build_parser():
    parser = argparse.ArgumentParser(
        description="材料价格调差计算器（GB/T 50500-2024 公式法）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 综合调差（公式法）
  python cost_adjuster.py index --base 520 --a 0.15 \\
    --factors 钢筋,0.35 水泥,0.25 混凝土,0.20 柴油,0.05 \\
    --ft 钢筋,4200 水泥,420 混凝土,560 柴油,8200 \\
    --f0 钢筋,3800 水泥,380 混凝土,520 柴油,7500

  # 单规格调差
  python cost_adjuster.py single --base 3800 --current 4200 --qty 120

  # 合同调差（已知调差系数）
  python cost_adjuster.py contract --price 520 --factor 1.08 --qty 2000 --title "C30混凝土调差"

  # 从 JSON 文件批量计算
  python cost_adjuster.py batch --file project_prices.json

价格来源：先用 material_price_lookup.py to-adjuster 从本地价库导出 ft/f0，
再填入上方 index 命令。勿用手算/网查价（缺四要素溯源）。
        """
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # ---- 综合调差（公式法）----
    p = sub.add_parser("index", help="综合调差（公式法 ΔP = P₀ × [A + Σ(Bᵢ × Ftᵢ/F₀ᵢ) − 1]）")
    p.add_argument("--base", type=float, required=True, help="基准期综合单价 P₀")
    p.add_argument("--a", type=float, required=True, help="定值权重 A（如 0.15）")
    p.add_argument("--factors", nargs="+", required=True,
                   help="可调因子及权重，格式：名称,权重  可多次指定")
    p.add_argument("--ft", nargs="+", required=True,
                   help="当期价格，格式：名称,价格  如：钢筋,4200")
    p.add_argument("--f0", nargs="+", required=True,
                   help="基准期价格，格式：名称,价格  如：钢筋,3800")
    p.add_argument("--qty", type=float, default=1.0, help="工程量（默认1.0，即输出单价）")
    p.add_argument("--title", default="综合调差计算", help="项目名称")
    p.add_argument("--json", action="store_true", help="输出 JSON 格式")

    # ---- 单规格调差----
    p = sub.add_parser("single", help="单规格材料调差（ΔP = P₀ × (Ft/F₀ − 1) × Q）")
    p.add_argument("--base", type=float, required=True, help="基准期价格 P₀（元）")
    p.add_argument("--current", type=float, required=True, help="当期价格 Ft（元）")
    p.add_argument("--qty", type=float, required=True, help="调差工程量")
    p.add_argument("--unit", default="t", help="单位（默认 t）")
    p.add_argument("--json", action="store_true", help="输出 JSON 格式")

    # ---- 合同调差----
    p = sub.add_parser("contract", help="合同调差（已知调差系数）")
    p.add_argument("--price", type=float, required=True, help="合同单价（元）")
    p.add_argument("--factor", type=float, required=True, help="调差系数（如 1.08）")
    p.add_argument("--qty", type=float, required=True, help="调差工程量")
    p.add_argument("--title", default="合同调差计算", help="项目名称")
    p.add_argument("--json", action="store_true", help="输出 JSON 格式")

    # ---- 批量计算----
    p = sub.add_parser("batch", help="从 JSON 文件批量计算")
    p.add_argument("--file", type=str, required=True, help="JSON 批量输入文件")
    p.add_argument("--out", type=str, default="adjuster_report.csv", help="输出 CSV 路径")
    p.add_argument("--json", action="store_true", help="输出 JSON 格式")

    return parser


def parse_kv_list(lst: List[str]) -> Dict[str, float]:
    result = {}
    for item in lst:
        parts = item.split(",")
        if len(parts) != 2:
            print(f"警告：无法解析 '{item}'，跳过")
            continue
        result[parts[0].strip()] = float(parts[1].strip())
    return result


def parse_factor_list(lst: List[str]) -> List[tuple]:
    result = []
    for item in lst:
        parts = item.split(",")
        if len(parts) != 2:
            print(f"警告：无法解析 '{item}'，跳过")
            continue
        result.append((parts[0].strip(), float(parts[1].strip())))
    return result


def run_batch(filepath: str, out_csv: str, as_json: bool) -> Dict:
    with open(filepath, encoding="utf-8") as f:
        data = json.load(f)

    results = []
    for entry in data:
        cmd = entry.get("type", "single")
        if cmd == "index":
            r = cost_adjustment_index_method(
                entry["base"], entry["a"],
                parse_factor_list(entry.get("factors", [])),
                parse_kv_list(entry.get("ft", [])),
                parse_kv_list(entry.get("f0", [])),
            )
            if "error" not in r:
                r["调差合价"] = round(r["调差金额ΔP"] * entry.get("qty", 1), 2)
        elif cmd == "single":
            r = single_material_adjustment(
                entry["base"], entry["current"], entry["qty"], entry.get("unit", "t")
            )
        elif cmd == "contract":
            r = contract_price_adjustment(
                entry["price"], entry["factor"], entry["qty"]
            )
        else:
            r = {"error": f"未知类型: {cmd}"}
        r["项目"] = entry.get("title", cmd)
        results.append(r)

    if as_json:
        output = json.dumps(results, ensure_ascii=False, indent=2)
        print(output)
        return {"results": results}

    # CSV
    fieldnames = ["项目", "基准单价", "调差金额ΔP", "调差幅度%", "综合调差系数", "error"]
    with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        w.writerows(results)
    return {"results": results, "csv": out_csv}


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    parser = build_parser()
    args = parser.parse_args()

    if args.cmd == "index":
        b_weights = parse_factor_list(args.factors)
        ft_dict = parse_kv_list(args.ft)
        f0_dict = parse_kv_list(args.f0)
        result = cost_adjustment_index_method(args.base, args.a, b_weights, ft_dict, f0_dict)
        if "error" not in result:
            total = result["调整后单价"] * args.qty
            result["调差合价"] = round(result["调差金额ΔP"] * args.qty, 2)
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(generate_report(result, args.title))

    elif args.cmd == "single":
        result = single_material_adjustment(args.base, args.current, args.qty, args.unit)
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(generate_report(result, "单规格调差"))

    elif args.cmd == "contract":
        result = contract_price_adjustment(args.price, args.factor, args.qty)
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(generate_report(result, args.title))

    elif args.cmd == "batch":
        r = run_batch(args.file, args.out, args.json)
        if not args.json:
            print(f"批量计算完成，结果已写入: {args.out}")


if __name__ == "__main__":
    main()
