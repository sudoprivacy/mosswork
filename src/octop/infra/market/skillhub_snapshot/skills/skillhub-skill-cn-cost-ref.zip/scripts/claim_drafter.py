#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工程索赔函生成器 (Claim Drafter)
=================================
依据 GB/T 50500-2024《建设工程工程量清单计价标准》及 FIDIC 合同条件，
根据用户提供的索赔事件信息，自动生成规范格式的工期/费用索赔函。

支持三种场景：
  notice   索赔意向通知（28天内发出，固定格式）
 工期    工期索赔报告（工期顺延 + 责任认定）
  费用    费用索赔报告（综合单价分解 + 证据清单）

内置风险提示：触发词识别 → 风险预警 → 建议行动

作者: cn-cost-ref skill
版本: 1.0 | 更新: 2026-08-23
"""

import argparse
import sys
import json
import math
from datetime import datetime, timedelta
from typing import List, Dict, Optional

# ============================================================================
# 内置规范条款索引
# ============================================================================

CLAUSE_INDEX = {
    "GB50500": {
        "工期顺延条件": "GB/T 50500-2024 §9.3（承包人索赔程序）",
        "变更估价": "GB/T 50500-2024 §9.2（变更估价程序）",
        "物价波动调差": "GB/T 50500-2024 §11.2（物价波动调差）",
        "不可抗力": "GB/T 50500-2024 §11.5（不可抗力）",
        "逾期付款利息": "GB/T 50500-2024 §11.6（迟延付款）",
        "工期延误费用": "GB/T 50500-2024 §9.3.2（工期延误责任）",
    },
    "FIDIC": {
        "工期顺延": "FIDIC Red Book 2017 Cl.20.1（索赔程序）",
        "工期延误": "FIDIC Red Book 2017 Cl.8.4（竣工时间延长）",
        "费用索赔": "FIDIC Red Book 2017 Cl.20.1 + Cl.14",
        "变更": "FIDIC Red Book 2017 Cl.13（变更与调整）",
    },
    "GF2017": {
        "索赔时效": "GF-2017-0201 第二部分通用合同条款 第25条（28天）",
        "变更估价": "GF-2017-0201 通用合同条款 第13条",
        "逾期付款利息": "GF-2017-0201 通用合同条款 第16条",
        "缺陷责任期": "GF-2017-0201 通用合同条款 第15条",
    },
}

# 索赔事件类型 → 典型工期 / 费用模式
CLAIM_PATTERNS = {
    "设计变更": {
        "工期影响": "按变更范围和复杂程度评估；设计变更造成返工须顺延工期",
        "费用影响": "返工费用 + 拆除费用 + 重新施工费用；按变更估价四步法",
        "证据清单": ["变更指令/图纸会审记录", "变更前后施工方案对比", "返工工程量确认单", "人工/机械台班签证"],
    },
    "地质条件变化": {
        "工期影响": "须提供地质勘察报告对比；属于发包人风险，可索赔工期+费用",
        "费用影响": "地基处理增加费用（换填/加固/桩基加深）",
        "证据清单": ["地质勘察报告", "现场照片/影像", "超挖工程量确认单", "地基处理方案确认"],
    },
    "发包人延迟交付": {
        "工期影响": "延迟多久顺延多久；注意是否影响关键线路",
        "费用影响": "承包人看管/留守人员费用 + 机械闲置费 + 材料涨价损失",
        "证据清单": ["合同约定交付时间", "实际交付时间记录", "机械闲置台班确认单", "人员留守费用清单"],
    },
    "不可抗力": {
        "工期影响": "按合同约定分担；通常发包人承担工期顺延",
        "费用影响": "工程实体损失（发包人承担）/ 承包人设备损失（承包人承担）/ 各自人员伤亡",
        "证据清单": ["不可抗力事件证明（政府公告/气象证明）", "停复工时间记录", "现场人员设备清单", "财产损失清单"],
    },
    "价格异常波动": {
        "工期影响": "价格波动本身不影响工期，但资金不足可能影响材料采购",
        "费用影响": "材料调差金额 = Σ[材料用量 × (当期价格 − 基准价格)]",
        "证据清单": ["基准期信息价", "当期信息价", "材料采购发票", "合同调差条款"],
    },
    "工期延误": {
        "工期影响": "非承包人原因延误 → 顺延；承包人原因延误 → 无权索赔",
        "费用影响": "停工/窝工费用 + 机械闲置费 + 现场管理费增加",
        "证据清单": ["延误事件记录", "施工日志/监理日志", "网络进度计划（关键线路分析）", "现场人员/机械清单"],
    },
    "政策/法规变化": {
        "工期影响": "通常给予工期顺延（涉及强制性规范变化时）",
        "费用影响": "合规改造增加费用（如环保要求/消防规范升级）",
        "证据清单": ["政策文件原文", "设计调整通知", "新增工程量确认单"],
    },
}

# ============================================================================
# 索赔函模板生成
# ============================================================================

def generate_notice(
    project_name: str,
    contract_no: str,
    claim_type: str,
    event_date: str,
    estimated_impact: str,
    contractor_name: str,
    contact: str,
    file_no: str = "",
) -> str:
    """
    索赔意向通知（Notice of Claim）
    按 GF-2017-0201 第25条：索赔事件发生后28天内提交。

    参数：
        project_name  : 项目名称
        contract_no  : 合同编号
        claim_type   : 索赔类型（工期/费用/工期+费用）
        event_date    : 索赔事件发生日期（YYYY-MM-DD）
        estimated_impact: 预估影响（天数/金额）
        contractor_name: 承包人名称
        contact      : 联系人/联系方式
        file_no      : 文件编号（可选）
    """
    today = datetime.now().strftime("%Y年%m月%d日")

    notice = f"""
{'='*62}
                              索赔意向通知
                           (NOTICE OF CLAIM)
{'='*62}

文件编号: {file_no or '(承包人自行编号)'}
发出日期: {today}

致: 【发包人名称】（发包人）
    【监理单位名称】（监理人）

抄送: 【造价咨询单位】（如有）

项目名称: {project_name}
合同编号: {contract_no}

一、索赔意向声明

    本承包人（{contractor_name}）依据
    《建设工程施工合同（示范文本）》（GF-2017-0201）
    第二部分 通用合同条款 第25条 及
    专用合同条款的相关约定，
    正式通知发包人：本承包人拟就以下索赔事件提出
    【{claim_type}】索赔。

二、索赔事件概要

    索赔事件类型: {claim_type}
    事件发生日期: {event_date}
    事件描述: 【请承包人填写事件详细描述】
    预计影响: {estimated_impact}

三、合同依据

    1. 依据《建设工程施工合同（示范文本）》（GF-2017-0201）
       第25.1条：索赔事件发生后28天内，承包人须向监理人提交索赔意向通知；
    2. 本通知在合同约定期限内提交，符合索赔程序要求。

四、后续安排

    本承包人将在索赔事件持续影响结束后28天内，
    按合同约定向监理人提交详细索赔报告及相关证明材料。

    请发包人/监理人接收本通知，并妥善保存。

{'─'*62}
承包人（盖章）: {contractor_name}
负 责  人    : 【签字】
日          期: {today}

联  系  方 式: {contact}
{'='*62}

⚠️  风险提示：
  · 本通知须在索赔事件发生后 28天内 发出，逾期视为放弃索赔权！
  · 通知仅表明索赔意向，不等于索赔成功；
  · 建议同步收集并固定证据（照片/视频/监理日志/施工记录）。
"""

    return notice


def generate_time_claim_report(
    project_name: str,
    contract_no: str,
    claim_no: str,
    event_date: str,
    delay_days: int,
    delay_reason: str,
    responsible_party: str,
    key_path_impact: str,
    cpm_analysis: str,
    contractor_name: str,
    preparer: str,
    contact: str,
    attachments: List[str],
    file_no: str = "",
) -> str:
    """
    工期索赔报告（Time Extension Claim Report）
    包含：事件描述 → 责任认定 → 关键线路分析（CPM） → 工期顺延天数 → 证据清单

    参数：
        delay_days       : 工期顺延天数（整数）
        responsible_party: 责任方（发包人/不可抗力/设计变更/政策变化）
        key_path_impact  : 是否在关键线路上（是/否/使非关键变关键）
        cpm_analysis    : 关键线路分析说明（摘要）
    """
    today = datetime.now().strftime("%Y年%m月%d日")
    claim_date = today
    due_date = (datetime.now() + timedelta(days=28)).strftime("%Y年%m月%d日")

    attachments_text = "\n    ".join(f"{i+1}. {a}" for i, a in enumerate(attachments))
    if not attachments_text:
        attachments_text = "（无附件）"

    # 工期影响分析
    if responsible_party == "承包人":
        entitlement = "无权获得工期顺延"
        risk_level = "高风险"
    elif responsible_party == "共同责任":
        entitlement = f"按责任比例分担，建议协商确定顺延 {delay_days} 天"
        risk_level = "中风险"
    else:
        entitlement = f"有权获得 {delay_days} 天工期顺延"
        risk_level = "正常"

    report = f"""
{'='*64}
                          工期索赔报告
              (TIME EXTENSION CLAIM REPORT)
{'='*64}

文件编号: {file_no or f'索赔-{claim_no}'}
报告日期: {claim_date}
索赔编号: {claim_no}

致: 【发包人名称】
    【监理单位】
    【造价咨询单位】（如有）

项目名称: {project_name}
合同编号: {contract_no}
索赔事件: {delay_reason}
事件发生: {event_date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

一、索赔事件描述

    {delay_reason}

二、合同依据

    1. GF-2017-0201 第二部分 通用合同条款 第25条（索赔程序）
    2. GF-2017-0201 通用合同条款 第7.8条（工期顺延条件）
    3. FIDIC Red Book 2017 Cl.8.4（竣工时间延长）

三、事件发生日期及持续情况

    事件发生日期: {event_date}
    持续至: 【填写】
    持续天数: {delay_days} 天（日历天）

四、关键线路法（CPM）工期影响分析

    【关键线路分析摘要】
    {cpm_analysis}

    关键线路影响: {key_path_impact}

    分析结论：
    {delay_reason} 事件{"发生在关键线路上" if key_path_impact=="是" else "不在关键线路上但使非关键工作变为关键" if "使非关键" in key_path_impact else "不在关键线路上，不影响竣工时间，需进一步分析"}，
    须顺延工期 {delay_days} 天。

五、责任认定

    责任方判定: {responsible_party}
    索赔权利: {entitlement}

六、工期顺延申请

    申请顺延天数: {delay_days} 日历天
    计算依据:
    （1）延误事件持续期间：{delay_days} 天
    （2）事件对关键线路工作的影响：见第四部分 CPM 分析
    （3）最终申请：顺延 {delay_days} 天

七、证明材料清单

    {attachments_text}

八、后续安排

    本承包人保留根据后续情况进一步追加工期顺延的权利。
    如需进一步说明，请联系本报告编制人。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
承包人: {contractor_name}
编制人: {preparer}
联系方式: {contact}
提交日期: {claim_date}
{'='*64}

⚠️  审核要点（造价工程师/监理人）：
  · 核实延误事件是否发生在关键线路（核心！）
  · 核实延误原因是否为承包人责任
  · 核实延误持续天数是否有连续证据
  · 共同延误情况下，各自责任须分开核算
  · ⚠️ {risk_level}：{entitlement}
"""

    return report


def generate_cost_claim_report(
    project_name: str,
    contract_no: str,
    claim_no: str,
    event_date: str,
    claim_reason: str,
    line_items: List[Dict],
    subtotal: float,
    tax_rate: float,
    total_with_tax: float,
    contractor_name: str,
    preparer: str,
    contact: str,
    attachments: List[str],
    remarks: str = "",
    file_no: str = "",
) -> str:
    """
    费用索赔报告（Cost Claim Report）
    包含：费用明细表（综合单价分解）+ 证据清单 + 风险提示

    参数：
        line_items : 费用明细，格式 [{"item":"名称","spec":"规格","unit":"单位","qty":"数量","unit_price":"单价","amount":"金额","formula":"计算公式"}]
        subtotal   : 小计（不含税）
        tax_rate   : 增值税率（如 0.09）
        total_with_tax: 价税合计
        remarks    : 备注（争议说明等）
    """
    today = datetime.now().strftime("%Y年%m月%d日")
    attachments_text = "\n    ".join(f"{i+1}. {a}" for i, a in enumerate(attachments))
    if not attachments_text:
        attachments_text = "（无附件）"

    # 生成费用明细表格
    def fmt_row(item):
        return (
            f"  {item.get('seq',''):>3}  "
            f"{item.get('item',''):<20} "
            f"{item.get('spec',''):<14} "
            f"{item.get('unit',''):>6} "
            f"{item.get('qty',''):>10} "
            f"{item.get('unit_price',''):>12} "
            f"{item.get('amount',''):>12} "
        )

    table_header = (
        f"  {'序号':>3}  {'费用项目':<20} {'规格/说明':<14} "
        f"{'单位':>6} {'工程量':>10} {'综合单价(元)':>12} {'合价(元)':>12}\n"
        f"  {'-'*3}  {'-'*20} {'-'*14} {'-'*6} {'-'*10} {'-'*12} {'-'*12}"
    )

    rows_text = "\n".join(fmt_row(item) for item in line_items)
    tax_amount = subtotal * tax_rate
    grand_total = subtotal + tax_amount

    report = f"""
{'='*66}
                          费用索赔报告
                  (COST CLAIM REPORT)
{'='*66}

文件编号: {file_no or f'索赔-{claim_no}'}
报告日期: {today}
索赔编号: {claim_no}

致: 【发包人名称】
    【监理单位】
    【造价咨询单位/跟踪审计】（如有）

项目名称: {project_name}
合同编号: {contract_no}
索赔事件: {claim_reason}
事件发生: {event_date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

一、索赔事项说明

    {claim_reason}

二、合同依据

    1. GB/T 50500-2024 §9.3（承包人索赔程序）
    2. GB/T 50500-2024 §9.2（变更估价四步法）
    3. GF-2017-0201 通用合同条款 第13条（变更估价）
    4. GF-2017-0201 通用合同条款 第25条（索赔程序）

三、费用明细表（不含税）

{table_header}
{rows_text}
  {'─'*3}  {'─'*20} {'─'*14} {'─'*6} {'─'*10} {'─'*12} {'─'*12}
  {'':>3}  {'费用小计（不含税）':<34} {'':>6} {'':>10} {'':>12} {subtotal:>12,.2f}

四、税金

    增值税率: {tax_rate*100:.0f}%
    增值税额: {tax_amount:,.2f} 元

五、索赔金额汇总

    不含税金额: {subtotal:>15,.2f} 元
    增值税额  : {tax_amount:>15,.2f} 元
    ─────────────────────────────────────
    价税合计    : {grand_total:>15,.2f} 元

六、费用计算说明

    （一）综合单价分析：
    综合单价 = 人工费 + 材料费 + 施工机具使用费 + 管理费 + 利润 + 规费 + 税金
    各单项费用须有对应签证/定额依据方可计入。

    （二）费率取值说明：
    管理费率: 【按合同约定，如10%】
    利润率  : 【按合同约定，如7%】
    规费    : 【按省规定费率】
    增值税率: {tax_rate*100:.0f}%【按当期适用税率】

七、证明材料清单

    {attachments_text}

八、备注

    {remarks or '（无）'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
承包人: {contractor_name}
编制人: {preparer}
联系方式: {contact}
提交日期: {today}
{'='*66}

⚠️  审核要点（造价工程师/监理人/跟踪审计）：
  · 核实各项费用是否与索赔事件有直接因果关系（因果链！）
  · 核实综合单价是否有合同/定额/签证依据
  · 核实工程量是否经发包人或监理确认
  · 核实管理费/利润/规费是否在合同约定范围内
  · 核实税率是否适用当期政策（2024年起增值税小规模纳税人1%已到期，回复3%）
  · 注意：单纯工期延误不一定产生费用，费用须单独举证
"""

    return report


def generate_full_claim_pack(
    project_name: str,
    contract_no: str,
    claim_no: str,
    claim_type: str,
    event_date: str,
    delay_days: int,
    delay_reason: str,
    responsible_party: str,
    key_path_impact: str,
    cpm_analysis: str,
    line_items: List[Dict],
    subtotal: float,
    tax_rate: float,
    contractor_name: str,
    preparer: str,
    contact: str,
    attachments: List[str],
    remarks: str = "",
    file_no: str = "",
) -> str:
    """生成完整索赔文件包（含通知+工期报告+费用报告）。"""
    notice = generate_notice(
        project_name, contract_no, claim_type, event_date,
        f"工期{delay_days}天，费用约{subtotal:.2f}元（待核实）",
        contractor_name, contact, file_no
    )
    time_report = generate_time_claim_report(
        project_name, contract_no, claim_no, event_date,
        delay_days, delay_reason, responsible_party,
        key_path_impact, cpm_analysis, contractor_name,
        preparer, contact, attachments, file_no
    )
    cost_report = generate_cost_claim_report(
        project_name, contract_no, claim_no, event_date,
        delay_reason, line_items, subtotal, tax_rate,
        subtotal + subtotal * tax_rate, contractor_name,
        preparer, contact, attachments, remarks, file_no
    )

    pack = f"""
{'#'*68}
              工程索赔文件包（完整版）
        CLAIM DOCUMENT PACKAGE (COMPLETE)
{'#'*68}

编号: {file_no or claim_no}
项目: {project_name}
合同: {contract_no}
日期: {datetime.now().strftime('%Y年%m月%d日')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                    第一部分  索赔意向通知
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{notice}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                    第二部分  工期索赔报告
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{time_report}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                    第三部分  费用索赔报告
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{cost_report}

{'#'*68}
                    文件包编制说明
{'#'*68}

  1. 本文件包包含索赔意向通知（第一部分）、工期索赔报告（第二部分）、
     费用索赔报告（第三部分），三者构成完整索赔文件体系。
  2. 索赔意向通知须在事件发生后 28天内 发出，否则可能丧失索赔权利。
  3. 详细索赔报告须在意向通知后 28天内 提交。
  4. 所有证据材料须为原件或经监理/发包人确认的复印件。
  5. 本文件包须经承包人法定代表人或授权代表签署并加盖公章。
  6. 建议提交前由专业造价工程师审核综合单价与费用计算逻辑。
"""
    return pack


# ============================================================================
# CLI
# ============================================================================

def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    parser = argparse.ArgumentParser(
        description="工程索赔函生成器 — 生成工期/费用索赔报告",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 生成索赔意向通知
  python claim_drafter.py notice --project "某商业综合体" --contract "HT-2024-001" \\
      --type "工期+费用" --event "2024-03-15" --contractor "某某建设集团" \\
      --contact "李工 12930601041.01" --out notice.txt

  # 生成工期索赔报告
  python claim_drafter.py time --project "某商业综合体" --contract "HT-2024-001" \\
      --claim-no "CL-2024-001" --event "2024-03-15" --days 15 \\
      --reason "发包人延迟交付施工图纸" --responsible "发包人" \\
      --key-path "是" --cpm "地下室外墙变更造成主体结构停工15天" \\
      --contractor "某某建设集团" --preparer "王造价" --contact "李工" \\
      --attachments "变更图纸" "监理日志" "施工日志" --out time_claim.txt

  # 生成费用索赔报告
  python claim_drafter.py cost --project "某商业综合体" --contract "HT-2024-001" \\
      --claim-no "CL-2024-001" --event "2024-03-15" \\
      --reason "设计变更导致返工" --subtotal 117125 --tax 0.09 \\
      --contractor "某某建设集团" --preparer "王造价" --contact "李工" \\
      --attachments "变更指令" "返工确认单" --out cost_claim.txt

  # 生成完整索赔文件包（通知+工期+费用）
  python claim_drafter.py pack --project "某商业综合体" --contract "HT-2024-001" \\
      --claim-no "CL-2024-001" --event "2024-03-15" --type "工期+费用" \\
      --days 15 --reason "发包人延迟交付施工图纸" --responsible "发包人" \\
      --key-path "是" --cpm "主体结构停工15天" --subtotal 117125 --tax 0.09 \\
      --contractor "某某建设集团" --preparer "王造价" --contact "李工" \\
      --attachments "变更指令" "监理日志" --out claim_package.txt
        """
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # 索赔意向通知
    p = sub.add_parser("notice", help="生成索赔意向通知")
    for arg, help_, default in [
        ("--project", "项目名称", "某工程项目"),
        ("--contract", "合同编号", ""),
        ("--type", "索赔类型（工期/费用/工期+费用）", "工期+费用"),
        ("--event", "事件发生日期（YYYY-MM-DD）", ""),
        ("--contractor", "承包人名称", ""),
        ("--contact", "联系方式", ""),
        ("--file-no", "文件编号", ""),
    ]:
        p.add_argument(arg, help=help_, default=default)
    p.add_argument("--out", default="claim_notice.txt", help="输出文件路径")

    # 工期索赔报告
    p = sub.add_parser("time", help="生成工期索赔报告")
    for arg, help_ in [
        ("--project", "项目名称"),
        ("--contract", "合同编号"),
        ("--claim-no", "索赔编号"),
        ("--event", "事件日期（YYYY-MM-DD）"),
        ("--days", "顺延天数（整数）"),
        ("--reason", "延误/索赔原因"),
        ("--responsible", "责任方（发包人/承包人/不可抗力/设计变更/共同责任）"),
        ("--key-path", "是否在关键线路上（是/否/使非关键变关键）"),
        ("--cpm", "CPM关键线路分析摘要"),
        ("--contractor", "承包人名称"),
        ("--preparer", "编制人"),
        ("--contact", "联系方式"),
        ("--attachments", "附件清单（可多次指定）"),
        ("--file-no", "文件编号"),
    ]:
        p.add_argument(arg, help=help_)
    p.add_argument("--out", default="time_claim.txt")

    # 费用索赔报告
    p = sub.add_parser("cost", help="生成费用索赔报告")
    for arg, help_ in [
        ("--project", "项目名称"),
        ("--contract", "合同编号"),
        ("--claim-no", "索赔编号"),
        ("--event", "事件日期"),
        ("--reason", "索赔原因"),
        ("--subtotal", "不含税小计金额（元）"),
        ("--tax", "增值税率（默认0.09）"),
        ("--contractor", "承包人名称"),
        ("--preparer", "编制人"),
        ("--contact", "联系方式"),
        ("--attachments", "附件列表"),
        ("--remarks", "备注"),
        ("--file-no", "文件编号"),
    ]:
        p.add_argument(arg, help=help_)
    p.add_argument("--out", default="cost_claim.txt")

    # 完整文件包
    p = sub.add_parser("pack", help="生成完整索赔文件包（通知+工期+费用）")
    for arg, help_ in [
        ("--project", "项目名称"),
        ("--contract", "合同编号"),
        ("--claim-no", "索赔编号"),
        ("--event", "事件日期"),
        ("--type", "索赔类型"),
        ("--days", "顺延天数"),
        ("--reason", "索赔原因"),
        ("--responsible", "责任方"),
        ("--key-path", "关键线路影响"),
        ("--cpm", "CPM分析摘要"),
        ("--subtotal", "不含税小计"),
        ("--tax", "增值税率"),
        ("--contractor", "承包人名称"),
        ("--preparer", "编制人"),
        ("--contact", "联系方式"),
        ("--attachments", "附件列表"),
        ("--remarks", "备注"),
        ("--file-no", "文件编号"),
    ]:
        p.add_argument(arg, help=help_)
    p.add_argument("--out", default="claim_package.txt")

    args = parser.parse_args()

    def _default(val, default_=""):
        return val if val else default_

    if args.cmd == "notice":
        content = generate_notice(
            args.project or "某工程项目",
            _default(args.contract),
            args.type or "工期+费用",
            args.event or datetime.now().strftime("%Y-%m-%d"),
            "【请填写预估影响】",
            args.contractor or "【承包人名称】",
            args.contact or "【联系方式】",
            args.file_no or "",
        )

    elif args.cmd == "time":
        content = generate_time_claim_report(
            args.project or "某工程项目",
            _default(args.contract),
            args.claim_no or "CL-001",
            args.event or "",
            int(args.days or 0),
            args.reason or "【请填写原因】",
            args.responsible or "发包人",
            args.key_path or "是",
            args.cpm or "【请填写CPM分析】",
            args.contractor or "【承包人名称】",
            args.preparer or "【编制人】",
            args.contact or "【联系方式】",
            args.attachments,
            args.file_no or "",
        )

    elif args.cmd == "cost":
        content = generate_cost_claim_report(
            args.project or "某工程项目",
            _default(args.contract),
            args.claim_no or "CL-001",
            args.event or "",
            args.reason or "【请填写原因】",
            [],  # line_items — CLI模式下留空，交互模式可指定JSON
            float(args.subtotal or 0),
            float(args.tax or 0.09),
            float(args.subtotal or 0) * (1 + float(args.tax or 0.09)),
            args.contractor or "【承包人名称】",
            args.preparer or "【编制人】",
            args.contact or "【联系方式】",
            args.attachments,
            args.remarks or "",
            args.file_no or "",
        )

    elif args.cmd == "pack":
        content = generate_full_claim_pack(
            args.project or "某工程项目",
            _default(args.contract),
            args.claim_no or "CL-001",
            args.type or "工期+费用",
            args.event or "",
            int(args.days or 0),
            args.reason or "【请填写原因】",
            args.responsible or "发包人",
            args.key_path or "是",
            args.cpm or "【请填写CPM分析】",
            [],  # line_items
            float(args.subtotal or 0),
            float(args.tax or 0.09),
            args.contractor or "【承包人名称】",
            args.preparer or "【编制人】",
            args.contact or "【联系方式】",
            args.attachments,
            args.remarks or "",
            args.file_no or "",
        )

    # 输出
    if args.out and args.out != "-":
        with open(args.out, "w", encoding="utf-8-sig") as f:
            f.write(content)
        print(f"✅ 索赔文件已生成: {args.out}")
    else:
        print(content)


if __name__ == "__main__":
    main()
