#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest_all.py · 造价稽核官统一回归测试台

为什么要有这个：本技能 31 个脚本里长期只有 7 个有自测入口，其余靠 `--help` 冒烟，
而 `--help` 通过**不代表算得对**。此前交付文档出现「冒烟 33/33」与「17/17」互相矛盾、
以及 A2M 测试在本机从未真正跑通，正是因为缺少一个跑得起来、且数字可信的总闸门。
本测试台即为反幻觉红线第 15 条「测试数字必须实跑」的落地装置。

分组：
  G1 语法与 CLI     全部脚本 py_compile；有 argparse 的必须 --help 不崩
  G2 引擎自测       有 selftest/demo 子命令的**实际执行**并断言 exit 0
  G3 关键算法真值   用关系式断言（单调/线性/公式）而非脆弱魔数
  G4 数据完整性     结构化库可解析 + 必要键齐全 + 价库四要素
  G5 frontmatter    YAML 合法 + 指纹自洽 + 形态声明一致
  G6 交付契约       引用纪律与红线条目在位

用法：
  python3 scripts/selftest_all.py            # 全量
  python3 scripts/selftest_all.py --quick    # 跳过 G3 的耗时项
  python3 scripts/selftest_all.py --json     # 机器可读

退出码：0 = 全通过；1 = 有失败项（供 release.sh 阻断打包）
"""
import glob
import json
import os
import py_compile
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PY = sys.executable

QUICK = "--quick" in sys.argv
AS_JSON = "--json" in sys.argv

GROUPS = []


def group(name):
    def deco(fn):
        GROUPS.append((name, fn))
        return fn
    return deco


class Rec:
    def __init__(self):
        self.rows = []

    def add(self, g, name, ok, detail=""):
        self.rows.append({"group": g, "name": name, "ok": bool(ok), "detail": str(detail)[:160]})

    @property
    def failed(self):
        return [r for r in self.rows if not r["ok"]]


R = Rec()


def scripts():
    return sorted(glob.glob(os.path.join(HERE, "*.py")))


def has_argparse(path):
    """是否真的 `import argparse` 了（用 AST 判定）。

    ⚠ 两次踩坑记录：不能用 `"argparse" in src` 粗判——
      ① 本文件 docstring 里就出现「argparse」二字；
      ② 改成匹配 `"import argparse" in src` 后，又匹配到本文件自己那行
         `("import argparse" in src)` 的字面量。
      两次都把自己误判为有 argparse，于是对自己的 --help 反复执行
      （--help 不会让它退出，只会继续跑全量测试 → 必然超时）。
      改用 AST 只认真实的 import 语句，字符串里的假阳性一律不算。
    """
    import ast
    try:
        tree = ast.parse(open(path, encoding="utf-8").read())
    except Exception:
        return False
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            if any(a.name.split(".")[0] == "argparse" for a in node.names):
                return True
        elif isinstance(node, ast.ImportFrom):
            if (node.module or "").split(".")[0] == "argparse":
                return True
    return False


def run(args, timeout=180):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                           cwd=ROOT)
        return r.returncode, (r.stdout or ""), (r.stderr or "")
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"
    except Exception as e:  # noqa: BLE001
        return 125, "", f"{type(e).__name__}: {e}"


# ============================================================ G1
@group("G1 语法与 CLI")
def g1():
    for p in scripts():
        n = os.path.basename(p)
        try:
            py_compile.compile(p, doraise=True, cfile=os.path.join(tempfile.gettempdir(), "_c.pyc"))
            R.add("G1", f"语法 {n}", True)
        except py_compile.PyCompileError as e:
            R.add("G1", f"语法 {n}", False, str(e)[:120])
    for p in scripts():
        n = os.path.basename(p)
        if not has_argparse(p):
            R.add("G1", f"CLI {n}", True, "无 argparse（直接读 argv），跳过 --help")
            continue
        rc, out, err = run([PY, p, "--help"], timeout=60)
        crashed = "Traceback" in (err or "")
        R.add("G1", f"CLI {n}", (rc == 0) and not crashed,
              f"exit={rc}" + (f" traceback" if crashed else ""))


# ============================================================ G2
SELFTESTS = [
    ("quantity_checker.py", "demo"),
    ("cadvector_takeoff.py", "selftest"),
    ("cadpdf_takeoff.py", "demo"),
    ("labor_settlement_audit.py", "demo"),
    ("handwritten_bill_parse.py", "demo"),
    ("cadpdf_room_decode.py", "demo"),
    ("alipay_payment_gateway.py", "demo"),
    ("bid_clean_check.py", "selftest"),
    ("limit_price_verify.py", "selftest"),
    ("capability_demo.py", "selftest"),
]


@group("G2 引擎自测")
def g2():
    for fn, sub in SELFTESTS:
        p = os.path.join(HERE, fn)
        if not os.path.isfile(p):
            R.add("G2", f"{fn} {sub}", False, "脚本不存在")
            continue
        rc, out, err = run([PY, p, sub])
        # 失败详情优先抓真实的 [FAIL] 行；否则退最后一条非空输出。
        # ⚠ 教训：直接取 last line 会抓到 "=====" 分隔线，诊断时毫无信息量。
        detail = ""
        if rc != 0:
            lines = [x.strip() for x in (out or "").splitlines() if x.strip()]
            fails = [x for x in lines if x.startswith("[FAIL]")]
            if fails:
                detail = " / ".join(fails[:3])
            else:
                el = [x for x in (err or "").splitlines() if x.strip()]
                detail = (el[-1] if el else (lines[-1] if lines else f"exit={rc}"))[:140]
        else:
            lines = [x.strip() for x in (out or "").splitlines() if x.strip()]
            summ = [x for x in lines if ("通过" in x or "PASS" in x)]
            detail = (summ[-1] if summ else (lines[-1] if lines else ""))[:140]
        R.add("G2", f"{fn} {sub}", rc == 0, detail)


# ============================================================ G3
@group("G3 关键算法真值")
def g3():
    # --- 3.1 材料调差公式 ΔP = P₀ × (Ft/F₀ − 1) × Q ---
    payload = [
        {"type": "single", "base": 5000, "current": 5200, "qty": 12, "unit": "t", "title": "钢筋"},
        {"type": "single", "base": 5000, "current": 4800, "qty": 12, "unit": "t", "title": "钢筋降"},
        {"type": "single", "base": 5000, "current": 5200, "qty": 24, "unit": "t", "title": "钢筋双倍量"},
    ]
    fp = os.path.join(tempfile.gettempdir(), "_st_adj.json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    try:
        rc, out, _ = run([PY, os.path.join(HERE, "cost_adjuster.py"),
                          "batch", "--file", fp, "--json"])
        if rc != 0:
            R.add("G3", "调差 batch 可执行", False, f"exit={rc}")
        else:
            try:
                arr = json.loads(out)
                R.add("G3", "调差 batch 可执行", True, f"{len(arr)} 条")
                up, dn, two = arr[0], arr[1], arr[2]
                R.add("G3", "调差·涨价 ΔP>0", float(up["合计调差金额"]) > 0,
                       f"ΔP={up['合计调差金额']}")
                R.add("G3", "调差·跌价 ΔP<0", float(dn["合计调差金额"]) < 0,
                       f"ΔP={dn['合计调差金额']}")
                R.add("G3", "调差·公式正确 5000×4%×12=2400",
                       abs(float(up["合计调差金额"]) - 2400.0) < 1e-6,
                       f"got {up['合计调差金额']}")
                R.add("G3", "调差·调差幅度%=+4.0", abs(float(up["调差幅度%"]) - 4.0) < 1e-9,
                       f"got {up['调差幅度%']}")
                R.add("G3", "调差·线性（工程量翻倍→金额翻倍）",
                       abs(float(two["合计调差金额"]) - 2 * float(up["合计调差金额"])) < 1e-6,
                       f"{two['合计调差金额']} vs {2*float(up['合计调差金额'])}")
                R.add("G3", "调差·单价调差=当期−基准",
                       abs(float(up["单价调差"]) - (5200 - 5000)) < 1e-9)
            except Exception as e:  # noqa: BLE001
                R.add("G3", "调差输出可解析为 JSON", False, str(e)[:120])
    finally:
        if os.path.exists(fp):
            os.remove(fp)

    if QUICK:
        R.add("G3", "（--quick 跳过价库/指数/三源项）", True)
        return

    # --- 3.2 价库：四要素齐全（期号/口径/地区/来源）---
    rc, out, err = run([PY, os.path.join(HERE, "material_price_lookup.py"), "search", "钢筋"])
    ok = rc == 0 and out.count("可核") + out.count("市场核") >= 1
    R.add("G3", "价库检索命中并带置信度", ok, f"exit={rc}")
    R.add("G3", "价库输出含期号与口径", bool(re.search(r"\[20\d\d-\d\d\]", out)))

    # --- 3.3 指数库：最新一期可读且四指数齐全 ---
    rc, out, _ = run([PY, os.path.join(HERE, "price_index_lookup.py"), "latest"])
    need = ["人工价格指数", "材料价格指数", "台班价格指数", "工程造价指数"]
    miss = [k for k in need if k not in out]
    R.add("G3", "指数库 latest 四指数齐全", rc == 0 and not miss,
          f"缺={miss}" if miss else f"exit={rc}")

    # --- 3.4 三源比价：输出必带判定与来源 ---
    rc, out, _ = run([PY, os.path.join(HERE, "audit_triple_source.py"),
                      "audit", "钢筋", "5000", "t"])
    R.add("G3", "三源比价可执行", rc == 0, f"exit={rc}")
    R.add("G3", "三源比价输出含判定档位",
          any(k in out for k in ("虚高", "可核", "存疑", "缺当期可比源")))

    # --- 3.5 隐私门禁本体可跑且零命中 ---
    rc, out, _ = run([PY, os.path.join(HERE, "privacy_scan.py")])
    R.add("G3", "隐私门禁零 L2/L3 命中", rc == 0, f"exit={rc}")


# ============================================================ G4
DATA_DIR = os.path.join(HERE, "data")
REQUIRED_KEYS = {
    "material_prices.json": ["schema_version", "materials", "meta"],
    "privacy_terms.json": ["project_names", "regex_rules", "raw_file_ext"],
    "policy_files.json": None,
    "gd_price_index.json": None,
    "gd2015_fee.json": None,
    "gz_municipal_2025.json": None,
    "gbt_2024_nav.json": None,
}


@group("G4 数据完整性")
def g4():
    for fn, keys in REQUIRED_KEYS.items():
        p = os.path.join(DATA_DIR, fn)
        if not os.path.isfile(p):
            R.add("G4", f"{fn} 存在", False, "缺失")
            continue
        try:
            d = json.load(open(p, encoding="utf-8"))
        except Exception as e:  # noqa: BLE001
            R.add("G4", f"{fn} 可解析", False, str(e)[:120])
            continue
        R.add("G4", f"{fn} 可解析", True, f"{os.path.getsize(p)//1024}KB")
        if keys:
            miss = [k for k in keys if k not in d]
            R.add("G4", f"{fn} 必要键齐全", not miss, f"缺={miss}" if miss else "")

    # 价库每条须有四要素 + 置信度三档之一
    try:
        d = json.load(open(os.path.join(DATA_DIR, "material_prices.json"), encoding="utf-8"))
        bad, total = [], 0
        for cat, ci in (d.get("materials") or {}).items():
            for spec, si in ((ci or {}).get("specs") or {}).items():
                for pr in (si or {}).get("periods") or []:
                    total += 1
                    missing = [k for k in ("期号", "口径", "计价地区", "价格", "置信度")
                               if pr.get(k) in (None, "")]
                    conf = pr.get("置信度")
                    if missing or conf not in ("可核", "市场核", "经验估"):
                        bad.append(f"{cat}·{spec} 缺{missing} 置信度={conf}")
        R.add("G4", f"价库 {total} 条四要素+置信度合规", not bad,
              f"{len(bad)} 条异常: {bad[:2]}")
    except Exception as e:  # noqa: BLE001
        R.add("G4", "价库逐条校验", False, str(e)[:120])


# ============================================================ G5
@group("G5 frontmatter 与指纹")
def g5():
    sp = os.path.join(ROOT, "SKILL.md")
    if not os.path.isfile(sp):
        R.add("G5", "SKILL.md 存在", False)
        return
    txt = open(sp, encoding="utf-8").read()
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", txt, re.S)
    R.add("G5", "frontmatter 区块存在", bool(m))
    if not m:
        return
    block = m.group(1)
    # 逐行解析（不依赖 PyYAML，且能避开「普通标量含 `: `」的 YAML 陷阱）
    fm = {}
    for line in block.split("\n"):
        if line.startswith("#") or not line.strip():
            continue
        mm = re.match(r"^([A-Za-z_][\w-]*):\s*(.*)$", line)
        if mm:
            fm[mm.group(1)] = mm.group(2).split("#")[0].strip()
    for k in ("name", "version", "license", "fingerprint_sha256", "total_files", "edition"):
        R.add("G5", f"frontmatter 有 {k}", k in fm, fm.get(k, "缺失"))
    R.add("G5", "license=MIT", fm.get("license") == "MIT", fm.get("license"))
    ed = fm.get("edition", "free")
    R.add("G5", "形态声明自洽（free 则 pay: 块须未启用）",
          ed != "free" or not re.search(r"^pay:\s*$", block, re.M),
          f"edition={ed}")
    R.add("G5", "description 为折叠块（避免多行普通标量 YAML 陷阱）",
          bool(re.search(r"^description:\s*[>|]", block, re.M)))
    # 指纹自洽
    import hashlib
    stored = fm.get("fingerprint_sha256", "")
    cleared = re.sub(r"^fingerprint_sha256:\s*\S+", "fingerprint_sha256:", txt, count=1, flags=re.M)
    calc = hashlib.sha256(cleared.encode("utf-8")).hexdigest()
    R.add("G5", "指纹自洽（清零重算比对）", calc == stored,
          stored[:16] + "…" if stored else "缺失")
    # total_files 与实际
    actual = (len(glob.glob(os.path.join(ROOT, "references", "*.md")))
              + len(glob.glob(os.path.join(ROOT, "scripts", "*.py")))
              + len([f for f in glob.glob(os.path.join(ROOT, "scripts", "data", "*.json"))
                     if os.path.basename(f) != "a402_orders.json"])
              + len(glob.glob(os.path.join(ROOT, "bridge", "*.py")))
              + len(glob.glob(os.path.join(ROOT, "bridge", "*.md")))
              + len(glob.glob(os.path.join(ROOT, "cost_auditor_pay", "**", "*.py"), recursive=True))
              + len(glob.glob(os.path.join(ROOT, "publish", "*.py")))
              + len(glob.glob(os.path.join(ROOT, "publish", "*.md"))))
    R.add("G5", f"total_files 与实际一致（声明 {fm.get('total_files')}）",
          str(actual) == fm.get("total_files"), f"实际={actual}")


# ============================================================ G6
@group("G6 交付契约与红线")
def g6():
    sp = os.path.join(ROOT, "SKILL.md")
    txt = open(sp, encoding="utf-8").read() if os.path.isfile(sp) else ""
    for n, kw in ((14, "形态如实申报"), (15, "测试数字必须实跑")):
        R.add("G6", f"反幻觉红线第 {n} 条在位（{kw}）", kw in txt)
    R.add("G6", "维护记录存在", "## 维护记录" in txt)
    R.add("G6", "结构树登记 selftest_all.py", "selftest_all.py" in txt)
    R.add("G6", "形态声明块存在（免费/付费切换指引）", "CAP_EDITION" in txt)
    R.add("G6", "四不原则在位（图纸算量）", "图纸算量四不原则" in txt)
    # 双形态代码在位
    for rel, needle in (("cost_auditor_pay/config.py", "PAY_REQUIRED"),
                        ("cost_auditor_pay/main.py", "FREE_MODE"),
                        ("scripts/payment_gate.py", "FREE_MODE"),
                        ("scripts/privacy_scan.py", "_is_protected"),
                        ("publish/privacy_scan.py", "ALLOW_VALUES")):
        p = os.path.join(ROOT, rel.replace("/", os.sep))
        ok = os.path.isfile(p) and needle in open(p, encoding="utf-8").read()
        R.add("G6", f"{rel} 含 {needle}", ok)


# ============================================================ main
def main():
    for name, fn in GROUPS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            R.add(name[:2], f"{name} 组执行异常", False, f"{type(e).__name__}: {e}"[:150])

    total = len(R.rows)
    passed = total - len(R.failed)
    if AS_JSON:
        print(json.dumps({"total": total, "passed": passed,
                          "failed": len(R.failed), "results": R.rows},
                         ensure_ascii=False, indent=2))
        sys.exit(0 if not R.failed else 1)

    cur = None
    for r in R.rows:
        if r["group"] != cur:
            cur = r["group"]
            print(f"\n──────── {cur} ────────")
        flag = "✅" if r["ok"] else "❌"
        line = f"  {flag} {r['name']}"
        if not r["ok"] and r["detail"]:
            line += f"  · {r['detail']}"
        print(line)

    print("\n" + "=" * 60)
    print(f"回归测试台：{passed}/{total} 通过"
          f"（{len(GROUPS)} 组）")
    if R.failed:
        print("失败项：")
        for r in R.failed:
            print(f"  - [{r['group']}] {r['name']}  {r['detail']}")
    print("=" * 60)
    sys.exit(0 if not R.failed else 1)


if __name__ == "__main__":
    main()
