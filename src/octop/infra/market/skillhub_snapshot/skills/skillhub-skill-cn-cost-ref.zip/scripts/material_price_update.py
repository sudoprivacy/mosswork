#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
material_price_update.py — 本地材料价格库 月度增量更新器（可写脚本）

对应思路（参照 zaojia_update_daily.py：读历史 → 执行 → 输出 → 记录摘要）：
每个自然月把当月新增/修正的材料信息价、市场核价追加进价库，保留历史多期快照。

数据纪律（违反即不可入）：
  ① 价格必须带「期号 + 口径 + 计价地区 + 来源」四要素；
  ② 四要素不齐 → 只能标 置信度=经验估（待校档），不得静默当作权威价；
  ③ 历史期快照不物理删除（本工具只 add/update 当期，不删旧期）；
  ④ 同 (类别,规格,期号,地区,口径) 幂等覆盖（update 改错价用），不影响别期；
  ⑤ 每次成功写入自动在 meta.changelog 追加一行。

用法：
    python3 material_price_update.py add <类别> <规格> --price P --period 2026-08 \
            --region 广州 --basis 市场价 --source "百年建筑2026-08" [--unit t] [--conf 市场核]
    python3 material_price_update.py update <类别> <规格> --price P --period 2026-08 ...  # 改当期错价
    python3 material_price_update.py batch --file newmonth.json   # 单月批量（见下格式）
    python3 material_price_update.py log [--since 2026-08]        # 查变更日志
    python3 material_price_update.py list                          # 列出全部类别/规格

batch 文件格式（JSON 数组）:
[ {"类别":"钢筋","规格":"HRB400E Φ12-25","单元":"t","期号":"2026-08","口径":"市场价",
   "计价地区":"广州","价格":3300,"来源":"...","置信度":"市场核","备注":""}, ... ]
"""
import json, os, sys, argparse, datetime

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'material_prices.json')
CONF = {'可核', '市场核', '经验估'}   # 置信度取值


def load():
    with open(DATA, encoding='utf-8') as f:
        return json.load(f)


def save(d):
    tmp = DATA + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DATA)          # 原子写，防中断损坏


def log(d, action, note):
    d['meta'].setdefault('changelog', []).append(
        {'date': datetime.date.today().isoformat(), 'action': action, 'note': note})
    d['meta']['last_publish'] = max(
        (p['期号'] for c in d['materials'].values()
         for s in (c.get('specs') or {}).values() for p in s.get('periods', [])),
        default=d['meta'].get('last_publish', ''))


def validate(price, period, region, basis, source, conf, unit):
    """可执行的四要素纪律（对齐 material-price-guide.md §二三条硬纪律）：
    ① 价格须为正数；② 期号须 YYYY-MM；③ 置信度须为 CONF 三档之一（可核/市场核/经验估）；
    ④ 可核/市场核 = 可溯权威价 → 来源必填，缺来源不得冒充权威价入库；
       经验估   = 凭经验待校价 → 四要素可缺来源，属低置信度档，不冒充权威价。
    （批量/单条均须过此闸，杜绝「缺来源却标市场核」静默入库。）"""
    if not isinstance(price, (int, float)) or price <= 0:
        sys.exit('[x] 价格必须为正数')
    if not re_full(period):
        sys.exit('[x] 期号格式须 YYYY-MM，如 2026-08')
    if conf not in CONF:
        sys.exit(f'[x] 置信度须为 {CONF} 之一，不是 "{conf}"')
    if conf in ('可核', '市场核') and not (source or '').strip():
        sys.exit(f'[x] 置信度="{conf}" 属可溯权威价，须带「来源」；缺来源只能标 经验估（待校）')


def re_full(s):
    import re
    return bool(re.match(r'^\d{4}-\d{2}$', s or ''))


# ---------------------------------------------------------------------------
# source_id 自动归属：每条价入库即挂批次，杜绝「溯源断裂」需手工补
# ---------------------------------------------------------------------------
_BATCH_TYPE = {'信息价税前': '造价站信息价', '信息价含税': '造价站信息价',
               '市场价': '市场询价', '合同暂估': '厂家报价(暂估)'}
_BATCH_REL = {'可核': '可核', '市场核': '市场核', '经验估': '经验估'}


def ensure_batch(d, source, period, region, basis, conf):
    """按(来源, 期号)在 meta.source_batches 中归属批次；已存在则复用，否则自动登记。
    批次 ID 由 来源+期号 派生，可复现；同来源同期必落到同一批次。
    返回 source_id。"""
    import hashlib
    batches = d.setdefault('meta', {}).setdefault('source_batches', {})
    src = (source or '').strip()
    # 1) 复用：同 issuer 且同 period
    for bid, b in batches.items():
        if b.get('period') == period:
            iss = str(b.get('issuer', ''))
            if src and (iss == src or src in iss or iss in src):
                return bid
    # 2) 新建：ID = X + md5(来源|期号) 前6位大写（可复现，不含中文/空格）
    suffix = hashlib.md5(f'{src}|{period}'.encode('utf-8')).hexdigest()[:6].upper()
    bid = f'X{suffix}'
    if bid in batches:  # 极小概率碰撞，退化为全长度
        bid = 'X' + hashlib.md5(f'{src}|{period}'.encode('utf-8')).hexdigest()[:10].upper()
    batches[bid] = {
        'source_type': _BATCH_TYPE.get(basis, '市场询价'),
        'issuer': src or '（未注明来源）',
        'period': period,
        'region': region or '',
        'caliber': basis or '',
        'reliability': _BATCH_REL.get(conf, '经验估'),
        'desc': f'{src} {period} {region or ""} {basis or ""}',
        'source_note': '由 material_price_update 入库时自动登记；须与实际来源文件/询价单核对',
        'auto_generated': True,
    }
    return bid


def upsert(d, a, mode):
    """mode: add 或 update"""
    # 统一过纪律闸：单条 add/update 与 batch（均落于此）必须先过 validate
    validate(a.price, a.period, a.region, a.basis, a.source, a.conf, a.unit)
    # 入库即挂批次：先算 source_id，随记录一同写入，避免事后溯源断裂
    sid = ensure_batch(d, a.source, a.period, a.region, a.basis, a.conf)
    cat, spec = a.cat.strip(), a.spec.strip()
    if cat not in d['materials']:
        d['materials'][cat] = {'类别说明': '', 'specs': {}}
    ci = d['materials'][cat].setdefault('specs', {})
    if spec not in ci:
        ci[spec] = {'单元': a.unit or ''}
    periods = ci[spec].setdefault('periods', [])
    # 同(期号,地区,口径)是否已存在
    idx = next((i for i, p in enumerate(periods)
                if p.get('期号') == a.period and p.get('计价地区') == a.region
                and p.get('口径') == a.basis), None)
    new = {'期号': a.period, '口径': a.basis, '计价地区': a.region, '价格': a.price,
           '来源': a.source, '置信度': a.conf, '备注': a.note or '',
           'source_id': sid}
    if mode == 'update':
        if idx is None:
            sys.exit(f'[x] update 目标不存在（{cat}·{spec} @{a.period} {a.region} {a.basis}）。用 add 新增')
        old = periods[idx]
        periods[idx] = new
        action = 'update'
        note = f"改价 {cat}·{spec} @{a.period}: {old.get('价格')} → {a.price}（{a.region} {a.basis}）"
    else:  # add
        if idx is not None:
            # 幂等：同键已存在，仅覆盖价格与来源，不改历史（视为补录修正）
            periods[idx] = new
            action = 'add'
            note = f"补录/更新 {cat}·{spec} @{a.period} {a.region} {a.basis}={a.price}"
        else:
            periods.append(new)
            periods.sort(key=lambda x: x.get('期号', ''), reverse=True)  # 新期在前
            action = 'add'
            note = f"新增 {cat}·{spec} @{a.period}={a.price} {a.region} {a.basis}"
    log(d, action, note)
    save(d)
    print(f'[√] {action}: {note}')
    print(f'    来源: {a.source} 置信度: {a.conf}')
    print(f'    溯源: source_id={sid} → {d["meta"]["source_batches"][sid].get("issuer", "")}')


def batch(d, a):
    with open(a.file, encoding='utf-8') as f:
        items = json.load(f)
    n_add = n_upd = 0
    for it in items:
        # 为每项构造 argparse.Namespace
        ns = argparse.Namespace(
            cat=it['类别'], spec=it['规格'], unit=it.get('单元', ''),
            period=it['期号'], region=it.get('计价地区', '广州'),
            basis=it.get('口径', '市场价'), price=it['价格'],
            source=it.get('来源', ''), conf=it.get('置信度', '市场核'), note=it.get('备注', ''))
        before = json.dumps(d['materials'].get(ns.cat, {}).get('specs', {}).get(ns.spec, {}), ensure_ascii=False)
        upsert(d, ns, 'add')
        after = json.dumps(d['materials'].get(ns.cat, {}).get('specs', {}).get(ns.spec, {}), ensure_ascii=False)
        if before == after:
            n_upd += 1
        else:
            n_add += 1
    print(f'\n批量完成：新增 {n_add}，未变化/幂等 {n_upd}（累计）')


def cmd_log(d, a):
    logs = d['meta'].get('changelog', [])
    if a.since:
        logs = [x for x in logs if x.get('date', '') >= a.since]
    print(f'\n变更日志（{len(logs)} 条）:')
    for x in reversed(logs[-60:]):
        print(f"  [{x.get('date')}] {x.get('action',''):<8}{x.get('note','')}")


def cmd_list(d, a):
    print('\n当前价库材料（类别·规格 → 最新期号）:')
    for cat, ci in d['materials'].items():
        print(f"  · {cat}")
        for spec, si in (ci.get('specs') or {}).items():
            per = si.get('periods', [])
            latest = per[0].get('期号') if per else '空'
            n = len(per)
            print(f"      - {spec:<22} 期数={n} 最新={latest}")


def main():
    p = argparse.ArgumentParser(description='本地材料价格库 月度增量更新器')
    sub = p.add_subparsers(dest='cmd')

    def add_common(sp):
        sp.add_argument('cat'); sp.add_argument('spec')
        sp.add_argument('--price', type=float, required=True)
        sp.add_argument('--period', required=True, help='YYYY-MM')
        sp.add_argument('--region', default='广州')
        sp.add_argument('--basis', default='市场价', help='信息价税前/市场价/合同暂估/信息价含税')
        sp.add_argument('--source', required=True, help='四要素之一：来源')
        sp.add_argument('--unit', default='')
        sp.add_argument('--conf', default='市场核', choices=['可核', '市场核', '经验估'])
        sp.add_argument('--note', default='')

    ad = sub.add_parser('add'); add_common(ad)
    up = sub.add_parser('update'); add_common(up)
    b = sub.add_parser('batch'); b.add_argument('--file', required=True)
    l = sub.add_parser('log'); l.add_argument('--since', default=None)
    sub.add_parser('list')

    a = p.parse_args()
    if not a.cmd:
        p.print_help(); return
    d = load()
    if a.cmd == 'add':
        upsert(d, a, 'add')
    elif a.cmd == 'update':
        upsert(d, a, 'update')
    elif a.cmd == 'batch':
        batch(d, a)
    elif a.cmd == 'log':
        cmd_log(d, a)
    elif a.cmd == 'list':
        cmd_list(d, a)


if __name__ == '__main__':
    main()
