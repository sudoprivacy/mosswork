#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
alipay_payment_gateway.py — 造价稽核官 · 支付宝 AI 按量付费(A2M/A402)真实接入网关(卖端)

覆盖支付宝 AI 按量付费审核的五个必查点：
  ① 402 账单下发 (Payment-Needed / Payment-Proof, Base64URL)
  ② 携带 Payment-Proof 凭证重试
  ③ 验付调用 (alipay.aipay.agent.payment.verify, SDK Model 类)
  ④ 履约确认 (alipay.aipay.agent.fulfillment.confirm, SDK Model 类)
  ⑤ 订单持久化与幂等 (repository 端口 + (resource_id, out_trade_no) 幂等键)

架构(对齐支付宝官方 A2M,非自建三端点):
  - 资源走【单一路径】资源接口: 无有效 Payment-Proof → HTTP 402 + Payment-Needed 账单;
    携 Payment-Proof → 验付(官方 SDK) → 履约(官方 SDK) → 返回资源内容。
  - 商家账单签名 RSA2,仅在商家本地完成(8 字段按 key 字典序签名),不请求支付宝。
  - 验付/履约通过支付宝开放平台网关 gateway.do + 官方 Python SDK,
    使用 Model 类(alipay-sdk-python 3.7+ 必须用 Model,不能 dict 直接赋给 biz_model)。

依赖(需安装,非标准库):
  pip install alipay-sdk-python pycryptodome flask

用法(命令行演示 + Web 资源端点):
  python3 alipay_payment_gateway.py demo                      # 控制流演示(无密钥→仅结构/沙箱模拟,明示非真实资金)
  python3 alipay_payment_gateway.py print-bill <resource_id> <amount>  # 打印一张真实结构的 Payment-Needed 账单
  python3 alipay_payment_gateway.py status <out_trade_no>     # 查订单状态
  python3 alipay_payment_gateway.py serve --port 8000         # 起 Web 资源端点(Flask)

反幻觉纪律(升级,守住不伪造):
  - 未配置 AIPAY_APP_ID/AIPAY_PRIVATE_KEY/AIPAY_ALIPAY_PUBLIC_KEY → 不初始化真实 SDK client,
    验付/履约只走【明示模拟】并打 mock=True,绝不伪造"已通过支付宝验付/已履约/已收款"。
  - 真实验付只认支付宝 gateway 返回 code==10000 且 active=true、金额/out_trade_no/resource_id 全对上;
    不凭 Payment-Proof 客户端自述放行资源。
  - 仅 PAID→(履约确认成功)→FULFILLED 才返回资源;已 FULFILLED 幂等返回,不二次扣款/重复发货。

密钥(环境变量,不入代码/git): AIPAY_APP_ID / AIPAY_PRIVATE_KEY(PKCS#1 Base64) /
  AIPAY_ALIPAY_PUBLIC_KEY / AIPAY_SELLER_ID(2088) / AIPAY_SERVICE_ID / AIPAY_GATEWAY
"""

import base64
import json
import os
import re
import time
import uuid
from decimal import Decimal
from datetime import datetime, timedelta, timezone
from urllib.parse import quote, unquote  # noqa: F401  (兼容/扩展用)

# ---------------------------------------------------------------------------
# 一、配置：环境变量(真实密钥) + 依赖门控
# ---------------------------------------------------------------------------
ENV_KEYS = ["AIPAY_APP_ID", "AIPAY_PRIVATE_KEY", "AIPAY_ALIPAY_PUBLIC_KEY",
            "AIPAY_SELLER_ID", "AIPAY_SERVICE_ID", "AIPAY_GATEWAY"]
GATEWAY_SANDBOX = "https://openapi-sandbox.dl.alipaydev.com/gateway.do"
GATEWAY_PROD = "https://openapi.alipay.com/gateway.do"
# 沙箱唯一允许的 service_id；生产必须替换为服务市场真实 serviceId
SANDBOX_SERVICE_ID = "api_mock_service_id"
# 造价稽核官默认资源定义: resource_id -> (goods_name, 单价元)
DEFAULT_RESOURCES = {
    "BOQ_REVIEW_ONCE": ("工程量清单一次复核", "0.99"),
    "UNIT_PRICE_AUDIT": ("综合单价审核(单条)", "2.99"),
    "SETTLEMENT_QUERY": ("结算争议/索赔检索", "1.99"),
}


def env(key, default=""):
    return os.environ.get(key, default)


def is_real_config() -> bool:
    """是否具备真实验付所需密钥(appId + 商户私钥 + 支付宝公钥)。"""
    return bool(env("AIPAY_APP_ID") and env("AIPAY_PRIVATE_KEY")
                and env("AIPAY_ALIPAY_PUBLIC_KEY") and env("AIPAY_SELLER_ID"))


def is_sandbox_mode() -> bool:
    """沙箱联调判定：gateway 指向沙箱 且 service_id 为 mock。"""
    gw = env("AIPAY_GATEWAY", GATEWAY_SANDBOX)
    svc = env("AIPAY_SERVICE_ID", SANDBOX_SERVICE_ID)
    return gw == GATEWAY_SANDBOX and svc == SANDBOX_SERVICE_ID


# ---------------------------------------------------------------------------
# 二、订单持久化 repository：默认本地 JSON(非内存) + 幂等键；项目可换 DB
# ---------------------------------------------------------------------------
# 官方要求：验付/履约前订单必须真实持久化；禁止回退进程内存。
# 本骨架默认提供 JsonOrderRepository(单机/演示可用，写盘非内存)，
# 正式项目可用 configure_order_repository() 绑定自有 DB 实现(见下)。
# 幂等键： (resource_id, out_trade_no)。
ORDERS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "a402_orders.json")
# 状态机：order_status  PAY = PENDING_PAYMENT/PAID；fulfill_status = UNFULFILLED/PENDING_CONFIRM/FULFILLED


class OrderRepository:
    """订单仓库抽象接口(官方端口)。实现须提供:
       create_pending / find_by_out_trade_no / prepare_fulfillment / mark_fulfilled
    """
    def create_pending(self, order):  raise NotImplementedError
    def find_by_out_trade_no(self, out_trade_no):  raise NotImplementedError
    def prepare_fulfillment(self, ctx):  raise NotImplementedError
    def mark_fulfilled(self, out_trade_no, trade_no):  raise NotImplementedError


def order_key(resource_id, out_trade_no):
    """幂等键：resource_id + out_trade_no 哈希。"""
    import hashlib
    return hashlib.sha256(f"{resource_id}|{out_trade_no}".encode()).hexdigest()[:32]


class JsonOrderRepository(OrderRepository):
    """本地 JSON 文件实现(演示/单机)。生产建议换数据库以保证事务+唯一约束。"""

    def __init__(self, path=ORDERS_FILE):
        self.path = path

    def _load(self):
        if os.path.exists(self.path):
            try:
                with open(self.path, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save(self, orders):
        d = os.path.dirname(self.path)
        if d:
            os.makedirs(d, exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(orders, f, ensure_ascii=False, indent=2)
        os.replace(tmp, self.path)

    def create_pending(self, order):
        orders = self._load()
        k = order_key(order["resource_id"], order["out_trade_no"])
        if k not in orders:
            rec = dict(order)
            rec["key"] = k
            rec["order_status"] = order.get("order_status", "PENDING_PAYMENT")
            rec["fulfill_status"] = order.get("fulfill_status", "UNFULFILLED")
            rec["created"] = time.strftime("%Y-%m-%d %H:%M:%S")
            rec["updated"] = rec["created"]
            rec["times"] = 1
            orders[k] = rec
            self._save(orders)
            return rec
        rec = orders[k]
        rec["times"] = rec.get("times", 0) + 1
        rec["updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self._save(orders)
        return rec

    def find_by_out_trade_no(self, out_trade_no):
        for rec in self._load().values():
            if rec.get("out_trade_no") == out_trade_no:
                return rec
        return None

    def prepare_fulfillment(self, ctx):
        """原子准备履约：订单须处于可履约态，只生成一次资源。
        返回 {state: PENDING_CONFIRM|FULFILLED, service_result: <资源>}。
        """
        orders = self._load()
        k = order_key(ctx["expected_resource_id"], ctx["out_trade_no"])
        rec = orders.get(k)
        if not rec:
            return None
        # 已履约 → 直接复用
        if rec.get("fulfill_status") == "FULFILLED":
            return {"state": "FULFILLED", "service_result": rec.get("service_result"),
                    "trade_no": rec.get("trade_no")}
        # 已进入待确认但无结果 → 视为异常(真实DB用行锁/唯一约束防并发)
        if rec.get("fulfill_status") == "PENDING_CONFIRM" and rec.get("service_result"):
            return {"state": "PENDING_CONFIRM", "service_result": rec["service_result"]}
        # 生成一次资源并落 PENDING_CONFIRM
        result = ctx["create_resource"](ctx["expected_resource_id"], ctx.get("payload"))
        rec["fulfill_status"] = "PENDING_CONFIRM"
        rec["service_result"] = result
        rec["trade_no"] = ctx.get("trade_no", rec.get("trade_no"))
        rec["order_status"] = "PAID"
        rec["updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
        orders[k] = rec
        self._save(orders)
        return {"state": "PENDING_CONFIRM", "service_result": result, "trade_no": ctx.get("trade_no")}

    def mark_fulfilled(self, out_trade_no, trade_no):
        orders = self._load()
        for rec in orders.values():
            if rec.get("out_trade_no") == out_trade_no:
                rec["fulfill_status"] = "FULFILLED"
                rec["order_status"] = "PAID"
                if trade_no:
                    rec["trade_no"] = trade_no
                rec["updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
                self._save(orders)
                return rec
        return None


_ORDER_REPO = JsonOrderRepository()  # 默认


def configure_order_repository(repo):
    """绑定项目真实持久化实现(官方端口)。缺失必需方法时明确失败。"""
    required = ("create_pending", "find_by_out_trade_no", "prepare_fulfillment", "mark_fulfilled")
    if repo is None or any(not callable(getattr(repo, m, None)) for m in required):
        raise RuntimeError("order_repository 必须实现 " + ", ".join(required)
                           + "；禁止回退到内存订单")
    global _ORDER_REPO
    _ORDER_REPO = repo


def repo():
    return _ORDER_REPO


# ---------------------------------------------------------------------------
# 三、工具：金额归一、时区时间戳、Base64URL、RSA2 商家账单签名
# ---------------------------------------------------------------------------
def normalize_amount(value):
    text = str(value or "").strip()
    if not re.fullmatch(r"\d+(?:\.\d{1,2})?", text):
        return None
    return f"{Decimal(text):.2f}"


def amounts_equal(left, right):
    l, r = normalize_amount(left), normalize_amount(right)
    return l is not None and r is not None and l == r


def is_future(value):
    try:
        return datetime.fromisoformat(value).timestamp() > time.time()
    except (TypeError, ValueError):
        return False


def alipay_timestamp(dt=None):
    return (dt or datetime.now()).strftime("%Y-%m-%d %H:%M:%S")


def base64url_encode(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("utf-8")


def base64url_decode(data):
    pad = 4 - len(data) % 4
    if pad != 4:
        data += "=" * pad
    return base64.urlsafe_b64decode(data).decode("utf-8")


def generate_seller_signature(params, private_key_pkcs1_b64):
    """RSA2(PKCS#1 v1.5 + SHA256)商家账单签名。
    params 按 key 字典序拼 k=v 后 & 连接；private_key 为裸 PKCS#1 Base64。
    """
    from Crypto.Signature import pkcs1_15
    from Crypto.Hash import SHA256
    from Crypto.PublicKey import RSA
    sorted_keys = sorted(params.keys())
    sign_content = [f"{k}={params[k]}" for k in sorted_keys
                    if params[k] is not None and params[k] != ""]
    sign_string = "&".join(sign_content)
    key = RSA.import_key(base64.b64decode(private_key_pkcs1_b64, validate=True))
    h = SHA256.new(sign_string.encode("utf-8"))
    return base64.b64encode(pkcs1_15.new(key).sign(h)).decode("utf-8")


# ---------------------------------------------------------------------------
# 四、支付宝 SDK 客户端(门控：无密钥不初始化，不伪造)
# ---------------------------------------------------------------------------
def init_alipay_client():
    """初始化支付宝 SDK 客户端。仅在具备真实密钥时可用，否则抛错(呼入方须捕获)。
    配置字段与官方 alipay-sdk-python 对齐。
    """
    if not is_real_config():
        raise RuntimeError("未配置 AIPAY_APP_ID/AIPAY_PRIVATE_KEY/AIPAY_ALIPAY_PUBLIC_KEY/"
                           "AIPAY_SELLER_ID，无法初始化真实支付宝 SDK；禁止伪造验付结果。")
    from alipay.aop.api.AlipayClientConfig import AlipayClientConfig
    from alipay.aop.api.DefaultAlipayClient import DefaultAlipayClient
    cfg = AlipayClientConfig()
    cfg.server_url = env("AIPAY_GATEWAY", GATEWAY_SANDBOX)
    cfg.app_id = env("AIPAY_APP_ID")
    cfg.app_private_key = env("AIPAY_PRIVATE_KEY")
    cfg.alipay_public_key = env("AIPAY_ALIPAY_PUBLIC_KEY")
    cfg.charset = "utf-8"
    cfg.sign_type = "RSA2"
    return DefaultAlipayClient(alipay_client_config=cfg)


def _seller_config():
    return {
        "app_id": env("AIPAY_APP_ID"),
        "seller_id": env("AIPAY_SELLER_ID"),
        "service_id": env("AIPAY_SERVICE_ID", SANDBOX_SERVICE_ID),
        "seller_name": env("AIPAY_SELLER_NAME", "造价稽核官"),
        "private_key": env("AIPAY_PRIVATE_KEY"),
    }


# ---------------------------------------------------------------------------
# 五、① 402 账单下发 (Payment-Needed / Payment-Proof) + ⑤ 幂等建单
# ---------------------------------------------------------------------------
def build_bill(resource_id, amount, goods_name=None, currency="CNY", ttl_minutes=30):
    """构造 Payment-Needed(两层 structure)并 Base64URL 编码。真实签名(有私钥)/占位(无密钥)。
    返回 (payment_needed, bill, out_trade_no)。
    """
    cfg = _seller_config()
    if goods_name is None:
        goods_name = DEFAULT_RESOURCES.get(resource_id, ("按量资源", "0.01"))[0]
    out_trade_no = f"ORDER_{int(time.time()*1000)}_{uuid.uuid4().hex[:12]}"
    pay_before = (datetime.now(timezone.utc).astimezone() + timedelta(minutes=ttl_minutes)).isoformat()
    sign_fields = {
        "amount": normalize_amount(amount),
        "currency": currency,
        "goods_name": goods_name,
        "out_trade_no": out_trade_no,
        "pay_before": pay_before,
        "resource_id": resource_id,
        "seller_id": cfg["seller_id"],
        "service_id": cfg["service_id"],
    }
    if cfg["private_key"]:
        seller_signature = generate_seller_signature(sign_fields, cfg["private_key"])
        sig_note = "RSA2(真实商家签名)"
    else:
        # 反幻觉：无私钥只给占位符并明示，绝不假装已签名。
        seller_signature = "MOCK_SIGNATURE_NO_PRIVATE_KEY"
        sig_note = "占位(MOCK,未配置私钥)"
    protocol = {
        "out_trade_no": out_trade_no,
        "amount": normalize_amount(amount),
        "currency": currency,
        "resource_id": resource_id,
        "pay_before": pay_before,
        "seller_signature": seller_signature,
        "seller_sign_type": "RSA2",
        "seller_unique_id": cfg["seller_id"],
    }
    method = {
        "seller_name": cfg["seller_name"],
        "seller_id": cfg["seller_id"],
        "seller_app_id": cfg["app_id"],
        "goods_name": goods_name,
        "seller_unique_id_key": "seller_id",
        "service_id": cfg["service_id"],
    }
    bill = {"protocol": protocol, "method": method}
    payment_needed = base64url_encode(json.dumps(bill, ensure_ascii=False))
    return payment_needed, bill, out_trade_no, sig_note


def _payment_required(resource_id, amount, goods_name):
    """返回 402 响应体 + 建 PENDING 订单。"""
    payment_needed, bill, ono, sig_note = build_bill(resource_id, amount, goods_name)
    repo().create_pending({
        "out_trade_no": ono, "amount": normalize_amount(amount), "currency": "CNY",
        "resource_id": resource_id, "goods_name": goods_name,
        "pay_before": bill["protocol"]["pay_before"],
        "order_status": "PENDING_PAYMENT", "fulfill_status": "UNFULFILLED",
    })
    print(f"[账单] 402 已下发 out_trade_no={ono} amount={amount} signature={sig_note}")
    return {
        "code": "Payment-Needed", "message": "需要支付",
        "out_trade_no": ono, "amount": normalize_amount(amount),
        "currency": "CNY", "goods_name": goods_name,
        "_mock_note": None if is_real_config() else sig_note,
    }, payment_needed


# ---------------------------------------------------------------------------
# 六、③ 验付调用 (alipay.aipay.agent.payment.verify) —— SDK Model 类
# ---------------------------------------------------------------------------
def _decode_proof(payment_proof):
    """解码 Payment-Proof，读取 protocol.payment_proof / trade_no / (兼容演示)out_trade_no
    以及 method.client_session。官方 Payment-Proof 本不含 out_trade_no(由验付响应返回)，
    这里兼容读取仅用于本地模拟演示的订单定位；真实以支付宝验付响应为准。
    """
    proof = json.loads(base64url_decode(payment_proof))
    protocol = proof.get("protocol", {})
    method = proof.get("method", {})
    return {
        "payment_proof": protocol.get("payment_proof"),
        "trade_no": protocol.get("trade_no"),
        "out_trade_no": protocol.get("out_trade_no"),
        "client_session": method.get("client_session"),
    }


def call_payment_verify(pf_value, trade_no, client_session=None):
    """真实验付：调支付宝 alipay.aipay.agent.payment.verify。
    返回原始响应 dict。SDK 异常/无密钥时抛错，由调用方决定(此处不伪造)。
    """
    from alipay.aop.api.request.AlipayAipayAgentPaymentVerifyRequest import \
        AlipayAipayAgentPaymentVerifyRequest
    from alipay.aop.api.domain.AlipayAipayAgentPaymentVerifyModel import \
        AlipayAipayAgentPaymentVerifyModel
    client = init_alipay_client()
    req = AlipayAipayAgentPaymentVerifyRequest()
    model = AlipayAipayAgentPaymentVerifyModel()
    model.payment_proof = pf_value
    model.trade_no = trade_no
    if client_session:
        model.client_session = client_session
    req.biz_model = model
    content = client.execute(req)
    import json as _j
    resp = _j.loads(content)
    # SDK 返回可能扁平或嵌套在响应键下，兼容两种情况
    return resp.get("alipay_aipay_agent_payment_verify_response", resp)


def _mock_verify(proof_info):
    """无密钥的【明示模拟】验付。绝不等于真实验付。"""
    # 演示用：mock 模式下把 proof 携带的 out_trade_no 回传，便于本地订单定位；真实模式不依赖。
    ono = (proof_info or {}).get("out_trade_no") or "MOCK_OUT"
    return {
        "code": "10000", "sub_msg": "MOCK(未配置真实密钥，本响应为本地模拟，非支付宝返回)",
        "trade_no": proof_info["trade_no"] or "MOCK_" + str(uuid.uuid4().hex[:8]),
        "out_trade_no": ono,
        "amount": None, "resource_id": None, "active": True, "_mock": True,
    }


def verify_payment_flow(payment_proof, expected_amount, expected_resource_id, expected_out_trade_no):
    """完整验付流程：解码 Proof → (真实SDK 或 明示模拟) → 严格六项校验。
    返回 (ok, {reason/结果})。任一校验不过 → ok=False(上层应返 402)。
    """
    try:
        info = _decode_proof(payment_proof)
    except Exception as e:
        return False, f"Payment-Proof 解析失败: {e}"
    pf_value, proof_trade_no = info["payment_proof"], info["trade_no"]
    if not pf_value or not pf_value.strip() or not proof_trade_no or not proof_trade_no.strip():
        return False, "Payment-Proof 缺少 payment_proof 或 trade_no"

    if is_real_config():
        # 真实调用支付宝网关验付(代码结构级；真实运行需密钥已就绪)
        try:
            resp = call_payment_verify(pf_value, proof_trade_no, info.get("client_session"))
        except Exception as e:
            return False, f"支付宝验付调用异常: {e}"
    else:
        resp = _mock_verify(info)

    mock = resp.get("_mock", False)
    if str(resp.get("code")) != "10000":
        return False, f"支付宝返回非成功: {resp.get('sub_msg', resp.get('sub_code'))}"

    returned_trade_no = resp.get("trade_no") or proof_trade_no
    returned_out_trade_no = resp.get("out_trade_no") or ""
    returned_amount = resp.get("amount")
    returned_resource_id = resp.get("resource_id") or ""
    active = resp.get("active")

    order = repo().find_by_out_trade_no(expected_out_trade_no) if expected_out_trade_no else None
    # 沙箱 mock 时支付宝不回 amount/resource_id → 用本地订单兜底(仅沙箱)
    sandbox_fallback = mock and is_sandbox_mode() and order is not None
    eff_amount = returned_amount if returned_amount else (order.get("amount") if sandbox_fallback else None)
    eff_resource = returned_resource_id if returned_resource_id else (order.get("resource_id") if sandbox_fallback else None)

    # ---- 严格六项校验(官方契约) ----
    checks = {
        "active=true": active is True,
        "trade_no 非空且一致": bool(returned_trade_no) and returned_trade_no == proof_trade_no,
        "out_trade_no 匹配本地订单": bool(returned_out_trade_no) and returned_out_trade_no == expected_out_trade_no,
        "amount 匹配": eff_amount is not None and amounts_equal(expected_amount, eff_amount),
        "resource_id 匹配": bool(eff_resource) and eff_resource == expected_resource_id,
    }
    if any(not v for v in checks.values()):
        return False, "验付校验未通过: " + "; ".join(f"{k}✗" for k, v in checks.items() if not v)

    # 订单可履约性 + 幂等防重
    if order:
        fs = order.get("fulfill_status")
        in_progress = fs in ("PENDING_CONFIRM", "FULFILLED")
        usable = (order.get("currency") == "CNY"
                  and order.get("order_status") in ("PENDING_PAYMENT", "PAID")
                  and fs in ("UNFULFILLED", "PENDING_CONFIRM", "FULFILLED")
                  and (in_progress or is_future(order.get("pay_before"))))
        if not usable:
            return False, "本地订单不在可履约状态或已过期"
    return True, {
        "trade_no": returned_trade_no,
        "out_trade_no": returned_out_trade_no,
        "amount": eff_amount,
        "resource_id": eff_resource,
        "mock": mock,
    }


# ---------------------------------------------------------------------------
# 七、④ 履约确认 (alipay.aipay.agent.fulfillment.confirm) —— SDK Model 类
# ---------------------------------------------------------------------------
def call_fulfillment_confirm(trade_no):
    """真实履约确认：调支付宝 alipay.aipay.agent.fulfillment.confirm。返回 bool。"""
    from alipay.aop.api.request.AlipayAipayAgentFulfillmentConfirmRequest import \
        AlipayAipayAgentFulfillmentConfirmRequest
    from alipay.aop.api.domain.AlipayAipayAgentFulfillmentConfirmModel import \
        AlipayAipayAgentFulfillmentConfirmModel
    client = init_alipay_client()
    req = AlipayAipayAgentFulfillmentConfirmRequest()
    model = AlipayAipayAgentFulfillmentConfirmModel()
    model.trade_no = trade_no
    req.biz_model = model
    content = client.execute(req)
    import json as _j
    resp = _j.loads(content)
    data = resp.get("alipay_aipay_agent_fulfillment_confirm_response", resp)
    if str(data.get("code")) == "10000":
        return True, None
    return False, data.get("sub_msg") or data.get("sub_code")


def _mock_fulfillment_confirm(trade_no):
    return True, None  # 明示模拟：实际会由 _mock 上下文标识，不冒充真实履约


def do_fulfillment_confirm(trade_no, mock):
    if mock:
        return _mock_fulfillment_confirm(trade_no)
    return call_fulfillment_confirm(trade_no)


# ---------------------------------------------------------------------------
# 八、资源生成(占位：换你技能真实产出) —— 单路径资源接口核心
# ---------------------------------------------------------------------------
def generate_service_resource(resource_id, payload=None):
    """按 resource_id 生成造价资源。默认返回占位说明；
    当 payload 携带真实业务入参时，绑定技能真实产出(三源比价审计结论)，
    让"按次付费资源"交付的是可用的审核结果而非空壳。

    payload 支持三种形态：
      - {"kind":"audit_triple","kw":材料/检测名,"price":报价,"unit":单位,
         "cat":"材料|检测","region":可选}
          → 调 audit_triple_source.audit_material/audit_testing，返回真实虚高判定
      - {"kind":"audit_pipeline","items":[{kw,price,unit,cat,...},...],"region":可选}
          → 调 audit_pipeline 跑整条审价流水线，返回整份审价报告(多条目)
      - 其它/无 → 返回占位说明(结构演示用，不伪造审计结论)。
    """
    goods_name = DEFAULT_RESOURCES.get(resource_id, ("按量资源", "0.01"))[0]
    if payload and isinstance(payload, dict) and payload.get("kind") == "audit_triple":
        try:
            from audit_triple_source import audit_material, audit_testing, audit_policy
            kw = str(payload.get("kw", ""))
            price = float(payload.get("price", 0))
            unit = str(payload.get("unit", ""))
            cat = str(payload.get("cat", "材料"))
            region = payload.get("region")
            if cat == "检测":
                line = audit_testing(kw, price, unit, float(payload.get("qty", 1) or 1))
            else:
                line = audit_material(kw, price, unit, region, float(payload.get("qty", 1) or 1))
            pol = audit_policy(line.get("verdict", ""), cat if cat == "检测" else "材料")
            content = json.dumps({
                "service_type": "COST_AUDITOR_TRIPLE_SOURCE",
                "resource_id": resource_id,
                "goods_name": goods_name,
                "audit_kind": "三源比价(价库+检测库+政策口径)",
                "input": {"kw": kw, "price": price, "unit": unit, "cat": cat, "region": region},
                "verdict": line.get("verdict"),
                "note": line.get("note"),
                "ref_price": line.get("ref_price"),
                "source": line.get("source", "—"),
                "policy_basis": pol.get("hint"),
                "generated_at": datetime.now(timezone.utc).astimezone().isoformat(),
            }, ensure_ascii=False)
            return content
        except Exception as e:  # noqa: BLE001
            # 绑定真实产出失败 → 不伪造，明示失败原因，回退占位
            return json.dumps({
                "status": "resource_generation_fallback",
                "resource_id": resource_id,
                "goods_name": goods_name,
                "content": f"【造价稽核官】资源 {resource_id}：真实审计产出绑定失败，需人工核对。原因: {e}",
                "generated_at": datetime.now(timezone.utc).astimezone().isoformat(),
            }, ensure_ascii=False)
    # payload kind=audit_pipeline → 跑审价流水线，返回整份审价报告(多条目)
    if payload and isinstance(payload, dict) and payload.get("kind") == "audit_pipeline":
        try:
            from audit_pipeline import run_one, render_md
            region = payload.get("region")
            lines = payload.get("items") or []
            results = [run_one({"kw": str(it.get("kw", "")), "price": float(it.get("price", 0)),
                                "unit": str(it.get("unit", "")), "qty": float(it.get("qty", 1) or 1),
                                "cat": str(it.get("cat", "材料"))}, region) for it in lines]
            md = render_md(results, region, f"payload({len(lines)} 项)")
            content = json.dumps({
                "service_type": "COST_AUDITOR_PIPELINE",
                "resource_id": resource_id,
                "goods_name": goods_name,
                "audit_kind": "审价流水线(溯源+三源比价+汇总)",
                "region": region,
                "row_count": len(results),
                "report": md,
                "generated_at": datetime.now(timezone.utc).astimezone().isoformat(),
            }, ensure_ascii=False)
            return content
        except Exception as e:  # noqa: BLE001
            return json.dumps({
                "status": "resource_generation_fallback",
                "resource_id": resource_id,
                "goods_name": goods_name,
                "content": f"【造价稽核官】资源 {resource_id}：审价流水线产出失败，需人工核对。原因: {e}",
                "generated_at": datetime.now(timezone.utc).astimezone().isoformat(),
            }, ensure_ascii=False)
    return json.dumps({
        "status": "success",
        "service_type": "COST_AUDITOR_RESOURCE",
        "resource_id": resource_id,
        "goods_name": goods_name,
        "content": f"【造价稽核官】资源 {resource_id} 内容(示例，可替换为真实审核产出)",
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(),
    }, ensure_ascii=False)


# ---------------------------------------------------------------------------
# 九、单路径资源接口主入口(供 Flask/CLI/Agent 复用)
# ---------------------------------------------------------------------------
def handle_resource_request(resource_id, payment_proof=None, amount=None, goods_name=None,
                            payload=None):
    """统一资源入口：
       - 无有效 Payment-Proof → (402, body, Payment-Needed header)
       - 携 Proof 且验付通过 → 履约确认 → (200, 资源)
       - 验付失败/校验不过 → (402, body, None)
    payload: 可选业务入参(dict)，在首次生成资源时透传给 create_resource，
             用于绑定真实审计产出(见 generate_service_resource)；幂等重试返回已存结果。
    返回 (http_status, response_dict, payment_needed_header_or_None)。
    """
    if resource_id not in DEFAULT_RESOURCES and not goods_name:
        return 404, {"error": f"resource_id 未注册: {resource_id}"}, None
    if amount is None:
        amount = DEFAULT_RESOURCES.get(resource_id, ("", "0.01"))[1]
    if goods_name is None:
        goods_name = DEFAULT_RESOURCES.get(resource_id, ("按量资源", ""))[0]
    if not payment_proof or not payment_proof.strip():
        body, header = _payment_required(resource_id, amount, goods_name)
        return 402, body, header

    # 有 Proof：先按幂等查单(已 FULFILLED → 直接复用资源，不二次扣款)
    # 由于 order 是在 402 下发时创建，故先解析 proof 内的 out_trade_no 定位订单
    try:
        pfi = _decode_proof(payment_proof)
        proto_out = pfi.get("out_trade_no")  # 部分客户端会在 protocol 带 out_trade_no
    except Exception:
        proto_out = None
    # 兼容：从 body 传的 expected 单号优先
    # 说明：官方 A2M 验付响应才返回 out_trade_no；若客户端未在 proof 带 ono，
    # 我们以支付宝验付返回的 out_trade_no 为准(见 verify_payment_flow)。
    ok, info_or_err = verify_payment_flow(payment_proof, amount, resource_id, proto_out or "")
    if not ok:
        print(f"[验付未过] {info_or_err}")
        return 402, {"code": "Payment-Needed", "message": "需要支付/凭证无效", "detail": info_or_err}, None

    # 取验付确认的 out_trade_no 定位订单
    verified_out = info_or_err.get("out_trade_no") or proto_out or ""
    order = repo().find_by_out_trade_no(verified_out) if verified_out else None
    if order and order.get("fulfill_status") == "FULFILLED" and order.get("service_result"):
        # 幂等：已履约直接返回已存资源
        return 200, _resource_response(order["trade_no"], verified_out, resource_id,
                                       order["service_result"], already_fulfilled=True), None

    # 准备履约(原子生成一次资源)
    fulfillment = repo().prepare_fulfillment({
        "out_trade_no": verified_out,
        "trade_no": info_or_err.get("trade_no"),
        "expected_amount": info_or_err.get("amount"),
        "expected_resource_id": resource_id,
        "create_resource": generate_service_resource,
        "payload": payload,
    })
    if not fulfillment or fulfillment.get("state") not in ("PENDING_CONFIRM", "FULFILLED") \
            or not fulfillment.get("service_result"):
        return 502, {"code": "PREPARE_FULFILLMENT_FAILED", "message": "履约准备失败"}, None
    service_result = fulfillment["service_result"]
    if fulfillment.get("state") == "FULFILLED":
        return 200, _resource_response(info_or_err.get("trade_no"), verified_out, resource_id,
                                       service_result, already_fulfilled=True), None

    # 履约确认成功后才返回资源
    confirm_ok, confirm_err = do_fulfillment_confirm(fulfillment.get("trade_no")
                                                     or info_or_err.get("trade_no"),
                                                     info_or_err.get("mock", False))
    if not confirm_ok:
        print(f"[履约确认失败] {confirm_err}")
        return 502, {"code": "FULFILLMENT_CONFIRM_FAILED",
                     "message": "资源已生成但履约确认失败，请用同一 Payment-Proof 重试"}, None
    repo().mark_fulfilled(verified_out, fulfillment.get("trade_no") or info_or_err.get("trade_no"))
    return 200, _resource_response(info_or_err.get("trade_no"), verified_out, resource_id,
                                   service_result, already_fulfilled=False), None


def _resource_response(trade_no, out_trade_no, resource_id, content, already_fulfilled):
    return {
        "resource_id": resource_id,
        "content": content,
        "trade_no": trade_no,
        "out_trade_no": out_trade_no,
        "already_fulfilled": already_fulfilled,
        "fulfillment_confirmed": True,
    }


# ---------------------------------------------------------------------------
# 十、Flask Web 资源端点(可选卖端 API)
# ---------------------------------------------------------------------------
def create_app():
    from flask import Flask, request, Response
    import json as _j
    app = Flask(__name__)

    @app.route("/resource/<resource_id>", methods=["GET", "POST"])
    def resource_endpoint(resource_id):
        proof = request.headers.get("Payment-Proof")
        body = _j.dumps({"status": "json"})
        try:
            status, payload, pn = handle_resource_request(
                resource_id, payment_proof=proof,
                amount=request.headers.get("X-Amount") or request.args.get("amount"),
            )
        except Exception as e:  # noqa: BLE001
            return _j.dumps({"code": "INTERNAL_ERROR", "message": str(e)},
                            ensure_ascii=False), 500
        headers = {}
        if status == 402 and pn:
            headers["Payment-Needed"] = pn
        return _j.dumps(payload, ensure_ascii=False), status, headers
    return app


def run_server(port=8000):
    app = create_app()
    mode = "真实(密钥已配置)" if is_real_config() else "模拟/结构演示(未配置真实密钥,验付与履约不打真实支付宝)"
    print(f"[造价稽核官] A2M 资源网关: http://0.0.0.0:{port}/resource/<resource_id>  [{mode}]")
    app.run(host="0.0.0.0", port=port)


# ---------------------------------------------------------------------------
# 十一、命令行演示
# ---------------------------------------------------------------------------
def cmd_demo():
    print("=" * 74)
    print("造价稽核官 · 支付宝 AI 按量付费(A2M) 真实接入控制流演示")
    print("=" * 74)
    rid = "BOQ_REVIEW_ONCE"
    if is_real_config():
        print("[模式] 真实密钥已配置 → 将调用支付宝真实网关(沙箱/生产按 AIPAY_GATEWAY)")
    else:
        print("[模式] 未配置真实密钥 → 仅【结构/模拟】演示，验付与履约不调真实支付宝、不伪造真实收款。")
    print("       真实接入需设 AIPAY_APP_ID/AIPAY_PRIVATE_KEY/AIPAY_ALIPAY_PUBLIC_KEY/AIPAY_SELLER_ID")

    print(f"\n[Step1] 请求付费资源 {rid}（无 Payment-Proof）")
    code, body, pn = handle_resource_request(rid)
    print(f"  → HTTP {code}  Payment-Needed 已下发(前60字符: {(pn or '')[:60]}...)")
    print(f"  → protocol.out_trade_no={body.get('out_trade_no')}  amount={body.get('amount')}")
    proof_for_retry = None
    try:
        b = json.loads(base64url_decode(pn))
        print(f"  → bill 结构: protocol.keys={list(b['protocol'].keys())}  method.keys={list(b['method'].keys())}")
        print(f"  → seller_signature={b['protocol']['seller_signature'][:24]}...  sign_type={b['protocol']['seller_sign_type']}")
    except Exception as e:
        print(f"  → 账单解析示意失败(不影响演示): {e}")

    print("\n[Step2] 模拟构造一个 Payment-Proof 并携带重试(仅演示验付分支，非真实支付宝凭证)")
    ono = body.get("out_trade_no")
    # 构造与本地订单匹配的 mock proof(演示用)；真实由 Agent 支付后回传
    if not is_real_config():
        mock_proof = base64url_encode(json.dumps({
            "protocol": {"payment_proof": "MOCK_PAYMENT_PROOF", "trade_no": "MOCK_TN_0001",
                         "out_trade_no": ono},
            "method": {},
        }, ensure_ascii=False))
        code2, body2, pn2 = handle_resource_request(rid, payment_proof=mock_proof)
        print(f"  → HTTP {code2}  resource={body2.get('resource_id')}  already_fulfilled={body2.get('already_fulfilled')}")
    else:
        print("  → 真实模式下请携带支付宝真实 Payment-Proof 联调(本 demo 不再本地构造假凭证)。")

    print("\n[Step3] 幂等验证：对已履约订单重复携带同一 Proof")
    if not is_real_config():
        code3, body3, pn3 = handle_resource_request(rid, payment_proof=mock_proof)
        print(f"  → HTTP {code3}  already_fulfilled={body3.get('already_fulfilled')}(应为 True,不重复履约)")
    else:
        print("  → (真实模式跳过本地幂等演示)")

    print("\n[Step4] 订单持久化状态")
    order = repo().find_by_out_trade_no(ono) if ono else None
    print(f"  → {json.dumps(order, ensure_ascii=False)[:200]}...")
    print("\n✅ 五必查点演示完成：402下发/Payment-Proof重试/验付/履约确认/持久化幂等。")
    if not is_real_config():
        print("⚠️  当前为模拟，验付/履约结果未过支付宝真实网关，仅供结构与控制流核验。")


def cmd_print_bill(resource_id, amount):
    pn, bill, ono, sig = build_bill(resource_id, amount)
    print(json.dumps({"payment_needed": pn, "bill": bill,
                      "out_trade_no": ono, "signature_note": sig},
                     ensure_ascii=False, indent=2))


def cmd_status(ono):
    order = repo().find_by_out_trade_no(ono)
    print(json.dumps({"out_trade_no": ono, "order": order}, ensure_ascii=False, indent=2))


def main():
    import argparse
    p = argparse.ArgumentParser(description="造价稽核官·支付宝 A2M 按量付费真实接入网关(卖端)")
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("demo")
    pb = sub.add_parser("print-bill"); pb.add_argument("resource_id"); pb.add_argument("amount")
    st = sub.add_parser("status"); st.add_argument("out_trade_no")
    sv = sub.add_parser("serve"); sv.add_argument("--port", type=int, default=8000)
    a = p.parse_args()
    if not a.cmd:
        p.print_help(); return
    if a.cmd == "demo": cmd_demo()
    elif a.cmd == "print-bill": cmd_print_bill(a.resource_id, a.amount)
    elif a.cmd == "status": cmd_status(a.out_trade_no)
    elif a.cmd == "serve": run_server(a.port)


if __name__ == "__main__":
    main()
