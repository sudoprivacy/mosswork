#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
material_price_lookup.py — 本地材料价格库 检索器（含调差衔接适配层）

背景：造价审计/重新组价中"材料价核减"需当期信息价（repricing-audit 六步法第④步），
但价格常散落无源。本库把广州造价站信息价 + 市场核价 + 实战核价存成本地 json，
做即时检索、多期比较、并可直接供 cost_adjuster.py 做调差。

⚠️ 效力/数据纪律（本库核心）：
  - 每个价格必须带「期号 + 口径 + 计价地区 + 来源」四要素，缺来源则只能标 置信度=经验估（待校档）；
  - 同一材料存在 信息价税前 / 含税市场价 两种口径，比价/调差前必须统一口径；
  - 本库是"半自动模板库"：造价站22种常用材已录可溯种子，其余靠
    material_price_update.py 按当期增量入库。未录材料会明确报"缺当期价"。

数据源：scripts/data/material_prices.json
用法：
    python3 material_price_lookup.py meta
    python3 material_price_lookup.py search <材料|类别> [--period 2026-07] [--region 广州]
    python3 material_price_lookup.py compare <材料> <期A> <期B> [--cat 类别] [--region 广州]
    python3 material_price_lookup.py list <类别>
    python3 material_price_lookup.py regions
    python3 material_price_lookup.py export <材料> [--json out.json] [--md out.md]
    python3 material_price_lookup.py adjust --cat 类别 --ft 2026-08 --f0 2026-03 [--mapping map.json]
    python3 material_price_lookup.py to-adjuster --ft 2026-08 --f0 2026-03 [--mapping map.json]
        → 输出 {"ft":{材料名:价},"f0":{材料名:价}}，可直接喂 cost_adjuster.py
"""
import json, os, re, sys, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data', 'material_prices.json')


def load():
    if not os.path.exists(DATA):
        sys.exit(f'[x] 价库缺失: {DATA}')
    with open(DATA, encoding='utf-8') as f:
        return json.load(f)


# ------------------------------------------------ 扁平化：产出 (材料全名, 类别, 规格, 单元, period)
def flatten(d):
    """遍历 material_prices.json → 每(类别,规格,期号)一条平铺记录"""
    out = []
    for cat, catinfo in d['materials'].items():
        for spec, sinfo in (catinfo.get('specs') or {}).items():
            unit = sinfo.get('单元', '')
            for p in sinfo.get('periods', []):
                out.append(dict(cat=cat, spec=spec, unit=unit, name=f"{cat}·{spec}",
                                **p))
    return out


def hit(r, kw, region=None):
    k = kw.lower()
    fields = [r['cat'], r['spec'], r['name'], str(r.get('来源', ''))]
    if region and r.get('计价地区', '') != region:
        return False
    return any(k in str(x).lower() for x in fields)


def latest_of(rows, region=None):
    """取每条材料在指定(或任一)地区的最新期号价格（用于速览）"""
    best = {}
    for r in rows:
        if region and r.get('计价地区', '') != region:
            continue
        key = r['name']
        if key not in best or r.get('期号', '') > best[key].get('期号', ''):
            best[key] = r
    return list(best.values())


def to_price_map(d, period, region, mapping=None):
    """提取某(期号,地区)的 {材料名: 价格} 平铺dict（调差用）。
    mapping: {类别: 目标key} 可选，用于把价库 key 映射为 cost_adjuster 期望键名。
    """
    m = {}
    for r in flatten(d):
        if r.get('期号') != period:
            continue
        if region and r.get('计价地区', '') != region:
            continue
        key = r['name']
        if mapping:
            # mapping 可含完整名 或 类别级前缀
            key = mapping.get(r['cat'], mapping.get(r['name'], key))
        m[key] = r['价格']
    return m


# ------------------------------------------------ 展示
def _show_price(p):
    src = (p.get('来源') or '')[:34]
    print(f"    [{p.get('期号')}] {p.get('口径',''):<10} {p.get('计价地区',''):<4}"
          f"{p['价格']:>10,.2f} 元/{p.get('单元','')}  {p.get('置信度',''):<6}{src}")


# ------------------------------------------------ 命令
def cmd_meta(d, a):
    m = d['meta']
    flat = flatten(d)
    specs = {(r['cat'], r['spec']) for r in flat}
    print('\n=== 材料价库概览 ===')
    print(f"  类别数   : {len(d['materials'])}")
    print(f"  (类别,规格): {len(specs)}")
    print(f"  价格记录  : {len(flat)}（含多期）")
    print(f"  覆盖地区  : {m.get('regions_covered')}")
    print(f"  最新发布  : {m.get('last_publish')}")
    print(f"  计价口径  : {m.get('price_basis')}")
    print('\n=== 类别清单 ===')
    for cat, ci in d['materials'].items():
        n = len(ci.get('specs', {}))
        print(f"  · {cat}（{n} 个规格）")
    print('\n⚠ 数据纪律：四要素(期号/口径/地区/来源)齐全才可作权威比价；缺来源只能标 经验估(待校档)')


def cmd_search(d, a):
    rows = flatten(d)
    rs = [r for r in rows if hit(r, a.kw, a.region)]
    if a.period:
        rs = [r for r in rs if r.get('期号') == a.period]
    rs.sort(key=lambda x: (x['cat'], x['spec'], x.get('期号', '')))
    print(f'\n命中 {len(rs)} 条（关键词「{a.kw}」）')
    cur = None
    for r in rs:
        if (r['cat'], r['spec']) != cur:
            cur = (r['cat'], r['spec'])
            print(f"\n  ■ {r['name']}（{r.get('unit','')}）")
        _show_price(r)
    if not rs:
        print('\n  （未命中。可能未录入该材料，请用 material_price_update.py add 入库，或缩小关键词）')


def cmd_compare(d, a):
    rows = flatten(d)
    rs = [r for r in rows if (a.kw in r['name'] or a.kw in r['spec'] or a.kw in r['cat'])]
    if a.cat:
        rs = [r for r in rs if r['cat'] == a.cat]
    # 匹配期A/期B
    fa = [r for r in rs if r.get('期号') == a.pa]
    fb = [r for r in rs if r.get('期号') == a.pb]
    print(f'\n多期比较：{a.pa} (基准F0) vs {a.pb} (当期Ft)')
    print('（统一地区的两种口径不可直接比，须先统一口径）')
    for ra in fa:
        rb = next((x for x in fb if x['cat'] == ra['cat'] and x['spec'] == ra['spec']
                   and x.get('计价地区') == ra.get('计价地区')
                   and x.get('口径') == ra.get('口径')), None)
        if not rb:
            print(f"\n  ■ {ra['name']}：{a.pa}有价，{a.pb}缺同口径价（请先 update 当期）")
            continue
        ratio = rb['价格'] / ra['价格'] if ra['价格'] else None
        chg = (rb['价格'] - ra['价格']) / ra['价格'] * 100 if ra['价格'] else 0
        print(f"\n  ■ {ra['name']}  {ra.get('口径')} {ra.get('计价地区')}")
        print(f"      {a.pa}={ra['价格']:,.2f}  {a.pb}={rb['价格']:,.2f}"
              f"  Ft/F0={ratio:.4f}  涨跌幅={chg:+.2f}%")


def cmd_list(d, a):
    rows = flatten(d)
    rs = [r for r in rows if r['cat'] == a.cat]
    rs = latest_of(rs, a.region)
    rs.sort(key=lambda x: x['spec'])
    print(f'\n类别「{a.cat}」最新价：')
    for r in rs:
        print(f"  · {r['spec']:<22}{r['价格']:>10,.2f} 元/{r.get('unit','')}  "
              f"[{r.get('期号')} {r.get('口径')} {r.get('计价地区')}] {r.get('置信度','')}")
    if not rs:
        print('  （空。请确认类别名，用 meta 查类别清单）')


def cmd_regions(d, a):
    s = set()
    for r in flatten(d):
        s.add(r.get('计价地区', ''))
    print('\n价库已覆盖地区:', '、'.join(sorted(s)) or '（无）')


def cmd_export(d, a):
    rows = flatten(d)
    rs = [r for r in rows if hit(r, a.kw)]
    rs.sort(key=lambda x: (x['cat'], x['spec'], x.get('期号', '')))
    if a.json:
        json.dump(rs, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(f'  → JSON 导出 {len(rs)} 条: {a.json}')
    md = a.md or 'material_export.md'
    lines = [f'# 材料价格「{a.kw}」查询（{len(rs)}条）\n',
             '| 材料 | 期号 | 口径 | 地区 | 价格(元) | 单元 | 置信度 | 来源 |',
             '|---|---|---|---|---:|:---:|:---:|---|']
    for r in rs:
        lines.append(f"| {r['name']} | {r.get('期号','')} | {r.get('口径','')} | {r.get('计价地区','')} | "
                     f"{r['价格']:,.2f} | {r.get('unit','')} | {r.get('置信度','')} | {(r.get('来源') or '')[:40]} |")
    open(md, 'w', encoding='utf-8').write('\n'.join(lines))
    print(f'  → Markdown 导出 {len(rs)} 条: {md}')


def cmd_to_adjuster(d, a):
    """调差衔接：输出 cost_adjuster 期望的 {材料名:价格} 平铺 dict（ft当期 / f0基准）"""
    mapping = None
    if a.mapping:
        mapping = json.load(open(a.mapping, encoding='utf-8'))
    ft = to_price_map(d, a.ft, a.region, mapping)
    f0 = to_price_map(d, a.f0, a.region, mapping)
    out = {'ft': ft, 'f0': f0, 'note': '键名=类别·规格，口径见各期；供 cost_adjuster.py 消费'}
    if a.json:
        json.dump(out, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(f'  → 调差输入已导出: {a.json}（ft={len(ft)}项, f0={len(f0)}项）')
    else:
        print(f'\n=== 调差输入（ft当期 / f0基准）===')
        print('ft:')
        for k, v in sorted(ft.items()):
            print(f"    {k:<24}{v:>10,.2f}")
        print('f0:')
        for k, v in sorted(f0.items()):
            print(f"    {k:<24}{v:>10,.2f}")
        print(f'\n将输出 {out["note"]}')
    # 缺失提示
    only_ft = set(ft) - set(f0)
    only_f0 = set(f0) - set(ft)
    if only_ft:
        print(f'\n⚠ 仅当期有、基准缺失: {sorted(only_ft)}（请 update 基准期）')
    if only_f0:
        print(f'\n⚠ 仅基准有、当期缺失: {sorted(only_f0)}（请 update 当期）')


def main():
    p = argparse.ArgumentParser(description='本地材料价格库检索器（粤材料信息价/市场价/实战核价）')
    sub = p.add_subparsers(dest='cmd')
    sub.add_parser('meta')
    s = sub.add_parser('search', help='关键词检索')
    s.add_argument('kw'); s.add_argument('--period', default=None); s.add_argument('--region', default=None)
    c = sub.add_parser('compare', help='多期比较输出Ft/F0')
    c.add_argument('kw'); c.add_argument('pa', help='基准期 如2026-03'); c.add_argument('pb', help='当期 如2026-08')
    c.add_argument('--cat', default=None); c.add_argument('--region', default=None)
    l = sub.add_parser('list', help='列类别最新价'); l.add_argument('cat'); l.add_argument('--region', default=None)
    sub.add_parser('regions', help='覆盖地区')
    e = sub.add_parser('export', help='导出查询结果')
    e.add_argument('kw'); e.add_argument('--json', default=None); e.add_argument('--md', default=None)
    t = sub.add_parser('to-adjuster', help='输出调差平铺dict {ft,f0} 供cost_adjuster')
    t.add_argument('--ft', required=True); t.add_argument('--f0', required=True)
    t.add_argument('--region', default=None); t.add_argument('--mapping', default=None)
    t.add_argument('--json', default=None)

    a = p.parse_args()
    if not a.cmd:
        p.print_help(); return
    d = load()
    {'meta': cmd_meta, 'search': cmd_search, 'compare': cmd_compare, 'list': cmd_list,
     'regions': cmd_regions, 'export': cmd_export,
     'to-adjuster': cmd_to_adjuster}[a.cmd](d, a)


if __name__ == '__main__':
    main()
