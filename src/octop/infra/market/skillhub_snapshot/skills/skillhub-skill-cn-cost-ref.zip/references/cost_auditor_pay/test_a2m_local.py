# -*- coding: utf-8 -*-
"""
test_a2m_local.py · 本地 402 协议全链路自验（dev mock 自签名验付）

⚠ 重写记录（v20260930-16F）：本测试此前**在本机从未真正跑通过**，声称的「25/25」无实据。
  根因有二：
    ① 用 httpx 打 `http://127.0.0.1:8000` 活服务，而本机 localhost 请求被代理拦截，
       恒返回 `502 upstream connect failed`（os error 10061），测试首断言即挂、
       后续 decode_header(None) 抛 TypeError，看不出是环境问题还是代码问题。
    ② 绑死付费形态：改为免费形态后 T1「期望 402」必然失败。
  现改为：① 进程内 TestClient（不起服务、不走网络、免代理干扰）；
        ② 按 CAP_EDITION 双分支——free 形态验「不收费不返 402 直接交付」，
           pay 形态验完整 25 项 A2M 协议；③ 用临时库隔离，不污染正式订单库。

覆盖：
  free 形态 F1~F5  不收费 / 不返 402 / 直接 200 / 免密钥 / 用量计量
  pay  形态 T1~T5  402 账单 → Payment-Proof 验付 → 资源交付 → 履约回执 → 幂等重试 → 篡改拒绝
"""
import json
import os
import sys
import tempfile

# 必须在 import config 之前设置：隔离订单库，避免污染正式库
_TMP_DB = os.path.join(tempfile.gettempdir(), "cap_a2m_selftest.db")
if os.path.exists(_TMP_DB):
    os.remove(_TMP_DB)
os.environ["CAP_ORDER_DB"] = f"sqlite:///{_TMP_DB}"
os.environ.setdefault("CAP_DEV_SECRET", "selftest-secret")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fastapi.testclient import TestClient  # noqa: E402

from config import EDITION, FREE_MODE  # noqa: E402
from main import app  # noqa: E402
from payment.a2m import AlipayA2MProvider  # noqa: E402
from payment.crypto import b64url_decode, b64url_encode  # noqa: E402

CAP = "cad_takeoff"
URL = f"/v1/capability/{CAP}"
BODY = {"pdf_path": "/workspace/demo.pdf", "page": 0, "items": [{"name": "C30混凝土"}]}

client = TestClient(app)
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f"  · {detail}" if detail else ""))


def decode_header(value):
    return json.loads(b64url_decode(value))


# ============================================================
# free 形态：验证「完全不需要支付」
# ============================================================
def run_free():
    check("F0.1 形态=free", FREE_MODE, EDITION)
    r = client.get("/v1/mode")
    check("F0.2 /v1/mode 可用", r.status_code == 200)
    check("F0.3 mode.payment_required=false", r.json().get("payment_required") is False)
    check("F0.4 mode.amount=0.00（免费）", r.json().get("package_price") is None)

    r1 = client.post(URL, json=BODY, headers={"X-User-Token": "selftest-free"})
    check("F1.1 无任何凭证 → HTTP 200（不返 402）", r1.status_code == 200, f"status={r1.status_code}")
    check("F1.2 不含 Payment-Needed 头", "Payment-Needed" not in r1.headers)
    b1 = r1.json()
    check("F1.3 返回内容非空", bool(b1.get("content")))
    check("F1.4 free_mode 标记为真", b1.get("free_mode") is True)
    check("F1.5 明示未收取费用", "未收取任何费用" in str(b1.get("message", "")))

    q = client.get(f"/v1/capability/{CAP}/quote")
    check("F2.1 quote 返回 0.00", q.json().get("amount") == "0.00", str(q.json().get("amount")))

    u = client.get("/v1/usage", headers={"X-User-Token": "selftest-free"})
    check("F3.1 用量端点可用且已计量", u.status_code == 200 and u.json().get("total_calls", 0) >= 1)

    # ⚠ HTTP 头值必须是 ASCII，中文放 header 会直接 UnicodeEncodeError
    r2 = client.post(URL, json=BODY, headers={"Payment-Proof": "bogus-proof-should-be-ignored"})
    check("F4.1 伪造凭证不触发验签失败（免费形态不验签）", r2.status_code == 200,
          f"status={r2.status_code}")

    r3 = client.post("/v1/capability/不存在的能力", json=BODY)
    check("F5.1 未知能力仍 404", r3.status_code == 404)


# ============================================================
# pay 形态：完整 A2M 协议 25 项
# ============================================================
def run_pay():
    r1 = client.post(URL, json=BODY)
    check("T1.1 HTTP 状态=402", r1.status_code == 402, f"status={r1.status_code}")
    pn = r1.headers.get("Payment-Needed")
    check("T1.2 含 Payment-Needed 头", bool(pn))
    if not pn:
        return
    dec = decode_header(pn)
    proto = dec.get("protocol", {})
    method = dec.get("method", {})
    req_proto = ["out_trade_no", "amount", "currency", "resource_id",
                 "pay_before", "seller_signature", "seller_sign_type", "seller_unique_id"]
    req_method = ["seller_name", "seller_id", "seller_app_id", "goods_name",
                  "seller_unique_id_key", "service_id"]
    miss_p = [k for k in req_proto if k not in proto]
    miss_m = [k for k in req_method if k not in method]
    check("T1.3 protocol 必含字段齐全", not miss_p, f"缺失={miss_p}" if miss_p else "")
    check("T1.4 method 必含字段齐全", not miss_m, f"缺失={miss_m}" if miss_m else "")
    check("T1.5 seller_sign_type=RSA2", proto.get("seller_sign_type") == "RSA2")
    check("T1.6 seller_unique_id_key=seller_id", method.get("seller_unique_id_key") == "seller_id")
    check("T1.7 沙箱 service_id=api_mock_service_id",
          method.get("service_id") == "api_mock_service_id", method.get("service_id"))
    check("T1.8 currency=CNY", proto.get("currency") == "CNY")
    check("T1.9 金额=15.00（单包价，与 config 一致）",
          proto.get("amount") == "15.00", proto.get("amount"))
    out_trade_no = proto.get("out_trade_no")
    trade_no = f"MOCKTN_{str(out_trade_no)[-8:]}"

    provider = AlipayA2MProvider()
    proof = provider.make_mock_proof(out_trade_no, trade_no)
    decoded_proof = decode_header(proof)
    check("T2.1 Payment-Proof 含 protocol.payment_proof",
          bool(decoded_proof["protocol"].get("payment_proof")))
    check("T2.2 Payment-Proof 含 protocol.trade_no",
          bool(decoded_proof["protocol"].get("trade_no")))
    check("T2.3 Payment-Proof 含 method.client_session",
          bool(decoded_proof.get("method", {}).get("client_session")))

    r2 = client.post(URL, json=BODY, headers={"Payment-Proof": proof})
    check("T3.1 验付后 HTTP 200", r2.status_code == 200, f"status={r2.status_code}")
    body2 = r2.json()
    check("T3.2 返回非空 resource_id", bool(body2.get("resource_id")))
    check("T3.3 返回非空 content（可归属资源）", bool(body2.get("content")))
    check("T3.4 content 含能力标识", body2.get("content", {}).get("capability") == CAP)
    pv = r2.headers.get("Payment-Validation")
    check("T4.1 含 Payment-Validation 头", bool(pv))
    pv_dec = decode_header(pv) if pv else {}
    check("T4.2 validated=true", pv_dec.get("validated") is True)
    check("T4.3 回执 resource_id 与响应体一致",
          pv_dec.get("resource_id") == body2.get("resource_id"))
    check("T4.4 fulfillment_confirmed=true", body2.get("fulfillment_confirmed") is True)
    check("T4.5 首次履约 already_fulfilled=false", body2.get("already_fulfilled") is False)

    r3 = client.post(URL, json=BODY, headers={"Payment-Proof": proof})
    body3 = r3.json()
    check("T5.1 重试 HTTP 200", r3.status_code == 200)
    check("T5.2 重试 already_fulfilled=true（幂等）", body3.get("already_fulfilled") is True)
    check("T5.3 重试 content 与首次一致（资源未重算）",
          json.dumps(body3.get("content"), sort_keys=True) ==
          json.dumps(body2.get("content"), sort_keys=True))

    tampered = json.loads(b64url_decode(proof))
    tampered["protocol"]["trade_no"] = "TAMPERED_TN"
    tampered_proof = b64url_encode(json.dumps(tampered, ensure_ascii=False))
    r4 = client.post(URL, json=BODY, headers={"Payment-Proof": tampered_proof})
    check("T5.4 篡改凭证 → 验付失败返回 402", r4.status_code == 402, f"status={r4.status_code}")


print(f"===== 形态：{EDITION}（{'免费，不需支付' if FREE_MODE else '付费'}）=====")
run_free() if FREE_MODE else run_pay()

passed = sum(1 for _, ok, _ in results if ok)
total = len(results)
print("\n" + "=" * 56)
print(f"自验结果：{passed}/{total} 通过（edition={EDITION}）")
print("=" * 56)

if os.path.exists(_TMP_DB):
    try:
        os.remove(_TMP_DB)
    except OSError:
        pass
sys.exit(0 if passed == total else 1)
