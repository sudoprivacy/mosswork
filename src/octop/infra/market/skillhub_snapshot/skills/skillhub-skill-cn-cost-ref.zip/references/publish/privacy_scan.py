#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
造价稽核官 · Pay Skill 交付包 隐私扫描 / 脱敏工具（交付包自带，零外部依赖）

适用对象：本交付包（SKILL.md + cost_auditor_pay/ + 交付清单.md），
          不依赖源技能目录的 privacy_terms.json，可独立运行。

三级分档（见 SKILL.md 数据隐私声明）：
  L3 客户原件（.dwg/.pdf/.xlsx… 出现在包内）            → 阻断
  L2 可识别主体（项目名/房号/手机/身份证/邮箱/银行卡）  → 阻断
  L1 脱敏数值（金额、单价、费率）                        → 放行；--redact 可扰动

用法（在交付根目录或 publish/ 目录下均可）：
  python3 publish/privacy_scan.py                 # 扫描，L2/L3 命中则 exit 1
  python3 publish/privacy_scan.py --json          # 机器可读输出
  python3 publish/privacy_scan.py --strict        # 同时报告 L1 数值密度
  python3 publish/privacy_scan.py --redact [out]  # 导出 L1 数值扰动后的对外副本

注意：
  --redact 按固定系数缩放金额，仅用于阻止数值被反向对号入座，不保证算术自洽
  （明细合计==小计之类等式会漂移）。仅供阅读方法论，不可用于核对/演示运行。
"""
import argparse
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)  # 交付根目录

# 扫描范围 = 会被打进发布包的内容文件
SCAN_MD = ["SKILL.md", "交付清单.md",
           "cost_auditor_pay/README.md",
           "cost_auditor_pay/A2M沙箱联调报告.md"]
SCAN_EXT = (".md", ".py", ".json", ".sh", ".env.example")
# 源根目录（优先用 ROOT，找不到再回退到上一层）
SCAN_ROOTS = [ROOT]
if not os.path.isfile(os.path.join(ROOT, "SKILL.md")):
    alt = os.path.dirname(ROOT)
    if os.path.isfile(os.path.join(alt, "SKILL.md")):
        SCAN_ROOTS.insert(0, alt)

# L2 项目名（交付包内应仅含案件码 CASE-A/B/C；如新增真实项目名用 --add 入库）
EXTRA_PROJECT_NAMES = []  # 例：["某某花园", "某某大厦某某馆"]  # ⚠ 禁止写入任何真实项目名

# L3 客户原件扩展名
RAW_EXT = {".dwg", ".dxf", ".pdf", ".xlsx", ".xls", ".docx", ".doc", ".dwf", ".rvt", ".skp"}

# L2 正则规则
# ⚠ 房号规则的教训（v20260930-16F）：本文件是交付包内**独立可运行**的扫描器副本，
#   其房号正则长期未同步主扫描器 scripts/privacy_scan.py 的修正，导致**永久性误报**：
#   `(?:房|室|栋|幢|单元|门牌|号房)[号\s]*-?[\dA-Za-z\-]{2,}` 会把
#   「备用电源**房 UPS**」「**房 8m**（每间 8m）」判成房号 —— 因为「房」后面
#   跟任意 2 位以上字母数字就算命中。发布预检因此永远 NO-GO，门禁形同虚设。
#   现对齐主扫描器已修正版：**数字在前 + 房/室 + 后置否定排除普通词**，
#   即 3~4 位数字接「房/室」且其后不得紧跟汉字。
REGEX_RULES = [
    ("mobile",   "手机号",        r"1[3-9]\d{9}"),
    ("idcard",   "身份证号",      r"\d{17}[\dXx]|\b\d{15}\b"),
    ("email",    "邮箱",          r"[\w.+-]+@[\w-]+\.[A-Za-z]{2,}"),
    ("bankcard", "疑似银行卡",    r"\b\d{16,19}\b"),
    ("room_no",  "房号/门牌",     r"[0-9]{3,4}\s*(?:房|室)(?![\u4e00-\u9fff])"),
]

# 遍历时跳过的目录名：构建副本 / 缓存 / 版本库。
# 脱敏副本（如 _public_build）是本包的冗余拷贝，扫它既重复又会因副本里
# 同样存在的示例房号把门禁打红。
SKIP_DIRS = {"__pycache__", ".pytest_cache", ".git", ".pay_cache",
             "_public_build", "_dist", "_pack"}

# 虚构示例值白名单：技能文档与脚本里作为**反例/示例**出现的号段不是真实主体。
# 与主扫描器 scripts/data/privacy_terms.json 的 allow 字段一一对应。
ALLOW_VALUES = {
    "mobile": ("12930601041.01", "13024302082.01"),
    "email": tuple(),          # 邮箱无需白名单，示例统一用 example.com 已由规则容忍
}

# L1 金额（6 位及以上或千分位形态）
L1_PATTERN = r"[0-9]{1,3}(?:,[0-9]{3})+|[0-9]{6,}(?:\.[0-9]+)?"

REDACT_K = 0.937  # 固定扰动系数：非 1、非整数比，避免一眼看穿


def _roots():
    return [r for r in SCAN_ROOTS if os.path.isdir(r)]


def iter_files():
    for root in _roots():
        for relp in SCAN_MD:
            p = os.path.join(root, relp)
            if os.path.isfile(p):
                yield p
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [x for x in dirnames
                           if x not in SKIP_DIRS and not x.startswith(("_public", "_pack"))]
            for fn in filenames:
                if fn in ("a402_orders.json", "_user_meta.json", "privacy_terms.json"):
                    continue
                if fn.endswith(SCAN_EXT) and fn not in ("SKILL.md", "交付清单.md"):
                    yield os.path.join(dirpath, fn)


def relpath(p):
    for r in _roots():
        if p.startswith(r):
            return os.path.relpath(p, r)
    return p


def scan(strict=False):
    hits = {"L3": [], "L2": [], "L1": []}
    # ---- L3 客户原件 ----
    for root in _roots():
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [x for x in dirnames
                           if x not in SKIP_DIRS and not x.startswith(("_public", "_pack"))]
            for fn in filenames:
                if os.path.splitext(fn)[1].lower() in RAW_EXT:
                    hits["L3"].append({"file": relpath(os.path.join(dirpath, fn)),
                                       "kind": "客户原件扩展名", "term": fn,
                                       "line": 0, "text": fn})
    # ---- L2 / L1 ----
    names = EXTRA_PROJECT_NAMES
    for p in iter_files():
        try:
            text = open(p, encoding="utf-8").read()
        except Exception:
            continue
        lines = text.split("\n")
        # L2a 项目名
        for i, ln in enumerate(lines, 1):
            for t in names:
                if t and t in ln:
                    hits["L2"].append({"file": relpath(p), "kind": "项目名(待脱敏)",
                                       "term": t, "line": i, "text": ln.strip()[:120]})
        # L2b 正则
        for rid, desc, pat in REGEX_RULES:
            rx = re.compile(pat)
            for i, ln in enumerate(lines, 1):
                for m in rx.finditer(ln):
                    v = m.group(0)
                    # 排除长数字串误匹配
                    if rid in ("mobile", "bankcard", "idcard"):
                        s, e = m.span()
                        if (s > 0 and ln[s - 1].isdigit()) or (e < len(ln) and ln[e].isdigit()):
                            continue
                    # 白名单：技能自带的**虚构示例值**不算泄漏。
                    # ⚠ 本副本长期缺此白名单（v20260930-16F 修正），导致
                    #   references/data-privacy-policy.md 与 scripts/claim_drafter.py
                    #   里作为反例/示例写的 13800001111 被判成真实手机号 → 门禁永久 NO-GO。
                    #   与主扫描器 scripts/data/privacy_terms.json 的 allow 字段保持一致。
                    if v in ALLOW_VALUES.get(rid, ()):
                        continue
                    hits["L2"].append({"file": relpath(p), "kind": desc,
                                       "term": v, "line": i, "text": ln.strip()[:120]})
        # L1 数值密度
        if strict:
            n = len(re.findall(L1_PATTERN, text))
            if n:
                hits["L1"].append({"file": relpath(p), "kind": "L1 数值(金额/单价)",
                                   "term": "-", "line": 0, "text": f"{n} 处"})
    return hits


def redact_amount(m):
    s = m.group(0)
    if "," in s:
        try:
            v = float(s.replace(",", ""))
        except ValueError:
            return s
        new = round(v * REDACT_K, 2)
        return f"{new:,.0f}" if new == int(new) else f"{new:,.2f}"
    try:
        v = float(s)
    except ValueError:
        return s
    if v < 10000:  # 小额（含量/系数/页码）不动，避免破坏算法常量
        return s
    new = round(v * REDACT_K, 2)
    return f"{new:.0f}" if new == int(new) else f"{new:.2f}"


def do_redact(outdir):
    pat = re.compile(L1_PATTERN)
    if os.path.exists(outdir):
        shutil.rmtree(outdir)
    os.makedirs(outdir)
    changed = 0
    for p in iter_files():
        # 仅对 .md 与 .env.example 做扰动复制；.py 源码原样复制（代码常量非客户数据）
        if not (p.endswith(".md") or p.endswith(".env.example")):
            dst = os.path.join(outdir, relpath(p))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(p, dst)
            continue
        s = open(p, encoding="utf-8").read()
        s2, n = pat.subn(redact_amount, s)
        dst = os.path.join(outdir, relpath(p))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        open(dst, "w", encoding="utf-8").write(s2)
        if n:
            changed += 1
    notice = os.path.join(outdir, "REDACTED-NOTICE.md")
    with open(notice, "w", encoding="utf-8") as f:
        f.write("# 对外分享版说明（L1 数值已扰动）\n\n"
                f"- 生成方式：`python3 publish/privacy_scan.py --redact`\n"
                f"- 处理：6 位及以上金额按固定系数 {REDACT_K} 缩放；"
                "小于 10000 的含量/系数/页码类常量保持不变。\n"
                "- ⚠ **不保证算术自洽**：明细合计、小计、总额等式会漂移，\n"
                "  仅供阅读方法论，不可用于核对或演示运行。\n"
                "- 案件名仍为脱敏案件码（CASE-A/B/C），房号门牌已泛化。\n")
    return changed, outdir


def run_check():
    hits = scan(strict=False)
    ok = not (hits["L2"] or hits["L3"])
    print("════ 交付包隐私扫描 ════")
    for lv, title in (("L3", "L3 客户原件（严禁入库）"),
                      ("L2", "L2 可识别主体（须脱敏为案件码）")):
        h = hits[lv]
        print(f"{title}: {'❌ 阻断' if h else '✅ 通过'}（{len(h)} 处）")
        for x in h[:25]:
            print(f"   - {x['file']}:{x['line']}  [{x['kind']}]  「{x['term']}」")
    return ok, hits


def main():
    ap = argparse.ArgumentParser(description="交付包隐私扫描/脱敏（发布前门禁）")
    ap.add_argument("--json", action="store_true", help="JSON 输出")
    ap.add_argument("--strict", action="store_true", help="同时报告 L1 数值密度")
    ap.add_argument("--redact", nargs="?", const=os.path.join(ROOT, "..", "CostAuditor-public"),
                    metavar="OUTDIR", help="导出 L1 数值扰动的对外副本")
    args = ap.parse_args()

    if args.redact:
        changed, out = do_redact(os.path.abspath(args.redact))
        print(f"✓ 对外副本已生成：{out}（{changed} 个文件做了数值扰动）")
        print("  ⚠ 不保证算术自洽，仅供阅读方法论，不可用于核对/演示。")
        return

    hits = scan(strict=args.strict)
    if args.json:
        print(json.dumps(hits, ensure_ascii=False, indent=2))
        sys.exit(1 if (hits["L2"] or hits["L3"]) else 0)

    ok, _ = run_check()
    if args.strict:
        print(f"\nL1 数值（放行，对外分享前建议 --redact）：{len(hits['L1'])} 个文件含金额类数值")
    print()
    if not ok:
        print("❌ 存在 L2/L3 命中，禁止打包发布。请先脱敏或移出客户原件。")
        sys.exit(1)
    print("✅ 隐私门禁通过（无 L2/L3 命中）。对外分享前请跑 --redact。")


if __name__ == "__main__":
    main()
