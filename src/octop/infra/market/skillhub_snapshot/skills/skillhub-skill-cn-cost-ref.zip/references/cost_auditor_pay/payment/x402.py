# -*- coding: utf-8 -*-
"""
payment/x402.py · 微信支付 AI 专属卡（SkillHub X402 协议层）

双渠道中与支付宝 A2M 并列的微信通道：
  - 未支付：HTTP 402 + 响应头 `WeixinPay-Required: <支付意图>` + `X-Out-Trade-No`
            body 含 `code_url`（Agent 未装 weixinpay_ 插件时的二维码兜底）
  - 已支付：请求头 `X-PAYMENT`（X402 标准）携带支付凭证 → 验付 → 幂等履约

真实模式由 SkillHub/微信侧验签；dev/sandbox 走 HMAC mock 验付，仅供本地联调。
"""
import json
from typing import Optional

from config import WEIXIN
from payment.a2m import new_out_trade_no, pay_before_iso
from payment.crypto import b64url_decode, b64url_encode, mock_sign, mock_verify


class WeixinX402Provider:
    """微信 X402 收单提供方（与 AlipayA2MProvider 同接口）。"""

    def payment_required(self, *, out_trade_no, amount, currency, resource_id,
                         goods_name, pay_before, repository) -> dict:
        protocol = {
            "out_trade_no": out_trade_no,
            "amount": amount,
            "currency": currency,
            "resource_id": resource_id,
            "pay_to": WEIXIN["pay_to"],
            "pay_before": pay_before,
            "sig": mock_sign({"out_trade_no": out_trade_no, "amount": amount}),
        }
        intent = {
            "protocol": protocol,
            "method": {
                "mch_id": WEIXIN["mch_id"],
                "app_id": WEIXIN["app_id"],
                "goods_name": goods_name,
                "scheme": "weixinpay-x402",
            },
        }
        encoded = b64url_encode(json.dumps(intent, ensure_ascii=False))
        code_url = f"weixin://wxpay/bizpayurl?pr={b64url_encode(out_trade_no)[:24]}"
        body = {
            "code": "WeixinPay-Required",
            "message": "需要微信支付",
            "out_trade_no": out_trade_no,
            "amount": amount,
            "currency": currency,
            "goods_name": goods_name,
            "code_url": code_url,  # 二维码兜底：Agent 无插件时提示用户扫码
        }
        return {
            "status": 402,
            "headers": {
                "WeixinPay-Required": encoded,
                "X-Out-Trade-No": out_trade_no,
            },
            "body": body,
        }

    def verify(self, payment_proof: str, repository) -> Optional[dict]:
        try:
            decoded = json.loads(b64url_decode(payment_proof))
            p = decoded.get("protocol", {})
            out_trade_no = p.get("out_trade_no")
            trade_no = p.get("trade_no") or f"WX{trade_no_seed(out_trade_no)}"
            if not out_trade_no:
                return None
        except Exception:
            return None
        order = repository.find_by_out_trade_no(out_trade_no)
        if not order:
            return None
        if not mock_verify({"out_trade_no": out_trade_no}, p.get("sig", "")):
            return None
        return {
            "out_trade_no": out_trade_no,
            "trade_no": trade_no,
            "amount": order["amount"],
            "resource_id": order["resource_id"],
            "active": True,
        }

    def confirm(self, trade_no: str) -> bool:
        # 真实模式调微信 smartapi 关单/回调确认；mock 直接成功
        return True

    def make_mock_proof(self, out_trade_no: str) -> str:
        order = None  # 调用方在 verify 时已建单；此处仅用于本地联调
        payload = {
            "protocol": {
                "out_trade_no": out_trade_no,
                "trade_no": f"WX{trade_no_seed(out_trade_no)}",
                "sig": mock_sign({"out_trade_no": out_trade_no}),
                "payment_proof": "MOCK",
            },
            "method": {"client_session": "MOCK"},
        }
        return b64url_encode(json.dumps(payload, ensure_ascii=False))


def trade_no_seed(out_trade_no: str) -> str:
    # 确定性派生，便于 mock 联调复现
    import hashlib
    return hashlib.md5(out_trade_no.encode()).hexdigest()[:16]
