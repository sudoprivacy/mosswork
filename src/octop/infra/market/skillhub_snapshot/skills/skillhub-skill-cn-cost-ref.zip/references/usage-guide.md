# 造价稽核官 · 命令速查使用说明（v20260930）

> 配套独立说明文档：`/workspace/造价稽核官_使用说明_v20260930.html`（含场景案例，可浏览器打开）。
> 本文件为**技能内自维护的命令速查**，随每次脚本改动同步更新。
> 所有脚本在 `scripts/` 下运行：`cd scripts && python3 <脚本> <子命令>`。

---

## 1. 材料价格四件套

| 脚本 | 子命令 | 说明 |
|---|---|---|
| `material_price_lookup.py`（检索） | `meta` | 价库概览（类别/记录/口径） |
| | `search <材> [--period 2026-03] [--region 广州]` | 关键词检索 |
| | `compare <材> <期A> <期B>` | 多期比较 Ft/F0 |
| | `to-adjuster --ft X --f0 Y` | 导出调差 dict 喂 cost_adjuster |
| | `export <材> [--md] [--json]` | 导出结果 |
| `material_price_update.py`（写价·唯一可写） | `add` / `batch` / `update` / `log` | 单条/整月批量/改错/日志（四要素齐才入） |
| `price_trace.py`（溯源·v0930） | `trace <材> [--period] [--region]` | 价格→来源链+置信度+效力评级+证据档 |
| | `source <批次ID>` / `batches` | 展开某来源批次 / 列出全部批次 |
| | `evidence <材>` | 审价核减证据汇总（最佳证据档） |
| `price_index_lookup.py`（广东指数·v0930-9） | `latest` | 最新一期：房建/市政/轨交 人工·材料·台班·造价指数 |
| | `get <类别> [--period 2026-07]` | 查某期某类别指数（类别：房屋建筑工程/市政基础设施工程/城市轨道交通工程） |
| | `trend <类别> <指数名>` | 时间序列（含较上期差值） |
| | `adjust --category 房建 --base 2026-03 --to 2026-07 --labor 93700 --machine 50000 --aux 20000 [--main-mat X]` | **编制期调差计算**；内置三条硬约束：台班指数不得重复调、调价不调管理费和利润、管理费利润基数须用调整后值 |
| `dispute_case_lookup.py`（争议判例·v0930-9） | `stats` | 判例库概况与主题分布（38 例，编号 331~554） |
| | `search <关键词> [--topic 主题] [--limit N]` | 全文检索（标题/争议事项/双方观点/我站观点/依据） |
| | `get <编号>` | 看某例全文（三段原文 + 援引文件） |
| | `topic <主题名>` / `list [--period]` | 按主题列出 / 按期号列出 |
| `price_estimator.py`（推演·v0930-2） | `cable --cores N --section S --cu <元/吨> --type <型号>` | **信息价缺项时**电缆铜价推演→信息价口径/市场含税口径 |
| | `steel --kind H\|I\|C\|L\|P\|PL\|R ... [--len] [--price]` | 型钢/钢板理论重量与金额 |
| | `cu --cu <元/吨>` | 铜价换算与基准提示 |
| `cost_adjuster.py`（调差） | `index` / `single` / `contract` / `batch` | GB/T 50500 公式法 ΔP=P₀×[A+Σ(BᵢFtᵢ/F₀ᵢ)−1] |

## 2. 审价与三源比价

| 脚本 | 子命令 | 说明 |
|---|---|---|
| `audit_triple_source.py`（三源·v0930） | `audit <项目> <单价> <单位> [--cat 材料\|检测\|其他] [--region]` | 单行判定 |
| | `audit-file <报价单.csv>` | csv 批量（列：项目名,数量,单价,单位,类别）逐行判定+汇总 |
| | `explain` | 解释三档判定口径 |
| `testing_fee_lookup.py`（检测检索） | `search` / `get` / `list` / `groups` / `tags` / `share` / `export` | 检测费条目检索；`meta` 带效力警示（8号文已废止） |
| `testing_fee_parser.py` | `<pdf> [--out] [--title] [--doc-no]` | 检测费 PDF→JSON 可复现解析 |
| `pdf_price_parser.py` | `<预算.pdf> [--auto] [out.json]` | 预算 PDF 抽表+钩稽校验+费率反推 |

## 3. 算量 / 图纸

| 脚本 | 子命令 | 说明 |
|---|---|---|
| `quantity_checker.py` | `rebar` / `stirrup` / `anchorage` / `rebar-content` / `concrete-content` / `beam-section` / `price` | 算量校验 |
| `takeoff_toolkit.py` | `dxf` / `pdf` / `pdftext` / `scale` / `measure` | 程序化取量（DWG/DXF/扫描件） |
| `cadpdf_takeoff.py` | `frame` / `dims` / `chains` / `conserve` / `demo` | **CAD导出PDF专项**：图框反推标定·文本层取尺寸·尺寸链·总量守恒 |
| `handwritten_bill_parse.py` | `ingest` / `tie` / `review` / `demo` | 手写单结构化·三层级钩稽·争议定位 |

## 3A. 清工 / 劳务分包结算

| 脚本 | 子命令 | 说明 |
|---|---|---|
| `labor_settlement_audit.py` | `check` / `crosspage` / `audit` / `points` / `demo` | 清工八大核减点 P1~P8 + 三层级核对（配套 `labor-settlement-audit.md`） |

> **何时用**：合同写「清工（只包人工）」「包工不包料」「劳务分包」，单价为元/㎡、元/m 的纯人工单，
> 无主材无取费 → **不要**走 `repricing-audit`（组价）或 `settlement-audit` 的包工包料核减点，走本节。

## 4. 清单 / 索赔（交付物）

| 脚本 | 子命令 | 说明 |
|---|---|---|
| `boq_builder.py` | `xlsx` / `json` / `estimate` | 清单模板 / JSON / 估算 |
| | `standard` / `decor` | GB/T 50500-2024 清单模式工作簿（五类清单+12位码+综合单价+三级汇总） |
| `claim_drafter.py` | `notice` / `time` / `cost` / `pack` | 索赔意向 / 工期 / 费用 / 完整文件包 |

## 5. AI 按量付费网关（A402/A2M）

| 子命令 | 说明 |
|---|---|
| `demo` | 全链路演示（402下发→验付→履约→200→幂等） |
| `print-bill <rid> <amt>` | 打印 Payment-Needed 账单 |
| `status <out_trade_no>` | 查订单 |
| `serve --port 8000` | 起 Web 资源端点 `/resource/<id>` |

> 资源真实绑定：`generate_service_resource(resource_id, payload)`，payload 携 `{"kind":"audit_triple", "kw":…, "price":…, "unit":…, "cat":"材料|检测"}` 时调 `audit_triple_source` 返回真实审计结论。未配 `AIPAY_*` 密钥仅明示模拟，不伪造真实收款。

## 6. 三大数据 JSON（`scripts/data/`）

| 文件 | 内容 | 备注 |
|---|---|---|
| `material_prices.json`（schema 1.1） | 10 大类 23 条价，每条带 source_id + 期号/口径/地区/价格/来源/置信度 | meta.source_batches 来源批次表（7 个） |
| `gd2015_fee.json` | 检测费 1967 条 / 218 组 / 11 大类 | 含已废止警示 |
| `policy_files.json`（v0930） | 政策文件效力基线（计价/计量/检测费文件现行效力） | 6 可核底子+待补占位 |

**写价纪律**：只有 `material_price_update.py` 能写价库；结构升级用一次性脚本（如 `upgrade_source_trace.py`）并记 changelog；运行时文件 `a402_orders.json` 不入版。

**溯源纪律（v0930-2 强化）**：
- 每条价**入库即挂 `source_id`**——`material_price_update.py` 的 `ensure_batch()` 按「来源 + 期号」自动归属/登记批次，新批次 ID 形如 `X1A2B3C`（md5 派生，可复现），**不再产生 `UNKNOWN_待补批次`**；
- `upgrade_source_trace.py` 已改为**数据驱动**：按 (期号, 来源) 在 `meta.source_batches` 中匹配，能自动修复三种断裂——① 无 `source_id` ② 占位 `UNKNOWN_待补批次` ③ 指向不存在批次（幽灵 ID）；
  ⚠️ 该脚本**只补种子批次、绝不覆盖既有批次表**（历史版本曾覆盖导致批次丢失，已修）；
- 自检命令：
  ```bash
  python3 -c "import json;d=json.load(open('scripts/data/material_prices.json'));b=d['meta']['source_batches'];\
  bad=[(c,s,p.get('source_id')) for c,i in d['materials'].items() for s,si in i.get('specs',{}).items() \
  for p in si['periods'] if p.get('source_id') not in b];print('断裂',len(bad),bad)"
  ```

## 7. 参考库（50 库 · 索引速查）

- **计价清单**：pricing-foundation · boq-standard-mode · quota-comparison · process-quota-mapping · new-process-quota · repricing-audit · material-price-guide · policy-basis✚
- **图纸算量**：drawing-recognition-detailed · drawing-qty-mapping · structural/mep/municipal-equipment-drawings · building-waterproofing-qty · municipal-pipe-network-qty · prefab-steel-landscape-qty · calibration-rules · quantity-takeoff-toolkit · cad-*
- **索赔结算**：claim-cases · claim-secure-template · claim-delay-analysis · contract-management · settlement-audit · settlement-vat · settlement-archive✚ · unbalanced-settlement · cost-indicators*
- **稽核终局**：gongying-material-audit · material-evidence-chain · cost-appraisal · second-review-defense · gd-testing-fee-2015 · leak-repair-pricing
- **投标/全过程/变现/备考**：tender-control-evaluation · bid-clarification · construction-cost-control✚ · whole-process-cost-consult✚ · alipay-a402-payment · exam-mapping✚ · cross-ref-index
- ✚ = v20260930 新增

> 反幻觉红线与效力闸：详见 `policy-basis.md` 与 SKILL.md「反幻觉红线」；跨库定位先查 `cross-ref-index.md`。

---

## 8. 升级为 Pay Skill（PAYSKILL 付费改造契约）

> **背景**：本技能自 v20260930-12 由"仅卖端网关"升级为**平台付费技能（PAYSKILL）**。此前 `alipay_payment_gateway.py` 只是支付宝官方 A2M **卖端**网关（单路径资源接口），但平台调度层 `probe→pay→complete→ack` 所需的**技能侧付费闸口（客户端）缺失**，即"缺少必要的支付宝 AI 按量付费服务"。本版新增 `scripts/payment_gate.py` 补齐该闸口。

### 8.1 平台契约（四步）

| 阶段 | 谁做 | 行为 |
|---|---|---|
| **probe（探测）** | 技能侧 `payment_gate.py` | 调用前探测是否已持有有效付费凭证；已付→直接放行；未付→向 stdout 返回 `HTTP 402 Payment Required` + `Payment-Needed:` 头（含金额 / 资源 / 币种），平台据此唤起支付宝付费页 |
| **pay / complete** | 平台 + 支付宝 | 用户在支付宝完成扣费，平台生成并回传 `Payment-Proof`（付费凭证） |
| **ack（验签放行）** | 技能侧 `payment_gate.py` | 平台携 `Payment-Proof` 重试本次调用；脚本验签通过后放行主流程，并写入本地缓存 |

### 8.2 命令表（`scripts/payment_gate.py`）

```bash
cd scripts
python3 payment_gate.py probe  --slug cost-auditor --resource UNIT_PRICE_AUDIT [--amount 2.99]   # 探测；未付打印 402+Payment-Needed，退出码 402
python3 payment_gate.py ack    --proof <base64url> --resource UNIT_PRICE_AUDIT [--slug cost-auditor]  # 验签 Payment-Proof（也可经环境变量 PAYMENT_PROOF 传入）
python3 payment_gate.py status                                                              # 查看 .pay_cache 缓存
python3 payment_gate.py reset                                                               # 开发期清空本地缓存（仅清 .pay_cache）
```

- 退出码约定：`0` = 已付费 / 放行；`402` = 需付费（未放行）；其他非 0 = 错误。
- 资源定价见 `alipay_payment_gateway.DEFAULT_RESOURCES`：`BOQ_REVIEW_ONCE` 清单复核 ¥0.99 · `UNIT_PRICE_AUDIT` 综合单价审核 ¥2.99 · `SETTLEMENT_QUERY` 结算争议检索 ¥1.99（可按真实能力增删）。

### 8.3 订阅持久化与幂等（`.pay_cache/state.json`）

- 付费状态缓存在技能根目录 `.pay_cache/state.json`，避免每次调用重复付费。
- 同一 `Payment-Proof` 在 **24h 幂等窗口**内仅生效一次（字段 `expire_at` = 付费时刻 + 24h），到期需重新验签。
- `reset` 仅清空 `.pay_cache`，不触碰订单库或密钥。

### 8.4 与 A2M 卖端网关的关系

- `payment_gate.py` 是**客户端闸口**（负责 402 下发、Proof 验签、本地持久化），本身不直连支付宝。
- 真实验付 / 履约后端复用同目录 `alipay_payment_gateway.py`（支付宝官方 A2M 单路径资源接口）：`probe` / `ack` 内部委托 `gw.handle_resource_request()` 建单与验付。
- 如改用云端计费服务，可设环境变量 `PAYSKILL_CLOUD_URL`，由云端点统一做 A2M 服务端。

### 8.5 反幻觉纪律（红线）

- `is_real_config()` 未配 `AIPAY_APP_ID / AIPAY_PRIVATE_KEY / AIPAY_ALIPAY_PUBLIC_KEY / AIPAY_SELLER_ID` 时 `is_mock=True`：仅输出**明示模拟**结果，**绝不伪造"已通过支付宝验付 / 已收款"**。
- 任何未配置密钥环境下的 "PAID" 均带 `"mock": true`，便于平台 / 用户识别。
