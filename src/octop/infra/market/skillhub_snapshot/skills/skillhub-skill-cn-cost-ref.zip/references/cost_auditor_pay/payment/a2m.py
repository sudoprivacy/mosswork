# -*- coding: utf-8 -*-
"""
payment/a2m.py · 支付宝 AI 按量付费（A2M）协议层

严格复刻 alipay-aipay A2M demo 的协议形状：
  - 未支付：HTTP 402 + 响应头 `Payment-Needed: <Base64URL 订单包>`
  - 已支付：请求头 `Payment-Proof` → 调 alipay.aipay.agent.payment.verify 验付
            → 幂等生成资源 → 调 alipay.aipay.agent.fulfillment.confirm 履约
            → 返回资源 + 响应头 `Payment-Validation`

prod 走真实支付宝 SDK；dev/sandbox 无 SDK 时走 HMAC mock 验付，仅供本地联调。
"""
import base64
import json
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from config import ALIPAY
from payment.crypto import (
    alipay_seller_signature,
    b64url_decode,
    b64url_encode,
    mock_sign,
    mock_verify,
)

SELLER_NAME = "造价稽核官（示例商户）"


def _real_sdk_ready() -> bool:
    return bool(ALIPAY["app_id"]) and bool(ALIPAY["private_key"])


class AlipayA2MProvider:
    """支付宝 A2M 收单提供方。"""

    # ---------- 1. 生成 402 支付要求 ----------
    def payment_required(self, *, out_trade_no, amount, currency, resource_id,
                         goods_name, pay_before, repository) -> dict:
        """返回 {status, headers, body}，headers 含 Payment-Needed。

        严格对齐 aipay-interface-contract.md：
          - protocol 必含 seller_unique_id（非 seller_id）
          - method 必含 seller_id + seller_unique_id_key=seller_id
          - 商家签名仅对 amount/currency/goods_name/out_trade_no/
            pay_before/resource_id/seller_id/service_id 八项字典序拼接
        """
        seller_id = ALIPAY["seller_id"]
        service_id = ALIPAY["service_id"]

        # 商家账单签名：契约规定的 8 个字段（字典序拼接）
        sig_params = {
            "amount": amount,
            "currency": currency,
            "goods_name": goods_name,
            "out_trade_no": out_trade_no,
            "pay_before": pay_before,
            "resource_id": resource_id,
            "seller_id": seller_id,
            "service_id": service_id,
        }
        if _real_sdk_ready():
            seller_signature = alipay_seller_signature(sig_params, ALIPAY["merchant_private_key"])
        else:
            seller_signature = mock_sign(sig_params)

        payment_needed = {
            "protocol": {
                "out_trade_no": out_trade_no,
                "amount": amount,
                "currency": currency,
                "resource_id": resource_id,
                "pay_before": pay_before,
                "seller_signature": seller_signature,
                "seller_sign_type": "RSA2",
                "seller_unique_id": seller_id,
            },
            "method": {
                "seller_name": SELLER_NAME,
                "seller_id": seller_id,
                "seller_app_id": ALIPAY["app_id"],
                "goods_name": goods_name,
                "seller_unique_id_key": "seller_id",
                "service_id": service_id,
            },
        }
        encoded = b64url_encode(json.dumps(payment_needed, ensure_ascii=False))
        body = {
            "code": "Payment-Needed",
            "message": "需要支付",
            "out_trade_no": out_trade_no,
            "amount": amount,
            "currency": currency,
            "goods_name": goods_name,
        }
        return {
            "status": 402,
            "headers": {"Payment-Needed": encoded},
            "body": body,
        }

    # ---------- 2. 验付 ----------
    def verify(self, payment_proof: str, repository) -> Optional[dict]:
        """
        返回规范化凭证 {out_trade_no, trade_no, amount, resource_id, active} 或 None。
        真实模式调 alipay.aipay.agent.payment.verify；mock 模式本地 HMAC 校验。

        解码严格按契约：protocol.payment_proof / protocol.trade_no /
        method.client_session（可选）；真实凭证可不含 out_trade_no，
        由验付响应回填。
        """
        try:
            decoded = json.loads(b64url_decode(payment_proof))
            protocol = decoded.get("protocol", {})
            trade_no = protocol.get("trade_no")
            out_trade_no = protocol.get("out_trade_no")  # 真实凭证可能缺，由响应回填
            if not trade_no:
                return None
        except Exception:
            return None

        if _real_sdk_ready():
            return self._verify_real(payment_proof, trade_no, out_trade_no)
        return self._verify_mock(protocol, trade_no, out_trade_no, repository)

    def _verify_mock(self, protocol, trade_no, out_trade_no, repository) -> Optional[dict]:
        if not out_trade_no:
            return None
        order = repository.find_by_out_trade_no(out_trade_no)
        if not order:
            return None
        # mock 验签：核对对（out_trade_no, trade_no）的 HMAC（与 make_mock_proof 一致）
        proof_val = protocol.get("payment_proof") or protocol.get("sig")
        if not mock_verify({"out_trade_no": out_trade_no, "trade_no": trade_no}, proof_val or ""):
            return None
        return {
            "out_trade_no": out_trade_no,
            "trade_no": trade_no,
            "amount": order["amount"],
            "resource_id": order["resource_id"],
            "active": True,
        }

    def _verify_real(self, payment_proof, trade_no, out_trade_no) -> Optional[dict]:
        try:
            from alipay.aop.api.DefaultAlipayClient import DefaultAlipayClient
            from alipay.aop.api.AlipayClientConfig import AlipayClientConfig
            from alipay.aop.api.domain.AlipayAipayAgentPaymentVerifyModel import (
                AlipayAipayAgentPaymentVerifyModel,
            )
            from alipay.aop.api.request.AlipayAipayAgentPaymentVerifyRequest import (
                AlipayAipayAgentPaymentVerifyRequest,
            )
        except ImportError:
            return None
        cfg = AlipayClientConfig()
        cfg.server_url = ALIPAY["gateway"]
        cfg.app_id = ALIPAY["app_id"]
        cfg.app_private_key = ALIPAY["private_key"]
        cfg.alipay_public_key = ALIPAY["alipay_public_key"]
        cfg.charset = "utf-8"
        cfg.sign_type = "RSA2"
        client = DefaultAlipayClient(alipay_client_config=cfg)
        model = AlipayAipayAgentPaymentVerifyModel()
        model.payment_proof = payment_proof
        model.trade_no = trade_no
        req = AlipayAipayAgentPaymentVerifyRequest()
        req.biz_model = model
        resp = json.loads(client.execute(req))
        data = resp.get("alipay_aipay_agent_payment_verify_response", resp)
        if data.get("code") != "10000":
            return None
        return {
            "out_trade_no": data.get("out_trade_no") or out_trade_no,
            "trade_no": data.get("trade_no") or trade_no,
            "amount": data.get("amount"),
            "resource_id": data.get("resource_id") or "",
            "active": data.get("active") is True,
        }

    # ---------- 3. 履约确认 ----------
    def confirm(self, trade_no: str) -> bool:
        if _real_sdk_ready():
            return self._confirm_real(trade_no)
        return True  # mock 模式跳过真实回调

    def _confirm_real(self, trade_no: str) -> bool:
        try:
            from alipay.aop.api.DefaultAlipayClient import DefaultAlipayClient
            from alipay.aop.api.AlipayClientConfig import AlipayClientConfig
            from alipay.aop.api.domain.AlipayAipayAgentFulfillmentConfirmModel import (
                AlipayAipayAgentFulfillmentConfirmModel,
            )
            from alipay.aop.api.request.AlipayAipayAgentFulfillmentConfirmRequest import (
                AlipayAipayAgentFulfillmentConfirmRequest,
            )
        except ImportError:
            return False
        cfg = AlipayClientConfig()
        cfg.server_url = ALIPAY["gateway"]
        cfg.app_id = ALIPAY["app_id"]
        cfg.app_private_key = ALIPAY["private_key"]
        cfg.alipay_public_key = ALIPAY["alipay_public_key"]
        cfg.charset = "utf-8"
        cfg.sign_type = "RSA2"
        client = DefaultAlipayClient(alipay_client_config=cfg)
        model = AlipayAipayAgentFulfillmentConfirmModel()
        model.trade_no = trade_no
        req = AlipayAipayAgentFulfillmentConfirmRequest()
        req.biz_model = model
        resp = json.loads(client.execute(req))
        data = resp.get("alipay_aipay_agent_fulfillment_confirm_response", resp)
        return data.get("code") == "10000"

    # ---------- 本地联调：生成 mock 支付凭证（prod 由支付宝返回，勿调用）----------
    def make_mock_proof(self, out_trade_no: str, trade_no: str) -> str:
        """dev/sandbox 本地联调专用：形状对齐真实 Payment-Proof
        （protocol.payment_proof + protocol.trade_no + 可选 out_trade_no；
        method.client_session）。prod 由支付宝收银返回，禁止调用本函数。"""
        payload = {
            "protocol": {
                "out_trade_no": out_trade_no,
                "trade_no": trade_no,
                "payment_proof": mock_sign(
                    {"out_trade_no": out_trade_no, "trade_no": trade_no}
                ),
            },
            "method": {"client_session": "MOCK"},
        }
        return b64url_encode(json.dumps(payload, ensure_ascii=False))


def new_out_trade_no() -> str:
    return f"CAP_{int(time.time() * 1000)}_{uuid.uuid4().hex[:12]}"


def pay_before_iso(minutes: int = 30) -> str:
    return (datetime.now(timezone.utc).astimezone() + timedelta(minutes=minutes)).isoformat()
