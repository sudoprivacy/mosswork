# 跨库主题索引 | 高频问题 → 命中文件/脚本/数据速查总表

> **定位**：本技能文件已增至 30+ 参考库 + 10 个脚本 + 2 个数据文件，同一类问题常散落在多个库。本文件把**高频实战问题**与**命中文件/脚本/数据**串成一张路由总表——**只做"跳转串联"，不重复任何库正文**。遇到问题时先查本表定位，再进对应库读细节。
>
> **使用**：按 ① 按专业/流程 或 ② 按脚本/数据 两个方向检索。每个主题给出「主文件」与「联动文件」，形如"先读 A → 再走 B → 落地用脚本 C"。

---

## 一、脚本 / 数据文件速查（一键索引）

| 脚本/数据 | 一句话功能 | 常用调用 | 命中的参考库 |
|:---------|:----------|:---------|:-------------|
| `scripts/quantity_checker.py` | 算量结果校验（锚固/搭接/含量/单价反算） | `python3 quantity_checker.py <量文件>` | `calibration-rules.md`、`cad-quantity-extraction.md` |
| `scripts/takeoff_toolkit.py` | 工具算量流水线（DXF几何/PDF渲染/比例尺/图像量测/BOQ） | `python3 takeoff_toolkit.py …` | `quantity-takeoff-toolkit.md`、`drawing-recognition-detailed.md` |
| `scripts/pdf_price_parser.py` | 预算PDF综合单价表/计价表程序化解析+钩稽校验+费率反推 | `python3 pdf_price_parser.py <预算.pdf> --analysis 5 75 --boq 2 6` | `pdf_price_tables.md`、`repricing-audit.md` |
| `scripts/testing_fee_lookup.py` | 检测收费检索（meta/search/get/list/groups/tags/share/export） | `python3 testing_fee_lookup.py search 回弹 --cat 2` | `gd-testing-fee-2015.md` |
| `scripts/testing_fee_parser.py` | 检测收费PDF→JSON可复现解析（换省/新版复用） | `python3 testing_fee_parser.py 收费表.pdf --out data/gd2015_fee.json` | `gd-testing-fee-2015.md` |
| `scripts/material_price_lookup.py` | 本地材料价检索/比价/导出调差 | `python3 material_price_lookup.py search 钢筋 --period 2026-08` | `material-price-guide.md` |
| `scripts/material_price_update.py` | 本地材料价**写入**（add/update/batch/log，幂等+快照） | `python3 material_price_update.py add 钢材 HRB400E --price … --period 2026-08` | `material-price-guide.md` |
| `scripts/cost_adjuster.py` | 材料价格调差（ΔP=P₀×[A+Σ(Bᵢ×Ftᵢ/F₀ᵢ)−1]） | `python3 cost_adjuster.py index …` | `contract-management.md`、`material-price-guide.md` |
| `scripts/boq_builder.py` | 清单模板生成（框架/剪力墙等骨架 + standard/decor 清单模式工作簿） | `python3 boq_builder.py xlsx --project …` | `boq-standard-mode.md` |
| `scripts/claim_drafter.py` | 索赔函生成（notice/time/cost/pack） | `python3 claim_drafter.py pack --project …` | `claim-secure-template.md`、`contract-management.md` |
| `data/gd2015_fee.json` | 粤建检协〔2015〕8号检测收费结构化（1967条） | 由 `testing_fee_lookup.py` 读取 | `gd-testing-fee-2015.md` |
| `data/material_prices.json` | 本地材料价格库（4要素+置信度） | 由 `material_price_lookup.py`/`update.py` 读写 | `material-price-guide.md` |

---

## 二、按专业 / 流程的主题路由（高频问题命中总表）

| 我遇到的问题是… | 先读（主文件） | 再联动 / 落地 |
|:----------------|:--------------|:--------------|
| **收到预算PDF要审综合单价、重新组价** | `repricing-audit.md`（六步法：骨架钩稽→病灶→取费→材价核减→重算→影响） | 解析PDF用 `pdf_price_parser.py`+`pdf_price_tables.md`；材价核减取 `material_price_lookup.py` 当期价；堵漏组价看 `leak-repair-pricing.md` |
| **审核检测费报价虚不虚高** | `gd-testing-fee-2015.md`（四大结构+列支红线+6大陷阱） | 检索用 `testing_fee_lookup.py search`；判断归施工单位还是建设方按文件红线 |
| **套定额不熟，某工艺该套哪条** | `process-quota-mapping.md`（工艺→定额）、`quota-comparison.md`（跨省对照） | 新工艺/新技术看 `new-process-quota.md`；防水堵漏专项看 `leak-repair-pricing.md` |
| **估概算/审指标，常规业态单方** | `cost-indicators.md`（住宅/办公/市政/园林/安装） | 非标业态（电竞馆/场馆/厂房/改造）看 `cost-indicators-nonstandard.md` |
| **非标项目（电竞馆/场馆/厂房/商业改造）报价是否合理** | `cost-indicators-nonstandard.md`（因子框架+比重体检带+沉淀模板） | 单价核减走 `repricing-audit.md`；设备价走 `material_price_lookup.py`；结算核减走 `settlement-audit.md` |
| **竣工结算审核、核减、甩项争议** | `settlement-audit.md`（三阶审核/核减点/甩项/报告模板） | 对量谈判+争议决策树看文件 §3A/§3B；与造价指标体检联动 `cost-indicators*.md` |
| **清工/包人工/劳务分包 结算怎么审** | `labor-settlement-audit.md`（八大核减点P1~P8/三层级核对/问询单结构/三档结论） | 自动判定用 `labor_settlement_audit.py`；手写单结构化用 `handwritten_bill_parse.py`；注：包工包料的核减点在此**全部失效** |
| **单面/双面计量、展开/投影口径争议** | `labor-settlement-audit.md` P1/P2 | 展开系数查 `decorative-drawings.md §4.3`；总量守恒反证用 `cadpdf_takeoff.py conserve` |
| **CAD导出PDF取量、无比例尺条怎么标定** | `quantity-takeoff-toolkit.md §3.5A` | 用 `cadpdf_takeoff.py`（图框反推标定+文本层取尺寸+总量守恒） |
| **看图纸提工程量，识图不会** | `drawing-recognition-detailed.md`（16类专业）按专业细分：结构/装饰/MEP/市政 | 图纸→清单映射走 `drawing-qty-mapping.md`；程序化提量走 `cad-programmatic.md`+`takeoff_toolkit.py` |
| **提取的工程量要校验可不可信** | `calibration-rules.md`（7类校验+阈值表） | `quantity_checker.py` 落地；含量异常对 `cost-indicators.md` 体检 |
| **清标/评标澄清回复怎么写** | `bid-clarification.md`（不澄清实质/偏差分类/回复模板） | 报价策略延伸见同文件；评标办法看 `tender-control-evaluation.md` |
| **招投标：控制价编制/异议/评标办法** | `tender-control-evaluation.md` | 清单模式规范走 `boq-standard-mode.md`；控制价范围红线走模块三红线 |
| **索赔/反索赔，工期顺延/费用补偿** | `claim-delay-analysis.md`（CPM关键线路/不可抗力/情势变更） | 索赔函起草用 `claim_drafter.py`；判例见 `claim-cases.md`；合同条款见 `contract-management.md` |
| **结算争议预防、要不要索赔** | `claim-secure-template.md`（决策模板） | 落到结算走 `settlement-audit.md` §3B |
| **合同价款类型/调差/风险分担/黑白合同** | `contract-management.md`（GF-2017条款+调差公式） | 材料调差落地用 `cost_adjuster.py`+`material_price_lookup.py to-adjuster` |
| **要报价/估算，心里没底求骨架** | `boq_builder.py estimate --type … --area …` | 清单模式工作簿走 `boq_builder.py standard/decor`+`boq-standard-mode.md` |
| **材料当期价多少、调差基准怎么取** | `material-price-guide.md`（价库纪律+月度SOP） | 查价 `material_price_lookup.py`；写价 `material_price_update.py`；调差 `cost_adjuster.py` |
| **防水/堵漏工程含量与价格陷阱** | `leak-repair-pricing.md`（渗透结晶/聚脲/止水条/速凝等） | 防水算量见 `building-waterproofing-qty.md`；单价核减走 `repricing-audit.md` |
| **计费基础/增值税/综合单价到底怎么构成** | `pricing-foundation.md`（费用构成/一般简易计税/综合单价辨析） | 清单模式见 `boq-standard-mode.md` |

---

## 三、按工具/交付物命中的"一条龙"

### 3.1 「审一份预算PDF」一条龙
1. `pdf_price_parser.py` 解析PDF → 得综合单价/计价表 → `repricing-audit.md` 钩稽校验+费率反推；
2. 材料价核减 → `material_price_lookup.py` 取当期信息价（价库纪律见 `material-price-guide.md`）；
3. 若涉检测费 → `testing_fee_lookup.py` + `gd-testing-fee-2015.md` 判归属与虚高；
4. 输出复核报告，含偏差触发 `repricing-audit.md` 六步法。

### 3.2 「给一个改造/非标项目报价把关」一条龙
1. `cost-indicators-nonstandard.md` 定位业态 → 读主导因子 + 专业比重体检带；
2. 比重异常专业 → 逐项核单价走 `repricing-audit.md`；
3. 涉设备采购归口、界面拆改 → 模块三范围红线 + `drawing-qty-mapping.md` 界面划分；
4. 项目落地后把可核单方填回 `cost-indicators-nonstandard.md` §6 沉淀模板 → 持续校准本地指标。

### 3.3 「做一版投标报价/清单」一条龙
1. `boq_builder.py standard/decor` 出清单模式工作簿骨架（见 `boq-standard-mode.md`）；
2. 按工艺套定额 → `process-quota-mapping.md` + `quota-comparison.md` + `new-process-quota.md`；
3. 材料取当期价 → `material_price_lookup.py`；
4. 报价策略与异常预警 → `tender-control-evaluation.md` + `bid-clarification.md`。

---

## 四、维护规则（新增文件时如何挂入本索引）

**任何新库/新脚本上线，都要在本文件登记，否则等于"没接通"，用户搜不到：**
1. 若新增 **reference** → 在 §2 对应主题行追加联动（或新增主题行）；已有同类主题则在该行「联动」列补一个。
2. 若新增 **脚本/数据** → 在 §1 速查表加一行（功能 + 调用 + 命中的库）。
3. 若同时新增**主题** → 建一条「我遇到的问题是…」行。
4. **登记完成后**，再同步到 SKILL.md 的 `references` 文件树、决策树触发词、description、`total_files`——本索引只是"门牌"，SKILL.md 才是总开关。

> 一句话：**「这问题在哪几个库」→ 查本索引；「某库具体怎么用」→ 去那个库正文；「某脚本敲什么」→ 看 §1。**

---

## 修订记录
| 日期 | 内容 |
|:-----|:-----|
| 2026-09-08 | 初版建立：脚本/数据速查表（10脚本+2数据）、按专业/流程主题路由、3条一条龙、维护规则 |
