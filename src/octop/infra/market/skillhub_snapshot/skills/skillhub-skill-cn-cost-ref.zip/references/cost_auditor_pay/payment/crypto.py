# -*- coding: utf-8 -*-
"""
payment/crypto.py · 签名与编码工具
- 真实模式：支付宝商家 RSA2 签名（pycryptodome，惰性导入）
- 开发模式：HMAC-SHA256 mock 签名（stdlib，仅本地联调）
"""
import base64
import hashlib
import hmac
import json
import os
from typing import Any

from config import DEV_HMAC_SECRET


# ============ Base64URL ============
def b64url_encode(data: Any) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("utf-8")


def b64url_decode(data: str) -> str:
    pad = 4 - len(data) % 4
    if pad != 4:
        data += "=" * pad
    return base64.urlsafe_b64decode(data).decode("utf-8")


# ============ 支付宝商家 RSA2 签名（真实模式）============
def alipay_seller_signature(params: dict, private_key_b64: str) -> str:
    """复刻 alipay-aipay A2M demo 的 generate_seller_signature（RSA2 / PKCS#1）。"""
    try:
        from Crypto.Hash import SHA256
        from Crypto.Signature import pkcs1_15
        from Crypto.PublicKey import RSA
    except ImportError as e:  # pragma: no cover
        raise RuntimeError("真实支付宝签名需安装 pycryptodome：pip install pycryptodome") from e

    items = []
    for k in sorted(params.keys()):
        v = params[k]
        if v is not None and v != "":
            items.append(f"{k}={v}")
    sign_string = "&".join(items)
    key_der = base64.b64decode(private_key_b64, validate=True)
    key = RSA.import_key(key_der)
    sig = pkcs1_15.new(key).sign(SHA256.new(sign_string.encode("utf-8")))
    return base64.b64encode(sig).decode("utf-8")


# ============ 开发态 mock 签名（HMAC）============
def mock_sign(payload: dict, secret: str = DEV_HMAC_SECRET) -> str:
    """本地联调用的代付凭证签名；prod 由支付宝/微信真实签名替代，不可用于生产。"""
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    sig = hmac.new(secret.encode("utf-8"), raw, hashlib.sha256).digest()
    return base64.b64encode(sig).decode("utf-8")


def mock_verify(payload: dict, sig: str, secret: str = DEV_HMAC_SECRET) -> bool:
    return hmac.compare_digest(mock_sign(payload, secret), sig)


def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()
