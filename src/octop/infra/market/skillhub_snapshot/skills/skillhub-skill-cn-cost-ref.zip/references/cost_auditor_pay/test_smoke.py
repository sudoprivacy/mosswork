# -*- coding: utf-8 -*-
"""cost_auditor_pay 端到端冒烟测试（dev mock 模式，无需外部支付 SDK）。

覆盖：9 项能力注册、价库日更桥接、bid_selfcheck 接真实引擎、反幻觉纪律
（基准价缺失 → PENDING 且不评分），以及付费形态下的 402 双通道账单、验付、
幂等履约、微信通道、单包价报价、免费试用额度、用量对账、退款标记。

⚠ 重写记录（v20260930-16F）：
  ① 原测试用 `sqlite:///./_smoke_test.db` 但**从不清理**，第二次运行时
     `u_free_smoke` 的 3 次免费额度已被上一轮吃光 → `free_quota_first3_free`
     必然失败。属于"跑一次就废"的不可重复测试。现启动前先删除库。
  ② 原测试绑死付费形态：改为免费形态后 T1「期望 402」必然失败。
     现按 CAP_EDITION 双分支——free 形态验「不收费不返 402 直接交付」。
"""
import os
import sys

# 启动前清库，保证可重复运行
_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_smoke_test.db")
if os.path.exists(_DB):
    os.remove(_DB)
os.environ["CAP_ORDER_DB"] = f"sqlite:///{_DB}"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi.testclient import TestClient  # noqa: E402
import main  # noqa: E402
from config import EDITION, FREE_MODE  # noqa: E402
from payment.a2m import AlipayA2MProvider  # noqa: E402
from payment.x402 import WeixinX402Provider  # noqa: E402

client = TestClient(main.app)
ali = AlipayA2MProvider()
wxn = WeixinX402Provider()
_fails = []


def check(name, cond, extra=""):
    ok = bool(cond)
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {extra}")
    if not ok:
        _fails.append(name)


print(f"===== 形态：{EDITION}（{'免费，不需支付' if FREE_MODE else '付费'}）=====")

# ---------- 1) health + 9 项能力注册（两形态通用）----------
r = client.get("/health")
caps = r.json()["capabilities"]
check("health", r.status_code == 200 and "cad_takeoff" in caps)
for c in ("reprice", "settle_review", "cad_takeoff", "bid_selfcheck",
          "claim_report", "price_query", "index_compare", "clear_tender", "health_check"):
    check(f"cap_registered:{c}", c in caps)

# ---------- 2) 未知能力 404（两形态通用）----------
r = client.post("/v1/capability/unknown")
check("unknown_capability_404", r.status_code == 404)


# ---------- 3) 形态相关主链 ----------
if FREE_MODE:
    r = client.post("/v1/capability/cad_takeoff", json={"pdf_path": "x.pdf", "page": 0})
    check("free_no_402", r.status_code == 200, f"status={r.status_code}")
    check("free_no_Payment-Needed", "Payment-Needed" not in r.headers)
    check("free_content", r.json().get("content", {}).get("capability") == "cad_takeoff")
    check("free_marked", r.json().get("free_mode") is True)
    q = client.get("/v1/capability/reprice/quote")
    check("free_quote_zero", q.status_code == 200 and q.json()["amount"] == "0.00",
          f"amount={q.json().get('amount')}")
else:
    # 未支付 → 402 双通道意图（支付宝）
    r = client.post("/v1/capability/cad_takeoff", json={"pdf_path": "x.pdf", "page": 0})
    check("402_status", r.status_code == 402, f"status={r.status_code}")
    check("has_Payment-Needed", "Payment-Needed" in r.headers)
    check("has_WeixinPay-Required", "WeixinPay-Required" in r.headers)
    check("has_X-Out-Trade-No", "X-Out-Trade-No" in r.headers)
    check("has_code_url", "code_url" in r.json())
    check("amount_is_15", r.json()["amount"] == "15.00")
    ot = r.headers["X-Out-Trade-No"]

    # 支付宝通道：mock 凭证 → 200 + 结果
    proof = ali.make_mock_proof(ot, "MOCKTRADE001")
    r2 = client.post("/v1/capability/cad_takeoff",
                     headers={"Payment-Proof": proof}, json={"pdf_path": "x.pdf", "page": 0})
    check("alipay_paid_200", r2.status_code == 200, f"status={r2.status_code}")
    check("alipay_content", r2.json()["content"]["capability"] == "cad_takeoff")
    check("alipay_confidence_field", "confidence" in r2.json()["content"])
    check("alipay_engine_field", "engine" in r2.json()["content"])
    check("alipay_validation_header", "Payment-Validation" in r2.headers)

    # 幂等：同一凭证重试
    r3 = client.post("/v1/capability/cad_takeoff",
                     headers={"Payment-Proof": proof}, json={"pdf_path": "x.pdf", "page": 0})
    check("idempotent_200", r3.status_code == 200)
    check("idempotent_flag", r3.json().get("already_fulfilled") is True)

    # 微信通道
    r4 = client.post("/v1/capability/settle_review", json={"claims": [{"item": "A"}]})
    check("wx_402", r4.status_code == 402)
    ot2 = r4.headers["X-Out-Trade-No"]
    wx_proof = wxn.make_mock_proof(ot2)
    r5 = client.post("/v1/capability/settle_review",
                     headers={"X-PAYMENT": wx_proof}, json={"claims": [{"item": "A"}]})
    check("wx_paid_200", r5.status_code == 200)
    check("wx_content", r5.json()["content"]["capability"] == "settle_review")
    check("wx_response_header", "X-Payment-Response" in r5.headers)

    r6 = client.get("/v1/capability/reprice/quote")
    check("quote", r6.status_code == 200 and r6.json()["amount"] == "15.00")

    # 免费试用额度（独立用户 u_free；库已在启动时清空）
    FREE_USER = "u_free_smoke"
    free_hits = 0
    for _ in range(3):
        rf = client.post("/v1/capability/reprice", headers={"X-User-Token": FREE_USER},
                         json={"items": [{"name": "电缆"}]})
        if rf.status_code == 200 and rf.json().get("free_quota") is True:
            free_hits += 1
    check("free_quota_first3_free", free_hits == 3, f"免单次数={free_hits}")
    rf4 = client.post("/v1/capability/reprice", headers={"X-User-Token": FREE_USER},
                      json={"items": [{"name": "电缆"}]})
    check("free_quota_exceed_then_402", rf4.status_code == 402, f"status={rf4.status_code}")

# ---------- 4) 用量对账（两形态通用）----------
U = "u_usage_smoke"
client.post("/v1/capability/price_query", headers={"X-User-Token": U}, json={"kw": "钢筋"})
ru = client.get("/v1/usage", headers={"X-User-Token": U})
check("usage_200", ru.status_code == 200)
check("usage_counts", ru.json()["total_calls"] >= 1, f"calls={ru.json()['total_calls']}")

# ---------- 5) 退款标记方法可调用 ----------
try:
    main.REPO.mark_refund("nonexistent_ot_smoke")
    check("refund_mark_safe", True)
except Exception as e:  # noqa: BLE001
    check("refund_mark_safe", False, str(e))

# ---------- 6) 价库日更桥接 ----------
rp = client.post("/v1/capability/price_query", headers={"X-User-Token": "u_pq_smoke"},
                 json={"kw": "钢筋"})
check("price_query_200", rp.status_code == 200, f"status={rp.status_code}")
pq = rp.json().get("content", {}) if rp.status_code == 200 else {}
check("price_query_db_live", pq.get("price_db", {}).get("ok") is True)
check("price_query_hit", pq.get("result", {}).get("hit_count", 0) > 0,
      f"hits={pq.get('result', {}).get('hit_count')}")
check("price_query_four_elements",
      all(p.get("period") and p.get("basis") and p.get("region") and p.get("source")
          for p in pq.get("result", {}).get("prices", [])))
check("price_query_changelog", pq.get("price_db", {}).get("changelog_total", 0) > 0,
      f"changelog={pq.get('price_db', {}).get('changelog_total')}")

# ---------- 7) bid_selfcheck 接真实引擎 cost_adjuster.py ----------
rb = client.post("/v1/capability/bid_selfcheck", headers={"X-User-Token": "u_bs_smoke"},
                 json={"quotes": [{"name": "混凝土·C30", "price": 500,
                                   "qty": 100, "unit": "m3"}]})
check("bid_selfcheck_200", rb.status_code == 200, f"status={rb.status_code}")
bs = rb.json().get("content", {}) if rb.status_code == 200 else {}
check("bid_engine_ran", bs.get("engine", {}).get("engine_ran") is True)
check("bid_engine_live", bs.get("engine", {}).get("live") is True)
check("bid_engine_is_cost_adjuster",
      "cost_adjuster" in str(bs.get("engine", {}).get("engine", "")))
check("bid_computed", bs.get("result", {}).get("computed_count", 0) >= 1,
      f"computed={bs.get('result', {}).get('computed_count')}")
first_item = (bs.get("result", {}).get("items") or [{}])[0]
check("bid_has_deviation", first_item.get("deviation_pct") is not None,
      f"dev={first_item.get('deviation_pct')}")
check("bid_has_flag", first_item.get("flag") in ("正常", "虚高预警", "压低预警", "无法判定"),
      f"flag={first_item.get('flag')}")
check("bid_benchmark_from_db", first_item.get("benchmark_source") == "price_db",
      f"src={first_item.get('benchmark_source')}")

# ---------- 8) 反幻觉：基准价缺失 → PENDING 且不评分 ----------
rb2 = client.post("/v1/capability/bid_selfcheck", headers={"X-User-Token": "u_rb_smoke"},
                  json={"quotes": [{"name": "未入库材料XYZ", "price": 100,
                                    "qty": 1, "unit": "t"}]})
bs2 = rb2.json().get("content", {}) if rb2.status_code == 200 else {}
check("bid_no_bench_pending", bs2.get("confidence") == "PENDING", f"conf={bs2.get('confidence')}")
check("bid_no_bench_no_score",
      bs2.get("result", {}).get("selfcheck", {}).get("score") is None)
check("bid_no_bench_unresolved",
      len(bs2.get("result", {}).get("unresolved", [])) >= 1)

# ---------- 汇总 ----------
total = len(_fails)
print()
if _fails:
    print(f"❌ 冒烟测试失败 {len(_fails)} 项：{_fails}")
    sys.exit(1)
print(f"✅ 全部冒烟测试通过（edition={EDITION}）")
if os.path.exists(_DB):
    try:
        os.remove(_DB)
    except OSError:
        pass
