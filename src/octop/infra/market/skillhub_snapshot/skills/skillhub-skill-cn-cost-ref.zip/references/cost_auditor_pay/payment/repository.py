# -*- coding: utf-8 -*-
"""
payment/repository.py · 订单仓储（真实持久化，禁用内存兜底）

实现 alipay-aipay A2M demo 要求的四个方法：
  create_pending / find_by_out_trade_no / prepare_fulfillment / mark_fulfilled
prepare_fulfillment 必须原子地校验订单、只生成一次资源（幂等履约）。

prod 可替换为 MySQL/PG 实现，只要满足同接口即可。
"""
import json
import sqlite3
import threading
from datetime import datetime, timezone
from typing import Callable, Optional

from config import ORDER_DB_URL


class OrderRepository:
    """接口契约（供替换实现复用）。"""

    def create_pending(self, order: dict) -> None:  # pragma: no cover
        raise NotImplementedError

    def find_by_out_trade_no(self, out_trade_no: str) -> Optional[dict]:  # pragma: no cover
        raise NotImplementedError

    def prepare_fulfillment(self, req: dict) -> Optional[dict]:  # pragma: no cover
        raise NotImplementedError

    def mark_fulfilled(self, out_trade_no: str, trade_no: str) -> None:  # pragma: no cover
        raise NotImplementedError


class SqliteOrderRepository(OrderRepository):
    def __init__(self, db_url: str = ORDER_DB_URL):
        assert db_url.startswith("sqlite:///"), "本骨架仅演示 sqlite；prod 请实现对应 DB 仓储"
        self._path = db_url[len("sqlite:///"):]
        self._lock = threading.Lock()
        self._init_schema()

    def _conn(self):
        return sqlite3.connect(self._path, timeout=15)

    def _init_schema(self):
        with self._conn() as c:
            c.execute(
                """
                CREATE TABLE IF NOT EXISTS orders (
                    out_trade_no TEXT PRIMARY KEY,
                    amount        TEXT NOT NULL,
                    currency      TEXT NOT NULL,
                    resource_id   TEXT NOT NULL,
                    goods_name    TEXT,
                    pay_before    TEXT,
                    order_status  TEXT NOT NULL,
                    fulfill_status TEXT NOT NULL,
                    trade_no      TEXT,
                    service_result TEXT,
                    need_refund   INTEGER DEFAULT 0,
                    created_at    TEXT,
                    updated_at    TEXT
                )
                """
            )
            # 用量计量表：每次成功履约（含免费免单）记录一笔，支撑对账与额度
            c.execute(
                """
                CREATE TABLE IF NOT EXISTS usage (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_token    TEXT NOT NULL,
                    capability    TEXT NOT NULL,
                    amount        TEXT NOT NULL,
                    out_trade_no  TEXT,
                    free          INTEGER DEFAULT 0,
                    created_at    TEXT
                )
                """
            )

    def create_pending(self, order: dict) -> None:
        now = datetime.now(timezone.utc).astimezone().isoformat()
        with self._conn() as c:
            c.execute(
                """
                INSERT OR IGNORE INTO orders
                (out_trade_no, amount, currency, resource_id, goods_name, pay_before,
                 order_status, fulfill_status, created_at, updated_at)
                VALUES (?,?,?,?,?,?, 'PENDING_PAYMENT', 'UNFULFILLED', ?, ?)
                """,
                (
                    order["out_trade_no"], order["amount"], order["currency"],
                    order["resource_id"], order.get("goods_name"),
                    order.get("pay_before"), now, now,
                ),
            )

    def find_by_out_trade_no(self, out_trade_no: str) -> Optional[dict]:
        with self._conn() as conn:
            cur = conn.execute(
                "SELECT * FROM orders WHERE out_trade_no=?", (out_trade_no,)
            )
            row = cur.fetchone()
            if not row:
                return None
            cols = [d[0] for d in cur.description]
            o = dict(zip(cols, row))
            if o.get("service_result"):
                try:
                    o["service_result"] = json.loads(o["service_result"])
                except (json.JSONDecodeError, TypeError):
                    pass
            return o

    def prepare_fulfillment(self, req: dict) -> Optional[dict]:
        """
        原子幂等履约：同 out_trade_no 只生成一次 service_result。
        req: {out_trade_no, trade_no, expected_amount, expected_resource_id, create_resource}
        """
        out_trade_no = req["out_trade_no"]
        with self._lock:
            with self._conn() as c:
                cur = c.execute(
                    "SELECT * FROM orders WHERE out_trade_no=?", (out_trade_no,)
                )
                row = cur.fetchone()
                if not row:
                    return None
                cols = [d[0] for d in cur.description]
                o = dict(zip(cols, row))

                # 已履约：直接返回既有结果（幂等）
                if o["fulfill_status"] in ("PENDING_CONFIRM", "FULFILLED"):
                    return {
                        "state": o["fulfill_status"],
                        "service_result": (
                            json.loads(o["service_result"])
                            if o.get("service_result") else None
                        ),
                    }

                # 首次生成资源
                create_resource: Callable = req["create_resource"]
                service_result = create_resource()
                now = datetime.now(timezone.utc).astimezone().isoformat()
                c.execute(
                    """
                    UPDATE orders
                    SET fulfill_status='PENDING_CONFIRM',
                        trade_no=?,
                        service_result=?,
                        updated_at=?
                    WHERE out_trade_no=?
                    """,
                    (req.get("trade_no"), json.dumps(service_result, ensure_ascii=False),
                     now, out_trade_no),
                )
                return {"state": "PENDING_CONFIRM", "service_result": service_result}

    def mark_fulfilled(self, out_trade_no: str, trade_no: str) -> None:
        with self._conn() as c:
            now = datetime.now(timezone.utc).astimezone().isoformat()
            c.execute(
                """
                UPDATE orders
                SET fulfill_status='FULFILLED', order_status='PAID',
                    trade_no=COALESCE(NULLIF(trade_no,''), ?), updated_at=?
                WHERE out_trade_no=?
                """,
                (trade_no, now, out_trade_no),
            )

    # ----- 用量计量与退款（企业级治理）-----
    def record_event(self, user_token: str, capability: str, amount: str,
                     out_trade_no: Optional[str], free: int = 0) -> None:
        """记录一次成功履约（含免费免单），用于额度判定与对账。"""
        now = datetime.now(timezone.utc).astimezone().isoformat()
        with self._conn() as c:
            c.execute(
                """
                INSERT INTO usage (user_token, capability, amount, out_trade_no, free, created_at)
                VALUES (?,?,?,?,?,?)
                """,
                (user_token, capability, amount,
                 out_trade_no if out_trade_no else None, free, now),
            )

    def count_fulfilled_today(self, user_token: str) -> int:
        """该用户当日已成功履约（含免费）次数，用于免费额度判定。"""
        with self._conn() as c:
            cur = c.execute(
                """
                SELECT COUNT(*) FROM usage
                WHERE user_token=? AND date(created_at)=date('now','localtime')
                """,
                (user_token,),
            )
            return cur.fetchone()[0] or 0

    def daily_spend(self, user_token: str) -> str:
        """该用户当日实付累计（免费笔不计入），用于单日消费上限熔断。"""
        with self._conn() as c:
            cur = c.execute(
                """
                SELECT COALESCE(SUM(CAST(amount AS REAL)),0) FROM usage
                WHERE user_token=? AND free=0 AND date(created_at)=date('now','localtime')
                """,
                (user_token,),
            )
            return f"{cur.fetchone()[0]:.2f}"

    def usage_stats(self, user_token: str) -> dict:
        with self._conn() as c:
            cur = c.execute(
                """
                SELECT capability, COUNT(*), COALESCE(SUM(CAST(amount AS REAL)),0),
                       SUM(free)
                FROM usage WHERE user_token=? GROUP BY capability
                """,
                (user_token,),
            )
            rows = cur.fetchall()
            total = c.execute(
                "SELECT COUNT(*), COALESCE(SUM(CAST(amount AS REAL)),0) FROM usage WHERE user_token=?",
                (user_token,),
            ).fetchone()
        return {
            "user_token": user_token,
            "by_capability": [
                {"capability": r[0], "calls": r[1], "paid": f"{r[2]:.2f}", "free": r[3]}
                for r in rows
            ],
            "total_calls": total[0] or 0,
            "total_paid": f"{total[1]:.2f}",
        }

    def mark_refund(self, out_trade_no: str) -> None:
        """标记订单需退款（prod 接真实支付宝退款 API；dev 仅占位）。"""
        with self._conn() as c:
            now = datetime.now(timezone.utc).astimezone().isoformat()
            c.execute(
                "UPDATE orders SET need_refund=1, fulfill_status='UNFULFILLED', updated_at=? WHERE out_trade_no=?",
                (now, out_trade_no),
            )

    def reset_for_test(self):
        with self._conn() as c:
            c.execute("DELETE FROM orders")
            c.execute("DELETE FROM usage")
