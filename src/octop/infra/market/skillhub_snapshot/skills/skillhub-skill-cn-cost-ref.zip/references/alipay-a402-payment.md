# 支付宝 AI 按量付费（A402）接入规范 —— 造价稽核官·卖端视角

> **定位**：让本技能对外提供的付费能力（如"某次综合单价核对""某预算文件深度审核"）通过 **支付宝 AI 按量付费（A2M / HTTP 402 Payment Required）** 向调用它的 AI Agent 按次收款。
> **来源**：支付宝官方 Skill `@alipay/alipay-aipay`（v1.6.6，安装后位于 `~/.agents/skills/alipay-aipay`）的 AI 按量付费本地接口契约 + Agent 场景最佳实践，聚焦**收款方（卖端）**应实现的五个必查点：① 402 账单下发（Payment-Needed / Payment-Proof）② 携带凭证重试 ③ 验付调用（`alipay.aipay.agent.payment.verify`）④ 履约确认（`alipay.aipay.agent.fulfillment.confirm`）⑤ 订单持久化与幂等。
> **配套脚本**：`scripts/alipay_payment_gateway.py`（已升级为官方真实 A2M：单路径资源接口 + 支付宝 SDK Model 类调用 + 持久化 repository 端口；沙箱默认、无密钥不伪造）。
> **官方依赖**：`pip install alipay-sdk-python pycryptodome flask`（已在本地验证可导入全部 A2M Model 类）。

---

## 〇、一句话理解 x402

> 把"付费资源"当成**自动售货机**：Agent 首次请求付费资源 → 服务端不回内容，而是返 `402` + 账单（Payment-Needed）→ Agent 展示账单让用户付款 → 用户付款后 Agent 携带**支付凭证（Payment-Proof）**再次请求 → 服务端调支付宝**验付**（`payment.verify`）通过 → **履约确认**（`fulfillment.confirm`）后返回资源 → **记录订单**（防重复扣款/重复发货）。

```
Agent ──GET/POST /resource/<id> 请求付费资源──▶ 卖端
Agent ◀──402 Payment Required + Payment-Needed(Base64URL账单)── 卖端
Agent(持Payment-Proof) ──携带凭证重试同路径──▶ 卖端
Agent ◀──验付通过(支付宝SDK) → 履约确认(支付宝SDK) → 200 返回资源── 卖端
```

---

## 一、服务端架构：单路径资源接口（非自建三端点）

> ⚠️ **本版核心修正**：早期骨架写的是"自建三端点 `prepare/payment-needed/check`"。接入官方 SDK 后确认 **官方 A2M 采用"单路径资源接口 + 支付宝开放平台网关"**：同一资源 URL，无 Proof 返 402、有 Proof 验付履约后返 200。**不要在卖端自建/伪造一套 `alipay.trade.*` 查单结算端点。**

| 环节 | 官方做法 |
|:--|:--|
| 资源接口 | **单一** `GET/POST /resource/<resource_id>`：无有效 `Payment-Proof` 头 → **HTTP 402 + `Payment-Needed` 头**；携 Proof → 验付+履约 → **200 返回资源** |
| 验付 | 调支付宝网关接口 **`alipay.aipay.agent.payment.verify`**（SDK Request 类 `AlipayAipayAgentPaymentVerifyRequest`，Model 类 `AlipayAipayAgentPaymentVerifyModel`，入参 `trade_no`/`payment_proof`/可选 `client_session`） |
| 履约确认 | 调支付宝网关接口 **`alipay.aipay.agent.fulfillment.confirm`**（`AlipayAipayAgentFulfillmentConfirmRequest`/`Model`，入参仅 `trade_no`） |
| 网关 | 支付宝 SDK client 指向 `gateway.do`（沙箱 `openapi-sandbox.dl.alipaydev.com` / 生产 `openapi.alipay.com`） |

> **状态判定**：支付宝返回 **`code==10000` 才算成功**；验付成功还必须 `active=true`（凭证有效）。判断"已付款"的唯一权威是支付宝验付响应，**不是**客户端自述或自建查单。

---

## 二、账单（Payment-Needed）核心字段

`bill` 是 Base64URL 编码的 JSON，解码后含两层：

**bill.protocol（协议/交易要素）—— 必须 8 字段**
| 字段 | 含义 |
|:--|:--|
| `out_trade_no` | 商户订单号（幂等键之一，必须唯一） |
| `amount` | 金额（元，两位小数） |
| `currency` | `CNY` |
| `resource_id` | 资源标识（另一幂等键） |
| `pay_before` | 支付有效期，**带时区 ISO8601**（如 `2026-09-09T10:44:04+08:00`），非时间戳 |
| `seller_signature` | 商家账单签名（RSA2，见下） |
| `seller_sign_type` | `RSA2` |
| `seller_unique_id` | 商户唯一 ID（= seller_id） |

**bill.method（收款商户信息）—— 必须 6 字段**
`seller_name` / `seller_id`(2088) / `seller_app_id` / `goods_name` / `seller_unique_id_key`(= `seller_id`) / `service_id`

> ⚠️ `out_trade_no` + `resource_id` 共同构成**幂等键**：同一 (resource_id, out_trade_no) 只应产生一次发货，重复请求不重复扣款、不重复返回资源。

### 商家账单签名（RSA2，本地完成）
签名字段按 key **字典序**拼接 `k=v` 后用 `&` 连接：
`amount,currency,goods_name,out_trade_no,pay_before,resource_id,seller_id,service_id`
用商户**私钥（PKCS#1 v1.5 + SHA256）**签名，Base64 输出。签名只在商家本地完成，**不请求支付宝服务端**。

---

## 三、五个必查点 → 落地实现

### ① 402 账单下发（Payment-Needed / Payment-Proof）
- 首次请求资源：未持有效凭证 → 返回 `402`，响应头写 `Payment-Needed: <Base64URL账单>`，body 给可读信息（`out_trade_no`/`amount` 等）。**Agent 支付依据是 Header，不是 body。**
- **Payment-Proof** = 买方付款成功后回传的凭证（Base64URL JSON：`{protocol:{payment_proof, trade_no}, method:{client_session?}}`）。解码后至少读 `payment_proof`、`trade_no`。

### ② 携带凭证重试
- 客户端支付成功后，携带 `Payment-Proof` 头**重试同一资源 URL**。
- 服务端**不得**因上次已返 402 而拒绝；按幂等键/订单查重。

### ③ 验付调用（官方 SDK）
- 解码 Proof → 取 `payment_proof` + `trade_no`(+可选 `client_session`) → 调 `AlipayAipayAgentPaymentVerifyRequest`（**必须用 Model 类赋 `biz_model`，不能 dict**）。
- **严格六项校验**，任一失败返 402 让 Agent 重新支付，不得返回资源：
  1. `active=true`
  2. 返回 `trade_no` 非空且与凭证一致
  3. 返回 `out_trade_no` 等于本地订单号
  4. 返回 `amount` 等于本地订单金额
  5. 返回 `resource_id` 等于当前请求资源
  6. 订单处于可履约态（首次履约须在 `pay_before` 内未取消；已待确认/已完成只能复用或重试确认）
- **反幻觉**：只认支付宝网关返回，不凭客户端自述放行。

### ④ 履约确认（官方 SDK）
- 资源生成（**只生成一次**）→ 调 `AlipayAipayAgentFulfillmentConfirmRequest`（入参仅 `trade_no`）→ **确认成功后才**把订单标为最终完成并发资源。
- 确认失败允许同一 Payment-Proof 重试确认，避免"资源已生成但平台未记录履约"。

### ⑤ 订单持久化与幂等
- **官方红线**：验付/履约前订单必须真实持久化，`configure_order_repository()` 绑定项目真实 DB，**禁止回退进程内存**。
- 幂等：同 (resource_id, out_trade_no) —— 已 FULFILLED 直接返回已存资源；已 PENDING_CONFIRM 只复用或重试确认；不重复扣款/不重复生成资源。DB 用事务 + 唯一约束。

---

## 四、状态机（订单）

官方把支付状态映射 `PENDING_PAYMENT/PAID`，履约状态映射 `UNFULFILLED/PENDING_CONFIRM/FULFILLED`：

```
PENDING_PAYMENT/UNFULFILLED ──验付通过→ PENDING_CONFIRM ──履约确认成功→ FULFILLED
        │                            (资源已生成,待平台确认)      (并发资源)
        └─过期/校验失败→ 拒绝(返402,可重下账单)        └─确认失败→ 同Proof重试确认
```

> 关键：**只有履约确认成功后（FULFILLED）才发内容**；FULFILLED 遇重复请求**幂等返回**同一资源，不二次扣款、不重复生成。

---

## 五、接入配置（沙箱 / 线上）

环境变量（**不写进代码、不进 git**）：
```
AIPAY_APP_ID=2024...            # 应用APPID
AIPAY_PRIVATE_KEY=...           # 商户私钥(PKCS#1 Base64, 商家签名+请求签名)
AIPAY_ALIPAY_PUBLIC_KEY=...     # 支付宝公钥(验签用)
AIPAY_SELLER_ID=2088...         # 商户ID(2088格式)
AIPAY_SERVICE_ID=api_mock_service_id   # 沙箱固定mock；生产换服务市场真实serviceId
AIPAY_GATEWAY=https://openapi-sandbox.dl.alipaydev.com/gateway.do   # 沙箱默认
# 线上: https://openapi.alipay.com/gateway.do
```

> **反幻觉纪律**：未配置 `AIPAY_APP_ID/AIPAY_PRIVATE_KEY/AIPAY_ALIPAY_PUBLIC_KEY/AIPAY_SELLER_ID` → 不初始化真实 SDK client，验付/履约只走**明示模拟**（打 `mock=True`），**绝不伪造"已通过支付宝验付/已履约/已收款"**。
> **密钥边界**：官方红线禁止向 Agent 索要/处理生产私钥、禁止生成密钥对、禁止补全改写公钥。密钥由商家在支付宝开放平台自行生成并配置。

---

## 六、与造价业务的结合（本技能怎么按量变现）

| 付费资源（resource_id） | 计价 | 计费粒度 | gateway 默认注册 |
|:--|:--|:--|:--|
| `BOQ_REVIEW_ONCE` | 工程量清单一次复核 | 按次 | ✓ 0.99 |
| `UNIT_PRICE_AUDIT` | 综合单价审核（单条） | 按次 | ✓ 2.99 |
| `SETTLEMENT_QUERY` | 结算争议/索赔检索 | 按次 | ✓ 1.99 |
| （可扩展）`MATERIAL_PRICE_CURRENT` | 当期材料价档 | 按次 | 加进 DEFAULT_RESOURCES |

> 单价在 `goods_name` 明确、金额 `amount` 与 `resource_id` 绑定，Agent 按 `resource_id` 自动走 402。**定价/计量须与技能真实能力匹配，不做"收了钱给不出货"的能力承诺。**

---

## 七、Checklist（过审 + 上线）

- [ ] 资源接口：无 Proof 返 **402 + `Payment-Needed` 头**；有 Proof 验付+履约后返 **200 资源**
- [ ] `Payment-Needed.protocol` 8 字段齐、`method` 6 字段齐，`pay_before` 为带时区 ISO8601
- [ ] 商家账单 RSA2 签名：8 字段字典序本地签名
- [ ] 处理 `Payment-Proof` 重试（同一资源路径，按幂等查单）
- [ ] 验付：`payment.verify` 严格六项校验，`code==10000` 且 `active=true`
- [ ] 履约：`fulfillment.confirm` **成功后才**返回资源；失败可同 Proof 重试确认
- [ ] 订单真实持久化（DB/JSON 非内存），(resource_id, out_trade_no) 幂等，不重复扣款/发货
- [ ] SDK 依赖就绪（`alipay-sdk-python`/`pycryptodome`/`flask`），本地可 import 全部 A2M Model 类
- [ ] 沙箱跑通全链路（402→付款→Proof→验付→履约→200）再上线上；线上换正式 gateway/serviceId
- [ ] 密钥走环境变量，不入库、不进版本库
