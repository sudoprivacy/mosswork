# 造价稽核官 × 造价师AI学习系统 联动桥（bridge/）

> 本目录把**造价稽核官技能**的沉淀物，桥接给**造价师AI学习系统 / 建材价日更流水线**消费，
> 实现两套系统"能读对方的数据、不打架、价源可回写"。
> 技能本体在 `scripts/` + `references/`，本桥只做**导出/对接**，不改写技能内部库。

---

## 一、桥接的两种数据 + 两个脚本

| 桥 | 脚本 | 导出处 | 消费端 | 用途 |
|---|---|---|---|---|
| 考点学习卡桥 | `exam_export.py` | exam-mapping 派生的 10 张考点卡 | AI学习系统题库/刷题/每日推送 | 把"考什么"变成可刷学习卡，做中学回查规范 |
| 建材价日更桥 | `price_sync_export.py` | `scripts/data/material_prices.json`(schema 1.1 带 source_id) | 日更流水线(如 automation zaojia_update_daily.py) | 两套价库对齐，价带口径与置信度不丢失 |

---

## 二、接入点与字段映射

### 2.1 考点学习卡 → 学习系统
```
exam_export.py --json cards.json --csv cards.csv
```
每张卡字段 → 学习系统字段映射：

| 本桥字段 | 学习系统建议落位 | 说明 |
|---|---|---|
| `card_id` | 题库主键(去重) | 稳定，可增量更新 |
| `point` | 卡片标题/考点标签 | |
| `subject`/`module` | 科目/章节分类 | 便于按备考计划索引 |
| `basis` | 知识点"规范依据"正文 | 引导回查**现行版** |
| `trap` | 刷题"易错点提示" | 与技能纠错呼应 |
| `how`/`skill_ref` | 延展"可练命令/工具" | 一键跳技能脚本做实战 |
| `priority` | 复习权重(高/中/低) | 可接每日刷题调度 |

> 学习系统侧去重键 = `card_id`；更新策略建议"全量覆盖 + 按 card_id 合并"，避免重复卡。

### 2.2 建材价日更 → 流水线
```
price_sync_export.py --json prices.json --csv prices.csv --latest   # 每日轻量(每材最新)
price_sync_export.py --json all.json --period 2026-08 --region 广州  # 指定期/地区全量
```
导出行字段：

| 字段 | 说明 |
|---|---|
| `as_of` | 价期号(如 2026-08)，即"该价代表哪个月" |
| `region` / `material` / `spec` / `unit` | 地区/类别/规格/单位 |
| `caliber` | **口径**(信息价税前/市场价/市场主流区间) —— 展示必带，防误当权威 |
| `price` | 价格数值 |
| `confidence` | 可核/市场核/经验估 |
| `source_id` / `source_desc` | 来源批次 + 可读描述(溯源链) |

> **双写策略建议**：本桥把技能价库导出给日更流水线**展示/对照**；流水线当日更到更权威的新价时，
> 用 `scripts/material_price_update.py add/batch` 把权威价**回写技能价库**(带置信度=可核/市场核，
> 带来源)，形成"技能审价 → 学习端展示 → 权威价回写技能"的闭环。勿在两端各维护一份手改的价。

---

## 三、字段口径红线（对接时务必遵守）

1. **别把"市场区间代表值"当权威信息价**：confidence=市场核 的下游展示应标注为"区间/市场参考"；
   只有 confidence=可核 才可作为核减/比对基准。对齐技能 `price_trace.py` 的效力评级。
2. **口径必随价**：信息价税前 ≠ 市场含税，下游展示/比较须带 caliber，先统一口径再比价。
3. **规范依据标"现行版"**：basis 指向现行标准(GB/T 50500-2024/50854-2024)；涉税涉规费以当期政策原文为准。
4. **学习卡非真题**：考点卡是"备考归纳"，正式刷题以当年官方考纲/真题为准(标"备考参考")。

---

## 四、在用户环境挂载 / 每日触发配置示例

> 造价师AI学习系统与 automation-6 流水线运行在**你的环境**(非本技能沙箱)，本桥给出接入示例，
> 你按实际路径把下面命令挂到对应工作流即可。

**每日建材价日更(挂 automation 定时)**
```bash
# 导出当前技能价库最新各材价 → 交给日更流水线对照/展示
cd <技能根目录>/bridge
python3 price_sync_export.py --latest --csv /data/zaojia_prices_latest.csv --json /data/zaojia_prices_latest.json
# 日更流水线取得新权威价后,回写技能价库(举例;参数见 material_price_update.py add --help)
cd ../scripts
python3 material_price_update.py add 水泥 "P.O 42.5R散装" \
  --period 2026-09 --region 广州 --basis 信息价税前 --price 288.0 \
  --source "广州造价站2026-09(待核)" --conf 经验估 --unit t
```

**每周/月考点推送(挂到学习系统内容源)**
```bash
cd <技能根目录>/bridge
python3 exam_export.py --csv /data/exam_cards.csv --json /data/exam_cards.json
# 学习系统按 card_id 全量合并刷新题库,按 priority 安排每日推送
```

---

## 五、配套自检
- `python3 exam_export.py --json /tmp/c.json` → 得到 `card_count` 张卡，字段完整；
- `python3 price_sync_export.py --latest --csv /tmp/p.csv` → 每种材料最新一期一行，带 caliber/confidence/source_id；
- 缺字段/缺口径 → 先回技能价库用 `material_price_update.py` 补齐，别在桥端硬凑。
