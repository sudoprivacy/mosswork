# 造价稽核官 CostAuditor · Pay Skill 后端骨架（cost_auditor_pay）

把「造价稽核官」核心能力包装为可被 SkillHub Pay Skill 远程调用的 HTTP 服务，
承载 5 项按次计费能力；支付链路严格对齐：

- **支付宝 AI 按量付费（A2M）**：`402 Payment-Needed` 头 + `Payment-Proof` 验付 + `Payment-Validation` 回执
  （协议形状直接复刻 `alipay-aipay` 的 `A2MPaymentDemo`，真实接口 `alipay.aipay.agent.payment.verify` / `fulfillment.confirm`）
- **微信支付 AI 专属卡（SkillHub X402）**：`402 WeixinPay-Required` + `X-Out-Trade-No` + `code_url` 二维码兜底
- **双通道统一 402**：一次下单同时返回两套支付意图，Agent 按自身插件能力择一支付

> 与 SKILL.md 的「AI 支付 / Pay Skill 接入（B.1–B.4）」章节一一对应；前端 Agent 走 `POST /v1/capability/{capability}`。

## 目录
```
cost_auditor_pay/
├── main.py              # FastAPI 应用：/health、/quote、/v1/capability/{capability}
├── config.py            # 配置中心（商户号/单价/网关，全部环境变量注入）
├── capabilities.py      # 9 项能力实现（真实引擎接线层：subprocess 调 cn-cost-ref/scripts）
├── payment/
│   ├── crypto.py        # Base64URL + RSA2（真实）/ HMAC（dev mock）签名
│   ├── repository.py    # 订单仓储（SQLite，禁用内存兜底，幂等履约）
│   ├── a2m.py           # 支付宝 A2M 协议层
│   └── x402.py          # 微信 X402 协议层
└── requirements.txt
```

## 9 项能力（统一单包价计费）

> 计费模式：**单包价 15.00 元/次**，9 项能力合并为单一计费项「造价稽核一次」，402 账单不分能力、报统一价格（`config.py` 的 `PACKAGE_PRICE`，可由 `CAP_PACKAGE_PRICE` 环境变量覆盖）。

| 能力键 | 含义 | 对应技能模块 | 真实引擎（`cn-cost-ref/scripts`） |
|:---|:---|:---|:---|
| `reprice` | 综合单价重算/核减 | 模块五 §5.12、模块七 | `price_estimator.py` |
| `settle_review` | 结算争议核减分析 | 模块四 §4.8、§7.2 | `audit_triple_source.py` |
| `cad_takeoff` | 工程量图纸核对（CAD算量） | 模块六 | `cadvector_takeoff.py` |
| `bid_selfcheck` | 投标报价经济性自检（不平衡报价） | 模块五 §5.7、模块九 §9.5 | **`cost_adjuster.py`** ✅ 已接线 |
| `claim_report` | 索赔报告生成 | 模块四 §4.5 | `claim_drafter.py` |
| `price_query` | 材料价格查询/市场定价 | 模块五 §5.14、模块九 §9.2 | **价库 `material_prices.json` 实时读** ✅ 已桥接日更 |
| `index_compare` | 造价指标/调差对比 | 模块九 §9.3 | `price_index_lookup.py` |
| `clear_tender` | 招投标清标 | 模块九 §9.4 | `audit_triple_source.py` |
| `health_check` | 成果质量体检 | 模块十 §10.1 | `audit_triple_source.py` |

> 重引擎（`cad_takeoff` 等长耗时算量）默认不执行、需显式传 `execute_real:true`；
> `price_query` / `bid_selfcheck` 为本地零耗时真实计算，**默认实时跑**，付费即出真结果。

### ① `price_query` ← 价库日更桥接

```
material_price_update.py（增量 add/batch + 联网刷新，日更流水线）
        └──→ scripts/data/material_prices.json ──实时读──→ price_query
```

- 日更一写入新价，**本能力即刻读到，无需重启服务**；
- 返回 `price_db` 新鲜度块：`last_publish` / `record_count` / `stale_days` / `periods_covered` / `changelog_total` + 最近 5 条更新记录；
- 价库不可读或未命中 → 自动兜底调 `material_price_lookup.py search`；
- 严守四要素：价格必带「期号+口径+地区+来源」，`可核→HIGH`、`市场核→MEDIUM`、缺来源/经验估→`PENDING`。

### ② `bid_selfcheck` ← 真实引擎 `cost_adjuster.py`

- **基准价**：优先取入参 `benchmark`；未提供则用报价名称**回查日更价库自动匹配**（`benchmark_source=price_db`）；
- **偏差率**：一次调 `cost_adjuster.py batch --json` 算完全部条目，取「调差幅度%」= `ΔP = P₀ × (Ft/F₀ − 1) × Q`；
- **判定**：≥ +15% `虚高预警`；≤ −15% `压低预警`（不平衡报价典型手法）；否则 `正常`；阈值由 `CAP_BID_HIGH/LOW_THRESHOLD` 覆盖；
- **反幻觉**：基准价缺失即**不算偏差、不评分**（`confidence=PENDING`、`score=None`、进 `unresolved`）。

## 运行
```bash
cd cost_auditor_pay
pip install -r requirements.txt
# dev 模式（无真实支付宝密钥 → 走 HMAC mock 自签名验付，仅供本地联调）
CAP_ENV=dev CAP_PORT=8000 uvicorn main:app --host 127.0.0.1 --port 8000

# prod 模式（设齐 ALIPAY_* 真实凭证后，自动切换真实 RSA2 + 支付宝 SDK 验付）
CAP_ENV=prod uvicorn main:app --host 0.0.0.0 --port 8000
```

## 本地 402 全链路自验（沙箱环境，不发起真实付款）
```bash
# 1) 先启动服务（见上，dev 模式）
# 2) 跑全链路自测：402 账单 → Payment-Proof 验付 → 资源交付 → 履约回执 → 同单重试
python3 test_a2m_local.py        # 输出 25/25 通过
```
> 说明：本轮为 dev mock 自签名验付（不调用支付宝）。**真实沙箱联调**由 alipay-aipay
> 技能脚本 `a2m run --auto-complete` 承担，需：① 可联网权限；② 支付宝沙箱买家 2088
> 账号；③ 真实沙箱 `appId/私钥/公钥`。届时服务配置 `ALIPAY_SERVICE_ID=api_mock_service_id`
> 不变，脚本会请求 `aicashier.dl.alipaydev.com` 真实收银并回带 `Payment-Proof` 重试本服务。

## 调用流程（以 cad_takeoff 为例）
```bash
# 1) 未支付 → 402 双通道支付意图
curl -s -X POST http://localhost:8000/v1/capability/cad_takeoff \
  -H "X-User-Token: u_demo" -H "Content-Type: application/json" \
  -d '{"pdf_path":"x.pdf","page":0}'
# → HTTP 402，headers: Payment-Needed / WeixinPay-Required / X-Out-Trade-No；body 含 code_url

# 2) 用户支付后，Agent 带支付凭证重试
curl -s -X POST http://localhost:8000/v1/capability/cad_takeoff \
  -H "X-User-Token: u_demo" -H "Payment-Proof: <凭证>" \
  -d '{"pdf_path":"x.pdf","page":0}'
# → HTTP 200，body.content 为造价结论；同 out_trade_no 幂等，只生成一次资源
```

## 上线前必须替换的生产配置
| 项 | dev/sandbox 现状 | 生产必须替换 |
|:---|:---|:---|
| `ALIPAY_APP_ID` | 空 | 支付宝开放平台应用 APP_ID |
| `ALIPAY_SELLER_ID` | 空 | 商户 PID（2088 开头） |
| `ALIPAY_APP_PRIVATE_KEY` | 空 | 应用私钥（PKCS#1 Base64，你本地生成，勿外泄） |
| `ALIPAY_PUBLIC_KEY` | 空 | 支付宝公钥（开放平台复制，禁代生成） |
| `ALIPAY_MERCHANT_PRIVATE_KEY` | 空 | 商家 RSA2 签名私钥 |
| `ALIPAY_GATEWAY` | `openapi-sandbox.dl.alipaydev.com` | `https://openapi.alipay.com/gateway.do` |
| `ALIPAY_SERVICE_ID` | `api_mock_service_id`（沙箱唯一例外） | 服务市场注册/复用的真实 serviceId |
| `CAP_ORDER_DB` | `sqlite:///./cost_auditor_pay_orders.db` | 真实 DB（MySQL/PG），满足事务+唯一约束 |
| `CAP_DEV_SECRET` / HMAC mock | 启用（dev 验付） | **删除**，切真实 `alipay.aipay.agent.payment.verify` |
| `CN_COST_REF_PRICE_DB` | 本地价库 JSON 路径 | 指向生产价库（日更流水线写入的同一份） |
| `capabilities.py` 重引擎 | 默认不跑（防误算/长耗时） | 生产按并发/超时加固后开放 `execute_real` |
| `requirements.txt` | 不含 `alipay-sdk-python` | 生产加 `alipay-sdk-python pycryptodome` |

> 私钥红线（alipay-aipay 执行红线 #6）：应用公钥仅由你生成并提供；禁止向用户索要/处理
> 生产私钥、生成密钥对、补全/改写公钥或添加 PEM 头尾。本骨架 dev 模式**无需任何私钥**即可联调。

## 上架清单（你本人动作）
1. SkillHub 实名认证 + 绑微信/支付宝商户号
2. 在 `config.py` 通过环境变量注入真实 `ALIPAY_*` / `WEIXIN_*` 商户凭证（勿硬编码）
3. 校验 `capabilities.py` 各真实引擎在目标环境的路径与超时（`CN_COST_REF_SCRIPTS_DIR` / `CN_COST_REF_PRICE_DB`）
4. 移除 dev mock 签名（`DEV_HMAC_SECRET`），切换真实 RSA2 / 微信验签
5. `skillhub publish ./cn-cost-ref --dry-run` 预检 → 正式发布；后台设定单包价（15 元/次）

## 合规红线
- 反幻觉纪律在付费调用中**原样保留**：未闭环量标「待实测」，未收妥不输出付费内容
- 上架即对外发布：先跑 `scripts/privacy_scan.py --redact` 脱敏，再发布
- 商户私钥仅经配置中心/KMS 注入，禁止入库
