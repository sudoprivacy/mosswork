# -*- coding: utf-8 -*-
"""
capabilities.py · 九项计费能力的远程实现（真实引擎接线层）

设计原则（严守反幻觉纪律）：
1. 本技能源目录 scripts/ 已有经过核验的真实算法脚本（cadvector_takeoff.py /
   quantity_checker.py / audit_triple_source.py / claim_drafter.py / price_estimator.py
   / material_price_lookup.py / price_index_lookup.py 等）。这里通过 subprocess 把它们
   接线为各能力的真实引擎。
2. 默认路径【不执行真实引擎】：避免长耗时算量与误算，直接返回「结构化反幻觉占位
   + 引擎可用性声明 + 调用契约」。只有当 params 显式带 execute_real:true 且输入齐备时，
   才调用真实脚本，并把其 stdout 作为 raw_output 返回，confidence 标 PENDING（真实输出
   未经本技能人工复核，不得直接采信为定案值）。
3. 每条结论带 confidence（HIGH/MEDIUM/PENDING）与 citations（定额条目号 / 信息价期号 /
   图纸页·坐标），支撑审计与司法存证。
"""
import json
import os
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

from config import (BID_HIGH_THRESHOLD, BID_LOW_THRESHOLD, CN_COST_REF_PRICE_DB,
                    CN_COST_REF_SCRIPTS_DIR, CAPABILITY_TITLES)

# 置信度分级
CONF_HIGH = "HIGH"        # 已核实（如矢量实测与计书精确勾稽）
CONF_MEDIUM = "MEDIUM"    # 部分核实，需补充资料
CONF_PENDING = "PENDING"  # 待实测 / 待复核，不得直接采信


def _now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat()


# --------------------------------------------------------------------------- #
# 真实引擎调用（安全降级）
# --------------------------------------------------------------------------- #
def _run_engine(script: str, argv: List[str], timeout: int = 180) -> Dict[str, Any]:
    """调用源技能真实脚本，全程异常兜底，绝不抛到上层。"""
    path = os.path.join(CN_COST_REF_SCRIPTS_DIR, script)
    if not os.path.exists(path):
        return {"ran": False, "ok": False, "error": f"engine_script_missing:{script}",
                "stdout": "", "stderr": ""}
    try:
        r = subprocess.run([sys.executable, path, *argv], capture_output=True,
                           text=True, timeout=timeout, cwd=CN_COST_REF_SCRIPTS_DIR)
        return {"ran": True, "ok": (r.returncode == 0),
                "stdout": (r.stdout or "")[:8000],
                "stderr": (r.stderr or "")[:2000],
                "error": "" if r.returncode == 0 else f"exit={r.returncode}"}
    except subprocess.TimeoutExpired:
        return {"ran": True, "ok": False, "error": "timeout", "stdout": "", "stderr": "timeout"}
    except Exception as e:  # noqa: BLE001
        return {"ran": True, "ok": False, "error": str(e)[:300], "stdout": "", "stderr": ""}


# --------------------------------------------------------------------------- #
# 报错"人话化"映射层
# ⚠ 修复记录（v20260930-16K）：外部评测指出「大部分错误能正确报错，但提示信息比较
#   技术化，普通人看不懂」。此前引擎失败时把 argparse / traceback 级原文
#   （如 `engine_script_missing:xxx.py`、`exit=2`、`invalid choice`）直接吐给用户，
#   造价人看不出"我该干什么"。现加一层映射：**人话提示 + 下一步动作**，
#   原始技术细节保留在 `technical` 字段供排查，两者都不丢。
# --------------------------------------------------------------------------- #
HUMAN_ERRORS = {
    "engine_script_missing": ("找不到算法引擎文件，技能安装可能不完整（缺 scripts/ 目录）",
                              "请确认技能完整安装；若只拿到了付费层增量包，需先合入完整技能包"),
    "argv_incomplete": ("输入信息不全，已拒绝执行",
                        "补齐提示里点名的必填项后重试；本技能宁可不出数，也不给一个猜出来的数"),
    "timeout": ("算法执行超时已中断（默认 180 秒）",
                "请缩小输入规模（如拆分清单、减少图元）后重试"),
    "price_db_missing": ("材料价库文件不存在或不可读",
                         "先跑 scripts/material_price_update.py 生成价库，或检查价库路径配置"),
    "invalid choice": ("调用参数不完整或不被识别",
                       "多半是必填子命令/列名缺失，请对照能力的调用契约补齐入参"),
    "clue": ("（见 note 原文）", "按 note 中的指引补齐输入"),
}


def _humanize(err: Optional[str], note: str = "") -> Dict[str, str]:
    """把技术错误串翻译成「人话提示 + 下一步动作」。"""
    raw = str(err or "")
    if not raw:
        return {}
    head = raw.split(":")[0].split("=")[0].strip()
    if "invalid choice" in raw or "unrecognized arguments" in raw:
        head = "invalid choice"
    msg, todo = HUMAN_ERRORS.get(head, ("算法执行未产出可用结果", "请核对输入格式与必填项后重试"))
    return {"human_hint": msg, "next_action": todo, "technical": raw[:300],
            "note": (note or "")[:200]}


def _with_hint(d: Dict[str, Any]) -> Dict[str, Any]:
    """给 engine 返回体补人话提示（幂等：已有则不覆盖）。"""
    if "human_hint" not in d:
        d.update(_humanize(d.get("error") or d.get("engine_error"), d.get("note", "")))
    return d


def _first_item(params: Dict[str, Any], key: str, inner: str) -> Dict[str, Any]:
    lst = params.get(key) or []
    return lst[0] if lst else {}


def _temp_csv(fieldnames: List[str], rows: List[Dict[str, Any]], prefix: str) -> str:
    """把内联列表落为临时 CSV（引擎只吃文件，长表批量比逐条高效）。"""
    import csv as _csv
    fd, path = tempfile.mkstemp(suffix=".csv", prefix=prefix)
    os.close(fd)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = _csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})
    return path


def _engine_call(script: str, params: Dict[str, Any],
                 argv_builder: Callable[[Dict[str, Any]], List[str]],
                 missing_note: str = "") -> Dict[str, Any]:
    """优先真实引擎；否则返回引擎可用声明（反幻觉占位）。

    ⚠ 修复记录：源技能全部引擎都用 argparse 子命令（如 audit_triple_source 的
      audit/audit-file/explain、cadvector_takeoff 的 probe…selftest），
      而本文件早期 6 处 argv_builder **漏传子命令**，execute_real 时必然
      argparse 「invalid choice」崩溃后降级为占位——即"声明已接线、实际从未跑通"。
      现改为：拼不出完整 argv 就**明确拒绝执行**并回原因，绝不静默返回占位数值。
    """
    if params.get("execute_real") is True:
        argv = argv_builder(params)
        if not argv:
            return _with_hint({"engine": script, "engine_ran": False, "confidence": CONF_PENDING,
                               "error": "argv_incomplete",
                               "note": missing_note or
                                       "入参不足以拼出引擎必填参数（子命令/必填项缺失），已拒绝执行；"
                                       "不返回任何占位数值，请补全输入后重试"})
        res = _run_engine(script, argv)
        if res["ran"] and res["ok"] and res["stdout"].strip():
            return {"engine": script, "engine_ran": True, "engine_argv": argv_builder(params),
                    "raw_output": res["stdout"], "confidence": CONF_PENDING,
                    "note": "真实引擎已执行；其原始输出未经本技能人工复核，标『待实测』，不得直接采信为定案值"}
        return _with_hint({"engine": script, "engine_ran": res.get("ran", False),
                           "engine_error": res.get("error"), "confidence": CONF_PENDING,
                           "note": "真实引擎未产出可用结果（缺输入/参数不匹配/超时被熔断），"
                                   "已降级为占位，请补全输入后重试 execute_real"})
    return {"engine": script, "engine_ran": False, "confidence": CONF_PENDING,
            "note": "默认不执行真实引擎（避免误算与长耗时）。补全输入并显式传 execute_real:true 后调用真实算法"}


# --------------------------------------------------------------------------- #
# 本地材料价库（日更源）读取层
# 价库由 material_price_update.py 增量/联网刷新维护 → price_query 实时读、
# bid_selfcheck 取基准价。本层只读，绝不写入。
# --------------------------------------------------------------------------- #
def _load_price_db() -> Dict[str, Any]:
    path = CN_COST_REF_PRICE_DB
    if not path or not os.path.exists(path):
        return {"ok": False, "error": "price_db_missing", "path": path}
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return {"ok": True, "path": path, "data": data,
                "mtime": datetime.fromtimestamp(os.path.getmtime(path), timezone.utc).astimezone().isoformat(),
                "size_bytes": os.path.getsize(path)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)[:200], "path": path}


def _flatten_prices(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """复刻 material_price_lookup.flatten：遍历 (类别,规格,期号) → 平铺记录。"""
    out: List[Dict[str, Any]] = []
    for cat, cat_info in (data.get("materials") or {}).items():
        for spec, spec_info in ((cat_info or {}).get("specs") or {}).items():
            unit = (spec_info or {}).get("单元", "")
            for p in (spec_info or {}).get("periods") or []:
                row = dict(p)
                row.update({"cat": cat, "spec": spec, "unit": unit, "name": f"{cat}·{spec}"})
                out.append(row)
    return out


def _price_db_meta() -> Dict[str, Any]:
    """价库新鲜度 + 日更追溯（meta.changelog），供 price_query 回报数据时效。"""
    db = _load_price_db()
    if not db.get("ok"):
        return _with_hint({"ok": False, "error": db.get("error"), "path": db.get("path")})
    data = db["data"]
    meta = data.get("meta") or {}
    rows = _flatten_prices(data)
    periods = sorted({r.get("期号", "") for r in rows if r.get("期号")})
    changelog = meta.get("changelog") or []
    recent = [{"date": e.get("date"), "action": e.get("action"),
               "note": str(e.get("note", ""))[:200]}
              for e in (changelog[-5:] if isinstance(changelog, list) else [])
              if isinstance(e, dict)]
    try:
        mt = datetime.fromtimestamp(os.path.getmtime(db["path"]), timezone.utc)
        stale_days = round((datetime.now(timezone.utc) - mt).total_seconds() / 86400.0, 2)
    except Exception:  # noqa: BLE001
        stale_days = None
    return {"ok": True, "path": db["path"], "mtime": db.get("mtime"),
            "stale_days": stale_days, "size_bytes": db.get("size_bytes"),
            "schema_version": data.get("schema_version"),
            "last_publish": meta.get("last_publish"),
            "regions_covered": meta.get("regions_covered"),
            "price_basis": str(meta.get("price_basis", ""))[:200],
            "record_count": len(rows), "periods_covered": periods,
            "changelog_total": len(changelog) if isinstance(changelog, list) else 0,
            "recent_updates": recent,
            "note": "价库由 material_price_update.py 增量/联网刷新维护（日更流水线写入同一份 JSON）"}


def _price_lookup(kw: str, period: Optional[str] = None,
                  region: Optional[str] = None) -> List[Dict[str, Any]]:
    """按关键词检索价库（匹配 类别/规格/全名/来源），返回按期号倒序的记录。"""
    db = _load_price_db()
    if not db.get("ok"):
        return []
    key = (kw or "").strip().lower()
    if not key:
        return []
    out: List[Dict[str, Any]] = []
    for r in _flatten_prices(db["data"]):
        fields = [r.get("cat", ""), r.get("spec", ""), r.get("name", ""), str(r.get("来源", ""))]
        if not any(key in str(x).lower() for x in fields):
            continue
        if region and r.get("计价地区", "") != region:
            continue
        if period and r.get("期号", "") != period:
            continue
        out.append(r)
    out.sort(key=lambda x: (x.get("期号", ""), x.get("name", "")), reverse=True)
    return out


def _conf_of_price(row: Optional[Dict[str, Any]]) -> str:
    """价格记录 → 置信度分级（严守：缺『来源/期号』或经验估一律 PENDING）。"""
    if not row:
        return CONF_PENDING
    if not row.get("来源") or not row.get("期号"):
        return CONF_PENDING
    c = row.get("置信度", "")
    if c == "可核":
        return CONF_HIGH
    if c == "市场核":
        return CONF_MEDIUM
    return CONF_PENDING


# --------------------------------------------------------------------------- #
# 能力 1：综合单价重算 / 核减（模块五 §5.12、模块七）
# --------------------------------------------------------------------------- #
def reprice(params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    items = params.get("items", [])

    # price_estimator.py 必填子命令：cable / steel / cu（漏传即 invalid choice）
    def _sub(it):
        s = str(it.get("engine_sub") or it.get("sub") or "").lower()
        if s in ("cable", "steel", "cu"):
            return s
        if it.get("kind"):
            return "steel"          # --kind 是 steel 独有必填项
        if it.get("cores") is not None and it.get("section") is not None:
            return "cable"
        if it.get("cu") is not None:
            return "cu"
        return None

    def _argv(p):
        it = _first_item(p, "items", "name")
        s = _sub(it)
        if not s:
            return []               # 触发 argv_incomplete 拒绝，不静默降级
        a = [s]
        if s == "cable":
            for k in ("cores", "section", "cu"):
                if it.get(k) is not None:
                    a += [f"--{k}", str(it[k])]
            if it.get("type"):
                a += ["--type", str(it["type"])]
            if it.get("hard"):
                a += ["--hard"]
        elif s == "steel":
            a += ["--kind", str(it["kind"])]
            for k in ("h", "b", "tw", "tf", "len", "price"):
                if it.get(k) is not None:
                    a += [f"--{k}", str(it[k])]
        else:                       # cu
            a += ["--cu", str(it["cu"])]
        return a

    eng = _engine_call(
        "price_estimator.py", params, _argv,
        missing_note="price_estimator 需 cable/steel/cu 子命令："
                     "电缆给 cores+section+cu；型钢给 kind；纯铜价给 cu。"
                     "无法推断请显式传 engine_sub")
    return {
        "capability": "reprice",
        "title": CAPABILITY_TITLES["reprice"],
        "confidence": eng["confidence"],
        "citations": [],
        "engine": eng,
        "result": {
            "input_count": len(items),
            "recomputed": [
                {"item": it.get("name", "?"),
                 "audited_unit_price": None,
                 "note": "接 price_estimator 真实重算后回填；未执行前不输出确定值"}
                for it in items
            ],
        },
        "anti_hallucination": "单价未经真实算法复核前一律不输出确定值",
        "generated_at": _now(),
    }


# --------------------------------------------------------------------------- #
# 能力 2：结算争议核减分析（模块四 §4.8、§7.2）— 三源比价 + 工程量比对
# --------------------------------------------------------------------------- #
def settle_review(params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    """结算争议核减分析 —— audit_triple_source.py 三源比价（价库 + 检测库 + 政策口径）。

    契约：`audit-file <csv>` 批量入参，CSV 列名 项目名/数量/单价/单位/类别
    （亦接受 kw/qty/price/unit/cat）。早期实现把首个 claim 当位置参数直接拼，
    而该脚本的位置参数是**子命令名**，必然 invalid choice 崩溃。
    """
    claims = [c for c in (params.get("claims") or []) if isinstance(c, dict)]
    rows = [{"项目名": c.get("kw") or c.get("name") or "",
             "数量": c.get("qty", 1),
             "单价": c.get("price") if c.get("price") is not None else c.get("quote", ""),
             "单位": c.get("unit", ""),
             "类别": c.get("cat") or c.get("category") or "材料"} for c in claims]

    tmp: List[str] = []

    def _argv(p):
        if p.get("audit_file"):
            a = ["audit-file", str(p["audit_file"])]
        elif rows:
            path = _temp_csv(["项目名", "数量", "单价", "单位", "类别"], rows, "cap_claims_")
            tmp.append(path)
            a = ["audit-file", path]
        else:
            return []               # 无 claim 可审 → 明确拒绝，不返回空判定
        if p.get("region"):
            a += ["--region", str(p["region"])]
        return a

    try:
        eng = _engine_call("audit_triple_source.py", params, _argv,
                           missing_note="无可审条目：请传 claims（含 kw/price/unit）"
                                        "或直接传 audit_file 指向报价 CSV")
    finally:
        for t in tmp:
            try:
                os.unlink(t)
            except OSError:
                pass

    return {
        "capability": "settle_review",
        "title": CAPABILITY_TITLES["settle_review"],
        "confidence": eng["confidence"],
        "citations": ["audit_triple_source · 三源交叉核（价库/检测库/政策效力闸）"],
        "engine": eng,
        "result": {
            "claim_count": len(claims),
            "analysis": {
                "support_reduction": [],
                "disputed": [],
                "reduction_summary": None,
            },
        },
        "anti_hallucination": "存疑项一律标『待实测』，不直接核减",
        "generated_at": _now(),
    }


# --------------------------------------------------------------------------- #
# 能力 3：工程量图纸核对 / CAD 算量（模块六）— cadvector_takeoff 矢量实测
# --------------------------------------------------------------------------- #
def cad_takeoff(params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    """工程量图纸核对 —— cadvector_takeoff.py 纯矢量算量。

    契约：子命令必填（probe/sign/calibrate/extract/chain/symbols/areas/takeoff/selftest）。
    ⚠ 守反幻觉红线第 11 条「未标定不得输出工程量」：默认走 **extract**（图元提取，不产出量），
    只有在显式给出标定（cal_json 或 m_per_pt）**且**指定 mode 时才走 takeoff 出量，
    否则宁不出数、不给假数。
    """
    pdf = params.get("pdf_path") or params.get("pdf")
    page = params.get("page", 0)
    mode = params.get("mode")
    calibrated = bool(params.get("cal_json") or params.get("m_per_pt"))

    def _argv(p):
        pdfp = p.get("pdf_path") or p.get("pdf")
        if not pdfp:
            return []
        if p.get("mode") and (p.get("cal_json") or p.get("m_per_pt")):
            a = ["takeoff", "--pdf", str(pdfp), "--mode", str(p["mode"])]
            if p.get("page") is not None:
                a += ["--page", str(p["page"])]
            if p.get("cal_json"):
                a += ["--cal-json", str(p["cal_json"])]
            if p.get("m_per_pt"):
                a += ["--m-per-pt", str(p["m_per_pt"])]
            if p.get("pick"):
                a += ["--pick", str(p["pick"])]
            return a
        # 默认：只做图元提取，不产工程量
        a = ["extract", "--pdf", str(pdfp)]
        if p.get("page") is not None:
            a += ["--page", str(p["page"])]
        if p.get("top"):
            a += ["--top", str(p["top"])]
        return a

    eng = _engine_call(
        "cadvector_takeoff.py", params, _argv,
        missing_note="缺少 pdf/pdf_path，无法识图")
    return {
        "capability": "cad_takeoff",
        "title": CAPABILITY_TITLES["cad_takeoff"],
        "confidence": eng["confidence"],
        "citations": [f"图纸页{page}"] if pdf else [],
        "engine": eng,
        "result": {
            "source": {"pdf": pdf, "page": page, "mode": mode, "calibrated": calibrated},
            "calibration_k": None,     # 双锚点标定 m/pt，真实引擎回填
            "measured": [],            # 管线/构件实测长度
            "stage": "takeoff" if (mode and calibrated) else "extract(未标定·不出量)",
        },
        "anti_hallucination": "未闭环量标『待实测』；黑色矢量层无颜色区分时不得拓扑闭合；"
                              "未标定（缺 cal_json/m_per_pt）时只做图元提取，不输出工程量",
        "generated_at": _now(),
    }


# --------------------------------------------------------------------------- #
# 能力 4：投标报价经济性自检（模块五 §5.7）— 不平衡报价/虚高预警（引擎待接入）
# --------------------------------------------------------------------------- #
def bid_selfcheck(params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    """投标报价经济性自检 —— 接真实引擎 cost_adjuster.py（GB/T 50500-2024 公式法）。

    判定口径（反幻觉：基准价缺失即不判、不评分）：
      ① 基准价：优先取入参 benchmark；未提供则用报价名称回查『日更价库』自动匹配。
      ② 偏差率：调 cost_adjuster.py batch，取「调差幅度%」= ΔP = P₀ × (Ft/F₀ − 1) × Q。
      ③ 判定：≥ +15% 虚高预警；≤ −15% 压低预警（不平衡报价典型手法）；否则正常。
    """
    quotes = params.get("quotes") or []
    prepared: List[Dict[str, Any]] = []
    unresolved: List[Dict[str, Any]] = []

    # ① 解析报价项 + 解析基准价（价库桥接）
    for q in quotes:
        if not isinstance(q, dict):
            continue
        name = q.get("name") or q.get("kw") or q.get("item") or ""
        quoted = q.get("price") if q.get("price") is not None else q.get("quote")
        qty = q.get("qty") if q.get("qty") is not None else q.get("quantity", 1.0)
        unit = q.get("unit") or ""
        bench = q.get("benchmark") if q.get("benchmark") is not None else q.get("base")
        bench_row = None
        bench_src = "params"
        if bench is None and name:
            rows = _price_lookup(name, q.get("period"), q.get("region"))
            if rows:
                bench_row = rows[0]
                bench = bench_row.get("价格")
                bench_src = "price_db"
        if bench is None or quoted is None:
            unresolved.append({"item": name,
                               "reason": "缺报价或基准价（价库未命中且未显式传 benchmark）"})
            continue
        try:
            prepared.append({"name": name, "unit": unit, "qty": float(qty),
                             "benchmark": float(bench), "quote": float(quoted),
                             "bench_src": bench_src, "bench_row": bench_row})
        except (TypeError, ValueError):
            unresolved.append({"item": name, "reason": "报价/基准价/工程量非数值"})
            continue

    # ② 调真实引擎 cost_adjuster.py batch（一次调用算完全部条目）
    items: List[Dict[str, Any]] = []
    engine: Dict[str, Any] = {"engine": "cost_adjuster.py", "engine_ran": False, "live": False}
    if prepared:
        tmp_path = os.path.join(tempfile.gettempdir(), f"cap_bid_{uuid4().hex[:10]}.json")
        payload = [{"type": "single", "base": p["benchmark"], "current": p["quote"],
                    "qty": p["qty"], "unit": p["unit"] or "t", "title": p["name"]}
                   for p in prepared]
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False)
            res = _run_engine("cost_adjuster.py", ["batch", "--file", tmp_path, "--json"])
        finally:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        if res.get("ran") and res.get("ok") and (res.get("stdout") or "").strip():
            try:
                arr = json.loads(res["stdout"])
                if not isinstance(arr, list):
                    raise ValueError("引擎输出非数组")
                engine = {"engine": "cost_adjuster.py", "engine_ran": True, "live": True,
                          "subcommand": "batch", "item_count": len(arr),
                          "raw_output": (res["stdout"] or "")[:4000],
                          "note": "真实引擎已执行：ΔP = P₀ × (Ft/F₀ − 1) × Q；"
                                  "『调差幅度%』即报价相对基准价的偏差率"}
                for p, r in zip(prepared, arr):
                    if not isinstance(r, dict) or "error" in r:
                        unresolved.append({"item": p["name"],
                                           "reason": str(r.get("error")) if isinstance(r, dict) else "引擎返回异常"})
                        continue
                    dev = r.get("调差幅度%")
                    dev_pct = float(dev) if dev is not None else None
                    if dev_pct is None:
                        flag = "无法判定"
                    elif dev_pct / 100.0 >= BID_HIGH_THRESHOLD:
                        flag = "虚高预警"
                    elif dev_pct / 100.0 <= BID_LOW_THRESHOLD:
                        flag = "压低预警"
                    else:
                        flag = "正常"
                    items.append({
                        "item": p["name"], "unit": p["unit"], "qty": p["qty"],
                        "benchmark_price": p["benchmark"], "quoted_price": p["quote"],
                        "benchmark_source": p["bench_src"],
                        "benchmark_period": (p["bench_row"] or {}).get("期号"),
                        "benchmark_basis": (p["bench_row"] or {}).get("口径"),
                        "benchmark_ref": ((p["bench_row"] or {}).get("来源") or "")[:120],
                        "deviation_pct": dev_pct, "price_index": r.get("价格指数"),
                        "unit_delta": r.get("单价调差"), "total_delta": r.get("合计调差金额"),
                        "flag": flag,
                        "confidence": _conf_of_price(p["bench_row"]) if p["bench_row"] else CONF_MEDIUM,
                        "note": "不平衡报价嫌疑：须结合工程量趋势复核（抬高项提前收款 / 压低项后期靠变更索赔）"
                                if flag in ("虚高预警", "压低预警") else "",
                    })
            except Exception as e:  # noqa: BLE001
                engine = {"engine": "cost_adjuster.py", "engine_ran": True, "live": False,
                          "error": f"引擎输出解析失败:{str(e)[:200]}"}
        else:
            engine = {"engine": "cost_adjuster.py", "engine_ran": res.get("ran", False),
                      "live": False, "error": res.get("error"),
                      "note": "真实引擎未产出可用结果（缺输入/参数不匹配/超时），已降级为占位"}
    else:
        engine["note"] = ("无可算条目：请提供报价明细(名称/报价/工程量)；"
                          "基准价可显式传 benchmark，或由日更价库按名称自动匹配")

    # ③ 汇总评分（反幻觉：无可算条目 → 不评分）
    hi_items = [i for i in items if i["flag"] == "虚高预警"]
    lo_items = [i for i in items if i["flag"] == "压低预警"]
    flagged = [i for i in items if i["flag"] in ("虚高预警", "压低预警")]
    if items:
        avg_abs = round(sum(abs(i["deviation_pct"] or 0.0) for i in items) / len(items), 3)
        score = max(0.0, round(100.0 - avg_abs * 2.0
                               - len(hi_items) * 5.0 - len(lo_items) * 5.0, 1))
        if all(i["confidence"] == CONF_HIGH for i in items):
            overall = CONF_HIGH
        elif any(i["confidence"] == CONF_MEDIUM for i in items):
            overall = CONF_MEDIUM
        else:
            overall = CONF_PENDING
    else:
        avg_abs, score, overall = None, None, CONF_PENDING

    return {
        "capability": "bid_selfcheck",
        "title": CAPABILITY_TITLES["bid_selfcheck"],
        "confidence": overall,
        "citations": [f"cost_adjuster.py ΔP=P₀×(Ft/F₀−1)×Q；基准来源={i['benchmark_source']}"
                      + (f"·{i['benchmark_period']}" if i.get("benchmark_period") else "")
                      for i in items[:10]],
        "engine": engine,
        "thresholds": {"high_pct": round(BID_HIGH_THRESHOLD * 100, 2),
                       "low_pct": round(BID_LOW_THRESHOLD * 100, 2),
                       "basis": "偏差率(调差幅度%)，可用 CAP_BID_HIGH/LOW_THRESHOLD 覆盖"},
        "result": {"quote_count": len(quotes), "computed_count": len(items),
                   "unresolved": unresolved,
                   "selfcheck": {"unbalanced_items": flagged,
                                 "waste_items": hi_items, "score": score},
                   "avg_abs_deviation_pct": avg_abs, "items": items},
        "anti_hallucination": "基准价缺失(价库未命中且未传 benchmark)时不算偏差、不评分；"
                              "偏差判定须结合工程量趋势，不得单独作为废标/定案依据",
        "generated_at": _now(),
    }


# --------------------------------------------------------------------------- #
# 能力 5：索赔报告生成（模块四 §4.5）— claim_drafter 三报告
# --------------------------------------------------------------------------- #
def claim_report(params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    """索赔报告生成 —— claim_drafter.py（子命令 notice/time/cost/pack）。

    ⚠ 副作用修复：claim_drafter 默认把成果写进**当前工作目录**
    （`--out` 默认 claim_notice.txt），而引擎以技能 scripts/ 为 cwd，
    等于每次付费调用都往技能安装目录落盘一个 txt——上架后会污染用户环境。
    现改为：--out 指向临时文件 → 读回正文放进 raw_output → 立即删除。
    """
    event = params.get("event", "")
    out_path = os.path.join(tempfile.gettempdir(), f"cap_claim_{uuid4().hex[:10]}.txt")

    def _argv(p):
        if not (p.get("event") or p.get("project")):
            return []
        a = ["notice", "--out", out_path]
        for k in ("project", "contract", "type", "event", "contractor", "contact"):
            if p.get(k):
                a += [f"--{k}", str(p[k])]
        if p.get("file_no"):
            a += ["--file-no", str(p["file_no"])]
        return a

    if params.get("execute_real") is True and _argv(params):
        res = _run_engine("claim_drafter.py", _argv(params))
        body = ""
        try:
            with open(out_path, encoding="utf-8") as f:
                body = f.read()
        except OSError:
            pass
        finally:
            try:
                os.unlink(out_path)
            except OSError:
                pass
        if res.get("ran") and res.get("ok"):
            eng = {"engine": "claim_drafter.py", "engine_ran": True,
                   "subcommand": "notice",
                   "raw_output": body or res.get("stdout", ""),
                   "confidence": CONF_PENDING,
                   "note": "真实引擎已生成（正文已读回本响应，未落盘技能目录）；"
                           "其输出未经人工复核，标『待实测』"}
        else:
            eng = _with_hint({"engine": "claim_drafter.py", "engine_ran": res.get("ran", False),
                              "engine_error": res.get("error"), "confidence": CONF_PENDING,
                              "note": "真实引擎未产出可用结果，已降级为占位"})
    else:
        eng = _engine_call("claim_drafter.py", params, _argv,
                           missing_note="缺少 event/project，无法生成索赔意向通知")

    return {
        "capability": "claim_report",
        "title": CAPABILITY_TITLES["claim_report"],
        "confidence": eng["confidence"],
        "citations": ["claim_drafter · notice（GF-2017-0201 / FIDIC / GB/T 50500 三模板）"],
        "engine": eng,
        "result": {
            "event": event,
            "report": {"notice": eng.get("raw_output") or None,
                       "schedule_report": None, "cost_report": None},
        },
        "anti_hallucination": "报告要素(工期/费用计算)未经真实事件数据核验前不生成定稿",
        "generated_at": _now(),
    }


# --------------------------------------------------------------------------- #
# 能力 6（新增）：材料价格查询 / 市场定价（对接 material_price_lookup）
# 对应行业『数据驱动、市场定价』趋势（广联达广材网/指标网、芒旭造价数据库）
# --------------------------------------------------------------------------- #
def price_query(params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    """材料价格查询 —— 实时读取本地材料价库（日更桥接）。

    桥接链路：material_price_update.py（增量/联网刷新，日更流水线）
                → scripts/data/material_prices.json → 本能力实时读取。
    日更一写入新价本能力即刻读到，无需重启服务；并回报价库新鲜度与最近更新记录。
    """
    kw = params.get("kw") or params.get("keyword") or ""
    period = params.get("period")
    region = params.get("region")

    meta = _price_db_meta()
    rows = _price_lookup(kw, period, region)

    prices = [{
        "name": r.get("name"), "cat": r.get("cat"), "spec": r.get("spec"),
        "unit": r.get("unit"), "price": r.get("价格"),
        "period": r.get("期号"), "basis": r.get("口径"), "region": r.get("计价地区"),
        "confidence": _conf_of_price(r), "confidence_raw": r.get("置信度"),
        "source": r.get("来源"),
    } for r in rows[:20]]

    citations = [f"{r.get('name')}·{r.get('期号')}·{r.get('口径')}·{r.get('计价地区')}"
                 f"·{(r.get('来源') or '')[:60]}" for r in rows[:10]]

    # 价库不可读或未命中 → 退回真实检索器 material_price_lookup.py 兜底
    fallback = None
    if not meta.get("ok") or not rows:
        def _argv(p):
            a = ["search", str(kw)]
            if period:
                a += ["--period", str(period)]
            if region:
                a += ["--region", str(region)]
            return a
        fallback = _engine_call("material_price_lookup.py",
                                {**params, "execute_real": True}, _argv)

    return {
        "capability": "price_query",
        "title": CAPABILITY_TITLES["price_query"],
        "confidence": _conf_of_price(rows[0]) if rows else CONF_PENDING,
        "citations": citations,
        "engine": {"engine": "material_prices.json(live) + material_price_lookup.py",
                   "engine_ran": bool(rows), "live_read": bool(meta.get("ok")),
                   "source": "价库由 material_price_update.py 增量/联网刷新维护（日更桥接）",
                   "note": "实时读取本地材料价库（零耗时、零误算风险，故不走 execute_real 门控）；"
                           "价库不可读或未命中时退回 material_price_lookup.py 检索器",
                   "fallback": fallback},
        "price_db": meta,
        "result": {"keyword": kw, "period": period, "region": region,
                   "hit_count": len(rows), "prices": prices},
        "anti_hallucination": "价格必须带『期号+口径+地区+来源』四要素；缺来源或『经验估』一律标 PENDING，不得冒充权威价",
        "generated_at": _now(),
    }


# --------------------------------------------------------------------------- #
# 能力 7（新增）：造价指标 / 调差对比（对接 price_index_lookup）— 指标库·全过程闭环
# 对应陆家嘴『目标造价≥合同总价±累计变更±其他价款调整=结算总价』动态闭环
# --------------------------------------------------------------------------- #
def index_compare(params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    """造价指标 / 调差对比 —— price_index_lookup.py。

    契约：子命令 latest / get / trend / adjust。
      · get   <category> [--period]          → 取某期指数
      · adjust --category --base --to [--labor --machine --aux --main-mat] → 算调差额
    早期实现只传 category 位置参数而无子命令 → invalid choice。
    """
    def _argv(p):
        if p.get("base") and p.get("to"):        # 有基期+目标期 → 走调差
            a = ["adjust", "--category", str(p.get("category") or "房屋建筑工程"),
                 "--base", str(p["base"]), "--to", str(p["to"])]
            for k in ("labor", "machine", "aux", "main_mat"):
                if p.get(k) is not None:
                    a += [f"--{k.replace('_', '-')}", str(p[k])]
            return a
        a = ["get", str(p.get("category") or "房屋建筑工程")]
        if p.get("period"):
            a += ["--period", str(p["period"])]
        return a

    eng = _engine_call("price_index_lookup.py", params, _argv)
    return {
        "capability": "index_compare",
        "title": CAPABILITY_TITLES["index_compare"],
        "confidence": eng["confidence"],
        "citations": ["price_index_lookup · 广东省造价指数库（gd_price_index.json）"],
        "engine": eng,
        "result": {"category": params.get("category", "房屋建筑工程"),
                   "period": params.get("period"),
                   "base": params.get("base"), "to": params.get("to"),
                   "index": None, "adjustment": None},
        "anti_hallucination": "调差须基于官方发布指数，无发布期号不输出调差额；"
                              "台班指数已含机上人工与燃料不得重复调，物价调价不调管理费和利润",
        "generated_at": _now(),
    }


# --------------------------------------------------------------------------- #
# 能力 8：招投标清标 + 围串标线索扫描
# 引擎 scripts/bid_clean_check.py（v20260930-14 新建，纯标准库无第三方依赖）
# 判据来源：发改法规〔2026〕195 号 17 条（辅助性定位）；商丘市《投标文件雷同情形》
#           （报价等差/差额等差/规律性百分比）；威海审计局实践路径（固定比例、陪标特征、
#           首位数频率分布）。对应行业『智能清标 3-5 天→4 小时』。
# 输入：boq_path + bids_path（CSV 文件路径）；或内联 boq / bids 列表（自动落临时 CSV）。
# --------------------------------------------------------------------------- #
def clear_tender(params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    import csv as _csv

    tmp_files: List[str] = []

    def _resolve(p: Dict[str, Any]):
        boq_path, bids_path = p.get("boq_path"), p.get("bids_path")
        if not boq_path and p.get("boq"):
            fd, boq_path = tempfile.mkstemp(suffix=".csv", prefix="boq_")
            os.close(fd)
            with open(boq_path, "w", encoding="utf-8", newline="") as f:
                w = _csv.DictWriter(f, fieldnames=["code", "name", "unit", "qty", "control_price"])
                w.writeheader()
                for r in p["boq"]:
                    w.writerow({k: r.get(k, "") for k in
                                ["code", "name", "unit", "qty", "control_price"]})
            tmp_files.append(boq_path)
        if not bids_path and p.get("bids"):
            fd, bids_path = tempfile.mkstemp(suffix=".csv", prefix="bids_")
            os.close(fd)
            with open(bids_path, "w", encoding="utf-8", newline="") as f:
                w = _csv.DictWriter(f, fieldnames=["bidder", "code", "unit_price"])
                w.writeheader()
                for r in p["bids"]:
                    w.writerow({k: r.get(k, "") for k in ["bidder", "code", "unit_price"]})
            tmp_files.append(bids_path)
        return boq_path, bids_path

    try:
        boq_path, bids_path = _resolve(params)
    except Exception as e:  # noqa: BLE001
        return {"capability": "clear_tender", "title": CAPABILITY_TITLES["clear_tender"],
                "confidence": CONF_PENDING, "citations": [],
                "error": f"输入预处理失败: {str(e)[:200]}",
                "result": {}, "generated_at": _now()}

    if not boq_path or not bids_path:
        return {"capability": "clear_tender", "title": CAPABILITY_TITLES["clear_tender"],
                "confidence": CONF_PENDING, "citations": [],
                "error": "缺少 boq/bids（或 boq_path/bids_path），无法清标",
                "result": {}, "generated_at": _now()}

    def _argv(p):
        # 子命令必填，此前漏传导致 invalid choice 崩溃 —— 此处显式传 report
        a = ["report", "--boq", boq_path, "--bids", bids_path, "--json"]
        if p.get("base") in ("control", "mean"):
            a += ["--base", p["base"]]
        return a

    eng = _engine_call("bid_clean_check.py", params, _argv)

    # 清理临时文件（仅清理本函数创建的）
    for t in tmp_files:
        try:
            os.unlink(t)
        except Exception:  # noqa: BLE001
            pass

    # 引擎成功则解析结构化结果
    parsed: Dict[str, Any] = {}
    if eng.get("engine_ran") and eng.get("raw_output"):
        try:
            parsed = json.loads(eng["raw_output"])
        except Exception:  # noqa: BLE001
            parsed = {}

    return {
        "capability": "clear_tender",
        "title": CAPABILITY_TITLES["clear_tender"],
        "confidence": eng["confidence"],
        "citations": ["发改法规〔2026〕195 号 第 17 条",
                      "商丘市《投标文件雷同情形》(2026-07-24 起施行)",
                      "威海市审计局《人工智能技术在招投标审计中的实践路径初探》"],
        "engine": eng,
        "result": {
            "totals": parsed.get("totals", {}),
            "compliance": parsed.get("compliance", []),
            "deviation": parsed.get("deviation", []),
            "unbalance": parsed.get("unbalance", []),
            "collusion": parsed.get("collusion", []),
            "collusion_clue_count": len(parsed.get("collusion", [])),
            "deviation_clue_count": len(parsed.get("deviation", [])),
        },
        "anti_hallucination": ("围串标全部输出为『线索/疑点』，依 195 号文坚持辅助性定位，"
                               "不构成定性结论、不替代法定责任，须经评标委员会或行政监督部门复核确认；"
                               "报价策略相关性已按清单项均价归一，剔除量级伪相关"),
        "generated_at": _now(),
    }


# --------------------------------------------------------------------------- #
# 能力 9（新增）：成果质量体检（对接 audit_triple_source 三源核对 + quantity_checker）
# 对应行业『成果文件智能审核、对标百万级清单识别价格异常并溯源』
# --------------------------------------------------------------------------- #
def health_check(params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    """成果质量体检 —— 双引擎：audit_triple_source（单价三源核对）+ quantity_checker（工程量比对）。

    ⚠ 修复：docstring 一直声称已接线 quantity_checker，实际从未调用（能力名不副实）；
    且 audit_triple_source 同样漏传子命令。现两条都真正跑通。
    """
    items = [c for c in (params.get("items") or []) if isinstance(c, dict)]
    rows = [{"项目名": c.get("kw") or c.get("name") or "",
             "数量": c.get("qty", 1),
             "单价": c.get("price") if c.get("price") is not None else c.get("quote", ""),
             "单位": c.get("unit", ""),
             "类别": c.get("cat") or c.get("category") or "材料"} for c in items]
    rebar = next((c for c in items
                  if c.get("diameter") and c.get("count") and c.get("length")), None)

    tmp: List[str] = []

    def _argv(p):
        if p.get("audit_file"):
            return ["audit-file", str(p["audit_file"])]
        if not rows:
            return []
        path = _temp_csv(["项目名", "数量", "单价", "单位", "类别"], rows, "cap_health_")
        tmp.append(path)
        return ["audit-file", path]

    def _argv_rebar(p):
        if not rebar or params.get("execute_real") is not True:
            return []
        a = ["rebar", "--diameter", str(rebar["diameter"]),
             "--count", str(rebar["count"]), "--length", str(rebar["length"])]
        if rebar.get("wastage") is not None:
            a += ["--wastage", str(rebar["wastage"])]
        return a

    try:
        eng = _engine_call("audit_triple_source.py", params, _argv,
                           missing_note="无可体检条目：请传 items（含 kw/price/unit）或 audit_file")
        qty = {"engine": "quantity_checker.py", "engine_ran": False}
        if rebar:
            qty = _engine_call("quantity_checker.py", params, _argv_rebar,
                               missing_note="无钢筋条目参数（diameter/count/length），跳过工程量比对")
    finally:
        for t in tmp:
            try:
                os.unlink(t)
            except OSError:
                pass

    return {
        "capability": "health_check",
        "title": CAPABILITY_TITLES["health_check"],
        "confidence": eng["confidence"],
        "citations": ["audit_triple_source · 单价三源核对", "quantity_checker · 工程量比对"],
        "engine": eng,
        "quantity_engine": qty,
        "result": {"checked": len(items),
                   "warnings": [], "risk_level": None},
        "anti_hallucination": "体检结论须标注风险等级与溯源，无数据不评级；"
                              "无一命中即不给 risk_level",
        "generated_at": _now(),
    }


CAPABILITY_FUNCS = {
    "reprice": reprice,
    "settle_review": settle_review,
    "cad_takeoff": cad_takeoff,
    "bid_selfcheck": bid_selfcheck,
    "claim_report": claim_report,
    "price_query": price_query,
    "index_compare": index_compare,
    "clear_tender": clear_tender,
    "health_check": health_check,
}


def run_capability(capability: str, params: Dict[str, Any], user_token: str) -> Dict[str, Any]:
    fn = CAPABILITY_FUNCS.get(capability)
    if fn is None:
        raise KeyError(capability)
    return fn(params or {}, user_token)
