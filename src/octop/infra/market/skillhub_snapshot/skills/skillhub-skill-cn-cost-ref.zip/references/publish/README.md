# 发布辅助工具（SkillHub 上架流程）

本目录提供**交付包自带、零外部依赖**的两个脚本，用于在 `skillhub publish` 之前完成
脱敏与发布预检。它们不依赖源技能目录的 `privacy_terms.json`，可独立运行。

## 1. 隐私扫描 / 脱敏 · `privacy_scan.py`

扫描交付包内 `SKILL.md` + `cost_auditor_pay/` 文档，按 SKILL.md 数据隐私三级分档处置：

| 级别 | 内容 | 处理 |
|---|---|---|
| L3 | 客户原件（.dwg/.pdf/.xlsx…） | 阻断打包 |
| L2 | 可识别主体（项目名/房号/手机/身份证/邮箱/银行卡） | 阻断打包 |
| L1 | 脱敏数值（金额/单价/费率） | 放行；`--redact` 可扰动 |

```bash
python3 publish/privacy_scan.py              # 扫描，L2/L3 命中则 exit 1
python3 publish/privacy_scan.py --strict     # 同时报告 L1 数值密度
python3 publish/privacy_scan.py --json       # 机器可读输出
python3 publish/privacy_scan.py --redact out # 导出 L1 数值扰动后的对外副本
```

> `--redact` 按固定系数 `0.937` 缩放 6 位及以上金额，**不保证算术自洽**，仅供阅读方法论。

## 2. 发布预检 · `skillhub_publish_dryrun.py`

等价于 `skillhub publish --dry-run`，自检上架门槛并输出 **GO / NO-GO**：

- frontmatter 必备字段 `name/version/slug/displayName/summary`
- `pay` 块完整（`channel=skillhub-dual` / `mode=per_call` / `gateway` 非空 / `capabilities` 非空）
- `license=MIT`（上架须放开；私有用应为 `Internal-Use`）
- 无真实密钥泄漏（`.env.example` 仅占位）
- 支付端口文件齐全（`payment/a2m.py` + `payment/x402.py`）
- 隐私门禁通过（无 L2/L3）
- 内容指纹已写入

```bash
python3 publish/skillhub_publish_dryrun.py
```

通过后会打印上线步骤清单（注入真实密钥 → 接真实造价脚本 → 刷指纹 → SkillHub 实名绑商户 →
`skillhub publish` 设单价 → 可选 `--redact`）。

## 3. 标准上架序列

```bash
# ① 脱敏（如需对外分享数值扰动版）
python3 publish/privacy_scan.py --redact ../CostAuditor-public

# ② 发布预检
python3 publish/skillhub_publish_dryrun.py

# ③ 源技能目录刷指纹（若改过 SKILL.md）
cd <源技能目录> && ./release.sh 20260930-12 "Pay Skill 上架"

# ④ 真实上架（用户侧，需 SkillHub 账号 + 绑商户号）
skillhub login
skillhub publish --set-price reprice=0.50 settle_review=1.00 cad_takeoff=2.00 \
                          bid_selfcheck=0.30 claim_report=0.80
```
