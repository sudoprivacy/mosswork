#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bridge/exam_export.py — 造价稽核官 × 造价师AI学习系统 联动桥：考点→学习卡种子导出

用途：把造价稽核官技能里沉淀的考试映射(exam-mapping.md)、规范依据、可练命令，
导出为**机器可读的"学习卡"种子 JSON**，供造价师AI学习系统(SPA/PWA)的题库/刷题/
每日推送功能摄入。让"做中学"闭环从技能落地到学习端。

本桥输出一份标准结构，学习系统侧可按 id 去重、按 subject/考点 建索引、绑定刷题计划：
  learning_card = {
    "card_id":  稳定ID(如 KCZJ-001),  学习系统用它去重/建题库
    "subject":  科目(土建案例),        "module": 技能模块/库,
    "point":    考点名,                "type": 题型(计算/判断/综合…),
    "basis":    规范依据(回查现行版),  "skill_ref": 技能对应文件/脚本,
    "how":      技能可练命令/工具,     "trap": 易错点(与技能纠错呼应),
    "priority": 备考优先级(高/中/低),  "source": "造价稽核官技能 exam-mapping 派生"
  }

用法：
  python3 exam_export.py                  → 全量导出到 stdout
  python3 exam_export.py --json out.json  → 写文件
  python3 exam_export.py --csv  out.csv   → 写 csv(导入用)
  python3 exam_export.py --subject 土建案例

说明：本种子的"规范依据/题型"基于 exam-mapping.md 备考归纳,标注「备考参考」；
      正式刷题/大纲以当年官方考纲与真题为准。本桥不产出真题,只产出考点学习卡。
"""
import json, os, sys, csv, argparse

# 内置考点学习卡种子：对齐 references/exam-mapping.md 的映射表，补充"易错点+技能可练命令"
# 便于学习系统直接把"考点"变成"可刷/可练卡片"。
SEED = [
    {
        "card_id": "KCZJ-001", "subject": "土建案例", "priority": "高",
        "point": "工程量计算(钢筋/混凝土/装饰基本算量)", "type": "计算",
        "module": "模块三识图 + calibration-rules",
        "basis": "GB/T 50854-2024 计量规范; 22G101 图集(现行)",
        "skill_ref": "references/calibration-rules.md, drawing-recognition-detailed.md",
        "how": "quantity_checker.py rebar/anchorage/content; takeoff_toolkit.py",
        "trap": "漏扣/重扣、锚固长度查错、含量指标越界",
    },
    {
        "card_id": "KCZJ-002", "subject": "土建案例", "priority": "高",
        "point": "工程量清单编制与12位项目编码", "type": "记忆+操作",
        "module": "模块五 boq-standard-mode",
        "basis": "GB/T 50500-2024, GB/T 50854-2024(编码前9位按附录)",
        "skill_ref": "references/boq-standard-mode.md",
        "how": "boq_builder.py standard/decor 生成清单模式工作簿",
        "trap": "12位码前9位编错、漏五类清单、措施/其他项目处理错",
    },
    {
        "card_id": "KCZJ-003", "subject": "土建案例", "priority": "高",
        "point": "综合单价分析与取费基数(含税/不含税)", "type": "计算",
        "module": "模块一/五 repricing-audit",
        "basis": "GB/T 50500-2024; 各地费用定额(广东管理28%/利润20%示例)",
        "skill_ref": "references/repricing-audit.md, pricing-foundation.md",
        "how": "repricing 六步重组法; pdf_price_parser 钩稽校验",
        "trap": "取费基数错(人工+机具 而非含材)、管理费利润费率记混、含税不含税混用",
    },
    {
        "card_id": "KCZJ-004", "subject": "土建案例", "priority": "中",
        "point": "计价规范/增值税(一般9%简易3%)", "type": "判断",
        "module": "pricing-foundation / settlement-vat",
        "basis": "现行增值税政策(以当期政策原文为准); 建标〔2013〕44号",
        "skill_ref": "references/pricing-foundation.md, settlement-vat.md",
        "how": "价税口径总开关; 甲供税差处理(看 material-evidence 相关)",
        "trap": "简易计税条件误判、甲供材税差漏算、价税分离口径混",
    },
    {
        "card_id": "KCZJ-005", "subject": "土建案例", "priority": "中",
        "point": "材料价格调差/价差(公式法与基准当期价)", "type": "计算",
        "module": "material-price + cost_adjuster",
        "basis": "GB/T 50500-2024 调差条款; 合同约定的基准价/当期价",
        "skill_ref": "references/material-price-guide.md; scripts/",
        "how": "cost_adjuster.py index/single/contract/batch; 价库 compare/to-adjuster",
        "trap": "公式中 A 定值系数与 B 权重理解错、基准价取错期、Ft/F0 倒置",
    },
    {
        "card_id": "KCZJ-006", "subject": "土建案例", "priority": "高",
        "point": "工程变更/价款调整规则", "type": "综合",
        "module": "模块四 claim-delay-analysis",
        "basis": "合同示范文本 GF-2017 价款调整条款(现行)",
        "skill_ref": "references/claim-delay-analysis.md, contract-management.md",
        "how": "变更三审(成本+工期+合规)落地清单",
        "trap": "变更未及时书面确认、变更与索赔边界混",
    },
    {
        "card_id": "KCZJ-007", "subject": "土建案例", "priority": "高",
        "point": "索赔(工期CPM关键线路+费用索赔)", "type": "综合",
        "module": "模块四索赔全流程",
        "basis": "合同示范文本 GF-2017 索赔程序; 现行计价规范",
        "skill_ref": "references/claim-secure-template.md, claim-delay-analysis.md",
        "how": "claim_drafter.py notice/time/cost/pack 生成索赔文书",
        "trap": "关键线路法(CPM)算错、费用索赔组成漏项、索赔时效过期",
    },
    {
        "card_id": "KCZJ-008", "subject": "土建案例", "priority": "高",
        "point": "结算/进度款/偏差分析", "type": "计算+综合",
        "module": "模块七 settlement-audit",
        "basis": "GB/T 50500-2024 结算条款(现行)",
        "skill_ref": "references/settlement-audit.md, settlement-vat.md",
        "how": "结算审核 三阶/对量谈判§3A/争议决策树§3B",
        "trap": "已完产值计算口径、甩项/未计量项处理、进度款扣留比例",
    },
    {
        "card_id": "KCZJ-009", "subject": "土建案例", "priority": "中",
        "point": "招标控制价/评标办法", "type": "判断+操作",
        "module": "tender-control-evaluation + 模块五",
        "basis": "招标投标法及实施条例; GB/T 50500-2024 控制价编制",
        "skill_ref": "references/tender-control-evaluation.md",
        "how": "控制价编制口径/异议程序; 评标办法类型识别",
        "trap": "控制价编制口径与招标文件不一致、评标办法适用错、异议超期",
    },
    {
        "card_id": "KCZJ-010", "subject": "土建案例", "priority": "中",
        "point": "成本测算/报价策略(保本与不平衡报价)", "type": "综合",
        "module": "construction-cost-control + 模块五",
        "basis": "GB/T 50500-2024; 招投标法(不得低于成本)",
        "skill_ref": "references/construction-cost-control.md, unbalanced-settlement.md",
        "how": "投标成本测算表(保本线); 不平衡报价结算定位",
        "trap": "报低于成本、漏规费税金、不平衡报价结算兑现判断",
    },
]

# 供学习系统建档/索引的元信息
META = {
    "schema_version": "1.0",
    "producer": "造价稽核官CostAuditor bridge/exam_export.py",
    "version": "18984491.41",
    "generated": "动态生成",
    "purpose": "把技能沉淀的考试考点导出为学习卡种子,供造价师AI学习系统题库/刷题/每日推送摄入",
    "dedup_key": "card_id",
    "note": "考点学习卡基于 exam-mapping 备考归纳(标'备考参考'),非真题预测;正式以当年考纲为准",
    "link_back": "每张卡的 skill_ref/how 指向技能对应文件/脚本,做中学回查规范依据",
}


def build():
    return {"meta": META, "cards": SEED}


def main():
    p = argparse.ArgumentParser(description='造价稽核官→AI学习系统 考点学习卡导出')
    p.add_argument('--json', default=None, help='写 JSON 文件')
    p.add_argument('--csv', default=None, help='写 CSV 文件(学习系统批量导入)')
    p.add_argument('--subject', default='土建案例', help='科目过滤,默认土建案例')
    a = p.parse_args()
    data = build()
    if a.subject and a.subject != '*':
        data['cards'] = [c for c in data['cards'] if c.get('subject') == a.subject]
    data['meta']['card_count'] = len(data['cards'])
    if a.json:
        json.dump(data, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        print(f"→ JSON 已写: {a.json} ({len(data['cards'])} 张学习卡)")
    if a.csv:
        keys = [k for k in SEED[0].keys()]
        with open(a.csv, 'w', newline='', encoding='utf-8-sig') as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            for c in data['cards']:
                w.writerow(c)
        print(f"→ CSV 已写: {a.csv} ({len(data['cards'])} 行)")
    if not a.json and not a.csv:
        print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
