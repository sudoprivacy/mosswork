# 工具驱动精准算量流水线（quantity-takeoff-toolkit）

> 对应 SKILL.md 模块六（CAD图纸工程量提取）的**实战升级**：把"能描述三种方案"变成"能用一切可用工具真把量算出来"。
> 核心思想：**视觉识别（image）+ 程序化解析（ezdxf/pymupdf）+ 比例尺标定（PIL/numpy）+ 交叉校验（quantity_checker）** 四条线协同，输出可复核的工程量清单。

---

## 1. 可用工具矩阵

| 工具 | 角色 | 适用 | 备注 |
|:-----|:-----|:-----|:-----|
| **image（视觉工具）** | 主识别引擎 | 截图/照片/PDF渲染图/在线CAD截图 | 始终可用，无需安装；读图、读尺寸、读钢筋最快 |
| **pdf（PDF工具）** | PDF 解析 | 图纸集 PDF | 抽文本/尺寸、定位页 |
| **browser（浏览器）** | 在线 CAD 查看 | DWG（无本地CAD时） | ShareCAD / Autodesk Viewer 打开→截图→image |
| **exec + Python** | 程序化精确提取 | DXF、PDF、图像量测 | 见本技能 `scripts/takeoff_toolkit.py` |
| **quantity_checker.py** | 交叉校验 | 锚固/含量/指标 | 模块七规则库落地的脚本 |
| **cadpdf_takeoff.py** | CAD-PDF 专项算量 | CAD 导出 PDF | 图框反推标定 + 文本层取尺寸 + 总量守恒反证（见 §3.5A） |
| **cadpdf_room_decode.py** | CAD-PDF 房名解码+逐间算量 | CAD 导出 PDF（多房间立面图集） | gid 真值解码房名字母数字 + 页组按标题归组 + 逐间 A/B/C/D 立面出量（见 §3.5B） |
| **labor_settlement_audit.py** | 清工结算审核 | 包人工/劳务分包 | 八大清工核减点 + 三层级核对（见 `labor-settlement-audit.md`） |
| **handwritten_bill_parse.py** | 手写单结构化 | 手写量单/结算单 | OCR 结果→结构化表格 + 三层级钩稽 + 争议数字定位 |
| **cadvector_takeoff.py** | **纯矢量图纸识别 + 图形算量** | **无文本层 / 图层丢失** 的 CAD 导出 PDF | probe/sign/calibrate/chain/symbols/areas/takeoff/selftest；双坐标锚点标定 + 虚线跨间隙还原 + 未标定拒绝出量（见 §3.5C） |

**Python 依赖**（缺则脚本自动 pip install）：`ezdxf`（DXF几何）、`pymupdf`（PDF→图/文）、`Pillow`+`numpy`（图像标定与量测）。

---

## 2. 四步流水线

```
① 获取图纸
   ├─ PDF 图纸集        → pdf 工具 / takeoff_toolkit.py pdf（逐页渲染 PNG）
   ├─ DWG               → 优先导出 DXF（CAD另存）→ ezdxf；无CAD → browser 在线查看截图
   └─ 图片/照片/截图    → 直接 image 工具
        ↓
② 解析 / 渲染
   ├─ DXF   → takeoff_toolkit.py dxf   → 线长/面积/图块（按图层）
   ├─ PDF   → takeoff_toolkit.py pdf    → 每页高清 PNG（喂 image）
   └─ 在线   → browser 打开 → 截图       → 喂 image
        ↓
③ 识别 + 量测
   ├─ image 工具：按 drawing-recognition-detailed.md 的提问模板，结构化读图
   ├─ 比例尺标定：已知尺寸/比例尺条 → takeoff_toolkit.py scale
   └─ 量测：标定后 → takeoff_toolkit.py measure（长度/面积）
        ↓
④ 校验 + 成表
   ├─ 模块六 6.7 精度校验（置信度/尺寸合理性/规范符合/经验指标）
   ├─ 模块七 quantity_checker.py 交叉校验（锚固/含量/指标）
   └─ BOQ 汇总：takeoff_toolkit.py boq → CSV/JSON
```

---

## 3. 各工具调用范式（可直接照抄）

### 3.1 视觉识别（image 工具）
对每张图调用 image，prompt 用 `drawing-recognition-detailed.md` 末节的模板。一次一图，要求**只报图面可读数值**，模糊处标"待确认"。多专业图纸分图识别后再汇总。

### 3.2 PDF 图纸集 → 逐页高清图
```powershell
# 渲染每页为 PNG（dpi 200，供 image 工具识别）
python <skill>/scripts/takeoff_toolkit.py pdf 图纸.pdf --out pdf_pages --dpi 200
# 抽文本与疑似尺寸
python <skill>/scripts/takeoff_toolkit.py pdftext 图纸.pdf --dim
```

### 3.3 DXF 几何提取（最精确）
```powershell
python <skill>/scripts/takeoff_toolkit.py dxf 图纸.dxf --json dxf_out.json
# 输出：各图层 line_len / poly_len / area / circles / inserts
# 注意：DXF 内为图形单位，须按图框比例换算为 m；本工具只量化几何，不判清单计入
```
**图层规范（正确量化前提）**：A-WALL(墙)/A-DOOR(门)/A-COLM(柱)/A-FLOR(楼面)/M-PIPE(水)/E-LITE(电)/S-STEL(钢) 等；图块 INSERT 多为设备/标注，须展开或单独计数。

### 3.4 DWG 处理（无本地 CAD）
- 方案 A（推荐）：请用户在 CAD 中"另存为 DXF" → 走 3.3。
- 方案 B：browser 打开 ShareCAD/Autodesk Viewer → 截图 → image 工具。
- 方案 C：ODA File Converter（若已安装）DWG→DXF → 走 3.3。

### 3.5 比例尺标定 + 图像量测
```powershell
# 已知：图上 100 像素 = 实际 1 米
python <skill>/scripts/takeoff_toolkit.py scale --pixels 100 --real 1 --unit m --out scale.json
# 量长度（两点像素坐标）
python <skill>/scripts/takeoff_toolkit.py measure --scale scale.json --kind length --points "[[x1,y1],[x2,y2]]"
# 量面积（闭合多边形像素坐标）
python <skill>/scripts/takeoff_toolkit.py measure --scale scale.json --kind area --points "[[x1,y1],[x2,y2],[x3,y3],[x4,y4]]"
```
**标定来源优先级**：① 图面比例尺条 → ② 已知构件尺寸（如轴网 6000、门 1000）→ ③ **图框反推（见 §3.5A）** → ④ 向用户索取。未标定**禁止**输出工程量。

### 3.5A CAD 导出 PDF 专项：图框反推标定 + 文本层尺寸提取

> **⚠️ 先判断图纸类型，再选路径。** §3.5 的"已知像素法"只适用于**图片/扫描件**。
> 若拿到的是 **CAD 导出的 PDF**（特征：页面为精确 A0~A4 图幅、文字可选中、线条为矢量），
> 有一条**精度高得多、且不怕中文乱码**的捷径 —— 用 `cadpdf_takeoff.py`。

**路径判别（30 秒决策）：**

| 图纸特征 | 走的路径 | 原因 |
|:---------|:---------|:-----|
| DWG / DXF | `takeoff_toolkit.py dxf` | 直接读几何，最精确 |
| **CAD 导出 PDF**（矢量、可选字） | **`cadpdf_takeoff.py`（本节）** | 文本层可精确取尺寸；图框可反推比例尺 |
| 扫描件 / 照片 / 截图 | `takeoff_toolkit.py pdf` 渲染 → 视觉工具 | 无文本层，只能读图 |

**① 图框反推标定（无比例尺条时的救命招）**

原理：CAD 出图时，图框**必然**按标准图幅打印 → 「图框在图面上的长度(pt)」≡「标准图幅(mm)」。
A0~A4 的标准 mm 尺寸是国标固定的，于是比例尺直接解出：

```powershell
# 从图框反推比例尺（--ratio 填图纸比例：平面 1:50 就填 50）
python <skill>/scripts/cadpdf_takeoff.py frame --pdf 平面施工图.pdf --page 3 --ratio 50 --out scale.json
```

输出含**横纵独立标定互证**：

```
长边 0.531338.97 mm/pt ｜ 短边 0.531164.69 mm/pt ｜ 互证偏差 0.0329%
⇒ 图面 1pt = 0.5670mm ；按 1:50 → 实际 1pt = 28.35mm
```

> **判定纪律**：横纵偏差 **<0.5%** 才可信（两向独立算出同一结果，说明量的确实是标准图框）；
> 偏差 >2% 说明量的不是图框（可能是图签内框或视口边框），**结果作废**，改用尺寸链标定。
>
> **❌ 反面教材（本技能实战踩坑）**：曾用"双点标定"（取两个标注的中点间距反推）得
> **55.2 mm/pt**，导致全部房间面积错得离谱（大堂算出 129㎡）。**根因**：尺寸数字是
> **居中标注**的，相邻数字的间距 ≠ 段长。**教训：双点标定不可靠，优先图框反推。**

**② 文本层尺寸提取（优先于 OCR）**

> **★ 核心认知**：CAD 导出 PDF 里，**尺寸数字是可选中文本**！用文本层提取
> 比 OCR 读图**准得多**，而且**完全不怕中文乱码**（中文房间名因 Identity-H 编码
> 会乱码成 `\u0b50ߋࠓ`，但**纯数字不受影响**——尺寸恰恰全是数字）。

```powershell
# 提取某页全部尺寸数字（带坐标 + 排布方向）
python <skill>/scripts/cadpdf_takeoff.py dims --pdf 平面施工图.pdf --page 3 --json dims.json
# 把数字聚成尺寸链（y=横向链, x=纵向链）
python <skill>/scripts/cadpdf_takeoff.py chains --json dims.json --axis y
```

**方向判读规则（关键）**：尺寸数字的**排布方向**决定它量的是哪个方向 ——

| 数字bbox | 排布 | 量的是 | 用途 |
|:---------|:-----|:-------|:-----|
| `w > h` | 横排 | **垂直**长度 | 竖向尺寸链 → 反算进深 |
| `h > w` | 竖排 | **水平**长度 | 横向尺寸链 → 反算开间 |

**③ 总量守恒反证（把"量"变成"审"）**

这是本工具最有杀伤力的一步 —— **用图纸可容纳量反证报量虚高**：

```powershell
python <skill>/scripts/cadpdf_takeoff.py conserve `
  --report   '{"item":"墙面碳晶板","qty":850.2,"basis":"乙方手写单"}' `
  --capacity '{"item":"图纸可容纳量","qty":495.6,"basis":"图纸墙长上限177m×层高2.8m"}'
```

```
ratio: 1.715  →  verdict: 落在双面计量区间
action: ★重点：核实是否单面报双面
```

| 比值 | 判定 | 动作 |
|:-----|:-----|:-----|
| ≈1.0 (±15%) | 量级吻合 | 可采信 |
| **1.5~2.5** | **双面计量区间** | ★核实是否单面报双面 |
| **2.5~4.0** | 展开/投影或重复计量 | ★核实计量规则 |
| >4.0 | 严重超可容纳量 | ★要求举证，否则核减 |
| <0.5 | 低于图纸量 | 注意反向敞口（乙方事后补报） |

> **纪律**：比值是"是否需追问口径"的**触发器**，**不直接等于核减额**。
> 核减前必须拿到对方计量口径的**书面确认**（衔接 `labor-settlement-audit.md` 问询单）。

**④ 能力边界（如实告知，不凑数）**

- ✅ 能：图框标定比例尺、提取全部尺寸数字与尺寸链、反算总开间/进深/墙长上限、总量守恒反证。
- ❌ 不能：**全自动逐间闭合面积**。射线法逐间提取会被家具/文字线条截断，结果普遍偏小；
  近邻配对噪声大（同一批尺寸被多房间共用）。**逐间净尺寸需人工归位**——这是方法边界，
  应在计算书中明示（守反幻觉红线7：置信度低如实告知）。

### 3.5B CAD 导出 PDF 专项：房名解码 + 逐间算量（v2 · gid 真值）

§3.5A 解决"比例尺和总尺寸"，但**逐间对账**还差两步：房名认得出、页组归得对。
用 `cadpdf_room_decode.py`（详解见 `cad-pdf-room-takeoff.md`）：

```bash
python <skill>/scripts/cadpdf_room_decode.py fonts  --pdf 立面图.pdf --max-pages 20
python <skill>/scripts/cadpdf_room_decode.py rooms  --pdf 立面图.pdf --json rooms.json
python <skill>/scripts/cadpdf_room_decode.py takeoff --pdf 立面图.pdf \
    --spec "SPA间1:9,10,11,12;SPA间2:15,16,17,18" --json takeoff.json
```

**与 §3.5A 的分工**：cadpdf_takeoff 管"整体标定+总量守恒反证"（一册图一个结论）；
cadpdf_room_decode 管"逐间"(每间 A/B/C/D 四立面 → 开间=max(A,C)、进深=max(B,D))。
实战中两步都用：总量守恒证"报量虚不虚"，逐间量证"虚在哪些间"。

**五条铁律**（踩坑实录，详见参考库 §5）：
1. 房名判不出来 ≠ 图纸查无，解码失败标"待现场核实"，禁止据此核减；
2. 同文档各嵌入字体 CID 偏移可不同（实测 NSimSun=+29 / MicrosoftYaHei=+26 皆真值），按字体各自探测；
3. 干净 span（texttrace 无 U+FFFD）永不偏移——`2026.6`、尺寸 `2800` 不许被改写；
4. 页组按图纸标题归组，**禁止固定节奏推页**（空白页/大样页会致 8/20 间错位）；
5. 尺寸链二段歧义一律取和（宁大勿小）：低估图纸量会导致错误核减。

### 3.5C 纯矢量图纸专项：无文本层 CAD-PDF 的识别与图形算量（cadvector_takeoff）

**判据**：`probe` 显示 **无文本层**（`get_text()` 为空）、图元数巨大且微段占比高（实测 SW-04：26 万图元、**88.9% 长度 < 3pt**）、`extract` 显示 **layer 全为 `-`**（打印版 PDF 丢失图层名）→ 走本路径，§3.5A/§3.5B（依赖文本层）均不可用。

```bash
python3 scripts/cadvector_takeoff.py probe  --pdf "$P"                       # 体检
python3 scripts/cadvector_takeoff.py calibrate --pdf "$P" --page 1 --trace --json cal.json
python3 scripts/cadvector_takeoff.py sign    --pdf "$P" --no-ocr             # 图种（几何主判据）
python3 scripts/cadvector_takeoff.py symbols --pdf "$P" --page 1 --m-per-pt 0.11097 --excel s.xlsx
python3 scripts/cadvector_takeoff.py chain   --pdf "$P" --page 1 --auto-gap --rows --excel c.xlsx
python3 scripts/cadvector_takeoff.py takeoff --pdf "$P" --page 1 --mode dist \
        --a 1466.2,1503.8 --b 1577.2,1503.8 --m-per-pt 0.11097
python3 scripts/cadvector_takeoff.py takeoff --pdf "$P" --page 1 --mode nearest-symbol \
        --a 1444.4,1503.8 --m-per-pt 0.11097 --top 5
python3 scripts/cadvector_takeoff.py selftest --excel st.xlsx                # 13 项断言回归
```

**四条纪律**（违反即出假数，错误方向不可逆）：

| # | 纪律 | 反例 / 实测 |
|:--|:---|:---|
| 1 | **不用图签比例代替实测比例** | SW-04 图签 1:150，实测 k=**0.11097 m/pt ≈ 1:315**（CAD 导出被整体缩放） |
| 2 | **未标定不得出量** | `_k_or_die` 缺 k 直接退出；绝不输出"大致多少" |
| 3 | **不得断言"图纸查无"** | 量不出确定值时给**可能区间 [下限,上限]**；送审量落在区间内 → 无核减亦无调增依据 |
| 4 | **不断言图形语义** | 132 个等半径圆曾被疑为树图例，经人工核定井心坐标反查确认正是井类符号（**误差 0.2pt**） |

**图种判定的两个可证伪判据**（此前失效过，勿改回粗放统计）：

- **管网** = `节点-链路拓扑`：等半径圆（井）**被管线串接**（`network_nodes`），房建图无此结构；
- **房建** = `等间距轴网组`：≥4 条平行、间距 CV<0.30 的贯穿正交线。
  ⚠ **不能**用「贯穿全图的正交长线数」单独判轴网 —— 道路边线/地界线会让 `spanning_ortho` 虚高到 44~86，
  导致 pipe 与 building 打平（实测曾 0.55 vs 0.5）。修正后：**pipe 1.00 vs building 0.248**。

**三步还原**（缺一不可，顺序不可换）：
`collect_dash_runs`（虚线→**首尾跨度**直线，非墨迹总和；每条虚线用自己的节奏定间隙）
→ `build_chains`（同组共线贪心，**只接近共线**，>14° 一律不接）
→ `stitch_chains`（端点唯一配对的**渐进放宽**缝合，专治矩形拐角）。

**实测核验**（人工核定值 → 引擎实测）：井心距 12.32→**12.3177 m**｜出户段 2.42→**2.4436 m**｜
至井内壁 1.54→**1.5641 m**｜井心坐标误差 **0.2pt**｜`selftest` **13/13 PASS**。

详见 `references/cad-vector-measure.md`。

### 3.6 交叉校验
```powershell
python <skill>/scripts/quantity_checker.py check-anchorage --rebar HRB400 --conc C30 --grade 2
python <skill>/scripts/quantity_checker.py check-rebar-content --type 框剪 --area 1000
```

### 3.7 BOQ 汇总
```powershell
python <skill>/scripts/takeoff_toolkit.py boq --rows rows.json --out boq.csv
# rows: [{item,unit,qty,source,confidence}, ...]
```

---

## 4. 精度控制红线

1. **先标定后量测**：任何图像量测必须有 scale.json，否则视为无效。
2. **多源交叉**：视觉量 ≠ 程序化量。两者偏差 >5% 必须复核原图；偏差 >10% 标注"待现场实测"。
3. **单位核对**：标高 m / 尺寸 mm 是默认；给排水管径 mm；面积 m²；体积 m³；重量 t/kg。
4. **比例一致性**：同一套图不同图比例可能不同（平面 1:100、节点 1:20），逐图确认。
5. **置信度如实**：image 输出模糊/遮挡处标"待确认"，不凑数；联动模块六 6.7 报警。
6. **几何≠清单**：工具只量化几何；是否计入清单、损耗、搭接、措施，由模块四/五/七判定。

---

## 5. 输出 BOQ 模板（CSV）

| item（项目） | unit（单位） | qty（数量） | source（来源） | confidence（置信度） |
|:------------|:------------|:-----------|:--------------|:-------------------|
| 现浇混凝土矩形柱 C35 | m³ | 128.5 | DXF+视觉交叉 | 高 |
| HRB400 钢筋（框剪） | t | 56.2 | 配筋图+含量校验 | 中（部分原位标注待确认） |
| 铝合金平开窗 1500×1800 | 樘 | 36 | 门窗表 | 高 |

> 来源标注"DXF / 视觉 / PDF文本 / 用户口述"，便于追溯与复核。
