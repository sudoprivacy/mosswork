#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bridge/price_sync_export.py — 造价稽核官 × 建材价日更流水线 联动桥：价库→日更消费格式

用途：技能价库(material_prices.json, 带 source_id/source_batches 来源批次)是"审价内部库"。
当你的造价师AI学习系统/其他流水线(如 automation-6 每日 zaojia_update_daily.py)也在维护
建材价时，本桥把技能价库**导出为扁平的、按日期/材料/口径组织的标准行**，供日更流水线消费，
实现"两套价库不打架、价源能回写、口径带置信度"的双写闭环。

导出行结构(JSON 与 CSV 同构)：
  { as_of, region, material, spec, unit, caliber, price,
    confidence, source_id, source_desc, note }

用法：
  python3 price_sync_export.py --json prices_sync.json      → 全量导出(每种材料各期一条)
  python3 price_sync_export.py --csv  prices_sync.csv       → csv(含口径列,便于学习系统展示)
  python3 price_sync_export.py --period 2026-08 [--region 广州]   → 只导出某期/某地区
  python3 price_sync_export.py --json all.json --latest     → 只导每种材料最新一期(轻量日更用)

说明：导出价带 confidence(可核/市场核/经验估) 与 source_id，下游展示时务必把口径与置信度
      一并带上，避免把"市场区间代表值"当成权威信息价。本桥只导出不改写技能价库。
"""
import json, os, sys, csv, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, '..', 'scripts', 'data', 'material_prices.json')


def load_mat():
    if not os.path.exists(DATA):
        sys.exit(f'[x] 价库缺失: {DATA}')
    with open(DATA, encoding='utf-8') as f:
        return json.load(f)


def flatten_mat(d):
    out = []
    batches = d.get('meta', {}).get('source_batches', {})
    for cat, catinfo in d['materials'].items():
        for spec, sinfo in (catinfo.get('specs') or {}).items():
            unit = sinfo.get('单元', '')
            for p in sinfo.get('periods', []):
                sid = p.get('source_id')
                batch = (batches or {}).get(sid) or {}
                out.append({
                    'as_of': p.get('期号', ''),
                    'region': p.get('计价地区', ''),
                    'material': cat,
                    'spec': spec,
                    'unit': unit,
                    'caliber': p.get('口径', ''),
                    'price': p.get('价格'),
                    'confidence': p.get('置信度', ''),
                    'source_id': sid or '',
                    'source_desc': (batch.get('desc') or p.get('来源', ''))[:80],
                })
    return out


def main():
    p = argparse.ArgumentParser(description='造价稽核官→建材价日更流水线 价库导出桥')
    p.add_argument('--json', default=None, help='写 JSON 文件')
    p.add_argument('--csv', default=None, help='写 CSV 文件')
    p.add_argument('--period', default=None, help='只导出某期(如 2026-08)')
    p.add_argument('--region', default=None, help='只导出某地区(如 广州)')
    p.add_argument('--latest', action='store_true', help='只导每种材料最新一期')
    a = p.parse_args()
    if not a.json and not a.csv:
        p.print_help()
        return
    d = load_mat()
    rows = flatten_mat(d)
    if a.period:
        rows = [r for r in rows if r['as_of'] == a.period]
    if a.region:
        rows = [r for r in rows if r['region'] == a.region]
    if a.latest:
        best = {}
        for r in rows:
            k = (r['material'], r['spec'], r['region'], r['caliber'])
            if k not in best or r['as_of'] > best[k]['as_of']:
                best[k] = r
        rows = list(best.values())
    rows.sort(key=lambda x: (x['material'], x['spec'], x['as_of']))
    meta = {'exported_at': __import__('datetime').datetime.now().isoformat(),
            'count': len(rows), 'schema': 'as_of/region/material/spec/unit/caliber/price/confidence/source_id'}
    if a.json:
        json.dump({'meta': meta, 'rows': rows},
                  open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        print(f"→ JSON 已写: {a.json} ({len(rows)} 条价行)")
    if a.csv:
        keys = [k for k in rows[0].keys()] if rows else ['as_of']
        with open(a.csv, 'w', newline='', encoding='utf-8-sig') as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            for r in rows:
                w.writerow(r)
        print(f"→ CSV 已写: {a.csv} ({len(rows)} 行, utf-8-sig 便于 Excel)")


if __name__ == '__main__':
    main()
