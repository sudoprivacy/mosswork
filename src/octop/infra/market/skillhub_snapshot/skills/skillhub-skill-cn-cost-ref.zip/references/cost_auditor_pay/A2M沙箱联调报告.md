# 造价稽核官 Pay Skill 后端 · 支付宝 AI 按量付费（A2M）沙箱联调报告

> 基于已加载的 `alipay-aipay` 技能（v1.7.0）的 A2M 契约完成接入与测试。
> 项目业务 API = `cost_auditor_pay`（造价稽核官 5 项按次计费能力的远程 HTTP 服务）。
> 本轮**不发起真实付款**，未使用任何生产私钥。

---

## 一、测试结果（你要求的 5 项全验证）

本地 402 协议全链路自验 `test_a2m_local.py`（httpx 直击运行中的 dev 服务）：**25/25 通过**。

| 编号 | 验证项 | 结果 | 关键证据 |
|:---|:---|:---|:---|
| T1 | **402 账单** | ✅ | `POST /v1/capability/cad_takeoff` 无凭证 → `HTTP 402` + `Payment-Needed` 头 |
| T1.3/4 | 契约字段齐全 | ✅ | protocol 含 `out_trade_no/amount/currency/resource_id/pay_before/seller_signature/seller_sign_type/seller_unique_id`；method 含 `seller_id/seller_app_id/goods_name/seller_unique_id_key/service_id` |
| T1.7 | 沙箱 service_id | ✅ | `api_mock_service_id`（契约允许的沙箱唯一例外） |
| T1.9 | 金额一致 | ✅ | `amount=15.00`（单包价），与 `config.py` 的 `PACKAGE_PRICE` 一致 |
| T2 | **Payment-Proof 验付** | ✅ | 凭证形状对齐真实：`protocol.payment_proof` + `protocol.trade_no` + `method.client_session`；dev mock 自签名本地验签通过 |
| T3 | **资源交付** | ✅ | 带凭证重试 → `HTTP 200` + 非空 `resource_id` + 非空可归属 `content`（含 `capability=cad_takeoff`） |
| T4 | **履约回执** | ✅ | 响应头 `Payment-Validation` 可解码：`validated=true`、`resource_id` 与响应体一致；`fulfillment_confirmed=true` |
| T5 | **同一订单重试** | ✅ | 同 `out_trade_no` 重试 → `already_fulfilled=true`，`content` 与首次完全一致（资源**只生成一次**） |
| T5.4 | 反例：篡改凭证 | ✅ | 改 `trade_no` 致 HMAC 不符 → 验付失败 → 重新返回 `HTTP 402`（不交付） |

**持久化校验**：已履约订单被重试命中仍为 **1 行 `FULFILLED`**（SQLite 事务 + 唯一约束 + 原子 `prepare_fulfillment` 保证幂等），未使用内存订单兜底。

### 关于「真实沙箱联调」的说明（重要）
技能规定「仅完整 402 链路满足 flow 才可称沙箱测试通过」，其官方路径是脚本
`a2m run --auto-complete`，该脚本会请求**真实沙箱收银接口**
`aicashier.dl.alipaydev.com/openclawpay/agent/v1/pay`。该路径在本轮**无法执行**，因为需要：
1. **可联网权限**（沙箱脚本需访问支付宝沙箱收银域名）；
2. **支付宝沙箱买家 2088 账号**（真实 `userId`）；
3. 真实沙箱 `appId/应用私钥/支付宝公钥`。

你本轮明确要求**不发起真实付款**且未提供上述凭据，因此本轮完成的是**等价本地 402 全链路自验**（dev HMAC 自签名模拟支付宝返回的凭证）。真实沙箱联调留待你提供沙箱买家 2088 + 开联网后，由技能脚本执行（服务配置 `ALIPAY_SERVICE_ID=api_mock_service_id` 不变即可）。

---

## 二、代码变更

本轮在 `cost_auditor_pay/` 内严格对齐 A2M 契约（`aipay-interface-contract.md`），共改 3 文件、新增 2 测试/配置产物：

### 2.1 `payment/a2m.py`（A2M 协议层，3 处修订）
- **`payment_required()`**：修正 `Payment-Needed.protocol` 字段。
  - 契约要求 protocol 含 `seller_unique_id`（此前错用 `seller_id`）；`seller_id` 仅留在 `method` 层。
  - 商家签名严格按契约 8 字段字典序拼接：`amount/currency/goods_name/out_trade_no/pay_before/resource_id/seller_id/service_id`（此前把 `seller_unique_id` 误纳入签名域）。
- **`verify()`**：解码严格读 `protocol.payment_proof` + `protocol.trade_no`；真实凭证可不含 `out_trade_no`（改由验付响应回填），故放宽 `out_trade_no` 的强制判定（仅校验 `trade_no` 必填）。
- **`make_mock_proof()`**：形状对齐真实 Payment-Proof（`protocol.payment_proof` + `protocol.trade_no` + 可选 `out_trade_no`；`method.client_session`），与 `verify()` 走同一解码路径。

### 2.2 `main.py`（主应用，1 处新增校验）
- 验付成功后、履约前，按契约 §39 新增 **amount / resource_id 一致性校验**：与本地订单不符即重下 402 账单，不交付资源。

### 2.3 新增/补充文件
- `test_a2m_local.py`：本地 402 全链路自测（25 用例）。
- `.env.example`：环境变量模板（含全部 `ALIPAY_*` / `WEIXIN_*` / `CAP_*`）。
- `README.md`、`requirements.txt`：补充 dev 启动、本地自测、生产配置替换表。

> 原业务成功响应（200 + `content`）与 5 项能力逻辑**未改动**，仅在外层包裹 402 收单协议。

---

## 三、启动方式

```bash
cd /workspace/cost_auditor_pay
pip install -r requirements.txt          # 沙箱已预装 fastapi/uvicorn/httpx/pycryptodome

# dev 模式（无真实支付宝密钥 → HMAC mock 自签名验付，本地联调用）
rm -f cost_auditor_pay_orders.db
CAP_ENV=dev CAP_PORT=8000 CAP_ORDER_DB="sqlite:///./cost_auditor_pay_orders.db" \
  uvicorn main:app --host 127.0.0.1 --port 8000

# 另开终端跑全链路自测
python3 test_a2m_local.py               # → 25/25 通过

# prod 模式（设齐 ALIPAY_* 真实凭证后，自动切真实 RSA2 + 支付宝 SDK 验付）
CAP_ENV=prod uvicorn main:app --host 0.0.0.0 --port 8000
```

接口契约（对应你给的模板）：
- **接口用途**：调用造价稽核官按次能力（如工程量图纸核对 / 结算争议核减分析等）
- **请求方式及路径**：`POST /v1/capability/{capability}`（capability ∈ reprice/settle_review/cad_takeoff/bid_selfcheck/claim_report）
- **请求体**：`{"pdf_path": "...", "page": 0, "items": [...]}`（按能力不同）
- **必要请求头**：无凭证 → 触发 402；已支付 → `Payment-Proof: <Base64URL 凭证>`（支付宝）/ `X-PAYMENT: <...>`（微信）；可选 `X-User-Token`
- **单次价格**：**15.00 元/次（单包价，不分能力）**——5 项能力合并为计费项「造价稽核一次」，402 账单统一报 `15.00`，见 `config.py` 的 `PACKAGE_PRICE`（可由 `CAP_PACKAGE_PRICE` 覆盖），上架后以后台设定为准

---

## 四、环境变量模板

见 `.env.example`（要点）：

```dotenv
CAP_ENV=dev
ALIPAY_APP_ID=                       # 生产填真实
ALIPAY_SELLER_ID=                    # 2088 商户号
ALIPAY_APP_PRIVATE_KEY=              # PKCS#1 Base64（你本地生成）
ALIPAY_PUBLIC_KEY=
ALIPAY_MERCHANT_PRIVATE_KEY=
ALIPAY_GATEWAY=https://openapi-sandbox.dl.alipaydev.com/gateway.do
ALIPAY_SERVICE_ID=api_mock_service_id   # 沙箱唯一例外；生产换真实 serviceId
CAP_ORDER_DB=sqlite:///./cost_auditor_pay_orders.db
CAP_DEV_SECRET=dev-only-mock-secret-do-not-use-in-prod   # 仅 dev，生产删除
```

---

## 五、上线前需要替换的生产配置

| 项 | 当前（dev/sandbox） | 上线前必须替换 |
|:---|:---|:---|
| `ALIPAY_APP_ID` / `SELLER_ID` / 私钥 / 公钥 | 空 | 支付宝开放平台真实凭证 |
| `ALIPAY_GATEWAY` | `openapi-sandbox.dl.alipaydev.com` | `https://openapi.alipay.com/gateway.do` |
| `ALIPAY_SERVICE_ID` | `api_mock_service_id` | 服务市场注册/复用的真实 serviceId |
| `CAP_ORDER_DB` | SQLite 文件 | 真实 DB（MySQL/PG），事务+唯一约束 |
| dev HMAC mock 验付 | 启用 | **删除** `CAP_DEV_SECRET`，切真实 `alipay.aipay.agent.payment.verify` |
| `capabilities.py` 的 TODO | 占位 | 接入 `cn-cost-ref/scripts` 真实算法 |
| `requirements.txt` | 已含 `alipay-sdk-python` | 生产环境确认装齐 `alipay-sdk-python pycryptodome` |

**私钥红线**：应用公钥仅由你生成并提供；本骨架 dev 模式**无需任何私钥**即可联调，不向你索要/处理生产私钥、不代生成密钥对。

---

## 六、遗留待办（你本人完成）
1. 提供支付宝沙箱买家 2088 账号 + 开联网 → 跑 `a2m run --auto-complete` 做真实沙箱收银联调；
2. 注入真实 `ALIPAY_*` 凭证，切 prod 模式复测；
3. 把 `capabilities.py` 的 TODO 接入真实造价算法；
4. SkillHub 实名绑商户号 + 设单价 + 发布。
