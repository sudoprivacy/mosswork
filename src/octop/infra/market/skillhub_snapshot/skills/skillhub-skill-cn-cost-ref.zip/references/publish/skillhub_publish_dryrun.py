#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
造价稽核官 · SkillHub 发布预检（等价于 `skillhub publish --dry-run`）

**形态感知**：本技能自 v20260930-16F 起是「一套代码两种形态」：
  · free（默认）——免费技能，不收单、不需要任何支付密钥 → 预检按**免费技能门槛**判定
  · pay        ——按次付费 Pay Skill              → 预检按**付费技能门槛**判定
形态取自 SKILL.md frontmatter 的 `edition` 与 `pay:` 块是否存在（可用 CAP_EDITION 覆盖）。

通用检查（两形态都做）：
  1. SKILL.md frontmatter 必备字段（name/version/slug/displayName/summary）
  2. license 为 MIT（上架须放开）
  3. 无真实密钥泄漏（无 PEM 私钥 / sk- / app_secret 真实值 / 支付宝私钥）
  4. 隐私门禁通过（调用 privacy_scan，无 L2/L3 命中）
  5. 内容指纹已写入且**自洽**（清零后重算比对，防止副本指纹失效）
  6. 形态与声明一致（红线第 14 条）

付费形态追加：
  7. pay 块完整（channel=skillhub-dual / mode / price / gateway / capabilities）
  8. 支付端口文件齐全（payment/a2m.py + payment/x402.py）

免费形态追加：
  9. 付费代码保留但默认关闭（cost_auditor_pay/ 在、但 edition=free 且 payment=disabled）
 10. **真跑验证**：起进程内 TestClient 实调能力入口，确认不返 402
     （缺 fastapi 时如实标注"未验证"，不假装通过 —— 反幻觉红线第 15 条）

用法：python3 publish/skillhub_publish_dryrun.py [--edition free|pay]
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import privacy_scan as ps  # noqa: E402


def find_skill_md():
    for cand in (os.path.join(ROOT, "SKILL.md"),
                 os.path.join(ROOT, "..", "SKILL.md")):
        if os.path.isfile(cand):
            return os.path.abspath(cand)
    return None


def parse_frontmatter(path):
    txt = open(path, encoding="utf-8").read()
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", txt.replace("\r\n", "\n"), re.S)
    if not m:
        return None, txt
    block = m.group(1)
    fm = {}
    for line in block.split("\n"):
        if line.startswith("#"):
            continue
        mm = re.match(r"^([A-Za-z_][\w-]*):\s*(.*)$", line)
        if mm:
            fm[mm.group(1)] = mm.group(2).split("#")[0].strip().strip('"')
    # pay 子块：gateway / channel / mode / price / capabilities
    pay = {}
    pm = re.search(r"^pay:\s*\n((?:[ \t]+.*\n?)+)", block, re.M)
    if pm:
        sub = pm.group(1)
        for line in sub.split("\n"):
            sm = re.match(r"^[ \t]+([\w-]+):\s*(.*)$", line)
            if sm:
                pay[sm.group(1)] = sm.group(2).split("#")[0].strip().strip('"')
        pay["capabilities"] = re.findall(r"^[ \t]+-\s*(\w+)", sub, re.M)
    fm["_pay"] = pay
    fm["_raw"] = txt
    return fm, txt


SECRET_PATTERNS = [
    (r"-----BEGIN [A-Z ]*PRIVATE KEY-----", "PEM 私钥块"),
    (r"\bsk-[A-Za-z0-9]{20,}\b", "sk- 真实密钥"),
    (r"app_secret\s*=\s*['\"]?[A-Za-z0-9]{16,}", "app_secret 真实值"),
    (r"ALIPAY_PRIVATE_KEY\s*=\s*['\"]?MII", "支付宝私钥真实值"),
]


def scan_secrets():
    hits = []
    for p in ps.iter_files():
        if not (p.endswith(".env.example") or p.endswith(".md") or p.endswith(".py")):
            continue
        try:
            txt = open(p, encoding="utf-8").read()
        except Exception:
            continue
        for pat, desc in SECRET_PATTERNS:
            for m in re.finditer(pat, txt):
                if "${" in m.group(0):      # .env.example 的 ${VAR} 占位不算泄漏
                    continue
                hits.append((ps.relpath(p), desc, m.group(0)[:24]))
    return hits


def fingerprint_selfcheck(txt, stored):
    """清零 fingerprint 行后重算，与已写入值比对（副本扰动后必须重算，否则失效）。"""
    import hashlib
    cleared = re.sub(r"^fingerprint_sha256:\s*\S+", "fingerprint_sha256:",
                     txt, count=1, flags=re.M)
    return hashlib.sha256(cleared.encode("utf-8")).hexdigest() == stored


def live_free_probe():
    """真跑验证：起进程内 TestClient 实调能力入口，确认免费形态不返 402。

    返回 (ok: bool, detail: str)。缺依赖或异常时返回「未验证」而不是假通过。
    """
    try:
        import importlib
        import tempfile
        db = os.path.join(tempfile.gettempdir(), "cap_dryrun_probe.db")
        if os.path.exists(db):
            os.remove(db)
        os.environ["CAP_ORDER_DB"] = f"sqlite:///{db}"
        os.environ.setdefault("CAP_EDITION", "free")
        cap_dir = os.path.join(ROOT, "cost_auditor_pay")
        if cap_dir not in sys.path:
            sys.path.insert(0, cap_dir)
        for m in ("config", "main"):
            if m in sys.modules:
                importlib.reload(sys.modules[m])
        from fastapi.testclient import TestClient  # noqa
        from config import FREE_MODE  # noqa
        from main import app  # noqa
        c = TestClient(app)
        r = c.post("/v1/capability/price_query", json={"kw": "钢筋"})
        got402 = (r.status_code == 402) or ("Payment-Needed" in r.headers)
        if not FREE_MODE:
            return False, f"CAP_EDITION 未生效，仍为付费形态（status={r.status_code}）"
        if got402:
            return False, f"免费形态却返回了 402/Payment-Needed（status={r.status_code}）"
        if r.status_code != 200:
            return False, f"免费形态调用失败 status={r.status_code}"
        return True, (f"实调 price_query → HTTP {r.status_code}、无 402、"
                      f"free_mode={r.json().get('free_mode')}")
    except ImportError as e:
        return None, f"未验证：缺依赖 {e}（pip install -r cost_auditor_pay/requirements.txt）"
    except Exception as e:  # noqa: BLE001
        return None, f"未验证：{type(e).__name__} {str(e)[:120]}"


def main():
    forced = None
    if "--edition" in sys.argv:
        forced = sys.argv[sys.argv.index("--edition") + 1].strip().lower()

    checks = []
    skill = find_skill_md()
    if not skill:
        print("❌ 未找到 SKILL.md（应在交付根目录）")
        sys.exit(1)
    fm, txt = parse_frontmatter(skill)

    def add(name, ok, detail="", soft=False):
        checks.append((name, ok, detail, soft))

    # ---- 形态判定 ----
    pay_block = fm.get("_pay", {})
    declared = (fm.get("edition") or "").strip().lower()
    has_pay = bool(pay_block.get("channel"))
    edition = forced or declared or ("pay" if has_pay else "free")
    is_pay = edition == "pay"

    # ---- 1. frontmatter 必备字段（两形态通用）----
    req = ["name", "version", "slug", "displayName", "summary"]
    missing = [k for k in req if not fm.get(k)]
    add("frontmatter 必备字段", not missing, f"缺失: {missing}" if missing else "齐全")

    # ---- 2. license ----
    lic = fm.get("license", "")
    add("license=MIT（上架放开）", lic == "MIT", lic or "（空）")

    # ---- 3. 密钥泄漏 ----
    sec = scan_secrets()
    add("无真实密钥泄漏", not sec, "命中: " + str(sec[:3]) if sec else "clean")

    # ---- 4. 隐私门禁 ----
    ok_priv, _ = ps.run_check()
    add("隐私门禁（无 L2/L3）", ok_priv)

    # ---- 5. 指纹已写入且自洽 ----
    fp = fm.get("fingerprint_sha256", "")
    if not fp:
        add("内容指纹已写入", False, "缺失")
    else:
        self_ok = fingerprint_selfcheck(txt, fp)
        add("内容指纹已写入", True, f"{fp[:16]}…")
        add("内容指纹自洽（清零重算比对）", self_ok,
            "自洽" if self_ok else "不自洽 —— 内容改动后未重跑 release.sh / --redact 未重算")

    # ---- 6. 形态与声明一致（红线第 14 条）----
    if declared:
        add("形态声明与实际一致", declared == edition or forced is not None,
            f"frontmatter edition={declared}，本次按 {edition} 判定")
    if is_pay:
        add("付费形态：pay 块存在", has_pay, "缺失" if not has_pay else pay_block.get("channel"))
    else:
        add("免费形态：pay 块未启用", not has_pay,
            "frontmatter 仍存在生效的 pay 块，免费形态下会被平台判为付费技能" if has_pay
            else "已注释/未启用 ✅")
        add("免费形态：payment=disabled", fm.get("payment") == "disabled",
            fm.get("payment") or "（未声明）")

    # ---- 7/8. 形态专属 ----
    if is_pay:
        p_ok = bool(pay_block.get("channel") and pay_block.get("mode")
                    and pay_block.get("gateway") and pay_block.get("capabilities"))
        add("pay 块完整(channel/mode/gateway/capabilities)", p_ok,
            f"channel={pay_block.get('channel')} mode={pay_block.get('mode')} "
            f"price={pay_block.get('price')} gateway={pay_block.get('gateway')} "
            f"caps={pay_block.get('capabilities')}")
        add("pay.channel=skillhub-dual", pay_block.get("channel") == "skillhub-dual",
            pay_block.get("channel") or "（空）")
        a2m = os.path.join(ROOT, "cost_auditor_pay", "payment", "a2m.py")
        x402 = os.path.join(ROOT, "cost_auditor_pay", "payment", "x402.py")
        add("支付端口文件(a2m.py + x402.py)",
            os.path.isfile(a2m) and os.path.isfile(x402),
            f"a2m={'Y' if os.path.isfile(a2m) else 'N'} "
            f"x402={'Y' if os.path.isfile(x402) else 'N'}")
    else:
        cap_dir = os.path.join(ROOT, "cost_auditor_pay")
        add("付费源码保留（可随时切回）", os.path.isdir(cap_dir),
            "cost_auditor_pay/ 在，默认关闭" if os.path.isdir(cap_dir) else "缺失")
        gate = os.path.join(ROOT, "scripts", "payment_gate.py")
        add("本地付费闸口保留（CAP_EDITION 切换）", os.path.isfile(gate),
            "scripts/payment_gate.py 在，默认免费" if os.path.isfile(gate) else "缺失")
        live_ok, live_detail = live_free_probe()
        if live_ok is None:
            add("真跑验证：免费形态不返 402", False, live_detail, soft=True)
        else:
            add("真跑验证：免费形态不返 402", live_ok, live_detail)

    # ---- 汇总 ----
    print("\n════════════════════════════════════════════")
    print(f"   SkillHub 发布预检（dry-run）· 形态 = {edition}"
          f"（{'按次付费 Pay Skill' if is_pay else '免费技能，不收单'}）")
    print("════════════════════════════════════════════")
    blocked = False
    for name, ok, detail, soft in checks:
        flag = "✅" if ok else ("⚠️" if soft else "❌")
        print(f"  {flag} {name}")
        if detail:
            print(f"        ↳ {detail}")
        if not ok and not soft:
            blocked = True
    if any((not ok) and soft for _, ok, _, soft in checks):
        print("  ⚠️ 存在「未验证」项：本预检未覆盖该风险点，上架前请自行补验。")
    print("════════════════════════════════════════════")

    if blocked:
        print("❌ NO-GO：存在阻断项，修复后再跑本预检。")
        sys.exit(1)

    print(f"✅ GO：交付包满足 SkillHub {'付费技能' if is_pay else '免费技能'}上架门槛。")
    print("\n── 上线步骤（用户侧执行）──")
    if is_pay:
        print("  1) 注入真实密钥：.env 填 ALIPAY_*（A2M 沙箱/生产）、WEIXIN_*。")
        print("  2) 切真实验签：unset CAP_EDITION 或 CAP_EDITION=pay 后端启动。")
        print("  3) 刷新指纹：如做过脱敏，跑 ./release.sh <版本> \"<说明>\"。")
        print("  4) SkillHub 后台：实名 + 绑商户号。")
        print("  5) skillhub publish → 设各 capability 单价（0.01～50 元，最多两位小数）。")
    else:
        print("  1) 无需任何支付密钥、无需商户号 —— 免费技能不走收单。")
        print("  2) 确认为对外分享副本时，跑 publish/privacy_scan.py --redact 生成脱敏版。")
        print("  3) 刷新指纹：脱敏后由脚本自动重算；如手工改过内容跑 ./release.sh。")
        print("  4) skillhub publish（普通技能发布，不带 pay 块）。")
    print("  5) 发布后自检：安装一次，跑 python3 scripts/payment_gate.py mode 确认 edition=free。")
    sys.exit(0)


if __name__ == "__main__":
    main()
