# CAD 程序化工程量提取（方案 D：DWG→DXF→Python）

本文件是模块六的第四种方案（补充 6.1~6.3 的截图法/PDF法/在线查看器法），适用于**规则图形、批量、可量化**的工程量提取，与 AI 视觉识别形成互补。

---

## 一、适用场景 vs 视觉识别

| 维度 | AI 视觉识别（方案 A/B/C） | 程序化提取（方案 D） |
|:-----|:--------------------------|:---------------------|
| 适合 | 复杂图纸语义理解、缺文本层、标注解读 | 规则图形、批量统计、坐标量化 |
| 精度 | 依赖模型，需 6.7 校验 | 几何精确（取决于 DWG 本身精度） |
| 局限 | 视觉误差、无文本层时失真 | 无法理解"语义"，依赖图层/图块命名规范 |
| 输出 | 工程量估算 + 风险点 | 精确长度/面积/数量/坐标 |

> **最佳实践：** 关键/争议工程量用方案 D 复核方案 A/B 的视觉结果（见 6.7 精度校验）。

---

## 二、操作流程

```
① DWG → DXF 转换
   工具：ODA File Converter（免费）/ Teigha / AutoCAD 另存为
   注意：DWG 是专有二进制格式，Python 无法直接读取，须先转 DXF
        ↓
② DXF 解析（Python + ezdxf）
   读取实体：LINE / LWPOLYLINE / CIRCLE / ARC / TEXT / MTEXT / INSERT(图块) / DIMENSION
        ↓
③ 几何计算
   长度 = 多段线总长；面积 = 闭合多段线；数量 = 图块 INSERT 计数；坐标 = 提取标注/属性
        ↓
④ 比例换算
   按图纸比例（1:100 等）或 DIMENSION 实测值换算为实际工程量
        ↓
⑤ 与视觉结果交叉校验（回到 6.7）
```

---

## 三、关键代码骨架（ezdxf 读取示例）

```python
import ezdxf

doc = ezdxf.readfile("plan.dxf")
msp = doc.modelspace()

total_len = 0.0
for e in msp.query("LINE"):           # 统计所有直线长度
    p1, p2 = e.dxf.start, e.dxf.end
    total_len += (p2 - p1).magnitude

polygons = msp.query("LWPOLYLINE")     # 闭合多段线面积
for pl in polygons:
    if pl.closed:
        area = abs(pl.virtual_area)    # ezdxf 提供 virtual_area

blocks = msp.query("INSERT")           # 图块（如灯具/设备）计数
block_count = {}
for b in blocks:
    block_count[b.dxf.name] = block_count.get(b.dxf.name, 0) + 1
```

> **注意：** `virtual_area` 返回的是图纸坐标面积，须乘以"比例²"换算实际面积（1:100 → ×100²）。图块命名须与图例表对应才能正确计数。

---

## 四、图层规范约定（决定成败）

| 图层名（建议） | 含义 | 提取用途 |
|:---------------|:-----|:---------|
| A-WALL | 墙体 | 墙体长度/面积 |
| A-DOOR / A-WIN | 门窗 | 门窗数量 |
| M-PIPE | 机电管线 | 管线长度 |
| E-LITE | 电气点位 | 灯具/插座数量 |
| A-ANNO-DIM | 标注 | 尺寸实测 |

> 若图纸图层混乱（无规范命名），程序化提取价值大降，此时应退回方案 A/B 视觉识别或要求提供规范图纸。

---

## 五、局限与反幻觉要求

- 程序化提取**只能量化几何**，不能判断"这是不是工程量"——需人工确认实体是否计入清单。
- 图纸比例错误、块参照炸开、标注与图形不符时，结果失真，须 6.7 校验。
- 提取结果须标注"图纸比例/来源图层/提取方法"，缺失即不完整。

---

*更新日期：2026-08-21 ｜ 数据来源：ezdxf 官方文档、ODA File Converter、AutoCAD DXF 参考*
