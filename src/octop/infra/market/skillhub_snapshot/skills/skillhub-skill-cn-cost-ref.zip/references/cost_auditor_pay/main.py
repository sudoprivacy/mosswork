# -*- coding: utf-8 -*-
"""
cost_auditor_pay · 主应用（FastAPI）

承载造价稽核官 9 项能力。**一套代码两种形态**，由 CAP_EDITION 切换（默认 free）：

  · 免费形态（CAP_EDITION=free）—— 完全不需要支付
      不收单、不建单、不返 402、**不需要任何支付密钥**，9 项能力直接本地执行。
      用于自用 / 内部分享 / 不想接支付的上架形态。

  · 付费形态（CAP_EDITION=pay）—— 原 A2M + x402 双通道按次计费
      无支付凭证 → HTTP 402 + 双通道支付意图（Payment-Needed / WeixinPay-Required）
      有支付凭证 → 验付 → 幂等履约（同 out_trade_no 只生成一次资源）
      并启用企业级付费治理：免费试用额度 / 单笔金额上限 / **单日累计熔断** / 退款标记 / 用量对账。

形态自述端点：GET /v1/mode
启动：uvicorn main:app --host 0.0.0.0 --port 8000  （在 cost_auditor_pay/ 目录内执行）
"""
import json
import os
import sys
from decimal import Decimal

from fastapi import FastAPI, Header, Request
from fastapi.responses import JSONResponse

# 保证从包根目录导入（scripts 同级的 config / payment / capabilities）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (  # noqa: E402
    PACKAGE_PRICE,
    PACKAGE_GOODS_NAME,
    CAP_FREE_QUOTA_PER_DAY,
    CAP_MAX_AMOUNT_PER_REQUEST,
    CAP_DAILY_SPEND_CEIL,
    CAP_REFUND_ENABLED,
    EDITION,
    FREE_MODE,
    PAY_REQUIRED,
    CAPABILITY_TITLES,
)
from payment.a2m import (  # noqa: E402
    AlipayA2MProvider,
    new_out_trade_no,
    pay_before_iso,
)
from payment.repository import SqliteOrderRepository  # noqa: E402
from payment.x402 import WeixinX402Provider  # noqa: E402
from capabilities import CAPABILITY_FUNCS, run_capability  # noqa: E402

app = FastAPI(title="造价稽核官 CostAuditor", version="20260930-15")

REPO = SqliteOrderRepository()
ALIPAY = AlipayA2MProvider()
WEIXIN = WeixinX402Provider()


@app.get("/health")
def health():
    return {"status": "ok", "edition": EDITION, "payment_required": PAY_REQUIRED,
            "capabilities": list(CAPABILITY_FUNCS.keys())}


@app.get("/v1/mode")
def mode():
    """形态自述：让调用方一眼看清当前是否需要支付，避免误判 402 为故障。"""
    return {
        "edition": EDITION,
        "payment_required": PAY_REQUIRED,
        "free_mode": FREE_MODE,
        "package_price": None if FREE_MODE else PACKAGE_PRICE,
        "note": ("免费形态：不收单、不返 402，直接返回能力结果，无需任何密钥。"
                 if FREE_MODE else
                 "付费形态：按次计费，未付返 402 + 双通道支付意图。"),
        "switch_back": "export CAP_EDITION=pay（并恢复 SKILL.md frontmatter 的 pay: 块）",
    }


@app.get("/v1/capability/{capability}/quote")
def quote(capability: str):
    """报价查询（不收单）：单包价，不分能力，统一 PACKAGE_PRICE。"""
    if capability not in CAPABILITY_FUNCS:
        return JSONResponse(status_code=404, content={"error": "unknown_capability"})
    if FREE_MODE:
        return {"capability": capability,
                "title": CAPABILITY_TITLES.get(capability, PACKAGE_GOODS_NAME),
                "amount": "0.00", "currency": "CNY", "free_mode": True}
    return {
        "capability": capability,
        "title": PACKAGE_GOODS_NAME,
        "amount": PACKAGE_PRICE,
        "currency": "CNY",
    }


@app.get("/v1/usage")
def usage(x_user_token: str = Header(default="")):
    """用量对账查询（企业级治理）：返回该用户按能力的调用/支付统计。"""
    if not x_user_token:
        return JSONResponse(status_code=401, content={"error": "missing_x_user_token"})
    return REPO.usage_stats(x_user_token)


def _safe_run(capability: str, params: dict, token: str) -> dict:
    """包装能力执行：捕获异常并返回退款待办标记，避免履约链路崩溃。"""
    try:
        return run_capability(capability, params, token)
    except Exception as e:  # noqa: BLE001
        return {"delivery_error": str(e)[:200], "refund_pending": True,
                "confidence": "PENDING",
                "note": "交付执行异常，已触发退款流程（dev 占位；prod 接真实退款 API）"}


@app.post("/v1/capability/{capability}")
async def invoke(
    capability: str,
    request: Request,
    x_user_token: str = Header(default=""),
    payment_proof: str = Header(default="", alias="Payment-Proof"),
    x_payment: str = Header(default="", alias="X-PAYMENT"),
):
    """
    能力统一入口。形态由 CAP_EDITION 决定（默认 free 免费）：

    - 免费形态（CAP_EDITION=free）：**不收单、不建单、不返 402、不需要任何密钥**，
      9 项能力直接本地执行。仍写 usage 计量用于本地对账，但不收钱、不熔断。
    - 付费形态（CAP_EDITION=pay）  ：无凭证 → 402 双通道支付意图；
      有凭证 → 验付 + 幂等履约；并启用免费额度、单笔上限、**单日累计熔断**。
    """
    if capability not in CAPABILITY_FUNCS:
        return JSONResponse(status_code=404, content={"error": "unknown_capability"})

    params = await _safe_json(request)  # 仅解析一次，闭包内复用

    resource_id = f"/v1/capability/{capability}"

    # ---------- 免费形态：直接执行，全程零支付 ----------
    if FREE_MODE:
        result = _safe_run(capability, params, x_user_token or "local")
        if isinstance(result, dict) and result.get("delivery_error"):
            return JSONResponse(status_code=500, content={
                "code": "DELIVERY_FAILED", "message": "能力执行异常", "content": result})
        try:
            REPO.record_event(x_user_token or "local", capability, "0.00", None, free=1)
        except Exception:  # noqa: BLE001  计量失败不得影响交付
            pass
        return JSONResponse(status_code=200, content={
            "resource_id": resource_id,
            "content": result,
            "edition": EDITION,
            "free_mode": True,
            "message": "免费形态：未收取任何费用，无需支付凭证",
        })

    # ================= 以下为付费形态 =================
    amount = PACKAGE_PRICE
    goods_name = PACKAGE_GOODS_NAME
    currency = "CNY"
    provided_proof = payment_proof or x_payment
    channel = "alipay" if payment_proof else ("weixin" if x_payment else None)

    # 金额风控护栏（本技能单价远低于上限，作为治理保留）
    if Decimal(amount) > Decimal(CAP_MAX_AMOUNT_PER_REQUEST):
        return JSONResponse(status_code=403, content={
            "code": "AMOUNT_OVER_CEIL", "message": "单笔金额超出风控上限"})

    # 单日累计消费熔断（防递归/失控扣费）
    # ⚠ 修复记录：CAP_DAILY_SPEND_CEIL 与 REPO.daily_spend() 早已存在并被 import，
    #   但本函数从未调用 → 「企业级付费治理」第 3 条是声明而非实现。此处补真正生效。
    if x_user_token and Decimal(CAP_DAILY_SPEND_CEIL) > 0:
        spent_today = Decimal(REPO.daily_spend(x_user_token))
        if spent_today >= Decimal(CAP_DAILY_SPEND_CEIL):
            return JSONResponse(status_code=429, content={
                "code": "DAILY_SPEND_CEILING",
                "message": f"当日累计消费已达上限 {CAP_DAILY_SPEND_CEIL} 元，已熔断，明日重置",
                "spent_today": str(spent_today),
                "ceiling": str(CAP_DAILY_SPEND_CEIL),
            })

    # ---------- 场景：已带支付凭证 → 验付 + 履约 ----------
    if provided_proof and channel:
        provider = ALIPAY if channel == "alipay" else WEIXIN
        verified = provider.verify(provided_proof, REPO)
        if not verified or verified.get("active") is not True:
            # 凭证无效/过期 → 重新下支付要求
            return _require_payment(capability, amount, currency, resource_id, goods_name)

        order = REPO.find_by_out_trade_no(verified["out_trade_no"])
        if not order:
            return _require_payment(capability, amount, currency, resource_id, goods_name)

        # 契约 §39 强制校验：amount / resource_id 必须与本地订单一致，否则重下账单
        if verified.get("amount") and order.get("amount") and verified["amount"] != order["amount"]:
            return _require_payment(capability, amount, currency, resource_id, goods_name)
        if verified.get("resource_id") and order.get("resource_id") and verified["resource_id"] != resource_id:
            return _require_payment(capability, amount, currency, resource_id, goods_name)

        fulfillment = REPO.prepare_fulfillment({
            "out_trade_no": verified["out_trade_no"],
            "trade_no": verified["trade_no"],
            "expected_amount": amount,
            "expected_resource_id": resource_id,
            "create_resource": lambda: _safe_run(capability, params, x_user_token),
        })
        if not fulfillment or not fulfillment.get("service_result"):
            return JSONResponse(
                status_code=502,
                content={"code": "FULFILLMENT_FAILED",
                         "message": "资源生成失败，请用同一支付凭证重试"},
            )
        result = fulfillment["service_result"]
        # 交付异常 → 标记退款（prod 接真实支付宝退款 API；dev 仅占位）
        if isinstance(result, dict) and result.get("refund_pending"):
            REPO.mark_refund(verified["out_trade_no"])
            return JSONResponse(status_code=200, content={
                "code": "DELIVERY_FAILED_REFUND_PENDING",
                "out_trade_no": verified["out_trade_no"],
                "refund": CAP_REFUND_ENABLED,
                "message": "交付执行异常，已自动标记退款，请稍后重试",
            })
        if fulfillment["state"] != "FULFILLED":
            if not provider.confirm(verified["trade_no"]):
                return JSONResponse(
                    status_code=502,
                    content={"code": "FULFILLMENT_CONFIRM_FAILED",
                             "message": "履约确认失败，请稍后重试"},
                )
            REPO.mark_fulfilled(verified["out_trade_no"], verified["trade_no"])
            REPO.record_event(x_user_token or "anonymous", capability, amount,
                              verified["out_trade_no"], free=0)

        headers = {}
        if channel == "alipay":
            headers["Payment-Validation"] = _validation_header(
                verified["trade_no"], verified["out_trade_no"], resource_id
            )
        else:
            headers["X-Payment-Response"] = _validation_header(
                verified["trade_no"], verified["out_trade_no"], resource_id
            )
        return JSONResponse(
            status_code=200,
            content={
                "resource_id": resource_id,
                "content": result,
                "trade_no": verified["trade_no"],
                "out_trade_no": verified["out_trade_no"],
                "already_fulfilled": fulfillment["state"] == "FULFILLED",
                "fulfillment_confirmed": True,
            },
            headers=headers,
        )

    # ---------- 场景：未支付 ----------
    # 免费试用额度：已登录用户当日前 N 次免单，直接交付不触发 402（降低首用门槛）
    if x_user_token and CAP_FREE_QUOTA_PER_DAY > 0:
        used = REPO.count_fulfilled_today(x_user_token)
        if used < CAP_FREE_QUOTA_PER_DAY:
            result = _safe_run(capability, params, x_user_token)
            if isinstance(result, dict) and result.get("refund_pending"):
                return JSONResponse(status_code=200, content={
                    "code": "DELIVERY_FAILED", "message": "交付执行异常", "content": result})
            REPO.record_event(x_user_token, capability, "0.00", None, free=1)
            return JSONResponse(status_code=200, content={
                "resource_id": resource_id,
                "content": result,
                "free_quota": True,
                "free_used_today": used + 1,
                "free_quota_total": CAP_FREE_QUOTA_PER_DAY,
                "message": "命中免费试用额度，本次免单",
            })

    # 超过免费额度或未登录 → 返回 402 双通道支付意图
    return _require_payment(capability, amount, currency, resource_id, goods_name)


async def _safe_json(request: Request):
    try:
        data = await request.json()
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _require_payment(capability, amount, currency, resource_id, goods_name):
    out_trade_no = new_out_trade_no()
    pay_before = pay_before_iso(30)
    REPO.create_pending({
        "out_trade_no": out_trade_no,
        "amount": amount,
        "currency": currency,
        "resource_id": resource_id,
        "goods_name": goods_name,
        "pay_before": pay_before,
    })
    ali = ALIPAY.payment_required(
        out_trade_no=out_trade_no, amount=amount, currency=currency,
        resource_id=resource_id, goods_name=goods_name, pay_before=pay_before, repository=REPO,
    )
    wxn = WEIXIN.payment_required(
        out_trade_no=out_trade_no, amount=amount, currency=currency,
        resource_id=resource_id, goods_name=goods_name, pay_before=pay_before, repository=REPO,
    )
    # 合并双通道意图：Agent 按自身插件能力择一支付
    headers = {
        "Payment-Needed": ali["headers"]["Payment-Needed"],
        "WeixinPay-Required": wxn["headers"]["WeixinPay-Required"],
        "X-Out-Trade-No": out_trade_no,
    }
    body = {
        "code": "Payment-Needed",
        "message": "需要支付（微信/支付宝双渠道）",
        "out_trade_no": out_trade_no,
        "amount": amount,
        "currency": currency,
        "goods_name": goods_name,
        "code_url": wxn["body"].get("code_url"),  # 二维码兜底
    }
    return JSONResponse(status_code=402, content=body, headers=headers)


def _validation_header(trade_no, out_trade_no, resource_id):
    from payment.crypto import b64url_encode
    return b64url_encode(json.dumps({
        "trade_no": trade_no,
        "out_trade_no": out_trade_no,
        "validated": True,
        "resource_id": resource_id,
    }, ensure_ascii=False))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
