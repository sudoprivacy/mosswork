# -*- coding: utf-8 -*-
"""
cost_auditor_pay · 配置中心
所有敏感字段从环境变量读取，禁止硬编码进仓库。
"""
import os
from decimal import Decimal


def _resolve_scripts_dir() -> str:
    """按优先级解析源技能真实算法脚本目录。

    优先级：① 环境变量 → ② 本包同级 ../scripts（技能包内相对路径，最稳）
            → ③ 常见安装位（~/.workbuddy / ~/.codebuddy / /root/.codebuddy）
            → ④ 兜底默认值（保持向后兼容）。

    说明：早期版本直接把默认值写死为 /root/.codebuddy/...，在非容器环境必然落空，
    导致 capabilities 传 execute_real:true 也只回 engine_script_missing。此处改为
    多级候选，任一命中即止；全部未命中才退回默认，且调用方可据此报清晰错误。
    """
    env_dir = os.environ.get("CN_COST_REF_SCRIPTS_DIR", "").strip()
    if env_dir:
        return env_dir

    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(os.path.dirname(here), "scripts"),          # 技能包内 ../scripts
        os.path.expanduser("~/.workbuddy/skills/cn-cost-ref/scripts"),
        os.path.expanduser("~/.codebuddy/skills/cn-cost-ref/scripts"),
        os.path.expanduser("~/.claude/skills/cn-cost-ref/scripts"),
        "/root/.codebuddy/skills/cn-cost-ref/scripts",
    ]
    for c in candidates:
        if os.path.isdir(c):
            return c
    return "/root/.codebuddy/skills/cn-cost-ref/scripts"

# ===== 版本形态（免费版 / 付费版）=====
# 一套代码两种形态，用 CAP_EDITION 一个环境变量切换，付费代码不删、日后可随时切回。
#   free（默认）——完全不需要支付：不配任何密钥、不建单、不返 402，9 项能力直接本地跑。
#                  适合：自用 / 内部分享 / 不想接支付的上架形态。
#   pay          ——原付费形态：按次收单、402 双通道支付意图、验付幂等履约、付费治理全开。
# 切回付费：export CAP_EDITION=pay（并把 SKILL.md frontmatter 的 pay: 块取消注释）。
EDITION = os.environ.get("CAP_EDITION", "free").strip().lower()
PAY_REQUIRED = EDITION == "pay"
FREE_MODE = not PAY_REQUIRED

# ===== 基础 =====
APP_NAME = "cost-auditor-pay"
ENV = os.environ.get("CAP_ENV", "dev")  # dev / sandbox / prod
HOST = os.environ.get("CAP_HOST", "0.0.0.0")
PORT = int(os.environ.get("CAP_PORT", "8000"))
GATEWAY_BASE = os.environ.get("CAP_GATEWAY_BASE", "http://localhost:8000")

# 源技能真实算法脚本目录（capabilities 通过 subprocess 接线的真实引擎所在）
# 默认指向本地 cn-cost-ref/scripts；上架/部署时由环境变量覆盖为实际路径
CN_COST_REF_SCRIPTS_DIR = _resolve_scripts_dir()

# 本地材料价库（日更源）：由 material_price_update.py 增量/联网刷新维护，
# price_query 实时读取、bid_selfcheck 取基准价；部署时可用环境变量覆盖为实际路径
CN_COST_REF_PRICE_DB = os.environ.get(
    "CN_COST_REF_PRICE_DB",
    os.path.join(CN_COST_REF_SCRIPTS_DIR, "data", "material_prices.json"),
)

# ===== 不平衡报价/偏差自检判定阈值（bid_selfcheck）=====
# 偏差率 = (报价 − 基准价) / 基准价，取自真实引擎 cost_adjuster.py 的「调差幅度%」
# ⚠ 阈值以【招标文件「不平衡报价」条款约定】为准，下列 0.15 仅为缺省提示值。
#   实测广东 2026-07 某施工招标补充公告约定为 **±20%**，原文：
#   「若投标清单项目综合单价相较于招标控制价《分部分项工程和单价措施项目清单与计价表》
#     对应子目综合单价偏差超出±20%，该清单项目认定为不平衡报价项目」，
#   并给出修正公式「调整单价=控制价对应子目综合单价×(1−中标下浮率)」与修正后总额校核规则。
#   15% 实为【工程量偏差】的常见约定（超 15% 部分下调/上调 3%）被移植，非不平衡报价规定值。
#   详见 references/unbalanced-bid-correction.md
# 用法：分析具体项目前先读招标文件，按其约定设 CAP_BID_DEV_HIGH / CAP_BID_DEV_LOW。
BID_HIGH_THRESHOLD = float(os.environ.get(
    "CAP_BID_DEV_HIGH",
    os.environ.get("CAP_BID_HIGH_THRESHOLD", "0.15")))   # ≥ +15% 判虚高预警（缺省，须按招标文件覆盖）
BID_LOW_THRESHOLD = float(os.environ.get(
    "CAP_BID_DEV_LOW",
    os.environ.get("CAP_BID_LOW_THRESHOLD", "-0.15")))   # ≤ −15% 判压低预警（缺省，须按招标文件覆盖）

# SkillHub 平台技能 ID（与 SKILL.md frontmatter skill_id 一致；用于发布绑定与网关自识别）
# 仅从环境变量注入，禁止硬编码真实值，避免随交付物泄露个人 API 标识
SKILL_ID = os.environ.get("SKILLHUB_SKILL_ID", "")

# ===== 商户 / 服务商（支付宝 A2M）=====
# 以下仅为占位，真实部署由配置中心 / KMS 注入
ALIPAY = {
    "app_id": os.environ.get("ALIPAY_APP_ID", ""),
    "private_key": os.environ.get("ALIPAY_APP_PRIVATE_KEY", ""),   # PKCS#1 Base64
    "alipay_public_key": os.environ.get("ALIPAY_PUBLIC_KEY", ""),
    "gateway": os.environ.get(
        "ALIPAY_GATEWAY",
        "https://openapi-sandbox.dl.alipaydev.com/gateway.do",
    ),
    "seller_id": os.environ.get("ALIPAY_SELLER_ID", ""),          # 2088 商户号
    "service_id": os.environ.get("ALIPAY_SERVICE_ID", "api_mock_service_id"),
    "merchant_private_key": os.environ.get("ALIPAY_MERCHANT_PRIVATE_KEY", ""),
}

# ===== 微信支付（SkillHub X402 / AI 专属卡）=====
WEIXIN = {
    "mch_id": os.environ.get("WEIXIN_MCH_ID", ""),
    "app_id": os.environ.get("WEIXIN_APP_ID", ""),
    # X402 收款地址（平台分配的 weixinpay 结算地址）
    "pay_to": os.environ.get("WEIXIN_PAY_TO", ""),
    "merchant_private_key": os.environ.get("WEIXIN_MERCHANT_PRIVATE_KEY", ""),
    "skillhub_public_key": os.environ.get("SKILLHUB_PUBLIC_KEY", ""),
}

# ===== 订单仓储 =====
# prod 必须绑定真实 DB；dev 用 SQLite 文件
ORDER_DB_URL = os.environ.get("CAP_ORDER_DB", "sqlite:///./cost_auditor_pay_orders.db")

# ===== 单包价（元，CNY）：不分能力，统一 15.00 元/次 =====
# A2M 为按次/按量付费；本项目将 5 项能力合并为单一计费项「造价稽核一次」。
# 仅骨架默认值；上线前由环境变量 CAP_PACKAGE_PRICE 覆盖，并以后台设定为准。
PACKAGE_PRICE = os.environ.get("CAP_PACKAGE_PRICE", "15.00")
PACKAGE_GOODS_NAME = "造价稽核一次"

CAPABILITY_TITLES: dict[str, str] = {
    "reprice": "综合单价重算/核减",
    "settle_review": "结算争议核减分析",
    "cad_takeoff": "工程量图纸核对（CAD算量）",
    "bid_selfcheck": "投标报价经济性自检",
    "claim_report": "索赔报告生成",
    # —— 以下为本轮对标行业工作台新增的 4 项能力（仍单包价 15 元/次）——
    "price_query": "材料价格查询/市场定价",      # 对应广联达广材网/指标网、芒旭造价数据库
    "index_compare": "造价指标/调差对比",        # 对应陆家嘴全过程闭环、三算对比
    "clear_tender": "招投标清标",                # 对应广联达智能清标 3-5天→4小时
    "health_check": "成果质量体检",              # 对应行业成果文件智能审核/360体检
}

# ===== 开发态 mock 密钥（仅 dev/sandbox 本地联调用，prod 必须移除）=====
DEV_HMAC_SECRET = os.environ.get("CAP_DEV_SECRET", "dev-only-mock-secret-do-not-use-in-prod")

# ===== 企业级付费治理（对标 x402/MPP 生产必备：额度/风控/退款/计量）=====
# 免费试用额度：同一 user 每日前 N 次免单（降低首次使用门槛，不触发 402）
CAP_FREE_QUOTA_PER_DAY = int(os.environ.get("CAP_FREE_QUOTA_PER_DAY", "3"))
# 单笔金额风控上限：超过则拒绝服务（本技能单价 15 远低于此，作为治理护栏保留）
CAP_MAX_AMOUNT_PER_REQUEST = os.environ.get("CAP_MAX_AMOUNT_PER_REQUEST", "50.00")
# 单日累计消费上限（元）：超过则熔断，防递归/失控扣费
CAP_DAILY_SPEND_CEIL = os.environ.get("CAP_DAILY_SPEND_CEIL", "500.00")
# 退款/争议处理开关（prod 接真实支付宝退款 API；dev 仅占位标记 need_refund）
CAP_REFUND_ENABLED = os.environ.get("CAP_REFUND_ENABLED", "true").lower() in ("1", "true", "yes")


def price_of(capability: str) -> Decimal:
    """单包价：不分能力，统一返回 PACKAGE_PRICE。"""
    return Decimal(PACKAGE_PRICE)
