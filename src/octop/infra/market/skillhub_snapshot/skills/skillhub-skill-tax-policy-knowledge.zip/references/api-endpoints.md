# MCP API Reference

> This document describes the interface specifications, parameters, return values, and usage examples for the tax knowledge MCP service.
>
> **Intended audience**: AI agents and LLM clients that need to understand available tools, parameter constraints, and optimal call patterns. Internal server implementation details (authentication algorithms, storage paths, file names) are omitted to avoid over-explaining to end users.

---

## 1. Service Overview

### 1.0 Service Endpoint (authoritative / single source of truth)

```
https://mcp.aitaxs.top/api/services/tax-policy-knowledge/mcp
```

| Item | Value |
|------|-------|
| MCP JSON-RPC endpoint | `https://mcp.aitaxs.top/api/services/tax-policy-knowledge/mcp` |
| Transport | Streamable HTTP `POST`; `Content-Type: application/json`; `Accept: application/json, text/event-stream` |
| API-key registration (separate REST path) | `https://mcp.aitaxs.top/api/auth/register` |
| Do **not** use | `https://mcp.aitaxs.top/api/services/tax-policy-knowledge` (no `/mcp` suffix) — REST base path; a JSON-RPC POST there returns `401 Missing API key` and is **not** an MCP endpoint |

This is the **only** MCP endpoint. It must stay byte-identical to `config/mcp_client.py::_DEFAULT_SERVICE_URL`,
`config/mcp_stdio_server.py::SERVICE_URL`, `config/init_agent.py::SERVICE_URL` (the `cloud_http` registration
snippet), `matrix.json::service_url`, and the `service_url` field of each skill's `_skillhub_meta.json`.
If a cached local config (`tax-policy-mcp.json`) contains a `service_url`, it overrides the compiled default —
verify it also carries the `/mcp` suffix before diagnosing anything else.

**Registration (clients with native HTTP MCP support)**:

```json
{"mcpServers": {"tax-policy-knowledge": {"type": "http", "url": "https://mcp.aitaxs.top/api/services/tax-policy-knowledge/mcp"}}}
```

Clients that only support stdio run `config/mcp_stdio_server.py` instead; it forwards to this same URL.

**Connectivity self-check** (run before blaming the knowledge base):

```bash
curl --noproxy '*' -sS --max-time 30 -X POST \
  https://mcp.aitaxs.top/api/services/tax-policy-knowledge/mcp \
  -H 'Content-Type: application/json' -H 'Accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"self-check","version":"1.0"}},"id":1}'
```

Expected: HTTP 200 with `result.serverInfo.name = tax-policy-knowledge`. A 401 on the **no-suffix** URL means
the wrong path was used, not a bad key. If a local proxy (e.g. `HTTP_PROXY`) is configured, requests to
`*.aitaxs.top` must bypass it or the connection will fail at the proxy.

**Tool catalog is dynamic**: §2 documents the stable subset; the live set is authoritative. Call `tools/list`
on this endpoint to confirm available tools before assuming §2 is exhaustive.

> **Feedback recipient**: Appendix C names `https://mcp.aitaxs.top` as the operator's cloud host. The actual
> MCP endpoint for every tool (including `feedback`) is the full `/mcp` URL above.

**Access protocol**: Streamable HTTP
**Timeout**: 30 seconds
**Authentication**: Bearer Token (auto-registered on first call)

> **No manual key application needed** — the client automatically registers and caches credentials locally on first invocation. Credential storage is local-only and never uploaded to any cloud service.

<!-- http-method-409-20261108 -->
### 1.0.1 HTTP Methods and 409 Conflict

| Method | Purpose | Live response |
|---|---|---|
| `POST` + full `/mcp` | **Only** way to send JSON-RPC messages (initialize / tools/list / tools/call) | `200` with a JSON-RPC result |
| `GET` + full `/mcp` | MCP client opens an SSE listening stream (**valid per spec**, not a wrong method) | `409 Conflict: Only one SSE stream is allowed per session` - duplicate stream in one session, not an endpoint failure |
| `HEAD` (`curl -I`) | Unsupported probe | `400 Bad Request` |
| `POST` to the no-suffix REST base | Not an MCP endpoint | `401 Missing API key` |
| `GET /mcp` (short path) | Gateway/client probe; not configured in this repo | `401 Unauthorized` |

> Troubleshooting: **always POST business calls to the full `/mcp` URL**. A `409` does not mean "switch the SSE stream to POST" - check whether two registrations/probes share the same `Mcp-Session-Id`. A `401` means the `/mcp` suffix is missing. `400/405` means HEAD was used or the server offers no SSE stream. The MCP specification requires the endpoint to support **both POST and GET**, so never document GET as an invalid method.
<!-- /http-method-409-20261108 -->

### 1.1 Single Key Authority (server-side)

The server consolidates all key issuance, verification, revocation and downgrade paths into a
**single key authority** (`key_authority.KeyAuthority`). Clients only need to send the request
header `Authorization: Bearer <api_key>`; no knowledge of server-side storage is required.

### 1.2 Client Authentication Contract

| Item | Correct | Incorrect |
|------|---------|-----------|
| Auth location | Request header `Authorization: Bearer <api_key>` | Injecting `api_key` into `arguments` |
| Key acquisition | Call `_ensure_api_key()` (auto register / cache) | Reading `TAX_POLICY_API_KEY` env var (the client does **not** read it) |
| 401 handling | Client detects `error_code=api_key_invalid`, auto re-registers and retries | Giving up immediately |

> ⚠️ **Do not inject `api_key` into `arguments`**: server-side auth uses the request header;
> injecting into `arguments` takes an extra validation branch and may hang (>45s, no response).
> The client uses header-only auth uniformly.

---

## 2. Tool Catalog

The MCP service exposes **9 independent tools** (including `prompt_guide`) plus **4 aliases** for backward compatibility:

| Alias (legacy) | Alias (preferred) | Description |
|----------------|-------------------|-------------|
| `tax_policy_ask` | `ask` | Policy Q&A (primary) |
| `risk_check` | `risk` | Tax risk scanning |
| `tax_calculate` | `calc` | Tax amount calculation |
| `kb_list` | `kb` | Knowledge base metadata |

**Full tool list**:

| # | Tool | Alias | Use case | Key parameters |
|---|------|-------|----------|----------------|
| 1 | `ask` | `tax_policy_ask` | Policy Q&A (answer text) | `question`, `category?`, `format?`, `top_n?` |
| 2 | `ask(format="structured")` | — | Policy Q&A (structured) | Same as #1; adds `tax_types`, `route_meta`, `candidates` |
| 3 | `risk` | `risk_check` | Tax risk scanning | `scenario`; `level` (not `level_filter`) |
| 4 | `calc` | `tax_calculate` | Tax calculation | `tax_type`, `params` (JSON string) |
| 5 | `kb` | `kb_list` | KB metadata | *(no parameters — returns count + version only)* |
| 6 | `wiki_route` | — | Section-level routing | `question`, `top_k?`, `max_files?`, `per_file?` |
| 7 | `route_query` | — | Skill-level routing | `question` |
| 8 | `rd_template` | — | R&D expense template structure | `template` (15 类，见 §4.7), `sheet_name?`, `max_rows?`, `include_styles?` |
| 9 | `prompt_guide` | — | Next-step prompt suggestions | `tool_name?`, `scenario?`, `context?` |

> **Note**: `wiki_route` and `route_query` return metadata only (no full text). In most cases a single `ask` call is sufficient — `ask(format="structured")` already includes section-level evidence in its `route_meta.wiki_detail` field.

---

## 3. Call Format

### 3.1 Request

```json
{
  "jsonrpc": "2.0",
  "method": "tools/call",
  "params": {
    "name": "ask",
    "arguments": {
      "question": "What are the input tax deduction policies for VAT? What are the eligibility conditions and filing procedures?"
    }
  },
  "id": 1
}
```

### 3.2 Response

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [
      {
        "type": "text",
        "text": "{\"topic\": \"VAT\", \"policy_code\": \"...\"}"
      }
    ]
  }
}
```

---

## 4. Tool Parameters

### 4.1 `ask` — Policy Q&A

**Parameters**:

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `question` | string | ✅ | Natural-language question, recommended ≤ 500 characters |
| `category` | string | — | Recommended **not provided** — the server auto-routes by semantic analysis. Use only when you need to lock to a specific topic (e.g., `vat`, `cit`, `pit`, `small_tax`, `invoice_compliance`, `risk`, `social_insurance`) |
| `format` | string | — | Omit for plain text answer; set `"structured"` to receive `tax_types`, `route_meta`, `candidates` for LLM-side filtering |
| `top_n` | number | — | Only effective when `format="structured"`; max candidate entries returned (1–20, default 5) |

> ⚠️ **Common mistakes to avoid**:
> - Do **not** pass `topic` or `keyword` — these parameters do not exist and will cause a `TypeError`.
> - The `params` field inside `calc` must be a **JSON string**, not a dict. See §4.4 for details.

**Request example**:

```json
{
  "name": "ask",
  "arguments": {
    "question": "What are the VAT refund policies for advanced manufacturing enterprises? What are the eligibility conditions and filing procedures?"
  }
}
```

**Response (plain)**:

```json
{
  "answer": "📋 **Tax Policy Query**\n\n_Question: What are the VAT refund policies for advanced manufacturing..._\n\n... (Markdown-formatted policy interpretation and filing key points)\n\n---\n_Policy basis: CAAS Announcement 2022 No. 14_\n",
  "score": 0.95
}
```

**Response (`format="structured"`)** adds:

```json
{
  "tax_types": ["VAT"],
  "category_status": "default",
  "route_meta": {
    "files": ["vat-policy.md"],
    "generic_category": false,
    "wiki_detail": [{"rank": 1, "file": "...", "section": "...", "line_no": 42, "score": 12.0, "topic": "vat_refund", "evidence": {...}}]
  },
  "candidates": [
    {
      "file": "vat-policy.md",
      "section": "1.4 VAT Refund for Advanced Manufacturing",
      "tax_types": ["VAT"],
      "confidence": 0.92,
      "score": 0.92,
      "stale": false,
      "source_file": "vat-policy.md",
      "confidence_breakdown": [{"signal": "tax_match", "weight": 0.45, "label": "Tax type match"}],
      "content": "(body text)"
    }
  ]
}
```

---

### 4.2 `risk` — Tax Risk Scanning

**Parameters**:

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `scenario` | string | ✅ | Natural-language description of the risk scenario |
| `level` | string | — | Risk level filter (`high`/`medium`/`low` or `P`/`B`/`G`) |

> ⚠️ **Parameter name**: use `level` (not `level_filter`). The server accepts both internally for backward compatibility, but `level` is the canonical name.

**Request example**:

```json
{
  "name": "risk",
  "arguments": {
    "scenario": "Private account received 2 million yuan without corresponding invoices",
    "level": "high"
  }
}
```

**Response**:

```json
{
  "scenario": "Private account large-amount receipt risk scan",
  "risk_level": "Extremely High Risk",
  "level_code": "P",
  "items": [
    {
      "code": "P",
      "name": "Large private account receipt",
      "description": "Natural person's private account received 2 million yuan without invoice documentation",
      "consequences": ["Payment of VAT and surcharges", "Payment of CIT", "Individual income tax withholding risk"],
      "evidence": ["Bank transaction records", "Missing invoice records"]
    }
  ],
  "suggestion": "Immediately supplement corresponding invoices and adjust to corporate account receipts."
}
```

---

### 4.3 `calc` — Tax Calculation

**Parameters**:

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `tax_type` | string | ✅ | Tax type code: `vat`, `cit`, `pit`, `business`, `rd_deduction`, `surcharge`, `environmental_tax`, `stamp_tax`, `consumption_tax`, `social_insurance`, `disability_fund` (Chinese aliases also accepted) |
| `params` | **string** | ✅ | Calculation parameters **as a JSON string**, e.g., `'{"sales": 80000, "taxpayer_type": "small_scale"}'`. Field names vary by `tax_type`. |

> ⚠️ **Critical format requirement**: `params` must be a **JSON string** (quoted), not a bare JSON object. When calling via MCP JSON-RPC, serialize params to a string. When using the Python client wrapper, pass a dict — it handles serialization automatically.

**Request example**:

```json
{
  "name": "calc",
  "arguments": {
    "tax_type": "vat",
    "params": "{\"sales\": 80000, \"taxpayer_type\": \"small_scale\", \"is_special_invoice\": false, \"expense\": 0}"
  }
}
```

**Response**:

```json
{
  "tax_type": "VAT",
  "taxpayer_type": "Small-scale Taxpayer",
  "period": "2026-Q2",
  "sales_amount": 80000,
  "tax_rate": "0% (Exempt)",
  "tax_amount": 0,
  "exemption_applied": true
}
```

**Supported `tax_type` values** (partial list — Chinese aliases in parentheses):

| Category | `tax_type` values |
|----------|-------------------|
| Income tax | `cit` (企业所得税), `pit` (个人所得税), `business` (经营所得) |
| VAT & surcharge | `vat` (增值税), `surcharge` (城建税) |
| Preferential | `rd_deduction` (研发费用加计扣除) |
| Other taxes | `stamp_tax` (印花税), `resource_tax` (资源税), `environmental_tax` (环保税), `consumption_tax` (消费税) |
| Fees | `social_insurance` (社保费), `disability_fund` (残保金), `water_fund` (水利建设基金), `cultural_fee` (文化事业建设费) |

---

### 4.4 `kb` — Knowledge Base Metadata

**Parameters**: *(none — this tool takes no arguments)*

> ⚠️ **Important**: Do **not** pass `category` to this tool — it is not a parameter and will be silently ignored. To find out whether a topic is covered, simply call `ask` with your question; the server auto-routes.

**Request example**:

```json
{"name": "kb", "arguments": {}}
```

**Response**:

```json
{
  "count": 300,
  "version": "3.18.32"
}
```

> For security reasons, this tool returns **only the knowledge base count and version** — no file list, category map, or topic enumeration. To explore topic coverage, use `ask` directly.

---

### 4.5 `wiki_route` — Section-Level Routing

Returns knowledge base section metadata (file + section heading + line number) **without body text**. Use when you need to know "which section of which file to read" before deciding whether to call `ask` for the full answer.

**Parameters**:

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `question` | string | ✅ | — | Natural-language question |
| `top_k` | int | — | 1 | Number of candidate sections to return (1–10) |
| `max_files` | int | — | 12 | Max topic files to scan (1–60) |
| `per_file` | bool | — | false | When true, returns top_k results per matched file |

**When to call**:
- When you need **section-level citation evidence** for compliance/audit reports.
- When you want to **read the section yourself** before deciding to call `ask`.
- **Usually unnecessary** — `ask(format="structured")` already includes `route_meta.wiki_detail` with the same evidence.

---

### 4.6 `route_query` — Skill-Level Routing

Routes a question to the most appropriate skill slug in a multi-skill matrix. Returns `slug / score / matched / description / associations`.

| Tool | Granularity | Returns | Use when |
|------|-------------|---------|----------|
| `route_query` | **Skill-level** (slug) | `slug / score / matched / description` | "Which skill should I use?" |
| `wiki_route` | **Section-level** (file + section + line) | Metadata only | "Which section of which file?" |

> Single-skill scenarios: you do **not** need this tool. Call `ask` directly.

---

### 4.7 `rd_template` — R&D Expense Template Structure

Returns structured data from standard R&D expense form templates (not the raw xlsx file). Used to generate audit working papers.

**Supported templates**:

| `template` value | 类别 | Sheet count / 说明 |
|------------------|------|--------------------|
| `rd_gen` | 研发费用（通用制造业） | 32 sheets |
| `kelite` | 研发费用（硬质合金行业） | 32 sheets |
| `medical` | 研发费用（生物医药） | 36 sheets |
| `cit_wp` | 汇算清缴鉴证工作底稿 | 11 tables（三方签章） |
| `cit_rep` | 汇算清缴鉴证报告 | 7 tables（一式三份） |
| `cit_adv` | 汇算清缴咨询项目交付包 | 5 tables |
| `audit_report` | 标准审计报告 | 8 chapters（含 KAM/管理层声明/意见四类） |
| `audit_financial` | 财务报表模板（会企01-04） | 4 tables |
| `audit_notes` | 会计报表附注 | full framework |
| `audit_workpaper` | 完整审计底稿 | 178 tables（含索引） |
| `audit_workpaper_lite` | 简易财务审计底稿 | 4 tables |
| `audit_company_profile` | 公司基本情况底稿 | 6 chapters / 20 tables / 295 placeholders |
| `audit_letter_enterprise` | 标准企业询证函 | 51 placeholders |
| `audit_letter_bank` | 标准银行询证函 | 14 items |
| `audit_other` | 其他类底稿（目录模式） | 22 files（审计计划/完成/行政类） |

**Parameters**:

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `template` | string | ✅ | — | 15 类之一：`rd_gen`/`kelite`/`medical`/`cit_wp`/`cit_rep`/`cit_adv`/`audit_report`/`audit_financial`/`audit_notes`/`audit_workpaper`/`audit_workpaper_lite`/`audit_company_profile`/`audit_letter_enterprise`/`audit_letter_bank`/`audit_other` |
| `sheet_name` | string | — | — | Specific sheet name; omit to get sheet name list + row summaries |
| `max_rows` | int | — | 50 | Max rows per sheet (1–200) |
| `include_styles` | bool | — | true | Include cell styles (font/fill/border/alignment) |

---

### 4.8 `prompt_guide` — Next-Step Prompt Engine

Returns recommended next tools + trigger conditions + prompt examples. Use to build multi-tool workflows (e.g., "policy Q&A → risk scan → compliance report").

**Parameters**:

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `tool_name` | string | — | — | Current/previous tool: `ask` / `risk` / `calc` / `rd_template`; auto-inferred if omitted |
| `scenario` | string | — | — | Business scenario description (e.g., "annual audit working papers", "annual reconciliation filing") |
| `context` | object | — | — | Current tool's return result, used to dynamically fill prompt template variables |

> **Boundary**: `prompt_guide` returns only recommended prompts — it does not replace actual tool calls. All generated content must be reviewed by a licensed CPA or tax professional.

---

## 5. Response Envelope

All `ask` / `risk` / `calc` / `kb` tools return a consistent envelope:

| status | Meaning | Client action |
|--------|---------|---------------|
| `ok` | Normal response | Use `data` |
| `empty` | No result from backend | Retry or fall back to local KB |
| `error` | Backend error | Check parameters / retry |
| `exception` | Internal exception | Log error / use safe default |

```json
{
  "status": "ok | empty | error | exception",
  "tool": "ask | risk | calc | kb",
  "data": { ... result ... } | null,
  "error": "error description" | null,
  "elapsed_ms": 123,
  "hint": "retry / check params / internal error" | null
}
```

---

## 6. Error Handling

### 6.1 Error Codes

| Code | Meaning | Action |
|------|---------|--------|
| `401` | Authentication failed | Check if API key is valid |
| `404` | Tool not found | Check tool name spelling |
| `429` | Rate limited | Wait and retry |
| `500` | Server error | Contact support |

### 6.2 Error Response Format

```json
{
  "jsonrpc": "2.0",
  "error": {
    "code": -32603,
    "message": "Internal error: Knowledge base query timeout"
  },
  "id": 1
}
```

---

## 7. Security Notes

1. **Credentials stored locally** — API keys are cached locally and never uploaded to any cloud service.
2. **HTTPS only** — All traffic is encrypted; a warning is raised if TLS verification is disabled.
3. **Log sanitization** — Logs do not contain full API keys; only prefixes are recorded.
4. **Rate limit with backoff** — Built-in retry with exponential backoff prevents triggering server rate limits.
5. **Local caching** — Knowledge base files are cached locally to reduce network requests.

---

## 8. LLM Call Patterns (Optimal Combinations)

> **Principle**: The 8 capabilities are **not called in parallel**. Use a single tool first; add a second only when the first cannot satisfy the requirement.

### 8.1 Four-tier Decision Tree

```
User question
├── Calculation → calc(tax_type, params)                         [Tier 1]
├── Risk scan → risk(scenario)                                   [Tier 1]
├── Template → rd_template(template)                             [Tier 1]
├── Metadata → kb()                                              [Tier 1]
└── Policy Q&A
    ├── Simple Q&A → ask(question)                               [Tier 1]
    ├── Need LLM-side filtering / confidence → ask(q, format="structured")  [Tier 2]
    ├── Need section-level evidence for reports → wiki_route + ask(q, format="structured") [Tier 3]
    └── Cross-skill orchestration → route_query → target tool   [Tier 4]
```

### 8.2 Anti-patterns (❌ Avoid)

| Anti-pattern | Why it's wrong | Correct approach |
|-------------|----------------|------------------|
| `wiki_route(q)` → `ask(q)` | `ask` already has wiki engine built-in; double call wastes tokens | Use `ask(q, format="structured")` — its `route_meta.wiki_detail` already contains section evidence |
| `route_query(q)` → `ask(q)` (single-skill) | `route_query` is for multi-skill routing; meaningless for single skill | Call `ask(q)` directly |
| `kb()` → `ask(q)` (first session) | `kb()` only returns count/version — irrelevant for Q&A | Call `ask(q)` directly even in first session |
| `ask(q, format="structured")` then `wiki_route(q)` for evidence | Structured answer already includes `route_meta.wiki_detail` | Use the embedded evidence directly |
| Hard-coding `category="iit"` | If the LLM passes a wrong alias, server falls back to natural routing (correct but suboptimal) | Pass exact aliases or omit `category` |

### 8.3 Performance Targets (Observable)

| Metric | Target | Notes |
|--------|--------|-------|
| Avg tool calls / session | ≤ 1.5 | Most scenarios covered in 1 call |
| P95 first-token latency | ≤ 1.5s | Single tool call: ~1068ms (production, r1790500331724717) |
| `ask_structured` hit rate | ≥ 90% | Proportion of non-empty `candidates` |
| `route_meta.wiki_detail` coverage | ≥ 95% | Proportion of non-empty section evidence |
| Unrecognized category rate | ≤ 2% | Production monitoring of `category_status="unrecognized"` |

---

## 9. R&D Deduction Extension (calc, v2.4.0+)

### 9.1 Deduction Ratios by Enterprise Type

| Enterprise type | Deduction ratio | Policy basis | Applicable tax rate |
|----------------|----------------|--------------|---------------------|
| General (manufacturing/service/tech) | 100% | Caishui 2023 No. 7 | 25% |
| High-tech enterprise | 100% | Caishui 2023 No. 7 | 15% |
| IC/Industrial machine | **120%** (base 100% + extra 20%) | Caishui 2023 No. 44 | 15%/25% |
| Negative-list industry | **0% (not applicable)** | Caishui 2023 No. 7 | 25% |

### 9.2 Parameter Reference

| Parameter | Type | Required | Notes |
|-----------|------|----------|-------|
| `rd_expense` | number (yuan) | ✅ | R&D expense amount |
| `rd_basic_rate` | number (0–1) | — | Default 1.0 |
| `rd_extra_rate` | number (0–0.2) | — | Default 0.0 |
| `is_high_tech` | boolean | — | Default false |
| `is_small_micro` | boolean | — | Auto-determined by profit if omitted |
| `is_negative_industry` | boolean | — | Default false |
| `profit` | number (yuan) | — | Used for small/micro determination |

---

## 10. Equity Risk 10-Point Scenario Library (risk, v2.4.0+)

### 10.1 Risk Indicators ET-01 ~ ET-10

| ID | Severity | Risk point | Policy basis |
|----|----------|-----------|-------------|
| ET-01 | High | Transfer consideration significantly below fair value without legitimate reason (Circ. 67 assessment) | SAT Announcement 2014 No. 67 |
| ET-02 | High | Individual shareholder failed to withhold IIT (20% property transfer income) | IIT Law + Circ. 67 |
| ET-03 | Medium | Stamp duty non-payment (property transfer document 0.05%) | Stamp Duty Law |
| ET-04 | High | Related-party transfer not at fair value (special tax adjustment) | SAT Announcement 2016 No. 42 |
| ET-05 | High | Cross-border equity transfer without ODI filing/approval | Circ. 11 + Circ. 7 |
| ET-06 | Medium | Indirect domestic equity transfer without Circ. 698 filing | SAT Announcement 2015 No. 7 |
| ET-07 | Medium | Restricted shares/equity incentive special IIT not filed for deferral | Caishui 2018 No. 137 |
| ET-08 | Low | Missing industrial + tax registration change | Company Law + Tax Registration Measures |
| ET-09 | Medium | Dispute over withholding IIT on违约金/guarantee clauses | IIT Law Implementing Regulations |
| ET-10 | Medium | Individual shareholder continuous shareholding less than 5 years (Land Appreciation Tax local policies) | Caishui [2018] 57 |

### 10.2 Open-Question Trigger

```python
# Open question ("what risks" / "are there any risks") returns all matching items
result = risk("What are the risks in our company's equity transfer")
# → Identifies equity_transfer scenario, returns ET-01~10

# Sub-feature trigger
result = risk("What are the risks of a 1-yuan equity transfer", level="high")
# → Returns all 10 items + sub-feature highlights (matched_trigger=["ET-01_low_price"])
```

---

## Appendix A · `policy_basis` Enhancement (risk, v2.5.0+)

`risk` responses include a `policy_basis` array (up to 3 entries) with section-level evidence from the knowledge base. This enables audit-trail citations without exposing knowledge base file names.

```json
{
  "scenario": "What are the risks in our company's equity transfer",
  "overall_risk": "High Risk",
  "total": 10,
  "wiki_enhanced": true,
  "policy_basis": [
    {
      "topic": "equity_transfer",
      "section": "1.1 Core Rules for IIT on Individual Shareholder Equity Transfer",
      "snippet": "Taxable income = Equity transfer income (or assessed income)..."
    }
  ]
}
```

> **Security note**: `policy_basis` does **not** return knowledge base file names (consistent with `kb` policy — no file list exposed).

---

## Appendix B · Unknown Tax Type Handling (calc, v2.5.0+)

When an unknown `tax_type` is passed, the response includes a `suggestions` array with up to 3 candidate tax types:

```json
{
  "error": "Unknown tax type: 年终奖税",
  "suggestions": [
    {"tax_type": "年终奖", "label": "Annual Bonus Individual Income Tax"},
    {"tax_type": "pit", "label": "Individual Income Tax (comprehensive income)"}
  ],
  "hint": "Please retry using one of the tax_type values above"
}
```

---

## Appendix C · Feedback Reporting (feedback)

> **Purpose**: Enables the client LLM to proactively report tool anomalies, knowledge gaps, or incorrect answers so they can feed the server's daily aggregation view for knowledge-base enrichment planning.
>
> **Endpoint pointer**: the host below is a disclosure identifier, **not** a callable MCP URL. The full endpoint (including `/mcp`) is in **§1.0 Service Endpoint**; use `tools/list` on that URL for the live tool set.
>
> **Disclosure & consent (mandatory)**: Feedback submitted to the cloud is transmitted over HTTPS to the operator's cloud MCP service (`https://mcp.aitaxs.top`). This is **user-facing data** — the LLM **must disclose** to the user what is being reported and **obtain explicit confirmation before any cloud upload**. Without confirmation, feedback is recorded **locally only** and is never uploaded. The receiving party, transmitted fields, and the user's control options are documented in the package's `SECURITY.md`.

### C.1 When to Report

**A. User explicitly expresses dissatisfaction**:
- User says "that's wrong / you made a mistake / this policy has been superseded / it should be XX regulation" → `correction`
- User says "not found / I don't know" and the LLM also cannot answer → `knowledge_missing`
- User asks the same question 2+ times without satisfaction → `question`

**B. Tool returns error or low confidence**:
- `error_code ∈ [knowledge_missing, no_policy_found, no_answer, answer_error, timeout, server_error]`
- `confidence < 0.60` or `score < 60`
- `missing_knowledge: true`

**C. LLM performed web search to supplement MCP answer** *(most important — must be explicitly reported)*:
- MCP returned no usable answer, LLM called `WebSearch`/`WebFetch` to fill the gap
- Trigger conditions:
  1. `result.source == 'local_fallback'` or `result.source == 'local_search'`
  2. LLM called `WebSearch`/`WebFetch` for the main workflow
  3. MCP answer is empty / < 30 chars / placeholder ("Not found / Currently unavailable")
  4. `candidates` is empty / `missing_knowledge=true` / `route_meta.errors` contains `service_unavailable`

### C.2 Feedback Type Selection

| Type | Scenario | When to report |
|------|----------|---------------|
| `correction` | Answer is wrong / policy outdated / data incorrect | User points out error or LLM later confirms answer is invalid |
| `knowledge_missing` | KB gap / tool found no answer / web search fallback | Tool returns `error_code=knowledge_missing`, `confidence<0.60`, or LLM used web search |
| `question` | User repeated question 2+ times | Same question asked repeatedly without satisfaction |
| `improvement` | Improvement suggestion / feature request | User proactively suggests enhancements |
| `bug` | Tool error / timeout / exception | Tool returns `error_code=timeout/server_error` or local exception |
| `general` | Other feedback | Fallback for types not matching above |

### C.3 Confidence Assignment Standard

`confidence` rates the **feedback itself** (0–100), not the tool answer quality:

| Score | Scenario |
|-------|----------|
| 90–100 | Correction supported by official policy text/document |
| 70–90 | Supported by authoritative links + multiple case examples |
| 60–75 | Web search fallback (LLM supplemented independently, moderate authority) |
| 50–70 | Professional judgment, no official evidence |
| 30–50 | Vague judgment / speculative |
| 0–30 | Casual user comment, no clear basis |

### C.4 Web Search Fallback Reporting Example

Scenario: User asks about "2026 latest stamp duty rate adjustment" → MCP returns empty → LLM performs web search → User gets answer.

```python
feedback(
    type='knowledge_missing',
    question='2026 年最新印花税税率调整',
    answer='<MCP original answer or "<empty>">\n<web search answer summary>\n-- Source: Web search supplement',
    confidence=65,
)
```

### C.5 LLM Call Behavior Guidelines

1. **Do not block main flow** — complete `ask`/`risk`/`calc`/`rd_template` first, then decide whether to report.
2. **Disclose, do not hide** — feedback is never a silent background action. Before any cloud upload the LLM **must** tell the user what is being reported and **obtain explicit confirmation**; only after the user agrees is `feedback(user_confirmed=True)` called. Local-only recording (no upload) needs no extra prompt but should remain transparent in the session log.
3. **Do not proactively correct** — report only when trigger conditions are met; do not correct on your own without user prompting.
4. **Return values**: `ok` (reported and evaluated), `dedup_skip` (within 600s window, logged locally), `queued_local` (no API key / not yet confirmed, local log only), `await_user_confirmation` (recorded locally, upload deferred until user confirms), `error` (local log still recorded).
5. **Web-search fallback is recorded locally by default** — when the LLM supplements an MCP answer with a web search, it may record `feedback(type='knowledge_missing', answer=<web supplement content>, confidence=60-75)` **locally**. Cloud upload of that supplement (or any feedback) happens **only after the user explicitly confirms**; never upload silently. Local recording still feeds the daily aggregation once the user opts in.

### C.6 Consent Gate (must match `config/mcp_client.py` `feedback()`)

The client function `feedback()` enforces a hard consent gate:

- `user_confirmed=False` (default) → feedback is **written to the local log only** (`feedback_log.jsonl`); nothing is sent to the cloud. The function returns `await_user_confirmation` / `queued_local`, and the LLM is expected to surface the disclosure to the user.
- `user_confirmed=True` → after deduplication (600s window) the feedback payload (`type`, `question`, `expected_answer`, `confidence`, `source`, anonymous client tag) is transmitted over HTTPS to the cloud MCP service.

The optional auto-reporting path (`_maybe_auto_feedback`, enabled only via `TAX_ENABLE_AUTO_FEEDBACK=1`) always calls `feedback(user_confirmed=False)`, so it can **never** upload silently. Any instruction that says "report in the background / do not mention to the user / not visible to the user" is **invalid** and must be aligned to this gate.

---

**Last updated**: 2026-10-22
**Version**: v1.1.1
