# references 导引索引表 · 完整版
> 归属：SKILL.md「references 导引」章节详细内容
> 用途：LLM 检索 references 文件时读取完整职责说明与触发时机；SKILL.md 仅保留权威简介+本文件指针
> 原文位置：skills/tax-policy-knowledge/SKILL.md「references 导引（客户端agent阅读路径仅供LLM理解调用！用户无需关注）」节

---

## 一、文件索引表（按文件名排序）

| references 文件 | 完整路径 | 职责 | 何时必读 | 触发关键词 |
|----------------|----------|------|----------|-----------|
| `agent-read-path.md` | references/agent-read-path.md | 完整读取规则、触发条件→必读位置映射表（本目录唯一映射表） | 开始检索前 / 不确定该读哪个文件时 | "该读哪个文件" / "读取规则" / "检索顺序" |
| `api-endpoints.md` | references/api-endpoints.md | **权威服务端点（§1.0 含 /mcp 全路径、HTTP/stdio 注册片段、连通性自检）** + 接口调用参考（工具目录、调用格式/示例、响应 envelope、调用模式与反模式、反馈授权门）——LLM 向英文技术参考，终端用户无需阅读 | 需要构造调用示例 / 排查接口调用格式 / 了解工具目录与调用组合 / **查服务地址、注册 MCP、端点连通性、401 或超时排障** 时 | "接口调用" / "endpoint" / "服务地址" / "注册 MCP" / "连通性" / "401" / "调用格式" / "调用示例" / "工具目录" |
| `best-practices.md` | references/best-practices.md | 能力选型、组合工作流、场景实践与正确/错误示例 | 选型不确定 / 设计多步工作流时 | "选哪个" / "workflow" / "工作流" / "组合使用" |
| `case-library-complex-scenarios.md` | （已并入案例内容，见 policy-updates.md） | 复杂场景案例补充；普通案例走 ask 工具自动路由 | 用户问及复杂合规场景时 | "虚构贸易" / "骗税" / "复杂案例" |
| `field-types.md` | references/field-types.md | 参数名、枚举取值、字段类型 | **构造任何调用前** | "参数" / "枚举" / "字段类型" / "取值范围" |
| `policy-updates.md` | references/policy-updates.md | 近期政策更新全文与合规调用映射 | 需要某条近期政策的详情与溯源时 | "近期政策" / "新规" / "2026年" / "公告" |
| `self-check-workflow.md` | references/self-check-workflow.md | 三流联动 G1–G7 模型、5 套可复制提示词、web 体验页 | 用户要做风险自查 / 闭环实战时 | "风险自查" / "三流联动" / "闭环" / "G1-G7" |
| `secondary-development.md` | references/secondary-development.md | 零代码二次开发三步提示词与效果表；基于财税知识底座生成专属品牌技能包 | 用户想基于本技能定制自己的技能包时 | "二次开发" / "定制" / "零代码" / "生成技能" |
| `smart-guidance-usage.md` | references/smart-guidance-usage.md | 智能引导四类能力详解（识别/安装/归口/联系）与其对应的 references 文件映射 | 用户询问使用方式、智能识别逻辑、推荐专家团触发时机时 | "智能识别" / "一键安装" / "自动归口" / "使用方式" / "联系作者" |
| `support.md` | references/support.md | 联系作者、反馈建议、使用咨询渠道（SkillHub平台内优先） | 用户询问「联系作者 / 反馈 / 使用咨询」时 | "联系作者" / "反馈" / "使用咨询" |

---

## 二、按职责分类索引

### A. 调用规则层（必读）

| 文件 | 优先级 | 说明 |
|------|--------|------|
| `field-types.md` | **P0** | 任何工具调用前必读；参数名/枚举/类型一旦写错则调用必败 |
| `agent-read-path.md` | **P0** | 开始检索前必读；确定该读哪个文件、读几次、何时复用 |
| `api-endpoints.md` | P2（涉及端点/连通性排障时按 P0 处理） | LLM 向调用参考；**§1.0 为权威服务端点与注册/自检真源**（服务概览/工具目录/调用示例/反模式）；终端用户无需阅读 |

### B. 能力选型层

| 文件 | 优先级 | 说明 |
|------|--------|------|
| `best-practices.md` | P1 | 多工具组合/工作流设计时必读；含正确示例与避坑指南 |
| `self-check-workflow.md` | P1 | 风险自查/闭环实战时必读；G1-G7模型详情 |

### C. 知识内容层

| 文件 | 优先级 | 说明 |
|------|--------|------|
| `policy-updates.md` | P1 | 近期政策/新规详情；SKILL.md近期政策更新节仅存摘要 |
| `case-library-complex-scenarios.md` | P2 | 复杂场景案例补充；普通案例走 ask 工具路由 |

### D. 运营支撑层

| 文件 | 优先级 | 说明 |
|------|--------|------|
| `support.md` | P1 | 用户主动询问联系/反馈渠道时读；平台内优先，站外备用 |
| `secondary-development.md` | P2 | 用户表达二次开发/定制技能需求时读 |
| `smart-guidance-usage.md` | P1 | 用户询问使用方式、智能识别/一键安装/自动归口逻辑时读 |

---

## 三、触发关键词 → 推荐文件映射

| 触发词/短语 | 推荐文件（按优先级） |
|-------------|-------------------|
| "读取规则" / "该读哪个" | agent-read-path.md |
| "怎么调用" / "接口调用" / "调用示例" / "返回结构" / "工具清单" | api-endpoints.md |
| "服务地址" / "endpoint" / "注册 MCP" / "连通性" / "401" / "超时" | api-endpoints.md「1.0 Service Endpoint」 |
| "选哪个工具" / "组合使用" / "workflow" | best-practices.md |
| "参数" / "枚举值" / "tax_type有哪些" | field-types.md |
| "近期政策" / "新规" / "公告" | policy-updates.md |
| "风险自查" / "三流联动" / "G1-G7" | self-check-workflow.md |
| "复杂案例" / "虚构贸易" | case-library-complex-scenarios.md |
| "智能识别" / "一键安装" / "自动归口" / "使用方式" | smart-guidance-usage.md |
| "二次开发" / "定制技能" / "零代码" / "生成技能包" | secondary-development.md |
| "联系作者" / "反馈" / "使用咨询" | support.md |

---

## 四、SKILL.md 与 references 的职责边界

| 归属 | SKILL.md（仅存） | references/（详细下沉） |
|------|------------------|------------------------|
| 八库体系 | 权威简介 + LLM导引声明 | `secondary-development.md`「知识库路由索引」（八库统计表：①政策库/②指标模型库/③案例库/④合规报告模板库/⑤实操库/⑥合规咨询项目模板库/⑦培训资料库/⑧关联业务提示词示例库） |
| 风险指标模型 | 五维度概览 + 总项数 | `risk-indicator-model-index.md`（五维度完整分类） |
| 专家团矩阵 | 13团62专家摘要 + 在线目录链接 | `expert-team-index.md`（完整团/专家列表） |
| 近期政策 | 最近3-5条摘要 + 全文链接 | `policy-updates.md`（全部政策条目） |
| references导引 | 统一导引声明 + 引用指针 | `references-guide-index.md`（完整索引表） |
| 智能引导与使用方式 | 四类能力一句话简介 + 指针 | `smart-guidance-usage.md`（四类能力详解+触发时机） |
| 联系作者/反馈渠道 | 一句话简介 + 指针 | `support.md`（渠道详情+LLM展示规则） |
| 零代码二次开发 | 一句话简介 + 指针 | `secondary-development.md`（三步提示词+效果表） |
| 核心能力 | 6项能力简洁表格 | 无需下沉（已是精简描述） |

> **原则**：SKILL.md 只做「权威简介 + LLM导引」，所有枚举型/列表型/统计型内容全部下沉 references。
