# 客户端 agent 阅读路径

> 本文件只服务客户端 agent 的 LLM；终端用户无需阅读。SKILL.md「references 导引」是
> 本文件的入口指针（统一导引表：职责一句话 × 何时必读），完整规则、文件职责速查与
> 触发条件映射表全部在本文件查阅。

## 一、分层契约

- **SKILL.md** 只定义能力边界，并给出本文件的入口指针；不含接口定义、参数枚举、字段结构与调用细节。
- **本文件（agent-read-path.md）** 定义完整读取规则与「触发条件 → 必读位置」映射表，是本目录内唯一一份映射表。
- **参考资料**（best-practices.md / field-types.md / policy-updates.md / self-check-workflow.md 等）是被读取的目标文件。
- 本文件与参考资料内容不一致时，**以本文件映射表为准**。

## 二、读取规则

1. **构造调用前**：先读 `field-types.md`，确认参数名与枚举取值。
2. **返回异常时**：读到空结果、报错或字段含义不明，读 `best-practices.md`「常见问题与解决方案」。
3. **选型不确定时**：读 `best-practices.md` 的选型与场景章节。
4. **同会话只读一次**：同一文件已读内容不重复读取，避免浪费上下文。
5. **冲突以 references 为准**：SKILL.md 与 references 不一致时，以 references 为最终依据。

## 三、文件职责速查

| 文件 | 职责 |
|------|------|
| `agent-read-path.md`（本文） | 完整读取规则与触发条件→必读位置映射表 |
| `api-endpoints.md` | 服务权威端点、HTTP/stdio 接入注册片段、连通性自检、工具目录与调用格式（LLM 向英文技术参考） |
| `best-practices.md` | 能力选型、组合工作流、场景实践、速算与实战示例 |
| `field-types.md` | 字段类型、枚举取值、响应结构与兜底字段 |
| `policy-updates.md` | 近期政策更新全文与调用映射 |
| `self-check-workflow.md` | 三流联动 G1–G7 模型与提示词 |
| `risk-indicator-model-index.md` | 风险指标体系（五维度 581 项详细分类） |
| `expert-team-index.md` | 13 团·62 专家完整列表 |
| `support.md` | 联系作者、反馈建议、问题咨询渠道 |

## 四、触发条件 → 必读位置

| 当前任务触发条件 | 必读位置（文件「标题关键词」） |
|-----------------|------------------------------|
| 算税额 / 测算研发加计扣除 | `field-types.md`「研发费用加计扣除」、`best-practices.md`「rd_deduction」 |
| 风险初筛 / 判断有无风险 | `field-types.md`「风险场景代码枚举」、`best-practices.md`「risk 开放问题」 |
| 以开放问句问风险（如"有什么风险"） | `best-practices.md`「开放问题」、`risk-indicator-model-index.md`「开票经济专项」 |
| 调用失败 / 无输出 / 字段看不懂 | `best-practices.md`「常见问题与解决方案」、`field-types.md`「统一响应 envelope」 |
| 需要多能力组合的调用顺序 | `best-practices.md`「完整工作流」 |
| 何时使用研发费用测算 | `best-practices.md`「何时使用 rd_deduction」 |
| 需要政策依据 / 条款出处 | `policy-updates.md`「按日期检索」、`self-check-workflow.md`「三流联动」 |
| 需要速算数字与完整实战示例 | `best-practices.md`「附录 E」 |
| 做合规自查 / 生成报告 | `self-check-workflow.md`「可复制提示词」 |
| 查服务地址 / 注册 MCP 端点 / 连通性自检 / 401 或超时排障 | `api-endpoints.md`「1.0 Service Endpoint」 |
| 核对线上工具清单与文档工具目录是否一致 | `api-endpoints.md`「2. Tool Catalog」+ `tools/list` 实测 |

## 五、政策更新检索导引

| 需要了解 | 必读位置 |
|---------|---------|
| 近期政策更新速览（按日期定位） | `policy-updates.md`「按日期检索」 |
| 某条政策的调用参数 | `policy-updates.md`「MCP 映射」列、`field-types.md` |
| 政策与风险场景的关联 | `policy-updates.md`「MCP 映射」、`risk-indicator-model-index.md`「开票经济专项」 |
| category 参数速查表 | `policy-updates.md`「category 参数速查」 |
| 降级兜底（服务不可达时） | `best-practices.md`「常见问题与解决方案」 |

## 六、风险指标与自查导引

| 需要了解 | 必读位置 |
|---------|---------|
| G1–G7 模型详情与十要素闭环 | `self-check-workflow.md`「三流联动专项模型」 |
| 5 套可复制提示词（全量/发票/合同/报表/跨国） | `self-check-workflow.md`「可复制提示词」 |
| 开票经济/资金流/经营数据指标清单 | `risk-indicator-model-index.md`「开票经济专项」「资金流监控」「经营数据异常」 |
| 指标评分与组合联动降误报规则 | `risk-indicator-model-index.md`「指标评分规则」 |
