# 字段类型与参数枚举（LLM 工具调用辅助）

> 本文件定义所有 MCP 工具的参数枚举取值与响应结构，供 LLM 构造调用时参考。
> **不包含服务端内部实现细节**（知识库文件键名、路由表等），如有需要请查阅 SKILL.md。

---

## 1. ask 工具参数

### 1.1 `category` 参数枚举

| category | 含义 | 覆盖范围 |
|---------|------|---------|
| `vat` | 增值税 | 含附加税、进项抵扣、留抵退税、加计抵减 |
| `cit` | 企业所得税 | 含非货币性资产交换、汇算清缴 |
| `iit` | 个人所得税 | 含股权转让、年终奖、股权激励 |
| `pit` | 个人所得税（别名）| 同 `iit` |
| `small_tax` | 小规模纳税人 | 小规模免税/减征政策 |
| `invoice_compliance` | 发票合规 | 含虚开、虚抵、滞留票 |
| `invoice` | 发票合规（别名）| 同 `invoice_compliance` |
| `risk` | 风险通用 | 含预警、红线、处罚案例 |
| `social_insurance` | 社保 | 社保缴费基数、险种 |
| `compliance` | 合规管理 | 含稽查、整改、争议解决 |
| `surtax` | 附加税费 | 城建税/教育费附加/地方教育附加 |

> **推荐不传 `category`**：服务端支持自动语义路由，LLM 直接用自然语言提问即可，category 仅在确需锁定专题时使用。

### 1.2 `format` 参数枚举

| format 值 | 含义 | 使用场景 |
|----------|------|---------|
| （空） | 仅返回 `answer` + `score` | 绝大多数场景 |
| `"structured"` | 附加 `tax_types` / `category_status` / `route_meta` / `candidates` | 需要 LLM 二次筛选置信度 / 章节级证据 |

### 1.3 `category_status` 值（仅 `format="structured"` 时）

| 值 | 含义 |
|----|------|
| `default` | 未传 category，走自然路由 |
| `explicit` | 传了 category，且识别到（含 `iit`/`vat`/`cit`/`pit` 等别名） |
| `generic_ignored` | 传了泛化 category（如 `database`/`tax`），已降级为自然路由 |
| `unrecognized` | category 未识别，已回退自然路由（`route_meta.errors` 含 `category_unrecognized`） |

---

## 2. risk 工具参数

### 2.1 `level` / `level_filter` 参数枚举

| 值 | 含义 |
|----|------|
| `high` / `P` | 极高风险 / 高风险（重大违法嫌疑） |
| `medium` / `D` / `C` | 中风险（需关注核查） |
| `low` / `B` | 低风险（基本合规） |
| `A` | 无风险（完全合规） |

> 注意：`risk_check` 用 `level_filter` 参数名，`risk` 用 `level`（参数名不同，服务端自动兼容）。

### 2.2 `overall_risk` 风险等级

| 值 | 含义 |
|----|------|
| `极高风险` / `P` | 重大违法嫌疑，需立即处理 |
| `高风险` / `D` | 较高违法风险，需重视 |
| `中风险` / `C` | 需关注核查 |
| `低风险` / `B` | 基本合规 |
| `无风险` / `A` | 完全合规 |

### 2.3 开放问题识别词

| 触发词 | 行为 |
|-------|------|
| 「什么风险」/「有哪些风险」/「全部风险」/「罗列」 | 返回所有匹配情形 |
| 「1元转让」/「低价转让」 | 触发对价偏低专项（ET-01） |
| 「关联转让」/「关联交易」 | 触发关联交易专项（ET-04） |
| 「跨境」/「ODI」/「境外」 | 触发 ODI 备案专项（ET-05） |
| 「印花税」 | 触发印花税专项（ET-03） |

---

## 3. calc 工具参数

### 3.1 `tax_type` 参数枚举

| 分类 | tax_type 值 |
|------|------------|
| 所得税 | `cit` / `企业所得税`、`pit` / `个人所得税`、`iit` / `个人所得税` |
| 增值税及附加 | `vat` / `增值税`、`surcharge` / `城建税` |
| 优惠 | `rd_deduction` / `研发费用加计扣除` |
| 小税种 | `stamp_tax` / `印花税`、`resource_tax` / `资源税`、`environmental_tax` / `环保税`、`consumption_tax` / `消费税` |
| 费基金 | `social_insurance` / `社保费`、`disability_fund` / `残保金`、`water_fund` / `水利建设基金`、`cultural_fee` / `文化事业建设费` |
| 其他 | `business` / `经营所得`、`surtax` / `附加税费`、`lvat` / `土地增值税` |

### 3.2 `rd_deduction` 行业模板

| 模板值 | 行业 | 表数 |
|--------|------|------|
| `kelite` | 硬质合金 | 32 表 |
| `medical` | 生物医药 | 36 表 |

### 3.3 VAT 小规模纳税人 params 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `sales` | number | 销售额（单位：元） |
| `taxpayer_type` | string | `"small_scale"`（小规模）/ `"general"`（一般纳税人） |
| `is_special_invoice` | boolean | 是否开具增值税专用发票 |
| `expense` | number | 进项税额（一般纳税人用） |

---

## 4. 统一响应 envelope

所有工具（ask / risk / calc）统一返回如下 envelope 结构：

### 4.1 `status` 值

| 值 | 含义 | data 字段 | error 字段 | 客户端处理 |
|---|------|-----------|-----------|-----------|
| `ok` | 正常返回 | 业务结果 | null | 使用 data |
| `empty` | 后端无返回 | null | "后端无返回" | 重试 / 走本地知识库 |
| `error` | 后端报错 | null | 错误详情 | 检查参数 / 重试 |
| `exception` | 内部异常 | null | 异常类型+消息 | 记录日志 / fallback |

### 4.2 envelope 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `status` | string | `ok` / `empty` / `error` / `exception` |
| `tool` | string | 工具名：`ask` / `risk` / `calc` / `kb` |
| `data` | object/null | 业务结果（status=ok 时非空） |
| `error` | string/null | 错误描述（status≠ok 时非空） |
| `elapsed_ms` | number | 服务端处理耗时（毫秒） |
| `hint` | string/null | 客户端处理提示（可选） |

---

## 5. `policy_basis` 政策依据结构

risk 与 calc 工具返回时，可能附加 `policy_basis` 字段：

| 键 | 说明 |
|----|------|
| `topic` | 知识库专题标识（可用于再次提问精确追问） |
| `section` | 命中的章节标题 |
| `snippet` | 原文摘录（≤260 字，已过滤噪音） |

> **安全约束**：`policy_basis` **不返回知识库文件名**，防止文件清单泄露。

---

## 6. feedback 工具参数

> **外送与授权说明（与 `config/mcp_client.py` 的 `feedback()` 一致）**：反馈仅在用户**显式确认**后才会上报至官方云端 MCP 服务（`https://mcp.aitaxs.top`，HTTPS）。未确认时反馈仅记录于本机 `feedback_log.jsonl`，**不会上报**。上报字段含 `type` / `question` / `expected_answer` / `confidence` / `source` / 客户端标识；不采集设备指纹。请勿以「后台静默」「对用户不可见」方式上报——该行为与代码中的 `user_confirmed` 确认门相悖，属未披露数据外送，已被审核整改禁用。详见随包 `SECURITY.md`。

### 6.1 `type` 类型枚举

| 类型 | 场景 |
|------|------|
| `correction` | 答案错误 / 政策过期 / 数据不对 |
| `knowledge_missing` | 知识库缺失 / 工具未找到答案 / Web 搜索兜底 |
| `question` | 用户追问 / 场景不清晰 |
| `improvement` | 改进建议 / 功能诉求 |
| `bug` | 工具报错 / 超时 / 异常 |
| `general` | 其他反馈（兜底） |

### 6.2 `confidence` 取值标准

| 区间 | 场景 |
|------|------|
| 90–100 | 有政策原文/官方文件依据的更正 |
| 70–90 | 有权威链接、多篇案例佐证 |
| 60–75 | Web 搜索兜底场景（LLM 自行补齐，来源权威性中等） |
| 50–70 | 依据专业经验判断，无官方证据 |
| 30–50 | 模糊判断/推测性建议 |
| 0–30 | 用户随口一说，无明确依据 |

---

**更新时间**：2026-10-17
**版本**：v2.0.0（精简版，移除内部路由细节）

---

## 附录. 章节标题别名（供 policy-updates.md 等引用）

> policy-updates.md 等文件引用本文件时使用以下别名，对应关系如下：

| 别名（引用标题）| 对应章节 |
|--------------|---------|
| `知识库分类` | §1.1 `category` 参数枚举 |
| `政策分类枚举` | §1.1 `category` 参数枚举 |
| `风险场景代码枚举` | §2 risk 工具参数 |
| `环保税分类` | §1.1 `category` 参数枚举（含 `surtax`） |
| `计算场景枚举` | §3 `calc` 工具参数 |
| `附录 D` | §5 `policy_basis` 政策依据结构 |
| `消费税分类` | §1.1 `category` 参数枚举（含 `surtax`） |
| `risk 工具扩展` | §2 risk 工具参数 |
| `calc 工具扩展` | §3 `calc` 工具参数 |
| `统一响应 envelope` | §4 统一响应 envelope |
