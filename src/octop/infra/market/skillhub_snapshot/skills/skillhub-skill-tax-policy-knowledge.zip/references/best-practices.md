# 最佳实践指南

> 财税 MCP 服务使用规范、最佳实践与避坑指南。

---

## 1. 工具选择指南

### 1.1 何时使用 ask（政策问答）

**适用场景**：
- 查询税收政策解读（如"留抵退税政策是什么？"）
- 了解特定行业税收优惠（如"高新技术企业税率多少？"）
- 查询政策依据和文号（如"研发费用加计扣除政策依据"）
- 获取合规建议（如"小规模纳税人免征额度是多少？"）

**最佳实践**：
```python
# ✓ 正确：用自然语言提出具体问题（推荐不传 category，服务端自动语义路由）
result = tax_policy_ask(question="留抵退税的适用条件、退免额度与申报流程是什么？")

# ✓ 正确：确需锁定专题时传具体分类
result = tax_policy_ask(question="高新技术企业企业所得税税率是多少？", category="cit")

# tax_policy_ask(question="留抵退税", category="vat")
```

---

### 1.2 何时使用 risk（风险扫描）

**适用场景**：
- 识别企业涉税风险点（如"私户收款风险"）
- 评估业务合规性（如"发票合规性检查"）
- 事前风险预判（如"合同签订前税务风险"）
- 事后风险补救（如"稽查应对建议"）

**最佳实践**：
```python
# ✓ 正确：描述具体场景
result = risk_check(
    scenario="私户大额收款 200 万元无发票对应",
    level_filter="high"
)

# ✓ 正确：多轮扫描（不同场景组合）
result1 = risk_check(scenario="发票金额与实际交易不符")
result2 = risk_check(scenario="关联交易定价不合理")
```

---

### 1.3 何时使用 calc（税费计算）

**适用场景**：
- 计算应纳税额（如"小规模纳税人季度销售额 8 万"）
- 比对不同方案的税负差异
- 季度免征判定（如"季度销售额是否超过 30 万"）
- 多方案税负测算（如"专票 vs 普票"）

**最佳实践**：
```python
# ✓ 正确：小规模纳税人季度判定（入参放在 params 对象内）
result = tax_calculate(tax_type="vat", params={"sales": 80000, "taxpayer_type": "small_scale"})
# 返回：tax_amount=0（免征）

# ✓ 正确：方案对比（一般纳税人开专票 vs 开普票）
result1 = tax_calculate(tax_type="vat", params={"sales": 100000, "taxpayer_type": "general", "is_special_invoice": True})
result2 = tax_calculate(tax_type="vat", params={"sales": 100000, "taxpayer_type": "general", "is_special_invoice": False})

# ✗ 错误：sales/taxpayer_type 不是顶层参数，会抛 TypeError
# tax_calculate(tax_type="vat", params={"sales": 80000, "taxpayer_type": "small_scale"})
```

---

### 1.4 何时使用 kb（知识库检索）

**适用场景**：
- 了解知识库覆盖范围（如"有哪些专题？"）
- 查询特定分类的文件数量
- 检索政策文件索引

**最佳实践**：
```python
# ✓ 正确：获取知识库规模与版本（本工具不接受任何参数）
result = kb_list()
# 返回：{"count": 300, "version": "3.18.32"}

# ✗ 错误：category 不是 kb_list 的参数，传入会被静默忽略
# kb_list(category="database")

# 需要按分类检索政策时，请用 ask 的 category 参数：
# tax_policy_ask(question="...", category="vat")
```

---

## 2. 组合使用策略

### 2.1 完整合规检查流程

```python
# 步骤 1：知识库概览，确认规模与版本
kb = kb_list()
print(f"知识库共 {kb['count']} 个专题文件，版本 {kb['version']}")

# 步骤 2：风险扫描，识别风险点
risk = risk_check(
    scenario="企业季度销售额 80 万，全部为私户收款无发票",
    level_filter="high"
)
print(f"风险等级：{risk['overall_risk']}")

# 步骤 3：税费计算，量化影响（入参放在 params 对象内）
calc = tax_calculate(
    tax_type="vat",
    params={"sales": 800000, "taxpayer_type": "general", "input_tax": 50000}
)
print(f"应纳税额：{calc['tax_amount']}")

# 步骤 4：政策问答，获取应对建议（自然语言 question，可选锁定分类）
policy = tax_policy_ask(
    question="私户收款有哪些合规风险与应对建议？",
    category="compliance"
)
print(f"应对建议：{policy['answer']}")
```

### 2.2 季度申报前自检流程

```python
# 1. 销售额判定（小规模免征额度，入参放在 params 对象内）
sales_check = tax_calculate(
    tax_type="vat",
    params={"sales": quarterly_sales, "taxpayer_type": "small_scale"}
)

# 2. 风险扫描（申报前风险识别）
risk_scan = risk_check(
    scenario="季度申报前风险自查",
    level_filter="medium"
)

# 3. 政策咨询（申报注意事项）
policy_advice = tax_policy_ask(
    question="小规模纳税人季度申报有哪些注意事项？",
    category="vat"
)
```

---

## 3. 常见问题与解决方案

### 3.1 TIMEOUT > 30 秒

**原因**：网络波动或服务端负载高。

**解决方案**：
```python
# 方案 1：重试机制（已内置，无需自行实现）
result = tax_policy_ask(question="留抵退税的适用条件与申报流程是什么？")
# 失败时自动重试 3 次，每次间隔 2s/4s/8s

# 方案 2：降低并发
# 避免同时发起多个高风险扫描请求

# 方案 3：检查网络连接
# 确保 HTTPS 可达 https://mcp.aitaxs.top
```

### 3.2 返回结果为空

**原因**：知识库未覆盖该问题。

**解决方案**：
```python
# 方案 1：改写问题为更具体的自然语言问句
result = tax_policy_ask(question="留抵退税的适用条件、计算方法与申报流程分别是什么？")

# 方案 2：不传 category，让服务端自动语义路由（推荐）
result = tax_policy_ask(question="小规模纳税人免征额是多少？")

# 方案 3：确需锁定专题时传具体分类
result = tax_policy_ask(question="小规模纳税人增值税减免政策有哪些？", category="vat")

# 方案 4：需要分类信息与候选依据时，用 ask_structured 接口
result = ask_structured(question="小规模纳税人增值税减免政策有哪些？", category="vat", top_n=5)
# → answer 与上例一致，另附 tax_types / route_meta / candidates 供 LLM 动态筛选
```

### 3.3 风险扫描结果不符合预期

**原因**：场景描述不够精确。

**解决方案**：
```python
# ✗ 错误：场景描述模糊
result = risk_check(scenario="有风险")

# ✓ 正确：场景描述具体
result = risk_check(
    scenario="2026 年 Q2 季度私户收款 200 万元，对方为自然人，无发票对应，无真实业务背景"
)
```

---

## 4. 安全注意事项

### 4.1 凭证安全

```python
# ✓ 正确：由客户端自动注册并本地缓存
from mcp_client import _ensure_api_key
api_key = _ensure_api_key()

# 注意：密钥一律经 _ensure_api_key() 自动注册，缓存在本地配置中。

# ✗ 错误：硬编码 API Key
api_key = "<YOUR_API_KEY>"  # 禁止！
```

### 4.2 日志脱敏

```python
# ✓ 正确：仅记录 API Key 前缀
import hashlib
key_prefix = api_key[:8] if api_key else "未注册"
print(f"使用 API Key 前缀: {key_prefix}...")

# ✗ 错误：记录完整 API Key
print(f"API Key: {api_key}")  # 禁止！
```

### 4.3 本地数据

```python
# 凭证存储路径（自动创建）
# Windows: %USERPROFILE%\.tax-policy-client\credentials.json
# Unix: ~/.tax-policy-client/credentials.json

# 定期清理过期缓存
import os
cache_dir = os.path.join(os.path.expanduser("~"), ".tax-policy-client", "cache")
# 建议：每季度清理一次过期缓存
```

---

## 5. 性能优化建议

### 5.1 批量查询优化

```python
# ✗ 错误：逐条串行查询，耗时长且占用重试窗口
for q in ["增值税最新政策", "企业所得税最新政策", "个人所得税最新政策"]:
    result = tax_policy_ask(question=q)

# ✓ 正确：批量并发查询（一次提交多个问题，客户端并行调用）
from mcp_client import batch_call
results = batch_call([
    {"tool": "tax_policy_ask", "params": {"question": "增值税最新政策有哪些？"}},
    {"tool": "tax_policy_ask", "params": {"question": "企业所得税最新优惠政策有哪些？"}},
    {"tool": "tax_policy_ask", "params": {"question": "个人所得税专项附加扣除最新标准是多少？"}},
])
```

### 5.2 缓存利用

```python
# 本地知识库文件已缓存，重复查询自动命中缓存
# 缓存路径：~/.tax-policy-client/cache/

# 手动刷新缓存（如需最新政策）
from mcp_client import refresh_knowledge_cache
refresh_knowledge_cache()
```

---

## 6. 版本兼容性

| MCP 版本 | 支持的工具 | 备注 |
|----------|-----------|------|
| v3.18.0+ | ask, risk, calc, kb | 当前版本 |
| v3.15.0+ | ask, risk, calc | kb 工具新增 |
| v3.14.0+ | ask, calc | 风险扫描新增 |

**升级检查**：
```python
from mcp_client import get_server_version
print(f"服务端版本：{get_server_version()}")
```

---

## 7. 调试技巧

### 7.1 开启详细日志

```python
import logging
logging.basicConfig(level=logging.DEBUG)
from mcp_client import tax_policy_ask
# 查看详细请求/响应日志
```

### 7.2 使用 cURL 调试

```bash
# 测试连通性（业务调用必须 POST；HEAD/GET 探测返回 400/409，不能作为可用性判据）
curl --noproxy '*' -sS --max-time 30 -X POST \
  https://mcp.aitaxs.top/api/services/tax-policy-knowledge/mcp \
  -H 'Content-Type: application/json' -H 'Accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"self-check","version":"1.0"}},"id":1}'

# 测试认证（API Key 由客户端自动注册，可在本地配置中查看）
curl -X POST "https://mcp.aitaxs.top/api/services/tax-policy-knowledge/mcp" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <你的 API Key>" \
  -d '{"jsonrpc":"2.0","method":"tools/call","params":{"name":"ask","arguments":{"question":"留抵退税政策有哪些？适用条件与申报流程是什么？"}},"id":1}'
```

### 7.3 本地模式验证

```python
# 本地模式（无网络时）
import os
os.environ["TAX_POLICY_OFFLINE"] = "1"
from mcp_client import tax_policy_ask
# 本地缓存知识库可用，云端工具不可用
```

---

## 8. 常见业务场景速查

| 场景 | 推荐工具 | 示例 |
|------|---------|------|
| 季度申报前自检 | risk + calc | 私户收款风险扫描 |
| 发票合规检查 | risk | 虚开发票特征匹配 |
| 小规模免征判定 | calc | 季度销售额≤30 万 |
| 政策条文查询 | ask | 研发费用加计扣除 |
| 行业税负率分析 | kb + calc | 制造业税负率比对 |
| 合同涉税审核 | ask | 价税分离条款审核 |
| 跨境交易税务 | ask + risk | 转让定价风险 |

---

**更新时间**：2026-09-05
**版本**：v1.0.0

## 9. v2.4.0+ 新增能力使用指南

### 9.1 何时使用 rd_deduction（研发费用加计扣除）

**适用场景：**
- 用户问「研发费用 500 万能加计扣除多少？」
- 用户问「研发投入 1000 万节税多少？」
- 用户问「高新技术企业研发加计扣除政策是什么？」
- 申报季自查研发加计扣除

**不适用：**
- 用户只问研发费用会计处理（用 ask 工具）
- 用户问研发加计扣除政策原文（用 ask 工具）

**调用模板：**
```python
# 步骤 1：识别企业类型
# 用户问句中提取"高新技术企业"/"集成电路"/"一般企业"等关键词
# 默认按一般企业处理

# 步骤 2：调用 calc
result = calc("rd_deduction", {
    "rd_expense": 5000000,           # 研发费用（元）
    "is_high_tech": False,            # 一般企业 False，高新 True
    "is_negative_industry": False,    # 负面清单行业 True
    "rd_extra_rate": 0.0,             # 集成电路/工业母机 0.2
})

# 步骤 3：解读结果
# rd_total_super_deduction：加计扣除金额
# rd_tax_saving：实际节税金额
```

**关键避坑：**
- ❌ 错误：rd_expense 单位传错（"500万" 应为 5000000）
- ❌ 错误：未识别"集成电路"关键词，错过 120% 加计
- ❌ 错误：未识别"负面清单"行业（烟草/住宿/批发/房地产等）
- ✅ 正确：先 ask 政策原文，再 calc 计算

### 9.2 何时使用 risk 工具的"开放问题"模式

**触发词识别：**
- 开放问题：「有什么风险？」「有哪些」「全部」「所有」「罗列」
- 子特征：「1元转让」「关联」「跨境」「印花税」「个税」

**调用模板：**
```python
# 开放问题：自动返回所有匹配情形
risk("我们公司股权转让有什么风险")
# → scenarios: ["equity_transfer"], 10 项风险点全量

# 子特征 + 开放问题：全量 + 子特征高亮
risk("1元转让股权有什么风险", level="high")
# → scenarios: ["equity_transfer"], 10 项 + matched_trigger=["ET-01_low_price"]
```

### 9.3 完整工作流（ask + risk + calc 组合）

**场景：用户问"研发费用 500 万，能加计扣除多少？"**

```python
# 第 1 步：ask 获取政策原文（不传 category，由服务端自动路由到研发费用专题）
policy = ask("研发费用加计扣除的比例是多少？适用条件与负面清单行业有哪些？")
# → 财税 2023 年第 7 号、44 号文要点

# 第 2 步：risk 识别研发相关风险
risks = risk("研发费用加计扣除申报风险")
# → RD-01 资料不全 / RD-02 负面清单误用 / RD-03 研发人员界定争议

# 第 3 步：calc 计算加计扣除
calc_result = calc("rd_deduction", {"rd_expense": 5000000})
# → 加计 500 万，节税 125 万

# 第 4 步：综合输出
return {
    "policy_basis": policy["answer"],
    "risk_indicators": risks["risks"],
    "rd_calculation": calc_result
}
```

### 9.4 MCP 工具调用无输出兜底

**问题症状：**
- 调用 risk/calc 后返回空字符串或超时
- 客户端 thinking 块显示"工具调用无输出"

**根本原因（v2.4.0 之前）：**
- 后端 streamable-HTTP 流被截断（30s 超时）
- JSON-RPC envelope 解析失败
- 异常被 catch 后未回填

**v2.4.0+ 解决：**
- 所有工具统一返回 envelope（status/data/error/elapsed_ms/hint）
- 客户端见 `status=empty` 即知"后端无响应"，可走本地知识库兜底

**客户端适配代码：**
```python
def safe_call_mcp(tool, args):
    try:
        resp = call_mcp(tool, args)
        if resp["status"] == "ok":
            return resp["data"]
        elif resp["status"] == "empty":
            # 后端无响应，走本地知识库
            return local_kb_lookup(tool, args)
        else:
            # error/exception，记录日志
            logger.error(f"{tool} failed: {resp['error']}")
            return safe_default(tool, args)
    except Exception as e:
        logger.exception(e)
        return safe_default(tool, args)
```

---

## 10. references 三件套交叉引用

> 三件套之间的定位映射与读取规则统一登记在 `agent-read-path.md`「四、触发条件 → 必读位置」，本节不再重复登记。

## 附录 C · v2.5.0 wiki 高效检索使用指南

### C.1 一次调用拿到「结果 + 政策依据」

risk_check 与 tax_calculate 的结果自带 `policy_basis`（主题 + 章节 + 原文摘录），
客户端**无需再发一次 ask** 才能给出应对依据。

### C.2 推荐组合调用顺序

1. **风险初筛** `risk` → 得到 `overall_risk`、`risks`、`policy_basis`
2. **需要展开条款** → 用 `policy_basis[].topic` + `section` 精确追问 `ask`（命中率远高于自由关键词）
3. **需要金额** → `calc` 测算，结果同样带 `policy_basis`
4. **税务合规体检闭环** → risk → calc → 生成报告

### C.3 性能收益（40 问基准实测）

| 指标 | wiki 关闭 | wiki 开启 | 变化 |
|------|----------|----------|------|
| 单问扫描段数均值 | 166 | 148 | **-10.3%** |
| 答案非空率 | 40/40 | 40/40 | 持平 |
| 有效回答率 | 40/40 | 40/40 | 持平 |
| 全库回退 | 0 | 0 | 持平 |

章节级检索替代「每文件前 80 段全扫」，大文件不再因截断漏答。

### C.4 降级行为（安全兜底）

- wiki 引擎缺失、解析失败、被 `/reload` 重置未重建时：`policy_basis = []`、
  `wiki_enhanced = false`，**主计算结果与风险结论完全不受影响**。
- ask 侧 wiki 关闭时自动回退原逻辑，扫描段数与答案质量不劣化（A/B 基准已固化）。

### C.5 0 命中判读提醒

`overall_risk = 低风险` 仅代表未触发显性关键词与结构化情形，
**不代表无风险**。遇到「公司想了解一下税务健康管理」这类开放问句，
应据 `suggestion` 中的研判线索逐项人工核查，或引导用户补充具体业务细节后重查。

## 附录 E · 速算与实战示例

> 本附录承接 SKILL.md 中原「v2.4.0 / v2.5.0 新能力快速指引」章节的具体技术细节；
> 速算表与实战示例统一在本节查阅，入口见 `agent-read-path.md`「附录 E」映射行。

### E.1 研发费用加计扣除速算（500 万研发费用示例）

| 企业类型 | 加计扣除金额 | 适用税率 | 节税金额 |
|---------|------------|---------|---------|
| 一般企业 | 500 万 | 25% | **125 万** |
| 高新技术企业 | 500 万 | 15% | **75 万** |
| 集成电路 / 工业母机 | 600 万 | 25% | **150 万** |
| 小型微利（应税所得 200 万）| 500 万 | 5% | **25 万** |
| 负面清单行业 | 0 | — | 0 |

### E.2 实战示例：研发费用 500 万加计扣除多少

> 用户问「研发费用 500 万能加计扣除多少？」

先取政策原文 → 再做申报风险初筛 → 最后按 `rd_deduction` 税种参数传入研发费用金额
（单位元）取节税金额；具体参数枚举见 `field-types.md`§3（`calc` 工具参数）。

### E.3 实战示例：股权转让有什么风险

> 用户问「我们公司股权转让有什么风险？」

| 步骤 | 结果 |
|------|------|
| 风险初筛 | `overall_risk=高风险`、`total=10`（结构化情形识别引擎自动展开 10 项风险点）|
| 政策依据 | `policy_basis` 直接返回 `equity_transfer`「1.1 自然人股权转让个税核心规则」等章节原文 |
| 节税测算 | 股权转让所得按财产转让 20% 税率，测算结果同样附政策依据 |

一次风险初筛即得「风险点 + 政策依据」，再用 `policy_basis[].topic` 精确追问政策原文，
无需关键词猜测；字段结构见 `field-types.md` 附录 D。
