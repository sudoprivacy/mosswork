"""财税政策 MCP 薄客户端（安全收敛版 · v4.0.0）

安全设计要点（与云端服务硬化后的安全工具面严格对齐）：
- 仅暴露云端已开放的安全工具：tax_policy_ask / risk_check / tax_calculate / kb_list / rd_template / route_query / wiki_route。
- 已彻底移除所有被服务端下线或移出白名单的危险运维端点对应的客户端函数，避免内部接口设计暴露。
- 本地数据目录通用化：改用跨平台用户数据目录（~/.tax-policy-client），
  便于其它 Agent / 通用 Python 环境直接复用本客户端。
- 注册时在本地生成随机匿名 device_id 并发送至云端 MCP 服务（用于服务调用鉴权），不采集任何主机指纹（MAC/序列号等）；API Key 仅记前缀、不落明细日志。完整安全与数据合规说明见随包 SECURITY.md（英文）。
- 全程标准库实现，不禁用 TLS 校验，不做 eval/exec/动态导入。
"""
import json
import os
import re
import time
import threading
import urllib.request
import urllib.error
import urllib.parse
import hashlib
import random
import uuid
from collections import OrderedDict


# ============================================================
# 初始化时自动识别 Agent 类型并决策接入方式（探测+日志，默认不写盘）
# 由 config/init_agent.py 提供；导入失败时静默跳过，不影响客户端主流程。
# ============================================================
def _maybe_init_agent():
    try:
        import sys as _sys
        _sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        try:
            from init_agent import detect_and_setup as _detect_and_setup
        except ImportError:
            from .init_agent import detect_and_setup as _detect_and_setup
        # 客户端导入阶段仅探测+日志；写盘需显式 auto_setup(dry_run=False) 或 TAX_ENABLE_AUTOSETUP=1
        _detect_and_setup(dry_run=True)
    except Exception:
        pass


_maybe_init_agent()

# 本地数据目录（通用、跨平台、非品牌专属）：~/.tax-policy-client/{config,cache,logs}
_DATA_ROOT = os.path.join(os.path.expanduser("~"), ".tax-policy-client")
_CONFIG_DIR = os.path.join(_DATA_ROOT, "config")
_CACHE_DIR = os.path.join(_DATA_ROOT, "cache")
_LOG_DIR = os.path.join(_DATA_ROOT, "logs")
_CONFIG_FILE = os.path.join(_CONFIG_DIR, "tax-policy-mcp.json")
_FEEDBACK_QUEUE_FILE = os.path.join(_CACHE_DIR, "feedback_queue.jsonl")
_LAST_VERSION_FILE = os.path.join(_CACHE_DIR, "last_version.json")
_HEALTH_FILE = os.path.join(_CACHE_DIR, "health_cache.json")

# Remote MCP service endpoints (standard MCP over HTTPS).
# SECURITY: This client sends user questions, risk-scenario descriptors (including
# business amounts and structure), and calculation parameters to these endpoints.
# No system fingerprint is collected; a locally-generated anonymous device-id is used
# for service-auth only. Full security & compliance disclosure: see SECURITY.md.
_DEFAULT_SERVICE_URL = "https://mcp.aitaxs.top/api/services/tax-policy-knowledge/mcp"

# API Key 自动注册端点（官方服务端）：可用 TAX_POLICY_REGISTER_URL 覆盖，覆盖值仍须
# 通过下方官方域名白名单校验；详见 SECURITY.md「API Key registration」。
_DEFAULT_REGISTER_URL = "https://mcp.aitaxs.top/api/auth/register"
_ALLOWED_REGISTER_HOST_SUFFIXES = (".aitaxs.top",)
_DEFAULT_API_BASE = "https://mcp.aitaxs.top/api/services/tax-policy-knowledge"

# JSON-RPC ID 计数器
_rpc_id = 0

# 降级超时设置
_MCPCHECK_TIMEOUT = 5
_FALLBACK_PROBE_INTERVAL = 30

# ============================================================
# 客户端身份（注入 X-Client-Id，供服务端按客户端归因与限流）
# ============================================================
_DEFAULT_CLIENT_VERSION = "3.18.94"

def _read_skill_version():
    """读取本技能 SKILL.md frontmatter 的 version，作为客户端上报版本。

    此前 _CLIENT_VERSION 在三处硬编码并存（3.18.25 / 3.18.27 / 3.18.30），与各技能
    SKILL.md 声明版本脱节、随升版必然再次漂移。改为按技能自身声明动态获取；
    SKILL.md 缺失、无 frontmatter 或无 version 键时回退 _DEFAULT_CLIENT_VERSION，
    绝不抛异常（不影响任何远程调用）。
    """
    try:
        skill_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(skill_root, "SKILL.md")
        if not os.path.isfile(path):
            return _DEFAULT_CLIENT_VERSION
        front = []
        with open(path, encoding="utf-8", errors="ignore") as f:
            for i, raw in enumerate(f):
                head = raw.lstrip()
                # 本仓库已知污染签名：SKILL.md 首行 frontmatter 分隔符被反斜杠污染
                if head[:1] == chr(92):
                    head = head[1:].lstrip()
                if i == 0 and not head.startswith("---"):
                    return _DEFAULT_CLIENT_VERSION  # 无 frontmatter
                if i > 0 and head == "---":
                    break
                front.append(raw)
        for raw in front:
            line = raw.strip()
            if line.startswith("version:"):
                val = line.split(":", 1)[1].strip()
                if len(val) >= 2 and val[0] == val[-1] and val[0] in ["'", '"']:
                    val = val[1:-1].strip()
                if val:
                    return val
    except Exception:
        pass
    return _DEFAULT_CLIENT_VERSION


_CLIENT_VERSION = _read_skill_version()

# 技能根目录名即技能身份：注入 X-Client-Id 供服务端按客户端归因与限流，
# 并被 _get_meta() 作为 skill 标识的硬兜底。此前为硬编码字面量，
# 有 4 个技能因模板复制而与自身 slug 不符（归因错记到别的技能名下）。
_CLIENT_ID = os.path.basename(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ============================================================
# 动态 _META：从运行时环境获取真实的 app/skill 标识
#
# 【通用设计】支持所有 Agent 平台和调用渠道，零品牌依赖。
# 调用方可通过环境变量注入自己的平台/技能标识，无需修改本模块。
#
# ── app 取数优先级（从高到低）──────────────────────────────
#   1. TAX_APP_NAME          显式注入（最优先，供任何渠道使用）
#   2. WORKBUDDY_PRODUCT_NAME  WorkBuddy Desktop 运行时
#   3. CODEBUDDY_AGENT_NAME   CodeBuddy Desktop 运行时
#   4. AGENT_NAME             通用 Agent 平台（如 Azure AI Agent）
#   5. RUNNER_NAME            通用 Runner（如 GitHub Actions）
#   6. CLIENT_NAME / APP_NAME  通用客户端名
#   7. CLAUDE_DESKTOP_CONVERSATION_ID → "ClaudeDesktop"
#   8. CURSOR_SESSION_ID      → "Cursor"
#   9. CLINE_SESSION_ID       → "Cline"
#  10. 兜底                    → "GenericAgent"（非 WorkBuddy 品牌）
#
# ── skill 取数优先级（从高到低）────────────────────────────
#   1. TAX_SKILL_NAME         显式注入（最优先）
#   2. TAX_SKILL              旧环境变量兼容
#   3. WORKBUDDY_SKILL_NAME   WorkBuddy 技能名
#   4. CODEBUDDY_SKILL_NAME   CodeBuddy 技能名
#   5. 从 CODEBUDDY_AGENT_NAME / AGENT_NAME / RUNNER_NAME 动态推导
#      （空格转横线，全小写，前缀 "tax-"，如 "Tax Expert" → "tax-tax-expert"）
#   6. 兜底                    → _CLIENT_ID
#
# 零协议侵入：所有来源均无值时 app="GenericAgent"，skill=_CLIENT_ID，
#            服务端按这两个值处理，不报异常，不影响业务流程。
# ============================================================

def _get_meta():
    """动态构建 _meta，兼容所有 Agent 平台和调用渠道。"""
    # --- app 取数 ---
    app = (
        os.environ.get("TAX_APP_NAME")
        or os.environ.get("WORKBUDDY_PRODUCT_NAME")
        or os.environ.get("CODEBUDDY_AGENT_NAME")
        or os.environ.get("AGENT_NAME")
        or os.environ.get("RUNNER_NAME")
        or os.environ.get("CLIENT_NAME")
        or os.environ.get("APP_NAME")
        or ("ClaudeDesktop" if "CLAUDE_DESKTOP_CONVERSATION_ID" in os.environ else None)
        or ("Cursor" if "CURSOR_SESSION_ID" in os.environ else None)
        or ("Cline" if os.environ.get("CLINE_SESSION_ID") else None)
        or "GenericAgent"
    )
    # --- skill 取数（独立回退，互不干扰）---
    # 优先级 1：显式注入的环境变量
    skill = os.environ.get("TAX_SKILL_NAME") or os.environ.get("TAX_SKILL")
    # 优先级 2：平台技能名
    if not skill:
        skill = os.environ.get("WORKBUDDY_SKILL_NAME") or os.environ.get("CODEBUDDY_SKILL_NAME")
    # 优先级 3：从 Agent 名称动态推导（空格→横线，全小写，tax-前缀）
    if not skill:
        for name_var in ("CODEBUDDY_AGENT_NAME", "AGENT_NAME", "RUNNER_NAME"):
            name = os.environ.get(name_var)
            if name:
                skill = "tax-" + name.lower().replace(" ", "-")
                break
    # 优先级 4：config 文件 skill_name（由安装器写入，WorkBuddy 场景的回退）
    if not skill and os.path.exists(_CONFIG_FILE):
        try:
            with open(_CONFIG_FILE, encoding="utf-8") as f:
                cfg = json.load(f)
            skill = cfg.get("skill_name") or None
        except Exception:
            pass
    # 优先级 5：_CLIENT_ID 硬兜底
    if not skill:
        skill = _CLIENT_ID
    return {"app": app, "skill": skill}

# 429 退避：最多重试次数 + 单次退避上限（秒），防止被长窗口拖死
_MAX_429_RETRIES = 2
_RATE_RETRY_CAP = 10

# 工具超时（与云端安全工具对齐；仅保留开放工具）
# [dalign 2026-09-27] 补齐 route_query(3s)/wiki_route(3s)/rd_template(15s)，
# 与服务端 TOOLS_CATALOG timeout_s 逐值一致（此前缺失时 fallback 30s，
# 与服务端目录漂移；服务端目录可达时仍优先取 catalog 值）。
_TOOL_TIMEOUT_FALLBACK = {
    # ★2026-10-08 冷启动友好：aliases（旧名）+ 短名并存，服务端两种形式都能识别；
    # 计算密集工具冷启动 > 30s（openpyxl load / wiki policy_basis 索引首次加载），
    # 客户端 timeout = fallback + buffer（buffer 见 _tool_timeout 分类）。
    "tax_policy_ask": 60,
    "risk_check": 5,
    "tax_calculate": 60,
    "kb_list": 5,
    "route_query": 3,
    "wiki_route": 3,
    "rd_template": 120,
    "prompt_guide": 3,
    # 短名（客户端实际调用形式，与服务端 fastmcp 白名单对齐）
    "ask": 60,
    "calc": 60,
    "risk": 5,
    "kb": 5,
}


def _base_headers(api_key: str = None) -> dict:
    h = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
        "User-Agent": f"tax-policy-client/{_CLIENT_VERSION}",
        "X-Client-Id": _CLIENT_ID,
        "X-Client-Version": _CLIENT_VERSION,
        "X-App-Name": _get_meta()["app"],
        "X-Skill-Name": _get_meta()["skill"],
    }
    if api_key:
        h["Authorization"] = f"Bearer {api_key}"
    return h


def _parse_retry_after(headers) -> int:
    try:
        ra = headers.get("Retry-After") if headers else None
        if ra is not None:
            return max(1, int(str(ra).strip()))
    except Exception:
        pass
    return 5


# 工具目录缓存（由 kb_list 填充，供 per-tool 超时与兼容检查）
_tools_catalog = None


def _tool_timeout(name: str) -> int:
    cat = _tools_catalog or {}
    t = cat.get(name, {}).get("timeout_s") if isinstance(cat, dict) else None
    if not t:
        t = _TOOL_TIMEOUT_FALLBACK.get(name, 30)
    # ★2026-10-08 冷启动友好★ 计算密集工具冷启动 > 30s（openpyxl load / wiki 索引加载），
    # 统一 buffer 需按工具分类：calc/rd_template/ask/prompt_guide +30s，其他 +10s。
    # ★2026-11-01 服务端重启后实测：kb（568 文档元数据 + 归因记录）耗时约 13.9s，
    # 原 15s 上限过于紧绷（抖动即超时），故把 kb/kb_catalog 并入 +30s 组（→35s）。
    if name in {"calc", "rd_template", "ask", "prompt_guide", "kb", "kb_catalog"}:
        return int(t) + 30
    return int(t) + 10


def _mcp_tools_list(api_key: str = None, service_url: str = None) -> dict:
    """MCP 标准 tools/list（工具目录的权威来源）。

    [authfix 2026-11-03] 原 get_tools_catalog 走 `kb` 工具取目录，但生产 kb 只返回
    知识库概览、不含 tools 字段，导致目录恒空、dzswj_tools_available 永远报"未知"。
    tools/list 才是目录的权威来源，故独立成函数。
    """
    global _rpc_id
    if service_url is None:
        service_url = _DEFAULT_SERVICE_URL
    _rpc_id += 1
    payload = json.dumps({
        "jsonrpc": "2.0", "id": _rpc_id, "method": "tools/list", "params": {},
        "_meta": _get_meta(),
    }).encode()
    try:
        req = urllib.request.Request(service_url, data=payload, headers=_base_headers(api_key))
        resp = urllib.request.urlopen(req, timeout=_MCPCHECK_TIMEOUT)
        result = json.loads(resp.read())
        return result.get("result", result) if isinstance(result, dict) else {}
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return _friendly_error("api_key_invalid")
        return _friendly_error("http_error", {"http_code": e.code})
    except Exception:
        return {}


def get_tools_catalog() -> dict:
    """返回服务端工具目录（含 timeout_s），按需拉取并缓存"""
    global _tools_catalog
    if _tools_catalog is None:
        try:
            cfg = _load_config()
            res = _mcp_tools_list(cfg.get("api_key"), cfg.get("service_url", _DEFAULT_SERVICE_URL))
            tools = res.get("tools") if isinstance(res, dict) else None
            if not tools:
                # [authfix 2026-11-03] 缓存 key 失效（401）时退化为无 key 重试一次，
                # 保证目录探测与 dzswj_tools_available 自查口径真实。
                res = _mcp_tools_list(None, cfg.get("service_url", _DEFAULT_SERVICE_URL))
                tools = res.get("tools") if isinstance(res, dict) else None
            if tools:
                _tools_catalog = {t["name"]: t for t in tools
                                  if isinstance(t, dict) and t.get("name")}
        except Exception:
            pass
    return _tools_catalog or {}


# ============================================================
# LLM优化：缓存管理
# ============================================================
# [cachefix 2026-09-27] 必须用 OrderedDict：_cache_get 依赖 move_to_end() 做
# LRU 置顶。原为普通 {} 时任何缓存命中都抛 AttributeError（生产上每轮问答新
# 进程、缓存永不命中而未暴露）。_cache_set 的 popitem(last=False) 在两种类型
# 下语义均为「淘汰最早插入项」，不受影响。
_result_cache = OrderedDict()
_CACHE_TTL = 300  # 5分钟


def _cache_get(key: str):
    if key in _result_cache:
        cached = _result_cache[key]
        if time.time() - cached["ts"] < _CACHE_TTL:
            _result_cache.move_to_end(key)
            return cached["result"]
        else:
            del _result_cache[key]
    return None


def _cache_set(key: str, result: dict):
    if len(_result_cache) >= 100:
        _result_cache.popitem(last=False)
    _result_cache[key] = {"ts": time.time(), "result": result}


def _cache_clear():
    global _result_cache
    _result_cache = OrderedDict()

_health_state = {
    "mode": "unknown",
    "last_check_time": 0,
    "consecutive_failures": 0,
    "last_probe_time": 0,
    "fallback_count": 0,
}


def _load_health_state():
    global _health_state
    if os.path.exists(_HEALTH_FILE):
        try:
            with open(_HEALTH_FILE, encoding="utf-8") as f:
                saved = json.load(f)
                _health_state.update(saved)
        except Exception:
            pass
    return _health_state


def _save_health_state():
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        with open(_HEALTH_FILE, "w", encoding="utf-8") as f:
            json.dump(_health_state, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _get_current_mode():
    now = time.time()
    current = _health_state["mode"]
    if current == "unknown":
        current = "remote"
    if current == "fallback" and _health_state["consecutive_failures"] > 0:
        if now - _health_state["last_probe_time"] >= _FALLBACK_PROBE_INTERVAL:
            _health_state["mode"] = "probe"
            _health_state["last_probe_time"] = now
            _save_health_state()
            return "probe"
        return "fallback"
    if current == "probe":
        return "probe"
    return "remote"


# ============================================================
# 用户友好错误
# ============================================================
_FRIENDLY_ERRORS = {
    "connection_failed": {
        "message": "无法连接到远程财税服务",
        "suggestion": "已为你返回本地离线指引。请检查网络后重试；若网络正常仍失败，可能是服务临时不可用。",
    },
    "timeout": {
        "message": "远程财税服务响应超时",
        "suggestion": "服务可能较繁忙。已为你返回本地离线指引，建议稍后重试，或把问题拆得更具体一些。",
    },
    "http_error": {
        "message": "远程服务返回了错误（HTTP {code}）",
        "suggestion": "服务可能正在维护或过载。已为你返回本地离线指引，可稍后重试。",
    },
    "api_key_invalid": {
        "message": "服务授权校验未通过（凭证失效或为空）",
        "suggestion": "正在尝试自动重新注册以获取新凭证；若仍失败，请重新启用本技能或联系技术支持。",
    },
    "not_registered": {
        "message": "尚未完成服务注册",
        "suggestion": "系统正在为您自动注册，请稍候再试。",
    },
    "unknown_error": {
        "message": "处理请求时出现意外错误",
        "suggestion": "已为你返回本地离线指引。可重新提问或换一种表述方式；若持续出现，请联系技术支持。",
    },
    "scenario_invalid": {
        "message": "风险场景描述不合法",
        "suggestion": "请使用纯文本描述业务场景（≤2000 字），不要粘贴文件或编码内容。可换一种表述重试。",
    },
    "rate_limited": {
        "message": "请求过于频繁，已被服务端限流",
        "suggestion": "已按服务端建议自动退避重试。若仍受限，请稍候片刻再试，或降低调用频率。",
    },
}


def _friendly_error(error_key: str, raw: dict = None):
    friendly = _FRIENDLY_ERRORS.get(error_key, _FRIENDLY_ERRORS["unknown_error"])
    msg = friendly["message"]
    if raw and isinstance(raw, dict):
        code = raw.get("http_code")
        if code and "{code}" in msg:
            msg = msg.format(code=code)
    # [authfix 2026-11-03] 增加机读 error_code：调用方判 401 自恢复须用字段，
    # 不能依赖用户可见文案子串（文案可本地化/改写，字面量判定会恒假）。
    result = {"error": msg, "suggestion": friendly["suggestion"], "error_code": error_key}
    if raw:
        result["error_detail"] = raw
    return result


# ============================================================
# 配置管理（通用本地目录）
# ============================================================
def _load_config():
    if os.path.exists(_CONFIG_FILE):
        try:
            with open(_CONFIG_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"service_url": _DEFAULT_SERVICE_URL, "api_key": None, "kb_version": None, "last_update_time": None}


def _save_config(config):
    os.makedirs(_CONFIG_DIR, exist_ok=True)
    with open(_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    _harden_config_permissions()


def _harden_config_permissions():
    """收紧含 API Key 的本地配置文件访问权限（仅本用户可读）。

    POSIX：目录 0700 + 文件 0600；Windows：无位权限模型，依赖 NTFS ACL（用户级
    目录默认仅本用户可访问），此处 best-effort，任何失败均静默降级不阻断主流程。
    详见 SECURITY.md「Credential storage」。
    """
    try:
        if os.name == "posix":
            try:
                os.chmod(_CONFIG_DIR, 0o700)
            except OSError:
                pass
            if os.path.exists(_CONFIG_FILE):
                os.chmod(_CONFIG_FILE, 0o600)
    except Exception:
        pass


# ============================================================
# API Key 管理（仅本地随机匿名标识，不采集主机指纹）
# ============================================================
def _validate_register_url(url):
    """注册端点须为 https 且主机属官方白名单，防配置被篡改后外联非官方地址。"""
    u = (url or "").strip()
    if not u.startswith("https://"):
        return False
    host = u.split("://", 1)[1].split("/", 1)[0].split("?", 1)[0].split("#", 1)[0]
    host = host.split("@")[-1].lower()
    if ":" in host:
        host = host.split(":", 1)[0]
    return any(host == s.lstrip(".") or host.endswith(s)
               for s in _ALLOWED_REGISTER_HOST_SUFFIXES)


def _register_url():
    """解析注册端点：环境变量覆盖（须通过官方域名校验）→ 默认官方端点。"""
    env = os.environ.get("TAX_POLICY_REGISTER_URL", "").strip()
    if env and _validate_register_url(env):
        return env
    return _DEFAULT_REGISTER_URL


def _announce_registration(device_id):
    """首次注册前一次性披露外联行为：端点、发送字段、凭据落盘位置。

    仅首次打印（避免每次调用刷屏），并落盘本地日志便于事后核对。
    详见 SECURITY.md「API Key registration」。
    """
    url = _register_url()
    flag = os.path.join(_CONFIG_DIR, ".registration-disclosed")
    first = not os.path.exists(flag)
    msg = (f"[隐私披露] 首次 API Key 注册将向官方端点 {url} 发送本地随机匿名设备标识"
           f"（device_id 前缀 {device_id[:8]}，UUID 随机生成、不含主机指纹），"
           f"凭据仅落盘至本机 {_CONFIG_FILE}（权限已收紧为仅本用户可读）。"
           f"如需关闭自动注册，请设置环境变量 TAX_NO_AUTO_REGISTER=1。")
    _log("registration_disclosure", {"url": url, "device_prefix": device_id[:8],
                                      "store": _CONFIG_FILE, "first": first})
    if first:
        print(msg)
        try:
            os.makedirs(_CONFIG_DIR, exist_ok=True)
            with open(flag, "w", encoding="utf-8") as f:
                f.write(msg)
        except Exception:
            pass


def _register_api_key(user_id=None, device_id=None):
    global _rpc_id
    if not device_id:
        device_id = uuid.uuid4().hex[:16]
    url = _register_url()
    if not _validate_register_url(url):
        _log("registration", {"status": "failed", "reason": "register_url_not_whitelisted"})
        return {"error": "注册端点未通过官方域名校验，已拒绝外联", "api_key": None}
    payload = json.dumps({"name": f"tax-policy-client-{device_id[:8]}", "user_id": user_id or "auto", "device_id": device_id}).encode()
    req = urllib.request.Request(url, data=payload, headers=_base_headers())
    try:
        resp = urllib.request.urlopen(req, timeout=15)
        result = json.loads(resp.read())
        api_key = result.get("api_key")
        if api_key:
            _log("registration", {"status": "success", "key_prefix": result.get("key_prefix", "unknown")})
            return {
                "api_key": api_key,
                "key_id": result.get("key_id"),
                "key_prefix": result.get("key_prefix"),
                "user_id": result.get("user_id", user_id or "auto"),
                "rate_limit": result.get("rate_limit"),
                "daily_limit": result.get("daily_limit"),
            }
        _log("registration", {"status": "failed", "reason": "no_api_key_in_response"})
        return {"error": _FRIENDLY_ERRORS["not_registered"]["message"], "api_key": None}
    except urllib.error.HTTPError as e:
        _log("registration", {"status": "failed", "reason": f"http_{e.code}"})
        return {"error": f"HTTP {e.code}", "api_key": None}
    except urllib.error.URLError:
        _log("registration", {"status": "failed", "reason": "connection_failed"})
        return {"error": "注册服务暂时不可用", "api_key": None}
    except Exception:
        _log("registration", {"status": "failed", "reason": "unknown"})
        return {"error": "注册过程出错", "api_key": None}


def _ensure_api_key(config: dict, force_refresh: bool = False) -> str:
    api_key = config.get("api_key")
    if api_key and not force_refresh:
        return api_key
    if api_key and force_refresh:
        config["api_key"] = None
        config["key_id"] = None
        config["user_id"] = None
        _save_config(config)
    # 显式退出自动注册：不触网、不写盘，交由调用方提示用户手动开启
    if os.environ.get("TAX_NO_AUTO_REGISTER", "").strip().lower() in ("1", "true", "yes"):
        _log("registration", {"status": "skipped", "reason": "TAX_NO_AUTO_REGISTER"})
        return None
    device_id = config.get("device_id") or uuid.uuid4().hex[:16]
    if not config.get("device_id"):
        config["device_id"] = device_id
    _announce_registration(device_id)
    result = _register_api_key(device_id=device_id)
    api_key = result.get("api_key")
    if api_key:
        config["api_key"] = api_key
        config["key_id"] = result.get("key_id")
        config["user_id"] = result.get("user_id")
        config["created_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        _save_config(config)
        return api_key
    _log("registration", {"status": "failed", "error": result.get("error", "unknown")})
    return None


# ============================================================
# 健康检查
# ============================================================
def _quick_health_check(timeout=_MCPCHECK_TIMEOUT) -> dict:
    config = _load_config()
    api_key = config.get("api_key")
    service_url = config.get("service_url", _DEFAULT_SERVICE_URL)
    rpc_payload = json.dumps({"jsonrpc": "2.0", "id": 9999, "method": "tools/list", "params": {}, "_meta": _get_meta()}).encode()
    headers = _base_headers(api_key)
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        req = urllib.request.Request(service_url, data=rpc_payload, headers=headers)
        resp = urllib.request.urlopen(req, timeout=timeout)
        result = json.loads(resp.read())
        if "result" in result and "tools" in result.get("result", {}):
            return {"healthy": True, "tools_count": len(result["result"]["tools"])}
        return {"healthy": False, "reason": "invalid_response"}
    except urllib.error.HTTPError as e:
        if e.code == 401 and api_key:
            return {"healthy": False, "reason": "api_key_invalid", "should_reregister": True}
        return {"healthy": False, "reason": f"http_{e.code}"}
    except urllib.error.URLError:
        return {"healthy": False, "reason": "connection_failed"}
    except Exception:
        return {"healthy": False, "reason": "timeout"}


def _update_mode(healthy: bool):
    global _health_state
    if healthy:
        if _health_state["mode"] != "remote":
            _health_state["mode"] = "remote"
            _health_state["consecutive_failures"] = 0
            _health_state["last_check_time"] = time.time()
            _save_health_state()
    else:
        if _health_state["mode"] != "fallback":
            _health_state["consecutive_failures"] += 1
            if _health_state["consecutive_failures"] >= 1:
                _health_state["mode"] = "fallback"
                _health_state["last_probe_time"] = time.time()
                _health_state["fallback_count"] += 1
                _save_health_state()
        _health_state["last_check_time"] = time.time()


# ============================================================
# MCP调用（仅安全工具：tax_policy_ask / risk_check / tax_calculate / kb_list）
# ============================================================
# [signature-rollout-20261110] 请求签名：每次请求/重试重生成 _ts/_nonce/_sig
# 修复 R05：429 重试不得复用同一 rpc_payload（开启 nonce 去重后会被自己的重试判为重放）
# 算法与服务端 security_hardening.RequestSigner / mcp_server._verify_request_signature 同源。
def _sign_rpc_payload(base, api_key):
    import hashlib as _hl
    import hmac as _hm
    import json as _js
    import time as _t
    import uuid as _u
    d = _js.loads(base.decode('utf-8'))
    d.pop('_sig', None)
    d.pop('_ts', None)
    d.pop('_nonce', None)
    _ts = int(_t.time())
    _nonce = _u.uuid4().hex[:16]
    _pstr = _js.dumps(d.get('params', {}), sort_keys=True, ensure_ascii=False)
    _key = _hm.new((api_key or '').encode('utf-8'), b'taxsig-v1', _hl.sha256).digest()
    _sig = _hm.new(_key, ('%s%s%s%s' % (_ts, _nonce, 'tools/call', _pstr)).encode('utf-8'),
                   _hl.sha256).hexdigest()
    d['_sig'], d['_ts'], d['_nonce'] = _sig, _ts, _nonce
    return _js.dumps(d, ensure_ascii=False).encode('utf-8')


def _call_mcp_tool(tool_name: str, params: dict, api_key: str = None, service_url: str = None, _retry: bool = True):
    """调用 MCP 工具。服务端仅认完整tool名，不使用短名映射。"""
    global _rpc_id
    _rpc_id += 1

    if service_url is None:
        service_url = _DEFAULT_SERVICE_URL

    # [mcp-authfix 2026-11-01] 服务端重启后暴露根因：把 api_key 注入
    # arguments 会使服务端鉴权路径挂起（实测 >45s 无响应），而仅 header
    # Authorization: Bearer 鉴权正常（kb 2.9s / ask 8.8s 实测）。
    # 故统一走 header-only 鉴权，不再向 arguments 注入 api_key。
    # （_base_headers 已自动附带 Authorization: Bearer <api_key>）

    rpc_payload = json.dumps({
        "jsonrpc": "2.0",
        "id": _rpc_id,
        "method": "tools/call",
        "params": {"name": tool_name, "arguments": params},
        "_meta": _get_meta(),
    }).encode()

    headers = _base_headers(api_key)
    timeout = _tool_timeout(tool_name)

    for _attempt in range(1 + _MAX_429_RETRIES):
        rpc_payload = _sign_rpc_payload(rpc_payload, api_key)  # [signature-rollout-20261110] 每次重试重签
        try:
            req = urllib.request.Request(service_url, data=rpc_payload, headers=headers)
            resp = urllib.request.urlopen(req, timeout=timeout)
            result = json.loads(resp.read())
            r = result.get("result", result)
            content_list = r.get("content", [])
            for item in content_list:
                if item.get("type") == "text":
                    text = item.get("text", "")
                    if "API Key" in text and _retry:
                        return _friendly_error("api_key_invalid")
                    if text.startswith("错误:") or text.startswith("❌"):
                        return _friendly_error("server_error", {"message": text[:200]})

            structured = r.get("structuredContent", {})
            if structured and isinstance(structured, dict):
                for key, value in structured.items():
                    if isinstance(value, str) and len(value) > 1500:
                        structured[key] = value[:1500] + f"\n\n... (内容已截断，共{len(value)}字符)"
                    if isinstance(value, list) and len(value) > 30:
                        structured[key] = value[:30]
                        structured[f"{key}_more"] = f"... 还有{len(value) - 30}条"
                return structured

            for item in content_list:
                if item.get("type") == "text":
                    text = item.get("text", "")
                    try:
                        parsed = json.loads(text)
                        if isinstance(parsed, dict):
                            return parsed
                    except (json.JSONDecodeError, TypeError):
                        pass
            return r
        except urllib.error.HTTPError as e:
            if e.code == 401 and _retry:
                return _friendly_error("api_key_invalid")
            if e.code == 429:
                ra = _parse_retry_after(e.headers)
                if _attempt < _MAX_429_RETRIES:
                    time.sleep(min(ra, _RATE_RETRY_CAP))
                    continue
                return _friendly_error("rate_limited", {"retry_after": ra, "http_code": 429})
            detail = e.read().decode("utf-8", errors="replace")[:200]
            return _friendly_error("http_error", {"http_code": e.code, "raw": detail})
        except urllib.error.URLError as e:
            reason = getattr(e, "reason", None)
            if isinstance(reason, TimeoutError) or (isinstance(reason, str) and "timed out" in reason.lower()):
                return _friendly_error("timeout")
            return _friendly_error("connection_failed")
        except Exception:
            return _friendly_error("unknown_error")
    return _friendly_error("unknown_error")


def batch_call(calls: list, api_key: str = None, service_url: str = None):
    """批量MCP调用（安全工具范围内并行执行）"""
    results = []

    def call_one(call):
        tool_name = call.get("tool")
        params = call.get("params", {})
        result = _call_mcp_tool(tool_name, params, api_key, service_url)
        results.append(result)

    threads = []
    for call in calls:
        t = threading.Thread(target=call_one, args=(call,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join(timeout=60)

    return results

# ============================================================
# 本地回退静态指引（不发起任何第三方搜索请求）
# ============================================================
# 云端服务不可达时的兜底：仅返回静态离线指引，提示用户侧 Agent 自行检索
# 权威来源（税务总局 / 省级税务局 / 财政部官网），客户端本身不做任何检索。
# 设计依据详见 SECURITY.md §7（本地搜索已彻底移除，断网=静态指引而非搜索）。
_LOCAL_SEARCH_GUIDANCE = (
    "当前云端财税服务暂不可用，本客户端未发起任何第三方搜索请求。"
    "请由您侧智能体（Agent）自行检索权威来源获取最新政策："
    "国家税务总局官网 https://www.chinatax.gov.cn 、对应省级税务局官网、"
    "财政部官网 https://www.mof.gov.cn ；或在云端服务恢复后重新提问，"
    "即可获得精准政策依据与专业分析。"
)


def _generate_local_answer(question: str, category: str = None) -> dict:
    """本地回退问答：不检索、不渲染第三方结果，仅返回静态离线指引。

    客户端在云端不可达时走此路径：不外传查询文本到任何第三方搜索引擎，
    只把静态指引交还给用户侧 Agent，由其自行检索权威来源。
    """
    _body = (
        "## 关于「" + question + "」\n\n"
        "⚠️ 当前**云端财税服务暂不可用**，本客户端未发起任何第三方搜索请求。\n\n"
        "> 📌 **指引**：请由您侧智能体（Agent）自行检索权威来源获取最新政策；"
        "云端服务恢复后再提问即可获得精准政策依据与专业分析。"
    )
    return {
        "source": "guidance_only",
        "status": "service_unavailable",
        "question": question,
        "message": _LOCAL_SEARCH_GUIDANCE,
        "result": _body,
        "search_query": question,
        "result_count": 0,
    }


# ============================================================
# 对外安全接口（仅 4 个云端安全工具 + 本地兜底）
# ============================================================
def tax_policy_ask(question: str = "", category: str = None, topic: str = "", keyword: str = "") -> dict:
    """政策问答（含风险应对政策依据）——topic/keyword 供服务端原始格式调用"""
    # 内部合并：topic+keyword 合成 question（方案C，兼容旧调用方）
    _question = question
    if not _question and (topic or keyword):
        _question = f"{topic}: {keyword}" if (topic and keyword) else (topic or keyword)
    if not _question:
        return _friendly_error("question_required", {"error_code": "QuestionRequired"})
    _load_health_state()
    mode = _get_current_mode()
    # Fallback 模式直接短路，不等待网络注册超时
    if mode == "fallback":
        return _generate_local_answer(_question, category)
    if mode == "probe":
        health = _quick_health_check()
        if health.get("healthy"):
            _update_mode(True)
        elif health.get("should_reregister"):
            _update_mode(False)
            config = _load_config()
            _ensure_api_key(config, force_refresh=True)
        else:
            _update_mode(False)

    cache_key = f"ask:{_question}:{category}"
    cached = _cache_get(cache_key)
    if cached:
        return cached

    result = _do_remote_policy_ask(_question, category)
    _cache_set(cache_key, result)
    return result


def _do_remote_policy_ask(question: str, category: str = None, _retry_count: int = 0,
                          fmt: str = "", top_n: int = 5) -> dict:
    config = _load_config()
    service_url = config.get("service_url", _DEFAULT_SERVICE_URL)
    api_key = _ensure_api_key(config)
    if not api_key:
        _log("policy_ask", {"question": question, "status": "no_api_key", "mode": "local"})
        return _generate_local_answer(question, category)
    params = {"question": question}
    if category:
        params["category"] = category
    # [askstruct 2026-09-27] 结构化响应透传：服务端缺省即旧行为，零回归
    if fmt:
        params["format"] = fmt
        params["top_n"] = top_n
    # 远程已统一用短名，tax_policy_ask → ask
    result = _call_mcp_tool("ask", params, api_key, service_url)
    # [authfix 2026-11-03] 401 自恢复判定改为机读 error_code 优先（原判 "api_key"
    # 子串因友好文案「服务授权校验未通过（凭证失效或为空）」不含该字面量而恒 False，
    # 导致 force_refresh 重注册分支成死代码、失效 key 永不自愈）。保留旧子串判定作兜底。
    if result.get("error_code") == "api_key_invalid" or (
            "error" in result and "api_key" in str(result.get("error", "")).lower()):
        if _retry_count < 1:
            api_key = _ensure_api_key(config, force_refresh=True)
            if api_key:
                return _do_remote_policy_ask(question, category, _retry_count=_retry_count + 1,
                                             fmt=fmt, top_n=top_n)
        _log("policy_ask", {"question": question, "status": "api_key_invalid", "mode": "local"})
        return _generate_local_answer(question, category)
    if "error" not in result:
        _log("policy_ask", {"question": question, "status": "ok", "format": fmt or None})
        _maybe_auto_feedback("ask", params, result)
    else:
        _log("policy_ask", {"question": question, "status": "error", "detail": result.get("error")})
        if _get_current_mode() in ["fallback", "probe"]:
            return _generate_local_answer(question, category)
    return result


# ============================================================
# [askstruct 2026-09-27] 结构化问答：分类信息回传 + 客户端 LLM 动态筛选组织
# 设计原则：服务端只做「检索 + 打标签」，answer 字段与 tax_policy_ask 零漂移；
#           客户端拿 candidates 自行筛选（剔税种不一致 / 低置信 / 陈旧）后组织最终回答。
# 零回归：tax_policy_ask 签名与行为完全不变；本区块全部为新增函数。
# ============================================================
_STRUCTURED_SNIPPET_MAX = 260      # 候选段落渲染时的单条正文截断长度
_STRUCTURED_CONTEXT_MAX = 3600     # 整段分类上下文块上限，防 prompt 膨胀


def _render_structured_answer(s: dict, question: str, top_n: int = 3,
                             min_conf: float = 0.0) -> str:
    """把服务端结构化返回渲染为「客户端 LLM 可直接消费的分类上下文块」。

    不改动 answer 原文（零漂移），仅在其前追加识别税种 / 路由 / 候选依据，
    使客户端 LLM 能按候选置信度与税种一致性动态筛选过滤后组织最终回答。

    Args:
        s: ask_structured 返回的结构化 dict
        question: 原始问题（用于标题回显）
        top_n: 最多渲染的候选条数
        min_conf: 候选置信度下限，低于该值的段落被剔除
    """
    if not isinstance(s, dict):
        return ""
    tax_types = s.get("tax_types") or []
    rm = s.get("route_meta") or {}
    files = rm.get("files") or []
    wiki_hits = rm.get("wiki_hits") or []
    errors = rm.get("errors") or []
    status = s.get("category_status") or "unknown"
    answer = s.get("answer") or ""

    lines = []
    lines.append("【用户问题】" + str(question))
    lines.append("【识别税种】" + ("、".join(tax_types) if tax_types else "（问题未含明确税种词，按全库检索）"))
    lines.append("【分类状态】" + status + ("（原始分类已被智能降级，按税种召回优先）"
                                          if status == "generic_ignored" else ""))
    if files:
        lines.append("【命中知识库文件】" + " → ".join(files[:6]))
    if wiki_hits:
        lines.append("【Wiki 章节命中】" + "、".join(wiki_hits[:6]))
    if errors:
        lines.append("【检索提示】" + "；".join(errors))

    cands = [c for c in (s.get("candidates") or [])
             if isinstance(c, dict) and float(c.get("confidence", 0) or 0) >= min_conf]
    kept = cands[:max(top_n, 0)]
    if kept:
        lines.append("【候选依据】（按置信度降序，confidence<0.35 建议弃用）")
        for i, c in enumerate(kept, 1):
            flags = []
            if c.get("stale"):
                flags.append("⚠️时效存疑")
            ct = c.get("tax_types") or []
            if tax_types and ct and not (set(ct) & set(tax_types)):
                flags.append("⚠️税种不符")
            flag_txt = ("  [" + "，".join(flags) + "]") if flags else ""
            conf = float(c.get("confidence", 0) or 0)
            sec = str(c.get("section") or "").strip() or "(无标题)"
            lines.append(f"  {i}. [置信度 {conf:.2f}] {c.get('file', '?')} › {sec}{flag_txt}")
            content = str(c.get("content") or "").strip()
            if len(content) > _STRUCTURED_SNIPPET_MAX:
                content = content[:_STRUCTURED_SNIPPET_MAX] + "…"
            if content:
                lines.append("     " + content.replace("\n", "\n     "))

    if answer:
        lines.append("【服务端权威答案】")
        lines.append(str(answer))

    lines.append("---")
    lines.append("【筛选与组织要求】优先采用 confidence≥0.7 且章节标题含识别税种的候选段落；"
                 "剔除标注「税种不符」「时效存疑」的段落；最终回答须明确标注政策依据"
                 "（文号 / 条款 / 章节），区分国家与地方口径，避免把不相关税种内容混入。")
    return "\n".join(lines)[:_STRUCTURED_CONTEXT_MAX]


def ask_structured(question: str, category: str = None, top_n: int = 5) -> dict:
    """结构化政策问答（分类信息 + 候选依据 + 渲染上下文）。

    与 tax_policy_ask 的关系：answer 字段与 tax_policy_ask 返回的 answer 逐字节一致
    （服务端同源于 ask_question 实现，零漂移）；本接口在其上附加 tax_types /
    route_meta / candidates / context 四组结构化字段，供客户端 LLM 动态筛选过滤
    后组织最终回答，避免泛段落抢答导致答非所问。

    Args:
        question: 用户问题
        category: 可选分类；泛化分类（如 database）会被服务端智能降级
        top_n: 候选上限（1-20，默认 5）

    Returns:
        {
          "answer":       服务端权威答案（与 tax_policy_ask 零漂移）,
          "context":      渲染后的分类上下文块（供 LLM 直接注入 prompt）,
          "tax_types":    识别到的税种标签,
          "category_status": default/explicit/generic_ignored/unrecognized,
          "route_meta":   {files, wiki_hits, generic_category, errors},
          "candidates":   [{file, section, tax_types, confidence, stale, content}],
          "source":       "structured" | "local_fallback"
        }
    """
    q = str(question or "").strip()
    try:
        tn = int(top_n)
    except (TypeError, ValueError):
        tn = 5
    tn = 1 if tn < 1 else (20 if tn > 20 else tn)

    if not q:
        return {
            "answer": "⚠️ 请提供具体的税务问题。",
            "context": "【用户问题】（空问题）\n\n【检索提示】empty_question",
            "tax_types": [], "category_status": "default",
            "route_meta": {"files": [], "wiki_hits": [], "generic_category": False,
                           "errors": ["empty_question"]},
            "candidates": [], "source": "structured",
        }

    _load_health_state()
    mode = _get_current_mode()
    # Fallback 模式：本地静态指引同样包成统一 schema，调用方可无差别消费
    if mode == "fallback":
        base = _generate_local_answer(q, category)
        return {
            "answer": base.get("message", ""),
            "context": base.get("result", ""),
            "tax_types": [], "category_status": "default",
            "route_meta": {"files": [], "wiki_hits": [], "generic_category": False,
                           "errors": ["service_unavailable"]},
            "candidates": [], "source": "local_fallback",
        }
    if mode == "probe":
        health = _quick_health_check()
        if health.get("healthy"):
            _update_mode(True)
        elif health.get("should_reregister"):
            _update_mode(False)
            config = _load_config()
            _ensure_api_key(config, force_refresh=True)
        else:
            _update_mode(False)

    cache_key = f"ask_s:{q}:{category}:{tn}"
    cached = _cache_get(cache_key)
    if cached:
        return cached

    result = _do_remote_policy_ask(q, category, fmt="structured", top_n=tn)

    if not isinstance(result, dict) or "error" in result:
        # 远端不可用 → 降级为本地指引，仍保持统一 schema
        base = _generate_local_answer(q, category)
        out = {
            "answer": base.get("message", ""),
            "context": base.get("result", ""),
            "tax_types": [], "category_status": "default",
            "route_meta": {"files": [], "wiki_hits": [], "generic_category": False,
                           "errors": [result.get("error", "remote_error") if isinstance(result, dict)
                                      else "remote_error"]},
            "candidates": [], "source": "local_fallback",
        }
    else:
        out = {
            "answer": result.get("answer", ""),
            "context": _render_structured_answer(result, q, top_n=min(tn, 3)),
            "tax_types": result.get("tax_types") or [],
            "category_status": result.get("category_status") or "default",
            "route_meta": result.get("route_meta") or {},
            "candidates": result.get("candidates") or [],
            "source": "structured",
        }
    _cache_set(cache_key, out)
    return out


def risk_check(scenario: str, level_filter: str = None) -> dict:
    """企业税务风险初筛（自然语言 scenario，≤2000 字）"""
    if not isinstance(scenario, str):
        return _friendly_error("scenario_invalid", {"error_code": "InvalidScenarioType"})
    _load_health_state()
    mode = _get_current_mode()
    # Fallback 模式直接短路，不等待网络注册超时
    if mode == "fallback":
        return _generate_local_answer(scenario)
    if mode == "probe":
        health = _quick_health_check()
        if health.get("healthy"):
            _update_mode(True)
        elif health.get("should_reregister"):
            _update_mode(False)
            config = _load_config()
            _ensure_api_key(config, force_refresh=True)
        else:
            _update_mode(False)

    cache_key = f"risk:{scenario}:{level_filter}"
    cached = _cache_get(cache_key)
    if cached:
        return cached

    result = _do_remote_risk_check(scenario, level_filter)
    _cache_set(cache_key, result)
    return result


def _do_remote_risk_check(scenario: str, level_filter: str = None, _retry_count: int = 0) -> dict:
    config = _load_config()
    service_url = config.get("service_url", _DEFAULT_SERVICE_URL)
    api_key = _ensure_api_key(config)
    if not api_key:
        _log("risk_check", {"scenario": scenario, "status": "no_api_key", "mode": "local"})
        return _generate_local_answer(scenario)
    params = {"scenario": scenario}
    if level_filter:
        params["level"] = level_filter   # 远程 risk(scenario, level) 用 level 而非 level_filter
    result = _call_mcp_tool("risk", params, api_key, service_url)
    if result.get("error_code") in ("InvalidScenarioType", "PayloadTooLarge"):
        return _friendly_error("scenario_invalid", {"error_code": result.get("error_code")})
    # [authfix 2026-11-03] 401 自恢复判定改为机读 error_code 优先（原判 "api_key"
    # 子串因友好文案「服务授权校验未通过（凭证失效或为空）」不含该字面量而恒 False，
    # 导致 force_refresh 重注册分支成死代码、失效 key 永不自愈）。保留旧子串判定作兜底。
    if result.get("error_code") == "api_key_invalid" or (
            "error" in result and "api_key" in str(result.get("error", "")).lower()):
        if _retry_count < 1:
            api_key = _ensure_api_key(config, force_refresh=True)
            if api_key:
                return _do_remote_risk_check(scenario, level_filter, _retry_count=_retry_count + 1)
        _log("risk_check", {"scenario": scenario, "status": "api_key_invalid", "mode": "local"})
        return _generate_local_answer(scenario)
    if "error" not in result:
        _log("risk_check", {"scenario": scenario, "status": "ok"})
        _maybe_auto_feedback("risk", params, result)
    else:
        _log("risk_check", {"scenario": scenario, "status": "error", "detail": result.get("error")})
        if _get_current_mode() in ["fallback", "probe"]:
            return _generate_local_answer(scenario)
    return result


def calc(tax_type: str, params: dict) -> dict:
    """各类税费计算"""
    _load_health_state()
    mode = _get_current_mode()
    # Fallback 模式直接短路
    if mode == "fallback":
        return _friendly_error("fallback_active")
    cache_key = f"calc:{tax_type}:{json.dumps(params, sort_keys=True)}"
    cached = _cache_get(cache_key)
    if cached:
        return cached
    result = _do_remote_tax_calculate(tax_type, params)
    if "error" in result and mode in ["fallback", "probe"]:
        return _friendly_error("fallback_active")
    _cache_set(cache_key, result)
    return result


def _normalize_calc_params(tax_type: str, params: dict) -> dict:
    """规范化 calc 参数，确保远程旧版服务器兼容。

    远程服务器（mcp.aitaxs.top）可能使用旧版 TaxCalculator，
    仅识别 taxpayer_type='small'（不识别 'small_scale'）。
    此处做客户端侧归一化，避免兼容性问题。
    """
    if tax_type.lower() in ("vat", "增值税"):
        tt = params.get("taxpayer_type", "small")
        if tt and tt.lower() in ("small_scale", "small-scale", "小规模"):
            params = dict(params)
            params["taxpayer_type"] = "small"
    return params


def _do_remote_tax_calculate(tax_type: str, params: dict) -> dict:
    config = _load_config()
    service_url = config.get("service_url", _DEFAULT_SERVICE_URL)
    api_key = _ensure_api_key(config)
    if not api_key:
        return _friendly_error("not_registered")
    # 客户端侧归一化：确保 remote 旧版服务器兼容
    params = _normalize_calc_params(tax_type, params)
    # 远程 schema（T21 起 tax_calculate/calc 的 params 契约已改为 dict，同时向后兼容 JSON 字符串）
    # 此处仍发送 JSON 字符串，以兼容尚未部署 T21 修复的生产服务器（旧版仅接受字符串），避免回归
    params_str = json.dumps(params, ensure_ascii=False) if isinstance(params, dict) else params
    payload = {"tax_type": tax_type, "params": params_str}
    # 远程已统一用短名（ask/risk/calc/kb），旧名 tax_policy_ask/risk_check/tax_calculate 不再被识别
    result = _call_mcp_tool("calc", payload, api_key, service_url)
    if "error" not in result:
        _log("tax_calculate", {"tax_type": tax_type, "status": "ok"})
    if "error" not in result:
        _log("tax_calculate", {"tax_type": tax_type, "status": "ok"})
        _maybe_auto_feedback("calc", payload, result)
    else:
        _log("tax_calculate", {"tax_type": tax_type, "status": "error", "detail": result.get("error")})
    return result


def kb_list() -> dict:
    """知识库概览（仅元数据，不回正文）"""
    _load_health_state()
    # Fallback 模式直接短路
    if _get_current_mode() == "fallback":
        return _generate_local_answer("知识库列表")
    config = _load_config()
    api_key = _ensure_api_key(config)
    if not api_key:
        return _friendly_error("not_registered")
    service_url = config.get("service_url", _DEFAULT_SERVICE_URL)
    result = _call_mcp_tool("kb", {}, api_key, service_url)
    if "error" not in result:
        global _tools_catalog
        tools = result.get("tools")
        if isinstance(tools, list):
            _tools_catalog = {t.get("name"): t for t in tools if isinstance(t, dict)}
        return result
    if _get_current_mode() in ["fallback", "probe"]:
        return _generate_local_answer("知识库列表")
    return result


def get_mode_status() -> dict:
    """查询当前运行模式"""
    _load_health_state()
    return {"mode": _get_current_mode(), "consecutive_failures": _health_state["consecutive_failures"],
            "fallback_count": _health_state["fallback_count"], "last_check_time": _health_state["last_check_time"]}


# ============================================================
# 本地日志（仅记前缀，不记 API Key 明细）
# ============================================================
def _log(action: str, data: dict):
    try:
        os.makedirs(_LOG_DIR, exist_ok=True)
        today = time.strftime("%Y-%m-%d")
        log_file = os.path.join(_LOG_DIR, f"{today}.jsonl")
        entry = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "action": action, **data}
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass


# >>> [clienttools 2026-09-27] begin

# ============================================================
# [clienttools 2026-09-27] rd_template / route_query / wiki_route
# 补齐服务端 TOOLS_CATALOG 已有、但客户端此前无入口的三个工具。
# 零协议侵入：复用 _call_mcp_tool 走 JSON-RPC tools/call，
# fallback 短路、缓存/归因/_meta 行为与 kb_list 完全一致。
# ============================================================
def rd_template(template: str = "", sheet_name: str = "", max_rows: int = 50,
                include_styles: bool = True, req_type: str = "file",
                action: str = "", delivery: str = "embedded",
                script: str = "", rule: str = "", prompt_id: str = "",
                group: str = "", groups=None,
                include_source: bool = False, include_prompts: bool = True,
                include_templates: bool = True, tier: str = "",
                watermark: bool = True) -> dict:
    """统一模板入口 + 审计能力包输出（对齐服务端 rd_template 3.3.0）

    服务端 VALID_TEMPLATES 15 个模板（rd_gen/kelite/medical/cit_wp/cit_rep/cit_adv/
    audit_report/audit_financial/audit_notes/audit_workpaper/audit_workpaper_lite/
    audit_company_profile/audit_letter_enterprise/audit_letter_bank/audit_other），
    多模式：type=file(默认)/info/baseline；action=capability/manifest/skeleton/
    ruleset/protection_status/capability_index/script_source/prompt。

    客户端不在此硬编码模板白名单（防滞后于服务端），仅做基础必填校验，
    模板枚举与参数合法性由服务端校验（返回 all_templates 供参考）。

    Args:
        template: 模板ID（type=file 时必填；15 个模板见服务端）
        sheet_name: 可选，指定表单名称；不传返回总览（所有表名+行次摘要）
        max_rows: 每表最多返回行数（1-200，服务端上限 200）
        include_styles: 是否包含单元格样式信息，默认 True
        req_type: file(默认)/info/baseline —— 对应服务端 type 参数
        action: capability/manifest/skeleton/ruleset/protection_status/capability_index/script_source/prompt
        delivery: embedded(默认，推荐)/source
        script: 脚本key（action=script_source 时，12 个）
        rule: 规则集名（action=ruleset 时，4 个）
        prompt_id: 提示词ID（action=prompt 时，7 个）
        group: 能力组筛选（action=manifest 时：report/workpaper/toolkit）
        groups: 能力组筛选（action=capability 时，list）
        include_source: 兼容参数；true 等价 delivery=source
        include_prompts: 是否下发示例提示词（action=capability 时，默认 true）
        include_templates: 是否下发模板索引（action=capability 时，默认 true）
        tier: 授权等级（action=ruleset 时：free/standard/professional/enterprise）
        watermark: 是否附加溯源水印（action=ruleset 时，默认 true）
    """
    _load_health_state()
    if _get_current_mode() == "fallback":
        return _friendly_error("fallback_active")
    # 基础校验：type=file（默认）且非 info/baseline 时 template 必填；
    # 模板枚举校验交服务端（VALID_TEMPLATES 15 个），客户端不硬编码白名单防滞后。
    if req_type in ("file", "") and not template:
        return {"error": "invalid_template",
                "message": "template 必填（type=file 时；目录概览请用 req_type=info）"}
    try:
        max_rows = max(1, min(int(max_rows or 50), 200))
    except (TypeError, ValueError):
        max_rows = 50
    config = _load_config()
    api_key = _ensure_api_key(config)
    if not api_key:
        return _friendly_error("not_registered")
    payload = {"type": req_type or "file", "max_rows": max_rows,
               "include_styles": bool(include_styles)}
    if template:
        payload["template"] = template
    if sheet_name:
        payload["sheet_name"] = str(sheet_name)
    if action:
        payload["action"] = action
    if delivery:
        payload["delivery"] = delivery
    if script:
        payload["script"] = script
    if rule:
        payload["rule"] = rule
    if prompt_id:
        payload["prompt_id"] = prompt_id
    if group:
        payload["group"] = group
    if groups:
        payload["groups"] = groups
    if include_source:
        payload["include_source"] = include_source
    if not include_prompts:
        payload["include_prompts"] = include_prompts
    if not include_templates:
        payload["include_templates"] = include_templates
    if tier:
        payload["tier"] = tier
    if not watermark:
        payload["watermark"] = watermark
    result = _call_mcp_tool("rd_template", payload, api_key,
                            config.get("service_url", _DEFAULT_SERVICE_URL))
    _log("rd_template", {"template": template or req_type,
                         "sheet": sheet_name or "overview",
                         "status": "ok" if "error" not in result else "error",
                         "detail": result.get("error", "")[:120] if "error" in result else ""})
    return result


def prompt_guide(scenario: str = "", tool_name: str = "", context: dict = None) -> dict:
    """⑧关联业务提示词示例库：按业务场景/前序工具推荐下一步提示词（含可注入联动提示词）

    配合 ask/risk_check/calc/rd_template 使用，构建「7库+⑧库」业务闭环。
    返回 next_steps（下n步推荐工具+触发条件+提示词示例）、all_prompt_examples（全部示例）、
    param_validation_summary（缺失参数汇总）、inline_next_prompt（可直接注入其他工具响应的联动提示词）。

    Args:
        scenario: 业务场景关键词（annual_audit/cit_reconciliation/...），与 tool_name 至少填一个
        tool_name: 当前/前序工具名（ask/risk_check/calc/rd_template），缺省时基于 scenario 推断
        context: 当前工具的返回结果（用于动态填充提示词模板变量）
    """
    _load_health_state()
    if _get_current_mode() == "fallback":
        return _friendly_error("fallback_active")
    if not (scenario or "").strip() and not (tool_name or "").strip():
        return {"error": "empty_scenario", "message": "scenario 或 tool_name 至少填一个"}
    config = _load_config()
    api_key = _ensure_api_key(config)
    if not api_key:
        return _friendly_error("not_registered")
    payload = {"scenario": (scenario or "").strip(), "tool_name": (tool_name or "").strip()}
    if context:
        payload["context"] = context
    result = _call_mcp_tool("prompt_guide", payload, api_key,
                            config.get("service_url", _DEFAULT_SERVICE_URL))
    _log("prompt_guide", {"scenario": (scenario or "")[:40],
                          "tool": (tool_name or "")[:20],
                          "status": "ok" if "error" not in result else "error",
                          "detail": result.get("error", "")[:120] if "error" in result else ""})
    return result


def route_query(question: str) -> dict:
    """技能路由查询：判断问题最匹配的技能 slug（多技能协作前先定目标技能）

    返回 hits[{slug, score, matched, description, associations}]，score 降序，最多 5 条。
    """
    _load_health_state()
    if _get_current_mode() == "fallback":
        return _friendly_error("fallback_active")
    question = (question or "").strip()
    if not question:
        return {"error": "empty_question", "message": "question 不能为空"}
    config = _load_config()
    api_key = _ensure_api_key(config)
    if not api_key:
        return _friendly_error("not_registered")
    result = _call_mcp_tool("route_query", {"question": question}, api_key,
                            config.get("service_url", _DEFAULT_SERVICE_URL))
    _log("route_query", {"q": question[:40],
                         "status": "ok" if "error" not in result else "error",
                         "detail": result.get("error", "")[:120] if "error" in result else ""})
    return result


def wiki_route(question: str, top_k: int = 1, max_files: int = 12,
               per_file: bool = False) -> dict:
    """知识库章节级检索定位：返回最匹配的专题文件与章节（只回元数据，不下发正文）

    适合在调用 tax_policy_ask 前先确认「该看哪个文件的哪一节」，避免全文问答命错章节。
    返回 tax_terms(识别到的税种词) 与
    hits[{rank, file, section 章节标题, line_no 起始行号, score 相关度,
          topic 主题, evidence 证据元数据}]。

    Args:
        question: 自然语言问题
        top_k: 按相关度降序返回的候选章节总数（1-10，默认 1）
        max_files: 扫描的专题文件上限（默认 12）
        per_file: True 时每个命中的文件各取 top_k 条章节（证据面广，适合需要完整证据链）
    """
    _load_health_state()
    if _get_current_mode() == "fallback":
        return _friendly_error("fallback_active")
    question = (question or "").strip()
    if not question:
        return {"error": "empty_question", "message": "question 不能为空"}
    try:
        top_k = max(1, min(int(top_k or 1), 10))
    except (TypeError, ValueError):
        top_k = 1
    try:
        max_files = max(1, min(int(max_files or 12), 60))
    except (TypeError, ValueError):
        max_files = 12
    config = _load_config()
    api_key = _ensure_api_key(config)
    if not api_key:
        return _friendly_error("not_registered")
    result = _call_mcp_tool(
        "wiki_route",
        {"question": question, "top_k": top_k, "max_files": max_files,
         "per_file": bool(per_file)},
        api_key, config.get("service_url", _DEFAULT_SERVICE_URL))
    _log("wiki_route", {"q": question[:40], "top_k": top_k, "per_file": bool(per_file),
                        "status": "ok" if "error" not in result else "error",
                        "detail": result.get("error", "")[:120] if "error" in result else ""})
    return result


# >>> [feedback-pipeline 2026-10-08] begin
# ============================================================
# [feedback-pipeline 2026-10-08] 反馈管道
# 让客户端 LLM 自动/手动提交有效反馈 → 本地持久化 + 云端即时评估
# → 每日 /feedback/daily-summary 聚合供增补计划消费
# 设计：
#   - feedback() 是主入口（LLM 显式调用；用户在对话里说「这个回答不对」时也调用）
#   - 本地队列 feedback_log.jsonl 保证离线可用 + 便于追溯
#   - 600s 去重窗口：同问题+同类型 10 分钟内只报一次
#   - 低置信自动上报默认关闭：env TAX_ENABLE_AUTO_FEEDBACK=1 显式开启
# ============================================================
_FEEDBACK_LOG_FILE = os.path.join(_LOG_DIR, "feedback_log.jsonl")
_FEEDBACK_DEDUP_FILE = os.path.join(_CACHE_DIR, "feedback_dedup.json")
_FEEDBACK_DEDUP_WINDOW_S = 600
_FEEDBACK_AUTO_THRESHOLD = 60.0  # score/confidence 触发阈值（0-100）
_FEEDBACK_AUTO_TYPES = {
    "knowledge_missing": "knowledge_missing",
    "no_policy_found": "knowledge_missing",
    "no_answer": "knowledge_missing",
    "answer_error": "bug",
    "timeout": "bug",
    "server_error": "bug",
}
_FEEDBACK_KNOWN = {
    "question", "correction", "improvement", "knowledge_missing",
    "bug", "misinformation", "general",
}


def _feedback_normalize_type(t) -> str:
    if not isinstance(t, str) or not t.strip():
        return "general"
    t = t.strip().lower()
    return t if t in _FEEDBACK_KNOWN else "general"


def _feedback_dedup_key(question, ftype) -> str:
    raw = f"{ftype}|{(question or '')[:200].lower().strip()}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


def _feedback_recent(key: str) -> bool:
    try:
        if not os.path.exists(_FEEDBACK_DEDUP_FILE):
            return False
        with open(_FEEDBACK_DEDUP_FILE, "r", encoding="utf-8") as _f:
            data = json.loads(_f.read())
        if not isinstance(data, dict):
            return False
        return float(data.get(key, 0)) >= time.time() - _FEEDBACK_DEDUP_WINDOW_S
    except Exception:
        return False


def _feedback_mark_sent(key: str):
    try:
        data = {}
        if os.path.exists(_FEEDBACK_DEDUP_FILE):
            try:
                with open(_FEEDBACK_DEDUP_FILE, "r", encoding="utf-8") as _f:
                    data = json.loads(_f.read())
                if not isinstance(data, dict):
                    data = {}
            except Exception:
                data = {}
        data[key] = time.time()
        cutoff = time.time() - 86400
        data = {k: v for k, v in data.items() if float(v) >= cutoff}
        os.makedirs(os.path.dirname(_FEEDBACK_DEDUP_FILE), exist_ok=True)
        with open(_FEEDBACK_DEDUP_FILE, "w", encoding="utf-8") as _f:
            _f.write(json.dumps(data, ensure_ascii=False))
    except Exception:
        pass


def _feedback_append_local(entry: dict):
    try:
        os.makedirs(_LOG_DIR, exist_ok=True)
        with open(_FEEDBACK_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass


def feedback(ftype: str = "question", question: str = "", answer: str = "",
             confidence: int = 90, source: str = "client",
             api_key: str = None, service_url: str = None,
             submit: bool = True, user_confirmed: bool = False) -> dict:
    """提交反馈（本地持久化 + 云端即时评估；600s 去重）

    隐私披露（审核整改 2026-10-21，云鼎实验室报告 2 项可疑清零）：
      - 接收方：https://mcp.aitaxs.top 运营方云端 MCP 服务（HTTPS）
      - 上报字段：ftype、question（截断 2000 字）、expected_answer（截断 4000 字）、
                  confidence、source、client 标识
      - 不采集设备指纹 / MAC / 序列号；仅本地生成匿名 device-id 用于鉴权
      - 用户须在使用前知悉本行为；LLM 调用本函数前应获得用户显式确认

    参数：
    ftype       question/correction/improvement/knowledge_missing/bug/general
    question    用户原始问题或上下文
    answer      期望答案（correction/knowledge_missing 场景建议填）
    confidence  调用方对反馈本身的置信度 0-100（默认 90）
    source      client(默认/外部) 或 internal(开发者内部，才会 auto-apply 入库)
    submit      False 时只写本地 feedback_log.jsonl 不上云
    user_confirmed  True 表示 LLM 已取得用户确认（首次提交前必须向用户披露
                    接收方与上报字段并取得确认）；未确认时本函数仅写本地，
                    返回 queued_local 并在提示中告知用户「该反馈已本地记录，
                    尚未上报；是否上报请确认」
    """
    entry = {
        "ts": time.time(),
        "ts_str": time.strftime("%Y-%m-%d %H:%M:%S"),
        "type": _feedback_normalize_type(ftype),
        "question": (question or "")[:2000],
        "expected_answer": (answer or "")[:4000],
        "confidence": int(confidence) if confidence is not None else 90,
        "source": source or "client",
        "client": f"mcp-client/{_CLIENT_VERSION}",
    }
    _feedback_append_local(entry)

    if not submit:
        return {"status": "queued_local", "local_only": True,
                "feedback_id": "", "type": entry["type"]}

    if not user_confirmed:
        # 审核整改：未确认时默认不上云，仅本地落盘 + 提示
        return {
            "status": "await_user_confirmation",
            "local_only": True,
            "type": entry["type"],
            "disclosure": (
                f"[隐私披露] 该反馈（type={entry['type']}）已本地记录。"
                f"是否上报至运营方云端 {_DEFAULT_SERVICE_URL}？"
                f"上报字段：question / expected_answer / confidence / client。"
                f"您确认后方可发送。"
            ),
        }

    key = _feedback_dedup_key(entry["question"], entry["type"])
    if _feedback_recent(key):
        return {"status": "dedup_skip", "local_only": True,
                "reason": "within_600s_window", "type": entry["type"]}

    try:
        config = _load_config()
        ak = api_key or _ensure_api_key(config)
        if not ak:
            return {"status": "queued_local", "local_only": True,
                    "reason": "no_api_key", "type": entry["type"]}
        params = {
            "api_key": ak,
            "type": entry["type"],
            "question": entry["question"],
            "expected_answer": entry["expected_answer"],
            "confidence": entry["confidence"],
            "source": entry["source"],
            "client": entry["client"],
        }
        result = _call_mcp_tool("feedback", params, ak,
                                service_url or config.get("service_url", _DEFAULT_SERVICE_URL))
        _feedback_mark_sent(key)
        return result
    except Exception as _e:
        return {"status": "error", "local_only": True,
                "reason": str(_e)[:200], "type": entry["type"]}


def _maybe_auto_feedback(tool: str, params: dict, result: dict):
    """低置信/知识缺口场景自动上报（默认关闭，env TAX_ENABLE_AUTO_FEEDBACK=1 开启）

    触发条件（任一即可）：
      1) result.error_code ∈ _FEEDBACK_AUTO_TYPES
      2) result.confidence 或 result.score 数值 < _FEEDBACK_AUTO_THRESHOLD
      3) result.missing_knowledge == True
    调用无阻塞副作用；失败静默。

    隐私披露（审核整改 2026-10-21）：
      - 本路径仅在用户显式开启 TAX_ENABLE_AUTO_FEEDBACK=1 时才运行
      - 自动路径调用 feedback() 时 user_confirmed=False → 仅本地落盘，
        返回 status=await_user_confirmation，由 LLM 决定是否向用户确认上报
      - 不向用户隐藏该行为；LLM 应在首次提交前披露接收方与上报字段
    """
    try:
        if os.getenv("TAX_ENABLE_AUTO_FEEDBACK") != "1":
            return
        if not isinstance(result, dict) or not isinstance(params, dict):
            return
        ftype = None
        _ec = str(result.get("error_code") or "").strip().lower()
        if _ec in _FEEDBACK_AUTO_TYPES:
            ftype = _FEEDBACK_AUTO_TYPES[_ec]
        if not ftype:
            _conf = result.get("confidence", result.get("score"))
            try:
                _cv = float(_conf) if _conf is not None else None
                if _cv is not None and 0 <= _cv <= 100 and _cv < _FEEDBACK_AUTO_THRESHOLD:
                    ftype = "knowledge_missing"
            except Exception:
                pass
        if not ftype and result.get("missing_knowledge") is True:
            ftype = "knowledge_missing"
        if not ftype:
            return
        q = params.get("question") or params.get("scenario") or ""
        if not q and tool == "calc":
            q = f"calc:{params.get('tax_type', '?')}"
        if not q:
            return
        # 自动路径：user_confirmed=False → 仅本地落盘，不上云
        feedback(ftype=ftype, question=str(q)[:2000], answer="", confidence=40,
                 source="client", user_confirmed=False)
    except Exception:
        pass


def _flush_feedback_queue(*args, **kwargs):
    """兼容占位：当前无独立队列生产者，feedback() 已本地持久化。"""
    return {"flushed": 0, "note": "no_pending_items", "log_file": _FEEDBACK_LOG_FILE}

# <<< [feedback-pipeline 2026-10-08] end
# <<< [clienttools 2026-09-27] end
if __name__ == "__main__":
    print("=== 财税政策 MCP 客户端（安全收敛版 v4.0.0）===")
    print(f"缓存容量: {_CACHE_TTL}秒")
    config = _load_config()
    print(f"服务地址: {config.get('service_url')}")
    print(f"API Key: {'已配置' if config.get('api_key') else '未配置（首次调用将自动注册）'}")
    print("\n测试模式状态...")
    print(json.dumps(get_mode_status(), ensure_ascii=False, indent=2))
