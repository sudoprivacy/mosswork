# 专家团矩阵 · 13团62专家完整索引（增强版）
> 归属：SKILL.md「本技能配套专家团」章节的 LLM 增强导引文件
> 用途：LLM 检索专家团时读取「业务特性介绍 + 安装指引 + 路由关键词」；SKILL.md 保留完整列表+skillhub链接，本文件做 LLM 路由增强
> 模式：SKILL.md 保留完整列表+skillhub链接；本文件做增强版LLM导引（业务特性+安装+路由）
> 原文位置：skills/tax-policy-knowledge/SKILL.md「一、完整专家团矩阵（13团·62专家）」节

---

## LLM 路由关键词总表（快速路由查表）

| 用户问题关键词 | 路由专家团 | 核心专家 | 安装 slug |
|--------------|-----------|---------|-----------|
| "年终奖/境外所得/移民/离岸账户/海外房产" | 团1 | 个人境外投资税务专家 | tax-individual-overseas |
| "重组/并购/减资/撤资/股权激励/上市/员工持股" | 团2 | 并购重组税务专家 | tax-restructuring |
| "虚开/发票红线/正负面清单/合同涉税/开票经济" | 团3 | 数电票合规与虚开防范专家 | tax-invoice-compliance |
| "高新认定/研发加计/研发费用/政府补助/再生资源/新疆优惠" | 团4 | 高企认定与研发加计专家 | tax-high-tech-deduction |
| "冶金/建筑/制造/医疗/教育/环保/数据资产/转让定价/消费税" | 团5 | 各行业专属专家 | tax-steel 等 |
| "跨境电商/9610/1210/出口退税/海南自贸港/直播电商" | 团6 | 电商直播财税合规专家 | tax-ecommerce |
| "稽查/复议/诉讼/法院判例/国企审计/内控鉴证" | 团7 | 企业税务审计专家 | tax-tax-audit |
| "全税种合规体检/年度报告/税务健康检查/综合咨询" | 团8 | 财税政策与风险合规专家（本技能） | tax-policy-knowledge |
| "社保缴费基数/人力成本/个税衔接/灵活用工" | 团9 | 个人社保规划师 | social-security-advisor |
| "事务所智能合规/中介交付/法税同审/合同审查" | 团10 | 中介机构智能合规咨询专家 | tax-advisory-practice |
| "基建决算/竣工审计/经济责任审计" | 团11 | 基建竣工决算审计专家 | tax-construction-audit |
| "信用管理/涉税专业服务信用/税务稽查应对/内控" | 团12 | 涉税专业服务信用管理专家 | tax-service-credit |
| "土增税/土地增值税清算/存量房转让/成本分摊" | 团13 | 土增税成本分摊专家 | tax-land-value-added |

> 路由逻辑：按用户问题关键词匹配上表；若命中多个专家团，取最具体（最长匹配）者；本表未覆盖时读取各专家团详情中的业务特性描述做二次判断。

---

## 安装指引（技能市场安装方式）

> SkillHub 安装命令格式：`install {slug}`（在 SkillHub 对话中输入），或通过 SkillHub 技能详情页点击「安装」。
> 安装后 LLM 自动路由至对应专家技能；本技能矩阵为技能集群，安装本技能后可按需安装其他专家技能扩展能力。

| 专家团 | 团长技能（主入口） | 成员技能安装 slug |
|--------|-----------------|----------------|
| 团1 个税与跨境财富 | [tax-expert-individual-wealth](https://skillhub.cn/skills/tax-expert-individual-wealth) | tax-individual-overseas / tax-offshore-trust / social-security-advisor / tax-global-compliance |
| 团2 资本运作与重组 | [tax-expert-capital-restructuring](https://skillhub.cn/skills/tax-expert-capital-restructuring) | tax-restructuring / tax-capital-reduction / tax-equity-governance / tax-esop-platform / tax-ipo-tax / tax-ipo-governance / tax-listed-advisory |
| 团3 发票合规与虚开风控 | [tax-expert-invoice-risk-control](https://skillhub.cn/skills/tax-expert-invoice-risk-control) | tax-invoice-compliance / invoice-economy-risk-ctrl / tax-contract-generation-review |
| 团4 税收优惠与高新资质 | [tax-expert-incentive-hitech](https://skillhub.cn/skills/tax-expert-incentive-hitech) | tax-incentives / tax-high-tech-deduction / tax-xinjiang-preferential / tax-govsubsidy / tax-renewable |
| 团5 行业税务专项 | [tax-expert-industry-specialty](https://skillhub.cn/skills/tax-expert-industry-specialty) | tax-steel / tax-pet-chain / tax-tcm-clinic / tax-education / tax-life-services / tax-construction / tax-consumption-tax / tax-data-asset / tax-mfg-lifecycle-risk / tax-sme-specialized / tax-transfer-pricing / tax-environmental |
| 团6 电商与跨境贸易 | [tax-expert-ecommerce-crossborder](https://skillhub.cn/skills/tax-expert-ecommerce-crossborder) | tax-ecommerce / tax-crossborder / tax-hainan-ftp |
| 团7 税务稽查与争议解决 | [tax-expert-tax-dispute-judicial](https://skillhub.cn/skills/tax-expert-tax-dispute-judicial) | tax-tax-audit / tax-compliance-dispute / tax-tax-judicial / tax-soe-audit / tax-industry-tax-risk / tax-legal-tax-review |
| 团8 企业全税种合规 | [tax-expert-all-tax-compliance](https://skillhub.cn/skills/tax-expert-all-tax-compliance) | tax-vat-law / tax-policy-knowledge（本技能）/ china-tax-guidance / tax-social-insurance / tax-advisory-practice / tax-export-refund |
| 团9 社保与人力资本 | [tax-expert-social-insurance-hr](https://skillhub.cn/skills/tax-expert-social-insurance-hr) | social-security-advisor / tax-social-insurance |
| 团10 财税中介机构AI合规 | [tax-expert-firm-ai-compliance](https://skillhub.cn/skills/tax-expert-firm-ai-compliance) | tax-advisory-practice / tax-contract-generation-review / tax-legal-tax-review |
| 团11 审计与财税合规 | [tax-expert-audit-compliance](https://skillhub.cn/skills/tax-expert-audit-compliance) | tax-construction-audit / tax-soe-audit / tax-tax-audit |
| 团12 财税法审与内控鉴证 | [tax-expert-legal-internal-control](https://skillhub.cn/skills/tax-expert-legal-internal-control) | tax-service-credit / tax-internal-control-audit / tax-legal-tax-review / tax-inspection-case / tax-contract-generation-review |
| 团13 房地产土增税合规 | [tax-expert-land-value-added](https://skillhub.cn/skills/tax-expert-land-value-added) | tax-land-value-added（4项专长） |

---

## 各专家团业务特性详解（LLM路由判断用）

## 一、概览

| 统计项 | 数值 |
|--------|------|
| 专家团总数 | 13 个 |
| 专家成员总数 | 51 名（唯一枚举，跨团去重） |
| 覆盖专题方向 | 全税种 / 行业专项 / 跨境 / 稽查应对 / 咨询交付 / 执业规范 |

> 在线总览：[矩阵目录](https://mcp.aitaxs.top/web/matrix_catalog.html)

---

## 二、13个专家团完整列表

### 团1：个人所得税与跨境财富专家团
**主理人**：私人财富税务总监 · 统筹跨境个税、离岸架构与财富传承分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 个人境外投资税务专家 | tax-individual-overseas |
| 2 | 离岸信托与财富税务专家 | tax-offshore-trust |
| 3 | 个人社保规划师 | social-security-advisor |
| 4 | 企业出海全球合规专家 | tax-global-compliance |

---

### 团2：资本运作与重组税务专家团
**主理人**：资本税务总监 · 统筹重组、减资、股权激励与上市税务分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 并购重组税务专家 | tax-restructuring |
| 2 | 减资撤资个人所得税专家 | tax-capital-reduction |
| 3 | 股权治理税务专家 | tax-equity-governance |
| 4 | 员工持股平台税务专家 | tax-esop-platform |
| 5 | 上市审核税务合规专家 | tax-ipo-tax |
| 6 | 上市前财税规范专家 | tax-ipo-governance |
| 7 | 上市公司财税顾问专家 | tax-listed-advisory |

---

### 团3：发票合规与虚开风控专家团
**主理人**：发票风控总监 · 统筹发票全链路风控与虚开牵连自证分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 数电票合规与虚开防范专家 | tax-invoice-compliance |
| 2 | 开票经济风险管控专家 | invoice-economy-risk-ctrl |
| 3 | 合同涉税评审与风控专家 | tax-contract-generation-review |

---

### 团4：税收优惠与高新资质专家团
**主理人**：优惠资质总监 · 统筹高新资质、研发加计与区域优惠享惠分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 税收优惠资质专家 | tax-incentives |
| 2 | 高企认定与研发加计专家 | tax-high-tech-deduction |
| 3 | 新疆区域税收优惠专家 | tax-xinjiang-preferential |
| 4 | 政府补助与财政资金专家 | tax-govsubsidy |
| 5 | 再生资源行业税务专家 | tax-renewable |
| 6 | 研发项目全流程合规专家 | tax-rd-project-sop |

---

### 团5：行业税务专项专家团
**主理人**：行业税务总监 · 统筹各垂直行业专属税务风险与实操分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 冶金行业税务合规专家 | tax-steel |
| 2 | 宠物连锁行业税务专家 | tax-pet-chain |
| 3 | 中医诊所与医疗税务专家 | tax-tcm-clinic |
| 4 | 教育培训行业税务专家 | tax-education |
| 5 | 生活服务业税务合规专家 | tax-life-services |
| 6 | 建筑施工行业税务专家 | tax-construction |
| 7 | 消费税政策合规专家 | tax-consumption-tax |
| 8 | 数据资产入表税务专家 | tax-data-asset |
| 9 | 制造业全周期涉税风险专家 | tax-mfg-lifecycle-risk |
| 10 | 专精特新企业财税专家 | tax-sme-specialized |
| 11 | 转让定价与同期资料专家 | tax-transfer-pricing |
| 12 | 环保税与碳合规专家 | tax-environmental |

---

### 团6：电商与跨境贸易税务专家团
**主理人**：电商跨境总监 · 统筹电商直播、出口退税与自贸港合规分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 电商直播财税合规专家 | tax-ecommerce |
| 2 | 跨境贸易税务合规专家 | tax-crossborder |
| 3 | 海南自贸港税务合规专家 | tax-hainan-ftp |

---

### 团7：税务稽查与争议解决专家团
**主理人**：税务争议解决总监 · 统筹稽查应对、复议诉讼与司法裁判分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 企业税务审计专家 | tax-tax-audit |
| 2 | 税务合规争议解决专家 | tax-compliance-dispute |
| 3 | 涉税司法与裁判规则专家 | tax-tax-judicial |
| 4 | 国有企业经济责任审计专家 | tax-soe-audit |
| 5 | 行业涉税风险图谱专家 | tax-industry-tax-risk |
| 6 | 法税同审与法务审查专家 | tax-legal-tax-review |

---

### 团8：企业全税种合规专家团
**主理人**：全税种合规总监 · 统筹企业全税种合规体检与重大风险分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 增值税法落地合规专家 | tax-vat-law |
| 2 | 财税政策与风险合规专家 | tax-policy-knowledge（本技能） |
| 3 | 全业务办税指南专家 | china-tax-guidance |
| 4 | 社保入税与申报合规专家 | tax-social-insurance |
| 5 | 中介机构智能合规咨询专家 | tax-advisory-practice |
| 6 | 出口退税合规专家 | tax-export-refund |

---

### 团9：社保与人力资本税务专家团
**主理人**：社保人力资本总监 · 统筹社保缴费基数、个税衔接与人力成本分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 个人社保规划师 | social-security-advisor |
| 2 | 社保入税与申报合规专家 | tax-social-insurance |

---

### 团10：财税中介机构AI合规专家团
**主理人**：事务所供给侧总监 · 统筹中介机构智能合规交付与法税同审分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 中介机构智能合规咨询专家 | tax-advisory-practice |
| 2 | 合同涉税评审与风控专家 | tax-contract-generation-review |
| 3 | 法税同审与法务审查专家 | tax-legal-tax-review |

---

### 团11：审计与财税合规专家团
**主理人**：审计合规总监 · 统筹基建决算、国企经责与税务审计分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 基建竣工决算审计专家 | tax-construction-audit |
| 2 | 国有企业经济责任审计专家 | tax-soe-audit |
| 3 | 企业税务审计专家 | tax-tax-audit |

---

### 团12：财税法审与内控鉴证专家团
**主理人**：法审与内控鉴证总监 · 统筹内控鉴证、法税同审与涉税信用分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 涉税专业服务信用管理专家 | tax-service-credit |
| 2 | 内控审计与鉴证专家 | tax-internal-control-audit |
| 3 | 法税同审与法务审查专家 | tax-legal-tax-review |
| 4 | 税务稽查应对专家 | tax-inspection-case |
| 5 | 合同涉税评审与风控专家 | tax-contract-generation-review |

---

### 团13：房地产土增税合规专家团
**主理人**：土增税清算审核总监 · 统筹清算审核、成本分摊、存量房转让与争议复议分诊

| # | 专家名称 | 关联技能 |
|---|----------|----------|
| 1 | 土增税成本分摊专家 | tax-land-value-added |
| 2 | 存量房转让土增税审核专家 | tax-land-value-added |
| 3 | 尾盘销售土增税审核专家 | tax-land-value-added |
| 4 | 土增税争议复议专家 | tax-land-value-added |

---

## 三、专家检索路由

| 用户问法 | 推荐专家团 | 推荐专家 |
|----------|-----------|----------|
| "个人所得税怎么申报" / "年终奖计税" | 团1 个人所得税与跨境财富 | 个人境外投资税务专家 |
| "企业重组要交什么税" / "股权激励税务处理" | 团2 资本运作与重组 | 并购重组税务专家 / 员工持股平台税务专家 |
| "收到虚开发票怎么办" / "如何防范虚开" | 团3 发票合规与虚开风控 | 数电票合规与虚开防范专家 |
| "高新企业怎么认定" / "研发费用加计扣除" | 团4 税收优惠与高新资质 | 高企认定与研发加计专家 |
| "建筑行业税务有什么特殊" | 团5 行业税务专项 | 建筑施工行业税务专家 |
| "跨境电商零售进口怎么交税" | 团6 电商与跨境贸易 | 跨境贸易税务合规专家 |
| "被税局稽查了怎么办" / "税务行政复议" | 团7 税务稽查与争议解决 | 税务合规争议解决专家 |
| "企业全税种合规体检" | 团8 企业全税种合规 | 财税政策与风险合规专家（本技能） |
| "社保基数怎么合规调整" | 团9 社保与人力资本 | 社保入税与申报合规专家 |
| "事务所想用AI提升合规交付" | 团10 财税中介机构AI合规 | 中介机构智能合规咨询专家 |
| "基建工程竣工决算有什么坑" | 团11 审计与财税合规 | 基建竣工决算审计专家 |
| "内控要怎么建设才合规" | 团12 财税法审与内控鉴证 | 内控审计与鉴证专家 |
| "土地增值税清算怎么做" | 团13 房地产土增税合规 | 土增税成本分摊专家 |

> 路由由 MCP ask 工具自动完成，LLM 根据用户问题关键词匹配对应专家团和专家技能。
