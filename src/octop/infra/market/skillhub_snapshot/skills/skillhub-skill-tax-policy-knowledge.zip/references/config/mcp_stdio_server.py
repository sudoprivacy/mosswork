#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""财税政策 MCP · 通用 stdio 服务器（零第三方依赖，仅标准库）。

目的：让本技能包可被**任意支持 MCP 的 Agent / 客户端**直接以 stdio 方式运行，
      而不依赖特定 Agent 运行时。它通过 HTTP 将请求代理到公共云端 MCP 端点，
      对外暴露与云端 TOOLS_CATALOG 一致的安全工具面（7 个工具）：
      tax_policy_ask（含 format="structured" 结构化模式）/ risk_check /
      tax_calculate / kb_list / route_query / wiki_route / rd_template。

      [dalign 2026-09-27] 与服务端 mcp_server.py TOOLS_CATALOG 全面对齐：
      - TOOLS 4 → 7：补 route_query（多技能路由）/ wiki_route（章节级定位）/
        rd_template（研发费用模板结构），描述与 inputSchema 逐字同步服务端目录；
      - tax_policy_ask inputSchema 补 format（["", "structured"]）与
        top_n（1-20，默认 5，仅 structured 生效）两个参数；
      - 请求头补 X-App-Name / X-Skill-Name，payload 补 _meta（与服务端
        2026-09-27 归因规范一致，取值逻辑与 config/mcp_client.py 相同）；
      - CLIENT_VERSION 从硬编码改为动态读取 SKILL.md frontmatter version
        （与 config/mcp_client.py 同机制，消除版本漂移）。

典型接入（以任意 MCP 客户端为例）：
  {
    "mcpServers": {
      "tax-policy": {
        "command": "python",
        "args": ["<技能包目录>/config/mcp_stdio_server.py"]
      }
    }
  }

或直接复用云端 MCP 端点（若客户端支持 HTTP/SSE 型 MCP）：
  https://mcp.aitaxs.top/api/services/tax-policy-knowledge/mcp
"""
import json
import sys
import os
import urllib.request
import urllib.error

SERVICE_URL = "https://mcp.aitaxs.top/api/services/tax-policy-knowledge/mcp"
CLIENT_ID = "tax-policy-stdio"

_SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_SKILL_MD = os.path.join(_SKILL_DIR, "SKILL.md")


def _read_skill_version() -> str:
    """从 SKILL.md frontmatter 动态读取版本（与 config/mcp_client.py 同机制）。

    [dalign 2026-09-27] 此前硬编码 "4.0.0"，技能升版后 stdio 桥版本与
    客户端/服务端漂移；现改为与主客户端一致的 frontmatter 读取，失败时
    兜底 "4.0.0" 保持向后兼容。
    """
    default = "4.0.0"
    try:
        with open(_SKILL_MD, encoding="utf-8") as f:
            head = [f.readline() for _ in range(30)]
    except Exception:
        return default
    front, started = [], False
    for i, raw in enumerate(head):
        line = raw.strip()
        # [dalign] SKILL.md 首行存在历史反斜杠污染「\---」（与
        # config/mcp_client.py 同样兼容处理：剥掉反斜杠后按 --- 识别）
        if line.startswith("\\---"):
            line = line[1:].strip()
        if i == 0 and line == "---":
            started = True
            continue
        if i == 0 and line.startswith("---"):
            started = True
            line = line[3:].lstrip()
            if not line:
                continue
        if i > 0 and line == "---":
            break
        if started:
            front.append(line)
    for line in front:
        if line.startswith("version:"):
            val = line.split(":", 1)[1].strip()
            if len(val) >= 2 and val[0] == val[-1] and val[0] in ("'", '"'):
                val = val[1:-1].strip()
            return val or default
    return default


CLIENT_VERSION = _read_skill_version()


def _get_meta():
    """动态 _meta：与 config/mcp_client.py 同逻辑（精简版，仅标准库）。"""
    app = (
        os.environ.get("TAX_APP_NAME")
        or os.environ.get("WORKBUDDY_PRODUCT_NAME")
        or os.environ.get("CODEBUDDY_AGENT_NAME")
        or os.environ.get("AGENT_NAME")
        or os.environ.get("RUNNER_NAME")
        or os.environ.get("CLIENT_NAME")
        or os.environ.get("APP_NAME")
        or ("ClaudeDesktop" if "CLAUDE_DESKTOP_CONVERSATION_ID" in os.environ else None)
        or ("Cursor" if "CURSOR_SESSION_ID" in os.environ else None)
        or ("Cline" if os.environ.get("CLINE_SESSION_ID") else None)
        or "GenericAgent"
    )
    skill = os.environ.get("TAX_SKILL_NAME") or os.environ.get("TAX_SKILL")
    if not skill:
        skill = os.environ.get("WORKBUDDY_SKILL_NAME") or os.environ.get("CODEBUDDY_SKILL_NAME")
    if not skill:
        for name_var in ("CODEBUDDY_AGENT_NAME", "AGENT_NAME", "RUNNER_NAME"):
            name = os.environ.get(name_var)
            if name:
                skill = "tax-" + name.lower().replace(" ", "-")
                break
    if not skill:
        skill = CLIENT_ID
    return {"app": app, "skill": skill}


# [dalign 2026-09-27] TOOLS 与服务端 mcp_server.py TOOLS_CATALOG 逐字同步
# （8 个独立安全工具；描述与 inputSchema 一致；auto_update/online_search/
#  submit_feedback 为服务端内部运维操作，不进安全目录，此处同样不暴露）。
# [toolname_compat 2026-09-28] 服务端 TOOLS_CATALOG 另有 3 个别名条目
# （ask/risk/kb），通过 path_map 在 _rpc 中路由到对应的完整工具，
# 此处 TOOLS 列表不重复列出别名，避免 list_tools 暴露重复条目。
TOOLS = [
    {
        "name": "tax_policy_ask",
        "description": "财税政策问答（含风险应对政策依据；内置 wiki 章节级高效检索，口语/长问法自动路由到最相关的知识库章节）",
        "inputSchema": {"type": "object", "properties": {
            "question": {"type": "string"},
            "category": {"type": "string"},
            "format": {"type": "string", "enum": ["", "structured"],
                       "description": "响应格式：缺省为空字符串（仅 answer + score）；传 'structured' 时附加 tax_types / route_meta / candidates 结构化分类信息，供客户端 LLM 动态筛选过滤"},
            "top_n": {"type": "integer", "default": 5, "minimum": 1, "maximum": 20,
                      "description": "仅 format=structured 生效：返回候选段落条数上限"},
        }},
    },
    {
        "name": "risk_check",
        "description": "企业税务风险初筛（关键词 + 结构化情形双引擎，自然语言 scenario，≤2000 字）。返回 overall_risk / risks 及 policy_basis（知识库政策依据：主题、章节、原文摘录），客户端无需二次追问即可给出应对依据。",
        "inputSchema": {"type": "object", "properties": {
            "scenario": {"type": "string", "description": "风险场景描述，≤2000 字"},
            "level_filter": {"type": "string", "description": "风险等级过滤（high/medium/low）；risk_check 工具用此参数名"},
            "level": {"type": "string", "description": "风险等级过滤（high/medium/low）；risk 工具（别名）用此参数名；与 level_filter 等价，服务端自动二选一生效"},
        }},
    },
    {
        "name": "tax_calculate",
        "description": "各类税费计算：增值税(vat)/企业所得税(cit)/个人所得税(pit)/经营所得(business)/研发费用加计扣除(rd_deduction)/资源税(resource_tax,按省份税率表)/城建税及教育费附加(surcharge)/环境保护税(environmental_tax)/印花税(stamp_tax)/社保费(social_insurance)/消费税(consumption_tax)/残保金(disability_fund)/房产税(property_tax)/城镇土地使用税(land_use_tax)/土地增值税(land_appreciation_tax)/契税(deed_tax)/车辆购置税(vehicle_purchase_tax)/车船税(vehicle_vessel_tax)/烟叶税(tobacco_leaf_tax)/耕地占用税(farmland_occupation_tax)。tax_type 支持中英文别名，资源税可传 province 与 rate 覆盖；params 数值支持\"100万\"等中文单位；结果附 policy_basis 政策依据；未知税种返回 suggestions 候选。",
        "inputSchema": {"type": "object", "properties": {
            "tax_type": {"type": "string"},
            "params": {"type": "string", "description": "JSON 字符串格式的计算参数"},
        }},
    },
    {
        "name": "kb_list",
        "description": "知识库概览（仅元数据，不回正文）",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "route_query",
        "description": "查询路由（基于 matrix_router 判断最匹配的技能slug，适合在多技能协作时先确定目标技能）",
        "inputSchema": {"type": "object", "properties": {
            "question": {"type": "string", "description": "自然语言查询"},
        }, "required": ["question"]},
    },
    {
        "name": "wiki_route",
        "description": "知识库章节级检索定位：输入自然语言问题，返回最匹配的 references 专题文件与章节（rank/file/section 章节标题/line_no 起始行号/score 相关度/topic 主题/evidence 证据元数据），并回显识别到的税种词（tax_terms）。只回元数据不下发正文，用于客户端/LLM 先定位「该看哪个文件的哪一节」再决定精读或调用 tax_policy_ask，避免直接全文问答时命错章节。",
        "inputSchema": {"type": "object", "properties": {
            "question": {"type": "string", "description": "自然语言问题"},
            "top_k": {"type": "integer", "default": 1, "minimum": 1, "maximum": 10,
                      "description": "按相关度降序返回的候选章节总数（默认1）"},
            "max_files": {"type": "integer", "default": 12,
                          "description": "扫描的专题文件上限（默认12）"},
            "per_file": {"type": "boolean", "default": False,
                         "description": "true 时改为每个命中的文件各取 top_k 条章节（证据面广，适合需要完整证据链的场景；默认 false=全局取前 top_k 条）"},
        }, "required": ["question"]},
    },
    {
        "name": "rd_template",
        "description": "流式读取研发费用标准表单模板（仅返回结构化数据，不下发原始文件），用于生成底稿/报告时填充范例内容。返回数据包含：单元格值、合并单元格范围、列宽、行高、字体/填充/边框/对齐样式。客户端可用这些数据重建完整格式的 Excel 文件。",
        "inputSchema": {"type": "object", "properties": {
            "template": {"type": "string", "enum": ["kelite", "medical"],
                         "description": "模板类型：kelite=硬质合金行业（32表），medical=生物医药行业（36表）"},
            "sheet_name": {"type": "string", "description": "可选：指定表单名称，不传则返回总览（所有表名+行次摘要）"},
            "max_rows": {"type": "integer", "default": 50,
                         "description": "每表最多返回行数（默认50，防止响应过大）"},
            "include_styles": {"type": "boolean", "default": True,
                               "description": "是否包含单元格样式信息（字体/填充/边框/对齐），默认true"},
        }, "required": ["template"]},
    },
]


def _rpc(method, params, rid=1):
    payload = {
        "jsonrpc": "2.0", "id": rid, "method": method,
        "params": params,
        # [dalign 2026-09-27] _meta 归因（与服务端 2026-09-27 规范一致）
        "_meta": _get_meta(),
    }
    data = json.dumps(payload).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "User-Agent": f"tax-policy-stdio/{CLIENT_VERSION}",
        "X-Client-Id": CLIENT_ID,
        "X-Client-Version": CLIENT_VERSION,
        "X-App-Name": _get_meta()["app"],
        "X-Skill-Name": _get_meta()["skill"],
    }
    req = urllib.request.Request(SERVICE_URL, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return {"error": {"code": e.code, "message": e.read().decode("utf-8", "replace")[:300]}}
    except Exception as e:  # 网络/超时等：优雅降级为本地提示
        return {"error": {"code": -32000, "message": f"云端服务暂不可用：{e}"}}


def _readline():
    line = sys.stdin.readline()
    if not line:
        return None
    return line.strip()


def main():
    # 强制 stdin/stdout 为 utf-8（Windows 控制台默认 GBK 易乱码）
    try:
        if hasattr(sys.stdin, "reconfigure"):
            sys.stdin.reconfigure(encoding="utf-8")
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    # 初始化时探测客户端 Agent 类型与接入方式（写盘需 TAX_ENABLE_AUTOSETUP=1）
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        try:
            from init_agent import detect_and_setup as _detect_and_setup
        except ImportError:
            from .init_agent import detect_and_setup as _detect_and_setup
        _detect_and_setup(dry_run=True)  # stdio 启动路径恒为探测-only，不写盘；写盘只经 auto_setup(dry_run=False) + TAX_ENABLE_AUTOSETUP/TAX_AUTOSETUP_CONFIRM 双确认
    except Exception:
        pass

    for line in iter(_readline, None):
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        method = msg.get("method")
        mid = msg.get("id")
        params = msg.get("params", {}) or {}

        if method == "initialize":
            resp = {
                "jsonrpc": "2.0", "id": mid,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "tax-policy-stdio", "version": CLIENT_VERSION},
                },
            }
        elif method == "notifications/initialized":
            continue
        elif method == "tools/list":
            resp = {"jsonrpc": "2.0", "id": mid, "result": {"tools": TOOLS}}
        elif method == "tools/call":
            name = params.get("name")
            arguments = params.get("arguments", {}) or {}
            res = _rpc("tools/call", {"name": name, "arguments": arguments})
            content = []
            if "error" in res:
                content = [{"type": "text", "text": f"错误：{res['error'].get('message', '')}"}]
            else:
                r = res.get("result", res)
                txt = r.get("content", [{}])[0].get("text", "") if r.get("content") else ""
                if not txt and r.get("structuredContent"):
                    txt = json.dumps(r["structuredContent"], ensure_ascii=False)
                content = [{"type": "text", "text": txt or json.dumps(r, ensure_ascii=False)}]
            resp = {"jsonrpc": "2.0", "id": mid, "result": {"content": content}}
        else:
            resp = {"jsonrpc": "2.0", "id": mid, "result": {}}
        sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
