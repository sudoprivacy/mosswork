# -*- coding: utf-8 -*-
"""
投行/董办 Skill 报告通用 md -> html 渲染器 v2
用法: python md2html.py <input.md> <output.html> [标题]

v2 修复与增强:
1. 【关键修复】支持列表项续行 —— 带缩进正文的有序列表不再被拆成多个 <ol>，
   序号连续递增（修复"子项序号全部显示为 1."的缺陷）。
2. 连续 > 引用行合并为单个 blockquote；blockquote 去除背景底色，仅保留左侧竖线，
   避免大段正文被染色导致排版不自然。
3. 占位符行内高亮：【待补充】/【待核实事实】黄色底；【需确认…】橙红底（仅标记本身，不染整段）。
4. 样式对齐 Skill《HTML 输出样式规范》：米白页面 #F5F1E8、深蓝页眉 #1F4E79、浅蓝 AI 声明条 #EAF1F8。
5. 支持 h1-h5、表格、代码块、行内代码、链接、分隔线、嵌套段落。
"""
import re, html, sys

PLACEHOLDER_TODO = re.compile(r"【(待补充[^】]*|待核实事实[^】]*|需补充[^】]*)】")
PLACEHOLDER_CONFIRM = re.compile(r"【(需确认[^】]*|重要假设[^】]*)】")


def inline(t):
    t = html.escape(t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"<i>\1</i>", t)
    t = re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)", r'<a href="\2" target="_blank">\1</a>', t)
    t = PLACEHOLDER_CONFIRM.sub(r'<span class="ph-confirm">【\1】</span>', t)
    t = PLACEHOLDER_TODO.sub(r'<span class="ph-todo">【\1】</span>', t)
    return t


OL_RE = re.compile(r"^(\d+)\.\s+(.*)$")
UL_RE = re.compile(r"^[-*]\s+(.*)$")


def is_ol(s):
    return bool(OL_RE.match(s))


def is_ul(s):
    return bool(UL_RE.match(s))


def render_item_body(parts):
    """列表项内容：首段为 li 主体，后续续行渲染为 li 内段落。"""
    if not parts:
        return ""
    out = [inline(parts[0])]
    for p in parts[1:]:
        out.append(f'<p class="li-cont">{inline(p)}</p>')
    return "".join(out)


def _strip_agent_footer(md):
    # 清理子 agent 在 Markdown 末尾硬塞的原生 HTML 声明段落，避免被转义为文本
    md = re.sub(r'\n?<p[^>]*style="[^"]*"[^>]*>\s*⚠\ufe0f?\s*AI生成.*?</p>\s*$', '', md,
                flags=re.IGNORECASE | re.DOTALL)
    # 只删最后一行的纯文本声明，不扫描全文，避免误伤正文中的 AI 生成声明
    lines = md.split('\n')
    footer_re = re.compile(r'^\s*⚠\ufe0f?\s*AI生成[·•\s].*$', flags=re.IGNORECASE)
    while lines and not lines[-1].strip():
        lines.pop()
    if lines and footer_re.match(lines[-1]):
        lines.pop()
    return '\n'.join(lines)


def md_to_html(md, title):
    md = _strip_agent_footer(md)
    lines = md.split("\n")
    out = []
    i = 0
    n = len(lines)

    def flush_table(buf):
        rows = []
        for r in buf:
            cells = [inline(c.strip()) for c in r.strip().strip("|").split("|")]
            rows.append(cells)
        if len(rows) < 2:
            return ""
        ncols = max(len(r) for r in rows)
        # 计算每列去标签后的最大内容长度，用于列宽适配
        maxlens = [0] * ncols
        for row in rows:
            for c in range(ncols):
                txt = re.sub(r"<[^>]+>", "", row[c]) if c < len(row) else ""
                maxlens[c] = max(maxlens[c], len(txt))
        def cls(c):
            # 短内容列（序号/日期/代码/百分比等）加窄列类，宽度收缩且不换行
            return ' class="tn"' if maxlens[c] <= 6 else ""
        h = "<tr>" + "".join(f"<th{cls(c)}>{rows[0][c] if c < len(rows[0]) else ''}</th>" for c in range(ncols)) + "</tr>"
        b = ""
        for row in rows[2:]:
            b += "<tr>" + "".join(f"<td{cls(c)}>{row[c] if c < len(row) else ''}</td>" for c in range(ncols)) + "</tr>"
        return f'<table class="t">{h}{b}</table>'

    def parse_list(i, ordered):
        """解析一个列表块（支持续行与块间空行），返回 (html, next_i)"""
        matcher = OL_RE if ordered else UL_RE
        items = []          # 每项为 [首行, 续行...]
        start_no = None
        while i < n:
            raw = lines[i]
            s = raw.strip()
            m = matcher.match(s)
            if m:
                if ordered and start_no is None:
                    start_no = int(m.group(1))
                items.append([m.group(2) if ordered else m.group(1)])
                i += 1
                continue
            # 续行：有缩进且非空、且不是新列表项
            if s and (raw.startswith("  ") or raw.startswith("\t")) and items:
                items[-1].append(s)
                i += 1
                continue
            # 空行：向前看是否仍属同一列表
            if s == "":
                j = i
                while j < n and lines[j].strip() == "":
                    j += 1
                if j < n:
                    nxt_raw = lines[j]
                    nxt = nxt_raw.strip()
                    if matcher.match(nxt) or (nxt and (nxt_raw.startswith("  ") or nxt_raw.startswith("\t"))):
                        i = j
                        continue
                break
            break
        lis = "".join(f"<li>{render_item_body(p)}</li>" for p in items)
        if ordered:
            st = f' start="{start_no}"' if start_no and start_no != 1 else ""
            return f"<ol{st}>{lis}</ol>", i
        return f"<ul>{lis}</ul>", i

    while i < n:
        raw = lines[i]
        s = raw.strip()

        # 代码块
        if s.startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            i += 1
            out.append("<pre class='code'>" + html.escape("\n".join(buf)) + "</pre>")
            continue

        # 表格
        if s.startswith("|") and s.endswith("|"):
            buf = []
            while i < n and lines[i].strip().startswith("|") and lines[i].strip().endswith("|"):
                buf.append(lines[i].strip())
                i += 1
            out.append(flush_table(buf))
            continue

        # 引用（连续行合并）
        if s.startswith(">"):
            buf = []
            while i < n and lines[i].strip().startswith(">"):
                buf.append(re.sub(r"^>\s?", "", lines[i].strip()))
                i += 1
            body = "".join(f"<p>{inline(x)}</p>" for x in buf if x.strip())
            out.append(f"<blockquote>{body}</blockquote>")
            continue

        if s == "":
            i += 1
            continue

        if re.fullmatch(r"-{3,}|\*{3,}|_{3,}", s):
            out.append("<hr/>")
            i += 1
            continue

        if s.startswith("##### "):
            out.append(f"<h5>{inline(s[6:])}</h5>"); i += 1; continue
        if s.startswith("#### "):
            out.append(f"<h4>{inline(s[5:])}</h4>"); i += 1; continue
        if s.startswith("### "):
            out.append(f"<h3>{inline(s[4:])}</h3>"); i += 1; continue
        if s.startswith("## "):
            out.append(f"<h2>{inline(s[3:])}</h2>"); i += 1; continue
        if s.startswith("# "):
            out.append(f"<h1>{inline(s[2:])}</h1>"); i += 1; continue

        if is_ol(s):
            frag, i = parse_list(i, True)
            out.append(frag)
            continue
        if is_ul(s):
            frag, i = parse_list(i, False)
            out.append(frag)
            continue

        out.append(f"<p>{inline(s)}</p>")
        i += 1

    body = "\n".join(x for x in out if x)

    css = """
* { box-sizing: border-box; }
body { margin:0; background:#F5F1E8; font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif; color:#222; line-height:1.8; }
header { background:#1F4E79; color:#fff; padding:14px 28px; font-size:14.5px; }
.aibox { background:#EAF1F8; color:#2E5E8C; padding:9px 28px; font-size:12.5px; border-bottom:1px solid #d3e0ee;}
.page { max-width:920px; margin:28px auto; background:#fff; border:1px solid #D9D2C5; border-radius:8px; box-shadow:0 1px 5px rgba(0,0,0,.06); padding:38px 46px 52px;}
h1 { color:#1F4E79; font-size:26px; border-bottom:3px solid #1F4E79; padding-bottom:12px; margin-top:8px; margin-bottom:22px;}
h2 { color:#1F4E79; font-size:20px; margin-top:40px; margin-bottom:14px; border-left:5px solid #1F4E79; padding-left:12px;}
h3 { color:#2E5E8C; font-size:16.5px; margin-top:28px; margin-bottom:10px;}
h4 { color:#3a6ea5; font-size:14.8px; margin-top:20px;}
h5 { color:#4a7ab0; font-size:13.8px; margin-top:16px;}
p { margin:12px 0;}
ul,ol { margin:12px 0; padding-left:28px;}
li { margin:9px 0;}
li > p.li-cont { margin:6px 0 0; color:#333;}
blockquote { border-left:4px solid #1F4E79; background:transparent; padding:4px 0 4px 16px; margin:16px 0; color:#3a4a5a;}
blockquote p { margin:6px 0;}
table.t { border-collapse:collapse; width:100%; margin:18px 0; font-size:13.5px; table-layout:auto;}
table.t th { background:#1F4E79; color:#fff; padding:10px 12px; text-align:center; font-weight:600; border:1px solid #1F4E79;}
table.t td { border:1px solid #D9D2C5; padding:9px 12px; vertical-align:middle;}
table.t .tn { width:1%; white-space:nowrap; }
pre.code { background:#f7f5f0; border:1px solid #D9D2C5; border-radius:6px; padding:14px 16px; overflow:auto; font-size:12.5px; font-family:Consolas,Menlo,monospace; line-height:1.6;}
code { background:#f0ede6; padding:1px 5px; border-radius:3px; font-size:90%; font-family:Consolas,Menlo,monospace;}
hr { border:none; border-top:1px solid #e3ddd0; margin:32px 0;}
a { color:#1F4E79; }
.ph-todo { background:#FFF3BF; padding:0 3px; border-radius:2px; }
.ph-confirm { background:#FFD8CC; padding:0 3px; border-radius:2px; }
footer { color:#888; font-size:13px; margin-top:40px; padding-top:16px; border-top:1px solid #e3ddd0; }
"""
    header_title = f" · {html.escape(title)}" if title.strip() else ""
    return f"""<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title) if title.strip() else '报告'}</title>
<style>{css}</style></head>
<body>
<header>欢迎关注 IMA 知识号「搬砖小能手」{header_title}</header>
<div class="aibox">AI 生成声明：本报告由 AI 自动生成，仅供参考，不构成专业意见，使用者应自行核实关键信息并独立判断。</div>
<div class="page">{body}
<footer>AI 生成 · 仅供参考 · 不构成专业意见。法规及案例以官方原文与最新版本为准。</footer>
</div>
</body></html>"""


if __name__ == "__main__":
    inp, outp = sys.argv[1], sys.argv[2]
    title = sys.argv[3] if len(sys.argv) > 3 else ""
    with open(inp, encoding="utf-8") as f:
        md = f.read()
    doc = md_to_html(md, title)
    with open(outp, "w", encoding="utf-8") as f:
        f.write(doc)
    print("written", outp, len(doc), "bytes")
