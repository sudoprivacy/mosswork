# 本 Skill 绑定的知识库

| 订阅知识库（知识号） | 检索ID（实例） |
|---|---|
| IPO被否案例库（持续更新）「搬砖小能手」 | `ima_kb_ZI6beoJY` |

检索须严格限定在上述知识库。报告正文仅出现知识库名称（如 IMA「IPO被否案例库（持续更新）」），**严禁输出任何知识库 ID**。

> 注：上述 ID 为 2026-11-07 实测有效的知识库 ID，可能随平台调整变化；检索前请确认账号可访问对应知识库。 若 `search_knowledge` 返回 `knowledge_base_id 无效`，可用 `search_knowledge_base` 按完整知识库名称重新确认当前 ID。唯一可用性判定 = 一次真实 `search_knowledge` 的返回。
