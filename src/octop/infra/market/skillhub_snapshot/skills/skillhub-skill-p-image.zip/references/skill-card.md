## Description: <br>
p-image helps agents generate fast text-to-image outputs for product shots, hero visuals, mood boards, and draft photos through Pruna P-API. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[pruna-ai](https://clawhub.ai/user/pruna-ai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creative operators use this skill to turn text prompts into image generation API calls and review the resulting assets for fit before downstream editing, try-on, avatar, or animation workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Prompts, generation parameters, and uploaded assets are sent to Pruna's external API. <br>
Mitigation: Do not include secrets or sensitive personal or business data, and only upload or generate identifiable-person assets when rights and consent are clear. <br>
Risk: The skill uses paid API calls authenticated with a Pruna API key. <br>
Mitigation: Verify PRUNA_API_KEY before generation, avoid exposing full keys in chat or committed files, and confirm cost-sensitive settings before paid requests. <br>
Risk: Generated images may contain visual artifacts, stray text, watermarks, or unsuitable representations. <br>
Mitigation: Apply the diversity and quality checklists, inspect saved outputs before downstream use, and regenerate or edit assets that do not meet the intended use. <br>


## Reference(s): <br>
- [p-image on ClawHub](https://clawhub.ai/pruna-ai/skills/p-image) <br>
- [Pruna p-image model docs](https://docs.api.pruna.ai/guides/models/p-image) <br>
- [Pruna P-API shared reference](artifact/references/pruna-api.md) <br>
- [API credentials guidance](artifact/references/api-credentials.md) <br>
- [p-image quality checklist](artifact/references/p-image-quality-checklist.md) <br>
- [Generation diversity guidance](artifact/references/generation-diversity.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with curl examples and JSON request bodies] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires a text prompt and Pruna API key; optional settings include aspect_ratio, seed, lora weights, and safety-checker controls.] <br>

## Skill Version(s): <br>
1.0.6 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
