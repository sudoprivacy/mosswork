# -*- coding: utf-8 -*-
"""商标尼斯分类选择器（gmai-trademark-class）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：核心类别建议清单（逐条对应商品/服务项目）；防御与关联类别布局建议；类别选择的成本与风险权衡说明
建议输入（专业字段）：事项类型；主体；关键事实
"""
import json, os, re, sys, time

SLUG = "gmai-trademark-class"
TITLE = "商标尼斯分类选择器"
PRICE_FEN = 4590
CATEGORY = "知识产权与专利商标"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['事项类型', True, ['法律事项', '文书类型', '争议类型'], '决定适用要件与文书结构'], ['主体', True, ['当事人', '权利人', '义务人'], '主体资格决定请求能否成立'], ['关键事实', True, ['事实', '案情', '经过'], '按时间顺序的事实链，是分析基础'], ['时间线', False, ['时间', '节点', '发生时间'], '决定起算点与期限'], ['已有证据', False, ['证据', '材料', '凭证'], '评估证明强度与补强方向'], ['标的/争议金额', False, ['金额', '标的额', '争议数额'], '影响程序选择与成本评估']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'reqs': [['权利基础与权属', '权利是否有效、权属是否清晰、有无共有或质押负担', '权属证明文件与登记簿记载'], ['保护范围确定', '保护范围如何界定（权利要求/注册类别/作品要素）', '权利文件的权利要求或登记内容'], ['技术或标识比对', '被控方案是否落入保护范围（逐项特征或标识比对）', '全面覆盖原则与等同或近似判断规则'], ['法定要件成立', '是否存在法定排除情形与无效事由', '法定要件与排除条款的现行规定'], ['侵权或不正当竞争成立', '行为是否构成侵权或不当获取', '侵权构成与举证责任规则'], ['期限与救济路径', '是否在有效期内、可主张的救济方式与期限', '时效与救济途径的现行规定']]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['《中华人民共和国民法典》合同编与侵权责任编相关要件（按事项适用）', '《中华人民共和国专利法》《商标法》《著作权法》相关条款（按权利类型适用）', '《中华人民共和国劳动合同法》相关条款（按劳动争议事项适用）', '民事诉讼时效与举证责任的一般规则', '证据形式与证明力的一般规则（书证、电子数据、鉴定意见等）', '管辖与程序选择的一般规则（标的额、地域、专属管辖）']
# 自检项（输入完备度）
CHECKS = [['商标尼斯分类选择·权利基础核查', ['商标尼斯分类选择', '商标尼斯分类选择器'], '先核查权属、有效性与保护地域范围'], ['商标尼斯分类选择·检索与比对', ['商标尼斯分类选择器', '商标尼斯分类选择'], '构建检索式并逐项做技术特征或标识比对'], ['商标尼斯分类选择·法律要件分析', ['商标尼斯分类选择'], '按法定要件分析授权前景或侵权成立要件'], ['商标尼斯分类选择·诚信红线', ['商标尼斯分类选择'], '识别编造证据与抄袭他人方案情形，命中即终止'], ['商标尼斯分类选择·策略与清单', ['商标尼斯分类选择', '商标尼斯分类选择器'], '输出申请或维权路径与证据准备清单']]
# 交付物构成
DELIVERABLES = ['核心类别建议清单（逐条对应商品/服务项目）', '防御与关联类别布局建议', '类别选择的成本与风险权衡说明']
FOOTER = "本报告不构成法律或代理意见；检索结论不保证穷尽，建议专利代理师复核。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """法律事项交付物：主体与权利基础 → 效力核查 → 法定要件分析 → 期限时序 → 文书结构 → 证据清单 → 风险与替代"""
    P = ctx["spec"]["params"]; L = []
    matter = ctx["fv"]("事项类型") or ctx["spec"]["title"]
    party = ctx["fv"]("主体")
    facts = ctx["fv"]("关键事实")
    timeline = ctx["fv"]("时间线")
    evid = ctx["fv"]("已有证据")
    amount = ctx["fv"]("标的/争议金额")
    reqs = P.get("reqs") or []           # [[要件, 本案核查问题, 依据方向], ...]

    L.append(("一、事项与主体", [
        "- 事项类型：%s" % brief(matter, 50),
        "- 涉及主体：%s" % (brief(party, 50) or "（未提供，主体资格直接决定请求能否成立，必须补充）"),
        "- 标的/争议金额：%s" % (brief(amount, 30) or "（未提供，影响管辖与程序选择）"),
        "- 关键事实：%s" % (brief(facts, 80) or "（未提供，需按时间顺序补充事实链）"),
        "",
        "> 本节结论依据当事人提供的事实与材料；未核实的事实一律标注「待核实」，不得作为结论基础。",
    ]))

    L.append(("二、权利基础与效力核查", [
        "| 核查项 | 核查内容 | 结论 |", "|---|---|---|",
        "| 主体资格 | 权利人或义务人是否具备相应资格与权限 | 待核实 |",
        "| 权属与有效性 | 权属是否清晰、是否存在共有/质押/许可负担 | 待核实 |",
        "| 保护范围/约定范围 | 与主张范围是否一致（地域、期限、类别） | 待核实 |",
        "| 存续状态与期限 | 是否在有效期内、是否已届期或可续展 | 待核实 |",
        "| 在先权利冲突 | 是否存在在先权利或既有约定构成障碍 | 待核实 |",
    ]))

    rows = ["| 序号 | 法定要件 | 本案核查问题 | 拟依据方向 | 结论 |", "|---|---|---|---|---|"]
    for i, x in enumerate(reqs, 1):
        rows.append("| %d | %s | %s | %s | 待核实（须以证据支撑） |" % (i, x[0], x[1], x[2]))
    if not reqs:
        rows.append("| 1 | 待补充要件 | 依事项类型展开法定要件 | 现行法律规定 | 待核实 |")
    L.append(("三、法定要件分析表", rows))

    tl = ["| 节点 | 时间 | 法律意义 | 是否已届满 |", "|---|---|---|---|"]
    tl.append("| 事实发生时点 | %s | 决定起算点与时效 | 待核实 |" % (brief(timeline, 40) or "待补充"))
    tl.append("| 时效/期限届满日 | 待按适用时效规则计算 | 逾期将影响救济途径 | 待核实 |")
    tl.append("| 举证期限 | 按程序要求确定 | 逾期提交可能不被采纳 | 待核实 |")
    tl.append("| 应诉/答复期限 | 按送达文件确定 | 逾期可能产生不利后果 | 待核实 |")
    L.append(("四、期限与时序", tl))

    L.append(("五、文书结构建议", [
        "以下为按事项类型给出的文书骨架，具体表述应由承办律师或代理师定稿：",
        "",
        "| 部分 | 应载明内容 | 要点 |", "|---|---|---|",
        "| 首部 | 当事人信息、文书名称 | 主体信息与登记一致 |",
        "| 请求/主张 | 明确的请求事项与金额 | 请求须具体、可执行 |",
        "| 事实与理由 | 按时间顺序的事实 + 要件对应 | 每项事实指向一个要件 |",
        "| 证据 | 证据目录与证明目的 | 一证一目的 |",
        "| 结尾 | 签署、日期、附件目录 | 形式要件齐全 |",
    ]))

    ev = ["| 序号 | 证据类型 | 证明目的 | 取得方式 | 证明强度初判 |", "|---|---|---|---|---|"]
    ev.append("| 1 | 书面文件（合同/往来函件） | 证明约定内容与履行情况 | 原件核对 | 较强 |")
    ev.append("| 2 | 电子数据（聊天/邮件/日志） | 证明事实经过与意思表示 | 公证或可信时间戳 | 中（需完整性与身份要素） |")
    ev.append("| 3 | 财务凭证（发票/流水） | 证明金额与损失 | 银行或税务调取 | 较强 |")
    ev.append("| 4 | 第三方证明/鉴定意见 | 证明专业事实 | 有资质机构出具 | 较强 |")
    if evid:
        ev.append("| 5 | 当事人已有材料 | %s | 需逐项核对原件 | 待评估 |" % brief(evid, 40))
    L.append(("六、证据清单", ev))

    L.append(("七、风险与替代方案", [
        "| 风险点 | 说明 | 应对 |", "|---|---|---|",
        "| 事实不清 | 关键事实缺乏证据支撑 | 先固定证据再推进程序 |",
        "| 时效风险 | 存在逾期可能 | 立即核算时效并保留主张痕迹 |",
        "| 主体瑕疵 | 资格或权限不足 | 补正授权或变更主体 |",
        "| 执行风险 | 对方履行能力不足 | 评估保全与担保措施 |",
        "| 替代路径 | 协商/调解/仲裁/诉讼成本不同 | 按金额与时间成本择优 |",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
