# 部署到 HTTPS 服务器

## 前置条件

- [ ] 微信支付商户号(完成 API 安全配置)
- [ ] SkillHub 开发者密钥(商户中心生成)
- [ ] 公网服务器(本项目用 8.166.118.240)
- [ ] 域名(已解析到服务器)
- [ ] SSL 证书(Let's Encrypt 或其他)
- [ ] Go 1.21+ / Python 3.11+ / Java 17+

## 部署流程(Go 示例)

### Step 1:SSH 登录

```bash
ssh root@8.166.118.240
```

### Step 2:安装运行时

```bash
# Go
wget https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
rm -rf /usr/local/go
tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
source ~/.bashrc
```

### Step 3:上传代码

```bash
# 本地
scp -r service/ root@8.166.118.240:/opt/pay-skill/
```

### Step 4:配置环境变量

```bash
ssh root@8.166.118.240
cd /opt/pay-skill/service
cp .env.example .env
nano .env
```

填入:
```bash
# 微信支付
MCH_ID=你的商户号
APP_ID=你的应用ID
SERIAL_NO=证书序列号
PRIVATE_KEY_PATH=/etc/skillhub/apiclient_key.pem
MCH_APIV3_KEY=你的APIv3密钥

# SkillHub
SKILLHUB_DEVELOPER_ID=sh-XXXXXXXX
SKILLHUB_PUB_KEY_ID=PUB_KEY_xxx
SKILLHUB_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nxxx\n-----END PRIVATE KEY-----"

# Skill
SKILL_ID=your-skill-slug
SKILL_VERSION=1.0.0
```

### Step 5:上传商户私钥

```bash
mkdir -p /etc/skillhub
nano /etc/skillhub/apiclient_key.pem
# 粘贴 apiclient_key.pem 内容
chmod 600 /etc/skillhub/apiclient_key.pem
```

### Step 6:编译 + 启动

```bash
go mod tidy
go build -o pay-skill-service
./pay-skill-service &
```

### Step 7:配置 HTTPS(Nginx)

```bash
# 安装
apt update && apt install -y nginx certbot python3-certbot-nginx

# 申请证书
certbot --nginx -d your-merchant-domain.com

# 配置反向代理
cat > /etc/nginx/sites-available/pay-skill <<EOF
server {
    listen 443 ssl;
    server_name your-merchant-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-merchant-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-merchant-domain.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

ln -s /etc/nginx/sites-available/pay-skill /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### Step 8:systemd 守护

```bash
cat > /etc/systemd/system/pay-skill.service <<EOF
[Unit]
Description=Pay Skill Service
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/pay-skill/service
EnvironmentFile=/opt/pay-skill/service/.env
ExecStart=/opt/pay-skill/service/pay-skill-service
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable pay-skill
systemctl start pay-skill
systemctl status pay-skill
```

### Step 9:配置微信支付回调

- 微信支付商户平台 -> 产品中心 -> Native 支付 -> 支付配置
- 支付回调:`https://your-merchant-domain.com/api/pay/notify`
- 退款回调:`https://your-merchant-domain.com/api/refund/notify`

### Step 10:测试

```bash
# 本地测试
curl -X POST https://your-merchant-domain.com/api/resource \
  -H "Content-Type: application/json" \
  -d '{"query": "test"}'

# 预期:HTTP 402 + WeixinPay-Required + X-Out-Trade-No Header
```

## 监控与维护

### 关键日志

```bash
# 应用日志
journalctl -u pay-skill -f

# Nginx 访问日志
tail -f /var/log/nginx/access.log

# 错误日志
tail -f /var/log/nginx/error.log
```

### 关键指标

- 支付成功率(应 > 95%)
- 平均响应时间(应 < 1s)
- 退款率(应 < 5%)
- 微信支付回调成功率(应 > 99%)

### 常见问题排查

| 症状 | 排查命令 |
|---|---|
| 服务挂了 | `systemctl status pay-skill` |
| 证书过期 | `certbot certificates` |
| 端口被占 | `netstat -tlnp \| grep 8080` |
| 微信支付 401 | 重下载平台证书 |

## 备份

定期备份:
- `/opt/pay-skill/`(代码)
- `/etc/skillhub/`(证书)
- 数据库(如果有)
