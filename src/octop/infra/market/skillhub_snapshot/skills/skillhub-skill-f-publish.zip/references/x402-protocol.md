# X402 协议详细说明

## 协议本质

X402 是基于 HTTP 402 (Payment Required) 状态码的支付协议。Agent 调用商户服务时,如果没有支付,服务端返回 402 + 支付凭证;Agent 调起支付,用户确认后,Agent 重新调用获得付费内容。

## 4 段架构

```
① Agent      -> 商户服务   POST /api/resource {"query":"xxx"}
② 商户服务    -> 微信支付   Native 下单(微信支付 API 证书签名)-> code_url
③ 商户服务    -> 微信支付   AI 预下单(SkillHub 开发者密钥签名)-> payment_code
④ 商户服务    -> Agent      HTTP 402 + WeixinPay-Required + X-Out-Trade-No

⑤ Agent      -> 微信支付    调用 weixinpay_pay(paymentCode=xxx)
⑥ 用户       -> 微信支付    确认并完成支付
⑦ Agent      -> 商户服务    POST /api/resource + X-Out-Trade-No Header
⑧ 商户服务    -> 微信支付    查单验证(微信支付 API 证书签名)-> trade_state=SUCCESS
⑨ 商户服务    -> Agent      HTTP 200 + 付费内容
```

## 关键时序

- `payment_code` 有效期最长 **15 分钟**,过期需重新下单
- `out_trade_no` 必须 <= 32 字符
- 同一 `out_trade_no` 只履约一次(幂等)

## 5 行签名串(AI 预下单核心)

签名串固定为 5 行,每行以 `\n` 结尾(最后一行也要保留换行):

```
POST\n
/palmpayminiapp/clawagentpay/preorder\n
{timestamp}\n
{nonce_str}\n
{payment_required}\n
```

**这是签名失败最常见根因**:换行错、Base64 错、时间戳错、私钥与 pub_key_id 不匹配。

## L1/L2 两层结构

L2 业务 JSON(Base64 编码后放入 L1):

```json
{
  "skill_info": { "skill_id": "your-skill-slug", "skill_version": "1.0.0" },
  "pay_type": "SKILL_PAY",
  "pay_mode": "AUTH_AND_PAY",
  "pay_items": [{
    "product_id": "SP20260725001",
    "pay_data": { "type": "code_url", "value": "weixin://wxpay/bizpayurl?pr=xxx" }
  }],
  "expires_at": 1782462000
}
```

L1 请求体:

```json
{
  "signature_type": "SKILLHUB-SHA256-RSA2048",
  "developer_platform": "SKILLHUB",
  "developer_id": "sh-XXXXXXXX",
  "pub_key_id": "PUB_KEY_xxx",
  "nonce_str": "32位随机串",
  "timestamp": 1782461100,
  "signature": "<base64-signature>",
  "payment_required": "<base64-L2-JSON>"
}
```

## 两套密钥(不能混用)

| 密钥 | 用途 | 签名算法 | 获取 |
|---|---|---|---|
| 微信支付 API 证书 | Native 下单、查单、退款 | WECHATPAY2-SHA256-RSA2048 | 微信支付商户平台 |
| SkillHub 开发者密钥 | AI 预下单 | SKILLHUB-SHA256-RSA2048 | SkillHub 商户中心 |

## HTTP 402 响应规范

必须同时返回 Header + Body(便于不同 Agent 兼容):

**Header**:
- `WeixinPay-Required: <payment_code>`
- `X-Out-Trade-No: <out_trade_no>`

**Body**:
```json
{
  "code": "PAYMENT_REQUIRED",
  "message": "需要支付后才能获取内容",
  "WeixinPay": {
    "WeixinPay-Required": "<payment_code>",
    "prompt": "本次使用微信支付,请将 WeixinPay-Required 的值作为 paymentCode 交给 weixinpay_pay,以向用户申请支付授权。"
  },
  "out_trade_no": "WX402_xxx",
  "amount": "9.00",
  "currency": "CNY"
}
```

## 幂等控制

同一 `out_trade_no` 只履约一次。生产环境建议使用:
- 数据库事务
- Redis SETNX with TTL
- 内存 Map(测试用)
