# 微信支付接入步骤

## Step 1:申请商户号

1. 访问 pay.weixin.qq.com
2. 注册并完成商户认证
3. 准备材料:
   - 营业执照(企业) / 个体工商户执照
   - 对公账户(企业) / 法人银行卡(个体)
   - 法人身份证
   - 经营场景说明
4. 审核周期:1-7 个工作日

## Step 2:获取 API 证书

1. 登录商户平台
2. 账户中心 -> API 安全 -> 申请 API 证书
3. 下载工具生成证书请求串
4. 上传请求串 -> 下载证书包(apiclient_cert.pem + apiclient_key.pem)
5. 保存:
   - `apiclient_key.pem` -> 服务端(用于签名)
   - `apiclient_cert.pem` -> 服务端(用于回调验签)

## Step 3:获取 APIv3 密钥

1. 账户中心 -> API 安全 -> 设置 APIv3 密钥
2. 32 位随机字符串(可手写或工具生成)
3. 保存到环境变量 `MCH_APIV3_KEY`

## Step 4:开通 Native 支付

1. 产品中心 -> Native 支付 -> 申请开通
2. 填写支付场景(扫码支付)
3. 等待审核(通常 1-2 个工作日)

## Step 5:配置回调地址

1. 产品中心 -> Native 支付 -> 支付配置
2. 支付回调 URL:`https://your-domain.com/api/pay/notify`
3. 退款回调 URL:`https://your-domain.com/api/refund/notify`
4. **必须 HTTPS**(微信支付强制)

## 测试与上线

### 测试阶段(微信支付沙箱)
- 商户平台 -> 开发配置 -> 沙箱测试
- 测试商户号:有专门的测试号
- 测试金额:可设任意金额(1 分起)

### 上线阶段
- 商户平台 -> 产品中心 -> Native 支付 -> 申请开通
- 提交营业执照、经营场景
- 等待 1-3 个工作日审核

## 常见问题

### Q:申请被拒?
A:通常是营业执照问题,需要真实经营场景。

### Q:测试时回调收不到?
A:检查 HTTPS 证书是否有效、回调 URL 是否能公网访问。

### Q:Native 支付和 JSAPI 支付区别?
A:Native = 扫码,JSAPI = 微信内 H5 支付。Pay Skill 推荐 Native(Agent 触发场景)。
