# 8 大报错速查

## 报错 1:`未进行 X402 协议改造`

**触发场景**:SkillHub 平台发布时勾选了"升级为 Pay Skill",但 SKILL.md 没有 `x402_compliant: true` 字段,或后端没有 X402 改造。

**解决方案**:
- **方案 A(免费发布)**:取消勾选,作为普通 skill 发布
- **方案 B(Pay Skill)**:完成本 skill 描述的 5 步改造

## 报错 2:`file type not allowed: xxx.service`

**触发场景**:zip 包含 `.service`(systemd 单元文件)、`.sh`(bash 脚本)、`.py`/`.go`/`.java`(后端代码)等。

**根本原因**:SkillHub 平台只接受特定文件类型:
- SKILL.md
- icon.png / icon.svg
- references/*.md(放在 references/ 子目录)

**解决方案**:
1. zip 内只放 SKILL.md + icon.png + references/*.md
2. Go 服务代码、`systematic-debugging.service`、`test_local.sh` 等放本地 `_deploy-only-do-not-upload/` 目录
3. 重新打包

## 报错 3:`签名失败`

**触发场景**:AI 预下单接口返回签名错误。

**根本原因**:`5 行签名串`的换行、Base64、时间戳、私钥与 `pub_key_id` 不匹配。

**解决方案**:
```python
# 正确格式(每行 \n 结尾,含最后一行)
sign_string = f"POST\n/palmpayminiapp/clawagentpay/preorder\n{timestamp}\n{nonce_str}\n{payment_required}\n"
```

检查清单:
- [ ] 5 行每行都有 `\n` 结尾
- [ ] `payment_required` 是 Base64(不是 Hex)
- [ ] 时间戳是 Unix 秒(不是毫秒)
- [ ] 私钥和 `pub_key_id` 配对

## 报错 4:`payment_code 已过期`

**触发场景**:用户从下单到确认支付超过 15 分钟。

**根本原因**:`payment_code` 有效期最长 15 分钟,过期需重新下单。

**解决方案**:
- Agent 端:捕获 NOT_PAID 状态后重新发起请求
- 商户端:每次重新请求都生成新的 out_trade_no

## 报错 5:`微信支付回调 401`

**触发场景**:微信支付无法验证回调签名。

**根本原因**:平台证书过期或本地证书不匹配。

**解决方案**:
1. 删除本地 `apiclient_cert.pem`
2. 重新下载平台证书(商户平台 -> 账户中心 -> API 安全)
3. 重启服务

## 报错 6:`退款失败`

**触发场景**:调起退款时返回错误。

**根本原因**:`MCH_APIV3_KEY` 错误或证书问题。

**解决方案**:
1. 检查 `MCH_APIV3_KEY` 是否正确(32 位)
2. 检查证书是否过期
3. 微信支付商户平台查看具体错误码

## 报错 7:`L1 验证失败`

**触发场景**:AI 预下单返回"L1 验证失败"。

**根本原因**:`pub_key_id` 与请求中的 `signature` 不配对(用了别的公钥对应的私钥签名)。

**解决方案**:
1. 重新生成密钥对
2. 确保签名用的私钥和 `pub_key_id` 是同一对
3. 微信支付后台会向 SkillHub 验签,确认商户身份

## 报错 8:`测试退款不触发`

**触发场景**:在 demo 中 query 设置 "trigger_refund" 不触发退款。

**根本原因**:`executeBusiness` 函数没正确判断 trigger_refund。

**解决方案**:
```go
func executeBusiness(query string) (string, error) {
    if query == "trigger_refund" {  // 严格匹配
        return "", fmt.Errorf("测试退款")
    }
    return yourLogic(query), nil
}
```

注意:
- 字符串严格匹配,不要加空格
- 返回 error(不是返回字符串)才能触发退款

## 调试技巧

### 1. 用 curl 测试 402 响应

```bash
curl -i -X POST https://your-domain.com/api/resource \
  -H "Content-Type: application/json" \
  -d '{"query": "test"}'
```

预期:
```
HTTP/1.1 402 Payment Required
WeixinPay-Required: payment_code_xxx
X-Out-Trade-No: WX402_xxx
```

### 2. 查微信支付商户平台的交易记录

- 交易管理 -> 实时交易
- 看 `out_trade_no` 状态

### 3. 看后端日志

```bash
journalctl -u your-service -f
```

重点看:
- Native 下单成功/失败
- AI 预下单成功/失败
- 签名错误信息

### 4. 微信支付沙箱测试

- 商户平台 -> 开发配置 -> 沙箱测试
- 用沙箱商户号测试
- 不会真实扣款

## 仍然无法解决?

- 微信支付客服:95017
- SkillHub 客服:skillhub_ipr@tencent.com
- mch-demo 代码:`mch-demo/mch-demo/`
- 官方文档:https://skillhub.cn/tutorials#agent-pay-upgrade
