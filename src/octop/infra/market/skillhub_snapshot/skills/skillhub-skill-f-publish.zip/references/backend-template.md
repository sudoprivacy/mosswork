# 后端服务模板

## 推荐技术栈

| 语言 | 框架 | 适用场景 | 部署难度 |
|---|---|---|---|
| Go | net/http 或 Gin | 高并发,SDK 成熟 | 中 |
| Java | Spring Boot | 企业级,生态完整 | 高 |
| Python | FastAPI | 快速开发,AI 集成 | 低 |
| Node.js | Express | 全栈友好 | 低 |

## Go 模板(基于 mch-demo)

mch-demo 提供完整 Go 实现:`mch-demo/mch-demo/go/main.go`

### 改 2 处即可

```go
// 改 1:金额
amount := int64(900) // ¥9.00 = 900 分

// 改 2:业务函数
func executeBusiness(query string) (string, error) {
    if query == "trigger_refund" {
        return "", fmt.Errorf("测试退款")
    }
    return yourBusinessLogic(query), nil
}
```

其他(SDK 集成、签名、AI 预下单)100% 复用 demo。

## Python 模板(快速集成)

```python
from fastapi import FastAPI, Header, HTTPException
import httpx
import json
import base64
import time
import uuid

app = FastAPI()

# 配置
WECHAT_PAY_URL = "https://api.mch.weixin.qq.com"
SKILLHUB_DEVELOPER_ID = "sh-XXXXXXXX"
SKILLHUB_PRIVATE_KEY = "-----BEGIN PRIVATE KEY-----\nxxx\n-----END PRIVATE KEY-----"
SKILLHUB_PUB_KEY_ID = "PUB_KEY_xxx"

@app.post("/api/resource")
async def handle_resource(
    body: dict,
    x_out_trade_no: str = Header(None)
):
    query = body.get("query", "")

    # 场景 1:支付后重试
    if x_out_trade_no:
        # 查单验证
        paid = await verify_payment(x_out_trade_no)
        if not paid:
            raise HTTPException(status_code=402, detail="PAYMENT_NOT_VERIFIED")

        # 履约
        content = your_business_logic(query)
        return {"code": "SUCCESS", "out_trade_no": x_out_trade_no, "content": content}

    # 场景 2:首次请求 -> 返回 402
    out_trade_no = f"WX402_{int(time.time())}{uuid.uuid4().hex[:8]}"[:32]
    payment_code = await create_payment(out_trade_no, query)

    return HTTPException(
        status_code=402,
        detail={
            "code": "PAYMENT_REQUIRED",
            "WeixinPay": {"WeixinPay-Required": payment_code},
            "out_trade_no": out_trade_no,
        },
        headers={
            "WeixinPay-Required": payment_code,
            "X-Out-Trade-No": out_trade_no,
        }
    )
```

## Java 模板(企业级)

参考 mch-demo 的 Java 版本,改 2 处即可。

## 部署架构

### 单服务模式(简单)

```
[Agent] -> [Pay Skill 后端] -> [微信支付 API]
                  ↓
            [你的业务逻辑]
            (LLM API / DB / 第三方)
```

### 多服务模式(企业级)

```
[Agent] -> [API Gateway] -> [Pay Skill 路由]
                              ↓
                       [业务微服务 1/2/3]
                              ↓
                       [LLM API / DB]
```

## 必装依赖

### Go
```bash
go get github.com/wechatpay-apiv3/wechatpay-go
```

### Python
```bash
pip install fastapi httpx uvicorn cryptography
```

### Java
```xml
<dependency>
    <groupId>com.github.wechatpay-apiv3</groupId>
    <artifactId>wechatpay-java</artifactId>
</dependency>
```
