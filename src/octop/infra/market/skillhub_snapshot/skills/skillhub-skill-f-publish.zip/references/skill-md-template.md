# SKILL.md 改造模板

## 关键:description 字段不要放在最前的应该是"价值 + 场景"

### 反例(平台抓取不友好)
```yaml
description: 付费版 X X X,通过微信 Agent Pay X402 协议完成支付后获取专业输出(¥9.00/次)。
```

### 正例(平台抓取友好)
```yaml
description: 4 阶段根因调试法,解决"乱改代码"问题。复现 -> 定位 -> 验证 -> 修复,30 分钟内定位棘手 bug。包含 17K 字方法论 + 137 条避坑规则。当用户说"我改了一次 bug 引入三个新 bug"等场景时使用本技能。
```

## 完整模板(可复制)

```markdown
---
name: your-skill-slug
description: [价值 + 适用场景,无价格/付费字样]
version: 1.0.0
author: 你的公司
license: MIT
platforms: [linux, macos, windows]
pay_skill: true
x402_compliant: true
pricing: paid
price: ¥9.00
metadata:
  hermes:
    tags: [tag1, tag2, ...]
    triggers: ["用户说 X", "用户说 Y", ...]
    name_zh: 中文名
---

# 中文名(付费版)

## 这是什么

[价值首句,优先被抓取]

[业务描述]

## 适用场景

- 目标用户 1
- 目标用户 2

## 业务输出

调用本 skill 后,你将获得:[业务标题]。

1. 业务步骤 1
2. 业务步骤 2
3. 业务步骤 3
4. 业务步骤 4

---

## 付费信息

- **每次调用**:¥X.00
- **计费方式**:微信支付(Agent Pay X402 协议)
- **payment_code 有效期**:最长 15 分钟
- **退款机制**:如返回 REFUNDED,自动退款

## X402 协议集成(技术细节)

### 工作流程

[4 段流程图]

### 付费前置检查

[weixinpay 插件检查]

### 第一步:请求资源

```bash
curl -X POST https://your-domain.com/api/resource ...
```

### 第二步:返回 402

[Header + Body 规范]

### 第三步:触发支付

[weixinpay_pay 调用]

### 第四步:重试

[Header 携带支付信息]

### 第五步:退款处理

[REFUNDED 响应]

## 商户服务代码

[部署专用目录说明]

## 部署

[详细步骤]
```

## 章节顺序原则

1. **价值**(## 这是什么)- 平台优先抓取
2. **适用人群**(## 适用场景)
3. **业务输出**(## 业务输出)
4. **付费信息**(## 付费信息)- 后置
5. **技术细节**(## X402 协议集成)- 最末尾
6. **部署**(## 部署)

## file type not allowed 避坑

zip 内**只允许**:
- SKILL.md
- icon.png / icon.svg
- references/*.md

**禁止**:
- .service 文件
- .sh / .bash 脚本
- .env / .env.example
- .py / .go / .java 后端代码

Go 服务代码放本地 `_deploy-only-do-not-upload/` 目录,**不上传 SkillHub**。
