# 输出规格：JSON 结构与 Word 版式（references/report_spec.md）

本 skill 的交付物按模式区分，由 `scripts/generate_reports.py` 依据**同一份质检结果 JSON** 生成：

- **质检模式**（`mode: "quality_inspection"`）：生成**两份** Word
  - 《翻译质量报告》（`*_翻译质量报告.docx`）——给译员的内部参考，含 AI 判断流程与争议点详述。
  - 《原文与推荐译文对照》（`*_原文与推荐译文对照.docx`）——给客户的商务成果，仅原文+推荐译文对照表。
- **自我迭代翻译模式**（`mode: "self_iterative"`）：仅生成**一份** Word
  - 《原文与推荐译文对照》（`*_原文与推荐译文对照.docx`）——给客户的商务成果。

---

## 一、供脚本消费的 JSON 结构

```json
{
  "mode": "quality_inspection",
  "meta": {
    "date": "2026-08-14",
    "source_language": "en",
    "target_language": "zh",
    "source_file": "（内联文本）",
    "project": "（可选，项目名称，用于对照文档抬头与文件前缀）",
    "purpose_class": "II",
    "purpose_CA": 0.75,
    "difficulty_K": 1.0,
    "char_count_W": 200,
    "glossary": "（无）",
    "pe_depth": "深度译后编辑（full PE）",
    "iteration": {"rounds": 1, "history": [{"round": 0, "rate": 0.8}]},
    "back_translation": {
      "enabled": true,
      "rounds": [
        {
          "segment_no": 1,
          "source": "The dose is 50 mg.",
          "back_translated": "剂量为 50 毫克。",
          "similarity": "high",
          "issues": [],
          "resolved": true
        },
        {
          "segment_no": 2,
          "source": "Install 3 PV modules by 2026-08-06.",
          "back_translated": "2026-08-06 前安装 3 个光伏模块。",
          "similarity": "medium",
          "issues": ["疑似语义漂移：日期与原文核对后确认已修正"],
          "resolved": true
        }
      ]
    }
  },
  "standard": "GB/T 19682-2005 + GB/T 40036-2021",
  "alignment": [
    {
      "no": 1,
      "source": "The dose is 50 mg.",
      "translation": "剂量为 50 克。",
      "recommended": "剂量为 50 毫克。",
      "english": "The dose is 50 mg."
    },
    {
      "no": 2,
      "source": "Install 3 PV modules by 2026-08-06.",
      "translation": "2026-08-07 前安装 3 个光伏模块。",
      "recommended": "2026-08-06 前安装 3 个光伏模块。",
      "english": "Install 3 PV modules by 2026-08-06."
    }
  ],
  "defects": [
    {
      "no": 1,
      "location": "对照段1",
      "category": "Ⅳ",
      "source": "The dose is 50 mg.",
      "original_translation": "剂量为 50 克。",
      "suggested_translation": "剂量为 50 毫克。",
      "reason": "争议点：单位译法。原文 mg（milligram，毫克）在译文中误作「克」（g），属计量单位未按约定译法（GB/T 19682-2005 第Ⅳ类、附录 A.1）。考虑过「毫克」「mg」两种写法，按中文行文习惯采用「50 毫克」并在术语表中统一。修订见 suggested_translation。",
      "english_reference": "The dose is 50 mg."
    },
    {
      "no": 2,
      "location": "对照段2",
      "category": "Ⅰ",
      "source": "Install 3 PV modules by 2026-08-06.",
      "original_translation": "2026-08-07 前安装 3 个光伏模块。",
      "suggested_translation": "2026-08-06 前安装 3 个光伏模块。",
      "reason": "争议点：日期错译。截止日 2026-08-06 误作 2026-08-07，提前一天，属关键字词（数字）差错（GB/T 19682-2005 第Ⅰ类；GB/T 40036-2021 第 6 章 a「未遗漏/误改信息」）。数据校准轮逐句核查发现 date_mismatch。修订为 2026-08-06。",
      "english_reference": "Install 3 PV modules by 2026-08-06."
    }
  ],
  "defect_counts": {"Ⅰ": 1, "Ⅱ": 0, "Ⅲ": 0, "Ⅳ": 1},
  "checklist_40036": [
    {"item": "术语/用语一致", "ok": false, "note": "第1段单位译法前后不一致"},
    {"item": "标准语法、拼写、标点", "ok": true, "note": ""},
    {"item": "正确断句", "ok": true, "note": ""},
    {"item": "适用受众与用途", "ok": true, "note": ""},
    {"item": "遵守客户协议", "ok": true, "note": ""},
    {"item": "无增删信息", "ok": false, "note": "第2段日期被改动"},
    {"item": "风格与格式", "ok": true, "note": ""}
  ],
  "error_rate_permil": 12.19,
  "pass_threshold_permil": 1.5,
  "pass": false,
  "final_grade": "不合格",
  "grade_detail_non_standard": {"enabled": false}
}
```

### JSON 字段约定

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| `mode` | 建议 | 生成模式：`quality_inspection`（默认，双文档）或 `self_iterative`（仅对照文档）；命令行 `--mode` 优先于此字段 |
| `meta.source_language` | 建议 | 决定对照文档是否插入「英文参考译文」列（原文非英文时插入）；缺省时按 `alignment.english` 或缺陷 `english_reference` 是否存在触发 |
| `meta.iteration` | 否 | 自我迭代翻译模式专用：`{"rounds": n, "history": [{"round": 0, "rate": R0}, ...]}`；脚本自动忽略未知字段 |
| `meta.back_translation` | 否 | 回译辅助校验记录（**默认关闭，用户要求时开启**）：`{"enabled": bool, "rounds": [{"segment_no", "source", "back_translated", "similarity"(high/medium/low), "issues"[], "resolved"}]}`。**仅日志追溯用**：不进入任何交付文档、不影响差错率与合格判定；脚本自动忽略 |
| `meta.pe_depth` | 建议 | 译后编辑深度，用于报告标注 |
| `alignment[]` | 建议 | 逐段全文对照：`no`(段号)、`source`(原文)、`translation`(待检译文)、`recommended`(**最终推荐译文完整句**——无缺陷段等于 translation，有缺陷段等于修正后完整译句)、可选 `english`(该句完整英文翻译全文) |
| `defects[].category` | 是 | 国标类别：Ⅰ/Ⅱ/Ⅲ/Ⅳ（脚本兼容 I/II/III/IV） |
| `defects[].source` | 是 | 原文内容（问题句） |
| `defects[].original_translation` | 是 | 待检译文（即原文译文） |
| `defects[].suggested_translation` | 是 | **修正后的完整译句**（整句翻译全文），填充质量报告「推荐译文」与对照文档 `recommended` |
| `defects[].reason` | 是 | **争议点详述**：错在何处、对应国标条款、考虑过的其他理解、采用修订的理由；仅用于质量报告（质检模式） |
| `defects[].english_reference` | 原文非英文时 | 该句完整英文翻译；行级 `alignment.english` 缺失时用其填充「英文参考译文」列 |
| `defects[].location` | 建议 | 引用对照段号（如「对照段1」），脚本据此绑定到对应行 |
| `defect_counts` | 否 | 四类计数；缺失时脚本从 defects 自动统计 |
| `error_rate_permil` | 否 | 综合差错率(‰)；缺失时脚本按公式重算 |
| `pass` / `final_grade` | 否 | 判定；缺失时脚本按阈值自动判定 |
| `checklist_40036` | 建议 | 定性清单（`ok`: true/false，可选 `note`） |
| `grade_detail_non_standard` | 否 | 可选扩展分档（非国标）；`enabled:false` 时省略 |

---

## 二、《翻译质量报告》版式（仅质检模式生成，给译员）

```
翻译质量报告
依据标准：GB/T 19682-2005 + GB/T 40036-2021

一、报告信息
  两列表格：检查日期 / 原文语言 / 译文语言 / 用途类别(C_A) / 综合难度系数 K /
  计字总字符数 W / 术语表 / 译后编辑深度 / （迭代轨迹：轮次与各轮差错率，若有）

二、质检流程与判断方法
  简述：依据 GB/T 40036-2021 三阶段（生产前—生产—生产后）+ GB/T 19682-2005 定量评分；
  说明四类差错、综合差错率公式、1.5‰ 合格线；若自我迭代，列出各轮差错率轨迹。

三、翻译争议点逐条详述（核心）
  每个缺陷一段：
  ▸ 小标题：争议点 N（对照段X）　【Ⅰ/Ⅱ/Ⅲ/Ⅳ类】（按类别着色）
  ▸ 原文：<source>
  ▸ 待检译文：<original_translation>
  ▸ 推荐译文：<suggested_translation>
  ▸ 判断与说明：<reason>（含对应国标条款、争议取舍、修订理由）

四、GB/T 40036-2021 定性检查清单
  表格：| 检查项 | 结论（✔符合 / ✘不符合 / —待确认） | 说明 |

五、各类别差错计数
  | 国标类别 | 定义 | 系数 | 数量 |（含合计行，浅蓝底）

六、综合差错率与合格判定
  综合差错率计算式 = 结果‰；合格线 ≤ 1.5‰；判定：合格(绿)/不合格(红) 居中大字
  （若有迭代：附各轮轨迹；残余缺陷注明「经 n 轮迭代仍有 N 处缺陷未消除」）

七、附录：公式与国标条款索引
页脚：页码
```

---

## 三、《原文与推荐译文对照》版式（两种模式均生成，给客户）

```
原文与推荐译文对照
（抬头：项目 | 日期 | 语言方向 —— 商务简洁）

一、对照表
  | 段号 | 原文 | 推荐译文 | [英文参考译文] |
  （逐段一一对应；每行「推荐译文」= alignment.recommended 的完整译句；
   原文非英文时自动增加「英文参考译文」列；斑马纹便于阅读，不做缺陷着色、不写判断说明）

页脚：页码 + 保密说明
```

> **对照文档原则**：只呈现成果（原文→推荐译文），**不含任何质量判定、判断逻辑、缺陷计数与公式，不渲染缺陷着色**。该文档是交付给客户的商务成果，须专业严谨、简洁直接；质检结论（合格/不合格、差错率等）只出现在《翻译质量报告》中（仅质检模式生成）。

---

## 四、生成命令

```bash
# 质检模式：生成双文档（报告 + 对照）
python scripts/generate_reports.py --input report.json --out-dir . --prefix 项目名 --mode quality_inspection
# 输出：项目名_翻译质量报告.docx、项目名_原文与推荐译文对照.docx

# 自我迭代翻译模式：仅生成对照文档
python scripts/generate_reports.py --input report.json --out-dir . --prefix 项目名 --mode self_iterative
# 输出：项目名_原文与推荐译文对照.docx

# --mode 缺省时：读取 JSON 的 mode 字段；仍缺省则默认 quality_inspection（双文档）
# 缺省 --prefix 时自动以时间戳命名；缺省 --out-dir 时输出到当前目录
```

依赖 `python-docx`（缺失时 `pip install python-docx`）。
