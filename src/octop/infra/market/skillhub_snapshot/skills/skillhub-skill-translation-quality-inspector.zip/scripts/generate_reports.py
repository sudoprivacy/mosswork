#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_reports.py - 由一份质检结果 JSON 生成 Word(.docx) 交付物：

  质检模式 (quality_inspection, 默认)：生成两份文档
    1) 《翻译质量报告》   (*_翻译质量报告.docx)   —— 给译员的内部参考
       含：报告信息、质检流程与判断方法、翻译争议点逐条详述（reason）、
           GB/T 40036-2021 定性清单、四类差错计数、综合差错率与合格判定、条款附录。
    2) 《原文与推荐译文对照》 (*_原文与推荐译文对照.docx) —— 给客户的商务成果
       仅列：项目信息 + 逐段「原文 | 推荐译文〔| 英文参考译文〕」对照表；
       不含质量判定、判断逻辑、缺陷计数与公式，不渲染缺陷着色。

  自我迭代翻译模式 (self_iterative)：仅生成一份文档
    1) 《原文与推荐译文对照》 (*_原文与推荐译文对照.docx) —— 给客户的商务成果

输入 JSON 结构见 references/report_spec.md。

用法:
    python generate_reports.py --input report.json [--out-dir DIR] [--prefix 项目名] [--mode quality_inspection|self_iterative]
"""

import argparse
import datetime
import json
import os
import re
import sys

try:
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt, RGBColor
except ImportError:
    sys.stderr.write(
        "[ERROR] 缺少 python-docx 依赖。请先安装：\n"
        "  pip install python-docx\n"
        "（或使用已安装该库的隔离 Python 环境执行本脚本。）\n"
    )
    sys.exit(2)


ENGLISH_LANGS = {"en", "eng", "english", "en-us", "en-gb", "英文", "英语"}

CATEGORY_DEFS = [
    ("Ⅰ", "核心语义 / 关键字词(含数字、日期) / 句段漏译错译", 3),
    ("Ⅱ", "一般语义 / 非关键字词 / 用词、语法错误", 1),
    ("Ⅲ", "术语不准确、不统一 / 专有名词错译", 0.5),
    ("Ⅳ", "计量单位、符号、缩略语未按约定译法", 0.25),
]

# 国标类别 → (文字色, 行底色)：Ⅰ类最严重用红系，Ⅱ橙系，Ⅲ金黄系，Ⅳ蓝灰系
CAT_STYLE = {
    "Ⅰ": ("C00000", "FDECEC"),
    "Ⅱ": ("C55A11", "FDF0E7"),
    "Ⅲ": ("BF8F00", "FBF5E0"),
    "Ⅳ": ("5D6D7E", "ECF0F3"),
}
CAT_ORDER = {"Ⅰ": 0, "Ⅱ": 1, "Ⅲ": 2, "Ⅳ": 3}  # 类别严重度排序（Ⅰ最严重）
HEADER_FILL = "2F5496"       # 表头深蓝底 + 白字
TOTAL_FILL = "D6E4F0"        # 合计行浅蓝底
ZEBRA_FILL = "F2F6FA"        # 对照表斑马纹
COMP_HEADER_FILL = "1F4E79"  # 对照表表头深蓝
COMP_ACCENT = "2E75B6"       # 对照文档装饰色
GREEN = RGBColor(0x00, 0x80, 0x00)
RED = RGBColor(0xC0, 0x00, 0x00)
DARK = RGBColor(0x1F, 0x1F, 0x1F)
GREY = RGBColor(0x59, 0x59, 0x59)
LIGHT_GREY = RGBColor(0x89, 0x89, 0x89)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)


# ---------------- 基础排版工具 ----------------

def _set_run_font(run, size=11, bold=False, cn_font="宋体", en_font="Times New Roman", color=None, italic=False):
    run.font.name = en_font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color is not None:
        run.font.color.rgb = color
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), cn_font)


def _shade_cell(cell, hex_fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tc_pr.append(shd)


def _set_cell(cell, text, bold=False, size=10, color=None, align=None):
    """写单元格文本；text 含换行符时拆为多行（同一单元格内多段落），垂直居中。"""
    p = cell.paragraphs[0]
    for r in list(p.runs):
        r._r.getparent().remove(r._r)
    for extra in cell.paragraphs[1:]:
        extra._p.getparent().remove(extra._p)
    lines = [""] if text is None else str(text).split("\n")
    for i, line in enumerate(lines):
        para = p if i == 0 else cell.add_paragraph()
        if align is not None:
            para.alignment = align
        para.paragraph_format.space_after = Pt(0)
        para.paragraph_format.space_before = Pt(0)
        para.paragraph_format.line_spacing = 1.2
        run = para.add_run(line)
        _set_run_font(run, size=size, bold=bold, color=color)
    tc_pr = cell._tc.get_or_add_tcPr()
    if tc_pr.find(qn("w:vAlign")) is None:
        va = OxmlElement("w:vAlign")
        va.set(qn("w:val"), "center")
        tc_pr.append(va)
    return cell


def _style_header_row(row, size=10, fill=HEADER_FILL):
    for cell in row.cells:
        _set_cell(cell, cell.text, bold=True, size=size, color=WHITE,
                  align=WD_ALIGN_PARAGRAPH.CENTER)
        _shade_cell(cell, fill)


def _set_table_fixed(table, widths):
    tbl_pr = table._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tbl_pr.append(layout)
    grid = table._tbl.find(qn("w:tblGrid"))
    if grid is not None:
        for gc in grid.findall(qn("w:gridCol")):
            grid.remove(gc)
        for wd in widths:
            gc = OxmlElement("w:gridCol")
            gc.set(qn("w:w"), str(int(wd.twips)))
            grid.append(gc)
    for i, wd in enumerate(widths):
        for row in table.rows:
            if i < len(row.cells):
                row.cells[i].width = wd


def _add_heading(doc, text, level=1, color=DARK):
    h = doc.add_heading(level=level)
    run = h.add_run(text)
    _set_run_font(run, size={0: 22, 1: 14, 2: 12}.get(level, 12), bold=True,
                  cn_font="黑体", color=color)
    pPr = h._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "2")
    bottom.set(qn("w:color"), "2F5496")
    pBdr.append(bottom)
    pPr.append(pBdr)
    return h


def _add_para(doc, text="", bold=False, size=11, indent=False, align=None, color=None, space_after=6):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_after = Pt(space_after)
    pf.line_spacing = 1.25
    if indent:
        pf.left_indent = Pt(18)
    if align is not None:
        p.alignment = align
    run = p.add_run(text)
    _set_run_font(run, size=size, bold=bold, color=color)
    return p


def _add_page_number_footer(section):
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    _set_run_font(run, size=9)
    fld1 = OxmlElement("w:fldChar"); fld1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve"); instr.text = "PAGE"
    fld2 = OxmlElement("w:fldChar"); fld2.set(qn("w:fldCharType"), "end")
    run._r.append(fld1); run._r.append(instr); run._r.append(fld2)


def _set_cell_margins(cell, top=60, bottom=60, left=80, right=80):
    """Set cell margins in twips (1/20 pt)."""
    tc_pr = cell._tc.get_or_add_tcPr()
    margins = OxmlElement("w:tcMar")
    for tag, val in [("top", top), ("bottom", bottom), ("start", left), ("end", right),
                     ("left", left), ("right", right)]:
        elem = OxmlElement(f"w:{tag}")
        elem.set(qn("w:w"), str(val))
        elem.set(qn("w:type"), "dxa")
        margins.append(elem)
    tc_pr.append(margins)


# ---------------- 计算 ----------------

def _count_defects(defects):
    counts = {"Ⅰ": 0, "Ⅱ": 0, "Ⅲ": 0, "Ⅳ": 0}
    for d in defects or []:
        cat = str(d.get("category", "")).strip().upper()
        key = {"I": "Ⅰ", "II": "Ⅱ", "III": "Ⅲ", "IV": "Ⅳ"}.get(cat, cat)
        if key in counts:
            counts[key] += 1
    return counts


def _compute_rate(k, ca, counts, w):
    if not w:
        return None
    weighted = 3 * counts["Ⅰ"] + 1 * counts["Ⅱ"] + 0.5 * counts["Ⅲ"] + 0.25 * counts["Ⅳ"]
    return round(k * ca * weighted / w * 1000, 2)


def _rate_process_text(k, ca, counts, w):
    return (
        f"{k} × {ca} × (3×{counts['Ⅰ']} + 1×{counts['Ⅱ']} "
        f"+ 0.5×{counts['Ⅲ']} + 0.25×{counts['Ⅳ']}) / {w} × 1000"
    )


# ---------------- 缺陷 / 对照 绑定 ----------------

def _norm_cat(cat):
    key = str(cat or "").strip().upper()
    return {"I": "Ⅰ", "II": "Ⅱ", "III": "Ⅲ", "IV": "Ⅳ"}.get(key, key)


def _loc_to_no(loc):
    if loc is None:
        return None
    m = re.search(r"(\d+)", str(loc))
    return int(m.group(1)) if m else None


def _sorted_defects(defects):
    return sorted(defects or [], key=lambda x: CAT_ORDER.get(_norm_cat(x.get("category")), 9))


def _defects_by_no(defects):
    """按对照段号索引缺陷列表（用于推荐译文派生与争议点排序）。"""
    out = {}
    for d in defects or []:
        n = _loc_to_no(d.get("location"))
        if n is not None:
            out.setdefault(n, []).append(d)
    return out


def _recommended_for_row(row, defects_for_row):
    """对照文档某段的推荐译文：优先 alignment.recommended；否则由缺陷派生；否则等于待检译文。"""
    rec = (row.get("recommended") or "").strip()
    if rec:
        return rec
    if defects_for_row:
        lines = [(d.get("suggested_translation") or "").strip() for d in _sorted_defects(defects_for_row)]
        joined = "\n".join(x for x in lines if x)
        if joined:
            return joined
    return (row.get("translation") or row.get("target") or "").strip()


def _is_lang(lang, langset):
    if not lang:
        return None
    return str(lang).strip().lower() in langset


def _load_meta(data):
    meta = data.get("meta") or {}
    defects = data.get("defects") or []
    counts = data.get("defect_counts") or {}
    counts = {
        "Ⅰ": counts.get("Ⅰ", counts.get("I", 0)),
        "Ⅱ": counts.get("Ⅱ", counts.get("II", 0)),
        "Ⅲ": counts.get("Ⅲ", counts.get("III", 0)),
        "Ⅳ": counts.get("Ⅳ", counts.get("IV", 0)),
    }
    if not any(counts.values()):
        counts = _count_defects(defects)
    k = float(data.get("difficulty_K", data.get("k", meta.get("difficulty_K", 1.0)) or 1.0))
    ca = float(data.get("purpose_CA", data.get("ca", meta.get("purpose_CA", 1.0)) or 1.0))
    w = int(data.get("char_count_W", data.get("w", meta.get("char_count_W", 0)) or 0))
    rate = data.get("error_rate_permil")
    rate = float(rate) if rate is not None else _compute_rate(k, ca, counts, w)
    threshold = float(data.get("pass_threshold_permil", 1.5))
    passed = data.get("pass")
    if passed is None:
        passed = rate is not None and rate <= threshold
    grade = data.get("final_grade", "合格" if passed else "不合格")
    src_lang = meta.get("source_language") or meta.get("src_lang")
    tgt_lang = meta.get("target_language") or meta.get("tgt_lang")
    need_en_col = (_is_lang(src_lang, ENGLISH_LANGS) is False) or any(
        d.get("english_reference") for d in defects
    ) or any((a.get("english") or "").strip() for a in (data.get("alignment") or []))
    return meta, counts, k, ca, w, rate, threshold, passed, grade, src_lang, tgt_lang, need_en_col


# ============================================================
# 文档一：翻译质量报告（给译员，含判断逻辑与争议点）
# ============================================================

def build_quality_report(data, out_path):
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(11)
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), "宋体")

    section = doc.sections[0]
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(2.0)
    section.left_margin = Cm(2.2)
    section.right_margin = Cm(2.2)
    _add_page_number_footer(section)

    meta, counts, k, ca, w, rate, threshold, passed, grade, src_lang, tgt_lang, need_en_col = _load_meta(data)
    defects = data.get("defects") or []
    defects_by_no = _defects_by_no(defects)

    # ---- 标题 ----
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("翻译质量报告")
    _set_run_font(run, size=24, bold=True, cn_font="黑体", color=DARK)
    pPr = title._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "18")
    bottom.set(qn("w:space"), "4")
    bottom.set(qn("w:color"), "2F5496")
    pBdr.append(bottom)
    pPr.append(pBdr)
    _add_para(
        doc,
        "依据标准：GB/T 19682-2005《翻译服务 译文质量要求》"
        "、GB/T 40036-2021《翻译服务 机器翻译结果的译后编辑 要求》",
        size=10, align=WD_ALIGN_PARAGRAPH.CENTER,
    )
    doc.add_paragraph()

    # ---- 一、报告信息 ----
    _add_heading(doc, "一、报告信息", level=1)
    info_items = [
        ("检查日期", meta.get("date") or datetime.date.today().isoformat()),
        ("原文语言", src_lang or "（未提供）"),
        ("译文语言", tgt_lang or "（未提供）"),
        ("用途类别", f"{data.get('purpose_class', meta.get('purpose_class', '—'))}　使用目的系数 C_A = {ca}"),
        ("综合难度系数 K", str(k)),
        ("计字总字符数 W", str(w) if w else "（未提供，按内联文本估算）"),
        ("术语表", meta.get("glossary") or "（无）"),
        ("译后编辑深度", meta.get("pe_depth") or "（未指定）"),
    ]
    it = doc.add_table(rows=0, cols=2)
    it.style = "Table Grid"
    it.alignment = WD_TABLE_ALIGNMENT.CENTER
    it.autofit = False
    for label, value in info_items:
        row = it.add_row().cells
        _set_cell(row[0], label, bold=True, size=10, align=WD_ALIGN_PARAGRAPH.CENTER)
        _shade_cell(row[0], "F2F6FA")
        _set_cell(row[1], value, size=10, align=WD_ALIGN_PARAGRAPH.LEFT)
    _set_table_fixed(it, [Cm(4.2), Cm(12.0)])
    _add_para(doc, "", size=4)

    # ---- 二、质检流程与判断方法 ----
    _add_heading(doc, "二、质检流程与判断方法", level=1)
    _add_para(
        doc,
        "本报告的判定严格依据两项国家标准：定量评分对齐 GB/T 19682-2005 附录 A（四类差错、"
        "综合差错率公式、1.5‰ 合格线）；过程与定性检查对齐 GB/T 40036-2021 的「生产前—生产—生产后」"
        "三阶段与深度译后编辑要求。流程为：①原文与译文逐段对齐；②数据校准轮（LLM 逐句核查数字/单位/日期）兜底；③逐句归入国标四类差错并写入争议点；④按 GB/T 40036-2021 "
        "定性清单核对术语、语法、无增漏、风格与受众；⑤计算综合差错率并作合格判定。",
        size=10.5, indent=True,
    )
    iteration = meta.get("iteration")
    if iteration:
        rounds = iteration.get("rounds")
        history = iteration.get("history") or []
        _add_para(doc, f"自我迭代翻译轨迹：共 {rounds} 轮。", size=10.5, bold=True)
        if history:
            ht = doc.add_table(rows=1, cols=2)
            ht.style = "Table Grid"
            ht.alignment = WD_TABLE_ALIGNMENT.CENTER
            _set_cell(ht.rows[0].cells[0], "轮次", bold=True, size=10)
            _set_cell(ht.rows[0].cells[1], "综合差错率(‰)", bold=True, size=10)
            _style_header_row(ht.rows[0], size=10)
            for h in history:
                row = ht.add_row().cells
                _set_cell(row[0], f"第 {h.get('round', '?')} 轮", size=10, align=WD_ALIGN_PARAGRAPH.CENTER)
                _set_cell(row[1], str(h.get("rate", "—")), size=10, align=WD_ALIGN_PARAGRAPH.CENTER)
            _set_table_fixed(ht, [Cm(4.0), Cm(4.0)])
    _add_para(doc, "", size=4)

    # ---- 三、翻译争议点逐条详述 ----
    _add_heading(doc, "三、翻译争议点逐条详述", level=1)
    if not defects:
        _add_para(doc, "本次质检未检出差错，译文符合 GB/T 19682-2005 与 GB/T 40036-2021 要求。", size=11)
    else:
        # 按对照段号排序，段号缺失的排后
        def _sort_key(d):
            n = _loc_to_no(d.get("location"))
            return (0, n) if n is not None else (1, d.get("no", 0))
        for i, d in enumerate(sorted(defects, key=_sort_key), start=1):
            cat = _norm_cat(d.get("category"))
            txt_color, row_fill = CAT_STYLE.get(cat, ("000000", None))
            loc = d.get("location") or "（未定位）"
            _add_heading(doc, f"争议点 {i}（{loc}）　【{cat}类】", level=2,
                         color=RGBColor.from_string(txt_color))
            # 信息小表：原文 / 待检译文 / 推荐译文
            bt = doc.add_table(rows=0, cols=2)
            bt.style = "Table Grid"
            bt.alignment = WD_TABLE_ALIGNMENT.CENTER
            bt.autofit = False
            for label, key in [("原文", "source"), ("待检译文", "original_translation"), ("推荐译文", "suggested_translation")]:
                row = bt.add_row().cells
                _set_cell(row[0], label, bold=True, size=9.5, align=WD_ALIGN_PARAGRAPH.CENTER)
                _shade_cell(row[0], "F2F6FA")
                _set_cell(row[1], d.get(key) or "（无）", size=9.5, align=WD_ALIGN_PARAGRAPH.LEFT)
            _set_table_fixed(bt, [Cm(2.6), Cm(13.6)])
            _add_para(doc, "判断与说明：", bold=True, size=10.5, space_after=2)
            _add_para(doc, d.get("reason") or "（未填写理由）", size=10.5, indent=True)
            _add_para(doc, "", size=4)

    # ---- 四、GB/T 40036-2021 定性检查清单 ----
    _add_heading(doc, "四、GB/T 40036-2021 定性检查清单", level=1)
    checklist = data.get("checklist_40036") or []
    if checklist:
        lt = doc.add_table(rows=1, cols=3)
        lt.style = "Table Grid"
        lt.alignment = WD_TABLE_ALIGNMENT.CENTER
        _set_cell(lt.rows[0].cells[0], "检查项", bold=True, size=10)
        _set_cell(lt.rows[0].cells[1], "结论", bold=True, size=10)
        _set_cell(lt.rows[0].cells[2], "说明", bold=True, size=10)
        _style_header_row(lt.rows[0], size=10)
        for item in checklist:
            row = lt.add_row().cells
            name = item.get("item", "")
            ok = item.get("ok")
            note = item.get("note") or ""
            if ok is True:
                mark, color = "✔ 符合", GREEN
            elif ok is False:
                mark, color = "✘ 不符合", RED
            else:
                mark, color = "— 待确认", DARK
            _set_cell(row[0], name, size=10, align=WD_ALIGN_PARAGRAPH.LEFT)
            _set_cell(row[1], mark, size=10, bold=True, color=color, align=WD_ALIGN_PARAGRAPH.CENTER)
            _set_cell(row[2], note, size=9.5, align=WD_ALIGN_PARAGRAPH.LEFT)
        _set_table_fixed(lt, [Cm(5.2), Cm(3.0), Cm(7.8)])
        _add_para(doc, "", size=4)
    else:
        _add_para(doc, "（未提供定性检查明细）", size=11)
    pe = meta.get("pe_depth")
    if pe:
        _add_para(doc, f"译后编辑深度：{pe}", size=11)

    # ---- 五、各类别差错计数 ----
    _add_heading(doc, "五、各类别差错计数", level=1)
    ct = doc.add_table(rows=1, cols=4)
    ct.style = "Table Grid"
    ct.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, htext in enumerate(["国标类别", "定义", "系数", "数量"]):
        _set_cell(ct.rows[0].cells[i], htext, bold=True, size=10)
    _style_header_row(ct.rows[0], size=10)
    for cat, definition, coef in CATEGORY_DEFS:
        row = ct.add_row().cells
        tcol, _ = CAT_STYLE.get(cat, ("000000", None))
        _set_cell(row[0], cat, bold=True, size=10, color=RGBColor.from_string(tcol),
                  align=WD_ALIGN_PARAGRAPH.CENTER)
        _set_cell(row[1], definition, size=9.5, align=WD_ALIGN_PARAGRAPH.LEFT)
        _set_cell(row[2], str(coef), size=10, align=WD_ALIGN_PARAGRAPH.CENTER)
        _set_cell(row[3], str(counts[cat]), size=10, align=WD_ALIGN_PARAGRAPH.CENTER)
    total = sum(counts.values())
    row = ct.add_row().cells
    for i, v in enumerate(["合计", "", "", str(total)]):
        _set_cell(row[i], v, bold=True, size=10, align=WD_ALIGN_PARAGRAPH.CENTER)
        _shade_cell(row[i], TOTAL_FILL)
    _set_table_fixed(ct, [Cm(1.6), Cm(11.0), Cm(1.8), Cm(1.8)])

    # ---- 六、综合差错率与合格判定 ----
    _add_heading(doc, "六、综合差错率与合格判定（GB/T 19682-2005 第 7.4 条）", level=1)
    if rate is not None:
        _add_para(doc, f"综合差错率 = {_rate_process_text(k, ca, counts, w)} = {rate}‰", size=11)
    _add_para(doc, f"合格线：≤ {threshold}‰（千分号；不足千字按千字计算）", size=11)
    verdict = _add_para(doc, f"判定：{grade}", size=16, bold=True, color=GREEN if passed else RED)
    verdict.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if iteration and (not passed):
        _add_para(doc,
                  f"注：经 {iteration.get('rounds')} 轮迭代仍有缺陷未消除。",
                  size=10.5, color=RED, align=WD_ALIGN_PARAGRAPH.CENTER)
    ext = data.get("grade_detail_non_standard")
    if ext and (ext.get("enabled") or ext.get("level")):
        _add_para(doc, "可选扩展分档（非国标约定，仅供内部/客户交付评级参考）：", size=11, bold=True)
        thresholds = ext.get("thresholds_permil") or {}
        _add_para(doc,
                  f"优秀 ≤ {thresholds.get('excellent', 0.5)}‰ / "
                  f"良好 ≤ {thresholds.get('good', 1.0)}‰ / "
                  f"合格 ≤ {thresholds.get('pass', 1.5)}‰ / 不合格 > {thresholds.get('pass', 1.5)}‰",
                  size=10, indent=True)
        _add_para(doc, f"本次评级：{ext.get('level') or '（未评级）'}", size=11, indent=True)

    # ---- 七、附录 ----
    _add_heading(doc, "七、附录：公式与国标条款索引", level=1)
    notes = [
        "综合差错率 = K × C_A × (3·DⅠ + 1·DⅡ + 0.5·DⅢ + 0.25·DⅣ) / W × 1000（单位：‰）",
        "W = 合同计字总字符数；不足千字按千字计算。",
        "同一差错重复出现时按一次计（GB/T 19682-2005 附录 A）。",
        "C_A：Ⅰ类用途=1，Ⅱ类用途=0.75，Ⅲ类用途=0.5，Ⅳ类用途=0.25。",
        "K：综合难度系数，建议取值 0.5~1.0，由供需双方约定。",
        "类别着色：Ⅰ类(红)最严重、Ⅱ类(橙)、Ⅲ类(黄)、Ⅳ类(蓝灰)。",
        "定性检查依据：GB/T 40036-2021 4.3.2 与第 6 章（深度译后编辑要求）。",
    ]
    for n in notes:
        _add_para(doc, f"• {n}", size=10)

    doc.save(out_path)
    return out_path


# ============================================================
# 文档二：原文与推荐译文对照（给客户，商务简洁，无判断逻辑）
# ============================================================

def build_comparison(data, out_path):
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(11)
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), "宋体")

    section = doc.sections[0]
    section.top_margin = Cm(2.2)
    section.bottom_margin = Cm(2.0)
    section.left_margin = Cm(2.5)
    section.right_margin = Cm(2.5)
    _add_page_number_footer(section)

    meta, _, _, _, _, _, _, _, _, src_lang, tgt_lang, need_en_col = _load_meta(data)
    alignment = data.get("alignment") or []
    defects_by_no = _defects_by_no(data.get("defects") or [])

    # ---- 标题区（商务简洁） ----
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_before = Pt(6)
    title.paragraph_format.space_after = Pt(2)
    run = title.add_run("原文与推荐译文对照")
    _set_run_font(run, size=22, bold=True, cn_font="黑体", color=DARK)
    # 标题下装饰线
    pPr = title._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "12")
    bottom.set(qn("w:space"), "4")
    bottom.set(qn("w:color"), COMP_ACCENT)
    pBdr.append(bottom)
    pPr.append(pBdr)

    # 副标题信息行
    proj = meta.get("project") or "翻译项目"
    lang_dir = f"{src_lang or '源'} → {tgt_lang or '译'}"
    subtitle_parts = [proj, meta.get("date") or datetime.date.today().isoformat(),
                      f"语言方向 {lang_dir}"]
    subtitle = "　|　".join(subtitle_parts)
    _add_para(doc, subtitle, size=10, align=WD_ALIGN_PARAGRAPH.CENTER, color=LIGHT_GREY,
              space_after=4)

    # 装饰性分隔
    sep = doc.add_paragraph()
    sep.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sep.paragraph_format.space_before = Pt(0)
    sep.paragraph_format.space_after = Pt(10)
    sep_run = sep.add_run("— — — — — — — — — —")
    _set_run_font(sep_run, size=9, color=LIGHT_GREY)

    # ---- 对照表 ----
    if not alignment:
        _add_para(doc, "（未提供全文对照数据。）", size=10, color=RED)
    else:
        headers = ["段号", "原文", "推荐译文"]
        widths = [Cm(1.0), Cm(7.0), Cm(7.0)]
        if need_en_col:
            headers.append("英文参考译文")
            widths = [Cm(1.0), Cm(5.4), Cm(5.4), Cm(3.2)]
        at = doc.add_table(rows=1, cols=len(headers))
        at.style = "Table Grid"
        at.alignment = WD_TABLE_ALIGNMENT.CENTER
        at.autofit = False
        for i, htext in enumerate(headers):
            _set_cell(at.rows[0].cells[i], htext, bold=True, size=10)
        _style_header_row(at.rows[0], size=10, fill=COMP_HEADER_FILL)
        # 表头行单元格边距加大
        for cell in at.rows[0].cells:
            _set_cell_margins(cell, top=80, bottom=80)

        for idx, r in enumerate(alignment):
            no = r.get("no")
            rec = _recommended_for_row(r, defects_by_no.get(no) if no is not None else None)
            eng = (r.get("english") or "").strip()
            if not eng and need_en_col:
                eng_lines = [(d.get("english_reference") or "").strip() for d in _sorted_defects(defects_by_no.get(no) or [])]
                eng = "\n".join(e for e in eng_lines if e) or "—"
            vals = [
                no if no is not None else "—",
                r.get("source") or "",
                rec,
            ]
            if need_en_col:
                vals.append(eng or "—")
            row = at.add_row().cells
            for i, v in enumerate(vals):
                _set_cell(row[i], v, size=10,
                          align=WD_ALIGN_PARAGRAPH.CENTER if i == 0 else WD_ALIGN_PARAGRAPH.LEFT)
                _set_cell_margins(row[i], top=70, bottom=70)
            # 斑马纹
            if idx % 2 == 1:
                for c in row:
                    _shade_cell(c, ZEBRA_FILL)
        _set_table_fixed(at, widths)
        _add_para(doc, "", size=4)

    # ---- 页脚说明 ----
    _add_para(doc, "", size=8)
    _add_para(doc, "本文件为翻译成果交付件，仅供项目相关方使用。",
              size=8.5, align=WD_ALIGN_PARAGRAPH.CENTER, color=LIGHT_GREY)

    doc.save(out_path)
    return out_path


# ---------------- 入口 ----------------

def main():
    ap = argparse.ArgumentParser(
        description="生成翻译质检交付物：质检模式出双文档（报告+对照），自我迭代翻译模式仅出对照文档")
    ap.add_argument("--input", "-i", required=True, help="质检结果 JSON 文件")
    ap.add_argument("--out-dir", "-d", default=".", help="输出目录；缺省当前目录")
    ap.add_argument("--prefix", "-p", default="", help="文件名前缀（如项目名）；缺省用时间戳")
    ap.add_argument("--mode", "-m", default=None,
                    choices=["quality_inspection", "self_iterative"],
                    help="生成模式：quality_inspection（默认，双文档）或 self_iterative（仅对照文档）。"
                         "未指定时读取 JSON 的 mode 字段，仍缺省则按 quality_inspection 处理。")
    args = ap.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 确定模式：命令行 > JSON.mode > 默认 quality_inspection
    mode = args.mode
    if mode is None:
        mode = data.get("mode", "quality_inspection")

    os.makedirs(args.out_dir, exist_ok=True)
    if args.prefix:
        prefix = args.prefix.rstrip("_")
        comp_name = f"{prefix}_原文与推荐译文对照.docx"
    else:
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        comp_name = f"原文与推荐译文对照_{stamp}.docx"

    comp_path = os.path.join(args.out_dir, comp_name)
    build_comparison(data, comp_path)
    print(f"[OK] 原文与推荐译文对照已生成: {comp_path}")

    if mode == "quality_inspection":
        if args.prefix:
            qual_name = f"{prefix}_翻译质量报告.docx"
        else:
            qual_name = f"翻译质量报告_{stamp}.docx"
        qual_path = os.path.join(args.out_dir, qual_name)
        build_quality_report(data, qual_path)
        print(f"[OK] 翻译质量报告已生成: {qual_path}")
    else:
        print(f"[INFO] 自我迭代翻译模式：仅生成对照文档，跳过质量报告。")


if __name__ == "__main__":
    main()
