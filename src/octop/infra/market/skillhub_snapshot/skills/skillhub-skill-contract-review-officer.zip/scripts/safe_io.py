#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""统一文件读取：编码探测 · 瞬时重试 · 特殊文件识别

为什么必须收成一个入口
    旧版有 4 个读取点（check / diff / redline / 自检），每处都写死
    encoding="utf-8"。加一个入口就多一处漏，而且漏了不会报错，
    只会在遇到 GBK 合同时让用户「另存为 UTF-8」——把兼容问题推给用户，
    是工具最容易犯的懒。
    收成一个函数之后，以后加多少命令都自动继承同一套容错。

三道防线
    1. 跑之前：文件在不在、是不是目录、有多大、是不是二进制；
    2. 跑的时候：瞬时占用重试（网络盘、同步盘、杀毒软件扫描会短暂锁文件）；
    3. 跑不通：把「为什么」和「下一步做什么」一起给出来，不是甩一个 E11。

解决得了与解决不了的
    解决得了：GBK/GB18030/UTF-16/Big5 编码、BOM、\r\n、瞬时占用、超大文件、
              二进制误传、docx 是 .doc 改名、docx 损坏或加密。
    解决不了：文件被 Word 独占打开、组织策略禁止读取、磁盘满、文件物理损坏。
              这几种给明确下一步，不假装能处理。
"""

import codecs
import errno
import os
import time

# 编码探测顺序：先严格后宽松。
# gb18030 放在 big5 前面，是因为简体中文场景远多于繁体；
# 但 gb18030 几乎能解出任何字节序列，所以它必须是「前面的都失败之后」才试。
ENCODINGS = ("utf-8", "utf-8-sig", "gb18030", "big5", "utf-16", "utf-16-le", "utf-16-be")

MAX_MB = 30

# 文件魔数：这些格式即使扩展名写成 .md/.txt，也不能当文本读。
# 靠扩展名判断是不可靠的——用户把 PDF 改成 .txt 是常见操作。
MAGIC = [
    (b"%PDF", "PDF", "本命令只读文本（.md/.txt）与 .docx。"
                     "PDF 请先用 Word 或 WPS 转成 .docx；扫描件需先做 OCR"),
    (b"PK\x03\x04", "ZIP 容器（多半是 .docx/.xlsx/.pptx）",
     "文本类命令只读 .md/.txt；要看 docx 请用 --redline，或先导出为文本"),
    (b"\xd0\xcf\x11\xe0", "Word 97-2003 或 Excel（.doc/.xls）",
     "请在 Word/WPS 中「另存为」.docx 后再处理；.doc 不是压缩包，读不出修订结构"),
    (b"\x89PNG", "PNG 图片", "这是图片，不是文本合同"),
    (b"\xff\xd8\xff", "JPEG 图片", "这是图片，不是文本合同"),
    (b"GIF8", "GIF 图片", "这是图片，不是文本合同"),
    (b"Rar!", "RAR 压缩包", "请解压后再处理其中的合同文件"),
    (b"7z\xbc\xaf", "7z 压缩包", "请解压后再处理其中的合同文件"),
]


def _magic_kind(data):
    for sig, kind, hint in MAGIC:
        if data.startswith(sig):
            return kind, hint
    return None, None


class ReadError(Exception):
    """带错误码与下一步建议的读取失败。

    自定义异常而不是直接抛 OSError，是为了让调用方拿到的
    不只是一句「读不了」，而是「为什么读不了 + 你现在该做什么」。
    """

    def __init__(self, code, message, hint=None):
        self.code = code
        self.message = message
        self.hint = hint
        super().__init__(message)

    def __str__(self):
        if self.hint:
            return "%s。%s" % (self.message, self.hint)
        return self.message


def _looks_binary(data):
    """判断是不是二进制。

    两个坑：
    · UTF-16 会大量出现 0x00（ASCII 字符的高字节），按「有 0x00 就是二进制」
      判，会把一整份 UTF-16 合同拒掉；
    · 反过来，如果只看「有没有 0x00」就放行，.doc 这类 OLE 文件会被
      utf-16「成功」解码成一堆乱码，然后当成正常合同往下跑。
    所以分两步：NUL 很少 → 先当文本试（解不出来还有可打印率兜底）；
    NUL 很多 → 看是否呈 UTF-16 的奇偶分布，是则放行，否则判二进制。
    """
    head = data[:8192]
    if not head:
        return False
    if head.startswith(codecs.BOM_UTF8):
        return False
    if head.startswith(codecs.BOM_UTF16_LE) or head.startswith(codecs.BOM_UTF16_BE):
        return False
    if b"\x00" not in head:
        return False

    nul_ratio = head.count(b"\x00") / float(len(head))
    if nul_ratio < 0.05:
        return False  # NUL 很稀疏，先按文本解，靠可打印率兜底

    odd_nul = sum(1 for i in range(1, len(head), 2) if head[i] == 0)
    even_nul = sum(1 for i in range(0, len(head), 2) if head[i] == 0)
    half = max(1, len(head) // 2)
    if odd_nul / half > 0.35 or even_nul / half > 0.35:
        return False  # 呈 UTF-16 规律
    return True


def _looks_garbage(text):
    """解出来的东西是不是人话。

    任何偶数长度的字节串都能被 utf-16「解码成功」，
    UTF-16 的中文合同也能被 utf-8「解码成功」——只是正文里塞满控制字符。
    所以「decode 没抛异常」完全不能证明编码猜对了，必须看解出来像不像文字。

    两条判据：控制字符比例、替换字符与私用区字符比例。
    真实合同文本里这两类几乎为零，超过 2% 就说明解错了。
    """
    sample = text[:4000]
    if not sample:
        return True
    n = float(len(sample))
    ctrl = sum(1 for ch in sample if ord(ch) < 32 and ch not in "\n\r\t")
    if ctrl / n > 0.02:
        return True
    weird = sum(1 for ch in sample if ch == "\ufffd" or 0xE000 <= ord(ch) <= 0xF8FF)
    if weird / n > 0.02:
        return True
    return False


def _try_decode(data):
    """返回 (文本, 编码名, 警告)；全部失败返回 (None, None, 原因)。"""
    if data.startswith(codecs.BOM_UTF8):
        return data.decode("utf-8-sig", "replace"), "utf-8-sig", None
    if data.startswith(codecs.BOM_UTF16_LE) or data.startswith(codecs.BOM_UTF16_BE):
        return data.decode("utf-16", "replace"), "utf-16", None

    for enc in ENCODINGS:
        try:
            text = data.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
        if _looks_garbage(text):
            continue  # 解得出来但全是乱码，不算解得出来
        warn = None
        if enc not in ("utf-8", "utf-8-sig"):
            warn = ("文件不是 UTF-8，已按 %s 解码。"
                    "若正文出现乱码，请将其另存为 UTF-8 后重试。" % enc)
        return text, enc, warn
    return None, None, "无法识别编码（可能不是文本文件，或编码不在支持范围）"


def read_text(path, retries=2, max_mb=MAX_MB):
    """读文本文件。返回 (文本, 编码, 警告)；失败抛 ReadError。

    重试只针对「瞬时占用」类错误（EBUSY / EAGAIN / ETXTBSY / EACCES 的第一次），
    不重试「文件不存在」——那种重试一百次也不会变。
    """
    if not path:
        raise ReadError("E11", "没有给出文件路径")

    for attempt in range(retries + 1):
        try:
            if os.path.isdir(path):
                raise ReadError("E11", "这是一个目录，不是文件：%s" % path,
                                "请指定具体文件，例如 合同.md")

            size = os.path.getsize(path)
            if size == 0:
                raise ReadError("E11", "文件是空的：%s" % path,
                                "确认是否保存成功，或换一份文件重试")
            if size > max_mb * 1024 * 1024:
                raise ReadError("E11",
                                "文件过大：%.1f MB（上限 %d MB）" % (size / 1048576.0, max_mb),
                                "合同正文通常远小于此。若确实是合同，请拆分成单份合同再查；"
                                "若是扫描件转的文字，建议先清理页眉页脚与页码")

            with open(path, "rb") as fh:
                data = fh.read()
            break
        except ReadError:
            raise
        except FileNotFoundError:
            raise ReadError("E11", "文件不存在：%s" % path,
                            "检查路径拼写；路径含空格或中文时请用引号包起来")
        except PermissionError:
            # 第一次可能是杀毒软件/同步盘短暂占用，值得重试；重试仍失败才判定无权限
            if attempt < retries:
                time.sleep(0.3 * (attempt + 1))
                continue
            raise ReadError("E11", "没有读取权限：%s" % path,
                            "确认文件未被其他程序独占；在 macOS 上可用"
                            "「系统设置 → 隐私与安全性 → 文件与文件夹」检查授权")
        except OSError as exc:
            transient = exc.errno in (errno.EBUSY, errno.EAGAIN, errno.ETXTBSY, errno.EIO)
            if transient and attempt < retries:
                time.sleep(0.3 * (attempt + 1))
                continue
            if exc.errno == errno.ENOSPC:
                raise ReadError("E11", "磁盘空间不足：%s" % path,
                                "清理磁盘后重试")
            raise ReadError("E11", "读取失败：%s（%s）" % (path, exc.strerror or exc),
                            "若文件在网络盘或同步盘上，先确保已完全下载到本地")

    # 顺序很关键：先认魔数（强信号），再试解码，最后才判二进制。
    # 反过来会误杀 UTF-16——中文码位低字节经常是 0x00（如「一」U+4E00 → 00 4E），
    # NUL 比例可以高到 20%，按「有 NUL 就是二进制」判，整份合同直接被拒。
    # 能解出正常文字，就说明它是文本；解不出来，才轮到「是不是二进制」这个问题。
    kind, hint = _magic_kind(data)
    if kind:
        raise ReadError("E11", "这不是文本文件（%s）：%s" % (kind, path), hint)

    text, enc, warn = _try_decode(data)
    if text is None:
        if _looks_binary(data):
            raise ReadError("E11", "这是二进制文件，不是文本合同：%s" % path,
                            "确认文件类型；合同正文应为可编辑文本（.md/.txt）或 .docx")
        raise ReadError("E11", "无法识别文件编码：%s" % path,
                        "该文件的编码不在支持范围（UTF-8/GBK/Big5/UTF-16）。"
                        "请用文本编辑器另存为 UTF-8 后重试")

    # \r\n 归一化：不归一会让「按行定位」在第 1 行之后全部偏移
    if "\r\n" in text:
        text = text.replace("\r\n", "\n")
    return text, enc, warn


def read_docx_bytes(path, retries=2, max_mb=MAX_MB):
    """读 docx 的原始字节。与 read_text 共用同一套存在性/大小/重试逻辑。"""
    if not path:
        raise ReadError("E11", "没有给出文件路径")
    if not path.lower().endswith(".docx"):
        if path.lower().endswith(".doc"):
            raise ReadError("E11", "这是 Word 97-2003 格式（.doc）：%s" % path,
                            "请在 Word/WPS 中「另存为」.docx 后再处理；"
                            ".doc 不是压缩包，本工具无法读取其修订结构")
        raise ReadError("E11", "不支持的文件类型：%s" % path,
                        "本命令只处理 .docx")

    for attempt in range(retries + 1):
        try:
            if os.path.isdir(path):
                raise ReadError("E11", "这是一个目录，不是文件：%s" % path)
            size = os.path.getsize(path)
            if size == 0:
                raise ReadError("E11", "文件是空的：%s" % path, "确认文档已保存")
            if size > max_mb * 1024 * 1024:
                raise ReadError("E11", "文件过大：%.1f MB（上限 %d MB）"
                                % (size / 1048576.0, max_mb), "请拆分文档后再处理")
            with open(path, "rb") as fh:
                return fh.read()
        except ReadError:
            raise
        except FileNotFoundError:
            raise ReadError("E11", "文件不存在：%s" % path, "检查路径拼写")
        except PermissionError:
            if attempt < retries:
                time.sleep(0.3 * (attempt + 1))
                continue
            raise ReadError("E11", "没有读取权限：%s" % path,
                            "文件可能正被 Word 独占打开，关闭后重试")
        except OSError as exc:
            if exc.errno in (errno.EBUSY, errno.EAGAIN, errno.ETXTBSY) and attempt < retries:
                time.sleep(0.3 * (attempt + 1))
                continue
            raise ReadError("E11", "读取失败：%s（%s）" % (path, exc.strerror or exc))


def diagnose_docx(path):
    """给 docx 做一次体检，把「打不开」翻译成人话。

    返回 (是否可用, 问题说明, 下一步建议)
    """
    import zipfile
    try:
        data = read_docx_bytes(path)
    except ReadError as exc:
        return False, exc.message, exc.hint

    if data[:2] != b"PK":
        return (False, "这不是有效的 .docx（文件头不是 ZIP）",
                "可能被错误地改了扩展名，或文件已损坏。用 Word 打开另存为 .docx 试一次")

    import io
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = z.namelist()
            if "word/document.xml" not in names:
                if any("EncryptedPackage" in n for n in names):
                    return (False, "文档已加密（设置了打开密码）",
                            "请先用 Word 去掉密码保护：文件 → 信息 → 保护文档 → 用密码进行加密，清空密码")
                return (False, "不是有效的 Word 文档（缺少 word/document.xml）",
                        "可能是 WPS 的 .wps 改名、或模板文件。用 Word/WPS 另存为 .docx")
            return True, "", ""
    except zipfile.BadZipFile:
        return (False, "压缩结构已损坏",
                "文件可能下载不完整。重新获取原文件后重试")
    except Exception as exc:  # noqa: BLE001
        return False, "解析失败：%s" % exc, "用 Word 打开并另存为 .docx 后重试"
