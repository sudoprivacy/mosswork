#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""两版对比：把「文字改了」翻译成「交易条件改了」

为什么普通 diff 不够
    文字 diff 会告诉你「第 7 段改动了 12 个字」，但合同审查要回答的是
    「付款期从 90 天改成 30 天，谁受益」——这是两个问题。
    所以这里做三件事：段落级对齐 → 变更归入交易维度 → 单独拎出数字变化。

判据的边界
    规则只能给线索，不能替代判断。所以输出一律带「维度命中」与「原文对照」，
    不直接下「对谁有利」的结论——那取决于你是甲方还是乙方。
"""

import difflib
import re

# 交易维度：命中即归入该维度。level 表示该维度变更的分量
DIMENSIONS = [
    ("价款", "high", ["价款", "金额", "总价", "单价", "价格", "报价", "含税", "税率", "发票"]),
    ("付款条件", "high", ["付款", "支付", "预付", "账期", "结算", "尾款", "质保金", "汇款"]),
    ("交付与验收", "high", ["交付", "交货", "工期", "验收", "签收", "交付时间", "安装", "调试"]),
    ("违约责任", "high", ["违约", "赔偿", "滞纳", "罚款", "违约金", "损失"]),
    ("责任限制", "high", ["上限", "不超过", "免除", "不承担", "概不负责", "免责", "责任限额"]),
    ("争议解决", "high", ["管辖", "仲裁", "法院", "诉讼", "争议"]),
    ("担保", "high", ["担保", "保证", "抵押", "质押", "保证金", "连带"]),
    ("知识产权", "mid", ["知识产权", "著作权", "专利", "商标", "成果归属", "成果", "许可"]),
    ("保密", "mid", ["保密", "商业秘密", "不得披露", "机密"]),
    ("解除与续期", "mid", ["解除", "终止", "续约", "续期", "到期", "提前退"]),
    ("质保与售后", "mid", ["质保", "保修", "售后", "维保", "维修"]),
    ("限制性条款", "mid", ["竞业", "排他", "独家", "不得", "禁止", "唯一"]),
    ("不可抗力", "low", ["不可抗力", "情势变更", "政策变化"]),
]

# 语气/权义方向词：只统计，不替用户判断方向
RIGHT_WORDS = ["有权", "可要求", "自行", "单方", "无需", "不予", "可解除", "可终止"]
DUTY_WORDS = ["应当", "应", "须", "负责", "承担", "保证", "赔偿", "配合", "提供"]

NUM_RE = re.compile(r"\d+(?:\.\d+)?\s*(?:%|‰|天|日|个工作日|个月|年|万元|元|倍|次)?")


def _norm(text):
    """归一化：去掉空白与全半角差异，避免「90天」和「90 天」被当成两处改动。"""
    t = text.replace("\u3000", " ")
    t = re.sub(r"\s+", "", t)
    return t


def read_paragraphs(path):
    """读段落。docx 走 OOXML，其余按纯文本（都经 safe_io，编码自动探测）。"""
    if path.lower().endswith(".docx"):
        import ooxml_redline as ox
        spans = ox.scan_paragraphs(ox.read_docx_xml(path))
        return [t for _, _, _, t in spans if t.strip()]
    import safe_io
    text, _enc, _warn = safe_io.read_text(path)
    return [ln.strip() for ln in text.split("\n") if ln.strip()]


def _dims_of(text):
    hit = []
    for name, level, kws in DIMENSIONS:
        if any(k in text for k in kws):
            hit.append((name, level))
    return hit


def _nums(text):
    return [m.group(0).replace(" ", "") for m in NUM_RE.finditer(text)]


def _polarity(text):
    r = sum(text.count(w) for w in RIGHT_WORDS)
    d = sum(text.count(w) for w in DUTY_WORDS)
    return r, d


def compare(old_path, new_path, sim_threshold=0.5):
    """返回结构化对比结果。"""
    a = read_paragraphs(old_path)
    b = read_paragraphs(new_path)
    if not a and not b:
        raise ValueError("两份文件都没有可识别的段落")

    sm = difflib.SequenceMatcher(None, [_norm(x) for x in a], [_norm(x) for x in b])
    changes = []

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        if tag == "replace":
            # 相似度高的成对判为「修改」，否则拆成「删 + 增」——
            # 否则整段重写会被报成一句修改，看不出其实换了整条交易条件。
            pairs = min(i2 - i1, j2 - j1)
            for k in range(pairs):
                o, n = a[i1 + k], b[j1 + k]
                ratio = difflib.SequenceMatcher(None, _norm(o), _norm(n)).ratio()
                if ratio >= sim_threshold:
                    changes.append(("修改", o, n))
                else:
                    changes.append(("删除", o, ""))
                    changes.append(("新增", "", n))
            for k in range(i1 + pairs, i2):
                changes.append(("删除", a[k], ""))
            for k in range(j1 + pairs, j2):
                changes.append(("新增", "", b[k]))
        elif tag == "delete":
            for k in range(i1, i2):
                changes.append(("删除", a[k], ""))
        elif tag == "insert":
            for k in range(j1, j2):
                changes.append(("新增", "", b[k]))

    detailed = []
    for kind, o, n in changes:
        body = (o if kind != "新增" else "") + (n if kind != "删除" else "")
        dims = _dims_of(o + n)
        nums_o, nums_n = _nums(o), _nums(n)
        num_changed = [x for x in nums_o if x not in nums_n] + \
                      [x for x in nums_n if x not in nums_o]
        ro, do = _polarity(o)
        rn, dn = _polarity(n)
        detailed.append({
            "kind": kind,
            "old": o,
            "new": n,
            "dims": dims,
            "nums_changed": num_changed,
            "substantive": bool(dims),
            "right_delta": rn - ro,
            "duty_delta": dn - do,
            "words": len(body),
        })

    # 实质变更：命中交易维度，或涉及数字/比例变化
    subs = [c for c in detailed if c["substantive"] or c["nums_changed"]]
    risk = sum(2 if any(l == "high" for _, l in c["dims"]) else 1 for c in subs)

    dim_count = {}
    for c in subs:
        for name, level in c["dims"]:
            dim_count.setdefault(name, {"count": 0, "level": level})
            dim_count[name]["count"] += 1

    return {
        "old": old_path, "new": new_path,
        "counts": {
            "old_paras": len(a), "new_paras": len(b),
            "changes": len(detailed), "substantive": len(subs),
            "insert": sum(1 for c in detailed if c["kind"] == "新增"),
            "delete": sum(1 for c in detailed if c["kind"] == "删除"),
            "modify": sum(1 for c in detailed if c["kind"] == "修改"),
        },
        "dimensions": dim_count,
        "risk_delta": risk,
        "changes": detailed,
        "substantive_changes": subs,
    }
