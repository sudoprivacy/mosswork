#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OOXML 原生修订写入器（零第三方依赖）

为什么手写 XML 而不用 python-docx
    · python-docx 不提供修订痕迹（w:ins / w:del）的写接口；
    · 目标环境不一定装了 python-docx，多一个依赖就多一处交付失败点；
    · 修订痕迹是可被 Word / WPS 接受或拒绝的结构，必须逐字节可控。

产出真吗
    真。Word 打开后「审阅 → 修订」里能看到作者、时间、每一处改动的
    插入与删除，可逐条接受或拒绝。这不是把文字涂成红色冒充修订。

修订的两条路径
    · inline   段落内文本替换：前缀保留 → 原文进 w:del → 新文进 w:ins → 后缀保留
    · paragraph 整段增删：新增段整段进 w:ins，删除段整段进 w:del
"""

import datetime
import os
import re
import zipfile

NS_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>
</Types>"""

ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>
</Relationships>"""

# 打开文档即进入修订模式：后续任何人的改动也会被记录，
# 避免「我们做了修订、对方改完发回来却看不到他改了什么」。
SETTINGS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:settings xmlns:w="%s">
<w:trackChanges/>
<w:defaultTabStop w:val="420"/>
<w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat>
</w:settings>""" % NS_W

SECT_PR = ('<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
           '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" '
           'w:header="851" w:footer="992" w:gutter="0"/></w:sectPr>')


def esc(text):
    """XML 转义。顺序不能变：先 & 再 < >，否则会二次转义出 &amp;lt;。"""
    return (str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def now_iso():
    return datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")


class RevIds(object):
    """w:id 必须全文档唯一，重复会让 Word 报文档损坏。"""

    def __init__(self):
        self.n = 0

    def next(self):
        self.n += 1
        return self.n


def run(text, rpr=""):
    return '<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r>' % (rpr, esc(text))


def ins_run(text, ids, author, date, rpr=""):
    return ('<w:ins w:id="%d" w:author="%s" w:date="%s">%s</w:ins>'
            % (ids.next(), esc(author), date, run(text, rpr)))


def del_run(text, ids, author, date, rpr=""):
    return ('<w:del w:id="%d" w:author="%s" w:date="%s">'
            '<w:r>%s<w:delText xml:space="preserve">%s</w:delText></w:r></w:del>'
            % (ids.next(), esc(author), date, rpr, esc(text)))


def para(content, ppr=""):
    return "<w:p>%s%s</w:p>" % (ppr, content)


def plain_para(text, style=""):
    ppr = '<w:pPr><w:pStyle w:val="%s"/></w:pPr>' % style if style else ""
    return para(run(text), ppr)


# ---------------------------------------------------------------------------
# 读：从 docx 取段落
# ---------------------------------------------------------------------------
def unesc(text):
    return (text.replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", '"').replace("&apos;", "'")
                .replace("&amp;", "&"))


def read_docx_xml(path):
    """读 document.xml 原文。读不到直接抛，不返回空串——
    空串会让调用方以为「文档没问题」，而实际是根本没读到。

    先用 safe_io 做一次体检：加密、损坏、.doc 改名、下载不完整，
    这四种「打不开」的原因各不相同，给的处理建议也完全不同。
    统一报「不是有效的 docx」等于什么都没说。
    """
    import io

    import safe_io

    ok, msg, hint = safe_io.diagnose_docx(path)
    if not ok:
        raise ValueError(("%s。%s" % (msg, hint)) if hint else msg)
    data = safe_io.read_docx_bytes(path)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        try:
            return z.read("word/document.xml").decode("utf-8")
        except KeyError:
            raise ValueError("不是有效的 docx：缺少 word/document.xml")
        except UnicodeDecodeError:
            raise ValueError("document.xml 不是合法的 UTF-8，文档可能已损坏")


def scan_paragraphs(xml):
    """在 body 全文中定位每个段落，返回 [(start, end, 段落XML, 纯文本)]。

    必须在全文上原位替换，不能「逐段拼回去」。
    真实合同的价格表、付款节点表、交付清单都在 w:tbl 里，
    按段落重建 body 会把整张表丢掉——那不是改合同，是把合同改坏。
    """
    spans = []
    for m in re.finditer(r"<w:p\b[^>]*>.*?</w:p>|<w:p\b[^>]*/>", xml, re.S):
        px = m.group(0)
        raw = unesc("".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", px, re.S)))
        spans.append((m.start(), m.end(), px, raw))
    return spans


def read_plain(path):
    """读纯文本。编码探测与重试统一交给 safe_io，这里只负责切行。"""
    import safe_io

    text, _enc, _warn = safe_io.read_text(path)
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()  # 末尾换行不该被算成一行空段落
    return lines


# ---------------------------------------------------------------------------
# 写：修订
# ---------------------------------------------------------------------------
def _pPr(px):
    m = re.search(r"<w:pPr>.*?</w:pPr>", px, re.S)
    return m.group(0) if m else ""


def _first_rPr(px):
    m = re.search(r"<w:rPr>.*?</w:rPr>", px, re.S)
    return m.group(0) if m else ""


def apply_inline(px, old, new, ids, author, date):
    """段落内替换：原文进 w:del、新文进 w:ins，前后缀原样保留。
    返回 (新段落 XML, 是否命中)。"""
    ptxt = "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", px, re.S))
    # 用解码后的纯文本做定位，避免 XML 实体把偏移算错
    plain = (ptxt.replace("&lt;", "<").replace("&gt;", ">")
                  .replace("&quot;", '"').replace("&apos;", "'")
                  .replace("&amp;", "&"))
    idx = plain.find(old)
    if idx < 0:
        return px, False
    before, after = plain[:idx], plain[idx + len(old):]
    rpr = _first_rPr(px)
    body = []
    if before:
        body.append(run(before, rpr))
    body.append(del_run(old, ids, author, date, rpr))
    if new:
        body.append(ins_run(new, ids, author, date, rpr))
    if after:
        body.append(run(after, rpr))
    return para("".join(body), _pPr(px)), True


def write_docx(document_xml, out_path):
    d = os.path.dirname(os.path.abspath(out_path))
    if d and not os.path.isdir(d):
        os.makedirs(d)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", CONTENT_TYPES)
        z.writestr("_rels/.rels", ROOT_RELS)
        z.writestr("word/document.xml", document_xml)
        z.writestr("word/_rels/document.xml.rels", DOC_RELS)
        z.writestr("word/settings.xml", SETTINGS)
    return out_path


def text_to_document(lines):
    """纯文本 → 完整 document.xml。走和 docx 同一条修订路径，
    避免「文本版能改、docx 版改不了」这种双路径行为分裂。"""
    body = "".join(plain_para(ln) for ln in lines) + SECT_PR
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:document xmlns:w="%s" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            "<w:body>%s</w:body></w:document>") % (NS_W, body)


def redline(src_path, out_path, patches, author="合同审查官"):
    """核心入口。patches: [{"old","new","reason","scope"}]

    返回 dict：applied（明细）、missed（未命中）、counts
    """
    ids = RevIds()
    date = now_iso()
    applied, missed = [], []

    if src_path.lower().endswith(".docx"):
        xml = read_docx_xml(src_path)
    else:
        xml = text_to_document(read_plain(src_path))

    spans = scan_paragraphs(xml)
    if not spans:
        raise ValueError("文档里没有可识别的段落，无法做修订")

    # 只记替换指令，最后从后往前统一应用：
    # 边改边算偏移，会让后面每一条 patch 的坐标全部错位。
    edits = []   # (start, end, new_xml)
    inserts = []  # (pos, xml)
    taken = set()

    for pt in patches:
        old = (pt.get("old") or "").strip()
        new = (pt.get("new") or "").strip()
        if not old and not new:
            # 空串能匹配任意位置，放过去会产生一条「假修订」
            missed.append({"kind": "empty", "old": "", "new": "", "reason": "条目为空"})
            continue
        reason = pt.get("reason") or ""
        scope = pt.get("scope") or "inline"

        # 四种意图靠 old / new 是否为空区分，不能靠 scope 区分：
        # scope 只描述「改动落在句内还是整段」，删一段也用 scope=paragraph，
        # 若拿 scope 判增删，删除会被当成插入，结果是删了一段又凭空多一段。
        if not old and new:
            # ---- 插入新段：插在锚点段落之后；无锚点则插在末尾 ----
            pos = None
            ppr = ""
            anchor_search = (pt.get("anchor") or "").strip()
            if anchor_search:
                for s, e, px, txt in spans:
                    if anchor_search in txt:
                        pos = e
                        ppr = _pPr(px)
                        break
                if pos is None:
                    missed.append({"kind": "insert", "old": anchor_search[:40],
                                   "new": new[:40], "reason": reason})
                    continue
            if pos is None:
                pos = spans[-1][1] if spans else 0
                ppr = ""
            ppr = re.sub(r"<w:rPr>.*?</w:rPr>", "", ppr or "")
            ppr = ppr.replace(
                "</w:pPr>",
                '<w:rPr><w:ins w:id="%d" w:author="%s" w:date="%s"/></w:rPr></w:pPr>'
                % (ids.next(), esc(author), date)) if ppr else ppr
            inserts.append((pos, para(ins_run(new, ids, author, date), ppr)))
            applied.append({"kind": "insert", "old": anchor_search[:40],
                            "new": new[:40], "reason": reason})
            continue

        if old and not new:
            # ---- 整段删除：段落标记一并标记删除，否则会留一个空行 ----
            hit = False
            for k, (s, e, px, txt) in enumerate(spans):
                if k in taken or old not in txt:
                    continue
                ppr = re.sub(r"<w:rPr>.*?</w:rPr>", "", _pPr(px))
                ppr = ppr.replace(
                    "</w:pPr>",
                    '<w:rPr><w:del w:id="%d" w:author="%s" w:date="%s"/></w:rPr></w:pPr>'
                    % (ids.next(), esc(author), date)) if ppr else ppr
                edits.append((s, e, para(del_run(txt, ids, author, date), ppr)))
                taken.add(k)
                applied.append({"kind": "delete", "old": txt[:40], "new": "",
                                "reason": reason})
                hit = True
                break
            if not hit:
                missed.append({"kind": "delete", "old": old[:40], "new": "",
                               "reason": reason})
            continue

        if scope == "paragraph":
            # ---- 整段替换：整段划掉，新段落在原位以插入修订呈现 ----
            hit = False
            for k, (s, e, px, txt) in enumerate(spans):
                if k in taken or old not in txt:
                    continue
                ppr = _pPr(px)
                rpr = _first_rPr(px)
                body = del_run(txt, ids, author, date, rpr) + \
                    ins_run(new, ids, author, date, rpr)
                edits.append((s, e, para(body, ppr)))
                taken.add(k)
                applied.append({"kind": "replace", "old": txt[:40], "new": new[:40],
                                "reason": reason})
                hit = True
                break
            if not hit:
                missed.append({"kind": "replace", "old": old[:40], "new": new[:40],
                               "reason": reason})
            continue

        # inline：段落内切三段
        hit = False
        for k, (s, e, px, txt) in enumerate(spans):
            if k in taken or old not in txt:
                continue
            idx = txt.find(old)
            rpr = _first_rPr(px)
            body = []
            if txt[:idx]:
                body.append(run(txt[:idx], rpr))
            body.append(del_run(old, ids, author, date, rpr))
            if new:
                body.append(ins_run(new, ids, author, date, rpr))
            if txt[idx + len(old):]:
                body.append(run(txt[idx + len(old):], rpr))
            edits.append((s, e, para("".join(body), _pPr(px))))
            taken.add(k)
            applied.append({"kind": "inline", "old": old[:40], "new": new[:40],
                            "reason": reason})
            hit = True
            break
        if not hit:
            missed.append({"kind": "inline", "old": old[:40], "new": new[:40],
                           "reason": reason})

    # 替换与插入混在一张表里，全部按原始坐标、从后往前一次应用。
    # 先做替换再算插入的偏移是错的——两轮之间坐标已经变了，
    # 越靠前的插入点偏得越多，而且不会报错，只会安静地把段落插到错位置。
    ops = [(s, 0, (e, newpx)) for s, e, newpx in edits]
    ops += [(pos, 1, newpx) for pos, newpx in inserts]
    ops.sort(key=lambda x: (-x[0], x[1]))
    for pos, kind, payload in ops:
        if kind == 0:
            e, newpx = payload
            xml = xml[:pos] + newpx + xml[e:]
        else:
            xml = xml[:pos] + payload + xml[pos:]

    write_docx(xml, out_path)
    return {
        "out": out_path,
        "applied": applied,
        "missed": missed,
        "counts": {"applied": len(applied), "missed": len(missed),
                   "paragraphs": len(scan_paragraphs(xml))},
        "author": author,
        "date": date,
    }
