#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""合同审查官 · 经营层审查引擎
contract_guard.py

设计纪律
    · 未提供的字段一律标「未测」，绝不默认填 0
    · 枚举越界一律报错并打印合法取值，绝不静默降级
    · 空输入硬阻断，返回需补充的字段清单
    · 所有默认阈值均标注来源，默认值不等于行业标准
    · nan / inf 在入口拦掉——它们会让所有比较失效，最后吐一个看起来正常的结论

退出码
    0  通过
    1  硬阻断（命中红线，或测算结果显示应止步）
    2  需返修（输入不完整 / 越界 / 矛盾）
"""

import argparse
import datetime
import json
import math
import os
import re
import sys

import safe_io
import tempfile

VERSION = "1.5.1"

EXIT_MEANING = {
    0: "通过",
    1: "硬阻断（命中红线 / 应止步）",
    2: "需返修（输入不完整、越界或矛盾）",
}

# ---------------------------------------------------------------------------
# 经验参数（全部可被命令行覆盖，且必须在输出里标注）
# ---------------------------------------------------------------------------
DEFAULT_PARAMS = {
    "margin_cover_red": (1.0, "经验线（最坏净损失 ÷ 合同毛利），低于 1 表示一单亏损吃掉全部利润"),
    "margin_cover_yellow": (2.0, "经验线（同上），1—2 之间为可控但需对冲"),
    "cash_shock_survival": (30.0, "经验线（最坏净损失 ÷ 现金储备 %），超过即生存级风险"),
    "cash_shock_high": (15.0, "经验线（同上），15%—30% 为高危"),
    "cash_shock_low": (5.0, "经验线（同上），低于 5% 为低冲击"),
    "funding_rate": (6.0, "经验值（资金占用成本率 %/年），须按企业真实融资成本替换"),
    "risk_density_red": (5.0, "经验线（红线数 ÷ 条款数 %），超过即判高风险密度"),
}

# 对方主体类型 → 判决后可执行回款率区间（经验值，非法律意见）
COUNTERPARTY_RECOVERY = {
    "国企/政府平台": (60, 80, "有预算与执行压力，但程序周期长"),
    "上市公司": (55, 75, "公开信息披露压力，执行意愿较强"),
    "民营大型": (40, 60, "有资产可执行，但可能转移或拖欠"),
    "中小民企": (15, 35, "资产薄、抗风险弱，胜诉常无财产可执行"),
    "个人": (10, 30, "执行难，多依赖其收入与名下财产"),
    "境外主体": (20, 45, "需跨境承认与执行，周期与成本显著上升"),
}

# 合同必备结构：钱 / 货 / 时间 / 责任 四格
# 四格的关键词要宽，不能窄。
# 窄了会误报「钱 0/5」——合同明明写了「服务费总额」「支付订金」，
# 只因没出现「金额」二字就判全缺，客户当场就会质疑整份报告的可信度。
FOUR_GRID = {
    "钱": ("金额|价款|总价|单价|服务费|报酬|租金|费用|付款|支付|预付|定金|订金|发票|税",
           "金额", "付款方式", "付款时间", "发票与税"),
    "货": ("标的|货物|服务内容|范围|数量|规格|质量|标准|交付|交货|验收|成果",
           "标的内容", "数量规格", "质量标准", "交付与验收"),
    "时间": ("期限|工期|开始|起算|生效|终止|解除|续期|节点|日历天",
           "合同期限", "关键节点", "生效条件", "解除与续期"),
    "责任": ("违约|赔偿|赔偿金|担保|保证|免责|不可抗力|争议|管辖|仲裁",
             "违约责任", "赔偿范围", "担保安排", "争议解决"),
}

CONTRACT_TYPES = ["买卖", "服务", "租赁", "借款担保", "劳动", "知识产权", "数据",
                  "投资", "工程", "运输", "加工承揽", "保密", "框架协议",
                  "股权转让", "代理经销", "仓储", "技术开发", "特许经营",
                  "居间中介", "融资租赁", "股权代持", "其他"]

FINDINGS = []
LOGBUF = []


def add(level, code, msg, detail=None):
    FINDINGS.append({"level": level, "code": code, "msg": msg, "detail": detail})


def out(lines):
    for l in lines:
        print(l)


_EMITTED = [False]


def emit_findings():
    """把校验项统一打出来。分散在各 calc 里打，会出现「加了码却没显示」的死码。

    幂等：多条路径都会调用它（命令自己一次、main 兜底一次），
    不设防就会把一个错误打印两遍，看起来像两个问题。
    """
    if _EMITTED[0]:
        return
    _EMITTED[0] = True
    blocking = [f for f in FINDINGS if f["level"] in ("BLOCK", "ASK")]
    if not blocking:
        return
    print("")
    print("-" * 68)
    for f in blocking:
        print("[%s] %s %s" % ("硬阻断" if f["level"] == "BLOCK" else "需补", f["code"], f["msg"]))
    print("-" * 68)
    code = exit_code_from_findings()
    print("退出码 %d：%s" % (code, EXIT_MEANING[code]))


def rule(title):
    out(["", "=" * 68, title, "=" * 68])


def num(raw, field, lo=None, hi=None, code="E05"):
    """数值解析。未提供返回 None（=未测），绝不默认 0。"""
    if raw is None or raw == "":
        return None
    s = str(raw).strip()
    try:
        val = float(s.replace(",", "").replace("%", ""))
    except (TypeError, ValueError):
        add("ASK", code, "字段「%s」不是有效数值：%r" % (field, raw))
        return None
    # nan / inf 会被 float() 静默接受，之后所有大小比较都是 False，
    # 越界检查全部放行，最后吐出一个看起来完全正常的结论。入口必须挡。
    if not math.isfinite(val):
        add("ASK", code, "字段「%s」=%r 不是有限数值（nan / inf 不能参与测算）" % (field, raw))
        return None
    if lo is not None and val < lo:
        add("ASK", "E04", "字段「%s」=%s 低于合法下限 %s" % (field, val, lo))
        return None
    if hi is not None and val > hi:
        add("ASK", "E04", "字段「%s」=%s 高于合法上限 %s" % (field, val, hi))
        return None
    return val


def pct(x):
    return "%.2f%%" % x if x is not None else "NA"


def money(x):
    return "%.2f 万元" % x if x is not None else "NA"


def exit_code_from_findings():
    if any(f["level"] == "BLOCK" for f in FINDINGS):
        return 1
    if any(f["level"] == "ASK" for f in FINDINGS):
        return 2
    return 0


def untested(items):
    if not items:
        return
    out(["", "-" * 68,
         "【未测项 · 未提供的数据不按 0 计算】"])
    for it in items:
        out(["  · %s" % it])


# ---------------------------------------------------------------------------
# 计算一：风险敞口定价（这是本技能与所有「条款清单型」工具的分界线）
# ---------------------------------------------------------------------------
def calc_exposure(a):
    rule("① 风险敞口定价：这份合同最坏会亏多少")
    amount = num(a.get("amount"), "合同金额（万元）", 0.01, 10_000_000)
    loss = num(a.get("loss"), "最坏损失额（万元）", 0, 10_000_000)
    prob = num(a.get("prob"), "发生概率（%）", 0, 100)
    recovery = num(a.get("recovery"), "可追偿率（%）", 0, 100)
    margin = num(a.get("margin"), "毛利率（%）", -100, 100)
    cash = num(a.get("cash"), "现金储备（万元）", 0, 10_000_000)

    need = []
    if amount is None:
        need.append("--amount 合同金额")
    if loss is None:
        need.append("--loss 最坏损失额（把最坏情形写成钱：货款全损 / 违约金 / 返工 / 停产）")
    if prob is None:
        need.append("--prob 发生概率（没有数据也要给区间中值，并标注是估计）")
    if need:
        add("ASK", "E01", "缺少关键字段：%s" % "、".join(need))
        out(["缺少关键字段：%s" % "、".join(need)])
        out(["用法：--calc exposure --amount 500 --loss 200 --prob 20 --recovery 40 --margin 25 --cash 800"])
        return 2

    recovery = 0.0 if recovery is None else recovery
    net_loss = loss * (1 - recovery / 100.0)
    exp_loss = loss * (prob / 100.0) * (1 - recovery / 100.0)

    out(["%-30s %s" % ("合同金额", money(amount))])
    out(["%-30s %s" % ("最坏损失额（毛）", money(loss))])
    out(["%-30s %s" % ("可追偿率", pct(recovery))])
    out(["%-30s %s" % ("最坏净损失", money(net_loss))])
    out(["%-30s %s" % ("期望损失（概率加权）", money(exp_loss))])
    out(["%-30s %s" % ("最坏净损失 ÷ 合同金额", pct(net_loss / amount * 100))])

    level = None
    reasons = []
    if margin is not None:
        gp = amount * margin / 100.0
        cover = gp / net_loss if net_loss > 0 else float("inf")
        out(["%-30s %s" % ("这份合同的毛利", money(gp))])
        out(["%-30s %.2f 倍" % ("毛利 ÷ 最坏净损失", cover)])
        if net_loss > 0 and cover < DEFAULT_PARAMS["margin_cover_red"][0]:
            level = "红"
            reasons.append("最坏净损失超过本单全部毛利（覆盖 %.2f 倍 < 1）——一单出事，这单白做还要倒贴" % cover)
        elif net_loss > 0 and cover < DEFAULT_PARAMS["margin_cover_yellow"][0]:
            level = "黄"
            reasons.append("最坏净损失吃掉毛利的 %.0f%%（覆盖 %.2f 倍）——需要担保或责任上限对冲" % (100 / cover, cover))
        else:
            reasons.append("毛利能覆盖最坏净损失（覆盖 %.2f 倍），商业上扛得住" % cover if net_loss > 0 else "未测出净损失，暂无法判断覆盖倍数")

    if cash is not None and cash > 0:
        shock = net_loss / cash * 100
        out(["%-30s %s" % ("最坏净损失 ÷ 现金储备", pct(shock))])
        if shock >= DEFAULT_PARAMS["cash_shock_survival"][0]:
            level = "红"
            reasons.append("现金冲击 %.1f%% 达到生存级——赔完这一单，公司现金流会断" % shock)
        elif shock >= DEFAULT_PARAMS["cash_shock_high"][0]:
            level = "红" if level != "红" else "红"
            reasons.append("现金冲击 %.1f%% 属高危——需要分期赔付或担保安排" % shock)
        elif shock >= DEFAULT_PARAMS["cash_shock_low"][0]:
            if level is None:
                level = "黄"
            reasons.append("现金冲击 %.1f%% 可控，但要预留这笔钱" % shock)
        else:
            reasons.append("现金冲击 %.1f%% 低，不影响经营" % shock)

    out([""])
    if level is None:
        level = "绿"
        reasons.append("各项均在经验线以内")
    out(["%-30s %s" % ("风险等级", level)])
    for r in reasons:
        out(["  · %s" % r])

    out([""])
    if level == "红":
        out(["判定：**不建议按当前条款签**。三条处置路径，选一条：",
             "  1. 降敞口——把最坏损失压到毛利覆盖 1 倍以内（责任上限 / 分批交付 / 预付款提高）",
             "  2. 转移风险——要求担保、保险或母公司兜底",
             "  3. 换交易结构——改赊销为款到发货、改总包为分包"])
    elif level == "黄":
        out(["判定：**可签，但必须带对冲条件**。在对冲落地前不算审完。"])
    else:
        out(["判定：**风险可控，可进入条款审查**。"])

    out(["", "口径：毛利率、概率、可追偿率均须标注来源；概率无数据时给区间中值并注明是估计。"
              "阈值 %.1f / %.1f / %.1f%% / %.1f%% / %.1f%% 为经验线，机构可微调。"
          % (DEFAULT_PARAMS["margin_cover_red"][0], DEFAULT_PARAMS["margin_cover_yellow"][0],
             DEFAULT_PARAMS["cash_shock_survival"][0], DEFAULT_PARAMS["cash_shock_high"][0],
             DEFAULT_PARAMS["cash_shock_low"][0])])
    LOG.append({"calc": "exposure", "level": level, "net_loss": net_loss})
    return 0


# ---------------------------------------------------------------------------
# 计算二：现金流占用（合同签了，钱什么时候回来）
# ---------------------------------------------------------------------------
def calc_cashflow(a):
    rule("② 现金流占用：这份合同要我垫多少钱、垫多久")
    amount = num(a.get("amount"), "合同金额（万元）", 0.01, 10_000_000)
    cost_ratio = num(a.get("cost_ratio"), "成本占合同额（%）", 0, 100)
    prepay = num(a.get("prepay"), "预付款比例（%）", 0, 100)
    progress = num(a.get("progress"), "进度款比例（%）", 0, 100)
    accept = num(a.get("accept"), "验收款比例（%）", 0, 100)
    retention = num(a.get("retention"), "质保金比例（%）", 0, 100)
    ret_days = num(a.get("retention_days"), "质保金退还天数", 0, 3650)
    pay_days = num(a.get("payment_days"), "账期（天）", 0, 720)
    rate = num(a.get("funding_rate"), "资金成本率（%/年）", 0, 100)

    if amount is None or cost_ratio is None:
        add("ASK", "E01", "缺少关键字段：合同金额 / 成本占比")
        out(["缺少关键字段：--amount 与 --cost-ratio 至少要有。"])
        out(["用法：--calc cashflow --amount 500 --cost-ratio 70 --prepay 30 --progress 40 --accept 25 --retention 5 --retention-days 365 --payment-days 60"])
        return 2

    prepay = 0.0 if prepay is None else prepay
    progress = 0.0 if progress is None else progress
    accept = 0.0 if accept is None else accept
    retention = 0.0 if retention is None else retention
    ret_days = 0.0 if ret_days is None else ret_days
    pay_days = 0.0 if pay_days is None else pay_days
    rate = DEFAULT_PARAMS["funding_rate"][0] if rate is None else rate

    total_pct = prepay + progress + accept + retention
    if abs(total_pct - 100) > 0.5:
        add("ASK", "E06", "回款结构合计 %.1f%%，不等于 100%%——比例漏了或重了" % total_pct)
        out(["回款结构合计 %.1f%%，不等于 100%%：预付款 + 进度款 + 验收款 + 质保金必须等于 100%%" % total_pct])
        return 2

    cost = amount * cost_ratio / 100.0
    out(["%-34s %s" % ("合同金额", money(amount))])
    out(["%-34s %s" % ("我方成本投入", money(cost))])
    out(["%-34s %s / %s / %s / %s" % ("回款结构 预付/进度/验收/质保",
                                       pct(prepay), pct(progress), pct(accept), pct(retention))])

    # 粗略时点模型：预付款第 0 天到账，进度款在 pay_days，验收款在 pay_days×2，
    # 质保金在 ret_days。成本在履约期均匀投入（按 pay_days×2 摊）。
    t_prog = pay_days
    t_accept = pay_days * 2
    t_ret = max(ret_days, pay_days * 2)
    inflow = [
        (0.0, amount * prepay / 100.0, "预付款"),
        (t_prog, amount * progress / 100.0, "进度款"),
        (t_accept, amount * accept / 100.0, "验收款"),
        (t_ret, amount * retention / 100.0, "质保金"),
    ]
    out([""])
    for t, v, name in inflow:
        out(["  %-10s 第 %6.0f 天  %s" % (name, t, money(v))])

    # 垫资峰值：在第 T 天，累计成本投入 - 累计回款，取最大
    horizon = int(t_ret) + 1
    peak, peak_day = 0.0, 0
    span = max(t_accept, 1.0)
    for day in range(0, horizon + 1):
        cum_cost = cost * min(day / span, 1.0)
        cum_in = sum(v for t, v, _ in inflow if t <= day)
        gap = cum_cost - cum_in
        if gap > peak:
            peak, peak_day = gap, day

    out([""])
    out(["%-34s %s" % ("垫资峰值", money(peak))])
    out(["%-34s 第 %d 天" % ("峰值出现时点", peak_day)])
    out(["%-34s %.0f 天" % ("质保金最后到账", t_ret)])
    hold_cost = peak * rate / 100.0 * (peak_day / 365.0)
    out(["%-34s %s" % ("垫资资金成本（按峰值×占用天数）", money(hold_cost))])
    if amount > 0:
        out(["%-34s %s" % ("垫资峰值 ÷ 合同金额", pct(peak / amount * 100))])

    out([""])
    # 判据用「预付款能覆盖多少成本」而不是峰值——峰值受成本投入节奏假设影响太大，
    # 而「对方先给多少钱、我方才开工」是合同里写死的，不含假设。
    cover_cost = (amount * prepay / 100.0) / cost * 100 if cost > 0 else 0.0
    out(["%-34s %s" % ("预付款 ÷ 我方成本", pct(cover_cost))])
    if cover_cost < 30:
        out(["判定：**高垫资**。预付款只覆盖成本的 %.0f%%，其余靠我方垫——这单本质是拿我方现金流替对方融资。" % cover_cost])
        add("BLOCK", "E09", "高垫资结构：预付款仅覆盖成本 %.0f%%（经验线 30%%）" % cover_cost)
    elif peak > 0 and peak_day > 180:
        out(["判定：**长占用**。资金被占 %d 天，须计入报价或要求提高预付款。" % peak_day])
    else:
        out(["判定：**现金流结构可接受**。"])

    out(["", "口径：时点模型为简化模型（预付款第 0 天、进度款按账期、验收款按两倍账期、质保金按约定天数），"
              "实际以合同节点为准。资金成本率默认 %.1f%% 为经验值，须按企业真实融资成本替换。"
          % DEFAULT_PARAMS["funding_rate"][0]])
    LOG.append({"calc": "cashflow", "peak": peak, "peak_day": peak_day})
    return 0


# ---------------------------------------------------------------------------
# 计算三：审查深度匹配
# ---------------------------------------------------------------------------
def calc_depth(a):
    rule("③ 审查深度匹配：这份合同该审到几分")
    amt = a.get("amount_level")
    irr = a.get("irreversible")
    cp = a.get("counterparty")
    if amt is None or irr is None or cp is None:
        add("ASK", "E01", "缺少关键字段：金额档 / 不可逆度 / 对方资信")
        out(["缺少参数。",
             "用法：--calc depth --amount-level 4 --irreversible 3 --counterparty 2",
             "  --amount-level  合同金额相对公司年营收的档位 1-5（1 <1%% / 5 >50%%）",
             "  --irreversible  条款不可逆度 1-5（1 可随时终止 / 5 独家+排他+长期绑定）",
             "  --counterparty  对方资信 1-5（1 查无此人 / 5 央国企上市公司）"])
        return 2
    for n, v in (("金额档", amt), ("不可逆度", irr), ("对方资信", cp)):
        if not 1 <= int(v) <= 5:
            add("ASK", "E04", "%s 取值须为 1-5，得到 %s" % (n, v))
            out(["%s 取值须为 1-5，得到 %s（E04）" % (n, v)])
            return 2

    amt, irr, cp = int(amt), int(irr), int(cp)
    score = amt * 2 + irr * 2 + (6 - cp)
    out(["%-22s %d x2 = %d" % ("金额档", amt, amt * 2)])
    out(["%-22s %d x2 = %d" % ("不可逆度", irr, irr * 2)])
    out(["%-22s (6-%d) = %d" % ("对方资信倒数", cp, 6 - cp)])
    out(["%-22s %d / 25" % ("综合分量", score)])
    out([""])

    if score >= 20:
        tier = "尽调级"
        do = "七步全走 + 主体尽调（工商/涉诉/被执行/资质）+ 交易结构设计 + 红队复核 + 履约能力核查"
        skip = "不可省任何一步"
    elif score >= 14:
        tier = "深度审查"
        do = "七步全走 + 主体核查 + 逐条法条映射 + 红黄绿分级 + 谈判方案"
        skip = "可省对标分析，不可省主体核查"
    elif score >= 8:
        tier = "标准审查"
        do = "七步走 + 通用清单 + 重点条款深挖（责任/付款/争议解决）"
        skip = "可省逐条法条映射，改为关键条款映射"
    else:
        tier = "速审"
        do = "通用清单扫一遍 + 常识红线（定金/金额大小写/盖章/授权）+ 四格完整性"
        skip = "不做深度法条映射；但红线项一条不能省"

    out(["%-22s %s" % ("建议档位", tier)])
    out(["%-22s %s" % ("必做", do)])
    out(["%-22s %s" % ("可省", skip)])
    out(["", "口径：综合分量 = 金额档×2 + 不可逆度×2 +（6−对方资信），满分 25；"
              "分档 20/14/8 为经验区间。对方资信越差、分量越高——因为钱要不回来的风险比条款写得差更致命。"])
    return 0


# ---------------------------------------------------------------------------
# 计算四：救济可行性（打赢了能不能拿到钱）
# ---------------------------------------------------------------------------
def calc_remedy(a):
    rule("④ 救济可行性：赢了官司，钱拿得回来吗")
    claim = num(a.get("claim"), "索赔金额（万元）", 0.01, 10_000_000)
    ctype = a.get("counterparty_type")
    if claim is None or not ctype:
        add("ASK", "E01", "缺少关键字段：索赔金额 / 对方主体类型")
        out(["缺少参数。",
             "用法：--calc remedy --claim 200 --counterparty-type 中小民企 --guarantee yes --jurisdiction clear --evidence full",
             "  --counterparty-type  %s" % " / ".join(COUNTERPARTY_RECOVERY.keys()),
             "  --guarantee    yes / no        有无有效担保",
             "  --jurisdiction clear / vague   管辖约定是否明确",
             "  --evidence     full / partial / weak  证据充分度"])
        return 2
    if ctype not in COUNTERPARTY_RECOVERY:
        add("ASK", "E03", "对方主体类型「%s」不在合法范围；合法取值：%s"
            % (ctype, " / ".join(COUNTERPARTY_RECOVERY)))
        out(["对方主体类型「%s」不在合法范围（E03）；合法取值：%s"
             % (ctype, " / ".join(COUNTERPARTY_RECOVERY))])
        return 2

    lo, hi, why = COUNTERPARTY_RECOVERY[ctype]
    adj = []
    if a.get("guarantee") == "yes":
        lo, hi = lo + 20, hi + 20
        adj.append("有有效担保 +20")
    if a.get("jurisdiction") == "clear":
        lo, hi = lo + 5, hi + 5
        adj.append("管辖明确 +5")
    elif a.get("jurisdiction") == "vague":
        lo, hi = lo - 10, hi - 10
        adj.append("管辖不明 −10（可能被拖到对方主场）")
    ev = a.get("evidence")
    if ev == "full":
        lo, hi = lo + 10, hi + 10
        adj.append("证据充分 +10")
    elif ev == "weak":
        lo, hi = lo - 20, hi - 20
        adj.append("证据薄弱 −20（举证不能＝败诉）")
    lo, hi = max(0, min(90, lo)), max(0, min(95, hi))

    out(["%-24s %s" % ("索赔金额", money(claim))])
    out(["%-24s %s（基准 %d-%d%%）" % ("对方类型", ctype, COUNTERPARTY_RECOVERY[ctype][0], COUNTERPARTY_RECOVERY[ctype][1])])
    out(["%-24s %s" % ("类型特性", why)])
    for x in adj:
        out(["%-24s %s" % ("调整", x)])
    out([""])
    out(["%-24s %d%% — %d%%" % ("预计可回款比例", lo, hi)])
    out(["%-24s %s — %s" % ("预计可回款金额", money(claim * lo / 100.0), money(claim * hi / 100.0))])
    out(["%-24s %s" % ("预计不可回收", money(claim * (1 - hi / 100.0)))])

    if hi < 30:
        verdict = "**低效救济**：打赢也很难拿到钱。条款再好也只是纸面权利，应优先改交易结构（预付/担保/分批）而不是加违约金。"
    elif hi < 55:
        verdict = "**中等救济**：需要担保或财产保全配合，否则胜诉常成一纸空文。"
    else:
        verdict = "**救济可用**：判决可执行性尚可，但仍须在合同中锁定管辖与证据条款。"

    out([""])
    out(["判定：%s" % verdict])
    out(["", "口径：回款比例为经验区间，不是法律意见，也不构成胜诉预测。实际执行取决于财产状况、"
              "执行法院、担保物权顺位等因素。担保与证据调整叠加后封顶 90%（不承诺 100%）。"])
    return 0


# ---------------------------------------------------------------------------
# 计算五：风险分级汇总
# ---------------------------------------------------------------------------
def calc_grade(a):
    rule("⑤ 风险分级：这份合同能不能签")
    red = a.get("red")
    yellow = a.get("yellow")
    green = a.get("green")
    total = a.get("clauses")
    if red is None or yellow is None:
        add("ASK", "E01", "缺少关键字段：红线数 / 黄线条数")
        out(["缺少关键字段：红线数 / 黄线条数。用法：--calc grade --red 3 --yellow 7 --green 20 --clauses 30"])
        return 2
    red, yellow = int(red), int(yellow)
    green = 0 if green is None else int(green)
    out(["%-16s %d 条" % ("红线（不改不签）", red)])
    out(["%-16s %d 条" % ("黄线（尽量改）", yellow)])
    out(["%-16s %d 条" % ("绿线（知悉即可）", green)])

    total = 0 if total is None else int(total)
    if total > 0:
        density = red / total * 100
        out(["%-16s %s" % ("红线密度", pct(density))])
        if density >= DEFAULT_PARAMS["risk_density_red"][0]:
            out(["  · 红线密度超过经验线 %.1f%%——这不是「改几条」的问题，是合同整体结构有问题"
                 % DEFAULT_PARAMS["risk_density_red"][0]])

    out([""])
    if red > 0:
        verdict = "**不能按现文本签**"
        cond = "红线 %d 条改到位后重审；未改到位不得签署" % red
        code = 1
    elif yellow >= 5:
        verdict = "**有条件签署**"
        cond = "黄线 %d 条中，涉及付款安全与责任上限的必须先改；其余可留待履约管控" % yellow
        code = 0
    elif yellow > 0:
        verdict = "**可签署（附提示）**"
        cond = "黄线 %d 条书面告知业务部门，由业务决策是否接受" % yellow
        code = 0
    else:
        verdict = "**可签署**"
        cond = "无红线无黄线，按标准流程签署"
        code = 0

    out(["%-16s %s" % ("整体结论", verdict)])
    out(["%-16s %s" % ("前置条件", cond)])
    out(["", "口径：红黄绿三色由审查人按五把尺判定；本题只做汇总与结论，不替代逐条判定。"])
    if code == 1:
        add("BLOCK", "E09", "存在 %d 条红线，判定不能按现文本签署" % red)
    return code


# ---------------------------------------------------------------------------
# 合同文本体检（规则扫描）
# ---------------------------------------------------------------------------
SCAN_RULES = [
    ("S01", "订金代替定金", re.compile(r"订\s*金"), "BLOCK",
     "「订金」不适用定金罚则，违约时无法主张双倍返还；若要担保履约须写「定金」"),
    ("S02", "管辖与仲裁并存", None, "BLOCK",
     "既约定法院管辖又约定仲裁，条款可能因约定不明而无效，须二选一"),
    ("S03", "自动续约无退出", re.compile(r"自动续[约签]|期满自动延"), "ASK",
     "自动续约须同时约定「任一方可提前 X 日书面不续约」，否则形成无限期锁定"),
    ("S04", "单方解除权不对等", re.compile(r"甲方有权(单方)?解除|乙方无权解除"), "ASK",
     "单方解除权须对等，或对等给予补偿；不对等条款在争议中易被认定显失公平"),
    ("S05", "责任上限缺失", re.compile(r"赔偿(责任)?(总额|累计)?不超过"), "INFO",
     "若全文无责任上限条款，违约赔偿可能无限扩张；建议约定不超过合同总额或已付金额的倍数"),
    ("S06", "违约金畸高", None, "ASK",
     "违约金约定过高（通常超过实际损失 30%）可能被法院调低，反而丧失约束力"),
    ("S07", "空白待填未清", re.compile(r"[＿_]{2,}|＿\s|×{2,}|[xX]{3,}|待填|待定"), "BLOCK",
     "存在空白待填项，签署前必须填实或划线删除，空白条款易被单方填充"),
    ("S08", "争议解决缺失", None, "BLOCK",
     "缺少争议解决条款（管辖法院或仲裁机构），争议时管辖不明，维权成本大增"),
    ("S09", "签署栏缺失", None, "BLOCK",
     "缺少双方签署栏（名称、盖章位、日期），形式要件不全"),
    ("S10", "发票义务缺失", None, "ASK",
     "未约定发票类型与开票时间，进项抵扣与付款条件易生争议"),
    ("S11", "验收标准缺失", None, "ASK",
     "未约定验收标准与异议期，质量争议时举证困难"),
    ("S12", "知识产权归属缺失", None, "ASK",
     "成果知识产权归属未约定，委托开发默认归完成方，可能丧失核心资产"),
    ("S13", "保密条款缺失", None, "INFO",
     "无保密条款，商业秘密泄露后难以追责"),
    ("S14", "数据合规缺失", re.compile(r"个人信息|数据出境|数据处理"), "ASK",
     "涉及个人信息或数据处理的，须补合规条款（处理目的、范围、期限、跨境安排）"),
    ("S15", "担保决议未核", re.compile(r"保证|担保|连带"), "ASK",
     "存在担保安排时，须核验担保方有权机关决议，否则担保可能对其不发生效力"),
]


def _read_text(path, code="E11"):
    """统一读文件入口。所有命令都走这里，不各自写一份 try/except。"""
    try:
        text, _enc, _warn = safe_io.read_text(path)
        return text, None
    except safe_io.ReadError as exc:
        return None, "%s（%s）" % (exc, code)


def parse_patch_args(items):
    """--patch "旧=>新" 转成 patch 字典。用 => 分隔，不切割「旧文本里的逗号」。"""
    out = []
    for raw in items or []:
        if "=>" not in raw:
            raise ValueError("--patch 格式应为「原文=>新文」，缺少 =>：%s" % raw[:40])
        old, new = raw.split("=>", 1)
        out.append({"old": old.strip(), "new": new.strip()})
    return out


def cmd_diff(a):
    import revision_diff as rd
    old_p, new_p = a.get("diff")
    rule("两版对比")
    try:
        r = rd.compare(old_p, new_p)
    except safe_io.ReadError as exc:
        out(["读取失败：%s（%s）" % (exc, exc.code)])
        add("ASK", exc.code, exc.message)
        return 2
    except ValueError as exc:
        out(["无法对比：%s（E12）" % exc])
        add("ASK", "E12", str(exc))
        return 2

    c = r["counts"]
    out(["旧：%s" % os.path.basename(old_p)])
    out(["新：%s" % os.path.basename(new_p)])
    out(["段落 %d → %d ｜ 变更 %d 处（新增 %d / 删除 %d / 修改 %d）"
         % (c["old_paras"], c["new_paras"], c["changes"], c["insert"], c["delete"], c["modify"])])
    out([""])

    subs = r["substantive_changes"]
    if subs:
        out(["-" * 68])
        out(["实质变更 %d 处（命中交易条件，不是改错别字）" % len(subs)])
        out(["-" * 68])
        for i, ch in enumerate(subs, 1):
            dims = "、".join(n for n, _ in ch["dims"]) or "（未命中维度）"
            num = ""
            if ch["nums_changed"]:
                num = " ｜ 数字变化：%s" % "、".join(ch["nums_changed"][:6])
            out([""])
            out(["%d. [%s] %s%s" % (i, ch["kind"], dims, num)])
            if ch["old"]:
                out(["   旧：%s" % ch["old"][:110]])
            if ch["new"]:
                out(["   新：%s" % ch["new"][:110]])
            if ch["right_delta"] or ch["duty_delta"]:
                out(["   权义表述变化：权利 %+d ／ 义务 %+d"
                     % (ch["right_delta"], ch["duty_delta"])])
        out([""])

    others = [x for x in r["changes"] if x not in subs]
    if others:
        out(["-" * 68])
        out(["非实质变更 %d 处（措辞 / 格式 / 表述顺序，逐条过一眼即可）" % len(others)])
        for ch in others[:12]:
            out(["  [%s] %s" % (ch["kind"], (ch["old"] or ch["new"])[:80])])
        if len(others) > 12:
            out(["  ……另有 %d 处" % (len(others) - 12)])
        out([""])

    if r["dimensions"]:
        out(["维度分布：" + "、".join(
            "%s %d 处" % (k, v["count"]) for k, v in
            sorted(r["dimensions"].items(), key=lambda kv: -kv[1]["count"]))])
    out(["风险增量：%d（0＝措辞级；1—3＝需复核；≥4＝需重谈）" % r["risk_delta"]])
    out([""])
    if r["risk_delta"] >= 4:
        out(["结论：这一版改的是交易条件，不是文字。**按原价接受等于按新条件签约**，须逐条重谈或书面确认。"])
        add("BLOCK", "E20", "对方修订版含 %d 处交易条件实质变更（风险增量 %d）"
            % (len(subs), r["risk_delta"]))
    elif r["risk_delta"] >= 1:
        out(["结论：有 %d 处触及交易条件，逐条确认后再签。" % len(subs)])
        add("ASK", "E20", "对方修订版含 %d 处实质变更" % len(subs))
    else:
        out(["结论：未命中交易维度，属措辞级修订（仍建议抽三条原文核对，规则只扫关键字）。"])
    out(["", "口径：维度判定按关键词命中，存在漏判（同义改写绕开关键词）。"
              "同类条款换了说法，本工具可能判为「非实质」——"
              "它给的是待核清单，不是免检结论。"])
    return exit_code_from_findings()


def cmd_redline(a):
    import ooxml_redline as ox
    src = a.get("redline")
    dst = a.get("out")
    if not src:
        out(["缺少输入文件：--redline <合同文件>（E01）"])
        add("ASK", "E01", "缺少 --redline 输入文件")
        return 2
    if not dst:
        # 默认输出：同目录同名 + 带修订
        base, ext = os.path.splitext(src)
        dst = base + "-修订" + (ext or ".docx")
        out(["未指定 --out，输出到：%s" % dst])

    patches = []
    try:
        patches += parse_patch_args(a.get("patch"))
    except ValueError as exc:
        out(["补丁格式错误：%s（E12）" % exc])
        add("ASK", "E12", str(exc))
        return 2
    if a.get("patch_file"):
        txt, err = _read_text(a["patch_file"])
        if err:
            out([err])
            add("ASK", "E11", err)
            return 2
        try:
            loaded = json.loads(txt)
        except ValueError as exc:
            out(["补丁文件不是合法 JSON：%s（E12）" % exc])
            add("ASK", "E12", "JSON 解析失败")
            return 2
        if not isinstance(loaded, list):
            out(["补丁文件必须是数组，每项含 old / new（E12）"])
            add("ASK", "E12", "补丁文件顶层不是数组")
            return 2
        patches += [p for p in loaded if isinstance(p, dict)]

    # 空串在三处是致命的：old 为空会匹配任意位置（"" in 任何文本都为真），
    # 于是「改了个空」被判成功，产生一条假修订。必须在这里拦掉。
    patches = [p for p in patches
               if (p.get("old") or "").strip() or (p.get("new") or "").strip()]
    if dst and not dst.lower().endswith(".docx"):
        out(["注意：输出文件不是 .docx 扩展名（%s）。"
             "本命令生成的是 OOXML 格式，扩展名写成 .doc 会导致 Word 打不开。" % dst])
    rule("生成修订稿")
    if not patches:
        out(["没有可执行的修订：请用 --patch \"原文=>新文\" 或 --patch-file 指定。"])
        out(["注意：本命令不会「自动猜」该怎么改。改什么由审查结论决定，不交给关键词匹配。"])
        add("ASK", "E01", "未提供任何修订条目")
        return 2

    try:
        r = ox.redline(src, dst, patches, author=a.get("author") or "合同审查官")
    except ValueError as exc:
        out(["无法生成修订稿：%s（E11）" % exc])
        add("ASK", "E11", str(exc))
        return 2
    except OSError as exc:
        out(["写入失败：%s（E13）" % exc])
        add("ASK", "E13", str(exc))
        return 2

    out(["已生成：%s" % r["out"]])
    out(["作者：%s ｜ 时间：%s ｜ 段落：%d"
         % (r["author"], r["date"], r["counts"]["paragraphs"])])
    out(["修订 %d 处（Word 打开「审阅→修订」可见，可逐条接受或拒绝）"
         % r["counts"]["applied"]])
    out([""])
    for i, ap in enumerate(r["applied"], 1):
        label = {"inline": "句内替换", "paragraph": "整段替换",
                 "insert": "新增段落", "delete": "删除段落",
                 "replace": "整段替换"}.get(ap["kind"], ap["kind"])
        out(["%d. [%s] %s" % (i, label, (ap["new"] or ap["old"])[:70])])
        if ap.get("reason"):
            out(["   理由：%s" % ap["reason"]])
    if r["missed"]:
        out([""])
        out(["未命中 %d 条（原文里找不到，**未改动**）：" % len(r["missed"])])
        for m in r["missed"]:
            out(["  · [%s] %s" % (m["kind"], (m["old"] or m["new"])[:70])])
        add("ASK", "E21", "%d 条修订在原文中未命中，未生效" % len(r["missed"]))
    out(["", "口径：修订痕迹为 OOXML 原生 w:ins / w:del，非颜色标注。"
              "文档已开启修订模式，其后任何人的改动同样会被记录。"
              "生成稿不改变原合同效力，签署前仍须法务复核。"])
    return exit_code_from_findings()


def cmd_template(a):
    import clause_library as lib
    ctype = a.get("template")
    rule("条款模板：%s" % ctype)
    rows = lib.get_template(ctype)
    if rows is None:
        out(["该类型暂无专属条款模板。通用四格底线："
             "钱（金额/付款方式/付款时间/发票）、"
             "货（标的/数量/质量/交付/验收）、"
             "时间（期限/节点/生效/解除）、"
             "责任（违约/赔偿/担保/免责/争议）——每格缺一项，就有一处将来会吵。"]
            )
        add("ASK", "E22", "合同类型「%s」暂无专属模板" % ctype)
        return exit_code_from_findings()
    out(["共 %d 条必守条款。文本为**谈判起手式**，不是标准答案——"
         "交易地位不同，同一句话的攻守方向相反。" % len(rows)])
    for i, (grid, name, text, risk) in enumerate(rows, 1):
        out([""])
        out(["%d. [%s] %s" % (i, grid, name)])
        out(["   起手：%s" % text])
        out(["   不写会怎样：%s" % risk])
    out(["", "用法：先用 --interview 问清交易背景，再按本清单裁剪。"
              "条款文本须按项目实际填【 】占位，不得原样照抄。"])
    return 0


def cmd_interview(a):
    import clause_library as lib
    ctype = a.get("interview")
    rule("审查访谈清单：%s" % ctype)
    rows = lib.get_interview(ctype)
    out(["共 %d 问，按四组推进。**先问背景，再问条款**——"
         "背景不清，条款审得再细也是审别人的交易。" % len(rows)])
    cur = None
    for i, (group, q, dodge, probe) in enumerate(rows, 1):
        if group != cur:
            cur = group
            out([""])
            out(["【%s】" % group])
        out(["%d. %s" % (i, q)])
        out(["   他大概会说：%s" % dodge])
        out(["   追问：%s" % probe])
    out(["", "用法：把答案记进审查底稿，答不上来的就是这次审查最该先查的地方。"])
    return 0


def _locate(text, snippet):
    """把命中片段定位到原文行号与整行。

    「第 5 条有风险」是废话，「第 7 行：合同金额：＿＿ 万元」才是审查。
    定位越具体，客户越没办法跳过。
    """
    if not snippet:
        return "（全文性问题，无具体位置）"
    idx = text.find(snippet)
    if idx < 0:
        return snippet
    line_no = text[:idx].count("\n") + 1
    start = text.rfind("\n", 0, idx) + 1
    end = text.find("\n", idx)
    if end < 0:
        end = len(text)
    return "第 %d 行 「%s」" % (line_no, text[start:end].strip()[:100])


def _grid_report(text):
    """四格覆盖度。

    第一项是「任一命中即算该格出现过」的宽匹配，后面是这张格子里的具体要件。
    分两层是因为：宽匹配判「有没有」，要件判「全不全」——混在一起会把
    「写了付款但没写发票」报成「钱完全缺失」。
    """
    rows, holes = [], []
    for grid, spec in FOUR_GRID.items():
        broad, *items = spec
        present = bool(re.search(broad, text))
        # 具体要件按同义词组判：任一同义词出现即视为该要件覆盖
        SYN = {
            "金额": ("金额", "价款", "总价", "服务费", "报酬", "租金"),
            "付款方式": ("付款方式", "支付方式", "转账", "汇款", "现金", "支票"),
            "付款时间": ("付款时间", "日内支付", "支付后", "到货后", "验收后", "月结"),
            "发票与税": ("发票", "开票", "增值税", "含税", "税率"),
            "标的内容": ("标的", "货物", "服务内容", "型号", "规格", "范围"),
            "数量规格": ("数量", "台", "套", "件", "吨", "人天"),
            "质量标准": ("质量", "标准", "技术协议", "国标", "合格"),
            "交付与验收": ("交付", "交货", "验收", "签收", "送达"),
            "合同期限": ("期限", "有效期", "自.{0,6}起至", "日历天", "个月", "年"),
            "关键节点": ("节点", "前完成", "之前", "进度", "里程碑"),
            "生效条件": ("生效", "签订之日", "签署之日", "盖章"),
            "解除与续期": ("解除", "终止", "续约", "续期"),
            "违约责任": ("违约", "赔偿", "滞纳", "罚款"),
            "赔偿范围": ("赔偿范围", "损失", "直接损失", "间接损失"),
            "担保安排": ("担保", "保证", "抵押", "质押", "保函"),
            "争议解决": ("管辖", "仲裁", "人民法院", "诉讼"),
        }
        hit_items = [k for k in items if any(w in text for w in SYN.get(k, (k,)))]
        miss = [k for k in items if k not in hit_items]
        rows.append((grid, len(hit_items), len(items), miss))
        if not present:
            holes.append(grid)
    return rows, holes


def _wrap(text, width=58, indent="      "):
    """长句折行。不折的话终端里一句话横穿整屏，读起来比不写还累。"""
    out_lines, cur = [], ""
    for ch in text:
        cur += ch
        if len(cur) >= width and ch in "，。；：、）":
            out_lines.append(indent + cur)
            cur = ""
    if cur:
        out_lines.append(indent + cur)
    return out_lines


def do_check(a):
    path = a.get("check")
    try:
        text, enc, warn = safe_io.read_text(path)
    except safe_io.ReadError as exc:
        add("ASK", exc.code, exc.message)
        print("读取失败：%s（%s）" % (exc, exc.code))
        return 2

    if not text.strip():
        add("ASK", "E11", "文件里没有文字内容：%s" % path)
        print("文件里没有文字内容（只有空白）：%s（E11）" % path)
        return 2
    if warn:
        print("[提示] %s" % warn)

    import scan_rules as sr

    ctype = (a.get("type") or "").strip()
    rules = sr.applicable(ctype) if ctype else sr.RULES
    skipped = sr.skipped_for(ctype) if ctype else []

    hits = []
    for r in rules:
        try:
            m = r["hit"](text)
        except Exception:  # noqa: BLE001 — 单条规则炸了不能拖垮整次体检
            m = None
        if m:
            hits.append((r, m))

    order = {"BLOCK": 0, "ASK": 1, "INFO": 2}
    hits.sort(key=lambda x: order.get(x[0]["level"], 3))
    red = sum(1 for r, _ in hits if r["level"] == "BLOCK")
    yellow = sum(1 for r, _ in hits if r["level"] == "ASK")
    info = sum(1 for r, _ in hits if r["level"] == "INFO")
    rows, holes = _grid_report(text)
    brief = bool(a.get("brief"))

    L = []
    L.append("")
    L.append("=" * 68)
    L.append("合同文本体检")
    L.append("=" * 68)
    L.append("文件：%s ｜ 共 %d 行 ｜ 命中 %d 处"
             % (os.path.basename(path), text.count("\n") + 1, len(hits)))
    if ctype:
        L.append("合同类型：%s ｜ 适用规则 %d 条、跳过 %d 条不适用规则"
                 % (ctype, len(rules), len(skipped)))
    else:
        L.append("合同类型：未指定（按通用规则全跑，可能含个别不适用的检查；"
                 "加 --type 可按类型过滤）")
    L.append("")

    if brief:
        for r, m in hits:
            tag = {"BLOCK": "红线", "ASK": "黄线", "INFO": "提示"}[r["level"]]
            L.append("[%s] %s %s — %s" % (tag, r["code"], r["name"], _locate(text, m)))
        if not hits:
            L.append("规则层未命中任何已知模式。")
        L.append("")
        L.append("清单模式：只给位置，不给改法。要看「为什么是坑、怎么改」，去掉 --brief。")
        _emit_check(L, path, a, red)
        return 1 if red else 0

    # ---------- 一、结论先行 ----------
    L.append("【一、结论先行】")
    L.append("  命中 %d 处：红线 %d ｜ 黄线 %d ｜ 提示 %d" % (len(hits), red, yellow, info))
    L.append("  四格：" + " ｜ ".join("%s %d/%d" % (g, h, n) for g, h, n, _ in rows))
    if red:
        L.append("  判定：**不能按现文本签署**——%d 处红线未处理。" % red)
    elif yellow:
        L.append("  判定：可签，但 %d 处黄线须逐条处理或书面知会业务。" % yellow)
    elif hits:
        L.append("  判定：规则层无硬伤，%d 处提示建议顺手改掉。" % info)
    else:
        L.append("  判定：规则层未发现问题。**这不等于合同没问题**——"
                 "规则只扫已知模式，结构性风险须人工过七步法。")
    L.append("")

    # ---------- 二、逐条拆解 ----------
    if hits:
        L.append("【二、逐条拆解】（红线优先，同级别按规则顺序）")
        L.append("")
        for i, (r, m) in enumerate(hits, 1):
            tag = {"BLOCK": "红线", "ASK": "黄线", "INFO": "提示"}[r["level"]]
            mark = "需律师复核" if r.get("review") == "法律" else "规则判定"
            head = "  ── %d ｜ %s ｜ %s %s 〔%s〕" % (i, tag, r["code"], r["name"], mark)
            L.append(head + "─" * max(2, 62 - len(head)))
            L.append("  坑在哪：%s" % _locate(text, m))
            ws0 = _wrap(r["why"], indent="          ")
            L.append("  为什么：" + ws0[0].strip())
            for extra in ws0[1:]:
                L.append(extra)
            ws = _wrap(r["plain"], indent="          ")
            L.append("  会怎么爆：" + ws[0].strip())
            for extra in ws[1:]:
                L.append(extra)
            fs = _wrap(r["fix"].split("\n")[0], indent="          ")
            L.append("  怎么改：" + fs[0].strip())
            for extra in fs[1:]:
                L.append(extra)
            L.append("  改后示范：")
            for seg in r["fix"].split("\n")[1:] or [r["fix"]]:
                L.append("      " + seg.strip())
            L.append("")
    else:
        L.append("【二、逐条拆解】")
        L.append("  规则层没有命中。这不代表没坑——规则只能认出「见过的写法」。")
        L.append("  换一种说法绕开关键词，它就不认识了。结构性问题必须人工过七步法。")
        L.append("")

    # ---------- 三、四格完整性 ----------
    L.append("【三、四格完整性】（钱 / 货 / 时间 / 责任）")
    for g, h, n, miss in rows:
        L.append("  %s ｜ %d/%d ｜ 缺：%s" % (g, h, n, "、".join(miss) or "（无）"))
    if holes:
        L.append("  ⚠ 完全缺失的格：%s —— 这一格里的坑无法通过改条款补救，是结构缺项。"
                 % "、".join(holes))
    L.append("")

    if skipped:
        L.append("【附：本次按类型跳过的规则】")
        L.append("  " + "、".join("%s %s" % (r["code"], r["name"]) for r in skipped))
        L.append("  跳过不等于没问题，是「这条检查不适用于该类合同」——"
                 "劳动合同没有发票、代持没有交付物验收。"
                 "若你认为该合同实际具有商事属性，去掉 --type 重跑一遍。")
        L.append("")

    # ---------- 四、口径 ----------
    L.append("【四、口径】")
    L.append("  本检查为规则级扫描，覆盖 %d 类高频模式，不构成法律意见。" % len(rules))
    L.append("  未命中不等于安全：规则认的是「写法」，同义改写可以绕开。")
    L.append("  命中项也须结合交易背景判断——同一句话在不同交易地位下，攻守方向相反。")
    L.append("  标〔需律师复核〕的条目涉及效力、性质或法律适用判断，"
             "本工具只给依据与方向，结论须由执业律师结合个案确认。")

    _emit_check(L, path, a, red)
    return 1 if red else 0


def _emit_check(L, path, a, red):
    """统一出口：有 --out 就落盘，否则打印。"""
    body = "\n".join(L)
    out_path = a.get("out")
    if out_path:
        try:
            with open(out_path, "w", encoding="utf-8") as fh:
                fh.write(body + "\n")
            print(body)
            print("")
            print("报告已写入：%s" % out_path)
        except OSError as exc:
            print(body)
            print("")
            print("[需补] E13 报告写入失败：%s" % exc)
            add("ASK", "E13", "报告写入失败：%s" % exc)
    else:
        print(body)


# ---------------------------------------------------------------------------
# 自检
# ---------------------------------------------------------------------------
LOG = []


def run_self_test():
    import subprocess
    me = os.path.abspath(__file__)
    cases = [
        # (名称, argv, 期望退出码, 期望输出包含)
        ("敞口 完整", ["--calc", "exposure", "--amount", "500", "--loss", "200",
                      "--prob", "20", "--recovery", "40", "--margin", "25", "--cash", "800"], 0, "风险等级"),
        ("敞口 缺参数", ["--calc", "exposure", "--amount", "500"], 2, "缺少关键字段"),
        ("敞口 nan 必须拒", ["--calc", "exposure", "--amount", "nan", "--loss", "1", "--prob", "1"], 2, "E05"),
        ("敞口 inf 必须拒", ["--calc", "exposure", "--amount", "inf", "--loss", "1", "--prob", "1"], 2, "E05"),
        ("敞口 高损失判红", ["--calc", "exposure", "--amount", "500", "--loss", "400",
                          "--prob", "50", "--recovery", "0", "--margin", "20", "--cash", "300"], 0, "红"),
        ("现金流 完整", ["--calc", "cashflow", "--amount", "500", "--cost-ratio", "70",
                       "--prepay", "30", "--progress", "40", "--accept", "25",
                       "--retention", "5", "--retention-days", "365", "--payment-days", "60"], 0, "垫资峰值"),
        ("现金流 比例不等于100", ["--calc", "cashflow", "--amount", "500", "--cost-ratio", "70",
                              "--prepay", "30", "--progress", "40", "--accept", "20", "--retention", "5"], 2, "不等于 100"),
        ("现金流 高垫资判阻断", ["--calc", "cashflow", "--amount", "500", "--cost-ratio", "80",
                          "--prepay", "0", "--progress", "50", "--accept", "45", "--retention", "5",
                          "--payment-days", "90"], 1, "高垫资"),
        ("深度 高档", ["--calc", "depth", "--amount-level", "5", "--irreversible", "5", "--counterparty", "1"], 0, "尽调级"),
        ("深度 低档", ["--calc", "depth", "--amount-level", "1", "--irreversible", "1", "--counterparty", "5"], 0, "速审"),
        ("深度 越界", ["--calc", "depth", "--amount-level", "6", "--irreversible", "1", "--counterparty", "5"], 2, "E04"),
        ("救济 中小民企", ["--calc", "remedy", "--claim", "200", "--counterparty-type", "中小民企"], 0, "可回款"),
        ("救济 担保加持", ["--calc", "remedy", "--claim", "200", "--counterparty-type", "中小民企",
                        "--guarantee", "yes", "--evidence", "full", "--jurisdiction", "clear"], 0, "调整"),
        ("救济 主体越界", ["--calc", "remedy", "--claim", "200", "--counterparty-type", "外星人"], 2, "E03"),
        ("分级 有红线不能签", ["--calc", "grade", "--red", "2", "--yellow", "3"], 1, "不能按现文本签"),
        ("分级 无红线可签", ["--calc", "grade", "--red", "0", "--yellow", "1"], 0, "可签署"),
        ("分级 缺参数", ["--calc", "grade"], 2, "缺少关键字段"),
        ("体检 空白未填判红", ["--check", "/tmp/cg_blank.md"], 1, "空白"),
        ("体检 干净文本无红线", ["--check", "/tmp/cg_ok.md"], 0, "红线 0"),
        ("体检 清单模式只出位置", ["--check", "/tmp/cg_ok.md", "--brief"], 0, "清单模式"),
        ("体检 报告可落盘", ["--check", "/tmp/cg_ok.md", "--out", "/tmp/cg_report.md"],
         0, "报告已写入"),
        ("体检 文件不存在", ["--check", "/tmp/cg_none_xyz.md"], 2, "E11"),
        ("schema 契约", ["--schema"], 0, "error_codes"),
        ("self-test 自身", ["--version"], 0, VERSION),
        # ---- 两版对比 ----
        ("对比 实质变更须阻断", ["--diff", "/tmp/cg_v1.md", "/tmp/cg_v2.md"], 1, "实质变更"),
        ("对比 同一版无实质", ["--diff", "/tmp/cg_v1.md", "/tmp/cg_v1.md"], 0, "未命中交易维度"),
        ("对比 文件不存在", ["--diff", "/tmp/cg_none_a.md", "/tmp/cg_none_b.md"], 2, "E11"),
        # ---- 条款模板 ----
        ("模板 服务", ["--template", "服务"], 0, "必守条款"),
        ("模板 无专属类型给通用四格", ["--template", "其他"], 2, "E22"),
        # ---- 访谈清单 ----
        ("访谈 租赁", ["--interview", "租赁"], 0, "追问"),
        # ---- 修订稿 ----
        ("修订 句内替换", ["--redline", "/tmp/cg_src.md", "--out", "/tmp/cg_rl1.docx",
                          "--patch", "90 日=>30 日"], 0, "已生成"),
        ("修订 无补丁须拒", ["--redline", "/tmp/cg_src.md", "--out", "/tmp/cg_rl2.docx"], 2, "E01"),
        ("修订 补丁格式错", ["--redline", "/tmp/cg_src.md", "--patch", "没有箭头"], 2, "E12"),
        ("修订 原文未命中须报", ["--redline", "/tmp/cg_src.md", "--out", "/tmp/cg_rl3.docx",
                              "--patch", "这句话原文里没有=>改"], 2, "E21"),
        ("修订 补丁文件非法JSON", ["--redline", "/tmp/cg_src.md", "--patch-file",
                              "/tmp/cg_bad.json"], 2, "E12"),
    ]
    # 造两份测试文本
    open("/tmp/cg_blank.md", "w", encoding="utf-8").write(
        "甲方：某公司\n乙方：某公司\n合同金额：＿ 万元\n以实物为准。\n")
    open("/tmp/cg_ok.md", "w", encoding="utf-8").write(
        "第一条 标的与数量：型号 A，数量 100 台。\n"
        "第二条 金额与付款：总价 50 万元，含税，签约后 30 日内付款，开具增值税专用发票。\n"
        "第三条 交付与验收：交付至甲方仓库，验收期 7 日，质量异议期 30 日。\n"
        "第四条 违约责任：逾期付款按日万分之五计息，累计不超过合同总价的 10%；\n"
        "赔偿以直接损失为限，不超过合同总价的 100%。\n"
        "第五条 争议解决：提交甲方所在地人民法院管辖。\n"
        "第六条 签署：甲方盖章、乙方盖章，签署日期。\n")

    # 对比与修订用的固定样本：两版差异是有意设计的，覆盖四类实质变更
    open("/tmp/cg_v1.md", "w", encoding="utf-8").write(
        "第一条 合同总价为人民币壹拾万元整（含税）。\n"
        "第二条 甲方应在验收合格后 90 日内支付全部款项。\n"
        "第三条 乙方逾期交货的，按日万分之三支付违约金，累计不超过合同总价的 5%。\n"
        "第四条 因本合同发生争议，由甲方所在地人民法院管辖。\n")
    open("/tmp/cg_v2.md", "w", encoding="utf-8").write(
        "第一条 合同总价为人民币壹拾万元整（含税）。\n"
        "第二条 甲方应在验收合格后 30 日内支付全部款项。\n"
        "第三条 乙方逾期交货的，按日万分之三支付违约金，累计不超过合同总价的 2%。\n"
        "第四条 因本合同发生争议，提交北京仲裁委员会仲裁。\n")
    open("/tmp/cg_src.md", "w", encoding="utf-8").write(
        "第一条 合同金额为人民币壹拾万元整。\n"
        "第二条 甲方应在验收合格后 90 日内支付全部款项。\n")
    open("/tmp/cg_bad.json", "w", encoding="utf-8").write("{不是合法 JSON，}")

    passed = failed = 0
    for name, args, want_rc, must in cases:
        try:
            p = subprocess.run([sys.executable, me] + args, capture_output=True,
                               text=True, timeout=30)
        except subprocess.SubprocessError as e:
            failed += 1
            print("[FAIL] %s → 子进程失败 %s" % (name, e))
            continue
        o = (p.stdout or "") + (p.stderr or "")
        ok = (p.returncode == want_rc) and (must in o)
        if ok:
            passed += 1
        else:
            failed += 1
            print("[FAIL] %s → 期望 rc=%d 含 %r，实际 rc=%d" % (name, want_rc, must, p.returncode))
    # ---- 进程内结构断言 ----
    # 子进程只能看输出字符串，验不了「产物本身对不对」。
    # 修订稿这种交付物，必须直接拆开看结构：表格在不在、修订 id 重不重、XML 良不良构。
    import zipfile as _zip
    from xml.etree import ElementTree as _ET
    sys.path.insert(0, os.path.dirname(me))
    import ooxml_redline as _ox

    def _mk_docx(path, body):
        doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
               '<w:document xmlns:w="%s"><w:body>%s</w:body></w:document>'
               % (_ox.NS_W, body))
        with _zip.ZipFile(path, "w") as z:
            z.writestr("[Content_Types].xml", _ox.CONTENT_TYPES)
            z.writestr("_rels/.rels", _ox.ROOT_RELS)
            z.writestr("word/document.xml", doc)
            z.writestr("word/_rels/document.xml.rels", _ox.DOC_RELS)
            z.writestr("word/settings.xml", _ox.SETTINGS)

    _mk_docx("/tmp/cg_tbl.docx",
             '<w:p><w:pPr><w:jc w:val="center"/></w:pPr>'
             '<w:r><w:rPr><w:sz w:val="32"/></w:rPr><w:t>设备采购合同</w:t></w:r></w:p>'
             '<w:p><w:r><w:t>第二条 验收后 90 日内付款。</w:t></w:r></w:p>'
             '<w:tbl><w:tr><w:tc><w:p><w:r><w:t>金额 100 万</w:t></w:r></w:p></w:tc></w:tr></w:tbl>'
             '<w:p><w:r><w:t>第四条 由甲方所在地法院管辖。</w:t></w:r></w:p>'
             '<w:p><w:r><w:t>第五条 保密期限为三年。</w:t></w:r></w:p>')

    _rl = _ox.redline("/tmp/cg_tbl.docx", "/tmp/cg_tbl_out.docx", [
        {"old": "90 日内", "new": "30 日内"},                       # inline
        {"old": "由甲方所在地法院管辖", "new": "由乙方所在地法院管辖",
         "scope": "paragraph"},                                     # 整段替换
        {"old": "第五条 保密期限为三年。", "new": ""},               # 整段删除
        {"new": "第六条 新增对等违约责任。", "anchor": "第二条"},     # 锚点插入
    ])
    _xml = _zip.ZipFile("/tmp/cg_tbl_out.docx").read("word/document.xml").decode("utf-8")
    _stg = _zip.ZipFile("/tmp/cg_tbl_out.docx").read("word/settings.xml").decode("utf-8")
    _ids = re.findall(r'<w:(?:ins|del) w:id="(\d+)"', _xml)

    def _wellformed():
        _ET.fromstring(_xml)
        return True

    def _parser_matches():
        pf = set()
        for act in build_parser()._actions:
            pf |= set(act.option_strings)
        pf -= {"-h", "--help"}
        return (not (pf - COMMAND_FLAGS - INPUT_FLAGS)) and (not (COMMAND_FLAGS - pf))

    def _schema_flags_registered():
        used = set()
        for k in SCHEMA["commands"]:
            used.add(k.split()[0])
        return used <= COMMAND_FLAGS

    def _library_complete():
        import clause_library as lib
        # 每种有模板的类型，都必须有访谈清单；否则「先问再改」的链路断在半路
        return all(t in lib.INTERVIEW for t in lib.TEMPLATES) and \
            all(len(v) >= 5 for v in lib.TEMPLATES.values()) and \
            all(len(v) >= 5 for v in lib.INTERVIEW.values())

    def _raises(fn, exc=Exception):
        """负向断言：该炸的时候必须炸。静默返回空结果比报错更危险。"""
        try:
            fn()
        except exc:
            return True
        return False

    open("/tmp/cg_notzip.docx", "w", encoding="utf-8").write("这不是一个 zip 包")
    # 容错样本：编码、格式伪装、类型过滤
    open("/tmp/cg_gbk.md", "wb").write("合同金额：壹拾万元\n第二条 验收后付款。".encode("gb18030"))
    open("/tmp/cg_u16.md", "wb").write("合同金额：壹拾万元\n第二条 验收后付款。".encode("utf-16"))
    open("/tmp/cg_bom.md", "wb").write(b"\xef\xbb\xbf" + "合同金额：壹拾万元".encode("utf-8"))
    open("/tmp/cg_fake.pdf", "wb").write(b"%PDF-1.7\n\x00\x01binary")
    open("/tmp/cg_fake.doc", "wb").write(b"\xd0\xcf\x11\xe0" + b"\x00" * 80)

    def _read_gbk():
        return safe_io.read_text("/tmp/cg_gbk.md")[1] == "gb18030"

    def _read_u16():
        text, enc, _ = safe_io.read_text("/tmp/cg_u16.md")
        return enc == "utf-16" and "合同金额" in text

    def _block_pdf():
        try:
            safe_io.read_text("/tmp/cg_fake.pdf")
            return False
        except safe_io.ReadError as exc:
            return "PDF" in exc.message

    def _block_doc():
        try:
            safe_io.read_text("/tmp/cg_fake.doc")
            return False
        except safe_io.ReadError as exc:
            return ".doc" in exc.message and bool(exc.hint)

    def _skip_invoice():
        import scan_rules as _sr
        labor = [r["code"] for r in _sr.applicable("劳动")]
        return "S10" not in labor and "S10" in [r["code"] for r in _sr.RULES]

    def _only_for_labor():
        import scan_rules as _sr
        labor = [r["code"] for r in _sr.applicable("劳动")]
        buy = [r["code"] for r in _sr.applicable("买卖")]
        none = [r["code"] for r in _sr.applicable(None)]
        return "S17" in labor and "S17" not in buy and "S17" not in none

    def _alias_ok():
        import scan_rules as _sr
        a = [r["code"] for r in _sr.applicable("劳动合同")]
        b = [r["code"] for r in _sr.applicable("劳动")]
        return a == b

    def _no_false_positive():
        """治「规则名与说明不一致」：名称写着「无退出」，就得真判有没有退出。"""
        import scan_rules as _sr
        bad = _sr.false_positives()
        if bad:
            print("      误伤：%s" % "、".join(bad))
        return not bad

    def _digest_complete():
        import scan_rules as _sr
        root = os.path.dirname(os.path.dirname(me))
        p14 = open(os.path.join(root, "references", "14-审查报告的三层结构.md"),
                   encoding="utf-8").read()
        codes = set(re.findall(r"\| (S\d\d) \|", p14))
        missing = sorted({r["code"] for r in _sr.RULES} - codes)
        if missing:
            print("      速查表缺：%s" % "、".join(missing))
        return not missing

    def _desc_len_ok():
        """门脸（货架描述）必须控制在 500–600 字。

        这条断言是为我自己加的：字数限制说过一次，改文档时又写回去了。
        「记得要短」靠记忆必然失效，靠断言才有效。
        """
        import json as _json
        root = os.path.dirname(os.path.dirname(me))
        meta = _json.load(open(os.path.join(root, "_meta.json"), encoding="utf-8"))
        n = len(meta.get("description", ""))
        if not (500 <= n <= 600):
            print("      当前 %d 字（要求 500–600）" % n)
            return False
        return True

    def _rule_count_match():
        """正文写的「N 类高频坑」必须等于实际规则数。

        同一个事实（规则一共几条）以前散在四处手写，改一处漏三处——
        这就是「规则和说明不一致」的来源。
        """
        import scan_rules as _sr
        root = os.path.dirname(os.path.dirname(me))
        sk = open(os.path.join(root, "SKILL.md"), encoding="utf-8").read()
        nums = re.findall(r"(\d+)\s*类高频坑", sk)
        if not nums:
            return False
        # 全文每一处都必须对上：只核第一处，第二处写错照样漏
        return all(int(x) == len(_sr.RULES) for x in nums)

    def _rules_alive():
        import scan_rules as _sr
        dead = _sr.uncovered_rules()
        if dead:
            print("      死规则：%s" % "、".join(dead))
        return not dead

    def _rules_complete():
        """三层缺一层，输出就会出现「有清单没改法」的半成品。"""
        import scan_rules as _sr
        bad = [r["code"] for r in _sr.RULES
               if not (r.get("why") and r.get("plain") and r.get("fix"))]
        if bad:
            print("      三层不全：%s" % "、".join(bad))
        return not bad

    def _doc_counts_match():
        """文档自称的数字，必须等于条款库的实际条数。

        这是最容易漂的一类：加了七类模板，正文还写着「14 类 85 条」。
        靠人记必然漏，所以让它变成一条断言。
        """
        import clause_library as _lib
        tc = sum(len(v) for v in _lib.TEMPLATES.values())
        tq = sum(len(v) for v in _lib.INTERVIEW.values())
        root = os.path.dirname(os.path.dirname(me))
        sk = open(os.path.join(root, "SKILL.md"), encoding="utf-8").read()
        m1 = re.search(r"(\d+)\s*条必守条款", sk)
        m2 = re.search(r"(\d+)\s*个问题", sk)
        if not (m1 and m2):
            return False
        if int(m1.group(1)) != tc or int(m2.group(1)) != tq:
            return False
        # references/13 的索引表：每类数字必须与实现一致
        r13 = open(os.path.join(root, "references", "13-条款模板与访谈清单.md"),
                   encoding="utf-8").read()
        for k, v in _lib.TEMPLATES.items():
            mm = re.search(r"\| %s \| (\d+) \|" % re.escape(k), r13)
            if not mm or int(mm.group(1)) != len(v):
                return False
        return True

    direct = [
        ("修订稿 XML 良构", _wellformed),
        ("修订稿保留表格（w:tbl 未被丢弃）", lambda: "<w:tbl>" in _xml),
        ("修订稿保留原段落样式", lambda: 'w:val="32"' in _xml),
        ("修订稿保留原对齐", lambda: 'w:jc w:val="center"' in _xml),
        ("修订稿 id 全文档唯一", lambda: len(_ids) == len(set(_ids)) and len(_ids) >= 4),
        ("修订稿开启修订模式", lambda: "trackChanges" in _stg),
        ("修订稿含真实删除痕迹 delText", lambda: _xml.count("<w:delText") >= 2),
        ("四种修订意图全部生效", lambda: _rl["counts"]["applied"] == 4
         and not _rl["missed"]),
        ("parser 开关与命令/输入两张表完全一致", _parser_matches),
        ("SCHEMA 未登记不存在的命令", _schema_flags_registered),
        ("SCHEMA 每命令三字段齐全",
         lambda: all({"summary", "inputs", "exit_codes"} <= set(v)
                     for v in SCHEMA["commands"].values())),
        ("条款库：模板与访谈清单一一对应且各不少于 5 条", _library_complete),
        ("文档自称的条款数/问题数与条款库实际一致", _doc_counts_match),
        ("读取：GBK 合同自动按 gb18030 解码", _read_gbk),
        ("读取：UTF-16 不被误判为二进制", _read_u16),
        ("读取：PDF 伪装成文本必须拦下", _block_pdf),
        ("读取：.doc 必须识别并给出另存建议", _block_doc),
        ("类型过滤：劳动合同跳过发票检查", _skip_invoice),
        ("类型过滤：劳动专属规则仅在劳动出现", _only_for_labor),
        ("类型别名：劳动合同/劳动 等价", _alias_ok),
        ("审查规则无死规则（每条都能被样本触发）", _rules_alive),
        ("审查规则无误伤（写对了必须放行）", _no_false_positive),
        ("速查表覆盖全部规则码", _digest_complete),
        ("文档自称的规则条数与实际一致", _rule_count_match),
        ("门脸描述长度在 500–600 字", _desc_len_ok),
        ("审查规则每条三层齐全（为什么/会怎么爆/怎么改）", _rules_complete),
        ("非法 docx 必须抛错而非静默",
         lambda: _raises(
             lambda: _ox.redline("/tmp/cg_notzip.docx", "/tmp/x.docx", []), Exception)),
    ]

    for name, fn in direct:
        try:
            ok = bool(fn())
        except Exception as exc:  # noqa: BLE001 — 断言本身炸了，就是没通过
            ok = False
            print("[FAIL] %s → 断言异常 %s" % (name, exc))
        if ok:
            passed += 1
        else:
            failed += 1
            print("[FAIL] %s" % name)

    print("\n自检 %d/%d 通过" % (passed, passed + failed))
    return 0 if failed == 0 else 1


# ---------------------------------------------------------------------------
# 机读契约
# ---------------------------------------------------------------------------
# 命令型开关与输入型参数的显式分界。
# 有了这两张表，才能写一条真断言：parser 里的开关必须恰好等于「命令 + 输入」，
# 多出来的就是「加了命令没登记」——以前靠人记，现在靠机检。
COMMAND_FLAGS = {"--calc", "--check", "--diff", "--redline", "--template",
                 "--interview", "--schema", "--self-test", "--version"}
INPUT_FLAGS = {"--amount", "--loss", "--prob", "--recovery", "--margin", "--cash",
               "--cost-ratio", "--prepay", "--progress", "--accept", "--retention",
               "--retention-days", "--payment-days", "--funding-rate",
               "--amount-level", "--irreversible", "--counterparty",
               "--claim", "--counterparty-type", "--guarantee", "--jurisdiction",
               "--evidence", "--red", "--yellow", "--green", "--clauses",
               "--out", "--patch", "--patch-file", "--author", "--brief", "--type"}

# 已在 build_parser 里手工定义过的开关，循环注册时必须跳过
DECLARED_SEPARATELY = {"--out", "--patch", "--patch-file", "--author", "--brief", "--type"}

SCHEMA = {
    "skill": "contract-review-officer",
    "display_name": "合同审查官",
    "version": VERSION,
    "exit_codes": {str(k): v for k, v in EXIT_MEANING.items()},
    "commands": {
        "--calc exposure": {"summary": "风险敞口定价：最坏净损失、期望损失、毛利覆盖、现金冲击",
                            "inputs": ["--amount", "--loss", "--prob", "--recovery", "--margin", "--cash"],
                            "exit_codes": [0, 2]},
        "--calc cashflow": {"summary": "现金流占用：回款结构、垫资峰值、资金成本",
                            "inputs": ["--amount", "--cost-ratio", "--prepay", "--progress",
                                       "--accept", "--retention", "--retention-days",
                                       "--payment-days", "--funding-rate"],
                            "exit_codes": [0, 1, 2]},
        "--calc depth": {"summary": "审查深度匹配：速审 / 标准 / 深度 / 尽调级",
                         "inputs": ["--amount-level", "--irreversible", "--counterparty"],
                         "exit_codes": [0, 2]},
        "--calc remedy": {"summary": "救济可行性：打赢了能拿回多少",
                          "inputs": ["--claim", "--counterparty-type", "--guarantee",
                                     "--jurisdiction", "--evidence"],
                          "exit_codes": [0, 2]},
        "--calc grade": {"summary": "风险分级汇总：能不能签",
                         "inputs": ["--red", "--yellow", "--green", "--clauses"],
                         "exit_codes": [0, 1, 2]},
        "--check": {"summary": "合同文本体检：规则级扫描 + 四格完整性",
                    "inputs": ["FILE"],
                    "exit_codes": [0, 1, 2]},
        "--diff": {"summary": "两版对比：把文字改动翻译成交易条件改动",
                   "inputs": ["OLD", "NEW"],
                   "exit_codes": [0, 1, 2]},
        "--redline": {"summary": "生成带 Word 原生修订痕迹（w:ins / w:del）的稿件",
                      "inputs": ["--redline SRC", "--out", "--patch", "--patch-file", "--author"],
                      "exit_codes": [0, 1, 2]},
        "--template": {"summary": "该合同类型的必守条款与起手文本",
                       "inputs": ["类型"],
                       "exit_codes": [0, 1, 2]},
        "--interview": {"summary": "该合同类型的审查访谈清单（含对方可能的搪塞与追问）",
                        "inputs": ["类型"],
                        "exit_codes": [0]},
        "--schema": {"summary": "打印机读契约", "inputs": [], "exit_codes": [0]},
        "--self-test": {"summary": "内置自检", "inputs": [], "exit_codes": [0, 1]},
        "--version": {"summary": "版本", "inputs": [], "exit_codes": [0]},
    },
    "error_codes": {
        "E01": ("关键字段缺失", 2),
        "E03": ("枚举越界", 2),
        "E04": ("数值越界", 2),
        "E05": ("数值非法（含 nan / inf）", 2),
        "E06": ("比例合计不等于 100%", 2),
        "E09": ("硬阻断（红线 / 应止步）", 1),
        "E11": ("文件读取失败", 2),
        "E12": ("输入格式非法（JSON / 补丁格式）", 2),
        "E13": ("写入失败", 2),
        "E20": ("两版对比命中交易条件实质变更", 1),
        "E21": ("修订条目未命中原文，未生效", 2),
        "E22": ("该合同类型暂无专属模板", 2),
    },
}


def build_parser():
    p = argparse.ArgumentParser(prog="contract_guard", add_help=True)
    p.add_argument("--version", action="store_true")
    p.add_argument("--self-test", dest="self_test", action="store_true")
    p.add_argument("--schema", action="store_true")
    p.add_argument("--calc", choices=["exposure", "cashflow", "depth", "remedy", "grade"])
    p.add_argument("--check")
    p.add_argument("--diff", nargs=2, metavar=("OLD", "NEW"),
                   help="两版对比：判断对方改的是交易条件还是错别字")
    p.add_argument("--redline", help="生成带 Word 原生修订痕迹的稿件")
    p.add_argument("--out", help="修订稿输出路径（默认同目录加 -修订）")
    p.add_argument("--patch", action="append",
                   help="一条修订，格式「原文=>新文」，可重复")
    p.add_argument("--patch-file", dest="patch_file",
                   help="修订条目 JSON 数组，每项含 old / new / reason / scope / anchor")
    p.add_argument("--author", default="合同审查官", help="修订痕迹作者名")
    p.add_argument("--brief", action="store_true",
                   help="体检只出清单（位置+规则名），不展开「为什么/怎么改」")
    p.add_argument("--type", help="合同类型（如 劳动合同/买卖/股权代持），"
                                 "用于跳过该类不适用的检查")
    p.add_argument("--template", choices=CONTRACT_TYPES, help="打印该类型必守条款")
    p.add_argument("--interview", choices=CONTRACT_TYPES, help="打印该类型审查访谈清单")
    for name in sorted(f.lstrip("-") for f in INPUT_FLAGS):
        if "--" + name in DECLARED_SEPARATELY:
            continue  # 已单独定义（dest 或提示语不同，不能重复注册）
        p.add_argument("--" + name, dest=name.replace("-", "_"))
    return p


def main(argv=None):
    p = build_parser()
    a = vars(p.parse_args(argv))

    if a.get("version"):
        print("contract_guard " + VERSION)
        return 0
    if a.get("schema"):
        print(json.dumps(SCHEMA, ensure_ascii=False, indent=2))
        return 0
    if a.get("self_test"):
        return run_self_test()
    if a.get("diff"):
        code = cmd_diff(a)
        emit_findings()
        return code
    if a.get("redline"):
        code = cmd_redline(a)
        emit_findings()
        return code
    if a.get("template"):
        code = cmd_template(a)
        emit_findings()
        return code
    if a.get("interview"):
        code = cmd_interview(a)
        emit_findings()
        return code
    if a.get("check") is not None:
        # 用 is not None 而不是真值判断：--check "" 是「传了但为空」，
        # 真值判断会把它当成「没传」，然后打印帮助并返回 0——
        # 用户以为检查通过了，实际什么都没查。
        return do_check(a)
    if a.get("calc"):
        # 退出码统一由 findings 决定：各计算函数自己 return 0，
        # 会让「加了 BLOCK 却退 0」成为死码——红线出了，进程却报成功。
        CALCS[a["calc"]](a)
        emit_findings()
        return exit_code_from_findings()
    p.print_help()
    return 0


CALCS = {
    "exposure": calc_exposure,
    "cashflow": calc_cashflow,
    "depth": calc_depth,
    "remedy": calc_remedy,
    "grade": calc_grade,
}


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except KeyboardInterrupt:
        print("已中断。", file=sys.stderr)
        sys.exit(2)
    except Exception as exc:  # noqa: BLE001 — 顶层兜底：未预料异常转退出码 2，不裸抛
        print("内部错误：%s" % exc, file=sys.stderr)
        print("输入快照：%s" % json.dumps(sys.argv[1:], ensure_ascii=False), file=sys.stderr)
        sys.exit(2)
