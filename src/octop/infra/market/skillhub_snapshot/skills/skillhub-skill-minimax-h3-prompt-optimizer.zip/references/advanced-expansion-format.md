# MiniMax H3 结构化扩写 Prompt 格式规范（开发者/专业向）

> 提炼自官方《MiniMax H3 - 视频扩写 Prompt 写作全能指南》。适用于需要精确控制、可复现、工程化的场景（API 调用、批量生产、专业团队）。
> 与 `prompt-guide.md` 的自然语言写法的关系：本规范是同一套思路的结构化英文格式——镜头、运镜、说话人、台词规则两边共用。

## 一、任务类型判定（文生/关键帧）

| 类型 | 含义 | instruction（必须位于 Prompt 第一行，后空一行再写主体） |
|---|---|---|
| T2VA | 纯文生视频 | 无 instruction，直接从主体字段开始 |
| I2VA | 首帧图生视频 | `For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.` |
| FL2VA | 首+尾帧 | `How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot N) aligns with the S.SS-second mark of the target video.` |
| L2VA | 仅尾帧 | `How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.` |

- `N` = 最后一个实际镜头编号；`S.SS` = 视频有效时长，固定两位小数。

## 二、主体三字段（T2VA/I2VA/FL2VA/L2VA 共用）

```text
integrated_multimodal_description: [Shot 1] ...

overall_soundscape: ...

non_diegetic_music: ...
```

- `integrated_multimodal_description`：沿时间线写画面、动作、镜头、说话人、台词、演唱和场景内声音。
- `overall_soundscape`：1-4 句英文概括环境声、物理动作声、非语言人声（风雨/脚步/衣料/呼吸/笑声）。不重复对白；整段静音才写 `N/A`。
- `non_diegetic_music`：1-3 句英文描述观众才能听到的配乐，写乐器、速度、节奏、动态变化；**不写抽象情绪词**。角色能听到的音乐属于场景内事件，写进多模态描述。无配乐写 `N/A`。

## 三、关键帧写作路径

- **I2VA**：首帧锚点 → 动作起点 → 连续变化 → 结果或反应。先建立图中的风格/主体/构图/场景锚点，人物身份、服装、颜色、空间关系保持一致。
- **FL2VA**：首帧状态 → 可观察的中间变化 → 差异逐步缩小 → 尾帧状态。优先单镜头连续插值；重点写位移、姿态、物体操作、构图、光线过渡，**不要重复描述两张图本身**。
- **L2VA**：合理前态 → 明确动作路径 → 最后镜头逐步收敛 → 尾帧落点。尾帧属于最后一个 [Shot N]。

## 四、镜头描述规则

- `[Shot 1]` 开头先写整体风格与初始构图，**不写时间戳**。风格词：`Cinematic`、`live-action`、`2D-animated`、`3D CG`、`claymation`、`watercolor`、`vintage film`。
- 后续镜头连续编号 + 递增切镜时间（在视频时长范围内）：
  `[Shot 2] At 00:03.500, the camera cuts to...`
- 切镜动词：`the camera cuts to` / `the shot cuts to` / `transitions to` / `changes to` / `switches to`。

### 规范运镜词汇（运镜 + 幅度 + 速度，中幅常速可省略）

| 维度 | 词汇 |
|---|---|
| 焦距 | `Zoom In` / `Zoom Out` |
| 前后移动 | `Push In` / `Pull Out` |
| 水平转动 | `Pan Left` / `Pan Right` |
| 水平平移 | `Truck Left` / `Truck Right` |
| 垂直转动 | `Tilt Up` / `Tilt Down` |
| 垂直移动 | `Pedestal Up` / `Pedestal Down` |
| 环绕/跟随 | `Arc Shot` / `Tracking Shot` |
| 静止/抖动 | `Static Shot` / `Shake Slightly` / `Shake Strongly` |
| 特殊 | `POV` / `Roll Clockwise` / `Roll Counterclockwise` |
| 幅度 | `with small amplitude` / `with large amplitude` |
| 速度 | `at slow speed` / `at fast speed` |

示例：`The camera pushes in with small amplitude at slow speed toward the folded letter in her hands.`

## 五、说话人、台词与声音标记

- 发声主体用稳定编号 `(S1)`、`(S2)`…，跨镜头保持同一编号；不发声者不编号；多人同时发声用组合编号 `(S1,S2)`。
- 首次出现补充身份与声音特征（年龄/性别/是否出镜/音高/音色/语速/口音）。
- 台词格式：`<d>[Language] 原文</d>`——原词标点逐字保留，不翻译不改写。
  `The young woman with a quiet, breathy voice (S1) says: <d>[English] I get off at the next station.</d>`
- 画外音：`says in an off-screen voiceover`，且 `<d>` 后立即写画面人物嘴唇闭合：
  `... says in an off-screen voiceover: <d>[English] ...</d> while his lips remain completely closed.`（纯画外说话人无可见嘴部则不写闭嘴描述）
- 跨切镜台词：两半句连接处各用 `<scenetrans>`，并在新镜头说明音频连续（`The audio seamlessly continues from the previous shot.` / `continues uninterrupted into the next shot` / `carries over from the previous shot` / `remains audible across the transition`）。跨两次切镜时中间段 `<d>` 以 `<scenetrans>` 同时开头结尾。
- 结尾台词被截断：句末用 `<cutoff>`。
- 画面可见文字（招牌/横幅/霓虹）：英文双引号包围原文，不翻译：`a red neon sign reading "营业中" glows above the doorway`。
- 复用音频中的台词无法辨认时写 `[unclear]`，不猜测；标点只保留基础书面标点，删除 emoji、波浪号、装饰性标点。

## 六、全能参考模式：六段结构

按固定顺序排列，正文统一英文（`<d>` 台词与画面文字保留原语言）：

| 段落 | 作用 |
|---|---|
| `subject_definitions` | 定义参考内容及引用标签 |
| `summary` | 概括任务类型、目标视频和主要引用关系 |
| `retention_analysis` | 说明每项参考的保留/迁移/复用关系 |
| `detailed_description` | 按播放顺序逐镜描述画面、动作、镜头、声音、台词 |
| `overall_soundscape` | 环境声与物理声音 |
| `non_diegetic_music` | 观众向背景配乐 |

### 1. 四类引用标签

| 标签 | 内容 |
|---|---|
| `<Subject N>` | 可复用/修改的可见内容单元：人物、动物、物体、场景、服装、道具、界面、特效、风格、动作、表情、姿态 |
| `<Picture N>` | 作为具体帧锚点（首帧/关键帧/尾帧/构图锚点/故事板）的参考图片 |
| `<Video N>` | 整段视频层面关系：剪辑源、续写起点、运镜/切镜/节奏/时序结构参考 |
| `<Audio N>` | 被复制或参考的音频信号 |

规则：

- 标签一旦分配，全文沿用同一含义。
- 一个 Subject 可由多份素材共同定义：`<Subject 1> is the woman whose appearance comes from <Picture 1> and whose walking motion comes from <Video 1>.`
- 图片仅用于定义人物/场景/风格时，不另建 `<Picture N>`，在 Subject 定义中引用来源即可。
- 参考视频里被复用的人物/物体/动作仍归 `<Subject N>`；`<Video N>` 只作素材/结构来源。
- `<Video N>` 与 `<Audio N>` 独立编号，同一份参考视频可同时是 `<Video 1>` 和 `<Audio 2>`；带声音的视频不自动产生 `<Audio N>`。
- `<Audio N>` 对应目标说话人时沿用全局编号：`<Audio 1> is the voice-timbre reference for <Subject 1> (S1).`

### 2. summary 任务类型标记

开头用方括号标注，多类型用 ` + ` 组合（加号前后各一空格）：

| 类型 | 场景 |
|---|---|
| `keyframe completion` | 图片作为首帧/关键帧/尾帧等帧锚点 |
| `reference generation` | 素材提供人物/场景/风格/动作/运镜/分镜参考，不作帧锚点或编辑源 |
| `video editing` | 直接修改已有源视频 |
| `video continuation` | 从源视频继续/延长/转接 |
| `audio reuse` | 完整或部分复用同一音频信号 |
| `audio reference` | 只参考配乐风格/音色/台词内容/节拍，不复制信号 |

注意：素材含视频/音频不自动产生对应类型——参考视频仅提供运镜节奏时属 `reference generation`；编辑源视频且原音轨可听时通常加 `audio reuse`。视频编辑类摘要在类型后接：`The target video is an edited version of <Video 1>.`

### 3. retention_analysis 关系标记

每个引用标签一行，标注出现的镜头 + 关系标记 + 说明：

可见内容（Subject/Picture/Video）：

| 标记 | 含义 |
|---|---|
| `fully_preserved` | 既定作用完整保留 |
| `partially_preserved` | 部分特征变化或只保留一部分 |
| `attribute_transfer` | 特征迁移到另一可识别载体 |
| `weak_reference` | 只保留宽泛风格/类别/构图/氛围相似 |

音频（Audio）：

| 标记 | 含义 |
|---|---|
| `fully_copy` | 完整源音频 1:1 作为最终音轨 |
| `partially_copy` | 只复制部分时段/层，或复制后有增删换 |
| `reference` | 只参考音色/节奏/风格/内容，不复制信号 |
| `weak_reference` | 只保留宽泛类别或氛围相似 |

写法：`<Subject 1> (appears in [Shot 1], [Shot 3]): fully_preserved - ...`；`retention_analysis` 中不写 `(Sx)`。

### 4. detailed_description 要点

- 与 T2VA 的差异：① 在 `[Shot 1]` **之前**用 1-2 句英文建立全局视觉风格；② 在引用首次出现和实际作用位置插入标签；③ 音频在对应镜头/时段引用 `<Audio N>` 并说明复制/参考关系。
- 生成类通常 350-500 英文单词；台词密集型以容纳台词时间线为先；编辑类按源视频复杂度展开。
- 帧锚点自然表达：`the shot begins from <Picture 1>` / `the shot's keyframe corresponds to <Picture 2>` / `the shot ends on <Picture 3>`。
- 主体本人发声：`<Subject 2> (S1) turns and says, <d>[English] ...</d>`；仅作为 BGM/soundtrack 音轨内容的人声片段用 `<Audio N>` 作声源，不分配 `(Sx)`。

## 七、精简完整示例（全能参考）

```text
subject_definitions:
<Subject 1> is the coffee-shop environment in <Picture 1>, featuring an exposed brick wall, an orange tufted sofa, and a neon sign.
<Subject 2> is the fluffy white Samoyed in <Picture 2>.
<Audio 1> is the voice-timbre reference for <Subject 3> (S1).

summary:
[reference generation + audio reference] The target video shows <Subject 3> eating a cookie in <Subject 1> ...

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2]): fully_preserved - the brick wall, sofa, neon sign are retained.
<Audio 1>: reference - its vocal timbre guides the dialogue delivery without copying the original signal.

detailed_description:
The target video uses a realistic multi-camera sitcom style with warm indoor lighting.
[Shot 1] A medium shot establishes <Subject 1> ... <Subject 3> (S1) exclaims, <d>[English] Hey! Watch your dog!</d> while her lips ...
[Shot 2] At 00:03.000, the shot cuts to a close-up of ...

overall_soundscape:
Soft indoor coffee-shop room tone continues throughout the scene.

non_diegetic_music:
N/A
```
