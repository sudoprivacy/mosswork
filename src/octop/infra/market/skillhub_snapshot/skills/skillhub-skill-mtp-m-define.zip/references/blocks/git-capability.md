trigger: Git 不可用、locator 缺失或失效
budget: 600
next: 降级状态不得报告为 verified 或 Accepted

# Git Capability

Git 不可用时 Define 仍可记录本地事实：`MTP_THINK.md` 与 `ai/brief.md` 的 digest 绑定写入不依赖
Registry。`scripts/manage_define.py` 的 `inspect` 返回 `capability`，由
`m-build/scripts/capability_matrix.py` 统一判定：无 Git 时共享查找/同步、Registry 相关
Acceptance、checkpoint、rollback、tag、formal-release 全部 blocked；locator 缺失时仅在 bootstrap
后恢复；locator 失效时本地工作可继续，但每个 Registry 依赖操作都要求显式 repair 且始终非
Accepting。任何降级状态都不得报告为 verified 或 Accepted。
