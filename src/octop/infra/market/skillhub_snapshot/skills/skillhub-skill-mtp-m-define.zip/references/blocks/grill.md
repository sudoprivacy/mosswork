trigger: 用户明确要求 grill me、访谈或逐题追问
budget: 300
next: 仍受同一文件边界与机器 Gate 约束

# Grill Mode

只有用户明确要求"grill me"、访谈、逐题追问或等价意图时才加载 `references/grill-mode.md`。
普通 Define 不读取该 reference、不产生 Think-More 输出、不自动进入访谈。Grill Mode 仍受同一
文件边界和机器 Gate 约束。
