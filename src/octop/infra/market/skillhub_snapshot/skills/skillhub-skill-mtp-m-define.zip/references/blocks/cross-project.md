trigger: 用户询问其他项目、可复用能力或跨项目 Lesson
budget: 700
next: 发现结果带 Registry revision 与选中 ID

# Cross-Project Navigation

用户询问其他项目、可复用能力或跨项目 Lesson 时，不直接扫描项目目录，也不先打开
`MTP_THINK.md`。按渐进式披露顺序：Registry 全量 index → 相关 record summary/detail → 来源项目
`CLAUDE.md` → evidence 指针所需的最小文件。使用当前项目安装的 `ai/registry.py` 与
`m-plan/scripts/validate_plan.py` 的 `discover` 路径；Skill 安装路径不是 locator。

Registry 不可用时，local-only 问题可继续普通 Define；显式跨项目问题阻断并说明需要恢复 Registry；
其他 Registry relevant 问题只记录 project-local `ai/NEXT.md` 的 `registry-pending`，不写入
Passport。发现结果必须包含 Registry revision、候选/选中 ID、适用性和停止条件。读取其他项目不
授权复制、调用、集成或修改其内容。
