trigger: 普通不确定性，要定点提问或只更新当前事实
budget: 800
next: 事实足够后路由 m-plan

# Ordinary Define

普通不确定性保持简洁：读取与问题相关的现有事实，提出必要问题，确认后只更新唯一允许的文件。立项
前使用 `references/think-format.md` 和 helper 原子更新 `MTP_THINK.md`；当前项目原位替换
`ai/brief.md` 中已失效的当前事实，历史由 Git 保留。不写 `ai/plan.md`、代码、`CLAUDE.md`、
`ai/lessons.md` 或聊天记录，不启动子 Agent。

遵循 Think Before Coding、Simplicity First、Surgical Changes 和 Goal-Driven Execution：先区分
事实、目标、范围、非目标、约束、假设、开放问题与成功标准。只问会改变方向的问题；当前事实足以
形成 AC、TC 和确定性验证时，路由 `m-plan`。

**收尾地图（D-4）**：目标 / 范围 / 边界变化后，用 `manage_define.py --target <项目> --apply-map`
（stdin 传 `{"sections": {"Project": …, "Scope": …, "Boundaries": …}, "conflicts": []}`）更新这
三节。`manage_define` **不直写 `CLAUDE.md`**：它只放行这三节，`Current State` 由
`project_memory` 生成器从 `ai/NEXT.md` 机械生成，写入经 `project_memory.apply_sync`；ACL 之外的
节一律零写拒绝。

方向已清晰、只是局部可逆且可确定性验证的工作，不进入 Define，路由 `m-build` Direct Path。
不以外部 Skill 声称替代 AC、TC、受影响验证、强制审查或机器 Gate；证据不足时停止或返回对应入口。
