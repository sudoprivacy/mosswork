---
name: skillhub-skill-mtp-m-define
description: "monster 的 MTP 0.2.4 定义入口。目标、范围、约束、成功标准或方案方向不确定时使用。"
---

# M-Define

```mermaid
flowchart LR
  A["查状态"] --> B["写事实"] --> C["路由"]
```

## Preflight

先用 `scripts/manage_think.py --target <root> --json` 检查目标。没有 `ai/mtp.json` 时仅可写根目录
`MTP_THINK.md`；有效的 `0.2.4 lightweight` 项目仅可写 `ai/brief.md`；缺失、损坏、版本不符或
不安全路径均零写并返回 `m-new`。不创建、修复或推测 manifest。

## 读哪块

| 状态 | 读 |
|---|---|
| 普通不确定性、要定点提问 | `blocks/ordinary-define.md` |
| 问其他项目、可复用能力 | `blocks/cross-project.md` |
| 用户要求 grill / 访谈 | `blocks/grill.md` |
| Git 不可用、locator 失效 | `blocks/git-capability.md` |

## 硬要求

1. 只问会改变方向的问题；事实足以形成 AC/TC 时路由 `m-plan`。
2. 只写唯一允许的文件；不写代码、`ai/plan.md`、`CLAUDE.md`、`ai/lessons.md`。
3. 不以"稍后补测试""看起来没问题""改动太小""Reviewer 不可用"替代机器 Gate。
4. M-Add / M-New 遇实质不确定路由普通 Define，不自动进 Grill Mode。
