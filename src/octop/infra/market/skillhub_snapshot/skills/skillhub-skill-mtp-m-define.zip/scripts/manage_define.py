#!/usr/bin/env python3
"""Fail-closed atomic writer for M-Define's two legal destinations."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import stat
import sys
import tempfile
from pathlib import Path
from typing import Any


class DefineError(ValueError):
    pass


CURRENT_MANIFEST_FIELDS = {"mtp_version", "profile", "project_id", "registry_id"}
PROJECT_ID_RE = re.compile(r"prj-[a-z0-9][a-z0-9-]{2,63}")
REGISTRY_ID = "mtp-local-registry-v1"


def _is_current_manifest(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and set(value) == CURRENT_MANIFEST_FIELDS
        and value.get("mtp_version") == "0.2.4"
        and value.get("profile") == "lightweight"
        and isinstance(value.get("project_id"), str)
        and PROJECT_ID_RE.fullmatch(value["project_id"]) is not None
        and value.get("registry_id") == REGISTRY_ID
    )


def _digest(path: Path) -> str:
    value = {"kind": "missing"}
    if path.exists():
        value = {"kind": "file", "mode": stat.S_IMODE(path.stat().st_mode), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _load_by_path(relative: tuple[str, ...], name: str, error: str):
    path = Path(__file__).resolve().parents[2].joinpath(*relative)
    if path.is_symlink() or not path.is_file():
        raise DefineError(error)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise DefineError(error)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_capability_matrix():
    return _load_by_path(
        ("m-build", "scripts", "capability_matrix.py"),
        "mtp_capability_matrix_define",
        "capability-matrix-missing",
    )


def _locator_facts() -> tuple[str | None, bool]:
    """Read-only probe of the same-OS-user Registry locator (AC-014X-2/3).

    Never writes, never scans for a Registry and never guesses a default: an absent
    locator stays absent and a present-but-unusable one stays raw-but-invalid, so the
    matrix can demand explicit repair instead of silently continuing.
    """
    try:
        helper = _load_by_path(
            ("m-new", "assets", "template", "ai", "registry.py"),
            "mtp_registry_define",
            "registry-helper-missing",
        )
    except Exception:
        return None, False
    try:
        return helper.resolve_registry()["path"], True
    except Exception:
        pass
    try:
        values = helper.read_locator_values()
    except Exception:
        return None, False
    return (values[0] if values else None), False


def _capability() -> dict[str, Any]:
    """Report the AC-014X-7 capability alongside the always-local Define path.

    Recording local facts (`MTP_THINK.md` / `ai/brief.md`) never depends on Git or the
    Registry, so `local_facts` stays available in every state. The Registry-dependent
    operations are reported exactly as the shared matrix decides, so a degraded
    environment can never be mistaken for a verified or Accepted one.
    """
    cap = _load_capability_matrix()
    git_ok = cap.git_available()
    locator_raw, locator_valid = _locator_facts() if git_ok else (None, False)
    state = cap.classify_locator_state(git_ok, locator_raw, locator_valid)
    decision = cap.eval_capability("m-define", state)
    return {
        "local_facts": "available",
        "registry_state": state.value,
        "registry_ops": {op.value: cap.reason_for(outcome) for op, outcome in decision.items()},
    }


def inspect(root: Path) -> dict[str, Any]:
    root = root.expanduser()
    if root.is_symlink() or not root.is_dir():
        raise DefineError("target must be an existing non-symlink directory")
    ai_dir = root / "ai"
    if ai_dir.is_symlink() or (ai_dir.exists() and not ai_dir.is_dir()):
        raise DefineError("ai must be a regular non-symlink directory")
    manifest = ai_dir / "mtp.json"
    if manifest.is_symlink():
        raise DefineError("manifest must not be a symlink")
    capability = _capability()
    if not manifest.exists():
        return {"route": "m-define", "path": "MTP_THINK.md", "write_allowed": True, "capability": capability}
    try:
        contract = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise DefineError("invalid manifest") from error
    if not _is_current_manifest(contract):
        return {"route": "m-new", "write_allowed": False, "capability": capability}
    path = root / "ai/brief.md"
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise DefineError("brief must be a regular non-symlink file")
    if path.exists():
        path.read_bytes().decode("utf-8")
    return {
        "route": "m-define", "path": "ai/brief.md", "write_allowed": True,
        "source_digest": _digest(path), "capability": capability,
    }


def apply_brief(root: Path, data: bytes, expected_digest: str) -> dict[str, Any]:
    state = inspect(root)
    if state.get("path") != "ai/brief.md" or state.get("source_digest") != expected_digest:
        raise DefineError("brief source digest mismatch or write is not allowed")
    try:
        data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise DefineError("brief must be UTF-8") from error
    path = root / "ai/brief.md"
    current = path.read_bytes() if path.exists() else b""
    # R-4: when the brief content is unchanged the contract did not move, so do not force
    # a replan — surface an explicit `contract_unchanged` signal and route to m-build.
    if data == current:
        return {
            "route": "m-build", "path": "ai/brief.md",
            "source_digest": _digest(path), "contract_unchanged": True,
        }
    descriptor, temporary_name = tempfile.mkstemp(prefix=".brief.md.mtp-tmp-", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if _digest(path) != expected_digest:
            raise DefineError("brief source digest mismatch")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return {
        "route": "m-plan", "path": "ai/brief.md",
        "source_digest": _digest(path), "contract_unchanged": False,
    }


# T-021-MAPTRIGGER: m-define may update exactly these map sections at its wrap-up; the
# `Current State` section is never caller-supplied — the project_memory generator owns it.
WRITABLE_MAP_SECTIONS = ("Project", "Scope", "Boundaries")


def _project_memory():
    """Load the single map writer (`m-build`'s project_memory) installed beside this skill."""
    path = Path(__file__).resolve().parents[2] / "m-build/scripts/project_memory.py"
    if not path.is_file():
        raise DefineError("project_memory is unavailable; map writes are not allowed")
    spec = importlib.util.spec_from_file_location("mtp_define_project_memory", path)
    if spec is None or spec.loader is None:
        raise DefineError("project_memory is unavailable; map writes are not allowed")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def apply_map(root: Path, projection: dict[str, Any], expected_digest: str | None = None) -> dict[str, Any]:
    """AC-MAPTRIGGER-2/-6: route map updates through project_memory.apply_sync only.

    ``manage_define`` never writes ``CLAUDE.md`` itself: the payload is checked against
    this module's ACL (only Project/Scope/Boundaries may be supplied), the Current State
    body is regenerated from ``ai/NEXT.md``, and the write goes through the same
    digest-bound sync path every other map writer uses. Anything else fails closed.
    """
    state = inspect(root)
    if state.get("route") != "m-define" or not state.get("write_allowed"):
        raise DefineError("map update is not allowed for this project")
    if not isinstance(projection, dict) or set(projection) != {"sections", "conflicts"}:
        raise DefineError("map projection must carry exactly sections and conflicts")
    sections = projection["sections"]
    if not isinstance(sections, dict) or not sections:
        raise DefineError("map projection sections must be a non-empty mapping")
    unknown = sorted(set(sections) - set(WRITABLE_MAP_SECTIONS))
    if unknown:
        raise DefineError(f"m-define may not write map section: {unknown[0]}")
    if projection["conflicts"]:
        raise DefineError("map conflicts must be resolved in m-define before writing")
    module = _project_memory()
    payload = dict(sections)
    next_path = root / "ai/NEXT.md"
    if next_path.is_file():
        payload["Current State"] = module.current_state_from_next(
            next_path.read_text(encoding="utf-8"))
    write = {"sections": payload, "conflicts": []}
    preview = module.inspect_sync(root, write, explicit=True, actor="primary")
    if expected_digest and preview["plan_digest"] != expected_digest:
        raise DefineError("map plan digest mismatch")
    return module.apply_sync(
        root, write, preview["plan_digest"], explicit=True, actor="primary",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Inspect or update M-Define brief.md")
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--expect-source-digest")
    parser.add_argument(
        "--apply-map", action="store_true",
        help="apply a project-map projection (JSON on stdin) through project_memory",
    )
    parser.add_argument("--expect-map-digest")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        if args.apply_map:
            if args.apply or args.expect_source_digest:
                raise DefineError("--apply-map cannot be combined with a brief write")
            projection = json.loads(sys.stdin.buffer.read().decode("utf-8"))
            result = apply_map(args.target, projection, args.expect_map_digest)
        elif args.apply:
            if not args.expect_source_digest:
                raise DefineError("apply requires --expect-source-digest")
            result = apply_brief(
                args.target, sys.stdin.buffer.read(), args.expect_source_digest,
            )
        else:
            if args.expect_source_digest:
                raise DefineError("--expect-source-digest requires --apply")
            result = inspect(args.target)
    except (OSError, DefineError, UnicodeDecodeError) as error:
        print(f"invalid-define-source: {error}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    else:
        print(
            f"{result.get('route', result.get('decision', 'm-define'))}: "
            f"{result.get('path', result.get('target_path', 'ai/brief.md'))}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
