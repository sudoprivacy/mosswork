#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
import tempfile
from pathlib import Path
from typing import Any


SOURCE_NAME = "MTP_THINK.md"
CHINESE_HEADINGS = (
    "# MTP 思考：", "## 0. 生命周期", "## 1. Absorption Summary",
    "### 项目名称", "### 一句话目标", "### 已确认事实", "### 范围",
    "### 非目标", "### 约束", "### 假设", "### 开放问题", "### 成功标准",
    "### Backlog 候选", "### 吸收提示", "## 2. 完整探索", "## 3. 备注",
)
SUMMARY_RE = re.compile(r"^## 1\. Absorption Summary\s*$", re.MULTILINE)
NEXT_SECTION_RE = re.compile(r"^ {0,3}##[ \t]+(?!#)", re.MULTILINE)
CURRENT_MANIFEST_FIELDS = {"mtp_version", "profile", "project_id", "registry_id"}
PROJECT_ID_RE = re.compile(r"prj-[a-z0-9][a-z0-9-]{2,63}")
REGISTRY_ID = "mtp-local-registry-v1"


class ThinkError(ValueError):
    pass


def _is_current_manifest(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and set(value) == CURRENT_MANIFEST_FIELDS
        and value.get("mtp_version") == "0.2.4"
        and value.get("profile") == "lightweight"
        and isinstance(value.get("project_id"), str)
        and PROJECT_ID_RE.fullmatch(value["project_id"]) is not None
        and value.get("registry_id") == REGISTRY_ID
    )


def _digest(target: Path, source: Path) -> str:
    if source.exists():
        data = source.read_bytes()
        state: dict[str, Any] = {
            "kind": "file",
            "mode": stat.S_IMODE(source.stat().st_mode),
            "sha256": hashlib.sha256(data).hexdigest(),
        }
    else:
        state = {"kind": "missing"}
    identity = {"source": state, "target": str(target.absolute())}
    return hashlib.sha256(
        json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def inspect(target: Path) -> dict[str, Any]:
    target = target.expanduser()
    if target.is_symlink() or not target.is_dir():
        raise ThinkError("target must be an existing non-symlink directory")
    ai_dir = target / "ai"
    if ai_dir.is_symlink() or (ai_dir.exists() and not ai_dir.is_dir()):
        raise ThinkError("ai must be a regular non-symlink directory")
    manifest = ai_dir / "mtp.json"
    if manifest.exists() or manifest.is_symlink():
        if manifest.is_symlink():
            return {
                "decision": "invalid-project",
                "route": "m-new",
                "write_allowed": False,
            }
        try:
            contract = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            contract = None
        return {
            "decision": "managed-project",
            "route": (
                "m-define"
                if _is_current_manifest(contract)
                else "m-new"
            ),
            "write_allowed": False,
        }
    source = target / SOURCE_NAME
    if source.is_symlink() or (source.exists() and not source.is_file()):
        raise ThinkError("MTP_THINK.md must be a regular non-symlink file")
    if source.exists():
        source.read_bytes().decode("utf-8")
    return {
        "decision": "update" if source.exists() else "create",
        "route": "m-define",
        "source_digest": _digest(target, source),
        "write_allowed": False,
    }


def validate_document(
    data: bytes,
    language: str = "zh",
    *,
    require_summary_content: bool = False,
) -> None:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ThinkError("document must be UTF-8") from error
    if "\x00" in text or "TODO" in text or "TBD" in text:
        raise ThinkError("document contains an invalid placeholder")
    if text.count("## 1. Absorption Summary") != 1:
        raise ThinkError("document requires one Absorption Summary")
    if language == "zh":
        missing = [heading for heading in CHINESE_HEADINGS if heading not in text]
        if missing:
            raise ThinkError(f"Chinese document is missing heading: {missing[0]}")
    if require_summary_content:
        match = SUMMARY_RE.search(text)
        if match is None:
            raise ThinkError("document requires one Absorption Summary")
        next_section = NEXT_SECTION_RE.search(text, match.end())
        summary = text[match.end():next_section.start() if next_section else len(text)]
        content = [
            line.strip()
            for line in summary.splitlines()
            if line.strip() and not line.startswith(("### ", ">"))
        ]
        if not content:
            raise ThinkError("Absorption Summary is empty")


def _write_temporary(target: Path, data: bytes, mode: int) -> Path:
    descriptor, name = tempfile.mkstemp(prefix=".MTP_THINK.md.mtp-tmp-", dir=target)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            descriptor = -1
            stream.write(data)
            stream.flush()
            os.fchmod(stream.fileno(), mode)
            os.fsync(stream.fileno())
    except BaseException:
        if descriptor >= 0:
            os.close(descriptor)
        temporary.unlink(missing_ok=True)
        raise
    return temporary


def apply(
    target: Path,
    data: bytes,
    expected_digest: str,
    *,
    ready: bool = False,
    language: str = "zh",
) -> dict[str, Any]:
    target = target.expanduser()
    preview = inspect(target)
    if preview["decision"] == "managed-project":
        raise ThinkError("managed project must route to m-define")
    if preview["source_digest"] != expected_digest:
        raise ThinkError("source digest mismatch")
    validate_document(data, language, require_summary_content=ready)
    source = target / SOURCE_NAME
    mode = stat.S_IMODE(source.stat().st_mode) if source.exists() else 0o644
    temporary = _write_temporary(target, data, mode)
    try:
        current = inspect(target)
        if current.get("source_digest") != expected_digest:
            raise ThinkError("source digest mismatch")
        os.replace(temporary, source)
    finally:
        temporary.unlink(missing_ok=True)
    return {
        "applied": True,
        "route": "m-new" if ready else "m-define",
        "source_digest": _digest(target, source),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Inspect or update one MTP_THINK.md")
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--expect-source-digest")
    parser.add_argument("--ready", action="store_true")
    parser.add_argument("--language", choices=("zh", "other"), default="zh")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        if args.apply:
            if not args.expect_source_digest:
                raise ThinkError("apply requires --expect-source-digest")
            result = apply(
                args.target,
                sys.stdin.buffer.read(),
                args.expect_source_digest,
                ready=args.ready,
                language=args.language,
            )
        else:
            if args.ready or args.expect_source_digest:
                raise ThinkError("apply options require --apply")
            result = inspect(args.target)
    except (OSError, ThinkError, UnicodeDecodeError) as error:
        print(f"invalid-think-source: {error}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    else:
        print(f"{result['decision'] if 'decision' in result else 'updated'}: route={result['route']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
