# 常见问题与解决方案（v3.2.0 更新）

## 模型下载慢与国内镜像（v3.2.0新增专题）

### whisper模型下载速度慢
**通俗解释**：whisper首次运行会下载"语音转文字模型"（相当于下载一个翻译词典），国内网络可能较慢

**症状**：首次运行whisper时卡在下载模型，base模型139MB可能要几分钟

**v3.2.0解决方案**：
1. **一键安装自动加速**：`powershell -File scripts/install_deps.ps1 -Mirror`
   - pip走清华镜像源，whisper模型走hf-mirror.com
2. **手动设置环境变量**：
   ```powershell
   # PowerShell
   $env:HF_ENDPOINT='https://hf-mirror.com'
   python -u scripts/run_all.py --keywords "关键词" --output-dir ./output
   ```
   ```bash
   # Linux/Mac
   export HF_ENDPOINT=https://hf-mirror.com
   python -u scripts/run_all.py --keywords "关键词" --output-dir ./output
   ```
3. **pip安装加速**（单独装Python包）：
   ```bash
   pip install -i https://pypi.tuna.tsinghua.edu.cn/simple openai-whisper websocket-client
   ```

> **下载完一次就不用再下载了**：模型会缓存到本地，后续运行直接使用缓存。

## 下载断线与续传（v3.1.9新增专题）

### 下载中断了怎么办（v3.1.9已自动重试）
**通俗解释**：下载中途网络断了，以前只能手动重新下载；现在脚本自动从断点继续

**症状**：curl下载报错/超时，文件下载一半就停了 → v3.1.9默认自动续传重试3次

**v3.1.9解决方案**：
- `download_audio` 已内置3次续传重试（`curl -C -`断点续传）
- 重试时**不删除部分文件**，而是从断点继续下载
- 每次重试间隔5秒，等待网络恢复
- 新参数 `--dl-retries 3`（默认3次，可调更大）

**调整重试次数**：
```bash
# 一键运行模式
python -u scripts/run_all.py --keywords "关键词" --output-dir ./output --dl-retries 5

# 分步运行模式
python -u scripts/search_and_extract.py --keywords "关键词" --output-dir ./output --dl-retries 5
```

### 下载失败后的手动处理
如果3次续传仍失败（极端网络问题）：
1. 检查网络连接是否恢复
2. 用 `--retry-failed` 或重新运行脚本（已下载文件自动跳过）
3. 删除失败的部分文件后重试：`del output\audio\{vid}.mp4`

## 依赖安装（v3.1.9新增专题）

### 一键安装
```powershell
# 自动检测Python + 安装whisper + websocket-client + 检查ffmpeg
powershell -File scripts/install_deps.ps1
```

### 逐个安装（手动）
```bash
# 1. Python依赖
pip install openai-whisper websocket-client

# 2. ffmpeg（whisper必需）
# Windows: winget install Gyan.FFmpeg
# Mac: brew install ffmpeg
# Linux: apt install ffmpeg

# 3. 如果pip安装whisper报错
# 可能需要先安装: pip install setuptools wheel
# 镜像加速: pip install -i https://pypi.tuna.tsinghua.edu.cn/simple openai-whisper
```

### 安装验证
```bash
python -c "import whisper; print('whisper:', whisper.__version__)"
python -c "import websocket; print('websocket:', websocket.__version__)"
ffmpeg -version  # 应能看到版本号
```

## CDP连接问题

### Chrome启动后CDP WebSocket连接被拒
**症状**：`websocket.create_connection` 失败，或连接后发命令无响应

**通俗解释**：脚本的"遥控器"连不上Chrome浏览器

**根因**：Chrome 111+ 默认限制WebSocket来源，"遥控器"信号被拒绝

**解决**：启动Chrome时必须加 `--remote-allow-origins=*`（相当于"允许所有遥控器连接"）
```powershell
Start-Process chrome -ArgumentList "--remote-debugging-port=9222","--remote-allow-origins=*","--user-data-dir=C:\temp\chrome_debug"
```
> 这是实战中最重要的发现！不加此参数所有CDP操作都会失败。

### "No douyin tab"
- Chrome没开"遥控器模式" → 运行 `start_chrome_debug.ps1`
- Chrome开了但没打开抖音网页 → 手动打开 https://www.douyin.com
- 端口冲突 → 检查9222端口是否被其他Chrome占用
- QClaw shim污染 `python` 命令 → 用 `C:\Python312\python.exe` 直接调用

### WebSocket断开
- Chrome崩溃 → 重启Chrome CDP
- 超时或内存不足 → 检查脚本日志

## 抖音风控

### 验证码拦截（verifycenter）
**通俗解释**：抖音检测到脚本操作，弹出"请证明你是人类"的验证

**症状**：搜索或打开视频后出现验证码页面

**处理流程**：
1. 脚本检测到验证码 → 打印警告 → 自动等待最多120秒
2. 你在Chrome中手动完成验证码（滑块/图片识别）
3. 脚本检测到验证码消失 → 继续执行
4. 如果120秒内未完成 → 跳过当前关键词

**防验证码最佳实践**：
- 关键词间暂停至少30秒（`--pause 30`）
- 视频间暂停至少15秒（`--video-interval 15`）
- 搜索不滚动，只取首页全部视频ID
- 不要频繁搜索敏感关键词
- 如果连续触发验证码 → 等待24小时后再试

### 搜索0结果
- **未登录（最常见）** → Chrome必须先扫码登录抖音，否则搜索页只显示登录弹窗
- 频繁搜索 → 增大 `--pause` 到65-80秒
- 账号限流 → 换账号或等24小时
- 关键词审查 → 换温和关键词
- SPA加载慢 → 搜索页需要等待，不要急于提取ID

### 视频页加载失败
- ID过期/被删 → 脚本标记FAIL跳过
- **需登录** → 确保Chrome已登录抖音
- blob URL不可用 → 必须用Network拦截音频URL

## URL提取

### 提取0个URL
**根因1**：CDP导航前未确认Page.enable → v3.1已自动处理

**根因2**：视频页是SPA，需要更长时间 → 增大 `--extract-timeout` 到20-30秒

**根因3**：`video.src` 是blob URL → 必须用网络请求拦截

**根因4**：页面加载后仍有延迟URL → 加载完成后额外等待5秒

### 下载403
- Referer缺失 → 脚本已内置
- Cookie过期 → 重新登录
- CDN URL过期(>2h) → 重新提取

## 转录

### Python输出不实时（看不到进度）
**根因**：Python输出缓冲（先存起来再一次性显示）

**解决**：用 `python -u` 无缓冲模式运行
```bash
python -u scripts/transcribe_batch.py --audio-dir ./output/audio --output-dir ./output/transcripts --model base
```

### whisper下载模型慢
- base模型139MB，约10秒下载
- medium模型1.42GB，约3-5分钟
- 镜像加速：`export HF_ENDPOINT=https://hf-mirror.com`
- 推荐用base模型，中文够用，速度快

### 转录质量与修正（v3.1.9强化）

**识别率**：whisper base模型中文约85%，常见谐音错误：

| 错误类型 | 示例 | 修正 |
|---------|------|------|
| 谐音替换 | "运营"→"运用" | 语义还原 |
| 术语错识别 | "ROI"→"肉爱" | 行业校验 |
| 繁简混用 | "運營"/"运营" | 统一简体 |
| 数字错 | "30%"→"三百分" | 检查量级 |

**修正方法论**：
1. 语义还原：看整句意思还原错字
2. 行业校验：用术语清单校验
3. 交叉验证：同一观点多源互校
4. 质量优先：先修正high_quality（>500字符）
5. 不确定项用 `[?]` 标注

### 转录速度参考（CPU模式）
| 模型 | 1分钟音频 | 大小 | 中文准确率 | 推荐场景 |
|------|----------|------|-----------|---------|
| tiny | ~5秒 | 39MB | ~60% | 快速预览 |
| **base** | **~30秒** | **139MB** | **~85%** | **日常推荐** |
| small | ~90秒 | 461MB | ~92% | 精确需求 |
| medium | ~180秒 | 1.42GB | ~95% | 学术研究 |

## Windows编码问题

### print输出emoji导致GBK崩溃
**症状**：`UnicodeEncodeError: 'gbk' codec can't encode character`

**根因**：Windows PowerShell默认GBK编码

**解决**：v3.1已将所有emoji替换为ASCII文本（[OK]/[FAIL]/[WARN]）

### Windows下Python stdout乱码
- 用 `python -u` 运行
- 确保脚本文件是UTF-8编码

## QClaw环境问题

### `python` 命令被QClaw shim污染
**通俗解释**：系统里的"python"命令指向了错误程序

**解决**：直接用绝对路径 `C:\Python312\python.exe scripts/xxx.py`

### PowerShell stderr被当成错误
- whisper进度条（stderr）触发PowerShell错误输出
- 不影响功能，可忽略

## 数据恢复

### 进程被kill后数据丢失？
- v3.1每个视频完成后立即保存进度（jsave）
- Ctrl+C不丢当前关键词数据

### 重复下载？
- 跳过已有文件（>1MB视为有效缓存）
- 中断后重跑自动跳过

## Mac/Linux

- curl可能叫curl.exe → 脚本自动检测
- ffmpeg: `brew install ffmpeg` 或 `apt install ffmpeg`
- Chrome路径不同 → 修改start脚本路径
- CDP同样需要 `--remote-allow-origins=*`
