# 抖音知识搜集器 依赖一键安装脚本 v3.2.2
# 用法: powershell -File scripts/install_deps.ps1
#       powershell -File scripts/install_deps.ps1 -Mirror    # 使用国内镜像加速
#
# 安装内容:
#   1. Python依赖: openai-whisper, websocket-client
#   2. ffmpeg（whisper依赖）
#   3. whisper模型下载（可选国内镜像加速）
#   4. 验证安装结果

Write-Host "========================================" -ForegroundColor Cyan
Write-Host " 抖音知识搜集器 依赖安装" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# 检测是否使用国内镜像（-Mirror参数或HF_ENDPOINT环境变量）
$useMirror = $args -contains "-Mirror"
$hfMirror = $env:HF_ENDPOINT
if (-not $hfMirror) { $hfMirror = "https://hf-mirror.com" }
$pipMirror = "https://pypi.tuna.tsinghua.edu.cn/simple"

if ($useMirror) {
    Write-Host "[INFO] 使用国内镜像加速（pip=清华源, whisper=hf-mirror.com）" -ForegroundColor Yellow
    $env:HF_ENDPOINT = $hfMirror
} else {
    Write-Host "[TIP] 如果下载慢，可用国内镜像: powershell -File scripts/install_deps.ps1 -Mirror" -ForegroundColor Yellow
    Write-Host "[TIP] 或设置环境变量: $env:HF_ENDPOINT='https://hf-mirror.com'" -ForegroundColor Yellow
}

# 检测Python
$pythonCmd = $null
$pythonPaths = @("C:\Python312\python.exe", "C:\Python311\python.exe", "C:\Python310\python.exe", "python", "python3")

foreach ($p in $pythonPaths) {
    try {
        $result = & $p --version 2>&1
        if ($result -match "3\.\d+") {
            $pythonCmd = $p
            Write-Host "[OK] 找到Python: $p ($result)" -ForegroundColor Green
            break
        }
    } catch {
        continue
    }
}

if (-not $pythonCmd) {
    Write-Host "[FAIL] 未找到Python 3.10+！请先安装Python" -ForegroundColor Red
    Write-Host "  下载: https://www.python.org/downloads/" -ForegroundColor Yellow
    exit 1
}

# 安装Python依赖
Write-Host "`n[STEP 1] 安装Python依赖..." -ForegroundColor Cyan
if ($useMirror) {
    & $pythonCmd -m pip install --upgrade -i $pipMirror openai-whisper websocket-client
} else {
    & $pythonCmd -m pip install --upgrade openai-whisper websocket-client
}
Write-Host "[OK] Python依赖安装完成" -ForegroundColor Green

# 检查ffmpeg
Write-Host "`n[STEP 2] 检查ffmpeg..." -ForegroundColor Cyan
$ffmpeg = Get-Command ffmpeg -ErrorAction SilentlyContinue
if (-not $ffmpeg) {
    $ffmpegExe = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
}

if ($ffmpeg -or $ffmpegExe) {
    Write-Host "[OK] ffmpeg已安装" -ForegroundColor Green
} else {
    Write-Host "[WARN] ffmpeg未安装！whisper需要ffmpeg" -ForegroundColor Yellow
    Write-Host "  安装方式:" -ForegroundColor Yellow
    Write-Host "    winget install Gyan.FFmpeg" -ForegroundColor White
    Write-Host "    或手动下载: https://www.gyan.dev/ffmpeg/builds/" -ForegroundColor White
    Write-Host "`n  是否现在用winget安装ffmpeg？(Y/N)" -ForegroundColor Yellow
    $answer = Read-Host
    if ($answer -eq "Y" -or $answer -eq "y") {
        winget install Gyan.FFmpeg
    }
}

# 验证
Write-Host "`n[STEP 3] 验证安装..." -ForegroundColor Cyan
& $pythonCmd -c "import whisper; print('[OK] whisper:', whisper.__version__)"
& $pythonCmd -c "import websocket; print('[OK] websocket-client:', websocket.__version__)"

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host " 安装完成！" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "`n下一步: 启动Chrome CDP并登录抖音" -ForegroundColor White
Write-Host "  powershell -File scripts/start_chrome_debug.ps1" -ForegroundColor White
