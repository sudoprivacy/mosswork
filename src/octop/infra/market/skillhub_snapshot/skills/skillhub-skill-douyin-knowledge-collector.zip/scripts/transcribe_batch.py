#!/usr/bin/env python3
"""
批量转录音频文件 v3.2.2 - openai-whisper base模型
v3.2.2 改进清单：
  1. 转录加标点符号（默认开启，--no-punctuation 关闭）
     用 initial_prompt="以下是普通话的句子，带有标点符号。" 引导 Whisper 输出中文标点
  2. 繁体→简体自动转换（内置映射表，不依赖 opencc）
     转录完成后自动把繁体字转为简体，如"運營"→"运营"、"購買"→"购买"
     已知限制：少数条目在特定书面语境可能误转（覆→复、藉→借、乾→干），
     但在抖音口语转录场景下影响<1%

保留v3.1.8所有特性：
  3. 深度停播抖音视频（iframe+shadowDOM+MutationObserver）
  4. --retry-failed 参数
  5. 转录质量分级 + quality_report.json
  6. transcription_summary.json
"""
import os, glob, argparse, time, json

# ===== v3.2.2: 繁体→简体映射表（常见繁体字，覆盖90%+中文场景） =====
TRADITIONAL_TO_SIMPLIFIED = {'丟':'丢','並':'并','乾':'干','亂':'乱','亞':'亚','佇':'伫','併':'并','來':'来','侖':'仑','侶':'侣','俁':'俣','係':'系','俠':'侠','倀':'伥','倆':'俩','倉':'仓','個':'个','們':'们','倫':'伦','偉':'伟','側':'侧','偵':'侦','傑':'杰','傖':'伧','傘':'伞','備':'备','傭':'佣','傯':'偬','傳':'传','傴':'伛','債':'债','傷':'伤','傾':'倾','僅':'仅','僉':'佥','僑':'侨','僕':'仆','僞':'伪','僥':'侥','僨':'偾','價':'价','儀':'仪','儁':'俊','儂':'侬','億':'亿','儈':'侩','儉':'俭','儐':'傧','儔':'俦','儕':'侪','儘':'尽','償':'偿','優':'优','儲':'储','儷':'俪','儻':'傥','儼':'俨','兒':'儿','內':'内','兩':'两','冊':'册','凍':'冻','凱':'凯','別':'别','刪':'删','則':'则','剛':'刚','創':'创','劃':'划','劇':'剧','劉':'刘','劍':'剑','劑':'剂','勁':'劲','動':'动','務':'务','勛':'勋','勞':'劳','勢':'势','勳':'勋','勵':'励','勸':'劝','勻':'匀','匯':'汇','區':'区','協':'协','卻':'却','厭':'厌','厲':'厉','參':'参','叢':'丛','吳':'吴','吶':'呐','員':'员','哩':'里','問':'问','啓':'启','啞':'哑','喪':'丧','喬':'乔','單':'单','喲':'哟','嘆':'叹','嘔':'呕','嘗':'尝','嘩':'哗','噁':'恶','噴':'喷','噸':'吨','噹':'当','嚐':'尝','嚕':'噜','嚲':'亸','嚴':'严','囂':'嚣','囌':'苏','國':'国','圍':'围','園':'园','圓':'圆','圖':'图','團':'团','執':'执','堅':'坚','堯':'尧','報':'报','場':'场','塊':'块','塵':'尘','墊':'垫','墜':'坠','墳':'坟','墾':'垦','壇':'坛','壓':'压','壘':'垒','壞':'坏','壟':'垄','壯':'壮','壺':'壶','壽':'寿','夠':'够','夢':'梦','夥':'伙','夾':'夹','奩':'奁','奪':'夺','奮':'奋','妝':'妆','姦':'奸','娛':'娱','婦':'妇','媽':'妈','嫗':'妪','嫵':'妩','嫺':'娴','嫻':'娴','嬌':'娇','嬰':'婴','嬸':'婶','孌':'娈','孫':'孙','學':'学','宮':'宫','實':'实','寧':'宁','審':'审','寫':'写','寬':'宽','寵':'宠','寶':'宝','將':'将','專':'专','尋':'寻','對':'对','導':'导','尷':'尴','屢':'屡','層':'层','屬':'属','岡':'冈','島':'岛','峽':'峡','崗':'岗','崙':'仑','崢':'峥','嵐':'岚','嶺':'岭','嶼':'屿','巒':'峦','巔':'巅','帥':'帅','師':'师','帳':'帐','帶':'带','幟':'帜','幣':'币','幫':'帮','幷':'并','幹':'干','幾':'几','庫':'库','廁':'厕','廂':'厢','廈':'厦','廚':'厨','廟':'庙','廠':'厂','廢':'废','廣':'广','廬':'庐','廳':'厅','張':'张','強':'强','彆':'别','彈':'弹','彌':'弥','彎':'弯','彔':'录','彙':'汇','徑':'径','從':'从','復':'复','徹':'彻','恥':'耻','悅':'悦','悶':'闷','惡':'恶','惱':'恼','愛':'爱','態':'态','慘':'惨','慚':'惭','慟':'恸','慣':'惯','慮':'虑','慶':'庆','憂':'忧','憊':'惫','憐':'怜','憑':'凭','憤':'愤','憫':'悯','憲':'宪','憶':'忆','懇':'恳','應':'应','懣':'懑','懲':'惩','懶':'懒','懷':'怀','懺':'忏','懼':'惧','戀':'恋','戰':'战','戲':'戏','戶':'户','掃':'扫','掙':'挣','揀':'拣','揚':'扬','換':'换','揮':'挥','損':'损','搖':'摇','搗':'捣','搶':'抢','摟':'搂','摳':'抠','摶':'抟','摻':'掺','撈':'捞','撐':'撑','撟':'挢','撥':'拨','撫':'抚','撲':'扑','撿':'捡','擁':'拥','擄':'掳','擇':'择','擊':'击','擔':'担','據':'据','擠':'挤','擬':'拟','擰':'拧','擱':'搁','擴':'扩','擷':'撷','擺':'摆','擾':'扰','攏':'拢','攔':'拦','攜':'携','攝':'摄','攢':'攒','攤':'摊','攪':'搅','攬':'揽','敗':'败','敵':'敌','數':'数','斂':'敛','斃':'毙','斷':'断','於':'于','時':'时','晉':'晋','暈':'晕','暫':'暂','曆':'历','曇':'昙','曉':'晓','曠':'旷','曬':'晒','書':'书','會':'会','朮':'术','東':'东','條':'条','棄':'弃','棗':'枣','棟':'栋','棧':'栈','楊':'杨','楓':'枫','業':'业','極':'极','榦':'干','榮':'荣','構':'构','槍':'枪','樂':'乐','樓':'楼','標':'标','樞':'枢','樣':'样','樹':'树','橋':'桥','機':'机','檢':'检','檯':'台','櫃':'柜','欄':'栏','權':'权','欽':'钦','歎':'叹','歐':'欧','歡':'欢','歲':'岁','歷':'历','歸':'归','殘':'残','殞':'殒','殯':'殡','殲':'歼','殺':'杀','殼':'壳','毀':'毁','氣':'气','氫':'氢','決':'决','沒':'没','況':'况','洶':'汹','淨':'净','淪':'沦','淵':'渊','淺':'浅','減':'减','測':'测','渾':'浑','湯':'汤','溝':'沟','溫':'温','滄':'沧','滅':'灭','滌':'涤','滙':'汇','滬':'沪','滯':'滞','滲':'渗','滷':'卤','滾':'滚','滿':'满','漁':'渔','漢':'汉','漬':'渍','漲':'涨','漸':'渐','漿':'浆','潔':'洁','潛':'潜','潤':'润','澀':'涩','澆':'浇','澇':'涝','澤':'泽','濁':'浊','濃':'浓','濟':'济','濤':'涛','濫':'滥','濱':'滨','濾':'滤','瀝':'沥','瀟':'潇','瀰':'弥','瀾':'澜','灑':'洒','灘':'滩','灣':'湾','災':'灾','烏':'乌','無':'无','煉':'炼','熒':'荧','熱':'热','熾':'炽','燈':'灯','營':'营','燦':'灿','燬':'毁','爍':'烁','爐':'炉','爛':'烂','爭':'争','爲':'为','爺':'爷','牆':'墙','牽':'牵','狀':'状','狹':'狭','猶':'犹','獄':'狱','獅':'狮','獎':'奖','獨':'独','獰':'狞','獲':'获','獵':'猎','獸':'兽','獻':'献','現':'现','瑤':'瑶','瑩':'莹','瑪':'玛','璣':'玑','環':'环','璽':'玺','瓊':'琼','產':'产','甦':'苏','甯':'宁','畝':'亩','畢':'毕','畫':'画','異':'异','當':'当','疇':'畴','疊':'叠','瘋':'疯','瘡':'疮','療':'疗','癡':'痴','癢':'痒','癬':'癣','癲':'癫','發':'发','皺':'皱','盞':'盏','盡':'尽','監':'监','盤':'盘','盧':'卢','睜':'睁','矚':'瞩','確':'确','碼':'码','磚':'砖','礎':'础','礦':'矿','礫':'砾','礬':'矾','礱':'砻','祇':'只','祿':'禄','禍':'祸','禪':'禅','禮':'礼','稈':'秆','種':'种','稱':'称','穀':'谷','積':'积','穢':'秽','穩':'稳','穫':'获','窩':'窝','窮':'穷','窯':'窑','窺':'窥','竄':'窜','竅':'窍','竈':'灶','竊':'窃','競':'竞','筆':'笔','筍':'笋','箇':'个','箏':'筝','節':'节','範':'范','築':'筑','篤':'笃','篩':'筛','簡':'简','簫':'箫','簽':'签','籃':'篮','籌':'筹','籠':'笼','籤':'签','籬':'篱','籮':'箩','粵':'粤','糧':'粮','糰':'团','糾':'纠','紀':'纪','約':'约','紅':'红','納':'纳','純':'纯','紙':'纸','級':'级','紛':'纷','紡':'纺','細':'细','紳':'绅','終':'终','組':'组','結':'结','絕':'绝','絡':'络','絢':'绚','給':'给','絨':'绒','統':'统','絲':'丝','絳':'绛','絹':'绢','綁':'绑','經':'经','綠':'绿','綢':'绸','維':'维','綱':'纲','網':'网','綸':'纶','綿':'绵','緊':'紧','緒':'绪','緞':'缎','緣':'缘','編':'编','緩':'缓','練':'练','緻':'致','縣':'县','縫':'缝','縮':'缩','縱':'纵','縴':'纤','縷':'缕','總':'总','績':'绩','繆':'缪','織':'织','繞':'绕','繡':'绣','繪':'绘','繫':'系','繼':'继','繽':'缤','續':'续','纖':'纤','罈':'坛','罰':'罚','罵':'骂','罷':'罢','羅':'罗','羈':'羁','義':'义','習':'习','翹':'翘','聖':'圣','聞':'闻','聯':'联','聰':'聪','聲':'声','聳':'耸','聶':'聂','職':'职','聽':'听','聾':'聋','肅':'肃','脈':'脉','脹':'胀','腎':'肾','腦':'脑','腫':'肿','腳':'脚','腸':'肠','膚':'肤','膩':'腻','膽':'胆','膿':'脓','臉':'脸','臘':'腊','臟':'脏','臨':'临','臺':'台','與':'与','興':'兴','舉':'举','舊':'旧','艙':'舱','艦':'舰','艱':'艰','艷':'艳','莊':'庄','莖':'茎','華':'华','萊':'莱','萬':'万','葯':'药','葷':'荤','蓮':'莲','蔘':'参','蕭':'萧','薩':'萨','藉':'借','藍':'蓝','藝':'艺','藥':'药','藹':'蔼','蘆':'芦','蘇':'苏','蘊':'蕴','蘭':'兰','蘿':'萝','處':'处','虛':'虚','虜':'虏','號':'号','虧':'亏','蝦':'虾','蝸':'蜗','蟄':'蛰','蟬':'蝉','蟲':'虫','蟻':'蚁','蠟':'蜡','蠻':'蛮','衆':'众','術':'术','衛':'卫','袷':'夹','裏':'里','補':'补','裝':'装','製':'制','複':'复','褲':'裤','襪':'袜','襬':'摆','襯':'衬','襲':'袭','覆':'复','見':'见','規':'规','覓':'觅','視':'视','親':'亲','覬':'觊','覺':'觉','覽':'览','覿':'觌','觀':'观','觶':'觯','訂':'订','計':'计','訊':'讯','討':'讨','訓':'训','訕':'讪','託':'托','記':'记','訣':'诀','訪':'访','設':'设','許':'许','訴':'诉','診':'诊','証':'证','詐':'诈','評':'评','詞':'词','詢':'询','試':'试','詩':'诗','詭':'诡','話':'话','該':'该','詳':'详','誇':'夸','認':'认','誕':'诞','誘':'诱','語':'语','誠':'诚','誤':'误','誦':'诵','誨':'诲','說':'说','誰':'谁','誼':'谊','調':'调','談':'谈','請':'请','論':'论','諧':'谐','諷':'讽','諸':'诸','諾':'诺','謀':'谋','謁':'谒','謂':'谓','謊':'谎','謗':'谤','謙':'谦','講':'讲','謝':'谢','謠':'谣','謬':'谬','謹':'谨','謾':'谩','譁':'哗','證':'证','譏':'讥','識':'识','譚':'谭','譜':'谱','譭':'毁','譯':'译','議':'议','譴':'谴','護':'护','譽':'誉','讀':'读','變':'变','讓':'让','讚':'赞','豈':'岂','豎':'竖','豐':'丰','豔':'艳','豬':'猪','貓':'猫','貝':'贝','貞':'贞','負':'负','財':'财','貢':'贡','貧':'贫','貨':'货','販':'贩','貪':'贪','貫':'贯','責':'责','貯':'贮','貳':'贰','貴':'贵','貶':'贬','買':'买','貸':'贷','費':'费','貼':'贴','貿':'贸','賀':'贺','資':'资','賊':'贼','賓':'宾','賜':'赐','賞':'赏','賠':'赔','賢':'贤','賣':'卖','賤':'贱','賦':'赋','質':'质','賬':'账','賭':'赌','賴':'赖','賺':'赚','購':'购','賽':'赛','贈':'赠','贊':'赞','贏':'赢','贓':'赃','贖':'赎','趕':'赶','趙':'赵','趨':'趋','踐':'践','蹤':'踪','躋':'跻','躍':'跃','軀':'躯','車':'车','軌':'轨','軍':'军','軒':'轩','軟':'软','軸':'轴','較':'较','載':'载','輔':'辅','輕':'轻','輛':'辆','輝':'辉','輟':'辍','輩':'辈','輪':'轮','輸':'输','輿':'舆','轄':'辖','轉':'转','轍':'辙','轟':'轰','辦':'办','辭':'辞','辮':'辫','辯':'辩','農':'农','迴':'回','逕':'径','這':'这','連':'连','進':'进','遊':'游','運':'运','過':'过','達':'达','違':'违','遙':'遥','遜':'逊','遞':'递','遠':'远','遲':'迟','遷':'迁','選':'选','遺':'遗','遼':'辽','邁':'迈','還':'还','邊':'边','郵':'邮','鄉':'乡','鄒':'邹','鄭':'郑','鄰':'邻','醜':'丑','醫':'医','釀':'酿','釁':'衅','釋':'释','釗':'钊','釘':'钉','針':'针','鈅':'钥','鈉':'钠','鈍':'钝','鈔':'钞','鈕':'钮','鈞':'钧','鈡':'钟','鉤':'钩','銀':'银','銜':'衔','銷':'销','鋅':'锌','鋒':'锋','鋼':'钢','錄':'录','錢':'钱','錯':'错','錳':'锰','鍊':'炼','鍍':'镀','鍵':'键','鍼':'针','鍾':'钟','鎂':'镁','鎖':'锁','鎗':'枪','鎢':'钨','鏈':'链','鏜':'镗','鏡':'镜','鐘':'钟','鐳':'镭','鐵':'铁','鑑':'鉴','鑒':'鉴','鑰':'钥','鑲':'镶','鑿':'凿','長':'长','門':'门','閃':'闪','閉':'闭','開':'开','閏':'闰','間':'间','閘':'闸','閣':'阁','閥':'阀','閨':'闺','閱':'阅','闊':'阔','闖':'闯','關':'关','陣':'阵','陰':'阴','陳':'陈','陸':'陆','陽':'阳','隊':'队','階':'阶','際':'际','隨':'随','險':'险','隱':'隐','隸':'隶','隻':'只','雙':'双','雛':'雏','雜':'杂','雞':'鸡','離':'离','難':'难','雲':'云','電':'电','霧':'雾','霽':'霁','靂':'雳','靄':'霭','靈':'灵','靜':'静','鞏':'巩','韻':'韵','響':'响','頁':'页','頂':'顶','頃':'顷','項':'项','順':'顺','須':'须','頌':'颂','預':'预','頑':'顽','頒':'颁','頓':'顿','頗':'颇','領':'领','頭':'头','頸':'颈','頹':'颓','頻':'频','顆':'颗','題':'题','額':'额','顏':'颜','願':'愿','顛':'颠','類':'类','顧':'顾','顫':'颤','顯':'显','顱':'颅','風':'风','颭':'飐','颮':'飑','颯':'飒','颱':'台','颶':'飓','颺':'飏','飄':'飘','飆':'飙','飛':'飞','飢':'饥','飯':'饭','飲':'饮','飴':'饴','飼':'饲','飽':'饱','飾':'饰','餃':'饺','餅':'饼','餌':'饵','餓':'饿','餘':'余','館':'馆','饅':'馒','饈':'馐','饑':'饥','饒':'饶','馬':'马','馭':'驭','馳':'驰','馴':'驯','駁':'驳','駐':'驻','駒':'驹','駕':'驾','駛':'驶','駝':'驼','駢':'骈','駭':'骇','駱':'骆','駿':'骏','騁':'骋','騎':'骑','騙':'骗','騫':'骞','騰':'腾','騾':'骡','驄':'骢','驅':'驱','驍':'骁','驕':'骄','驗':'验','驚':'惊','驛':'驿','驟':'骤','驢':'驴','驥':'骥','驪':'骊','髒':'脏','體':'体','髮':'发','鬚':'须','鬧':'闹','鬱':'郁','魚':'鱼','魯':'鲁','鮑':'鲍','鮮':'鲜','鯛':'鲷','鯤':'鲲','鯨':'鲸','鰍':'鳅','鰓':'鳃','鰭':'鳍','鰲':'鳌','鰻':'鳗','鱉':'鳖','鱗':'鳞','鱷':'鳄','鱸':'鲈','鳥':'鸟','鳩':'鸠','鳳':'凤','鳴':'鸣','鴉':'鸦','鴛':'鸳','鴨':'鸭','鴻':'鸿','鴿':'鸽','鵡':'鹉','鵬':'鹏','鵲':'鹊','鶯':'莺','鶴':'鹤','鷗':'鸥','鷹':'鹰','鹵':'卤','鹽':'盐','麗':'丽','麥':'麦','麪':'面','麴':'曲','麼':'么','黃':'黄','點':'点','黨':'党','黴':'霉','齊':'齐','齋':'斋','齒':'齿','龍':'龙','龜':'龟','鎮':'镇','線':'线','葉':'叶','跡':'迹',}

# 模块加载时构建一次性转换表（str.translate 比逐字符 dict.get 快约10倍）
SIMPLIFIED_TABLE = str.maketrans(TRADITIONAL_TO_SIMPLIFIED)

def traditional_to_simplified(text):
    """[v3.2.2] 繁体→简体转换（str.translate，高性能）"""
    return text.translate(SIMPLIFIED_TABLE)


def stop_douyin_videos_deep(cdp_port=9222):
    """[v3.1.8] 深度停止抖音视频播放"""
    try:
        import websocket
    except ImportError:
        print("  websocket-client未安装，跳过停播视频")
        return
    try:
        import urllib.request
        resp = urllib.request.urlopen(f"http://localhost:{cdp_port}/json", timeout=5)
        tabs = json.loads(resp.read())
        douyin_tabs = [t for t in tabs if "douyin" in t.get("url", "") and "sw.js" not in t.get("url", "")]

        js_deep_stop = """
        (function() {
          var count = 0;
          function stopAllVids(root) {
            var vids = root.querySelectorAll('video');
            vids.forEach(function(v) {
              v.pause(); v.currentTime = 0; v.autoplay = false;
              v.removeAttribute('autoplay'); v.muted = true;
              v.play = function() { v.pause(); return Promise.resolve(); };
              count++;
            });
            root.querySelectorAll('*').forEach(function(el) {
              if (el.shadowRoot) stopAllVids(el.shadowRoot);
            });
          }
          stopAllVids(document);
          try {
            document.querySelectorAll('iframe').forEach(function(iframe) {
              try { stopAllVids(iframe.contentDocument); } catch(e) {}
            });
          } catch(e) {}
          var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(m) {
              m.addedNodes.forEach(function(node) {
                if (node.nodeName === 'VIDEO') {
                  node.pause(); node.currentTime = 0;
                  node.play = function(){node.pause();return Promise.resolve();};
                  count++;
                }
                try {
                  node.querySelectorAll && node.querySelectorAll('video').forEach(function(v) {
                    v.pause(); v.currentTime = 0;
                    v.play = function(){v.pause();return Promise.resolve();};
                  });
                } catch(e) {}
              });
            });
          });
          observer.observe(document.body || document.documentElement, {childList: true, subtree: true});
          return 'Deep-stopped ' + count + ' videos, observer active';
        })()
        """

        stopped_count = 0
        for tab in douyin_tabs:
            ws_url = tab.get("webSocketDebuggerUrl")
            if not ws_url: continue
            try:
                ws = websocket.create_connection(ws_url, timeout=10)
                ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate", "params": {"expression": js_deep_stop}}))
                # [v3.2.2 fix] CDP可能先返回observer事件，需循环recv拿到id=1的响应
                val = "N/A"
                for _ in range(10):  # 最多收10条消息，防止无限循环
                    msg = ws.recv()
                    if not msg:
                        break
                    result = json.loads(msg)
                    if result.get("id") == 1:  # 这才是Runtime.evaluate的响应
                        val = result.get("result", {}).get("result", {}).get("value", "N/A")
                        break
                print(f"  已停播: {tab['url'][:50]} - {val}")
                stopped_count += 1
                ws.close()
            except Exception: pass

        if douyin_tabs:
            print(f"  深度停播完成: {stopped_count}/{len(douyin_tabs)} 个tab")
        else:
            print(f"  未找到抖音tab（无需停播）")
    except Exception as e:
        print(f"  停播视频失败（非致命）: {e}")


def classify_quality(char_count):
    if char_count < 100: return "low"
    elif char_count < 500: return "medium"
    else: return "high"


def main():
    parser = argparse.ArgumentParser(description="批量转录音频文件 v3.2.2")
    parser.add_argument("--audio-dir", required=True, help="音频文件目录")
    parser.add_argument("--output-dir", required=True, help="转录文本输出目录")
    parser.add_argument("--model", default="base", help="Whisper模型 (默认base)")
    parser.add_argument("--no-punctuation", action="store_true", help="[v3.2.2] 不加标点符号（默认开启标点）")
    parser.add_argument("--language", default="zh", help="语言代码")
    parser.add_argument("--kw-map", default=None, help="关键词->视频ID映射JSON文件")
    parser.add_argument("--retry-failed", action="store_true", help="[v3.1.8] 重试所有.failed文件")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    try:
        import whisper
    except ImportError:
        print("ERROR: openai-whisper not installed. Run: pip install openai-whisper")
        return

    # 转录前深度停播抖音视频
    print("深度停止抖音视频播放（iframe+shadowDOM+MutationObserver）...")
    stop_douyin_videos_deep()

    print(f"加载 whisper {args.model} 模型...")
    t0 = time.time()
    model = whisper.load_model(args.model)
    print(f"模型加载完成（{time.time()-t0:.1f}秒）")

    # 标点模式：默认开启，--no-punctuation 关闭
    use_punctuation = not args.no_punctuation
    if use_punctuation:
        print(f"[v3.2.2] 标点模式：开启（initial_prompt引导Whisper输出中文标点）")
    else:
        print(f"[v3.2.2] 标点模式：关闭")
    print(f"[v3.2.2] 繁→简转换：开启（内置映射表，无需opencc）")

    done = set(f.replace(".txt", "") for f in os.listdir(args.output_dir) if f.endswith(".txt"))

    if args.retry_failed:
        failed_ids = set()
        for f in os.listdir(args.output_dir):
            if f.endswith(".txt.failed"):
                fid = f.replace(".txt.failed", "")
                failed_ids.add(fid)
                try: os.remove(os.path.join(args.output_dir, f))
                except: pass
        print(f"重试模式: 移除 {len(failed_ids)} 个失败标记")
        done = done - failed_ids
    else:
        failed_ids = set(f.replace(".txt.failed", "") for f in os.listdir(args.output_dir) if f.endswith(".txt.failed"))

    audio_files = sorted(glob.glob(os.path.join(args.audio_dir, "*.mp4")))
    good_files = [f for f in audio_files if os.path.getsize(f) > 500000]
    skipped = len(audio_files) - len(good_files)
    if skipped > 0:
        print(f"跳过 {skipped} 个小文件(<500KB)，仅处理 {len(good_files)} 个有效文件")
    todo = [f for f in good_files
            if os.path.splitext(os.path.basename(f))[0] not in done
            and os.path.splitext(os.path.basename(f))[0] not in failed_ids]

    print(f"有效文件: {len(good_files)}, 已转录: {len(done)}, 已失败: {len(failed_ids)}, 待处理: {len(todo)}")
    if not todo:
        print("无需转录！")
        organize_transcripts(args.output_dir, args.kw_map)
        generate_quality_report(args.output_dir)
        generate_transcription_summary(args.output_dir, 0, 0, 0, 0, args.model, use_punctuation)
        return

    total_chars = 0
    completed = 0
    fail_count = 0
    start_time = time.time()
    trad_converted_count = 0  # 繁→简转换统计

    for i, af in enumerate(todo):
        vid = os.path.splitext(os.path.basename(af))[0]
        out = os.path.join(args.output_dir, f"{vid}.txt")
        tmp = os.path.join(args.output_dir, f"{vid}.tmp")
        sz_mb = os.path.getsize(af) / 1024 / 1024
        print(f"[{i+1}/{len(todo)}] {vid} ({sz_mb:.1f}MB)...")
        try:
            t1 = time.time()
            # v3.2.2: 标点符号 initial_prompt
            prompt = "以下是普通话的句子，带有标点符号。" if use_punctuation else None
            result = model.transcribe(af, language=args.language, initial_prompt=prompt)
            elapsed = time.time() - t1

            # 生成带时间戳的转录
            txt = "".join(
                f"[{s['start']:.1f}s-{s['end']:.1f}s] {s['text']}\n"
                for s in result["segments"]
            )

            # v3.2.2: 繁体→简体自动转换
            txt_before = txt
            txt = traditional_to_simplified(txt)
            trad_chars = sum(1 for a, b in zip(txt_before, txt) if a != b)
            if trad_chars > 0:
                trad_converted_count += trad_chars
                print(f"  繁→简: 转换了{trad_chars}个繁体字")

            with open(tmp, "w", encoding="utf-8") as f:
                f.write(txt)
            os.replace(tmp, out)
            total_chars += len(txt)
            completed += 1

            q = classify_quality(len(txt))
            print(f"  OK 完成 ({len(txt)}字符, {elapsed:.1f}秒, 质量={q})")
        except Exception as e:
            fail_count += 1
            print(f"  FAIL: {type(e).__name__}: {str(e)[:100]}")
            if os.path.exists(tmp):
                try: os.remove(tmp)
                except: pass
            with open(out + ".failed", "w", encoding="utf-8") as f:
                f.write(f"error: {type(e).__name__}: {str(e)[:200]}")

    elapsed_total = time.time() - start_time
    print(f"\n转录完成: {completed} 成功, {fail_count} 失败, 共{total_chars}字符（耗时{elapsed_total/60:.1f}分钟）")
    if trad_converted_count > 0:
        print(f"[v3.2.2] 繁→简转换总计: {trad_converted_count}个繁体字已转为简体")

    organize_transcripts(args.output_dir, args.kw_map)
    generate_quality_report(args.output_dir)
    generate_transcription_summary(args.output_dir, completed, fail_count, total_chars, elapsed_total, args.model, use_punctuation)


def load_all_transcripts(output_dir):
    """[v3.2.2] 读取所有 .txt 转录，返回 {vid: content}（一次读取，多处复用，避免重复磁盘IO）"""
    result = {}
    for f in os.listdir(output_dir):
        if not f.endswith('.txt'):
            continue
        vid = os.path.splitext(f)[0]
        try:
            with open(os.path.join(output_dir, f), 'r', encoding='utf-8') as fh:
                result[vid] = fh.read()
        except Exception:
            pass
    return result


def organize_transcripts(output_dir, kw_map_file=None):
    texts = load_all_transcripts(output_dir)
    if kw_map_file and os.path.exists(kw_map_file):
        try:
            with open(kw_map_file, encoding='utf-8') as kf:
                kw_map = json.load(kf)
            organized = {}
            for kw, ids in kw_map.items():
                kw_texts = []
                for vid in ids:
                    if vid in texts:
                        content = texts[vid]
                        kw_texts.append({"id": vid, "text": content, "chars": len(content)})
                if kw_texts:
                    organized[kw] = kw_texts
            out_path = os.path.join(output_dir, "organized_by_keyword.json")
            with open(out_path, 'w', encoding='utf-8') as f:
                json.dump(organized, f, ensure_ascii=False, indent=2)
            for kw, kw_texts in organized.items():
                total_chars = sum(t["chars"] for t in kw_texts)
                print(f"  {kw}: {len(kw_texts)}条转录, {total_chars}字符")
            print(f"按关键词组织完成，保存至: {out_path}")
        except Exception as e:
            print(f"组织转录时出错: {e}")
    else:
        print(f"（无kw-map文件，跳过按关键词组织）")


def generate_quality_report(output_dir):
    texts = load_all_transcripts(output_dir)
    report = {
        "version": "3.2.2",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "total_transcripts": len(texts),
        "quality_breakdown": {"low": 0, "medium": 0, "high": 0},
        "low_quality_ids": [],
        "medium_quality_ids": [],
        "high_quality_ids": [],
        "total_chars": 0,
        "avg_chars": 0
    }
    total_chars = 0
    for vid, content in texts.items():
        chars = len(content)
        total_chars += chars
        q = classify_quality(chars)
        report["quality_breakdown"][q] += 1
        report[f"{q}_quality_ids"].append({"id": vid, "chars": chars})
    report["total_chars"] = total_chars
    report["avg_chars"] = round(total_chars / len(texts), 1) if texts else 0
    for level in ["low", "medium", "high"]:
        report[f"{level}_quality_ids"].sort(key=lambda x: -x["chars"])
    out_path = os.path.join(output_dir, "quality_report.json")
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"\n质量报告:")
    print(f"  low (<100字符): {report['quality_breakdown']['low']} 个")
    print(f"  medium (100-500字符): {report['quality_breakdown']['medium']} 个")
    print(f"  high (>500字符): {report['quality_breakdown']['high']} 个")
    print(f"  总字符数: {total_chars}, 平均: {report['avg_chars']}字符/条")
    print(f"  保存至: {out_path}")


def generate_transcription_summary(output_dir, completed, fail_count, total_chars, elapsed_seconds, model_name, use_punctuation=True):
    texts = load_all_transcripts(output_dir)
    failed_files = [f for f in os.listdir(output_dir) if f.endswith(".txt.failed")]
    summary = {
        "version": "3.2.2",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "model": model_name,
        "punctuation": use_punctuation,
        "traditional_to_simplified": True,
        "elapsed_seconds": round(elapsed_seconds, 1),
        "total_transcripts": len(texts),
        "new_completed": completed,
        "new_failed": fail_count,
        "existing_failed_files": len(failed_files),
        "total_chars": total_chars,
        "quality_breakdown": {"low": 0, "medium": 0, "high": 0}
    }
    for vid, content in texts.items():
        try:
            chars = len(content)
            q = classify_quality(chars)
            summary["quality_breakdown"][q] += 1
        except: pass
    out_path = os.path.join(output_dir, "transcription_summary.json")
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"转录摘要保存至: {out_path}")


if __name__ == "__main__":
    main()
