#!/usr/bin/env python3
"""
抖音视频搜索+URL提取+下载脚本 v3.2.2
基于外卖行业实战（8关键词，5/8成功，2因CDP断连丢失）的全面改进：

v3.2.0 改进清单：
  1. 国内镜像源加速（install_deps.ps1 -Mirror，pip清华源+whisper hf-mirror）
      - T(4.8)："下载语音转文字模型时可能稍慢"
  2. 触发词扩充（5→9个）
      - 适用性："触发词选择比较单一"

v3.1.9 改进清单：
  1. CDP WebSocket断连重试（3次，每次重新获取tab/ws_url）
  2. 搜索页智能加载检测（Page.loadEventFired + 最多30秒轮询）
  3. kw_map.json自动生成（搜索过程中自动产出关键词→视频ID映射）
  4. 搜索去重报告（每关键词打印新ID占比，新增<3提示换词）
  5. CDP健康检查（脚本启动前检测Chrome+抖音tab是否可用）
  6. 采集摘要自动生成（collection_summary.json）
  7. 深度停播抖音视频（iframe+shadowDOM+MutationObserver，转录前自动执行）
  8. 转录质量分级+quality_report.json自动生成
  9. --retry-failed参数（transcribe_batch.py）

保留v3.1.4所有特性：
  - 搜索页不滚动，取首页全部视频
  - 关键词间随机20-40秒等待
  - 验证码检测+自动等待
  - 已下载文件智能跳过
  - 大文件跳过下载选项
"""
import json, time, urllib.request, urllib.parse, argparse, os, subprocess, websocket, sys, random

def jload(path, fallback_type="dict"):
    """加载JSON文件，不存在时返回空dict或空list"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {} if fallback_type == "dict" else []

def jsave(path, data):
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def get_tabs(port, timeout=5):
    try:
        req = urllib.request.Request(f"http://localhost:{port}/json")
        return json.loads(urllib.request.urlopen(req, timeout=timeout).read())
    except Exception:
        return []

def find_douyin(ts):
    for t in ts:
        if "douyin.com" in t.get("url", "") and t.get("type") == "page":
            return t
    return None

def check_cdp_health(port):
    """[v3.1.8新增] 脚本启动前检测CDP健康状态"""
    # 1. 检查CDP端口是否可连
    try:
        req = urllib.request.Request(f"http://localhost:{port}/json")
        tabs = json.loads(urllib.request.urlopen(req, timeout=5).read())
    except Exception:
        print("[FAIL] Chrome CDP无法连接！请检查：")
        print("  1. Chrome是否以 --remote-debugging-port=9222 启动")
        print("  2. 是否加了 --remote-allow-origins=* 参数")
        print("  3. Chrome是否正在运行")
        return False
    
    # 2. 检查是否有抖音tab
    dt = find_douyin(tabs)
    if not dt:
        print("[WARN] 未找到抖音tab！请先在Chrome中打开 https://www.douyin.com 并登录")
        print("  现有tabs:")
        for t in tabs:
            if t.get("type") == "page":
                print(f"    {t.get('url', '')[:60]}")
        return False
    
    # 3. 检查是否有验证码
    vc_tabs = [t for t in tabs if "verifycenter" in t.get("url", "") and t.get("type") == "page"]
    if vc_tabs:
        print(f"[WARN] 检测到 {len(vc_tabs)} 个验证码页面，请先在Chrome中完成验证")
        return False
    
    print(f"[OK] CDP健康检查通过 - 抖音tab: {dt['url'][:50]}")
    return True

def check_verify_code(port, auto_wait=120):
    """检测抖音验证码tab，自动等待用户处理"""
    tabs = get_tabs(port)
    vc_tabs = [t for t in tabs if "verifycenter" in t.get("url", "") and t.get("type") == "page"]
    if not vc_tabs:
        return True
    print(f"  [WARN] 检测到 {len(vc_tabs)} 个验证码页面！请在Chrome中完成验证...")
    for i in range(auto_wait):
        time.sleep(1)
        tabs2 = get_tabs(port)
        vc = [t for t in tabs2 if "verifycenter" in t.get("url", "") and t.get("type") == "page"]
        if not vc:
            print(f"  [OK] 验证码已通过（等待{i+1}秒）")
            return True
    print(f"  [FAIL] 验证码等待超时，跳过当前关键词")
    return False

def drain(ws, seconds=2):
    deadline = time.time() + seconds
    n = 0
    while time.time() < deadline:
        try:
            ws.settimeout(0.5)
            ws.recv()
            n += 1
        except Exception:
            break
    return n

def recv_by_id(ws, target_id, timeout=10):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            ws.settimeout(2)
            m = json.loads(ws.recv())
            if m.get("id") == target_id:
                return m
        except Exception:
            continue
    return None

def cdp_enable_confirm(ws, methods, timeout=5):
    """发送CDP enable命令并确认收到响应"""
    for mid, method in enumerate(methods, 1):
        ws.send(json.dumps({"id": mid, "method": method}))
    deadline = time.time() + timeout
    confirmed = set()
    while time.time() < deadline and len(confirmed) < len(methods):
        try:
            ws.settimeout(2)
            m = json.loads(ws.recv())
            if m.get("id") in range(1, len(methods)+1):
                confirmed.add(m["id"])
        except:
            break
    return len(confirmed) == len(methods)

def search_keyword_with_retry(port, keyword, max_retries=3):
    """[v3.1.8新增] 搜索关键词，CDP断连时自动重试"""
    for attempt in range(1, max_retries + 1):
        try:
            # 每次重试重新获取tab列表（断连后ws_url可能变化）
            tabs = get_tabs(port)
            dt = find_douyin(tabs)
            if not dt:
                if attempt < max_retries:
                    print(f"  [RETRY {attempt}] 未找到抖音tab，5秒后重试...")
                    time.sleep(5)
                    continue
                else:
                    print(f"  [FAIL] {max_retries}次重试后仍未找到抖音tab")
                    return []
            
            ws_url = dt.get("webSocketDebuggerUrl")
            if not ws_url:
                if attempt < max_retries:
                    print(f"  [RETRY {attempt}] 无WebSocket URL，5秒后重试...")
                    time.sleep(5)
                    continue
                else:
                    print(f"  [FAIL] {max_retries}次重试后仍无WebSocket URL")
                    return []
            
            ids = search_keyword(ws_url, keyword)
            return ids
            
        except (websocket.WebSocketException, ConnectionError, OSError) as e:
            if attempt < max_retries:
                print(f"  [RETRY {attempt}] CDP连接异常: {type(e).__name__}, 5秒后重试...")
                time.sleep(5)
            else:
                print(f"  [FAIL] {max_retries}次重试后仍失败: {type(e).__name__}: {str(e)[:60]}")
                return []
        except Exception as e:
            print(f"  [FAIL] 搜索错误: {type(e).__name__}: {str(e)[:60]}")
            return []

def search_keyword(ws_url, keyword):
    """导航到搜索页，提取当前页面显示的全部视频ID（不滚动）
    [v3.1.8改进] 用Page.loadEventFired智能等待，最多30秒"""
    ws = websocket.create_connection(ws_url, timeout=30)
    
    # 必须先enable并确认
    cdp_enable_confirm(ws, ["Runtime.enable", "Page.enable"])
    drain(ws, 1)

    url = f"https://www.douyin.com/search/{urllib.parse.quote(keyword)}?type=video"
    ws.send(json.dumps({"id": 10, "method": "Page.navigate", "params": {"url": url}}))
    
    # [v3.1.8] 智能等待：监听Page.loadEventFired，最多30秒
    print(f"  导航到搜索页，智能等待加载...")
    loaded = False
    deadline = time.time() + 30
    while time.time() < deadline and not loaded:
        try:
            ws.settimeout(2)
            m = json.loads(ws.recv())
            if m.get("method") == "Page.loadEventFired":
                loaded = True
                print(f"  页面加载完成（{time.time() - deadline + 30:.0f}秒）")
        except websocket.WebSocketTimeoutException:
            continue
        except Exception:
            break
    
    if not loaded:
        print(f"  [WARN] 30秒内未收到loadEventFired，继续提取（可能加载较慢）")
    
    # 加载完成后等3秒让SPA渲染
    time.sleep(3)
    drain(ws, 2)

    # 提取当前页面全部视频ID（只取首页，不滚动）
    js = r"""(()=>{var i=[],s={};document.querySelectorAll('a[href*="/video/"]').forEach(function(a){var h=a.href||a.getAttribute('href')||'',m=h.match(/video\/(\d+)/);if(m&&!s[m[1]]){s[m[1]]=1;i.push(m[1]);}});return JSON.stringify(i);})()"""
    mid = 900
    ws.send(json.dumps({"id": mid, "method": "Runtime.evaluate",
        "params": {"expression": js, "returnByValue": True}}))
    r = recv_by_id(ws, mid, 10)
    
    ws.close()
    
    ids = []
    if r:
        v = r.get("result", {}).get("result", {}).get("value")
        if v:
            try:
                ids = json.loads(v)
            except Exception:
                pass
    
    print(f"  搜索完成：首页发现{len(ids)}个视频")
    return ids

def extract_audio_url_with_retry(vid, port, timeout=15, max_retries=3):
    """[v3.1.8新增] URL提取+CDP断连重试"""
    for attempt in range(1, max_retries + 1):
        try:
            url, tp, cnt = extract_audio_url(vid, port, timeout)
            return url, tp, cnt
        except (websocket.WebSocketException, ConnectionError, OSError) as e:
            if attempt < max_retries:
                print(f"    [RETRY {attempt}] URL提取CDP异常，5秒后重试...")
                time.sleep(5)
            else:
                print(f"    [FAIL] URL提取{max_retries}次重试后仍失败")
                return None, "cdp_error", 0
        except Exception as e:
            return None, f"error:{type(e).__name__}", 0

def extract_audio_url(vid, port, timeout=15):
    """创建新后台tab → Network拦截douyinvod URL → 关闭tab"""
    try:
        req = urllib.request.Request(f"http://localhost:{port}/json/new", method="PUT")
        resp = urllib.request.urlopen(req)
        nt = json.loads(resp.read())
        nws_url = nt.get("webSocketDebuggerUrl")
        nt_id = nt.get("id")
        if not nws_url:
            return None, "no_ws_url", 0
    except Exception:
        return None, "new_tab_error", 0

    ws = websocket.create_connection(nws_url, timeout=30)
    
    # 必须先enable并确认（Page.enable + Network.enable）
    cdp_enable_confirm(ws, ["Page.enable", "Network.enable", "Runtime.enable"])
    drain(ws, 1)

    ws.send(json.dumps({"id": 10, "method": "Page.navigate",
        "params": {"url": f"https://www.douyin.com/video/{vid}"}}))

    urls = {}
    loaded = False
    deadline = time.time() + timeout + 10  # 额外10秒等待加载
    while time.time() < deadline:
        try:
            ws.settimeout(3)
            m = json.loads(ws.recv())
            mn = m.get("method","")
            if mn == "Page.loadEventFired":
                loaded = True
            elif mn == "Network.requestWillBeSent":
                u = m.get("params", {}).get("request", {}).get("url", "")
                if "douyinvod" in u:
                    urls[u] = "req"
            elif mn == "Network.responseReceived":
                u = m.get("params", {}).get("response", {}).get("url", "")
                if "douyinvod" in u:
                    urls[u] = "resp"
        except websocket.WebSocketTimeoutException:
            if loaded:
                # 加载完成后再等5秒收集延迟URL
                time.sleep(5)
                try:
                    ws.settimeout(2)
                    for _ in range(30):
                        raw = ws.recv()
                        mm = json.loads(raw)
                        u = ""
                        if mm.get("method") == "Network.requestWillBeSent":
                            u = mm.get("params",{}).get("request",{}).get("url","")
                        elif mm.get("method") == "Network.responseReceived":
                            u = mm.get("params",{}).get("response",{}).get("url","")
                        if u and "douyinvod" in u:
                            urls[u] = "extra"
                except:
                    pass
                break
            continue
        except Exception:
            continue

    # 关闭tab
    try:
        req = urllib.request.Request(f"http://localhost:{port}/json/close/{nt_id}", method="PUT")
        urllib.request.urlopen(req, timeout=5)
    except:
        pass
    ws.close()

    # 选择最佳URL：DASH音频 > 完整视频
    audio_urls = [u for u in urls if "dash-audio" in u.lower() or "media-audio" in u.lower()]
    mp4_urls = [u for u in urls if "video_mp4" in u.lower() or ("tos-cn" in u.lower() and "dash-audio" not in u.lower() and "media-audio" not in u.lower())]
    best = audio_urls[0] if audio_urls else (mp4_urls[0] if mp4_urls else None)
    tp = "dash_audio" if audio_urls else ("full_mp4" if mp4_urls else "none")
    return best, tp, len(urls)

def download_audio(vid, url, audio_dir, skip_large_mb=0, dl_retries=3):
    """[v3.1.9] curl下载音频文件，断线自动续传重试
    dl_retries: 下载最大重试次数，每次用curl -C -续传（不删部分文件）"""
    out = os.path.join(audio_dir, f"{vid}.mp4")
    
    # 智能跳过：已下载且>1MB视为有效缓存
    if os.path.exists(out) and os.path.getsize(out) > 1000000:
        sz = os.path.getsize(out)
        print(f"    已缓存({sz/1024:.0f}KB)，跳过")
        return out
    
    # 跳过超大文件
    if skip_large_mb > 0:
        curl_cmd = "curl.exe" if sys.platform == "win32" else "curl"
        head = subprocess.run(
            [curl_cmd, "-sI", "-H", "Referer: https://www.douyin.com/", url],
            capture_output=True, timeout=15)
        for line in head.stdout.decode('utf-8', errors='replace').split('\n'):
            if line.lower().startswith('content-length'):
                try:
                    cl = int(line.split(':')[1].strip())
                    if cl > skip_large_mb * 1024 * 1024:
                        print(f"    文件过大({cl/1024/1024:.1f}MB > {skip_large_mb}MB)，跳过")
                        return None
                except:
                    pass
    
    curl_cmd = "curl.exe" if sys.platform == "win32" else "curl"
    for attempt in range(1, dl_retries + 1):
        # [v3.1.9] 断点续传：首次正常下载，重试时用 -C - 从断点继续
        resume_flag = ["-C", "-"] if attempt > 1 and os.path.exists(out) else []
        r = subprocess.run(
            [curl_cmd, "-L",
             "-H", "Referer: https://www.douyin.com/",
             "-H", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
             "-o", out, "--max-time", "120"] + resume_flag + [url],
            capture_output=True, timeout=130)
        
        if r.returncode == 0 and os.path.exists(out) and os.path.getsize(out) > 100000:
            sz = os.path.getsize(out)
            if attempt > 1:
                print(f"    [OK] 第{attempt}次下载续传成功({sz/1024:.1f}KB)")
            else:
                print(f"    下载成功({sz/1024:.1f}KB)")
            return out
        else:
            if attempt < dl_retries:
                partial_sz = os.path.getsize(out) if os.path.exists(out) else 0
                print(f"    [RETRY {attempt}] 下载中断(已下载{partial_sz/1024:.0f}KB)，5秒后续传重试...")
                time.sleep(5)
            else:
                # 最后一次也失败：保留部分文件，下次重跑可续传
                partial_sz = os.path.getsize(out) if os.path.exists(out) else 0
                print(f"    [FAIL] 下载{dl_retries}次续传后仍失败（保留{partial_sz/1024:.0f}KB部分文件，下次可续传）")
                return None

def stop_douyin_videos_deep(cdp_port=9222):
    """[v3.1.8新增] 深度停止抖音视频播放 - mainDOM+iframe+shadowDOM+MutationObserver
    外卖实测验证：成功暂停2个video元素 + override play() + 拦截自动播放"""
    try:
        import websocket as ws_mod
    except ImportError:
        print("  websocket-client未安装，跳过停播视频")
        return
    
    try:
        resp = urllib.request.urlopen(f"http://localhost:{cdp_port}/json", timeout=5)
        tabs = json.loads(resp.read())
        douyin_tabs = [t for t in tabs if "douyin" in t.get("url", "") and "sw.js" not in t.get("url", "")]
        
        # 深度停播JS：主DOM + iframe + shadow DOM + override play() + MutationObserver
        js_deep_stop = """
        (function() {
          var count = 0;
          function stopAllVids(root) {
            var vids = root.querySelectorAll('video');
            vids.forEach(function(v) {
              v.pause();
              v.currentTime = 0;
              v.autoplay = false;
              v.removeAttribute('autoplay');
              v.muted = true;
              v.play = function() { v.pause(); return Promise.resolve(); };
              count++;
            });
            root.querySelectorAll('*').forEach(function(el) {
              if (el.shadowRoot) stopAllVids(el.shadowRoot);
            });
          }
          stopAllVids(document);
          try {
            document.querySelectorAll('iframe').forEach(function(iframe) {
              try { stopAllVids(iframe.contentDocument); } catch(e) {}
            });
          } catch(e) {}
          var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(m) {
              m.addedNodes.forEach(function(node) {
                if (node.nodeName === 'VIDEO') {
                  node.pause(); node.currentTime = 0;
                  node.play = function(){node.pause();return Promise.resolve();};
                  count++;
                }
                try {
                  node.querySelectorAll && node.querySelectorAll('video').forEach(function(v) {
                    v.pause(); v.currentTime = 0;
                    v.play = function(){v.pause();return Promise.resolve();};
                  });
                } catch(e) {}
              });
            });
          });
          observer.observe(document.body || document.documentElement, {childList: true, subtree: true});
          return 'Deep-stopped ' + count + ' videos, observer active';
        })()
        """
        
        stopped_count = 0
        for tab in douyin_tabs:
            ws_url = tab.get("webSocketDebuggerUrl")
            if not ws_url:
                continue
            try:
                ws = ws_mod.create_connection(ws_url, timeout=10)
                ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate", "params": {"expression": js_deep_stop}}))
                result = json.loads(ws.recv())
                val = result.get("result", {}).get("result", {}).get("value", "N/A")
                print(f"  已停播: {tab['url'][:50]} - {val}")
                stopped_count += 1
                ws.close()
            except Exception:
                pass
        
        if douyin_tabs:
            print(f"  深度停播完成: {stopped_count}/{len(douyin_tabs)} 个tab")
        else:
            print(f"  未找到抖音tab（无需停播）")
    except Exception as e:
        print(f"  停播视频失败（非致命）: {e}")

def main():
    parser = argparse.ArgumentParser(description="抖音视频搜索+URL提取+下载 v3.2.2")
    parser.add_argument("--keywords", required=True, help="逗号分隔的搜索关键词")
    parser.add_argument("--output-dir", default="./output", help="输出目录")
    parser.add_argument("--cdp-port", type=int, default=9222, help="Chrome CDP端口")
    parser.add_argument("--pause", type=int, default=0, help="关键词间暂停秒数（默认随机20-40秒）")
    parser.add_argument("--extract-timeout", type=int, default=15, help="URL提取超时秒数")
    parser.add_argument("--video-interval", type=int, default=15, help="视频间间隔秒数")
    parser.add_argument("--skip-large-mb", type=float, default=0, help="跳过大于此MB的文件（0=不跳过）")
    parser.add_argument("--auto-wait-verify", type=int, default=120, help="验证码自动等待秒数")
    parser.add_argument("--max-retries", type=int, default=3, help="CDP操作最大重试次数")
    parser.add_argument("--dl-retries", type=int, default=3, help="[v3.1.9] 下载断线重试次数（0=不重试）")
    args = parser.parse_args()

    out = args.output_dir
    audio_dir = os.path.join(out, "audio")
    id_file = os.path.join(out, "all_video_ids.json")
    url_file = os.path.join(out, "audio_urls.json")
    dl_file = os.path.join(out, "dl_progress.json")
    result_file = os.path.join(out, "collection_results.json")
    kw_map_file = os.path.join(out, "kw_map.json")       # [v3.1.8] 自动生成
    summary_file = os.path.join(out, "collection_summary.json")  # [v3.1.8] 采集摘要
    os.makedirs(audio_dir, exist_ok=True)

    # [v3.1.8] CDP健康检查
    print("=" * 60)
    print("CDP健康检查...")
    if not check_cdp_health(args.cdp_port):
        print("\n请修复以上问题后重新运行脚本")
        return

    kws = [k.strip() for k in args.keywords.split(",")]
    print(f"\n关键词列表: {kws}（共{len(kws)}个）")
    
    # jload现在正确处理不存在文件
    rlist = jload(id_file, "list")
    existing = set(r["id"] for r in rlist if isinstance(r, dict)) if isinstance(rlist, list) else set()
    urls = jload(url_file, "dict")
    dl = jload(dl_file, "dict")
    kw_map = jload(kw_map_file, "dict")  # [v3.1.8] 关键词→视频ID映射
    
    dl_ok = sum(1 for v in dl.values() if isinstance(v, dict) and v.get("file"))
    print(f"初始化: {len(existing)} 个已有ID, {len(urls)} 个URL, {dl_ok} 个已下载")

    stats = {"found": 0, "url_ok": 0, "url_fail": 0, "dl_ok": 0, "dl_fail": 0, "skipped": 0,
             "keywords_total": len(kws), "keywords_ok": 0, "keywords_fail": 0}
    all_results = []
    kw_stats = {}  # [v3.1.8] 每关键词统计
    start_time = time.time()

    for ki, kw in enumerate(kws):
        print(f"\n{'='*60}")
        print(f"[{ki+1}/{len(kws)}] 关键词: {kw}")
        print(f"{'='*60}")

        # 检查验证码
        if not check_verify_code(args.cdp_port, args.auto_wait_verify):
            kw_stats[kw] = {"status": "skipped_verify", "ids_found": 0, "new_ids": 0}
            stats["keywords_fail"] += 1
            continue

        # [v3.1.8] 搜索+CDP断连重试
        try:
            ids = search_keyword_with_retry(args.cdp_port, kw, args.max_retries)
        except Exception as e:
            print(f"  [FAIL] 搜索异常: {type(e).__name__}: {str(e)[:60]}")
            ids = []
        
        if not ids:
            kw_stats[kw] = {"status": "no_results", "ids_found": 0, "new_ids": 0}
            stats["keywords_fail"] += 1
            print(f"  [WARN] 关键词'{kw}'搜索0结果，可能是风控或关键词无匹配")
            continue

        new = [i for i in ids if i not in existing]
        dedup_rate = len(new) / len(ids) * 100 if ids else 0
        
        # [v3.1.8] 去重报告
        print(f"  发现{len(ids)}个视频，{len(new)}个新ID（去重率{dedup_rate:.0f}%）")
        if len(new) < 3 and len(ids) > 0:
            print(f"  [HINT] 新增<3，关键词'{kw}'与前面的重叠度高，可考虑换词")
        
        existing.update(ids)
        kw_map[kw] = ids  # [v3.1.8] 自动生成kw_map
        for i in ids:
            rlist.append({"id": i, "keyword": kw, "url": f"https://www.douyin.com/video/{i}"})
        stats["found"] += len(new)
        stats["keywords_ok"] += 1
        kw_stats[kw] = {"status": "ok", "ids_found": len(ids), "new_ids": len(new), "dedup_rate": dedup_rate}
        jsave(id_file, rlist)
        jsave(kw_map_file, kw_map)  # [v3.1.8] 实时保存kw_map

        # 提取URL + 下载（逐个处理，带间隔+重试）
        to_process = [i for i in new if i not in urls]
        for ii, vid in enumerate(to_process):
            print(f"\n  [{ii+1}/{len(to_process)}] 视频 {vid}")
            
            # 再次检查验证码
            if not check_verify_code(args.cdp_port, args.auto_wait_verify):
                break
            
            # [v3.1.8] URL提取+CDP重试
            url, tp, cnt = extract_audio_url_with_retry(vid, args.cdp_port, args.extract_timeout, args.max_retries)
            if url:
                urls[vid] = {"url": url, "type": tp, "raw_count": cnt}
                stats["url_ok"] += 1
                print(f"    URL提取成功 ({tp}, {cnt}个网络请求)")
            else:
                urls[vid] = {"url": None, "type": tp, "raw_count": cnt}
                stats["url_fail"] += 1
                print(f"    URL提取失败 ({tp})")
                if ii < len(to_process) - 1:
                    time.sleep(args.video_interval)
                continue
            
            jsave(url_file, urls)
            
            # 下载（v3.1.9: 断线续传重试）
            f = download_audio(vid, urls[vid]["url"], audio_dir, args.skip_large_mb, args.dl_retries)
            result_entry = {"id": vid, "keyword": kw, "url_type": tp}
            if f:
                dl[vid] = {"file": f, "size": os.path.getsize(f)}
                stats["dl_ok"] += 1
                result_entry["file"] = f
                result_entry["size"] = os.path.getsize(f)
            elif f is None and os.path.exists(os.path.join(audio_dir, f"{vid}.mp4")) and os.path.getsize(os.path.join(audio_dir, f"{vid}.mp4")) > 1000000:
                stats["skipped"] += 1
                result_entry["file"] = "cached"
            else:
                dl[vid] = {"file": None, "error": "download_failed"}
                stats["dl_fail"] += 1
            all_results.append(result_entry)
            
            jsave(dl_file, dl)
            jsave(result_file, all_results)
            
            # 视频间间隔
            if ii < len(to_process) - 1:
                print(f"    等待{args.video_interval}秒...")
                time.sleep(args.video_interval)

        print(f"  关键词统计: found={stats['found']}, url={stats['url_ok']}/{stats['url_fail']}, dl={stats['dl_ok']}/{stats['dl_fail']}, skipped={stats['skipped']}")

        if ki < len(kws) - 1:
            w = args.pause if args.pause > 0 else random.randint(20, 40)
            print(f"  关键词间等待{w}秒...")
            time.sleep(w)

    elapsed = time.time() - start_time
    
    # [v3.1.8] 采集摘要自动生成
    summary = {
        "version": "3.2.2",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_seconds": round(elapsed, 1),
        "keywords": kws,
        "keywords_total": stats["keywords_total"],
        "keywords_ok": stats["keywords_ok"],
        "keywords_fail": stats["keywords_fail"],
        "keywords_detail": kw_stats,
        "total_found": stats["found"],
        "url_ok": stats["url_ok"],
        "url_fail": stats["url_fail"],
        "dl_ok": stats["dl_ok"],
        "dl_fail": stats["dl_fail"],
        "skipped": stats["skipped"]
    }
    jsave(summary_file, summary)

    print(f"\n{'='*60}")
    print(f"全部完成！（耗时{elapsed/60:.1f}分钟）")
    print(f"  关键词: {stats['keywords_ok']}/{stats['keywords_total']} 成功")
    print(f"  发现: {stats['found']} | URL成功: {stats['url_ok']} | URL失败: {stats['url_fail']}")
    print(f"  下载成功: {stats['dl_ok']} | 下载失败: {stats['dl_fail']} | 跳过缓存: {stats['skipped']}")
    print(f"  摘要: {summary_file}")
    print(f"  kw_map: {kw_map_file}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
