# 启动Chrome CDP调试模式 (Windows)
# 用法: powershell -File scripts/start_chrome_debug.ps1
#
# 改进（基于2026-07实战）：
#   - 添加 --remote-allow-origins=* 防止CDP WebSocket被拒
#   - 添加 --disable-web-security 防止跨域问题
#   - 更智能的路径检测（Google Chrome / Chrome Portable / Edge）

$cdpPort = 9222
$userDataDir = "C:\temp\chrome_debug"

# 检测Chrome路径（优先Google Chrome，其次Edge）
$chromePaths = @(
    "C:\Program Files\Google\Chrome\Application\chrome.exe",
    "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    "C:\Users\$env:USERNAME\AppData\Local\Google\Chrome\Application\chrome.exe",
    "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
)

$chromePath = $null
foreach ($p in $chromePaths) {
    if (Test-Path $p) {
        $chromePath = $p
        break
    }
}

if (-not $chromePath) {
    Write-Host "❌ 未找到Chrome或Edge浏览器！" -ForegroundColor Red
    Write-Host "请手动指定路径或安装Chrome"
    exit 1
}

Write-Host "使用浏览器: $chromePath" -ForegroundColor Green

# 检查是否已有CDP实例
$existing = Get-Process -Name "chrome","msedge" -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -match "remote-debugging-port"
}

if ($existing) {
    Write-Host "⚠ Chrome CDP已在运行 (PID: $($existing.Id))" -ForegroundColor Yellow
    Write-Host "CDP: http://localhost:$cdpPort/json"
    
    # 测试连接
    try {
        $resp = Invoke-WebRequest -Uri "http://localhost:$cdpPort/json" -UseBasicParsing -TimeoutSec 2
        Write-Host "✅ CDP连接正常" -ForegroundColor Green
    } catch {
        Write-Host "❌ CDP连接失败，可能需要重启Chrome" -ForegroundColor Red
    }
    exit 0
}

# 启动Chrome（关键：--remote-allow-origins=* 防止WebSocket被拒）
Write-Host "启动Chrome CDP（端口 $cdpPort）..." -ForegroundColor Cyan
$chromeArgs = @(
    "--remote-debugging-port=$cdpPort",
    "--remote-allow-origins=*",     # ⚠ 必须！否则CDP WebSocket连接会被拒绝
    "--user-data-dir=$userDataDir",
    "--disable-web-security",       # 防止跨域问题
    "https://www.douyin.com"
)

Start-Process $chromePath -ArgumentList $chromeArgs

# 等待CDP就绪
for ($i = 0; $i -lt 20; $i++) {
    try {
        $resp = Invoke-WebRequest -Uri "http://localhost:$cdpPort/json" -UseBasicParsing -TimeoutSec 2
        Write-Host "✅ CDP就绪！请在浏览器中登录抖音" -ForegroundColor Green
        Write-Host "CDP: http://localhost:$cdpPort/json"
        exit 0
    } catch {
        Write-Host "等待CDP就绪... ($i/20)"
        Start-Sleep -Seconds 1
    }
}
Write-Host "❌ CDP未在20秒内就绪" -ForegroundColor Red
exit 1
