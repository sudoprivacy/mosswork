#!/usr/bin/env python3
"""
抖音知识搜集器 一键运行脚本 v3.2.2
将搜索+转录串联为一条命令，降低非技术用户的操作门槛。

用法：
  python -u scripts/run_all.py --keywords "民宿经营,民宿运营" --output-dir ./output

可选参数：
  --cdp-port 9222       Chrome CDP端口
  --model base          Whisper模型
  --language zh         语言
  --skip-transcribe     只搜索下载，不转录
"""
import subprocess, sys, os, argparse, time

def run_step(script, args, label):
    """运行一个步骤脚本"""
    cmd = [sys.executable, "-u", script] + args
    print(f"\n{'='*60}")
    print(f"[STEP] {label}")
    print(f"命令: {' '.join(cmd)}")
    print(f"{'='*60}")
    t0 = time.time()
    result = subprocess.run(cmd)
    elapsed = time.time() - t0
    if result.returncode != 0:
        print(f"[FAIL] {label} 失败 (返回码={result.returncode}, 耗时{elapsed/60:.1f}分钟)")
        return False
    print(f"[OK] {label} 完成 (耗时{elapsed/60:.1f}分钟)")
    return True

def main():
    parser = argparse.ArgumentParser(description="抖音知识搜集器 一键运行 v3.2.2")
    parser.add_argument("--keywords", required=True, help="逗号分隔的搜索关键词")
    parser.add_argument("--output-dir", default="./output", help="输出目录")
    parser.add_argument("--cdp-port", type=int, default=9222, help="Chrome CDP端口")
    parser.add_argument("--pause", type=int, default=0, help="关键词间暂停秒数（默认随机20-40秒）")
    parser.add_argument("--video-interval", type=int, default=15, help="视频间间隔秒数")
    parser.add_argument("--extract-timeout", type=int, default=15, help="URL提取超时秒数")
    parser.add_argument("--model", default="base", help="Whisper模型 (默认base，不建议tiny)")
    parser.add_argument("--punctuation", dest="punctuation", action=argparse.BooleanOptionalAction, default=True, help="转录加标点符号（默认开启）")
    parser.add_argument("--language", default="zh", help="语言代码")
    parser.add_argument("--skip-large-mb", type=float, default=0, help="跳过大于此MB的文件")
    parser.add_argument("--max-retries", type=int, default=3, help="CDP操作最大重试次数")
    parser.add_argument("--dl-retries", type=int, default=3, help="下载断线重试次数（0=不重试）")
    parser.add_argument("--skip-transcribe", action="store_true", help="只搜索下载，不转录")
    parser.add_argument("--retry-failed", action="store_true", help="重试之前失败的转录")
    args = parser.parse_args()

    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    search_script = os.path.join(scripts_dir, "search_and_extract.py")
    transcribe_script = os.path.join(scripts_dir, "transcribe_batch.py")

    audio_dir = os.path.join(args.output_dir, "audio")
    transcript_dir = os.path.join(args.output_dir, "transcripts")

    # Step 1: 搜索+提取+下载
    search_args = [
        "--keywords", args.keywords,
        "--output-dir", args.output_dir,
        "--cdp-port", str(args.cdp_port),
        "--video-interval", str(args.video_interval),
        "--extract-timeout", str(args.extract_timeout),
        "--max-retries", str(args.max_retries),
        "--dl-retries", str(args.dl_retries),
    ]
    if args.pause > 0:
        search_args.extend(["--pause", str(args.pause)])
    if args.skip_large_mb > 0:
        search_args.extend(["--skip-large-mb", str(args.skip_large_mb)])

    if not run_step(search_script, search_args, "Step 1: 搜索+提取+下载"):
        print("\n[STOP] Step 1失败，无法继续Step 2")
        return

    if args.skip_transcribe:
        print("\n[SKIP] 跳过转录（--skip-transcribe）")
        print(f"音频文件保存在: {audio_dir}")
        print("后续可手动运行转录:")
        print(f"  python -u scripts/transcribe_batch.py --audio-dir {audio_dir} --output-dir {transcript_dir} --model {args.model}")
        return

    # Step 2: 批量转录
    transcribe_args = [
        "--audio-dir", audio_dir,
        "--output-dir", transcript_dir,
        "--model", args.model,
        "--language", args.language,
    ]

    # [v3.2.2] 标点符号参数传递
    if not args.punctuation:
        transcribe_args.append("--no-punctuation")

    # 自动查找kw_map.json
    kw_map_path = os.path.join(args.output_dir, "kw_map.json")
    if os.path.exists(kw_map_path):
        transcribe_args.extend(["--kw-map", kw_map_path])

    if args.retry_failed:
        transcribe_args.append("--retry-failed")

    if not run_step(transcribe_script, transcribe_args, "Step 2: 批量转录"):
        print("\n[WARN] Step 2失败，但音频文件已保存在: " + audio_dir)
        return

    # 完成
    print(f"\n{'='*60}")
    print("[DONE] 全流程完成！")
    print(f"  音频: {audio_dir}")
    print(f"  转录: {transcript_dir}")
    print(f"  质量报告: {os.path.join(transcript_dir, 'quality_report.json')}")
    print(f"  kw_map: {kw_map_path}")
    print(f"\n下一步: 告诉Agent你采集的行业关键词，")
    print(f"  Agent会读取转录文件，提炼结构化知识库。")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
