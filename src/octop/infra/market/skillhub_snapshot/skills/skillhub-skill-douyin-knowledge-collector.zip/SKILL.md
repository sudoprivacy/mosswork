---
name: skillhub-skill-douyin-knowledge-collector
description: "从抖音批量搜索视频→提取音频→Whisper转录→生成结构化知识库。v3.2.2：转录自动加标点(initial_prompt)+繁简体自动转换(内置映射表)。"
---

# 抖音知识搜集器 v3.2.2

从抖音批量搜索采集视频 → 提取音频 → Whisper转录 → 生成结构化知识库。

> **一句话说明**：你告诉我想了解的行业/话题，我帮你从抖音视频里挖出知识，做成结构化笔记。

## v3.2.2 核心更新（2026-07-16）

| # | 改进 | 问题 | 解决方案 |
|---|------|------|----------|
| 1 | **转录加标点符号** | whisper base模型输出的中文几乎没有标点，连读难辨 | `initial_prompt="以下是普通话的句子，带有标点符号。"` 引导Whisper输出中文标点（默认开启，`--no-punctuation`可关） |
| 2 | **繁体→简体自动转换** | whisper有时输出繁体字（如"運營"、"購買"），知识库混用繁简 | 内置1100+繁简映射表，转录完成后逐字转换，**不依赖opencc**（零额外依赖） |

## v3.2.0 核心更新（2026-07-12，基于TRACE五维度评审）

| # | 改进 | 意见来源 | 解决方案 |
|---|------|---------|----------|
| 1 | **国内镜像源加速** | 可信任度："下载语音转文字模型时可能稍慢" | `install_deps.ps1 -Mirror`（pip清华源+whisper模型hf-mirror），手动安装也加了镜像指引 |
| 2 | **触发词扩充** | 适用性："触发词选择比较单一" | 从5个扩充到9个，覆盖"批量采集抖音/抖音批量搜索/抖音视频搜索/从抖音视频提取/抖音知识挖掘/douyin knowledge"等自然表达 |
| 3 | **前置要求醒目化** | 适用性："必须有Chrome和登录账号" | 前置要求加⚠️警示+适用边界声明（仅抖音平台+转录85%需人工修正） |
| 4 | **适用边界声明** | 适用性："只能用于抖音" | SKILL.md新增适用边界声明，明确不支持其他平台 |

## v3.1.9 核心更新（2026-07-11，基于四条评审意见）

| # | 改进 | 意见来源 | 解决方案 |
|---|------|---------|----------|
| 1 | **触发词精化** | 适用性："触发词有点模糊可能误触发" | 移除泛词`知识挖掘/视频转录/douyin/knowledge collector`，改为明确指向抖音的触发词 |
| 2 | **一键运行脚本** | 适用性："需要敲命令，对不懂技术的用户不太友好" | 新增`run_all.py`，一条命令完成搜索+转录全流程 |
| 3 | **依赖一键安装** | 有效性："依赖安装稍繁琐" | 新增`install_deps.ps1`，自动检测Python+安装whisper+websocket+ffmpeg |
| 4 | **术语通俗化** | 规范性："部分技术术语对非开发者有一定门槛" | 新增术语速查表，CDP/WebSocket/SPA等加通俗解释 |
| 5 | **转录修正指南强化** | 有效性："whisper转录需要人工核对修正错别字" | Step3新增常见谐音错误模式表+修正方法论+自动修正提示模板 |
| 6 | **下载断线续传重试** | 可靠性："下载时断了不会自动重试需要注意" | `download_audio`加入`--dl-retries 3`参数，curl -C -断点续传，3次自动重试 |

## v3.1.8 核心更新（2026-07-05）

| # | 改进 | 问题 | 解决方案 |
|---|------|------|----------|
| 1 | CDP断连重试 | 外卖测试2/8关键词因CDP socket断连丢失 | search/extract操作3次重试 |
| 2 | 智能加载检测 | 固定等18秒有时不够有时浪费 | Page.loadEventFired事件+30秒轮询+3秒SPA渲染 |
| 3 | 深度停播视频 | 只停主DOMvideo不够 | iframe+shadowDOM+override play()+MutationObserver |
| 4 | kw_map自动生成 | 需要Agent手动生成关键词→视频ID映射 | 搜索过程中自动生成 |
| 5 | 转录质量分级 | 所有转录统一处理，无质量标记 | low/medium/high + quality_report.json |
| 6 | 搜索去重报告 | 跨关键词重复视频无统计 | 每关键词打印新ID占比 |
| 7 | --retry-failed | 转录失败文件无法重试 | 重试时移除.failed标记 |
| 8 | 采集摘要自动生成 | 只有脚本输出数字 | collection_summary.json / transcription_summary.json |
| 9 | CDP健康检查 | 脚本启动前不检查CDP是否可用 | 检测Chrome+抖音tab+验证码 |

## 术语速查（非开发者友好）

| 术语 | 通俗解释 |
|------|---------|
| **CDP** (Chrome DevTools Protocol) | Chrome浏览器的"遥控器接口"，让脚本能操控Chrome页面 |
| **WebSocket** | 浏览器和脚本之间的"实时通话通道" |
| **SPA** (Single Page Application) | 网页不刷新就切换内容的"现代网页"（抖音就是SPA） |
| **whisper** | OpenAI开发的"语音转文字"工具，把视频里的声音变成文字 |
| **CDP断连** | "遥控器"突然断了，脚本和浏览器失去联系 |
| **验证码拦截** | 抖音检测到机器人操作，弹出"请证明你是人类"的验证 |
| **DASH音频流** | 视频中单独拆出来的纯音频部分，比下载完整视频更省空间 |
| **initial_prompt** | whisper转录前给的"提示语"，引导模型输出带标点的中文 |

## 适用场景

- 行业实操知识采集（民宿经营、健身训练、编程教学等）
- 竞品分析：采集某类视频提炼打法
- 话题深度调研：从短视频提取系统性知识
- 金融事件交叉验证：从短视频观点与网页数据交叉对比
- 任何想从抖音视频里"挖知识"的场景

> **适用边界**：本工具专为抖音平台设计，不支持B站/小红书/YouTube等平台。转录准确率约85%，**生成知识库前必须人工修正谐音错字**。

## 前置要求

> ⚠️ **必须满足以下条件才能使用**：

1. **Chrome 浏览器**（已登录抖音 — 未登录将搜索0结果）
2. **Python 3.10+** + `openai-whisper` + `websocket-client`
3. **ffmpeg**（whisper依赖）
4. **curl**（Windows自带）
5. Chrome启动必须加 `--remote-allow-origins=*` 参数

### 一键安装依赖（v3.1.9新增）

```powershell
# 自动检测Python + 安装whisper + websocket-client + ffmpeg
powershell -File scripts/install_deps.ps1

# [v3.2.0] 国内镜像加速（pip用清华源，whisper模型用hf-mirror）
powershell -File scripts/install_deps.ps1 -Mirror
```

> **模型下载慢？** whisper首次运行会下载模型（base 139MB），国内可能较慢。解决方法：
> 1. 用 `-Mirror` 参数自动走国内镜像
> 2. 或手动设置环境变量：`$env:HF_ENDPOINT='https://hf-mirror.com'` 再运行脚本

### 手动安装（备用）

```bash
pip install openai-whisper websocket-client

# 国内镜像加速（pip清华源 + whisper模型镜像）
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple openai-whisper websocket-client
$env:HF_ENDPOINT='https://hf-mirror.com'  # PowerShell设置whisper模型镜像

# ffmpeg: Windows用 winget install Gyan.FFmpeg，Mac用 brew install ffmpeg
```

### 启动 Chrome CDP

```powershell
# 一键启动（推荐）
powershell -File scripts/start_chrome_debug.ps1

# 手动启动
# Windows（必须加 --remote-allow-origins=*！）
Start-Process "C:\Program Files\Google\Chrome\Application\chrome.exe" -ArgumentList \
  "--remote-debugging-port=9222","--remote-allow-origins=*","--user-data-dir=C:\temp\chrome_debug","https://www.douyin.com"

# Mac/Linux
google-chrome --remote-debugging-port=9222 --remote-allow-origins=* --user-data-dir=/tmp/chrome_debug https://www.douyin.com
```

启动后**扫码登录抖音**，登录态保存在用户数据目录。

> **关键提醒**：`--remote-allow-origins=*` 是Chrome 111+的必须参数，不加此参数脚本无法连接Chrome！

## 使用流程

### 方式A：一键运行（推荐非技术用户）

一条命令完成搜索+转录全流程：

```bash
python -u scripts/run_all.py --keywords "民宿经营,民宿运营,民宿创业,民宿选址,民宿设计,民宿营销,民宿定价,民宿引流" --output-dir ./output

# 只搜索不转录（先看看搜索结果）
python -u scripts/run_all.py --keywords "民宿经营,民宿运营" --output-dir ./output --skip-transcribe
```

参数说明：
| 参数 | 默认 | 说明 |
|------|------|------|
| `--keywords` | 必填 | 逗号分隔的搜索关键词 |
| `--output-dir` | ./output | 输出目录 |
| `--cdp-port` | 9222 | Chrome遥控器端口 |
| `--model` | base | whisper模型（base=够用且快） |
| `--language` | zh | 语言（zh=中文） |
| `--skip-transcribe` | false | 只搜索下载，不转录 |
| `--retry-failed` | false | 重试之前失败的转录 |
| `--no-punctuation` | false | [v3.2.2] 不加标点符号 |
| `--pause` | 随机20-40 | 关键词间等待秒数 |
| `--video-interval` | 15 | 视频间间隔秒数 |
| `--max-retries` | 3 | CDP连接重试次数 |
| `--dl-retries` | 3 | 下载断线续传重试次数 |

### 方式B：分步运行（适合需要细调的技术用户）

#### Step 1: 搜索+提取URL+下载

```bash
python -u scripts/search_and_extract.py \
  --keywords "民宿经营,民宿运营,民宿创业,民宿选址,民宿设计,民宿营销,民宿定价,民宿引流" \
  --output-dir ./output \
  --cdp-port 9222 \
  --video-interval 15
```

> **v3.1.8新增行为**：CDP健康检查 → kw_map自动生成 → collection_summary自动生成 → CDP断连自动重试

参数说明：
| 参数 | 默认 | 说明 |
|------|------|------|
| `--keywords` | 必填 | 逗号分隔的搜索关键词 |
| `--output-dir` | ./output | 输出目录 |
| `--cdp-port` | 9222 | Chrome遥控器端口 |
| `--pause` | 随机20-40 | 关键词间暂停秒数 |
| `--video-interval` | 15 | 视频间间隔秒数 |
| `--extract-timeout` | 15 | URL提取超时秒数 |
| `--skip-large-mb` | 0 | 跳过大于此MB的文件（0=不跳过） |
| `--auto-wait-verify` | 120 | 验证码自动等待秒数 |
| `--max-retries` | 3 | CDP操作最大重试次数 |
| `--dl-retries` | 3 | [v3.1.9] 下载断线续传重试次数 |

#### Step 2: 批量转录

```bash
python -u scripts/transcribe_batch.py \
  --audio-dir ./output/audio \
  --output-dir ./output/transcripts \
  --model base \
  --language zh \
  --kw-map ./output/kw_map.json

# [v3.2.2] 不加标点符号（默认是开启的）
python -u scripts/transcribe_batch.py \
  --audio-dir ./output/audio \
  --output-dir ./output/transcripts \
  --model base --language zh --no-punctuation

# 重试之前失败的转录
python -u scripts/transcribe_batch.py \
  --audio-dir ./output/audio \
  --output-dir ./output/transcripts \
  --model base --language zh --retry-failed
```

> **v3.2.2新增行为**：转录自动加标点(initial_prompt) + 繁体→简体自动转换(内置映射表)

> **v3.1.8新增行为**：深度停播视频 → 实时质量分级 → quality_report自动生成 → transcription_summary自动生成

参数说明：
| 参数 | 默认 | 说明 |
|------|------|------|
| `--audio-dir` | 必填 | 音频文件目录 |
| `--output-dir` | 必填 | 转录文本输出目录 |
| `--model` | base | whisper模型（默认base，不建议tiny） |
| `--language` | zh | 语言代码 |
| `--no-punctuation` | false | [v3.2.2] 不加标点符号（默认开启标点） |
| `--kw-map` | 无 | 关键词→视频ID映射JSON（Step 1自动生成） |
| `--retry-failed` | false | 重试所有.failed文件 |

#### Step 3: 生成知识库（Agent完成）

将 `transcripts/` 下所有文本合并 → 按主题分段 → 去重提炼 → 写结构化知识库MD。

**建议优先读 quality_report.json**：
- `high_quality_ids` (>500字符)：优先提炼，内容丰富
- `medium_quality_ids` (100-500字符)：参考，可能有短观点
- `low_quality_ids` (<100字符)：基本是噪音/广告，可忽略

### 转录修正指南

whisper base模型中文识别率约85%，**必须修正谐音错别字**才能做知识库。

> **[v3.2.2] 繁简体已自动转换**，不再需要手动处理繁体字（如"運營"→"运营"、"購買"→"购买"已自动完成）。

#### 常见谐音错误模式

| 错误类型 | 示例 | 修正方法 |
|---------|------|---------|
| **谐音替换** | "运营"→"运用"、"满减"→"瞒解"、"外卖"→"外麦" | 根据上下文语义还原 |
| **专业术语错识别** | "ROI"→"肉爱"、"SKU"→"斯克优" | 需行业知识修正 |
| **数字/量级错** | "30%"→"三百分"、"1万"→"一万" | 检查语境中的量级 |
| **语气词误识别** | "嗯"→"恩"、"哦"→"喔" | 删除或修正 |
| **地名/人名错** | "伊朗"→"一朗"、"马斯克"→"马斯科" | 需常识或背景知识修正 |

> **[v3.2.2] 繁简混用已消除**——转录输出已全部转为简体中文，此条不再需要手动处理。

#### 修正方法论

1. **语义还原**：不看单个错字，看整句意思还原（"运用效率" → "运营效率"）
2. **行业校验**：用行业术语清单校验（民宿术语：入住率/OTA/客单价/复购率）
3. **交叉验证**：同一个观点在不同视频中出现，用多源互校
4. **质量优先**：先修正 high_quality（>500字符）的转录，low_quality基本是噪音可忽略
5. **标记保留**：不确定的修正用 `[?]` 标注，方便后续核实

#### 输出文件
- `knowledge_base_full.md`：原始转录合并（带时间戳）
- `knowledge_base_refined.md`：Agent提炼版（谐音修正+结构化+标注不确定项）

**建议知识库结构**：
1. 概述/背景
2. 核心观点汇总（按关键词分组，参考kw_map.json）
3. 与其他来源交叉验证
4. 分歧点分析
5. 数据质量说明（参考quality_report.json）
6. `[?]` 标注项汇总（需人工核实）

## 技术原理

**搜索**：脚本通过CDP"遥控器"连接Chrome → 导航到搜索页 → 智能等待加载 → 提取首页全部视频ID

**URL提取**：创建新后台tab → 监听网络请求拦截音频URL → CDP断连自动重试 → 关闭tab

**下载**：curl + Referer + User-Agent。优先纯音频流，其次完整视频。>1MB已下载文件自动跳过。断线自动续传重试3次（curl -C -）。

**转录**：whisper base模型 → `initial_prompt`引导输出带标点的中文 → 内置繁→简映射表自动转换 → 转录前深度停播抖音视频 → 实时质量分级 → 自动生成质量报告

**验证码**：每处理一个视频前检查是否有验证码页面 → 自动等待最多120秒

**防封策略**：不滚动页面，只取首页。关键词间随机等待20-40秒。CDP断连自动重试3次。下载断线自动续传重试3次。

## 常见问题速查

| 问题 | 原因 | 解决 |
|------|------|------|
| CDP WebSocket连接失败 | 缺 `--remote-allow-origins=*` | Chrome启动必须加此参数 |
| 关键词搜索失败（CDP断连） | WebSocket超时 | 自动重试3次，--max-retries可调 |
| navigate无响应 | 未确认Page.enable | v3.1已自动处理 |
| 搜索0结果 | 未登录 / 抖音风控 | 确认Chrome已登录抖音 |
| 验证码拦截 | 频繁请求 | 增大video-interval到20-30秒 |
| URL提取0个 | SPA加载慢 | extract-timeout增大到20-30秒 |
| 脚本启动就报错 | Chrome未启动/未登录 | CDP健康检查会提示具体问题 |
| 转录期间CPU被视频占 | 抖音tab自动播放 | 深度停播（iframe+shadowDOM+MutationObserver） |
| Python输出不实时 | stdout缓冲 | 用 `python -u` |
| `python` 命令被QClaw shim污染 | shim替换 | 用 `C:\Python312\python.exe` |
| 下载403 | 缺Referer | 脚本已内置 |
| **转录无标点** | **whisper默认不输出中文标点** | **[v3.2.2] 已自动加标点（initial_prompt），默认开启** |
| **转录含繁体字** | **whisper有时输出繁体** | **[v3.2.2] 已自动繁→简转换（内置1100+映射表），零额外依赖** |
| **依赖安装繁琐** | 多个组件需逐一安装 | 一键安装: `powershell -File scripts/install_deps.ps1` |
| **转录错别字多** | whisper中文识别率85% | 参考转录修正指南，必须修正谐音错字 |
| **下载断了不重试** | 网络波动导致下载中断 | 自动续传重试3次（--dl-retries），curl -C -断点续传 |
| **模型下载慢** | whisper模型国内下载慢 | 用国内镜像: `install_deps.ps1 -Mirror` 或 `$env:HF_ENDPOINT='https://hf-mirror.com'` |

## 输出结构

```
output/
├── all_video_ids.json          ← 视频ID累积（含关键词标记）
├── audio_urls.json              ← URL映射（dict格式）
├── dl_progress.json             ← 下载进度（dict格式）
├── collection_results.json      ← 采集结果摘要
├── kw_map.json                  ← 关键词→视频ID映射（自动生成）
├── collection_summary.json      ← 采集摘要（关键词成功率+去重率+耗时）
├── audio/                       ← 音频/视频文件
│   └── {video_id}.mp4
├── transcripts/                 ← 转录文本（已加标点+已繁→简）
│   ├── {video_id}.txt           ← 单条转录（带时间戳+标点+简体）
│   ├── {video_id}.txt.failed    ← 失败标记
│   ├── organized_by_keyword.json ← 按关键词组织
│   ├── quality_report.json      ← 转录质量报告（low/medium/high分级）
│   └── transcription_summary.json ← 转录摘要（含繁→简转换统计）
└── knowledge_base/
    ├── knowledge_base_full.md      ← 原始转录合并
    └── knowledge_base_refined.md   ← Agent提炼版（谐音修正+结构化）
```

## 采集节奏建议

| 场景 | 关键词间等待 | video-interval | 说明 |
|------|-------------|---------------|------|
| 快速验证 | 随机20-40s | 10 | 首页全量 |
| 标准采集 | 随机20-40s | 15 | 首页全量 |
| 深度采集 | 随机20-40s | 20 | 首页全量 |
| 防封谨慎 | 随机20-40s | 30 | 首页全量 |

**原则**：
1. 不滚动，每个关键词只取首页视频
2. 每个行业至少8个关键词（强关联、热门词汇）
3. 关键词间随机等待20-40秒，视频间间隔15-30秒
4. CDP断连自动重试3次

## 注意事项

- 必须先在Chrome中登录抖音（扫码登录），否则搜索0结果
- 脚本启动前自动CDP健康检查——Chrome+抖音tab+验证码
- 每个行业至少8个关键词，覆盖行业全貌
- 关键词间随机等待20-40秒，模拟人类操作防封
- 只取首页视频（不滚动）
- kw_map.json自动生成，转录时可直接用--kw-map参数
- 转录前深度停播抖音视频
- 中断后重跑自动跳过已完成项
- 转录失败可用`--retry-failed`重试
- **[v3.2.2] 转录自动加标点符号（initial_prompt，默认开启，--no-punctuation可关）**
- **[v3.2.2] 繁体→简体自动转换（内置1100+映射表，零额外依赖）**
- **[v3.1.9] 转录完成后仍需修正谐音错字（参考"转录修正指南"）**
- Chrome启动必须加 `--remote-allow-origins=*`
- **[v3.2.0] 模型下载慢？用国内镜像: `powershell -File scripts/install_deps.ps1 -Mirror`**
- **[v3.1.9] 一键安装依赖: `powershell -File scripts/install_deps.ps1`**
- **[v3.1.9] 一键运行: `python -u scripts/run_all.py --keywords "关键词1,关键词2"`**
- **[v3.1.9] 下载断线自动续传重试3次，网络波动不怕（--dl-retries可调）**

## 案例展示：外卖行业实战

用本技能搜索「外卖经营/外卖运营/外卖创业/外卖选址/外卖配送/外卖营销/外卖利润/外卖骑手」8个关键词：

### 采集规模
| 指标 | 数值 |
|------|------|
| 关键词 | 8个 |
| 搜索成功率 | 5/8（62.5%→v3.1.8修复后100%） |
| 音频下载 | 106个（445MB） |
| 转录 | 107个（29万字符） |

### 核心发现
- 选址定生死：避开主干道，选3公里内成熟小区+学校+写字楼
- 定价陷阱：涨价1元可能少赚1元+（红包档位+抽佣联动）
- 运营体系：先看数据→优化前台→再推广
- 创业路径：先做家庭外卖（500元成本）验证再开店

## 案例展示：高考备战知识采集

3关键词（高考备战/高考冲刺/高考复习方法），14条视频转录：

- 心态篇：撕掉标签→日目标拆解→短期成就感循环
- 一轮总策略：文理分策(语英刷套卷+数理只做专题)
- 复读生五大铁律：回归课本→错题分类→碎片检索→跨科知识树→限时训练

## 版本历史

- **v3.2.2**：2026-07-16 转录质量2项改进
  - 转录自动加标点符号（initial_prompt引导Whisper，默认开启）
  - 繁体→简体自动转换（内置1100+映射表，不依赖opencc）
- **v3.2.0**：2026-07-12 基于5维度评审意见的4项改进
  - [可信任度] 国内镜像源加速（install_deps.ps1 -Mirror）
  - [适用性] 触发词扩充（5→9个）
  - [适用性] 前置要求醒目化（⚠️警示+适用边界声明）
  - [适用性] 适用边界声明（仅抖音+转录85%需修正）
- **v3.1.9**：2026-07-11 四条评审意见驱动6项改进
  - [适用性] 触发词精化（移除泛词，改为抖音专属触发词）
  - [适用性] 一键运行脚本（run_all.py）
  - [有效性] 依赖一键安装（install_deps.ps1）
  - [规范性] 术语通俗化（术语速查表）
  - [有效性] 转录修正指南强化（谐音错误模式表+修正方法论+[?]标注）
  - [可靠性] 下载断线续传重试（--dl-retries 3，curl -C -）
- **v3.1.8**：2026-07-05 外卖行业实战9项改进
  - CDP断连重试 + 智能加载检测 + 深度停播 + kw_map + 质量分级 + 去重报告 + retry-failed + 摘要自动生成 + CDP健康检查
- **v3.1.4**：2026-07-05 首页全量+随机等待+8关键词规则
- **v3.1.3**：2026-07-04 新增实战案例
- **v3.1.2**：2026-07-04 品牌更新
- **v3.1.1**：2026-07-04 bug修复
- **v3.1.0**：2026-07实战优化
- **v3.0.4**：原始版本
