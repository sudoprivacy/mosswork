trigger: 恢复真实交接、新会话或跨会话独立审查
budget: 1300
next: 一致则回 m-build；不一致则停止并零写

# 恢复流程

先核对交接假设与差异，只恢复继续当前 Task 所需的最小上下文；任何写入授权绑定到计划身份、
AC、TC 和验证。

1. 按 `AGENTS.md` -> `ai/NEXT.md` **头部** -> `ai/HANDOFF.md` -> 当前 Task 的顺序读取；NEXT 头部
   之外的内容**按引用读取**，长材料只沿交接中的路径按需读取。
2. **恢复前必须重新取证（AC-AT-2）**：重跑 `date` 取当前盘钟，重读 `git HEAD`、`ai/NEXT.md` 与
   工作区状态，禁止沿用会话内的过期时间或状态。用 `tools/approval.py freshness_problem` 比对交接
   的 `reverify_at` 与刚取到的当前时间——陈旧时停止，要求重跑验证而非按旧值继续。
3. 对照当前项目检查 `plan_commit`、`plan_revision`、Task/状态、分支、HEAD、工作区状态、允许范围
   和验证。缺失、冲突或陈旧时停止，报告差异且零写；不得按旧交接覆盖当前事实。
4. 一致时恢复最小上下文（**NEXT 头部 + 按引用走**，不整篇加载），并路由到唯一当前入口。实现或
   恢复执行交给 `m-build`；需重新塑形或规划时分别路由到对应主流程入口。
5. 跨会话独立审查只读取交接指定的固定 artifact HEAD 和审查范围，不接管实现，不修改被审查产物。

## 失败修复与阶段沉淀

若 HANDOFF 包含失败修复，接手前核对并原样保留唯一 Lesson Check、consulted Registry revision 和
`registry pending` 状态；三者与当前事实冲突、把 pending 写入 Passport 或把 Deprecated 当作即时
Lesson Check 时停止并零写。同一 Agent 连续工作没有 HANDOFF 时直接回到 `m-build`。

若交接声明是真实交接（而非同一 Agent 连续推进），接手前核对交接中的阶段沉淀检查（L-013）：
`lessons` / `capability` / `docs` 三类各取 `record` / `none` / `no-new-deposit`；调用 m-build 的
`skills/m-build/scripts/lesson_gate.py phase_completion_blocked` 判定——记录缺失或非法时停止并
零写，不得据以继续。对照当前事实检查 `reverify_at` / 交接日期是否新鲜，陈旧则要求重跑而非按旧值
继续。

本 Skill 不认领隐藏任务、不执行 Task、不启动子 Agent，也不伪造交接有效性；不写 `CLAUDE.md` 或
`ai/lessons.md`。
