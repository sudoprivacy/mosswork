---
name: skillhub-skill-mtp-m-take
description: "monster 的 MTP 0.2.4 接棒入口。恢复真实交接、新会话或跨会话独立审查时使用。"
---

# M-Take

```mermaid
flowchart LR
  A["读交接"] --> B["核对身份"] --> C["路由当前工作"]
```

## Version Preflight

读取前核对 `$SKILL_DIR/MTP_VERSION` 和 `ai/mtp.json`。manifest 缺失、profile
不是 `lightweight`、缺少有效 `project_id` / `registry_id` 或版本不匹配时，返回
`m-new` 且零写。只有完整 Bundle `0.2.4` 项目才继续。

同一 Agent 在同一会话连续工作或接收同会话子 Agent 结果时不要使用本 Skill，直接回到 `m-build`。

## 读哪块

恢复流程、陈旧检查与阶段沉淀校验全部在 `blocks/restore.md`。

四原则：Think Before Coding / Simplicity First / Surgical Changes / Goal-Driven Execution。

## 硬要求

1. 顺序：`AGENTS.md` → `ai/NEXT.md` 头部 → `ai/HANDOFF.md` → 当前 Task；NEXT 头部之外按引用
   读取，只恢复最小上下文。
2. 恢复前必须重新取证（`date`、`git HEAD`、工作区），禁止沿用会话内过期状态。
3. 缺失、冲突或陈旧时停止，零写并报告差异，不按旧交接覆盖当前事实。
