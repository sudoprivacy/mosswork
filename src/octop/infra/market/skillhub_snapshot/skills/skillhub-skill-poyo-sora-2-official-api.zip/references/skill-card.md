## Description: <br>
Sora 2 Official video generation on PoYo / poyo.ai via `https://api.poyo.ai/api/generate/submit`; use for `sora-2-official`, text-to-video, optional single-image guided video, 4/8/12/16/20 second duration, vertical or landscape video, polling, and webhooks. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External developers and agents use this skill to prepare and submit PoYo Sora 2 Official text-to-video or single-image guided video jobs, then track completion through polling or webhooks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: PoYo API keys can be exposed if copied into browser code, logs, screenshots, public repositories, or chat output. <br>
Mitigation: Keep `POYO_API_KEY` in server-side environment variables or a backend secret manager and avoid echoing secrets in generated commands or reports. <br>
Risk: Live submissions send prompts, image URLs, and callback URLs to an external PoYo API. <br>
Mitigation: Submit only after explicit user approval from a trusted server-side environment, and avoid confidential source images or private URLs unless the user accepts that external processing. <br>
Risk: Generated payloads may use model-specific fields that change over time. <br>
Mitigation: Verify current PoYo field support before relying on duration, aspect ratio, image URL, polling, or webhook options in production. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/coolhackboy/skills/poyo-sora-2-official-api) <br>
- [PoYo Sora 2 Official model page](https://poyo.ai/models/sora-2-official) <br>
- [PoYo Sora 2 Official API docs](https://docs.poyo.ai/api-manual/video-series/sora-2-official) <br>
- [PoYo Sora 2 Official API reference](references/api.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with JSON payload examples and shell command snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include model id, request mode, duration, aspect ratio, payload summary, task id after submission, and the next polling or webhook step.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
