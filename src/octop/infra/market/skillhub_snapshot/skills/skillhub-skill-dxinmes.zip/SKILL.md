---
name: skillhub-skill-dxinmes
description: "鼎信微MOM（MES）条码打印/标签设计前端开发方法论。当用户要求修改 barcode.html（物料条码打印/预览调整/纸张布局/二维码条形码切换/打印弹窗/标签裁剪修复/字段显示选择/条码宽高调整）时使用。覆盖 Code39+QR纯本地渲染、实时滑块调整（偏移/缩放/宽高）、字段checkbox选择+位置+字号、scale/bh解耦、Grid纸张排版、window.open打印预览弹窗。适用于 D:\\ML-DEMO\\templates\\barcode.html（6001）或 D:\\MES系统\\templates\\barcode.html（5000）的 barcode 相关开发。"
---

# 条码打印设计（Code SPR）— barcode.html 开发方法论

## 文件结构

`templates/barcode.html` — 单文件纯前端（无框架依赖），约 1700+ 行：

| 区段 | 内容 |
|------|------|
| CSS 样式 | 内联 `<style>`，含 print-settings / badge / Grid / @media print |
| Tab 导航 | material(BOM物料) / pcb / BOM批量 / 其他 / custom |
| 物料标签 Tab | 表单(编码/名称/规格/供应商/批次/日期/数量) + 调整滑块 + 预览区 + 打印设置 |
| 打印参数 | 纸张宽高/每排张数/间距 + 条码偏移/缩放/宽高 + 标签模板选择(小/中/大/料盘) |
| JS 函数 | 约 50 个函数：renderCode39/renderQRCode/loadMaterialInfo/mat_* |

## 物料标签 Tab（核心设计模式）

### 1. 物料信息自动带出

```javascript
function loadMaterialInfo(){
  const code = mat_materialCode.value.trim();
  fetch('/api/material/list?keyword='+encodeURIComponent(code))
    .then(r=>r.json()).then(j=>{
      const item = j.data.find(m=>m.code===code);
      if(item){
        mat_materialName.value = item.name||'';
        mat_spec.value = item.specification||'';
        mat_supplier.value = item.supplier||item.supplier_code||'';
      } else showMsg('未找到该物料','error');
    });
}
```

**关键约定**：
- 供应商字段：`item.supplier || item.supplier_code`（名称优先，编码兜底）
- API端点 `/api/material/list` 返回 `data[]`，每条含 code/name/specification/supplier/supplier_code
- 输入框 `onblur` 触发，自动带出 readonly 字段

### 2. 条码类型切换（Code39 ↔ QR）

```html
<select id="mat_barcodeType" onchange="mat_onBarcodeTypeChange()">
  <option value="code39">条形码(Code39)</option>
  <option value="qr">二维码(QR)</option>
</select>
```

**mat_onBarcodeTypeChange()** 职责：切换类型 → 复位宽高默认值（Code39:h=15, QR:w=h=50）→ `mat_applyAdjust()` + `mat_previewBarcode()`

### 3. 条码渲染（纯本地 JS，零外网）

**Code39**：`renderCode39(text)` → 二进制模块编码 → SVG rects。支持 A-Z/0-9/-.$/+%/空格。

**QR Code**：`QRCodeGen.render(text, opts)` — 自实现 IIFE 模块（~480行），ISO 18004 标准。Byte模式、EC Level M、自动版本选择(1-10)、Reed-Solomon 纠错、8种掩码评估。

**QR 正方形强制**：`w=h=bw`，三处统一处理（`mat_applyAdjust`/`mat_previewBarcode`/`mat_printBarcode`）。

### 4. 预览调整控件

```javascript
function mat_getAdjust(){
  return {
    ox: parseInt(mat_offsetX.value)||0,   // 水平偏移 px
    oy: parseInt(mat_offsetY.value)||0,   // 垂直偏移 px
    sc: parseInt(mat_scale.value)||100,    // 缩放 %
    bw: parseInt(mat_bcWidth.value)||50,   // 条码宽 mm
    bh: parseInt(mat_bcHeight.value)||15   // 条码高 mm
  };
}
```

**mat_applyAdjust()**：读取 slider → 更新数值显示 → 遍历 `.barcode-card` 设置 `transform: translate(ox,oy) scale(sc)` → 设置内部 SVG `width/height`。

**mat_resetAdjust()**：所有滑块归默认值，调用 mat_applyAdjust()。

**所有滑块 `oninput="mat_applyAdjust()"` 实时生效**。

### 5. 打印预览弹窗

```javascript
function mat_printBarcode(){
  // 1) 校验 code + batch 必填
  // 2) 读 layout = mat_getLayout()  → {pw, ph, cols, gx, gy}
  // 3) 读 adjust = mat_getAdjust()  → {ox, oy, sc, bw, bh}
  // 4) 生成标签 HTML：循环 copies × qty，每个标签含 SVG + 物料信息
  // 5) window.open() → 写入完整 HTML + 内联 CSS
}
```

**弹窗核心 CSS**：
```css
*{box-sizing:border-box}
body{overflow-x:auto}
.labels-wrap{
  display:grid;
  grid-template-columns:repeat(N, Wmm);
  gap:Ymm Xmm;
  width:max-content;
  margin:0 auto
}
.label-card{
  width:Wmm; height:Hmm;
  padding:1mm; box-sizing:border-box;
  border:1px dashed #ccc
}
.label-card svg{max-width:100%;flex-shrink:0;display:block;margin:0 auto}
.lc-text{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}
@media print{
  .btn-bar,.preview-header{display:none!important}
  .label-card{border:0!important}
}
```

**打印关键**：`window.print()` → 500ms 后 `window.opener.mat_afterPrint()` → 记录历史。

### 6. 纸张布局

```javascript
function mat_getLayout(){
  return {
    pw: parseInt(mat_paperW.value)||50,   // 纸张宽 mm
    ph: parseInt(mat_paperH.value)||30,   // 纸张高 mm
    cols: parseInt(mat_cols.value)||1,    // 每排张数
    gx: parseInt(mat_gapX.value)||3,      // 水平间距 mm
    gy: parseInt(mat_gapY.value)||3       // 垂直间距 mm
  };
}
```

### 7. 显示字段选择

```javascript
function mat_getFields(){
  const pos=document.querySelector('input[name="mat_textPos"]:checked');
  return {
    show: { code: mat_showCode.checked, name: mat_showName.checked, ... },
    pos: pos?pos.value:'bottom',   // 'top'|'bottom'
    fs: parseFloat(mat_textSize.value)||7     // 5-20pt
  };
}
```

**约定**：7个checkbox默认全选（物料编码/名称/规格/供应商/批次/生产日期/有效期），位置默认下方，字号默认7pt。checkbox的onchange触发mat_previewBarcode实时刷新。打印弹窗同样读取mat_getFields()。

### 8. scale/bh 解耦（关键陷阱）

**陷阱**：scale缩放被应用到整个barcode-card → bh=15mm的条码被scale=200%放大到30mm。

**修复**：barcode-card的transform只保留translate(ox,oy)，scale单独应用到内部`.barcode-svg-wrap`。bh控制SVG物理高度，scale控制显示缩放，两者独立。

## 常见陷阱

### 预览裁剪 Bug
- **SVG 未适配容器** → 加 `max-width:100%` + `flex-shrink:0`（**不用 height:auto，会覆盖 inline height**）

### scale/bh 耦合
- scale 必须只在 SVG wrapper 上，**不得**应用到 barcode-card 整体

### 标签 SVG 高度被 CSS 覆盖
- `.label-card svg{height:auto}` 会覆盖 inline `style="height:bh mm"` → 改为 `flex-shrink:0`

### preserveAspectRatio 宽高比陷阱（Code39 bh 不生效根因）
- Code39 SVG viewBox 宽高比(~4.4) 与 bw/bh 设定比不匹配，浏览器默认 `preserveAspectRatio="meet"` 等比缩放导致高度不达 bh
- **修复**：Code39 注入 `preserveAspectRatio="none"` 强制拉伸到 bw×bh；QR 保持默认 meet

改前备份铁律
```
copy templates\barcode.html templates\barcode.html.bak
# 改完重启
python start_mldemo.py --no-browser
```
