# z-index（技能目录 · 发现层）

一句话：z-系列的目录与解释器——扫描本机技能安装位，分类列示单体/流程/发现技能并给解释型描述，流程技能附流程图；其他本地技能忠实转述、零加戏。

## 何时使用

说"技能目录、有哪些技能、列出技能、找技能、搜索技能、这个系列有什么"，或不知道该用哪个 z 技能时触发。

## 用法速览

- 问法：「有哪些 z 技能」「技能目录」「我想做 X，用哪个技能」「z-flow-kickoff 的流程是什么样」
- 用法卡：聊天说 `z-index help`，ZCode 下 `/z-index-help` 直达
- 预期：单轮即答；扫描范围永远如实声明（用户级+项目级；不含插件与内置技能）

## 核心机制

- **三层架构的发现层**：发现（z-index，有什么/是什么）→ 编排（z-flow-*，按什么顺序串）→ 功能（单体 z-*，具体实现）。
- **分类呈现**：单体技能（名称/版本/定位/问法/help 命令）；流程技能另附流程图与逐步解释（原样引用其 SKILL.md 关系图，单一事实源不另绘）。
- **其他本地技能**：集中列示 + frontmatter 描述忠实转述，标注来源；不加戏、不评价、不推测用法（宁缺勿编）。
- **意图指路**："我想做 X 用哪个"按问法公式（对象+意图+边界）匹配候选，不唯一就列出让用户选。

## 与 z-系列的关系

```
z-index（本 skill：发现层）→ z-flow-kickoff（编排层）
                              └─ 单体技能（pyramid/clarify/chain/assess/init）
```

命名规则即分类：`z-<能力>`=单体、`z-flow-<里程碑>`=流程、`z-index`=发现；从技能名即可分辨层级。

## 安装

### ZCode（推荐：随系列整装，symlink 安装）

```bash
git clone https://github.com/zimy0033/z-skill-series.git ~/z-skill-series
bash ~/z-skill-series/install.sh
```

install.sh 把 `skills/*` 以 symlink 装入 `~/.zcode/skills/`（help 命令装入 `~/.zcode/commands/`），并自动清理指向本仓库的失效旧链接；更新只需 `git -C ~/z-skill-series pull`，无需重装。

### 单独安装（任一 agent）

把 `skills/z-index` 目录复制到目标 agent 的 skills 目录（ZCode 用户级 `~/.zcode/skills/`，项目级 `<项目>/.zcode/skills/`）。安装后重启会话生效。skills CLI 子路径安装：`npx skills add zimy0033/z-skill-series/skills/z-index`。

## License

MIT
