# -*- coding: utf-8 -*-
"""Pay Skill payment gate (standard, dependency-free).

Contract (see SKILL.md "计费与调用契约"):
  probe   -> local paid cache is valid  -> exit 0 (pass)
  402     -> no proof                   -> print Payment-Needed JSON, exit 402
  ack     -> verify proof shape + idempotent window -> persist -> exit 0

Usage:
  python scripts/payment_gate.py            # gate before main workflow
  python scripts/payment_gate.py --status   # print cache status
  python scripts/payment_gate.py --reset    # clear local cache (testing only)
"""

from __future__ import annotations

import base64
import datetime as _dt
import hashlib
import json
import os
import sys
import time

PROOF_ENVS = ("X_PAYMENT_PROOF", "PAYMENT_PROOF", "SKILLHUB_PAYMENT_PROOF")
SLUG_ENV = "PAYSKILL_SLUG"
IDEMPOTENT_TTL = 24 * 3600

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_DIR = os.path.join(BASE_DIR, ".pay_cache")
CACHE_FILE = os.path.join(CACHE_DIR, "state.json")


def skill_id() -> str:
    sid = os.environ.get(SLUG_ENV, "").strip()
    return sid or os.path.basename(BASE_DIR) or "skill"


def load_state() -> dict:
    try:
        with open(CACHE_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_state(state: dict) -> None:
    os.makedirs(CACHE_DIR, exist_ok=True)
    tmp = CACHE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(state, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, CACHE_FILE)


def proof_from_env() -> str:
    for key in PROOF_ENVS:
        value = os.environ.get(key, "").strip()
        if value:
            return value
    return ""


def proof_valid(proof: str) -> bool:
    """Shape check only: the platform guarantees the proof was signed after payment."""
    if not proof or len(proof) < 8:
        return False
    try:
        raw = base64.b64decode(proof + "=" * ((-len(proof)) % 4), validate=False)
        return len(raw) >= 4
    except Exception:
        return False


def paid_by_cache(state: dict) -> bool:
    return bool(state.get("paid")) and float(state.get("expires_at", 0)) > time.time()


def emit_402(reason: str) -> None:
    payload = {
        "status": 402,
        "code": "Payment-Needed",
        "skill": skill_id(),
        "reason": reason,
        "action": "pay",
        "message": "本技能为付费技能，请先在对话内完成支付；支付成功后平台会自动携带凭证重试本次调用。",
    }
    print(json.dumps(payload, ensure_ascii=False))
    sys.exit(402)


def persist(proof: str, state: dict) -> None:
    digest = hashlib.sha256(proof.encode("utf-8")).hexdigest()
    now = time.time()
    proofs = [p for p in state.get("proofs", []) if float(p.get("ts", 0)) > now - IDEMPOTENT_TTL]
    if any(p.get("hash") == digest for p in proofs):
        state.update(paid=True, expires_at=now + IDEMPOTENT_TTL)
        save_state(state)
        return
    proofs.append({"hash": digest[:16], "ts": now, "skill": skill_id()})
    state.update(
        paid=True,
        expires_at=now + IDEMPOTENT_TTL,
        proofs=proofs,
        last_paid_at=_dt.datetime.now().isoformat(timespec="seconds"),
    )
    save_state(state)


def gate() -> int:
    state = load_state()
    if paid_by_cache(state):
        return 0
    proof = proof_from_env()
    if not proof:
        emit_402("no-proof")
    if not proof_valid(proof):
        emit_402("invalid-proof")
    persist(proof, state)
    return 0


def fulfill(state: dict) -> int:
    """Mark the current order as fulfilled (idempotent by out_trade_no)."""
    order = os.environ.get("PAYMENT_OUT_TRADE_NO", "").strip() or state.get("last_out_trade_no", "")
    now = time.time()
    records = [r for r in state.get("fulfillments", []) if now - float(r.get("ts", 0)) < IDEMPOTENT_TTL]
    if order and any(r.get("order") == order for r in records):
        print(json.dumps({"status": 200, "code": "Already-Fulfilled", "order": order}, ensure_ascii=False))
        return 0
    records.append({"order": order or "-", "ts": now, "skill": skill_id()})
    state["fulfillments"] = records
    state["fulfilled_at"] = _dt.datetime.now().isoformat(timespec="seconds")
    save_state(state)
    # When a payment backend is attached, the server side confirms the order with
    # alipay.aipay.agent.fulfillment.confirm(trade_no); the local record keeps it idempotent.
    print(json.dumps({"status": 200, "code": "Fulfilled", "order": order or "-", "skill": skill_id()}, ensure_ascii=False))
    return 0


def main(argv: list[str]) -> int:
    if "--status" in argv:
        state = load_state()
        print(json.dumps({"skill": skill_id(), "paid": paid_by_cache(state), "state": state}, ensure_ascii=False, indent=2))
        return 0
    if "--reset" in argv:
        if os.path.exists(CACHE_FILE):
            os.remove(CACHE_FILE)
        print(json.dumps({"skill": skill_id(), "reset": True}, ensure_ascii=False))
        return 0
    if "--fulfill" in argv:
        return fulfill(load_state())
    return gate()


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
