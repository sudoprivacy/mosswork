#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""起重机械安全体检卡 · 体检引擎（纯标准库，无网络）

6 类起重机共用一套「通用体检项」，各设备再叠加「专属体检项」。
这样同一份标准下，既能通用体检，又能查到每类设备的差异化要求。

覆盖：塔式起重机 / 龙门起重机 / 架桥机 / 汽车起重机 / 履带起重机 / 桥式（行吊）

用法：
  python checkup.py --list                      # 设备总览
  python checkup.py --device 塔式起重机          # 生成体检卡
  python checkup.py --device 汽车起重机 --out 体检卡.md
  python checkup.py --common                    # 只看通用体检项
  python checkup.py --check 自查.txt             # 逐项判定
  python checkup.py --audit 台账.csv             # 多机台账批量体检
  python checkup.py --cases 塔吊                 # 同类事故案例
"""
import argparse
import csv
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(os.path.dirname(HERE), "data", "起重机条目切片.json")

MAJOR = "重大隐患"

# ---------------------------------------------------------------- 通用体检项（6类共用）
COMMON_ITEMS = [
    ("安全装置有效", "起重量/起重力矩限制器、高度/行程/回转/行走限位、防坠安全器、急停开关、抗风防滑装置是否齐全有效", "REQ101/REQ131/REQ157", MAJOR),
    ("主体结构完好", "主梁/塔身/支腿/臂架等受力结构件有无裂纹、变形、锈蚀超标", "REQ102", MAJOR),
    ("人员持证上岗", "司机、起重指挥、司索工是否持有效证件", "REQ103", MAJOR),
    ("专项方案与交底", "是否编制专项方案、是否交底到人、是否专家论证（超规模）", "REQ105/REQ170④", MAJOR),
    ("警戒隔离与指挥", "吊装危险区域是否设警戒隔离、是否设专职指挥", "REQ105", MAJOR),
    ("钢丝绳状态", "是否按 GB/T 5972-2023 判废（断丝10%/直径-7%/磨损40%）", "REQ160/REQ156", MAJOR),
    ("索具配套合规", "绳卡是否合规（夹座压主绳、无滑移）；滑轮是否超标", "REQ161", "缺陷"),
    ("吊装带合规", "是否用色标吊装带、白色吊带禁用、破断力≥6倍WLL", "REQ162/REQ163", MAJOR),
    ("许可与检验", "是否取得许可生产、是否经监督检验合格、是否超期未检", "REQ130", MAJOR),
    ("淘汰报废", "是否使用淘汰目录内设备、是否超设计年限未评估", "REQ104", MAJOR),
    ("十不准纪律", "是否交底十不准（超载/斜吊/吊物站人/六级风等）", "REQ158", "缺陷"),
    ("检维修闭环", "是否定期检查并有书面限期整改与复查闭环", "REQ157", "缺陷"),
]

# ---------------------------------------------------------------- 各设备专属体检项
DEVICE_ITEMS = {
    "塔式起重机": [
        ("顶升加节控制", "顶升人员固定（禁临时拼凑）、每次顶升后双侧爬爪压踏步双确认方可回缩油缸", "REQ155", MAJOR),
        ("顶升旁站与安全带", "顶升全程专职安全员旁站、作业人员全程系挂安全带", "REQ155", "缺陷"),
        ("附着结构检查", "附着处及以上结构状态是否顶升前检查", "REQ155", "缺陷"),
        ("多塔作业防碰撞", "多塔作业是否专项方案审批、是否满足2m最小架设距离", "REQ158", MAJOR),
        ("安拆单位资质", "安拆单位是否具专业承包资质＋安全生产许可证、是否验收签字", "REQ158", MAJOR),
        ("防脱钩装置", "吊钩防脱钩装置是否完好（间隙<绳径20%）", "REQ157", "缺陷"),
        ("风速仪/障碍灯", "臂根铰点高>50m风速仪、塔顶>30m障碍指示灯是否装设", "REQ157", "缺陷"),
    ],
    "龙门起重机": [
        ("轨道锚固与平整", "行走轨道是否锚固可靠、轨道平整度是否符合要求", "REQ131/REQ105族经验", MAJOR),
        ("抗风防滑装置", "室外轨道式抗风防滑装置是否齐全有效（判定重大隐患项）", "REQ131", MAJOR),
        ("夹轨器/锚定装置", "夹轨器、锚定装置是否完好可用", "REQ131", "缺陷"),
        ("大车行走限位", "大车行走限位、缓冲止挡是否有效", "REQ157", "缺陷"),
        ("轨道基础", "轨道基础有无沉降、轨距偏差是否超标", "REQ102族经验", "缺陷"),
    ],
    "架桥机": [
        ("防遛逸措施", "架梁作业是否采取可靠防遛逸措施（纵坡时防滑行、运梁平车设楔铁）", "REQ172⑥/REQ205③", MAJOR),
        ("防倾覆固结锚固", "是否按要求采取固结、锚固等防倾覆措施；收工时是否手拉葫芦固定、纵坡天车木楔塞住", "REQ172⑥/REQ205⑲", MAJOR),
        ("前支腿抄垫", "前支腿是否用合格钢支墩/枕木抄垫，横移走行梁下枕木是否呈『井』字架、木楔调整（严禁橡胶垫块代替）", "REQ172/REQ205⑥·H203案例", MAJOR),
        ("垫木/垫块规范", "中支腿边梁处垫木垛是否符合说明书、有无变形碎裂（禁用橡胶垫块、禁用不合规垫木）", "REQ205⑥·H204案例", MAJOR),
        ("纵坡与横坡控制", "主梁纵移纵坡是否<3%、带梁纵移（天车携梁）纵坡是否<1%；横移轨道是否水平平行、两轨道间距是否每次过孔检查", "REQ205③⑤⑫·H203案例", MAJOR),
        ("天车提升与携梁行走", "起吊天车提升与携梁行走是否严禁同时进行；携梁纵移时前支腿与横移轨道是否拉紧", "REQ205⑤⑧", MAJOR),
        ("过孔与喂梁", "过孔工序是否简化、零散构件是否捆绑扎牢；过孔前横隔板主筋连接是否组织验收；喂梁是否有规程与专人指挥", "REQ172族/REQ205⑨·H204案例", "缺陷"),
        ("试吊与验收", "架桥机是否经安全部组合验收＋试吊，取得验收合格证方可投用；是否设专人指挥/操作/电工/安全检查员并交底", "REQ205①·H203案例", MAJOR),
        ("吊具与安全装置", "卷扬/辅助支腿起升机构是否装高度限制器；吊具是否符合要求、有无高度限位缺失", "REQ205⑰·H202案例", MAJOR),
        ("恶劣天气与收工", "雨雪雾六级以上大风是否严禁作业、停工是否用缆绳稳固并切断电源；雷雨季是否设避雷装置", "REQ205⑮⑯", "缺陷"),
        ("行走限位与挡铁", "大车横移行走方梁两自由端是否设挡铁、行走轮是否配楔铁；纵横运梁轨道间距是否固定、限位是否可靠", "REQ205⑦⑱", "缺陷"),
        ("双导梁同步", "双导梁行走是否同步、有无偏移监控", "REQ105族经验", "缺陷"),
    ],
    "汽车起重机": [
        ("支腿与地基", "支腿是否全伸、垫木/钢支墩是否符合规范、地基承载力是否满足", "REQ111/REQ003案例", MAJOR),
        ("站位与幅度", "站位地形是否满足起升高度曲线、工作幅度是否合规", "REQ004案例", MAJOR),
        ("超载控制", "力矩限制器是否有效、司机是否无视超载报警", "REQ101/REQ001案例", MAJOR),
        ("取证口径", "司机/司索/指挥需特种作业操作证（2014年已移出特种设备目录，不需Q1/Q2）", "REQ134", "缺陷"),
        ("进场验收32项", "资料核查＋外观与安全装置＋支腿与作业条件是否逐项验收", "REQ111", MAJOR),
        ("吊装区域隔离", "回转半径内是否设警戒、有无人员靠近", "REQ005案例", MAJOR),
    ],
    "履带起重机": [
        ("双机抬吊协同", "抬吊是否同步、是否同一指挥、荷载分配是否符合方案（≤80%）", "REQ204案例/JTG F90", MAJOR),
        ("选型与机位", "选型与机位是否与方案一致、额定载荷是否满足", "REQ204案例", MAJOR),
        ("水平度控制", "机身水平度是否达标、是否超载作业", "REQ204案例", MAJOR),
        ("地基承载力", "履带下方地基是否满足接地比压要求、有无沉陷风险", "REQ102族经验", MAJOR),
        ("回转行走限制", "抬吊期间是否禁止独自回转行走", "REQ204案例", MAJOR),
    ],
    "桥式（行吊）": [
        ("制动装置", "起升/大车/小车制动装置是否工作正常", "REQ174①（同类要求）", MAJOR),
        ("防溜逸措施", "是否按要求设置防溜逸措施", "REQ174①", MAJOR),
        ("轨道与端部止挡", "轨道是否平直、端部止挡是否完好", "REQ102族经验", "缺陷"),
        ("限位与缓冲", "各方向限位、缓冲器是否有效", "REQ157", "缺陷"),
        ("遥控操作安全", "遥控操作有无误操作防护、有无司机确认", "REQ302案例", "缺陷"),
    ],
}

ALIASES = {
    "塔式起重机": ["塔吊", "塔机", "塔式起重机"],
    "龙门起重机": ["龙门吊", "龙门", "门式起重机", "门机"],
    "架桥机": ["架桥机", "运架", "架梁机"],
    "汽车起重机": ["汽车吊", "汽车起重机", "轮式起重机"],
    "履带起重机": ["履带吊", "履带起重机"],
    "桥式（行吊）": ["行吊", "行车", "桥式起重机", "天车", "单梁", "双梁"],
}

# ------------------------------------------------- 体检项别名表（现场口语 → 体检项全名）
# 现场填清单/台账时，仪表、班组、监理各用各的叫法；不能靠字面子串匹配。
# 每项列出 3~10 个现场常用写法；匹配时先归一化（去空格/全角括号/标点）再查。
ITEM_ALIASES = {
    "安全装置有效": ["安全装置", "安全装置是否齐全", "力矩限制器", "起重量限制器", "超载保护",
                     "限位器", "限位装置", "防坠安全器", "急停开关", "抗风防滑",
                     "行程限位", "回转限位", "高度限位", "安全保护装置"],
    "主体结构完好": ["主体结构", "主体钢结构", "钢结构", "金属结构", "受力构件",
                     "主梁", "塔身", "支腿结构", "臂架", "结构件"],
    "人员持证上岗": ["人员持证", "持证上岗", "操作证", "司机证", "特种作业证",
                     "指挥证", "司索证", "资格证", "持证情况"],
    "专项方案与交底": ["专项方案", "施工方案", "方案与交底", "安全交底", "技术交底",
                       "专家论证", "方案审批", "方案编制"],
    "警戒隔离与指挥": ["警戒隔离", "警戒", "隔离", "专职指挥", "指挥人员", "警戒区域",
                       "吊装区域隔离", "信号指挥"],
    "钢丝绳状态": ["钢丝绳", "钢丝绳判废", "断丝", "钢丝绳磨损", "钢丝绳损伤"],
    "索具配套合规": ["索具", "绳卡", "滑轮", "吊索具配套", "绳夹", "卡环", "卸扣"],
    "吊装带合规": ["吊装带", "吊带", "色标吊带", "白色吊带"],
    "许可与检验": ["许可", "使用登记", "监督检验", "检验合格", "定期检验", "年检", "检验报告"],
    "淘汰报废": ["淘汰", "报废", "淘汰目录", "超设计年限", "使用年限"],
    "十不准纪律": ["十不准", "作业纪律", "起重十不准", "纪律要求"],
    "检维修闭环": ["检维修", "维修闭环", "整改闭环", "复查", "限期整改", "维修记录", "检查记录"],
    # —— 专属项 ——
    "顶升加节控制": ["顶升加节", "顶升", "加节", "爬爪", "踏步", "顶升油缸", "顶升作业"],
    "顶升旁站与安全带": ["顶升旁站", "旁站", "安全带", "顶升安全带", "专职安全员旁站"],
    "附着结构检查": ["附着", "附着结构", "附墙", "锚固点检查"],
    "多塔作业防碰撞": ["多塔作业", "防碰撞", "群塔", "塔群", "两台塔吊", "架设距离"],
    "安拆单位资质": ["安拆单位", "安拆资质", "安装单位", "拆卸单位", "专业承包资质", "安拆"],
    "防脱钩装置": ["防脱钩", "吊钩", "脱钩装置", "吊钩保险"],
    "风速仪/障碍灯": ["风速仪", "风速计", "障碍灯", "障碍指示灯", "风速监测"],
    "轨道锚固与平整": ["轨道锚固", "轨道平整", "轨道基础沉降", "行走轨道"],
    "抗风防滑装置": ["抗风防滑", "防风装置", "防滑装置", "抗风装置", "夹轨器防滑"],
    "夹轨器/锚定装置": ["夹轨器", "锚定装置", "锚定", "铁鞋", "防风夹轨"],
    "大车行走限位": ["大车行走限位", "大车限位", "缓冲止挡", "大车缓冲", "行走限位"],
    "轨道基础": ["轨道基础", "轨距", "轨距偏差", "基础沉降"],
    "防遛逸措施": ["防遛逸", "防溜逸", "防滑行", "溜逸", "防溜", "楔铁"],
    "防倾覆固结锚固": ["防倾覆", "固结", "锚固措施", "手拉葫芦固定", "抗倾覆", "压重"],
    "前支腿抄垫": ["前支腿抄垫", "前支腿支承", "前支腿", "抄垫", "钢支墩", "支墩",
                   "枕木抄垫", "横移走行梁", "前支腿垫实"],
    "垫木/垫块规范": ["垫木", "垫块", "垫木垛", "木楔", "垫木规范", "中支腿边梁", "垫木质量"],
    "纵坡与横坡控制": ["纵坡", "横坡", "纵移坡度", "带梁纵移", "坡度控制", "横移轨道水平"],
    "天车提升与携梁行走": ["天车提升与携梁行走", "天车提升", "携梁行走", "提升与携梁",
                           "携梁纵移", "天车携梁", "同时进行"],
    "过孔与喂梁": ["过孔", "喂梁", "过孔工序", "零散构件", "横隔板主筋", "过孔验收"],
    "试吊与验收": ["试吊", "验收", "架桥机验收", "验收合格证", "组合验收", "专人指挥"],
    "吊具与安全装置": ["吊具", "高度限制器", "起升机构", "卷扬", "辅助支腿", "吊具安全"],
    "恶劣天气与收工": ["恶劣天气", "大风", "六级风", "雨雪雾", "停工", "收工",
                       "缆绳稳固", "避雷装置", "雷雨"],
    "行走限位与挡铁": ["行走限位与挡铁", "挡铁", "行走轮楔铁", "纵横运梁轨道", "运梁轨道间距"],
    "双导梁同步": ["双导梁", "导梁同步", "偏移监控", "导梁偏移"],
    "支腿与地基": ["支腿与地基", "支腿", "支腿全伸", "地基承载力", "垫板", "支腿垫木"],
    "站位与幅度": ["站位", "工作幅度", "起升高度曲线", "站位地形", "幅度", "作业半径"],
    "超载控制": ["超载", "力矩限制器报警", "超载报警", "超载保护", "超载控制"],
    "取证口径": ["取证", "操作证口径", "特种作业操作证"],
    "进场验收32项": ["进场验收", "32项验收", "设备验收", "进场检查"],
    "吊装区域隔离": ["吊装区域隔离", "回转半径警戒", "作业区域隔离", "警戒围栏"],
    "双机抬吊协同": ["双机抬吊", "抬吊", "抬吊同步", "双机协同", "抬吊方案"],
    "选型与机位": ["选型", "机位", "额定载荷", "选型与机位"],
    "水平度控制": ["水平度", "机身水平", "整机水平"],
    "地基承载力": ["地基承载力", "接地比压", "地基", "履带基础"],
    "回转行走限制": ["回转行走限制", "抬吊回转", "独自回转"],
    "制动装置": ["制动装置", "制动器", "刹车", "制动系统", "起升制动", "大车制动",
                 "小车制动", "制动器动作", "制动是否可靠"],
    "防溜逸措施": ["防溜逸", "防溜", "溜逸", "防滑"],
    "轨道与端部止挡": ["轨道与端部止挡", "端部止挡", "止挡", "轨道平直"],
    "限位与缓冲": ["限位与缓冲", "缓冲器", "限位开关"],
    "遥控操作安全": ["遥控操作", "遥控器", "误操作防护", "遥控制动"],
}


def canon_device(t):
    t = (t or "").strip()
    for k, al in ALIASES.items():
        if t == k or t == k.split("（")[0] or any(a in t for a in al):
            return k
    return None


def load_db():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def items_of(dev):
    return COMMON_ITEMS + DEVICE_ITEMS.get(dev, [])


def render(dev):
    L = []
    L.append(f"# 起重机械安全体检卡 · {dev}\n")
    L.append(f"> 依据：特种设备安全法、起重机械重大事故隐患判定准则4.7（REQ131）、"
             f"GB/T 5972-2023、危大工程严重缺陷清单等。\n")
    L.append(f"## 一、通用体检项（6 类起重机共用 · {len(COMMON_ITEMS)} 条）\n")
    L.append("| # | 体检项 | 体检要点 | 依据 | 等级 |")
    L.append("|--:|---|---|---|---|")
    for i, (it, desc, dep, lvl) in enumerate(COMMON_ITEMS, 1):
        flag = " 🔴" if lvl == MAJOR else ""
        L.append(f"| {i} | {it}{flag} | {desc} | {dep} | {lvl} |")
    spec = DEVICE_ITEMS.get(dev, [])
    L.append(f"\n## 二、{dev} 专属体检项（{len(spec)} 条）\n")
    if spec:
        L.append("| # | 体检项 | 体检要点 | 依据 | 等级 |")
        L.append("|--:|---|---|---|---|")
        for i, (it, desc, dep, lvl) in enumerate(spec, 1):
            flag = " 🔴" if lvl == MAJOR else ""
            L.append(f"| {i} | {it}{flag} | {desc} | {dep} | {lvl} |")
    else:
        L.append("（该设备暂无专属条款，按通用体检项执行）")
    n_major = sum(1 for x in COMMON_ITEMS + spec if x[3] == MAJOR)
    L.append(f"\n> 合计 **{len(COMMON_ITEMS) + len(spec)}** 条体检项，其中 🔴 标注 **{n_major}** 条不满足即构成**重大事故隐患**。")
    L.append("\n**体检结论口径**：🔴 项任一不通过 → 立即停用整改，属重大事故隐患；一般项不通过 → 限期整改并复查销号。")
    return "\n".join(L)


def cmd_list(args):
    print("# 起重机械安全体检卡 · 设备总览\n")
    print("| 设备 | 专属体检项 | 累计体检项 | 触发别名 |")
    print("|---|---|---|---|")
    for k, al in ALIASES.items():
        spec = len(DEVICE_ITEMS.get(k, []))
        print(f"| {k} | {spec} | {len(COMMON_ITEMS) + spec} | {'、'.join(al)} |")
    print(f"\n通用体检项 **{len(COMMON_ITEMS)}** 条，全设备共用；各设备叠加专属项，合计覆盖 **{len(ALIASES)}** 类起重机。")
    return 0


def cmd_device(args):
    dev = canon_device(args.device)
    if not dev:
        print(f"未识别设备「{args.device}」。支持：{'、'.join(ALIASES.keys())}", file=sys.stderr)
        return 2
    text = render(dev)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"体检卡已生成：{args.out}")
    else:
        print(text)
    return 0


def cmd_common(args):
    print("# 起重机械通用体检项（6 类共用）\n")
    print("| # | 体检项 | 体检要点 | 依据 | 等级 |")
    print("|--:|---|---|---|---|")
    for i, (it, desc, dep, lvl) in enumerate(COMMON_ITEMS, 1):
        flag = " 🔴" if lvl == MAJOR else ""
        print(f"| {i} | {it}{flag} | {desc} | {dep} | {lvl} |")
    return 0


NEG = ["无", "未", "否", "缺失", "没有", "失效", "超", "擅自", "不", "违规"]

# 正向表述：整句只描述「运转正常 / 已按规定办」，应判合格。
POSITIVE_PATTERNS = ["无漏检", "无缺失", "无异常", "无隐患", "无问题", "未发现", "未超", "未擅自",
                     "不缺失", "均有", "已按", "已设置", "已规定", "已编制", "齐全", "完好", "正常", "有效"]

# 强负词：命中即违规，即便句中含「无/未」等否定包装，也按违规判定（可被整句正向表述覆盖）。
STRONG_NEG = [
    # 合规性缺失
    "失效", "缺失", "擅自", "未设置", "未按", "未取得", "未检验", "未检测",
    "未组织", "未审批", "未编制", "未交底", "未验收", "未持证", "无证", "超期",
    "漏检", "未探伤", "未封闭", "未采取", "未落实", "未闭锁", "未挂牌", "未许可",
    # 量化超限
    "超限", "超速", "超载", "超标", "超过允许", "超设计",
    # 结构 / 机构缺陷（现象描述型，最易漏判）
    "裂纹", "裂缝", "变形", "严重锈蚀", "锈蚀超标", "腐蚀超标", "断裂", "开焊", "脱焊",
    "磨损超标", "磨损超限", "断丝超标", "断股", "直径减小超标", "沉降超标", "沉陷",
    "松脱", "松旷", "滑移", "倾斜超标", "扭曲", "塑性变形", "失稳", "碎裂", "氢脆",
    "整股断裂", "笼状畸变", "扭结", "压扁", "绳芯挤出", "热损伤", "熔融",
    # 安全装置状态
    "失灵", "损坏", "破损", "卡滞", "报警失效", "带病运转", "带病作业", "无高度限制器",
    # 作业行为
    "违规", "违章", "无票作业", "无监护人",
    # 现象类（用于否定组合剥离；本身命中亦违规）
    "溜逸", "偏移超限", "脱轨", "啃轨", "超温", "异响", "抖动", "渗漏", "漏油",
]

# ---------------------------------------------------------------- 恒定违规词（ABSOLUTE_BAN）
# 这类词本身即「禁止使用的做法」，无论句中是否出现「未/无」等否定前缀，只要出现即违规；
# 且**不得**被否定剥离逻辑吃掉（否则「未使用橡胶垫块」这类合规表述会被误判，
# 而「使用橡胶垫块」这类真违规会被误放行）。
# 注意：剥离时只允许「否定词 + 该词」整体作为一个合规短语被剥离——
# 但实践表明更稳的做法是：出现该词即违规，除非该词前紧邻否定词且句中无其他违规信号。
ABSOLUTE_BAN = [
    "橡胶垫块",          # 架桥机前支腿严禁橡胶垫块代替钢支墩（津保402倾覆事故直接诱因）
    "白色吊带",          # GB/T 8521 禁用白色吊装带
    "以次充好",
    "带病运转", "带病作业",
    "无证操作",
]

# ---------------------------------------------------------------- 语境规则（CONTEXT_RULES）
# 「同时进行」单独出现不构成违规信号（"两机同时进行"未必违规），
# 但在「天车提升 + 携梁行走」语境下，"同时进行" 即违反 REQ205⑤⑧（严禁同时进行）。
# ⚠️ 规则顺序铁律：**豁免规则（False）必须排在违规规则（True）之前**，
#    否则「未同时进行」会被「同时进行」的违规规则抢先命中。
# 规则形式：(触发正则, 是否违规, 说明)
CONTEXT_RULES = [
    # —— 豁免规则在前（双向匹配，语序不限）——
    (re.compile(r"(?:提升|携梁|起吊)[^，。；、,;]{0,8}未[^，。；、,;]{0,4}同时"
                r"|未[^，。；、,;]{0,4}同时[^，。；、,;]{0,10}(?:提升|携梁|起吊)"),
     False, "提升与携梁行走未同时进行，合规"),
    (re.compile(r"(?:提升|携梁|起吊)[^，。；、,;]{0,10}(?:错开|分别|先后|逐一|单独)[^，。；、,;]{0,4}(?:进行|作业|实施)"
                r"|(?:错开|分别|先后|逐一|单独)[^，。；、,;]{0,6}(?:提升|携梁|进行|作业)"),
     False, "提升与携梁行走错开进行，合规"),
    # —— 违规规则在后 ——
    (re.compile(r"(?:同时进行|同时作业|同步进行)[^，。；、,;]{0,12}?(?:提升|携梁|行走)"
                r"|(?:提升|起吊|携梁)[^，。；、,;]{0,12}(?:同时进行|同时作业|同步进行)"),
     True, "天车提升与携梁行走严禁同时进行"),
]

# 通用否定词（按长度降序，避免单字「未」吃掉「未发现」首字）
# ⚠️ 必须收录「未使用/未采用/未用」等**行为否定**，否则「未使用橡胶垫块」会被当成违规。
_NEG_WORDS = sorted(["未发现", "未出现", "未见到", "未见", "未使用", "未采用", "未用",
                     "不存在", "没有发现", "没有出现", "没有", "无", "未", "不", "非"],
                    key=len, reverse=True)

# 否定词 + 现象词：整体剥离（表示"未出现该现象"=合规）
# ⚠️ 现场写法三型都要吃下：
#   ①「无变形」                —— 否定词紧邻单现象词
#   ②「无变形、碎裂」          —— 逗号/顿号分隔，逐分句剥离
#   ③「无变形碎裂」            —— 否定词 + 连续多现象词（无标点连写）
# 因此正则允许多个现象词连续出现；同时对分句再剥一次兜底。
_PHENOMENON = [w for w in STRONG_NEG if not w.startswith(("未", "无", "不"))]
_PHEN_ALT = "|".join(re.escape(w) for w in sorted(_PHENOMENON, key=len, reverse=True))
_NEG_ALT = "|".join(re.escape(n) for n in _NEG_WORDS)
_PHENOMENON_GROUP = r"(?:(?:" + _PHEN_ALT + r")[^，。；、,;]{0,2}?){1,4}"
_NEG_PHENOMENON_RE = re.compile(
    r"(?:" + _NEG_ALT + r")" r"[^，。；、,;]{0,4}?" r"(?:" + _PHENOMENON_GROUP + r")"
)
# 「裸现象词」：整分句仅由一个/多个现象词构成（如「碎裂」「变形」「变形、碎裂」），
# 用于否定作用域跨「、」分句继承判定。
_PHENOMENON_ONLY_RE = re.compile(r"(?:(?:" + _PHEN_ALT + r")[、\s]{0,1}){1,4}")
_ABS_BAN_RE = re.compile("|".join(re.escape(w) for w in sorted(ABSOLUTE_BAN, key=len, reverse=True)))


def judge_status(status):
    """判定现状是否违规（四步法 + 语境规则 + 恒定违规词）。

    规则顺序：
      0) 语境规则命中 → 直接给出结论（先于一切，避免被通用否定剥离污染）；
      1) 恒定违规词：命中即违规（否定前缀不豁免、不剥离）；
      2) 否定 + 现象词组合剥离（"未发现裂纹""无变形""未出现溜逸"→ 合规表述）；
         — 剥离按「、／，」分句后进行，保证「无变形、碎裂」中两个词都被否掉；
      3) 正向表述剥离；
      4) 剩余文本命中强负词 → 违规；
      5) 剩余文本含一般否定词 → 违规。
    """
    s = (status or "").strip()
    if not s:
        return False

    # 0) 语境规则
    for pat, is_bad, _note in CONTEXT_RULES:
        if pat.search(s):
            return is_bad

    # 1) 恒定违规词（先看是否是"否定前缀 + 恒定违规词"的合规写法）
    ban_seen = False
    for w in ABSOLUTE_BAN:
        if w not in s:
            continue
        ban_seen = True
        # 「未使用橡胶垫块」= 合规写法；「使用橡胶垫块」= 违规
        idx = s.find(w)
        head = s[:idx]
        negated = any(head.rstrip("了").endswith(n) or head.rstrip("了，,、 ").endswith(n)
                      for n in _NEG_WORDS)
        if not negated:
            return True
    if ban_seen:
        # 出现恒定违规词但均被否定（如"未使用橡胶垫块，采用钢支墩抄垫"）→ 合规，直接返回，
        # 不再往下走通用规则（否则残留的"未"会被第 5 步误计为违规）。
        return False

    # 1.5) 双重否定 → 违规（"并非无卡滞" = 存在卡滞；"不能说未交底" = 未交底）
    for w in _PHENOMENON + [x for x in STRONG_NEG if x.startswith(("未", "无", "不"))]:
        for dbl in ("并非无", "并非未", "不是无", "不是未", "不能说未", "不能说无",
                    "不能说没有", "并非没有", "不是没有"):
            if dbl + w in s:
                return True

    # 2) 否定 + 现象词组合剥离（按分句逐一处理，防止「、」切断否定作用域）
    chunks = re.split(r"[，。；、,;]", s)
    scrubbed_parts = []
    carried_neg = False       # 否定词跨「、」分句向前继承（如「未见变形、碎裂」→ 碎裂亦被否定）
    for c in chunks:
        c2 = _NEG_PHENOMENON_RE.sub("", c)
        has_neg = bool(re.search(r"(?:" + _NEG_ALT + r")", c))
        if has_neg:
            carried_neg = True
        elif carried_neg and c2 == c and c.strip():
            # 本分句无自身否定词，但上一分句是否定句，且本分句整体是"裸现象词" → 继承否定
            if _PHENOMENON_ONLY_RE.fullmatch(c.strip()):
                c2 = ""
        scrubbed_parts.append(c2)
    scrubbed = "，".join(scrubbed_parts)
    # 兼容跨分句的「无X、Y」写法：整句再剥一次
    scrubbed = _NEG_PHENOMENON_RE.sub("", scrubbed)

    # 3) 正向表述剥离
    for p in POSITIVE_PATTERNS:
        scrubbed = scrubbed.replace(p, "")

    # 4) 强负词命中 → 违规
    if any(w in scrubbed for w in STRONG_NEG):
        return True
    # 5) 一般否定词 → 违规
    #    （合规的"否定+恒定违规词"写法已在第 1 步直接返回；
    #      合规的"否定+现象词"已由第 2 步剥离。此处残留否定词 → 确属违规。）
    return any(n in scrubbed for n in NEG)


def _norm(s):
    """归一化：去空白、去全角/半角标点括号、统一书名号引号，便于别名比对。"""
    s = (s or "").strip()
    for ch in " \t\u3000（）()【】[]{}《》〈〉\"'“”‘’·、，。；：,.;:!！?？-—_/\\|":
        s = s.replace(ch, "")
    return s


_ALIAS_INDEX = None


def _alias_index():
    """体检项全名 → 归一化别名集合（含全名自身与全名去括号形式）。"""
    global _ALIAS_INDEX
    if _ALIAS_INDEX is None:
        idx = {}
        for full, als in ITEM_ALIASES.items():
            keys = set()
            keys.add(_norm(full))
            keys.add(_norm(full.split("/")[0]))
            keys.add(_norm(full.split("（")[0]))
            for a in als:
                keys.add(_norm(a))
            idx[full] = {k for k in keys if k}
        _ALIAS_INDEX = idx
    return _ALIAS_INDEX


def _match(dev, item_kw):
    """在通用+专属中匹配体检项（专属项优先，避免通用项抢匹配）。

    匹配顺序：
      1) 别名表精确命中（归一化后相等）；
      2) 别名表双向包含（现场写法含全名或全名含现场写法）；
      3) 字面子串（全名/描述）兜底。
    命中失败时明确返回 (原名, "—", "—") 并由调用方显性告警（绝不静默降级）。
    """
    raw = (item_kw or "").strip()
    d = canon_device(dev)
    spec = DEVICE_ITEMS.get(d or "", [])
    pools = (spec, COMMON_ITEMS)
    nk = _norm(raw)

    # 0) 设备专属项自身的全名/别名（用于「制动装置」这类跨设备同名项优先本设备专属池）
    if nk:
        for pool in pools:
            for it, desc, dep, lvl in pool:
                idx = _alias_index().get(it, set())
                if nk == _norm(it) or nk in idx:
                    return it, dep, lvl
        # 双向包含
        for pool in pools:
            for it, desc, dep, lvl in pool:
                idx = _alias_index().get(it, set())
                if any(nk and (nk in k or k in nk) for k in idx):
                    return it, dep, lvl

    # 1) 字面子串兜底
    for pool in pools:
        for it, desc, dep, lvl in pool:
            if raw and (raw in it or raw in desc):
                return it, dep, lvl

    # 2) 全名反查（现状列里出现体检项全名也算命中）
    for pool in pools:
        for it, desc, dep, lvl in pool:
            if _norm(it) and _norm(it) in nk:
                return it, dep, lvl
    return raw, "—", "—"


def cmd_check(args):
    if not os.path.exists(args.check):
        print(f"文件不存在：{args.check}", file=sys.stderr)
        return 3
    rows = []
    with open(args.check, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = [x.strip() for x in line.replace("｜", "|").split("|")]
            if len(parts) >= 3:
                rows.append(parts)
    print(f"# 起重机安全体检（共 {len(rows)} 项）\n")
    print("| 设备 | 体检项 | 现状 | 判定 | 依据 |")
    print("|---|---|---|---|---|")
    bad = maj = 0
    unmatched = []
    for parts in rows:
        dev, item_kw, status = parts[0], parts[1], parts[2]
        name, dep, lvl = _match(dev, item_kw)
        if lvl == "—":
            unmatched.append(item_kw)
        isbad = judge_status(status)
        if isbad:
            bad += 1
            if lvl == MAJOR:
                maj += 1
        verdict = (f"🔴 不合规（{lvl}）" if lvl == MAJOR else "🟠 不合规") if isbad else "✅ 合格"
        print(f"| {dev} | {name} | {status} | {verdict} | {dep} |")
    print(f"\n**体检结论**：共 {len(rows)} 项，不合规 **{bad}** 项，其中**重大隐患 {maj}** 项。")
    if unmatched:
        print(f"\n⚠️ **体检项未识别（{len(unmatched)} 项，依据落空、等级未知）**："
              f"{'、'.join(unmatched)}")
        print("　→ 未识别项**不计入红线判定**，可能低估风险。请改用体检项全名，"
              "或对照 `--device <设备>` 生成的体检卡核对。")
    if maj:
        print("⚠️ 发现重大隐患项，设备须立即停用整改并按规定上报。")
    return 0


def cmd_audit(args):
    """台账：设备,体检项,现状"""
    if not os.path.exists(args.audit):
        print(f"文件不存在：{args.audit}", file=sys.stderr)
        return 3
    with open(args.audit, encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    print(f"# 起重机台账批量体检（{len(rows)} 行）\n")
    print("| 设备 | 体检项 | 现状 | 判定 | 依据 |")
    print("|---|---|---|---|---|")
    bad = maj = 0
    unmatched = []
    for r in rows:
        dev = (r.get("设备") or "").strip()
        item = (r.get("体检项") or r.get("检查项") or "").strip()
        status = (r.get("现状") or r.get("结果") or "").strip()
        name, dep, lvl = _match(dev, item)
        if lvl == "—":
            unmatched.append(item)
        isbad = judge_status(status)
        if isbad:
            bad += 1
            if lvl == MAJOR:
                maj += 1
        verdict = (f"🔴 不合规（{lvl}）" if lvl == MAJOR else "🟠 不合规") if isbad else "✅ 合格"
        print(f"| {dev} | {name} | {status} | {verdict} | {dep} |")
    print(f"\n**统计**：不合规 {bad} 项，其中重大隐患 **{maj}** 项。")
    if unmatched:
        print(f"\n⚠️ **体检项未识别（{len(unmatched)} 项，依据落空、等级未知）**："
              f"{'、'.join(unmatched)}")
        print("　→ 未识别项**不计入红线判定**，可能低估风险。请改用体检项全名。")
    return 0


def cmd_cases(args):
    db = load_db()
    kw = args.cases
    hits = [c for c in db.get("cases", [])
            if kw in (c.get("设备", "") + c.get("描述", "") + c.get("诱因", ""))]
    print(f"# 同类事故案例：{kw}（命中 {len(hits)} 起）\n")
    if not hits:
        print("未检索到相关案例。")
        return 0
    print("| 编号 | 设备 | 经过 | 后果 |")
    print("|---|---|---|---|")
    for c in hits:
        print(f"| {c['编号']} | {c['设备']} | {c['描述'][:56]} | {c['后果']} |")
    return 0


def main():
    p = argparse.ArgumentParser(description="起重机械安全体检卡")
    p.add_argument("--device", help="按设备生成体检卡")
    p.add_argument("--common", action="store_true", help="只看通用体检项")
    p.add_argument("--list", action="store_true", help="设备总览")
    p.add_argument("--check", help="逐项体检文件（设备|体检项|现状）")
    p.add_argument("--audit", help="CSV 台账（设备,体检项,现状）")
    p.add_argument("--cases", help="同类事故案例检索")
    p.add_argument("--out", help="输出文件")
    args = p.parse_args()

    if args.list:
        return cmd_list(args)
    if args.common:
        return cmd_common(args)
    if args.device:
        return cmd_device(args)
    if args.check:
        return cmd_check(args)
    if args.audit:
        return cmd_audit(args)
    if args.cases:
        return cmd_cases(args)
    p.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
