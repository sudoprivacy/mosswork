#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""起重机械安全体检卡 · 自检（纯标准库）"""
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
S = os.path.join(HERE, "scripts", "checkup.py")
D = os.path.join(HERE, "data")
fails = []


def check(name, cond, detail=""):
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail and not cond else ""))
    if not cond:
        fails.append(name)


def run(*args):
    r = subprocess.run([PY, S, *args], capture_output=True, text=True, encoding="utf-8", cwd=HERE)
    return r.returncode, r.stdout or "", r.stderr or ""


print("=== 1. 数据 ===")
check("切片文件存在", os.path.exists(os.path.join(D, "起重机条目切片.json")))
db = json.load(open(os.path.join(D, "起重机条目切片.json"), encoding="utf-8"))
_raw = open(os.path.join(D, "起重机条目切片.json"), encoding="utf-8").read()
_BANNED = ["内部" + "问题库", "xmin" + "d框架", "I" + "MA", "相关" + "条款", "相关" + "规程", "规程" + "精神"]
check("依据无" + "内部/模糊" + "来源残留", not any(x in _raw for x in _BANNED), "数据文件仍含" + "内部" + "来源" + "表述")
check("REQ >= 15", len(db["req"]) >= 15, f"{len(db['req'])}")
check("案例 >= 10", len(db.get("cases", [])) >= 10, f"{len(db.get('cases', []))}")
check("含 REQ131 起重机械专项", any(r["编号"] == "REQ131" for r in db["req"]))
check("含 REQ205 架桥机专项", any(r["编号"] == "REQ205" for r in db["req"]))

print("\n=== 2. 设备总览 ===")
rc, out, err = run("--list")
check("总览退出码0", rc == 0, err[:200])
for dev in ["塔式起重机", "龙门起重机", "架桥机", "汽车起重机", "履带起重机", "桥式（行吊）"]:
    check(f"覆盖{dev}", dev in out)
check("通用12条", "12" in out)

print("\n=== 3. 通用体检项 ===")
rc, out, err = run("--common")
check("通用项退出码0", rc == 0, err[:200])
check("含安全装置有效", "安全装置有效" in out)
check("含钢丝绳状态", "钢丝绳状态" in out)

print("\n=== 4. 各设备专属项 ===")
rc, out, err = run("--device", "塔吊")
check("塔吊退出码0", rc == 0, err[:200])
check("塔吊含顶升加节", "顶升加节控制" in out)
check("塔吊含多塔2m", "2m" in out)
rc, out, err = run("--device", "龙门吊")
check("龙门吊含抗风防滑", "抗风防滑装置" in out)
check("龙门吊含轨道锚固", "轨道锚固" in out)
rc, out, err = run("--device", "汽车吊")
check("汽车吊含支腿与地基", "支腿与地基" in out)
check("汽车吊含32项验收", "32项" in out)
rc, out, err = run("--device", "履带吊")
check("履带吊含双机抬吊", "双机抬吊协同" in out)
rc, out, err = run("--device", "架桥机")
check("架桥机含防遛逸", "防遛逸" in out)
check("架桥机含垫木/垫块规范", "垫块规范" in out or "垫木" in out)
check("架桥机含纵坡控制", "纵坡" in out)
check("架桥机含天车提升携梁", "携梁" in out)
check("架桥机专属项12条", "专属体检项（12 条）" in out, out[:400])
rc, out, err = run("--device", "行吊")
check("行吊含制动装置", "制动装置" in out)
rc, out, err = run("--device", "不存在的设备XYZ")
check("未知设备返回码2", rc == 2, f"rc={rc}")

print("\n=== 5. 逐项体检 ===")
with tempfile.TemporaryDirectory() as td:
    cl = os.path.join(td, "自查.txt")
    with open(cl, "w", encoding="utf-8") as f:
        f.write("塔吊|顶升加节控制|顶升人员为临时拼凑，未核验资质\n")
        f.write("塔吊|安全装置有效|力矩限制器齐全有效，无异常\n")
        f.write("汽车吊|支腿与地基|支腿未全伸，直接架在回填土上\n")
        f.write("龙门吊|抗风防滑装置|室外轨道式抗风防滑装置缺失\n")
        f.write("履带吊|双机抬吊协同|两台吊车不同步，各自回转\n")
    rc, out, err = run("--check", cl)
    check("逐项体检退出码0", rc == 0, err[:200])
    check("正向表述判合格", "✅ 合格" in out)
    check("标重大隐患", "不合规（重大隐患）" in out)
    check("龙门吊匹配专属项", "REQ131" in out)
    check("统计重大隐患4", "重大隐患 4" in out, out[-250:])

print("\n=== 6. CSV 台账体检 ===")
with tempfile.TemporaryDirectory() as td:
    au = os.path.join(td, "台账.csv")
    with open(au, "w", encoding="utf-8-sig") as f:
        f.write("设备,体检项,现状\n")
        f.write("塔吊,主体结构完好,主梁发现裂纹\n")
        f.write("行吊,制动装置,制动装置工作正常\n")
    rc, out, err = run("--audit", au)
    check("台账体检退出码0", rc == 0, err[:200])
    check("统计不合规", "不合规 1" in out, out[-200:])

print("\n=== 7. 案例检索 ===")
rc, out, err = run("--cases", "塔吊")
check("案例检索退出码0", rc == 0, err[:200])
check("命中塔吊案例", "H320" in out or "塔式起重机" in out)

# ============================================================
# 第 8~11 组：真实业务语句压测（现场口径）
# 教训来源：旧版自检全是"喂好样本"（正向词堆砌），44 项全绿，
# 一上真实涉铁现场句式就崩。判定类技能必须以真实业务语句回归。
# 三句式重点：否定句 / 并列句 / 正反包装。
# ============================================================

def _verdict(out, status_text):
    """从输出表格里取某条现状文本的判定单元。"""
    for line in out.splitlines():
        if status_text in line and line.startswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if len(cells) >= 4:
                return cells[3]
    return ""


print("\n=== 8. 体检项别名识别（依据不得落空）===")
with tempfile.TemporaryDirectory() as td:
    c = os.path.join(td, "alias.txt")
    with open(c, "w", encoding="utf-8") as f:
        f.write("行吊|大车制动装置|制动器动作正常\n")
        f.write("行吊|制动器|制动器动作正常\n")
        f.write("行吊|制动装置是否正常|制动器动作正常\n")
        f.write("架桥机|前支腿支承|使用橡胶垫块代替钢支墩\n")
        f.write("塔吊|力矩限制器|力矩限制器齐全有效\n")
        f.write("塔吊|风速计|臂根铰点高60m，风速仪未装设\n")
        f.write("架桥机|天车携梁|起吊天车提升与携梁行走同时进行\n")
    rc, out, err = run("--check", c)
    check("别名组退出码0", rc == 0, err[:200])
    check("大车制动装置→制动装置(REQ174)", "REQ174" in out, out[:600])
    check("制动器→制动装置(REQ174)", out.count("REQ174") >= 3, f"命中{out.count('REQ174')}次")
    check("前支腿支承→前支腿抄垫(REQ172)", "REQ172" in out)
    check("力矩限制器→安全装置有效(REQ101)", "REQ101" in out)
    check("风速计→风速仪/障碍灯", "风速" in out)
    check("天车携梁→天车提升与携梁行走", "REQ205" in out)
    check("别名组无依据落空", "依据落空" not in out, "出现未识别告警")
    check("别名组红线正确(橡胶垫块/同时进行)", out.count("不合规（重大隐患）") == 2, out[-260:])

print("\n=== 9. 语境规则（天车提升与携梁行走）===")
with tempfile.TemporaryDirectory() as td:
    c = os.path.join(td, "ctx.txt")
    with open(c, "w", encoding="utf-8") as f:
        f.write("架桥机|天车提升与携梁行走|起吊天车提升与携梁行走同时进行\n")
        f.write("架桥机|天车提升与携梁行走|提升与携梁行走未同时进行\n")
        f.write("架桥机|天车提升与携梁行走|未同时进行提升与携梁行走\n")
        f.write("架桥机|天车提升与携梁行走|提升与携梁行走已错开进行\n")
        f.write("架桥机|天车提升与携梁行走|天车携梁行走与提升同步进行\n")
    rc, out, err = run("--check", c)
    check("语境组退出码0", rc == 0, err[:200])
    check("同时进行→违规", _verdict(out, "起吊天车提升与携梁行走同时进行").startswith("🔴"))
    check("未同时进行(前置)→合格", _verdict(out, "提升与携梁行走未同时进行") == "✅ 合格")
    check("未同时进行(后置)→合格", _verdict(out, "未同时进行提升与携梁行走") == "✅ 合格")
    check("已错开进行→合格", _verdict(out, "提升与携梁行走已错开进行") == "✅ 合格")
    check("同步进行→违规", _verdict(out, "天车携梁行走与提升同步进行").startswith("🔴"))
    check("语境组红线数=2", out.count("不合规（重大隐患）") == 2, out[-260:])

print("\n=== 10. 恒定违规词（不受否定误伤、不被漏判）===")
with tempfile.TemporaryDirectory() as td:
    c = os.path.join(td, "ban.txt")
    with open(c, "w", encoding="utf-8") as f:
        f.write("架桥机|前支腿抄垫|使用橡胶垫块代替钢支墩\n")
        f.write("架桥机|前支腿抄垫|前支腿采用橡胶垫块抄垫\n")
        f.write("架桥机|前支腿抄垫|未使用橡胶垫块，采用钢支墩抄垫\n")
        f.write("架桥机|前支腿抄垫|前支腿已抄垫，但使用的是橡胶垫块\n")
    rc, out, err = run("--check", c)
    check("恒定词组退出码0", rc == 0, err[:200])
    check("使用橡胶垫块→违规", _verdict(out, "使用橡胶垫块代替钢支墩").startswith("🔴"))
    check("采用橡胶垫块→违规", _verdict(out, "前支腿采用橡胶垫块抄垫").startswith("🔴"))
    check("未使用橡胶垫块→合格", _verdict(out, "未使用橡胶垫块，采用钢支墩抄垫") == "✅ 合格")
    check("已抄垫但用橡胶垫块→违规", _verdict(out, "前支腿已抄垫，但使用的是橡胶垫块").startswith("🔴"))
    check("恒定词组红线数=3", out.count("不合规（重大隐患）") == 3, out[-260:])

print("\n=== 11. 否定作用域 / 并列句 / 正反包装 ===")
with tempfile.TemporaryDirectory() as td:
    c = os.path.join(td, "neg.txt")
    with open(c, "w", encoding="utf-8") as f:
        f.write("架桥机|垫木/垫块规范|垫木垛无变形碎裂\n")
        f.write("架桥机|垫木/垫块规范|垫木垛未见变形、碎裂\n")
        f.write("架桥机|垫木/垫块规范|垫木垛无变形，无碎裂\n")
        f.write("架桥机|垫木/垫块规范|垫木垛无变形，但存在碎裂\n")
        f.write("架桥机|垫木/垫块规范|垫木垛已按要求设置，无变形、无碎裂，符合说明书\n")
        f.write("行吊|制动装置|制动装置无失灵、无卡滞\n")
        f.write("行吊|制动装置|制动装置失灵\n")
        f.write("行吊|制动装置|大车制动器失灵、小车制动器卡滞\n")
        f.write("行吊|制动装置|制动装置无失灵，但存在卡滞\n")
        f.write("架桥机|防遛逸措施|已设置防遛逸措施，未出现溜逸\n")
        f.write("架桥机|防遛逸措施|架梁作业未采取防滑行措施，运梁平车未设楔铁\n")
        f.write("塔吊|安全装置有效|力矩限制器齐全，但行程限位失效、急停开关未设置\n")
        f.write("汽车吊|支腿与地基|支腿全伸，垫板为合格钢支墩，地基承载力满足\n")
        f.write("汽车吊|支腿与地基|支腿未全伸，垫木不符合规范\n")
        f.write("架桥机|防倾覆固结锚固|收工后已按要求用缆绳稳固、切断电源，并用手拉葫芦将天车固定，纵坡段木楔塞住，未发现溜逸\n")
    rc, out, err = run("--check", c)
    check("否定组退出码0", rc == 0, err[:200])
    check("无变形碎裂→合格", _verdict(out, "垫木垛无变形碎裂") == "✅ 合格")
    check("未见变形、碎裂→合格", _verdict(out, "垫木垛未见变形、碎裂") == "✅ 合格")
    check("无变形，无碎裂→合格", _verdict(out, "垫木垛无变形，无碎裂") == "✅ 合格")
    check("无变形但存在碎裂→违规", _verdict(out, "垫木垛无变形，但存在碎裂").startswith("🔴"))
    check("长合规句→合格", _verdict(out, "符合说明书") == "✅ 合格")
    check("无失灵无卡滞→合格", _verdict(out, "制动装置无失灵、无卡滞") == "✅ 合格")
    check("失灵→违规", _verdict(out, "| 制动装置失灵 |").startswith("🔴") or _verdict(out, "制动装置失灵").startswith("🔴"))
    check("并列双缺陷→违规", _verdict(out, "大车制动器失灵、小车制动器卡滞").startswith("🔴"))
    check("无失灵但卡滞→违规", _verdict(out, "制动装置无失灵，但存在卡滞").startswith("🔴"))
    check("未出现溜逸→合格", _verdict(out, "未出现溜逸") == "✅ 合格")
    check("未采取防滑行→违规", _verdict(out, "运梁平车未设楔铁").startswith("🔴"))
    check("齐全但限位失效→违规", _verdict(out, "急停开关未设置").startswith("🔴"))
    check("支腿全伸合规句→合格", _verdict(out, "地基承载力满足") == "✅ 合格")
    check("支腿未全伸→违规", _verdict(out, "垫木不符合规范").startswith("🔴"))
    check("超长合规句→合格", _verdict(out, "纵坡段木楔塞住，未发现溜逸") == "✅ 合格")
    check("否定组红线数=7", out.count("不合规（重大隐患）") == 7, out[-300:])

print(f"\n{'=' * 40}")
if fails:
    print(f"❌ 失败 {len(fails)} 项：{'；'.join(fails)}")
    sys.exit(1)
print("✅ 全部通过")
sys.exit(0)
