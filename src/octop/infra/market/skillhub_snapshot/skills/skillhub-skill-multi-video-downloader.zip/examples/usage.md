# 使用示例

统一入口 `scripts/download.py`，把任意视频链接丢进去，脚本按域名自动选引擎：

```bash
python scripts/download.py "<视频链接>" [输出目录]
```

## 1. 抖音（Playwright 引擎，已实测）
```bash
python scripts/download.py "https://v.douyin.com/xxxx" ./downloads
```

## 2. B站 / YouTube / TikTok 等 1000+ 平台（yt-dlp 引擎）
```bash
python scripts/download.py "https://www.bilibili.com/video/BV1xx" ./downloads
```

## 3. 视频号 / 好看视频 / 快手 / 小红书（redfox 解析引擎，需个人 Key）
```bash
# 配置一次即可
export REDFOX_API_KEY="你的key"          # 方式一：环境变量
# 或写入文件（脚本自动读取，权限 600）
# ~/.qoder/apis/redfox.json  ->  {"api_key": "你的key"}

python scripts/download.py "https://weixin.qq.com/sph/xxxx" ./downloads
```

## 4. 视频号免 Key 备选（用户本机操作）
使用 res-downloader（本地抓流工具，详见 `references/platforms.md`）：
在本机开代理 + 装 CA 证书，播放目标视频号视频时由工具捕获下载，无需任何 API Key。
