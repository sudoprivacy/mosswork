#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多平台视频下载统一入口
用法: python download.py "<视频链接>" [输出目录]
根据链接自动路由到三种引擎:
  - douyin : 抖音 (Playwright 抓分离流 + ffmpeg 合并, 已验证稳定)
  - parse  : 视频号/好看视频/快手/小红书 (redfox 解析接口, 返回单文件, 需个人 API Key)
  - ytdlp  : 其余 1000+ 平台 (yt-dlp, 稳定, 无需登录/接口)
内置便携版 ffmpeg 于 assets/, 无需安装。
"""
import sys, os, re, json, shutil, subprocess, time, urllib.request, urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "assets")

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0")


def ensure_ffmpeg():
    """定位 ffmpeg: 优先技能自带 / 同目录 / 系统 PATH; 都没有则从公开源自动下载便携版到 assets/。"""
    for c in (os.path.join(ASSETS, "ffmpeg.exe"),
              os.path.join(HERE, "ffmpeg.exe"),
              shutil.which("ffmpeg.exe"), shutil.which("ffmpeg")):
        if c and os.path.exists(c):
            return c
    # 自动下载便携版 (gyan.dev 官方 Windows essentials 构建, 仅含 ffmpeg.exe)
    url = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
    target = os.path.join(ASSETS, "ffmpeg.exe")
    try:
        import zipfile
        print("FFMPEG_AUTO_DOWNLOAD: 未检测到 ffmpeg, 正在从公开源下载便携版 (约 50MB)...")
        tmp = os.path.join(ASSETS, "_ffmpeg_dl.zip")
        urllib.request.urlretrieve(url, tmp)
        with zipfile.ZipFile(tmp) as z:
            name = [n for n in z.namelist() if n.endswith("bin/ffmpeg.exe")]
            if not name:
                raise FileNotFoundError("zip 内未找到 ffmpeg.exe")
            with z.open(name[0]) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
        os.remove(tmp)
        if os.path.exists(target):
            print("FFMPEG_AUTO_DOWNLOAD: 已就绪 ->", target)
            return target
    except Exception as e:
        print("FFMPEG_DOWNLOAD_FAIL", e, "| 可手动安装 ffmpeg 并加入 PATH, 或把 ffmpeg.exe 放进 assets/")
    return None


def route(url):
    u = url.lower()
    if "douyin.com" in u or "iesdouyin" in u or "v.douyin" in u:
        return "douyin"
    if "weixin.qq.com/sph" in u or ("weixin.qq.com" in u and "sph" in u):
        return "parse"          # 视频号
    if "haokan.baidu.com" in u or "haokan.com" in u:
        return "parse"          # 好看视频
    if "kuaishou.com" in u or "v.kuaishou" in u:
        return "parse"          # 快手
    if "xiaohongshu.com" in u or "xhslink" in u:
        return "parse"          # 小红书
    return "ytdlp"


# ---------------------------------------------------------------------------
# 引擎 1: yt-dlp (覆盖 B站/YouTube/TikTok/X/Instagram/微博/优酷/爱奇艺/芒果TV 等 1000+)
# ---------------------------------------------------------------------------
def engine_ytdlp(url, out):
    py = sys.executable
    cmd = [py, "-m", "yt_dlp", "--no-playlist",
           "-o", os.path.join(out, "%(title).60s.%(ext)s"), url]
    ff = ensure_ffmpeg()
    env = os.environ.copy()
    if ff:  # 让 yt-dlp 也能用内置 ffmpeg 合并 DASH 流
        env["PATH"] = os.path.dirname(ff) + os.pathsep + env.get("PATH", "")
    r = subprocess.run(cmd, env=env)
    return r.returncode == 0


# ---------------------------------------------------------------------------
# 引擎 2: 抖音 Playwright (音视频分离流 -> ffmpeg 合并)
# ---------------------------------------------------------------------------
def engine_douyin(url, out):
    ff = ensure_ffmpeg()
    if not ff:
        print("FFMPEG_MISSING: 抖音需要 ffmpeg 合并音视频, 可手动安装 ffmpeg 并加入 PATH, 或将 ffmpeg.exe 放入 assets/")
        return False
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("PLAYWRIGHT_MISSING: 请先 pip install playwright 并确保本机有 Edge/Chrome")
        return False

    video_urls, audio_urls = [], []
    def on_response(resp):
        u = resp.url
        ct = (resp.headers or {}).get("content-type", "")
        if "douyinvod" not in u or "video/mp4" not in ct:
            return
        if "media-video-avc1" in u:
            video_urls.append(u)
        elif "media-audio-und-mp4a" in u:
            audio_urls.append(u)

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(channel="msedge", headless=True)
            ctx = browser.new_context(user_agent=UA, viewport={"width": 1280, "height": 800})
            page = ctx.new_page()
            page.on("response", on_response)
            try:
                page.goto(url, timeout=45000, wait_until="domcontentloaded")
            except Exception as e:
                print("GOTO_WARN", e)
            time.sleep(9)  # 等待视频流加载
            try:
                title = page.title() or "douyin_video"
            except Exception:
                title = "douyin_video"
            browser.close()
    except Exception as e:
        print("PLAYWRIGHT_LAUNCH_FAIL", e)
        return False

    if not video_urls:
        print("NO_VIDEO_FOUND (可能页面未正常加载或链接失效)")
        return False

    def pick(urls):
        best, bestbr = urls[0], -1
        for u in urls:
            m = re.search(r"[?&]br=(\d+)", u)
            br = int(m.group(1)) if m else 0
            if br > bestbr:
                best, bestbr = u, br
        return best

    vurl = pick(video_urls)
    aurl = pick(audio_urls) if audio_urls else None
    safe = re.sub(r'[\\/:*?"<>|\r\n]+', "_", title).strip()[:60] or "douyin_video"
    vpath = os.path.join(out, safe + "_video.mp4")
    apath = os.path.join(out, safe + "_audio.mp4")
    final = os.path.join(out, safe + ".mp4")

    def dl(u, path):
        req = urllib.request.Request(u, headers={"User-Agent": UA, "Referer": "https://www.douyin.com/"})
        with urllib.request.urlopen(req, timeout=120) as r, open(path, "wb") as f:
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                f.write(chunk)
        print("saved", os.path.basename(path), os.path.getsize(path), "bytes")

    dl(vurl, vpath)
    if aurl:
        dl(aurl, apath)
        cmd = [ff, "-y", "-i", vpath, "-i", apath, "-c", "copy", "-movflags", "+faststart", final]
    else:
        cmd = [ff, "-y", "-i", vpath, "-c", "copy", "-movflags", "+faststart", final]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print("FFMPEG_ERROR", r.stderr[-800:])
        return False
    for p_ in (vpath, apath):
        try:
            os.remove(p_)
        except OSError:
            pass
    print("FINAL:", final, os.path.getsize(final), "bytes")
    return True


# ---------------------------------------------------------------------------
# 引擎 3: redfox 解析接口 (视频号/好看视频/快手/小红书, 返回已合并单文件)
# ---------------------------------------------------------------------------
def engine_parse(url, out):
    api_url = "https://redfox.hk/story/api/parseWork/parse"
    api_key = os.environ.get("REDFOX_API_KEY")
    cfg = os.path.join(os.path.expanduser("~"), ".qoder", "apis", "redfox.json")
    if not api_key and os.path.exists(cfg):
        try:
            api_key = json.load(open(cfg)).get("api_key")
        except Exception:
            pass
    if not api_key:
        api_key = "ak_b45b6a6881f4400fb321428947eb6661"  # 公共 Key (易失效)

    req = urllib.request.Request(
        api_url,
        data=json.dumps({"url": url, "source": "多平台视频下载"}).encode(),
        headers={"Content-Type": "application/json", "X-API-KEY": api_key})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            res = json.loads(r.read().decode())
    except Exception as e:
        print("API_FAIL", e)
        return False

    code = str(res.get("code"))
    if not code.startswith("2"):
        print("API_ERROR code", res.get("code"), res.get("msg"))
        if code in ("3106", "3107"):
            print("-> 公共 Key 已失效, 需配置个人 REDFOX_API_KEY。去 redfox.hk 注册后: "
                  "export REDFOX_API_KEY=你的key  或写入 ~/.qoder/apis/redfox.json")
        return False

    data = res.get("data") or {}
    title = data.get("title", "untitled")

    if data.get("awemeType") == "video":
        vurl = data.get("videoUrl")
        if not vurl:
            print("NO_VIDEO_URL")
            return False
        safe = re.sub(r'[\\/:*?"<>|\r\n]+', "_", title).strip()[:60] or "video"
        fp = os.path.join(out, safe + ".mp4")
        if dl_simple(vurl, fp):
            print("FINAL:", fp, os.path.getsize(fp), "bytes")
            return True
        return False
    elif data.get("awemeType") == "photo":
        urls = data.get("imageUrls") or []
        ok = False
        base = re.sub(r'[\\/:*?"<>|\r\n]+', "_", title).strip()[:50] or "photo"
        for i, u in enumerate(urls, 1):
            ext = os.path.splitext(u.split("?")[0])[1] or ".jpg"
            if dl_simple(u, os.path.join(out, f"{base}_{i}{ext}")):
                ok = True
        return ok
    else:
        print("UNKNOWN_TYPE", data.get("awemeType"))
        return False


def dl_simple(url, path):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=120) as r, open(path, "wb") as f:
            while True:
                c = r.read(65536)
                if not c:
                    break
                f.write(c)
        return True
    except Exception as e:
        print("DL_FAIL", e)
        return False


def main():
    if len(sys.argv) < 2:
        print("用法: python download.py <视频链接> [输出目录]")
        sys.exit(1)
    url = sys.argv[1].strip().strip('"').strip("'")
    out = sys.argv[2] if len(sys.argv) > 2 else os.getcwd()
    os.makedirs(out, exist_ok=True)
    eng = route(url)
    print("路由引擎:", eng)
    if eng == "douyin":
        ok = engine_douyin(url, out)
    elif eng == "parse":
        ok = engine_parse(url, out)
    else:
        ok = engine_ytdlp(url, out)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
