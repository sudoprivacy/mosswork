---
name: skillhub-skill-multi-video-downloader
description: "当用户想从抖音、视频号(微信)、好看视频、快手、小红书、B站、YouTube、TikTok、Twitter/X、Instagram 等平台下载视频时使用本技能。它提供统一入口，根据链接自动路由到最合适的下载引擎（yt-dlp / 抖音 Playwright / 第三方解析接口），并内置便携版 ffmpeg 用于音视频合并，无需安装。This skill should be used when the user wants to download videos from Chinese and international platforms including Douyin, WeChat Channels, Haokan, Kuaishou, Xiaohongshu, Bilibili, YouTube, TikTok, and 1000+ others."
---

# 多平台视频下载（Multi-Platform Video Downloader）

## Overview

提供一个统一入口，把任意视频链接路由到最合适的下载引擎，覆盖抖音、视频号、好看视频、快手、小红书、B站以及 YouTube/TikTok 等 1000+ 平台。内置便携版 ffmpeg（无需安装），自动处理抖音等平台的音视频分离合并。

**核心现实（务必先读）**：不同平台的可靠度差异极大，没有"一个引擎通吃所有平台"的免费稳定方案。本技能按三层引擎组织，每层可靠度不同，详见 `references/platforms.md`。

| 引擎 | 覆盖平台 | 可靠度 | 依赖 |
|---|---|---|---|
| **yt-dlp** | B站、YouTube、TikTok、X、Instagram、微博、Vimeo、优酷、爱奇艺、芒果TV 等 1000+ | ★★★★★ 稳定，无需登录/接口 | 需 `yt-dlp` 已安装 |
| **抖音 Playwright** | 抖音（douyin.com / v.douyin.com） | ★★★★☆ 稳定 | 需 `playwright` + 本机 Edge/Chrome + ffmpeg |
| **解析接口（redfox）** | 视频号、好看视频、快手、小红书 | ★★☆☆☆ 需个人 API Key，接口依赖第三方服务、存在失效风险 | 需配置 `REDFOX_API_KEY` |

## Quick Start

```bash
# 下载到当前目录（自动识别平台并选引擎）
python scripts/download.py "https://v.douyin.com/xxxx/"
python scripts/download.py "https://weixin.qq.com/sph/xxxx" "D:/下载"
```

- 不传输出目录时，文件落到**当前工作目录**。
- ffmpeg 优先使用技能 `assets/ffmpeg.exe`（已内置），找不到再找系统 PATH。
- 抖音会输出已合并音视频的 mp4；yt-dlp 平台直接输出；解析接口平台输出无水印直链文件。

## Engine Routing（路由逻辑）

`scripts/download.py` 根据 URL 域名自动分流，无需手动指定引擎：

1. 含 `douyin.com` / `iesdouyin` / `v.douyin` → **抖音引擎**
2. 含 `weixin.qq.com/sph`（视频号）、`haokan.baidu.com`（好看）、`kuaishou.com`（快手）、`xiaohongshu.com` / `xhslink`（小红书） → **解析接口引擎**
3. 其余所有链接 → **yt-dlp 引擎**

## 引擎 1：yt-dlp（稳定，推荐优先）

适用于 B站、YouTube、TikTok 等绝大多数公开平台。

```bash
# 已安装则直接可用
python -m yt_dlp --no-playlist -o "%(title).60s.%(ext)s" "<URL>"
```

- 若某平台报 "Sign in to confirm" 或需要 cookies，可加 `--cookies-from-browser edge`。
- yt-dlp **不支持**视频号、好看视频、快手、小红书——这些会路由到解析接口引擎。

## 引擎 2：抖音 Playwright（稳定，已验证）

抖音采用音视频分离流（DASH），必须分别抓取视频轨与音频轨再用 ffmpeg 合并。脚本 `scripts/download.py` 内置此逻辑：

- 用 `playwright` 驱动本机 Edge（`channel="msedge"`），监听响应中 `content-type: video/mp4` 且 URL 含 `douyinvod` 的请求；
- 按 `br=` 参数挑选最高码率；
- 分别下载 `media-video-avc1`（视频）与 `media-audio-und-mp4a`（音频），执行 `ffmpeg -y -i v.mp4 -i a.mp4 -c copy -movflags +faststart out.mp4` 合并。

**依赖**：`pip install playwright` 且本机已装 Edge/Chrome。若没有浏览器，安装：`playwright install msedge`。

## 引擎 3：解析接口（redfox，覆盖视频号/好看/快手/小红书）

这些封闭平台无开源稳定方案，只能走第三方解析接口。本技能复用 redfox.hk 接口（支持视频号、好看、快手、小红书）。

**必须配置个人 API Key**（内置免费 Key 极易失效，已实测 `code 3105: API Key已禁用`）：

```bash
# 方式一：环境变量
export REDFOX_API_KEY="你的key"
# 方式二：文件（脚本自动读取）
# ~/.qoder/apis/redfox.json 写 {"api_key": "你的key"}
```

Key 获取：前往 redfox.hk 注册。配置后解析接口引擎即可返回无水印直链并下载。

**风险揭示**：解析接口依赖第三方服务器，可能随时失效或要求付费；用户链接会发往 redfox.hk 解析（不上传本地文件）。若接口挂掉，该层引擎整体不可用，需用其他方式兜底（见下）。

### 视频号首选（免 Key）：本地抓流工具 res-downloader

对视频号，比 redfox 解析接口更稳、免费、无需任何 Key 的路线是**本地抓流**。res-downloader 是开源 GUI 工具，在本机开代理 + 装自签 CA 证书，捕获你播放视频时的真实视频流直接存盘（视频号 / 抖音 / 快手 / B站 / 小红书等通用）。缺点是需图形界面 + 你在本机播放该视频 + 通常要管理员装证书，**无法在 headless 环境自主运行**。适合在用户本机操作；详细步骤见 `references/platforms.md`。

## ffmpeg（按需自动获取，便携）

ffmpeg 用于合并抖音的音视频分离流、以及 yt-dlp 的 DASH 流。**技能发布包不再内置 ffmpeg 二进制**（避免大体积与审核风险）。脚本查找顺序：技能 `assets/` → 技能根目录 → 系统 PATH；若都找不到，会**首次运行时自动从公开源（gyan.dev 的 Windows essentials 构建）下载便携版到 `assets/ffmpeg.exe`**，无需安装、无需管理员权限。若自动下载失败，可手动把 `ffmpeg.exe` 放入 `assets/` 或安装到系统 PATH。

## 网络与权限（审核声明）

本技能会发起以下网络请求，均已明示用途：

| 域名 / 来源 | 用途 | 触发条件 |
|---|---|---|
| `redfox.hk` | 视频号 / 好看视频 / 快手 / 小红书 的分享链解析接口（需用户个人 API Key） | 仅当链接命中这四个封闭平台时 |
| 各平台官方视频 CDN（如 `douyin.com`、`bilibili.com`、`youtube.com` 等） | 下载视频 / 音频流本体 | 下载时 |
| `www.gyan.dev`（ffmpeg 官方 Windows 构建源） | 首次运行缺 ffmpeg 时自动下载便携版 | 仅当本地无 ffmpeg 时 |
| `pypi.org` | `pip install yt-dlp playwright` 安装运行依赖 | 首次按需安装时 |

**权限说明**：仅需「网络访问」与「在用户指定输出目录写入文件」；抖音引擎会调用本机已安装的 Edge/Chrome 浏览器（Playwright）渲染页面以拦截视频流，不会上传用户本地文件。所有外部请求均不含用户隐私文件，解析类请求（redfox.hk）仅发送用户主动提供的视频分享链接。

## Dependencies & Setup

依赖见 `requirements.txt`（`yt-dlp`、`playwright`）。首次使用按需安装：

```bash
"C:/Users/Administrator/.workbuddy/binaries/python/envs/default/Scripts/python.exe" -m pip install -r requirements.txt
playwright install msedge   # 若本机没有 Edge
```

## Troubleshooting

- **抖音报需 cookies / yt-dlp 下不了抖音**：正常，抖音已路由到 Playwright 引擎，与本机浏览器无关；确保 playwright + Edge 可用。
- **解析接口报 API Key 已禁用 / 401**：去 redfox.hk 注册个人 Key 并配置（见引擎 3）。这是免费额度失效，非操作问题。
- **抖音下完没声音**：说明只下了视频轨，脚本合并步骤未执行——检查 ffmpeg 是否就位（脚本会优先用 `assets/ffmpeg.exe`）。
- **换电脑跑不了**：确认已连同 `assets/ffmpeg.exe` 一起拷贝；并确认目标机有 Python + playwright（这两项无法绿色化，是最重依赖）。

## Resources

- `scripts/download.py` — 统一入口，含路由 + 三引擎 + ffmpeg 自动获取
- `references/platforms.md` — 平台支持矩阵、各引擎可靠度、视频号 res-downloader 路线
- `requirements.txt` — 运行依赖声明（yt-dlp、playwright）
- `tests/test_route.py` — 路由逻辑单元测试
- `examples/usage.md` — 使用示例
- ffmpeg：**不打包**；首次运行自动下载便携版到 `assets/`，或用户自行安装
- `references/platforms.md` — 平台支持矩阵与可靠度详表
