#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""路由逻辑单元测试：验证各平台链接正确分流到对应引擎。

运行：python tests/test_route.py
依赖：仅标准库；不触发任何网络请求、不调用浏览器。
"""
import os
import sys
import importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPT = os.path.join(HERE, "..", "scripts", "download.py")

spec = importlib.util.spec_from_file_location("dl_mod", SCRIPT)
dl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dl)

CASES = [
    ("https://v.douyin.com/abc", "douyin"),
    ("https://www.douyin.com/video/1", "douyin"),
    ("https://weixin.qq.com/sph/abc", "parse"),
    ("https://haokan.baidu.com/v/1", "parse"),
    ("https://v.kuaishou.com/1", "parse"),
    ("https://www.xiaohongshu.com/explore/1", "parse"),
    ("https://www.bilibili.com/video/BV1xx", "ytdlp"),
    ("https://www.youtube.com/watch?v=1", "ytdlp"),
    ("https://www.tiktok.com/@u/video/2", "ytdlp"),
]


def main():
    ok = 0
    for url, exp in CASES:
        got = dl.route(url)
        passed = got == exp
        if passed:
            ok += 1
        print(f"{'OK  ' if passed else 'FAIL'} {url[:44].ljust(44)} -> {got} (expect {exp})")
    print(f"\n{ok}/{len(CASES)} passed")
    sys.exit(0 if ok == len(CASES) else 1)


if __name__ == "__main__":
    main()
