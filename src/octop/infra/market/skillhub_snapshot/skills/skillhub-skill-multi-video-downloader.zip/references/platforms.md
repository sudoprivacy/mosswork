# 平台支持矩阵与可靠度

本技能按三层引擎组织。可靠度差异巨大——**不存在"一个引擎免费稳定通吃所有平台"的方案**。请按下方标注选择预期。

## ★★★★★ 稳定 — yt-dlp 引擎（无需登录、无需接口）

通过 `yt-dlp` 直接下载，覆盖 1000+ 公开站点：

- **B站** `bilibili.com` / `b23.tv`
- **YouTube** `youtube.com` / `youtu.be`
- **TikTok** `tiktok.com`
- **X / Twitter** `x.com` / `twitter.com`
- **Instagram** `instagram.com`
- **微博** `weibo.com`
- **Vimeo** `vimeo.com`、**Twitch** `twitch.tv`
- 优酷、爱奇艺、芒果TV、西瓜视频、今日头条、AcFun、喜马拉雅、知乎、斗鱼、虎牙 等

完整站点列表见 yt-dlp 官方 `supportedsites.md`。

> 个别平台（如部分 B站高码率、YouTube 受限视频）若报需 cookies，可在引擎命令加 `--cookies-from-browser edge`。脚本已把内置 ffmpeg 注入 PATH，DASH 分离流会自动合并。

**爱奇艺（iqiyi）特别提示**：yt-dlp 官方收录了 iqiyi（支持站点列表第 587 行），本技能会正确路由到 yt-dlp 引擎。但爱奇艺是国内加密/DRM 限制最严的平台之一——**仅免费、非加密的短视频/部分公开内容可下**；VIP 会员剧集电影即便用 `--cookies-from-browser` 登录也常因强加密而失败。实际成功率远低于 B站。如要实测，请提供一条具体爱奇艺链接。

## ★★★★☆ 稳定 — 抖音 Playwright 引擎（已实测验证）

- **抖音** `douyin.com` / `v.douyin.com` / `iesdouyin.com`

机制：抖音采用音视频分离流（DASH）。脚本用 Playwright 驱动本机 Edge 真实渲染，从网络请求拦截 `media-video-avc1`（视频轨）与 `media-audio-und-mp4a`（音频轨），分别下载后用内置 ffmpeg 无损合并（`-c copy`）。

依赖：`playwright` 库 + 本机已装 Edge/Chrome + 内置 `assets/ffmpeg.exe`。

限制：依赖本机浏览器；抖音短链有时效，建议复制后尽快下载。

## ★★☆☆☆ 需个人 Key — 解析接口引擎（redfox）

以下**封闭平台 yt-dlp 全部不支持**，只能走第三方解析接口。接口返回**已合并的单文件 mp4（无水印）**，因此本层**不需要 ffmpeg**：

| 平台 | 链接特征 | 可靠度 |
|---|---|---|
| **视频号** | `weixin.qq.com/sph/...` | ★★★☆☆ 需 Key |
| **好看视频** | `haokan.baidu.com/...` | ★★☆☆☆ 需 Key |
| **快手** | `kuaishou.com` / `v.kuaishou.com` | ★★★☆☆ 需 Key |
| **小红书** | `xiaohongshu.com` / `xhslink.com` | ★★★☆☆ 需 Key |

**配置个人 API Key（公共 Key 已失效，必须自配）：**

```bash
# 方式一：环境变量
export REDFOX_API_KEY="你的key"
# 方式二：文件（脚本自动读取，权限 600）
# ~/.qoder/apis/redfox.json  ->  {"api_key": "你的key"}
```

获取：前往 redfox.hk 注册。配置后引擎返回无水印直链并下载。

**风险揭示（务必知悉）：**
- 接口依赖第三方服务器 **redfox.hk**，可能随时失效或转为收费；
- 用户视频链接会发往该服务器做解析（**不会上传本地文件**）；
- 若接口报错 `code 3106/3107`（缺 Key / Key 失效），即公共额度不可用，需自配 Key；
- 接口整体挂掉时，该层引擎不可用，需用其他途径兜底（如各平台官方 App 的保存功能、或带内置 ffmpeg 的桌面下载器）。

## 视频号首选（免 Key）：本地抓流工具 res-downloader

对**视频号**这类封闭平台，比起依赖第三方解析接口（redfox，要 Key、易失效），**本地抓流**是更稳、免费、不需要任何 Key 的路子。用户平时即使用此方案。

**原理**：res-downloader 是开源 GUI 工具，在本机开启一个代理 + 安装自签 CA 证书，捕获你播放视频时的 HTTPS 视频流，直接存成文件。因为它抓的是你本机真实播放的流，不依赖任何外部解析接口，**视频号、抖音、快手、B站、小红书等都能抓**。

**为什么比 redfox 更适合视频号**：
- 不需要 API Key、不依赖第三方服务器；
- 不会因为接口额度失效而突然不能用；
- 缺点：需要**图形界面 + 你在本机播放该视频 + 安装 CA 证书（通常需要管理员权限）**，无法在 headless 环境自主运行。

**使用方式（用户本机操作）**：
1. 下载并打开 res-downloader（开源，搜索 "res-downloader" 即可）；
2. 按提示安装其 CA 根证书（授权管理员）；
3. 让工具开始捕获，然后在微信 / 浏览器中播放目标视频号视频；
4. 工具会自动列出视频流，选中下载即可。

> 本技能的 parse 引擎（redfox）仍保留作为"有 Key 时一键脚本化"的备选；但**视频号首选推荐 res-downloader**（免 Key、更稳）。抖音已另有稳定的 Playwright 引擎；其余 1000+ 平台走 yt-dlp。

## 不支持 / 未覆盖

- 任何需登录的私有内容、付费内容；
- 直播流的实时录制（需 OBS 等额外工具）；
- 微信视频号、好看视频、快手、小红书**未配置 Key 时**等于不可用（路由到该层但会报错提示）。

## 换电脑迁移速查

| 依赖 | 是否可绿色化 | 说明 |
|---|---|---|
| `assets/ffmpeg.exe` | ✅ 已内置 | 拷贝技能目录即带走，无需安装 |
| Python | ⚠️ 便携版可带 | 但体积大 |
| `playwright` 库 | ⚠️ 需联网 pip | 且依赖浏览器驱动 |
| 本机 Edge/Chrome | ❌ 一般预装 | 抖音引擎必需 |
| `yt-dlp` | ⚠️ 需联网 pip | 1000+ 平台引擎必需 |
| redfox Key | — | 视频号/好看/快手/小红书必需 |

**最快的跨设备方案**：在能跑的电脑上下载完，只把成品 mp4 拷走——视频文件本身零依赖，播放不需要 ffmpeg。
