# AI Skills

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)

面向 [Claude Code](https://docs.claude.com/en/docs/claude-code) 的 AI 技能体系，覆盖从创意探索到交付物导出的完整研发链路。

## 技能列表

| 技能 | 职责 | 输出 |
|------|------|------|
| `m-chat` | 创意探索：头脑风暴、初步分析 | `docs/explorations/` |
| `m-init` | 项目初始化 / 已有项目分析 | 目录结构 + CLAUDE.md |
| `m-req` | 需求分析：What + Why + What NOT | `docs/requirements/` |
| `m-design` | 技术设计：How + How NOT + Boundaries | `docs/designs/` |
| `m-test` | 测试工程：测试计划与测试用例 | `docs/tests/` |
| `m-plan` | 任务规划：任务拆分与资源清单 | `docs/plans/` |
| `m-execute` | 执行调度：子代理调度与质量评审 | `docs/plans/`（执行记录） |
| `m-docs` | Docsify工具 | `docs/` 文档站点 |

## 开发流程

```
想法萌芽 → m-chat（创意探索）
    ↓
想法清晰 → m-req（需求分析）
    ↓
完成需求 → m-design（技术设计）
    ↓
完成设计 → m-test（测试工程）
    ↓
完成测试 → m-plan（任务规划）
    ↓
完成计划 → m-execute（执行调度）

任何阶段 → m-docs（文档站点）
```

## 文档输出

```
docs/
├── explorations/         # m-chat 输出（index.md + yyyy-mm-dd-abstract.md）
├── requirements/         # m-req 输出（.md）
├── designs/              # m-design 输出（.md）
├── plans/                # m-plan / m-execute 输出
└── tests/                # m-test 输出
```

## 项目集成

采用本技能体系的项目，将 m-init 技能目录下的 `templates/CLAUDE.md` 复制到项目根目录 `CLAUDE.md`，
项目 AI 会自动发现需求、设计、测试、计划文档的位置。

## Git 提交规范

```
<type>(<scope>): <subject>

<type>: chat | init | req | design | test | plan | execute | docs
<scope>: 功能或模块名称
```

## 远程仓库

GitHub: `github.com/zhangmf/m-skills`
