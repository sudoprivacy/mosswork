# 项目文档索引

> 本文件由 AI Skills 技能体系自动生成。采用 m-chat / m-init / m-req / m-design / m-test / m-plan / m-execute / m-docs
> 技能的项目，应将本模板复制到项目根目录 `CLAUDE.md`。AI 在本项目工作时，
> 通过本文件自动发现需求、设计、测试、计划文档的位置，无需显式告知。

---

## 文档目录

| 类型 | 路径 | 说明 |
|------|------|------|
| 探索报告 | `docs/explorations/`（index.md + yyyy-mm-dd-abstract.md） | m-chat 输出，包含方案对比、根因分析、开放问题、下一步 |
| 需求文档 | `docs/requirements/`（`.md`） | m-req 输出，包含验收标准、AC 依赖、禁止条款 |
| 设计文档 | `docs/designs/`（`.md`） | m-design 输出，包含组件、数据模型、API、约束 |
| 测试文档 | `docs/tests/`（`.md`） | m-test 输出，包含测试计划、测试用例、回归向量 |
| 执行计划 | `docs/plans/`（`.md`） | m-plan / m-execute 输出，包含任务拆分和执行记录 |

---

## 索引

### 需求文档索引

<!-- 在 m-req 执行后，AI 自动更新以下内容 -->
<!-- 格式: - [需求名称](docs/requirements/<feature>.md) -->

### 设计文档索引

<!-- 在 m-design 执行后，AI 自动更新以下内容 -->
<!-- 格式: - [设计名称](docs/designs/<feature>.md) -->

### 测试文档索引

<!-- 在 m-test 执行后，AI 自动更新以下内容 -->
<!-- 格式: - [功能名称](docs/tests/features/<feature>/index.md) -->

### 执行计划索引

<!-- 在 m-plan / m-execute 执行后，AI 自动更新以下内容 -->
<!-- 格式: - [功能名称](docs/plans/features/<feature>/index.md) -->

---

## 开发流程

```
想法萌芽 → m-chat（创意探索）
    ↓
想法清晰 → m-req（需求分析）
    ↓
完成需求 → m-design（技术设计）
    ↓
完成设计 → m-test（测试工程）
    ↓
完成测试 → m-plan（任务规划）
    ↓
完成计划 → m-execute（执行调度）

任何阶段 → m-docs（文档站点）
```

---

## 约束

- 需求文档未通过 m-req Exit Gate，不得进入 m-design
- 设计文档未通过 m-design Exit Gate，不得进入 m-test
- 测试文档未提交 git，不得进入 m-plan
- 计划文档未提交 git，不得启动 m-execute
- 设计与实现必须遵循 `docs/designs/` 中的 `constraints`（must not / must go through）
