#!/usr/bin/env python3
"""
Generate docs/_sidebar.md listing all documents in:
  requirements/, designs/, plans/, tests/, explorations/

Also copy each subdirectory's index.md to docs/ with renaming
(e.g. requirements-index.md) and fix relative paths.
"""

import os
import re
from pathlib import Path

DOCS_DIR = Path(__file__).resolve().parent

CATEGORIES = [
    {"dir": "requirements", "label": "需求文档", "emoji": "📋"},
    {"dir": "designs",      "label": "设计文档", "emoji": "📐"},
    {"dir": "plans",        "label": "执行计划", "emoji": "📦"},
    {"dir": "tests",        "label": "测试文档", "emoji": "🧪"},
    {"dir": "explorations", "label": "探索报告", "emoji": "🔍"},
]


def extract_title(md_path: Path) -> str:
    """Extract first # heading from a markdown file."""
    try:
        with open(md_path, "r", encoding="utf-8") as f:
            for line in f:
                m = re.match(r"^#\s+(.+)", line)
                if m:
                    return m.group(1).strip()
    except Exception:
        pass
    return md_path.stem  # fallback: filename without extension


def copy_and_fix_index(category: dict) -> None:
    """Copy subdir/index.md to docs/<dir>-index.md and fix relative paths."""
    subdir = DOCS_DIR / category["dir"]
    index_md = subdir / "index.md"
    if not index_md.exists():
        print(f"  [SKIP] {index_md} not found")
        return

    dest_name = f"{category['dir']}-index.md"
    dest_path = DOCS_DIR / dest_name

    with open(index_md, "r", encoding="utf-8") as f:
        content = f.read()

    # Fix relative markdown links: [text](path.md) or [text](path/to/index.md)
    # Prepend the subdirectory so links work from docs/ root
    prefix = category["dir"] + "/"

    def fix_link(match):
        text = match.group(1)
        link = match.group(2)
        # Skip external links, absolute paths, and anchor-only links
        if link.startswith(("http://", "https://", "/", "#")):
            return match.group(0)
        # Already has the prefix?
        if link.startswith(prefix):
            return match.group(0)
        return f"[{text}]({prefix}{link})"

    content = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", fix_link, content)

    with open(dest_path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"  [COPIED] {index_md} -> {dest_name} (paths fixed)")


def collect_docs(category_dir: Path, base_dir: Path) -> list:
    """Collect all markdown files under category_dir, sorted by depth then name."""
    docs = []
    for root, dirs, files in os.walk(category_dir):
        # Skip hidden dirs
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for f in sorted(files):
            if f.endswith(".md"):
                full_path = Path(root) / f
                rel_path = full_path.relative_to(base_dir)
                docs.append(rel_path)
    # Sort: top-level files first, then by path
    docs.sort(key=lambda p: (p.as_posix().count("/"), p.as_posix()))
    return docs


def generate_sidebar() -> None:
    sidebar_path = DOCS_DIR / "_sidebar.md"

    lines = []
    lines.append("- 📖 首页")
    lines.append("- [项目主页](README.md)")
    lines.append("")

    for cat in CATEGORIES:
        cat_dir = DOCS_DIR / cat["dir"]
        if not cat_dir.is_dir():
            continue

        # Copy and fix index.md
        copy_and_fix_index(cat)

        lines.append(f"- {cat['emoji']} {cat['label']}")

        # Link to the copied index
        index_dest = f"{cat['dir']}-index.md"
        if (DOCS_DIR / index_dest).exists():
            lines.append(f"  - [索引]({index_dest})")

        # Collect and list all documents
        base_dir = DOCS_DIR
        docs = collect_docs(cat_dir, base_dir)

        # Group: top-level single docs and feature sub-dirs
        top_level = []
        features = {}  # feature_name -> list of paths

        for rel_path in docs:
            parts = rel_path.parts
            inner = parts[1:]  # strip category dir

            if len(inner) == 1:
                # Top-level doc under category
                if inner[0] != "index.md":
                    top_level.append(rel_path)
            else:
                # Nested: group by second-level dir
                feature_name = inner[0]
                if feature_name == "features":
                    # Third level is the actual feature name
                    if len(inner) >= 2:
                        feat = inner[1]
                        if feat not in features:
                            features[feat] = []
                        features[feat].append(rel_path)
                elif feature_name == "adr":
                    if "adr" not in features:
                        features["adr"] = []
                    features["adr"].append(rel_path)
                else:
                    if feature_name not in features:
                        features[feature_name] = []
                    features[feature_name].append(rel_path)

        # Print top-level docs
        for rel_path in top_level:
            title = extract_title(DOCS_DIR / rel_path)
            lines.append(f"  - [{title}]({rel_path.as_posix()})")

        # Print feature groups
        for feat_name in sorted(features.keys()):
            feat_docs = features[feat_name]
            feat_title = feat_name.replace("-", " ").title()
            lines.append(f"  - **{feat_title}**")
            for rel_path in feat_docs:
                title = extract_title(DOCS_DIR / rel_path)
                indent = "    "
                lines.append(f"  {indent}- [{title}]({rel_path.as_posix()})")

        lines.append("")

    with open(sidebar_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print(f"\n✅ Generated {sidebar_path}")
    print(f"   {len(lines)} lines")


if __name__ == "__main__":
    os.chdir(DOCS_DIR)
    generate_sidebar()
