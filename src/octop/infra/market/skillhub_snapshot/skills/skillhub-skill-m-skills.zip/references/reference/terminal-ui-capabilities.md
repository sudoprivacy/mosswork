# Claude Code Terminal UI Capabilities — SKILL 应用指南

> 探索 Claude Code 终端 UI 能力边界，记录对 SKILL 有价值的使用模式。
> 基于实测，非推测。

---

## 已验证能力

### 1. AskUserQuestion

**键盘交互**：
- `↑↓` — 方向键导航选项
- `Enter` — 确认选中项
- `空格` — 多选模式下选中/取消
- `Esc` — 取消
- `数字` — 部分场景可按数字快速选择

**选项渲染**：
```
  ○ → m-test              继续：设计 → 测试 → 计划 → 执行
  ● 稍后                  文档已保存。

  [↑↓] 选择   [Enter] 确认
```

**preview 字段**：选项旁显示 markdown 内容（diff、ASCII mockup）

---

### 2. TaskCreate / TaskUpdate / TaskList

- TaskCreate 创建的任务在 UI 中以结构化列表展示
- TaskUpdate(status) 会更新显示状态
- **用途**：Phase 执行过程中，作为步骤进度指示器

---

### 3. Plan Mode

- 用户显式进入 Plan Mode 审批
- 适合作为 SKILL 的**重大决策审批门**
- 不适合高频交互（每次 Phase 都进 Plan Mode 太重）

---

## SKILL 应用模式

### 模式 A: 步骤进度指示器（TaskCreate as Progress）

**问题**：Phase 执行中用户不知道当前在哪一步。

**方案**：用 TaskCreate 在每个 Phase 开始时创建步骤任务，完成后更新。

```
# Phase 1 开始
TaskCreate(subject: "Step 1/4: 分析需求文档", status: "in_progress")
  → 用户看到进度指示

# Phase 1 完成
TaskUpdate(id, status: "completed")
TaskCreate(subject: "Step 2/4: 生成测试用例", status: "in_progress")
```

**效果**：用户始终知道 SKILL 在哪一步，类似安装向导的进度条。

---

### 模式 B: AskUserQuestion + Preview (Diff/Mockup)

**问题**：选项没有上下文，用户无法快速决策。

**方案**：选项带 preview，展示变更内容。

```
AskUserQuestion(
  question: "需求变更摘要（2 项）。确认？",
  options: [
    { label: "→ 确认变更", preview: "AC-003:\n  - 依赖: [AC-001]\n  + 依赖: [AC-001, AC-002]\n\nAC-005:\n  - 优先级: P1\n  + 优先级: P0" },
    { label: "取消" }
  ]
)
```

**效果**：用户不用猜，看完 diff 再决定。

---

### 模式 C: Plan Mode 作为重大决策审批门

**问题**：某些决策（如：架构变更、性能策略）不适合在普通对话中确认。

**方案**：进入 Plan Mode，展示完整决策内容和方案对比，让用户审批。

```
# SKILL 检测到重大决策点
ExitPlanMode()
# 用户进入 Plan Mode，审查方案
# 用户确认后重新进入 SKILL
```

**适合场景**：
- m-design 中发现架构冲突，需要用户决策
- m-plan 中发现资源不足，需要用户决定优先级
- m-execute 中发现实现与设计严重偏离，需要用户决定是否继续

---

### 模式 D: Checklist 模式（多选 + 快捷方式）

**问题**：资源清单选项过多，逐项确认效率低。

**方案**：多选 + "→ 全部确认" 快捷选项。

```
AskUserQuestion(
  questions: [
    { question: "R-01 PostgreSQL：", multiSelect: false, options: [
      { label: "[✓] 已就绪", description: "10.0.0.5:5432" },
      { label: "[ ] 暂无" }
    ]},
    { question: "R-02 Redis：", multiSelect: false, options: [
      { label: "[✓] 已就绪", description: "10.0.0.6:6379" },
      { label: "[ ] 暂无" }
    ]},
    { question: "批量操作：", multiSelect: false, options: [
      { label: "→ 全部确认 ✓", description: "跳过逐项，全部标记为已就绪" }
    ]}
  ]
)
```

---

### 模式 E: 渐进式披露（分屏显示）

**问题**：大量信息一次性展示，用户容易迷失。

**方案**：分多步，每步只问一个核心问题。

```
Step 1: 确认范围（AskUserQuestion）
  ↓ 用户确认
Step 2: 确认策略（AskUserQuestion）
  ↓ 用户确认
Step 3: 确认工具选型（AskUserQuestion）
  ↓ 用户确认
Step 4: 展示最终摘要（text）
  → Sign-Off（AskUserQuestion）
```

---

## 未充分验证的能力（待探索）

| 能力 | 状态 | 潜在价值 |
|------|------|---------|
| Bash 实时输出动画 | 待测 | 长时间操作的进度反馈 |
| Mermaid 图表渲染 | 待测 | 架构图、流程图直接在终端展示 |
| ANSI 颜色输出 | 待测 | 关键信息高亮 |
| Clickable links | 待测 | 快速打开文档链接 |
| 表格渲染（markdown） | 待测 | 复杂数据展示 |

---

## SKILL 交互设计建议

基于以上能力，SKILL 交互应遵循：

**1. 始终用 AskUserQuestion 做选择，不让用户猜**
```
Bad: "请确认范围，输入 1 或 2"
Good: AskUserQuestion(options: [label: "完整", description: "..."], [label: "精简", description: "..."])
```

**2. 每步用 TaskCreate 显示进度**
```
Phase 开始 → TaskCreate("Step N/M: ...") → Phase 完成 → TaskUpdate(completed)
```

**3. 重大决策用 Plan Mode**
```
SKILL 发现架构冲突 → "这是一个重大决策，我将进入 Plan Mode 让你审批"
→ Plan Mode 审批 → 继续
```

**4. 变更内容用 preview 展示**
```
AskUserQuestion(options: [
  { label: "确认", preview: "diff 内容..." }
])
```

**5. 多选项加快捷方式**
```
"[→] 继续"  # 一键 Enter 继续
```

---

## 待探索清单

如需进一步验证，可测试：

1. **Bash 长时间操作**：sleep + timeout，UI 是否显示进度
2. **Mermaid 渲染**：在支持 Mermaid 的终端插件中效果
3. **CronCreate 提醒**：设置 5 分钟后提醒，查看提醒 UI
4. **文件 diff 渲染**：Edit 工具的 diff 输出格式
