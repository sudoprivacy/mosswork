# 贡献指南

欢迎贡献代码、文档、Issue 和 PR。本项目采用 MIT 协议。

## 提 Issue

- **Bug 报告**：描述复现步骤、期望行为、实际行为；附上 Claude Code 版本。
- **功能建议**：说明使用场景、期望的交互流程、备选方案。
- **技能改进**：引用具体技能名（如 `m-plan`）和文件位置（如 `m-plan/SKILL.md:42`）。

## 提 PR

1. Fork 仓库，创建分支：`feat/<name>` 或 `fix/<name>`。
2. 修改 `m-*/SKILL.md`，保持 frontmatter 的 `name` / `description` / `updated` 字段同步更新。
3. 提交信息遵循 `<type>(<scope>): <subject>`：
   - `<type>`：常用 `feat` `fix` `docs` `chore` `refactor`
   - `<scope>`：技能名（`m-plan`、`m-design` 等）
4. PR 描述说明：变更背景、变更内容、是否影响已有用户、如何验证。

## 技能质量标准

每个 `m-*` 技能应满足：

- **Frontmatter 完整**：`name` / `description` 简洁明确，包含触发关键词。
- **阶段明确**：用 `## Phase` 或 `## Step` 划分流程节点。
- **退出标准**：在文件末尾以 `## Exit Gate` 列出可验证的完成条件。
- **不依赖未声明的副作用**：不在未说明的情况下创建文件 / 提交 git / 调用网络。

## 开发约定

- 使用中文写文档和 commit message。
- 代码示例优先选择最简形式，不为未请求的灵活性编写抽象。
- 不要把个人 IDE 配置、`.DS_Store`、环境特定的密钥带入仓库。

## 行为守则

所有参与者应保持尊重、就事论事。贡献者通过 PR 视为同意按 MIT 协议发布其贡献。
