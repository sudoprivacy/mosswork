# AI Skills 项目

本项目是 AI 技能体系的开发仓库，包含 m-chat / m-init / m-req / m-design / m-test / m-plan / m-execute / m-docs 八个技能的源代码。

> **采用本技能体系的项目**：请将 m-init 技能目录下的 `templates/CLAUDE.md` 复制到项目根目录 `CLAUDE.md`，
> 并按模板说明创建 `docs/requirements/`、`docs/designs/`、`docs/plans/` 目录。
> 项目 AI 通过该文件自动发现文档位置，无需显式告知。

---

## 技能体系

| 技能 | 职责 | 输出 |
|------|------|------|
| `m-chat` | 创意探索：头脑风暴、初步分析 | `docs/explorations/` |
| `m-init` | 项目初始化 / 已有项目分析 | 目录结构 + CLAUDE.md |
| `m-req` | 需求分析：What + Why + What NOT | `docs/requirements/` |
| `m-design` | 技术设计：How + How NOT + Boundaries | `docs/designs/`（`.md`） |
| `m-test` | 测试工程：测试计划与测试用例 | `docs/tests/` |
| `m-plan` | 任务规划：任务拆分与资源清单 | `docs/plans/` |
| `m-execute` | 执行调度：子代理调度与质量评审 | `docs/plans/`（执行记录） |
| `m-docs` | Docsify工具 | `docs/` 文档站点 |

## 文档目录结构

```
docs/
├── explorations/         # m-chat 输出（index.md + yyyy-mm-dd-abstract.md）
│   ├── index.md
│   └── YYYY-MM-DD-abstract.md
├── requirements/          # m-req 输出（.md）
│   ├── index.md
│   └── <feature-name>.md
├── designs/              # m-design 输出（.md）
│   ├── index.md
│   ├── <feature-name>.md
│   └── adr/
│       ├── index.md
│       └── ADR-<N>.md
├── plans/               # m-plan / m-execute 输出（.md）
│   ├── index.md
│   └── features/
│       └── <feature>/
│           ├── index.md
│           ├── wave-0.md
│           ├── wave-1.md
│           └── wave-2.md
└── tests/               # m-test 输出（.md）
    ├── index.md
    └── features/
        └── <feature>/
            ├── index.md
            ├── test-plan.md
            ├── test-cases/
            │   ├── unit.md
            │   ├── integration.md
            │   └── e2e.md
            └── execution-log.md
```

## Git 提交要求

所有 `m-*` 技能产出的文档（requirements / designs / plans）**必须**在确认后提交到 git。

提交时机：
- `m-req` 文档确认后 → 提交
- `m-design` 文档确认后 → 提交
- `m-test` 文档确认后 → 提交
- `m-plan` 计划确认后 → 提交
- `m-execute` 执行记录更新后 → 提交

提交信息规范：
```
<type>(<scope>): <subject>

<type>: chat | init | req | design | test | plan | execute | docs
<scope>: 功能或模块名称
<subject>: 简短描述（中文，≤ 50 字）
```

示例：
```
chat(order): 订单功能创意探索，3 个方案对比
req(order): 添加订单创建需求和验收标准
design(order): 订单功能详细设计
test(order): 添加订单功能测试计划与测试用例
plan(order): 拆分 8 个实现任务，2 个测试任务
execute(order): 完成 T-001~T-005，T-003 设计合规失败
docs(api-spec): API 规范文档，导出 Word 版
```

## 禁止事项

- 不得在未提交文档的情况下开始下一阶段工作
- 不得跳过 sign-off 步骤直接写入文档
- 不得在 git 未追踪的文档上启动 m-test / m-execute
