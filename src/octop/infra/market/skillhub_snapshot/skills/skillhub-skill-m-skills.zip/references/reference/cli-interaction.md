# CLI-Optimized Interaction for SKILLs

> Claude Code 支持方向键 ↑↓ 选择、Enter 确认。
> 本规范让 SKILL 的人机交互在终端中自然、流畅、高效。

---

## 核心原则

**CLI-Native over Web-Like.** 选项是给终端看的，不是给网页看的。

| 原则 | 错误示例 | 正确示例 |
|------|---------|---------|
| 简短 | "已就绪，地址: 10.0.0.5:5432, 数据库: app_prod" | "已就绪: 10.0.0.5:5432" |
| 动词开头 | "我觉得可以继续" | "继续 →" |
| 一行一意 | "确认并写入文件，同时提交 git" | "确认 ✓" / "取消" |
| 可预览 | 选项旁带 preview 字段 | 含 mockup / diff 的选项 |

---

## 选项写作规范

### 1. Label — 简短、动词、可操作

```
✓ 确认写入
✗ 确认
✗ 这个选项代表确认并将文件写入磁盘然后提交 git
```

### 2. Description — 一行，讲清后果

```
"将生成 docs/requirements/order.md，git commit 后进入设计阶段"
```

### 3. 热键标注（如适用）

```
[→] 继续        [N] 暂缓，稍后继续
```

---

## 按 Pattern 重构

### Pattern 1: Binary Confirm — 精简为两行

**Before**:
```
"设计已完成，文档已保存。下一步是否进入测试计划（m-test）？"
options: [
  { label: "进入测试计划 (m-test)", description: "继续标准流程：设计 → 测试 → 计划 → 执行" },
  { label: "暂缓，稍后继续", description: "文档已保存。使用 'm-test' 可随时继续。" }
]
```

**After**（CLI-optimized）:
```
AskUserQuestion(
  question: "设计已完成。",
  options: [
    { label: "→ m-test", description: "继续：设计 → 测试 → 计划 → 执行" },
    { label: "稍后再说", description: "文档已保存。随时用 'm-test' 继续。" }
  ]
)
```

### Pattern 2: Structured Choice — 热键 + 预览

```
AskUserQuestion(
  question: "集成测试工具选型？",
  options: [
    { label: "[1] supertest + Jest", description: "Node.js，配置简单，REST API" },
    { label: "[2] Playwright API", description: "浏览器层，可测 SSR + cookies" },
    { label: "[3] Pytest + requests", description: "Python 生态，与单元测试共用框架" }
  ]
)
```

### Pattern 3: Sign-Off — 加编号让选择更快

```
AskUserQuestion(
  question: "需求摘要（3 AC）。请确认：",
  options: [
    { label: "[✓] 确认，无误", description: "写入文件 → git commit → 进入 m-design" },
    { label: "[~] 小调整", description: "说出需修改的部分，我将更新后再确认" },
    { label: "[✗] 取消", description: "不写入，不提交，本次会话结束" }
  ]
)
```

### Pattern 4: Resource Checklist — 全选/跳过快捷方式

```
AskUserQuestion(
  questions: [
    {
      question: "PostgreSQL (R-01)：",
      options: [
        { label: "[✓] 已就绪", description: "10.0.0.5:5432 / app_db" },
        { label: "[ ] 暂无", description: "T-007 标记阻塞" }
      ]
    },
    {
      question: "Redis (R-02)：",
      options: [
        { label: "[✓] 已就绪", description: "10.0.0.6:6379" },
        { label: "[ ] 暂无", description: "T-008 标记阻塞" }
      ]
    },
    {
      question: "全部就绪 → 跳过细节",
      options: [
        { label: "→ 全部确认，继续", description: "资源就绪，执行准备检查" }
      ]
    }
  ]
)
```

---

## 预览增强（AskUserQuestion preview 字段）

当选项涉及**视觉内容**（mockup、diff、架构图）时，用 preview 字段：

```
AskUserQuestion(
  question: "选择哪种布局？",
  options: [
    { label: "布局 A: 侧边导航", preview: "┌────┬──────────┐\n│导航│  内容区  │\n│    │          │\n└────┴──────────┘" },
    { label: "布局 B: 顶部导航", preview: "┌──────────────┐\n│    顶部导航   │\n├──────────────┤\n│     内容区   │\n└──────────────┘" }
  ]
)
```

当选项涉及**变更 diff** 时：

```
AskUserQuestion(
  question: "需求变更摘要（2 项）：",
  options: [
    { label: "→ 确认变更", preview: "AC-003:\n  - 依赖: [AC-001]\n  + 依赖: [AC-001, AC-002]\n\nAC-005:\n  - 优先级: P1\n  + 优先级: P0" },
    { label: "取消" }
  ]
)
```

---

## 交互节奏：快 → 慢 → 快

```
Phase 1: 快速确认（Binary Confirm）
  "文档已确认。继续？"
  → 1 秒决策

Phase 2: 实质性交互（Structured / Sign-Off）
  展示摘要 + 选项
  → 30 秒决策

Phase 3: 快速确认（Binary Confirm）
  "用例已生成完毕（47个TC）。提交 git？"
  → 1 秒决策
```

---

## SKILL 交互点速查卡

每个 SKILL 在写 AskUserQuestion 时，对照此表：

| 场景 | 格式 | 原则 |
|------|------|------|
| 继续/跳过 | Binary Confirm | 2 选项，↓ 后 + Enter 即可 |
| 方案选择 | Numbered Choice | [1] [2] [3]，按数字更快 |
| 文档确认 | Sign-Off | [✓] [~] [✗]，含义自明 |
| 资源输入 | Checklist | 逐项确认，最后加"→ 全部确认" |
| 开放澄清 | Plain text | 直接提问，不走 AskUserQuestion |
| 视觉/变更 | Preview 增强 | 用 preview 字段展示 diff/mockup |

---

## 热键约定（跨 SKILL 一致）

| 热键 | 含义 | 用于 |
|------|------|------|
| → | 继续/下一步 | Binary Confirm |
| ✓ | 确认/是 | Sign-Off |
| ~ | 修改 | Sign-Off |
| ✗ | 取消/否 | Sign-Off |
| [1] [2] [3] | 数字选择 | Structured Choice |
| [ ] | 未选中/暂无 | Checklist |

---

## AskUserQuestion 格式示例速查

```javascript
// 最小化：2 选项
AskUserQuestion({ question: "...", options: [{ label: "→ 继续" }, { label: "取消" }] })

// 推荐：带说明
AskUserQuestion({ question: "...", options: [
  { label: "→ m-test", description: "设计 → 测试 → 计划 → 执行" },
  { label: "稍后", description: "文档已保存。" }
]})

// 带预览
AskUserQuestion({ question: "选择布局：", options: [
  { label: "侧边导航", preview: "ASCII mockup..." },
  { label: "顶部导航", preview: "ASCII mockup..." }
]})
```
