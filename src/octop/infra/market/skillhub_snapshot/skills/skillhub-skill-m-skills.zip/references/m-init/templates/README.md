# {PROJECT_NAME}

> {PROJECT_DESCRIPTION}
> 作者: {AUTHOR}

## 技术栈

| 层级 | 技术 |
|------|------|
| {TECH_STACK_ROWS} |

## 文档导航

| 类型 | 入口 | 说明 |
|------|------|------|
| 📋 需求文档 | [需求索引](requirements-index.md) | 用户故事、验收标准、功能需求 |
| 📐 设计文档 | [设计索引](designs-index.md) | 技术方案、数据模型、API 设计 |
| 🧪 测试文档 | [测试索引](tests-index.md) | 测试计划、测试用例、回归向量 |
| 📦 执行计划 | [计划索引](plans-index.md) | 任务拆分、Wave 规划、执行记录 |
| 🔍 探索报告 | [探索索引](explorations-index.md) | 方案对比、根因分析、技术调研 |

## 开发端口

| 服务 | 端口 |
|------|------|
| 后端 API | {API_PORT} |
| 前端 Dev | {FRONTEND_PORT} |
| Docsify 文档 | {DOCS_PORT} |
