#!/bin/bash
set -e

# 0. 初始化 (首次使用取消注释)
# docsify init ./docs

# 关闭脚本钩子再全局安装 (首次使用取消注释)
#npm config set ignore-scripts true
#npm i docsify-cli -g

# 安装完恢复脚本执行权限（日常开发需要）
#npm config set ignore-scripts false

# 1. Regenerate sidebar and copy index files
python3 docs/generate_sidebar.py

# 2. Serve docsify
nohup docsify serve docs -H {SERVER_HOST} -p {DOCS_PORT} > /dev/null 2>&1 &
