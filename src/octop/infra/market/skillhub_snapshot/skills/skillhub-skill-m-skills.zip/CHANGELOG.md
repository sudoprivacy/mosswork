# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Changed

- `CLAUDE.md.template` 移至 `m-init/templates/CLAUDE.md`（技能市场上架限制），相关文档引用同步更新
- m-docs 市场说明改为 Docsify 工具，输出改为 `docs/` 文档站点（SKILL.md / README.md / CLAUDE.md / 模板同步）
- 根 SKILL.md frontmatter 补充 `name: m-skills` 字段（技能市场上架校验要求）

## [0.1.0] - 2026-07-30

### Added

- 初次公开发布 8 个技能：`m-chat`、`m-init`、`m-req`、`m-design`、`m-test`、`m-plan`、`m-execute`、`m-docs`
- `CLAUDE.md.template`：供采用本技能体系的项目复制到根目录
- MIT 协议
- 提交信息规范（`<type>(<scope>): <subject>`）

### Removed

- `m-quickstart`（内部 UI 演示技能）
- `m-docs.tar.gz`（开发期备份）

[Unreleased]: https://github.com/zhangmf/m-skills/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/zhangmf/m-skills/releases/tag/v0.1.0
