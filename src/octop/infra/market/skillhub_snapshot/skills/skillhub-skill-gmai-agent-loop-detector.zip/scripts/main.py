# -*- coding: utf-8 -*-
# gmai-agent-loop-detector command line entry (unique per skill)
import argparse
import json
import sys

import core

SPEC = {
    "slug": "gmai-agent-loop-detector",
    "displayName": "GMAI-Agent循环卡死检测大师",
    "engine": "detect_agent_loop",
    "version": "1.0.0",
}


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="gmai-agent-loop-detector",
        description="GMAI-Agent循环卡死检测大师：检测 Agent 调用轨迹中的重复调用、无进展循环、递归无终止、缺步数上限与失败无脑重试 付费技能，调用前需安装微信支付插件。")
    parser.add_argument("--input", required=True, help="输入 JSON 文件路径")
    parser.add_argument("--output", required=True, help="检测结果 JSON 输出路径")
    parser.add_argument("--version", action="version", version="gmai-agent-loop-detector 1.0.0")
    args = parser.parse_args(argv)
    with open(args.input, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    result = core.detect_agent_loop(payload)
    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=2)
    print("%s %s verdict=%s score=%s findings=%d"
          % (SPEC["slug"], SPEC["version"], result["verdict"],
             result["score"], len(result["findings"])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
