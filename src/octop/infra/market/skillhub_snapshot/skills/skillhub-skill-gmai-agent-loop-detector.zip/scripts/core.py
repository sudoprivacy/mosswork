# -*- coding: utf-8 -*-
# gmai-agent-loop-detector core (unique engine, stdlib json)
"""Agent 调用轨迹循环卡死检测引擎：重复调用、无进展循环、递归无终止、缺步数上限、失败无脑重试。"""
import json
from collections import defaultdict

_FAIL_STATUS = {"error", "failed", "failure", "fail", "errored"}
_BACKOFF_KEYS = ("backoff", "backoff_seconds", "delay", "wait_seconds", "retry_delay")
_STEP_KEYS = ("steps", "trace", "events", "trajectory")
_TERM_KEYS = ("termination_condition", "base_case", "stop_condition", "max_recursion_depth")


def _finding(rule, severity, line, desc, evidence, suggestion, path):
    return {"rule": rule, "severity": severity, "line": int(line),
            "description": desc, "evidence": str(evidence).strip()[:120],
            "suggestion": suggestion, "path": path}


def _tool(step):
    return str(step.get("tool") or step.get("name")
               or step.get("function") or step.get("action") or "").strip()


def _input(step):
    return step.get("input", step.get("arguments",
                    step.get("args", step.get("params", {}))))


def _output_text(step):
    value = step.get("output", step.get("result", step.get("response", "")))
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _intent(step):
    return str(step.get("intent") or step.get("thought") or step.get("goal") or "").strip()


def _failed(step):
    status = str(step.get("status") or step.get("state") or "").strip().lower()
    return status in _FAIL_STATUS or bool(step.get("error"))


def _has_backoff(step):
    for key in _BACKOFF_KEYS:
        try:
            if float(step.get(key) or 0) > 0:
                return True
        except (TypeError, ValueError):
            continue
    return False


def _key(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _squash(text):
    return "".join(str(text).split())


def _as_steps(doc):
    if isinstance(doc, list):
        return [s for s in doc if isinstance(s, dict)], {}
    if isinstance(doc, dict):
        for k in _STEP_KEYS:
            seq = doc.get(k)
            if isinstance(seq, list):
                return [s for s in seq if isinstance(s, dict)], doc
    return [], doc if isinstance(doc, dict) else {}


def _collect(payload):
    bundles = []
    direct_steps, direct_doc = _as_steps(payload)
    if direct_steps:
        bundles.append(("<inline>", direct_steps, direct_doc))
    for item in (payload.get("files") or []) if isinstance(payload, dict) else []:
        path = item.get("path", "<file>")
        if not str(path).lower().endswith(".json"):
            continue
        try:
            doc = json.loads(item.get("content") or "")
        except (ValueError, TypeError):
            continue
        steps, owner = _as_steps(doc)
        if steps:
            bundles.append((path, steps, owner))
    if isinstance(payload, dict) and payload.get("content") and not payload.get("files") \
            and not direct_steps:
        try:
            doc = json.loads(payload["content"])
        except (ValueError, TypeError):
            doc = None
        steps, owner = _as_steps(doc)
        if steps:
            bundles.append(("<inline>", steps, owner))
    return bundles


def _find_cycle(tools, edges):
    """DFS 三色法在调用图上找一条递归环路径。"""
    color = {t: 0 for t in tools}
    stack = []

    def dfs(u):
        color[u] = 1
        stack.append(u)
        for v in edges.get(u, []):
            if v not in color:
                continue
            if color[v] == 1:
                idx = stack.index(v)
                return stack[idx:] + [v]
            hit = dfs(v)
            if hit:
                return hit
        stack.pop()
        color[u] = 2
        return None

    for t in tools:
        if color[t] == 0:
            hit = dfs(t)
            if hit:
                return hit
    return None


def _flush_progress(run, findings, path):
    if len(run) >= 3:
        findings.append(_finding(
            "no_progress_loop", "Critical", run[-1]["i"],
            "第 %d-%d 步重复同一意图 %r 且输出完全相同，连续无新增信息"
            % (run[0]["i"], run[-1]["i"], run[0]["intent"] or run[0]["tool"]),
            "stuck-output=%s" % run[0]["out"].strip()[:80],
            "为循环设置进展判据（新信息/状态变化），连续无进展立即中止并升级", path))


def detect_agent_loop(payload):
    findings = []
    for path, steps, owner in _collect(payload or {}):
        cfg = owner.get("config") if isinstance(owner.get("config"), dict) else {}
        success_runs = defaultdict(list)
        fail_runs = defaultdict(list)
        enriched = []
        for i, step in enumerate(steps, 1):
            tool, inp = _tool(step), _input(step)
            rec = {"i": i, "tool": tool, "input": inp, "out": _output_text(step),
                   "intent": _intent(step), "failed": _failed(step),
                   "backoff": _has_backoff(step), "raw": step}
            enriched.append(rec)
            if tool:
                sig = (tool, _key(inp))
                (fail_runs if rec["failed"] else success_runs)[sig].append(rec)

        # ---- identical_call_repeat：相同 tool+相同 input 成功调用累计 >=3 ----
        for sig, recs in success_runs.items():
            if len(recs) >= 3:
                lines = [r["i"] for r in recs]
                findings.append(_finding(
                    "identical_call_repeat", "Critical", lines[-1],
                    "工具 %r 以完全相同的输入被重复调用 %d 次（步 %s），Agent 原地打转"
                    % (sig[0], len(recs), ",".join(str(x) for x in lines)),
                    "tool=%s input=%s" % (sig[0], sig[1][:80]),
                    "重复调用前比对缓存/状态是否变化，无变化则跳出循环并升级处理", path))

        # ---- no_progress_loop：连续 >=3 步同意图且输出无新增信息 ----
        run, prev_sig = [], None
        for rec in enriched:
            text = rec["out"].strip()
            sig = (rec["intent"] or rec["tool"], _squash(rec["out"])) if text else None
            if sig is not None and prev_sig is not None and sig == prev_sig:
                run.append(rec)
            else:
                _flush_progress(run, findings, path)
                run = [rec] if sig is not None else []
            prev_sig = sig
        _flush_progress(run, findings, path)

        # ---- repeated_failure_retry：同一失败调用无退避重试 >=3 ----
        for sig, recs in fail_runs.items():
            if len(recs) >= 3 and not any(r["backoff"] for r in recs):
                findings.append(_finding(
                    "repeated_failure_retry", "Major", recs[-1]["i"],
                    "失败调用 %r 在无退避/无参数调整情况下被无脑重试 %d 次"
                    % (sig[0], len(recs)),
                    "tool=%s retries=%d backoff=0" % (sig[0], len(recs)),
                    "失败重试必须指数退避并封顶次数，连续失败立即熔断并转人工", path))

        # ---- recursion_no_termination：调用图成环且无终止条件 ----
        tools, edges, seen_tools = [], defaultdict(list), set()
        for rec in enriched:
            t = rec["tool"]
            if t and t not in seen_tools:
                seen_tools.add(t)
                tools.append(t)
            callees = rec["raw"].get("calls", rec["raw"].get("invokes")) or []
            for callee in callees:
                cname = str(callee).strip()
                if cname and cname not in edges[t]:
                    edges[t].append(cname)
        cycle = _find_cycle(tools, edges)
        term_declared = any(owner.get(k) is not None or cfg.get(k) is not None
                            for k in _TERM_KEYS)
        term_declared = term_declared or any(
            r["raw"].get("base_case") or r["raw"].get("terminates") for r in enriched)
        if cycle and not term_declared:
            findings.append(_finding(
                "recursion_no_termination", "Major", len(steps),
                "函数调用链 %s 形成递归环，且轨迹中未声明任何终止条件/base_case"
                % " -> ".join(cycle),
                "cycle=%s" % " -> ".join(cycle),
                "递归必须声明 base_case 与最大递归深度，互调改为可收敛的迭代状态机", path))

        # ---- no_step_cap：轨迹无 max_steps/步数上限配置 ----
        cap = owner.get("max_steps", owner.get("step_cap",
                  owner.get("max_iterations", cfg.get("max_steps", cfg.get("step_cap")))))
        if steps and cap is None:
            findings.append(_finding(
                "no_step_cap", "Major", 1,
                "轨迹未配置 max_steps/步数上限，失控 Agent 可无限执行直至耗尽 token 与预算",
                "max_steps=<missing>",
                "在运行配置中声明 max_steps，达到上限强制中止并返回兜底响应", path))

    critical = sum(1 for f in findings if f["severity"] == "Critical")
    major = sum(1 for f in findings if f["severity"] == "Major")
    minor = sum(1 for f in findings if f["severity"] == "Minor")
    score = max(0, 100 - critical * 25 - major * 12 - minor * 4)
    verdict = "REJECT" if critical > 0 or major >= 2 or score < 70 else "PASS"
    summary = ("发现 %d 处 Agent 循环/失控风险(Critical %d/Major %d)"
               % (len(findings), critical, major)) if findings else "Agent 调用轨迹可收敛、无卡死模式"
    suggestions = sorted({"[%s] %s" % (f["rule"], f["suggestion"]) for f in findings})[:6]
    return {"verdict": verdict, "score": score, "findings": findings,
            "summary": summary, "suggestions": suggestions}
