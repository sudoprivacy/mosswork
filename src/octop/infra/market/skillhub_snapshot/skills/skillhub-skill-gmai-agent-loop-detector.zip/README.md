# GMAI-Agent循环卡死检测大师

检测 Agent 调用轨迹中的重复调用、无进展循环、递归无终止、缺步数上限与失败无脑重试

付费技能（X402 微信 Agent Pay，¥4.90/次），调用前需安装微信支付插件。

- 运行：`python main.py --input examples/input.json --output result.json`
- 测试：`python -m unittest discover -s test -v`
- 支付：见 SKILL.md「调用前置检查与支付引导」
