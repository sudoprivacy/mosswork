# 规则手册 - GMAI-Agent循环卡死检测大师

| rule | severity | 检测项 | 修复建议 |
|---|---|---|---|
| identical_call_repeat | Critical | 相同调用重复≥3次 | 状态比对+跳出循环 |
| no_progress_loop | Critical | 同意图同输出无进展 | 设置进展判据+中止 |
| recursion_no_termination | Major | 调用成环无终止条件 | base_case+深度上限 |
| no_step_cap | Major | 未配置步数上限 | 声明 max_steps 强制中止 |
| repeated_failure_retry | Major | 失败无退避重试 | 指数退避+熔断 |
