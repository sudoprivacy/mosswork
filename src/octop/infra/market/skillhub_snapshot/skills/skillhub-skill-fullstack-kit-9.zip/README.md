# 全栈锦囊（Fullstack Kit）

一囊九技的高级全栈工程师：网页全栈、微信小程序、Python 数据与 AI、UI 设计审查、浏览器自动化。先出计划再写代码，交付可运行的生产级实现。

## 类型

Agent 型（单个 AI 专家）

## 功能

- **全栈开发**：Node.js / Python / Go / Java / PHP 后端，React / Vue / Svelte 前端，PostgreSQL / MySQL / MongoDB / Redis 数据层
- **微信小程序**：原生框架（WXML/WXSS）、Skyline 渲染引擎、TDesign 组件库、云开发、微信支付/订阅消息/分享、分包与审核合规
- **架构设计**：微服务、事件驱动、DDD、REST / GraphQL / WebSocket
- **工程交付**：Docker、CI/CD、Nginx、云服务部署
- **质量把关**：内置代码自检清单，覆盖导入完整性、密钥硬编码、边界条件、SQL 参数化、XSS 转义

## 工作方式

1. 先输出不超过 10 行的任务分解（功能点 + 复杂度 + 技术选型）
2. 增量实现，每完成一块立即 lint / build / test 验证
3. 交付时给出清单、运行命令、已知限制

## 内置技能

| 技能 | 触发场景 |
|---|---|
| fullstack-dev | 全栈应用、REST API、后端服务、前后端集成 |
| frontend-dev | 前端 UI、复杂动效、AI 媒体资产 |
| impeccable | 高品质 UI 设计与审查、避免通用 AI 美学 |
| wechat-miniprogram | 微信小程序框架、组件、API、云开发 |
| tdesign-miniprogram | TDesign 60+ 小程序组件、主题定制 |
| skyline | Skyline 渲染引擎、worklet 动画、路由 |
| browser-use | 网页自动化、截图、数据提取 |

## 使用示例

- 帮我开发一个功能，我会描述需求，请你先给出实现计划再动手写代码。
- 帮我搭建一个全栈项目（前端+后端+数据库），包含用户认证功能
- Review 我的代码，找出潜在的性能问题和安全隐患

## 头像

头像位于 `avatars/expert.png`。如需替换：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

专家包目录：

```
C:\Users\Administrator\.workbuddy\plugins\marketplaces\my-experts\plugins\fullstack-kit\
```

注册命令：

```bash
python3 scripts/register_expert.py <expert-dir>
```

## 打包分享

```bash
zip -r fullstack-kit.zip fullstack-kit/
```
