# 数据分析参考（Pandas / Polars / Plotly）

## Pandas vs Polars
| 需求 | 选 |
|------|----|
| 生态成熟、要 `.plot` / 老代码兼容 | Pandas |
| 大表（>1M 行）、要快、惰性执行 | **Polars**（`LazyFrame` 自动优化） |

```python
import polars as pl
df = pl.read_csv("data.csv").lazy() \
      .filter(pl.col("amount") > 0) \
      .group_by("category").agg(pl.col("amount").sum()) \
      .sort("amount", descending=True).collect()
```

## 清洗套路
- 缺失：`df.drop_nulls(subset=[...])` / `fill_null(strategy="forward")`，不要盲目 `dropna()` 丢数据
- 类型：`cast` 明确 dtype，读入后先 `dtypes` 核对（金额别用 float 累加，用 Decimal 或分单位 int）
- 去重：`unique(subset=[...], keep="first")`
- 关联：`join` 前确认关联键无重复，避免行数爆炸

## 可视化（Plotly，可交互）
```python
import plotly.express as px
fig = px.bar(df, x="category", y="amount", title="销售构成")
fig.write_html("chart.html")   # 或 fig.show()
```

## 常见坑
- `SettingWithCopyWarning` → 链式赋值先 `.copy()`，或用 `.loc[row_mask, col] =`
- 浮点求和误差 → 金额累加用整数分；展示再 `/100`
- 内存爆 → 读大文件用 `chunksize` / Polars 惰性 + 投影只取所需列
- 时区混乱 → 统一 `UTC` 存、展示时本地化；`.dt` 操作前确认 `tz`
- 类别型未编码 → 模型前 `astype("category")` 或 `OneHotEncoder`，别把字符串当数值喂进去
