# 合并文档 第1部分（共1部分，含 9 个组件）


---

# [attachments]

# Attachments 文件附件

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-attachments": "tdesign-miniprogram/attachments/attachments"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/nsYgGtm58k4g)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

#### 图片类型

**WXML** (`html`):
```html
<view class="chat-example">
<view class="chat-example-block">
<t-attachments items="{{items}}" bind:fileClick="onFileClick" bind:remove="onRemove" bind:add="onAdd" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Page({
data: {
items: [
{
fileType: 'image',
name: 'sample-image.jpg',
url: 'https://tdesign.gtimg.com/site/avatar.jpg',
size: 1024,
status: 'success',
},
],
},

onFileClick(e) {
const { item } = e.detail;
console.log('点击文件:', item);
wx.showToast({
title: `点击了${item.name}`,
icon: 'none',
});
},

onRemove(e) {
const { item, index } = e.detail;
console.log('删除文件:', e, item, '索引:', index);

// 从列表中移除文件
const newItems = [...this.data.items];
newItems.splice(index, 1);

this.setData({
items: newItems,
});

wx.showToast({
title: '删除成功',
icon: 'success',
});
},

onAdd() {
console.log('点击添加按钮');
wx.showToast({
title: '点击了添加按钮',
icon: 'none',
});

// 模拟添加新文件
const newFile = {
fileType: 'txt',
name: `新文件${this.data.items.length + 1}.txt`,
url: 'https://example.com/newfile.txt',
size: 256,
status: 'success',
};

this.setData({
items: [...this.data.items, newFile],
});
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
padding: 32rpx;
background-color: var(--td-bg-color-container);
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-attachments": "tdesign-miniprogram/attachments/attachments"
}
}

```

#### 文件类型

**WXML** (`html`):
```html
<view class="chat-example">
<!-- 有效的示例，呈现效果为 单行滚动 -->
<!-- <view class="chat-example-block">
<t-attachments items="{{items}}" bind:fileClick="onFileClick" bind:remove="onRemove" bind:add="onAdd" />
</view> -->

<view class="chat-example-block" wx:for="{{items}}" wx:for-item="item" wx:key="url">
<t-attachments items="{{[item]}}" bind:fileClick="onFileClick" bind:remove="onRemove" bind:add="onAdd" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Page({
data: {
items: [
{
fileType: 'doc',
name: 'word-file.doc',
url: 'https://example.com/word-file.doc',
size: 222859,
status: 'success',
},
{
fileType: 'excel',
name: 'excel-file.xlsx',
url: 'https://example.com/excel-file.xlsx',
size: 222859,
status: 'success',
},
{
fileType: 'pdf',
name: 'pdf-file.pdf',
url: 'https://example.com/pdf-file.pdf',
size: 222859,
status: 'success',
},
{
fileType: 'ppt',
name: 'ppt-file.pptx',
url: 'https://example.com/ppt-file.pptx',
size: 222859,
status: 'success',
},
{
fileType: 'video',
name: 'video-file.mp4',
url: 'https://example.com/video-file.mp4',
size: 222859,
status: 'success',
},
{
fileType: 'file',
name: 'file',
url: 'https://example.com/audio-file.mp3',
size: 222859,
status: 'success',
},
],
},

onFileClick(e) {
const { item } = e.detail;
console.log('点击文件:', item);
wx.showToast({
title: `点击了${item.name}`,
icon: 'none',
});
},

onRemove(e) {
const { item, index } = e.detail;
console.log('删除文件:', e, item, '索引:', index);

// 从列表中移除文件
const newItems = [...this.data.items];
newItems.splice(index, 1);

this.setData({
items: newItems,
});

wx.showToast({
title: '删除成功',
icon: 'success',
});
},

onAdd() {
console.log('点击添加按钮');
wx.showToast({
title: '点击了添加按钮',
icon: 'none',
});

// 模拟添加新文件
const newFile = {
fileType: 'txt',
name: `新文件${this.data.items.length + 1}.txt`,
url: 'https://example.com/newfile.txt',
size: 256,
status: 'success',
};

this.setData({
items: [...this.data.items, newFile],
});
},
});

```

**CSS** (`css`):
```css
.chat-example {
padding: 32rpx;
box-sizing: border-box;
background-color: var(--td-bg-color-container);
}

.chat-example-block {
display: inline-flex;
width: 336rpx;
margin-bottom: 26rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"styleIsolation": "isolated",
"usingComponents": {
"t-attachments": "tdesign-miniprogram/attachments/attachments"
}
}

```

### 02组件状态

#### 图片类型加载状态

**WXML** (`html`):
```html
<view class="chat-example">
<view class="chat-example-block">
<t-attachments items="{{items}}" bind:fileClick="onFileClick" bind:remove="onRemove" bind:add="onAdd" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Page({
data: {
items: [
{
fileType: 'image',
name: 'sample-image.jpg',
url: 'https://tdesign.gtimg.com/site/avatar.jpg',
size: 1024,
status: 'pending',
},
],
},

onFileClick(e) {
const { item } = e.detail;
console.log('点击文件:', item);
wx.showToast({
title: `点击了${item.name}`,
icon: 'none',
});
},

onRemove(e) {
const { item, index } = e.detail;
console.log('删除文件:', e, item, '索引:', index);

// 从列表中移除文件
const newItems = [...this.data.items];
newItems.splice(index, 1);

this.setData({
items: newItems,
});

wx.showToast({
title: '删除成功',
icon: 'success',
});
},

onAdd() {
console.log('点击添加按钮');
wx.showToast({
title: '点击了添加按钮',
icon: 'none',
});

// 模拟添加新文件
const newFile = {
fileType: 'txt',
name: `新文件${this.data.items.length + 1}.txt`,
url: 'https://example.com/newfile.txt',
size: 256,
status: 'success',
};

this.setData({
items: [...this.data.items, newFile],
});
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
padding: 32rpx;
background-color: var(--td-bg-color-container);
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-attachments": "tdesign-miniprogram/attachments/attachments"
}
}

```

#### 文件类型加载状态

**WXML** (`html`):
```html
<view class="chat-example">
<view class="chat-example-block">
<t-attachments items="{{items}}" bind:fileClick="onFileClick" bind:remove="onRemove" bind:add="onAdd" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Page({
data: {
items: [
{
fileType: 'doc',
name: 'word-file.doc',
url: 'https://example.com/word-file.doc',
size: 222859,
status: 'pending',
},
],
},

onFileClick(e) {
const { item } = e.detail;
console.log('点击文件:', item);
wx.showToast({
title: `点击了${item.name}`,
icon: 'none',
});
},

onRemove(e) {
const { item, index } = e.detail;
console.log('删除文件:', e, item, '索引:', index);

// 从列表中移除文件
const newItems = [...this.data.items];
newItems.splice(index, 1);

this.setData({
items: newItems,
});

wx.showToast({
title: '删除成功',
icon: 'success',
});
},

onAdd() {
console.log('点击添加按钮');
wx.showToast({
title: '点击了添加按钮',
icon: 'none',
});

// 模拟添加新文件
const newFile = {
fileType: 'txt',
name: `新文件${this.data.items.length + 1}.txt`,
url: 'https://example.com/newfile.txt',
size: 256,
status: 'success',
};

this.setData({
items: [...this.data.items, newFile],
});
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
padding: 32rpx;
background-color: var(--td-bg-color-container);
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-attachments": "tdesign-miniprogram/attachments/attachments"
}
}

```

## API

### AttachmentsProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| addable | Boolean | true | 【讨论中】是否显示添加按钮 | N |
| image-viewer | Boolean | true | 是否启用图片预览功能 | N |
| items | Array | [] | 必需。附件列表。TS 类型：`FileItem[]``interface FileItem { fileType: 'image'\|'video'\|'audio'\|'pdf'\|'doc'\|'ppt'\|'txt'; name: string; url: string; size: number; status?: 'success'\|'fail'\|'pending'\|'error'; progress?: number; errorMessage?: string; fileIcon?: string; width?: number; height?: number; mode?: 'aspectFit' \| 'aspectFill' \| 'widthFix' \| 'heightFix' \| 'scaleToFill'}`。详细类型定义 | Y |
| removable | Boolean | true | 是否显示删除按钮 | N |

### AttachmentsEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| add | - | 点击添加按钮时触发 |
| file-click | `(item: FileItem)` | 点击文件时触发 |
| remove | `(item: FileItem, index: number)` | 点击删除按钮时触发 |

---

# [chat-actionbar]

# ChatActionbar 对话操作

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/TfXVvtmM8I4c)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

#### 基础类型

**WXML** (`html`):
```html
<t-toast id="t-toast" />
<view class="container">
<t-chat-actionbar content="{{content}}" bind:actions="handleAction" />
</view>

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';

Component({
data: {
content: '这是一段可以被复制的内容，支持markdown格式。\n\n**粗体文本**\n*斜体文本*\n\n- 列表项1\n- 列表项2',
},

methods: {
handleAction(e) {
const { name, active, data } = e.detail;

let message = '';
switch (name) {
case 'replay':
message = '重新生成';
break;
case 'copy':
console.log(data);
message = '复制成功';
break;
case 'good':
message = active ? '点赞成功' : '取消点赞';
break;
case 'bad':
message = active ? '点踩成功' : '取消点踩';
break;
case 'share':
message = '分享功能';
break;
default:
message = `执行了${name}操作`;
}

Toast({
context: this,
selector: '#t-toast',
message,
theme: 'success',
});
},
},
});

```

**CSS** (`css`):
```css
.container {
padding: 32rpx;
background-color: var(--td-bg-color-container);
}

.layout-btn {
margin: 16rpx 0;
padding: 12rpx 24rpx;
background-color: #0052d9;
color: #fff;
border: none;
border-radius: 8rpx;
font-size: 28rpx;
}

.demo-text {
padding: 16rpx 0;
}

.checkbox-group {
display: flex;
flex-wrap: wrap;
gap: 16rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

### 02组件状态

#### 手动初始化状态

**WXML** (`html`):
```html
<t-toast id="t-toast" />
<view class="container">
<t-chat-actionbar content="{{content}}" bind:actions="handleAction" comment="{{comment}}" />
</view>

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';

Page({
data: {
content: '这是一段可以被复制的内容，支持markdown格式。\n\n**粗体文本**\n*斜体文本*\n\n- 列表项1\n- 列表项2',
comment: 'good',
},

handleAction(e) {
const { name, active, data } = e.detail;

let message = '';
switch (name) {
case 'replay':
message = '重新生成';
break;
case 'copy':
console.log(data);
message = '复制成功';
break;
case 'good':
message = active ? '点赞成功' : '取消点赞';
break;
case 'bad':
message = active ? '点踩成功' : '取消点踩';
break;
case 'share':
message = '分享功能';
break;
default:
message = `执行了${name}操作`;
}

Toast({
context: this,
selector: '#t-toast',
message,
theme: 'success',
});
},
});

```

**CSS** (`css`):
```css
.container {
padding: 32rpx;
background-color: var(--td-bg-color-container);
}

.layout-btn {
margin: 16rpx 0;
padding: 12rpx 24rpx;
background-color: #0052d9;
color: #fff;
border: none;
border-radius: 8rpx;
font-size: 28rpx;
}

.demo-text {
padding: 16rpx 0;
}

.checkbox-group {
display: flex;
flex-wrap: wrap;
gap: 16rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

## API

### ChatActionbarProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| action-bar | Array | ['replay', 'copy', 'good', 'bad', 'share'] | 操作栏配置。TS 类型：`Array<'replay'\|'copy'\|'good'\|'bad'\|'share'>` | N |
| chat-id | String | - | 【实验】聊天消息的唯一标识 | N |
| comment | String | - | 评价内容 | N |
| content | String | - | 被复制的内容 | N |
| copy-mode | String | markdown | 【实验】复制内容的模式，可选 'markdown'（复制markdown原文）或 'text'（复制纯文本）。可选项：markdown/text | N |
| disabled | Boolean | false | 【讨论中】操作按钮是否可点击 | N |
| placement | String | start | 【实验】操作栏位置。可选项：start/end/space-around/space-between | N |

### ChatActionbarEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| actions | `(detail: {name: string, active: boolean})` | 点击点赞，点踩，复制，分享，重新生成按钮时触发发 |

---

# [chat-content]

# ChatContent 对话正文

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-chat-content": "tdesign-miniprogram/chat-content/chat-content"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/rIY05tmE8p4o)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

- 对大模型返回的 markdown 数据自动渲染。markdown 会内置调用 `t-chat-markdown` 渲染，同时可根据 role（user/assistant）切换样式。
- 用户发送的消息保持默认格式显示，纯文本会做 HTML 转义并用 rich-text 渲染；

**WXML** (`html`):
```html
<view class="chat-example">
<view class="title">用户内容纯文本支持HTML转义</view>
<view class="chat-example-block">
<t-chat-content content="{{userContent}}" role="user"></t-chat-content>
</view>
</view>

<view class="chat-example">
<view class="title">助手内容（Markdown）</view>
<view class="chat-example-block">
<t-chat-content content="{{assistantContent}}" role="assistant"></t-chat-content>
</view>
</view>

```

**JS** (`javascript`):
```javascript
// import { Lexer } from 'marked';
import markdownData from './mock.js';

// 创建Lexer实例时添加配置，禁用gfm规范中的缩进代码块
// const lexer = new Lexer({});

// const tokens = lexer.lex(markdownData);

Component({
data: {
userContent: {
type: 'text',
data: '这是用户发送的普通文本内容',
},
assistantContent: {
type: 'markdown',
data: markdownData,
},
},
methods: {},
});

```

**CSS** (`css`):
```css
.chat-example {
margin-bottom: 32rpx;
}

.chat-example-block {
padding: 32rpx;
background-color: var(--td-bg-color-container);
}

.title {
padding: 0 32rpx 32rpx;
font-size: 28rpx;
line-height: 44rpx;
color: var(--bg-color-demo-desc);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-chat-content": "tdesign-miniprogram/chat-content/chat-content"
}
}

```

**MOCK** (`javascript`):
```javascript
const mockMarkdownData = `# Markdown功能测试 (H1标题)

## 基础语法测试 (H2标题)

### 列表测试

- 无序列表项1
- 无序列表项2
- 缩进列表项1（4个空格缩进）
- 缩进列表项2（4个空格缩进）

1. 有序列表项1
2. 有序列表项2
1. 缩进有序列表项1（4个空格缩进）
2. 缩进有序列表项2（4个空格缩进）

### 代码块测试

\`\`\`javascript
// JavaScript 代码块
function greet(name) {
console.log(\`Hello, \${name}!\`);
}
greet('Markdown');
\`\`\`

### 其他元素

> 引用文本块
> 多行引用内容

**加粗文字** _斜体文字_ ~~删除线~~

这是一个链接 [TDesign](https://tdesign.tencent.com)。
`;

export default mockMarkdownData;

```

## API

### ChatContentProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| content | Object | - | 必需。聊天内容对象。TS 类型：`TdChatContentType ``interface TdChatContentType { type: 'text' \| 'markdown'; data: string; }`。详细类型定义 | Y |
| markdown-props | Object | - | marked 解析器的配置选项。TS 类型：`ChatMarkdownProps`，ChatMarkdown API Documents。详细类型定义 | N |
| role | String | - | 必需。消息角色，用于区分用户和助手的消息样式	。可选项：user/assistant/system | Y |
| status | String | - | 正文状态。可选项：error / '' | N |

---

# [chat-list]

# ChatList 对话列表

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-chat": "tdesign-miniprogram/chat-list/chat-list"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/Cl1guumx824W)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

#### 基础使用

**WXML** (`html`):
```html
<view class="chat-box" style="height: {{contentHeight}};">
<t-chat id="chatList" bindscroll="onScroll">
<block wx:for="{{chatList}}" wx:key="index">
<t-chat-message
avatar="{{item.avatar || ''}}"
name="{{item.name || ''}}"
datetime="{{item.datetime || ''}}"
content="{{item.content}}"
role="{{item.role}}"
placement="{{item.role === 'user' ? 'right' : 'left'}}"
status="{{item.status || ''}}"
>
<t-chat-actionbar
wx:if="{{chatIndex !== chatList.length - 1 && item.status === 'complete' && item.role === 'assistant'}}"
slot="actionbar"
placement="end"
bind:actions="handleAction"
/>
</t-chat-message>
</block>
<view slot="footer">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
autoRiseWithKeyboard="{{true}}"
renderPresets="{{renderPresets}}"
bind:send="onSend"
bind:stop="onStop"
bind:focus="onFocus"
/>
</view>
</t-chat>
<!-- 内置虚拟列表优化性能仅在data属性中使用 -->
<!-- <t-chat id="chatList" bindscroll="onScroll" data="{{chatList}}"></t-chat> -->
</view>
<t-toast id="t-toast" />

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';
import { getNavigationBarHeight } from '../../../utils/utils';

const mockData = `南极的自动提款机并没有一个特定的专属名称，但历史上确实有一台ATM机曾短暂存在于南极的**麦克默多站**（McMurdo Station）。这台ATM由美国**富兰克林国家银行**（Wells Fargo）于1998年安装，主要供驻扎在该站的科研人员使用。不过，由于南极的极端环境和极低的人口密度，这台ATM机并未长期运行，最终被移除。

**背景补充：**
- **麦克默多站**是美国在南极最大的科研基地，夏季人口可达约1,000人，冬季约200人。
- 该ATM机更多是作为一种象征性服务存在，实际使用频率极低，因为南极科考人员通常依靠预支资金或电子支付。
- 目前南极已无长期运行的ATM机，现代科考站更多依赖非现金交易方式。

南极作为非主权领土，其基础设施以科研和生活支持为主，商业金融服务非常有限。若有类似设施，通常是临时或实验性质的。`;

const sleep = (ms) => {
return new Promise((resolve) => setTimeout(resolve, ms));
};

const fetchStream = async (str, options) => {
const { success, complete, delay = 100 } = options;

const arr = str.split('');

for (let i = 0; i < arr.length; i += 1) {
// eslint-disable-next-line no-await-in-loop
await sleep(delay);
success(arr[i]);
}

complete();
};

Component({
options: {
styleIsolation: 'shared',
},
data: {
renderPresets: [{ name: 'send', type: 'icon' }],
chatList: [
{
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
role: 'assistant',
status: 'complete',
content: [
{
type: 'text',
data: '它叫 McMurdo Station ATM，是美国富国银行安装在南极洲最大科学中心麦克默多站的一台自动提款机。',
},
],
},
{
role: 'user',
content: [
{
type: 'text',
data: '牛顿第一定律是否适用于所有参考系？',
},
],
},
],
value: '', // 输入框的值
loading: false, // 加载状态
disabled: false, // 禁用状态
inputStyle: '', // 输入框样式
contentHeight: '100vh', // 内容高度
animation: 'dots',
},

methods: {
// 调用chatList的滚动到底部方法
scrollToBottom() {
const chatListComponent = this.selectComponent('#chatList');
if (chatListComponent && typeof chatListComponent.scrollToBottom === 'function') {
chatListComponent.scrollToBottom();
}
},
onScroll(e) {
console.log('监听滚动', e);
},
// 发送消息事件处理
onSend(e) {
const { value } = e.detail;
if (!value || value.trim() === '') return;

// 创建用户消息对象
const userMessage = {
role: 'user',
content: [
{
type: 'text',
data: value.trim(),
},
],
};

// 将用户消息插入到chatList的开头（因为reverse为true，所以用unshift）
this.setData({
chatList: [userMessage, ...this.data.chatList],
value: '', // 清空输入框
});

// 模拟助手回复（可选）
this.simulateAssistantReply(value.trim());
},

// 停止事件处理
onStop() {
this.setData({
loading: false,
});
},

// 聚焦事件处理
onFocus() {
console.log('输入框聚焦');
},
// 获取当前时间
getCurrentTime() {
const now = new Date();
const hours = now.getHours().toString().padStart(2, '0');
const minutes = now.getMinutes().toString().padStart(2, '0');
return `${hours}:${minutes}`;
},

// 模拟助手回复
simulateAssistantReply() {
this.setData({ loading: true});
// 请求中
const assistantMessage = {
role: 'assistant',
content: [
{
type: 'markdown',
data: '',
},
],
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
status: 'pending',
};
this.setData({
chatList: [assistantMessage, ...this.data.chatList],
});
const that = this;
wx.nextTick(() => {
fetchStream(mockData, {
success(result) {
// 生文中
that.data.chatList[0].status = 'streaming';
if (!that.data.loading) return;
that.data.chatList[0].content[0].data += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {
that.data.chatList[0].status = 'complete';
that.setData({
chatList: that.data.chatList,
});
that.setData({
loading: false,
});
},
});
});
},
handleAction(e) {
const { name, active, data } = e.detail;

let message = '';
switch (name) {
case 'replay':
message = '重新生成';
break;
case 'copy':
console.log(data);
message = '复制成功';
break;
case 'good':
message = active ? '点赞成功' : '取消点赞';
break;
case 'bad':
message = active ? '点踩成功' : '取消点踩';
break;
case 'share':
message = '分享功能';
break;
default:
message = `执行了${name}操作`;
}

Toast({
context: this,
selector: '#t-toast',
message,
theme: 'success',
});
},
},
lifetimes: {
attached: function () {
/**
* 计算内容区域高度
* 生成CSS calc表达式：calc(100vh - 96rpx - 导航高度 - 底部安全区域高度)
*/
try {
// 获取当前的导航栏高度和安全区域高度
const navigationBarHeight = getNavigationBarHeight() || 0;

// 生成CSS calc表达式字符串
const contentHeight = `calc(100vh - 96rpx - ${navigationBarHeight}px)`;

this.setData({
contentHeight: contentHeight,
});

console.log('内容区域高度CSS表达式:', contentHeight);
} catch (error) {
console.error('生成内容高度表达式失败:', error);
this.setData({
contentHeight: 'calc(100vh - 96rpx)',
});
}
},
},
});

```

**CSS** (`css`):
```css
.chat-box {
padding-top: 32rpx;
box-sizing: border-box;
}

.t-chat__list {
padding: 0 0 0 32rpx;
box-sizing: border-box;
}

.t-chat-message {
padding: 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-content": "tdesign-miniprogram/chat-content/chat-content",
"t-chat": "tdesign-miniprogram/chat-list/chat-list",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

**MOCK** (`javascript`):
```javascript
// file test

```

#### 组合式用法

**WXML** (`html`):
```html
<view class="chat-box" style="height: {{contentHeight}};">
<t-chat>
<block wx:for="{{chatList}}" wx:key="index">
<t-chat-message
avatar="{{item.avatar || ''}}"
name="{{item.name || ''}}"
datetime="{{item.datetime || ''}}"
content="{{item.message.content}}"
role="{{item.message.role}}"
placement="{{item.message.role === 'user' ? 'right' : 'left'}}"
>
<t-chat-actionbar
wx:if="{{chatIndex !== chatList.length - 1 && item.message.status === 'complete' && item.message.role === 'assistant'}}"
slot="actionbar"
placement="end"
bind:actions="handleAction"
/>
</t-chat-message>
</block>
<view slot="footer">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
renderPresets="{{renderPresets}}"
bind:send="onSend"
bind:stop="onStop"
bind:focus="onFocus"
autoRiseWithKeyboard="{{true}}"
/>
</view>
</t-chat>
</view>
<t-toast id="t-toast" />

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';
import { getNavigationBarHeight } from '../../../utils/utils';

const mockData = {
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
role: 'assistant',
content: [
{
type: 'thinking',
status: 'complete',
data: {
title: '思考中',
text: '',
},
},
],
},
};

const mockData1 =
'嗯，用户问的是南极的自动提款机叫什么名字。这个问题有点有趣，因为南极是一个极端寒冷的地方，而且大部分地区都是无人居住的科研站。\n';

const mockData2 =
'\n\n南极的自动提款机并没有一个特定的专属名称，但历史上确实有一台ATM机曾短暂存在于南极的**麦克默多站**（McMurdo Station）。这台ATM由美国**富兰克林国家银行**（Wells Fargo）于1998年安装，主要供驻扎在该站的科研人员使用。不过，由于南极的极端环境和极低的人口密度，这台ATM机并未长期运行，最终被移除。\n\n**背景补充：**\n- **麦克默多站**是美国在南极最大的科研基地，夏季人口可达约1,000人，冬季约200人。\n- 该ATM机更多是作为一种象征性服务存在，实际使用频率极低，因为南极科考人员通常依靠预支资金或电子支付。\n- 目前南极已无长期运行的ATM机，现代科考站更多依赖非现金交易方式。\n\n南极作为非主权领土，其基础设施以科研和生活支持为主，商业金融服务非常有限。若有类似设施，通常是临时或实验性质的。';

const sleep = (ms) => {
return new Promise((resolve) => setTimeout(resolve, ms));
};

const fetchStream = async (str, options) => {
const { success, complete, delay = 100 } = options;

const arr = str.split('');

for (let i = 0; i < arr.length; i += 1) {
// eslint-disable-next-line no-await-in-loop
await sleep(delay);
success(arr[i]);
}

complete();
};

Component({
properties: {
isActive: {
type: Boolean,
value: false,
observer: function (v) {
this.setData({
value: v ? '南极的自动提款机叫什么名字' : '', // 输入框的值
});
},
},
},
data: {
renderPresets: [
{
name: 'send',
type: 'icon',
},
],
chatList: [
{
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
status: 'complete',
role: 'assistant',
content: [
{
type: 'text',
data: '它叫 McMurdo Station ATM，是美国富国银行安装在南极洲最大科学中心麦克默多站的一台自动提款机。',
},
],
},
},
{
message: {
role: 'user',
content: [
{
type: 'text',
data: '牛顿第一定律是否适用于所有参考系？',
},
],
},
},
],

value: '',
loading: false, // 加载状态
disabled: false, // 禁用状态
inputStyle: '', // 动态样式
contentHeight: '100vh', // 内容高度
},

methods: {
// 发送消息事件处理
onSend(e) {
const { value } = e.detail;
if (!value || value.trim() === '') return;

// 创建用户消息对象
const userMessage = {
message: {
role: 'user',
content: [
{
type: 'text',
data: value.trim(),
},
],
},
};

// 将用户消息插入到chatList的开头（因为reverse为true，所以用unshift）
this.setData({
chatList: [userMessage, ...this.data.chatList],
value: '', // 清空输入框
});

// 模拟助手回复（可选）
this.simulateAssistantReply(value.trim());
},

// 停止事件处理
onStop() {
console.log('停止发送');
this.setData({
loading: false,
});
},

// 聚焦事件处理
onFocus() {
console.log('输入框聚焦');
},

// 获取当前时间
getCurrentTime() {
const now = new Date();
const hours = now.getHours().toString().padStart(2, '0');
const minutes = now.getMinutes().toString().padStart(2, '0');
return `${hours}:${minutes}`;
},

// 模拟助手回复
simulateAssistantReply() {
this.setData({ loading: true });

const assistantMessage = mockData;

this.setData({
chatList: [assistantMessage, ...this.data.chatList],
});

const that = this;
wx.nextTick(async () => {
await fetchStream(mockData1, {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[0].data.text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {
that.data.chatList[0].message.content[0].data.title = '思考完成';
that.setData({
chatList: that.data.chatList,
});
},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content.push({
type: 'markdown',
data: '',
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream(mockData2, {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].data += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {
that.data.chatList[0].message.status = 'complete';
that.setData({
chatList: that.data.chatList,
});
that.setData({
loading: false,
});
},
});
});
},
handleAction(e) {
const { name, active, data } = e.detail;

let message = '';
switch (name) {
case 'replay':
message = '重新生成';
break;
case 'copy':
console.log(data);
message = '复制成功';
break;
case 'good':
message = active ? '点赞成功' : '取消点赞';
break;
case 'bad':
message = active ? '点踩成功' : '取消点踩';
break;
case 'share':
message = '分享功能';
break;
default:
message = `执行了${name}操作`;
}

Toast({
context: this,
selector: '#t-toast',
message,
theme: 'success',
});
},
},
lifetimes: {
attached: function () {
console.log('-----attached----');
/**
* 计算内容区域高度
* 生成CSS calc表达式：calc(100vh - 96rpx - 导航高度 - 底部安全区域高度)
*/
try {
// 获取当前的导航栏高度和安全区域高度
const navigationBarHeight = getNavigationBarHeight() || 0;

// 生成CSS calc表达式字符串
const contentHeight = `calc(100vh - 96rpx - ${navigationBarHeight}px)`;

this.setData({
contentHeight: contentHeight,
});

console.log('内容区域高度CSS表达式:', contentHeight);
} catch (error) {
console.error('生成内容高度表达式失败:', error);
this.setData({
contentHeight: 'calc(100vh - 96rpx)',
});
}
},
},
});

```

**CSS** (`css`):
```css
.chat-box {
padding-top: 32rpx;
box-sizing: border-box;
}

.t-chat__list {
padding: 0 0 0 32rpx;
box-sizing: border-box;
}

.t-chat-message {
padding: 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-content": "tdesign-miniprogram/chat-content/chat-content",
"t-chat": "tdesign-miniprogram/chat-list/chat-list",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

#### 自定义

`t-chat-message`支持`content`自定义，使用建议：渲染聊天消息统一用 `t-chat-content`；仅在需要“单独使用 Markdown 组件”或自定义管线时使用 `t-chat-markdown`。也支持别的 markdown 渲染组件，选择其他 markdown 渲染库由用户自行安装。

**WXML** (`html`):
```html
<view class="chat-box chart-chat" style="height: {{contentHeight}};">
<t-chat>
<block wx:for="{{chatList}}" wx:key="index" wx:for-index="chatIndex">
<t-chat-message
class="{{item.message.role}}"
avatar="{{item.avatar || ''}}"
name="{{item.name || ''}}"
datetime="{{item.datetime || ''}}"
role="{{item.message.role || 'assistant'}}"
placement="{{item.message.role === 'user' ? 'right' : 'left'}}"
>
<view slot="content">
<block
wx:for="{{item.message.content}}"
wx:for-item="contentItem"
wx:for-index="contentIndex"
wx:key="contentIndex"
>
<t-chat-content
content="{{contentItem}}"
wx:if="{{contentItem.type === 'text' || contentItem.type === 'markdown'}}"
/>
<!-- 封装的图表组件见源码 -->
<chart-component wx:if="{{contentItem.type === 'chart'}}" el="normalLine" options="{{contentItem}}" />
</block>
</view>
<t-chat-actionbar
wx:if="{{chatIndex !== chatList.length - 1 && item.message.status === 'complete' && item.message.role === 'assistant'}}"
slot="actionbar"
placement="end"
bind:actions="handleAction"
/>
</t-chat-message>
</block>
<view slot="footer">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
renderPresets="{{renderPresets}}"
bind:send="onSend"
bind:stop="onStop"
bind:focus="onFocus"
autoRiseWithKeyboard="{{true}}"
/>
</view>
</t-chat>
</view>
<t-toast id="t-toast" />

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';
import { getNavigationBarHeight } from '../../../utils/utils';

const sleep = (ms) => {
return new Promise((resolve) => setTimeout(resolve, ms));
};

const fetchStream = async (str, options) => {
const { success, complete, delay = 100 } = options;

const arr = str.split('');

for (let i = 0; i < arr.length; i += 1) {
// eslint-disable-next-line no-await-in-loop
await sleep(delay);
success(arr[i]);
}

complete();
};

Component({
properties: {
isActive: {
type: Boolean,
value: false,
observer: function (v) {
this.setData({
value: v ? '南极的自动提款机叫什么名字' : '', // 输入框的值
});
},
},
},

options: {
styleIsolation: 'shared',
},
data: {
renderPresets: [
{
name: 'send',
type: 'icon',
},
],
chatList: [
{
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
role: 'assistant',
content: [
{
type: 'text',
data: '欢迎使用TDesign智能图表分析助手，请输入你的问题',
},
],
},
},
],
value: '', // 输入框的值
loading: false, // 加载状态
disabled: false, // 禁用状态
inputStyle: '', // 动态样式
contentHeight: '100vh', // 内容高度
},
methods: {
// 发送消息事件处理
onSend(e) {
const { value } = e.detail;
if (!value || value.trim() === '') return;

// 创建用户消息对象
const userMessage = {
message: {
role: 'user',
content: [
{
type: 'text',
data: value.trim(),
},
],
},
};

// 将用户消息插入到chatList的开头（因为reverse为true，所以用unshift）
this.setData({
chatList: [userMessage, ...this.data.chatList],
value: '', // 清空输入框
});

// 模拟助手回复（可选）
this.simulateAssistantReply(value.trim());
},

// 停止事件处理
onStop() {
console.log('停止发送');
this.setData({
loading: false,
});
},

// 聚焦事件处理
onFocus() {
console.log('输入框聚焦');
},

// 获取当前时间
getCurrentTime() {
const now = new Date();
const hours = now.getHours().toString().padStart(2, '0');
const minutes = now.getMinutes().toString().padStart(2, '0');
return `${hours}:${minutes}`;
},

// 模拟助手回复
simulateAssistantReply() {
this.setData({ loading: true });

const assistantMessage = {
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
role: 'assistant',
content: [
{
type: 'markdown',
data: '',
},
],
},
};

const list = [assistantMessage, ...this.data.chatList];

this.setData({
chatList: list,
});

const that = this;
wx.nextTick(async () => {
await fetchStream(
'今日上午北京道路车辆通行状况9:00的峰值（1320),可能显示早高峰拥堵最严重时段10:00后缓慢回落，可以得出如下折线图：',
{
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[0].data += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
},
);

if (!that.data.loading) return;

that.data.chatList[0].message.content.push(
{
type: 'chart',
data: {
id: 8379.117942106575,
chartType: 'line',
options: {
xAxis: {
boundaryGap: true,
type: 'category',
data: ['0:00', '1:00', '2:00', '3:00', '4:00', '5:00', '6:00'],
},
yAxis: {
type: 'value',
},
series: [
{
data: [500, 401, 382, 433, 560, 630, 720],
type: 'line',
},
],
},
},
},
{
type: 'markdown',
data: '',
},
);
that.setData({
chatList: that.data.chatList,
});

await fetchStream(
'今日晚上北京道路车辆通行状况18:00的峰值（1322),可能显示早高峰拥堵最严重时段21:00后缓慢回落，可以得出如下折线图：',
{
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[2].data += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
},
);

if (!that.data.loading) return;

that.data.chatList[0].message.content.push({
type: 'chart',
data: {
id: 9954.694158956194,
chartType: 'line',
options: {
xAxis: {
boundaryGap: true,
type: 'category',
data: ['0:00', '1:00', '2:00', '3:00', '4:00', '5:00', '6:00'],
},
yAxis: {
type: 'value',
},
series: [
{
data: [500, 401, 382, 433, 560, 630, 720],
type: 'line',
},
],
},
},
strategy: 'append',
status: 'complete',
});
that.data.chatList[0].message.status = 'complete';
that.setData({
chatList: that.data.chatList,
loading: false,
});
});
},
handleAction(e) {
const { name, active, data } = e.detail;

let message = '';
switch (name) {
case 'replay':
message = '重新生成';
break;
case 'copy':
console.log(data);
message = '复制成功';
break;
case 'good':
message = active ? '点赞成功' : '取消点赞';
break;
case 'bad':
message = active ? '点踩成功' : '取消点踩';
break;
case 'share':
message = '分享功能';
break;
default:
message = `执行了${name}操作`;
}

Toast({
context: this,
selector: '#t-toast',
message,
theme: 'success',
});
},
},
lifetimes: {
attached: function () {
/**
* 计算内容区域高度
* 生成CSS calc表达式：calc(100vh - 96rpx - 导航高度 - 底部安全区域高度)
*/
try {
// 获取当前的导航栏高度和安全区域高度
const navigationBarHeight = getNavigationBarHeight() || 0;

// 生成CSS calc表达式字符串
const contentHeight = `calc(100vh - 96rpx - ${navigationBarHeight}px)`;

this.setData({
contentHeight: contentHeight,
});

console.log('内容区域高度CSS表达式:', contentHeight);
} catch (error) {
console.error('生成内容高度表达式失败:', error);
this.setData({
contentHeight: 'calc(100vh - 96rpx)',
});
}
},
},
});

```

**CSS** (`css`):
```css
.chat-box {
padding-top: 32rpx;
box-sizing: border-box;
}

.t-chat__list {
padding: 0 0 0 32rpx;
box-sizing: border-box;
}

.t-chat-message {
padding: 0 32rpx;
}

.chart-chat .assistant .t-chat__detail {
width: 100%;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-toast": "tdesign-miniprogram/toast/toast",
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-content": "tdesign-miniprogram/chat-content/chat-content",
"t-chat": "tdesign-miniprogram/chat-list/chat-list",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"chart-component": "../chart-component"
}
}

```

#### 文案助手

**WXML** (`html`):
```html
<view class="chat-box" style="height: {{contentHeight}};">
<t-chat>
<block wx:for="{{chatList}}" wx:key="index" wx:for-index="chatIndex">
<t-chat-message
avatar="{{item.avatar || ''}}"
name="{{item.name || ''}}"
datetime="{{item.datetime || ''}}"
content="{{item.message.content}}"
role="{{item.message.role}}"
chatContentProps="{{chatContentProps}}"
placement="{{item.message.role === 'user' ? 'right' : 'left'}}"
>
<t-chat-actionbar
wx:if="{{chatIndex !== chatList.length - 1 && item.message.status === 'complete' && item.message.role === 'assistant'}}"
slot="actionbar"
actionBar="{{customActionBar}}"
bind:actions="handleAction"
/>
</t-chat-message>
</block>
<view slot="footer">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
bind:send="onSend"
fileList="{{fileList}}"
bind:stop="onStop"
bind:focus="onFocus"
bind:keyboardheightchange="onkeyboardheightchange"
bind:updateVisible="onUpdateVisible"
bind:fileDelete="onFileDelete"
bind:fileChange="onFileChange"
attachmentsProps="{{attachmentsProps}}"
renderPresets="{{renderPresets}}"
autoRiseWithKeyboard="{{true}}"
visible="{{visible}}"
/>
</view>
</t-chat>
</view>
<t-toast id="t-toast" />

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';
import { getNavigationBarHeight } from '../../../utils/utils';

const mockData1 =
'🌼宝子们，春天来啦，这些户外郊游打卡地你必须知道👏\n\n🌟郊野公园\n这里有大片的草地和各种花卉，随便一拍都是大片既视感📷。还能放风筝、野餐，享受惬意的春日时光。\n\n🌳植物园\n各种珍稀植物汇聚于此，仿佛置身于绿色的海洋。漫步其中，感受大自然的神奇与美丽。\n\n💧湖边湿地\n湖水清澈，周围生态环境优越。能看到很多候鸟和水生植物，是亲近自然的好去处。\n\n宝子们，赶紧收拾行囊，去这些地方打卡吧😜。\n\n#春天郊游 #打卡目的地 #户外之旅 #春日美景';

const sleep = (ms) => {
return new Promise((resolve) => setTimeout(resolve, ms));
};

const fetchStream = async (str, options) => {
const { success, complete, delay = 100 } = options;

const arr = str.split('');

for (let i = 0; i < arr.length; i += 1) {
// eslint-disable-next-line no-await-in-loop
await sleep(delay);
success(arr[i]);
}

complete();
};

Component({
properties: {
isActive: {
type: Boolean,
value: false,
observer: function (v) {
// 延迟 30ms，避免 hidden 场景下， value 变更无法触发 textarea 的自动换行
// 代码片段（iOS 真机可复现）：https://developers.weixin.qq.com/s/7UoAYgmr8G4k
setTimeout(() => {
this.setData({
value: v ? '根据所提供的材料总结一篇文章，推荐春天户外郊游打卡目的地，需要符合小红书平台写作风格' : '', // 输入框的值
});
}, 30);
},
},
},
data: {
customActionBar: ['copy', 'good', 'bad'],
chatList: [
{
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
role: 'assistant',
content: [
{
type: 'text',
data: '欢迎使用TDesign文案写作助手，可以先上传你需要参考的文件，输入你要撰写的主题~',
},
],
},
},
],
value: '', // 输入框的值
loading: false, // 加载状态
disabled: false, // 禁用状态
inputStyle: '', // 动态样式
attachmentsProps: {
items: [],
removable: true,
imageViewer: true,
addable: false,
},
renderPresets: [
{
name: 'upload',
presets: ['uploadCamera', 'uploadImage', 'uploadAttachment'],
status: '',
},
{
name: 'send',
type: 'icon',
},
],
fileList: [],
visible: false, // 是否显示选择文件面板
chatContentProps: {
thinking: { maxHeight: 100, collapsed: true },
},
contentHeight: '100vh', // 内容高度
},

methods: {
// 发送消息事件处理
onSend(e) {
const { value } = e.detail;
if (!value || value.trim() === '') return;

// 创建用户消息对象
const content = [
{
type: 'text',
data: value.trim(),
},
];
const attachments = this.data.attachmentsProps.items.map((item) => {
return {
...item,
status: 'success',
};
});
content.unshift({
type: 'attachment',
data: attachments,
});
this.setData({
attachmentsProps: {
...this.data.attachmentsProps,
items: [],
},
fileList: [],
});
const userMessage = {
message: {
role: 'user',
content,
},
};

// 将用户消息插入到chatList的开头（因为reverse为true，所以用unshift）
this.setData({
chatList: [userMessage, ...this.data.chatList],
value: '', // 清空输入框
});

// 模拟助手回复（可选）
this.simulateAssistantReply(value.trim());
},

// 停止事件处理
onStop() {
console.log('停止发送');
this.setData({
loading: false,
});
},

// 聚焦事件处理
onFocus() {
console.log('输入框聚焦');
},

// 打开选择文件界面
onUpdateVisible(e) {
const visible = e.detail;
console.log('上传面板显示状态:', visible);
this.setData({ visible });
},

onFileDelete() {
this.setData({
attachmentsProps: {
...this.data.attachmentsProps,
items: [],
},
});
},

onFileChange(e) {
const { files } = e.detail;
this.setData({ attachmentsProps: { ...this.data.attachmentsProps, items: files } });
this.setData({ fileList: files });
},

// 模拟助手回复
simulateAssistantReply() {
this.setData({ loading: true });

const assistantMessage = {
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
role: 'assistant',
content: [
{
type: 'markdown',
data: '',
},
],
},
};

this.setData({
chatList: [assistantMessage, ...this.data.chatList],
});

const that = this;
wx.nextTick(() => {
fetchStream(mockData1, {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[0].data += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {
that.data.chatList[0].message.status = 'complete';
that.setData({
chatList: that.data.chatList,
});
that.setData({
loading: false,
});
},
});
});
},
handleAction(e) {
const { name, active, data } = e.detail;

let message = '';
switch (name) {
case 'replay':
message = '重新生成';
break;
case 'copy':
console.log(data);
message = '复制成功';
break;
case 'good':
message = active ? '点赞成功' : '取消点赞';
break;
case 'bad':
message = active ? '点踩成功' : '取消点踩';
break;
case 'share':
message = '分享功能';
break;
default:
message = `执行了${name}操作`;
}

Toast({
context: this,
selector: '#t-toast',
message,
theme: 'success',
});
},
},
lifetimes: {
attached: function () {
/**
* 计算内容区域高度
* 生成CSS calc表达式：calc(100vh - 96rpx - 导航高度 - 底部安全区域高度)
*/
try {
// 获取当前的导航栏高度和安全区域高度
const navigationBarHeight = getNavigationBarHeight() || 0;

// 生成CSS calc表达式字符串
const contentHeight = `calc(100vh - 96rpx - ${navigationBarHeight}px)`;

this.setData({
contentHeight: contentHeight,
});

console.log('内容区域高度CSS表达式:', contentHeight);
} catch (error) {
console.error('生成内容高度表达式失败:', error);
this.setData({
contentHeight: 'calc(100vh - 96rpx)',
});
}
},
},
});

```

**CSS** (`css`):
```css
.chat-box {
padding-top: 32rpx;
box-sizing: border-box;
}

.t-chat__list {
padding: 0 0 0 32rpx;
box-sizing: border-box;
}

.t-chat-message {
padding: 0 32rpx;
}

.preview {
padding: 16rpx;
display: flex;
justify-content: space-between;
border: 1px solid black;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-content": "tdesign-miniprogram/chat-content/chat-content",
"t-chat": "tdesign-miniprogram/chat-list/chat-list",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

#### 图像生成

**WXML** (`html`):
```html
<view class="chat-box image-chat" style="height: {{contentHeight}};">
<t-chat>
<block wx:for="{{chatList}}" wx:key="index" wx:for-index="chatIndex">
<t-chat-message
avatar="{{item.avatar || ''}}"
name="{{item.name || ''}}"
datetime="{{item.datetime || ''}}"
role="{{item.message.role}}"
placement="{{item.message.role === 'user' ? 'right' : 'left'}}"
>
<view wx:if="{{item.message.role === 'user'}}" slot="content">
<block
wx:for="{{item.message.content}}"
wx:for-item="contentItem"
wx:for-index="contentIndex"
wx:key="contentIndex"
>
<t-chat-content
content="{{contentItem}}"
wx:if="{{contentItem.type === 'text' || contentItem.type === 'markdown'}}"
/>
</block>
</view>
<view wx:else style="width: 100%" slot="content">
<block
wx:for="{{item.message.content}}"
wx:for-item="contentItem"
wx:for-index="contentIndex"
wx:key="contentIndex"
>
<t-chat-content
content="{{contentItem}}"
wx:if="{{contentItem.type === 'text' || contentItem.type === 'markdown'}}"
/>
<view wx:else class="attachment-slide">
<t-attachments items="{{contentItem.data}}" inChat="{{true}}" removable="{{false}}" />
</view>
</block>
</view>
<t-chat-actionbar
wx:if="{{chatIndex !== chatList.length - 1 && item.message.status === 'complete' && item.message.role === 'assistant'}}"
slot="actionbar"
placement="end"
bind:actions="handleAction"
/>
</t-chat-message>
</block>
<view slot="footer">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
renderPresets="{{renderPresets}}"
bind:send="onSend"
bind:stop="onStop"
bind:focus="onFocus"
autoRiseWithKeyboard="{{true}}"
/>
</view>
</t-chat>
</view>
<t-toast id="t-toast" />

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';
import { getNavigationBarHeight } from '../../../utils/utils';

const sleep = (ms) => {
return new Promise((resolve) => setTimeout(resolve, ms));
};

const fetchStream = async (str, options) => {
const { success, complete, delay = 100 } = options;

const arr = str.split('');

for (let i = 0; i < arr.length; i += 1) {
// eslint-disable-next-line no-await-in-loop
await sleep(delay);
success(arr[i]);
}

complete();
};

Component({
properties: {
isActive: {
type: Boolean,
value: false,
observer: function (v) {
this.setData({
value: v ? '请为Tdesign设计三张品牌宣传图' : '', // 输入框的值
});
},
},
},
options: {
styleIsolation: 'shared',
},
data: {
renderPresets: [
{
name: 'send',
type: 'icon',
},
],
customActionBar: ['good', 'bad'],
chatList: [
{
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
role: 'assistant',
content: [
{
type: 'text',
data: '欢迎使用TDesign智能生图助手，请先写下你的创意，可以试试上传参考图哦～',
},
],
},
},
],
value: '', // 输入框的值
loading: false, // 加载状态
disabled: false, // 禁用状态
inputStyle: '', // 输入框动态样式
attachmentsProps: {
items: [],
removable: true,
imageViewer: true,
addable: false,
},
contentHeight: '100vh', // 内容高度
},

methods: {
// 发送消息事件处理
onSend(e) {
const { value } = e.detail;
if (!value || value.trim() === '') return;

// 创建用户消息对象
const userMessage = {
message: {
role: 'user',
content: [
{
type: 'text',
data: value.trim(),
},
],
},
};

// 将用户消息插入到chatList的开头（因为reverse为true，所以用unshift）
this.setData({
chatList: [userMessage, ...this.data.chatList],
value: '', // 清空输入框
});

// 模拟助手回复（可选）
this.simulateAssistantReply(value.trim());
},

// 停止事件处理
onStop() {
console.log('停止发送');
this.setData({
loading: false,
});
},

// 聚焦事件处理
onFocus() {
console.log('输入框聚焦');
},

// 打开选择文件界面
onUpdateVisible() {
const that = this;
wx.chooseMessageFile({
count: 1,
type: 'file',
success(res) {
const tempFile = res.tempFiles[0];
console.log('选择的文件信息：', tempFile);
const item = {
fileType: 'doc',
name: tempFile.name,
url: tempFile.path,
size: tempFile.size,
status: 'success',
};
that.setData({
attachmentsProps: {
...that.data.attachmentsProps,
items: [item],
},
});
},
fail(err) {
console.error('选择文件失败：', err);
},
});
},

// 模拟助手回复
simulateAssistantReply() {
this.setData({ loading: true });

const assistantMessage = {
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
role: 'assistant',
content: [
{
type: 'markdown',
data: '',
},
],
},
};

this.setData({
chatList: [assistantMessage, ...this.data.chatList],
});

const that = this;
wx.nextTick(async () => {
await fetchStream('接下来我将生成符合要求的图片', {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[0].data += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content.push({
type: 'imageview',
status: 'complete',
data: [
{
name: 'sample1.png',
url: 'https://tdesign.gtimg.com/site/square.png',
fileType: 'image',
status: 'success',
size: 1032,
width: 128,
height: 128,
},
{
name: 'sample2.png',
url: 'https://tdesign.gtimg.com/site/square.png',
fileType: 'image',
status: 'success',
size: 1032,
width: 128,
height: 128,
},
{
name: 'sample3.png',
url: 'https://tdesign.gtimg.com/site/square.png',
fileType: 'image',
status: 'success',
size: 1032,
width: 128,
height: 128,
},
{
name: 'sample4.png',
url: 'https://tdesign.gtimg.com/site/square.png',
fileType: 'image',
status: 'success',
size: 1032,
width: 128,
height: 128,
},
{
name: 'sample5.png',
url: 'https://tdesign.gtimg.com/site/square.png',
fileType: 'image',
status: 'success',
size: 1032,
width: 128,
height: 128,
},
],
});
that.data.chatList[0].message.status = 'complete';
that.setData({
chatList: that.data.chatList,
loading: false,
});
});
},
handleAction(e) {
const { name, active, data } = e.detail;
console.log('----', name);
let message = '';
switch (name) {
case 'replay':
message = '重新生成';
break;
case 'copy':
console.log(data);
message = '复制成功';
break;
case 'good':
message = active ? '点赞成功' : '取消点赞';
break;
case 'bad':
message = active ? '点踩成功' : '取消点踩';
break;
case 'share':
message = '分享功能';
break;
default:
message = `执行了${name}操作`;
}

Toast({
context: this,
selector: '#t-toast',
message,
theme: 'success',
});
},
},
lifetimes: {
attached: function () {
/**
* 计算内容区域高度
* 生成CSS calc表达式：calc(100vh - 96rpx - 导航高度 - 底部安全区域高度)
*/
try {
// 获取当前的导航栏高度和安全区域高度
const navigationBarHeight = getNavigationBarHeight() || 0;

// 生成CSS calc表达式字符串
const contentHeight = `calc(100vh - 96rpx - ${navigationBarHeight}px)`;

this.setData({
contentHeight: contentHeight,
});

console.log('内容区域高度CSS表达式:', contentHeight);
} catch (error) {
console.error('生成内容高度表达式失败:', error);
this.setData({
contentHeight: 'calc(100vh - 96rpx)',
});
}
},
},
});

```

**CSS** (`css`):
```css
.chat-box {
padding-top: 32rpx;
box-sizing: border-box;
}

.image-chat .t-chat__list {
padding: 0 0 0 0;
box-sizing: border-box;
}

.t-chat-message {
padding: 0 32rpx;
}

.image-chat .t-chat__inner.assistant .t-chat__avatar {
padding-left: 32rpx;
}

.image-chat .assistant,
.image-chat .assistant .t-chat__detail {
width: 100%;
}

.attachment-slide {
height: 274rpx;
width: 100%;
}

.attachment-slide .t-attachments {
padding-right: 32rpx;
padding-top: 24rpx;
box-sizing: border-box;
position: fixed;
z-index: 2;
left: 0;
right: 0;
}

.attachment-slide .t-attachments .t-attachments__files:first-child {
padding-left: 120rpx;
}

.attachment-slide .t-attachments .t-attachments__files:last-child {
padding-right: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-content": "tdesign-miniprogram/chat-content/chat-content",
"t-chat": "tdesign-miniprogram/chat-list/chat-list",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"t-attachments": "tdesign-miniprogram/attachments/attachments",
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

#### 任务规划

**WXML** (`html`):
```html
<view class="chat-box" style="height: {{contentHeight}};">
<t-chat>
<block wx:for="{{chatList}}" wx:key="index" wx:for-index="chatIndex">
<t-chat-message
avatar="{{item.avatar || ''}}"
name="{{item.name || ''}}"
datetime="{{item.datetime || ''}}"
role="{{item.message.role}}"
placement="{{item.message.role === 'user' ? 'right' : 'left'}}"
>
<view slot="content">
<block
wx:for="{{item.message.content}}"
wx:for-item="contentItem"
wx:for-index="contentIndex"
wx:key="contentIndex"
>
<t-chat-content
content="{{contentItem}}"
wx:if="{{contentItem.type === 'text' || contentItem.type === 'markdown'}}"
/>
<view class="step" wx:if="{{contentItem.type === 'agent'}}">
<t-steps layout="vertical" current="{{contentItem.content.steps.length}}">
<t-step-item wx:for="{{contentItem.content.steps}}" wx:key="index" title="{{item.step}}">
<view slot="content" class="step-text-list">
<view
wx:for="{{item.tasks}}"
wx:key="index"
wx:for-item="taskItem"
class="step-text {{taskItem.type}}"
>
<t-icon
wx:if="{{taskItem.type === 'command'}}"
name="control-platform"
size="32rpx"
class="step-icon"
/>
{{taskItem.text}}
</view>
</view>
</t-step-item>
</t-steps>
</view>
</block>
</view>
<t-chat-actionbar
wx:if="{{chatIndex !== chatList.length - 1 && item.message.status === 'complete' && item.message.role === 'assistant'}}"
slot="actionbar"
placement="end"
bind:actions="handleAction"
/>
</t-chat-message>
</block>
<view slot="footer">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
renderPresets="{{renderPresets}}"
bind:send="onSend"
bind:stop="onStop"
bind:focus="onFocus"
autoRiseWithKeyboard="{{true}}"
/>
</view>
</t-chat>
</view>
<t-toast id="t-toast" />

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';
import { getNavigationBarHeight } from '../../../utils/utils';

const sleep = (ms) => {
return new Promise((resolve) => setTimeout(resolve, ms));
};

const fetchStream = async (str, options) => {
const { success, complete, delay = 100 } = options;

const arr = str.split('');

for (let i = 0; i < arr.length; i += 1) {
// eslint-disable-next-line no-await-in-loop
await sleep(delay);
success(arr[i]);
}

complete();
};

Component({
properties: {
contentHeight: {
type: String,
value: '100vh',
},

isActive: {
type: Boolean,
value: false,
observer: function (v) {
this.setData({
value: v ? '请帮我做一个5岁儿童生日聚会的规划' : '', // 输入框的值
});
},
},
},

options: {
styleIsolation: 'shared',
},
data: {
renderPresets: [
{
name: 'send',
type: 'icon',
},
],
chatList: [
{
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
role: 'assistant',
content: [
{
type: 'text',
data: '欢迎使用TDesign Agent家庭活动策划助手，请给我布置任务吧～',
},
],
},
},
],
value: '', // 输入框的值
loading: false, // 加载状态
disabled: false, // 禁用状态
inputStyle: '', // 输入框动态样式
},

methods: {
// 发送消息事件处理
onSend(e) {
const { value } = e.detail;
if (!value || value.trim() === '') return;

// 创建用户消息对象
const userMessage = {
message: {
role: 'user',
content: [
{
type: 'text',
data: value.trim(),
},
],
},
};

// 将用户消息插入到chatList的开头（因为reverse为true，所以用unshift）
this.setData({
chatList: [userMessage, ...this.data.chatList],
value: '', // 清空输入框
});

// 模拟助手回复（可选）
this.simulateAssistantReply(value.trim());
},

// 停止事件处理
onStop() {
console.log('停止发送');
this.setData({
loading: false,
});
},

// 聚焦事件处理
onFocus() {
console.log('输入框聚焦');
},

// 模拟助手回复
simulateAssistantReply() {
this.setData({ loading: true });

const assistantMessage = {
avatar: 'https://tdesign.gtimg.com/site/chat-avatar.png',
message: {
role: 'assistant',
content: [
{
type: 'markdown',
data: '',
},
],
},
};

this.setData({
chatList: [assistantMessage, ...this.data.chatList],
});

const that = this;
wx.nextTick(async () => {
await fetchStream('为5岁小朋友准备一场生日派对，我会根据要求准备合适方案，计划从以下几个步骤进行准备：', {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[0].data += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content.push({
type: 'agent',
id: 'task1',
content: {
text: '',
steps: [],
},
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream('生日聚会规划任务已分解为3个执行阶段', {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].content.text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content[1].content.steps.push({
step: '确定派对餐饮方案',
agent_id: 'a1',
tasks: [
{
type: 'command',
text: '',
},
],
status: 'finish',
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream('调用智能搜索工具', {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].content.steps[0].tasks[0].text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content[1].content.steps[0].tasks.push({
type: 'command',
text: '',
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream('已筛选出3种高性价比菜单方案，开始进行营养匹配', {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].content.steps[0].tasks[1].text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content[1].content.steps[0].tasks.push({
type: 'result',
text: '',
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream('主菜是香草烤鸡（无麸质），准备耗时45分钟；', {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].content.steps[0].tasks[2].text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content[1].content.steps.push({
step: '准备派对现场布置',
agent_id: 'a2',
tasks: [
{
type: 'command',
text: '',
},
],
status: 'finish',
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream('调用智能搜索工具，搜索儿童派对用品清单', {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].content.steps[1].tasks[0].text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content[1].content.steps[1].tasks.push({
type: 'result',
text: '',
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream(
'推荐现场布置方案：餐具（一次性纸盘、刀叉套装）、杯子、纸巾、一次性桌布，装饰气球、横幅、礼帽等',
{
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].content.steps[1].tasks[1].text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
},
);

if (!that.data.loading) return;

that.data.chatList[0].message.content[1].content.steps.push({
step: '策划派对活动',
agent_id: 'a1',
tasks: [
{
type: 'command',
text: '',
},
],
status: 'finish',
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream('搜索儿童派对游戏', {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].content.steps[2].tasks[0].text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content[1].content.steps[2].tasks.push({
type: 'command',
text: '',
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream('整理信息并进行合理性分析，安全性评估', {
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].content.steps[2].tasks[1].text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
});

if (!that.data.loading) return;

that.data.chatList[0].message.content[1].content.steps[2].tasks.push({
type: 'result',
text: '',
});
that.setData({
chatList: that.data.chatList,
});

await fetchStream(
'派对总时长建议控制在1.5小时，符合5岁儿童注意力持续时间，每位小朋友到达时可以在拍照区留影，可设置一个签到',
{
success(result) {
if (!that.data.loading) return;
that.data.chatList[0].message.content[1].content.steps[2].tasks[2].text += result;
that.setData({
chatList: that.data.chatList,
});
},
complete() {},
},
);
that.data.chatList[0].message.status = 'complete';
that.setData({
chatList: that.data.chatList,
});
that.setData({
loading: false,
});
});
},
handleAction(e) {
const { name, active, data } = e.detail;

let message = '';
switch (name) {
case 'replay':
message = '重新生成';
break;
case 'copy':
console.log(data);
message = '复制成功';
break;
case 'good':
message = active ? '点赞成功' : '取消点赞';
break;
case 'bad':
message = active ? '点踩成功' : '取消点踩';
break;
case 'share':
message = '分享功能';
break;
default:
message = `执行了${name}操作`;
}

Toast({
context: this,
selector: '#t-toast',
message,
theme: 'success',
});
},
},
lifetimes: {
attached: function () {
/**
* 计算内容区域高度
* 生成CSS calc表达式：calc(100vh - 96rpx - 导航高度 - 底部安全区域高度)
*/
try {
// 获取当前的导航栏高度和安全区域高度
const navigationBarHeight = getNavigationBarHeight() || 0;

// 生成CSS calc表达式字符串
const contentHeight = `calc(100vh - 96rpx - ${navigationBarHeight}px)`;

this.setData({
contentHeight: contentHeight,
});

console.log('内容区域高度CSS表达式:', contentHeight);
} catch (error) {
console.error('生成内容高度表达式失败:', error);
this.setData({
contentHeight: 'calc(100vh - 96rpx)',
});
}
},
},
});

```

**CSS** (`css`):
```css
.chat-box {
padding-top: 32rpx;
box-sizing: border-box;
}

.t-chat__list {
padding: 0 0 0 32rpx;
box-sizing: border-box;
}
.t-chat-message {
padding: 0 32rpx;
}

.preview {
padding: 16rpx;
display: flex;
justify-content: space-between;
border: 1px solid var(--td-component-border);
}

.step {
padding-top: 24rpx;
}

.step-text-list {
display: flex;
flex-direction: column;
gap: 16rpx;
}

.step-text {
text-align: start;
}

.step-text.command {
padding: 16rpx;
border-radius: 16rpx;
background-color: var(--td-bg-color-secondarycontainer);
display: flex;
font-size: 28rpx;
line-height: 44rpx;
color: var(--td-text-color-secondary);
}

.step-text.result {
font-size: 28rpx;
line-height: 44rpx;
color: var(--td-text-color-primary);
}

.step-icon {
margin-right: 12rpx;
margin-top: 6rpx;
}

.t-steps-item__circle--finish {
background-color: transparent;
color: var(--td-text-color-primary);
border: 1px solid var(--td-text-color-primary);
width: 16px;
height: 16px;
}

.t-steps-item__circle--finish .t-icon {
font-size: 12px;
}

.t-steps-item__line--finish {
background-color: var(--td-component-border);
}

.t-steps-item__title--finish {
color: var(--td-text-color-primary);
font-weight: 600;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-content": "tdesign-miniprogram/chat-content/chat-content",
"t-chat": "tdesign-miniprogram/chat-list/chat-list",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"t-steps": "tdesign-miniprogram/steps/steps",
"t-step-item": "tdesign-miniprogram/step-item/step-item",
"t-icon": "tdesign-miniprogram/icon/icon",
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

## API

### ChatListProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| animation | String | skeleton | 动画效果，支持「渐变加载动画」,「闪烁加载动画」, 「骨架屏」三种。可选项：skeleton/moving/gradient/dot | N |
| data | Array | - | 对话列表的数据。TS 类型：`Array<TdChatItemMeta>`` interface TdChatItemMeta { avatar?: string; name?:string; role?:string; datetime?: string; content?: string; status?: string }`。详细类型定义 | N |
| layout | String | both | 对话布局形式，支持两侧对齐与左对齐。使用插槽自定义对话内容时不生效，得用`t-chat-message`的`placement`属性。可选项：both/single | N |
| reverse | Boolean | true | 是否表现为倒序 | N |

### ChatListEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| scroll | `(detail: {scrollLeft, scrollTop, scrollHeight, scrollWidth, deltaX, deltaY})` | 滚动事件的回调 |

### ChatListSlots

| 名称 | 描述 |
| --- | --- |
| actionbar | 自定义操作按钮的插槽 |

---

# [chat-loading]

# ChatLoading 对话加载

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-chat-loading": "tdesign-miniprogram/chat-loading/chat-loading"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/GQYNbtmE8g4C)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

支持多种加载中动效类型，包括 gradient、moving、dots

**WXML** (`html`):
```html
<view class="chat-example">
<!-- <view class="chat-example-block">
<t-chat-loading animation="skeleton" />
</view> -->
<view class="chat-example-block">
<t-chat-loading animation="gradient" />
</view>
<view class="chat-example-block">
<t-chat-loading animation="moving" />
</view>
<view class="chat-example-block">
<t-chat-loading animation="dots" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
currentAnimation: 'skeleton',
loadingText: '',
animations: [
{ key: 'moving', text: '正在理解中...' },
{ key: 'gradient', text: '深度思考中...' },
{ key: 'circle', text: '加载中...' },
{ key: 'skeleton', text: '' },
],
},

onLoad() {
// 模拟动画切换
this.startAnimationCycle();
},

startAnimationCycle() {
let index = 0;
this.animationTimer = setInterval(() => {
const animation = this.data.animations[index];
this.setData({
currentAnimation: animation.key,
loadingText: animation.text,
});

index = (index + 1) % this.data.animations.length;
}, 2000); // 每2秒切换一次动画
},

onUnload() {
// 清理定时器
if (this.animationTimer) {
clearInterval(this.animationTimer);
}
},

// 手动切换动画类型
switchAnimation(e) {
const { animation } = e.currentTarget.dataset;
const animationData = this.data.animations.find((item) => item.key === animation);

if (animationData) {
this.setData({
currentAnimation: animationData.key,
loadingText: animationData.text,
});
}
},
});

```

**CSS** (`css`):
```css
.chat-example {
background-color: var(--td-bg-color-container);
padding: 32rpx;
display: flex;
align-items: center;
gap: 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-loading": "tdesign-miniprogram/chat-loading/chat-loading",
"t-col": "tdesign-miniprogram/col/col",
"t-row": "tdesign-miniprogram/row/row"
}
}

```

#### 带文案描述的加载组件

**WXML** (`html`):
```html
<view class="chat-example">
<view class="chat-example-block">
<t-chat-loading animation="dots" text="加载中..." />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {},
});

```

**CSS** (`css`):
```css
.chat-example {
background-color: var(--td-bg-color-container);
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-loading": "tdesign-miniprogram/chat-loading/chat-loading"
}
}

```

## API

### ChatLoadingProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| animation | String | moving | 加载的状态形式。可选项：skeleton/moving/gradient/dot | N |
| text | String | - | 加载过程展示的文字内容 | N |

---

# [chat-markdown]

# ChatMarkdown Markdown内容

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-chat-markdown": "tdesign-miniprogram/chat-markdown/chat-markdown"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/tpXWatmU8P44)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01基础Markdown样式

#### 标题与文本

**WXML** (`html`):
```html
<view class="chat-example-block">
<t-chat-markdown content="{{markdownContent}}" bind:click="handleLinkTap" />
</view>

```

**JS** (`javascript`):
```javascript
import markdownData from './mock.js';
// 内置marked处理
Page({
data: {
markdownContent: markdownData,
},
handleLinkTap(e) {
// 打开链接
console.log('监听点击', e);
wx.navigateTo({
url: e.detail.node.href,
});
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-markdown": "tdesign-miniprogram/chat-markdown/chat-markdown"
}
}

```

**MOCK** (`javascript`):
```javascript
const mockMarkdownData = `
# 一级标题

## 二级标题

### 三级标题

#### 四级标题

##### 五级标题

###### 六级标题

正文

**加粗正文**

~~删除线~~

行内代码: \`console.log('Hello')\`
`;

export default mockMarkdownData;

```

#### 列表

**WXML** (`html`):
```html
<view class="chat-example-block">
<t-chat-markdown content="{{markdownContent}}" bind:click="handleLinkTap" />
</view>

```

**JS** (`javascript`):
```javascript
import markdownData from './mock.js';
// 内置marked处理
Page({
data: {
markdownContent: markdownData,
},
handleLinkTap(e) {
// 打开链接
console.log('监听点击', e);
wx.navigateTo({
url: e.detail.node.href,
});
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-markdown": "tdesign-miniprogram/chat-markdown/chat-markdown"
}
}

```

**MOCK** (`javascript`):
```javascript
const mockMarkdownData = `
- 无序列表
- 无序列表
- 嵌套列表
- 嵌套列表

1. 有序列表
2. 有序列表
`;

export default mockMarkdownData;

```

### 02代码块与表格

#### 代码块

**WXML** (`html`):
```html
<view class="chat-example-block">
<t-chat-markdown content="{{markdownContent}}" bind:click="handleLinkTap" />
</view>

```

**JS** (`javascript`):
```javascript
import markdownData from './mock.js';
// 内置marked处理
Page({
data: {
markdownContent: markdownData,
},
handleLinkTap(e) {
// 打开链接
console.log('监听点击', e);
wx.navigateTo({
url: e.detail.node.href,
});
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-markdown": "tdesign-miniprogram/chat-markdown/chat-markdown"
}
}

```

**MOCK** (`javascript`):
```javascript
const mockMarkdownData = `
\`\`\`TDesign-登录表单.jsx
import { Form, Input, Button, Message } from 'tdesign-react';
const LoginForm = () => { const [loading, setLoading] = useState(false);
\`\`\`
`;

export default mockMarkdownData;

```

#### 表格

**WXML** (`html`):
```html
<view class="chat-example-block">
<t-chat-markdown content="{{markdownContent}}" bind:click="handleLinkTap" />
</view>

```

**JS** (`javascript`):
```javascript
import markdownData from './mock.js';
// 内置marked处理
Page({
data: {
markdownContent: markdownData,
},
handleLinkTap(e) {
// 打开链接
console.log('监听点击', e);
wx.navigateTo({
url: e.detail.node.href,
});
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-markdown": "tdesign-miniprogram/chat-markdown/chat-markdown"
}
}

```

**MOCK** (`javascript`):
```javascript
const mockMarkdownData = `
| 左对齐     | 居中对齐 | 右对齐 | 内容 |
| :--------- | :------: | -----: | ----- |
| 单元格     |  单元格  | 单元格 | 单元格 |
| 长文本示例| 长文本示例长文本示例长文本示例 |   $100 | 文本内容 |
| 文本示例 | 文本内容 | $100 |  文本内容 |
`;

export default mockMarkdownData;

```

### 03图片与超链接

支持监听链接的点击事件

**WXML** (`html`):
```html
<view class="chat-example-block">
<t-chat-markdown content="{{markdownContent}}" bind:click="handleLinkTap" />
</view>

```

**JS** (`javascript`):
```javascript
import markdownData from './mock.js';
// 内置marked处理
Page({
data: {
markdownContent: markdownData,
},
handleLinkTap(e) {
// 打开链接
console.log('监听点击', e);
wx.navigateTo({
url: e.detail.node.href,
});
},
});

```

**CSS** (`css`):
```css
.demo-container {
padding: 32rpx;
background-color: #fff;
}

.text {
margin-left: 10rpx;
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-markdown": "tdesign-miniprogram/chat-markdown/chat-markdown"
}
}

```

**MOCK** (`javascript`):
```javascript
const mockMarkdownData = `
![示例](https://tdesign.gtimg.com/demo/demo-image-1.png "示例")
这是一个链接 [Markdown语法](https://markdown.com.cn)。
`;

export default mockMarkdownData;

```

### 04引用

**WXML** (`html`):
```html
<view class="chat-example-block">
<t-chat-markdown content="{{markdownContent}}" bind:click="handleLinkTap" />
</view>

```

**JS** (`javascript`):
```javascript
import markdownData from './mock.js';
// 内置marked处理
Page({
data: {
markdownContent: markdownData,
},
handleLinkTap(e) {
// 打开链接
console.log('监听点击', e);
wx.navigateTo({
url: e.detail.node.href,
});
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-markdown": "tdesign-miniprogram/chat-markdown/chat-markdown"
}
}

```

**MOCK** (`javascript`):
```javascript
const mockMarkdownData = `
下面是引用示例

> TDesign distills Tencent's years of design experience into professional design guideline, providing universal design solutions that assist product managers, designers, developers, and other roles in efficiently completing the design and development of enterprise-level products, while maintaining consistent design language and style to meet user experience requirements.
`;

export default mockMarkdownData;

```

## API

### ChatMarkdownProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| content | String | - | 必需。markdown 内容文本 | Y |
| options | Object |  | Markdown 解析器基础配置。TS 类型：`TdChatContentMDOptions ``interface TdChatContentMDOptions {gfm?: boolean; pedantic?: boolean; smartLists?: boolean; breaks?: boolean}`。详细类型定义 | N |

### ChatMarkdownEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| click | `(detail: {detail:{event, node}, currentTarget, target})` | 点击链接时触发 |

---

# [chat-message]

# ChatMessage 对话消息体

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/TqXIftmF8c4G)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

#### 基础类型

**WXML** (`html`):
```html
<view class="chat-example">
<view class="chat-example-block">
<t-chat-message content="{{userMessage.content}}" role="{{userMessage.role}}"></t-chat-message>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
properties: {
userMessage: {
type: Object,
value: {
role: 'user',
content: [
{
type: 'text',
data: '牛顿第一定律是否适用于所有参考系？',
},
],
},
},
},
});

```

**CSS** (`css`):
```css
.chat-example {
display: flex;
flex-direction: column;
gap: 32rpx;
}

.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx 32rpx 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar"
}
}

```

#### 可配置昵称、头像、对齐方式

支持`avatar`，`name`插槽自定义

**WXML** (`html`):
```html
<view class="chat-example">
<view class="chat-example-block">
<t-chat-message datetime="16:38" name="张三" content="{{message.content}}" role="{{message.role}}"></t-chat-message>
</view>
<view class="chat-example-block">
<t-chat-message
avatar="https://tdesign.gtimg.com/site/chat-avatar.png"
datetime="16:38"
name="TDesignAI"
content="{{message.content}}"
role="{{message.role}}"
></t-chat-message>
</view>
<view class="chat-example-block">
<t-chat-message
avatar="https://tdesign.gtimg.com/site/chat-avatar.png"
datetime="16:38"
name="TDesignAI"
content="{{message.content}}"
role="{{message.role}}"
placement="right"
></t-chat-message>
</view>
<view class="chat-example-block">
<t-chat-message content="{{message.content}}" role="{{message.role}}" datetime="16:38">
<view slot="name" class="name-block">
<image src="https://tdesign.gtimg.com/site/chat-avatar.png" />
<view>Canxuan</view>
</view>
</t-chat-message>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
message: {
role: 'system',
content: [
{
type: 'text',
data: '牛顿第一定律是否适用于所有参考系？',
},
],
},
},
});

```

**CSS** (`css`):
```css
.chat-example {
display: flex;
flex-direction: column;
gap: 32rpx;
}

.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx 32rpx 0 32rpx;
}

.name-block {
display: flex;
align-items: center;
margin-right: 16rpx;
}

.name-block image {
margin-right: 16rpx;
width: 40rpx;
height: 40rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"t-divider": "tdesign-miniprogram/divider/divider"
}
}

```

#### 配置消息属性

支持`content`插槽自定义, `content`插槽使用建议：渲染聊天消息统一用 `t-chat-content`；仅在需要“单独使用 Markdown 组件”时使用 `t-chat-markdown`。也支持别的 markdown 渲染组件，选择其他 markdown 渲染库由用户自行安装。

**WXML** (`html`):
```html
<view class="chat-example">
<!-- 附件消息 -->
<view class="chat-example-block">
<t-chat-message
content="{{pic2.content}}"
role="{{pic2.role}}"
chatContentProps="{{chatContentProps}}"
></t-chat-message>
</view>
<view class="chat-example-block">
<t-chat-message
content="{{pic3.content}}"
role="{{pic3.role}}"
placement="right"
chatContentProps="{{chatContentProps}}"
></t-chat-message>
</view>
<view class="chat-example-block">
<t-chat-message
content="{{fileMessage.content}}"
role="{{fileMessage.role}}"
chatContentProps="{{chatContentProps}}"
></t-chat-message>
</view>
<view class="chat-example-block">
<t-chat-message
content="{{fileMessage.content}}"
role="{{fileMessage.role}}"
placement="right"
chatContentProps="{{chatContentProps}}"
></t-chat-message>
</view>
<!-- 思考过程消息 -->
<view class="chat-example-block">
<t-chat-message
content="{{aiMessage.content}}"
role="{{aiMessage.role}}"
status="{{aiMessage.status}}"
variant="text"
>
<t-chat-actionbar slot="actionbar" />
</t-chat-message>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
aiMessage: {
role: 'assistant',
status: 'complete',
content: [
{
type: 'thinking',
data: {
title: '已完成思考（耗时3秒）',
text: '好的，我现在需要回答用户关于对比近3年当代偶像爱情剧并总结创作经验的问题\n查询网络信息中...\n根据网络搜索结果，成功案例包括《春色寄情人》《要久久爱》《你也有今天》等，但缺乏具体播放数据，需要结合行业报告总结共同特征。2022-2024年偶像爱情剧的创作经验主要集中在题材创新、现实元素融入、快节奏叙事等方面。结合行业报告和成功案例，总结出以下创作经验。',
},
},
{
type: 'text',
data: '不，牛顿第一定律并不适用于所有参考系。它只适用于惯性参考系。',
},
],
},
pic1: {
role: 'user',
name: '张三',
avatar: 'https://tdesign.gtimg.com/site/avatar.jpg',
content: [
{
type: 'attachment',
data: [
{
fileType: 'image',
name: 'avatar.jpg',
size: 234234,
url: 'https://tdesign.gtimg.com/demo/demo-image-1.png',
width: 1920, // 图片实际宽度
height: 1080, // 图片实际高度
},
],
},
{
type: 'text',
data: '分析以下内容，总结一篇广告策划方案',
},
],
},
pic3: {
role: 'user',
content: [
{
type: 'attachment',
data: [
{
fileType: 'image',
name: 'avatar.jpg',
size: 234234,
url: 'https://tdesign.gtimg.com/demo/demo-image-1.png',
width: 1920, // 图片实际宽度
height: 1080, // 图片实际高度
},
],
},
{
type: 'text',
data: '分析以下',
},
],
},
pic2: {
role: 'user',
content: [
{
type: 'attachment',
data: [
{
fileType: 'image',
name: 'avatar.jpg',
size: 234234,
url: 'https://tdesign.gtimg.com/demo/demo-image-1.png',
width: 1920, // 为了更好的适配不同尺寸图片建议传入宽高，不传也有兜底尺寸
height: 1080, // 为了更好的适配不同尺寸图片建议传入宽高，不传也有兜底尺寸
},
{
fileType: 'image',
name: 'avatar2.jpg',
size: 234234,
url: 'https://tdesign.gtimg.com/demo/demo-image-1.png',
width: 1920, // 图片实际宽度
height: 1080, // 图片实际高度
},
],
},
{
type: 'text',
data: '分析以下内容，总结一篇广告策划方案',
},
],
},
fileMessage: {
role: 'user',
content: [
{
type: 'attachment',
data: [
{
fileType: 'doc',
name: 'word-file.doc',
url: 'https://example.com/word-file.doc',
size: 222859,
status: 'success',
},
{
fileType: 'excel',
name: 'excel-file.xlsx',
url: 'https://example.com/excel-file.xlsx',
size: 222859,
status: 'success',
},
{
fileType: 'pdf',
name: 'pdf-file.pdf',
url: 'https://example.com/pdf-file.pdf',
size: 222859,
status: 'success',
},
{
fileType: 'ppt',
name: 'ppt-file.pptx',
url: 'https://example.com/ppt-file.pptx',
size: 222859,
status: 'success',
},
{
fileType: 'video',
name: 'video-file.mp4',
url: 'https://example.com/video-file.mp4',
size: 222859,
status: 'success',
},
{
fileType: 'file',
name: 'file',
url: 'https://example.com/audio-file.mp3',
size: 222859,
status: 'success',
},
],
},
{
type: 'text',
data: '不，牛顿第一定律并不适用于所有参考系。它只适用于惯性参考系。',
},
],
},
},
});

```

**CSS** (`css`):
```css
.chat-example {
display: flex;
flex-direction: column;
gap: 32rpx;
}

.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx 32rpx 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar",
"t-avatar": "tdesign-miniprogram/avatar/avatar"
}
}
```

### 02组件状态

#### 加载状态

**WXML** (`html`):
```html
<view class="chat-example">
<view class="chat-example-block">
<t-chat-message
avatar="https://tdesign.gtimg.com/site/chat-avatar.png"
content="{{message.content}}"
role="{{message.role}}"
animation="gradient"
status="{{message.status}}"
></t-chat-message>
</view>
<view class="chat-example-block">
<t-chat-message
avatar="https://tdesign.gtimg.com/site/chat-avatar.png"
content="{{message.content}}"
role="{{message.role}}"
animation="skeleton"
status="{{message.status}}"
></t-chat-message>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
message: {
role: 'assistant',
status: 'pending',
content: [
{
type: 'text',
data: '牛顿第一定律并不适用于所有参考系，它只适用于惯性参考系。在质点不受外力作用时，能够判断出质点静止或作匀速直线运动的参考系一定是惯性参考系，因此只有在惯性参考系中牛顿第一定律才适用。',
},
],
},
},
});

```

**CSS** (`css`):
```css
.chat-example {
display: flex;
flex-direction: column;
gap: 32rpx;
}

.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx 32rpx 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar"
}
}

```

#### 出错状态

**WXML** (`html`):
```html
<view class="chat-example">
<view class="chat-example-block">
<t-chat-message
avatar="https://tdesign.gtimg.com/site/chat-avatar.png"
content="{{message.content}}"
role="{{message.role}}"
status="error"
></t-chat-message>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
message: {
role: 'assistant',
status: 'error',
content: [
{
type: 'text',
data: '´• •`!!!请求出错',
},
],
},
},
});

```

**CSS** (`css`):
```css
.chat-example {
display: flex;
flex-direction: column;
gap: 32rpx;
}

.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx 32rpx 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar"
}
}

```

### 03组件样式

#### 气泡样式

**WXML** (`html`):
```html
<view class="chat-example">
<view class="chat-example-block"
><t-chat-message content="{{userMessage.content}}" role="{{userMessage.role}}" variant="text"></t-chat-message
></view>
<view class="chat-example-block"
><t-chat-message content="{{userMessage.content}}" role="{{userMessage.role}}" variant="base"></t-chat-message
></view>
<view class="chat-example-block"
><t-chat-message content="{{userMessage.content}}" role="{{userMessage.role}}" variant="outline"></t-chat-message
></view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
properties: {
userMessage: {
type: Object,
value: {
role: 'user',
content: [
{
type: 'text',
data: '牛顿第一定律是否适用于所有参考系？',
},
],
},
},
},
});

```

**CSS** (`css`):
```css
.chat-example {
display: flex;
flex-direction: column;
gap: 32rpx;
}

.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx 32rpx 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-chat-message": "tdesign-miniprogram/chat-message/chat-message",
"t-chat-actionbar": "tdesign-miniprogram/chat-actionbar/chat-actionbar"
}
}

```

## API

### ChatMessageProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| animation | String | skeleton | 动画效果。可选项：skeleton/moving/gradient/dots | N |
| avatar | String | - | 自定义的头像配置 | N |
| chat-content-props | Object | - | 聊天内容组件的属性。TS 类型：`ChatContentProps`，ChatContent API Documents。详细类型定义 | N |
| chat-id | String | - | 聊天消息的唯一标识 | N |
| content | Array | - | 消息内容，数组中的每一项为一个消息内容对象。TS 类型：`ChatMessageContent[] ``type ChatMessageContent = TextContent \| MarkdownContent \| ThinkingContent \| AttachmentContent`` type AttachmentContent = ChatBaseContent<'attachment', FileItem[]>``type ThinkingContent = ChatBaseContent<'thinking', ThinkingContentData>``type MarkdownContent = ChatBaseContent<'markdown', string>``type TextContent = ChatBaseContent<'text', string>``interface ThinkingContentData {title?: string; text: string}``interface ChatBaseContent<T extends ChatContentType, TData> {type: T; data: TData}``type ChatMessageStatus = 'pending' \| 'streaming' \| 'complete' \| 'stop' \| 'error'``type ChatContentType = \| 'text' \| 'markdown' \| 'thinking' \| 'attachment'`，Attachments API Documents。详细类型定义 | N |
| datetime | String | - | 对话单元的时间配置 | N |
| name | String | - | 自定义的昵称 | N |
| placement | String | - | 消息显示位置。可选项：left/right | N |
| role | String | user | 消息角色。可选项：user/assistant/system | N |
| status | String | - | 消息状态。可选项：pending/streaming/complete/stop/error | N |
| variant | String | base | 气泡框样式，支持基础、线框、文字三种类型。可选项：base/outline/text | N |

### ChatMessageEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| longpress | `(detail: { id: string })` | - |

### ChatMessageSlots

| 名称 | 描述 |
| --- | --- |
| avatar | 自定义`avatar`显示内容 |
| content | 自定义消息内容 |
| name | 自定义`name`显示内容 |

---

# [chat-sender]

# ChatSender 对话输入

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/1b3SQumy8n4O)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

#### 基础类型

**WXML** (`html`):
```html
<view class="demo-base-container">
<!-- 聊天发送器组件 -->
<view class="chat-sender-demo-wrapper">
<view class="chat-sender-height-limit">
<view class="chat-sender-height-left-limit"> </view>
<view class="chat-sender-height-right-limit"> </view>
</view>
<view class="chat-sender-placeholder"> 高度限制：最大高度为132px </view>
<view class="chat-sender-wrapper">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
placeholder="{{placeholder}}"
textareaProps="{{textareaProps}}"
fileList="{{fileList}}"
attachmentsProps="{{attachmentsProps}}"
renderPresets="{{renderPresets}}"
visible="{{visible}}"
bind:send="onSend"
bind:stop="onStop"
bind:focus="onFocus"
bind:blur="onBlur"
bind:change="onChange"
bind:uploadClick="onUploadClick"
bind:fileClick="onFileClick"
bind:fileDelete="onFileDelete"
bind:fileChange="onFileChange"
bind:fileAdd="onFileAdd"
bind:fileSelect="onFileSelect"
bind:updateVisible="onUpdateVisible"
bind:keyboardheightchange="onKeyboardHeightChange"
>
<view slot="footer-prefix" class="demo-footer-prefix">
<view class="deep-think-block {{deepThinkActive ? 'active' : ''}}" bind:tap="onDeepThinkTap">
<t-icon name="system-sum" size="40rpx" />
<text class="deep-think-text">深度思考</text>
</view>
<view class="net-search-block {{ netSearchActive ? 'active' : '' }}" bind:tap="onNetSearchTap">
<t-icon name="internet" size="40rpx" />
</view>
</view>
</t-chat-sender>
</view>
<view class="demo-footer"> 内容由AI生成，仅供参考 </view>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Page({
data: {
value: '',
loading: false,
disabled: false,
fileList: [],
visible: false,
placeholder: '请输入消息...',
textareaProps: {
autosize: {
maxHeight: 264,
minHeight: 48, // 设置为0时，用自动计算height的高度
}, // 默认为false
},
attachmentsProps: {
items: [],
removable: true,
imageViewer: true,
addable: false,
},
renderPresets: [
{
name: 'send',
type: 'icon',
},
],
deepThinkActive: false,
netSearchActive: false,
},

// 发送消息
onSend(e) {
const { value } = e.detail;
console.log('发送消息:', value);

if (!value.trim()) {
wx.showToast({
title: '请输入消息内容',
icon: 'none',
});
return;
}

// 模拟发送状态
this.setData({ loading: true });

setTimeout(() => {
if (this.data.loading) {
this.setData({
loading: false,
value: '', // 清空输入框
});
wx.showToast({
title: '发送成功',
icon: 'success',
});
}
}, 3000);
},

// 停止发送
onStop(e) {
const { value } = e.detail;
console.log('停止发送:', value);

this.setData({ loading: false });
wx.showToast({
title: '已停止发送',
icon: 'none',
});
},

// 输入框聚焦
onFocus(e) {
const { value, context } = e.detail;
console.log('输入框聚焦:', value, context);
},

// 输入框失焦
onBlur(e) {
const { value, context } = e.detail;
console.log('输入框失焦:', value, context);
},

// 输入内容变化
onChange(e) {
const { value } = e.detail;
console.log('输入内容变化:', value);
this.setData({ value });
},

// 点击上传按钮
onUploadClick() {
console.log('点击上传按钮');
},

// 点击文件
onFileClick(e) {
const { file } = e.detail;
console.log('点击文件:', file);
wx.showToast({
title: `点击了文件: ${file.name}`,
icon: 'none',
});
},

// 删除文件
onFileDelete(e) {
const { file } = e.detail;
console.log('删除文件:', file);
wx.showToast({
title: '文件删除成功',
icon: 'success',
});
},

// 文件列表变化
onFileChange(e) {
console.log(e, 'e----');

const { files } = e.detail;
console.log('文件列表变化:', files);
this.setData({ fileList: files });
},

// 添加文件
onFileAdd() {
console.log('添加文件');
},

// 选择文件
onFileSelect(e) {
const { name, files } = e.detail;
console.log('选择文件:', name, files);

wx.showToast({
title: `选择了${files.length}个文件`,
icon: 'success',
});
},

// 上传面板显示状态变化
onUpdateVisible(e) {
const visible = e.detail;
console.log('上传面板显示状态:', visible);
this.setData({ visible });
},

// 键盘高度变化
onKeyboardHeightChange(e) {
console.log('键盘高度变化:', e.detail);
},

// 切换禁用状态
toggleDisabled() {
this.setData({ disabled: !this.data.disabled });
},

// 切换加载状态
toggleLoading() {
this.setData({ loading: !this.data.loading });
},

// 清空输入框
clearInput() {
this.setData({ value: '' });
},

onDeepThinkTap() {
this.setData({ deepThinkActive: !this.data.deepThinkActive });
},

onNetSearchTap() {
this.setData({ netSearchActive: !this.data.netSearchActive });
},
});

```

**CSS** (`css`):
```css
.demo-base-container {
padding: 56rpx 0 0 0;
background-color: var(--td-bg-color-container);
height: 488rpx;
position: relative;
}

/* 聊天发送器包装器 */
.chat-sender-demo-wrapper {
margin-bottom: 32rpx;
/* border: 2rpx solid #e5e5e5; */
border-radius: 8rpx;
overflow: hidden;
}

.chat-sender-height-limit {
height: 72rpx;
padding: 0 24rpx;
display: flex;
justify-content: space-between;
align-items: center;
}

.chat-sender-height-left-limit {
height: 70rpx;
width: 70rpx;
border-top: 1px var(--td-component-stroke) dashed;
border-left: 1px var(--td-component-stroke) dashed;
border-top-left-radius: 32rpx;
}
.chat-sender-height-right-limit {
height: 70rpx;
width: 70rpx;
border-top: 1px var(--td-component-stroke) dashed;
border-right: 1px var(--td-component-stroke) dashed;
border-top-right-radius: 32rpx;
}
.chat-sender-placeholder {
font-size: 32rpx;
font-weight: 600;
color: var(--demo-chat-sender-placeholder);
text-align: center;
height: 48rpx;
}

.chat-sender-wrapper {
position: absolute;
width: 100%;
bottom: 0rpx;
background-color: var(--td-bg-color-container);
}

.demo-footer {
height: 32rpx;
width: 100%;
text-align: center;
font-size: 20rpx;
line-height: 32rpx;
color: var(--td-text-color-placeholder);
position: absolute;
bottom: 32rpx;
}

.demo-footer-prefix {
display: flex;
align-items: center;
}

.deep-think-block {
padding: 0 24rpx;
height: 60rpx;
margin-right: 16rpx;
}

.deep-think-text {
margin-left: 8rpx;
}

.deep-think-block,
.net-search-block {
color: var(--td-text-color-primary);
border-radius: 200rpx;
border: 2rpx solid var(--td-component-border);
display: flex;
justify-content: center;
align-items: center;
}

.net-search-block {
width: 64rpx;
height: 60rpx;
}

.active {
border-color: var(--td-brand-color-light-active);
color: var(--td-brand-color);
background-color: var(--td-brand-color-light);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender"
}
}

```

#### 上传文件

支持选择附件及展示附件列表，受控进行文件数据管理，示例中模拟了文件上传流程

**WXML** (`html`):
```html
<view class="demo-attachments-container {{showUploadMenu ? 'show-upload-menu' : ''}}">
<view class="chat-sender-demo-wrapper">
<view class="chat-sender-height-limit">
<view class="chat-sender-height-left-limit"> </view>
<view class="chat-sender-height-right-limit"> </view>
</view>
<view class="chat-sender-placeholder"> 高度限制：最大高度为132px </view>
<view class="chat-sender-wrapper" style="{{showUploadMenu ? 'bottom:32rpx;' : ''}}">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
placeholder="{{placeholder}}"
textareaProps="{{textareaProps}}"
fileList="{{fileList}}"
attachmentsProps="{{attachmentsProps}}"
renderPresets="{{renderPresets}}"
visible="{{visible}}"
bind:send="onSend"
bind:stop="onStop"
bind:focus="onFocus"
bind:blur="onBlur"
bind:change="onChange"
bind:uploadClick="onUploadClick"
bind:fileClick="onFileClick"
bind:fileDelete="onFileDelete"
bind:fileChange="onFileChange"
bind:fileAdd="onFileAdd"
bind:fileSelect="onFileSelect"
bind:updateVisible="onUpdateVisible"
bind:keyboardheightchange="onKeyboardHeightChange"
>
<view slot="footer-prefix" class="demo-footer-prefix">
<view class="deep-think-block {{deepThinkActive ? 'active' : ''}}" bind:tap="onDeepThinkTap">
<t-icon name="system-sum" size="40rpx" />
<text class="deep-think-text">深度思考</text>
</view>
<view class="net-search-block {{ netSearchActive ? 'active' : '' }}" bind:tap="onNetSearchTap">
<t-icon name="internet" size="40rpx" />
</view>
</view>
</t-chat-sender>
</view>
<view wx:if="{{!visible}}" class="demo-attachments-footer"> 内容由AI生成，仅供参考 </view>
</view>
</view>
<t-toast id="t-toast" />

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';

Page({
data: {
value: '',
loading: false,
disabled: false,
fileList: [
{
fileType: 'image',
name: '图片1.png',
url: 'https://tdesign.gtimg.com/site/square.png',
},
{
fileType: 'pdf',
name: '文档.pdf',
url: 'https://example.com/document.pdf',
size: 3072,
status: 'pending',
},
],
visible: true,
placeholder: '请输入消息...',
textareaProps: {
autosize: {
maxHeight: 264,
minHeight: 48, // 设置为0时，用自动计算height的高度
}, // 默认为false
},
attachmentsProps: {
items: [
{
fileType: 'image',
name: '图片1.png',
url: 'https://tdesign.gtimg.com/site/square.png',
},
{
fileType: 'pdf',
name: '文档.pdf',
url: 'https://example.com/document.pdf',
size: 3072,
status: 'pending',
},
],
removable: true,
imageViewer: true,
addable: false,
},
renderPresets: [
{
name: 'upload',
presets: ['uploadCamera', 'uploadImage', 'uploadAttachment'],
type: 'bottom',
status: '',
},
{
name: 'send',
type: 'icon',
},
],
deepThinkActive: false,
netSearchActive: false,
showUploadMenu: true,
},

// 发送消息
onSend(e) {
const { value } = e.detail;
console.log('发送消息:', value);

if (!value.trim()) {
wx.showToast({
title: '请输入消息内容',
icon: 'none',
});
return;
}

// 模拟发送状态
this.setData({ loading: true });

setTimeout(() => {
if (this.data.loading) {
this.setData({
loading: false,
value: '', // 清空输入框
});
wx.showToast({
title: '发送成功',
icon: 'success',
});
}
}, 3000);
},

// 停止发送
onStop(e) {
const { value } = e.detail;
console.log('停止发送:', value);

this.setData({ loading: false });
wx.showToast({
title: '已停止发送',
icon: 'none',
});
},

// 输入框聚焦
onFocus(e) {
const { value, context } = e.detail;
console.log('输入框聚焦:', value, context);
},

// 输入框失焦
onBlur(e) {
const { value, context } = e.detail;
console.log('输入框失焦:', value, context);
},

// 输入内容变化
onChange(e) {
const { value } = e.detail;
console.log('输入内容变化:', value);
this.setData({ value });
},

// 点击上传按钮
onUploadClick() {
console.log('点击上传按钮');
},

// 点击文件
onFileClick(e) {
const { file } = e.detail;
console.log('点击文件:', file);
wx.showToast({
title: `点击了文件: ${file.name}`,
icon: 'none',
});
},

// 删除文件
onFileDelete(e) {
const { file } = e.detail;
console.log('删除文件:', file);
wx.showToast({
title: '文件删除成功',
icon: 'success',
});
},

// 文件列表变化
onFileChange(e) {
const { files } = e.detail;
console.log('文件列表变化:', files);
this.setData({ attachmentsProps: { ...this.data.attachmentsProps, items: files } });
this.setData({ fileList: files });
},

// 添加文件
onFileAdd() {
console.log('添加文件');
},

// 选择文件
onFileSelect(e) {
const { name, files } = e.detail;
console.log('选择文件:', name, files);

wx.showToast({
title: `选择了${files.length}个文件`,
icon: 'success',
});
},

// 上传面板显示状态变化
onUpdateVisible() {
Toast({
context: this,
selector: '#t-toast',
message: '暂不可操作',
});
},

// 键盘高度变化
onKeyboardHeightChange(e) {
console.log('键盘高度变化:', e.detail);
},

// 切换禁用状态
toggleDisabled() {
this.setData({ disabled: !this.data.disabled });
},

// 切换加载状态
toggleLoading() {
this.setData({ loading: !this.data.loading });
},

// 清空输入框
clearInput() {
this.setData({ value: '' });
},

onDeepThinkTap() {
this.setData({ deepThinkActive: !this.data.deepThinkActive });
},

onNetSearchTap() {
this.setData({ netSearchActive: !this.data.netSearchActive });
},
});

```

**CSS** (`css`):
```css
.demo-attachments-container {
padding: 56rpx 0 0 0;
background-color: var(--td-bg-color-container);
height: 608rpx;
position: relative;
transition: all 0.3s;
}

.show-upload-menu {
height: 780rpx;
}

.demo-attachments-footer {
height: 32rpx;
width: 100%;
text-align: center;
font-size: 20rpx;
line-height: 32rpx;
color: rgba(0, 0, 0, 0.4);
position: absolute;
bottom: 32rpx;
}

/* 聊天发送器包装器 */
.chat-sender-wrapper {
/* border: 2rpx solid #e5e5e5; */
border-radius: 8rpx;
overflow: hidden;
background-color: var(--td-bg-color-container);
}

.demo-footer-prefix {
display: flex;
align-items: center;
}

.deep-think-block {
padding: 0 24rpx;
height: 60rpx;
margin-right: 16rpx;
}

.deep-think-text {
margin-left: 8rpx;
}

.deep-think-block,
.net-search-block {
color: var(--td-text-color-primary);
border-radius: 200rpx;
border: 2rpx solid var(--td-component-border);
display: flex;
justify-content: center;
align-items: center;
}

.net-search-block {
width: 64rpx;
height: 60rpx;
}

.active {
border-color: var(--td-brand-color-light-active);
color: var(--td-brand-color);
background-color: var(--td-brand-color-light);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender",
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

#### 内容引用

输入框顶部区域 `header` ，输入框底部左侧区域 `footer-prefix` ，输入框底部操作区域 `suffix`

**WXML** (`html`):
```html
<view class="demo-content-citation-container">
<view class="chat-sender-demo-wrapper">
<view class="chat-sender-height-limit">
<view class="chat-sender-height-left-limit"> </view>
<view class="chat-sender-height-right-limit"> </view>
</view>
<view class="chat-sender-placeholder"> 高度限制：最大高度为132px </view>
<view class="chat-sender-wrapper">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
placeholder="{{placeholder}}"
textareaProps="{{textareaProps}}"
fileList="{{fileList}}"
attachmentsProps="{{attachmentsProps}}"
renderPresets="{{renderPresets}}"
visible="{{visible}}"
bind:send="onSend"
bind:stop="onStop"
bind:focus="onFocus"
bind:blur="onBlur"
bind:change="onChange"
bind:uploadClick="onUploadClick"
bind:fileClick="onFileClick"
bind:fileDelete="onFileDelete"
bind:fileChange="onFileChange"
bind:fileAdd="onFileAdd"
bind:fileSelect="onFileSelect"
bind:updateVisible="onUpdateVisible"
bind:keyboardheightchange="onKeyboardHeightChange"
>
<view slot="header" class="demo-header" wx:if="{{headerText}}">
<view style="padding: 4rpx; height: 40rpx; color: var(--td-text-color-disabled)">
<t-icon name="enter" size="40rpx" style="transform: scaleX(-1)" />
</view>
<view class="header-content"> {{headerText}} </view>
<view style="padding: 4rpx; height: 40rpx; margin-left: auto; color: var(--td-text-color-placeholder)">
<t-icon name="close" size="40rpx" bind:tap="handleCLoseCite" />
</view>
</view>
<view slot="footer-prefix" class="demo-footer-prefix">
<view class="deep-think-block {{deepThinkActive ? 'active' : ''}}" bind:tap="onDeepThinkTap">
<t-icon name="system-sum" size="40rpx" />
<text class="deep-think-text">深度思考</text>
</view>
<view class="net-search-block {{ netSearchActive ? 'active' : '' }}" bind:tap="onNetSearchTap">
<t-icon name="internet" size="40rpx" />
</view>
</view>
</t-chat-sender>
</view>
<view class="demo-content-citation-footer"> 内容由AI生成，仅供参考 </view>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Page({
data: {
value: '',
loading: false,
disabled: false,
fileList: [],
visible: false,
placeholder: '请输入消息...',
textareaProps: {
autosize: {
maxHeight: 264,
minHeight: 48, // 设置为0时，用自动计算height的高度
}, // 默认为false
},
attachmentsProps: {
items: [],
removable: true,
imageViewer: true,
addable: false,
},
renderPresets: [
{
name: 'send',
type: 'icon',
},
],
deepThinkActive: false,
netSearchActive: false,
headerText:
'牛顿第一定律并不适用于所有参考系，它只适用于惯性参考系。在质点不受外力作用时，能够判断出质点静止或作匀速直线运动的参考系一定是惯性参考系，因此只有在惯性参考系中牛顿第一定律才适用。',
},

// 发送消息
onSend(e) {
const { value } = e.detail;
console.log('发送消息:', value);

if (!value.trim()) {
wx.showToast({
title: '请输入消息内容',
icon: 'none',
});
return;
}

// 模拟发送状态
this.setData({ loading: true });

setTimeout(() => {
if (this.data.loading) {
this.setData({
loading: false,
value: '', // 清空输入框
});
wx.showToast({
title: '发送成功',
icon: 'success',
});
}
}, 3000);
},

// 停止发送
onStop(e) {
const { value } = e.detail;
console.log('停止发送:', value);

this.setData({ loading: false });
wx.showToast({
title: '已停止发送',
icon: 'none',
});
},

// 输入框聚焦
onFocus(e) {
const { value, context } = e.detail;
console.log('输入框聚焦:', value, context);
},

// 输入框失焦
onBlur(e) {
const { value, context } = e.detail;
console.log('输入框失焦:', value, context);
},

// 输入内容变化
onChange(e) {
const { value } = e.detail;
console.log('输入内容变化:', value);
this.setData({ value });
},

// 点击上传按钮
onUploadClick() {
console.log('点击上传按钮');
},

// 点击文件
onFileClick(e) {
const { file } = e.detail;
console.log('点击文件:', file);
wx.showToast({
title: `点击了文件: ${file.name}`,
icon: 'none',
});
},

// 删除文件
onFileDelete(e) {
const { file } = e.detail;
console.log('删除文件:', file);
wx.showToast({
title: '文件删除成功',
icon: 'success',
});
},

// 文件列表变化
onFileChange(e) {
console.log(e, 'e----');

const { files } = e.detail;
console.log('文件列表变化:', files);
this.setData({ fileList: files });
},

// 添加文件
onFileAdd() {
console.log('添加文件');
},

// 选择文件
onFileSelect(e) {
const { name, files } = e.detail;
console.log('选择文件:', name, files);

wx.showToast({
title: `选择了${files.length}个文件`,
icon: 'success',
});
},

// 上传面板显示状态变化
onUpdateVisible(e) {
const visible = e.detail;
console.log('上传面板显示状态:', visible);
this.setData({ visible });
},

// 键盘高度变化
onKeyboardHeightChange(e) {
console.log('键盘高度变化:', e.detail);
},

// 切换禁用状态
toggleDisabled() {
this.setData({ disabled: !this.data.disabled });
},

// 切换加载状态
toggleLoading() {
this.setData({ loading: !this.data.loading });
},

// 清空输入框
clearInput() {
this.setData({ value: '' });
},

onDeepThinkTap() {
this.setData({ deepThinkActive: !this.data.deepThinkActive });
},

onNetSearchTap() {
this.setData({ netSearchActive: !this.data.netSearchActive });
},

handleCLoseCite() {
this.setData({ headerText: '' });
},
});

```

**CSS** (`css`):
```css
.demo-content-citation-container {
padding: 56rpx 0 0 0;
background-color: var(--td-bg-color-container);
height: 568rpx;
position: relative;
}

.demo-content-citation-footer {
height: 32rpx;
width: 100%;
text-align: center;
font-size: 20rpx;
line-height: 32rpx;
color: var(--td-text-color-placeholder);
position: absolute;
bottom: 32rpx;
}

/* 聊天发送器包装器 */

.chat-sender-wrapper {
/* border: 2rpx solid #e5e5e5; */
border-radius: 8rpx;
overflow: hidden;
background-color: var(--td-bg-color-container);
}

.demo-footer-prefix {
display: flex;
align-items: center;
}

.deep-think-block {
padding: 0 24rpx;
height: 60rpx;
margin-right: 16rpx;
}

.deep-think-text {
margin-left: 8rpx;
}

.deep-think-block,
.net-search-block {
color: var(--td-text-color-primary);
border-radius: 200rpx;
border: 2rpx solid var(--td-component-border);
display: flex;
justify-content: center;
align-items: center;
}

.net-search-block {
width: 64rpx;
height: 60rpx;
}

.active {
border-color: var(--td-brand-color-light-active);
color: var(--td-brand-color);
background-color: var(--td-brand-color-light);
}

.demo-header {
display: flex;
width: calc(100% - 48rpx);
margin-left: 24rpx;
height: 62rpx;
border-bottom: 2rpx solid var(--td-component-stroke);
}

.header-content {
padding: 2rpx 24rpx;
box-sizing: border-box;
white-space: nowrap;
overflow: hidden;
text-overflow: ellipsis;
font-size: var(--td-font-size-body-medium);
line-height: 44rpx;
color: var(--td-text-color-placeholder);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender"
}
}

```

#### 文件引用

输入框顶部区域 `header` ，输入框底部左侧区域 `footer-prefix` ，输入框底部操作区域 `suffix`

**WXML** (`html`):
```html
<view class="demo-content-citation-container">
<view class="chat-sender-demo-wrapper">
<view class="chat-sender-height-limit">
<view class="chat-sender-height-left-limit"> </view>
<view class="chat-sender-height-right-limit"> </view>
</view>
<view class="chat-sender-placeholder"> 高度限制：最大高度为132px </view>
<view class="chat-sender-wrapper">
<t-chat-sender
value="{{value}}"
loading="{{loading}}"
disabled="{{disabled}}"
placeholder="{{placeholder}}"
textareaProps="{{textareaProps}}"
fileList="{{fileList}}"
attachmentsProps="{{attachmentsProps}}"
renderPresets="{{renderPresets}}"
visible="{{visible}}"
bind:send="onSend"
bind:stop="onStop"
bind:focus="onFocus"
bind:blur="onBlur"
bind:change="onChange"
bind:uploadClick="onUploadClick"
bind:fileClick="onFileClick"
bind:fileDelete="onFileDelete"
bind:fileChange="onFileChange"
bind:fileAdd="onFileAdd"
bind:fileSelect="onFileSelect"
bind:updateVisible="onUpdateVisible"
bind:keyboardheightchange="onKeyboardHeightChange"
>
<view slot="header" class="demo-header" wx:if="{{headerText}}">
<view style="padding: 4rpx; height: 40rpx; color: var(--td-text-color-disabled)">
<t-icon name="enter" size="40rpx" style="transform: scaleX(-1)" />
</view>
<view class="header-content-wrapper">
<t-icon
name="file-word-filled"
color="var(--td-brand-color)"
size="32rpx"
style="margin-top: 8rpx; margin-right: 16rpx"
/>
<view class="header-file-content" hover-class="none" hover-stop-propagation="false"> {{headerText}} </view>
</view>
<view style="padding: 4rpx; height: 40rpx; margin-left: auto; color: var(--td-text-color-placeholder)">
<t-icon name="close" size="40rpx" bind:tap="handleCLoseCite" />
</view>
</view>
<view slot="footer-prefix" class="demo-footer-prefix">
<view class="deep-think-block {{deepThinkActive ? 'active' : ''}}" bind:tap="onDeepThinkTap">
<t-icon name="system-sum" size="40rpx" />
<text class="deep-think-text">深度思考</text>
</view>
<view class="net-search-block {{ netSearchActive ? 'active' : '' }}" bind:tap="onNetSearchTap">
<t-icon name="internet" size="40rpx" />
</view>
</view>
</t-chat-sender>
</view>
<view class="demo-file-citation-footer"> 内容由AI生成，仅供参考 </view>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Page({
data: {
value: '',
loading: false,
disabled: false,
fileList: [],
visible: false,
placeholder: '请输入消息...',
textareaProps: {
autosize: {
maxHeight: 264,
minHeight: 48, // 设置为0时，用自动计算height的高度
}, // 默认为false
},
attachmentsProps: {
items: [],
removable: true,
imageViewer: true,
addable: false,
},
renderPresets: [
{
name: 'send',
type: 'icon',
},
],
deepThinkActive: false,
netSearchActive: false,
headerText: 'word文件.docx',
},

// 发送消息
onSend(e) {
const { value } = e.detail;
console.log('发送消息:', value);

if (!value.trim()) {
wx.showToast({
title: '请输入消息内容',
icon: 'none',
});
return;
}

// 模拟发送状态
this.setData({ loading: true });

setTimeout(() => {
if (this.data.loading) {
this.setData({
loading: false,
value: '', // 清空输入框
});
wx.showToast({
title: '发送成功',
icon: 'success',
});
}
}, 3000);
},

// 停止发送
onStop(e) {
const { value } = e.detail;
console.log('停止发送:', value);

this.setData({ loading: false });
wx.showToast({
title: '已停止发送',
icon: 'none',
});
},

// 输入框聚焦
onFocus(e) {
const { value, context } = e.detail;
console.log('输入框聚焦:', value, context);
},

// 输入框失焦
onBlur(e) {
const { value, context } = e.detail;
console.log('输入框失焦:', value, context);
},

// 输入内容变化
onChange(e) {
const { value } = e.detail;
console.log('输入内容变化:', value);
this.setData({ value });
},

// 点击上传按钮
onUploadClick() {
console.log('点击上传按钮');
},

// 点击文件
onFileClick(e) {
const { file } = e.detail;
console.log('点击文件:', file);
wx.showToast({
title: `点击了文件: ${file.name}`,
icon: 'none',
});
},

// 删除文件
onFileDelete(e) {
const { file } = e.detail;
console.log('删除文件:', file);
wx.showToast({
title: '文件删除成功',
icon: 'success',
});
},

// 文件列表变化
onFileChange(e) {
console.log(e, 'e----');

const { files } = e.detail;
console.log('文件列表变化:', files);
this.setData({ fileList: files });
},

// 添加文件
onFileAdd() {
console.log('添加文件');
},

// 选择文件
onFileSelect(e) {
const { name, files } = e.detail;
console.log('选择文件:', name, files);

wx.showToast({
title: `选择了${files.length}个文件`,
icon: 'success',
});
},

// 上传面板显示状态变化
onUpdateVisible(e) {
const visible = e.detail;
console.log('上传面板显示状态:', visible);
this.setData({ visible });
},

// 键盘高度变化
onKeyboardHeightChange(e) {
console.log('键盘高度变化:', e.detail);
},

// 切换禁用状态
toggleDisabled() {
this.setData({ disabled: !this.data.disabled });
},

// 切换加载状态
toggleLoading() {
this.setData({ loading: !this.data.loading });
},

// 清空输入框
clearInput() {
this.setData({ value: '' });
},

onDeepThinkTap() {
this.setData({ deepThinkActive: !this.data.deepThinkActive });
},

onNetSearchTap() {
this.setData({ netSearchActive: !this.data.netSearchActive });
},

handleCLoseCite() {
this.setData({ headerText: '' });
},
});

```

**CSS** (`css`):
```css
.demo-content-citation-container {
padding: 56rpx 0 0 0;
background-color: var(--td-bg-color-container);
height: 568rpx;
position: relative;
}

.demo-file-citation-footer {
height: 32rpx;
width: 100%;
text-align: center;
font-size: 20rpx;
line-height: 32rpx;
color: var(--td-text-color-placeholder);
position: absolute;
bottom: 32rpx;
}

.chat-sender-wrapper {
/* border: 2rpx solid #e5e5e5; */
border-radius: 8rpx;
overflow: hidden;
background-color: var(--td-bg-color-container);
}

.demo-footer-prefix {
display: flex;
align-items: center;
}

.deep-think-block {
padding: 0 24rpx;
height: 60rpx;
margin-right: 16rpx;
}

.deep-think-text {
margin-left: 8rpx;
}

.deep-think-block,
.net-search-block {
color: var(--td-text-color-primary);
border-radius: 200rpx;
border: 2rpx solid var(--td-component-border);
display: flex;
justify-content: center;
align-items: center;
}

.net-search-block {
width: 64rpx;
height: 60rpx;
}

.active {
border-color: var(--td-brand-color-light-active);
color: var(--td-brand-color);
background-color: var(--td-brand-color-light);
}

.demo-header {
display: flex;
width: calc(100% - 48rpx);
margin-left: 24rpx;
height: 62rpx;
border-bottom: 2rpx solid var(--td-component-stroke);
}

.header-content-wrapper {
padding: 0 24rpx;
display: flex;
}

.header-file-content {
padding: 2rpx 0;
line-height: 44rpx;
white-space: nowrap;
overflow: hidden;
text-overflow: ellipsis;
font-size: var(--td-font-size-body-medium);
color: var(--td-text-color-placeholder);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar",
"t-chat-sender": "tdesign-miniprogram/chat-sender/chat-sender"
}
}

```

## API

### ChatSenderProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| adjust-position | Boolean | false | 默认键盘弹起不会把页面顶起来 | N |
| attachments-props | Object | - | 附件列表属性。TS 类型：`AttachmentsProps`，Attachments API Documents。详细类型定义 | N |
| auto-rise-with-keyboard | Boolean | false | 键盘弹起时自动顶起来输入框 | N |
| disabled | Boolean | false | 是否禁用输入框 | N |
| file-list | Array | [] | 附件文件列表。TS 类型：`FileItem[]` | N |
| loading | Boolean | false | 发送按钮是否处于加载状态 | N |
| placeholder | String | 请输入消息... | 输入框默认文案 | N |
| render-presets | Array | [{name: 'upload', presets: ['uploadCamera', 'uploadImage', 'uploadAttachment'], status: ''},{ name: 'send', type: 'icon'}] | 预设发送区渲染配置，用于灵活配置发送区的上传入口和发送按钮，支持自定义类型、顺序、样式。TS 类型：`ChatActionButtons``type ChatActionButtons = Array<ChatActionButton>``type ChatActionButton = UploadButton \| SendButton``interface UploadButton { name: 'upload'; presets: string[]; status?: string; }``interface SendButton { name: 'send'; type: 'icon' \| 'text';}`。详细类型定义 | N |
| textarea-props | Boolean / Object | { autosize: { maxHeight: 264, minHeight: 48 } } | 透传给 Textarea 组件的属性，autosize数值单位为 rpx | N |
| value | String | - | 输入框的值 | N |
| visible | Boolean | false | 上传面板是否可见 | N |

### ChatSenderEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| blur | `(value:string, context: { e: FocusEvent })` | 输入框聚焦时触发 |
| change | `(value:string, context: { e: InputEvent \| MouseEvent \| KeyboardEvent })` | 输入框值发生变化时触发 |
| file-add | - | 添加附件时触发 |
| file-change | `(file:FileItem)` | 附件列表变化时触发 |
| file-click | `(file:FileItem)` | 点击附件时触发 |
| file-delete | `(file:FileItem)` | 删除附件时触发 |
| file-select | `(detail: {files: FileList, name: UploadActionType})` | 选择文件（图片/微信文件）时触发 |
| focus | `(value:string, context: { e: FocusEvent }) ` | 输入框聚焦时触发 |
| keyboardheightchange | `(detail: {height: number, duration: number})` | 选择文件（图片/微信文件）时触发 |
| send | `(value:string, context: {\| KeyboardEvent })` | 点击消息发送的回调方法 |
| stop | `(value:string)` | 点击消息终止的回调方法 |
| upload-click | - | 【实验】点击上传按钮时触发 |

---

# [chat-thinking]

# ChatThinking 思考过程

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-chat-thinking": "tdesign-miniprogram/chat-thinking/chat-thinking"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/mjXfGtmd8V4h)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

支持多种加载动效类型，包括gradient、moving、dots

**WXML** (`html`):
```html
<view class="chat-example-block">
<t-chat-thinking
content="{{content}}"
layout="block"
status="{{status}}"
animation="moving"
bind:expandChange="handleExpandChange"
/>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
thinking: true,
fullText:
'嗯，用户问牛顿第一定律是不是适用于所有参考系。首先，我得先回忆一下牛顿第一定律的内容。牛顿第一定律，也就是惯性定律，说物体在没有外力作用时会保持静止或匀速直线运动。也就是说， 保持原来的运动状态。',
currentText: '',
isTyping: true,
content: {
text: '',
title: '思考过程',
},
typeSpeed: 50,
status: 'pending',
startTime: 0,
},

lifetimes: {
attached() {
this.setData({
startTime: Date.now(),
});
this.startTyping();
},

detached() {
if (this.typingTimer) {
clearTimeout(this.typingTimer);
}
},
},

methods: {
startTyping() {
const { fullText, typeSpeed } = this.data;
let currentIndex = 0;
const typeNextChar = () => {
if (currentIndex <= fullText.length) {
const currentText = fullText.substring(0, currentIndex);
// 检查是否已经完成打字
if (currentIndex === fullText.length) {
const endTime = Date.now();
const duration = Math.round((endTime - this.data.startTime) / 1000);
this.setData({
currentText,
content: {
text: currentText,
title: `已完成思考（耗时${duration}秒）`,
},
isTyping: false,
status: 'complete',
});
return; // 直接返回，不再继续执行
}
// 正常打字过程
this.setData({
currentText,
content: {
text: currentText,
title: '思考过程',
},
isTyping: currentIndex < fullText.length,
});
if (currentIndex < fullText.length) {
this.typingTimer = setTimeout(typeNextChar, typeSpeed);
}
currentIndex += 1;
}
};
typeNextChar();
},
replayTyping() {
if (this.typingTimer) {
clearTimeout(this.typingTimer);
}
this.setData({
currentText: '',
content: {
text: '',
title: '思考过程',
},
isTyping: true,
startTime: Date.now(),
});
this.startTyping();
},
onStop() {
console.log('停止思考');
this.setData({
thinking: false,
});
wx.showToast({
title: '已停止思考',
icon: 'success',
});
},
toggleThinking() {
this.setData({
thinking: !this.data.thinking,
});
},
resetThinking() {
this.setData({
thinking: true,
});
wx.showToast({
title: '已重置',
icon: 'success',
});
},
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-thinking": "tdesign-miniprogram/chat-thinking/chat-thinking"
},
"component": true
}

```

### 02组件状态

#### 思考中

**WXML** (`html`):
```html
<view class="chat-example-block">
<t-chat-thinking content="{{content}}" layout="block" status="{{status}}" bind:collapsedChange="handleCollapsedChange" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
animation: 'moving',
content: {
text: '嗯，用户问牛顿第一定律是不是适用于所有参考系。首先，我得先回忆一下牛顿第一定律的内容。牛顿第一定律',
title: '思考中···',
},
status: 'pending',
},
methods: {
handleCollapsedChange(e) {
console.log('展开状态变化:', e.detail);
},
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-thinking": "tdesign-miniprogram/chat-thinking/chat-thinking"
}
}

```

#### 思考完成

**WXML** (`html`):
```html
<view class="chat-example-block">
<t-chat-thinking content="{{content}}" layout="block" status="{{status}}" bind:collapsedChange="handleCollapsedChange" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
animation: 'moving',
status: 'complete',
content: {
text: '嗯，用户问牛顿第一定律是不是适用于所有参考系。首先，我得先回忆一下牛顿第一定律的内容。牛顿第一定律，也就是惯性定律，说物体在没有外力作用时会保持静止或匀速直线运动。也就是说， 保持原来的运动状态。',
title: '已深度思考(用时19秒)',
},
},
methods: {
handleCollapsedChange(e) {
console.log('展开状态变化:', e.detail);
},
},
});

```

**CSS** (`css`):
```css
.chat-example-block {
background-color: var(--td-bg-color-container);
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-thinking": "tdesign-miniprogram/chat-thinking/chat-thinking",
"t-radio": "tdesign-miniprogram/radio/radio",
"t-radio-group": "tdesign-miniprogram/radio-group/radio-group"
}
}

```

### 03组件样式

支持通过`layout`来设置思考过程的布局方式

**WXML** (`html`):
```html
<block>
<view class="chat-example-desc">block 样式</view>
<view class="chat-example-block">
<t-chat-thinking layout="block" content="{{content}}" status="{{status}}" animation="{{animation}}" />
</view>

<view class="chat-example-desc">border 样式</view>
<view class="chat-example-block">
<t-chat-thinking layout="border" content="{{content}}" status="{{status}}" animation="{{animation}}" />
</view>
</block>

```

**JS** (`javascript`):
```javascript
Component({
data: {
animation: 'moving',
status: 'complete',
content: {
text: '嗯，用户问牛顿第一定律是不是适用于所有参考系。首先，我得先回忆一下牛顿第一定律的内容。牛顿第一定律，也就是惯性定律，说物体在没有外力作用时会保持静止或匀速直线运动。也就是说， 保持原来的运动状态。',
title: '已深度思考(用时19秒)',
},
},
});

```

**CSS** (`css`):
```css
.chat-example-desc {
margin: var(--td-spacer-3) var(--td-spacer-2) var(--td-spacer-2);
font-size: var(--td-font-size-base);
white-space: pre-line;
color: var(--bg-color-demo-desc);
line-height: 22px;
}

.chat-example-desc:first-child {
margin-top: -8px;
}

.chat-example-block {
background-color: var(--td-bg-color-container);
padding: var(--td-spacer-2);
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-chat-thinking": "tdesign-miniprogram/chat-thinking/chat-thinking"
}
}

```

## API

### ChatThinkingProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| animation | String | moving | 内容区域最大高度，超出会自动滚动。可选项：skeleton/moving/gradient/dot | N |
| collapsed | Boolean | false | 是否折叠 | N |
| content | Object | - | 必需。思考内容对象。TS 类型：`{ text?: string; title?: string }` | Y |
| layout | String | block | 布局方式。可选项：block/border | N |
| max-height | Number | - | 内容区域最大高度，超出会自动滚动 | N |
| status | String | pending | 必需。思考状态。可选项：complete/stop/error/pending | Y |

### ChatThinkingEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| collapsed-change | `(value: Boolean)` | 切换折叠面板时触发 |