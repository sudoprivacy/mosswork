# FastAPI 生产化参考

## 项目结构（见 SKILL.md 模板）
分层：`api`(路由) → `services`(业务) → `repositories`(数据访问) → `models`(ORM)。

## 配置：pydantic-settings
```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "app"
    db_url: str = Field(alias="DATABASE_URL")   # 凭据走环境变量，不进代码
    jwt_secret: str
    class Config: env_file = ".env"

settings = Settings()
```

## 认证（OAuth2 密码流 + JWT）
```python
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
import jwt

oauth2 = OAuth2PasswordBearer(tokenUrl="auth/login")

def get_user(token: str = Depends(oauth2)) -> dict:
    try:
        return jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(401, "invalid token")
```

## 后台任务 / 重活
- 轻量异步 → `BackgroundTasks`
- 重计算 / 周期性 → `Celery` + Redis，或 `arq`；不要在请求线程里跑训练/大批量 IO

## 测试（真实 DB + 事务回滚）
```python
from fastapi.testclient import TestClient
import pytest

@pytest.fixture
def client():
    yield TestClient(app)   # 用测试库，teardown 回滚

def test_health(client):
    assert client.get("/health").status_code == 200
```

## 生产部署清单
- [ ] `requirements.txt` 锁定版本，含 `uvicorn[standard]`
- [ ] `Dockerfile` 用 `python:3.12-slim`，非 root 用户运行
- [ ] CORS 显式白名单，不写 `*`
- [ ] 全局异常处理器（不向客户端泄露堆栈）
- [ ] 限流（slowapi / 网关层），防爆破
- [ ] 结构化日志（json），不上报密钥

## 常见坑
- 启动时连库失败阻塞 → 用 lifespan 做带超时的启动检查
- `Depends` 循环 → 把依赖拆到独立模块
- 同步阻塞调用（requests）卡事件循环 → 改用 `httpx.AsyncClient` 或 `anyio.to_thread`
- Pydantic v2：`model_dump()` 替代 `dict()`；`Field(alias=...)` 需 `populate_by_name`
