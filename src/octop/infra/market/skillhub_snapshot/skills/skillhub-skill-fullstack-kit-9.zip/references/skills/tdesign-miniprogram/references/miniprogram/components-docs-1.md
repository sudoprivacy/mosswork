# 合并文档 第1部分（共3部分，含 20 个组件）


---

# [action-sheet]

# ActionSheet 动作面板

## 示例

该组件于 0.9.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-action-sheet": "tdesign-miniprogram/action-sheet/action-sheet",
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/IQVKnNmp8i5e)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

列表型动作面板

**WXML** (`html`):
```html
<t-action-sheet id="t-action-sheet" usingCustomNavbar bind:selected="handleSelected" />

<t-button size="large" variant="outline" bind:tap="handleAction" block theme="primary">常规列表型</t-button>

<t-button size="large" variant="outline" bind:tap="showDescAction" block theme="primary">带描述列表型</t-button>

<t-button size="large" variant="outline" bind:tap="showIconAction" block theme="primary">带图标列表型</t-button>

```

**JS** (`javascript`):
```javascript
import ActionSheet, { ActionSheetTheme } from 'tdesign-miniprogram/action-sheet';

Component({
methods: {
handleAction() {
ActionSheet.show({
theme: ActionSheetTheme.List,
selector: '#t-action-sheet',
context: this,
cancelText: 'cancel',
items: ['Move', 'Mark as important', 'Unsubscribe', 'Add to Tasks'],
});
},
showDescAction() {
ActionSheet.show({
theme: ActionSheetTheme.List,
selector: '#t-action-sheet',
context: this,
cancelText: 'cancel',
description: 'Email Settings',
items: ['Move', 'Mark as important', 'Unsubscribe', 'Add to Tasks'],
});
},
showIconAction() {
ActionSheet.show({
theme: ActionSheetTheme.List,
selector: '#t-action-sheet',
context: this,
cancelText: 'cancel',
items: [
{
label: 'Move',
icon: 'enter',
},
{
label: 'Mark as important',
icon: 'bookmark',
},
{
label: 'Unsubscribe',
icon: 'pin',
},
{
label: 'Add to Tasks',
icon: 'cloud-upload',
},
],
});
},
handleSelected(e) {
console.log(e.detail);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-action-sheet": "tdesign-miniprogram/action-sheet/action-sheet"
}
}

```

宫格型动作面板

**WXML** (`html`):
```html
<t-action-sheet id="t-action-sheet" usingCustomNavbar bind:selected="handleSelected" />

<t-button size="large" variant="outline" bind:tap="handleAction" block theme="primary">常规宫格型</t-button>

<t-button size="large" variant="outline" bind:tap="handleActionWithDesc" block theme="primary">常描述宫格型</t-button>

<t-button size="large" variant="outline" bind:tap="handleMultiAction" block theme="primary">带翻页宫格型</t-button>

```

**JS** (`javascript`):
```javascript
import ActionSheet, { ActionSheetTheme } from 'tdesign-miniprogram/action-sheet';

const firstGrid = [
{
label: '微信',
image: 'https://tdesign.gtimg.com/mobile/demos/wechat.png',
},
{
label: '朋友圈',
image: 'https://tdesign.gtimg.com/mobile/demos/times.png',
},
{
label: 'QQ',
image: 'https://tdesign.gtimg.com/mobile/demos/qq.png',
},
{
label: '企业微信',
image: 'https://tdesign.gtimg.com/mobile/demos/wecom.png',
},
{
label: '收藏',
icon: 'star',
},
{
label: '刷新',
icon: 'refresh',
},
{
label: '下载',
icon: 'download',
},
{
label: '复制',
icon: 'queue',
},
];

Component({
methods: {
handleAction() {
ActionSheet.show({
theme: ActionSheetTheme.Grid,
selector: '#t-action-sheet',
context: this,
items: firstGrid,
});
},
handleActionWithDesc() {
ActionSheet.show({
theme: ActionSheetTheme.Grid,
selector: '#t-action-sheet',
context: this,
items: firstGrid,
description: '动作面板描述文字',
});
},

handleMultiAction() {
ActionSheet.show({
theme: ActionSheetTheme.Grid,
selector: '#t-action-sheet',
context: this,
items: firstGrid.concat(
new Array(8).fill({
label: '标题文字',
icon: 'image',
}),
),
});
},
handleSelected(e) {
console.log(e.detail);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-action-sheet": "tdesign-miniprogram/action-sheet/action-sheet"
}
}

```

### 组件状态

宫格型动作面板

**WXML** (`html`):
```html
<t-action-sheet id="t-action-sheet" usingCustomNavbar bind:selected="handleSelected" />

<t-button size="large" variant="outline" bind:tap="handleAction" block theme="primary">列表型选项状态</t-button>

```

**JS** (`javascript`):
```javascript
import ActionSheet, { ActionSheetTheme } from 'tdesign-miniprogram/action-sheet';

Component({
methods: {
handleAction() {
ActionSheet.show({
theme: ActionSheetTheme.List,
selector: '#t-action-sheet',
context: this,
cancelText: 'cancel',
items: [
{
label: 'Move',
icon: 'enter',
},
{
label: 'Mark as important',
icon: 'bookmark',
color: '#0052D9',
},
{
label: 'Unsubscribe',
icon: 'pin',
color: '#E34D59',
},
{
label: 'Add to Tasks',
icon: 'cloud-upload',
disabled: true,
},
],
});
},
handleSelected(e) {
console.log(e.detail);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-action-sheet": "tdesign-miniprogram/action-sheet/action-sheet"
}
}

```

### 组件样式

列表型对齐方式

**WXML** (`html`):
```html
<t-action-sheet id="t-action-sheet" usingCustomNavbar bind:selected="handleSelected" />

<t-button size="large" variant="outline" custom-dataset="center" bind:tap="handleAction" block theme="primary"
>居中列表型</t-button
>

<t-button size="large" variant="outline" custom-dataset="left" bind:tap="handleAction" block theme="primary"
>左对齐列表型</t-button
>

```

**JS** (`javascript`):
```javascript
import ActionSheet, { ActionSheetTheme } from 'tdesign-miniprogram/action-sheet';

Component({
methods: {
handleAction(e) {
const align = e.detail.currentTarget.dataset.custom;

ActionSheet.show({
theme: ActionSheetTheme.List,
selector: '#t-action-sheet',
context: this,
cancelText: 'cancel',
align,
description: 'Email Settings',
items: [
{
label: 'Move',
icon: 'enter',
},
{
label: 'Mark as important',
icon: 'bookmark',
},
{
label: 'Unsubscribe',
icon: 'pin',
},
{
label: 'Add to Tasks',
icon: 'cloud-upload',
},
],
});
},
handleSelected(e) {
console.log(e.detail);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-action-sheet": "tdesign-miniprogram/action-sheet/action-sheet"
}
}

```

### 支持指令调用

```javascript
import ActionSheet, { ActionSheetTheme } from 'tdesign-miniprogram/action-sheet/index';

// 指令调用不同于组件引用不需要传入visible
const basicListOption: ActionSheetShowOption = {
theme: ActionSheetTheme.List,
selector: '#t-action-sheet',
items: [
{
label: '默认选项',
},
{
label: '失效选项',
disabled: true,
},
{
label: '警告选项',
color: '#e34d59',
},
],
};

const handler = ActionSheet.show(basicListOption);
```

指令调用的关闭如下

```javascript
handler.close();
```

## API

### ActionSheetProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| align | String | center | `0.29.0`。水平对齐方式。可选项：center/left | N |
| cancel-text | String | - | 设置取消按钮的文本 | N |
| count | Number | 8 | 设置每页展示菜单的数量，仅当 type=grid 时有效 | N |
| description | String | - | `0.29.0`。动作面板描述文字 | N |
| items | Array | - | 必需。菜单项。TS 类型：`Array<string \| ActionSheetItem>``interface ActionSheetItem { label: string; description?: string; color?: string; disabled?: boolean; icon?: string; suffixIcon?: string }`。详细类型定义 | Y |
| popup-props | Object | {} | 透传 Popup 组件全部属性。TS 类型：`PopupProps`，Popup API Documents。详细类型定义 | N |
| show-cancel | Boolean | true | 是否显示取消按钮 | N |
| show-overlay | Boolean | true | 是否显示遮罩层 | N |
| theme | String | list | 展示类型，列表和表格形式展示。可选项：list/grid | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| visible | Boolean | false | 显示与隐藏 | N |
| default-visible | Boolean | undefined | 显示与隐藏。非受控属性 | N |

### ActionSheetEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| cancel | - | 点击取消按钮时触发 |
| close | `(trigger: ActionSheetTriggerSource)` | 关闭时触发。详细类型定义。<br>`type ActionSheetTriggerSource = 'overlay' \| 'command' \| 'select' `<br> |
| selected | `(selected: ActionSheetItem \| string, index: number)` | 选择菜单项时触发 |

### ActionSheetSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### ActionSheetExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-cancel | 取消样式类 |
| t-class-content | 内容样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-action-sheet-border-color | @component-stroke | - |
| --td-action-sheet-border-radius | @radius-extraLarge | - |
| --td-action-sheet-cancel-color | @text-color-primary | - |
| --td-action-sheet-color | @text-color-primary | - |
| --td-action-sheet-description-color | @text-color-placeholder | - |
| --td-action-sheet-description-font | @font-body-medium | - |
| --td-action-sheet-disabled-color | @text-color-disabled | - |
| --td-action-sheet-dot-active-color | @brand-color | - |
| --td-action-sheet-dot-color | @text-color-disabled | - |
| --td-action-sheet-dot-size | 16rpx | - |
| --td-action-sheet-gap-color | @bg-color-page | - |

---

# [avatar]

# Avatar 头像

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-avatar": "tdesign-miniprogram/avatar/avatar",
"t-avatar-group": "tdesign-miniprogram/avatar-group/avatar-group"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/BLUuQNmC8K5Y)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 头像类型

图片头像

**WXML** (`html`):
```html
<t-avatar class="avatar-example" image="{{image}}" />
<t-avatar class="avatar-example" shape="round" image="{{image}}" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
image: 'https://tdesign.gtimg.com/mobile/demos/avatar1.png',
},
});

```

**CSS** (`css`):
```css
.avatar-example {
margin-right: 64rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-avatar": "tdesign-miniprogram/avatar/avatar"
}
}

```

字符头像

**WXML** (`html`):
```html
<t-avatar class="avatar-example" t-class-content="external-class-content" aria-label="字符头像">A</t-avatar>
<t-avatar class="avatar-example" t-class-content="external-class-content" shape="round">A</t-avatar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
image: 'https://tdesign.gtimg.com/mobile/demos/avatar1.png',
},
});

```

**CSS** (`css`):
```css
.avatar-example:not(:last-child) {
margin-right: 64rpx;
}

.external-class-content {
color: #fff;
background-color: var(--td-brand-color, #0052d9);
font-weight: 400;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-avatar": "tdesign-miniprogram/avatar/avatar"
}
}

```

图标头像

**WXML** (`html`):
```html
<t-avatar class="avatar-example" icon="user" />
<t-avatar class="avatar-example" shape="round" icon="user" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
image: 'https://tdesign.gtimg.com/mobile/demos/avatar1.png',
},
});

```

**CSS** (`css`):
```css
.avatar-example:not(:last-child) {
margin-right: 64rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-avatar": "tdesign-miniprogram/avatar/avatar"
}
}

```

徽标头像

**WXML** (`html`):
```html
<t-avatar class="avatar-example" image="{{image}}" badge-props="{{ {dot: true, offset: [0, 4] } }}" />
<t-avatar
class="avatar-example"
t-class-content="external-class-content"
badge-props="{{ {count: 8, offset: [-6, 6] } }}"
>A</t-avatar
>
<t-avatar class="avatar-example" icon="user" badge-props="{{ {count: 12,  offset: [-6, 6] } }}" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
image: 'https://tdesign.gtimg.com/mobile/demos/avatar1.png',
},
});

```

**CSS** (`css`):
```css
.avatar-example:not(:last-child) {
margin-right: 64rpx;
}

.external-class-content {
color: #fff;
background-color: var(--td-brand-color, #0052d9);
font-weight: 400;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-avatar": "tdesign-miniprogram/avatar/avatar"
}
}

```

### 组合头像

纯展示

**WXML** (`html`):
```html
<t-avatar-group max="5" collapseAvatar="+5">
<t-avatar wx:for="{{pics}}" wx:for-item="pic" wx:key="index" image="{{pic}}" />
</t-avatar-group>

```

**JS** (`javascript`):
```javascript
Component({
data: {
pics: [
'https://tdesign.gtimg.com/mobile/demos/avatar1.png',
'https://tdesign.gtimg.com/mobile/demos/avatar2.png',
'https://tdesign.gtimg.com/mobile/demos/avatar3.png',
'https://tdesign.gtimg.com/mobile/demos/avatar4.png',
'https://tdesign.gtimg.com/mobile/demos/avatar5.png',
'https://tdesign.gtimg.com/mobile/demos/avatar1.png',
],
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-avatar": "tdesign-miniprogram/avatar/avatar",
"t-avatar-group": "tdesign-miniprogram/avatar-group/avatar-group"
}
}

```

带操作

**WXML** (`html`):
```html
<t-avatar-group cascading="right-up" max="5" bind:collapsed-item-click="onClickCollapsedAvatar">
<t-avatar wx:for="{{pics}}" wx:for-item="pic" wx:key="index" image="{{pic}}" />
</t-avatar-group>

```

**JS** (`javascript`):
```javascript
Component({
data: {
pics: [
'https://tdesign.gtimg.com/mobile/demos/avatar1.png',
'https://tdesign.gtimg.com/mobile/demos/avatar2.png',
'https://tdesign.gtimg.com/mobile/demos/avatar3.png',
'https://tdesign.gtimg.com/mobile/demos/avatar4.png',
'https://tdesign.gtimg.com/mobile/demos/avatar5.png',
'https://tdesign.gtimg.com/mobile/demos/avatar1.png',
],
},

methods: {
onAddTap() {
wx.showToast({ title: '您按下了添加', icon: 'none', duration: 1000 });
},
onClickCollapsedAvatar() {
console.log('click collapsed avatar');
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-avatar": "tdesign-miniprogram/avatar/avatar",
"t-avatar-group": "tdesign-miniprogram/avatar-group/avatar-group"
}
}

```

### 头像尺寸

头像 large/medium/small 尺寸

**WXML** (`html`):
```html
<view class="avatar-example">
<t-avatar class="avatar-example--large" image="{{image}}" size="large" />
<t-avatar class="avatar-example--large" t-class-content="external-class-content" size="large">A</t-avatar>
<t-avatar class="avatar-example--large" icon="user" size="large" />
</view>

<view class="avatar-example">
<t-avatar class="avatar-example--medium" image="{{image}}" />
<t-avatar class="avatar-example--medium" t-class-content="external-class-content" size="medium">A</t-avatar>
<t-avatar class="avatar-example--medium" icon="user" size="medium" />
</view>

<view class="avatar-example">
<t-avatar class="avatar-example--small" image="{{image}}" size="small" />
<t-avatar class="avatar-example--small" t-class-content="external-class-content" size="small">A</t-avatar>
<t-avatar class="avatar-example--small" icon="user" size="small" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
image: 'https://tdesign.gtimg.com/mobile/demos/avatar1.png',
},
});

```

**CSS** (`css`):
```css
.avatar-example {
display: flex;
margin-bottom: 32rpx;
}

.external-class-content {
color: #fff;
background-color: var(--td-brand-color, #0052d9);
font-weight: 400;
}

.avatar-example--small:not(:last-child) {
margin-right: 112rpx;
}

.avatar-example--medium:not(:last-child) {
margin-right: 96rpx;
}

.avatar-example--large:not(:last-child) {
margin-right: 64rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-avatar": "tdesign-miniprogram/avatar/avatar"
}
}

```

## API

### AvatarProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| alt | String | - | 头像替换文本，仅当图片加载失败时有效 | N |
| badge-props | Object | - | 头像右上角提示信息，继承 Badge 组件的全部特性。如：小红点，或者数字。TS 类型：`BadgeProps`，Badge API Documents。详细类型定义 | N |
| bordered | Boolean | false | 已废弃。是否显示外边框 | N |
| hide-on-load-failed | Boolean | false | 加载失败时隐藏图片 | N |
| icon | String / Object | - | 图标。值为字符串表示图标名称，值为`Object`类型，表示透传至`icon` | N |
| image | String | - | 图片地址 | N |
| image-props | Object | - | 透传至 Image 组件。TS 类型：`ImageProps`，Image API Documents。详细类型定义 | N |
| shape | String | - | 形状。优先级高于 AvatarGroup.shape 。Avatar 单独存在时，默认值为 circle。如果父组件 AvatarGroup 存在，默认值便由 AvatarGroup.shape 决定。可选项：circle/round。TS 类型：`ShapeEnum`。通用类型定义 | N |
| size | String | - | 尺寸，示例值：small/medium/large/24px/38px 等。优先级高于 AvatarGroup.size 。Avatar 单独存在时，默认值为 medium。如果父组件 AvatarGroup 存在，默认值便由 AvatarGroup.size 决定 | N |

### AvatarEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| error | - | 图片加载失败时触发 |

### AvatarSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### AvatarExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-alt | 替代文本样式类 |
| t-class-content | 内容样式类 |
| t-class-icon | 图标样式类 |
| t-class-image | 图片样式类 |

### AvatarGroupProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| cascading | String | 'left-up' | 图片之间的层叠关系，可选值：左侧图片在上和右侧图片在上。可选项：left-up/right-up。TS 类型：`CascadingValue``type CascadingValue = 'left-up' \| 'right-up'`。详细类型定义 | N |
| collapse-avatar | String | - | 头像数量超出时，会出现一个头像折叠元素。该元素内容可自定义。默认为`+N`。示例：`+5`，`...`,`更多` | N |
| max | Number | - | 能够同时显示的最多头像数量 | N |
| shape | String | - | 形状。优先级低于 Avatar.shape。可选项：circle/round。TS 类型：`ShapeEnum`。通用类型定义 | N |
| size | String | - | 尺寸，示例值：small/medium/large/24px/38px 等。优先级低于 Avatar.size | N |

### AvatarGroupEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| collapsed-item-click | - | 点击头像折叠元素触发 |

### AvatarGroupSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |
| collapse-avatar | 自定义`collapse-avatar`显示内容 |

### AvatarGroupExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |
| t-class-image | 图片样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-avatar-group-init-z-index | @avatar-group-init-zIndex | - |
| --td-avatar-group-line-spacing | 4rpx | - |
| --td-avatar-group-margin-left-large | -16rpx | - |
| --td-avatar-group-margin-left-medium | -16rpx | - |
| --td-avatar-group-margin-left-small | -16rpx | - |
| --td-avatar-bg-color | @brand-color-light-active | - |
| --td-avatar-border-color | #fff | - |
| --td-avatar-border-width-large | 6rpx | - |
| --td-avatar-border-width-medium | 4rpx | - |
| --td-avatar-border-width-small | 2rpx | - |
| --td-avatar-circle-border-radius | @radius-circle | - |
| --td-avatar-content-color | @brand-color | - |
| --td-avatar-icon-large-font-size | 64rpx | - |
| --td-avatar-icon-medium-font-size | 48rpx | - |
| --td-avatar-icon-small-font-size | 40rpx | - |
| --td-avatar-large-width | 128rpx | - |
| --td-avatar-margin-left | 0 | - |
| --td-avatar-medium-width | 96rpx | - |
| --td-avatar-round-border-radius | @radius-default | - |
| --td-avatar-small-width | 80rpx | - |
| --td-avatar-text-large-font-size | @font-size-xl | - |
| --td-avatar-text-medium-font-size | @font-size-m | - |
| --td-avatar-text-small-font-size | @font-size-base | - |

---

# [back-top]

# BackTop 返回顶部

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-back-top": "tdesign-miniprogram/back-top/back-top",
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/miU0GNmy8X5O)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础返回顶部

**WXML** (`html`):
```html
<t-back-top
theme="{{backTopTheme}}"
text="{{backTopText}}"
scroll-top="{{scrollTop}}"
bind:to-top="onToTop"
></t-back-top>

```

**JS** (`javascript`):
```javascript
Component({
properties: {
scrollTop: { type: Number, value: 0 },
},
data: {
backTopTheme: 'round',
backTopText: '顶部',
},
methods: {
onToTop(e) {
this.triggerEvent('to-top', e);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-back-top": "tdesign-miniprogram/back-top/back-top"
}
}

```

## API

### BackTopProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| fixed | Boolean | true | 是否绝对定位固定到屏幕右下方 | N |
| icon | String / Boolean / Object | true | 图标。值为`false`表示不显示图标。不传表示使用默认图标`'backtop'` | N |
| scroll-top | Number | 0 | 页面滚动距离 | N |
| text | String | '' | 文案 | N |
| theme | String | round | 预设的样式类型。可选项：round/half-round/round-dark/half-round-dark | N |
| visibility-height | Number | 200 | 滚动高度达到此参数值才出现 | N |

### BackTopEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| to-top | - | 点击触发 |

### BackTopSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |
| icon | 自定义图标内容 |

### BackTopExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-icon | 图标样式类 |
| t-class-text | 文本样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-back-top-half-round-border-radius | @radius-round | - |
| --td-back-top-round-bg-color | @bg-color-container | - |
| --td-back-top-round-border-color | @component-border | - |
| --td-back-top-round-border-radius | @radius-circle | - |
| --td-back-top-round-color | @text-color-primary | - |
| --td-back-top-round-dark-bg-color | @gray-color-13 | - |
| --td-back-top-round-dark-color | @text-color-anti | - |

---

# [badge]

# Badge 徽标

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-badge": "tdesign-miniprogram/badge/badge"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/W0VFgNmo845R)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

**WXML** (`html`):
```html
<view class="demo-desc">红点徽标</view>
<view class="demo-wrapper">
<t-badge dot class="wrapper" content="消息" />
<t-badge dot offset="{{ [1, -1] }}" class="wrapper">
<t-icon name="notification" size="48rpx" ariaLabel="通知" />
</t-badge>
<t-badge dot offset="{{ [1, 1] }}" class="wrapper">
<t-button>按钮</t-button>
</t-badge>
</view>

<view class="demo-desc">数字徽标</view>
<view class="demo-wrapper">
<t-badge count="8" content="消息" offset="{{ [4] }}" class="wrapper" />
<t-badge count="2" offset="{{ [2, -2] }}" class="wrapper">
<t-icon name="notification" size="48rpx" ariaLabel="通知" />
</t-badge>
<t-badge count="8" offset="{{ [2, 2] }}" class="wrapper">
<t-button>按钮</t-button>
</t-badge>
</view>

<view class="demo-desc">自定义徽标</view>
<view class="demo-wrapper">
<t-badge count="NEW" offset="{{ [0, 2] }}" ariaRole="button">
<t-button icon="notification" ariaLabel="通知" shape="square" size="large" />
</t-badge>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.wrapper {
margin-right: 48px;
}

.demo-wrapper {
display: flex;
margin-left: 32rpx;
margin-top: 28px;
margin-bottom: 24px;
align-items: center;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-badge": "tdesign-miniprogram/badge/badge",
"t-icon": "tdesign-miniprogram/icon/icon",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

### 组件样式

**WXML** (`html`):
```html
<!--
由于 button 被 t-badeg包裹，t-badge 中存在 role="option", 导致button中的 role=button 失去作用。相当于button 被申明了 role=presentation
因此提升了 aria-role=button 到 t-badge上
可参考： https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Roles/option_role
https://www.zhangxinxu.com/wordpress/2017/01/voiceover-aria-web-accessible-iphone/
-->

<view class="demo-desc">圆形徽标</view>
<view class="demo-wrapper">
<t-badge count="2" offset="{{ [2, -2] }}">
<t-icon name="notification" size="48rpx" ariaLabel="通知" />
</t-badge>
</view>

<view class="demo-desc">方形徽标</view>
<view class="demo-wrapper">
<t-badge count="2" shape="square" offset="{{ [1, -2] }}">
<t-icon name="notification" size="48rpx" ariaLabel="通知" />
</t-badge>
</view>

<view class="demo-desc">气泡徽标</view>
<view class="demo-wrapper">
<t-badge count="领积分" shape="bubble" ariaRole="button">
<t-button icon="shop" ariaLabel="商店" shape="square" size="large" />
</t-badge>
</view>

<view class="demo-desc" style="margin-bottom: 32rpx">角标</view>
<t-cell title="单行标题" t-class="t-class-cell">
<t-badge count="NEW" offset="{{skylineRender ? ['-18rpx', '-32rpx']: [0, 0]}}" shape="ribbon-left" slot="note" />
</t-cell>
<t-cell title="单行标题" bordered="{{false}}" t-class="t-class-cell">
<t-badge count="NEW" offset="{{skylineRender ? ['-18rpx', '-32rpx']: [0, 0]}}" shape="ribbon" slot="note" />
</t-cell>

<view class="demo-desc" style="margin-bottom: 32rpx">三角角标</view>
<t-cell title="单行标题" t-class="t-class-cell">
<t-badge count="NEW" offset="{{skylineRender ? ['-24rpx', '-32rpx']: [0, 0]}}" shape="triangle-left" slot="note" />
</t-cell>
<t-cell title="单行标题" bordered="{{false}}" t-class="t-class-cell">
<t-badge count="NEW" offset="{{skylineRender ? ['-24rpx', '-32rpx']: [0, 0]}}" shape="triangle-right" slot="note" />
</t-cell>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
options: {
styleIsolation: 'apply-shared',
},
behaviors: [SkylineBehavior],
});

```

**CSS** (`css`):
```css
.demo-wrapper {
display: flex;
margin-left: 32rpx;
margin-top: 28px;
margin-bottom: 24px;
align-items: center;
}

.t-class-cell {
overflow: hidden;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-badge": "tdesign-miniprogram/badge/badge",
"t-cell": "tdesign-miniprogram/cell/cell",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

### 组件尺寸

**WXML** (`html`):
```html
<view class="demo-desc">Large</view>

<view class="block">
<t-avatar icon="user" size="large" badge-props="{{ {count: 8, size: 'large', offset: [7, 7]} }}" />
</view>

<view class="demo-desc">Medium</view>

<view class="block">
<t-avatar icon="user" badge-props="{{ {count: 8, offset: [5, 5]} }}" />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.block {
padding: 32rpx 32rpx 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-badge": "tdesign-miniprogram/badge/badge",
"t-avatar": "tdesign-miniprogram/avatar/avatar"
}
}

```

## FAQ

### 如何处理由ribbon徽标溢出导致页面出现横向滚动？

角标溢出问题建议从父容器组件处理。如 [#3063](https://github.com/Tencent/tdesign-miniprogram/issues/3063)，可以给父容器 `cell` 组件添加 `overflow: hidden`，处理溢出造成页面出现横向滚动的问题。

## API

### BadgeProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| color | String | - | 颜色 | N |
| content | String | - | 徽标内容，示例：`content='自定义内容'`。也可以使用默认插槽定义 | N |
| count | String / Number | 0 | 徽标右上角内容。可以是数字，也可以是文字。如：'new'/3/99+。特殊：值为空表示使用插槽渲染 | N |
| dot | Boolean | false | 是否为红点 | N |
| max-count | Number | 99 | 封顶的数字值 | N |
| offset | Array | - | 设置状态点的位置偏移，示例：[-10, 20] 或 ['10em', '8rem']。TS 类型：`Array<string \| number>` | N |
| shape | String | circle | 徽标形状，其中 ribbon 和 ribbon-right 等效。可选项：circle/square/bubble/ribbon/ribbon-right/ribbon-left/triangle-right/triangle-left | N |
| show-zero | Boolean | false | 当数值为 0 时，是否展示徽标 | N |
| size | String | medium | 尺寸。可选项：medium/large | N |

### BadgeSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |
| count | 徽标右上角内容 |

### BadgeExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |
| t-class-count | 计数样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-badge-basic-height | 32rpx | - |
| --td-badge-basic-padding | 8rpx | - |
| --td-badge-basic-width | 32rpx | - |
| --td-badge-bg-color | @error-color | - |
| --td-badge-border-radius | 4rpx | - |
| --td-badge-bubble-border-radius | 20rpx 20rpx 20rpx 1px | - |
| --td-badge-content-text-color | @text-color-primary | - |
| --td-badge-dot-size | 16rpx | - |
| --td-badge-font | @font-mark-extraSmall | - |
| --td-badge-large-font | @font-mark-small | - |
| --td-badge-large-height | 40rpx | - |
| --td-badge-large-padding | 10rpx | - |
| --td-badge-text-color | @text-color-anti | - |

---

# [button]

# Button 按钮

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/NSVqRNmh8l5a)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

#### 基础按钮

**WXML** (`html`):
```html
<view class="button-example">
<t-button theme="primary" size="large">填充按钮</t-button>
<t-button theme="light" size="large">填充按钮</t-button>
<t-button size="large">填充按钮</t-button>
</view>

<view class="button-example">
<t-button theme="primary" size="large" variant="outline">描边按钮</t-button>
<t-button theme="primary" size="large" variant="text">文字按钮</t-button>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.button-example {
margin: 32rpx;
display: flex;
justify-content: space-between;
}

.button-example:after {
content: '';
flex: auto;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button"
}
}

```

#### 图标按钮

**WXML** (`html`):
```html
<view class="button-example">
<t-button theme="primary" icon="app" content="填充按钮" size="large"></t-button>
<t-button wx:if="{{skylineRender}}" theme="light" size="large">
<t-loading t-class="loading" theme="spinner" size="40rpx" text="加载中..." />
</t-button>
<t-button wx:else theme="primary" size="large" loading>加载中</t-button>
<t-button theme="primary" icon="search" shape="square" size="large" aria-label="搜索"></t-button>
</view>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({ behaviors: [SkylineBehavior] });

```

**CSS** (`css`):
```css
.button-example {
margin: 32rpx;
display: flex;
justify-content: space-between;
}

.button-example:after {
content: '';
flex: auto;
}

.button-example .loading {
display: flex;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-loading": "tdesign-miniprogram/loading/loading"
}
}

```

#### 幽灵按钮

**WXML** (`html`):
```html
<view class="button-example">
<t-button theme="primary" ghost size="large">幽灵按钮</t-button>
<t-button theme="danger" ghost size="large">幽灵按钮</t-button>
<t-button ghost size="large">幽灵按钮</t-button>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.button-example {
display: flex;
justify-content: space-between;
background-color: #181818;
padding: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button"
}
}

```

#### 组合按钮

**WXML** (`html`):
```html
<view class="button-example">
<t-button theme="light" block size="large" t-class="group-btn">填充按钮</t-button>
<t-button theme="primary" block size="large" t-class="group-btn">填充按钮</t-button>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.button-example {
margin: 32rpx;
display: flex;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button"
}
}

```

#### 通栏按钮

**WXML** (`html`):
```html
<view class="button-example">
<t-button theme="primary" size="large" block>填充按钮</t-button>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.button-example {
margin: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button"
}
}

```

### 02组件状态

#### 按钮禁用态

**WXML** (`html`):
```html
<view class="button-example">
<t-button theme="primary" size="large" disabled>填充按钮</t-button>
<t-button theme="light" size="large" disabled>填充按钮</t-button>
<t-button size="large" disabled>填充按钮</t-button>
</view>

<view class="button-example">
<t-button theme="primary" size="large" variant="outline" disabled>描边按钮</t-button>
<t-button theme="primary" size="large" variant="text" disabled>文字按钮</t-button>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.button-example {
margin: 32rpx;
display: flex;
justify-content: space-between;
}

.button-example:after {
content: '';
flex: auto;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button"
}
}

```

### 03组件样式

#### 按钮尺寸

**WXML** (`html`):
```html
<view class="button-example">
<t-button theme="primary" size="large">按钮48</t-button>
<t-button theme="primary">按钮40</t-button>
<t-button theme="primary" size="small">按钮32</t-button>
<t-button theme="primary" size="extra-small">按钮28</t-button>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.button-example {
display: flex;
align-items: flex-start;
justify-content: space-between;
margin: 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button"
}
}

```

#### 按钮形状

**WXML** (`html`):
```html
<view class="button-example">
<t-button theme="primary" size="large">填充按钮</t-button>
<t-button theme="primary" size="large" icon="search" shape="square" aria-label="搜索"></t-button>
<t-button theme="primary" size="large" shape="round">填充按钮</t-button>
<t-button theme="primary" size="large" icon="search" shape="circle" aria-label="搜索"></t-button>
</view>

<t-button theme="primary" size="large" block t-class="external-class">填充按钮</t-button>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.button-example {
display: flex;
justify-content: space-between;
margin: 0 32rpx 32rpx;
}

.external-class {
border-radius: 0 !important;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button"
}
}

```

#### 按钮主题

**WXML** (`html`):
```html
<view class="button-example">
<t-button size="large">填充按钮</t-button>
<t-button size="large" variant="outline">描边按钮</t-button>
<t-button size="large" variant="text">文字按钮</t-button>
</view>

<view class="button-example">
<t-button size="large" theme="primary">填充按钮</t-button>
<t-button size="large" theme="primary" variant="outline">描边按钮</t-button>
<t-button size="large" theme="primary" variant="text">文字按钮</t-button>
</view>

<view class="button-example">
<t-button size="large" theme="danger">填充按钮</t-button>
<t-button size="large" theme="danger" variant="outline">描边按钮</t-button>
<t-button size="large" theme="danger" variant="text">文字按钮</t-button>
</view>

<view class="button-example">
<t-button size="large" theme="light">填充按钮</t-button>
<t-button size="large" theme="light" variant="outline">描边按钮</t-button>
<t-button size="large" theme="light" variant="text">文字按钮</t-button>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.button-example {
margin: 32rpx;
display: flex;
justify-content: space-between;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button"
}
}

```

## API

### ButtonProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| app-parameter | String | - | 打开 APP 时，向 APP 传递的参数，open-type=launchApp时有效 | N |
| block | Boolean | false | 是否为块级元素 | N |
| content | String | - | 按钮内容 | N |
| custom-dataset | any | - | 自定义 dataset，可通过 event.currentTarget.dataset.custom 获取 | N |
| disabled | Boolean | undefined | 禁用状态。优先级：Button.disabled > Form.disabled | N |
| ghost | Boolean | false | 是否为幽灵按钮（镂空按钮） | N |
| hover-class | String | - | 指定按钮按下去的样式类，按钮不为加载或禁用状态时有效。当`hover-class="none"`时，没有点击态效果 | N |
| hover-start-time | Number | 20 | 按住后多久出现点击态，单位毫秒 | N |
| hover-stay-time | Number | 70 | 手指松开后点击态保留时间，单位毫秒 | N |
| hover-stop-propagation | Boolean | false | 指定是否阻止本节点的祖先节点出现点击态 | N |
| icon | String / Object | - | 图标名称。值为字符串表示图标名称，值为`Object`类型，表示透传至`icon` | N |
| lang | String | - | 指定返回用户信息的语言，zh_CN 简体中文，zh_TW 繁体中文，en 英文。<br>具体释义：<br>`en`英文；<br>`zh_CN`简体中文；<br>`zh_TW`繁体中文。<br>小程序官方文档。可选项：en/zh_CN/zh_TW | N |
| loading | Boolean | false | 是否显示为加载状态 | N |
| loading-props | Object | - | 透传 Loading 组件全部属性。TS 类型：`LoadingProps`，Loading API Documents。详细类型定义 | N |
| open-type | String | - | 微信开放能力。<br>具体释义：<br>`contact`打开客服会话，如果用户在会话中点击消息卡片后返回小程序，可以从 bindcontact 回调中获得具体信息，具体说明（鸿蒙 OS 暂不支持）；<br>`liveActivity`通过前端获取新的一次性订阅消息下发机制使用的 code；<br>`share`触发用户转发，使用前建议先阅读使用指引；<br>`getPhoneNumber`获取用户手机号，可以从 bindgetphonenumber 回调中获取到用户信息，具体说明（小程序插件中不能使用）；<br>`getUserInfo`获取用户信息，可以从 bindgetuserinfo 回调中获取到用户信息 （小程序插件中不能使用）；<br>`launchApp`打开APP，可以通过 app-parameter 属性设定向 APP 传的参数具体说明；<br>`openSetting`打开授权设置页；<br>`feedback`打开“意见反馈”页面，用户可提交反馈内容并上传日志，开发者可以登录小程序管理后台后进入左侧菜单“客服反馈”页面获取到反馈内容；<br>`chooseAvatar`获取用户头像，可以从 bindchooseavatar 回调中获取到头像信息；<br>`agreePrivacyAuthorization`用户同意隐私协议按钮。用户点击一次此按钮后，所有隐私接口可以正常调用。可通过`bindagreeprivacyauthorization`监听用户同意隐私协议事件。隐私合规开发指南详情可见《小程序隐私协议开发指南》。<br>小程序官方文档。可选项：contact/share/getPhoneNumber/getUserInfo/launchApp/openSetting/feedback/chooseAvatar/agreePrivacyAuthorization | N |
| phone-number-no-quota-toast | Boolean | true | 原生按钮属性，当手机号快速验证或手机号实时验证额度用尽时，是否对用户展示“申请获取你的手机号，但该功能使用次数已达当前小程序上限，暂时无法使用”的提示，默认展示，open-type="getPhoneNumber" 或 open-type="getRealtimePhoneNumber" 时有效 | N |
| send-message-img | String | 截图 | 会话内消息卡片图片，open-type="contact"时有效 | N |
| send-message-path | String | 当前分享路径 | 会话内消息卡片点击跳转小程序路径，open-type="contact"时有效 | N |
| send-message-title | String | 当前标题 | 会话内消息卡片标题，open-type="contact"时有效 | N |
| session-from | String | - | 会话来源，open-type="contact"时有效 | N |
| shape | String | rectangle | 按钮形状，有 4 种：长方形、正方形、圆角长方形、圆形。可选项：rectangle/square/round/circle | N |
| show-message-card | Boolean | false | 是否显示会话内消息卡片，设置此参数为 true，用户进入客服会话会在右下角显示"可能要发送的小程序"提示，用户点击后可以快速发送小程序消息，open-type="contact"时有效 | N |
| size | String | medium | 组件尺寸。可选项：extra-small/small/medium/large | N |
| t-id | String | - | 按钮标签id | N |
| theme | String | default | 组件风格，依次为品牌色、危险色。可选项：default/primary/danger/light | N |
| type | String | - | 同小程序的 formType。可选项：submit/reset | N |
| variant | String | base | 按钮形式，基础、线框、虚线、文字。可选项：base/outline/dashed/text | N |

### ButtonEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| agreeprivacyauthorization | - | 原生按钮属性，用户同意隐私协议事件回调，open-type=agreePrivacyAuthorization时有效 （Tips: 如果使用 onNeedPrivacyAuthorization 接口，需要在 bindagreeprivacyauthorization 触发后再调用 resolve({ event: "agree", buttonId })） |
| chooseavatar | - | 原生按钮属性，获取用户头像回调，`open-type=chooseAvatar`时有效。返回`e.detail.avatarUrl`为头像临时文件链接 |
| click | `(e: MouseEvent)` | 点击时触发 |
| contact | - | 原生按钮属性，客服消息回调，`open-type="contact"`时有效 |
| createliveactivity | - | 新的一次性订阅消息下发机制回调，`open-type=liveActivity`时有效 |
| error | - | 原生按钮属性，当使用开放能力时，发生错误的回调，`open-type=launchApp`时有效 |
| getphonenumber | - | 原生按钮属性，手机号快速验证回调，open-type=getPhoneNumber时有效。Tips：在触发 bindgetphonenumber 回调后应立即隐藏手机号按钮组件，或置为 disabled 状态，避免用户重复授权手机号产生额外费用 |
| getrealtimephonenumber | - | 原生按钮属性，手机号实时验证回调，open-type=getRealtimePhoneNumber 时有效。Tips：在触发 bindgetrealtimephonenumber 回调后应立即隐藏手机号按钮组件，或置为 disabled 状态，避免用户重复授权手机号产生额外费用 |
| getuserinfo | - | 原生按钮属性，用户点击该按钮时，会返回获取到的用户信息，回调的detail数据与wx.getUserInfo返回的一致，open-type="getUserInfo"时有效 |
| launchapp | - | 打开 APP 成功的回调，`open-type=launchApp`时有效 |
| opensetting | - | 原生按钮属性，在打开授权设置页后回调，open-type=openSetting时有效 |
| tap | `event` | 点击按钮，当按钮不为加载或禁用状态时触发 |

### ButtonSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，作用同`content`插槽 |
| content | 自定义`content`显示内容 |
| suffix | 右侧内容，可用于定义右侧图标 |

### ButtonExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-icon | 图标样式类 |
| t-class-loading | 加载样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-button-border-radius | @radius-default | - |
| --td-button-border-width | 4rpx | - |
| --td-button-danger-active-bg-color | @error-color-active | - |
| --td-button-danger-active-border-color | @error-color-active | - |
| --td-button-danger-bg-color | @error-color | - |
| --td-button-danger-border-color | @error-color | - |
| --td-button-danger-color | @text-color-anti | - |
| --td-button-danger-dashed-border-color | @button-danger-dashed-color | - |
| --td-button-danger-dashed-color | @error-color | - |
| --td-button-danger-dashed-disabled-color | @button-danger-disabled-color | - |
| --td-button-danger-disabled-bg | @error-color-3 | - |
| --td-button-danger-disabled-border-color | @error-color-3 | - |
| --td-button-danger-disabled-color | @font-white-1 | - |
| --td-button-danger-outline-active-bg-color | @bg-color-container-active | - |
| --td-button-danger-outline-active-border-color | @error-color-active | - |
| --td-button-danger-outline-border-color | @button-danger-outline-color | - |
| --td-button-danger-outline-color | @error-color | - |
| --td-button-danger-outline-disabled-color | @error-color-3 | - |
| --td-button-danger-text-active-bg-color | @bg-color-container-active | - |
| --td-button-danger-text-color | @error-color | - |
| --td-button-danger-text-disabled-color | @button-danger-disabled-color | - |
| --td-button-default-active-bg-color | @bg-color-component-active | - |
| --td-button-default-active-border-color | @bg-color-component-active | - |
| --td-button-default-bg-color | @bg-color-component | - |
| --td-button-default-border-color | @bg-color-component | - |
| --td-button-default-color | @text-color-primary | - |
| --td-button-default-disabled-bg | @bg-color-component-disabled | - |
| --td-button-default-disabled-border-color | @bg-color-component-disabled | - |
| --td-button-default-disabled-color | @text-color-disabled | - |
| --td-button-default-outline-active-bg-color | @bg-color-container-active | - |
| --td-button-default-outline-active-border-color | @component-border | - |
| --td-button-default-outline-border-color | @component-border | - |
| --td-button-default-outline-color | @text-color-primary | - |
| --td-button-default-outline-disabled-color | @component-border | - |
| --td-button-default-text-active-bg-color | @bg-color-container-active | - |
| --td-button-extra-small-font-size | @font-size-base | - |
| --td-button-extra-small-height | 56rpx | - |
| --td-button-extra-small-icon-size | 36rpx | - |
| --td-button-extra-small-padding-horizontal | 16rpx | - |
| --td-button-font-weight | 600 | - |
| --td-button-ghost-border-color | @button-ghost-color | - |
| --td-button-ghost-color | @text-color-anti | - |
| --td-button-ghost-danger-border-color | @error-color | - |
| --td-button-ghost-danger-color | @error-color | - |
| --td-button-ghost-danger-hover-color | @error-color-active | - |
| --td-button-ghost-disabled-color | @font-white-4 | - |
| --td-button-ghost-hover-color | @font-white-2 | - |
| --td-button-ghost-primary-border-color | @brand-color | - |
| --td-button-ghost-primary-color | @brand-color | - |
| --td-button-ghost-primary-hover-color | @brand-color-active | - |
| --td-button-icon-border-radius | 8rpx | - |
| --td-button-icon-spacer | @spacer | - |
| --td-button-large-font-size | @font-size-m | - |
| --td-button-large-height | 96rpx | - |
| --td-button-large-icon-size | 48rpx | - |
| --td-button-large-padding-horizontal | 40rpx | - |
| --td-button-light-active-bg-color | @brand-color-light-active | - |
| --td-button-light-active-border-color | @brand-color-light-active | - |
| --td-button-light-bg-color | @brand-color-light | - |
| --td-button-light-border-color | @brand-color-light | - |
| --td-button-light-color | @brand-color | - |
| --td-button-light-disabled-bg | @brand-color-light | - |
| --td-button-light-disabled-border-color | @brand-color-light | - |
| --td-button-light-disabled-color | @brand-color-disabled | - |
| --td-button-light-outline-active-bg-color | @brand-color-light-active | - |
| --td-button-light-outline-active-border-color | @brand-color-active | - |
| --td-button-light-outline-bg-color | @brand-color-light | - |
| --td-button-light-outline-border-color | @button-light-outline-color | - |
| --td-button-light-outline-color | @brand-color | - |
| --td-button-light-outline-disabled-color | @brand-color-disabled | - |
| --td-button-light-text-active-bg-color | @bg-color-container-active | - |
| --td-button-light-text-color | @brand-color | - |
| --td-button-medium-font-size | @font-size-m | - |
| --td-button-medium-height | 80rpx | - |
| --td-button-medium-icon-size | 40rpx | - |
| --td-button-medium-padding-horizontal | 32rpx | - |
| --td-button-primary-active-bg-color | @brand-color-active | - |
| --td-button-primary-active-border-color | @brand-color-active | - |
| --td-button-primary-bg-color | @brand-color | - |
| --td-button-primary-border-color | @brand-color | - |
| --td-button-primary-color | @text-color-anti | - |
| --td-button-primary-dashed-border-color | @button-primary-dashed-color | - |
| --td-button-primary-dashed-color | @brand-color | - |
| --td-button-primary-dashed-disabled-color | @brand-color-disabled | - |
| --td-button-primary-disabled-bg | @brand-color-disabled | - |
| --td-button-primary-disabled-border-color | @brand-color-disabled | - |
| --td-button-primary-disabled-color | @text-color-anti | - |
| --td-button-primary-outline-active-bg-color | @bg-color-container-active | - |
| --td-button-primary-outline-active-border-color | @brand-color-active | - |
| --td-button-primary-outline-border-color | @button-primary-outline-color | - |
| --td-button-primary-outline-color | @brand-color | - |
| --td-button-primary-outline-disabled-color | @brand-color-disabled | - |
| --td-button-primary-text-active-bg-color | @bg-color-container-active | - |
| --td-button-primary-text-color | @brand-color | - |
| --td-button-primary-text-disabled-color | @brand-color-disabled | - |
| --td-button-small-font-size | @font-size-base | - |
| --td-button-small-height | 64rpx | - |
| --td-button-small-icon-size | 36rpx | - |
| --td-button-small-padding-horizontal | 24rpx | - |

---

# [calendar]

# Calendar 日历

## 示例

该组件于 0.22.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-calendar": "tdesign-miniprogram/calendar/calendar"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/VgWTzNmh8R5A)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

#### 单个选择日历

**WXML** (`html`):
```html
<wxs src="../calendar.wxs" module="_this" />

<t-calendar visible="{{visible}}" value="{{value}}" bind:confirm="handleConfirm" bind:close="onClose" />
<t-cell arrow title="单个选择日历" note="{{_this.formatTimestamp(value)}}" bind:tap="handleCalendar" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: false,
value: null,
},
methods: {
handleCalendar() {
this.setData({ visible: true });
},

handleConfirm(e) {
const { value } = e.detail;
console.log(value);
this.setData({
value,
});
},

onClose({ detail }) {
console.log(detail.trigger);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-calendar": "tdesign-miniprogram/calendar/calendar",
"t-cell": "tdesign-miniprogram/cell/cell"
}
}

```

#### 多个选择日历

**WXML** (`html`):
```html
<wxs src="../calendar.wxs" module="_this" />

<t-calendar visible="{{visible}}" value="{{value}}" type="multiple" bind:confirm="handleConfirm" />
<t-cell arrow title="多个选择日历" bind:tap="handleCalendar">
<view slot="note" class="custom-class-note"> {{_this.formatTimestamp(value)}} </view>
</t-cell>

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: false,
value: null,
},
methods: {
handleCalendar() {
this.setData({ visible: true });
},
handleConfirm(e) {
const { value } = e.detail;
this.setData({ value });
console.log(e.detail.value);
},
},
});

```

**CSS** (`css`):
```css
.custom-class-note {
width: 360rpx;
overflow: hidden;
text-overflow: ellipsis;
white-space: nowrap;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-calendar": "tdesign-miniprogram/calendar/calendar"
}
}

```

#### 带单行/双行描述的日历

**WXML** (`html`):
```html
<wxs src="../calendar.wxs" module="_this" />

<t-cell
arrow
title="带单行描述的日历"
note="{{_this.formatTimestamp(singleValue)}}"
data-type="single"
bind:tap="handleCalendar"
/>

<view class="demo-desc">带双行描述的日历</view>
<t-calendar
visible="{{visible}}"
value="{{type === 'single' ? singleValue : value}}"
minDate="{{minDate}}"
maxDate="{{maxDate}}"
format="{{type === 'single' ? singleFormat: format}}"
data-type="{{type}}"
bind:confirm="handleConfirm"
/>
<t-cell
arrow
title="带双行描述的日历"
note="{{_this.formatTimestamp(value)}}"
data-type="multiple"
bind:tap="handleCalendar"
/>

```

**JS** (`javascript`):
```javascript
Component({
data: {
type: 'single',
visible: false,
value: new Date(2022, 1, 18).getTime(),
singleValue: new Date(2022, 1, 18).getTime(),
minDate: new Date(2022, 1, 1).getTime(),
maxDate: new Date(2022, 2, 15).getTime(),
singleFormat(day) {
day.suffix = '¥60';
return day;
},
format(day) {
const { date } = day;
const year = date.getFullYear();
const month = date.getMonth() + 1;
const curDate = date.getDate();

day.suffix = '¥60';

if (year === 2022) {
if (month === 2) {
const map = {
1: '初一',
2: '初二',
3: '初三',
14: '情人节',
15: '元宵节',
};
if (curDate in map) {
day.prefix = map[curDate];
day.suffix = '¥100';
day.className = 'is-holiday';
}
}
}

return day;
},
},
methods: {
handleCalendar(e) {
const { type } = e.currentTarget.dataset;
this.setData({ type, visible: true });
},

handleConfirm(e) {
const { type } = e.currentTarget.dataset;
const { value } = e.detail;

if (type === 'single') {
this.setData({
singleValue: value,
});
} else {
this.setData({
value,
});
}
console.log(e.detail.value);
},
},
});

```

**CSS** (`css`):
```css
.demo-desc {
margin-top: 32rpx;
margin-bottom: 32rpx;
}

.is-holiday:not(.t-calendar__dates-item--selected) {
color: #e34d59 !important;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-calendar": "tdesign-miniprogram/calendar/calendar"
}
}

```

#### 带翻页功能的日历

**WXML** (`html`):
```html
<wxs src="../calendar.wxs" module="_this" />

<t-calendar
visible="{{visible}}"
value="{{value}}"
switch-mode="year-month"
minDate="{{minDate}}"
maxDate="{{maxDate}}"
bind:confirm="handleConfirm"
bind:panel-change="handlePanelChange"
/>
<t-cell arrow title="带翻页功能的日历" note="{{_this.formatTimestamp(value)}}" bind:tap="handleCalendar" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: false,
value: new Date(2022, 1, 27).getTime(),
minDate: new Date(2022, 0, 10).getTime(),
maxDate: new Date(2027, 10, 27).getTime(),
},

methods: {
handleCalendar() {
this.setData({ visible: true });
},

handleConfirm(e) {
this.setData({ value: e.detail.value });
console.log(e.detail.value);
},

handlePanelChange(e) {
const { year, month } = e.detail;
console.log('year: ', year, 'month: ', month);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-calendar": "tdesign-miniprogram/calendar/calendar"
}
}

```

#### 可选择区间日期的日历

**WXML** (`html`):
```html
<wxs src="../calendar.wxs" module="_this" />

<t-calendar
visible="{{visible}}"
value="{{value}}"
minDate="{{minDate}}"
maxDate="{{maxDate}}"
type="range"
bind:confirm="handleConfirm"
/>

<view class="wrapper" bind:tap="handleCalendar">
<view class="wrapper__left">{{_this.formatTimestamp(value[0])}}</view>
<t-icon class="wrapper__center" name="swap-right" size="40rpx" />
<view class="wrapper__right">{{_this.formatTimestamp(value[1])}}</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: false,
value: [new Date(2024, 11, 5).getTime(), new Date(2024, 11, 10).getTime()],
minDate: new Date(2024, 10, 1).getTime(),
maxDate: new Date(2024, 12, 1).getTime(),
},
methods: {
handleCalendar() {
this.setData({ visible: true });
},

handleConfirm(e) {
console.log(e.detail.value);
const { value } = e.detail;
this.setData({
value,
});
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
background-color: var(--td-bg-color-container);
padding: 32rpx;
box-sizing: border-box;
display: flex;
align-items: center;
justify-content: space-between;
}

.wrapper__center {
color: var(--td-text-color-placeholder);
}

.wrapper__left,
.wrapper__right {
width: 240rpx;
color: var(--td-text-color-primary);
font-size: 32rpx;
font-weight: 600;
line-height: 48rpx;
}

.wrapper__right {
text-align: right;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-icon": "tdesign-miniprogram/icon/icon",
"t-calendar": "tdesign-miniprogram/calendar/calendar"
}
}

```

### 组件样式

#### 国际化

**WXML** (`html`):
```html
<wxs src="../calendar.wxs" module="_this" />

<t-calendar
visible="{{visible}}"
value="{{value}}"
minDate="{{minDate}}"
maxDate="{{maxDate}}"
localeText="{{localeText}}"
bind:confirm="handleConfirm"
bind:close="onClose"
/>
<t-cell arrow title="国际化" note="{{_this.formatTimestamp(value)}}" bind:tap="handleCalendar" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: false,
value: new Date(2022, 1, 18).getTime(),
minDate: new Date(2022, 1, 1).getTime(),
maxDate: new Date(2022, 2, 15).getTime(),
localeText: {
title: 'Select Date',
weekdays: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
monthTitle: '{month} {year}',
confirm: 'Confirm',
months: [
'January',
'February',
'March',
'April',
'May',
'June',
'July',
'August',
'September',
'October',
'November',
'December',
],
},
},
methods: {
handleCalendar() {
this.setData({ visible: true });
},

handleConfirm(e) {
const { value } = e.detail;
this.setData({
value,
});
},

onClose({ detail }) {
console.log(detail.trigger);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-calendar": "tdesign-miniprogram/calendar/calendar",
"t-cell": "tdesign-miniprogram/cell/cell"
}
}

```

#### 含不可选的日历

**WXML** (`html`):
```html
<wxs src="../calendar.wxs" module="_this" />

<t-calendar
visible="{{visible}}"
value="{{value}}"
minDate="{{minDate}}"
maxDate="{{maxDate}}"
bind:confirm="handleConfirm"
/>
<t-cell arrow title="含不可选的日历" note="{{_this.formatTimestamp(value)}}" bind:tap="handleCalendar" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: false,
value: new Date(2022, 1, 18).getTime(),
minDate: new Date(2022, 1, 18).getTime(),
maxDate: new Date(2022, 2, 1).getTime(),
},
methods: {
handleCalendar() {
this.setData({ visible: true });
},

handleConfirm(e) {
const { value } = e.detail;
this.setData({ value });
console.log(value);
},
},
});

```

**CSS** (`css`):
```css
.is-holiday:not(.t-calendar__dates-item--selected) {
color: #e34d59 !important;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-calendar": "tdesign-miniprogram/calendar/calendar"
}
}

```

#### 不使用Popup

**WXML** (`html`):
```html
<t-calendar title="日历标题" use-popup="{{false}}" type="multiple" bind:select="handleSelect" />

```

**JS** (`javascript`):
```javascript
Component({
methods: {
handleSelect(e) {
const { value } = e.detail;

console.log(value);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-calendar": "tdesign-miniprogram/calendar/calendar"
}
}

```

## API

### CalendarProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| allow-same-day | Boolean | false | `1.11.2`。是否允许区间选择日历的起止时间相同，仅当`type='range'`时有效 | N |
| auto-close | Boolean | true | `0.34.0`。自动关闭；在点击关闭按钮、确认按钮、遮罩层时自动关闭，不需要手动设置 visible | N |
| confirm-btn | String / Object | '' | 确认按钮。值为 null 则不显示确认按钮。值类型为字符串，则表示自定义按钮文本，值类型为 Object 则表示透传 Button 组件属性。详细类型定义 | N |
| first-day-of-week | Number | 0 | 第一天从星期几开始，默认 0 = 周日 | N |
| format | Function | - | 用于格式化日期的函数。TS 类型：`CalendarFormatType ``type CalendarFormatType = (day: TDate) => TDate``type TDateType = 'selected' \| 'disabled' \| 'start' \| 'start-end' \|'centre' \| 'end' \| ''``interface TDate { date: Date; day: number; type: TDateType; className?: string; prefix?: string; suffix?: string;}`。详细类型定义 | N |
| locale-text | Object | - | 国际化文案。TS 类型：`CalendarLocaleText``interface CalendarLocaleText {title?: string; weekdays?: string[]; monthTitle?: string; months?: string[]; confirm?: string;}`。详细类型定义 | N |
| max-date | Number | - | 最大可选的日期，不传则默认半年后 | N |
| min-date | Number | - | 最小可选的日期，不传则默认今天 | N |
| readonly | Boolean | - | `1.9.7`。是否只读，只读状态下不能选择日期 | N |
| switch-mode | String | none | `1.8.2`。切换模式。`none`表示平铺展示所有月份；`month`表示支持按月切换，`year-month`表示既按年切换，也支持按月切换。可选项：none/month/year-month | N |
| title | String | - | 标题，不传默认为“请选择日期” | N |
| type | String | single | 日历的选择类型，single = 单选；multiple = 多选; range = 区间选择。可选项：single/multiple/range | N |
| use-popup | Boolean | true | `0.32.0`。是否使用弹出层包裹日历 | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| value | Number / Array | - | 当前选择的日期，不传则选用 minDate 属性值或今天，优先级：minDate > today。当 type = multiple 或 range 时传入数组。TS 类型：`number \| number[]` | N |
| default-value | Number / Array | undefined | 当前选择的日期，不传则选用 minDate 属性值或今天，优先级：minDate > today。当 type = multiple 或 range 时传入数组。非受控属性。TS 类型：`number \| number[]` | N |
| visible | Boolean | false | 是否显示日历；`usePopup`为 true 时有效 | N |

### CalendarEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: timestamp)` | `0.28.0`。不显示 confirm-btn 时，完成选择时触发（暂不支持 type = multiple） |
| close | `(trigger: CalendarTrigger)` | `0.34.0`。关闭按钮时触发。详细类型定义。<br>`type CalendarTrigger = 'close-btn' \| 'confirm-btn' \| 'overlay' \| 'auto-close'`<br> |
| confirm | `(value: timestamp)` | 点击确认按钮时触发 |
| panel-change | `(detail: { year: number, month: number })` | `1.8.4`。切换月或年时触发（switch-mode 不为 none 时有效） |
| scroll | `({scrollLeft, scrollTop, scrollHeight, scrollWidth, deltaX, deltaY})` | `1.4.6`。滚动时触发 |
| select | `(value: timestamp)` | `0.28.0`。点击日期时触发 |

### CalendarSlots

| 名称 | 描述 |
| --- | --- |
| confirm-btn | 确认按钮 |
| title | 标题 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-calendar-active-color | @brand-color | - |
| --td-calendar-bg-color | @bg-color-container | - |
| --td-calendar-days-color | @text-color-secondary | - |
| --td-calendar-item-centre-color | @brand-color-light | - |
| --td-calendar-item-disabled-color | @text-color-disabled | - |
| --td-calendar-item-suffix-color | @text-color-placeholder | - |
| --td-calendar-radius | 24rpx | - |
| --td-calendar-selected-border-radius | @radius-default | - |
| --td-calendar-selected-color | @text-color-anti | - |
| --td-calendar-switch-mode-icon-color | @text-color-secondary | - |
| --td-calendar-switch-mode-icon-disabled-color | @text-color-disabled | - |
| --td-calendar-title-color | @text-color-primary | - |
| --td-calendar-title-font | @font-title-large | - |

---

# [cascader]

# Cascader 级联选择器

## 示例

该组件于 0.23.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-cascader": "tdesign-miniprogram/cascader/cascader"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/WOWeTNmJ8X5B)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础用法

**WXML** (`html`):
```html
<t-cell title="地址" note="{{note}}" bind:click="showCascader" arrow />

<t-cascader
visible="{{visible}}"
value="{{value}}"
options="{{options}}"
title="请选择地址"
bind:change="onChange"
bind:pick="onPick"
/>

```

**JS** (`javascript`):
```javascript
const data = {
areaList: [
{
label: '北京市',
value: '110000',
children: [
{
value: '110100',
label: '北京市',
children: [
{ value: '110101', label: '东城区' },
{ value: '110102', label: '西城区' },
{ value: '110105', label: '朝阳区' },
{ value: '110106', label: '丰台区' },
{ value: '110107', label: '石景山区' },
{ value: '110108', label: '海淀区' },
{ value: '110109', label: '门头沟区' },
{ value: '110111', label: '房山区' },
{ value: '110112', label: '通州区' },
{ value: '110113', label: '顺义区' },
{ value: '110114', label: '昌平区' },
{ value: '110115', label: '大兴区' },
{ value: '110116', label: '怀柔区' },
{ value: '110117', label: '平谷区' },
{ value: '110118', label: '密云区' },
{ value: '110119', label: '延庆区' },
],
},
],
},
{
label: '天津市',
value: '120000',
children: [
{
value: '120100',
label: '天津市',
children: [
{ value: '120101', label: '和平区' },
{ value: '120102', label: '河东区' },
{ value: '120103', label: '河西区' },
{ value: '120104', label: '南开区' },
{ value: '120105', label: '河北区' },
{ value: '120106', label: '红桥区' },
{ value: '120110', label: '东丽区' },
{ value: '120111', label: '西青区' },
{ value: '120112', label: '津南区' },
{ value: '120113', label: '北辰区' },
{ value: '120114', label: '武清区' },
{ value: '120115', label: '宝坻区' },
{ value: '120116', label: '滨海新区' },
{ value: '120117', label: '宁河区' },
{ value: '120118', label: '静海区' },
{ value: '120119', label: '蓟州区' },
],
},
],
},
],
};

Component({
data: {
options: data.areaList,
note: '请选择地址',
visible: false,
value: '',
},
methods: {
showCascader() {
this.setData({ visible: true });
},
onPick(e) {
console.log(e.detail);
},
onChange(e) {
const { selectedOptions, value } = e.detail;

this.setData({
value,
note: selectedOptions.map((item) => item.label).join('/'),
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-cascader": "tdesign-miniprogram/cascader/cascader"
}
}

```

### 选项卡风格

**WXML** (`html`):
```html
<t-cell title="地址" note="{{note}}" bind:click="showCascader" arrow></t-cell>

<t-cascader
visible="{{visible}}"
theme="tab"
options="{{options}}"
title="请选择地址"
bind:change="onChange"
></t-cascader>

```

**JS** (`javascript`):
```javascript
const data = {
areaList: [
{
label: '北京市',
value: '110000',
children: [
{
value: '110100',
label: '北京市',
children: [
{ value: '110101', label: '东城区' },
{ value: '110102', label: '西城区' },
{ value: '110105', label: '朝阳区' },
{ value: '110106', label: '丰台区' },
{ value: '110107', label: '石景山区' },
{ value: '110108', label: '海淀区' },
{ value: '110109', label: '门头沟区' },
{ value: '110111', label: '房山区' },
{ value: '110112', label: '通州区' },
{ value: '110113', label: '顺义区' },
{ value: '110114', label: '昌平区' },
{ value: '110115', label: '大兴区' },
{ value: '110116', label: '怀柔区' },
{ value: '110117', label: '平谷区' },
{ value: '110118', label: '密云区' },
{ value: '110119', label: '延庆区' },
],
},
],
},
{
label: '天津市',
value: '120000',
children: [
{
value: '120100',
label: '天津市',
children: [
{ value: '120101', label: '和平区' },
{ value: '120102', label: '河东区' },
{ value: '120103', label: '河西区' },
{ value: '120104', label: '南开区' },
{ value: '120105', label: '河北区' },
{ value: '120106', label: '红桥区' },
{ value: '120110', label: '东丽区' },
{ value: '120111', label: '西青区' },
{ value: '120112', label: '津南区' },
{ value: '120113', label: '北辰区' },
{ value: '120114', label: '武清区' },
{ value: '120115', label: '宝坻区' },
{ value: '120116', label: '滨海新区' },
{ value: '120117', label: '宁河区' },
{ value: '120118', label: '静海区' },
{ value: '120119', label: '蓟州区' },
],
},
],
},
],
};

Component({
data: {
options: data.areaList,
note: '请选择地址',
visible: false,
},
methods: {
showCascader() {
this.setData({ visible: true });
},
onChange(e) {
const { selectedOptions } = e.detail;

this.setData({
note: selectedOptions.map((item) => item.label).join('/'),
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-cascader": "tdesign-miniprogram/cascader/cascader"
}
}

```

### 进阶

#### 带初始值

**WXML** (`html`):
```html
<t-cell title="地址" note="{{note}}" bind:click="showCascader" arrow></t-cell>

<t-cascader
visible="{{visible}}"
value="120119"
options="{{options}}"
title="请选择地址"
bind:change="onChange"
></t-cascader>

```

**JS** (`javascript`):
```javascript
const data = {
areaList: [
{
label: '北京市',
value: '110000',
children: [
{
value: '110100',
label: '北京市',
children: [
{ value: '110101', label: '东城区' },
{ value: '110102', label: '西城区' },
{ value: '110105', label: '朝阳区' },
{ value: '110106', label: '丰台区' },
{ value: '110107', label: '石景山区' },
{ value: '110108', label: '海淀区' },
{ value: '110109', label: '门头沟区' },
{ value: '110111', label: '房山区' },
{ value: '110112', label: '通州区' },
{ value: '110113', label: '顺义区' },
{ value: '110114', label: '昌平区' },
{ value: '110115', label: '大兴区' },
{ value: '110116', label: '怀柔区' },
{ value: '110117', label: '平谷区' },
{ value: '110118', label: '密云区' },
{ value: '110119', label: '延庆区' },
],
},
],
},
{
label: '天津市',
value: '120000',
children: [
{
value: '120100',
label: '天津市',
children: [
{ value: '120101', label: '和平区' },
{ value: '120102', label: '河东区' },
{ value: '120103', label: '河西区' },
{ value: '120104', label: '南开区' },
{ value: '120105', label: '河北区' },
{ value: '120106', label: '红桥区' },
{ value: '120110', label: '东丽区' },
{ value: '120111', label: '西青区' },
{ value: '120112', label: '津南区' },
{ value: '120113', label: '北辰区' },
{ value: '120114', label: '武清区' },
{ value: '120115', label: '宝坻区' },
{ value: '120116', label: '滨海新区' },
{ value: '120117', label: '宁河区' },
{ value: '120118', label: '静海区' },
{ value: '120119', label: '蓟州区' },
],
},
],
},
],
};

Component({
data: {
options: data.areaList,
note: '请选择地址',
visible: false,
},
methods: {
showCascader() {
this.setData({ visible: true });
},
onChange(e) {
const { selectedOptions } = e.detail;

this.setData({
note: selectedOptions.map((item) => item.label).join('/'),
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-cascader": "tdesign-miniprogram/cascader/cascader"
}
}

```

#### 自定义keys

**WXML** (`html`):
```html
<t-cell title="地址" note="{{note}}" bind:click="showCascader" arrow></t-cell>

<t-cascader
class="demo"
visible="{{visible}}"
keys="{{keys}}"
options="{{options}}"
title="请选择地址"
placeholder="未选中时的提示文案"
bind:change="onChange"
></t-cascader>

```

**JS** (`javascript`):
```javascript
const data = {
areaList: [
{
name: '北京市',
id: '110000',
sub: [
{
id: '110100',
name: '北京市',
sub: [
{ id: '110101', name: '东城区' },
{ id: '110102', name: '西城区' },
{ id: '110105', name: '朝阳区' },
{ id: '110106', name: '丰台区' },
{ id: '110107', name: '石景山区' },
{ id: '110108', name: '海淀区' },
{ id: '110109', name: '门头沟区' },
{ id: '110111', name: '房山区' },
{ id: '110112', name: '通州区' },
{ id: '110113', name: '顺义区' },
{ id: '110114', name: '昌平区' },
{ id: '110115', name: '大兴区' },
{ id: '110116', name: '怀柔区' },
{ id: '110117', name: '平谷区' },
{ id: '110118', name: '密云区' },
{ id: '110119', name: '延庆区' },
],
},
],
},
{
name: '天津市',
id: '120000',
sub: [
{
id: '120100',
name: '天津市',
sub: [
{ id: '120101', name: '和平区' },
{ id: '120102', name: '河东区' },
{ id: '120103', name: '河西区' },
{ id: '120104', name: '南开区' },
{ id: '120105', name: '河北区' },
{ id: '120106', name: '红桥区' },
{ id: '120110', name: '东丽区' },
{ id: '120111', name: '西青区' },
{ id: '120112', name: '津南区' },
{ id: '120113', name: '北辰区' },
{ id: '120114', name: '武清区' },
{ id: '120115', name: '宝坻区' },
{ id: '120116', name: '滨海新区' },
{ id: '120117', name: '宁河区' },
{ id: '120118', name: '静海区' },
{ id: '120119', name: '蓟州区' },
],
},
],
},
],
};

Component({
data: {
options: data.areaList,
note: '请选择地址',
visible: false,
keys: {
label: 'name',
value: 'id',
children: 'sub',
},
},
methods: {
showCascader() {
this.setData({ visible: true });
},
onChange(e) {
const { selectedOptions } = e.detail;

this.setData({
note: selectedOptions.map((item) => item.name).join('/'),
});
},
},
});

```

**CSS** (`css`):
```css
page .demo {
--td-cascader-active-color: green;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-cascader": "tdesign-miniprogram/cascader/cascader"
}
}

```

#### 使用次级标题

**WXML** (`html`):
```html
<t-cell title="地址" note="{{note}}" bind:click="showCascader" arrow></t-cell>

<t-cascader
visible="{{visible}}"
options="{{options}}"
title="请选择地址"
sub-titles="{{subTitles}}"
bind:change="onChange"
></t-cascader>

```

**JS** (`javascript`):
```javascript
const data = {
areaList: [
{
label: '北京市',
value: '110000',
children: [
{
value: '110100',
label: '北京市',
children: [
{ value: '110101', label: '东城区' },
{ value: '110102', label: '西城区' },
{ value: '110105', label: '朝阳区' },
{ value: '110106', label: '丰台区' },
{ value: '110107', label: '石景山区' },
{ value: '110108', label: '海淀区' },
{ value: '110109', label: '门头沟区' },
{ value: '110111', label: '房山区' },
{ value: '110112', label: '通州区' },
{ value: '110113', label: '顺义区' },
{ value: '110114', label: '昌平区' },
{ value: '110115', label: '大兴区' },
{ value: '110116', label: '怀柔区' },
{ value: '110117', label: '平谷区' },
{ value: '110118', label: '密云区' },
{ value: '110119', label: '延庆区' },
],
},
],
},
{
label: '天津市',
value: '120000',
children: [
{
value: '120100',
label: '天津市',
children: [
{ value: '120101', label: '和平区' },
{ value: '120102', label: '河东区' },
{ value: '120103', label: '河西区' },
{ value: '120104', label: '南开区' },
{ value: '120105', label: '河北区' },
{ value: '120106', label: '红桥区' },
{ value: '120110', label: '东丽区' },
{ value: '120111', label: '西青区' },
{ value: '120112', label: '津南区' },
{ value: '120113', label: '北辰区' },
{ value: '120114', label: '武清区' },
{ value: '120115', label: '宝坻区' },
{ value: '120116', label: '滨海新区' },
{ value: '120117', label: '宁河区' },
{ value: '120118', label: '静海区' },
{ value: '120119', label: '蓟州区' },
],
},
],
},
],
};

Component({
data: {
options: data.areaList,
note: '请选择地址',
visible: false,
subTitles: ['请选择省份', '请选择城市', '请选择区/县'],
},
methods: {
showCascader() {
this.setData({ visible: true });
},
onChange(e) {
const { selectedOptions } = e.detail;

this.setData({
note: selectedOptions.map((item) => item.label).join('/'),
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-cascader": "tdesign-miniprogram/cascader/cascader"
}
}

```

#### 选择任意一项

**WXML** (`html`):
```html
<t-cell title="地址" note="{{note}}" bind:click="showCascader" arrow />

<t-cascader
close-btn="{{false}}"
check-strictly="{{true}}"
visible="{{visible}}"
value="{{value}}"
options="{{options}}"
title="请选择地址"
bind:change="onChange"
bind:pick="onPick"
>
<text class="confirm-btn" slot="close-btn">确定</text>
</t-cascader>

```

**JS** (`javascript`):
```javascript
const data = {
areaList: [
{
label: '北京市',
value: '110000',
children: [
{
value: '110100',
label: '北京市',
children: [
{ value: '110101', label: '东城区' },
{ value: '110102', label: '西城区' },
{ value: '110105', label: '朝阳区' },
{ value: '110106', label: '丰台区' },
{ value: '110107', label: '石景山区' },
{ value: '110108', label: '海淀区' },
{ value: '110109', label: '门头沟区' },
{ value: '110111', label: '房山区' },
{ value: '110112', label: '通州区' },
{ value: '110113', label: '顺义区' },
{ value: '110114', label: '昌平区' },
{ value: '110115', label: '大兴区' },
{ value: '110116', label: '怀柔区' },
{ value: '110117', label: '平谷区' },
{ value: '110118', label: '密云区' },
{ value: '110119', label: '延庆区' },
],
},
],
},
{
label: '天津市',
value: '120000',
children: [
{
value: '120100',
label: '天津市',
children: [
{ value: '120101', label: '和平区' },
{ value: '120102', label: '河东区' },
{ value: '120103', label: '河西区' },
{ value: '120104', label: '南开区' },
{ value: '120105', label: '河北区' },
{ value: '120106', label: '红桥区' },
{ value: '120110', label: '东丽区' },
{ value: '120111', label: '西青区' },
{ value: '120112', label: '津南区' },
{ value: '120113', label: '北辰区' },
{ value: '120114', label: '武清区' },
{ value: '120115', label: '宝坻区' },
{ value: '120116', label: '滨海新区' },
{ value: '120117', label: '宁河区' },
{ value: '120118', label: '静海区' },
{ value: '120119', label: '蓟州区' },
],
},
],
},
],
};

Component({
data: {
options: data.areaList,
note: '请选择地址',
visible: false,
value: '',
},
methods: {
showCascader() {
this.setData({ visible: true });
},
onPick(e) {
console.log(e.detail);
},
onChange(e) {
const { selectedOptions, value } = e.detail;
console.log(value);
this.setData({
value,
note: selectedOptions.map((item) => item.label).join('/'),
});
},
},
});

```

**CSS** (`css`):
```css
.confirm-btn {
color: #0052d9;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-cascader": "tdesign-miniprogram/cascader/cascader"
}
}

```

## API

### CascaderProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| check-strictly | Boolean | false | 父子节点选中状态不再关联，可各自选中或取消 | N |
| close-btn | Boolean | true | 关闭按钮 | N |
| keys | Object | - | 用来定义 value / label / children / disabled 在`options`中对应的字段别名。TS 类型：`CascaderKeysType``type CascaderKeysType = TreeKeysType`。通用类型定义。详细类型定义 | N |
| options | Array | [] | 可选项数据源。TS 类型：`Array<CascaderOption>` | N |
| placeholder | String | 选择选项 | 未选中时的提示文案 | N |
| sub-titles | Array | [] | 每级展示的次标题。TS 类型：`Array<string>` | N |
| theme | String | step | 展示风格。可选项：step/tab | N |
| title | String | - | 标题 | N |
| value | String / Number | null | 选项值 | N |
| default-value | String / Number | undefined | 选项值。非受控属性 | N |
| visible | Boolean | false | 是否展示 | N |

### CascaderEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: string \| number, selectedOptions: string[])` | `1.0.1`。值发生变更时触发 |
| close | `(trigger: CascaderTriggerSource)` | `1.0.1`。关闭时触发。详细类型定义。<br>`type CascaderTriggerSource = 'overlay' \| 'close-btn' \| 'finish'`<br> |
| pick | `(value: string \| number, label: string, index: number, level: number)` | `1.0.1`。选择后触发 |

### CascaderSlots

| 名称 | 描述 |
| --- | --- |
| close-btn | 自定义`close-btn`显示内容 |
| header | `1.9.1`。头部 |
| middle-content | 中间内容 |
| title | 自定义`title`显示内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-cascader-active-color | @brand-color | - |
| --td-cascader-bg-color | @bg-color-container | - |
| --td-cascader-border-color | @component-stroke | - |
| --td-cascader-content-height | 78vh | - |
| --td-cascader-disabled-color | @text-color-disabled | - |
| --td-cascader-options-height | calc(100% - @cascader-step-height) | - |
| --td-cascader-options-title-color | @text-color-placeholder | - |
| --td-cascader-step-arrow-color | @text-color-placeholder | - |
| --td-cascader-step-dot-size | 16rpx | - |
| --td-cascader-step-height | 88rpx | - |
| --td-cascader-title-color | @text-color-primary | - |
| --td-cascader-title-font | @font-title-large | - |
| --td-cascader-title-padding | @spacer-2 | - |

---

# [cell]

# Cell 单元格

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-cell-group": "tdesign-miniprogram/cell-group/cell-group"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/M8XBNNmG855M)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 类型

单行单元格

**WXML** (`html`):
```html
<t-cell title="单行标题" hover arrow />
<t-cell title="单行标题" hover required arrow />
<t-cell title="单行标题" hover arrow ariaLabel="单行标题，有16条消息">
<t-badge count="{{16}}" slot="note" />
</t-cell>
<t-cell title="单行标题" hover>
<t-switch defaultValue="{{true}}" slot="note" />
</t-cell>
<t-cell title="单行标题" hover note="辅助信息" arrow />
<t-cell title="单行标题" hover arrow leftIcon="app" bordered="{{false}}" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-badge": "tdesign-miniprogram/badge/badge",
"t-switch": "tdesign-miniprogram/switch/switch",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

多行单元格

**WXML** (`html`):
```html
<t-cell title="单行标题" description="一段很长很长的内容文字" hover arrow />
<t-cell title="单行标题" description="一段很长很长的内容文字" hover arrow required />
<t-cell title="单行标题" description="一段很长很长的内容文字" hover arrow>
<t-badge count="{{16}}" slot="note" />
</t-cell>
<t-cell title="单行标题" description="一段很长很长的内容文字" hover>
<t-switch defaultValue="{{true}}" slot="note" />
</t-cell>
<t-cell title="单行标题" description="一段很长很长的内容文字" note="辅助信息" hover arrow />
<t-cell title="单行标题" description="一段很长很长的内容文字" leftIcon="app" hover arrow />
<t-cell title="单行标题" description="一段很长很长的内容文字，长文本自动换行，该选项的描述是一段很长的内容" hover />
<t-cell title="单行标题" description="一段很长很长很长的内容文字" hover arrow>
<view class="avatar" slot="left-icon">
<open-data type="userAvatarUrl" />
</view>
</t-cell>
<t-cell
title="单行标题"
description="一段很长很长的内容文字"
align="top"
image="https://tdesign.gtimg.com/mobile/demos/avatar1.png"
hover
bordered="{{false}}"
/>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.avatar {
width: 96rpx;
height: 96rpx;
border-radius: 50%;
overflow: hidden;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-icon": "tdesign-miniprogram/icon/icon",
"t-switch": "tdesign-miniprogram/switch/switch"
}
}

```

### 样式

卡片单元格

**WXML** (`html`):
```html
<t-cell-group theme="card">
<t-cell title="单行标题" leftIcon="service" hover arrow />
<t-cell title="单行标题" leftIcon="internet" hover arrow />
<t-cell title="单行标题" leftIcon="lock-on" hover arrow />
</t-cell-group>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell-group": "tdesign-miniprogram/cell-group/cell-group",
"t-cell": "tdesign-miniprogram/cell/cell",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

## API

### CellProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| align | String | middle | 右侧内容的对齐方式，默认居中对齐。可选项：top/middle/bottom | N |
| arrow | Boolean / Object | false | 是否显示右侧箭头 | N |
| bordered | Boolean | true | 是否显示下边框 | N |
| description | String | - | 下方内容描述 | N |
| hover | Boolean | - | 是否开启点击反馈 | N |
| image | String | - | 主图 | N |
| jump-type | String | navigateTo | 链接跳转类型。可选项：switchTab/reLaunch/redirectTo/navigateTo | N |
| left-icon | String / Object | - | 左侧图标，出现在单元格标题的左侧 | N |
| note | String | - | 和标题同行的说明文字 | N |
| required | Boolean | false | 是否显示表单必填星号 | N |
| right-icon | String / Object | - | 最右侧图标 | N |
| title | String | - | 标题 | N |
| url | String | - | 点击后跳转链接地址。如果值为空，则表示不需要跳转 | N |

### CellEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| click | - | 右侧内容 |

### CellSlots

| 名称 | 描述 |
| --- | --- |
| description | 自定义`description`显示内容 |
| image | 自定义`image`显示内容 |
| left-icon | 自定义`left-icon`显示内容 |
| note | 自定义`note`显示内容 |
| right-icon | 自定义`right-icon`显示内容 |
| title | 自定义`title`显示内容 |

### CellExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-center | 中间（`title`,`description`）内容样式类 |
| t-class-description | 下方描述内容样式类 |
| t-class-hover | 悬停样式类 |
| t-class-image | 图片样式类 |
| t-class-left | 左侧内容样式类 |
| t-class-left-icon | 左侧图标样式类 |
| t-class-note | 右侧说明文字样式类 |
| t-class-right | 右侧内容样式类 |
| t-class-right-icon | 右侧图标样式类 |
| t-class-title | 标题样式类 |

### CellGroupProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| bordered | Boolean | false | 是否显示组边框 | N |
| theme | String | default | 单元格组风格。可选项：default/card | N |
| title | String | - | 单元格组标题 | N |

### CellGroupSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### CellGroupExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-title | 标题样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-cell-group-border-color | @component-stroke | - |
| --td-cell-group-title-bg-color | @bg-color-secondarycontainer | - |
| --td-cell-group-title-color | @text-color-placeholder | - |
| --td-cell-group-title-font-size | 28rpx | - |
| --td-cell-group-title-line-height | 90rpx | - |
| --td-cell-group-title-padding-left | 32rpx | - |
| --td-cell-bg-color | @bg-color-container | - |
| --td-cell-border-color | @component-stroke | - |
| --td-cell-border-left-space | @cell-horizontal-padding | - |
| --td-cell-border-right-space | 0 | - |
| --td-cell-border-width | 1px | - |
| --td-cell-description-color | @text-color-secondary | - |
| --td-cell-description-font | @font-body-medium | - |
| --td-cell-height | auto | - |
| --td-cell-horizontal-padding | 32rpx | - |
| --td-cell-hover-color | @bg-color-secondarycontainer | - |
| --td-cell-image-height | 96rpx | - |
| --td-cell-image-width | 96rpx | - |
| --td-cell-left-icon-color | @brand-color | - |
| --td-cell-left-icon-size | 48rpx | - |
| --td-cell-note-color | @text-color-placeholder | - |
| --td-cell-note-font-size | @font-size-m | - |
| --td-cell-required-color | @error-color | - |
| --td-cell-required-font-size | @font-size-m | - |
| --td-cell-right-icon-color | @text-color-placeholder | - |
| --td-cell-right-icon-size | 48rpx | - |
| --td-cell-title-color | @text-color-primary | - |
| --td-cell-title-font | @font-body-large | - |
| --td-cell-vertical-padding | 32rpx | - |

---

# [checkbox]

# Checkbox 多选框

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-checkbox": "tdesign-miniprogram/checkbox/checkbox",
"t-checkbox-group": "tdesign-miniprogram/checkbox-group/checkbox-group"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/I0XgVNml8E5I)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

纵向多选框

**WXML** (`html`):
```html
<t-checkbox-group value="{{current}}" bind:change="handleGroupChange" options="{{options}}" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
current: ['checkbox1', 'checkbox2'],
options: [
{ label: '多选', value: 'checkbox1' },
{ label: '多选', value: 'checkbox2' },
{
label: '多选标题多行多选标题多行多选标题多行多选标题多行多选标题多行多选标题多行',
value: 'checkbox3',
maxLabelRow: 2,
},
{
label: '多选',
value: 'checkbox4',
content: '描述信息描述信息描述信息描述信息描述信息描述信息描述信息描述信息描述信息描述信息',
maxContentRow: 2,
},
],
},

methods: {
handleGroupChange(event) {
console.log('group', event.detail.value);
this.setData({
current: event.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-checkbox-group": "tdesign-miniprogram/checkbox-group/checkbox-group",
"t-checkbox": "tdesign-miniprogram/checkbox/checkbox"
}
}

```

横向多选框

**WXML** (`html`):
```html
<t-checkbox-group t-class="box" borderless bind:change="onChange" defaultValue="{{demoCheckboxMax}}">
<t-checkbox block="{{false}}" value="checkbox1" label="多选标题" />
<t-checkbox block="{{false}}" value="checkbox2" label="多选标题" />
<t-checkbox block="{{false}}" value="checkbox3" label="上限四字" />
</t-checkbox-group>

```

**JS** (`javascript`):
```javascript
Component({
/**
* 组件的初始数据
*/
data: {
demoCheckboxMax: ['checkbox1', 'checkbox2'],
},

/**
* 组件的方法列表
*/
methods: {
onChange(event) {
console.log('checkbox', event.detail.value);
},
},
});

```

**CSS** (`css`):
```css
.box {
padding: 32rpx;
display: flex;
justify-content: space-between;
flex-wrap: wrap;
background-color: var(--td-bg-color-container, #fff);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-checkbox-group": "tdesign-miniprogram/checkbox-group/checkbox-group",
"t-checkbox": "tdesign-miniprogram/checkbox/checkbox"
}
}

```

带全选多选框

**WXML** (`html`):
```html
<t-checkbox-group
options="{{options}}"
defaultValue="{{checkAllValues}}"
bind:change="onCheckAllChange"
></t-checkbox-group>

```

**JS** (`javascript`):
```javascript
Component({
data: {
options: [
{ label: '全选', checkAll: true },
{ label: '多选', value: 1 },
{ label: '多选', value: 2 },
{
label: '多选',
value: 3,
content: '单选描述信息单选描述信息单选描述信息单选描述信息单选描述信息单选描述信息单选描述信息',
},
],
checkAllValues: [1, 2, 3, ''],
},

methods: {
onCheckAllChange(event) {
console.log('checkbox', event.detail.value);
this.setData({
checkAllValues: event.detail,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-checkbox-group": "tdesign-miniprogram/checkbox-group/checkbox-group"
}
}

```

### 组件状态

多选框状态

**WXML** (`html`):
```html
<t-checkbox-group defaultValue="{{['checkbox1']}}" disabled>
<t-checkbox value="checkbox1" label="选项禁用-已选" />
<t-checkbox value="checkbox2" label="选项禁用-默认" />
</t-checkbox-group>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-checkbox-group": "tdesign-miniprogram/checkbox-group/checkbox-group",
"t-checkbox": "tdesign-miniprogram/checkbox/checkbox"
}
}

```

### 组件样式

勾选样式

**WXML** (`html`):
```html
<t-checkbox label="多选" icon="line" default-checked />

<view class="box" style="height: 32rpx"></view>

<t-checkbox label="多选" icon="rectangle" default-checked />

<view class="box" style="height: 32rpx"></view>

<t-checkbox value="checkbox1" label="图片图标" icon="{{[activeImage,inActiveImage]}}" />

```

**JS** (`javascript`):
```javascript
Component({
/**
* 组件的初始数据
*/
data: {
demoCheckbox2: ['checkbox2', 'checkbox3'],
activeImage: 'https://tdesign.gtimg.com/mobile/demos/checkbox-checked.png',
inActiveImage: 'https://tdesign.gtimg.com/mobile/demos/checkbox.png',
},

/**
* 组件的方法列表
*/
methods: {
onChange(event) {
console.log('checkbox', event.detail.value);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-checkbox-group": "tdesign-miniprogram/checkbox-group/checkbox-group",
"t-checkbox": "tdesign-miniprogram/checkbox/checkbox"
}
}

```

勾选显示位置

**WXML** (`html`):
```html
<t-checkbox value="1" label="多选" default-checked />

<view class="box" style="height: 32rpx" />

<t-checkbox value="2" label="多选" placement="right" default-checked />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-checkbox-group": "tdesign-miniprogram/checkbox-group/checkbox-group",
"t-checkbox": "tdesign-miniprogram/checkbox/checkbox"
}
}

```

非通栏多选样式

**WXML** (`html`):
```html
<t-checkbox-group t-class="theme-card" default-value="{{['1', '2']}}">
<t-checkbox value="1" label="多选" />
<t-checkbox value="2" label="多选" />
<t-checkbox value="3" label="多选标题多行多选标题多行多选标题多行多选标题多行多选标题多行多选标题" />
</t-checkbox-group>

```

**JS** (`javascript`):
```javascript
Component({
/**
* 组件的初始数据
*/
data: {
checked: true,
},

/**
* 组件的方法列表
*/
methods: {
changeChecked(e) {
this.setData({
checked: e.detail.checked,
});
},
},
});

```

**CSS** (`css`):
```css
.theme-card {
border-radius: 24rpx;
margin: 32rpx;
overflow: hidden;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-checkbox-group": "tdesign-miniprogram/checkbox-group/checkbox-group",
"t-checkbox": "tdesign-miniprogram/checkbox/checkbox"
}
}

```

### 组件规格

多选框尺寸规格

**WXML** (`html`):
```html
<wxs module="_"> module.exports.contain = function(arr, key) { return arr.indexOf(key) > -1 } </wxs>

<t-checkbox-group value="{{value}}" bind:change="onChange">
<view wx:for="{{3}}" wx:key="index" class="card {{_.contain(value, index) ? 'card--active' : ''}}">
<t-icon wx:if="{{_.contain(value, index)}}" name="check" t-class="card__icon" ariaHidden="{{true}}" />
<t-checkbox
value="{{index}}"
label="多选"
content="描述信息描述信息描述信息描述信息描述信息"
icon="none"
borderless
/>
</view>
</t-checkbox-group>

<view class="demo-desc" style="margin: 48rpx 32rpx 32rpx">横向卡片多选框</view>

<t-checkbox-group t-class="horizontal-box" value="{{value1}}" bind:change="onChange1">
<view wx:for="{{3}}" wx:key="index" class="card {{_.contain(value1, index) ? 'card--active' : ''}}">
<t-icon wx:if="{{_.contain(value1, index)}}" name="check" t-class="card__icon" ariaHidden="{{true}}" />
<t-checkbox value="{{index}}" label="多选" icon="none" borderless />
</view>
</t-checkbox-group>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: [0, 1],
value1: [0, 1],
},
methods: {
onChange(e) {
this.setData({ value: e.detail.value });
},
onChange1(e) {
this.setData({ value1: e.detail.value });
},
},
});

```

**CSS** (`css`):
```css
.card {
position: relative;
margin: 32rpx;
border-radius: 12rpx;
overflow: hidden;
box-sizing: border-box;
border: 3rpx solid var(--td-bg-color-container, #fff);
}

.card--active {
border-color: var(--td-brand-color, #0052d9);
}

.card--active::after {
content: '';
display: block;
position: absolute;
left: 0;
top: 0;
width: 0;
height: 0;
border-width: 28px 28px 28px 0;
border-style: solid;
border-color: #0052d9 transparent transparent transparent;
border: 14px solid var(--td-brand-color, #0052d9);
border-bottom-color: transparent;
border-right-color: transparent;
}

.card__icon {
color: var(--td-bg-color-container, #fff);
position: absolute;
left: 1.5px;
top: 1.5px;
z-index: 1;
}

/* 横向布局 */
.horizontal-box {
display: flex;
align-items: center;
justify-content: space-between;
flex-wrap: wrap;
margin: 32rpx;
}

.horizontal-box .card {
flex: 0 0 calc(33.33% - 12rpx);
margin: 0 0 24rpx 0;
}

.horizontal-box .card::after {
border-width: 48rpx 48rpx 48rpx 0;
}

.horizontal-box .card__icon {
font-size: 24rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-checkbox-group": "tdesign-miniprogram/checkbox-group/checkbox-group",
"t-checkbox": "tdesign-miniprogram/checkbox/checkbox",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

## API

### CheckboxProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| block | Boolean | true | 是否为块级元素 | N |
| borderless | Boolean | undefined | 是否开启无边框模式 | N |
| check-all | Boolean | false | 用于标识是否为「全选选项」。单独使用无效，需在 CheckboxGroup 中使用 | N |
| checked | Boolean | false | 是否选中 | N |
| default-checked | Boolean | undefined | 是否选中。非受控属性 | N |
| content | String | - | 多选框内容 | N |
| content-disabled | Boolean | - | 是否禁用组件内容（content）触发选中 | N |
| disabled | Boolean | undefined | 是否禁用组件。如果父组件存在 CheckboxGroup，默认值由 CheckboxGroup.disabled 控制。优先级：Checkbox.disabled > CheckboxGroup.disabled > Form.disabled | N |
| icon | String / Array | 'circle' | 自定义选中图标和非选中图标。使用 Array 时表示：`[选中态图标，非选中态图标，半选中态图标]`。使用 String 时，值为 circle 表示填充圆形图标、值为 line 表示描边型图标、值为 rectangle 表示填充矩形图标。TS 类型：`'circle' \| 'line' \| 'rectangle' \| string[]` | N |
| indeterminate | Boolean | false | 是否为半选 | N |
| label | String | - | 主文案 | N |
| max-content-row | Number | 5 | 内容最大行数限制 | N |
| max-label-row | Number | 3 | 主文案最大行数限制 | N |
| name | String | - | HTML 元素原生属性 | N |
| placement | String | left | 多选框和内容相对位置。可选项：left/right | N |
| readonly | Boolean | undefined | 只读状态 | N |
| value | String / Number / Boolean | - | 多选框的值。TS 类型：`string \| number \| boolean` | N |

### CheckboxEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(checked: boolean, context: { value: boolean\|number\|string, label: boolean\|number\|string })` | 值变化时触发。`context`表示当前点击项内容 |

### CheckboxSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，主文案 |
| content | 自定义`content`显示内容 |
| label | 自定义`label`显示内容 |

### CheckboxExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-border | 边框样式类 |
| t-class-content | 内容样式类 |
| t-class-icon | 图标样式类 |
| t-class-label | 标签样式类 |

### CheckboxGroupProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| borderless | Boolean | false | 是否开启无边框模式。优先级低于 Checkbox.borderless | N |
| disabled | Boolean | undefined | 是否禁用组件。优先级：Form.disabled < CheckboxGroup.disabled < Checkbox.disabled | N |
| keys | Object | - | 用来定义 value / label / disabled 在`options`中对应的字段别名。TS 类型：`KeysType`。通用类型定义 | N |
| max | Number | undefined | 支持最多选中的数量 | N |
| name | String | - | 统一设置内部复选框 HTML 属性 | N |
| options | Array | [] | 以配置形式设置子元素。示例1：`['北京', '上海']`，示例2:`[{ label: '全选', checkAll: true }, { label: '上海', value: 'shanghai' }]`。checkAll 值为 true 表示当前选项为「全选选项」。TS 类型：`Array<CheckboxOption>``type CheckboxOption = string \| number \| CheckboxOptionObj``interface CheckboxOptionObj { label?: string; value?: string \| number; disabled?: boolean; checkAll?: true }`。详细类型定义 | N |
| readonly | Boolean | undefined | 只读状态 | N |
| value | Array | [] | 选中值。TS 类型：`T``type CheckboxGroupValue = Array<string \| number \| boolean>`。详细类型定义 | N |
| default-value | Array | undefined | 选中值。非受控属性。TS 类型：`T``type CheckboxGroupValue = Array<string \| number \| boolean>`。详细类型定义 | N |

### CheckboxGroupEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: CheckboxGroupValue, context: { value: boolean\|number\|string, label: boolean\|number\|string })` | 值变化时触发。`context`表示当前点击项内容 |

### CheckboxGroupSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，多选框组内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-checkbox-bg-color | @bg-color-container | - |
| --td-checkbox-border-color | @component-stroke | - |
| --td-checkbox-description-color | @text-color-secondary | - |
| --td-checkbox-description-disabled-color | @text-color-disabled | - |
| --td-checkbox-description-font | @font-body-medium | - |
| --td-checkbox-icon-checked-color | @brand-color | - |
| --td-checkbox-icon-color | @component-border | - |
| --td-checkbox-icon-disabled-bg-color | @bg-color-component-disabled | - |
| --td-checkbox-icon-disabled-color | @brand-color-disabled | - |
| --td-checkbox-icon-size | 48rpx | - |
| --td-checkbox-tag-active-bg-color | @brand-color-light | - |
| --td-checkbox-tag-active-color | @brand-color | - |
| --td-checkbox-title-color | @text-color-primary | - |
| --td-checkbox-title-disabled-color | @text-color-disabled | - |
| --td-checkbox-title-font | @font-body-large | - |
| --td-checkbox-title-line-height | 48rpx | - |
| --td-checkbox-vertical-padding | @spacer-2 | - |

---

# [collapse]

# Collapse 折叠面板

## 示例

该组件于 0.7.3 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-collapse": "tdesign-miniprogram/collapse/collapse",
"t-collapse-panel": "tdesign-miniprogram/collapse-panel/collapse-panel"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/d6Xg3Nmp8W5B)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 类型

基础折叠面板

**WXML** (`html`):
```html
<view class="wrapper">
<t-collapse value="{{activeValues}}" bind:change="handleChange">
<t-collapse-panel header="折叠面板标题" value="{{0}}" expandIcon>
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
</t-collapse>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
activeValues: [0],
},
methods: {
handleChange(e) {
this.setData({
activeValues: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-collapse": "tdesign-miniprogram/collapse/collapse",
"t-collapse-panel": "tdesign-miniprogram/collapse-panel/collapse-panel"
}
}

```

带操作说明

**WXML** (`html`):
```html
<wxs module="_"> module.exports.contains = function(arr, target) { return arr.indexOf(target) > -1; } </wxs>
<view class="wrapper">
<t-collapse value="{{activeValues}}" bind:change="handleChange">
<t-collapse-panel
header="折叠面板标题"
header-right-content="{{_.contains(activeValues, 0) ? '收起' : '展开'}}"
value="{{0}}"
expandIcon
>
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
</t-collapse>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
activeValues: [0],
},
methods: {
handleChange(e) {
this.setData({
activeValues: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-collapse": "tdesign-miniprogram/collapse/collapse",
"t-collapse-panel": "tdesign-miniprogram/collapse-panel/collapse-panel"
}
}

```

手风琴模式

**WXML** (`html`):
```html
<t-collapse defaultValue="{{[0]}}" expandMutex expandIcon>
<t-collapse-panel header="折叠面板标题" value="{{0}}">
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
<t-collapse-panel header="折叠面板标题" value="{{1}}">
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
<t-collapse-panel header="折叠面板标题" value="{{2}}">
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
<t-collapse-panel header="折叠面板标题" disabled value="{{3}}">
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
</t-collapse>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-collapse": "tdesign-miniprogram/collapse/collapse",
"t-collapse-panel": "tdesign-miniprogram/collapse-panel/collapse-panel"
}
}

```

### 样式

卡片折叠面板

**WXML** (`html`):
```html
<t-collapse theme="card" defaultValue="{{[3]}}" expandIcon>
<t-collapse-panel header="折叠面板标题" value="{{0}}">
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
<t-collapse-panel header="折叠面板标题" value="{{1}}">
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
<t-collapse-panel header="折叠面板标题" value="{{2}}">
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
<t-collapse-panel header="折叠面板标题" disabled value="{{3}}">
此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容此处可自定义内容
</t-collapse-panel>
</t-collapse>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-collapse": "tdesign-miniprogram/collapse/collapse",
"t-collapse-panel": "tdesign-miniprogram/collapse-panel/collapse-panel"
}
}

```

## API

### CollapseProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| default-expand-all | Boolean | false | 默认是否展开全部 | N |
| disabled | Boolean | - | 是否禁用面板展开/收起操作 | N |
| expand-icon | Boolean | true | 展开图标 | N |
| expand-mutex | Boolean | false | 每个面板互斥展开，每次只展开一个面板 | N |
| theme | String | default | 折叠面板风格。可选项：default/card | N |
| value | Array | [] | 展开的面板集合。TS 类型：`CollapseValue``type CollapseValue = Array<string \| number>`。详细类型定义 | N |
| default-value | Array | undefined | 展开的面板集合。非受控属性。TS 类型：`CollapseValue``type CollapseValue = Array<string \| number>`。详细类型定义 | N |

### CollapseEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: CollapseValue)` | 切换面板时触发，返回变化的值 |

### CollapseSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### CollapsePanelProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| content | String | - | 折叠面板内容 | N |
| disabled | Boolean | undefined | 禁止当前面板展开，优先级大于 Collapse 的同名属性 | N |
| expand-icon | Boolean | undefined | 当前折叠面板展开图标，优先级大于 Collapse 的同名属性 | N |
| header | String | - | 面板头内容 | N |
| header-left-icon | String | - | 面板头左侧图标 | N |
| header-right-content | String | - | 面板头的右侧区域，一般用于呈现面板操作 | N |
| placement | String | bottom | `0.34.0`。选项卡内容的位置。可选项：bottom/top | N |
| value | String / Number | - | 当前面板唯一标识，如果值为空则取当前面下标兜底作为唯一标识 | N |

### CollapsePanelSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，作用同`content`插槽 |
| content | 自定义`content`显示内容 |
| expand-icon | 自定义`expand-icon`显示内容 |
| header | 自定义`header`显示内容 |
| header-left-icon | 自定义`header-left-icon`显示内容 |
| header-right-content | 自定义`header-right-content`显示内容 |

### CollapsePanelExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |
| t-class-header | 头部样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-collapse-border-color | @border-level-1-color | - |
| --td-collapse-content-font | @font-body-medium | - |
| --td-collapse-content-padding | 32rpx | - |
| --td-collapse-content-text-color | @text-color-primary | - |
| --td-collapse-extra-font | @font-body-large | - |
| --td-collapse-header-height | auto | - |
| --td-collapse-header-text-color | @text-color-primary | - |
| --td-collapse-header-text-disabled-color | @text-color-disabled | - |
| --td-collapse-horizontal-padding | 32rpx | - |
| --td-collapse-icon-color | @font-gray-3 | - |
| --td-collapse-panel-bg-color | @bg-color-container | - |
| --td-collapse-title-font | @font-body-large | - |

---

# [count-down]

# CountDown 倒计时

## 示例

> CountDown 组件用于实时展示倒计时数值。 如果需要与站点演示一致的数字字体效果，推荐您到 [数字字体章节](https://tdesign.tencent.com/design/fonts)，将 TCloudNumber 字体下载并将包含的 TCloudNumberVF.ttf 做为 TCloudNumber 字体资源引入到具体项目中使用。

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-count-down": "tdesign-miniprogram/count-down/count-down"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/TAsNNMmh875W)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础倒计时

**WXML** (`html`):
```html
<view class="demo-count-down">
<text class="demo-count-down-desc"> 时分秒 </text>
<view class="demo-count-down-content">
<t-count-down time="{{ time }}" />
</view>
</view>

<view class="demo-count-down">
<text class="demo-count-down-desc"> 带毫秒 </text>
<view class="demo-count-down-content">
<t-count-down format="HH:mm:ss:SSS" time="{{ time }}" millisecond />
</view>
</view>

<view class="demo-count-down">
<text class="demo-count-down-desc"> 带方形底 </text>
<view class="demo-count-down-content">
<t-count-down content="default" time="{{ time }}" theme="square"> </t-count-down>
</view>
</view>

<view class="demo-count-down">
<text class="demo-count-down-desc"> 带圆形底 </text>
<view class="demo-count-down-content">
<t-count-down content="default" time="{{ time }}" theme="round"> </t-count-down>
</view>
</view>

<view class="demo-count-down">
<text class="demo-count-down-desc"> 带单位 </text>
<view class="demo-count-down-content">
<t-count-down content="default" time="{{ time }}" splitWithUnit theme="round" />
</view>
</view>

<view class="demo-count-down">
<text class="demo-count-down-desc"> 无底色带单位 </text>
<view class="demo-count-down-content">
<t-count-down
t-class-count="external-count"
t-class-split="external-split"
content="default"
time="{{ time }}"
splitWithUnit
/>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
time: 96 * 60 * 1000,
},
});

```

**CSS** (`css`):
```css
.demo-count-down-desc {
color: var(--td-text-color-secondary);
font-size: 28rpx;
}

.demo-count-down-content {
margin: 32rpx 0 48rpx;
}

.external-count {
color: #e34d59;
font-size: 36rpx;
line-height: 48rpx;
vertical-align: middle;
}

.external-split {
font-size: 20rpx;
margin: 0 10rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-count-down": "tdesign-miniprogram/count-down/count-down"
}
}

```

### 调整尺寸

**WXML** (`html`):
```html
<view class="demo-count-down">
<text class="demo-count-down-desc"> 时分秒 </text>
<view class="demo-count-down-content">
<t-count-down size="small" time="{{ time }}" />
</view>
<view class="demo-count-down-content">
<t-count-down time="{{ time }}" />
</view>
<view class="demo-count-down-content">
<t-count-down size="large" time="{{ time }}" />
</view>
</view>

<view class="demo-count-down">
<text class="demo-count-down-desc"> 带毫秒 </text>
<view class="demo-count-down-content">
<t-count-down size="small" format="HH:mm:ss:SSS" time="{{ time }}" millisecond />
</view>
<view class="demo-count-down-content">
<t-count-down format="HH:mm:ss:SSS" time="{{ time }}" millisecond />
</view>
<view class="demo-count-down-content">
<t-count-down size="large" format="HH:mm:ss:SSS" time="{{ time }}" millisecond />
</view>
</view>

<view class="demo-count-down">
<text class="demo-count-down-desc"> 带方形底 </text>
<view class="demo-count-down-content">
<t-count-down size="small" format="HH:mm:ss" time="{{ time }}" theme="square" />
</view>
<view class="demo-count-down-content">
<t-count-down format="HH:mm:ss" time="{{ time }}" theme="square" />
</view>
<view class="demo-count-down-content">
<t-count-down size="large" format="HH:mm:ss" time="{{ time }}" theme="square" />
</view>
</view>

<view class="demo-count-down">
<text class="demo-count-down-desc"> 带圆形底 </text>
<view class="demo-count-down-content">
<t-count-down size="small" format="HH:mm:ss" time="{{ time }}" theme="round" />
</view>
<view class="demo-count-down-content">
<t-count-down format="HH:mm:ss" time="{{ time }}" theme="round" />
</view>
<view class="demo-count-down-content">
<t-count-down size="large" format="HH:mm:ss" time="{{ time }}" theme="round" />
</view>
</view>

<view class="demo-count-down">
<text class="demo-count-down-desc"> 带单位 </text>
<view class="demo-count-down-content">
<t-count-down size="small" format="HH:mm:ss" time="{{ time }}" splitWithUnit theme="round" />
</view>
<view class="demo-count-down-content">
<t-count-down format="HH:mm:ss" time="{{ time }}" splitWithUnit theme="round" />
</view>
<view class="demo-count-down-content">
<t-count-down size="large" format="HH:mm:ss" time="{{ time }}" splitWithUnit theme="round" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
time: 96 * 60 * 1000,
},
});

```

**CSS** (`css`):
```css
.demo-count-down {
padding-bottom: 32rpx;
}

.demo-count-down-desc {
color: var(--td-text-color-secondary);
font-size: 28rpx;
}

.demo-count-down-content {
margin: 24rpx 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-count-down": "tdesign-miniprogram/count-down/count-down"
}
}

```

## API

### CountDownProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| auto-start | Boolean | true | 是否自动开始倒计时 | N |
| content | String | 'default' | 最终倒计时的展示内容，值为'default'时使用默认的格式，否则使用自定义样式插槽 | N |
| format | String | HH:mm:ss | 时间格式，DD-日，HH-时，mm-分，ss-秒，SSS-毫秒 | N |
| millisecond | Boolean | false | 是否开启毫秒级渲染 | N |
| size | String | 'medium' | `0.5.1`。倒计时尺寸。可选项：small/medium/large | N |
| split-with-unit | Boolean | false | `0.5.1`。使用时间单位分割 | N |
| theme | String | 'default' | `0.5.1`。倒计时风格。可选项：default/round/square | N |
| time | Number | 0 | 必需。倒计时时长，单位毫秒 | Y |

### CountDownEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(time: TimeData)` | 时间变化时触发。详细类型定义。<br>`interface TimeData {  days: number; hours: number; minutes: number; seconds: number; milliseconds: number }`<br> |
| finish | - | 倒计时结束时触发 |

### CountDownSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，作用同`content`插槽 |
| content | 自定义`content`显示内容 |

### CountDownExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-count | 计数样式类 |
| t-class-split | 分隔线样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-countdown-bg-color | @error-color | - |
| --td-countdown-default-color | @text-color-primary | - |
| --td-countdown-round-border-radius | @radius-circle | - |
| --td-countdown-round-color | @text-color-anti | - |
| --td-countdown-square-border-radius | @radius-small | - |

---

# [date-time-picker]

# DateTimePicker 时间选择器

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-date-time-picker": "tdesign-miniprogram/date-time-picker/date-time-picker"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/hts3GMmc8c5q)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

#### 年月日选择器

**WXML** (`html`):
```html
<t-cell
title="选择日期"
hover
note="{{dateText || ''}}"
arrow
data-mode="date"
bindtap="showPicker"
class="test"
t-class="panel-item"
/>

<!-- 年月日 -->
<t-date-time-picker
auto-close
title="选择日期"
showWeek
visible="{{dateVisible}}"
mode="date"
default-value="{{date}}"
format="YYYY-MM-DD ddd"
filter="{{filter}}"
formatter="{{formatter}}"
popup-props="{{popupProps}}"
bindchange="onConfirm"
bindpick="onColumnChange"
bindcancel="hidePicker"
bindclose="handleClose"
/>

```

**JS** (`javascript`):
```javascript
const calendarMonth = [
'January',
'February',
'March',
'April',
'May',
'June',
'July',
'August',
'September',
'October',
'November',
'December',
];

Page({
data: {
mode: '',
dateVisible: false,
date: new Date('2021-12-23').getTime(), // 支持时间戳传入
dateText: '',
filter(type, options) {
if (type === 'year') {
return options.sort((a, b) => b.value - a.value);
}
return options;
},
popupProps: {
usingCustomNavbar: true,
},

formatter(item, index) {
if (index === 1) {
const label = item.label.slice(0, -1);
return {
value: item.value,
label: calendarMonth[Number(label) - 1],
};
}
if (index === 2) {
const [dateValue, weekValue] = item.label.split(' ');
const dateSuffixes = {
1: 'st',
2: 'nd',
3: 'rd',
};
const weekMap = {
周一: 'Mon.',
周二: 'Tues.',
周三: 'Wed.',
周四: 'Thurs.',
周五: 'Fri.',
周六: 'Sat.',
周日: 'Sun.',
};
const label = dateValue.slice(0, -1);

return {
value: item.value,
label: `${label}${dateSuffixes[label] || 'th'} ${weekMap[weekValue]}`,
};
}

return {
value: item.value,
label: item.label.slice(0, -1),
};
},
},
showPicker(e) {
const { mode } = e.currentTarget.dataset;
this.setData({
mode,
[`${mode}Visible`]: true,
});
},

handleClose(e) {
console.log('handleClose:', e);
},

onConfirm(e) {
const { value } = e.detail;
const { mode } = this.data;

console.log('confirm', value);

this.setData({
[mode]: value,
[`${mode}Text`]: value,
});
},

onColumnChange(e) {
console.log('pick', e.detail.value);
},
});

```

**CSS** (`css`):
```css
.panel-item {
margin-bottom: 32rpx;
}

.panel-item::after {
border: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-date-time-picker": "tdesign-miniprogram/date-time-picker/date-time-picker"
}
}

```

#### 年月选择器

**WXML** (`html`):
```html
<t-cell title="选择日期" hover note="{{monthText}}" arrow data-mode="month" bindtap="showPicker" t-class="panel-item" />

<!-- 年月 -->
<t-date-time-picker
title="选择日期"
visible="{{monthVisible}}"
mode="month"
value="{{month}}"
format="YYYY-MM"
bindchange="onConfirm"
bindpick="onColumnChange"
bindcancel="hidePicker"
start="{{start}}"
end="{{end}}"
/>

```

**JS** (`javascript`):
```javascript
Page({
data: {
mode: '',
monthVisible: false,
month: '2021-09',
monthText: '',

// 指定选择区间起始值
start: '2000-01-01 00:00:00',
end: '2030-09-09 12:12:12',
},
showPicker(e) {
const { mode } = e.currentTarget.dataset;
this.setData({
mode,
[`${mode}Visible`]: true,
});
},
hidePicker() {
const { mode } = this.data;
this.setData({
[`${mode}Visible`]: false,
});
},
onConfirm(e) {
const { value } = e.detail;
const { mode } = this.data;

console.log('confirm', value);

this.setData({
[mode]: value,
[`${mode}Text`]: value,
});

this.hidePicker();
},

onColumnChange(e) {
console.log('pick', e.detail.value);
},
});

```

**CSS** (`css`):
```css
.panel-item {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-date-time-picker": "tdesign-miniprogram/date-time-picker/date-time-picker"
}
}

```

### 时间选择器

包括：`时分秒`、`时分`两个示例

**WXML** (`html`):
```html
<view class="demo-desc">时分秒选择器</view>
<t-cell
title="选择时间"
hover
note="{{secondText || ''}}"
arrow
data-mode="second"
bindtap="showPicker"
t-class="panel-item"
/>

<view class="demo-desc">时分选择器</view>
<t-cell
title="选择时间"
hover
note="{{minuteText || ''}}"
arrow
data-mode="minute"
bindtap="showPicker"
t-class="panel-item"
/>

<!-- 时分 -->
<t-date-time-picker
title="选择时间"
visible="{{secondVisible}}"
mode="{{['null', 'second']}}"
value="{{second}}"
format="HH:mm:ss"
bindchange="onConfirm"
bindpick="onColumnChange"
bindcancel="hidePicker"
/>

<!-- 时分 -->
<t-date-time-picker
title="选择时间"
visible="{{minuteVisible}}"
mode="{{['null', 'minute']}}"
start="{{start}}"
value="{{minute}}"
format="HH:mm"
bindchange="onConfirm"
bindpick="onColumnChange"
bindcancel="hidePicker"
/>

```

**JS** (`javascript`):
```javascript
Component({
data: {
mode: '',
second: '10:00:00',
minute: '23:59',
start: '2025-04-29 00:00:00',
},
methods: {
showPicker(e) {
const { mode } = e.currentTarget.dataset;
this.setData({
mode,
[`${mode}Visible`]: true,
});
},
hidePicker() {
const { mode } = this.data;
this.setData({
[`${mode}Visible`]: false,
});
},
onConfirm(e) {
const { value } = e.detail;
const { mode } = this.data;

console.log('confirm', value);

this.setData({
[mode]: value,
[`${mode}Text`]: value,
});

this.hidePicker();
},

onColumnChange(e) {
console.log('pick', e.detail.value);
},
},
});

```

**CSS** (`css`):
```css
.panel-item {
margin: 32rpx 0;
}

```

**JSON** (`javascript`):
```javascript
{
"styleIsolation": "apply-shared",
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-date-time-picker": "tdesign-miniprogram/date-time-picker/date-time-picker"
}
}

```

#### 年月日时分秒选择器

**WXML** (`html`):
```html
<t-cell
title="选择日期时间"
hover
note="{{datetimeText}}"
arrow
data-mode="datetime"
bindtap="showPicker"
t-class="panel-item"
/>

<!-- 年月日时分 -->
<t-date-time-picker
title="选择日期和时间"
visible="{{datetimeVisible}}"
mode="second"
value="{{datetime}}"
format="YYYY-MM-DD HH:mm:ss"
bindchange="onConfirm"
bindpick="onColumnChange"
bindcancel="hidePicker"
/>

```

**JS** (`javascript`):
```javascript
Page({
data: {
mode: '',
datetimeVisible: false,
datetime: new Date('2021-12-23').getTime(),
datetimeText: '',
},
showPicker(e) {
const { mode } = e?.currentTarget?.dataset;
this.setData({
mode,
[`${mode}Visible`]: true,
});
},
hidePicker() {
const { mode } = this.data;
this.setData({
[`${mode}Visible`]: false,
});
},
onConfirm(e) {
const { value } = e?.detail;
const { mode } = this.data;

console.log('confirm', value);

this.setData({
[mode]: value,
[`${mode}Text`]: value,
});

this.hidePicker();
},

onColumnChange(e) {
console.log('pick', e?.detail?.value);
},
});

```

**CSS** (`css`):
```css
.panel-item {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-date-time-picker": "tdesign-miniprogram/date-time-picker/date-time-picker"
}
}

```

### 组件用法

#### 调整步数

**WXML** (`html`):
```html
<t-cell title="选择时间" hover note="{{text || ''}}" arrow bindtap="showPicker" t-class="panel-item" />

<t-date-time-picker
title="选择时间"
visible="{{visible}}"
value="{{value}}"
format="HH:mm:ss"
mode="{{['null', 'second']}}"
steps="{{ { minute: 5 } }}"
bindchange="onConfirm"
bindpick="onColumnChange"
bindcancel="hidePicker"
/>

```

**JS** (`javascript`):
```javascript
Component({
data: {
text: '',
value: '10:00:00',
visible: false,
},
methods: {
showPicker() {
this.setData({
visible: true,
});
},
hidePicker() {
this.setData({
visible: false,
});
},
onConfirm(e) {
const { value } = e.detail;

console.log('confirm', value);

this.setData({
value,
text: value,
});

this.hidePicker();
},

onColumnChange(e) {
console.log('pick', e.detail.value);
},
},
});

```

**CSS** (`css`):
```css
.panel-item {
margin: 32rpx 0;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-date-time-picker": "tdesign-miniprogram/date-time-picker/date-time-picker"
}
}

```

#### 不使用Popup

**WXML** (`html`):
```html
<t-date-time-picker
usePopup="{{false}}"
title="选择日期"
visible="{{dateVisible}}"
mode="date"
defaultValue="{{date}}"
format="YYYY-MM-DD"
bindchange="onConfirm"
bindpick="onColumnChange"
bindcancel="hidePicker"
start="{{start}}"
end="{{end}}"
/>

```

**JS** (`javascript`):
```javascript
Page({
data: {
mode: '',
dateVisible: false,
date: new Date('2021-12-23').getTime(), // 支持时间戳传入

// 指定选择区间起始值
start: '2000-01-01 00:00:00',
end: '2030-09-09 12:12:12',
},

hidePicker() {
const { mode } = this.data;
this.setData({
[`${mode}Visible`]: false,
});
},
onConfirm(e) {
const { value } = e.detail;
const { mode } = this.data;

console.log('confirm', value);

this.setData({
[mode]: value,
[`${mode}Text`]: value,
});

this.hidePicker();
},

onColumnChange(e) {
console.log('pick', e.detail.value);
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-date-time-picker": "tdesign-miniprogram/date-time-picker/date-time-picker"
}
}

```

## API

### DateTimePickerProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| auto-close | Boolean | false | 自动关闭；在确认、取消、点击遮罩层自动关闭，不需要手动设置 visible | N |
| cancel-btn | String | 取消 | 取消按钮文字 | N |
| confirm-btn | String | - | 确定按钮文字 | N |
| custom-locale | String | zh | 组件国际化语言，目前支持: 简体中文(zh)、(tc)、英文(en)、日语(ja)、韩语(ko)、俄语(ru)等六种语言 | N |
| end | String / Number | - | 选择器的最大可选时间，默认为当前时间+10年 | N |
| filter | Function | - | 列选项过滤函数，支持自定义列内容。(type 值可为: year, month, date, hour, minute, second)。TS 类型：`(type: TimeModeValues, columns: DateTimePickerColumn) => DateTimePickerColumn``type DateTimePickerColumn = DateTimePickerColumnItem[]``interface DateTimePickerColumnItem { label: string,value: string}`。详细类型定义 | N |
| format | String | 'YYYY-MM-DD HH:mm:ss' | 用于格式化 pick、change、confirm 事件返回的值，详细文档 | N |
| formatter | Function | - | 格式化标签。TS 类型：`(option: DateTimePickerColumnItem, columnIndex: number) => DateTimePickerColumnItem` | N |
| header | Boolean | true | 头部内容。值为 true 显示空白头部，值为 false 不显示任何内容 | N |
| mode | String / Array | 'date' | year = 年；month = 年月；date = 年月日；hour = 年月日时； minute = 年月日时分；当类型为数组时，第一个值控制年月日，第二个值控制时分秒。TS 类型：`DateTimePickerMode``type DateTimePickerMode = TimeModeValues \| Array<TimeModeValues> ``type TimeModeValues = 'year' \| 'month' \| 'date' \| 'hour' \| 'minute' \| 'second'`。详细类型定义 | N |
| popup-props | Object | {} | 透传 Popup 组件全部属性。TS 类型：`PopupProps`，Popup API Documents。详细类型定义 | N |
| show-week | Boolean | false | `1.9.0`。是否在日期旁边显示周几（如周一，周二，周日等） | N |
| start | String / Number | - | 选择器的最小可选时间，默认为当前时间-10年 | N |
| steps | Object | {} | 时间间隔步数，示例：`{ minute: 5 }`。TS 类型：`{ [key in TimeModeValues]?: number }` | N |
| title | String | - | 标题 | N |
| use-popup | Boolean | true | 是否使用弹出层包裹 | N |
| value | String / Number | - | 选中值。TS 类型：`DateValue``type DateValue = string \| number`。详细类型定义 | N |
| default-value | String / Number | undefined | 选中值。非受控属性。TS 类型：`DateValue``type DateValue = string \| number`。详细类型定义 | N |
| visible | Boolean | false | 是否显示 | N |

### DateTimePickerEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| cancel | - | 取消按钮点击时触发 |
| change | `(value: DateValue)` | 确认按钮点击时触发 |
| close | `(trigger: TriggerSource)` | `1.0.1`。关闭时触发。详细类型定义。<br>`type TriggerSource = 'overlay' \| 'cancel-btn' \| 'confirm-btn'`<br> |
| confirm | `(value: DateValue)` | `1.0.1`。确认按钮点击时触发 |
| pick | `(value: DateValue)` | 选中值发生变化时触发 |

### DateTimePickerSlots

| 名称 | 描述 |
| --- | --- |
| footer | 底部内容 |
| header | 自定义`header`显示内容 |

### DateTimePickerExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-cancel | 取消样式类 |
| t-class-confirm | 确认样式类 |
| t-class-title | 标题样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-data-time-picker-year-width | 128rpx | - |

---

# [dialog]

# Dialog 对话框

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-dialog": "tdesign-miniprogram/dialog/dialog"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/WKslWMmK8g5L)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

按钮的样式，默认使用 `variant = text`，如果任意按钮改变了 `variant`，那么全部按钮都改变成这个。

#### 反馈类对话框

**WXML** (`html`):
```html
<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showTextAndTitle"
bind:tap="showDialog"
block
>
反馈类-带标题
</t-button>
<t-dialog
visible="{{showTextAndTitle}}"
title="对话框标题"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="{{ confirmBtn }}"
bind:confirm="closeDialog"
/>

<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showContentOnly"
bind:tap="showDialog"
block
>
反馈类-无标题
</t-button>
<t-dialog
visible="{{showContentOnly}}"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="{{ confirmBtn }}"
bind:confirm="closeDialog"
/>

<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showTitleOnly"
bind:tap="showDialog"
block
>
反馈类-纯标题
</t-button>
<t-dialog visible="{{showTitleOnly}}" title="对话框标题" confirm-btn="{{ confirmBtn }}" bind:confirm="closeDialog" />

<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showMultiTextAndTitle"
bind:tap="showDialog"
block
>
反馈类-内容超长
</t-button>
<t-dialog
visible="{{showMultiTextAndTitle}}"
title="对话框标题"
confirm-btn="{{ confirmBtn }}"
bind:confirm="closeDialog"
>
<!-- 适配skyline，增加type="list" -->
<scroll-view slot="content" type="list" scroll-y class="long-content">
<view class="content-container"
>这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案，这里是辅助内容文案
</view>
</scroll-view>
</t-dialog>

```

**JS** (`javascript`):
```javascript
Component({
data: {
confirmBtn: { content: '知道了', variant: 'base' },
dialogKey: '',
showText: false,
showMultiText: false,
showTextAndTitle: false,
showTitleOnly: false,
showMultiTextAndTitle: false,
},
methods: {
showDialog(e) {
const { key } = e.currentTarget.dataset;
this.setData({ [key]: true, dialogKey: key });
},

closeDialog() {
const { dialogKey } = this.data;
this.setData({ [dialogKey]: false });
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
margin-bottom: 32rpx;
}

.long-content {
height: 576rpx;
margin-top: 16rpx;
font-size: 32rpx;
color: #888;
}

.long-content .content-container {
white-space: pre-line;
}

.long-content ::-webkit-scrollbar {
display: none;
width: 0;
height: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-dialog": "tdesign-miniprogram/dialog/dialog"
}
}

```

> 使用这种方式，对话框的 `visible` 是受控的，需要手动设置额 `visible` 为 `false` 才会关闭对话框。

#### 确认类对话框

**WXML** (`html`):
```html
<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showConfirm"
bind:tap="showDialog"
block
>
确认类-带标题
</t-button>
<t-dialog
visible="{{showConfirm}}"
title="对话框标题"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="{{ confirmBtn }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
/>

<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showWarnConfirm"
bind:tap="showDialog"
block
>
确认类-无标题
</t-button>
<t-dialog
visible="{{showWarnConfirm}}"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="{{ { content: '警示操作', variant: 'base', theme: 'danger' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
/>

<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showLightConfirm"
bind:tap="showDialog"
block
>
确认类-纯标题
</t-button>
<t-dialog
visible="{{showLightConfirm}}"
title="对话框标题"
confirm-btn="{{ { content: '确定', variant: 'base', theme: 'light' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
/>

```

**JS** (`javascript`):
```javascript
Component({
data: {
confirmBtn: { content: '确定', variant: 'base' },
dialogKey: '',
showConfirm: false,
showWarnConfirm: false,
showLightConfirm: false,
},
methods: {
showDialog(e) {
const { key } = e.currentTarget.dataset;
this.setData({ [key]: true, dialogKey: key });
},

closeDialog() {
const { dialogKey } = this.data;
this.setData({ [dialogKey]: false });
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-dialog": "tdesign-miniprogram/dialog/dialog"
}
}

```

#### 输入类对话框

**WXML** (`html`):
```html
<t-button
t-class="wrapper"
size="large"
theme="primary"
variant="outline"
data-key="showWithInput"
bind:tap="showDialog"
block
>
输入类-无描述
</t-button>
<t-dialog
visible="{{showWithInput}}"
title="带输入框对话框"
confirm-btn="确定"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
>
<t-input
borderless
class="dialog-input"
clearable
slot="content"
placeholder="输入12文案"
placeholder-class="placeholder"
/>
</t-dialog>

<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showTextAndTitleWithInput"
bind:tap="showDialog"
block
>输入类-带描述</t-button
>
<t-dialog
visible="{{showTextAndTitleWithInput}}"
title="带输入框对话框"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="确定"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
>
<t-input
borderless
class="dialog-input"
clearable
slot="content"
placeholder="输入12文案"
placeholder-class="placeholder"
/>
</t-dialog>

```

**JS** (`javascript`):
```javascript
Component({
data: {
dialogKey: '',
showWithInput: false,
showTextAndTitleWithInput: false,
},
methods: {
showDialog(e) {
const { key } = e.currentTarget.dataset;
this.setData({ [key]: true, dialogKey: key });
},

closeDialog() {
const { dialogKey } = this.data;
this.setData({ [dialogKey]: false });
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
margin-bottom: 32rpx;
}

.placeholder {
color: var(--td-text-color-placeholder);
line-height: 96rpx;
height: 96rpx !important;
display: flex;
align-items: center;
}

.dialog-input {
padding-top: 12px;
padding-bottom: 12px;
text-align: left;
margin-top: 32rpx;
border-radius: 8rpx;
background-color: var(--td-bg-color-page);
box-sizing: border-box;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-input": "tdesign-miniprogram/input/input",
"t-dialog": "tdesign-miniprogram/dialog/dialog"
}
}

```

#### 带图片对话框

**WXML** (`html`):
```html
<t-button
t-class="wrapper"
size="large"
theme="primary"
variant="outline"
data-key="imageOnTop"
bind:tap="showDialog"
block
>
图片置顶-带标题描述
</t-button>
<t-dialog
visible="{{imageOnTop}}"
title="对话框标题"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="{{ {content: '确定', variant: 'base' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
>
<t-image slot="top" t-class="dialog-image" src="https://tdesign.gtimg.com/mobile/demos/dialog1.png" />
</t-dialog>

<t-button
t-class="wrapper"
size="large"
theme="primary"
variant="outline"
data-key="imageOnTopWithContent"
bind:tap="showDialog"
block
>
图片置顶-无标题
</t-button>
<t-dialog
visible="{{imageOnTopWithContent}}"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="{{ {content: '确定', variant: 'base' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
>
<t-image slot="top" t-class="dialog-image" src="https://tdesign.gtimg.com/mobile/demos/dialog1.png" />
</t-dialog>

<t-button
t-class="wrapper"
size="large"
theme="primary"
variant="outline"
data-key="imageOnTopWithTitle"
bind:tap="showDialog"
block
>
图片置顶-纯标题
</t-button>
<t-dialog
visible="{{imageOnTopWithTitle}}"
title="对话框标题"
confirm-btn="{{ {content: '确定', variant: 'base' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
>
<t-image slot="top" t-class="dialog-image" src="https://tdesign.gtimg.com/mobile/demos/dialog1.png" />
</t-dialog>

<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="imageOnMiddleWithImage"
bind:tap="showDialog"
block
>
图片置顶-纯图片
</t-button>
<t-dialog
visible="{{imageOnMiddleWithImage}}"
confirm-btn="{{ {content: '确定', variant: 'base' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
>
<t-image slot="top" t-class="dialog-image" src="https://tdesign.gtimg.com/mobile/demos/dialog1.png" />
</t-dialog>

<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="imageOnMiddle"
bind:tap="showDialog"
block
>
图片居中-带标题描述
</t-button>
<t-dialog
visible="{{imageOnMiddle}}"
title="对话框标题"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="{{ {content: '确定', variant: 'base' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
>
<t-image slot="middle" t-class="image-host dialog-image" src="https://tdesign.gtimg.com/mobile/demos/dialog1.png" />
</t-dialog>

<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="imageOnMiddleWithTitle"
bind:tap="showDialog"
block
>
图片居中-纯标题
</t-button>
<t-dialog
visible="{{imageOnMiddleWithTitle}}"
title="对话框标题"
confirm-btn="{{ {content: '确定', variant: 'base' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
>
<t-image slot="middle" t-class="image-host dialog-image" src="https://tdesign.gtimg.com/mobile/demos/dialog1.png" />
</t-dialog>

```

**JS** (`javascript`):
```javascript
Component({
data: {
dialogKey: '',
imageOnTop: false,
imageOnTopWithContent: false,
imageOnTopWithTitle: false,
imageOnMiddle: false,
imageOnMiddleWithTitle: false,
imageOnMiddleWithImage: false,
},
methods: {
showDialog(e) {
const { key } = e.currentTarget.dataset;
this.setData({ [key]: true, dialogKey: key });
},

closeDialog() {
const { dialogKey } = this.data;
this.setData({ [dialogKey]: false });
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
margin-bottom: 32rpx;
}

.dialog-image {
width: 100%;
height: 160px;
}

.image-host {
display: block;
margin-top: 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-image": "tdesign-miniprogram/image/image",
"t-dialog": "tdesign-miniprogram/dialog/dialog"
}
}

```

### 组件状态

**WXML** (`html`):
```html
<view class="demo-desc">文字按钮</view>
<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showConfirm"
bind:tap="showDialog"
block
>
文字按钮
</t-button>
<t-dialog
visible="{{showConfirm}}"
title="对话框标题"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="确定"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
/>

<view class="demo-desc">水平基础按钮</view>
<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showWarnConfirm"
bind:tap="showDialog"
block
>
水平基础按钮
</t-button>
<t-dialog
visible="{{showWarnConfirm}}"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="{{ { content: '确定', variant: 'base' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
/>

<view class="demo-desc">垂直基础按钮</view>
<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showTooLongBtnContent"
bind:tap="showDialog"
block
>
垂直基础按钮
</t-button>
<t-dialog
visible="{{showTooLongBtnContent}}"
title="对话框标题"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
confirm-btn="{{ confirmBtn }}"
cancel-btn="取消"
button-layout="vertical"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
/>

<view class="demo-desc">多按钮</view>
<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showMultiBtn"
bind:tap="showDialog"
block
>
多按钮
</t-button>
<t-dialog
visible="{{showMultiBtn}}"
title="对话框标题"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
button-layout="vertical"
actions="{{ multiBtnList }}"
bind:action="closeDialog"
/>

<view class="demo-desc">带关闭按钮的对话框</view>
<t-button
t-class="wrapper"
theme="primary"
size="large"
variant="outline"
data-key="showCloseBtn"
bind:tap="showDialog"
block
>
带关闭按钮的对话框
</t-button>
<t-dialog
visible="{{showCloseBtn}}"
title="对话框标题"
content="告知当前状态、信息和解决方法，等内容。描述文案尽可能控制在三行内"
close-btn
confirm-btn="{{ { content: '警示操作', variant: 'base', theme: 'danger' } }}"
cancel-btn="取消"
bind:confirm="closeDialog"
bind:cancel="closeDialog"
/>

```

**JS** (`javascript`):
```javascript
Component({
data: {
confirmBtn: { content: '确定', variant: 'base' },
dialogKey: '',
showConfirm: false,
showWarnConfirm: false,
showTooLongBtnContent: false,
showMultiBtn: false,
multiBtnList: [
{ content: '次要按钮', theme: 'light' },
{ content: '次要按钮', theme: 'light' },
{ content: '主要按钮', theme: 'primary' },
],
},
methods: {
showDialog(e) {
const { key } = e.currentTarget.dataset;
this.setData({ [key]: true, dialogKey: key });
},

closeDialog() {
const { dialogKey } = this.data;
this.setData({ [dialogKey]: false });
},
},
});

```

**CSS** (`css`):
```css
.demo-desc {
margin: 0 0 32rpx;
}

.wrapper {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-dialog": "tdesign-miniprogram/dialog/dialog"
}
}

```

### 组件用法

#### 命令调用

**WXML** (`html`):
```html
<t-button size="large" variant="outline" theme="primary" bind:tap="showDialog" block> 命令行操作 </t-button>
<t-dialog id="t-dialog" />

```

**JS** (`javascript`):
```javascript
import Dialog from 'tdesign-miniprogram/dialog';

Component({
methods: {
showDialog() {
const dialogConfig = {
context: this,
title: '弹窗标题',
closeOnOverlayClick: true,
content: '告知当前状态、信息和解决方法等内容。',
confirmBtn: '确定',
cancelBtn: '取消',
};

Dialog.confirm(dialogConfig)
.then((data) => console.log('点击了确定', data))
.catch((data) => console.log('点击了取消', data));
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-dialog": "tdesign-miniprogram/dialog/dialog"
}
}

```

#### 开放能力按钮

当传入的按钮类型为对象时，整个对象都将透传至 `t-button`，因此按钮可以直接使用开放能力

**WXML** (`html`):
```html
<t-button size="large" theme="primary" variant="outline" data-type="hasCancelBtn" bind:tap="showDialog" block>
开放能力按钮
</t-button>
<t-dialog id="t-dialog" />

```

**JS** (`javascript`):
```javascript
import Dialog from 'tdesign-miniprogram/dialog';

Component({
methods: {
showDialog() {
const dialogConfig = {
context: this,
title: '弹窗标题',
content: '告知当前状态、信息和解决方法等内容。',
cancelBtn: '取消',
confirmBtn: {
openType: 'share',
content: '分享给朋友',
bindgetphonenumber({ detail }) {
console.log(detail);
if (detail.errMsg.includes('fail')) {
console.log('获取失败');
return false; // 不关闭弹窗
}
return true; // 关闭弹窗
},
},
};

Dialog.confirm(dialogConfig)
.then(() => {
console.log('点击确定');
})
.catch(() => {
console.log('点击取消');
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-dialog": "tdesign-miniprogram/dialog/dialog"
}
}

```

## API

### DialogProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| actions | Array | - | 操作栏。TS 类型：`Array<ButtonProps>`，Button API Documents。详细类型定义 | N |
| button-layout | String | horizontal | 多按钮排列方式。可选项：horizontal/vertical | N |
| cancel-btn | String / Object | - | 取消按钮，可自定义。值为 null 则不显示取消按钮。值类型为字符串，则表示自定义按钮文本，值类型为 Object 则表示透传 Button 组件属性。使用 Slot 自定义按钮时，需自行控制取消事件。详细类型定义 | N |
| close-btn | Boolean / Object | false | `0.31.0`。是否展示关闭按钮，值为`true`显示默认关闭按钮；值为`false`则不显示关闭按钮；使用 Object 时透传至图标组件。TS 类型：`boolean \| ButtonProps \| null`，Button API Documents。详细类型定义 | N |
| close-on-overlay-click | Boolean | false | 点击蒙层时是否触发关闭事件 | N |
| confirm-btn | String / Object | - | 确认按钮。值为 null 则不显示确认按钮。值类型为字符串，则表示自定义按钮文本，值类型为 Object 则表示透传 Button 组件属性。使用 Slot 自定义按钮时，需自行控制确认事件 | N |
| content | String | - | 内容 | N |
| overlay-props | Object | {} | 透传至 Overlay 组件。TS 类型：`OverlayProps`，Overlay API Documents。详细类型定义 | N |
| prevent-scroll-through | Boolean | true | 防止滚动穿透 | N |
| show-overlay | Boolean | true | 是否显示遮罩层 | N |
| title | String | - | 标题 | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| visible | Boolean | - | 控制对话框是否显示 | N |
| z-index | Number | 11500 | 对话框层级，Web 侧样式默认为 2500，移动端样式默认 2500，小程序样式默认为 11500 | N |

### DialogEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| cancel | - | 如果“取消”按钮存在，则点击“取消”按钮时触发，同时触发关闭事件 |
| close | `(trigger: DialogEventSource)` | 关闭事件，点击 取消按钮 或 点击蒙层 时触发。详细类型定义。<br>`type DialogEventSource = 'cancel' \| 'overlay' \| 'close-btn'`<br> |
| confirm | - | 如果“确认”按钮存在，则点击“确认”按钮时触发 |
| overlay-click | - | 如果蒙层存在，点击蒙层时触发 |

### DialogSlots

| 名称 | 描述 |
| --- | --- |
| actions | 自定义`actions`显示内容 |
| cancel-btn | 自定义`cancel-btn`显示内容 |
| confirm-btn | 自定义`confirm-btn`显示内容 |
| content | 自定义`content`显示内容 |
| middle | 中间自定义内容 |
| title | 自定义`title`显示内容 |
| top | 顶部自定义内容 |

### DialogExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-action | 操作样式类 |
| t-class-cancel | 取消样式类 |
| t-class-confirm | 确认样式类 |
| t-class-content | 内容样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-dialog-body-max-height | 912rpx | - |
| --td-dialog-border-radius | @radius-extraLarge | - |
| --td-dialog-close-color | @text-color-placeholder | - |
| --td-dialog-content-color | @text-color-secondary | - |
| --td-dialog-content-font | @font-body-large | - |
| --td-dialog-title-color | @text-color-primary | - |
| --td-dialog-title-font | @font-title-large | - |
| --td-dialog-width | 622rpx | - |

---

# [divider]

# Divider 分割线

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-divider": "tdesign-miniprogram/divider/divider"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/00UGcNmK8g5T)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础分割符

分割符主要是由直线和文字组成，通过`slot`传入分割线文案或者其他自定义内容，通过`layout`控制分隔符是垂直还是横向

**WXML** (`html`):
```html
<t-divider />

<view class="divider-demo__title">带文字水平分割线</view>

<t-divider content="文字信息" align="left" />
<t-divider content="文字信息" />
<t-divider content="文字信息" align="right" />

<view class="divider-demo__title">垂直分割线</view>

<view class="divider-wrapper">
<text class="demo-6__text-color">文字信息</text>
<t-divider layout="vertical" />
<text class="demo-6__text-color">文字信息</text>
<t-divider layout="vertical" />
<text class="demo-6__text-color">文字信息</text>
</view>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
behaviors: [SkylineBehavior],
});

```

**CSS** (`css`):
```css
.divider-demo__title {
font-size: 28rpx;
color: var(--bg-color-demo-desc);
padding: 16rpx 32rpx;
line-height: 40rpx;
}

.divider-wrapper {
display: flex;
align-items: center;
font-size: 28rpx;
color: var(--td-text-color-primary);
padding-left: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-divider": "tdesign-miniprogram/divider/divider"
}
}

```

### 虚线样式

**WXML** (`html`):
```html
<t-divider t-class="{{skylineRender?'skyline-dashed':''}}" dashed />
<t-divider t-class="{{skylineRender?'skyline-dashed':''}}" dashed content="文字信息" align="left" />
<t-divider t-class="{{skylineRender?'skyline-dashed':''}}" dashed content="文字信息" />
<t-divider t-class="{{skylineRender?'skyline-dashed':''}}" dashed content="文字信息" align="right" />

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
behaviors: [SkylineBehavior],
});

```

**CSS** (`css`):
```css
.divider-demo__title {
font-size: 24rpx;
color: rgba(0, 0, 0, 0.4);
padding: 0 32rpx 16rpx;
line-height: 40rpx;
}

.demo-5 {
margin: 0 32rpx;
}

/* 兼容skyline写法，后续skyline支持border-top后可删除 */
.skyline-dashed {
border-style: unset !important;
border-top-style: dashed !important;
border-color: unset !important;
border-top-color: #e7e7e7 !important;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-divider": "tdesign-miniprogram/divider/divider"
}
}

```

## API

### DividerProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| align | String | center | 文本位置（仅在水平分割线有效）。可选项：left/right/center | N |
| content | String | - | 子元素 | N |
| dashed | Boolean | false | 是否虚线（仅在水平分割线有效） | N |
| layout | String | horizontal | 分隔线类型有两种：水平和垂直。可选项：horizontal/vertical | N |

### DividerSlots

| 名称 | 描述 |
| --- | --- |
| content | 自定义`content`显示内容 |

### DividerExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-divider-border-width | 2rpx | - |
| --td-divider-color | @bg-color-component | - |
| --td-divider-content-color | @text-color-placeholder | - |
| --td-divider-content-font | @font-body-small | - |
| --td-divider-content-line-style | solid | - |
| --td-divider-content-margin | @spacer-1 | - |
| --td-divider-horizontal-margin | 20rpx | - |
| --td-divider-vertical-margin | @spacer | - |

---

# [drawer]

# Drawer 抽屉

## 示例

该组件于 0.7.2 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-drawer": "tdesign-miniprogram/drawer/drawer"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/UMv9BMmK885L)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础抽屉

**WXML** (`html`):
```html
<t-button variant="outline" bind:tap="openDrawerBase" block size="large" theme="primary">基础抽屉</t-button>

<t-drawer
visible="{{visible}}"
placement="{{placement}}"
items="{{sidebar}}"
usingCustomNavbar
bind:overlay-click="overlayClick"
bind:item-click="itemClick"
></t-drawer>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
behaviors: [SkylineBehavior],
data: {
placement: 'left',
sidebar: [],
baseSidebar: [
{
title: '菜单一',
},
{
title: '菜单二',
},
{
title: '菜单三',
},
{
title: '菜单四',
},
{
title: '菜单五',
},
{
title: '菜单六',
},
{
title: '菜单七',
},
{
title: '菜单八',
},
],
},

/**
* 组件的方法列表
*/
methods: {
openDrawerBase() {
this.setData({
visible: true,
sidebar: this.data.baseSidebar,
});
},

itemClick(e) {
console.log(e.detail);
},

overlayClick(e) {
console.log(e.detail);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-drawer": "tdesign-miniprogram/drawer/drawer"
}
}

```

### 带图标的抽屉

**WXML** (`html`):
```html
<t-button variant="outline" block bind:tap="openDrawerIcon" size="large" theme="primary">带图标抽屉</t-button>

<t-drawer
visible="{{visible}}"
placement="{{placement}}"
items="{{sidebar}}"
usingCustomNavbar
bind:overlay-click="overlayClick"
bind:item-click="itemClick"
></t-drawer>

```

**JS** (`javascript`):
```javascript
Component({
data: {
placement: 'left',
sidebar: [],
iconSidebar: [
{
title: '菜单一',
icon: 'app',
},
{
title: '菜单二',
icon: 'app',
},
{
title: '菜单三',
icon: 'app',
},
{
title: '菜单四',
icon: 'app',
},
{
title: '菜单五',
icon: 'app',
},
{
title: '菜单六',
icon: 'app',
},
{
title: '菜单七',
icon: 'app',
},
{
title: '菜单八',
icon: 'app',
},
],
},

/**
* 组件的方法列表
*/
methods: {
openDrawerIcon() {
this.setData({
visible: true,
sidebar: this.data.iconSidebar,
});
},

itemClick(e) {
console.log(e.detail);
},

overlayClick(e) {
console.log(e.detail);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-drawer": "tdesign-miniprogram/drawer/drawer"
}
}

```

> Drawer的 `visible` 是受控的，需要手动设置 `visible` 为 `true` 才会开启抽屉

## API

### DrawerProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| close-on-overlay-click | Boolean | true | 点击蒙层时是否触发抽屉关闭事件 | N |
| destroy-on-close | Boolean | false | 抽屉关闭时是否销毁节点 | N |
| items | Array | - | 抽屉里的列表项。TS 类型：`DrawerItem[]``interface DrawerItem { title: string; icon: string; }`。详细类型定义 | N |
| overlay-props | Object | {} | 遮罩层的属性，透传至 overlay。TS 类型：`OverlayProps`，Overlay API Documents。详细类型定义 | N |
| placement | String | right | 抽屉方向。可选项：left/right | N |
| show-overlay | Boolean | true | 是否显示遮罩层 | N |
| title | String | - | `0.29.0`。抽屉的标题 | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| visible | Boolean | false | 组件是否可见 | N |
| z-index | Number | 11500 | 抽屉层级，样式默认为 11500 | N |

### DrawerSlots

| 名称 | 描述 |
| --- | --- |
| footer | `0.29.0`。抽屉的底部 |
| title | `0.29.0`。抽屉的标题 |

### DrawerEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| close | `(trigger: DrawerTriggerSource)` | 关闭时触发。。详细类型定义。<br>`type DrawerTriggerSource = 'overlay'`<br> |
| item-click | `(index: number; item: DrawerItem)` | 点击抽屉里的列表项 |
| overlay-click | - | 如果蒙层存在，点击蒙层时触发 |

### DrawerSlots

| 名称 | 描述 |
| --- | --- |
| - | 自定义抽屉的底部 |
| footer | `0.29.0`。抽屉的底部 |
| title | `0.29.0`。自定义`title`显示内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-drawer-bg-color | @bg-color-container | - |
| --td-drawer-border-color | @border-level-1-color | - |
| --td-drawer-footer-padding-bottom | 40rpx | - |
| --td-drawer-hover-color | @bg-color-secondarycontainer | - |
| --td-drawer-item-icon-color | @drawer-title-color | - |
| --td-drawer-item-icon-size | 48rpx | - |
| --td-drawer-item-padding | 32rpx | - |
| --td-drawer-sidebar-height | 70vh | - |
| --td-drawer-title-color | @text-color-primary | - |
| --td-drawer-title-font | @font-title-large | - |
| --td-drawer-title-padding | 48rpx 32rpx 16rpx | - |
| --td-drawer-width | 560rpx | - |

---

# [dropdown-menu]

# DropdownMenu 下拉菜单

## 示例

该组件于 0.8.0 版本上线，请留意版本。
## 引入

### 引入组件

在 `app.json` 或 `page.json` 中引入组件：

```json
"usingComponents": {
"t-dropdown-menu": "tdesign-miniprogram/dropdown-menu/dropdown-menu",
"t-dropdown-item": "tdesign-miniprogram/dropdown-item/dropdown-item"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/ncvL0Mmd8e5n)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 单选下拉菜单

**WXML** (`html`):
```html
<t-dropdown-menu>
<t-dropdown-item options="{{product.options}}" placement="right" value="{{product.value}}" bindchange="onChange" />
<t-dropdown-item options="{{sorter.options}}" placement="right" default-value="{{sorter.value}}" />
</t-dropdown-menu>

```

**JS** (`javascript`):
```javascript
Component({
data: {
product: {
value: 'all',
options: [
{
value: 'all',
label: '全部产品',
},
{
value: 'new',
label: '最新产品',
},
{
value: 'hot',
label: '最火产品',
},
{
value: 'disabled',
label: '禁用选项',
disabled: true,
},
],
},
sorter: {
value: 'default',
options: [
{
value: 'default',
label: '默认排序',
},
{
value: 'price',
label: '价格从高到低',
},
],
},
},
methods: {
onChange(e) {
this.setData({
'product.value': e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-dropdown-menu": "tdesign-miniprogram/dropdown-menu/dropdown-menu",
"t-dropdown-item": "tdesign-miniprogram/dropdown-item/dropdown-item"
}
}

```

### 多列下拉菜单

**WXML** (`html`):
```html
<t-dropdown-menu>
<t-dropdown-item
label="单列多选"
options="{{multipleSelect.options}}"
value="{{multipleSelect.value}}"
bindchange="handleMultipleSelect"
multiple
/>
<t-dropdown-item
label="双列多选"
optionsColumns="2"
options="{{doubleColumnsOptions}}"
defaultValue="{{['option_1', 'option_2']}}"
multiple
/>
<t-dropdown-item
label="三列多选"
optionsColumns="3"
options="{{tripleColumnsOptions}}"
defaultValue="{{['option_1', 'option_2', 'option_3']}}"
multiple
/>
</t-dropdown-menu>

```

**JS** (`javascript`):
```javascript
const chineseNumber = '一二三四五六七八九十'.split('');

const singleSelectOptions = new Array(8).fill(null).map((_, i) => ({
label: `选项${chineseNumber[i]}`,
value: `option_${i + 1}`,
disabled: false,
}));

singleSelectOptions.push({
label: '禁用选项',
value: 'disabled',
disabled: true,
});

const doubleColumnsOptions = [
...singleSelectOptions,
{
label: '禁用选项',
value: 'disabled',
disabled: true,
},
];

const tripleColumnsOptions = [
...doubleColumnsOptions,
{
label: '禁用选项',
value: 'disabled',
disabled: true,
},
];

tripleColumnsOptions.splice(8, 0, {
label: `选项${chineseNumber[8]}`,
value: `option_${9}`,
disabled: false,
});

Component({
data: {
multipleSelect: {
value: ['option_1'],
options: singleSelectOptions,
},
doubleColumnsOptions,
tripleColumnsOptions,
},

methods: {
handleMultipleSelect(e) {
this.setData({
'multipleSelect.value': e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-dropdown-menu": "tdesign-miniprogram/dropdown-menu/dropdown-menu",
"t-dropdown-item": "tdesign-miniprogram/dropdown-item/dropdown-item"
}
}

```

### 树形下拉菜单

**WXML** (`html`):
```html
<t-dropdown-menu>
<t-dropdown-item
label="树形双列"
optionsLayout="tree"
options="{{doubleColumnsTree.options}}"
value="{{doubleColumnsTree.value}}"
bindchange="handleTreeSelect"
/>
<t-dropdown-item
label="选项最多八字树形三列"
optionsLayout="tree"
options="{{tripleColumnsTree.options}}"
defaultValue="{{tripleColumnsTree.value}}"
multiple
/>
</t-dropdown-menu>

```

**JS** (`javascript`):
```javascript
const chineseNumber = '一二三四五六七八九十'.split('');

const generateTree = function (deep = 0, count = 10, prefix) {
const ans = [];

for (let i = 0; i < count; i += 1) {
const value = prefix ? `${prefix}-${i}` : `${i}`;
const rect = {
label: `选项${chineseNumber[i]}`,
value,
};

if (deep > 0) {
rect.options = generateTree(deep - 1, 10, value);
}
ans.push(rect);
}

return ans;
};

Component({
data: {
doubleColumnsTree: {
options: generateTree(1),
value: ['0', '0-0'],
},
tripleColumnsTree: {
options: generateTree(2),
value: ['0', '0-0', ['0-0-0', '0-0-1']],
},
},

methods: {
handleTreeSelect(e) {
this.setData({
'doubleColumnsTree.value': e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-dropdown-menu": "tdesign-miniprogram/dropdown-menu/dropdown-menu",
"t-dropdown-item": "tdesign-miniprogram/dropdown-item/dropdown-item"
}
}

```

## API

### DropdownMenuProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| arrow-icon | String / Object | 'caret-down-small' | 自定义箭头图标 | N |
| close-on-click-overlay | Boolean | true | 是否在点击遮罩层后关闭菜单 | N |
| duration | String / Number | 200 | 动画时长 | N |
| show-overlay | Boolean | true | 是否显示遮罩层 | N |
| z-index | Number | 11600 | 菜单栏 z-index 层级 | N |

### DropdownMenuEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| close | - | 菜单关闭时触发 |
| open | - | 菜单展开时触发 |

### DropdownMenuSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### DropdownMenuExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-icon | 图标样式类 |
| t-class-item | 选项样式类 |
| t-class-label | 标签样式类 |

### DropdownItemProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| disabled | Boolean | false | 是否禁用操作项 | N |
| keys | Object | - | 用来定义 value / label / disabled 在`options`中对应的字段别名。TS 类型：`KeysType`。通用类型定义 | N |
| label | String | - | 标题 | N |
| multiple | Boolean | false | 是否多选 | N |
| options | Array | [] | 选项数据。TS 类型：`Array<DropdownOption>``interface DropdownOption { label: string; disabled: boolean; value: DropdownValue; }`。详细类型定义 | N |
| options-columns | String / Number | 1 | 选项分栏（1-3） | N |
| options-layout | String | columns | 已废弃。选项排列；不再支持 tree 布局，可与 treeSelect 配合使用 | N |
| placement | String | left | 复选框和内容相对位置，仅单选菜单栏有效。可选项：left/right | N |
| value | String / Number / Array | undefined | 选中值。TS 类型：`DropdownValue ``type DropdownValue = string \| number \| Array<DropdownValue>;`。详细类型定义 | N |
| default-value | String / Number / Array | undefined | 选中值。非受控属性。TS 类型：`DropdownValue ``type DropdownValue = string \| number \| Array<DropdownValue>;`。详细类型定义 | N |

### DropdownItemEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: DropdownValue)` | 值改变时触发 |
| close | - | 关闭时触发 |
| confirm | `(value: DropdownValue)` | 点击确认时触发 |
| reset | - | 点击重置时触发 |

### DropdownItemSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |
| footer | 底部 |

### DropdownItemExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-column | 菜单列样式类 |
| t-class-column-item | 菜单列选项样式类 |
| t-class-column-item-label | 菜单列选项标签样式类 |
| t-class-content | 内容样式类 |
| t-class-footer | 底部样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-dropdown-menu-active-color | @brand-color | - |
| --td-dropdown-menu-bg-color | @bg-color-container | - |
| --td-dropdown-menu-border-width | 1px | - |
| --td-dropdown-menu-color | @text-color-primary | - |
| --td-dropdown-menu-disabled-color | @text-color-disabled | - |
| --td-dropdown-menu-font-size | 28rpx | - |
| --td-dropdown-menu-height | 96rpx | - |
| --td-dropdown-menu-icon-size | 40rpx | - |
| --td-dropdown-body-max-height | 560rpx | - |

---

# [empty]

# Empty 空状态

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-empty": "tdesign-miniprogram/empty/empty"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/7OvyJMmt8i5y)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 类型

图标空状态

**WXML** (`html`):
```html
<t-empty icon="info-circle-filled" description="描述文字" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-empty": "tdesign-miniprogram/empty/empty"
}
}

```

自定义图片空状态

**WXML** (`html`):
```html
<t-empty t-class="empty-cls" t-class-image="t-empty__image" image="{{image}}" description="描述文字" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
image: 'https://tdesign.gtimg.com/mobile/demos/empty1.png',
},
});

```

**CSS** (`css`):
```css
.t-empty__image {
width: 240rpx !important;
height: 240rpx !important;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-empty": "tdesign-miniprogram/empty/empty"
}
}

```

带操作空状态

**WXML** (`html`):
```html
<t-empty icon="info-circle-filled" description="描述文字">
<t-button slot="action" theme="primary" size="large">操作按钮</t-button>
</t-empty>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-empty": "tdesign-miniprogram/empty/empty",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

## API

### EmptyProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| description | String | - | 描述文字 | N |
| icon | String / Object | - | 图标名称。值为字符串表示图标名称，值为`Object`类型，表示透传至`icon` | N |
| image | String | - | 图片地址 | N |

### EmptySlots

| 名称 | 描述 |
| --- | --- |
| action | 操作按钮 |
| description | 自定义`description`显示内容 |
| image | 自定义`image`显示内容 |

### EmptyExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-description | 描述样式类 |
| t-class-image | 图片样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-empty-action-margin-top | @spacer-4 | - |
| --td-empty-description-color | @text-color-placeholder | - |
| --td-empty-description-font | @font-body-medium | - |
| --td-empty-description-margin-top | @spacer-2 | - |
| --td-empty-icon-color | @text-color-placeholder | - |

---

# [fab]

# Fab 悬浮按钮

## 示例

该组件于 0.7.2 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-fab": "tdesign-miniprogram/fab/fab"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/8ovNaMml8w5n)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础使用

**WXML** (`html`):
```html
<t-fab icon="add" bind:click="handleClick" aria-label="增加"></t-fab>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
handleClick(e) {
console.log(e);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-fab": "tdesign-miniprogram/fab/fab"
}
}

```

### 进阶使用

**WXML** (`html`):
```html
<t-fab icon="add" button-props="{{fabButton}}" bind:click="handleClick" text="分享给朋友" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
fabButton: {
icon: 'share',
openType: 'share',
},
},
methods: {
handleClick(e) {
console.log(e);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-fab": "tdesign-miniprogram/fab/fab"
}
}

```

### 可移动悬浮按钮

**WXML** (`html`):
```html
<t-fab
icon="gesture-press"
text="拖我"
aria-label="增加"
usingCustomNavbar
draggable
y-bounds="{{[0, 32]}}"
bind:click="handleClick"
bind:dragstart="handleDragStart"
bind:dragend="handleDragEnd"
></t-fab>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
handleClick(e) {
console.log('handleClick: ', e);
},

handleDragStart(e) {
console.log('handleDragStart: ', e);
},

handleDragEnd(e) {
console.log('handleDragEnd: ', e);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-fab": "tdesign-miniprogram/fab/fab"
}
}

```

### 带自动收缩功能

**WXML** (`html`):
```html
<t-fab
customStyle="{{scrolling ? 'right: 0;bottom:64px;' : 'right:16px;bottom:24px'}}"
bind:click="handleClick"
bind:dragstart="handleDragStart"
bind:dragend="handleDragEnd"
>
<view wx:if="{{!scrolling}}" class="wrap">
<view class="item">
<t-icon name="add-circle" size="20" />
<view class="text">添加</view>
</view>
<view class="item">
<t-icon name="star" size="20" />
<view class="text">收藏</view>
</view>
<view class="item">
<t-icon name="jump" size="20" />
<view class="text">分享</view>
</view>
</view>
<view wx:else class="symbol">
<t-icon name="chevron-left" size="20" />
</view>
</t-fab>

```

**JS** (`javascript`):
```javascript
import pageScrollMixin from 'tdesign-miniprogram/mixins/page-scroll';

Component({
behaviors: [pageScrollMixin()],
data: {
scrolling: false,
timer: null,
},
methods: {
handleClick(e) {
console.log('handleClick: ', e);
},
handleDragStart(e) {
console.log('handleDragStart: ', e);
},
handleDragEnd(e) {
console.log('handleDragEnd: ', e);
},
onScroll() {
clearTimeout(this.timer);
this.setData({
scrolling: true,
});
this.timer = setTimeout(() => {
this.setData({
scrolling: false,
});
}, 100);
},
},
});

```

**CSS** (`css`):
```css
.wrap {
border: 1px solid #dcdcdc;
display: flex;
flex-direction: column;
align-items: center;
justify-content: space-around;
padding: 8px 0;
border-radius: 22px;
box-shadow: 0px 5px 5px -3px rgba(0, 0, 0, 0.1), 0px 8px 10px 1px rgba(0, 0, 0, 0.06),
0px 3px 14px 2px rgba(0, 0, 0, 0.05);
background: rgba(255, 255, 255, 1);
width: 44px;
height: 156px;
box-sizing: border-box;
}

.item {
width: 100%;
height: 44px;
display: flex;
flex-direction: column;
align-items: center;
justify-content: flex-end;
font-size: 12px;
color: rgba(0, 0, 0, 0.9);
cursor: pointer;
}

.item:not(:last-child) {
margin-bottom: 4px;
}

.text {
height: 20px;
line-height: 20px;
}

.symbol {
width: 32px;
height: 32px;
display: flex;
align-items: center;
justify-content: center;
border-radius: 16px 0 0 16px;
background: #fff;

border: 1px solid #dcdcdc;
border-right: 0;
box-shadow: 0px 5px 5px -3px #0000001a, 0px 8px 10px 1px #0000000f, 0px 3px 14px 2px #0000000d;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-fab": "tdesign-miniprogram/fab/fab",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

## FAQ

### 为什么通过style/customStyle设置top/left调整初试定位后，会使页面内容无法点击以及拖拽异常？

由于 `position: fixed;` 会使得元素脱离文档流，它将悬浮于页面上方。同时，元素没有设置宽高，当同时使用 `top`、`right`、`bottom` 和 `left` 属性时，浏览器会根据给定的 `top`、`right`、`bottom` 和 `left` 创建一个矩形框来容纳元素及其内容，所以会出现元素覆盖页面内容及拖拽异常等问题。

Fab 组件默认定位 `right: 16px; bottom: 32px;`，且拖拽功能也是通过调整 `right` 与 `bottom` 属性值实现，因此在使用 `Fab` 组件时，仅支持通过 `style/customStyle` 属性设置 `right/bottom` 来调整初试位置， 避免使用 `top/left`。

### 开启Skyline渲染引擎后，组件所在页面崩溃？

因为 Skyline 还不支持多层阴影，要等微信官方处理。当下可参考 [#2865](https://github.com/Tencent/tdesign-miniprogram/issues/2865) 进行规避处理

## API

### FabProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| button-props | Object | - | 透传至 Button 组件。TS 类型：`ButtonProps`，Button API Documents。详细类型定义 | N |
| draggable | String / Boolean | false | 是否可拖拽。`true`/`'all'`可拖动<br>`'vertical'`可垂直拖动<br>`'horizontal'`可水平拖动<br>`false`禁止拖动。TS 类型：`boolean \| FabDirectionEnum ``type FabDirectionEnum = 'all' \| 'vertical' \| 'horizontal'`。详细类型定义 | N |
| icon | String | - | 图标 | N |
| text | String | - | 文本内容 | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| y-bounds | Array | - | 设置垂直方向边界限制，示例：[48, 48] 或 ['96px', 80]。TS 类型：`Array<string \| number>` | N |

### FabEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| click | `(detail: {e: Event})` | 悬浮按钮点击事件 |
| drag-end | `(detail: { e: TouchEvent })` | 结束拖拽时触发 |
| drag-start | `(detail: { e: TouchEvent })` | 开始拖拽时触发 |

### FabSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，按钮内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-fab-shadow | @shadow-2 | - |

---

# [footer]

# Footer 页脚

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-footer": "tdesign-miniprogram/footer/footer"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/J6v8BMmr8B5h)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 类型

基础页脚

**WXML** (`html`):
```html
<!-- 基础页脚 只有版权信息 -->
<t-footer text="{{text}}"></t-footer>

```

**JS** (`javascript`):
```javascript
Component({
data: {
text: 'Copyright © 2021-2031 TD.All Rights Reserved.',
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-footer": "tdesign-miniprogram/footer/footer"
}
}

```

基础加链接页脚

**WXML** (`html`):
```html
<!-- theme 为 text，含有底部链接 -->
<view class="footer-example">
<t-footer text="{{text}}" links="{{links[0]}}" />
</view>

<view class="footer-example">
<t-footer text="{{text}}" links="{{links[1]}}" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
text: 'Copyright © 2021-2031 TD.All Rights Reserved.',
links: [
[
{
name: '底部链接',
url: '/pages/index',
openType: 'navigate',
},
],
[
{
name: '底部链接',
url: '/pages/index',
openType: 'navigate',
},
{
name: '底部链接',
url: '',
openType: 'navigateBack',
},
],
],
},
});

```

**CSS** (`css`):
```css
.footer-example {
padding: 8rpx 0;
}

.footer-example:not(:last-child) {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-footer": "tdesign-miniprogram/footer/footer"
}
}

```

品牌页脚

**WXML** (`html`):
```html
<!-- theme 为 logo -->
<view class="footer-example">
<t-footer logo="{{logo}}" />
</view>

<view class="footer-example">
<t-footer
logo="{{{url: theme === 'dark'?'https://tdesign.gtimg.com/mobile/demos/footer-logo-dark.png':'https://tdesign.gtimg.com/mobile/demos/logo1.png'} }}"
/>
</view>

```

**JS** (`javascript`):
```javascript
import themeChangeBehavior from 'tdesign-miniprogram/mixins/theme-change';

Component({
behaviors: [themeChangeBehavior],
data: {
logo: {
icon: 'https://tdesign.gtimg.com/mobile/demos/logo2.png',
title: '品牌名称',
},
},
});

```

**CSS** (`css`):
```css
.footer-example {
padding: 8rpx 0;
}

.footer-example:not(:last-child) {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-footer": "tdesign-miniprogram/footer/footer"
}
}

```

## API

### FooterProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| copyright | String | '' | 已废弃。版权信息，type 为`text`生效 | N |
| links | Array | [] | `1.0.0`。链接列表。name 表示链接名称， url 表示链接 page 路径，目前只支持小程序内部跳转，openType 表示跳转方式。TS 类型：`Array<LinkObj>``interface LinkObj { name: string; url?: string; openType?: 'navigate' \| 'redirect' \| 'relaunch' \| 'switchTab' \| 'navigateBack' }`。详细类型定义 | N |
| logo | Object | - | 图标配置。`logo.icon`表示图标链接地址，`logo.title`表示标题文本，`logo.url`表示链接。TS 类型：`FooterLogo``interface FooterLogo { icon: string; title?: string; url?: string }`。详细类型定义 | N |
| text | String | '' | `1.0.0`。版权信息 | N |
| text-link-list | Array | [] | 已废弃。链接列表，type 为`text`生效。name 表示链接名称， url 表示链接 page 路径，目前只支持小程序内部跳转，openType 表示跳转方式。TS 类型：`Array<LinkObj>``interface LinkObj { name: string; url?: string; openType?: 'navigate' \| 'redirect' \| 'relaunch' \| 'switchTab' \| 'navigateBack' }`。详细类型定义 | N |
| theme | String | 'text' | 已废弃。页脚展示类型。可选项：text/logo | N |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-footer-link-color | @brand-color | - |
| --td-footer-link-dividing-line-color | @text-color-placeholder | - |
| --td-footer-link-dividing-line-padding | @spacer-1 | - |
| --td-footer-link-font | @font-body-medium | - |
| --td-footer-logo-icon-height | 48rpx | - |
| --td-footer-logo-icon-margin-right | @spacer | - |
| --td-footer-logo-icon-width | 48rpx | - |
| --td-footer-logo-title-font | @font-title-medium | - |
| --td-footer-logo-title-url-width | 256rpx | - |
| --td-footer-text-color | @text-color-placeholder | - |
| --td-footer-text-font | @font-body-small | - |
| --td-footer-text-margin-top | 8rpx | - |

---

# [form]

# 组件概览

### 基础6

[Button 按钮](/miniprogram/components/button)   [Divider 分割线](/miniprogram/components/divider)   [Fab 悬浮按钮](/miniprogram/components/fab)   [Icon 图标](/miniprogram/components/icon)   [Layout 布局](/miniprogram/components/layout)   [Link 链接](/miniprogram/components/link)
### 导航8

[BackTop 返回顶部](/miniprogram/components/back-top)   [Drawer 抽屉](/miniprogram/components/drawer)   [Indexes 索引](/miniprogram/components/indexes)   [Navbar 导航条](/miniprogram/components/navbar)   [SideBar 侧边导航栏](/miniprogram/components/side-bar)   [Steps 步骤条](/miniprogram/components/steps)   [TabBar 底部标签栏](/miniprogram/components/tab-bar)   [Tabs 选项卡](/miniprogram/components/tabs)
### 输入16

[Calendar 日历](/miniprogram/components/calendar)   [Cascader 级联选择器](/miniprogram/components/cascader)   [CheckBox 多选框](/miniprogram/components/checkbox)   [ColorPicker 颜色选择器](/miniprogram/components/color-picker)   [DateTimePicker 日期选择器](/miniprogram/components/date-time-picker)   [Input 输入框](/miniprogram/components/input)   [Picker 选择器](/miniprogram/components/picker)   [Radio 单选框](/miniprogram/components/radio)   [Rate 评分](/miniprogram/components/rate)   [Search 搜索框](/miniprogram/components/search)   [Slider 滑动选择器](/miniprogram/components/slider)   [Stepper 步进器](/miniprogram/components/stepper)   [Switch 开关](/miniprogram/components/switch)   [Textarea 多行文本框](/miniprogram/components/textarea)   [TreeSelect 树形选择器](/miniprogram/components/tree-select)   [Upload 上传](/miniprogram/components/upload)
### 数据展示18

[Avatar 头像](/miniprogram/components/avatar)   [Badge 徽章](/miniprogram/components/badge)   [Cell 单元格](/miniprogram/components/cell)   [Collapse 折叠面板](/miniprogram/components/collapse)   [CountDown 倒计时](/miniprogram/components/count-down)   [Empty 空状态](/miniprogram/components/empty)   [Footer 页脚](/miniprogram/components/footer)   [Grid 宫格](/miniprogram/components/grid)   [Image 图片](/miniprogram/components/image)   [ImageViewer 图片预览](/miniprogram/components/image-viewer)   [Progress 进度条](/miniprogram/components/progress)   [QRCode 二维码](/miniprogram/components/qrcode)   [Result 结果](/miniprogram/components/result)   [Skeleton 骨架屏](/miniprogram/components/skeleton)   [Sticky 吸顶容器](/miniprogram/components/sticky)   [Swiper 轮播图](/miniprogram/components/swiper)   [Tag 标签](/miniprogram/components/tag)   [Watermark 水印](/miniprogram/components/watermark)
### 反馈12

[ActionSheet 动作面板](/miniprogram/components/action-sheet)   [Dialog 对话框](/miniprogram/components/dialog)   [DropdownMenu 下拉菜单](/miniprogram/components/dropdown-menu)   [Guide 引导](/miniprogram/components/guide)   [Loading 加载](/miniprogram/components/loading)   [Message 全局提示](/miniprogram/components/message)   [NoticeBar 消息提醒](/miniprogram/components/notice-bar)   [Overlay 遮罩层](/miniprogram/components/overlay)   [Popover 弹出气泡](/miniprogram/components/popover)   [Popup 弹出层](/miniprogram/components/popup)   [PullDownRefresh 下拉刷新](/miniprogram/components/pull-down-refresh)   [SwipeCell 滑动操作](/miniprogram/components/swipe-cell)   [Toast 轻提示](/miniprogram/components/toast)