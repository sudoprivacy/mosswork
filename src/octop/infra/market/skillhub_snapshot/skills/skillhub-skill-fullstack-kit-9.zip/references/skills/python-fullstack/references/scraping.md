# 爬虫工程参考（httpx / Playwright / Scrapy）

## 选型
| 场景 | 方案 | 说明 |
|------|------|------|
| 静态页 / JSON 接口 | `httpx` + `parsel` | 最轻量，优先用 |
| JS 渲染 / 反爬 | `Playwright` (async) | 真实浏览器，能过大部分反爬 |
| 大规模 / 增量 / 分布式 | `Scrapy` | 内置调度、去重、中间件 |

## httpx + parsel（首选）
```python
import httpx, parsel, asyncio

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; Bot/1.0)"}

async def fetch(url: str) -> str:
    async with httpx.AsyncClient(headers=HEADERS, timeout=15, follow_redirects=True) as c:
        r = await c.get(url)
        r.raise_for_status()
        return r.text

def parse(html: str):
    sel = parsel.Selector(html)
    return [s.get().strip() for s in sel.css("a::attr(href)")]
```

## Playwright（反爬 / SPA）
```python
from playwright.async_api import async_playwright

async def scrape(url: str) -> str:
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True)
        pg = await b.new_page()
        await pg.goto(url, wait_until="networkidle")
        await pg.wait_for_selector("article")
        return await pg.content()
```

## 工程纪律（红线）
- **尊重 robots.txt / 频率限制**：默认 `asyncio.Semaphore(5)` 限并发，间隔随机 0.5–2s
- **失败重试**：`tenacity` 包裹，指数退避，最多 3 次；4xx 不重试，5xx 重试
- **不要硬编码 IP / 买代理池**：敏感站点用 `proxy` 参数，凭据走环境变量
- **解析容错**：字段缺失给默认值，不要因单条脏数据中断整个批次
- **合规**：仅爬取公开数据，避开需登录的隐私内容；商用前确认目标站 ToS

## 常见坑
- 中文乱码 → `r.encoding = r.apparent_encoding` 或显式 `utf-8`
- 反爬 403 → 加 `Referer` / `Cookie`，或切 Playwright
- 数据重复 → Scrapy 开 `DUPEFILTER`，自建用 `seen = set()`
- 内存爆 → 流式写入，不要 `list(get_all())` 全量驻留
