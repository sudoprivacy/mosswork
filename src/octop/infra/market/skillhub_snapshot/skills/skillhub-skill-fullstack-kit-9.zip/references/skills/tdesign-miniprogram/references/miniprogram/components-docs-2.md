# 合并文档 第2部分（共3部分，含 20 个组件）


---

# [grid]

# Grid 宫格

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/iDvoiMm78V5c)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

基础宫格

**WXML** (`html`):
```html
<t-grid class="block" column="{{5}}">
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img2}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img3}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img2}}" />
<t-grid-item t-class-image="image" text="最多四字" image="{{img1}}" />
</t-grid>

<t-grid class="block">
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img2}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img3}}" />
<t-grid-item t-class-image="image" text="最多五个字" image="{{img1}}" />
</t-grid>

<t-grid class="block" column="{{3}}">
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img2}}" />
<t-grid-item t-class-image="image" text="最多六个文字" image="{{img3}}" />
</t-grid>

```

**JS** (`javascript`):
```javascript
Component({
data: {
img1: 'https://tdesign.gtimg.com/mobile/demos/example1.png',
img2: 'https://tdesign.gtimg.com/mobile/demos/example2.png',
img3: 'https://tdesign.gtimg.com/mobile/demos/example3.png',
},
});

```

**CSS** (`css`):
```css
.block {
display: block;
margin-bottom: 32rpx;
}

.block .image {
position: inherit;
}

.block .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

带说明的宫格

**WXML** (`html`):
```html
<view class="block">
<t-grid column="{{3}}">
<t-grid-item t-class-image="image" text="标题文字" description="描述文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" description="描述文字" image="{{img2}}" />
<t-grid-item t-class-image="image" text="标题文字" description="描述文字" image="{{img3}}" />
</t-grid>
</view>

<view class="block">
<t-grid column="{{2}}" align="left">
<t-grid-item t-class-image="image" text="标题文字" description="描述文字" layout="horizontal" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" description="描述文字" layout="horizontal" image="{{img2}}" />
</t-grid>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
img1: 'https://tdesign.gtimg.com/mobile/demos/example1.png',
img2: 'https://tdesign.gtimg.com/mobile/demos/example2.png',
img3: 'https://tdesign.gtimg.com/mobile/demos/example3.png',
},
});

```

**CSS** (`css`):
```css
.block {
display: block;
margin-bottom: 32rpx;
}

.block .image {
position: inherit;
}

.block .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

带边框的宫格

**WXML** (`html`):
```html
<view class="block">
<t-grid border="{{border}}" column="{{3}}">
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img2}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img3}}" />
</t-grid>
</view>

<view class="block">
<t-grid border="{{border}}" column="{{2}}" align="left">
<t-grid-item t-class-image="image" text="标题文字" description="描述文字" layout="horizontal" image="{{img1}}" />
<t-grid-item
t-class-image="image"
text="标题最多六字"
description="描述文字"
layout="horizontal"
image="{{img2}}"
/>
</t-grid>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
img1: 'https://tdesign.gtimg.com/mobile/demos/example1.png',
img2: 'https://tdesign.gtimg.com/mobile/demos/example2.png',
img3: 'https://tdesign.gtimg.com/mobile/demos/example3.png',
border: {
color: 'var(--td-border-level-1-color, #E7E7E7)',
},
},
});

```

**CSS** (`css`):
```css
.block {
display: block;
margin-bottom: 32rpx;
}

.block .image {
position: inherit;
}

.block .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

带徽章的宫格

**WXML** (`html`):
```html
<t-grid class="t-grid badge">
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" badge-props="{{ { dot: true } }}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img2}}" badge-props="{{ { count: 8 } }}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img3}}" badge-props="{{ { count: 13 } }}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img3}}" badge-props="{{ { count: 'NEW' } }}" />
</t-grid>

```

**JS** (`javascript`):
```javascript
Component({
data: {
img1: 'https://tdesign.gtimg.com/mobile/demos/example1.png',
img2: 'https://tdesign.gtimg.com/mobile/demos/example2.png',
img3: 'https://tdesign.gtimg.com/mobile/demos/example3.png',
},
});

```

**CSS** (`css`):
```css
.external-class-content {
padding: 32rpx 0 !important;
}

.text {
font-size: 24rpx !important;
line-height: 40rpx !important;
padding-top: 20rpx !important;
}
.image {
width: 64rpx !important;
height: 64rpx !important;
}
.image-icon {
width: 64rpx;
height: 64rpx;
}

.badge-circle {
display: flex;
justify-content: center;
background-color: #e34d59;
border-radius: 15rpx;
width: 36rpx;
height: 32rpx;
align-items: center;
position: absolute;
top: -15rpx;
left: 46rpx;
}

.circle {
width: 4rpx;
height: 4rpx;
border-radius: 2rpx;
background-color: white;
margin-left: 4rpx;
}

.badge-circle-container {
margin-left: -4rpx;
display: flex;
}

.badge .image {
position: inherit;
}

.badge .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

可滑动的宫格

**WXML** (`html`):
```html
<t-grid class="block" column="{{0}}">
<t-grid-item
wx:for="{{gridItemList}}"
wx:key="index"
t-class-image="image"
text="{{item.text}}"
image="{{item.img}}"
/>
</t-grid>

```

**JS** (`javascript`):
```javascript
Component({
data: {
gridItemList: [
{
text: '标题文字',
img: 'https://tdesign.gtimg.com/mobile/demos/example1.png',
},
{
text: '标题文字',
img: 'https://tdesign.gtimg.com/mobile/demos/example2.png',
},
{
text: '标题文字',
img: 'https://tdesign.gtimg.com/mobile/demos/example3.png',
},
{
text: '最多五个字',
img: 'https://tdesign.gtimg.com/mobile/demos/example1.png',
},
{
text: '最多五个字',
img: 'https://tdesign.gtimg.com/mobile/demos/example2.png',
},
{
text: '最多五个字',
img: 'https://tdesign.gtimg.com/mobile/demos/example3.png',
},
],
},
});

```

**CSS** (`css`):
```css
.block {
display: block;
margin-bottom: 32rpx;
}

.block .image {
position: inherit;
}

.block .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

### 组件样式

可传图标的宫格

**WXML** (`html`):
```html
<t-grid class="block">
<t-grid-item text="分享" image="slot">
<view slot="image" class="grid-item__image">
<t-button variant="text" icon="share" open-type="share"></t-button>
</view>
</t-grid-item>
<t-grid-item text="收藏" icon="star" bindclick="onClick" />
<t-grid-item text="保存" icon="download" bindclick="onClick" />
<t-grid-item text="编辑" icon="edit-1" bindclick="onClick" />
</t-grid>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
onClick() {
console.log('click grid-item');
},
},
});

```

**CSS** (`css`):
```css
.block {
display: block;
margin-bottom: 32rpx;
}

.grid-item__image {
height: 100%;
display: flex;
align-items: center;
justify-content: center;
overflow: hidden;
background-color: var(--td-bg-color-secondarycontainer);
border-radius: 12rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

多行宫格

**WXML** (`html`):
```html
<t-grid class="block" column="{{4}}">
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img2}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img3}}" />
<t-grid-item t-class-image="image" text="最多五个字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img3}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="最多五个字" image="{{img2}}" />
</t-grid>

```

**JS** (`javascript`):
```javascript
Component({
data: {
img1: 'https://tdesign.gtimg.com/mobile/demos/example1.png',
img2: 'https://tdesign.gtimg.com/mobile/demos/example2.png',
img3: 'https://tdesign.gtimg.com/mobile/demos/example3.png',
},
});

```

**CSS** (`css`):
```css
.block {
display: block;
margin-bottom: 32rpx;
}

.block .image {
position: inherit;
}

.block .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

卡片宫格

**WXML** (`html`):
```html
<view class="block">
<t-grid column="{{4}}" theme="card">
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img2}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img3}}" />
<t-grid-item t-class-image="image" text="最多五个字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img1}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img3}}" />
<t-grid-item t-class-image="image" text="标题文字" image="{{img2}}" />
<t-grid-item t-class-image="image" text="最多五个字" image="{{img2}}" />
</t-grid>
</view>

<view class="block">
<t-grid border="{{border}}" column="{{2}}" theme="card" align="left">
<t-grid-item t-class-image="image" text="标题文字" description="描述文字" layout="horizontal" image="{{img1}}" />
<t-grid-item
t-class-image="image"
text="标题最多六字"
description="描述文字"
layout="horizontal"
image="{{img2}}"
/>
</t-grid>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
img1: 'https://tdesign.gtimg.com/mobile/demos/example1.png',
img2: 'https://tdesign.gtimg.com/mobile/demos/example2.png',
img3: 'https://tdesign.gtimg.com/mobile/demos/example3.png',
},
});

```

**CSS** (`css`):
```css
.block {
display: block;
margin-bottom: 32rpx;
}

.block .image {
position: inherit;
}

.block .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

## API

### GridProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| align | String | center | 内容对齐方式。可选项：left/center | N |
| border | Boolean / Object | false | 边框，默认不显示。值为 true 则显示默认边框，值类型为 object 则表示自定义边框样式。TS 类型：`boolean \| { color?: string; width?: string; style?: 'solid' \| 'dashed' \| 'dotted' \| 'double' \| 'groove' \| 'inset' \| 'outset' }` | N |
| column | Number | 4 | 每一行的列数量；为 0 时等于固定大小 | N |
| gutter | Number | - | 间隔大小 | N |
| hover | Boolean | false | 是否开启点击反馈 | N |
| theme | String | default | 宫格的风格。可选项：default/card | N |

### GridSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### GridExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |

### GridItemProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| badge-props | Object | null | 透传至 Badge 属性。TS 类型：`BadgeProps`，Badge API Documents。详细类型定义 | N |
| description | String | - | 文本以外的更多描述，辅助信息。可以通过 Props 传入文本，也可以自定义标题节点 | N |
| icon | String / Object | - | 图标名称。值为字符串表示图标名称，值为`Object`类型，表示透传至`icon` | N |
| image | String | - | 图片，可以是图片地址，也可以自定义图片节点，值为 slot 的时候才能使用插槽 | N |
| image-props | Object | - | 透传至 Image 组件。TS 类型：`ImageProps`，Image API Documents。详细类型定义 | N |
| jump-type | String | navigate-to | 链接跳转类型。可选项：redirect-to/switch-tab/relaunch/navigate-to | N |
| layout | String | vertical | 内容布局方式。可选项：vertical/horizontal | N |
| text | String | - | 文本，可以通过 Props 传入文本，也可以自定义标题节点 | N |
| url | String | - | 点击后的跳转链接 | N |

### GridItemEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| click | - | 点击子项后触发 |

### GridItemSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |
| description | 自定义`description`模块内容 |
| image | 自定义`image`模块内容 |
| text | 自定义`text`模块内容 |

### GridItemExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |
| t-class-description | 描述样式类 |
| t-class-image | 图片样式类 |
| t-class-text | 文本样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-grid-bg-color | @bg-color-container | - |
| --td-grid-card-radius | @radius-large | - |
| --td-grid-item-bg-color | @bg-color-container | - |
| --td-grid-item-description-color | @text-color-placeholder | - |
| --td-grid-item-description-font | @font-body-small | - |
| --td-grid-item-description-padding-top | 0 | - |
| --td-grid-item-horizontal-text-description-top | 0 | - |
| --td-grid-item-horizontal-text-padding-left | 0 | - |
| --td-grid-item-hover-bg-color | @bg-color-secondarycontainer | - |
| --td-grid-item-image-middle-width | 80rpx | - |
| --td-grid-item-image-small-width | 64rpx | - |
| --td-grid-item-image-width | 96rpx | - |
| --td-grid-item-padding | 32rpx | - |
| --td-grid-item-text-color | @text-color-primary | - |
| --td-grid-item-text-font | @font-body-medium | - |
| --td-grid-item-text-middle-font | @font-body-small | - |
| --td-grid-item-text-padding-top | 16rpx | - |
| --td-grid-item-text-small-font | @font-body-extraSmall | - |

---

# [guide]

# Guide 引导

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-guide": "tdesign-miniprogram/guide/guide"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/P7xJCMmR8H5k)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

#### 基础按钮

**WXML** (`html`):
```html
<view>
<view class="main-title">
<view class="title-major">用户引导标题</view>
<view class="title-sub"> 按钮用于开启一个闭环的操作任务，如“删除”对象、“购买”商品等。 </view>
</view>
<view class="field label-field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="action">
<t-button block theme="light" size="large">重置</t-button>
<t-button block theme="primary" size="large">确定</t-button>
</view>
</view>

<t-guide current="{{current}}" steps="{{steps}}" bind:skip="close" bind:finish="close">
<view slot="body-2" class="slot-body">slot展示 用户引导的说明文案</view>
</t-guide>

```

**JS** (`javascript`):
```javascript
Component({
data: {
current: -1,
steps: [],
},
lifetimes: {
attached() {
this.setData({
current: 0,
steps: [
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.main-title')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
body: '用户引导的说明文案',
placement: 'center',
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.label-field')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
body: '用户引导的说明文案',
placement: 'bottom',
highlightPadding: 0,
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.action')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
// body: '用户引导的说明文案',
placement: 'bottom-right',
},
],
});
},
},
methods: {
close() {
this.triggerEvent('close');
},
},
});

```

**CSS** (`css`):
```css
.main-title {
margin: 32rpx;
display: inline-block;
}

.title-major {
font-size: 48rpx;
font-weight: 600;
line-height: 72rpx;
}

.title-sub {
font-size: 32rpx;
font-weight: 400;
line-height: 48rpx;
margin-top: 8rpx;
}

.action {
margin: 64rpx;
display: grid;
grid-template-columns: repeat(2, 1fr);
gap: 64rpx;
}

.slot-body {
margin-top: 8rpx;
text-align: left;
color: var(--td-text-color-secondary);
font-size: 28rpx;
font-weight: 400;
line-height: 44rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-guide": "tdesign-miniprogram/guide/guide",
"t-input": "tdesign-miniprogram/input/input",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

#### 不带遮罩的引导

**WXML** (`html`):
```html
<view>
<view class="main-title">
<view class="title-major">用户引导标题</view>
<view class="title-sub"> 按钮用于开启一个闭环的操作任务，如“删除”对象、“购买”商品等。 </view>
</view>
<view class="field label-field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="action">
<t-button block theme="light" size="large">重置</t-button>
<t-button block theme="primary" size="large">确定</t-button>
</view>
</view>

<t-guide current="{{current}}" steps="{{steps}}" show-overlay="{{false}}" bind:skip="close" bind:finish="close" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
current: -1,
steps: [],
},
lifetimes: {
attached() {
this.setData({
current: 0,
steps: [
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.main-title')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
body: '用户引导的说明文案',
placement: 'center',
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.label-field')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
body: '用户引导的说明文案',
placement: 'bottom',
highlightPadding: 0,
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.action')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
body: '用户引导的说明文案',
placement: 'top-right',
},
],
});
},
},
methods: {
close() {
this.triggerEvent('close');
},
},
});

```

**CSS** (`css`):
```css
.main-title {
margin: 32rpx;
display: inline-block;
}

.title-major {
font-size: 48rpx;
font-weight: 600;
line-height: 72rpx;
}

.title-sub {
font-size: 32rpx;
font-weight: 400;
line-height: 48rpx;
margin-top: 8rpx;
}

.action {
margin: 64rpx;
display: grid;
grid-template-columns: repeat(2, 1fr);
gap: 64rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-guide": "tdesign-miniprogram/guide/guide",
"t-input": "tdesign-miniprogram/input/input",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

#### 弹窗形式的引导

**WXML** (`html`):
```html
<view>
<view class="main-title">
<view class="title-major">用户引导标题</view>
<view class="title-sub"> 按钮用于开启一个闭环的操作任务，如“删除”对象、“购买”商品等。 </view>
</view>
<view class="field label-field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="action">
<t-button block theme="light" size="large">重置</t-button>
<t-button block theme="primary" size="large">确定</t-button>
</view>
</view>

<t-guide current="{{current}}" steps="{{steps}}" mode="dialog" bind:skip="close" bind:finish="close">
<view slot="body-0" class="slot-body">
<p>用户引导的说明文案 0</p>
<t-image
class="guide-demo-image"
src="https://tdesign.gtimg.com/demo/demo-image-1.png"
mode="scaleToFill"
width="100%"
></t-image>
</view>
<view slot="body-1" class="slot-body">
<p>用户引导的说明文案 1</p>
<t-image
class="guide-demo-image"
src="https://tdesign.gtimg.com/demo/demo-image-1.png"
mode="scaleToFill"
width="100%"
></t-image>
</view>
<view slot="body-2" class="slot-body">
<p>用户引导的说明文案 2</p>
<t-image
class="guide-demo-image"
src="https://tdesign.gtimg.com/demo/demo-image-1.png"
mode="scaleToFill"
width="100%"
></t-image>
</view>
</t-guide>

```

**JS** (`javascript`):
```javascript
Component({
data: {
current: -1,
steps: [],
},
lifetimes: {
attached() {
this.setData({
current: 0,
steps: [
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.main-title')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
placement: 'center',
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.label-field')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
placement: 'bottom',
highlightPadding: 0,
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.action')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
placement: 'bottom-right',
},
],
});
},
},
methods: {
close() {
this.triggerEvent('close');
},
},
});

```

**CSS** (`css`):
```css
.main-title {
margin: 32rpx;
display: inline-block;
}

.title-major {
font-size: 48rpx;
font-weight: 600;
line-height: 72rpx;
}

.title-sub {
font-size: 32rpx;
font-weight: 400;
line-height: 48rpx;
margin-top: 8rpx;
}

.action {
margin: 64r px;
display: grid;
grid-template-columns: repeat(2, 1fr);
gap: 64rpx;
}

.slot-body {
margin-top: 8rpx;
text-align: center;
color: var(--td-text-color-secondary);
font-size: 32rpx;
font-weight: 400;
line-height: 48rpx;
}

.slot-body .guide-demo-image {
margin-top: 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-guide": "tdesign-miniprogram/guide/guide",
"t-input": "tdesign-miniprogram/input/input",
"t-button": "tdesign-miniprogram/button/button",
"t-image": "tdesign-miniprogram/image/image"
}
}

```

#### 气泡与弹窗混合的引导

**WXML** (`html`):
```html
<view>
<view class="main-title">
<view class="title-major">用户引导标题</view>
<view class="title-sub"> 按钮用于开启一个闭环的操作任务，如“删除”对象、“购买”商品等。 </view>
</view>
<view class="field label-field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="action">
<t-button block theme="light" size="large">重置</t-button>
<t-button block theme="primary" size="large">确定</t-button>
</view>
</view>

<t-guide current="{{current}}" steps="{{steps}}" bind:skip="close" bind:finish="close">
<view slot="body-1" class="slot-body">
<p>用户引导的说明文案 1</p>
<t-image
class="guide-demo-image"
src="https://tdesign.gtimg.com/demo/demo-image-1.png"
mode="scaleToFill"
width="100%"
></t-image>
</view>
</t-guide>

```

**JS** (`javascript`):
```javascript
Component({
data: {
current: -1,
steps: [],
},
lifetimes: {
attached() {
this.setData({
current: 0,
steps: [
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.main-title')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
body: '用户引导的说明文案',
placement: 'center',
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.label-field')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
placement: 'bottom',
mode: 'dialog',
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.action')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
title: '用户引导标题',
body: '用户引导的说明文案',
placement: 'bottom-right',
},
],
});
},
},
methods: {
close() {
this.triggerEvent('close');
},
},
});

```

**CSS** (`css`):
```css
.main-title {
margin: 32rpx;
display: inline-block;
}

.title-major {
font-size: 48rpx;
font-weight: 600;
line-height: 72rpx;
}

.title-sub {
font-size: 32rpx;
font-weight: 400;
line-height: 48rpx;
margin-top: 8rpx;
}

.action {
margin: 63rpx;
display: grid;
grid-template-columns: repeat(2, 1fr);
gap: 63rpx;
}

.slot-body {
margin-top: 8rpx;
text-align: center;
color: var(--td-text-color-secondary);
font-size: 32rpx;
font-weight: 400;
line-height: 48rpx;
}

.slot-body .guide-demo-image {
margin-top: 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-guide": "tdesign-miniprogram/guide/guide",
"t-input": "tdesign-miniprogram/input/input",
"t-button": "tdesign-miniprogram/button/button",
"t-image": "tdesign-miniprogram/image/image"
}
}

```

#### 自定义气泡

**WXML** (`html`):
```html
<view>
<view class="main-title">
<view class="title-major">用户引导标题</view>
<view class="title-sub"> 按钮用于开启一个闭环的操作任务，如“删除”对象、“购买”商品等。 </view>
</view>
<view class="field label-field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="field">
<t-input label="标签文字" layout="vertical" placeholder="请输入文字"></t-input>
</view>
<view class="action">
<t-button block theme="light" size="large">重置</t-button>
<t-button block theme="primary" size="large">确定</t-button>
</view>
</view>

<t-guide current="{{current}}" steps="{{steps}}" bind:skip="close" bind:finish="close">
<view slot="content-0" class="content">
<t-icon name="arrow-up" size="64rpx" color="#fff" class="icon" />
<p class="text">1、自定义的图形或说明文案，用来解释或指导该功能使用。</p>
<view class="footer">
<t-button
wx:if="{{current < steps.length - 1}}"
theme="light"
content="跳过"
size="extra-small"
bindtap="skip"
class="guide-demo-button"
></t-button>
<t-button
wx:else
class="guide-demo-button"
theme="light"
content="返回"
size="extra-small"
bindtap="back"
></t-button>
<t-button
wx:if="{{current < steps.length - 1}}"
theme="primary"
content="下一步"
size="extra-small"
bindtap="next"
class="guide-demo-button"
></t-button>
<t-button
wx:else
class="guide-demo-button"
theme="primary"
content="完成"
size="extra-small"
bindtap="finish"
></t-button>
</view>
</view>
<view slot="content-1" class="content">
<t-icon name="arrow-up" size="64rpx" color="#fff" class="icon" />
<p class="text">2、自定义的图形或说明文案，用来解释或指导该功能使用。</p>
<view class="footer">
<t-button
wx:if="{{current < steps.length - 1}}"
theme="light"
content="跳过"
size="extra-small"
bindtap="skip"
class="guide-demo-button"
></t-button>
<t-button
wx:else
class="guide-demo-button"
theme="light"
content="返回"
size="extra-small"
bindtap="back"
></t-button>
<t-button
wx:if="{{current < steps.length - 1}}"
theme="primary"
content="下一步"
size="extra-small"
bindtap="next"
class="guide-demo-button"
></t-button>
<t-button
wx:else
class="guide-demo-button"
theme="primary"
content="完成"
size="extra-small"
bindtap="finish"
></t-button>
</view>
</view>
<view slot="content-2" class="content">
<t-icon name="arrow-up" size="64rpx" color="#fff" class="icon" />
<p class="text">3、自定义的图形或说明文案，用来解释或指导该功能使用。</p>
<view class="footer">
<t-button
wx:if="{{current < steps.length - 1}}"
theme="light"
content="跳过"
size="extra-small"
bindtap="skip"
class="guide-demo-button"
></t-button>
<t-button
wx:else
class="guide-demo-button"
theme="light"
content="返回"
size="extra-small"
bindtap="back"
></t-button>
<t-button
wx:if="{{current < steps.length - 1}}"
theme="primary"
content="下一步"
size="extra-small"
bindtap="next"
class="guide-demo-button"
></t-button>
<t-button
wx:else
class="guide-demo-button"
theme="primary"
content="完成"
size="extra-small"
bindtap="finish"
></t-button>
</view>
</view>
</t-guide>

```

**JS** (`javascript`):
```javascript
Component({
data: {
current: -1,
steps: [],
},
lifetimes: {
attached() {
this.setData({
current: 0,
steps: [
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.main-title')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
placement: 'center',
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.label-field')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
placement: 'bottom',
highlightPadding: 0,
},
{
element: () =>
new Promise((resolve) =>
this.createSelectorQuery()
.select('.action')
.boundingClientRect((rect) => resolve(rect))
.exec(),
),
placement: 'bottom-right',
},
],
});
},
},
methods: {
close() {
this.triggerEvent('close');
},
skip() {
this.setData({ current: -1 });
this.close();
},
back() {
this.setData({ current: 0 });
},
next() {
this.setData({ current: this.data.current + 1 });
},
finish() {
this.setData({ current: -1 });
this.close();
},
},
});

```

**CSS** (`css`):
```css
.main-title {
margin: 32rpx;
display: inline-block;
}

.title-major {
font-size: 48rpx;
font-weight: 600;
line-height: 72rpx;
}

.title-sub {
font-size: 32rpx;
font-weight: 400;
line-height: 48rpx;
margin-top: 8rpx;
}

.action {
margin: 64rpx;
display: grid;
grid-template-columns: repeat(2, 1fr);
gap: 64rpx;
}

.content {
width: 480rpx;
}

.content .icon {
font-weight: 700;
width: 64rpx;
}

.content .text {
margin-top: 32rpx;
color: #fff;
font-size: 32rpx;
font-weight: 600;
text-align: left;
line-height: 48rpx;
}

.content .footer {
text-align: right;
margin-top: 32rpx;
}

.content .footer .guide-demo-button + .guide-demo-button {
margin-left: 24rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-guide": "tdesign-miniprogram/guide/guide",
"t-input": "tdesign-miniprogram/input/input",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

## API

### GuideProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| back-button-props | Object | - | 透传 返回按钮 的全部属性，示例：`{ content: '返回', theme: 'default' }`。TS 类型：`ButtonProps` | N |
| counter | String / Function | - | 用于自定义渲染计数部分。TS 类型：`string \| ((params: { total: number; current: number }) => string)` | N |
| current | Number | - | 当前步骤，即整个引导的进度。-1 则不展示，用于需要中断展示的场景 | N |
| default-current | Number | undefined | 当前步骤，即整个引导的进度。-1 则不展示，用于需要中断展示的场景。非受控属性 | N |
| finish-button-props | Object | - | 透传 完成按钮 的全部属性，示例：`{ content: '完成', theme: 'primary' }`。TS 类型：`ButtonProps` | N |
| hide-back | Boolean | false | 是否隐藏返回按钮 | N |
| hide-counter | Boolean | false | 是否隐藏计数 | N |
| hide-skip | Boolean | false | 是否隐藏跳过按钮 | N |
| highlight-padding | Number | 16 | 高亮框的内边距，单位rpx | N |
| mode | String | popover | 引导框的类型。可选项：popover/dialog | N |
| next-button-props | Object | - | 透传 下一步按钮 的全部属性，示例：{ content: '下一步', theme: 'primary' }。TS 类型：`ButtonProps`，Button API Documents。详细类型定义 | N |
| show-overlay | Boolean | true | 是否出现遮罩层 | N |
| skip-button-props | Object | - | 透传 跳过按钮 的全部属性，{ content: '跳过', theme: 'default' }。TS 类型：`ButtonProps` | N |
| steps | Array | - | 用于定义每个步骤的内容，包括高亮的节点、相对位置和具体的文案内容等。TS 类型：`Array<GuideStep>` | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| z-index | Number | 999999 | 提示框的层级 | N |

### GuideEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| back | `(detail: { current: number, total: number  })` | 点击返回按钮时触发 |
| change | `(current: number, context?: {  total: number })` | 当前步骤发生变化时触发 |
| finish | `(detail: { current: number, total: number  })` | 点击完成按钮时触发 |
| next-step-click | `(detail: { next: number, current: number, total: number  })` | 点击下一步时触发 |
| skip | `(detail: { current: number, total: number  })` | 点击跳过按钮时触发 |

### GuideExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-back | 返回按钮样式类 |
| t-class-body | 高亮框提示内容主体样式类 |
| t-class-finish | 结束按钮样式类 |
| t-class-footer | 高亮框底部操作区域样式类 |
| t-class-next | 下一步按钮样式类 |
| t-class-popover | 引导框样式类 |
| t-class-reference | 高亮框样式类 |
| t-class-skip | 跳过按钮样式类 |
| t-class-title | 高亮框提示内容标题样式类 |
| t-class-tooltip | 高亮框提示内容区域样式类 |

### GuideStep

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| back-button-props | Object | - | 用于自定义当前引导框的返回按钮的内容。TS 类型：`ButtonProps` | N |
| body | String | - | 当前步骤提示框的内容，支持插槽：slot="body-{{index}}" (1、当要显示body-{{index}}插槽时，请将body设置为空；2、当要显示content-{{index}}插槽完全自定义内容时，请将body和title都设置为空) | N |
| element | Function | - | 必需。高亮的节点。示例：`() => new Promise((resolve) => this.createSelectorQuery().select('#tdesign').boundingClientRect((rect) => resolve(rect)).exec())`。TS 类型：`StepElement``type StepElement = () => Promise<WechatMiniprogram.BoundingClientRectCallbackResult>`。详细类型定义 | Y |
| finish-button-props | Object | - | 透传 完成 的全部属性，示例：`{ content: '完成', theme: 'primary' }`。TS 类型：`ButtonProps` | N |
| highlight-padding | Number | - | 高亮框的内边距，单位rpx | N |
| mode | String | - | 引导框的类型。可选项：popover/dialog | N |
| next-button-props | Object | - | 用于自定义当前引导框的下一步按钮的内容。TS 类型：`ButtonProps` | N |
| offset | Array | - | 相对于 placement 的偏移量[left, top]，默认单位rpx，示例：[-10, 20] 或 ['10px', '8px'] 或 ['20rpx', '16rpx'] (仅当`mode`为`popover`时生效)。TS 类型：`Array<string \| number>` | N |
| placement | String | 'top' | 引导框相对于高亮元素出现的位置，(仅当`mode`为`popover`时生效)。TS 类型：`StepPopoverPlacement ``type StepPopoverPlacement = 'top'\|'left'\|'right'\|'bottom'\|'top-left'\|'top-right'\|'bottom-left'\|'bottom-right'\|'left-top'\|'left-bottom'\|'right-top'\|'right-bottom'\|'center'`。详细类型定义 | N |
| show-overlay | Boolean | true | 是否出现遮罩层 | N |
| skip-button-props | Object | - | 用于自定义当前步骤引导框的跳过按钮的内容。TS 类型：`ButtonProps` | N |
| title | String | - | 当前步骤的标题内容，支持插槽：slot="title-{{index}}" (1、当要显示body-{{index}}插槽时，请将title设置为空；2、当要显示content-{{index}}插槽完全自定义内容时，请将body和title都设置为空) | N |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-guide-body-color | @text-color-secondary | - |
| --td-guide-dialog-body-font | @font-body-large | - |
| --td-guide-dialog-body-margin-top | 16rpx | - |
| --td-guide-dialog-body-text-align | center | - |
| --td-guide-dialog-border-radius | @radius-extraLarge | - |
| --td-guide-dialog-footer-button-padding | 0 @spacer-3 | - |
| --td-guide-dialog-padding | @spacer-3 0 | - |
| --td-guide-dialog-title-font | @font-title-large | - |
| --td-guide-dialog-title-text-align | center | - |
| --td-guide-dialog-width | 622rpx | - |
| --td-guide-footer-button-space | @spacer-1 | - |
| --td-guide-footer-margin-top | @spacer-3 | - |
| --td-guide-footer-text-align | right | - |
| --td-guide-popover-bg-color | @bg-color-container | - |
| --td-guide-popover-body-font | @font-body-medium | - |
| --td-guide-popover-body-margin-top | 8rpx | - |
| --td-guide-popover-body-text-align | left | - |
| --td-guide-popover-border | 2rpx solid @component-border | - |
| --td-guide-popover-border-radius | @radius-large | - |
| --td-guide-popover-max-width | 540rpx | - |
| --td-guide-popover-min-width | 480rpx | - |
| --td-guide-popover-padding | @spacer-2 | - |
| --td-guide-popover-shadow | @shadow-3 | - |
| --td-guide-popover-title-font | @font-title-medium | - |
| --td-guide-popover-title-text-align | left | - |
| --td-guide-reference-border | 4rpx solid @brand-color | - |
| --td-guide-reference-border-radius | @radius-default | - |
| --td-guide-reference-mask-color | @font-gray-2 | - |
| --td-guide-title-color | @text-color-primary | - |

---

# [icon]

# Icon 图标

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-icon": "tdesign-miniprogram/icon/icon"
}
```

## 常见问题

控制台告警：Failed to load font 👇
告警属于开发者工具的 bug，可以忽略，具体可以看 [官网文档](https://developers.weixin.qq.com/miniprogram/dev/api/ui/font/wx.loadFontFace.html)

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/7OxuPMmW8X5w)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础组件图标

**WXML** (`html`):
```html
<view class="demo__list">
<view class="demo__card" wx:for="{{icons}}" wx:key="index">
<t-icon name="{{item}}" size="48rpx" data-name="{{item}}" bind:click="onIconTap" />
<view class="demo__card-name">{{item}}</view>
</view>
</view>

```

**JS** (`javascript`):
```javascript
import icons from '../data';

Component({
data: {
icons,
},

methods: {
onIconTap(event) {
const { name, type } = event.currentTarget.dataset;
if (type === 'prefix') return;
wx.showToast({ title: name, icon: 'none', duration: 1000 });
},
},
});

```

**CSS** (`css`):
```css
.demo__list {
display: flex;
flex-wrap: wrap;
padding: 16rpx 32rpx;
}

.demo__card {
flex: 0 0 25%;
text-align: center;
margin-bottom: 30rpx;
color: var(--td-text-color-primary);
}

.demo__card-name {
font-size: 24rpx;
color: #999;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

### 自定义组件图标

**WXML** (`html`):
```html
<view class="demo__list">
<view class="demo__card" wx:for="{{prefixIcons}}" wx:key="index">
<t-icon name="{{item}}" size="48rpx" prefix="icon" data-name="{{item}}" data-type="prefix" bind:click="onIconTap" />
<view class="demo__card-name">{{item}}</view>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
prefixIcons: ['a-0', 'a-1h', 'a-2h', 'a-3h'],
},
methods: {
onIconTap(event) {
const { name, type } = event.currentTarget.dataset;
if (type === 'prefix') return;
wx.showToast({ title: name, icon: 'none', duration: 1000 });
},
},
});

```

**CSS** (`css`):
```css
.demo__list {
display: flex;
flex-wrap: wrap;
padding: 16rpx 32rpx;
}

.demo__card {
flex: 0 0 25%;
text-align: center;
}

.demo__card-name {
font-size: 24rpx;
color: #999;
}

/* 自定义图标 */
@font-face {
font-family: 'icon'; /* Project id 3144196 */
src: url('data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAAAPUAAsAAAAACGAAAAOFAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHFQGYACDGgqEPIQBATYCJAMUCwwABCAFhDcHQhtVBxHVmy/JfhzGjunMd9u7ZdNoJGL95+B5ckPfvzsIgZjoVHHRKe1qNlEdfUoAPFpzlgKhvLdV7dpf4MyYhRbmw1+ObxM9+wDSmJP2okWn0XkEe1sWSOAJJR4mYA3TSx7kD48ggEsZ9VFNm7ftSsjYQVPHk4DBlwpUtTJ21IhBONyBmagVHAR76U6DbMQCtUo9BzZk75cfVIgDCkvjn9NxeLOhPPTb+R31wtqF6PckEgQ4WwEWoIGih7mk93SgK7pIF6FxhwKGPDTZIOB3rK312yWKZ//hgaDQGBAbvzoIgIYwY8BvFxEI+O0JFPgdCDT4HVVfpN0CwAWWfQ68w1yWUQUvFRUUEJMZ0zBmzKILZ26suXbqHGrh2ZNXV18/fV68hafWnInRi06vPskQ3VV6eKqH9vB2nPDWbNu2C1xZtH31VhgiPfbE7kmo2ba78+R9oy6cueOtuXVuHwt3+kNEdfVYNWfEmhMii067q3cK6kYqetu26F2w6GjUtlO79uXprVE7b7r38YsHl62wxmwPBrvdDvyl7A2Os2v65berseOS461n/fL6PbPim4dlpFSGJIdmpmSGMm3NvmaVrZtVNPePPcwtGCU9i0KcX3dKyKGCTUFnY9aHrCNjTeN5PzcGxQd6498Eh4WH5zXPjbbvdIxJHLz4dnx4QLNlC4Y/nd98/MZvwLSjqfOTGoRGhEX8dfOa50XbtyfEJHVbM+JAnW7F8SnLQr7+lxVUpFRN6PF4ZnpY62/ZybnNs8Ki0qIimiWf7HroYciPBM85E3+uGqdmAKjPamomzPiEAAJN2zkJA0Lr/nY8A8DHwLJq4DAszzgoYIrfbuy7UNRYGTKaoc7Ih2BddD9goQJcXKDWj0Tw8RhT5OIkCKahZFAEEAuNIYUyXAYsPHJgYyiHSyHV+z0iGYhGTCCQwxQAwWEXFCEcgsbhAmW4G7CI4QFsHF7AxXn+ZQ85QYZDxpFxgekHag6eQj1npVcULztmKY8ST8xFwTh0dVvPXdBjXrOmvEXPTEA5ODhvvQ+tDRBz0DhzLZnjvmlo6Cn1HNzqkHFkXIDpB6g5eEos3Fx+RfGyYx5QZ74nQl3hclgPdNS0E9TF4Ce7XrS+vEUPMwFkq4MDzlf70AbpAMThaRpnrpEbknFPg8RoqaG+1uTekpz14a+2RIkWI5bYbAdV7S6ydTKm+/ggVysAAAA=')
format('woff2'),
url('//at.alicdn.com/t/font_3144196_s14ifjx2cyi.woff?t=1642299317916') format('woff'),
url('//at.alicdn.com/t/font_3144196_s14ifjx2cyi.ttf?t=1642299317916') format('truetype');
}

.icon {
font-family: 'icon' !important;
font-size: 16px;
font-style: normal;
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
}

.icon-a-0:before {
content: '\e64d';
}

.icon-a-1h:before {
content: '\e64e';
}

.icon-a-2h:before {
content: '\e64f';
}

.icon-a-3h:before {
content: '\e650';
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

自定义图标用法，下面以 `iconfont` 为例

#### 准备图标文件

文件后缀应为`.wxss`，如下方代码块所示：

```css
@font-face {
font-family: 'icon';  // 使用自定义的字体名称
···
}

.icon {
font-family: 'icon' !important;  // 字体名称
···
}

.icon-a-0:before {  // icon 图标。注意 FontClass 前缀与 font-family 保持一致
content: '\e64d';
}
```

- 添加所需图标，下载图标。图标库一般会提供 **在线链接** 或者 **下载至本地** 等使用方式。**在线链接** 方式会指向一个 `.css` 文件，可以下载或复制其内容，将其修改成后缀名为 `.wxss` 的文件
- 将 `.wxss` 文件中的 `FontClass/Symbol前缀` 与 `Font Family` 两项内容保持一致，如: `FontClass/Symbol` 前缀为 `icon-`，则 `Font Family` 为 `icon`。

> 注：若是采用 `下载至本地` 方式，需关注 `.css` 和 `.ttf` 文件。由于微信小程序不支持处理 `ttf、woff、eot` 等文件，但支持 `base64`，所以需要将 `.ttf` 文件转换为 `base64` (可借助转换工具，如 [transfonter.org](https://transfonter.org/)，会得到一个 `stylesheet.css` 文件)，然后将 `.css` 文件中的 `@font-face {}` 内容替换为 `stylesheet.css` 中的 `base64` 内容，最后将 `.css` 文件修改后缀为 `.wxss`

#### 引入自定义图标

- 全局引入：在项目 `app.wxss`，使用 `@import` 引入上述的 `.wxss` 文件
- 局部引入：在 `page` 对应的 `.wxss` 中，使用 `@import` 引入上述的 `.wxss` 文件

#### 自定义图标的使用

`<t-icon>` 组件中的 `prefix` 属性值与前面设置的 `Font Family` 保持一致，即 `prefix="icon"`，`name` 属性值为自定义图标名称，如图标的 `className` 为 `icon-a-1h`，则 `name="a-1h"`。

### 图片链接

**WXML** (`html`):
```html
<view class="demo__list">
<view class="demo__card" wx:for="{{imageIconList}}" wx:key="index">
<t-icon name="{{item}}" size="48rpx" data-name="{{item}}" bind:click="onIconTap" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
imageIconList: [
'https://tdesign.gtimg.com/mobile/demos/icon1.png',
'https://tdesign.gtimg.com/mobile/demos/icon2.png',
],
},

methods: {
onIconTap(event) {
const { name, type } = event.currentTarget.dataset;
if (type === 'prefix') return;
wx.showToast({ title: name, icon: 'none', duration: 1000 });
},
},
});

```

**CSS** (`css`):
```css
.demo__list {
display: flex;
flex-wrap: wrap;
padding: 16rpx 32rpx;
}

.demo__card {
flex: 0 0 25%;
display: flex;
justify-content: center;
text-align: center;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

### 全部图标

大部分图标在 1.8.0 版本中新增，如果发现引入组件库后，部分图标无法使用，请检查安装的组件库`tdesign-miniprogram`的版本。支持中文英文搜索，如果觉得可以再增加其他关键词提示，欢迎到 [图标仓库](https://github.com/Tencent/tdesign-icons/blob/develop/packages/view/src/manifest.js) 提交PR，帮我们一起补充。

## API

### IconProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| color | String | - | 图标颜色 | N |
| name | String | - | 必需。图标名称或图片链接 | Y |
| prefix | String | - | 自定义图标前缀 | N |
| size | String / Number | - | 图标大小, 如`20`,`20px`,`48rpx`, 默认单位是`px` | N |

### IconEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| click | - | 点击图标时触发。通用类型定义 |

### IconExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| ant: norma | ant: norma | - |

---

# [image-viewer]

# ImageViewer 图片预览

## 示例

该组件于 0.10.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-image-viewer": "tdesign-miniprogram/image-viewer/image-viewer",
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/0qyn8MmS8d52)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 类型

#### 基础图片预览

**WXML** (`html`):
```html
<t-button theme="primary" size="large" variant="outline" block bind:tap="onClick">基础图片预览</t-button>
<t-toast id="t-toast" />
<t-image-viewer
usingCustomNavbar
deleteBtn="{{deleteBtn}}"
closeBtn="{{closeBtn}}"
showIndex="{{showIndex}}"
visible="{{visible}}"
images="{{images}}"
bind:change="onChange"
bind:delete="onDelete"
bind:close="onClose"
></t-image-viewer>

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast/index';

Component({
data: {
visible: false,
showIndex: false,
closeBtn: false,
deleteBtn: false,
images: [],
},
methods: {
onClick() {
this.setData({
images: [
'https://tdesign.gtimg.com/mobile/demos/swiper1.png',
'https://tdesign.gtimg.com/mobile/demos/swiper2.png',
],
showIndex: true,
visible: true,
});
},
onChange(e) {
const { index } = e.detail;

console.log('change', index);
},

onDelete(e) {
const { index } = e.detail;

Toast({
context: this,
selector: '#t-toast',
message: `删除第${index + 1}个`,
});
},

onClose(e) {
const { trigger } = e.detail;
console.log(trigger);
this.setData({
visible: false,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-toast": "tdesign-miniprogram/toast/toast",
"t-image-viewer": "tdesign-miniprogram/image-viewer/image-viewer"
}
}

```

#### 带操作图片预览

顶部区域可以配置关闭按钮、页码信息、删除按钮。

**WXML** (`html`):
```html
<t-button theme="primary" size="large" variant="outline" block bind:tap="onClick">带操作图片预览</t-button>

<t-action-sheet id="t-action-sheet" />

<t-image-viewer
usingCustomNavbar
deleteBtn="{{deleteBtn}}"
closeBtn="{{closeBtn}}"
showIndex="{{showIndex}}"
visible="{{visible}}"
images="{{images}}"
bind:change="onChange"
bind:delete="onDelete"
bind:close="onClose"
></t-image-viewer>

```

**JS** (`javascript`):
```javascript
import ActionSheet from 'tdesign-miniprogram/action-sheet/index';

Component({
data: {
visible: false,
showIndex: false,
closeBtn: false,
deleteBtn: false,
images: [],
},
methods: {
onClick() {
this.setData({
images: [
'https://tdesign.gtimg.com/mobile/demos/swiper1.png',
'https://tdesign.gtimg.com/mobile/demos/swiper2.png',
],
showIndex: true,
visible: true,
closeBtn: true,
deleteBtn: true,
});
},
onChange(e) {
const { index } = e.detail;

console.log(index);
},

onDelete(e) {
const { index } = e.detail;

console.log(index);

ActionSheet.show({
context: this,
selector: '#t-action-sheet',
description: '要删除这张照片吗？',
items: [
{
label: '删除',
color: '#d54941',
},
],
});
},

onClose(e) {
const { trigger } = e.detail;

console.log(trigger);
this.setData({
visible: false,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-action-sheet": "tdesign-miniprogram/action-sheet/action-sheet",
"t-image-viewer": "tdesign-miniprogram/image-viewer/image-viewer"
}
}

```

> 当使用自定义导航栏的时候，顶部的操作按钮会被遮挡，此时需要开启 `using-custom-navbar` 来解决

## API

### ImageViewerProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| background-color | String | - | 遮罩的背景颜色 | N |
| close-btn | String / Boolean / Object | false | 是否显示关闭操作，前提需要开启页码。值为字符串表示图标名称，值为`true`表示使用默认图标`close`，值为`Object`类型，表示透传至`icon`，不传表示不显示图标 | N |
| delete-btn | String / Boolean / Object | false | 是否显示删除操作，前提需要开启页码。值为字符串表示图标名称，值为`true`表示使用默认图标`delete`，值为`Object`类型，表示透传至`icon`，不传表示不显示图标 | N |
| image-props | Object | - | `1.12.0`。透传至 Image 组件。TS 类型：`ImageProps`，Image API Documents。详细类型定义 | N |
| images | Array | [] | 图片数组。TS 类型：`Array<string>` | N |
| initial-index | Number | 0 | 初始化页码。TS 类型：`Number` | N |
| lazy | Boolean | true | `1.9.4`。是否开启图片懒加载。开启后会预加载当前图片、相邻图片 | N |
| show-index | Boolean | false | 是否显示页码 | N |
| using-custom-navbar | Boolean | false | `v1.1.4`。是否使用了自定义导航栏 | N |
| visible | Boolean | false | 隐藏/显示预览 | N |
| default-visible | Boolean | undefined | 隐藏/显示预览。非受控属性 | N |

### ImageViewerEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(index: number)` | 翻页时回调 |
| close | `(trigger: 'overlay' \| 'button', visible: Boolean, index: Number)` | 点击操作按钮button或者overlay时触发 |
| delete | `(index: number)` | 点击删除操作按钮时触发 |

### ImageViewerSlots

| 名称 | 描述 |
| --- | --- |
| close-btn | 关闭操作 |
| delete-btn | 删除操作 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-image-viewer-close-margin-left | @spacer-1 | - |
| --td-image-viewer-delete-margin-right | @spacer-1 | - |
| --td-image-viewer-mask-bg-color | @mask-active | - |
| --td-image-viewer-nav-bg-color | #000 | - |
| --td-image-viewer-nav-color | @text-color-anti | - |
| --td-image-viewer-nav-height | 96rpx | - |
| --td-image-viewer-nav-index-font-size | @font-size-base | - |
| --td-image-viewer-top | @position-fixed-top | - |

---

# [image]

# Image 图片

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-image": "tdesign-miniprogram/image/image"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/Ntye2Mmz895A)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 裁切样式

**WXML** (`html`):
```html
<view class="tr">
<view class="col">
<view class="text">裁切</view>
<t-image src="{{imageSrc}}" mode="aspectFill" width="72" height="72" aria-label="一个放置在墙角的黄色行李箱" />
</view>
<view class="col">
<view class="text">适应高</view>
<t-image src="{{imageSrc}}" mode="heightFix" width="72" height="72" aria-label="一个放置在墙角的黄色行李箱" />
</view>
<view class="col">
<view class="text">拉伸</view>
<t-image src="{{imageSrc}}" width="72" height="72" aria-label="一个放置在墙角的黄色行李箱" />
</view>
</view>

<view class="tr">
<view class="col">
<view class="text">方形</view>
<t-image src="{{imageSrc}}" mode="aspectFill" width="72" height="72" aria-label="一个放置在墙角的黄色行李箱" />
</view>
<view class="col">
<view class="text">圆角方形</view>
<t-image src="{{imageSrc}}" width="72" height="72" shape="round" aria-label="一个放置在墙角的黄色行李箱" />
</view>
<view class="col">
<view class="text">圆形</view>
<t-image src="{{imageSrc}}" width="72" height="72" shape="circle" aria-label="一个放置在墙角的黄色行李箱" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
imageSrc: 'https://tdesign.gtimg.com/mobile/demos/image1.jpeg',
},
});

```

**CSS** (`css`):
```css
.tr {
display: flex;
}

.col {
margin: 0 32rpx;
}

.tr + .tr {
margin-top: 48rpx;
}

.text {
font-size: 28rpx;
color: var(--td-text-color-secondary);
line-height: 44rpx;
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-image": "tdesign-miniprogram/image/image"
}
}

```

### 加载状态

**WXML** (`html`):
```html
<view class="tr">
<view class="col">
<view class="text">加载默认提示</view>
<t-image id="loading-img" shape="round" width="72" height="72" />
</view>
<view class="col">
<view class="text">加载自定义提示</view>
<t-image id="loading-img-custom" shape="round" loading="slot" width="72" height="72">
<t-loading slot="loading" theme="spinner" size="40rpx" loading />
</t-image>
</view>
</view>

<view class="tr">
<view class="col">
<view class="text">失败默认提示</view>
<t-image id="loading-img" shape="round" src="" width="72" height="72" />
</view>
<view class="col">
<view class="text">失败自定义提示</view>
<t-image src="" shape="round" error="slot" width="72" height="72">
<text class="error-text" slot="error">加载失败</text>
</t-image>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
pageLifetimes: {
show: function () {
const $ele1 = this.selectComponent('#loading-img');
const $ele2 = this.selectComponent('#loading-img-custom');

this.setLoadingStatus($ele1);
this.setLoadingStatus($ele2);
},
},
methods: {
setLoadingStatus(ele) {
ele.onLoadError = null;
ele.onLoaded = null;
ele.setData({
isLoading: true,
isFailed: false,
});
},
},
});

```

**CSS** (`css`):
```css
.tr {
display: flex;
}

.col {
margin: 0 32rpx;
}

.tr + .tr {
margin-top: 48rpx;
}

.text {
font-size: 28rpx;
color: var(--td-text-color-secondary);
line-height: 44rpx;
margin-bottom: 32rpx;
}

.error-text {
font-size: 20rpx;
font-weight: 400;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-image": "tdesign-miniprogram/image/image",
"t-loading": "tdesign-miniprogram/loading/loading"
}
}

```

## 常见问题

本地图片无法正确引用? 👇
建议使用绝对路径，而不是相对路径。绝对路径以 app.json 所在位置为基准。

## API

### ImageProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| error | String | 'default' | 加载失败时显示的内容。值为`default`则表示使用默认加载失败风格；值为空或者`slot`表示使用插槽渲染，插槽名称为`error`；值为其他则表示普通文本内容，如“加载失败” | N |
| height | String / Number | - | 高度，默认单位为`px` | N |
| lazy | Boolean | false | 是否开启图片懒加载 | N |
| loading | String | 'default' | 加载态内容。值为`default`则表示使用默认加载中风格；值为其他则表示普通文本内容，如“加载中” | N |
| mode | String | scaleToFill | 图片裁剪、缩放的模式；小程序官方文档。可选项：scaleToFill/aspectFit/aspectFill/widthFix/heightFix/top/bottom/center/left/right/top left/top right/bottom left/bottom right | N |
| shape | String | square | 图片圆角类型。可选项：circle/round/square | N |
| show-menu-by-longpress | Boolean | false | 长按图片显示发送给朋友、收藏、保存图片、搜一搜、打开名片/前往群聊/打开小程序（若图片中包含对应二维码或小程序码）的菜单 | N |
| src | String | - | 图片链接 | N |
| t-id | String | - | `1.2.10`。图片标签id | N |
| webp | Boolean | false | 默认不解析 webP 格式，只支持网络资源 | N |
| width | String / Number | - | 宽度，默认单位为`px` | N |

### ImageEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| error | - | 图片加载失败时触发。通用类型定义 |
| load | - | 图片加载完成时触发。通用类型定义 |

### ImageSlots

| 名称 | 描述 |
| --- | --- |
| error | 自定义`error`显示内容 |
| loading | 自定义`loading`显示内容 |

### ImageExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-load | 加载样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-image-color | @text-color-placeholder | - |
| --td-image-loading-bg-color | @bg-color-secondarycontainer | - |
| --td-image-loading-color | @text-color-placeholder | - |
| --td-image-round-radius | @radius-default | - |

---

# [indexes]

# Indexes 索引

## 示例

IndexesAnchor 索引锚点组件于 0.32.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-indexes": "tdesign-miniprogram/indexes/indexes",
"t-indexes-anchor": "tdesign-miniprogram/indexes-anchor/indexes-anchor"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/iz0F6Om38d5t)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础索引

**WXML** (`html`):
```html
<view class="custom-navbar">
<t-navbar title="TDesign" leftArrow />
</view>
<t-indexes
current="{{current}}"
index-list="{{indexList}}"
sticky-offset="{{stickyOffset}}"
bind:select="onSelect"
bind:change="onChange"
>
<block wx:for="{{list}}" wx:key="index">
<t-indexes-anchor index="{{item.index}}" />
<t-cell-group>
<t-cell wx:for="{{item.children}}" wx:key="city" wx:for-item="city" title="{{city}}" aria-role="button" />
</t-cell-group>
</block>
</t-indexes>

```

**JS** (`javascript`):
```javascript
Page({
data: {
current: 'B',
indexList: [],
list: [
{
index: 'A',
children: ['阿坝', '阿拉善', '阿里', '安康', '安庆', '鞍山', '安顺', '安阳', '澳门'],
},
{
index: 'B',
children: [
'北京',
'白银',
'保定',
'宝鸡',
'保山',
'包头',
'巴中',
'北海',
'蚌埠',
'本溪',
'毕节',
'滨州',
'百色',
'亳州',
],
},
{
index: 'C',
children: [
'重庆',
'成都',
'长沙',
'长春',
'沧州',
'常德',
'昌都',
'长治',
'常州',
'巢湖',
'潮州',
'承德',
'郴州',
'赤峰',
'池州',
'崇左',
'楚雄',
'滁州',
'朝阳',
],
},
{
index: 'D',
children: [
'大连',
'东莞',
'大理',
'丹东',
'大庆',
'大同',
'大兴安岭',
'德宏',
'德阳',
'德州',
'定西',
'迪庆',
'东营',
],
},
{
index: 'E',
children: ['鄂尔多斯', '恩施', '鄂州'],
},
{
index: 'F',
children: ['福州', '防城港', '佛山', '抚顺', '抚州', '阜新', '阜阳'],
},
{
index: 'G',
children: ['广州', '桂林', '贵阳', '甘南', '赣州', '甘孜', '广安', '广元', '贵港', '果洛'],
},
{
index: 'J',
children: ['揭阳', '吉林', '晋江', '吉安', '胶州', '嘉兴', '济南', '鸡西', '荆州', '江门', '基隆'],
},
{
index: 'K',
children: ['昆明', '开封', '康定', '喀什'],
},
],
stickyOffset: 0,
},

onLoad() {
this.getCustomNavbarHeight();
},

onReady() {
this.setData({
indexList: this.data.list.map((item) => item.index),
});
},

onChange(e) {
const { index } = e.detail;
this.setData({
current: index,
});
console.log('change:', index);
},

onSelect(e) {
const { index } = e.detail;

console.log('select:', index);
},

getCustomNavbarHeight() {
const query = wx.createSelectorQuery();
query.select('.custom-navbar').boundingClientRect();
query.exec((res) => {
const { height = 0 } = res[0] || {};
this.setData({ stickyOffset: height });
});
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-indexes": "tdesign-miniprogram/indexes/indexes",
"t-indexes-anchor": "tdesign-miniprogram/indexes-anchor/indexes-anchor",
"t-cell-group": "tdesign-miniprogram/cell-group/cell-group",
"t-cell": "tdesign-miniprogram/cell/cell"
}
}

```

### 自定义索引

**WXML** (`html`):
```html
<view class="custom-navbar">
<t-navbar title="TDesign" leftArrow />
</view>
<view class="indexes">
<t-indexes bind:change="onChange" index-list="{{indexList}}" sticky-offset="{{stickyOffset + 8}}" t-class="wrapper">
<block wx:for="{{list}}" wx:key="index">
<t-indexes-anchor index="{{item.index}}" t-class="anchor-wrapper">
<view class="capsule{{curIndex == item.index ? ' capsule--active' : ''}}">{{item.index}}</view>
</t-indexes-anchor>
<t-cell-group>
<t-cell
wx:for="{{item.children}}"
wx:key="city"
wx:for-item="city"
title="{{city}}"
bordered="{{item.children.length - 1 != index}}"
/>
</t-cell-group>
</block>
</t-indexes>
</view>

```

**JS** (`javascript`):
```javascript
const children = new Array(5).fill('列表内容');

const list = [
{
index: 1,
children,
},
{
index: 3,
children,
},
{
index: 5,
children,
},
{
index: 7,
children,
},
{
index: 8,
children,
},
{
index: 10,
children,
},
{
index: '#',
children,
},
];

Page({
data: {
list,
indexList: list.map((item) => item.index),
curIndex: '',
stickyOffset: 0,
},

onLoad() {
this.getCustomNavbarHeight();
},

onChange(e) {
const { index } = e.detail;

console.log(index);
this.setData({
curIndex: index,
});
},

getCustomNavbarHeight() {
const query = wx.createSelectorQuery();
query.select('.custom-navbar').boundingClientRect();
query.exec((res) => {
const { height = 0 } = res[0] || {};
this.setData({ stickyOffset: height });
});
},
});

```

**CSS** (`css`):
```css
.capsule {
margin: 0 8px;
height: 30px;
border-radius: 15px;
background-color: var(--td-bg-color-secondarycontainer, #f3f3f3);
padding-left: 32rpx;
display: flex;
align-items: center;
font-size: 14px;
box-sizing: border-box;
}

.capsule--active {
border: 1px solid var(--td-border-level-1-color, #e7e7e7);
}

.wrapper {
padding-top: 8px;
height: 100%;
}

.indexes,
.capsule--active,
.anchor-wrapper {
background: var(--td-bg-color-container, #ffffff);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-indexes": "tdesign-miniprogram/indexes/indexes",
"t-indexes-anchor": "tdesign-miniprogram/indexes-anchor/indexes-anchor",
"t-cell-group": "tdesign-miniprogram/cell-group/cell-group",
"t-cell": "tdesign-miniprogram/cell/cell"
}
}

```

## FAQ

### 在滚动元素中，Indexes索引组件失效（#3746）？

`Indexes` 组件自 `0.32.0` 版本开始移除了对 `scroll-view` 的依赖，组件内部使用 [wx.pageScrollTo](https://developers.weixin.qq.com/miniprogram/dev/api/ui/scroll/wx.pageScrollTo.html) 滚动到指定位置，因此只支持页面级滚动，不支持在滚动元素中嵌套使用，包括 overflow: scroll、 scroll-view 等。

## API

### IndexesProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| current | String / Number | - | `1.9.7`。索引列表的激活项，默认首项 | N |
| default-current | String / Number | undefined | `1.9.7`。索引列表的激活项，默认首项。非受控属性 | N |
| index-list | Array | - | `0.32.0`。索引字符列表。不传默认`A-Z`。TS 类型：`Array<string \| number>` | N |
| list | Array | [] | 已废弃。索引列表的列表数据。每个元素包含三个子元素，index(string)：索引值，例如1，2，3，...或A，B，C等；title(string): 索引标题，可不填将默认设为索引值；children(Array<{title: string}>): 子元素列表，title为子元素的展示文案。TS 类型：`ListItem[] ``interface ListItem { title: string;  index: string;  children: { title: string; [key: string]: any} [] }`。详细类型定义 | N |
| sticky | Boolean | true | 索引是否吸顶，默认为true。TS 类型：`Boolean` | N |
| sticky-offset | Number | 0 | `1.0.0`。锚点吸顶时与顶部的距离 | N |

### IndexesEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(index: string \| number)` | `0.34.0`。索引发生变更时触发事件 |
| select | `(index: string \| number)` | 点击侧边栏时触发事件 |

### IndexesSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### IndexesAnchorProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| index | String / Number | - | 索引字符 | N |

### IndexesAnchorSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### IndexesAnchorExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-sidebar | 侧边栏样式类 |
| t-class-sidebar-item | 侧边栏选项样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-indexes-sidebar-active-bg-color | @brand-color | - |
| --td-indexes-sidebar-active-color | @text-color-anti | - |
| --td-indexes-sidebar-color | @text-color-primary | - |
| --td-indexes-sidebar-font | @font-body-small | - |
| --td-indexes-sidebar-item-size | 40rpx | - |
| --td-indexes-sidebar-right | 16rpx | - |
| --td-indexes-sidebar-tips-bg-color | @brand-color-light | - |
| --td-indexes-sidebar-tips-color | @brand-color | - |
| --td-indexes-sidebar-tips-font | @font-title-extraLarge | - |
| --td-indexes-sidebar-tips-right | calc(100% + 32rpx) | - |
| --td-indexes-sidebar-tips-size | 96rpx | - |
| --td-indexes-anchor-active-bg-color | @bg-color-container | - |
| --td-indexes-anchor-active-color | @brand-color | - |
| --td-indexes-anchor-active-font-weight | 600 | - |
| --td-indexes-anchor-bg-color | @bg-color-secondarycontainer | - |
| --td-indexes-anchor-border-color | @component-border | - |
| --td-indexes-anchor-color | @text-color-primary | - |
| --td-indexes-anchor-font | @font-body-medium | - |
| --td-indexes-anchor-padding | 8rpx 32rpx | - |
| --td-indexes-anchor-top | 0 | - |

---

# [input]

# Input 输入框

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/JMyCXMm98m5b)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

基础输入框

**WXML** (`html`):
```html
<t-input label="标签文字" placeholder="请输入文字" />

<t-input placeholder="请输入文字">
<view slot="label" class="custom-label"> 标签文字 </view>
</t-input>

<t-input placeholder="请输入文字" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.custom-label {
display: inline-flex;
}

.custom-label::after {
content: '*';
color: red;
font-size: 32rpx;
margin-left: 4rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

带字数限制输入框

**WXML** (`html`):
```html
<t-input class="custom-class" label="标签文字" placeholder="请输入文字" tips="最大输入10个字符" maxlength="{{10}}" />
<t-input
class="custom-class"
label="标签文字"
placeholder="请输入文字"
tips="最大输入10个字符，汉字算两个"
maxcharacter="{{10}}"
/>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.custom-class {
--td-input-align-items: start;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

带操作输入框

**WXML** (`html`):
```html
<t-input
label="标签文字"
placeholder="请输入文字"
suffixIcon="{{ { name: 'info-circle-filled', ariaLabel: '提示' } }}"
bind:click="click"
/>

<t-input class="extra" label="标签文字" placeholder="请输入文字" tips="最多十个字" maxcharacter="{{10}}">
<t-button slot="extra" theme="primary" size="extra-small"> 操作按钮 </t-button>
</t-input>

<t-input label="标签文字" placeholder="请输入文字" suffixIcon="{{ { name: 'user-avatar', ariaLabel: '通讯录' } }}" />

```

**JS** (`javascript`):
```javascript
Component({
methods: {
click(e) {
const { trigger } = e.detail;
console.log('click: ', trigger);
},
},
});

```

**CSS** (`css`):
```css
.extra {
--td-input-align-items: start;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-input": "tdesign-miniprogram/input/input"
}
}

```

带图标输入框

**WXML** (`html`):
```html
<t-input prefixIcon="app" label="标签文字" placeholder="请输入文字" />

<t-input prefixIcon="app" placeholder="请输入文字" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

特定类型输入框

**WXML** (`html`):
```html
<t-input
label="输入密码"
type="password"
value="{{textPassword}}"
suffixIcon="{{ { name: 'browse-off', ariaLabel: '密码' } }}"
/>

<t-input placeholder="输入验证码" label="验证码">
<view slot="suffix" class="suffix">
<view class="suffix--line"></view>
<image
class="image"
src="https://wwcdn.weixin.qq.com/node/wework/images/202010241547.ac6876be9c.png"
mode="heightFix"
aria-role="img"
aria-label="验证码"
/>
</view>
</t-input>

<t-input
label="手机号"
placeholder="输入手机号码"
value="{{phoneNumber}}"
type="number"
tips="{{phoneError ? '手机号输入不正确' : ''}}"
bindchange="onPhoneInput"
>
<view slot="suffix" style="display: flex; align-items: center">
<view class="suffix--line"></view>
<view class="verify" aria-role="button"> 发送验证码 </view>
</view>
</t-input>

<t-input
label="价格"
placeholder="0.00"
suffix="元"
align="right"
type="number"
format="{{priceFormat}}"
bindchange="onPriceInput"
tips="{{priceError ? '请输入正确的价格' : ''}}"
t-class-tips="tips"
/>

<t-input label="数量" placeholder="填写个数" suffix="个" align="right" type="number" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
textPassword: '123456',
phoneError: false,
phoneNumber: '17600600600',
priceError: false,
priceFormat: (v) => {
const isNumber = /^\d+(\.\d+)?$/.test(v);
if (isNumber) {
return parseFloat(v).toFixed(2);
}
return v;
},
},

methods: {
onPhoneInput(e) {
const { phoneError } = this.data;
const isPhoneNumber = /^[1][3,4,5,7,8,9][0-9]{9}$/.test(e.detail.value);
if (phoneError === isPhoneNumber) {
this.setData({
phoneError: !isPhoneNumber,
});
}
},

onPriceInput(e) {
const { priceError } = this.data;
const isNumber = /^\d+(\.\d+)?$/.test(e.detail.value);
if (priceError === isNumber) {
this.setData({
priceError: !isNumber,
});
}
},
},
});

```

**CSS** (`css`):
```css
.suffix {
display: flex;
align-items: center;
}

.suffix--line {
width: 1px;
height: 24px;
background-color: var(--td-component-stroke, #f3f3f3);
margin-right: 16px;
}

.image {
width: 72px;
height: 36px;
display: block;
margin-top: -6px;
margin-bottom: -6px;
}

.tips {
text-align: right !important;
}

.verify {
color: var(--td-brand-color, #0052d9);
font-size: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

### 02组件状态

输入框状态

**WXML** (`html`):
```html
<t-input
class="custom-class"
label="标签文字"
placeholder="请输入文字"
value="已输入内容"
status="error"
tips="错误提示"
clearable="{{ { name: 'close', color: '#D54941', ariaLabel: '通讯录' } }}"
/>

<t-input label="标签文字" value="不可编辑文字" disabled />

<t-input label="标签文字" value="只读模式" readonly></t-input>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.custom-class {
--td-input-align-items: start;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

信息超长状态

**WXML** (`html`):
```html
<t-input label="标签超长时最多十个字" placeholder="请输入文字" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

### 03组件样式

内容位置

**WXML** (`html`):
```html
<t-input label="左对齐" placeholder="请输入文字" />
<t-input label="居中" placeholder="请输入文字" align="center" />
<t-input label="右对齐" placeholder="请输入文字" align="right" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

竖排样式

**WXML** (`html`):
```html
<t-input
label="标签文字"
layout="vertical"
placeholder="请输入文字"
suffixIcon="{{ { name: 'info-circle-filled', ariaLabel: '提示' } }}"
></t-input>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

非通栏样式

**WXML** (`html`):
```html
<view class="input-example">
<t-input style="{{style}}" label="标签文字" placeholder="请输入文字" borderless />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
style: 'border-radius: 18rpx;',
},
});

```

**CSS** (`css`):
```css
.input-example {
margin: 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

标签外置样式

**WXML** (`html`):
```html
<view class="input-example">
<view class="input-example__label"> 标签文字 </view>
<t-input
placeholder="请输入文字"
borderless="{{true}}"
suffixIcon="{{ { name: 'info-circle-filled', ariaLabel: '提示' } }}"
style="{{style}}"
/>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
style: 'border: 2rpx solid var(--td-component-border);border-radius: 12rpx;',
},
});

```

**CSS** (`css`):
```css
.input-example {
--td-input-vertical-padding: 24rpx;
background-color: var(--bg-color-demo);
padding: 32rpx 32rpx 16rpx;
}

.input-example__label {
color: var(--td-text-color-primary);
font-size: 24rpx;
line-height: 40rpx;
margin: 0 8rpx 16rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

自定义样式文本框

**WXML** (`html`):
```html
<view class="input-example custom-theme">
<t-input label="标签文字" placeholder="请输入文字" />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.input-example {
padding-bottom: 48rpx;
}

.custom-theme {
--td-input-bg-color: rgba(44, 44, 44, 1);
--td-input-border-color: rgba(75, 75, 75, 1);
--td-input-default-text-color: rgba(255, 255, 255, 1);
--td-input-placeholder-text-color: rgba(255, 255, 255, 0.35);
--td-input-label-text-color: rgba(255, 255, 255, 1);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-input": "tdesign-miniprogram/input/input"
}
}

```

## API

### InputProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| adjust-position | Boolean | true | 键盘弹起时，是否自动上推页面 | N |
| align | String | left | 文本内容位置，居左/居中/居右。可选项：left/center/right | N |
| allow-input-over-max | Boolean | false | `1.8.6`。超出`maxlength`或`maxcharacter`之后是否允许继续输入 | N |
| always-embed | Boolean | false | 强制 input 处于同层状态，默认 focus 时 input 会切到非同层状态 (仅在 iOS 下生效) | N |
| auto-focus | Boolean | false | (即将废弃，请直接使用 focus )自动聚焦，拉起键盘 | N |
| borderless | Boolean | false | 是否开启无边框模式 | N |
| clear-trigger | String | always | 清空图标触发方式，仅在输入框有值时有效。可选项：always / focus | N |
| clearable | Boolean / Object | false | 是否可清空，默认不启动。值为`true`表示使用默认清空按钮，值为`Object`表示透传至`icon` | N |
| confirm-hold | Boolean | false | 点击键盘右下角按钮时是否保持键盘不收起 | N |
| confirm-type | String | done | 设置键盘右下角按钮的文字，仅在type='text'时生效。<br>具体释义：<br>`send`右下角按钮为“发送”；<br>`search`右下角按钮为“搜索”；<br>`next`右下角按钮为“下一个”；<br>`go`右下角按钮为“前往”；<br>`done`右下角按钮为“完成”。<br>小程序官方文档。可选项：send/search/next/go/done | N |
| cursor | Number | -1 | 必需。指定 focus 时的光标位置 | Y |
| cursor-color | String | #0052d9 | 光标颜色。iOS 下的格式为十六进制颜色值 #000000，安卓下的只支持 default 和 green，Skyline 下无限制 | N |
| cursor-spacing | Number | 0 | 指定光标与键盘的距离，取 input 距离底部的距离和 cursor-spacing 指定的距离的最小值作为光标与键盘的距离 | N |
| disabled | Boolean | undefined | 是否禁用输入框 | N |
| error-message | String | - | 已废弃。错误提示文本，值为空不显示（废弃属性，如果需要，请更为使用 status 和 tips） | N |
| focus | Boolean | false | 获取焦点 | N |
| format | Function | - | 指定输入框展示值的格式。TS 类型：`InputFormatType``type InputFormatType = (value: InputValue) => string`。详细类型定义 | N |
| hold-keyboard | Boolean | false | focus时，点击页面的时候不收起键盘 | N |
| label | String | - | 左侧文本 | N |
| layout | String | horizontal | 标题输入框布局方式。可选项：vertical/horizontal | N |
| maxcharacter | Number | - | 用户最多可以输入的字符个数，一个中文汉字表示两个字符长度。`maxcharacter`和`maxlength`二选一使用 | N |
| maxlength | Number | -1 | 用户最多可以输入的文本长度，一个中文等于一个计数长度。默认为 -1，不限制输入长度。`maxcharacter`和`maxlength`二选一使用 | N |
| password | Boolean | false | 已废弃。是否是密码类型（已废弃，请更为使用 type 指定输入框类型） | N |
| placeholder | String | undefined | 占位符 | N |
| placeholder-class | String | input-placeholder | 指定 placeholder 的样式类 | N |
| placeholder-style | String | - | 必需。指定 placeholder 的样式 | Y |
| prefix-icon | String / Object | - | 组件前置图标。值为字符串表示图标名称，值为`Object`类型，表示透传至`icon` | N |
| readonly | Boolean | undefined | `1.7.1`。只读状态 | N |
| safe-password-cert-path | String | - | 安全键盘加密公钥的路径，只支持包内路径 | N |
| safe-password-custom-hash | String | - | 安全键盘计算 hash 的算法表达式，如`md5(sha1('foo' + sha256(sm3(password + 'bar'))))` | N |
| safe-password-length | Number | - | 安全键盘输入密码长度 | N |
| safe-password-nonce | String | - | 安全键盘加密盐值 | N |
| safe-password-salt | String | - | 安全键盘计算 hash 盐值，若指定custom-hash 则无效 | N |
| safe-password-time-stamp | Number | - | 安全键盘加密时间戳 | N |
| selection-end | Number | -1 | 光标结束位置，自动聚集时有效，需与 selection-start 搭配使用 | N |
| selection-start | Number | -1 | 光标起始位置，自动聚集时有效，需与 selection-end 搭配使用 | N |
| size | String | medium | 已废弃。输入框尺寸。可选项：small/medium。TS 类型：`'medium' \| 'small'` | N |
| status | String | default | 输入框状态。可选项：default/success/warning/error | N |
| suffix | String | - | 后置图标前的后置内容 | N |
| suffix-icon | String / Object | - | 后置文本内容。值为字符串则表示图标名称，值为`Object`类型，表示透传至`icon` | N |
| tips | String | - | 输入框下方提示文本，会根据不同的`status`呈现不同的样式 | N |
| type | String | text | 输入框类型。可选项：text/number/idcard/digit/safe-password/password/nickname | N |
| value | String / Number | - | 输入框的值。TS 类型：`InputValue``type InputValue = string \| number`。详细类型定义 | N |
| default-value | String / Number | undefined | 输入框的值。非受控属性。TS 类型：`InputValue``type InputValue = string \| number`。详细类型定义 | N |

### InputEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| blur | `(value: InputValue)` | 失去焦点时触发 |
| change | `(value: InputValue, cursor: number, keyCode: number)` | 输入框值发生变化时触发；cursor 为光标位置； |
| clear | - | 清空按钮点击时触发 |
| click | `(trigger: InputTrigger)` | `0.32.0`。点击事件。详细类型定义。<br>`type InputTrigger = 'suffix' \| 'suffix-icon';`<br> |
| enter | `(value: InputValue)` | 回车键按下时触发 |
| focus | `(value: InputValue)` | 获得焦点时触发 |
| keyboardheightchange | `(height: number, duration: number)` | 键盘高度发生变化的时候触发此事件 |
| nicknamereview | `(pass: boolean, timeout: boolean)` | 用户昵称审核完毕后触发，仅在 type 为 "nickname" 时有效 |
| validate | `(detail: { error?: 'exceed-maximum' \| 'below-minimum' })` | 字数超出限制时触发 |

### InputSlots

| 名称 | 描述 |
| --- | --- |
| extra | `1.9.1`。右侧额外内容 |
| label | 自定义`label`显示内容 |
| prefix-icon | 组件前置图标 |
| suffix | 自定义`suffix`显示内容 |
| suffix-icon | 后置文本图标 |
| tips | 输入框下方提示内容 |

### InputExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-clearable | 清空按钮样式类 |
| t-class-input | 输入框样式类 |
| t-class-label | 标签样式类 |
| t-class-prefix-icon | 前置图标样式类 |
| t-class-suffix | 后置样式类 |
| t-class-suffix-icon | 后置图标样式类 |
| t-class-tips | 提示样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-input-align-items | center | - |
| --td-input-bg-color | @bg-color-container | - |
| --td-input-border-color | @component-stroke | - |
| --td-input-border-left-space | 32rpx | - |
| --td-input-border-right-space | 0 | - |
| --td-input-default-text-color | @text-color-primary | - |
| --td-input-default-tips-color | @text-color-placeholder | - |
| --td-input-disabled-text-color | @text-color-disabled | - |
| --td-input-error-text-color | @error-color | - |
| --td-input-error-tips-color | @error-color | - |
| --td-input-label-max-width | 5em | - |
| --td-input-label-min-width | 2em | - |
| --td-input-label-text-color | @text-color-primary | - |
| --td-input-label-text-font | @font-body-large | - |
| --td-input-placeholder-text-color | @text-color-placeholder | - |
| --td-input-placeholder-text-font | @font-body-large | - |
| --td-input-prefix-icon-color | @text-color-primary | - |
| --td-input-success-text-color | @success-color | - |
| --td-input-success-tips-color | @success-color | - |
| --td-input-suffix-icon-color | @text-color-placeholder | - |
| --td-input-suffix-text-color | @text-color-primary | - |
| --td-input-vertical-padding | 32rpx | - |
| --td-input-warning-text-color | @warning-color | - |
| --td-input-warning-tips-color | @warning-color | - |

---

# [link]

# Link 链接

## 示例

该组件于 0.32.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-link": "tdesign-miniprogram/link/link",
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/hsyYRMm78r59)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

基础文字链接

**WXML** (`html`):
```html
<view class="link-example">
<t-link size="small" theme="primary" content="跳转链接" hover />
<t-link size="small" content="跳转链接" hover />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.link-example {
display: flex;
align-items: center;
justify-content: space-evenly;
height: 96rpx;
background-color: var(--bg-color-demo);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-link": "tdesign-miniprogram/link/link"
}
}

```

下划线文字链接

**WXML** (`html`):
```html
<view class="link-example">
<t-link size="small" theme="primary" content="跳转链接" underline hover />
<t-link size="small" content="跳转链接" underline hover />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.link-example {
display: flex;
align-items: center;
justify-content: space-evenly;
height: 96rpx;
background-color: var(--bg-color-demo);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-link": "tdesign-miniprogram/link/link"
}
}

```

前置图标文字链接

**WXML** (`html`):
```html
<view class="link-example">
<t-link size="small" theme="primary" content="跳转链接" prefixIcon="link" hover />
<t-link size="small" content="跳转链接" prefixIcon="link" hover />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.link-example {
display: flex;
align-items: center;
justify-content: space-evenly;
height: 96rpx;
background-color: var(--bg-color-demo);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-link": "tdesign-miniprogram/link/link"
}
}

```

后置图标文字链接

**WXML** (`html`):
```html
<view class="link-example">
<t-link size="small" theme="primary" content="跳转链接" suffixIcon="jump" hover />
<t-link size="small" content="跳转链接" suffixIcon="jump" hover />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.link-example {
display: flex;
align-items: center;
justify-content: space-evenly;
height: 96rpx;
background-color: var(--bg-color-demo);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-link": "tdesign-miniprogram/link/link"
}
}

```

### 组件状态

不同主题

**WXML** (`html`):
```html
<view class="link-example">
<t-link size="small" theme="primary" content="跳转链接" suffixIcon="jump" hover />
<t-link size="small" content="跳转链接" suffixIcon="jump" hover />
<t-link size="small" theme="danger" content="跳转链接" suffixIcon="jump" hover />
</view>
<view class="link-example">
<t-link size="small" theme="warning" content="跳转链接" suffixIcon="jump" hover />
<t-link size="small" theme="success" content="跳转链接" suffixIcon="jump" hover />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.link-example {
display: flex;
align-items: center;
justify-content: space-evenly;
height: 96rpx;
background-color: var(--bg-color-demo);
}

.link-example:not(:last-child) {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-link": "tdesign-miniprogram/link/link"
}
}

```

禁用状态

**WXML** (`html`):
```html
<view class="link-example">
<t-link
navigatorProps="{{navigatorProps}}"
size="small"
theme="primary"
content="跳转链接"
suffixIcon="jump"
disabled
hover
/>
<t-link size="small" content="跳转链接" suffixIcon="jump" disabled />
<t-link size="small" theme="danger" content="跳转链接" suffixIcon="jump" disabled />
</view>
<view class="link-example">
<t-link size="small" theme="warning" content="跳转链接" suffixIcon="jump" disabled />
<t-link size="small" theme="success" content="跳转链接" suffixIcon="jump" disabled />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
navigatorProps: {
url: '/pages/home/home',
},
},
});

```

**CSS** (`css`):
```css
.link-example {
display: flex;
align-items: center;
justify-content: space-evenly;
height: 96rpx;
background-color: var(--bg-color-demo);
}

.link-example:not(:last-child) {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-link": "tdesign-miniprogram/link/link"
}
}

```

### 组件样式

链接尺寸

**WXML** (`html`):
```html
<view class="link-example">
<t-link size="small" theme="primary" content="S号链接" suffixIcon="jump" hover />
<t-link theme="primary" content="M号链接" suffixIcon="jump" hover />
<t-link size="large" theme="primary" content="L号链接" suffixIcon="jump" hover />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.link-example {
display: flex;
align-items: center;
justify-content: space-evenly;
height: 96rpx;
background-color: var(--bg-color-demo);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-link": "tdesign-miniprogram/link/link"
}
}

```

## API

### LinkProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| content | String | - | 链接内容 | N |
| disabled | Boolean | false | 是否为禁用态 | N |
| hover | Boolean | - | 是否开启点击反馈 | N |
| navigator-props | Object | - | 与 navigator 原生组件属性保持一致，具体使用参考：微信开放文档。使用时请将形如`open-type`风格的属性名改为`openType`风格 | N |
| prefix-icon | String / Object | - | 前置图标 | N |
| size | String | medium | 尺寸。可选项：small/medium/large。TS 类型：`SizeEnum`。通用类型定义 | N |
| status | String | normal | 已废弃。组件状态。可选项：normal/active/disabled | N |
| suffix-icon | String / Object | - | 后置图标 | N |
| theme | String | default | 组件风格，依次为默认色、品牌色、危险色、警告色、成功色。可选项：default/primary/danger/warning/success | N |
| underline | Boolean | - | 是否显示链接下划线 | N |

### LinkEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| complete | - | 页面链接执行完成后触发（失败或成功均会触发） |
| fail | - | 页面链接跳转失败后触发 |
| success | - | 页面链接跳转成功后触发 |

### LinkSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，作用同`content`插槽 |
| content | 自定义`content`显示内容 |
| prefix-icon | 自定义`prefix-icon`显示内容 |
| suffix-icon | 自定义`suffix-icon`显示内容 |

### LinkExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |
| t-class-hover | 悬停样式类 |
| t-class-prefix-icon | 前置图标样式类 |
| t-class-suffix-icon | 后置图标样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-link-danger-active-color | @error-color-active | - |
| --td-link-danger-color | @error-color | - |
| --td-link-danger-disabled-color | @error-color-disabled | - |
| --td-link-default-active-color | @brand-color-active | - |
| --td-link-default-color | @text-color-primary | - |
| --td-link-default-disabled-color | @text-color-disabled | - |
| --td-link-primary-active-color | @brand-color-active | - |
| --td-link-primary-color | @brand-color | - |
| --td-link-primary-disabled-color | @brand-color-disabled | - |
| --td-link-success-active-color | @success-color-active | - |
| --td-link-success-color | @success-color | - |
| --td-link-success-disabled-color | @success-color-disabled | - |
| --td-link-warning-active-color | @warning-color-active | - |
| --td-link-warning-color | @warning-color | - |
| --td-link-warning-disabled-color | @warning-color-disabled | - |

---

# [list]

# 组件概览

### 基础6

[Button 按钮](/miniprogram/components/button)   [Divider 分割线](/miniprogram/components/divider)   [Fab 悬浮按钮](/miniprogram/components/fab)   [Icon 图标](/miniprogram/components/icon)   [Layout 布局](/miniprogram/components/layout)   [Link 链接](/miniprogram/components/link)
### 导航8

[BackTop 返回顶部](/miniprogram/components/back-top)   [Drawer 抽屉](/miniprogram/components/drawer)   [Indexes 索引](/miniprogram/components/indexes)   [Navbar 导航条](/miniprogram/components/navbar)   [SideBar 侧边导航栏](/miniprogram/components/side-bar)   [Steps 步骤条](/miniprogram/components/steps)   [TabBar 底部标签栏](/miniprogram/components/tab-bar)   [Tabs 选项卡](/miniprogram/components/tabs)
### 输入16

[Calendar 日历](/miniprogram/components/calendar)   [Cascader 级联选择器](/miniprogram/components/cascader)   [CheckBox 多选框](/miniprogram/components/checkbox)   [ColorPicker 颜色选择器](/miniprogram/components/color-picker)   [DateTimePicker 日期选择器](/miniprogram/components/date-time-picker)   [Input 输入框](/miniprogram/components/input)   [Picker 选择器](/miniprogram/components/picker)   [Radio 单选框](/miniprogram/components/radio)   [Rate 评分](/miniprogram/components/rate)   [Search 搜索框](/miniprogram/components/search)   [Slider 滑动选择器](/miniprogram/components/slider)   [Stepper 步进器](/miniprogram/components/stepper)   [Switch 开关](/miniprogram/components/switch)   [Textarea 多行文本框](/miniprogram/components/textarea)   [TreeSelect 树形选择器](/miniprogram/components/tree-select)   [Upload 上传](/miniprogram/components/upload)
### 数据展示18

[Avatar 头像](/miniprogram/components/avatar)   [Badge 徽章](/miniprogram/components/badge)   [Cell 单元格](/miniprogram/components/cell)   [Collapse 折叠面板](/miniprogram/components/collapse)   [CountDown 倒计时](/miniprogram/components/count-down)   [Empty 空状态](/miniprogram/components/empty)   [Footer 页脚](/miniprogram/components/footer)   [Grid 宫格](/miniprogram/components/grid)   [Image 图片](/miniprogram/components/image)   [ImageViewer 图片预览](/miniprogram/components/image-viewer)   [Progress 进度条](/miniprogram/components/progress)   [QRCode 二维码](/miniprogram/components/qrcode)   [Result 结果](/miniprogram/components/result)   [Skeleton 骨架屏](/miniprogram/components/skeleton)   [Sticky 吸顶容器](/miniprogram/components/sticky)   [Swiper 轮播图](/miniprogram/components/swiper)   [Tag 标签](/miniprogram/components/tag)   [Watermark 水印](/miniprogram/components/watermark)
### 反馈12

[ActionSheet 动作面板](/miniprogram/components/action-sheet)   [Dialog 对话框](/miniprogram/components/dialog)   [DropdownMenu 下拉菜单](/miniprogram/components/dropdown-menu)   [Guide 引导](/miniprogram/components/guide)   [Loading 加载](/miniprogram/components/loading)   [Message 全局提示](/miniprogram/components/message)   [NoticeBar 消息提醒](/miniprogram/components/notice-bar)   [Overlay 遮罩层](/miniprogram/components/overlay)   [Popover 弹出气泡](/miniprogram/components/popover)   [Popup 弹出层](/miniprogram/components/popup)   [PullDownRefresh 下拉刷新](/miniprogram/components/pull-down-refresh)   [SwipeCell 滑动操作](/miniprogram/components/swipe-cell)   [Toast 轻提示](/miniprogram/components/toast)

---

# [loading]

# Loading 加载

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-loading": "tdesign-miniprogram/loading/loading"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/Bx1fqOm9805P)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 纯icon

**WXML** (`html`):
```html
<view class="loading-container-flex">
<t-loading wx:if="{{!skylineRender}}" theme="circular" size="40rpx" class="wrapper" />
<t-loading theme="spinner" size="40rpx" class="wrapper" />
<t-loading theme="dots" size="80rpx" class="wrapper" />
<t-loading theme="custom" class="wrapper">
<t-image
slot="indicator"
style="width: 100%; height: 100%"
src="https://tdesign.gtimg.com/mobile/demos/logo2.png"
/>
</t-loading>
</view>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
behaviors: [SkylineBehavior],
});

```

**CSS** (`css`):
```css
.loading-container-flex {
display: flex;
align-items: center;
}

.wrapper {
margin-right: 40px;
}

```

**JSON** (`javascript`):
```javascript
{
"components": true,
"usingComponents": {
"t-loading": "tdesign-miniprogram/loading/loading",
"t-image": "tdesign-miniprogram/image/image"
}
}

```

### icon加文字横向

**WXML** (`html`):
```html
<view class="loading-container-flex">
<t-loading wx:if="{{!skylineRender}}" theme="circular" size="40rpx" text="加载中..." class="wrapper" />
<t-loading theme="spinner" size="40rpx" text="加载中..." inheritColor class="wrapper" />
</view>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
behaviors: [SkylineBehavior],
});

```

**CSS** (`css`):
```css
.loading-container-flex {
display: flex;
align-items: center;
color: #000;
}

.wrapper {
display: flex;
margin-right: 64px;
}

```

**JSON** (`javascript`):
```javascript
{
"components": true,
"usingComponents": {
"t-loading": "tdesign-miniprogram/loading/loading"
}
}

```

### icon加文字竖向

**WXML** (`html`):
```html
<div class="box">
<t-loading
theme="{{ skylineRender ? 'spinner' : 'circular'}}"
size="40rpx"
text="加载中"
layout="vertical"
class="wrapper"
/>
<t-loading theme="spinner" size="40rpx" text="加载中" layout="vertical" class="wrapper" />
</div>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
behaviors: [SkylineBehavior],
});

```

**CSS** (`css`):
```css
.box {
display: flex;
}

.wrapper {
margin-right: 64px;
}

```

**JSON** (`javascript`):
```javascript
{
"components": true,
"usingComponents": {
"t-loading": "tdesign-miniprogram/loading/loading"
}
}

```

### 纯文字

**WXML** (`html`):
```html
<t-loading indicator="{{false}}" text="加载中..."></t-loading>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"components": true,
"usingComponents": {
"t-loading": "tdesign-miniprogram/loading/loading"
}
}

```

### 加载失败

### DEMO(🚧建设中）...

### 状态

### DEMO(🚧建设中）...

### 加载速度

**WXML** (`html`):
```html
<t-loading
theme="{{ skylineRender ? 'spinner' : 'circular'}}"
size="52rpx"
text="加载中..."
t-class-text="text-l"
duration="{{2000 - duration}}"
></t-loading>
<view class="slider-container">
<t-slider
class="slider-class"
value="{{duration}}"
min="{{100}}"
max="{{1500}}"
label
bind:change="durationChange"
></t-slider>
</view>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
behaviors: [SkylineBehavior],

data: {
duration: 800,
},
methods: {
durationChange(e) {
this.setData({ duration: e.detail.value });
},
},
});

```

**CSS** (`css`):
```css
.slider-container {
display: flex;
align-items: center;
width: 718rpx;
}

.slider-class {
flex-grow: 1;
}

```

**JSON** (`javascript`):
```javascript
{
"components": true,
"usingComponents": {
"t-loading": "tdesign-miniprogram/loading/loading",
"t-slider": "tdesign-miniprogram/slider/slider"
}
}

```

### 规格

**WXML** (`html`):
```html
<view class="loading-size-demo">
<t-loading theme="{{ skylineRender ? 'spinner' : 'circular'}}" size="64rpx" text="加载中..." class="large" />

<view class="demo-desc">中尺寸</view>

<t-loading theme="{{ skylineRender ? 'spinner' : 'circular'}}" size="56rpx" text="加载中..." class="medium" />

<view class="demo-desc">小尺寸</view>

<t-loading theme="{{ skylineRender ? 'spinner' : 'circular'}}" size="48rpx" text="加载中..." />
</view>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
behaviors: [SkylineBehavior],
});

```

**CSS** (`css`):
```css
.large {
--td-loading-text-font: var(--td-font-body-large);
}

.medium {
--td-loading-text-font: var(--td-font-body-medium);
}

.loading-size-demo .demo-desc {
margin: 48rpx 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"components": true,
"usingComponents": {
"t-loading": "tdesign-miniprogram/loading/loading"
}
}

```

## API

### LoadingProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| delay | Number | 0 | 延迟显示加载效果的时间，用于防止请求速度过快引起的加载闪烁，单位：毫秒 | N |
| duration | Number | 800 | 加载动画执行完成一次的时间，单位：毫秒 | N |
| fullscreen | Boolean | false | `1.8.5`。是否显示为全屏加载 | N |
| indicator | Boolean | true | 加载指示符，值为 true 显示默认指示符，值为 false 则不显示，也可以自定义指示符 | N |
| inherit-color | Boolean | false | 是否继承父元素颜色 | N |
| layout | String | horizontal | 对齐方式。可选项：horizontal/vertical | N |
| loading | Boolean | true | 是否处于加载状态 | N |
| pause | Boolean | false | 是否暂停动画 | N |
| progress | Number | - | 加载进度 | N |
| reverse | Boolean | - | 加载动画是否反向 | N |
| size | String | '20px' | 尺寸，示例：20px | N |
| text | String | - | 加载提示文案 | N |
| theme | String | circular | 加载组件类型。可选项：circular/spinner/dots | N |

### LoadingSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，作用同`text`插槽 |
| indicator | 自定义`indicator`显示内容 |
| text | 自定义`text`显示内容 |

### LoadingExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-indicator | 指示符样式类 |
| t-class-text | 文本样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-loading-color | @brand-color | - |
| --td-loading-full-bg-color | rgba(255, 255, 255, 0.6) | - |
| --td-loading-text-color | @text-color-primary | - |
| --td-loading-text-font | @font-body-small | - |
| --td-loading-z-index | 3500 | - |

---

# [message]

# Message 消息通知

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-message": "tdesign-miniprogram/message/message"
}
```

### 引入API

若以 API 形式调用 Message，则需在页面 `page.js` 中引入组件 API：

```js
import Message from 'tdesign-miniprogram/message/index';
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/mAyR8MmK8z5A)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

弹窗内容为纯文本、标题和副标题、带输入框，用 API `Message.info` 方法调用反馈类对话框。

**WXML** (`html`):
```html
<t-message id="t-message" />

<t-message visible="{{visible}}" offset="{{[90, 32]}}" content="这是一条通过组件调用的消息通知" />

<view class="message-example">
<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showTextMessage"
>纯文字的通知</t-button
>

<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showIconMessage"
>带图标的通知</t-button
>

<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showCloseMessage"
>带关闭的通知</t-button
>

<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showScrollMessage"
>可滚动的通知</t-button
>

<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showBtnMessage"
>带按钮的通知</t-button
>

<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showComponent"
>组件调用</t-button
>
</view>

```

**JS** (`javascript`):
```javascript
import Message from 'tdesign-miniprogram/message/index';

Component({
data: {
visible: false,
},
methods: {
showTextMessage() {
Message.info({
context: this,
offset: [90, 32],
duration: 5000,
icon: false,
// single: false, // 打开注释体验多个消息叠加效果
content: '这是一条纯文字的消息通知 5s消失',
});
},

showIconMessage() {
Message.info({
context: this,
offset: ['180rpx', '32rpx'],
duration: 5000,
content: '这是一条带图标的消息通知 5s消失',
});
},

showCloseMessage() {
Message.info({
context: this,
offset: ['180rpx', 32],
content: '这是一条带关闭的消息通知',
duration: -1,
link: {
content: '按钮',
navigatorProps: {
url: '/page/xxx/xxx',
},
},
closeBtn: true,
});
},

showScrollMessage() {
Message.info({
context: this,
offset: [90, 32],
marquee: { speed: 50, loop: -1, delay: 5000 },
icon: false,
content: '这是一条滚动的通知信息',
duration: -1,
});
},

showBtnMessage() {
Message.info({
context: this,
offset: [90, 32],
icon: 'notification-filled',
content: '这是一条带操作的消息通知',
duration: -1,
link: {
content: '链接',
navigatorProps: {
url: '/page/xxx/xxx',
},
},
});
},
showSingleMessage() {
Message.info({
context: this,
offset: [90, 32],
duration: 5000,
icon: false,
content: '这是一条纯文字的消息通知且仅显示一条',
single: true,
});
},
showComponent() {
this.setData({
visible: true,
});
},
},
});

```

**CSS** (`css`):
```css
.message-example {
margin: 32rpx;
}

.external-class {
margin: 0 0 32rpx 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-message": "tdesign-miniprogram/message/message"
}
}

```

### 组件状态

消息通知类型为普通（info）、警示（warning）、成功（success）、错误（error）

**WXML** (`html`):
```html
<t-message id="t-message" />

<view class="message-example">
<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showInfoMessage"
>普通通知</t-button
>

<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showSuccessMessage"
>成功通知</t-button
>

<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showWarnMessage"
>警示通知</t-button
>

<t-button t-class="external-class" theme="primary" variant="outline" size="large" block bind:tap="showErrorMessage"
>错误通知</t-button
>
</view>

```

**JS** (`javascript`):
```javascript
import Message from 'tdesign-miniprogram/message/index';

Component({
methods: {
showInfoMessage() {
Message.info({
context: this,
offset: [90, 32],
duration: 5000,
content: '这是一条普通通知信息',
});
},

showWarnMessage() {
Message.warning({
context: this,
offset: [90, 32],
duration: 5000,
content: '这是一条需要用户关注到的警示通知',
});
},

showSuccessMessage() {
Message.success({
context: this,
offset: [90, 32],
duration: 5000,
content: '这是一条成功的提示消息',
});
},

showErrorMessage() {
Message.error({
context: this,
offset: [90, 32],
duration: 5000,
content: '这是一条错误提示通知',
});
},
},
});

```

**CSS** (`css`):
```css
.message-example {
margin: 32rpx;
}

.external-class {
margin: 0 0 32rpx 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-button": "tdesign-miniprogram/button/button",
"t-message": "tdesign-miniprogram/message/message"
}
}

```

## API

### MessageProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| action | String | - | 已废弃。操作 | N |
| align | String | left | 文本对齐方式。可选项：left/center。TS 类型：`MessageAlignType``type MessageAlignType = 'left' \| 'center'`。详细类型定义 | N |
| close-btn | String / Boolean / Object | false | 关闭按钮，可以自定义。值为 true 显示默认关闭按钮，值为 false 不显示关闭按钮。值类型为 string ，如：'user'，则显示组件内置图标。值类型为 object ，则会透传至 icon 组件 | N |
| content | String | - | 用于自定义消息弹出内容 | N |
| duration | Number | 3000 | 消息内置计时器，计时到达时会触发 duration-end 事件。单位：毫秒。值为 0 则表示没有计时器 | N |
| gap | String / Number / Boolean | 12 | 两条`message`之间的间距 | N |
| icon | String / Boolean / Object | true | 消息提醒前面的图标，可以自定义。值为 true 则根据 theme 显示对应的图标，值为 false 则不显示图标。值为 true 显示默认关闭按钮，值为 false 不显示关闭按钮。值类型为 string ，如：'info'，则显示组件内置图标。值类型为 object ，则会透传至 icon 组件 | N |
| link | String / Object | - | 链接名称。值为字符串表示链接名称，值为`Object`类型，表示透传至`Link` | N |
| marquee | Boolean / Object | false | 跑马灯效果。speed 指速度控制；loop 指循环播放次数，值为 -1 表示循环播放，值为 0 表示不循环播放；delay 表示延迟多久开始播放。TS 类型：`boolean \| MessageMarquee``interface MessageMarquee { speed?: number; loop?: number; delay?: number }`。详细类型定义 | N |
| offset | Array | - | 相对于 placement 的偏移量，默认单位 rpx。示例：[-10, 20] 或 ['10rpx', '8rpx']。TS 类型：`Array<string \| number>` | N |
| single | Boolean | true | 是否保持仅显示一条信息 | N |
| theme | String | info | 消息组件风格。可选项：info/success/warning/error。TS 类型：`MessageThemeList``type MessageThemeList = 'info' \| 'success' \| 'warning' \| 'error'`。详细类型定义 | N |
| visible | Boolean | false | 是否显示，隐藏时默认销毁组件 | N |
| default-visible | Boolean | undefined | 是否显示，隐藏时默认销毁组件。非受控属性 | N |
| z-index | Number | 15000 | 元素层级，样式默认为 15000 | N |

### MessageEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| action-btn-click | - | 已废弃。当操作按钮存在时，用户点击操作按钮时触发 |
| close-btn-click | - | 当关闭按钮存在时，用户点击关闭按钮触发 |
| duration-end | - | 计时结束后触发 |
| link-click | - | 当`link`链接存在时，点击链接文本时触发 |

### MessageSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，作用同`content`插槽 |
| action | 已废弃。自定义`action`显示内容 |
| close-btn | 关闭按钮 |
| content | 自定义消息弹出内容 |
| icon | 消息提醒前面的图标 |
| link | 链接名称 |

### MessageExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-close-btn | 关闭按钮样式类 |
| t-class-content | 内容样式类 |
| t-class-icon | 图标样式类 |
| t-class-link | 链接样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-message-bg-color | @bg-color-container | - |
| --td-message-border-radius | @radius-default | - |
| --td-message-box-shadow | @shadow-4 | - |
| --td-message-close-icon-color | @font-gray-3 | - |
| --td-message-content-font-color | @font-gray-1 | - |
| --td-message-error-color | @error-color | - |
| --td-message-info-color | @brand-color | - |
| --td-message-success-color | @success-color | - |
| --td-message-warning-color | @warning-color | - |

---

# [navbar]

# Navbar 导航栏

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar",
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/XmyPWMmX8D5A)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础导航栏

**WXML** (`html`):
```html
<view class="block">
<t-navbar title="标题文字" fixed="{{false}}" placeholder t-class-title="nav-title" />
</view>

<view class="block">
<t-navbar class="block" title="标题文字" fixed="{{false}}" left-arrow bind:go-back="handleBack" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
handleBack() {
console.log('go back');
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar"
}
}

```

### 胶囊样式导航栏

**WXML** (`html`):
```html
<t-navbar fixed="{{false}}" title="标题文字">
<view slot="capsule" class="custom-capsule">
<t-icon
size="40rpx"
bind:tap="onBack"
aria-role="button"
aria-label="返回"
name="chevron-left"
class="custom-capsule__icon back"
/>
<t-icon
size="40rpx"
bind:tap="onGoHome"
aria-role="button"
aria-label="首页"
name="home"
class="custom-capsule__icon home"
/>
</view>
</t-navbar>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
onBack() {
wx.navigateBack();
},
onGoHome() {
wx.reLaunch({
url: '/pages/home/home',
});
},
},
});

```

**CSS** (`css`):
```css
.custom-capsule {
width: 100%;
display: flex;
align-items: center;
justify-content: center;
}

.custom-capsule__icon {
flex: 1;
position: relative;
}

.custom-capsule__icon.home:before {
content: '';
display: block;
position: absolute;
left: -1px;
top: 50%;
transform: translateY(-50%);
width: 1px;
height: 18px;
background: #e7e7e7;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

### 带搜索导航栏

**WXML** (`html`):
```html
<t-navbar fixed="{{false}}" leftIcon="slot">
<view class="search-box" slot="left">
<t-search shape="round" placeholder="搜索内容" />
</view>
</t-navbar>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.search-box {
--td-search-height: 32px;
--td-search-font: var(--td-font-body-medium);
--td-search-icon-size: 40rpx;
width: 252px;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar",
"t-search": "tdesign-miniprogram/search/search"
}
}

```

### 带图片导航栏

**WXML** (`html`):
```html
<t-navbar fixed="{{false}}">
<view slot="left">
<t-image
t-class="custom-image"
src="{{theme === 'dark' ? 'https://tdesign.gtimg.com/mobile/demos/image-dark.png' : 'https://tdesign.gtimg.com/mobile/demos/logo-light.png'}}"
aria-label="导航栏图片"
/>
</view>
</t-navbar>

```

**JS** (`javascript`):
```javascript
import themeChangeBehavior from 'tdesign-miniprogram/mixins/theme-change';

Component({
behaviors: [themeChangeBehavior],
});

```

**CSS** (`css`):
```css
.custom-image {
height: 24px;
width: 87px;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar",
"t-image": "tdesign-miniprogram/image/image"
}
}

```

### 组件样式

**WXML** (`html`):
```html
<view class="block">
<t-navbar fixed="{{false}}" left-arrow title="标题居中" />
</view>

<t-navbar fixed="{{false}}" left-arrow>
<view slot="left" class="custom-title">标题左对齐</view>
</t-navbar>

<view class="demo-desc">标题尺寸</view>

<t-navbar fixed="{{false}}" left-arrow>
<text class="left-text" slot="left" bind:tap="onBack">返回</text>
</t-navbar>
<view class="header-title">大标题尺寸</view>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
onBack() {
wx.navigateBack();
},
},
});

```

**CSS** (`css`):
```css
.custom-title {
margin-left: 8px;
font-size: 18px;
font-weight: 600;
}

.block {
display: block;
margin-bottom: 48rpx;
}

.demo-desc {
margin-top: 48rpx;
margin-bottom: 32rpx;
}

.left-text {
display: block;
margin-left: 4px;
font-size: 16px;
}

.header-title {
font-size: 28px;
line-height: 36px;
padding: 8rpx 32rpx 16rpx;
background-color: var(--td-bg-color-container);
font-weight: 600;
color: var(--td-text-color-primary);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar"
}
}

```

### 自定义颜色

**WXML** (`html`):
```html
<t-navbar class="custom-navbar" fixed="{{false}}" left-arrow title="标题文字" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.custom-navbar {
--td-navbar-color: #fff;
--td-navbar-bg-color: #0052d9;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-navbar": "tdesign-miniprogram/navbar/navbar"
}
}

```

## API

### NavbarProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| animation | Boolean | true | 是否添加动画效果 | N |
| background | String | - | 已废弃。背景 | N |
| delta | Number | 1 | 后退按钮后退层数，含义参考wx.navigateBack，特殊的，传入 0 不会发生执行 wx.navigateBack | N |
| fixed | Boolean | true | 是否固定在顶部 | N |
| home-icon | String | - | 已废弃。首页图标地址。值为 '' 或者 undefined 则表示不显示返回图标，值为 'circle' 表示显示默认图标，值为 'slot' 表示使用插槽渲染，值为其他则表示图标地址 | N |
| left-arrow | Boolean | false | `0.26.0`。是否展示左侧箭头 | N |
| left-icon | String | - | 已废弃。左侧图标地址，值为 '' 或者 undefined 则表示不显示返回图标，值为 'arrow-left' 表示显示返回图标，值为 'slot' 表示使用插槽渲染，值为其他则表示图标地址 | N |
| placeholder | Boolean | false | `1.12.1`。固定在顶部时是否开启占位 | N |
| safe-area-inset-top | Boolean | true | 是否开启顶部安全区适配 | N |
| title | String | - | 页面标题 | N |
| title-max-length | Number | - | 标题文字最大长度，超出的范围使用`...`表示 | N |
| visible | Boolean | true | 是否显示 | N |
| z-index | Number | 1 | 导航条层级 | N |

### NavbarEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| complete | - | navigateBack 执行完成后触发（失败或成功均会触发） |
| fail | - | navigateBack 执行失败后触发 |
| go-back | - | 点击左侧箭头时触发 |
| go-home | - | 已废弃。点击 Home 触发 |
| success | - | navigateBack 执行成功后触发 |

### NavbarSlots

| 名称 | 描述 |
| --- | --- |
| capsule | 左侧胶囊区域 |
| left | `0.26.0`。左侧内容区域 |
| title | 自定义`title`显示内容 |

### NavbarExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-capsule | 左侧胶囊区域样式类 |
| t-class-center | 中间内容样式类 |
| t-class-home-icon | 首页图标样式类 |
| t-class-left | 左侧内容样式类 |
| t-class-left-icon | 左侧图标样式类 |
| t-class-nav-btn | 导航按钮样式类 |
| t-class-title | 标题样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-navbar-padding-top | 20px | - |
| --td-navbar-right | 95px | - |
| --td-navbar-background | @navbar-bg-color | - |
| --td-navbar-bg-color | @bg-color-container | - |
| --td-navbar-capsule-border-color | @border-level-1-color | - |
| --td-navbar-capsule-border-radius | 16px | - |
| --td-navbar-capsule-height | 32px | - |
| --td-navbar-capsule-width | 88px | - |
| --td-navbar-center-left | @navbar-right | - |
| --td-navbar-center-width | 187px | - |
| --td-navbar-color | @text-color-primary | - |
| --td-navbar-height | 48px | - |
| --td-navbar-left-arrow-size | 24px | - |
| --td-navbar-left-max-width | --td-navbar-left-max-width | - |
| --td-navbar-title-font | @font-title-large | - |

---

# [notice-bar]

# NoticeBar 公告栏

## 示例

该组件于 0.9.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-notice-bar": "tdesign-miniprogram/notice-bar/notice-bar"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/MEyzaMmo8I52)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

纯文字的公告栏

**WXML** (`html`):
```html
<t-notice-bar visible="{{true}}" prefixIcon="{{false}}">
<view slot="content">这是一条普通的通知信息</view>
</t-notice-bar>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-notice-bar": "tdesign-miniprogram/notice-bar/notice-bar"
}
}

```

带图标的公告栏

**WXML** (`html`):
```html
<t-notice-bar visible="{{visible}}" prefixIcon="{{false}}" content="提示文字描述提示文字描述提示文字描述">
<view slot="prefix-icon">
<t-icon name="error-circle-filled"></t-icon>
</view>
</t-notice-bar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: true,
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-notice-bar": "tdesign-miniprogram/notice-bar/notice-bar",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

带关闭的公告栏

**WXML** (`html`):
```html
<t-notice-bar
visible="{{visible}}"
suffixIcon="close"
content="这是一条普通的通知信息"
bind:click="click"
></t-notice-bar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: true,
},

methods: {
click(e) {
const { trigger } = e.detail;
console.log(`click on the ${trigger} area`);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-notice-bar": "tdesign-miniprogram/notice-bar/notice-bar"
}
}

```

带入口的公告栏

**WXML** (`html`):
```html
<t-notice-bar visible="{{visible}}" suffixIcon="chevron-right" bind:click="click">
<view slot="content" class="inline"> 这是一条普通的通知信息 </view>
<t-link slot="operation" content="详情" theme="primary" underline="{{false}}" navigator-props="{{navigatorProps}}" />
</t-notice-bar>

<t-notice-bar
visible="{{visible}}"
suffixIcon="chevron-right"
content="这是一条普通的通知信息"
bind:click="click"
></t-notice-bar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: true,
navigatorProps: {
url: '/pages/xxx/xxx',
},
},

methods: {
click(e) {
const { trigger } = e.detail;
console.log(`click on the ${trigger} area`);
},
},
});

```

**CSS** (`css`):
```css
.inline {
display: inline;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-notice-bar": "tdesign-miniprogram/notice-bar/notice-bar",
"t-link": "tdesign-miniprogram/link/link"
}
}

```

自定义样式的公告栏

**WXML** (`html`):
```html
<t-notice-bar
visible="{{true}}"
prefixIcon="sound"
suffixIcon="chevron-right"
content="提示文字描述提示文字描述提示文字描述"
t-class="external-class"
t-class-prefix-icon="external-class-prefix-icon"
></t-notice-bar>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
page .external-class {
opacity: 1;
background: var(--td-bg-color-secondarycontainer, #f3f3f3);
}

page .external-class-prefix-icon {
color: var(--td-text-color-primary);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-notice-bar": "tdesign-miniprogram/notice-bar/notice-bar"
}
}

```

自定义内容的公告栏

**WXML** (`html`):
```html
<!-- slot实现自定义content内容 -->
<t-notice-bar visible="{{true}}">
<view slot="content" class="inline"> 提示文字描述提示文字描述提示文字描述提示文字描述提示文字描述提示文字描述 </view>
<t-link slot="operation" content="详情" theme="primary" underline="{{false}}" navigator-props="{{navigatorProps}}" />
<t-icon slot="suffix-icon" name="close" size="44rpx"></t-icon>
</t-notice-bar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
navigatorProps: {
url: '/pages/xxx/xxx',
},
},
});

```

**CSS** (`css`):
```css
.inline {
display: inline;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-notice-bar": "tdesign-miniprogram/notice-bar/notice-bar",
"t-link": "tdesign-miniprogram/link/link",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

### 02组件状态

公告栏类型有普通（info）、警示（warning）、成功（success）、错误（error）

**WXML** (`html`):
```html
<t-notice-bar visible="{{true}}" content="默认状态公告栏默认状态公告栏"></t-notice-bar>
<t-notice-bar visible="{{true}}" theme="success" content="成功状态公告栏成功状态公告栏"></t-notice-bar>
<t-notice-bar visible="{{true}}" theme="warning" content="警示状态公告栏警示状态公告栏"></t-notice-bar>
<t-notice-bar visible="{{true}}" theme="error" content="错误状态公告栏错误状态公告栏"></t-notice-bar>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-notice-bar": "tdesign-miniprogram/notice-bar/notice-bar"
}
}

```

### 03可滚动公告栏

可滚动公告栏有水平（horizontal）和垂直（vertical）

**WXML** (`html`):
```html
<t-notice-bar
visible="{{visible}}"
prefixIcon="{{false}}"
marquee="{{marquee1}}"
content="提示文字描述提示文字描述提示文字描述提示文字描述文"
></t-notice-bar>

<t-notice-bar
visible="{{visible}}"
marquee="{{marquee2}}"
content="提示文字描述提示文字描述提示文字描述提示文字描述文"
></t-notice-bar>

<t-notice-bar
visible="{{true}}"
direction="vertical"
interval="{{3000}}"
content="{{content}}"
prefixIcon="sound"
bind:click="click"
></t-notice-bar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: true,
marquee1: {
speed: 80,
loop: -1,
delay: 0,
},
marquee2: {
speed: 60,
loop: -1,
delay: 0,
},
content: ['君不见', '高堂明镜悲白发', '朝如青丝暮成雪', '人生得意须尽欢', '莫使金樽空对月'],
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-notice-bar": "tdesign-miniprogram/notice-bar/notice-bar"
}
}

```

## API

### NoticeBarProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| content | String / Array | - | 文本内容 | N |
| direction | String | horizontal | 滚动方向。可选项：horizontal/vertical | N |
| interval | Number | 2000 | 间隔时间【仅在 direction='vertical' 有效】 | N |
| marquee | Boolean / Object | false | 跑马灯效果。speed 指速度控制；loop 指循环播放次数，值为 -1 表示循环播放，值为 0 表示不循环播放；delay 表示延迟多久开始播放【仅在 direction='horizontal' 有效】。TS 类型：`boolean \| NoticeBarMarquee``interface NoticeBarMarquee { speed?: number; loop?: number; delay?: number }`。详细类型定义 | N |
| operation | String | - | 右侧额外信息 | N |
| prefix-icon | String / Boolean / Object | true | 前缀图标。值为字符串表示图标名称，值为`false`表示不显示前缀图标，值为`Object`类型，表示透传至`icon`，不传表示使用主题图标 | N |
| suffix-icon | String / Object | - | 后缀图标。值为字符串表示图标名称。值为`Object`类型，表示透传至`icon`，不传表示不显示后缀图标 | N |
| theme | String | info | 内置主题。可选项：info/success/warning/error | N |
| visible | Boolean | false | 显示/隐藏 | N |
| default-visible | Boolean | undefined | 显示/隐藏。非受控属性 | N |

### NoticeBarEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(current: number, source: '' \| 'autoplay' \| 'touch')` | 当`direction="vertical"`时轮播切换时触发 |
| click | `(trigger: NoticeBarTrigger)` | 点击事件。详细类型定义。<br>`type NoticeBarTrigger = 'prefix-icon' \| 'content' \| 'operation' \| 'suffix-icon';`<br> |

### NoticeBarSlots

| 名称 | 描述 |
| --- | --- |
| content | 文本内容 |
| operation | 自定义`operation`显示内容 |
| prefix-icon | 前缀图标 |
| suffix-icon | 后缀图标 |

### NoticeBarExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |
| t-class-operation | 右侧额外信息样式类 |
| t-class-prefix-icon | 前置图标样式类 |
| t-class-suffix-icon | 后置图标样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-notice-bar-error-bg-color | @error-color-1 | - |
| --td-notice-bar-error-color | @error-color | - |
| --td-notice-bar-font-color | @text-color-primary | - |
| --td-notice-bar-info-bg-color | @brand-color-light | - |
| --td-notice-bar-info-color | @brand-color | - |
| --td-notice-bar-operation-font-color | @brand-color | - |
| --td-notice-bar-success-bg-color | @success-color-1 | - |
| --td-notice-bar-success-color | @success-color | - |
| --td-notice-bar-suffix-icon-color | @text-color-placeholder | - |
| --td-notice-bar-warning-bg-color | @warning-color-1 | - |
| --td-notice-bar-warning-color | @warning-color | - |

---

# [overlay]

# Overlay 遮罩层

## 示例

该组件于 0.10.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-overlay": "tdesign-miniprogram/overlay/overlay"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/K7ypAMmC8L5D)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础使用

**WXML** (`html`):
```html
<t-overlay visible="{{visible}}" duration="{{500}}" bind:click="handleOverlayClick" />

<t-button block size="large" theme="primary" variant="outline" bind:tap="handleClick">基础用法</t-button>

```

**JS** (`javascript`):
```javascript
Component({
data: {
visible: false,
},
methods: {
handleClick() {
this.setData({ visible: true });
},
handleOverlayClick(e) {
this.setData({
visible: e.detail.visible,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-overlay": "tdesign-miniprogram/overlay/overlay",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

## API

### OverlayProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| background-color | String | - | 遮罩层的背景色 | N |
| duration | Number | 300 | 背景色过渡时间，单位毫秒 | N |
| prevent-scroll-through | Boolean | true | 防止滚动穿透，即不允许点击和滚动 | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| visible | Boolean | false | 是否展示 | N |
| z-index | Number | 11000 | 遮罩层级 | N |

### OverlayEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| click | `({ visible: boolean })` | 点击遮罩时触发 |

### OverlaySlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-overlay-bg-color | @mask-active | - |
| --td-overlay-transition-duration | 300ms | - |

---

# [picker]

# Picker 选择器

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-picker": "tdesign-miniprogram/picker/picker",
"t-picker-item": "tdesign-miniprogram/picker-item/picker-item",
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/T7yFwMmi8O57)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

#### 基础选择器

单项和多选选择

**WXML** (`html`):
```html
<t-cell class="mb-16" title="选择城市" arrow hover note="{{cityText}}" bind:click="onCityPicker" />

<t-cell class="mb-16" title="选择时间" arrow hover note="{{dateText}}" bind:click="onSeasonPicker" />

<t-picker
visible="{{cityVisible}}"
value="{{cityValue}}"
data-key="city"
title="选择城市"
cancelBtn="取消"
confirmBtn="确认"
usingCustomNavbar
bindchange="onPickerChange"
bindpick="onColumnChange"
bindcancel="onPickerCancel"
>
<t-picker-item options="{{citys}}" format="{{formatter}}">
<block wx:for="{{citys}}" wx:key="index" wx:for-item="option">
<view wx:if="{{option.tag}}" slot="label-suffix--{{index}}" class="label-suffix">
<t-tag size="small" theme="primary">{{option.tag}}</t-tag>
</view>
</block>
</t-picker-item>
</t-picker>

<t-picker
visible="{{dateVisible}}"
value="{{dateValue}}"
data-key="date"
title="选择时间"
cancelBtn="取消"
confirmBtn="确认"
usingCustomNavbar
bindchange="onPickerChange"
bindpick="onColumnChange"
bindcancel="onPickerCancel"
>
<t-picker-item options="{{years}}"></t-picker-item>
<t-picker-item options="{{seasons}}"></t-picker-item>
</t-picker>

```

**JS** (`javascript`):
```javascript
Component({
data: {
cityText: '',
cityValue: [],
dateText: '',
dateValue: [],
citys: [
{ label: '北京市', value: '北京市', icon: 'home', tag: '合' },
{ label: '上海市', value: '上海市', tag: '合' },
{ label: '广州市', value: '广州市' },
{ label: '深圳市', value: '深圳市' },
{ label: '成都市', value: '成都市' },
],
years: [
{ label: '2021年', value: '2021' },
{ label: '2020年', value: '2020' },
{ label: '2019年', value: '2019' },
],
seasons: [
{ label: '春', value: '春' },
{ label: '夏', value: '夏' },
{ label: '秋', value: '秋' },
{ label: '冬', value: '冬' },
],
formatter(item) {
const { value, label } = item;
if (value === '北京市') {
return {
...item,
value,
label: label.substring(0, 2),
};
}
return item;
},
},

methods: {
onColumnChange(e) {
console.log('picker pick:', e);
},

onPickerChange(e) {
const { key } = e.currentTarget.dataset;
const { value } = e.detail;

console.log('picker change:', e.detail);
this.setData({
[`${key}Visible`]: false,
[`${key}Value`]: value,
[`${key}Text`]: value.join(' '),
});
},

onPickerCancel(e) {
const { key } = e.currentTarget.dataset;
console.log(e, '取消');
console.log('picker1 cancel:');
this.setData({
[`${key}Visible`]: false,
});
},

onCityPicker() {
this.setData({ cityVisible: true });
},

onSeasonPicker() {
this.setData({ dateVisible: true });
},
},
});

```

**CSS** (`css`):
```css
.mb-16 {
margin-bottom: 32rpx;
}

.label-suffix {
--td-tag-small-height: 32rpx;

display: flex;
align-items: center;
justify-content: center;
margin-left: 12rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell-group": "tdesign-miniprogram/cell-group/cell-group",
"t-cell": "tdesign-miniprogram/cell/cell",
"t-picker": "tdesign-miniprogram/picker/picker",
"t-picker-item": "tdesign-miniprogram/picker-item/picker-item",
"t-tag": "tdesign-miniprogram/tag/tag"
}
}

```

#### 地区选择器

支持省市区切换，支持数据联动

**WXML** (`html`):
```html
<t-cell title="选择地区" arrow hover note="{{areaText}}" bind:click="onAreaPicker" />

<t-picker
visible="{{areaVisible}}"
value="{{areaValue}}"
title="选择地区"
cancelBtn="取消"
confirmBtn="确认"
usingCustomNavbar
bindchange="onPickerChange"
bindpick="onColumnChange"
bindcancel="onPickerCancel"
>
<t-picker-item options="{{provinces}}"></t-picker-item>
<t-picker-item options="{{cities}}"></t-picker-item>
<t-picker-item options="{{counties}}"></t-picker-item>
</t-picker>

```

**JS** (`javascript`):
```javascript
const areaList = {
provinces: {
110000: '北京市',
440000: '广东省',
},
cities: {
110100: '北京市',
440100: '广州市',
440200: '韶关市',
440300: '深圳市',
440400: '珠海市',
440500: '汕头市',
440600: '佛山市',
},
counties: {
110101: '东城区',
110102: '西城区',
110105: '朝阳区',
110106: '丰台区',
110107: '石景山区',
110108: '海淀区',
110109: '门头沟区',
110111: '房山区',
110112: '通州区',
110113: '顺义区',
110114: '昌平区',
110115: '大兴区',
110116: '怀柔区',
110117: '平谷区',
110118: '密云区',
110119: '延庆区',
440103: '荔湾区',
440104: '越秀区',
440105: '海珠区',
440106: '天河区',
440111: '白云区',
440112: '黄埔区',
440113: '番禺区',
440114: '花都区',
440115: '南沙区',
440117: '从化区',
440118: '增城区',
440203: '武江区',
440204: '浈江区',
440205: '曲江区',
440222: '始兴县',
440224: '仁化县',
440229: '翁源县',
440232: '乳源瑶族自治县',
440233: '新丰县',
440281: '乐昌市',
440282: '南雄市',
440303: '罗湖区',
440304: '福田区',
440305: '南山区',
440306: '宝安区',
440307: '龙岗区',
440308: '盐田区',
440309: '龙华区',
440310: '坪山区',
440311: '光明区',
440402: '香洲区',
440403: '斗门区',
440404: '金湾区',
440507: '龙湖区',
440511: '金平区',
440512: '濠江区',
440513: '潮阳区',
440514: '潮南区',
440515: '澄海区',
440523: '南澳县',
440604: '禅城区',
440605: '南海区',
440606: '顺德区',
440607: '三水区',
440608: '高明区',
},
};

// 使用这份数据可以模拟大量数据场景
// // 生成广东省1000个城市
// const generateCities = () => {
//   const cities = {
//     110100: '北京市',
//   };
//
//   // 生成广东省1000个城市
//   for (let i = 1; i <= 1000; i++) {
//     const cityCode = 440000 + i * 100;
//     cities[cityCode] = `广东城市${i}`;
//   }
//
//   return cities;
// };
//
// // 生成广州市10000个地区
// const generateCounties = () => {
//   const counties = {
//     110101: '东城区',
//     110102: '西城区',
//     110105: '朝阳区',
//     110106: '丰台区',
//     110107: '石景山区',
//     110108: '海淀区',
//     110109: '门头沟区',
//     110111: '房山区',
//     110112: '通州区',
//     110113: '顺义区',
//     110114: '昌平区',
//     110115: '大兴区',
//     110116: '怀柔区',
//     110117: '平谷区',
//     110118: '密云区',
//     110119: '延庆区',
//   };
//
//   // 生成广州市(440100)10000个地区
//   for (let i = 1; i <= 10000; i++) {
//     const countyCode = 44010000 + i;
//     counties[countyCode] = `广州地区${i}`;
//   }
//
//   return counties;
// };
//
// const areaList = {
//   provinces: {
//     110000: '北京市',
//     440000: '广东省',
//   },
//   cities: generateCities(),
//   counties: generateCounties(),
// };

const getOptions = (obj, filter) => {
const res = Object.keys(obj).map((key) => ({ value: key, label: obj[key] }));

if (filter) {
return res.filter(filter);
}

return res;
};

const match = (v1, v2, size) => v1.toString().slice(0, size) === v2.toString().slice(0, size);

Component({
data: {
areaText: '',
areaValue: [],
provinces: getOptions(areaList.provinces),
cities: [],
counties: [],
},

lifetimes: {
ready() {
this.init();
},
},

methods: {
init() {
const { provinces } = this.data;
const { cities, counties } = this.getCities(provinces[0].value);

this.setData({ cities, counties });
},

onColumnChange(e) {
console.log('pick:', e.detail);
const { column, index } = e.detail;
const { provinces, cities } = this.data;

if (column === 0) {
// 更改省份
const { cities, counties } = this.getCities(provinces[index].value);

this.setData({ cities, counties });
}

if (column === 1) {
// 更改城市
const counties = this.getCounties(cities[index].value);

this.setData({ counties });
}

if (column === 2) {
// 更改区县
}
},

getCities(provinceValue) {
const cities = getOptions(areaList.cities, (city) => match(city.value, provinceValue, 2));
const counties = this.getCounties(cities[0].value);

return { cities, counties };
},

getCounties(cityValue) {
return getOptions(areaList.counties, (county) => match(county.value, cityValue, 4));
},

onPickerChange(e) {
const { value, label } = e.detail;

console.log('picker confirm:', e.detail);
this.setData({
areaVisible: false,
areaValue: value,
areaText: label.join(' '),
});
},

onPickerCancel(e) {
console.log('picker cancel', e.detail);
this.setData({
areaVisible: false,
});

if (this.data.areaValue.length) return;
this.init();
},

onAreaPicker() {
this.setData({ areaVisible: true });
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell-group": "tdesign-miniprogram/cell-group/cell-group",
"t-cell": "tdesign-miniprogram/cell/cell",
"t-picker": "tdesign-miniprogram/picker/picker",
"t-picker-item": "tdesign-miniprogram/picker-item/picker-item"
}
}

```

### 组件样式

是否带标题

**WXML** (`html`):
```html
<t-cell class="mb-16" title="带标题选择器" arrow hover note="{{cityText}}" bind:click="onTitlePicker" />

<t-cell title="无标题选择器" arrow hover note="{{city2Text}}" bind:click="onWithoutTitlePicker" />

<t-picker
visible="{{cityVisible}}"
value="{{cityValue}}"
data-key="city"
title="{{cityTitle}}"
cancelBtn="取消"
confirmBtn="确认"
usingCustomNavbar
bindchange="onPickerChange"
bindpick="onColumnChange"
bindcancel="onPickerCancel"
>
<t-picker-item options="{{citys}}"></t-picker-item>
</t-picker>

<t-picker
visible="{{city2Visible}}"
value="{{city2Value}}"
data-key="city2"
title="{{city2Title}}"
cancelBtn="取消"
confirmBtn="确认"
usingCustomNavbar
bindchange="onPickerChange"
bindpick="onColumnChange"
bindcancel="onPickerCancel"
>
<t-picker-item options="{{citys}}"></t-picker-item>
</t-picker>

```

**JS** (`javascript`):
```javascript
Component({
data: {
cityText: '',
city2Text: '',
cityValue: [],
city2Value: [],
cityTitle: '',
city2Title: '',
citys: [
{ label: '北京市', value: '北京市' },
{ label: '上海市', value: '上海市' },
{ label: '广州市', value: '广州市' },
{ label: '深圳市', value: '深圳市' },
{ label: '成都市', value: '成都市' },
],
},

methods: {
onColumnChange(e) {
console.log('picker pick:', e);
},

onPickerChange(e) {
const { key } = e.currentTarget.dataset;
const { value } = e.detail;

console.log('picker change:', e.detail);
this.setData({
[`${key}Visible`]: false,
[`${key}Value`]: value,
[`${key}Text`]: value.join(' '),
});
},

onPickerCancel(e) {
const { key } = e.currentTarget.dataset;
console.log(e, '取消');
console.log('picker1 cancel:');
this.setData({
[`${key}Visible`]: false,
});
},

onTitlePicker() {
this.setData({ cityVisible: true, cityTitle: '选择城市' });
},

onWithoutTitlePicker() {
this.setData({ city2Visible: true, city2Title: '' });
},
},
});

```

**CSS** (`css`):
```css
.mb-16 {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell-group": "tdesign-miniprogram/cell-group/cell-group",
"t-cell": "tdesign-miniprogram/cell/cell",
"t-picker": "tdesign-miniprogram/picker/picker",
"t-picker-item": "tdesign-miniprogram/picker-item/picker-item"
}
}

```

## API

### PickerProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| auto-close | Boolean | true | 自动关闭；在确认、取消、点击遮罩层自动关闭，不需要手动设置 visible | N |
| cancel-btn | String / Boolean | true | 取消按钮文字。TS 类型：`boolean \| string` | N |
| confirm-btn | String / Boolean | true | 确定按钮文字。TS 类型：`boolean \| string` | N |
| header | Boolean | true | 头部内容。值为 true 显示空白头部，值为 false 不显示任何内容 | N |
| item-height | Number | 40 | PickerItem 的子项高度，单位`px` | N |
| keys | Object | - | 用来定义 value / label / icon 在`options`中对应的字段别名。TS 类型：`KeysType`。通用类型定义 | N |
| popup-props | Object | {} | 透传 Popup 组件全部属性。TS 类型：`PopupProps`，Popup API Documents。详细类型定义 | N |
| title | String | '' | 标题 | N |
| use-popup | Boolean | true | 是否使用弹出层包裹 | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| value | Array | - | 选中值。TS 类型：`Array<PickerValue>``type PickerValue = string \| number`。详细类型定义 | N |
| default-value | Array | undefined | 选中值。非受控属性。TS 类型：`Array<PickerValue>``type PickerValue = string \| number`。详细类型定义 | N |
| visible | Boolean | false | 是否显示 | N |
| visible-item-count | Number | 5 | 可视区域 PickerItem 的子项个数 | N |

### PickerEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| cancel | - | 点击取消按钮时触发 |
| change | `(value: Array<PickerValue>, label: string, columns: Array<{ column: number; index: number; disabled?: boolean; }> )` | 选中变化时候触发，即确认变化时触发 |
| close | `(trigger: TriggerSource)` | `1.0.1`。关闭时触发。详细类型定义。<br>`type TriggerSource = 'overlay' \| 'cancel-btn' \| 'confirm-btn'`<br> |
| confirm | `(value: Array<PickerValue>, label: string, columns: Array<{ column: number; index: number; disabled?: boolean; }> )` | 点击确认按钮时触发 |
| pick | `(value: Array<PickerValue>, label: string, column: number, index: number)` | 任何一列选中都会触发，不同的列参数不同。`column`表示第几列变化，`index`表示变化那一列的选中项下标 |

### PickerSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容 |
| content | 中间内容，介于头部跟内容之间 |
| footer | 底部内容 |
| header | 自定义`header`显示内容 |

### PickerItemProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| format | Function | - | 格式化标签。TS 类型：`(option: PickerItemOption, columnIndex: number) => PickerItemOption` | N |
| options | Array | [] | 数据源。TS 类型：`PickerItemOption[]``interface PickerItemOption { label: string; value: string \| number; icon?: string }`。详细类型定义 | N |

### PickerItemSlots

| 名称 | 描述 |
| --- | --- |
| label-suffix-index | 列表子项后置插槽，用于自定义标签文本之后的内容。 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-picker-bg-color | @bg-color-container | - |
| --td-picker-border-radius | 24rpx | - |
| --td-picker-button-font | @font-body-large | - |
| --td-picker-cancel-color | @text-color-secondary | - |
| --td-picker-confirm-color | @brand-color | - |
| --td-picker-indicator-bg-color | @bg-color-secondarycontainer | - |
| --td-picker-indicator-border-radius | 12rpx | - |
| --td-picker-title-color | @text-color-primary | - |
| --td-picker-title-font | @font-title-large | - |
| --td-picker-toolbar-height | 116rpx | - |
| --td-picker-transparent-color | --td-picker-transparent-color | - |
| --td-picker-item-active-color | @text-color-primary | - |
| --td-picker-item-color | @text-color-secondary | - |
| --td-picker-item-font-size | @font-size-m | - |

---

# [popup]

# Popup 弹出层

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-popup": "tdesign-miniprogram/popup/popup"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/oDyr8Mmf8W57)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

基础弹出层

**WXML** (`html`):
```html
<t-popup
visible="{{visible}}"
usingCustomNavbar
bind:visible-change="onVisibleChange"
placement="{{cur.value || 'top'}}"
>
<view class="block block--{{cur.value}}">{{cur.text}}</view>
</t-popup>

<t-button
wx:for="{{position}}"
wx:key="index"
block
size="large"
variant="outline"
theme="primary"
bind:tap="handlePopup"
data-item="{{item}}"
t-class="wrapper"
>
{{item.text}}
</t-button>

```

**JS** (`javascript`):
```javascript
Component({
data: {
cur: {},
position: [
{ value: 'top', text: '顶部弹出' },
{ value: 'left', text: '左侧弹出' },
{ value: 'center', text: '中间弹出' },
{ value: 'bottom', text: '底部弹出' },
{ value: 'right', text: '右侧弹出' },
],
},
methods: {
handlePopup(e) {
const { item } = e.currentTarget.dataset;

this.setData(
{
cur: item,
},
() => {
this.setData({ visible: true });
},
);
},
onVisibleChange(e) {
this.setData({
visible: e.detail.visible,
});
},
},
});

```

**CSS** (`css`):
```css
.block {
color: var(--td-text-color-secondary);
display: flex;
align-items: center;
justify-content: center;
}

.block--top,
.block--bottom {
width: 100vw;
height: 240px;
}

.block--left,
.block--right {
width: 280px;
height: 100%;
}

.block--center {
width: 240px;
height: 240px;
}

.wrapper {
margin-bottom: 32rpx;
}

.wrapper:last-child {
margin-bottom: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-popup": "tdesign-miniprogram/popup/popup",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

### 组件示例

应用示例

**WXML** (`html`):
```html
<t-popup visible="{{visible}}" bind:visible-change="onVisibleChange" placement="bottom">
<view class="block">
<view class="header">
<view class="btn btn--cancel" aria-role="button">取消</view>
<view class="title">标题文字</view>
<view class="btn btn--confirm" aria-role="button">确定</view>
</view>
</view>
</t-popup>

<t-button block size="large" variant="outline" theme="primary" bind:tap="handlePopup">底部弹出层-带标题及操作</t-button>

```

**JS** (`javascript`):
```javascript
Component({
data: {
cur: {},
position: [
{ value: 'top', text: '顶部弹出' },
{ value: 'left', text: '左侧弹出' },
{ value: 'center', text: '中间弹出' },
{ value: 'bottom', text: '底部弹出' },
{ value: 'right', text: '右侧弹出' },
],
},
methods: {
handlePopup(e) {
const { item } = e.currentTarget.dataset;

this.setData(
{
cur: item,
},
() => {
this.setData({ visible: true });
},
);
},
onVisibleChange(e) {
this.setData({
visible: e.detail.visible,
});
},
},
});

```

**CSS** (`css`):
```css
.block {
width: 100vw;
height: 240px;
background: var(--td-bg-color-container);
border-top-left-radius: 16rpx;
border-top-right-radius: 16rpx;
}

.header {
display: flex;
align-items: center;
height: 116rpx;
}

.title {
flex: 1;
text-align: center;
font-weight: 600;
font-size: 36rpx;
color: var(--td-text-color-primary);
}

.btn {
font-size: 32rpx;
padding: 32rpx;
}

.btn--cancel {
color: var(--td-text-color-secondary);
}

.btn--confirm {
color: #0052d9;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-popup": "tdesign-miniprogram/popup/popup",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

**WXML** (`html`):
```html
<t-popup visible="{{visible}}" bind:visible-change="onVisibleChange" placement="center">
<view class="block">
<t-icon t-class="close-btn" name="close-circle" size="64rpx" color="#fff" bind:tap="onClose" />
</view>
</t-popup>

<t-button block size="large" variant="outline" theme="primary" bind:tap="handlePopup">
居中弹出层-带自定义关闭按钮
</t-button>

```

**JS** (`javascript`):
```javascript
Component({
data: {
cur: {},
position: [
{ value: 'top', text: '顶部弹出' },
{ value: 'left', text: '左侧弹出' },
{ value: 'center', text: '中间弹出' },
{ value: 'bottom', text: '底部弹出' },
{ value: 'right', text: '右侧弹出' },
],
},
methods: {
handlePopup(e) {
const { item } = e.currentTarget.dataset;

this.setData(
{
cur: item,
},
() => {
this.setData({ visible: true });
},
);
},
onVisibleChange(e) {
this.setData({
visible: e.detail.visible,
});
},
onClose() {
this.setData({
visible: false,
});
},
},
});

```

**CSS** (`css`):
```css
.block {
position: relative;
width: 240px;
height: 240px;
background: var(--td-bg-color-container);
border-radius: 16rpx;
}

.close-btn {
position: absolute;
left: 50%;
margin-left: -32rpx;
bottom: calc(-1 * (48rpx + 64rpx));
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-popup": "tdesign-miniprogram/popup/popup",
"t-icon": "tdesign-miniprogram/icon/icon",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

## API

### PopupProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| close-btn | Boolean | - | 关闭按钮，值类型为 Boolean 时表示是否显示关闭按钮。也可以自定义关闭按钮 | N |
| close-on-overlay-click | Boolean | true | 点击遮罩层是否关闭 | N |
| content | String | - | 浮层里面的内容 | N |
| duration | Number | 240 | 动画过渡时间 | N |
| overlay-props | Object | {} | 遮罩层的属性，透传至 overlay。TS 类型：`OverlayProps`，Overlay API Documents。详细类型定义 | N |
| placement | String | top | 浮层出现位置。可选项：top/left/right/bottom/center | N |
| prevent-scroll-through | Boolean | true | 是否阻止背景滚动 | N |
| show-overlay | Boolean | true | 是否显示遮罩层 | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| visible | Boolean | - | 是否显示浮层。TS 类型：`boolean` | N |
| default-visible | Boolean | undefined | 是否显示浮层。非受控属性。TS 类型：`boolean` | N |
| z-index | Number | 11500 | 组件层级，Web 侧样式默认为 5500，移动端样式默认为 1500，小程序样式默认为11500 | N |

### PopupEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| visible-change | `(visible: boolean, trigger: PopupSource) ` | 当浮层隐藏或显示时触发。详细类型定义。<br>`type PopupSource = 'close-btn' \| 'overlay'`<br> |

### PopupSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，作用同`content`插槽 |
| close-btn | 自定义`close-btn`显示内容 |
| content | 自定义`content`显示内容 |

### PopupExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-popup-bg-color | @bg-color-container | - |
| --td-popup-border-radius | @radius-extraLarge | - |
| --td-popup-close-btn-color | @text-color-primary | - |
| --td-popup-distance-top | 0 | - |
| --td-popup-transition | all 300ms ease | - |

---

# [progress]

# Progress 进度条

## 示例

该组件于 0.7.3 版本上线，请留意版本。
## 引入

### 引入组件

在 `app.json` 或 `page.json` 中引入组件：

```json
"usingComponents": {
"t-progress": "tdesign-miniprogram/progress/progress"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/32zr7MmR8054)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

**WXML** (`html`):
```html
<view class="demo-desc">基础进度条</view>
<view class="demo-wrapper">
<t-progress percentage="80" />
</view>

<view class="demo-desc">百分比内显</view>
<view class="demo-wrapper">
<t-progress theme="plump" percentage="80" />
</view>

<view class="demo-desc">环形进度条</view>
<view class="demo-wrapper">
<t-progress theme="circle" percentage="30" />
</view>

<view class="demo-desc">微型环形进度条</view>
<view class="demo-wrapper">
<t-progress theme="circle" size="micro" percentage="30" label="{{false}}" />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.demo-wrapper {
padding: 0 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-progress": "tdesign-miniprogram/progress/progress"
}
}

```

### 02组件状态

线性进度条

**WXML** (`html`):
```html
<t-progress percentage="80" />
<t-progress percentage="80" status="warning" />
<t-progress percentage="80" status="error" />
<t-progress percentage="80" status="success" />
<t-progress percentage="80" color="{{ {  from: '#0052D9', to: '#00A870' } }}" status="active" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-progress": "tdesign-miniprogram/progress/progress"
}
}

```

百分比内显进度条

**WXML** (`html`):
```html
<t-progress theme="plump" percentage="80" />
<t-progress theme="plump" percentage="80" status="warning" />
<t-progress theme="plump" percentage="80" status="error" />
<t-progress theme="plump" percentage="80" status="success" />
<t-progress theme="plump" color="{{ {  from: '#0052D9', to: '#00A870' } }}" percentage="80" status="active" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-progress": "tdesign-miniprogram/progress/progress"
}
}

```

环形进度条

**WXML** (`html`):
```html
<t-demo desc="环形进度条" padding>
<t-progress theme="circle" percentage="30" />
<t-progress theme="circle" percentage="30" status="warning" />
<t-progress theme="circle" percentage="30" status="error" />
<t-progress theme="circle" percentage="100" status="success" />
</t-demo>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-progress": "tdesign-miniprogram/progress/progress"
}
}

```

## API

### ProgressProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| color | String / Object / Array | '' | 进度条颜色。示例：'#ED7B2F' 或 'orange' 或`['#f00', '#0ff', '#f0f']`或`{ '0%': '#f00', '100%': '#0ff' }`或`{ from: '#000', to: '#000' }`等。TS 类型：`string \| Array<string> \| Record<string, string>` | N |
| label | String / Boolean | true | 进度百分比，可自定义 | N |
| percentage | Number | 0 | 进度条百分比 | N |
| size | String / Number | 'default' | 进度条尺寸，仅对环形进度条有效。可选值：default/micro。default 值为 112； micro 值为 24 | N |
| status | String | - | 进度条状态。可选项：success/error/warning/active。TS 类型：`ProgressStatus``type ProgressStatus = 'success' \| 'error' \| 'warning' \| 'active'`。详细类型定义 | N |
| stroke-width | String / Number | - | 进度条线宽，默认单位`px` | N |
| theme | String | line | 进度条风格。值为 line，标签（label）显示在进度条右侧；值为 plump，标签（label）显示在进度条里面；值为 circle，标签（label）显示在进度条正中间。可选项：line/plump/circle。TS 类型：`ProgressTheme``type ProgressTheme = 'line' \| 'plump' \| 'circle'`。详细类型定义 | N |
| track-color | String | '' | 进度条未完成部分颜色 | N |

### ProgressSlots

| 名称 | 描述 |
| --- | --- |
| label | 进度百分比 |

### ProgressExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-bar | 进度文字样式类 |
| t-class-label | 标签样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-progress-info-dark-color | @text-color-primary | - |
| --td-progress-info-light-color | @text-color-anti | - |
| --td-progress-inner-bg-color-active | @bg-color-container | - |
| --td-progress-inner-bg-color-error | @error-color | - |
| --td-progress-inner-bg-color-success | @success-color | - |
| --td-progress-inner-bg-color-warning | @warning-color | - |
| --td-progress-circle-icon-size | 96rpx | - |
| --td-progress-circle-inner-bg-color | @bg-color-container | - |
| --td-progress-circle-label-font | @font-title-extraLarge | - |
| --td-progress-circle-width | 224rpx | - |
| --td-progress-inner-bg-color | @brand-color | - |
| --td-progress-line-stroke-width | 12rpx | - |
| --td-progress-stroke-circle-width | 12rpx | - |
| --td-progress-stroke-plump-width | 40rpx | - |
| --td-progress-track-bg-color | @bg-color-component | - |

---

# [pull-down-refresh]

# PullDownRefresh 下拉刷新

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-pull-down-refresh": "tdesign-miniprogram/pull-down-refresh/pull-down-refresh"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/5Uzn4Mml855j)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 顶部下拉刷新

由于组件内无法监听页面滚动，需要由页面获取组件实例，并将页面滚动事件传递到组件。

**WXML** (`html`):
```html
<t-pull-down-refresh
value="{{enable}}"
loadingTexts="{{['下拉刷新', '松手刷新', '正在刷新', '刷新完成']}}"
usingCustomNavbar
bind:refresh="onRefresh"
bind:scroll="onScroll"
>
<!-- 包裹页面全部内容 -->
<view class="demo">
<t-demo-header
title="PullDownRefresh 下拉刷新"
desc="用于快速刷新页面信息，刷新可以是整页刷新也可以是页面的局部刷新。"
notice="渲染框架支持情况：WebView"
/>
<view class="pulldown-refresh__content">
<t-skeleton rowCol="{{rowCol1}}" loading></t-skeleton>
<view class="row">
<t-skeleton rowCol="{{rowCol2}}" loading></t-skeleton>
<t-skeleton rowCol="{{rowCol2}}" loading></t-skeleton>
</view>
<view class="row">
<t-skeleton rowCol="{{rowCol2}}" loading></t-skeleton>
<t-skeleton rowCol="{{rowCol2}}" loading></t-skeleton>
</view>
<view class="row">
<t-skeleton rowCol="{{rowCol2}}" loading></t-skeleton>
<t-skeleton rowCol="{{rowCol2}}" loading></t-skeleton>
</view>
<view class="text">拖拽该区域演示 顶部下拉刷新</view>
</view>
<t-back-top text="顶部" scroll-top="{{scrollTop}}" visibility-height="{{100}}" />
</view>
</t-pull-down-refresh>

```

**JS** (`javascript`):
```javascript
Component({
data: {
enable: false,
rowCol1: [{ width: '100%', height: '342rpx', borderRadius: '24rpx' }],
rowCol2: [[{ width: '327rpx' }], [{ width: '200rpx' }], [{ size: '327rpx', borderRadius: '24rpx' }]],
scrollTop: 0,
},

ready() {
this.setData({ enable: true });
setTimeout(() => {
this.setData({ enable: false });
}, 1000);
},

methods: {
onRefresh() {
this.setData({ enable: true });
setTimeout(() => {
this.setData({ enable: false });
}, 1500);
},
onScroll(e) {
const { scrollTop } = e.detail;
this.setData({ scrollTop });
},
},
});

```

**CSS** (`css`):
```css
.demo {
padding-bottom: 56rpx;
overflow: hidden;
}

.demo-title {
font-size: 48rpx;
font-weight: 700;
line-height: 64rpx;
margin: 48rpx 32rpx 0;
color: var(--td-text-color-primary);
}

.demo-desc {
font-size: 28rpx;
color: var(--td-text-color-secondary);
margin: 16rpx 32rpx 0;
line-height: 44rpx;
}

.pulldown-refresh__content {
margin: 64rpx 32rpx 0;
position: relative;
}

.row {
display: flex;
justify-content: space-between;
margin-top: 32rpx;
}

.text {
position: absolute;
top: 152rpx;
left: 50%;
transform: translateX(-50%);
text-align: center;
font-size: 32rpx;
color: var(--td-text-color-disabled);
width: 686rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-pull-down-refresh": "tdesign-miniprogram/pull-down-refresh/pull-down-refresh",
"t-skeleton": "tdesign-miniprogram/skeleton/skeleton",
"t-back-top": "tdesign-miniprogram/back-top/back-top"
}
}

```

> 在使用 pull-down-refresh 组件的页面，建议开启 `disableScroll: true`

## API

### PullDownRefreshProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| disabled | Boolean | false | 是否禁用下拉刷新 | N |
| enable-back-to-top | Boolean | true | `1.1.5`。iOS点击顶部状态栏、安卓双击标题栏时，滚动条返回顶部，只支持竖向。自 2.27.3 版本开始，若非显式设置为 false，则在显示尺寸大于屏幕 90% 时自动开启 | N |
| enable-passive | Boolean | false | `1.1.5`。开启 passive 特性，能优化一定的滚动性能 | N |
| loading-bar-height | String / Number | 50 | 加载中下拉高度，如果值为数字则单位是：'px' | N |
| loading-props | Object | - | 加载loading样式。TS 类型：`LoadingProps`，Loading API Documents。详细类型定义 | N |
| loading-texts | Array | [] | 提示语，组件内部默认值为 ['下拉刷新', '松手刷新', '正在刷新', '刷新完成']。TS 类型：`string[]` | N |
| lower-threshold | String / Number | 50 | `1.1.5`。距底部/右边多远时，触发 scrolltolower 事件 | N |
| max-bar-height | String / Number | 80 | 最大下拉高度，如果值为数字则单位是：'px' | N |
| refresh-timeout | Number | 3000 | 刷新超时时间 | N |
| scroll-into-view | String | - | `1.1.5`。值应为某子元素id（id不能以数字开头）。设置哪个方向可滚动，则在哪个方向滚动到该元素 | N |
| show-scrollbar | Boolean | true | 滚动条显隐控制 (同时开启 enhanced 属性后生效) | N |
| success-duration | String / Number | 500 | 刷新成功提示展示时长，单位 'ms' | N |
| upper-threshold | String / Number | 50 | `1.1.5`。距顶部/左边多远时，触发 scrolltoupper 事件 | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |
| value | Boolean | false | 组件状态，值为`true`表示下拉状态，值为`false`表示收起状态 | N |
| default-value | Boolean | undefined | 组件状态，值为`true`表示下拉状态，值为`false`表示收起状态。非受控属性 | N |

### PullDownRefreshEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: boolean)` | 下拉或收起时触发，用户手势往下滑动触发下拉状态，手势松开触发收起状态 |
| dragend | `(scrollTop: number, scrollLeft: number)` | `1.2.10`。滑动结束事件 |
| dragging | `(scrollTop: number, scrollLeft: number)` | `1.2.10`。滑动事件 |
| dragstart | `(scrollTop: number, scrollLeft: number)` | `1.2.10`。滑动开始事件 |
| refresh | - | 结束下拉时触发 |
| scrolltolower | - | 滚动到页面底部时触发 |
| timeout | - | 刷新超时触发 |

### PullDownRefreshSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |
| header | `1.2.10`。头部 |

### PullDownRefreshExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-indicator | 指示样式类 |
| t-class-loading | 加载样式类 |
| t-class-text | 文本样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-pull-down-refresh-color | @text-color-placeholder | - |

---

# [radio]

# Radio 单选框

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-radio": "tdesign-miniprogram/radio/radio",
"t-radio-group": "tdesign-miniprogram/radio-group/radio-group"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/jWzlhMmr8e5m)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 纵向单选框

**WXML** (`html`):
```html
<t-radio-group bind:change="onChange" allow-uncheck value="{{current}}" options="{{options}}" />

```

**JS** (`javascript`):
```javascript
Component({
data: {
current: 1,
options: [
{ value: 0, label: '单选' },
{ value: 1, label: '单选' },
{ value: 2, label: '单选单选单选单选单选单选单选单选单选单选单选单选单选单选' },
{
value: 3,
label: '单选',
content: '描述信息描述信息描述信息描述信息描述信息描述信息描述信息描述信息描述信息描述信息',
},
],
},
methods: {
onChange(event) {
const { value } = event.detail;

this.setData({ current: value });
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-radio-group": "tdesign-miniprogram/radio-group/radio-group",
"t-radio": "tdesign-miniprogram/radio/radio"
}
}

```

### 横向单选框

**WXML** (`html`):
```html
<t-radio-group default-value="0" borderless t-class="box">
<t-radio block="{{false}}" label="单选标题" value="0" />
<t-radio block="{{false}}" label="单选标题" value="1" />
<t-radio block="{{false}}" label="上限四字" value="2" />
</t-radio-group>

```

**JS** (`javascript`):
```javascript
Page({
data: {
checked: false,
},
handleChange(e) {
this.setData({
checked: e.detail.checked,
});
},
});

```

**CSS** (`css`):
```css
.box {
padding: 32rpx;
display: flex;
justify-content: space-between;
flex-wrap: wrap;
background-color: var(--td-bg-color-container, #fff);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-radio-group": "tdesign-miniprogram/radio-group/radio-group",
"t-radio": "tdesign-miniprogram/radio/radio"
}
}

```

### 单选框状态

**WXML** (`html`):
```html
<t-radio-group defaultValue="radio1" disabled="{{true}}">
<t-radio value="radio1" label="单选" />
<t-radio value="radio2" label="单选" />
</t-radio-group>

```

**JS** (`javascript`):
```javascript
Component({
/**
* 组件的属性列表
*/
properties: {},

/**
* 组件的初始数据
*/
data: {},

/**
* 组件的方法列表
*/
methods: {},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-radio-group": "tdesign-miniprogram/radio-group/radio-group",
"t-radio": "tdesign-miniprogram/radio/radio"
}
}

```

### 勾选样式

**WXML** (`html`):
```html
<t-radio default-checked="{{true}}" allow-uncheck icon="line" label="单选" />

<view class="gutter" style="height: 32rpx"></view>

<t-radio default-checked="{{true}}" allow-uncheck icon="dot" label="单选" />

```

**JS** (`javascript`):
```javascript
Component({
/**
* 组件的属性列表
*/
properties: {},

/**
* 组件的初始数据
*/
data: {},

/**
* 组件的方法列表
*/
methods: {},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-radio": "tdesign-miniprogram/radio/radio"
}
}

```

### 勾选显示位置

**WXML** (`html`):
```html
<t-radio value="radio1" allow-uncheck label="单选" default-checked />

<view class="block"></view>

<t-radio value="radio2" allow-uncheck label="单选" placement="right" default-checked />

```

**JS** (`javascript`):
```javascript
Component({
/**
* 组件的属性列表
*/
properties: {},

/**
* 组件的初始数据
*/
data: {},

/**
* 组件的方法列表
*/
methods: {
onChange(event) {
console.log('radio', event.detail);
},
},
});

```

**CSS** (`css`):
```css
.block {
height: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-radio": "tdesign-miniprogram/radio/radio"
}
}

```

### 非通栏单选样式

**WXML** (`html`):
```html
<t-radio-group t-class="theme-card" default-value="radio1">
<t-radio label="单选" value="radio1" default-checked />
<t-radio label="单选" value="radio2" />
<t-radio label="单选标题多行单选标题多行单选标题多行单选标题多行单选标题多行" value="radio3" />
</t-radio-group>

```

**JS** (`javascript`):
```javascript
Component({
/**
* 组件的属性列表
*/
properties: {},

/**
* 组件的初始数据
*/
data: {},

/**
* 组件的方法列表
*/
methods: {
onChange() {},
},
});

```

**CSS** (`css`):
```css
.theme-card {
border-radius: 24rpx;
margin: 32rpx;
overflow: hidden;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-radio-group": "tdesign-miniprogram/radio-group/radio-group",
"t-radio": "tdesign-miniprogram/radio/radio"
}
}

```

### 特殊样式

**WXML** (`html`):
```html
<t-radio-group value="{{value}}" allow-uncheck bind:change="onChange">
<view wx:for="{{3}}" wx:key="index" class="card {{value == index ? 'card--active' : ''}}">
<t-icon wx:if="{{value == index}}" name="check" t-class="card__icon" />
<t-radio value="{{index}}" label="单选" content="描述信息描述信息描述信息描述信息描述信息" icon="none" borderless />
</view>
</t-radio-group>

<view class="demo-desc" style="margin: 48rpx 32rpx 32rpx">横向卡片单选框</view>

<t-radio-group t-class="horizontal-box" value="{{value1}}" bind:change="onChange1">
<view wx:for="{{3}}" wx:key="index" class="card {{value1 == index ? 'card--active' : ''}}">
<t-icon wx:if="{{value1 == index}}" name="check" t-class="card__icon" />
<t-radio value="{{index}}" label="单选" icon="none" borderless />
</view>
</t-radio-group>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 0,
value1: 0,
},
methods: {
onChange(e) {
this.setData({ value: e.detail.value });
},
onChange1(e) {
this.setData({ value1: e.detail.value });
},
},
});

```

**CSS** (`css`):
```css
.card {
position: relative;
margin: 32rpx;
border-radius: 12rpx;
overflow: hidden;
box-sizing: border-box;
border: 3rpx solid var(--td-bg-color-container, #fff);
}

.card--active {
border-color: var(--td-brand-color, #0052d9);
}

.card--active::after {
content: '';
display: block;
position: absolute;
left: 0;
top: 0;
width: 0;
border-width: 28px 28px 28px 0;
border-style: solid;
border-color: var(--td-brand-color, #0052d9) transparent transparent transparent;
}

.card__icon {
color: var(--td-bg-color-container, #fff);
position: absolute;
left: 1.5px;
top: 1.5px;
z-index: 1;
}

/* 横向布局 */
.horizontal-box {
display: flex;
align-items: center;
justify-content: space-between;
flex-wrap: wrap;
margin: 32rpx;
}

.horizontal-box .card {
flex: 0 0 calc(33.33% - 12rpx);
margin: 0 0 24rpx 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-radio-group": "tdesign-miniprogram/radio-group/radio-group",
"t-radio": "tdesign-miniprogram/radio/radio",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

## API

### RadioProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| allow-uncheck | Boolean | false | 是否允许取消选中 | N |
| block | Boolean | true | 是否为块级元素 | N |
| checked | Boolean | false | 是否选中 | N |
| default-checked | Boolean | undefined | 是否选中。非受控属性 | N |
| content | String | - | 单选内容 | N |
| content-disabled | Boolean | false | 是否禁用组件内容（content）触发选中 | N |
| disabled | Boolean | undefined | 是否为禁用态 | N |
| icon | String / Array | 'circle' | 自定义选中图标和非选中图标。使用 Array 时表示：`[选中态图标，非选中态图标]`。使用 String 时，值为 circle 表示填充型图标、值为 line 表示描边型图标、值为 dot 表示圆点图标，值为 slot 时使用插槽。TS 类型：`'circle' \| 'line' \| 'dot' \| Array<string>` | N |
| label | String | - | 主文案 | N |
| max-content-row | Number | 5 | 内容最大行数限制 | N |
| max-label-row | Number | 3 | 主文案最大行数限制 | N |
| name | String | - | HTML 元素原生属性 | N |
| placement | String | - | 复选框和内容相对位置。优先级高于 RadioGroup.placement。Radio 单独存在时，默认值为 left。如果父组件存在 RadioGroup，默认值便由 RadioGroup.placement 决定。可选项：left/right | N |
| readonly | Boolean | undefined | `1.8.6`。只读状态 | N |
| value | String / Number / Boolean | false | 单选按钮的值。TS 类型：`T``type RadioValue = string \| number \| boolean`。详细类型定义 | N |

### RadioEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(checked: boolean)` | 值变化时触发 |

### RadioSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，主文案 |
| content | 自定义`content`显示内容 |
| icon | 自定义选中图标和非选中图标 |
| label | 自定义`label`显示内容 |

### RadioExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-border | 边框样式类 |
| t-class-content | 内容样式类 |
| t-class-icon | 图标样式类 |
| t-class-label | 标签样式类 |

### RadioGroupProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| allow-uncheck | Boolean | false | 是否允许取消选中 | N |
| borderless | Boolean | false | 是否开启无边框模式 | N |
| disabled | Boolean | undefined | 是否禁用全部子单选框 | N |
| icon | String / Array | 'circle' | 自定义选中图标和非选中图标。示例：[选中态图标，非选中态图标]。使用 String 时，值为 circle 表示填充型图标、值为 line 表示描边型图标、值为 dot 表示圆点图标；仅在使用 options 时生效。TS 类型：`'circle' \| 'line' \| 'dot' \| Array<string>` | N |
| keys | Object | - | 用来定义 value / label / disabled 在`options`中对应的字段别名。TS 类型：`KeysType`。通用类型定义 | N |
| name | String | - | HTML 元素原生属性 | N |
| options | Array | - | 单选组件按钮形式。RadioOption 数据类型为 string 或 number 时，表示 label 和 value 值相同。TS 类型：`Array<RadioOption>``type RadioOption = string \| number \| RadioOptionObj``interface RadioOptionObj { label?: string; value?: string \| number; readonly?: boolean; disabled?: boolean; allowUncheck?: boolean; }`。详细类型定义 | N |
| placement | String | left | 复选框和内容相对位置。优先级低于 Radio.placement。可选项：left/right | N |
| readonly | Boolean | undefined | `1.8.6`。只读状态 | N |
| value | String / Number / Boolean | - | 选中的值。TS 类型：`T``type RadioValue = string \| number \| boolean`。详细类型定义 | N |
| default-value | String / Number / Boolean | undefined | 选中的值。非受控属性。TS 类型：`T``type RadioValue = string \| number \| boolean`。详细类型定义 | N |

### RadioGroupEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: RadioValue)` | 选中值发生变化时触发 |

### RadioGroupSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，单选框组内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-radio-bg-color | @bg-color-container | - |
| --td-radio-border-color | @component-stroke | - |
| --td-radio-content-checked-color | @text-color-secondary | - |
| --td-radio-content-color | @text-color-secondary | - |
| --td-radio-content-disabled-color | @text-color-disabled | - |
| --td-radio-content-font | @font-body-medium | - |
| --td-radio-font | @font-body-large | - |
| --td-radio-icon-checked-color | @brand-color | - |
| --td-radio-icon-color | @component-border | - |
| --td-radio-icon-disabled-bg-color | @bg-color-component-disabled | - |
| --td-radio-icon-disabled-color | @brand-color-disabled | - |
| --td-radio-icon-size | 48rpx | - |
| --td-radio-label-checked-color | @text-color-primary | - |
| --td-radio-label-color | @text-color-primary | - |
| --td-radio-label-disabled-color | @text-color-disabled | - |
| --td-radio-label-line-height | 48rpx | - |
| --td-radio-vertical-padding | 32rpx | - |

---

# [rate]

# Rate 评分

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
{
"usingComponents": {
"t-rate": "tdesign-miniprogram/rate/rate"
}
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/V8zRWMm68h5w)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

实心评分

**WXML** (`html`):
```html
<view class="demo-rate">
<view class="demo-rate__title">实心评分</view>

<t-rate value="{{value}}" bind:change="onChange" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 3,
},
methods: {
onChange(e) {
const { value } = e.detail;
this.setData({
value,
});
},
},
});

```

**CSS** (`css`):
```css
.demo-rate {
background-color: var(--bg-color-demo);
color: var(--td-text-color-primary);
height: 96rpx;
display: flex;
align-items: center;
justify-content: space-between;
padding: 0 32rpx;
margin-top: 32rpx;
margin-bottom: 32rpx;
}

.demo-rate__title {
width: 200rpx;
}

.demo-rate__transparent {
background-color: transparent;
padding-left: 32rpx;
border: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-rate": "tdesign-miniprogram/rate/rate"
}
}

```

自定义评分

**WXML** (`html`):
```html
<view class="demo-rate">
<view class="demo-rate__title">自定义评分</view>
<t-rate value="{{value}}" icon="thumb-up" bind:change="onChange" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 3,
},
methods: {
onChange(e) {
const { value } = e.detail;
this.setData({
value,
});
},
},
});

```

**CSS** (`css`):
```css
.demo-rate {
background-color: var(--bg-color-demo);
color: var(--td-text-color-primary);
height: 96rpx;
display: flex;
align-items: center;
justify-content: space-between;
padding: 0 32rpx;
margin-top: 32rpx;
margin-bottom: 32rpx;
}

.demo-rate__title {
width: 200rpx;
}

.demo-rate__transparent {
background-color: transparent;
padding-left: 32rpx;
border: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-rate": "tdesign-miniprogram/rate/rate"
}
}

```

自定义评分数量

**WXML** (`html`):
```html
<view class="demo-rate">
<view class="demo-rate__title">自定义评分数量</view>
<!-- 自定义评分数量，设置属性：count-->
<t-rate value="{{value}}" count="{{3}}" bind:change="onChange" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 2,
},

methods: {
onChange(e) {
const { value } = e.detail;
this.setData({
value,
});
},
},
});

```

**CSS** (`css`):
```css
.demo-rate {
background-color: var(--bg-color-demo);
color: var(--td-text-color-primary);
height: 96rpx;
display: flex;
align-items: center;
justify-content: space-between;
padding: 0 32rpx;
margin-top: 32rpx;
margin-bottom: 32rpx;
}

.demo-rate__transparent {
background-color: transparent;
padding-left: 32rpx;
border: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-rate": "tdesign-miniprogram/rate/rate"
}
}

```

带描述评分

**WXML** (`html`):
```html
<view class="demo-rate">
<view class="demo-rate__title">带描述评分</view>
<!-- 自定义带描述评分，设置属性：texts -->
<t-rate value="{{value[0]}}" data-index="{{0}}" bind:change="onChange" showText="{{true}}" texts="{{texts}}" />
</view>
<view class="demo-rate">
<view class="demo-rate__title">带描述评分</view>
<!-- 带描述评分，设置属性：showText-->
<t-rate value="{{value[1]}}" data-index="{{1}}" bind:change="onChange" showText="{{true}}" />
</view>

<view class="demo-rate">
<view class="demo-rate__title">带描述评分</view>
<t-rate value="{{value[2]}}" data-index="{{2}}" bind:change="onChange" showText="{{true}}" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: [3, 3, 0],
texts: ['1分', '2分', '3分', '4分', '5分'],
},

methods: {
onChange(e) {
const { index } = e.currentTarget.dataset;
const { value } = e.detail;
this.setData({
[`value[${index}]`]: value,
});
},
},
});

```

**CSS** (`css`):
```css
.demo-rate {
background-color: var(--bg-color-demo);
color: var(--td-text-color-primary);
height: 96rpx;
display: flex;
align-items: center;
justify-content: space-between;
padding: 0 32rpx;
margin-top: 32rpx;
margin-bottom: 32rpx;
}

.demo-rate__title {
width: 200rpx;
}

.demo-rate__transparent {
background-color: transparent;
padding-left: 32rpx;
border: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-rate": "tdesign-miniprogram/rate/rate"
}
}

```

### 组件状态

**WXML** (`html`):
```html
<view class="demo-desc">只可选全星时</view>

<view class="demo-rate">
<view class="demo-rate__title">点击或滑动</view>
<t-rate value="{{value}}" bind:change="onChange" />
</view>

<view class="demo-desc">只可选半星时</view>

<view class="demo-rate">
<view class="demo-rate__title">点击或滑动</view>
<t-rate default-value="{{3}}" allowHalf />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 3.5,
},
methods: {
onChange(e) {
const { value } = e.detail;
this.setData({
value,
});
},
},
});

```

**CSS** (`css`):
```css
.demo-rate {
background-color: var(--bg-color-demo);
color: var(--td-text-color-primary);
height: 96rpx;
display: flex;
align-items: center;
justify-content: space-between;
padding: 0 32rpx;
margin-top: 32rpx;
margin-bottom: 32rpx;
}

.demo-rate__transparent {
background-color: transparent;
padding-left: 32rpx;
border: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-rate": "tdesign-miniprogram/rate/rate"
}
}

```

### 组件样式

评分大小

**WXML** (`html`):
```html
<view class="demo-rate">
<view class="demo-rate__title">大尺寸 24</view>
<t-rate value="{{value[0]}}" data-index="{{0}}" bind:change="onChange" />
</view>
<view class="demo-rate">
<view class="demo-rate__title">小尺寸 20</view>
<t-rate value="{{value[1]}}" data-index="{{1}}" bind:change="onChange" size="{{20}}" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: [3, 3],
},
methods: {
onChange(e) {
const { index } = e.currentTarget.dataset;
const { value } = e.detail;
this.setData({
[`value[${index}]`]: value,
});
},
},
});

```

**CSS** (`css`):
```css
.demo-rate {
background-color: var(--bg-color-demo);
color: var(--td-text-color-primary);
height: 96rpx;
display: flex;
align-items: center;
justify-content: space-between;
padding: 0 32rpx;
margin-top: 32rpx;
margin-bottom: 32rpx;
}

.demo-rate__title {
width: 200rpx;
}

.demo-rate__transparent {
background-color: transparent;
padding-left: 32rpx;
border: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-rate": "tdesign-miniprogram/rate/rate"
}
}

```

设置评分颜色

**WXML** (`html`):
```html
<view class="demo-rate custom-color">
<view class="demo-rate__title">填充评分</view>
<t-rate default-value="{{3}}" allowHalf />
</view>
<view class="demo-rate">
<view class="demo-rate__title">线描评分</view>
<t-rate default-value="{{3}}" icon="{{ ['star-filled', 'star'] }}" color="#00a870" />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.custom-color {
--td-rate-selected-color: #f96102;
--td-rate-unselected-color: #bbbbbb;
}

.demo-rate {
background-color: var(--bg-color-demo);
color: var(--td-text-color-primary);
height: 96rpx;
display: flex;
align-items: center;
justify-content: space-between;
padding: 0 32rpx;
margin-top: 32rpx;
margin-bottom: 32rpx;
}

.demo-rate__title {
width: 200rpx;
}

.demo-rate__transparent {
background-color: transparent;
padding-left: 32rpx;
border: 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-rate": "tdesign-miniprogram/rate/rate"
}
}

```

### 特殊样式

竖向带描述评分

**WXML** (`html`):
```html
<view class="demo-rate">
<view class="rate-wrapper">
<t-rate value="{{value}}" size="60rpx" bind:change="onChange" texts="{{texts}}" />
</view>
<view class="desc desc--{{value > 3 ? 'active' : ''}}">{{texts[value - 1]}}</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 4,
texts: ['非常糟糕', '有些糟糕', '可以尝试', '可以前往', '推荐前往'],
},
methods: {
onChange(e) {
const { value } = e.detail;
this.setData({
value,
});
},
},
});

```

**CSS** (`css`):
```css
.demo-rate {
background-color: var(--bg-color-demo);
color: var(--td-text-color-primary);
padding: 32rpx;
margin-top: 32rpx;
margin-bottom: 32rpx;
}

.rate-wrapper {
display: flex;
justify-content: center;
}

.desc {
text-align: center;
margin-top: 24rpx;
}

.desc--active {
color: #ed7b2f;
font-weight: 600;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-rate": "tdesign-miniprogram/rate/rate"
}
}

```

自定义图片前缀

{{iconPrefix}}

## API

### RateProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| allow-half | Boolean | false | 是否允许半选 | N |
| color | String / Array | '#ED7B2F' | `0.30.0`。评分图标的颜色，样式中默认为 #ED7B2F。一个值表示设置选中高亮的五角星颜色，示例：[选中颜色]。数组则表示分别设置 选中高亮的五角星颜色 和 未选中暗灰的五角星颜色，[选中颜色，未选中颜色]。示例：['#ED7B2F', '#E3E6EB']。TS 类型：`string \| Array<string>` | N |
| count | Number | 5 | 评分的数量 | N |
| disabled | Boolean | undefined | 是否禁用评分 | N |
| gap | String / Number | 8 | 评分图标的间距 | N |
| icon | String / Array | - | `0.30.0`。自定义评分图标，[选中图标，未选中图标]。TS 类型：`string \| string[]` | N |
| icon-prefix | String | undefined | 定义图标前缀 | N |
| placement | String | top | 选择评分弹框的位置，值为空字符表示不显示评分弹框。可选项：top / bottom / '' | N |
| show-text | Boolean | false | 是否显示对应的辅助文字 | N |
| size | String | 24px | 评分图标的大小 | N |
| texts | Array | [] | 评分等级对应的辅助文字。组件内置默认值为：['极差', '失望', '一般', '满意', '惊喜']。自定义值示例：['1分', '2分', '3分', '4分', '5分']。TS 类型：`Array<string>` | N |
| value | Number | 0 | 选择评分的值 | N |
| default-value | Number | undefined | 选择评分的值。非受控属性 | N |
| variant | String | outline | 已废弃。形状类型，有描边类型和填充类型两种。可选项：outline/filled | N |

### RateEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: number)` | 评分数改变时触发 |

### RateExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-icon | 图标样式类 |
| t-class-text | 文本样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-rate-icon-scale | 1.33 | - |
| --td-rate-selected-color | @warning-color | - |
| --td-rate-text-active-color | @text-color-primary | - |
| --td-rate-text-active-font-weight | 600 | - |
| --td-rate-text-color | @text-color-disabled | - |
| --td-rate-text-font-size | @font-size-m | - |
| --td-rate-unselected-color | @component-border | - |