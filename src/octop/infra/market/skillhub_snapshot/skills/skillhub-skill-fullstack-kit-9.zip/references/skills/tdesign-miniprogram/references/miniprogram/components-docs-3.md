# 合并文档 第3部分（共3部分，含 19 个组件）


---

# [result]

# Result 结果

## 示例

该组件于 0.16.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-result": "tdesign-miniprogram/result/result"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/gJzz5Mmu8m5g)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

基础结果

**WXML** (`html`):
```html
<view wx:for="{{resultList}}" wx:for-item="item" wx:key="index">
<view class="demo-section__content">
<t-result theme="{{item.theme}}" title="{{item.title}}" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
resultList: [
{
title: '成功状态',
theme: 'success',
},
{
title: '失败状态',
theme: 'error',
},
{
title: '警示状态',
theme: 'warning',
},
{
title: '默认状态',
theme: 'default',
},
],
},
});

```

**CSS** (`css`):
```css
.demo-section__content {
margin-bottom: 96rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-result": "tdesign-miniprogram/result/result"
}
}

```

带描述的结果

**WXML** (`html`):
```html
<view wx:for="{{resultList}}" wx:for-item="item" wx:key="index">
<view class="demo-section__content">
<t-result theme="{{item.theme}}" title="{{item.title}}" description="{{item.description}}" />
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
resultList: [
{
title: '成功状态',
theme: 'success',
description: '描述文字',
},
{
title: '失败状态',
theme: 'error',
description: '描述文字',
},
{
title: '警示状态',
theme: 'warning',
description: '描述文字',
},
{
title: '默认状态',
theme: 'default',
description: '描述文字',
},
],
},
});

```

**CSS** (`css`):
```css
.demo-section__content {
margin-bottom: 96rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-result": "tdesign-miniprogram/result/result"
}
}

```

自定义结果

**WXML** (`html`):
```html
<t-result t-class-image="external-class-image" image="https://tdesign.gtimg.com/mobile/demos/result1.png">
<view slot="title"> 自定义结果 </view>
<view slot="description"> 描述文字 </view>
</t-result>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.external-class-image {
width: 100px;
height: 80px;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-result": "tdesign-miniprogram/result/result"
}
}

```

## 常见问题

本地图片无法正确引用? 👇
建议使用绝对路径，而不是相对路径。绝对路径以 app.json 所在位置为基准。

## API

### ResultProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| description | String | - | 描述文字 | N |
| icon | String / Boolean / Object | true | 图标名称。值为字符串表示图标名称，值为`false`表示不显示图标，值为`Object`类型，表示透传至`icon`，不传表示使用主题图标 | N |
| image | String | - | 图片地址 | N |
| theme | String | default | 内置主题。可选项：default/success/warning/error | N |
| title | String | '' | 标题 | N |

### ResultSlots

| 名称 | 描述 |
| --- | --- |
| description | 自定义`description`显示内容 |
| image | 自定义`image`显示内容 |
| title | 自定义`title`显示内容 |

### ResultExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-description | 描述样式类 |
| t-class-image | 图片样式类 |
| t-class-title | 标题样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-result-description-color | @text-color-secondary | - |
| --td-result-description-font | @font-body-medium | - |
| --td-result-description-margin-top | @spacer | - |
| --td-result-icon-default-color | @brand-color | - |
| --td-result-icon-error-color | @error-color | - |
| --td-result-icon-success-color | @success-color | - |
| --td-result-icon-warning-color | @warning-color | - |
| --td-result-title-color | @text-color-primary | - |
| --td-result-title-font | @font-title-extraLarge | - |
| --td-result-title-margin-top | @spacer-1 | - |

---

# [search]

# Search 搜索框

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-search": "tdesign-miniprogram/search/search"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/2XDtrNmK8o5d)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 01组件类型

基础搜索框

**WXML** (`html`):
```html
<view class="example-search">
<t-search placeholder="搜索预设文案" />
</view>

<view class="example-search">
<t-search placeholder="输入tdesign，有预览结果" resultList="{{resultList}}" bind:change="onChangeValue" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: '',
resultList: [],
},
methods: {
onChangeValue(e) {
const { value } = e.detail;
const list = [
'tdesign-vue',
'tdesign-react',
'tdesign-miniprogram',
'tdesign-angular',
'tdesign-mobile-vue',
'tdesign-mobile-react',
];
this.setData({
resultList: value ? list.filter((v) => v.includes(value)) : [],
});
},
},
});

```

**CSS** (`css`):
```css
.example-search {
background-color: var(--bg-color-demo);
padding: 16rpx 32rpx;
}

.example-search:not(:last-child) {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-search": "tdesign-miniprogram/search/search"
}
}

```

获取焦点后显示取消按钮

**WXML** (`html`):
```html
<view class="example-search">
<t-search
value="{{value}}"
center
placeholder="搜索预设文案"
action="{{actionText}}"
bind:blur="blurHandle"
bind:focus="focusHandle"
bind:action-click="actionHandle"
bind:change="changeHandle"
/>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: '',
actionText: '',
},

methods: {
changeHandle(e) {
const { value } = e.detail;
this.setData({
value,
});
},

focusHandle() {
this.setData({
actionText: '取消',
});
},

blurHandle() {
this.setData({
actionText: '',
});
},

actionHandle() {
this.setData({
value: '',
actionText: '',
});
},
},
});

```

**CSS** (`css`):
```css
.example-search {
background-color: var(--bg-color-demo);
padding: 16rpx 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-search": "tdesign-miniprogram/search/search"
}
}

```

### 02组件样式

搜索框形状

**WXML** (`html`):
```html
<view class="example-search">
<t-search placeholder="搜索预设文案" />
</view>

<view class="example-search">
<t-search placeholder="搜索预设文案" shape="round" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: '',
},
methods: {
onChange(e) {
console.log(e.detail.value);
},
},
});

```

**CSS** (`css`):
```css
.example-search {
background-color: var(--bg-color-demo);
padding: 16rpx 32rpx;
}

.example-search:not(:last-child) {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"styleIsolation": "apply-shared",
"usingComponents": {
"t-search": "tdesign-miniprogram/search/search"
}
}

```

### 03组件状态

默认状态其他对齐方式

**WXML** (`html`):
```html
<view class="example-search">
<t-search model:value="{{value}}" center placeholder="搜索预设文案" bind:change="onChange" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: '',
},

methods: {
onChange({ detail }) {
console.log(`modelValue: ${detail.value}`);
},
},
});

```

**CSS** (`css`):
```css
.example-search {
background-color: var(--bg-color-demo);
padding: 16rpx 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"usingComponents": {
"t-search": "tdesign-miniprogram/search/search"
}
}

```

## API

### SearchProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| action | String | '' | 自定义右侧操作按钮文字 | N |
| adjust-position | Boolean | true | 键盘弹起时，是否自动上推页面 | N |
| always-embed | Boolean | false | 强制 input 处于同层状态，默认 focus 时 input 会切到非同层状态 (仅在 iOS 下生效) | N |
| center | Boolean | false | 是否居中 | N |
| clear-trigger | String | always | 清空图标触发方式，仅在输入框有值时有效。可选项：always / focus | N |
| clearable | Boolean | true | 是否启用清除控件 | N |
| confirm-hold | Boolean | false | 点击键盘右下角按钮时是否保持键盘不收起 | N |
| confirm-type | String | search | 设置键盘右下角按钮的文字，仅在type='text'时生效。<br>具体释义：<br>`send`右下角按钮为“发送”；<br>`search`右下角按钮为“搜索”；<br>`next`右下角按钮为“下一个”；<br>`go`右下角按钮为“前往”；<br>`done`右下角按钮为“完成”。<br>小程序官方文档。可选项：send/search/next/go/done | N |
| cursor | Number | -1 | 必需。指定 focus 时的光标位置 | Y |
| cursor-color | String | #0052d9 | `1.12.1`。光标颜色。iOS 下的格式为十六进制颜色值 #000000，安卓下的只支持 default 和 green，Skyline 下无限制 | N |
| cursor-spacing | Number | 0 | 搜索框聚焦时底部与键盘的距离 | N |
| disabled | Boolean | false | 是否禁用 | N |
| focus | Boolean | false | 是否聚焦 | N |
| hold-keyboard | Boolean | false | focus时，点击页面的时候不收起键盘 | N |
| label | String | '' | 已废弃。左侧文本 | N |
| left-icon | String | 'search' | 左侧图标。如果需要使用`Slot`进行自定义，必须将该值设置为假值 | N |
| maxcharacter | Number | - | 用户最多可以输入的字符个数，一个中文汉字表示两个字符长度。`maxcharacter`和`maxlength`二选一使用 | N |
| maxlength | Number | -1 | 用户最多可以输入的文本长度，一个中文等于一个计数长度。默认为 -1，不限制输入长度。`maxcharacter`和`maxlength`二选一使用 | N |
| placeholder | String | '' | 占位符 | N |
| placeholder-class | String | input-placeholder | 指定 placeholder 的样式类 | N |
| placeholder-style | String | - | 必需。指定 placeholder 的样式 | Y |
| readonly | Boolean | undefined | 只读状态 | N |
| result-list | Array | [] | 预览结果列表。TS 类型：`Array<string>` | N |
| right-icon | String | 'close-circle-filled' | 已废弃。右侧图标 | N |
| selection-end | Number | -1 | 光标结束位置，自动聚集时有效，需与 selection-start 搭配使用 | N |
| selection-start | Number | -1 | 光标起始位置，自动聚集时有效，需与 selection-end 搭配使用 | N |
| shape | String | 'square' | 搜索框形状。可选项：square/round | N |
| type | String | 'text' | 拉起键盘的类型。可选项：text/number/idcard/digit/nickname | N |
| value | String | '' | 值 | N |

### SearchEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| action-click | `({})` | 点击右侧操作按钮文字时触发 |
| blur | `({ value: string })` | 失去焦点时触发 |
| change | `({ value: string })` | 值发生变化时触发 |
| clear | `({ value: string })` | 点击清除时触发 |
| focus | `({ value: string })` | 聚焦时触发 |
| submit | `({ value: string })` | 提交时触发 |

### SearchSlots

| 名称 | 描述 |
| --- | --- |
| action | 自定义`action`显示内容 |
| left-icon | 左侧图标 |
| right-icon | 已废弃。自定义`right-icon`显示内容 |

### SearchExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-action | 操作按钮样式类 |
| t-class-clear | 右侧图标样式类 |
| t-class-input | 输入框样式类 |
| t-class-input-container | 输入框容器样式类 |
| t-class-left | 左侧图标样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-search-action-color | @brand-color | - |
| --td-search-bg-color | @bg-color-secondarycontainer | - |
| --td-search-clear-icon-color | @text-color-placeholder | - |
| --td-search-clear-icon-size | 48rpx | - |
| --td-search-disabled-text-color | @text-color-disabled | - |
| --td-search-font | @font-body-large | - |
| --td-search-height | 80rpx | - |
| --td-search-icon-color | @text-color-placeholder | - |
| --td-search-icon-size | 48rpx | - |
| --td-search-label-color | @text-color-primary | - |
| --td-search-padding | 16rpx 24rpx | - |
| --td-search-placeholder-color | @text-color-placeholder | - |
| --td-search-result-high-light-color | @brand-color | - |
| --td-search-square-radius | @radius-default | - |
| --td-search-text-color | @text-color-primary | - |

---

# [side-bar]

# SideBar 侧边栏

## 示例

该组件于 0.25.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
{
"usingComponents": {
"t-side-bar": "tdesign-miniprogram/side-bar/side-bar",
"t-side-bar-item": "tdesign-miniprogram/side-bar-item/side-bar-item",
}
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/CoD8wNmL8s5h)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 锚点用法

**WXML** (`html`):
```html
<view class="custom-navbar">
<t-navbar class="demo-navbar" title="TDesign" leftArrow placeholder zIndex="{{99}}" />
</view>

<view class="side-bar-wrapper" style="height: calc(100vh - {{navbarHeight}}px)">
<t-side-bar value="{{sideBarIndex}}" bind:change="onSideBarChange">
<t-side-bar-item
wx:for="{{categories}}"
wx:key="label"
value="{{item.value || index}}"
label="{{item.label}}"
badge-props="{{item.badgeProps}}"
/>
</t-side-bar>
<scroll-view class="content" scroll-y scroll-with-animation scroll-top="{{scrollTop}}" bind:scroll="onScroll">
<view wx:for="{{categories}}" wx:key="index" class="section">
<view class="title">{{item.title || item.label}}</view>
<t-grid column="{{3}}" border="{{false}}">
<block wx:for="{{item.items}}" wx:key="index" wx:for-item="cargo">
<t-grid-item
t-class-image="image"
text="{{cargo.label}}"
image="{{cargo.image}}"
image-props="{{ { shape: 'round', lazy: true } }}"
>
</t-grid-item>
</block>
</t-grid>
</view>
</scroll-view>
</view>

```

**JS** (`javascript`):
```javascript
const image = 'https://tdesign.gtimg.com/mobile/demos/example2.png';
const items = new Array(12).fill().map((_, index) => ({
label: index % 3 === 2 ? '最多六个文字' : '标题文字',
image: image,
}));

Page({
offsetTopList: [],
lastScrollTop: 0,
data: {
sideBarIndex: 1,
scrollTop: 0,
categories: [
{
label: '选项一',
title: '标题一',
badgeProps: {},
items,
},
{
label: '选项二',
title: '标题二',
badgeProps: {
dot: true,
},
items: items.slice(0, 9),
},
{
label: '选项三',
title: '标题三',
badgeProps: {},
items: items.slice(0, 9),
},
{
label: '选项四',
title: '标题四',
badgeProps: {
count: 6,
},
items: items.slice(0, 6),
},
{
label: '选项五',
title: '标题五',
badgeProps: {},
items: items.slice(0, 3),
},
],
navbarHeight: 0,
},
onLoad() {
const query = wx.createSelectorQuery().in(this);
const { sideBarIndex } = this.data;
query.selectAll('.title').boundingClientRect();
query.select('.custom-navbar').boundingClientRect();
query.exec((res) => {
const [rects, { height: navbarHeight }] = res;
this.offsetTopList = rects.map((item) => item.top - navbarHeight);
this.setData({ navbarHeight, scrollTop: this.offsetTopList[sideBarIndex] });
});
},

onSideBarChange(e) {
const { value } = e.detail;

this.setData({ sideBarIndex: value, scrollTop: this.offsetTopList[value] });
},
onScroll(e) {
const { scrollTop } = e.detail;
const threshold = 50; // 下一个标题与顶部的距离
const direction = scrollTop > this.lastScrollTop ? 'down' : 'up';
this.lastScrollTop = scrollTop;

// 动态调整阈值：向下滚动时增大阈值，向上时减小
const dynamicThreshold = direction === 'down' ? threshold * 1.5 : threshold * 0.8;

// 使用二分查找优化查找效率
const findNearestIndex = (arr, target) => {
let left = 0;
let right = arr.length - 1;
let result = 0;
while (left <= right) {
const mid = Math.floor((left + right) / 2);
if (arr[mid] <= target + dynamicThreshold) {
result = mid;
left = mid + 1;
} else {
right = mid - 1;
}
}
return result;
};

const newIndex = findNearestIndex(this.offsetTopList, scrollTop);

if (newIndex !== this.data.sideBarIndex) {
this.setData({ sideBarIndex: newIndex });
}
},
});

```

**CSS** (`css`):
```css
page {
background-color: var(--td-bg-color-container);
}

page .round-image {
border-radius: 12rpx;
}

.side-bar-wrapper {
display: flex;
height: 100vh;

--td-grid-item-text-font: var(--td-font-body-small);
}

.side-bar-wrapper .content {
flex: 1;
}

.side-bar-wrapper .section {
padding: 32rpx 0;
}

.side-bar-wrapper .title {
padding-left: 40rpx;
margin-bottom: 8rpx;
font-size: 28rpx;
line-height: 44rpx;
color: var(--td-text-color-primary);
}

.side-bar-wrapper .image {
width: 96rpx;
height: 96rpx;
position: relative;
}

.side-bar-wrapper .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"navigationBarBackgroundColor": "#fff",
"usingComponents": {
"t-side-bar": "tdesign-miniprogram/side-bar/side-bar",
"t-side-bar-item": "tdesign-miniprogram/side-bar-item/side-bar-item",
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

### 切页用法

**WXML** (`html`):
```html
<view class="custom-navbar">
<t-navbar class="demo-navbar" title="TDesign" leftArrow placeholder zIndex="{{99}}" />
</view>

<view class="side-bar-wrapper" style="height: calc(100vh - {{navbarHeight}}px)">
<t-side-bar value="{{sideBarIndex}}" bind:change="onSideBarChange">
<t-side-bar-item
wx:for="{{categories}}"
wx:key="label"
value="{{item.value || index}}"
label="{{item.label}}"
disabled="{{item.disabled}}"
badge-props="{{item.badgeProps}}"
/>
</t-side-bar>
<view class="content" style="transform: translateY(-{{sideBarIndex * 100}}%)">
<scroll-view
wx:for="{{categories}}"
wx:key="label"
class="section"
scroll-y
scroll-top="{{scrollTop}}"
scroll-with-animation
show-scrollbar="{{false}}"
>
<view class="title">{{item.title || item.label}}</view>
<t-cell-group>
<block wx:for="{{item.items}}" wx:key="index" wx:for-item="cargo">
<t-cell t-class-left="cell" title="{{cargo.label}}{{index}}">
<t-image shape="round" src="{{cargo.image}}" slot="image" lazy t-class="image" />
</t-cell>
</block>
</t-cell-group>
</scroll-view>
</view>
</view>

```

**JS** (`javascript`):
```javascript
const image = 'https://tdesign.gtimg.com/mobile/demos/example2.png';
const items = new Array(12).fill({ label: '标题文字', image }, 0, 12);

Page({
offsetTopList: [],
data: {
sideBarIndex: 1,
scrollTop: 0,
categories: [
{
label: '选项一',
title: '标题一',
badgeProps: {},
items,
},
{
label: '选项二',
title: '标题二',
badgeProps: {
dot: true,
},
items: items.slice(0, 10),
},
{
label: '选项三',
title: '标题三',
badgeProps: {},
items: items.slice(0, 6),
},
{
label: '选项四',
title: '标题四',
badgeProps: {
count: 8,
},
items: items.slice(0, 8),
},
{
label: '选项五',
title: '标题五',
badgeProps: {},
disabled: true,
items: items.slice(0, 8),
},
],
navbarHeight: 0,
},
onLoad() {
this.getCustomNavbarHeight();
},

getCustomNavbarHeight() {
const query = wx.createSelectorQuery();
query.select('.custom-navbar').boundingClientRect();
query.exec((res) => {
const { height = 0 } = res[0] || {};
this.setData({ navbarHeight: height });
});
},

onSideBarChange(e) {
const { value } = e.detail;
console.log('---', value);
this.setData({ sideBarIndex: value, scrollTop: 0 });
},
});

```

**CSS** (`css`):
```css
page {
background-color: var(--td-bg-color-container);
}

page .round-image {
border-radius: 12rpx;
}

.side-bar-wrapper {
display: flex;
height: 100vh;
overflow: hidden;
}

.side-bar-wrapper .content {
flex: 1;
transition: transform 0.3s ease;
}

.side-bar-wrapper .section {
padding: 32rpx 0;
box-sizing: border-box;
height: 100%;
}

.side-bar-wrapper .title {
padding-left: 40rpx;
margin-bottom: 8rpx;
font: var(--td-font-body-medium);
color: var(--td-text-color-primary);
}

.side-bar-wrapper .image {
width: 96rpx;
height: 96rpx;

position: relative;
}

.side-bar-wrapper .cell {
margin-right: 32rpx !important;
}

.side-bar-wrapper .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"navigationBarBackgroundColor": "#fff",
"usingComponents": {
"t-side-bar": "tdesign-miniprogram/side-bar/side-bar",
"t-side-bar-item": "tdesign-miniprogram/side-bar-item/side-bar-item",
"t-cell-group": "tdesign-miniprogram/cell-group/cell-group",
"t-cell": "tdesign-miniprogram/cell/cell",
"t-image": "tdesign-miniprogram/image/image"
}
}

```

### 带图标侧边导航

**WXML** (`html`):
```html
<view class="custom-navbar">
<t-navbar class="demo-navbar" title="TDesign" leftArrow placeholder zIndex="{{99}}" />
</view>

<view class="side-bar-wrapper" style="height: calc(100vh - {{navbarHeight}}px)">
<t-side-bar value="{{sideBarIndex}}" bind:change="onSideBarChange">
<t-side-bar-item
wx:for="{{categories}}"
wx:key="label"
value="{{item.value || index}}"
label="{{item.label}}"
icon="{{item.icon}}"
badge-props="{{item.badgeProps}}"
/>
</t-side-bar>
<scroll-view class="content" scroll-y scroll-with-animation scroll-top="{{scrollTop}}" bind:scroll="onScroll">
<view wx:for="{{categories}}" wx:key="label" class="section">
<view class="title">{{item.title || item.label}}</view>
<t-grid column="{{3}}" border="{{false}}">
<block wx:for="{{item.items}}" wx:key="index" wx:for-item="cargo">
<t-grid-item
t-class-image="image"
text="{{cargo.label}}"
image="{{cargo.image}}"
image-props="{{ { shape: 'round', lazy: true } }}"
>
</t-grid-item>
</block>
</t-grid>
</view>
</scroll-view>
</view>

```

**JS** (`javascript`):
```javascript
const image = 'https://tdesign.gtimg.com/mobile/demos/example2.png';
const items = new Array(12).fill().map((_, index) => ({
label: index % 3 === 2 ? '最多六个文字' : '标题文字',
image: image,
}));

Page({
offsetTopList: [],
lastScrollTop: 0,
data: {
sideBarIndex: 1,
scrollTop: 0,
categories: [
{
label: '选项一',
title: '标题一',
icon: 'app',
badgeProps: {},
items,
},
{
label: '选项二',
title: '标题二',
icon: 'app',
badgeProps: {
dot: true,
},
items: items.slice(0, 9),
},
{
label: '选项三',
title: '标题三',
icon: 'app',
badgeProps: {},
items: items.slice(0, 9),
},
{
label: '选项四',
title: '标题四',
icon: 'app',
badgeProps: {
count: 6,
},
items: items.slice(0, 6),
},
{
label: '选项五',
title: '标题五',
icon: 'app',
badgeProps: {},
items: items.slice(0, 3),
},
],
navbarHeight: 0,
},
onLoad() {
const query = wx.createSelectorQuery().in(this);
const { sideBarIndex } = this.data;
query.selectAll('.title').boundingClientRect();
query.select('.custom-navbar').boundingClientRect();
query.exec((res) => {
const [rects, { height: navbarHeight = 0 }] = res;
this.offsetTopList = rects.map((item) => item.top - navbarHeight);
this.setData({ navbarHeight, scrollTop: this.offsetTopList[sideBarIndex] });
});
},
onSideBarChange(e) {
const { value } = e.detail;

this.setData({ sideBarIndex: value, scrollTop: this.offsetTopList[value] });
},
onScroll(e) {
const { scrollTop } = e.detail;
const threshold = 50; // 下一个标题与顶部的距离
const direction = scrollTop > this.lastScrollTop ? 'down' : 'up';
this.lastScrollTop = scrollTop;

// 动态调整阈值：向下滚动时增大阈值，向上时减小
const dynamicThreshold = direction === 'down' ? threshold * 1.5 : threshold * 0.8;

// 使用二分查找优化查找效率
const findNearestIndex = (arr, target) => {
let left = 0;
let right = arr.length - 1;
let result = 0;
while (left <= right) {
const mid = Math.floor((left + right) / 2);
if (arr[mid] <= target + dynamicThreshold) {
result = mid;
left = mid + 1;
} else {
right = mid - 1;
}
}
return result;
};

const newIndex = findNearestIndex(this.offsetTopList, scrollTop);

if (newIndex !== this.data.sideBarIndex) {
this.setData({ sideBarIndex: newIndex });
}
},
});

```

**CSS** (`css`):
```css
page {
background-color: var(--td-bg-color-container);
}

page .round-image {
border-radius: 12rpx;
}

.side-bar-wrapper {
display: flex;
height: 100vh;

--td-grid-item-text-font: var(--td-font-body-small);
}

.side-bar-wrapper .content {
flex: 1;
}

.side-bar-wrapper .section {
padding: 32rpx 0;
}

.side-bar-wrapper .title {
padding-left: 40rpx;
margin-bottom: 8rpx;
font: var(--td-font-body-medium);
color: var(--td-text-color-primary);
}

.side-bar-wrapper .image {
width: 96rpx;
height: 96rpx;
position: relative;
}

.side-bar-wrapper .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

```

**JSON** (`javascript`):
```javascript
{
"navigationBarBackgroundColor": "#fff",
"usingComponents": {
"t-side-bar": "tdesign-miniprogram/side-bar/side-bar",
"t-side-bar-item": "tdesign-miniprogram/side-bar-item/side-bar-item",
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

### 自定义样式

**WXML** (`html`):
```html
<view class="custom-navbar">
<t-navbar class="demo-navbar" title="TDesign" leftArrow placeholder zIndex="{{99}}" />
</view>

<view class="side-bar-wrapper" style="height: calc(100vh - {{navbarHeight}}px)">
<t-side-bar value="{{sideBarIndex}}" bind:change="onSideBarChange">
<t-side-bar-item
wx:for="{{categories}}"
wx:key="label"
value="{{item.value || index}}"
label="{{item.label}}"
badge-props="{{item.badgeProps}}"
/>
</t-side-bar>
<scroll-view class="content" scroll-y scroll-with-animation scroll-top="{{scrollTop}}" bind:scroll="onScroll">
<view wx:for="{{categories}}" wx:key="index" class="section">
<view class="title">{{item.title || item.label}}</view>
<t-grid column="{{3}}" border="{{false}}">
<block wx:for="{{item.items}}" wx:key="index" wx:for-item="cargo">
<t-grid-item
t-class-image="image"
text="{{cargo.label}}"
image="{{cargo.image}}"
image-props="{{ { shape: 'round', lazy: true } }}"
>
</t-grid-item>
</block>
</t-grid>
</view>
</scroll-view>
</view>

```

**JS** (`javascript`):
```javascript
const image = 'https://tdesign.gtimg.com/mobile/demos/example1.png';
const items = new Array(12).fill().map((_, index) => ({
label: index % 3 === 2 ? '最多六个文字' : '标题文字',
image: image,
}));

Page({
offsetTopList: [],
lastScrollTop: 0,
data: {
sideBarIndex: 1,
scrollTop: 0,
categories: [
{
label: '选项一',
title: '标题一',
badgeProps: {},
items,
},
{
label: '选项二',
title: '标题二',
badgeProps: {
dot: true,
},
items: items.slice(0, 9),
},
{
label: '选项三',
title: '标题三',
badgeProps: {},
items: items.slice(0, 9),
},
{
label: '选项四',
title: '标题四',
badgeProps: {
count: 6,
},
items: items.slice(0, 6),
},
{
label: '选项五',
title: '标题五',
badgeProps: {},
items: items.slice(0, 3),
},
],
navbarHeight: 0,
},
onLoad() {
const query = wx.createSelectorQuery().in(this);
const { sideBarIndex } = this.data;
query.selectAll('.title').boundingClientRect();
query.select('.custom-navbar').boundingClientRect();
query.exec((res) => {
const [rects, { height: navbarHeight }] = res;
this.offsetTopList = rects.map((item) => item.top - navbarHeight);
this.setData({ navbarHeight, scrollTop: this.offsetTopList[sideBarIndex] });
});
},
onSideBarChange(e) {
const { value } = e.detail;

this.setData({ sideBarIndex: value, scrollTop: this.offsetTopList[value] });
},
onScroll(e) {
const { scrollTop } = e.detail;
const threshold = 50; // 下一个标题与顶部的距离
const direction = scrollTop > this.lastScrollTop ? 'down' : 'up';
this.lastScrollTop = scrollTop;

// 动态调整阈值：向下滚动时增大阈值，向上时减小
const dynamicThreshold = direction === 'down' ? threshold * 1.5 : threshold * 0.8;

// 使用二分查找优化查找效率
const findNearestIndex = (arr, target) => {
let left = 0;
let right = arr.length - 1;
let result = 0;
while (left <= right) {
const mid = Math.floor((left + right) / 2);
if (arr[mid] <= target + dynamicThreshold) {
result = mid;
left = mid + 1;
} else {
right = mid - 1;
}
}
return result;
};

const newIndex = findNearestIndex(this.offsetTopList, scrollTop);

if (newIndex !== this.data.sideBarIndex) {
this.setData({ sideBarIndex: newIndex });
}
},
});

```

**CSS** (`css`):
```css
page {
background-color: var(--td-bg-color-container);
}

page .round-image {
border-radius: 12rpx;
}

.side-bar-wrapper {
display: flex;
height: 100vh;

--td-grid-item-text-font: var(--td-font-body-small);
}

.side-bar-wrapper .content {
flex: 1;
}

.side-bar-wrapper .section {
padding: 32rpx 0;
}

.side-bar-wrapper .title {
padding-left: 40rpx;
margin-bottom: 8rpx;
font-size: 28rpx;
line-height: 44rpx;
color: var(--td-text-color-primary);
}

.side-bar-wrapper .image {
width: 96rpx;
height: 96rpx;
position: relative;
}

.side-bar-wrapper .image::before {
content: ' ';
position: absolute;
top: 0;
left: 0;
width: 200%;
height: 200%;
border-radius: 24rpx;
border: 2rpx solid var(--td-gray-color-4);
transform-origin: 0 0;
transform: scale(0.5);
}

page .side-bar-wrapper {
--td-side-bar-border-radius: 6px;
--td-side-bar-active-color: green;
}

```

**JSON** (`javascript`):
```javascript
{
"navigationBarBackgroundColor": "#fff",
"usingComponents": {
"t-side-bar": "tdesign-miniprogram/side-bar/side-bar",
"t-side-bar-item": "tdesign-miniprogram/side-bar-item/side-bar-item",
"t-grid": "tdesign-miniprogram/grid/grid",
"t-grid-item": "tdesign-miniprogram/grid-item/grid-item"
}
}

```

## API

### SideBarProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| value | String / Number | - | 选项值 | N |
| default-value | String / Number | undefined | 选项值。非受控属性 | N |

### SideBarEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: number \| string, label: string)` | 选项值发生变化时触发 |
| click | `(value: number \| string, label: string)` | 点击选项时触发 |

### SideBarSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义侧边导航栏内容 |

### SideBarItemProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| badge-props | Object | - | 透传至 Badge 组件。TS 类型：`BadgeProps`，Badge API Documents。详细类型定义 | N |
| disabled | Boolean | false | 是否禁用 | N |
| icon | String / Object | - | 图标，传对象则透传至 Icon | N |
| label | String | - | 展示的标签 | N |
| value | String / Number | - | 当前选项的值 | N |

### SideBarItemSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义侧边导航项内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-side-bar-bg-color | @bg-color-secondarycontainer | - |
| --td-side-bar-height | 100% | - |
| --td-side-bar-width | 206rpx | - |
| --td-side-bar-active-color | @brand-color | - |
| --td-side-bar-border-radius | 18rpx | - |
| --td-side-bar-color | @text-color-primary | - |
| --td-side-bar-disabled-color | @text-color-disabled | - |
| --td-side-bar-font | @font-body-large | - |
| --td-side-bar-icon-size | 40rpx | - |
| --td-side-bar-item-height | auto | - |

---

# [skeleton]

# Skeleton 骨架屏

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-skeleton": "tdesign-miniprogram/skeleton/skeleton"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/ZeDxjNmz8z5T)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 骨架屏类型

基础骨架屏

**WXML** (`html`):
```html
<view wx:for="{{themeList}}" wx:for-item="themeItem" wx:key="index">
<view class="demo-section__desc">{{themeItem.title}}</view>
<view class="demo-section__content">
<t-skeleton theme="{{themeItem.value}}"></t-skeleton>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
themeList: [
{
title: '头像骨架屏',
value: 'avatar',
},
{
title: '图片骨架屏',
value: 'image',
},
{
title: '文本骨架屏',
value: 'text',
},
{
title: '段落骨架屏',
value: 'paragraph',
},
],
},
});

```

**CSS** (`css`):
```css
.demo-section__desc {
font-size: 28rpx;
color: var(--td-text-color-placeholder);
margin-top: 16rpx;
line-height: 44rpx;
}

.demo-section__content {
margin-top: 32rpx;
margin-bottom: 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-skeleton": "tdesign-miniprogram/skeleton/skeleton"
}
}

```

单元格骨架屏

**WXML** (`html`):
```html
<view class="group">
<t-skeleton class="group-avatar" rowCol="{{rowColsAvater}}" loading></t-skeleton>
<t-skeleton class="group-content" rowCol="{{rowColsContent}}" loading></t-skeleton>
</view>

<view class="group">
<t-skeleton class="group-avatar" rowCol="{{rowColsImage}}" loading></t-skeleton>
<t-skeleton class="group-content" rowCol="{{rowColsContent}}" loading></t-skeleton>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
rowColsAvater: [{ size: '96rpx', type: 'circle' }],
rowColsImage: [{ size: '96rpx', type: 'rect' }],
rowColsContent: [{ width: '50%' }, { width: '100%' }],
},
});

```

**CSS** (`css`):
```css
.group {
display: flex;
align-items: center;
margin-top: 32rpx;
}

.group-avatar {
margin-right: 24rpx;
}

.group-content {
width: 566rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-skeleton": "tdesign-miniprogram/skeleton/skeleton"
}
}

```

宫格骨架屏

**WXML** (`html`):
```html
<view class="wrapper">
<t-skeleton rowCol="{{grid}}" loading></t-skeleton>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
grid: [
[
{ width: '96rpx', height: '96rpx', borderRadius: '12rpx' },
{ width: '96rpx', height: '96rpx', borderRadius: '12rpx' },
{ width: '96rpx', height: '96rpx', borderRadius: '12rpx' },
{ width: '96rpx', height: '96rpx', borderRadius: '12rpx' },
{ width: '96rpx', height: '96rpx', borderRadius: '12rpx' },
],
[
{ width: '96rpx', height: '32rpx', borderRadius: '6rpx' },
{ width: '96rpx', height: '32rpx', borderRadius: '6rpx' },
{ width: '96rpx', height: '32rpx', borderRadius: '6rpx' },
{ width: '96rpx', height: '32rpx', borderRadius: '6rpx' },
{ width: '96rpx', height: '32rpx', borderRadius: '6rpx' },
],
],
},
});

```

**CSS** (`css`):
```css
.wrapper {
--td-skeleton-row-spacing: 20rpx;
margin-top: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-skeleton": "tdesign-miniprogram/skeleton/skeleton"
}
}

```

图文组合骨架屏

**WXML** (`html`):
```html
<view class="group">
<t-skeleton rowCol="{{rowCol}}" loading></t-skeleton>
<t-skeleton rowCol="{{rowCol}}" loading></t-skeleton>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
rowCol: [{ size: '327rpx', borderRadius: '24rpx' }, 1, { width: '61%' }],
},
});

```

**CSS** (`css`):
```css
.group {
display: flex;
justify-content: space-between;
margin-top: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-skeleton": "tdesign-miniprogram/skeleton/skeleton"
}
}

```

### 组件动效

**WXML** (`html`):
```html
<view wx:for="{{animationList}}" wx:for-item="animationItem" wx:key="index">
<view class="demo-section__desc">{{animationItem.title}}</view>
<view class="demo-section__content">
<t-skeleton theme="paragraph" animation="{{animationItem.value}}" loading="{{animationItem.loading}}"></t-skeleton>
</view>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
animationList: [
{
title: '渐变加载效果',
value: 'gradient',
loading: true,
},
{
title: '闪烁加载效果',
value: 'flashed',
loading: true,
},
],
},
});

```

**CSS** (`css`):
```css
.demo-section__desc {
font-size: 28rpx;
color: var(--td-text-color-placeholder);
margin-top: 16rpx;
line-height: 44rpx;
}

.demo-section__content {
margin-top: 32rpx;
margin-bottom: 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-skeleton": "tdesign-miniprogram/skeleton/skeleton"
}
}

```

## API

### SkeletonProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| animation | String | none | 动画效果，有「渐变加载动画」和「闪烁加载动画」两种。值为 'none' 则表示没有动画。可选项：gradient/flashed/none | N |
| delay | Number | 0 | 延迟显示加载效果的时间，用于防止请求速度过快引起的加载闪烁，单位：毫秒 | N |
| loading | Boolean | true | 是否为加载状态，如果是则显示骨架图，如果不是则显示加载完成的内容 | N |
| row-col | Array | - | 高级设置，用于自定义行列数量、宽度高度、间距等。【示例一】，`[1, 1, 2]`表示输出三行骨架图，第一行一列，第二行一列，第三行两列。【示例二】，`[1, 1, { width: '100px' }]`表示自定义第三行的宽度为`100px`。【示例三】，`[1, 2, [{ width, height }, { width, height, marginLeft }]]`表示第三行有两列，且自定义宽度、高度、尺寸（圆形或方形使用）、间距、内容等。TS 类型：`SkeletonRowCol``type SkeletonRowCol = Array<Number \| SkeletonRowColObj \| Array<SkeletonRowColObj>>``interface SkeletonRowColObj { width?: string; size?: string;height?: string; marginRight?: string; marginLeft?: string; margin?: string; type?: 'rect' \| 'circle' \| 'text';}`。详细类型定义 | N |
| theme | String | text | 骨架图风格，有基础、头像组合等两大类。可选项：avatar/image/text/paragraph | N |

### SkeletonSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### SkeletonExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-col | 行样式类 |
| t-class-row | 列样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-skeleton-circle-border-radius | @skeleton-circle-border-radius | - |
| --td-skeleton-animation-flashed | rgba(90%, 90%, 90%, 0.3) | - |
| --td-skeleton-animation-gradient | rgba(0, 0, 0, 4%) | - |
| --td-skeleton-bg-color | @bg-color-secondarycontainer | - |
| --td-skeleton-circle-height | 96rpx | - |
| --td-skeleton-rect-border-radius | @radius-default | - |
| --td-skeleton-rect-height | 32rpx | - |
| --td-skeleton-row-spacing | @spacer-2 | - |
| --td-skeleton-text-border-radius | @radius-small | - |
| --td-skeleton-text-height | 32rpx | - |

---

# [slider]

# Slider 滑动选择器

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-slider": "tdesign-miniprogram/slider/slider"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/5gDq5NmO8D5P)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

单游标滑块

**WXML** (`html`):
```html
<view class="wrapper">
<t-slider default-value="{{23}}" step="{{0.1}}" bind:change="handleChange" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
handleChange(e) {
console.log(e.detail.value);
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
background: var(--bg-color-demo);
padding: 0 12rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-slider": "tdesign-miniprogram/slider/slider"
}
}

```

双游标滑块

**WXML** (`html`):
```html
<view class="wrapper">
<t-slider range defaultValue="{{[35, 65]}}" bind:dragstart="onDragstart" bind:dragend="onDragend" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
onDragstart(e) {
console.log('dragstart', e.detail);
},
onDragend(e) {
console.log('dragend', e.detail);
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
background: var(--bg-color-demo);
padding: 0 12rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-slider": "tdesign-miniprogram/slider/slider"
}
}

```

带数值滑动选择器

**WXML** (`html`):
```html
<view class="wrapper">
<t-slider value="{{value}}" label="${value}%" bind:change="handleChange"></t-slider>
</view>

<view class="demo-desc">带数值双游标滑块</view>

<view class="wrapper">
<t-slider show-extreme-value label="{{label}}" default-value="{{ [40, 60] }}" range />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 35,
label(value, position) {
const symbols = { min: '%', max: '%', start: '%', end: '%' };
return `${value}${symbols[position]}`;
},
},

methods: {
handleChange(e) {
this.setData({
value: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css
.demo-desc {
margin-top: 24rpx;
margin-bottom: 16rpx;
}

.wrapper {
background: var(--bg-color-demo);
padding: 40rpx 12rpx 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-slider": "tdesign-miniprogram/slider/slider"
}
}

```

带刻度滑动选择器

**WXML** (`html`):
```html
<view class="wrapper">
<t-slider defaultValue="{{60}}" marks="{{marks}}" step="{{20}}" bind:change="handleChange" />
</view>

<view class="demo-desc">带刻度双游标滑块</view>

<view class="wrapper">
<t-slider range defaultValue="{{ [20, 60] }}" marks="{{marks}}" step="{{20}}" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
marks: {
0: '0',
20: '20',
40: '40',
60: '60',
80: '80',
100: '100',
},
},
methods: {
handleChange(e) {
console.log(e);
},
},
});

```

**CSS** (`css`):
```css
.demo-desc {
margin-top: 24rpx;
margin-bottom: 16rpx;
}

.wrapper {
background: var(--bg-color-demo);
padding: 40rpx 12rpx 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-slider": "tdesign-miniprogram/slider/slider"
}
}

```

### 组件状态

滑块禁用状态

**WXML** (`html`):
```html
<t-slider value="{{35}}" disabled />

<view class="wrapper">
<t-slider show-extreme-value label="${value}%" value="{{ [40, 60] }}" range disabled />
</view>

<view class="wrapper">
<t-slider range value="{{ [20, 60] }}" marks="{{marks}}" step="{{20}}" disabled />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
marks: {
0: '0',
20: '20',
40: '40',
60: '60',
80: '80',
100: '100',
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
margin-top: 32rpx;
background: var(--bg-color-demo);
padding: 40rpx 12rpx 0;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-slider": "tdesign-miniprogram/slider/slider"
}
}

```

#### 特殊样式

胶囊型滑块

**WXML** (`html`):
```html
<view class="wrapper">
<t-slider defaultValue="{{30}}" theme="capsule" />

<t-slider defaultValue="{{ [40, 60] }}" range theme="capsule" />

<t-slider defaultValue="{{ [40, 60] }}" range label="${value}%" theme="capsule" />

<t-slider defaultValue="{{60}}" marks="{{marks}}" step="{{20}}" theme="capsule" />

<t-slider defaultValue="{{ [20, 80] }}" range marks="{{marks}}" step="{{20}}" theme="capsule" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
marks: {
0: '0',
20: '20',
40: '40',
60: '60',
80: '80',
100: '100',
},
},
});

```

**CSS** (`css`):
```css
.label {
display: flex;
align-items: center;
width: 718rpx;
padding-left: 32rpx;
}

.label-class {
flex-grow: 1;
}

.wrapper {
background: var(--bg-color-demo);
padding: 0 12rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-slider": "tdesign-miniprogram/slider/slider"
}
}

```

#### 垂直状态

垂直方向的滑块

**WXML** (`html`):
```html
<view class="demo-desc">单游标垂直滑块</view>
<view class="wrapper">
<t-slider vertical value="{{singlevalue}}" label="${value}%" bind:change="handleSingleChange" />
</view>
<view class="demo-desc">带刻度的双游标垂直滑块</view>
<view class="wrapper">
<t-slider vertical range defaultValue="{{ [20, 60] }}" marks="{{marks}}" step="{{20}}" />
</view>
<view class="demo-desc">胶囊型垂直滑块</view>
<view class="wrapper">
<t-slider vertical value="{{capsuleValue}}" label="${value}%" theme="capsule" bind:change="handleCapsuleChange" />
</view>
<view class="demo-desc">带刻度的胶囊型垂直滑块</view>
<view class="wrapper">
<t-slider vertical defaultValue="{{ [20, 80] }}" range marks="{{marks}}" step="{{20}}" theme="capsule" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
singlevalue: 35,
capsuleValue: 35,
marks: {
0: '0',
20: '20',
40: '40',
60: '60',
80: '80',
100: '100',
},
},

methods: {
handleSingleChange(e) {
this.setData({
singlevalue: e.detail.value,
});
},
handleCapsuleChange(e) {
this.setData({
capsuleValue: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css
.demo-desc {
margin-top: 24rpx;
margin-bottom: 16rpx;
}

.wrapper {
background: var(--bg-color-demo);
padding-top: 40rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-slider": "tdesign-miniprogram/slider/slider"
}
}

```

## FAQ

当 slider 外层使用 `hidden` 包裹，需要在 `hidden = false` 时，重新调用组件的 `init` 方法，才能正常渲染（在t-popup/t-dialog中同理）。如下：

```html
<t-slider id="slider" />
```

```js
const $slider = this.selectComponent('#slider');

$slider.init();
```

## API

### SliderProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| colors | Array | [] | 已废弃。颜色，[已选择, 未选择]。TS 类型：`Array<string>` | N |
| disabled | Boolean | undefined | 是否禁用组件 | N |
| disabled-color | Array | [] | 已废弃。禁用状态滑动条的颜色，[已选, 未选]。TS 类型：`Array<string>` | N |
| label | String / Boolean / Function | false | 滑块当前值文本。<br>值为 true 显示默认文案；值为 false 不显示滑块当前值文本；<br>值为`${value}%`则表示组件会根据占位符渲染文案；<br>值类型为函数时，参数`value`标识滑块值，参数`position=start`表示范围滑块的起始值，参数`position=end`表示范围滑块的终点值。TS 类型：`string \| boolean` | N |
| marks | Object / Array | {} | 刻度标记，示例：`[0, 10, 40, 200]`或者`{ 5:  '5¥', 10: '10%' }`。TS 类型：`Record<number, string> \| Array<number>` | N |
| max | Number | 100 | 滑块范围最大值 | N |
| min | Number | 0 | 滑块范围最小值 | N |
| range | Boolean | false | 双游标滑块 | N |
| show-extreme-value | Boolean | false | 是否边界值 | N |
| step | Number | 1 | 步长 | N |
| theme | String | default | `0.30.0`。滑块风格。可选项：default/capsule | N |
| value | Number / Array | 0 | 滑块值。TS 类型：`SliderValue``type SliderValue = number \| Array<number>`。详细类型定义 | N |
| default-value | Number / Array | undefined | 滑块值。非受控属性。TS 类型：`SliderValue``type SliderValue = number \| Array<number>`。详细类型定义 | N |
| vertical | Boolean | false | 是否是垂直的滑块（渲染垂直滑块时，默认高度为400rpx，可通过修改`--td-slider-bar-height`来自定义高度） | N |

### SliderEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: SliderValue)` | 滑块值变化时触发 |
| dragend | `(value: SliderValue, e: TouchEvent)` | 结束拖动时触发 |
| dragstart | `(e: TouchEvent)` | 开始拖动时触发 |

### SliderExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-bar | 滑道底部样式类 |
| t-class-bar-active | 滑道激活态样式类 |
| t-class-bar-disabled | 滑道禁用态样式类 |
| t-class-cursor | 游标样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-slider-active-color | @brand-color | - |
| --td-slider-bar-height | 8rpx | - |
| --td-slider-bar-width | 8rpx | - |
| --td-slider-capsule-bar-color | @bg-color-component | - |
| --td-slider-capsule-bar-heihgt | 48rpx | - |
| --td-slider-capsule-bar-width | 48rpx | - |
| --td-slider-capsule-line-heihgt | 36rpx | - |
| --td-slider-default-color | @bg-color-component | - |
| --td-slider-disabled-color | @brand-color-disabled | - |
| --td-slider-disabled-text-color | @text-color-disabled | - |
| --td-slider-dot-bg-color | #fff | - |
| --td-slider-dot-color | @component-border | - |
| --td-slider-dot-disabled-bg-color | #fff | - |
| --td-slider-dot-disabled-border-color | #f3f3f3 | - |
| --td-slider-dot-size | 40rpx | - |
| --td-slider-text-color | @text-color-primary | - |

---

# [stepper]

# Stepper 步进器

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-stepper": "tdesign-miniprogram/stepper/stepper"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/1oDoyNmm8G5k)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

基础步进器

**WXML** (`html`):
```html
<view class="stepper-example">
<t-stepper defaultValue="3" theme="filled" />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.stepper-example {
padding: 32rpx;
background-color: var(--bg-color-demo);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-stepper": "tdesign-miniprogram/stepper/stepper"
}
}

```

### 组件状态

最大最小状态

**WXML** (`html`):
```html
<view class="stepper-example">
<t-stepper defaultValue="0" theme="filled" />
<t-stepper defaultValue="99" theme="filled" min="5" max="999" />
<t-stepper defaultValue="999" theme="filled" max="999" />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.stepper-example {
padding: 32rpx;
display: flex;
background-color: var(--bg-color-demo);
justify-content: space-between;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-stepper": "tdesign-miniprogram/stepper/stepper"
}
}

```

禁用状态

**WXML** (`html`):
```html
<view class="stepper-example">
<t-stepper disabled theme="filled" />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.stepper-example {
padding: 32rpx;
background-color: var(--bg-color-demo);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-stepper": "tdesign-miniprogram/stepper/stepper"
}
}

```

### 组件样式

步进器样式

**WXML** (`html`):
```html
<view class="stepper-example">
<t-stepper defaultValue="3" theme="filled" />
<t-stepper defaultValue="3" theme="outline" />
<t-stepper defaultValue="3" />
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.stepper-example {
padding: 32rpx;
display: flex;
background-color: var(--bg-color-demo);
justify-content: space-between;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-stepper": "tdesign-miniprogram/stepper/stepper"
}
}

```

步进器尺寸

**WXML** (`html`):
```html
<view class="stepper-example">
<t-stepper value="{{value}}" size="large" theme="filled" bind:change="handleChange" />
<t-stepper defaultValue="3" max="99" theme="filled" />
<t-stepper defaultValue="3" size="small" theme="filled" />
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 3,
},

methods: {
handleChange(e) {
const { value } = e.detail;

console.log(value);
this.setData({
value,
});
},
},
});

```

**CSS** (`css`):
```css
.stepper-example {
padding: 32rpx;
display: flex;
background-color: var(--bg-color-demo);
justify-content: space-between;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-stepper": "tdesign-miniprogram/stepper/stepper"
}
}

```

## API

### StepperProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| disable-input | Boolean | false | 禁用输入框 | N |
| disabled | Boolean | undefined | 禁用全部操作 | N |
| input-width | Number | - | 输入框宽度，默认单位`px` | N |
| integer | Boolean | true | 是否整型 | N |
| max | Number | 100 | 最大值 | N |
| min | Number | 0 | 最小值 | N |
| size | String | medium | 组件尺寸。可选项：small/medium/large。TS 类型：`SizeEnum`。通用类型定义 | N |
| step | Number | 1 | 步长 | N |
| theme | String | normal | 组件风格。可选项：normal/filled/outline | N |
| value | String / Number | 0 | 值 | N |
| default-value | String / Number | undefined | 值。非受控属性 | N |

### StepperEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| blur | `({ type: string \| number })` | 输入框失去焦点时触发 |
| change | `({ value: string \| number })` | 数值发生变更时触发 |
| focus | `({ value: string \| number }))` | 输入框聚焦时触发 |
| overlimit | `({type: 'minus' \| 'plus'})` | 数值超出限制时触发 |

### StepperExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-input | 输入框样式类 |
| t-class-minus | 左侧递减号样式类 |
| t-class-plus | 右侧递增号样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-stepper-input-disabled-bg | @bg-color-component-disabled | - |
| --td-stepper-input-disabled-color | @text-color-disabled | - |
| --td-stepper-border-color | @component-border | - |
| --td-stepper-border-radius | @radius-small | - |
| --td-stepper-input-color | @text-color-primary | - |

---

# [steps]

# Steps 步骤条

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-steps": "tdesign-miniprogram/steps/steps",
"t-step-item": "tdesign-miniprogram/step-item/step-item",
}
```

## 代码演示

步骤条，方向可以横向和纵向，可以自定义步骤条显示内容以及是否可写

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/hDDtINmI8M5F)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

#### 水平步骤条

支持三种类型：序号、图标、简略

**WXML** (`html`):
```html
<view class="demo-desc">水平带序号步骤条</view>
<wxs module="_">
module.exports.getText = function(value, curr) { if (value > curr) return '已完成'; if (value == curr)
return'当前步骤'; return '未完成'; }
</wxs>

<view class="block">
<t-steps current="{{first}}" bind:change="onFirstChange">
<t-step-item wx:for="{{4}}" wx:key="index" title="{{_.getText(first, index)}}" content="辅助信息" />
</t-steps>
</view>

<view class="demo-desc">水平带图标步骤条</view>

<view class="block">
<t-steps current="{{second}}" bind:change="onSecondChange">
<t-step-item wx:for="{{4}}" wx:key="index" title="{{_.getText(second, index)}}" content="辅助信息" icon="cart" />
</t-steps>
</view>

<view class="demo-desc">水平简略步骤条</view>

<view class="block">
<t-steps theme="dot" current="{{third}}" bind:change="onThirdChange">
<t-step-item wx:for="{{4}}" wx:key="index" title="{{_.getText(third, index)}}" content="辅助信息" />
</t-steps>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
first: 1,
second: 1,
third: 1,
},

methods: {
onFirstChange(e) {
this.setData({ first: e.detail.current });
},
onSecondChange(e) {
this.setData({ second: e.detail.current });
},
onThirdChange(e) {
this.setData({ third: e.detail.current });
},
},
});

```

**CSS** (`css`):
```css
.block {
background-color: var(--bg-color-demo);
padding: 32rpx 0;
margin: 32rpx 0 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-steps": "tdesign-miniprogram/steps/steps",
"t-step-item": "tdesign-miniprogram/step-item/step-item"
}
}

```

#### 垂直步骤条

支持三种类型：序号、图标、简略

**WXML** (`html`):
```html
<wxs module="_">
module.exports.getText = function(value, curr) { if (value > curr) return '已完成步骤'; if (value == curr)
return'当前步骤'; return '未完成步骤'; }
</wxs>

<view class="demo-desc">垂直带序号步骤条</view>

<view class="block">
<t-steps layout="vertical" current="{{first}}" bind:change="onFirstChange">
<t-step-item wx:for="{{4}}" wx:key="index" title="{{_.getText(first, index)}}" content="可自定义此处内容" />
</t-steps>
</view>

<view class="demo-desc">垂直带图标步骤条</view>

<view class="block">
<t-steps layout="vertical" current="{{second}}" bind:change="onSecondChange">
<t-step-item
wx:for="{{4}}"
wx:key="index"
title="{{_.getText(second, index)}}"
content="可自定义此处内容"
icon="cart"
/>
</t-steps>
</view>

<view class="demo-desc">垂直简略步骤条</view>

<view class="block">
<t-steps layout="vertical" theme="dot" current="{{third}}" bind:change="onThirdChange">
<t-step-item wx:for="{{4}}" wx:key="index" title="{{_.getText(third, index)}}" content="可自定义此处内容" />
</t-steps>
</view>

<view class="demo-desc">垂直带自定义内容步骤条</view>

<view class="block">
<t-steps layout="vertical" current="{{third}}" bind:change="onThirdChange">
<t-step-item wx:for="{{3}}" wx:key="index" title="{{_.getText(third, index)}}" content="可自定义此处内容">
<view wx:if="{{index == 1}}" slot="extra">
<image src="https://tdesign.gtimg.com/mobile/demos/steps1.png" alt="图标" style="width: 100%" mode="widthFix" />
</view>
</t-step-item>
</t-steps>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
first: 1,
second: 1,
third: 1,
},

methods: {
onFirstChange(e) {
this.setData({ first: e.detail.current });
},
onSecondChange(e) {
this.setData({ second: e.detail.current });
},
onThirdChange(e) {
this.setData({ third: e.detail.current });
},
},
});

```

**CSS** (`css`):
```css
.block {
background-color: var(--bg-color-demo);
padding: 32rpx;
margin: 32rpx 0 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-steps": "tdesign-miniprogram/steps/steps",
"t-step-item": "tdesign-miniprogram/step-item/step-item"
}
}

```

### 组件状态

#### 选项卡状态

共支持 4 种状态：未完成（default）、已完成（finish）、进行中（process）、错误（error）

**WXML** (`html`):
```html
<wxs module="_">
module.exports.getText = function(value, curr) { if (value > curr) return '已完成'; if (value == curr)
return'错误步骤'; return '未完成'; }
</wxs>

<view class="block">
<t-steps current="{{first}}" bind:change="onFirstChange" current-status="error">
<t-step-item wx:for="{{4}}" wx:key="index" title="{{_.getText(first, index)}}" content="辅助信息" />
</t-steps>
</view>

<view class="block">
<t-steps current="{{second}}" bind:change="onSecondChange" current-status="error">
<t-step-item wx:for="{{4}}" wx:key="index" title="{{_.getText(second, index)}}" content="辅助信息" icon="cart" />
</t-steps>
</view>

<view class="block">
<t-steps theme="dot" current="{{third}}" bind:change="onThirdChange" current-status="error">
<t-step-item wx:for="{{4}}" wx:key="index" title="{{_.getText(third, index)}}" content="辅助信息" />
</t-steps>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
first: 1,
second: 1,
third: 1,
},

methods: {
onFirstChange(e) {
this.setData({ first: e.detail.current });
},
onSecondChange(e) {
this.setData({ second: e.detail.current });
},
onThirdChange(e) {
this.setData({ third: e.detail.current });
},
},
});

```

**CSS** (`css`):
```css
.block {
background-color: var(--bg-color-demo);
padding: 32rpx 0;
margin: 32rpx 0 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-steps": "tdesign-miniprogram/steps/steps",
"t-step-item": "tdesign-miniprogram/step-item/step-item"
}
}

```

### 特殊类型

通过已有特性，改造出两种常见类型：

- 垂直自定义（在 Cascader 中使用）
- 纯展示步骤条

可以参考以下代码实现

**WXML** (`html`):
```html
<wxs module="_">
module.exports.getText = function(value, curr) { if (value > curr) return '已完成步骤'; if (value == curr)
return'当前步骤'; return '未完成步骤'; }
</wxs>

<view class="demo-desc">垂直自定义步骤条</view>

<view class="block">
<t-steps layout="vertical" theme="dot" current="{{count - 1}}" bind:change="onCascader">
<t-step-item wx:for="{{count}}" wx:key="index" title="{{_.getText(count - 1, index)}}">
<t-icon name="chevron-right" size="44rpx" color="rgba(0, 0, 0, .4)" slot="title-right" />
</t-step-item>
</t-steps>

<t-button style="margin-top: 32rpx; display: block" block bind:tap="toNext">下一步</t-button>
</view>

<view class="demo-desc">纯展示步骤条</view>

<view class="block">
<t-steps layout="vertical" readonly theme="dot" current="{{5}}">
<t-step-item wx:for="{{4}}" wx:key="index" title="步骤展示" content="可自定义此处内容" />
</t-steps>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
count: 4,
},
methods: {
toNext() {
this.setData({ count: this.data.count + 1 });
},
onCascader(e) {
const { current } = e.detail;

this.setData({
count: current + 1,
});
},
},
});

```

**CSS** (`css`):
```css
.block {
background-color: var(--bg-color-demo);
padding: 32rpx;
margin: 32rpx 0 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-steps": "tdesign-miniprogram/steps/steps",
"t-step-item": "tdesign-miniprogram/step-item/step-item",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

## API

### StepsProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| current | String / Number | - | 当前步骤，即整个步骤条进度。默认根据步骤下标判断步骤的完成状态，当前步骤为进行中，当前步骤之前的步骤为已完成，当前步骤之后的步骤为未开始。如果每个步骤没有设置 value，current 值为步骤长度则表示所有步骤已完成。如果每个步骤设置了自定义 value，则 current = 'FINISH' 表示所有状态完成 | N |
| default-current | String / Number | undefined | 当前步骤，即整个步骤条进度。默认根据步骤下标判断步骤的完成状态，当前步骤为进行中，当前步骤之前的步骤为已完成，当前步骤之后的步骤为未开始。如果每个步骤没有设置 value，current 值为步骤长度则表示所有步骤已完成。如果每个步骤设置了自定义 value，则 current = 'FINISH' 表示所有状态完成。非受控属性 | N |
| current-status | String | process | 用于控制 current 指向的步骤条的状态。可选项：default/process/finish/error | N |
| layout | String | horizontal | 步骤条方向，有两种：横向和纵向。可选项：horizontal/vertical | N |
| readonly | Boolean | undefined | 只读状态 | N |
| sequence | String | positive | 步骤条顺序。可选项：positive/reverse | N |
| theme | String | default | 步骤条风格。可选项：default/dot | N |

### StepsEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `({current: string \| number, previous: string \| number})` | 当前步骤发生变化时触发 |

### StepsSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义步骤条内容 |

### StepsExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |

### StepItemProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| content | String | '' | 步骤描述 | N |
| extra | String | - | 步骤条自定义内容 | N |
| icon | String | - | 图标。传入 slot 代表使用插槽，其他字符串代表使用内置图标 | N |
| status | String | default | 当前步骤的状态：默认状态（未开始）、进行中状态、完成状态、错误状态。可选项：default/process/finish/error。TS 类型：`StepStatus``type StepStatus = 'default' \| 'process' \| 'finish' \| 'error'`。详细类型定义 | N |
| sub-step-items | Array | [] | 已废弃。子步骤条，仅支持 layout  = 'vertical' 时。TS 类型：`SubStepItem[]``interface SubStepItem { status: StepStatus, title: string }`。详细类型定义 | N |
| title | String | '' | 标题 | N |

### StepItemSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义步骤内容 |
| content | 自定义`content`显示内容 |
| extra | 自定义`extra`显示内容 |
| icon | 自定义`icon`显示内容 |
| title | 自定义`title`显示内容 |

### StepItemExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |
| t-class-description | 描述样式类 |
| t-class-extra | 额外样式类 |
| t-class-title | 标题样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-step-item-circle-size | 44rpx | - |
| --td-step-item-circle-text-font | @font-body-medium | - |
| --td-step-item-default-circle-bg | @bg-color-secondarycontainer | - |
| --td-step-item-default-circle-color | @text-color-placeholder | - |
| --td-step-item-default-dot-border-color | @component-border | - |
| --td-step-item-default-icon-color | @text-color-placeholder | - |
| --td-step-item-default-title-color | @text-color-placeholder | - |
| --td-step-item-description-color | @text-color-placeholder | - |
| --td-step-item-dot-size | 16rpx | - |
| --td-step-item-error-circle-bg | @error-color-1 | - |
| --td-step-item-error-circle-color | @error-color | - |
| --td-step-item-error-dot-border-color | @error-color | - |
| --td-step-item-error-icon-color | @error-color | - |
| --td-step-item-error-title-color | @error-color | - |
| --td-step-item-finish-circle-bg | @brand-color-light | - |
| --td-step-item-finish-circle-color | @brand-color | - |
| --td-step-item-finish-dot-border-color | @brand-color | - |
| --td-step-item-finish-icon-color | @brand-color | - |
| --td-step-item-finish-line-color | @brand-color | - |
| --td-step-item-finish-title-color | @text-color-primary | - |
| --td-step-item-line-color | @component-border | - |
| --td-step-item-process-circle-bg | @brand-color | - |
| --td-step-item-process-circle-color | @text-color-anti | - |
| --td-step-item-process-dot-border-color | @brand-color | - |
| --td-step-item-process-icon-color | @brand-color | - |
| --td-step-item-process-title-color | @brand-color | - |

---

# [sticky]

# Sticky 吸顶容器

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-sticky": "tdesign-miniprogram/sticky/sticky"
}
```

## 代码演示

将内容包裹在 `Sticky` 组件内

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/YLDNkNmz8Q5S)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础吸顶

**WXML** (`html`):
```html
<t-sticky offset-top="{{navbarHeight}}">
<t-button size="large" theme="primary" t-class="external-class">基础吸顶</t-button>
</t-sticky>

```

**JS** (`javascript`):
```javascript
Component({
properties: {
navbarHeight: {
type: Number,
value: 0,
},
},
});

```

**CSS** (`css`):
```css
.external-class {
width: 208rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-sticky": "tdesign-miniprogram/sticky/sticky",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

### 吸顶距离

**WXML** (`html`):
```html
<t-sticky offset-top="{{ 40 + navbarHeight }}">
<t-button size="large" theme="danger" t-class="external-class">吸顶距离</t-button>
</t-sticky>

```

**JS** (`javascript`):
```javascript
Component({
properties: {
navbarHeight: {
type: Number,
value: 0,
},
},
});

```

**CSS** (`css`):
```css
.external-class {
width: 208rpx;
margin-left: 272rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-sticky": "tdesign-miniprogram/sticky/sticky",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

### 指定容器

**WXML** (`html`):
```html
<view class="wrapper">
<t-sticky container="{{ container }}" offset-top="{{navbarHeight}}">
<t-button size="large" t-class="external-class green-button" hover-class="hover-class ">指定容器</t-button>
</t-sticky>
</view>

```

**JS** (`javascript`):
```javascript
Component({
properties: {
navbarHeight: {
type: Number,
value: 0,
},
},

data: {
container: null,
},

lifetimes: {
ready: function () {
this.setData({
container: () => this.createSelectorQuery().select('.wrapper'),
});
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
width: 100%;
height: 150px;
background-color: var(--bg-color-demo-secondary);
}

.external-class {
width: 208rpx;
margin-left: 512rpx;
}

.green-button {
z-index: 0 !important;
background-color: #008858 !important;
color: #fff !important;
}

.hover-class::after {
z-index: -1;
background-color: #006c45;
border-color: #006c45;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "shared",
"usingComponents": {
"t-sticky": "tdesign-miniprogram/sticky/sticky",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

## API

### StickyProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| container | Function | - | 函数返回容器对应的 NodesRef 节点，将对应节点指定为组件的外部容器，滚动时组件会始终保持在容器范围内，当组件即将超出容器底部时，会返回原位置 | N |
| disabled | Boolean | false | 是否禁用组件 | N |
| offset-top | String / Number | 0 | 吸顶时与顶部的距离，单位`px` | N |
| z-index | Number | 99 | 吸顶时的 z-index | N |

### StickyEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| scroll | `(detail: { scrollTop: number, isFixed: boolean })` | 滚动时触发，scrollTop: 距离顶部位置，isFixed: 是否吸顶 |

### StickySlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |

### StickyExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-content | 内容样式类 |

---

# [swipe-cell]

# SwipeCell 滑动操作

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-swipe-cell": "tdesign-miniprogram/swipe-cell/swipe-cell"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/hfDOjNmY8Z5S)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

左滑单操作

**WXML** (`html`):
```html
<t-swipe-cell>
<t-cell title="左滑单操作" note="辅助信息" bordered="{{false}}" />
<view slot="right" class="btn delete-btn" bind:tap="onDelete">删除</view>
</t-swipe-cell>

<t-swipe-cell>
<t-cell
bordered="{{false}}"
title="左滑大列表"
description="一段很长很长的内容文字"
note="辅助信息"
image="https://tdesign.gtimg.com/mobile/demos/avatar1.png"
/>
<view slot="right" class="btn delete-btn" bind:tap="onDelete">删除</view>
</t-swipe-cell>

<t-swipe-cell right="{{right}}" bind:click="onActionClick">
<t-cell title="左滑双操作" note="辅助信息" bordered="{{false}}" />
</t-swipe-cell>

<t-swipe-cell>
<t-cell title="左滑多操作" note="辅助信息" bordered="{{false}}" />
<view slot="right" class="btn-wrapper">
<view class="btn favor-btn" bind:tap="onFavor">收藏</view>
<view class="btn edit-btn" bind:tap="onEdit">编辑</view>
<view class="btn delete-btn" bind:tap="onDelete">删除</view>
</view>
</t-swipe-cell>

```

**JS** (`javascript`):
```javascript
Component({
data: {
right: [
{
text: '编辑',
className: 'btn edit-btn',
},
{
text: '删除',
className: 'btn delete-btn',
},
],
},
methods: {
onActionClick({ detail }) {
wx.showToast({ title: `你点击了${detail.text}`, icon: 'none' });
},

onDelete() {
wx.showToast({ title: '你点击了删除', icon: 'none' });
},
onEdit() {
wx.showToast({ title: '你点击了编辑', icon: 'none' });
},
onFavor() {
wx.showToast({ title: '你点击了收藏', icon: 'none' });
},
onChoice() {
wx.showToast({ title: '你点击了选择', icon: 'none' });
},
},
});

```

**CSS** (`css`):
```css
.btn-wrapper {
height: 100%;
}

.btn {
display: inline-flex;
justify-content: center;
align-items: center;
width: 120rpx;
height: 100%;
color: white;
}

.delete-btn {
background-color: #e34d59;
}

.edit-btn {
background-color: #ed7b2f;
}

.favor-btn {
background-color: var(--td-brand-color, #0052d9);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swipe-cell": "tdesign-miniprogram/swipe-cell/swipe-cell",
"t-cell": "tdesign-miniprogram/cell/cell"
}
}

```

右滑单操作

**WXML** (`html`):
```html
<t-swipe-cell>
<t-cell title="右滑单操作" note="辅助信息" bordered="{{false}}" />
<view slot="left" class="btn favor-btn" bind:tap="onChoice">选择</view>
</t-swipe-cell>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
onChoice() {
wx.showToast({ title: '你点击了选择', icon: 'none' });
},
},
});

```

**CSS** (`css`):
```css
.btn {
display: inline-flex;
justify-content: center;
align-items: center;
width: 120rpx;
height: 100%;
color: white;
}

.favor-btn {
background-color: var(--td-brand-color, #0052d9);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swipe-cell": "tdesign-miniprogram/swipe-cell/swipe-cell",
"t-cell": "tdesign-miniprogram/cell/cell"
}
}

```

左右滑操作

**WXML** (`html`):
```html
<t-swipe-cell right="{{right}}" left="{{left}}" bind:click="onActionClick">
<t-cell title="左右滑操作" note="辅助信息" bordered="{{false}}" />
</t-swipe-cell>

```

**JS** (`javascript`):
```javascript
Component({
data: {
right: [
{
text: '删除',
className: 'btn delete-btn',
},
],
left: [
{
text: '选择',
className: 'btn favor-btn',
},
],
},

methods: {
onActionClick({ detail }) {
wx.showToast({ title: `你点击了${detail.text}`, icon: 'none' });
},
},
});

```

**CSS** (`css`):
```css
.btn {
display: inline-flex;
justify-content: center;
align-items: center;
width: 120rpx;
height: 100%;
color: white;
}

.favor-btn {
background-color: var(--td-brand-color, #0052d9);
}

.delete-btn {
background-color: #e34d59;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swipe-cell": "tdesign-miniprogram/swipe-cell/swipe-cell",
"t-cell": "tdesign-miniprogram/cell/cell"
}
}

```

带图标的滑动操作

**WXML** (`html`):
```html
<t-swipe-cell right="{{right}}" bind:click="onActionClick">
<t-cell title="左滑-带图标文本双操作" note="辅助信息" bordered="{{false}}" />
</t-swipe-cell>

<t-swipe-cell right="{{rightIcon}}">
<t-cell title="左滑-仅带图标双操作" note="辅助信息" bordered="{{false}}" />
</t-swipe-cell>

<t-swipe-cell>
<t-cell
bordered="{{false}}"
title="左滑大列表-仅带图标双操作"
description="一段很长很长的内容文字"
note="辅助信息"
image="https://tdesign.gtimg.com/mobile/demos/avatar1.png"
/>
<view slot="right" class="btn-wrapper">
<view class="btn edit-btn column" bind:tap="onEdit">
<t-icon class="padding-bottom" name="edit" size="32rpx"></t-icon>
编辑
</view>
<view class="btn delete-btn column" bind:tap="onDelete">
<t-icon class="padding-bottom" name="delete" size="32rpx"></t-icon>
删除
</view>
</view>
</t-swipe-cell>

```

**JS** (`javascript`):
```javascript
Component({
data: {
right: [
{
text: '编辑',
icon: {
name: 'edit',
size: 16,
},
className: 'btn edit-btn',
},
{
text: '删除',
icon: {
name: 'delete',
size: 16,
},
className: 'btn delete-btn',
},
],
rightIcon: [
{
icon: 'edit',
className: 'btn edit-btn',
},
{
icon: 'delete',
className: 'btn delete-btn',
},
],
},
methods: {
onActionClick({ detail }) {
wx.showToast({ title: `你点击了${detail.text}`, icon: 'none' });
},

onDelete() {
wx.showToast({ title: '你点击了删除', icon: 'none' });
},
onEdit() {
wx.showToast({ title: '你点击了编辑', icon: 'none' });
},
onFavor() {
wx.showToast({ title: '你点击了收藏', icon: 'none' });
},
onChoice() {
wx.showToast({ title: '你点击了选择', icon: 'none' });
},
},
});

```

**CSS** (`css`):
```css
.btn-wrapper {
height: 100%;
}

.btn {
display: inline-flex;
justify-content: center;
align-items: center;
width: 120rpx;
height: 100%;
color: white;
}

.delete-btn {
background-color: #e34d59;
}

.edit-btn {
background-color: #ed7b2f;
}

.favor-btn {
background-color: var(--td-brand-color, #0052d9);
}

.column {
flex-direction: column;
}

.padding-bottom {
padding-bottom: 8rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swipe-cell": "tdesign-miniprogram/swipe-cell/swipe-cell",
"t-cell": "tdesign-miniprogram/cell/cell",
"t-icon": "tdesign-miniprogram/icon/icon"
}
}

```

## FAQ

### SwipeCell组件在真机上无法滑动？

移除全局配置项: "componentFramework": "glass-easel"，详情见： [issue 2524](https://github.com/Tencent/tdesign-miniprogram/issues/2524)。如需使用 `skyline render`，建议页面级粒度开启。

## API

### SwipeCellProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| disabled | Boolean | - | 是否禁用滑动 | N |
| left | Array | - | 左侧滑动操作项。所有行为同`right`。TS 类型：`Array<SwipeActionItem>` | N |
| opened | Boolean / Array | false | 操作项是否呈现为打开态，值为数组时表示分别控制左右滑动的展开和收起状态。TS 类型：`boolean \| Array<boolean>` | N |
| right | Array | - | 右侧滑动操作项。有两种定义方式，一种是使用数组，二种是使用插槽。`right.text`表示操作文本，`right.className`表示操作项类名，`right.style`表示操作项样式，`right.onClick`表示点击操作项后执行的回调函数。示例：`[{ text: '删除', icon: 'delete', style: 'background-color: red', onClick: () => {} }]`。TS 类型：`Array<SwipeActionItem>``interface SwipeActionItem {text?: string; icon?: string \| object, className?: string; style?: string; onClick?: () => void; [key: string]: any }`。详细类型定义 | N |

### SwipeCellEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| click | `(action: SwipeActionItem, source: SwipeSource)` | 操作项点击时触发（插槽写法组件不触发，业务侧自定义内容和事件）。详细类型定义。<br>`type SwipeSource = 'left' \| 'right'`<br> |
| dragend | - | 滑动结束事件 |
| dragstart | - | 滑动开始事件 |

### SwipeCellSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |
| left | 左侧滑动操作项 |
| right | 右侧滑动操作项 |

---

# [swiper]

# Swiper 轮播图

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-swiper": "tdesign-miniprogram/swiper/swiper",
"t-swiper-nav": "tdesign-miniprogram/swiper-nav/swiper-nav",
}
```

### 组件说明

从 `0.32.0` 版本开始，依赖原生 `swiper` 组件实现，移除了 `swiper-item` 组件，新增了 `list` 属性；

## 代码演示

多种轮播样式，通过 `navigation` 设置导航样式，没有值则不显示，也可以自定义 `nav` 组件

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/QwElpNmY825g)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

#### 点状（dots）轮播图

**WXML** (`html`):
```html
<t-swiper
current="{{current}}"
autoplay="{{autoplay}}"
duration="{{duration}}"
interval="{{interval}}"
navigation="{{ { type: 'dots' } }}"
list="{{swiperList}}"
bind:click="onTap"
bind:change="onChange"
bind:image-load="onImageLoad"
>
</t-swiper>

```

**JS** (`javascript`):
```javascript
const imageCdn = 'https://tdesign.gtimg.com/mobile/demos';
const swiperList = [
`${imageCdn}/swiper1.png`,
`${imageCdn}/swiper2.png`,
`${imageCdn}/swiper1.png`,
`${imageCdn}/swiper2.png`,
`${imageCdn}/swiper1.png`,
];

Component({
data: {
current: 0,
autoplay: false,
duration: 500,
interval: 5000,
swiperList,
},

methods: {
onTap(e) {
const { index } = e.detail;

console.log(index);
},
onChange(e) {
const { current, source } = e.detail;

console.log(current, source);
},
onImageLoad(e) {
console.log(e.detail.index);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swiper": "tdesign-miniprogram/swiper/swiper"
}
}

```

#### 点条状（dots-bar）轮播图

**WXML** (`html`):
```html
<t-swiper
current="{{current}}"
autoplay="{{autoplay}}"
duration="{{duration}}"
interval="{{interval}}"
list="{{swiperList}}"
navigation="{{ { type: 'dots-bar' } }}"
/>

```

**JS** (`javascript`):
```javascript
const imageCdn = 'https://tdesign.gtimg.com/mobile/demos';
const swiperList = [
{
value: `${imageCdn}/swiper1.png`,
ariaLabel: '图片1',
},
{
value: `${imageCdn}/swiper2.png`,
ariaLabel: '图片2',
},
{
value: `${imageCdn}/swiper1.png`,
ariaLabel: '图片1',
},
{
value: `${imageCdn}/swiper2.png`,
ariaLabel: '图片2',
},
];

Component({
data: {
current: 1,
autoplay: true,
duration: 500,
interval: 5000,
swiperList,
},
});

```

**CSS** (`css`):
```css
.img {
width: 100%;
height: 100%;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swiper": "tdesign-miniprogram/swiper/swiper"
}
}

```

#### 分式（fraction）导航器轮播图

**WXML** (`html`):
```html
<t-swiper
current="{{current}}"
autoplay="{{autoplay}}"
duration="{{duration}}"
interval="{{interval}}"
navigation="{{navigation}}"
paginationPosition="{{paginationPosition}}"
list="{{swiperList}}"
>
</t-swiper>

```

**JS** (`javascript`):
```javascript
const imageCdn = 'https://tdesign.gtimg.com/mobile/demos';
const swiperList = [
`${imageCdn}/swiper1.png`,
`${imageCdn}/swiper2.png`,
`${imageCdn}/swiper1.png`,
`${imageCdn}/swiper2.png`,
`${imageCdn}/swiper1.png`,
];

Component({
data: {
current: 2,
autoplay: true,
duration: 500,
interval: 5000,
paginationPosition: 'bottom-right',
swiperList,
navigation: { type: 'fraction' },
},
});

```

**CSS** (`css`):
```css
.img {
width: 100%;
height: 100%;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swiper": "tdesign-miniprogram/swiper/swiper"
}
}

```

#### 切换按钮（controls）轮播图

**WXML** (`html`):
```html
<t-swiper
current="{{current}}"
autoplay="{{autoplay}}"
duration="{{duration}}"
interval="{{interval}}"
navigation="{{navigation}}"
list="{{swiperList}}"
loop="{{false}}"
>
</t-swiper>

```

**JS** (`javascript`):
```javascript
const imageCdn = 'https://tdesign.gtimg.com/mobile/demos';
const swiperList = [
{
value: `${imageCdn}/swiper1.png`,
ariaLabel: '图片1',
},
{
value: `${imageCdn}/swiper2.png`,
ariaLabel: '图片2',
},
{
value: `${imageCdn}/swiper1.png`,
ariaLabel: '图片1',
},
{
value: `${imageCdn}/swiper2.png`,
ariaLabel: '图片2',
},
];

Component({
data: {
current: 3,
autoplay: true,
duration: 500,
interval: 5000,
swiperList,
navigation: { type: '', showControls: true },
},
});

```

**CSS** (`css`):
```css
.img {
width: 100%;
height: 100%;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swiper": "tdesign-miniprogram/swiper/swiper"
}
}

```

#### 卡片式（cards）轮播图

**WXML** (`html`):
```html
<view class="card-theme">
<t-swiper
current="{{current}}"
autoplay="{{autoplay}}"
duration="{{duration}}"
interval="{{interval}}"
bindchange="onChange"
navigation="{{ { type: 'dots' } }}"
list="{{swiperList}}"
image-props="{{ { shape: 'round' } }}"
previousMargin="34px"
nextMargin="34px"
t-class-nav="card-theme-nav"
/>

<view class="box" style="height: 42px" />

<t-swiper
class="scale-card-theme"
current="{{current}}"
autoplay="{{autoplay}}"
duration="{{duration}}"
interval="{{interval}}"
bindchange="onChange"
navigation="{{ { type: 'dots' } }}"
list="{{swiperList}}"
image-props="{{ { shape: 'round' } }}"
previousMargin="34px"
nextMargin="34px"
t-class-nav="card-theme-nav"
t-class-prev-image="scale-candidate"
t-class-next-image="scale-candidate"
/>
</view>

```

**JS** (`javascript`):
```javascript
const imageCdn = 'https://tdesign.gtimg.com/mobile/demos';
const swiperList = [
`${imageCdn}/swiper1.png`,
`${imageCdn}/swiper2.png`,
`${imageCdn}/swiper1.png`,
`${imageCdn}/swiper2.png`,
`${imageCdn}/swiper1.png`,
];

Component({
data: {
current: 0,
autoplay: false,
duration: 500,
interval: 5000,
swiperList,
},

methods: {
onChange(e) {
const {
detail: { current, source },
} = e;
console.log(current, source);
},
},
});

```

**CSS** (`css`):
```css
.card-theme {
--td-swiper-radius: 0;
--td-swiper-item-padding: 0 12rpx;
--td-swiper-nav-dot-color: var(--td-bg-color-component, #e7e7e7);
--td-swiper-nav-dot-active-color: var(--td-brand-color, #0052d9);

padding-bottom: 18px;
}

.card-theme .card-theme-nav {
bottom: -18px;
}

.scale-candidate {
height: 126px !important;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swiper": "tdesign-miniprogram/swiper/swiper"
}
}

```

### 组件样式

#### 垂直模式

**WXML** (`html`):
```html
<view class="swiper-box">
<t-swiper
current="{{1}}"
autoplay="{{autoplay}}"
duration="{{duration}}"
interval="{{interval}}"
navigation="{{navigation}}"
direction="vertical"
paginationPosition="{{paginationPosition}}"
list="{{swiperList}}"
>
</t-swiper>
</view>

<view class="swiper-box swiper-box-option">
<view class="cell">
<view class="label">自动播放</view>
<view class="option">
<t-switch t-class="swiper-switch" bindchange="onAutoplayChange" value="{{autoplay}}"></t-switch>
<view class="option-desc">{{autoplay?'开':'关'}}</view>
</view>
</view>
<view class="cell">
<view class="label">自动播放间隔时间(单位毫秒)</view>
<view class="option">
<t-slider
t-class="swiper-slider"
t-class-bar="external-class-bar"
value="{{interval}}"
min="{{1000}}"
max="{{5000}}"
label="{{true}}"
step="{{500}}"
bindchange="onIntervalChange"
></t-slider>
</view>
</view>
<view class="cell">
<view class="label">动画持续时间(单位毫秒)</view>
<view class="option">
<t-slider
t-class="swiper-slider"
t-class-bar="external-class-bar"
value="{{duration}}"
min="{{200}}"
max="{{2000}}"
label="{{true}}"
step="{{100}}"
bindchange="onDurationChange"
></t-slider>
</view>
</view>
</view>

```

**JS** (`javascript`):
```javascript
const imageCdn = 'https://tdesign.gtimg.com/mobile/demos';
const swiperList = [
{
value: `${imageCdn}/swiper1.png`,
ariaLabel: '图片1',
},
{
value: `${imageCdn}/swiper2.png`,
ariaLabel: '图片2',
},
{
value: `${imageCdn}/swiper1.png`,
ariaLabel: '图片1',
},
{
value: `${imageCdn}/swiper2.png`,
ariaLabel: '图片2',
},
];
Component({
data: {
current: 1,
autoplay: true,
duration: 500,
interval: 5000,
swiperList,
navigation: { type: 'dots-bar' },
paginationPosition: 'right',
},

methods: {
onChange(e) {
const {
detail: { current, source },
} = e;
console.log(current, source);
},
onAutoplayChange(e) {
this.setData({
autoplay: e.detail.value,
});
},
onIntervalChange(e) {
this.setData({
interval: e.detail.value,
});
},
onDurationChange(e) {
this.setData({
duration: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css
.swiper-box {
margin: 0 32rpx 32rpx;
border-radius: 16rpx;
overflow: hidden;
transform: translateY(0);
}

.swiper-box .img {
width: 100%;
height: 100%;
}

.swiper-switch {
margin: 22rpx 0;
}

.swiper-switch .t-switch__label {
display: none;
}

.cell {
padding: 10rpx 0;
font-size: 28rpx;
color: #999;
}
.cell.row {
display: flex;
flex-direction: row;
}

.cell .label {
color: #999;
margin-right: 20rpx;
}

.cell .option-desc {
width: 68rpx;
}

.cell .swiper-slider {
margin: 32rpx 0;
}

.swiper-box-vertical .item {
line-height: 400rpx;
}

.swiper-box-option {
overflow: visible;
border-radius: 0;
}

.external-class-bar {
margin: 0 !important;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-swiper": "tdesign-miniprogram/swiper/swiper",
"t-switch": "tdesign-miniprogram/switch/switch",
"t-slider": "tdesign-miniprogram/slider/slider"
}
}

```

## API

### SwiperProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| autoplay | Boolean | true | 是否自动播放 | N |
| current | Number | 0 | 当前轮播在哪一项（下标） | N |
| direction | String | horizontal | 轮播滑动方向，包括横向滑动和纵向滑动两个方向。可选项：horizontal/vertical | N |
| display-multiple-items | Number | 1 | `0.32.0`。同时显示的滑块数量 | N |
| duration | Number | 300 | 滑动动画时长 | N |
| easing-function | String | default | `0.32.0`。指定 swiper 切换缓动动画类型。可选项：default/linear/easeInCubic/easeOutCubic/easeInOutCubic | N |
| height | String / Number | 192 | 轮播的高度；默认单位`px` | N |
| image-props | Object | - | `0.34.0`。透传至 Image 组件 | N |
| interval | Number | 5000 | 轮播间隔时间 | N |
| list | Array | - | `0.32.0`。图片列表。TS 类型：`string[] \| SwiperList[]``interface SwiperList { value: string, ariaLabel: string }`。详细类型定义 | N |
| loop | Boolean | true | 是否循环播放 | N |
| navigation | Boolean / Object | true | 导航器全部配置，true 的话使用默认配置。TS 类型：`SwiperNavProps \| boolean`，SwiperNav API Documents。详细类型定义 | N |
| next-margin | String / Number | 0 | `0.32.0`。后边距，可用于露出后一项的一小部分。默认单位`px` | N |
| pagination-position | String | bottom | 页码信息展示位置。可选项：top-left/top/top-right/bottom-left/bottom/bottom-right | N |
| previous-margin | String / Number | 0 | `0.32.0`。前边距，可用于露出前一项的一小部分。默认单位`px` | N |
| snap-to-edge | Boolean | false | `0.32.0`。当 swiper-item 的个数大于等于 2，关闭 circular 并且开启 previous-margin 或 next-margin 的时候，可以指定这个边距是否应用到第一个、最后一个元素 | N |

### SwiperEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| animationfinish | `(current: number, source: SwiperChangeSource)` | `1.11.0`。轮播切换时触发 |
| change | `(current: number, source: SwiperChangeSource)` | 轮播切换时触发。详细类型定义。<br>`type SwiperChangeSource = 'autoplay' \| 'touch' \| 'nav'`<br> |
| click | `(index: number)` | `0.34.0`。点击轮播项时触发 |
| image-load | `(index: number)` | `1.1.4`。图片加载时触发 |

### SwiperSlots

| 名称 | 描述 |
| --- | --- |
| navigation | 导航器全部配置 |

### SwiperExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-image | 当前图片样式类 |
| t-class-nav | 导航样式类 |
| t-class-next-image | 下一图片样式类 |
| t-class-prev-image | 上一图片样式类 |

### SwiperNavProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| current | Number | 0 | `0.34.0`。当前轮播在哪一项（下标） | N |
| direction | String | horizontal | `0.34.0`。轮播滑动方向，包括横向滑动和纵向滑动两个方向。可选项：horizontal/vertical | N |
| min-show-num | Number | 2 | 小于这个数字不会显示导航器 | N |
| pagination-position | String | bottom | `0.34.0`。页码信息展示位置。可选项：top-left/top/top-right/bottom-left/bottom/bottom-right | N |
| show-controls | Boolean | false | `0.32.0`。是否显示两侧的控制按钮 | N |
| total | Number | 0 | `0.34.0`。总共的项数 | N |
| type | String | dots | 导航器类型，点状(dots)、点条状(dots-bar)、分式(fraction)等。TS 类型：`SwiperNavigationType``type SwiperNavigationType = 'dots' \| 'dots-bar' \| 'fraction'`。详细类型定义 | N |

### SwiperNavExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-swiper-item-padding | 0 | - |
| --td-swiper-radius | @radius-large | - |
| --td-swiper-nav-btn-bg-color | @font-gray-3 | - |
| --td-swiper-nav-btn-color | @text-color-anti | - |
| --td-swiper-nav-btn-size | 48rpx | - |
| --td-swiper-nav-dot-active-color | @text-color-anti | - |
| --td-swiper-nav-dot-color | @font-white-2 | - |
| --td-swiper-nav-dot-size | 12rpx | - |
| --td-swiper-nav-dots-bar-active-width | 40rpx | - |
| --td-swiper-nav-fraction-bg-color | @font-gray-3 | - |
| --td-swiper-nav-fraction-color | @text-color-anti | - |
| --td-swiper-nav-fraction-font | @font-body-small | - |
| --td-swiper-nav-fraction-height | 48rpx | - |

---

# [switch]

# Switch 开关

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-switch": "tdesign-miniprogram/switch/switch"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/IsE5yNmz865p)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础开关

**WXML** (`html`):
```html
<t-cell title="基础开关" bordered="{{false}}">
<t-switch defaultValue="{{true}}" slot="note" />
</t-cell>

```

**JS** (`javascript`):
```javascript
Component({
data: {
defaultVal: true,
},
methods: {
handleChange(e) {
this.setData({
defaultVal: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-switch": "tdesign-miniprogram/switch/switch"
}
}

```

### 带描述开关

**WXML** (`html`):
```html
<t-cell title="带文字开关">
<t-switch bindchange="handleChange" value="{{defaultVal}}" label="{{['开', '关']}}" slot="note" />
</t-cell>

<t-cell title="带图标开关" bordered="{{false}}">
<t-switch defaultValue="{{true}}" icon="{{['check', 'close']}}" slot="note" />
</t-cell>

```

**JS** (`javascript`):
```javascript
Component({
data: {
defaultVal: true,
},
methods: {
handleChange(e) {
this.setData({
defaultVal: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-switch": "tdesign-miniprogram/switch/switch"
}
}

```

### 自定义颜色

**WXML** (`html`):
```html
<view class="custom-color">
<t-cell title="自定义颜色开关" bordered="{{false}}">
<t-switch defaultValue="{{true}}" slot="note" />
</t-cell>
<!-- <t-cell title="自定义颜色" bordered="{{false}}">
<t-switch loading defaultValue="{{true}}" slot="note" />
</t-cell>
<t-cell title="自定义颜色" bordered="{{false}}">
<t-switch defaultValue="{{true}}" label="{{['关', '开']}}" slot="note" />
</t-cell>
<t-cell title="自定义颜色" bordered="{{false}}">
<t-switch defaultValue="{{true}}" icon="{{['close', 'check']}}" slot="note" />
</t-cell> -->
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
defaultVal: true,
},
methods: {
handleChange(e) {
this.setData({
defaultVal: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css
.custom-color {
--td-switch-checked-color: #00a870;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-switch": "tdesign-miniprogram/switch/switch"
}
}

```

### 开关状态

**WXML** (`html`):
```html
<view class="demo-desc">加载状态</view>

<view class="group">
<t-cell title="加载状态">
<t-switch defaultValue="{{false}}" loading slot="note" />
</t-cell>
<t-cell title="加载状态" bordered="{{false}}">
<t-switch defaultValue="{{true}}" loading slot="note" />
</t-cell>
</view>

<view class="demo-desc">禁用状态</view>

<view class="group">
<t-cell title="禁用状态">
<t-switch disabled slot="note" />
</t-cell>
<t-cell title="禁用状态" bordered="{{false}}">
<t-switch default-value="{{true}}" disabled slot="note" />
</t-cell>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.group {
margin-top: 32rpx;
}

.group + .demo-desc {
margin-top: 48rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-switch": "tdesign-miniprogram/switch/switch"
}
}

```

### 尺寸

**WXML** (`html`):
```html
<t-cell title="大尺寸 32">
<t-switch defaultValue="{{true}}" size="large" slot="note" />
</t-cell>
<t-cell title="中尺寸 28">
<t-switch defaultValue="{{true}}" slot="note" />
</t-cell>
<t-cell title="小尺寸 24" bordered="{{false}}">
<t-switch defaultValue="{{true}}" size="small" slot="note" />
</t-cell>

```

**JS** (`javascript`):
```javascript
Component({
data: {
defaultVal: true,
},
methods: {
handleChange(e) {
this.setData({
defaultVal: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-cell": "tdesign-miniprogram/cell/cell",
"t-switch": "tdesign-miniprogram/switch/switch"
}
}

```

## API

### SwitchProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| custom-value | Array | [true, false] | 用于自定义开关的值，[打开时的值，关闭时的值]。默认为 [true, false]。示例：[1, 0]、['open', 'close']。TS 类型：`Array<SwitchValue>` | N |
| disabled | Boolean | undefined | 是否禁用组件。优先级：Switch.disabled > Form.disabled | N |
| icon | Array | [] | `0.27.0`。开关的图标；[打开时的图标，关闭时的图标]。TS 类型：`string[]` | N |
| label | Array | [] | `0.27.0`。开关内容，[开启时内容，关闭时内容]。示例：['开', '关'] 。TS 类型：`string[]` | N |
| loading | Boolean | false | `0.27.0`。是否处于加载中状态 | N |
| size | String | medium | `0.27.0`。开关尺寸。可选项：small/medium/large | N |
| value | String / Number / Boolean | null | 开关值。TS 类型：`SwitchValue``type SwitchValue = string \| number \| boolean`。详细类型定义 | N |
| default-value | String / Number / Boolean | undefined | 开关值。非受控属性。TS 类型：`SwitchValue``type SwitchValue = string \| number \| boolean`。详细类型定义 | N |

### SwitchEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: SwitchValue)` | 数据发生变化时触发 |

### SwitchExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-body | 描述文本样式类 |
| t-class-dot | 滑块样式类 |
| t-class-label | 开关内容样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-switch-checked-color | @brand-color | - |
| --td-switch-checked-disabled-color | @brand-color-disabled | - |
| --td-switch-dot-disabled-color | @font-white-1 | - |
| --td-switch-dot-horizontal-margin | 6rpx | - |
| --td-switch-dot-large-size | 52rpx | - |
| --td-switch-dot-plain-horizontal-margin | 10rpx | - |
| --td-switch-dot-plain-large-size | 44rpx | - |
| --td-switch-dot-plain-size | 36rpx | - |
| --td-switch-dot-plain-small-size | 28rpx | - |
| --td-switch-dot-shadow | @shadow-1 | - |
| --td-switch-dot-size | 44rpx | - |
| --td-switch-dot-small-size | 36rpx | - |
| --td-switch-height | 56rpx | - |
| --td-switch-icon-large-size | 48rpx | - |
| --td-switch-icon-size | 40rpx | - |
| --td-switch-icon-small-size | 32rpx | - |
| --td-switch-label-checked-color | @switch-checked-color | - |
| --td-switch-label-color | @bg-color-secondarycontainer-active | - |
| --td-switch-label-font-size | 28rpx | - |
| --td-switch-label-large-font-size | 32rpx | - |
| --td-switch-label-small-font-size | 24rpx | - |
| --td-switch-large-height | 64rpx | - |
| --td-switch-large-radius | calc(@switch-large-height / 2) | - |
| --td-switch-large-width | 104rpx | - |
| --td-switch-loading-color | @brand-color | - |
| --td-switch-radius | calc(@switch-height / 2) | - |
| --td-switch-small-height | 48rpx | - |
| --td-switch-small-radius | calc(@switch-small-height / 2) | - |
| --td-switch-small-width | 78rpx | - |
| --td-switch-unchecked-color | @bg-color-secondarycontainer-active | - |
| --td-switch-unchecked-disabled-color | @bg-color-component-disabled | - |
| --td-switch-width | 90rpx | - |

---

# [tab-bar]

# TabBar 底部标签栏

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-tab-bar": "tdesign-miniprogram/tab-bar/tab-bar",
"t-tab-bar-item": "tdesign-miniprogram/tab-bar-item/tab-bar-item"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/MCE5rNmh8953)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

#### 纯文本标签栏

**WXML** (`html`):
```html
<t-tab-bar t-class="t-tab-bar" value="{{value}}" theme="tag" fixed="{{false}}" split="{{false}}" bindchange="onChange">
<t-tab-bar-item wx:for="{{list}}" wx:key="index" value="{{item.value}}"> {{item.label}} </t-tab-bar-item>
</t-tab-bar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 'home',
list: [
{ value: 'home', label: '首页' },
{ value: 'app', label: '应用' },
{ value: 'chat', label: '聊天' },
{ value: 'user', label: '我的' },
],
},

methods: {
onChange(e) {
this.setData({
value: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-tab-bar": "tdesign-miniprogram/tab-bar/tab-bar",
"t-tab-bar-item": "tdesign-miniprogram/tab-bar-item/tab-bar-item"
}
}

```

#### 图标加文字标签栏

**WXML** (`html`):
```html
<t-tab-bar t-class="t-tab-bar" value="{{value}}" bindchange="onChange" theme="tag" fixed="{{false}}" split="{{false}}">
<t-tab-bar-item wx:for="{{list}}" wx:key="value" value="{{item.value}}" icon="{{item.icon}}">
{{item.label}}
</t-tab-bar-item>
</t-tab-bar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 'label_1',
list: [
{ value: 'label_1', label: '首页', icon: 'home' },
{ value: 'label_2', label: '应用', icon: 'app' },
{ value: 'label_3', label: '聊天', icon: 'chat' },
{ value: 'label_4', label: '我的', icon: 'user' },
],
},

methods: {
onChange(e) {
this.setData({
value: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-tab-bar": "tdesign-miniprogram/tab-bar/tab-bar",
"t-tab-bar-item": "tdesign-miniprogram/tab-bar-item/tab-bar-item"
}
}

```

#### 纯图标标签栏

**WXML** (`html`):
```html
<t-tab-bar t-class="t-tab-bar" value="{{value}}" theme="tag" fixed="{{false}}" split="{{false}}" bindchange="onChange">
<t-tab-bar-item
wx:for="{{list}}"
wx:key="value"
value="{{item.value}}"
icon="{{item.icon}}"
ariaLabel="{{item.ariaLabel}}"
></t-tab-bar-item>
</t-tab-bar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 'label_1',
list: [
{ value: 'label_1', icon: 'home', ariaLabel: '首页' },
{ value: 'label_2', icon: 'app', ariaLabel: '软件' },
{ value: 'label_3', icon: 'chat', ariaLabel: '聊天' },
{ value: 'label_4', icon: 'user', ariaLabel: '我的' },
],
},

methods: {
onChange(e) {
this.setData({
value: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-tab-bar": "tdesign-miniprogram/tab-bar/tab-bar",
"t-tab-bar-item": "tdesign-miniprogram/tab-bar-item/tab-bar-item"
}
}

```

#### 双层级纯文本标签栏

**WXML** (`html`):
```html
<t-tab-bar t-class="t-tab-bar" defaultValue="user" theme="tag" fixed="{{false}}" split="{{false}}">
<t-tab-bar-item wx:for="{{list}}" wx:key="value" value="{{item.value}}" sub-tab-bar="{{item.children}}">
{{item.label}}
</t-tab-bar-item>
</t-tab-bar>

```

**JS** (`javascript`):
```javascript
const list = [
{
value: 'home',
label: '首页',
icon: 'home',
children: [],
},
{
value: 'app',
label: '应用',
icon: 'app',
children: [],
},
{
value: 'user',
label: '我的',
children: [
{
value: 'info',
label: '基本信息',
},
{
value: 'home-page',
label: '个人主页',
},
{
value: 'setting',
label: '设置',
},
],
},
];

Component({
data: {
list,
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-tab-bar": "tdesign-miniprogram/tab-bar/tab-bar",
"t-tab-bar-item": "tdesign-miniprogram/tab-bar-item/tab-bar-item"
}
}

```

### 组件样式

#### 弱选中标签栏

**WXML** (`html`):
```html
<!-- 文本 + 徽标 -->
<view class="wrapper">
<t-tab-bar t-class="t-tab-bar" defaultValue="label1" fixed="{{false}}">
<t-tab-bar-item badge-props="{{ {count: 16, offset: [16, 0]} }}" ariaLabel="首页，有16条消息" value="label1">
首页
</t-tab-bar-item>
<t-tab-bar-item badge-props="{{ { dot: true, offset: [16, 0] } }}" ariaLabel="应用，有新的消息" value="label2">
应用
</t-tab-bar-item>
<t-tab-bar-item badge-props="{{ {count: 'New', offset: [16, 0]} }}" ariaLabel="聊天，New" value="label3">
聊天
</t-tab-bar-item>
<t-tab-bar-item badge-props="{{ {count: '···', offset: [16, 0]} }}" ariaLabel="我的，有很多消息" value="label4">
我的
</t-tab-bar-item>
</t-tab-bar>
</view>

<!-- 图标 + 徽标 -->
<view class="wrapper">
<t-tab-bar t-class="t-tab-bar" defaultValue="label1" fixed="{{false}}" split="{{false}}">
<t-tab-bar-item badge-props="{{ {count: 16} }}" ariaLabel="首页，有16条消息" value="label1" icon="home" />
<t-tab-bar-item badge-props="{{ { dot: true } }}" ariaLabel="应用，有新的消息" value="label2" icon="app" />
<t-tab-bar-item badge-props="{{ {count: 'New'} }}" ariaLabel="聊天，New" value="label3" icon="chat" />
<t-tab-bar-item badge-props="{{ {count: '···'} }}" ariaLabel="我的，有很多消息" value="label4" icon="user" />
</t-tab-bar>
</view>

<!-- 文本 + 图标 + 徽标 -->
<view class="wrapper">
<t-tab-bar t-class="t-tab-bar" defaultValue="label1" fixed="{{false}}" split="{{false}}">
<t-tab-bar-item badge-props="{{ {count: 16} }}" ariaLabel="首页，有16条消息" value="label1" icon="home">
首页
</t-tab-bar-item>
<t-tab-bar-item badge-props="{{ { dot: true } }}" ariaLabel="应用，有新的消息" value="label2" icon="app">
应用
</t-tab-bar-item>
<t-tab-bar-item badge-props="{{ {count: 'New'} }}" ariaLabel="聊天，New" value="label3" icon="chat">
聊天
</t-tab-bar-item>
<t-tab-bar-item badge-props="{{ {count: '···'} }}" ariaLabel="我的，有很多消息" value="label4" icon="user">
我的
</t-tab-bar-item>
</t-tab-bar>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
list: [
{ value: 'label_1', label: '文字', icon: 'home' },
{ value: 'label_2', label: '文字', icon: 'app' },
{ value: 'label_3', label: '文字', icon: 'chat' },
{ value: 'label_4', label: '文字', icon: 'user' },
],
},
});

```

**CSS** (`css`):
```css
.wrapper:not(:last-child) {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-tab-bar": "tdesign-miniprogram/tab-bar/tab-bar",
"t-tab-bar-item": "tdesign-miniprogram/tab-bar-item/tab-bar-item"
}
}

```

#### 悬浮胶囊标签栏

**WXML** (`html`):
```html
<t-tab-bar
t-class="t-tab-bar"
value="{{value}}"
shape="round"
theme="tag"
fixed="{{false}}"
split="{{false}}"
bindchange="onChange"
>
<t-tab-bar-item
wx:for="{{list}}"
wx:key="value"
value="{{item.value}}"
icon="{{item.icon}}"
ariaLabel="{{item.ariaLabel}}"
>
</t-tab-bar-item>
</t-tab-bar>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 'label_1',
list: [
{ value: 'label_1', icon: 'home', ariaLabel: '首页' },
{ value: 'label_2', icon: 'app', ariaLabel: '软件' },
{ value: 'label_3', icon: 'chat', ariaLabel: '聊天' },
{ value: 'label_4', icon: 'user', ariaLabel: '我的' },
],
},

methods: {
onChange(e) {
this.setData({
value: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-tab-bar": "tdesign-miniprogram/tab-bar/tab-bar",
"t-tab-bar-item": "tdesign-miniprogram/tab-bar-item/tab-bar-item"
}
}

```

#### 自定义主题

**WXML** (`html`):
```html
<view class="wrapper">
<t-tab-bar t-class="t-tab-bar" value="{{value}}" fixed="{{false}}" bindchange="onChange">
<t-tab-bar-item
wx:for="{{list}}"
wx:key="value"
value="{{item.value}}"
icon="{{item.icon}}"
ariaLabel="{{item.ariaLabel}}"
></t-tab-bar-item>
</t-tab-bar>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: 'label_1',
list: [
{ value: 'label_1', icon: 'home', ariaLabel: '首页' },
{ value: 'label_2', icon: 'app', ariaLabel: '软件' },
{ value: 'label_3', icon: 'chat', ariaLabel: '聊天' },
{ value: 'label_4', icon: 'user', ariaLabel: '我的' },
],
},

methods: {
onChange(e) {
this.setData({
value: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css
.wrapper {
--td-tab-bar-border-color: var(--td-border-level-1-color, #e7e7e7);
--td-tab-bar-bg-color: var(--td-bg-color-secondarycontainer, #f3f3f3);
--td-tab-bar-hover-color: #ddd;
--td-tab-bar-item-color: var(--td-text-color-primary, rgba(0, 0, 0, 0.9));
--td-tab-bar-item-active-color: var(--td-brand-color, #0052d9);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-tab-bar": "tdesign-miniprogram/tab-bar/tab-bar",
"t-tab-bar-item": "tdesign-miniprogram/tab-bar-item/tab-bar-item"
}
}

```

## API

### TabBarProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| bordered | Boolean | true | 是否显示外边框 | N |
| fixed | Boolean | true | 是否固定在底部 | N |
| placeholder | Boolean | false | `1.12.1`。固定在底部时是否开启占位 | N |
| safe-area-inset-bottom | Boolean | true | 是否开启底部安全区适配 | N |
| shape | String | normal | 标签栏的形状。可选项：normal/round | N |
| split | Boolean | true | 是否需要分割线 | N |
| theme | String | normal | 选项风格。可选项：normal/tag | N |
| value | String / Number / Array | - | 当前选中标签的索引。TS 类型：`string \| number \| Array<string \| number>` | N |
| default-value | String / Number / Array | undefined | 当前选中标签的索引。非受控属性。TS 类型：`string \| number \| Array<string \| number>` | N |
| z-index | Number | 1 | 标签栏层级 | N |

### TabBarEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: string \| number)` | 选中标签切换时触发 |

### TabBarExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |

### TabBarItemProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| badge-props | Object | - | 图标右上角提示信息。TS 类型：`BadgeProps`，Badge API Documents。详细类型定义 | N |
| icon | String / Object | - | 图标名称。传入对象时透传至 Icon 组件 | N |
| sub-tab-bar | Array | - | 二级菜单。TS 类型：`SubTabBarItem[] ``interface SubTabBarItem { value: string; label: string }`。详细类型定义 | N |
| value | String / Number | - | 标识符 | N |

### TabBarItemSlots

| 名称 | 描述 |
| --- | --- |
| icon | 图标插槽，用于自定义图标区域内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-tab-bar-bg-color | @bg-color-container | - |
| --td-tab-bar-border-color | @border-level-1-color | - |
| --td-tab-bar-round-shadow | @shadow-3 | - |
| --td-tab-bar-active-bg | @brand-color-light | - |
| --td-tab-bar-active-color | @brand-color | - |
| --td-tab-bar-color | @text-color-primary | - |
| --td-tab-bar-height | 80rpx | - |
| --td-tab-bar-hover-bg-color | rgba(0, 0, 0, 0.05) | - |
| --td-tab-bar-spread-border-color | @border-color | - |
| --td-tab-bar-spread-shadow | @shadow-3 | - |

---

# [table]

# 组件概览

### 基础6

[Button 按钮](/miniprogram/components/button)   [Divider 分割线](/miniprogram/components/divider)   [Fab 悬浮按钮](/miniprogram/components/fab)   [Icon 图标](/miniprogram/components/icon)   [Layout 布局](/miniprogram/components/layout)   [Link 链接](/miniprogram/components/link)
### 导航8

[BackTop 返回顶部](/miniprogram/components/back-top)   [Drawer 抽屉](/miniprogram/components/drawer)   [Indexes 索引](/miniprogram/components/indexes)   [Navbar 导航条](/miniprogram/components/navbar)   [SideBar 侧边导航栏](/miniprogram/components/side-bar)   [Steps 步骤条](/miniprogram/components/steps)   [TabBar 底部标签栏](/miniprogram/components/tab-bar)   [Tabs 选项卡](/miniprogram/components/tabs)
### 输入16

[Calendar 日历](/miniprogram/components/calendar)   [Cascader 级联选择器](/miniprogram/components/cascader)   [CheckBox 多选框](/miniprogram/components/checkbox)   [ColorPicker 颜色选择器](/miniprogram/components/color-picker)   [DateTimePicker 日期选择器](/miniprogram/components/date-time-picker)   [Input 输入框](/miniprogram/components/input)   [Picker 选择器](/miniprogram/components/picker)   [Radio 单选框](/miniprogram/components/radio)   [Rate 评分](/miniprogram/components/rate)   [Search 搜索框](/miniprogram/components/search)   [Slider 滑动选择器](/miniprogram/components/slider)   [Stepper 步进器](/miniprogram/components/stepper)   [Switch 开关](/miniprogram/components/switch)   [Textarea 多行文本框](/miniprogram/components/textarea)   [TreeSelect 树形选择器](/miniprogram/components/tree-select)   [Upload 上传](/miniprogram/components/upload)
### 数据展示18

[Avatar 头像](/miniprogram/components/avatar)   [Badge 徽章](/miniprogram/components/badge)   [Cell 单元格](/miniprogram/components/cell)   [Collapse 折叠面板](/miniprogram/components/collapse)   [CountDown 倒计时](/miniprogram/components/count-down)   [Empty 空状态](/miniprogram/components/empty)   [Footer 页脚](/miniprogram/components/footer)   [Grid 宫格](/miniprogram/components/grid)   [Image 图片](/miniprogram/components/image)   [ImageViewer 图片预览](/miniprogram/components/image-viewer)   [Progress 进度条](/miniprogram/components/progress)   [QRCode 二维码](/miniprogram/components/qrcode)   [Result 结果](/miniprogram/components/result)   [Skeleton 骨架屏](/miniprogram/components/skeleton)   [Sticky 吸顶容器](/miniprogram/components/sticky)   [Swiper 轮播图](/miniprogram/components/swiper)   [Tag 标签](/miniprogram/components/tag)   [Watermark 水印](/miniprogram/components/watermark)
### 反馈12

[ActionSheet 动作面板](/miniprogram/components/action-sheet)   [Dialog 对话框](/miniprogram/components/dialog)   [DropdownMenu 下拉菜单](/miniprogram/components/dropdown-menu)   [Guide 引导](/miniprogram/components/guide)   [Loading 加载](/miniprogram/components/loading)   [Message 全局提示](/miniprogram/components/message)   [NoticeBar 消息提醒](/miniprogram/components/notice-bar)   [Overlay 遮罩层](/miniprogram/components/overlay)   [Popover 弹出气泡](/miniprogram/components/popover)   [Popup 弹出层](/miniprogram/components/popup)   [PullDownRefresh 下拉刷新](/miniprogram/components/pull-down-refresh)   [SwipeCell 滑动操作](/miniprogram/components/swipe-cell)   [Toast 轻提示](/miniprogram/components/toast)

---

# [tabs]

# Tabs 选项卡

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-tabs": "tdesign-miniprogram/tabs/tabs",
"t-tab-panel": "tdesign-miniprogram/tab-panel/tab-panel"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/3cEe7Nmu8d5T)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础选项卡

**WXML** (`html`):
```html
<t-tabs defaultValue="{{0}}" bind:change="onTabsChange" bind:click="onTabsClick" t-class="custom-tabs">
<t-tab-panel label="选项" value="0" />
<t-tab-panel label="选项" value="1" />
</t-tabs>

<t-tabs defaultValue="{{0}}" bind:change="onTabsChange" bind:click="onTabsClick" t-class="custom-tabs">
<t-tab-panel label="选项" value="0" />
<t-tab-panel label="选项" value="1" />
<t-tab-panel label="上限六个文字" value="2" />
</t-tabs>

<t-tabs defaultValue="{{0}}" bind:change="onTabsChange" bind:click="onTabsClick" t-class="custom-tabs">
<t-tab-panel label="选项" value="0" />
<t-tab-panel label="选项" value="1" />
<t-tab-panel label="选项" value="2" />
<t-tab-panel label="上限四字" value="3" />
</t-tabs>

<t-tabs
defaultValue="{{0}}"
sticky
stickyProps="{{stickyProps}}"
bind:change="onTabsChange"
bind:click="onTabsClick"
bind:scroll="onStickyScroll"
t-class="custom-tabs"
>
<t-tab-panel label="选项" value="0" />
<t-tab-panel label="选项" value="1" />
<t-tab-panel label="选项" value="2" />
<t-tab-panel label="选项" value="3" />
<t-tab-panel label="上限四字" value="4" />
</t-tabs>

```

**JS** (`javascript`):
```javascript
Component({
data: {
stickyProps: {
zIndex: 100,
},
},
methods: {
onTabsChange(event) {
console.log(`Change tab, tab-panel value is ${event.detail.value}.`);
},

onTabsClick(event) {
console.log(`Click tab, tab-panel value is ${event.detail.value}.`);
},

onStickyScroll(event) {
console.log(event.detail);
},
},
});

```

**CSS** (`css`):
```css
.custom-tabs {
margin-bottom: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tabs": "tdesign-miniprogram/tabs/tabs",
"t-tab-panel": "tdesign-miniprogram/tab-panel/tab-panel"
}
}

```

### 等距选项卡

**WXML** (`html`):
```html
<t-tabs defaultValue="{{0}}" space-evenly="{{false}}" bind:change="onTabsChange" bind:click="onTabsClick">
<t-tab-panel wx:for="{{8}}" wx:key="index" label="选项" value="{{index}}" />
</t-tabs>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
onTabsChange(event) {
console.log(`Change tab, tab-panel value is ${event.detail.value}.`);
},

onTabsClick(event) {
console.log(`Click tab, tab-panel value is ${event.detail.value}.`);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tabs": "tdesign-miniprogram/tabs/tabs",
"t-tab-panel": "tdesign-miniprogram/tab-panel/tab-panel"
}
}

```

### 带图标选项卡

**WXML** (`html`):
```html
<t-tabs defaultValue="{{0}}">
<t-tab-panel wx:for="{{3}}" wx:key="index" icon="app" label="选项" value="{{index}}" />
</t-tabs>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tabs": "tdesign-miniprogram/tabs/tabs",
"t-tab-panel": "tdesign-miniprogram/tab-panel/tab-panel"
}
}

```

### 带徽章选项卡

**WXML** (`html`):
```html
<t-tabs defaultValue="{{0}}">
<t-tab-panel label="选项" value="0" badge-props="{{ { dot: true, offset: [0, 1] } }}" />
<t-tab-panel label="选项" value="1" badge-props="{{ { count: 8, offset: [0, 1] } }}" />
<t-tab-panel label="选项" value="2" />
</t-tabs>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tabs": "tdesign-miniprogram/tabs/tabs",
"t-tab-panel": "tdesign-miniprogram/tab-panel/tab-panel"
}
}

```

### 带内容区选项卡

**WXML** (`html`):
```html
<t-tabs
animation="{{ { duration: 0.6 } }}"
defaultValue="{{0}}"
bind:change="onTabsChange"
bind:click="onTabsClick"
t-class="custom-tabs"
t-class-content="custom-panel"
>
<t-tab-panel label="选项一" value="0">
<view class="custom-panel__content">选项一内容</view>
</t-tab-panel>
<t-tab-panel label="选项二" value="1">
<view class="custom-panel__content">选项二内容</view>
</t-tab-panel>
<t-tab-panel label="选项三" value="2">
<view class="custom-panel__content">选项三内容</view>
</t-tab-panel>
<t-tab-panel label="选项四" value="3">
<view class="custom-panel__content">选项四内容</view>
</t-tab-panel>
</t-tabs>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
onTabsChange(event) {
console.log(`Change tab, tab-panel value is ${event.detail.value}.`);
},

onTabsClick(event) {
console.log(`Click tab, tab-panel value is ${event.detail.value}.`);
},
},
});

```

**CSS** (`css`):
```css
.custom-tabs {
margin-bottom: 32rpx;
}

.custom-panel {
color: var(--td-text-color-primary);
}

.custom-panel__content {
height: 240rpx;
font-size: 28rpx;
color: var(--td-text-color-placeholder);
padding: 40rpx;
display: flex;
justify-content: center;
align-items: center;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tabs": "tdesign-miniprogram/tabs/tabs",
"t-tab-panel": "tdesign-miniprogram/tab-panel/tab-panel"
}
}

```

### 选项卡状态

**WXML** (`html`):
```html
<t-tabs value="{{value}}" bind:change="onTabsChange" bind:click="onTabsClick">
<t-tab-panel label="{{value == '0' ? '选中' : '默认'}}" value="0" />
<t-tab-panel label="{{value == '1' ? '选中' : '默认'}}" value="1" />
<t-tab-panel label="禁用" value="2" disabled />
</t-tabs>

```

**JS** (`javascript`):
```javascript
Component({
data: {
value: '0',
},
methods: {
onTabsChange(event) {
this.setData({
value: event.detail.value,
});
console.log(`Change tab, tab-panel value is ${event.detail.value}.`);
},

onTabsClick(event) {
console.log(`Click tab, tab-panel value is ${event.detail.value}.`);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tabs": "tdesign-miniprogram/tabs/tabs",
"t-tab-panel": "tdesign-miniprogram/tab-panel/tab-panel"
}
}

```

### 选项卡尺寸

**WXML** (`html`):
```html
<t-tabs defaultValue="{{0}}">
<t-tab-panel label="小尺寸" value="0" />
<t-tab-panel label="选项" value="1" />
<t-tab-panel label="选项" value="2" />
<t-tab-panel label="选项" value="3" />
</t-tabs>

<view style="height: 16px" />

<t-tabs class="bigger" defaultValue="{{0}}">
<t-tab-panel label="大尺寸" value="0" />
<t-tab-panel label="选项" value="1" />
<t-tab-panel label="选项" value="2" />
<t-tab-panel label="选项" value="3" />
</t-tabs>

```

**JS** (`javascript`):
```javascript
Component({
methods: {
onTabsChange(event) {
console.log(`Change tab, tab-panel value is ${event.detail.value}.`);
},

onTabsClick(event) {
console.log(`Click tab, tab-panel value is ${event.detail.value}.`);
},
},
});

```

**CSS** (`css`):
```css
.bigger {
--td-tab-font: var(--td-font-body-large);
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tabs": "tdesign-miniprogram/tabs/tabs",
"t-tab-panel": "tdesign-miniprogram/tab-panel/tab-panel"
}
}

```

### 选项卡样式

使用 theme 属性可以变换风格，支持 line = 线条（默认）；tag = 标签；card = 卡片

**WXML** (`html`):
```html
<t-tabs defaultValue="{{0}}" theme="tag">
<t-tab-panel wx:for="{{4}}" wx:key="index" label="选项" value="{{index}}" />
</t-tabs>

<view style="height: 16px" />

<t-tabs defaultValue="{{0}}" theme="card">
<t-tab-panel wx:for="{{4}}" wx:key="index" label="选项" value="{{index}}" />
</t-tabs>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tabs": "tdesign-miniprogram/tabs/tabs",
"t-tab-panel": "tdesign-miniprogram/tab-panel/tab-panel"
}
}

```

### 受控用法

```html
<t-tabs value="{{value}}" bind:change="onTabsChange">
<t-tab-panel label="标签页一" value="0">标签一内容</t-tab-panel>
<t-tab-panel label="标签页二" value="1">标签二内容</t-tab-panel>
</t-tabs>
```

```js
Page({
data: {
value: '0',
},
onTabsChange(e) {
this.setData({ value: e.detail.value })
},
});
```

### 与Popup使用

```html
<t-popup visible="{{visible}}" bind:visible-change="onVisibleChange">
<t-tabs id="tabs" defaultValue="{{0}}" bind:change="onTabsChange" bind:click="onTabsClick" t-class="custom-tabs">
<t-tab-panel label="标签页一" value="0">标签一内容</t-tab-panel>
<t-tab-panel label="标签页二" value="1">标签二内容</t-tab-panel>
<t-tab-panel label="标签页三" value="2">标签三内容</t-tab-panel>
</t-tabs>
</t-popup>
```

```js
Page({
data: {
visible: false
},
showPopup() {
this.setData({
visible: true
}, () => {
const tabs = this.selectComponent('tabs');

tabs.setTrack(); // 这一步很重要，因为小程序的无法正确执行生命周期，所以需要手动设置下 tabs 的滑块
})
}
})
```

## API

### TabsProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| animation | Object | - | 动画效果设置。其中 duration 表示动画时长。（单位：秒）。TS 类型：`TabAnimation``type TabAnimation = { duration: number } & Record<string, any>`。详细类型定义 | N |
| bottom-line-mode | String | fixed | 激活下划线的模式。可选项：fixed/auto/full | N |
| show-bottom-line | Boolean | true | 是否展示底部激活线条 | N |
| space-evenly | Boolean | true | 选项卡头部空间是否均分 | N |
| split | Boolean | true | `1.1.10`。是否展示分割线 | N |
| sticky | Boolean | false | 是否开启粘性布局 | N |
| sticky-props | Object | - | 透传至 Sticky 组件。TS 类型：`StickyProps`，Sticky API Documents。详细类型定义 | N |
| swipeable | Boolean | true | 是否可以滑动切换 | N |
| theme | String | line | 标签的样式。可选项：line/tag/card | N |
| value | String / Number | - | 激活的选项卡值。TS 类型：`TabValue``type TabValue = string \| number`。详细类型定义 | N |
| default-value | String / Number | undefined | 激活的选项卡值。非受控属性。TS 类型：`TabValue``type TabValue = string \| number`。详细类型定义 | N |

### TabsEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: TabValue, label: string)` | 激活的选项卡发生变化时触发 |
| click | `(value: TabValue, label: string)` | 点击选项卡时触发 |
| scroll | `(scrollTop: number, isFixed: boolean)` | 页面滚动时触发 |

### TabsSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义选项卡内容 |
| middle | 中间内容，介于头部和内容之间 |

### TabsExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-active | 激活态样式类 |
| t-class-content | 内容样式类 |
| t-class-item | 选项样式类 |
| t-class-track | 滚动条样式类 |

### TabPanelProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| badge-props | Object | - | 透传至 Badge 组件 | N |
| disabled | Boolean | false | 是否禁用当前选项卡 | N |
| icon | String / Object | - | `1.0.0-rc.1`。图标，传对象则透传至 Icon | N |
| label | String | - | 选项卡名称 | N |
| lazy | Boolean | false | 是否启用选项卡懒加载 | N |
| panel | String | - | 用于自定义选项卡面板内容 | N |
| value | String / Number | - | 选项卡的值，唯一标识。TS 类型：`TabValue`，Tabs API Documents。详细类型定义 | N |

### TabPanelSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义选项卡面板内容 |
| panel | 自定义`panel`显示内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-tab-border-color | @component-stroke | - |
| --td-tab-font | @font-body-medium | - |
| --td-tab-icon-size | 36rpx | - |
| --td-tab-item-active-color | @brand-color | - |
| --td-tab-item-color | @text-color-primary | - |
| --td-tab-item-disabled-color | @text-color-disabled | - |
| --td-tab-item-height | 96rpx | - |
| --td-tab-item-tag-active-bg | @brand-color-light | - |
| --td-tab-item-tag-bg | @bg-color-secondarycontainer | - |
| --td-tab-item-tag-height | 64rpx | - |
| --td-tab-item-vertical-height | 108rpx | - |
| --td-tab-item-vertical-width | 208rpx | - |
| --td-tab-nav-bg-color | @bg-color-container | - |
| --td-tab-track-color | @brand-color | - |
| --td-tab-track-radius | 8rpx | - |
| --td-tab-track-thickness | 6rpx | - |
| --td-tab-track-width | 32rpx | - |

---

# [tag]

# Tag 标签

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-tag": "tdesign-miniprogram/tag/tag",
"t-check-tag": "tdesign-miniprogram/check-tag/check-tag"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/5GEWDNm18j5u)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

**WXML** (`html`):
```html
<view class="demo">
<view class="demo-desc">基础标签</view>

<t-tag class="margin-16" variant="light">标签文字</t-tag>
<t-tag class="margin-16" variant="outline">标签文字</t-tag>
</view>

<view class="demo">
<view class="demo-desc">圆弧标签</view>

<t-tag class="margin-16" variant="light" shape="round">标签文字</t-tag>
<t-tag class="margin-16" variant="outline" shape="round">标签文字</t-tag>
<t-tag class="margin-16" variant="outline" shape="mark">标签文字</t-tag>
</view>

<view class="demo">
<view class="demo-desc">带图标的标签</view>

<t-tag class="margin-16" variant="light" icon="discount"> 标签文字 </t-tag>
<t-tag class="margin-16" variant="outline" icon="discount"> 标签文字 </t-tag>
</view>

<!-- skyline暂不支持设置后max-width超出省略 -->
<view class="demo" wx:if="{{!skylineRender}}">
<view class="demo-desc">超长省略文本标签</view>

<t-tag max-width="{{130}}" variant="light">超长省略文本标签超长省略文本标签</t-tag>
</view>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

Component({
behaviors: [SkylineBehavior],
});

```

**CSS** (`css`):
```css
.demo {
padding: 0 32rpx 48rpx;
}

.demo:last-child {
padding-bottom: 0;
}

.demo-desc {
font-size: 14px;
color: var(--td-text-color-secondary);
margin-bottom: 32rpx;
}

.demo .margin-16:not(:last-child) {
margin-right: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tag": "tdesign-miniprogram/tag/tag"
}
}

```

可关闭的标签

**WXML** (`html`):
```html
<view class="demo">
<t-tag wx:if="{{show[0]}}" class="margin-16" bind:close="handleClose0" closable variant="light">文字标签</t-tag>
<t-tag wx:if="{{show[1]}}" class="margin-16" bind:close="handleClose1" closable variant="outline">文字标签</t-tag>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
show: [true, true],
},

methods: {
handleClose0() {
this.setData({
[`show[0]`]: false,
});
},
handleClose1() {
this.setData({
[`show[1]`]: false,
});
},
},
});

```

**CSS** (`css`):
```css
.demo {
margin-left: 32rpx;
}

.demo .margin-16:not(:last-child) {
margin-right: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tag": "tdesign-miniprogram/tag/tag"
}
}

```

可点击的标签

**WXML** (`html`):
```html
<view class="wrapper">
<block wx:for="{{items}}" wx:key="index">
<view class="block">
<text>{{item}}</text>
<t-check-tag class="margin-16" size="large" variant="{{item}}" content="{{ ['已选中态', '未选中态'] }}" />
<t-check-tag
class="margin-16"
default-checked
size="large"
variant="{{item}}"
content="{{ ['已选中态', '未选中态'] }}"
/>
</view>
</block>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
items: ['light', 'dark', 'outline', 'light-outline'],
},
});

```

**CSS** (`css`):
```css
.wrapper {
flex-wrap: wrap;
margin: 0 32rpx;
}

.wrapper t-check-tag {
display: block;
}

.block {
display: flex;
font-size: 14px;
align-items: center;
line-height: 76rpx;
color: var(--td-text-color-placeholder);
}

.block text {
display: block;
width: 160rpx;
margin-right: 32rpx;
}

/* .block t-check-tag {
margin-right: 32rpx;
} */

.block + .block {
margin-top: 32rpx;
}

.block .margin-16:not(:last-child) {
margin-right: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-check-tag": "tdesign-miniprogram/check-tag/check-tag"
}
}

```

### 组件状态

展示型标签

**WXML** (`html`):
```html
<view class="block">
<t-tag class="margin-16" variant="light">默认</t-tag>
<t-tag class="margin-16" variant="light" theme="primary">主要</t-tag>
<t-tag class="margin-16" variant="light" theme="warning">警告</t-tag>
<t-tag class="margin-16" variant="light" theme="danger">危险</t-tag>
<t-tag class="margin-16" variant="light" theme="success">成功</t-tag>
</view>

<view class="block">
<t-tag class="margin-16" theme="default">默认</t-tag>
<t-tag class="margin-16" theme="primary">主要</t-tag>
<t-tag class="margin-16" theme="warning">警告</t-tag>
<t-tag class="margin-16" theme="danger">危险</t-tag>
<t-tag class="margin-16" theme="success">成功</t-tag>
</view>

<view class="block">
<t-tag class="margin-16" variant="outline">默认</t-tag>
<t-tag class="margin-16" variant="outline" theme="primary">主要</t-tag>
<t-tag class="margin-16" variant="outline" theme="warning">警告</t-tag>
<t-tag class="margin-16" variant="outline" theme="danger">危险</t-tag>
<t-tag class="margin-16" variant="outline" theme="success">成功</t-tag>
</view>

<view class="block">
<t-tag class="margin-16" variant="light-outline">默认</t-tag>
<t-tag class="margin-16" variant="light-outline" theme="primary">主要</t-tag>
<t-tag class="margin-16" variant="light-outline" theme="warning">警告</t-tag>
<t-tag class="margin-16" variant="light-outline" theme="danger">危险</t-tag>
<t-tag class="margin-16" variant="light-outline" theme="success">成功</t-tag>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.block {
margin: 0 32rpx;
}

.block + .block {
margin-top: 48rpx;
}

.block .margin-16:not(:last-child) {
margin-right: 32rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tag": "tdesign-miniprogram/tag/tag"
}
}

```

### 组件尺寸

**WXML** (`html`):
```html
<view class="block">
<t-tag class="margin-16" size="extra-large" variant="light">加大尺寸</t-tag>
<t-tag class="margin-16" size="large" variant="light">大尺寸</t-tag>
<t-tag class="margin-16" size="medium" variant="light">中尺寸</t-tag>
<t-tag class="margin-16" size="small" variant="light">小尺寸</t-tag>
</view>

<view class="block">
<t-tag class="margin-8" size="extra-large" variant="light" closable>加大尺寸</t-tag>
<t-tag class="margin-8" size="large" variant="light" closable>大尺寸</t-tag>
<t-tag class="margin-8" size="medium" variant="light" closable>中尺寸</t-tag>
<t-tag class="margin-8" size="small" variant="light" closable>小尺寸</t-tag>
</view>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.block {
margin: 0 32rpx;
}

.block + .block {
margin-top: 32rpx;
}

.block .margin-16,
.block .margin-8 {
vertical-align: top;
}

.block .margin-16:not(:last-child) {
margin-right: 32rpx;
}

.block .margin-8:not(:last-child) {
margin-right: 10rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tag": "tdesign-miniprogram/tag/tag"
}
}

```

## API

### TagProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| closable | Boolean / Object | false | 标签是否可关闭 | N |
| disabled | Boolean | false | 标签禁用态，失效标签不能触发事件。默认风格（theme=default）才有禁用态 | N |
| icon | String / Object | - | 标签中的图标，可自定义图标呈现 | N |
| max-width | String / Number | - | 标签最大宽度，宽度超出后会出现省略号。示例：'50px' / 80 | N |
| shape | String | square | 标签类型，有三种：方形、圆角方形、标记型。可选项：square/round/mark | N |
| size | String | medium | 标签尺寸。可选项：small/medium/large/extra-large | N |
| theme | String | default | 组件风格，用于描述组件不同的应用场景。可选项：default/primary/warning/danger/success | N |
| variant | String | dark | 标签风格变体。可选项：dark/light/outline/light-outline | N |

### TagEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| click | - | 点击时触发 |
| close | - | 如果关闭按钮存在，点击关闭按钮时触发 |

### TagSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，自定义内容区域内容 |
| closable | 标签可关闭内容区域 |
| icon | 标签中的图标 |

### TagExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |

### CheckTagProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| checked | Boolean | - | 标签选中的状态，默认风格（theme=default）才有选中态 | N |
| default-checked | Boolean | undefined | 标签选中的状态，默认风格（theme=default）才有选中态。非受控属性 | N |
| closable | Boolean | false | 标签是否可关闭 | N |
| content | String / Number / Array | - | 组件子元素；传入数组时：[选中内容，非选中内容]。TS 类型：`string \| number \| string[]` | N |
| disabled | Boolean | false | 标签禁用态，失效标签不能触发事件。默认风格（theme=default）才有禁用态 | N |
| icon | String / Object | - | 标签图标 | N |
| shape | String | square | 标签类型，有三种：方形、圆角方形、标记型。可选项：square/round/mark | N |
| size | String | medium | 标签尺寸。可选项：small/medium/large。TS 类型：`SizeEnum`。通用类型定义 | N |
| variant | String | dark | `0.26.0`。标签风格变体。可选项：dark/light/outline/light-outline | N |

### CheckTagEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(checked: boolean)` | 状态切换时触发 |
| click | - | 点击标签时触发 |
| close | - | 如果关闭按钮存在，点击关闭按钮时触发 |

### CheckTagSlots

| 名称 | 描述 |
| --- | --- |
| - | 默认插槽，作用同`content`插槽 |
| content | 自定义内容区域 |
| icon | 标签区域 |

### CheckTagExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-tag-close-icon-color | @text-color-placeholder | - |
| --td-tag-danger-color | @error-color | - |
| --td-tag-danger-light-color | @error-color-1 | - |
| --td-tag-default-color | @bg-color-component | - |
| --td-tag-default-font-color | @text-color-primary | - |
| --td-tag-default-light-color | @bg-color-secondarycontainer | - |
| --td-tag-disabled-background-color | @bg-color-component-disabled | - |
| --td-tag-disabled-border-color | @component-border | - |
| --td-tag-disabled-color | @text-color-disabled | - |
| --td-tag-extra-large-font | @font-body-medium | - |
| --td-tag-extra-large-icon-size | 32rpx | - |
| --td-tag-extra-large-padding | 16rpx 30rpx | - |
| --td-tag-large-font | @font-body-medium | - |
| --td-tag-large-icon-size | 32rpx | - |
| --td-tag-large-padding | 4rpx 14rpx | - |
| --td-tag-mark-border-radius | @tag-round-border-radius | - |
| --td-tag-medium-font | @font-body-small | - |
| --td-tag-medium-icon-size | 28rpx | - |
| --td-tag-medium-padding | 2rpx 14rpx | - |
| --td-tag-outline-bg-color | @bg-color-container | - |
| --td-tag-primary-color | @brand-color | - |
| --td-tag-primary-light-color | @brand-color-light | - |
| --td-tag-round-border-radius | 999px | - |
| --td-tag-small-font | @font-body-extraSmall | - |
| --td-tag-small-icon-size | 24rpx | - |
| --td-tag-small-padding | 2rpx 10rpx | - |
| --td-tag-square-border-radius | 8rpx | - |
| --td-tag-success-color | @success-color | - |
| --td-tag-success-light-color | @success-color-1 | - |
| --td-tag-warning-color | @warning-color | - |
| --td-tag-warning-light-color | @warning-color-1 | - |

---

# [textarea]

# Textarea 多行文本框

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-textarea": "tdesign-miniprogram/textarea/textarea"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/Q1EXbNm58n5J)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

基础多行文本框

**WXML** (`html`):
```html
<t-textarea t-class="external-class" placeholder="请输入文字" disableDefaultPadding="{{true}}" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.external-class {
height: 256rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-textarea": "tdesign-miniprogram/textarea/textarea"
}
}

```

带标题多行文本框

**WXML** (`html`):
```html
<t-textarea t-class="external-class" label="标签文字" placeholder="请输入文字" disableDefaultPadding="{{true}}" />

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.external-class {
height: 256rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-textarea": "tdesign-miniprogram/textarea/textarea"
}
}

```

自动增高多行文本框

**WXML** (`html`):
```html
<t-textarea
label="标签文字"
placeholder="请输入文字"
disableDefaultPadding="{{true}}"
autosize="{{autosize}}"
bind:line-change="onLineChange"
/>

```

**JS** (`javascript`):
```javascript
Component({
data: {
autosize: {
maxHeight: 120,
minHeight: 20,
},
},
methods: {
onLineChange(e) {
console.log('lineCount: ', e.detail);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-textarea": "tdesign-miniprogram/textarea/textarea"
}
}

```

设置最大字符个数

**WXML** (`html`):
```html
<t-textarea
t-class="external-class"
label="标签文字"
placeholder="设置最大字符个数"
maxlength="200"
disableDefaultPadding="{{true}}"
indicator
/>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.external-class {
height: 324rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-textarea": "tdesign-miniprogram/textarea/textarea"
}
}

```

设置最大字符个数，一个汉字表示两个字符

**WXML** (`html`):
```html
<t-textarea
t-class="external-class"
label="标签文字"
placeholder="设置最大字符个数，一个汉字表示两个字符"
maxcharacter="200"
disableDefaultPadding="{{true}}"
indicator
/>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.external-class {
height: 324rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-textarea": "tdesign-miniprogram/textarea/textarea"
}
}

```

### 组件状态

禁用多行文本框

**WXML** (`html`):
```html
<t-textarea
t-class="external-class"
label="标签文字"
placeholder="请输入文字"
value="不可编辑文字"
disableDefaultPadding="{{true}}"
disabled
/>

```

**JS** (`javascript`):
```javascript
Component({});

```

**CSS** (`css`):
```css
.external-class {
height: 256rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-textarea": "tdesign-miniprogram/textarea/textarea"
}
}

```

### 自定义组件样式

标签外置输入框

**WXML** (`html`):
```html
<view class="textarea-example">
<text class="textarea-example__label">标签文字</text>
<t-textarea
t-class="external-class"
placeholder="请输入文字"
bordered
maxlength="100"
disableDefaultPadding="{{true}}"
indicator
style="{{style}}"
/>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
style: 'height: 248rpx',
},
});

```

**CSS** (`css`):
```css
.textarea-example {
padding: 32rpx 32rpx 48rpx;
background-color: var(--bg-color-demo);
}

.external-class {
padding-top: 24rpx !important;
padding-bottom: 24rpx !important;
}

.textarea-example__label {
display: block;
color: var(--td-text-color-primary);
font-size: 24rpx;
line-height: 40rpx;
padding-bottom: 16rpx;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-textarea": "tdesign-miniprogram/textarea/textarea"
}
}

```

## 提示

- 如果需要在页面中调整 `textarea` 中 `placeholder` 样式，请使用名称为`t-textarea__placeholder`的Class选择器，直接覆盖组件内部样式（注意权重）。

## API

### TextareaProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| adjust-position | Boolean | true | 键盘弹起时，是否自动上推页面 | N |
| allow-input-over-max | Boolean | false | `1.8.6`。超出`maxlength`或`maxcharacter`之后是否还允许输入 | N |
| autofocus | Boolean | false | 自动聚焦，拉起键盘 | N |
| autosize | Boolean / Object | false | 是否自动增高，值为 true 时，style.height 不生效。支持传入对象，如 { maxHeight: 120, minHeight: 20 }。TS 类型：`boolean \| { maxHeight?: number, minHeight?: number }` | N |
| bordered | Boolean | false | 是否显示外边框 | N |
| confirm-hold | Boolean | false | 点击键盘右下角按钮时是否保持键盘不收起点 | N |
| confirm-type | String | return | 设置键盘右下角按钮的文字，仅在 type='text'时生效。可选项：return/send/search/next/go/done。TS 类型：`'return' \| 'send' \| 'search' \| 'next' \| 'go' \| 'done'` | N |
| cursor | Number | -1 | 指定 focus 时的光标位置 | N |
| cursor-color | String | #0052d9 | 【试验性】光标颜色，仅在 Skyline 下有效 | N |
| cursor-spacing | Number | 0 | 指定光标与键盘的距离。取textarea距离底部的距离和cursor-spacing指定的距离的最小值作为光标与键盘的距离 | N |
| disable-default-padding | Boolean | false | 是否去掉 iOS 下的默认内边距 | N |
| disabled | Boolean | undefined | 是否禁用文本框 | N |
| fixed | Boolean | false | 如果 textarea 是在一个`position:fixed`的区域，需要显式指定属性 fixed 为 true | N |
| focus | Boolean | false | 自动聚焦 | N |
| hold-keyboard | Boolean | false | focus时，点击页面的时候不收起键盘 | N |
| indicator | Boolean | false | 显示文本计数器，如 0/140。当`maxlength < 0 && maxcharacter < 0`成立时， indicator无效 | N |
| label | String | - | 左侧文本 | N |
| maxcharacter | Number | - | 用户最多可以输入的字符个数，一个中文汉字表示两个字符长度 | N |
| maxlength | Number | -1 | 用户最多可以输入的字符个数，值为 -1 的时候不限制最大长度 | N |
| placeholder | String | undefined | 占位符 | N |
| placeholder-class | String | textarea-placeholder | 指定 placeholder 的样式类，目前仅支持color,font-size和font-weight | N |
| placeholder-style | String | - | 指定 placeholder 的样式，目前仅支持 color ,font-size和font-weight | N |
| readonly | Boolean | undefined | `1.8.6`。只读状态 | N |
| selection-end | Number | -1 | 光标结束位置，自动聚集时有效，需与 selection-start 搭配使用 | N |
| selection-start | Number | -1 | 光标起始位置，自动聚集时有效，需与 selection-end 搭配使用 | N |
| show-confirm-bar | Boolean | true | 是否显示键盘上方带有”完成“按钮那一栏 | N |
| value | String / Number | - | 文本框值。TS 类型：`TextareaValue``type TextareaValue = string \| number`。详细类型定义 | N |
| default-value | String / Number | undefined | 文本框值。非受控属性。TS 类型：`TextareaValue``type TextareaValue = string \| number`。详细类型定义 | N |

### TextareaEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| blur | `(value: TextareaValue, cursor: number)` | 失去焦点时触发 |
| change | `(value: TextareaValue, cursor: number)` | 输入内容变化时触发 |
| enter | `(value: TextareaValue)` | 点击完成时触发 |
| focus | `(value: TextareaValue)` | 获得焦点时触发 |
| keyboardheightchange | `(height: number, duration: number)` | 键盘高度发生变化的时候触发此事件 |
| line-change | `(value: TextareaValue)` | 行高发生变化时触发 |

### TextareaSlots

| 名称 | 描述 |
| --- | --- |
| label | 自定义`label`显示内容 |

### TextareaExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-indicator | 计数器样式类 |
| t-class-label | 左侧文本样式类 |
| t-class-textarea | 多行文本框样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-textarea-background-color | @bg-color-container | - |
| --td-textarea-border-color | @component-border | - |
| --td-textarea-border-radius | @radius-default | - |
| --td-textarea-disabled-text-color | @text-color-disabled | - |
| --td-textarea-indicator-text-color | @text-color-placeholder | - |
| --td-textarea-label-color | @text-color-primary | - |
| --td-textarea-padding | 32rpx | - |
| --td-textarea-placeholder-color | @text-color-placeholder | - |
| --td-textarea-text-color | @text-color-primary | - |

---

# [toast]

# Toast 轻提示

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-toast": "tdesign-miniprogram/toast/toast"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/RA0opOm78g53)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 基础提示

**WXML** (`html`):
```html
<t-toast id="t-toast" />
<view class="box">
<t-button size="large" variant="outline" theme="primary" bind:tap="showText" block>纯文本</t-button>
<t-button size="large" variant="outline" theme="primary" bind:tap="showMultiText" block>多行文字</t-button>
<t-button size="large" variant="outline" theme="primary" bind:tap="showHorizontalText" block>带横向图标</t-button>
<t-button size="large" variant="outline" theme="primary" bind:tap="showVerticalText" block>带竖向图标</t-button>
<t-button wx:if="{{!skylineRender}}" size="large" variant="outline" theme="primary" bind:tap="showLoading" block
>加载状态</t-button
>
</view>

```

**JS** (`javascript`):
```javascript
import SkylineBehavior from '@behaviors/skyline.js';

import Toast from 'tdesign-miniprogram/toast';

Component({
behaviors: [SkylineBehavior],

methods: {
showText() {
Toast({
context: this,
selector: '#t-toast',
message: '轻提示文字内容',
});
},

showMultiText() {
Toast({
context: this,
selector: '#t-toast',
message: '最多一行展示十个汉字宽度限制最多不超过三行文字',
});
},

showHorizontalText() {
Toast({
context: this,
selector: '#t-toast',
message: '带横向图标',
icon: 'check-circle',
});
},

showVerticalText() {
Toast({
context: this,
selector: '#t-toast',
message: '带竖向图标',
icon: 'check-circle',
direction: 'column',
});
},

showLoading() {
Toast({
context: this,
selector: '#t-toast',
message: '加载中...',
theme: 'loading',
direction: 'column',
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-toast": "tdesign-miniprogram/toast/toast",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

### 组件状态

**WXML** (`html`):
```html
<t-toast id="t-toast" />

<view class="box">
<t-button theme="primary" size="large" variant="outline" bind:tap="showSuccessToast" block>成功提示</t-button>
<t-button theme="primary" size="large" variant="outline" bind:tap="showWarningToast" block>警告提示</t-button>
<t-button theme="primary" size="large" variant="outline" bind:tap="showErrorToast" block>错误提示</t-button>
</view>

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';

Component({
methods: {
showSuccessToast() {
Toast({
context: this,
selector: '#t-toast',
message: '成功文案',
theme: 'success',
direction: 'column',
});
},

showWarningToast() {
Toast({
context: this,
selector: '#t-toast',
message: '警告文案',
theme: 'warning',
direction: 'column',
});
},

showErrorToast() {
Toast({
context: this,
selector: '#t-toast',
message: '错误文案',
theme: 'error',
direction: 'column',
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-toast": "tdesign-miniprogram/toast/toast",
"t-button": "tdesign-miniprogram/button/button"
}
}

```

### 显示遮罩

**WXML** (`html`):
```html
<t-toast id="t-toast" />

<view class="box">
<t-button theme="primary" size="large" variant="outline" bind:tap="handleToast" block>禁止滑动和点击</t-button>
</view>

```

**JS** (`javascript`):
```javascript
import Toast from 'tdesign-miniprogram/toast';

Component({
methods: {
handleToast() {
Toast({
context: this,
selector: '#t-toast',
message: '禁止滑动和点击',
direction: 'column',
duration: 3000,
preventScrollThrough: true,
icon: 'poweroff',
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

### 手动关闭

**WXML** (`html`):
```html
<t-toast id="t-toast" />

<view class="box">
<view class="toast-example">
<t-button theme="primary" size="large" variant="outline" bind:tap="handleShow">显示提示</t-button>
<t-button theme="primary" size="large" variant="outline" bind:tap="handleHide">关闭提示</t-button>
</view>
</view>

```

**JS** (`javascript`):
```javascript
import Toast, { hideToast } from 'tdesign-miniprogram/toast';

Component({
methods: {
handleShow() {
Toast({
context: this,
selector: '#t-toast',
duration: -1,
message: '轻提示文字内容',
});
},
handleHide() {
hideToast({
context: this,
selector: '#t-toast',
});
},
},
});

```

**CSS** (`css`):
```css
.toast-example {
text-align: center;
display: flex;
}

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"styleIsolation": "apply-shared",
"usingComponents": {
"t-toast": "tdesign-miniprogram/toast/toast"
}
}

```

## API

### ToastProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| direction | String | row | 图标排列方式。可选项：row/column | N |
| duration | Number | 2000 | 弹窗显示毫秒数 | N |
| icon | String / Object / Slot | - | 自定义图标。传入对象则透传至 Icon 组件。通用类型定义 | N |
| message | String / Slot | - | 弹窗显示文字。通用类型定义 | N |
| overlay-props | Object | - | 遮罩层属性，透传至 Overlay。TS 类型：`OverlayProps `，Overlay API Documents。详细类型定义 | N |
| placement | String | middle | 弹窗展示位置。可选项： top/middle/bottom | N |
| prevent-scroll-through | Boolean | false | 防止滚动穿透，即不允许点击和滚动 | N |
| show-overlay | Boolean | false | 是否显示遮罩层 | N |
| theme | String | - | 提示类型。可选项：loading/success/warning/error | N |
| using-custom-navbar | Boolean | false | 是否使用了自定义导航栏 | N |

### ToastEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| close | - | 轻提示隐藏的时候触发 |
| destroy | - | 轻提示销毁的时候触发 |

### ToastExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-toast-bg-color | @mask-active | - |
| --td-toast-color | @text-color-anti | - |
| --td-toast-column-icon-size | 64rpx | - |
| --td-toast-max-width | 370rpx | - |
| --td-toast-radius | @radius-default | - |
| --td-toast-row-icon-size | 48rpx | - |

---

# [tree-select]

# TreeSelect 树形选择器

## 示例

该组件于 0.32.0 版本上线，请留意版本。
## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-tree-select": "tdesign-miniprogram/tree-select/tree-select"
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/1zElDNmq8v5G)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 组件类型

#### 基础树形选择

**WXML** (`html`):
```html
<t-tree-select options="{{options}}" value="{{value}}" bind:change="onChange" />

```

**JS** (`javascript`):
```javascript
const chineseNumber = '一二三四五六七八九十'.split('');

const generateTree = function (deep = 0, count = 10, prefix) {
const ans = [];

for (let i = 0; i < count; i += 1) {
const value = prefix ? `${prefix}-${i}` : `${i}`;
const rect = {
label: `选项${chineseNumber[i]}`,
value,
};

if (deep > 0) {
rect.children = generateTree(deep - 1, 10, value);
}
ans.push(rect);
}

return ans;
};

Component({
data: {
options: generateTree(1),
value: ['5', '5-5'],
},

methods: {
onChange(e) {
this.setData({
value: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tree-select": "tdesign-miniprogram/tree-select/tree-select"
}
}

```

#### 多选树形选择

**WXML** (`html`):
```html
<t-tree-select options="{{options}}" value="{{value}}" multiple bind:change="onChange" />

```

**JS** (`javascript`):
```javascript
const chineseNumber = '一二三四五六七八九十'.split('');

const generateTree = function (deep = 0, count = 10, prefix) {
const ans = [];

for (let i = 0; i < count; i += 1) {
const value = prefix ? `${prefix}-${i}` : `${i}`;
const rect = {
label: `选项${chineseNumber[i]}`,
value,
};

if (deep > 0) {
rect.children = generateTree(deep - 1, 10, value);
}
ans.push(rect);
}

return ans;
};

Component({
data: {
options: generateTree(1),
value: ['5', ['5-0', '5-1']],
},

methods: {
onChange(e) {
this.setData({
value: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tree-select": "tdesign-miniprogram/tree-select/tree-select"
}
}

```

### 组件状态

#### 三级树形选择

**WXML** (`html`):
```html
<t-tree-select options="{{options}}" value="{{value}}" bind:change="onChange" />

```

**JS** (`javascript`):
```javascript
const areaList = {
provinces: {
110000: '北京市',
440000: '广东省',
},
cities: {
110100: '北京市',
440100: '广州市',
440200: '韶关市',
440300: '深圳市',
440400: '珠海市',
440500: '汕头市',
440600: '佛山市',
},
counties: {
110101: '东城区',
110102: '西城区',
110105: '朝阳区',
110106: '丰台区',
110107: '石景山区',
110108: '海淀区',
110109: '门头沟区',
110111: '房山区',
110112: '通州区',
110113: '顺义区',
110114: '昌平区',
110115: '大兴区',
110116: '怀柔区',
110117: '平谷区',
110118: '密云区',
110119: '延庆区',
440103: '荔湾区',
440104: '越秀区',
440105: '海珠区',
440106: '天河区',
440111: '白云区',
440112: '黄埔区',
440113: '番禺区',
440114: '花都区',
440115: '南沙区',
440117: '从化区',
440118: '增城区',
440203: '武江区',
440204: '浈江区',
440205: '曲江区',
440222: '始兴县',
440224: '仁化县',
440229: '翁源县',
440232: '乳源瑶族自治县',
440233: '新丰县',
440281: '乐昌市',
440282: '南雄市',
440303: '罗湖区',
440304: '福田区',
440305: '南山区',
440306: '宝安区',
440307: '龙岗区',
440308: '盐田区',
440309: '龙华区',
440310: '坪山区',
440311: '光明区',
440402: '香洲区',
440403: '斗门区',
440404: '金湾区',
440507: '龙湖区',
440511: '金平区',
440512: '濠江区',
440513: '潮阳区',
440514: '潮南区',
440515: '澄海区',
440523: '南澳县',
440604: '禅城区',
440605: '南海区',
440606: '顺德区',
440607: '三水区',
440608: '高明区',
},
};

const generateTree = () => {
const { provinces, cities, counties } = areaList;
const options = [];
const eachObj = (obj, cb) => Object.keys(obj).forEach(cb);
const match = (v1, v2, base) => parseInt(v1 / base, 10) === parseInt(v2 / base, 10);

eachObj(provinces, (prov) => {
const cityList = [];

eachObj(cities, (city) => {
const countyList = [];

if (match(city, prov, 10000)) {
eachObj(counties, (county) => {
if (match(county, city, 100)) {
countyList.push({
label: counties[county],
value: county,
});
}
});
cityList.push({
label: cities[city],
value: city,
children: countyList,
});
}
});

const item = {
label: provinces[prov],
value: prov,
children: cityList,
};

options.push(item);
});

return options;
};

Component({
data: {
options: generateTree(),
value: ['110000', '110100', '110101'],
},

methods: {
onChange(e) {
this.setData({
value: e.detail.value,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-tree-select": "tdesign-miniprogram/tree-select/tree-select"
}
}

```

## API

### TreeSelectProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| custom-value | String / Number / Array | - | 自定义选中值，优先级高于`value`。TS 类型：`TreeSelectValue` | N |
| height | String / Number | 336 | 高度，默认单位为 px | N |
| keys | Object | - | 用来定义`value / label / disabled / children`在`options`数据中对应的字段别名，示例：`{ value: 'key', label: 'name', children: 'list' }`。TS 类型：`TreeKeysType`。通用类型定义 | N |
| multiple | Boolean | false | 是否允许多选 | N |
| options | Array | [] | 选项。TS 类型：`Array<DataOption>` | N |
| value | String / Number / Array | - | 选中值。TS 类型：`TreeSelectValue``type TreeSelectValue = string \| number \| Array<TreeSelectValue>`。详细类型定义 | N |
| default-value | String / Number / Array | undefined | 选中值。非受控属性。TS 类型：`TreeSelectValue``type TreeSelectValue = string \| number \| Array<TreeSelectValue>`。详细类型定义 | N |

### TreeSelectEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| change | `(value: TreeSelectValue, level: TreeLevel) ` | 点击任何节点均会触发；level 代表当前点击的层级，0 代表最左侧，依次递进。详细类型定义。<br>`type TreeLevel = 0 \| 1 \| 2`<br> |

### TreeSelectExternalClasses

| 类名 | 描述 |
| --- | --- |
| t-class | 根节点样式类 |
| t-class-left-column | 左侧第一列样式类 |
| t-class-left-item | 左侧第一列子项样式类 |
| t-class-middle-item | 中间列子项样式类 |
| t-class-right-column | 右侧第一列样式类 |
| t-class-right-item | 右侧第一列子项样式类 |
| t-class-right-item-label | 右侧第一列子项标签样式类 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-tree-bg-color | @bg-color-container | - |
| --td-tree-colum-text-color | @text-color-primary | - |
| --td-tree-colum-width | 206rpx | - |
| --td-tree-item-active-color | @brand-color | - |
| --td-tree-item-disabled-color | @text-color-disabled | - |
| --td-tree-item-font-size | 32rpx | - |
| --td-tree-item-height | 112rpx | - |
| --td-tree-root-bg-color | @bg-color-secondarycontainer | - |

---

# [upload]

# Upload 上传

## 示例

## 引入

全局引入，在 miniprogram 根目录下的`app.json`中配置，局部引入，在需要引入的页面或组件的`index.json`中配置。

```json
"usingComponents": {
"t-upload": "tdesign-miniprogram/upload/upload",
}
```

## 代码演示

[在开发者工具中预览效果](https://developers.weixin.qq.com/s/uXEjPNm68y52)

> Tips: 请确保开发者工具为打开状态。导入开发者工具后，依次执行：npm i > 构建npm包 > 勾选 "将JS编译成ES5"

### 单选上传图片

图片上传有两种方式：

1 选择完所有图片之后，统一上传，因此选择完就直接展示

2 每次选择图片都上传，展示每次上传图片的进度

**WXML** (`html`):
```html
<view class="wrapper">
<t-upload
disabled
mediaType="{{['video','image']}}"
max="{{1}}"
files="{{fileList}}"
bind:add="handleAdd"
bind:remove="handleRemove"
>
</t-upload>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
fileList: [],
},
methods: {
handleAdd(e) {
const { fileList } = this.data;
const { files } = e.detail;

// 方法1：选择完所有图片之后，统一上传，因此选择完就直接展示
this.setData({
fileList: [...fileList, ...files], // 此时设置了 fileList 之后才会展示选择的图片
});

// 方法2：每次选择图片都上传，展示每次上传图片的进度
// files.forEach(file => this.uploadFile(file))
},
onUpload(file) {
const { fileList } = this.data;

this.setData({
fileList: [...fileList, { ...file, status: 'loading' }],
});
const { length } = fileList;

const task = wx.uploadFile({
url: 'https://example.weixin.qq.com/upload', // 仅为示例，非真实的接口地址
filePath: file.url,
name: 'file',
formData: { user: 'test' },
success: () => {
this.setData({
[`fileList[${length}].status`]: 'done',
});
},
});
task.onProgressUpdate((res) => {
this.setData({
[`fileList[${length}].percent`]: res.progress,
});
});
},
handleRemove(e) {
const { index } = e.detail;
const { fileList } = this.data;

fileList.splice(index, 1);
this.setData({
fileList,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-upload": "tdesign-miniprogram/upload/upload"
}
}

```

### 多选上传图片

**WXML** (`html`):
```html
<view class="wrapper">
<t-upload
disabled
media-type="{{['video','image']}}"
files="{{originFiles}}"
gridConfig="{{gridConfig}}"
removeBtn="{{false}}"
bind:success="handleSuccess"
bind:remove="handleRemove"
bind:click="handleClick"
bind:sort-end="handleSortEnd"
/>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
originFiles: [
{
url: 'https://tdesign.gtimg.com/mobile/demos/example4.png',
name: 'uploaded1.png',
type: 'image',
removeBtn: true,
},
{
url: 'https://tdesign.gtimg.com/mobile/demos/example6.png',
name: 'uploaded2.png',
type: 'image',
removeBtn: true,
},
{
url: 'https://tdesign.gtimg.com/mobile/demos/example5.png',
name: 'uploaded3.png',
type: 'image',
removeBtn: true,
},
],
gridConfig: {
column: 4,
width: 160,
height: 160,
},
config: {
count: 1,
},
},
methods: {
handleSuccess(e) {
const { files } = e.detail;
this.setData({
originFiles: files,
});
},
handleRemove(e) {
const { index } = e.detail;
const { originFiles } = this.data;
originFiles.splice(index, 1);
this.setData({
originFiles,
});
},
handleClick(e) {
console.log(e.detail.file);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-upload": "tdesign-miniprogram/upload/upload"
}
}

```

### 长按拖拽排序图片

**WXML** (`html`):
```html
<view class="wrapper">
<t-upload
draggable
disabled
media-type="{{['video','image']}}"
files="{{originFiles}}"
gridConfig="{{gridConfig}}"
bind:success="handleSuccess"
bind:remove="handleRemove"
bind:click="handleClick"
bind:drop="handleDrop"
/>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
originFiles: [
{
url: 'https://tdesign.gtimg.com/mobile/demos/example4.png',
name: 'uploaded1.png',
type: 'image',
},
{
url: 'https://tdesign.gtimg.com/mobile/demos/example6.png',
name: 'uploaded2.png',
type: 'image',
},
{
url: 'https://tdesign.gtimg.com/mobile/demos/example5.png',
name: 'uploaded3.png',
type: 'image',
},
],
gridConfig: {
column: 4,
width: 160,
height: 160,
},
config: {
count: 1,
},
},
methods: {
handleSuccess(e) {
const { files } = e.detail;
this.setData({
originFiles: files,
});
},
handleRemove(e) {
const { index } = e.detail;
const { originFiles } = this.data;
originFiles.splice(index, 1);
this.setData({
originFiles,
});
},
handleClick(e) {
console.log(e.detail.file);
},

handleDrop(e) {
const { files } = e.detail;
this.setData({
originFiles: files,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-upload": "tdesign-miniprogram/upload/upload"
}
}

```

### 加载状态

支持多种状态：`loading`、`reload`、`failed`；

其中 `loading` 还可以通过传入 `percent` 来区分是否展示进度。

**WXML** (`html`):
```html
<view class="wrapper">
<t-upload
disabled
media-type="{{['video','image']}}"
files="{{originFiles}}"
gridConfig="{{gridConfig}}"
bind:success="handleSuccess"
bind:remove="handleRemove"
bind:click="handleClick"
/>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
originFiles: [
{
url: 'https://tdesign.gtimg.com/mobile/demos/example4.png',
name: 'uploaded1.png',
type: 'image',
status: 'loading',
},
{
url: 'https://tdesign.gtimg.com/mobile/demos/example5.png',
name: 'uploaded2.png',
type: 'image',
percent: 68,
status: 'loading',
},
{
url: 'https://tdesign.gtimg.com/mobile/demos/example6.png',
name: 'uploaded3.png',
type: 'image',
status: 'reload',
},
{
url: 'https://tdesign.gtimg.com/mobile/demos/example5.png',
name: 'uploaded4.png',
type: 'image',
status: 'failed',
},
],
gridConfig: {
column: 4,
width: 160,
height: 160,
},
config: {
count: 1,
},
},
methods: {
handleSuccess(e) {
const { files } = e.detail;
this.setData({
originFiles: files,
});
},
handleRemove(e) {
const { index } = e.detail;
const { originFiles } = this.data;
originFiles.splice(index, 1);
this.setData({
originFiles,
});
},
handleClick(e) {
console.log(e.detail.file);
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-upload": "tdesign-miniprogram/upload/upload"
}
}

```

### 从聊天记录上选

使用 `wx.chooseMessageFile` 实现，需要基础版本库 `2.5.0+`

**WXML** (`html`):
```html
<view class="wrapper">
<t-upload
disabled
mediaType="{{['video','image']}}"
files="{{originFiles}}"
gridConfig="{{gridConfig}}"
config="{{config}}"
source="messageFile"
bind:success="handleSuccess"
bind:remove="handleRemove"
>
</t-upload>
</view>

```

**JS** (`javascript`):
```javascript
Component({
data: {
originFiles: [
{
url: 'https://tdesign.gtimg.com/mobile/demos/example4.png',
name: 'uploaded1.png',
type: 'image',
},
],
gridConfig: {
column: 4,
width: 160,
height: 160,
},
config: {
count: 1,
},
},
methods: {
handleSuccess(e) {
const { files } = e.detail;
this.setData({
originFiles: files,
});
},
handleRemove(e) {
const { index } = e.detail;
const { originFiles } = this.data;
originFiles.splice(index, 1);
this.setData({
originFiles,
});
},
},
});

```

**CSS** (`css`):
```css

```

**JSON** (`javascript`):
```javascript
{
"component": true,
"usingComponents": {
"t-upload": "tdesign-miniprogram/upload/upload"
}
}

```

## FAQ

### 为什么Upload外层使用display:flex时会造成组件样式混乱？

`Upload` 是基于 `TGrid` 宫格实现，当外层使用 `display: flex` ，子元素会默认加上 `flex-grow: 0`，造成 `Upload` 组件整体宽度不足。可以通过给 `Upload` 组件节点加上 `flex-grow: 1` 处理。

## API

### UploadProps

| 名称 | 类型 | 默认值 | 描述 | 必传 |
| --- | --- | --- | --- | --- |
| style | Object | - | 样式 | N |
| custom-style | Object | - | 样式，一般用于开启虚拟化组件节点场景 | N |
| add-btn | Boolean | true | 添加按钮 | N |
| add-content | String | - | 添加按钮内容 | N |
| allow-upload-duplicate-file | Boolean | false | `暂不支持`。是否允许重复上传相同文件名的文件 | N |
| config | Object | - | 图片上传配置，视频上传配置，文件上传配置等，包含图片尺寸、图片来源、视频来源、视频拍摄最长时间等。更多细节查看小程序官网。图片上传。视频上传。TS 类型：`UploadMpConfig``type UploadMpConfig = ImageConfig \| VideoConfig``interface ImageConfig { count?: number; sizeType?: Array<SizeTypeValues>; sourceType?: Array<SourceTypeValues> }``type SizeTypeValues = 'original' \| 'compressed'``type SourceTypeValues = 'album' \| 'camera'``interface VideoConfig { sourceType?: Array<SourceTypeValues>; compressed?: boolean; maxDuration?: number; camera?: 'back' \| 'front' }`。详细类型定义 | N |
| disabled | Boolean | undefined | 是否禁用组件 | N |
| draggable | Boolean / Object | - | 是否支持拖拽排序。长按时是否振动，碰撞时是否振动。示例一：`true`。示例二：`{ vibrate: true, collisionVibrate: true }`。TS 类型：`boolean \| {vibrate?: boolean; collisionVibrate?: boolean}` | N |
| files | Array | - | 已上传文件列表。TS 类型：`Array<UploadFile>``interface UploadFile { url: string; name?: string; size?: number; type?: 'image' \| 'video'; percent?: number; status: 'loading' \| 'reload' \| 'failed' \| 'done' }`。详细类型定义 | N |
| default-files | Array | undefined | 已上传文件列表。非受控属性。TS 类型：`Array<UploadFile>``interface UploadFile { url: string; name?: string; size?: number; type?: 'image' \| 'video'; percent?: number; status: 'loading' \| 'reload' \| 'failed' \| 'done' }`。详细类型定义 | N |
| grid-config | Object | - | upload组件每行上传图片列数以及图片的宽度和高度。TS 类型：`{column?: number;  width?: number; height?: number;}` | N |
| gutter | Number | 16 | 预览窗格的`gutter`大小，单位 rpx | N |
| image-props | Object | - | 透传 Image 组件全部属性。TS 类型：`ImageProps`，Image API Documents。详细类型定义 | N |
| max | Number | 0 | 用于控制文件上传数量，值为 0 则不限制 | N |
| media-type | Array | ['image', 'video'] | 支持上传的文件类型，图片或视频。TS 类型：`Array<MediaType>``type MediaType = 'image' \| 'video'`。详细类型定义 | N |
| preview | Boolean | true | `1.9.5`。是否支持图片预览，文件没有预览 | N |
| remove-btn | Boolean | true | 移除按钮 | N |
| request-method | Function | - | 自定义上传方法 | N |
| size-limit | Number / Object | - | 图片文件大小限制，默认单位 KB。可选单位有：`'B' \| 'KB' \| 'MB' \| 'GB'`。示例一：`1000`。示例二：`{ size: 2, unit: 'MB', message: '图片大小不超过 {sizeLimit} MB' }`。TS 类型：`number \| SizeLimitObj``interface SizeLimitObj { size: number; unit: SizeUnit ; message?: string }``type SizeUnitArray = ['B', 'KB', 'MB', 'GB']``type SizeUnit = SizeUnitArray[number]`。详细类型定义 | N |
| source | String | media | 来源。可选项：media/messageFile | N |
| transition | Object |  | 拖拽位置移动时的过渡参数,`duration`单位为ms。TS 类型：`Transition``interface Transition { backTransition?: boolean, duration?: number, timingFunction?: string }`。详细类型定义 | N |

### UploadEvents

| 名称 | 参数 | 描述 |
| --- | --- | --- |
| add | `(files: MediaContext)` | 选择后触发，仅包含本次选择的照片；`url`表示选定视频的临时文件路径 (本地路径)。`duration`表示选定视频的时间长度。`size`选定视频的数据量大小。更多描述参考 wx.chooseMedia 小程序官网描述。详细类型定义。<br>`type MediaContext = VideoContext[] \| ImageContext[]`<br><br>`interface VideoContext { name?: string; type?: string; url?: string; duration?: number; size?: number; width?: number; height?: number; thumb: string; progress: number }`<br><br>`interface ImageContext { name: string; type: string; url: string;  size: number; width: number; height: number; progress: number  }`<br> |
| click | `(index: number; file: VideoContext \| ImageContext)` | 点击已选文件时触发；常用于重新上传 |
| complete | - | 上传成功或失败后触发 |
| drop | `(files: MediaContext) ` | 拖拽结束后触发，包含所有上传的文件（拖拽后的文件顺序）；`url`表示选定视频的临时文件路径 (本地路径)。`duration`表示选定视频的时间长度。`size`选定视频的数据量大小。更多描述参考 wx.chooseMedia 小程序官网描述。详细类型定义。<br>`type MediaContext = VideoContext[] \| ImageContext[]; interface VideoContext { name?: string; type?: string; url?: string; duration?: number; size?: number; width?: number; height?: number; thumb: string; progress: number }; interface ImageContext { name: string; type: string; url: string;  size: number; width: number; height: number; progress: number}`<br> |
| fail | - | 上传失败后触发 |
| remove | `(index: number; file: UploadFile)` | 移除文件时触发 |
| select-change | `(files: MediaContext[]; currentSelectedFiles: MediaContext[])` | 选择文件或图片之后，上传之前，触发该事件。<br>`files`表示之前已经上传完成的文件列表。<br>`currentSelectedFiles`表示本次上传选中的文件列表 |
| success | `(files: MediaContext)` | 上传成功后触发，包含所有上传的文件；`url`表示选定视频的临时文件路径 (本地路径)。`duration`表示选定视频的时间长度。`size`选定视频的数据量大小。更多描述参考 wx.chooseMedia 小程序官网描述。详细类型定义。<br>`type MediaContext = VideoContext[] \| ImageContext[]`<br><br>`interface VideoContext { name?: string; type?: string; url?: string; duration?: number; size?: number; width?: number; height?: number; thumb: string; progress: number }`<br><br>`interface ImageContext { name: string; type: string; url: string;  size: number; width: number; height: number; progress: number  }`<br> |

### UploadSlots

| 名称 | 描述 |
| --- | --- |
| add-content | 自定义`add-content`显示内容 |

### CSSVariables

组件提供了下列 CSS 变量，可用于自定义样式。

| 名称 | 默认值 | 描述 |
| --- | --- | --- |
| --td-upload-add-bg-color | @bg-color-secondarycontainer | - |
| --td-upload-add-color | @text-color-placeholder | - |
| --td-upload-add-disabled-bg-color | @bg-color-component-disabled | - |
| --td-upload-add-icon-disabled-color | @text-color-disabled | - |
| --td-upload-add-icon-size | 56rpx | - |
| --td-upload-disabled-mask | rgba(0, 0.6) | - |
| --td-upload-drag-transition-duration | --td-upload-drag-transition-duration | - |
| --td-upload-drag-transition-timing-function | --td-upload-drag-transition-timing-function | - |
| --td-upload-drag-z-index | 999 | - |
| --td-upload-radius | @radius-default | - |