# ML 工程参考（scikit-learn / PyTorch）

## scikit-learn：先管道，后调参
```python
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score

pre = ColumnTransformer([("num", StandardScaler(), ["age", "income"])])
pipe = Pipeline([("pre", pre), ("clf", RandomForestClassifier(n_estimators=200))])

X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)
pipe.fit(X_tr, y_tr)
print("cv:", cross_val_score(pipe, X_tr, y_tr, cv=5).mean())
print("test:", pipe.score(X_te, y_te))
```
- **数据泄漏红线**：`ColumnTransformer` / `StandardScaler` 必须放在 Pipeline 内，永远不要在 `fit` 前对整个 X 做 `fit_transform` 再切分
- 类别不平衡 → `class_weight="balanced"` 或 `imblearn`

## PyTorch：训练循环模板
```python
import torch
from torch import nn, optim
from torch.utils.data import DataLoader

def train(model, loader, epochs=10, lr=3e-4):
    opt = optim.AdamW(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    for ep in range(epochs):
        model.train(); tot = 0
        for xb, yb in loader:
            opt.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward(); opt.step()
            tot += loss.item()
        print(f"ep{ep} loss={tot/len(loader):.4f}")

# 设备无关：有卡用卡，无卡用 CPU
device = "cuda" if torch.cuda.is_available() else "cpu"
model = MyNet().to(device)
```

## 推理服务化（FastAPI）
- 模型**只加载一次**（模块级 / 启动钩子），不要每次请求 reload
- 输入做 schema 校验（Pydantic），输出做数值裁剪防 NaN
- 大模型走 batch + `torch.inference_mode()` 省显存
- 可选导出 ONNX 用 `onnxruntime` 推理，吞吐更高、依赖更轻

## 常见坑
- `CUDA out of memory` → 降 batch、开 `torch.cuda.empty_cache()`、用 `amp` 混合精度
- 训练/推理结果不一致 → 推理时 `model.eval()` + `torch.no_grad()`
- 标签错位 → `Dataset` 返回 `(x, y)` 顺序与 `collate_fn` 对齐
- 特征漂移 → 线上特征工程必须与训练完全一致（同一 `pre` 对象）
