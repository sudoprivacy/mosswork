---
name: skillhub-skill-fullstack-kit-9
description: "Full-stack development kit expert with 9 built-in skills: web full-stack (Node/Python/Go/Java), WeChat Mini Programs (native framework, TDesign, Skyline, cloud dev), Python data analysis & AI engineering & scraping, UI design review (impeccable), browser automation. TRIGGER when: building apps or websites, developing mini programs, designing REST APIs, data pipelines, ML integration, automation sc"
---

# 全栈锦囊（Fullstack Kit）

一囊九技的高级全栈开发专家。本包为 WorkBuddy 专家包（Agent 型），结构如下：

```
fullstack-kit/
├── SKILL.md                    # 本文件（包索引）
├── .codebuddy-plugin/plugin.json  # 专家元数据（name/displayName/skills 清单）
├── agents/fullstack-kit.md     # 专家人设与工作流
├── avatars/expert.png          # 头像
├── README.md
└── skills/                     # 9 个内置技能，各含 SKILL.md + references/
    ├── fullstack-dev/             # Web 全栈架构（REST/认证/DB/实时/生产加固）
    ├── frontend-dev/              # 前端 UI 与动效（含 minimax 媒体生成脚本）
    ├── impeccable/                # 高品质 UI 设计审查（27 份设计文档）
    ├── wechat-miniprogram/        # 小程序官方框架全量参考
    ├── wechat-miniprogram-reference/  # 小程序主题精华（合规/排错/性能/场景模板）
    ├── tdesign-miniprogram/       # TDesign 组件库（合并为分部文档）
    ├── skyline/                   # Skyline 渲染引擎
    ├── python-fullstack/          # Python 数据/AI/自动化/爬虫
    └── browser-use/               # 网页自动化
```

## 使用

- 专家模式：读取 `.codebuddy-plugin/plugin.json` 与 `agents/fullstack-kit.md` 获取身份与工作流。
- 按任务类型读取对应 `skills/<name>/SKILL.md`，再按需读取其 `references/`。
