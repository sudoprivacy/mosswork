# 世舶科技招投标 API 接入契约 v1.0

> 本契约依据用户提供的《接口文档》v1.0（生成时间 2026-10-28 15:29:35，共 31 个接口）提炼，供运行时确认真实接口路径、字段大小写、鉴权位置与分页约束使用。本文件不包含真实 API Key、带签名下载链接或未经证实的项目结果。文档已读取不等于接口实测成功，实际调用须以真实响应为准。

## 1. 服务信息

- 生产环境基础地址：`https://gate.gov-bid.com/outer-gateway`
- 鉴权方式：每个请求 URL 均需携带参数 `key`（即 `BBIAO_API_KEY`）
- 数据来源：世舶科技招投标数据 API

## 2. 常用接口路径与用途

| 用途 | HTTP 接口路径 | 说明 |
| --- | --- | --- |
| 项目检索（正式） | `POST /outer-gateway/bid/searchProjectApi` | 搜索招标、中标、采购意向等项目，支持精确采购类别、编码地区与高级字段 |
| 项目检索（AI 轻量） | `POST /outer-gateway/bid/SearchProjectForAI` | 面向 AI 客户端的轻量项目搜索，供普通查询优先使用 |
| 合同搜索 | `POST /outer-gateway/bid/searchProjectContactApi` | 搜索合同公告数据 |
| 结构化详情 | `POST /outer-gateway/bid/getZTBStructreDetail` | 获取招中标信息结构化详情 |
| 正文详情 | `POST /outer-gateway/bid/getZTBProjectDetail` | 获取招中标信息正文详情 |
| 附件列表 | `POST /outer-gateway/bid/getZTBProjectFiles` | 获取招中标信息附件列表 |
| 原始采集地址 | `POST /outer-gateway/bid/getCollectUrl` | 获取公告原始采集地址 |
| 自然语言改写 | `POST /outer-gateway/bid/aiSearchSubmitPolling` | 将自然语言查询转换为结构化搜索条件（对应 `rewrite-query`） |
| 行业推理 | `POST /outer-gateway/bid/industryReasoning` | 根据业务描述推理行业编码 |

> 上述接口路径、字段和分页规则以接口文档为准，不得自行杜撰。`searchProjectApi` 与 `SearchProjectForAI` 字段不能互串。

## 3. Agent 列表接口（SearchProjectForAI）要点

- 支持 `className` 以英文逗号组合“招标信息,中标信息”（需求适配且权限允许时优先一次统一查询，不默认拆成两个请求）。
- 支持 `areaName`（地区名称）、`startDate`、`endDate`。
- 分页参数为 `pageId` 与 `pageNumber`。
- 约束：`pageNumber` 不要超过 20；`pageNumber=0` 只返回数量，不是免费或无限返回开关，不能据此把下一次列表请求设为 0。
- 日期：搜索类命令支持 `yyyy-MM-dd` 或 `yyyy-MM-dd HH:mm:ss`；详情类命令的发布时间必须为完整格式 `yyyy-MM-dd HH:mm:ss`。

## 4. searchProjectApi 字段大小写说明

保留接口文档原始大小写与历史拼写，如 `inCludeKW`、`OrderByType` 与 `orderByType`、`proviceCodeList` 等，不能改写。两接口不推定等价或自动切换，实际切换会消耗额度。

## 5. 调用规范

- 未配置密钥时，按 `SKILL.md` 的「开通方式」引导用户获取密钥，不自动注册、猜测或编造密钥。
- 禁止在命令参数、代码、示例、日志、完整请求 URL 或异常输出中写入真实 Key。
- 默认只请求第 1 页；用户明确续页/全量时按页码或游标协议执行，并做跨页去重。
- 只读临时失败最多补试 1 次并遵循服务端退避；鉴权、额度、参数错误直接说明并停止，禁止反复重试。

## 6. 校验与验收分层

- 本地资料制作完成 ≠ 平台已上传/安装成功/端到端可用；未发起真实业务请求前不得称“已查询到商机”。
- 分别记录：Skill 被加载、检测到凭据、实际发出业务请求、HTTP 响应、业务结果解析、目标筛选与分页核验、目标平台安装调用。
- 业务数据请求为 0 次时明确写“未发出业务查询请求”，不得宣称已查询、暂无商机或全部数据为空。
