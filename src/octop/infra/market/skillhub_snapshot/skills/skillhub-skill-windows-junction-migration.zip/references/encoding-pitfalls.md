# Encoding Pitfalls: Chinese Paths in Windows Batch / Admin cmd

This document records every approach that FAILED while trying to run a migration
`.bat`/`.ps1` whose target path contained Chinese characters (`E:\软件\workbuudy\.workbuddy`),
and the single approach that worked. Read it before debugging any stubborn Windows
batch task involving non-ASCII paths.

## Symptom that signals "encoding problem"

The black cmd window prints lines like:

```
'local' is not recognized as an internal or external command
'WorkBuddy' is not recognized ...
'(1)' is not recognized ...
```

i.e. the script's own text (comments, menu, even `@echo off`) is being executed as
commands. Root cause: `cmd` failed to decode the file, so it never saw `@echo off`,
and treated every line as a command.

## Approaches tried, and why each failed

| # | Approach | Result |
|---|----------|--------|
| 1 | PowerShell `.ps1`, UTF-8 no BOM, Chinese comments + path | PowerShell 5.1 read the file as the wrong codepage → Chinese became mojibake → syntax errors on every line. |
| 2 | `.bat` with Chinese comments/strings (UTF-8) | Admin cmd mis-parsed; `@echo off` never took effect; every line echoed as a command. |
| 3 | `.bat` with `chcp 65001` (UTF-8) at top | Still failed — `chcp` in admin cmd does not make Chinese `.bat` parsing reliable. |
| 4 | `.bat` with `chcp 936` (GBK) | Closer, but any stray non-ASCII byte (even in a comment) breaks parsing. Brittle. |
| 5 | `.bat` with auto-elevation `powershell Start-Process -Verb RunAs` re-launching itself | The Chinese path in the re-launched elevated process broke again — the new cmd instance re-parsed the file and failed. |
| 6 | `.bat` written in GBK via `iconv -f UTF-8 -t GBK` | Stray non-ASCII bytes still crept in (hidden chars), parsing failed intermittently. |
| 7 | `.bat` that scans `E:\*` for the Chinese folder via `for /d %%D in ("E:\*")` | Admin cmd could not enumerate the Chinese-named directory; `DST` came back empty. |
| 8 | `.bat` using `%%~sI` to get the 8.3 short path of `E:\软件\workbuudy` | 8.3 short names were disabled on the volume → `%%~sI` returned empty/garbage. |
| 9 | `.bat` reading target from `_migrate_target.txt` written in **UTF-8** | `set /p` read it in GBK → `软件` became `杞欢` (mojibake) → `if exist` failed. |
| 10 | **`.bat` reading target from `_migrate_target.txt` written in **GBK**** + `.bat` 100% pure ASCII | **WORKED.** Target displayed correctly, `if exist` passed, junction created. |

## The winning pattern (steps 9→10 refined)

1. Write the migration logic as a `.bat` that contains **zero** Chinese/non-ASCII bytes.
   Verify with:
   ```python
   data = open("migrate.bat","rb").read()
   assert sum(1 for b in data if b > 127) == 0
   ```
2. Put the Chinese destination path in a SEPARATE file encoded as **GBK**:
   ```python
   open("migrate_config.txt","w",encoding="gbk").write(src + "\n" + dst + "\n")
   ```
3. In the `.bat`, read it with `set /p DST=<migrate_config.txt` (admin cmd reads the
   file in the system codepage = GBK, so Chinese is correct).
4. Place the `.bat` at an **ASCII path** (e.g. `C:\Users\Administrator\migrate.bat`) and
   run it as Administrator. Use `%~dp0migrate_config.txt` so the config is found
   regardless of where the user moves the pair.

## Other lessons

- **The agent cannot run the final step itself.** The agent lives inside the app
  (e.g. WorkBuddy). Closing the app to free locked files also kills the agent. So the
  migration's final, destructive step must be performed by a script the *user* runs
  after closing the app — not by the agent.
- **Never copy+delete a live data dir.** If the app is running, log/session files are
  locked; a delete loop can partially wipe data. Prefer junction + rename-only backup.
- **Keep a `.bak`, never delete immediately.** Rename `SRC` → `SRC.bak`. Rollback is a
  single rename back. Only delete `.bak` after several days of verified clean operation.
- **Integrity gate before rename.** Compare file counts (`dir /s /b /a:-d | find /c`)
  and abort if the destination is incomplete (<80% of source). Prevents silent data loss.
