#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate an encoding-safe Windows directory-junction migration script.

WHY THIS EXISTS
---------------
Windows administrator `cmd.exe` cannot reliably parse a `.bat` file that contains ANY
Chinese / non-ASCII characters -- not UTF-8, not GBK, not even with `chcp`. The whole
file mis-parses (even `@echo off` fails, so every line is echoed as a command).

The only reliable pattern is:
  * the `.bat` is 100% pure ASCII (zero bytes > 127)
  * the Chinese destination path is fed in from an EXTERNAL file written in GBK,
    which admin cmd reads natively via `set /p VAR=<file`.

This generator emits exactly that pair, so a user can relocate an app's data folder
(even one under a Chinese path) by running the generated `.bat` as Administrator after
closing the app.

USAGE
-----
    python gen_migration_bat.py --src "C:\\Users\\Administrator\\.workbuddy" \
                                --dst "E:\\软件\\workbuudy\\.workbuddy" \
                                --out "C:\\Users\\Administrator\\migrate.bat"

Outputs (next to --out):
    <out>.bat            pure-ASCII migration script
    <out_dir>\\migrate_config.txt   GBK-encoded: line1=SRC, line2=DST

The generated .bat performs, in order:
    admin check -> optional app-running warning -> final robocopy /PURGE sync ->
    integrity check (DST >= 80% of SRC file count) -> rename SRC to SRC.bak ->
    mklink /J SRC DST -> write/delete probe through junction -> auto-rollback on failure.
"""

import argparse
import os
import sys


# ---------------------------------------------------------------------------
# The .bat TEMPLATE. MUST stay 100% pure ASCII. No Chinese anywhere.
# SRC and DST are NOT embedded here; they are read from migrate_config.txt (GBK).
# ---------------------------------------------------------------------------
BAT_TEMPLATE = r'''@echo off
setlocal enabledelayedexpansion

:: Config file sits next to this .bat (GBK encoded: line1=SRC, line2=DST)
set "CFGFILE=%~dp0migrate_config.txt"

:: Read SRC (line 1) and DST (line 2) from the GBK config file
set /p SRC=<%CFGFILE%
for /f "usebackq skip=1 delims=" %%A in ("%CFGFILE%") do set "DST=%%A" & goto :cfgdone
:cfgdone

set "BAK=%SRC%.bak"

echo ===== MIGRATION START =====
echo SRC : %SRC%
echo DST : %DST%
echo BAK : %BAK%

:: Step 0: admin check
net session >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Administrator rights required. Right-click and Run as administrator.
    pause
    exit /b 1
)
echo [OK] Admin OK.

:: Step 1: warn if the app/target process is still running
tasklist /FI "IMAGENAME eq WorkBuddy.exe" /NH 2>nul | find /i "WorkBuddy" >nul 2>&1
if not errorlevel 1 (
    echo [WARNING] WorkBuddy.exe appears to still be running.
    set /p FORCE="Force anyway? Type YES: "
    if /i not "!FORCE!"=="YES" (
        echo Aborted. Close the app first.
        pause
        exit /b 0
    )
)

:: Step 2: target must exist
if not exist "%DST%" (
    echo [ERROR] Destination not found: %DST%
    pause
    exit /b 1
)
echo [OK] Destination found.

echo.
echo This will:
echo   1. Final-sync %SRC% to %DST%
echo   2. Rename %SRC% to %BAK%  [backup, NOT deleted]
echo   3. Create junction %SRC% -^> %DST%
echo.
set /p CONFIRM="Type YES to continue: "
if /i not "!CONFIRM!"=="YES" (
    echo Aborted.
    pause
    exit /b 0
)

:: Step 3: final sync (close the gap from files written since the pre-mirror)
echo.
echo [1/4] Syncing...
robocopy "%SRC%" "%DST%" /E /PURGE /R:2 /W:2 /MT:8 /NFL /NDL /NJH /XJ
if errorlevel 8 (
    echo [ERROR] robocopy failed (code %errorlevel%).
    pause
    exit /b 1
)
echo [OK] Sync done.

:: Step 4: integrity check (DST file count must be >= 80%% of SRC)
echo [2/4] Integrity check...
for /f %%a in ('dir /s /b /a:-d "%SRC%" 2^>nul ^| find /c /v ""') do set CCOUNT=%%a
for /f %%a in ('dir /s /b /a:-d "%DST%" 2^>nul ^| find /c /v ""') do set ECOUNT=%%a
echo     SRC ~%CCOUNT%  DST ~%ECOUNT%
set /a THRESH=%CCOUNT% * 80 / 100
if %ECOUNT% LSS %THRESH% (
    echo [ERROR] Destination incomplete (%ECOUNT% ^< %THRESH%). Aborting to avoid data loss.
    pause
    exit /b 1
)
echo [OK] Integrity OK.

:: Step 5: backup (rename only)
echo [3/4] Backing up...
if exist "%BAK%" (
    echo [ERROR] Backup %BAK% already exists. Delete it first.
    pause
    exit /b 1
)
ren "%SRC%" ".workbuddy.bak"
if errorlevel 1 (
    echo [ERROR] Rename failed. Is the app still running? Close it and retry.
    pause
    exit /b 1
)
echo [OK] Backed up.

:: Step 6: create junction + probe, with auto-rollback
echo [4/4] Creating junction...
mklink /J "%SRC%" "%DST%"
if errorlevel 1 (
    echo [ERROR] Junction failed. Rolling back...
    ren "%BAK%" ".workbuddy"
    echo [OK] Rolled back.
    pause
    exit /b 1
)

echo Verifying junction (read/write probe)...
echo ok > "%SRC%\_probe.tmp"
if errorlevel 1 (
    echo [ERROR] Write test failed. Rolling back...
    rmdir "%SRC%"
    ren "%BAK%" ".workbuddy"
    pause
    exit /b 1
)
del /f /q "%SRC%\_probe.tmp" >nul 2>&1

echo.
echo ============ SUCCESS ============
echo.
echo   Backup : %BAK%
echo   Junction active: %SRC% -^> %DST%
echo   Start the app to verify. Delete the .bak only after a few clean days.
echo.
pause
exit /b 0
'''


def main():
    ap = argparse.ArgumentParser(description="Generate encoding-safe Windows junction migration script.")
    ap.add_argument("--src", required=True, help="Live path the app uses, e.g. C:\\Users\\Administrator\\.workbuddy")
    ap.add_argument("--dst", required=True, help="New location, e.g. E:\\软件\\workbuudy\\.workbuddy")
    ap.add_argument("--out", default=r"C:\Users\Administrator\migrate.bat",
                    help="Output .bat path (keep it ASCII / no Chinese). Default: C:\\Users\\Administrator\\migrate.bat")
    args = ap.parse_args()

    out_bat = os.path.abspath(args.out)
    out_dir = os.path.dirname(out_bat)

    # 1) Write the config file in GBK (line1=SRC, line2=DST)
    cfg_path = os.path.join(out_dir, "migrate_config.txt")
    try:
        with open(cfg_path, "w", encoding="gbk") as f:
            f.write(args.src + "\n")
            f.write(args.dst + "\n")
    except UnicodeEncodeError:
        sys.exit("[FATAL] SRC/DST contain characters not representable in GBK. "
                 "Use a destination whose path is encodable in GBK (most Chinese paths are).")

    # 2) Write the pure-ASCII .bat
    try:
        with open(out_bat, "w", encoding="ascii", newline="\r\n") as f:
            f.write(BAT_TEMPLATE)
    except UnicodeEncodeError:
        sys.exit("[FATAL] Internal error: BAT_TEMPLATE is not pure ASCII.")

    # 3) Verify the .bat is genuinely pure ASCII
    with open(out_bat, "rb") as f:
        data = f.read()
    non_ascii = sum(1 for b in data if b > 127)
    if non_ascii != 0:
        sys.exit(f"[FATAL] Generated .bat has {non_ascii} non-ASCII bytes. Aborting.")

    print(f"[OK] Wrote pure-ASCII script : {out_bat}")
    print(f"[OK] Wrote GBK config file   : {cfg_path}")
    print(f"[OK] .bat verified pure ASCII (non-ASCII bytes = 0)")
    print()
    print("Next:")
    print("  1. Fully close the app (including system tray).")
    print(f"  2. Right-click {out_bat} -> Run as administrator.")
    print("  3. Type YES when prompted.")
    print("  4. After SUCCESS, start the app and verify; delete the .bak after a few days.")


if __name__ == "__main__":
    main()
