#!/usr/bin/env python3
"""
Unified Skill authorization helper.

The Skill instructions should call this file before running any protected
capability. The helper owns all local credential storage, WorkBuddy JWT binding,
and optional remote authorization checks.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Any


AUTH_OK = "AUTH_OK"
AUTH_REQUIRED = "AUTH_REQUIRED"
AUTH_INVALID = "AUTH_INVALID"
AUTH_BIND_OK = "AUTH_BIND_OK"
AUTH_ACTION_REQUIRED = "AUTH_ACTION_REQUIRED"

# Backward-compatible signal names used by older Skill instructions.
SIGNAL_MISSING = "CREDENTIALS_MISSING"
SIGNAL_INVALID = "CREDENTIALS_INVALID"


SKILL_ROOT = Path(__file__).resolve().parents[1]


def load_skill_meta() -> dict[str, Any]:
    """Load package metadata when available."""
    for name in ("_meta.json", "_skillhub_meta.json"):
        path = SKILL_ROOT / name
        if not path.exists():
            continue
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def detect_default_skill_code() -> str:
    """Return platform skillCode from _meta.json.slug, then fall back to folder name."""
    meta = load_skill_meta()
    slug = str(meta.get("slug", "")).strip()
    if slug:
        return slug
    return SKILL_ROOT.name


def safe_cache_name(skill_code: str) -> str:
    """Make a stable cache file name for a Skill code."""
    value = skill_code.strip() or "unknown-skill"
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value)
    return value.strip("._-") or "unknown-skill"


SKILL_CODE = os.environ.get("SKILL_CODE", detect_default_skill_code())
# 默认地址由后端当前环境的 SKILL_AUTH_API_BASE 注入，运行时仍可通过同名环境变量覆盖。
API_BASE_URL = os.environ.get(
    "SKILL_AUTH_API_BASE",
    "https://s.1100111.cn",
).rstrip("/")
BIND_URL = os.environ.get("SKILL_AUTH_BIND_URL",
                          f"{API_BASE_URL}/baitong_ai/api/skill/bind")
VERIFY_URL = os.environ.get("SKILL_AUTH_VERIFY_URL",
                            f"{API_BASE_URL}/baitong_ai/api/skill/verify")
CACHE_FILE = None

# Legacy path used by the first xxxx-search prototype. Kept as read fallback.
LEGACY_CACHE_FILE = Path.home() / ".workbuddy" / ".xxxx_search_credentials.json"


def cache_file_for(skill_code: str | None = None, agent: str = "workbuddy") -> Path:
    """Return the credential cache path for the requested Skill.

    Agent routing:
    - "workbuddy" → ~/.workbuddy/skill_auth/{skill}.json
    - "qwenwork"  → ~/.qwen/skill_auth/{skill}.json
    - anything else falls back as-is (backward-compat for unknown agents).
    """
    if CACHE_FILE is not None:
        return Path(CACHE_FILE)
    target_skill_code = skill_code or SKILL_CODE
    if agent == "qwenwork":
        root = Path.home() / ".qwenworkcn"
    else:
        root = Path.home() / ".workbuddy"
    return root / "skill_auth" / f"{safe_cache_name(target_skill_code)}.json"


def _now_ms() -> str:
    return str(int(time.time() * 1000))


def make_sign_headers(app_key: str, app_secret: str) -> dict[str, str]:
    """Build the platform signature headers."""
    timestamp = _now_ms()
    raw = app_key + timestamp + app_secret
    sign = hashlib.md5(raw.encode("utf-8")).hexdigest()
    return {
        "X-App-Key": app_key,
        "X-Timestamp": timestamp,
        "X-Sign": sign,
        "Content-Type": "application/json; charset=utf-8",
    }


def save_credentials(
    app_key: str,
    app_secret: str,
    *,
    workbuddy_sub: str = "",
    skill_code: str | None = None,
    mcp_token: str = "",
    mcp_url: str = "",
    agent: str = "workbuddy",
) -> None:
    """Save credentials for this Skill with user binding metadata.

    The cache file is routed by agent: workbuddy → ~/.workbuddy/, qwenwork → ~/.qwen/.
    """
    target_skill_code = skill_code or SKILL_CODE
    cache_file = cache_file_for(target_skill_code, agent=agent)
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "skill_code": target_skill_code,
        "app_key": app_key.strip(),
        "app_secret": app_secret.strip(),
        "mcp_token": (mcp_token or "").strip(),
        "mcp_url": (mcp_url or "").strip(),
        "workbuddy_sub": workbuddy_sub.strip(),
        "saved_at": int(time.time()),
    }
    cache_file.write_text(json.dumps(
        data, ensure_ascii=False, indent=2), encoding="utf-8")
    cache_file.chmod(stat.S_IRUSR | stat.S_IWUSR)
    print(f"[auth] credentials saved: {cache_file}")


def _read_cache_file(path: Path) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        raise ValueError("cache file is empty")
    data = json.loads(raw)
    if not str(data.get("app_key", "")).strip():
        raise ValueError("app_key is empty")
    if not str(data.get("app_secret", "")).strip():
        raise ValueError("app_secret is empty")
    return data


def load_credential_record(*, skill_code: str | None = None, agent: str = "") -> dict[str, Any]:
    """Load the full credential cache record."""
    target_skill_code = skill_code or SKILL_CODE
    # 默认从环境变量取 agent；未设置时回退 workbuddy（向后兼容）
    effective_agent = agent or os.environ.get("BT_SKILL_AGENT", "workbuddy").lower()
    cache_path = cache_file_for(target_skill_code, agent=effective_agent)
    if not cache_path.exists() and SKILL_CODE == "xxxx-search" and LEGACY_CACHE_FILE.exists():
        cache_path = LEGACY_CACHE_FILE

    if not cache_path.exists():
        print(AUTH_REQUIRED)
        print(SIGNAL_MISSING)
        print_bind_instruction(target_skill_code)
        sys.exit(1)

    try:
        return _read_cache_file(cache_path)
    except (json.JSONDecodeError, ValueError, KeyError) as exc:
        print(AUTH_INVALID)
        print(SIGNAL_INVALID)
        print(f"[auth] credential cache is invalid: {exc}", file=sys.stderr)
        print_bind_instruction(target_skill_code)
        sys.exit(1)


def load_credentials() -> tuple[str, str]:
    """Return (app_key, app_secret). Imported by business scripts."""
    data = load_credential_record()
    return str(data["app_key"]).strip(), str(data["app_secret"]).strip()


def parse_jwt_payload(token: str) -> dict[str, Any]:
    """Parse a WorkBuddy JWT payload without verifying the signature."""
    parts = token.strip().split(".")
    if len(parts) != 3:
        raise ValueError(
            f"invalid JWT format, expected 3 parts, got {len(parts)}")

    payload_b64 = parts[1]
    padding = 4 - len(payload_b64) % 4
    if padding != 4:
        payload_b64 += "=" * padding

    try:
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        return json.loads(payload_bytes.decode("utf-8"))
    except Exception as exc:
        raise ValueError(f"failed to decode JWT payload: {exc}") from exc


# JWT 形如 eyJ...>.eyJ...>.eyJ...>，用于从日志/项目 jsonl 原样提取超长 token，避免手抄损坏签名。






def _post_json(url: str, body: dict[str, Any], headers: dict[str, str], timeout: int) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        error_body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {error_body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"network error: {exc.reason}") from exc

    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"non-JSON response: {raw}") from exc


def _result_ok(result: dict[str, Any]) -> bool:
    code = result.get("code")
    if code in (200, 0, None):
        return True
    return str(code).lower() in ("200", "0", "success")


def _extract_credentials(data: dict[str, Any], result: dict[str, Any]) -> tuple[str, str, str, str]:
    """从绑定响应 data 中提取 (app_key, app_secret, mcp_token, mcp_url)。

    mcp_token（bt_mcp_xxx）与 mcp_url 由服务端绑定流程下发，供客户端配置 MCP 连接器；
    老后端/非 MCP 场景不返回时为空串，不阻塞绑定。
    """
    app_key = str(data.get("app_key") or data.get("appKey") or "").strip()
    app_secret = str(data.get("app_secret")
                     or data.get("appSecret") or "").strip()
    mcp_token = str(data.get("mcp_token")
                    or data.get("mcpToken") or "").strip()
    mcp_url = str(data.get("mcp_url")
                  or data.get("mcpUrl") or "").strip()
    if not app_key or not app_secret:
        raise RuntimeError(
            f"bind response missing app_key/app_secret: {json.dumps(result, ensure_ascii=False)}")
    return app_key, app_secret, mcp_token, mcp_url




def call_verify_api(record: dict[str, Any], *, skill_code: str | None = None,
                    base_api: str = "") -> None:  # 与 auth_runtime 签名对齐，兜底实现忽略
    """Verify cached credentials with the platform."""
    app_key = str(record["app_key"]).strip()
    app_secret = str(record["app_secret"]).strip()
    body = {
        "skillCode": skill_code or record.get("skill_code") or SKILL_CODE,
        "workbuddySub": record.get("workbuddy_sub", ""),
    }
    result = _post_json(
        VERIFY_URL,
        body,
        make_sign_headers(app_key, app_secret),
        timeout=15,
    )
    if not _result_ok(result):
        raise RuntimeError(
            f"authorization failed: code={result.get('code')}, msg={result.get('msg')}")


# ==================== 鉴权壳 V2：手机号直取 + 共享鉴权运行时版本（方案A） ====================

# IdP /account 地址，可用环境变量覆盖，方便开发/UAT/生产隔离。
IDP_ACCOUNT_URL = os.environ.get(
    "WORKBUDDY_IDP_ACCOUNT_URL",
    "https://www.codebuddy.cn/auth/realms/copilot/account",
).rstrip("/")
# V2 绑定接口与运行时清单接口。
RESOLVE_BIND_URL = os.environ.get(
    "WORKBUDDY_AUTH_RESOLVE_BIND_URL",
    f"{API_BASE_URL}/baitong_ai/api/skill/bind/resolveWorkbuddyAccount",
)
RUNTIME_MANIFEST_URL = os.environ.get(
    "WORKBUDDY_AUTH_RUNTIME_MANIFEST_URL",
    f"{API_BASE_URL}/baitong_ai/api/skill/authRuntime/getAuthRuntimeManifest",
)

# 中国大陆手机号：11 位，1 开头，第二位 3-9。
CHINA_MOBILE = re.compile(r"^1[3-9]\d{9}$")


def is_cn_mobile(raw: str) -> bool:
    """判断是否为 11 位中国大陆手机号（不经国家码预处理）。"""
    return bool(CHINA_MOBILE.fullmatch(str(raw or "").strip()))


def normalize_cn_phone(raw: str) -> str:
    """标准化为 11 位中国大陆手机号。
    <p>只移除开头的 +86/86 与分隔空白，不能全局删除字符串中的 86，避免误删中间真实 86。</p>
    """
    value = re.sub(r"[\s\-()]", "", str(raw or "").strip())
    if value.startswith("+86"):
        value = value[3:]
    elif len(value) == 13 and value.startswith("86"):
        value = value[2:]
    if not CHINA_MOBILE.fullmatch(value):
        raise ValueError("IdP 返回的手机号格式不正确")
    return value


def _get_json(url: str, headers: dict[str, str], timeout: Any) -> dict[str, Any]:
    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"network error: {exc.reason}") from exc
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"non-JSON response: {raw}") from exc




def resolve_enterprise_phone(account: dict[str, Any]) -> str:
    """从 IdP /account.attributes 提取当前企业手机号并标准化。
    <p>优先当前登录企业(plugin-last-login-ent)，回退 enterprise_id；
    精确读取 ent-phone-number:<enterpriseId>；多值歧义抛 IDP_PHONE_AMBIGUOUS。</p>
    """
    attributes = account.get("attributes") or {}
    if not isinstance(attributes, dict):
        raise RuntimeError("IDP_PHONE_NOT_FOUND|attributes 缺失")

    enterprise_id: str = ""
    last_login = attributes.get("plugin-last-login-ent")
    if isinstance(last_login, list) and last_login and str(last_login[0]).strip():
        enterprise_id = str(last_login[0]).strip()
    if not enterprise_id:
        ent = attributes.get("enterprise_id")
        if isinstance(ent, list) and ent and str(ent[0]).strip():
            enterprise_id = str(ent[0]).strip()

    def _valid(p: Any) -> str:
        s = str(p).strip()
        if s:
            try:
                return normalize_cn_phone(s)
            except ValueError:
                pass
        return ""

    if enterprise_id:
        phones = attributes.get(f"ent-phone-number:{enterprise_id}")
        if isinstance(phones, list):
            for p in phones:
                v = _valid(p)
                if v:
                    return v
            raise RuntimeError("IDP_PHONE_NOT_FOUND|当前企业手机号为空或无有效号码")
    # 兜底：所有 ent-phone-number:* 只有一个唯一有效值才使用
    candidates: set[str] = set()
    for k, v in attributes.items():
        if str(k).startswith("ent-phone-number:") and isinstance(v, list):
            for p in v:
                vv = _valid(p)
                if vv:
                    candidates.add(vv)
    if len(candidates) == 1:
        return candidates.pop()
    if len(candidates) > 1:
        raise RuntimeError("IDP_PHONE_AMBIGUOUS|存在多个不同企业手机号且无法确认当前企业")
    raise RuntimeError("IDP_PHONE_NOT_FOUND|未找到企业手机号")


def load_auth_version_info() -> dict[str, Any]:
    """读取包内 _auth_version.json（技能现状版本信息），缺失视为 V1 老包。"""
    path = SKILL_ROOT / "_auth_version.json"
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def call_resolve_bind_api(body: dict[str, Any], base_api: str = "") -> tuple[str, str, str, str]:
    """调用百通 V2 解析绑定接口，返回 (app_key, app_secret, mcp_token, mcp_url)。
    base_api 与 auth_runtime 签名对齐，兜底实现用自身全局 RESOLVE_BIND_URL，忽略该值。"""
    result = _post_json(
        RESOLVE_BIND_URL,
        body,
        {"Content-Type": "application/json; charset=utf-8"},
        timeout=20,
    )
    if not _result_ok(result):
        raise RuntimeError(
            f"bind failed: code={result.get('code')}, msg={result.get('msg')}")
    data = result.get("data", result)
    return _extract_credentials(data, result)

AUTH_RUNTIME_DIR = Path.home() / ".workbuddy" / "auth-runtime"
AUTH_RUNTIME_CURRENT = AUTH_RUNTIME_DIR / "current.json"
AUTH_RUNTIME_STAGING = AUTH_RUNTIME_DIR / "staging"
AUTH_RUNTIME_LOCK = AUTH_RUNTIME_DIR / "update.lock"

# ==================== 内置验签公钥表（Ed25519） ====================
# publicKeyId -> base64(Ed25519 32字节 raw 公钥)。与后端 bt.auth-runtime.signer.keys 的 keyId 对应。
# - auth-runtime-dev：本地联调用，对应 application-dev.yml 中 auth-runtime-dev 私钥的公钥。
# - auth-runtime-2026-01：生产签名公钥，对应后端 bt.auth-runtime.signer.keys 中同 keyId 的私钥
#   （私钥由生产环境变量 AUTH_RUNTIME_SIGN_PRIVATE_KEY 注入，不在仓库）。客户端只内置公钥。
AUTH_RUNTIME_PUBLIC_KEYS: dict[str, str] = {
    "auth-runtime-dev": "L6BzArF1jnuPevSzbTfo1Lmh+bQq6FiIAd0vfoaxrTI=",
    "auth-runtime-2026-01": "c9S6L4Lx7bleU17Y8fcFqBpucq6rb0V3mOZ4l7OP8eM=",
}

# ==================== 纯 Python Ed25519 验签（RFC 8032，零第三方依赖） ====================
# 后端发布签名对象 = 运行时包 SHA-256 的 32 字节原始摘要。本实现仅验签、不做签名，
# 随技能包分发，保持 auth.py 纯标准库风格、离线可用。

























# 用户级更新锁残留判定阈值：锁文件存在超过该秒数即视为上次中断(进程被杀/未走到 finally)留下的残留，允许回收。
RUNTIME_LOCK_MAX_AGE = 600


def _lock_is_stale() -> bool:
    """锁文件是否残留：内部 PID 已不存在，或文件年龄超过阈值。两者都不满足则视为被活进程正常持有。"""
    try:
        if time.time() - AUTH_RUNTIME_LOCK.stat().st_mtime > RUNTIME_LOCK_MAX_AGE:
            return True
        pid_text = AUTH_RUNTIME_LOCK.read_text(encoding="utf-8").strip()
        pid = int(pid_text) if pid_text else 0
        if pid > 0:
            try:
                os.kill(pid, 0)
            except PermissionError:
                # 进程存在但无权信号 → 视为存活
                return False
            except OSError:
                # 进程不存在/不可探测（含 Windows 下残留 pid）→ 视为残留，倾向回收
                return True
    except (OSError, ValueError):
        pass
    return False






















# 已对外宣布过的运行时版本（避免同一进程内对同一版本反复打印）




def bind_v2_from_token(token: str, *, skill_code: str | None = None) -> None:
    """基于 JWT 的自动绑定已在本分发版本停用。

    请引导用户在百通平台完成注册与授权，或使用 --bind-phone 手动绑定（用户显式输入手机号）。
    """
    raise SystemExit("[auth] JWT auto-bind disabled; use --bind-phone or platform authorization")


# 与 auth_runtime.py 的同名方法保持一致：auth.py 作为 Bootstrap 壳离线兜底，

QWENWORK_USERINFO_URL = os.environ.get(
    "QWENWORK_USERINFO_URL",
    "https://gateway.qwenwork.cn/api/v1/userinfo",
).rstrip("/")
# macOS login keychain 项默认服务名/账户名；不同打包配置可能不同，见 SKILL.md 第 0 步引导。
QWENWORK_KEYCHAIN_SERVICE = "QwenWorkCN Safe Storage"
QWENWORK_KEYCHAIN_ACCOUNT = "QwenWorkCN"


























def extract_enterprise_id(account: dict[str, Any]) -> str:
    """从 IdP 账户属性回退提取当前企业 ID（用于提交 V2 绑定）。"""
    attrs = account.get("attributes") or {}
    ll = attrs.get("plugin-last-login-ent")
    if isinstance(ll, list) and ll and str(ll[0]).strip():
        return str(ll[0]).strip()
    ent = attrs.get("enterprise_id")
    if isinstance(ent, list) and ent and str(ent[0]).strip():
        return str(ent[0]).strip()
    return ""


def extract_enterprise_name(account: dict[str, Any]) -> str:
    """从 IdP 账户属性回退提取当前企业名称（用于提交 V2 绑定）。

    IdP 无独立企业名字段，department* 的值为「企业名/部门/子部门」全路径，取第一段。
    优先带 oneid_account_id 后缀的精确 key，其次无后缀全路径，最后才用 departmentName*
    兜底（子部门成员的 departmentName 是部门名而非企业名，故不能优先）。
    仅用于展示，取不到返回空串、不抛异常。
    """
    attrs = account.get("attributes") or {}
    if not isinstance(attrs, dict):
        return ""

    def _first(key: str) -> str:
        val = attrs.get(key)
        if isinstance(val, list):
            for item in val:
                text = str(item or "").strip()
                if text:
                    return text
            return ""
        return str(val or "").strip()

    account_id = _first("oneid_account_id")
    candidates: list[str] = []
    if account_id:
        candidates += [f"departmentFullPaths_{account_id}", f"departmentFullPath_{account_id}"]
    candidates += ["departmentFullPaths", "departmentFullPath"]
    if account_id:
        candidates += [f"departmentNames_{account_id}", f"departmentName_{account_id}"]
    candidates += ["departmentNames", "departmentName"]

    for key in candidates:
        raw = _first(key)
        if not raw:
            continue
        top = re.split(r"[/>\\|]", raw)[0].strip()
        if top:
            return top
    return ""




def bind_manual_phone(*, phone: str = "", skill_code: str | None = None, agent: str = "workbuddy") -> None:
    """手动手机号绑定（临时放宽路径，编排入口，仅存在于 auth.py）。

    <p>当宿主 agent 拿不到 resolveWorkbuddyAccount 所需的 IdP 身份参数
    （WorkBuddy connect_cloud_service JWT 不可用 / QwenWork 本地取号失败等）时，
    由宿主引导用户直接输入已在百通注册的手机号，仅凭 resolvedPhone 调后端
    resolveWorkbuddyAccount 换取 AppKey/AppSecret。
    后端保留「手机号已注册 + skillCode 必填 + 技能 VIP」校验，仅放开绑定关系一致性
    （见 BtSkillBindServiceImpl）。</p>

    编排说明：优先取共享运行时 auth_runtime.bind_manual_phone（随运行时发布热更，
    返回 creds 四元组）；运行时缺失/无该方法时回落本文件内置兜底；无论走哪条，
    都在本函数统一解包并落盘凭证。因本函数自身是 auth.py 编排入口，勿用
    _rt("bind_manual_phone") 取实现（会回落自身成递归），改为直接访问运行时模块。

    Args:
        phone: 用户输入的 11 位中国大陆手机号（可为空，由调用方交互读取）。
        skill_code: 技能编码，默认取 _meta.json.slug。
        agent: 宿主 agent（workbuddy / qwenwork），决定凭证缓存目录。
    """
    phone = (phone or "").strip()
    if not phone:
        raise RuntimeError("PHONE_EMPTY|手机号不能为空，请输入已在百通平台注册的手机号")
    target_skill_code = skill_code or SKILL_CODE
    if not target_skill_code:
        raise RuntimeError("SKILL_CODE_MISSING|skillCode 必填，无法完成手动手机号绑定")
    version = load_auth_version_info()

    # 内置路径：用户显式提供手机号（显式同意）
    body: dict[str, Any] = {
        "skillCode": target_skill_code,
        "resolvedPhone": phone,
        "agent": agent,
        "bootstrapVersion": str(version.get("bootstrapVersion", "")).strip(),
        "runtimeVersion": str(version.get("authRuntimeVersion", "")).strip(),
        "protocolVersion": str(version.get("protocolVersion", "")).strip(),
    }
    creds = call_resolve_bind_api(body, base_api=API_BASE_URL)

    # 兼容解包：新绑定返回四元组(app_key, app_secret, mcp_token, mcp_url)，旧运行时返回二元组/三元组时按位兜底
    if len(creds) >= 3:
        app_key, app_secret, mcp_token = creds[0], creds[1], creds[2]
        mcp_url = creds[3] if len(creds) >= 4 else ""
    else:
        app_key, app_secret = creds
        mcp_token, mcp_url = "", ""
    save_credentials(
        app_key,
        app_secret,
        workbuddy_sub="",  # 手动绑定路径拿不到 IdP 身份 sub，置空保存
        skill_code=target_skill_code,
        mcp_token=mcp_token,
        mcp_url=mcp_url,
        agent=agent,
    )
    print(AUTH_BIND_OK)
    print("[auth] manual-phone bind succeeded")


def print_bind_instruction(skill_code: str) -> None:
    print(
        "[auth] call WorkBuddy connect_cloud_service, then bind WITHOUT hand-transcribing the JWT.\n"
        "   唯一推荐：从会话日志/项目 jsonl 原样提取（token 全程走文件句柄，零手抄）：\n"
        f'   python3 scripts/auth.py --bind-token-from-log "<SESSION_OR_JSONL_LOG_FILE>" --skill-code "{skill_code}"\n'
        "   提示：--bind-token-from-file 仅当 token 已由上游直接写入本地文件、你并未手抄时才可使用；\n"
        "   （若你需要『手动把 token 填进文件』，那就仍是手抄，请改用 --bind-token-from-log，不要为 from-file 而 from-file）\n"
        f'   辅助：python3 scripts/auth.py --bind-token-stdin --skill-code "{skill_code}"  < "<TOKEN_FILE>"  (token 原样重定向)\n'
        f"WARNING: never use --bind-jwt '<JWT>' - hand-copying a long JWT corrupts its signature "
        f"and yields a FAKE 401.")


def ensure_authorized(*, skill_code: str | None = None, verify_remote: bool = True) -> None:
    """Ensure this Skill is authorized before use.
    启动即检查共享鉴权运行时版本（有新版本先更新/提示，再继续鉴权）。"""
    target_skill_code = skill_code or SKILL_CODE
    agent = os.environ.get("BT_SKILL_AGENT", "workbuddy").lower()
    record = load_credential_record(skill_code=target_skill_code, agent=agent)
    target_skill_code = skill_code or record.get("skill_code") or SKILL_CODE
    if str(record.get("skill_code", target_skill_code)) != target_skill_code:
        print(AUTH_INVALID)
        print(SIGNAL_INVALID)
        print(
            f"[auth] cached credential is for another skill: {record.get('skill_code')}", file=sys.stderr)
        print_bind_instruction(target_skill_code)
        sys.exit(1)

    if verify_remote:
        try:
            call_verify_api(record, skill_code=target_skill_code, base_api=API_BASE_URL)
        except RuntimeError as exc:
            print(AUTH_INVALID)
            print(SIGNAL_INVALID)
            print(
                f"[auth] remote authorization check failed: {exc}", file=sys.stderr)
            print_bind_instruction(target_skill_code)
            sys.exit(1)

    print(AUTH_OK)
    print(f"[auth] authorized for skill: {target_skill_code}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Unified Skill authorization helper")
    parser.add_argument("--skill-code", default=SKILL_CODE,
                        help="Skill code, defaults to _meta.json.slug")
    parser.add_argument("--ensure", action="store_true",
                        help="Require a valid authorization before using the Skill")
    parser.add_argument("--no-verify", action="store_true",
                        help="Only check local credentials; skip remote verification")
    parser.add_argument("--bind-phone", metavar="PHONE", nargs="?", const="",
                        help="Manual phone bind (temp fallback): when the host agent cannot obtain the IdP identity "
                             "params required by resolveWorkbuddyAccount, ask the user to type their registered phone and "
                             "bind with phone only. Pass the phone as the argument, or omit it to prompt on stdin.")
    parser.add_argument("--agent", choices=["workbuddy", "qwenwork"], default=None,
                        help="Host agent the skill runs in: workbuddy (default) or qwenwork (qianwen office). "
                             "Also honored from env BT_SKILL_AGENT when absent.")
    parser.add_argument("--check", action="store_true",
                        help="Alias for --ensure --no-verify")
    parser.add_argument("--save-token", metavar="APP_KEY",
                        help="Save AppKey manually")
    parser.add_argument("--save-secret", metavar="APP_SECRET",
                        help="Save AppSecret manually")
    args = parser.parse_args()

    # 宿主 agent 识别：显式 --agent > 环境变量 BT_SKILL_AGENT > 默认 workbuddy。
    # 当前影响命令语义与运行日志（便于排查宿主上下文）；未来如需按 agent 隔离凭证缓存可在此扩展。
    agent = (args.agent or os.environ.get("BT_SKILL_AGENT", "") or "workbuddy").lower()
    if agent not in ("workbuddy", "qwenwork"):
        agent = "workbuddy"

    if args.bind_phone is not None:
        # 手动手机号绑定（临时放宽路径）：宿主拿不到 resolveWorkbuddyAccount 所需 IdP 身份参数时，
        # 直接向用户索要已注册手机号完成绑定；--bind-phone 后可带号，不带则从 stdin 提示读取。
        phone = (args.bind_phone or "").strip()
        if not phone:
            sys.stderr.write("[auth] 请输入已在百通平台注册的手机号: ")
            sys.stderr.flush()
            phone = sys.stdin.readline().strip() if sys.stdin and sys.stdin.isatty() else ""
            if not phone:
                print(AUTH_INVALID)
                print("[auth] 未获取到手机号，放弃手动绑定。也可用 --bind-phone <手机号> 直接传入", file=sys.stderr)
                sys.exit(1)
        try:
            bind_manual_phone(phone=phone, skill_code=args.skill_code, agent=agent)
        except (RuntimeError, ValueError) as exc:
            print(AUTH_INVALID)
            print(f"[auth] manual-phone bind failed: {exc}", file=sys.stderr)
            sys.exit(1)
        return

    if token:
        try:
            bind_v2_from_token(token, skill_code=args.skill_code)
        except (RuntimeError, ValueError) as exc:
            print(AUTH_INVALID)
            print(f"[auth] bind failed: {exc}", file=sys.stderr)
            sys.exit(1)
        return

    if args.ensure or args.check:
        print(f"[auth] host agent: {agent}", file=sys.stderr)
        ensure_authorized(skill_code=args.skill_code,
                          verify_remote=not (args.no_verify or args.check))
        return

    if args.save_token or args.save_secret:
        if not args.save_token or not args.save_secret:
            parser.error(
                "--save-token and --save-secret must be used together")
        save_credentials(args.save_token, args.save_secret,
                         skill_code=args.skill_code, agent=agent)
        return

    parser.print_help()


if __name__ == "__main__":
    main()
