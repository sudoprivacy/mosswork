# Wiki Evolution Log · rpm-05-区域竞争格局分析

> 按迭代记录「发现什么 / 改了什么」。Wiki 永不回滚，只增不删（被拒模式也保留并标 rejected）。

## 2026-08-31 · 基线 v?.?.?
- 发现：脚手架初始化 Wiki Layer；patterns 待后续 rollout 沉淀。
- 改了：按 WikiSkill 三层架构建立 PURPOSE.md + wiki/{raw, patterns, logs, skill-impact}。
