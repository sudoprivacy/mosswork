## Description: <br>
Use APIDot for GPT 5.2 API workflows, including OpenAI-compatible chat, long-context synthesis, agentic coding handoffs, chart reasoning, streaming planning, usage tracking, API key safety guidance, and APIDot docs routing. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[jiehao71727](https://clawhub.ai/user/jiehao71727) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this documentation-only skill to find the right APIDot GPT 5.2 model pages, API docs, and integration guidance before implementing chat, streaming, long-context, chart reasoning, or coding-handoff workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: APIDot API keys and private prompts could be exposed if copied into browser code, logs, screenshots, repositories, or chat output. <br>
Mitigation: Keep APIDOT_API_KEY in server-side environment variables or a backend secret manager, and avoid logging credentials, private prompts, documents, tool inputs, generated responses, usage records, and request IDs. <br>
Risk: API details, model fields, limits, availability, and commercial terms may change after the skill was published. <br>
Mitigation: Verify current request fields, response fields, limits, and terms in APIDot's live docs before implementing or making real API calls. <br>
Risk: Live API calls may send sensitive customer or source data to an external service. <br>
Mitigation: Only make real API calls when the user explicitly asks and a controlled server-side environment is available. <br>


## Reference(s): <br>
- [APIDot Docs](https://apidot.ai/docs) <br>
- [APIDot GPT 5.2 Model Page](https://apidot.ai/models/gpt-5-2) <br>
- [APIDot GPT 5.2 API Docs](https://apidot.ai/docs/gpt-5-2) <br>
- [APIDot Quickstart](https://apidot.ai/docs/quickstart) <br>
- [APIDot Error Guidance](https://apidot.ai/docs/errors) <br>
- [APIDot Examples](https://github.com/APIDotAI/apidot-examples) <br>
- [APIDot GPT 5.2 Reference](references/api.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, configuration] <br>
**Output Format:** [Markdown] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Documentation-only; no executable files, network requests, bundled clients, or stored credentials.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
