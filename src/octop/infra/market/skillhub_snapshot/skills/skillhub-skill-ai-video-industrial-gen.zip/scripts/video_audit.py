#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""video_audit.py — AI电影级短视频总导演 · 确定性裁决工具

把 SKILL.md 里可判定的规则固化成命令，避免同一句需求每次裁决出不同模板。

子命令：
  plan <文本> [--channel 渠道] [--sec 秒] [--ratio 宽高比] [--json] [--out 文件]
                      一次跑完：模板裁决 + 技术参数 + 输出骨架 + 质量门（推荐入口）
  template <文本>   模板适配裁决（品类词 > 形式词 > 渠道词 > 兜底）
  spec <渠道> [--sec 秒] [--ratio 宽高比]
                      技术参数裁决（宽高比 / 帧率 / 时长上限 / 拆分）
  checkpoint <文本> --n 1..10
                      质量门单项通过判定（返回该条的验收标准与失败回补动作）
  checklist         打印交付前 10 项质量门
  demo              跑一个完整实战案例
  selftest          跑内置断言

退出码：0=成功  2=输入/用法错误  3=内部错误
零第三方依赖，仅用 Python 标准库。
"""

import argparse
import io
import json
import os
import sys

# ---- Windows 控制台 GBK 兜底：任何环境下都不因编码炸掉 ----
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
try:
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


# ============================================================
# 规则表（全部取自 references/templates.md 的「适用场景」与 SKILL.md §Step 2）
# 所有词匹配统一走「小写归一」：词表保留展示形态，比对用小写键，
# 因此 b2b / B2B / B2b 三种写法等价（修 defect：小写 b2b 曾不命中品类词）。
# ============================================================

def _mk(words):
    """把词表转成 {小写键: 展示形态}。"""
    return dict((w.lower(), w) for w in words)


# 第一层：品类词 —— 决定画面主体与材质美学，优先级最高
CATEGORY_WORDS = {
    "D": _mk(["科技出海", "企业品宣", "跨境展会", "B2B", "工业", "制造", "机械",
              "新能源", "芯片"]),
    # 「茶」单字已从 A 移除：它会把奶茶 / 果茶 / 茶饮等快消食品误判为东方高奢美学。
    # 改为只认更长的茶文化词（茶道/茶器/茶艺/东方茶/名茶/茶叶），
    # 奶茶/果茶/茶饮/新茶饮 归入 B（食品快消）。
    "A": _mk(["中药美妆", "东方文化", "高净值", "奢侈品", "高奢", "珠宝", "瓷器",
              "丝绸", "茶道", "茶器", "茶艺", "东方茶", "名茶", "茶叶"]),
    "B": _mk(["美妆", "食品", "家居", "母婴", "奶茶", "果茶", "茶饮", "新茶饮",
              "咖啡", "快消", "日用"]),
}

# 第二层：形式词 —— 决定叙事方式与情绪弧线
FORM_WORDS = {
    "C": _mk(["微短剧", "剧情号", "剧情", "带货", "情感", "快手"]),
    "A": _mk(["出海TVC", "高净值"]),
    "B": _mk(["种草", "生活方式", "生活", "温暖", "美妆日常"]),
}

# 第三层：渠道词 —— 只决定投放端。分三类：
#   B2B/官宣渠道 → 判 D（跨境 B2B 工业科技基线），不再一律判成消费品种草
#   消费竖屏渠道 → 判 B
#   中性横屏内容平台 → 判 B，并在依据里提示补品类词
CHANNEL_B2B = _mk(["LinkedIn", "领英", "官网"])
CHANNEL_CONSUMER = _mk(["抖音", "TikTok", "小红书", "视频号"])
CHANNEL_NEUTRAL = _mk(["B站", "YouTube"])
CHANNEL_WORDS = dict(
    list(CHANNEL_B2B.items()) + list(CHANNEL_CONSUMER.items()) + list(CHANNEL_NEUTRAL.items())
)

# 兜底：品类与形式都未命中时
FALLBACK_LUX = ["奢侈", "高端", "珠宝", "瓷器", "丝绸"]
FALLBACK_CONSUMER = ["美妆", "食品", "家居", "母婴", "日用", "消费"]

TEMPLATE_NAME = {
    "A": "东方美学·高奢品牌出海",
    "B": "小红书/TikTok 视觉种草",
    "C": "短视频情感/剧情带货",
    "D": "跨境/B2B 工业科技出海",
}

# 各模板的 Event 1–4 叙事主轴（供 plan 输出骨架，避免每次现编导致轴不一致）
SKELETON = {
    "A": ["Event 1 材质与工艺微距（瓷/丝/木/茶，侧逆光，写实纹理）",
          "Event 2 匠人动作与空间氛围（慢镜，构图留白，Logo 位预留）",
          "Event 3 文化符号转场（器物/节气/书法元素）",
          "Event 4 品牌收束与字幕留白"],
    "B": ["Event 1 使用前痛点（真实生活场景，3 秒内给到结果）",
          "Event 2 产品亮相与使用动作（近景手感 + 细节特写）",
          "Event 3 效果对比与情绪上扬（暖光，人物微表情）",
          "Event 4 口播收口与行动号召（字幕留白）"],
    "C": ["Event 1 冲突开场（一句话抛出矛盾）",
          "Event 2 情绪升级（人物关系推进，节奏加快）",
          "Event 3 反转或释然（镜头运动加强）",
          "Event 4 落点与转化口播"],
    "D": ["Event 1 产线/工况全景（真实车间，设备运转）",
          "Event 2 技术细节与工艺特写（参数可视、材质写实）",
          "Event 3 交付/合作场景（跨境物流、客户现场）",
          "Event 4 品牌承诺与字幕留白（Logo 位）"],
}

# 渠道 → 宽高比（SKILL.md §风险与边界 3 给了 TikTok/抖音=9:16、B站/官网=16:9；
# 其余按平台实际主形态补齐，与 tags 承诺的「适配抖音、小红书、TikTok、视频号」一致）
RATIO_PORTRAIT = _mk(["抖音", "TikTok", "小红书", "视频号", "快手"])
RATIO_LANDSCAPE = _mk(["B站", "官网", "YouTube", "LinkedIn", "领英"])
ALLOWED_RATIO = ("9:16", "16:9", "1:1")

MAX_SEC = 60        # SKILL.md §风险与边界 3：单条短视频建议 ≤60s
MAX_TOTAL_SEC = 3600  # 单次规划总时长上界；超过即视为输入异常，拒绝产出荒谬拆分


# ============================================================
# 裁决逻辑
# ============================================================

def _longest_hit(lowered, mapping):
    """在映射表 {小写键: 展示形态} 中做最长命中。返回 (展示形态, 长度)。"""
    best, best_len = None, 0
    for low, disp in mapping.items():
        if low and low in lowered and len(low) > best_len:
            best, best_len = disp, len(low)
    return best, best_len


def decide_template(text):
    """模板裁决：品类词 > 形式词 > 渠道词 > 兜底。

    返回 dict：template / name / reason / hit / fallback
    """
    if text is None or not str(text).strip():
        raise ValueError("需求文本为空，无法裁决模板")

    lowered = str(text).lower()  # 大小写归一：b2b / B2B / B2b 等价

    # 第一层：品类词（最长命中优先；并列时按 D > A > B，工业与出海企业形态最明确）
    hits = []
    for tpl in ("D", "A", "B"):
        w, ln = _longest_hit(lowered, CATEGORY_WORDS[tpl])
        if w:
            hits.append((ln, tpl, w))
    if hits:
        hits.sort(key=lambda x: (-x[0], {"D": 0, "A": 1, "B": 2}[x[1]]))
        ln, tpl, w = hits[0]
        return {
            "template": "Template " + tpl,
            "code": tpl,
            "name": TEMPLATE_NAME[tpl],
            "hit": w,
            "layer": "品类词",
            "reason": "命中品类词「%s」（%d 字），品类决定画面主体与材质美学，优先级高于投放形式" % (w, ln),
            "fallback": False,
        }

    # 第二层：形式词
    hits = []
    for tpl in ("C", "A", "B"):
        w, ln = _longest_hit(lowered, FORM_WORDS[tpl])
        if w:
            hits.append((ln, tpl, w))
    if hits:
        hits.sort(key=lambda x: (-x[0], {"C": 0, "A": 1, "B": 2}[x[1]]))
        ln, tpl, w = hits[0]
        return {
            "template": "Template " + tpl,
            "code": tpl,
            "name": TEMPLATE_NAME[tpl],
            "hit": w,
            "layer": "形式词",
            "reason": "无品类词，命中形式词「%s」（%d 字），按叙事方式裁决" % (w, ln),
            "fallback": False,
        }

    # 第三层：只有渠道词 —— B2B/官宣渠道走 D，消费与中性渠道走 B
    b2b_hits = sorted(set(v for k, v in CHANNEL_B2B.items() if k in lowered))
    other_hits = sorted(set(
        v for k, v in CHANNEL_WORDS.items() if k in lowered and k not in CHANNEL_B2B))
    if b2b_hits:
        return {
            "template": "Template D",
            "code": "D",
            "name": TEMPLATE_NAME["D"],
            "hit": "/".join(b2b_hits),
            "layer": "渠道词",
            "reason": "仅命中 B2B/官宣渠道（%s），无品类与形式信息，按跨境 B2B 工业科技基线裁决，"
                      "须在输出标注 [模板兜底]" % "/".join(b2b_hits),
            "fallback": True,
        }
    if other_hits:
        return {
            "template": "Template B",
            "code": "B",
            "name": TEMPLATE_NAME["B"],
            "hit": "/".join(other_hits),
            "layer": "渠道词",
            "reason": "仅命中渠道词（%s），无品类与形式信息，按消费品种草基线裁决，须在输出标注 [模板兜底]" % "/".join(other_hits),
            "fallback": True,
        }

    # 第四层：完全无法判断 —— 按品类兜底
    if any(w in lowered for w in FALLBACK_LUX):
        tpl = "A"
        reason = "完全无特征词，命中奢侈/高端线索，兜底 Template A（高奢出海基线）"
    elif any(w in lowered for w in FALLBACK_CONSUMER):
        tpl = "B"
        reason = "完全无特征词，命中消费品线索，兜底 Template B（默认最高转化率）"
    else:
        tpl = "A"
        reason = "完全无特征词且无品类线索，兜底 Template A（高奢出海基线），须在输出标注 [模板兜底：默认A]"
    return {
        "template": "Template " + tpl,
        "code": tpl,
        "name": TEMPLATE_NAME[tpl],
        "hit": None,
        "layer": "兜底",
        "reason": reason,
        "fallback": True,
    }


def decide_spec(channel, sec=None, ratio=None):
    """技术参数裁决：宽高比 / 帧率 / 时长上限 / 拆分方案。"""
    if channel is None or not str(channel).strip():
        raise ValueError("渠道为空，无法裁决技术参数")

    ch = str(channel)
    lowered = ch.lower()

    if ratio is not None:
        r = str(ratio).strip()
        if r not in ALLOWED_RATIO:
            raise ValueError("宽高比必须是 %s 之一，收到「%s」" % ("/".join(ALLOWED_RATIO), r))
        ratio, note = r, "用户显式指定 %s（覆盖渠道自动裁决）" % r
    else:
        portrait = sorted(set(v for k, v in RATIO_PORTRAIT.items() if k in lowered))
        landscape = sorted(set(v for k, v in RATIO_LANDSCAPE.items() if k in lowered))
        if portrait and landscape:
            ratio = "9:16"
            note = "同时命中竖屏（%s）与横屏（%s）渠道，按竖屏优先（短视频投放主形态）" % (
                "/".join(portrait), "/".join(landscape))
        elif portrait:
            ratio = "9:16"
            note = "命中竖屏渠道 %s" % "/".join(portrait)
        elif landscape:
            ratio = "16:9"
            note = "命中横屏渠道 %s" % "/".join(landscape)
        else:
            raise ValueError(
                "未识别渠道「%s」。已支持：竖屏(%s) / 横屏(%s)；"
                "1:1 仅在用户显式指定时使用" % (
                    ch, "/".join(list(RATIO_PORTRAIT.values())[:5]),
                    "/".join(list(RATIO_LANDSCAPE.values())[:4])))

    result = {
        "channel": ch,
        "ratio": ratio,
        "fps": "24fps" if ratio == "16:9" else "30fps",
        "max_sec": MAX_SEC,
        "note": note,
    }

    if sec is not None:
        if isinstance(sec, bool):
            raise ValueError("时长必须是整数秒，收到布尔值")
        try:
            s = int(sec)
        except (TypeError, ValueError):
            raise ValueError("时长必须是整数秒，收到「%s」" % sec)
        if s <= 0:
            raise ValueError("时长必须为正整数，收到 %d" % s)
        if s > MAX_TOTAL_SEC:
            raise ValueError(
                "时长 %ds 超出单次规划上界 %ds（约 %d 分钟）。"
                "请按影片/系列拆成多次规划，或先用 spec 单条校验" % (s, MAX_TOTAL_SEC, MAX_TOTAL_SEC // 60))
        result["sec"] = s
        if s > MAX_SEC:
            result["over_limit"] = True
            result["split_into"] = (s + MAX_SEC - 1) // MAX_SEC
            result["advice"] = "超出单条 ≤%ds 上限，须拆分为 %d 条独立输出，每条独立走 Event 1-4 轴" % (
                MAX_SEC, result["split_into"])
        else:
            result["over_limit"] = False
            result["advice"] = "在 ≤%ds 上限内，可单条输出" % MAX_SEC
    return result


def _split_line(spec):
    """把 spec 的时长结论写成固定一句，保证 plan 输出里恒定出现「拆分」。"""
    if "sec" not in spec:
        return "未指定时长，默认按单条 ≤%ds 规划" % spec["max_sec"]
    if spec.get("over_limit"):
        return "%d 条（每条 ≤%ds，各走一条 Event 1-4 轴）" % (
            spec["split_into"], spec["max_sec"])
    return "单条输出，无需拆分（%ds ≤ %ds）" % (spec["sec"], spec["max_sec"])


CHECKLIST = [
    (1, "触发正确", "属本 skill 范围，未误触非触发边界；命中 §Step 0 六条边界之一须转交",
     "在输出开头写「本需求不属本 skill 范围，建议转交 XXX」并停止生成"),
    (2, "输入解析完整", "三字段均处理；缺项已按 L1–L4 补全并标 [补全推断]",
     "补 §Step 1 的三字段表，缺项逐条标 [补全推断] 并说明推断依据"),
    (3, "模板正确激活", "由 video_audit.py template 裁决且与品类一致；兜底须标 [模板兜底]",
     "重跑 video_audit.py plan，按裁决结果换模板；属兜底则显式标 [模板兜底]"),
    (4, "事件驱动语法", "无「第X秒」时间切片，使用 Event 1–4 轴",
     "把所有「第X秒」改写为 Event N + 动作描述，时间感靠动作先后体现"),
    (5, "双语提示词", "中文版（可灵/即梦/海螺）+ 英文版（Sora/Runway）均给出",
     "补缺失语言版本；可灵/即梦用中文主体描述，Sora/Runway 用英文"),
    (6, "技术参数合理", "时长/比例/帧率/运动强度均填；由 video_audit.py spec 校验",
     "重跑 video_audit.py spec 并把 ratio/fps/max_sec 原样抄进提示词"),
    (7, "商业留白", "构图为 Logo/字幕留白说明",
     "在 Event 4 补一句「画面下方 1/4 留白，供 Logo 与字幕」"),
    (8, "绝对写实", "皮肤微观纹理等写实约束已注入",
     "在人物镜头补「皮肤可见毛孔与细微纹理，不做磨皮美颜」"),
    (9, "反虚构", "无杜撰真实品牌/认证/数据；补全项标 [补全推断]",
     "删掉所有真实品牌名与未经验证的数据，或改写为 [补全推断]"),
    (10, "零废话", "结构外无过渡语，直奔主题",
     "删掉「好的，以下是…」「希望对你有帮助」等所有结构外语句"),
]


def run_template(args):
    r = decide_template(args.text)
    if args.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print("需求：%s" % args.text)
        print("裁决：%s — %s" % (r["template"], r["name"]))
        print("依据：%s（%s）" % (r["reason"], r["layer"]))
        if r["fallback"]:
            print("提示：属兜底裁决，输出时须标注 [模板兜底]")
    return 0


def run_spec(args):
    r = decide_spec(args.channel, args.sec, getattr(args, "ratio", None))
    if args.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print("渠道：%s" % r["channel"])
        print("宽高比：%s   帧率：%s   单条上限：≤%ds" % (r["ratio"], r["fps"], r["max_sec"]))
        print("依据：%s" % r["note"])
        if "sec" in r:
            print("时长：%ds → %s" % (r["sec"], r["advice"]))
            print("拆分：%s" % _split_line(r))
    return 0


def run_checklist(args):
    print("交付前质量门（10 项 · 全过=完稿）")
    print("-" * 60)
    for n, name, std in ((c[0], c[1], c[2]) for c in CHECKLIST):
        print("%2d  %-8s %s" % (n, name, std))
    print("-" * 60)
    print("任一未达标 → 回补对应模块后重新输出（见 SKILL.md §异常与兜底）")
    return 0


def run_checkpoint(args):
    """单项质量门的通过判定：给标准 + 失败回补动作，可机械核对。"""
    n = args.n
    if not isinstance(n, int) or n < 1 or n > len(CHECKLIST):
        sys.stderr.write("[错误] 质量门编号必须是 1~%d 的整数，收到「%s」\n" % (len(CHECKLIST), n))
        return 2
    num, name, std, fix = CHECKLIST[n - 1]
    if args.json:
        print(json.dumps({"no": num, "name": name, "standard": std, "if_failed": fix},
                         ensure_ascii=False, indent=2))
    else:
        print("质量门 %d · %s" % (num, name))
        print("  通过标准：%s" % std)
        print("  未过回补：%s" % fix)
    return 0


DEMO_TEXT = "工业传感器，投放 LinkedIn，做企业出海形象片"


def run_demo(args):
    print("=" * 60)
    print("实战案例：%s" % DEMO_TEXT)
    print("=" * 60)
    r = decide_template(DEMO_TEXT)
    print("\n[Step 2 模板裁决]")
    print("  %s — %s" % (r["template"], r["name"]))
    print("  依据：%s" % r["reason"])

    s = decide_spec("LinkedIn", 75)
    print("\n[Step 4 技术参数]")
    print("  宽高比 %s / 帧率 %s / 单条上限 ≤%ds" % (s["ratio"], s["fps"], s["max_sec"]))
    print("  时长 75s → %s" % s["advice"])

    print("\n[质量门] 共 %d 项，逐条核对后交付（video_audit.py checklist）" % len(CHECKLIST))
    return 0


def _plan_dict(text, channel=None, sec=None, ratio=None):
    tpl = decide_template(text)
    payload = {"requirement": text, "template": tpl}
    ch = channel
    if not ch:
        hits = sorted(set(v for k, v in CHANNEL_WORDS.items() if k in text.lower()))
        ch = hits[0] if hits else None
    if ch:
        payload["spec"] = decide_spec(ch, sec, ratio)
    payload["skeleton"] = SKELETON[tpl["code"]]
    payload["checklist"] = [{"no": n, "name": nm, "standard": st} for n, nm, st, _ in CHECKLIST]
    return payload


def _plan_text(p):
    lines = []
    lines.append("=" * 60)
    lines.append("短视频交付裁决书")
    lines.append("=" * 60)
    lines.append("需求：%s" % p["requirement"])
    t = p["template"]
    lines.append("")
    lines.append("[1 模板裁决]")
    lines.append("  %s — %s" % (t["template"], t["name"]))
    lines.append("  依据：%s" % t["reason"])
    lines.append("  层级：%s    兜底：%s" % (t["layer"], "是" if t["fallback"] else "否"))
    if t["fallback"]:
        lines.append("  ⚠ 属兜底裁决，正式输出时须标注 [模板兜底]")
    if "spec" in p:
        s = p["spec"]
        lines.append("")
        lines.append("[2 技术参数]")
        lines.append("  渠道：%s" % s["channel"])
        lines.append("  宽高比：%s   帧率：%s   单条上限：≤%ds" % (
            s["ratio"], s["fps"], s["max_sec"]))
        lines.append("  依据：%s" % s["note"])
        if "sec" in s:
            lines.append("  时长：%ds   拆分：%s" % (s["sec"], _split_line(s)))
        else:
            lines.append("  拆分：%s" % _split_line(s))
    else:
        lines.append("")
        lines.append("[2 技术参数]")
        lines.append("  未识别到投放渠道，跳过技术参数裁决。"
                     "补 --channel 抖音/TikTok/小红书/视频号/B站/官网/YouTube/LinkedIn 后重跑")
    lines.append("")
    lines.append("[3 输出骨架（Event 1–4 轴）]")
    for i, s in enumerate(p["skeleton"], 1):
        lines.append("  %d  %s" % (i, s))
    lines.append("")
    lines.append("[4 交付前质量门（%d 项）]" % len(p["checklist"]))
    for c in p["checklist"]:
        lines.append("  %2d  %-8s %s" % (c["no"], c["name"], c["standard"]))
    lines.append("")
    lines.append("任一未达标 → 用 video_audit.py checkpoint <文本> --n <编号> 查回补动作")
    return "\n".join(lines)


def run_plan(args):
    p = _plan_dict(args.text, getattr(args, "channel", None), args.sec,
                   getattr(args, "ratio", None))
    body = json.dumps(p, ensure_ascii=False, indent=2) if args.json else _plan_text(p)
    if getattr(args, "out", None):
        d = os.path.dirname(os.path.abspath(args.out))
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        with open(args.out, "w", encoding="utf-8", newline="\n") as f:
            f.write(body + "\n")
        sys.stderr.write("[已写入] %s\n" % os.path.abspath(args.out))
        return 0
    print(body)
    return 0


def run_selftest(args):
    cases = []

    def chk(name, got, want):
        cases.append((name, got == want, "got=%r want=%r" % (got, want)))

    # —— 冲突案例锁死：子串抢占（工业 + 出海，必须判 D 而非 A）——
    chk("工业设备出海 → D", decide_template("工业设备出海")["code"], "D")
    chk("机械零件出海TVC → D", decide_template("机械零件出海TVC")["code"], "D")
    chk("新能源企业品宣 → D", decide_template("新能源企业品宣")["code"], "D")
    chk("B2B芯片科技出海 → D", decide_template("B2B芯片科技出海")["code"], "D")
    # —— 大小写归一：b2b / B2b 与 B2B 等价 ——
    chk("小写 b2b 企业服务 → D", decide_template("b2b 企业服务")["code"], "D")
    chk("B2b 企业服务 → D", decide_template("B2b 企业服务")["code"], "D")
    # —— 泛化出海词在无工业线索时仍归 A ——
    chk("高奢手表出海TVC → A", decide_template("高奢手表出海TVC")["code"], "A")
    chk("东方茶器出海 → A", decide_template("东方茶器出海")["code"], "A")
    chk("珠宝品牌高净值 → A", decide_template("珠宝品牌高净值")["code"], "A")
    # —— 单字品类词不再抢走快消食品：奶茶/果茶归 B ——
    chk("奶茶新品上市种草 → B", decide_template("奶茶新品上市种草")["code"], "B")
    chk("果茶夏季新品 → B", decide_template("果茶夏季新品")["code"], "B")
    chk("新茶饮门店开业 → B", decide_template("新茶饮门店开业")["code"], "B")
    # —— 形式词层 ——
    chk("抖音剧情带货 → C", decide_template("抖音剧情带货")["code"], "C")
    chk("小红书种草 → B", decide_template("小红书种草")["code"], "B")
    chk("母婴食品种草 → B", decide_template("母婴食品种草")["code"], "B")
    # —— 渠道层：B2B/官宣渠道归 D，消费渠道归 B ——
    chk("投 LinkedIn → D", decide_template("投 LinkedIn")["code"], "D")
    chk("领英投放 → D", decide_template("领英投放")["code"], "D")
    chk("企业官网形象片 → D", decide_template("企业官网形象片")["code"], "D")
    chk("只说TikTok → B 且兜底", decide_template("TikTok")["code"], "B")
    chk("只说TikTok 标兜底", decide_template("TikTok")["fallback"], True)
    # —— 兜底层 ——
    chk("空泛需求 → A 且兜底", decide_template("做个视频")["code"], "A")
    # —— spec ——
    chk("抖音 → 9:16", decide_spec("抖音")["ratio"], "9:16")
    chk("小红书 → 9:16", decide_spec("小红书")["ratio"], "9:16")
    chk("LinkedIn → 16:9", decide_spec("LinkedIn")["ratio"], "16:9")
    chk("B站 → 16:9", decide_spec("B站")["ratio"], "16:9")
    chk("显式 1:1", decide_spec("小红书", None, "1:1")["ratio"], "1:1")
    chk("75s 超限需拆 2 条", decide_spec("抖音", 75)["split_into"], 2)
    chk("60s 不超限", decide_spec("抖音", 60)["over_limit"], False)
    chk("61s 超限", decide_spec("抖音", 61)["over_limit"], True)
    # —— plan：一次跑完且可落盘 ——
    p1 = _plan_dict("工业传感器", "LinkedIn", 75)
    p2 = _plan_dict("工业传感器", "LinkedIn", 75)
    chk("plan 结果可重复", _plan_text(p1) == _plan_text(p2), True)
    chk("plan 含骨架 4 轴", len(p1["skeleton"]), 4)
    chk("plan 含质量门 10 项", len(p1["checklist"]), 10)
    chk("plan 自动识别渠道", _plan_dict("工业传感器，投放LinkedIn")["spec"]["ratio"], "16:9")
    # —— 输入错误必须抛 ValueError（不是 sys.exit，保证调用方可捕获）——
    for bad in (lambda: decide_template(""), lambda: decide_template("   "),
                lambda: decide_spec(""), lambda: decide_spec("抖音", 0),
                lambda: decide_spec("抖音", -5), lambda: decide_spec("抖音", "abc"),
                lambda: decide_spec("不存在的渠道"),
                lambda: decide_spec("抖音", 10 ** 9),
                lambda: decide_spec("抖音", None, "4:3"),
                lambda: decide_spec("抖音", True)):
        try:
            bad()
            cases.append(("输入错误应抛 ValueError", False, "未抛异常"))
        except ValueError:
            cases.append(("输入错误抛 ValueError", True, "ok"))
        except Exception as e:
            cases.append(("输入错误应抛 ValueError", False, "抛了 %s" % type(e).__name__))

    ok = sum(1 for _, p, _ in cases if p)
    for name, p, detail in cases:
        print("  %s %s%s" % ("PASS" if p else "FAIL", name, "" if p else "  << " + detail))
    print("-" * 60)
    print("selftest: %d/%d 通过" % (ok, len(cases)))
    return 0 if ok == len(cases) else 2


def build_parser():
    p = argparse.ArgumentParser(
        prog="video_audit.py",
        description="AI电影级短视频总导演 · 确定性裁决工具（零依赖）")
    sub = p.add_subparsers(dest="cmd")

    pl = sub.add_parser("plan", help="一次跑完：模板+技术参数+骨架+质量门（推荐入口）")
    pl.add_argument("text", help="需求文本")
    pl.add_argument("--channel", default=None,
                    help="投放渠道；不给则自动从需求文本里识别")
    pl.add_argument("--sec", type=int, default=None, help="计划总时长（秒）")
    pl.add_argument("--ratio", default=None, help="显式宽高比：9:16 / 16:9 / 1:1")
    pl.add_argument("--json", action="store_true")
    pl.add_argument("--out", default=None, help="落盘路径；不落盘则打印到标准输出")
    pl.set_defaults(func=run_plan)

    t = sub.add_parser("template", help="模板适配裁决")
    t.add_argument("text", help="需求文本")
    t.add_argument("--json", action="store_true")
    t.set_defaults(func=run_template)

    s = sub.add_parser("spec", help="技术参数裁决")
    s.add_argument("channel", help="投放渠道，如 抖音/TikTok/小红书/视频号/B站/官网/YouTube/LinkedIn")
    s.add_argument("--sec", type=int, default=None, help="计划时长（秒）")
    s.add_argument("--ratio", default=None, help="显式宽高比：9:16 / 16:9 / 1:1")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=run_spec)

    ck = sub.add_parser("checkpoint", help="查某一条质量门的通过标准与失败回补动作")
    ck.add_argument("text", help="需求文本（留档用，便于回溯）")
    ck.add_argument("--n", type=int, required=True, help="质量门编号 1-10")
    ck.add_argument("--json", action="store_true")
    ck.set_defaults(func=run_checkpoint)

    c = sub.add_parser("checklist", help="打印交付前 10 项质量门")
    c.set_defaults(func=run_checklist)

    d = sub.add_parser("demo", help="完整实战案例")
    d.set_defaults(func=run_demo)

    st = sub.add_parser("selftest", help="跑内置断言")
    st.set_defaults(func=run_selftest)
    return p


def _main(argv=None):
    p = build_parser()
    args = p.parse_args(argv)
    if not getattr(args, "cmd", None):
        p.print_help()
        return 2
    return args.func(args)


def main(argv=None):
    try:
        return _main(argv)
    except SystemExit as e:
        # argparse 遇到未知子命令/参数会 sys.exit(2)，SystemExit 是 BaseException，
        # 不被 except Exception 捕获，会直接终止进程。这里转成返回值，保证退出码封闭。
        code = e.code
        if code is None or code == 0:
            return 0
        try:
            return int(code)
        except (TypeError, ValueError):
            return 2
    except ValueError as e:
        sys.stderr.write("[错误] %s\n" % e)
        return 2
    except KeyboardInterrupt:
        sys.stderr.write("[中断] 用户取消\n")
        return 2
    except Exception as e:
        sys.stderr.write("[内部错误] %s: %s\n" % (type(e).__name__, e))
        return 3


if __name__ == "__main__":
    sys.exit(main())
