# SkillHub 技能发布验证器 - 常见问题解答

> 文档版本：v1.0.0
> 更新日期：2026-05-25
> 评测维度：基于 TRACE 五维质量标准

---

## 一、快速入门

### Q1: 如何快速验证一个 Skill？

```bash
# 基本验证
python3 validator.py --path /path/to/skill

# 严格模式（警告也视为错误）
python3 validator.py --path /path/to/skill --strict

# JSON 格式输出
python3 validator.py --path /path/to/skill --format json
```

### Q2: 验证需要多长时间？

- 简单 Skill（3-5个文件）：< 1秒
- 复杂 Skill（20+个文件）：1-3秒
- 超大 Skill（100+个文件）：5-10秒

---

## 二、验证结果解读

### Q3: pass/warning/fail 分别是什么意思？

| 状态 | 含义 | 发布准备 |
|------|------|----------|
| `pass` | 全部检查通过 | ✅ 可以发布 |
| `warning` | 有警告但无阻塞 | ⚠️ 可以发布 |
| `fail` | 存在 P0/P1 问题 | ❌ 需修复后发布 |

### Q4: P0/P1/P2 问题区别？

| 级别 | 严重程度 | 处理策略 |
|------|----------|----------|
| **P0** | 阻塞级 | 必须立即修复 |
| **P1** | 严重级 | 建议短期修复 |
| **P2** | 一般级 | 可按需修复 |

---

## 三、常见错误与修复

### Q5: 提示 "frontmatter 缺少 metadata 字段"

**原因**：SKILL.md 的 YAML frontmatter 缺少 `metadata` 字段

**修复**：在 frontmatter 中添加：
```yaml
metadata:
  execution: analysis  # 或 full/utility
```

### Q6: 提示 "identifier 格式不规范"

**原因**：Skill ID 包含大写字母或特殊字符

**修复**：使用小写字母、数字、连字符
- 错误：`My-Skill-v2`
- 正确：`my-skill-v2`

### Q7: 提示 "存在 __pycache__ 目录"

**原因**：Python 缓存目录未清理

**修复**：
```bash
find . -type d -name '__pycache__' -exec rm -rf {} +
```

### Q8: 提示 "version 格式不规范"

**原因**：版本号不符合语义化版本 (x.y.z)

**修复**：使用标准格式如 `1.0.0`、`2.1.3`

---

## 四、反模式 (千万别这么用)

### ⚠️ Q9: 这些用法是错误的

| 错误用法 | 问题 | 正确用法 |
|----------|------|----------|
| 忽略 P0 问题直接发布 | 发布被拒 | 修复所有 P0 问题 |
| 手动删除验证文件 | 可能损坏 Skill | 使用验证器修复建议 |
| 修改 validator.py 绕过检查 | 不安全 | 修复源文件问题 |

### ⚠️ Q10: 这些场景暂不支持

1. **Git 仓库验证** - 建议先克隆到本地
2. **远程 URL 验证** - 只支持本地路径
3. **加密/混淆 Skill** - 无法解析
4. **非标准结构 Skill** - 可能误报

---

## 五、最佳实践

### ✅ Q11: 提交前自检清单

```bash
# 1. 清理缓存文件
find . -name '__pycache__' -exec rm -rf {} +
find . -name '*.pyc' -delete
rm -f .DS_Store

# 2. 运行验证
python3 validator.py --path . --strict

# 3. 检查输出
# 确保 status 为 pass 或 warning
# 确保 publish_eligible 为 true
```

### ✅ Q12: 修复优先级建议

1. **首先修复 P0 问题**（阻塞发布）
2. **然后处理 P1 问题**（影响体验）
3. **最后优化 P2 问题**（锦上添花）

---

## 六、联系与反馈

### Q13: 发现验证器 bug 怎么办？

1. 检查是否使用最新版本
2. 确认 Skill 结构是否符合规范
3. 在 SkillHub 提交 Issue

---

**文档版本**：v1.0.0
**更新日期**：2026-05-25
