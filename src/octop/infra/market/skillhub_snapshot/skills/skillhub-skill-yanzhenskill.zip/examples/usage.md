# SkillHub Validator 使用示例

## 基本用法

### 1. 验证单个 Skill

```bash
python3 validator.py --path /path/to/skill
```

### 2. 严格模式（警告也视为错误）

```bash
python3 validator.py --path /path/to/skill --strict
```

### 3. JSON 格式输出

```bash
python3 validator.py --path /path/to/skill --format json
```

### 4. 验证示例 - 检查"找剧本"Skill

```bash
python3 validator.py \
  --path /Users/lin/Documents/Agents配套/Skills/剧本类/找剧本 \
  --format report
```

## 实际输出示例

### 报告格式输出

```
======================================================================
  SkillHub TRACE 验证报告 - screenplay-finder@1.2.0
======================================================================

📊 TRACE 五维度评估:
----------------------------------------------------------------------
  🔒 T - Trust 信任
     状态: ✅ 通过
     检查项: 1/1 通过, 0 失败
  ...

🎯 发布资格: ✅ 可以发布
```

### JSON 格式输出

```json
{
  "status": "pass",
  "skill_name": "screenplay-finder",
  "version": "1.2.0",
  "trace_scores": {
    "T": "pass",
    "R": "pass",
    "A": "warning",
    "C": "pass",
    "E": "warning"
  },
  "publish_eligible": true
}
```

## 常见错误修复

### 修复 __pycache__ 问题

```bash
find . -type d -name '__pycache__' -exec rm -rf {} +
```

### 修复 .DS_Store 问题

```bash
find . -name '.DS_Store' -delete
```

### 统一版本号

确保 SKILL.md、_meta.json、metadata.json 中的 version 字段一致。
