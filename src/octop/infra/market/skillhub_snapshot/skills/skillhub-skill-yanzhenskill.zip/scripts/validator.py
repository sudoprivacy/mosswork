#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validator.py - SkillHub 技能发布验证工具 v2.0.0

基于 TRACE 五维度评测体系:
- T (Trust)      信任: 安全性、国内适配性
- R (Reliability) 可靠性: 运行稳定性、异常处理、功能完善性
- A (Adaptability) 适用性: 能力边界、触发方式、使用场景
- C (Convention)  规范性: 文档分层、代码规范、FAQ
- E (Effectiveness) 有效性: 输出准确性、完整性、开箱即用度

用法:
    python3 validator.py --path /path/to/skill
    python3 validator.py --path /path/to/skill --strict
    python3 validator.py --path /path/to/skill --format json
"""

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False

# ============================================================================
# 正则表达式
# ============================================================================

VERSION_PATTERN = re.compile(r'^\d+\.\d+\.\d+$')
NAME_PATTERN = re.compile(r'^[a-z0-9-]+$')
YAML_FRONT_PATTERN = re.compile(r'^---\s*\n(.*?)\n---', re.DOTALL)
YAML_BLOCK_PATTERN = re.compile(r'^---', re.MULTILINE)

# 虚假宣传关键词（按类别分组）
FALSE_CLAIM_KEYWORDS = {
    'AI生成类': ['AI剧本生成', 'AI可执行剧本', 'ai_script_generation', '生成AI剧本', 'AI生成剧本'],
    '工具类': ['16引擎搜索', '集成搜索工具', '内置搜索引擎'],
    '执行类': ['可自动执行', '自动运行', '一键启动']
}

# ============================================================================
# 验证结果类
# ============================================================================

class CheckResult:
    """单个检查结果"""

    def __init__(self, trace_dim: str, code: str, severity: str,
                 status: str, message: str, fix_suggestion: str = ""):
        self.trace_dim = trace_dim  # T/R/A/C/E
        self.code = code
        self.severity = severity  # P0/P1/P2
        self.status = status  # pass, warning, fail
        self.message = message
        self.fix_suggestion = fix_suggestion

    def to_dict(self) -> Dict:
        return {
            "trace_dim": self.trace_dim,
            "code": self.code,
            "status": self.status,
            "severity": self.severity,
            "message": self.message,
            "fix_suggestion": self.fix_suggestion
        }


class ValidationReport:
    """完整验证报告"""

    # TRACE 维度映射
    TRACE_NAMES = {
        'T': 'Trust 信任',
        'R': 'Reliability 可靠性',
        'A': 'Adaptability 适用性',
        'C': 'Convention 规范性',
        'E': 'Effectiveness 有效性'
    }

    def __init__(self, skill_path: str):
        self.skill_path = Path(skill_path)
        self.skill_name = ""
        self.version = ""
        self.checks: List[CheckResult] = []
        self.start_time = time.time()

    def add_check(self, result: CheckResult):
        self.checks.append(result)

    def get_by_dim(self, dim: str) -> List[CheckResult]:
        """获取指定维度的所有检查"""
        return [c for c in self.checks if c.trace_dim == dim]

    def get_dim_status(self, dim: str) -> str:
        """获取维度状态"""
        results = self.get_by_dim(dim)
        if not results:
            return "skip"

        has_fail = any(r.status == "fail" for r in results)
        has_warn = any(r.status == "warning" for r in results)

        if has_fail:
            return "fail"
        elif has_warn:
            return "warning"
        return "pass"

    def get_summary(self) -> Dict:
        """获取汇总信息"""
        return {
            "total_checks": len(self.checks),
            "passed": sum(1 for c in self.checks if c.status == "pass"),
            "warnings": sum(1 for c in self.checks if c.status == "warning"),
            "failed": sum(1 for c in self.checks if c.status == "fail"),
            "by_dimension": {
                dim: {
                    "total": len(self.get_by_dim(dim)),
                    "passed": sum(1 for c in self.get_by_dim(dim) if c.status == "pass"),
                    "failed": sum(1 for c in self.get_by_dim(dim) if c.status == "fail"),
                    "status": self.get_dim_status(dim)
                }
                for dim in ['T', 'R', 'A', 'C', 'E']
            }
        }

    def is_publish_eligible(self, strict: bool = False) -> bool:
        """是否可以发布"""
        # P0 错误（fail）阻塞发布
        if any(c.status == "fail" and c.severity == "P0" for c in self.checks):
            return False

        if strict:
            # 严格模式：任何 warning 都阻塞
            return not any(c.status in ("fail", "warning") for c in self.checks)

        return True

    def get_recommendations(self) -> List[str]:
        """获取修复建议（按优先级排序）"""
        recs = []
        for c in self.checks:
            if c.status in ("fail", "warning") and c.fix_suggestion:
                recs.append(f"[{c.trace_dim}-{c.code}] {c.fix_suggestion}")
        return recs

    def to_dict(self) -> Dict:
        dim_summary = self.get_summary()["by_dimension"]

        return {
            "status": "pass" if self.is_publish_eligible() and self.get_summary()["warnings"] == 0
                      else "warning" if self.is_publish_eligible()
                      else "fail",
            "skill_name": self.skill_name,
            "version": self.version,
            "trace_results": {
                dim: {
                    "name": self.TRACE_NAMES.get(dim, dim),
                    "status": self.get_dim_status(dim),
                    "checks": len(self.get_by_dim(dim)),
                    "passed": sum(1 for c in self.get_by_dim(dim) if c.status == "pass"),
                    "failed": sum(1 for c in self.get_by_dim(dim) if c.status == "fail"),
                }
                for dim in ['T', 'R', 'A', 'C', 'E']
            },
            "checks": [c.to_dict() for c in self.checks if c.status != "pass"],
            "summary": self.get_summary(),
            "recommendations": self.get_recommendations(),
            "publish_eligible": self.is_publish_eligible(),
            "validation_time": f"{time.time() - self.start_time:.2f}s"
        }


# ============================================================================
# 验证器类
# ============================================================================

class SkillHubValidator:
    """SkillHub 发布验证器 (TRACE 五维度)"""

    def __init__(self, skill_path: str, strict_mode: bool = False):
        self.skill_path = Path(skill_path)
        self.strict_mode = strict_mode
        self.report = ValidationReport(skill_path)
        self.frontmatter: Dict = {}

    def validate(self) -> ValidationReport:
        """执行完整验证"""
        # 1. 路径检查
        if not self._check_path():
            return self.report

        # T - Trust 信任
        self._check_trust()

        # R - Reliability 可靠性
        self._check_reliability()

        # A - Adaptability 适用性
        self._check_adaptability()

        # C - Convention 规范性
        self._check_convention()

        # E - Effectiveness 有效性
        self._check_effectiveness()

        return self.report

    def _check_path(self) -> bool:
        """检查路径是否存在"""
        if not self.skill_path.exists():
            self.report.add_check(CheckResult(
                trace_dim='T', code='PATH001', severity='P0', status='fail',
                message=f"路径不存在: {self.skill_path}",
                fix_suggestion="请确认路径是否正确"
            ))
            return False

        if not self.skill_path.is_dir():
            self.report.add_check(CheckResult(
                trace_dim='T', code='PATH002', severity='P0', status='fail',
                message=f"路径不是目录: {self.skill_path}",
                fix_suggestion="请指定 Skill 的根目录"
            ))
            return False

        self.report.add_check(CheckResult(
            trace_dim='T', code='PATH000', severity='P0', status='pass',
            message="路径检查通过"
        ))
        return True

    # =========================================================================
    # T - Trust 信任
    # =========================================================================
    def _check_trust(self):
        """T - Trust: 安全性、国内适配性"""

        # 1. SKILL.md 存在性和安全性检查
        skill_md = self.skill_path / "SKILL.md"
        if not skill_md.exists():
            self.report.add_check(CheckResult(
                trace_dim='T', code='T-FM001', severity='P0', status='fail',
                message="SKILL.md 文件不存在",
                fix_suggestion="在 Skill 根目录创建 SKILL.md 文件"
            ))
            return

        # 2. 读取并解析 frontmatter
        try:
            content = skill_md.read_text(encoding='utf-8')
        except Exception as e:
            self.report.add_check(CheckResult(
                trace_dim='T', code='T-FM006', severity='P0', status='fail',
                message=f"无法读取 SKILL.md: {str(e)}",
                fix_suggestion="检查文件编码和权限"
            ))
            return

        self.frontmatter = self._parse_frontmatter(content)
        if self.frontmatter is None:
            self.report.add_check(CheckResult(
                trace_dim='T', code='T-FM003', severity='P0', status='fail',
                message="SKILL.md frontmatter 格式错误",
                fix_suggestion="确保 SKILL.md 以 --- 开头和结尾，中间为有效的 YAML"
            ))
            return

        # 3. frontmatter 必需字段检查
        required_fields = {
            "name": "Skill ID",
            "version": "版本号",
            "description": "技能描述",
            "tags": "标签数组",
            "icon": "图标",
            "author": "作者",
            "license": "许可证",
            "schema_version": "契约版本",
            "metadata": "元数据对象"
        }

        for field, desc in required_fields.items():
            if field not in self.frontmatter or not self.frontmatter[field]:
                self.report.add_check(CheckResult(
                    trace_dim='T', code='T-FM002', severity='P0', status='fail',
                    message=f"frontmatter 缺少必需字段: {field} ({desc})",
                    fix_suggestion=f"在 SKILL.md frontmatter 中添加 {field} 字段"
                ))

        # 4. name 格式检查
        name = self.frontmatter.get("name", "")
        if name:
            self.report.skill_name = name
            if not NAME_PATTERN.match(name):
                self.report.add_check(CheckResult(
                    trace_dim='T', code='T-CN001', severity='P1', status='fail',
                    message=f"Skill ID 格式错误: {name}",
                    fix_suggestion=f"改为小写字母/数字/连字符，如: {name.lower().replace('_', '-')}"
                ))

        # 5. version 格式检查
        version = self.frontmatter.get("version", "")
        if version:
            self.report.version = version
            if not VERSION_PATTERN.match(version):
                self.report.add_check(CheckResult(
                    trace_dim='T', code='T-FM004', severity='P0', status='fail',
                    message=f"version 格式错误: {version}",
                    fix_suggestion="使用 x.y.z 格式，如: 1.0.0"
                ))

        # 6. tags 检查
        tags = self.frontmatter.get("tags")
        if tags is None:
            self.report.add_check(CheckResult(
                trace_dim='T', code='T-FM005', severity='P0', status='fail',
                message="tags 字段缺失",
                fix_suggestion="添加 tags: [\"tag1\", \"tag2\"]"
            ))
        elif not isinstance(tags, list) or len(tags) == 0:
            self.report.add_check(CheckResult(
                trace_dim='T', code='T-FM005', severity='P1', status='warning',
                message="tags 为空数组",
                fix_suggestion="添加有意义的标签"
            ))

        # 7. description 长度检查
        desc = self.frontmatter.get("description", "")
        if desc and len(desc) < 10:
            self.report.add_check(CheckResult(
                trace_dim='T', code='T-DESC001', severity='P1', status='warning',
                message=f"description 过短 ({len(desc)} 字符)",
                fix_suggestion="description 应至少 50 字符，描述清楚技能功能"
            ))

        # 8. 检查禁止文件（安全性）
        forbidden = self._find_forbidden_files()
        if forbidden['pycache']:
            self.report.add_check(CheckResult(
                trace_dim='T', code='T-FL003', severity='P0', status='fail',
                message=f"存在 __pycache__ 目录 (安全风险)",
                fix_suggestion="执行: find . -type d -name '__pycache__' -exec rm -rf {} +"
            ))
        if forbidden['pyc']:
            self.report.add_check(CheckResult(
                trace_dim='T', code='T-FL004', severity='P0', status='fail',
                message=f"存在 .pyc 字节码文件 (安全风险)",
                fix_suggestion="执行: find . -name '*.pyc' -delete"
            ))

        # 9. 国内适配性检查
        self._check_domestic_adaptation()

    def _check_domestic_adaptation(self):
        """检查国内适配性"""
        # 检查是否有 requirements.txt（依赖说明）
        req_file = self.skill_path / "requirements.txt"
        has_requirements = req_file.exists()

        # 检查 Python 脚本是否使用了国内不可访问的 API
        py_files = list(self.skill_path.rglob("*.py"))
        if py_files:
            try:
                all_content = ""
                for py in py_files:
                    try:
                        all_content += py.read_text(encoding='utf-8', errors='ignore')
                    except:
                        pass

                # 检查是否依赖需要特殊网络的库
                overseas_apis = ['openai.', 'api.openai', 'anthropic.']
                uses_overseas = any(api in all_content for api in overseas_apis)

                if uses_overseas and not has_requirements:
                    self.report.add_check(CheckResult(
                        trace_dim='T', code='T-API001', severity='P1', status='warning',
                        message="使用了海外 API 但未提供依赖说明",
                        fix_suggestion="在 requirements.txt 中说明所需依赖，并提供国内替代方案"
                    ))
            except:
                pass

    # =========================================================================
    # R - Reliability 可靠性
    # =========================================================================
    def _check_reliability(self):
        """R - Reliability: 运行稳定性、异常处理、功能完善性"""

        # 1. 版本一致性检查
        version_in_md = self.frontmatter.get("version", "")

        meta_json = self.skill_path / "_meta.json"
        if meta_json.exists():
            try:
                meta_data = json.loads(meta_json.read_text(encoding='utf-8'))
                if meta_data.get("version") and meta_data.get("version") != version_in_md:
                    self.report.add_check(CheckResult(
                        trace_dim='R', code='R-VC001', severity='P1', status='fail',
                        message=f"_meta.json version ({meta_data.get('version')}) 与 SKILL.md ({version_in_md}) 不一致",
                        fix_suggestion=f"将 _meta.json 的 version 改为 {version_in_md}"
                    ))
            except:
                pass

        metadata_json = self.skill_path / "metadata.json"
        if metadata_json.exists():
            try:
                metadata_data = json.loads(metadata_json.read_text(encoding='utf-8'))
                if metadata_data.get("version") and metadata_data.get("version") != version_in_md:
                    self.report.add_check(CheckResult(
                        trace_dim='R', code='R-VC002', severity='P1', status='fail',
                        message=f"metadata.json version ({metadata_data.get('version')}) 与 SKILL.md ({version_in_md}) 不一致",
                        fix_suggestion=f"将 metadata.json 的 version 改为 {version_in_md}"
                    ))
            except:
                pass

        # 2. Python 脚本异常处理检查
        py_files = list(self.skill_path.rglob("*.py"))
        has_error_handling = False
        has_try_except = False
        has_timeout = False
        has_retry = False

        for py in py_files:
            try:
                content = py.read_text(encoding='utf-8', errors='ignore')
                if 'try:' in content or 'try :' in content:
                    has_try_except = True
                if 'except' in content:
                    has_error_handling = True
                if 'timeout' in content.lower() or 'Timeout' in content:
                    has_timeout = True
                if 'retry' in content.lower() or '重试' in content:
                    has_retry = True
            except:
                pass

        if py_files and not has_try_except:
            self.report.add_check(CheckResult(
                trace_dim='R', code='R-EX001', severity='P1', status='warning',
                message="Python 脚本缺少异常处理 (try-except)",
                fix_suggestion="为关键代码添加 try-except 异常捕获"
            ))

        if py_files and not has_timeout:
            self.report.add_check(CheckResult(
                trace_dim='R', code='R-TO001', severity='P2', status='warning',
                message="Python 脚本未设置超时处理",
                fix_suggestion="添加 timeout 机制防止无限等待"
            ))

        # 3. 文件数量和大小检查
        all_files = [f for f in self.skill_path.rglob('*') if f.is_file()]
        file_count = len(all_files)
        total_size = sum(f.stat().st_size for f in all_files)

        if file_count > 200:
            self.report.add_check(CheckResult(
                trace_dim='R', code='R-FL001', severity='P0', status='fail',
                message=f"文件数量超限: {file_count} > 200",
                fix_suggestion="删除不必要文件或拆分为多个 Skill"
            ))

        if total_size > 10 * 1024 * 1024:
            self.report.add_check(CheckResult(
                trace_dim='R', code='R-FL002', severity='P0', status='fail',
                message=f"总大小超限: {total_size/1024/1024:.1f}MB > 10MB",
                fix_suggestion="压缩或删除不必要的资源"
            ))

        # 4. 参数校验检查（如果 metadata.json 存在）
        if metadata_json.exists():
            try:
                metadata = json.loads(metadata_json.read_text(encoding='utf-8'))
                input_schema = metadata.get("input_schema", {})
                if input_schema and isinstance(input_schema, dict):
                    # 检查每个参数是否有 validation 定义
                    params_without_validation = []
                    for param_name, param_def in input_schema.items():
                        if isinstance(param_def, dict) and param_name not in ["type", "description", "required"]:
                            validation = param_def.get("validation")
                            if not validation:
                                params_without_validation.append(param_name)
                            elif not any(k in validation for k in ["minLength", "maxLength", "pattern", "enum", "min", "max", "allowedValues"]):
                                params_without_validation.append(param_name)

                    # 如果有 Python 脚本但参数缺少校验定义，给出警告
                    # 注意：format, strict_mode 等辅助参数可以不需要校验
                    critical_params = [p for p in params_without_validation if p in ["skill_path", "command", "input"]]
                    if critical_params and py_files:
                        self.report.add_check(CheckResult(
                            trace_dim='R', code='R-VAL001', severity='P2', status='warning',
                            message=f"关键参数缺少校验定义: {', '.join(critical_params)}",
                            fix_suggestion="在 input_schema 中为关键参数添加 min/max/pattern/enum 等校验规则"
                        ))
            except Exception as e:
                pass

    # =========================================================================
    # A - Adaptability 适用性
    # =========================================================================
    def _check_adaptability(self):
        """A - Adaptability: 能力边界、触发方式、使用场景"""

        # 1. 检查是否有 applicable_scenarios（使用场景定义）
        metadata_json = self.skill_path / "metadata.json"
        has_scenarios = False

        if metadata_json.exists():
            try:
                metadata = json.loads(metadata_json.read_text(encoding='utf-8'))
                if metadata.get("applicable_scenarios"):
                    has_scenarios = True
            except:
                pass

        if not has_scenarios:
            self.report.add_check(CheckResult(
                trace_dim='A', code='A-SC001', severity='P1', status='warning',
                message="缺少使用场景定义 (applicable_scenarios)",
                fix_suggestion="在 metadata.json 中添加 applicable_scenarios 说明技能适用场景"
            ))

        # 2. 检查触发方式是否清晰（search_type 或 input_schema）
        has_trigger = False
        if metadata_json.exists():
            try:
                metadata = json.loads(metadata_json.read_text(encoding='utf-8'))
                if metadata.get("input_schema") or metadata.get("search_types"):
                    has_trigger = True
            except:
                pass

        if not has_trigger and list(self.skill_path.rglob("*.py")):
            self.report.add_check(CheckResult(
                trace_dim='A', code='A-TR001', severity='P1', status='warning',
                message="缺少触发方式/输入参数定义",
                fix_suggestion="在 metadata.json 中定义清晰的 input_schema"
            ))

        # 3. 检查能力边界是否定义（key_features 或 core_capabilities）
        has_boundary = False
        if metadata_json.exists():
            try:
                metadata = json.loads(metadata_json.read_text(encoding='utf-8'))
                if metadata.get("key_features") or metadata.get("core_capabilities"):
                    has_boundary = True
            except:
                pass

        if not has_boundary:
            self.report.add_check(CheckResult(
                trace_dim='A', code='A-BD001', severity='P1', status='warning',
                message="缺少能力边界定义",
                fix_suggestion="在 metadata.json 中定义 key_features 或 core_capabilities"
            ))

        # 4. 检查是否有使用示例
        examples_dir = self.skill_path / "examples"
        has_examples = examples_dir.exists() and any(examples_dir.iterdir())

        if not has_examples:
            self.report.add_check(CheckResult(
                trace_dim='A', code='A-EX001', severity='P1', status='warning',
                message="缺少使用示例 (examples/)",
                fix_suggestion="在 examples/ 目录添加实际使用示例"
            ))

    # =========================================================================
    # C - Convention 规范性
    # =========================================================================
    def _check_convention(self):
        """C - Convention: 文档分层、代码规范、FAQ"""

        # 1. 检查文档分层（README + 详细文档）
        readme = self.skill_path / "README.md"
        has_detailed_doc = (self.skill_path / "使用指南.md").exists()

        if not readme.exists():
            self.report.add_check(CheckResult(
                trace_dim='C', code='C-DOC001', severity='P0', status='fail',
                message="缺少 README.md",
                fix_suggestion="创建 README.md 提供技能概述和使用说明"
            ))

        if readme.exists():
            try:
                readme_content = readme.read_text(encoding='utf-8')
                if len(readme_content) > 5000:
                    self.report.add_check(CheckResult(
                        trace_dim='C', code='C-DOC002', severity='P1', status='warning',
                        message=f"README.md 过长 ({len(readme_content)} 字符)，建议分层",
                        fix_suggestion="将详细说明移至使用指南.md，README.md 保持简洁"
                    ))
            except:
                pass

        # 2. 检查目录结构规范性
        expected_dirs = ['references', 'examples']
        for dir_name in expected_dirs:
            dir_path = self.skill_path / dir_name
            if not dir_path.exists():
                self.report.add_check(CheckResult(
                    trace_dim='C', code='C-STR001', severity='P2', status='warning',
                    message=f"缺少 {dir_name}/ 目录",
                    fix_suggestion=f"创建 {dir_name}/ 目录组织相关内容"
                ))

        # 3. 检查 Python 脚本 docstring
        py_files = list(self.skill_path.rglob("*.py"))
        scripts_without_docstring = []

        for py in py_files:
            try:
                content = py.read_text(encoding='utf-8', errors='ignore')
                lines = content.split('\n')[:20]  # 只检查前20行
                has_docstring = any('"""' in line or "'''" in line for line in lines)
                if not has_docstring:
                    scripts_without_docstring.append(py.name)
            except:
                pass

        if scripts_without_docstring:
            self.report.add_check(CheckResult(
                trace_dim='C', code='C-CODE001', severity='P2', status='warning',
                message=f"脚本缺少 docstring: {', '.join(scripts_without_docstring[:3])}",
                fix_suggestion="为 Python 脚本添加模块级 docstring"
            ))

        # 4. 检查是否有 FAQ 或使用限制说明
        has_faq = (self.skill_path / "FAQ.md").exists() or \
                  (self.skill_path / "使用指南.md").exists()  # 使用指南通常包含 FAQ

        # 5. 检查命名一致性
        if py_files:
            snake_case_files = [f.name for f in py_files if '_' in f.name and not f.name.startswith('_')]
            if snake_case_files:
                self.report.add_check(CheckResult(
                    trace_dim='C', code='C-NAM001', severity='P2', status='warning',
                    message=f"存在 snake_case 命名的 Python 文件: {len(snake_case_files)} 个",
                    fix_suggestion="Python 文件建议使用 snake_case 或保持一致性"
                ))

        # 6. 检查 .DS_Store
        ds_store = list(self.skill_path.rglob('.DS_Store'))
        if ds_store:
            self.report.add_check(CheckResult(
                trace_dim='C', code='C-FL005', severity='P2', status='warning',
                message=f"存在 .DS_Store 文件: {len(ds_store)} 个",
                fix_suggestion="执行: find . -name '.DS_Store' -delete"
            ))

    # =========================================================================
    # E - Effectiveness 有效性
    # =========================================================================
    def _check_effectiveness(self):
        """E - Effectiveness: 虚假宣传检测、输出准确性"""

        skill_md = self.skill_path / "SKILL.md"
        if not skill_md.exists():
            return

        try:
            content = skill_md.read_text(encoding='utf-8')
        except:
            return

        # 1. 虚假宣传检测
        false_claims = []

        # 检查文档中的声称
        for category, keywords in FALSE_CLAIM_KEYWORDS.items():
            for keyword in keywords:
                if keyword in content:
                    # 检查代码中是否有实现
                    has_impl = self._check_implementation(keyword)
                    if not has_impl:
                        false_claims.append(f"{keyword} ({category})")

        if false_claims:
            self.report.add_check(CheckResult(
                trace_dim='E', code='E-FP001', severity='P1', status='fail',
                message=f"疑似虚假宣传: {', '.join(false_claims[:3])}",
                fix_suggestion="从文档移除未实现的功能描述，或在代码中实现对应功能"
            ))

        # 2. 检查是否有输出格式定义（output_schema）
        metadata_json = self.skill_path / "metadata.json"
        has_output_schema = False

        if metadata_json.exists():
            try:
                metadata = json.loads(metadata_json.read_text(encoding='utf-8'))
                if metadata.get("output_schema"):
                    has_output_schema = True
            except:
                pass

        if not has_output_schema:
            self.report.add_check(CheckResult(
                trace_dim='E', code='E-OUT001', severity='P1', status='warning',
                message="缺少输出格式定义 (output_schema)",
                fix_suggestion="在 metadata.json 中定义 output_schema 说明输出格式"
            ))

        # 3. 检查是否有后续建议或推荐生成
        has_recommendations = False
        if metadata_json.exists():
            try:
                metadata = json.loads(metadata_json.read_text(encoding='utf-8'))
                if metadata.get("output_sections") or metadata.get("recommendations"):
                    has_recommendations = True
            except:
                pass

        if not has_recommendations:
            self.report.add_check(CheckResult(
                trace_dim='E', code='E-REC001', severity='P2', status='warning',
                message="缺少后续建议/推荐生成机制",
                fix_suggestion="在 metadata.json 中定义 output_sections 包含 recommendations"
            ))

    def _check_implementation(self, keyword: str) -> bool:
        """检查关键词是否有代码实现"""
        for py in self.skill_path.rglob('*.py'):
            try:
                content = py.read_text(encoding='utf-8', errors='ignore')
                if keyword in ['AI剧本生成', 'AI可执行剧本', '生成AI剧本']:
                    if 'def generate' in content or 'def create' in content:
                        return True
                elif keyword == '16引擎搜索':
                    if 'engines' in content.lower() and len(content) > 1000:
                        return True
                elif '可执行' in keyword or '自动' in keyword:
                    if 'def main' in content or 'if __name__' in content:
                        return True
            except:
                pass
        return False

    # =========================================================================
    # 辅助方法
    # =========================================================================
    def _find_forbidden_files(self) -> Dict:
        """查找禁止文件"""
        result = {'pycache': [], 'pyc': [], 'ds_store': []}

        for f in self.skill_path.rglob('*'):
            if not f.is_file():
                continue
            rel = f.relative_to(self.skill_path)
            if '__pycache__' in rel.parts:
                result['pycache'].append(str(rel))
            elif f.suffix == '.pyc':
                result['pyc'].append(str(rel))
            elif f.name == '.DS_Store':
                result['ds_store'].append(str(rel))

        return result

    def _parse_frontmatter(self, content: str) -> Optional[Dict]:
        """解析 YAML frontmatter"""
        match = YAML_FRONT_PATTERN.match(content)
        if not match:
            return None

        yaml_content = match.group(1)

        if HAS_YAML:
            try:
                return yaml.safe_load(yaml_content)
            except yaml.YAMLError:
                pass

        # 回退：简单解析
        return self._simple_parse(yaml_content)

    def _simple_parse(self, yaml_content: str) -> Optional[Dict]:
        """简单 YAML 解析（回退方案）"""
        result = {}
        current_key = None
        in_array = False
        array_items = []
        in_object = False
        obj_data = {}
        obj_indent = 0

        for line in yaml_content.split('\n'):
            stripped = line.strip()

            # 注释跳过
            if stripped.startswith('#'):
                continue

            # 处理数组
            if in_array:
                if stripped.startswith('- '):
                    array_items.append(stripped[2:].strip().strip('"\''))
                elif stripped and not stripped.startswith('-'):
                    in_array = False
                    result[current_key] = array_items
                    array_items = []
                    current_key = None

            # 处理对象
            if in_object:
                if stripped:
                    indent = len(line) - len(line.lstrip())
                    if indent > obj_indent:
                        if ':' in stripped:
                            parts = stripped.split(':', 1)
                            key = parts[0].strip()
                            val = parts[1].strip().strip('"\'') if len(parts) > 1 and parts[1].strip() else ""
                            if val:
                                obj_data[key] = val
                            else:
                                obj_data[key] = None
                    else:
                        in_object = False
                        result[current_key] = obj_data
                        obj_data = {}

            # 普通键值对
            if not in_array and not in_object:
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip()
                    val = parts[1].strip() if len(parts) > 1 else ""

                    # 保存之前的键
                    if current_key:
                        if in_array and array_items:
                            result[current_key] = array_items
                        elif val:
                            result[current_key] = val.strip('"\'')

                    # 检查是否为数组开始
                    if stripped.startswith('- '):
                        current_key = key
                        in_array = True
                        array_items = [stripped[2:].strip().strip('"\'')]
                    elif not val:
                        # 可能需要检查下一行
                        current_key = key
                        # 检查是否是多行对象
                        in_object = True
                        obj_data = {}
                        obj_indent = len(line) - len(line.lstrip())
                    else:
                        current_key = None
                        if val:
                            if val.startswith('[') and val.endswith(']'):
                                result[key] = [i.strip().strip('"\'') for i in val[1:-1].split(',') if i.strip()]
                            else:
                                result[key] = val.strip('"\'')

        # 处理最后一个
        if current_key:
            if in_array and array_items:
                result[current_key] = array_items
        if obj_data and current_key:
            result[current_key] = obj_data

        return result if result else None


# ============================================================================
# 命令行接口
# ============================================================================

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description='SkillHub TRACE 验证工具 v2.0.0',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
TRACE 五维度:
  T - Trust (信任)      安全性、国内适配性
  R - Reliability (可靠性) 运行稳定、异常处理
  A - Adaptability (适用性) 能力边界、触发方式
  C - Convention (规范性) 文档分层、代码规范
  E - Effectiveness (有效性) 输出准确性、无虚假宣传

示例:
  python3 validator.py --path /path/to/skill
  python3 validator.py --path /path/to/skill --strict
  python3 validator.py --path /path/to/skill --format json

返回码:
  0 - 所有检查通过
  1 - 存在警告
  2 - 存在错误（阻塞发布）
  3 - 路径不存在
        '''
    )

    parser.add_argument('--path', '-p', type=str, required=True,
                        help='要验证的 Skill 目录路径')
    parser.add_argument('--strict', '-s', action='store_true',
                        help='严格模式（警告也视为错误）')
    parser.add_argument('--format', '-f', type=str,
                        choices=['json', 'report', 'simple'],
                        default='report',
                        help='输出格式 (默认: report)')

    return parser.parse_args()


def print_report(report: ValidationReport, strict: bool = False):
    """打印报告格式输出"""
    status_emoji = {"pass": "✅", "warning": "⚠️", "fail": "❌", "skip": "➖"}
    dim_emoji = {'T': '🔒', 'R': '⚙️', 'A': '🎯', 'C': '📋', 'E': '✨'}

    summary = report.get_summary()
    dim_results = summary["by_dimension"]

    print("\n" + "=" * 70)
    print(f"  SkillHub TRACE 验证报告 - {report.skill_name or 'Unknown'}@{report.version or '?'}")
    print("=" * 70)

    # 各维度状态
    print("\n📊 TRACE 五维度评估:")
    print("-" * 70)
    for dim in ['T', 'R', 'A', 'C', 'E']:
        info = dim_results[dim]
        emoji = status_emoji.get(info["status"], "❓")
        dim_name = report.TRACE_NAMES.get(dim, dim)
        print(f"  {dim_emoji.get(dim, '•')} {dim} - {dim_name}")
        print(f"     状态: {emoji} {'通过' if info['status']=='pass' else '警告' if info['status']=='warning' else '失败' if info['status']=='fail' else '跳过'}")
        print(f"     检查项: {info['passed']}/{info['total']} 通过, {info['failed']} 失败")
        print()

    # 汇总
    print("-" * 70)
    print(f"\n📋 汇总: ✅{summary['passed']}  ⚠️{summary['warnings']}  ❌{summary['failed']}")

    publish = report.is_publish_eligible(strict)
    print(f"🎯 发布资格: {'✅ 可以发布' if publish else '❌ 不可发布'}")

    # 失败/警告详情
    failed_checks = [c for c in report.checks if c.status == "fail"]
    warn_checks = [c for c in report.checks if c.status == "warning"]

    if failed_checks:
        print(f"\n🔴 阻塞性错误 ({len(failed_checks)}):")
        for c in failed_checks[:5]:
            print(f"   [{c.trace_dim}-{c.code}] {c.message}")
            if c.fix_suggestion:
                print(f"      💡 {c.fix_suggestion}")

    if warn_checks:
        print(f"\n🟡 警告 ({len(warn_checks)}):")
        for c in warn_checks[:5]:
            print(f"   [{c.trace_dim}-{c.code}] {c.message}")
            if c.fix_suggestion:
                print(f"      💡 {c.fix_suggestion}")

    # 建议
    recs = report.get_recommendations()
    if recs:
        print(f"\n📌 修复建议 (共 {len(recs)} 条):")
        for i, rec in enumerate(recs[:5], 1):
            print(f"   {i}. {rec}")
        if len(recs) > 5:
            print(f"   ... 还有 {len(recs) - 5} 条")

    print("\n" + "=" * 70)


def print_simple(report: ValidationReport):
    """打印简单格式"""
    summary = report.get_summary()
    dim_status = "-".join(
        f"{dim}:{report.get_dim_status(dim)[0].upper()}"
        for dim in ['T', 'R', 'A', 'C', 'E']
    )
    print(f"[{report.skill_name}@{report.version}] {dim_status} "
          f"P:{summary['passed']} W:{summary['warnings']} F:{summary['failed']} "
          f"-> {'PASS' if report.is_publish_eligible() else 'FAIL'}")


def main():
    """主函数"""
    args = parse_args()

    validator = SkillHubValidator(args.path, strict_mode=args.strict)
    report = validator.validate()

    if args.format == 'json':
        print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
    elif args.format == 'simple':
        print_simple(report)
    else:
        print_report(report, strict=args.strict)

    # 返回码
    summary = report.get_summary()

    if summary['failed'] > 0:
        sys.exit(2)
    elif summary['warnings'] > 0:
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == '__main__':
    main()
