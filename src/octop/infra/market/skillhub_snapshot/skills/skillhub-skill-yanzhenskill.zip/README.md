# SkillHub 技能发布验证器 v1.0.0

> 独立版 - 可分发给任何电脑使用

## 简介

SkillHub 技能发布验证器，用于自动化检测目标 Skill 是否符合 SkillHub 发布规范。

### 核心功能

- ✅ **Frontmatter 验证** - 检查 SKILL.md YAML frontmatter 完整性
- ✅ **文件规范检查** - 文件数量、大小、禁止文件检测
- ✅ **内容规范检查** - 版本一致性、虚假宣传检测
- ✅ **命名规范检查** - Skill ID 格式验证
- ✅ **详细报告生成** - 结构化修复建议

---

## 快速开始

### 1. 基本用法

```bash
# 验证单个 Skill
python3 validator.py --path /path/to/skill

# 验证并使用严格模式
python3 validator.py --path /path/to/skill --strict

# JSON 格式输出
python3 validator.py --path /path/to/skill --format json
```

### 2. 验证示例

```bash
# 验证找剧本 Skill
python3 validator.py --path /Users/lin/Documents/Agents配套/Skills/剧本类/找剧本
```

---

## 输出格式

### 报告格式 (默认)

```
============================================================
SkillHub 发布验证报告 - screenplay-finder
============================================================

📊 验证结果: ✅ 通过

📋 检查汇总:
   通过: 20
   警告: 0
   失败: 0

🎯 发布资格: ✅ 可以发布
```

### JSON 格式

```json
{
  "status": "pass",
  "skill_name": "screenplay-finder",
  "version": "1.2.0",
  "checks": {...},
  "summary": {
    "total_checks": 20,
    "passed": 20,
    "warnings": 0,
    "failed": 0
  },
  "publish_eligible": true
}
```

---

## 返回码

| 返回码 | 含义 |
|--------|------|
| 0 | 所有检查通过，可以发布 |
| 1 | 存在警告，建议修复 |
| 2 | 存在错误，阻塞发布 |
| 3 | 路径不存在或无法访问 |

---

## 验证规则

### Frontmatter 必需字段

| 字段 | 说明 |
|------|------|
| name | Skill ID (小写字母/数字/连字符) |
| version | 版本号 (x.y.z 格式) |
| description | 技能描述 |
| tags | 标签数组 |
| icon | emoji 图标 |
| author | 作者 |
| license | 许可证 (推荐 MIT) |
| schema_version | 契约版本 (固定为 1.0) |
| metadata | 元数据对象 |

### 文件规范

| 检查项 | 标准 |
|--------|------|
| 文件数量 | < 200 |
| 总大小 | < 10MB |
| __pycache__ | 不存在 |
| .pyc 文件 | 不存在 |

---

## 错误代码

| 前缀 | 说明 |
|------|------|
| FM | Frontmatter 相关 |
| FL | File 规范相关 |
| CN | Naming 命名相关 |
| VC | Version 版本一致性 |
| FP | False Claims 虚假宣传 |

---

## 版本信息

- **版本**: 1.0.0
- **更新日期**: 2026-05-25
- **作者**: Claude Code

---

## 许可证

MIT License
