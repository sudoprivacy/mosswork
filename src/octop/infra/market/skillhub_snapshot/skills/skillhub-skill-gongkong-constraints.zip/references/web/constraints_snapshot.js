// 自动生成，请勿手改：由 serve.py / gk_constraints.py 写库时同步刷新。
// 用途：双击 web/index.html 且未启动 serve.py 时的离线只读预览数据。
window.GK_SNAPSHOT = {
  "generatedAt": "2026-11-13",
  "source": "references/constraints_data.json",
  "constraints": [
    {
      "id": "SAFE-01",
      "category": "安全铁律",
      "title": "安全回路黑名单",
      "rule": "急停、安全门、安全继电器、硬件限位等安全回路禁止接入任何远程手动控制清单，一律写入黑名单；上位机、HMI、孪生均不得下发。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "SAFE-02",
      "category": "安全铁律",
      "title": "安全类 DB 与逻辑块禁止上位机/HMI 写入",
      "rule": "安全类 DB 与安全逻辑块只在 PLC 内部处理，禁止被上位机或 HMI 写入。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "SAFE-03",
      "category": "安全铁律",
      "title": "指令只是请求",
      "rule": "所有手动指令只是动作请求；能否执行、是否被本地抢占、是否联锁禁止，全部由 PLC 判定。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "SAFE-04",
      "category": "安全铁律",
      "title": "点动超时在 PLC 内",
      "rule": "点动最长运行超时保护必须写在 PLC 内，参数放参数区可配置，默认 5 秒；上位机卡死或断网时 PLC 按超时自动切断输出。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.1/§2.3/§3.6",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "SAFE-05",
      "category": "安全铁律",
      "title": "断线冻结不补发",
      "rule": "通信断开时所有指令入口自动禁用，画面冻结在最后一次读到的状态，恢复后自动同步真实状态，且不自动补发任何指令。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "SAFE-06",
      "category": "安全铁律",
      "title": "本地手动优先",
      "rule": "本地 HMI 手动优先级高于上位机远程手动，也高于上位机孪生交互；同一时刻只允许一个操作源有效。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "SAFE-07",
      "category": "安全铁律",
      "title": "统一握手闭环",
      "rule": "所有跨端动作统一走握手：请求方置位 Cmd → PLC 上升沿执行 → 置位 Ack → 请求方读 Ack 复位 Cmd → PLC 复位 Ack。无握手的单点脉冲指令禁止使用。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.3",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "COMMON-01",
      "category": "公共基础",
      "title": "AI 与人工分工：不覆盖人工布局",
      "rule": "AI 生成初始骨架；人工维护配置。AI 初次生成后，迭代不得整体覆盖人工改过的布局清单，只能输出差异清单由人工合并。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §1.5",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "COMMON-02",
      "category": "公共基础",
      "title": "布局清单驱动界面",
      "rule": "普通控件/工艺流程元素/孪生图元/总览卡片全部由清单驱动，工厂按清单生成；硬代码不零散实例化，坐标/文字/阈值/绑定不硬编码。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §5.3/§5.4/§6.2/§7.3",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "COMMON-03",
      "category": "公共基础",
      "title": "启动布局校验",
      "rule": "程序启动先跑布局校验，不通过则弹窗列错误清单并终止加载，不允许带病运行（唯一键重复、绑定变量须存在、引用须存在、坐标不越界、枚举合法）。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.8",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "COMMON-04",
      "category": "公共基础",
      "title": "全局颜色规范",
      "rule": "颜色定义在全局配置，禁止代码散落硬编码：空闲灰#888888 / 运行绿#22BB22 / 预警黄#FFBB22 / 故障红#DD2222 / 手动蓝#2288DD。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.6",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "COMMON-05",
      "category": "公共基础",
      "title": "整块周期读、禁止高频单点轮询",
      "rule": "通信按 DB 整块批量周期读取，默认周期 500ms；禁止高频单点轮询；写操作只发生在用户动作时。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.3/§5.8/§6.3",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "COMMON-06",
      "category": "公共基础",
      "title": "报警编码全局统一",
      "rule": "报警编码全局统一为「模块号+故障编号」整数形式；报警文本字典三方（HMI/上位机/孪生）共用同一份，保证显示一致。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.5",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLC-01",
      "category": "PLC",
      "title": "SCL 优先与功能块分层",
      "rule": "编程语言以 SCL 优先，采用 FB/FC 结构化编程，禁止单块堆叠大量线性程序。功能块固定分层：FB_Safety(最高)>FB_Mode>FB_Alarm(高)>FB_Auto/FB_Manual/FB_Axis/FB_IO/FB_Comm(中)>FB_Recipe(低)。层名不得随意更改。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §3.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLC-02",
      "category": "PLC",
      "title": "变量命名三段式",
      "rule": "英文大驼峰，禁止中文变量名，按「前缀_对象_功能」三段式。前缀固定：Cmd_/Ack_/Di_/Do_/Ai_/Ao_/Set_/St_/Fb_/T_/C_/Alm_/Warn_，跨项目不得私自扩展含义。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §3.2",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLC-03",
      "category": "PLC",
      "title": "数据块划分固定",
      "rule": "DB 划分固定：DB_Global/DB_CmdFromHmi/DB_CmdFromScada/DB_ScadaManualCtrl/DB_Param/DB_Status/DB_Alarm/DB_Diag；对外交互点位不得零散分布在各 FB 背景数据。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §3.2",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLC-04",
      "category": "PLC",
      "title": "上位机与 HMI 指令区物理分离",
      "rule": "上位机指令区与 HMI 指令区必须物理分离；当二者对同一设备同时下发请求时，PLC 拒绝上位机请求并置位多方同时操作报警，不得两个请求同时生效。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §3.2/§3.6",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLC-05",
      "category": "PLC",
      "title": "状态码约定",
      "rule": "状态码整数固定取值：0空闲/1运行/2暂停/3故障/4调试；布尔用 Bool；设定值与工程量用浮点（mm、mm/s、℃、Pa）；报警编码用无符号整数。时间常量不写死，进参数区。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §3.3",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLC-06",
      "category": "PLC",
      "title": "IO 软件滤波",
      "rule": "数字量与模拟量输入必须做软件滤波，默认防抖 50ms，滤波时长参数化可调。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §3.4",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLC-07",
      "category": "PLC",
      "title": "通信看门狗三路独立",
      "rule": "PLC 内部设通信看门狗；上位机心跳超时默认 3s 置位通信丢失预警，自动流程转暂停保留状态，不直接急停（是否升级停机由配置决定）。HMI 心跳/上位机心跳/PLC 看门狗三路相互独立。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §3.5",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLC-08",
      "category": "PLC",
      "title": "远程手动仲裁层",
      "rule": "上位机全控件手动操作必须建 PLC 仲裁层：总允许位仅 HMI 可写（上位机只读）；HMI 本地手动激活时拒绝上位机并置冲突报警；每路受控输出绑定工艺联锁，不满足即拒绝；点动超时 PLC 计时切断；安全类输出永不进手动列表（黑名单）。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §3.6",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "HMI-01",
      "category": "HMI",
      "title": "HMI 与上位机独立客户端",
      "rule": "HMI 与上位机是两个独立客户端，各自与 PLC 建连、各自独立心跳；HMI 不得转发上位机指令，上位机也不得经 HMI 中转。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §4",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "HMI-02",
      "category": "HMI",
      "title": "按钮走握手、参数双校验",
      "rule": "所有按钮不直接置位线圈，一律走握手信号；参数输入框 HMI 侧做上下限前置校验，PLC 侧二次校验，超限拒绝写入并提示。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §4.2",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "HMI-03",
      "category": "HMI",
      "title": "工艺画面只做流转",
      "rule": "HMI 工艺流程画面只展示工序流转，不承担时序判断；只允许工序级启停按钮，机构点动与单点调试按钮一律放监控面板，不得放入工艺画面。工序编号/变量绑定/状态定义须与上位机工艺图一致。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §4.3",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "CS-01",
      "category": "上位机(C#)",
      "title": "三层架构",
      "rule": "界面层(只展示与采集输入，不写 PLC 读写)→业务逻辑层(指令封装/参数校验/握手状态管理)→驱动服务层(只读写，不含业务判断)；配置/报警/日志/配方/刷新五类服务。禁止在按钮点击事件里直接调用读写方法，统一走指令助手。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §5.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "CS-02",
      "category": "上位机(C#)",
      "title": "纯代码 UI 与控件元数据",
      "rule": "界面不使用设计器拖拽，全部由代码动态创建；每个业务控件必须挂载强类型 UiControlMeta（业务键全局唯一、页面/分组、绑定 PLC 变量与 DB、业务类型、权限标记、备注）。业务键是检索主键。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §5.2",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "CS-03",
      "category": "上位机(C#)",
      "title": "控件命名规范化",
      "rule": "控件原生名称格式「界面_控件类型_业务标识」，控件类型缩写固定：按钮Btn/指示灯Led/数值框Num/文本框Txt/下拉框Cbx/面板Pnl/分组框Grp/页签Tab。装饰性标签与分割线不纳入检索池。",
      "severity": "should",
      "source": "SPEC-CTRL-2026-001 §5.2/附录C",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "CS-04",
      "category": "上位机(C#)",
      "title": "表格布局容器",
      "rule": "页面内固定使用表格布局容器，不使用流式布局；行列坐标是唯一布局坐标，便于后期对齐与局部调整。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §5.3",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "CS-05",
      "category": "上位机(C#)",
      "title": "工厂/检索器/校验器",
      "rule": "工厂按清单生成控件、统一样式、自动挂载元数据、注册检索器、绑定统一点击回调。检索器维护业务键→控件字典（常数级查找），支持按业务键/PLC变量/页面分组/业务类型查找与导出。校验器启动时检查唯一键重复、无效绑定、越界坐标、非法枚举。禁止在业务代码写死控件名称字符串。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §5.4",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "CS-06",
      "category": "上位机(C#)",
      "title": "控件不主动读 PLC",
      "rule": "控件不主动读 PLC；通信线程按周期批量读 DB 更新缓存，刷新服务按 PLC 变量名检索所有绑定控件统一更新显示与颜色。按钮点击只从元数据取点位与 DB 交指令助手。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §5.5",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "CS-07",
      "category": "上位机(C#)",
      "title": "远程手动面板隔离",
      "rule": "远程手动面板单独成页，与自动监控页完全隔离，仅管理员可见；顶部固定状态条显示授权/被抢占/通信/联锁状态；每路独立卡片含反馈状态、开/关或点动、锁定与联锁禁止标记；被拒请求必须生成预警日志并弹窗，不得静默失败。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §5.6",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "CS-08",
      "category": "上位机(C#)",
      "title": "断线重连指数退避",
      "rule": "驱动实例全局单例，按站点分别创建；心跳线程独立，默认 500ms 读，超时 3s 判断线。断线重连指数退避 1/2/4/5s 上限。读写返回码区分成功/失败/超时/断开并逐条入日志；所有读写包裹异常捕获，禁止未捕获异常导致程序退出。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §5.8",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "TWIN-01",
      "category": "数字孪生",
      "title": "孪生定位与边界",
      "rule": "孪生是可视化图层，与常规监控面板并列，不替代后者；表达设备本体/机构动作/位移旋转，与工艺流程工序流转是两种视图，不得合并到同一标签页。孪生不承担任何联锁判断与工艺时序，点击同样只是请求，最终由 PLC 仲裁。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §6.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "TWIN-02",
      "category": "数字孪生",
      "title": "图元清单驱动与映射规则",
      "rule": "画布二维矢量代码绘制，不使用设计器堆叠图元；图元由清单驱动，映射规则单独成表集中管理，多图元可复用同一条规则。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §6.2",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "TWIN-03",
      "category": "数字孪生",
      "title": "渲染循环独立解耦",
      "rule": "图元实现统一接口（绘制/按值更新/点击命中检测）；渲染循环独立计时默认 30 帧，与 PLC 读取周期解耦，插值平滑在孪生层完成，禁止在渲染循环内读写 PLC。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §6.3",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "TWIN-04",
      "category": "数字孪生",
      "title": "孪生交互安全",
      "rule": "点击图元先做命中检测，再依次校验权限、远程手动总允许位、本地手动抢占标记，通过后才走指令助手握手；点动按下置请求、松开复位，超时保护仍在 PLC。只读图元交互类型设无。断线冻结最后状态，按钮自动禁用。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §6.4",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "TWIN-05",
      "category": "数字孪生",
      "title": "图层与资源",
      "rule": "图元增加图层字段（0背景/1设备/2上层交互），可单独开关图层；矢量与位图资源统一放资产目录，清单只写资源标识不写绝对路径。",
      "severity": "should",
      "source": "SPEC-CTRL-2026-001 §6.5",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "MULTI-01",
      "category": "多站点",
      "title": "站点独立隔离",
      "rule": "每台 PLC 是独立站点（StationId+中文StationName）；通信实例/点位缓存/握手状态/报警/日志/远程手动授权全部独立；一个站点断网或故障不得影响其他站点。停用某 PLC 只需启用开关置 false。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §2.2/§7",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "MULTI-02",
      "category": "多站点",
      "title": "总览+详情固定结构",
      "rule": "所有站点在同一主界面汇总，每站点有独立详情界面；总览页固定唯一、卡片排列启用站点；详情页按子标签组织（监控/工艺/孪生/参数/报警），上下文锁定该站点。禁止一个按钮同时向多台 PLC 下发动作，批量动作须单独批量确认面板并日志标记。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §7",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "MULTI-03",
      "category": "多站点",
      "title": "跨站点联动在 PLC",
      "rule": "跨站点联动逻辑不得写上位机，应写在 PLC 或单独上层调度 PLC；上位机只做展示。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §7.5",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLAN-01",
      "category": "方案裁剪",
      "title": "五套方案组成",
      "rule": "A 触摸屏+PLC(无上位机/无孪生)；B 上位机+PLC(无HMI/无孪生)；C 上位机+HMI+PLC(无孪生)；D 孪生+PLC+触摸屏(独立孪生,无中控上位机)；E 全套(上位机三套页面+HMI两套页面)。启动时先定方案，只生成该方案模块。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §1.4/§8/§10.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLAN-02",
      "category": "方案裁剪",
      "title": "模块开关为假则不生成",
      "rule": "任何方案在模块开关为假时，直接不生成对应页面与服务，不允许生成后靠运行时判断跳过。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §10.1",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "PLAN-03",
      "category": "方案裁剪",
      "title": "E 方案三级操作优先级",
      "rule": "方案 E 三级操作优先级由 PLC 实现：本地 HMI 手动最高 > 上位机孪生交互 > 上位机工艺图按钮 > 上位机监控面板远程手动。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §8.5",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "NAMING-01",
      "category": "命名缩写",
      "title": "控件命名缩写表",
      "rule": "Btn按钮/Led指示灯/Num数值输入框/Txt文本框/Cbx下拉框/Pnl面板/Grp分组框/Tab页签。适用于界面_控件类型_业务标识命名。",
      "severity": "should",
      "source": "SPEC-CTRL-2026-001 附录C",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "MAINT-01",
      "category": "维护禁止项",
      "title": "维护红线",
      "rule": "禁止：在窗体构造函数零散创建按钮脱离清单；同一唯一键多条目复用；只注释创建代码不删布局条目；把行列坐标写死在工厂代码；手动改检索器内部字典；在工艺图/孪生画布放机构点动按钮。",
      "severity": "must",
      "source": "SPEC-CTRL-2026-001 §9.3",
      "project": "",
      "createdAt": "2026-11-12"
    },
    {
      "id": "MAINT-02",
      "category": "维护禁止项",
      "title": "配置纳入版本管理",
      "rule": "配置清单、站点列表、报警字典全部纳入版本管理；每次修改布局提交说明写清页面/分组/新增或删除或移动的设备；回滚直接回退配置版本，不需重新生成代码。",
      "severity": "should",
      "source": "SPEC-CTRL-2026-001 §9.4",
      "project": "",
      "createdAt": "2026-11-12"
    }
  ]
};
