/* 工控统一开发约束集 · 本地管理门户（纯本地，零外部依赖）
 * ---------------------------------------------------------------
 * 三种运行方式，自动探测，无需配置：
 *   1. python3 web/serve.py  → http://localhost:8765   完整读写（推荐）
 *   2. 双击 web/index.html   → file://                 离线只读预览（用随包快照）
 *   3. 把 web/ 放到任意静态服务器                      完整读写（需该服务器实现 /api）
 * 权威源恒为技能包 references/constraints_data.json；不联网、不依赖任何云服务。
 */
(function () {
  "use strict";

  var all = [];
  var mode = "probing";   // "local" 可读写 | "snapshot" 只读 | "empty" 无数据
  var editingId = null;

  function $(id) { return document.getElementById(id); }
  function toast(msg) {
    var t = $("toast"); if (!t) return;
    t.textContent = msg; t.classList.add("show");
    setTimeout(function () { t.classList.remove("show"); }, 2400);
  }
  function setState(txt, color) {
    var s = $("connState"); if (!s) return;
    s.textContent = txt; s.style.color = color || "#6b7280";
  }
  function sevText(s) { return s === "must" ? "铁律" : (s === "should" ? "推荐" : "可选"); }
  function created(r) { return String(r.createdAt || r.created_at || "").slice(0, 10); }
  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (m) {
      return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[m];
    });
  }
  function isWritable() { return mode === "local"; }

  /* ---------- 模式探测 ---------- */
  function probe() {
    // file:// 下不发 fetch，直接用随包快照
    if (location.protocol === "file:") {
      return Promise.resolve(useSnapshot());
    }
    return fetch("/api/health", { method: "GET" })
      .then(function (r) { return r.ok ? r.json() : Promise.reject(new Error("http " + r.status)); })
      .then(function () { mode = "local"; return null; })
      .catch(function () { return useSnapshot(); });
  }
  function useSnapshot() {
    var snap = window.GK_SNAPSHOT;
    if (snap && Array.isArray(snap.constraints) && snap.constraints.length) {
      mode = "snapshot";
      return snap.constraints.map(function (r) {
        var o = {}; for (var k in r) if (Object.prototype.hasOwnProperty.call(r, k)) o[k] = r[k];
        return o;
      });
    }
    mode = "empty";
    return [];
  }

  /* ---------- 数据层（仅本地模式可写） ---------- */
  function apiList() {
    if (mode === "local") {
      return fetch("/api/constraints").then(function (r) { return r.json(); })
        .then(function (j) { return { data: j.constraints || [], error: null }; })
        .catch(function (e) { return { data: [], error: e }; });
    }
    return Promise.resolve({ data: [], error: null });
  }
  function apiAdd(p) {
    return fetch("/api/constraints", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(p)
    }).then(function (r) { return r.json(); })
      .then(function (j) { return { data: j.data || null, error: j.error || null }; });
  }
  function apiUpdate(id, p) {
    return fetch("/api/constraints/" + encodeURIComponent(id), {
      method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(p)
    }).then(function (r) { return r.json(); })
      .then(function (j) { return { data: j.data || null, error: j.error || null }; });
  }
  function apiDelete(id) {
    return fetch("/api/constraints/" + encodeURIComponent(id), { method: "DELETE" })
      .then(function (r) { return r.json(); })
      .then(function (j) { return { data: j.data || null, error: j.error || null }; });
  }
  function apiImport(rows) {
    return fetch("/api/import", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ constraints: rows })
    }).then(function (r) { return r.json(); })
      .then(function (j) { return { error: j.error || null, added: j.added }; });
  }

  /* ---------- 渲染 ---------- */
  function load() {
    apiList().then(function (res) {
      if (res.error) {
        $("list").innerHTML = '<div class="empty">读取失败：' + escapeHtml(res.error.message || res.error) +
          '<br/><small>请确认已运行 <code>python3 web/serve.py</code> 并刷新页面。</small></div>';
        setState("读取失败", "#DD2222");
        return;
      }
      all = res.data;
      applyModeUI();
      fillCategories(); render();
    }).catch(function (e) {
      $("list").innerHTML = '<div class="empty">读取错误：' + escapeHtml(e) + "</div>";
      setState("读取失败", "#DD2222");
    });
  }
  function applyModeUI() {
    var w = isWritable();
    var banner = $("modeBanner");
    if (w) {
      setState("● 本地读写模式（serve.py）", "#22BB22");
      if (banner) banner.style.display = "none";
    } else if (mode === "snapshot") {
      setState("● 离线只读预览", "#FFBB22");
      if (banner) {
        banner.style.display = "block";
        banner.innerHTML = "当前为<b>离线只读预览</b>（数据来自随包快照，可能不是最新）。" +
          "要新增 / 编辑 / 删除 / 导入，请在本目录运行 <code>python3 serve.py</code> 后打开 " +
          "<code>http://localhost:8765</code>；导出与筛选在只读模式下同样可用。";
      }
    } else {
      setState("● 未找到数据", "#DD2222");
      if (banner) {
        banner.style.display = "block";
        banner.innerHTML = "未找到约束数据。请运行 <code>python3 serve.py</code> 启动本地服务，" +
          "或确认 <code>constraints_snapshot.js</code> 随技能包一起提供。";
      }
    }
    ["btnAdd", "fileImport"].forEach(function (id) {
      var el = $(id); if (el) { el.disabled = !w; el.style.opacity = w ? "1" : "0.45"; }
    });
    var lbl = $("importLabel");
    if (lbl) { lbl.style.opacity = w ? "1" : "0.45"; lbl.title = w ? "" : "只读模式下不可用，请先启动 serve.py"; }
  }
  function fillCategories() {
    var sel = $("fCategory"); if (!sel) return;
    var cur = sel.value;
    var cats = {}; all.forEach(function (c) { if (c.category) cats[c.category] = 1; });
    sel.innerHTML = '<option value="">全部分类</option>' +
      Object.keys(cats).sort().map(function (k) {
        return '<option value="' + escapeHtml(k) + '">' + escapeHtml(k) + "</option>";
      }).join("");
    sel.value = cur;
  }
  function render() {
    var q = ($("search").value || "").trim().toLowerCase();
    var fc = $("fCategory").value, fs = $("fSeverity").value;
    var rows = all.filter(function (c) {
      if (fc && c.category !== fc) return false;
      if (fs && c.severity !== fs) return false;
      if (q) {
        var hay = ((c.id || "") + " " + (c.title || "") + " " + (c.rule || "") + " " +
                   (c.category || "") + " " + (c.project || "")).toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });
    var mustN = all.filter(function (c) { return c.severity === "must"; }).length;
    var cats = {}; all.forEach(function (c) { if (c.category) cats[c.category] = 1; });
    $("stats").innerHTML = stat(all.length, "条约束") + stat(mustN, "铁律") + stat(Object.keys(cats).length, "分类");
    if (!rows.length) {
      $("list").innerHTML = '<div class="empty">没有匹配的约束。可调整筛选条件，或' +
        (isWritable() ? '点击「+ 新增约束」/「导入 JSON」' : '启动 serve.py 后新增') + '。</div>';
      return;
    }
    $("list").innerHTML = rows.map(card).join("");
    rows.forEach(function (c) {
      var key = c.id || c._id || "";
      var e = document.querySelector('[data-edit="' + cssEscape(key) + '"]');
      var d = document.querySelector('[data-del="' + cssEscape(key) + '"]');
      if (e) e.onclick = function () { openModal(c); };
      if (d) d.onclick = function () { del(c); };
    });
  }
  function cssEscape(s) { return String(s).replace(/["\\]/g, "\\$&"); }
  function stat(n, label) { return '<div class="stat"><b>' + n + "</b><span>" + label + "</span></div>"; }
  function card(c) {
    var key = c.id || c._id || "";
    var acts = isWritable()
      ? '<div class="acts"><button data-edit="' + escapeHtml(key) + '">编辑</button>' +
        '<button class="danger" data-del="' + escapeHtml(key) + '">删除</button></div>'
      : "";
    return '<div class="card"><div class="top">' +
      '<span class="badge ' + (c.severity || "may") + '">' + sevText(c.severity) + "</span>" +
      '<span class="cat">' + escapeHtml(c.category || "未分类") + "</span>" +
      '<span class="cid">' + escapeHtml(key) + "</span></div>" +
      "<h3>" + escapeHtml(c.title || "(无标题)") + "</h3>" +
      '<div class="rule">' + escapeHtml(c.rule || "") + "</div>" +
      '<div class="meta"><span>来源：' + escapeHtml(c.source || "—") + "</span>" +
      "<span>项目：" + escapeHtml(c.project || "—") + "</span>" +
      "<span>创建：" + escapeHtml(created(c) || "—") + "</span></div>" + acts + "</div>";
  }

  /* ---------- 表单与操作 ---------- */
  function openModal(c) {
    if (!isWritable()) { toast("只读预览模式不可编辑，请先启动 serve.py"); return; }
    editingId = c ? (c.id || c._id || null) : null;
    $("modalTitle").textContent = c ? "编辑约束" : "新增约束";
    $("mCategory").value = c ? (c.category || "") : "";
    $("mTitle").value = c ? (c.title || "") : "";
    $("mRule").value = c ? (c.rule || "") : "";
    $("mSeverity").value = c ? (c.severity || "should") : "should";
    $("mProject").value = c ? (c.project || "") : "";
    $("mSource").value = c ? (c.source || "") : "";
    $("mErr").textContent = "";
    $("mask").style.display = "flex";
  }
  function closeModal() { $("mask").style.display = "none"; editingId = null; }
  function save() {
    var payload = {
      category: $("mCategory").value.trim(), title: $("mTitle").value.trim(),
      rule: $("mRule").value.trim(), severity: $("mSeverity").value,
      project: $("mProject").value.trim(),
      source: $("mSource").value.trim() || "本地界面"
    };
    if (!payload.category || !payload.title || !payload.rule) {
      $("mErr").textContent = "分类、标题、规则正文均为必填。"; return;
    }
    var isEdit = editingId != null;
    var p = isEdit ? apiUpdate(editingId, payload) : apiAdd(payload);
    p.then(function (res) {
      if (res.error) { $("mErr").textContent = "保存失败：" + (res.error.message || res.error); return; }
      closeModal(); toast(isEdit ? "已更新" : "已新增"); load();
    }).catch(function (e) { $("mErr").textContent = "保存失败：" + e; });
  }
  function del(c) {
    if (!isWritable()) { toast("只读预览模式不可删除"); return; }
    var key = c.id || c._id;
    if (!confirm("确认删除约束 [" + (c.title || key) + "] ？此操作不可撤销。")) return;
    apiDelete(key).then(function (res) {
      if (res.error) { toast("删除失败：" + (res.error.message || res.error)); return; }
      toast("已删除"); load();
    }).catch(function (e) { toast("删除失败：" + e); });
  }
  function exportJson() {
    var rows = all.map(function (c) {
      return {
        id: c.id, category: c.category, title: c.title, rule: c.rule,
        severity: c.severity, source: c.source, project: c.project,
        createdAt: created(c)
      };
    });
    var data = JSON.stringify({
      exportedAt: new Date().toISOString().slice(0, 10),
      from: "gongkong-constraints web", constraints: rows
    }, null, 2);
    var blob = new Blob([data], { type: "application/json" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "gk_constraints_export.json";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    toast("已导出 " + rows.length + " 条");
  }
  function importJson(file) {
    if (!isWritable()) { toast("只读预览模式不可导入，请先启动 serve.py"); return; }
    var reader = new FileReader();
    reader.onerror = function () { toast("文件读取失败，请确认文件可访问"); };
    reader.onload = function () {
      var payload;
      try { payload = JSON.parse(reader.result); }
      catch (e) { toast("JSON 解析失败：文件可能已损坏或被截断"); return; }
      var rows = (payload && (payload.constraints || payload.data)) || [];
      if (!Array.isArray(rows)) { toast("格式不正确：未找到 constraints 数组"); return; }
      var valid = rows.filter(function (r) { return r && r.category && r.title && r.rule; });
      if (!valid.length) { toast("没有可用的约束条目（需含 category/title/rule）"); return; }
      if (valid.length < rows.length) toast("已跳过 " + (rows.length - valid.length) + " 条不完整记录");
      apiImport(valid).then(function (res) {
        if (res.error) { toast("导入失败：" + (res.error.message || res.error)); return; }
        toast("已导入 " + (res.added != null ? res.added : valid.length) + " 条（重复项自动跳过）");
        load();
      }).catch(function (e) { toast("导入失败：" + e); });
    };
    reader.readAsText(file);
  }

  /* ---------- 事件绑定 ---------- */
  $("btnAdd").onclick = function () { openModal(null); };
  $("btnCancel").onclick = closeModal;
  $("btnSave").onclick = save;
  $("btnRefresh").onclick = load;
  $("btnExport").onclick = exportJson;
  $("fileImport").onchange = function (e) { if (e.target.files[0]) importJson(e.target.files[0]); e.target.value = ""; };
  $("search").oninput = render;
  $("fCategory").onchange = render;
  $("fSeverity").onchange = render;
  $("mask").onclick = function (e) { if (e.target === $("mask")) closeModal(); };
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeModal(); });

  /* ---------- 启动 ---------- */
  probe().then(function (snapshotRows) {
    if (snapshotRows && snapshotRows.length) all = snapshotRows;
    applyModeUI();
    if (mode === "local") { load(); }
    else { fillCategories(); render(); }
  }).catch(function (e) {
    setState("初始化失败", "#DD2222");
    $("list").innerHTML = '<div class="empty">初始化失败：' + escapeHtml(e) + "</div>";
  });
})();
