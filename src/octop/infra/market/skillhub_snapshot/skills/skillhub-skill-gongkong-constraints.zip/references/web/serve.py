#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工控统一开发约束集 · 本地管理接口服务（纯标准库，零第三方依赖、零联网）
================================================================
启动后在浏览器打开 http://localhost:8765 即可查看/新增/编辑/删除/导入/导出约束。

本服务直接读写技能唯一权威源：
    <技能根>/references/constraints_data.json
路径按「本文件所在目录」推导，因此技能包解压到任意位置、换机器都能用。

用法：
  python3 serve.py                       # 默认 8765
  python3 serve.py --port 9000
  python3 serve.py --store <约束库JSON>  # 显式指定权威源
  python3 serve.py --open                # 启动后自动打开浏览器

不启动本服务时，双击 web/index.html 仍可用「随包快照」做离线只读预览。
"""
import argparse
import json
import os
import re
import sys
import webbrowser
from datetime import date
from functools import partial
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, unquote

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT = os.path.dirname(HERE)
# 关键修复：按技能包相对位置推导，而不是写死 ~/.workbuddy/...（换机/解压即失效）
DEFAULT_STORE = os.path.join(SKILL_ROOT, "references", "constraints_data.json")
SNAPSHOT = os.path.join(HERE, "constraints_snapshot.js")

SEVERITY_ALLOWED = ("must", "should", "may")

# 与 scripts/gk_constraints.py 的 CATEGORY_PREFIX 保持一致
CATEGORY_PREFIX = {
    "安全铁律": "SAFE", "公共基础": "COMMON", "PLC": "PLC", "HMI": "HMI",
    "上位机(C#)": "CS", "数字孪生": "TWIN", "多站点": "MULTI",
    "方案裁剪": "PLAN", "命名缩写": "NAMING", "维护禁止项": "MAINT",
}


class StoreError(Exception):
    """约束库读写故障，用于向前端返回友好错误而非抛栈。"""


def _prefix(category):
    if category in CATEGORY_PREFIX:
        return CATEGORY_PREFIX[category]
    return re.sub(r"[^A-Za-z0-9]", "", category or "").upper()[:8] or "GEN"


def next_id(constraints, category):
    prefix = _prefix(category)
    mx = 0
    for c in constraints:
        m = re.match(r"^" + re.escape(prefix) + r"-(\d+)$", str(c.get("id", "")))
        if m:
            mx = max(mx, int(m.group(1)))
    return "%s-%02d" % (prefix, mx + 1)


def norm_row(r):
    """统一到权威源字段口径 createdAt（兼容历史 created_at）。"""
    out = dict(r)
    if "createdAt" not in out and "created_at" in out:
        out["createdAt"] = out.pop("created_at")
    else:
        out.pop("created_at", None)
    out.setdefault("source", "导入")
    out.setdefault("project", "")
    out.setdefault("severity", "should")
    out.setdefault("createdAt", date.today().isoformat())
    return out


def load_store(path):
    if not os.path.exists(path):
        raise StoreError(
            "约束库文件不存在：%s。请确认技能包完整（应含 references/constraints_data.json），"
            "或运行 `python3 scripts/gk_constraints.py init` 生成空库。" % path)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except PermissionError:
        raise StoreError("没有读取权限：%s。请检查文件/目录权限或换有权限的账户运行。" % path)
    except json.JSONDecodeError as e:
        raise StoreError(
            "约束库文件已损坏（JSON 第 %s 行第 %s 列：%s）。请用备份覆盖，"
            "或运行 `python3 scripts/gk_constraints.py init --force` 重建（会丢失现有条目）。"
            % (e.lineno, e.colno, e.msg))
    except OSError as e:
        raise StoreError("读取约束库失败：%s" % e)
    if not isinstance(data, dict) or not isinstance(data.get("constraints"), list):
        raise StoreError("约束库结构不正确：缺少 constraints 数组。文件：%s" % path)
    return data


def _write_snapshot(data):
    """写库后同步刷新双击预览用的快照；失败不阻断主流程。"""
    try:
        payload = {
            "generatedAt": date.today().isoformat(),
            "source": "references/constraints_data.json",
            "constraints": [norm_row(r) for r in data["constraints"]],
        }
        js = ("// 自动生成，请勿手改：由 serve.py / gk_constraints.py 写库时同步刷新。\n"
              "// 用途：双击 web/index.html 且未启动 serve.py 时的离线只读预览数据。\n"
              "window.GK_SNAPSHOT = " + json.dumps(payload, ensure_ascii=False, indent=2) + ";\n")
        tmp = SNAPSHOT + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(js)
        os.replace(tmp, SNAPSHOT)
    except Exception:
        pass


def save_store(path, data, refresh_snapshot=True):
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except PermissionError:
        _cleanup(tmp)
        raise StoreError("没有写入权限：%s。请检查文件/目录权限或换有权限的账户运行。" % path)
    except OSError as e:
        _cleanup(tmp)
        raise StoreError("写入约束库失败：%s" % e)
    # 快照是「技能包内 index.html」的离线预览数据：仅当操作包内权威源时才刷新，
    # 用 --store 指向外部/临时库时不得污染随包快照。
    if refresh_snapshot:
        _write_snapshot(data)


def _cleanup(path):
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


class Handler(SimpleHTTPRequestHandler):
    store = DEFAULT_STORE
    refresh_snapshot = True   # 仅当操作包内权威源时为 True（main 里按路径判定）

    def _send(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _read_json(self):
        """返回 (payload, error)，解析失败给明确原因，绝不静默返回 {}。"""
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length <= 0:
                return None, "请求体为空"
            if length > 8 * 1024 * 1024:
                return None, "请求体过大（超过 8MB）"
            raw = self.rfile.read(length)
            return json.loads(raw.decode("utf-8")), None
        except UnicodeDecodeError:
            return None, "请求体不是 UTF-8 编码"
        except json.JSONDecodeError as e:
            return None, "请求体不是合法 JSON（第 %s 行第 %s 列：%s）" % (e.lineno, e.colno, e.msg)
        except Exception as e:
            return None, "读取请求体失败：%s" % e

    def _with_store(self, fn):
        """统一包住约束库读写异常，返回友好 JSON 而不是 500 抛栈。"""
        try:
            return fn(load_store(self.store))
        except StoreError as e:
            self._send(500, {"error": str(e)})
        except Exception as e:
            self._send(500, {"error": "服务内部错误：%s: %s" % (type(e).__name__, e)})

    def list_directory(self, path):
        self._send(403, {"error": "目录浏览已禁用"})
        return None

    def do_GET(self):
        p = urlparse(self.path)
        if p.path == "/api/health":
            try:
                data = load_store(self.store)
                self._send(200, {"ok": True, "mode": "local",
                                 "count": len(data["constraints"]), "store": self.store})
            except StoreError as e:
                self._send(200, {"ok": False, "mode": "local", "error": str(e)})
            return
        if p.path in ("/api/constraints", "/api/export"):
            def action(data):
                self._send(200, {"constraints": [norm_row(r) for r in data["constraints"]]})
            self._with_store(action)
            return
        if p.path.startswith("/api/"):
            self._send(404, {"error": "接口不存在：%s" % p.path})
            return
        if p.path in ("/", "/index.html"):
            self.path = "/index.html"
        return SimpleHTTPRequestHandler.do_GET(self)

    def do_POST(self):
        p = urlparse(self.path)
        if p.path == "/api/constraints":
            payload, err = self._read_json()
            if err:
                self._send(400, {"error": err}); return
            verr = self._validate(payload)
            if verr:
                self._send(400, {"error": verr}); return
            def action(data):
                rows = data["constraints"]
                for c in rows:
                    if c.get("category") == payload["category"] and c.get("title") == payload["title"]:
                        self._send(409, {"error": "已存在相同约束：%s %s" % (c.get("id"), c.get("title"))})
                        return
                entry = {
                    "id": next_id(rows, payload["category"]),
                    "category": payload["category"], "title": payload["title"],
                    "rule": payload["rule"],
                    "severity": payload.get("severity") or "should",
                    "source": payload.get("source") or "本地界面",
                    "project": payload.get("project") or "",
                    "createdAt": date.today().isoformat(),
                }
                rows.append(entry)
                save_store(self.store, data, self.refresh_snapshot)
                self._send(201, {"data": entry})
            self._with_store(action)
            return
        if p.path == "/api/import":
            payload, err = self._read_json()
            if err:
                self._send(400, {"error": err}); return
            if not isinstance(payload, dict):
                self._send(400, {"error": "导入文件顶层必须是 JSON 对象（含 constraints 数组）"}); return
            rows = payload.get("constraints") or payload.get("data") or []
            if not isinstance(rows, list):
                self._send(400, {"error": "格式不正确：未找到 constraints 数组"}); return
            valid = [r for r in rows if isinstance(r, dict) and r.get("category") and r.get("title") and r.get("rule")]
            if not valid:
                self._send(400, {"error": "没有可用的约束条目（每条需含 category / title / rule）"}); return
            def action(data):
                existing = {(c.get("category"), c.get("title")) for c in data["constraints"]}
                existing_ids = {str(c.get("id")) for c in data["constraints"]}
                added = 0
                for raw in valid:
                    r = norm_row(raw)
                    key = (r.get("category"), r.get("title"))
                    if key in existing:
                        continue
                    rid = str(r.get("id", ""))
                    if not rid or rid in existing_ids:
                        r["id"] = next_id(data["constraints"], str(r.get("category", "")))
                    data["constraints"].append(r)
                    existing.add(key)
                    existing_ids.add(str(r["id"]))
                    added += 1
                save_store(self.store, data, self.refresh_snapshot)
                self._send(200, {"added": added, "skipped": len(valid) - added,
                                 "invalid": len(rows) - len(valid)})
            self._with_store(action)
            return
        self._send(404, {"error": "接口不存在：%s" % p.path})

    def do_PUT(self):
        p = urlparse(self.path)
        m = re.match(r"^/api/constraints/(.+)$", p.path)
        if not m:
            self._send(404, {"error": "接口不存在"}); return
        cid = unquote(m.group(1))
        payload, err = self._read_json()
        if err:
            self._send(400, {"error": err}); return
        verr = self._validate(payload, partial=True)
        if verr:
            self._send(400, {"error": verr}); return
        def action(data):
            for c in data["constraints"]:
                if str(c.get("id")) == cid:
                    for k in ("category", "title", "rule", "severity", "source", "project"):
                        if k in payload:
                            c[k] = payload[k]
                    c.pop("created_at", None)
                    c.setdefault("createdAt", date.today().isoformat())
                    save_store(self.store, data, self.refresh_snapshot)
                    self._send(200, {"data": norm_row(c)})
                    return
            self._send(404, {"error": "未找到该约束：%s" % cid})
        self._with_store(action)

    def do_DELETE(self):
        p = urlparse(self.path)
        m = re.match(r"^/api/constraints/(.+)$", p.path)
        if not m:
            self._send(404, {"error": "接口不存在"}); return
        cid = unquote(m.group(1))
        def action(data):
            before = len(data["constraints"])
            data["constraints"] = [c for c in data["constraints"] if str(c.get("id")) != cid]
            if len(data["constraints"]) == before:
                self._send(404, {"error": "未找到该约束：%s" % cid}); return
            save_store(self.store, data, self.refresh_snapshot)
            self._send(200, {"data": {"id": cid}})
        self._with_store(action)

    @staticmethod
    def _validate(p, partial=False):
        if not isinstance(p, dict):
            return "请求体必须是 JSON 对象"
        if not partial:
            for k in ("category", "title", "rule"):
                if not p.get(k):
                    return "category / title / rule 均为必填"
        if p.get("severity") and p.get("severity") not in SEVERITY_ALLOWED:
            return "severity 必须是 must / should / may"
        return None

    def log_message(self, *args):
        pass  # 静默，避免刷屏


def main():
    ap = argparse.ArgumentParser(description="工控约束集本地管理接口")
    ap.add_argument("--port", type=int, default=8765, help="监听端口（默认 8765）")
    ap.add_argument("--store", default=DEFAULT_STORE, help="约束库 JSON 路径（默认随包 references/constraints_data.json）")
    ap.add_argument("--open", action="store_true", help="启动后自动打开浏览器")
    args = ap.parse_args()

    store = os.path.abspath(args.store)
    try:
        load_store(store)
    except StoreError as e:
        sys.exit("[错误] " + str(e))

    Handler.store = store
    # 仅操作包内权威源时刷新随包快照；--store 指向外部/临时库时不污染技能包
    Handler.refresh_snapshot = (os.path.normcase(store) == os.path.normcase(os.path.abspath(DEFAULT_STORE)))
    handler = partial(Handler, directory=HERE)
    try:
        srv = HTTPServer(("127.0.0.1", args.port), handler)
    except OSError as e:
        sys.exit("[错误] 无法监听 127.0.0.1:%s（%s）。\n"
                 "       端口可能被占用，请换一个端口：python3 serve.py --port 9000" % (args.port, e))

    # 启动时刷新一次快照，保证双击 index.html 的离线预览与权威源一致
    if Handler.refresh_snapshot:
        try:
            _write_snapshot(load_store(store))
        except Exception:
            pass

    url = "http://localhost:%d" % args.port
    print("工控约束集本地管理接口已启动： " + url)
    print("约束库：" + store)
    print("离线预览快照：" + (SNAPSHOT if Handler.refresh_snapshot else "（外部库，不刷新随包快照）"))
    print("按 Ctrl+C 停止。")
    if args.open:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
