# 工控项目统一开发约束集（gongkong-constraints）

SPEC-CTRL-2026-001 · 纯本地 WorkBuddy 技能 · 版本 1.1.1

把分散在多份工控项目里的强约束合并成一份可复用规范，让 AI 生成 PLC / 触摸屏 HMI /
C# 上位机 / 数字孪生代码时一次落在同一套框架内；项目里出现的新规则可随时追加进约束库，
后续生成自动遵守。

**特点：纯本地、零联网、零第三方依赖、随包可用。** 不依赖任何云服务或账号。

---

## 快速开始

```bash
# 1) 查看全部 46 条约束
python3 scripts/gk_constraints.py list

# 2) 打开网页管理界面（完整读写）
python3 web/serve.py --open          # 浏览器自动打开 http://localhost:8765
#    Windows 若 python3 命令不可用，改用：py -3 web/serve.py --open

# 3) 只想看一眼、不启服务：直接双击 web/index.html（离线只读预览）

# 4) 检查约束库是否完好
python3 scripts/gk_constraints.py doctor

# 5) 生成代码后扫描项目
python3 scripts/gk_constraints.py validate --project <项目目录>
```

环境要求：Python 3（仅标准库）+ 任选现代浏览器。无需 pip install，无需网络。

## 目录结构

| 路径 | 内容 |
|---|---|
| `SKILL.md` | 技能入口：用途、触发条件、六条安全铁律、关键结构约束、能力边界、自动追加流程 |
| `references/spec.md` | 完整规范：全部表格与细则（变量前缀 / DB 划分 / 分层 / 清单字段 / 方案 A~E / 交付物） |
| `references/constraints_data.json` | **唯一权威约束源**（46 条 / 10 分类 / 42 条铁律） |
| `references/selfcheck.md` | 生成后 15 项自检清单 |
| `references/walkthrough.md` | 端到端项目示范、5 组完整对话示例、预期结果对照 |
| `references/faq.md` | 19 条集中 FAQ + 9 条反模式逐步修正指引 |
| `scripts/gk_constraints.py` | CLI：`list / add / doctor / validate / export / import / init` |
| `scripts/selftest.py` | 回归测试（离线一键自检，见下文） |
| `web/index.html` + `app.js` | 本地管理门户前端（无 CDN、无 ESM、无外部请求） |
| `web/serve.py` | 本地 API 服务（Python 标准库，仅监听 127.0.0.1；`--open` 自动打开浏览器） |
| `web/constraints_snapshot.js` | 随包快照：双击 index.html 时的离线只读预览数据 |
| `assets/top_config_template.json` | 顶层配置样例（多站点 + 方案 E 骨架） |
| `CHANGELOG.md` | 版本变更记录 |

## 三种运行方式的区别

| 方式 | 读写 | 需要启动服务 | 说明 |
|---|---|---|---|
| `python3 web/serve.py --open` | 完整读写 | 是 | 推荐。列表 / 筛选 / 新增 / 编辑 / 删除 / 导入导出，自动开浏览器 |
| 双击 `web/index.html` | 只读预览 | 否 | 查看 / 筛选 / 导出；数据来自随包快照 |
| CLI `gk_constraints.py` | 完整读写 | 否 | 适合自动化、批量、脚本集成，`--json` 可结构化输出 |

三处围绕**同一份** `references/constraints_data.json`；写库会自动刷新快照，保持一致。

## 常用操作

```bash
# 按分类/级别筛选
python3 scripts/gk_constraints.py list --category 安全铁律 --severity must

# 追加新约束（自动按分类前缀编号，如 安全铁律 -> SAFE-08）
python3 scripts/gk_constraints.py add --category 维护禁止项 \
  --title "禁止在工厂里写死颜色" --rule "颜色必须来自 ColorRule" \
  --severity must --project "某项目" --source "项目现场"

# 备份 / 恢复
python3 scripts/gk_constraints.py export -o backup.json
python3 scripts/gk_constraints.py import -i backup.json

# 运行完整回归测试（含上传文件类型合规检查）
python3 scripts/selftest.py
```

## 数据与安全

- 所有数据只在本机技能目录，服务仅绑定 `127.0.0.1`，不加载外部脚本、不发外部请求。
- 约束库损坏或权限不足时，CLI 与服务都给出中文定位提示（含行列号），不会抛裸异常栈。
- 包内**不含** `.bat` / `.cmd` / `.exe` 等可执行脚本，仅 `md / json / py / js / html` 五类文本，可直接提交技能市场。
  需要「双击启动」请在桌面自建指向 `python3 web/serve.py --open` 的快捷方式（本机文件，不随包分发）。
- 如需分享技能包给他人，直接复制整个文件夹即可——**注意约束内容会随包一起分发**。

## 版本口径

版本 1.1.1（2026-11-13）· 46 条约束 · 纯本地 · 详见 `CHANGELOG.md`。
