#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gongkong-constraints 技能回归自检（纯标准库）
============================================
运行：python3 scripts/selftest.py
所有破坏性用例都在临时副本上做，不会修改真实约束库。
退出码：0 = 全绿；1 = 有失败项。
"""
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLI = os.path.join(ROOT, "scripts", "gk_constraints.py")
SERVE = os.path.join(ROOT, "web", "serve.py")
DATA = os.path.join(ROOT, "references", "constraints_data.json")
SNAP = os.path.join(ROOT, "web", "constraints_snapshot.js")

RESULTS = []


def check(name, fn):
    try:
        ok, detail = fn()
    except Exception as e:
        ok, detail = False, "测试自身异常：%s: %s" % (type(e).__name__, e)
    RESULTS.append((name, bool(ok), detail))
    print("  [%s] %-34s %s" % ("PASS" if ok else "FAIL", name, detail))
    return ok


def run_cli(args, cwd=ROOT, script=None):
    return subprocess.run([sys.executable, script or CLI] + args, cwd=cwd,
                          capture_output=True, text=True, encoding="utf-8", timeout=30)


def make_copy():
    d = tempfile.mkdtemp(prefix="gk_selftest_")
    dst = os.path.join(d, "skill")
    shutil.copytree(ROOT, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"))
    return d, dst


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


# ---------------------------------------------------------------- 用例
def t01_files():
    need = ["SKILL.md", "README.md", "CHANGELOG.md",
            "references/spec.md", "references/selfcheck.md", "references/faq.md",
            "references/walkthrough.md", "references/constraints_data.json",
            "assets/top_config_template.json",
            "scripts/gk_constraints.py", "scripts/selftest.py",
            "web/index.html", "web/app.js", "web/serve.py",
            "web/constraints_snapshot.js"]
    miss = [f for f in need if not os.path.isfile(os.path.join(ROOT, f))]
    return not miss, "必需文件 %d 个齐全" % len(need) if not miss else "缺失：" + ",".join(miss)


def t02_data():
    d = json.load(open(DATA, encoding="utf-8"))
    rows = d["constraints"]
    fields = {"id", "category", "title", "rule", "severity", "source", "project", "createdAt"}
    bad = [r["id"] for r in rows if not fields.issubset(r.keys())]
    ids = [r["id"] for r in rows]
    ok = (len(rows) == 46 and not bad and len(set(ids)) == 46 and
          all(r["severity"] in ("must", "should", "may") for r in rows))
    must = sum(1 for r in rows if r["severity"] == "must")
    return ok, "%d 条 / %d 分类 / %d 铁律" % (len(rows), len({r["category"] for r in rows}), must)


def t03_doctor_ok():
    r = run_cli(["doctor", "--json"])
    j = json.loads(r.stdout)
    return r.returncode == 0 and j["ok"], "权威源自检通过，problems=%d" % len(j["problems"])


def t04_doctor_detects():
    tmp, cp = make_copy()
    try:
        p = os.path.join(cp, "references", "constraints_data.json")
        d = json.load(open(p, encoding="utf-8"))
        d["constraints"][1]["id"] = d["constraints"][0]["id"]      # 重复 id
        d["constraints"][2]["severity"] = "致命"                     # 非法 severity
        d["constraints"][3]["created_at"] = "2026-01-01"            # 字段名不统一
        del d["constraints"][3]["createdAt"]
        json.dump(d, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        r = run_cli(["doctor", "--json"], script=os.path.join(cp, "scripts", "gk_constraints.py"))
        j = json.loads(r.stdout)
        return r.returncode == 1 and len(j["problems"]) >= 3, "能检出 %d 项问题" % len(j["problems"])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t05_list():
    r = run_cli(["list", "--json"])
    j = json.loads(r.stdout)
    r2 = run_cli(["list", "--category", "安全铁律", "--severity", "must"])
    return (r.returncode == 0 and j["total"] == 46 and "SAFE-01" in r2.stdout
            and "过滤后 7 条" in r2.stdout), "JSON 输出与分类/级别过滤正常"


def t06_add_id():
    tmp, cp = make_copy()
    try:
        s = os.path.join(cp, "scripts", "gk_constraints.py")
        r = run_cli(["add", "--category", "安全铁律", "--title", "回归测试约束",
                     "--rule", "仅用于自检", "--severity", "must", "--json"], script=s)
        j = json.loads(r.stdout)
        return r.returncode == 0 and j["added"]["id"] == "SAFE-08", "新约束编号 = " + j["added"]["id"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t07_add_dup():
    tmp, cp = make_copy()
    try:
        s = os.path.join(cp, "scripts", "gk_constraints.py")
        args = ["add", "--category", "安全铁律", "--title", "回归测试约束", "--rule", "x"]
        run_cli(args, script=s)
        r = run_cli(args, script=s)
        return r.returncode == 1 and "已存在相同约束" in r.stderr, "重复约束被拦截"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t08_export_import():
    tmp, cp = make_copy()
    try:
        s = os.path.join(cp, "scripts", "gk_constraints.py")
        out = os.path.join(tmp, "b.json")
        r1 = run_cli(["export", "-o", out], script=s)
        r2 = run_cli(["import", "-i", out], script=s)
        b = json.load(open(out, encoding="utf-8"))
        b["constraints"].append({"category": "PLC", "title": "新增验证", "rule": "x", "severity": "may"})
        json.dump(b, open(out, "w", encoding="utf-8"), ensure_ascii=False)
        r3 = run_cli(["import", "-i", out], script=s)
        return (r1.returncode == 0 and "跳过重复 46 条" in r2.stdout
                and "新增 1 条" in r3.stdout), "往返：全跳过 46，新增 1 条"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _mk_project(base, bad=True):
    os.makedirs(base, exist_ok=True)
    if bad:
        open(os.path.join(base, "Form1.cs"), "w", encoding="utf-8").write(
            "class Form1 { void Init(){ var b = new Button(); b.Location = new Point(10,20); } }")
    else:
        open(os.path.join(base, "Layout.cs"), "w", encoding="utf-8").write(
            "class UiLayoutItem { string BusinessKey; } class UiControlMeta { string FlowItemKey; } "
            "class Factory { object Build(UiLayoutItem i, ColorRule c){ try { return null; } catch(System.Exception e){} return null; } } "
            "class PlcDriver { bool Cmd_Start; bool Ack_Start; } class Logic {} class Service {} class Model {} "
            "class Cfg { System.Collections.Generic.List<string> ControlBlackList; } "
            "class LayoutValidator { } class CommandHelper { } class Log { void OpSource(){} }")
    return base


def t09_validate_bad():
    tmp = tempfile.mkdtemp(prefix="gk_vbad_")
    try:
        proj = _mk_project(os.path.join(tmp, "p"), bad=True)
        r = run_cli(["validate", "--project", proj, "--json"])
        j = json.loads(r.stdout)
        hits = sum(n["violations"] for n in j["negatives"])
        return r.returncode == 1 and not j["ok"] and hits > 0, "违规项目判不通过，反模式命中 %d 处" % hits
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t10_validate_good():
    tmp = tempfile.mkdtemp(prefix="gk_vgood_")
    try:
        proj = _mk_project(os.path.join(tmp, "p"), bad=False)
        r = run_cli(["validate", "--project", proj, "--json"])
        j = json.loads(r.stdout)
        return (r.returncode == 0 and j["ok"] and
                j["positive_passed"] == j["positive_total"]), "合规项目正向 %d/%d 通过" % (
                    j["positive_passed"], j["positive_total"])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t11_validate_dupkey():
    tmp = tempfile.mkdtemp(prefix="gk_vdup_")
    try:
        proj = _mk_project(os.path.join(tmp, "p"), bad=False)
        json.dump({"items": [{"BusinessKey": "K1"}, {"BusinessKey": "K1"}]},
                  open(os.path.join(proj, "layout.json"), "w", encoding="utf-8"))
        j = json.loads(run_cli(["validate", "--project", proj, "--json"]).stdout)
        return len(j["layout_duplicate_keys"]) == 1, "检出重复 BusinessKey"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t12_corrupt_store():
    tmp, cp = make_copy()
    try:
        open(os.path.join(cp, "references", "constraints_data.json"), "w", encoding="utf-8").write("{ bad")
        s = os.path.join(cp, "scripts", "gk_constraints.py")
        r = run_cli(["list"], script=s)
        return (r.returncode == 2 and "损坏" in r.stderr and "Traceback" not in r.stderr), "损坏库给中文定位提示，无裸异常栈"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t13_corrupt_import():
    tmp, cp = make_copy()
    try:
        s = os.path.join(cp, "scripts", "gk_constraints.py")
        bad = os.path.join(tmp, "bad.json")
        open(bad, "w", encoding="utf-8").write("{oops")
        r = run_cli(["import", "-i", bad], script=s)
        d = json.load(open(os.path.join(cp, "references", "constraints_data.json"), encoding="utf-8"))
        return (r.returncode == 2 and "不是合法 JSON" in r.stderr
                and len(d["constraints"]) == 46), "导入损坏整体中止，原库仍 46 条"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t14_init_guard():
    tmp, cp = make_copy()
    try:
        s = os.path.join(cp, "scripts", "gk_constraints.py")
        r = run_cli(["init"], script=s)
        return r.returncode == 1 and "已存在" in r.stderr, "init 无 --force 时拒绝覆盖"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t15_web_api():
    tmp = tempfile.mkdtemp(prefix="gk_web_")
    store = os.path.join(tmp, "c.json")
    shutil.copy(DATA, store)
    before = open(SNAP, "r", encoding="utf-8").read()
    port = free_port()
    proc = subprocess.Popen([sys.executable, SERVE, "--port", str(port), "--store", store],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8")
    base = "http://127.0.0.1:%d" % port

    def req(m, p, b=None):
        data = None if b is None else (b if isinstance(b, bytes) else json.dumps(b, ensure_ascii=False).encode("utf-8"))
        rq = urllib.request.Request(base + p, data=data, method=m,
                                    headers={"Content-Type": "application/json"} if data else {})
        try:
            with urllib.request.urlopen(rq, timeout=5) as x:
                raw, code = x.read().decode("utf-8", "ignore"), x.status
        except urllib.error.HTTPError as e:
            raw, code = e.read().decode("utf-8", "ignore"), e.code
        try:
            return code, json.loads(raw)
        except Exception:
            return code, raw

    try:
        for _ in range(40):
            try:
                if req("GET", "/api/health")[0] == 200:
                    break
            except Exception:
                time.sleep(0.15)
        c, h = req("GET", "/api/health")
        c, lst = req("GET", "/api/constraints")
        c, add = req("POST", "/api/constraints",
                     {"category": "安全铁律", "title": "回归测试", "rule": "x", "severity": "must"})
        nid = add.get("data", {}).get("id", "")
        c2, dup = req("POST", "/api/constraints",
                      {"category": "安全铁律", "title": "回归测试", "rule": "x"})
        c3, upd = req("PUT", "/api/constraints/" + nid, {"title": "回归测试(改)", "severity": "should"})
        c4, imp = req("POST", "/api/import", {"constraints": [
            {"category": "PLC", "title": "导入验证", "rule": "x", "severity": "may"}]})
        c5, bad = req("POST", "/api/constraints", b"{oops")
        c6, miss = req("POST", "/api/constraints", {"category": "X"})
        c7, sev = req("POST", "/api/constraints",
                      {"category": "X", "title": "Y", "rule": "Z", "severity": "bad"})
        c8, nf = req("GET", "/api/nope")
        c9, home = req("GET", "/")
        c10, dels = req("DELETE", "/api/constraints/" + nid)
        c11, final = req("GET", "/api/constraints")
        after = open(SNAP, "r", encoding="utf-8").read()
        ok = (h["count"] == 46 and len(lst["constraints"]) == 46 and nid == "SAFE-08" and
              c2 == 409 and upd["data"]["title"] == "回归测试(改)" and imp["added"] == 1 and
              c5 == 400 and "不是合法 JSON" in bad["error"] and c6 == 400 and c7 == 400 and
              c8 == 404 and isinstance(nf, dict) and c9 == 200 and c10 == 200 and
              len(final["constraints"]) == 47 and before == after)
        return ok, "health/CRUD/导入/异常/静态/隔离 全通过，终态 47 条，快照未污染"
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except Exception:
            proc.kill()
        shutil.rmtree(tmp, ignore_errors=True)


def t16_snapshot():
    txt = open(SNAP, encoding="utf-8").read()
    j = json.loads(txt.split("=", 1)[1].strip().rstrip(";"))
    rows = j["constraints"]
    d = json.load(open(DATA, encoding="utf-8"))["constraints"]
    ok = (len(rows) == 46 and all("createdAt" in r and "created_at" not in r for r in rows)
          and [r["id"] for r in rows] == [r["id"] for r in d])
    return ok, "随包快照 46 条，字段 createdAt 统一，id 与权威源一致"


def t17_frontend_syntax():
    if not shutil.which("node"):
        return True, "node 不可用，跳过（非失败）"
    tmp = tempfile.mkdtemp(prefix="gk_node_")
    try:
        a = os.path.join(tmp, "app.js")
        shutil.copy(os.path.join(ROOT, "web", "app.js"), a)
        r = subprocess.run(["node", "--check", a], capture_output=True, text=True, timeout=20)
        r2 = subprocess.run(["node", "--check", SNAP], capture_output=True, text=True, timeout=20)
        return r.returncode == 0 and r2.returncode == 0, "app.js 与快照 JS 语法通过"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t18_no_cloud_residue():
    # 禁用词按片段拼接，避免本测试文件自身被扫描命中
    banned = ["Cloud" + "Base", "cloud" + "base", "industrial-" + "constrain",
              "匿名" + "登录", "share" + "code", "wbapp" + "_", "gk_cloud" + "_client"]
    targets = ["SKILL.md", "README.md", "references/faq.md", "references/walkthrough.md",
               "references/selfcheck.md", "references/spec.md", "references/constraints_data.json",
               "scripts/gk_constraints.py", "web/app.js", "web/index.html", "web/serve.py"]
    hits = []
    for f in targets:
        txt = open(os.path.join(ROOT, f), encoding="utf-8").read()
        for b in banned:
            if b in txt:
                hits.append("%s:%s" % (f, b))
    return not hits, "全包无云端残留" if not hits else "残留：" + ",".join(hits)


def t19_release_consistency():
    sk = open(os.path.join(ROOT, "SKILL.md"), encoding="utf-8").read()
    rm = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()
    ch = open(os.path.join(ROOT, "CHANGELOG.md"), encoding="utf-8").read()
    ver = re.search(r"^version:\s*([\d.]+)", sk, re.M)
    ok = (ver and ver.group(1) == "1.1.1" and "1.1.1" in rm and "1.1.1" in ch
          and "46 条" in sk and "46 条" in rm)
    return bool(ok), "SKILL/README/CHANGELOG 版本 1.1.1 与 46 条口径一致"


def t20_scripts_compile():
    a = subprocess.run([sys.executable, "-m", "py_compile", CLI, SERVE,
                        os.path.join(ROOT, "scripts", "selftest.py")],
                       capture_output=True, text=True)
    return a.returncode == 0, "三个 Python 脚本语法通过"


def t21_browser_render():
    """真实浏览器验证：双击只读预览 + HTTP 读写模式都能渲染出 46 条。"""
    edge = None
    for p in (r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
              r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"):
        if os.path.isfile(p):
            edge = p
            break
    if not edge:
        return True, "未找到 Edge，跳过（非失败）"

    base = [edge, "--headless=new", "--disable-gpu", "--no-first-run",
            "--no-default-browser-check", "--enable-unsafe-swiftshader",
            "--virtual-time-budget=4000", "--dump-dom"]
    tmp = tempfile.mkdtemp(prefix="gk_browser_")
    store = os.path.join(tmp, "c.json")
    shutil.copy(DATA, store)
    port = free_port()
    proc = subprocess.Popen([sys.executable, SERVE, "--port", str(port), "--store", store],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8")
    try:
        for _ in range(40):
            try:
                urllib.request.urlopen("http://127.0.0.1:%d/api/health" % port, timeout=1)
                break
            except Exception:
                time.sleep(0.15)
        ud1 = os.path.join(tmp, "p1")
        file_url = "file:///" + os.path.join(ROOT, "web", "index.html").replace("\\", "/")
        r1 = subprocess.run(base + ["--user-data-dir=" + ud1, file_url],
                            capture_output=True, text=True, encoding="utf-8", timeout=90)
        ud2 = os.path.join(tmp, "p2")
        r2 = subprocess.run(base + ["--user-data-dir=" + ud2, "http://127.0.0.1:%d/" % port],
                            capture_output=True, text=True, encoding="utf-8", timeout=90)
        d1, d2 = r1.stdout or "", r2.stdout or ""
        ok = (d1.count('class="card"') == 46 and "离线只读预览" in d1
              and "data-edit=" not in d1
              and d2.count('class="card"') == 46 and d2.count("data-edit=") == 46
              and "本地读写模式" in d2)
        return ok, "真实浏览器：双击预览 46 卡片(只读) / HTTP 46 卡片+46 编辑按钮(读写)"
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except Exception:
            proc.kill()
        shutil.rmtree(tmp, ignore_errors=True)


def t22_upload_file_types():
    """技能市场上传合规：包内只允许文本类白名单扩展名，禁止可执行/脚本类文件。

    平台按文件类型白名单校验技能包，历史上曾因 web/start-web.bat 提交被拒。
    """
    allowed = {"md", "json", "py", "js", "html", "txt", "css", "svg",
               "png", "jpg", "jpeg", "yaml", "yml", "csv"}
    banned = {"bat", "cmd", "exe", "ps1", "sh", "dll", "so", "msi",
              "com", "scr", "vbs", "jar", "bin", "app"}
    bad, total = [], 0
    for root, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
        for fn in files:
            total += 1
            ext = fn.rsplit(".", 1)[1].lower() if "." in fn else ""
            if ext in banned or ext not in allowed:
                bad.append(os.path.relpath(os.path.join(root, fn), ROOT).replace("\\", "/") + "." + ext)
    detail = ("%d 个文件均为白名单文本类型，无可执行脚本" % total
              if not bad else "不合规文件：" + ",".join(bad))
    return not bad, detail


def main():
    print("\n工控约束集技能 · 回归自检（v1.1.1）\n" + "=" * 60)
    for name, fn in [
        ("T01 包内文件齐全", t01_files),
        ("T02 权威约束源结构", t02_data),
        ("T03 doctor 权威源通过", t03_doctor_ok),
        ("T04 doctor 能检出问题", t04_doctor_detects),
        ("T05 list / 过滤 / JSON", t05_list),
        ("T06 add 规范编号", t06_add_id),
        ("T07 add 重复拦截", t07_add_dup),
        ("T08 export/import 往返", t08_export_import),
        ("T09 validate 违规判不通过", t09_validate_bad),
        ("T10 validate 合规通过", t10_validate_good),
        ("T11 validate 重复唯一键", t11_validate_dupkey),
        ("T12 损坏库友好报错", t12_corrupt_store),
        ("T13 损坏导入整体中止", t13_corrupt_import),
        ("T14 init 覆盖保护", t14_init_guard),
        ("T15 Web 接口全链路", t15_web_api),
        ("T16 随包快照一致性", t16_snapshot),
        ("T17 前端脚本语法", t17_frontend_syntax),
        ("T18 无云端残留", t18_no_cloud_residue),
        ("T19 发布口径一致", t19_release_consistency),
        ("T20 Python 脚本语法", t20_scripts_compile),
        ("T21 真实浏览器渲染", t21_browser_render),
        ("T22 上传文件类型合规", t22_upload_file_types),
    ]:
        check(name, fn)
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    failed = len(RESULTS) - passed
    print("=" * 60)
    print("结果：%d/%d 通过，%d 失败" % (passed, len(RESULTS), failed))
    if failed:
        for n, ok, d in RESULTS:
            if not ok:
                print("  FAIL -> %s : %s" % (n, d))
    # 清理可能的 __pycache__
    for sub in ("scripts", "web"):
        shutil.rmtree(os.path.join(ROOT, sub, "__pycache__"), ignore_errors=True)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
