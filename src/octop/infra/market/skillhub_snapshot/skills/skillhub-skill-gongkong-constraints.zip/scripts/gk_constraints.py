#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gongkong-constraints 约束库管理 CLI（纯本地，零第三方依赖）
==========================================================
本脚本管理技能唯一权威约束源 references/constraints_data.json，配合
SKILL.md 的「自动追加新约束」流程使用。不联网、不依赖任何云服务。

子命令：
  list      列出约束（可按 --category / --severity 过滤）
  add       追加一条新约束（自动按分类生成规范编号）
  doctor    约束库完整性自检（必填/唯一/severity/字段/编号/分类映射）
  validate  对照 §10.3 自检清单扫描项目目录（区分正向特征与反模式）
  export    导出约束库为独立 JSON（备份 / 迁移 / 门户导入）
  import    从 JSON 合并回本地约束库（按 分类+标题 去重）
  init      重建一个空的约束库骨架（仅文件丢失且无备份时使用）

用法示例：
  python3 gk_constraints.py list
  python3 gk_constraints.py list --category 安全铁律 --severity must
  python3 gk_constraints.py add --category 维护禁止项 --title "禁止在工厂里写死颜色" \
      --rule "所有颜色必须从顶层 ColorRule 读取，工厂代码不得出现十六进制色值字面量" \
      --severity must --project "蒙东矿业封闭煤场" --source "项目现场"
  python3 gk_constraints.py doctor
  python3 gk_constraints.py validate --project "D:/Projects/PRJ-XXX-2026-001"
  python3 gk_constraints.py validate --project . --json
  python3 gk_constraints.py export -o constraints_export.json
  python3 gk_constraints.py import -i constraints_export.json
  python3 gk_constraints.py init            # 谨慎：会生成空库

退出码：0 = 正常/检查无问题；1 = 检查发现问题或参数校验失败；2 = 运行错误。
"""
import argparse
import json
import os
import re
import sys
from datetime import date

# 约束库相对脚本位置：scripts/ -> 技能根 -> references/constraints_data.json
SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(SKILL_ROOT, "references", "constraints_data.json")
SNAPSHOT_PATH = os.path.join(SKILL_ROOT, "web", "constraints_snapshot.js")

SEVERITY_ALLOWED = ("must", "should", "may")
REQUIRED_FIELDS = ("id", "category", "title", "rule", "severity", "source", "project", "createdAt")

# 分类 -> 编号前缀（与库内既有 46 条保持一致；新分类自动归入 GEN）
CATEGORY_PREFIX = {
    "安全铁律": "SAFE", "公共基础": "COMMON", "PLC": "PLC", "HMI": "HMI",
    "上位机(C#)": "CS", "数字孪生": "TWIN", "多站点": "MULTI",
    "方案裁剪": "PLAN", "命名缩写": "NAMING", "维护禁止项": "MAINT",
}


# ------------------------------ 通用工具 ------------------------------
def _err(msg, code=1):
    """统一友好报错出口，绝不把裸异常栈抛给用户。"""
    print("[错误] " + msg, file=sys.stderr)
    return code


def _created(r):
    """兼容 createdAt 与历史 created_at 两种写法，统一返回字符串。"""
    return str(r.get("createdAt") or r.get("created_at") or "")


def _norm_row(r):
    """把一条外部来源的约束归一成权威源字段口径。"""
    out = dict(r)
    if "createdAt" not in out and "created_at" in out:
        out["createdAt"] = out.pop("created_at")
    elif "created_at" in out:
        out.pop("created_at")
    out.setdefault("source", "导入")
    out.setdefault("project", "")
    out.setdefault("severity", "should")
    out.setdefault("createdAt", date.today().isoformat())
    return out


def _load():
    """读取本地约束库，对常见故障给出友好提示与可用退出码。"""
    if not os.path.exists(DATA_PATH):
        sys.exit(_err(
            f"找不到约束库文件：{DATA_PATH}\n"
            "        请确认技能包完整；若文件丢失，可从技能压缩包重新解压 "
            "references/constraints_data.json，\n"
            "        或运行 `python3 gk_constraints.py init` 生成一个空库骨架（会丢失现有条目）。", 2))
    try:
        with open(DATA_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
    except PermissionError:
        sys.exit(_err(f"没有读取权限：{DATA_PATH}\n        请以有读权限的账户运行，或检查文件/目录权限。", 2))
    except json.JSONDecodeError as e:
        sys.exit(_err(
            f"约束库文件已损坏（JSON 解析失败）：{DATA_PATH}\n"
            f"        出错位置：第 {e.lineno} 行第 {e.colno} 列（{e.msg}）。\n"
            "        建议：① 用同目录 .bak 或最近备份覆盖；② 从技能压缩包重新解压该文件；\n"
            "        ③ 均无备份时运行 `python3 gk_constraints.py init --force` 重建空库（会丢失现有条目）。", 2))
    except OSError as e:
        sys.exit(_err(f"读取约束库失败：{DATA_PATH}\n        原因：{e}", 2))
    except Exception as e:
        sys.exit(_err(f"读取约束库时发生未知错误：{DATA_PATH}\n        原因：{e}", 2))
    if not isinstance(data, dict) or not isinstance(data.get("constraints"), list):
        sys.exit(_err(f"约束库结构不正确：缺少 constraints 数组。\n        文件：{DATA_PATH}", 2))
    return data


def _write_snapshot(data):
    """把权威源同步为纯 JS 数据文件，使双击 web/index.html 也能离线只读预览。
    快照失败不阻断主流程（只是降级能力缺失），故单独吞异常。"""
    try:
        os.makedirs(os.path.dirname(SNAPSHOT_PATH), exist_ok=True)
        payload = {
            "generatedAt": date.today().isoformat(),
            "source": "references/constraints_data.json",
            "constraints": [_norm_row(r) for r in data["constraints"]],
        }
        js = ("// 自动生成，请勿手改：由 gk_constraints.py 写库时同步刷新。\n"
              "// 用途：双击 web/index.html 且未启动 serve.py 时的离线只读预览数据。\n"
              "window.GK_SNAPSHOT = " + json.dumps(payload, ensure_ascii=False, indent=2) + ";\n")
        with open(SNAPSHOT_PATH, "w", encoding="utf-8") as f:
            f.write(js)
    except Exception:
        pass


def _save(data):
    """原子写入：先落临时文件再替换，避免中途失败把库写坏。"""
    tmp = DATA_PATH + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        if os.path.exists(DATA_PATH):
            os.replace(tmp, DATA_PATH)
        else:
            os.rename(tmp, DATA_PATH)
        _write_snapshot(data)
    except PermissionError:
        _cleanup(tmp)
        sys.exit(_err(f"没有写入权限：{DATA_PATH}\n        请以有写权限的账户运行，或检查文件/目录权限。", 2))
    except OSError as e:
        _cleanup(tmp)
        sys.exit(_err(f"写入约束库失败：{DATA_PATH}\n        原因：{e}", 2))
    except Exception as e:
        _cleanup(tmp)
        sys.exit(_err(f"写入约束库时发生未知错误：{DATA_PATH}\n        原因：{e}", 2))


def _cleanup(path):
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def _prefix(category):
    """按分类取规范前缀；未登记分类用清洗后的英文/拼音占位或 GEN。"""
    if category in CATEGORY_PREFIX:
        return CATEGORY_PREFIX[category]
    cleaned = re.sub(r"[^A-Za-z0-9]", "", category or "").upper()[:8]
    return cleaned or "GEN"


def _next_id(constraints, category):
    """只在同前缀内递增，避免跨分类串号（如 SAFE-08 而非 安全铁律-47）。"""
    prefix = _prefix(category)
    mx = 0
    for c in constraints:
        m = re.match(r"^" + re.escape(prefix) + r"-(\d+)$", str(c.get("id", "")))
        if m:
            mx = max(mx, int(m.group(1)))
    return f"{prefix}-{mx + 1:02d}"


# ------------------------------ 子命令 ------------------------------
def cmd_list(args):
    data = _load()
    rows = data["constraints"]
    if args.category:
        rows = [c for c in rows if c.get("category") == args.category]
    if args.severity:
        rows = [c for c in rows if c.get("severity") == args.severity]
    if args.json:
        print(json.dumps({"total": len(data["constraints"]), "count": len(rows),
                          "constraints": rows}, ensure_ascii=False, indent=2))
        return 0
    print(f"约束库共 {len(data['constraints'])} 条，当前过滤后 {len(rows)} 条\n")
    for c in rows:
        flag = {"must": "【铁律】", "should": "【推荐】", "may": "【可选】"}.get(c.get("severity"), "")
        print(f"  {str(c.get('id')):<12} {flag}{c.get('category')} | {c.get('title')}")
        print(f"               {c.get('rule')}")
        src, proj, crt = c.get("source") or "", c.get("project") or "", _created(c)
        if src or proj or crt:
            print(f"               来源: {src}  项目: {proj}  创建: {crt[:10]}")
    print()
    return 0


def cmd_add(args):
    if args.severity not in SEVERITY_ALLOWED:
        return _err(f"--severity 必须是 {'/'.join(SEVERITY_ALLOWED)} 之一")
    if not args.title or not args.rule:
        return _err("--title 与 --rule 必填")
    data = _load()
    for c in data["constraints"]:
        if c.get("category") == args.category and c.get("title") == args.title:
            return _err(f"已存在相同约束：{c.get('id')} {c.get('title')}（如需更新请用 import 或手工编辑）")
    entry = {
        "id": _next_id(data["constraints"], args.category),
        "category": args.category, "title": args.title, "rule": args.rule,
        "severity": args.severity, "source": args.source or "项目现场",
        "project": args.project or "", "createdAt": date.today().isoformat(),
    }
    data["constraints"].append(entry)
    _save(data)
    if args.json:
        print(json.dumps({"added": entry}, ensure_ascii=False, indent=2))
    else:
        print(f"[已追加] {entry['id']} | {args.category} | {args.title}")
        print(f"  写入文件: {DATA_PATH}")
        print("  本约束已写入技能权威源，本次会话剩余生成会自动应用。")
        print(f"  可用 `python3 gk_constraints.py doctor` 复核约束库完整性。")
    return 0


def cmd_init(args):
    if os.path.exists(DATA_PATH) and not args.force:
        return _err(f"约束库已存在：{DATA_PATH}\n        仅当文件损坏且无备份时才需重建；确认要覆盖请加 --force（会丢失现有条目）。")
    if os.path.exists(DATA_PATH) and args.force:
        try:
            with open(DATA_PATH + ".bak", "w", encoding="utf-8") as bak:
                bak.write(open(DATA_PATH, "r", encoding="utf-8", errors="replace").read())
        except Exception:
            pass
    data = {
        "meta": {"doc": "SPEC-CTRL-2026-001", "title": "工控项目统一开发约束集",
                 "version": "1.0", "seedDate": date.today().isoformat(),
                 "description": "本文件是 gongkong-constraints 技能的唯一权威约束源。severity: must=铁律/必须, should=推荐, may=可选。"},
        "constraints": [],
    }
    _save(data)
    print(f"[已重建] 空约束库骨架 -> {DATA_PATH}")
    print("  提示：可从技能压缩包重新解压原始 46 条，或用 Web 门户「导入 JSON」恢复备份。")
    return 0


def cmd_doctor(args):
    """约束库完整性自检：把'完整检查能力'真正交付出来。"""
    data = _load()
    rows = data["constraints"]
    problems = []
    seen_ids = {}
    seen_keys = {}
    for i, r in enumerate(rows):
        tag = f"第 {i + 1} 条（id={r.get('id', '?')}）"
        if not isinstance(r, dict):
            problems.append(f"{tag} 不是对象"); continue
        for f in REQUIRED_FIELDS:
            if f == "createdAt" and ("createdAt" in r or "created_at" in r):
                continue
            if f not in r or (f in ("id", "category", "title", "rule", "severity") and not str(r.get(f, "")).strip()):
                problems.append(f"{tag} 缺少必填字段 {f}")
        if r.get("severity") not in SEVERITY_ALLOWED:
            problems.append(f"{tag} severity 非法：{r.get('severity')}（应为 must/should/may）")
        if "created_at" in r and "createdAt" not in r:
            problems.append(f"{tag} 字段名 created_at 不统一（应改为 createdAt）")
        rid = str(r.get("id", ""))
        if rid in seen_ids:
            problems.append(f"{tag} id 与第 {seen_ids[rid] + 1} 条重复：{rid}")
        seen_ids[rid] = i
        key = (r.get("category"), r.get("title"))
        if key in seen_keys:
            problems.append(f"{tag} (分类,标题) 与第 {seen_keys[key] + 1} 条重复：{key}")
        seen_keys[key] = i
        exp = _prefix(str(r.get("category", "")))
        if rid and not re.match(r"^" + re.escape(exp) + r"-\d+$", rid):
            problems.append(f"{tag} 编号前缀不符规范：应为 {exp}-NN，实际 {rid}")
    meta = data.get("meta")
    if not isinstance(meta, dict) or not meta.get("version"):
        problems.append("缺少 meta.version（版本口径）")

    result = {"total": len(rows), "categories": len({r.get("category") for r in rows}),
              "severity": {s: sum(1 for r in rows if r.get("severity") == s) for s in SEVERITY_ALLOWED},
              "problems": problems, "ok": not problems}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"约束库自检：共 {result['total']} 条 / {result['categories']} 个分类；"
              f"铁律 {result['severity']['must']}、推荐 {result['severity']['should']}、可选 {result['severity']['may']}")
        if problems:
            print(f"\n[发现问题 {len(problems)} 项]")
            for p in problems[:50]:
                print("  - " + p)
            if len(problems) > 50:
                print(f"  …其余 {len(problems) - 50} 项略。")
            print("\n建议：按上述清单修正 references/constraints_data.json，或运行 init --force 重建。")
        else:
            print("\n[通过] 必填字段、id 唯一、分类+标题唯一、severity 合法、字段名、编号前缀、版本口径均正常。")
    return 0 if not problems else 1


# 检查项：(名称, 正则, 类型)  type=positive 应出现 / negative 不应出现（反模式）
POSITIVE_CHECKS = [
    ("布局清单驱动（存在 BusinessKey/FlowItemKey/TwinKey 等）", r"\b(UiLayoutItem|FlowChartItem|TwinLayoutItem|OverviewCardLayoutItem|BusinessKey|FlowItemKey|TwinKey|CardItemKey)\b"),
    ("控件元数据挂载（UiControlMeta）", r"\bUiControlMeta\b"),
    ("统一握手（Cmd_/Ack_ 变量对）", r"\b(Cmd_|Ack_)[A-Za-z0-9_]+"),
    ("分层架构（PlcDriver/Logic/Service/Model）", r"\b(PlcDriver|Logic|Service|Model)\b"),
    ("安全黑名单（ControlBlackList/BlackList/黑名单）", r"(ControlBlackList|BlackList|黑名单)"),
    ("颜色全局配置（ColorRule）", r"\bColorRule\b"),
    ("异常捕获（try/catch 或 try/except）", r"\btry\s*[:\{]|\bcatch\s*\(|\bexcept\b"),
    ("操作日志/来源标记（OperatorLog/OpSource/操作来源）", r"(OperatorLog|OpSource|OperationSource|操作日志|操作来源)"),
    ("启动校验器（LayoutValidator/ValidateLayout/Validator）", r"(LayoutValidator|ValidateLayout|UiLayoutValidator|\bValidator\b|布局校验)"),
    ("指令助手/统一命令入口（CommandHelper/CmdSender/指令助手）", r"(CommandHelper|CmdSender|CommandService|指令助手)"),
]

NEGATIVE_CHECKS = [
    ("零散实例化控件（new Button/Label/TextBox… 应只在工厂内出现）", r"new\s+(Button|Label|TextBox|ComboBox|Panel|GroupBox)\s*\("),
    ("源码内硬编码十六进制色值（应从 ColorRule 读取）", r"#(?:[0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b"),
    ("疑似裸写 PLC 输出（Write/WriteAsync 直接出现在事件回调附近不做全量判定）", r"\.(Write|WriteAsync)\s*\(\s*[\"'](?:Do_|Cmd_)"),
    ("硬编码坐标 Location/Point（应来自布局清单）", r"(Location\s*=\s*new\s+Point\(|new\s+Point\(\s*\d+\s*,\s*\d+\s*\))"),
]

SCAN_EXT = (".cs", ".js", ".ts", ".scl", ".xml", ".json", ".txt", ".md")
# 这些文件里的色值/坐标属配置或文档示例，不作为违规证据
NEG_SKIP_EXT = (".md", ".txt", ".json", ".xml")


def _scan_files(proj):
    """遍历项目，返回 (相对路径, 内容) 列表，并单独收集无法读取的文件。"""
    out, failed = [], []
    for root, dirs, files in os.walk(proj):
        dirs[:] = [d for d in dirs if d not in (".git", "bin", "obj", "node_modules", ".vs", "__pycache__")]
        for fn in files:
            if not fn.lower().endswith(SCAN_EXT):
                continue
            fp = os.path.join(root, fn)
            try:
                with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                    out.append((os.path.relpath(fp, proj), f.read()))
            except Exception as e:
                failed.append((os.path.relpath(fp, proj), str(e)))
    return out, failed


def cmd_validate(args):
    """对照 §10.3 自检清单扫描：正向特征判通过，反模式命中判违规（不再算合格）。"""
    proj = args.project
    if not proj or not os.path.isdir(proj):
        return _err(f"项目目录不存在或不可访问：{proj}\n        请检查路径是否正确、目录是否有权限读取。", 2)
    try:
        files, failed = _scan_files(proj)
    except Exception as e:
        return _err(f"扫描项目目录失败：{e}", 2)

    positives, negatives = [], []
    for name, pat in POSITIVE_CHECKS:
        hits = sorted({rel for rel, txt in files if re.search(pat, txt)})
        positives.append({"name": name, "ok": bool(hits), "files": hits[:5], "total": len(hits)})
    for name, pat in NEGATIVE_CHECKS:
        hits = sorted({rel for rel, txt in files
                       if not rel.lower().endswith(NEG_SKIP_EXT) and re.search(pat, txt)})
        negatives.append({"name": name, "violations": len(hits), "files": hits[:5]})

    dup_report = _check_layout_unique_keys(proj, files)
    passed = sum(1 for p in positives if p["ok"])
    violation_hits = sum(n["violations"] for n in negatives)
    ok = (passed == len(positives)) and violation_hits == 0 and not dup_report and not failed

    result = {
        "project": os.path.abspath(proj), "scanned_files": len(files),
        "positive_passed": passed, "positive_total": len(positives),
        "positives": positives, "negatives": negatives,
        "layout_duplicate_keys": [{"file": f, "keys": k} for f, k in dup_report],
        "unreadable_files": [{"file": f, "reason": r} for f, r in failed],
        "ok": ok,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if ok else 1

    print(f"对目录 {os.path.abspath(proj)} 做 §10.3 结构性扫描（共 {len(files)} 个文件）：\n")
    print("— 应有特征（命中=通过）—")
    for p in positives:
        tag = "通过" if p["ok"] else "建议核查"
        print(f"  [{tag}] {p['name']}")
        if p["ok"]:
            print(f"          命中 {p['total']} 个文件（示例：{', '.join(p['files'])}）")
    print("\n— 反模式扫描（命中=疑似违规，绝不计为合格）—")
    for n in negatives:
        if n["violations"]:
            print(f"  [发现 {n['violations']} 处] {n['name']}")
            print(f"          示例文件：{', '.join(n['files'])}")
        else:
            print(f"  [未发现] {n['name']}")
    if dup_report:
        print("\n[不通过] 布局清单内发现重复唯一键（违反 §10.3 第 3 项）：")
        for f, keys in dup_report:
            print(f"    {f}: {', '.join(keys)}")
    elif violation_hits == 0:
        print("\n[通过] 反模式与布局清单唯一键检查：未发现违规。")
    if failed:
        print(f"\n[警告] {len(failed)} 个文件无法读取（可能是损坏或权限问题），已跳过：")
        for f, r in failed[:20]:
            print(f"    {f} -> {r}")
    print(f"\n小结：正向特征 {passed}/{len(positives)} 项通过；反模式疑似违规 {violation_hits} 处；"
          f"重复唯一键 {len(dup_report)} 处；无法读取 {len(failed)} 个文件。")
    print("注意：本扫描是辅助手段，反模式命中需人工确认（例如工厂内 new Button 属合法），"
          "最终以人工逐条核对 §10.3 为准，切勿把'疑似'当作'已合格'。")
    return 0 if ok else 1


def _check_layout_unique_keys(proj, files=None):
    """查找布局清单类 JSON，校验四类唯一键不重复。"""
    key_fields = ("BusinessKey", "FlowItemKey", "TwinKey", "CardItemKey")
    report = []
    if files is None:
        files, _ = _scan_files(proj)
    from collections import Counter
    for rel, text in files:
        if not rel.lower().endswith(".json") or not any(k in text for k in key_fields):
            continue
        try:
            obj = json.loads(text)
        except Exception:
            report.append((rel, ["(JSON 解析失败，无法校验)"]))
            continue
        items = obj if isinstance(obj, list) else (obj.get("items") or obj.get("layout") or [])
        if not isinstance(items, list):
            continue
        seen = {}
        for it in items:
            if not isinstance(it, dict):
                continue
            for k in key_fields:
                if it.get(k):
                    seen.setdefault(k, []).append(it[k])
        dups = [f"{k}={v}(×{c})" for k, vals in seen.items() for v, c in Counter(vals).items() if c > 1]
        if dups:
            report.append((rel, dups))
    return report


def cmd_export(args):
    data = _load()
    out = args.output or os.path.join(SKILL_ROOT, "constraints_export.json")
    payload = {
        "exportedAt": date.today().isoformat(),
        "from": "gongkong-constraints local",
        "constraints": [_norm_row(r) for r in data["constraints"]],
    }
    try:
        with open(out, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
    except PermissionError:
        return _err(f"没有写入权限：{out}\n        请换一个有权限的输出路径，或检查目录权限。", 2)
    except OSError as e:
        return _err(f"导出失败：{out}\n        原因：{e}", 2)
    print(f"[已导出] {len(data['constraints'])} 条约束 -> {out}")
    print("  用途：备份 / 在 Web 门户「导入 JSON」恢复 / 合并到另一份技能库。")
    return 0


def cmd_import(args):
    src = args.input
    if not os.path.exists(src):
        return _err(f"导入文件不存在：{src}\n        请检查路径；导出/备份的 JSON 请先保存到本地再导入。", 2)
    try:
        with open(src, "r", encoding="utf-8") as f:
            payload = json.load(f)
    except json.JSONDecodeError as e:
        return _err(f"导入文件不是合法 JSON（第 {e.lineno} 行第 {e.colno} 列：{e.msg}）：{src}\n"
                    "        请确认是 export / Web 门户导出的完整文件，未被截断或手动改坏。", 2)
    except PermissionError:
        return _err(f"没有读取权限：{src}", 2)
    except OSError as e:
        return _err(f"读取导入文件失败：{src}\n        原因：{e}", 2)
    if not isinstance(payload, dict):
        return _err("导入文件顶层必须是 JSON 对象（含 constraints 数组）。", 2)
    incoming = payload.get("constraints") or payload.get("data") or []
    if not isinstance(incoming, list):
        return _err("导入文件格式不正确：未找到 constraints 数组（或 data 数组）。", 2)
    bad = [i + 1 for i, c in enumerate(incoming) if not isinstance(c, dict) or not c.get("title") or not c.get("rule")]
    if bad:
        return _err(f"导入文件中有 {len(bad)} 条记录缺少 title/rule（第 {bad[:10]} 条），未做任何修改。\n"
                    "        请修正后重试；为避免写坏约束库，本次导入已整体中止。", 2)
    data = _load()
    existing = {(c.get("category"), c.get("title")) for c in data["constraints"]}
    existing_ids = {str(c.get("id")) for c in data["constraints"]}
    added, skipped = 0, 0
    for raw in incoming:
        c = _norm_row(raw)
        key = (c.get("category"), c.get("title"))
        if key in existing:
            skipped += 1
            continue
        rid = str(c.get("id", ""))
        if not rid or rid in existing_ids:
            c["id"] = _next_id(data["constraints"], str(c.get("category", "")))
        data["constraints"].append(c)
        existing.add(key)
        existing_ids.add(str(c["id"]))
        added += 1
    _save(data)
    print(f"[已合并] 新增 {added} 条，跳过重复 {skipped} 条。")
    print(f"  本地约束库现共 {len(data['constraints'])} 条。")
    print("  建议运行 `python3 gk_constraints.py doctor` 复核完整性。")
    return 0


def main():
    p = argparse.ArgumentParser(description="工控统一开发约束库管理 CLI（纯本地）")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_list = sub.add_parser("list", help="列出约束")
    p_list.add_argument("--category", help="按分类过滤")
    p_list.add_argument("--severity", choices=SEVERITY_ALLOWED, help="按严重度过滤")
    p_list.add_argument("--json", action="store_true", help="以 JSON 输出")
    p_list.set_defaults(func=cmd_list)

    p_add = sub.add_parser("add", help="追加新约束")
    p_add.add_argument("--category", required=True)
    p_add.add_argument("--title", required=True)
    p_add.add_argument("--rule", required=True)
    p_add.add_argument("--severity", default="should", choices=SEVERITY_ALLOWED)
    p_add.add_argument("--project", default="")
    p_add.add_argument("--source", default="项目现场")
    p_add.add_argument("--json", action="store_true", help="以 JSON 输出")
    p_add.set_defaults(func=cmd_add)

    p_doc = sub.add_parser("doctor", help="约束库完整性自检")
    p_doc.add_argument("--json", action="store_true", help="以 JSON 输出")
    p_doc.set_defaults(func=cmd_doctor)

    p_val = sub.add_parser("validate", help="对照自检清单扫描项目目录")
    p_val.add_argument("--project", required=True, help="项目目录路径")
    p_val.add_argument("--json", action="store_true", help="以 JSON 输出")
    p_val.set_defaults(func=cmd_validate)

    p_exp = sub.add_parser("export", help="导出约束库为 JSON")
    p_exp.add_argument("-o", "--output", help="输出文件路径")
    p_exp.set_defaults(func=cmd_export)

    p_imp = sub.add_parser("import", help="从 JSON 合并回本地约束库")
    p_imp.add_argument("-i", "--input", required=True, help="导入文件路径")
    p_imp.set_defaults(func=cmd_import)

    p_init = sub.add_parser("init", help="重建空约束库骨架（谨慎）")
    p_init.add_argument("--force", action="store_true", help="覆盖已存在文件（先自动备份 .bak）")
    p_init.set_defaults(func=cmd_init)

    args = p.parse_args()
    try:
        rc = args.func(args)
        sys.exit(rc if isinstance(rc, int) else 0)
    except KeyboardInterrupt:
        sys.exit(_err("操作已被用户中断。", 2))
    except SystemExit:
        raise
    except Exception as e:
        sys.exit(_err(f"命令执行时发生未预期错误：{type(e).__name__}: {e}\n"
                      "        请检查输入与文件状态；若反复出现，请把本提示反馈给技能维护者。", 2))


if __name__ == "__main__":
    main()
