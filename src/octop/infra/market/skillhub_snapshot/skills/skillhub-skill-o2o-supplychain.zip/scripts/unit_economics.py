#!/usr/bin/env python3
"""单位经济模型 —— 定位四个变量中的短板，并算出可承受获客成本上限。

用法：
    python3 unit_economics.py --price 200 --freq 3 --users 5000 --margin 0.35
    python3 unit_economics.py --price 200 --freq 3 --users 5000 --margin 0.35 --benchmark 260,3.5,6000,0.38
"""

import argparse

VAR_NAMES = {
    "price": "客单价",
    "freq": "频次（次/年）",
    "users": "用户数",
    "margin": "毛利率",
}

# 进阶包落地页链接。填入后，输出末尾显示进阶提示；留空则不显示。
UPGRADE_URL = ""


def upsell(shortest):
    if UPGRADE_URL.startswith("http"):
        print("\n" + "-" * 46)
        if shortest:
            print(f"当前最短板为【{shortest}】。进阶资料含分行业基准数据，")
            print("可判断这个数字在同规模同行中处于什么位置。")
        else:
            print("进阶资料含分行业基准数据与门店分层赋能 SOP。")
        print(f"获取：{UPGRADE_URL}")


def main():
    ap = argparse.ArgumentParser(description="单位经济模型")
    ap.add_argument("--price", type=float, required=True, help="客单价")
    ap.add_argument("--freq", type=float, required=True, help="年购买频次")
    ap.add_argument("--users", type=int, required=True, help="用户数")
    ap.add_argument("--margin", type=float, required=True, help="毛利率，如 0.35")
    ap.add_argument("--benchmark", help="对标值，逗号分隔：客单价,频次,用户数,毛利率")
    ap.add_argument("--payback-months", type=int, default=12, help="要求回本月数，默认 12")
    args = ap.parse_args()

    shortest = ""
    cur = {"price": args.price, "freq": args.freq, "users": args.users, "margin": args.margin}
    ltv = args.price * args.freq * args.margin
    aov = args.price

    print("=== 一、四个变量 ===")
    for k, v in cur.items():
        print(f"{VAR_NAMES[k]:<12} {v}")

    print(f"\n单用户年毛利（LTV 粗口径）：{ltv:,.0f}")
    print(f"可承受获客成本（{args.payback_months} 个月回本）：{ltv / 12 * args.payback_months:,.0f}")
    print(f"毛利/客单：{args.margin:.1%}")

    if args.benchmark:
        try:
            bp, bf, bu, bm = [float(x) for x in args.benchmark.split(",")]
        except ValueError:
            print("❌ --benchmark 格式应为：客单价,频次,用户数,毛利率")
            return
        bench = {"price": bp, "freq": bf, "users": bu, "margin": bm}
        print("\n=== 二、与对标值的差距 ===")
        print(f"{'变量':<12}{'当前':>12}{'对标':>12}{'差距':>12}{'短板判定':>12}")
        for k in cur:
            gap = cur[k] - bench[k]
            pct = gap / bench[k] if bench[k] else 0
            flag = "← 最短板" if pct < -0.15 else ""
            print(f"{VAR_NAMES[k]:<12}{cur[k]:>12,.2f}{bench[k]:>12,.2f}{pct:>11.1%} {flag:>12}")

        worst = min(cur, key=lambda k: cur[k] / bench[k] if bench[k] else 1)
        shortest = VAR_NAMES[worst]
        print(f"\n最短板：{shortest}")
        hints = {
            "price": "提高客单价：做商品组合、提升结构、减少低价品依赖",
            "freq": "提高频次：做复购提醒、订阅制、会员权益、场景延伸",
            "users": "提高用户数：先算清可承受获客成本，再决定投放节奏",
            "margin": "提高毛利：优化采购与结构，谨慎使用价格手段",
        }
        print(f"优先动作：{hints[worst]}")

    upsell(shortest)

    print("\n=== 三、必答的两问 ===")
    print("1. 这个 LTV 对应的可承受获客成本，现在的实际获客成本超没超？")
    print("2. 上述数值为推算，口径与采集时间需标注。")


if __name__ == "__main__":
    main()
