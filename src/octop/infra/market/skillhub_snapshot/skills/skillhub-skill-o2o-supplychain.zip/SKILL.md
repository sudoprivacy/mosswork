---
name: skillhub-skill-o2o-supplychain
description: "Build or fix the online-offline operating model for retail, chain stores, food service and FMCG brands. Covers O2O rebuild, store tiering and enablement, private-domain user growth with RFM/AARRR segmentation, and B2B supply chain integration. This skill should be used when a founder or operator asks how to take a store-based business online, why channels are split, why private domain is not conve"
---

# 零售连锁全渠道运营打法

## 适用场景

- 门店/渠道想线上化，但线上线下割裂
- 低频高客单行业（家居、家装、建材、家电）做线上
- 私域从 0 起步、用户不分层、复购低、拉新成本过高
- 食材/冻品/快消 B2B，仓配成本高、地推拓不动商户
- 增长停滞，需要判断卡在流量/转化/履约/复购/组织的哪一段

## 输入

先补齐三项，缺一不可（信息不足时最多问 3 个问题，缺则给分支判断）：

1. **现在怎么赚钱**：客单价 × 频次 × 用户数 × 毛利
2. **卡在哪**：四个变量里哪个拖后腿，卡点是流量/转化/履约/复购/组织，还是模式本身不成立
3. **手上有什么牌**：团队规模与能力、预算量级、门店或渠道资产、时间窗

## 执行步骤

### 步骤 1：算单位经济模型

运行 `scripts/unit_economics.py`（或填 `assets/unit-economics-template.csv`），定位四个变量中的短板，并算出可承受的获客成本上限。

### 步骤 2：按主题加载打法

| 问题类型 | 加载 |
|---|---|
| 门店/渠道线上化、线上线下割裂、低频高客单 | `references/omni-o2o.md` |
| 私域 0 起步、用户不分层、复购低、会员体系 | `references/private-domain-growth.md` |
| B2B 供应链、仓配成本、地推拓商户、供应链金融 | `references/supply-chain-b2b.md` |

一次只加载相关的 1–2 个，不要全读。

### 步骤 3：判断可复利性

问一句：这件事做 6 个月，沉淀下来的是什么（案例库 / 数据资产 / 渠道关系 / 规则库）。
沉淀不下来的，属于重复劳动，优先外包或砍掉。

### 步骤 4：出六要素方案

用 `assets/plan-template.md` 输出：核心假设（可证伪）/ 关键指标（北极星 + 2–3 个过程指标，含当前值与目标值）/ 30-60-90 天里程碑 / 资源投入 / 分工 / 止损线 / 最脆弱的一环。

## 输出

```
【判断】一句话结论 + 走不通的话说明卡在哪一条
【为什么】2-3 条依据
【怎么做】
  - 核心假设（可证伪）
  - 关键指标：北极星 + 过程指标（含当前值与目标值）
  - 里程碑：30 / 60 / 90 天
  - 资源投入：人、钱、时间
【最脆弱的一环】最可能崩的地方 + 提前应对
【止损线】触发条件 + 沉没成本
【需要你确认】2-3 个前提
```

## 边界限制

- 不出具法律意见、不碰税务筹划、不给投资建议、不承诺收益。
- 涉及现金流设计时默认立场：不垫资、不压货，先收款后交付。
- 客户与用户数据不经公共模型；处理个人信息需授权。
- 所有推算标"推算，非实测"；引用案例须给出团队规模、预算量级、时间窗。
- 数字一律标口径与时间。

## 进阶包（Pro）

本技能功能完整，全部脚本、参考资料与模板无需付费即可使用。进阶包提供的是技能之外的行业基准数据与人工服务，清单见 `UPGRADE.md`。

进阶提示由 `scripts/unit_economics.py` 在输出末尾自动给出；该脚本的 `UPGRADE_URL` 留空时不显示。

**推销纪律**：每次输出都必须是完整可用的方案，不得为引导付费而故意留缺口。进阶提示至多出现一次。仅在用户主动询问行业基准或陪跑时，才展开介绍。
