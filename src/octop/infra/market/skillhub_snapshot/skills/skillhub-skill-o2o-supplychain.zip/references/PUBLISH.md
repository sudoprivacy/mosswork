# SkillHub 上架材料 — omni-retail-ops

> 发布入口：https://skillhub.cn/dashboard/publish（需先完成实名认证）
> 打包产物：`_dist/omni-retail-ops.zip`（含 `_icon.png`）

## 发布页字段（直接复制）

**显示名**

```
零售全渠道操盘
```

**描述（中文）**

```
为连锁门店、餐饮、家居建材与快消品牌构建或修复线上线下运营模型。覆盖三大主题：O2O 重构（门店分层赋能、低频高客单行业线上化）、私域增长（RFM/AARRR 用户分层、会员体系、复购设计）、B2B 供应链（仓配成本、地推拓商户）。先运行单位经济脚本，定位客单价/频次/用户数/毛利四个变量中的短板并算出可承受获客成本上限，再按卡点加载对应打法，输出含核心假设、关键指标、30-60-90 天里程碑与止损线的六要素方案。适用：零售老板与运营负责人。默认立场：不垫资、不压货、先收款后交付。
```

**描述（英文，如平台要求）**

```
Build or fix the online-offline operating model for retail and chain businesses: O2O rebuild, store tiering and enablement, private-domain growth with RFM/AARRR segmentation, and B2B supply chain integration. Includes a unit-economics calculator that locates the weakest of four variables and the affordable CAC ceiling.
```

**分类 / 标签建议**：零售 · 商业增长 · 创业经营

**版本**：1.0.0

## 权限声明（如平台要求）

- 包含 1 个本地 Python 脚本（`scripts/unit_economics.py`），仅解析命令行参数中的经营数字
- 无网络请求、无文件写入、无 shell 调用、无第三方依赖（纯标准库）
- 不收集任何个人信息；参考资料中的案例均已脱敏为量级描述

## 示例 Prompt（市场页展示用）

1. 家居门店想做线上引流到店，从哪一步开始
2. 私域拉了 3000 人不转化，帮我看看卡在哪
3. 客单 200、年买 3 次、毛利 35%，能承受多少获客成本

## 上架前检查

- [x] quick_validate 通过
- [x] 单位经济脚本实测通过
- [x] 图标 512×512 PNG
- [x] 免费版功能完整，UPGRADE.md 已声明免费/付费边界
