#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通用 · 敏感词机检
==============
用法：
    python3 sensitive_scan.py 文案.txt
    python3 sensitive_scan.py . --hard-only        # 扫目录
    echo "文案" | python3 sensitive_scan.py        # 管道
    python3 sensitive_scan.py 文案.md --show-clean # 连通过项也列出来

退出码：
    0 = 干净，可以发
    1 = 命中 HARD，必须改
    2 = 用法错误
    3 = 词表缺失（重要：不会静默放行）

设计原则：
- 词表与脚本同目录的 sensitive-words.md，一行一条「词||等级||建议」。
- 扫描 .md 时自动跳过 ``` 代码块（词表、示例本身不应被判违规）。
- 词表读不到就直接报错退出，绝不"用内置 12 个词凑合扫一遍"。
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DICT_FILE = os.path.join(HERE, "sensitive-words.md")

C_RED = "\033[31m"
C_YEL = "\033[33m"
C_GRN = "\033[32m"
C_DIM = "\033[2m"
C_END = "\033[0m"


def load_dict(path=DICT_FILE):
    """解析「词||HARD||建议」格式。读不到就报错，不兜底。"""
    if not os.path.exists(path):
        print(f"{C_RED}✗ 词表不存在：{path}{C_END}", file=sys.stderr)
        print("  这个扫描器依赖同目录的 sensitive-words.md（170+ 条）。缺了它，扫描结果不完整，"
              "所以这里直接停下，不给你一个假的「通过」。", file=sys.stderr)
        print("  修复：确认 sensitive-words.md 与 sensitive_scan.py 在同一目录。", file=sys.stderr)
        sys.exit(3)

    rules = []
    with open(path, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line or line.startswith("#") or line.startswith(">"):
                continue
            m = re.match(r"^(.+?)\|\|\s*(HARD|SOFT)\s*\|\|\s*(.*)$", line)
            if m:
                word = m.group(1).strip()
                if word:
                    rules.append((word, m.group(2), m.group(3).strip()))
    if not rules:
        print(f"{C_RED}✗ 词表为空或格式不对：{path}{C_END}", file=sys.stderr)
        print("  应为每行「词||HARD||建议替换」。", file=sys.stderr)
        sys.exit(3)
    return rules


def strip_fences(text):
    """把 ``` 代码块内容替换为空行（保留行号），避免词表自己被判违规。"""
    out, inside = [], False
    for line in text.split("\n"):
        if line.lstrip().startswith("```"):
            inside = not inside
            out.append("")
            continue
        out.append("" if inside else line)
    return "\n".join(out)


def is_word_boundary_ok(text, idx, word):
    """英文词前后不能紧贴字母数字，避免 pin 命中 spin。"""
    if not re.fullmatch(r"[A-Za-z0-9 ]+", word):
        return True
    before = text[idx - 1] if idx > 0 else " "
    after = text[idx + len(word)] if idx + len(word) < len(text) else " "
    return not (before.isalnum() or after.isalnum())


def scan_text(text, rules, fname="<text>", skip_code=True):
    if skip_code:
        text = strip_fences(text)
    low = text.lower()
    hits = []
    for word, level, repl in rules:
        wl = word.lower()
        start = 0
        while True:
            i = low.find(wl, start)
            if i < 0:
                break
            if is_word_boundary_ok(low, i, wl):
                line_no = low.count("\n", 0, i) + 1
                # 取所在行的上下文，便于定位
                ls = low.rfind("\n", 0, i) + 1
                le = low.find("\n", i)
                snippet = text[ls:le if le > 0 else len(text)].strip()
                hits.append({
                    "word": word, "level": level, "repl": repl,
                    "file": fname, "line": line_no,
                    "snippet": snippet[:60] + ("…" if len(snippet) > 60 else ""),
                })
                start = i + len(wl)
            else:
                start = i + 1
    # 去重（同词同行只报一次）
    seen, uniq = set(), []
    for h in hits:
        k = (h["word"], h["file"], h["line"])
        if k in seen:
            continue
        seen.add(k)
        uniq.append(h)
    return uniq


def iter_files(target):
    if os.path.isfile(target):
        yield target
    else:
        for root, dirs, files in os.walk(target):
            dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "_frames"}]
            for fn in sorted(files):
                if fn.endswith((".md", ".txt", ".py", ".json", ".csv")):
                    # 词表与脚本本身是"教材"，不扫
                    if fn in {"sensitive-words.md", "sensitive_scan.py"}:
                        continue
                    yield os.path.join(root, fn)


def main():
    args = [a for a in sys.argv[1:]]
    hard_only = "--hard-only" in args
    show_clean = "--show-clean" in args
    args = [a for a in args if not a.startswith("--")]
    target = args[0] if args else None

    rules = load_dict()

    if target is None or target == "-":
        text = sys.stdin.read()
        hits = scan_text(text, rules, "<stdin>")
        sources = 1
    elif os.path.exists(target):
        hits = []
        sources = 0
        for fp in iter_files(target):
            sources += 1
            try:
                hits += scan_text(open(fp, encoding="utf-8").read(), rules,
                                  os.path.relpath(fp, os.getcwd()))
            except UnicodeDecodeError:
                continue
    else:
        print(f"找不到：{target}", file=sys.stderr)
        sys.exit(2)

    hard = [h for h in hits if h["level"] == "HARD"]
    soft = [] if hard_only else [h for h in hits if h["level"] == "SOFT"]

    if hard:
        print(f"\n{C_RED}❌ HARD {len(hard)} 处（必须改，改完重扫）{C_END}")
        for h in hard:
            print(f"  {C_RED}「{h['word']}」{C_END}  {h['file']}:{h['line']}")
            print(f"     {C_DIM}{h['snippet']}{C_END}")
            if h["repl"]:
                print(f"     → {h['repl']}")

    if soft:
        print(f"\n{C_YEL}⚠️  SOFT {len(soft)} 处（看语境，人工判断）{C_END}")
        for h in soft[:40]:
            print(f"  {C_YEL}「{h['word']}」{C_END}  {h['file']}:{h['line']}   → {h['repl'] or '人工确认'}")

    if not hard and not soft:
        if show_clean:
            print(f"{C_GRN}✓ 干净：{sources} 个文件，词表 {len(rules)} 条，0 命中{C_END}")
        sys.exit(0)

    print(f"\n{C_DIM}扫了 {sources} 个文件 · 词表 {len(rules)} 条 · HARD {len(hard)} · SOFT {len(soft)}{C_END}")
    if hard:
        print(f"{C_RED}❌ 存在必须替换的词，先改再发。{C_END}")
        sys.exit(1)
    print(f"{C_YEL}⚠️ 无 HARD，SOFT 请人工过一眼。{C_END}")
    sys.exit(0)


if __name__ == "__main__":
    main()
