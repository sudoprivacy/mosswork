from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


TASKS = {
    "standard": [
        ("route", "路线与范围", 40),
        ("story", "故事骨架", 40),
        ("character", "角色与风格", 70),
        ("script", "剧本与分镜", 90),
        ("keyframes", "关键帧素材", 80),
        ("video", "视频镜头", 150),
        ("edit", "声音与剪辑", 90),
        ("publish", "检查与发布", 40),
    ],
    "mini": [
        ("route", "路线与范围", 30),
        ("story", "故事骨架", 30),
        ("character", "角色与风格", 45),
        ("script", "剧本与分镜", 60),
        ("keyframes", "关键帧素材", 45),
        ("video", "视频镜头", 75),
        ("edit", "声音与剪辑", 55),
        ("publish", "检查与发布", 30),
    ],
}


def parse_day(value: str, field: str) -> date:
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} 必须是 YYYY-MM-DD：{value!r}") from exc


def date_range(start: date, end: date) -> list[date]:
    if end < start:
        raise ValueError("target_date 不能早于 start_date")
    count = (end - start).days + 1
    return [start + timedelta(days=offset) for offset in range(count)]


def remaining_tasks(scope: str, completed: set[str]) -> list[dict[str, Any]]:
    all_ids = {task_id for task_id, _, _ in TASKS[scope]}
    unknown = completed - all_ids
    if unknown:
        raise ValueError(f"completed 含未知任务：{', '.join(sorted(unknown))}")
    return [
        {"id": task_id, "name": name, "minutes": minutes}
        for task_id, name, minutes in TASKS[scope]
        if task_id not in completed
    ]


def add_item(schedule: dict[date, list[dict[str, Any]]], day: date, task: dict[str, Any], minutes: int) -> None:
    schedule.setdefault(day, []).append(
        {"task_id": task["id"], "task": task["name"], "minutes": minutes}
    )


def allocate_forward(
    tasks: list[dict[str, Any]], start: date, daily_minutes: int, blocked: set[date]
) -> tuple[dict[date, list[dict[str, Any]]], date]:
    if not tasks:
        return {}, start
    schedule: dict[date, list[dict[str, Any]]] = {}
    day = start
    used = 0
    for task in tasks:
        remaining = task["minutes"]
        while remaining > 0:
            while day in blocked:
                day += timedelta(days=1)
                used = 0
            capacity = daily_minutes - used
            if capacity <= 0:
                day += timedelta(days=1)
                used = 0
                continue
            chunk = min(capacity, remaining)
            add_item(schedule, day, task, chunk)
            remaining -= chunk
            used += chunk
            if used >= daily_minutes and remaining > 0:
                day += timedelta(days=1)
                used = 0
    return schedule, max(schedule)


def allocate_backward(
    tasks: list[dict[str, Any]], days: list[date], daily_minutes: int
) -> dict[date, list[dict[str, Any]]]:
    if not tasks:
        return {}
    schedule: dict[date, list[dict[str, Any]]] = {}
    day_index = len(days) - 1
    used = 0
    for task in reversed(tasks):
        remaining = task["minutes"]
        while remaining > 0:
            if day_index < 0:
                raise ValueError("倒推排程容量不足，无法在日期窗口内分配")
            capacity = daily_minutes - used
            if capacity <= 0:
                day_index -= 1
                used = 0
                continue
            chunk = min(capacity, remaining)
            add_item(schedule, days[day_index], task, chunk)
            remaining -= chunk
            used += chunk
            if used >= daily_minutes and remaining > 0:
                day_index -= 1
                used = 0
    for items in schedule.values():
        items.reverse()
    return schedule


def serialize_schedule(schedule: dict[date, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    return [
        {
            "date": day.isoformat(),
            "total_minutes": sum(item["minutes"] for item in schedule[day]),
            "items": schedule[day],
        }
        for day in sorted(schedule)
    ]


def build_plan(data: dict[str, Any]) -> dict[str, Any]:
    start = parse_day(data.get("start_date", date.today().isoformat()), "start_date")
    target_raw = data.get("target_date")
    target = parse_day(target_raw, "target_date") if target_raw else None
    scope = data.get("scope", "standard")
    if scope not in TASKS:
        raise ValueError("scope 只能是 standard 或 mini")

    daily_minutes = data.get("daily_minutes")
    if not isinstance(daily_minutes, int) or isinstance(daily_minutes, bool) or daily_minutes <= 0:
        raise ValueError("daily_minutes 必须是大于0的整数")

    completed_raw = data.get("completed", [])
    if not isinstance(completed_raw, list) or not all(isinstance(item, str) for item in completed_raw):
        raise ValueError("completed 必须是任务ID数组")
    completed = set(completed_raw)

    blocked_raw = data.get("blocked_dates", [])
    if not isinstance(blocked_raw, list):
        raise ValueError("blocked_dates 必须是日期数组")
    blocked = {parse_day(item, "blocked_dates") for item in blocked_raw}

    tasks = remaining_tasks(scope, completed)
    total_minutes = sum(task["minutes"] for task in tasks)
    common = {
        "scope": scope,
        "scope_label": "30至60秒标准样片" if scope == "standard" else "15至30秒缩小样片",
        "start_date": start.isoformat(),
        "daily_minutes": daily_minutes,
        "remaining_minutes": total_minutes,
        "completed": sorted(completed),
        "notice": "这是按任务基线生成的排程，不是完成或收益保证。",
    }

    if target is None:
        schedule, finish = allocate_forward(tasks, start, daily_minutes, blocked)
        return {
            **common,
            "mode": "forward",
            "feasible": True,
            "target_date": None,
            "predicted_finish": finish.isoformat(),
            "required_daily_minutes": None,
            "capacity_gap_minutes": 0,
            "schedule": serialize_schedule(schedule),
        }

    window = [day for day in date_range(start, target) if day not in blocked]
    if not window and total_minutes > 0:
        raise ValueError("开始日到目标日之间没有可用日期")

    available_capacity = len(window) * daily_minutes
    feasible = available_capacity >= total_minutes
    required_daily = math.ceil(total_minutes / len(window)) if window else 0
    capacity_gap = max(0, total_minutes - available_capacity)

    effective_daily = daily_minutes if feasible else required_daily
    backward = allocate_backward(tasks, window, effective_daily) if tasks else {}
    current_forward, current_finish = allocate_forward(tasks, start, daily_minutes, blocked)
    warning = None
    if not feasible:
        warning = (
            f"按当前每天{daily_minutes}分钟无法在{target.isoformat()}前完成；"
            f"还差{capacity_gap}分钟。候选倒推表按每天{required_daily}分钟生成，"
            "用户需选择增加时间、缩短样片或移动日期。"
        )

    return {
        **common,
        "mode": "backward",
        "feasible": feasible,
        "target_date": target.isoformat(),
        "predicted_finish_with_current_capacity": current_finish.isoformat(),
        "required_daily_minutes": required_daily,
        "capacity_gap_minutes": capacity_gap,
        "schedule_assumed_daily_minutes": effective_daily,
        "warning": warning,
        "schedule": serialize_schedule(backward),
        "current_capacity_forward_schedule": serialize_schedule(current_forward) if not feasible else [],
    }


def load_input(args: argparse.Namespace) -> dict[str, Any]:
    if bool(args.input) == bool(args.json):
        raise ValueError("必须且只能提供 --input 或 --json 其中一个")
    if args.input:
        return json.loads(Path(args.input).read_text(encoding="utf-8"))
    return json.loads(args.json)


def main() -> int:
    parser = argparse.ArgumentParser(description="为AI短剧第一集生成正推或倒推时间表")
    parser.add_argument("--input", help="UTF-8 JSON输入文件")
    parser.add_argument("--json", help="直接传入JSON字符串")
    args = parser.parse_args()
    try:
        result = build_plan(load_input(args))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
