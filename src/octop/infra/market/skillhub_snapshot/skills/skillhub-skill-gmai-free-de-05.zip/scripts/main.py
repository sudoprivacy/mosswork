# -*- coding: utf-8 -*-
"""报表需求梳理表一键生成指令包（gmai-free-de-05）业务主脚本
免费技能：零费用，安装后可直接运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：报表需求梳理表一键生成指令成品（代码片段 / 配置样例 / 检查项清单，可直接落地）；问题定位与修复优先级（严重度 + 证据 + 动作）；验证步骤与回归建议（命令 + 期望输出）
建议输入（专业字段）：分析目标；数据集
"""
import json, os, re, sys, time

SLUG = "gmai-free-de-05"
TITLE = "报表需求梳理表一键生成指令包"
PRICE_FEN = 0
CATEGORY = "企业系统集成与ERP"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['分析目标', True, ['目标', '分析目的', '问题'], '目标不清会导致指标选择失焦'], ['数据集', True, ['数据源', '数据集', '数据表'], '须说明来源表与提取条件'], ['时间范围', False, ['时间窗', '统计周期', '时间范围'], '决定可比性'], ['样本量', False, ['记录数', '样本量', '行数'], '决定结论置信度'], ['已知口径问题', False, ['口径问题', '已知问题', '争议口径'], '需在结论中显式说明']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'metrics': [['活跃用户数', '去重后的有效访问用户（按用户标识去重，排除内部与爬虫）', '自然日', '按用户标识去重'], ['转化率', '完成目标行为的去重用户 ÷ 同期活跃用户', '自然日', '分子分母同口径去重'], ['人均使用时长', '总时长 ÷ 活跃用户数（剔除异常值：单次 >3 小时按缺失处理）', '自然周', '按用户去重后聚合'], ['次日留存率', 'T+1 仍活跃的用户 ÷ T 日新增用户', '按天对齐', '按用户标识去重'], ['收入', '已支付订单金额（含税，剔除退款）', '自然日', '按订单号去重']]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['Git 提交信息约定（Conventional Commits）：type(scope): subject', '语义化版本（SemVer 2.0.0）与变更记录（Keep a Changelog）规范', '缺陷复现三要素：环境、操作步骤、期望与实际结果', '研发工程通行准则：单一职责、依赖锁定、异常不吞、变更可回滚', '代码评审与单元测试判据：断言可判定、分支覆盖可度量']
# 自检项（输入完备度）
CHECKS = [['报表需求梳理表一键生成指令·输入与上下文核查', ['报表需求梳理表一键生成指令', 'ERP'], '先核对技术栈、版本与运行环境，缺项不臆测参数'], ['报表需求梳理表一键生成指令·方案与技术依据', ['ERP', '面向企业系统集成与场景'], '方案落到真实工程实践（单一职责/依赖锁定/异常不吞），拒绝玄学调优'], ['报表需求梳理表一键生成指令·边界与失败路径', ['面向企业系统集成与场景', '报表需求梳理表一键生成指令'], '覆盖空值、超时、并发与回滚路径，逐项给出失败后的可观测信号'], ['报表需求梳理表一键生成指令·验证方式', ['报表需求梳理表一键生成指令'], '给出可复现的验证步骤（命令/断言/期望输出），不以「看起来对」结案'], ['报表需求梳理表一键生成指令·诚信红线', ['破解软件', '植入后门'], '不得破解商业软件、植入后门或绕过授权校验，命中即终止']]
# 交付物构成
DELIVERABLES = ['报表需求梳理表一键生成指令成品（代码片段 / 配置样例 / 检查项清单，可直接落地）', '问题定位与修复优先级（严重度 + 证据 + 动作）', '验证步骤与回归建议（命令 + 期望输出）']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """数据分析交付物：目标口径 → 指标定义 → 数据质量 → 分析结论 → 行动建议"""
    P = ctx["spec"]["params"]; L = []
    goal = ctx["fv"]("分析目标")
    ds = ctx["fv"]("数据集")
    period = ctx["fv"]("时间范围")
    n = ctx["nm"]("样本量")
    issue = ctx["fv"]("已知口径问题")
    metrics = P.get("metrics") or []      # [[指标, 口径定义, 时间窗, 去重规则], ...]

    L.append(("一、分析目标与口径", [
        "- 分析目标：%s" % (brief(goal, 60) or "（未提供，目标不清会导致指标选择失焦）"),
        "- 数据集：%s" % (brief(ds, 60) or "（未提供，须说明来源表与提取条件）"),
        "- 时间范围：%s" % (brief(period, 40) or "（未提供，默认近 30 天）"),
        "- 样本量：%s" % (fmt(n) if n is not None else "（未提供，样本量决定结论置信度）"),
        "- 已知口径问题：%s" % (brief(issue, 50) or "未说明"),
    ]))

    rows = ["| 序号 | 指标 | 口径定义 | 时间窗 | 去重规则 |", "|---|---|---|---|---|"]
    for i, m in enumerate(metrics, 1):
        rows.append("| %d | %s | %s | %s | %s |" % (i, m[0], m[1], m[2], m[3]))
    if not metrics:
        rows.append("| 1 | 待补充指标 | 需明确分子分母与统计口径 | 待定 | 待定 |")
    L.append(("二、指标定义表", rows))

    L.append(("三、数据质量体检", [
        "| 检查项 | 检查方法 | 处理要求 |", "|---|---|---|",
        "| 缺失率 | 按字段统计空值占比 | 缺失 > 5% 的字段不得用于结论，需说明 |",
        "| 重复 | 按主键/业务键去重 | 重复记录须先确认是采集问题还是业务真实 |",
        "| 值域越界 | 数值范围与业务上限比对 | 越界值须核对来源并标记 |",
        "| 时间一致性 | 跨表时间字段能否对齐 | 时区与口径差异须统一 |",
        "| 分母口径 | 率类指标的分子分母是否同口径 | 不同口径不得混算 |",
        "",
        "体检结论未通过前，任何比率类结论都应标注为「待口径确认」。",
    ]))

    L.append(("四、分析框架与结论", [
        "| 层次 | 要回答的问题 | 输出 |", "|---|---|---|",
        "| 描述 | 发生了什么（趋势、分布、对比） | 指标现状与变化幅度 |",
        "| 归因 | 为什么发生（拆解到维度/环节） | 贡献度拆解 |",
        "| 预判 | 接下来会怎样（趋势外推） | 区间预测与前提假设 |",
        "| 决策 | 应该做什么（取舍） | 行动建议与优先级 |",
        "",
        "结论撰写规范：**每条结论必须附带数据依据与口径脚注**；相关性结论不得表述为因果；样本量不足时须显式说明局限。",
    ]))

    L.append(("五、行动建议", [
        "| 优先级 | 建议 | 依据 | 验证方式 |", "|---|---|---|---|",
        "| P0 | 修正口径或补数据（若体检未通过） | 三、体检结论 | 重跑后指标可复现 |",
        "| P1 | 针对主要贡献维度做改进实验 | 四、归因结论 | 前后对比（同口径） |",
        "| P2 | 建立例行监控看板 | 指标定义表 | 指标可自动刷新 |",
        "",
        "每一轮改进后按同一口径复算，避免口径变动带来的假改善。",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：免费（Free Skill · 零费用）",
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
