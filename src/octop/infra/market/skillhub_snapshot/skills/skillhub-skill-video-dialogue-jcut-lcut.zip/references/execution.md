# 执行与参数

在Skill目录执行。示例使用相对路径和源时间，需替换为自己的实际素材和有效区间。

```text
python scripts/dialogue_cut.py examples/project.json --output output/preview.mp4 --dry-run
python scripts/dialogue_cut.py examples/project.json --output output/preview.mp4
```

inputs恰好两项。mode为audio-first/video-first；offset_seconds至少一输出帧且小于两段中较短时长减一帧。edge_fade_seconds为0～0.05秒，且不超过最短声音片段的一半。audio为source/none，source模式至少一段有音轨。成片总时长为A+B-offset，具体源范围及切点写入报告。

canvas的width/height为64～3840偶数，fps为1～120整数，默认1080×1920/30fps。项目JSON中的素材相对路径以项目文件目录为准，输出相对当前工作目录；analyze的输入相对当前目录。--ffmpeg/--ffprobe可指定本地程序。

已有输出或报告默认停止，明确替换时用--overwrite；源视频、配置及硬链接别名不能被覆盖。--dry-run探测输入后只打印命令，不创建计划或成片。音轨按相对视频的起始时间差对齐，缺失区域补静音；HDR(PQ/HLG)输入要求先明确色彩流程。

输出H.264/yuv420p MP4，保留声音时AAC48kHz。每个成片附.render.json，包括执行参数、源探测、输出尺寸/时长/帧率/像素比例、FFmpeg版本、文件哈希和剪辑时间记录。报告含本地路径，分享前按需整理。

失败返回非零状态，可能留下部分MP4，不把文件存在当作完成。单次进程超时20分钟。先用短样片，避免长片与大量回放同时缓存。本包不联网安装依赖、不捆绑FFmpeg。仅Windows实测，macOS/Linux能力不能冒充实测。
