# 来源与组件

核对日期2026-10-16。滤镜与参数依据为[FFmpeg官方滤镜文档](https://ffmpeg.org/ffmpeg-filters.html)及[FFprobe文档](https://ffmpeg.org/ffprobe.html)。对白剪辑的J/L概念参考[Adobe剪辑说明](https://helpx.adobe.com/premiere/desktop/edit-projects/trim-clips/perform-j-cuts-and-l-cuts.html)，具体源范围与同步方法由本包明确列出并实测。

数据流：剪辑目标与本地素材 → 宿主助手选择参数/审阅清单 → Python数值和路径校验 → FFprobe与固定滤镜图 → 本地FFmpeg → 成片、时间映射和结构核验。配置不能注入shell命令或原始滤镜图。

silencedetect/ametadata提供低能量候选，trim/atrim与concat按清单粗剪；reverse/areverse与tpad执行倒放定格；对白切镜通过分开的声音/画面裁切及拼接保留源时间对应。三者分别负责停顿粗剪、动作回放、对白切镜，不重复字幕找高光、变速或补充镜头替换。

复用上一批原创media_common.py的路径保护、媒体归一、音轨起始时间对齐和输出核验；每包携带独立副本，不要求安装其他Skill。字幕和其他剪辑包通过MP4及时间记录衔接。

原创代码与说明按MIT发布，未复制第三方滤镜源码或二进制；FFmpeg由用户单独安装，受其构建自身许可约束。无钱包、Machine Pay、收费网关或二次收费调用。
