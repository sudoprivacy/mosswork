# 视频对白预入与延后切声

Slug：video-dialogue-jcut-lcut

版本：1.0.0

分类：设计多媒体 / 视频处理

制作对白先听后看或先看后听的J/L切镜，分别安排声音与画面切点，并修剪源片范围以保留后续音画对应。支持缺音轨补静音与轻微接缝淡化。

目标：账号三 @user_8b22ab22，免费本地标准 Skill。

发布ZIP：G:\技能资源总整理\14_专家技能包\staging\release-edit2-20261016\video-dialogue-jcut-lcut-v1.0.0-SkillHub.zip

SHA-256：4cd74e2cd52e470b3cf8f3744fbd0ef55e15b49adef2941ae15fec994f5b23ce

发布结果以同批发布记录及平台回读为准。文件类型白名单 .md/.py/.json/.png；PNG由平台独立图标入口上传。
