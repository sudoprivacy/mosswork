"""J/L cuts with source trim choices that preserve subsequent lip-sync."""
import sys
from media_common import context, number, norm, aligned_audio, finish


def main():
    args,cfg,w,h,fps,output,info,argv=context("Dialogue audio-first or video-first edit",2)
    mode=cfg.get("mode","audio-first")
    if mode not in {"audio-first","video-first"}:raise ValueError("mode must be audio-first or video-first")
    da,db=[x["duration"] for x in info]
    offset=number(cfg.get("offset_seconds",0.4),"offset_seconds",1/fps,min(da,db)-1/fps)
    fade=number(cfg.get("edge_fade_seconds",0.01),"edge_fade_seconds",0,min(0.05,(min(da,db)-offset)/2))
    audio=cfg.get("audio","source")
    if audio not in {"source","none"}:raise ValueError("audio must be source or none")
    present=any(x["has_audio"] for x in info)
    if audio=="source" and not present:raise ValueError("J/L sound edits need at least one audio track")
    has_audio=audio=="source" and present
    video_ranges=[(0,da),(offset,db)] if mode=="audio-first" else [(0,da-offset),(0,db)]
    audio_ranges=[(0,da-offset),(0,db)] if mode=="audio-first" else [(0,da),(offset,db)]
    total=da+db-offset;graph=[]
    for i,((vs,ve),(ass,ae)) in enumerate(zip(video_ranges,audio_ranges)):
        graph.append(f"[{i}:v]trim=start={vs:.9f}:end={ve:.9f},setpts=PTS-STARTPTS,{norm(w,h,fps,ve-vs)}[v{i}]")
        if has_audio:
            base=aligned_audio(info,i) if info[i]["has_audio"] else "anullsrc=r=48000:cl=stereo"
            chain=f"{base},apad,atrim=start={ass:.9f}:end={ae:.9f},asetpts=PTS-STARTPTS"
            if fade:chain+=f",afade=t=in:st=0:d={fade:.9f},afade=t=out:st={ae-ass-fade:.9f}:d={fade:.9f}"
            graph.append(chain+f"[a{i}]")
    graph.append("[v0][v1]concat=n=2:v=1:a=0[vout]")
    if has_audio:graph.append("[a0][a1]concat=n=2:v=0:a=1[aout]")
    visual_cut=video_ranges[0][1];sound_cut=audio_ranges[0][1]
    args.edit_info={"kind":"dialogue-jl-cut","mode":mode,"offset_seconds":offset,"video_ranges":video_ranges,
                    "audio_ranges":audio_ranges,"visual_cut":visual_cut,"sound_cut":sound_cut,
                    "source_sync_policy":"B video/audio share source time after their cut points"}
    argv.extend(["-filter_complex",";".join(graph)])
    finish(args,argv,output,info,w,h,fps,total,"[aout]" if has_audio else None)


if __name__=="__main__":
    try:main()
    except (ValueError,OSError,RuntimeError,KeyError,TypeError) as exc:
        print(f"Error: {exc}",file=sys.stderr);raise SystemExit(1)
