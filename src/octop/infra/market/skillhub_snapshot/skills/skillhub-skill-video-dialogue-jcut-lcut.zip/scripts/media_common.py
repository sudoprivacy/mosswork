"""Shared local media runtime. Python 3.10+, FFmpeg/FFprobe on PATH."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
from fractions import Fraction


def number(value, name, low, high):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be numeric")
    value = float(value)
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{name} must be in [{low}, {high}]")
    return value


def integer(value, name, low, high, even=False):
    result = number(value, name, low, high)
    if not result.is_integer() or (even and int(result) % 2):
        raise ValueError(f"{name} must be {'an even ' if even else 'an '}integer")
    return int(result)


def execute(argv, timeout=1200):
    try:
        result = subprocess.run(argv, capture_output=True, text=True, encoding="utf-8",
                                errors="replace", timeout=timeout, shell=False)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("Local media operation timed out; inspect the partial output") from exc
    if result.returncode:
        raise RuntimeError(result.stderr[-4000:] or result.stdout[-4000:])
    return result.stdout


def probe(path, ffprobe):
    data = json.loads(execute([ffprobe, "-v", "error", "-show_streams",
                               "-show_format", "-of", "json", str(path)]))
    video = next((s for s in data["streams"] if s["codec_type"] == "video"
                  and not s.get("disposition", {}).get("attached_pic")), None)
    if not video:
        raise ValueError(f"No video stream: {path.name}")
    if video.get("color_transfer") in {"smpte2084", "arib-std-b67"}:
        raise ValueError("HDR input requires a deliberate HDR/tone-map workflow first")
    duration = number(float(video.get("duration") or data["format"].get("duration", 0)),
                      "input duration", 0.02, 86400)
    audio_stream = next((s for s in data["streams"] if s["codec_type"] == "audio"), None)
    audio_offset = (float(audio_stream.get("start_time") or 0)-float(video.get("start_time") or 0)) if audio_stream else 0.0
    return {"duration": duration, "width": video["width"], "height": video["height"],
            "fps": video.get("avg_frame_rate"), "sar": video.get("sample_aspect_ratio"),
            "has_audio": any(s["codec_type"] == "audio" for s in data["streams"]),
            "path": str(path), "audio_offset": audio_offset}


def norm(w, h, fps, duration):
    return (f"scale=trunc(iw*sar/2)*2:ih,setsar=1,"
            f"scale={w}:{h}:force_original_aspect_ratio=decrease:force_divisible_by=2,"
            f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps},"
            f"trim=duration={duration:.6f},settb=AVTB,setpts=PTS-STARTPTS,format=yuv420p")


def rect(value, name, canvas_w, canvas_h):
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be an object")
    x = integer(value.get("x"), name+".x", 0, canvas_w, True)
    y = integer(value.get("y"), name+".y", 0, canvas_h, True)
    w = integer(value.get("width"), name+".width", 2, canvas_w, True)
    h = integer(value.get("height"), name+".height", 2, canvas_h, True)
    if x+w > canvas_w or y+h > canvas_h:
        raise ValueError(f"{name} exceeds canvas")
    return x, y, w, h


def context(description, expected_inputs):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("config", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--ffmpeg", default="ffmpeg")
    parser.add_argument("--ffprobe", default="ffprobe")
    args = parser.parse_args()
    for name in ("ffmpeg", "ffprobe"):
        resolved = shutil.which(getattr(args, name))
        if not resolved:
            raise ValueError(f"{name} not found; install an official local FFmpeg build")
        setattr(args, name, resolved)
    config_path = args.config.resolve()
    cfg = json.loads(config_path.read_text(encoding="utf-8-sig"))
    if not isinstance(cfg, dict):
        raise ValueError("Project config must be a JSON object")
    canvas = cfg.get("canvas", {})
    if not isinstance(canvas, dict):
        raise ValueError("canvas must be a JSON object")
    w = integer(canvas.get("width", 1080), "width", 64, 3840, True)
    h = integer(canvas.get("height", 1920), "height", 64, 3840, True)
    fps = integer(canvas.get("fps", 30), "fps", 1, 120)
    raw_inputs = cfg.get("inputs")
    lower, upper = expected_inputs if isinstance(expected_inputs, tuple) else (expected_inputs, expected_inputs)
    if not isinstance(raw_inputs, list) or not lower <= len(raw_inputs) <= upper:
        raise ValueError(f"inputs must contain {lower} to {upper} paths")
    paths = []
    for value in raw_inputs:
        if not isinstance(value, str) or not value.strip():
            raise ValueError("Input paths must be nonempty strings")
        path = (config_path.parent / value).resolve()
        if not path.is_file():
            raise ValueError(f"Missing input: {path}")
        paths.append(path)
    output = args.output.resolve()
    if output.suffix.lower() != ".mp4":
        raise ValueError("Output must be .mp4")
    if output in paths or output == config_path:
        raise ValueError("Output must differ from every input")
    if output.exists() and not args.overwrite:
        raise ValueError("Output exists; choose a new path or explicitly use --overwrite")
    sidecar = output.with_suffix(".render.json")
    if sidecar == config_path or sidecar in paths:
        raise ValueError("Render report must differ from project and sources")
    if sidecar.exists() and not args.overwrite:
        raise ValueError("Render report exists; choose a new output path")
    for source in paths + [config_path]:
        if output.exists() and output.samefile(source):
            raise ValueError("Output aliases an input file")
        if sidecar.exists() and sidecar.samefile(source):
            raise ValueError("Render report aliases an input file")
    info = [probe(path, args.ffprobe) for path in paths]
    base = [args.ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin",
            "-y" if args.overwrite else "-n", "-filter_complex_threads", "1"]
    for path in paths:
        base.extend(["-i", str(path)])
    return args, cfg, w, h, fps, output, info, base


def finish(args, argv, output, info, w, h, fps, duration, audio_map):
    argv.extend(["-map", "[vout]"])
    if audio_map:
        argv.extend(["-map", audio_map, "-c:a", "aac", "-ar", "48000", "-b:a", "192k"])
    else:
        argv.append("-an")
    argv.extend(["-c:v", "libx264", "-preset", "medium", "-crf", "20",
                 "-pix_fmt", "yuv420p", "-t", f"{duration:.6f}",
                 "-movflags", "+faststart", str(output)])
    report = {"argv": argv, "inputs": info, "expected": {
        "width": w, "height": h, "fps": fps, "duration": duration},
        "audio": audio_map or "none"}
    if hasattr(args, "edit_info"):
        report["edit"] = args.edit_info
    if args.dry_run:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return
    output.parent.mkdir(parents=True, exist_ok=True)
    execute(argv)
    actual = probe(output, args.ffprobe)
    if (actual["width"], actual["height"]) != (w, h):
        raise RuntimeError("Rendered geometry does not match requested canvas")
    if Fraction(actual["fps"]) != fps or actual["sar"] not in {"1:1", None}:
        raise RuntimeError("Rendered FPS or sample aspect ratio differs from requested output")
    if abs(actual["duration"]-duration) > max(0.15, 2/fps):
        raise RuntimeError("Rendered duration exceeds two-frame verification tolerance")
    report["actual"] = actual
    report["ffmpeg_version"] = execute([args.ffmpeg, "-version"]).splitlines()[0]
    with output.open("rb") as handle:
        digest = hashlib.sha256()
        for chunk in iter(lambda: handle.read(1024*1024), b""):
            digest.update(chunk)
        report["sha256"] = digest.hexdigest()
    output.with_suffix(".render.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(f"Rendered: {output}")


def audio_track(graph, info, chosen, duration):
    if chosen is None or not info[chosen]["has_audio"]:
        return None
    graph.append(aligned_audio(info, chosen) + ","
                 f"apad,atrim=duration={duration:.6f},asetpts=PTS-STARTPTS[aout]")
    return "[aout]"


def aligned_audio(info, index):
    offset = info[index].get("audio_offset", 0.0)
    return (f"[{index}:a:0]asetpts=PTS-STARTPTS+({offset:.9f})/TB,"
            "aresample=48000:async=1:first_pts=0,aformat=sample_fmts=fltp:channel_layouts=stereo")
