# 三份产物结构规范

三份产物同源：均读 `_bench/report_data.json`。首稿只出 HTML，Word 与 Excel 在用户确认后补出。字段先定，后生成，禁止各产物自行取数。

## 一、report_data.json 结构

```json
{
  "meta": {
    "school": "全称", "dept": "规范部门名", "province": "省", "level": "市属本科",
    "period": "2026", "generated_at": "2026-11-11",
    "bench_schools": ["对标校1", "对标校2"],
    "item_count": 8, "gap_count": 3, "copy_count": 5
  },
  "items": [
    {
      "id": "I1", "name": "微专业建设",
      "rows": [
        {"school": "本校全称", "self": true, "did": "做了什么，含数字与规则", "scale": "首批 3 个结业", "evidence": ["E3"]},
        {"school": "对标校全称", "did": "…", "scale": "21 个", "evidence": ["E27"]}
      ],
      "judgement": "一句判断：本校处在什么位置，差在哪"
    }
  ],
  "gaps": [
    {"item": "教师 AI 能力建设", "note": "缺什么、对方怎么做的、差多少", "evidence": ["E15", "E30"]}
  ],
  "copy_list": [
    {"id": "C1", "title": "抄的这件事叫什么", "source": "来源校",
     "why": "为什么要抄这件事", "steps": ["动宾短语", "动宾短语"],
     "need": "要准备什么", "owner": "谁牵头", "cycle": "多久", "cost": "多少钱",
     "condition": "① … ② … ③ …", "evidence": ["E31"]}
  ],
  "evidence": [
    {"id": "E1", "school": "校名", "title": "标题", "url": "https://", "date": "2026-03-12",
     "excerpt": "≤80字原文"}
  ]
}
```

约束：

- `items` 6–8 项，每项 `rows` 覆盖全部样本校（含本校），本校那行 `self: true`。
- 某校在某件事上没做，`did` 写「未检索到公开信息」，`evidence` 留空数组，**不删行**——缺行就比不出差距。
- `gaps` 恰好 3 条。
- `copy_list` 4–6 条，`steps` 2–4 条且每条以动词开头，`condition` 三条。
- `evidence` 编号连续，全文引用的编号必须真实存在。

## 二、HTML 报告

主交付物。单文件，内联 CSS，不引用任何外网资源。样式取 `assets/report_template.html`。

| 序 | 区块 | 内容 | 数据来源 |
|---|---|---|---|
| 1 | 概览条 | 学校+部门+周期；四个数字：对标校数、实事件数、本校缺口数、改进建议数 | `meta` |
| 2 | 五校实事件总览 | 一张矩阵：行=事项，列=学校，格内一句话摘要，本校列高亮 | `items[].rows[].scale` |
| 3 | 逐事对比 | 每事一张五校表（学校／做了什么／规模／证据）+ 一句判断块 | `items` |
| 4 | 本校三处短板 | 三张卡：缺什么、对方怎么做的、差多少 | `gaps` |
| 5 | 对标改进建议 | 每张卡：抄什么、为什么、步骤、材料、牵头、周期、成本、三个条件 | `copy_list` |
| 6 | 证据索引 | 表：编号、学校、标题（超链接）、日期、摘录 | `evidence` |

视觉约束：单强调色（深蓝 `#1F4E79` 系），左侧目录 sticky 可跳转，表格横向可滚动，打印去阴影。

## 三、Word 正式稿

`scripts/build_report_docx.py` 生成，全文微软雅黑（`w:eastAsia` + `w:ascii` + `w:hAnsi`，含样式级默认字体）。

| 章 | 标题 | 内容 |
|---|---|---|
| 一 | 检索范围与方法 | 检索周期、样本校、渠道、事项归纳依据 |
| 二 | 五校实事件总览 | 事项 × 学校矩阵表 |
| 三 | 逐事对比 | 每事一节：五校表 + 一句判断 |
| 四 | 本校短板 | `gaps` 三条 |
| 五 | 对标改进建议 | `copy_list` 每条含步骤与六项参数 |
| 六 | 证据与来源 | `evidence` 全表 |

## 四、Excel 对比表

`scripts/build_matrix.py` 生成，三张工作表：

| 表 | 名称 | 列头 |
|---|---|---|
| 1 | 实事对比 | 事项、学校、做法、规模、证据编号、证据URL、发布日期 |
| 2 | 对标改进建议 | 编号、事项、来源校、步骤、要准备什么、牵头、周期、成本、照搬条件 |
| 3 | 证据索引 | 编号、学校、标题、URL、日期、摘录 |

表头加粗、冻结首行、列宽自适应、URL 列超链接，全表微软雅黑。

## 五、一致性检查

1. `meta.item_count` 等于 `items` 长度，三份产物中事项数与顺序一致。
2. `meta.copy_count` 等于 `copy_list` 长度，也等于 HTML 卡片数与 Excel 表 2 行数。
3. `meta.gap_count` 等于 `gaps` 长度，恒为 3。
4. 三份产物里每条证据编号都能在 `evidence` 中找到。
5. HTML 中每个证据链接与 Excel 表 3 的 URL 一致。
