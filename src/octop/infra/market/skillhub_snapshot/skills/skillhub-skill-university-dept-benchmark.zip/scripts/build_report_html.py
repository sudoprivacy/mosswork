# -*- coding: utf-8 -*-
"""把 report_data.json 渲染成单文件 HTML 报告（主交付物）。

结构：概览 → 五校实事件总览 → 逐事对比 → 本校三处短板 → 抄作业清单 → 证据索引。
样式取 assets/report_template.html 的 <style>，脚本只生成正文与目录。

用法：
    python build_report_html.py --data report_data.json --out 报告.html

无参数运行时用内置样例，产物写到系统临时目录。
"""
from __future__ import annotations

import argparse
import html
import io
import json
import os
import re
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "..", "assets", "report_template.html")

TOC = [
    ("overview", "01", "概览"),
    ("allitems", "02", "五校实事件总览"),
    ("items", "03", "逐事对比"),
    ("gaps", "04", "本校三处短板"),
    ("copy", "05", "对标改进建议"),
    ("evidence", "06", "证据索引"),
]

EXTRA_CSS = """
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.item-block{margin-bottom:34px}
.item-block h3{font-size:16.5px;color:#1F4E79;margin-bottom:10px;
  display:flex;align-items:center;gap:10px}
.item-block h3 .idx{font-family:Georgia,serif;font-size:13px;color:#fff;
  background:#1F4E79;border-radius:4px;padding:2px 8px}
.item-tbl{width:100%;border-collapse:collapse;font-size:13.5px;
  border:1px solid #E7E7EB;border-radius:10px;overflow:hidden}
.item-tbl th{background:#F2F7FB;color:#1F4E79;font-size:12.5px;text-align:left;
  padding:9px 12px;border-bottom:1px solid #E7E7EB;white-space:nowrap}
.item-tbl td{padding:10px 12px;border-bottom:1px solid #E7E7EB;vertical-align:top}
.item-tbl tr:last-child td{border-bottom:0}
.item-tbl td.school{white-space:nowrap;font-weight:600;color:#1F4E79}
.item-tbl tr.self td{background:#EAF1F8}
.item-tbl td.scale{white-space:nowrap;font-size:12.5px;color:#5A6570}
.judge{background:#EAF1F8;border-left:4px solid #1F4E79;border-radius:0 8px 8px 0;
  padding:11px 16px;font-size:13.5px;color:#41505E;margin-top:10px}
.gap-card{border-left:4px solid #1F4E79;border-radius:0 10px 10px 0;background:#fff;
  padding:20px 22px;box-shadow:var(--sh1)}
.gap-card h4{font-size:15px;color:#1F4E79;margin-bottom:8px}
.gap-card p{font-size:13.5px;color:#41505E}
.copy-card{background:#fff;border:1px solid #E7E7EB;border-radius:12px;padding:24px 26px;
  box-shadow:var(--sh1);margin-bottom:20px;border-left:4px solid #1F4E79}
.copy-card h3{font-size:16px;color:#1F4E79}
.copy-card .src{font-size:12.5px;color:#8B8B95;margin-top:4px}
.copy-card .why{margin-top:12px;font-size:13.5px;color:#41505E;
  background:#F7F7F9;border-radius:8px;padding:11px 14px}
.copy-card ol{margin:14px 0 0 18px;font-size:14px;color:#3A3A43}
.copy-card ol li{margin-bottom:7px;line-height:1.7}
.copy-meta{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:16px;
  padding-top:14px;border-top:1px solid #E7E7EB;font-size:13px}
.copy-meta span{display:block;font-size:11.5px;color:#8B8B95;margin-bottom:2px}
.cond{margin-top:14px;font-size:13px;color:#41505E;border-top:1px dashed #E7E7EB;padding-top:12px}
@media(max-width:1024px){.grid3{grid-template-columns:1fr}.copy-meta{grid-template-columns:1fr 1fr}}
"""


def e(s) -> str:
    return html.escape("" if s is None else str(s))


def shell() -> tuple[str, str]:
    path = os.path.abspath(TEMPLATE)
    if not os.path.isfile(path):
        raise SystemExit(f"模板不存在：{path}")
    t = io.open(path, encoding="utf-8").read()
    css = re.search(r"<style>(.*?)</style>", t, re.S).group(1)
    script = re.search(r"(<script>.*?</script>)", t, re.S).group(1)
    return css + EXTRA_CSS, script


def render(d: dict, css: str, script: str) -> str:
    meta = d.get("meta", {})
    items = d.get("items", [])
    gaps = d.get("gaps", [])
    copies = d.get("copy_list", [])
    ev = d.get("evidence", [])
    schools = [meta.get("school", "")] + meta.get("bench_schools", [])

    o = []
    a = o.append

    a('<div class="bg-layer"></div>')
    a('<div class="wrap">')

    a('<nav class="toc" aria-label="目录"><h3>目录</h3><div class="hr"></div>')
    for i, (sid, no, nm) in enumerate(TOC):
        cls = ' class="on"' if i == 0 else ''
        a(f'  <a href="#{sid}"{cls}><span class="no serif">{no}</span>{nm}</a>')
    a('</nav>')
    a('<main>')

    a('<header class="hero" id="overview">')
    a(f'  <div class="eyebrow">{e(meta.get("province"))} · {e(meta.get("level"))} · {e(meta.get("period"))} 年度</div>')
    a(f'  <h1>{e(meta.get("school"))}{e(meta.get("dept"))}<br>今年办了哪几件事</h1>')
    a(f'  <p class="sub">对照 {len(meta.get("bench_schools", []))} 所同档院校同一部门，'
      f'按事排列，逐条挂证据。看别人怎么做的，挑能抄的。</p>')
    a('  <div class="stats">')
    a(f'    <div class="stat"><div class="num">{len(meta.get("bench_schools", []))}</div><div class="lab">对标院校</div></div>')
    a(f'    <div class="stat"><div class="num">{len(items)}</div><div class="lab">本年实事</div></div>')
    a(f'    <div class="stat"><div class="num">{len(gaps)}</div><div class="lab">本校缺口</div></div>')
    a(f'    <div class="stat"><div class="num">{len(copies)}</div><div class="lab">改进建议</div></div>')
    a('  </div>')
    a('</header>')

    a('<section id="allitems">')
    a('  <div class="sec-head"><div class="no serif">02</div>'
      '<h2>五校实事件总览<span class="en">Overview</span></h2></div>')
    a('  <div class="tbl-wrap"><table><thead><tr><th>事项</th>')
    for s in schools:
        a(f'<th style="text-align:center">{e(s)}</th>')
    a('</tr></thead><tbody>')
    for it in items:
        a(f'    <tr><td class="dim-name">{e(it.get("name"))}</td>')
        by = {r.get("school"): r for r in it.get("rows", [])}
        for s in schools:
            r = by.get(s, {})
            did = r.get("did") or ""
            if did.startswith("本轮检索未见"):
                mark, color, tip = "—", "#C9C9D2", "该渠道未见公开记录"
            elif "未见" in did and len(did) < 40:
                mark, color, tip = "◐", "#7FA3C4", "有相关动作，缺关键内容"
            else:
                mark, color, tip = "●", "#1F4E79", "有可核的做法与规模"
            cls = ' class="self"' if r.get("self") else ''
            a(f'<td{cls} title="{tip}" style="text-align:center;color:{color};font-size:17px">{mark}</td>')
        a('</tr>')
    a('  </tbody></table></div>')
    a('  <div class="note" style="margin-top:16px">'
      '<strong>●</strong> 有可核的做法与规模数字　　'
      '<strong style="color:#7FA3C4">◐</strong> 有相关动作但缺关键内容　　'
      '<strong style="color:#9A9AA3">—</strong> 该渠道未见公开记录，不代表没做。<br>'
      '本表只看「这件事做到什么程度」，各校具体做法与规模见下一节逐事对比；'
      '数据来源为学校官网、市教委公示与政府采购网。</div>')
    a('</section>')

    a('<section id="items">')
    a('  <div class="sec-head"><div class="no serif">03</div>'
      '<h2>逐事对比<span class="en">Item by Item</span></h2></div>')
    for it in items:
        a('  <div class="item-block">')
        a(f'    <h3><span class="idx">{e(it.get("id"))}</span>{e(it.get("name"))}</h3>')
        a('    <table class="item-tbl"><thead><tr>'
          '<th style="width:118px">学校</th><th>今年做了什么</th>'
          '<th style="width:118px">规模</th></tr></thead><tbody>')
        for r in it.get("rows", []):
            tr_cls = ' class="self"' if r.get("self") else ''
            a(f'      <tr{tr_cls}><td class="school">{e(r.get("school"))}</td>'
              f'<td>{e(r.get("did"))}</td><td class="scale">{e(r.get("scale"))}</td></tr>')
        a('    </tbody></table>')
        if it.get("judgement"):
            a(f'    <div class="judge">{e(it.get("judgement"))}</div>')
        a('  </div>')
    a('</section>')

    a('<section id="gaps">')
    a('  <div class="sec-head"><div class="no serif">04</div>'
      '<h2>本校三处短板<span class="en">Gaps</span></h2></div>')
    a('  <div class="grid3">')
    for g in gaps:
        a(f'    <div class="gap-card"><h4>{e(g.get("item"))}</h4>'
          f'<p>{e(g.get("note"))}</p></div>')
    a('  </div>')
    a('</section>')

    a('<section id="copy">')
    a('  <div class="sec-head"><div class="no serif">05</div>'
      '<h2>对标改进建议<span class="en">Improvement Actions</span></h2></div>')
    for c in copies:
        a('  <div class="copy-card">')
        a(f'    <h3>{e(c.get("id"))}　{e(c.get("title"))}</h3>')
        a(f'    <div class="src">来源：{e(c.get("source"))}　｜　证据 {e("、".join(c.get("evidence", [])))}</div>')
        a(f'    <div class="why">{e(c.get("why"))}</div>')
        a('    <ol>')
        for st in c.get("steps", []):
            a(f'      <li>{e(st)}</li>')
        a('    </ol>')
        a('    <div class="copy-meta">')
        a(f'      <div><span>要准备什么</span>{e(c.get("need"))}</div>')
        a(f'      <div><span>谁牵头</span>{e(c.get("owner"))}</div>')
        a(f'      <div><span>多久</span>{e(c.get("cycle"))}</div>')
        a(f'      <div><span>多少钱</span>{e(c.get("cost"))}</div>')
        a('    </div>')
        a(f'    <div class="cond"><strong>实施前提：</strong>{e(c.get("condition"))}</div>')
        a('  </div>')
    a('</section>')

    a('<section id="evidence">')
    a('  <div class="sec-head"><div class="no serif">06</div>'
      '<h2>证据索引<span class="en">Evidence</span></h2></div>')
    a('  <div class="tbl-wrap"><table><thead><tr>'
      '<th>编号</th><th>学校</th><th>标题与摘录</th><th>日期</th></tr></thead><tbody>')
    for x in ev:
        a(f'    <tr id="{e(x.get("id"))}"><td style="white-space:nowrap">{e(x.get("id"))}</td>'
          f'<td style="white-space:nowrap">{e(x.get("school"))}</td>'
          f'<td><a href="{e(x.get("url"))}" target="_blank" rel="noopener" style="color:#1F4E79">'
          f'{e(x.get("title"))}</a><br>'
          f'<span style="font-size:12.5px;color:#8B8B95">{e(x.get("excerpt"))}</span></td>'
          f'<td style="white-space:nowrap">{e(x.get("date"))}</td></tr>')
    a('  </tbody></table></div>')
    a('</section>')

    a(f'<footer>检索日 {e(meta.get("generated_at"))}。信息来自学校官网、北京市教育委员会公示、'
      '北京市政府采购网与第三方媒体报道。'
      '「未检索到公开信息」表示该渠道未见公开记录，不代表该项工作未开展。'
      '全部条目可在配套 Excel 中逐条核验。</footer>')
    a('</main></div>')

    return ('<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n<meta charset="UTF-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
            f'<title>{e(meta.get("school"))}{e(meta.get("dept"))} 对标研判</title>\n'
            f'<style>{css}</style>\n</head>\n<body>\n' + "\n".join(o) + "\n" + script
            + "\n</body>\n</html>\n")


def markdown(d: dict) -> str:
    m = d.get("meta", {})
    L = [f'# {m.get("school")}{m.get("dept")} 年度对标研判', "",
         f'周期 {m.get("period")}｜对标校 {"、".join(m.get("bench_schools", []))}｜'
         f'检索日 {m.get("generated_at")}', ""]
    schools = [m.get("school")] + m.get("bench_schools", [])
    L += ["## 一、五校实事件总览", ""]
    L.append("| 事项 | " + " | ".join(schools) + " |")
    L.append("|---" * (len(schools) + 1) + "|")
    for it in d.get("items", []):
        by = {r.get("school"): r for r in it.get("rows", [])}
        cells = [(by.get(s, {}).get("scale") or "未检索到") for s in schools]
        L.append(f'| {it.get("name")} | ' + " | ".join(cells) + " |")
    L += ["", "## 二、逐事对比", ""]
    for it in d.get("items", []):
        L += [f'### {it.get("id")} {it.get("name")}', ""]
        for r in it.get("rows", []):
            L.append(f'- **{r.get("school")}**：{r.get("did")}（{r.get("scale")}）')
        L += ["", f'> {it.get("judgement")}', ""]
    L += ["## 三、本校三处短板", ""]
    for g in d.get("gaps", []):
        L.append(f'- **{g.get("item")}**：{g.get("note")}')
    L += ["", "## 四、抄作业清单", ""]
    for c in d.get("copy_list", []):
        L += [f'### {c.get("id")} {c.get("title")}', f'抄自 {c.get("source")}', "",
              str(c.get("why") or ""), ""]
        for i, st in enumerate(c.get("steps", []), 1):
            L.append(f'{i}. {st}')
        L += ["", f'要准备：{c.get("need")}｜牵头：{c.get("owner")}｜'
                  f'周期：{c.get("cycle")}｜成本：{c.get("cost")}',
              f'照搬条件：{c.get("condition")}', ""]
    L += ["## 五、证据索引", "", "| 编号 | 学校 | 标题 | 日期 | URL |", "|---|---|---|---|---|"]
    for x in d.get("evidence", []):
        L.append(f'| {x.get("id")} | {x.get("school")} | {x.get("title")} | {x.get("date")} | {x.get("url")} |')
    return "\n".join(L) + "\n"


def sample() -> dict:
    return {
        "meta": {"school": "示例大学", "dept": "教务处", "province": "北京市", "level": "市属本科",
                 "period": "2026", "generated_at": "2026-11-11",
                 "bench_schools": ["示例A大学"], "item_count": 1, "gap_count": 1, "copy_count": 1},
        "items": [{"id": "I1", "name": "微专业建设",
                   "rows": [{"school": "示例大学", "self": True, "did": "示例做法", "scale": "3 个", "evidence": ["E1"]},
                            {"school": "示例A大学", "did": "示例做法", "scale": "21 个", "evidence": ["E1"]}],
                   "judgement": "示例判断。"}],
        "gaps": [{"item": "示例缺口", "note": "示例说明。", "evidence": ["E1"]}],
        "copy_list": [{"id": "C1", "title": "示例做法", "source": "示例A大学", "why": "示例理由",
                       "steps": ["第一步", "第二步"], "need": "示例材料", "owner": "教务处",
                       "cycle": "1 学期", "cost": "3 万元", "condition": "① ② ③", "evidence": ["E1"]}],
        "evidence": [{"id": "E1", "school": "示例A大学", "title": "示例标题",
                      "url": "https://example.edu.cn/a", "date": "2026-04-01", "excerpt": "示例摘录"}],
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="report_data.json -> 单文件 HTML 报告")
    ap.add_argument("--data")
    ap.add_argument("--out")
    args = ap.parse_args()

    css, script = shell()

    if not args.data:
        out = os.path.join(tempfile.gettempdir(), "_report_demo.html")
        io.open(out, "w", encoding="utf-8").write(render(sample(), css, script))
        print("未提供 --data，样例产物：", out)
        return

    d = json.load(io.open(args.data, encoding="utf-8"))
    out = args.out or os.path.splitext(os.path.abspath(args.data))[0] + ".html"
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    io.open(out, "w", encoding="utf-8").write(render(d, css, script))
    md = os.path.splitext(out)[0] + ".md"
    io.open(md, "w", encoding="utf-8").write(markdown(d))
    print("已生成：", out)
    print("存档稿：", md)


if __name__ == "__main__":
    main()
