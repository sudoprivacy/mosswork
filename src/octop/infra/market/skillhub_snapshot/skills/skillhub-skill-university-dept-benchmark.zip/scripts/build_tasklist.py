# -*- coding: utf-8 -*-
"""生成高校部门对标的检索任务清单。

用法：
    python build_tasklist.py --school 华中师范大学 --dept 学生工作部 \
        --province 湖北省 --city 武汉市 --year 2026 \
        --peers 武汉理工大学,湖北大学 --out tasklist.json

无参数运行时把示例清单写到系统临时目录，不在包内留文件。
"""
from __future__ import annotations

import argparse
import json
import os
import tempfile

# 规范名 -> (别名列表, 招标品目关键词)
DEPTS = {
    "学生工作部": (
        ["党委学生工作部", "学工部", "学生处", "学生工作处", "学工处"],
        "学生管理系统 心理健康 智慧学工 资助平台 辅导员培训",
    ),
    "教务处": (
        ["本科生院", "教学运行中心", "教学工作部", "教务部"],
        "教务系统 课程资源平台 智慧教室 教材建设 教学能力比赛",
    ),
    "科学技术处": (
        ["科研处", "科技处", "科研院", "科学研究管理处", "科技发展研究院"],
        "科研管理系统 成果转化 重点实验室 知识产权",
    ),
    "研究生院": (
        ["研究生工作部", "研究生处", "学科建设办公室"],
        "研究生管理系统 学位论文送审 学科评估 导师培训",
    ),
    "校团委": (
        ["团委", "共青团委员会", "创新创业中心"],
        "第二课堂 双创赛事 社会实践",
    ),
    "人事处": (
        ["党委教师工作部", "人力资源处", "人事人才处", "教师发展中心"],
        "人事系统 职称评审 教师发展平台 人才招聘",
    ),
    "招生就业处": (
        ["招就处", "招生与就业指导中心", "就业创业指导中心", "招生办公室"],
        "就业管理系统 招生宣传 生涯规划 招聘会",
    ),
    "党委宣传部": (
        ["宣传部", "新闻中心", "融媒体中心"],
        "融媒体平台 舆情监测 宣传片 新媒体运营",
    ),
    "国际交流合作处": (
        ["国际处", "国际合作与交流处", "国际教育学院", "港澳台事务办公室"],
        "留学生管理 中外合作办学 国际项目",
    ),
    "信息化建设与管理处": (
        ["信息中心", "网络与信息中心", "信息化办公室", "数据管理中心"],
        "数据中台 智慧校园 网络安全 AI应用平台",
    ),
    "图书馆": (
        ["图书馆（档案馆）", "图书信息中心", "文献资源建设部"],
        "数据库采购 文献资源平台 阅读推广 空间改造",
    ),
    "后勤保障处": (
        ["后勤管理处", "资产与后勤管理处", "后勤服务集团", "基建处"],
        "智慧后勤 能源管理 食堂改造 物业服务",
    ),
}

DIM_NAMES = {
    1: "战略议题", 2: "制度供给", 3: "标志性成果", 4: "品牌活动",
    5: "数字与平台", 6: "采购与合作", 7: "队伍与机构", 8: "传播与推广",
}


def resolve_dept(raw: str) -> tuple[str, list[str], str, bool]:
    """返回 (规范名, 别名列表, 品目词, 是否命中)。"""
    raw = raw.strip()
    if raw in DEPTS:
        alias, kw = DEPTS[raw]
        return raw, alias, kw, True
    for canon, (alias, kw) in DEPTS.items():
        if raw in alias:
            return canon, alias, kw, True
    return raw, [raw], "信息化 服务 平台 建设", False


def build_queries(school: str, aliases: list[str], kw: str, year: int) -> dict[int, list[str]]:
    """按维度生成检索 query，别名逐一轮换，避免单轮漏检。"""
    a = aliases
    q = {i: [] for i in range(1, 9)}

    for al in a:
        q[1] += [
            f'"{school}" "{al}" {year}',
            f'"{school}" "{al}" {year} 工作要点',
            f'"{school}" {al} 年度 部署 推进 会议 {year}',
        ]
        q[2] += [
            f'"{school}" "{al}" 管理办法 {year}',
            f'"{school}" "{al}" 实施细则 OR 工作规程 {year}',
        ]
        q[3] += [
            f'"{school}" "{al}" {year} 获评 OR 入选 OR 立项',
        ]
        q[7] += [
            f'"{school}" "{al}" 培训 OR 聘任 OR 工作室 {year}',
        ]

    theme = " ".join(a[:2])
    q[3].append(f'"{school}" {theme} {year} 省级 公示 名单')
    q[4] += [
        f'"{school}" {theme} 第.*届 OR 连续 {year}',
        f'"{school}" {theme} 活动 {year}',
    ]
    q[5] += [
        f'"{school}" 平台 OR 系统 上线 {theme} {year}',
        f'"{school}" AI 应用 {theme} {year}',
    ]
    q[6] += [
        f'"{school}" 招标 OR 采购 {kw} {year}',
        f'"{school}" "{a[0]}" 签约 OR 共建 {year}',
    ]
    q[7].append(f'"{school}" 机构调整 {theme} {year}')
    q[8] += [
        f'"{school}" {theme} 中国教育报 OR 人民网 OR 教育厅 {year}',
        f'"{school}" {theme} 典型发言 OR 经验交流 {year}',
    ]

    # 去重并保序
    for k in q:
        seen, out = set(), []
        for s in q[k]:
            if s not in seen:
                seen.add(s)
                out.append(s)
        q[k] = out
    return q


def main() -> None:
    ap = argparse.ArgumentParser(description="生成高校部门对标检索任务清单")
    ap.add_argument("--school")
    ap.add_argument("--dept")
    ap.add_argument("--province", default="")
    ap.add_argument("--city", default="")
    ap.add_argument("--year", type=int, default=2026)
    ap.add_argument("--peers", default="", help="逗号分隔的对标校全称")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    if not args.school or not args.dept:
        demo = {
            "meta": {
                "school": "示例大学", "dept": "学生工作部", "province": "示例省",
                "city": "示例市", "year": 2026, "dept_normalized": True,
                "dept_aliases": DEPTS["学生工作部"][0],
                "note": "这是无参数运行的示例清单",
            },
            "schools": [],
        }
        path = os.path.join(tempfile.gettempdir(), "_tasklist_demo.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(demo, f, ensure_ascii=False, indent=2)
        print(f"未提供参数，示例已写入：{path}")
        return

    canon, aliases, kw, hit = resolve_dept(args.dept)
    peers = [p.strip() for p in args.peers.split(",") if p.strip()]

    schools = [{"school": args.school, "role": "self", "target_per_dim": 5}]
    schools += [{"school": p, "role": "peer", "target_per_dim": 2} for p in peers]

    for s in schools:
        qs = build_queries(s["school"], aliases, kw, args.year)
        s["tasks"] = [
            {"dim": d, "name": DIM_NAMES[d], "target": s["target_per_dim"], "queries": qs[d]}
            for d in range(1, 9)
        ]

    data = {
        "meta": {
            "school": args.school,
            "dept": canon,
            "dept_input": args.dept,
            "dept_normalized": hit,
            "dept_aliases": aliases,
            "procurement_keywords": kw,
            "province": args.province,
            "city": args.city,
            "year": args.year,
            "peer_count": len(peers),
            "query_total": sum(len(t["queries"]) for s in schools for t in s["tasks"]),
        },
        "schools": schools,
    }

    text = json.dumps(data, ensure_ascii=False, indent=2)
    if args.out:
        out = args.out if os.path.isabs(args.out) else os.path.abspath(args.out)
        os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"已写入 {out}｜学校 {len(schools)} 所｜检索式 {data['meta']['query_total']} 条"
              f"｜部门归一 {'是' if hit else '否（按原词直检）'}")
    else:
        print(text)


if __name__ == "__main__":
    main()
