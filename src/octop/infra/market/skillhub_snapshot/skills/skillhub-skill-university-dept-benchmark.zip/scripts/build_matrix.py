# -*- coding: utf-8 -*-
"""把 report_data.json 渲染成三张工作表的对比底表。

表1 实事对比｜表2 对标改进建议｜表3 证据索引

用法：
    python build_matrix.py --data report_data.json --out 对比表.xlsx

无参数运行时用内置样例，产物写到系统临时目录。
"""
from __future__ import annotations

import argparse
import json
import os
import tempfile

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

CN = "微软雅黑"
HEAD_FILL = PatternFill("solid", fgColor="1F4E79")
SELF_FILL = PatternFill("solid", fgColor="EAF1F8")
HEAD_FONT = Font(name=CN, size=10.5, bold=True, color="FFFFFF")
BODY_FONT = Font(name=CN, size=10)
LINK_FONT = Font(name=CN, size=10, color="1F4E79", underline="single")
THIN = Side(style="thin", color="D9D9D9")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)

SHEETS = {
    "实事对比": ["事项", "学校", "今年做了什么", "规模", "证据编号", "证据URL", "发布日期"],
    "对标改进建议": ["编号", "事项", "来源校", "步骤", "要准备什么", "牵头", "周期", "成本", "照搬条件"],
    "证据索引": ["编号", "学校", "标题", "URL", "日期", "摘录"],
}


def _w(text) -> int:
    if text is None:
        return 8
    w = sum(2 if ord(c) > 127 else 1 for c in str(text))
    return max(8, min(64, w + 2))


def _sheet(wb, name, rows, link_col=None, self_key=""):
    ws = wb.create_sheet(name)
    heads = SHEETS[name]
    ws.append(heads)
    for c in range(1, len(heads) + 1):
        cell = ws.cell(row=1, column=c)
        cell.font, cell.fill, cell.alignment, cell.border = HEAD_FONT, HEAD_FILL, CENTER, BORDER
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 26

    for r, row in enumerate(rows, start=2):
        ws.append(row)
        for c in range(1, len(heads) + 1):
            cell = ws.cell(row=r, column=c)
            cell.font, cell.alignment, cell.border = BODY_FONT, WRAP, BORDER
            if self_key and str(row[1]) == self_key and name == "实事对比":
                cell.fill = SELF_FILL
            if link_col and c == link_col and str(cell.value or "").startswith("http"):
                cell.hyperlink = str(cell.value)
                cell.font = LINK_FONT

    for c in range(1, len(heads) + 1):
        width = max([_w(heads[c - 1])] + [_w(row[c - 1]) for row in rows] or [8])
        ws.column_dimensions[get_column_letter(c)].width = width


def build(d: dict, out: str) -> str:
    meta = d.get("meta", {})
    self_school = meta.get("school", "")
    ev = {x.get("id"): x for x in d.get("evidence", [])}

    wb = Workbook()
    wb.remove(wb.active)

    rows = []
    for it in d.get("items", []):
        for r in it.get("rows", []):
            ids = r.get("evidence", [])
            first = ev.get(ids[0], {}) if ids else {}
            rows.append([
                it.get("name"), r.get("school"), r.get("did"),
                r.get("scale") or "未检索到", "、".join(ids) or "—",
                first.get("url", ""), first.get("date", ""),
            ])
    _sheet(wb, "实事对比", rows, link_col=6, self_key=self_school)

    rows = []
    for c in d.get("copy_list", []):
        rows.append([
            c.get("id"), c.get("title"), c.get("source"),
            " ／ ".join(f"{i}. {s}" for i, s in enumerate(c.get("steps", []), 1)),
            c.get("need"), c.get("owner"), c.get("cycle"), c.get("cost"),
            c.get("condition"),
        ])
    _sheet(wb, "对标改进建议", rows)

    rows = [[x.get("id"), x.get("school"), x.get("title"), x.get("url"),
             x.get("date"), x.get("excerpt")] for x in d.get("evidence", [])]
    _sheet(wb, "证据索引", rows, link_col=4, self_key=self_school)

    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    wb.save(out)
    return out


def sample() -> dict:
    return {
        "meta": {"school": "示例大学", "bench_schools": ["示例A大学"]},
        "items": [{"id": "I1", "name": "微专业建设", "judgement": "示例",
                   "rows": [{"school": "示例大学", "self": True, "did": "示例做法",
                             "scale": "3 个", "evidence": ["E1"]},
                            {"school": "示例A大学", "did": "示例做法", "scale": "21 个", "evidence": ["E1"]}]}],
        "gaps": [{"item": "示例", "note": "示例"}],
        "copy_list": [{"id": "C1", "title": "示例做法", "source": "示例A大学",
                       "steps": ["第一步", "第二步"], "need": "材料", "owner": "教务处",
                       "cycle": "1 学期", "cost": "3 万元", "condition": "①②③"}],
        "evidence": [{"id": "E1", "school": "示例A大学", "title": "示例标题",
                      "url": "https://example.edu.cn/a", "date": "2026-04-01", "excerpt": "示例摘录"}],
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="report_data.json -> 对比表 xlsx")
    ap.add_argument("--data")
    ap.add_argument("--out")
    args = ap.parse_args()

    if not args.data:
        out = os.path.join(tempfile.gettempdir(), "_matrix_demo.xlsx")
        print("未提供 --data，样例产物：", build(sample(), out))
        return

    d = json.load(open(args.data, encoding="utf-8"))
    out = args.out or os.path.join(os.path.dirname(os.path.abspath(args.data)), "对比表.xlsx")
    print("已生成：", build(d, out))


if __name__ == "__main__":
    main()
