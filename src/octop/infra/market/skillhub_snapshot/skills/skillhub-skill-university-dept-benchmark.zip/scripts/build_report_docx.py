# -*- coding: utf-8 -*-
"""把 report_data.json 渲染成 Word 正式稿（全篇微软雅黑）。

章节：一 检索范围｜二 五校实事件总览｜三 逐事对比｜四 本校短板｜
      五 对标改进建议｜六 证据与来源

用法：
    python build_report_docx.py --data report_data.json --out 报告.docx

无参数运行时用内置样例，产物写到系统临时目录。
"""
from __future__ import annotations

import argparse
import json
import os
import tempfile

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

CN = "微软雅黑"
ACCENT = RGBColor(0x1F, 0x4E, 0x79)
GREY = RGBColor(0x59, 0x59, 0x59)


def _font(run, size=10.5, bold=False, color=None):
    run.font.name = CN
    run.font.size = Pt(size)
    run.bold = bold
    if color is not None:
        run.font.color.rgb = color
    rpr = run._element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = rpr.makeelement(qn("w:rFonts"), {})
        rpr.append(rf)
    for a in ("w:eastAsia", "w:ascii", "w:hAnsi"):
        rf.set(qn(a), CN)


def para(doc, text="", size=10.5, bold=False, color=None, align=None,
         before=0, after=6, indent=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.5
    if indent:
        p.paragraph_format.first_line_indent = Pt(21)
    if align is not None:
        p.alignment = align
    if text:
        _font(p.add_run(str(text)), size, bold, color)
    return p


def heading(doc, text, level=1):
    return para(doc, text, size=15 if level == 1 else 11.5, bold=True, color=ACCENT,
                before=14 if level == 1 else 10, after=6)


def table(doc, heads, rows, widths=None):
    t = doc.add_table(rows=1, cols=len(heads))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(heads):
        c = t.rows[0].cells[i]
        c.text = ""
        _font(c.paragraphs[0].add_run(str(h)), 9.5, True)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            _font(cells[i].paragraphs[0].add_run("" if v is None else str(v)), 9)
    if widths:
        for r in t.rows:
            for i, w in enumerate(widths):
                if i < len(r.cells):
                    r.cells[i].width = Pt(w)
    para(doc, "", size=6, after=0)
    return t


def build(d: dict, out: str) -> str:
    meta = d.get("meta", {})
    items = d.get("items", [])
    gaps = d.get("gaps", [])
    copies = d.get("copy_list", [])
    ev = d.get("evidence", [])
    self_school = meta.get("school", "")
    schools = [self_school] + meta.get("bench_schools", [])

    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = CN
    normal.font.size = Pt(10.5)
    rpr = normal.element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = rpr.makeelement(qn("w:rFonts"), {})
        rpr.append(rf)
    for a in ("w:eastAsia", "w:ascii", "w:hAnsi"):
        rf.set(qn(a), CN)

    para(doc, f'{self_school}　{meta.get("dept", "")}　今年办了哪几件事',
         size=18, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, after=4)
    para(doc, f'{meta.get("period", "")} 年度　|　{meta.get("province", "")}　|　'
              f'对标 {len(meta.get("bench_schools", []))} 所　|　'
              f'实事 {len(items)} 件　|　证据 {len(ev)} 条',
         size=9, color=GREY, align=WD_ALIGN_PARAGRAPH.CENTER, after=14)

    heading(doc, "一、检索范围与方法")
    para(doc, f'检索对象为{meta.get("province", "")}{self_school}{meta.get("dept", "")}，'
              f'时间范围 {meta.get("period", "")} 年 1 月 1 日至检索日。'
              f'对照样本为 {("、".join(meta.get("bench_schools", [])))}，'
              f'均为{meta.get("level", "")}院校，经确认后纳入。', indent=True)
    para(doc, "报告按「今年办了哪几件事」组织，不按抽象维度分类。每件事给一张五校对比表，"
              "写清各校做法与规模，再给一句判断。规模只记可核的数字与规则，"
              "在建项目标注「在建」，查不到标「未检索到公开信息」。", indent=True)
    para(doc, "信息来源为学校官网、北京市教育委员会公示、北京市政府采购网与第三方媒体报道，"
              "仅采公开内容。", indent=True)

    heading(doc, "二、五校实事件总览")
    rows = []
    for it in items:
        by = {r.get("school"): r for r in it.get("rows", [])}
        cells = [it.get("name")]
        for s in schools:
            r = by.get(s, {})
            v = r.get("scale")
            cells.append(v if v and v not in ("—", "") else "未检索到")
        rows.append(cells)
    table(doc, ["事项"] + schools, rows, widths=[62] + [92] * len(schools))
    para(doc, "注：格内只放可核的规模数字。「未检索到」表示该渠道未见公开记录，不代表该项工作未开展。",
         size=9, color=GREY)

    heading(doc, "三、逐事对比")
    for it in items:
        heading(doc, f'{it.get("id")}　{it.get("name")}', level=2)
        rows = [[r.get("school"), r.get("did"), r.get("scale"),
                 "、".join(r.get("evidence", [])) or "—"] for r in it.get("rows", [])]
        table(doc, ["学校", "今年做了什么", "规模", "证据"], rows,
              widths=[66, 240, 62, 46])
        if it.get("judgement"):
            para(doc, it["judgement"], size=10, color=GREY)

    heading(doc, "四、本校短板")
    for g in gaps:
        para(doc, f'· {g.get("item")}', size=11, bold=True, before=6)
        para(doc, g.get("note", ""), size=10.5, indent=True)

    heading(doc, "五、对标改进建议")
    for c in copies:
        heading(doc, f'{c.get("id")}　{c.get("title")}', level=2)
        para(doc, f'抄自 {c.get("source", "")}｜证据 {"、".join(c.get("evidence", []))}',
             size=9, color=GREY)
        para(doc, c.get("why", ""), size=10, indent=True)
        for i, st in enumerate(c.get("steps", []), 1):
            para(doc, f'{i}. {st}', size=10.5)
        table(doc, ["要准备什么", "谁牵头", "多久", "多少钱"],
              [[c.get("need"), c.get("owner"), c.get("cycle"), c.get("cost")]],
              widths=[150, 80, 62, 70])
        para(doc, f'能不能照搬，看三条：{c.get("condition", "")}', size=10, color=GREY)

    heading(doc, "六、证据与来源")
    rows = [[x.get("id"), x.get("school"), x.get("title"), x.get("date"), x.get("url")]
            for x in ev]
    table(doc, ["编号", "学校", "标题", "日期", "URL"], rows,
          widths=[34, 82, 176, 58, 118])

    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    doc.save(out)
    return out


def sample() -> dict:
    return {
        "meta": {"school": "示例大学", "dept": "教务处", "province": "北京市", "level": "市属本科",
                 "period": "2026", "generated_at": "2026-11-11", "bench_schools": ["示例A大学"]},
        "items": [{"id": "I1", "name": "微专业建设", "judgement": "示例判断。",
                   "rows": [{"school": "示例大学", "self": True, "did": "示例做法",
                             "scale": "3 个", "evidence": ["E1"]},
                            {"school": "示例A大学", "did": "示例做法", "scale": "21 个", "evidence": ["E1"]}]}],
        "gaps": [{"item": "示例缺口", "note": "示例说明。"}],
        "copy_list": [{"id": "C1", "title": "示例做法", "source": "示例A大学", "why": "示例理由",
                       "steps": ["第一步", "第二步"], "need": "材料", "owner": "教务处",
                       "cycle": "1 学期", "cost": "3 万元", "condition": "①②③", "evidence": ["E1"]}],
        "evidence": [{"id": "E1", "school": "示例A大学", "title": "示例标题",
                      "url": "https://example.edu.cn/a", "date": "2026-04-01", "excerpt": "示例摘录"}],
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="report_data.json -> Word 报告")
    ap.add_argument("--data")
    ap.add_argument("--out")
    args = ap.parse_args()

    if not args.data:
        out = os.path.join(tempfile.gettempdir(), "_report_demo.docx")
        print("未提供 --data，样例产物：", build(sample(), out))
        return

    d = json.load(open(args.data, encoding="utf-8"))
    out = args.out or os.path.join(os.path.dirname(os.path.abspath(args.data)), "研判报告.docx")
    print("已生成：", build(d, out))


if __name__ == "__main__":
    main()
