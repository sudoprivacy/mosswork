---
name: skillhub-skill-08-video-merge
description: "# 视频合成技能"
---

# 视频合成技能
## 功能介绍
将视频、音频、字幕一键合成为 9:16 竖屏成品短剧。
## 输入参数
- video_url：视频地址（必填）
- audio_url：音频地址（必填）
- subtitle_url：字幕地址（可选）
## 输出结果
- final_video_url：最终成片地址
## 使用场景
- 短剧最终合成发布
- 批量产出可发布视频
- 一键成片自动化
## 技术说明
纯本地运行，无需API、无需模型配置。
