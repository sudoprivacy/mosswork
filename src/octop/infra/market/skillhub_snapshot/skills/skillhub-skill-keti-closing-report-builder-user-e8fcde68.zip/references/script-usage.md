# 脚本用法、依赖与降级

## 依赖

| 依赖 | 用途 | 缺失后果 |
| --- | --- | --- |
| `python-docx` | 生成/检查 Word | 必需 |
| `openpyxl` | 读取 .xlsx 量表 | 量表材料无法提取 |
| `pywin32` + 本机 Word/WPS | 读取老 `.doc`、更新目录域、导出 PDF | 自动降级，见下 |
| `pymupdf` | 提取 PDF 材料、渲染预览页图 | PDF 材料跳过；版面目视检查可用 Word 另存 |

安装（按需）：`python3 -m pip install python-docx openpyxl pywin32 pymupdf`

## 阶段 1 · 材料提取

```bash
python3 scripts/extract_materials.py --src "<材料目录>" --out "<输出目录>"
python3 scripts/extract_materials.py --src "<材料目录>" --no-word   # 强制纯 Python
```

- 只读、不递归、不改源文件；输出 UTF-8 `.txt` 与 `manifest.json`。
- Word 用 COM 另存为 Unicode 文本，自动识别 UTF-16 BOM / GBK / UTF-8；`.doc` 依赖本机 Word。
- `.xlsx` 逐 sheet 导出，并在 manifest 里标记 `blank_sheets`（只有表头没有数据行的空白模板）。**看到该标记，报告中禁止出现任何统计结果。**
- 无 Word 时：`.docx` 回退 `python-docx`（取不到文本框/批注）；老 `.doc` 输出 SKIPPED 提示，需人工另存为 `.docx` 后重跑。

## 阶段 6 · 渲染与终稿

```bash
# 1) 生成 Word（可单独用）
python3 scripts/build_report.py --parts part1.md part2.md \
    --config report-config.json --out "研究报告（定稿）.docx"

# 2) 两阶段终稿（推荐，各起一个独立进程）
python3 scripts/finalize_report.py --stage A --parts part1.md part2.md \
    --config report-config.json --docx "研究报告（定稿）.docx"
python3 scripts/finalize_report.py --stage B --config report-config.json \
    --docx "研究报告（定稿）.docx" --pdf preview.pdf
```

分两个进程是为了避免同一进程反复 `DispatchEx`/`Quit` Word 触发 COM 会话冲突。

## 阶段 7 · 自检

```bash
python3 scripts/check_report.py --docx "研究报告（定稿）.docx" --json check.json
```

退出码 0 表示结构、残留标记、引文闭环三项通过；非 0 时读输出逐项修。量化表述风险与占位符只作提示，需人工判断。

## 源稿标记完整说明

| 标记 | 作用 |
| --- | --- |
| `@@COVER@@` … `@@ENDCOVER@@` | 封面逐行文字；第 1 行左对齐，第 2/3/4 行分级居中放大，其余居中 |
| `@@TOC@@` | 目录插入位置；其后为正文。缺省时自动去掉封面块并在正文前插目录 |
| `## 一、研究背景及意义` | 一级标题（黑体四号、居中、段前段后、与下段同页） |
| `### （一）研究背景` | 二级标题（楷体四号加粗） |
| `#### 1. 政策背景` | 三级标题（宋体小四加粗） |
| `@CAPTION@表 8-1 ……` | 表题，必须紧贴在表格前一行；居中、加粗、与表同页 |
| `@NOTE@注：……` | 表下注释，宋体五号、首行缩进两字 |
| `\| A \| B \|` + `\| --- \| --- \|` | Markdown 表格；分隔行自动忽略；首行加底纹并设为跨页重复表头 |
| `[1] 作者.题名[J]……` | 参考文献条目；仅在标题含"参考文献"的章节内启用五号悬挂缩进 |

注意：分隔行 `| --- |` 会被识别并跳过；不要在正文里用 `##` 开头写普通段落。

## 版面目视抽查清单

导出 PDF 后至少看 5 页：封面、目录、正文起始页、最宽表格所在页、末页。检查标题层级字体、行距、首行缩进、页眉页码、宽表是否溢出页边距、表格行是否被拆开、附录结尾注释是否完整。

## 平台差异

- Windows + Word：全功能（老 `.doc`、真实页码目录、PDF）。
- macOS / Linux 或无 Word：用 LibreOffice `soffice --headless --convert-to pdf` 导出预览；目录域保留 `w:updateFields=true`，需在 Word/WPS 中手动更新一次。
- 所有脚本均不发起网络请求、不执行外部可执行文件、不读取用户显式传入目录之外的路径。
