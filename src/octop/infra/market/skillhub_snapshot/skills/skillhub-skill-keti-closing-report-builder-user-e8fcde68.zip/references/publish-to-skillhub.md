# 发布到 SkillHub（skillhub.cn）

平台：SkillHub —— 面向中国用户的 AI Skills 社区，支持 WorkBuddy / Claude Code / Codex / Cursor / OpenClaw 等 Agent 安装。发布入口 `https://skillhub.cn/dashboard/publish`（首页「发布个人 Skill」同入口）。

## 一、三道前置门槛（缺一不可，且只能由账号本人完成）

1. **注册 + 实名认证**：手机号验证码登录 → 个人中心 → 实名认证（腾讯云人脸核身）。未实名无法创建 API Token，也无法发布（CLI 报 403）。
2. **三线安全审核**：内容合规过滤 + 科恩实验室漏洞扫描 + 云鼎实验室 AI 模型安全评估，全部通过后自动上架；发布后状态为 `pending_review`。
3. **格式规范**：`SKILL.md` frontmatter 必填 `slug` / `version` / `displayName`；`slug` 为 kebab-case 且长度 2–128，`version` 为合法 SemVer（如 `1.0.0`）。`summary` / `description` / `tags` / `license` / `homepage` 建议填写但不阻断。

> 身份与授权边界：实名认证、人脸核身、创建并保管 API Token、选择可见性与许可证、点击最终提交，均属账号持有人专属操作。自动化流程不代做、不索要、不打印任何完整密钥或 Token。

## 二、双平台兼容 frontmatter

本技能同时保留两套字段，一份 SKILL.md 即可本机识别与平台上架：

- WorkBuddy / Claude 通用：`name`（与目录名一致）、`description`（写触发场景，不写形容词）、`agent_created: true`
- SkillHub 发布：`slug`、`version`、`displayName`、`summary`、`license`、`tags`、`category`

**发布前必改**：`slug` 提交后不可修改且全网唯一。当前值是占位的 `keti-closing-report-builder-userhandle`，应把 `userhandle` 换成自己的账号 handle，避免 409 冲突。`license` 默认 `UNLICENSED`（保留全部权利）；改为 `MIT` 意味着公开授出使用、修改、商用权，属不可逆决定。

## 三、三条发布路径

### 路径 A · 网页可视化（一次性发布，最省事）

1. 登录 `https://skillhub.cn` → 完成实名认证。
2. 打开 `https://skillhub.cn/dashboard/publish`。
3. 按页面填写名称、描述、分类、标签；上传技能 zip（不要解压）或按相对路径逐个上传文件。
4. 提交审核 → 个人中心「我的 Skill」查看状态。

zip 要求：解压后技能文件夹内直接可见 `SKILL.md`（不要多套一层）；整包 < 10 MB；不含密钥、`.env`、无关大文件。

### 路径 B · CLI（适合后续迭代与版本管理）

前置：实名认证 + 个人中心「API keys」创建 Token（`skh_` 开头，只显示一次，立即保存）。官方 CLI 适用 Mac/Linux，Windows 走 WSL。

```bash
# 安装 CLI（建议先下载并阅读脚本再执行，不要直接把远程内容管道给解释器）
curl -fsSL https://skillhub.cn/install/install.sh -o install.sh
bash install.sh --cli-only
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc && source ~/.zshrc
skillhub --version

# 用环境变量提供 Token（不要写进脚本、不要打印）
export SKILLHUB_KEY="<你的 Token>"
skillhub login --key "$SKILLHUB_KEY" --host "https://api.skillhub.cn"
skillhub auth whoami

# 先本地预检，再正式发布
skillhub publish "<skill 目录>" --host "https://api.skillhub.cn" --dry-run
skillhub publish "<skill 目录>" --host "https://api.skillhub.cn" --changelog "首次发布"
```

看到 `status=pending_review` 即进入审核。后续更新保持 `slug` 不变、递增 `version`、写清 `--changelog`。

本机安装 SkillHub 商店（消费者侧）用：
```bash
curl -fsSL https://skillhub-1388575217.cos.ap-guangzhou.myqcloud.com/install/install.sh -o install.sh
bash install.sh --cli-only
skillhub install <slug> --dir ~/.workbuddy/skills/
```

### 路径 C · Agent 对话发布

在已接入 SkillHub 的 Agent 客户端里发送：
`根据 https://skillhub.cn/ai/release.md 把 <skill 目录> 发布到 SkillHub。`
Agent 会读取官方规范、校验 frontmatter、确认登录态并提交，完成后回传名称/slug、版本、状态与 URL。官方规范要求：不打印完整 API Key，不发布缺少必填项或本地校验失败的技能。

## 四、常见失败与处理

| 现象 | 原因 / 处理 |
| --- | --- |
| 403 请先完成实名认证 | 账号未实名，只能本人到个人中心完成人脸核身 |
| 409 slug 已被占用 | 换一个带自己 handle 的 slug；slug 提交后不可改 |
| `SKILL.md 缺少 ...` | 补齐 `slug` / `version` / `displayName`；`version` 必须是 SemVer |
| zip 被拒 | 检查 >10MB、SKILL.md 是否多套一层目录、是否混入密钥或临时文件 |
| 安全扫描标风险 | 脚本不得访问隐私路径、不得外传数据、不得下载远程脚本执行；在发布表单功能说明里写清只读本地文件、不联网、不采集用户信息 |
| 描述被驳回 | 不写"效率提升 10 倍""准确率 99%"等无来源的夸大表述 |
| 分类不一致 | 发布表单分类与 frontmatter `category` 保持一致 |

## 五、本技能的安全自检要点（提交前逐项确认）

- 4 个脚本只读取用户显式传入的目录与文件，不递归、不访问系统或隐私路径。
- 不发起任何网络请求、不下载远程脚本、不使用 `eval` / `exec` / `subprocess` 调外部命令（Word COM 为本地 Office 自动化）。
- 不含任何密钥、Token、真实人名、真实课题数据；示例均为占位符。
- 明确声明「不代替账号持有人完成实名认证与凭据创建」「不索要或打印完整密钥」。
- 包内无 `.env`、无临时文件、无大体积素材。

## 六、可见性建议

`public`（任何人可搜到并安装）会公开整套方法论；若只是在同事/合作方之间复用，可优先选 `unlisted`（凭链接安装）或直接分发 zip 本机导入，不必公开发布。
