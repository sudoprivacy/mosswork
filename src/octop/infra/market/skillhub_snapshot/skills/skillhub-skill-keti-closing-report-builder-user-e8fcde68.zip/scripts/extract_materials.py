#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""只读批量提取课题结题材料文本。

用途：把一间目录里的开题申报书、论证活页、开题报告、中期报告、结题申请表、
课堂观察量表、格式规范等 .doc/.docx/.xlsx/.pdf/.txt/.md 统一提取为 UTF-8 文本，
供后续事实台账与报告撰写使用。

安全边界：
- 仅读取通过 --src 显式传入的目录，不递归、不访问任何系统或个人隐私路径；
- 全程只读打开原始文件，不修改、不移动、不删除任何源文件；
- 不发起任何网络请求，不执行外部命令、不使用 eval/exec；
- 输出统一写入 --out 目录（默认 <src>/.workbuddy/extract）。

用法：
    python3 extract_materials.py --src /path/to/materials --out /path/to/extract
    python3 extract_materials.py --src . --no-word     # 无 Word 环境下强制纯 Python 回退
"""
import argparse
import datetime
import glob
import json
import os
import sys
import traceback

WORD_EXT = {".doc", ".docx", ".wps"}
EXCEL_EXT = {".xls", ".xlsx", ".xlsm"}
CSV_EXT = {".csv", ".tsv"}
TEXT_EXT = {".txt", ".md", ".markdown"}
PDF_EXT = {".pdf"}
SUPPORTED = WORD_EXT | EXCEL_EXT | CSV_EXT | TEXT_EXT | PDF_EXT


def decode_bytes(raw):
    """Word 的 wdFormatUnicodeText 在不同环境下可能输出 UTF-16LE 或本地 ANSI(GBK)。"""
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16", errors="replace")
    for enc in ("utf-8-sig", "gbk", "utf-8"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def clean_text(text):
    return (text.replace("\x07", "\t")
                .replace("\x0b", "\n")
                .replace("\x0c", "\n")
                .replace("\r\n", "\n")
                .replace("\r", "\n"))


def extract_docx_python(path):
    """无 Word COM 时的 .docx 回退（仅能取段落与表格文字，不能取文本框/批注）。"""
    from docx import Document
    d = Document(path)
    lines = [p.text for p in d.paragraphs]
    for t in d.tables:
        lines.append("----- TABLE -----")
        for row in t.rows:
            lines.append(" | ".join(c.text.replace("\n", " / ") for c in row.cells))
    return "\n".join(lines)


def extract_word_com(paths, out_dir, manifest):
    """用本机 Word 只读打开并另存为 Unicode 文本；兼容老 .doc。"""
    try:
        import win32com.client as win32
    except ImportError:
        return False
    try:
        app = win32.DispatchEx("Word.Application")
    except Exception:
        return False
    app.Visible = False
    app.DisplayAlerts = 0
    try:
        for path in paths:
            name = os.path.splitext(os.path.basename(path))[0]
            tmp = os.path.join(out_dir, "_tmp_%d.txt" % abs(hash(name + path)))
            final = os.path.join(out_dir, name + ".txt")
            entry = {"file": os.path.basename(path), "type": "word", "engine": "word-com"}
            try:
                d = app.Documents.Open(path, ReadOnly=True, AddToRecentFiles=False,
                                       ConfirmConversions=False, Visible=False)
                # 7 = wdFormatUnicodeText
                d.SaveAs2(tmp, FileFormat=7)
                d.Close(False)
                with open(tmp, "rb") as fh:
                    raw = fh.read()
                text = clean_text(decode_bytes(raw))
                with open(final, "w", encoding="utf-8") as fh:
                    fh.write(text)
                os.remove(tmp)
                entry.update(status="ok", chars=len(text), output=os.path.basename(final))
                print("OK   WORD  %s  %d chars" % (name, len(text)))
            except Exception as exc:
                entry.update(status="failed", error=repr(exc))
                print("FAIL WORD  %s  %r" % (name, exc))
                traceback.print_exc()
            manifest["items"].append(entry)
    finally:
        app.Quit()
    return True


SUMMARY_HINTS = ("得分", "总分", "均分", "平均", "得分率", "合计", "总计", "汇总", "综合等级")


def extract_excel(path, out_dir):
    """逐 sheet 导出为文本，并标记两类需要谨慎处理的表格。

    blank_sheets：非空行 <=2 的纯空白模板；
    summary_like_sheets：出现计分/汇总表头，需人工确认是否真的填入了观察数据。
    返回 (text, blank_sheets, summary_like_sheets, sheet_stats)。
    """
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    lines, blank_sheets, summary_like, stats = [], [], [], []
    for ws in wb.worksheets:
        lines.append("===== SHEET: %s  (%d x %d) =====" % (ws.title, ws.max_row, ws.max_column))
        nonempty, head_text = 0, []
        for row in ws.iter_rows():
            vals = ["" if c.value is None else str(c.value).replace("\n", " / ") for c in row]
            while vals and vals[-1] == "":
                vals.pop()
            if any(v.strip() for v in vals):
                line = " | ".join(vals)
                lines.append(line)
                nonempty += 1
                if len(head_text) < 8:
                    head_text.append(line)
        stats.append({"sheet": ws.title, "rows": ws.max_row,
                      "cols": ws.max_column, "nonempty_rows": nonempty})
        if nonempty <= 2:
            blank_sheets.append(ws.title)
        if any(h in " ".join(head_text) for h in SUMMARY_HINTS):
            summary_like.append(ws.title)
    return "\n".join(lines), blank_sheets, summary_like, stats


def extract_plain(path):
    with open(path, "rb") as fh:
        return clean_text(decode_bytes(fh.read()))


def extract_pdf(path):
    try:
        import pymupdf
        doc = pymupdf.open(path)
        return "\n".join(page.get_text() for page in doc)
    except ImportError:
        return "[SKIPPED] 需要 pymupdf 才能提取 PDF：pip install pymupdf"


def main():
    ap = argparse.ArgumentParser(description="只读批量提取课题结题材料文本")
    ap.add_argument("--src", required=True, help="材料所在目录（只读，不递归）")
    ap.add_argument("--out", default=None, help="输出目录，默认 <src>/.workbuddy/extract")
    ap.add_argument("--no-word", action="store_true", help="不使用 Word COM，强制纯 Python 回退")
    args = ap.parse_args()

    src = os.path.abspath(args.src)
    if not os.path.isdir(src):
        print("ERROR: 材料目录不存在：%s" % src)
        return 2
    out_dir = os.path.abspath(args.out) if args.out else os.path.join(src, ".workbuddy", "extract")
    os.makedirs(out_dir, exist_ok=True)

    files = sorted(f for f in glob.glob(os.path.join(src, "*"))
                   if os.path.isfile(f) and os.path.splitext(f)[1].lower() in SUPPORTED)
    manifest = {
        "source_dir": src,
        "out_dir": out_dir,
        "generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "readonly": True,
        "items": [],
    }

    word_files = [f for f in files if os.path.splitext(f)[1].lower() in WORD_EXT]
    com_used = False
    if word_files and not args.no_word:
        com_used = extract_word_com(word_files, out_dir, manifest)

    for path in files:
        ext = os.path.splitext(path)[1].lower()
        name = os.path.splitext(os.path.basename(path))[0]
        if ext in WORD_EXT and com_used:
            continue  # 已由 Word COM 处理
        final = os.path.join(out_dir, name + ".txt")
        entry = {"file": os.path.basename(path), "type": ext.lstrip(".")}
        note = ""
        override_status = None
        try:
            if ext in WORD_EXT:
                if ext == ".docx":
                    text = extract_docx_python(path)
                    entry["engine"] = "python-docx"
                else:
                    text = "[SKIPPED] 老 .doc 需要本机 Word/WPS 或 LibreOffice；"
                    text += "本环境未启用 Word COM，请人工另存为 .docx 后重跑。"
                    entry["engine"] = "unavailable"
                    override_status = "skipped"
                    note = "老 .doc 未提取到内容：请人工另存为 .docx 后重跑，或启用本机 Word COM"
            elif ext in EXCEL_EXT:
                text, blanks, summary_like, stats = extract_excel(path, out_dir)
                entry["engine"] = "openpyxl"
                entry["sheet_stats"] = stats
                if blanks:
                    entry["blank_sheets"] = blanks
                if summary_like:
                    entry["summary_like_sheets"] = summary_like
                notes = []
                if blanks:
                    notes.append("空白模板表：%s（不得据此编造数据）" % "、".join(blanks))
                if summary_like:
                    notes.append("含计分/汇总表头：%s，须人工确认是否已填入真实观察数据，"
                                 "无数据只能描述工具设计" % "、".join(summary_like))
                note = "；".join(notes)
            elif ext in CSV_EXT:
                text, blanks = extract_plain(path), []
                entry["engine"] = "plain"
            elif ext in PDF_EXT:
                text = extract_pdf(path)
                entry["engine"] = "pymupdf"
            else:
                text = extract_plain(path)
                entry["engine"] = "plain"
            with open(final, "w", encoding="utf-8") as fh:
                fh.write(text)
            entry.update(status=override_status or "ok", chars=len(text),
                         output=os.path.basename(final))
            if note:
                entry["note"] = note
            print("OK   %-5s %s  %d chars%s" % (ext.lstrip("."), name, len(text),
                                                ("  | " + note) if note else ""))
        except Exception as exc:
            entry.update(status="failed", error=repr(exc))
            print("FAIL %-5s %s  %r" % (ext.lstrip("."), name, exc))
            traceback.print_exc()
        manifest["items"].append(entry)

    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2)
    print("DONE  %d files -> %s" % (len(files), out_dir))
    print("提示：manifest.json 中 blank_sheets / summary_like_sheets / note 标记的材料，"
          "须人工确认是否真有观察数据；无数据时只能描述工具设计，不能填写统计结果。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
