#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把分章 Markdown 源稿合成为符合指定格式规范的 .docx 课题结题/研究报告。

设计原则：格式规范由外部 JSON 配置驱动，不把任何一家单位的字体、章节、
课题名称写死在代码里；脚本只负责"按配置渲染"。内置默认配置取自
《重庆市教育评估研究会课题报告文本内容规范及要点》作为示例 profile。

支持的源稿标记（详见 references/script-usage.md）：
    @@COVER@@ ... @@ENDCOVER@@   封面逐行文字
    @@TOC@@                     目录插入位置
    ## 一、研究背景及意义       一级标题
    ### （一）研究背景          二级标题
    #### 1. 政策背景            三级标题
    @CAPTION@表1-1 ...         表格标题（置于表格前一行）
    @NOTE@注：...              表下注释（宋体五号、首行缩进两字）
    | 列1 | 列2 |              Markdown 表格
    [1] 作者.题名[J]...        参考文献条目（在"参考文献"章自动用五号悬挂缩进）

用法：
    python3 build_report.py --parts part1.md part2.md --config report-config.json \
                            --out 研究报告（定稿）.docx
"""
import argparse
import json
import os
import re
import sys

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

DEFAULT_CONFIG = {
    "profile": "重庆市教育评估研究会课题报告文本内容规范及要点（示例 profile，可被覆盖）",
    "header": "课题研究报告",
    "cover": [],
    "fonts": {"h1": "黑体", "h2": "楷体", "h3": "宋体",
              "body": "宋体", "ref": "宋体", "table": "宋体"},
    "sizes": {"h1": 14, "h2": 14, "h3": 12, "body": 12,
              "ref": 10.5, "table": 10.5, "table_wide": 9,
              "caption": 10.5, "toc1": 12, "toc2": 10.5},
    "bold": {"h1": False, "h2": True, "h3": True},
    "line_spacing_pt": 23,
    "margins_cm": {"top": 2.8, "bottom": 2.6, "left": 3.0, "right": 2.6,
                   "header": 1.5, "footer": 1.5},
    "wide_table_min_cols": 8,
    "toc": {"enabled": True, "levels": "1-2", "title": "目　　录",
            "line_spacing_pt": 17, "fonts": {"toc1": "黑体", "toc2": "宋体"}},
    "reference_heading_keyword": "参考文献",
}


def load_config(path):
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))  # deep copy
    if path:
        with open(path, encoding="utf-8") as fh:
            user = json.load(fh)
        for key, value in user.items():
            if isinstance(value, dict) and isinstance(cfg.get(key), dict):
                cfg[key].update(value)
            else:
                cfg[key] = value
    return cfg


def set_font(run, name, size, bold=False):
    run.font.name = name
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor(0, 0, 0)
    rPr = run._element.get_or_add_rPr()
    rf = rPr.find(qn("w:rFonts"))
    if rf is None:
        rf = OxmlElement("w:rFonts")
        rPr.insert(0, rf)
    for attr in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        rf.set(qn(attr), name)
    return run


def fmt_par(p, size, indent_chars=2, exact=None, align=WD_ALIGN_PARAGRAPH.JUSTIFY,
            before=0, after=0, keep_next=False):
    pf = p.paragraph_format
    pf.alignment = align
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    if exact:
        pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
        pf.line_spacing = Pt(exact)
    else:
        pf.line_spacing = 1.0
    pf.first_line_indent = Pt(size * indent_chars) if indent_chars else Pt(0)
    pf.keep_with_next = keep_next
    pf.widow_control = True
    return p


def add_text(p, text, name, size, bold=False):
    return set_font(p.add_run(text), name, size, bold)


def shade(cell, fill="EDEDED"):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    th = OxmlElement("w:tblHeader")
    th.set(qn("w:val"), "true")
    trPr.append(th)


def no_split(row):
    """禁止表格行跨页断开——长报告跨页表格最常见的版面缺陷。"""
    trPr = row._tr.get_or_add_trPr()
    trPr.append(OxmlElement("w:cantSplit"))


def add_field(paragraph, instr, placeholder=""):
    r = paragraph.add_run()
    fc = OxmlElement("w:fldChar")
    fc.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText")
    it.set(qn("xml:space"), "preserve")
    it.text = instr
    fs = OxmlElement("w:fldChar")
    fs.set(qn("w:fldCharType"), "separate")
    tx = OxmlElement("w:t")
    tx.text = placeholder
    fe = OxmlElement("w:fldChar")
    fe.set(qn("w:fldCharType"), "end")
    for el in (fc, it, fs, tx, fe):
        r._r.append(el)
    return r


def set_cell(cell, text, font, size, bold=False, center=False):
    cell.text = ""
    p = cell.paragraphs[0]
    fmt_par(p, size=size, indent_chars=0, exact=None,
            align=WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.LEFT)
    p.paragraph_format.space_before = Pt(1)
    p.paragraph_format.space_after = Pt(1)
    p.paragraph_format.line_spacing = 1.15
    add_text(p, text, font, size, bold)


def is_sep(cells):
    return all(re.fullmatch(r":?-{2,}:?", c.strip()) for c in cells if c.strip() != "")


def split_row(line):
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    return [c.strip() for c in s.split("|")]


def read_parts(paths):
    chunks = []
    for path in paths:
        with open(path, encoding="utf-8") as fh:
            chunks.append(fh.read())
    return "\n".join(c.rstrip() for c in chunks) + "\n"


def parse_source(full, cfg):
    m = re.search(r"@@COVER@@\s*\n(.*?)\n@@ENDCOVER@@", full, re.S)
    cover_lines = [x.strip() for x in m.group(1).split("\n") if x.strip()] if m else list(cfg["cover"])
    if "@@TOC@@" in full:
        rest = full[full.index("@@TOC@@") + len("@@TOC@@"):].lstrip("\n")
    else:
        rest = re.sub(r"@@COVER@@\s*\n.*?\n@@ENDCOVER@@", "", full, flags=re.S).lstrip("\n")
    return cover_lines, rest


def build(parts, out_path, config_path=None, config=None):
    cfg = config or load_config(config_path)
    F, S, B = cfg["fonts"], cfg["sizes"], cfg["bold"]
    EXACT = cfg["line_spacing_pt"]
    full = read_parts(parts)
    cover_lines, rest = parse_source(full, cfg)

    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)  # A4
    M = cfg["margins_cm"]
    sec.top_margin, sec.bottom_margin = Cm(M["top"]), Cm(M["bottom"])
    sec.left_margin, sec.right_margin = Cm(M["left"]), Cm(M["right"])
    sec.header_distance, sec.footer_distance = Cm(M["header"]), Cm(M["footer"])
    sec.different_first_page_header_footer = True

    normal = doc.styles["Normal"]
    normal.font.name = F["body"]
    normal.font.size = Pt(S["body"])
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), F["body"])
    for sname, fkey, skey, bkey in (("Heading 1", "h1", "h1", "h1"),
                                    ("Heading 2", "h2", "h2", "h2"),
                                    ("Heading 3", "h3", "h3", "h3")):
        st = doc.styles[sname]
        st.font.name = F[fkey]
        st.font.size = Pt(S[skey])
        st.font.bold = B[bkey]
        st.font.color.rgb = RGBColor(0, 0, 0)
        st._element.rPr.rFonts.set(qn("w:eastAsia"), F[fkey])

    hp = sec.header.paragraphs[0]
    fmt_par(hp, size=9, indent_chars=0, exact=None, align=WD_ALIGN_PARAGRAPH.CENTER)
    add_text(hp, cfg["header"], F["body"], 9)
    fp = sec.footer.paragraphs[0]
    fmt_par(fp, size=10.5, indent_chars=0, exact=None, align=WD_ALIGN_PARAGRAPH.CENTER)
    add_text(fp, "— ", F["body"], 10.5)
    add_field(fp, "PAGE", "1")
    add_text(fp, " —", F["body"], 10.5)

    # 封面：编号行左对齐、主标题居中放大，其余行居中
    if cover_lines:
        for i, line in enumerate(cover_lines):
            p = doc.add_paragraph()
            if i == 0:
                fmt_par(p, size=S["body"], indent_chars=0, exact=EXACT,
                        align=WD_ALIGN_PARAGRAPH.LEFT, before=6)
                add_text(p, line, F["body"], S["body"])
            elif i == 1:
                fmt_par(p, size=18, indent_chars=0, exact=None,
                        align=WD_ALIGN_PARAGRAPH.CENTER, before=90)
                add_text(p, line, F["h1"], 18)
            elif i == 2:
                fmt_par(p, size=26, indent_chars=0, exact=None,
                        align=WD_ALIGN_PARAGRAPH.CENTER, before=10, after=40)
                add_text(p, line, F["h1"], 26)
            elif i == 3:
                fmt_par(p, size=16, indent_chars=0, exact=None,
                        align=WD_ALIGN_PARAGRAPH.CENTER, before=10, after=70)
                add_text(p, line, F["h1"], 16)
            else:
                fmt_par(p, size=14, indent_chars=0, exact=None,
                        align=WD_ALIGN_PARAGRAPH.CENTER, after=8)
                add_text(p, line, F["body"], 14)
        doc.add_page_break()

    # 目录域：由 finalize_report.py 用 Word 更新后生成真实页码
    TOC = cfg["toc"]
    if TOC.get("enabled", True):
        tp = doc.add_paragraph()
        fmt_par(tp, size=18, indent_chars=0, exact=None,
                align=WD_ALIGN_PARAGRAPH.CENTER, after=18)
        add_text(tp, TOC["title"], F["h1"], 18)
        toc = doc.add_paragraph()
        fmt_par(toc, size=S["body"], indent_chars=0, exact=EXACT,
                align=WD_ALIGN_PARAGRAPH.LEFT)
        add_field(toc, 'TOC \\o "%s" \\h \\z \\u' % TOC["levels"],
                  "（在 Word 中右键“更新域”生成目录）")
        doc.add_page_break()

    lines = rest.split("\n")
    i = 0
    pending_caption = None
    ref_mode = False
    table_count = 0
    while i < len(lines):
        line = lines[i].rstrip().strip()
        if not line:
            i += 1
            continue

        if line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = split_row(lines[i])
                if not is_sep(cells):
                    rows.append(cells)
                i += 1
            if pending_caption:
                cp = doc.add_paragraph()
                fmt_par(cp, size=S["caption"], indent_chars=0, exact=EXACT,
                        align=WD_ALIGN_PARAGRAPH.CENTER, before=8, after=3, keep_next=True)
                add_text(cp, pending_caption, F["table"], S["caption"], True)
                pending_caption = None
            ncols = max(len(r) for r in rows)
            tsize = S["table_wide"] if ncols >= cfg["wide_table_min_cols"] else S["table"]
            tbl = doc.add_table(rows=len(rows), cols=ncols)
            tbl.style = "Table Grid"
            tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
            tbl.autofit = True
            for ri, row in enumerate(rows):
                for ci in range(ncols):
                    txt = row[ci] if ci < len(row) else ""
                    set_cell(tbl.cell(ri, ci), txt, F["table"], tsize,
                             bold=(ri == 0), center=(ri == 0))
                    if ri == 0:
                        shade(tbl.cell(ri, ci))
            for r in tbl.rows:
                no_split(r)
            repeat_header(tbl.rows[0])
            table_count += 1
            sp = doc.add_paragraph()
            fmt_par(sp, size=6, indent_chars=0, exact=6,
                    align=WD_ALIGN_PARAGRAPH.LEFT, after=4)
            continue

        if pending_caption:
            cp = doc.add_paragraph()
            fmt_par(cp, size=S["caption"], indent_chars=0, exact=EXACT,
                    align=WD_ALIGN_PARAGRAPH.CENTER, before=6, after=3)
            add_text(cp, pending_caption, F["table"], S["caption"], True)
            pending_caption = None

        if line.startswith("@CAPTION@"):
            pending_caption = line[len("@CAPTION@"):].strip()
            i += 1
            continue

        if line.startswith("@NOTE@"):
            p = doc.add_paragraph()
            fmt_par(p, size=S["ref"], indent_chars=2, exact=EXACT,
                    align=WD_ALIGN_PARAGRAPH.JUSTIFY, before=3, after=6)
            add_text(p, line[len("@NOTE@"):].strip(), F["ref"], S["ref"])
            i += 1
            continue

        if line.startswith("## "):
            title = line[3:].strip()
            ref_mode = cfg["reference_heading_keyword"] in title
            p = doc.add_paragraph(style="Heading 1")
            fmt_par(p, size=S["h1"], indent_chars=0, exact=EXACT,
                    align=WD_ALIGN_PARAGRAPH.CENTER, before=18, after=12, keep_next=True)
            add_text(p, title, F["h1"], S["h1"], B["h1"])
            i += 1
            continue

        if line.startswith("### "):
            p = doc.add_paragraph(style="Heading 2")
            fmt_par(p, size=S["h2"], indent_chars=0, exact=EXACT,
                    align=WD_ALIGN_PARAGRAPH.LEFT, before=12, after=6, keep_next=True)
            add_text(p, line[4:].strip(), F["h2"], S["h2"], B["h2"])
            i += 1
            continue

        if line.startswith("#### "):
            p = doc.add_paragraph(style="Heading 3")
            fmt_par(p, size=S["h3"], indent_chars=2, exact=EXACT,
                    align=WD_ALIGN_PARAGRAPH.LEFT, before=8, after=4, keep_next=True)
            add_text(p, line[5:].strip(), F["h3"], S["h3"], B["h3"])
            i += 1
            continue

        if ref_mode and re.match(r"^\[\d+\]", line):
            p = doc.add_paragraph()
            fmt_par(p, size=S["ref"], indent_chars=0, exact=EXACT,
                    align=WD_ALIGN_PARAGRAPH.JUSTIFY, after=2)
            p.paragraph_format.left_indent = Pt(21)
            p.paragraph_format.first_line_indent = Pt(-21)
            add_text(p, line, F["ref"], S["ref"])
            i += 1
            continue

        p = doc.add_paragraph()
        fmt_par(p, size=S["body"], indent_chars=2, exact=EXACT,
                align=WD_ALIGN_PARAGRAPH.JUSTIFY)
        add_text(p, line, F["body"], S["body"])
        i += 1

    settings = doc.settings.element
    upd = OxmlElement("w:updateFields")
    upd.set(qn("w:val"), "true")
    settings.append(upd)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)
    doc.save(out_path)
    print("SAVED: %s  (tables=%d, size=%d bytes)" %
          (out_path, table_count, os.path.getsize(out_path)))
    return {"docx": out_path, "tables": table_count}


def main():
    ap = argparse.ArgumentParser(description="按格式规范渲染课题结题/研究报告 Word")
    ap.add_argument("--parts", nargs="+", required=True, help="分章 Markdown 源稿，按顺序拼接")
    ap.add_argument("--out", required=True, help="输出 .docx 路径")
    ap.add_argument("--config", default=None, help="格式配置 JSON；不传则用内置示例 profile")
    args = ap.parse_args()
    build(args.parts, args.out, args.config)
    return 0


if __name__ == "__main__":
    sys.exit(main())
