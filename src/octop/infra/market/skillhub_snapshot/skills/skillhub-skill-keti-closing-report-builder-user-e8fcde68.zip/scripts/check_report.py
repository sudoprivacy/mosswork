#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""结题/研究报告成文自检：结构、残留标记、引文闭环、占位符、数据表述风险、版式抽样。

这是"交付前最后一道闸"，只做本地只读检查，不修改文档、不联网、不访问隐私路径。

用法：
    python3 check_report.py --docx 研究报告（定稿）.docx
    python3 check_report.py --docx 研究报告（定稿）.docx --json check.json
"""
import argparse
import json
import os
import re
import sys

from docx import Document

RESIDUAL_MARKERS = ["@@COVER@@", "@@ENDCOVER@@", "@@TOC@@", "@CAPTION@", "@NOTE@",
                    "## ", "### ", "#### ", "| ---", "|---"]
PLACEHOLDERS = ["据实填写", "待补", "TODO", "TBD", "以实物清单为准", "以结题实物清单为准",
                "XX学校", "××", "（此处填", "<填写>"]
# 只做人工复核提示，不判定为错误：出现量化/因果表述时必须能指回证据
RISK_PATTERNS = [
    r"提升\s*\d+(?:\.\d+)?\s*(?:%|％|个百分点)",
    r"提高\s*\d+(?:\.\d+)?\s*(?:%|％|个百分点|分)",
    r"下降\s*\d+(?:\.\d+)?\s*(?:%|％|个百分点)",
    r"得分率\s*\d+(?:\.\d+)?\s*%",
    r"平均(?:分|成绩)\s*\d+",
    r"显著(?:提升|提高|改善|优于)",
    r"证明(?:了)?(?:有效|显著)",
    r"对照组.{0,12}(?:提高|优于)",
]


def font_desc(par):
    if not par.runs:
        return None
    run = par.runs[0]
    pf = par.paragraph_format
    spacing = pf.line_spacing
    if hasattr(spacing, "pt"):
        spacing = spacing.pt
    return {
        "font": run.font.name,
        "size_pt": run.font.size.pt if run.font.size else None,
        "bold": run.font.bold,
        "line_spacing": spacing,
        "first_line_indent_pt": pf.first_line_indent.pt if pf.first_line_indent else None,
    }


def check(docx_path):
    d = Document(docx_path)
    paras = d.paragraphs
    texts = [p.text for p in paras]
    table_text = "\n".join(c.text for t in d.tables for r in t.rows for c in r.cells)
    all_text = "\n".join(texts) + "\n" + table_text

    h1 = [p for p in paras if p.style.name == "Heading 1"]
    h2 = [p for p in paras if p.style.name == "Heading 2"]
    h3 = [p for p in paras if p.style.name == "Heading 3"]

    ref_paras = [p for p in paras if re.match(r"^\[\d+\]", p.text.strip())]
    ref_nums = {int(re.match(r"^\[(\d+)\]", p.text.strip()).group(1)) for p in ref_paras}
    body_text = "\n".join(p.text for p in paras if p not in ref_paras) + "\n" + table_text
    in_text_nums = {int(x) for x in re.findall(r"\[(\d+)\]", body_text)}

    residual = {m: all_text.count(m) for m in RESIDUAL_MARKERS if all_text.count(m)}
    placeholders = {m: all_text.count(m) for m in PLACEHOLDERS if all_text.count(m)}
    risks = {}
    for pat in RISK_PATTERNS:
        hits = re.findall(pat, all_text)
        if hits:
            risks[pat] = len(hits)

    body_par = next((p for p in paras if len(p.text) > 60 and p.style.name == "Normal"), None)
    samples = {}
    for label, par in (("Heading 1", h1[0] if h1 else None),
                       ("Heading 2", h2[0] if h2 else None),
                       ("Heading 3", h3[0] if h3 else None),
                       ("正文", body_par),
                       ("参考文献", ref_paras[0] if ref_paras else None)):
        if par is not None:
            samples[label] = font_desc(par)

    return {
        "docx": os.path.abspath(docx_path),
        "structure": {
            "paragraphs": len(paras),
            "tables": len(d.tables),
            "heading1": len(h1),
            "heading2": len(h2),
            "heading3": len(h3),
            "chapters": [p.text for p in h1],
        },
        "citations": {
            "reference_entries": len(ref_paras),
            "cited_in_body": sorted(in_text_nums),
            "listed_in_references": sorted(ref_nums),
            "cited_but_not_listed": sorted(in_text_nums - ref_nums),
            "listed_but_not_cited": sorted(ref_nums - in_text_nums),
        },
        "residual_markers": residual,
        "placeholders_needing_human_input": placeholders,
        "quantitative_claims_to_verify": risks,
        "format_samples": samples,
        "pass": (not residual
                 and not (in_text_nums - ref_nums)
                 and len(h1) > 0
                 and len(ref_paras) > 0),
    }


def main():
    ap = argparse.ArgumentParser(description="结题/研究报告成文自检")
    ap.add_argument("--docx", required=True)
    ap.add_argument("--json", default=None, help="可选：把检查结果写成 JSON")
    args = ap.parse_args()
    if not os.path.isfile(args.docx):
        print("ERROR: 找不到文档", args.docx)
        return 2
    result = check(args.docx)
    s, c = result["structure"], result["citations"]
    print("=== 结构 ===")
    print("章节 %d / 二级 %d / 三级 %d / 表格 %d / 段落 %d" %
          (s["heading1"], s["heading2"], s["heading3"], s["tables"], s["paragraphs"]))
    print("=== 引文闭环 ===")
    print("参考文献条目 %d，正文引用 %d，漏列 %s，未引用 %s" %
          (c["reference_entries"], len(c["cited_in_body"]),
           c["cited_but_not_listed"] or "无", c["listed_but_not_cited"] or "无"))
    print("=== 残留标记 ===", result["residual_markers"] or "无")
    print("=== 待人工补齐 ===", result["placeholders_needing_human_input"] or "无")
    print("=== 需核对证据的量化表述 ===", result["quantitative_claims_to_verify"] or "无")
    print("=== 版式抽样 ===")
    for k, v in result["format_samples"].items():
        print("  %-10s %s" % (k, v))
    print("=== 结论 ===", "PASS" if result["pass"] else "NEEDS ATTENTION")
    if args.json:
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(result, fh, ensure_ascii=False, indent=2)
        print("JSON ->", args.json)
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
