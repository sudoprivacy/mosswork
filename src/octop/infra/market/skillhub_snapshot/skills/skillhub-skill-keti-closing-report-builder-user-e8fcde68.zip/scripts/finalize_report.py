#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""两阶段终稿合成：Word 目录域更新 + 目录样式压缩 + PDF 预览导出。

为什么要分两个独立进程（stage A / stage B）：
同一 Python 进程里反复 DispatchEx/Quit Word.Application 会触发 COM 会话冲突
（常见表现为 "被调用方拒绝接收呼叫"）。分进程执行可稳定复现。

    stage A：生成 docx → Word 更新目录 → 压缩目录样式（toc 1 / toc 2 字体行距）
    stage B：Word 再次更新目录（页码稳定）→ 导出 PDF 预览 → 回报总页数

无本机 Word 时脚本不会崩溃：会跳过目录/PDF 步骤并打印降级说明，
docx 中的 w:updateFields 已置 true，用户用 Word 打开即可自动更新目录。

用法：
    python3 finalize_report.py --stage A --parts p1.md p2.md \
        --config report-config.json --docx 研究报告（定稿）.docx
    python3 finalize_report.py --stage B --docx 研究报告（定稿）.docx \
        --pdf preview.pdf --config report-config.json
"""
import argparse
import json
import os
import sys

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

import build_report


def word_app():
    """返回 (app, ok)。无 win32com 或无 Word 时返回 (None, False)。"""
    try:
        import win32com.client as win32
        app = win32.DispatchEx("Word.Application")
        app.Visible = False
        app.DisplayAlerts = 0
        return app, True
    except Exception as exc:
        print("[DEGRADE] 本机 Word COM 不可用（%r），跳过目录更新/PDF 导出。" % exc)
        print("[DEGRADE] docx 已写入 w:updateFields=true，用 Word 打开时目录会自动更新。")
        return None, False


def word_update(docx_path, pdf_path=None):
    app, ok = word_app()
    if not ok:
        return None
    pages = None
    try:
        doc = app.Documents.Open(docx_path)
        try:
            for i in range(1, doc.TablesOfContents.Count + 1):
                doc.TablesOfContents(i).Update()
            doc.Fields.Update()
            doc.Save()
            pages = doc.ComputeStatistics(2)  # wdStatisticPages
            if pdf_path:
                os.makedirs(os.path.dirname(os.path.abspath(pdf_path)) or ".", exist_ok=True)
                doc.ExportAsFixedFormat(os.path.abspath(pdf_path), 17)  # wdExportFormatPDF
        finally:
            doc.Close(0)
    finally:
        app.Quit()
    return pages


def set_toc_styles(docx_path, cfg):
    """目录生成后 toc 1 / toc 2 样式才存在；压缩行距避免目录多占一页。"""
    d = Document(docx_path)
    sizes = cfg["sizes"]
    fonts = cfg["toc"].get("fonts", {"toc1": "黑体", "toc2": "宋体"})
    exact = cfg["toc"].get("line_spacing_pt", 17)
    targets = (("toc 1", fonts["toc1"], sizes.get("toc1", 12)),
               ("toc 2", fonts["toc2"], sizes.get("toc2", 10.5)))
    for name, fname, size in targets:
        try:
            st = d.styles[name]
        except KeyError:
            print("missing style", name)
            continue
        st.font.name = fname
        st.font.size = Pt(size)
        st.font.bold = False
        st.font.color.rgb = RGBColor(0, 0, 0)
        rpr = st._element.get_or_add_rPr()
        rf = rpr.find(qn("w:rFonts"))
        if rf is None:
            rf = OxmlElement("w:rFonts")
            rpr.insert(0, rf)
        for attr in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
            rf.set(qn(attr), fname)
        pf = st.paragraph_format
        pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
        pf.line_spacing = Pt(exact)
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)
    for p in d.paragraphs:
        if p.style.name in ("toc 1", "toc 2"):
            pf = p.paragraph_format
            pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
            pf.line_spacing = Pt(exact)
            pf.space_before = Pt(0)
            pf.space_after = Pt(0)
    d.save(docx_path)


def load_cfg(path):
    return build_report.load_config(path)


def main():
    ap = argparse.ArgumentParser(description="终稿合成：目录域 / 目录样式 / PDF 预览")
    ap.add_argument("--stage", choices=["A", "B"], required=True)
    ap.add_argument("--parts", nargs="*", default=[], help="stage A 需要，分章 Markdown 源稿")
    ap.add_argument("--docx", required=True, help="输出/待处理的 .docx 路径")
    ap.add_argument("--pdf", default=None, help="stage B 的 PDF 预览输出路径")
    ap.add_argument("--config", default=None, help="格式配置 JSON")
    args = ap.parse_args()
    cfg = load_cfg(args.config)

    if args.stage == "A":
        if args.parts:
            build_report.build(args.parts, args.docx, config=cfg)
        elif not os.path.isfile(args.docx):
            print("ERROR: stage A 需要 --parts 或已存在的 --docx")
            return 2
        pages = word_update(args.docx)
        set_toc_styles(args.docx, cfg)
        print("stage A done, pages =", pages)
    else:
        pages = word_update(args.docx, args.pdf)
        print("stage B done, pages =", pages)
        if args.pdf and os.path.isfile(args.pdf):
            print("PDF:", args.pdf, os.path.getsize(args.pdf), "bytes")
    return 0


if __name__ == "__main__":
    sys.exit(main())
