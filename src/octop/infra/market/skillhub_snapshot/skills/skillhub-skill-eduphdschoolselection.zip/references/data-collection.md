# 招生简章数据采集规范（近五年）

本文件定义"一条招生简章要采什么字段、从哪采、怎么标可信度"。数据质量决定报告可用性，采集环节偷懒等于报告作废。

## 一、信息源层级（抓取顺序固定）

| 层级 | 文件 | 决定什么 | 可否省略 |
|---|---|---|---|
| L1 学校层 | 研究生院/研招网《博士研究生招生简章》 | 招生方式、报名时间、报考费、录取规则、全校性条件 | 不可 |
| L2 院系层 | 教育学部/教育学院《博士研究生招生工作办法》或《实施细则》 | 专业目录、招考人数、材料清单、考核流程、考核内容与占比、具体时间 | **不可，这是最核心的一份** |
| L3 目录层 | 《招生学科专业目录》 | 学科-导师对应关系、导师限招名额 | 不可 |
| L4 专项层 | 专项计划独立公告 | 师范教育协同提质、高校思政课教师专项、少数民族骨干、对口支援 | 视情况，行政岗考生优先查 |
| L5 补充层 | 院系官网通知、学院公众号推文 | 地址、时间微调、材料寄送方式 | 可选 |
| L6 参考层 | 往届拟录取公示、导师个人主页 | 实际录取人数、导师在招方向与偏好、学生来源结构 | **强烈建议**，用于推算报录比 |

**关键**：材料清单、考核内容、导师名单 100% 在 L2/L3，不在 L1。只查学校简章等于没查。

## 二、逐字段采集清单

每年每校一份，按下表逐字段填入 `dataset.json` 的 `schools[].admissions[年份]`。

### 1. 招生基本信息

| 字段 | key | 说明与坑 |
|---|---|---|
| 招生年度 | 年份键 | 用"招生年份"而非"发布年份"。2025 年入学简章通常 2024 年 10–12 月发布 |
| 院系招生计划 | `plan_total` | 院系拟招总数 |
| 分专业计划 | `plan_by_specialty` | **必须采**。不同方向分档差别极大，总数没有决策价值 |
| 报考人数 | `applied` | 从报名系统统计或公示推算；多数院校不公开，需估 |
| 实际录取人数 | `enrolled` | 从拟录取公示数人头。这是"实际录取人数"最可靠的来源 |
| 分专业录取 | `enrolled_by_specialty` | 推算目标方向真实竞争度 |
| 学费总额 | `tuition_total` | 注意是**全周期总额**，不是每年额 |
| 学制 | `duration_years` | |
| 学习方式 | `study_mode` | 全日制 / 非全日制 |
| 就业类型 | `employment_type` | 定向 / 非定向 |

### 2. 时间节点

| 字段 | key | 说明 |
|---|---|---|
| 简章发布日 | `announcement_date` | |
| 报名起止 | `signup_start` / `signup_end` | 以系统关闭时间为准，纸质材料以**寄出邮戳**为准 |
| 考核日期 | `exam_date` | |
| 政审调档 | 可放 `notes` | 通常在次年 6 月 |

### 3. 招考条件 / 报名条件 / 报名要求（三者要分开记）

- `requirements.degree_min`：学位门槛
- `requirements.work_years_min`：工作年限门槛（EdD 最常见的硬筛）
- `requirements.foreign_language`：外语门槛原文
- `requirements.title_requirement`：职称要求原文
- `requirements.same_equivalence_accepted`：是否接收同等学力（接收通常还要学士满 6 年 + 5 门主干课成绩）
- `requirements.recommenders`：推荐专家人数
- `requirements.unit_consent_required`：是否要单位同意报考证明
- `requirements.other`：其余原文

**易混提醒**：
- "招考条件"= 你必须满足才能报名（资格门槛）
- "报名要求"= 报名时怎么交材料（系统操作 + 纸质寄送）
- "报名条件"常被混用，本技能统一收进 `requirements`，原文进 `other`

### 4. 考试内容与流程

```
process:        ["网上报名","资格审查","材料评议","专业笔试","面试","政审与调档"]
exam_content.written:    笔试科目 + 参考书
exam_content.interview:  面试形式（结构化/试讲/专题陈述/外文问答）
exam_content.weights:    各环节分值结构
```

`weights` 是本技能最有价值的字段。典型结构：

```json
{"学业成绩": 10, "外语": 10, "科研成果": 40, "科研潜力": 40, "综合考核单科最低": 60}
```

读懂它才知道材料往哪写：科研成果 40–50 分 + 科研潜力 30–60 分合计常超 70 分，个人陈述与 CV 只是这一环节的输入；外语与学业成绩是送分项。

### 5. 毕业要求

```
graduation.credits_required    学分
graduation.coursework          核心课程清单
graduation.thesis              学位论文类型
graduation.practice_requirement 实践环节要求
graduation.publications        毕业成果硬要求（写清"CSSCI/北大核心 X 篇"及是否有年份弹性）
graduation.assessment           考核方式
```

对行政岗考生，`practice_requirement` 决定"读博期间还得做多少一线实践"——这是能不能承受的关键，直接进培养契合分。

### 6. 博士生导师名单（核心字段）

每位导师一个对象：

```json
{
  "name": "×××",
  "title": "教授 / 博导",
  "research": ["学校组织变革", "教师专业发展", "课程领导"],
  "recent_papers": ["近3年代表论文或课题主题"],
  "recruit_preference": "招生偏好描述",
  "spots_2025": 3,
  "spots_2024": 3,
  "student_background": "往届学生来源结构",
  "contact_hint": "信息来源"
}
```

采集来源与可靠性排序：
1. 招生专业目录（名单权威，但无研究方向与偏好）
2. 导师个人主页 / 学院师资页（研究方向、近期论文权威）
3. 招生方向说明、导师访谈、课题组介绍（招生偏好、学生来源结构多来自这里，标 `inferred`）

`recruit_preference` 与 `spots` 常无公开来源，必须在 `verification_log` 里标 `inferred` 或 `pending`。

### 7. 学术实力

```
strengths.discipline_eval     {year, grade, is_target_discipline, source}
strengths.subject_ranking     {system, year, rank, source}
strengths.dr_double_first_class ["教育学"]
```

- 学科评估用教育部第四轮（2022）结果，注明是"教育学"还是"教育技术学"等不同一级学科——**不要混用**
- 排名用软科教育学，注明年份与体系，不与 QS/ESI 混算
- 打分模型对 `is_target_discipline=true` 的评估等级给更高权重：学校整体强但目标学科弱的情况要区别对待

## 三、采集执行方式（混合模式）

### 3.1 自动抓取（用 WebSearch / WebFetch）

按 L1→L6 顺序抓，构造查询串：

```
<院校名> <院系名> 博士研究生 招生工作办法 <年份>
<院校名> 博士研究生 招生专业目录 <年份>
<院校名> 博士 拟录取名单 公示 <年份>
<导师名> <院校名> 研究方向 招生
```

抓取时的三条纪律：
1. 只把**官方域名**（学校 .edu.cn 域、研究生院、院系站点、学位授予单位公示）作为 `verification_level: official`；公众号推文、论坛、考研机构文章标 `secondary`，**其数字不得单独作为打分依据**。
2. 抓不到就写 `null`。不用常识补。
3. 记录 `retrieved_at`。

### 3.2 用户补充（无法公开获取的字段）

以下字段基本只能由用户提供或从申请者视角推算：

- 报考人数 `applied`（院校通常不公开）
- 导师招生偏好 `recruit_preference`
- 导师名额 `spots_*`（部分院系办法会写"导师限招数"）
- 分专业实际录取数

提供 `assets/dataset-template.json` 作为填写模板，用户按 `data_gaps` 清单补齐。

### 3.3 数据代际对齐（近五年的坑）

- 2021–2022 年多为"申请—考核"制，考核环节与分值结构常与近年不同 → 趋势分析时标注制度变更年份，不把制度变化误读为竞争变化
- 招生单位可能更名（如教育学院→教育学部）→ 用 `school_id` 保持同一实体
- 专业代码会变（如 045101）→ 以名称为主、代码为辅
- 疫情年份报名人数异常 → 趋势解读时标注

## 四、核验日志规范

每条非 obvious 的数字都要在 `verification_log` 留痕：

```json
{
  "school_id": "ecnu-edu",
  "year": 2025,
  "field": "enrolled",
  "value": 28,
  "status": "verified | inferred | pending",
  "source_url": "...",
  "note": "差额为推免占用与方向调剂"
}
```

status 语义：
- `verified`：官方原文可查
- `inferred`：由公开信息推断（如导师偏好），报告中必须提示人工确认
- `pending`：用户尚未提供，报告中该维度降权处理

## 五、采集完成的判定标准

一所院校的数据算"可用于打分"，须同时满足：

- [ ] 至少 1 个招生年度的 `plan_total` / `plan_by_specialty` / `process` / `exam_content` / `requirements` 齐全
- [ ] 至少 1 位在招导师有 `research` 与 `recruit_preference`
- [ ] `strengths.discipline_eval` 或 `subject_ranking` 至少一项有值
- [ ] 有 `source_url` 与 `retrieved_at`
- [ ] 近五年至少 3 个年度有数据（否则趋势分析不可用，只能单年判断）

未达标的院校在报告中标注"信息不足"，**不参与优先级排序**，单独列在待补齐清单里。
