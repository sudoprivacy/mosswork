#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""择校建议报告生成器（输出环节）。

输入：数据集 JSON（含 profile 与 schools）+ 打分结果 JSON（score_schools.py 产出）
输出：一份完整的 Markdown 择校建议报告，含优先级排序、逐校理由、导师匹配矩阵、
      五年趋势、时间倒排表、数据缺口与待核实清单。

用法:
    python3 build_report.py dataset.json --scores scores.json --out 择校建议报告.md
    python3 build_report.py dataset.json --scores scores.json --top 3
"""

import argparse
import json
import os
import sys

POSITION_LABEL = {
    "kindergarten_admin": "幼儿园管理岗",
    "k12_admin": "中小学管理岗",
    "higher_ed_admin": "高校行政岗",
}


def fmt(v, nd=1):
    if v is None:
        return "—"
    if isinstance(v, float):
        return f"{v:.{nd}f}"
    return str(v)


def exclusion_hint(r):
    """被排除时给出可行动作，而不是只丢一句"不符合条件"。"""
    fatals = [g for g in r.get("gates", []) if g.get("fatal")]
    names = {g["name"]: g["detail"] for g in fatals}
    hints = []
    if "工作年限" in names:
        hints.append("关注同校上一年度是否放宽年限，或改走对工作年限另有口径的专项通道")
    if "外语" in names:
        hints.append("查询该专业是否接受同等英语水平证明，或改报同校无外语硬门槛的专业")
    if "职称" in names:
        hints.append("查询该专业是否对职称另有说明，或先完成职称晋升再申报下一轮")
    if "单位同意报考证明" in names:
        hints.append("先与单位人事部门确认能否出具在职证明，再决定是否投入材料准备")
    if "学习方式" in names:
        hints.append("确认本人所在岗位能否脱产；若不能，优先找同方向的非全日制定向项目")
    if "就业类型" in names:
        hints.append("核对单位是否只能提供在职证明；部分院校定向通道要求单位统一报名")
    if "学费" in names:
        hints.append("了解分期学费、奖学金与助学金政策，或改选学费更低的院校")
    if "学位门槛" in names:
        hints.append("该专业要求更高学位，需等学历提升后再申报")
    if "导师在招" in names:
        hints.append("招生目录中该方向当年无导师在招，可关注下一年度新增导师或新增专业")
    if not hints:
        hints.append("补齐该校招生简章与在招导师信息后重新评估")
    return "；".join(hints)


def build(dataset, scores, top=None):
    profile = dataset.get("profile") or {}
    schools = {s.get("id"): s for s in (dataset.get("schools") or [])}
    passed = scores.get("passed") or []
    failed = scores.get("failed") or []
    weights = scores.get("weights") or {}
    td = profile.get("target_direction") or {}
    pd_ = profile.get("position_detail") or {}
    cons = profile.get("constraints") or {}

    L = []
    L.append("# 教育专业博士择校建议报告\n")
    L.append(f"**画像定位**：{POSITION_LABEL.get(profile.get('position_category'), '未分类')} · "
             f"{pd_.get('role') or '岗位未填'} · "
             f"教学 {fmt(pd_.get('teaching_years'), 0)} 年 / 管理 {fmt(pd_.get('admin_years'), 0)} 年\n")
    L.append(f"**主攻方向**：{td.get('primary') or '—'}　|　"
             f"**次要方向**：{'、'.join(td.get('secondary') or []) or '—'}\n")
    L.append(f"**核心研究兴趣**：{td.get('topic_interest') or '—'}\n")
    L.append("> 本报告由数据与打分模型生成，硬门槛结论可信；权重与理由须经人工复核后方可作为报考依据。"
             "所有招生信息以目标院校当年官方文件为准。\n")

    # 一、候选池与筛选结果
    L.append("\n## 一、候选池与筛选结果\n")
    L.append(f"- 候选院校总数：{len(schools)}")
    L.append(f"- 通过硬门槛：{len(passed)} 所")
    L.append(f"- 未通过或信息不足：{len(failed)} 所")
    if failed:
        L.append("\n**被排除的院校及原因**：\n")
        for r in failed:
            fatals = [g for g in r.get("gates", []) if g.get("fatal")]
            if fatals:
                msg = "；".join(f"**{g['name']}** — {g['detail']}" for g in fatals)
            else:
                msg = r.get("error", "信息不足，无法评估")
            L.append(f"- {r.get('school')}：{msg}")
            hint = exclusion_hint(r)
            if hint:
                L.append(f"  - 可行动作：{hint}")
    L.append("\n**打分权重（可按个人偏好调整）**：" + "、".join(
        f"{k} {v:.0%}" for k, v in weights.items()))

    if not passed:
        L.append("\n> 无通过硬门槛的院校。请先补充数据或放宽约束条件。")
        return "\n".join(L)

    # 二、优先级排序
    L.append("\n## 二、优先级排序\n")
    L.append("| 优先级 | 院校 | 城市 | 层次 | 目标专业 | 总分 | 方向 | 导师 | 概率 | 实力 | 培养 | 时间 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    for r in passed[:top or len(passed)]:
        d = r["dimensions"]
        L.append("| {rank} | **{school}** | {city} | {tier} | {spec} | {total} | {a} | {b} | {c} | {e} | {f} | {g} |".format(
            rank=r["rank"], school=r["school"], city=r.get("city") or "—",
            tier=r.get("tier") or "—",
            spec=(r.get("top_specialty") or {}).get("name", "—"),
            total=fmt(r["total"], 1), a=fmt(d["方向匹配"]), b=fmt(d["导师匹配"]),
            c=fmt(d["录取概率"]), e=fmt(d["学术实力"]), f=fmt(d["培养契合"]), g=fmt(d["时间成本"])))
    L.append("\n> 分值为 0–100 的相对可比刻度，用于**同一份报告内部横向排序**，不可跨报告比较，也不可解读为录取概率。")

    # 三、逐校深度分析
    L.append("\n## 三、逐校分析（按优先级）\n")
    for r in passed[:top or len(passed)]:
        sch = schools.get(r["school_id"]) or {}
        L.append(f"### 第 {r['rank']} 优先级 · {r['school']}\n")
        comp = r.get("competitiveness") or {}
        aca = r.get("academic") or {}
        cul = r.get("cultivation") or {}
        tim = r.get("timing") or {}
        L.append(f"- **城市 / 层次**：{r.get('city') or '—'} · {r.get('tier') or '—'}")
        L.append(f"- **招生年度**：{r['year_used']}（数据来源：{r['source'].get('type') or '—'}，"
                 f"核验级别 {r['source'].get('verification_level') or '—'}，查阅日期 {r['source'].get('retrieved_at') or '—'}）")
        L.append(f"- **建议报考专业**：{(r.get('top_specialty') or {}).get('name')}"
                 f"（{(r.get('top_specialty') or {}).get('type') or '类型未标注'}）")
        L.append(f"- **学术实力**：{aca.get('note') or '—'}")
        if aca.get("double_first_class"):
            L.append(f"  - 双一流学科：{'、'.join(aca['double_first_class'])}")
        fill = comp.get("plan_fill")
        fill_txt = f"{fill * 100:.0f}%" if isinstance(fill, (int, float)) else "—"
        L.append(f"- **录取概率参考**：报录比 {fmt(comp.get('ratio'), 2)}:1"
                 f"（计划 {fmt(comp.get('plan_total'), 0)} / 报考 {fmt(comp.get('applied'), 0)}"
                 f" / 实际录取 {fmt(comp.get('enrolled'), 0)}），计划完成率 {fill_txt}")
        L.append(f"- **培养方案要点**：核心课程 {fmt(cul.get('coursework_count'), 0)} 门；"
                 f"实践要求：{cul.get('practice') or '未标注'}；学制 {fmt(cul.get('duration_years'), 0)} 年")
        if cul.get("publications"):
            L.append(f"  - 毕业成果要求：{cul['publications']}")
        tl = tim.get("timeline") or {}
        if tl:
            L.append(f"- **时间节点**：简章 {tl.get('announcement_date', '—')} 发布；"
                     f"报名 {tl.get('signup_start', '—')} 至 {tl.get('signup_end', '—')}；"
                     f"考核 {tl.get('exam_date', '—')}"
                     + (f"；材料准备窗口 {tim['buffer_days']} 天" if tim.get("buffer_days") else ""))
        L.append(f"\n**其他可报专业**：")
        for sp in r.get("specialty_candidates") or []:
            L.append(f"  - {sp['name']}（{sp.get('type') or '类型未标注'}）契合度 {sp['fit']}")
        L.append(f"\n**推荐理由**：\n")
        for i, reason in enumerate(r.get("reasons") or [], 1):
            L.append(f"{i}. {reason}")
        ar = r.get("advisor_ranking") or []
        if ar:
            L.append(f"\n**导师匹配排序**（依据招生专业目录与导师主页）：\n")
            L.append("| 导师 | 职称 | 匹配分 | 研究方向 | 招生偏好 | 名额 | 近年论文/课题 |")
            L.append("|---|---|---|---|---|---|---|")
            for a in ar:
                L.append(f"| {a.get('name') or '—'} | {a.get('title') or '—'} | {fmt(a.get('match'))} | "
                         f"{'；'.join(a.get('research') or []) or '—'} | "
                         f"{a.get('recruit_preference') or '—'} | {fmt(a.get('spots'), 0)} | "
                         f"{'、'.join(a.get('recent_papers') or []) or '—'} |")
            L.append(f"\n> 首位导师的匹配拆解：方向重合 {fmt(ar[0].get('direction_score'))} 分 / "
                     f"偏好命中 {fmt(ar[0].get('preference_score'))} 分"
                     f"（命中类别：{'、'.join(ar[0].get('preference_hits') or []) or '无'}）"
                     + (f" / 实践经历对位加分 {fmt(ar[0].get('practice_bonus'))} 分"
                        f"（重叠维度：{'、'.join(ar[0].get('practice_overlap') or [])}）"
                        if ar[0].get("practice_bonus") else "")
                     + "。建议在联系导师时直接引用上述偏好表述，而非泛泛自我介绍。")
        tr = r.get("five_year_trend") or []
        if len(tr) >= 2:
            span = f"{tr[0]['year']}–{tr[-1]['year']}"
            L.append(f"\n**招生趋势（{span}）**：\n")
            L.append("| 年度 | 计划 | 报考 | 录取 | 报录比 |")
            L.append("|---|---|---|---|---|")
            for t in tr:
                L.append(f"| {t['year']} | {fmt(t['plan'], 0)} | {fmt(t['applied'], 0)} | "
                         f"{fmt(t['enrolled'], 0)} | {fmt(t['ratio'], 2)} |")
            ratios = [t["ratio"] for t in tr if t.get("ratio")]
            if len(ratios) >= 2:
                delta = ratios[-1] - ratios[0]
                trend_word = "上升（竞争加剧）" if delta > 1 else ("下降（竞争缓和）" if delta < -1 else "基本持平")
                L.append(f"\n> 报录比在 {span} 期间{trend_word}：{ratios[0]:.2f} → {ratios[-1]:.2f}。"
                         f"须注意：计划数同步变化时，报录比持平可能意味着实际竞争未加剧；"
                         f"若报考人数缺失，此趋势仅反映已录入年份。")
        gaps = r.get("data_gaps") or []
        if gaps:
            L.append(f"\n**数据缺口**：{'；'.join(gaps)}")
        L.append("")

    # 四、行动清单
    L.append("\n## 四、行动清单与时间倒排\n")
    L.append("| 优先级 | 动作 | 说明 |")
    L.append("|---|---|---|")
    acts = [
        ("P0", "补齐候选院校近五年招生简章原文", "学校简章 + 院系招生工作办法 + 招生学科专业目录 + 拟录取公示，四件套缺一不可"),
        ("P0", "核验目标专业在招导师与限招名额", "招生专业目录是唯一权威来源；导师主页只能作为方向参考"),
        ("P1", "联系首选导师前先完成三项确认", "是否在招、名额数、选题与招生偏好的具体表述"),
        ("P1", "按各校材料清单倒排准备时间", "从报名截止日倒推：材料定稿 → 推荐人签署 → 扫描合成 PDF → 打印装订 → 寄出（留足 5–7 天）"),
        ("P2", "补全外语成绩与职称证明", "这两项是硬门槛，不能靠综合考核补救"),
        ("P2", "准备" + "综合考核" + "三件套", "笔试科目范围、面试形式、外文问答，按目标院校考核办法逐项准备"),
    ]
    for p, a, d in acts:
        L.append(f"| {p} | {a} | {d} |")

    # 五、数据可信度
    L.append("\n## 五、数据可信度与待核实清单\n")
    vl = dataset.get("verification_log") or []
    if vl:
        L.append("| 院校 | 年度 | 字段 | 状态 | 说明 |")
        L.append("|---|---|---|---|---|")
        for v in vl:
            L.append(f"| {v.get('school_id', '—')} | {v.get('year', '—')} | {v.get('field', '—')} | "
                     f"{v.get('status', '—')} | {v.get('note', '')} |")
    else:
        L.append("未登记核验日志。")
    L.append("\n**通用提醒**：招生人数、考核科目、时间节点每年变动，任何数字都必须回到该校当年官方文件二次确认。")

    L.append("\n---\n")
    L.append("**生成方式**：教育专业博士择校决策支持工具（edu-phd-school-selection）· "
             "数据来源见各校条目的 source 与查阅日期。")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="生成择校建议报告")
    ap.add_argument("dataset")
    ap.add_argument("--scores", required=True, help="score_schools.py 产出的 JSON")
    ap.add_argument("--out", default="择校建议报告.md")
    ap.add_argument("--top", type=int, default=None, help="只展开前 N 所")
    args = ap.parse_args()

    with open(args.dataset, encoding="utf-8") as f:
        dataset = json.load(f)
    with open(args.scores, encoding="utf-8") as f:
        scores = json.load(f)

    md = build(dataset, scores, args.top)
    out = os.path.abspath(args.out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(f"报告已写入 {out}（{len(md)} 字符）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
