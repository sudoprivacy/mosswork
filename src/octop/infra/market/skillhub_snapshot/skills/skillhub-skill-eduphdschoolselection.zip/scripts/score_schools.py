#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""教育专业博士择校匹配打分引擎。

读取 assets/dataset-template.json 结构的数据集，执行：
  1. 硬门槛过滤（学历、工作年限、外语、职称、单位证明、定向/非定向、学制学费、地域、导师在招）
  2. 多维度打分（学术实力 / 方向匹配 / 导师匹配 / 录取概率 / 培养契合 / 时间成本）
  3. 优先级排序 + 理由生成

用法:
    python3 score_schools.py dataset.json                    # 输出到 stdout
    python3 score_schools.py dataset.json --out scores.json --csv scores.csv
    python3 score_schools.py dataset.json --weights '{"方向匹配":0.35}'

仅用标准库，无需 pandas。
"""

import argparse
import csv
import json
import math
import re
import sys
from collections import Counter

# ---------------------------------------------------------------- 权重配置

DEFAULT_WEIGHTS = {
    "方向匹配": 0.30,
    "导师匹配": 0.22,
    "录取概率": 0.18,
    "学术实力": 0.15,
    "培养契合": 0.08,
    "时间成本": 0.07,
}

# 不同岗位类别下对"名校"与"导师"的偏好不同：高校行政更看重学术实力与导师声望，
# 一线中小学管理者更看重方向对口、录取概率与时间成本。
POSITION_WEIGHTS = {
    "kindergarten_admin": {
        "方向匹配": 0.32, "导师匹配": 0.24, "录取概率": 0.20,
        "学术实力": 0.10, "培养契合": 0.08, "时间成本": 0.06,
    },
    "k12_admin": {
        "方向匹配": 0.30, "导师匹配": 0.22, "录取概率": 0.18,
        "学术实力": 0.15, "培养契合": 0.08, "时间成本": 0.07,
    },
    "higher_ed_admin": {
        "方向匹配": 0.24, "导师匹配": 0.26, "录取概率": 0.13,
        "学术实力": 0.24, "培养契合": 0.07, "时间成本": 0.06,
    },
}

EVAL_GRADE_SCORE = {
    "A+": 100, "A": 92, "A-": 84, "B+": 76, "B": 68, "B-": 60,
    "C+": 52, "C": 45, "C-": 38, "D+": 32, "D": 25,
}
EVAL_GRADE_DEFAULT = 45  # 未获评估等级：按中位处理，同时在理由中标注"缺少学科评估支撑"

# 报录比（applied / enrolled）到录取概率分的分段映射
RATIO_BREAKPOINTS = [
    (2.0, 100), (3.0, 88), (4.0, 78), (6.0, 66), (8.0, 55),
    (12.0, 42), (20.0, 30), (float("inf"), 20),
]

# 中文文本分词缺失时的兜底：偏好词典命中表
PREFERENCE_LEXICON = {
    "管理": ["管理", "校长", "行政", "组织", "领导", "治理", "教研主任", "教科室"],
    "课程": ["课程", "校本课程", "教学", "课堂", "教案", "课程开发"],
    "教师发展": ["教师发展", "教师专业发展", "教研", "培训", "名师", "师资"],
    "德育": ["德育", "班级管理", "学生工作", "心理健康", "班主任"],
    "实践": ["实践", "行动研究", "现场", "一线", "校本", "试点", "实验学校"],
    "评价": ["评价", "评估", "质量监测", "督导", "考核"],
    "信息化": ["信息化", "数字", "人工智能", "数据", "智慧教育", "技术"],
    "公平": ["公平", "弱势", "乡村", "特殊教育", "随迁", "农村"],
}

FOREIGN_LANGUAGE_LEVELS = {
    "none": 0, "cet4_425": 1, "cet6_425": 2, "cet6_500": 3,
    "ielts_65": 4, "ielts_70": 3.5, "toefl_90": 4, "gre_310": 3.5,
    "专八": 4, "专四": 2.5,
}

REQUIRED_LANG_BY_REQ = {
    "cet4_425": "cet4_425", "四级 425": "cet4_425", "四级425": "cet4_425",
    "cet6_425": "cet6_425", "六级 425": "cet6_425", "六级425": "cet6_425",
    "六级 450": "cet6_500", "六级450": "cet6_500",
    "ielts_65": "ielts_65", "雅思 6.5": "ielts_65", "toefl_90": "toefl_90",
    "托福 90": "toefl_90", "gre_310": "gre_310",
}

STAGE_ORDER = ["幼儿园", "小学", "初中", "高中", "高校"]


# ---------------------------------------------------------------- 文本工具

def norm_text(s):
    if not isinstance(s, str):
        return ""
    return re.sub(r"[\s　]+", "", s)


def bigrams(s):
    s = norm_text(s)
    if len(s) < 2:
        return {s} if s else set()
    return {s[i:i + 2] for i in range(len(s) - 1)}


def dice(a, b):
    if not a or not b:
        return 0.0
    inter = len(a & b)
    return 2.0 * inter / (len(a) + len(b))


def token_set(texts):
    out = set()
    for t in texts:
        out |= bigrams(t)
    return out


def clamp(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, x))


def find_matching(text, candidates):
    """在 text 中找出 candidates 里出现的词（归一化后子串匹配）。"""
    t = norm_text(text)
    return [c for c in candidates if norm_text(c) and norm_text(c) in t]


# ---------------------------------------------------------------- 数据提取

def latest_year_block(school):
    adm = school.get("admissions") or {}
    years = sorted([y for y in adm.keys() if re.match(r"^\d{4}$", str(y))], reverse=True)
    if not years:
        return None, None
    return years[0], adm[years[0]]


def year_blocks(school):
    adm = school.get("admissions") or {}
    out = {}
    for y in sorted([y for y in adm.keys() if re.match(r"^\d{4}$", str(y))]):
        out[y] = adm[y]
    return out


def user_corpus(profile):
    """用户画像的完整语料（方向 + 资产 + 实践），用于宽松包含度计算。"""
    td = profile.get("target_direction") or {}
    rd = profile.get("research_assets") or {}
    pd_ = profile.get("position_detail") or {}
    texts = [
        td.get("primary") or "", td.get("topic_interest") or "",
        " ".join(td.get("secondary") or []),
        " ".join(td.get("keywords") or []),
        " ".join(rd.get("practice_research") or []),
        " ".join(rd.get("awards") or []),
        " ".join(pd_.get("admin_scope") or []),
        pd_.get("role") or "",
    ]
    return token_set([t for t in texts if t])


def user_focus(profile):
    """用户关注点关键词集合，用于与短文本（导师研究方向、专业名称）做包含度匹配。

    中文无空格分词，用二元组会让"导师研究方向"这类短文本与长语料做 Dice 时被长度差稀释，
    导致真实匹配被低估。故短文本匹配改用"包含度"：目标文本有多少比例被用户覆盖。

    只收**短词**（关键词、方向切分片段、兴趣短语）。实践研究经历往往是很长的句子
    （"主持校本课程改革三年行动研究，含两轮前后测…"），把它放进匹配分母会拉低所有包含度，
    因此实践经历改由"招生偏好命中"通道（见 PREFERENCE_LEXICON）体现。
    """
    td = profile.get("target_direction") or {}
    out = set()
    for kw in (td.get("keywords") or []):
        k = norm_text(kw)
        if k:
            out.add(k)
    primary = norm_text(td.get("primary") or "")
    for part in re.split(r"[/／、,，\s]+", primary):
        p = norm_text(part)
        if len(p) >= 2:
            out.add(p)
    topic = norm_text(td.get("topic_interest") or "")
    for seg in re.split(r"[/／、,，与和的\s]+", topic):
        if 3 <= len(seg) <= 10:
            out.add(seg)
    return out


def practice_text(profile):
    """实践研究经历文本，单独用于偏好匹配。"""
    rd = profile.get("research_assets") or {}
    return " ".join(rd.get("practice_research") or [])


def containment(needles, haystack):
    """haystack（归一化文本）被 needles 覆盖的比例，0–1。"""
    h = norm_text(haystack)
    if not h or not needles:
        return 0.0
    hit = 0
    for n in needles:
        if n and n in h:
            hit += 1
    return hit / float(len(needles))


def specialty_fit(profile, specialty):
    """专业与用户方向的契合度：显式 fit_with_profile 优先，否则用名称做文本匹配。"""
    explicit = specialty.get("fit_with_profile")
    mapping = {"high": 90, "medium": 65, "low": 35}
    if explicit in mapping:
        return mapping[explicit], "简章/自评标注"
    focus = user_focus(profile)
    name = specialty.get("name") or ""
    hit = containment(focus, name) * 100
    if hit < 20:
        notes = norm_text(specialty.get("notes") or "")
        hit = max(hit, containment(focus, notes) * 70)
    return clamp(hit), "名称/说明文本匹配"


def advisor_match(profile, advisor, corpus):
    """导师匹配度：研究方向重合 65% + 招生偏好命中 35%。"""
    research_text = " ".join(
        (advisor.get("research") or []) + (advisor.get("recent_papers") or [])
    )
    focus = user_focus(profile)
    # 短文本（导师方向）用包含度：对每个研究方向词，判断是否落在用户关注面上
    dirs = [norm_text(d) for d in (advisor.get("research") or []) if norm_text(d)]
    if dirs:
        matched = [d for d in dirs
                   if any(f in d or d in f for f in focus)
                   or containment(focus, d) >= 0.34]
        dir_score = len(matched) / float(len(dirs)) * 100
    else:
        dir_score = 0.0
    # 长文本（近三年论文）用 Dice 补充：论文主题整体相近也是信号
    paper_score = dice(corpus, bigrams(research_text)) * 100
    dir_score = dir_score * 0.75 + min(paper_score, 60) * 0.25
    primary = norm_text((profile.get("target_direction") or {}).get("primary") or "")
    if primary and (primary in norm_text(research_text)
                    or containment(focus, research_text) >= 0.4):
        dir_score = max(dir_score, 70)
    hits = []
    pref = advisor.get("recruit_preference") or ""
    prac = practice_text(profile)
    for cat, words in PREFERENCE_LEXICON.items():
        # 类别词命中即认为该维度相关，再用具体词确认
        if not find_matching(pref, [cat]):
            continue
        if not find_matching(pref, words):
            continue
        hits.append(cat)
    pref_score = clamp(len(hits) * 26)
    # 实践经历与偏好描述的交集：导师要"有管理实绩者"而用户确有实操经历时加分
    practice_bonus = 0.0
    if prac and pref:
        prac_cats = [cat for cat, words in PREFERENCE_LEXICON.items()
                     if find_matching(prac, words) or find_matching(prac, [cat])]
        overlap = set(prac_cats) & set(hits)
        if overlap:
            practice_bonus = min(12.0, 6.0 * len(overlap))
    total = dir_score * 0.65 + pref_score * 0.35 + practice_bonus
    return clamp(total), {
        "direction_score": round(dir_score, 1),
        "preference_score": round(pref_score, 1),
        "preference_hits": hits,
        "practice_bonus": round(practice_bonus, 1),
        "practice_overlap": sorted(set(hits) & set(
            cat for cat, words in PREFERENCE_LEXICON.items()
            if find_matching(prac, words) or find_matching(prac, [cat]))),
    }


# ---------------------------------------------------------------- 硬门槛

def gate_checks(profile, school, year, block, best_advisor):
    """返回 (passed: bool, gates: list[dict])。任一 fatal 门槛失败即淘汰。"""
    cons = profile.get("constraints") or {}
    req = (block or {}).get("requirements") or {}
    gates = []

    def add(name, ok, detail, fatal=True, kind="hard"):
        gates.append({
            "name": name, "ok": bool(ok), "detail": detail,
            "fatal": fatal and not ok, "kind": kind,
        })

    # 1. 学位门槛
    deg = (profile.get("education") or {}).get("highest_degree")
    need = req.get("degree_min") or "硕士"
    order = {"学士": 1, "硕士": 2, "博士": 3}
    add("学位门槛", order.get(deg, 0) >= order.get(need, 2),
        f"本人{deg or '未知'} / 要求{need}")

    # 2. 工作年限门槛（教育博士常见 5 年硬筛）
    wmin = req.get("work_years_min")
    if wmin is None:
        add("工作年限", True, "简章未设年限要求", fatal=False, kind="soft")
    else:
        have = max((profile.get("position_detail") or {}).get("admin_years") or 0,
                   (profile.get("position_detail") or {}).get("teaching_years") or 0)
        add("工作年限", have >= wmin, f"本人教学+行政合计{have}年 / 要求{wmin}年")

    # 3. 外语门槛
    fl = cons.get("foreign_language")
    req_fl = req.get("foreign_language")
    if not req_fl:
        add("外语", True, "未设硬门槛", fatal=False, kind="soft")
    else:
        need_key = None
        for k, v in REQUIRED_LANG_BY_REQ.items():
            if k in req_fl:
                need_key = v
                break
        have_lv = FOREIGN_LANGUAGE_LEVELS.get(fl, 0)
        need_lv = FOREIGN_LANGUAGE_LEVELS.get(need_key, 0) if need_key else 0
        if need_key:
            add("外语", have_lv >= need_lv,
                f"本人{fl or '未提供'} / 要求「{req_fl}」")
        else:
            add("外语", True, f"要求「{req_fl}」需人工确认等效标准", fatal=False, kind="soft")

    # 4. 职称要求
    t = req.get("title_requirement")
    if not t:
        add("职称", True, "未设职称要求", fatal=False, kind="soft")
    else:
        title = norm_text((profile.get("position_detail") or {}).get("title") or "")
        ok = bool(title) and (norm_text(t)[:2] in title or title[:2] in norm_text(t))
        add("职称", ok, f"要求「{t}」/ 本人「{title or '未提供'}」")

    # 5. 单位同意证明
    if req.get("unit_consent_required"):
        add("单位同意报考证明", bool(cons.get("unit_support_required")),
            f"简章要求单位同意；本人可获得：{'是' if cons.get('unit_support_required') else '否'}")

    # 6. 定向 / 非定向
    if cons.get("employment_type"):
        offer = (block or {}).get("employment_type") or "未标注"
        add("就业类型", norm_text(offer).find(norm_text(cons["employment_type"])) >= 0,
            f"要求{cons['employment_type']} / 该校{offer}")

    # 7. 学习方式（脱产 vs 非全）
    if cons.get("study_mode"):
        offer = (block or {}).get("study_mode") or "未标注"
        c = norm_text(cons["study_mode"])
        ok = (c in norm_text(offer)) or (c == "非全日制" and "非全" in norm_text(offer))
        add("学习方式", ok, f"要求{cons['study_mode']} / 该校{offer}")

    # 8. 学费预算
    if cons.get("budget_total") and (block or {}).get("tuition_total"):
        ok = block["tuition_total"] <= cons["budget_total"]
        add("学费", ok, f"预算{cons['budget_total']}元 / 实际{block['tuition_total']}元")

    # 9. 学制（可按个人接受度提示，非致命）
    if cons.get("max_commute_trips") is not None:
        add("往返次数", True,
            f"上限{cons['max_commute_trips']}次，需人工核对考核安排（{block.get('exam_date') or '待定'}）",
            fatal=False, kind="soft")

    # 10. 导师是否在招
    if best_advisor is None:
        add("导师在招", False, "未获取到在招导师信息")
    else:
        spots = best_advisor.get("spots_2025")
        if spots is None:
            add("导师在招", True, "导师名单已获取，招生名额待核实", fatal=False, kind="soft")
        else:
            add("导师在招", spots > 0, f"意向导师名额 {spots} 人")

    # 11. 专项计划附加条件（若有匹配专项且有额外条件，做提示）
    for prog in (block or {}).get("special_programs") or []:
        add("专项条件", True,
            f"存在专项「{prog.get('name')}」：{prog.get('extra_requirements') or '见简章'}",
            fatal=False, kind="soft")

    passed = not any(g["fatal"] for g in gates)
    return passed, gates


# ---------------------------------------------------------------- 维度打分

def score_academic(school):
    st = school.get("strengths") or {}
    ev = st.get("discipline_eval") or {}
    grade = (ev.get("grade") or "").strip()
    if grade:
        s = EVAL_GRADE_SCORE.get(grade, EVAL_GRADE_DEFAULT)
        note = f"学科评估 {ev.get('year', '')} {grade}"
    else:
        s = EVAL_GRADE_DEFAULT
        note = "无目标学科评估等级，按中位计分"
    rk = st.get("subject_ranking") or {}
    rank = rk.get("rank")
    rk_score = 0
    if rank:
        rk_score = clamp(100 - (rank - 1) * 6.5)
        note += f"；{rk.get('system', '')}排名 {rank}"
    dfc = st.get("dr_double_first_class") or []
    total = s * 0.62 + rk_score * 0.30 + (8 if dfc else 0)
    return clamp(total), {
        "eval_grade": grade, "eval_score": s, "rank": rank,
        "rank_score": round(rk_score, 1), "double_first_class": dfc,
        "note": note,
    }


def score_competitiveness(school, block):
    plan = block.get("plan_total")
    applied = block.get("applied")
    enrolled = block.get("enrolled")
    detail = {}
    score = 45.0
    ratio = None
    if applied and enrolled:
        ratio = applied / float(enrolled)
        for lim, sc in RATIO_BREAKPOINTS:
            if ratio <= lim:
                score = sc
                break
        detail["ratio"] = round(ratio, 2)
        detail["applied"] = applied
        detail["enrolled"] = enrolled
    if plan and enrolled:
        fill = enrolled / float(plan)
        detail["plan_fill"] = round(fill, 2)
        # 计划完成率低 → 存在隐性竞争或推免/调剂占用，适度扣分
        score = score - max(0, (0.9 - fill)) * 40
        detail["plan_total"] = plan
    score = clamp(score)
    if ratio:
        tone = "，竞争激烈" if ratio >= 8 else "，竞争相对温和"
        detail["note"] = f"报录比 {ratio:.1f}:1{tone}"
    else:
        detail["note"] = "缺报考/录取数据，按中性处理"
    return score, detail


def score_timing(school, block, profile):
    cons = profile.get("constraints") or {}
    target_years = cons.get("target_years") or []
    year = str(block.get("_year") or "")
    detail = {}
    score = 70.0
    if target_years and year and year not in target_years:
        # 招生简章通常在上一年秋季发布，采到上一年数据是常态，不应重罚；
        # 只有当数据年份明显早于目标年度时，才提示信息过期。
        try:
            gap = min(int(y) for y in target_years) - int(year)
        except Exception:
            gap = 1
        if gap >= 2:
            score -= 18
            detail["warning"] = f"数据年度 {year} 早于目标年度 {target_years}，信息可能已过期"
        else:
            detail["warning"] = (f"数据年度 {year} 为上一周期（目标 {target_years}），"
                                 f"本轮简章通常在上一年秋季发布，需按当年文件复核")
    dates = []
    for k in ("announcement_date", "signup_start", "signup_end", "exam_date"):
        if block.get(k):
            dates.append((k, block[k]))
    detail["timeline"] = dict(dates)
    # 考核到报名截止的缓冲过短则提示
    if block.get("signup_end") and block.get("exam_date"):
        try:
            from datetime import date
            s = date(*map(int, str(block["signup_end"]).split("-")))
            e = date(*map(int, str(block["exam_date"]).split("-")))
            buf = (e - s).days
            detail["buffer_days"] = buf
            if buf < 45:
                score -= 10
                detail["warning"] = (detail.get("warning", "") +
                                     f"；材料准备窗口仅 {buf} 天，需提前启动")
        except Exception:
            pass
    cities = cons.get("target_cities") or []
    city = school.get("city") or ""
    province = school.get("province") or ""
    if cities and city:
        # 偏好城市列表里可能写省份（如"安徽"），学校落在该省任一城市即算命中
        hit = city in cities or (province and province in cities)
        if not hit:
            score -= 12
            detail["city_warning"] = f"城市 {city}（{province or '省份未填'}）不在偏好范围 {cities} 内"
    return clamp(score), detail


def score_cultivation(school, block, profile):
    """培养契合度。基准 55 分，各项加分后封顶 100——基准偏低以拉开区分度，
    避免所有院校都因"有实践要求 + 有课程 + 有论文"而顶格。"""
    g = block.get("graduation") or {}
    cons = profile.get("constraints") or {}
    detail = {}
    score = 55.0
    if g.get("practice_requirement"):
        score += 14
        detail["practice"] = g["practice_requirement"]
    if g.get("coursework"):
        detail["coursework_count"] = len(g["coursework"])
        score += 4 if len(g["coursework"]) >= 2 else 2
    if g.get("publications"):
        detail["publications"] = g["publications"]
        # 毕业成果要求越严苛，对在职考生的额外负担越重
        pubs = g["publications"]
        if "CSSCI" in pubs or "核心" in pubs:
            score -= 6
            detail["publications_burden"] = "有核心期刊发表硬要求，需确认本人产出节奏"
    if g.get("thesis"):
        score += 5
    if cons.get("study_mode") == "非全日制" and (block.get("study_mode") or "").find("非全") >= 0:
        score += 10
        detail["in_service_friendly"] = True
    dur = block.get("duration_years")
    if dur:
        detail["duration_years"] = dur
        if dur and dur <= 3:
            score += 6
    return clamp(score), detail


# ---------------------------------------------------------------- 主流程

def build_candidate(profile, school):
    year, block = latest_year_block(school)
    if block is None:
        return None
    block = dict(block)
    block["_year"] = year
    corpus = user_corpus(profile)

    specs = school.get("specialties_offered") or []
    if not specs:
        specs = [{"name": "未标注专业", "fit_with_profile": None}]

    spec_scores = []
    for sp in specs:
        fs, basis = specialty_fit(profile, sp)
        spec_scores.append((fs, sp, basis))
    spec_scores.sort(key=lambda x: x[0], reverse=True)
    top_spec_score, top_spec, spec_basis = spec_scores[0]

    advisors = block.get("advisors") or []
    adv_details = []
    for adv in advisors:
        m, info = advisor_match(profile, adv, corpus)
        adv_details.append({"advisor": adv, "match": m, "detail": info})
    adv_details.sort(key=lambda x: x["match"], reverse=True)
    best = adv_details[0] if adv_details else None

    passed, gates = gate_checks(profile, school, year, block, best["advisor"] if best else None)

    dir_score = top_spec_score
    adv_score = best["match"] if best else 0.0
    aca_score, aca_detail = score_academic(school)
    comp_score, comp_detail = score_competitiveness(school, block)
    time_score, time_detail = score_timing(school, block, profile)
    cult_score, cult_detail = score_cultivation(school, block, profile)

    weights = POSITION_WEIGHTS.get(
        (profile.get("position_category") or "").strip(),
        DEFAULT_WEIGHTS,
    )
    dims = {
        "方向匹配": dir_score,
        "导师匹配": adv_score,
        "录取概率": comp_score,
        "学术实力": aca_score,
        "培养契合": cult_score,
        "时间成本": time_score,
    }
    total = sum(dims[k] * weights.get(k, 0) for k in dims)
    total = clamp(total)

    # ---- 理由生成
    reasons = []
    if top_spec_score >= 70:
        reasons.append(
            f"专业「{top_spec.get('name')}」与你的方向（{profile.get('target_direction', {}).get('primary')}）"
            f"直接对口（契合度 {top_spec_score:.0f}，依据：{spec_basis}）")
    elif best and best["detail"]["preference_hits"]:
        reasons.append(
            f"意向导师在招生偏好上命中：{'、'.join(best['detail']['preference_hits'])}，"
            f"你的{'、'.join((profile.get('research_assets') or {}).get('practice_research') or []) or '实践经历'}与之一致")
    if aca_detail.get("eval_grade"):
        reasons.append(f"学术实力硬指标：{aca_detail['note']}")
    else:
        reasons.append("学术实力缺少目标学科评估等级支撑，排名为参考项，报考时需自证方向价值")
    if comp_detail.get("ratio"):
        reasons.append(f"录取概率：报录比约 {comp_detail['ratio']}:1，{comp_detail.get('note', '')}")
    if comp_detail.get("plan_fill") is not None:
        reasons.append(f"计划完成率 {comp_detail['plan_fill']:.0%}"
                       f"（计划 {comp_detail.get('plan_total')} / 实际录取 {comp_detail.get('enrolled')}），"
                       f"差额可由推免占用或方向调剂解释")
    if cult_detail.get("practice"):
        reasons.append(f"培养方案含实践环节：{cult_detail['practice']}，与在职身份相容")
    if time_detail.get("warning"):
        reasons.append(f"时间节点需注意：{time_detail['warning']}")
    soft_warn = [g for g in gates if not g["ok"] and g["kind"] == "soft"]
    if soft_warn:
        reasons.append("待人工确认：" + "；".join(f"{g['name']}（{g['detail']}）" for g in soft_warn))
    if not reasons:
        reasons.append("信息不完整，建议先补齐该校的招生简章与在招导师信息再做判断")

    # 五年趋势
    trend = []
    for y, b in year_blocks(school).items():
        trend.append({
            "year": y,
            "plan": b.get("plan_total"),
            "applied": b.get("applied"),
            "enrolled": b.get("enrolled"),
            "ratio": round(b["applied"] / float(b["enrolled"]), 2) if b.get("applied") and b.get("enrolled") else None,
        })
    trend.sort(key=lambda x: x["year"])

    return {
        "school_id": school.get("id"),
        "school": school.get("name"),
        "city": school.get("city"),
        "tier": school.get("tier_label"),
        "year_used": year,
        "passed_gates": passed,
        "total": round(total, 2),
        "weights": weights,
        "dimensions": {k: round(v, 2) for k, v in dims.items()},
        "top_specialty": top_spec,
        "specialty_candidates": [
            {"name": s.get("name"), "type": s.get("type"), "fit": round(sc, 1)}
            for sc, s, _ in spec_scores
        ],
        "advisor_ranking": [
            {
                "name": a["advisor"].get("name"),
                "title": a["advisor"].get("title"),
                "research": a["advisor"].get("research"),
                "recent_papers": a["advisor"].get("recent_papers"),
                "recruit_preference": a["advisor"].get("recruit_preference"),
                "student_background": a["advisor"].get("student_background"),
                "spots": a["advisor"].get("spots_2025"),
                "match": round(a["match"], 1),
                **a["detail"],
            }
            for a in adv_details
        ],
        "academic": aca_detail,
        "competitiveness": comp_detail,
        "timing": time_detail,
        "cultivation": cult_detail,
        "gates": gates,
        "reasons": reasons,
        "five_year_trend": trend,
        "data_gaps": school.get("data_gaps") or [],
        "source": {
            "url": block.get("source_url"),
            "type": block.get("source_type"),
            "retrieved_at": block.get("retrieved_at"),
            "verification_level": block.get("verification_level"),
        },
    }


def score_dataset(data, weight_override=None):
    profile = data.get("profile") or {}
    schools = data.get("schools") or []
    weights = dict(POSITION_WEIGHTS.get(
        (profile.get("position_category") or "").strip(), DEFAULT_WEIGHTS))
    if weight_override:
        weights.update(weight_override)

    results = []
    for sch in schools:
        c = build_candidate(profile, sch)
        if c is None:
            results.append({
                "school_id": sch.get("id"), "school": sch.get("name"),
                "passed_gates": False, "total": 0.0,
                "error": "缺少 admissions 数据，无法评分",
            })
            continue
        # 用最终权重重算总分
        dims = c["dimensions"]
        c["weights"] = weights
        c["total"] = round(sum(dims[k] * weights.get(k, 0) for k in dims), 2)
        results.append(c)

    passed = sorted([r for r in results if r.get("passed_gates")],
                    key=lambda r: r["total"], reverse=True)
    failed = sorted([r for r in results if not r.get("passed_gates")],
                    key=lambda r: r.get("school") or "")
    for i, r in enumerate(passed):
        r["rank"] = i + 1
    return {"profile": profile, "weights": weights,
            "passed": passed, "failed": failed, "all": results}


# ---------------------------------------------------------------- 输出

def to_markdown(scores):
    L = []
    L.append("# 择校优先级排序（机器初评）\n")
    L.append("> 本表为工具初评结果，硬门槛由数据判定，理由需人工复核后定稿。\n")
    L.append("\n## 通过硬门槛的候选（按总分降序）\n")
    L.append("| 优先级 | 院校 | 专业 | 总分 | 方向 | 导师 | 概率 | 实力 | 培养 | 时间 | 关键理由 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for r in scores["passed"]:
        d = r["dimensions"]
        reason = r["reasons"][0] if r["reasons"] else ""
        L.append("| {rank} | {school} | {spec} | {total} | {a} | {b} | {c} | {e} | {f} | {g} | {reason} |".format(
            rank=r["rank"], school=r["school"],
            spec=(r.get("top_specialty") or {}).get("name", "-"),
            total=r["total"], a=d["方向匹配"], b=d["导师匹配"], c=d["录取概率"],
            e=d["学术实力"], f=d["培养契合"], g=d["时间成本"], reason=reason))
    L.append("\n## 未通过硬门槛（需人工复核或补充信息）\n")
    if not scores["failed"]:
        L.append("无。")
    else:
        for r in scores["failed"]:
            fatals = [g for g in r.get("gates", []) if g.get("fatal")]
            if fatals:
                msg = "；".join(f"{g['name']}：{g['detail']}" for g in fatals)
            else:
                msg = r.get("error", "信息不足")
            L.append(f"- **{r['school']}** — {msg}")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="教育专业博士择校匹配打分")
    ap.add_argument("dataset", help="数据集 JSON 路径")
    ap.add_argument("--out", help="打分结果 JSON 输出路径")
    ap.add_argument("--csv", help="优先级 CSV 输出路径")
    ap.add_argument("--weights", help="权重覆盖 JSON，如 '{\"方向匹配\":0.35}'")
    args = ap.parse_args()

    with open(args.dataset, encoding="utf-8") as f:
        data = json.load(f)
    override = json.loads(args.weights) if args.weights else None
    scores = score_dataset(data, override)

    md = to_markdown(scores)
    print(md)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(scores, f, ensure_ascii=False, indent=2)
    if args.csv:
        with open(args.csv, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["优先级", "院校", "城市", "层次", "专业", "总分",
                        "方向匹配", "导师匹配", "录取概率", "学术实力", "培养契合", "时间成本",
                        "报录比", "计划完成率", "首选导师", "导师匹配分", "关键理由"])
            for r in scores["passed"]:
                d = r["dimensions"]
                comp = r.get("competitiveness") or {}
                best = (r.get("advisor_ranking") or [{}])[0]
                w.writerow([
                    r["rank"], r["school"], r.get("city"), r.get("tier"),
                    (r.get("top_specialty") or {}).get("name"), r["total"],
                    d["方向匹配"], d["导师匹配"], d["录取概率"], d["学术实力"],
                    d["培养契合"], d["时间成本"],
                    comp.get("ratio", ""), comp.get("plan_fill", ""),
                    best.get("name", ""), best.get("match", ""),
                    " | ".join(r.get("reasons", [])[:3]),
                ])
    return 0


if __name__ == "__main__":
    sys.exit(main())
