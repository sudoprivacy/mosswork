#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""用户背景信息采集器（输入环节）。

两种用法：
  1) 交互式：python3 intake.py  -> 逐题询问，生成 profile.json
  2) 非交互：python3 intake.py --preset k12_admin --out profile.json
     直接生成带默认值的画像骨架，交由用户在工作区里填写。

只收集与"择校决策"直接相关的字段，不收集与申请无关的个人信息。
"""

import argparse
import json
import os
import sys

POSITION_PRESETS = {
    "kindergarten_admin": {
        "label": "幼儿园园长 / 保教主任 / 教研组长",
        "school_stage": "kindergarten",
        "school_type": "公办 / 民办 / 普惠",
        "role": "园长 / 保教主任 / 教研组长 / 副园长",
        "admin_years": 5,
        "teaching_years": 6,
        "grade_span": "幼儿园",
        "admin_scope": ["园本课程开发", "保教质量管理", "教师专业发展", "办园行为规范"],
        "achievements": [],
        "target_direction": {
            "primary": "学前教育 / 幼儿园教育管理",
            "secondary": ["课程与教学", "教师发展", "教育管理"],
            "topic_interest": "幼儿园园本课程建设与保教队伍专业发展",
            "keywords": ["园本课程", "学前教育", "保教管理", "幼儿园管理", "游戏化课程"],
        },
    },
    "k12_admin": {
        "label": "中小学教务 / 德育 / 教科室 / 校级管理者",
        "school_stage": "middle",
        "school_type": "公办",
        "role": "德育处主任 / 教科室主任 / 教务副校长",
        "admin_years": 5,
        "teaching_years": 8,
        "grade_span": "初中",
        "admin_scope": ["课程管理", "教师发展", "德育与班级管理"],
        "achievements": [],
        "target_direction": {
            "primary": "课程与教学管理 / 教育领导与管理",
            "secondary": ["教师发展", "学校治理", "德育管理"],
            "topic_interest": "学校课程领导力与教师专业发展的学校场域落地",
            "keywords": ["课程领导", "教师专业发展", "校本课程", "学校改进", "课程管理"],
        },
    },
    "higher_ed_admin": {
        "label": "高校教务 / 学工 / 院系行政管理 / 高校教师",
        "school_stage": "higher_ed",
        "school_type": "公办",
        "role": "教务处长 / 学院副书记 / 系主任 / 副教授",
        "admin_years": 6,
        "teaching_years": 9,
        "grade_span": "高校",
        "admin_scope": ["教学管理", "教师发展", "学生发展", "院系治理"],
        "achievements": [],
        "target_direction": {
            "primary": "高等教育管理 / 教育领导与管理",
            "secondary": ["教师发展", "课程与教学", "教育经济与管理"],
            "topic_interest": "高校教学治理与教师教学发展机制",
            "keywords": ["高等教育", "教学管理", "教师发展", "院系治理", "课程建设"],
        },
    },
}

QUESTIONS = [
    ("position_category", "岗位类别（kindergarten_admin / k12_admin / higher_ed_admin）", "k12_admin"),
    ("role", "现任岗位名称", "教务副校长"),
    ("admin_years", "教育管理岗位年限（整数）", "6"),
    ("teaching_years", "一线教学年限（整数）", "9"),
    ("school_stage", "所在学段（幼儿园 / 小学 / 初中 / 高中 / 高校）", "初中"),
    ("school_type", "学校性质（公办 / 民办 / 普惠）", "公办"),
    ("highest_degree", "最高学历（学士 / 硕士 / 博士）", "硕士"),
    ("degree_field", "所学专业", "教育学（课程与教学论）"),
    ("degree_year", "毕业年份", "2016"),
    ("master_thesis", "硕士论文题目（用于判断研究方向延续性）", ""),
    ("papers_published", "已发表论文数（整数）", "3"),
    ("papers_first_author", "其中第一作者/通讯作者数", "2"),
    ("projects_principal", "主持课题数", "1"),
    ("projects_participate", "参与课题数", "4"),
    ("awards", "获奖（顿号或逗号分隔，可留空）", "区级优秀论文一等奖"),
    ("practice_research", "实践研究经历（顿号分隔，重要，直接决定导师匹配分）", "主持校本课程改革三年行动研究，含两轮前后测"),
    ("data_skills", "研究方法能力（顿号分隔）", "问卷设计、课堂观察、行动研究"),
    ("primary_direction", "主攻方向", ""),
    ("secondary_directions", "次要方向（顿号分隔）", ""),
    ("topic_interest", "最想做的研究问题", ""),
    ("keywords", "关键词（顿号分隔，建议 5 个）", ""),
    ("foreign_language", "外语水平（none / cet4_425 / cet6_425 / cet6_500 / ielts_65 / toefl_90 / gre_310）", "cet6_425"),
    ("title", "职称（无则填 无）", "一级教师"),
    ("unit_support", "单位能否出具同意报考证明（yes / no）", "yes"),
    ("study_mode", "可接受的学习方式（非全日制 / 全日制 / 均可）", "非全日制"),
    ("employment_type", "可接受的就业类型（定向 / 非定向 / 均可）", "定向"),
    ("budget_total", "学费总预算（元，填 0 表示不限）", "100000"),
    ("max_commute_trips", "备考期间可接受的异地往返次数", "3"),
    ("target_years", "目标招生年度（顿号分隔）", "2026、2027"),
    ("target_cities", "偏好城市（顿号分隔）", "上海、江苏、浙江"),
    ("exclude", "明确排除项（顿号分隔）", "需要全日制脱产"),
    ("candidate_schools", "已知候选院校（顿号分隔，可留空由工具扩展）", ""),
]


def build_profile(answers):
    pos = POSITION_PRESETS.get(answers.get("position_category", "k12_admin"), POSITION_PRESETS["k12_admin"])
    def num(k, d):
        try:
            return int(str(answers.get(k, d)).strip())
        except Exception:
            return d
    def split(k):
        return [x.strip() for x in str(answers.get(k, "")).replace(",", "、").split("、") if x.strip()]

    profile = {
        "candidate_id": answers.get("candidate_id", "P001"),
        "position_category": answers.get("position_category", "k12_admin"),
        "position_detail": {
            "school_stage": answers.get("school_stage") or pos["school_stage"],
            "school_type": answers.get("school_type") or pos["school_type"],
            "role": answers.get("role") or pos["role"],
            "title": answers.get("title") or "无",
            "admin_years": num("admin_years", pos["admin_years"]),
            "teaching_years": num("teaching_years", pos["teaching_years"]),
            "grade_span": answers.get("school_stage") or pos["grade_span"],
            "admin_scope": pos["admin_scope"],
            "achievements": split("awards"),
        },
        "education": {
            "highest_degree": answers.get("highest_degree", "硕士"),
            "degree_field": answers.get("degree_field", ""),
            "degree_year": num("degree_year", 2016),
            "degree_mode": "全日制",
            "master_thesis": answers.get("master_thesis", ""),
        },
        "research_assets": {
            "papers_published": num("papers_published", 0),
            "papers_first_author": num("papers_first_author", 0),
            "journals": [],
            "projects_principal": num("projects_principal", 0),
            "projects_participate": num("projects_participate", 0),
            "awards": split("awards"),
            "practice_research": split("practice_research"),
            "data_skills": split("data_skills"),
        },
        "target_direction": {
            "primary": answers.get("primary_direction") or pos["target_direction"]["primary"],
            "secondary": split("secondary_directions") or pos["target_direction"]["secondary"],
            "topic_interest": answers.get("topic_interest") or pos["target_direction"]["topic_interest"],
            "keywords": split("keywords") or pos["target_direction"]["keywords"],
        },
        "constraints": {
            "work_years_for_edd": num("admin_years", 0),
            "title_required": "一级及以上高级职称",
            "foreign_language": answers.get("foreign_language", "none"),
            "unit_support_required": str(answers.get("unit_support", "yes")).lower() == "yes",
            "study_mode": answers.get("study_mode", "非全日制"),
            "employment_type": answers.get("employment_type", "定向"),
            "budget_total": num("budget_total", 0) or None,
            "max_commute_trips": num("max_commute_trips", 3),
            "target_years": split("target_years"),
            "target_cities": split("target_cities"),
            "exclude": split("exclude"),
        },
        "_candidate_pool": split("candidate_schools"),
    }
    return profile


def interactive():
    ans = {}
    print("=== 教育专业博士择校 · 背景信息采集 ===")
    print("提示：直接回车使用推荐值；不适用的填“无”。\n")
    for key, label, default in QUESTIONS:
        raw = input(f"{label}\n  (默认 {default or '空'}) > ").strip()
        ans[key] = raw if raw else default
    return build_profile(ans)


def non_interactive(preset):
    base = {
        "position_category": preset,
        "role": POSITION_PRESETS[preset]["role"],
        "school_stage": POSITION_PRESETS[preset]["school_stage"],
        "admin_years": POSITION_PRESETS[preset]["admin_years"],
        "teaching_years": POSITION_PRESETS[preset]["teaching_years"],
        "primary_direction": POSITION_PRESETS[preset]["target_direction"]["primary"],
        "keywords": "、".join(POSITION_PRESETS[preset]["target_direction"]["keywords"]),
        "topic_interest": POSITION_PRESETS[preset]["target_direction"]["topic_interest"],
        "secondary_directions": "、".join(POSITION_PRESETS[preset]["target_direction"]["secondary"]),
        "highest_degree": "硕士",
        "degree_field": "教育学",
        "degree_year": "2016",
        "papers_published": "3",
        "papers_first_author": "2",
        "projects_principal": "1",
        "projects_participate": "4",
        "awards": "",
        "practice_research": "主持校本课程改革行动研究",
        "data_skills": "问卷设计、课堂观察",
        "foreign_language": "cet6_425",
        "title": "一级教师",
        "unit_support": "yes",
        "study_mode": "非全日制",
        "employment_type": "定向",
        "budget_total": "100000",
        "max_commute_trips": "3",
        "target_years": "2026、2027",
        "target_cities": "上海、江苏、浙江",
        "exclude": "需要全日制脱产",
        "candidate_schools": "",
    }
    return build_profile(base)


def main():
    ap = argparse.ArgumentParser(description="教育专业博士择校 · 用户背景采集")
    ap.add_argument("--preset", choices=list(POSITION_PRESETS),
                    help="非交互模式：使用岗位预置生成画像骨架")
    ap.add_argument("--out", default="profile.json", help="输出路径")
    ap.add_argument("--list-presets", action="store_true", help="列出岗位预置")
    args = ap.parse_args()

    if args.list_presets:
        for k, v in POSITION_PRESETS.items():
            print(f"{k:22s} {v['label']}")
        return 0

    if sys.stdin.isatty() and not args.preset:
        profile = interactive()
    else:
        profile = non_interactive(args.preset or "k12_admin")

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    print(f"画像已写入 {args.out}")
    print("下一步：用此画像填充 dataset.json 的 profile 字段，再运行 score_schools.py。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
