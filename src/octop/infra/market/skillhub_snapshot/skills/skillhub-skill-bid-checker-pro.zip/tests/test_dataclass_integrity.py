#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v9.0.6 守护测试：验证 @dataclass 类的字段没有被 logger import 块吞掉

防止 print→logger 批量替换脚本再次把 logger 块错误插入到类体内。
"""

import ast
import os
import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def _scan_dataclass_classes(filepath: Path):
    """扫描文件中所有 @dataclass 类，返回 [(class_name, has_dataclass, top_field_count, has_try_in_body)]"""
    if not filepath.exists():
        return []

    with open(filepath, 'r', encoding='utf-8') as f:
        try:
            tree = ast.parse(f.read())
        except SyntaxError:
            return []

    results = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        has_dataclass = any(
            (isinstance(d, ast.Name) and d.id == 'dataclass') or
            (isinstance(d, ast.Attribute) and d.attr == 'dataclass')
            for d in node.decorator_list
        )
        if not has_dataclass:
            continue
        top_fields = [n for n in node.body if isinstance(n, ast.AnnAssign)]
        has_try_in_body = any(isinstance(n, ast.Try) for n in node.body)
        results.append((node.name, has_dataclass, len(top_fields), has_try_in_body))
    return results


class TestDataclassIntegrity(unittest.TestCase):
    """验证所有 @dataclass 类的字段完整性"""

    def test_material_section_has_fields(self):
        """MaterialSection 类必须有 ≥10 个顶层字段（v9.0.6 修复后的状态）"""
        results = _scan_dataclass_classes(PROJECT_ROOT / "scripts" / "material_deep_scanner.py")
        ms = [r for r in results if r[0] == 'MaterialSection']
        self.assertEqual(len(ms), 1, "应有 1 个 MaterialSection 类")
        name, has_dc, field_count, has_try = ms[0]
        self.assertTrue(has_dc, "MaterialSection 必须有 @dataclass 装饰器")
        self.assertGreaterEqual(field_count, 10,
            f"MaterialSection 顶层字段数={field_count}，应 ≥10（logger 块吞掉字段会导致 0）")
        self.assertFalse(has_try,
            "MaterialSection 类体内不应有 try 块（logger import 应在类外）")

    def test_map_result_has_fields(self):
        """MapResult 类必须有 ≥10 个顶层字段"""
        results = _scan_dataclass_classes(PROJECT_ROOT / "requirement_mapper.py")
        mr = [r for r in results if r[0] == 'MapResult']
        self.assertEqual(len(mr), 1, "应有 1 个 MapResult 类")
        name, has_dc, field_count, has_try = mr[0]
        self.assertTrue(has_dc, "MapResult 必须有 @dataclass 装饰器")
        self.assertGreaterEqual(field_count, 10,
            f"MapResult 顶层字段数={field_count}，应 ≥10（logger 块吞掉字段会导致 0）")
        self.assertFalse(has_try,
            "MapResult 类体内不应有 try 块（logger import 应在类外）")

    def test_template_requirement_has_fields(self):
        """TemplateRequirement 类必须有 ≥5 个顶层字段"""
        results = _scan_dataclass_classes(PROJECT_ROOT / "requirement_mapper.py")
        tr = [r for r in results if r[0] == 'TemplateRequirement']
        self.assertEqual(len(tr), 1)
        name, has_dc, field_count, has_try = tr[0]
        self.assertTrue(has_dc)
        self.assertGreaterEqual(field_count, 5)
        self.assertFalse(has_try)

    def test_material_file_report_has_fields(self):
        """MaterialFileReport 类必须有 ≥5 个顶层字段"""
        results = _scan_dataclass_classes(PROJECT_ROOT / "scripts" / "material_deep_scanner.py")
        mfr = [r for r in results if r[0] == 'MaterialFileReport']
        self.assertEqual(len(mfr), 1)
        name, has_dc, field_count, has_try = mfr[0]
        self.assertTrue(has_dc)
        self.assertGreaterEqual(field_count, 5)
        self.assertFalse(has_try)

    def test_image_info_has_fields(self):
        """ImageInfo 类必须有 ≥3 个顶层字段"""
        results = _scan_dataclass_classes(PROJECT_ROOT / "scripts" / "material_deep_scanner.py")
        ii = [r for r in results if r[0] == 'ImageInfo']
        self.assertEqual(len(ii), 1)
        name, has_dc, field_count, has_try = ii[0]
        self.assertTrue(has_dc)
        self.assertGreaterEqual(field_count, 3)
        self.assertFalse(has_try)


class TestDataclassInstantiation(unittest.TestCase):
    """验证 @dataclass 类能正常实例化（接收关键字参数）"""

    def test_material_section_instantiation(self):
        """MaterialSection 必须能接收 section_id 等关键字参数"""
        sys.path.insert(0, str(PROJECT_ROOT / "scripts"))
        from material_deep_scanner import MaterialSection
        ms = MaterialSection(
            section_id=1, heading="测试", heading_para_index=0,
            para_start=0, para_end=1, content_type="text_only"
        )
        self.assertEqual(ms.section_id, 1)
        self.assertEqual(ms.heading, "测试")
        self.assertEqual(ms.content_type, "text_only")

    def test_map_result_instantiation(self):
        """MapResult 必须能接收 req_id 等关键字参数"""
        sys.path.insert(0, str(PROJECT_ROOT))
        from requirement_mapper import MapResult
        mr = MapResult(req_id="test_req", status="matched", fill_strategy="insert_images")
        self.assertEqual(mr.req_id, "test_req")
        self.assertEqual(mr.status, "matched")
        self.assertEqual(mr.fill_strategy, "insert_images")


class TestMaterialDeepScannerSysImport(unittest.TestCase):
    """v9.0.6: 验证 material_deep_scanner.py 顶部有 import sys"""

    def test_sys_imported(self):
        fpath = PROJECT_ROOT / "scripts" / "material_deep_scanner.py"
        with open(fpath, 'r', encoding='utf-8') as f:
            tree = ast.parse(f.read())
        # 找顶层 import sys
        has_sys = False
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == 'sys':
                        has_sys = True
                        break
            elif isinstance(node, ast.ImportFrom):
                if node.module == 'sys':
                    has_sys = True
        self.assertTrue(has_sys, "material_deep_scanner.py 必须在顶部 import sys")


if __name__ == "__main__":
    unittest.main()
