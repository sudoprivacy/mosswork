#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 OCR 引擎的无 API 配置行为 (v11)

验证：
  - 模块不再提供任何云端 OCR 凭证加载函数（无 API 模式）
  - create_ocr_engine 不依赖任何环境变量/密钥，优雅返回引擎或 None
    （测试中以 mock 替代 RapidOCRBackend，避免触发真实联网安装）
"""

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 让 ocr_engine 能导入
sys.path.insert(0, str(PROJECT_ROOT))

from bid_checker.core import ocr_engine
from bid_checker.core.ocr_engine import create_ocr_engine


class TestNoBaiduCredentials(unittest.TestCase):
    """确认不再存在任何百度 OCR 凭证加载逻辑"""

    def test_no_baidu_symbols(self):
        for symbol in ("_load_baidu_credentials", "_has_baidu_config",
                       "ENV_BAIDU_API_KEY", "ENV_BAIDU_SECRET_KEY", "BaiduOCR"):
            self.assertFalse(hasattr(ocr_engine, symbol),
                             f"不应再存在百度 OCR 符号: {symbol}")

    def test_no_baidu_env_vars_consumed(self):
        # 即使设置了历史百度环境变量，也不应影响引擎初始化（无读取路径）
        os.environ.pop("BAIDU_OCR_API_KEY", None)
        os.environ.pop("BAIDU_OCR_SECRET_KEY", None)
        os.environ["BAIDU_OCR_API_KEY"] = "should_be_ignored"
        os.environ["BAIDU_OCR_SECRET_KEY"] = "should_be_ignored"
        try:
            with patch('bid_checker.core.ocr_engine.RapidOCRBackend') as mock_backend:
                mock_instance = MagicMock()
                mock_instance._engine = None  # 模拟 RapidOCR 不可用
                mock_backend.return_value = mock_instance
                # 不应读取这些变量；工厂函数优雅返回 None，不抛异常、不联网
                engine = create_ocr_engine("/nonexistent/config.json", verbose=False)
                self.assertIsNone(engine)
        finally:
            os.environ.pop("BAIDU_OCR_API_KEY", None)
            os.environ.pop("BAIDU_OCR_SECRET_KEY", None)


if __name__ == "__main__":
    unittest.main()
