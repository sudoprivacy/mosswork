#!/usr/bin/env python3
"""
bid-checker-pro v1.1.0 新增模块行为契约测试
测试价格分检查和抄袭检测的 5 项/5 维度检查
"""
import sys
import os
import json
import tempfile
from pathlib import Path
from docx import Document

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))
sys.path.insert(0, str(SKILL_DIR / 'scripts'))


def test_cn_amount_parsing():
    """测试 1: 大写金额解析"""
    from bid_checker.core.extract_amounts import cn_amount_to_number

    assert cn_amount_to_number('壹佰贰拾万元整') == 1200000
    assert cn_amount_to_number('叁亿伍仟万元整') == 350000000
    assert cn_amount_to_number('贰拾万元整') == 200000
    assert cn_amount_to_number('玖仟玖佰玖拾玖元整') == 9999
    print('✅ test_cn_amount_parsing 通过')


def test_num_amount_parsing():
    """测试 2: 小写金额解析"""
    from bid_checker.core.extract_amounts import num_amount_to_value

    assert num_amount_to_value('1,200,000元') == 1200000
    assert num_amount_to_value('120万元') == 1200000
    assert num_amount_to_value('3.5亿元') == 350000000
    assert num_amount_to_value('¥120') == 120
    print('✅ test_num_amount_parsing 通过')


def test_cn_amount_validity():
    """测试 3: 大写金额合规性检查"""
    from bid_checker.core.extract_amounts import check_cn_amount_validity

    is_valid, _ = check_cn_amount_validity('壹佰贰拾万元整')
    assert is_valid is True

    is_valid, reason = check_cn_amount_validity('一百二十万元整')
    assert is_valid is False, f'一百二十万 应判为不合规: {reason}'

    is_valid, reason = check_cn_amount_validity('壹佰贰拾万')
    assert is_valid is False, f'不以元整结尾 应判为不合规: {reason}'

    print('✅ test_cn_amount_validity 通过')


def test_text_similarity():
    """测试 4: 文本相似度计算"""
    from bid_checker.core.text_similarity import text_similarity

    t1 = '本方案采用微服务架构，将系统拆分为多个独立服务'
    t2 = '本方案采用微服务架构，将系统拆分为多个独立服务模块'
    t3 = '本系统使用单体架构，所有功能模块集中部署'

    sim12 = text_similarity(t1, t2)
    sim13 = text_similarity(t1, t3)

    assert sim12 > 0.5, f'高度相似应 >50%, 实际 {sim12:.0%}'
    assert sim13 < 0.3, f'不同内容应 <30%, 实际 {sim13:.0%}'
    print(f'✅ test_text_similarity 通过 (sim12={sim12:.0%}, sim13={sim13:.0%})')


def test_self_duplicate_detection():
    """测试 5: 跨章节自重复检测"""
    from bid_checker.core.text_similarity import split_into_paragraphs, find_similar_paragraph_pairs

    text1 = '本方案采用微服务架构进行系统设计，将整体业务功能拆分为多个独立服务模块。每个服务模块负责特定的业务领域，通过 API 网关统一对外提供服务。'
    text2 = '本方案采用微服务架构进行系统设计，将整体业务功能拆分为多个独立服务模块。每个服务模块负责特定的业务领域，通过 API 网关统一对外提供服务。'

    paragraphs = split_into_paragraphs(text1, min_length=20, location_prefix='章节1')
    paragraphs += split_into_paragraphs(text2, min_length=20, location_prefix='章节2')

    pairs = find_similar_paragraph_pairs(paragraphs, threshold=0.5, skip_adjacent=False)
    assert len(pairs) > 0, '应找到重复段落'
    assert pairs[0][2] >= 0.9, f'相同段落相似度应 ≥90%, 实际 {pairs[0][2]:.0%}'
    print(f'✅ test_self_duplicate_detection 通过 (相似度 {pairs[0][2]:.0%})')


def test_price_check_runs():
    """测试 6: 价格检查端到端运行"""
    from check_price_consistency import (
        check_cn_amount_validity_in_doc, check_size_consistency,
        check_cross_location_consistency
    )
    from bid_checker.core.extract_amounts import Amount

    amounts_by_location = {
        '投标函': [
            Amount(raw='壹佰贰拾万元整', value=1200000, position=0,
                  location_hint='投标函', amount_type='cn_upper'),
            Amount(raw='1,250,000元', value=1250000, position=20,
                  location_hint='投标函', amount_type='num'),
        ],
    }

    # 大写合规性检查
    items = check_cn_amount_validity_in_doc(amounts_by_location)
    assert len(items) >= 1, '应至少有 1 项检查'

    # 大小写一致性检查（120万 vs 125万 应判为不一致）
    items = check_size_consistency(amounts_by_location)
    non_compliant = [it for it in items if it.status == 'non_compliant']
    assert len(non_compliant) > 0, '120万 vs 125万 应判为不一致'
    print(f'✅ test_price_check_runs 通过 (识别 {len(non_compliant)} 处大小写不一致)')


def test_residual_info_detection():
    """测试 7: 残留他人信息检测"""
    from check_plagiarism import check_residual_info
    from docx import Document

    doc = Document()
    doc.add_paragraph('投标人名称：XX科技有限公司')
    doc.add_paragraph('本项目由 YY科技有限公司 负责实施')

    requirements = {
        'project_info': {
            '项目名称': 'XX信息化项目',
            '采购人': 'XX局',
        }
    }

    issues = check_residual_info(doc, requirements)
    # 应识别到 YY科技有限公司
    yy_issues = [it for it in issues if 'YY科技' in it.description or 'YY科技' in it.evidence]
    assert len(yy_issues) > 0, f'应识别 YY科技有限公司, 实际 issues: {[i.description for i in issues]}'
    print(f'✅ test_residual_info_detection 通过 (识别 {len(issues)} 处残留)')


def test_ai_trace_detection():
    """测试 8: AI 痕迹检测"""
    from check_plagiarism import check_ai_traces
    from docx import Document

    doc = Document()
    # 故意写一段高密度套话（≥200 字以触发检测）
    doc.add_paragraph(
        '在信息化快速发展的今天，本方案秉承以用户为中心的设计理念。'
        '首先，我们致力于全面提升用户体验，为业务发展提供有力保障。'
        '其次，我们将秉承精益求精的理念，确保项目万无一失。'
        '此外，本方案始终坚持以客户需求为导向，以质量为核心。'
        '一方面，我们致力于构建开放生态，打造核心平台。'
        '另一方面，我们推动企业转型升级，助力企业实现数字化目标。'
        '总之，本方案将实现既定目标，为项目成功奠定坚实基础。'
        '综上所述，我们将确保项目按期交付，实现合作共赢。'
        '值得一提的是，本方案采用先进技术架构，确保系统稳定运行。'
        '众所周知，信息化建设是现代企业发展的必由之路，意义重大。'
    )

    issues = check_ai_traces(doc)
    assert len(issues) > 0, '应识别到 AI 痕迹'
    has_cliche = any('套话' in it.description for it in issues)
    assert has_cliche, '应有套话密度过高的问题'
    print(f'✅ test_ai_trace_detection 通过 (识别 {len(issues)} 处 AI 痕迹)')


def test_citation_detection():
    """测试 9: 引用未署名检测"""
    from check_plagiarism import check_citations
    from docx import Document

    doc = Document()
    doc.add_paragraph('本方案参考行业最佳实践进行设计。')
    doc.add_paragraph('根据相关标准，系统应满足以下要求。')

    issues = check_citations(doc)
    assert len(issues) > 0, '应识别到引用未署名'
    print(f'✅ test_citation_detection 通过 (识别 {len(issues)} 处未署名引用)')


def test_amounts_equal():
    """测试 10: 金额相等判断（含容差）"""
    from bid_checker.core.extract_amounts import values_equal

    assert values_equal(1200000, 1200000) is True
    assert values_equal(1200000, 1250000) is False
    assert values_equal(1200000.0, 1200000.01) is True  # 容差内（1 分钱）
    assert values_equal(1200000, 1200000.5) is False  # 超 2 分钱容差
    print('✅ test_amounts_equal 通过')


if __name__ == '__main__':
    print('运行 bid-checker-pro v1.1.0 行为契约测试...\n')

    tests = [
        test_cn_amount_parsing,
        test_num_amount_parsing,
        test_cn_amount_validity,
        test_text_similarity,
        test_self_duplicate_detection,
        test_price_check_runs,
        test_residual_info_detection,
        test_ai_trace_detection,
        test_citation_detection,
        test_amounts_equal,
    ]

    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f'❌ {test.__name__} 失败：{e}')
            import traceback
            traceback.print_exc()
            failed += 1

    print(f'\n{"="*50}')
    print(f'测试结果：通过 {passed}/{len(tests)}，失败 {failed}')
    if failed > 0:
        sys.exit(1)
