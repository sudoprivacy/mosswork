#!/usr/bin/env python3
"""
bid-checker-pro 行为契约测试：8 类格式合规检查

测试 audit_format_compliance.py 的 8 类检查在典型输入下的行为契约。
"""
import sys
import os
import json
import tempfile
from pathlib import Path

# 把 skill 根目录加入 path
SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))
sys.path.insert(0, str(SKILL_DIR / 'scripts'))


def test_chapter_completeness_with_missing_chapter():
    """测试 1: 章节完整性 - 缺失章节应判为 non_compliant"""
    from audit_format_compliance import check_chapter_completeness

    requirements = {
        'chapter_requirements': [
            {'chapter_id': 'ch01', 'title': '投标函', 'required': True,
             'must_be_present': True, 'evidence_keywords': ['投标函']},
            {'chapter_id': 'ch02', 'title': '技术方案', 'required': True,
             'must_be_present': True, 'evidence_keywords': ['技术方案']},
        ]
    }
    chapter_index = {
        'chapters': [
            {'chapter_id': 'ch01', 'title': '投标函', 'page_start': 3, 'page_end': 4},
            # 注意：没有"技术方案"章节
        ]
    }

    items = check_chapter_completeness(requirements, chapter_index)
    assert len(items) == 2, f'应有 2 个检查项，实际 {len(items)}'

    # 第一个应通过
    assert items[0].status == 'compliant', '投标函存在应通过'
    # 第二个应失败
    assert items[1].status == 'non_compliant', '技术方案缺失应失败'
    assert items[1].severity == 'critical', '必需章节缺失应为 critical'
    print('✅ test_chapter_completeness_with_missing_chapter 通过')


def test_required_fields_with_placeholder():
    """测试 2: 必填项 - 占位符应判为未填写"""
    from audit_format_compliance import check_required_fields
    from docx import Document

    doc = Document()
    doc.add_paragraph('项目名称：___________')  # 占位符
    doc.add_paragraph('项目编号：XXX')  # 占位符
    doc.add_paragraph('投标人名称：XX科技有限公司')  # 真实值

    requirements = {
        'required_fields': [
            {'field_id': 'f001', 'label': '项目名称', 'appears_in': ['封面']},
            {'field_id': 'f002', 'label': '项目编号', 'appears_in': ['封面']},
            {'field_id': 'f003', 'label': '投标人名称', 'appears_in': ['封面']},
        ]
    }

    items = check_required_fields(doc, requirements, {})
    assert len(items) == 3, f'应有 3 个检查项，实际 {len(items)}'

    # 前两个应失败（占位符）
    assert items[0].status == 'non_compliant', '占位符 ___ 应判为未填写'
    assert items[1].status == 'non_compliant', '占位符 XXX 应判为未填写'
    # 第三个应通过
    assert items[2].status == 'compliant', '真实值应判为已填写'
    print('✅ test_required_fields_with_placeholder 通过')


def test_field_consistency_with_inconsistent_values():
    """测试 3: 字段一致性 - 多处不一致应判为 non_compliant"""
    from audit_format_compliance import check_field_consistency
    from docx import Document

    doc = Document()
    doc.add_paragraph('项目名称：XX信息化项目')
    doc.add_paragraph('项目名称：XX信息化项目二期')  # 不一致
    doc.add_paragraph('项目编号：YZ-2026-001')

    requirements = {
        'required_fields': [
            {'field_id': 'f001', 'label': '项目名称', 'must_be_consistent': True},
            {'field_id': 'f002', 'label': '项目编号', 'must_be_consistent': True},
        ]
    }

    items = check_field_consistency(doc, requirements)
    # 项目名称不一致，应失败；项目编号只有一个值，应通过
    inconsistent_item = next((it for it in items if '项目名称' in it.requirement), None)
    consistent_item = next((it for it in items if '项目编号' in it.requirement), None)

    assert inconsistent_item is not None, '应有项目名称一致性检查'
    assert inconsistent_item.status == 'non_compliant', '项目名称不一致应失败'

    assert consistent_item is not None, '应有项目编号一致性检查'
    assert consistent_item.status == 'compliant', '项目编号一致应通过'
    print('✅ test_field_consistency_with_inconsistent_values 通过')


def test_severity_classification():
    """测试 4: 严重度分类 - 8 类检查的严重度应正确"""
    from audit_format_compliance import (
        check_chapter_completeness, check_chapter_page_breaks,
        check_required_fields, check_signature_positions,
        check_label_format, check_image_compliance,
        check_field_consistency, check_qualification_completeness,
    )
    from docx import Document

    doc = Document()
    doc.add_paragraph('测试')

    requirements = {'chapter_requirements': [], 'required_fields': []}
    chapter_index = {'chapters': []}

    # 章节完整性 - critical
    items = check_chapter_completeness(requirements, chapter_index)
    for it in items:
        if it.status == 'non_compliant':
            assert it.severity == 'critical', f'章节完整性失败应为 critical，实际 {it.severity}'

    print('✅ test_severity_classification 通过')


def test_audit_plan_structure():
    """测试 5: 审核计划 JSON 结构应包含所有必需字段"""
    from dataclasses import asdict
    from audit_format_compliance import AuditPlan, AuditItem

    item = AuditItem(
        check_id='chk_001',
        category='测试',
        severity='critical',
        rule_id='rule_test',
        requirement='测试要求',
        actual='测试实际',
        status='non_compliant',
        evidence='测试证据',
        suggestion='测试建议',
        page_ref='1',
    )
    plan = AuditPlan(
        audit_id='audit_test',
        audit_time='2026-07-16T12:00:00',
        total_checks=1,
        passed=0,
        failed=1,
        failures_by_severity={'critical': 1, 'major': 0, 'minor': 0, 'info': 0},
        items=[item],
    )

    d = asdict(plan)
    required_keys = ['audit_id', 'audit_time', 'total_checks', 'passed', 'failed',
                     'failures_by_severity', 'items']
    for k in required_keys:
        assert k in d, f'AuditPlan 缺少字段：{k}'

    item_required_keys = ['check_id', 'category', 'severity', 'rule_id', 'requirement',
                          'actual', 'status', 'evidence', 'suggestion', 'page_ref']
    for k in item_required_keys:
        assert k in d['items'][0], f'AuditItem 缺少字段：{k}'

    print('✅ test_audit_plan_structure 通过')


def test_response_status_levels():
    """测试 6: 评分项响应质量 4 级标准"""
    from evaluate_scoring_items import rule_based_evaluation

    # 完全命中
    result = rule_based_evaluation(
        {'evidence_keywords': ['技术方案', '实施方案'], 'max_score': 10, 'title': '技术方案'},
        '本章为技术方案，包含实施方案详细内容'
    )
    assert result['response_status'] == 'fully_responded', f'应完全响应，实际 {result["response_status"]}'
    assert result['estimated_score'] >= 9, f'预估分应 ≥9，实际 {result["estimated_score"]}'

    # 部分命中
    result = rule_based_evaluation(
        {'evidence_keywords': ['技术方案', '实施方案', '应急响应'], 'max_score': 10, 'title': '技术方案'},
        '本章为技术方案，包含实施方案详细内容'  # 缺"应急响应"
    )
    assert result['response_status'] == 'partially_responded', f'应部分响应，实际 {result["response_status"]}'

    # 完全缺失
    result = rule_based_evaluation(
        {'evidence_keywords': ['技术方案'], 'max_score': 10, 'title': '技术方案'},
        ''  # 空文本
    )
    assert result['response_status'] == 'missing', f'应缺失，实际 {result["response_status"]}'
    assert result['estimated_score'] == 0

    print('✅ test_response_status_levels 通过')


def test_ocr_validity_check_with_long_term():
    """测试 7: OCR 有效期检查 - "长期"应视为有效"""
    from ocr_evidence_check import check_validity
    from datetime import datetime

    # "长期" 应视为有效
    issue = check_validity('营业期限至', '长期', datetime(2026, 7, 16))
    assert issue is None, f'"长期"应视为有效，但返回 {issue}'

    # 过期日期应返回 critical
    issue = check_validity('有效期至', '2025-06-30', datetime(2026, 7, 16))
    assert issue is not None, '过期日期应返回 issue'
    assert issue['severity'] == 'critical', f'过期应为 critical，实际 {issue["severity"]}'

    # 未来日期应视为有效
    issue = check_validity('有效期至', '2030-12-31', datetime(2026, 7, 16))
    assert issue is None, f'未来日期应视为有效，但返回 {issue}'

    # 即将过期（30天内）应返回 major
    issue = check_validity('有效期至', '2026-08-01', datetime(2026, 7, 16))
    assert issue is not None, '即将过期应返回 issue'
    assert issue['severity'] == 'major', f'即将过期应为 major，实际 {issue["severity"]}'

    print('✅ test_ocr_validity_check_with_long_term 通过')


def test_image_type_detection():
    """测试 8: 图片类型识别"""
    from ocr_evidence_check import detect_image_type

    assert detect_image_type('统一社会信用代码 91110108MA01... 注册资本 1000万') == '营业执照'
    assert detect_image_type('公民身份号码 11010819800101XXXX 签发机关 XX') == '身份证'
    assert detect_image_type('资质等级 一级 发证机关 XX') == '资质证书'
    assert detect_image_type('检测机构 XX 检测日期 2026-01-01') == '检测报告'
    assert detect_image_type('一段普通文本') == '未知'

    print('✅ test_image_type_detection 通过')


def test_chapter_slicing_with_no_headings():
    """测试 9: 章节切片 - 无标题时应返回 0 章节"""
    from slice_chapters import slice_chapters
    from docx import Document
    import tempfile

    doc = Document()
    doc.add_paragraph('这是一段普通文本，没有标题样式')
    doc.add_paragraph('另一段普通文本')

    with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f:
        doc.save(f.name)
        docx_path = f.name

    try:
        result = slice_chapters(docx_path)
        assert result['total_paragraphs'] == 2
        assert len(result['chapters']) == 0, f'无标题应返回 0 章节，实际 {len(result["chapters"])}'
    finally:
        Path(docx_path).unlink()

    print('✅ test_chapter_slicing_with_no_headings 通过')


def test_keyword_index_basic():
    """测试 10: 关键词倒排索引基本功能"""
    from build_keyword_index import build_index

    chapters = [
        {'chapter_id': 'ch01', 'title': '投标函', 'full_text': '本章为投标函正文，包含投标金额'},
        {'chapter_id': 'ch02', 'title': '技术方案', 'full_text': '本章为技术方案，包含实施步骤和应急响应'},
        {'chapter_id': 'ch03', 'title': '营业执照', 'full_text': '营业执照副本扫描件'},
    ]

    index = build_index(chapters)
    assert '投标函' in index, '应包含关键词"投标函"'
    assert 'ch01' in index['投标函'], '"投标函"应在 ch01'

    assert '技术方案' in index, '应包含关键词"技术方案"'
    assert 'ch02' in index['技术方案'], '"技术方案"应在 ch02'

    print('✅ test_keyword_index_basic 通过')


if __name__ == '__main__':
    print('运行 bid-checker-pro 行为契约测试...\n')

    tests = [
        test_chapter_completeness_with_missing_chapter,
        test_required_fields_with_placeholder,
        test_field_consistency_with_inconsistent_values,
        test_severity_classification,
        test_audit_plan_structure,
        test_response_status_levels,
        test_ocr_validity_check_with_long_term,
        test_image_type_detection,
        test_chapter_slicing_with_no_headings,
        test_keyword_index_basic,
    ]

    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f'❌ {test.__name__} 失败：{e}')
            failed += 1

    print(f'\n{"="*50}')
    print(f'测试结果：通过 {passed}/{len(tests)}，失败 {failed}')
    if failed > 0:
        sys.exit(1)
