#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 PDF 转 Word 工具的跨平台行为 (v9.0)
"""

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from pdf_to_word import convert_pdf_to_word, _try_win32com_convert


class TestPDFConvertPlatform(unittest.TestCase):
    """测试 PDF 转换的跨平台行为"""

    def test_nonexistent_pdf_raises(self):
        """不存在的 PDF 文件应抛 FileNotFoundError"""
        with self.assertRaises(FileNotFoundError):
            convert_pdf_to_word("/nonexistent/file.pdf")

    @patch('sys.platform', 'linux')
    def test_win32com_skipped_on_linux(self):
        """Linux 平台上 win32com 应直接返回 None"""
        result = _try_win32com_convert("/any/path.pdf", "/any/output.docx")
        self.assertIsNone(result)

    @patch('sys.platform', 'darwin')
    def test_win32com_skipped_on_macos(self):
        """macOS 平台上 win32com 应直接返回 None"""
        result = _try_win32com_convert("/any/path.pdf", "/any/output.docx")
        self.assertIsNone(result)

    def test_output_path_default(self):
        """未指定 output_path 时自动生成"""
        # 用 mock 阻止实际转换
        with patch('pdf_to_word._try_pdf2docx_convert', return_value="/fake/output.docx"), \
             patch('pdf_to_word._try_fallback_convert', return_value=None):
            # 由于 PDF 不存在会先抛 FileNotFoundError，所以测试 mock 整个函数
            with patch('pdf_to_word.os.path.exists', return_value=True):
                result = convert_pdf_to_word("/fake/test.pdf")
                # 应使用 pdf2docx 主路径
                self.assertTrue(result)


if __name__ == "__main__":
    unittest.main()
