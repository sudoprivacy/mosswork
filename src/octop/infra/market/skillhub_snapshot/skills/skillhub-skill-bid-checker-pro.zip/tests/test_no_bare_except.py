#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 bare except 已全部修复 (v9.0)
"""

import os
import re
import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class TestNoBareExcept(unittest.TestCase):
    """验证所有 Python 文件中无 bare except"""

    EXCLUDE_DIRS = {
        ".git", "__pycache__", ".pytest_cache", "node_modules",
        "venv", ".venv", ".idea", ".vscode",
    }

    EXCLUDE_FILES = {
        # 修复脚本本身含 except: 字符串（注释/字符串字面量），跳过
        "fix_bare_except.py",
        "replace_print_with_logger.py",
    }

    def test_no_bare_except_in_source_files(self):
        """所有源代码文件中不应有 bare except:"""
        # bare except 模式：行尾是 "except:" 或 "except:  # comment"
        bare_except_pattern = re.compile(r'^\s*except\s*:\s*(#.*)?$')

        violations = []
        for root, dirs, files in os.walk(PROJECT_ROOT):
            # 排除目录
            dirs[:] = [d for d in dirs if d not in self.EXCLUDE_DIRS]
            for fname in files:
                if not fname.endswith('.py'):
                    continue
                if fname in self.EXCLUDE_FILES:
                    continue

                fpath = Path(root) / fname
                try:
                    text = fpath.read_text(encoding="utf-8")
                except Exception:
                    continue

                for i, line in enumerate(text.splitlines(), start=1):
                    if bare_except_pattern.match(line):
                        violations.append(f"{fpath.relative_to(PROJECT_ROOT)}:{i}: {line.strip()}")

        if violations:
            self.fail(f"发现 {len(violations)} 处 bare except:\n" + "\n".join(violations))


if __name__ == "__main__":
    unittest.main()
