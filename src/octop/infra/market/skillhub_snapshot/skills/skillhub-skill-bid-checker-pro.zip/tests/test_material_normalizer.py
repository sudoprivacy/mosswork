#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 v20.3 资料命名规范化预处理
"""

import os
import sys
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from bid_checker.core.material_normalizer import (
    MaterialNormalizer,
    STANDARD_MATERIAL_TYPES,
    OCR_CONTENT_KEYWORDS,
    DIRECTORY_CONTEXT,
)
from hitl_review import (
    parse_material_confirmation,
    apply_material_confirmation,
)


class TestKeywordMapping(unittest.TestCase):
    """测试标准资料类型关键词映射表"""

    def test_all_types_have_keywords(self):
        """每个标准类型必须有 keywords"""
        for mat_type, config in STANDARD_MATERIAL_TYPES.items():
            self.assertIn('keywords', config, f"{mat_type} 缺少 keywords")
            self.assertGreater(len(config['keywords']), 0,
                f"{mat_type} 的 keywords 为空")

    def test_all_types_have_context_dirs(self):
        """每个标准类型必须有 context_dirs"""
        for mat_type, config in STANDARD_MATERIAL_TYPES.items():
            self.assertIn('context_dirs', config, f"{mat_type} 缺少 context_dirs")

    def test_ocr_keywords_cover_main_types(self):
        """OCR 关键词应覆盖主要资料类型"""
        main_types = ['营业执照', '法人身份证正面', '财务审计报告',
                      '税收缴纳证明', '社保证明', '信用查询', '授权委托书']
        for t in main_types:
            self.assertIn(t, OCR_CONTENT_KEYWORDS, f"OCR 关键词缺少 {t}")

    def test_directory_context_covers_standard_layout(self):
        """目录上下文应覆盖标准资料文件夹结构"""
        standard_dirs = ['01_营业执照', '02_财务报表', '03_法人证件',
                         '04_授权委托人证件', '05_完税社保证明']
        for d in standard_dirs:
            self.assertIn(d, DIRECTORY_CONTEXT, f"目录上下文缺少 {d}")


class TestMatchByFilename(unittest.TestCase):
    """测试规则 A：文件名关键词匹配"""

    def setUp(self):
        self.normalizer = MaterialNormalizer(use_ocr=False)

    def test_standard_name(self):
        """标准命名应精确匹配"""
        result = self.normalizer._match_by_filename('营业执照.jpg')
        self.assertEqual(result['type'], '营业执照')

    def test_abbreviation_BL(self):
        """缩写 BL 应识别为营业执照"""
        result = self.normalizer._match_by_filename('BL.jpg')
        self.assertEqual(result['type'], '营业执照')

    def test_suffix_副本(self):
        """带'副本'后缀应识别"""
        result = self.normalizer._match_by_filename('营业执照副本.jpg')
        self.assertEqual(result['type'], '营业执照')

    def test_id_card_front(self):
        """身份证正面应识别"""
        result = self.normalizer._match_by_filename('法人身份证正面.png')
        self.assertEqual(result['type'], '法人身份证正面')

    def test_audit_report(self):
        """审计报告应识别"""
        result = self.normalizer._match_by_filename('2024审计报告.pdf')
        self.assertEqual(result['type'], '财务审计报告')

    def test_tax_certificate(self):
        """完税证明应识别"""
        result = self.normalizer._match_by_filename('完税证明.jpg')
        self.assertEqual(result['type'], '税收缴纳证明')

    def test_social_security(self):
        """社保证明应识别"""
        result = self.normalizer._match_by_filename('社保缴纳证明.pdf')
        self.assertEqual(result['type'], '社保证明')

    def test_credit(self):
        """信用查询应识别"""
        result = self.normalizer._match_by_filename('信用中国截图.png')
        self.assertEqual(result['type'], '信用查询')

    def test_authorization(self):
        """授权委托书应识别"""
        result = self.normalizer._match_by_filename('授权委托书.docx')
        self.assertEqual(result['type'], '授权委托书')

    def test_performance_contract(self):
        """业绩合同应识别"""
        result = self.normalizer._match_by_filename('项目业绩合同.pdf')
        self.assertEqual(result['type'], '业绩合同')

    def test_unrecognized_number(self):
        """纯数字文件名应返回 None"""
        result = self.normalizer._match_by_filename('1.jpg')
        self.assertIsNone(result)

    def test_unrecognized_random(self):
        """随机命名应返回 None"""
        result = self.normalizer._match_by_filename('IMG_20240101_001.jpg')
        self.assertIsNone(result)

    def test_case_insensitive(self):
        """英文关键词应大小写不敏感"""
        result = self.normalizer._match_by_filename('bl.jpg')
        self.assertEqual(result['type'], '营业执照')


class TestMatchByDirectory(unittest.TestCase):
    """测试规则 C：目录上下文匹配"""

    def setUp(self):
        self.normalizer = MaterialNormalizer(use_ocr=False)
        self.base_dir = Path('/tmp/test_materials')

    def test_standard_directory_layout(self):
        """标准目录结构应识别"""
        result = self.normalizer._match_by_directory(
            '01_营业执照', '/tmp/test_materials/01_营业执照', self.base_dir)
        self.assertIsNotNone(result)
        self.assertEqual(result['type'], '营业执照')

    def test_finance_directory(self):
        """财务目录应识别"""
        result = self.normalizer._match_by_directory(
            '02_财务报表', '/tmp/test_materials/02_财务报表', self.base_dir)
        self.assertIsNotNone(result)
        self.assertEqual(result['type'], '财务审计报告')

    def test_legal_person_directory(self):
        """法人证件目录应识别"""
        result = self.normalizer._match_by_directory(
            '03_法人证件', '/tmp/test_materials/03_法人证件', self.base_dir)
        self.assertIsNotNone(result)
        self.assertEqual(result['type'], '法人身份证正面')

    def test_nested_directory(self):
        """嵌套目录应识别（如 资料文件夹/财务/审计/）"""
        result = self.normalizer._match_by_directory(
            '财务/审计', '/tmp/test_materials/财务/审计', self.base_dir)
        self.assertIsNotNone(result)

    def test_no_match(self):
        """无关键词的目录应返回 None"""
        result = self.normalizer._match_by_directory(
            'misc', '/tmp/test_materials/misc', self.base_dir)
        self.assertIsNone(result)


class TestNormalizeEndToEnd(unittest.TestCase):
    """端到端测试：完整规范化流程"""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.materials_dir = Path(self.tmpdir) / 'materials'
        self.output_dir = Path(self.tmpdir) / 'standardized'

        # 创建模拟资料文件
        self.materials_dir.mkdir(parents=True)

        # 标准命名文件
        (self.materials_dir / '营业执照.jpg').write_bytes(b'fake image')
        (self.materials_dir / '法人身份证正面.png').write_bytes(b'fake image')
        (self.materials_dir / '法人身份证反面.png').write_bytes(b'fake image')

        # 缩写命名文件
        (self.materials_dir / 'BL.jpg').write_bytes(b'fake image')

        # 模糊命名文件
        (self.materials_dir / '审计2024.pdf').write_bytes(b'fake pdf')

        # 无法识别文件
        (self.materials_dir / '1.jpg').write_bytes(b'fake image')
        (self.materials_dir / 'IMG_001.png').write_bytes(b'fake image')

        # 创建子目录 + 文件
        subdir = self.materials_dir / '03_法人证件'
        subdir.mkdir()
        (subdir / '证件.jpg').write_bytes(b'fake image')

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_normalize_basic(self):
        """基础端到端测试（禁用 OCR）"""
        normalizer = MaterialNormalizer(use_ocr=False)
        result = normalizer.normalize(str(self.materials_dir), str(self.output_dir))

        self.assertEqual(result['stats']['total'], 8)
        # 应识别 6 个（营业执照.jpg / 法人身份证正面.png / 法人身份证反面.png / BL.jpg / 审计2024.pdf / 证件.jpg via 目录）
        self.assertGreaterEqual(result['stats']['identified'], 5)
        # 未识别 2 个（1.jpg / IMG_001.png）
        self.assertGreaterEqual(result['stats']['unidentified'], 2)

    def test_normalize_generates_report(self):
        """应生成 rename_report.md"""
        normalizer = MaterialNormalizer(use_ocr=False)
        result = normalizer.normalize(str(self.materials_dir), str(self.output_dir))

        report_path = Path(result['report_md'])
        self.assertTrue(report_path.exists())
        content = report_path.read_text(encoding='utf-8')
        self.assertIn('资料命名规范化报告', content)
        self.assertIn('逐文件匹配详情', content)
        self.assertIn('营业执照', content)

    def test_normalize_generates_standardized_dir(self):
        """应生成规范化文件夹"""
        normalizer = MaterialNormalizer(use_ocr=False)
        result = normalizer.normalize(str(self.materials_dir), str(self.output_dir))

        self.assertTrue(self.output_dir.exists())
        # 规范化文件应存在
        standardized_files = list(self.output_dir.glob('*'))
        # 应包含 rename_report.md + 规范化的资料文件
        self.assertGreater(len(standardized_files), 3)

    def test_normalize_unidentified_goes_to_subdir(self):
        """未识别文件应进入 unidentified/ 子目录"""
        normalizer = MaterialNormalizer(use_ocr=False)
        result = normalizer.normalize(str(self.materials_dir), str(self.output_dir))

        unid_dir = self.output_dir / 'unidentified'
        if unid_dir.exists():
            # 未识别文件应在该目录
            unid_files = list(unid_dir.iterdir())
            self.assertGreater(len(unid_files), 0)

    def test_normalize_with_copy(self):
        """use_symlink=False 应复制副本"""
        normalizer = MaterialNormalizer(use_ocr=False)
        result = normalizer.normalize(str(self.materials_dir), str(self.output_dir),
                                        use_symlink=False)
        # 副本应是独立文件（不是软链接）
        for f in result['files']:
            if f.get('standardized_path') and f['suggested_type'] != '未识别':
                self.assertTrue(os.path.exists(f['standardized_path']))
                self.assertFalse(os.path.islink(f['standardized_path']))


class TestMaterialConfirmation(unittest.TestCase):
    """测试资料规范化 HITL 确认"""

    def test_parse_confirm(self):
        result = parse_material_confirmation("1.确认")
        self.assertEqual(result['item_actions'][1], 'confirm')

    def test_parse_rename(self):
        result = parse_material_confirmation("2.修改:营业执照.jpg")
        self.assertEqual(result['item_actions'][2], ('rename', '营业执照.jpg'))

    def test_parse_specify_type(self):
        result = parse_material_confirmation("3.手动指定:法人身份证正面")
        self.assertEqual(result['item_actions'][3], ('specify_type', '法人身份证正面'))

    def test_parse_skip(self):
        result = parse_material_confirmation("4.跳过")
        self.assertEqual(result['item_actions'][4], 'skip')

    def test_parse_global_confirm_all(self):
        result = parse_material_confirmation("全部确认")
        self.assertEqual(result['global_action'], 'confirm_all')

    def test_parse_global_skip_unidentified(self):
        result = parse_material_confirmation("全部跳过未识别")
        self.assertEqual(result['global_action'], 'skip_unidentified')

    def test_apply_confirmation_confirm(self):
        """确认操作应标记 confirmed"""
        normalize_result = {
            'files': [
                {'original_name': 'BL.jpg', 'suggested_type': '营业执照',
                 'suggested_name': '营业执照.jpg', 'confidence': 0.9},
            ]
        }
        confirmation = {'item_actions': {1: 'confirm'}, 'global_action': None}
        result = apply_material_confirmation(normalize_result, confirmation)
        self.assertEqual(result['files'][0]['final_status'], 'confirmed')

    def test_apply_confirmation_rename(self):
        """修改操作应更新 suggested_name"""
        normalize_result = {
            'files': [
                {'original_name': 'BL.jpg', 'suggested_type': '营业执照',
                 'suggested_name': '营业执照.jpg', 'confidence': 0.9, 'ext': '.jpg'},
            ]
        }
        confirmation = {'item_actions': {1: ('rename', 'my_license.jpg')}, 'global_action': None}
        result = apply_material_confirmation(normalize_result, confirmation)
        self.assertEqual(result['files'][0]['final_status'], 'renamed')
        self.assertEqual(result['files'][0]['suggested_name'], 'my_license.jpg')

    def test_apply_confirmation_specify_type(self):
        """手动指定操作应更新 suggested_type + suggested_name"""
        normalize_result = {
            'files': [
                {'original_name': '1.jpg', 'suggested_type': '未识别',
                 'suggested_name': '1.jpg', 'confidence': 0.0, 'ext': '.jpg'},
            ]
        }
        confirmation = {'item_actions': {1: ('specify_type', '法人身份证正面')}, 'global_action': None}
        result = apply_material_confirmation(normalize_result, confirmation)
        self.assertEqual(result['files'][0]['final_status'], 'specified')
        self.assertEqual(result['files'][0]['suggested_type'], '法人身份证正面')
        self.assertEqual(result['files'][0]['suggested_name'], '法人身份证正面.jpg')
        self.assertEqual(result['files'][0]['confidence'], 1.0)

    def test_apply_global_confirm_all(self):
        """全部确认 → 高/中置信度项默认通过"""
        normalize_result = {
            'files': [
                {'suggested_type': '营业执照', 'confidence': 0.9},
                {'suggested_type': '财务审计报告', 'confidence': 0.7},
                {'suggested_type': '未识别', 'confidence': 0.0},
            ]
        }
        confirmation = {'item_actions': {}, 'global_action': 'confirm_all'}
        result = apply_material_confirmation(normalize_result, confirmation)
        self.assertEqual(result['files'][0]['final_status'], 'confirmed')
        self.assertEqual(result['files'][1]['final_status'], 'confirmed')
        self.assertEqual(result['files'][2]['final_status'], 'skipped')

    def test_apply_default_for_unoperated(self):
        """未操作项：高置信度默认确认，未识别默认跳过"""
        normalize_result = {
            'files': [
                {'suggested_type': '营业执照', 'confidence': 0.9},
                {'suggested_type': '未识别', 'confidence': 0.0},
            ]
        }
        confirmation = {'item_actions': {}, 'global_action': None}
        result = apply_material_confirmation(normalize_result, confirmation)
        self.assertEqual(result['files'][0]['final_status'], 'confirmed')
        self.assertEqual(result['files'][1]['final_status'], 'skipped')


if __name__ == "__main__":
    unittest.main()
