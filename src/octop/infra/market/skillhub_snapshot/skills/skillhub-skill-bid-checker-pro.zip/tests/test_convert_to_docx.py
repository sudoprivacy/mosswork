#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 v20.2 统一文件转换工具 convert_to_docx.py
"""

import os
import sys
import shutil
import tempfile
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from convert_to_docx import convert_to_docx


class TestConvertToDocxDirect(unittest.TestCase):
    """测试 .docx 直接通过"""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_docx_pass_through(self):
        """ .docx 文件应直接通过，不转换"""
        from docx import Document
        docx_path = os.path.join(self.tmpdir, "test.docx")
        doc = Document()
        doc.add_paragraph("测试内容")
        doc.save(docx_path)

        out_path = os.path.join(self.tmpdir, "out.docx")
        result = convert_to_docx(docx_path, out_path)
        self.assertEqual(result, out_path)
        self.assertTrue(os.path.exists(out_path))


class TestConvertToDocxDoc(unittest.TestCase):
    """测试 .doc 自动转换（需 LibreOffice）"""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        # 检查 LibreOffice 是否可用
        self.soffice = shutil.which('libreoffice') or shutil.which('soffice')
        if self.soffice is None:
            self.skipTest("LibreOffice 未安装，跳过 .doc 转换测试")

        # 生成 .doc 测试文件：先用 python-docx 生成 .docx，再用 LibreOffice 转 .doc
        from docx import Document
        docx_path = os.path.join(self.tmpdir, "test.docx")
        doc = Document()
        doc.add_heading("投标文件格式", level=1)
        doc.add_paragraph("测试内容")
        doc.save(docx_path)

        import subprocess
        result = subprocess.run(
            [self.soffice, '--headless', '--norestore', '--convert-to', 'doc',
             '--outdir', self.tmpdir, docx_path],
            capture_output=True, text=True, timeout=60
        )
        self.doc_path = os.path.join(self.tmpdir, "test.doc")
        if not os.path.exists(self.doc_path):
            self.skipTest("无法生成 .doc 测试文件")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_doc_to_docx_auto_convert(self):
        """ .doc 应自动用 LibreOffice 转 .docx"""
        out_path = os.path.join(self.tmpdir, "out.docx")
        result = convert_to_docx(self.doc_path, out_path)
        self.assertEqual(result, out_path)
        self.assertTrue(os.path.exists(out_path))

        # 验证转换后的 .docx 可读
        from docx import Document
        doc = Document(out_path)
        self.assertGreater(len(doc.paragraphs), 0)


class TestConvertToDocxPdf(unittest.TestCase):
    """测试 .pdf 处理"""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        # 创建假 PDF 文件
        self.pdf_path = os.path.join(self.tmpdir, "test.pdf")
        with open(self.pdf_path, 'wb') as f:
            f.write(b"%PDF-1.4 fake pdf content")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_pdf_rejected_by_default(self):
        """默认情况下 PDF 应被拒绝"""
        out_path = os.path.join(self.tmpdir, "out.docx")
        with self.assertRaises(RuntimeError) as ctx:
            convert_to_docx(self.pdf_path, out_path)
        self.assertIn("PDF 默认拒绝转换", str(ctx.exception))

    def test_pdf_force_convert_attempts(self):
        """传 force_pdf=True 应尝试转换（可能失败，但不应是 RuntimeError 拒绝）"""
        out_path = os.path.join(self.tmpdir, "out.docx")
        # 假 PDF 不是真 PDF，转换会失败，但错误信息应是"转换失败"而非"拒绝转换"
        with self.assertRaises(RuntimeError) as ctx:
            convert_to_docx(self.pdf_path, out_path, force_pdf=True)
        # 不应包含"默认拒绝"
        self.assertNotIn("默认拒绝", str(ctx.exception))


class TestConvertToDocxErrors(unittest.TestCase):
    """测试错误处理"""

    def test_nonexistent_file(self):
        with self.assertRaises(FileNotFoundError):
            convert_to_docx("/nonexistent/file.docx")

    def test_unsupported_format(self):
        with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as tmp:
            tmp.write(b"text content")
            tmp_path = tmp.name
        try:
            with self.assertRaises(ValueError):
                convert_to_docx(tmp_path)
        finally:
            os.unlink(tmp_path)


class TestSKILLMdReferences(unittest.TestCase):
    """验证 SKILL.md 正确引用了 convert_to_docx.py"""

    def test_skill_md_mentions_convert_to_docx(self):
        """SKILL.md 应多次提及 convert_to_docx.py"""
        with open(PROJECT_ROOT / "SKILL.md", 'r', encoding='utf-8') as f:
            content = f.read()
        # 应至少出现 4 次（脚本清单 + 强制规则 + 命令示例 + 输入输出）
        self.assertGreaterEqual(content.count('convert_to_docx'), 4,
            "SKILL.md 中 convert_to_docx 引用不足 4 次")

    def test_skill_md_does_not_recommend_pdf_to_word_directly(self):
        """SKILL.md 不应再推荐直接用 pdf_to_word.py（应改用 convert_to_docx.py）"""
        with open(PROJECT_ROOT / "SKILL.md", 'r', encoding='utf-8') as f:
            content = f.read()
        # 不应出现"PDF需先用 scripts/pdf_to_word.py 转换"这种旧描述
        self.assertNotIn("PDF需先用 `scripts/pdf_to_word.py` 转换", content,
            "SKILL.md 仍含旧的 pdf_to_word.py 直接推荐，应改为 convert_to_docx.py")


if __name__ == "__main__":
    unittest.main()
