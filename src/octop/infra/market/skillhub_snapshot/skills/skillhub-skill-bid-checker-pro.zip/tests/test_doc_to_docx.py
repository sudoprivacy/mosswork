#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 bid_checker.utils.doc_to_docx — DOC 转 DOCX 模块 (v9.0.3)
"""

import os
import sys
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from bid_checker.utils.doc_to_docx import (
    is_doc_file,
    is_docx_file,
    _find_libreoffice,
    convert_doc_to_docx,
    ensure_docx,
)


class TestFileTypeDetection(unittest.TestCase):
    """测试文件类型检测"""

    def test_is_doc_file(self):
        self.assertTrue(is_doc_file("test.doc"))
        self.assertTrue(is_doc_file("TEST.DOC"))
        self.assertTrue(is_doc_file("/path/to/file.doc"))

    def test_is_docx_file(self):
        self.assertTrue(is_docx_file("test.docx"))
        self.assertTrue(is_docx_file("TEST.DOCX"))

    def test_not_doc_file(self):
        self.assertFalse(is_doc_file("test.docx"))
        self.assertFalse(is_doc_file("test.pdf"))
        self.assertFalse(is_doc_file("test.txt"))
        self.assertFalse(is_doc_file(""))

    def test_not_docx_file(self):
        self.assertFalse(is_docx_file("test.doc"))
        self.assertFalse(is_docx_file("test.pdf"))
        self.assertFalse(is_docx_file(""))

    def test_empty_path(self):
        self.assertFalse(is_doc_file(""))
        self.assertFalse(is_docx_file(""))
        self.assertFalse(is_doc_file(None))


class TestFindLibreoffice(unittest.TestCase):
    """测试 LibreOffice 查找"""

    def test_find_libreoffice_on_linux(self):
        """Linux 环境下应能找到 libreoffice 或 soffice"""
        if sys.platform != 'win32':
            result = _find_libreoffice()
            # 不强制要求一定找到（CI环境可能没装），但函数应正常返回
            if result is not None:
                self.assertTrue(os.path.exists(result) or shutil.which(result))


class TestConvertDocToDocx(unittest.TestCase):
    """测试 DOC 转 DOCX 主函数"""

    def test_nonexistent_file_raises(self):
        """不存在的文件应抛 FileNotFoundError"""
        with self.assertRaises(FileNotFoundError):
            convert_doc_to_docx("/nonexistent/file.doc")

    def test_docx_file_returns_directly(self):
        """传入 .docx 文件应直接返回，不转换"""
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as tmp:
            tmp.write(b"fake docx content")
            tmp_path = tmp.name

        try:
            result, converted = convert_doc_to_docx(tmp_path)
            self.assertEqual(result, tmp_path)
            self.assertFalse(converted)
        finally:
            os.unlink(tmp_path)

    def test_other_format_raises(self):
        """非 .doc/.docx 文件应抛 ValueError（在 ensure_docx 中）"""
        with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as tmp:
            tmp.write(b"text content")
            tmp_path = tmp.name

        try:
            with self.assertRaises(ValueError):
                ensure_docx(tmp_path)
        finally:
            os.unlink(tmp_path)


class TestEnsureDocx(unittest.TestCase):
    """测试 ensure_docx 函数"""

    def test_docx_returns_directly(self):
        """传入 .docx 应直接返回"""
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as tmp:
            tmp.write(b"fake docx")
            tmp_path = tmp.name

        try:
            result = ensure_docx(tmp_path)
            self.assertEqual(result, tmp_path)
        finally:
            os.unlink(tmp_path)

    def test_nonexistent_raises(self):
        """不存在的文件应抛 FileNotFoundError"""
        with self.assertRaises(FileNotFoundError):
            ensure_docx("/nonexistent/file.docx")


class TestEndToEndConversion(unittest.TestCase):
    """端到端转换测试（仅在 LibreOffice 可用时运行）"""

    @classmethod
    def setUpClass(cls):
        cls.soffice = _find_libreoffice()
        if cls.soffice is None:
            raise unittest.SkipTest("LibreOffice 未安装，跳过端到端测试")

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

        # 用 python-docx 生成 .docx，再用 libreoffice 转 .doc
        from docx import Document
        doc = Document()
        doc.add_heading('测试文档', level=1)
        doc.add_paragraph('这是测试段落。')
        docx_path = os.path.join(self.tmpdir, 'test.docx')
        doc.save(docx_path)

        # 转换为 .doc
        import subprocess
        result = subprocess.run(
            [self.soffice, '--headless', '--norestore', '--convert-to', 'doc',
             '--outdir', self.tmpdir, docx_path],
            capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            raise unittest.SkipTest(f"无法生成测试 .doc 文件: {result.stderr}")

        self.doc_path = os.path.join(self.tmpdir, 'test.doc')
        if not os.path.exists(self.doc_path):
            raise unittest.SkipTest(".doc 文件未生成")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_convert_doc_to_docx_e2e(self):
        """端到端：.doc → .docx 转换并验证可读"""
        result, was_converted = convert_doc_to_docx(self.doc_path, self.tmpdir)

        self.assertTrue(was_converted)
        self.assertTrue(os.path.exists(result))
        self.assertTrue(result.lower().endswith('.docx'))

        # 验证转换后的 .docx 能被 python-docx 读取
        from docx import Document
        doc = Document(result)
        self.assertGreater(len(doc.paragraphs), 0)
        # 应包含原始内容（可能格式略有变化）
        all_text = '\n'.join(p.text for p in doc.paragraphs)
        self.assertIn('测试', all_text)

    def test_ensure_docx_e2e(self):
        """端到端：ensure_docx 函数"""
        result = ensure_docx(self.doc_path)
        self.assertTrue(result.lower().endswith('.docx'))
        self.assertTrue(os.path.exists(result))


if __name__ == "__main__":
    unittest.main()
