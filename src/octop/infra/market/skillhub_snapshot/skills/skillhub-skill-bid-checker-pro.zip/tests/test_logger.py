#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 bid_checker.utils.logger — 统一日志模块
"""

import os
import sys
import logging
import unittest
from pathlib import Path
from io import StringIO

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from bid_checker.utils.logger import get_logger, set_level


class TestLogger(unittest.TestCase):
    """测试 logger 模块"""

    def test_get_logger_returns_logger(self):
        logger = get_logger("test_module_1")
        self.assertIsInstance(logger, logging.Logger)

    def test_same_name_returns_same_logger(self):
        """同名 logger 返回同一对象"""
        logger1 = get_logger("test_module_2")
        logger2 = get_logger("test_module_2")
        self.assertIs(logger1, logger2)

    def test_logger_has_handler(self):
        """logger 至少有一个 handler"""
        logger = get_logger("test_module_3")
        self.assertGreater(len(logger.handlers), 0)

    def test_logger_no_propagate(self):
        """logger 不向上传播"""
        logger = get_logger("test_module_4")
        self.assertFalse(logger.propagate)

    def test_set_level(self):
        """set_level 能调整级别"""
        logger = get_logger("test_module_5")
        set_level("DEBUG")
        self.assertEqual(logger.level, logging.DEBUG)
        set_level("WARNING")
        self.assertEqual(logger.level, logging.WARNING)
        # 还原
        set_level("INFO")

    def test_log_to_stderr(self):
        """日志输出到 stderr 不污染 stdout"""
        # 由于 handler 在初始化时已绑定到真实 stderr，
        # 直接测试 handler 的 stream 是否为 sys.stderr
        logger = get_logger("test_stderr_check")
        self.assertGreater(len(logger.handlers), 0)
        # 第一个 handler 应是 StreamHandler，stream 是 stderr
        handler = logger.handlers[0]
        self.assertEqual(handler.stream, sys.stderr)

        # 测试日志格式包含关键部分
        import io
        test_handler = logging.StreamHandler(io.StringIO())
        test_handler.setFormatter(logging.Formatter(
            "[%(levelname)s] [%(name)s] %(message)s"
        ))
        test_logger = logging.getLogger("test_format_check")
        test_logger.handlers = [test_handler]
        test_logger.setLevel(logging.INFO)
        test_logger.propagate = False
        test_logger.info("测试消息")

        output = test_handler.stream.getvalue()
        self.assertIn("测试消息", output)
        self.assertIn("INFO", output)


if __name__ == "__main__":
    unittest.main()
