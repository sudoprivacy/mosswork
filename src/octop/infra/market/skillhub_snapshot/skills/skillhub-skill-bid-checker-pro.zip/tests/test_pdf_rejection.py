#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 v9.0.5: PDF 拒绝自动转换 + --allow-pdf-convert 强制转换
"""

import os
import sys
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from generate_framework_v5 import create_framework_by_subtraction


class TestPDFRejection(unittest.TestCase):
    """测试 PDF 输入时的拒绝行为"""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        # 创建一个假的 PDF 文件
        self.pdf_path = os.path.join(self.tmpdir, "test.pdf")
        with open(self.pdf_path, 'wb') as f:
            f.write(b"%PDF-1.4 fake pdf content")
        self.output_path = os.path.join(self.tmpdir, "framework.docx")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_pdf_rejected_by_default(self):
        """默认情况下 PDF 应被拒绝，返回 False"""
        result = create_framework_by_subtraction(self.pdf_path, self.output_path)
        self.assertFalse(result, "PDF 应被拒绝，应返回 False")

        # 输出文件不应被生成
        self.assertFalse(os.path.exists(self.output_path),
                         "PDF 被拒绝时不应生成输出文件")

    def test_pdf_rejection_does_not_touch_output(self):
        """PDF 拒绝时不应修改输出路径下的文件"""
        # 先创建一个已存在的输出文件
        with open(self.output_path, 'wb') as f:
            f.write(b"existing content")

        result = create_framework_by_subtraction(self.pdf_path, self.output_path)
        self.assertFalse(result)

        # 输出文件内容应未被修改
        with open(self.output_path, 'rb') as f:
            content = f.read()
        self.assertEqual(content, b"existing content")


class TestDocxFileStillWorks(unittest.TestCase):
    """测试 .docx 文件依然能正常处理"""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_docx_still_works(self):
        """正常 .docx 文件应能正常生成框架"""
        from docx import Document

        # 创建包含"投标文件格式"章节的 .docx
        docx_path = os.path.join(self.tmpdir, "test.docx")
        doc = Document()
        doc.add_paragraph("第一章 项目概况")
        doc.add_paragraph("项目说明" * 5)
        doc.add_paragraph("投标文件格式")
        doc.add_paragraph("一、投标函")
        doc.add_paragraph("投标函内容")
        doc.save(docx_path)

        output_path = os.path.join(self.tmpdir, "framework.docx")
        result = create_framework_by_subtraction(docx_path, output_path)

        self.assertTrue(result)
        self.assertTrue(os.path.exists(output_path))

        # 验证框架内容
        doc = Document(output_path)
        all_text = '\n'.join(p.text for p in doc.paragraphs)
        self.assertIn("投标文件格式", all_text)
        self.assertIn("投标函", all_text)
        # 前置内容应被删除
        self.assertNotIn("第一章 项目概况", all_text)


class TestUnsupportedFormat(unittest.TestCase):
    """测试不支持的文件格式"""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_txt_file_rejected(self):
        """纯文本文件应被拒绝"""
        txt_path = os.path.join(self.tmpdir, "test.txt")
        with open(txt_path, 'w') as f:
            f.write("plain text content")

        output_path = os.path.join(self.tmpdir, "framework.docx")
        result = create_framework_by_subtraction(txt_path, output_path)
        self.assertFalse(result)

    def test_nonexistent_file_rejected(self):
        """不存在的文件应被拒绝"""
        result = create_framework_by_subtraction(
            "/nonexistent/file.docx",
            "/tmp/output.docx"
        )
        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main()
