#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 OCR 本地引擎配置 (v11, 无 API)

验证：
  - 模块不再导出任何百度 OCR 相关符号（BaiduOCR / _load_baidu_credentials 等）
  - create_ocr_engine 在无 RapidOCR 时优雅返回 None（不再读取任何云端密钥）
  - create_ocr_engine 在 RapidOCR 可用时返回 RapidOCRBackend 实例
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

sys.path.insert(0, str(PROJECT_ROOT))

from bid_checker.core import ocr_engine
from bid_checker.core.ocr_engine import RapidOCRBackend, create_ocr_engine


class TestNoBaiduOCR(unittest.TestCase):
    """确认百度 OCR 相关符号已从模块移除（无 API 模式）"""

    def test_baidu_symbols_removed(self):
        for symbol in ("BaiduOCR", "_load_baidu_credentials",
                       "_has_baidu_config", "ENV_BAIDU_API_KEY",
                       "ENV_BAIDU_SECRET_KEY", "_create_paddleocr_instance",
                       "_auto_install_paddleocr"):
            self.assertFalse(
                hasattr(ocr_engine, symbol),
                f"模块不应再导出百度 OCR / PaddleOCR 相关符号: {symbol}"
            )

    def test_no_paddle_dependency(self):
        """v11 不再依赖 paddlepaddle / paddleocr"""
        for symbol in ("paddle", "PaddleOCR"):
            self.assertFalse(hasattr(ocr_engine, symbol),
                             f"模块不应再引用 paddle 符号: {symbol}")


class TestFactoryReturnsNone(unittest.TestCase):
    """RapidOCR 不可用时工厂函数优雅返回 None（无密钥读取、不抛异常）"""

    def test_factory_returns_none_when_engine_unavailable(self):
        with patch('bid_checker.core.ocr_engine.RapidOCRBackend') as mock_backend:
            mock_instance = MagicMock()
            mock_instance._engine = None  # 模拟 RapidOCR 不可用
            mock_backend.return_value = mock_instance
            engine = create_ocr_engine("/nonexistent.json", verbose=False)
            # RapidOCR 也降级到 None 时，整个工厂函数返回 None
            self.assertIsNone(engine)

    def test_factory_returns_none_on_init_exception(self):
        with patch('bid_checker.core.ocr_engine.RapidOCRBackend',
                   side_effect=RuntimeError("model download failed")):
            engine = create_ocr_engine("/nonexistent.json", verbose=False)
            self.assertIsNone(engine)


class TestFactoryReturnsBackend(unittest.TestCase):
    """RapidOCR 可用时工厂函数返回 RapidOCRBackend 实例"""

    def test_factory_returns_backend_when_available(self):
        with patch('bid_checker.core.ocr_engine.RapidOCRBackend') as mock_backend:
            mock_instance = MagicMock()
            mock_instance._engine = object()  # 非 None 表示可用
            mock_instance.backend_name = 'rapidocr'
            mock_backend.return_value = mock_instance
            engine = create_ocr_engine("/nonexistent.json", verbose=False)
            self.assertIs(engine, mock_instance)
            self.assertEqual(engine.backend_name, 'rapidocr')


if __name__ == "__main__":
    unittest.main(verbosity=2)
