#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bid_checker.core.interactive_fill — Stage 3.5 交互式补全 (v9.0 脚本化)
==============================================================

将原 SKILL.md 中的 Stage 3.5 交互式补全流程从"模型自行执行"固化为可执行 Python 脚本。
弱模型也能通过运行本脚本完成 Stage 3.5，避免漏问 / 问错 / 跳过关键 P0 字段。

核心能力：
  1. 从填入需求报告中提取 status="missing" 的条目
  2. 按优先级分类（P0 必填 / P1 必填 / P2 建议 / P3 可选）
  3. 批量生成提问文本（可直接展示给用户）
  4. 解析用户回复（"1A 2B 3:张三" 等快捷语法）
  5. 调用 OCR 补充缺失字段（可选）
  6. 生成 user_supplements.json
  7. 将补充数据注入 project_config.json 的 business_rules

用法：
    # 命令行模式
    python -m bid_checker.core.interactive_fill \
        --report "{项目名}_填入需求报告.md" \
        --project-name "{项目名}" \
        --non-interactive  # 不交互，仅生成空模板供用户填写

    # 程序调用
    from bid_checker.core.interactive_fill import InteractiveFiller
    filler = InteractiveFiller(report_path, project_name)
    questions = filler.collect_missing_fields()
    answers = filler.parse_user_reply("1A 2:张三 3B")
    filler.save_supplements(answers)
"""

import os
import re
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from bid_checker.utils.logger import get_logger
# v20.3.2: load_json 从 bid_checker.core.utils 迁移至此
def load_json(path):
    """加载 JSON 文件，失败时返回空 dict"""
    if not path:
        return {}
    import json as _json
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return _json.load(f)
    except (_json.JSONDecodeError, OSError) as e:
        import logging
        logging.getLogger('interactive_fill').error('JSON 加载失败: %s -> %s', path, e)
        return {}

_logger = get_logger("bid_checker.core.interactive_fill")


# ============================================================
# 优先级分类（与 SKILL.md Stage 3.5 表格一致）
# ============================================================

# P0 必填项：投标人名称 / 法定代表人 / 被授权人
P0_FIELDS = {
    "投标人名称", "投标人", "供应商名称", "公司名称", "公司全称",
    "法定代表人姓名", "法定代表人", "法人姓名",
    "被授权人姓名", "被授权人", "授权代表姓名", "授权代表",
}

# P1 必填项：身份证号 / 性别 / 年龄 / 联系方式
P1_FIELDS = {
    "法人性别", "法人年龄", "法人身份证号", "法定代表人身份证号",
    "被授权人性别", "被授权人年龄", "被授权人身份证号",
    "联系电话", "联系地址", "联系方式",
}

# P2 建议项：项目编号 / 开标日期
P2_FIELDS = {
    "项目编号", "项目代码",
    "开标日期", "开标时间", "投标日期",
}

# P3 可选项：其他
# 不在 P0/P1/P2 中的字段统一归为 P3


def classify_priority(field_name: str) -> str:
    """根据字段名判断优先级"""
    if field_name in P0_FIELDS:
        return "P0"
    if field_name in P1_FIELDS:
        return "P1"
    if field_name in P2_FIELDS:
        return "P2"
    return "P3"


# ============================================================
# 主类：InteractiveFiller
# ============================================================

class InteractiveFiller:
    """
    Stage 3.5 交互式补全引擎。

    工作流：
      1. __init__ 加载填入需求报告
      2. collect_missing_fields() 提取所有 status="missing" 字段并分类
      3. generate_questions() 生成提问文本（可直接展示给用户）
      4. parse_user_reply() 解析用户回复
      5. save_supplements() 生成 user_supplements.json
      6. inject_into_config() 注入 project_config.json
    """

    def __init__(self, report_path: str, project_name: str,
                 work_dir: Optional[str] = None):
        """
        Args:
            report_path: 填入需求报告 .md 文件路径
            project_name: 项目名称
            work_dir: 工作目录（默认为 report_path 所在目录）
        """
        self.report_path = Path(report_path)
        self.project_name = project_name
        self.work_dir = Path(work_dir) if work_dir else self.report_path.parent

        if not self.report_path.exists():
            raise FileNotFoundError(f"填入需求报告不存在: {self.report_path}")

        # 加载报告内容
        try:
            self.report_text = self.report_path.read_text(encoding="utf-8")
        except OSError as e:
            raise RuntimeError(f"报告读取失败: {e}") from e

        # 尝试加载映射数据 JSON（用于获取 AI 疑似值）
        self.missing_fields: List[Dict[str, Any]] = []
        self._ai_suggestions: Dict[str, List[Tuple[str, str, float]]] = {}

    # ----------------------------------------------------------
    # Step 3.5-1: 从报告中提取缺失项
    # ----------------------------------------------------------

    def collect_missing_fields(self) -> List[Dict[str, Any]]:
        """
        从填入需求报告中提取所有 status="missing" 的字段。

        Returns:
            缺失字段列表，每项包含：
              - field_name: 字段名
              - priority: P0/P1/P2/P3
              - source_section: 报告中出现的章节
              - ai_suggestions: AI 疑似值列表 [(value, source, confidence)]
        """
        _logger.info("开始提取缺失字段: %s", self.report_path.name)

        # 简易解析：从 markdown 表格中提取缺失项
        # 表格格式参考：| 字段名 | 状态 | 来源 | 值 |
        missing = []
        seen_fields = set()

        # 匹配 markdown 表格行
        # 简化模式：找包含"missing"或"缺失"的行
        table_row_pattern = re.compile(
            r'\|\s*([^|]+)\s*\|\s*([^|]*)\s*\|\s*([^|]*)\s*\|\s*([^|]*)\s*\|'
        )

        lines = self.report_text.splitlines()
        for line in lines:
            if '|' not in line:
                continue
            m = table_row_pattern.match(line.strip())
            if not m:
                continue

            field_name = m.group(1).strip()
            status = m.group(2).strip()
            source = m.group(3).strip()
            value = m.group(4).strip()

            # 跳过表头和分隔行
            if field_name in ('字段名', '名称', '---', '---') or field_name.startswith('---'):
                continue
            if 'missing' not in status.lower() and '缺失' not in status and '未匹配' not in status:
                continue
            if not field_name or field_name in seen_fields:
                continue

            priority = classify_priority(field_name)
            missing.append({
                "field_name": field_name,
                "priority": priority,
                "source_section": source,
                "ai_suggestions": [],
                "current_value": value if value and value != "—" else None,
            })
            seen_fields.add(field_name)

        # 按优先级排序
        priority_order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
        missing.sort(key=lambda x: priority_order.get(x["priority"], 99))

        self.missing_fields = missing
        _logger.info("提取完成: %d 个缺失字段 (P0=%d, P1=%d, P2=%d, P3=%d)",
                     len(missing),
                     sum(1 for m in missing if m["priority"] == "P0"),
                     sum(1 for m in missing if m["priority"] == "P1"),
                     sum(1 for m in missing if m["priority"] == "P2"),
                     sum(1 for m in missing if m["priority"] == "P3"))
        return missing

    # ----------------------------------------------------------
    # Step 3.5-2: 生成批量提问
    # ----------------------------------------------------------

    def generate_questions(self) -> str:
        """
        生成批量提问文本（可直接展示给用户）。

        格式遵循 SKILL.md Stage 3.5 的话术模板：
          ━━ P0 必填项 ━━
          1. 投标人名称（公司全称）
             AI已在资料中找到以下疑似值，请确认或修正：
             A. 陕西XX商贸有限公司（来源：营业执照OCR，置信度90%）
             B. 我直接告诉你：_____
             C. 资料中没有，先不填（标黄提醒）
          ...

          ━━ 快捷回复 ━━
          - "1A 2A 3A" = 全部选择A选项
          - "1:陕西XX 2:张三" = 直接输入值
        """
        if not self.missing_fields:
            self.collect_missing_fields()

        if not self.missing_fields:
            return "✓ 所有字段均已匹配，无需交互补全。"

        lines = [
            "【第3.5阶段 — 缺失项补全】",
            "",
            "以下字段未能从资料中自动匹配，需要您协助补充：",
            "（可以直接输入值，或告诉我去哪里找）",
            "",
        ]

        current_priority = None
        priority_headers = {
            "P0": "━━ P0 必填项（不可跳过）━━",
            "P1": "━━ P1 必填项 ━━",
            "P2": "━━ P2 建议项 ━━",
            "P3": "━━ P3 可选项 ━━",
        }

        for idx, field in enumerate(self.missing_fields, start=1):
            if field["priority"] != current_priority:
                current_priority = field["priority"]
                lines.append("")
                lines.append(priority_headers.get(current_priority, "━━ 其他 ━━"))
                lines.append("")

            lines.append(f"{idx}. {field['field_name']}")

            # AI 疑似值
            suggestions = field.get("ai_suggestions", [])
            if suggestions:
                for letter, (val, src, conf) in zip("ABCD", suggestions):
                    lines.append(f"   {letter}. {val}（来源：{src}，置信度{int(conf*100)}%）")
                next_letter = chr(ord('A') + len(suggestions))
                lines.append(f"   {next_letter}. 我直接告诉你：_____")
                skip_letter = chr(ord('A') + len(suggestions) + 1)
                lines.append(f"   {skip_letter} 资料中没有，先不填（标黄提醒）")
            else:
                lines.append("   A. 我直接告诉你：_____")
                if field["priority"] == "P0":
                    lines.append("   B. 资料中没有，先不填（P0 必填，强烈建议补全）")
                else:
                    lines.append("   B. 资料中没有，先不填（标黄提醒）")
            lines.append("")

        # 快捷回复说明
        lines.append("━━ 快捷回复 ━━")
        lines.append("")
        lines.append('- "1A 2A 3A" = 全部选择 A 选项')
        lines.append('- "1:陕西XX 2:张三" = 直接输入值')
        lines.append('- "全部A" = 所有项选择 A 选项')
        lines.append('- "全部跳过" = 所有项标黄不填（P0 项除外）')

        return "\n".join(lines)

    # ----------------------------------------------------------
    # Step 3.5-3: 解析用户回复
    # ----------------------------------------------------------

    def parse_user_reply(self, reply: str) -> Dict[str, str]:
        """
        解析用户回复，生成 {field_name: value} 字典。

        支持的语法：
          - "1A 2B 3C"            → 第 N 项选择对应字母
          - "1:张三 2:138xxx"     → 第 N 项直接输入值
          - "全部A"               → 所有项选择 A
          - "全部跳过"            → 所有项跳过
          - "1A 2:张三 全部跳过"  → 混合（前面已指定的覆盖"全部"）

        Args:
            reply: 用户回复文本

        Returns:
            {field_name: value} 字典（跳过的字段不出现在字典中）
        """
        if not self.missing_fields:
            self.collect_missing_fields()

        reply = reply.strip()
        result: Dict[str, str] = {}
        skipped: set = set()

        # 处理"全部跳过"
        if "全部跳过" in reply:
            for field in self.missing_fields:
                if field["priority"] != "P0":  # P0 不允许跳过
                    skipped.add(field["field_name"])
            _logger.info("用户选择全部跳过（P0 项除外）")

        # 处理"全部A"
        all_a_match = re.search(r'全部([A-D])', reply)
        if all_a_match:
            default_letter = all_a_match.group(1)
            for idx, field in enumerate(self.missing_fields, start=1):
                if field["field_name"] in skipped:
                    continue
                if field["field_name"] in result:
                    continue
                # 应用默认字母（A = 第一个 AI 疑似值，或直接输入）
                suggestions = field.get("ai_suggestions", [])
                if default_letter == "A" and suggestions:
                    val, src, _ = suggestions[0]
                    result[field["field_name"]] = val
                elif default_letter == "A" and not suggestions:
                    # A 在无 suggestions 时 = "我直接告诉你"，无值
                    pass

        # 处理 "1A 2B 3C" 语法
        letter_pattern = re.compile(r'(\d+)([A-D])')
        for m in letter_pattern.finditer(reply):
            idx = int(m.group(1))
            letter = m.group(2)
            if idx < 1 or idx > len(self.missing_fields):
                continue
            field = self.missing_fields[idx - 1]
            field_name = field["field_name"]

            if field_name in skipped:
                skipped.discard(field_name)

            suggestions = field.get("ai_suggestions", [])
            letter_idx = ord(letter) - ord('A')

            if letter_idx < len(suggestions):
                val, src, _ = suggestions[letter_idx]
                result[field_name] = val
            elif letter_idx == len(suggestions) or (not suggestions and letter == "A"):
                # "我直接告诉你" — 无值，等用户后续补充
                pass
            else:
                # 跳过
                if field["priority"] != "P0":
                    skipped.add(field_name)

        # 处理 "1:张三 2:138xxx" 语法
        value_pattern = re.compile(r'(\d+):([^\s\d]+)')
        for m in value_pattern.finditer(reply):
            idx = int(m.group(1))
            value = m.group(2)
            if idx < 1 or idx > len(self.missing_fields):
                continue
            field = self.missing_fields[idx - 1]
            field_name = field["field_name"]
            if field_name in skipped:
                skipped.discard(field_name)
            result[field_name] = value

        _logger.info("用户回复解析完成: %d 个字段已补全, %d 个字段跳过",
                     len(result), len(skipped))
        return result

    # ----------------------------------------------------------
    # Step 3.5-4: 保存 user_supplements.json
    # ----------------------------------------------------------

    def save_supplements(self, fields: Dict[str, str]) -> Path:
        """
        保存用户补充数据为 user_supplements.json。

        Args:
            fields: {field_name: value} 字典

        Returns:
            保存的文件路径
        """
        output_path = self.work_dir / f"{self.project_name}_用户补充数据.json"

        data = {
            "project_name": self.project_name,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "fields": fields,
        }

        try:
            output_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
            _logger.info("用户补充数据已保存: %s (%d 个字段)",
                         output_path.name, len(fields))
        except OSError as e:
            raise RuntimeError(f"保存失败: {e}") from e

        return output_path

    # ----------------------------------------------------------
    # Step 3.5-5: 注入 project_config.json
    # ----------------------------------------------------------

    def inject_into_config(self, config_path: Optional[str] = None) -> Path:
        """
        将补充数据注入 project_config.json 的 business_rules。

        Args:
            config_path: project_config.json 路径（默认为 work_dir 下）

        Returns:
            注入后的配置文件路径
        """
        if config_path is None:
            config_path = self.work_dir / "project_config.json"
        config_path = Path(config_path)

        if not config_path.exists():
            _logger.warning("配置文件不存在，将创建: %s", config_path)
            config = {
                "project_name": self.project_name,
                "paths": {},
                "business_rules": {},
            }
        else:
            config = load_json(str(config_path))

        # 加载补充数据
        supplements_path = self.work_dir / f"{self.project_name}_用户补充数据.json"
        if not supplements_path.exists():
            raise FileNotFoundError(f"补充数据文件不存在: {supplements_path}")

        supplements = load_json(str(supplements_path))
        fields = supplements.get("fields", {})

        # 注入 business_rules
        br = config.setdefault("business_rules", {})
        for k, v in fields.items():
            br[k] = v

        # 保存
        try:
            config_path.write_text(
                json.dumps(config, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
            _logger.info("补充数据已注入配置: %s (%d 个字段)",
                         config_path.name, len(fields))
        except OSError as e:
            raise RuntimeError(f"配置保存失败: {e}") from e

        return config_path


# ============================================================
# CLI 入口
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Stage 3.5 交互式补全 v9.0")
    parser.add_argument("--report", required=True,
                        help="填入需求报告 .md 文件路径")
    parser.add_argument("--project-name", required=True,
                        help="项目名称")
    parser.add_argument("--work-dir",
                        help="工作目录（默认为报告所在目录）")
    parser.add_argument("--non-interactive", action="store_true",
                        help="非交互模式：仅生成空模板供用户填写")
    parser.add_argument("--config",
                        help="project_config.json 路径（用于注入）")
    args = parser.parse_args()

    filler = InteractiveFiller(
        report_path=args.report,
        project_name=args.project_name,
        work_dir=args.work_dir,
    )

    # 收集缺失字段
    missing = filler.collect_missing_fields()
    if not missing:
        print("✓ 所有字段均已匹配，无需补全")
        return 0

    if args.non_interactive:
        # 非交互模式：生成提问文本输出到 stdout
        questions = filler.generate_questions()
        print(questions)
        print("\n--- 非交互模式 ---")
        print("请将上述问题展示给用户，收集回复后用 --reply 参数继续")
        return 0

    # 交互模式
    questions = filler.generate_questions()
    print(questions)
    print()
    reply = input("请输入您的回复（按回车跳过）: ").strip()

    if not reply:
        print("未收到回复，跳过补全")
        return 0

    fields = filler.parse_user_reply(reply)
    if not fields:
        print("未解析到有效字段")
        return 0

    # 保存
    saved_path = filler.save_supplements(fields)
    print(f"✓ 补充数据已保存: {saved_path}")

    # 注入配置
    if args.config:
        injected_path = filler.inject_into_config(args.config)
        print(f"✓ 已注入配置: {injected_path}")

    return 0


# ============================================================
# P1: 资料缺口确认引擎 (v20.3+)
# ============================================================

MATERIAL_TYPE_DESCRIPTIONS = {
    '法定代表人身份证明': '法人身份证（正反面）+ 法人身份证明文本',
    '法定代表人授权委托书': '授权委托书 + 被授权人身份证（正反面）',
    '商务条款偏离表': '商务条款偏离表（含逐行响应）',
    '技术参数条款偏离表': '技术参数偏离表（含逐行响应）',
    '拟投入人员': '项目人员汇总表 + 人员身份证/学历/资质证书',
    '资质证明文件': '营业执照 + 财务审计报告 + 社保证明 + 纳税证明 + 信用查询 + 资质证书',
    '业绩': '类似项目业绩合同（含合同关键页）',
    '报价表': '报价表（含总价 + 分项明细）',
}


class MaterialGapFiller:
    """
    P1: 资料缺口确认引擎。

    与 InteractiveFiller（字段级补全）配合使用：
      - InteractiveFiller: 问"投标人名称没找到，请补充值"
      - MaterialGapFiller: 问"项目人员资料整类缺失，请指定文件位置或跳过"
    """

    def __init__(self, mapping_json_path: str, project_name: str,
                 work_dir=None):
        self.mapping_json_path = Path(mapping_json_path)
        self.project_name = project_name
        self.work_dir = Path(work_dir) if work_dir else self.mapping_json_path.parent

        if not self.mapping_json_path.exists():
            raise FileNotFoundError(f"需求映射 JSON 不存在: {self.mapping_json_path}")

        try:
            with open(self.mapping_json_path, 'r', encoding='utf-8') as f:
                self.mapping_data = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            raise RuntimeError(f"映射 JSON 加载失败: {e}") from e

        self.gaps = []

    def collect_material_gaps(self):
        """按资料类型聚合缺失项"""
        _logger.info("开始收集资料缺口...")

        results = self.mapping_data.get('results', [])
        if not results:
            _logger.warning("映射数据中无 results 字段")
            return []

        category_items = {}
        for r in results:
            category = r.get('chapter') or r.get('category') or ''
            if not category:
                req_id = r.get('req_id', '')
                if '_' in req_id:
                    prefix = req_id.split('_')[0]
                    category = {
                        'ch2': '法定代表人身份证明',
                        'ch3': '法定代表人授权委托书',
                        'ch4': '商务条款偏离表',
                        'ch5': '技术参数条款偏离表',
                        'ch6': '拟投入人员',
                        'ch7': '资质证明文件',
                        'ch11': '业绩',
                    }.get(prefix, '')
            if not category:
                continue
            category_items.setdefault(category, []).append(r)

        gaps = []
        for category, items in category_items.items():
            missing_items = [i for i in items if i.get('status') == 'missing']
            if not missing_items:
                continue
            severity = 'critical' if len(missing_items) == len(items) else 'partial'
            description = MATERIAL_TYPE_DESCRIPTIONS.get(category, category)
            gaps.append({
                'category': category,
                'description': description,
                'missing_items': missing_items,
                'total_items': len(items),
                'missing_count': len(missing_items),
                'severity': severity,
            })

        gaps.sort(key=lambda x: (0 if x['severity'] == 'critical' else 1, -x['missing_count']))
        self.gaps = gaps
        _logger.info(f"收集完成: {len(gaps)} 类资料有缺口")
        return gaps

    def generate_gap_questions(self):
        """生成资料缺口提问文本"""
        if not self.gaps:
            self.collect_material_gaps()
        if not self.gaps:
            return "✓ 所有资料类型均已匹配，无缺口。"

        lines = [
            "【Stage 3.5 资料缺口确认】",
            "",
            "以下资料类型在您的资料文件夹中未找到对应文件：",
            "",
        ]

        for idx, gap in enumerate(self.gaps, start=1):
            severity_icon = "🔴" if gap['severity'] == 'critical' else "⚠️"
            severity_label = "整类缺失" if gap['severity'] == 'critical' else "部分缺失"
            lines.append(f"{idx}. {severity_icon} {gap['category']}（{severity_label}）")
            lines.append(f"   说明：{gap['description']}")
            lines.append(f"   缺失条目：{gap['missing_count']}/{gap['total_items']} 项")
            lines.append("")
            lines.append(f"   请选择：")
            lines.append(f"   A. 指定文件位置：告诉我文件路径（如 D:/资料/人员表.docx）")
            lines.append(f"   B. 跳过（标黄提醒，手动填写）")
            if gap['severity'] == 'critical':
                lines.append(f"   ⚠️ 整类缺失，建议补充文件以确保评分覆盖")
            lines.append("")

        lines.append("━━ 快捷回复 ━━")
        lines.append("")
        lines.append('- "1A D:/资料/人员表.docx" = 第1项指定文件')
        lines.append('- "1B" = 第1项跳过')
        lines.append('- "全部跳过" = 所有缺口项跳过')

        return "\n".join(lines)

    def parse_gap_reply(self, reply):
        """解析用户回复"""
        if not self.gaps:
            self.collect_material_gaps()
        reply = reply.strip()
        result = {}

        if "全部跳过" in reply:
            for idx in range(1, len(self.gaps) + 1):
                result[idx] = {'action': 'skip'}
            _logger.info(f"用户选择全部跳过（{len(result)} 项）")
            return result

        pattern = re.compile(r'(\d+)\s*([AB])\s*([^\d\n]*)')
        for m in pattern.finditer(reply):
            idx = int(m.group(1))
            action_code = m.group(2)
            file_path = m.group(3).strip()
            if action_code == 'A':
                if file_path:
                    result[idx] = {'action': 'specify', 'file': file_path}
                else:
                    result[idx] = {'action': 'needs_file'}
            elif action_code == 'B':
                result[idx] = {'action': 'skip'}

        _logger.info(f"用户回复解析: {len(result)} 项操作")
        return result

    def apply_gap_reply(self, reply):
        """应用用户回复"""
        if not self.gaps:
            self.collect_material_gaps()
        parsed = self.parse_gap_reply(reply)
        result = {'specify': [], 'skip': [], 'unhandled': []}

        for idx, gap in enumerate(self.gaps, start=1):
            action = parsed.get(idx)
            if action is None:
                result['unhandled'].append(gap)
            elif action['action'] == 'specify':
                gap['user_specified_file'] = action.get('file', '')
                result['specify'].append(gap)
                _logger.info(f"  {gap['category']}: 用户指定文件 {action.get('file', '')}")
            elif action['action'] == 'skip':
                result['skip'].append(gap)
                _logger.info(f"  {gap['category']}: 用户选择跳过")

        for gap in result['unhandled']:
            _logger.warning(f"  {gap['category']}: 未处理，将标黄")

        return result


if __name__ == "__main__":
    sys.exit(main())
