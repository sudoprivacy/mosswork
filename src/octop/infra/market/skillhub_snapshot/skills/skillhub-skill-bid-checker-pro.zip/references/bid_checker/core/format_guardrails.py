# -*- coding: utf-8 -*-
"""
format_guardrails.py — 投标文件填充「格式护栏 / 自检」通用模块
=======================================================================

为什么需要它（踩过的坑，已固化为机械规则，不再依赖 AI 临场判断）：

  BUG-1  标签后多余空格导致排版断裂（如 "投标人：  XX公司" 多出空格、
         甚至把封面顶成两页）。根因回填正则把标签后的空白吞进了标签本身。
  BUG-2  章节标题前没有强制分页，所有章节挤在一起。
  BUG-3  签字 / （盖章）位置被误填，本应留空手签。
  BUG-4  残留锚点 token（[[FILL:]] / [[SLOT:]]）未被清理。
  BUG-5  年龄等派生字段取了资料自报值而非由身份证号推导（规则4）。

设计哲学：
  「人类的手感」= 把反复犯的格式错误抽象成「不变量（invariant）」，用机械程序
  在每次保存前强制校验+自动修复。AI 不需要每次重新"想到"这些，护栏兜底。

本模块对任何回填产物都可独立运行（与具体项目解耦）：
    python format_guardrails.py input.docx --fix --out output.docx
或在回填脚本末尾调用：
    from format_guardrails import run_guardrails
    report = run_guardrails(doc, auto_fix=True)
"""

import re
import json
from docx import Document


# --------------------------------------------------------------------------
# 不变量 1：标签冒号后不允许有空格（中文标书里 "标签：值" 永远紧贴）
# --------------------------------------------------------------------------
_COLON_WS = re.compile(r'([：:])\s+(?=\S)')          # 冒号后紧跟非空白前的空格
_LABEL_TRAIL = re.compile(r'([一-鿿A-Za-z0-9]+[：:])\s+(?=\S)')
_LEAD_WS = re.compile(r'(?<=\S)\s+([一-鿿A-Za-z0-9]+[：:])')  # 值前、标签前的空格（少用）


def _font_props(r):
    """提取 run 的字体属性快照（用于精确复刻）。"""
    f = r.font
    color = None
    try:
        if f.color is not None and f.color.type is not None:
            color = f.color.rgb
    except Exception:
        color = None
    return {
        'size': f.size, 'bold': f.bold, 'italic': f.italic,
        'name': f.name, 'color': color, 'underline': f.underline,
    }


def _apply_font(r, props):
    if not props:
        return
    f = r.font
    f.size = props.get('size')
    f.bold = props.get('bold')
    f.italic = props.get('italic')
    f.name = props.get('name')
    col = props.get('color')
    if col is not None:
        try:
            f.color.rgb = col
        except Exception:
            pass


def _ref_font_props(runs_snapshot, pos):
    """取替换区域起点所在 run 的字体作为「值」的参考字体（通常是字段标签 run，
    而非占位符小字 run）。"""
    acc = 0
    for (rt, props) in runs_snapshot:
        if rt and acc < pos <= acc + len(rt):
            return props
        acc += len(rt)
    for (rt, props) in runs_snapshot:
        if rt:
            return props
    return None


def replace_placeholder(p, new_text, val_start, val_end, had_underline):
    """v20 精确回填原语：保留未改动前缀的原 run 格式；被替换的「值」用参考字体
    （标签 run，非占位符小字）；下划线仅加到 [val_start, val_end) 区域（若该占位符
    原带下划线）；文本逐字复刻，不丢空格。

    解决三层老问题：① 字体变小（继承占位符小字）② 下划线整段 ③ 空格被吃。"""
    # 1) 快照原 run（含格式）后清空段落 run
    orig = [(r.text, _font_props(r)) for r in p.runs]
    ref = _ref_font_props(orig, val_start)
    for r in list(p.runs):
        r._r.getparent().remove(r._r)

    def _add(text, props=None, underline=False):
        if not text:
            return
        nr = p.add_run(text)
        _apply_font(nr, props)
        nr.font.underline = bool(underline)

    # 2) 前缀（[0, val_start) 未改动）按原 run 格式逐段复刻
    acc = 0
    for (rt, props) in orig:
        if acc >= val_start:
            break
        take = min(len(rt), val_start - acc)
        if take > 0:
            _add(rt[:take], props)
        acc += len(rt)
    # 3) 被替换的值
    val = new_text[val_start:val_end]
    _add(val, ref, underline=(had_underline and bool(val)))
    # 4) 后缀（改动后的剩余，通常为另一字段/落款）用参考字体
    suffix = new_text[val_end:]
    _add(suffix, ref, underline=False)


def _set_para_text_keep(p, new_text, underline_after=None):
    """向后兼容包装：旧调用方（护栏/正则整体替换）无「替换区域」信息时，
    退化为整段替换（沿用首 run 格式）。新填充逻辑请用 replace_placeholder。
    v20.3.1: 改进——如果原段落有下划线 run，尽量保留下划线格式。"""
    if not p.runs:
        run = p.add_run(new_text)
        if underline_after == 0:
            run.font.underline = True
        return

    # v20.3.1: 检测原段落下划线状态
    had_underline = any(getattr(r.font, 'underline', None) for r in p.runs if r.text)
    if underline_after is None and had_underline:
        underline_after = 0

    first = p.runs[0]
    # 清掉其它 run 的文本，首 run 承载全部
    for r in p.runs[1:]:
        r.text = ''

    # v20.3.1: 保留首 run 的原始字体格式（不强制覆盖 underline）
    # 如果 underline_after 指定了，按指定位置拆分
    if underline_after is not None and 0 < underline_after < len(new_text):
        # 拆成两段：前缀不加下划线，后缀加下划线
        prefix = new_text[:underline_after]
        suffix = new_text[underline_after:]
        first.text = prefix
        first.font.underline = False
        # 在原段落追加后缀 run
        run = p.add_run(suffix)
        run.font.underline = True
    elif underline_after == 0:
        # 整段加下划线
        first.text = new_text
        first.font.underline = True
    else:
        # v20.3.1: 不强制设 underline=False，保留首 run 原始格式
        first.text = new_text
        # 只有在原段落无下划线时才显式设 False
        if not had_underline:
            first.font.underline = False


# --------------------------------------------------------------------------
# 文本填充原语（供 Stage 4 消费端调用；与 image_format 的图片原语对称）
# 这些函数只做「标签定位 + 精确填值 + 清多余空格」，不写任何尺寸/分页逻辑。
# --------------------------------------------------------------------------
def _has_underline_in_range(p, start, end):
    """判断段落中 [start, end) 字符范围内是否有任意 run 带下划线。"""
    pos = 0
    for r in p.runs:
        rt = r.text
        if not rt:
            continue
        r_start = pos
        r_end = pos + len(rt)
        pos = r_end
        if r_end <= start or r_start >= end:
            continue
        if getattr(r.font, 'underline', None):
            return True
    return False


def _clear_first_line_indent_if_letter(p):
    """如果段落是函件开头（致：XXX），清除首行缩进。"""
    t = p.text.strip()
    if t.startswith('致') and ('：' in t or ':' in t):
        pf = p.paragraph_format
        if pf.first_line_indent is not None:
            pf.first_line_indent = None


def _is_addressee_token(token):
    """占位 token 是否为收件人/招标人名称类（如 '（招标人名称）'）。"""
    return bool(re.search(r'[（(](?:招标人|采购人|单位|甲方|业主|名称|[致送]往?).{0,10}?[）)]', token))


def _clear_indent_for_addressee(p, new_text, token):
    """如果填充的是函件抬头（'（招标人名称）：'），清除首行缩进并去掉前导空格。"""
    if not _is_addressee_token(token):
        return new_text
    t = new_text.strip()
    if t.endswith('：') or t.startswith('致') or t.startswith('送'):
        pf = p.paragraph_format
        if pf.first_line_indent is not None:
            pf.first_line_indent = None
        return new_text.lstrip()
    return new_text


def label_re(label):
    """允许标签各字之间有任意空白，但末尾不吞后续空格（否则 '投标人：  值' 整体被当标签）。"""
    chars = list(label)
    if not chars:
        return re.compile('')
    parts = [re.escape(chars[0])] + [r'\s*' + re.escape(c) for c in chars[1:]]
    return re.compile(''.join(parts))


_HINT_PAREN = re.compile(r'(公章|签字|盖章|签名|签章|鲜章|骑缝|印)')


def _is_hint_paren(text):
    """判断括号里的内容是否为「落款提示语」（全称并加盖公章/签字或盖章…），
    而非占位 token（招标人名称）。有填充内容时应删除落款提示语。"""
    return bool(_HINT_PAREN.search(text))


def fill_after_label(p, label, value, preserve_after=None):
    """在段落中找到 label，把「其后字段值」替换为 value。

    填充语义 = 替换。关键规则（v20）：
      - 有填充内容(value 非空) 且其后紧跟落款提示括号（如（全称并加盖公章）），
        则删除该提示括号（用户要求：带括号提示语，填了就删）。
      - 无填充（value 空）则保留括号提示语不动。
      - 仅被替换的「值」区域加下划线（若该占位符原带下划线），其余不动。
      - 值字体继承标签 run（非占位符小字）；文本逐字复刻，不丢空格。"""
    rx = label_re(label)
    m = rx.search(p.text)
    if not m:
        return False
    idx = m.end()
    head = p.text[:idx]
    tail = p.text[idx:]
    # 护栏：标签后紧跟闭括号（如 “（项目编号： ）” 内部），说明这是括号占位，
    # 应交由 fill_inline_paren 处理；此处若填会误吞括号外文本。跳过。
    # v20.3.1 修复：仅当 tail 紧跟闭括号（中间无下划线/空格占位符）时才跳过。
    # 如果 tail 是 "____）" 或 "  ）" 这种（中间有占位符），说明是 "标签：____）" 格式，
    # 应该填充值而不是跳过（修复 P1：项目编号未填写）。
    tail_stripped = tail.lstrip()
    if tail_stripped.startswith(('）', ')', '】', ']')):
        # 紧跟闭括号 → 跳过（交给 fill_inline_paren）
        return False
    # 如果 tail 是 "____）" 或 "_）" 格式（下划线后跟闭括号），不跳过，继续填充
    if preserve_after and preserve_after in tail:
        suff = tail[tail.index(preserve_after):]
        new_tail = (value or '') + suff
    else:
        br = tail.find('（')
        if br >= 0:
            hint = tail[br:]
            if value and _is_hint_paren(hint):
                # 已填充 -> 删掉落款提示括号
                new_tail = value
            else:
                new_tail = (value or '') + hint
        else:
            rest = tail.lstrip()
            if re.match(r'^[一-鿿A-Za-z0-9]+[：:]', rest):
                # 同段紧跟另一个字段标签，保留并前置新值
                new_tail = (value or '') + ' ' + rest
            else:
                # v20.3.3: 空 / 占位符 / 已预填旧值 -> 整体替换
                # 如果 tail 是纯空格（无占位符无已有值），直接在冒号后插入 value
                if tail.strip() == '' and value:
                    new_tail = value
                else:
                    new_tail = (value or '')
    new_text = head + new_tail
    val_start = len(head)
    val_end = val_start + len(value or '')
    # 仅「标签后原占位符部分」带下划线时，给值区域加下划线
    had_ul = _has_underline_in_range(p, idx, len(p.text))
    replace_placeholder(p, new_text, val_start, val_end, had_ul)
    _clear_first_line_indent_if_letter(p)
    return True


def fill_inline_token(p, token, value):
    """把段落中的占位 token（如 '（投标人名称）'/'（招标人名称）'）替换为 value，
    精确保留格式/下划线/空格，并清理抬头缩进。不做激进空格折叠（避免吃掉落款前空格）。
    v20.3.3: 替换后清理 token 两侧的多余空格和下划线占位符。"""
    if token not in p.text:
        return False
    pos = p.text.index(token)
    had_ul = _has_underline_in_range(p, pos, pos + len(token))
    new_text = p.text.replace(token, value or '')
    if value:
        new_text = _clear_indent_for_addressee(p, new_text, token)
        val_start = new_text.index(value) if value in new_text else pos
    else:
        val_start = pos
    val_end = val_start + len(value or '')
    replace_placeholder(p, new_text, val_start, val_end, had_ul)
    _clear_first_line_indent_if_letter(p)
    return True


def fill_inline_paren(p, label, value):
    """把 '（项目编号：   ）' 这种括号占位替换为 '（项目编号：VALUE）'，兼容内部空格。"""
    m = re.search(r'（\s*' + re.escape(label) + r'\s*[:：][^）]*）', p.text)
    if m:
        had_ul = _has_underline_in_range(p, m.start(), m.end())
        new_text = p.text[:m.start()] + '（%s：%s）' % (label, value or '') + p.text[m.end():]
        underline_after = m.start() if had_ul else None
        _set_para_text_keep(p, new_text, underline_after=underline_after)
        _clear_first_line_indent_if_letter(p)
        return True
    return False


def fix_label_whitespace(doc):
    """不变量1：清理每个段落中 '：' 后、值前的多余空格；并清理标签与值之间的空白。
    返回修复的段落数。
    v20.3.1: 增加签名位例外——冒号后紧跟（全称/签字/盖章）等提示语时不删空格。"""
    cnt = 0
    # v20.3.1: 签名位提示语模式（这些括号前的空格是手动签字用的，不能删）
    _SIGN_HINT_PAREN = re.compile(r'[（(](?:全称|签字|盖章|签名|签章|盖章）|签字或盖章)')
    for p in doc.paragraphs:
        txt = p.text
        # v20.3.1: 检查是否含签名位提示语
        if _SIGN_HINT_PAREN.search(txt):
            # 含签名位 → 不做空格清理（保留手动签字空间）
            continue
        new = _COLON_WS.sub(r'\1', txt)
        if new != txt:
            _set_para_text_keep(p, new)
            cnt += 1
    return cnt


# --------------------------------------------------------------------------
# 不变量 2：章节标题前强制分页
# --------------------------------------------------------------------------
CHAPTER_PATTERNS = [
    re.compile(r'^第[一二三四五六七八九十百]+章[、\s]?[^，。；\n]{0,40}$'),
    re.compile(r'^[一二三四五六七八九十百]+、[^，。；\n]{1,40}$'),
    re.compile(r'^[（(][一二三四五六七八九十百]+[）)]、?[^，。；\n]{1,40}$'),
]


def _is_toc_line(t):
    """目录条目识别：含点线引导符或纯 '条目...页码' 形态。"""
    if '......' in t or '….'.replace('…', '.') in t:
        return True
    if t.count('.') >= 3 and t.strip()[-1].isdigit():
        return True
    return False


def _looks_like_chapter(t, style_name):
    if style_name and 'toc' in style_name.lower():
        return False
    t = t.strip()
    if len(t) > 45:
        return False
    if _is_toc_line(t):
        return False
    return any(pat.match(t) for pat in CHAPTER_PATTERNS)


def ensure_chapter_page_breaks(doc):
    """不变量2：给所有章节标题设置 page_break_before=True。返回设置的段落数。"""
    cnt = 0
    for p in doc.paragraphs:
        style_name = p.style.name if p.style else ''
        if _looks_like_chapter(p.text, style_name):
            if not p.paragraph_format.page_break_before:
                p.paragraph_format.page_break_before = True
                cnt += 1
    return cnt


# --------------------------------------------------------------------------
# 不变量 3：签字 / 盖章位置必须留空
# --------------------------------------------------------------------------
# 完整的签字落款短语（全角括号），用作"签名位"边界
_SIGN_PHRASE = re.compile(r'[（(]签字[）)]|[（(]签字或盖章[）)]|[（(]盖章[）)]|[（(]签章[）)]')
# 这些次级标签出现时，说明该行是"多字段行"（如"授权代表：姓名 （签字） 性别：女"），
# （签字）是嵌在带值字段里的，不算纯签名位误填
_SECONDARY_LABELS = ('性别', '年龄', '身份证', '职务', '项目', '名称', '日期', '电话', '传真', '地址', '邮编')


def verify_signatures_empty(doc):
    """不变量3：扫描签名落款短语（签字/盖章），若其闭合括号之后被填入了实质内容则告警。
    返回告警列表。本函数只检查不自动删（避免误删真实内容）。

    判定逻辑（避免误报）：
      - 签名短语通常为 "...（签字或盖章）"，正确情况其后应为空白（手签区）。
      - 若其后有内容，但内容含次级标签（性别/年龄/身份证…），说明是"字段+嵌入签名"
        结构（如"授权代表：唐旻玥 （签字） 性别：女"），属正常填充，不告警。
      - 仅当签名短语位于行尾且无上述次级标签、却仍跟有实质内容时，才视为误填告警。
    """
    warnings = []
    for i, p in enumerate(doc.paragraphs):
        t = p.text
        m = _SIGN_PHRASE.search(t)
        if not m:
            continue
        tail = t[m.end():]
        tail_clean = re.sub(r'[\s（）()　、，。:：]', '', tail)
        if not tail_clean:
            continue  # 闭合后为空 → 正确留空
        if any(lb in tail for lb in _SECONDARY_LABELS):
            continue  # 多字段行，嵌入签名，正常
        if re.search(r'[一-鿿A-Za-z0-9]', tail_clean):
            warnings.append('段落#%d 签字/盖章位置疑似被误填: %r' % (i, t[:80]))
    return warnings


# --------------------------------------------------------------------------
# 不变量 4：残留锚点 token 必须清零
# --------------------------------------------------------------------------
_ANCHOR_RE = re.compile(r'\[\[(?:FILL|SLOT|ANCHOR)[^\]]*\]\]')


def verify_no_anchor_residue(doc):
    """不变量4：检测文档中是否残留 [[FILL:]]/[[SLOT:]] 等锚点 token。
    返回残留 token 列表。"""
    found = []
    full = '\n'.join(p.text for p in doc.paragraphs)
    for m in _ANCHOR_RE.finditer(full):
        found.append(m.group(0))
    for tbl in doc.tables:
        for row in tbl.rows:
            for cell in row.cells:
                if _ANCHOR_RE.search(cell.text):
                    found.append(cell.text[:40])
    return found


def strip_anchor_residue(doc):
    """不变量4（修复）：清除段落与表格单元格中的残留锚点 token。返回清除数。"""
    n = 0
    for p in doc.paragraphs:
        if _ANCHOR_RE.search(p.text):
            new = _ANCHOR_RE.sub('', p.text)
            _set_para_text_keep(p, new)
            n += 1
    for tbl in doc.tables:
        for row in tbl.rows:
            for cell in row.cells:
                if _ANCHOR_RE.search(cell.text):
                    new = _ANCHOR_RE.sub('', cell.text)
                    # 单元格首段落承载
                    if cell.paragraphs:
                        _set_para_text_keep(cell.paragraphs[0], new)
                    n += 1
    return n


# --------------------------------------------------------------------------
# 不变量 5：年龄等派生字段应由身份证号推导（规则4）
# --------------------------------------------------------------------------
def derive_age_from_id(id_number, base_year):
    """由 18 位身份证号出生日期 + 计算基准年推导年龄。
    返回 int 或 None。base_year 一般用开标年份。"""
    if not id_number or len(id_number) < 14:
        return None
    try:
        yymmdd = id_number[6:14]
        birth_year = int(yymmdd[:4])
        return base_year - birth_year
    except (ValueError, IndexError):
        return None


def run_guardrails(doc, auto_fix=True, base_year=None):
    """统一入口：跑全部不变量，返回结构化报告。
    auto_fix=True 时自动修复可安全修复的项（空格/分页/锚点），签字误填只告警。"""
    report = {'fixed': {}, 'warnings': []}
    if auto_fix:
        report['fixed']['label_whitespace'] = fix_label_whitespace(doc)
        report['fixed']['chapter_page_breaks'] = ensure_chapter_page_breaks(doc)
        report['fixed']['anchor_residue'] = strip_anchor_residue(doc)
    else:
        # 仅检查模式下统计
        ws = 0
        for p in doc.paragraphs:
            if _COLON_WS.search(p.text):
                ws += 1
        report['fixed']['label_whitespace'] = 0
        report['check_only'] = {
            'label_whitespace_hits': ws,
            'chapter_break_needed': sum(
                1 for p in doc.paragraphs
                if _looks_like_chapter(p.text, p.style.name if p.style else '')
                and not p.paragraph_format.page_break_before
            ),
        }
    report['warnings'] += verify_signatures_empty(doc)
    anchors = verify_no_anchor_residue(doc)
    report['anchor_residue_remaining'] = anchors
    if auto_fix and anchors:
        # 已在上面清过；若仍残留说明在表格深层，再次尝试
        report['anchor_residue_remaining'] = verify_no_anchor_residue(doc)
    # 不变量 6：图片尺寸 / 分页合规（RULE-IMG-1 / RULE-IMG-2）
    try:
        from image_format import verify_image_sizing
        img_rep = verify_image_sizing(doc)
        report['image_sizing'] = img_rep
        for w in img_rep.get('warnings', []):
            report['warnings'].append('图片尺寸: ' + w)
    except Exception as e:
        report['image_sizing'] = {'error': str(e)}
    return report


def main():
    import argparse
    ap = argparse.ArgumentParser(description='投标文件格式护栏：校验并自动修复常见排版不变量')
    ap.add_argument('input')
    ap.add_argument('--out', default=None, help='输出路径（默认在原名后加 _guarded）')
    ap.add_argument('--no-fix', action='store_true', help='只检查不修复')
    ap.add_argument('--base-year', type=int, default=None, help='年龄派生基准年（开标年）')
    args = ap.parse_args()

    doc = Document(args.input)
    report = run_guardrails(doc, auto_fix=not args.no_fix, base_year=args.base_year)
    print(json.dumps(report, ensure_ascii=False, indent=2))

    if not args.no_fix:
        out = args.out or args.input.replace('.docx', '_guarded.docx')
        doc.save(out)
        print('已保存:', out)


if __name__ == '__main__':
    main()
