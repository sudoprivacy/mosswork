# -*- coding: utf-8 -*-
"""
template_review.py — 通用投标模板评审（"看一遍模板就知道往哪填"的机制）
=========================================================================

用户核心诉求（2026-07-12）：
  "建立一个评审投标文件模板的机制，看一遍模板，然后就知道哪里该填入哪里了，
   也不会往目录下面填写了。" 且明确 **不要针对某个项目写死章节号**（如"第七章"）。

本模块不依赖任何项目硬编码：
  - 资质证明章节：用通用关键词识别（资质/资格/证明/证件/材料/审查 + 文件/证明/材料…），
    任何项目、任何章节号都能命中。
  - 其下编号小标题：用通用编号格式识别（1、xxx / （一）xxx / (1) xxx），
    遇到下一个更高层级标题即停止收集。
  - 资质图片定位：按图片 caption / OCR 文本的语义关键词，匹配到对应小标题，
    从而插入正确位置；绝不插入目录。

消费端 fill_images 据此把图片分布到正确小标题下，并对该小标题强制分页。
"""
import re
from docx import Document

# 资质证明章节：标题含「资质/资格」类型词 + 「文件/材料/证书/资料/情况/证明」对象词。
# 仅用 资质/资格 作为类型词，避免把正文中含"证明/材料"的描述段落误判为章节。
QUAL_SECTION_RE = re.compile(r'(资质|资格).*(文件|材料|证书|资料|情况|证明)')

# 编号小标题：1、xxx / （一）xxx / (1) xxx / 1.xxx
SUBHEAD_RE = re.compile(
    r'^\s*(?:[（(]?\d{1,2}[、.）)][）]?|[（(][一二三四五六七八九十]+[）)]\s*[:：]?)\s*(.+)$'
)

# 更高层级标题（章/大标题）出现则停止收集小标题
TOP_HEADING_RE = re.compile(r'^第[一二三四五六七八九十百]+章|^[一二三四五六七八九十百]+[、.、]')

# 图片语义 → 小标题关键词分类（通用投标领域知识，非项目特有）
IMAGE_TAXONOMY = [
    ('营业执照', ['营业执照', '统一社会信用代码', '法人营业执照', '副本', '登记证明文件']),
    ('财务报告', ['财务', '审计', '资产负债', '会计', '报表', '资信']),
    ('纳税',     ['税收', '纳税', '完税', '税务']),
    ('社保',     ['社会保障', '社保', '保险缴费', '社会保险']),
    ('信用',     ['信用', '信用中国', '失信', '严重失信', '异常名录']),
    ('无违法',   ['无违法', '违法记录', '重大违法', '书面声明']),
    ('关联',     ['关联', '控股', '管理关系']),
    ('联合体',   ['联合体']),
    ('能力',     ['能力', '资质', '设备', '资金', '认证', '等级', '检测', '声明', '承诺']),
]


def _looks_like_top_heading(t):
    return bool(TOP_HEADING_RE.match(t.strip()))


def detect_qualification_layout(template_path):
    """扫描框架模板，返回 {'section': 章节标题 or None, 'subheads': [小标题, ...]}。

    通用：不写死章节号。注意：
      1) 章节标题可能带 [[FILL:]] 锚点 token，长度不固定；
      2) 小标题常为「描述性段落」（如"财务状况报告：..."），未必带编号；
      3) 正文中也常含"证明/材料"等词，不能仅凭关键词判章节。

    策略：先按 资质/资格 类型词筛出章节候选；再对每候选统计其下「直到下一个
    更高层级标题」之间的段落中，命中资质图片分类关键词（营业执照/财务/纳税/
    社保/信用/无违法/关联/联合体/能力）的密度；密度最高者即真实资质章节
    （目录里的同名条目下不会有这些小标题，故被自然排除）。
    """
    doc = Document(template_path)
    paras = [(i, p.text.strip()) for i, p in enumerate(doc.paragraphs) if p.text.strip()]
    idx2text = {i: t for i, t in paras}
    candidates = [i for i, t in paras if QUAL_SECTION_RE.search(t)]
    best = None
    best_subs = []
    best_score = -1
    for ci in candidates:
        subs = []
        started = False
        for i, t in paras:
            if not started:
                if i == ci:
                    started = True
                continue
            if _looks_like_top_heading(t):
                break
            subs.append(t)
        score = sum(1 for s in subs if any(kw in s for _c, kws in IMAGE_TAXONOMY for kw in kws))
        # 密度最高者胜；并列取最后（真实章节通常在目录条目之后）
        if score > best_score or (score == best_score and ci > (best or -1)):
            best = ci
            best_subs = subs
            best_score = score
    section = idx2text.get(best) if best is not None else None
    return {'section': section, 'subheads': best_subs}


def classify_image_to_subheading(caption, subheads):
    """按图片 caption / OCR 文本语义，匹配最相关的小标题，返回索引或 None。

    匹配逻辑：先为 caption 确定主要类别（按 IMAGE_TAXONOMY 关键词命中数），
    再为每个 subhead 计算同类别的匹配得分，取最高者。这样可以避免
    "信用" 等关键词同时出现在 "统一社会信用代码" 和 "信用中国" 小节时
    被误分配到营业执照小节。
    """
    if not subheads or not caption:
        return None
    # 1) caption 的类别得分
    caption_scores = {}
    for cat, kws in IMAGE_TAXONOMY:
        s = sum(1 for kw in kws if kw in caption)
        if s > 0:
            caption_scores[cat] = s
    if not caption_scores:
        return None
    best = None
    best_score = 0
    for idx, sh in enumerate(subheads):
        score = 0
        for cat, kws in IMAGE_TAXONOMY:
            sh_score = sum(1 for kw in kws if kw in sh)
            score += caption_scores.get(cat, 0) * sh_score
        if score > best_score:
            best_score = score
            best = idx
    return best
