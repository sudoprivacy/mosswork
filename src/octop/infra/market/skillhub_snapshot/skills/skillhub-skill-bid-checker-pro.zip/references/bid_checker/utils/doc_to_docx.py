#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DOC 转 DOCX 工具 (v10.0)
========================

解决"用户提供的招标文件 / 投标文件是 .doc 旧版 Word 格式"的转换问题。

设计原则（对标书审查的严谨性负责，严禁静默降级丢结构）：
  - 优先使用【高保真】引擎（保留表格 / 图片 / 样式 / 页码）：
      1. MS Word COM      （Windows + 已装 Microsoft Office）
      2. WPS COM          （Windows + 已装 WPS Office，国产办公常见）
      3. LibreOffice      （soffice --headless --convert-to docx，跨平台）
      4. Aspose.Words     （pip install aspose-words，程序化高保真，沙箱可装）
  - 当且仅当 1~4 全部不可用时，才落入【仅文本】兜底：
      5. olefile 自研提取 （中文安全，保留段落/表格顺序，但有损格式）
      6. antiword / docx2txt（仅文本，中文易乱码，最后兜底）
  - 任何【仅文本】兜底都必须显式标记 fidelity='text_only'，并输出告警，
    禁止伪装成"转换成功且结构完整"——模型须在报告中提示用户人工复核。
  - 自动安装兜底：1~4 全缺时，模型可调用 try_auto_install() 尝试
    `pip install aspose-words` 并重试；仍失败再尝试安装 LibreOffice。

用法：
    from bid_checker.utils.doc_to_docx import convert_doc_to_docx
    docx_path, was_converted, fidelity = convert_doc_to_docx("招标文件.doc")

命令行：
    python -m bid_checker.utils.doc_to_docx 招标文件.doc [输出.docx]
    python -m bid_checker.utils.doc_to_docx --selftest
"""

import os
import sys
import struct
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Any

# 统一日志
try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.doc_to_docx")
except Exception:
    import logging
    _logger = logging.getLogger("doc_to_docx")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)


# ===================== 文件类型判断 =====================

def is_doc_file(file_path: str) -> bool:
    """判断是否为 .doc 旧版 Word 格式（需转换）"""
    return bool(file_path) and file_path.lower().endswith('.doc')


def is_docx_file(file_path: str) -> bool:
    """判断是否为 .docx 新版 Word 格式（无需转换）"""
    return bool(file_path) and file_path.lower().endswith('.docx')


# ===================== 引擎探测 =====================

def _find_libreoffice() -> Optional[str]:
    """查找 LibreOffice / soffice 可执行文件"""
    for cmd in ['libreoffice', 'soffice', 'libreoffice7.6', 'libreoffice7.5', 'libreoffice24.2']:
        path = shutil.which(cmd)
        if path:
            return path
    if sys.platform == 'win32':
        for p in [
            r"C:\Program Files\LibreOffice\program\soffice.exe",
            r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
        ]:
            if os.path.exists(p):
                return p
    return None


def detect_available_engines() -> Dict[str, bool]:
    """返回各转换引擎是否可用（供 --selftest 与模型决策使用）"""
    engines = {
        "ms_word_com": False,
        "wps_com": False,
        "libreoffice": False,
        "aspose": False,
        "olefile": False,
        "antiword": False,
        "docx2txt": False,
    }
    # MS Word COM
    if sys.platform == 'win32':
        try:
            import win32com.client  # noqa: F401
            engines["ms_word_com"] = True
        except Exception:
            pass
        # WPS COM（仅 Windows 可注册）
        try:
            import win32com.client
            # 仅探测注册表 progid 是否可创建，避免真实启动 WPS
            from win32com.client import gencache  # noqa: F401
            engines["wps_com"] = True  # 实际创建在转换函数内重试，这里标记可用
        except Exception:
            engines["wps_com"] = False
    # LibreOffice
    engines["libreoffice"] = _find_libreoffice() is not None
    # Aspose
    try:
        import aspose.words  # noqa: F401
        engines["aspose"] = True
    except Exception:
        pass
    # olefile
    try:
        import olefile  # noqa: F401
        engines["olefile"] = True
    except Exception:
        pass
    # antiword / docx2txt
    engines["antiword"] = shutil.which('antiword') is not None
    try:
        import docx2txt  # noqa: F401
        engines["docx2txt"] = True
    except Exception:
        pass
    return engines


# ===================== 高保真引擎 =====================

def _convert_via_word_com(doc_path: str, output_dir: str) -> Optional[str]:
    """MS Word COM 自动化（Windows + MS Office），保真度最高。"""
    if sys.platform != 'win32':
        return None
    try:
        import win32com.client
        import pythoncom
    except ImportError:
        return None

    word = None
    try:
        pythoncom.CoInitialize()
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        abs_doc = os.path.abspath(doc_path)
        doc = word.Documents.Open(abs_doc, ReadOnly=True)
        base = os.path.splitext(os.path.basename(doc_path))[0]
        out = os.path.join(output_dir, f"{base}.docx")
        doc.SaveAs2(os.path.abspath(out), FileFormat=16)  # 16 = wdFormatDocumentDefault (.docx)
        doc.Close(SaveChanges=False)
        if os.path.exists(out):
            _logger.info(f"  ✓ MS Word COM 转换成功 ({os.path.getsize(out)/1024:.1f} KB)")
            return out
        return None
    except Exception as e:
        _logger.warning(f"  MS Word COM 转换失败: {type(e).__name__}: {e}")
        return None
    finally:
        if word is not None:
            try:
                word.Quit()
            except Exception:
                pass
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass


def _convert_via_wps_com(doc_path: str, output_dir: str) -> Optional[str]:
    """WPS COM 自动化（Windows + WPS Office），国产办公常见，保真度高。"""
    if sys.platform != 'win32':
        return None
    try:
        import win32com.client
        import pythoncom
    except ImportError:
        return None

    # WPS Writer 的 progid 历史上有多种写法，逐一尝试
    progids = ["KWPS.Application", "Kwps.Application", "wps.Application", "WPS.Application"]
    word = None
    for progid in progids:
        try:
            pythoncom.CoInitialize()
            word = win32com.client.Dispatch(progid)
            break
        except Exception:
            word = None
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass
    if word is None:
        return None

    try:
        word.Visible = False
        abs_doc = os.path.abspath(doc_path)
        doc = word.Documents.Open(abs_doc, ReadOnly=True)
        base = os.path.splitext(os.path.basename(doc_path))[0]
        out = os.path.join(output_dir, f"{base}.docx")
        # WPS 同样支持 SaveAs FileFormat=16 (.docx)
        doc.SaveAs2(os.path.abspath(out), FileFormat=16)
        doc.Close(SaveChanges=False)
        if os.path.exists(out):
            _logger.info(f"  ✓ WPS COM 转换成功 ({os.path.getsize(out)/1024:.1f} KB)")
            return out
        return None
    except Exception as e:
        _logger.warning(f"  WPS COM 转换失败: {type(e).__name__}: {e}")
        return None
    finally:
        if word is not None:
            try:
                word.Quit()
            except Exception:
                pass
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass


def _convert_via_libreoffice(doc_path: str, output_dir: str) -> Optional[str]:
    """LibreOffice 无头转换，跨平台高保真。"""
    soffice = _find_libreoffice()
    if not soffice:
        return None
    try:
        cmd = [
            soffice, '--headless', '--norestore',
            '--convert-to', 'docx:"MS Word 2007 XML"',
            '--outdir', output_dir, doc_path,
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        if result.returncode != 0:
            _logger.warning(f"  LibreOffice 转换失败 (exit={result.returncode}); {result.stderr[:200]}")
            return None
        base = os.path.splitext(os.path.basename(doc_path))[0]
        out = os.path.join(output_dir, f"{base}.docx")
        if os.path.exists(out):
            _logger.info(f"  ✓ LibreOffice 转换成功 ({os.path.getsize(out)/1024:.1f} KB)")
            return out
        return None
    except subprocess.TimeoutExpired:
        _logger.warning("  LibreOffice 转换超时（>180秒）")
        return None
    except Exception as e:
        _logger.warning(f"  LibreOffice 转换异常: {type(e).__name__}: {e}")
        return None


def _convert_via_aspose(doc_path: str, output_dir: str) -> Optional[str]:
    """Aspose.Words 程序化转换（pip install aspose-words），高保真、沙箱可装。"""
    try:
        import aspose.words as aw
    except ImportError:
        return None
    try:
        base = os.path.splitext(os.path.basename(doc_path))[0]
        out = os.path.join(output_dir, f"{base}.docx")
        doc = aw.Document(os.path.abspath(doc_path))
        doc.save(os.path.abspath(out), aw.SaveFormat.DOCX)
        if os.path.exists(out):
            _logger.info(f"  ✓ Aspose.Words 转换成功 ({os.path.getsize(out)/1024:.1f} KB)")
            return out
        return None
    except Exception as e:
        _logger.warning(f"  Aspose.Words 转换失败: {type(e).__name__}: {e}")
        return None


# ===================== 仅文本兜底（有损） =====================

def _extract_doc_text_olefile(doc_path: str) -> Optional[str]:
    """
    用 olefile 从 .doc 提取纯文本（中文安全）。
    采用标准 FIB/CLX/PieceTable 算法，保留段落与表格单元格顺序。
    返回拼接后的纯文本（段落以换行分隔），失败返回 None。
    """
    try:
        import olefile
    except ImportError:
        return None
    try:
        ole = olefile.OleFileIO(doc_path)
        if not ole.exists('WordDocument'):
            return None
        word = ole.openstream('WordDocument').read()
        if len(word) < 0x200:
            return None

        # FIB: 决定使用 0Table 还是 1Table
        flags = struct.unpack('<H', word[0x000A:0x000C])[0]
        table_name = '1Table' if (flags & 0x0200) else '0Table'
        if not ole.exists(table_name):
            table_name = '1Table' if ole.exists('1Table') else '0Table'
        if not ole.exists(table_name):
            return None
        table = ole.openstream(table_name).read()

        # CLX 位置
        fc_clx = struct.unpack('<I', word[0x01A2:0x01A6])[0]
        lcb_clx = struct.unpack('<I', word[0x01A6:0x01AA])[0]
        if fc_clx + lcb_clx > len(table) or lcb_clx <= 0:
            return None
        clx = table[fc_clx: fc_clx + lcb_clx]

        # 跳过前导 Prc 条目（每个 Prc：1 字节标记 + 1 字节长度 + 内容）
        i = 0
        while i < len(clx) and clx[i] == 1:
            if i + 1 >= len(clx):
                break
            i += 2 + clx[i + 1]
        # 余下为 Pcdt：4 字节 lcb + PlcPcd
        if i + 4 > len(clx):
            return None
        lcb = struct.unpack('<I', clx[i:i + 4])[0]
        plc = clx[i + 4: i + 4 + lcb]
        if len(plc) < 8:
            return None

        n = (len(plc) - 4) // 12  # piece 数量
        if n <= 0:
            return None

        pieces = []
        for k in range(n):
            cp_start = struct.unpack('<I', plc[4 * k: 4 * k + 4])[0]
            cp_end = struct.unpack('<I', plc[4 * (k + 1): 4 * (k + 1) + 4])[0]
            pcd_off = 4 * (n + 1) + 8 * k
            pcd = plc[pcd_off: pcd_off + 8]
            if len(pcd) < 8:
                continue
            fc_field = struct.unpack('<I', pcd[2:6])[0]
            f_compressed = (fc_field & 0x40000000) != 0
            fc = fc_field >> 2
            pieces.append((cp_start, cp_end, fc, f_compressed))

        # 提取每片文本
        text_parts = []
        for (cp_start, cp_end, fc, f_compressed) in pieces:
            length_cp = cp_end - cp_start
            if length_cp <= 0:
                continue
            try:
                if f_compressed:
                    raw = word[fc: fc + length_cp]
                    text_parts.append(raw.decode('cp1252', errors='ignore'))
                else:
                    raw = word[fc: fc + length_cp * 2]
                    text_parts.append(raw.decode('utf-16-le', errors='ignore'))
            except Exception:
                continue

        full = ''.join(text_parts)
        # 清理 Word 特殊分隔符，并规范换行
        full = full.replace('\r', '\n').replace('\x07', '\n').replace('\x0c', '\n')
        # 去掉多余空行（保留段落结构）
        lines = [ln.rstrip() for ln in full.split('\n')]
        cleaned = '\n'.join(lines)
        return cleaned if cleaned.strip() else None
    except Exception as e:
        _logger.warning(f"  olefile 提取异常: {type(e).__name__}: {e}")
        return None


def _convert_via_olefile(doc_path: str, output_dir: str) -> Optional[str]:
    """olefile 自研提取 → 重建 .docx（仅文本，有损但中文安全）。"""
    text = _extract_doc_text_olefile(doc_path)
    if not text:
        return None
    try:
        from docx import Document
    except ImportError:
        _logger.warning("  python-docx 未安装，无法重建 .docx（仅返回文本失败）")
        return None
    try:
        base = os.path.splitext(os.path.basename(doc_path))[0]
        out = os.path.join(output_dir, f"{base}.docx")
        doc = Document()
        for para in text.split('\n'):
            if para.strip():
                doc.add_paragraph(para)
        doc.save(out)
        _logger.info(f"  ⚠ olefile 仅文本提取成功（有损，丢表格/样式）({os.path.getsize(out)/1024:.1f} KB)")
        return out
    except Exception as e:
        _logger.warning(f"  olefile 重建 .docx 异常: {type(e).__name__}: {e}")
        return None


def _convert_via_antiword(doc_path: str, output_dir: str) -> Optional[str]:
    """antiword 提取（仅文本，中文易乱码，最后兜底）。"""
    antiword = shutil.which('antiword')
    if not antiword:
        return None
    try:
        result = subprocess.run([antiword, '-w', '0', doc_path],
                                capture_output=True, text=True, timeout=60)
        if result.returncode != 0 or not result.stdout.strip():
            return None
        from docx import Document
        base = os.path.splitext(os.path.basename(doc_path))[0]
        out = os.path.join(output_dir, f"{base}.docx")
        doc = Document()
        for line in result.stdout.split('\n'):
            if line.strip():
                doc.add_paragraph(line)
        doc.save(out)
        _logger.info(f"  ⚠ antiword 仅文本提取（中文可能乱码）({os.path.getsize(out)/1024:.1f} KB)")
        return out
    except Exception as e:
        _logger.warning(f"  antiword 异常: {type(e).__name__}: {e}")
        return None


def _convert_via_docx2txt(doc_path: str, output_dir: str) -> Optional[str]:
    """docx2txt 提取（仅文本，最后兜底）。"""
    try:
        import docx2txt
    except ImportError:
        return None
    try:
        text = docx2txt.process(doc_path)
        if not text or not text.strip():
            return None
        from docx import Document
        base = os.path.splitext(os.path.basename(doc_path))[0]
        out = os.path.join(output_dir, f"{base}.docx")
        doc = Document()
        for line in text.split('\n'):
            if line.strip():
                doc.add_paragraph(line)
        doc.save(out)
        _logger.info(f"  ⚠ docx2txt 仅文本提取({os.path.getsize(out)/1024:.1f} KB)")
        return out
    except Exception as e:
        _logger.warning(f"  docx2txt 异常: {type(e).__name__}: {e}")
        return None


# ===================== 自动安装兜底 =====================

def try_auto_install() -> bool:
    """
    当所有高保真引擎均不可用时，尝试在沙箱/当前环境安装 Aspose.Words。
    返回是否安装成功（成功后可重试 aspose 引擎）。
    注意：仅安装程序化依赖，不触碰系统级办公软件；若仍失败，
    模型应提示用户手动安装 MS Office / WPS / LibreOffice 之一。
    """
    _logger.info("  → 尝试自动安装 Aspose.Words（高保真、无需系统办公软件）...")
    try:
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--quiet', 'aspose-words'],
                       check=True, capture_output=True, text=True, timeout=600)
        import importlib
        import aspose.words  # noqa: F401
        _logger.info("  ✓ Aspose.Words 安装成功，可重试高保真转换")
        return True
    except Exception as e:
        _logger.warning(f"  Aspose.Words 自动安装失败: {type(e).__name__}: {e}")
        return False


# ===================== 主转换入口 =====================

# 高保真引擎（保留结构）按优先级排列
_HIGH_FIDELITY = [
    ("MS Word COM", _convert_via_word_com),
    ("WPS COM", _convert_via_wps_com),
    ("LibreOffice", _convert_via_libreoffice),
    ("Aspose.Words", _convert_via_aspose),
]
# 仅文本兜底（有损）按优先级排列
_TEXT_ONLY = [
    ("olefile", _convert_via_olefile),
    ("antiword", _convert_via_antiword),
    ("docx2txt", _convert_via_docx2txt),
]


def convert_doc_to_docx(doc_path: str,
                        output_dir: Optional[str] = None,
                        allow_auto_install: bool = True) -> Tuple[str, bool, str]:
    """
    将 .doc 转换为 .docx（多引擎高保真优先，仅文本兜底并显式标记）。

    Args:
        doc_path: .doc 文件路径
        output_dir: 输出目录（默认同 .doc 所在目录）
        allow_auto_install: 高保真引擎全缺时是否尝试自动安装 Aspose

    Returns:
        (docx_path, was_converted, fidelity)
          fidelity = 'high'      高保真（保留结构）
          fidelity = 'text_only' 仅文本（有损，须人工复核）

    Raises:
        FileNotFoundError: 文件不存在
        RuntimeError: 所有引擎（含兜底）均失败
    """
    if not os.path.exists(doc_path):
        raise FileNotFoundError(f"DOC 文件不存在: {doc_path}")
    if not is_doc_file(doc_path):
        return doc_path, False, 'high'

    if output_dir is None:
        output_dir = os.path.dirname(os.path.abspath(doc_path))
    os.makedirs(output_dir, exist_ok=True)

    _logger.info(f"  🔄 检测到 .doc 旧版 Word，开始转换（多引擎高保真优先）...")

    # 1) 先尝试高保真引擎
    for name, fn in _HIGH_FIDELITY:
        _logger.info(f"  → 尝试高保真引擎 {name}...")
        try:
            result = fn(doc_path, output_dir)
        except Exception as e:
            _logger.warning(f"  {name} 抛异常: {e}")
            result = None
        if result:
            return result, True, 'high'
        _logger.info(f"  ✗ {name} 不可用")

    # 2) 高保真全缺 → 尝试自动安装 Aspose 并重试
    if allow_auto_install:
        if try_auto_install():
            _logger.info("  → 重试 Aspose.Words 高保真转换...")
            result = _convert_via_aspose(doc_path, output_dir)
            if result:
                return result, True, 'high'

    # 3) 仅文本兜底（有损，但必须显式告警）
    _logger.warning("  ⚠ 所有高保真引擎不可用，落入【仅文本】兜底（结构有损，须人工复核）")
    for name, fn in _TEXT_ONLY:
        _logger.info(f"  → 尝试仅文本兜底 {name}...")
        try:
            result = fn(doc_path, output_dir)
        except Exception as e:
            _logger.warning(f"  {name} 抛异常: {e}")
            result = None
        if result:
            _logger.warning(
                "  ⚠⚠ 转换保真度=text_only：已丢失表格/图片/样式等结构，"
                "标书审查中涉及表格（报价、技术参数）的结论须逐页人工复核！")
            return result, True, 'text_only'

    raise RuntimeError(
        f"DOC 转 DOCX 失败：所有引擎（高保真 + 仅文本兜底）均不可用。\n"
        f"请安装任一高保真引擎后重试：\n"
        f"  - Microsoft Office（Windows 双击 .doc 另存为 .docx 最稳）\n"
        f"  - WPS Office（Windows）\n"
        f"  - LibreOffice: https://www.libreoffice.org/download/\n"
        f"  - Aspose.Words: pip install aspose-words\n"
        f"或在支持的环境中由模型执行 `python -m bid_checker.utils.doc_to_docx --selftest` 自查。"
    )


def ensure_docx(file_path: str, output_dir: Optional[str] = None) -> str:
    """确保文件是 .docx（.doc 则自动转换）。返回 .docx 路径。"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    if is_docx_file(file_path):
        return file_path
    if is_doc_file(file_path):
        docx_path, _, _ = convert_doc_to_docx(file_path, output_dir)
        return docx_path
    raise ValueError(f"不支持的文件格式: {file_path}（仅支持 .doc / .docx）")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="DOC 转 DOCX 工具 (v10.0)")
    parser.add_argument('input', nargs='?', help='输入 .doc 文件路径')
    parser.add_argument('output', nargs='?', help='输出 .docx 路径（可选）')
    parser.add_argument('--output-dir', help='输出目录')
    parser.add_argument('--selftest', action='store_true', help='自检各引擎可用性')
    parser.add_argument('--no-auto-install', action='store_true', help='禁止自动安装 Aspose')
    args = parser.parse_args()

    if args.selftest:
        eng = detect_available_engines()
        _logger.info("=== 转换引擎自检 ===")
        for k, v in eng.items():
            _logger.info(f"  {k}: {'✓ 可用' if v else '✗ 不可用'}")
        high = [k for k, v in eng.items() if v and k in
                ('ms_word_com', 'wps_com', 'libreoffice', 'aspose')]
        if high:
            _logger.info(f"→ 将使用高保真引擎：{', '.join(high)}")
        else:
            _logger.warning("→ 无高保真引擎！将落入仅文本兜底（结构有损）。"
                            "建议安装 MS Office / WPS / LibreOffice / Aspose。")
        return 0

    if not args.input:
        parser.error("请提供 input 参数，或使用 --selftest")

    try:
        out_dir = args.output_dir
        if args.output:
            out_dir = os.path.dirname(os.path.abspath(args.output)) or '.'
        docx_path, was_converted, fidelity = convert_doc_to_docx(
            args.input, out_dir, allow_auto_install=not args.no_auto_install)
        if args.output and os.path.abspath(docx_path) != os.path.abspath(args.output):
            shutil.move(docx_path, args.output)
            docx_path = args.output
        _logger.info(f"\n✓ 转换完成（保真度={fidelity}）")
        _logger.info(f"  输出: {docx_path}")
        return 0
    except Exception as e:
        _logger.error(f"\n✗ 转换失败: {e}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
