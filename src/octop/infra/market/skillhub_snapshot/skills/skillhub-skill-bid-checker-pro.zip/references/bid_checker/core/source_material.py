# -*- coding: utf-8 -*-
"""
source_material.py — 源资料读取器（通用）
=========================================================
按源资料文件/目录的原始顺序提取图片，并按源文件内的标题分组。

支持输入：
  - .docx 文档（按段落标题分组，图片紧跟最近非空段落标题）
  - 图片文件夹（整体为一组；若含子文件夹，按子文件夹分组）
  - .pdf 文档（按页提取为整页图片，整体为一组）

输出：groups = [
    {'heading': '财务状况报告', 'images': [{'path':..., 'caption':...}, ...]},
    ...
]

设计原则：
  - 源资料是顺序权威：输出顺序 = 源资料顺序。
  - 源资料里的标题是分组权威：同一标题下的图片必须连续出现。
  - 消费端把 group 映射到目标投标文件的对应小节，组内顺序不再打乱。
"""
import os
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn


# --------------------------------------------------------------------------
# 通用工具
# --------------------------------------------------------------------------
def _norm_heading(t):
    """归一化标题文本，去掉多余空白。"""
    return re.sub(r'\s+', ' ', t).strip()


def _copy_unique(src_path, out_dir, prefix, seq, ext=None):
    """把 src_path 复制到 out_dir，返回新路径。"""
    os.makedirs(out_dir, exist_ok=True)
    if ext is None:
        ext = os.path.splitext(src_path)[1] or '.png'
    ext = ext.lower()
    dst = os.path.join(out_dir, '%s_%04d%s' % (prefix, seq, ext))
    # 如果源和目标相同，不复制
    if os.path.abspath(src_path) != os.path.abspath(dst):
        with open(src_path, 'rb') as f:
            data = f.read()
        with open(dst, 'wb') as f:
            f.write(data)
    return dst


def _is_heading_text(t):
    """简单启发式：判断一段文字像不像标题/小节名。"""
    t = t.strip()
    if not t:
        return False
    if len(t) > 80:
        return False
    # 编号开头：1. / 一、 / (一) / 1）
    if re.match(r'^[（(]?[一二三四五六七八九十百0-9]+[）).、\s]', t):
        return True
    # 以「证明」「报告」「证书」「承诺」「执照」「案例」「彩页」等结尾
    if any(k in t for k in ('证明', '报告', '证书', '承诺', '执照', '案例', '彩页',
                            '说明', '截图', '信息')):
        return True
    return False


def _looks_like_subproject(t, group_heading):
    """业绩/案例组内，产品线/项目名作为子标题（用于分隔多个业绩）。

    严格判定：项目名是「纯标题」，不含冒号（带冒号的是合同抬头/落款，如
    "XX市XX局 ：""供应商（公章）：XX公司"），也不含
    公章/签字/供应商等落款关键词。"""
    if not any(k in group_heading for k in ('业绩', '案例', '合同')):
        return False
    if not (6 <= len(t) <= 60):
        return False
    if '：' in t or ':' in t:          # 带冒号 -> 抬头/落款行，不是项目名
        return False
    if any(k in t for k in ('公章', '签字', '供应商', '采购人', '招标人', '授权', '法定代表人')):
        return False
    return any(k in t for k in ('项目', '采购', '合同', '中标', '供货', '建设', '工程',
                                '学校', '幼儿园', '医院', '局', '公司', '研究院', '大学', '中心'))


def _is_copyable_statement(t):
    """资质章节里应复制进投标文件的文字段落（承诺/声明/说明/非联合体等）。
    过滤页脚/页码/过短过长，避免破坏结构与注入噪声。"""
    if not (4 <= len(t) <= 500):
        return False
    if re.search(r'第\s*\d+\s*页|Page\s*\d+|\-{3,}', t):
        return False
    return any(k in t for k in ('承诺', '声明', '说明', '保证', '陈述', '兹', '我方',
                                '本公司', '我们', '本单位', '不参与', '不处于', '具有', '具备'))


# --------------------------------------------------------------------------
# docx 源资料
# --------------------------------------------------------------------------
def _rels_map(docx_path):
    z = zipfile.ZipFile(docx_path)
    rels = {}
    try:
        data = z.read('word/_rels/document.xml.rels').decode('utf-8', 'ignore')
    except KeyError:
        return rels
    for m in re.finditer(r'Id="([^"]+)"[^>]*Target="([^"]+)"', data):
        rels[m.group(1)] = m.group(2)
    return rels


def _media_path(target):
    if not target:
        return None
    if target.startswith('word/'):
        return target
    return 'word/' + target.lstrip('/')


def read_docx_source(docx_path, out_dir, prefix='src'):
    """读取 docx 源资料，按段落标题分组；组内保留「文字/图片/子标题」原始顺序（blocks）。

    第一原则：保持资料文件原有格式与顺序。图片紧跟其最近的标题/小标题；
    业绩组内的项目名识别为 subheading（用于插入时分隔多个业绩）；
    承诺/声明/说明类文字段落标记为 text（随图片一并复制到投标文件对应章节）。"""
    os.makedirs(out_dir, exist_ok=True)
    z = zipfile.ZipFile(docx_path)
    rels = _rels_map(docx_path)
    doc = Document(docx_path)

    groups = []
    current_heading = '资质证明材料'
    current_blocks = []
    seen_media = set()
    seq = 0

    for p in doc.paragraphs:
        t = _norm_heading(p.text)
        drawings = p._p.findall('.//' + qn('w:drawing'))

        # 先处理标题切换：如果本段是标题且不是纯数字页码，切换当前分组
        if t and _is_heading_text(t) and not drawings:
            if current_blocks:
                groups.append({'heading': current_heading, 'blocks': current_blocks})
                current_blocks = []
            current_heading = t
            continue

        if drawings:
            for d in drawings:
                blip = d.find('.//' + qn('a:blip'))
                if blip is None:
                    continue
                rid = blip.get(qn('r:embed'))
                target = rels.get(rid)
                if not target:
                    continue
                media = _media_path(target)
                name = os.path.basename(media)
                if name in seen_media:
                    continue
                seen_media.add(name)
                try:
                    data = z.read(media)
                except KeyError:
                    continue
                ext = os.path.splitext(name)[1] or '.png'
                op = os.path.join(out_dir, '%s_%04d%s' % (prefix, seq, ext))
                with open(op, 'wb') as f:
                    f.write(data)
                current_blocks.append({'type': 'image', 'path': op, 'caption': current_heading})
                seq += 1
        elif t:
            # 文字段落：业绩组内识别为子标题；其余按「声明/承诺」类复制（跳过默认组预置文字）
            if _looks_like_subproject(t, current_heading):
                current_blocks.append({'type': 'subheading', 'text': t})
            elif _is_copyable_statement(t) and current_heading != '资质证明材料':
                current_blocks.append({'type': 'text', 'text': t})

    if current_blocks:
        groups.append({'heading': current_heading, 'blocks': current_blocks})

    return groups


# --------------------------------------------------------------------------
# 图片文件夹源资料
# --------------------------------------------------------------------------
def read_folder_source(folder_path, out_dir, prefix='src'):
    """读取图片文件夹。若含子文件夹，按子文件夹分组；否则整体为一组。"""
    folder = Path(folder_path)
    image_exts = {'.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif', '.gif'}
    groups = []
    seq = 0

    subdirs = [d for d in folder.iterdir() if d.is_dir()]
    if subdirs:
        sources = sorted(subdirs)
    else:
        sources = [folder]

    for src_dir in sources:
        imgs = []
        for f in sorted(src_dir.iterdir()):
            if not f.is_file():
                continue
            if f.suffix.lower() not in image_exts:
                continue
            op = _copy_unique(str(f), out_dir, prefix, seq, f.suffix)
            imgs.append({'type': 'image', 'path': op, 'caption': src_dir.name})
            seq += 1
        if imgs:
            groups.append({'heading': src_dir.name, 'blocks': imgs})

    return groups


# --------------------------------------------------------------------------
# PDF 源资料（按页渲染为图片）
# --------------------------------------------------------------------------
def read_pdf_source(pdf_path, out_dir, prefix='src', dpi=200):
    """读取 PDF，每页渲染为一张图片，整体作为一组。"""
    try:
        import fitz  # PyMuPDF
    except ImportError:
        raise RuntimeError('PDF 读取需要 PyMuPDF（fitz），当前环境未安装')

    os.makedirs(out_dir, exist_ok=True)
    doc = fitz.open(pdf_path)
    imgs = []
    seq = 0
    for page_no in range(len(doc)):
        page = doc.load_page(page_no)
        mat = fitz.Matrix(dpi / 72, dpi / 72)
        pix = page.get_pixmap(matrix=mat)
        op = os.path.join(out_dir, '%s_%04d.png' % (prefix, seq))
        pix.save(op)
        imgs.append({'path': op, 'caption': os.path.splitext(os.path.basename(pdf_path))[0]})
        seq += 1

    heading = os.path.splitext(os.path.basename(pdf_path))[0]
    return [{'heading': heading, 'blocks': imgs}]


# --------------------------------------------------------------------------
# 统一入口
# --------------------------------------------------------------------------
def read_source_materials(paths, out_dir, prefix='src'):
    """
    读取一个或多个源资料路径，返回合并后的分组列表。
    paths: str or list[str]，每个路径可以是 .docx、图片文件夹或 .pdf
    """
    if isinstance(paths, str):
        paths = [paths]

    all_groups = []
    for p in paths:
        if not os.path.exists(p):
            continue
        if os.path.isdir(p):
            groups = read_folder_source(p, out_dir, prefix)
        elif p.lower().endswith('.docx'):
            groups = read_docx_source(p, out_dir, prefix)
        elif p.lower().endswith('.pdf'):
            groups = read_pdf_source(p, out_dir, prefix)
        else:
            continue
        all_groups.extend(groups)

    return all_groups


if __name__ == '__main__':
    import sys
    if len(sys.argv) >= 3:
        groups = read_source_materials(sys.argv[1], sys.argv[2], 'src')
        for g in groups:
            print('GROUP:', g['heading'])
            for img in g['images']:
                print('  ', img['path'])
        print('total groups:', len(groups))
        print('total images:', sum(len(g['images']) for g in groups))
