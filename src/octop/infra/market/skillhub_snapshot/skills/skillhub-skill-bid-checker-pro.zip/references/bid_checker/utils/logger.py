#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一日志模块（v9.0 新增）
====================

替代散落在各脚本中的 print() 语句，提供：
  - 分级日志（DEBUG/INFO/WARNING/ERROR/CRITICAL）
  - 控制台 + 文件双输出
  - 结构化字段（时间戳/模块名/级别）
  - 子 logger 隔离（每个模块独立 logger）

使用方式：
    from bid_checker.utils.logger import get_logger
    logger = get_logger(__name__)
    logger.info("启动填充流水线")
    logger.warning("字段未匹配: %s", field_name)
    logger.error("框架文件不存在: %s", path, exc_info=True)
"""

import logging
import os
import sys
from pathlib import Path

# ============================================================
# 全局配置
# ============================================================

_DEFAULT_FORMAT = "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s"
_DEFAULT_DATE_FMT = "%Y-%m-%d %H:%M:%S"

# 日志级别环境变量（DEBUG/INFO/WARNING/ERROR/CRITICAL）
_ENV_LEVEL = os.environ.get("BID_TOOL_LOG_LEVEL", "INFO").upper()

# 日志文件目录（默认在工作目录下的 logs/）
_ENV_LOG_DIR = os.environ.get("BID_TOOL_LOG_DIR", "")

# 已配置的 logger 名称集合，避免重复添加 handler
_configured_loggers: set = set()

# 全局共享 handler
_console_handler: logging.Handler = None
_file_handler: logging.Handler = None


def _level_from_env() -> int:
    """从环境变量解析日志级别"""
    mapping = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "WARN": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
    }
    return mapping.get(_ENV_LEVEL, logging.INFO)


def _ensure_handlers() -> tuple:
    """初始化全局 handler（仅一次）"""
    global _console_handler, _file_handler

    if _console_handler is not None:
        return _console_handler, _file_handler

    formatter = logging.Formatter(_DEFAULT_FORMAT, datefmt=_DEFAULT_DATE_FMT)

    # 控制台 handler —— 输出到 stderr，避免污染 stdout（stdout 用于结构化输出）
    _console_handler = logging.StreamHandler(sys.stderr)
    _console_handler.setFormatter(formatter)
    _console_handler.setLevel(_level_from_env())

    # 文件 handler —— 写入 logs/bid_checker.log（如指定目录）
    if _ENV_LOG_DIR:
        try:
            log_dir = Path(_ENV_LOG_DIR)
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / "bid_checker.log"
            _file_handler = logging.FileHandler(
                str(log_file), encoding="utf-8", mode="a"
            )
            _file_handler.setFormatter(formatter)
            _file_handler.setLevel(_level_from_env())
        except (OSError, PermissionError) as e:
            # 文件 handler 创建失败不影响控制台输出
            print(f"[logger] 文件handler创建失败: {e}", file=sys.stderr)
            _file_handler = None

    return _console_handler, _file_handler


def get_logger(name: str = "bid_checker") -> logging.Logger:
    """
    获取模块级 logger。

    Args:
        name: 模块名（建议传 __name__），如 "bid_checker.fillers.text_fill"

    Returns:
        配置好的 logging.Logger 实例
    """
    logger = logging.getLogger(name)

    if name in _configured_loggers:
        return logger

    console, file_handler = _ensure_handlers()

    # 避免重复添加 handler
    if not logger.handlers:
        logger.addHandler(console)
        if file_handler is not None:
            logger.addHandler(file_handler)

    logger.setLevel(_level_from_env())
    # 不向上传播，避免 root logger 重复输出
    logger.propagate = False

    _configured_loggers.add(name)
    return logger


def set_level(level: str) -> None:
    """
    运行时调整全局日志级别。

    Args:
        level: "DEBUG" / "INFO" / "WARNING" / "ERROR" / "CRITICAL"
    """
    mapping = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "WARN": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
    }
    lvl = mapping.get(level.upper(), logging.INFO)
    for name in list(_configured_loggers):
        logging.getLogger(name).setLevel(lvl)
    if _console_handler is not None:
        _console_handler.setLevel(lvl)
    if _file_handler is not None:
        _file_handler.setLevel(lvl)


# ============================================================
# 向后兼容：保留旧式 print 风格接口（迁移期使用）
# ============================================================

_default_logger = None


def _get_default_logger() -> logging.Logger:
    global _default_logger
    if _default_logger is None:
        _default_logger = get_logger("bid_checker")
    return _default_logger


def log_info(msg: str, *args) -> None:
    """旧式 info 接口（兼容 print('xxx') → log_info('xxx')）"""
    _get_default_logger().info(msg, *args)


def log_warn(msg: str, *args) -> None:
    """旧式 warning 接口"""
    _get_default_logger().warning(msg, *args)


def log_error(msg: str, *args) -> None:
    """旧式 error 接口"""
    _get_default_logger().error(msg, *args)


def log_debug(msg: str, *args) -> None:
    """旧式 debug 接口"""
    _get_default_logger().debug(msg, *args)


if __name__ == "__main__":
    # 自测
    logger = get_logger("test")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
