#!/usr/bin/env python3
"""
金额提取与转换工具

功能：
  1. 从文本中提取所有金额（大写金额 / 小写金额 / 中文描述金额）
  2. 把大写金额转换为阿拉伯数字（"壹佰贰拾万元整" → 1200000）
  3. 把"120万元" "1,200,000元" 等格式统一为数值

支持格式：
  - 大写金额：人民币壹佰贰拾万元整
  - 小写金额：1,200,000元 / 120万元 / ¥120万
  - 中文描述：人民币 1200000 元
"""
import re
from dataclasses import dataclass
from typing import List, Optional

# 大写数字映射
CN_NUM = {
    '零': 0, '〇': 0, '一': 1, '壹': 1, '二': 2, '贰': 2, '两': 2, '三': 3, '叁': 3,
    '四': 4, '肆': 4, '五': 5, '伍': 5, '六': 6, '陆': 6, '七': 7, '柒': 7,
    '八': 8, '捌': 8, '九': 9, '玖': 9,
}

# 大写单位映射
CN_UNIT = {
    '十': 10, '拾': 10,
    '百': 100, '佰': 100,
    '千': 1000, '仟': 1000,
    '万': 10000, '萬': 10000,
    '亿': 100000000, '億': 100000000,
}


@dataclass
class Amount:
    """一个金额实例"""
    raw: str           # 原始文本
    value: float       # 标准化后的数值（元）
    position: int      # 在原文中的字符位置
    location_hint: str # 位置提示（如"投标函"、"报价表第3行"）
    amount_type: str   # 'cn_upper' / 'num' / 'mixed'
    is_valid: bool = True
    invalid_reason: str = ''


# ============= 大写金额解析 =============

def cn_amount_to_number(cn_str: str) -> Optional[float]:
    """
    把大写金额字符串转为数值
    例：'壹佰贰拾万元整' → 1200000.0
        '壹佰贰拾万叁仟伍佰元整' → 12003500.0
    
    返回 None 表示无法解析
    
    算法：分段累加
      - 遇到"亿"结算一次（亿段）
      - 遇到"万"结算一次（万段）
      - "十百千"在段内累乘
    """
    if not cn_str:
        return None
    
    # 移除"人民币"、"整"、"正"、"元"、"圆"等修饰词
    cleaned = re.sub(r'[人民币￥¥]', '', cn_str)
    cleaned = re.sub(r'[元圆][整正]?', '', cleaned)
    cleaned = cleaned.strip()
    
    if not cleaned:
        return None
    
    # 处理小数部分（角/分）
    has_jiao = '角' in cleaned
    has_fen = '分' in cleaned
    decimal_part = 0.0
    integer_part = cleaned
    
    if has_jiao or has_fen:
        jiao_match = re.search(r'([零壹贰叁肆伍陆柒捌玖])角', cleaned)
        fen_match = re.search(r'([零壹贰叁肆伍陆柒捌玖])分', cleaned)
        if jiao_match:
            decimal_part += CN_NUM.get(jiao_match.group(1), 0) * 0.1
            integer_part = integer_part.replace(jiao_match.group(0), '')
        if fen_match:
            decimal_part += CN_NUM.get(fen_match.group(1), 0) * 0.01
            integer_part = integer_part.replace(fen_match.group(0), '')
        integer_part = integer_part.strip()
    
    if not integer_part:
        return decimal_part
    
    # 分段解析：按"亿"和"万"切分
    # 例：'叁亿伍仟万' → ['3亿', '5000万']
    # 例：'壹佰贰拾万叁仟伍佰' → ['壹佰贰拾万', '叁仟伍佰']
    
    total = 0.0
    # 用正则按"亿"和"万"切分，保留分隔符
    # 先按"亿"切分
    yi_parts = re.split(r'(亿|億)', integer_part)
    
    yi_section_total = 0.0  # 亿段累计
    current_multiplier = 1  # 当前段乘数（亿=1e8, 万=1e4, 无=1）
    pending_section = ''  # 待结算的段
    
    i = 0
    while i < len(yi_parts):
        part = yi_parts[i]
        if part in ('亿', '億'):
            # 结算 pending_section × 1e8
            section_value = parse_section(pending_section)
            if section_value is None:
                return None
            yi_section_total += section_value * 1e8
            pending_section = ''
        else:
            pending_section += part
        i += 1
    
    # 处理剩余部分（万段 + 个段）
    if pending_section:
        # 按"万"切分
        wan_parts = re.split(r'(万|萬)', pending_section)
        wan_section_total = 0.0  # 万段累计
        pending = ''
        
        for part in wan_parts:
            if part in ('万', '萬'):
                section_value = parse_section(pending)
                if section_value is None:
                    return None
                wan_section_total += section_value * 1e4
                pending = ''
            else:
                pending += part
        
        # 剩余是个段
        if pending:
            section_value = parse_section(pending)
            if section_value is None:
                return None
            wan_section_total += section_value
        
        yi_section_total += wan_section_total
    
    total = yi_section_total
    return total + decimal_part


def parse_section(section: str) -> Optional[float]:
    """
    解析一个"段"内的数字（不含亿/万）
    例：'壹佰贰拾' → 120
        '叁仟伍佰' → 3500
        '玖仟玖佰玖拾玖' → 9999
    
    算法：
      current = 0  # 当前累积的"个位数"
      total = 0    # 段内总数
      遇到数字：current = 数字
      遇到单位（十百千）：
        如果 current == 0：current = 1（"拾" = "壹拾"）
        total += current × 单位
        current = 0
      末尾：total += current
    """
    if not section:
        return 0
    
    total = 0.0
    current = 0  # 待乘的数字
    
    for ch in section:
        if ch in CN_NUM:
            current = CN_NUM[ch]
        elif ch in CN_UNIT:
            unit = CN_UNIT[ch]
            if current == 0:
                current = 1  # "拾" 等同于 "壹拾"
            total += current * unit
            current = 0
        else:
            # 未知字符
            return None
    
    total += current
    return total


# ============= 小写金额解析 =============

def num_amount_to_value(num_str: str) -> Optional[float]:
    """
    把小写金额字符串转为数值（元）
    例：'1,200,000元' → 1200000.0
        '120万元' → 1200000.0
        '120万' → 1200000.0
        '¥120' → 120.0
    """
    if not num_str:
        return None
    
    cleaned = num_str.strip()
    
    # 检查单位
    multiplier = 1.0
    if '万亿' in cleaned:
        multiplier = 1e12
        cleaned = cleaned.replace('万亿', '')
    elif '亿' in cleaned:
        multiplier = 1e8
        cleaned = cleaned.replace('亿', '')
    elif '万' in cleaned:
        multiplier = 1e4
        cleaned = cleaned.replace('万', '')
    
    # 移除"元"、"元整"、"圆"、"人民币"、"￥"、"¥"等
    cleaned = re.sub(r'[人民币￥¥]', '', cleaned)
    cleaned = re.sub(r'[元圆][整正]?', '', cleaned)
    cleaned = cleaned.replace(',', '').replace('，', '').strip()
    
    if not cleaned:
        return None
    
    try:
        value = float(cleaned)
        return value * multiplier
    except ValueError:
        return None


# ============= 全文金额提取 =============

# 大写金额正则：连续的中文数字+单位组合
CN_AMOUNT_PATTERN = re.compile(
    r'(?:人民币\s*)?'
    r'((?:[零〇壹贰叁肆伍陆柒捌玖拾佰仟万亿萬億一二三四五六七八九两十百千万亿]+'
    r'(?:[元圆][整正]?|角|分|万元|万元整)?))'
)

# 小写金额正则：数字+逗号+小数点 + 单位
NUM_AMOUNT_PATTERN = re.compile(
    r'(?:人民币\s*|￥|¥)?'
    r'((?:\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?)'
    r'\s*(?:万亿元|万元|万元整|亿|万|元整|元|圆))'
)


def extract_all_amounts(text: str, location_hint: str = '') -> List[Amount]:
    """
    从文本中提取所有金额，返回 Amount 列表
    
    :param text: 输入文本
    :param location_hint: 位置提示（如"投标函第3段"）
    :return: Amount 列表，按出现位置排序
    """
    amounts = []
    
    # 1. 提取小写金额
    for match in NUM_AMOUNT_PATTERN.finditer(text):
        raw = match.group(1)
        value = num_amount_to_value(raw)
        if value is not None and value > 0:
            amounts.append(Amount(
                raw=raw,
                value=value,
                position=match.start(),
                location_hint=location_hint,
                amount_type='num',
                is_valid=True,
            ))
    
    # 2. 提取大写金额
    for match in CN_AMOUNT_PATTERN.finditer(text):
        raw = match.group(1)
        # 跳过单字（"一"、"二"等不当作金额）
        if len(raw) < 2:
            continue
        # 必须包含"元/圆/万/亿/角/分"才算金额
        if not any(kw in raw for kw in ['元', '圆', '万', '亿', '角', '分']):
            continue
        
        value = cn_amount_to_number(raw)
        if value is not None and value > 0:
            # 检查是否与已提取的小写金额位置重叠（避免重复）
            overlap = False
            for existing in amounts:
                if abs(existing.position - match.start()) < 20:
                    overlap = True
                    break
            if not overlap:
                amounts.append(Amount(
                    raw=raw,
                    value=value,
                    position=match.start(),
                    location_hint=location_hint,
                    amount_type='cn_upper',
                    is_valid=True,
                ))
    
    # 按位置排序
    amounts.sort(key=lambda a: a.position)
    return amounts


# ============= 大写金额合规性检查 =============

# 规范的大写金额用字
VALID_CN_AMOUNT_CHARS = set('零〇壹贰叁肆伍陆柒捌玖拾佰仟万亿萬億元圆整正角分') | set('人民币')

# 不规范用法：用"一二三..."代替"壹贰叁..."
INFORMAL_NUM_CHARS = set('一二三四五六七八九两十百千万亿')


def check_cn_amount_validity(cn_str: str) -> tuple:
    """
    检查大写金额是否合规
    
    :return: (is_valid, reason)
    """
    if not cn_str:
        return False, '空字符串'
    
    # 移除"人民币"、"元整"等修饰词
    cleaned = re.sub(r'人民币|元整|元正|圆整|圆正|整|正', '', cn_str)
    
    # 检查是否使用了不规范数字
    informal_chars = set(cleaned) & INFORMAL_NUM_CHARS
    if informal_chars:
        # 但"两"用作"两万元"也算不规范（应用"贰万"）
        # "十百千万亿" 单独用是 OK 的（如"拾万元"），但"一十"应该用"壹拾"
        for ch in informal_chars:
            if ch in '一二三四五六七八九':
                return False, f'使用了不规范数字"{ch}"，应使用大写"{ {"一":"壹","二":"贰","三":"叁","四":"肆","五":"伍","六":"陆","七":"柒","八":"捌","九":"玖"}[ch] }"'
            elif ch == '两':
                return False, '使用了"两"，应使用"贰"'
            elif ch in '十百千万亿':
                # 检查是否前面跟着小写数字（"一百" 应为 "壹佰"）
                idx = cleaned.find(ch)
                if idx > 0 and cleaned[idx-1] in '一二三四五六七八九两':
                    return False, f'"{cleaned[idx-1]}{ch}"不规范，应使用大写'
    
    # 检查是否以"元整"/"圆整"/"元正"/"圆正"结尾（金融标准要求）
    if not re.search(r'[元圆][整正]?$', cn_str):
        if not cn_str.endswith('角') and not cn_str.endswith('分'):
            return False, '大写金额应以"元整"或"圆整"结尾'
    
    return True, ''


# ============= 工具函数 =============

def format_value(value: float) -> str:
    """格式化金额为可读字符串"""
    if value >= 1e8:
        return f'{value/1e8:.4f}亿元（{value:,.0f}元）'
    elif value >= 1e4:
        return f'{value/1e4:.4f}万元（{value:,.0f}元）'
    else:
        return f'{value:,.2f}元'


def values_equal(v1: float, v2: float, tolerance: float = 0.02) -> bool:
    """两个金额是否相等（容差 2 分钱，避免浮点精度问题）"""
    return abs(v1 - v2) <= tolerance


if __name__ == '__main__':
    # 自检测试
    print('=== 大写金额解析测试 ===')
    test_cases = [
        ('壹佰贰拾万元整', 1200000),
        ('壹佰贰拾万叁仟伍佰元整', 1203500),
        ('叁亿伍仟万元整', 350000000),
        ('贰拾万元整', 200000),
        ('玖仟玖佰玖拾玖元整', 9999),
        ('壹角伍分', 0.15),
    ]
    for cn, expected in test_cases:
        actual = cn_amount_to_number(cn)
        ok = '✓' if actual == expected else '✗'
        print(f'  {ok} {cn} → {actual} (期望 {expected})')
    
    print('\n=== 小写金额解析测试 ===')
    test_cases = [
        ('1,200,000元', 1200000),
        ('120万元', 1200000),
        ('120万', 1200000),
        ('¥120', 120),
        ('3.5亿元', 350000000),
    ]
    for num, expected in test_cases:
        actual = num_amount_to_value(num)
        ok = '✓' if actual == expected else '✗'
        print(f'  {ok} {num} → {actual} (期望 {expected})')
    
    print('\n=== 全文提取测试 ===')
    text = '''
    致：XX局
    我方愿意以人民币壹佰贰拾万元整（¥1,200,000元）参与本项目投标。
    其中设备费用 80 万元，服务费用 40万元。
    本项目总报价：1250000元。
    '''
    amounts = extract_all_amounts(text, location_hint='测试文本')
    for a in amounts:
        print(f'  [{a.amount_type}] {a.raw} → {a.value} (位置 {a.position})')
    
    print('\n=== 大写金额合规性检查 ===')
    test_cases = [
        ('壹佰贰拾万元整', True),
        ('一百二十万元整', False),
        ('壹佰贰拾万', False),  # 不以元整结尾
        ('壹万元正', True),
    ]
    for cn, expected_valid in test_cases:
        is_valid, reason = check_cn_amount_validity(cn)
        ok = '✓' if is_valid == expected_valid else '✗'
        print(f'  {ok} {cn}: valid={is_valid} {reason}')
