#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HITL（Human-In-The-Loop）确认模块 (v20.1+)
==========================================

把 Stage 4 从"一键生成"改造为"四步走"：
  4-A: AI 生成 FILL Plan（已有 fill_plan.py）
  4-B: 把 Plan 渲染成"逐章节确认卡片"（本模块 render_plan_cards）
  4-C: 用户确认（本模块 parse_user_confirmation + apply_confirmation_to_plan）
  4-D: AI 按确认后的 Plan 机械执行（已有 stage4_fill_plan.py）
  4-E: 护栏审计 + 渲染预览（已有 stage4_fill_plan.py --render）

核心 API：
  render_plan_cards(plan_path_or_dict, output_md_path) -> str
      把 FILL Plan 渲染成 Markdown 确认卡片，供用户逐章节确认

  parse_user_confirmation(confirmation_text) -> dict
      解析用户的确认回复（"1.确认 2.修改:张三 3.跳过"）

  apply_confirmation_to_plan(plan, confirmation) -> plan
      把用户确认应用到 Plan，生成最终执行版 Plan

  classify_confidence(item) -> ('high'|'medium'|'low'|'missing')
      根据槽位 status/value_source 判断置信度

使用示例：
    from hitl_review import render_plan_cards, parse_user_confirmation, apply_confirmation_to_plan

    # 4-B: 渲染确认卡片
    render_plan_cards('fill_plan.json', 'plan_review.md')

    # 4-C: 用户确认后
    confirmation = parse_user_confirmation("1.确认 2.修改:新公司名 3.跳过")
    final_plan = apply_confirmation_to_plan(plan, confirmation)

    # 4-D: 执行最终 Plan
    # python stage4_fill_plan.py --plan final_plan.json ...
"""

import os
import sys
import json
from pathlib import Path
from typing import Dict, List, Optional, Union

try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.hitl_review")
except ImportError:
    import logging
    _logger = logging.getLogger("hitl_review")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)


# ============================================================
# 置信度分类
# ============================================================

# 高置信度来源：OCR 直接识别、业务规则默认值、报价 xlsx
HIGH_CONFIDENCE_SOURCES = {
    'ocr', 'OCR', '营业执照OCR', '身份证OCR',
    'business_rule', '业务规则', '默认值',
    'xlsx', '报价xlsx', '报价单xlsx',
}

# 中置信度来源：资料文本提取、映射匹配
MEDIUM_CONFIDENCE_SOURCES = {
    'material', '资料', '资料提取', '资料文本',
    'match', '匹配', '映射',
}

# 低置信度来源：AI 推断、模糊匹配
LOW_CONFIDENCE_SOURCES = {
    'inferred', '推断', 'AI推断', '模糊匹配',
    'fallback', '兜底',
}


def classify_confidence(item: Dict) -> str:
    """
    根据槽位 status / value_source 判断置信度。

    Returns:
        'high'    — 高置信度（OCR/业务规则/xlsx，默认通过）
        'medium'  — 中置信度（资料提取/匹配，建议确认）
        'low'     — 低置信度（AI推断/模糊匹配，必须确认）
        'missing' — 缺失（无值，必须用户补充或标黄）
    """
    status = item.get('status', '')
    value_source = str(item.get('value_source', '') or item.get('source', ''))
    value = item.get('value')
    src = item.get('src')

    # 缺失项
    if status in ('missing', 'not_found', 'absent') or (not value and not src):
        return 'missing'

    # 高置信度
    if any(s in value_source for s in HIGH_CONFIDENCE_SOURCES):
        return 'high'
    if status in ('matched', 'filled') and value:
        # status=matched 但无 value_source 标注，按中置信度处理
        pass

    # 低置信度
    if any(s in value_source for s in LOW_CONFIDENCE_SOURCES):
        return 'low'

    # 中置信度
    if any(s in value_source for s in MEDIUM_CONFIDENCE_SOURCES):
        return 'medium'

    # 默认中置信度（有值但来源不明）
    return 'medium'


# ============================================================
# 4-B: 渲染确认卡片
# ============================================================

CONFIDENCE_LABELS = {
    'high': ('✅ 高置信度', '默认通过，用户可不操作'),
    'medium': ('⚠️ 中置信度', '建议确认'),
    'low': ('🔴 低置信度', '必须确认'),
    'missing': ('❌ 缺失', '必须补充或确认标黄'),
}


def _group_items_by_chapter(plan: Dict) -> Dict[str, List[Dict]]:
    """把 Plan 中的 items 按章节分组。

    分组依据：item['chapter'] 或 item['semantic_tag'] 前缀或 item['id'] 前缀。
    """
    items = plan.get('items', [])
    if not items:
        # 兼容直接是 list 的 plan
        if isinstance(plan, list):
            items = plan

    chapters = {}
    for item in items:
        # 优先用 chapter 字段
        chapter = item.get('chapter') or item.get('section') or ''
        if not chapter:
            # 从 id 推断（如 "ch2_identity_text" → "ch2"）
            item_id = item.get('id', '')
            if '_' in item_id:
                chapter = item_id.split('_')[0]
            else:
                chapter = '其他'
        chapters.setdefault(chapter, []).append(item)

    return chapters


def render_plan_cards(plan: Union[str, Dict, List], output_md_path: Optional[str] = None) -> str:
    """
    把 FILL Plan 渲染成 Markdown 确认卡片。

    Args:
        plan: Plan 路径（.json）或 Plan dict 或 Plan list
        output_md_path: 输出 .md 文件路径（可选）

    Returns:
        Markdown 文本
    """
    # 加载 Plan
    if isinstance(plan, str):
        with open(plan, 'r', encoding='utf-8') as f:
            plan = json.load(f)

    # 统一成 dict 结构
    if isinstance(plan, list):
        plan = {'items': plan}

    items = plan.get('items', [])
    chapters = _group_items_by_chapter(plan)

    # 统计
    stats = {'high': 0, 'medium': 0, 'low': 0, 'missing': 0}
    for item in items:
        conf = classify_confidence(item)
        stats[conf] += 1

    # 生成 Markdown
    lines = []
    lines.append("# FILL Plan 逐章节确认卡片")
    lines.append("")
    lines.append("> **本文件由 HITL 模块自动生成，请逐章节确认后回复。**")
    lines.append("> - 高置信度项（✅）默认通过，无需操作")
    lines.append("> - 中/低置信度项（⚠️/🔴）建议确认或修改")
    lines.append("> - 缺失项（❌）必须补充或确认标黄")
    lines.append("")
    lines.append("## 总览")
    lines.append("")
    lines.append(f"| 置信度 | 数量 | 说明 |")
    lines.append(f"|--------|------|------|")
    for conf in ['high', 'medium', 'low', 'missing']:
        label, desc = CONFIDENCE_LABELS[conf]
        lines.append(f"| {label} | {stats[conf]} | {desc} |")
    lines.append(f"| **合计** | **{len(items)}** | |")
    lines.append("")
    lines.append("---")
    lines.append("")

    # 逐章节渲染
    seq = 0  # 全局序号，用户回复用
    for chapter, chapter_items in chapters.items():
        lines.append(f"## 章节：{chapter}")
        lines.append("")

        for item in chapter_items:
            seq += 1
            conf = classify_confidence(item)
            label, desc = CONFIDENCE_LABELS[conf]
            item_id = item.get('id', '')
            kind = item.get('kind', '')
            semantic_tag = item.get('semantic_tag', '')
            format_str = item.get('format', '')
            value = item.get('value', '')
            src = item.get('src', '')
            value_source = item.get('value_source', '') or item.get('source', '')

            lines.append(f"### {seq}. [{label}] {semantic_tag or item_id}")
            lines.append("")
            lines.append(f"- **槽位 ID**：`{item_id}`")
            lines.append(f"- **类型**：{kind} / 格式：`{format_str}`")
            if value:
                value_display = str(value)[:80] + ('...' if len(str(value)) > 80 else '')
                lines.append(f"- **填充值**：`{value_display}`")
            if src:
                src_display = os.path.basename(str(src)) if isinstance(src, str) else str(src)
                lines.append(f"- **图片来源**：`{src_display}`")
            if value_source:
                lines.append(f"- **值来源**：{value_source}")
            lines.append(f"- **置信度说明**：{desc}")
            lines.append("")

            # 用户操作提示
            if conf == 'high':
                lines.append(f"  👉 默认通过。如需修改回复 `{seq}.修改:新值`")
            elif conf == 'medium':
                lines.append(f"  👉 建议确认。回复 `{seq}.确认` 或 `{seq}.修改:新值`")
            elif conf == 'low':
                lines.append(f"  👉 必须确认。回复 `{seq}.确认` 或 `{seq}.修改:新值` 或 `{seq}.标黄`")
            else:  # missing
                lines.append(f"  👉 缺失项。回复 `{seq}.补充:值` 或 `{seq}.标黄`")
            lines.append("")

        lines.append("---")
        lines.append("")

    # 快捷回复说明
    lines.append("## 快捷回复格式")
    lines.append("")
    lines.append("```")
    lines.append("# 逐项确认（用序号）")
    lines.append("1.确认")
    lines.append("2.修改:新公司名")
    lines.append("3.标黄")
    lines.append("4.补充:13800138000")
    lines.append("")
    lines.append("# 批量操作")
    lines.append("全部确认            # 所有高/中置信度项默认通过")
    lines.append("全部标黄缺失项      # 所有缺失项标黄")
    lines.append("")
    lines.append("# 章节级操作")
    lines.append("章节ch2:全部确认    # ch2 章节所有项确认")
    lines.append("```")
    lines.append("")
    lines.append("> 回复后，AI 会生成最终执行版 Plan 并调用 stage4_fill_plan.py 生成投标文件。")

    md_text = '\n'.join(lines)

    # 写文件
    if output_md_path:
        Path(output_md_path).write_text(md_text, encoding='utf-8')
        _logger.info(f"确认卡片已保存: {output_md_path}")

    return md_text


# ============================================================
# 4-C: 解析用户确认 + 应用到 Plan
# ============================================================

def parse_user_confirmation(confirmation_text: str) -> Dict:
    """
    解析用户确认回复。

    支持的语法：
      "1.确认"                     → item 1 确认
      "2.修改:新值"                → item 2 修改为新值
      "3.标黄"                     → item 3 标黄
      "4.补充:值"                  → item 4 补充值
      "全部确认"                   → 所有项确认
      "全部标黄缺失项"             → 所有缺失项标黄
      "章节ch2:全部确认"           → ch2 章节全部确认

    Returns:
        {
            'item_actions': {1: 'confirm', 2: ('modify', '新值'), 3: 'yellow', 4: ('fill', '值')},
            'global_action': 'confirm_all' | 'yellow_missing' | None,
            'chapter_actions': {'ch2': 'confirm_all'}
        }
    """
    result = {
        'item_actions': {},
        'global_action': None,
        'chapter_actions': {},
    }

    lines = confirmation_text.strip().split('\n')
    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue

        # 全局操作
        if line == '全部确认':
            result['global_action'] = 'confirm_all'
            continue
        if line == '全部标黄缺失项':
            result['global_action'] = 'yellow_missing'
            continue

        # 章节级操作
        if line.startswith('章节') and ':' in line:
            chapter_part, action = line.split(':', 1)
            chapter = chapter_part.replace('章节', '').strip()
            if action.strip() == '全部确认':
                result['chapter_actions'][chapter] = 'confirm_all'
            elif action.strip() == '全部标黄':
                result['chapter_actions'][chapter] = 'yellow_all'
            continue

        # 逐项操作
        if '.' in line:
            parts = line.split('.', 1)
            try:
                seq = int(parts[0])
            except ValueError:
                continue
            action = parts[1].strip()

            if action == '确认':
                result['item_actions'][seq] = 'confirm'
            elif action == '标黄':
                result['item_actions'][seq] = 'yellow'
            elif action.startswith('修改:'):
                result['item_actions'][seq] = ('modify', action[3:])
            elif action.startswith('补充:'):
                result['item_actions'][seq] = ('fill', action[3:])

    _logger.info(f"用户确认解析: {len(result['item_actions'])} 项操作, 全局={result['global_action']}")
    return result


def apply_confirmation_to_plan(plan: Union[str, Dict, List],
                                confirmation: Dict) -> Dict:
    """
    把用户确认应用到 Plan，生成最终执行版 Plan。

    Args:
        plan: 原始 Plan
        confirmation: parse_user_confirmation 返回的 dict

    Returns:
        最终执行版 Plan（每个 item 增加 'final_status' 字段：
        'confirmed' / 'modified' / 'yellow' / 'filled' / 'default_pass'）
    """
    # 加载 Plan
    if isinstance(plan, str):
        with open(plan, 'r', encoding='utf-8') as f:
            plan = json.load(f)
    if isinstance(plan, list):
        plan = {'items': plan}

    items = plan.get('items', [])
    chapters = _group_items_by_chapter(plan)

    # 构建 seq → item 映射（与 render_plan_cards 一致的序号）
    seq_to_item = {}
    seq = 0
    for chapter in chapters:
        for item in chapters[chapter]:
            seq += 1
            seq_to_item[seq] = item

    # 应用全局操作
    global_action = confirmation.get('global_action')
    if global_action == 'confirm_all':
        for s, item in seq_to_item.items():
            conf = classify_confidence(item)
            if conf in ('high', 'medium') and s not in confirmation['item_actions']:
                item['final_status'] = 'default_pass'

    elif global_action == 'yellow_missing':
        for s, item in seq_to_item.items():
            conf = classify_confidence(item)
            if conf == 'missing' and s not in confirmation['item_actions']:
                item['final_status'] = 'yellow'

    # 应用章节级操作
    for chapter, action in confirmation.get('chapter_actions', {}).items():
        for item in chapters.get(chapter, []):
            # 找到该 item 的 seq
            for s, it in seq_to_item.items():
                if it is item:
                    if s in confirmation['item_actions']:
                        continue  # 逐项操作优先
                    if action == 'confirm_all':
                        item['final_status'] = 'default_pass'
                    elif action == 'yellow_all':
                        item['final_status'] = 'yellow'
                    break

    # 应用逐项操作
    for seq, action in confirmation['item_actions'].items():
        item = seq_to_item.get(seq)
        if not item:
            continue

        if action == 'confirm':
            item['final_status'] = 'confirmed'
        elif action == 'yellow':
            item['final_status'] = 'yellow'
        elif isinstance(action, tuple) and action[0] == 'modify':
            item['value'] = action[1]
            item['final_status'] = 'modified'
            item['value_source'] = 'user_confirmed'
        elif isinstance(action, tuple) and action[0] == 'fill':
            item['value'] = action[1]
            item['final_status'] = 'filled'
            item['value_source'] = 'user_filled'

    # 未操作的项：高置信度默认通过，其他标黄
    for item in items:
        if 'final_status' not in item:
            conf = classify_confidence(item)
            if conf == 'high':
                item['final_status'] = 'default_pass'
            elif conf == 'medium':
                item['final_status'] = 'default_pass'  # 中置信度未操作也默认通过
            else:
                item['final_status'] = 'yellow'

    plan['items'] = items
    plan['hitl_applied'] = True
    return plan


# ============================================================
# CLI 入口
# ============================================================


# ============================================================
# 资料规范化确认 (v20.3 新增)
# ============================================================

def parse_material_confirmation(confirmation_text: str) -> Dict:
    """
    解析用户对资料规范化建议的确认回复。

    支持的语法：
      "1.确认"                     → 接受 AI 建议
      "2.修改:营业执照.jpg"        → 修改为新文件名
      "3.手动指定:法人身份证正面"   → 手动指定资料类型
      "4.跳过"                     → 保留原名
      "全部确认"                   → 所有高/中置信度项默认通过
      "全部跳过未识别"             → 未识别文件保留原名
    """
    result = {
        'item_actions': {},
        'global_action': None,
    }

    lines = confirmation_text.strip().split('\n')
    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue

        if line == '全部确认':
            result['global_action'] = 'confirm_all'
            continue
        if line == '全部跳过未识别':
            result['global_action'] = 'skip_unidentified'
            continue

        if '.' in line:
            parts = line.split('.', 1)
            try:
                seq = int(parts[0])
            except ValueError:
                continue
            action = parts[1].strip()

            if action == '确认':
                result['item_actions'][seq] = 'confirm'
            elif action == '跳过':
                result['item_actions'][seq] = 'skip'
            elif action.startswith('修改:'):
                result['item_actions'][seq] = ('rename', action[3:])
            elif action.startswith('手动指定:'):
                result['item_actions'][seq] = ('specify_type', action[5:])

    _logger.info(f"资料规范化确认解析: {len(result['item_actions'])} 项操作")
    return result


def apply_material_confirmation(normalize_result: Dict, confirmation: Dict) -> Dict:
    """
    把用户确认应用到规范化结果，生成最终执行版规范化方案。

    Args:
        normalize_result: MaterialNormalizer.normalize() 返回的 dict
        confirmation: parse_material_confirmation() 返回的 dict

    Returns:
        更新后的 normalize_result（每个 file 增加 'final_status' 字段）
    """
    files = normalize_result.get('files', [])

    # 应用全局操作
    global_action = confirmation.get('global_action')
    if global_action == 'confirm_all':
        for i, f in enumerate(files, 1):
            if i not in confirmation['item_actions']:
                if f['confidence'] >= 0.6 and f['suggested_type'] != '未识别':
                    f['final_status'] = 'confirmed'
                elif f['suggested_type'] == '未识别':
                    f['final_status'] = 'skipped'
    elif global_action == 'skip_unidentified':
        for i, f in enumerate(files, 1):
            if i not in confirmation['item_actions'] and f['suggested_type'] == '未识别':
                f['final_status'] = 'skipped'

    # 应用逐项操作
    for seq, action in confirmation['item_actions'].items():
        if seq < 1 or seq > len(files):
            continue
        f = files[seq - 1]

        if action == 'confirm':
            f['final_status'] = 'confirmed'
        elif action == 'skip':
            f['final_status'] = 'skipped'
        elif isinstance(action, tuple) and action[0] == 'rename':
            f['suggested_name'] = action[1]
            f['final_status'] = 'renamed'
        elif isinstance(action, tuple) and action[0] == 'specify_type':
            f['suggested_type'] = action[1]
            # 重新生成建议文件名
            ext = f.get('ext', '')
            f['suggested_name'] = f"{action[1]}{ext}"
            f['final_status'] = 'specified'
            f['confidence'] = 1.0  # 用户指定的，置信度 100%

    # 未操作的项：高置信度默认确认，低置信度标黄
    for f in files:
        if 'final_status' not in f:
            if f['confidence'] >= 0.85:
                f['final_status'] = 'confirmed'
            elif f['confidence'] >= 0.6:
                f['final_status'] = 'confirmed'  # 中置信度也默认通过
            elif f['confidence'] > 0:
                f['final_status'] = 'needs_review'
            else:
                f['final_status'] = 'skipped'

    normalize_result['files'] = files
    normalize_result['material_hitl_applied'] = True
    return normalize_result



def main():
    """命令行入口：渲染确认卡片"""
    import argparse
    parser = argparse.ArgumentParser(description='HITL 确认卡片渲染 (v20.1+)')
    parser.add_argument('--plan', required=True, help='FILL Plan JSON 路径')
    parser.add_argument('--output', help='输出 Markdown 路径（默认: plan_review.md）')
    parser.add_argument('--apply', help='应用用户确认（传入确认文本文件路径）')
    args = parser.parse_args()

    if args.apply:
        # 应用确认模式
        with open(args.apply, 'r', encoding='utf-8') as f:
            confirmation_text = f.read()
        confirmation = parse_user_confirmation(confirmation_text)
        final_plan = apply_confirmation_to_plan(args.plan, confirmation)

        out_path = args.output or args.plan.replace('.json', '_final.json')
        with open(out_path, 'w', encoding='utf-8') as f:
            json.dump(final_plan, f, ensure_ascii=False, indent=2)
        print(f"✓ 最终执行版 Plan 已保存: {out_path}")
    else:
        # 渲染卡片模式
        out_path = args.output or 'plan_review.md'
        md = render_plan_cards(args.plan, out_path)
        print(f"✓ 确认卡片已保存: {out_path}")
        print(f"  共 {md.count('###')} 个槽位待确认")


if __name__ == '__main__':
    main()
