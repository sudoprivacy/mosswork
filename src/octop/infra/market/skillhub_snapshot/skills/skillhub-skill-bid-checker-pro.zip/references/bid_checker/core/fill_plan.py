# -*- coding: utf-8 -*-
"""
fill_plan.py — Stage 3 的「唯一交付物」：FILL Plan（机器可读填充计划）
=========================================================================

设计意图（用户 2026-07-12 拍板）：
  - 「需求填入报告」(prose) 废除，不再生成给人看，也不给 AI 当散文读。
  - Stage 3 直接产出 FILL Plan JSON：每个槽位 = 一条结构化指令，
    AI 只需决定「kind + format 原语 + value_source」，Stage 4 照指令机械执行。
  - 语义与格式彻底解耦：AI 不写尺寸/分页代码，只选原语。

本模块是「标签语义」的唯一权威来源：
  - LABEL_RULES 沉淀「通用投标文档字段 → 标签写法」的领域知识（非项目硬编码，
    是投标书常见字段约定）。Stage 3 据此把 label 写进 Plan，Stage 4 照着填。
  - 图片 src 解析：身份证优先取权威 OCR supply JSON 完整路径；其余按文件名在
    media 目录检索。身份证正反面按「人」分组，是否进单元格由计划决定。

format 原语枚举（对应 image_format.py / format_guardrails.py 的确定实现）：
  text 类：
    inline_after_label  标签后填值（自动清标签前后空格） -> format_guardrails.fill_after_label
    inline_paren        括号内占位替换（如（项目编号： ）） -> format_guardrails.fill_inline_paren
  image 类：
    full_page          除身份证外所有图片：整页 contain 竖放 -> image_format.insert_full_page_image
    cell_id            单元格内身份证：按单元格大小         -> image_format.insert_cell_image
    id_pair            无单元格身份证：正反左右并排横放一页 -> image_format.insert_id_pair_page

Plan item schema（自包含，Stage 4 不需要再反推任何东西）：
  text : {id,kind,semantic_tag,format,status,group,value,labels[],inline_tokens[],paren[]}
  image: {id,kind,semantic_tag,format,status,person,side,src,target?}
  table: {id,kind,semantic_tag,format,status,table_idx,table_action,mkb_tag?}
"""
import json
import os
import re
from collections import Counter

# 开标日期（固化值由 config 提供；此处默认，可在 main 覆盖）
DEFAULT_OPEN_DATE = '2025年08月13日'

IMG_SEMANTICS = ('身份证', 'identity', 'id_card')

# --------------------------------------------------------------------------
# LABEL_RULES —— 通用投标文档字段的「标签语义」知识库
#   labels       : 在文档里「标签：值」写法的标签串（全部匹配段落都会被填）
#   inline_tokens: 行内占位 token（如 （项目名称））
#   paren        : （标签： ）括号占位的标签（如 项目编号）
#   group        : simple / legal / auth / date / missing_simple
# --------------------------------------------------------------------------
LABEL_RULES = {
    '开标日期':      {'labels': ['开标日期：', '开标时间：'], 'inline_tokens': [], 'paren': [], 'group': 'date'},
    '投标日期':      {'labels': ['投标日期：', '日期：'], 'inline_tokens': [], 'paren': [], 'group': 'date'},
    '签名日期':      {'labels': ['日期：', '日 期：', '日    期：'], 'inline_tokens': [], 'paren': [], 'group': 'date'},
    '项目名称':      {'labels': ['项目名称：'], 'inline_tokens': ['（项目名称）'], 'paren': [], 'group': 'simple'},
    '项目编号':      {'labels': ['项目编号：'], 'inline_tokens': [], 'paren': ['项目编号'], 'group': 'simple'},
    # v20.3.2: 投标人名称——覆盖 fill_positions 的 field_name
    '投标人名称':    {'labels': ['投标人名称：', '投标人：', '供应商名称：', '投 标 人：', '投   标   人：'], 'inline_tokens': ['（投标人名称）'], 'paren': [], 'group': 'simple'},
    '供应商名称':    {'labels': ['投标人名称：', '投标人：', '供应商名称：', '投 标 人：', '投   标   人：'], 'inline_tokens': ['（投标人名称）'], 'paren': [], 'group': 'simple'},
    '招标人名称':    {'labels': ['招标人名称：', '采购人名称：'], 'inline_tokens': ['（招标人名称）'], 'paren': [], 'group': 'simple'},
    '采购人名称':    {'labels': ['招标人名称：', '采购人名称：'], 'inline_tokens': ['（招标人名称）'], 'paren': [], 'group': 'simple'},
    '注册地址':      {'labels': ['注册地址：', '联系地址：', '地    址：', '地 址：', '地址：'], 'inline_tokens': [], 'paren': [], 'group': 'simple'},
    '联系地址':      {'labels': ['联系地址：', '注册地址：', '地    址：', '地址：'], 'inline_tokens': [], 'paren': [], 'group': 'missing_simple'},
    '联系电话':      {'labels': ['联系电话：', '电话：', '电    话：'], 'inline_tokens': [], 'paren': [], 'group': 'missing_simple'},
    '成立时间':      {'labels': ['成立时间：'], 'inline_tokens': [], 'paren': [], 'group': 'simple'},
    '经营期限':      {'labels': ['经营期限：'], 'inline_tokens': [], 'paren': [], 'group': 'simple'},
    '单位性质':      {'labels': ['单位性质：', '单位类型：'], 'inline_tokens': [], 'paren': [], 'group': 'simple'},
    '传真':          {'labels': ['传真：', '传    真：', '传真:'], 'inline_tokens': [], 'paren': [], 'group': 'missing_simple'},
    '邮编':          {'labels': ['邮编：', '邮政编码：', '邮    编：', '邮编:'], 'inline_tokens': [], 'paren': [], 'group': 'missing_simple'},
    '电子邮箱':      {'labels': ['电子邮箱：', '邮箱：', 'E-mail：', 'Email：'], 'inline_tokens': [], 'paren': [], 'group': 'missing_simple'},
    # legal 组
    '法定代表人':     {'labels': [], 'inline_tokens': [], 'paren': [], 'group': 'legal'},
    '法定代表人姓名':   {'labels': [], 'inline_tokens': [], 'paren': [], 'group': 'legal'},
    '法定代表人性别年龄': {'labels': [], 'inline_tokens': [], 'paren': [], 'group': 'legal'},
    '姓名':          {'labels': ['姓名：'], 'inline_tokens': [], 'paren': [], 'group': 'legal'},
    '性别':          {'labels': ['性别：', '性 别：', '性    别：'], 'inline_tokens': [], 'paren': [], 'group': 'legal'},
    '年龄':          {'labels': ['年龄：', '年 龄：', '年    龄：'], 'inline_tokens': [], 'paren': [], 'group': 'legal'},
    '职务':          {'labels': ['职务：', '职 务：', '职    务：'], 'inline_tokens': [], 'paren': [], 'group': 'legal'},
    # auth 组
    '被授权人性别年龄':   {'labels': [], 'inline_tokens': [], 'paren': [], 'group': 'auth'},
    '被授权人身份证号':   {'labels': ['身份证号码：', '身份证明号码：'], 'inline_tokens': [], 'paren': [], 'group': 'auth'},
    '授权代表':       {'labels': ['授权代表：'], 'inline_tokens': [], 'paren': [], 'group': 'auth'},
    '系投标人名称(法定代表人句)': {'labels': [], 'inline_tokens': ['（投标人名称）'], 'paren': [], 'group': 'legal'},
    '法定代表人身份证明':   {'labels': [], 'inline_tokens': ['（投标人名称）'], 'paren': [], 'group': 'legal'},
    '法定代表人授权委托书': {'labels': [], 'inline_tokens': ['（投标人名称）', '（项目名称）'], 'paren': [], 'group': 'auth'},
}


def classify_format(slot, match):
    """根据槽位语义/位置，决定使用哪个格式原语。这是 AI 在 Stage 3 的『唯一格式判断』。"""
    kind = (slot.get('kind') or match.get('kind') or '').lower()
    sem = slot.get('semantic_tag', '') or ''
    loc = slot.get('location') or {}

    is_image = (kind == 'image') \
        or ('image' in str(slot.get('fill_source', '')).lower()) \
        or any(k in sem for k in ('图片', '图', '营业执照', '检测报告', '彩页',
                                  '授权书', '证书', '资质', '证件'))
    if is_image:
        if any(k in sem for k in IMG_SEMANTICS):
            # 身份证：目标在单元格内 -> cell_id，否则无单元格 -> id_pair
            # （注意：是否进单元格由 build_fill_plan 的正反面分组最终裁定）
            loc_str = json.dumps(loc, ensure_ascii=False)
            if any(k in loc_str for k in ('col', 'row', 'cell', 'table')):
                return 'cell_id'
            return 'id_pair'
        return 'full_page'

    label = (loc.get('label') or slot.get('label') or '')
    if '（' in label or '(' in label:
        return 'inline_paren'
    return 'inline_after_label'


# --------------------------------------------------------------------------
# 图片 src 解析
# --------------------------------------------------------------------------
def resolve_image_path(filename, media_base, here):
    """给定图片文件名，在 media_base / here 递归查找，返回绝对路径或 None。"""
    if not filename:
        return None
    if os.path.isabs(filename) and os.path.exists(filename):
        return filename
    candidates = []
    if media_base:
        candidates.append(os.path.join(media_base, os.path.basename(filename)))
    candidates.append(os.path.join(here, os.path.basename(filename)))
    for c in candidates:
        if os.path.exists(c):
            return c
    # 递归搜索 here
    for root, _, files in os.walk(here):
        if os.path.basename(filename) in files:
            return os.path.join(root, os.path.basename(filename))
    return None


def _person_of(sem):
    if '法定代表人' in sem or '法人' in sem:
        return '法定代表人'
    if '被授权人' in sem or '授权人' in sem or '授权代表' in sem:
        return '被授权人'
    return None


def _side_of(sem):
    # v20.3.1: 修复身份证正反面识别——支持更多命名变体
    if '正面' in sem or '人像' in sem or '正面' in sem:
        return '正面'
    if '反面' in sem or '背面' in sem or '国徽' in sem:
        return '反面'
    # v20.3.1: 如果 sem 含"身份证"但没有正反面字样，默认返回正面
    # （反面由分组逻辑自动补充）
    if '身份证' in sem:
        return '正面'
    return None


# --------------------------------------------------------------------------
# 计划构建
# --------------------------------------------------------------------------
# v20.2 审查清理：原此处有一个简版 build_fill_plan（line 135-244），
# 被 line 616 的扩展版覆盖（Python 后定义的覆盖前面的），属于死代码。
# 已删除简版，保留扩展版（支持 quote_xlsx/qual_doc/brochure_dir 等参数）。



def _table_action(sem):
    """v20.3.1: 人员表优先用 supply 数据，没有则标黄"""
    if '报价' in sem or '分项' in sem:
        return 'fill_quote'      # 由 plan['quote']（xlsx）填总报价+分项
    if '偏离' in sem:
        return 'deviation'       # 标准「无偏离」行
    if '人员' in sem or '业绩' in sem:
        return 'fill_mkb'        # 从 MKB 表格事实填行
    return 'yellow'


def _mkb_tag_for(sem):
    if '人员' in sem:
        return '表格:六、本项目拟投入人员汇总表'
    if '业绩' in sem:
        return '业绩表'
    return None


# --------------------------------------------------------------------------
# 报价（从 xlsx 抽取）-> plan['quote']
# --------------------------------------------------------------------------
def _num(v):
    try:
        return '{:,.2f}'.format(float(v))
    except (TypeError, ValueError):
        return '' if v is None else str(v)


def _unit(u):
    if u is None:
        return ''
    u = str(u).strip()
    return u


def num_to_capital(num):
    """人民币金额 -> 中文大写（如 1921507.96 -> 壹佰玖拾贰万壹仟伍佰零柒元玖角陆分）。"""
    num = round(float(num) + 1e-9, 2)
    if num == 0:
        return '零元整'
    int_part = int(num)
    dec = int(round((num - int_part) * 100))
    digits = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖']
    int_units = ['', '拾', '佰', '仟']
    big_units = ['', '万', '亿', '兆']

    def int2cap(n):
        if n == 0:
            return ''
        s = str(n)
        groups = []
        while s:
            groups.append(s[-4:])
            s = s[:-4]
        groups = groups[::-1]
        res = ''
        for gi, g in enumerate(groups):
            g = g.zfill(4)
            gcap = ''
            zero_flag = False
            for i, ch in enumerate(g):
                d = int(ch)
                if d == 0:
                    zero_flag = True
                else:
                    if zero_flag and gcap:
                        gcap += '零'
                    gcap += digits[d] + int_units[3 - i]
                    zero_flag = False
            if gcap:
                res += gcap + big_units[len(groups) - 1 - gi]
        return res

    cap = int2cap(int_part) + '元'
    if dec == 0:
        cap += '整'
    else:
        jiao = dec // 10
        fen = dec % 10
        if jiao:
            cap += digits[jiao] + '角'
        if fen:
            cap += digits[fen] + '分'
    return cap


def build_quote(xlsx_path, detail_per_sheet=4):
    """从报价 xlsx 抽取：总报价、大写、分项明细（2 大系统 + 每系统若干子项，共 10 行）。"""
    import openpyxl
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    ov = wb['总览']
    overview = []
    total = None
    for r in range(3, ov.max_row + 1):
        name = ov.cell(r, 2).value
        qty = ov.cell(r, 4).value
        unit = ov.cell(r, 5).value
        amount = ov.cell(r, 6).value
        if name is None:
            continue
        if str(name).startswith('合计'):
            total = amount
            continue
        overview.append((str(name), qty, unit, amount))
    if total is None:
        total = sum(a for _, _, _, a in overview if isinstance(a, (int, float)))

    details = []
    # v21.0.1: 动态读取所有 sheet（不再硬编码 sheet 名）
    for sheet_name in wb.sheetnames:
        sh = wb[sheet_name]
        cnt = 0
        for r in range(3, sh.max_row + 1):
            dev = sh.cell(r, 2).value
            if not dev:
                continue
            if '系统' in str(dev) and ('含' in str(dev) or str(dev).endswith('系统')):
                continue  # 系统标题行
            qty = sh.cell(r, 4).value
            unit = sh.cell(r, 5).value
            price = sh.cell(r, 7).value
            amount = sh.cell(r, 8).value
            if not isinstance(qty, (int, float)):
                continue
            # v21.0.1: brand 从 xlsx 读取（不硬编码）
            brand = sh.cell(r, 3).value or ''
            details.append((str(dev), qty, unit, price, amount, str(brand) if brand else ''))
            cnt += 1
            if cnt >= detail_per_sheet:
                break

    items = []
    seq = 1
    for name, qty, unit, amount in overview:
        items.append({'seq': str(seq), 'name': name, 'brand': '', 'spec': '',
                      'qty': _num(qty), 'unit': _unit(unit),
                      'price': _num(amount), 'amount': _num(amount)})
        seq += 1
    for dev, qty, unit, price, amount, brand in details:
        items.append({'seq': str(seq), 'name': dev, 'brand': brand, 'spec': '',
                      'qty': _num(qty), 'unit': _unit(unit),
                      'price': _num(price), 'amount': _num(amount)})
        seq += 1

    total_f = float(total)
    return {
        'total': total_f,
        'total_text': _num(total_f),
        'capital': num_to_capital(total_f),
        'items': items,
    }


# --------------------------------------------------------------------------
# 资质图 / 彩页：通用定位（扫描模板识别章节+小标题，绝不写死"第七章"）
# --------------------------------------------------------------------------
def _detect_yeji_table_idx(doc):
    """检测目标模板中「业绩」表索引（通用）。"""
    from docx.text.paragraph import Paragraph as _P
    body = doc.element.body

    def _is_toc_line(t):
        if '......' in t:
            return True
        if t.count('.') >= 3 and t.strip() and t.strip()[-1].isdigit():
            return True
        return False

    def _preceding_para_text(tbl_el):
        out = None
        for child in body:
            if child is tbl_el:
                return out
            if child.tag.endswith('}p'):
                t = _P(child, doc).text.strip()
                if t:
                    out = t
        return out

    for i, tbl in enumerate(doc.tables):
        pre = _preceding_para_text(tbl._tbl)
        if pre and '业绩' in pre and not _is_toc_line(pre) and len(pre) < 40:
            return i
    return None


def _detect_top_level_headings(doc):
    """检测目标模板中一级章节标题，返回 {keyword: heading_text}。"""
    headings = {}
    for p in doc.paragraphs:
        t = p.text.strip()
        if len(t) > 60:
            continue
        # 一级章节模式：一、二、... 或 第X章
        if re.match(r'^[一二三四五六七八九十百]+、', t):
            if '法定代表人身份证明' in t:
                headings['法人身份证明'] = t
            elif '法定代表人授权' in t:
                headings['授权委托书'] = t
    return headings


def _map_source_group_to_target(heading, subheads, section_h, top_heads, yeji_idx):
    """把源资料分组标题映射到目标投标文件插入位置。
    v20.3.1: 增强小标题匹配——按资料类型关键词精确匹配小标题。"""
    h = heading or ''
    # 身份证 / 法人身份证明 直接进第二章
    if any(k in h for k in ('法定代表人身份证明', '法人身份证明', '身份证')):
        return top_heads.get('法人身份证明') or '二、法定代表人身份证明'
    # 授权委托书 进第三章
    if any(k in h for k in ('法定代表人授权书', '授权委托书', '授权书')):
        return top_heads.get('授权委托书') or '三、法定代表人授权委托书'
    # 业绩案例 插到业绩表后
    if any(k in h for k in ('业绩', '案例', '合同')) and yeji_idx is not None:
        return '_AFTER_TABLE:%d' % yeji_idx
    # 产品彩页
    if '彩页' in h:
        for sh in subheads:
            if '彩页' in sh:
                return sh
        return section_h

    # v20.3.3: 按资料类型关键词精确匹配小标题
    # 资料类型 → 小标题关键词映射（通用，不依赖项目特定命名）
    MATERIAL_TO_SUBHEAD_KW = {
        '营业执照': ['营业执照', '主体资格', '法人资格', '独立承担'],
        '财务': ['财务', '审计', '财务状况'],
        '税收': ['税收', '纳税', '完税'],
        '社保': ['社保', '社会保障', '社会保险'],
        '信用': ['信用中国', '失信', '信用记录', '信用信息', '信用查询'],
        '设备': ['设备', '履约', '专业技术能力'],
        '守法': ['守法', '违法', '重大违法'],
        '关联': ['控股', '关联', '管理关系'],
        '联合体': ['联合体'],
        '资质证书': ['资质', 'ISO', '认证'],
        '检测报告': ['检测', '测试', '检验'],
        '厂家授权': ['厂家授权', '厂商授权', '代理授权'],
    }

    # v20.3.3: 排除规则——"统一社会信用代码"是营业执照的特征，不是信用查询
    EXCLUDE_FROM_MATCH = {
        '信用': ['统一社会信用代码', '社会信用代码'],
    }

    # 用源标题匹配资料类型
    for mat_type, kws in MATERIAL_TO_SUBHEAD_KW.items():
        if any(kw in h for kw in kws):
            # 检查排除规则
            exclude_kws = EXCLUDE_FROM_MATCH.get(mat_type, [])
            # 找对应的小标题
            for sh in subheads:
                # 排除含"统一社会信用代码"的小标题（防止信用图片误匹配到营业执照）
                if any(ekw in sh for ekw in exclude_kws):
                    continue
                if any(kw in sh for kw in kws):
                    return sh
            break

    # 其他资质：用源标题去匹配资质章节小标题
    if subheads:
        from template_review import classify_image_to_subheading
        idx = classify_image_to_subheading(h, subheads)
        if idx is not None:
            return subheads[idx]
    return section_h


def add_qualification_images(plan, qual_doc, brochure_dir, out_dir, here, template=None):
    from source_material import read_source_materials
    from template_review import detect_qualification_layout
    os.makedirs(out_dir, exist_ok=True)
    # 通用识别：资质证明章节标题 + 其下编号小标题
    layout = detect_qualification_layout(template) if template and os.path.exists(template) else None
    section_h = layout['section'] if layout else None
    subheads = layout['subheads'] if layout else []
    if not section_h:
        section_h = '资质证明文件'

    # 模板额外结构：业绩表索引、法人/授权章节标题
    yeji_idx = None
    top_heads = {}
    if template and os.path.exists(template):
        from docx import Document
        tdoc = Document(template)
        yeji_idx = _detect_yeji_table_idx(tdoc)
        top_heads = _detect_top_level_headings(tdoc)

    added = 0

    # 资格证明图：按源资料分组读取，组内保持原顺序，组标题映射到目标小节
    sources = []
    if qual_doc:
        if isinstance(qual_doc, (list, tuple)):
            sources.extend([p for p in qual_doc if os.path.exists(p)])
        elif os.path.exists(qual_doc):
            sources.append(qual_doc)

    if sources:
        groups = read_source_materials(sources, out_dir, prefix='qual')
        # 身份证/授权书章节中的图片已在 cell_id 计划项中单独处理，避免从源资料重复插入
        identity_chaps = ('法定代表人身份证明', '法人身份证明', '法定代表人授权', '授权委托书')
        for g in groups:
            th = _map_source_group_to_target(g['heading'], subheads, section_h, top_heads, yeji_idx)
            if th and any(k in th for k in identity_chaps):
                continue
            for blk in g.get('blocks', []):
                if blk['type'] == 'image':
                    plan['items'].append({
                        'kind': 'image', 'semantic_tag': '资质-' + (g['heading'][:20]),
                        'format': 'full_page', 'status': 'matched',
                        'person': None, 'side': None,
                        'src': os.path.abspath(blk['path']),
                        'caption': '',  # 不在图片前插 caption
                        'insert_after_heading': th,
                    })
                    added += 1
                elif blk['type'] == 'subheading':
                    # 业绩组内项目名 -> 子标题，插入时分隔多个业绩
                    plan['items'].append({
                        'kind': 'heading', 'text': blk['text'],
                        'insert_after_heading': th,
                    })
                    added += 1
                elif blk['type'] == 'text':
                    # 资料文件里的文字段落（承诺/声明/说明等）按原顺序复制
                    plan['items'].append({
                        'kind': 'text', 'format': 'copied', 'text': blk['text'],
                        'status': 'matched', 'insert_after_heading': th,
                    })
                    added += 1
    # 注：产品彩页不在此自动插入（v20）。其落点应由「资料扫描审核阶段」按本项目章节结构
    # 显式映射决定，避免默认塞进资质文件破坏结构；本期不生成彩页项。
    plan['count'] = len(plan['items'])
    return added


def add_business_license_fields(plan, bl_supply, template=None):
    """营业执照 OCR 主动反填（通用）：扫描模板发现 单位性质/地址/经营期限/经营范围/
    成立时间 等空白字段，自动从营业执照 OCR supply 取对应值反填。不写死标签。

    模板中某字段判定为"空白需反填"：标签后仅跟下划线/空格/括号（无实质内容）。
    """
    # v20.3.2: 兼容 dict 类型和文件路径
    if not bl_supply:
        return 0
    if isinstance(bl_supply, dict):
        d = bl_supply
    elif isinstance(bl_supply, str) and os.path.exists(bl_supply):
        d = json.load(open(bl_supply, encoding='utf-8'))
    else:
        return 0
    kv = {f['tag']: f.get('value') for f in d.get('facts', []) if isinstance(f, dict) and f.get('tag')}
    if not kv:
        return 0
    # 模板字段标签 -> 取值 key（通用映射；多个 key 依次尝试）
    # 经营期限按用户要求统一固化填「长期」
    FIELD_MAP = {
        '单位性质：': ['公司类型', '企业类型', '企业性质', '类型'],
        '企业类型：': ['公司类型', '企业性质'],
        '企业性质：': ['公司类型'],
        '类型：':     ['公司类型'],
        '地址：':     ['注册地址', '住所', '地址'],
        '住所：':     ['注册地址', '住所'],
        '经营场所：': ['注册地址', '住所'],
        '注册地址：': ['注册地址', '住所'],
        '经营范围：': ['经营范围'],
        '成立时间：': ['成立时间', '成立日期', '登记日期'],
        '成立日期：': ['成立时间', '成立日期'],
        '经营期限：': ['经营期限', '营业期限'],
        '营业期限：': ['营业期限', '经营期限'],
    }
    FIXED_VALUES = {
        '经营期限：': '长期',
        '营业期限：': '长期',
    }
    added = 0
    existing = {it.get('semantic_tag') for it in plan.get('items', [])}
    if template and os.path.exists(template):
        from docx import Document
        doc = Document(template)
        for p in doc.paragraphs:
            t = p.text
            for label, keys in FIELD_MAP.items():
                if label not in t:
                    continue
                sem = label.strip('：')
                if sem in existing:
                    break  # 已存在，跳过避免重复
                after = t[t.index(label) + len(label):].strip()
                # 空白判定：空 或 仅由下划线/空格/括号构成
                if after and not set(after) <= set(' _（）()—-'):
                    break  # 该字段已有值，跳过
                val = None
                if label in FIXED_VALUES:
                    val = FIXED_VALUES[label]
                else:
                    for k in keys:
                        if k in kv and kv[k]:
                            val = kv[k]
                            break
                if val:
                    plan['items'].append({
                        'kind': 'text', 'semantic_tag': sem,
                        'format': 'inline_after_label', 'status': 'matched',
                        'group': 'simple', 'value': val,
                        'labels': [label], 'inline_tokens': [], 'paren': [],
                    })
                    added += 1
                    existing.add(sem)
                    break
    plan['count'] = len(plan['items'])
    return added


def build_fill_plan(scan_path, match_path, out_path=None, template=None,
                    media_base=None, supply_paths=None, open_date=None,
                    quote_xlsx=None, qual_doc=None, brochure_dir=None,
                    bl_supply=None, image_out_dir=None, purchaser=None):
    """v20.3.2 方案A: 直接读 fill_positions + results 构建 FILL Plan。

    数据源：
      scan_path: template_scanner.py 产出的扫描数据 JSON（含 fill_positions）
      match_path: requirement_mapper.py 产出的需求映射数据 JSON（含 results）

    不再依赖 slot_manifest / slots 结构，直接从两个字段构建。
    """
    sm = json.load(open(scan_path, encoding='utf-8'))
    mr = json.load(open(match_path, encoding='utf-8'))

    # v20.3.2: 直接读 fill_positions（扫描数据）和 results（需求映射数据）
    fill_positions = sm.get('fill_positions', [])
    if not fill_positions:
        # 兼容旧格式
        fill_positions = sm.get('slots', sm if isinstance(sm, list) else [])

    match_results = mr.get('results', mr.get('slots', []))
    # 用 req_id 构建 matches 字典
    matches = {}
    for r in match_results:
        rid = r.get('req_id') or r.get('id', '')
        if rid:
            matches[rid] = r

    here = os.path.dirname(os.path.abspath(scan_path))
    _extracted_cache = {}  # v20.3.3: 缓存已提取的源 docx 图片
    od = open_date or DEFAULT_OPEN_DATE

    # 汇总 supply
    supplies = []
    for sp in (supply_paths or []):
        if os.path.exists(sp):
            supplies.append(json.load(open(sp, encoding='utf-8')))
    # bl_supply 也加入
    if bl_supply and isinstance(bl_supply, dict):
        supplies.append(bl_supply)
    elif bl_supply and os.path.exists(str(bl_supply)):
        supplies.append(json.load(open(str(bl_supply), encoding='utf-8')))

    # v20.3.2: 自动从需求映射数据提取关键字段，构建虚拟 supply
    # v20.3.3: 增强提取——多模式招标人名称 + 营业执照字段
    import re as _re
    auto_supply = {}
    all_tc = ' '.join(m.get('text_content', '') or '' for m in matches.values())

    # --- 提取公司名（投标人名称）---
    cm = _re.search(r'([\u4e00-\u9fff]{2,4}(?:省|市|区)[\u4e00-\u9fff]{0,10}(?:有限公司|股份公司|有限责任公司|集团))', all_tc)
    if not cm:
        cm = _re.search(r'([\u4e00-\u9fff]{2,15}(?:有限公司|股份公司|有限责任公司|集团))', all_tc)
    if cm:
        auto_supply['公司名称'] = cm.group()
        auto_supply['投标人名称'] = cm.group()
        auto_supply['单位名称'] = cm.group()

    # --- 提取项目编号 ---
    pm = _re.search(r'([A-Z]{2,6}[\-\s]*\d{3,8}[号]?)', all_tc)
    if pm:
        auto_supply['项目编号'] = pm.group(1).strip()
    # 也从解析数据补充
    bi = sm.get('basic_info', {}) or {}
    if isinstance(bi.get('项目编号'), dict):
        pn = bi['项目编号'].get('value', '')
        if pn and '项目编号' not in auto_supply:
            auto_supply['项目编号'] = pn

    # --- v20.3.3: 多模式提取招标人名称 ---
    if '招标人名称' not in auto_supply:
        # 模式1: "致：XXX" / "致:XXX"
        mm1 = _re.search(r'致[：:\s]*([^\s，。,\n]{4,30}(?:学校|局|中心|院|政府|公司|委员会|办事处|总站))', all_tc)
        if mm1:
            auto_supply['招标人名称'] = mm1.group(1)
            auto_supply['采购人名称'] = mm1.group(1)
    if '招标人名称' not in auto_supply:
        # 模式2: "采购人：XXX" / "招标人：XXX"
        mm2 = _re.search(r'(?:采购人|招标人)[：:\s]*([^\s，。,\n]{4,30})', all_tc)
        if mm2 and not any(w in mm2.group(1) for w in ['项目', '招标文件', '投标']):
            auto_supply['招标人名称'] = mm2.group(1)
            auto_supply['采购人名称'] = mm2.group(1)
    if '招标人名称' not in auto_supply:
        # 模式3: 从 basic_info.采购人 提取
        if isinstance(bi.get('采购人'), dict):
            purchaser_val = bi['采购人'].get('value', '')
            if purchaser_val and len(purchaser_val) > 3 and '项目' not in purchaser_val:
                auto_supply['招标人名称'] = purchaser_val
                auto_supply['采购人名称'] = purchaser_val
    if '招标人名称' not in auto_supply and purchaser:
        auto_supply['招标人名称'] = purchaser
        auto_supply['采购人名称'] = purchaser

    # --- 提取法人姓名 ---
    lm = _re.search(r'法定代表人[（(]([^\s，。()（）]{2,4})[)）]', all_tc)
    if not lm:
        lm = _re.search(r'法定代表人[：:\s]*([^\s，。]{2,4})', all_tc)
    if lm:
        auto_supply['法人姓名'] = lm.group(1)
        auto_supply['法定代表人姓名'] = lm.group(1)

    # --- 提取被授权人姓名 ---
    am = _re.search(r'授权[^\s]{0,10}?([\u4e00-\u9fff]{2,4})', all_tc)
    if am and am.group(1) not in ['公司', '代表']:
        auto_supply['被授权人姓名'] = am.group(1)

    # --- 提取身份证号 ---
    idm = _re.findall(r'(\d{17}[\dXx])', all_tc)
    if idm:
        auto_supply['法人身份证号'] = idm[0]
        auto_supply['法定代表人身份证号'] = idm[0]
        if len(idm) > 1:
            auto_supply['被授权人身份证号'] = idm[1]

    # --- v20.3.3: 提取营业执照字段（通用正则）---
    # 单位性质
    if '单位性质' not in auto_supply:
        um = _re.search(r'(有限责任公司|股份有限公司|事业单位|合伙企业|个人独资企业|国有独资公司|集体所有制)', all_tc)
        if um:
            auto_supply['单位性质'] = um.group(1)
    # 注册地址
    if '注册地址' not in auto_supply:
        addr_m = _re.search(r'((?:北京市|天津市|上海市|重庆市|河北|山西|辽宁|吉林|黑龙江|江苏|浙江|安徽|福建|江西|山东|河南|湖北|湖南|广东|海南|四川|贵州|云南|陕西|甘肃|青海|台湾|内蒙古|广西|西藏|宁夏|新疆|香港|澳门)[\u4e00-\u9fff]{2,30}(?:号|栋|单元|楼|室|号院|号院|街|路|道|巷))', all_tc)
        if addr_m:
            auto_supply['注册地址'] = addr_m.group(1)
            auto_supply['地址'] = addr_m.group(1)
    # 成立时间
    if '成立时间' not in auto_supply:
        # 搜索含"成立"附近的日期
        found_date = _re.search(r'(?:成立|注册)[^\d]{0,10}?(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', all_tc)
        if found_date:
            auto_supply['成立时间'] = '%s年%s月%s日' % (found_date.group(1), int(found_date.group(2)), int(found_date.group(3)))
    # 统一社会信用代码
    if '统一社会信用代码' not in auto_supply:
        ccm = _re.search(r'([0-9A-Z]{18})', all_tc)
        if ccm:
            auto_supply['统一社会信用代码'] = ccm.group(1)
    # v20.3.3: 从解析数据补充项目名称
    if '项目名称' not in auto_supply:
        if isinstance(bi.get('项目名称'), dict):
            pName = bi['项目名称'].get('value', '')
            if pName and '项目编号' not in pName and len(pName) > 4:
                auto_supply['项目名称'] = pName
    # v20.3.3: 从匹配结果 source_path 推断项目名称（通用：取路径中的项目相关文字）
    if '项目名称' not in auto_supply:
        for r in match_results:
            sp = r.get('source_path', '') or ''
            # 从路径中提取可能的项目名（含"学校"/"医院"/"采购"等关键词的路径段）
            parts = sp.replace('\\', '/').split('/')
            for part in parts:
                if len(part) > 10 and any(kw in part for kw in ['采购', '项目', '学校', '医院', '系统', '工程', '建设']):
                    # 去掉文件扩展名
                    clean = _re.sub(r'\.(docx?|pdf|xlsx?|png|jpg|jpeg)$', '', part, flags=_re.IGNORECASE)
                    if len(clean) > 10:
                        auto_supply['项目名称'] = clean
                        break
            if '项目名称' in auto_supply:
                break
    # 采购人名称（从 purchaser 参数或解析数据）
    if purchaser:
        auto_supply['招标人名称'] = purchaser
        auto_supply['采购人名称'] = purchaser

    if auto_supply:
        supplies.append(auto_supply)
        print(f'  [fill_plan] 自动 supply: {list(auto_supply.keys())}')

    def supply_get(*keys):
        for s in supplies:
            for k in keys:
                if k in s and s[k]:
                    return s[k]
        return None

    # ---- 第一遍：从 fill_positions 构建 text 类型的 item ----
    raw_items = []
    for fp in fill_positions:
        field_name = fp.get('field_name', '')
        fill_type = fp.get('fill_type', 'text')
        pattern = fp.get('pattern', '')
        para_idx = fp.get('para_idx', 0)
        hint_text = fp.get('hint_text', '')

        # 跳过 signature 类型
        if fill_type == 'signature' or fill_type == 'skip':
            continue

        # 确定 kind
        kind = 'text'
        if fill_type == 'image':
            kind = 'image'
        elif fill_type == 'table':
            kind = 'table'
        elif fill_type == 'date':
            kind = 'text'

        # 查 LABEL_RULES（v20.3.2: 支持别名查找）
        rule = LABEL_RULES.get(field_name, {})
        if not rule:
            # 尝试别名
            for alias in ['供应商名称', '投标人名称', '采购人名称', '招标人名称',
                          '法定代表人姓名', '法定代表人', '注册地址', '联系地址']:
                if field_name and alias in field_name:
                    rule = LABEL_RULES.get(alias, {})
                    break
        group = rule.get('group', 'simple')

        # 确定值
        val = None
        vs = ''
        if field_name == '开标日期' or '开标' in field_name:
            val = od
            vs = '固化:开标日期'
            group = 'date'
        elif group in ('legal', 'auth'):
            # legal/auth 组不从 text_content 取值（避免塞入整段文字）
            val = None
        else:
            # 从 matches 的 text_content 提取
            # 尝试用 field_name 匹配 req_id
            for rid, m in matches.items():
                if field_name and field_name in rid:
                    tc = m.get('text_content', '')
                    if tc and len(tc) < 200:
                        val = tc
                        break

        # 构造 item
        item = {
            'id': 'fp_%d' % para_idx,
            'kind': kind,
            'semantic_tag': field_name,
            'format': classify_format({'kind': kind, 'semantic_tag': field_name,
                                        'fill_source': vs, 'location': {}}, {}),
            'status': 'matched' if val else 'missing',
        }
        if kind == 'text':
            item['group'] = group
            item['value'] = val
            item['labels'] = list(rule.get('labels', []))
            item['inline_tokens'] = list(rule.get('inline_tokens', []))
            item['paren'] = list(rule.get('paren', []))
            # v20.3.2: 从 supply 补充关键字段（支持别名）
            if not val:
                sv = None
                if field_name in ('供应商名称', '投标人名称', '投标人', '公司名称', '系投标人名称(法定代表人句)'):
                    sv = supply_get('公司名称', '投标人名称', '单位名称')
                elif field_name == '项目名称':
                    sv = supply_get('项目名称', '项目全称')
                elif field_name == '项目编号':
                    sv = supply_get('项目编号')
                elif field_name in ('采购人名称', '招标人名称', '招标人', '采购人'):
                    sv = supply_get('招标人名称', '采购人名称')
                    if not sv and purchaser:
                        sv = purchaser
                elif field_name in ('法定代表人', '法定代表人姓名', '法人姓名', '姓名'):
                    sv = supply_get('法定代表人姓名', '法人姓名')
                elif field_name in ('注册地址', '联系地址', '地址', '地    址'):
                    sv = supply_get('注册地址', '联系地址', '地址')
                elif field_name in ('成立时间',):
                    sv = supply_get('成立时间')
                elif field_name in ('联系电话', '电话'):
                    sv = supply_get('联系电话', '电话')
                elif field_name in ('单位性质',):
                    sv = supply_get('单位性质', '公司类型', '类型')
                elif field_name in ('经营期限',):
                    sv = supply_get('经营期限') or '长期'
                if sv:
                    item['value'] = sv
                    item['status'] = 'matched'
        elif kind == 'image':
            item['person'] = _person_of(field_name)
            item['side'] = _side_of(field_name)
        elif kind == 'table':
            item['table_idx'] = None
            item['table_action'] = _table_action(field_name)
            item['mkb_tag'] = _mkb_tag_for(field_name)

        raw_items.append(item)

    # ---- 第二遍：从 matches（需求映射数据）补充 image/table 类型的 item ----
    existing_tags = {it.get('semantic_tag', '') for it in raw_items}
    for rid, m in matches.items():
        strategy = m.get('fill_strategy', '')
        status = m.get('status', 'missing')

        # 跳过已处理的 text 类型
        sem = _sem_from_req_id(rid)
        if sem in existing_tags and strategy != 'insert_images':
            continue

        if strategy == 'insert_images' and m.get('images'):
            # v20.3.3: 从源 docx 提取图片到临时目录
            source_path = m.get('source_path', '')
            extracted_images = {}
            if source_path and os.path.exists(source_path) and not _extracted_cache.get(source_path):
                try:
                    from extract_images import extract_images as _extract
                    extract_dir = os.path.join(here, '_extracted_imgs')
                    os.makedirs(extract_dir, exist_ok=True)
                    results = _extract(source_path, extract_dir, prefix='src')
                    if results and isinstance(results, dict):
                        for orig_name, ext_path in results.items():
                            extracted_images[orig_name] = ext_path
                    _extracted_cache[source_path] = extracted_images
                except Exception as e:
                    print(f'  [fill_plan] 图片提取失败: {e}')
            elif source_path:
                extracted_images = _extracted_cache.get(source_path, {})

            # 身份证图片
            person = _person_of(sem)
            side = _side_of(sem)
            if person:
                # 身份证：每人正反面各一个 item
                for img_name in m.get('images', [])[:2]:
                    # v20.3.3: 优先用提取后的路径
                    src = extracted_images.get(img_name)
                    if not src:
                        src = _resolve_image_from_source(m, img_name, here, media_base)
                    item = {
                        'id': rid + '_img',
                        'kind': 'image',
                        'semantic_tag': sem,
                        'format': 'cell_id' if _has_id_card_table(template) else 'id_pair',
                        'status': 'matched',
                        'person': person,
                        'side': side or '正面',
                        'src': src,
                    }
                    raw_items.append(item)
                    if side is None:
                        side = '反面'  # 第二张默认反面
            else:
                # 资质图片：由 add_qualification_images 处理
                pass
        elif strategy == 'copy_text' and m.get('text_content'):
            # 方案/声明类文本复制
            if sem not in existing_tags:
                item = {
                    'id': rid,
                    'kind': 'text',
                    'semantic_tag': sem,
                    'format': 'copied',
                    'status': 'matched',
                    'group': 'simple',
                    'value': m['text_content'][:500],
                    'labels': [], 'inline_tokens': [], 'paren': [],
                    'insert_after_heading': m.get('target_description', ''),
                }
                raw_items.append(item)
                existing_tags.add(sem)

    # ---- 第三遍：身份证正反面分组 ----
    id_items = [it for it in raw_items if it.get('kind') == 'image' and it.get('person')]
    by_person = {}
    for it in id_items:
        by_person.setdefault(it['person'], []).append(it)

    for person, items in by_person.items():
        sides = [it.get('side') for it in items]
        has_front = '正面' in sides
        has_back = '反面' in sides

        # 补反面
        if has_front and not has_back:
            sp_prefix = '法人' if person == '法定代表人' else person
            back_src = supply_get('%s身份证反面图' % sp_prefix)
            if back_src:
                items.append({
                    'id': '%s_id_back' % ('legal' if person == '法定代表人' else 'auth'),
                    'kind': 'image', 'semantic_tag': '%s身份证反面' % person,
                    'format': 'cell_id', 'status': 'matched',
                    'person': person, 'side': '反面', 'src': back_src,
                })

        cell_target = None
        for it in items:
            loc = it.get('target') or {}
            if loc.get('type') == 'table' and 'col' in loc:
                cell_target = loc
                break
        if cell_target:
            for it in items:
                it['format'] = 'cell_id'
                it['target'] = cell_target
        else:
            for it in items:
                it['format'] = 'id_pair'

    # ---- 构建 plan ----
    plan = {
        'project': mr.get('template') or sm.get('project', ''),
        'generated_by': 'Stage3 fill_plan builder (v20.3.2 方案A)',
        'open_date': od,
        'count': len(raw_items),
        'items': raw_items,
    }

    # 扩展：报价 xlsx
    if quote_xlsx and os.path.exists(quote_xlsx):
        plan['quote'] = build_quote(quote_xlsx)

    # 扩展：资质图片
    if qual_doc:
        image_out = image_out_dir or os.path.join(here, '_qual_imgs')
        add_qualification_images(plan, qual_doc, brochure_dir, image_out, here, template)

    # 扩展：营业执照字段
    if supplies:
        add_business_license_fields(plan, supplies[0], template)

    plan['count'] = len(plan['items'])
    if out_path:
        with open(out_path, 'w', encoding='utf-8') as f:
            json.dump(plan, f, ensure_ascii=False, indent=2)
    return plan


def _sem_from_req_id(rid):
    """从 req_id 推断 semantic_tag"""
    if 'identity' in rid:
        return '法定代表人身份证' if 'id_card' in rid else '法定代表人身份证明'
    if 'auth' in rid:
        return '被授权人身份证' if 'id_card' in rid else '法定代表人授权委托书'
    if 'personnel' in rid:
        return '拟投入人员'
    if 'qualification' in rid:
        for k, v in [('business_license', '营业执照'), ('finance', '财务状况报告'),
                      ('tax', '税收缴纳证明'), ('social', '社会保障资金缴纳证明'),
                      ('credit', '信用记录证明')]:
            if k in rid:
                return v
        return '资质证明文件'
    if 'performance' in rid or '业绩' in rid:
        return '业绩'
    if 'quotation' in rid or '报价' in rid:
        return '报价表'
    if 'proposal' in rid:
        return rid
    if 'commercial_deviation' in rid:
        return '商务条款偏离表'
    if 'technical_deviation' in rid:
        return '技术参数条款偏离表'
    return rid


def _resolve_image_from_source(m, img_name, here, media_base):
    """从源 docx 的图片名解析出可用路径"""
    source_path = m.get('source_path', '')
    if not source_path or not os.path.exists(source_path):
        return resolve_image_path(img_name, media_base, here)
    # 图片在源 docx 内部，需要 extract_images 提取
    # 这里返回 source_path + img_name，由消费端处理
    return os.path.join(os.path.dirname(source_path), img_name) if img_name else None


def _has_id_card_table(template_path):
    """检查模板中是否有身份证表格（用于决定 cell_id vs id_pair）"""
    if not template_path or not os.path.exists(template_path):
        return True  # 默认有
    try:
        from docx import Document
        doc = Document(template_path)
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if '身份证' in cell.text or '复印件' in cell.text:
                        return True
        return False
    except Exception:
        return True


if __name__ == '__main__':
    import argparse
    from collections import Counter
    ap = argparse.ArgumentParser(description='构建 FILL Plan')
    ap.add_argument('--slot', required=True, help='扫描数据 JSON')
    ap.add_argument('--match', required=True, help='需求映射数据 JSON')
    ap.add_argument('--out', default=None)
    ap.add_argument('--media', default=None)
    ap.add_argument('--supply', action='append', default=[])
    ap.add_argument('--open-date', default=None)
    ap.add_argument('--quote', default=None, help='报价 xlsx')
    ap.add_argument('--qual-doc', default=None, help='资格证明 docx')
    ap.add_argument('--brochure-dir', default=None, help='产品彩页目录')
    ap.add_argument('--bl-supply', default=None, help='营业执照 OCR supply')
    ap.add_argument('--image-out', default=None, help='抽取图片输出目录')
    ap.add_argument('--template', default=None, help='框架模板 docx')
    ap.add_argument('--purchaser', default=None, help='采购人名称')
    a = ap.parse_args()
    plan = build_fill_plan(a.slot, a.match, a.out, template=a.template,
                           media_base=a.media, supply_paths=a.supply, open_date=a.open_date,
                           quote_xlsx=a.quote, qual_doc=a.qual_doc,
                           brochure_dir=a.brochure_dir, bl_supply=a.bl_supply,
                           image_out_dir=a.image_out, purchaser=a.purchaser)
    print('FILL Plan 生成: %s (%d 条)' % (a.out, plan['count']))
    print('format 分布:', dict(Counter(i['format'] for i in plan['items'])))
    print('group 分布 :', dict(Counter(i.get('group', i['kind']) for i in plan['items'])))
    if 'quote' in plan:
        print('报价: 合计', plan['quote']['total_text'], '大写', plan['quote']['capital'],
              '分项行', len(plan['quote']['items']))
