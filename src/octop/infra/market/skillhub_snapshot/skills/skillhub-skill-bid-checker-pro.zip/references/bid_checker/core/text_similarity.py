#!/usr/bin/env python3
"""
文本相似度工具

功能：
  1. N-gram 指纹生成
  2. Jaccard 相似度计算
  3. SimHash 相似度计算（备选）
  4. 段落级相似度比对

用途：
  - 跨章节自重复检测（标书内段落两两比对）
  - 与公开资料相似度（标书段落 vs 网页内容）
"""
import re
from dataclasses import dataclass
from typing import List, Set, Tuple
from collections import Counter


@dataclass
class Paragraph:
    """一个段落"""
    text: str
    location: str  # 位置描述，如"第8章第3段"
    page_ref: str = ''
    fingerprint: Set[str] = None  # N-gram 集合


def normalize_text(text: str) -> str:
    """文本归一化：移除空白、标点、统一大小写"""
    if not text:
        return ''
    # 移除所有空白
    text = re.sub(r'\s+', '', text)
    # 移除常见标点
    text = re.sub(r'[，。；：！？""''（）《》、,.:;!?()\[\]{}「」【】]', '', text)
    return text.lower()


def generate_ngrams(text: str, n: int = 4) -> Set[str]:
    """生成 N-gram 集合"""
    normalized = normalize_text(text)
    if len(normalized) < n:
        return {normalized} if normalized else set()
    return {normalized[i:i+n] for i in range(len(normalized) - n + 1)}


def jaccard_similarity(set1: Set[str], set2: Set[str]) -> float:
    """Jaccard 相似度：|A∩B| / |A∪B|"""
    if not set1 or not set2:
        return 0.0
    intersection = set1 & set2
    union = set1 | set2
    return len(intersection) / len(union)


def text_similarity(text1: str, text2: str, n: int = 4) -> float:
    """两段文本的相似度（0-1）"""
    fp1 = generate_ngrams(text1, n)
    fp2 = generate_ngrams(text2, n)
    return jaccard_similarity(fp1, fp2)


def split_into_paragraphs(text: str, min_length: int = 100, max_length: int = 500,
                          location_prefix: str = '') -> List[Paragraph]:
    """
    把长文本切分为段落（用于相似度比对）
    
    策略：
      - 按换行符初切
      - 短段落合并到下一段（直到达到 min_length）
      - 长段落按句号切分（直到不超过 max_length）
    
    :param text: 输入文本
    :param min_length: 段落最小长度（短于此合并）
    :param max_length: 段落最大长度（长于此切分）
    :param location_prefix: 位置前缀（如"第8章"）
    """
    if not text:
        return []
    
    # 按换行符初切
    raw_paragraphs = [p.strip() for p in text.split('\n') if p.strip()]
    
    # 合并短段落
    merged = []
    current = ''
    for p in raw_paragraphs:
        if len(current) + len(p) < min_length:
            current = (current + p).strip()
        else:
            if current:
                merged.append(current)
            current = p
    if current:
        merged.append(current)
    
    # 切分长段落
    paragraphs = []
    for p in merged:
        if len(p) <= max_length:
            paragraphs.append(p)
        else:
            # 按句号切分
            sentences = re.split(r'(?<=[。；！？])', p)
            current = ''
            for s in sentences:
                if not s:
                    continue
                if len(current) + len(s) > max_length and current:
                    paragraphs.append(current)
                    current = s
                else:
                    current += s
            if current:
                paragraphs.append(current)
    
    # 生成 Paragraph 对象
    result = []
    for i, p in enumerate(paragraphs):
        result.append(Paragraph(
            text=p,
            location=f'{location_prefix}第{i+1}段' if location_prefix else f'第{i+1}段',
            fingerprint=generate_ngrams(p),
        ))
    
    return result


def find_similar_paragraph_pairs(paragraphs: List[Paragraph],
                                  threshold: float = 0.6,
                                  skip_adjacent: bool = True) -> List[Tuple[Paragraph, Paragraph, float]]:
    """
    找出所有相似段落对
    
    :param paragraphs: 段落列表
    :param threshold: 相似度阈值（默认 0.6）
    :param skip_adjacent: 是否跳过相邻段落（相邻段落通常自然相似）
    :return: [(p1, p2, similarity), ...]
    """
    similar_pairs = []
    
    for i, p1 in enumerate(paragraphs):
        for j, p2 in enumerate(paragraphs[i+1:], i+1):
            # 跳过相邻段落
            if skip_adjacent and j == i + 1:
                continue
            
            # 跳过指纹为空的
            if not p1.fingerprint or not p2.fingerprint:
                continue
            
            sim = jaccard_similarity(p1.fingerprint, p2.fingerprint)
            if sim >= threshold:
                similar_pairs.append((p1, p2, sim))
    
    # 按相似度降序排序
    similar_pairs.sort(key=lambda x: -x[2])
    return similar_pairs


def find_most_similar_external(paragraph: Paragraph,
                                external_texts: List[str],
                                threshold: float = 0.7) -> List[Tuple[int, float]]:
    """
    找出段落与外部文本列表中最相似的
    
    :param paragraph: 待比对的段落
    :param external_texts: 外部文本列表（如搜索结果）
    :param threshold: 相似度阈值
    :return: [(external_index, similarity), ...] 按相似度降序
    """
    if not paragraph.fingerprint:
        return []
    
    matches = []
    for i, ext_text in enumerate(external_texts):
        ext_fp = generate_ngrams(ext_text)
        if not ext_fp:
            continue
        sim = jaccard_similarity(paragraph.fingerprint, ext_fp)
        if sim >= threshold:
            matches.append((i, sim))
    
    matches.sort(key=lambda x: -x[1])
    return matches


def extract_key_sentence(text: str, max_length: int = 80) -> str:
    """
    从段落中抽取关键句（用于搜索引擎查询）
    
    策略：取段落的中间一句（避免开头套话和结尾总结）
    """
    if not text:
        return ''
    
    # 按句号切分
    sentences = re.split(r'(?<=[。；！？])', text)
    sentences = [s.strip() for s in sentences if s.strip() and len(s.strip()) > 15]
    
    if not sentences:
        # 没有完整句子，取前 max_length 字
        return text[:max_length]
    
    # 取中间一句
    mid_idx = len(sentences) // 2
    key = sentences[mid_idx]
    
    # 限制长度
    if len(key) > max_length:
        key = key[:max_length]
    
    return key


if __name__ == '__main__':
    # 自检
    print('=== 相似度计算测试 ===')
    t1 = '本方案采用微服务架构，将系统拆分为多个独立服务'
    t2 = '本方案采用微服务架构，将系统拆分为多个独立服务模块'
    t3 = '本系统使用单体架构，所有功能模块集中部署'
    
    print(f'  t1 vs t2 (高度相似): {text_similarity(t1, t2):.2%}')
    print(f'  t1 vs t3 (不同): {text_similarity(t1, t3):.2%}')
    
    print('\n=== 段落切分测试 ===')
    text = '''
    本方案采用微服务架构。将系统拆分为多个独立服务。每个服务负责特定业务功能。
    
    本系统使用单体架构。所有功能模块集中部署。便于维护和管理。
    
    本方案采用微服务架构。将系统拆分为多个独立服务。每个服务负责特定业务功能。
    '''
    paragraphs = split_into_paragraphs(text, min_length=20, max_length=200, location_prefix='测试章节')
    print(f'  切分出 {len(paragraphs)} 段')
    for p in paragraphs:
        print(f'    [{p.location}] {p.text[:50]}...')
    
    print('\n=== 相似段落对检测 ===')
    pairs = find_similar_paragraph_pairs(paragraphs, threshold=0.5, skip_adjacent=False)
    print(f'  找到 {len(pairs)} 对相似段落')
    for p1, p2, sim in pairs:
        print(f'    {sim:.2%}: {p1.location} vs {p2.location}')
