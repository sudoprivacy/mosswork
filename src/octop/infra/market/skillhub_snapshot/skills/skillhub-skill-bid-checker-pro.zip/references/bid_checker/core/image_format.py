# -*- coding: utf-8 -*-
"""
image_format.py — 投标文件图片插入「格式原语 / 自检」通用模块
=====================================================================

为什么需要它（用户提出的固化规则，已抽象为机械原语，不再依赖 AI 临场判断）：

  RULE-IMG-1  所有插入的图片（除身份证外）一律「占位一整页」：
              - 尺寸 = A4 可用区域「contain 适配」（长或宽其中之一顶到最大值，
                不拉伸、不变形）；A4 是竖版，横图也按竖版页面放（不旋转）。
              - 图片所在段落 page_break_before=True，且独占一页（后面强制分页）。
              - 适用：营业执照、检测报告、彩页、厂家授权书、资质证书等非身份证图。

  RULE-IMG-2  身份证分两类：
              - 有单元格的（法定代表人身份证明表、授权委托书表中的身份证格）：
                按「单元格大小」contain 插入（不拉伸）。
              - 没有单元格的身份证插入处：正、反两面「左右并排横放」共占用「一页」
                （同一段落内左正面、右反面，各 contain 到半页宽，不拉伸）。

设计哲学（与 format_guardrails.py 一致）：
  「格式手感」= 把图片该用什么尺寸/占几页这种反复出错的点，抽象成「原语 + 不变量」。
  AI 只需要决定「这张图属于哪一类（full_page / cell_id / id_pair）」，
  具体的 OOXML 尺寸/分页计算全部由本模块确定性完成。AI 不写尺寸代码。

对外接口：
  insert_full_page_image(doc, target, path)   # RULE-IMG-1
  insert_cell_image(doc, cell, path)          # RULE-IMG-2（单元格类）
  insert_id_pair_page(doc, front, back, before=None)  # RULE-IMG-2（无单元格类）
  verify_image_sizing(doc)                    # 护栏不变量：校验所有图片尺寸/分页合规
"""

import os
import io
from docx.shared import Inches, Emu, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from PIL import Image

EMU_PER_IN = 914400


# --------------------------------------------------------------------------
# 工具：读取模板真实页边距下的「可用区域」
# --------------------------------------------------------------------------
def get_usable_area(section):
    """返回 (可用宽 inch, 可用高 inch)，按该 section 真实页边距算（不写死 1in）。"""
    pgw = section.page_width or Emu(int(8.2677 * EMU_PER_IN))
    pgh = section.page_height or Emu(int(11.6929 * EMU_PER_IN))
    lm = section.left_margin or Emu(int(1 * EMU_PER_IN))
    rm = section.right_margin or Emu(int(1 * EMU_PER_IN))
    tm = section.top_margin or Emu(int(1 * EMU_PER_IN))
    bm = section.bottom_margin or Emu(int(1 * EMU_PER_IN))
    uw = (pgw - lm - rm) / EMU_PER_IN
    uh = (pgh - tm - bm) / EMU_PER_IN
    return uw, uh


def _img_px(path):
    with Image.open(path) as im:
        return im.size  # (w, h) 像素


def compute_contain(path, max_w_in, max_h_in):
    """contain 适配：保持原始宽高比，使图片完整落在 (max_w, max_h) 框内，
    且长或宽其中之一顶到最大值（不拉伸、不变形）。返回 (w_in, h_in)。"""
    iw, ih = _img_px(path)
    return compute_contain_dims(iw, ih, max_w_in, max_h_in)


def compute_contain_dims(iw, ih, max_w_in, max_h_in):
    """compute_contain 的尺寸计算版（直接传像素尺寸，避免重复读文件）。"""
    if iw <= 0 or ih <= 0:
        return max_w_in, max_h_in
    ar = iw / ih
    if max_w_in / max_h_in > ar:
        # 高度受限：高顶满，宽按比例
        h = max_h_in
        w = h * ar
    else:
        # 宽度受限：宽顶满，高按比例
        w = max_w_in
        h = w / ar
    return round(w, 3), round(h, 3)


def _first_para_of(target):
    """target 可能是 Paragraph 或 Cell，返回其首个 Paragraph。"""
    if hasattr(target, 'paragraphs'):
        if not target.paragraphs:
            target.add_paragraph()
        return target.paragraphs[0]
    return target


# --------------------------------------------------------------------------
# RULE-IMG-1：整页图片（除身份证外）
# --------------------------------------------------------------------------
def insert_full_page_image(doc, target, path, allow_rotate=True, first_in_section=False):
    """把图片以 contain 适配放入 A4 可用区域，居中。
    target: 承载图片的 Paragraph（或 Cell，取首段）。
    allow_rotate: 横图（宽/高 > 1.2）顺时针旋转 90° 再 contain，确保「竖着放」填满 A4。
    first_in_section: v20.3.2 如果是某小标题下的第一张图片，缩小尺寸跟标题同页（不分页）。"""
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    section = doc.sections[0]
    uw, uh = get_usable_area(section)

    para = _first_para_of(target)
    para.text = ''
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER

    iw, ih = _img_px(path)

    if first_in_section:
        # v20.3.3: 小标题下第一张图片——宽度全宽，高度取可用高度的 65%
        # 这样不管标题几行（1~4行）都不会超页，且图片尽可能大
        small_w, small_h = uw, uh * 0.65
        if allow_rotate and iw > 0 and ih > 0 and (iw / float(ih)) > 1.2:
            with Image.open(path) as im:
                im2 = im.rotate(-90, expand=True)
                buf = io.BytesIO()
                im2.save(buf, format='PNG')
                buf.seek(0)
                w, h = compute_contain_dims(ih, iw, small_w, small_h)
                para.add_run().add_picture(buf, width=Inches(w), height=Inches(h))
        else:
            w, h = compute_contain_dims(iw, ih, small_w, small_h) if iw > 0 else compute_contain(path, small_w, small_h)
            para.add_run().add_picture(path, width=Inches(w), height=Inches(h))
        pf = para.paragraph_format
        # 不加分页符——跟标题同页
    else:
        # 原逻辑：整页 contain + 分页
        if allow_rotate and iw > 0 and ih > 0 and (iw / float(ih)) > 1.2:
            with Image.open(path) as im:
                im2 = im.rotate(-90, expand=True)
                buf = io.BytesIO()
                im2.save(buf, format='PNG')
                buf.seek(0)
                w, h = compute_contain_dims(ih, iw, uw, uh)
                para.add_run().add_picture(buf, width=Inches(w), height=Inches(h))
        else:
            w, h = compute_contain(path, uw, uh)
            para.add_run().add_picture(path, width=Inches(w), height=Inches(h))
        pf = para.paragraph_format
        pf.page_break_before = True
        pf.page_break_after = True          # 独占一页，后面内容另起一页
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    return para


# --------------------------------------------------------------------------
# RULE-IMG-2a：单元格内身份证（按单元格大小）
# --------------------------------------------------------------------------
def insert_cell_image(doc, cell, path, max_w_in=None, max_h_in=None, append=False):
    """身份证按单元格大小 contain 插入（不拉伸）。
    若单元格有显式宽度则以此为准；否则回退到默认身份证尺寸。
    append=True 时不清空单元格已有内容，而是在末尾追加一个段落（用于正+反面叠放）。"""
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    section = doc.sections[0]
    uw, uh = get_usable_area(section)

    # 单元格可用宽度：优先单元格设定宽度，否则默认身份证宽
    cell_w_emu = None
    try:
        if cell.width is not None:
            cell_w_emu = int(cell.width)
    except Exception:
        cell_w_emu = None

    if max_w_in is None:
        if cell_w_emu:
            # 单元格内边距留 0.1in
            max_w_in = max(0.5, (cell_w_emu / EMU_PER_IN) - 0.1)
        else:
            max_w_in = 2.2
    if max_h_in is None:
        # 身份证高度不超过半页，避免撑爆行
        max_h_in = min(uh * 0.45, 2.2 / 0.58)  # 0.58≈身份证宽高比下限保护

    w, h = compute_contain(path, max_w_in, max_h_in)

    if append and cell.paragraphs and cell.paragraphs[0].runs:
        para = cell.add_paragraph()
    else:
        para = _first_para_of(cell)
        para.text = ''
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    para.add_run().add_picture(path, width=Inches(w), height=Inches(h))
    return para


# --------------------------------------------------------------------------
# RULE-IMG-2b：无单元格的身份证（正反面左右并排横放，共占一页）
# --------------------------------------------------------------------------
def insert_id_pair_page(doc, front, back, before=None):
    """法人/被授权人身份证正、反两面「左右并排横放」共占一页：同一段落内
    左正面、右反面，各 contain 到半页宽（不拉伸）。before=None 时追加到文档末尾。"""
    if not os.path.exists(front) or not os.path.exists(back):
        raise FileNotFoundError('front/back 身份证图缺失')
    section = doc.sections[0]
    uw, uh = get_usable_area(section)
    half_w = uw / 2.0 - 0.1

    w1, h1 = compute_contain(front, half_w, uh)
    w2, h2 = compute_contain(back, half_w, uh)

    if before is not None:
        p = before.insert_paragraph_before()
    else:
        p = doc.add_paragraph()
    p.text = ''
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(front, width=Inches(w1), height=Inches(h1))
    p.add_run().add_picture(back, width=Inches(w2), height=Inches(h2))
    pf = p.paragraph_format
    pf.page_break_before = True
    pf.page_break_after = True
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    return p


# --------------------------------------------------------------------------
# 护栏不变量：校验所有图片尺寸 / 分页合规
# --------------------------------------------------------------------------
def _iter_inline_images(doc):
    """遍历文档所有内联图片，产出 (paragraph, run, cx_emu, cy_emu, in_cell)。"""
    ns = {'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
          'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    # 顶层段落
    for p in doc.paragraphs:
        for r in p.runs:
            exts = r._r.xpath('.//wp:extent')
            if exts:
                ext = exts[0]
                yield (p, r, int(ext.get('cx')), int(ext.get('cy')), False)
    # 表格单元格
    for tbl in doc.tables:
        for row in tbl.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for r in p.runs:
                        exts = r._r.xpath('.//wp:extent')
                        if exts:
                            ext = exts[0]
                            yield (p, r, int(ext.get('cx')), int(ext.get('cy')), True)


def verify_image_sizing(doc, tol_in=0.05):
    """不变量：检查图片是否越界 / 分页是否合规。返回 {warnings:[], stats:{}}。"""
    section = doc.sections[0]
    uw, uh = get_usable_area(section)
    uw_emu = uw * EMU_PER_IN
    uh_emu = uh * EMU_PER_IN
    tol = tol_in * EMU_PER_IN

    warnings = []
    stats = {'total': 0, 'full_page': 0, 'cell': 0, 'overflow': 0}

    # 收集顶层图片段落（用于分页分组判定），同时做越界/单元格检查
    for p, r, cx, cy, in_cell in _iter_inline_images(doc):
        stats['total'] += 1
        if in_cell:
            stats['cell'] += 1
            # 单元格图片越界检查（仅当单元格宽度「可靠」时才比对）
            cell = None
            node = r._r
            while node is not None:
                if node.tag == qn('w:tc'):
                    cell = node
                    break
                node = node.getparent()
            if cell is not None:
                tcPr = cell.find(qn('w:tcPr'))
                if tcPr is not None:
                    tcW = tcPr.find(qn('w:tcW'))
                    if tcW is not None and tcW.get(qn('w:w')):
                        wtype = tcW.get(qn('w:type'))
                        try:
                            cw = int(tcW.get(qn('w:w')))
                        except ValueError:
                            cw = None
                        # 不可靠宽度（非 dxa 或极小默认宽）跳过，避免误报
                        reliable = (wtype in (None, 'dxa')) and cw is not None and cw >= 0.5 * EMU_PER_IN
                        if reliable and cx > cw + tol:
                            warnings.append('单元格图片超出单元格宽度：cx=%.2fin > 单元格 %.2fin' % (
                                cx/EMU_PER_IN, cw/EMU_PER_IN))
        else:
            stats['full_page'] += 1
            if cx > uw_emu + tol or cy > uh_emu + tol:
                stats['overflow'] += 1
                warnings.append('整页图片超出 A4 可用区域：%.2f x %.2f in（可用 %.2f x %.2f）' % (
                    cx/EMU_PER_IN, cy/EMU_PER_IN, uw, uh))

    # 分页分组：就地遍历段落，直接判断每段是否含「顶层」图片（不在单元格内），
    # 不再用 id(p) 跨两次 doc.paragraphs 迭代匹配（python-docx 每次返回新包装对象，
    # id 不匹配会导致误报 / 漏报）。组内仅首段要求 page_break_before；
    # 非首段（前一段也是图片）共享该页，OK。
    def _is_top_image_para(p):
        if not p._p.xpath('.//wp:extent'):
            return False
        parent = p._p.getparent()
        return parent is None or parent.tag != qn('w:tc')

    prev_was_top_img = False
    for p in doc.paragraphs:
        is_top = _is_top_image_para(p)
        if is_top:
            if not p.paragraph_format.page_break_before and not prev_was_top_img:
                warnings.append('整页图片所在段落未设 page_break_before（且前一段非图片，可能未独占一页）')
            prev_was_top_img = True
        else:
            prev_was_top_img = False

    return {'warnings': warnings, 'stats': stats}
