# -*- coding: utf-8 -*-
"""
extract_images.py — 从 docx 抽取内嵌图片（通用工具，与具体项目解耦）
=========================================================================

把投标文件资料 docx（如「资格证明材料.docx」、厂家「产品彩页」docx）
里的图片按**文档顺序**抽取成独立图片文件，供 Stage 4 消费端作为 full_page 图片项插入。

两种 caption 模式：
  - 'preceding'：取该图片**最近的上一段落非空文本**作 caption（资格证明类，图前有标题）。
  - 'filename' ：用来源 docx 的文件名（去扩展名）作 caption（彩页类，图即整页内容）。

去重：同一 docx 内同一媒体文件（按 media 文件名）只抽一次。
文件名使用全局递增序号，避免多段落图片时发生覆盖（旧版本用段落索引做文件名导致覆盖）。

对外接口：
  extract_images(docx_path, out_dir, prefix, caption_mode='filename') -> [{'path','caption'}, ...]
"""
import os
import re
import zipfile

from docx import Document
from docx.oxml.ns import qn


def _rels_map(docx_path):
    """返回 {rId: media 相对路径}。"""
    z = zipfile.ZipFile(docx_path)
    rels = {}
    try:
        data = z.read('word/_rels/document.xml.rels').decode('utf-8', 'ignore')
    except KeyError:
        return rels
    for m in re.finditer(r'Id="([^"]+)"[^>]*Target="([^"]+)"', data):
        rels[m.group(1)] = m.group(2)
    return rels


def _media_path(target):
    if not target:
        return None
    if target.startswith('word/'):
        return target
    return 'word/' + target.lstrip('/')


def extract_images(docx_path, out_dir, prefix, caption_mode='filename'):
    """抽取 docx 内图片（文档顺序、去重），返回 [{'path','caption'}]。"""
    os.makedirs(out_dir, exist_ok=True)
    z = zipfile.ZipFile(docx_path)
    rels = _rels_map(docx_path)
    doc = Document(docx_path)
    seen = set()
    out = []
    seq = 0  # 全局递增序号，避免多段落图片覆盖

    for p_idx, p in enumerate(doc.paragraphs):
        drawings = p._p.findall('.//' + qn('w:drawing'))
        if not drawings:
            continue
        cap = ''
        if caption_mode == 'preceding':
            for j in range(p_idx - 1, -1, -1):
                tt = doc.paragraphs[j].text.strip()
                if tt:
                    cap = tt
                    break
        elif caption_mode == 'filename':
            cap = os.path.splitext(os.path.basename(docx_path))[0]
        for d in drawings:
            blip = d.find('.//' + qn('a:blip'))
            if blip is None:
                continue
            rid = blip.get(qn('r:embed'))
            target = rels.get(rid)
            if not target:
                continue
            media = _media_path(target)
            name = os.path.basename(media)
            if name in seen:
                continue
            seen.add(name)
            try:
                data = z.read(media)
            except KeyError:
                continue
            ext = os.path.splitext(name)[1] or '.png'
            op = os.path.join(out_dir, '%s_%04d%s' % (prefix, seq, ext))
            with open(op, 'wb') as f:
                f.write(data)
            out.append({'path': op, 'caption': cap})
            seq += 1
    return out


def extract_dir_images(dir_path, out_dir, prefix, caption_mode='filename'):
    """批量抽取一个目录下所有 docx 的图片，prefix 自动按文件名区分。返回合并列表。"""
    results = []
    for f in sorted(os.listdir(dir_path)):
        if not f.lower().endswith('.docx'):
            continue
        fp = os.path.join(dir_path, f)
        sub = os.path.splitext(f)[0]
        items = extract_images(fp, out_dir, '%s_%s' % (prefix, sub[:20]), caption_mode)
        results.extend(items)
    return results


if __name__ == '__main__':
    import sys
    if len(sys.argv) >= 3:
        items = extract_images(sys.argv[1], sys.argv[2], 'img',
                                sys.argv[3] if len(sys.argv) > 3 else 'filename')
        for it in items:
            print(it['caption'], '->', it['path'])
        print('total:', len(items))
