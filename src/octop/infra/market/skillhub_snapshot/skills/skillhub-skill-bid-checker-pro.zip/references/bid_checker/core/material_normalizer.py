#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
资料文件命名规范化预处理 (v20.3)
================================

Stage 3-0 预处理：把用户原始资料文件夹（命名千奇百怪）规范化为标准命名的资料文件夹。

解决痛点：
  - "BL.jpg" / "执照.jpg" → 营业执照.jpg
  - "证件1.png" → 法人身份证正面.jpg（需 OCR 确认）
  - "1.jpg" → 通过 OCR 内容识别
  - "财务/2024审计.pdf" → 财务审计报告.pdf

三级匹配策略（按优先级）：
  规则 A: 文件名关键词匹配（最快，置信度 90%）
  规则 B: OCR 内容匹配（图片文字识别，置信度 70-85%）
  规则 C: 目录上下文匹配（文件所在目录推断，置信度 60-75%）

输出：
  - standardized/ 子目录：规范化命名的文件（软链接/副本）
  - rename_report.md：原名 → 新名映射 + 置信度 + 匹配规则

用法：
    from bid_checker.core.material_normalizer import MaterialNormalizer
    normalizer = MaterialNormalizer()
    report = normalizer.normalize("/path/to/资料文件夹", "/path/to/standardized")

    # CLI
    python -m bid_checker.core.material_normalizer --input 资料文件夹 --output standardized
"""

import os
import sys
import re
import shutil
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.material_normalizer")
except ImportError:
    import logging
    _logger = logging.getLogger("material_normalizer")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)


# ============================================================
# 标准资料类型定义 + 关键词映射表
# ============================================================

# 标准资料类型 → 关键词列表（用于规则 A：文件名匹配）
# 顺序很重要：长的关键词优先匹配（避免"营业执照"被"执照"先匹配）
STANDARD_MATERIAL_TYPES = {
    # === 证件类（最高优先级）===
    '法人身份证正面': {
        'keywords': ['法人身份证正面', '法人证件正面', '法人身份证明正面',
                     '身份证正面', '身份证人像面', '身份证人像'],
        'context_dirs': ['法人证件', '03_法人证件', '法人', '法定代表人'],
    },
    '法人身份证反面': {
        'keywords': ['法人身份证反面', '法人证件反面', '法人身份证明反面',
                     '身份证反面', '身份证国徽面', '身份证国徽'],
        'context_dirs': ['法人证件', '03_法人证件', '法人', '法定代表人'],
    },
    '被授权人身份证正面': {
        'keywords': ['被授权人身份证正面', '被授权人证件正面', '授权人身份证正面',
                     '被授权人正面', '授权代表身份证正面'],
        'context_dirs': ['04_授权委托人证件', '被授权人', '授权人', '授权代表'],
    },
    '被授权人身份证反面': {
        'keywords': ['被授权人身份证反面', '被授权人证件反面', '授权人身份证反面',
                     '被授权人反面', '授权代表身份证反面'],
        'context_dirs': ['04_授权委托人证件', '被授权人', '授权人', '授权代表'],
    },

    # === 证照类 ===
    '营业执照': {
        'keywords': ['营业执照', '执照', 'BL', 'bl', 'business_license',
                     '营业执照副本', '执照副本'],
        'context_dirs': ['01_营业执照', '营业执照', '证照'],
    },

    # === 财务类 ===
    '财务审计报告': {
        'keywords': ['审计', '财务审计', '财报', '财务报告', '财务状况',
                     'audit', 'financial'],
        'context_dirs': ['02_财务报表', '财务', '审计'],
    },
    '税收缴纳证明': {
        'keywords': ['纳税', '完税', '税收', '税收缴纳', 'tax'],
        'context_dirs': ['05_完税社保证明', '税收', '纳税'],
    },
    '社保证明': {
        'keywords': ['社保', '社会保障', '社会保险', 'social_security', 'social'],
        'context_dirs': ['05_完税社保证明', '社保'],
    },
    '信用查询': {
        'keywords': ['信用', '失信', '信用中国', '信用报告', '信用记录',
                     'credit'],
        'context_dirs': ['06_信用记录', '信用'],
    },

    # === 授权类 ===
    '授权委托书': {
        'keywords': ['授权', '委托书', '授权委托', 'authorization'],
        'context_dirs': ['04_授权委托人证件', '授权', '委托'],
    },

    # === 业绩类 ===
    '业绩合同': {
        'keywords': ['业绩', '合同', '中标', 'project', 'contract'],
        'context_dirs': ['07_业绩合同', '业绩', '合同'],
    },

    # === 资质类 ===
    '资质证书': {
        'keywords': ['资质', 'ISO', '认证', '证书', 'qualification'],
        'context_dirs': ['08_资质证书', '资质', '证书'],
    },
    '检测报告': {
        'keywords': ['检测报告', '检测', '测试报告', 'test_report'],
        'context_dirs': ['检测', '报告'],
    },
    '厂家授权书': {
        'keywords': ['厂家授权', '厂商授权', '代理授权', 'manufacturer'],
        'context_dirs': ['厂家授权', '授权'],
    },

    # === 其他 ===
    '产品彩页': {
        'keywords': ['彩页', '产品介绍', '产品手册', 'brochure'],
        'context_dirs': ['产品彩页', '彩页'],
    },
    '人员汇总表': {
        'keywords': ['人员', '人员表', '人员汇总', '团队', 'staff'],
        'context_dirs': ['09_项目人员', '人员', '团队'],
    },
    '报价表': {
        'keywords': ['报价', '报价表', '报价单', 'quotation', 'quote'],
        'context_dirs': ['10_报价文件', '报价'],
    },
}


# OCR 内容匹配的关键词（规则 B）
# 当文件名无法识别时，对图片做 OCR，根据文字内容判断类型
OCR_CONTENT_KEYWORDS = {
    '营业执照': ['营业执照', '统一社会信用代码', '营业执照副本', '营业执照正本',
                  '类型', '注册资本', '成立日期', '法定代表人'],
    '法人身份证正面': ['姓名', '性别', '民族', '出生', '住址', '公民身份号码'],
    '法人身份证反面': ['签发机关', '有效期', '中华人民共和国'],
    '财务审计报告': ['审计报告', '资产负债表', '利润表', '现金流量表',
                     '注册会计师', '审计意见'],
    '税收缴纳证明': ['税收', '完税', '纳税', '税收完税证明'],
    '社保证明': ['社会保险', '社会保障', '社保', '参保', '缴费'],
    '信用查询': ['信用中国', '失信被执行人', '信用信息', '信用记录',
                 '重大税收违法'],
    '授权委托书': ['授权', '委托', '授权人', '被授权人', '代理人'],
    '业绩合同': ['合同', '项目', '采购', '供货', '建设', '中标',
                 '甲方', '乙方', '合同金额'],
    '检测报告': ['检测', '测试', '检验', '报告', 'CMA', 'CNAS'],
    '厂家授权书': ['授权', '代理', '经销商', '厂家', '厂商'],
}

# 目录上下文匹配（规则 C）
# 文件所在目录名 → 推断资料类型
DIRECTORY_CONTEXT = {
    '01_营业执照': '营业执照',
    '02_财务报表': '财务审计报告',
    '03_法人证件': '法人身份证正面',  # 默认推断为正面（需 OCR 区分正反）
    '04_授权委托人证件': '被授权人身份证正面',
    '05_完税社保证明': '税收缴纳证明',  # 可能是税收或社保，需 OCR 区分
    '06_信用记录': '信用查询',
    '07_业绩合同': '业绩合同',
    '08_资质证书': '资质证书',
    '09_项目人员': '人员汇总表',
    '10_报价文件': '报价表',
    '11_技术参数响应': '检测报告',
    '12_其他资料': None,  # 不确定
    # 通用目录名
    '营业执照': '营业执照',
    '财务': '财务审计报告',
    '审计': '财务审计报告',
    '社保': '社保证明',
    '纳税': '税收缴纳证明',
    '完税': '税收缴纳证明',
    '信用': '信用查询',
    '授权': '授权委托书',
    '业绩': '业绩合同',
    '合同': '业绩合同',
    '资质': '资质证书',
    '证书': '资质证书',
    '人员': '人员汇总表',
    '团队': '人员汇总表',
    '报价': '报价表',
}


# ============================================================
# MaterialNormalizer 主类
# ============================================================

class MaterialNormalizer:
    """资料文件命名规范化预处理引擎"""

    def __init__(self, use_ocr: bool = True, ocr_timeout: int = 15):
        """
        Args:
            use_ocr: 是否启用 OCR（规则 B）。使用本地 RapidOCR 引擎（基于 ONNX Runtime，无需 API 密钥）
            ocr_timeout: 单张图片 OCR 超时秒数
        """
        self.use_ocr = use_ocr
        self.ocr_timeout = ocr_timeout
        self._ocr_engine = None

    def _get_ocr_engine(self):
        """惰性初始化 OCR 引擎"""
        if self._ocr_engine is not None:
            return self._ocr_engine
        if not self.use_ocr:
            return None
        try:
            # 优先用 ocr_engine.py 的双引擎
            import sys as _sys
            _sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
            from ocr_engine import create_ocr_engine
            self._ocr_engine = create_ocr_engine(verbose=False)
            if self._ocr_engine:
                _logger.info(f"OCR 引擎就绪: {self._ocr_engine.backend_name}")
            else:
                _logger.warning("OCR 引擎不可用，规则 B（OCR 内容匹配）将跳过")
        except Exception as e:
            _logger.warning(f"OCR 引擎初始化失败: {e}")
            self._ocr_engine = None
        return self._ocr_engine

    # ----------------------------------------------------------
    # 主入口
    # ----------------------------------------------------------

    def normalize(self, materials_dir: str, output_dir: str,
                  use_symlink: bool = True) -> Dict[str, Any]:
        """
        主入口：扫描资料文件夹 + 智能重命名 + 生成规范化文件夹。

        Args:
            materials_dir: 用户原始资料文件夹路径
            output_dir: 规范化输出文件夹路径（如 .../standardized/）
            use_symlink: True=软链接（推荐，不复制文件）；False=复制副本

        Returns:
            {
                'standardized_dir': str,
                'report_md': str,  # rename_report.md 路径
                'files': [  # 每个文件的处理结果
                    {
                        'original_path': str,
                        'original_name': str,
                        'suggested_type': str,  # 如 '营业执照'
                        'suggested_name': str,  # 如 '营业执照.jpg'
                        'confidence': float,    # 0-1
                        'matched_rule': str,    # 'filename' / 'ocr' / 'directory' / 'none'
                        'matched_keyword': str,
                    }
                ],
                'stats': {
                    'total': int,
                    'identified': int,
                    'unidentified': int,
                    'high_confidence': int,   # >= 0.85
                    'medium_confidence': int, # 0.6-0.85
                    'low_confidence': int,    # < 0.6
                }
            }
        """
        materials_dir = Path(materials_dir)
        output_dir = Path(output_dir)

        if not materials_dir.exists():
            raise FileNotFoundError(f"资料文件夹不存在: {materials_dir}")

        _logger.info(f"=" * 60)
        _logger.info(f"资料命名规范化预处理 (v20.3)")
        _logger.info(f"=" * 60)
        _logger.info(f"输入: {materials_dir}")
        _logger.info(f"输出: {output_dir}")
        _logger.info(f"OCR: {'启用' if self.use_ocr else '禁用'}")

        # 1. 扫描所有文件
        _logger.info(f"\n[Step 1] 扫描资料文件...")
        files = self._scan_files(materials_dir)
        _logger.info(f"  共扫描 {len(files)} 个文件")

        # 2. 对每个文件，按三级规则匹配
        _logger.info(f"\n[Step 2] 智能匹配（三级规则）...")
        results = []
        for f in files:
            result = self._match_file(f, materials_dir)
            results.append(result)

        # 3. 去重：同一类型可能有多个文件（如多张营业执照），加序号
        _logger.info(f"\n[Step 3] 去重 + 命名...")
        results = self._deduplicate(results)

        # 4. 生成规范化文件夹（软链接/副本）
        _logger.info(f"\n[Step 4] 生成规范化文件夹...")
        self._generate_standardized(results, output_dir, use_symlink)

        # 5. 生成 rename_report.md
        _logger.info(f"\n[Step 5] 生成重命名报告...")
        report_path = output_dir / 'rename_report.md'
        stats = self._generate_report(results, report_path)

        # 6. 统计
        identified = sum(1 for r in results if r['suggested_type'] != '未识别')
        unidentified = len(results) - identified
        high_conf = sum(1 for r in results if r['confidence'] >= 0.85)
        med_conf = sum(1 for r in results if 0.6 <= r['confidence'] < 0.85)
        low_conf = sum(1 for r in results if 0 < r['confidence'] < 0.6)

        _logger.info(f"\n✓ 规范化完成")
        _logger.info(f"  已识别: {identified}/{len(results)}")
        _logger.info(f"  高置信度(≥85%): {high_conf}")
        _logger.info(f"  中置信度(60-85%): {med_conf}")
        _logger.info(f"  低置信度(<60%): {low_conf}")
        _logger.info(f"  未识别: {unidentified}")
        _logger.info(f"  报告: {report_path}")

        return {
            'standardized_dir': str(output_dir),
            'report_md': str(report_path),
            'files': results,
            'stats': {
                'total': len(results),
                'identified': identified,
                'unidentified': unidentified,
                'high_confidence': high_conf,
                'medium_confidence': med_conf,
                'low_confidence': low_conf,
            }
        }

    # ----------------------------------------------------------
    # Step 1: 扫描文件
    # ----------------------------------------------------------

    def _scan_files(self, materials_dir: Path) -> List[Dict]:
        """递归扫描资料文件夹下的所有文件"""
        supported_exts = {'.jpg', '.jpeg', '.png', '.bmp', '.gif', '.webp',
                          '.pdf', '.docx', '.doc', '.xlsx', '.xls'}
        files = []
        for root, dirs, filenames in os.walk(materials_dir):
            for fname in filenames:
                ext = os.path.splitext(fname)[1].lower()
                if ext in supported_exts:
                    fpath = Path(root) / fname
                    rel_dir = fpath.parent.relative_to(materials_dir)
                    files.append({
                        'path': str(fpath),
                        'name': fname,
                        'ext': ext,
                        'rel_dir': str(rel_dir) if str(rel_dir) != '.' else '',
                        'abs_dir': str(fpath.parent),
                    })
        return files

    # ----------------------------------------------------------
    # Step 2: 三级匹配
    # ----------------------------------------------------------

    def _match_file(self, file_info: Dict, base_dir: Path) -> Dict:
        """对单个文件按三级规则匹配"""
        result = {
            'original_path': file_info['path'],
            'original_name': file_info['name'],
            'ext': file_info['ext'],
            'rel_dir': file_info['rel_dir'],
            'suggested_type': '未识别',
            'suggested_name': file_info['name'],  # 默认保留原名
            'confidence': 0.0,
            'matched_rule': 'none',
            'matched_keyword': '',
        }

        # 规则 A: 文件名关键词匹配
        match_a = self._match_by_filename(file_info['name'])
        if match_a:
            result.update({
                'suggested_type': match_a['type'],
                'confidence': 0.9,
                'matched_rule': 'filename',
                'matched_keyword': match_a['keyword'],
            })
            return result

        # 规则 B: OCR 内容匹配（仅图片文件）
        if file_info['ext'] in {'.jpg', '.jpeg', '.png', '.bmp', '.gif', '.webp'}:
            match_b = self._match_by_ocr(file_info['path'])
            if match_b:
                result.update({
                    'suggested_type': match_b['type'],
                    'confidence': match_b['confidence'],
                    'matched_rule': 'ocr',
                    'matched_keyword': match_b['keyword'],
                })
                return result

        # 规则 C: 目录上下文匹配
        match_c = self._match_by_directory(file_info['rel_dir'], file_info['abs_dir'], base_dir)
        if match_c:
            result.update({
                'suggested_type': match_c['type'],
                'confidence': match_c['confidence'],
                'matched_rule': 'directory',
                'matched_keyword': match_c['dir_name'],
            })
            return result

        # 未识别
        return result

    def _match_by_filename(self, filename: str) -> Optional[Dict]:
        """规则 A: 文件名关键词匹配"""
        filename_lower = filename.lower()
        # 按关键词长度倒序匹配（避免短词先匹配）
        for mat_type, config in STANDARD_MATERIAL_TYPES.items():
            keywords = sorted(config['keywords'], key=len, reverse=True)
            for kw in keywords:
                if kw.lower() in filename_lower:
                    return {'type': mat_type, 'keyword': kw}
        return None

    def _match_by_ocr(self, image_path: str) -> Optional[Dict]:
        """规则 B: OCR 内容匹配"""
        engine = self._get_ocr_engine()
        if engine is None:
            return None

        try:
            # 用通用 OCR 识别
            text = ''
            if hasattr(engine, 'recognize_general'):
                text = engine.recognize_general(image_path) or ''
            elif hasattr(engine, 'smart_recognize'):
                result = engine.smart_recognize(image_path)
                if result:
                    text = str(result)

            if not text.strip():
                return None

            # 匹配 OCR 内容关键词
            best_type = None
            best_score = 0
            best_keyword = ''
            for mat_type, keywords in OCR_CONTENT_KEYWORDS.items():
                score = sum(1 for kw in keywords if kw in text)
                if score > best_score:
                    best_score = score
                    best_type = mat_type
                    best_keyword = keywords[0]

            if best_type and best_score >= 2:  # 至少匹配 2 个关键词
                # 置信度：匹配关键词数越多越高
                confidence = min(0.5 + best_score * 0.1, 0.85)
                return {'type': best_type, 'keyword': best_keyword,
                        'confidence': confidence}
        except Exception as e:
            _logger.debug(f"OCR 匹配失败 {image_path}: {e}")

        return None

    def _match_by_directory(self, rel_dir: str, abs_dir: str,
                              base_dir: Path) -> Optional[Dict]:
        """规则 C: 目录上下文匹配"""
        # 检查相对目录名 + 绝对目录名中的各级
        dir_parts = []
        if rel_dir:
            dir_parts.extend(rel_dir.replace('\\', '/').split('/'))
        # 也检查绝对路径中 base_dir 之后的部分
        try:
            abs_path = Path(abs_dir)
            rel_to_base = abs_path.relative_to(base_dir)
            dir_parts.extend(str(rel_to_base).replace('\\', '/').split('/'))
        except ValueError:
            pass

        # 去重
        dir_parts = list(dict.fromkeys(dir_parts))

        for part in dir_parts:
            # 精确匹配
            if part in DIRECTORY_CONTEXT:
                ctx_type = DIRECTORY_CONTEXT[part]
                if ctx_type:
                    return {'type': ctx_type, 'dir_name': part,
                            'confidence': 0.7}

            # 模糊匹配（目录名包含关键词）
            for mat_type, config in STANDARD_MATERIAL_TYPES.items():
                for ctx_dir in config.get('context_dirs', []):
                    if ctx_dir in part:
                        return {'type': mat_type, 'dir_name': part,
                                'confidence': 0.65}

        return None

    # ----------------------------------------------------------
    # Step 3: 去重（同类型多文件加序号）
    # ----------------------------------------------------------

    def _deduplicate(self, results: List[Dict]) -> List[Dict]:
        """同类型多文件加序号（如 营业执照_1.jpg, 营业执照_2.jpg）"""
        type_counter: Dict[str, int] = {}

        for r in results:
            if r['suggested_type'] == '未识别':
                continue

            mat_type = r['suggested_type']
            type_counter[mat_type] = type_counter.get(mat_type, 0) + 1
            count = type_counter[mat_type]

            if count == 1:
                # 第一个不加序号
                r['suggested_name'] = f"{mat_type}{r['ext']}"
            else:
                # 后续加序号
                r['suggested_name'] = f"{mat_type}_{count}{r['ext']}"
                # 同时把之前的也加序号（如果没加过）
                # 简化处理：只给后续加序号，第一个保持不带序号

        return results

    # ----------------------------------------------------------
    # Step 4: 生成规范化文件夹
    # ----------------------------------------------------------

    def _generate_standardized(self, results: List[Dict], output_dir: Path,
                                 use_symlink: bool):
        """生成规范化文件夹（软链接或副本）"""
        output_dir.mkdir(parents=True, exist_ok=True)

        for r in results:
            if r['suggested_type'] == '未识别':
                # 未识别文件复制到 unidentified/ 子目录
                unid_dir = output_dir / 'unidentified'
                unid_dir.mkdir(exist_ok=True)
                target = unid_dir / r['original_name']
            else:
                target = output_dir / r['suggested_name']

            # 避免覆盖
            if target.exists():
                base, ext = os.path.splitext(str(target))
                i = 2
                while Path(f"{base}_{i}{ext}").exists():
                    i += 1
                target = Path(f"{base}_{i}{ext}")

            try:
                if use_symlink:
                    # 软链接（不复制文件，节省空间）
                    if not target.exists():
                        os.symlink(r['original_path'], target)
                else:
                    # 复制副本
                    shutil.copy2(r['original_path'], target)
                r['standardized_path'] = str(target)
            except OSError as e:
                # 软链接失败（如 Windows 无权限），回退到复制
                _logger.debug(f"软链接失败，回退到复制: {e}")
                try:
                    shutil.copy2(r['original_path'], target)
                    r['standardized_path'] = str(target)
                except Exception as e2:
                    _logger.warning(f"文件复制失败: {r['original_name']} -> {target}: {e2}")
                    r['standardized_path'] = None

    # ----------------------------------------------------------
    # Step 5: 生成报告
    # ----------------------------------------------------------

    def _generate_report(self, results: List[Dict], report_path: Path) -> Dict:
        """生成 rename_report.md"""
        lines = []
        lines.append("# 资料命名规范化报告")
        lines.append("")
        lines.append("> **本文件由 material_normalizer 自动生成，请逐项确认后回复。**")
        lines.append("> - 高置信度（≥85%）默认通过")
        lines.append("> - 中置信度（60-85%）建议确认")
        lines.append("> - 低置信度（<60%）必须确认或手动指定")
        lines.append("")

        # 统计
        stats = {
            'total': len(results),
            'identified': sum(1 for r in results if r['suggested_type'] != '未识别'),
            'high': sum(1 for r in results if r['confidence'] >= 0.85),
            'medium': sum(1 for r in results if 0.6 <= r['confidence'] < 0.85),
            'low': sum(1 for r in results if 0 < r['confidence'] < 0.6),
            'unidentified': sum(1 for r in results if r['suggested_type'] == '未识别'),
        }
        lines.append("## 总览")
        lines.append("")
        lines.append(f"| 项 | 数量 |")
        lines.append(f"|----|------|")
        lines.append(f"| 总文件数 | {stats['total']} |")
        lines.append(f"| 已识别 | {stats['identified']} |")
        lines.append(f"| ✅ 高置信度(≥85%) | {stats['high']} |")
        lines.append(f"| ⚠️ 中置信度(60-85%) | {stats['medium']} |")
        lines.append(f"| 🔴 低置信度(<60%) | {stats['low']} |")
        lines.append(f"| ❌ 未识别 | {stats['unidentified']} |")
        lines.append("")
        lines.append("---")
        lines.append("")

        # 逐文件详情
        lines.append("## 逐文件匹配详情")
        lines.append("")
        lines.append("| 序号 | 原文件名 | 建议类型 | 建议新名 | 置信度 | 匹配规则 | 匹配关键词 |")
        lines.append("|------|---------|---------|---------|--------|---------|-----------|")

        for i, r in enumerate(results, 1):
            conf_pct = f"{int(r['confidence'] * 100)}%" if r['confidence'] > 0 else "—"
            rule_label = {
                'filename': '文件名',
                'ocr': 'OCR',
                'directory': '目录',
                'none': '未匹配',
            }.get(r['matched_rule'], r['matched_rule'])
            lines.append(f"| {i} | {r['original_name']} | {r['suggested_type']} | "
                         f"{r['suggested_name']} | {conf_pct} | {rule_label} | "
                         f"{r['matched_keyword']} |")

        lines.append("")
        lines.append("---")
        lines.append("")

        # 用户确认提示
        lines.append("## 用户确认")
        lines.append("")
        lines.append("```")
        lines.append("# 逐项确认（用序号）")
        lines.append("1.确认                    # 接受 AI 建议的命名")
        lines.append("2.修改:营业执照.jpg       # 修改为新文件名")
        lines.append("3.手动指定:法人身份证正面  # 手动指定资料类型")
        lines.append("4.跳过                    # 不处理，保留原名")
        lines.append("")
        lines.append("# 批量操作")
        lines.append("全部确认                  # 所有高/中置信度项默认通过")
        lines.append("全部跳过未识别            # 未识别文件保留原名")
        lines.append("```")
        lines.append("")
        lines.append("> 确认后，AI 会用规范化文件夹跑 Stage 3 资料扫描，匹配率大幅提升。")

        report_path.write_text('\n'.join(lines), encoding='utf-8')
        return stats


# ============================================================
# CLI 入口
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description='资料命名规范化预处理 (v20.3)')
    parser.add_argument('--input', required=True, help='用户原始资料文件夹路径')
    parser.add_argument('--output', required=True, help='规范化输出文件夹路径')
    parser.add_argument('--no-ocr', action='store_true', help='禁用 OCR（仅用文件名+目录匹配）')
    parser.add_argument('--copy', action='store_true', help='复制副本（默认软链接）')
    args = parser.parse_args()

    normalizer = MaterialNormalizer(use_ocr=not args.no_ocr)
    result = normalizer.normalize(args.input, args.output, use_symlink=not args.copy)

    print(f"\n✓ 规范化完成")
    print(f"  输出目录: {result['standardized_dir']}")
    print(f"  报告文件: {result['report_md']}")
    print(f"  已识别: {result['stats']['identified']}/{result['stats']['total']}")
    print(f"  高置信度: {result['stats']['high_confidence']}")
    print(f"  中置信度: {result['stats']['medium_confidence']}")
    print(f"  低置信度: {result['stats']['low_confidence']}")
    print(f"  未识别: {result['stats']['unidentified']}")


if __name__ == '__main__':
    main()
