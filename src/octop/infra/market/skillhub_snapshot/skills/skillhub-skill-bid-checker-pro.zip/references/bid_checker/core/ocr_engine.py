#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OCR 统一引擎模块 (v11 — 本地无 API 架构)

仅使用 RapidOCR 本地模型（基于 ONNX Runtime，无需注册、无需 API 密钥、无需联网）。
RapidOCR 实例不可用时返回 None，由调用方标黄提示用户手动填写。

为什么是 RapidOCR 而不是 PaddleOCR（v11 变更说明）：
  本技能 v10 曾使用 PaddleOCR 作为本地引擎。但在 Python 3.13 运行时上，
  PaddlePaddle 3.x 的 OneDNN/PIR 执行器存在未实现的属性转换 bug
  （ConvertPirAttribute2RuntimeAttribute），导致 PaddleOCR 推理必崩；而能绕过该
  bug 的 paddlepaddle==2.6.2 在 Python 3.13 上根本没有可用轮子。因此 v11 将本地
  引擎切换为 RapidOCR —— 它是 PaddleOCR 检测/识别模型的纯 ONNX 重实现，仅依赖
  onnxruntime（CPU 即可），不依赖 paddlepaddle，在 Python 3.13 上原生可用，且同样
  无需任何云端 API 密钥。

统一接口：
  - recognize_id_card(image_input, side) -> 身份证结构化数据
  - recognize_business_license(image_input) -> 营业执照结构化数据
  - recognize_general(image_input) -> 通用文字文本
  - smart_recognize(image_input) -> 自动判断类型+结构化输出
  - get_business_license_mapped(image_input) -> 映射后字段名
  - get_id_card_mapped(image_input, side) -> 映射后字段名

工厂函数：
  create_ocr_engine(config_path=None) -> 返回 RapidOCR 本地引擎或 None

历史说明：
  v9 及以前曾内置「百度 OCR API」后端，因需云端密钥、存在密钥泄露风险，
  且不符合本技能「无需任何 API」的诉求，已从本模块彻底移除（v10）。
  v10 改用本地 PaddleOCR，但 Python 3.13 上的推理兼容性问题使其不可用（v11 修复）。
  配置文件中残留的 `baidu_ocr` 字段会被直接忽略，不再读取。
"""

import os
import sys
import re
import tempfile
import subprocess

# 统一日志
try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.ocr_engine")
except ImportError:
    # 独立运行时回退到 print
    import logging
    _logger = logging.getLogger("ocr_engine")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)


# ============================================================
# 配置加载（本地无 API 模式，无需读取任何云端密钥）
# ============================================================
# 本模块仅使用 RapidOCR 本地引擎，不加载也不依赖任何云端 OCR 密钥。
# 历史上曾存在的 BAIDU_OCR_API_KEY / BAIDU_OCR_SECRET_KEY 等配置已被彻底移除，
# 旧 config.json 中的 `baidu_ocr` 字段直接忽略，不作任何读取，
# 从根源上杜绝密钥泄露与"静默降级"问题。


# ============================================================
# 后端：RapidOCR 本地模型（基于 ONNX Runtime，无需注册，无需 API 密钥）
# ============================================================

class RapidOCRBackend:
    """RapidOCR 本地模型后端 — 基于 ONNX Runtime，无需注册 API 密钥，自动安装"""

    # 身份证正面的常见字段关键词（用于从通用OCR结果中提取结构化数据）
    _ID_CARD_FRONT_KEYS = ['姓名', '性别', '民族', '出生', '公民身份号码', '住址', '身份证号']
    _ID_CARD_BACK_KEYS = ['签发机关', '有效期', '失效日期']
    _BUSINESS_LICENSE_KEYS = ['单位名称', '社会信用代码', '法定代表人', '法人',
                              '注册资本', '成立日期', '营业期限', '经营范围', '类型']

    def __init__(self, config_path=None):
        """初始化 RapidOCR，自动检测并安装"""
        self._engine = None
        self.backend_name = 'rapidocr'
        self._init_engine()

    def _init_engine(self):
        """延迟初始化 RapidOCR 实例（首次调用时加载 ONNX 模型）"""
        try:
            from rapidocr_onnxruntime import RapidOCR
            self._engine = RapidOCR()
            if self._engine is not None:
                _logger.info('RapidOCR 本地模型初始化成功')
        except ImportError:
            _logger.warning('RapidOCR 未安装，尝试自动安装...')
            self._auto_install_rapidocr()
            try:
                from rapidocr_onnxruntime import RapidOCR
                self._engine = RapidOCR()
                if self._engine is not None:
                    _logger.info('RapidOCR 自动安装并初始化成功')
                else:
                    _logger.warning('RapidOCR 自动安装后仍无法初始化')
                    self._engine = None
            except Exception as e:
                _logger.warning(f'RapidOCR 自动安装失败: {e}')
                self._engine = None
        except Exception as e:
            # 模型下载/加载失败也视为不可用，避免整个流程崩溃
            _logger.warning(f'RapidOCR 初始化异常（模型可能无法下载）: {e}')
            self._engine = None

    @staticmethod
    def _auto_install_rapidocr():
        """自动安装 rapidocr-onnxruntime 与 onnxruntime（使用 python -m pip 方式）"""
        python_path = sys.executable
        if not python_path:
            _logger.warning('  [WARN] 无法找到 Python 解释器，请手动安装: '
                            'pip install rapidocr-onnxruntime onnxruntime')
            return False

        try:
            _logger.info('  -> 正在安装 rapidocr-onnxruntime + onnxruntime...')
            result = subprocess.run(
                [python_path, '-m', 'pip', 'install', 'rapidocr-onnxruntime', 'onnxruntime', '-q'],
                timeout=300, capture_output=True
            )
            if result.returncode != 0:
                stderr = result.stderr.decode('utf-8', errors='replace')[:300]
                _logger.warning(f'  [WARN] rapidocr-onnxruntime 安装失败: {stderr}')
                return False
            _logger.info('  [OK] RapidOCR 安装成功')
            return True
        except subprocess.TimeoutExpired:
            _logger.warning('  [WARN] 安装超时（网络可能较慢），请手动安装: '
                            'pip install rapidocr-onnxruntime onnxruntime')
            return False
        except Exception as e:
            _logger.warning(f'  [WARN] 安装异常: {e}')
            return False

    def _ocr_image(self, image_input):
        """RapidOCR 核心识别 — 返回 [(text, confidence), ...]

        RapidOCR 1.x 的 `engine(img)` 返回 `(detections, thresholds)`，
        其中 detections 为 list，每个元素是 `[box, text, score]`。
        """
        if self._engine is None:
            return []

        # 处理输入类型
        if isinstance(image_input, bytes):
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
                tmp.write(image_input)
                img_path = tmp.name
        elif isinstance(image_input, str):
            img_path = image_input
        else:
            raise TypeError("image_input 必须是 str(路径) 或 bytes(数据)")

        try:
            result = self._engine(img_path)
            # result 可能为 None（推理失败）
            if not result or not result[0]:
                return []
            detections = result[0]
            texts = []
            for item in detections:
                try:
                    # item: [box, text, score]
                    text = item[1]
                    score = item[2] if len(item) >= 3 else 0.0
                    texts.append((str(text), float(score)))
                except (IndexError, TypeError, ValueError):
                    continue
            return texts
        except Exception as e:
            _logger.warning(f'RapidOCR 识别出错: {e}')
            return []
        finally:
            if isinstance(image_input, bytes) and os.path.exists(img_path):
                os.unlink(img_path)

    def recognize_general(self, image_input, detect_direction=True):
        """通用文字识别"""
        texts = self._ocr_image(image_input)
        if not texts:
            return ""
        return "\n".join(t[0] for t in texts)

    def recognize_id_card(self, image_input, side="front"):
        """
        身份证识别（基于通用OCR + 正则提取）
        RapidOCR 没有身份证专用 API，所以用通用 OCR + 关键词匹配来提取结构化数据
        """
        texts = self._ocr_image(image_input)
        if not texts:
            return {}

        # 将所有识别文字合并，用于关键词匹配
        all_text = "\n".join(t[0] for t in texts)

        id_info = {}
        if side == "front":
            # 正面：姓名、性别、民族、出生日期、身份证号、住址
            # 姓名 — 通常单独一行，2-4个汉字，姓氏开头
            name_match = re.search(r'姓名\s*[：:]\s*([\u4e00-\u9fff]{2,4})', all_text)
            if name_match:
                id_info["姓名"] = name_match.group(1)
            else:
                # 尝试找紧接"姓名"后面的短文本
                for text, conf in texts:
                    if text.startswith('姓名') and len(text) <= 8:
                        name = re.sub(r'^姓名\s*[：:]*', '', text)
                        if re.match(r'^[\u4e00-\u9fff]{2,4}$', name):
                            id_info["姓名"] = name

            # 性别
            gender_match = re.search(r'性别\s*[：:]\s*(男|女)', all_text)
            if gender_match:
                id_info["性别"] = gender_match.group(1)

            # 民族
            nation_match = re.search(r'民族\s*[：:]\s*([\u4e00-\u9fff]+)', all_text)
            if nation_match:
                id_info["民族"] = nation_match.group(1)

            # 出生日期
            birth_match = re.search(r'出生\s*[：:]*\s*(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', all_text)
            if birth_match:
                id_info["出生日期"] = f"{birth_match.group(1)}{birth_match.group(2)}{birth_match.group(3)}"
                from datetime import datetime
                id_info["年龄"] = datetime.now().year - int(birth_match.group(1))
            else:
                # 紧凑格式：19560712
                birth_match2 = re.search(r'(\d{4})(\d{2})(\d{2})', all_text)
                if birth_match2 and int(birth_match2.group(1)) > 1940:
                    id_info["出生日期"] = f"{birth_match2.group(1)}{birth_match2.group(2)}{birth_match2.group(3)}"
                    from datetime import datetime
                    id_info["年龄"] = datetime.now().year - int(birth_match2.group(1))

            # 身份证号 — 18位数字（最后一位可能是X）
            id_match = re.search(r'[：:]*\s*(\d{17}[\dXx])', all_text)
            if id_match:
                id_info["身份证号"] = id_match.group(1)
            else:
                # 查找包含"号码"关键词的行
                for text, conf in texts:
                    if '号码' in text or '身份' in text:
                        num_match = re.search(r'(\d{17}[\dXx])', text)
                        if num_match:
                            id_info["身份证号"] = num_match.group(1)

            # 住址
            addr_match = re.search(r'住址\s*[：:]\s*([\u4e00-\u9fff\d]+)', all_text)
            if addr_match:
                id_info["地址"] = addr_match.group(1)

        else:
            # 反面：签发机关、有效期
            sign_match = re.search(r'签发机关\s*[：:]\s*([\u4e00-\u9fff]+)', all_text)
            if sign_match:
                id_info["签发机关"] = sign_match.group(1)

            # 有效期格式：2010.01.01-2030.01.01 或 长期
            valid_match = re.search(r'(\d{4}[.\-]\d{2}[.\-]\d{2})\s*[-—]\s*(\d{4}[.\-]\d{2}[.\-]\d{2}|长期)', all_text)
            if valid_match:
                id_info["有效期开始"] = valid_match.group(1)
                id_info["有效期结束"] = valid_match.group(2)

        return id_info

    def recognize_business_license(self, image_input):
        """
        营业执照识别（基于通用OCR + 关键词提取）
        """
        texts = self._ocr_image(image_input)
        if not texts:
            return {}

        all_text = "\n".join(t[0] for t in texts)

        license_info = {}

        # 公司名称/单位名称
        name_match = re.search(r'(?:单位名称|公司名称|名称)\s*[：:]\s*([\u4e00-\u9fff（()）]+)', all_text)
        if name_match:
            license_info["公司名称"] = name_match.group(1)
        else:
            # 营业执照通常第一行或包含"有限公司"的行是公司名
            for text, conf in texts:
                if '有限公司' in text or '有限责任' in text:
                    license_info["公司名称"] = text.strip()
                    break

        # 统一社会信用代码 — 18位字母数字
        credit_match = re.search(r'(?:统一社会信用代码|社会信用代码|信用代码)\s*[：:]*\s*([A-Z0-9]{18})', all_text)
        if credit_match:
            license_info["统一社会信用代码"] = credit_match.group(1)
        else:
            # 查找18位代码（不以纯数字开头排除身份证号）
            for text, conf in texts:
                code_match = re.search(r'[A-Z0-9]{18}', text)
                if code_match and code_match.group(0)[0].isalpha():
                    license_info["统一社会信用代码"] = code_match.group(0)

        # 法定代表人
        legal_match = re.search(r'(?:法定代表人|法人|负责人)\s*[：:]\s*([\u4e00-\u9fff]{2,4})', all_text)
        if legal_match:
            license_info["法定代表人"] = legal_match.group(1)

        # 注册资本
        capital_match = re.search(r'注册资本\s*[：:]\s*([\d,.]+\s*万?\s*元)', all_text)
        if capital_match:
            license_info["注册资本"] = capital_match.group(1)

        # 成立日期
        date_match = re.search(r'成立日期\s*[：:]\s*(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日)', all_text)
        if date_match:
            license_info["成立日期"] = date_match.group(1)
        else:
            date_match2 = re.search(r'成立日期\s*[：:]\s*(\d{4}[.\-/\s]+\d{1,2}[.\-/\s]+\d{1,2})', all_text)
            if date_match2:
                license_info["成立日期"] = date_match2.group(1)

        # 营业期限
        term_match = re.search(r'营业期限\s*[：:]\s*(.+)', all_text)
        if term_match:
            license_info["营业期限"] = term_match.group(1).strip()

        # 经营范围
        scope_match = re.search(r'经营范围\s*[：:]\s*([\u4e00-\u9fff，、,;.]+)', all_text)
        if scope_match:
            license_info["经营范围"] = scope_match.group(1)

        # 类型/单位性质
        type_match = re.search(r'(?:类型|公司类型|单位性质)\s*[：:]\s*([\u4e00-\u9fff]+)', all_text)
        if type_match:
            license_info["类型"] = type_match.group(1)

        return license_info

    def smart_recognize(self, image_input):
        """智能识别：自动判断图片类型"""
        # 1. 营业执照
        result = self.recognize_business_license(image_input)
        if result and any(result.values()):
            result['识别类型'] = '营业执照'
            return result

        # 2. 身份证正面
        result = self.recognize_id_card(image_input, side='front')
        if result and result.get('姓名'):
            result['识别类型'] = '身份证正面'
            return result

        # 3. 身份证反面
        result = self.recognize_id_card(image_input, side='back')
        if result and any(result.values()):
            result['识别类型'] = '身份证反面'
            return result

        # 4. 通用OCR
        text = self.recognize_general(image_input)
        if text:
            result = {'识别类型': '通用文字', '通用文字': text.split('\n')}
            return result

        return None

    def get_business_license_mapped(self, image_input):
        """识别营业执照并返回映射后的字段名"""
        raw = self.recognize_business_license(image_input)
        if not raw:
            return None
        mapped = {
            '单位名称': raw.get('公司名称', ''),
            '地址': raw.get('地址', ''),
            '法人': raw.get('法定代表人', ''),
            '成立日期': raw.get('成立日期', ''),
            '社会信用代码': raw.get('统一社会信用代码', ''),
            '单位性质': raw.get('类型', ''),
            '经营范围': raw.get('经营范围', ''),
        }
        mapped = {k: v for k, v in mapped.items() if v}
        return mapped

    def get_id_card_mapped(self, image_input, side='front'):
        """识别身份证并返回映射后的字段名"""
        raw = self.recognize_id_card(image_input, side)
        if not raw or not raw.get('姓名'):
            return None
        mapped = {}
        if side == 'front':
            mappings = {
                '姓名': raw.get('姓名', ''),
                '性别': raw.get('性别', ''),
                '民族': raw.get('民族', ''),
                '公民身份号码': raw.get('身份证号', ''),
                '住址': raw.get('地址', ''),
            }
            if raw.get('出生日期'):
                mapped['出生日期'] = raw.get('出生日期')
            if raw.get('年龄'):
                mapped['年龄'] = raw.get('年龄')
        else:
            mappings = {
                '签发机关': raw.get('签发机关', ''),
            }
        mapped.update({k: v for k, v in mappings.items() if v})
        return mapped


# ============================================================
# 工厂函数
# ============================================================

def create_ocr_engine(config_path=None, verbose=True):
    """
    OCR 引擎工厂函数 — 返回本地 RapidOCR 引擎（v11 无 API 模式）。

    RapidOCR 无需任何云端密钥、无需注册、无需联网；首次使用时
    RapidOCRBackend 会自动安装 rapidocr-onnxruntime + onnxruntime 并下载 ONNX 模型。
    若 RapidOCR 不可用（未安装且自动安装失败，或模型无法下载），返回 None，
    由调用方标黄提示用户手动填写资质信息。

    :param config_path: 保留参数（历史兼容），本模式不再读取任何密钥
    :param verbose: 是否打印选择信息
    :return: RapidOCRBackend 实例 或 None
    """
    try:
        engine = RapidOCRBackend(config_path)
        if engine._engine is not None:
            if verbose:
                _logger.info('  [OK] OCR 后端: RapidOCR 本地模型（无需 API 密钥）')
            return engine
        else:
            if verbose:
                _logger.warning('  [WARN] RapidOCR 初始化失败（未安装且自动安装未成功）')
    except Exception as e:
        if verbose:
            _logger.warning(f'  [WARN] RapidOCR 初始化异常: {e}')

    if verbose:
        _logger.warning('  [WARN] OCR 引擎不可用（RapidOCR 未安装/不可用）')
        _logger.info('  -> 图片类资料将标黄提示用户手动填写；')
        _logger.info('  -> 如需启用：pip install rapidocr-onnxruntime onnxruntime')
    return None


# ============================================================
# 测试代码
# ============================================================

if __name__ == "__main__":
    _logger.info("=" * 60)
    _logger.info("  OCR 统一引擎 v11 — 本地 RapidOCR（无 API）")
    _logger.info("=" * 60)

    import argparse
    parser = argparse.ArgumentParser(description='OCR 引擎测试')
    parser.add_argument('--config', default=None, help='配置文件路径（保留参数，无实际密钥读取）')
    parser.add_argument('--image', help='测试图片路径')
    args = parser.parse_args()

    # 创建引擎（始终为本地 RapidOCR，无需任何 API 密钥）
    ocr = create_ocr_engine(args.config)
    if ocr is None:
        _logger.error("  [ERROR] 无可用 OCR 引擎：请先安装 RapidOCR"
                      "（pip install rapidocr-onnxruntime onnxruntime）")
        sys.exit(1)

    _logger.info(f"  当前后端: {ocr.backend_name}（本地，无 API 密钥）")

    if args.image and os.path.exists(args.image):
        _logger.info("\n--- 智能识别测试 ---")
        result = ocr.smart_recognize(args.image)
        if result:
            _logger.info(f"  识别类型: {result.get('识别类型', '未知')}")
            for k, v in result.items():
                if k != '识别类型':
                    _logger.info(f"  {k}: {v}")
        else:
            _logger.info("  未能识别")
    else:
        _logger.info("\n  未提供测试图片，跳过识别测试")
        _logger.info("  使用方法: python ocr_engine.py --image 图片路径")

    _logger.info("\n--- 后端信息 ---")
    _logger.info("  RapidOCR: 纯 ONNX 模型 + ONNX Runtime，无需注册，本地运行（自动安装）")
