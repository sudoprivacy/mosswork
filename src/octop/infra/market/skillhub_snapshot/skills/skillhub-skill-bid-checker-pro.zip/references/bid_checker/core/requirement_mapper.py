#!/usr/bin/env python3
"""
需求映射引擎 (Requirement Mapper)
=================================
将模板需求位与资料清单进行智能匹配，生成映射报告。

匹配规则（按优先级）：
1. 关键词精确匹配（模板.expected_keyword == 资料.章节标题）
2. 内容类型校验（image_block 只能匹配 image_only/mixed）
3. 一对一约束（同一资料章节不重复匹配）
4. 关键词近似匹配（社保↔社会保障资金等别名扩展）
5. 语义近似匹配（模糊匹配）

输出：每个模板需求的 fill_strategy
- insert_images: 从源文档插入图片
- copy_text: 从源文档复制文本（需变量替换）
- ai_generate: AI生成
- mark_missing: 标黄缺失
"""

import os
import re
import json
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field
from collections import defaultdict

# ============================================================================
# 数据结构
# ============================================================================

@dataclass
class TemplateRequirement:
    """模板中的一个需求位置"""
    req_id: str                         # 唯一ID (如 "ch7_finance")
    chapter: str                        # 所属章节
    para_index: int                     # 段落索引
    description: str                    # 需求描述（模板原文）
    need_type: str                      # image_block / text_block / text_reference
    keywords: List[str] = field(default_factory=list)  # 匹配关键词
    aliases: List[str] = field(default_factory=list)   # 关键词别名


# v9.0: 统一日志
try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.requirement_mapper")
except ImportError:
    import logging
    _logger = logging.getLogger("requirement_mapper")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)

# v9.0.3: token 生成（与 fill_anchor 一致）
try:
    from fill_anchor import TOKEN_OPEN, TOKEN_CLOSE
    def _make_token(sid):
        return f"{TOKEN_OPEN}{sid}{TOKEN_CLOSE}"
except ImportError:
    def _make_token(sid):
        return f"[[FILL:{sid}]]"

@dataclass
class MapResult:
    """单个需求的匹配结果"""
    req_id: str
    status: str                         # matched / partial / missing
    fill_strategy: str                  # insert_images / copy_text / ai_generate / mark_missing / extract_and_fill
    chapter: str = ""                   # 所属章节标题（方案类章节直接用检测到的标题）
    target_para_index: int = 0          # 模板中的目标段落索引（旧定位，保留兼容）
    target_token: str = ""              # v9.0.3: 确定性定位锚点 token（Stage 2 注入）
    slot_type: str = ""                 # v9.0.3: text_field/table_cell/image_block/proposal_section/signature_block/cover_field
    target_description: str = ""        # 模板需求描述
    source_file: Optional[str] = None
    source_path: Optional[str] = None   # 源文件完整路径
    source_section_id: Optional[int] = None
    source_heading: Optional[str] = None
    source_para_start: int = 0          # 源章节起始段落
    source_para_end: int = 0            # 源章节结束段落
    image_count: int = 0
    images: List[str] = field(default_factory=list)
    text_content: Optional[str] = None
    note: str = ""
    # v9.0.3: 方案来源路由（用户协议：State A 直接复制 / State B 交互撰写）
    source_doc: str = ""                  # 资料中该方案章节的原文文件路径（State A）
    needs_write: bool = False             # 资料中无原文，需 Stage 5 交互撰写（State B）
    proposal_candidates: List[str] = field(default_factory=list)  # 资料中发现的所有方案原文候选
    proposal_confidence: int = 0          # 自动匹配置信度 0~100


# ============================================================================
# 需求定义 — 模板无关的章节检测模式
# ============================================================================
# 所有章节位置不再硬编码 para_index，改为运行时从模板动态扫描。
# 
# 架构：
#   FIXED_CHAPTER_PATTERNS  → 定义各类"固定类型"章节的关键词匹配规则
#   PROPOSAL_CHAPTER_PATTERNS → 定义方案类章节（已在 v7.0 实现）
#   detect_fixed_chapters()  → 扫描模板，按模式生成 TemplateRequirement 列表
#   detect_proposal_chapters() → 扫描模板，按模式生成方案类 TemplateRequirement 列表
#   TEMPLATE_REQUIREMENTS = detect_fixed_chapters(...) + detect_proposal_chapters(...)
#
# 每个模式说明：
#   category:    人类可读的分类名
#   req_id_base: req_id 前缀（如 'identity' → 'identity_text', 'identity_id_card'）
#   primary_kw:  精确匹配关键词（至少命中一个即匹配）
#   sub_items:   该章节下的子需求（每个生成一个 TemplateRequirement）
#                - 如果为空，则该章节只生成1个 TemplateRequirement（用 single_need）
#   single_need: 仅当 sub_items 为空时使用，定义该章节的唯一需求
#   priority:    数字越小优先级越高（避免"授权委托书"被"法定代表人授权委托书"吞掉）
# ============================================================================

# 模板章节与资料章节的关键词映射（保留，供匹配引擎使用）
CHAPTER_KEYWORD_MAP = {
    '营业执照': {
        'keywords': ['营业执照'],
        'aliases': ['统一社会信用代码', '营业执照副本'],
        'need_type': 'image_block',
    },
    '财务状况报告': {
        'keywords': ['财务状况报告', '财务状况', '财务报告', '财务审计报告'],
        'aliases': ['审计报告', '财务报表', '资产负债表'],
        'need_type': 'image_block',
    },
    '税收缴纳证明': {
        'keywords': ['税收缴纳证明', '税收缴纳', '完税证明', '纳税证明'],
        'aliases': ['税收证明', '完税', '纳税'],
        'need_type': 'image_block',
    },
    '社会保障资金缴纳证明': {
        'keywords': ['社会保障资金缴纳证明', '社会保障资金', '社保', '社会保险'],
        'aliases': ['社保缴纳', '社保缴存', '社会保险参保'],
        'need_type': 'image_block',
    },
    '信用信息证明': {
        'keywords': ['信用中国', '信用信息证明', '信用信息', '失信被执行人'],
        'aliases': ['信用报告', '信用记录', '中国执行信息公开网', '税收违法失信'],
        'need_type': 'image_block',
    },
    '法定代表人身份证明': {
        'keywords': ['法定代表人身份证明', '法定代表人'],
        'aliases': ['法人身份证明', '法人代表身份证明'],
        'need_type': 'text_reference',
    },
    '法定代表人授权书': {
        'keywords': ['法定代表人授权书', '法定代表人授权委托书', '授权委托书'],
        'aliases': ['授权书', '委托书'],
        'need_type': 'text_reference',
    },
    '法定代表人身份证复印件': {
        'keywords': ['法定代表人', '身份证'],
        'aliases': ['法人身份证'],
        'need_type': 'image_block',
    },
    '被授权人身份证复印件': {
        'keywords': ['被授权人', '授权代表', '身份证'],
        'aliases': ['代理人身份证'],
        'need_type': 'image_block',
    },
    '设备技术能力证明': {
        'keywords': ['提供履行合同所必需的设备和专业技术能力', '设备和专业技术能力'],
        'aliases': ['履行合同', '设备能力', '技术能力', '专业技术能力的说明'],
        'need_type': 'text_block',
    },
    '非联合体投标声明': {
        'keywords': ['非联合体投标声明', '非联合体投标', '联合体'],
        'aliases': ['非联合体', '联合体投标'],
        'need_type': 'text_block',
    },
    '无重大违法记录声明': {
        'keywords': ['无重大违法记录', '经营活动中没有重大违法记录', '重大违法记录'],
        'aliases': ['无违法记录', '违法记录声明'],
        'need_type': 'text_block',
    },
    '无控股关系声明': {
        'keywords': ['单位负责人为同一人', '控股关系', '管理关系'],
        'aliases': ['控股', '关联关系'],
        'need_type': 'text_block',
    },
}


# ── 固定类型章节检测模式 ──
# 每个模式描述一类在投标模板中常见的章节类型。
# sub_items 中同一个 sub_id 不会重复。
FIXED_CHAPTER_PATTERNS = [
    # ── 法定代表人身份证明 ──
    {
        'category': '法定代表人身份证明',
        'req_id_base': 'identity',
        'primary_kw': ['法定代表人身份证明', '法定代表人身份'],
        'sub_items': [
            {
                'sub_id': 'identity_text',
                'description': '法定代表人身份信息（姓名、职务、地址等）',
                'need_type': 'text_reference',
                'keywords': ['法定代表人身份证明', '法定代表人身份'],
                'aliases': ['法人身份证明', '法定代表人信息', '法定代表人'],
            },
            {
                'sub_id': 'identity_id_card',
                'description': '附：法定代表人身份证复印件',
                'need_type': 'image_block',
                'keywords': ['法定代表人', '身份证复印件', '法定代表人身份证明'],
                'aliases': ['法人身份证', '身份证'],
            },
        ],
        'priority': 5,
    },
    # ── 法定代表人授权委托书 ──
    {
        'category': '法定代表人授权委托书',
        'req_id_base': 'auth',
        'primary_kw': ['法定代表人授权委托书', '法定代表人授权书', '授权委托书'],
        'sub_items': [
            {
                'sub_id': 'auth_text',
                'description': '授权委托书文本及被授权人信息',
                'need_type': 'text_reference',
                'keywords': ['法定代表人授权委托书', '法定代表人授权书', '授权委托'],
                'aliases': ['授权书', '委托书'],
            },
            {
                'sub_id': 'auth_id_card',
                'description': '附：法定代表人、被授权人身份证复印件',
                'need_type': 'image_block',
                'keywords': ['法定代表人', '被授权人', '身份证复印件', '身份证'],
                'aliases': ['法人身份证', '授权代表身份证'],
            },
        ],
        'priority': 5,
    },
    # ── 商务条款偏离表 ──
    {
        'category': '商务条款偏离表',
        'req_id_base': 'commercial_deviation',
        'primary_kw': ['商务条款偏离表', '商务偏离表'],
        'sub_items': [],
        'single_need': {
            'description': '商务条款偏离表（从用户资料逐行填入）',
            'need_type': 'text_reference',
            'keywords': ['商务条款偏离', '商务偏离表', '商务偏离'],
            'aliases': ['商务条款', '商务偏离', '偏离表'],
        },
        'priority': 10,
    },
    # ── 技术参数条款偏离表 ──
    {
        'category': '技术参数条款偏离表',
        'req_id_base': 'technical_deviation',
        'primary_kw': ['技术参数条款偏离表', '技术偏离表', '技术参数偏离表'],
        'sub_items': [],
        'single_need': {
            'description': '技术参数条款偏离表（从用户资料逐行填入）',
            'need_type': 'text_reference',
            'keywords': ['技术参数偏离', '技术偏离表', '技术参数条款偏离'],
            'aliases': ['技术偏离', '技术参数', '参数偏离'],
        },
        'priority': 10,
    },
    # ── 拟投入人员 ──
    {
        'category': '拟投入人员',
        'req_id_base': 'personnel',
        'primary_kw': ['拟投入人员', '项目人员', '项目组人员', '人员配备', '项目团队'],
        'sub_items': [],
        'single_need': {
            'description': '拟投入人员汇总表 + 人员资料附件',
            'need_type': 'text_reference',
            'keywords': ['人员资料', '人员信息', '投入人员', '项目组'],
            'aliases': ['人员汇总', '项目团队', '人员名单'],
        },
        'priority': 15,
    },
    # ── 资质证明文件 ──
    {
        'category': '资质证明文件',
        'req_id_base': 'qualification',
        'primary_kw': ['资质证明文件', '资格证明文件', '资格审查材料', '资质文件',
                       '资格证明', '投标人资格'],
        'sub_items': [
            {
                'sub_id': 'qualification_business_license',
                'description': '具有独立承担民事责任能力的法人（营业执照）',
                'need_type': 'image_block',
                'keywords': ['营业执照'],
                'aliases': ['统一社会信用代码', '营业执照副本'],
            },
            {
                'sub_id': 'qualification_finance_report',
                'description': '财务状况报告',
                'need_type': 'image_block',
                'keywords': ['财务状况报告', '财务状况', '财务审计报告'],
                'aliases': ['审计报告', '财务报表', '资信证明'],
            },
            {
                'sub_id': 'qualification_tax_cert',
                'description': '税收缴纳证明',
                'need_type': 'image_block',
                'keywords': ['税收缴纳证明', '税收缴纳', '完税证明', '纳税证明'],
                'aliases': ['税收证明', '完税'],
            },
            {
                'sub_id': 'qualification_social_security',
                'description': '社会保障资金缴纳证明',
                'need_type': 'image_block',
                'keywords': ['社会保障资金缴纳证明', '社会保障资金', '社保', '社会保险'],
                'aliases': ['社保缴纳', '社保缴存'],
            },
            {
                'sub_id': 'qualification_credit',
                'description': '信用中国/失信被执行人查询截图',
                'need_type': 'image_block',
                'keywords': ['信用中国', '信用信息', '失信被执行人', '税收违法失信'],
                'aliases': ['信用报告', '信用记录', '执行信息公开网', '未列入失信', '严重失信'],
            },
            {
                'sub_id': 'qualification_equipment_capability',
                'description': '投标人应在人员、设备、资金等方面具备相应的能力',
                'need_type': 'text_block',
                'keywords': ['设备', '专业技术能力', '履行合同'],
                'aliases': ['设备能力', '技术能力', '人员和设备'],
            },
            {
                'sub_id': 'qualification_no_major_violation',
                'description': '无重大违法记录书面声明（格式自拟）',
                'need_type': 'text_block',
                'keywords': ['无重大违法记录', '经营活动中没有重大违法记录'],
                'aliases': ['无违法记录', '违法记录声明'],
            },
            {
                'sub_id': 'qualification_no_affiliation',
                'description': '单位负责人无控股/管理关系的不同投标人声明',
                'need_type': 'text_block',
                'keywords': ['单位负责人', '控股关系', '管理关系'],
                'aliases': ['控股', '关联关系', '负责人'],
            },
            {
                'sub_id': 'qualification_no_joint_venture',
                'description': '非联合体投标声明',
                'need_type': 'text_block',
                'keywords': ['非联合体投标', '非联合体', '联合体投标', '联合体'],
                'aliases': ['非联合体声明', '不组成联合体'],
            },
        ],
        'priority': 15,
    },
    # ── 业绩 ──
    {
        'category': '业绩',
        'req_id_base': 'performance',
        'primary_kw': ['同类项目业绩', '项目业绩', '投标人业绩', '业绩证明', '合同业绩'],
        'sub_items': [],
        'single_need': {
            'description': '同类项目业绩（需附合同关键页等证明）',
            'need_type': 'image_block',
            # v9.0.2: 移除项目特定硬编码"管理平台""视频监控"，保留通用业绩关键词
            'keywords': ['采购项目', '项目案例', '类似项目', '项目业绩', '业绩案例'],
            'aliases': ['业绩', '项目业绩', '同类业绩', '已完成项目'],
        },
        'priority': 20,
    },
    # ── 报价表 ──
    {
        'category': '报价表',
        'req_id_base': 'quotation',
        'primary_kw': ['报价表', '报价单', '投标报价表', '分项报价表', '价格表', '开标一览表'],
        'sub_items': [],
        'single_need': {
            'description': '报价表/投标报价（从用户资料逐行填入）',
            'need_type': 'text_reference',
            'keywords': ['报价表', '报价单', '投标报价', '分项报价', '价格表', '开标一览'],
            'aliases': ['报价', '投标报价表', '价格清单', '报价明细'],
        },
        'priority': 10,
    },
]


def _collect_heading_paras(doc) -> List[tuple]:
    """收集框架模板中像章节标题的段落 (para_index, text)。

    v9.0.3 改进：
    - 序号正则全部锚定行首，避免 "备注：1、" 这类备注被误判为标题；
    - 排除含句号"。"的整句段落（备注/说明类，非章节标题）；
    - 标题长度上限 30（章节标题通常很短，备注为长句）；
    - v9.0.3: 匹配前清除 Stage 2 注入的锚点 token，避免 token 使 TOC 与正文标题
      文本不同而导致去重失效 / 重复识别（如 proposal_xxx_2）。
    """
    heading_paras = []
    pat = re.compile(r'^[一二三四五六七八九十百]+[、．.]|^第[一二三四五六七八九十]+[章节]|^\d+[、．.]')
    token_re = re.compile(r'\[\[FILL:[^\]]*\]\]')
    for pi, p in enumerate(doc.paragraphs):
        text = token_re.sub('', p.text or '').strip()
        if not text or len(text) > 30:
            continue
        if '。' in text:
            continue
        if pat.search(text):
            heading_paras.append((pi, text))
    return heading_paras


def _dedup_headings_by_text(heading_paras: List[tuple]) -> List[tuple]:
    """同一标题文本只保留最后一次出现（框架文档通常在开头有章节目录/outline，
    outline 在前、真正的模板内容在后，故保留最后一次匹配即模板章节）。"""
    _seen = {}
    for pi, text in heading_paras:
        _seen[re.sub(r'\s+', '', text)] = (pi, text)
    return list(_seen.values())


def detect_fixed_chapters(framework_doc_path: str = '') -> list:
    """
    动态检测模板中的固定类型章节（法定代表人、授权书、偏离表、人员、资质、业绩、报价表等）。

    原理：扫描框架模板的所有段落标题，用 FIXED_CHAPTER_PATTERNS 匹配。
    不硬编码 ch2/ch3/.../ch11，不硬编码 para_index，适配任意章节编号/排列的模板。

    参数:
        framework_doc_path: 框架模板路径

    返回:
        动态生成的 TemplateRequirement 列表
    """
    if not framework_doc_path or not os.path.exists(framework_doc_path):
        return []

    try:
        from docx import Document
        doc = Document(framework_doc_path)
    except Exception as e:
        _logger.info(f"[fixed_chapter_detect] 无法打开框架模板: {e}")
        return []

    # 收集所有看起来像章节标题的段落（v9.0.3：改进识别，排除备注/说明长句）
    heading_paras = _collect_heading_paras(doc)
    heading_paras = _dedup_headings_by_text(heading_paras)  # 去除开头 outline 重复

    if not heading_paras:
        return []

    # 逐个模式匹配，记录已匹配的段落避免重复
    matched_para_indices = set()
    dynamic_requirements = []
    sorted_patterns = sorted(FIXED_CHAPTER_PATTERNS, key=lambda x: x['priority'])

    for pattern in sorted_patterns:
        category = pattern['category']
        req_id_base = pattern['req_id_base']

        for pi, text in heading_paras:
            if pi in matched_para_indices:
                continue

            # 用 primary_kw 精确匹配
            matched = False
            for kw in pattern['primary_kw']:
                if kw in text:
                    matched = True
                    break

            if matched:
                matched_para_indices.add(pi)
                _logger.info(f"[fixed_chapter_detect] ✅ 识别到固定章节: P{pi} 「{text}」 → {category}")

                if pattern.get('sub_items'):
                    # 有子需求：每个子需求生成一个 TemplateRequirement
                    for sub in pattern['sub_items']:
                        sub_id = sub['sub_id']
                        req_id = f"{req_id_base}_{sub_id}"
                        dynamic_requirements.append(TemplateRequirement(
                            req_id=req_id,
                            chapter=text,
                            para_index=0,  # 动态定位
                            description=sub['description'],
                            need_type=sub['need_type'],
                            keywords=sub['keywords'],
                            aliases=sub['aliases'],
                        ))
                else:
                    # 单需求章节
                    single = pattern.get('single_need', {})
                    req_id = req_id_base
                    dynamic_requirements.append(TemplateRequirement(
                        req_id=req_id,
                        chapter=text,
                        para_index=0,
                        description=single.get('description', f'{text}'),
                        need_type=single.get('need_type', 'text_reference'),
                        keywords=single.get('keywords', []),
                        aliases=single.get('aliases', []),
                    ))

    if dynamic_requirements:
        _logger.info(f"[fixed_chapter_detect] 共识别 {len(dynamic_requirements)} 个固定类型需求")
    else:
        _logger.info(f"[fixed_chapter_detect] 未识别到固定类型章节（请检查模板路径和格式）")

    return dynamic_requirements


# ── 向后兼容：运行时动态组装 TEMPLATE_REQUIREMENTS ──
# 在 v7.0 之前是硬编码列表，现在改为 detect_fixed_chapters() + detect_proposal_chapters()
# 的结果在 run_mapping() 中合并。此处保留空列表作为 fallback。
TEMPLATE_REQUIREMENTS = []  # 不再硬编码，由 detect_fixed_chapters() 动态生成

# ── 支撑材料分类关键词（从资料扫描结果中自动筛选） ──
SUPPORTING_MATERIAL_KEYWORDS = {
    '检测报告': ['检测报告', '检验报告', '测试报告', '质检报告', '第三方检测', 'CMA', 'CNAS'],
    '厂家授权书': ['厂家授权', '授权书', '授权函', '厂家授权书', '制造商授权', '原厂授权'],
    '奖项荣誉': ['获奖', '奖项', '荣誉', '荣誉证书', '表彰', '科技进步', '优秀', '示范'],
    '软件著作权': ['软件著作权', '软著', '著作权', '计算机软件', '软件登记', '版权'],
}


# ── 方案类章节关键词模式（动态检测用） ──
# 每个模式定义一类方案章节的匹配规则
# priority: 数值越小优先级越高（避免"技术方案"把"售后服务方案"也吞掉）
PROPOSAL_CHAPTER_PATTERNS = [
    {
        'category': '售后服务方案',
        'primary_kw': ['售后服务方案', '售后服务', '售后方案', '售后保障方案', '售后承诺'],
        'search_kw': ['售后', '质保', '保修', '维护'],
        'priority': 10,
    },
    {
        'category': '培训方案',
        'primary_kw': ['培训方案', '培训计划', '技术培训方案', '人员培训方案'],
        'search_kw': ['培训'],
        'priority': 10,
    },
    {
        'category': '实施方案',
        'primary_kw': ['项目实施方案', '施工方案', '实施方案', '组织方案', '项目组织方案'],
        'search_kw': ['实施', '施工组织'],
        'priority': 20,
    },
    {
        'category': '运维方案',
        'primary_kw': ['运维方案', '运行维护方案', '运维服务方案'],
        'search_kw': ['运维', '运行维护'],
        'priority': 10,
    },
    {
        'category': '服务方案',
        'primary_kw': ['服务方案', '服务保障方案', '技术服务方案'],
        'search_kw': ['服务方案'],
        'priority': 15,
    },
    # "技术方案"优先级最低，作为兜底——它通常也包含实施/售后/培训
    {
        'category': '技术方案',
        'primary_kw': ['技术方案', '项目技术方案', '技术响应方案'],
        'search_kw': ['技术方案'],
        'priority': 50,
    },
]


def detect_proposal_chapters(framework_doc_path: str = '') -> List[TemplateRequirement]:
    """
    动态检测模板中的方案类章节，生成对应的 TemplateRequirement 列表。

    原理：扫描框架模板的所有段落标题，用 PROPOSAL_CHAPTER_PATTERNS 匹配。
    不硬编码 ch8/ch9/ch10，支持任意数量和组合的方案章节。

    参数:
        framework_doc_path: 框架模板路径（可选，用于从文档扫描；不传则返回空列表）

    返回:
        动态生成的 TemplateRequirement 列表
    """
    if not framework_doc_path or not os.path.exists(framework_doc_path):
        return []

    try:
        from docx import Document
        doc = Document(framework_doc_path)
    except Exception as e:
        _logger.info(f"[proposal_detect] 无法打开框架模板: {e}")
        return []

    # 收集所有看起来像章节标题的段落（v9.0.3：改进识别，排除备注/说明长句）
    heading_paras = _collect_heading_paras(doc)
    heading_paras = _dedup_headings_by_text(heading_paras)  # 去除开头 outline 重复

    if not heading_paras:
        return []

    # 逐个模式匹配，记录已匹配的段落避免重复
    matched_para_indices = set()
    dynamic_requirements = []

    # 按 priority 排序（小数字=高优先级，先匹配）
    sorted_patterns = sorted(PROPOSAL_CHAPTER_PATTERNS, key=lambda x: x['priority'])

    for pattern in sorted_patterns:
        category = pattern['category']
        for pi, text in heading_paras:
            if pi in matched_para_indices:
                continue

            # 用 primary_kw 精确匹配
            matched = False
            for kw in pattern['primary_kw']:
                if kw in text:
                    matched = True
                    break

            # 用 search_kw 宽松匹配（但要求标题更短，避免误匹配）
            if not matched:
                for kw in pattern['search_kw']:
                    if kw in text and len(text) < 30:
                        matched = True
                        break

            if matched:
                matched_para_indices.add(pi)
                # 生成安全的 req_id
                safe_id = re.sub(r'[^\w]', '_', category)
                req_id = f'proposal_{safe_id}'
                # 如果同 category 匹配多个，加序号
                existing_ids = [r.req_id for r in dynamic_requirements]
                if req_id in existing_ids:
                    idx = 2
                    while f'proposal_{safe_id}_{idx}' in existing_ids:
                        idx += 1
                    req_id = f'proposal_{safe_id}_{idx}'

                dynamic_requirements.append(TemplateRequirement(
                    req_id=req_id,
                    chapter=text,
                    para_index=0,  # 动态定位
                    description=f'{text}（评分维度驱动，需根据评分办法逐项撰写）',
                    need_type='text_block',
                    keywords=pattern['primary_kw'][:2],
                    aliases=pattern['search_kw'][:3],
                ))
                _logger.info(f"[proposal_detect] ✅ 识别到方案章节: P{pi} 「{text}」 → {req_id}")

    if dynamic_requirements:
        _logger.info(f"[proposal_detect] 共识别 {len(dynamic_requirements)} 个方案类章节")
    else:
        _logger.info(f"[proposal_detect] 未识别到方案类章节")

    return dynamic_requirements


def classify_supporting_materials(material_sections: List[Dict]) -> Dict[str, List[Dict]]:
    """
    从资料扫描结果中自动筛选支撑材料（检测报告/授权书/奖项/软著）。

    不要求用户整理到特定文件夹，通过关键词匹配自动分类。
    返回: {类别: [section_info, ...]}
    """
    result = {}
    for category, keywords in SUPPORTING_MATERIAL_KEYWORDS.items():
        matched = []
        for sec in material_sections:
            heading = sec.get('heading', '')
            text = sec.get('text_content', '') or ''
            source_file = sec.get('source_file', '')

            # 文件名 + 标题 + 内容 三个维度匹配
            search_text = f"{source_file} {heading} {text[:200]}"

            for kw in keywords:
                if kw in search_text:
                    matched.append({
                        'category': category,
                        'source_file': source_file,
                        'source_path': sec.get('source_path', ''),
                        'heading': heading,
                        'section_id': sec.get('section_id'),
                        'match_keyword': kw,
                        'image_count': sec.get('image_count', 0),
                        'images': sec.get('images', []),
                        'text_content': sec.get('text_content', ''),
                    })
                    break
        if matched:
            result[category] = matched
    return result


# ============================================================================
# 匹配引擎
# ============================================================================

def load_material_sections(json_path: str) -> List[Dict]:
    """从扫描JSON加载资料章节数据"""
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    all_sections = []
    for file_data in data.get('files', []):
        for sec in file_data.get('sections', []):
            sec['source_file'] = file_data['file_name']
            sec['source_path'] = file_data['file_path']
            all_sections.append(sec)
    
    return all_sections


# 允许多个模板需求共用同一个资料章节（如身份证复印件）
SHAREABLE_KEYWORDS = ['法定代表人', '身份证', '被授权人', '授权代表', '身份证复印件']


def match_requirement(req: TemplateRequirement, 
                       material_sections: List[Dict],
                       used_sections: set) -> MapResult:
    """
    为单个模板需求匹配资料内容。
    
    匹配规则（优先级从高到低）：
    1. 关键词精确匹配 + 类型校验 + 未使用
    2. 别名匹配 + 类型校验 + 未使用
    3. 关键词包含匹配（资料标题包含模板关键词） + 类型校验
    4. 无匹配
    """
    result = MapResult(
        req_id=req.req_id,
        status='missing',
        fill_strategy='mark_missing',
        chapter=getattr(req, 'chapter', '') or '',
        target_para_index=req.para_index,
        target_token=_make_token(req.req_id),
        slot_type=getattr(req, 'need_type', '') or '',
        target_description=req.description,
        note=''
    )
    
    all_keywords = req.keywords + req.aliases
    if not all_keywords:
        return result
    
    candidates = []
    
    for sec in material_sections:
        sec_id = f"{sec['source_file']}::{sec['section_id']}"
        
        # 判断是否为可共享章节（如身份证复印件可被多章引用）
        is_shareable = any(kw in req.description or kw in str(req.keywords) 
                          for kw in SHAREABLE_KEYWORDS)
        
        if sec_id in used_sections and not is_shareable:
            continue
        
        heading = sec.get('heading', '')
        content_type = sec.get('content_type', '')
        has_images = sec.get('image_count', 0) > 0
        has_text = sec.get('text_content') and len(sec['text_content']) > 10
        
        # 类型校验
        if req.need_type == 'image_block':
            if content_type not in ('image_only', 'mixed'):
                continue
            if not has_images:
                continue
            # 身份证匹配特殊处理：排除业绩截图（>15张图通常是业绩材料）
            if any(kw in str(req.keywords) for kw in ['身份证', '身份证复印件']):
                if sec.get('image_count', 0) > 15:
                    continue  # 排除大批量图片的业绩型章节
        elif req.need_type == 'text_block':
            if content_type not in ('text_only', 'mixed'):
                continue
            if not has_text:
                continue
        elif req.need_type == 'text_reference':
            # 文本参考可以用任何有文本的章节
            if not has_text and not has_images:
                continue
        
        # 计算匹配分数
        score = 0
        match_type = 'none'
        
        # 优先级1: 精确关键词匹配
        for kw in req.keywords:
            if kw in heading:
                score = 100
                match_type = 'exact_keyword'
                break
        
        # 优先级2: 别名匹配
        if score == 0:
            for kw in req.aliases:
                if kw in heading:
                    score = 80
                    match_type = 'alias'
                    break
        
        # 优先级3: 包含匹配
        if score == 0:
            for kw in all_keywords:
                if kw in heading:
                    score = 50
                    match_type = 'contains'
                    break
        
        # 评分加成：优先匹配资格证明材料（核心源文件）
        if score > 0:
            source_file = sec.get('source_file', '')
            # v9.0.1: 移除项目特定硬编码"天宝祥"，只保留通用关键词"资格证明"
            if '资格证明' in source_file or '资质证明' in source_file:
                score += 10
        
        if score > 0:
            candidates.append((score, match_type, sec))
    
    if not candidates:
        result.note = '无匹配资料'
        if req.need_type == 'text_block':
            result.fill_strategy = 'ai_generate'
            result.status = 'missing'
        else:
            result.fill_strategy = 'mark_missing'
            result.status = 'missing'
        return result
    
    # 取最高分
    candidates.sort(key=lambda x: x[0], reverse=True)
    best_score, match_type, best = candidates[0]
    
    # ── 多段匹配扩展：信用类需求跨段收集 ──
    extra_sections = []
    if '信用' in req.description or '信用' in str(req.keywords) or '失信' in str(req.keywords):
        for score2, mt2, sec2 in candidates[1:]:
            sec2_heading = sec2.get('heading', '')
            if any(kw in sec2_heading for kw in ['信用', '失信', '税收违法', '严重失信']):
                extra_sections.append(sec2)
    
    # ── 多段匹配扩展：业绩案例跨段收集 ──
    # v9.0.2: 移除项目特定硬编码"幼儿园"，只保留通用业绩/项目关键词
    if '业绩' in req.description or '采购项目' in str(req.keywords) or '项目案例' in str(req.keywords):
        for score2, mt2, sec2 in candidates[1:]:
            sec2_heading = sec2.get('heading', '')
            # 匹配看起来像项目名称的section（含"采购"、"项目"、"业绩"等通用词）
            if any(kw in sec2_heading for kw in ['采购项目', '项目案例', '类似项目', '业绩案例', '项目业绩']):
                extra_sections.append(sec2)
    
    # 标记所有匹配段为已使用
    sec_id = f"{best['source_file']}::{best['section_id']}"
    used_sections.add(sec_id)
    for extra in extra_sections:
        extra_id = f"{extra['source_file']}::{extra['section_id']}"
        used_sections.add(extra_id)
    
    # 合并图片列表
    merged_image_count = best.get('image_count', 0)
    merged_images = list(best.get('images', []))
    merged_text = best.get('text_content', '') or ''
    # 将最佳匹配的标题也加入文本（对于业绩等需要标题的场景）
    best_heading = best.get('heading', '')
    # v9.0.2: 移除"幼儿园"项目特定硬编码，只保留通用业绩关键词
    if best_heading and ('采购' in best_heading or '项目' in best_heading or '业绩' in best_heading):
        merged_text = best_heading + '\n' + merged_text
    merged_para_start = best.get('para_start', 0)
    merged_para_end = best.get('para_end', 0)
    
    for extra in extra_sections:
        merged_image_count += extra.get('image_count', 0)
        for img in extra.get('images', []):
            if img not in merged_images:
                merged_images.append(img)
        extra_text = extra.get('text_content', '') or ''
        if extra_text:
            merged_text += '\n' + extra_text
        # 对于业绩案例，额外将章节标题添加到文本中
        extra_heading = extra.get('heading', '')
        # v9.0.2: 移除"幼儿园"项目特定硬编码
        if extra_heading and ('采购' in extra_heading or '项目' in extra_heading or '业绩' in extra_heading):
            merged_text += '\n' + extra_heading
        # 合并段落范围：start取最小，end取最大
        merged_para_start = min(merged_para_start, extra.get('para_start', merged_para_start))
        merged_para_end = max(merged_para_end, extra.get('para_end', 0))
    
    # 填充结果
    result.status = 'matched'
    result.source_file = best['source_file']
    result.source_path = best.get('source_path', '')  # 源文件完整路径
    result.source_section_id = best['section_id']
    result.source_heading = best['heading']
    result.source_para_start = merged_para_start
    result.source_para_end = merged_para_end
    result.image_count = merged_image_count
    result.images = merged_images
    result.text_content = merged_text
    
    # 决定 fill_strategy
    if req.need_type == 'image_block':
        result.fill_strategy = 'insert_images'
        result.note = f'从源文件插入 {result.image_count} 张图片'
    elif req.need_type == 'text_block':
        result.fill_strategy = 'copy_text'
        result.note = f'从源文件复制文本（需变量替换）'
    elif req.need_type == 'text_reference':
        if best.get('content_type') in ('text_only', 'mixed'):
            result.fill_strategy = 'extract_and_fill'
            result.note = '从源文件提取信息填入表单'
        else:
            result.fill_strategy = 'insert_images'
            result.note = f'插入身份证复印件 ({result.image_count}张)'
    
    result.note += f' [{match_type}]'
    return result


# ============================================================================
# 方案来源路由（v9.0.3 / 用户协议：State A 资料已有原文→直接复制 / State B 无原文→交互撰写）
# ============================================================================

# 文件名含这些词 → 视为"方案类原文"候选
PROPOSAL_FILE_INCLUDE = ['技术方案', '施工方案', '服务方案', '售后服务', '售后方案',
                         '培训方案', '实施方案', '设计方案', '施工组织', '技术标',
                         '投标方案', '项目方案', '专项方案', '组织设计', '深化设计']
# 文件名含这些词 → 排除（这些是其他类型资料，不是方案章节原文）
PROPOSAL_FILE_EXCLUDE = ['报价', '偏离', '资质', '资格', '身份证', '授权', '彩页',
                         '证书', '营业执照', '信用', '财务', '发票', '清单', '业绩',
                         '合同', '人员', '承诺函', '检测报告']

# 章节标题 → 用于匹配文件名的关键词组（按特异性从高到低排列）
CHAPTER_MATCH_KEYWORDS = {
    '服务方案': ['服务方案', '技术服务', '实施方案', '技术方案', '施工方案', '服务', '实施'],
    '售后服务方案': ['售后服务', '售后方案', '售后', '服务方案'],
    '培训方案': ['培训方案', '培训', '售后培训'],
    '技术方案': ['技术方案', '技术标', '技术'],
    '施工方案': ['施工方案', '施工组织', '实施'],
    '设计方案': ['设计方案', '设计', '深化设计'],
    '投标方案': ['投标方案', '技术方案'],
}
DEFAULT_CHAPTER_KW = ['方案', '技术', '实施', '服务']


def _normalize_chapter_title(title: str) -> str:
    """去掉章节前缀，保留核心名。'八、服务方案' → '服务方案'"""
    t = title or ''
    t = re.sub(r'^[一二三四五六七八九十]+[、.．]', '', t)
    t = re.sub(r'^第[一二三四五六七八九十]+章[、.．\s]*', '', t)
    t = re.sub(r'^[（(][^)）]*[)）]', '', t)
    return t.strip()


def _chapter_match_keywords(title: str) -> List[str]:
    norm = _normalize_chapter_title(title)
    if norm in CHAPTER_MATCH_KEYWORDS:
        return CHAPTER_MATCH_KEYWORDS[norm]
    m = re.search(r'([\u4e00-\u9fa5A-Za-z]+方案)', norm)
    if m:
        core = m.group(1)
        return [core, core.replace('方案', ''), '方案']
    return list(DEFAULT_CHAPTER_KW)


def _derive_proposal_search_dirs(material_sections, material_manifest, explicit_dirs=None):
    """从已扫描资料推断搜索目录（含父目录，捕捉兄弟文件夹里的方案原文）"""
    dirs = set()
    if explicit_dirs:
        for d in explicit_dirs:
            if d and os.path.isdir(d):
                dirs.add(os.path.abspath(d))
    for sec in (material_sections or []):
        sp = sec.get('source_path') or sec.get('source_file')
        if sp:
            d = os.path.dirname(os.path.abspath(sp))
            dirs.add(d)
            parent = os.path.dirname(d)
            if parent:
                dirs.add(parent)
    if material_manifest:
        for p in material_manifest.values():
            if p and os.path.exists(p):
                dirs.add(os.path.dirname(os.path.abspath(p)))
                up = os.path.dirname(os.path.dirname(os.path.abspath(p)))
                if up:
                    dirs.add(up)
    return list(dirs)


def find_proposal_source_docs(search_dirs):
    """扫描目录（含一层子目录），返回方案类原文文件候选列表 [{path, name}]"""
    candidates = []
    seen = set()
    seen_name = set()
    for d in (search_dirs or []):
        if not os.path.isdir(d):
            continue
        scan_dirs = [d] + [os.path.join(d, s) for s in os.listdir(d)
                           if os.path.isdir(os.path.join(d, s)) and not s.startswith('.')]
        for sd in scan_dirs:
            try:
                files = os.listdir(sd)
            except Exception:
                continue
            for fn in files:
                low = fn.lower()
                if not (low.endswith('.doc') or low.endswith('.docx')
                        or low.endswith('.pdf') or low.endswith('.wps')):
                    continue
                if any(ex in fn for ex in PROPOSAL_FILE_EXCLUDE):
                    continue
                if not any(inc in fn for inc in PROPOSAL_FILE_INCLUDE):
                    if '方案' not in fn:
                        continue
                full = os.path.abspath(os.path.join(sd, fn))
                if full in seen or fn in seen_name:
                    continue
                seen.add(full)
                seen_name.add(fn)
                candidates.append({'path': full, 'name': fn})
    return candidates


def match_proposal_to_source(chapter_title, candidates):
    """为方案章节匹配最佳来源文件。返回 (best_path, confidence, all_candidate_paths)"""
    kws = _chapter_match_keywords(chapter_title)
    best_path = None
    best_score = 0
    for cand in candidates:
        name = cand['name']
        score = 0
        for i, kw in enumerate(kws):
            if kw and kw in name:
                score = max(score, max(0, 100 - i * 25))
        if score > best_score:
            best_score = score
            best_path = cand['path']
    return best_path, best_score, [c['path'] for c in candidates]


def run_mapping(scan_json_path: str,
                framework_doc_path: str = '',
                material_manifest: Dict[str, str] = None,
                proposal_source_dirs: List[str] = None) -> List[MapResult]:
    """
    执行全量需求映射。
    
    参数:
        scan_json_path: 资料深度扫描JSON路径
        framework_doc_path: 框架模板路径（用于动态检测方案类章节）
        material_manifest: 用户提供的资料清单 {资料类型: 文件路径}
            例: {'检测报告': '附件/检测报告.docx', '法人身份证': '资料/法人身份证.jpg'}
    
    返回:
        List[MapResult]: 每个需求位置的映射结果
    """
    material_sections = load_material_sections(scan_json_path)
    
    # ── 如果用户提供了 material_manifest，将其条目作为额外资料注入 ──
    if material_manifest:
        manifest_sections = _build_manifest_sections(material_manifest)
        if manifest_sections:
            _logger.info(f"[material_manifest] 用户指定了 {len(manifest_sections)} 项资料位置")
            material_sections = manifest_sections + material_sections
    
    used_sections = set()
    results = []
    
    # 基础需求（非方案类）—— 运行时动态检测固定类型章节
    fixed_requirements = detect_fixed_chapters(framework_doc_path)
    for req in fixed_requirements:
        result = match_requirement(req, material_sections, used_sections)
        results.append(result)
    
    # 动态方案类章节
    dynamic_proposals = detect_proposal_chapters(framework_doc_path)
    for req in dynamic_proposals:
        result = match_requirement(req, material_sections, used_sections)
        results.append(result)

    # ── 方案来源路由（v9.0.3）：为每个方案章节标注资料来源，决定 State A / State B ──
    prop_results = [r for r in results if r.req_id.startswith('proposal_')]
    if prop_results:
        search_dirs = _derive_proposal_search_dirs(material_sections, material_manifest, proposal_source_dirs)
        candidates = find_proposal_source_docs(search_dirs)
        if candidates:
            _logger.info(f"[proposal_route] 资料中发现 {len(candidates)} 份方案类原文: "
                         + " | ".join(c['name'] for c in candidates))
        else:
            _logger.info("[proposal_route] 资料中未发现任何方案类原文文件")
        for r in prop_results:
            best, conf, all_c = match_proposal_to_source(r.chapter, candidates)
            r.proposal_candidates = all_c
            r.proposal_confidence = conf
            if best:
                r.source_doc = best
                r.fill_strategy = 'copy_text'      # State A：直接复制资料原文
                r.status = 'matched'
                tag = '高置信' if conf >= 80 else ('中置信' if conf >= 40 else '低置信')
                r.note = (f'资料已有方案原文(State A)，来源: {os.path.basename(best)}'
                          f'（{tag}，置信{conf}）')
                _logger.info(f"[proposal_route] {r.req_id} → {os.path.basename(best)} (conf={conf})")
            else:
                r.needs_write = True               # State B：资料无原文，延后交互撰写
                r.fill_strategy = 'ai_generate'
                r.status = 'missing'
                if candidates:
                    r.note = '发现方案文件但无法确定对应关系，请于 Stage 3.5 指定(State B)'
                else:
                    r.note = '资料中未找到方案原文(State B)，待 Stage 5 交互撰写'
                _logger.info(f"[proposal_route] {r.req_id} → 未匹配来源，标记 needs_write")

    return results


def _build_manifest_sections(material_manifest: Dict[str, str]) -> List[Dict]:
    """
    将用户提供的 material_manifest 转换为 material_sections 格式，
    使其能被 match_requirement() 匹配。

    manifest 格式: {'检测报告': '/path/to/检测报告.docx', '法人身份证': '/path/xxx.jpg'}
    输出格式: 与 material_deep_scanner.py 的 section 格式兼容
    """
    sections = []
    for material_type, file_path in material_manifest.items():
        if not file_path or not os.path.exists(file_path):
            _logger.warning(f"[material_manifest] ⚠️ 文件不存在: {material_type} → {file_path}")
            continue

        file_name = os.path.basename(file_path)
        file_ext = os.path.splitext(file_name)[1].lower()

        # 判断内容类型
        has_images = file_ext in ('.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff')
        has_text = file_ext in ('.docx', '.pdf', '.xlsx', '.doc')

        if has_images:
            content_type = 'image_only'
        elif has_text:
            content_type = 'text_only'
        else:
            content_type = 'text_only'

        section = {
            'section_id': f'manifest_{material_type}',
            'heading': material_type,
            'source_file': file_name,
            'source_path': file_path,
            'content_type': content_type,
            'text_content': f'【用户指定】{material_type}，位于 {file_name}',
            'image_count': 1 if has_images else 0,
            'images': [file_path] if has_images else [],
            'para_start': 0,
            'para_end': 0,
            '_from_manifest': True,  # 标记来源
        }
        sections.append(section)
        _logger.info(f"[material_manifest] ✅ {material_type} → {file_name}")

    return sections


# ============================================================================
# 生成映射报告 (.md)
# ============================================================================

def generate_markdown_report(results: List[MapResult], output_path: str,
                             supporting_materials: Dict[str, List[Dict]] = None,
                             project_name: str = ""):
    """生成 Markdown 格式的需求映射报告
    
    v9.0.1: 增加 project_name 参数，替代硬编码的"梦桃小学"。
    """
    # 按章节分组（动态，不硬编码章节号）
    chapter_map = {}
    # 非 proposal 类需求用 req_id 前缀推断章节名
    req_map = {
        'ch2': '第二章 法定代表人身份证明',
        'ch3': '第三章 法定代表人授权委托书',
        'ch4': '第四章 商务条款偏离表',
        'ch5': '第五章 技术参数条款偏离表',
        'ch6': '第六章 本项目拟投入人员',
        'ch7': '第七章 资质证明文件',
        'ch11': '第十一章 业绩',
    }
    
    for r in results:
        # proposal_ 开头的是动态方案章节
        if r.req_id.startswith('proposal_'):
            ch_name = r.chapter  # 直接用检测到的章节标题
        else:
            ch_key = r.req_id[:3]
            ch_name = req_map.get(ch_key, ch_key)
        if ch_name not in chapter_map:
            chapter_map[ch_name] = []
        chapter_map[ch_name].append(r)
    
    # 统计
    total = len(results)
    matched = sum(1 for r in results if r.status == 'matched')
    missing = sum(1 for r in results if r.status == 'missing')
    insert_image = sum(1 for r in results if r.fill_strategy == 'insert_images')
    copy_text = sum(1 for r in results if r.fill_strategy == 'copy_text')
    ai_gen = sum(1 for r in results if r.fill_strategy == 'ai_generate')
    mark_missing = sum(1 for r in results if r.fill_strategy == 'mark_missing')
    extract_fill = sum(1 for r in results if r.fill_strategy == 'extract_and_fill')
    
    lines = []
    # v9.0.1: 使用项目名称参数，替代硬编码"梦桃小学"
    display_name = project_name or "投标文件"
    lines.append(f'# {display_name}投标文件 — 资料扫描与需求映射报告')
    lines.append('')
    from datetime import datetime as _dt
    lines.append(f'> 生成时间: {_dt.now().strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append(f'> 资料文件: 用户提供的资料文件夹 + 可选的资格证明材料')
    lines.append('')
    
    # 总览
    lines.append('## 一、填充总览')
    lines.append('')
    lines.append(f'| 统计项 | 数量 |')
    lines.append(f'|--------|------|')
    lines.append(f'| 模板需求位总数 | {total} |')
    lines.append(f'| ✅ 可匹配填充 | {matched} |')
    lines.append(f'| ❌ 缺失 | {missing} |')
    lines.append('')
    lines.append(f'| 填充策略 | 数量 |')
    lines.append(f'|----------|------|')
    lines.append(f'| 🖼️ 插入图片 | {insert_image} |')
    lines.append(f'| 📝 复制文本 | {copy_text} |')
    lines.append(f'| 📋 提取填表 | {extract_fill} |')
    lines.append(f'| 🤖 AI生成 | {ai_gen} |')
    lines.append(f'| ⚠️ 标黄缺失 | {mark_missing} |')
    lines.append('')
    
    # 各章明细（动态章节列表）
    chapter_num = 2
    # 固定章节 + 动态方案章节（方案章节排在最后）
    fixed_chapters = ['第二章 法定代表人身份证明', '第三章 法定代表人授权委托书',
                      '第六章 本项目拟投入人员', '第七章 资质证明文件',
                      '第十一章 业绩']
    # 收集动态方案章节名
    proposal_chapters = [name for name in chapter_map.keys()
                         if name not in fixed_chapters and not name.startswith('第')]
    all_chapter_order = fixed_chapters + proposal_chapters

    for ch_name in all_chapter_order:
        if ch_name not in chapter_map:
            continue
        
        lines.append(f'## {chapter_num}、{ch_name}需求映射明细')
        chapter_num += 1
        lines.append('')
        lines.append('| 模板需求 | 资料匹配 | 处理方式 | 来源/说明 |')
        lines.append('|----------|----------|----------|-----------|')
        
        for r in chapter_map[ch_name]:
            # 动态获取描述
            desc = r.target_description if r.target_description else r.req_id

            # 方案章节：按来源路由特殊渲染
            if r.req_id.startswith('proposal_'):
                if r.source_doc:
                    strategy = '📄 复制方案原文(State A)'
                    src = os.path.basename(r.source_doc) + f'（置信{r.proposal_confidence}）'
                    lines.append(f'| {desc} | ✅ | {strategy} | {src} |')
                else:
                    strategy = '🤖 AI生成(State B)'
                    lines.append(f'| {desc} | ❌ | {strategy} | {r.note} |')
                continue

            if r.status == 'matched':
                match_info = f'✅ {r.source_heading[:25]}'
                
                if r.fill_strategy == 'insert_images':
                    strategy = f'🖼️ 插入图片({r.image_count}张)'
                    source = f'{r.source_file} §{r.source_section_id}'
                elif r.fill_strategy == 'copy_text':
                    strategy = f'📝 复制文本'
                    text_len = len(r.text_content) if r.text_content else 0
                    source = f'{r.source_file} §{r.source_section_id} ({text_len}字)'
                elif r.fill_strategy == 'extract_and_fill':
                    strategy = '📋 提取填表'
                    source = f'{r.source_file} §{r.source_section_id}'
                else:
                    strategy = f'✅ {r.fill_strategy}'
                    source = r.note
            else:
                match_info = '❌ 无匹配'
                if r.fill_strategy == 'ai_generate':
                    strategy = '🤖 AI生成'
                    source = '需大模型生成模板文本'
                else:
                    strategy = '⚠️ 标黄缺失'
                    source = '待用户手动补充'
            
            lines.append(f'| {desc} | {match_info} | {strategy} | {source} |')
        
        lines.append('')
    
    # 缺失项汇总
    lines.append('## 四、缺失项汇总')
    lines.append('')
    
    missing_items = [r for r in results if r.status == 'missing']
    if missing_items:
        lines.append('| 模板位置 | 缺失内容 | 建议处理 |')
        lines.append('|----------|----------|----------|')
        for r in missing_items:
            suggestion = 'AI生成模板文本' if r.fill_strategy == 'ai_generate' else '标黄，待用户补充'
            desc = r.target_description if r.target_description else r.req_id
            lines.append(f'| {r.req_id} | {desc} | {suggestion} |')
    else:
        lines.append('> 🎉 无缺失项，所有需求均已匹配！')
    
    lines.append('')
    
    # ── 支撑材料清单（从资料中自动筛选） ──
    lines.append('## 五、可用支撑材料清单（方案撰写参考）')
    lines.append('')
    # v9.0.1: 不硬编码章节号，改为通用描述
    lines.append('> 以下材料从用户资料中自动识别，用于方案章节撰写时引用。')
    lines.append('> AI撰写方案时，应根据内容相关性将对应材料插入到方案适当位置。')
    lines.append('')
    
    if supporting_materials:
        for category, items in supporting_materials.items():
            lines.append(f'### {category}（{len(items)}项）')
            lines.append('')
            for item in items:
                src = item.get('source_file', '')
                heading = item.get('heading', '')[:40]
                img_count = item.get('image_count', 0)
                has_img = f'，含{img_count}张图片' if img_count > 0 else ''
                from_manifest = '（用户指定）' if item.get('_from_manifest') else ''
                lines.append(f'- {heading} — 来源: {src}{has_img}{from_manifest}')
            lines.append('')
    else:
        lines.append('> 未在用户资料中识别到支撑材料（检测报告/授权书/奖项/软著）。')
        lines.append('> 如有此类材料，请确保文件名或内容中包含对应关键词。')
        lines.append('')
    
    # ── 方案来源路由（Stage 5 依据） ──
    lines.append('## 六、方案来源路由（State A 直接复制 / State B 交互撰写）')
    lines.append('')
    prop_list = [r for r in results if r.req_id.startswith('proposal_')]
    if prop_list:
        lines.append('> 协议：资料已有方案原文 → 直接复制(State A)；资料无 → 延后交互撰写(State B)。')
        lines.append('')
        lines.append('| 方案章节 | 路由状态 | 匹配来源 | 置信度 | 资料中全部候选方案文件 |')
        lines.append('|----------|----------|----------|--------|----------------------|')
        for r in prop_list:
            if r.source_doc:
                state = 'State A（复制原文）'
                src = os.path.basename(r.source_doc)
                conf = str(r.proposal_confidence)
            else:
                state = 'State B（交互撰写）'
                src = '—'
                conf = '0'
            cands = '；'.join(os.path.basename(c) for c in r.proposal_candidates) or '（无）'
            lines.append(f'| {r.chapter} | {state} | {src} | {conf} | {cands} |')
        lines.append('')
        lines.append('> 若「匹配来源」不准确或置信度低，请于 Stage 3.5 指定每个方案章节对应的资料原文文件。')
    else:
        lines.append('> 未识别到方案类章节。')
    lines.append('')

    # 写入文件
    content = '\n'.join(lines)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    _logger.info(f"[requirement_mapper] 映射报告已生成: {output_path}")
    return content


def save_mapping_json(results: List[MapResult], output_path: str,
                      supporting_materials: Dict[str, List[Dict]] = None):
    """保存映射结果为JSON（供 (已删除的V9引擎) 驱动填充）"""
    data = {
        'total': len(results),
        'matched': sum(1 for r in results if r.status == 'matched'),
        'missing': sum(1 for r in results if r.status == 'missing'),
        'supporting_materials': supporting_materials or {},
        'results': []
    }
    
    for r in results:
        data['results'].append({
            'req_id': r.req_id,
            'status': r.status,
            'fill_strategy': r.fill_strategy,
            'target_para_index': r.target_para_index,
            'target_token': r.target_token,
            'slot_type': r.slot_type,
            'target_description': r.target_description,
            'source_file': r.source_file,
            'source_path': r.source_path,
            'source_section_id': r.source_section_id,
            'source_heading': r.source_heading,
            'source_para_start': r.source_para_start,
            'source_para_end': r.source_para_end,
            'image_count': r.image_count,
            'images': r.images,
            'text_content': r.text_content,
            'text_length': len(r.text_content) if r.text_content else 0,
            'note': r.note,
            'source_doc': r.source_doc,
            'needs_write': r.needs_write,
            'proposal_candidates': r.proposal_candidates,
            'proposal_confidence': r.proposal_confidence,
        })
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    _logger.info(f"[requirement_mapper] 映射JSON已保存: {output_path}")


# ============================================================================
# CLI 入口
# ============================================================================

if __name__ == '__main__':
    import sys
    import argparse
    sys.stdout.reconfigure(encoding='utf-8')
    
    parser = argparse.ArgumentParser(description='需求映射引擎')
    parser.add_argument('--project-name', required=True, help='项目名称')
    parser.add_argument('--framework', default='', help='框架模板路径（用于动态识别方案类章节）')
    parser.add_argument('--material-manifest', default='', help='用户资料清单JSON字符串，如 \'{"检测报告": "/path/to/xxx.docx"}\'')
    parser.add_argument('--proposal-source-dirs', default='', help='方案原文搜索目录（逗号分隔，可选；不传则自动从资料目录推断含父目录）')
    parser.add_argument('--no-report', action='store_true',
                        help='废除 prose 需求报告，仅输出映射 JSON（作为 FILL Plan 数据源）')
    args = parser.parse_args()
    
    # 自动查找扫描JSON
    scan_json = f'{args.project_name}_资料深度扫描.json'
    output_md = f'{args.project_name}_需求映射报告.md'
    output_json = f'{args.project_name}_需求映射数据.json'
    
    # 解析 material_manifest
    material_manifest = None
    if args.material_manifest:
        try:
            material_manifest = json.loads(args.material_manifest)
        except json.JSONDecodeError as e:
            _logger.error(f"[ERROR] material_manifest JSON 解析失败: {e}")
            sys.exit(1)
    
    _logger.info("=" * 60)
    _logger.info("需求映射引擎 v7.0")
    _logger.info("=" * 60)
    
    prop_dirs = [d.strip() for d in args.proposal_source_dirs.split(',') if d.strip()] or None
    results = run_mapping(scan_json,
                          framework_doc_path=args.framework,
                          material_manifest=material_manifest,
                          proposal_source_dirs=prop_dirs)
    
    # 支撑材料分类
    material_sections = load_material_sections(scan_json)
    # 也把 manifest 的资料加入分类
    if material_manifest:
        manifest_secs = _build_manifest_sections(material_manifest)
        material_sections = manifest_secs + material_sections
    supporting = classify_supporting_materials(material_sections)
    if supporting:
        total_items = sum(len(v) for v in supporting.values())
        _logger.info(f"\n[支撑材料] 识别到 {total_items} 项支撑材料:")
        for cat, items in supporting.items():
            _logger.info(f"  {cat}: {len(items)}项")
    else:
        _logger.info(f"\n[支撑材料] 未识别到支撑材料")
    
    # 打印结果
    for r in results:
        icon = '✅' if r.status == 'matched' else '❌'
        _logger.info(f"  {icon} [{r.req_id:30s}] {r.fill_strategy:15s} | {r.note}")
    
    # 生成MD报告（v9.0.1: 传入 project_name 替代硬编码）
    # 2026-07-12 起：prose 需求报告废除，默认不再生成；仅保留映射 JSON（作为 FILL Plan 数据源）
    if not getattr(args, 'no_report', False):
        generate_markdown_report(results, output_md, supporting_materials=supporting,
                                 project_name=args.project_name)
    else:
        _logger.info('[需求报告] --no-report 已启用，跳过 prose 报告生成（仅输出映射 JSON）')
    
    # 保存JSON（供填充引擎驱动，含支撑材料数据）
    save_mapping_json(results, output_json, supporting_materials=supporting)
    
    # 统计
    matched = sum(1 for r in results if r.status == 'matched')
    proposal_count = sum(1 for r in results if r.req_id.startswith('proposal_'))
    _logger.info(f"\n总计: {len(results)}个需求, {matched}个已匹配, {len(results)-matched}个缺失")
    if proposal_count > 0:
        _logger.info(f"方案类章节: {proposal_count}个（动态识别）")
