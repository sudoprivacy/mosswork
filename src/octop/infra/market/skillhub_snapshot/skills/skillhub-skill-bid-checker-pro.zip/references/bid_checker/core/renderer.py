# -*- coding: utf-8 -*-
"""
renderer.py — 渲染 + 视觉闭环（让 AI 真正「看见」格式对不对）
=========================================================================

为什么需要它（用户 2026-07-12 拍板）：
  python-docx 给的是「结构」，不是「长什么样」。不看渲染，AI 对格式对错的判断是盲的。
  本模块把 docx -> PDF -> PNG，让 AI 用视觉核对产物，把「未知格式问题」暴露出来，
  再归约成 image_format.py / format_guardrails.py 的新原语。

渲染器优先级（自动探测，无需用户手动装）：
  1. Microsoft Word COM（win32com）—— 本机已装 Office 时首选，零安装。
  2. LibreOffice / soffice —— 未装 Word 时的免费备选。
  3. 都没有 -> 抛清晰可执行的错误，并给出安装命令（winget install LibreOffice）。

依赖：
  - docx->pdf：win32com（Windows/Office）或 soffice
  - pdf->png：PyMuPDF（fitz，已验证 1.28.0 可用）
"""
import os
import sys
import subprocess
import shutil

try:
    import fitz  # PyMuPDF
    _HAVE_FITZ = True
except Exception:
    _HAVE_FITZ = False


def _detect_word():
    try:
        import win32com.client as wc
        w = wc.Dispatch('Word.Application')
        w.Quit()
        return True
    except Exception:
        return False


def _detect_soffice():
    # PATH 中查找
    import shutil
    p = shutil.which('soffice') or shutil.which('libreoffice')
    if p:
        return p
    # 常见安装位置
    for cand in (
        r'C:\Program Files\LibreOffice\program\soffice.exe',
        r'C:\Program Files (x86)\LibreOffice\program\soffice.exe',
    ):
        if os.path.exists(cand):
            return cand
    return None


def detect_renderer():
    """返回 ('word'|'libreoffice'|None, path_or_None)。"""
    if _detect_word():
        return 'word', None
    so = _detect_soffice()
    if so:
        return 'libreoffice', so
    return None, None


def docx_to_pdf(docx_path, pdf_path=None):
    """docx -> pdf。返回 pdf 路径。自动选渲染器。"""
    docx_path = os.path.abspath(docx_path)
    if pdf_path is None:
        pdf_path = os.path.splitext(docx_path)[0] + '.pdf'
    pdf_path = os.path.abspath(pdf_path)

    kind, path = detect_renderer()
    if kind == 'word':
        return _docx_to_pdf_word(docx_path, pdf_path)
    elif kind == 'libreoffice':
        return _docx_to_pdf_soffice(docx_path, pdf_path, path)
    else:
        raise RuntimeError(
            '未找到可用渲染器。请二选一安装：\n'
            '  (A) 安装 Microsoft Office（已含 Word）\n'
            '  (B) 命令行执行：winget install --id TheDocumentFoundation.LibreOffice -e --source winget\n'
            '安装后重新运行即可。'
        )


def _docx_to_pdf_word(docx_path, pdf_path):
    import win32com.client as wc
    # 使用 DispatchEx 避免复用已有 Word 实例的 COM 代理失效问题
    w = wc.DispatchEx('Word.Application')
    w.Visible = False
    w.DisplayAlerts = 0  # wdAlertsNone — 禁止弹窗阻塞
    doc = w.Documents.Open(FileName=os.path.abspath(docx_path), ConfirmConversions=False, ReadOnly=True)
    # SaveAs2 到临时目录再移至目标路径（绕过 Word COM 对某些网络/非标准路径的写入限制）
    import tempfile
    tmp_dir = tempfile.gettempdir()
    tmp_pdf = os.path.join(tmp_dir, '_bidchecker_tmp_preview.pdf')
    doc.SaveAs2(tmp_pdf, FileFormat=17)  # 17 = wdFormatPDF
    doc.Close()
    try:
        w.Quit()
    except Exception:
        pass
    # 移至目标路径
    os.makedirs(os.path.dirname(os.path.abspath(pdf_path)), exist_ok=True)
    shutil.copy2(tmp_pdf, os.path.abspath(pdf_path))
    try:
        os.remove(tmp_pdf)
    except Exception:
        pass
    return os.path.abspath(pdf_path)


def _docx_to_pdf_soffice(docx_path, pdf_path, soffice):
    out_dir = os.path.dirname(pdf_path)
    cmd = [soffice, '--headless', '--convert-to', 'pdf', '--outdir', out_dir, docx_path]
    subprocess.run(cmd, check=True, capture_output=True, timeout=180)
    # soffice 输出名 = 同名.pdf
    guessed = os.path.join(out_dir, os.path.splitext(os.path.basename(docx_path))[0] + '.pdf')
    if guessed != pdf_path and os.path.exists(guessed):
        os.replace(guessed, pdf_path)
    return pdf_path


def pdf_to_pngs(pdf_path, out_dir, pages=None, dpi=110):
    """pdf -> 指定页 PNG。pages=None 表示全部。返回 png 路径列表（按页序）。"""
    if not _HAVE_FITZ:
        raise RuntimeError('缺少 PyMuPDF（pip install pymupdf）。')
    os.makedirs(out_dir, exist_ok=True)
    doc = fitz.open(pdf_path)
    total = doc.page_count
    if pages is None:
        pages = list(range(total))
    else:
        pages = [p for p in pages if 0 <= p < total]
    out = []
    for i in pages:
        pg = doc.load_page(i)
        pix = pg.get_pixmap(dpi=dpi)
        png = os.path.join(out_dir, 'page_%03d.png' % (i + 1))
        pix.save(png)
        out.append(png)
    doc.close()
    return out


def render_docx_pages(docx_path, pages=None, work_dir=None, dpi=110):
    """一站式：docx -> pdf -> 指定页 png。返回 png 路径列表。
    用于「视觉闭环」：AI 读这些 png 即可核对格式。"""
    docx_path = os.path.abspath(docx_path)
    if work_dir is None:
        work_dir = os.path.join(os.path.dirname(docx_path), '_render_preview')
    os.makedirs(work_dir, exist_ok=True)
    pdf = docx_to_pdf(docx_path, os.path.join(work_dir, 'preview.pdf'))
    return pdf_to_pngs(pdf, work_dir, pages=pages, dpi=dpi)


if __name__ == '__main__':
    here = sys.argv[1] if len(sys.argv) > 1 else '.'
    docx = sys.argv[2] if len(sys.argv) > 2 else '投标文件_filled.docx'
    pages = None
    if len(sys.argv) > 3:
        pages = [int(x) for x in sys.argv[3].split(',')]
    target = os.path.join(here, docx)
    kind, _ = detect_renderer()
    print('渲染器:', kind)
    pngs = render_docx_pages(target, pages=pages)
    print('生成 %d 张预览 PNG:' % len(pngs))
    for p in pngs:
        print('  ', p)
