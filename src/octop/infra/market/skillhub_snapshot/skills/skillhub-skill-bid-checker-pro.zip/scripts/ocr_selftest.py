#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OCR 引擎自检脚本 (v11, 无 API)
=====================

检查本地 RapidOCR 引擎是否可用，定位调用失败的原因。
本技能不再使用任何云端 OCR API，OCR 完全在本地运行（基于 ONNX Runtime），无需 API 密钥。

用法：
    python scripts/ocr_selftest.py                # 自检并输出诊断报告
    python scripts/ocr_selftest.py --image x.jpg  # 自检 + 实测一张图片

退出码：
    0 = RapidOCR 后端可用
    1 = RapidOCR 不可用（Stage 5 将降级为规则/关键词兜底）
"""

import os
import sys
import tempfile
from pathlib import Path

# 加入项目根目录到 sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.ocr_selftest")
except ImportError:
    import logging
    _logger = logging.getLogger("ocr_selftest")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stdout)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)


def check_rapid_backend():
    """测试 RapidOCR 后端是否能初始化"""
    print("\n" + "=" * 60)
    print("【1/2】RapidOCR 本地引擎初始化测试")
    print("=" * 60)

    # v11: RapidOCR 是唯一后端，无需任何 API 密钥
    try:
        import rapidocr_onnxruntime
        print(f"  ✓ rapidocr-onnxruntime 包已安装 "
              f"(版本: {getattr(rapidocr_onnxruntime, '__version__', '未知')})")
    except ImportError:
        print(f"  ✗ rapidocr-onnxruntime 包未安装")
        print(f"    安装命令: pip install rapidocr-onnxruntime onnxruntime")
        return None

    # onnxruntime 是必需依赖
    try:
        import onnxruntime
        print(f"  ✓ onnxruntime 包已安装 (版本: {getattr(onnxruntime, '__version__', '未知')})")
    except ImportError:
        print(f"  ✗ onnxruntime 包未安装")
        print(f"    安装命令: pip install onnxruntime")
        return None

    # 直接尝试创建实例，避免误判
    try:
        from bid_checker.core.ocr_engine import RapidOCRBackend
        print(f"  → 正在初始化 RapidOCR（首次会下载 ONNX 模型，请耐心等待）...")
        engine = RapidOCRBackend()
        # _engine 不为 None 才算真正可用
        if engine._engine is not None:
            print(f"  ✓ RapidOCR 引擎初始化成功")
            # 用空白图验证推理真的能跑
            try:
                from PIL import Image
                tmp = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
                Image.new('RGB', (100, 50), 'white').save(tmp.name)
                test_texts = engine.recognize_general(tmp.name)
                os.unlink(tmp.name)
                if test_texts == "" or test_texts is None:
                    print(f"  ✓ RapidOCR 推理测试通过（空白图正确返回空）")
                else:
                    print(f"  ✓ RapidOCR 推理测试通过")
            except Exception as e_test:
                print(f"  - RapidOCR 推理测试失败: {e_test}")
            return engine
        else:
            print(f"  ✗ RapidOCR 引擎初始化失败（_engine 为 None，可能模型无法下载）")
            return None
    except Exception as e:
        print(f"  ✗ RapidOCR 初始化异常: {type(e).__name__}: {e}")
        return None


def check_factory(config_path=None):
    """测试工厂函数 create_ocr_engine"""
    print("\n" + "=" * 60)
    print("【2/2】工厂函数 create_ocr_engine 测试")
    print("=" * 60)

    try:
        from bid_checker.core.ocr_engine import create_ocr_engine
        engine = create_ocr_engine(config_path or "config.json", verbose=False)
        if engine is not None:
            print(f"  ✓ 工厂函数返回引擎: {engine.backend_name}")
            return engine
        else:
            print(f"  ✗ 工厂函数返回 None（RapidOCR 不可用）")
            return None
    except Exception as e:
        print(f"  ✗ 工厂函数异常: {type(e).__name__}: {e}")
        return None


def test_image_recognition(engine, image_path):
    """用真实图片测试引擎识别能力"""
    print("\n" + "=" * 60)
    print(f"【实测】用图片 {image_path} 测试识别能力")
    print("=" * 60)

    if not os.path.exists(image_path):
        print(f"  ✗ 图片不存在: {image_path}")
        return

    print(f"  → 后端: {engine.backend_name}")
    try:
        result = engine.smart_recognize(image_path)
        if result:
            print(f"  ✓ 识别成功！")
            for k, v in result.items():
                if k != '识别类型':
                    if isinstance(v, list):
                        v = ' | '.join(str(x) for x in v[:5])
                        if len(result[k]) > 5:
                            v += f" ... (共{len(result[k])}项)"
                    print(f"    {k}: {v}")
        else:
            print(f"  ✗ 识别失败（返回 None）")
    except Exception as e:
        print(f"  ✗ 识别异常: {type(e).__name__}: {e}")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="OCR 引擎自检 v11 (无 API)")
    parser.add_argument("--image", help="测试图片路径（可选）")
    parser.add_argument("--config", help="config.json 路径（默认自动搜索）")
    args = parser.parse_args()

    print("=" * 60)
    print("  OCR 引擎自检 v11 — 本地 RapidOCR（无 API）")
    print("=" * 60)
    print(f"项目根目录: {PROJECT_ROOT}")
    print(f"Python: {sys.executable}")

    # 1. RapidOCR 后端测试
    rapid_engine = check_rapid_backend()

    # 2. 工厂函数测试
    factory_engine = check_factory(args.config)

    # 实测图片
    if args.image and factory_engine:
        test_image_recognition(factory_engine, args.image)
    elif args.image and rapid_engine:
        test_image_recognition(rapid_engine, args.image)

    # 总结
    print("\n" + "=" * 60)
    print("  自检总结")
    print("=" * 60)

    if rapid_engine is not None:
        print(f"  ✓ 可用后端: RapidOCR（本地，无需 API 密钥）")
        print(f"  ✓ OCR 功能可用")
        return 0
    else:
        print(f"  ✗ RapidOCR 不可用")
        print(f"  ")
        print(f"  解决方案：")
        print(f"    A. 安装 RapidOCR（本地免费，无需注册/密钥）：")
        print(f"       pip install rapidocr-onnxruntime onnxruntime")
        print(f"    ")
        print(f"    B. 不安装也能运行：Stage 5 资质图片 OCR 比对将自动降级为")
        print(f"       规则/关键词兜底，并在报告中标注，不会整段跳过。")
        return 1


if __name__ == "__main__":
    sys.exit(main())
