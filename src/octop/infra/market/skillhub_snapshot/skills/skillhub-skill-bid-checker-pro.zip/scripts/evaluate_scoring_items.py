#!/usr/bin/env python3
"""
Stage 4: 评分项响应质量评估

对评分表中的每个评分项，通过"评分项驱动精读"策略评估标书响应质量。

输入：
  --scoring-table: 评分表 JSON
  --chapter-index: 标书章节索引 JSON
  --chapter-summaries: 标书章节摘要 JSON
  --keyword-index: 关键词索引 JSON

输出：{项目名}_评分预估Plan.json

策略（每评分项独立执行）：
  Step 4-1: 摘要粗筛 → top-10 相关章节
  Step 4-2: 关键词精筛 → top-3 章节
  Step 4-3: 精读评估 → LLM 调用
  Step 4-4: 客观分项特殊处理 → 标记 OCR 检查
"""
import argparse
import json
import re
import subprocess
import sys
import time
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any, Optional
from datetime import datetime
from collections import defaultdict

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger

_logger = get_logger('evaluate_scoring_items')


@dataclass
class DeductionReason:
    sub_criteria: str
    max_score: float
    deducted_score: float
    reason: str
    suggestion: str


@dataclass
class EvaluationItem:
    item_id: str
    category: str
    title: str
    max_score: float
    estimated_score: float
    type: str  # objective / subjective
    response_status: str  # fully_responded / partially_responded / insufficient_response / missing
    evidence_chapters: List[str]
    evidence_text: str
    page_ref: str
    deduction_reasons: List[DeductionReason] = field(default_factory=list)
    improvement_suggestions: List[str] = field(default_factory=list)
    needs_ocr_check: bool = False
    ocr_check_target: str = ''


@dataclass
class EvaluationPlan:
    evaluation_id: str
    evaluation_time: str
    total_score: float
    estimated_score: float
    confidence: str  # high / medium / low
    confidence_reason: str
    items: List[EvaluationItem]
    baseline_price: Optional[float] = None          # 价格分基准价（用户交互得到的竞争对手最低报价预估）
    bid_price: Optional[float] = None               # 本投标报价总额
    price_score_confidence: str = 'low'             # 价格分置信度（用户交互→medium；保守默认→low）
    baseline_price_source: str = ''                 # 基准价来源（如 user_A_限价90% / conservative_default）


# 客观分项需要 OCR 检查的关键词
OCR_CHECK_KEYWORDS = {
    '营业执照': '营业执照有效期、公司名称、统一社会信用代码',
    '身份证': '身份证姓名、身份证号、有效期',
    '资质证书': '资质等级、有效期',
    '检测报告': '报告编号、检测日期、有效期',
    '授权书': '授权方、被授权方、授权期限',
    '财务审计': '审计年度、会计师事务所',
    '纳税证明': '纳税年度、税种',
    '社保证明': '社保年度、参保人数',
}


def find_relevant_chapters_via_summary(
    scoring_item: Dict, summaries: List[Dict], top_k: int = 10
) -> List[Dict]:
    """Step 4-1: 摘要粗筛"""
    evidence_keywords = scoring_item.get('evidence_keywords', [])
    if not evidence_keywords:
        return summaries[:top_k]

    scored = []
    for s in summaries:
        title = s.get('title', '')
        summary = s.get('summary', '')
        key_points = ' '.join(s.get('key_points', []))
        combined = title + ' ' + summary + ' ' + key_points

        # 计算关键词命中数
        hits = sum(1 for kw in evidence_keywords if kw in combined)
        if hits > 0:
            scored.append((hits, s))

    # 按命中数排序
    scored.sort(key=lambda x: -x[0])
    return [s for _, s in scored[:top_k]]


def find_relevant_chapters_via_keyword_index(
    scoring_item: Dict, keyword_index: Dict, candidate_chapter_ids: List[str], top_k: int = 3
) -> List[str]:
    """Step 4-2: 关键词精筛"""
    evidence_keywords = scoring_item.get('evidence_keywords', [])
    index = keyword_index.get('index', {})

    # 对每个候选章节，计算关键词索引命中数
    chapter_hits = defaultdict(int)
    for kw in evidence_keywords:
        chapters_with_kw = index.get(kw, [])
        for ch_id in chapters_with_kw:
            if ch_id in candidate_chapter_ids:
                chapter_hits[ch_id] += 2  # 关键词精确命中加权

    # 也用评分项标题做模糊匹配
    title = scoring_item.get('title', '')
    for ch_id in candidate_chapter_ids:
        if ch_id in keyword_index.get('index', {}):
            pass  # 已处理

    # 取 top_k
    sorted_chapters = sorted(chapter_hits.items(), key=lambda x: -x[1])
    return [ch_id for ch_id, _ in sorted_chapters[:top_k]]


def build_evaluation_prompt(scoring_item: Dict, chapters_text: str) -> str:
    """构建 LLM 评估提示词"""
    sub_criteria_text = ''
    sub_criteria = scoring_item.get('sub_criteria', [])
    if sub_criteria:
        sub_criteria_text = '\n子评分点：\n'
        for sc in sub_criteria:
            if isinstance(sc, dict):
                sub_criteria_text += f"  - {sc.get('desc', '')}（{sc.get('score', 0)} 分）\n"

    item_type = scoring_item.get('type', 'subjective')
    type_desc = '客观分（核对此项是否响应，是/否）' if item_type == 'objective' else '主观分（评估响应质量）'

    return f"""请评估标书对以下评分项的响应质量。

【评分项信息】
- 评分类别：{scoring_item.get('category', '')}
- 评分项名称：{scoring_item.get('title', '')}
- 满分：{scoring_item.get('max_score', 0)} 分
- 评分标准：{scoring_item.get('criteria', '')}
- 类型：{type_desc}
{sub_criteria_text}

【标书相关章节内容】
{chapters_text[:10000]}

请输出 JSON 格式的评估结果（严格遵循，不要其他文字）：
{{
  "response_status": "fully_responded | partially_responded | insufficient_response | missing",
  "estimated_score": {scoring_item.get('max_score', 0)},
  "evidence_text": "在标书中找到的关键证据原文（限200字）",
  "deduction_reasons": [
    {{
      "sub_criteria": "扣分的子项",
      "max_score": 5,
      "deducted_score": 2,
      "reason": "扣分原因",
      "suggestion": "改进建议"
    }}
  ],
  "improvement_suggestions": ["建议1", "建议2"]
}}

判断标准：
- fully_responded（完全响应）：所有评分点都覆盖，预估得分率 90-100%
- partially_responded（部分响应）：覆盖主要评分点但有遗漏，预估得分率 60-89%
- insufficient_response（响应不足）：关键评分点缺失，预估得分率 30-59%
- missing（缺失）：完全未响应，预估得分率 0-29%
"""


def call_llm_for_evaluation(prompt: str, timeout: int = 180) -> Optional[Dict]:
    """调用 z-ai CLI 做评估"""
    try:
        result = subprocess.run(
            ['z-ai', 'chat', '-p', prompt],
            capture_output=True, text=True, timeout=timeout, check=False
        )
        if result.returncode != 0:
            _logger.warning(f'    z-ai 调用失败：{result.stderr[:200]}')
            return None

        output = result.stdout.strip()
        json_match = re.search(r'\{[\s\S]*\}', output)
        if not json_match:
            _logger.warning('    无法从 LLM 输出提取 JSON')
            return None

        return json.loads(json_match.group(0))
    except subprocess.TimeoutExpired:
        _logger.warning(f'    z-ai 调用超时（{timeout}秒）')
        return None
    except json.JSONDecodeError as e:
        _logger.warning(f'    LLM 输出 JSON 解析失败：{e}')
        return None
    except FileNotFoundError:
        _logger.warning('    z-ai CLI 未安装')
        return None


def rule_based_evaluation(scoring_item: Dict, chapters_text: str) -> Dict:
    """规则兜底评估（不调用 LLM）"""
    evidence_keywords = scoring_item.get('evidence_keywords', [])
    max_score = scoring_item.get('max_score', 0)
    title = scoring_item.get('title', '')

    # 计算关键词命中率
    if not evidence_keywords or not chapters_text:
        return {
            'response_status': 'missing',
            'estimated_score': 0,
            'evidence_text': '未找到相关章节',
            'deduction_reasons': [{
                'sub_criteria': title,
                'max_score': max_score,
                'deducted_score': max_score,
                'reason': '未找到相关章节内容',
                'suggestion': f'补充「{title}」相关内容'
            }],
            'improvement_suggestions': [f'补充「{title}」章节']
        }

    hits = sum(1 for kw in evidence_keywords if kw in chapters_text)
    hit_rate = hits / len(evidence_keywords)

    if hit_rate >= 0.9:
        status = 'fully_responded'
        estimated = max_score * 0.95
    elif hit_rate >= 0.6:
        status = 'partially_responded'
        estimated = max_score * 0.75
    elif hit_rate >= 0.3:
        status = 'insufficient_response'
        estimated = max_score * 0.4
    else:
        status = 'missing'
        estimated = 0

    return {
        'response_status': status,
        'estimated_score': round(estimated, 1),
        'evidence_text': f'关键词命中率 {hit_rate*100:.0f}%（{hits}/{len(evidence_keywords)}）',
        'deduction_reasons': [] if status == 'fully_responded' else [{
            'sub_criteria': title,
            'max_score': max_score,
            'deducted_score': round(max_score - estimated, 1),
            'reason': f'关键词覆盖率仅 {hit_rate*100:.0f}%',
            'suggestion': f'补充缺失的关键内容'
        }],
        'improvement_suggestions': []
    }


def evaluate_single_item(
    scoring_item: Dict,
    chapter_index: Dict,
    chapter_summaries: List[Dict],
    keyword_index: Dict,
    use_llm: bool = True
) -> EvaluationItem:
    """评估单个评分项"""
    item_id = scoring_item.get('item_id', '')
    title = scoring_item.get('title', '')
    _logger.info(f'  评估：{title}（{scoring_item.get("max_score", 0)} 分）')

    # Step 4-1: 摘要粗筛
    candidates = find_relevant_chapters_via_summary(scoring_item, chapter_summaries, top_k=10)
    candidate_ids = [c.get('chapter_id', '') for c in candidates]

    # Step 4-2: 关键词精筛
    if candidate_ids:
        top_chapter_ids = find_relevant_chapters_via_keyword_index(
            scoring_item, keyword_index, candidate_ids, top_k=3
        )
    else:
        # 摘要粗筛无结果，用关键词索引直接找
        evidence_keywords = scoring_item.get('evidence_keywords', [])
        index = keyword_index.get('index', {})
        all_ch_ids = set()
        for kw in evidence_keywords:
            all_ch_ids.update(index.get(kw, []))
        top_chapter_ids = list(all_ch_ids)[:3]

    # Step 4-3: 收集 top 章节全文
    chapters_dict = {ch['chapter_id']: ch for ch in chapter_index.get('chapters', [])}
    chapters_text_parts = []
    evidence_chapters = []
    page_refs = []
    for ch_id in top_chapter_ids:
        ch = chapters_dict.get(ch_id)
        if ch:
            chapters_text_parts.append(f"=== 章节：{ch.get('title', '')}（页 {ch.get('page_start', '?')}-{ch.get('page_end', '?')}） ===\n{ch.get('full_text', '')[:5000]}")
            evidence_chapters.append(ch_id)
            page_refs.append(f"{ch.get('page_start', '')}-{ch.get('page_end', '')}")

    chapters_text = '\n\n'.join(chapters_text_parts)

    # Step 4-4: LLM 评估
    eval_result = None
    if use_llm and chapters_text:
        prompt = build_evaluation_prompt(scoring_item, chapters_text)
        eval_result = call_llm_for_evaluation(prompt)

    if not eval_result:
        _logger.info('    LLM 不可用，使用规则兜底')
        eval_result = rule_based_evaluation(scoring_item, chapters_text)

    # 规范化扣分理由
    deduction_reasons = []
    for r in eval_result.get('deduction_reasons', []):
        if isinstance(r, dict):
            deduction_reasons.append(DeductionReason(
                sub_criteria=r.get('sub_criteria', ''),
                max_score=float(r.get('max_score', 0)),
                deducted_score=float(r.get('deducted_score', 0)),
                reason=r.get('reason', ''),
                suggestion=r.get('suggestion', ''),
            ))

    # 客观分项特殊处理：检查是否需要 OCR
    needs_ocr = False
    ocr_target = ''
    if scoring_item.get('type') == 'objective':
        for ocr_kw, ocr_desc in OCR_CHECK_KEYWORDS.items():
            if ocr_kw in title or any(ocr_kw in kw for kw in scoring_item.get('evidence_keywords', [])):
                needs_ocr = True
                ocr_target = ocr_desc
                break

    return EvaluationItem(
        item_id=item_id,
        category=scoring_item.get('category', ''),
        title=title,
        max_score=float(scoring_item.get('max_score', 0)),
        estimated_score=float(eval_result.get('estimated_score', 0)),
        type=scoring_item.get('type', 'subjective'),
        response_status=eval_result.get('response_status', 'missing'),
        evidence_chapters=evidence_chapters,
        evidence_text=eval_result.get('evidence_text', '')[:500],
        page_ref=','.join(page_refs),
        deduction_reasons=deduction_reasons,
        improvement_suggestions=eval_result.get('improvement_suggestions', []),
        needs_ocr_check=needs_ocr,
        ocr_check_target=ocr_target,
    )


def assess_confidence(items: List[EvaluationItem]) -> tuple:
    """评估置信度"""
    if not items:
        return 'low', '未评估任何评分项'

    subjective_items = [it for it in items if it.type == 'subjective']
    if not subjective_items:
        return 'high', '全部为客观分项，预估准确'

    # 主观分项越多，置信度越低
    if len(subjective_items) <= 3:
        return 'medium', '主观分项预估存在 5-10 分误差'
    elif len(subjective_items) <= 8:
        return 'medium', '主观分项较多，预估存在 5-15 分误差'
    else:
        return 'low', '主观分项过多，预估存在 10-20 分误差'


def main():
    parser = argparse.ArgumentParser(description='Stage 4: 评分项响应质量评估')
    parser.add_argument('--scoring-table', required=True, help='评分表 JSON')
    parser.add_argument('--chapter-index', required=True, help='章节索引 JSON')
    parser.add_argument('--chapter-summaries', required=True, help='章节摘要 JSON')
    parser.add_argument('--keyword-index', required=True, help='关键词索引 JSON')
    parser.add_argument('--output', required=True, help='输出评分预估 Plan JSON')
    parser.add_argument('--no-llm', action='store_true', help='不调用 LLM，仅用规则')
    parser.add_argument('--parallel', type=int, default=1, help='并发数（暂未实现）')
    parser.add_argument('--baseline-price', type=float, default=None,
                        help='价格分基准价=预估竞争对手最低报价；来自 Stage4.2.1 与用户交互（A-F）')
    parser.add_argument('--bid-price', type=float, default=None,
                        help='本投标报价总额（用于价格分公式：基准价/报价×满分）')
    parser.add_argument('--price-confidence', default='medium',
                        help='价格分置信度：用户交互确认填 medium，保守默认填 low')
    parser.add_argument('--baseline-source', default='',
                        help='基准价来源说明，如 user_A_限价90% / conservative_default')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取评分表：{args.scoring_table}')
    with open(args.scoring_table, 'r', encoding='utf-8') as f:
        scoring_table = json.load(f)

    _logger.info(f'读取章节索引：{args.chapter_index}')
    with open(args.chapter_index, 'r', encoding='utf-8') as f:
        chapter_index = json.load(f)

    _logger.info(f'读取章节摘要：{args.chapter_summaries}')
    with open(args.chapter_summaries, 'r', encoding='utf-8') as f:
        summaries_data = json.load(f)
    chapter_summaries = summaries_data.get('summaries', [])

    _logger.info(f'读取关键词索引：{args.keyword_index}')
    with open(args.keyword_index, 'r', encoding='utf-8') as f:
        keyword_index = json.load(f)

    scoring_items = scoring_table.get('scoring_items', [])
    total_score = scoring_table.get('total_score', 100)
    _logger.info(f'  评分项数：{len(scoring_items)}')
    _logger.info(f'  总分：{total_score}')

    # 评估每个评分项
    eval_items = []
    for i, item in enumerate(scoring_items):
        _logger.info(f'[{i+1}/{len(scoring_items)}] 处理评分项...')
        eval_item = evaluate_single_item(
            item, chapter_index, chapter_summaries, keyword_index,
            use_llm=not args.no_llm
        )
        eval_items.append(eval_item)
        # 简单限流
        if not args.no_llm and i < len(scoring_items) - 1:
            time.sleep(1)

    # 计算预估总分
    estimated_total = sum(it.estimated_score for it in eval_items)

    # ===== 价格分交互重算（Stage 4.2.1 强制）=====
    baseline_price = args.baseline_price
    bid_price = args.bid_price
    baseline_source = args.baseline_source or 'interactive'
    price_conf = args.price_confidence
    if baseline_price and bid_price:
        for it in eval_items:
            is_price = (it.category == '价格分' or it.type == 'price'
                        or '报价' in it.title or '价格分' in it.title)
            if is_price:
                max_s = it.max_score
                if bid_price <= baseline_price:
                    price_score = max_s  # 我方即最低价，满分
                else:
                    price_score = (baseline_price / bid_price) * max_s
                price_score = round(min(price_score, max_s), 2)
                _logger.info(f'  价格分重算：基准价 {baseline_price} / 报价 {bid_price} × 满分 {max_s} = {price_score}')
                it.estimated_score = price_score
                it.response_status = 'fully_responded' if price_score >= max_s * 0.99 else 'partially_responded'
                it.evidence_text = (f'价格分=(基准价{baseline_price}/报价{bid_price})×满分{max_s}'
                                    f'={price_score}（基准价来源：{baseline_source}）')
        # 重算总分
        estimated_total = sum(it.estimated_score for it in eval_items)
    else:
        _logger.warning('  未提供 --baseline-price / --bid-price，价格分沿用规则预估（不推荐，'
                        '应在 Stage 4.2.1 与用户交互后传入）。')

    # 评估置信度
    confidence, confidence_reason = assess_confidence(eval_items)

    plan = EvaluationPlan(
        evaluation_id=f'eval_{datetime.now().strftime("%Y%m%d_%H%M%S")}',
        evaluation_time=datetime.now().isoformat(),
        total_score=float(total_score),
        estimated_score=round(estimated_total, 1),
        confidence=confidence,
        confidence_reason=confidence_reason,
        items=eval_items,
        baseline_price=baseline_price,
        bid_price=bid_price,
        price_score_confidence=price_conf,
        baseline_price_source=baseline_source,
    )

    output = asdict(plan)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  预估总分：{plan.estimated_score}/{plan.total_score}')
    _logger.info(f'  置信度：{plan.confidence}（{plan.confidence_reason}）')
    ocr_count = sum(1 for it in eval_items if it.needs_ocr_check)
    _logger.info(f'  需 OCR 检查项：{ocr_count}')


if __name__ == '__main__':
    main()
