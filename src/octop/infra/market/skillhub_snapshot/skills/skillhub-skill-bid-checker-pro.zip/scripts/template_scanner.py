#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
模板扫描器 — Phase 2B Step 1

扫描2A生成的投标文件框架模板，自动识别所有需要填充的位置，
分类标注填写类型（文本/图片/表格/签名/日期），生成"投标文件填入需求清单"报告。

核心逻辑：纯模式匹配，不依赖大模型，不依赖特定项目名称。
"""

import os
import sys
import json
import re
import argparse
from docx import Document

# v9.0: 统一日志
try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.template_scanner")
except ImportError:
    import logging
    _logger = logging.getLogger("template_scanner")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)


# ============================================================
# 章节追踪器
# ============================================================

def detect_chapter(text):
    """
    从段落文本中检测章节标题。

    关键改进：必须区分真正的章节标题和正文中的序号列表项。
    真正的章节标题特征：
      - 文字简短（≤18字）
      - 是标题性文字，不是完整句子（不含句号/逗号/分号等句子标点）
      - 不以"我方"、"本"、"我公司"等正文常见开头词起始
    """
    stripped = text.strip()

    # 标准中文章节格式："一、投标函"、"二、法定代表人身份证明"等
    m = re.match(r'^[\s　]*([一二三四五六七八九十]+)[、．\.]\s*(.+)', stripped)
    if m:
        num, title = m.group(1), m.group(2).strip()
        if _is_valid_chapter_title(title):
            return num, title

    # 数字章节格式："1. 投标函" （仅当数字较小且标题像章芓名时）
    m = re.match(r'^[\s　]*(\d+)[、．\.]\s*(.+)', stripped)
    if m:
        num_str, title = m.group(1), m.group(2).strip()
        num_val = int(num_str)
        # 只有 1-20 的数字且标题看起来像章节名才接受
        if num_val <= 20 and _is_valid_chapter_title(title):
            return num_str, title

    # "(一)" 子章节格式 — 如"（一）投标函"
    m = re.match(r'^[\s　]*[（(][一二三四五六七八九十]+[）)]\s*(.+)', stripped)
    if m:
        title = m.group(1).strip()
        if _is_valid_chapter_title(title):
            return '子章节', title

    return None, None


def _is_valid_chapter_title(title_text):
    """
    判断检测到的标题文字是否真的是一个章节标题（而非正文序号列表项）。

    排除规则：
    1. 太长（>18字）→ 大概率是正文句子
    2. 包含句子标点（句号、逗号、分号、感叹号、问号）→ 是正文
    3. 以正文常见开头词起始 → 是承诺/声明条款
    4. 纯数字或极短无意义文字 → 不是有效标题
    """

    # 规则1：长度限制
    if len(title_text) > 18:
        return False

    # 规则2：包含句子标点 → 绝对是正文
    sentence_puncts = ['。', '，', '；', '！？', '！', '？', '..', '……']
    for punct in sentence_puncts:
        if punct in title_text:
            return False

    # 规则3：以正文开头词起始 → 承诺/声明/说明类条款
    # 注意：这些词只在标题较长时才触发过滤，避免误杀合法短标题
    body_starters = [
        '我方', '我司', '我公司', '本公司', '我们',
        '若', '如', '如果', '一旦',
        '保证', '承诺', '同意', '确认', '理解',
        '所投', '附件', '附：', '注',
        '系',  # "系XXX的法定代表人" 是正文句式
    ]
    for starter in body_starters:
        if title_text.startswith(starter):
            return False

    # 规则4：太短且无意义（纯符号/单个字但不在允许名单中）
    if len(title_text) <= 1:
        return False

    # 规则5：看起来像表格单元格残留（含|或多个连续空白+字母数字混杂）
    if '|' in title_text and len(title_text) > 5:
        return False

    return True


def build_chapter_tracker(doc):
    """构建段落索引到章节的映射"""
    chapter_map = {}  # para_index -> (chapter_num, chapter_title)
    current_chapter = ('-', '封面/前置')

    for i, para in enumerate(doc.paragraphs):
        text = para.text.strip()
        num, title = detect_chapter(text)
        if num:
            current_chapter = (num, title)
        chapter_map[i] = current_chapter

    return chapter_map


# ============================================================
# 填充位置识别器
# ============================================================

def classify_fill_type(field_name, hint_text, para_text):
    """
    判断某个填充位置的填写类型。

    返回:
      'text'    — 需要填入文本值
      'image'   — 需要插入图片
      'signature' — 签名/盖章位（不填，留空）
      'date'    — 日期型（需要年月日）
      'table'   — 表格型（需要整行数据）
    """
    # 1. 签名位
    if '签字' in hint_text or '盖章' in hint_text or '签章' in hint_text:
        return 'signature'

    # 2. 附材料指令 → 图片插入
    if '附' in para_text and any(kw in para_text for kw in
        ['身份证', '证件', '复印件', '证书', '资质', '证明材料', '证明资料']):
        return 'image'

    # 3. 日期型
    if field_name and any(kw in field_name for kw in
        ['日期', '时间', '年', '月', '日', '成立时间', '经营期限']):
        if '年' in para_text and '月' in para_text:
            return 'date'

    # 4. 图片类（明确是图片占位）
    if any(kw in hint_text for kw in
        ['照片', '图片', '印章', '公章', '执照复印件']):
        return 'image'

    # 5. 表格型 — 由表格扫描器单独处理，这里不判断

    # 6. 默认文本
    return 'text'


def scan_paragraph_fill_positions(para, para_idx, chapter_info):
    """
    扫描单个段落，识别所有需要填充的位置。

    返回: list of fill_position dicts
    """
    text = para.text
    if not text.strip():
        return []

    runs = para.runs
    if not runs:
        return []

    positions = []
    chapter_num, chapter_title = chapter_info

    # ========== 1. 括号占位符检测 ==========
    # 模式: （项目名称）、（投标人名称）、（全称并加盖公章）等
    bracket_hints = re.findall(r'（([^）]+)）', text)
    for hint in bracket_hints:
        # === 过滤：不作为填充位的括号内容 ===
        # 1. 章节序号标记：(一)、(二)等
        if re.match(r'^[一二三四五六七八九十\d]+$', hint):
            continue
        # 2. 过长的描述性文本（>20字且不含关键词）
        if len(hint) > 20:
            # 仅保留含明确填充关键词的短提示
            fill_keywords = ['项目名称', '投标人', '招标人', '项目编号', '签字', '盖章',
                            '公章', '全称', '名称', '日期']
            if not any(kw in hint for kw in fill_keywords):
                continue
        # 3. 重复内容提示/指令性文本（不是填充位）
        skip_keywords = ['偏离', '包括', '如下', '详见', '不含', '不超过',
                        '格式自拟', '任意', '依法', '两种形式', '提供任何一种即可',
                        '评标办法', '仅供参考', '不得虚假', '据实填写',
                        '活动', '复印件', '原件', '副本', '正本', '原件及']
        if any(kw in hint for kw in skip_keywords):
            continue
        # 4. 极短片段过滤：≤2字的括号内容（除非是已知有效字段）
        valid_short_hints = {'签字', '盖章', '性别', '年龄', '职务', '姓名'}
        if len(hint) <= 2 and hint not in valid_short_hints:
            continue

        # === 分类 ===
        if hint in ('签字或盖章', '签字', '盖章'):
            fill_type = 'signature'
            field_name = hint
        elif hint in ('全称并加盖公章',):
            fill_type = 'text'
            field_name = '投标人名称'
        elif '项目名称' in hint:
            fill_type = 'text'
            field_name = '项目名称'
        elif '招标人名称' in hint:
            fill_type = 'text'
            field_name = '招标人名称'
        elif '投标人名称' in hint:
            fill_type = 'text'
            field_name = '投标人名称'
        elif '项目编号' in hint:
            fill_type = 'text'
            field_name = '项目编号'
        else:
            fill_type = classify_fill_type('', hint, text)
            field_name = hint

        # 检查是否有前置空白（填写位置）
        has_blank_before = False
        has_blank_after = False
        hint_start = text.find(f'（{hint}）')
        if hint_start > 0:
            before = text[:hint_start].rstrip()
            # 如果括号前有连续空白字符，说明有预留填写位
            blank_match = re.search(r'[\s　]{4,}$', before)
            has_blank_before = blank_match is not None

        positions.append({
            'para_idx': para_idx,
            'chapter_num': chapter_num,
            'chapter_title': chapter_title,
            'fill_type': fill_type,
            'field_name': field_name,
            'hint_text': hint,
            'pattern': 'bracket_hint',
            'has_blank_slot': has_blank_before,
            'para_text_preview': text.strip()[:80],
        })

    # ========== 2. 冒号后空白检测 ==========
    # 模式: "投标人名称：___"、"联系电话：___" 等
    colon_fields = [
        ('联系地址', ['联系地址', '地    址', '地址']),
        ('联系电话', ['联系电话', '电    话', '电话']),
        ('传真', ['传    真', '传真']),
        ('邮编', ['邮    编', '邮编', '邮政编码']),
        ('电子邮箱', ['电子邮箱', '邮箱', '电子信箱']),
        ('投标人名称', ['投标人名称', '投标人']),
        ('单位性质', ['单位性质']),
        ('经营期限', ['经营期限']),
        ('经营范围', ['经营范围']),
        ('成立时间', ['成立时间']),
        ('项目名称', ['项目名称']),
        ('项目编号', ['项目编号']),
        ('法定代表人', ['法定代表人']),
        ('被授权人', ['被授权人']),
        ('授权代表', ['授权代表']),
        ('法人姓名', ['法人姓名']),
    ]

    # 通用检测：关键词+冒号+空白
    for canonical_name, kw_variants in colon_fields:
        matched = False
        for kw in kw_variants:
            norm_text = text.replace(' ', '').replace('　', '')
            if kw in norm_text:
                # 检查是否紧随冒号
                if norm_text.startswith(kw) or kw + '：' in norm_text or kw + ':' in norm_text:
                    matched = True
                    break
        if not matched:
            continue

        # 检查冒号后是否有空白run（填写位）
        has_blank = False
        for run in runs:
            rt = run.text
            if '：' in rt or ':' in rt:
                after_colon = rt.split('：', 1)[-1] if '：' in rt else rt.split(':', 1)[-1]
                if re.search(r'\s{4,}', after_colon):
                    has_blank = True
                    break
            elif rt.strip() == '' and len(rt) >= 4:
                has_blank = True

        # 不要重复记录已被括号检测捕获的字段
        already_captured = any(p['field_name'] == canonical_name for p in positions)
        # 也不要重复记录同一段落中已匹配的其他变体
        if not already_captured:
            field_name = canonical_name
            fill_type = 'text'
            if '时间' in canonical_name or '日期' in canonical_name:
                fill_type = 'date'
            elif '地址' in canonical_name:
                fill_type = 'text'

            positions.append({
                'para_idx': para_idx,
                'chapter_num': chapter_num,
                'chapter_title': chapter_title,
                'fill_type': fill_type,
                'field_name': field_name,
                'hint_text': f'{canonical_name}：___',
                'pattern': 'colon_blank',
                'has_blank_slot': has_blank,
                'para_text_preview': text.strip()[:80],
            })

    # ========== 3. 复合行检测 ==========
    # 模式: "姓名：___ 性别：___ 年龄：___ 职务：___"
    if '姓名' in text and '性别' in text:
        inline_fields = re.findall(r'([\u4e00-\u9fff]+)[：:]', text)
        for field_kw in inline_fields:
            if field_kw in ('姓名', '性别', '年龄', '职务', '住址', '身份证号码', '身份证明号码'):
                already_captured = any(p['field_name'] == f'法人{field_kw}' or p['field_name'] == field_kw
                                       for p in positions)
                if not already_captured:
                    positions.append({
                        'para_idx': para_idx,
                        'chapter_num': chapter_num,
                        'chapter_title': chapter_title,
                        'fill_type': 'text',
                        'field_name': f'法人{field_kw}' if '法定代表人' in chapter_title else field_kw,
                        'hint_text': f'{field_kw}：___',
                        'pattern': 'inline_multi_field',
                        'has_blank_slot': True,
                        'para_text_preview': text.strip()[:80],
                    })

    # ========== 4. 日期行检测 ==========
    # 模式: "日期：___年___月___日" 或 裸日期行 "___年___月___日"
    if re.search(r'日[\s　]*期[：:]', text) and '年' in text and '月' in text:
        already_captured = any(p['fill_type'] == 'date' and '日期' in p['field_name'] for p in positions)
        if not already_captured:
            positions.append({
                'para_idx': para_idx,
                'chapter_num': chapter_num,
                'chapter_title': chapter_title,
                'fill_type': 'date',
                'field_name': '投标日期',
                'hint_text': '___年___月___日',
                'pattern': 'date_line',
                'has_blank_slot': True,
                'para_text_preview': text.strip()[:80],
            })

    if re.match(r'^[\s　]*年[\s　]+月[\s　]+日[\s　]*$', text.strip()):
        positions.append({
            'para_idx': para_idx,
            'chapter_num': chapter_num,
            'chapter_title': chapter_title,
            'fill_type': 'date',
            'field_name': '签名日期',
            'hint_text': '年___月___日',
            'pattern': 'bare_date',
            'has_blank_slot': True,
            'para_text_preview': text.strip()[:80],
        })

    # ========== 5. 附材料指令检测 ==========
    # 模式1: "注：附相关人员身份证复印件..."
    # 模式2: "附：法定代表人身份证复印件。"（独立附材料行）
    # 模式3: "附xxx复印件"（无冒号版本）
    is_attach_instruction = False

    # 模式1: 注 + 附/随
    if re.search(r'注[：:]', text) and ('附' in text or '随' in text):
        if any(kw in text for kw in ['身份证', '证件', '复印件', '证书', '资质', '证明材料', '证明资料']):
            is_attach_instruction = True

    # 模式2: 附：xxx复印件 / 附xxx复印件（独立附行，不含"注"）
    if not is_attach_instruction and (text.strip().startswith('附') or text.strip().startswith('随')):
        if any(kw in text for kw in ['身份证', '证件', '复印件', '证书', '资质', '证明材料', '证明资料']):
            # 确认是附材料指令而非正文引用
            if len(text.strip()) < 80:  # 附材料指令通常很短
                is_attach_instruction = True

    if is_attach_instruction:
        already_captured = any(p['fill_type'] == 'image' for p in positions)
        if not already_captured:
            positions.append({
                'para_idx': para_idx,
                'chapter_num': chapter_num,
                'chapter_title': chapter_title,
                'fill_type': 'image',
                'field_name': '附件图片插入',
                'hint_text': text.strip()[:60],
                'pattern': 'attach_instruction',
                'has_blank_slot': False,
                'para_text_preview': text.strip()[:80],
                'attach_keywords': re.findall(r'身份证|证件|复印件|证书|资质|证明', text),
            })

    # ========== 6. 系___（投标人名称）的法定代表人 ==========
    if text.strip().startswith('系') and '（投标人名称）' in text and '法定代表人' in text:
        # 已被括号检测覆盖，但需标注是特殊复合行
        for p in positions:
            if p['field_name'] == '投标人名称' and p['para_idx'] == para_idx:
                p['pattern'] = '系_投标人_法定代表人'
                p['field_name'] = '系投标人名称(法定代表人句)'

    # ========== 7. 授权委托书复合段落 ==========
    if '本人作为' in text and '法定代表人' in text and '在此授权' in text:
        # 标记为复合段落，包含多个字段
        for p in positions:
            if p['para_idx'] == para_idx:
                p['pattern'] = 'authorization_complex'

    return positions


def scan_table_fill_positions(table, table_idx, chapter_map, doc):
    """
    扫描表格，识别需要填充的表格位置。

    改进：增加对图片插入表格的识别（如身份证粘贴区表格）。

    返回: list of fill_position dicts
    """
    positions = []

    # ========== 先检测图片插入类表格（如1行×2列的身份证粘贴区）==========
    # 特征：行数少（≤3行），单元格包含 身份证/复印件/正反面 等关键词
    if len(table.rows) <= 3:
        image_keywords_found = []
        for row in table.rows:
            for cell in row.cells:
                cell_text = cell.text.strip()
                if any(kw in cell_text for kw in ['身份证', '复印件', '正反面', '证件复印件', '执照复印件']):
                    image_keywords_found.append(cell_text[:40])

        if image_keywords_found:
            # 这是一个图片插入表格（身份证粘贴区等）
            # 找到表格的章节归属
            from lxml import etree
            body = doc.element.body
            table_element = table._element
            all_children = list(body)
            table_pos_in_body = None
            para_pos_in_body = {}
            for idx, child in enumerate(all_children):
                if child is table_element:
                    table_pos_in_body = idx
                if child.tag.endswith('}p'):
                    para_pos_in_body[idx] = child

            nearest_para_idx = 0
            if table_pos_in_body is not None:
                for pos in range(table_pos_in_body - 1, -1, -1):
                    if pos in para_pos_in_body:
                        for pi, p in enumerate(doc.paragraphs):
                            if p._element is para_pos_in_body[pos]:
                                nearest_para_idx = pi
                                break
                        break

            chapter_num, chapter_title = chapter_map.get(nearest_para_idx, ('-', '未知'))

            # 生成图片插入描述
            desc_items = '、'.join(image_keywords_found[:4])
            positions.append({
                'para_idx': nearest_para_idx,
                'table_idx': table_idx,
                'chapter_num': chapter_num,
                'chapter_title': chapter_title,
                'fill_type': 'image',
                'field_name': '附件图片插入',
                'hint_text': f'粘贴{desc_items}',
                'pattern': 'table_image_insertion',
                'has_blank_slot': False,
                'para_text_preview': f'图片粘贴表格: {desc_items}',
                'attach_keywords': image_keywords_found,
                'table_type': 'image_insertion',
            })
            return positions  # 图片插入表格不需要再处理为数据表格

    if len(table.rows) < 2:
        return positions

    # 获取表头
    header_row = table.rows[0]
    headers = [c.text.replace(' ', '').replace('　', '').strip() for c in header_row.cells]

    # 确定表格类型
    table_type = 'unknown'
    # 人员表：含姓名+性别+(年龄)+(职务/担任职务/拟担任的职务)
    if any('姓名' in h for h in headers) and any('性别' in h for h in headers):
        if any(h in ('职务', '担任职务', '拟担任的职务', '岗位', '拟担任职务') for h in headers):
            table_type = 'personnel'
        else:
            table_type = 'personnel_basic'
    # 偏离表：含招标文件+投标文件+偏离
    elif any('招标文件' in h for h in headers) and any('投标文件' in h for h in headers) and any('偏离' in h for h in headers):
        table_type = 'deviation'
    # 业绩表：含年份+用户名称+项目名称
    elif any('年份' in h for h in headers) and any('用户名称' in h for h in headers) and any('项目名称' in h for h in headers):
        table_type = 'performance'
    # 报价表：含名称+报价
    elif '序号' in headers and (any('名称' in h for h in headers) or any('项目' in h for h in headers)) and any('报价' in h for h in headers):
        table_type = 'quotation'
    elif '序号' in headers and (any('内容' in h for h in headers) or any('条款' in h for h in headers)):
        table_type = 'generic_list'

    # 找到表格在文档中的位置（用第一个段落索引估算）
    # python-docx没有直接的表格位置API，我们用近似方法
    # 通过检查表格后面紧接着的段落来推断
    table_para_idx = None
    # 找到包含此表格的最近章节
    # 使用表格行数和位置来估算
    # 更简单的方法：通过表格的 _element 在文档XML中的位置

    # 使用一个简化策略：遍历所有段落找到最近的前置章节
    # 对于表格，我们用它在doc.tables中的索引作为定位参考
    estimated_para_idx = sum(len(doc.paragraphs[:i]) for i in range(len(doc.paragraphs)))
    # 简化：用表格索引*100作为估算
    estimated_para_idx = table_idx * 100  # rough estimate

    # 获取章节信息（使用表格在文档中大概的位置）
    # python-docx中表格和段落交替排列，但无法直接获取表格位置
    # 我们使用一个近似方法：找表格前最近的段落章节
    # 通过XML元素顺序来确定

    from lxml import etree
    body = doc.element.body
    table_element = table._element
    # 找到表格元素在body中的位置
    all_children = list(body)
    table_pos_in_body = None
    para_pos_in_body = {}
    for idx, child in enumerate(all_children):
        if child is table_element:
            table_pos_in_body = idx
        # 同时记录段落位置
        if child.tag.endswith('}p'):
            para_pos_in_body[idx] = child

    # 找到表格前面最近的段落索引
    nearest_para_idx = 0
    if table_pos_in_body is not None:
        for pos in range(table_pos_in_body - 1, -1, -1):
            if pos in para_pos_in_body:
                # 找到这个段落元素在doc.paragraphs中的索引
                for pi, p in enumerate(doc.paragraphs):
                    if p._element is para_pos_in_body[pos]:
                        nearest_para_idx = pi
                        break
                break

    chapter_num, chapter_title = chapter_map.get(nearest_para_idx, ('-', '未知'))

    # 计算空行数量
    empty_rows = 0
    for ri in range(1, len(table.rows)):
        row = table.rows[ri]
        row_empty = all(c.text.strip() == '' or c.text.strip() in ('-', '/') for c in row.cells)
        if row_empty:
            empty_rows += 1

    # 根据表格类型生成填充位置描述
    if table_type == 'personnel':
        # 人员表：每行一个人，需要姓名+性别+年龄+职务+备注
        col_fields = {}
        for ci, h in enumerate(headers):
            if h == '序号':
                col_fields[ci] = '序号'
            elif h == '姓名':
                col_fields[ci] = '姓名'
            elif h in ('性别',):
                col_fields[ci] = '性别'
            elif h in ('年龄',):
                col_fields[ci] = '年龄'
            elif h in ('担任职务', '职务', '拟担任的职务', '岗位', '拟担任职务'):
                col_fields[ci] = '职务'
            elif h in ('备注', '说明'):
                col_fields[ci] = '备注'
            else:
                col_fields[ci] = h

        positions.append({
            'para_idx': nearest_para_idx,
            'table_idx': table_idx,
            'chapter_num': chapter_num,
            'chapter_title': chapter_title,
            'fill_type': 'table',
            'field_name': f'项目人员({empty_rows}人)',
            'hint_text': f'表格{table_idx}: {len(headers)}列×{len(table.rows)}行，{empty_rows}空行待填',
            'pattern': 'table_personnel',
            'has_blank_slot': True,
            'para_text_preview': f'人员汇总表: {", ".join(headers)}',
            'table_type': table_type,
            'col_fields': col_fields,
            'empty_rows': empty_rows,
            'total_rows': len(table.rows) - 1,  # excluding header
        })

    elif table_type == 'deviation':
        # 偏离表：每行一个偏离项
        positions.append({
            'para_idx': nearest_para_idx,
            'table_idx': table_idx,
            'chapter_num': chapter_num,
            'chapter_title': chapter_title,
            'fill_type': 'table',
            'field_name': f'偏离表({empty_rows}项)',
            'hint_text': f'表格{table_idx}: {len(headers)}列×{len(table.rows)}行，{empty_rows}空行待填',
            'pattern': 'table_deviation',
            'has_blank_slot': True,
            'para_text_preview': f'偏离表: {", ".join(headers)}',
            'table_type': table_type,
            'empty_rows': empty_rows,
            'total_rows': len(table.rows) - 1,
        })

    elif table_type == 'quotation':
        # 报价表
        positions.append({
            'para_idx': nearest_para_idx,
            'table_idx': table_idx,
            'chapter_num': chapter_num,
            'chapter_title': chapter_title,
            'fill_type': 'table',
            'field_name': f'报价表({empty_rows}项)',
            'hint_text': f'表格{table_idx}: 报价明细表，{empty_rows}空行待填',
            'pattern': 'table_quotation',
            'has_blank_slot': True,
            'para_text_preview': f'报价表: {", ".join(headers)}',
            'table_type': table_type,
            'empty_rows': empty_rows,
            'total_rows': len(table.rows) - 1,
        })

    elif table_type == 'performance':
        # 业绩表：每行一个业绩合同
        positions.append({
            'para_idx': nearest_para_idx,
            'table_idx': table_idx,
            'chapter_num': chapter_num,
            'chapter_title': chapter_title,
            'fill_type': 'table',
            'field_name': f'业绩表({empty_rows}项)',
            'hint_text': f'表格{table_idx}: 类似项目业绩表，{empty_rows}空行待填',
            'pattern': 'table_performance',
            'has_blank_slot': True,
            'para_text_preview': f'业绩表: {", ".join(headers)}',
            'table_type': table_type,
            'empty_rows': empty_rows,
            'total_rows': len(table.rows) - 1,
        })

    else:
        # 通用表格
        if empty_rows > 0:
            positions.append({
                'para_idx': nearest_para_idx,
                'table_idx': table_idx,
                'chapter_num': chapter_num,
                'chapter_title': chapter_title,
                'fill_type': 'table',
                'field_name': f'表格{table_idx}({empty_rows}空行)',
                'hint_text': f'表格{table_idx}: {", ".join(headers)}, {empty_rows}空行',
                'pattern': 'table_generic',
                'has_blank_slot': True,
                'para_text_preview': f'通用表格: {", ".join(headers)}',
                'table_type': table_type,
                'empty_rows': empty_rows,
                'total_rows': len(table.rows) - 1,
            })

    return positions


# ============================================================
# 必填/选填判断（结合解析报告）
# ============================================================

def determine_required_level(field_name, fill_type, parse_report_data=None):
    """
    判断字段是必填还是选填。

    优先级：
      1. 从解析报告的资格要求/响应文件组成中自动判断
      2. 从字段类型推断（签名位=不填，表格必填项=必填，括号提示=必填）
      3. 默认=待确认
    """
    # 签名位：不填
    if fill_type == 'signature':
        return 'skip'

    # 图片插入位：必填（资格证明材料通常是硬性要求）
    if fill_type == 'image':
        return 'required'

    # 从解析报告判断
    if parse_report_data:
        required_fields = parse_report_data.get('required_fill_fields', [])
        if field_name in required_fields:
            return 'required'

    # 基于字段名推断
    core_required = [
        '项目名称', '招标人名称', '投标人名称', '项目编号',
        '法人姓名', '法人性别', '法人年龄', '法人职务',
        '联系地址', '联系电话', '投标日期',
        '社会信用代码', '单位性质', '成立时间', '经营期限',
    ]
    if field_name in core_required:
        return 'required'

    return '待确认'


# ============================================================
# 主扫描函数
# ============================================================

def scan_template(framework_path, parse_report_path=None):
    """
    扫描投标文件框架模板，识别所有需要填充的位置。

    参数:
      framework_path: 2A生成的框架模板docx路径（可以是.pdf，自动转换）
      parse_report_path: 第一阶段解析报告路径（可选，用于必填判断）

    返回:
      dict: {
        'template_info': {...},    # 模板基本信息
        'chapter_summary': [...],  # 章节概览
        'fill_positions': [...],   # 所有填充位置详情
        'statistics': {...},       # 统计汇总
      }
    """
    # ★ 自动检测PDF并转换（转换到当前工作目录）
    if framework_path.lower().endswith('.pdf'):
        from pdf_to_word import convert_pdf_to_word
        output_dir = os.path.dirname(os.path.abspath(framework_path))
        _logger.info(f'  → 检测到PDF招标文件，自动转换为Word格式...')
        _logger.info(f'  → 转换目录: {output_dir}')
        converted_path = convert_pdf_to_word(framework_path)
        _logger.info(f'  → PDF转换完成: {converted_path}')
        framework_path = converted_path

    if not framework_path.lower().endswith('.docx') and not framework_path.lower().endswith('.doc'):
        raise ValueError(f'框架文件必须是Word格式(.docx/.doc)，收到: {framework_path}')

    doc = Document(framework_path)

    # 加载解析报告数据（用于必填判断）
    parse_report_data = None
    if parse_report_path and parse_report_path.strip() and os.path.isfile(parse_report_path):
        with open(parse_report_path, 'r', encoding='utf-8') as f:
            parse_content = f.read()
        # 提取必填字段列表
        parse_report_data = {
            'required_fill_fields': _extract_required_fields_from_report(parse_content),
        }

    # 构建章节追踪器
    chapter_map = build_chapter_tracker(doc)

    # 模板基本信息
    template_info = {
        'file_path': framework_path,
        'total_paragraphs': len(doc.paragraphs),
        'total_tables': len(doc.tables),
        'total_runs': sum(len(p.runs) for p in doc.paragraphs),
    }

    # 章节概览
    chapter_summary = []
    seen_chapters = set()
    for i, para in enumerate(doc.paragraphs):
        ch_num, ch_title = chapter_map[i]
        if ch_num != '-' and (ch_num, ch_title) not in seen_chapters:
            seen_chapters.add((ch_num, ch_title))
            chapter_summary.append({
                'chapter_num': ch_num,
                'chapter_title': ch_title,
                'para_idx': i,
                'para_text_preview': para.text.strip()[:60],
            })

    # ========== 段落级扫描 ==========
    fill_positions = []

    for i, para in enumerate(doc.paragraphs):
        text = para.text
        if not text.strip():
            continue

        chapter_info = chapter_map[i]
        positions = scan_paragraph_fill_positions(para, i, chapter_info)
        fill_positions.extend(positions)

    # ========== 表格级扫描 ==========
    for ti, table in enumerate(doc.tables):
        positions = scan_table_fill_positions(table, ti, chapter_map, doc)
        fill_positions.extend(positions)

    # ========== 必填判断 ==========
    for pos in fill_positions:
        pos['required_level'] = determine_required_level(
            pos['field_name'], pos['fill_type'], parse_report_data)

    # ========== 统计汇总 ==========
    stats = {
        'total_fill_positions': len(fill_positions),
        'by_type': {},
        'by_chapter': {},
        'by_required_level': {},
        'by_pattern': {},
    }
    for pos in fill_positions:
        ft = pos['fill_type']
        stats['by_type'][ft] = stats['by_type'].get(ft, 0) + 1

        ch_key = f"{pos['chapter_num']}-{pos['chapter_title']}"
        stats['by_chapter'][ch_key] = stats['by_chapter'].get(ch_key, 0) + 1

        rl = pos['required_level']
        stats['by_required_level'][rl] = stats['by_required_level'].get(rl, 0) + 1

        pt = pos['pattern']
        stats['by_pattern'][pt] = stats['by_pattern'].get(pt, 0) + 1

    return {
        'template_info': template_info,
        'chapter_summary': chapter_summary,
        'fill_positions': fill_positions,
        'statistics': stats,
    }


def _extract_required_fields_from_report(content):
    """从解析报告中提取必填字段列表"""
    required = []

    # 搜索"响应文件组成"或"资格要求"章节
    sections = re.split(r'^##\s+', content)
    for section in sections:
        if '资格要求' in section[:50] or '响应文件组成' in section[:50]:
            # 提取表格中的"证明材料"列
            lines = section.split('\n')
            for line in lines:
                if '|' in line:
                    cells = [c.strip() for c in line.split('|')]
                    if len(cells) >= 4:
                        proof = cells[-2] if cells[-2] else cells[-1]
                        if proof and proof not in ('—', '', '具体要求', '证明材料'):
                            required.append(proof)

    return required


# ============================================================
# 报告生成器
# ============================================================

def _get_top_chapter(ch_key):
    """从完整章节key提取顶级章节编号用于归并分组。"""
    if not ch_key:
        return '-'

    # 匹配中文数字开头（一、二、三...）
    m = re.match(r'^([一二三四五六七八九十]+)', ch_key)
    if m:
        return m.group(1)

    # 匹配阿拉伯数字开头
    m = re.match(r'^(\d+)', ch_key)
    if m:
        num = int(m.group(1))
        cn_nums = ['零','一','二','三','四','五','六','七','八','九','十',
                   '十一','十二','十三','十四','十五','十六','十七','十八','十九','二十']
        if num < len(cn_nums):
            return cn_nums[num]
        # 超过20的数字 → 不是正常章节号，标记为异常
        return f'异常-{ch_key}'

    # 子章节 → 归入父章节（返回父章节标记，由调用方处理）
    if '子章节' in ch_key or ch_key == '子章节':
        return '__sub__'  # 特殊标记：表示这是子章节，需要归属到前一个正常章节

    return ch_key


# 标准中文数字排序权重
CHAPTER_ORDER_WEIGHT = {
    '-': 0, '封面': 0, '__sub__': 1,  # 子章节排在封面之后、一之前（实际会归入父章节）
    '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8,
    '九': 9, '十': 10, '十一': 11, '十二': 12, '十三': 13, '十四': 14, '十五': 15,
    '十六': 16, '十七': 17, '十八': 18, '十九': 19, '二十': 20,
}


def _chapter_sort_key(ch_key):
    """获取章节排序用的数值键"""
    return CHAPTER_ORDER_WEIGHT.get(ch_key, 999)


def _get_display_title(pos, all_positions_in_group=None):
    """
    获取适合展示的章节标题。

    改进策略：
    1. 有正常的 chapter_title 且看起来像章芓名 → "一、投标函"
    2. chapter_title 为空或像正文句子 → 回退到只用章节号+根据上下文推断
    3. 子章节 → 归入父章节处理
    4. 纯数字异常章节 → 归入上一个有效章节
    """
    ch_num = pos.get('chapter_num', '')
    ch_title = pos.get('chapter_title', '')

    # 情况1：有正常标题且长度合适
    if ch_title and len(ch_title) <= 18 and _is_valid_chapter_title(ch_title):
        # 子章节格式特殊处理
        if ch_num == '子章节':
            return f'（{ch_title}）'
        return f"{ch_num}、{ch_title}"

    # 情况2：没有有效标题 → 用章节号，但需要美化
    if ch_num and ch_num not in ('-', '子章节'):
        # 检查是否是中文数字章节号（一/二/三...）
        if ch_num in CHAPTER_ORDER_WEIGHT:
            return f'{ch_num}（未命名章节）'
        # 阿拉伯数字或异常情况 → 签名区
        try:
            int(ch_num)
            return f'签名 / 盖章区'
        except ValueError:
            pass

    # 情况3：默认 — 封面/前置区域
    return '封面 / 前置信息'


def _merge_signature_groups(groups, order):
    """
    将只有签名/盖章字段的孤小组节合并到前一个有实质内容的章节。
    这解决了偏离表末尾签名行被单独列为孤立章节的问题。
    返回 (merged_groups, merged_order)
    """
    merged_groups = dict(groups)
    merged_order = list(order)

    i = 0
    while i < len(merged_order):
        key = merged_order[i]
        grp = merged_groups[key]
        positions = grp['positions']

        # 判断这个小组是否"值得独立成章"
        has_substantial_content = any(
            p['fill_type'] not in ('signature',)
            for p in positions
        )

        # 如果全是签名位且不是第一个组 → 合并到前一节
        if (not has_substantial_content
            and len(positions) <= 6
            and i > 0):

            prev_key = merged_order[i - 1]
            merged_groups[prev_key]['positions'].extend(positions)
            del merged_groups[key]
            merged_order.pop(i)
            # 不递增i，继续检查新的当前位置
        else:
            i += 1

    return merged_groups, merged_order


def generate_fill_report(scan_result, output_path, mapping_data=None):
    """
    生成"投标文件填入需求报告"（Markdown格式，面向用户）。

    改进（v3）：
    1. 合并资料来源对照信息 → 6列统一报表
    2. 显示所有章节（含无填充位置的"格式自拟"章节）
    3. 图片插入区也列入报告

    6列格式：序号 | 填写项 | 数据来源 | 将填入值 | 所在章节 | 状态
    """
    lines = []
    positions = scan_result['fill_positions']
    stats = scan_result['statistics']
    template_info = scan_result.get('template_info', {})
    chapter_summary = scan_result.get('chapter_summary', [])

    # ===== 标题区 =====
    project_name = os.path.basename(output_path).split('_')[0] if output_path else ''
    lines.append(f'# 投标文件填入需求报告 — {project_name}')
    lines.append('')
    lines.append('> 本报告列出投标文件模板中所有需要您关注的位置，包含数据来源信息。')
    lines.append(f'> 共识别 **{stats["total_fill_positions"]}** 处需要处理的内容。')
    lines.append('')

    # ===== 概览统计 =====
    by_type = stats.get('by_type', {})
    sign_count = by_type.get('signature', 0)
    img_count = by_type.get('image', 0)

    # 如果有映射数据，用映射结果更新统计
    missing_count = 0
    matched_count = 0
    pending_count = 0
    if mapping_data:
        matched_count = mapping_data['statistics'].get('matched', 0)
        missing_count = mapping_data['statistics'].get('missing', 0)
        sign_count = mapping_data['statistics'].get('skip', 0)
        img_count = mapping_data['statistics'].get('image_pending', 0)
        pending_count = mapping_data['statistics'].get('pending', 0)

    # 数据来源标签映射
    source_labels = {
        'phase1_report': '🏛️ 招标文件解析',
        'parse_report': '🏛️ 招标文件解析',
        'material_file': '📄 企业资料',
        'text_extraction': '📄 资料文件',
        'ocr_scanned': '📄 OCR扫描',
        'derived': '🧠 系统推断',
        'inferred': '🧠 系统推断',
        'business_rules': '⚙️ 配置值',
        'medium_alias': '📄 资料(别名)',
        'high': '📄 资料(精确)',
        'table_extraction': '📋 表格提取',
        'user_input_required': '⚠️ 需提供',
    }

    lines.append('## 总览')
    lines.append('')
    lines.append('| 类别 | 数量 | 说明 |')
    lines.append('|------|------|------|')
    if mapping_data:
        lines.append(f'| ✅ 可自动填充 | {matched_count} | 已找到数据，系统自动写入 |')
        lines.append(f'| ⚠ 需您填写 | {missing_count} | 未找到数据，需要您手动补充 |')
        if sign_count:
            lines.append(f'| 📝 签名/盖章 | {sign_count} | 请在打印后手写签名并盖章 |')
        if img_count:
            lines.append(f'| 📎 附件材料 | {img_count} | 需要附上相关证件复印件 |')
        table_count = by_type.get('table', 0)
        if table_count or pending_count:
            lines.append(f'| 📋 表格/待确认 | {table_count + pending_count} | 表格将根据资料自动填充，部分待确认 |')
    else:
        auto_count = by_type.get('text', 0) + by_type.get('date', 0) + by_type.get('table', 0)
        lines.append(f'| 文本/日期 | {auto_count} | 文本值或日期 |')
        if sign_count:
            lines.append(f'| 签名/盖章 | {sign_count} | 需要手写签名或盖章 |')
        if img_count:
            lines.append(f'| 图片附件 | {img_count} | 需要插入证件图片 |')
        table_count = by_type.get('table', 0)
        if table_count:
            lines.append(f'| 表格数据 | {table_count} | 人员表/偏离表等 |')
    lines.append('')

    # ===== 构建字段→映射状态的索引 =====
    field_status = {}  # key = (field_name, para_idx) → mapping info
    if mapping_data:
        for m in mapping_data['mapping_table']:
            key = (m['template_field'], m.get('template_para_idx', 0))
            field_status[key] = {
                'status': m['status'],
                'value': m.get('matched_value', ''),
                'source': m.get('matched_source_type', ''),
                'source_label': source_labels.get(m.get('matched_source_type', ''), m.get('matched_source_type', '—')),
            }

    # ===== 按章节分组（含空章节）=====
    lines.append('## 详细清单')
    lines.append('')

    # 构建fill_positions的章节分组
    chapter_order = []
    chapter_groups = {}
    last_normal_ch = None
    cover_para_max = 0

    for pos in positions:
        ch_num = pos['chapter_num']
        top_ch = _get_top_chapter(ch_num)
        para_idx = pos.get('para_idx', 0)

        if top_ch == '-' or (last_normal_ch is None and top_ch != '__sub__'):
            cover_para_max = max(cover_para_max, para_idx)

        if top_ch == '__sub__':
            if last_normal_ch and last_normal_ch != '-':
                target_ch = last_normal_ch
            elif para_idx > cover_para_max + 5:
                target_ch = '-'
                for ch in chapter_order:
                    if ch != '-':
                        target_ch = ch
                        break
                if target_ch == '-' and '一' not in chapter_groups:
                    target_ch = '一'
                    chapter_groups[target_ch] = {
                        'title': '一、投标函及投标报价表',
                        'positions': [],
                        'sub_sections': []
                    }
                    if target_ch not in chapter_order:
                        idx = chapter_order.index('-') + 1 if '-' in chapter_order else 0
                        chapter_order.insert(idx, target_ch)
            else:
                target_ch = '-'
                if target_ch not in chapter_groups:
                    display_title = _get_display_title(pos)
                    chapter_groups[target_ch] = {
                        'title': display_title,
                        'positions': [],
                        'sub_sections': []
                    }
                    chapter_order.append(target_ch)

            chapter_groups[target_ch]['positions'].append(pos)
            sub_name = pos.get('chapter_title', '')
            if sub_name:
                if 'sub_sections' not in chapter_groups[target_ch]:
                    chapter_groups[target_ch]['sub_sections'] = []
                if sub_name not in chapter_groups[target_ch]['sub_sections']:
                    chapter_groups[target_ch]['sub_sections'].append(sub_name)
            continue

        if top_ch not in chapter_groups:
            display_title = _get_display_title(pos)
            chapter_groups[top_ch] = {
                'title': display_title,
                'positions': [],
                'sub_sections': []
            }
            chapter_order.append(top_ch)
        last_normal_ch = top_ch
        chapter_groups[top_ch]['positions'].append(pos)

    # 合并纯签名孤小组节到前一节
    chapter_groups, chapter_order = _merge_signature_groups(chapter_groups, chapter_order)

    # ★★★ 新增：补充空章节（格式自拟章节，如八/九/十）★★★
    # 从chapter_summary中找出没有出现在chapter_groups中的章节
    existing_ch_nums = set(chapter_groups.keys())
    for ch_entry in chapter_summary:
        ch_num = ch_entry['chapter_num']
        ch_title = ch_entry['chapter_title']
        top_ch = _get_top_chapter(ch_num)

        if top_ch not in existing_ch_nums and top_ch != '__sub__' and top_ch != '-':
            # 这个章节没有fill_positions → 格式自拟
            chapter_groups[top_ch] = {
                'title': f"{ch_num}、{ch_title}",
                'positions': [],  # 空的
                'sub_sections': [],
                'is_format_free': True,  # 标记为格式自拟
            }
            chapter_order.append(top_ch)
            existing_ch_nums.add(top_ch)

    # 按中文数字顺序排序
    chapter_order.sort(key=_chapter_sort_key)

    # ===== 生成各章节的表格 =====
    for group_key in chapter_order:
        grp = chapter_groups[group_key]
        positions_in_ch = grp['positions']

        # 章节标题
        section_title = grp['title']
        sub_secs = grp.get('sub_sections', [])
        if sub_secs:
            sub_info = '、'.join(f'（{s}）' for s in sub_secs[:4])
            if len(sub_secs) > 4:
                sub_info += f' 等{len(sub_secs)}个子节'
            section_title = f'{section_title} <small>{sub_info}</small>'

        # ★ 格式自拟章节特殊标注
        if grp.get('is_format_free'):
            lines.append(f'### {section_title}')
            lines.append('')
            lines.append('> ⚠️ **格式自拟** — 本章需要您自行撰写内容，模板中无具体占位符。')
            lines.append('')
            continue

        lines.append(f'### {section_title}')
        lines.append('')

        # ★ 6列合并报表：序号 | 填写项 | 数据来源 | 将填入值 | 状态 | 备注
        lines.append('| 序号 | 填写项 | 数据来源 | 将填入值 | 状态 |')
        lines.append('|------|--------|---------|---------|------|')

        for idx, pos in enumerate(positions_in_ch):
            field_name = pos['field_name']
            fill_type = pos['fill_type']
            para_idx_val = pos.get('para_idx', 0)

            # 从mapping_data获取状态和来源信息
            map_key = (field_name, para_idx_val)
            fs = field_status.get(map_key, None)

            # 如果没有精确匹配，尝试仅用field_name查找（某些字段可能para_idx不一致）
            if not fs:
                for mk, mv in field_status.items():
                    if mk[0] == field_name:
                        fs = mv
                        break

            if fs:
                status_val = fs['status']
                if status_val == 'matched':
                    status_str = '✅ 自动'
                    val_preview = fs['value'][:30] if len(fs['value']) > 30 else fs['value']
                    source_str = fs.get('source_label', '—')
                    hint = f'`{val_preview}`'
                elif status_val == 'missing':
                    status_str = '⚠ 需填写'
                    source_str = '❌ 无数据'
                    hint = pos.get('hint_text', '')[:35] or '请补充'
                elif status_val == 'skip':
                    status_str = '📝 签名'
                    source_str = '—'
                    hint = '请手写签名/盖章'
                elif status_val == 'pending':
                    status_str = '⏳ 待确认'
                    source_str = '⚠️ 需提供'
                    hint = '需确认是否需要填写'
                elif status_val == 'image_pending':
                    status_str = '📎 附件'
                    source_str = '📎 需附证件'
                    hint = pos.get('hint_text', '')[:35] or '需附证件复印件'
                else:
                    status_str = '❓'
                    source_str = '—'
                    hint = ''
            else:
                # 无mapping数据时的默认
                if fill_type == 'signature':
                    status_str = '📝 签名'
                    source_str = '—'
                    hint = '请手写签名/盖章'
                elif fill_type == 'image':
                    status_str = '📎 附件'
                    source_str = '📎 需附证件'
                    hint = pos.get('hint_text', '')[:35] or '需附证件复印件'
                elif fill_type == 'table':
                    status_str = '📋 表格'
                    source_str = '📋 资料提取'
                    hint = pos.get('hint_text', '')[:35] or '根据资料填充'
                elif fill_type == 'date':
                    status_str = '⚠ 日期'
                    source_str = '—'
                    hint = pos.get('hint_text', '')[:35] or '填写日期'
                else:
                    status_str = '⚠ 待填'
                    source_str = '—'
                    hint = pos.get('hint_text', '')[:35] or ''

            lines.append(f'| {idx+1} | {field_name} | {source_str} | {hint} | {status_str} |')
        lines.append('')

    # ===== 操作指引 =====
    lines.append('---')
    lines.append('')
    lines.append('## 操作指南')
    lines.append('')
    lines.append('- **✅ 自动**：系统已找到对应数据，将在生成投标文件时自动填入')
    lines.append('- **⚠ 需填写**：未在现有资料中找到该信息，请您在最终标书中补充')
    lines.append('- **📝 签名**：请在打印后的纸质标书上手写签名并加盖公章')
    lines.append('- **📎 附件**：需要附上相关证件的复印件或粘贴图片')
    lines.append('- **⏳ 待确认**：表格类内容，需您确认是否需要填写')
    lines.append('- **⚠️ 格式自拟**：模板中只有章节标题，正文内容需您自行撰写')
    lines.append('')

    # 写入文件
    report_content = '\n'.join(lines)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(report_content)

    return report_content


# ============================================================
# 入口
# ============================================================

def load_project_config(config_path):
    """加载项目配置文件"""
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    project_name = config.get('project_name', '未命名项目')
    work_dir = os.path.dirname(os.path.abspath(config_path))

    # 解析路径模板
    paths = config.get('paths', {})
    resolved_paths = {}
    for key, path_template in paths.items():
        resolved = path_template.replace('{project_name}', project_name)
        if not os.path.isabs(resolved):
            resolved = os.path.join(work_dir, resolved)
        resolved_paths[key] = resolved

    config['project_name'] = project_name
    config['work_dir'] = work_dir
    config['resolved_paths'] = resolved_paths
    return config


def main():
    parser = argparse.ArgumentParser(description='模板扫描器 — 识别投标文件模板中所有需要填充的位置')
    parser.add_argument('--project-name', required=True, help='项目名称（用于输出文件命名）')
    parser.add_argument('--framework', required=True, help='框架模板路径（.docx）')
    parser.add_argument('--config', default='', help='项目配置文件路径（可选，用于补充路径）')
    parser.add_argument('--parse-report', default='', help='解析报告路径（可选）')
    parser.add_argument('--output', default='', help='输出报告路径（默认: {项目名}_填入需求报告.md）')
    parser.add_argument('--json-output', default='', help='输出JSON路径（默认: {项目名}_扫描数据.json）')

    args = parser.parse_args()

    project_name = args.project_name

    _logger.info('=' * 60)
    _logger.info('  模板扫描器 v7.1 — 投标文件填入需求报告生成')
    _logger.info('=' * 60)

    # 可选：加载配置文件（补充 paths）
    work_dir = os.getcwd()
    rp = {}
    if args.config and os.path.exists(args.config):
        config = load_project_config(args.config)
        rp = config.get('resolved_paths', {})
        work_dir = config.get('work_dir', work_dir)
        _logger.info(f'  配置文件: {args.config}')

    # 确定路径
    framework = args.framework
    parse_report = args.parse_report or rp.get('parse_report', '')
    default_output = os.path.join(work_dir, f'{project_name}_填入需求报告.md')
    output = args.output or default_output

    _logger.info(f'  项目: {project_name}')
    _logger.info(f'  模板: {framework}')
    if parse_report:
        _logger.info(f'  解析报告: {parse_report}')
    _logger.info(f'  输出: {output}')
    print()

    if not os.path.exists(framework):
        _logger.error(f'  [ERROR] 框架模板不存在: {framework}')
        sys.exit(1)

    # 执行扫描
    _logger.info('步骤1: 扫描框架模板...')
    parse_report_to_use = parse_report if parse_report and parse_report.strip() else None
    scan_result = scan_template(framework, parse_report_to_use)

    # 输出扫描统计
    stats = scan_result['statistics']
    _logger.info(f'  ✓ 识别到 {stats["total_fill_positions"]} 个填充位置')
    for t, count in sorted(stats['by_type'].items()):
        _logger.info(f'    - {t}: {count} 处')
    print()

    # 生成报告（如果有映射数据则合并状态信息）
    _logger.info('步骤2: 生成填入需求报告...')
    mapping_data = None
    mapping_json = os.path.join(work_dir, f'{project_name}_映射数据.json')
    if os.path.exists(mapping_json):
        try:
            with open(mapping_json, 'r', encoding='utf-8') as f:
                mapping_data = json.load(f)
            _logger.info('  → 检测到映射数据，将合并匹配状态')
        except Exception:
            pass
    report = generate_fill_report(scan_result, output, mapping_data)
    _logger.info(f'  ✓ 报告已写入: {output}')

    # 输出JSON（默认自动写入）
    default_json = os.path.join(work_dir, f'{project_name}_扫描数据.json')
    json_output = args.json_output or default_json
    with open(json_output, 'w', encoding='utf-8') as f:
        json.dump(scan_result, f, ensure_ascii=False, indent=2)
    _logger.info(f'  ✓ JSON数据已写入: {json_output}')

    print()
    _logger.info('=' * 60)
    _logger.info('  模板扫描完成！')
    _logger.info(f'  输出报告: {output}')
    _logger.info('=' * 60)


if __name__ == '__main__':
    main()
