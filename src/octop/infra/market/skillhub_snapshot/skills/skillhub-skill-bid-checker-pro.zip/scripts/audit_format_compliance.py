#!/usr/bin/env python3
"""
Stage 3: 格式合规比对（8 类检查）

输入：
  --requirements: 招标要求清单 JSON
  --docx: 标书 .docx 路径
  --chapter-index: 标书章节索引 JSON

输出：{项目名}_格式审核Plan.json

8 类检查：
  ① 章节完整性（critical）
  ② 章节分页（major）
  ③ 必填项完整性（critical）
  ④ 签字盖章位（critical）
  ⑤ 标签格式（minor）
  ⑥ 图片合规（major）
  ⑦ 字段一致性（major）
  ⑧ 资质章节完整性（major）

复用模块：
  - format_guardrails (标签空格/章节分页/签字位/锚点残留)
  - image_format.verify_image_sizing (图片尺寸)
  - template_review.detect_qualification_layout (资质章节识别)
  - requirement_mapper.detect_fixed_chapters (固定章节识别)
"""
import argparse
import json
import sys
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any, Optional
from datetime import datetime

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger
from bid_checker.core import format_guardrails
from bid_checker.core import image_format
from bid_checker.core import template_review
from bid_checker.core import extract_images
from docx import Document

_logger = get_logger('audit_format_compliance')


@dataclass
class AuditItem:
    check_id: str
    category: str
    severity: str  # critical / major / minor / info
    rule_id: str
    requirement: str
    actual: str
    status: str  # compliant / non_compliant / not_applicable
    evidence: str
    suggestion: Optional[str]
    page_ref: str = ''


@dataclass
class AuditPlan:
    audit_id: str
    audit_time: str
    total_checks: int
    passed: int
    failed: int
    failures_by_severity: Dict[str, int]
    items: List[AuditItem]


# ============= 检查 1: 章节完整性 =============
def check_chapter_completeness(requirements: Dict, chapter_index: Dict) -> List[AuditItem]:
    """检查招标要求的所有章节是否都存在于标书中"""
    _logger.info('  [检查1] 章节完整性...')
    items = []

    required_chapters = requirements.get('chapter_requirements', [])
    actual_chapters = chapter_index.get('chapters', [])

    # 标书所有标题拼接（用于关键词匹配）
    all_titles_text = ' '.join(ch.get('title', '') for ch in actual_chapters)
    all_titles_lower = all_titles_text

    for req_ch in required_chapters:
        if not req_ch.get('must_be_present', True):
            continue

        evidence_keywords = req_ch.get('evidence_keywords', [])
        title = req_ch.get('title', '')

        # 在标书标题中找匹配
        matched_chapter = None
        for actual_ch in actual_chapters:
            actual_title = actual_ch.get('title', '')
            if any(kw in actual_title for kw in evidence_keywords) or title in actual_title:
                matched_chapter = actual_ch
                break

        if matched_chapter:
            items.append(AuditItem(
                check_id=f'chk_{len(items)+1:03d}',
                category='章节完整性',
                severity='critical' if req_ch.get('required') else 'major',
                rule_id=req_ch.get('chapter_id', ''),
                requirement=f"章节「{title}」必须存在",
                actual=f"已存在，位于第 {matched_chapter.get('page_start', '?')}-{matched_chapter.get('page_end', '?')} 页",
                status='compliant',
                evidence=f"章节标题：{matched_chapter.get('title', '')}",
                suggestion=None,
                page_ref=f"{matched_chapter.get('page_start', '')}-{matched_chapter.get('page_end', '')}",
            ))
        else:
            items.append(AuditItem(
                check_id=f'chk_{len(items)+1:03d}',
                category='章节完整性',
                severity='critical' if req_ch.get('required') else 'major',
                rule_id=req_ch.get('chapter_id', ''),
                requirement=f"章节「{title}」必须存在",
                actual="未找到对应章节",
                status='non_compliant',
                evidence=f"在标书所有标题中未匹配到关键词：{evidence_keywords}",
                suggestion=f"补充「{title}」章节，建议参考招标文件中的投标文件格式要求",
                page_ref='',
            ))

    return items


# ============= 检查 2: 章节分页 =============
def check_chapter_page_breaks(doc, requirements: Dict) -> List[AuditItem]:
    """检查每个章节标题前是否强制分页"""
    _logger.info('  [检查2] 章节分页...')
    items = []

    # 调用 format_guardrails 的 ensure_chapter_page_breaks 检查模式
    # 但只检查，不修复
    chapter_violations = []

    for i, para in enumerate(doc.paragraphs):
        text = (para.text or '').strip()
        if not text:
            continue

        # 判断是否像章节标题
        from docx.oxml.ns import qn
        style_name = para.style.name if para.style else ''
        is_heading = style_name.startswith('Heading') or style_name in ('Title', 'Subtitle')

        pPr = para._element.find(qn('w:pPr'))
        has_page_break_before = False
        if pPr is not None:
            pageBreakBefore = pPr.find(qn('w:pageBreakBefore'))
            if pageBreakBefore is not None:
                has_page_break_before = True

        # 也检查前一段是否有分页符
        has_manual_break = False
        if i > 0:
            prev_para = doc.paragraphs[i-1]
            for run in prev_para.runs:
                for br in run._element.findall(qn('w:br')):
                    if br.get(qn('w:type')) == 'page':
                        has_manual_break = True
                        break

        if is_heading and not has_page_break_before and not has_manual_break and i > 0:
            # 第一个章节标题（i=0）不要求分页
            chapter_violations.append({
                'para_index': i,
                'title': text[:50],
                'page_break_before': has_page_break_before,
                'manual_break': has_manual_break,
            })

    # 估算页码
    from scripts.slice_chapters import estimate_page_breaks
    try:
        page_starts = estimate_page_breaks(doc)
    except Exception:
        page_starts = [1] * len(doc.paragraphs)

    for v in chapter_violations:
        page = page_starts[v['para_index']] if v['para_index'] < len(page_starts) else '?'
        items.append(AuditItem(
            check_id=f'chk_{len(items)+1:03d}',
            category='章节分页',
            severity='major',
            rule_id='rule_page_break',
            requirement="每个章节标题前必须强制分页",
            actual=f"章节「{v['title']}」前未设分页符",
            status='non_compliant',
            evidence=f"段落 {v['para_index']}，页 {page}",
            suggestion=f"在章节标题「{v['title']}」前插入分页符，或设置段落属性'段前分页'",
            page_ref=str(page),
        ))

    # 通过项
    # 统计所有标题数 - 违规数 = 通过数
    total_headings = sum(1 for p in doc.paragraphs
                        if p.style and p.style.name and
                        (p.style.name.startswith('Heading') or p.style.name in ('Title', 'Subtitle')))
    passed = max(0, total_headings - len(chapter_violations))
    for i in range(passed):
        items.append(AuditItem(
            check_id=f'chk_{len(items)+1:03d}',
            category='章节分页',
            severity='major',
            rule_id='rule_page_break',
            requirement="每个章节标题前必须强制分页",
            actual="已设置分页符",
            status='compliant',
            evidence="",
            suggestion=None,
            page_ref='',
        ))

    return items


# ============= 检查 3: 必填项完整性 =============
def check_required_fields(doc, requirements: Dict, chapter_index: Dict) -> List[AuditItem]:
    """检查必填字段是否都已填写"""
    _logger.info('  [检查3] 必填项完整性...')
    items = []

    required_fields = requirements.get('required_fields', [])

    # 收集所有段落文本
    all_text = '\n'.join(p.text or '' for p in doc.paragraphs)
    # 加上表格文本
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                all_text += '\n' + (cell.text or '')

    import re

    for field in required_fields:
        label = field.get('label', '')
        appears_in = field.get('appears_in', [])

        # 查找所有形如"标签：值"或"标签:值"的位置
        # 值不能为空，且不能只是空白或下划线
        pattern = re.compile(
            rf'{re.escape(label)}\s*[：:]\s*([^\s（(【\[<_]+)'
        )
        matches = pattern.findall(all_text)

        # 过滤掉无效值（全是下划线、空白、占位符）
        valid_values = []
        for m in matches:
            m_clean = m.strip()
            if not m_clean:
                continue
            if re.match(r'^[_\s]+$', m_clean):
                continue
            if m_clean in ('XXX', 'xxx', '...', '【】', '[]', '（）', '()'):
                continue
            valid_values.append(m_clean)

        if valid_values:
            items.append(AuditItem(
                check_id=f'chk_{len(items)+1:03d}',
                category='必填项完整性',
                severity='critical',
                rule_id=field.get('field_id', ''),
                requirement=f"必填字段「{label}」必须填写（出现在：{', '.join(appears_in)}）",
                actual=f"已填写，值示例：{valid_values[0][:30]}",
                status='compliant',
                evidence=f"共找到 {len(valid_values)} 处填写",
                suggestion=None,
                page_ref='',
            ))
        else:
            items.append(AuditItem(
                check_id=f'chk_{len(items)+1:03d}',
                category='必填项完整性',
                severity='critical',
                rule_id=field.get('field_id', ''),
                requirement=f"必填字段「{label}」必须填写（出现在：{', '.join(appears_in)}）",
                actual="未填写或填写为空白/占位符",
                status='non_compliant',
                evidence=f"在全文中未找到「{label}：实际值」的填写",
                suggestion=f"请填写「{label}」，应出现在：{', '.join(appears_in)}",
                page_ref='',
            ))

    return items


# ============= 检查 4: 签字盖章位 =============
def check_signature_positions(doc) -> List[AuditItem]:
    """检查签字/盖章位是否被误填"""
    _logger.info('  [检查4] 签字盖章位...')
    items = []

    # 调用 format_guardrails.verify_signatures_empty
    try:
        sig_result = format_guardrails.verify_signatures_empty(doc)
        if isinstance(sig_result, dict):
            warnings = sig_result.get('warnings', [])
        elif isinstance(sig_result, list):
            warnings = sig_result
        else:
            warnings = []

        for w in warnings:
            if isinstance(w, dict):
                items.append(AuditItem(
                    check_id=f'chk_{len(items)+1:03d}',
                    category='签字盖章位',
                    severity='critical',
                    rule_id='rule_signature',
                    requirement="签字/盖章位必须留空（待现场签字盖章）",
                    actual=f"签字位被填入：{w.get('filled_text', '?')[:30]}",
                    status='non_compliant',
                    evidence=f"段落 {w.get('para_index', '?')}：{w.get('context', '')[:80]}",
                    suggestion="删除签字位的填写内容，签字位应留空",
                    page_ref=str(w.get('page', '')),
                ))
            else:
                items.append(AuditItem(
                    check_id=f'chk_{len(items)+1:03d}',
                    category='签字盖章位',
                    severity='critical',
                    rule_id='rule_signature',
                    requirement="签字/盖章位必须留空",
                    actual=str(w)[:100],
                    status='non_compliant',
                    evidence="",
                    suggestion="检查并清理签字位",
                    page_ref='',
                ))

        # 通过项
        if not warnings:
            items.append(AuditItem(
                check_id=f'chk_{len(items)+1:03d}',
                category='签字盖章位',
                severity='critical',
                rule_id='rule_signature',
                requirement="签字/盖章位必须留空",
                actual="所有签字/盖章位均正确留空",
                status='compliant',
                evidence="",
                suggestion=None,
                page_ref='',
            ))
    except Exception as e:
        _logger.warning(f'  签字位检查异常：{e}')
        items.append(AuditItem(
            check_id=f'chk_{len(items)+1:03d}',
            category='签字盖章位',
            severity='info',
            rule_id='rule_signature',
            requirement="签字/盖章位检查",
            actual=f"检查异常：{e}",
            status='not_applicable',
            evidence="",
            suggestion=None,
            page_ref='',
        ))

    return items


# ============= 检查 5: 标签格式 =============
def check_label_format(doc) -> List[AuditItem]:
    """检查标签冒号空格、占位符残留"""
    _logger.info('  [检查5] 标签格式...')
    items = []

    import re
    # 5.1: 标签冒号后多余空格
    space_violations = []
    for i, para in enumerate(doc.paragraphs):
        text = para.text or ''
        # 模式："标签：  值"（冒号后2个或更多空格）
        matches = re.findall(r'[\u4e00-\u9fa5]{2,8}[：:]\s{2,}\S', text)
        for m in matches:
            space_violations.append({
                'para_index': i,
                'text': m,
            })

    for v in space_violations:
        items.append(AuditItem(
            check_id=f'chk_{len(items)+1:03d}',
            category='标签格式',
            severity='minor',
            rule_id='rule_label_space',
            requirement="标签冒号后不应有多余空格",
            actual=f"标签「{v['text']}」冒号后有多余空格",
            status='non_compliant',
            evidence=f"段落 {v['para_index']}",
            suggestion="删除冒号后的多余空格",
            page_ref='',
        ))

    # 5.2: 残留锚点 token
    try:
        residue_result = format_guardrails.verify_no_anchor_residue(doc)
        if isinstance(residue_result, dict):
            residues = residue_result.get('residues', [])
        elif isinstance(residue_result, list):
            residues = residue_result
        else:
            residues = []

        for r in residues[:20]:  # 最多报告 20 个
            if isinstance(r, dict):
                items.append(AuditItem(
                    check_id=f'chk_{len(items)+1:03d}',
                    category='标签格式',
                    severity='info',
                    rule_id='rule_anchor_residue',
                    requirement="不应残留 [[FILL:]]/[[SLOT:]]/[[ANCHOR:]] 等占位符 token",
                    actual=f"残留 token：{r.get('token', '?')}",
                    status='non_compliant',
                    evidence=f"段落 {r.get('para_index', '?')}",
                    suggestion="清除所有 [[FILL:]]/[[SLOT:]]/[[ANCHOR:]] token",
                    page_ref='',
                ))
    except Exception as e:
        _logger.warning(f'  锚点残留检查异常：{e}')

    # 5.3: 通过项（如果没有违规）
    if not space_violations:
        items.append(AuditItem(
            check_id=f'chk_{len(items)+1:03d}',
            category='标签格式',
            severity='minor',
            rule_id='rule_label_space',
            requirement="标签冒号后不应有多余空格",
            actual="所有标签格式正确",
            status='compliant',
            evidence="",
            suggestion=None,
            page_ref='',
        ))

    return items


# ============= 检查 6: 图片合规 =============
def check_image_compliance(doc) -> List[AuditItem]:
    """检查图片尺寸是否合规"""
    _logger.info('  [检查6] 图片合规...')
    items = []

    try:
        sizing_result = image_format.verify_image_sizing(doc)
        if isinstance(sizing_result, dict):
            warnings = sizing_result.get('warnings', [])
            stats = sizing_result.get('stats', {})
        else:
            warnings = sizing_result if isinstance(sizing_result, list) else []
            stats = {}

        for w in warnings:
            if isinstance(w, dict):
                items.append(AuditItem(
                    check_id=f'chk_{len(items)+1:03d}',
                    category='图片合规',
                    severity='major',
                    rule_id='rule_image_sizing',
                    requirement="图片不应越界页面或单元格",
                    actual=f"图片问题：{w.get('issue', '?')}",
                    status='non_compliant',
                    evidence=f"段落 {w.get('para_index', '?')}，图片 {w.get('image_path', '?')}",
                    suggestion="调整图片尺寸，确保不越界",
                    page_ref='',
                ))

        # 通过项
        if not warnings and stats:
            items.append(AuditItem(
                check_id=f'chk_{len(items)+1:03d}',
                category='图片合规',
                severity='major',
                rule_id='rule_image_sizing',
                requirement="图片不应越界页面或单元格",
                actual=f"共 {stats.get('total_images', 0)} 张图片均合规",
                status='compliant',
                evidence=f"统计：{stats}",
                suggestion=None,
                page_ref='',
            ))
    except Exception as e:
        _logger.warning(f'  图片合规检查异常：{e}')
        items.append(AuditItem(
            check_id=f'chk_{len(items)+1:03d}',
            category='图片合规',
            severity='info',
            rule_id='rule_image_sizing',
            requirement="图片合规检查",
            actual=f"检查异常：{e}",
            status='not_applicable',
            evidence="",
            suggestion=None,
            page_ref='',
        ))

    return items


# ============= 检查 7: 字段一致性 =============
def check_field_consistency(doc, requirements: Dict) -> List[AuditItem]:
    """检查多处出现的字段值是否一致（项目名/编号/金额等）"""
    _logger.info('  [检查7] 字段一致性...')
    items = []

    import re
    from collections import defaultdict

    required_fields = requirements.get('required_fields', [])
    must_consistent_fields = [f for f in required_fields if f.get('must_be_consistent', True)]

    # 收集所有文本
    all_text_blocks = []
    for p in doc.paragraphs:
        if p.text:
            all_text_blocks.append(('para', p.text))
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text:
                    all_text_blocks.append(('table', cell.text))

    for field in must_consistent_fields:
        label = field.get('label', '')

        # 查找所有"标签：值"
        pattern = re.compile(rf'{re.escape(label)}\s*[：:]\s*([^\s，,。；;（(【\[<_]+)')
        values_found = set()
        for _, text in all_text_blocks:
            matches = pattern.findall(text)
            for m in matches:
                m_clean = m.strip()
                if m_clean and not re.match(r'^[_\s]+$', m_clean):
                    values_found.add(m_clean)

        if len(values_found) > 1:
            values_str = ' / '.join(list(values_found)[:5])
            items.append(AuditItem(
                check_id=f'chk_{len(items)+1:03d}',
                category='字段一致性',
                severity='major',
                rule_id='rule_consistency',
                requirement=f"字段「{label}」多处出现必须一致",
                actual=f"发现 {len(values_found)} 个不同值：{values_str}",
                status='non_compliant',
                evidence=f"不一致的值：{values_str}",
                suggestion=f"统一「{label}」的所有出现为同一个值",
                page_ref='',
            ))
        elif len(values_found) == 1:
            items.append(AuditItem(
                check_id=f'chk_{len(items)+1:03d}',
                category='字段一致性',
                severity='major',
                rule_id='rule_consistency',
                requirement=f"字段「{label}」多处出现必须一致",
                actual=f"一致：{list(values_found)[0][:30]}",
                status='compliant',
                evidence="",
                suggestion=None,
                page_ref='',
            ))
        # 0 个值的情况在必填项检查中已报告，不重复

    return items


# ============= 检查 8: 资质章节完整性 =============
def check_qualification_completeness(doc, chapter_index: Dict) -> List[AuditItem]:
    """检查资质证明章节是否完整"""
    _logger.info('  [检查8] 资质章节完整性...')
    items = []

    try:
        # 调用 template_review.detect_qualification_layout
        # 但这个函数需要 docx_path，我们从内存 doc 反推
        # 简化：在章节索引中找资质章节
        chapters = chapter_index.get('chapters', [])

        # 资质章节关键词
        qual_keywords = ['资质', '资格', '证明文件', '资格审查']
        qual_chapters = []
        for ch in chapters:
            title = ch.get('title', '')
            if any(kw in title for kw in qual_keywords):
                qual_chapters.append(ch)

        # 期望的资质子项
        expected_subitems = [
            '营业执照', '组织机构代码', '税务登记', '财务审计', '纳税证明',
            '社保证明', '信用查询', '无违法记录', '授权委托书', '身份证',
        ]

        if qual_chapters:
            # 拼接资质章节全文
            qual_full_text = ''
            for ch in qual_chapters:
                qual_full_text += '\n' + ch.get('full_text', '')

            # 检查每个期望子项
            for sub in expected_subitems:
                if sub in qual_full_text:
                    items.append(AuditItem(
                        check_id=f'chk_{len(items)+1:03d}',
                        category='资质章节完整性',
                        severity='major',
                        rule_id='rule_qualification',
                        requirement=f"资质章节应包含「{sub}」",
                        actual=f"已包含",
                        status='compliant',
                        evidence=f"在资质章节中找到「{sub}」",
                        suggestion=None,
                        page_ref=','.join(str(ch.get('page_start', '')) for ch in qual_chapters),
                    ))
                else:
                    items.append(AuditItem(
                        check_id=f'chk_{len(items)+1:03d}',
                        category='资质章节完整性',
                        severity='major',
                        rule_id='rule_qualification',
                        requirement=f"资质章节应包含「{sub}」",
                        actual="未找到",
                        status='non_compliant',
                        evidence=f"在资质章节中未找到「{sub}」",
                        suggestion=f"补充「{sub}」相关资质材料",
                        page_ref='',
                    ))
        else:
            items.append(AuditItem(
                check_id=f'chk_{len(items)+1:03d}',
                category='资质章节完整性',
                severity='critical',
                rule_id='rule_qualification',
                requirement="标书应包含资质证明文件章节",
                actual="未找到资质章节",
                status='non_compliant',
                evidence="在章节索引中未找到含'资质/资格/证明文件'关键词的章节",
                suggestion="补充资质证明文件章节",
                page_ref='',
            ))
    except Exception as e:
        _logger.warning(f'  资质章节检查异常：{e}')
        items.append(AuditItem(
            check_id=f'chk_{len(items)+1:03d}',
            category='资质章节完整性',
            severity='info',
            rule_id='rule_qualification',
            requirement="资质章节检查",
            actual=f"检查异常：{e}",
            status='not_applicable',
            evidence="",
            suggestion=None,
            page_ref='',
        ))

    return items


def main():
    parser = argparse.ArgumentParser(description='Stage 3: 格式合规比对（8 类检查）')
    parser.add_argument('--requirements', required=True, help='招标要求清单 JSON')
    parser.add_argument('--docx', required=True, help='标书 .docx 路径')
    parser.add_argument('--chapter-index', required=True, help='标书章节索引 JSON')
    parser.add_argument('--output', required=True, help='输出审核 Plan JSON')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取招标要求：{args.requirements}')
    with open(args.requirements, 'r', encoding='utf-8') as f:
        requirements = json.load(f)

    _logger.info(f'读取章节索引：{args.chapter_index}')
    with open(args.chapter_index, 'r', encoding='utf-8') as f:
        chapter_index = json.load(f)

    _logger.info(f'读取标书：{args.docx}')
    doc = Document(args.docx)

    # 执行 8 类检查
    all_items = []
    _logger.info('开始执行 8 类格式合规检查...')

    all_items.extend(check_chapter_completeness(requirements, chapter_index))
    all_items.extend(check_chapter_page_breaks(doc, requirements))
    all_items.extend(check_required_fields(doc, requirements, chapter_index))
    all_items.extend(check_signature_positions(doc))
    all_items.extend(check_label_format(doc))
    all_items.extend(check_image_compliance(doc))
    all_items.extend(check_field_consistency(doc, requirements))
    all_items.extend(check_qualification_completeness(doc, chapter_index))

    # 统计
    total = len(all_items)
    passed = sum(1 for it in all_items if it.status == 'compliant')
    failed = sum(1 for it in all_items if it.status == 'non_compliant')

    failures_by_severity = {
        'critical': sum(1 for it in all_items if it.status == 'non_compliant' and it.severity == 'critical'),
        'major': sum(1 for it in all_items if it.status == 'non_compliant' and it.severity == 'major'),
        'minor': sum(1 for it in all_items if it.status == 'non_compliant' and it.severity == 'minor'),
        'info': sum(1 for it in all_items if it.status == 'non_compliant' and it.severity == 'info'),
    }

    plan = AuditPlan(
        audit_id=f'audit_{datetime.now().strftime("%Y%m%d_%H%M%S")}',
        audit_time=datetime.now().isoformat(),
        total_checks=total,
        passed=passed,
        failed=failed,
        failures_by_severity=failures_by_severity,
        items=all_items,
    )

    # 输出
    output = asdict(plan)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  总检查项：{total}')
    _logger.info(f'  通过：{passed}')
    _logger.info(f'  不合规：{failed}')
    _logger.info(f'  按严重度：critical={failures_by_severity["critical"]}, '
                f'major={failures_by_severity["major"]}, '
                f'minor={failures_by_severity["minor"]}, '
                f'info={failures_by_severity["info"]}')


if __name__ == '__main__':
    main()
