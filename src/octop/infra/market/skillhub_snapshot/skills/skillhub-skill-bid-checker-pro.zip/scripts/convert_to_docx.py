#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文件格式统一转换工具 (v20.2)
============================

把任意招标文件格式统一转成 .docx，作为 Stage 2 生成框架前的预处理步骤。

支持的输入格式：
  - .docx  → 直接通过（无需转换）
  - .doc   → LibreOffice 转 .docx（保真度高，推荐）
  - .pdf   → 默认拒绝（保真度差），传 --force 才强制转换

转换引擎优先级（.doc → .docx）：
  1. LibreOffice / soffice（跨平台，保真度最高）
  2. win32com（仅 Windows + MS Word）
  3. antiword（仅提取文本，保底）
  4. docx2txt（仅提取文本，最后兜底）

用法：
    python convert_to_docx.py --input "招标文件.doc" --output "招标文件.docx"
    python convert_to_docx.py --input "招标文件.pdf" --output "招标文件.docx" --force
    python convert_to_docx.py --input "招标文件.docx"  # 已是 .docx，直接通过

退出码：
    0 = 转换成功（或无需转换）
    1 = 转换失败（如 PDF 未传 --force，或所有引擎都不可用）
"""

import os
import sys
import argparse
from pathlib import Path

# 加入项目根目录到 sys.path
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.convert_to_docx")
except ImportError:
    import logging
    _logger = logging.getLogger("convert_to_docx")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)


def convert_to_docx(input_path: str, output_path: str = None, force_pdf: bool = False) -> str:
    """
    把任意格式文件转成 .docx。

    Args:
        input_path: 输入文件路径（.docx / .doc / .pdf）
        output_path: 输出 .docx 路径（可选，默认同输入文件名 + .docx）
        force_pdf: 是否强制转换 PDF（默认 False，PDF 会被拒绝）

    Returns:
        .docx 文件路径

    Raises:
        FileNotFoundError: 输入文件不存在
        ValueError: 不支持的文件格式
        RuntimeError: 转换失败
    """
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"输入文件不存在: {input_path}")

    input_lower = input_path.lower()

    # 设置默认输出路径
    if output_path is None:
        base = os.path.splitext(input_path)[0]
        output_path = base + '.docx'

    # .docx 直接通过
    if input_lower.endswith('.docx'):
        _logger.info(f"✓ 输入文件已是 .docx 格式，无需转换: {input_path}")
        if input_path != output_path:
            import shutil
            shutil.copy2(input_path, output_path)
        return output_path

    # .doc 用多引擎高保真转换（MS Word COM / WPS COM / LibreOffice / Aspose，兜底仅文本）
    if input_lower.endswith('.doc'):
        _logger.info(f"🔄 检测到 .doc 旧版 Word 文件，自动转换为 .docx...")
        try:
            from bid_checker.utils.doc_to_docx import convert_doc_to_docx
            output_dir = os.path.dirname(os.path.abspath(output_path)) or '.'
            result, _, fidelity = convert_doc_to_docx(input_path, output_dir)
            # convert_doc_to_docx 输出文件名是 input.basename + .docx，可能跟 output_path 不同
            if os.path.abspath(result) != os.path.abspath(output_path):
                import shutil
                shutil.move(result, output_path)
            if fidelity == 'text_only':
                _logger.warning(
                    "⚠ 本次转换为【仅文本兜底】，已丢失表格/图片/样式等结构！\n"
                    "  标书审查中涉及表格（报价、技术参数）的结论须逐页人工复核。\n"
                    "  建议：安装 Microsoft Office / WPS / LibreOffice 后重转，或用 Word 手动另存为 .docx。")
            _logger.info(f"✓ .doc → .docx 转换成功（保真度={fidelity}）: {output_path}")
            return output_path
        except Exception as e:
            raise RuntimeError(
                f".doc → .docx 转换失败: {e}\n"
                f"解决方案（任选高保真其一）：\n"
                f"  1. 安装 Microsoft Office（Windows 双击 .doc 另存为 .docx 最稳）\n"
                f"  2. 安装 WPS Office（Windows）\n"
                f"  3. 安装 LibreOffice: https://www.libreoffice.org/download/\n"
                f"  4. pip install aspose-words（沙箱可装，程序化高保真）\n"
                f"  5. 或手动用 Word/WPS 打开 .doc 另存为 .docx 后重新运行"
            ) from e

    # .pdf 默认拒绝，传 force_pdf 才转
    if input_lower.endswith('.pdf'):
        if not force_pdf:
            _logger.error("")
            _logger.error("❌ 检测到 PDF 文件，默认拒绝自动转换！")
            _logger.error("")
            _logger.error("   原因：PDF 转 Word 格式无法保真，会导致框架格式错乱")
            _logger.error("")
            _logger.error("   推荐做法（按优先级）：")
            _logger.error("")
            _logger.error("   方式 A（推荐）：用 Microsoft Word 或 WPS 打开 PDF")
            _logger.error("     1. 双击 PDF 用 Word 打开（Word 2016+ 支持）")
            _logger.error("     2. Word 提示'将 PDF 转换为可编辑的 Word 文档'，点确定")
            _logger.error("     3. 另存为 .docx，把新文件路径告诉 AI")
            _logger.error("")
            _logger.error("   方式 B：只复制'投标文件格式'章节到新 Word")
            _logger.error("     1. 用 Adobe Acrobat / WPS 打开 PDF")
            _logger.error("     2. 找到'投标文件格式'章节，复制全部内容")
            _logger.error("     3. 新建 Word 粘贴，另存为 .docx")
            _logger.error("")
            _logger.error("   方式 C（不推荐）：强制自动转换")
            _logger.error("     传 --force 参数：python convert_to_docx.py --input x.pdf --output x.docx --force")
            _logger.error("     ⚠️ 转换保真度差，生成的框架可能需要大量人工修复")
            _logger.error("")
            raise RuntimeError("PDF 默认拒绝转换，传 force_pdf=True 或 --force 强制转换")

        _logger.warning("⚠️ 警告：您启用了 --force，将强制用 pdf2docx 转换 PDF")
        _logger.warning("   PDF 转 Word 保真度差，建议优先用 Word/WPS 手动转")
        try:
            sys.path.insert(0, str(SCRIPT_DIR))
            from pdf_to_word import convert_pdf_to_word
            convert_pdf_to_word(input_path, output_path)
            _logger.info(f"✓ PDF → .docx 强制转换完成: {output_path}")
            return output_path
        except Exception as e:
            raise RuntimeError(
                f"PDF → .docx 强制转换失败: {e}\n"
                f"请手动用 Word/WPS 打开 PDF 另存为 .docx"
            ) from e

    raise ValueError(f"不支持的文件格式: {input_path}（仅支持 .docx / .doc / .pdf）")


def main():
    parser = argparse.ArgumentParser(
        description='文件格式统一转换工具 (v20.3) — 把任意招标文件转成 .docx（多引擎高保真优先）',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例：
  # .docx 直接通过
  python convert_to_docx.py --input 招标文件.docx

  # .doc 自动转（多引擎高保真，按 MS Word COM → WPS → LibreOffice → Aspose 顺序）
  python convert_to_docx.py --input 招标文件.doc --output 招标文件.docx

  # 自检各转换引擎可用性
  python convert_to_docx.py --selftest

  # .pdf 默认拒绝，需 --force
  python convert_to_docx.py --input 招标文件.pdf --output 招标文件.docx --force
        """,
    )
    parser.add_argument('--input', help='输入文件路径（.docx / .doc / .pdf）')
    parser.add_argument('--output', help='输出 .docx 路径（可选，默认同输入文件名）')
    parser.add_argument('--force', action='store_true', help='强制转换 PDF（保真度差，不推荐）')
    parser.add_argument('--selftest', action='store_true', help='自检各转换引擎可用性')
    args = parser.parse_args()

    if args.selftest:
        from bid_checker.utils.doc_to_docx import detect_available_engines
        eng = detect_available_engines()
        print("=== 文档转换引擎自检 ===")
        high = []
        for k, v in eng.items():
            mark = "✓ 可用" if v else "✗ 不可用"
            print(f"  {k}: {mark}")
            if v and k in ('ms_word_com', 'wps_com', 'libreoffice', 'aspose'):
                high.append(k)
        if high:
            print(f"\n→ 将使用【高保真】引擎：{', '.join(high)}（保留表格/样式）")
        else:
            print("\n⚠ 无高保真引擎！将落入【仅文本】兜底（结构有损，审查结论须人工复核）。")
            print("  建议安装其一：Microsoft Office / WPS / LibreOffice / `pip install aspose-words`")
        sys.exit(0)

    if not args.input:
        parser.error("请提供 --input，或使用 --selftest")

    try:
        result = convert_to_docx(args.input, args.output, force_pdf=args.force)
        print(f"\n✓ 转换成功: {result}")
        sys.exit(0)
    except Exception as e:
        _logger.error(f"\n❌ {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
