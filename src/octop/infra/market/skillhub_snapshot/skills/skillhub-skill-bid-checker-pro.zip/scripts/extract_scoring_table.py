#!/usr/bin/env python3
"""
Stage 1.4: 提取评分表
从 parse_bid_document.py 解析的 JSON 数据中，提取评分表。

输入：{项目名}_招标解析数据.json
输出：{项目名}_评分表.json

评分表结构：
  total_score: 总分（默认 100）
  scoring_items: [
    {
      item_id, category(商务分/技术分/价格分/其他), title, max_score,
      criteria, type(objective/subjective), evidence_keywords, sub_criteria, weight
    }
  ]
"""
import argparse
import json
import re
import subprocess
import sys
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any, Optional

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger

_logger = get_logger('extract_scoring_table')

# 评分项常见关键词
SCORING_KEYWORDS = [
    '评分', '评标', '评审', '评议', '打分', '分值', '得分', '满分',
    '商务分', '技术分', '价格分', '资信分', '服务分',
    '主观分', '客观分', '加分项', '扣分项',
]

# 评分类别关键词
CATEGORY_KEYWORDS = {
    '商务分': ['商务分', '商务部分', '商务评审', '资质分'],
    '技术分': ['技术分', '技术部分', '技术评审', '技术方案'],
    '价格分': ['价格分', '报价分', '投标报价', '价格评审'],
    '资信分': ['资信分', '资信评审', '业绩分', '信誉分'],
    '服务分': ['服务分', '售后服务分', '服务方案分'],
}


@dataclass
class SubCriteria:
    desc: str
    score: float


@dataclass
class ScoringItem:
    item_id: str
    category: str
    title: str
    max_score: float
    criteria: str
    type: str  # 'objective' / 'subjective'
    evidence_keywords: List[str]
    sub_criteria: List[SubCriteria] = field(default_factory=list)
    weight: float = 1.0


@dataclass
class ScoringTable:
    total_score: float
    scoring_items: List[ScoringItem]
    extraction_confidence: str = 'medium'
    low_confidence_items: List[str] = field(default_factory=list)


def find_scoring_section(parse_data: Dict) -> Optional[str]:
    """从解析数据中找到评分章节文本"""
    chapter_map = parse_data.get('chapter_map', [])
    chapter_texts = parse_data.get('chapter_texts', {})
    key_chapters = parse_data.get('key_chapters_detected', {})

    # 1. 通过 key_chapters_detected 找"评标方法/评分"章节
    for ch_name, ch_title in key_chapters.items() if isinstance(key_chapters, dict) else []:
        if any(kw in str(ch_name) or kw in str(ch_title) for kw in ['评标', '评分', '评审', '评议']):
            # chapter_texts 的 key 可能是章节标题或章节名
            text = chapter_texts.get(ch_name, '') or chapter_texts.get(ch_title, '')
            if text:
                _logger.info(f'  找到评分章节：{ch_title}')
                return text

    # 2. 通过 chapter_map 找评分章节
    if isinstance(chapter_map, list):
        for ch_info in chapter_map:
            title = ch_info.get('title', '') if isinstance(ch_info, dict) else str(ch_info)
            if any(kw in title for kw in ['评标', '评分', '评审', '评议']):
                text = chapter_texts.get(title, '')
                if text:
                    _logger.info(f'  找到评分章节：{title}')
                    return text

    # 3. 兜底：拼接所有章节文本，搜索评分关键词
    full_text = ''
    if isinstance(chapter_texts, dict):
        full_text = ' '.join(chapter_texts.values())
    elif isinstance(chapter_texts, list):
        full_text = ' '.join(str(t) for t in chapter_texts)

    for kw in SCORING_KEYWORDS:
        idx = full_text.find(kw)
        if idx >= 0:
            start = max(0, idx - 500)
            end = min(len(full_text), idx + 3000)
            _logger.info(f'  通过关键词 "{kw}" 定位评分章节')
            return full_text[start:end]

    return None


def extract_scoring_via_llm(scoring_text: str) -> Optional[Dict]:
    """通过 z-ai CLI 调用 LLM 提取评分表"""
    prompt = f"""请从以下招标文件评分章节文本中，提取评分表信息。

要求：
1. 识别每一个评分项，包括：评分类别（商务分/技术分/价格分/资信分/服务分）、评分项名称、分值、评分标准
2. 区分客观分（如"提供营业执照得5分"）和主观分（如"技术方案完整性，优15分良10分中5分"）
3. 主观分项如有子评分点，列出每个子评分点及其分值
4. 识别评分项对应的"证据关键词"（用于在标书中检索对应章节）

输出 JSON 格式（严格遵循，不要其他文字）：
{{
  "total_score": 100,
  "scoring_items": [
    {{
      "category": "商务分",
      "title": "投标函格式",
      "max_score": 5,
      "criteria": "投标函格式符合招标文件要求",
      "type": "objective",
      "evidence_keywords": ["投标函"],
      "sub_criteria": [],
      "weight": 1.0
    }},
    {{
      "category": "技术分",
      "title": "技术方案完整性",
      "max_score": 15,
      "criteria": "方案覆盖招标要求的所有技术点",
      "type": "subjective",
      "evidence_keywords": ["技术方案", "实施方案"],
      "sub_criteria": [
        {{"desc": "技术路线清晰", "score": 5}},
        {{"desc": "实施步骤完整", "score": 5}},
        {{"desc": "应急响应流程", "score": 5}}
      ],
      "weight": 1.0
    }}
  ]
}}

评分章节文本：
{scoring_text[:8000]}
"""
    try:
        result = subprocess.run(
            ['z-ai', 'chat', '-p', prompt],
            capture_output=True, text=True, timeout=120, check=False
        )
        if result.returncode != 0:
            _logger.warning(f'  z-ai CLI 调用失败：{result.stderr[:200]}')
            return None

        output = result.stdout.strip()
        # 尝试提取 JSON
        json_match = re.search(r'\{[\s\S]*\}', output)
        if not json_match:
            _logger.warning('  无法从 LLM 输出提取 JSON')
            return None

        data = json.loads(json_match.group(0))
        _logger.info(f'  LLM 提取评分项数：{len(data.get("scoring_items", []))}')
        return data
    except subprocess.TimeoutExpired:
        _logger.warning('  z-ai CLI 调用超时（120秒）')
        return None
    except json.JSONDecodeError as e:
        _logger.warning(f'  LLM 输出 JSON 解析失败：{e}')
        return None
    except FileNotFoundError:
        _logger.warning('  z-ai CLI 未安装，将使用规则兜底')
        return None


def extract_scoring_via_rules(scoring_text: str) -> Dict:
    """规则兜底：用正则提取评分项"""
    items = []

    # 模式1: "X.X 分" 或 "X分"
    score_pattern = re.compile(r'([0-9]+(?:\.[0-9]+)?)\s*分')
    # 模式2: "项目/类别/分值"表格行
    row_pattern = re.compile(r'[\|｜]\s*([^|｜]+)\s*[\|｜]\s*([^|｜]+)\s*[\|｜]\s*([0-9]+(?:\.[0-9]+)?)\s*分?\s*[\|｜]')

    # 识别评分类别
    current_category = '其他'
    lines = scoring_text.split('\n')
    for line in lines:
        # 类别切换
        for cat, keywords in CATEGORY_KEYWORDS.items():
            if any(kw in line for kw in keywords) and len(line) < 30:
                current_category = cat
                break

        # 评分项行
        score_match = score_pattern.search(line)
        if score_match and len(line) < 200:
            score = float(score_match.group(1))
            # 简单识别标题（去掉分数和标点）
            title = re.sub(r'[0-9]+(?:\.[0-9]+)?\s*分', '', line).strip(' |｜·:-')
            if title and len(title) < 50:
                # 推断类型
                is_objective = any(kw in line for kw in ['提供', '具备', '有效', '是否', '有无'])
                item_type = 'objective' if is_objective else 'subjective'
                items.append({
                    'category': current_category,
                    'title': title,
                    'max_score': score,
                    'criteria': line.strip(),
                    'type': item_type,
                    'evidence_keywords': [title[:4]],
                    'sub_criteria': [],
                    'weight': 1.0,
                })

    total_score = sum(item['max_score'] for item in items)
    if total_score == 0:
        total_score = 100  # 默认

    return {
        'total_score': total_score if 50 <= total_score <= 200 else 100,
        'scoring_items': items,
    }


def normalize_scoring_data(raw: Dict) -> ScoringTable:
    """规范化评分数据为 ScoringTable 对象"""
    items = []
    for i, raw_item in enumerate(raw.get('scoring_items', [])):
        sub_criteria = []
        for sc in raw_item.get('sub_criteria', []):
            if isinstance(sc, dict):
                sub_criteria.append(SubCriteria(
                    desc=sc.get('desc', ''),
                    score=float(sc.get('score', 0)),
                ))

        items.append(ScoringItem(
            item_id=f'sc{i+1:03d}',
            category=raw_item.get('category', '其他'),
            title=raw_item.get('title', f'评分项{i+1}'),
            max_score=float(raw_item.get('max_score', 0)),
            criteria=raw_item.get('criteria', ''),
            type=raw_item.get('type', 'subjective'),
            evidence_keywords=raw_item.get('evidence_keywords', []),
            sub_criteria=sub_criteria,
            weight=float(raw_item.get('weight', 1.0)),
        ))

    # 评估置信度
    low_items = []
    if not items:
        low_items.append('未识别到任何评分项')
    elif len(items) < 3:
        low_items.append(f'评分项数 {len(items)} 较少，建议人工核对')
    total_calculated = sum(item.max_score for item in items)
    if items and abs(total_calculated - raw.get('total_score', 100)) > 10:
        low_items.append(f'各项分值之和 {total_calculated} 与总分 {raw.get("total_score", 100)} 不一致')

    confidence = 'high' if not low_items else ('medium' if len(low_items) <= 1 else 'low')

    return ScoringTable(
        total_score=float(raw.get('total_score', 100)),
        scoring_items=items,
        extraction_confidence=confidence,
        low_confidence_items=low_items,
    )


def main():
    parser = argparse.ArgumentParser(description='Stage 1.4: 提取评分表')
    parser.add_argument('--input', required=True, help='解析数据 JSON 路径')
    parser.add_argument('--output', required=True, help='输出评分表 JSON 路径')
    parser.add_argument('--no-llm', action='store_true', help='不调用 LLM，仅用规则兜底')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取解析数据：{args.input}')
    with open(args.input, 'r', encoding='utf-8') as f:
        parse_data = json.load(f)

    # Step 1: 找评分章节
    scoring_text = find_scoring_section(parse_data)
    if not scoring_text:
        _logger.warning('  未找到评分章节，生成空评分表')
        table = ScoringTable(total_score=100, scoring_items=[],
                            extraction_confidence='low',
                            low_confidence_items=['未找到评分章节'])
    else:
        _logger.info(f'  评分章节文本长度：{len(scoring_text)}')

        # Step 2: LLM 提取（首选）
        raw = None
        if not args.no_llm:
            _logger.info('  尝试 LLM 提取评分表...')
            raw = extract_scoring_via_llm(scoring_text)

        # Step 3: 规则兜底
        if not raw:
            _logger.info('  使用规则兜底提取评分表...')
            raw = extract_scoring_via_rules(scoring_text)

        table = normalize_scoring_data(raw)

    # Step 4: 输出
    output = {
        'total_score': table.total_score,
        'scoring_items': [asdict(item) for item in table.scoring_items],
        'extraction_confidence': table.extraction_confidence,
        'low_confidence_items': table.low_confidence_items,
    }

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  总分：{table.total_score}')
    _logger.info(f'  评分项数：{len(table.scoring_items)}')
    obj_count = sum(1 for item in table.scoring_items if item.type == 'objective')
    sub_count = sum(1 for item in table.scoring_items if item.type == 'subjective')
    _logger.info(f'  客观分 {obj_count} 项 + 主观分 {sub_count} 项')
    _logger.info(f'  抽取置信度：{table.extraction_confidence}')
    if table.low_confidence_items:
        _logger.warning(f'  低置信项：{table.low_confidence_items}')


if __name__ == '__main__':
    main()
