#!/usr/bin/env python3
"""
Stage 2.2: 章节切片
扫描 .docx 文件，识别所有 Heading 段落，建立章节树。

输入：{项目名}_标书.docx
输出：{项目名}_标书章节索引.json

复用：template_scanner.detect_chapter + _is_valid_chapter_title
"""
import argparse
import json
import sys
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any, Optional
from collections import Counter

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger
from docx import Document
from docx.oxml.ns import qn

_logger = get_logger('slice_chapters')


@dataclass
class Chapter:
    chapter_id: str
    level: int  # 1=H1, 2=H2, 3=H3
    title: str
    para_index_start: int
    para_index_end: int  # 不含
    page_start: int = 0  # 估算
    page_end: int = 0
    word_count: int = 0
    full_text: str = ''
    parent_chapter_id: Optional[str] = None


def is_heading_paragraph(para) -> bool:
    """判断段落是否为标题"""
    style_name = para.style.name if para.style else ''
    if style_name.startswith('Heading'):
        return True
    if style_name in ('Title', 'Subtitle'):
        return True
    # 检查 outline level
    pPr = para._element.find(qn('w:pPr'))
    if pPr is not None:
        outlineLvl = pPr.find(qn('w:outlineLvl'))
        if outlineLvl is not None:
            return True
    return False


def get_heading_level(para) -> int:
    """获取标题层级，1=H1, 2=H2, ..."""
    style_name = para.style.name if para.style else ''
    if style_name.startswith('Heading'):
        try:
            return int(style_name.replace('Heading ', '').strip())
        except ValueError:
            return 1
    if style_name == 'Title':
        return 1
    if style_name == 'Subtitle':
        return 2
    # outline level
    pPr = para._element.find(qn('w:pPr'))
    if pPr is not None:
        outlineLvl = pPr.find(qn('w:outlineLvl'))
        if outlineLvl is not None:
            val = outlineLvl.get(qn('w:val'))
            try:
                return int(val) + 1
            except (ValueError, TypeError):
                pass
    return 1


# 序号模式（用于识别"一、""第一章""1.""1.1"等手动编号的标题）
CHAPTER_NUMBER_PATTERNS = [
    r'^第[一二三四五六七八九十百零]+[章节部分篇]',
    r'^[一二三四五六七八九十]+[、.．]',
    r'^[（(][一二三四五六七八九十]+[)）]',
    r'^\d+[、.．]\s*\S',
    r'^\d+\.\d+\s*\S',
]


def looks_like_chapter_title(text: str) -> bool:
    """启发式判断文本是否像章节标题"""
    text = text.strip()
    if not text or len(text) > 100:
        return False
    if '。' in text or '；' in text:
        return False
    # 已知样式
    return True


def extract_para_text(para) -> str:
    """提取段落纯文本（含表格内文本）"""
    return para.text or ''


def estimate_page_breaks(doc) -> List[int]:
    """估算每个段落所在的页码（按分页符 + 字数估算）"""
    page_starts = []  # 每个段落属于哪一页
    current_page = 1
    chars_per_page = 800  # 估算：每页约 800 字
    chars_accumulated = 0

    for para in doc.paragraphs:
        # 检测分页符
        for run in para.runs:
            for br in run._element.findall(qn('w:br')):
                if br.get(qn('w:type')) == 'page':
                    current_page += 1
                    chars_accumulated = 0
                    break

        # 检测 page_break_before 属性
        pPr = para._element.find(qn('w:pPr'))
        if pPr is not None:
            pageBreakBefore = pPr.find(qn('w:pageBreakBefore'))
            if pageBreakBefore is not None and chars_accumulated > 0:
                current_page += 1
                chars_accumulated = 0

        page_starts.append(current_page)
        chars_accumulated += len(para.text or '')
        if chars_accumulated >= chars_per_page:
            current_page += 1
            chars_accumulated = 0

    return page_starts


def slice_chapters(docx_path: str) -> Dict[str, Any]:
    """主函数：切片章节"""
    _logger.info(f'读取 .docx：{docx_path}')
    doc = Document(docx_path)

    # 估算每个段落的页码
    page_starts = estimate_page_breaks(doc)
    total_pages = max(page_starts) if page_starts else 1

    # 扫描所有段落
    paragraphs = list(doc.paragraphs)
    total_words = sum(len(p.text or '') for p in paragraphs)

    _logger.info(f'  段落数：{len(paragraphs)}')
    _logger.info(f'  估算页数：{total_pages}')
    _logger.info(f'  总字数：{total_words}')

    # 识别所有标题段落
    heading_indices = []
    for i, para in enumerate(paragraphs):
        if is_heading_paragraph(para) and looks_like_chapter_title(para.text or ''):
            level = get_heading_level(para)
            heading_indices.append((i, level, para.text.strip()))

    _logger.info(f'  识别到标题数：{len(heading_indices)}')

    # 构建章节树
    chapters = []
    for idx, (para_idx, level, title) in enumerate(heading_indices):
        # 章节文本范围：当前标题段 → 下一个同级或更高级标题前
        end_idx = len(paragraphs)
        for next_para_idx, next_level, _ in heading_indices[idx+1:]:
            if next_level <= level:
                end_idx = next_para_idx
                break

        # 收集章节全文
        chapter_text_parts = []
        for p in paragraphs[para_idx+1:end_idx]:
            if p.text:
                chapter_text_parts.append(p.text)

        full_text = '\n'.join(chapter_text_parts)
        word_count = len(full_text)

        # 页码范围
        page_start = page_starts[para_idx] if para_idx < len(page_starts) else 1
        page_end = page_starts[end_idx-1] if end_idx-1 < len(page_starts) else page_start

        # 找父章节
        parent_id = None
        for prev_idx, prev_level, _ in reversed(heading_indices[:idx]):
            if prev_level < level:
                parent_id = f'ch{prev_idx+1:03d}'
                break

        chapters.append(Chapter(
            chapter_id=f'ch{idx+1:03d}',
            level=level,
            title=title,
            para_index_start=para_idx,
            para_index_end=end_idx,
            page_start=page_start,
            page_end=page_end,
            word_count=word_count,
            full_text=full_text[:50000],  # 截断超长章节，避免 JSON 过大
            parent_chapter_id=parent_id,
        ))

    # 统计
    level_counter = Counter(ch.level for ch in chapters)
    _logger.info(f'  H1: {level_counter.get(1, 0)}, H2: {level_counter.get(2, 0)}, H3: {level_counter.get(3, 0)}')

    return {
        'doc_path': docx_path,
        'total_paragraphs': len(paragraphs),
        'total_pages': total_pages,
        'total_words': total_words,
        'chapters': [asdict(ch) for ch in chapters],
    }


def main():
    parser = argparse.ArgumentParser(description='Stage 2.2: 章节切片')
    parser.add_argument('--input', required=True, help='标书 .docx 路径')
    parser.add_argument('--output', required=True, help='输出章节索引 JSON 路径')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    if args.verbose:
        import logging
        logging.getLogger('slice_chapters').setLevel(logging.DEBUG)

    if not Path(args.input).exists():
        _logger.error(f'文件不存在：{args.input}')
        sys.exit(1)

    result = slice_chapters(args.input)

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  章节数：{len(result["chapters"])}')


if __name__ == '__main__':
    main()
