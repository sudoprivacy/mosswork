#!/usr/bin/env python3
"""
Stage 6: 生成最终审核报告

输入：
  --format-plan: 格式审核 Plan JSON
  --scoring-plan: 评分预估 Plan JSON
  --ocr-report: OCR 比对报告 JSON（可选）
  --chapter-index: 章节索引 JSON

输出：{项目名}_审核报告.md（最终交付）
"""
import argparse
import json
import sys
from pathlib import Path
from datetime import datetime
from collections import defaultdict

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger

_logger = get_logger('generate_audit_report')


def severity_icon(severity: str) -> str:
    return {
        'critical': '🔴',
        'major': '🟡',
        'minor': '🔵',
        'info': '⚪',
    }.get(severity, '❓')


def status_icon(status: str) -> str:
    return {
        'compliant': '✅',
        'non_compliant': '❌',
        'not_applicable': '➖',
    }.get(status, '❓')


def render_overview(format_plan, scoring_plan, ocr_report, chapter_index) -> str:
    """渲染总体概览"""
    project_info_text = ''
    # 从 chapter_index 获取基本信息
    total_pages = chapter_index.get('total_pages', 0)
    total_words = chapter_index.get('total_words', 0)
    chapter_count = len(chapter_index.get('chapters', []))

    format_total = format_plan.get('total_checks', 0)
    format_passed = format_plan.get('passed', 0)
    format_failed = format_plan.get('failed', 0)
    compliance_rate = (format_passed / format_total * 100) if format_total > 0 else 0

    estimated_score = scoring_plan.get('estimated_score', 0)
    total_score = scoring_plan.get('total_score', 100)
    confidence = scoring_plan.get('confidence', 'medium')
    confidence_reason = scoring_plan.get('confidence_reason', '')

    ocr_total = ocr_report.get('total_checks', 0) if ocr_report else 0
    ocr_compliant = ocr_report.get('compliant', 0) if ocr_report else 0
    ocr_non_compliant = ocr_report.get('non_compliant', 0) if ocr_report else 0

    md = f"""# 标书审核报告

> 审核工具：bid-checker-pro v1.2.0
> 审核时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 一、总体概览

| 指标 | 值 |
|------|-----|
| 标书总页数 | {total_pages} 页 |
| 标书总字数 | {total_words:,} 字 |
| 章节数 | {chapter_count} 个 |
| 格式合规检查项 | {format_total} 项 |
| 格式合规通过 | {format_passed} 项 |
| 格式合规失败 | {format_failed} 项 |
| **格式合规率** | **{compliance_rate:.1f}%** |
| 评分项数 | {len(scoring_plan.get('items', []))} 项 |
| **预估得分** | **{estimated_score}/{total_score} 分** |
| 置信度 | {confidence}（{confidence_reason}） |
| OCR 比对项 | {ocr_total} 项 |
| OCR 合规 | {ocr_compliant} 项 |
| OCR 不合规 | {ocr_non_compliant} 项 |

"""
    return md


def render_format_audit(format_plan) -> str:
    """渲染格式合规审核部分"""
    items = format_plan.get('items', [])
    failures_by_severity = format_plan.get('failures_by_severity', {})

    md = "## 二、格式合规审核\n\n"

    # 按严重度分组
    for severity in ['critical', 'major', 'minor', 'info']:
        severity_name = {
            'critical': '致命违规', 'major': '重大违规',
            'minor': '轻微违规', 'info': '提示项'
        }[severity]
        count = failures_by_severity.get(severity, 0)

        md += f"### 2.{['critical', 'major', 'minor', 'info'].index(severity)+1} {severity_name}（{severity}）— {count} 项\n\n"

        # 找该严重度的所有失败项
        failed_items = [it for it in items
                       if it.get('status') == 'non_compliant' and it.get('severity') == severity]

        if not failed_items:
            md += f"（无）\n\n"
            continue

        for i, item in enumerate(failed_items, 1):
            md += f"#### 违规 {i}: {item.get('category', '')} - {item.get('requirement', '')[:50]}\n\n"
            md += f"- **严重度**：{severity_icon(severity)} {severity}\n"
            md += f"- **位置**：第 {item.get('page_ref', '?')} 页\n"
            md += f"- **招标要求**：{item.get('requirement', '')}\n"
            md += f"- **标书实际**：{item.get('actual', '')}\n"
            evidence = item.get('evidence', '')
            if evidence:
                md += f"- **原文引用**：\n  > {evidence[:200]}\n"
            suggestion = item.get('suggestion', '')
            if suggestion:
                md += f"- **建议**：{suggestion}\n"
            md += "\n"

    return md


def render_scoring_evaluation(scoring_plan) -> str:
    """渲染评分项预估部分"""
    items = scoring_plan.get('items', [])
    total_score = scoring_plan.get('total_score', 100)
    estimated_score = scoring_plan.get('estimated_score', 0)
    confidence = scoring_plan.get('confidence', 'medium')
    confidence_reason = scoring_plan.get('confidence_reason', '')

    md = "## 三、评分项预估\n\n"
    md += f"### 3.1 预估总分：{estimated_score}/{total_score} 分（置信度：{confidence}）\n\n"
    md += f"> {confidence_reason}\n\n"

    # 按类别分组
    by_category = defaultdict(list)
    for it in items:
        by_category[it.get('category', '其他')].append(it)

    # 类别汇总表
    md += "| 类别 | 满分 | 预估得分 | 得分率 |\n"
    md += "|------|------|---------|--------|\n"
    for cat, cat_items in by_category.items():
        cat_max = sum(it.get('max_score', 0) for it in cat_items)
        cat_estimated = sum(it.get('estimated_score', 0) for it in cat_items)
        rate = (cat_estimated / cat_max * 100) if cat_max > 0 else 0
        md += f"| {cat} | {cat_max:.1f} | {cat_estimated:.1f} | {rate:.0f}% |\n"
    md += f"| **合计** | **{total_score:.1f}** | **{estimated_score:.1f}** | **{(estimated_score/total_score*100) if total_score > 0 else 0:.0f}%** |\n\n"

    # 价格分计算依据（Stage 4.2.1 用户交互，强制展示）
    baseline_price = scoring_plan.get('baseline_price')
    bid_price = scoring_plan.get('bid_price')
    if baseline_price and bid_price:
        price_items = [it for it in items
                       if it.get('category') == '价格分' or it.get('type') == 'price'
                       or '报价' in str(it.get('title', '')) or '价格分' in str(it.get('title', ''))]
        price_score = price_items[0].get('estimated_score', 0) if price_items else 0
        price_max = price_items[0].get('max_score', 0) if price_items else 0
        md += "### 3.2 价格分计算依据（强制展示）\n\n"
        md += f"- **基准价（baseline_price）**：{baseline_price:,.2f} 元（来源：{scoring_plan.get('baseline_price_source', '交互')}）\n"
        md += f"- **本投标报价**：{bid_price:,.2f} 元\n"
        md += f"- **报价满分**：{price_max} 分\n"
        md += (f"- **报价分 = (基准价 / 报价) × 满分 = ({baseline_price:,.2f} / {bid_price:,.2f}) "
               f"× {price_max} = {price_score} 分**\n")
        md += f"- **置信度**：{scoring_plan.get('price_score_confidence', 'low')}"
        md += "（基准价为用户预估/保守假设，实际以开标结果为准）\n\n"

    # 各类别明细
    for cat, cat_items in by_category.items():
        cat_max = sum(it.get('max_score', 0) for it in cat_items)
        cat_estimated = sum(it.get('estimated_score', 0) for it in cat_items)
        md += f"### 3.{list(by_category.keys()).index(cat)+3} {cat}明细（{cat_estimated:.1f}/{cat_max:.1f} 分）\n\n"

        md += "| 评分项 | 满分 | 预估 | 状态 | 类型 |\n"
        md += "|--------|------|------|------|------|\n"
        for it in cat_items:
            status = it.get('response_status', 'missing')
            status_text = {
                'fully_responded': '✅ 完全响应',
                'partially_responded': '⚠️ 部分响应',
                'insufficient_response': '⚠️ 响应不足',
                'missing': '❌ 缺失',
            }.get(status, status)
            item_type = '客观' if it.get('type') == 'objective' else '主观'
            md += f"| {it.get('title', '')[:30]} | {it.get('max_score', 0)} | {it.get('estimated_score', 0)} | {status_text} | {item_type} |\n"
        md += "\n"

        # 主观分项的详细扣分理由
        for it in cat_items:
            deductions = it.get('deduction_reasons', [])
            if deductions:
                md += f"#### 评分项：{it.get('title', '')}（{it.get('max_score', 0)} 分，预估 {it.get('estimated_score', 0)} 分）\n\n"
                evidence_text = it.get('evidence_text', '')
                if evidence_text:
                    md += f"- **响应证据**：{evidence_text[:200]}\n"
                page_ref = it.get('page_ref', '')
                if page_ref:
                    md += f"- **位置**：第 {page_ref} 页\n"
                md += f"- **主要扣分点**：\n"
                for d in deductions:
                    if isinstance(d, dict):
                        md += f"  - {d.get('sub_criteria', '')}（扣 {d.get('deducted_score', 0)}/{d.get('max_score', 0)} 分）：{d.get('reason', '')}\n"
                suggestions = it.get('improvement_suggestions', [])
                if suggestions:
                    md += f"- **改进建议**：\n"
                    for s in suggestions:
                        md += f"  - {s}\n"
                md += "\n"

    return md


def render_ocr_report(ocr_report) -> str:
    """渲染 OCR 比对报告"""
    if not ocr_report:
        return "## 四、OCR 资质详细比对\n\n（OCR 比对未执行或无数据）\n\n"

    md = "## 四、OCR 资质详细比对\n\n"

    total = ocr_report.get('total_checks', 0)
    compliant = ocr_report.get('compliant', 0)
    non_compliant = ocr_report.get('non_compliant', 0)
    errors = ocr_report.get('errors', 0)

    md += "### 4.1 比对结果概览\n\n"
    md += f"- 总检查项：{total}\n"
    md += f"- ✅ 合规：{compliant}\n"
    md += f"- ❌ 不合规：{non_compliant}\n"
    md += f"- ⚠️ 错误：{errors}\n\n"

    checks = ocr_report.get('checks', [])

    # 不合规项
    non_compliant_checks = [c for c in checks if c.get('status') == 'non_compliant']
    if non_compliant_checks:
        md += "### 4.2 不合规项\n\n"
        for i, c in enumerate(non_compliant_checks, 1):
            md += f"#### 不合规 {i}: {c.get('title', '')}\n\n"
            md += f"- **位置**：第 {c.get('page_ref', '?')} 页\n"
            md += f"- **图片**：{c.get('image_path', '')}\n"
            ocr_result = c.get('ocr_result', {})
            if ocr_result:
                md += f"- **OCR 识别**：\n"
                for k, v in ocr_result.items():
                    if v:
                        md += f"  - {k}：{v}\n"
            issues = c.get('issues_found', [])
            if issues:
                md += f"- **问题**：\n"
                for issue in issues:
                    if isinstance(issue, dict):
                        md += f"  - {severity_icon(issue.get('severity', 'info'))} {issue.get('issue', '')}：{issue.get('detail', '')}\n"
            md += "\n"

    # 合规项（简要列出）
    compliant_checks = [c for c in checks if c.get('status') == 'compliant']
    if compliant_checks:
        md += "### 4.3 合规项\n\n"
        md += "| 评分项 | OCR 主要字段 | 位置 |\n"
        md += "|--------|-------------|------|\n"
        for c in compliant_checks:
            ocr_result = c.get('ocr_result', {})
            key_fields = []
            for k in ['公司名称', '姓名', '资质等级', '报告编号']:
                if ocr_result.get(k):
                    key_fields.append(f"{k}: {ocr_result[k][:20]}")
            md += f"| {c.get('title', '')} | {'; '.join(key_fields[:2])} | 第 {c.get('page_ref', '?')} 页 |\n"
        md += "\n"

    # 错误项
    error_checks = [c for c in checks if c.get('status') == 'error']
    if error_checks:
        md += "### 4.4 错误项（需人工复核）\n\n"
        for c in error_checks:
            md += f"- **{c.get('title', '')}**："
            issues = c.get('issues_found', [])
            if issues:
                md += issues[0].get('detail', '')
            md += "\n"
        md += "\n"

    return md


def render_visual_review(chapter_index) -> str:
    """渲染视觉核对部分（占位，实际需模型读 PNG 后填）"""
    md = "## 五、视觉核对发现\n\n"
    md += "> 本部分由模型读取 Stage 5 渲染的 PNG 后人工填写。\n\n"

    chapters = chapter_index.get('chapters', [])
    md += "### 5.1 关键页核对结果\n\n"
    md += "| 页面 | 类型 | 发现问题 |\n"
    md += "|------|------|---------|\n"
    md += "| 第 1 页 | 封面 | （待模型填写） |\n"
    md += "| ... | ... | ... |\n\n"

    return md


def render_star_items(star_plan) -> str:
    """渲染「六、标⭐️项（关键参数/废标条款）检查」章节【v2.0.0 新增】。"""
    if star_plan is None:
        return ("## 六、标⭐️项（关键参数/废标条款）检查\n\n"
                "> ⚠️ 未提供标星项检查 Plan，本章节跳过。如需检查，请在 Stage 2.5 运行 "
                "`check_star_items.py --tender <招标文件> --bid <投标文件>` 并将结果传入 `--star-plan`。\n\n")

    has = star_plan.get('has_star_items', False)
    summary = star_plan.get('summary', {})
    items = star_plan.get('star_items', [])
    note = star_plan.get('note', '')
    llm_needed = star_plan.get('llm_review_needed', False)

    # —— 无标星项（如梦桃小学项目）——
    if not has:
        md = "## 六、标⭐️项（关键参数/废标条款）检查\n\n"
        md += "> ✅ **本项目招标文件未标注任何 ⭐️（星号）项**，亦无星号条款 / 评分加分-减分政策。\n\n"
        if note:
            md += f"> {note}\n\n"
        md += "- 无标星项专项风险，本报告跳过逐条核查。\n\n"
        return md

    # —— 有标星项 ——
    md = "## 六、标⭐️项（关键参数/废标条款）检查\n\n"
    md += "### 6.1 标星项概览\n\n"
    md += "| 类别 | 数量 |\n|------|------|\n"
    md += f"| 参数项（关键指标） | {summary.get('star_parameter_count', 0)} |\n"
    md += f"| 废标 / 实质性条款 | {summary.get('star_clause_count', 0)} |\n"
    md += f"| 评分加分-减分政策 | {summary.get('star_policy_count', 0)} |\n\n"
    md += (f"- **投标响应**：满足 {summary.get('response_met', 0)} 项 ｜ "
            f"不满足 {summary.get('response_not_met', 0)} 项 ｜ "
            f"需复核 {summary.get('response_needs_review', 0)} 项\n")
    md += f"- **关键风险等级**：{summary.get('critical_risk', 'none')}\n\n"

    md += "### 6.2 标星项明细与响应（必含定位表）\n\n"
    md += "| 编号 | 类型 | 招标文件要求（原文） | 投标响应 | 证据 / 复核提示 |\n"
    md += "|------|------|----------------------|---------|--------------------|\n"
    _TYPE_NAMES = {'parameter': '参数项', 'clause': '废标/实质条款', 'policy': '评分政策'}
    _STATUS_ICON = {'met': '✅ 满足', 'not_met': '❌ 不满足', 'needs_review': '⚠️ 需复核'}
    for it in items:
        resp = it.get('bid_response', {}) or {}
        st = resp.get('status', 'needs_review')
        text = str(it.get('text', '')).replace('|', '／')[:50]
        ev = str(resp.get('evidence', '') or '').replace('|', '／')[:60]
        md += (f"| {it.get('id', '')} | {_TYPE_NAMES.get(it.get('type', ''), it.get('type', ''))} | "
                f"{text} | {_STATUS_ICON.get(st, st)} | {ev} |\n")
    md += "\n"

    md += "### 6.3 LLM 逐条复核结论\n\n"
    if llm_needed:
        md += ("- ⚠️ **未做 LLM 逐条复核**（llm_review_needed=true）：机器仅做抽取与初判，"
                "技术规格是否满足、废标条款是否被触发、评分政策是否已在得分中落实，均须模型通读"
                "招标文件与投标响应后逐条确认。\n\n")
    else:
        md += "- 模型已逐条复核标星项，并已将结论更新至 6.2 表。\n\n"

    if summary.get('response_not_met', 0) > 0 or summary.get('critical_risk') == 'high':
        md += "> 🚨 **高危提示**：存在不满足或被触发风险的标星项，可能直接导致废标或该模块零分，"
        md += "须优先处理并经模型确认。\n\n"

    return md


def render_typo_check(typo_plan) -> str:
    """渲染「七、文字错误（错别字）检查」章节（v1.2.0 新增）。"""
    if typo_plan is None:
        return ("## 七、文字错误（错别字）检查\n\n"
                "> ⚠️ 未提供错别字检查 Plan，本章节跳过。如需检查，请在 Stage 2.5 运行 "
                "`check_typos.py` 并将结果传入 `--typo-plan`。\n\n")

    md = "## 七、文字错误（错别字）检查\n\n"

    summary = typo_plan.get('summary_by_type', {})
    total = typo_plan.get('total_issues', sum(summary.values()))
    llm_needed = typo_plan.get('llm_review_needed', False)

    md += "### 7.1 检查概览\n\n"
    if summary:
        md += "| 类型 | 数量 |\n|------|------|\n"
        for t, n in summary.items():
            md += f"| {t} | {n} |\n"
        md += f"\n- **合计**：{total} 处\n\n"
    else:
        md += "- （无）\n\n"

    md += "### 7.2 错别字明细（必含定位表）\n\n"
    issues = typo_plan.get('issues', [])
    if issues:
        md += "| 编号 | 类型 | 严重度 | 原文 | 建议 | 位置 / 上下文 |\n"
        md += "|------|------|--------|------|------|--------------|\n"
        for i, it in enumerate(issues, 1):
            original = str(it.get('original', '')).replace('|', '／')[:40]
            suggestion = str(it.get('suggestion', '')).replace('|', '／')[:40]
            location = str(it.get('location', '') or it.get('context', '')).replace('|', '／')[:50]
            md += (f"| T-{i:03d} | {it.get('type', '')} | "
                    f"{severity_icon(it.get('severity', ''))} {it.get('severity', '')} | "
                    f"{original} | {suggestion} | {location} |\n")
        md += "\n"
    else:
        md += "- （未发现机器可判定的错别字）\n\n"

    md += "### 7.3 LLM 语境复核结论\n\n"
    if llm_needed:
        md += ("- ⚠️ **未做 LLM 语境复核**（llm_review_needed=true）：可能漏检语境类错误"
               "（的/地/得、做/作、语义误用、废标敏感词误写等）。建议模型通读全文后追加。\n\n")
    else:
        md += "- 模型已通读全文，完成语境相关错误复核并追加至 7.2 表。\n\n"

    return md


def render_price_check(price_plan) -> str:
    """渲染价格分一致性检查部分【v1.1.0 新增】"""
    if not price_plan:
        return ""

    md = "## 八、价格分一致性检查\n\n"

    total = price_plan.get('total_checks', 0)
    passed = price_plan.get('passed', 0)
    failed = price_plan.get('failed', 0)
    failures_by_severity = price_plan.get('failures_by_severity', {})

    md += "### 8.1 检查结果概览\n\n"
    md += f"- 总检查项：{total}\n"
    md += f"- ✅ 通过：{passed}\n"
    md += f"- ❌ 不合规：{failed}\n"
    md += f"  - 🔴 critical：{failures_by_severity.get('critical', 0)}\n"
    md += f"  - 🟡 major：{failures_by_severity.get('major', 0)}\n"
    md += f"  - 🔵 minor：{failures_by_severity.get('minor', 0)}\n\n"

    # 金额汇总
    amount_summary = price_plan.get('amount_summary', {})
    if amount_summary:
        md += "### 8.2 金额汇总\n\n"
        md += f"- 总金额数：{amount_summary.get('total_amounts', 0)}\n"
        by_location = amount_summary.get('by_location', {})
        if by_location:
            md += "- 按位置分布：\n"
            for loc, count in by_location.items():
                md += f"  - {loc}：{count} 个金额\n"
        max_value = amount_summary.get('max_value', 0)
        if max_value > 0:
            md += f"- 最大金额：{max_value:,.2f} 元\n"
        md += "\n"

    # 不合规项明细（按 5 类分组）
    items = price_plan.get('items', [])
    type_names = {
        'cn_validity': '大写金额合规性',
        'size_consistency': '大小写一致性',
        'cross_location': '跨位置一致性',
        'subtotal': '分项合计校验',
        'text_table': '文字-表格一致性',
    }

    failed_items = [it for it in items if it.get('status') == 'non_compliant']
    if failed_items:
        md += "### 8.3 不合规项明细\n\n"
        by_type = defaultdict(list)
        for it in failed_items:
            by_type[it.get('check_type', '')].append(it)

        for check_type, type_items in by_type.items():
            type_name = type_names.get(check_type, check_type)
            md += f"#### {type_name}（{len(type_items)} 项）\n\n"
            for i, it in enumerate(type_items, 1):
                md += f"**问题 {i}**: {it.get('actual', '')[:120]}\n\n"
                md += f"- **严重度**：{severity_icon(it.get('severity', ''))} {it.get('severity', '')}\n"
                evidence = it.get('evidence', '')
                if evidence:
                    md += f"- **证据**：{evidence[:150]}\n"
                suggestion = it.get('suggestion', '')
                if suggestion:
                    md += f"- **建议**：{suggestion}\n"
                md += "\n"

    return md


def render_plagiarism_check(plagiarism_plan) -> str:
    """渲染技术方案抄袭检测部分【v1.1.0 新增】"""
    if not plagiarism_plan:
        return ""

    md = "## 九、技术方案抄袭检测\n\n"

    total_paragraphs = plagiarism_plan.get('total_paragraphs', 0)
    summary = plagiarism_plan.get('summary_by_dimension', {})

    md += "### 9.1 检测结果概览\n\n"
    md += f"- 总段落数：{total_paragraphs}\n"
    md += f"- 问题总数：{sum(summary.values())}\n\n"

    md += "按维度统计：\n\n"
    md += "| 维度 | 问题数 | 严重度 |\n"
    md += "|------|--------|--------|\n"
    dim_names = {
        'residual_info': ('残留他人信息', 'critical'),
        'self_duplicate': ('跨章节自重复', 'major'),
        'external_similar': ('与公开资料相似', 'major'),
        'ai_trace': ('AI 痕迹', 'minor'),
        'citation': ('引用未署名', 'info'),
    }
    for dim, count in summary.items():
        name, severity = dim_names.get(dim, (dim, 'info'))
        md += f"| {name} | {count} | {severity_icon(severity)} {severity} |\n"
    md += "\n"

    # 维度③ 状态警示（禁止伪装"无抄袭"）
    ext_status = plagiarism_plan.get('external_search_status', 'unknown')
    ext_note = plagiarism_plan.get('external_search_note', '')
    if ext_status == 'skipped_no_tool':
        md += "> ⚠️ **维度③ 公开资料比对未执行**：本环境 z-ai web-search 不可用且未提供兜底结果，"
        md += "相似度未核验。**不得写为「无抄袭」**，需调用方用 WebSearch 兜底检索后复核。\n\n"
    elif ext_status == 'disabled_by_flag':
        md += f"> 维度③ 公开资料比对已跳过（{ext_note}）。\n\n"
    elif ext_status == 'searched':
        md += f"> 维度③ 已检索公开资料（{ext_note}）。\n\n"

    # 各维度明细
    issues = plagiarism_plan.get('issues', [])
    if issues:
        by_dim = defaultdict(list)
        for it in issues:
            by_dim[it.get('dimension', '')].append(it)

        # 维度② 跨章节自重复 → 明细定位表
        sd = by_dim.get('self_duplicate', [])
        if sd:
            md += "### 9.2 跨章节自重复明细（维度②）\n\n"
            md += "| 编号 | 内容摘要 | 位置 A（章节/页/行） | 位置 B（章节/页/行） | 相似度 | 风险等级 | 研判建议 |\n"
            md += "|------|---------|---------------------|---------------------|--------|----------|----------|\n"
            for i, it in enumerate(sd, 1):
                summary = (it.get('content_summary') or it.get('description', ''))[:60]
                pa = it.get('position_a') or '-'
                pb = it.get('position_b') or it.get('location', '-')
                sim = f"{it.get('similarity', 0)*100:.0f}%" if it.get('similarity') is not None else '-'
                md += f"| D-{i:02d} | {summary} | {pa} | {pb} | {sim} | {severity_icon(it.get('severity', ''))} {it.get('severity', '')} | {it.get('suggestion', '')} |\n"
            md += "\n"

        # 维度③ 与公开资料相似 → 明细定位表
        es = by_dim.get('external_similar', [])
        if es:
            md += "### 9.3 与公开资料相似明细（维度③）\n\n"
            md += "| 编号 | 内容摘要 | 标书位置（章节/页/行） | 公开来源（标题/URL） | 相似度 | 风险等级 | 研判建议 |\n"
            md += "|------|---------|----------------------|---------------------|--------|----------|----------|\n"
            for i, it in enumerate(es, 1):
                summary = (it.get('content_summary') or it.get('description', ''))[:60]
                pa = it.get('position_a') or '-'
                pb = it.get('position_b') or it.get('location', '-')
                sim = f"{it.get('similarity', 0)*100:.0f}%" if it.get('similarity') is not None else '-'
                md += f"| E-{i:02d} | {summary} | {pa} | {pb} | {sim} | {severity_icon(it.get('severity', ''))} {it.get('severity', '')} | {it.get('suggestion', '')} |\n"
            md += "\n"

        # 其余维度（残留他人信息 / AI 痕迹 / 引用未署名）→ 列表
        other_dims = [d for d in by_dim if d not in ('self_duplicate', 'external_similar')]
        if other_dims:
            md += "### 9.4 其他维度明细\n\n"
            for dim in other_dims:
                name, _ = dim_names.get(dim, (dim, 'info'))
                dim_issues = by_dim[dim]
                md += f"#### {name}（{len(dim_issues)} 项）\n\n"
                for i, it in enumerate(dim_issues, 1):
                    md += f"**问题 {i}**: {it.get('description', '')[:120]}\n\n"
                    md += f"- **严重度**：{severity_icon(it.get('severity', ''))} {it.get('severity', '')}\n"
                    md += f"- **位置**：{it.get('location', '')}\n"
                    evidence = it.get('evidence', '')
                    if evidence:
                        evidence_short = evidence.replace('\n', ' ')[:300]
                        md += f"- **证据**：\n  > {evidence_short}\n"
                    suggestion = it.get('suggestion', '')
                    if suggestion:
                        md += f"- **建议**：{suggestion}\n"
                    md += "\n"

    return md


def render_improvement_suggestions(format_plan, scoring_plan, ocr_report,
                                    price_plan=None, plagiarism_plan=None) -> str:
    """渲染改进建议（按优先级排序）"""
    md = "## 十、改进建议（按优先级排序）\n\n"

    # P0 - 必须修复（critical）
    p0_items = []
    # 格式审核 critical
    for it in format_plan.get('items', []):
        if it.get('status') == 'non_compliant' and it.get('severity') == 'critical':
            p0_items.append(it.get('suggestion', '') or it.get('requirement', ''))

    # 价格检查 critical
    if price_plan:
        for it in price_plan.get('items', []):
            if it.get('status') == 'non_compliant' and it.get('severity') == 'critical':
                p0_items.append(f"[价格] {it.get('suggestion', '') or it.get('actual', '')}")

    # 抄袭检测 critical
    if plagiarism_plan:
        for it in plagiarism_plan.get('issues', []):
            if it.get('severity') == 'critical':
                p0_items.append(f"[抄袭] {it.get('suggestion', '') or it.get('description', '')}")

    # OCR critical
    if ocr_report:
        for c in ocr_report.get('checks', []):
            if c.get('status') == 'non_compliant':
                for issue in c.get('issues_found', []):
                    if isinstance(issue, dict) and issue.get('severity') == 'critical':
                        p0_items.append(f"[OCR] {c.get('title', '')}: {issue.get('detail', '')}")

    md += f"### P0 - 必须修复（critical，共 {len(p0_items)} 项）\n\n"
    for i, s in enumerate(p0_items, 1):
        md += f"{i}. {s}\n"
    if not p0_items:
        md += "（无）\n"
    md += "\n"

    # P1 - 强烈建议修复（major）
    p1_items = []
    for it in format_plan.get('items', []):
        if it.get('status') == 'non_compliant' and it.get('severity') == 'major':
            p1_items.append(it.get('suggestion', '') or it.get('requirement', ''))

    # 评分项缺失
    for it in scoring_plan.get('items', []):
        if it.get('response_status') == 'missing':
            p1_items.append(f"补充评分项「{it.get('title', '')}」的响应内容")

    # 价格检查 major
    if price_plan:
        for it in price_plan.get('items', []):
            if it.get('status') == 'non_compliant' and it.get('severity') == 'major':
                p1_items.append(f"[价格] {it.get('suggestion', '') or it.get('actual', '')}")

    # 抄袭检测 major
    if plagiarism_plan:
        for it in plagiarism_plan.get('issues', []):
            if it.get('severity') == 'major':
                p1_items.append(f"[抄袭] {it.get('suggestion', '') or it.get('description', '')}")

    md += f"### P1 - 强烈建议修复（major，共 {len(p1_items)} 项）\n\n"
    for i, s in enumerate(p1_items, 1):
        md += f"{i}. {s}\n"
    if not p1_items:
        md += "（无）\n"
    md += "\n"

    # P2 - 建议修复（minor）
    p2_items = []
    for it in format_plan.get('items', []):
        if it.get('status') == 'non_compliant' and it.get('severity') == 'minor':
            p2_items.append(it.get('suggestion', '') or it.get('requirement', ''))

    # 价格检查 minor
    if price_plan:
        for it in price_plan.get('items', []):
            if it.get('status') == 'non_compliant' and it.get('severity') == 'minor':
                p2_items.append(f"[价格] {it.get('suggestion', '') or it.get('actual', '')}")

    # 抄袭检测 minor
    if plagiarism_plan:
        for it in plagiarism_plan.get('issues', []):
            if it.get('severity') == 'minor':
                p2_items.append(f"[抄袭] {it.get('suggestion', '') or it.get('description', '')}")

    md += f"### P2 - 建议修复（minor，共 {len(p2_items)} 项）\n\n"
    for i, s in enumerate(p2_items, 1):
        md += f"{i}. {s}\n"
    if not p2_items:
        md += "（无）\n"
    md += "\n"

    # P3 - 可选优化（info）
    p3_items = []
    for it in format_plan.get('items', []):
        if it.get('status') == 'non_compliant' and it.get('severity') == 'info':
            p3_items.append(it.get('suggestion', '') or it.get('requirement', ''))

    # 抄袭检测 info
    if plagiarism_plan:
        for it in plagiarism_plan.get('issues', []):
            if it.get('severity') == 'info':
                p3_items.append(f"[抄袭] {it.get('suggestion', '') or it.get('description', '')}")

    md += f"### P3 - 可选优化（info，共 {len(p3_items)} 项）\n\n"
    for i, s in enumerate(p3_items, 1):
        md += f"{i}. {s}\n"
    if not p3_items:
        md += "（无）\n"
    md += "\n"

    return md


def main():
    parser = argparse.ArgumentParser(description='Stage 6: 生成最终审核报告')
    parser.add_argument('--format-plan', required=True, help='格式审核 Plan JSON')
    parser.add_argument('--scoring-plan', required=True, help='评分预估 Plan JSON')
    parser.add_argument('--ocr-report', help='OCR 比对报告 JSON（可选）')
    parser.add_argument('--price-plan', help='价格检查 Plan JSON（v1.1.0 新增，可选）')
    parser.add_argument('--plagiarism-plan', help='抄袭检测 Plan JSON（v1.1.0 新增，可选）')
    parser.add_argument('--typo-plan', help='错别字检查 Plan JSON（v1.2.0 新增，可选）')
    parser.add_argument('--star-plan', help='标⭐️项检查 Plan JSON（v2.0.0 新增，可选）')
    parser.add_argument('--chapter-index', required=True, help='章节索引 JSON')
    parser.add_argument('--output', required=True, help='输出审核报告 .md 路径')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取格式审核 Plan：{args.format_plan}')
    with open(args.format_plan, 'r', encoding='utf-8') as f:
        format_plan = json.load(f)

    _logger.info(f'读取评分预估 Plan：{args.scoring_plan}')
    with open(args.scoring_plan, 'r', encoding='utf-8') as f:
        scoring_plan = json.load(f)

    ocr_report = None
    if args.ocr_report and Path(args.ocr_report).exists():
        _logger.info(f'读取 OCR 比对报告：{args.ocr_report}')
        with open(args.ocr_report, 'r', encoding='utf-8') as f:
            ocr_report = json.load(f)

    price_plan = None
    if args.price_plan and Path(args.price_plan).exists():
        _logger.info(f'读取价格检查 Plan：{args.price_plan}')
        with open(args.price_plan, 'r', encoding='utf-8') as f:
            price_plan = json.load(f)

    plagiarism_plan = None
    if args.plagiarism_plan and Path(args.plagiarism_plan).exists():
        _logger.info(f'读取抄袭检测 Plan：{args.plagiarism_plan}')
        with open(args.plagiarism_plan, 'r', encoding='utf-8') as f:
            plagiarism_plan = json.load(f)

    typo_plan = None
    if args.typo_plan and Path(args.typo_plan).exists():
        _logger.info(f'读取错别字检查 Plan：{args.typo_plan}')
        with open(args.typo_plan, 'r', encoding='utf-8') as f:
            typo_plan = json.load(f)

    star_plan = None
    if args.star_plan and Path(args.star_plan).exists():
        _logger.info(f'读取标⭐️项检查 Plan：{args.star_plan}')
        with open(args.star_plan, 'r', encoding='utf-8') as f:
            star_plan = json.load(f)

    _logger.info(f'读取章节索引：{args.chapter_index}')
    with open(args.chapter_index, 'r', encoding='utf-8') as f:
        chapter_index = json.load(f)

    # 渲染各部分
    md = ''
    md += render_overview(format_plan, scoring_plan, ocr_report, chapter_index)
    md += render_format_audit(format_plan)
    md += render_scoring_evaluation(scoring_plan)
    md += render_ocr_report(ocr_report)
    md += render_visual_review(chapter_index)
    md += render_star_items(star_plan)
    md += render_typo_check(typo_plan)
    md += render_price_check(price_plan)
    md += render_plagiarism_check(plagiarism_plan)
    md += render_improvement_suggestions(format_plan, scoring_plan, ocr_report, price_plan, plagiarism_plan)

    # 输出
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(md)

    file_size_kb = Path(args.output).stat().st_size / 1024
    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  文件大小：{file_size_kb:.1f} KB')
    _logger.info(f'  报告行数：{len(md.splitlines())}')


if __name__ == '__main__':
    main()
