#!/usr/bin/env python3
"""
Stage 5.3: 渲染关键页为 PNG

输入：
  --docx: 标书 .docx 路径
  --chapter-index: 章节索引 JSON
  --output-dir: 输出 PNG 目录

输出：{项目名}_审核预览PNG/ 目录下的关键页 PNG
"""
import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger
from bid_checker.core.renderer import render_docx_pages, detect_renderer

_logger = get_logger('render_key_pages')


def find_key_pages(chapter_index: Dict, key_page_types: str) -> list:
    """根据关键页类型找到对应的页码"""
    chapters = chapter_index.get('chapters', [])
    pages_to_render = set()

    type_keywords = {
        '封面': ['封面', '投标文件', '响应文件'],
        '投标函': ['投标函', '投标书'],
        '资质': ['资质', '资格', '证明文件'],
        '技术方案': ['技术方案', '技术部分', '实施方案'],
        '签字页': ['签字', '盖章', '授权委托'],
        '报价': ['报价', '投标一览表', '开标一览表'],
    }

    requested_types = [t.strip() for t in key_page_types.split(',')]

    # 总是渲染第 1 页（封面）
    pages_to_render.add(1)

    for ch in chapters:
        title = ch.get('title', '')
        page_start = ch.get('page_start', 0)
        for req_type in requested_types:
            keywords = type_keywords.get(req_type, [req_type])
            if any(kw in title for kw in keywords):
                if page_start > 0:
                    pages_to_render.add(page_start)
                break

    return sorted(pages_to_render)


def main():
    parser = argparse.ArgumentParser(description='Stage 5.3: 渲染关键页')
    parser.add_argument('--docx', required=True, help='标书 .docx 路径')
    parser.add_argument('--chapter-index', required=True, help='章节索引 JSON')
    parser.add_argument('--output-dir', required=True, help='输出 PNG 目录')
    parser.add_argument('--key-pages', default='封面,投标函,资质,技术方案,签字页',
                       help='关键页类型，逗号分隔')
    parser.add_argument('--max-pages', type=int, default=20, help='最多渲染页数')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取章节索引：{args.chapter_index}')
    with open(args.chapter_index, 'r', encoding='utf-8') as f:
        chapter_index = json.load(f)

    # 检测渲染器
    renderer_type, renderer_path = detect_renderer()
    if renderer_type is None:
        _logger.error('❌ 未检测到可用的渲染器（Microsoft Word 或 LibreOffice）')
        _logger.error('  Windows: 安装 Microsoft Office')
        _logger.error('  Linux/Mac: 安装 LibreOffice: apt install libreoffice 或 brew install libreoffice')
        sys.exit(1)
    _logger.info(f'  渲染器：{renderer_type} ({renderer_path})')

    # 找到关键页
    key_pages = find_key_pages(chapter_index, args.key_pages)
    _logger.info(f'  关键页码：{key_pages}')

    # 限制最大页数
    if len(key_pages) > args.max_pages:
        _logger.warning(f'  关键页数 {len(key_pages)} 超过最大值 {args.max_pages}，截断')
        key_pages = key_pages[:args.max_pages]

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 渲染
    try:
        rendered = render_docx_pages(args.docx, key_pages, str(output_dir), dpi=150)
        _logger.info(f'✅ 已渲染 {len(rendered)} 张 PNG：{output_dir}')
        for png in rendered:
            _logger.info(f'  - {png}')
    except Exception as e:
        _logger.error(f'  渲染失败：{e}')
        sys.exit(1)


if __name__ == '__main__':
    main()
