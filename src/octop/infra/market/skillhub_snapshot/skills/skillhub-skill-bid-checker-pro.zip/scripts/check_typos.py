#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
错别字 / 文字质量检查工具 (v1.0)
================================

对标书全文做多维度文字质量核查，输出结构化 JSON 供 Stage 6 报告渲染。

检查维度：
  ① 常见错别字词典      —— 如 布署→部署、签定→签订、帐目→账目
  ② 异形词 / 易混词      —— 如 其它→其他、截止→截至、定金→订金（法律效力不同）
  ③ 叠字 / 重复字        —— 连续相同汉字（非常常）、整词重复
  ④ 中英文标点混用      —— 中文文本中出现的半角 ,.;:!? 等
  ⑤ 金额大小写一致性    —— 大写金额（壹佰…圆…角…分）与小写数字是否相等（critical）
  ⑥ 专有名词一致性      —— 同一公司名 / 项目名称在不同处写法是否一致

设计原则：
  - 规则 / 词典可复现，不依赖外部 LLM，保证基础准确率 100%。
  - 语境相关错误（的/地/得、做/作、语义误用）由模型在 Stage 2.5 的
    【LLM 语境复核】步骤人工追加（见 SKILL.md），本脚本只输出可机器判定的部分。

输入：
  --input   标书全文（.docx / .txt / .doc 均可；.doc 走 olefile 提取）
  --output  输出 JSON 路径（默认 {input名}_错别字检查Plan.json）
  --chapter-index  可选，提供章节索引 JSON 以把行号映射到章节名

输出 JSON 结构：
  {
    "check_id", "check_time", "total_issues",
    "summary_by_type": {"常见错别字": n, ...},
    "issues": [
      {"id","type","severity","original","suggestion","context","location","confidence"}
    ]
  }
"""

import os
import re
import sys
import json
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.check_typos")
except Exception:
    import logging
    _logger = logging.getLogger("check_typos")
    if not _logger.handlers:
        _h = logging.StreamHandler(sys.stderr)
        _h.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_h)
        _logger.setLevel(logging.INFO)


# ===================== 规则数据 =====================

# ① 常见错别字（错 → 对）
TYPO_DICT: List[tuple] = [
    ("布署", "部署"), ("按步就班", "按部就班"), ("甘败下风", "甘拜下风"),
    ("凭心而论", "平心而论"), ("不径而走", "不胫而走"), ("迫不急待", "迫不及待"),
    ("默守成规", "墨守成规"), ("一愁莫展", "一筹莫展"), ("穿流不息", "川流不息"),
    ("融汇贯通", "融会贯通"), ("言简意该", "言简意赅"), ("再接再励", "再接再厉"),
    ("涣然一新", "焕然一新"), ("淋漓尽至", "淋漓尽致"), ("世外桃园", "世外桃源"),
    ("修养生息", "休养生息"), ("震聋发聩", "振聋发聩"), ("既往不究", "既往不咎"),
    ("并行不背", "并行不悖"), ("泊来品", "舶来品"), ("水蒸汽", "水蒸气"),
    ("蜂涌", "蜂拥"), ("决对", "绝对"), ("重迭", "重叠"), ("粗旷", "粗犷"),
    ("寒喧", "寒暄"), ("挖墙角", "挖墙脚"), ("九宵", "九霄"), ("弦律", "旋律"),
    ("精萃", "精粹"), ("坐阵", "坐镇"), ("发韧", "发轫"), ("凑和", "凑合"),
    ("亲睐", "青睐"), ("幅射", "辐射"), ("蜇伏", "蛰伏"), ("泻漏", "泄漏"),
    ("膺品", "赝品"), ("告磬", "告罄"), ("磬竹难书", "罄竹难书"),
    ("饮鸠止渴", "饮鸩止渴"), ("痉孪", "痉挛"), ("沉湎", "沉湎"),
    ("声名雀起", "声名鹊起"), ("贪脏枉法", "贪赃枉法"), ("引亢高歌", "引吭高歌"),
    # 标书高频（合同 / 财务语境）
    ("签定", "签订"), ("签定合同", "签订合同"), ("签定协议", "签订协议"),
    ("帐目", "账目"), ("帐单", "账单"), ("入帐", "入账"), ("出帐", "出账"),
    ("帐务", "账务"), ("帐表", "报表"), ("涵概", "涵盖"), ("急待", "亟待"),
    ("对换", "兑换"), ("平帐", "平账"), ("冲帐", "冲账"), ("过帐", "过账"),
]

# ② 异形词 / 易混词（错 → 对，带说明）
CONFUSABLE: List[tuple] = [
    ("其它", "其他", "正式公文中统一用『其他』"),
    ("截止", "截至", "『截止』后不接时间宾语；『截至』接时间（截至X月X日）"),
    ("定金", "订金", "法律上『定金』有担保罚则，『订金』无；标书中须区分"),
    ("权利", "权力", "『权利』多指权益，『权力』多指职权；按需区分"),
    ("必须", "必需", "『必须』为副词，『必需』为动词/形容词（必需的条件）"),
    ("启用", "起用", "『启用』指开始使用物，『起用』指任用某人"),
    ("以至", "以致", "『以致』表因果（多指不好结果），『以至』表延伸"),
    ("含义", "涵义", "现代规范多用『含义』"),
    ("启示", "启事", "『启事』为名词（招领启事），『启示』为启发"),
    ("考察", "考查", "『考查』侧重考核，『考察』侧重观察了解"),
    ("交待", "交代", "正式文书用『交代』"),
    ("其它", "其他", "与前述合并去重即可"),
]

# ⑤ 金额大写 → 数字 解析
_CAPITAL_DIGITS = {
    '零': 0, '壹': 1, '贰': 2, '叁': 3, '肆': 4, '伍': 5, '陆': 6,
    '柒': 7, '捌': 8, '玖': 9,
}
_CAPITAL_UNITS = {
    '拾': 10, '佰': 100, '仟': 1000,
    '万': 10000, '亿': 100000000,
}


def parse_capital_amount(text: str) -> Optional[float]:
    """解析中文大写金额（如 壹佰玖拾壹万捌仟贰佰捌拾玖圆玖角）为 float。失败返回 None。

    采用标准「pending-digit」算法：数字累加到 pending，拾/佰/仟 将 pending 乘单位并入
    当前节，万/亿 将当前节并入总计并乘进位，末尾总计 = 已入账 + 当前节 + pending。
    """
    t = text.replace('圆', '元').replace(' ', '')
    if not re.search(r'[零壹贰叁肆伍陆柒捌玖拾佰仟万亿]', t):
        return None

    # 拆分整数与小数（以首个 元 为界）
    m = re.search(r'元', t)
    integer_part = t[:m.start()] if m else t
    decimal_part = t[m.end():] if m else ''

    total = 0.0
    section = 0.0     # 当前 万/亿 节内已累加值
    pending = 0       # 待乘单位的数字
    for ch in integer_part:
        if ch in _CAPITAL_DIGITS:
            pending = _CAPITAL_DIGITS[ch]
        elif ch in ('拾', '佰', '仟'):
            section += pending * _CAPITAL_UNITS[ch]
            pending = 0
        elif ch == '万':
            section += pending
            total += section * 10000
            section = 0.0
            pending = 0
        elif ch == '亿':
            section += pending
            total += section * 100000000
            section = 0.0
            pending = 0
        elif ch == '零':
            continue
        else:
            continue
    integer_val = total + section + pending

    # 小数：角 / 分
    decimal_val = 0.0
    jiao = re.search(r'([零壹贰叁肆伍陆柒捌玖])角', decimal_part)
    fen = re.search(r'([零壹贰叁肆伍陆柒捌玖])分', decimal_part)
    if jiao:
        decimal_val += _CAPITAL_DIGITS[jiao.group(1)] * 0.1
    if fen:
        decimal_val += _CAPITAL_DIGITS[fen.group(1)] * 0.01

    result = integer_val + decimal_val
    if result <= 0:
        return None
    return round(result, 2)


# ===================== 文本读取 =====================

def read_text(input_path: str) -> str:
    """读取 .docx / .txt / .doc 为纯文本。"""
    low = input_path.lower()
    if low.endswith('.txt'):
        with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    if low.endswith('.docx'):
        try:
            from docx import Document
            doc = Document(input_path)
            return '\n'.join(p.text for p in doc.paragraphs)
        except Exception as e:
            _logger.warning(f"  python-docx 读取失败: {e}")
    if low.endswith('.doc'):
        try:
            from bid_checker.utils.doc_to_docx import _extract_doc_text_olefile
            txt = _extract_doc_text_olefile(input_path)
            if txt:
                return txt
        except Exception as e:
            _logger.warning(f"  olefile 提取失败: {e}")
    raise RuntimeError(f"无法读取输入文件: {input_path}")


# ===================== 各维度检查 =====================

def _ctx(text: str, idx: int, width: int = 30) -> str:
    s = max(0, idx - width)
    e = min(len(text), idx + width)
    return text[s:e].replace('\n', ' ').strip()


def check_typo_dict(text: str) -> List[Dict[str, Any]]:
    issues = []
    for wrong, right in TYPO_DICT:
        if not wrong:
            continue
        start = 0
        while True:
            i = text.find(wrong, start)
            if i < 0:
                break
            issues.append({
                "type": "常见错别字", "severity": "major",
                "original": wrong, "suggestion": right,
                "context": _ctx(text, i), "location": f"字符位 {i}",
                "confidence": "high",
            })
            start = i + len(wrong)
    return issues


def check_confusable(text: str) -> List[Dict[str, Any]]:
    issues = []
    seen = set()
    for wrong, right, note in CONFUSABLE:
        if wrong in seen:
            continue
        seen.add(wrong)
        if not wrong:
            continue
        start = 0
        while True:
            i = text.find(wrong, start)
            if i < 0:
                break
            issues.append({
                "type": "异形词/易混词", "severity": "minor",
                "original": wrong, "suggestion": f"{right}（{note}）",
                "context": _ctx(text, i), "location": f"字符位 {i}",
                "confidence": "medium",
            })
            start = i + len(wrong)
    return issues


def check_repeat_chars(text: str) -> List[Dict[str, Any]]:
    issues = []
    # 连续 3 个及以上相同汉字（排除标点/空白）
    for m in re.finditer(r'([一-龥])\1{2,}', text):
        ch = m.group(1)
        issues.append({
            "type": "叠字/重复字", "severity": "minor",
            "original": m.group(0), "suggestion": f"疑似多打，请确认是否为『{ch}』",
            "context": _ctx(text, m.start()), "location": f"字符位 {m.start()}",
            "confidence": "medium",
        })
    # 整词重复（2 字及以上词组连续出现两次）
    for m in re.finditer(r'([一-龥]{2,4})\1', text):
        w = m.group(1)
        issues.append({
            "type": "叠字/重复字", "severity": "minor",
            "original": m.group(0), "suggestion": f"疑似『{w}』重复，请确认",
            "context": _ctx(text, m.start()), "location": f"字符位 {m.start()}",
            "confidence": "low",
        })
    return issues


def check_punctuation(text: str) -> List[Dict[str, Any]]:
    issues = []
    # 中文文本中的半角标点（前后为中文）
    pattern = re.compile(r'([一-龥])([,.!?;:])')
    for m in pattern.finditer(text):
        issues.append({
            "type": "中英文标点混用", "severity": "minor",
            "original": m.group(0), "suggestion": f"半角『{m.group(2)}』建议改为全角『{m.group(2)}』",
            "context": _ctx(text, m.start()), "location": f"字符位 {m.start()}",
            "confidence": "high",
        })
    return issues


def check_amount_consistency(text: str) -> List[Dict[str, Any]]:
    """大写金额与其附近小写数字是否一致。critical 级。"""
    issues = []
    # 匹配大写金额（含 圆/元 及后续 角/分，贪婪吃到非大写字符为止）
    cap_pattern = re.compile(
        r'[零壹贰叁肆伍陆柒捌玖拾佰仟万亿]{2,}'
        r'(?:元|圆)[零壹贰叁肆伍陆柒捌玖拾佰仟万亿角分]*'
    )
    for m in cap_pattern.finditer(text):
        cap_str = m.group(0)
        cap_val = parse_capital_amount(cap_str)
        if cap_val is None:
            continue
        # 在附近 80 字符内查找小写金额
        window = text[max(0, m.start() - 80): m.end() + 80]
        nums = re.findall(r'\d[\d,]*\.?\d*', window)
        found_match = False
        for num in nums:
            try:
                val = float(num.replace(',', ''))
            except ValueError:
                continue
            if abs(val - cap_val) < 0.01:
                found_match = True
                break
        if not found_match:
            issues.append({
                "type": "金额大小写不一致", "severity": "critical",
                "original": cap_str,
                "suggestion": f"大写『{cap_str}』附近未找到一致的小写金额（解析值≈{cap_val:,.2f}），请核对大小写是否一致",
                "context": _ctx(text, m.start(), 50), "location": f"字符位 {m.start()}",
                "confidence": "high",
            })
    return issues


_GENERIC_PREFIX = ("我公司作为", "我司作为", "作为", "关于", "针对", "依据", "根据")
_GENERIC_SUFFIX = ("的供应商", "的采购人", "的招标人", "项目", "的投标方", "的承接方")


def _is_trivial_variant(a: str, b: str) -> bool:
    """判断 a/b 的包含关系是否仅为通用修饰语（如『我公司作为X』vs『X』），而非真变体。"""
    short, long = (a, b) if len(a) <= len(b) else (b, a)
    if short not in long:
        return False  # 非包含关系，视为真变体
    idx = long.index(short)
    prefix = long[:idx]
    suffix = long[idx + len(short):]
    if prefix in _GENERIC_PREFIX or suffix in _GENERIC_SUFFIX:
        return True  # 仅为修饰语，忽略
    return False


def check_proper_noun_consistency(text: str) -> List[Dict[str, Any]]:
    """提取候选专有名词（公司名/项目名），检测同一实体的写法变体。"""
    issues = []
    # 公司名 / 机构名模式
    names = re.findall(
        r'[一-龥A-Za-z0-9（）()]{2,40}?'
        r'(?:有限公司|股份公司|有限责任公司|集团|中心|学校|小学|中学|学院|大学|研究院)',
        text)
    from collections import Counter
    cnt = Counter(n.strip() for n in names)
    uniq = list(cnt.keys())
    for a in uniq:
        for b in uniq:
            if a == b:
                continue
            if a in b or b in a:
                if _is_trivial_variant(a, b):
                    continue  # 仅修饰语差异，非真变体
                issues.append({
                    "type": "专有名词一致性", "severity": "major",
                    "original": f"『{a}』 与 『{b}』",
                    "suggestion": "同一主体出现两种写法，请统一为工商登记全称",
                    "context": f"{a}({cnt[a]}次) / {b}({cnt[b]}次)",
                    "location": "全文", "confidence": "medium",
                })
                break  # 每个 a 只报一次
    return issues


# ===================== 主流程 =====================

def run_checks(text: str) -> Dict[str, Any]:
    all_issues: List[Dict[str, Any]] = []
    all_issues += check_typo_dict(text)
    all_issues += check_confusable(text)
    all_issues += check_repeat_chars(text)
    all_issues += check_punctuation(text)
    all_issues += check_amount_consistency(text)
    all_issues += check_proper_noun_consistency(text)

    # 编号
    for i, it in enumerate(all_issues, 1):
        it["id"] = f"typo_{i:03d}"

    summary: Dict[str, int] = {}
    for it in all_issues:
        summary[it["type"]] = summary.get(it["type"], 0) + 1

    return {
        "check_id": f"typo_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "check_time": datetime.now().isoformat(),
        "total_issues": len(all_issues),
        "summary_by_type": summary,
        "issues": all_issues,
        "llm_review_needed": True,  # 语境相关错误须模型追加
    }


def main():
    parser = argparse.ArgumentParser(description="错别字 / 文字质量检查 (v1.0)")
    parser.add_argument('--input', required=True, help='标书全文 .docx/.txt/.doc')
    parser.add_argument('--output', help='输出 JSON（默认 {input}_错别字检查Plan.json）')
    args = parser.parse_args()

    out_path = args.output or (os.path.splitext(args.input)[0] + "_错别字检查Plan.json")
    _logger.info(f"读取文本: {args.input}")
    text = read_text(args.input)
    _logger.info(f"文本长度: {len(text)} 字")
    result = run_checks(text)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or '.', exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    _logger.info(f"✓ 错别字检查完成：共 {result['total_issues']} 处")
    for t, n in result['summary_by_type'].items():
        _logger.info(f"   {t}: {n}")
    _logger.info(f"   输出: {out_path}")
    _logger.info("⚠ 语境相关错误（的/地/得、做/作、语义误用）须模型在 Stage 2.5 做 LLM 语境复核后追加。")
    return 0


if __name__ == '__main__':
    sys.exit(main())
