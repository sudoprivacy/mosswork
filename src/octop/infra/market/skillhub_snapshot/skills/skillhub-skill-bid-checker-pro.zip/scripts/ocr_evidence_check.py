#!/usr/bin/env python3
"""
Stage 5.2: OCR 资质详细比对

对评分预估 Plan 中标记为 needs_ocr_check 的评分项，OCR 对应图片并核对字段一致性。

输入：
  --evaluation-plan: 评分预估 Plan JSON
  --images-dir: 标书抽取的图片目录
  --requirements: 招标要求清单 JSON

输出：{项目名}_OCR比对报告.json
"""
import argparse
import json
import re
import sys
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any, Optional
from datetime import datetime

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger

_logger = get_logger('ocr_evidence_check')


@dataclass
class ConsistencyIssue:
    field_name: str
    expected: str
    actual: str
    severity: str


@dataclass
class OcrCheckItem:
    item_id: str
    title: str
    image_path: str
    ocr_result: Dict[str, str]
    consistency_check: Dict[str, bool]
    issues_found: List[Dict[str, str]]
    status: str  # compliant / non_compliant / error
    page_ref: str = ''


@dataclass
class OcrReport:
    ocr_check_id: str
    ocr_check_time: str
    total_checks: int
    compliant: int
    non_compliant: int
    errors: int
    checks: List[OcrCheckItem]


# 图片类型与 OCR 提取字段映射
IMAGE_TYPE_FIELDS = {
    '营业执照': {
        '公司名称': r'名称[：:]\s*([^\s]+)',
        '统一社会信用代码': r'统一社会信用代码[：:]\s*([A-Z0-9]+)',
        '法定代表人': r'法定代表人[：:]\s*([^\s]+)',
        '注册资本': r'注册资本[：:]\s*([^\s]+)',
        '成立日期': r'成立日期[：:]\s*([\d年月日]+)',
        '营业期限至': r'营业期限[^\d]*([\d年月日]+)',
    },
    '身份证': {
        '姓名': r'姓名[：:\s]*([^\s]+)',
        '性别': r'性别[：:\s]*([男女])',
        '民族': r'民族[：:\s]*([^\s]+)',
        '出生日期': r'出生[：:\s]*([\d年月日]+)',
        '住址': r'住址[：:\s]*([^\n]+)',
        '身份证号': r'公民身份号码[：:\s]*([0-9X]+)',
        '签发机关': r'签发机关[：:\s]*([^\n]+)',
        '有效期至': r'有效期[^\d]*([\d.年月日-]+)',
    },
    '资质证书': {
        '证书编号': r'证书编号[：:]\s*([A-Z0-9]+)',
        '资质等级': r'资质等级[：:]\s*([^\s]+)',
        '有效期至': r'有效期[^\d]*([\d年月日]+)',
        '发证机关': r'发证机关[：:]\s*([^\n]+)',
    },
    '检测报告': {
        '报告编号': r'报告编号[：:]\s*([A-Z0-9]+)',
        '检测日期': r'检测日期[：:]\s*([\d年月日]+)',
        '检测机构': r'检测机构[：:]\s*([^\n]+)',
    },
}

# 图片类型识别关键词
IMAGE_TYPE_KEYWORDS = {
    '营业执照': ['营业执照', '统一社会信用代码', '注册资本'],
    '身份证': ['公民身份号码', '签发机关', '出生'],
    '资质证书': ['资质等级', '资质证书', '发证机关'],
    '检测报告': ['检测报告', '检测机构', '检测日期'],
}


def detect_image_type(ocr_text: str) -> str:
    """根据 OCR 文本识别图片类型"""
    for img_type, keywords in IMAGE_TYPE_KEYWORDS.items():
        hits = sum(1 for kw in keywords if kw in ocr_text)
        if hits >= 1:
            return img_type
    return '未知'


def extract_fields_by_type(ocr_text: str, img_type: str) -> Dict[str, str]:
    """根据图片类型提取字段"""
    fields = {}
    patterns = IMAGE_TYPE_FIELDS.get(img_type, {})
    for field_name, pattern in patterns.items():
        match = re.search(pattern, ocr_text)
        if match:
            fields[field_name] = match.group(1).strip()
        else:
            fields[field_name] = ''
    return fields


def check_validity(field_name: str, value: str, current_date: datetime = None) -> Optional[Dict]:
    """检查有效期相关字段"""
    if not value or '有效期' not in field_name and '期限' not in field_name and '日期' not in field_name:
        return None

    if current_date is None:
        current_date = datetime.now()

    # 提取日期
    date_patterns = [
        r'(\d{4})年(\d{1,2})月(\d{1,2})日',
        r'(\d{4})\.(\d{1,2})\.(\d{1,2})',
        r'(\d{4})-(\d{1,2})-(\d{1,2})',
        r'(\d{4})/(\d{1,2})/(\d{1,2})',
    ]

    extracted_date = None
    for pat in date_patterns:
        m = re.search(pat, value)
        if m:
            try:
                year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
                extracted_date = datetime(year, month, day)
                break
            except (ValueError, IndexError):
                continue

    if extracted_date is None:
        return None

    # "长期" 等永久有效
    if '长期' in value or '永久' in value:
        return None

    if extracted_date < current_date:
        days_ago = (current_date - extracted_date).days
        return {
            'issue': f'{field_name}已过期',
            'severity': 'critical',
            'detail': f'有效期至 {extracted_date.strftime("%Y-%m-%d")}，当前 {current_date.strftime("%Y-%m-%d")}，已过期 {days_ago} 天',
        }

    # 即将过期（30天内）
    days_left = (extracted_date - current_date).days
    if days_left <= 30:
        return {
            'issue': f'{field_name}即将过期',
            'severity': 'major',
            'detail': f'有效期至 {extracted_date.strftime("%Y-%m-%d")}，仅剩 {days_left} 天',
        }

    return None


def check_consistency(item_id: str, title: str, ocr_fields: Dict, requirements: Dict) -> Dict:
    """检查 OCR 提取字段与招标要求的一致性"""
    consistency = {}
    issues = []

    # 检查有效期相关字段
    for field_name, value in ocr_fields.items():
        if not value:
            continue
        validity_issue = check_validity(field_name, value)
        if validity_issue:
            issues.append(validity_issue)
            consistency[f'{field_name}有效'] = False
        else:
            consistency[f'{field_name}有效'] = True

    # 检查公司名称与投标人一致（如果有）
    company_name = ocr_fields.get('公司名称', '')
    if company_name:
        # 从招标要求获取投标人期望名称（如果有）
        project_info = requirements.get('project_info', {})
        # 这里简化处理，实际应从标书中提取投标人名称
        consistency['公司名称已识别'] = True

    return consistency, issues


def ocr_image_via_zai(image_path: str) -> Optional[str]:
    """通过 z-ai CLI 调用 VLM 做 OCR"""
    try:
        result = subprocess.run(
            ['z-ai', 'vision', '-p',
             '请提取这张图片中的所有文字信息，按字段对齐输出，格式为"字段名：值"。如果是营业执照、身份证、资质证书等证件，请提取所有可见字段。',
             '-i', image_path],
            capture_output=True, text=True, timeout=60, check=False
        )
        if result.returncode != 0:
            _logger.warning(f'  z-ai vision 调用失败：{result.stderr[:200]}')
            return None
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        _logger.warning(f'  z-ai vision 调用超时（60秒）')
        return None
    except FileNotFoundError:
        _logger.warning('  z-ai CLI 未安装')
        return None


def ocr_image_via_local(image_path: str) -> Optional[str]:
    """通过本地 RapidOCR 引擎做 OCR（基于 ONNX Runtime，无需 API 密钥）"""
    try:
        from bid_checker.core.ocr_engine import create_ocr_engine
        engine = create_ocr_engine(verbose=False)
        if engine is None:
            return None

        from PIL import Image
        img = Image.open(image_path)
        result = engine.smart_recognize(img)
        if isinstance(result, dict):
            # 拼接所有字段
            parts = []
            for k, v in result.items():
                if v:
                    parts.append(f'{k}：{v}')
            return '\n'.join(parts)
        elif isinstance(result, str):
            return result
        return None
    except Exception as e:
        _logger.warning(f'  本地 OCR 失败：{e}')
        return None


def find_image_for_item(item_id: str, title: str, images_dir: Path) -> Optional[str]:
    """根据评分项找到对应的图片文件"""
    # 简化策略：根据 title 中的关键词找匹配的图片文件名
    images = list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.png')) + list(images_dir.glob('*.jpeg'))
    if not images:
        return None

    # 关键词匹配
    title_keywords = [kw for kw in ['营业执照', '身份证', '资质', '证书', '检测报告'] if kw in title]
    if not title_keywords:
        # 没有明确关键词，返回第一张（简化处理，实际应通过章节位置定位）
        return str(images[0]) if images else None

    for img in images:
        img_name = img.name
        if any(kw in img_name for kw in title_keywords):
            return str(img)

    return None


def main():
    parser = argparse.ArgumentParser(description='Stage 5.2: OCR 资质详细比对')
    parser.add_argument('--evaluation-plan', required=True, help='评分预估 Plan JSON')
    parser.add_argument('--images-dir', required=True, help='标书抽取图片目录')
    parser.add_argument('--requirements', required=True, help='招标要求清单 JSON')
    parser.add_argument('--output', required=True, help='输出 OCR 比对报告 JSON')
    parser.add_argument('--no-zai', action='store_true', help='不使用 z-ai vision')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取评分预估 Plan：{args.evaluation_plan}')
    with open(args.evaluation_plan, 'r', encoding='utf-8') as f:
        eval_plan = json.load(f)

    _logger.info(f'读取招标要求：{args.requirements}')
    with open(args.requirements, 'r', encoding='utf-8') as f:
        requirements = json.load(f)

    images_dir = Path(args.images_dir)
    if not images_dir.exists():
        _logger.warning(f'图片目录不存在：{images_dir}')
        # 创建空目录避免后续报错
        images_dir.mkdir(parents=True, exist_ok=True)

    # 找出需要 OCR 检查的项
    items_to_check = [it for it in eval_plan.get('items', []) if it.get('needs_ocr_check')]
    _logger.info(f'  需要 OCR 检查的项：{len(items_to_check)}')

    ocr_items = []
    compliant_count = 0
    non_compliant_count = 0
    error_count = 0

    for item in items_to_check:
        item_id = item.get('item_id', '')
        title = item.get('title', '')
        ocr_target = item.get('ocr_check_target', '')
        page_ref = item.get('page_ref', '')

        _logger.info(f'  [{item_id}] {title} - OCR 检查中...')

        # 找图片
        image_path = find_image_for_item(item_id, title, images_dir)
        if not image_path:
            _logger.warning(f'    未找到对应图片')
            ocr_items.append(OcrCheckItem(
                item_id=item_id, title=title, image_path='',
                ocr_result={}, consistency_check={},
                issues_found=[{'issue': '未找到对应图片', 'severity': 'major',
                              'detail': f'在 {images_dir} 中未找到匹配「{title}」的图片'}],
                status='error', page_ref=page_ref,
            ))
            error_count += 1
            continue

        # OCR 提取
        ocr_text = None
        if not args.no_zai:
            ocr_text = ocr_image_via_zai(image_path)
        if not ocr_text:
            ocr_text = ocr_image_via_local(image_path)

        if not ocr_text:
            _logger.warning(f'    OCR 提取失败')
            ocr_items.append(OcrCheckItem(
                item_id=item_id, title=title, image_path=image_path,
                ocr_result={}, consistency_check={},
                issues_found=[{'issue': 'OCR 提取失败', 'severity': 'major',
                              'detail': 'z-ai vision 和本地 OCR 均失败，请检查 OCR 配置'}],
                status='error', page_ref=page_ref,
            ))
            error_count += 1
            continue

        # 识别图片类型
        img_type = detect_image_type(ocr_text)
        _logger.info(f'    图片类型：{img_type}')

        # 提取字段
        ocr_fields = extract_fields_by_type(ocr_text, img_type)
        _logger.info(f'    提取字段：{ocr_fields}')

        # 一致性检查
        consistency, issues = check_consistency(item_id, title, ocr_fields, requirements)

        # 状态判定
        if issues:
            critical_count = sum(1 for i in issues if i.get('severity') == 'critical')
            if critical_count > 0:
                status = 'non_compliant'
                non_compliant_count += 1
            else:
                status = 'non_compliant'  # 有 issue 就算 non_compliant
                non_compliant_count += 1
        else:
            status = 'compliant'
            compliant_count += 1

        ocr_items.append(OcrCheckItem(
            item_id=item_id, title=title, image_path=image_path,
            ocr_result=ocr_fields, consistency_check=consistency,
            issues_found=issues, status=status, page_ref=page_ref,
        ))

    report = OcrReport(
        ocr_check_id=f'ocr_{datetime.now().strftime("%Y%m%d_%H%M%S")}',
        ocr_check_time=datetime.now().isoformat(),
        total_checks=len(items_to_check),
        compliant=compliant_count,
        non_compliant=non_compliant_count,
        errors=error_count,
        checks=ocr_items,
    )

    output = asdict(report)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  总检查项：{report.total_checks}')
    _logger.info(f'  合规：{compliant_count}')
    _logger.info(f'  不合规：{non_compliant_count}')
    _logger.info(f'  错误：{error_count}')


if __name__ == '__main__':
    main()
