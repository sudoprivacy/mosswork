#!/usr/bin/env python3
"""
Stage 2.3: 生成章节摘要
对每个章节用 LLM 生成 200 字内的摘要。

输入：{项目名}_标书章节索引.json
输出：{项目名}_标书章节摘要.json

策略：
  - 章节数 ≤30：一次 LLM 调用处理所有章节
  - 章节数 >30：分批调用，每批 30 个章节
"""
import argparse
import json
import re
import subprocess
import sys
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger

_logger = get_logger('generate_chapter_summaries')

BATCH_SIZE = 30  # 每批 30 个章节


@dataclass
class ChapterSummary:
    chapter_id: str
    title: str
    summary: str
    key_points: List[str] = field(default_factory=list)


def build_prompt(chapters: List[Dict]) -> str:
    """构建 LLM 提示词"""
    chapter_list = []
    for ch in chapters:
        preview = (ch.get('full_text') or '')[:500]
        chapter_list.append(f"""
章节ID：{ch['chapter_id']}
标题：{ch['title']}
前500字：{preview}
""")
    chapters_text = '\n---\n'.join(chapter_list)

    return f"""请为以下标书的每个章节生成摘要。

要求：
1. 每个章节摘要不超过 200 字
2. 摘要应包含：章节主要内容、关键信息点（如金额、日期、签字位、关键字段）
3. 提取 2-5 个关键点（key_points）
4. 关键点用于后续评分项检索，应突出该章节的"可被检索的特征"

输出 JSON 格式（严格遵循，不要其他文字）：
{{
  "summaries": [
    {{
      "chapter_id": "ch001",
      "summary": "本章为投标函正文，包含投标人致采购人的函件，落款含法人签字位、公章位、日期位。投标金额为人民币壹佰贰拾万元整。",
      "key_points": ["投标金额120万", "法人签字位", "公章位", "日期位"]
    }}
  ]
}}

待摘要的章节：
{chapters_text}
"""


def call_llm(prompt: str) -> Dict:
    """调用 z-ai CLI"""
    try:
        result = subprocess.run(
            ['z-ai', 'chat', '-p', prompt],
            capture_output=True, text=True, timeout=300, check=False
        )
        if result.returncode != 0:
            _logger.warning(f'  z-ai CLI 调用失败：{result.stderr[:200]}')
            return {'summaries': []}

        output = result.stdout.strip()
        json_match = re.search(r'\{[\s\S]*\}', output)
        if not json_match:
            _logger.warning('  无法从 LLM 输出提取 JSON')
            return {'summaries': []}

        return json.loads(json_match.group(0))
    except subprocess.TimeoutExpired:
        _logger.warning('  z-ai CLI 调用超时（300秒）')
        return {'summaries': []}
    except json.JSONDecodeError as e:
        _logger.warning(f'  LLM 输出 JSON 解析失败：{e}')
        return {'summaries': []}
    except FileNotFoundError:
        _logger.warning('  z-ai CLI 未安装，使用规则兜底')
        return {'summaries': []}


def rule_based_summary(ch: Dict) -> ChapterSummary:
    """规则兜底：取前 200 字 + 提取关键词作为摘要"""
    text = ch.get('full_text') or ''
    title = ch.get('title', '')

    # 取前 200 字
    summary = text[:200].replace('\n', ' ').strip()
    if len(text) > 200:
        summary += '...'

    # 提取关键点（简单：标题 + 出现的金额/日期）
    key_points = [title]
    money_match = re.findall(r'[壹贰叁肆伍陆柒捌玖拾佰仟万亿]+元|[0-9,]+(?:\.[0-9]+)?(?:万元|元)', text)
    key_points.extend(money_match[:3])
    date_match = re.findall(r'\d{{4}}年\d{{1,2}}月\d{{1,2}}日', text)
    key_points.extend(date_match[:2])

    return ChapterSummary(
        chapter_id=ch['chapter_id'],
        title=title,
        summary=summary,
        key_points=key_points[:5],
    )


def main():
    parser = argparse.ArgumentParser(description='Stage 2.3: 生成章节摘要')
    parser.add_argument('--input', required=True, help='章节索引 JSON 路径')
    parser.add_argument('--output', required=True, help='输出章节摘要 JSON 路径')
    parser.add_argument('--no-llm', action='store_true', help='不调用 LLM，仅用规则兜底')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取章节索引：{args.input}')
    with open(args.input, 'r', encoding='utf-8') as f:
        chapter_data = json.load(f)

    chapters = chapter_data.get('chapters', [])
    _logger.info(f'  章节数：{len(chapters)}')

    all_summaries = []

    if not args.no_llm and chapters:
        # 分批调用 LLM
        batches = [chapters[i:i+BATCH_SIZE] for i in range(0, len(chapters), BATCH_SIZE)]
        _logger.info(f'  分 {len(batches)} 批调用 LLM')

        for batch_idx, batch in enumerate(batches):
            _logger.info(f'  处理第 {batch_idx+1}/{len(batches)} 批（{len(batch)} 个章节）...')
            prompt = build_prompt(batch)
            result = call_llm(prompt)

            if result.get('summaries'):
                for s in result['summaries']:
                    # 找到对应章节
                    ch = next((c for c in batch if c['chapter_id'] == s.get('chapter_id')), None)
                    if ch:
                        all_summaries.append(ChapterSummary(
                            chapter_id=s.get('chapter_id', ''),
                            title=ch.get('title', ''),
                            summary=s.get('summary', ''),
                            key_points=s.get('key_points', []),
                        ))
            else:
                # LLM 失败，规则兜底
                for ch in batch:
                    all_summaries.append(rule_based_summary(ch))
    else:
        # 全部规则兜底
        _logger.info('  使用规则兜底生成摘要')
        for ch in chapters:
            all_summaries.append(rule_based_summary(ch))

    # 输出
    output = {
        'total_chapters': len(all_summaries),
        'llm_used': not args.no_llm,
        'summaries': [asdict(s) for s in all_summaries],
    }

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  摘要数：{len(all_summaries)}')


if __name__ == '__main__':
    main()
