#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
匹配引擎 — Phase 2B Step 3

将模板需求清单(报告1)与多源数据做智能匹配，
生成"资料来源对照报告"(报告2)。

数据源（三层）：
  1. Phase 1 解析报告：项目名称、编号、招标人、投标日期等上下文数据
  2. Phase 2B 资料扫描数据：投标人信息、人员、资质等实体数据
  3. 推断数据：法人信息（从人员数据+配置推断）、业务规则默认值

匹配策略：
  1. 精确匹配：字段名完全对应
  2. 别名匹配：字段名变体对应
  3. 推断匹配：从已知数据推断（法人=首个人员、法人职务=配置值）
  4. 章节关联：资料文件与模板位置章节关联
  5. 缺失标记：无匹配的字段标记为❌缺失
"""

import os
import sys
import json
import re
import argparse

# v9.0: 统一日志
try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.matching_engine")
except ImportError:
    import logging
    _logger = logging.getLogger("matching_engine")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)



# ============================================================
# 字段名映射表（别名匹配）
# ============================================================

# 模板字段名 → 资料数据可能出现的别名
FIELD_ALIAS_MAP = {
    '项目名称': ['项目名称', '项目名'],
    '项目编号': ['项目编号', '编号', '项目编号号'],
    '招标人名称': ['招标人名称', '招标人', '采购人名称'],
    '投标人名称': ['投标人名称', '单位名称', '公司名称', '投标人', '名称'],
    '联系地址': ['联系地址', '地址', '住所'],
    '联系电话': ['联系电话', '电话', '手机'],
    '传真': ['传真'],
    '邮编': ['邮编', '邮政编码'],
    '电子邮箱': ['电子邮箱', '邮箱', '电子信箱'],
    '法人姓名': ['法人姓名', '法人', '法定代表人'],
    '法人性别': ['法人性别', '性别'],
    '法人年龄': ['法人年龄', '年龄'],
    '法人职务': ['法人职务', '职务', '担任职务', '总经理'],
    '法定代表人': ['法定代表人', '法人姓名', '法人', '法定代表人姓名'],
    '授权代表': ['授权代表', '被授权人', '被授权人姓名', '委托代理人'],
    '单位性质': ['单位性质', '类型', '公司类型'],
    '成立时间': ['成立时间', '成立日期'],
    '经营期限': ['经营期限', '营业期限'],
    '经营范围': ['经营范围'],
    '社会信用代码': ['社会信用代码', '统一社会信用代码', '信用代码'],
    '投标日期': ['投标日期', '开标时间', '投标截止时间'],
    '签名日期': ['投标日期', '开标时间'],
    '系投标人名称(法定代表人句)': ['投标人名称', '单位名称'],
}

# 表格类型 → 资料数据匹配规则
TABLE_MATCH_RULES = {
    'table_personnel': {
        'data_key': 'personnel',
        'match_fields': ['姓名', '性别', '年龄', '职务'],
    },
    'table_deviation': {
        'data_key': 'deviation',
        'match_fields': ['偏离表数据'],
    },
    'table_quotation': {
        'data_key': 'quotation',
        'match_fields': ['报价数据'],
    },
    'table_performance': {
        'data_key': 'performance',
        'match_fields': ['业绩数据'],
    },
}


# ============================================================
# Phase 1 解析报告数据提取
# ============================================================

def extract_phase1_data(report_path, source_text_path=None):
    """
    从Phase 1解析报告(Markdown)提取项目级数据字段。
    对未提取到的字段，尝试从招标文件原始文本作为后备。

    返回 dict: {field_name: value, ...}，作为匹配引擎的额外数据源。
    """
    phase1_data = {}

    if report_path and os.path.exists(report_path):
        with open(report_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # === 从Markdown表格提取项目基本信息 ===
        basic_info_patterns = [
            (r'\|\s*项目名称\s*\|\s*([^|]+)\s*\|', '项目名称'),
            (r'\|\s*招标人\s*\|\s*([^|]+)\s*\|', '招标人名称'),
            (r'\|\s*采购人\s*\|\s*([^|]+)\s*\|', '招标人名称'),
            (r'\|\s*最高限价[^|]*\|\s*([^|]+)\s*\|', '最高限价'),
        ]

        for pattern, field_name in basic_info_patterns:
            match = re.search(pattern, content)
            if match:
                value = match.group(1).strip()
                if value and value not in phase1_data:
                    phase1_data[field_name] = value

        # === 提取项目编号 ===
        proj_num_patterns = [
            r'项目编号[：:]\s*([\w\-]+)',
            r'编号[：:]\s*([\w\-]+)',
            r'\|\s*项目编号\s*\|\s*([^|]+)\s*\|',
        ]
        for pattern in proj_num_patterns:
            match = re.search(pattern, content)
            if match:
                phase1_data['项目编号'] = match.group(1).strip()
                break

        # === 提取投标截止/开标时间 ===
        time_row_patterns = [
            (r'\|\s*\d+\s*\|\s*投标截止时间\s*\|\s*\*?\*?([^|]+?)\s*\*?\*?\s*\|', '投标截止时间'),
            (r'\|\s*\d+\s*\|\s*开标时间\s*\|\s*\*?\*?([^|]+?)\s*\*?\*?\s*\|', '开标时间'),
        ]
        for pattern, field_name in time_row_patterns:
            for match in re.finditer(pattern, content):
                value = match.group(1).strip().replace('*', '')
                if value and not re.match(r'^[\d]+日前$', value) and '投标截止时间' not in value:
                    phase1_data[field_name] = value
                    break

        # 如果有截止时间，推断投标日期
        if '投标截止时间' in phase1_data:
            phase1_data['投标日期'] = phase1_data['投标截止时间']
        elif '开标时间' in phase1_data:
            phase1_data['投标日期'] = phase1_data['开标时间']

        # === 提取资金来源/预算金额 ===
        budget_match = re.search(r'\|\s*资金来源\s*\|\s*([^|]+)\s*\|', content)
        if budget_match:
            phase1_data['资金来源'] = budget_match.group(1).strip()

    # === 后备：从招标文件原始文本提取未获取的字段 ===
    if source_text_path and os.path.exists(source_text_path):
        with open(source_text_path, 'r', encoding='utf-8') as f:
            raw_text = f.read()

        # 项目编号（解析报告中可能缺失）
        if '项目编号' not in phase1_data:
            match = re.search(r'项目编号[：:]\s*([\w\-()]+)', raw_text)
            if match:
                phase1_data['项目编号'] = match.group(1).strip()

        # 项目名称（如果解析报告也没提取到）
        if '项目名称' not in phase1_data:
            match = re.search(r'项目名称[：:]\s*([^\n,，]+)', raw_text)
            if match:
                phase1_data['项目名称'] = match.group(1).strip()

    return phase1_data


def infer_derived_data(material_data, config):
    """
    从已有数据+配置推断衍生数据。

    核心推断：
      - 法人信息：取personnel列表中第一个人员为法定代表人
      - 法人职务：从business_rules.法人职务读取
      - 其他默认值：从business_rules读取
    """
    derived = {}

    personnel = material_data.get('personnel', [])
    business_rules = config.get('business_rules', {})

    # === 法人推断 ===
    if personnel:
        # 第一个人员作为法定代表人
        first_person = personnel[0]
        name = first_person.get('姓名', '')
        if name:
            derived['法人姓名'] = name
            derived['法定代表人'] = name
            derived['法人性别'] = first_person.get('性别', '')
            derived['法人年龄'] = first_person.get('年龄', '')

    # 从配置补充法人职务
    法人职务 = business_rules.get('法人职务', '')
    if 法人职务:
        derived['法人职务'] = 法人职务

    # 投标日期来源配置
    投标日期来源 = business_rules.get('投标日期来源', '开标时间')
    derived['_投标日期来源'] = 投标日期来源

    return derived


def match_template_with_materials(template_data, material_data, phase1_data=None, derived_data=None):
    """
    将模板需求与多源数据做匹配，生成映射表。

    参数:
      template_data: template_scanner输出的扫描数据（dict）
      material_data: material_scanner_v2输出的资料数据（dict）
      phase1_data: Phase 1解析报告提取的项目级数据（dict, 可选）
      derived_data: 从已知数据+配置推断的衍生数据（dict, 可选）

    返回:
      dict: {
        'mapping_table': [...],
        'statistics': {...},
        'missing_items': [...],
      }
    """
    fill_positions = template_data.get('fill_positions', [])
    data_points = material_data.get('data_points', [])
    personnel = material_data.get('personnel', [])

    # 兼容旧版扁平字典格式（scan_user_materials 输出）
    # 如果没有 data_points 但有顶层字段，自动转换为 data_points 格式
    if not data_points and isinstance(material_data, dict):
        flat_fields = {k: v for k, v in material_data.items()
                       if not k.startswith('_') and k not in ('OCR原始文字', '业绩案例')
                       and not isinstance(v, (list,)) or (isinstance(v, str) and v)}
        if flat_fields:
            skip_keys = {'OCR原始文字', '业绩案例'}
            for k, v in material_data.items():
                if k in skip_keys or k.startswith('_') or isinstance(v, list):
                    continue
                if isinstance(v, str) and v.strip():
                    data_points.append({
                        'field_name': k,
                        'value': v,
                        'source_file': 'user_data_scanned.json',
                        'source_type': 'ocr_scanned',
                        'confidence': 'high',
                    })

    phase1_data = phase1_data or {}
    derived_data = derived_data or {}

    # 构建多源数据查找索引
    # 优先级: material > phase1 > derived
    data_index = {}  # field_name → [data_point, ...]
    for dp in data_points:
        fn = dp['field_name']
        data_index.setdefault(fn, []).append(dp)

    # Phase 1 数据加入索引
    phase1_index = {}
    for fn, value in phase1_data.items():
        phase1_index[fn] = {
            'field_name': fn,
            'value': value,
            'source_file': 'Phase1_解析报告',
            'source_type': 'parse_report',
            'confidence': 'high',
            'ocr_type': None,
            'expected_chapters': [],
        }

    # 推断数据加入索引
    derived_index = {}
    for fn, value in derived_data.items():
        if fn.startswith('_'):  # 跳过元信息
            continue
        derived_index[fn] = {
            'field_name': fn,
            'value': value,
            'source_file': '推断数据',
            'source_type': 'inferred',
            'confidence': 'medium_inferred',
            'ocr_type': None,
            'expected_chapters': [],
        }

    # 逐个模板需求位置匹配
    mapping_table = []
    missing_items = []

    for pos in fill_positions:
        field_name = pos['field_name']
        fill_type = pos['fill_type']
        chapter = f"{pos['chapter_num']}-{pos['chapter_title']}"

        # === 跳过签名位 ===
        if fill_type == 'signature':
            mapping_table.append({
                'template_field': field_name,
                'template_chapter': chapter,
                'template_para_idx': pos['para_idx'],
                'template_fill_type': fill_type,
                'template_pattern': pos['pattern'],
                'template_required': pos['required_level'],
                'matched_value': '（签字/盖章位，不填）',
                'matched_source': '—',
                'matched_source_type': 'skip',
                'confidence': 'skip',
                'status': 'skip',
            })
            continue

        # === 图片插入位 ===
        if fill_type == 'image':
            # 检查是否有对应图片资源
            attach_kws = pos.get('attach_keywords', [])
            image_files = []
            for fi in material_data.get('file_inventory', []):
                nc = fi.get('name_classification', {})
                # Level 1: 文件名关联
                if nc.get('category') in ('人员资料', '资质证明', '业绩证明'):
                    image_files.append(fi['filename'])
                # Level 2: 标题关联
            for fa in material_data.get('file_analysis', []):
                for title in fa.get('titles', []):
                    for kw in attach_kws:
                        if kw in title:
                            image_files.append(fa['filename'])
                            break

            mapping_table.append({
                'template_field': field_name,
                'template_chapter': chapter,
                'template_para_idx': pos['para_idx'],
                'template_fill_type': 'image',
                'template_pattern': pos['pattern'],
                'template_required': pos['required_level'],
                'matched_value': f'需插入图片（关键词: {attach_kws}）',
                'matched_source': ', '.join(image_files[:3]) if image_files else '❌ 未找到',
                'matched_source_type': 'image_insertion',
                'confidence': image_files and 'medium' or 'none',
                'status': image_files and 'image_pending' or 'missing',
            })
            continue

        # === 表格位 ===
        if fill_type == 'table':
            table_type = pos.get('table_type', 'unknown')
            rule = TABLE_MATCH_RULES.get(f'table_{table_type}', None)

            if table_type == 'personnel':
                # 人员表 → 查找personnel数据
                if personnel:
                    person_names = ', '.join([p.get('姓名', '') for p in personnel[:5]])
                    source_file = personnel[0].get('source_file', '') if personnel else ''
                    mapping_table.append({
                        'template_field': pos['field_name'],
                        'template_chapter': chapter,
                        'template_para_idx': pos['para_idx'],
                        'template_fill_type': 'table',
                        'template_pattern': pos['pattern'],
                        'template_required': pos['required_level'],
                        'matched_value': f'{len(personnel)}人: {person_names}',
                        'matched_source': source_file,
                        'matched_source_type': 'table_extraction',
                        'confidence': 'high',
                        'status': 'matched',
                    })
                else:
                    mapping_table.append({
                        'template_field': pos['field_name'],
                        'template_chapter': chapter,
                        'template_para_idx': pos['para_idx'],
                        'template_fill_type': 'table',
                        'template_pattern': pos['pattern'],
                        'template_required': pos['required_level'],
                        'matched_value': '❌ 无人员数据',
                        'matched_source': '—',
                        'matched_source_type': 'none',
                        'confidence': 'none',
                        'status': 'missing',
                    })
                    missing_items.append(field_name)
                continue

            elif table_type in ('deviation', 'quotation', 'performance'):
                # 其他表格 → 需要用户数据，暂时标记待确认
                mapping_table.append({
                    'template_field': pos['field_name'],
                    'template_chapter': chapter,
                    'template_para_idx': pos['para_idx'],
                    'template_fill_type': 'table',
                    'template_pattern': pos['pattern'],
                    'template_required': pos['required_level'],
                    'matched_value': f'待用户提供{table_type}数据',
                    'matched_source': '—',
                    'matched_source_type': 'user_input_required',
                    'confidence': 'pending',
                    'status': 'pending',
                })
                continue

            else:
                # 通用表格
                mapping_table.append({
                    'template_field': pos['field_name'],
                    'template_chapter': chapter,
                    'template_para_idx': pos['para_idx'],
                    'template_fill_type': 'table',
                    'template_pattern': pos['pattern'],
                    'template_required': pos['required_level'],
                    'matched_value': '待确认表格数据来源',
                    'matched_source': '—',
                    'matched_source_type': 'pending',
                    'confidence': 'pending',
                    'status': 'pending',
                })
                continue

        # === 日期位 ===
        if fill_type == 'date':
            # 尝试匹配日期类字段
            date_matched = _match_field(field_name, data_index, phase1_index, derived_index)
            if date_matched:
                mapping_table.append({
                    'template_field': field_name,
                    'template_chapter': chapter,
                    'template_para_idx': pos['para_idx'],
                    'template_fill_type': 'date',
                    'template_pattern': pos['pattern'],
                    'template_required': pos['required_level'],
                    'matched_value': date_matched['value'],
                    'matched_source': date_matched['source_file'],
                    'matched_source_type': date_matched['source_type'],
                    'confidence': date_matched['confidence'],
                    'status': 'matched',
                })
            else:
                # 特殊处理：投标日期可能从解析报告中获取
                mapping_table.append({
                    'template_field': field_name,
                    'template_chapter': chapter,
                    'template_para_idx': pos['para_idx'],
                    'template_fill_type': 'date',
                    'template_pattern': pos['pattern'],
                    'template_required': pos['required_level'],
                    'matched_value': '❌ 缺失日期数据',
                    'matched_source': '—',
                    'matched_source_type': 'none',
                    'confidence': 'none',
                    'status': 'missing',
                })
                missing_items.append(field_name)
            continue

        # === 文本位 ===
        matched = _match_field(field_name, data_index, phase1_index, derived_index)
        if matched:
            mapping_table.append({
                'template_field': field_name,
                'template_chapter': chapter,
                'template_para_idx': pos['para_idx'],
                'template_fill_type': fill_type,
                'template_pattern': pos['pattern'],
                'template_required': pos['required_level'],
                'matched_value': matched['value'],
                'matched_source': matched['source_file'],
                'matched_source_type': matched['source_type'],
                'confidence': matched['confidence'],
                'status': 'matched',
            })
        else:
            mapping_table.append({
                'template_field': field_name,
                'template_chapter': chapter,
                'template_para_idx': pos['para_idx'],
                'template_fill_type': fill_type,
                'template_pattern': pos['pattern'],
                'template_required': pos['required_level'],
                'matched_value': '❌ 缺失',
                'matched_source': '—',
                'matched_source_type': 'none',
                'confidence': 'none',
                'status': 'missing',
            })
            if pos['required_level'] == 'required':
                missing_items.append(field_name)

    # 统计
    stats = {
        'total': len(mapping_table),
        'matched': sum(1 for m in mapping_table if m['status'] == 'matched'),
        'missing': sum(1 for m in mapping_table if m['status'] == 'missing'),
        'skip': sum(1 for m in mapping_table if m['status'] == 'skip'),
        'pending': sum(1 for m in mapping_table if m['status'] == 'pending'),
        'image_pending': sum(1 for m in mapping_table if m['status'] == 'image_pending'),
        'match_rate': 0,
    }
    actionable = stats['total'] - stats['skip']
    if actionable > 0:
        stats['match_rate'] = f"{stats['matched'] / actionable * 100:.1f}%"

    return {
        'mapping_table': mapping_table,
        'statistics': stats,
        'missing_items': missing_items,
    }


def _match_field(field_name, data_index, phase1_index=None, derived_index=None):
    """
    尝试在多源数据索引中匹配指定字段名。

    优先级：
      1. 精确匹配（资料数据）
      2. 别名匹配（资料数据）
      3. Phase 1 解析数据
      4. 推断数据
    """
    phase1_index = phase1_index or {}
    derived_index = derived_index or {}

    # 1. 精确匹配（资料数据）
    if field_name in data_index:
        candidates = data_index[field_name]
        best = max(candidates, key=lambda x: 0 if x['confidence'] == 'high' else 1 if x['confidence'] == 'medium' else 2)
        return best

    # 2. 别名匹配（资料数据）
    aliases = FIELD_ALIAS_MAP.get(field_name, [])
    for alias in aliases:
        if alias in data_index:
            candidates = data_index[alias]
            best = max(candidates, key=lambda x: 0 if x['confidence'] == 'high' else 1)
            best['confidence'] = 'medium_alias'
            return best

    # 3. Phase 1 数据
    if field_name in phase1_index:
        return phase1_index[field_name]

    # Phase 1 别名匹配
    for alias in aliases:
        if alias in phase1_index:
            entry = dict(phase1_index[alias])
            entry['confidence'] = 'medium_alias_phase1'
            return entry

    # 4. 推断数据
    if field_name in derived_index:
        return derived_index[field_name]

    # 推断别名匹配
    for alias in aliases:
        if alias in derived_index:
            entry = dict(derived_index[alias])
            entry['confidence'] = 'medium_alias_inferred'
            return entry

    return None


# ============================================================
# 报告生成器
# ============================================================

def generate_mapping_report(match_result, template_info, material_info, output_path):
    """
    生成"资料来源对照报告"（Markdown格式，面向用户）。

    用户视角：告诉用户每个字段的数据从哪来、哪些需要自己动手。
    """
    lines = []
    project_name = os.path.basename(output_path).split('_')[0] if output_path else ''

    # ===== 标题区 =====
    lines.append(f'# 资料来源对照报告 — {project_name}')
    lines.append('')
    lines.append('> 本报告说明投标文件中每个填写项的数据来源。')
    lines.append('')

    stats = match_result['statistics']

    # ===== 总览 =====
    lines.append('## 数据来源总览')
    lines.append('')
    
    # 统计各来源
    source_counts = {}
    for m in match_result['mapping_table']:
        if m['status'] == 'matched':
            src = m.get('matched_source_type', '未知')
            source_counts[src] = source_counts.get(src, 0) + 1

    source_labels = {
        'phase1_report': '🏛️ 招标文件解析',
        'parse_report': '🏛️ 招标文件解析',
        'material_file': '📄 企业资料文件',
        'text_extraction': '📄 资料文件提取',
        'derived': '🧠 系统推断',
        'inferred': '🧠 系统推断',
        'business_rules': '⚙️ 配置默认值',
        'medium_alias': '📄 资料文件(别名匹配)',
        'high': '📄 资料文件(精确匹配)',
        'table_extraction': '📋 表格数据提取',
    }
    
    lines.append('| 来源 | 字段数 | 说明 |')
    lines.append('|------|--------|------|')
    for src, cnt in sorted(source_counts.items(), key=lambda x: -x[1]):
        label = source_labels.get(src, f'📎 {src}')
        lines.append(f'| {label} | {cnt} | |')
    
    lines.append('')
    lines.append(f'**总体情况**：{stats["total"]} 个填写项中，'
                 f'{stats["matched"]} 个已找到数据源（{stats["match_rate"]}），'
                 f'{stats["missing"]} 个需要您补充。')
    lines.append('')

    # ===== 第一部分：已自动匹配的字段 =====
    matched_items = [m for m in match_result['mapping_table'] if m['status'] == 'matched']
    if matched_items:
        lines.append('## 一、已找到数据的字段（自动填充）')
        lines.append('')
        lines.append('以下字段系统已找到对应数据，将在生成标书时自动填入：')
        lines.append('')
        lines.append('| 序号 | 填写项 | 数据来源 | 将填入的值 | 所在章节 |')
        lines.append('|------|--------|---------|-----------|---------|')

        for idx, m in enumerate(matched_items):
            field = m['template_field']
            value = m['matched_value']
            src_type = m.get('matched_source_type', '')
            src_label = source_labels.get(src_type, src_type)
            
            # 截断过长的值
            if len(value) > 35:
                value = value[:35] + '...'
            
            chapter_short = m['template_chapter']
            if len(chapter_short) > 20:
                chapter_short = chapter_short[:20] + '...'
            
            lines.append(f'| {idx+1} | **{field}** | {src_label} | `{value}` | {chapter_short} |')
        lines.append('')

    # ===== 第二部分：需要用户手动填写的字段 =====
    missing_items = [m for m in match_result['mapping_table'] if m['status'] == 'missing']
    if missing_items:
        lines.append('## 二、需要您手动填写的字段')
        lines.append('')
        lines.append('> ⚠ 以下字段在现有资料中未找到对应数据，请您在最终标书中补充：')
        lines.append('')

        # 按类别给建议
        manual_suggestions = {
            '联系电话': '请填写公司对外公布的联系电话（固定电话或手机）',
            '传真': '请填写公司传真号码（如无传真可留空或填写"无"）',
            '邮编': '请填写公司注册地址对应的邮政编码',
            '电子邮箱': '请填写公司用于接收招标通知的电子邮箱',
            '授权代表': '请指定前往现场投标的代表姓名（需携带身份证和授权委托书）',
            '单位性质': '如：有限责任公司、个人独资企业等（参见营业执照）',
            '经营期限': '如：长期、20年等（参见营业执照）',
        }

        lines.append('| 序号 | 需填写的内容 | 所在章节 | 操作建议 |')
        lines.append('|------|-------------|---------|---------|')
        for idx, m in enumerate(missing_items):
            field = m['template_field']
            chapter_short = m['template_chapter']
            if len(chapter_short) > 15:
                chapter_short = chapter_short[:15] + '...'
            
            suggestion = manual_suggestions.get(field, '请在投标文件中补充此信息')
            lines.append(f'| {idx+1} | **{field}** | {chapter_short} | {suggestion} |')
        lines.append('')

    # ===== 第三部分：签名/盖章位 =====
    skip_items = [m for m in match_result['mapping_table'] if m['status'] == 'skip']
    if skip_items:
        lines.append('## 三、签名 / 盖章位')
        lines.append('')
        lines.append('> 📝 以下位置需要在**打印后手写签名并加盖公章**：')
        lines.append('')
        lines.append('| 序号 | 签名位置 | 说明 |')
        lines.append('|------|---------|------|')
        sign_descs = {
            '签名或盖章': '法定代表人亲笔签名并加盖公章',
            '投标人名称(法定代表人句)': '此处为声明语句末尾的签名位',
        }
        for idx, m in enumerate(skip_items):
            field = m['template_field']
            desc = sign_descs.get(field, '请签名盖章')
            chapter_short = m['template_chapter']
            if len(chapter_short) > 20:
                chapter_short = chapter_short[:20] + '...'
            lines.append(f'| {idx+1} | **{field}** ({chapter_short}) | {desc} |')
        lines.append('')

    # ===== 第四部分：附件材料 =====
    img_items = [m for m in match_result['mapping_table'] if m['status'] == 'image_pending']
    if img_items:
        lines.append('## 四、需附的材料')
        lines.append('')
        lines.append('> 📎 以下位置需要附上相关证件复印件：')
        lines.append('')
        for idx, m in enumerate(img_items):
            field = m['template_field']
            hint = m.get('matched_value', '')
            # 清理原始提示文字，去掉技术关键词
            if '身份证' in hint:
                desc = '相关人员身份证复印件'
            elif '业绩' in hint or '项目' in hint:
                desc = '类似项目业绩证明材料'
            elif '资质' in hint or '证书' in hint:
                desc = '相关资质证书复印件'
            else:
                desc = '相关证件或证明材料复印件'
            chapter = m.get('template_chapter', '')
            if len(chapter) > 15:
                chapter = chapter[:15] + '...'
            lines.append(f'{idx+1}. **{field}**（{chapter}）：{desc}')
        lines.append('')

    # ===== 第五部分：待确认项 =====
    pending_items = [m for m in match_result['mapping_table'] if m['status'] == 'pending']
    if pending_items:
        lines.append('## 五、待确认项')
        lines.append('')
        lines.append('> ⏳ 以下字段需要您确认是否需要填写：')
        lines.append('')
        for idx, m in enumerate(pending_items):
            field = m['template_field']
            chapter = m['template_chapter']
            lines.append(f'- **{field}** （{chapter}）')
        lines.append('')

    # ===== 底部统计 =====
    lines.append('---')
    lines.append('')
    lines.append('## 统计汇总')
    lines.append('')
    lines.append(f'| 指标 | 数量 |')
    lines.append(f'|------|------|')
    lines.append(f'| ✅ 已找到数据 | {stats["matched"]} |')
    lines.append(f'| ⚠ 需您填写 | {stats["missing"]} |')
    lines.append(f'| 📝 签名/盖章 | {stats["skip"]} |')
    if stats.get('image_pending'):
        lines.append(f'| 📎 需要附件 | {stats["image_pending"]} |')
    if stats.get('pending'):
        lines.append(f'| ⏳ 待确认 | {stats["pending"]} |')
    lines.append(f'| **匹配率** | **{stats["match_rate"]}** |')
    lines.append('')

    lines.append('---')
    lines.append('')
    lines.append('*本报告由 bid-document-maker 自动生成*')

    # 写入文件
    report_content = '\n'.join(lines)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(report_content)

    return report_content


# ============================================================
# 入口
# ============================================================

def load_project_config(config_path):
    """加载项目配置文件"""
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    project_name = config.get('project_name', '未命名项目')
    work_dir = os.path.dirname(os.path.abspath(config_path))

    paths = config.get('paths', {})
    resolved_paths = {}
    for key, path_template in paths.items():
        resolved = path_template.replace('{project_name}', project_name)
        if not os.path.isabs(resolved):
            resolved = os.path.join(work_dir, resolved)
        resolved_paths[key] = resolved

    config['project_name'] = project_name
    config['work_dir'] = work_dir
    config['resolved_paths'] = resolved_paths
    return config


def main():
    parser = argparse.ArgumentParser(description='匹配引擎 — 生成资料来源对照报告')
    parser.add_argument('--project-name', required=True, help='项目名称（用于输出文件命名和自动查找输入）')
    parser.add_argument('--config', default='', help='项目配置文件路径（可选，用于 business_rules 等）')
    parser.add_argument('--template-data', default='', help='模板扫描数据JSON路径（默认: {项目名}_扫描数据.json）')
    parser.add_argument('--material-data', default='', help='资料扫描数据JSON路径（默认: {项目名}_资料深度扫描.json）')
    parser.add_argument('--parse-report', default='', help='Phase 1解析报告路径（可选）')
    parser.add_argument('--source-text', default='', help='招标文件全文文本路径（后备数据源）')
    parser.add_argument('--output-json', default='', help='输出映射数据JSON路径（默认: {项目名}_映射数据.json）')
    parser.add_argument('--report', default='', help='输出映射报告Markdown路径（默认: {项目名}_资料来源对照报告.md）')

    args = parser.parse_args()

    project_name = args.project_name
    work_dir = os.getcwd()

    _logger.info('=' * 60)
    _logger.info('  匹配引擎 v7.1 — 资料来源对照报告生成')
    _logger.info('=' * 60)

    # 可选：加载配置文件
    config = {}
    if args.config and os.path.exists(args.config):
        config = load_project_config(args.config)
        work_dir = config.get('work_dir', work_dir)
        _logger.info(f'  配置文件: {args.config}')

    # 确定路径（优先显式参数 > 自动按项目名查找）
    default_template = os.path.join(work_dir, f'{project_name}_扫描数据.json')
    default_material = os.path.join(work_dir, f'{project_name}_资料深度扫描.json')
    default_json = os.path.join(work_dir, f'{project_name}_映射数据.json')
    default_report = os.path.join(work_dir, f'{project_name}_资料来源对照报告.md')
    default_source_text = os.path.join(work_dir, '招标文件_全文文本.txt')

    template_path = args.template_data or default_template
    material_path = args.material_data or default_material
    parse_report_path = args.parse_report
    source_text_path = args.source_text or default_source_text
    json_output = args.output_json or default_json
    report_output = args.report or default_report

    _logger.info(f'  项目: {project_name}')
    _logger.info(f'  模板数据: {template_path}')
    _logger.info(f'  资料数据: {material_path}')
    if parse_report_path:
        _logger.info(f'  解析报告: {parse_report_path}')
    _logger.info(f'  输出JSON: {json_output}')
    _logger.info(f'  输出报告: {report_output}')
    print()

    # 加载模板扫描数据
    if not os.path.exists(template_path):
        _logger.error(f'  [ERROR] 模板扫描数据不存在: {template_path}')
        _logger.info(f'  请先运行: python template_scanner.py --project-name "{project_name}" --framework <框架路径>')
        sys.exit(1)

    with open(template_path, 'r', encoding='utf-8') as f:
        template_data = json.load(f)

    # 加载资料扫描数据
    if not os.path.exists(material_path):
        # 兼容旧文件名
        old_material_path = os.path.join(work_dir, f'{project_name}_资料数据.json')
        if os.path.exists(old_material_path):
            _logger.info(f'  [INFO] 使用旧格式资料数据: {old_material_path}')
            material_path = old_material_path
        else:
            _logger.error(f'  [ERROR] 资料扫描数据不存在: {material_path}')
            _logger.info(f'  请先运行: python material_deep_scanner.py --project-name "{project_name}" --materials-dir <资料路径>')
            sys.exit(1)

    with open(material_path, 'r', encoding='utf-8') as f:
        material_data = json.load(f)

    # 合并补充数据源：user_data_scanned.json
    user_data_path = os.path.join(work_dir, 'user_data_scanned.json')
    if os.path.exists(user_data_path):
        with open(user_data_path, 'r', encoding='utf-8') as f:
            user_data = json.load(f)
        existing_names = {dp['field_name'] for dp in material_data.get('data_points', [])}
        skip_keys = {'OCR原始文字', '业绩案例'}
        merged_count = 0
        for k, v in user_data.items():
            if k in skip_keys or k.startswith('_') or isinstance(v, list):
                continue
            if k in existing_names or k in {dp.get('field_name') for dp in material_data.get('data_points', [])}:
                continue
            if isinstance(v, str) and v.strip() and v != '（签字或盖章）':
                material_data.setdefault('data_points', []).append({
                    'field_name': k,
                    'value': v,
                    'source_file': 'user_data_scanned.json',
                    'source_type': 'ocr_scanned',
                    'confidence': 'high',
                })
                merged_count += 1
        if merged_count > 0:
            _logger.info(f'  ✓ 从 user_data_scanned.json 补充 {merged_count} 个字段')

    # 提取Phase 1数据
    _logger.info('  提取Phase 1解析报告数据...')
    phase1_data = extract_phase1_data(parse_report_path, source_text_path)
    if phase1_data:
        _logger.info(f'  ✓ 提取到 {len(phase1_data)} 个项目级数据点:')
        for k, v in phase1_data.items():
            _logger.info(f'    - {k} = {str(v)[:50]}')
    else:
        _logger.warning('  ⚠ 未提取到Phase 1数据（报告不存在或格式不符）')

    # 推断衍生数据
    _logger.info('  推断衍生数据...')
    derived_data = infer_derived_data(material_data, config)
    if derived_data:
        _logger.info(f'  ✓ 推断出 {len([k for k in derived_data if not k.startswith("_")])} 个衍生数据点:')
        for k, v in derived_data.items():
            if not k.startswith('_'):
                _logger.info(f'    - {k} = {v}')
    else:
        _logger.warning('  ⚠ 未能推断衍生数据')

    print()

    # 执行匹配
    _logger.info('  开始匹配...')
    match_result = match_template_with_materials(
        template_data, material_data,
        phase1_data=phase1_data,
        derived_data=derived_data)

    # 输出统计
    stats = match_result['statistics']
    _logger.info(f'  ✓ 匹配完成:')
    _logger.info(f'    - 总位置: {stats["total"]}')
    _logger.info(f'    - 已匹配: {stats["matched"]}')
    _logger.info(f'    - 缺失: {stats["missing"]}')
    _logger.info(f'    - 匹配率: {stats["match_rate"]}')

    # 保存JSON
    with open(json_output, 'w', encoding='utf-8') as f:
        json.dump(match_result, f, ensure_ascii=False, indent=2)
    _logger.info(f'  ✓ JSON数据已写入: {json_output}')

    # 生成报告
    generate_mapping_report(
        match_result,
        template_data.get('template_info', {}),
        material_data.get('scan_info', {}),
        report_output)
    _logger.info(f'  ✓ 报告已写入: {report_output}')

    print()
    _logger.info('=' * 60)
    _logger.info('  匹配引擎完成！')
    _logger.info(f'  映射数据: {json_output}')
    _logger.info(f'  对照报告: {report_output}')
    _logger.info('=' * 60)


if __name__ == '__main__':
    main()
