#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
标⭐️项（关键参数 / 废标条款）检查工具 (v1.0)
==========================================

招标文件中常以 ★ / ⭐ / ☆ 等符号标注「标星项」，或在评分办法中规定
「带★指标的加分 / 减分 / 不满足即废标」政策。这类条目一旦不满足，后果通常是
**废标** 或 **该模块零分**，严重程度远高于一般格式 / 文字问题，因此单独成章、
详细核查，且**绝不静默跳过**。

本脚本做两件事（确定性、可复现，不依赖外部 LLM）：
  ① 从【招标文件】抽取所有标星项（参数 / 废标条款 / 评分加分-减分政策）；
  ② 在【投标文件】中检索每一项标星的响应情况（满足 / 不满足 / 需复核），
     给出证据片段与低置信度标记，交由模型在 Stage 2.5 的【LLM 逐条复核】
     中最终判定（机器无法可靠判断"技术规格是否满足"，必须人工/模型确认）。

若招标文件不含任何标星符号或星号条款，输出 has_star_items=false，
报告章节显示「无标星项」，**不视为错误**（仅说明无此项风险）。

输入：
  --tender   招标文件全文（.docx / .txt / .doc 均可）
  --bid      投标文件全文（可选；缺省则只列标星项、响应一律标"需复核"）
  --output   输出 JSON 路径（默认 {tender名}_标星项检查Plan.json）
  --chapter-index  可选，用于把行号映射到章节名（暂仅透传，不影响判定）

输出 JSON 结构：
  {
    "check_id", "check_time", "has_star_items",
    "tender_source", "bid_source",
    "summary": {
        "star_parameter_count", "star_clause_count", "star_policy_count",
        "response_met", "response_not_met", "response_needs_review",
        "critical_risk": "none|low|medium|high"
    },
    "star_items": [
      {"id","type","text","location","policy"(policy 型),
       "bid_response":{"found","status","evidence","confidence"},
       "severity","llm_review_needed"}
    ],
    "llm_review_needed": true
  }
"""

import os
import re
import sys
import json
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime

try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.check_star_items")
except Exception:
    import logging
    _logger = logging.getLogger("check_star_items")
    if not _logger.handlers:
        _h = logging.StreamHandler(sys.stderr)
        _h.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_h)
        _logger.setLevel(logging.INFO)


# ===================== 标星符号与判定规则 =====================

# 常见"星"符号（含 emoji ⭐ U+1F31F 及其变体选择符 U+FE0F）
STAR_SYMBOLS = set("★☆⭐✩✪✦✧✬✭")
_STAR_RE = re.compile("[" + re.escape("".join(STAR_SYMBOLS)) + "]")

# 仅含星号、但属于"说明性"而非"条目"的噪声行过滤
_META_HINT_RE = re.compile(r"^(注|说明|注：|备注|注:|以下|如上|详见|见附件|注\s*：)")

# 评分办法区段锚点（命中即认为进入"评分政策区"）
_SCORING_ANCHORS = ["评分办法", "评分标准", "评审办法", "评分细则", "评分方法", "评审标准"]

# 评分政策动作词
_BONUS_RE = re.compile(r"(加分|加\s*\d+\s*分|得\s*\d+\s*分|每有.{0,12}项|每项.{0,12}分|满足.{0,8}加)")
_PENALTY_RE = re.compile(r"(扣分|减分|不满足.{0,16}(分|扣分)|未响应.{0,12}分)")
_DISQUALIFY_RE = re.compile(r"(废标|否决|无效标|按无效应|不满足.*?(废标|投标无效|不予)())")
_POINTS_RE = re.compile(r"(\d+(?:\.\d+)?)\s*分")

# 废标 / 实质性条款
_CLAUSE_RE = re.compile(r"(废标|否决|投标无效|无效标|实质性要求|实质性响应|不满足.*?(处理|判定|视为))")

# 投标响应肯定/否定线索
_AFFIRM_RE = re.compile(r"(满足|符合|响应|承诺|提供|支持|优于|等于|不低于|具备|完全响应|严格响应|遵照)")
_NEGATE_RE = re.compile(r"(不满足|未满足|未提供|不响应|不符合|不具备|缺失|缺|没有|无此|未响应)")


# ===================== 文本读取 =====================

def read_text(input_path: str) -> str:
    """读取 .docx / .txt / .doc 为纯文本。"""
    low = input_path.lower()
    if low.endswith('.txt'):
        with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    if low.endswith('.docx'):
        try:
            from docx import Document
            doc = Document(input_path)
            return '\n'.join(p.text for p in doc.paragraphs)
        except Exception as e:
            _logger.warning(f"  python-docx 读取失败: {e}")
    if low.endswith('.doc'):
        try:
            from bid_checker.utils.doc_to_docx import _extract_doc_text_olefile
            txt = _extract_doc_text_olefile(input_path)
            if txt:
                return txt
        except Exception as e:
            _logger.warning(f"  olefile 提取失败: {e}")
    raise RuntimeError(f"无法读取输入文件: {input_path}")


# ===================== 标星项抽取 =====================

def _is_star_line(line: str) -> bool:
    """该行是否含星号符号或星号条款关键词。"""
    if _STAR_RE.search(line):
        return True
    if re.search(r"星号|标星|带星|星项|星条款|星指标|关键指标|关键参数", line):
        return True
    return False


def _find_scoring_zone(tender: str) -> Optional[int]:
    """返回评分办法区段的起始字符偏移；未找到返回 None。"""
    best = None
    for anchor in _SCORING_ANCHORS:
        i = tender.find(anchor)
        if i >= 0 and (best is None or i < best):
            best = i
    return best


def _classify(line: str, pos: int, scoring_start: Optional[int]) -> str:
    """判定标星项类型：policy / clause / parameter。"""
    in_scoring = scoring_start is not None and pos >= scoring_start
    if in_scoring and (_BONUS_RE.search(line) or _PENALTY_RE.search(line)):
        return "policy"
    if _DISQUALIFY_RE.search(line) or _CLAUSE_RE.search(line):
        return "clause"
    return "parameter"


def _extract_policy(line: str) -> Dict[str, Any]:
    """从政策行抽取 action / points / detail。"""
    detail = line.strip()
    action = "bonus"  # 默认加分
    if _DISQUALIFY_RE.search(line):
        action = "disqualify"
    elif _PENALTY_RE.search(line):
        action = "penalty"
    points = None
    m = _POINTS_RE.search(line)
    if m:
        try:
            points = float(m.group(1))
        except ValueError:
            points = None
    return {"action": action, "points": points, "detail": detail}


def _extract_star_items(tender: str) -> List[Dict[str, Any]]:
    """逐行扫描招标文件，抽取标星项候选。"""
    scoring_start = _find_scoring_zone(tender)
    items: List[Dict[str, Any]] = []
    lines = tender.split('\n')
    offset = 0
    for raw in lines:
        line = raw.strip()
        if not line:
            offset += len(raw) + 1
            continue
        if not _is_star_line(line):
            offset += len(raw) + 1
            continue
        # 过滤纯说明行（"注：带★项为关键参数"这类，无实质条目内容）
        if _META_HINT_RE.match(line) and not re.search(r"参数|指标|规格|要求|条款|配置|性能|功能|加分|扣分|减分", line):
            offset += len(raw) + 1
            continue
        # 过短且无具体条目特征的也跳过（如单独一个"★"）
        if len(line) < 4:
            offset += len(raw) + 1
            continue

        itype = _classify(line, offset, scoring_start)
        item: Dict[str, Any] = {
            "type": itype,
            "text": line,
            "location": f"字符位 {offset}",
        }
        if itype == "policy":
            item["policy"] = _extract_policy(line)
        items.append(item)
        offset += len(raw) + 1
    return items


# ===================== 投标响应判定（启发式 + LLM 复核） =====================

def _search_query(line: str) -> str:
    """从标星行提取用于在投标文中检索的核心片段。

    优先取「最后一个星号之后的要求文本」（星号通常紧贴要求，如
    "显示系统亮度：★ 亮度不低于500cd/㎡" → 取 "亮度不低于500cd/㎡"），
    该部分最可能在投标响应中复现。若无星号，则去掉行首序号后取全文。
    """
    m = None
    for mm in _STAR_RE.finditer(line):
        m = mm
    if m and (len(line) - m.end()) >= 3:
        q = line[m.end():]
    else:
        q = re.sub(r"^\d+[\.、]\s*", "", line)
    # 去掉残留星号与其他干扰符号；保留 / ㎡ 等规格符号（投标文中同样存在）
    q = re.sub(r"[★☆⭐✩✪✦✧✬✭*#◆●▲■]", "", q)
    q = re.sub(r"[\s，。；：、（）\[\]【】\"'\"'‘’“”]", "", q)
    # 若仍有标签前缀残留（冒号），再切一刀
    if "：" in q:
        q = q.split("：", 1)[1]
    return q[:24].strip()


def _assess_response(item: Dict[str, Any], bid: str) -> Dict[str, Any]:
    """在投标文中检索标星项的响应情况。

    - parameter（参数项）：检索投标是否响应，给 满足/不满足/需复核。
    - policy（评分政策）/ clause（废标条款）：非"逐条响应"条目，
      直接标需复核并附提示，交由 LLM 复核确认政策已在得分/合规中落实。
    """
    itype = item.get("type")
    if itype in ("policy", "clause"):
        note = ("评分政策条目（加分/减分/废标），请在 LLM 复核中确认该政策"
                 "已纳入得分预估或合规判定" if itype == "policy"
                 else "废标/实质性条款，请在 LLM 复核中确认投标文件未触发此条款")
        return {"found": False, "status": "needs_review",
                "evidence": note, "confidence": "low"}

    if not bid:
        return {"found": False, "status": "needs_review",
                "evidence": "未提供投标文件，无法检索响应", "confidence": "low"}

    line = item["text"]
    # 渐进式检索：先长后短
    candidates = []
    core = _search_query(line)
    for length in (min(24, len(core)), 16, 10, 6, 4):
        sub = core[:length]
        if len(sub) >= 4 and sub in bid:
            candidates.append(sub)
    if not candidates:
        return {"found": False, "status": "needs_review",
                "evidence": "未在投标文中检索到该标星项的具体响应描述", "confidence": "low"}

    query = max(candidates, key=len)
    pos = bid.find(query)
    # 仅取「该要求所在句子」做判定，避免被同段落其他条目的否定词污染
    s_start = bid.rfind('。', 0, pos)
    s_start = s_start + 1 if s_start >= 0 else 0
    s_end = bid.find('。', pos)
    s_end = s_end + 1 if s_end >= 0 else len(bid)
    sent = bid[s_start:s_end]
    if _NEGATE_RE.search(sent):
        status = "not_met"
    elif _AFFIRM_RE.search(sent):
        status = "met"
    else:
        status = "needs_review"
    return {"found": True, "status": status,
            "evidence": sent.replace('\n', ' ').strip()[:160], "confidence": "low"}


def _risk_level(items: List[Dict[str, Any]]) -> str:
    if not items:
        return "none"
    has_not_met = any(it.get("bid_response", {}).get("status") == "not_met" for it in items)
    has_clause = any(it["type"] == "clause" for it in items)
    has_needs = any(it.get("bid_response", {}).get("status") == "needs_review" for it in items)
    if (has_not_met) or (has_clause and has_needs):
        return "high"
    if has_not_met:
        return "high"
    if has_needs:
        return "medium"
    return "low"


# ===================== 主流程 =====================

def run_checks(tender: str, bid: Optional[str] = None) -> Dict[str, Any]:
    raw_items = _extract_star_items(tender)
    has_star = len(raw_items) > 0

    star_items: List[Dict[str, Any]] = []
    for i, it in enumerate(raw_items, 1):
        resp = _assess_response(it, bid)
        star_items.append({
            "id": f"S-{i:03d}",
            "type": it["type"],
            "text": it["text"],
            "location": it["location"],
            "policy": it.get("policy"),
            "bid_response": resp,
            "severity": "critical",  # 标星项均为最高风险
            "llm_review_needed": True,
        })

    summary = {
        "star_parameter_count": sum(1 for x in star_items if x["type"] == "parameter"),
        "star_clause_count": sum(1 for x in star_items if x["type"] == "clause"),
        "star_policy_count": sum(1 for x in star_items if x["type"] == "policy"),
        "response_met": sum(1 for x in star_items if x["bid_response"]["status"] == "met"),
        "response_not_met": sum(1 for x in star_items if x["bid_response"]["status"] == "not_met"),
        "response_needs_review": sum(1 for x in star_items if x["bid_response"]["status"] == "needs_review"),
        "critical_risk": _risk_level(star_items),
    }

    note = ""
    if not has_star:
        note = ("招标文件未标注任何⭐️（星号）项，亦无星号条款 / 评分加分-减分政策。"
                 "本项目无标星项专项风险，本报告跳过详细核查。"
                 "（若招标文件使用其他非标准标记表示关键/废标条款，请人工确认。）")

    return {
        "check_id": f"star_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "check_time": datetime.now().isoformat(),
        "has_star_items": has_star,
        "summary": summary,
        "star_items": star_items,
        "note": note,
        "llm_review_needed": True,  # 机器判定不可靠，必须模型逐条复核
    }


def main():
    parser = argparse.ArgumentParser(description="标⭐️项（关键参数/废标条款）检查 (v1.0)")
    parser.add_argument('--tender', required=True, help='招标文件全文 .docx/.txt/.doc')
    parser.add_argument('--bid', help='投标文件全文 .docx/.txt/.doc（可选）')
    parser.add_argument('--output', help='输出 JSON（默认 {tender}_标星项检查Plan.json）')
    args = parser.parse_args()

    out_path = args.output or (os.path.splitext(args.tender)[0] + "_标星项检查Plan.json")
    _logger.info(f"读取招标文件: {args.tender}")
    tender = read_text(args.tender)
    _logger.info(f"招标文件长度: {len(tender)} 字")

    bid = None
    if args.bid:
        _logger.info(f"读取投标文件: {args.bid}")
        bid = read_text(args.bid)
        _logger.info(f"投标文件长度: {len(bid)} 字")

    result = run_checks(tender, bid)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or '.', exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    s = result["summary"]
    if result["has_star_items"]:
        _logger.info(f"✓ 标⭐️项检查完成：共 {len(result['star_items'])} 项")
        _logger.info(f"   参数项: {s['star_parameter_count']}  废标/实质条款: {s['star_clause_count']}  评分政策: {s['star_policy_count']}")
        _logger.info(f"   投标响应 → 满足: {s['response_met']}  不满足: {s['response_not_met']}  需复核: {s['response_needs_review']}")
        _logger.info(f"   关键风险等级: {s['critical_risk']}")
    else:
        _logger.info("✓ 标⭐️项检查完成：本项目【无标星项】")
    _logger.info(f"   输出: {out_path}")
    _logger.info("⚠ 机器仅做抽取与初判，须模型在 Stage 2.5 对每条逐条复核（尤其技术规格是否满足）。")
    return 0


if __name__ == '__main__':
    sys.exit(main())
