#!/usr/bin/env python3
"""
Stage 1.3: 提取格式要求清单
从 parse_bid_document.py 解析的 JSON 数据中，进一步提取格式合规要求清单。

输入：{项目名}_招标解析数据.json
输出：{项目名}_招标要求清单.json

复用：requirement_mapper.CHAPTER_KEYWORD_MAP + FIXED_CHAPTER_PATTERNS
"""
import argparse
import json
import re
import sys
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional

# 把 bid_checker 包加入 path
SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger

_logger = get_logger('extract_format_requirements')

# 必需章节关键词（来自招标文件常见结构）
REQUIRED_CHAPTER_KEYWORDS = {
    '投标函': ['投标函', '投标书'],
    '投标一览表': ['投标一览表', '开标一览表', '报价一览表'],
    '法定代表人身份证明': ['法定代表人身份证明', '法人身份证明'],
    '授权委托书': ['授权委托书', '法定代表人授权书'],
    '投标保证金': ['投标保证金', '保证金交纳'],
    '资格证明文件': ['资格证明', '资格审查', '资质文件'],
    '商务部分': ['商务部分', '商务标', '商务文件'],
    '技术部分': ['技术部分', '技术标', '技术方案', '技术文件'],
    '施工组织设计': ['施工组织设计', '组织设计'],
    '售后服务': ['售后服务', '服务方案'],
    '偏离表': ['偏离表', '偏离情况'],
}

# 必填字段（跨章节必须一致）
REQUIRED_FIELDS = [
    {'label': '项目名称', 'appears_in': ['封面', '投标函', '投标一览表']},
    {'label': '项目编号', 'appears_in': ['封面', '投标函', '投标一览表']},
    {'label': '投标人名称', 'appears_in': ['封面', '投标函', '投标一览表', '资格审查']},
    {'label': '法定代表人', 'appears_in': ['法定代表人身份证明', '授权委托书']},
    {'label': '投标金额', 'appears_in': ['投标函', '投标一览表', '报价表']},
    {'label': '投标日期', 'appears_in': ['投标函', '投标一览表']},
]

# 签字盖章规则
SIGNATURE_RULES = [
    {'context': '投标函', 'type': '法人签字+公章', 'must_be_empty': True},
    {'context': '投标一览表', 'type': '法人签字+公章', 'must_be_empty': True},
    {'context': '授权委托书', 'type': '法人签字+公章', 'must_be_empty': True},
    {'context': '资格审查', 'type': '公章', 'must_be_empty': True},
]

# 格式规则（字体字号等，通用默认）
DEFAULT_FORMAT_RULES = [
    {'rule_id': 'fmt001', 'type': 'font', 'description': '正文宋体小四', 'scope': '正文'},
    {'rule_id': 'fmt002', 'type': 'font', 'description': '标题黑体三号', 'scope': '标题'},
    {'rule_id': 'fmt003', 'type': 'page_break', 'description': '每章必须另起一页', 'scope': '章节'},
    {'rule_id': 'fmt004', 'type': 'page_number', 'description': '页码连续，从封面开始', 'scope': '全文'},
]


@dataclass
class ChapterRequirement:
    chapter_id: str
    title: str
    required: bool
    must_be_present: bool
    must_page_break_before: bool
    evidence_keywords: List[str]
    source: str  # 'extracted' / 'inferred'


@dataclass
class RequiredField:
    field_id: str
    label: str
    appears_in: List[str]
    must_be_consistent: bool = True


@dataclass
class SignatureRule:
    rule_id: str
    context: str
    type: str
    must_be_empty: bool
    warning_if_filled: bool = False


@dataclass
class FormatRule:
    rule_id: str
    type: str
    description: str
    scope: str


@dataclass
class ProjectInfo:
    项目名称: str = ''
    项目编号: str = ''
    采购人: str = ''
    采购方式: str = ''
    预算金额: str = ''
    开标时间: str = ''


@dataclass
class RequirementList:
    project_info: ProjectInfo
    chapter_requirements: List[ChapterRequirement]
    required_fields: List[RequiredField]
    signature_rules: List[SignatureRule]
    format_rules: List[FormatRule]
    extraction_confidence: str = 'medium'  # high/medium/low
    low_confidence_items: List[str] = field(default_factory=list)


def extract_project_info(parse_data: Dict) -> ProjectInfo:
    """从解析数据中提取项目基本信息"""
    basic_info = parse_data.get('basic_info', {})
    return ProjectInfo(
        项目名称=basic_info.get('项目名称', {}).get('value', '') or '未识别',
        项目编号=basic_info.get('项目编号', {}).get('value', '') or '未识别',
        采购人=basic_info.get('采购人', {}).get('value', '') or '未识别',
        采购方式=basic_info.get('采购方式', {}).get('value', '') or '未识别',
        预算金额=basic_info.get('预算金额', {}).get('value', '') or
                basic_info.get('预算', {}).get('value', '') or '未识别',
        开标时间=basic_info.get('开标时间', {}).get('value', '') or
                basic_info.get('投标截止', {}).get('value', '') or '未识别',
    )


def extract_chapter_requirements(parse_data: Dict) -> List[ChapterRequirement]:
    """从解析数据中提取章节要求"""
    chapter_map = parse_data.get('chapter_map', [])
    chapter_texts = parse_data.get('chapter_texts', {})

    # chapter_map 可能是 list（v3.0 格式）或 dict（旧格式）
    identified = []
    if isinstance(chapter_map, list):
        for ch_info in chapter_map:
            if isinstance(ch_info, dict):
                title = ch_info.get('title', '')
            else:
                title = str(ch_info)
            if not title:
                continue
            keywords = [title]
            for req_name, req_keywords in REQUIRED_CHAPTER_KEYWORDS.items():
                if any(kw in title for kw in req_keywords):
                    keywords = req_keywords
                    break

            identified.append(ChapterRequirement(
                chapter_id=f'ch_{len(identified)+1:03d}',
                title=title,
                required=True,
                must_be_present=True,
                must_page_break_before=True,
                evidence_keywords=keywords,
                source='extracted',
            ))
    elif isinstance(chapter_map, dict):
        for ch_key, ch_info in chapter_map.items():
            title = ch_info.get('title', '') if isinstance(ch_info, dict) else str(ch_info)
            if not title:
                continue
            keywords = [title]
            for req_name, req_keywords in REQUIRED_CHAPTER_KEYWORDS.items():
                if any(kw in title for kw in req_keywords):
                    keywords = req_keywords
                    break

            identified.append(ChapterRequirement(
                chapter_id=f'ch_{len(identified)+1:03d}',
                title=title,
                required=True,
                must_be_present=True,
                must_page_break_before=True,
                evidence_keywords=keywords,
                source='extracted',
            ))

    # 推断应当存在但未识别到的章节
    identified_titles = ' '.join([ch.title for ch in identified])
    for req_name, req_keywords in REQUIRED_CHAPTER_KEYWORDS.items():
        if not any(kw in identified_titles for kw in req_keywords):
            identified.append(ChapterRequirement(
                chapter_id=f'ch_{len(identified)+1:03d}',
                title=req_name,
                required=False,
                must_be_present=True,
                must_page_break_before=True,
                evidence_keywords=req_keywords,
                source='inferred',
            ))

    return identified


def extract_required_fields(parse_data: Dict) -> List[RequiredField]:
    """提取必填字段清单"""
    fields = []
    for i, f in enumerate(REQUIRED_FIELDS):
        fields.append(RequiredField(
            field_id=f'f{i+1:03d}',
            label=f['label'],
            appears_in=f['appears_in'],
            must_be_consistent=True,
        ))
    return fields


def extract_signature_rules(parse_data: Dict) -> List[SignatureRule]:
    """提取签字盖章规则"""
    rules = []
    for i, r in enumerate(SIGNATURE_RULES):
        rules.append(SignatureRule(
            rule_id=f's{i+1:03d}',
            context=r['context'],
            type=r['type'],
            must_be_empty=r['must_be_empty'],
            warning_if_filled=False,
        ))
    return rules


def extract_format_rules(parse_data: Dict) -> List[FormatRule]:
    """提取格式规则（字体字号等）"""
    # 尝试从招标文件中识别明确的格式要求（如"宋体小四"等）
    chapter_texts = parse_data.get('chapter_texts', {})
    full_text = ' '.join(chapter_texts.values()) if isinstance(chapter_texts, dict) else ''

    rules = []
    # 默认规则
    for r in DEFAULT_FORMAT_RULES:
        rules.append(FormatRule(**r))

    # 尝试识别明确指定的字体字号
    font_patterns = [
        (r'宋体[\s]*小[一二三四五六号]', '宋体小一/二/三/四/五/六号'),
        (r'黑体[\s]*[一二三四五六号]', '黑体一/二/三/四/五/六号'),
        (r'仿宋[\s]*GB2312', '仿宋GB2312'),
    ]
    for pattern, desc in font_patterns:
        if re.search(pattern, full_text):
            rules.append(FormatRule(
                rule_id=f'fmt{len(rules)+1:03d}',
                type='font_explicit',
                description=f'招标文件明确指定：{desc}',
                scope='正文',
            ))

    return rules


def assess_confidence(req_list: RequirementList, parse_data: Dict):
    """评估抽取置信度"""
    low_items = []
    # 项目信息缺失
    for field_name in ['项目名称', '项目编号', '采购人']:
        value = getattr(req_list.project_info, field_name)
        if not value or value == '未识别':
            low_items.append(f'项目信息缺：{field_name}')

    # 推断章节过多
    inferred_count = sum(1 for ch in req_list.chapter_requirements if ch.source == 'inferred')
    if inferred_count > 5:
        low_items.append(f'推断章节数 {inferred_count} 较多，建议人工核对')

    req_list.low_confidence_items = low_items
    if not low_items:
        req_list.extraction_confidence = 'high'
    elif len(low_items) <= 2:
        req_list.extraction_confidence = 'medium'
    else:
        req_list.extraction_confidence = 'low'


def main():
    parser = argparse.ArgumentParser(description='Stage 1.3: 提取格式要求清单')
    parser.add_argument('--input', required=True, help='解析数据 JSON 路径')
    parser.add_argument('--output', required=True, help='输出要求清单 JSON 路径')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    if args.verbose:
        import logging
        logging.getLogger('extract_format_requirements').setLevel(logging.DEBUG)

    _logger.info(f'读取解析数据：{args.input}')
    with open(args.input, 'r', encoding='utf-8') as f:
        parse_data = json.load(f)

    # 提取各类要求
    project_info = extract_project_info(parse_data)
    chapter_reqs = extract_chapter_requirements(parse_data)
    required_fields = extract_required_fields(parse_data)
    signature_rules = extract_signature_rules(parse_data)
    format_rules = extract_format_rules(parse_data)

    req_list = RequirementList(
        project_info=project_info,
        chapter_requirements=chapter_reqs,
        required_fields=required_fields,
        signature_rules=signature_rules,
        format_rules=format_rules,
    )
    assess_confidence(req_list, parse_data)

    # 序列化（dataclass → dict）
    output = {
        'project_info': asdict(req_list.project_info),
        'chapter_requirements': [asdict(ch) for ch in req_list.chapter_requirements],
        'required_fields': [asdict(f) for f in req_list.required_fields],
        'signature_rules': [asdict(r) for r in req_list.signature_rules],
        'format_rules': [asdict(r) for r in req_list.format_rules],
        'extraction_confidence': req_list.extraction_confidence,
        'low_confidence_items': req_list.low_confidence_items,
    }

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  章节要求数：{len(chapter_reqs)}（其中推断 {sum(1 for ch in chapter_reqs if ch.source == "inferred")} 个）')
    _logger.info(f'  必填字段数：{len(required_fields)}')
    _logger.info(f'  签字盖章规则数：{len(signature_rules)}')
    _logger.info(f'  格式规则数：{len(format_rules)}')
    _logger.info(f'  抽取置信度：{req_list.extraction_confidence}')
    if req_list.low_confidence_items:
        _logger.warning(f'  低置信项：{req_list.low_confidence_items}')


if __name__ == '__main__':
    main()
