#!/usr/bin/env python3
"""
Stage 5.5.2: 技术方案抄袭检测

5 个维度：
  ① 残留他人信息检测（critical）
  ② 跨章节自重复检测（major）
  ③ 与公开资料相似度检测（major，调用 web-search）
  ④ AI 痕迹检测（minor，宽松阈值）
  ⑤ 引用未署名检测（info）

输入：
  --docx: 标书 .docx 路径
  --chapter-index: 章节索引 JSON
  --requirements: 招标要求清单 JSON
  --output: 输出抄袭检测 Plan JSON

输出：{项目名}_抄袭检测Plan.json
"""
import argparse
import json
import re
import sys
import subprocess
import time
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any, Optional, Set, Tuple
from datetime import datetime
from collections import Counter

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger
from bid_checker.core.text_similarity import (
    Paragraph, split_into_paragraphs, generate_ngrams,
    jaccard_similarity, find_similar_paragraph_pairs, find_most_similar_external,
    extract_key_sentence
)
from docx import Document

_logger = get_logger('check_plagiarism')


@dataclass
class PlagiarismIssue:
    issue_id: str
    dimension: str  # residual_info / self_duplicate / external_similar / ai_trace / citation
    severity: str
    description: str
    evidence: str
    location: str
    suggestion: str
    similarity: Optional[float] = None          # 维度②/③ 相似度（0-1）
    content_summary: Optional[str] = None        # 维度②/③ 重复内容摘要（≤60字）
    position_a: Optional[str] = None             # 维度②：第一次出现位置（章节/页/行）
    position_b: Optional[str] = None             # 维度②：第二次出现位置；维度③：公开来源 URL/标题


@dataclass
class PlagiarismPlan:
    check_id: str
    check_time: str
    total_paragraphs: int
    issues: List[PlagiarismIssue]
    summary_by_dimension: Dict[str, int]
    external_search_status: str = 'unknown'  # searched / skipped_no_tool / disabled_by_flag
    external_search_note: str = ''           # 维度③ 状态说明（禁止伪装"无抄袭"）


def web_search_available() -> bool:
    """检测 z-ai web-search CLI 是否可用（用于维度③ 状态判定）"""
    try:
        import shutil
        return shutil.which('z-ai') is not None
    except Exception:
        return False


def load_external_fallback(path: str) -> List[PlagiarismIssue]:
    """加载 agent 用自带 WebSearch 兜底检索得到的结果（维度③ 不可静默跳过）。

    输入 JSON 格式：[{"text": 标书段落, "location": 章节/页/行,
                       "url": 公开来源URL, "title": 来源标题,
                       "similarity": 0.x, "snippet": 公开摘要}]
    """
    issues = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        _logger.warning(f'  加载维度③兜底结果失败：{e}')
        return issues
    for i, item in enumerate(data):
        sim = float(item.get('similarity', 0.0))
        if sim < 0.7:
            continue
        risk = 'critical' if sim >= 0.95 else ('major' if sim >= 0.8 else 'minor')
        issues.append(PlagiarismIssue(
            issue_id=f'plag_fb_{i+1:03d}',
            dimension='external_similar',
            severity=risk,
            description=f'与公开资料高度相似（相似度 {sim:.0%}）[WebSearch 兜底]',
            evidence=f'标书段落："{str(item.get("text",""))[:100]}..."\n公开资料：{str(item.get("snippet","(无摘要)"))[:100]}',
            location=f'{item.get("location","")} vs {item.get("title","") or item.get("url","")}',
            suggestion='改写为原创表述，或注明引用来源',
            similarity=sim,
            content_summary=str(item.get('text', ''))[:60],
            position_a=item.get('location', ''),
            position_b=item.get('title', '') or item.get('url', ''),
        ))
    _logger.info(f'  维度③ WebSearch 兜底载入 {len(issues)} 处相似')
    return issues


# ============= 维度①：残留他人信息检测 =============

# 常见其他公司名后缀（用于检测"不应该出现的公司名"）
COMPANY_SUFFIXES = ['科技有限公司', '股份有限公司', '有限责任公司', '有限公司', '集团', '公司']

# 残留信息关键词模式
RESIDUAL_INFO_PATTERNS = {
    'other_project_name': [
        r'(\w{2,15}(?:局|委|办|中心|院|校|公司))\s*(?:信息化|数字化|智能化|建设|改造|升级)?项目',
    ],
    'other_date': [
        r'(20[12]\d)\s*年\s*\d{1,2}\s*月\s*(?:实施|完成|启动|建设|交付)',
        r'截至\s*(20[12]\d)\s*年',
    ],
    'other_location': [
        r'(北京|上海|广州|深圳|杭州|南京|成都|武汉|西安|重庆|天津)\s*(?:分公司|分部|办事处|项目部)',
    ],
}

# 套话词库（AI 痕迹检测用）
AI_CLICHE_PHRASES = [
    '在信息化快速发展的今天',
    '在数字化转型的浪潮中',
    '随着信息技术的不断进步',
    '在当今信息化时代',
    '随着互联网的快速发展',
    '本方案秉承',
    '致力于',
    '全面提升',
    '为...提供有力保障',
    '我们将秉承...理念',
    '始终坚持以...为导向',
    '以...为核心',
    '助力企业实现',
    '赋能业务发展',
    '构建...生态',
    '打造...平台',
    '推动...转型升级',
    '实现...目标',
    '确保...万无一失',
    '坚持...原则',
]

# 过渡词（用于检测重复使用）
AI_TRANSITION_WORDS = [
    '首先', '其次', '再次', '最后',
    '一方面', '另一方面',
    '此外', '另外', '同时', '与此同时',
    '因此', '所以', '于是',
    '总之', '综上', '总体而言',
    '需要注意的是',
    '值得一提的是',
    '众所周知',
]


def check_residual_info(doc, requirements: Dict) -> List[PlagiarismIssue]:
    """维度①：残留他人信息检测"""
    _logger.info('  [抄袭检测1] 残留他人信息检测...')
    issues = []
    
    # 收集全文
    all_text = '\n'.join(p.text or '' for p in doc.paragraphs)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                all_text += '\n' + (cell.text or '')
    
    # 1. 项目名一致性
    project_info = requirements.get('project_info', {}) if requirements else {}
    expected_project = project_info.get('项目名称', '')
    expected_buyer = project_info.get('采购人', '')
    
    # 提取所有"XX局/委/办 + 项目" 模式
    other_projects = set()
    for pattern in RESIDUAL_INFO_PATTERNS['other_project_name']:
        for match in re.finditer(pattern, all_text):
            found = match.group(0)
            # 检查是否与采购人/项目名匹配
            if expected_buyer and expected_buyer in found:
                continue
            if expected_project and expected_project in found:
                continue
            other_projects.add(found)
    
    for proj in list(other_projects)[:5]:  # 最多报告 5 个
        issues.append(PlagiarismIssue(
            issue_id=f'plag_{len(issues)+1:03d}',
            dimension='residual_info',
            severity='critical',
            description=f'疑似残留其他项目名：{proj}',
            evidence=f'标书中出现"{proj}"，但本项目采购人是"{expected_buyer}"',
            location='全文',
            suggestion=f'检查是否为复制其他标书未替换干净，删除或改为本项目相关表述',
        ))
    
    # 2. 公司名一致性
    # 提取所有"XX有限公司/集团"模式
    bidder_name = ''  # 投标人名称
    name_pattern = re.compile(r'(?:投标人名称|投标人|单位名称)\s*[：:]\s*([^\s，,。；;]+)')
    name_matches = name_pattern.findall(all_text)
    if name_matches:
        bidder_name = name_matches[0]
    
    # 找其他公司名
    # 预处理：把"YY 科技有限公司"这种带空格的合并为"YY科技有限公司"
    # 因为标书里有时会有空格分隔
    normalized_text = re.sub(
        r'([A-Za-z0-9]+)\s+([\u4e00-\u9fa5]*?(?:' + '|'.join(COMPANY_SUFFIXES) + r'))',
        r'\1\2', all_text
    )
    
    # 正则：公司名前缀可以包含中文+英文+数字
    company_pattern = re.compile(r'([\u4e00-\u9fa5A-Za-z0-9]{2,15}(?:' + '|'.join(COMPANY_SUFFIXES) + r'))')
    all_companies = set(company_pattern.findall(normalized_text))
    
    for company in all_companies:
        # 跳过采购人
        if expected_buyer and company == expected_buyer:
            continue
        # 跳过投标人完整名称
        if bidder_name and company == bidder_name:
            continue
        # 跳过通用词
        if company in ('有限公司', '股份有限公司', '科技有限公司', '股份有限公司', '有限责任公司'):
            continue
        
        # 检查 company 是否是 bidder_name 的子串
        if bidder_name and company in bidder_name:
            continue
        # 反向检查：company 包含 bidder_name
        if bidder_name and bidder_name in company:
            continue
        
        # 找到公司名出现的位置（用 normalized_text 定位，因为前面做了空格合并）
        for match in re.finditer(re.escape(company), normalized_text):
            pos = match.start()
            context = normalized_text[max(0, pos-30):pos+len(company)+30]
            
            # 排除"投标人：XX公司" 这种正式引用
            if re.search(r'(?:投标人|单位名称|名称)\s*[：:]\s*' + re.escape(company), context):
                continue
            
            issues.append(PlagiarismIssue(
                issue_id=f'plag_{len(issues)+1:03d}',
                dimension='residual_info',
                severity='critical',
                description=f'标书中出现其他公司名：{company}',
                evidence=f'上下文："{context}"',
                location=f'字符位置 {pos}',
                suggestion=f'检查"{company}"是否应出现，若是残留请删除',
            ))
            break  # 同一公司名只报告一次
    
    # 3. 历史日期检测
    # 投标日期应该在招标文件之后，如果标书出现"2020 年实施"等历史日期，可能是抄的
    current_year = datetime.now().year
    for pattern in RESIDUAL_INFO_PATTERNS['other_date']:
        for match in re.finditer(pattern, all_text):
            year = int(match.group(1))
            if year < current_year - 2:  # 比当前年份早 2 年以上
                issues.append(PlagiarismIssue(
                    issue_id=f'plag_{len(issues)+1:03d}',
                    dimension='residual_info',
                    severity='major',
                    description=f'标书中出现历史日期：{match.group(0)}',
                    evidence=f'年份 {year} 距今已超过 2 年，疑似抄自历史项目',
                    location=f'字符位置 {match.start()}',
                    suggestion='检查该日期是否合理，若是历史项目残留请更新',
                ))
    
    return issues


# ============= 维度②：跨章节自重复检测 =============

def check_self_duplicate(doc, chapter_index: Dict) -> List[PlagiarismIssue]:
    """维度②：跨章节自重复检测"""
    _logger.info('  [抄袭检测2] 跨章节自重复检测...')
    issues = []
    
    # 收集所有章节的段落
    all_paragraphs = []
    chapters = chapter_index.get('chapters', [])
    
    paragraphs = list(doc.paragraphs)
    
    for ch in chapters:
        title = ch.get('title', '')
        start = ch.get('para_index_start', 0)
        end = ch.get('para_index_end', len(paragraphs))
        full_text = ch.get('full_text', '')
        
        if not full_text or len(full_text) < 100:
            continue
        
        # 切分章节内段落
        chapter_paragraphs = split_into_paragraphs(
            full_text, min_length=100, max_length=500,
            location_prefix=f'章节「{title}」'
        )
        all_paragraphs.extend(chapter_paragraphs)
    
    _logger.info(f'    共切分 {len(all_paragraphs)} 个段落')
    
    if len(all_paragraphs) < 2:
        return issues
    
    # 找相似段落对
    similar_pairs = find_similar_paragraph_pairs(
        all_paragraphs, threshold=0.6, skip_adjacent=True
    )
    
    _logger.info(f'    发现 {len(similar_pairs)} 对相似段落')
    
    for p1, p2, sim in similar_pairs[:20]:  # 最多报告 20 对
        # 截取段落前 80 字作为证据
        evidence = f'段落1（{p1.location}）: "{p1.text[:80]}..."\n段落2（{p2.location}）: "{p2.text[:80]}..."'
        
        issues.append(PlagiarismIssue(
            issue_id=f'plag_{len(issues)+1:03d}',
            dimension='self_duplicate',
            severity='critical' if sim >= 0.95 else ('major' if sim >= 0.8 else 'minor'),
            description=f'跨章节内容重复（相似度 {sim:.0%}）',
            evidence=evidence,
            location=f'{p1.location} vs {p2.location}',
            suggestion='检查是否为有意重复（如标准化条款），若不是请改写或合并',
            similarity=sim,
            content_summary=p1.text[:60],
            position_a=p1.location,
            position_b=p2.location,
        ))
    
    return issues


# ============= 维度③：与公开资料相似度检测 =============

def web_search(query: str, top_k: int = 3) -> List[Dict]:
    """调用 z-ai web-search CLI 检索"""
    try:
        result = subprocess.run(
            ['z-ai', 'web-search', '-q', query, '-n', str(top_k)],
            capture_output=True, text=True, timeout=30, check=False
        )
        if result.returncode != 0:
            _logger.debug(f'    web-search 失败：{result.stderr[:200]}')
            return []
        
        # 尝试解析 JSON
        output = result.stdout.strip()
        try:
            data = json.loads(output)
            if isinstance(data, list):
                return data[:top_k]
            elif isinstance(data, dict) and 'results' in data:
                return data['results'][:top_k]
        except json.JSONDecodeError:
            pass
        
        return []
    except subprocess.TimeoutExpired:
        _logger.debug('    web-search 超时')
        return []
    except FileNotFoundError:
        _logger.debug('    z-ai CLI 未安装')
        return []


def fetch_url_content(url: str) -> Optional[str]:
    """通过 z-ai web-reader 获取网页内容"""
    try:
        result = subprocess.run(
            ['z-ai', 'web-reader', '-u', url],
            capture_output=True, text=True, timeout=30, check=False
        )
        if result.returncode != 0:
            return None
        
        output = result.stdout.strip()
        try:
            data = json.loads(output)
            if isinstance(data, dict):
                return data.get('content', '') or data.get('html', '') or data.get('text', '')
            return output
        except json.JSONDecodeError:
            return output
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None


def check_external_similarity(doc, chapter_index: Dict, max_searches: int = 20) -> List[PlagiarismIssue]:
    """维度③：与公开资料相似度检测"""
    _logger.info(f'  [抄袭检测3] 与公开资料相似度检测（最多 {max_searches} 次检索）...')
    issues = []
    
    # 收集所有段落（按章节）
    all_paragraphs = []
    chapters = chapter_index.get('chapters', [])
    
    for ch in chapters:
        title = ch.get('title', '')
        full_text = ch.get('full_text', '')
        if not full_text or len(full_text) < 100:
            continue
        chapter_paragraphs = split_into_paragraphs(
            full_text, min_length=150, max_length=500,
            location_prefix=f'章节「{title}」'
        )
        all_paragraphs.extend(chapter_paragraphs)
    
    if not all_paragraphs:
        return issues
    
    # 选择待检索的段落（取每章节最长的 1-2 段，避免太多 API 调用）
    by_chapter = {}
    for p in all_paragraphs:
        ch_name = p.location.split('第')[0] if '第' in p.location else p.location
        if ch_name not in by_chapter:
            by_chapter[ch_name] = []
        by_chapter[ch_name].append(p)
    
    paragraphs_to_search = []
    for ch_name, ps in by_chapter.items():
        # 取最长的 2 段
        ps_sorted = sorted(ps, key=lambda x: -len(x.text))
        paragraphs_to_search.extend(ps_sorted[:2])
    
    # 限制总数
    paragraphs_to_search = paragraphs_to_search[:max_searches]
    
    _logger.info(f'    将检索 {len(paragraphs_to_search)} 个段落')
    
    search_count = 0
    for p in paragraphs_to_search:
        # 抽取关键句
        key_sentence = extract_key_sentence(p.text, max_length=60)
        if not key_sentence or len(key_sentence) < 15:
            continue
        
        search_count += 1
        _logger.info(f'    [{search_count}/{len(paragraphs_to_search)}] 检索: "{key_sentence[:30]}..."')
        
        # 调用 web-search
        results = web_search(key_sentence, top_k=3)
        if not results:
            continue
        
        # 对每个搜索结果，获取内容并计算相似度
        for result in results[:2]:
            url = result.get('url', '') or result.get('link', '')
            snippet = result.get('snippet', '') or result.get('content', '') or result.get('summary', '')
            
            if not url and not snippet:
                continue
            
            # 优先用 snippet（快），如果相似度较高再获取全文
            sim_with_snippet = 0
            if snippet:
                ext_fp = generate_ngrams(snippet)
                sim_with_snippet = jaccard_similarity(p.fingerprint, ext_fp)
            
            # 如果 snippet 相似度 > 50%，获取网页全文再算一次
            if sim_with_snippet >= 0.5 or not snippet:
                full_content = fetch_url_content(url) if url else None
                if full_content:
                    ext_fp = generate_ngrams(full_content[:5000])  # 限制长度
                    sim = jaccard_similarity(p.fingerprint, ext_fp)
                else:
                    sim = sim_with_snippet
            else:
                sim = sim_with_snippet
            
            if sim >= 0.7:
                ext_title = result.get('title', '') or result.get('source', '') or url
                risk = 'critical' if sim >= 0.95 else ('major' if sim >= 0.8 else 'minor')
                issues.append(PlagiarismIssue(
                    issue_id=f'plag_{len(issues)+1:03d}',
                    dimension='external_similar',
                    severity=risk,
                    description=f'与公开资料高度相似（相似度 {sim:.0%}）',
                    evidence=f'标书段落："{p.text[:100]}..."\n公开资料：{snippet[:100] if snippet else "(无摘要)"}',
                    location=f'{p.location} vs {ext_title or url}',
                    suggestion='改写为原创表述，或注明引用来源',
                    similarity=sim,
                    content_summary=p.text[:60],
                    position_a=p.location,
                    position_b=ext_title or url,
                ))
                break  # 同一段落只报告一次
        
        # 控制检索频率
        time.sleep(0.5)
    
    _logger.info(f'    检索完成，发现 {len(issues)} 处相似')
    return issues


# ============= 维度④：AI 痕迹检测 =============

def check_ai_traces(doc) -> List[PlagiarismIssue]:
    """维度④：AI 痕迹检测（宽松阈值）"""
    _logger.info('  [抄袭检测4] AI 痕迹检测（宽松阈值）...')
    issues = []
    
    all_text = '\n'.join(p.text or '' for p in doc.paragraphs)
    total_chars = len(all_text)
    
    if total_chars < 200:
        return issues
    
    # 1. 套话密度检测
    # 宽松阈值：每千字 5 处套话才报警
    cliche_count = 0
    cliche_examples = []
    for phrase in AI_CLICHE_PHRASES:
        matches = re.findall(re.escape(phrase), all_text)
        if matches:
            cliche_count += len(matches)
            if len(cliche_examples) < 3:
                cliche_examples.append(f'{phrase}（×{len(matches)}）')
    
    cliche_density = cliche_count / (total_chars / 1000)
    
    if cliche_density >= 5:
        issues.append(PlagiarismIssue(
            issue_id=f'plag_{len(issues)+1:03d}',
            dimension='ai_trace',
            severity='minor',
            description=f'套话密度过高（每千字 {cliche_density:.1f} 处套话）',
            evidence=f'套话示例：{", ".join(cliche_examples)}',
            location='全文',
            suggestion='替换为具体技术描述，减少空泛套话',
        ))
    
    # 2. 过渡词重复检测
    # 宽松阈值：同一过渡词在 1000 字内出现 ≥4 次
    transition_counter = Counter()
    for word in AI_TRANSITION_WORDS:
        count = len(re.findall(word, all_text))
        if count > 0:
            transition_counter[word] = count
    
    for word, count in transition_counter.most_common(5):
        density = count / (total_chars / 1000)
        if density >= 4:
            issues.append(PlagiarismIssue(
                issue_id=f'plag_{len(issues)+1:03d}',
                dimension='ai_trace',
                severity='minor',
                description=f'过渡词"{word}"使用过于频繁（每千字 {density:.1f} 次）',
                evidence=f'共出现 {count} 次',
                location='全文',
                suggestion=f'减少"{word}"的使用，换用其他表达方式',
            ))
    
    # 3. 结构对仗检测
    # 检测连续 3 个以上"动词+名词"的对仗结构（如"提升效率、降低成本、优化体验"）
    parallelism_pattern = re.compile(r'([\u4e00-\u9fa5]{2}[、，]\s*[\u4e00-\u9fa5]{2}[、，]\s*[\u4e00-\u9fa5]{2}(?:[、，]\s*[\u4e00-\u9fa5]{2})+)')
    parallelisms = parallelism_pattern.findall(all_text)
    
    if len(parallelisms) >= 5:  # 宽松阈值：5 个以上才报警
        issues.append(PlagiarismIssue(
            issue_id=f'plag_{len(issues)+1:03d}',
            dimension='ai_trace',
            severity='info',
            description=f'结构对仗过多（共 {len(parallelisms)} 处连续对仗）',
            evidence=f'示例：{parallelisms[0][:30]}...',
            location='全文',
            suggestion='减少机械对仗结构，使表达更自然',
        ))
    
    return issues


# ============= 维度⑤：引用未署名检测 =============

def check_citations(doc) -> List[PlagiarismIssue]:
    """维度⑤：引用未署名检测"""
    _logger.info('  [抄袭检测5] 引用未署名检测...')
    issues = []
    
    all_text = '\n'.join(p.text or '' for p in doc.paragraphs)
    
    # 找"参考"/"引自"/"根据"等关键词
    citation_patterns = [
        (r'引自\s*[《<]?([^》，。>。\s]{2,30})[》>]?', '引自'),
        (r'参考\s*[《<]?([^》，。>。\s]{2,30})[》>]?', '参考'),
        (r'根据\s*([^，。：:\s]{2,20})\s*[，。：:]', '根据'),
        (r'按照\s*([^，。：:\s]{2,20})\s*[，。：:]', '按照'),
        (r'依据\s*([^，。：:\s]{2,20})\s*[，。：:]', '依据'),
    ]
    
    # 完整引用（有书名号或具体文档名）
    complete_citation_pattern = re.compile(r'(?:引自|参考|根据|按照|依据)\s*[《<「]([^》>」]+)[》>」]')
    
    # 找所有"参考/引自"出现位置
    for pattern, kw in citation_patterns:
        for match in re.finditer(pattern, all_text):
            cited = match.group(1).strip()
            
            # 跳过通用词
            if cited in ('实际', '需要', '要求', '规定', '招标文件', '本项目', '方案', '设计'):
                continue
            
            # 检查是否有完整引用（书名号包裹）
            context = all_text[max(0, match.start()-10):match.end()+20]
            has_complete = bool(re.search(r'(?:引自|参考|根据|按照|依据)\s*[《<「]', context))
            
            if not has_complete:
                issues.append(PlagiarismIssue(
                    issue_id=f'plag_{len(issues)+1:03d}',
                    dimension='citation',
                    severity='info',
                    description=f'引用"{cited}"未署名完整来源',
                    evidence=f'上下文："{all_text[max(0,match.start()-20):match.end()+30]}"',
                    location=f'字符位置 {match.start()}',
                    suggestion=f'补充完整引用来源（如"参考《{cited}》第X章"）',
                ))
    
    # 去重（同一位置可能匹配多个 pattern）
    seen_positions = set()
    unique_issues = []
    for issue in issues:
        # 用位置做唯一性判断
        pos_key = issue.location
        if pos_key not in seen_positions:
            seen_positions.add(pos_key)
            unique_issues.append(issue)
    
    # 最多报告 10 个
    return unique_issues[:10]


def main():
    parser = argparse.ArgumentParser(description='Stage 5.5.2: 技术方案抄袭检测')
    parser.add_argument('--docx', required=True, help='标书 .docx 路径')
    parser.add_argument('--chapter-index', required=True, help='章节索引 JSON')
    parser.add_argument('--requirements', help='招标要求清单 JSON（可选）')
    parser.add_argument('--output', required=True, help='输出抄袭检测 Plan JSON')
    parser.add_argument('--no-web-search', action='store_true', help='跳过 web-search 检索')
    parser.add_argument('--max-searches', type=int, default=20, help='最多检索次数')
    parser.add_argument('--external-results-json', help='agent 用 WebSearch 兜底检索的维度③结果 JSON（z-ai 不可用时必填）')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取章节索引：{args.chapter_index}')
    with open(args.chapter_index, 'r', encoding='utf-8') as f:
        chapter_index = json.load(f)

    requirements = None
    if args.requirements and Path(args.requirements).exists():
        _logger.info(f'读取招标要求：{args.requirements}')
        with open(args.requirements, 'r', encoding='utf-8') as f:
            requirements = json.load(f)

    _logger.info(f'读取标书：{args.docx}')
    doc = Document(args.docx)

    all_issues = []
    _logger.info('开始执行抄袭检测 5 维度...')

    # 维度1: 残留他人信息
    all_issues.extend(check_residual_info(doc, requirements))
    # 维度2: 跨章节自重复
    all_issues.extend(check_self_duplicate(doc, chapter_index))
    # 维度3: 与公开资料相似度
    ext_status = 'unknown'
    ext_note = ''
    if args.no_web_search:
        _logger.info('  [抄袭检测3] 跳过 web-search（用户指定 --no-web-search）')
        ext_status = 'disabled_by_flag'
        ext_note = '用户指定 --no-web-search，维度③ 未检索公开资料。'
    elif args.external_results_json:
        # agent 已用自带 WebSearch 兜底检索，直接载入结果
        all_issues.extend(load_external_fallback(args.external_results_json))
        ext_status = 'searched'
        ext_note = '维度③ 由 agent 用自带 WebSearch 兜底检索公开资料。'
    elif not web_search_available():
        # z-ai 不可用且未提供兜底 → 明确标记，禁止伪装"无抄袭"
        _logger.warning('  [抄袭检测3] z-ai web-search 不可用，维度③ 未检索。'
                        '必须由调用方改用 WebSearch 兜底，禁止将 external_similar=0 当作"无抄袭"。')
        ext_status = 'skipped_no_tool'
        ext_note = ('本环境 z-ai web-search 不可用，维度③ 未检索公开资料；'
                    '需调用方（agent）用自带 WebSearch 工具兜底检索后填入 --external-results-json。')
    else:
        all_issues.extend(check_external_similarity(doc, chapter_index, args.max_searches))
        ext_status = 'searched'
        ext_note = '维度③ 已用 z-ai web-search 检索公开资料。'
    # 维度4: AI 痕迹
    all_issues.extend(check_ai_traces(doc))
    # 维度5: 引用未署名
    all_issues.extend(check_citations(doc))

    # 统计段落总数
    total_paragraphs = len([p for p in doc.paragraphs if p.text and p.text.strip()])

    summary_by_dimension = {
        'residual_info': sum(1 for i in all_issues if i.dimension == 'residual_info'),
        'self_duplicate': sum(1 for i in all_issues if i.dimension == 'self_duplicate'),
        'external_similar': sum(1 for i in all_issues if i.dimension == 'external_similar'),
        'ai_trace': sum(1 for i in all_issues if i.dimension == 'ai_trace'),
        'citation': sum(1 for i in all_issues if i.dimension == 'citation'),
    }

    plan = PlagiarismPlan(
        check_id=f'plag_{datetime.now().strftime("%Y%m%d_%H%M%S")}',
        check_time=datetime.now().isoformat(),
        total_paragraphs=total_paragraphs,
        issues=all_issues,
        summary_by_dimension=summary_by_dimension,
        external_search_status=ext_status,
        external_search_note=ext_note,
    )

    output = asdict(plan)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  总段落数：{total_paragraphs}')
    _logger.info(f'  问题数：{len(all_issues)}')
    _logger.info(f'  按维度：{summary_by_dimension}')


if __name__ == '__main__':
    main()
