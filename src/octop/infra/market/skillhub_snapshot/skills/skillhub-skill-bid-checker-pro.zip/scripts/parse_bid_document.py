#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
招标文件解析器 — Stage 1: 采购文件解析（Python预处理版）

核心思路：Python干脏活（提取确定性字段+定位章节原文），模型只做"填空和润色"

功能：
  1. 读取PDF/Word全文（PDF用pdfplumber，Word用python-docx）
  2. 自动检测章节结构 → 生成文档目录地图
  3. 正则提取关键字段 → 项目名称、编号、预算、日期等
  4. 定位+提取关键章节原文 → 资格要求、评分标准、技术参数等
  5. 自动识别采购方式（公开招标/竞争性谈判/磋商/单一来源/询价）
  6. 输出结构化JSON + 半成品Markdown报告

输出产物：
  - {项目名}_解析数据.json — 结构化中间数据
  - {项目名}_解析报告_auto.md — 半成品报告（确定性字段已填，分析性内容留空标注）

用法：
  python parse_bid_document.py --source "招标文件.pdf" [--output-dir ./output]
  python parse_bid_document.py --source "招标文件.docx"
"""

import os
import re
import sys
import json
import argparse
from datetime import datetime
from collections import OrderedDict

# v9.0: 统一日志
try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.bid_parser")
except ImportError:
    import logging
    _logger = logging.getLogger("bid_parser")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)

# ─── 文件读取层 ───

def load_pdf_text(pdf_path):
    """用pdfplumber逐页提取PDF全文"""
    import pdfplumber

    pages = []
    with pdfplumber.open(pdf_path) as pdf:
        total_pages = len(pdf.pages)
        for i, page in enumerate(pdf.pages):
            text = page.extract_text() or ""
            pages.append({
                "page_num": i + 1,
                "text": text
            })
    full_text = "\n\n".join([p["text"] for p in pages])
    _logger.info(f"PDF读取完成: {total_pages}页")
    return full_text, pages, total_pages


def load_word_text(docx_path):
    """用python-docx提取Word全文"""
    from docx import Document
    doc = Document(docx_path)
    paragraphs = []
    for i, para in enumerate(doc.paragraphs):
        if para.text.strip():
            paragraphs.append(para.text.strip())
    # 也提取表格文本
    tables_text = []
    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join([cell.text.strip() for cell in row.cells])
            if row_text.strip():
                tables_text.append(row_text)
    
    full_text = "\n".join(paragraphs) + "\n\n--- TABLES ---\n\n" + "\n".join(tables_text)
    _logger.info(f"  ✓ Word读取完成: {len(paragraphs)}段落, {len(doc.tables)}表格")
    return full_text, paragraphs, len(paragraphs)


def load_file(file_path):
    """统一入口：根据文件类型调用对应的读取函数"""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.pdf':
        return load_pdf_text(file_path)
    elif ext in ('.docx', '.doc'):
        return load_word_text(file_path)
    else:
        raise ValueError(f"不支持的文件格式: {ext}（仅支持.pdf/.docx/.doc）")


# ─── 章节检测层 ───

# 只检测主级章节标题（第X章 / 第X部分），不检测子级（一、/1.）避免误判
PRIMARY_CHAPTER_PATTERNS = [
    (r'^第[一二三四五六七八九十百零\d]+章\s+(.+)', 'chapter_num'),
    (r'^第[一二三四五六七八九十百零\d]+部分\s+(.+)', 'part_num'),
]

# 二级标题模式（仅用于已知章节内的小节定位）
SECTION_PATTERNS = [
    (r'^[一二三四五六七八九十百]+、\s*(.+)', 'section_num'),
    (r'^附件[一二三四五六七八九十百\d]+\s*(.+)', 'appendix'),
]

# 关键章节关键词映射 — 精确匹配优先，避免正文误匹配
KEY_CHAPTER_KEYWORDS = {
    '招标公告': ['招标公告', '采购公告', '竞争性谈判公告', '磋商公告', '询价公告'],
    '投标人须知': ['投标须知', '投标人须知', '供应商须知', '谈判须知'],
    '资格要求': ['资格审查材料', '资格要求', '供应商资格条件'],
    '评标方法': ['评标方法及标准', '评标方法', '评审方法', '评分标准', '评审标准'],
    '采购内容': ['采购需求', '采购内容', '招标内容', '技术参数', '货物需求'],
    '合同条款': ['合同格式条款', '合同条款', '合同格式', '协议条款', '采购合同'],
    '投标文件格式': ['投标文件格式', '响应文件格式', '报价文件格式', '投标文件组成'],
    '废标条款': ['废标条款', '无效投标条款', '否决投标'],
}


def detect_primary_chapters(full_text):
    """
    从全文中检测主级章节（第X章/第X部分）。
    返回: list of {title, level, char_pos, char_end}
    """
    chapters = []
    lines = full_text.split('\n')
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or len(stripped) < 5:
            continue
        for pattern, level in PRIMARY_CHAPTER_PATTERNS:
            match = re.match(pattern, stripped)
            if match:
                chapters.append({
                    'title': stripped,
                    'level': level,
                    'line_pos': i,
                })
                break
    
    # 如果没找到"第X章"结构，退而求其次检测二级标题
    if len(chapters) < 3:
        for i, line in enumerate(lines):
            stripped = line.strip()
            if not stripped or len(stripped) < 5:
                continue
            for pattern, level in SECTION_PATTERNS:
                match = re.match(pattern, stripped)
                if match:
                    # 检查是否包含关键章节关键词才保留
                    has_keyword = False
                    for kws in KEY_CHAPTER_KEYWORDS.values():
                        for kw in kws:
                            if kw in stripped:
                                has_keyword = True
                                break
                    # 或者标题足够长（可能是有意义的小节）
                    if has_keyword or len(stripped) > 15:
                        chapters.append({
                            'title': stripped,
                            'level': level,
                            'line_pos': i,
                        })
                    break
    
    _logger.info(f"  ✓ 章节检测: 发现 {len(chapters)} 个章节标题")
    return chapters


def map_key_chapters(chapters):
    """
    将检测到的章节映射到关键章节类型。
    只取第一个匹配（最重要的），避免正文误匹配。
    """
    mapped = {}
    for ch in chapters:
        title = ch['title']
        for ch_type, keywords in KEY_CHAPTER_KEYWORDS.items():
            # 只匹配未映射的类型（取第一个）
            if ch_type in mapped:
                continue
            for kw in keywords:
                if kw in title:
                    mapped[ch_type] = ch
                    break
    
    # 打印映射结果
    for ch_type, ch in mapped.items():
        _logger.info(f"    📌 {ch_type}: {ch['title'][:50]}")
    
    return mapped


def extract_chapter_text(full_text, chapter_info, all_chapters=None):
    """
    提取某个章节的原文内容（字符级定位）。
    从章节标题行开始，到下一个主级章节为止。
    最多提取3000字（避免太长）。
    """
    lines = full_text.split('\n')
    start_pos = chapter_info['line_pos']
    
    # 找结束位置：下一个主级章节或文档末尾
    end_pos = len(lines)
    if all_chapters:
        for ch in all_chapters:
            if ch['line_pos'] > start_pos and ch['level'] in ('chapter_num', 'part_num'):
                end_pos = ch['line_pos']
                break
    
    # 限制提取范围（最多150行）
    max_lines = 150
    end_pos = min(end_pos, start_pos + max_lines)
    
    chapter_text = '\n'.join(lines[start_pos:end_pos])
    # 也限制总字符数
    if len(chapter_text) > 3000:
        chapter_text = chapter_text[:3000]
    
    return chapter_text


# ─── 关键字段提取层 ───

# 字段提取规则：关键词+正则模式
# 注意：关键词必须精确，避免"标项名称"匹配到"项目名称"
EXTRACT_RULES = OrderedDict({
    '项目名称': {
        'keywords': ['项目名称'],
        'patterns': [
            r'(?:^|\n)项目名称[：:]\s*(.+?)[\n,，；;]',
            r'项目名称[：:]\s*([^\n,，；;]{5,60}?)[\n,，；;]',
        ],
        'negative_keywords': ['标项名称', '包件名称'],
    },
    '项目编号': {
        'keywords': ['项目编号', '招标编号', '采购编号'],
        'patterns': [
            r'项目编号[：:]\s*(.+?)[\n,，；;]',
            r'招标编号[：:]\s*([A-Za-z\u4e00-\u9fa5\d\-—_]{3,30})',
            r'编号[：:]\s*([A-Za-z\d\-—_]{5,20})',
        ],
        'negative_keywords': ['投标人名称', '供应商名称'],
    },
    '采购人': {
        'keywords': ['采购人', '招标人', '采购单位'],
        'patterns': [
            r'采购人[：:]\s*(.+?)[\n,，；;]',
            r'招标人[：:]\s*(.+?)[\n,，；;]',
            r'采购单位[：:]\s*(.+?)[\n,，；;]',
        ],
    },
    '采购代理机构': {
        'keywords': ['采购代理机构', '代理机构', '招标代理'],
        'patterns': [
            r'采购代理机构[：:]\s*(.+?)[\n,，；;]',
            r'代理机构[：:]\s*(.+?)[\n,，；;]',
            r'招标代理[机构]*[：:]\s*(.+?)[\n,，；;]',
        ],
    },
    '采购方式': {
        'keywords': ['公开招标', '竞争性谈判', '竞争性磋商', '单一来源', '询价'],
        'patterns': [
            r'采购方式[：:]\s*(公开招标|竞争性谈判|竞争性磋商|单一来源采购|询价)',
        ],
        'auto_detect': True,
    },
    '预算金额': {
        'keywords': ['预算金额', '最高限价', '项目预算', '控制价', '采购预算'],
        'patterns': [
            r'预算金额[：:]\s*([\d,，.．]+\s*万?元)',
            r'最高限价[：:]\s*([\d,，.．]+\s*万?元)',
            r'项目预算[：:]\s*([\d,，.．]+\s*万?元)',
            r'控制价[：:]\s*([\d,，.．]+\s*万?元)',
            # 数字+元 的宽泛匹配
            r'(?:预算|限价|控制价|预算金额).*?([\d,，.．]+\s*万?元)',
        ],
    },
    '资金来源': {
        'keywords': ['资金来源', '资金落实'],
        'patterns': [
            r'资金来源[：:]\s*(.+?)[\n,，；;]',
            r'资金落实情况[：:]\s*(.+?)[\n,，；;]',
        ],
    },
    '投标保证金': {
        'keywords': ['投标保证金', '保证金'],
        'patterns': [
            r'投标保证金[：:]\s*(.+?)[\n,，；;]',
            r'保证金[金额]*[：:]\s*(.+?)[\n,，；;]',
        ],
    },
    '投标有效期': {
        'keywords': ['投标有效期', '有效期'],
        'patterns': [
            r'投标有效期[：:]\s*(\d+\s*日历天|\d+\s*天|\d+日)',
            r'有效期[：:]\s*(\d+\s*日历天|\d+\s*天)',
        ],
    },
    '交货期': {
        'keywords': ['交货期', '供货期', '交付期', '交货期限', '供货期限'],
        'patterns': [
            r'交货期[限]*[：:]\s*(.+?)[\n,，；;]',
            r'供货期[限]*[：:]\s*(.+?)[\n,，；;]',
            r'交付期[限]*[：:]\s*(.+?)[\n,，；;]',
        ],
    },
    '质保期': {
        'keywords': ['质保期', '保修期', '质量保证期'],
        'patterns': [
            r'质保期[：:]\s*(.+?)[\n,，；;]',
            r'保修期[：:]\s*(.+?)[\n,，；;]',
            r'质量保证期[：:]\s*(.+?)[\n,，；;]',
        ],
    },
    '是否允许联合体': {
        'keywords': ['联合体', '联合投标'],
        'patterns': [
            r'(不接受|不允许|禁止)\s*联合体',
            r'(接受|允许)\s*联合体',
            r'联合体[：:]\s*(不接受|不允许|接受|允许|否|是)',
        ],
    },
    '开标时间': {
        'keywords': ['开标时间', '开标日期'],
        'patterns': [
            r'开标时间[：:]\s*(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日[\s\d：:点分]+)',
            r'开标时间[：:]\s*(.+?)[\n,，；;]',
            r'开标日期[：:]\s*(.+?)[\n,，；;]',
        ],
    },
    '投标截止时间': {
        'keywords': ['投标截止', '递交截止', '截止时间'],
        'patterns': [
            r'投标截止时间[：:]\s*(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日[\s\d：:点分]+)',
            r'递交截止时间[：:]\s*(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日)',
            r'截止时间[：:]\s*(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日)',
        ],
    },
    '供货地点': {
        'keywords': ['供货地点', '交货地点', '项目地点', '实施地点'],
        'patterns': [
            r'供货地点[：:]\s*(.+?)[\n,，；;]',
            r'交货地点[：:]\s*(.+?)[\n,，；;]',
            r'项目地点[：:]\s*(.+?)[\n,，；;]',
        ],
    },
})

# 采购方式自动识别关键词
PROCUREMENT_TYPE_KEYWORDS = {
    '公开招标': ['公开招标', '招标公告', '招标文件', '招标投标法'],
    '竞争性谈判': ['竞争性谈判', '谈判文件', '谈判公告', '谈判采购'],
    '竞争性磋商': ['竞争性磋商', '磋商文件', '磋商公告', '磋商采购'],
    '单一来源采购': ['单一来源', '单一来源采购', '单一来源协商'],
    '询价': ['询价', '询价通知书', '询价采购', '询价公告'],
}


def extract_fields(full_text):
    """
    用关键词+正则从全文中提取关键字段。
    返回: dict of {field_name: {value, source, confidence}}
    """
    results = {}
    
    for field_name, rule in EXTRACT_RULES.items():
        value = None
        source = 'regex'
        confidence = 'low'
        neg_kws = rule.get('negative_keywords', [])
        
        # 逐个正则模式尝试
        for pattern in rule.get('patterns', []):
            # 找所有匹配位置
            for match in re.finditer(pattern, full_text):
                m = match.group(1) if match.lastindex else match.group(0)
                val = m.strip()
                
                # 负关键词过滤：排除误匹配
                match_start = match.start()
                context_before = full_text[max(0, match_start-30):match_start]
                skip = False
                for nk in neg_kws:
                    if nk in context_before or nk in val:
                        skip = True
                        break
                
                if skip or not val or len(val) < 2:
                    continue
                
                value = val
                confidence = 'high'
                break  # 取第一个有效匹配
            
            if value:
                break
        
        # 采购方式特殊处理：自动从全文识别
        if field_name == '采购方式' and not value:
            for ptype, kws in PROCUREMENT_TYPE_KEYWORDS.items():
                for kw in kws:
                    if kw in full_text[:3000]:
                        value = ptype
                        source = 'keyword_detect'
                        confidence = 'high'
                        break
                if value:
                    break
        
        # 关键词搜索兜底：如果正则没匹配到，用关键词上下文提取
        if not value and rule.get('keywords'):
            for kw in rule['keywords']:
                idx = full_text.find(kw)
                if idx >= 0:
                    context = full_text[idx:idx + len(kw) + 80].strip()
                    # 排除负关键词
                    skip = False
                    for nk in neg_kws:
                        if nk in context[:len(kw)+5]:
                            skip = True
                            break
                    if skip:
                        continue
                    
                    colon_idx = context.find('：')
                    if colon_idx < 0:
                        colon_idx = context.find(':')
                    if colon_idx >= 0 and colon_idx < len(kw) + 5:
                        after_colon = context[colon_idx + 1:].strip()
                        for stop in ['\n', '，', ',', '；', ';']:
                            si = after_colon.find(stop)
                            if si > 0:
                                after_colon = after_colon[:si]
                        if after_colon and len(after_colon) > 1:
                            value = after_colon
                            source = 'keyword_context'
                            confidence = 'medium'
                            break
        
        results[field_name] = {
            'value': value or '',
            'source': source,
            'confidence': confidence if value else 'none'
        }
    
    # 统计提取率
    filled = sum(1 for v in results.values() if v['value'])
    total = len(results)
    _logger.info(f"  ✓ 字段提取: {filled}/{total} ({filled/total*100:.0f}%)")
    
    return results


# ─── 关键日期提取层 ───

def extract_date_nodes(full_text, basic_info):
    """
    提取关键时间节点。
    返回: list of {node_name, date_value, context}
    """
    date_nodes = []
    
    # 日期正则模式
    date_patterns = [
        r'(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日\s*\d{1,2}\s*[时:：]\s*\d{1,2}\s*分)',
        r'(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日)',
        r'(\d{4}\s*[-/]\s*\d{1,2}\s*[-/]\s*\d{1,2})',
    ]
    
    # 时间节点关键词
    time_keywords = [
        ('招标文件获取开始', ['招标文件获取', '获取招标文件', '文件获取开始']),
        ('招标文件获取截止', ['获取截止', '文件获取截止', '领取截止']),
        ('投标截止时间', ['投标截止', '递交截止', '截止时间', '递交投标']),
        ('开标时间', ['开标时间', '开标日期', '开标']),
        ('答疑截止', ['答疑截止', '质疑截止', '提问截止']),
        ('投标有效期截止', ['有效期截止', '投标有效期']),
    ]
    
    for node_name, keywords in time_keywords:
        found_date = None
        context = ''
        
        for kw in keywords:
            # 在关键词前后200字范围内搜索日期
            idx = full_text.find(kw)
            while idx >= 0 and not found_date:
                search_range = full_text[max(0, idx-50):idx + len(kw) + 150]
                for dp in date_patterns:
                    dm = re.search(dp, search_range)
                    if dm:
                        found_date = dm.group(1).strip()
                        # 清理日期格式
                        found_date = re.sub(r'\s+', '', found_date)
                        context = search_range.strip()[:100]
                        break
                if not found_date:
                    # 继续搜索下一个关键词位置
                    idx = full_text.find(kw, idx + 1)
        
        # 优先使用basic_info中已提取的值
        if node_name == '开标时间' and basic_info.get('开标时间', {}).get('value'):
            found_date = basic_info['开标时间']['value']
        if node_name == '投标截止时间' and basic_info.get('投标截止时间', {}).get('value'):
            found_date = basic_info['投标截止时间']['value']
        
        date_nodes.append({
            'node_name': node_name,
            'date_value': found_date or '',
            'context': context,
            'source': 'regex' if found_date else 'none'
        })
    
    filled = sum(1 for d in date_nodes if d['date_value'])
    _logger.info(f"  ✓ 时间节点: {filled}/{len(date_nodes)}")
    
    return date_nodes


# ─── 报告生成层 ───

def generate_json_output(basic_info, date_nodes, chapter_map, key_chapters, 
                          chapter_texts, meta_info, output_path):
    """生成结构化JSON中间数据"""
    output = {
        'meta': meta_info,
        'chapter_map': chapter_map[:50],  # 只保留前50个章节标题
        'key_chapters_detected': {k: v['title'][:60] for k, v in key_chapters.items()},
        'basic_info': basic_info,
        'date_nodes': date_nodes,
        'chapter_texts': chapter_texts,
    }
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    
    _logger.info(f"  ✓ JSON输出: {output_path}")
    return output


def generate_markdown_report(basic_info, date_nodes, chapter_map, key_chapters,
                              chapter_texts, meta_info, output_path):
    """
    生成半成品Markdown报告。
    确定性字段已填入，分析性内容留空标注 ⬜，
    预提取的章节原文附在对应位置供模型补全。
    """
    project_name = basic_info.get('项目名称', {}).get('value', '未识别项目')
    procurement_type = basic_info.get('采购方式', {}).get('value', '未知')
    
    # ── 计算提取率 ──
    filled_fields = sum(1 for v in basic_info.values() if v.get('value'))
    total_fields = len(basic_info)
    filled_dates = sum(1 for d in date_nodes if d.get('date_value'))
    total_dates = len(date_nodes)
    overall_rate = (filled_fields + filled_dates) / (total_fields + total_dates) * 100
    
    # ── 构建报告 ──
    report = []
    report.append(f"# 采购文件解析报告（Python预处理版）")
    report.append("")
    report.append(f"> **项目**：{project_name}")
    report.append(f"> **采购方式**：{procurement_type}")
    report.append(f"> **解析时间**：{datetime.now().strftime('%Y-%m-%d')}")
    report.append(f"> **解析版本**：bid-document-maker v3.0 Python预处理")
    report.append(f"> **自动提取率**：{overall_rate:.0f}%（确定性字段由Python正则提取，分析性内容⬜待模型补全）")
    report.append("")
    report.append("---")
    
    # ── 〇、文档目录地图 ──
    report.append("## 〇、文档目录地图")
    report.append("")
    report.append("| 章节 | 内容类型 | 提取状态 |")
    report.append("|------|---------|---------|")
    
    # 用章节标题生成目录地图
    seen_titles = set()
    for ch in chapter_map[:30]:
        title_short = ch['title'][:50].rstrip('-')
        if title_short in seen_titles:
            continue
        seen_titles.add(title_short)
        
        # 映射内容类型
        content_type = '—'
        for ch_type, keywords in KEY_CHAPTER_KEYWORDS.items():
            for kw in keywords:
                if kw in title_short:
                    content_type = ch_type
                    break
        
        status = '✅ 已定位' if content_type != '—' else '📋 已识别'
        report.append(f"| {title_short} | {content_type} | {status} |")
    
    report.append("")
    report.append("---")
    
    # ── 一、项目基本信息 ──
    report.append("## 一、项目基本信息")
    report.append("")
    report.append("| 信息项 | 内容 | 提取方式 | 确信度 |")
    report.append("|--------|------|---------|--------|")
    
    field_order = ['项目名称', '项目编号', '采购人', '采购代理机构', '采购方式',
                   '预算金额', '资金来源', '投标保证金', '投标有效期', 
                   '交货期', '质保期', '供货地点', '是否允许联合体',
                   '开标时间', '投标截止时间']
    
    for fname in field_order:
        if fname in basic_info:
            info = basic_info[fname]
            value = info.get('value', '')
            src = info.get('source', '')
            conf = info.get('confidence', 'none')
            
            # 确信度标记
            conf_mark = {
                'high': '✅ 高',
                'medium': '⚠️ 中',
                'low': '⚠️ 低',
                'none': '⬜ 待补'
            }.get(conf, '⬜ 待补')
            
            # 来源标记
            src_mark = {
                'regex': '🤖 正则',
                'keyword_detect': '🔍 关键词',
                'keyword_context': '🔍 上下文',
            }.get(src, '—')
            
            display_value = value if value else '⬜ 待模型补全'
            report.append(f"| {fname} | {display_value} | {src_mark} | {conf_mark} |")
    
    # 补充: 招标公告原文片段（供模型参考）
    if '招标公告' in chapter_texts:
        report.append("")
        report.append("> **📌 招标公告原文片段（供模型补全参考）**：")
        report.append(">")
        raw = chapter_texts['招标公告'][:600]
        # 每行加 > 引用标记
        for line in raw.split('\n')[:15]:
            report.append(f"> {line}")
        report.append("")
    
    report.append("")
    report.append("---")
    
    # ── 二、标项划分 ──
    report.append("## 二、标项/包件划分")
    report.append("")
    report.append("⬜ **待模型补全** — 需从采购内容章节中识别标项/包件划分，整理成总览表。")
    if '采购内容' in chapter_texts:
        report.append("")
        report.append("> **📌 采购内容原文片段（供模型补全参考）**：")
        report.append(">")
        raw = chapter_texts['采购内容'][:500]
        for line in raw.split('\n')[:10]:
            report.append(f"> {line}")
    report.append("")
    report.append("---")
    
    # ── 三、关键时间节点 ──
    report.append("## 三、关键时间节点")
    report.append("")
    report.append("| 序号 | 时间节点 | 日期/期限 | 提取方式 |")
    report.append("|------|---------|----------|---------|")
    
    for i, dn in enumerate(date_nodes, 1):
        value = dn.get('date_value', '') or '⬜ 待补'
        src = dn.get('source', 'none')
        src_mark = '🤖 正则' if src == 'regex' else '⬜ 手动'
        report.append(f"| {i} | {dn['node_name']} | {value} | {src_mark} |")
    
    report.append("")
    report.append("---")
    
    # ── 四、资格要求 ──
    report.append("## 四、资格要求")
    report.append("")
    report.append("⬜ **待模型补全** — 需从资格要求章节原文中提取资格条件清单、证明材料要求。")
    if '资格要求' in chapter_texts:
        report.append("")
        report.append("> **📌 资格要求原文片段（供模型补全参考）**：")
        report.append(">")
        raw = chapter_texts['资格要求'][:800]
        for line in raw.split('\n')[:20]:
            report.append(f"> {line}")
    report.append("")
    report.append("---")
    
    # ── 五、技术要求 ──
    report.append("## 五、技术要求（逐标项）")
    report.append("")
    report.append("⬜ **待模型补全** — 需从技术参数章节中提取：")
    report.append("  - 实质性技术要求（★条款）")
    report.append("  - 一般技术要求")
    report.append("  - 逐设备技术参数对照表")
    report.append("  - 技术要求汇总统计")
    if '采购内容' in chapter_texts:
        report.append("")
        report.append("> **📌 采购需求/技术参数原文片段（供模型补全参考）**：")
        report.append(">")
        raw = chapter_texts['采购内容'][:800]
        for line in raw.split('\n')[:20]:
            report.append(f"> {line}")
    report.append("")
    report.append("---")
    
    # ── 六、评分标准 ──
    report.append("## 六、评分标准 + 量化分析")
    report.append("")
    report.append("⬜ **待模型补全** — 需从评标方法章节中提取：")
    report.append("  - 评分结构总览")
    report.append("  - 评分细则量化分析（得分难度评级）")
    report.append("  - 价格评分公式")
    if '评标方法' in chapter_texts:
        report.append("")
        report.append("> **📌 评标/评分标准原文片段（供模型补全参考）**：")
        report.append(">")
        raw = chapter_texts['评标方法'][:800]
        for line in raw.split('\n')[:20]:
            report.append(f"> {line}")
    report.append("")
    report.append("---")
    
    # ── 七、政策支持条款 ──
    report.append("## 七、政府采购政策支持条款")
    report.append("")
    report.append("⬜ **待模型补全** — 需从全文中提取中小企业扶持、节能产品、环境标志产品等政策条款。")
    report.append("")
    report.append("---")
    
    # ── 八、废标条款 ──
    report.append("## 八、废标/无效投标条款")
    report.append("")
    if '废标条款' in chapter_texts:
        report.append("> **📌 废标/无效投标原文片段（供模型补全参考）**：")
        report.append(">")
        raw = chapter_texts['废标条款'][:800]
        for line in raw.split('\n')[:20]:
            report.append(f"> {line}")
    else:
        report.append("⬜ **待模型补全** — 需从投标人须知章节中提取废标/无效投标情形。")
        if '投标人须知' in chapter_texts:
            report.append("")
            report.append("> **📌 投标人须知原文片段（供模型补全参考）**：")
            report.append(">")
            raw = chapter_texts['投标人须知'][:500]
            for line in raw.split('\n')[:10]:
                report.append(f"> {line}")
    report.append("")
    report.append("---")
    
    # ── 九、响应文件组成清单 ──
    report.append("## 九、响应文件组成清单 ⭐第三阶段核心输入")
    report.append("")
    if '投标文件格式' in chapter_texts:
        report.append("> **📌 投标文件格式原文片段（供模型补全参考）**：")
        report.append(">")
        raw = chapter_texts['投标文件格式'][:600]
        for line in raw.split('\n')[:15]:
            report.append(f"> {line}")
        report.append("")
        report.append("⬜ **待模型补全** — 需从以上原文提取：")
        report.append("  - 响应文件结构（必须包含的文件列表及顺序）")
        report.append("  - 文件生成清单（每个文件需要的信息依赖）")
        report.append("  - 格式要求（封面、目录、页码、装订、签字盖章等）")
    else:
        report.append('⬜ **待模型补全** — 未自动定位到"投标文件格式"章节。')
    report.append("")
    report.append("---")
    
    # ── 十、完整性校验 ──
    report.append("## 十、完整性校验结果")
    report.append("")
    report.append("| 序号 | 信息类别 | Python提取状态 | 完整度 | 说明 |")
    report.append("|------|---------|--------------|--------|------|")
    
    check_items = [
        ('1', '项目基本信息', f'{filled_fields}/{total_fields}字段已提取', 
         f'{filled_fields/total_fields*100:.0f}%', '确定性字段由正则提取，其余⬜待补'),
        ('2', '标项/包件划分', '⬜ 待模型补全', '0%', '需从采购内容章节提取'),
        ('3', '资格要求', '⬜ 待模型补全', '0%', '原文已定位，需模型整理'),
        ('4', '技术要求', '⬜ 待模型补全', '0%', '原文已定位，需模型整理'),
        ('5', '评分标准', '⬜ 待模型补全', '0%', '原文已定位，需模型整理'),
        ('6', '关键时间节点', f'{filled_dates}/{total_dates}节点已提取', 
         f'{filled_dates/total_dates*100:.0f}%', '日期由正则提取'),
        ('7', '合同条款', '⬜ 待模型补全', '0%', '需定位合同章节'),
        ('8', '投标文件格式', '✅ 已定位' if '投标文件格式' in key_chapters else '⬜ 未定位', 
         '0%', '原文已定位，需模型整理'),
        ('9', '废标条款', '⬜ 待模型补全', '0%', '原文已定位，需模型整理'),
        ('10', '政策支持条款', '⬜ 待模型补全', '0%', '需从全文提取'),
    ]
    
    for item in check_items:
        report.append(f"| {item[0]} | {item[1]} | {item[2]} | {item[3]} | {item[4]} |")
    
    report.append("")
    report.append(f"> **整体完整度评估**：约{overall_rate:.0f}%（Python预处理部分）。")
    report.append(f"> 模型补全后预期可达90%+。")
    report.append("")
    report.append("---")
    
    # ── 补全指引 ──
    report.append("## 📋 模型补全指引")
    report.append("")
    report.append("本报告由 `parse_bid_document.py` 自动生成，包含两部分：")
    report.append("  - ✅ **确定性字段**：由Python正则提取，高确信度（项目名称、编号、预算、日期等）")
    report.append("  - ⬜ **分析性内容**：留空待补，原文片段已附在旁边供参考")
    report.append("")
    report.append("模型补全时请遵循以下规则：")
    report.append("  1. 先**校验**已提取的确定性字段是否正确（对照原文片段）")
    report.append("  2. 从预提取的章节原文中**整理**分析性内容（评分标准表格、资格要求清单等）")
    report.append("  3. ⬜ 空缺项从原文中**补填**（项目编号、采购人地址等细节字段）")
    report.append("  4. **不允许留空白项** — 缺失项必须标注原因并给出用户操作指引")
    report.append("  5. 保持报告的**Markdown格式**不变，只替换⬜标记的内容")
    report.append("")
    
    # 写入文件
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(report))
    
    _logger.info(f"  ✓ Markdown报告: {output_path}")
    return '\n'.join(report)


# ─── 主流程 ───

def parse_bid_document(source_path, output_dir=None):
    """
    招标文件解析主流程。
    
    步骤:
      1. 加载文件 → 提取全文
      2. 检测章节结构 → 生成目录地图
      3. 提取关键字段 → 正则匹配
      4. 提取时间节点 → 正则匹配
      5. 定位关键章节 → 提取原文片段
      6. 生成JSON + Markdown报告
    """
    _logger.info(f"=== 招标文件解析器（Python预处理版） ===")
    _logger.info(f"  源文件: {source_path}")
    
    if not os.path.exists(source_path):
        raise FileNotFoundError(f"文件不存在: {source_path}")
    
    # 确定输出目录
    if not output_dir:
        output_dir = os.path.dirname(os.path.abspath(source_path))
    
    ext = os.path.splitext(source_path)[1].lower()
    
    # ── Step 1: 加载文件 ──
    _logger.info("\n[Step 1] 加载文件...")
    full_text, raw_data, total_count = load_file(source_path)
    
    # ── Step 2: 检测章节结构 ──
    _logger.info("\n[Step 2] 检测章节结构...")
    chapters = detect_primary_chapters(full_text)
    key_chapters = map_key_chapters(chapters)
    
    # ── Step 3: 提取关键字段 ──
    _logger.info("\n[Step 3] 提取关键字段...")
    basic_info = extract_fields(full_text)
    
    # ── 确定项目名（优先从提取结果获取）──
    extracted_name = basic_info.get('项目名称', {}).get('value', '')
    if not extracted_name:
        basename = os.path.splitext(os.path.basename(source_path))[0]
        cleaned = re.sub(r'定稿文件|公开招标文件|招标文件|采购文件|竞争性谈判文件|磋商文件|询价通知书|\d+', '', basename)
        project_name = cleaned.strip()[:20] if cleaned.strip() else '未识别项目'
    else:
        project_name = extracted_name
        if len(project_name) > 30:
            short_match = re.search(r'([\u4e00-\u9fa5]{2,10}(?:学校|公司|医院|局|厅|部|中心|集团))', project_name)
            if short_match:
                project_name = short_match.group(1)
    
    project_name = re.sub(r'[（()）\s]', '', project_name)[:20]
    _logger.info(f"  ✓ 项目名: {project_name}")
    
    # ── Step 4: 提取时间节点 ──
    _logger.info("\n[Step 4] 提取时间节点...")
    date_nodes = extract_date_nodes(full_text, basic_info)
    
    # ── Step 5: 定位关键章节原文 ──
    _logger.info("\n[Step 5] 定位关键章节原文...")
    chapter_texts = {}
    
    for ch_type, ch_info in key_chapters.items():
        text = extract_chapter_text(full_text, ch_info, chapters)
        chapter_texts[ch_type] = text
        _logger.info(f"    📄 {ch_type}: 提取 {len(text)} 字原文")
    
    # ── Step 6: 生成输出 ──
    _logger.info("\n[Step 6] 生成报告...")
    
    meta_info = {
        'source_file': source_path,
        'project_name': project_name,
        'file_type': ext,
        'total_pages_or_paragraphs': total_count,
        'parse_time': datetime.now().strftime('%Y-%m-%d %H:%M'),
        'parser_version': 'v3.0-python-preprocess',
    }
    
    json_path = os.path.join(output_dir, f'{project_name}_解析数据.json')
    md_path = os.path.join(output_dir, f'{project_name}_解析报告_auto.md')
    
    # 生成JSON
    generate_json_output(basic_info, date_nodes, chapters, key_chapters,
                          chapter_texts, meta_info, json_path)
    
    # 生成Markdown报告
    generate_markdown_report(basic_info, date_nodes, chapters, key_chapters,
                              chapter_texts, meta_info, md_path)
    
    _logger.info(f"\n=== 解析完成 ===")
    _logger.info(f"  JSON数据: {json_path}")
    _logger.info(f"  半成品报告: {md_path}")
    _logger.info(f"  自动提取率: {overall_rate(basic_info, date_nodes):.0f}%")
    _logger.info(f"  ⬜ 待模型补全: 标项划分、资格要求、技术要求、评分标准、政策条款、废标条款")
    
    return {
        'json_path': json_path,
        'md_path': md_path,
        'basic_info': basic_info,
        'date_nodes': date_nodes,
        'chapter_texts': chapter_texts,
    }


def overall_rate(basic_info, date_nodes):
    filled_b = sum(1 for v in basic_info.values() if v.get('value'))
    total_b = len(basic_info)
    filled_d = sum(1 for d in date_nodes if d.get('date_value'))
    total_d = len(date_nodes)
    return (filled_b + filled_d) / (total_b + total_d) * 100


# ─── CLI入口 ───

def main():
    parser = argparse.ArgumentParser(description='招标文件解析器（Python预处理版）')
    parser.add_argument('--source', required=True, help='招标文件路径（.pdf/.docx/.doc）')
    parser.add_argument('--output-dir', default=None, help='输出目录（默认=源文件所在目录）')
    args = parser.parse_args()
    
    result = parse_bid_document(args.source, args.output_dir)


if __name__ == '__main__':
    main()
