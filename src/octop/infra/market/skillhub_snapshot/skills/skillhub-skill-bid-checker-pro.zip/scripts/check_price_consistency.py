#!/usr/bin/env python3
"""
Stage 5.5.1: 价格分一致性检查

5 项检查：
  ① 大写金额合规性
  ② 大小写一致性
  ③ 跨位置一致性（投标函/一览表/报价表/商务标/技术标）
  ④ 分项合计校验（含 Excel 报价表）
  ⑤ 文字-表格一致性

输入：
  --docx: 标书 .docx 路径
  --chapter-index: 章节索引 JSON
  --requirements: 招标要求清单 JSON
  --xlsx: 报价表 xlsx 路径（可选）
  --output: 输出价格检查 Plan JSON

输出：{项目名}_价格检查Plan.json
"""
import argparse
import json
import sys
import re
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any, Optional
from datetime import datetime

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger
from bid_checker.core.extract_amounts import (
    extract_all_amounts, cn_amount_to_number, num_amount_to_value,
    check_cn_amount_validity, Amount, format_value, values_equal
)
from docx import Document

_logger = get_logger('check_price_consistency')


@dataclass
class PriceCheckItem:
    check_id: str
    check_type: str  # cn_validity / size_consistency / cross_location / subtotal / text_table
    severity: str
    requirement: str
    actual: str
    status: str  # compliant / non_compliant / not_applicable
    evidence: str
    suggestion: Optional[str]
    page_ref: str = ''


@dataclass
class PriceCheckPlan:
    check_id: str
    check_time: str
    total_checks: int
    passed: int
    failed: int
    failures_by_severity: Dict[str, int]
    items: List[PriceCheckItem]
    amount_summary: Dict[str, Any]  # 金额汇总信息


# 位置关键词映射
LOCATION_KEYWORDS = {
    '投标函': ['投标函', '投标书'],
    '投标一览表': ['投标一览表', '开标一览表', '报价一览表'],
    '报价表': ['报价表', '分项报价', '报价清单', '工程量清单'],
    '商务标': ['商务部分', '商务标', '商务文件'],
    '技术标': ['技术部分', '技术标', '技术方案', '技术文件'],
}


def identify_location(text: str, chapter_index: Dict) -> str:
    """根据文本上下文识别所属位置"""
    chapters = chapter_index.get('chapters', [])
    for ch in chapters:
        title = ch.get('title', '')
        for loc_name, keywords in LOCATION_KEYWORDS.items():
            if any(kw in title for kw in keywords):
                return loc_name
    return '其他'


def extract_amounts_from_docx(doc, chapter_index: Dict) -> Dict[str, List[Amount]]:
    """从 docx 中提取金额，按位置分组"""
    by_location = {loc: [] for loc in LOCATION_KEYWORDS.keys()}
    by_location['其他'] = []
    
    # 把段落按章节归类
    paragraphs = list(doc.paragraphs)
    chapter_map = {}  # para_index → location
    current_location = '其他'
    
    chapters = chapter_index.get('chapters', [])
    chapter_starts = sorted([(ch.get('para_index_start', 0), ch) for ch in chapters],
                            key=lambda x: x[0])
    
    for para_idx, para in enumerate(paragraphs):
        # 更新当前章节
        for start_idx, ch in chapter_starts:
            if para_idx >= start_idx:
                title = ch.get('title', '')
                matched = False
                for loc_name, keywords in LOCATION_KEYWORDS.items():
                    if any(kw in title for kw in keywords):
                        current_location = loc_name
                        matched = True
                        break
                if matched:
                    break
        
        # 提取金额
        text = para.text or ''
        if text:
            amounts = extract_all_amounts(text, location_hint=current_location)
            for a in amounts:
                a.location_hint = current_location
                by_location[current_location].append(a)
    
    # 表格中的金额也提取
    for table_idx, table in enumerate(doc.tables):
        for row_idx, row in enumerate(table.rows):
            for cell_idx, cell in enumerate(row.cells):
                text = cell.text or ''
                if text:
                    amounts = extract_all_amounts(text, location_hint=f'表格{table_idx+1}')
                    for a in amounts:
                        by_location['其他'].append(a)
    
    return by_location


def check_cn_amount_validity_in_doc(amounts_by_location: Dict[str, List[Amount]]) -> List[PriceCheckItem]:
    """检查 ① 大写金额合规性"""
    _logger.info('  [价格检查1] 大写金额合规性...')
    items = []
    
    for loc, amounts in amounts_by_location.items():
        for a in amounts:
            if a.amount_type != 'cn_upper':
                continue
            
            is_valid, reason = check_cn_amount_validity(a.raw)
            if is_valid:
                items.append(PriceCheckItem(
                    check_id=f'price_{len(items)+1:03d}',
                    check_type='cn_validity',
                    severity='minor',
                    requirement='大写金额必须使用规范汉字（壹贰叁...拾佰仟万亿）并以"元整"结尾',
                    actual=f'大写金额「{a.raw}」（位置：{loc}）',
                    status='compliant',
                    evidence=f'数值：{format_value(a.value)}',
                    suggestion=None,
                ))
            else:
                items.append(PriceCheckItem(
                    check_id=f'price_{len(items)+1:03d}',
                    check_type='cn_validity',
                    severity='major',
                    requirement='大写金额必须使用规范汉字（壹贰叁...拾佰仟万亿）并以"元整"结尾',
                    actual=f'大写金额「{a.raw}」不合规：{reason}',
                    status='non_compliant',
                    evidence=f'位置：{loc}',
                    suggestion=f'修改为规范大写形式（如"壹佰贰拾万元整"）',
                ))
    
    return items


def check_size_consistency(amounts_by_location: Dict[str, List[Amount]]) -> List[PriceCheckItem]:
    """检查 ② 大小写一致性"""
    _logger.info('  [价格检查2] 大小写一致性...')
    items = []
    
    for loc, amounts in amounts_by_location.items():
        # 同一位置（30字以内）的大写和小写金额应相等
        for i, a1 in enumerate(amounts):
            if a1.amount_type != 'cn_upper':
                continue
            for a2 in amounts[i+1:]:
                if a2.amount_type != 'num':
                    continue
                # 位置接近（30字以内）视为同一处
                if abs(a1.position - a2.position) > 30:
                    continue
                
                if values_equal(a1.value, a2.value):
                    items.append(PriceCheckItem(
                        check_id=f'price_{len(items)+1:03d}',
                        check_type='size_consistency',
                        severity='critical',
                        requirement='同一处的大写金额和小写金额必须相等',
                        actual=f'大写「{a1.raw}」({format_value(a1.value)}) 与 小写「{a2.raw}」({format_value(a2.value)}) 一致',
                        status='compliant',
                        evidence=f'位置：{loc}',
                        suggestion=None,
                    ))
                else:
                    items.append(PriceCheckItem(
                        check_id=f'price_{len(items)+1:03d}',
                        check_type='size_consistency',
                        severity='critical',
                        requirement='同一处的大写金额和小写金额必须相等',
                        actual=f'大写「{a1.raw}」({format_value(a1.value)}) ≠ 小写「{a2.raw}」({format_value(a2.value)})',
                        status='non_compliant',
                        evidence=f'位置：{loc}，差额：{format_value(abs(a1.value-a2.value))}',
                        suggestion='统一大写和小写金额，确保完全一致',
                    ))
    
    return items


def check_cross_location_consistency(amounts_by_location: Dict[str, List[Amount]]) -> List[PriceCheckItem]:
    """检查 ③ 跨位置一致性"""
    _logger.info('  [价格检查3] 跨位置一致性...')
    items = []
    
    # 找出每个位置的"投标总金额"
    # 启发式：取每个位置中数值最大的金额作为"投标总金额"
    location_totals = {}
    for loc, amounts in amounts_by_location.items():
        if not amounts:
            continue
        # 过滤掉小金额（< 1000 元的可能是单价/小项）
        big_amounts = [a for a in amounts if a.value >= 1000]
        if not big_amounts:
            continue
        # 取最大值
        max_amount = max(big_amounts, key=lambda a: a.value)
        location_totals[loc] = max_amount
    
    if not location_totals:
        items.append(PriceCheckItem(
            check_id=f'price_{len(items)+1:03d}',
            check_type='cross_location',
            severity='info',
            requirement='投标总金额应在多处出现且一致',
            actual='未识别到任何位置的投标总金额',
            status='not_applicable',
            evidence='',
            suggestion=None,
        ))
        return items
    
    # 比对所有位置的总金额
    locations = list(location_totals.keys())
    if len(locations) >= 2:
        all_equal = True
        base_value = location_totals[locations[0]].value
        diffs = []
        for loc in locations[1:]:
            other = location_totals[loc]
            if not values_equal(base_value, other.value):
                all_equal = False
                diffs.append(f'{loc}={format_value(other.value)}')
        
        if all_equal:
            items.append(PriceCheckItem(
                check_id=f'price_{len(items)+1:03d}',
                check_type='cross_location',
                severity='critical',
                requirement='投标总金额在投标函/一览表/报价表/商务标/技术标中必须完全一致',
                actual=f'所有位置一致：{format_value(base_value)}',
                status='compliant',
                evidence=f'位置：{", ".join(locations)}',
                suggestion=None,
            ))
        else:
            items.append(PriceCheckItem(
                check_id=f'price_{len(items)+1:03d}',
                check_type='cross_location',
                severity='critical',
                requirement='投标总金额在投标函/一览表/报价表/商务标/技术标中必须完全一致',
                actual=f'不一致：{locations[0]}={format_value(base_value)}，{", ".join(diffs)}',
                status='non_compliant',
                evidence=f'差异金额：{format_value(abs(max(a.value for a in location_totals.values()) - min(a.value for a in location_totals.values())))}',
                suggestion='统一所有位置的投标总金额',
            ))
    else:
        # 只有 1 个位置有金额
        items.append(PriceCheckItem(
            check_id=f'price_{len(items)+1:03d}',
            check_type='cross_location',
            severity='info',
            requirement='投标总金额应在多处出现（投标函/一览表/报价表等）',
            actual=f'仅在 {locations[0]} 找到投标总金额',
            status='not_applicable',
            evidence=f'金额：{format_value(location_totals[locations[0]].value)}',
            suggestion='检查其他位置是否漏写投标总金额',
        ))
    
    return items


def check_subtotal_in_tables(doc) -> List[PriceCheckItem]:
    """检查 ④ 分项合计校验（标书内表格）"""
    _logger.info('  [价格检查4] 分项合计校验（标书内表格）...')
    items = []
    
    for table_idx, table in enumerate(doc.tables):
        # 检测是否为报价表（包含"单价"/"数量"/"小计"/"合计"等表头）
        if len(table.rows) < 2:
            continue
        
        header_row = table.rows[0]
        header_text = ' '.join(cell.text or '' for cell in header_row.cells)
        
        # 检测报价表特征
        has_price_keywords = any(kw in header_text for kw in ['单价', '数量', '小计', '合计', '金额', '总价'])
        if not has_price_keywords:
            continue
        
        # 识别列索引
        headers = [cell.text or '' for cell in header_row.cells]
        col_map = {}
        for i, h in enumerate(headers):
            h_clean = h.strip()
            if '单价' in h_clean:
                col_map['unit_price'] = i
            elif '数量' in h_clean:
                col_map['quantity'] = i
            elif '小计' in h_clean or '金额' in h_clean:
                col_map['subtotal'] = i
            elif '合计' in h_clean or '总价' in h_clean:
                col_map['total'] = i
        
        # 如果有单价×数量=小计，做校验
        if 'unit_price' in col_map and 'quantity' in col_map and 'subtotal' in col_map:
            for row_idx, row in enumerate(table.rows[1:], 1):  # 跳过表头
                cells = [cell.text or '' for cell in row.cells]
                unit_price_text = cells[col_map['unit_price']] if col_map['unit_price'] < len(cells) else ''
                quantity_text = cells[col_map['quantity']] if col_map['quantity'] < len(cells) else ''
                subtotal_text = cells[col_map['subtotal']] if col_map['subtotal'] < len(cells) else ''
                
                # 解析数值
                unit_price = parse_cell_number(unit_price_text)
                quantity = parse_cell_number(quantity_text)
                subtotal = parse_cell_number(subtotal_text)
                
                if unit_price is None or quantity is None or subtotal is None:
                    continue
                
                expected = unit_price * quantity
                if values_equal(expected, subtotal, tolerance=0.1):
                    items.append(PriceCheckItem(
                        check_id=f'price_{len(items)+1:03d}',
                        check_type='subtotal',
                        severity='critical',
                        requirement=f'表格{table_idx+1}第{row_idx+1}行：单价 × 数量 = 小计',
                        actual=f'{unit_price} × {quantity} = {subtotal}（正确）',
                        status='compliant',
                        evidence=f'表{table_idx+1}行{row_idx+1}',
                        suggestion=None,
                    ))
                else:
                    items.append(PriceCheckItem(
                        check_id=f'price_{len(items)+1:03d}',
                        check_type='subtotal',
                        severity='critical',
                        requirement=f'表格{table_idx+1}第{row_idx+1}行：单价 × 数量 = 小计',
                        actual=f'{unit_price} × {quantity} = {expected} ≠ {subtotal}（小计）',
                        status='non_compliant',
                        evidence=f'表{table_idx+1}行{row_idx+1}，差额：{abs(expected-subtotal)}',
                        suggestion=f'修正小计为 {expected}',
                    ))
        
        # 检查小计之和 = 合计
        if 'subtotal' in col_map:
            subtotals = []
            for row in table.rows[1:]:
                cells = [cell.text or '' for cell in row.cells]
                if col_map['subtotal'] < len(cells):
                    v = parse_cell_number(cells[col_map['subtotal']])
                    if v is not None:
                        subtotals.append(v)
            
            if subtotals:
                sum_subtotals = sum(subtotals)
                
                # 找合计
                if 'total' in col_map:
                    # 合计通常在最后一行
                    total = None
                    for row in reversed(table.rows):
                        cells = [cell.text or '' for cell in row.cells]
                        if col_map['total'] < len(cells):
                            v = parse_cell_number(cells[col_map['total']])
                            if v is not None:
                                total = v
                                break
                    
                    if total is not None:
                        if values_equal(sum_subtotals, total, tolerance=1.0):
                            items.append(PriceCheckItem(
                                check_id=f'price_{len(items)+1:03d}',
                                check_type='subtotal',
                                severity='critical',
                                requirement=f'表格{table_idx+1}：分项小计之和 = 合计',
                                actual=f'小计之和 {sum_subtotals} = 合计 {total}（正确）',
                                status='compliant',
                                evidence=f'表{table_idx+1}',
                                suggestion=None,
                            ))
                        else:
                            items.append(PriceCheckItem(
                                check_id=f'price_{len(items)+1:03d}',
                                check_type='subtotal',
                                severity='critical',
                                requirement=f'表格{table_idx+1}：分项小计之和 = 合计',
                                actual=f'小计之和 {sum_subtotals} ≠ 合计 {total}',
                                status='non_compliant',
                                evidence=f'表{table_idx+1}，差额：{abs(sum_subtotals-total)}',
                                suggestion=f'修正合计为 {sum_subtotals}',
                            ))
    
    if not items:
        items.append(PriceCheckItem(
            check_id=f'price_{len(items)+1:03d}',
            check_type='subtotal',
            severity='info',
            requirement='报价表分项合计校验',
            actual='未识别到报价表（含单价/数量/小计列的表格）',
            status='not_applicable',
            evidence='',
            suggestion=None,
        ))
    
    return items


def check_subtotal_in_xlsx(xlsx_path: str) -> List[PriceCheckItem]:
    """检查 ④ 分项合计校验（Excel 报价表）"""
    _logger.info(f'  [价格检查4-Excel] 解析 Excel 报价表：{xlsx_path}')
    items = []
    
    try:
        from openpyxl import load_workbook
        wb = load_workbook(xlsx_path, data_only=True)
    except ImportError:
        _logger.warning('    openpyxl 未安装，跳过 Excel 检查')
        items.append(PriceCheckItem(
            check_id=f'price_{len(items)+1:03d}',
            check_type='subtotal',
            severity='info',
            requirement='Excel 报价表分项合计校验',
            actual='openpyxl 未安装，跳过 Excel 检查',
            status='not_applicable',
            evidence='',
            suggestion='安装 openpyxl: pip install openpyxl',
        ))
        return items
    except Exception as e:
        _logger.warning(f'    Excel 解析失败：{e}')
        items.append(PriceCheckItem(
            check_id=f'price_{len(items)+1:03d}',
            check_type='subtotal',
            severity='info',
            requirement='Excel 报价表分项合计校验',
            actual=f'Excel 解析失败：{e}',
            status='not_applicable',
            evidence='',
            suggestion=None,
        ))
        return items
    
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        _logger.info(f'    处理工作表：{sheet_name}（{ws.max_row} 行 × {ws.max_column} 列）')
        
        # 找表头行（含"单价"/"数量"/"小计"等关键词的行）
        header_row_idx = None
        col_map = {}
        for row_idx in range(1, min(ws.max_row + 1, 20)):  # 前 20 行内找表头
            row_values = [str(ws.cell(row=row_idx, column=c).value or '') for c in range(1, ws.max_column + 1)]
            header_text = ' '.join(row_values)
            if any(kw in header_text for kw in ['单价', '数量', '小计', '合计', '金额', '总价']):
                header_row_idx = row_idx
                for i, h in enumerate(row_values):
                    h_clean = h.strip()
                    if '单价' in h_clean:
                        col_map['unit_price'] = i + 1
                    elif '数量' in h_clean:
                        col_map['quantity'] = i + 1
                    elif '小计' in h_clean or '金额' in h_clean:
                        col_map['subtotal'] = i + 1
                    elif '合计' in h_clean or '总价' in h_clean:
                        col_map['total'] = i + 1
                break
        
        if not header_row_idx:
            continue
        
        # 检查单价 × 数量 = 小计
        if 'unit_price' in col_map and 'quantity' in col_map and 'subtotal' in col_map:
            for row_idx in range(header_row_idx + 1, ws.max_row + 1):
                unit_price = ws.cell(row=row_idx, column=col_map['unit_price']).value
                quantity = ws.cell(row=row_idx, column=col_map['quantity']).value
                subtotal = ws.cell(row=row_idx, column=col_map['subtotal']).value
                
                if not isinstance(unit_price, (int, float)) or not isinstance(quantity, (int, float)) or not isinstance(subtotal, (int, float)):
                    continue
                
                expected = unit_price * quantity
                if not values_equal(expected, subtotal, tolerance=0.1):
                    items.append(PriceCheckItem(
                        check_id=f'price_{len(items)+1:03d}',
                        check_type='subtotal',
                        severity='critical',
                        requirement=f'Excel[{sheet_name}]行{row_idx}：单价 × 数量 = 小计',
                        actual=f'{unit_price} × {quantity} = {expected} ≠ {subtotal}（小计）',
                        status='non_compliant',
                        evidence=f'工作表{sheet_name}行{row_idx}',
                        suggestion=f'修正小计为 {expected}',
                    ))
        
        # 检查小计之和 = 合计
        if 'subtotal' in col_map:
            subtotals = []
            for row_idx in range(header_row_idx + 1, ws.max_row + 1):
                v = ws.cell(row=row_idx, column=col_map['subtotal']).value
                if isinstance(v, (int, float)):
                    subtotals.append(v)
            
            if subtotals:
                sum_sub = sum(subtotals)
                # 找合计（最后一行的 total 列）
                if 'total' in col_map:
                    total = None
                    for row_idx in range(ws.max_row, header_row_idx, -1):
                        v = ws.cell(row=row_idx, column=col_map['total']).value
                        if isinstance(v, (int, float)):
                            total = v
                            break
                    
                    if total is not None and not values_equal(sum_sub, total, tolerance=1.0):
                        items.append(PriceCheckItem(
                            check_id=f'price_{len(items)+1:03d}',
                            check_type='subtotal',
                            severity='critical',
                            requirement=f'Excel[{sheet_name}]：分项小计之和 = 合计',
                            actual=f'小计之和 {sum_sub} ≠ 合计 {total}',
                            status='non_compliant',
                            evidence=f'工作表{sheet_name}，差额：{abs(sum_sub-total)}',
                            suggestion=f'修正合计为 {sum_sub}',
                        ))
    
    if not items:
        items.append(PriceCheckItem(
            check_id=f'price_{len(items)+1:03d}',
            check_type='subtotal',
            severity='info',
            requirement='Excel 报价表分项合计校验',
            actual='Excel 中未识别到报价表',
            status='not_applicable',
            evidence='',
            suggestion=None,
        ))
    
    return items


def parse_cell_number(text: str) -> Optional[float]:
    """从表格单元格文本中解析数值"""
    if not text:
        return None
    text = str(text).strip()
    # 移除货币符号和千分位
    text = re.sub(r'[￥¥人民币元整,，]', '', text)
    text = text.strip()
    try:
        return float(text)
    except ValueError:
        return None


def check_text_table_consistency(doc, amounts_by_location: Dict[str, List[Amount]]) -> List[PriceCheckItem]:
    """检查 ⑤ 文字-表格一致性"""
    _logger.info('  [价格检查5] 文字-表格一致性...')
    items = []
    
    # 收集正文文字描述的金额（来自段落，非表格）
    para_amounts = []
    # 重新提取（已包含 location_hint）
    for para in doc.paragraphs:
        text = para.text or ''
        if text:
            for a in extract_all_amounts(text):
                para_amounts.append(a)
    
    # 收集表格中的金额
    table_amounts = []
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                text = cell.text or ''
                if text:
                    for a in extract_all_amounts(text):
                        table_amounts.append(a)
    
    # 找出正文中"投标报价/总报价/投标总金额"等关键词后的金额
    keyword_pattern = re.compile(r'(?:投标报价|总报价|投标总金额|投标金额|总金额|报价总额)\s*[为是：:]\s*([0-9,]+(?:\.[0-9]+)?(?:万元?|元|亿元))')
    
    text_values = []
    for para in doc.paragraphs:
        text = para.text or ''
        for match in keyword_pattern.finditer(text):
            v = num_amount_to_value(match.group(1))
            if v is not None:
                text_values.append({
                    'value': v,
                    'raw': match.group(1),
                    'context': text[max(0, match.start()-20):match.end()+20],
                })
    
    # 找出表格中最大的金额（视为总价）
    table_max = max((a.value for a in table_amounts), default=None)
    
    if text_values and table_max is not None:
        all_consistent = True
        for tv in text_values:
            if not values_equal(tv['value'], table_max, tolerance=1.0):
                all_consistent = False
                items.append(PriceCheckItem(
                    check_id=f'price_{len(items)+1:03d}',
                    check_type='text_table',
                    severity='critical',
                    requirement='正文文字描述的金额应与表格中的金额一致',
                    actual=f'正文"{tv["raw"]}"({format_value(tv["value"])}) ≠ 表格最大金额({format_value(table_max)})',
                    status='non_compliant',
                    evidence=f'正文上下文："{tv["context"]}"',
                    suggestion='统一正文与表格中的金额',
                ))
        
        if all_consistent:
            items.append(PriceCheckItem(
                check_id=f'price_{len(items)+1:03d}',
                check_type='text_table',
                severity='critical',
                requirement='正文文字描述的金额应与表格中的金额一致',
                actual=f'一致：{format_value(table_max)}',
                status='compliant',
                evidence='',
                suggestion=None,
            ))
    elif not text_values:
        items.append(PriceCheckItem(
            check_id=f'price_{len(items)+1:03d}',
            check_type='text_table',
            severity='info',
            requirement='正文文字描述的金额应与表格中的金额一致',
            actual='正文中未找到"投标报价/总报价"等关键词',
            status='not_applicable',
            evidence='',
            suggestion=None,
        ))
    elif table_max is None:
        items.append(PriceCheckItem(
            check_id=f'price_{len(items)+1:03d}',
            check_type='text_table',
            severity='info',
            requirement='正文文字描述的金额应与表格中的金额一致',
            actual='表格中未找到任何金额',
            status='not_applicable',
            evidence='',
            suggestion=None,
        ))
    
    return items


def main():
    parser = argparse.ArgumentParser(description='Stage 5.5.1: 价格分一致性检查')
    parser.add_argument('--docx', required=True, help='标书 .docx 路径')
    parser.add_argument('--chapter-index', required=True, help='章节索引 JSON')
    parser.add_argument('--requirements', help='招标要求清单 JSON（可选）')
    parser.add_argument('--xlsx', help='报价表 xlsx 路径（可选）')
    parser.add_argument('--output', required=True, help='输出价格检查 Plan JSON')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取章节索引：{args.chapter_index}')
    with open(args.chapter_index, 'r', encoding='utf-8') as f:
        chapter_index = json.load(f)

    _logger.info(f'读取标书：{args.docx}')
    doc = Document(args.docx)

    # 提取所有金额
    _logger.info('提取标书中所有金额...')
    amounts_by_location = extract_amounts_from_docx(doc, chapter_index)
    for loc, amounts in amounts_by_location.items():
        if amounts:
            _logger.info(f'  {loc}: {len(amounts)} 个金额')

    # 执行 5 项检查
    all_items = []
    _logger.info('开始执行价格分 5 项检查...')

    all_items.extend(check_cn_amount_validity_in_doc(amounts_by_location))
    all_items.extend(check_size_consistency(amounts_by_location))
    all_items.extend(check_cross_location_consistency(amounts_by_location))
    all_items.extend(check_subtotal_in_tables(doc))
    all_items.extend(check_text_table_consistency(doc, amounts_by_location))

    # Excel 报价表检查
    if args.xlsx:
        all_items.extend(check_subtotal_in_xlsx(args.xlsx))

    # 统计
    total = len(all_items)
    passed = sum(1 for it in all_items if it.status == 'compliant')
    failed = sum(1 for it in all_items if it.status == 'non_compliant')

    failures_by_severity = {
        'critical': sum(1 for it in all_items if it.status == 'non_compliant' and it.severity == 'critical'),
        'major': sum(1 for it in all_items if it.status == 'non_compliant' and it.severity == 'major'),
        'minor': sum(1 for it in all_items if it.status == 'non_compliant' and it.severity == 'minor'),
        'info': sum(1 for it in all_items if it.status == 'non_compliant' and it.severity == 'info'),
    }

    # 金额汇总
    all_amounts = []
    for loc, amounts in amounts_by_location.items():
        for a in amounts:
            all_amounts.append({
                'raw': a.raw,
                'value': a.value,
                'location': loc,
                'type': a.amount_type,
            })
    amount_summary = {
        'total_amounts': len(all_amounts),
        'by_location': {loc: len(amts) for loc, amts in amounts_by_location.items() if amts},
        'max_value': max((a['value'] for a in all_amounts), default=0),
        'all_amounts': all_amounts[:50],  # 限制输出
    }

    plan = PriceCheckPlan(
        check_id=f'price_{datetime.now().strftime("%Y%m%d_%H%M%S")}',
        check_time=datetime.now().isoformat(),
        total_checks=total,
        passed=passed,
        failed=failed,
        failures_by_severity=failures_by_severity,
        items=all_items,
        amount_summary=amount_summary,
    )

    output = asdict(plan)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')
    _logger.info(f'  总检查项：{total}')
    _logger.info(f'  通过：{passed}')
    _logger.info(f'  不合规：{failed}')
    _logger.info(f'  按严重度：{failures_by_severity}')


if __name__ == '__main__':
    main()
