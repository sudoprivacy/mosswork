#!/usr/bin/env python3
"""
Stage 2.4: 建立关键词倒排索引
对章节全文建立关键词倒排索引，用于评分项驱动精读的"关键词精筛"。

输入：{项目名}_标书章节索引.json
输出：{项目名}_标书关键词索引.json
"""
import argparse
import json
import re
import sys
from pathlib import Path
from collections import defaultdict, Counter
from typing import List, Dict

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from bid_checker.utils.logger import get_logger

_logger = get_logger('build_keyword_index')

# 停用词
STOP_WORDS = {
    '的', '了', '和', '是', '在', '我', '有', '与', '及', '或', '等',
    '为', '以', '于', '到', '从', '对', '按', '据', '将', '被', '让',
    '使', '由', '向', '往', '供', '需', '应', '可', '能', '会',
    '本', '该', '此', '其', '之', '所', '者', '们', '你', '他',
    '一', '二', '三', '四', '五', '六', '七', '八', '九', '十',
    '个', '中', '上', '下', '内', '外', '前', '后', '间', '时',
    '并', '且', '但', '而', '则', '即', '若', '如', '虽', '因',
    '这', '那', '些', '么', '也', '都', '还', '已', '正', '将',
    '不', '无', '未', '非', '别', '莫', '勿', '再', '只', '仅',
}

# 标书领域关键词（这些词即使短也保留）
DOMAIN_KEYWORDS = {
    '投标', '招标', '评标', '中标', '废标', '投标函', '投标书',
    '授权', '委托', '法人', '代表', '印章', '公章', '签字',
    '资质', '资格', '营业执照', '身份证', '证书',
    '报价', '金额', '总价', '单价', '币种',
    '技术', '方案', '实施', '部署', '运维', '售后',
    '工期', '交货', '质保', '保修',
    '偏离', '响应', '符合', '满足',
    '商务', '财务', '审计', '纳税', '社保',
    '业绩', '案例', '项目',
}


def is_chinese(ch):
    return '\u4e00' <= ch <= '\u9fff'


def extract_keywords(text: str) -> Counter:
    """从文本中提取关键词（中文 2-4 字组合）"""
    if not text:
        return Counter()

    # 移除标点和空白
    cleaned = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9]+', ' ', text)
    tokens = cleaned.split()

    keywords = Counter()
    for token in tokens:
        # 中文 token：提取 2-4 字组合
        if any(is_chinese(c) for c in token):
            # 提取 2-4 字的中文子串
            chinese_only = ''.join(c for c in token if is_chinese(c))
            for length in (2, 3, 4):
                for i in range(len(chinese_only) - length + 1):
                    word = chinese_only[i:i+length]
                    if word not in STOP_WORDS or word in DOMAIN_KEYWORDS:
                        keywords[word] += 1
        else:
            # 英文/数字 token
            if token.lower() not in STOP_WORDS and len(token) >= 2:
                keywords[token.lower()] += 1

    return keywords


def build_index(chapters: List[Dict]) -> Dict[str, List[str]]:
    """构建倒排索引：keyword -> [chapter_id, chapter_id, ...]"""
    inverted = defaultdict(set)

    for ch in chapters:
        ch_id = ch['chapter_id']
        # 章节标题也作为关键词
        title_keywords = extract_keywords(ch.get('title', ''))
        for kw in title_keywords:
            inverted[kw].add(ch_id)

        # 章节全文关键词
        text_keywords = extract_keywords(ch.get('full_text', ''))
        # 只保留出现 ≥2 次的关键词（避免噪音）
        for kw, count in text_keywords.items():
            if count >= 2:
                inverted[kw].add(ch_id)

    # 转换 set 为 list
    return {kw: sorted(list(ch_ids)) for kw, ch_ids in inverted.items()}


def main():
    parser = argparse.ArgumentParser(description='Stage 2.4: 建立关键词倒排索引')
    parser.add_argument('--input', required=True, help='章节索引 JSON 路径')
    parser.add_argument('--output', required=True, help='输出关键词索引 JSON 路径')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    _logger.info(f'读取章节索引：{args.input}')
    with open(args.input, 'r', encoding='utf-8') as f:
        chapter_data = json.load(f)

    chapters = chapter_data.get('chapters', [])
    _logger.info(f'  章节数：{len(chapters)}')

    index = build_index(chapters)

    # 统计
    _logger.info(f'  关键词总数：{len(index)}')

    # 输出
    output = {
        'total_keywords': len(index),
        'total_chapters': len(chapters),
        'index': index,
    }

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    _logger.info(f'✅ 已生成：{args.output}')


if __name__ == '__main__':
    main()
