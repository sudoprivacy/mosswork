#!/usr/bin/env python3
"""
资料深度扫描器 (Material Deep Scanner)
======================================
功能：对项目资料文件夹中的所有文件进行深度扫描，建立精确的章节树。
支持：docx/pdf/xlsx/图片
输出：统一的结构化资料清单JSON

v8.1: 已验证无图片数量截断限制

核心改进（相比 material_scanner_v2.py）：
1. 标题检测算法建立完整章节树（序号格式→关键词→样式级别）
2. 按章节边界精确切割内容（非关键词模糊匹配）
3. 每个章节标记内容类型（text_only / image_only / mixed）
4. 同时收集文本内容和图片文件列表

v8.1: 已验证无图片数量截断限制（旧版 images[:10] 截断已移除）
"""

import os
import sys
import re
import json
import zipfile
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from collections import OrderedDict
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Tuple, Any


# ============================================================================
# 数据结构
# ============================================================================

@dataclass
class ImageInfo:
    """图片信息"""
    filename: str          # 文件名（如 image1.jpeg）
    rId: str               # 关系ID
    para_index: int        # 所在段落索引
    width_px: int = 0
    height_px: int = 0


# v9.0: 统一日志
try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.material_scanner")
except ImportError:
    import logging
    _logger = logging.getLogger("material_scanner")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)

@dataclass
class MaterialSection:
    """资料章节"""
    section_id: int                       # 全局唯一ID
    heading: str                          # 标题文本
    heading_para_index: int               # 标题所在段落索引
    para_start: int                       # 起始段落索引（包含）
    para_end: int                         # 结束段落索引（不包含）
    content_type: str                     # text_only / image_only / mixed
    text_content: Optional[str] = None    # 文本内容（去重合并）
    images: List[str] = field(default_factory=list)      # 图片文件名列表
    image_count: int = 0
    source_file: str = ""                 # 来源文件名
    raw_paragraphs: List[Dict] = field(default_factory=list)  # 原始段落数据
    ocr_text: Optional[str] = None         # v8.1: 图片OCR识别文本（image_only章节或独立图片）
    ocr_images: Dict[str, str] = field(default_factory=dict)  # v8.1: {图片文件名: OCR文本}


@dataclass
class MaterialFileReport:
    """单个文件的扫描报告"""
    file_path: str
    file_name: str
    file_type: str                        # docx / pdf / xlsx / image
    sections: List[MaterialSection] = field(default_factory=list)
    total_images: int = 0
    total_sections: int = 0
    errors: List[str] = field(default_factory=list)


# ============================================================================
# 标题检测引擎
# ============================================================================

# 可在任何位置触发的小标题关键词（不限长度，且永不合并到其他标题）
HEADING_KEYWORDS_ANYLEN = [
    '营业执照',
    '信用中国',
    '税收缴纳证明',
    '社会保障资金缴纳证明',
    '财务状况报告',
    '非联合体投标声明',
    '法定代表人（签字或盖章）',
    '业绩案例',
]

# 需在短文本中触发的小标题关键词（≤30字符）
HEADING_KEYWORDS_SHORT = [
    '财务状况报告', '税收缴纳证明', '社会保障资金', '身份证明',
    '法定代表人身份证明', '法定代表人授权书', '法定代表人',
    '非联合体投标声明', '非联合体投标', '联合体投标',
    '信用信息证明', '未列入重大税收违法失信主体',
    '履行合同所必需的设备和专业技术能力',
    '设备和专业技术能力的说明', '设备和专业技术能力',
    '无重大违法记录', '控股关系',
    '授权委托书', '书面声明', '承诺书',
    '完税证明', '纳税证明', '社保', '财务审计',
    '基本存款账户', '资信证明', '声明', '承诺',
    '业绩案例', '采购项目', '项目案例', '类似项目', '项目业绩',
    '未列入失信执行人证明', '未列入严重失信主体名单证明',
    '法人和非法人组织公共信用信息报告',
]

# 标题序号正则（仅当短文本时有效）
HEADING_NUM_PATTERNS = [
    re.compile(r'^\s*(\d+)\s*[\.\s、)]'),             # 1.  1、  1) 
    re.compile(r'^\s*[(（]\s*(\d+)\s*[)）]'),          # (1) （1）
    re.compile(r'^\s*[一二三四五六七八九十]+\s*[、\s]'),  # 一、 一 
]


def is_heading_paragraph(text: str, para_index: int) -> Tuple[bool, Optional[str]]:
    """
    判断段落是否为小标题。
    
    规则（按优先级）：
    1. 包含 H1 级关键词（营业执照、信用中国）→ 不限长度，必定是标题
    2. 短文本（≤30字符）+ 序号格式开头 → 标题
    3. 短文本（≤30字符）+ 包含标题关键词 → 标题
    4. 中等长度（≤60字符）+ 包含重要关键词 → 标题
    
    返回: (is_heading, matched_keyword)
    """
    text = text.strip()
    if not text:
        return False, None
    
    # 规则1：H1级关键词，不限长度
    for kw in HEADING_KEYWORDS_ANYLEN:
        if kw in text and len(text) < 100:
            return True, kw
    
    # 规则2：短文本 + 序号格式
    if len(text) <= 30:
        for pattern in HEADING_NUM_PATTERNS:
            if pattern.match(text):
                return True, text[:20]
    
    # 规则3：短文本（≤30字符）+ 标题关键词
    if len(text) <= 30:
        for kw in HEADING_KEYWORDS_SHORT:
            if kw in text:
                # 排除"附：XXX"这种段落
                if not text.startswith('附') and not text.startswith('注'):
                    return True, kw
    
    # 规则4：中等长度（≤60字符）+ 重要关键词
    if len(text) <= 60:
        important_kws = ['法定代表人身份证明', '法定代表人授权书', 
                         '非联合体投标声明', '设备和专业技术能力',
                         '财务状况报告', '税收缴纳证明']
        for kw in important_kws:
            if kw in text and not text.startswith(('附', '注', '我公司', '供应商')):
                return True, kw
    
    return False, None


def merge_close_headings(headings: List[Dict]) -> List[Dict]:
    """
    合并距离过近的小标题（同一级标题拆成了多行）。
    
    合并条件（全部满足才合并）：
    1. 相邻标题间距 ≤ 3段
    2. 后一个标题不包含任何 H1 关键词（永不合并独立章节）
    3. 后一个标题看起来像是前一个的后缀/说明（不以"H1关键词"独立开头）
    """
    if len(headings) <= 1:
        return headings
    
    merged = []
    i = 0
    while i < len(headings):
        current = headings[i]
        
        # 看后续标题是否需要合并
        while i + 1 < len(headings):
            next_h = headings[i + 1]
            gap = next_h['para_index'] - current['para_index']
            
            # 条件1: 间距 ≤ 3
            if gap > 3:
                break
            
            # 条件2: 后置标题不是 H1 级独立章节
            is_h1 = any(kw in next_h['text'] for kw in HEADING_KEYWORDS_ANYLEN)
            if is_h1:
                break
            
            # 条件3: 后置标题看起来像前缀（如序号、括号子项）
            next_text = next_h['text'].strip()
            is_sub_item = (
                (next_text.startswith('（') or next_text.startswith('(')) and
                (next_text.endswith('）') or next_text.endswith(')'))
            ) or re.match(r'^\d+[\.\s、)]', next_text)
            
            if is_sub_item:
                # 合并：跳过当前，到下一个
                i += 1
                continue
            else:
                break
        
        merged.append(current)
        i += 1
    
    return merged


def extract_sections_from_docx(file_path: str) -> MaterialFileReport:
    """
    从 Word 文档提取章节结构。
    
    流程：
    1. 遍历段落，检测所有小标题
    2. 合并过近的标题
    3. 按标题边界切分章节
    4. 每个章节统计文本和图片
    """
    from docx import Document
    
    report = MaterialFileReport(
        file_path=file_path,
        file_name=os.path.basename(file_path),
        file_type='docx'
    )
    
    try:
        doc = Document(file_path)
    except Exception as e:
        report.errors.append(f"无法打开文档: {e}")
        return report
    
    # ── Step 1: 检测所有标题 ──
    raw_headings = []
    for pi, para in enumerate(doc.paragraphs):
        text = para.text.strip()
        is_h, matched_kw = is_heading_paragraph(text, pi)
        if is_h:
            raw_headings.append({
                'para_index': pi,
                'text': text,
                'matched_keyword': matched_kw
            })
    
    # ── Step 2: 合并过近标题 ──
    headings = merge_close_headings(raw_headings)
    
    # ── Step 3: 提取图片映射 ──
    rId_to_file = _extract_image_mapping(file_path)
    
    # 为每个段落建立图片列表
    para_images = {}  # pi -> [filenames]
    for pi, para in enumerate(doc.paragraphs):
        imgs = _get_para_images(para, rId_to_file)
        if imgs:
            para_images[pi] = imgs
    
    # ── Step 4: 按标题边界切分章节 ──
    total_imgs_before = 0
    sections = []
    
    for i, h in enumerate(headings):
        start_pi = h['para_index']
        end_pi = headings[i + 1]['para_index'] if i + 1 < len(headings) else len(doc.paragraphs)
        heading_text = h['text']
        
        # 收集章节内图片（跨段落去重，保持出现顺序）
        section_images = []
        section_images_seen = set()
        section_text_parts = []
        section_raw_paras = []
        
        for pi in range(start_pi, min(end_pi, len(doc.paragraphs))):
            para = doc.paragraphs[pi]
            text = para.text.strip()
            
            # 收集图片（去重）
            if pi in para_images:
                for img in para_images[pi]:
                    if img not in section_images_seen:
                        section_images_seen.add(img)
                        section_images.append(img)
            
            # 收集文本（排除标题段落和空段落）
            if pi > start_pi and text:
                section_text_parts.append(text)
            
            # 保存原始段落（用于后续精确复制）
            section_raw_paras.append({
                'pi': pi,
                'text': text,
                'has_image': pi in para_images,
            })
        
        # 判定内容类型
        has_text = len(section_text_parts) > 0
        has_images = len(section_images) > 0
        
        if has_text and has_images:
            content_type = 'mixed'
        elif has_images:
            content_type = 'image_only'
        elif has_text:
            content_type = 'text_only'
        else:
            content_type = 'empty'
        
        # 合并文本
        text_content = '\n'.join(section_text_parts) if section_text_parts else None
        
        section_id = i + 1
        sections.append(MaterialSection(
            section_id=section_id,
            heading=heading_text,
            heading_para_index=start_pi,
            para_start=start_pi,
            para_end=end_pi,
            content_type=content_type,
            text_content=text_content,
            images=section_images,
            image_count=len(section_images),
            source_file=report.file_name,
            raw_paragraphs=section_raw_paras,
        ))
    
    # ── Fallback: 无标题文档处理 ──
    # 当文档无任何检测到的标题，但有内容时，创建一个"整体文档"章节
    if len(sections) == 0 and len(doc.paragraphs) > 0:
        has_any_text = False
        all_images = []
        all_seen = set()
        all_text_parts = []
        
        for pi, para in enumerate(doc.paragraphs):
            text = para.text.strip()
            if text:
                has_any_text = True
                all_text_parts.append(text)
            if pi in para_images:
                for img in para_images[pi]:
                    if img not in all_seen:
                        all_seen.add(img)
                        all_images.append(img)
        
        if has_any_text or all_images:
            content_type = 'mixed' if (has_any_text and all_images) else ('text_only' if has_any_text else 'image_only')
            text_content = '\n'.join(all_text_parts) if all_text_parts else None
            sections.append(MaterialSection(
                section_id=1,
                heading=os.path.splitext(report.file_name)[0],
                heading_para_index=0,
                para_start=0,
                para_end=len(doc.paragraphs),
                content_type=content_type,
                text_content=text_content,
                images=all_images,
                image_count=len(all_images),
                source_file=report.file_name,
            ))
    
    report.sections = sections
    report.total_sections = len(sections)
    report.total_images = sum(s.image_count for s in sections)
    
    return report


def _extract_image_mapping(docx_path: str) -> Dict[str, str]:
    """从 docx 提取 rId → 文件名的映射"""
    mapping = {}
    try:
        with zipfile.ZipFile(docx_path) as z:
            rels_xml = z.read('word/_rels/document.xml.rels')
            tree = ET.fromstring(rels_xml)
            for rel in tree:
                rId = rel.get('Id', '')
                target = rel.get('Target', '')
                if 'image' in target.lower() or 'media' in target.lower():
                    mapping[rId] = os.path.basename(target)
    except Exception:
        pass
    return mapping


def _get_para_images(para, rId_to_file: Dict[str, str]) -> List[str]:
    """获取段落中包含的图片文件名列表（已去重，保持出现顺序）"""
    W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    
    images = []
    seen = set()
    for blip in para._element.iter(f'{{{A_NS}}}blip'):
        embed = blip.get(f'{{{R_NS}}}embed')
        if embed and embed in rId_to_file:
            fname = rId_to_file[embed]
            if fname not in seen:
                seen.add(fname)
                images.append(fname)
    return images


# ============================================================================
# PDF 扫描
# ============================================================================

def extract_sections_from_pdf(file_path: str) -> MaterialFileReport:
    """从 PDF 提取章节结构（基础版：按页面组织）"""
    report = MaterialFileReport(
        file_path=file_path,
        file_name=os.path.basename(file_path),
        file_type='pdf'
    )
    
    try:
        import fitz  # PyMuPDF
        pdf = fitz.open(file_path)
        
        for page_num in range(len(pdf)):
            page = pdf[page_num]
            text = page.get_text().strip()
            if text:
                # 尝试检测标题
                first_line = text.split('\n')[0].strip()
                is_h, _ = is_heading_paragraph(first_line, page_num)
                
                heading = first_line if is_h else f"PDF 第{page_num+1}页"
                
                sections = [
                    MaterialSection(
                        section_id=page_num + 1,
                        heading=heading,
                        heading_para_index=page_num,
                        para_start=page_num,
                        para_end=page_num + 1,
                        content_type='text_only',
                        text_content=text[:5000],
                        images=[],
                        image_count=0,
                        source_file=report.file_name,
                    )
                ]
                report.sections.extend(sections)
        
        pdf.close()
    except ImportError:
        # 降级：用 PyPDF2 或 pdfplumber
        try:
            import PyPDF2
            with open(file_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page_num, page in enumerate(reader.pages):
                    text = page.extract_text() or ''
                    if text.strip():
                        report.sections.append(MaterialSection(
                            section_id=page_num + 1,
                            heading=f"PDF 第{page_num+1}页",
                            heading_para_index=page_num,
                            para_start=page_num,
                            para_end=page_num + 1,
                            content_type='text_only',
                            text_content=text[:5000],
                            source_file=report.file_name,
                        ))
        except ImportError:
            report.errors.append('PDF解析需要安装 PyMuPDF 或 PyPDF2')
        except Exception as e:
            report.errors.append(f'PDF解析失败: {e}')
    except Exception as e:
        report.errors.append(f'PDF解析失败: {e}')
    
    report.total_sections = len(report.sections)
    return report


# ============================================================================
# Excel 扫描
# ============================================================================

def extract_sections_from_xlsx(file_path: str) -> MaterialFileReport:
    """从 Excel 提取数据（按 sheet 组织）"""
    report = MaterialFileReport(
        file_path=file_path,
        file_name=os.path.basename(file_path),
        file_type='xlsx'
    )
    
    try:
        import openpyxl
        wb = openpyxl.load_workbook(file_path, data_only=True)
        
        for sid, sheet_name in enumerate(wb.sheetnames):
            ws = wb[sheet_name]
            
            # 提取表格文本
            rows = []
            for row in ws.iter_rows(values_only=True):
                row_text = '\t'.join(str(c) if c is not None else '' for c in row)
                if row_text.strip():
                    rows.append(row_text)
            
            text_content = '\n'.join(rows)
            
            report.sections.append(MaterialSection(
                section_id=sid + 1,
                heading=f"Sheet: {sheet_name}",
                heading_para_index=sid,
                para_start=sid,
                para_end=sid + 1,
                content_type='text_only' if text_content.strip() else 'empty',
                text_content=text_content[:5000],
                source_file=report.file_name,
            ))
        
        wb.close()
    except ImportError:
        report.errors.append('Excel解析需要安装 openpyxl')
    except Exception as e:
        report.errors.append(f'Excel解析失败: {e}')
    
    report.total_sections = len(report.sections)
    return report


# ============================================================================
# 图片文件扫描
# ============================================================================

IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff', '.webp'}


# ============================================================================
# v8.1: 通用 OCR 索引
# ============================================================================

def _ocr_single_image(img_path: str, timeout: int = 15) -> str:
    """对单张图片调用 z-ai CLI 进行 OCR。

    返回识别到的文本，失败返回空字符串。
    """
    import subprocess
    try:
        result = subprocess.run(
            ['z-ai', 'vision', '-p',
             '请提取这张图片中的所有文字内容，保持原有格式和布局。如果是证件照/营业执照/证书，请提取全部文字信息。',
             '-i', img_path],
            capture_output=True, text=True, timeout=timeout,
            encoding='utf-8', errors='replace'
        )
        if result.returncode == 0:
            # 从 JSON 输出中提取 content 字段
            output = result.stdout
            # z-ai vision 输出是 JSON 格式
            try:
                data = json.loads(output)
                content = data.get('choices', [{}])[0].get('message', {}).get('content', '')
                if content:
                    return content.strip()
            except (json.JSONDecodeError, IndexError, KeyError):
                pass
            # 如果 JSON 解析失败，尝试直接用输出（可能不是JSON）
            if output.strip():
                return output.strip()[:2000]
    except subprocess.TimeoutExpired:
        _logger.info(f'      [OCR] 超时: {os.path.basename(img_path)}')
    except FileNotFoundError:
        _logger.info(f'      [OCR] z-ai CLI 未安装，跳过OCR')
    except Exception as e:
        _logger.info(f'      [OCR] 失败: {os.path.basename(img_path)}: {e}')
    return ''


def _extract_images_from_docx_to_temp(docx_path: str) -> Dict[str, str]:
    """从 docx 中提取所有图片到临时目录，返回 {文件名: 临时路径}"""
    result = {}
    try:
        temp_dir = tempfile.mkdtemp(prefix='ocr_extract_')
        with zipfile.ZipFile(docx_path) as z:
            for name in z.namelist():
                if name.startswith('word/media/'):
                    fname = os.path.basename(name)
                    dst = os.path.join(temp_dir, fname)
                    with z.open(name) as src, open(dst, 'wb') as out:
                        out.write(src.read())
                    result[fname] = dst
    except Exception:
        pass
    return result


def run_ocr_indexing(reports: List[MaterialFileReport], docx_path: str = '',
                     materials_dir: str = '') -> int:
    """对所有 image_only 章节和独立图片文件执行 OCR 索引。

    参数:
        reports: 扫描报告列表
        docx_path: 源 docx 文件路径（用于提取内嵌图片）
        materials_dir: 资料文件夹路径（用于定位独立图片文件）

    返回:
        成功 OCR 的图片数量
    """
    import tempfile as _tf

    ocr_count = 0
    # 缓存已提取的 docx 图片 {docx_path: {fname: temp_path}}
    docx_image_cache = {}

    for report in reports:
        # 准备 docx 内嵌图片的临时提取
        if report.file_type == 'docx' and report.file_path and report.file_path not in docx_image_cache:
            docx_image_cache[report.file_path] = _extract_images_from_docx_to_temp(report.file_path)

        extracted_images = docx_image_cache.get(report.file_path, {})

        for sec in report.sections:
            # 只对 image_only 或 mixed 类型章节中无文本的部分做 OCR
            if sec.content_type == 'text_only':
                continue
            if not sec.images:
                continue
            if sec.text_content and sec.content_type == 'mixed':
                # mixed 类型有文本，跳过 OCR（文本已足够）
                continue

            section_ocr_parts = []
            for img_fname in sec.images:
                img_path = None

                # 1. 从 docx 提取的临时图片
                if img_fname in extracted_images:
                    img_path = extracted_images[img_fname]
                # 2. 从资料文件夹找独立图片文件
                elif materials_dir:
                    candidate = os.path.join(materials_dir, img_fname)
                    if os.path.exists(candidate):
                        img_path = candidate
                    else:
                        # 递归搜索
                        for root, dirs, files in os.walk(materials_dir):
                            if img_fname in files:
                                img_path = os.path.join(root, img_fname)
                                break

                if not img_path or not os.path.exists(img_path):
                    continue

                _logger.info(f'      [OCR] {img_fname}...', end=' ', flush=True)
                ocr_text = _ocr_single_image(img_path)
                if ocr_text:
                    sec.ocr_images[img_fname] = ocr_text
                    section_ocr_parts.append(ocr_text)
                    ocr_count += 1
                    preview = ocr_text[:40].replace('\n', ' ')
                    _logger.info(f'OK ({len(ocr_text)}字) "{preview}..."')
                else:
                    _logger.info('无文字')

            # 合并整个章节的 OCR 文本
            if section_ocr_parts:
                sec.ocr_text = '\n'.join(section_ocr_parts)

        # 对独立图片文件（file_type == 'image'）做 OCR
        if report.file_type == 'image' and report.file_path:
            img_path = report.file_path
            if os.path.exists(img_path):
                _logger.info(f'      [OCR] {report.file_name}...', end=' ', flush=True)
                ocr_text = _ocr_single_image(img_path)
                if ocr_text:
                    for sec in report.sections:
                        sec.ocr_text = ocr_text
                        sec.ocr_images[report.file_name] = ocr_text
                    ocr_count += 1
                    preview = ocr_text[:40].replace('\n', ' ')
                    _logger.info(f'OK ({len(ocr_text)}字) "{preview}..."')
                else:
                    _logger.info('无文字')

    # 清理临时文件
    for temp_images in docx_image_cache.values():
        for tmp_path in temp_images.values():
            try:
                os.remove(tmp_path)
            except Exception:
                pass
        # 清理临时目录
        if temp_images:
            first_tmp = list(temp_images.values())[0]
            tmp_dir = os.path.dirname(first_tmp)
            try:
                os.rmdir(tmp_dir)
            except Exception:
                pass

    return ocr_count


def extract_from_image_file(file_path: str) -> MaterialFileReport:
    """扫描单张图片文件"""
    report = MaterialFileReport(
        file_path=file_path,
        file_name=os.path.basename(file_path),
        file_type='image'
    )
    
    report.sections.append(MaterialSection(
        section_id=1,
        heading=os.path.basename(file_path),
        heading_para_index=0,
        para_start=0,
        para_end=1,
        content_type='image_only',
        images=[os.path.basename(file_path)],
        image_count=1,
        source_file=report.file_name,
    ))
    
    report.total_sections = 1
    report.total_images = 1
    return report


# ============================================================================
# 主入口：扫描整个资料文件夹
# ============================================================================

def scan_materials_folder(folder_path: str) -> List[MaterialFileReport]:
    """
    扫描项目资料文件夹中的所有文件。
    
    参数:
        folder_path: 资料文件夹路径
    
    返回:
        List[MaterialFileReport]: 每个文件的扫描报告
    """
    folder = Path(folder_path)
    if not folder.exists():
        raise FileNotFoundError(f"资料文件夹不存在: {folder_path}")
    
    reports = []
    
    for file_path in folder.iterdir():
        # 跳过临时文件
        if file_path.name.startswith('~$'):
            continue
        
        suffix = file_path.suffix.lower()
        
        try:
            if suffix == '.docx':
                report = extract_sections_from_docx(str(file_path))
            elif suffix == '.doc':
                # .doc 文件暂不支持，标记
                report = MaterialFileReport(
                    file_path=str(file_path),
                    file_name=file_path.name,
                    file_type='doc_unsupported'
                )
                report.errors.append('.doc 格式暂不支持，建议另存为 .docx')
            elif suffix == '.pdf':
                report = extract_sections_from_pdf(str(file_path))
            elif suffix in {'.xlsx', '.xls'}:
                report = extract_sections_from_xlsx(str(file_path))
            elif suffix.lower() in IMAGE_EXTENSIONS:
                report = extract_from_image_file(str(file_path))
            else:
                continue  # 跳过不支持的类型
            
            reports.append(report)
        except Exception as e:
            error_report = MaterialFileReport(
                file_path=str(file_path),
                file_name=file_path.name,
                file_type='error'
            )
            error_report.errors.append(f"扫描失败: {e}")
            reports.append(error_report)
    
    return reports


# ============================================================================
# 报告序列化
# ============================================================================

def reports_to_dict(reports: List[MaterialFileReport]) -> Dict:
    """将扫描报告列表转换为可序列化的字典"""
    result = {
        'scan_summary': {
            'total_files': len(reports),
            'total_sections': sum(r.total_sections for r in reports),
            'total_images': sum(r.total_images for r in reports),
            'total_errors': sum(len(r.errors) for r in reports),
        },
        'files': []
    }
    
    for report in reports:
        file_data = {
            'file_name': report.file_name,
            'file_path': report.file_path,
            'file_type': report.file_type,
            'total_sections': report.total_sections,
            'total_images': report.total_images,
            'errors': report.errors,
            'sections': []
        }
        
        for sec in report.sections:
            file_data['sections'].append({
                'section_id': sec.section_id,
                'heading': sec.heading,
                'para_start': sec.para_start,
                'para_end': sec.para_end,
                'content_type': sec.content_type,
                'text_content': sec.text_content,  # 保留完整文本
                'image_count': sec.image_count,
                'images': sec.images,  # v8.0: 不再截断，返回全部图片
                'ocr_text': sec.ocr_text or '',  # v8.1: OCR识别文本
                'ocr_images': sec.ocr_images,  # v8.1: {图片文件名: OCR文本}
                'total_images_in_section': sec.image_count,
            })
        
        result['files'].append(file_data)
    
    return result


def save_reports_json(reports: List[MaterialFileReport], output_path: str):
    """保存扫描结果为JSON文件"""
    data = reports_to_dict(reports)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    _logger.info(f"[material_deep_scanner] 扫描报告已保存: {output_path}")


# ============================================================================
# 单文件扫描入口
# ============================================================================

def scan_single_file(file_path: str) -> MaterialFileReport:
    """扫描单个文件（自动根据扩展名选择解析器）"""
    suffix = Path(file_path).suffix.lower()
    if suffix == '.docx':
        return extract_sections_from_docx(file_path)
    elif suffix == '.pdf':
        return extract_sections_from_pdf(file_path)
    elif suffix in {'.xlsx', '.xls'}:
        return extract_sections_from_xlsx(file_path)
    elif suffix in IMAGE_EXTENSIONS:
        return extract_from_image_file(file_path)
    elif suffix == '.doc':
        report = MaterialFileReport(
            file_path=file_path,
            file_name=os.path.basename(file_path),
            file_type='doc_unsupported'
        )
        report.errors.append('.doc 格式暂不支持，建议另存为 .docx')
        return report
    else:
        report = MaterialFileReport(
            file_path=file_path,
            file_name=os.path.basename(file_path),
            file_type='unsupported'
        )
        report.errors.append(f'不支持的文件格式: {suffix}')
        return report


# ============================================================================
# 递归文件夹扫描（支持子目录）
# ============================================================================

def scan_materials_folder_recursive(folder_path: str) -> List[MaterialFileReport]:
    """
    递归扫描资料文件夹（含子目录）中的所有文件。
    """
    folder = Path(folder_path)
    if not folder.exists():
        raise FileNotFoundError(f"资料文件夹不存在: {folder_path}")

    reports = []

    for file_path in sorted(folder.rglob('*')):
        if not file_path.is_file():
            continue
        if file_path.name.startswith('~$'):
            continue

        suffix = file_path.suffix.lower()
        supported = suffix in {'.docx', '.pdf', '.xlsx', '.xls'} | IMAGE_EXTENSIONS
        if not supported:
            continue

        try:
            report = scan_single_file(str(file_path))
            reports.append(report)
        except Exception as e:
            error_report = MaterialFileReport(
                file_path=str(file_path),
                file_name=file_path.name,
                file_type='error'
            )
            error_report.errors.append(f"扫描失败: {e}")
            reports.append(error_report)

    return reports


# ============================================================================
# CLI 入口
# ============================================================================

if __name__ == '__main__':
    import sys
    import argparse
    if sys.platform == 'win32':
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr = open(sys.stderr.fileno(), mode='w', encoding='utf-8', errors='replace', buffering=1)
    else:
        sys.stdout.reconfigure(encoding='utf-8')

    parser = argparse.ArgumentParser(description='资料深度扫描器 — 扫描项目资料文件/文件夹，建立章节结构JSON')
    parser.add_argument('--project-name', required=True, help='项目名称（用于输出文件命名）')
    parser.add_argument('--materials-dir', default='', help='资料文件夹路径（递归扫描子目录）')
    parser.add_argument('--materials-file', default='', help='单个资料文件路径（与 --materials-dir 二选一）')
    parser.add_argument('--output', default='', help='输出JSON路径（默认: {项目名}_资料深度扫描.json）')
    parser.add_argument('--ocr', action='store_true', help='v8.1: 对图片执行OCR索引（需要 z-ai CLI）')
    args = parser.parse_args()

    project_name = args.project_name
    output_path = args.output or f'{project_name}_资料深度扫描.json'

    _logger.info("=" * 60)
    _logger.info(f"  资料深度扫描器 v7.1")
    _logger.info("=" * 60)

    # 收集扫描报告
    reports = []

    if args.materials_file:
        # 单文件模式
        fpath = args.materials_file
        if not os.path.exists(fpath):
            _logger.error(f"[ERROR] 文件不存在: {fpath}")
            sys.exit(1)
        _logger.info(f"  扫描单文件: {fpath}")
        report = scan_single_file(fpath)
        reports.append(report)
    elif args.materials_dir:
        # 文件夹模式（递归）
        dpath = args.materials_dir
        if not os.path.isdir(dpath):
            _logger.error(f"[ERROR] 文件夹不存在: {dpath}")
            sys.exit(1)
        _logger.info(f"  扫描文件夹: {dpath}（递归）")
        reports = scan_materials_folder_recursive(dpath)
    else:
        _logger.error("[ERROR] 必须指定 --materials-dir 或 --materials-file")
        parser.print_help()
        sys.exit(1)

    # 打印结果
    for report in reports:
        _logger.info(f"\n--- {report.file_name} ({report.file_type}) ---")
        if report.errors:
            for err in report.errors:
                _logger.error(f"  [ERROR] {err}")
        _logger.info(f"  章节数: {report.total_sections}")
        _logger.info(f"  图片数: {report.total_images}")
        for sec in report.sections:
            img_info = f"({sec.image_count}张图)" if sec.image_count > 0 else ""
            text_info = " [文本]" if sec.text_content else ""
            _logger.info(f"    §{sec.section_id}: [{sec.content_type:10s}] {sec.heading[:50]} {img_info}{text_info}")

    # v8.1: OCR 索引（如果启用）
    if args.ocr:
        ocr_total = 0
        _logger.info(f"\n{'=' * 60}")
        _logger.info(f"  OCR 图片索引（v8.1）")
        _logger.info(f"{'=' * 60}")
        ocr_total = run_ocr_indexing(reports, materials_dir=dpath or os.path.dirname(args.materials_file or ''))
        _logger.info(f"  OCR 完成: {ocr_total}张图片识别到文字")
        # 重新保存JSON（含OCR数据）
        save_reports_json(reports, output_path)

    if not args.ocr:
        # 保存JSON
        save_reports_json(reports, output_path)

    total_sections = sum(r.total_sections for r in reports)
    total_images = sum(r.total_images for r in reports)
    total_errors = sum(len(r.errors) for r in reports)
    _logger.info(f"\n  总计: {len(reports)}个文件, {total_sections}个章节, {total_images}张图片, {total_errors}个错误")
    _logger.info(f"  输出: {output_path}")
