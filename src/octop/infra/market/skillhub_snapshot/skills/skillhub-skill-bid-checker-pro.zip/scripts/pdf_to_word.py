#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF转Word工具 — 招标文件的PDF→DOCX转换器（v9.0 跨平台统一版）

核心功能：
  - 当招标文件是PDF格式时，自动转换为Word（.docx）格式
  - v9.0: 跨平台统一优先级（不再Windows优先）
    1. pdf2docx库（纯Python，跨平台，质量较好）—— 主路径
    2. win32com Word自动化（仅Windows + 安装了MS Word时）—— 可选高保真
    3. 降级方案：pdfplumber提取文本+表格 —— 保底
"""

import os
import sys
import subprocess
import tempfile
import shutil
import platform
from pathlib import Path

# v9.0: 统一日志
try:
    from bid_checker.utils.logger import get_logger
    _logger = get_logger("bid_checker.pdf_to_word")
except ImportError:
    import logging
    _logger = logging.getLogger("pdf_to_word")
    if not _logger.handlers:
        _handler = logging.StreamHandler(sys.stderr)
        _handler.setFormatter(logging.Formatter("[%(levelname)s] [%(name)s] %(message)s"))
        _logger.addHandler(_handler)
        _logger.setLevel(logging.INFO)


def convert_pdf_to_word(pdf_path, output_path=None):
    """
    将PDF文件转换为Word（.docx）格式（v9.0 跨平台统一优先级）。

    参数:
      pdf_path: 输入PDF文件路径
      output_path: 输出Word文件路径（可选，默认同名替换）

    返回:
      output_path: 转换后的Word文件完整路径

    v9.0 变更：
      - 默认使用 pdf2docx（跨平台纯Python）作为主路径
      - win32com 降为可选高保真路径（仅 Windows + MS Word 可用时生效）
      - Linux/Mac 上不再尝试不可用的 win32com
    """
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF文件不存在: {pdf_path}")

    if output_path is None:
        base = Path(pdf_path).stem
        output_path = f"{base}_转换.docx"

    # 确保输出目录存在
    out_dir = os.path.dirname(os.path.abspath(output_path))
    os.makedirs(out_dir, exist_ok=True)

    # v9.0: 跨平台统一优先级
    # 1. pdf2docx（跨平台，主路径）
    _logger.info("尝试 pdf2docx 转换（跨平台主路径）")
    result = _try_pdf2docx_convert(pdf_path, output_path)
    if result:
        return result

    # 2. win32com（仅Windows + MS Word可用时，高保真可选路径）
    if sys.platform == 'win32':
        _logger.info("尝试 win32com 转换（Windows + MS Word 可选高保真路径）")
        result = _try_win32com_convert(pdf_path, output_path)
        if result:
            return result
    else:
        _logger.debug("非 Windows 平台，跳过 win32com")

    # 3. 降级方案：提取文本+表格，重建Word
    _logger.info("尝试降级方案：pdfplumber + python-docx")
    result = _try_fallback_convert(pdf_path, output_path)
    if result:
        return result

    raise RuntimeError("所有PDF转换方式均失败，请检查依赖或手动转换")


def _try_win32com_convert(pdf_path, output_path):
    """
    尝试使用Microsoft Word的COM接口转换PDF。
    这是保真度最高的方式，因为Word原生支持PDF→DOCX转换。
    v9.0: 仅在 Windows 平台上调用，避免在 Linux/Mac 上产生 ImportError 噪声。
    """
    if sys.platform != 'win32':
        _logger.debug("非 Windows 平台，win32com 不可用")
        return None
    try:
        import win32com.client
    except ImportError:
        _logger.error("  ✗ 未安装pywin32，无法使用Win32 COM方式")
        _logger.info("     安装: pip install pywin32")
        return None

    # 检查MS Word是否可用
    try:
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        word.DisplayAlerts = False
    except Exception as e:
        _logger.error(f"  ✗ Microsoft Word不可用: {e}")
        return None

    try:
        # 转换PDF到Word
        word.Documents.Open(pdf_path)
        # 另存为docx
        word.ActiveDocument.SaveAs2(output_path, FileFormat=16)  # 16 = wdFormatXMLDocument
        word.ActiveDocument.Close()
        word.Quit()

        file_size = os.path.getsize(output_path) / 1024
        _logger.info(f"  ✓ 使用Microsoft Word转换PDF成功（保真度最高）: {file_size:.1f} KB")
        return output_path

    except Exception as e:
        _logger.error(f"  ✗ Win32 COM转换失败: {e}")
        return None


def _try_pdf2docx_convert(pdf_path, output_path):
    """
    尝试使用pdf2docx库转换（纯Python，无需安装Microsoft Word）。
    如果未安装，自动提示安装。
    """
    try:
        from pdf2docx import Converter
    except ImportError:
        _logger.warning("  ⚠ 未安装pdf2docx库")
        _logger.info("     安装: pip install pdf2docx")
        return None

    try:
        import time
        start = time.time()
        cv = Converter(pdf_path)
        cv.convert(output_path, start=0, end=None)
        cv.close()
        elapsed = time.time() - start

        file_size = os.path.getsize(output_path) / 1024
        _logger.info(f"  ✓ 使用pdf2docx转换PDF成功: {file_size:.1f} KB, 耗时{elapsed:.1f}s")
        return output_path

    except Exception as e:
        _logger.error(f"  ✗ pdf2docx转换失败: {e}")
        return None


def _try_fallback_convert(pdf_path, output_path):
    """
    降级方案：使用pdfplumber提取文本和表格，用python-docx重建Word。
    优点：纯Python，无需额外安装
    缺点：格式保真度较低（无图片、复杂排版可能丢失）
    """
    try:
        import pdfplumber
    except ImportError:
        _logger.warning("  ⚠ 未安装pdfplumber，无法使用降级方案")
        return None

    try:
        from docx import Document
        from docx.shared import Pt, Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        _logger.warning("  ⚠ 未安装python-docx，无法使用降级方案")
        return None

    _logger.warning("  ⚠ 使用降级方案：pdfplumber + python-docx重建Word...")
    _logger.info("     （格式保真度较低，建议优先使用Word转换或pdf2docx）")

    doc = Document()
    doc.add_heading("招标文件（PDF转换）", level=1)

    with pdfplumber.open(pdf_path) as pdf:
        page_num = 0
        for page in pdf.pages:
            page_num += 1

            # 提取文本
            text = page.extract_text()
            if text:
                doc.add_paragraph(text)

            # 提取表格
            tables = page.extract_tables()
            for table in tables:
                if table:
                    t = doc.add_table(rows=len(table), cols=len(table[0]))
                    for i, row in enumerate(table):
                        for j, cell in enumerate(row):
                            t.cell(i, j).text = str(cell) if cell else ''

    doc.save(output_path)
    file_size = os.path.getsize(output_path) / 1024
    _logger.info(f"  ✓ 降级方案转换完成: {file_size:.1f} KB")
    return output_path


def auto_detect_and_convert(pdf_or_word_path, output_dir=None):
    """
    自动检测文件格式并处理。

    如果输入是Word（.docx），直接返回原路径
    如果输入是PDF，自动转换并返回转换后的Word路径

    参数:
      pdf_or_word_path: 输入文件路径
      output_dir: 输出目录（默认同输入文件同级）

    返回:
      tuple: (word_path, was_pdf_bool)
    """
    if not os.path.exists(pdf_or_word_path):
        raise FileNotFoundError(f"文件不存在: {pdf_or_word_path}")

    # 如果已经是Word文件，直接返回
    if pdf_or_word_path.lower().endswith('.docx') or pdf_or_word_path.lower().endswith('.doc'):
        _logger.info(f"  ✓ 文件已是Word格式，无需转换")
        return pdf_or_word_path, False

    # 如果是PDF，进行转换
    if pdf_or_word_path.lower().endswith('.pdf'):
        if output_dir is None:
            output_dir = os.path.dirname(os.path.abspath(pdf_or_word_path))

        base_name = os.path.splitext(os.path.basename(pdf_or_word_path))[0]
        output_word = os.path.join(output_dir, f"{base_name}_转换.docx")

        _logger.info(f"  🔄 检测到PDF文件，自动转换中...")
        converted_path = convert_pdf_to_word(pdf_or_word_path, output_word)
        _logger.info(f"  ✓ PDF→Word转换完成: {converted_path}")
        return converted_path, True

    # 其他格式报错
    raise ValueError(f"不支持的文件格式: {pdf_or_word_path}（仅支持.docx/.pdf）")


if __name__ == '__main__':
    # 命令行使用示例
    import argparse

    parser = argparse.ArgumentParser(description='PDF转Word工具')
    parser.add_argument('input', help='输入PDF文件路径')
    parser.add_argument('output', nargs='?', help='输出Word文件路径（可选）')
    args = parser.parse_args()

    try:
        result = convert_pdf_to_word(args.input, args.output)
        _logger.info(f"\n转换成功！输出: {result}")
    except Exception as e:
        _logger.info(f"\n转换失败: {e}")
        sys.exit(1)
