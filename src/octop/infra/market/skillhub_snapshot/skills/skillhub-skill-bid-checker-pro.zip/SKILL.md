---
name: skillhub-skill-bid-checker-pro
description: "标书审核专家：解析招标文件→建立标书章节索引→格式合规8类检查→评分项响应质量评估（含主观分预估）→OCR资质详细比对→价格分一致性检查（大写金额合规/大小写一致/跨位置一致/分项合计/文字-表格一致）→技术方案抄袭检测（残留他人信息/跨章节自重复/与公开资料相似/AI痕迹/引用未署名）→Markdown审核报告。专治标书\"做完不敢交\"的痛点，专门检查已完成的标书是否合规、能拿多少分、哪些点要扣分、有没有抄袭风险。支持政府采购/工程类/IT信息化全类型，支持Word+PDF+Excel混合输入，支持上百页大文档分段精读。务必在用户说\"帮我检查这份标书/审核标书/标书查错/标书体检/评估标书得分/标书能拿多少分/检查标书抄袭/检查价格一致性\"等任何与标书审核、检查、纠错、评分预估、抄袭检测、价格检查相关的场景下立即触发本技能。"
---

# bid-checker-pro v1.2.2 — 标书审核专家

> **v1.2.2 变更（通用化，不硬编码任何具体项目）**：
> 1. **Stage 1 增强「资格要求 + 偏离表结构化提取」**：解析招标文件时除格式要求/评分表，新增抽取 `qualification_requirements`（资格审查要求清单：每条含"要求描述 + 投标人须提供的证明材料类型"）与 `deviation_tables`（技术规格条款偏离表 / 商务条款偏离表的行级结构）。类型与字段名由 LLM 从招标文本归纳，**不写死任何具体字段**（信用中国/社保等均不硬编码，跟随招标文本走）。
> 2. **Stage 2.7 拆为「技术偏离 + 商务偏离」双核对**：保留原技术参数逐项数值比对（2.7A），新增商务条款偏离核对（2.7B，逐行核对投标响应是否如实填偏离、有无隐瞒负偏离）；无商务偏离表时显式标注"本项目未提供商务偏离表"。偏离表逐行结果**必须逐行写入报告第⑧章**，不得只给汇总。
> 3. **Stage 5 资格审查核验改为「要求驱动 + 图文双搜」**：对 `qualification_requirements` 的**每一条**都必须在报告出现——先在投标文件全目录（递归遍历所有 PDF+docx 正文）文本检索，再对命中点相邻页用 `page.get_images()` 提取嵌入图片并导出临时图做视觉确认（图片确认方式见下方 5.x 注，本次不强行依赖图像识别）。三态结论：`compliant` / `missing_critical`（列明"投标文件中未提供"并醒目警示一票否决风险）/ `needs_review`。**强制规则：要求清单每一项都必须有报告表行，绝不允许静默跳过。**
> 4. **报告模板 + 自检表对齐**：第 6.3 节报告模板重写为与自检表一致的 **11 章**结构；自检表新增两行硬门控（④章行数==资格要求条数；⑧章含技术+商务偏离逐行核对）。

> **v1.2.1 变更**：取消六阶段之间的强制暂停（门控1/2/3/4 + Stage 1.4 / 2.7 / 3 / 4 / 6 收尾 ⏸️ 暂停），改为连续运行、一口气出报告。仅保留一次必要用户交互：Stage 4 计算价格分前的竞争对手基准价询问（OCR 已改为本地 RapidOCR，无需任何 API 密钥与凭证采集，见 E 节）。内部"阶段-报告对照自检（11 章）"硬门控保留。

> **路径约定**：本文档中 `{WORK_DIR}` 表示当前工作目录（即项目根目录），`{WORK_DIR}/download/` 为输出目录。模型应根据实际运行环境动态确定路径，不硬编码绝对路径。

> **核心理念**：不是"AI替你重写标书"，而是"AI帮你审标书"——读招标文件抽要求+评分表，分段精读标书建索引，逐项核对格式合规性+评分项响应质量，输出带原文定位的Markdown审核报告。

> **与 bid-document-maker 的区别**：maker 是"填标书"（提取模板→自动填充→缺失标黄），checker 是"查标书"（提取要求→比对实际→违规报告）。两者共享前半段（解析+模板提取+格式护栏），后半段方向相反。

---

## ⚠️ 强制执行规则（ALL MODELS MUST FOLLOW）

> **以下规则对本技能的所有调用者（任何模型）具有强制约束力，不得跳过、合并或并行执行多个阶段。违反以下流程将导致产出物不可用。**
>
> **【全阶段强制总则 · 任何模型不得豁免】**
> 1. **六阶段全部必做**：Stage 1→2→3→4→5→6 缺一不可。严禁以"环境不可用 / 降级 / 时间紧 / 用户没要求"为由，整段跳过某一阶段或其对应报告章节。
> 2. **报告章节不可缺**：最终报告必须包含全部 **11** 章（① 总体概览 ② 格式合规 ③ 评分项预估 ④ OCR 比对（资格审查要求驱动核验） ⑤ 视觉核对 ⑥ 标⭐️项检查 ⑦ 文字错误检查 **⑧ 技术参数偏离分析（技术偏离 + 商务偏离）** ⑨ 价格分一致性 ⑩ 技术方案抄袭 ⑪ 改进建议）。其中 **③ 评分项预估（含报价分预估）**、**④ OCR 比对（资格审查要求清单每一项都必须有表行，不得静默漏项）**、**⑥ 标⭐️项检查**、**⑧ 技术参数偏离分析（须含技术+商务双偏离逐行表）** 与 **⑩ 技术方案抄袭检测（含跨章节自重复维度② + 与公开资料相似维度③）** 最易被遗漏，**强制列为"高优先级必交付章节"**——缺失即视为检查未完成、产出物不可用，禁止交付。
> 3. **降级≠跳过**：若某子能力（OCR、z-ai web-search、LibreOffice 转换、LLM 评估等）在本环境不可用，必须**显式标注降级原因与影响范围**，并改用本 agent 的等价能力兜底（如用 WebSearch 替代 z-ai web-search、用 olefile/PyMuPDF 提取替代 LibreOffice 转换），禁止静默整段跳过。
> 4. **交付前自检（硬门控）**：Stage 6 生成报告后、交付前，必须执行"阶段-报告对照自检"（清单见下方"自检清单"与"阶段-报告对照自检"），缺章必须返回补做，绝不允许"看起来做完了"就交付。
> 5. **OCR 为本地无 API 模式（无需凭证采集）**：本技能 OCR 统一使用本地 RapidOCR 引擎，无需任何 API 密钥、无需注册、无需联网，因此**不再需要**进入 Stage 1 前的 OCR 凭证采集交互。若本机 RapidOCR 不可用，Stage 5 须**显式标注降级原因与影响范围**并改用规则/关键词兜底（禁止静默整段跳过 OCR 比对章节）。

### 六阶段顺序执行（连续运行，仅 2 次交互）

> **运行模型（v1.2.1）**：六阶段连续执行、不暂停，一气呵成出报告。仅一处向用户交互：Stage 4 计算价格分前询问竞争对手基准价。OCR 为本地 RapidOCR，无需凭证采集。其余阶段仅展示进度摘要即自动进入下一阶段。

```
┌─────────────────────────────────────────────────────────┐
│  Stage 1: 解析招标文件（提取格式要求+评分表）              │
│  输入: 招标文件（.docx/.doc/.pdf）                        │
│  产物: {项目名}_招标要求清单.json                         │
│  产物: {项目名}_评分表.json                               │
│  OCR: 本地 RapidOCR（无需 API 密钥，无需交互采集）            │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│  Stage 2: 解析待审核标书（建立章节索引）                  │
│  输入: 标书文件（.docx/.doc/.pdf，可上百页）              │
│  产物: {项目名}_标书章节索引.json                         │
│  产物: {项目名}_标书章节摘要.json                         │
│  完成后展示摘要，自动进入 Stage 3                                 │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│  Stage 3: 格式合规比对（8类检查）                         │
│  输入: 招标要求清单 + 标书章节索引                        │
│  产物: {项目名}_格式审核Plan.json                         │
│  完成后展示摘要，自动进入 Stage 4                 │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│  Stage 4: 评分项响应质量评估                              │
│  输入: 评分表 + 标书章节索引+章节摘要                     │
│  产物: {项目名}_评分预估Plan.json                         │
│  🔑 交互②: 计算价格分前询问竞争对手基准价                 │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│  Stage 5: OCR 资质详细比对 + 渲染视觉核对                 │
│  输入: 标书图片 + 资质章节                                │
│  产物: {项目名}_OCR比对报告.json                          │
│  产物: {项目名}_审核预览PNG/                              │
│  完成后展示摘要，自动进入 Stage 6                                 │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│  Stage 6: 生成最终审核报告                                │
│  输入: 格式审核Plan + 评分预估Plan + OCR比对 + 视觉核对   │
│  产物: {项目名}_审核报告.md（最终交付）                   │
│  完成后执行阶段-报告对照自检，交付报告                                   │
└─────────────────────────────────────────────────────────┘
```

### 每阶段完成后的标准动作（不暂停）

每个阶段完成后依次执行以下动作，**不暂停、不等待用户回复**，展示摘要后立即自动推进：

1. **产物文件存在性检查**：`ls -la {WORK_DIR}/{产物文件}` 验证文件存在且大小 ≥1KB
2. **展示产物摘要**：在对话中展示关键统计（如"共检查 8 类格式合规项，发现 5 处违规"），作为连续进度播报
3. **自动进入下一阶段**：无需用户确认立即推进（仅 Stage 4 基准价一次交互已在对应步骤前置完成；OCR 为本地无 API，无需交互）

> **交付前阶段-报告对照自检（内部硬门控，非用户暂停）**：Stage 6 生成报告后、交付前，报告必须包含全部 **11** 个章节（① 总体概览 ② 格式合规 ③ 评分项预估 ④ OCR 比对（资格审查要求驱动核验） ⑤ 视觉核对 ⑥ 标⭐️项检查 ⑦ 文字错误检查 **⑧ 技术参数偏离分析（技术偏离+商务偏离）** ⑨ 价格分一致性 ⑩ 技术方案抄袭 ⑪ 改进建议）。**缺任何一章（尤其"③ 评分项预估""④ OCR 比对""⑥ 标⭐️项检查""⑧ 技术参数偏离分析"与"⑩ 技术方案抄袭检测"）必须返回补做，禁止交付缺章报告。** 对照清单见下方"阶段-报告对照自检"。

### 自检清单（每个阶段必问自己）

- [ ] 我是否用 `ls -la` 验证了产物文件存在且 ≥1KB？
- [ ] 我是否展示了产物文件的关键摘要（连续进度播报，不暂停）？
- [ ] OCR 是否已确认使用本地 RapidOCR（无需凭证采集，无需交互）？若不可用，Stage 5 是否会显式标注降级？
- [ ] 我是否在 Stage 4 计算价格分前执行了 **基准价 AskUserQuestion**（2 次交互之②）？
- [ ] 我是否在 Stage 6 交付前执行了 **阶段-报告对照自检（11 章）**，缺章已补做？
- [ ] **④ 章资格审查核验表行数 == 招标解析 `qualification_requirements` 条数**（无静默漏项）？
- [ ] **⑧ 章含技术偏离逐行表 + 商务偏离逐行表**（无商务偏离表时显式标注"已等价核对"）？

### 阶段-报告对照自检（Stage 6 交付前硬门控 · 缺章即返回补做）

| 报告章节 | 对应阶段 | 必含内容（不可缺） | 缺失后果 |
|---------|---------|------------------|---------|
| ① 总体概览 | Stage 1 / 4 | 合规率 + 预估得分 + 置信度 | 报告不可用 |
| ② 格式合规审核 | Stage 3 | 4 级严重度分组 + 致命违规明细 | 漏检废标项 |
| ③ 评分项预估 | Stage 4 | 逐项预估分 + 总分 + `baseline_price` 价格分计算依据 | **🔴 禁止交付缺章** |
| ④ OCR 比对 | Stage 5 | **资格审查要求驱动核验表**：`qualification_requirements` 每一项都须有对应行（行数 == 招标解析资格要求条数）；三态结论（compliant/missing_critical/needs_review）；`missing_critical` 须醒目警示一票否决 | 资质风险漏检 / 静默漏项 |
| ⑤ 视觉核对 | Stage 5 | 按页面核对发现 | 版式问题漏检 |
| ⑥ 标⭐️项检查 | Stage 2.5 | 标星项（参数/废标条款/评分政策）明细表 + 投标响应判定 + LLM 逐条复核结论（无标星项须显式标注）+ **隐性废标条款(2.5.2a)检测结果** | **🔴 禁止交付缺章** |
| ⑦ 文字错误检查 | Stage 2.6 | 错别字/异形词/金额大小写/专名一致性 明细表 + LLM 语境复核结论 | **🔴 禁止交付缺章** |
| **⑧ 技术参数偏离分析** | **Stage 2.7** | **技术偏离逐行表（方向性+严重度）+ 商务偏离逐行表（或显式标注"本项目未提供商务偏离表，已等价核对"）+ 偏离汇总统计 + 隐瞒负偏离检测 + 隐性废标条款** | **🔴 禁止交付缺章（v1.2.0 新增）** |
| ⑨ 价格分一致性 | Stage 5.5 | 5 项结果 + 报价分计算依据 | **🔴 禁止交付缺章** |
| ⑩ 技术方案抄袭 | Stage 5.5 | 5 维度 + 维度②/③ 明细定位表 + 维度③状态字段 | **🔴 禁止交付缺章** |
| ⑪ 改进建议 | Stage 3/4/5 | 按优先级 P0–P3 排序 | 缺行动指引 |

> 凡标注「🔴 禁止交付缺章」的章节缺失，必须返回对应 Stage 补做，**绝不允许"看起来做完了"就交付**。报告交付前必须逐行核对本表 **11 行**。

---

## 启动前必读

在执行 Stage 1 之前，模型必须依次完成以下准备：

### A. 读取经验案例库（强制）

读取 `{SKILL_DIR}/EXPERIENCES.md`，理解 11 条审核规则（E1-E11）及其对应的检查项。这些规则是从真实标书踩坑案例提炼的，每一项都对应审核 Plan 中的一个检查项。

### B. 读取审核规则配置（强制）

读取 `{SKILL_DIR}/config/audit_rules.yaml`，了解：
- 8 类格式合规检查项的具体规则
- 4 级严重度分类标准（critical/major/minor/info）
- 评分项响应质量评估的 4 级标准（完全响应/部分响应/不足/缺失）
- 必填项清单（投标函/法人信息/项目编号/日期等）

### C. 启动自检

运行 `python {SKILL_DIR}/scripts/ocr_selftest.py` 检查本地 RapidOCR 引擎当前可用性（无需任何 API 密钥）。若不可用，Stage 5 资质图片 OCR 比对将自动降级为规则/关键词兜底，并在报告中标注，不得据此整段跳过 OCR 比对章节。

### D. 确认输入

向用户确认以下信息（缺失时主动询问）：
1. **招标文件路径**（必需）：可以是 .docx/.doc/.pdf
2. **标书文件路径**（必需）：可以是 .docx/.doc/.pdf
3. **项目名称**（必需）：用于产物文件命名，若用户未提供，从招标文件解析后回填
4. **审核重点**（可选）：默认全量审核，用户可指定"只审格式"或"只评得分"

### E. OCR 本地模式说明（无需凭证采集）

本技能 OCR 统一采用 **本地 RapidOCR 引擎**，无需任何 API 密钥、无需注册、无需联网，因此**不再需要**向用户采集 OCR 凭证，也不存在"强制 OCR 交互"。

- 进入 Stage 1 前，模型可运行 `python {SKILL_DIR}/scripts/ocr_selftest.py` 自查 RapidOCR 是否可用；仅用于内部诊断，**不向用户弹出密钥采集界面**。
- 若 RapidOCR 可用：Stage 5 直接对资质图片（营业执照 / 证书 / 身份证等）做本地 OCR 详细比对。
- 若 RapidOCR 不可用（未安装且自动安装失败）：Stage 5 的资质图片 OCR 详细比对降级为「规则 / 关键词 / 人工标注」兜底；最终报告 **④ OCR 比对** 章节须显式标注「OCR 未配置，资质图片文字未自动核验，相关结论以'须人工确认'呈现」，**不得因降级而整段跳过 OCR 比对章节**（章节仍须存在并说明降级范围）。
- 如需启用本地 OCR：`pip install rapidocr-onnxruntime onnxruntime`（首次运行引擎也会自动安装）。

---

## 文档格式转换策略（多引擎高保真 · 严禁静默降级）

标书多为 `.doc`（老版 Word）格式。转换质量直接决定后续所有检查的准确性——一旦落入
「仅文本」提取，报价表、技术参数表、签字位等结构会丢失，价格核对等结论将不可信。
**绝不允许"只有 LibreOffice 才能转、没有就降级"的思路：用户电脑普遍装有 Office /
WPS，沙箱也能装 Aspose，可选项远不止 LibreOffice。**

### 引擎优先级（保真度从高到低，模型按序尝试）

| 优先级 | 引擎 | 可用条件 | 保真度 |
|------|------|---------|--------|
| 1 | **MS Word COM** | Windows + 已装 Microsoft Office | 高（保留表格/图片/样式/页码） |
| 2 | **WPS COM** | Windows + 已装 WPS Office（国产办公常见） | 高 |
| 3 | **LibreOffice** | 已装 `soffice`（跨平台） | 高 |
| 4 | **Aspose.Words** | `pip install aspose-words`（沙箱可装，程序化） | 高 |
| 5 | **olefile 提取** | 有 `olefile`（中文安全，保留段落/表格顺序） | 低（有损） |
| 6 | **antiword / docx2txt** | 最后兜底（中文易乱码） | 低（有损） |

> 实现见 `bid_checker/utils/doc_to_docx.py`：`convert_doc_to_docx()` 按上表顺序尝试，
> 返回 `(docx_path, was_converted, fidelity)`，其中 `fidelity` ∈ `{'high','text_only'}`。

### 铁律（对标书严谨性负责）

- **高保真优先**：先试 1~4，任一成功即用，绝不在有高保真引擎可用时跳到仅文本兜底。
- **自动安装兜底（AI 在沙箱主动安装）**：若 1~4 全不可用，模型**应先执行自动安装**
  （`try_auto_install()` 即 `pip install aspose-words`）并重试；仍失败再提示用户安装
  MS Office / WPS / LibreOffice 之一。**严禁在"可安装高保真引擎"时直接宣布"无法转换"。**
- **禁止静默降级**：仅当 1~4 全部失败才落入 5/6 仅文本兜底，此时函数返回
  `fidelity='text_only'`，模型须：
  1. 在进度摘要与最终报告中显式标注「本次转换为仅文本兜底，结构有损」；
  2. 凡涉及表格（报价、技术参数、资质清单）的结论，提示「须逐页人工复核」；
  3. 强烈建议用户用 Word/WPS 另存为 `.docx` 后重新运行。
- **自检命令**：`python {SKILL_DIR}/scripts/convert_to_docx.py --selftest` 列出各引擎
  可用性及将使用的保真度，Stage 1 前建议先跑一次。

---

## Stage 1: 解析招标文件

### 1.1 目标

从招标文件中提取两类信息：
1. **格式要求清单**：章节结构要求、必填项清单、签字盖章规则、字体字号要求、页码要求等
2. **评分表**：评分项、分值、评分标准、客观/主观分类

### 1.2 执行步骤

```bash
# Step 1: 统一格式为 .docx
python {SKILL_DIR}/scripts/convert_to_docx.py \
  --input "{招标文件路径}" \
  --output "{WORK_DIR}/{项目名}_招标文件.docx"

# Step 2: 解析招标文件，提取结构化信息
python {SKILL_DIR}/scripts/parse_bid_document.py \
  --input "{WORK_DIR}/{项目名}_招标文件.docx" \
  --output-json "{WORK_DIR}/{项目名}_招标解析数据.json" \
  --output-md "{WORK_DIR}/{项目名}_招标解析报告.md"

# Step 3: 提取格式要求清单（基于解析数据 + LLM 二次抽取）
python {SKILL_DIR}/scripts/extract_format_requirements.py \
  --input "{WORK_DIR}/{项目名}_招标解析数据.json" \
  --output "{WORK_DIR}/{项目名}_招标要求清单.json"

# Step 4: 提取评分表（LLM 抽取，结构化输出）
python {SKILL_DIR}/scripts/extract_scoring_table.py \
  --input "{WORK_DIR}/{项目名}_招标解析数据.json" \
  --output "{WORK_DIR}/{项目名}_评分表.json"

# Step 5: 提取资格审查要求清单（通用化，不硬编码具体字段名）
#   从第三章资格性审查表 + 第六章资格审查材料，LLM 归纳每条：
#   要求描述 + 投标人须提供的证明材料类型（截图类/声明函类/审计报告类/证书类...）
#   类型由文本归纳，不写死"信用中国/社保"等具体字符串
python {SKILL_DIR}/scripts/extract_qualification_requirements.py \
  --input "{WORK_DIR}/{项目名}_招标解析数据.json" \
  --output "{WORK_DIR}/{项目名}_招标要求清单.json" \
  --append-field "qualification_requirements"

# Step 6: 提取偏离表结构（技术规格条款偏离表 + 商务条款偏离表，行级）
#   识别两张表的位置与行结构（行级，含"招标要求/投标响应/偏离说明"三列），
#   供 Stage 2.7 逐行核对使用
python {SKILL_DIR}/scripts/extract_deviation_tables.py \
  --tender "{WORK_DIR}/{项目名}_招标文件.docx" \
  --bid "{WORK_DIR}/{项目名}_标书.docx" \
  --output "{WORK_DIR}/{项目名}_偏离表原始数据.json"
```

### 1.3 产物文件

1. `{项目名}_招标要求清单.json` — 格式合规要求清单，结构：
```json
{
  "project_info": {
    "项目名称": "...",
    "项目编号": "...",
    "采购人": "...",
    "采购方式": "公开招标/竞争性谈判/..."
  },
  "chapter_requirements": [
    {
      "chapter_id": "ch01",
      "title": "投标函",
      "required": true,
      "must_be_present": true,
      "must_page_break_before": true,
      "evidence_keywords": ["投标函", "致："]
    }
  ],
  "required_fields": [
    {
      "field_id": "f001",
      "label": "项目名称",
      "appears_in": ["投标函", "投标一览表", "封面"],
      "must_be_consistent": true
    }
  ],
  "signature_rules": [
    {
      "rule_id": "s001",
      "context": "投标函",
      "type": "法人签字+公章",
      "must_be_empty": true,
      "warning_if_filled": false
    }
  ],
  "format_rules": [
    {
      "rule_id": "fmt001",
      "type": "font",
      "description": "正文宋体小四",
      "scope": "正文"
    }
  ],
  "qualification_requirements": [
    {
      "req_id": "q001",
      "source": "第三章 资格性审查表 / 第六章 资格审查材料",
      "requirement_text": "投标人须满足的资格审查要求原文（LLM 从招标文本摘取，不改写）",
      "material_type": "website_screenshot",
      "material_hint": "投标人须提供在某网站上的查询记录截图（类型由文本归纳，不写死具体网站名）",
      "is_rejection_clause": true
    },
    {
      "req_id": "q002",
      "source": "第三章 资格性审查表",
      "requirement_text": "提供近一年财务审计报告（或资信证明）",
      "material_type": "audit_report",
      "material_hint": "审计报告 PDF/图片，含四表一注或事务所意见",
      "is_rejection_clause": true
    }
  ]
}
```

> **`qualification_requirements` 通用化约束（强制）**：
> - `material_type` 仅取通用枚举：`website_screenshot` / `audit_report` / `declaration_letter` / `certificate` / `bank_account_permit` / `guarantee_letter` / `sme_declaration` / `other`，**不得写死任何项目专有字符串**（如"信用中国""社保"）。
> - `requirement_text` 必须原样摘取招标文本，LLM 不得概括改写，以保证后续检索关键词准确。
> - `is_rejection_clause=true` 表示该条缺失将导致资格审查不通过（一票否决），Stage 5 据此给 `missing_critical`。

2. `{项目名}_评分表.json` — 评分表，结构：
```json
{
  "total_score": 100,
  "scoring_items": [
    {
      "item_id": "sc001",
      "category": "商务分",
      "title": "投标函格式",
      "max_score": 5,
      "criteria": "投标函格式符合招标文件要求",
      "type": "objective",
      "evidence_keywords": ["投标函"],
      "weight": 1.0
    },
    {
      "item_id": "sc002",
      "category": "技术分",
      "title": "技术方案完整性",
      "max_score": 15,
      "criteria": "方案覆盖招标要求的所有技术点，包括应急响应流程",
      "type": "subjective",
      "evidence_keywords": ["技术方案", "应急响应", "实施方案"],
      "sub_criteria": [
        {"desc": "技术路线清晰", "score": 5},
        {"desc": "实施步骤完整", "score": 5},
        {"desc": "应急响应流程", "score": 5}
      ],
      "weight": 1.0
    }
  ]
}
```

### 1.4 Stage 1 收尾（不暂停）

**展示内容**：
- 项目基本信息（名称、编号、采购人、采购方式）
- 章节要求清单摘要：共 X 个章节，其中 Y 个为必需章节
- 评分表摘要：总分 X 分，共 Y 个评分项（客观分 Z 项 + 主观分 W 项）
- 任何 LLM 抽取过程中的低置信项（收集后在报告对应章节标注『待用户复核』，不暂停）

**展示话术模板（连续进度播报，不暂停）**：
```
✅ Stage 1 完成

📋 招标文件解析结果：
- 项目名称：{xxx}
- 项目编号：{xxx}
- 采购方式：{xxx}
- 必需章节数：{X} 个
- 评分项数：{Y} 个（客观分 {Z} 项 + 主观分 {W} 项）
- 总分：{total} 分

⚠️ 待用户复核项：
- {低置信项1}
- {低置信项2}

➡️ 自动进入 Stage 2（解析标书+建立章节索引）
```

---

## Stage 2: 解析待审核标书 + 建立章节索引

### 2.1 目标

对待审核的标书（可能上百页）做以下处理：
1. **统一格式**为 .docx
2. **扫描章节树**：识别所有标题段落，建立"标题→起止页/字数/正文"映射
3. **生成章节摘要**：每章节用 LLM 生成 200 字内的摘要（用于后续评分项驱动的精读）
4. **建立关键词倒排索引**：所有章节正文建立关键词倒排表（用于精筛）

### 2.2 大文档分段读取策略（核心）

标书可能上百页，模型上下文有限，必须用"评分项驱动的检索增强"策略：

```
全文档（N页，可能 300+）
    ↓
[Step 1] 章节切片（用 python-docx 扫描所有 Heading 段落）
    ↓
章节列表（M个章节，每个 5-30 页）
    ↓
[Step 2] 章节摘要（一次 LLM 调用，所有章节标题+前500字 → 200字摘要）
    ↓
章节摘要表（M 条摘要，每条 200 字）
    ↓
[Step 3] 评分项驱动精读（每个评分项独立调用）
    ↓
    对每个评分项：
      3-1. 摘要粗筛 → 选出 top-10 相关章节
      3-2. 关键词精筛 → 选出 top-3 章节
      3-3. 精读评估 → 只把这 3 个章节的全文喂给 LLM
```

**这种策略的优点**：
- 上下文可控：每个评分项只读 3-5 个章节（5-10K tokens）
- 精准定位：用关键词+摘要双层筛选，避免误读无关章节
- 可解释：每个评分项的评估都附原文引用和章节定位
- 可并行：多个评分项可以并发评估，加速处理

### 2.3 执行步骤

```bash
# Step 1: 统一格式为 .docx
python {SKILL_DIR}/scripts/convert_to_docx.py \
  --input "{标书文件路径}" \
  --output "{WORK_DIR}/{项目名}_标书.docx"

# Step 2: 章节切片（扫描所有 Heading 段落，建立章节树）
python {SKILL_DIR}/scripts/slice_chapters.py \
  --input "{WORK_DIR}/{项目名}_标书.docx" \
  --output "{WORK_DIR}/{项目名}_标书章节索引.json"

# Step 3: 生成章节摘要（LLM 调用）
python {SKILL_DIR}/scripts/generate_chapter_summaries.py \
  --input "{WORK_DIR}/{项目名}_标书章节索引.json" \
  --output "{WORK_DIR}/{项目名}_标书章节摘要.json"

# Step 4: 建立关键词倒排索引
python {SKILL_DIR}/scripts/build_keyword_index.py \
  --input "{WORK_DIR}/{项目名}_标书章节索引.json" \
  --output "{WORK_DIR}/{项目名}_标书关键词索引.json"
```

### 2.4 产物文件

1. `{项目名}_标书章节索引.json` — 章节树，结构：
```json
{
  "doc_path": "...",
  "total_pages": 287,
  "total_words": 156800,
  "chapters": [
    {
      "chapter_id": "ch01",
      "level": 1,
      "title": "投标函",
      "para_index_start": 12,
      "para_index_end": 25,
      "page_start": 3,
      "page_end": 4,
      "word_count": 850,
      "full_text": "..."
    }
  ]
}
```

2. `{项目名}_标书章节摘要.json` — 章节摘要表，结构：
```json
{
  "summaries": [
    {
      "chapter_id": "ch01",
      "title": "投标函",
      "summary": "本章为投标函正文，包含投标人致采购人的函件，落款含法人签字位、公章位、日期位。投标金额为人民币壹佰贰拾万元整。",
      "key_points": ["投标金额120万", "法人签字位", "公章位"]
    }
  ]
}
```

3. `{项目名}_标书关键词索引.json` — 关键词倒排索引（用于精筛），结构：
```json
{
  "index": {
    "投标函": ["ch01"],
    "营业执照": ["ch05", "ch12"],
    "技术方案": ["ch08", "ch09", "ch10"]
  }
}
```

### 2.5 自动进入 Stage 3

Stage 2 完成后，展示进度摘要但不暂停，自动进入 Stage 3：

```
✅ Stage 2 完成

📚 标书索引建立结果：
- 总页数：{X} 页
- 总字数：{Y} 字
- 识别章节数：{M} 个
- 章节摘要已生成

➡️ 自动进入 Stage 3：格式合规比对
```

---

## Stage 2.5: 标⭐️项（关键参数 / 废标条款）检查

### 2.5.1 目标

招标文件中常以 ★ / ⭐ / ☆ 标注「标星项」，或在评分办法中规定「带★指标的加分 / 减分 / 不满足即废标」政策。这类条目一旦不满足，通常是 **废标** 或 **该模块零分**，严重程度远高于一般格式 / 文字问题。故单独成章、详细核查，且 **绝不静默跳过**（无标星项时显式标注「无标星项」，不视为错误）。

### 2.5.2 机器可抽取的维度（脚本覆盖 · check_star_items.py）

| 维度 | 说明 | 严重度 |
|------|------|--------|
| 参数项（关键指标） | 带 ★/⭐ 的技术参数、规格、配置、性能指标 | critical |
| 废标 / 实质性条款 | 带星号的废标、否决、实质性响应条款；**以及虽无星号但含「将被否决 / 无效报价 / 作废 / 不满足即×」等废标关键词的技术条款**（见 2.5.2a 补充检测） | critical |
| 评分加分-减分政策 | 评分办法中「带★每满足加X分 / 不满足扣X分 / 废标」 | critical |

> 抽取覆盖多种星号符号（★ ☆ ⭐ ✩ ✪ 等）以及「星号 / 标星 / 带星 / 关键参数 / 实质性要求」等文字标记；**同时必须扫描招标文件全文中的废标关键词**（见下方 2.5.2a），防止无星号但实质为废标的条款漏检。评分政策自动识别 加分 / 减分 / 废标 动作与分值。
> 投标响应判定：**逐句**匹配（取星号后要求文本在投标文中检索，仅在该句内判定 满足/不满足，避免跨条污染），policy/clause 两类直接标"需复核"交 LLM 确认。

### 2.5.2a 废标条款补充检测（LLM 必做 · 防止无星号废标条款漏检）

> **背景**：2026-07-16 实战发现：某军队采购项目招标文件 P935 写有「供应商提供产品需与整流模块保证无缝衔接（提供承诺函加盖供应商公章）。否则,其投标将被否决。」——该条**不带★符号**，但「否则其投标将被否决」明确是废标条款。`check_star_items.py` 脚本仅按星号/关键词抽取，会漏检此类条款。
>
> **强制规则**：模型在完成 `check_star_items.py` 脚本运行后，**必须额外执行以下 LLM 扫描**（不可跳过，不可仅依赖脚本输出）：

```bash
# 脚本抽取完成后，模型须自行扫描：
# 1. 在招标文件全文中 grep 搜索以下废标关键词模式：
#    - "将被否决" / "作无效报价处理" / "视为不满足" / "不通过资格审查"
#    - "否则.*废标" / "否则.*否决" / "取消中标资格"
#    - "实质性.*不满足" / "必须.*提供.*(承诺函|证明|报告)"
# 2. 对每条命中的句子，判断：
#    a) 是否属于新的废标/否决条款（未在 star_items 中出现）
#    b) 投标文件是否提供了对应的响应材料（承诺函/证明/报告等）
#    c) 若缺失 → 标记为 S-NEW{N}，severity=critical，写入标星项检查Plan.json
# 3. 将检测结果追加到 star_items 数组中，更新 summary 计数
```

> **产物**：新增的条款以 `S-NEW1`、`S-NEW2`…编号追加到 `{项目名}_标星项检查Plan.json` 的 `star_items` 中，`type` 字段为 `"hidden_rejection_clause"`（隐性废标条款）。

### 2.5.3 执行步骤

```bash
# Step1: 机器抽取 + 初判投标响应（支持 .docx / .txt / .doc；.doc 走 olefile 提取）
python {SKILL_DIR}/scripts/check_star_items.py \
  --tender "{WORK_DIR}/{项目名}_招标文件.docx" \
  --bid "{WORK_DIR}/{项目名}_标书.docx" \
  --output "{WORK_DIR}/{项目名}_标星项检查Plan.json"

# Step2: 【LLM 逐条复核】（模型必做，不可跳过）
#   机器仅做抽取与"满足/不满足/需复核"初判；技术规格是否真正满足、
#   废标条款是否被触发、评分政策是否已在得分预估中落实，必须模型通读
#   招标文件与投标响应后逐条确认，将结论写回 Plan 的 bid_response.status
#   与 issues，并置 llm_review_needed=false。此步骤不能用脚本替代。
```

### 2.5.4 产物

`{项目名}_标星项检查Plan.json`：`has_star_items` + `summary`（参数/废标/政策计数 + 投标响应分布 + 关键风险等级）+ `star_items` 明细（`id / type / text / location / policy / bid_response{status,evidence} / severity / llm_review_needed`）。

- 若 `has_star_items=false`：报告第六章显式标注「无标星项」，不视为错误（如梦桃小学项目）。

### 2.5.5 展示（不暂停）

展示标星项概览（按类型计数）与 critical 级 / 不满足项明细，**不暂停，自动进入 Stage 2.6**。最终报告须含「六、标⭐️项（关键参数/废标条款）检查」章节（见报告模板）。凡存在不满足或被触发风险的标星项，须在核心结论中升级为高危提示。

---

## Stage 2.6: 文字错误（错别字）检查

### 2.6.1 目标

对标书全文做文字质量核查，捕获**机器可判定**的错误，并补充**模型语境复核**（捕捉语境相关错误）。标书里的错别字（尤其金额、公司名、废标敏感词）可能改变法律含义，属高风险。

### 2.6.2 可机器判定的维度（脚本覆盖）

| 维度 | 说明 | 严重度 |
|------|------|--------|
| 常见错别字 | 布署→部署、签定→签订、帐目→账目 等词典 | major |
| 异形词/易混词 | 其它→其他、截止→截至、定金→订金（法律效力不同） | minor |
| 叠字/重复字 | 连续相同汉字、整词重复 | minor |
| 中英文标点混用 | 中文文本中的半角 ,.;:!? | minor |
| 金额大小写一致性 | 大写金额（壹…圆…角…分）与小写数字是否相等 | **critical** |
| 专有名词一致性 | 同一公司名/项目名在不同处写法是否一致 | major |

### 2.6.3 执行步骤

```bash
# Step 1: 机器检查（支持 .docx / .txt / .doc）
python {SKILL_DIR}/scripts/check_typos.py \
  --input "{WORK_DIR}/{项目名}_标书.docx" \
  --output "{WORK_DIR}/{项目名}_错别字检查Plan.json"

# Step 2: 【LLM 语境复核】（模型必做，不可跳过）
#   模型通读标书全文，重点核对语境相关错误：的/地/得、做/作、截止/截至、
#   语义反转、废标敏感词误写等，将发现以追加条目写入同一 JSON 的 issues，
#   并置 llm_review_needed=false。此步骤不能用脚本替代。
```

### 2.6.4 产物

`{项目名}_错别字检查Plan.json`：按类型统计 + issues 明细（`id / type / severity / original / suggestion / context / location / confidence`）。

### 2.6.5 展示（不暂停）

展示错别字概览（按类型计数）与 critical 级明细，**不暂停，自动进入 Stage 2.7**。最终报告须含「七、文字错误（错别字）检查」章节（见报告模板）。

---

## Stage 2.7: 偏离表逐行核对（技术偏离 + 商务偏离）【v1.2.0 新增 · v1.2.2 拆双核对】

### 2.7.0 为什么需要本阶段（实战教训）

> **2026-07-16 实战漏检案例 A（技术参数）**：某军队采购项目审核中，投标「技术指标参数响应偏离表」13 行全部自述"无偏离"，但逐项数值比对发现：
> - UPS 电池包高度：招标 ≤98mm，投标 100±2mm → **超标 +2mm**
> - 高频开关电源均流误差：招标 ±3%，投标 ±5% → **实质性偏离**
> - 三相静态转换开关：招标 ≥125A/≤5ms/-10~50°C/≤2000m，投标 100A/≤8ms/0~40°C/≤1000m → **4项偏离（3项实质+1项严重）**
> - 单相静态转换开关：同样 4 项偏离
> - 整流模块无缝衔接承诺函缺失 → **隐性废标条款触发**
>
> **根因**：Stage 2.5 的★检测只做文本匹配；Stage 4 评分预估关注得分而非合规性；整个流程**缺少对技术参数表的逐行拆解和方向性数值比较**。本阶段填补此缺口。

### 2.7.1 目标

对招标文件中的**技术参数/规格要求表**与投标文件中的**技术指标参数响应偏离表**做逐行、逐参数的**语义级数值比对**：

- 拆解复合参数（一行含多个规格 → 拆成独立参数项）
- 判断方向性（≤ 是上限 / ≥ 是下限 / 范围是区间）
- 数值比较（实际值是否在要求范围内）
- 偏离严重度分级（无偏离 / 正偏离 / 轻微负偏离 / 严重负偏离 / 实质性不满足）
- 统计负偏离总数并与招标文件"允许负偏离项数"限制交叉检验
- 触发废标条款时自动升级为核心结论高危提示

### 2.7.1B 目标（商务偏离 · v1.2.2 新增）

对招标文件中的**商务条款**（投标函格式、报价、业绩、资质响应、交货期、质保期、付款条件、授权委托书等）与投标文件中的**商务条款偏离表**（若有）做逐行核对：

- 逐行比对"招标商务要求 / 投标响应 / 偏离说明"三列
- 检测**隐瞒负偏离**：投标填"无偏离"但实质上未满足招标商务条款（如业绩数量不足、资质等级不够、交货期超期）
- 检测**商务实质性条款不满足**：如投标函未按要求签署、报价大写错误、授权书缺法定代表人签字等
- 若本项目招标文件/投标文件**未提供商务偏离表**：显式标注"本项目未提供商务偏离表"，并基于 Stage 1 解析的商务条款要求 + 投标文件实际内容做等价核对（不强行套表，缺表不跳过）

> **强制**：技术偏离（2.7A）与商务偏离（2.7B）的逐行核对结果**都必须逐行写入报告第⑧章**，不得只给汇总或只核技术不管商务。

### 2.7.2 输入数据

| 数据 | 来源 | 格式 |
|------|------|------|
| 招标技术参数表 | 招标文件正文中的采购清单/技术规格表 | 表格文本（通常在 `附件2-4` 或第六/七章） |
| 投标偏离表 | 投标文件「技术指标参数响应偏离表」 | 表格文本（每行 = 一个评审项目） |
| 负偏离限制 | 招标文件说明（通常在参数表末尾） | 如 "非实质性商务和技术参数可分别允许一项负偏离" |

### 2.7.3 执行步骤（LLM 主导 · 脚本辅助）

```bash
# Step 1 (2.7A 技术偏离): 提取技术参数两张表（脚本辅助 — 若 parse_bid_document 已提取则复用）
# 脚本从招标文件 .docx 和投标文件 .docx 中提取表格文本，
# 输出为结构化 JSON（行级）
python {SKILL_DIR}/scripts/extract_tech_param_tables.py \
  --tender "{WORK_DIR}/{项目名}_招标文件.docx" \
  --bid "{WORK_DIR}/{项目名}_标书.docx" \
  --output "{WORK_DIR}/{项目名}_技术参数比对原始数据.json"

# Step 1B (2.7B 商务偏离): 提取商务偏离表（若投标文件存在「商务条款偏离表」）
python {SKILL_DIR}/scripts/extract_deviation_tables.py \
  --tender "{WORK_DIR}/{项目名}_招标文件.docx" \
  --bid "{WORK_DIR}/{项目名}_标书.docx" \
  --table-type "business" \
  --output "{WORK_DIR}/{项目名}_商务偏离比对原始数据.json"
#   ★ 若脚本未找到商务偏离表：不打断流程，置 business_deviation_table_found=false，
#     进入 Step 2B 的等价核对分支（基于 Stage 1 商务条款要求做核对）。

# Step 2A: 【LLM 技术参数逐项数值比对】（核心步骤 · 模型必做 · 不可跳过）
#
# 对每一行评审项目，执行：
#   A) 参数拆解：
#      将 "技术评审要求" 和 "技术参数响应" 两列文本拆解为独立参数元组列表：
#      示例: "长≤530mm、宽≤280mm、高≤230mm"
#           → [("长", "≤", 530, "mm"), ("宽", "≤", 280, "mm"), ("高", "≤", 230, "mm")]
#   B) 方向性判断：
#      ≤ / < / 不超过 / 不高于 → 上限（实际值必须 ≤ 要求值）
#      ≥ / > / 不低于 / 至少   → 下限（实际值必须 ≥ 要求值）
#      范围 A~B               → 区间（实际值必须在 [A,B] 内）
#      等于 / = / 为          → 精确匹配
#   C) 数值提取与比较：
#      从投标响应中提取对应参数的实际值（注意处理 ±公差表示法，如 "100±2mm"）：
#        - 上限约束：取实际值上限（100+2=102）与要求值比 → 102 > 98 → 超标
#        - 下限约束：取实际值下限（100-2=98）与要求值比 → 98 < 125 → 不满足
#        - 区间约束：检查 [实际下限, 实际上限] 是否 ⊆ [要求下限, 要求上限]
#   D) 偏离度判定：
#        - 无偏离：所有参数均在要求范围内
#        - 正偏离（优于要求）：可接受，标注原因
#        - 轻微负偏离：偏差 < 要求值的 5% 或绝对偏差在合理工程容差内
#        - 严重负偏离：偏差明显超差但不一定触发否决
#        - 实质性不满足：该参数被招标文件标记为 ★ 或属于关键指标
#   E) 特殊规则检测：
#        - "原文完全复制询价文件技术要求，作无效报价处理" → 检测是否抄袭式复制
#        - "负偏离应当如实注明" vs 实际填了"无偏离" → 隐瞒负偏离
#
# Step 2B: 【LLM 商务条款逐行核对】（模型必做 · 不可跳过）
#   若 business_deviation_table_found=true：逐行比对商务偏离表三列（招标要求/投标响应/偏离说明），
#     检测隐瞒负偏离与商务实质性条款不满足。
#   若 business_deviation_table_found=false：基于 Stage 1 解析的商务条款要求 +
#     投标文件实际内容做等价核对（投标函签署/报价/业绩/资质/交货期/质保期/授权书等），
#     并在产物与报告中显式标注"本项目未提供商务偏离表，已按招标商务条款做等价核对"。
#
# Step 3: 生成比对结果（技术 + 商务 两部分均写入同一 Plan 文件）
```

### 2.7.4 产物

`{项目名}_技术参数偏离分析Plan.json`（**技术 + 商务 双部分同文件**）：
```json
{
  "check_id": "deviation_20260716",
  "check_time": "2026-07-16T17:00:00",
  "tender_table_summary": { "total_rows": 13, "source": "招标文件第六章/附件2-4" },
  "bid_table_summary": { "total_rows": 13, "source": "投标文件附件2-4" },
  "deviation_limit": { "allowed_negative_deviations_per_category": 1, "text": "非实质性商务和技术参数可分别允许一项负偏离" },
  "comparison_result": {
    "total_params_checked": 78,
    "by_severity": {
      "no_deviation": 55,
      "positive_deviation": 8,
      "minor_negative": 3,
      "severe_negative": 6,
      "substantive_non_compliance": 6
    }
  },
  "items": [
    {
      "row_num": 2,
      "item_name": "UPS电池包蓄电池(12V/7AH)",
      "bid_model": "HS12-7",
      "param_deviations": [
        {
          "param_name": "高度",
          "requirement": { "operator": "≤", "value": 98, "unit": "mm" },
          "actual": { "value": "100±2", "min": 98, "max": 102, "unit": "mm" },
          "deviation_type": "negative",
          "severity": "minor",
          "deviation_amount": "+2mm (上限102 > 要求98)",
          "is_substantive": false,
          "note": "总高100±2mm超出招标高≤98mm要求"
        }
      ],
      "row_verdict": "轻微负偏离",
      "self_claimed": "无偏离",
      "concealment_detected": true
    },
    {
      "row_num": 9,
      "item_name": "三相静态转换开关",
      "bid_model": "HPS-33100",
      "param_deviations": [
        {
          "param_name": "额定电流",
          "requirement": { "operator": "≥", "value": 125, "unit": "A" },
          "actual": { "value": 100, "unit": "A" },
          "deviation_type": "negative",
          "severity": "severe",
          "deviation_amount": "-25A (实际100 < 要求125)",
          "is_substantive": true,
          "note": "额定电流不满足最低要求"
        }
        // ... 其他3个偏离参数
      ],
      "row_verdict": "实质性不满足(4项偏离)",
      "self_claimed": "无偏离",
      "concealment_detected": true
    }
    // ... 其余11行
  ],
  "hidden_rejection_clauses": [
    {
      "id": "HR-1",
      "text": "供应商提供产品需与整流模块保证无缝衔接（提供承诺函加盖供应商公章）。否则,其投标将被否决。",
      "location": "P935",
      "bid_response_found": false,
      "evidence": "技术方案中提及整流模块均流但未找到独立盖章承诺函",
      "verdict": "triggered",
      "severity": "critical"
    }
  ],
  "business_deviation": {
    "business_deviation_table_found": true,
    "table_rows": 6,
    "summary": "商务偏离表 6 行中：5 行无偏离；1 行（业绩数量）投标填'无偏离'但实际仅提供 1 份同类业绩，招标要求近三年至少 2 份 → 隐瞒负偏离",
    "items": [
      {
        "row_num": 4,
        "clause": "近三年同类项目业绩",
        "tender_requirement": "近三年至少 2 份同类业绩",
        "bid_response": "无偏离",
        "actual": "仅提供 1 份同类业绩合同",
        "verdict": "隐瞒负偏离",
        "severity": "major",
        "concealment_detected": true
      }
    ]
  },
  "summary": "技术：13项物资中4项存在参数偏离（共11处），其中实质性不满足6处/严重4处/轻微1处；商务：6行偏离表中1行隐瞒负偏离。负偏离项数超过'允许各1项'限制 → 符合性审查风险极高。",
  "overall_risk_level": "critical",
  "llm_review_needed": false,
  "llm_review_note": "已完成技术+商务逐行核对，每个参数均已方向性校验。"
}
```

### 2.7.5 展示（不暂停）

展示技术参数比对概览（按物资分组 + 偏离严重度统计）**与商务偏离概览**，**凡存在实质性不满足或隐藏的废标条款，必须在核心结论中升级为 P0 高危**。

展示话术模板：
```
📊 Stage 2.7 偏离表逐行核对结果：
【技术偏离 2.7A】
- 比对物资：{N} 项 | 拆解参数：{M} 个
- 无偏离：{n0} | 正偏离：{n1} | 轻微负偏离：{n2} | 严重负偏离：{n3} | 实质性不满足：{n4}
- ⚠️ 偏离表自述"无偏离"但实际检出偏离：{X} 项（隐瞒负偏离风险）
- 🔴 隐性废标条款：{Y} 条
【商务偏离 2.7B】
- 商务偏离表：{found?"找到 "+rows+" 行":"本项目未提供，已按招标商务条款等价核对"}
- 隐瞒负偏离：{b} 项 | 商务实质性不满足：{c} 项
- 📋 偏离明细 Top 5：
  1. {物资名/条款} - {参数/要求}: 要求{req} vs 实际{act} → {severity}
  ...
➡️ 自动进入 Stage 3
```

最终报告须含**「⑧ 技术参数偏离分析」**章节（见报告模板），且**必须同时含「技术偏离逐行表 + 商务偏离逐行表」**（无商务偏离表时显式标注"本项目未提供商务偏离表，已按招标商务条款等价核对"）。凡存在实质性不满足或隐瞒偏离，须在改进建议 P0 中列出具体修改方案（换型号 / 改参数 / 补承诺函 / 补业绩合同）。

---

## Stage 3: 格式合规比对（8 类检查）

### 3.1 8 类格式合规检查

| 序号 | 检查类 | 严重度 | 检查内容 | 复用模块 |
|------|--------|--------|---------|---------|
| ① | 章节完整性 | critical | 招标要求的所有章节是否都有 | `requirement_mapper.detect_fixed_chapters` |
| ② | 章节分页 | major | 每章是否另起一页 | `format_guardrails.ensure_chapter_page_breaks` (检查模式) |
| ③ | 必填项完整性 | critical | 投标函/法人/项目编号/日期等必填项是否填写 | `template_scanner.scan_paragraph_fill_positions` (反向) |
| ④ | 签字盖章位 | critical | 签字/盖章位是否被误填或漏填 | `format_guardrails.verify_signatures_empty` |
| ⑤ | 标签格式 | minor | 冒号空格、占位符残留、字体字号 | `format_guardrails.fix_label_whitespace` (检查模式) + `verify_no_anchor_residue` |
| ⑥ | 图片合规 | major | 图片尺寸是否越界、是否插入正确位置 | `image_format.verify_image_sizing` |
| ⑦ | 字段一致性 | major | 项目名/编号/金额多处出现是否一致 | `matching_engine._match_field` (反向) |
| ⑧ | 资质章节完整性 | major | 资质证明章节是否齐全 | `template_review.detect_qualification_layout` |

### 3.2 执行步骤

```bash
# 综合执行 8 类检查，输出机器可读 Plan
python {SKILL_DIR}/scripts/audit_format_compliance.py \
  --requirements "{WORK_DIR}/{项目名}_招标要求清单.json" \
  --docx "{WORK_DIR}/{项目名}_标书.docx" \
  --chapter-index "{WORK_DIR}/{项目名}_标书章节索引.json" \
  --output "{WORK_DIR}/{项目名}_格式审核Plan.json"
```

### 3.3 产物文件

`{项目名}_格式审核Plan.json` — 机器可读审核 Plan，结构：
```json
{
  "audit_id": "audit_20260716_xxx",
  "audit_time": "2026-07-16T12:00:00",
  "total_checks": 156,
  "passed": 142,
  "failed": 14,
  "failures_by_severity": {
    "critical": 3,
    "major": 5,
    "minor": 4,
    "info": 2
  },
  "items": [
    {
      "check_id": "chk_001",
      "category": "章节完整性",
      "severity": "critical",
      "rule_id": "rule_ch01",
      "requirement": "投标函章节必须存在",
      "actual": "已存在，位于第3-4页",
      "status": "compliant",
      "evidence": "章节索引 ch01",
      "suggestion": null,
      "page_ref": "3-4"
    },
    {
      "check_id": "chk_002",
      "category": "签字盖章位",
      "severity": "critical",
      "rule_id": "rule_s001",
      "requirement": "投标函法人签字位必须留空（待现场签字）",
      "actual": "签字位被填入文字'张三'",
      "status": "non_compliant",
      "evidence": "原文：'法定代表人（签字）：张三'",
      "suggestion": "删除签字位的'张三'，签字位应留空",
      "page_ref": "3"
    }
  ]
}
```

### 3.4 4 级严重度分类

| 级别 | 说明 | 例子 | 处理 |
|------|------|------|------|
| **critical** | 致命违规，可能导致废标 | 必填项空着、签字位被填值、无投标函 | 必须修复 |
| **major** | 重大违规，扣分或废标风险 | 章节未分页、图片越界、关键信息不一致 | 强烈建议修复 |
| **minor** | 轻微违规，扣分 | 标签冒号空格、字体字号不符 | 建议修复 |
| **info** | 提示项，建议优化 | 残留 token、年龄与身份证不符 | 可选修复 |

### 3.5 Stage 3 收尾（不暂停）

**展示内容**：
- 总检查项数 + 通过/失败统计
- 按 4 级严重度分组的失败项摘要（每项含检查项+严重度+位置+建议）
- critical 项必须高亮提示用户优先处理

**展示话术模板（连续进度播报，不暂停）**：
```
✅ Stage 3 完成

🔍 格式合规审核结果：
- 总检查项：{X} 项
- ✅ 通过：{Y} 项
- ❌ 不合规：{Z} 项
  - 🔴 critical（致命）：{a} 项
  - 🟡 major（重大）：{b} 项
  - 🔵 minor（轻微）：{c} 项
  - ⚪ info（提示）：{d} 项

🔴 critical 违规项（必须修复）：
1. {检查项1} — {位置} — {建议}
2. {检查项2} — {位置} — {建议}
...

🟡 major 违规项（强烈建议修复）：
1. {检查项1} — {位置} — {建议}
...

➡️ 自动进入 Stage 4（评分项响应质量评估）
```

---

## Stage 4: 评分项响应质量评估

### 4.1 目标

针对评分表中的每一个评分项，评估标书的响应质量，给出预估得分。区分两类：

1. **客观分项**（type=objective）：核对是否响应（如"提供营业执照"→是/否）
2. **主观分项**（type=subjective）：评估响应质量（如"技术方案完整性"→预估得分+理由）

### 4.2 评分项驱动精读流程

对每个评分项独立执行：

```
评分项 X
  ↓
[Step 4-1] 摘要粗筛
  从章节摘要表中筛选 top-10 相关章节
  （用评分项的 evidence_keywords 匹配章节摘要）
  ↓
[Step 4-2] 关键词精筛
  从 top-10 章节中筛出 top-3 章节
  （用关键词倒排索引 + TF-IDF 排序）
  ↓
[Step 4-3] 精读评估（LLM 调用）
  输入：评分项 + 评分标准 + top-3 章节全文
  输出：是否响应 + 响应质量 + 预估得分 + 扣分理由 + 改进建议
  ↓
[Step 4-4] 客观分项特殊处理
  对资质类客观分项，标记需要 Stage 5 OCR 详细比对的图片
```

### 4.2.1 价格分基准价交互确认（强制 · 不可跳过）

> **规则**：Stage 4 计算"报价分/价格分"之前，**必须**用 `AskUserQuestion` 工具与用户交互，询问本项目其他投标人（竞争对手）的最低报价大约是多少，以此作为"基准价"计算价格分。禁止在不询问用户的情况下，直接用本投标报价或最高限价自行假设基准价。

**交互脚本（每次检查必须执行一次）**：
- **问题**：「您预估本项目其他投标人（除我方外）的最低报价大约为多少？该数值将作为价格分计算的基准价（满足招标文件要求的最低报价）。」
- **选项（6 选 1，用户可自选"其他"填写任意金额）**：
  - **A**：最高限价的 **90%**
  - **B**：最高限价的 **80%**
  - **C**：最高限价的 **70%**
  - **D**：最高限价的 **60%**
  - **E**：最高限价的 **50%**
  - **F**：**自定义**——用户直接填写预估的其他家最低报价金额（元）
- 用户选择后计算 `baseline_price`：
  - 选 A–E：`baseline_price = 最高限价 × 对应比例`
  - 选 F：`baseline_price = 用户填写的金额`
- **用户拒绝回答 / 未提供**：保守按 `baseline_price = 最高限价 × 90%` 计算，并在报告中将该价格分的 `confidence` 标注为 `low`，`confidence_reason` 注明「基准价为保守假设（限价 90%），未获用户确认」。

**价格分计算公式**（与政府采购通用规则一致）：

```
报价分 = (baseline_price / 本投标报价) × 报价满分
```

- 当 `本投标报价 ≤ baseline_price`（我方即最低价）时，报价分 = 满分。
- `baseline_price` 必须写入 `{项目名}_评分预估Plan.json` 的顶层字段 `baseline_price` 与 `price_score_confidence`，供 Stage 6 报告引用与复核。

### 4.3 执行步骤

```bash
# 评分项响应质量评估
python {SKILL_DIR}/scripts/evaluate_scoring_items.py \
  --scoring-table "{WORK_DIR}/{项目名}_评分表.json" \
  --chapter-index "{WORK_DIR}/{项目名}_标书章节索引.json" \
  --chapter-summaries "{WORK_DIR}/{项目名}_标书章节摘要.json" \
  --keyword-index "{WORK_DIR}/{项目名}_标书关键词索引.json" \
  --baseline-price {baseline_price} \
  --bid-price {bid_total} \
  --price-confidence {medium_or_low} \
  --baseline-source {user_A..F 或 conservative_default} \
  --output "{WORK_DIR}/{项目名}_评分预估Plan.json"
```
> **注意**：
> - `--baseline-price` 的值来自 4.2.1 与用户交互得到的 `baseline_price`（竞争对手最低报价预估）。
> - `--bid-price` 的值来自 Stage 1 解析出的本投标报价总额（如 `1,918,289.90`）。
> - `--price-confidence`：用户交互确认填 `medium`，保守默认（限价90%）填 `low`。
> - **未与用户交互、未传入 `--baseline-price` 不得运行本命令**——价格分必须基于用户对竞争对手报价的预估。

### 4.4 产物文件

`{项目名}_评分预估Plan.json` — 评分预估 Plan，结构：
```json
{
  "evaluation_id": "eval_20260716_xxx",
  "evaluation_time": "2026-07-16T12:00:00",
  "total_score": 100,
  "estimated_score": 78,
  "confidence": "medium",
  "confidence_reason": "主观分项预估存在 5-10 分误差",
  "baseline_price": 1731088.25,
  "price_score_confidence": "medium",
  "baseline_price_source": "user_interactive_A(限价90%)",
  "items": [
    {
      "item_id": "sc001",
      "category": "商务分",
      "title": "投标函格式",
      "max_score": 5,
      "estimated_score": 5,
      "type": "objective",
      "response_status": "fully_responded",
      "evidence_chapters": ["ch01"],
      "evidence_text": "投标函章节存在，格式符合要求",
      "page_ref": "3-4",
      "deduction_reasons": [],
      "improvement_suggestions": [],
      "needs_ocr_check": false
    },
    {
      "item_id": "sc002",
      "category": "技术分",
      "title": "技术方案完整性",
      "max_score": 15,
      "estimated_score": 12,
      "type": "subjective",
      "response_status": "partially_responded",
      "evidence_chapters": ["ch08", "ch09", "ch10"],
      "evidence_text": "技术方案章节覆盖了8个技术点中的7个，缺少应急响应流程",
      "page_ref": "45-78",
      "deduction_reasons": [
        {
          "sub_criteria": "应急响应流程",
          "max_score": 5,
          "deducted_score": 3,
          "reason": "未提供应急响应流程章节",
          "suggestion": "在第8章后新增'应急响应流程'章节"
        }
      ],
      "improvement_suggestions": [
        "补充应急响应流程章节，覆盖故障分级、响应时间、升级机制"
      ],
      "needs_ocr_check": false
    },
    {
      "item_id": "sc003",
      "category": "商务分",
      "title": "营业执照（有效期内）",
      "max_score": 5,
      "estimated_score": 5,
      "type": "objective",
      "response_status": "fully_responded",
      "evidence_chapters": ["ch05"],
      "evidence_text": "营业执照图片已插入资质章节",
      "page_ref": "12",
      "deduction_reasons": [],
      "improvement_suggestions": [],
      "needs_ocr_check": true,
      "ocr_check_target": "营业执照有效期、公司名称、统一社会信用代码"
    }
  ]
}
```

### 4.5 响应质量 4 级标准

| 级别 | 说明 | 预估得分率 |
|------|------|-----------|
| **fully_responded** | 完全响应，所有评分点都覆盖 | 90-100% |
| **partially_responded** | 部分响应，覆盖主要评分点但有遗漏 | 60-89% |
| **insufficient_response** | 响应不足，关键评分点缺失 | 30-59% |
| **missing** | 完全缺失 | 0-29% |

### 4.6 置信度评估

| 置信度 | 标准 |
|--------|------|
| **high** | 客观分项全部评估完成 + 主观分项预估误差 <5 分 |
| **medium** | 主观分项预估误差 5-10 分 |
| **low** | 主观分项预估误差 >10 分 或 关键章节无法识别 |

### 4.7 Stage 4 收尾（不暂停）

**展示内容**：
- 预估总分 + 置信度
- 按评分项类别分组（商务分/技术分/价格分/其他）展示
- 每个 critical 扣分点高亮（如"营业执照缺失"扣 5 分）
- 标记需要 Stage 5 OCR 详细比对的评分项
- **价格分计算依据**：展示 `baseline_price`（来源：Stage 4 前置的「竞争对手基准价」AskUserQuestion，即全程 2 次用户交互之②）、计算公式与得分，提醒用户该数值依赖其对竞争对手报价的预估

**展示话术模板（连续进度播报，不暂停）**：
```
✅ Stage 4 完成

📊 评分预估结果：
- 总分：{estimated}/{total} 分
- 置信度：{confidence}（{reason}）

📋 按类别分组：
【商务分】{a}/{b} 分
  - {item1}: {score}/{max} ✅
  - {item2}: {score}/{max} ⚠️ {reason}
  ...

【技术分】{c}/{d} 分
  - {item1}: {score}/{max} ✅
  - {item2}: {score}/{max} ❌ {reason}
  ...

【价格分】{e}/{f} 分
  ...

🔍 需 Stage 5 OCR 详细比对的项：
1. {item1} — {ocr_check_target}
2. {item2} — {ocr_check_target}

➡️ 自动进入 Stage 5（OCR 详细比对 + 视觉核对）
```

---

## Stage 5: OCR 资质详细比对 + 渲染视觉核对

### 5.1 目标

完成两件事：

1. **OCR 资质详细比对**：对 Stage 4 标记为 `needs_ocr_check` 的评分项，OCR 出对应图片的文本，详细核对：
   - 营业执照：有效期、公司名称、统一社会信用代码（与投标人信息一致）
   - 身份证：有效期、姓名、身份证号（与法人/被授权人信息一致）
   - 资质证书：有效期、资质等级（与招标要求一致）
   - 检测报告：报告编号、检测日期（在有效期内）

2. **渲染视觉核对**：渲染标书关键页（封面/签字页/资质页/方案关键页）为 PNG，让模型视觉核对结构层看不到的问题。

### 5.1B 资格审查要求驱动核验（v1.2.2 新增 · 要求清单每一项都必须出现）

> **实战教训（2026-07-16）**：早期版本只 OCR 了 4 项资质（营业执照/身份证/社保/纳税），漏了审计报告、开户许可、信用中国截图等；且用 `page.get_text()` 搜投标文件正文时，因截图是**嵌入图片对象**、文本层不含图内文字，误判"信用中国截图缺失"，实际投标文件 P58–P60 三张图就是合规的信用中国/政府采购网查询截图。**根因：把文本层当成投标文件内容的全部，忘了 PDF 截图是图片对象。**

**通用流程（不硬编码任何具体项目字段）**：

对 Stage 1 解析出的 `qualification_requirements` 数组的**每一条**，都必须在报告第④章出现对应行，检索分两步：

1. **文本检索**：递归遍历投标文件根目录下的**全部 PDF + docx**（含主标书、分页PDF、厂家资料等子目录），在正文文本中检索该要求的关键词（关键词取自 `requirement_text` 原文字）。找到 → 说明"文字层面响应"。
2. **图片检索（关键补丁）**：对文本命中页及相邻页，用 `page.get_images(full=True)` 提取所有嵌入图片并导出为临时 PNG/JPEG；**对导出的图片做视觉核对（Read）确认图内是否为真实证明材料**（网站查询截图需出现对应域名/查询结果；审计报告需出现事务所/审计意见字样等）。
   - **图片确认方式（按用户 2026-07-16 决议：本次先不动）**：若运行环境支持图像识别则自动视觉核对；否则**不强行依赖**，仅标注"图片已提取、待视觉确认"，并以 `needs_review` 呈现，不默认判缺失。
   - **区分"条款复刻"与"真实证明材料"（强制）**：若投标文件某页文本含该要求字段、但对应图片仅是招标条款原文截图/占位符、而非投标人自身证明材料，则**不能判为 compliant**，须标 `needs_review` 或 `missing_critical` 并说明"仅抄写招标要求、未附实际证明材料"。

3. **三态结论**（通用，不依赖具体项目）：
   - ✅ `compliant`：正文或图片中确认提供了对应材料（投标人自身材料）
   - 🔴 `missing_critical`：全投标文件（文本+图片）均无任何该材料痕迹 → 列明"投标文件中未提供"，并**醒目警示一票否决风险**（`is_rejection_clause=true` 时）
   - ⚠️ `needs_review`：找到文字但图片无法确认（加密/低清/环境不支持图像识别）→ 标注待人工复核，**不默认判缺失**

> **强制规则**：`qualification_requirements` 的每一项都必须有报告表行，**绝不允许静默跳过**；即使某项在投标文件中完全找不到，也要以 `missing_critical` 列出并警示——而不是漏掉不干活。

### 5.2 执行步骤

```bash
# Step 1: 抽取标书内嵌图片
python {SKILL_DIR}/scripts/extract_images.py \
  --input "{WORK_DIR}/{项目名}_标书.docx" \
  --output "{WORK_DIR}/{项目名}_标书图片/" \
  --prefix "{项目名}_img"

# Step 2: OCR 详细比对（对 needs_ocr_check 的项）
python {SKILL_DIR}/scripts/ocr_evidence_check.py \
  --evaluation-plan "{WORK_DIR}/{项目名}_评分预估Plan.json" \
  --images-dir "{WORK_DIR}/{项目名}_标书图片/" \
  --requirements "{WORK_DIR}/{项目名}_招标要求清单.json" \
  --output "{WORK_DIR}/{项目名}_OCR比对报告.json"

# Step 2B: 【v1.2.2 新增】资格审查要求驱动核验（每一项都必须出现）
#   递归遍历投标文件全目录 PDF+docx 正文做文本检索；
#   对命中页相邻页提取嵌入图片并导出临时图；
#   按 material_type 通用枚举判定，输出三态结论。
python {SKILL_DIR}/scripts/check_qualification_requirements.py \
  --requirements "{WORK_DIR}/{项目名}_招标要求清单.json" \
  --bid-root "{投标文件根目录}" \
  --output "{WORK_DIR}/{项目名}_OCR比对报告.json" \
  --append-field "qualification_items"

# Step 3: 渲染关键页为 PNG（封面/签字页/资质页/方案关键页）
python {SKILL_DIR}/scripts/render_key_pages.py \
  --docx "{WORK_DIR}/{项目名}_标书.docx" \
  --chapter-index "{WORK_DIR}/{项目名}_标书章节索引.json" \
  --output-dir "{WORK_DIR}/{项目名}_审核预览PNG/" \
  --key-pages "封面,投标函,资质,技术方案首页,签字页"
```

> **`check_qualification_requirements.py` 检索范围约定**：`--bid-root` 指向投标文件根目录，脚本**递归遍历其下所有 `.pdf` 与 `.docx` 文件**（含子目录如分页PDF、厂家资料），不限定固定子目录，以适配任意标书结构。文本检索用 PyMuPDF / python-docx 抽取正文；图片检索用 `page.get_images()` 提取并导出临时图（导出后是否视觉核对取决于环境能力，见 5.1B）。

### 5.3 产物文件

1. `{项目名}_标书图片/` — 抽取出的所有内嵌图片

2. `{项目名}_OCR比对报告.json` — OCR 比对结果，结构：
```json
{
  "ocr_check_id": "ocr_20260716_xxx",
  "checks": [
    {
      "item_id": "sc003",
      "title": "营业执照（有效期内）",
      "image_path": "{项目名}_标书图片/img_012.jpg",
      "ocr_result": {
        "公司名称": "XX科技有限公司",
        "统一社会信用代码": "91110108MA01XX...",
        "营业期限至": "2030-12-31",
        "注册资本": "1000万元"
      },
      "consistency_check": {
        "公司名称与投标人一致": true,
        "统一社会信用代码与填写一致": true,
        "营业期限有效": true
      },
      "issues_found": [],
      "status": "compliant",
      "page_ref": "12"
    },
    {
      "item_id": "sc005",
      "title": "法人身份证",
      "image_path": "{项目名}_标书图片/img_005.jpg",
      "ocr_result": {
        "姓名": "张三",
        "身份证号": "11010819800101XXXX",
        "有效期至": "2025-06-30"
      },
      "consistency_check": {
        "姓名与法人信息一致": true,
        "身份证号与填写一致": true,
        "有效期有效": false
      },
      "issues_found": [
        {
          "issue": "身份证已过期",
          "severity": "critical",
          "detail": "有效期至 2025-06-30，当前日期 2026-07-16，已过期一年"
        }
      ],
      "status": "non_compliant",
      "page_ref": "8"
    }
  ]
}
```

3. `{项目名}_审核预览PNG/` — 渲染的关键页 PNG

4. **`qualification_items`（v1.2.2 新增 · 追加进 OCR 比对报告 JSON）** — 资格审查要求驱动核验结果，结构：
```json
{
  "qualification_items": [
    {
      "item_id": "q001",
      "requirement_text": "投标人须提供在指定网站上的查询记录截图（资格性审查必备）",
      "material_type": "website_screenshot",
      "is_rejection_clause": true,
      "search_scope": "递归遍历投标文件全目录 PDF+docx 正文 + 嵌入图片",
      "text_hit": true,
      "image_extracted": true,
      "status": "compliant",
      "evidence_file": "投标文件 P58-P60 嵌入截图（信用中国失信被执行人/重大税收违法/政府采购网查询截图，查询结果无记录）",
      "consistency_check": { "投标文件含该字段文字": true, "实际附投标人查询截图": true, "满足资格审查要求": true },
      "issues": []
    },
    {
      "item_id": "q002",
      "requirement_text": "提供近一年财务审计报告（或资信证明）",
      "material_type": "audit_report",
      "is_rejection_clause": true,
      "text_hit": true,
      "image_extracted": true,
      "status": "compliant",
      "evidence_file": "审计报告 PDF（标准无保留意见，四表一注齐备）",
      "issues": []
    },
    {
      "item_id": "qXXX",
      "requirement_text": "（某资格审查要求原文）",
      "material_type": "other",
      "is_rejection_clause": true,
      "text_hit": false,
      "image_extracted": false,
      "status": "missing_critical",
      "evidence_file": "全投标文件（文本+图片）均未检索到该材料",
      "consistency_check": { "投标文件含该字段文字": false, "实际附投标人证明材料": false, "满足资格审查要求": false },
      "issues": ["投标文件中未提供该资格审查材料——资格性审查一票否决项，须立即补件"]
    }
  ],
  "summary": "共核验 N 项资格审查要求：M 项合规，K 项缺失(critical)，L 项待人工复核。"
}
```

### 5.4 视觉核对要点

模型读取渲染的 PNG 后，重点核对：
- 封面：项目名称/编号/投标人/日期是否完整
- 投标函：签字位/公章位是否正确
- 资质页：图片是否越界、是否清晰
- 表格页：表格是否挤到下一页、是否完整
- 方案首页：标题层级是否清晰

### 5.5 自动进入 Stage 6

Stage 5 完成后，展示进度摘要但不暂停，自动进入 Stage 6：

```
✅ Stage 5 完成

🖼️ OCR 比对 + 视觉核对结果：
- OCR 比对项：{X} 项
  - ✅ 合规：{Y} 项
  - ❌ 不合规：{Z} 项
- 渲染关键页：{N} 张 PNG
- 视觉发现问题：{M} 处

➡️ 自动进入 Stage 5.5：专项风险检查
```

---

## Stage 5.5: 专项风险检查（价格分一致性 + 抄袭检测）【v1.1.0 新增】

### 5.5.0 目标

完成两项专项风险检查：

1. **价格分一致性检查**：5 项检查（大写金额合规/大小写一致/跨位置一致/分项合计/文字-表格一致）
2. **技术方案抄袭检测**：5 维度检查（残留他人信息/跨章节自重复/与公开资料相似/AI痕迹/引用未署名）

这两项检查是 v1.1.0 新增的高危风险检查，价格不一致和抄袭残留都会直接导致废标。

### 5.5.1 价格分一致性检查

**5 项检查项**：

| 序号 | 检查项 | 严重度 | 检查内容 |
|------|--------|--------|---------|
| ① | 大写金额合规性 | minor | 大写金额必须用规范汉字（壹贰叁...拾佰仟万亿）并以"元整"结尾 |
| ② | 大小写一致性 | critical | 同一处的大写金额和小写金额必须相等 |
| ③ | 跨位置一致性 | critical | 投标函/一览表/报价表/商务标/技术标 里的投标总金额必须完全一致 |
| ④ | 分项合计校验 | critical | 单价×数量=小计，所有小计之和=合计（含 Excel 报价表） |
| ⑤ | 文字-表格一致性 | critical | 正文"投标报价 XX 元"的金额必须与表格金额一致 |

**执行步骤**：

```bash
python {SKILL_DIR}/scripts/check_price_consistency.py \
  --docx "{WORK_DIR}/{项目名}_标书.docx" \
  --chapter-index "{WORK_DIR}/{项目名}_标书章节索引.json" \
  --requirements "{WORK_DIR}/{项目名}_招标要求清单.json" \
  --xlsx "{报价表.xlsx路径，可选}" \
  --output "{WORK_DIR}/{项目名}_价格检查Plan.json"
```

**产物文件**：`{项目名}_价格检查Plan.json`，结构包含：
- 5 项检查的所有结果（compliant/non_compliant）
- 金额汇总（按位置分组的所有金额，最大值）
- 4 级严重度统计

### 5.5.2 技术方案抄袭检测

**5 个维度**：

| 维度 | 检测内容 | 严重度 | 实现方式 |
|------|---------|--------|---------|
| ① 残留他人信息 | 标书中出现其他公司名/项目名/采购人名/历史日期/异地地点 | critical | NER + 正则 |
| ② 跨章节自重复 | 标书内段落两两比对，相似度 ≥60% 报警 | major | N-gram Jaccard |
| ③ 与公开资料相似 | 标书段落调 web-search 检索，相似度 ≥70% 报警 | major | z-ai web-search + web-reader |
| ④ AI 痕迹检测 | 套话密度 ≥5/千字、过渡词重复、结构对仗 | minor | 正则+统计 |
| ⑤ 引用未署名 | "引自/参考/根据"后无完整书名号引用 | info | 正则 |

**执行步骤**：

```bash
python {SKILL_DIR}/scripts/check_plagiarism.py \
  --docx "{WORK_DIR}/{项目名}_标书.docx" \
  --chapter-index "{WORK_DIR}/{项目名}_标书章节索引.json" \
  --requirements "{WORK_DIR}/{项目名}_招标要求清单.json" \
  --output "{WORK_DIR}/{项目名}_抄袭检测Plan.json" \
  --max-searches 20
```

**重要参数**：
- `--no-web-search`：跳过维度③（不调搜索引擎，速度快但漏检网络抄袭）
- `--max-searches N`：控制维度③的检索次数（默认 20，避免 API 限流）

**维度③ 公开资料比对 · 强制兜底规则（不可静默跳过）**：
- 维度③ 默认调用 `z-ai web-search` 检索公开资料；**若本环境 z-ai 不可用（FileNotFoundError / 命令缺失），必须改用本 agent 的 `WebSearch` 工具兜底**，逐段检索标书方案段落与公开网页的相似度。
- **严禁静默跳过**：无论用 z-ai 还是 WebSearch，维度③ 都必须产出真实检索结果或明确的"已跳过 + 原因"标记；`external_similar` 计数为 0 时，必须在报告中显式区分「真干净（已检索）」与「未检索（降级）」——输出 `status` 字段（`searched` / `skipped_no_tool`），**禁止把"未检索"伪装成"无抄袭"**，否则视为检查未完成。
- 检索范围优先级：厂商官网产品手册/规格书 → 招标代理机构历史公告 → 同行公开标书范本 → 技术论坛/文库。

**产物文件**：`{项目名}_抄袭检测Plan.json`，结构包含：
- 5 维度的所有问题列表
- 按维度的统计汇总
- 每个问题含原文引用、位置、严重度、改进建议
- **维度②跨章节自重复、维度③与公开资料相似，必须额外输出逐对明细表**（字段见 5.5.2.1），供 Stage 6 报告渲染详细定位表格

### 5.5.2.1 维度②/③ 输出明细表规格（强制）

维度②（跨章节自重复）与维度③（与公开资料相似）不允许只给"计数"，必须输出**逐对明细**，让用户一眼看懂"哪里和哪里重复了、在第几页、什么内容、风险多高"。

**必含字段**：

| 字段 | 说明 |
|------|------|
| `pair_id` | 重复对编号（D-01, D-02 …） |
| `dimension` | `self_repeat`（维度②）/ `external_similar`（维度③） |
| `content_summary` | 重复内容的原文摘要（首句 / 关键句，≤60 字） |
| `position_a` | 第一次出现位置：**章节名 + 页码 + 行号**（如「技术方案 §8.2 / P56 / L1064」） |
| `position_b` | 第二次出现位置（维度③ 则为「公开来源 URL / 网页标题」） |
| `similarity` | 相似度（0–1，如 0.92）；维度③ 注明检索来源 |
| `risk_level` | 风险等级：`critical` / `major` / `minor` / `info`（见下方映射） |
| `verdict` | 研判建议（如「建议删除 L1064 整段，保留 L1086 版本」） |

**风险等级映射**：

| 相似度 | 风险等级 | 含义 | 建议动作 |
|--------|----------|------|----------|
| ≥ 0.95（近乎完全相同） | **critical** | 整段复制，主观分项会被认定凑字数/抄袭 | 必须删改一处 |
| 0.80–0.95 | **major** | 大段雷同，明显复制粘贴 | 建议大幅改写 |
| 0.60–0.80 | **minor** | 部分雷同，表述高度一致 | 适度改写 |
| < 0.60 | **info** | 共性表述（行业通用话术），可接受 | 可不处理 |

> 维度③ 的 `position_b` 必须是真实检索到的公开网页（标题 + URL），并附原文片段对比；若 `status=skipped_no_tool`，该对标记 `risk_level=info` 且 `verdict` 注明「未检索，需人工复核」。

### 5.5.3 抄袭检测的常见问题

| 场景 | 检测方法 | 典型表现 |
|------|---------|---------|
| 复制其他公司标书 | 维度①残留他人信息 | 出现竞争对手公司名 |
| 复制自己历史标书 | 维度①残留其他项目名 | 出现"XX 局信息化项目"但本项目是"YY 局" |
| 大段抄网络资料 | 维度③公开资料相似 | 与厂商产品手册相似度 ≥70% |
| 同一份标书凑字数 | 维度②跨章节自重复 | 技术方案和实施方案大段相同 |
| AI 生成痕迹明显 | 维度④AI 痕迹 | "在信息化快速发展的今天"+"致力于"等套话密度过高 |
| 引用未注明来源 | 维度⑤引用未署名 | "根据行业最佳实践"但无具体出处 |

### 5.5.4 自动进入 Stage 6

Stage 5.5 完成后，展示进度摘要但不暂停，自动进入 Stage 6：

```
✅ Stage 5.5 完成

💰 价格分一致性检查：
- 总检查项：{X} 项
- ✅ 通过：{Y} 项
- ❌ 不合规：{Z} 项
  - 🔴 critical：{a} 项
  - 🟡 major：{b} 项
  - 🔵 minor：{c} 项

🔍 抄袭检测：
- 总段落数：{N}
- 问题数：{M}
- 按维度：
  - 残留他人信息：{a}
  - 跨章节自重复：{b}（明细见报告第七章《技术方案抄袭检测》D 系列表）
  - 与公开资料相似：{c}（status={searched/skipped_no_tool}；明细见同章）
  - AI 痕迹：{d}
  - 引用未署名：{e}

➡️ 自动进入 Stage 6：生成最终审核报告
```

---

## Stage 6: 生成最终审核报告

### 6.1 目标

把 Stage 3/4/5/5.5 的所有结果汇总成一份 Markdown 审核报告，按以下结构组织：

1. **总体概览**：合规率 + 预估得分 + 置信度
2. **格式合规审核**（按 4 级严重度分组）
3. **评分项预估**（按类别分组 + 总分）
4. **OCR 详细比对**（按图片分组）
5. **视觉核对发现**（按页面分组）
6. **价格分一致性检查**（5 项检查结果）【v1.1.0 新增】
7. **技术方案抄袭检测**（5 维度结果）【v1.1.0 新增】
8. **改进建议**（按优先级排序）

### 6.2 执行步骤

```bash
python {SKILL_DIR}/scripts/generate_audit_report.py \
  --format-plan "{WORK_DIR}/{项目名}_格式审核Plan.json" \
  --scoring-plan "{WORK_DIR}/{项目名}_评分预估Plan.json" \
  --ocr-report "{WORK_DIR}/{项目名}_OCR比对报告.json" \
  --price-plan "{WORK_DIR}/{项目名}_价格检查Plan.json" \
  --plagiarism-plan "{WORK_DIR}/{项目名}_抄袭检测Plan.json" \
  --typo-plan "{WORK_DIR}/{项目名}_错别字检查Plan.json" \
  --star-plan "{WORK_DIR}/{项目名}_标星项检查Plan.json" \
  --chapter-index "{WORK_DIR}/{项目名}_标书章节索引.json" \
  --output "{WORK_DIR}/{项目名}_审核报告.md"
```

### 6.3 产物文件

`{项目名}_审核报告.md` — 最终审核报告（**最终交付物**），结构（**与阶段-报告对照自检严格一致的 11 章，章节编号用 ①~⑪**）：

```markdown
# 标书审核报告

## ① 总体概览

| 指标 | 值 |
|------|-----|
| 项目名称 | {xxx} |
| 项目编号 | {xxx} |
| 审核时间 | 2026-07-16 12:00:00 |
| 标书总页数 | {N} 页 |
| 总字数 | {M} 字 |
| 格式合规率 | 91%（142/156 项通过） |
| 预估得分 | 78/100 分 |
| 置信度 | 中（主观分项预估误差 5-10 分） |
| 整体风险 | 中高 / 中 / 低（含资格审查缺失、偏离风险等） |

## ② 格式合规审核

### 2.1 致命违规（critical）— 3 项

#### 违规 1: 投标函法人签字位被填入文字
- **严重度**：critical
- **位置**：第 3 页
- **招标要求**：法人签字位必须留空（待现场签字）
- **标书实际**：签字位被填入"张三"
- **原文引用**：
  > "法定代表人（签字）：张三"
- **建议**：删除签字位的"张三"，签字位应留空

### 2.2 重大违规（major）— 5 项
...

### 2.3 轻微违规（minor）— 4 项
...

### 2.4 提示项（info）— 2 项
...

## ③ 评分项预估

### 3.1 预估总分：78/100 分（置信度：中）

> **评分办法来源**：基于招标文件真实评分表（解析 Stage 1 提取，含价格分/技术分/商务分权重），逐项打分；非定性估算。若招标文件未含评分表，须在此显式标注「招标文件未解析到评分表，以下为定性低置信评估」。

| 类别 | 满分 | 预估得分 | 得分率 |
|------|------|---------|--------|
| 商务分 | 30 | 28 | 93% |
| 技术分 | 50 | 35 | 70% |
| 价格分 | 20 | 15 | 75% |
| **合计** | **100** | **78** | **78%** |

### 3.2 商务分明细（28/30 分）

| 评分项 | 满分 | 预估 | 状态 |
|--------|------|------|------|
| 投标函格式 | 5 | 5 | ✅ 完全响应 |
| 营业执照 | 5 | 5 | ✅ 完全响应 |
| 财务审计报告 | 5 | 0 | ❌ 缺失 |
| ... | ... | ... | ... |

### 3.3 技术分明细（35/50 分）

#### 评分项：技术方案完整性（15 分，预估 12 分）
- **响应质量**：方案覆盖招标要求的 8 个技术点中的 7 个
- **主要扣分点**：未提供应急响应流程
- **原文引用**：
  > "本方案采用..."（第 45 页）
- **改进建议**：补充应急响应章节，覆盖故障分级、响应时间、升级机制

## ④ OCR 比对（资格审查要求驱动核验）

> **核验范围**：递归遍历投标文件全目录 PDF+docx 正文 + 嵌入图片；对 Stage 1 解析的每条资格审查要求做文本+图片双搜，三态结论（compliant / missing_critical / needs_review）。**要求清单每一项都必须有下表对应行，行数 == 招标解析资格要求条数。**

| # | 资格审查要求（取自招标解析） | 材料类型 | 检索方式（文本+图片） | 结论 | 备注 |
|---|------------------------------|---------|----------------------|------|------|
| Q1 | {要求原文} | website_screenshot | 正文命中 P57 + 提取图片 P58-60 | ✅ compliant | 投标人查询截图，结果无记录 |
| Q2 | {要求原文} | audit_report | 正文命中 + 提取图片 | ✅ compliant | 标准无保留意见 |
| ... | ... | ... | ... | ... | ... |
| **QN** | **{某资格审查要求原文}** | other | 全目录文本+图片均未检索到 | **🔴 missing_critical** | **投标文件中未提供，一票否决，须立即补件** |

**结论**：共核验 N 项，M 项合规、K 项缺失(critical)、L 项待人工复核。缺失项须优先处理。

## ⑤ 视觉核对发现

### 5.1 关键页核对结果

| 页面 | 类型 | 发现问题 |
|------|------|---------|
| 第 1 页 | 封面 | ✅ 无问题 |
| 第 3 页 | 投标函 | ⚠️ 签字位被填 |
| 第 8 页 | 资质页 | ❌ 身份证过期 |
| 第 45 页 | 技术方案首页 | ✅ 无问题 |

## ⑥ 标⭐️项（关键参数/废标条款）检查

### 6.1 标星项概览

| 类别 | 数量 |
|------|------|
| 参数项（关键指标） | {p1} |
| 废标 / 实质性条款 | {p2} |
| 评分加分-减分政策 | {p3} |

- **投标响应**：满足 {m} 项 ｜ 不满足 {n} 项 ｜ 需复核 {r} 项
- **关键风险等级**：{risk}

> 若 `has_star_items=false`：本章显式标注「✅ 本项目招标文件未标注任何 ⭐️（星号）项，亦无星号条款 / 评分加分-减分政策。无标星项专项风险，跳过逐条核查。」（如梦桃小学项目）。**不视为错误。**

### 6.2 标星项明细与响应（必含定位表）

| 编号 | 类型 | 招标文件要求（原文） | 投标响应 | 证据 / 复核提示 |
|------|------|----------------------|---------|--------------------|
| S-001 | 参数项 | {星标参数原文} | ❌ 不满足 | {投标对应段落} |
| S-002 | 废标/实质条款 | {星标废标条款原文} | ⚠️ 需复核 | 请在 LLM 复核中确认未触发此条款 |
| ... | ... | ... | ... | ... |

### 6.3 LLM 逐条复核结论

- 模型已通读招标文件与投标响应，逐条复核标星项（技术规格是否满足、废标条款是否触发、评分政策是否已在得分预估中落实），并更新 6.2 表。
- 若未执行复核，须明确标注「⚠ 未做 LLM 逐条复核，技术规格是否满足等须人工确认」。
- 凡存在不满足或被触发风险项：⚠️ **高危提示**——可能直接导致废标或该模块零分，须优先处理并经模型确认。

## ⑦ 文字错误（错别字）检查

### 7.1 检查概览

| 类型 | 数量 | 严重度分布 |
|------|------|-----------|
| 常见错别字 | {n1} | ... |
| 异形词/易混词 | {n2} | ... |
| 金额大小写不一致 | {n3} | ...（critical，须重点核对） |
| 专有名词一致性 | {n4} | ... |
| 叠字/重复字 | {n5} | ... |
| 中英文标点混用 | {n6} | ... |
| LLM 语境复核追加 | {n7} | ... |

### 7.2 错别字明细（必含定位表）

| 编号 | 类型 | 严重度 | 原文 | 建议 | 位置 / 上下文 |
|------|------|--------|------|------|--------------|
| T-01 | 金额大小写不一致 | critical | {大写金额} | 核对大小写是否一致 | {位置} |
| T-02 | 常见错别字 | major | 签定 | 签订 | {位置} |
| ... | ... | ... | ... | ... | ... |

### 7.3 LLM 语境复核结论

- 模型已通读全文，复核语境相关错误（的/地/得、做/作、语义误用、废标敏感词误写等），追加 {n7} 条（见 7.2 表）。
- 若未执行语境复核，须明确标注「⚠ 未做 LLM 语境复核，可能漏检语境类错误」。

## ⑧ 技术参数偏离分析（技术偏离 + 商务偏离）

### 8.1 技术偏离逐行表（2.7A）

| 行号 | 物资/项目 | 招标要求 | 投标响应 | 偏离说明 | 严重度 | 隐瞒负偏离 |
|------|----------|---------|---------|---------|--------|-----------|
| 1 | UPS电池包 | 高≤98mm | 100±2mm | 超标+2mm | minor | 是（自述无偏离）|
| 9 | 三相静态转换开关 | 额定电流≥125A | 100A | 不满足 | severe | 是 |
| ... | ... | ... | ... | ... | ... | ... |

### 8.2 商务偏离逐行表（2.7B）

> 若本项目投标文件含「商务条款偏离表」：逐行列出招标商务要求/投标响应/偏离说明/严重度/是否隐瞒负偏离。
> 若**未提供商务偏离表**：显式标注「本项目未提供商务偏离表，已按招标商务条款（投标函/报价/业绩/资质/交货期/质保期/授权书等）做等价核对」，并列出等价核对发现。

| 行号 | 商务条款 | 招标要求 | 投标响应 | 偏离说明 | 严重度 | 隐瞒负偏离 |
|------|---------|---------|---------|---------|--------|-----------|
| 4 | 近三年同类业绩 | ≥2 份 | 仅 1 份 | 数量不足 | major | 是（自述无偏离）|
| ... | ... | ... | ... | ... | ... | ... |

### 8.3 偏离汇总 + 隐性废标条款

- 技术偏离：X 项实质性不满足 / Y 项严重 / Z 项轻微；商务偏离：W 项隐瞒负偏离
- 隐性废标条款：{N} 条（如整流模块无缝衔接承诺函缺失）
- 负偏离项数是否超招标限制：{是/否}

## ⑨ 价格分一致性检查

### 9.1 检查概览（5 项）

| 检查项 | 严重度 | 结果 | 说明 |
|--------|--------|------|------|
| 大写金额合规性 | minor | ✅ 通过 | 大写用规范汉字且以"元整"结尾 |
| 大小写一致性 | critical | ✅ 通过 | 同一处大小写金额相等 |
| 跨位置一致性 | critical | ✅ 通过 | 投标函/一览表/报价表/商务/技术标总金额一致 |
| 分项合计校验 | critical | ✅ 通过 | 单价×数量=小计，Σ小计=合计 |
| 文字-表格一致性 | critical | ❌ 不合规 | 正文"XX 元"与报价表不一致 |

### 9.2 价格分计算依据（强制展示）

- **基准价（baseline_price）**：{baseline_price} 元（来源：用户交互选项 {A–F} / 保守假设限价 90%）
- **本投标报价**：{bid_price} 元（低于最高限价：{是/否}）
- **报价满分**：{price_max} 分
- **报价分 = (baseline_price / 本投标报价) × 报价满分 = {price_score} 分**
- **置信度**：{price_score_confidence}（说明：基准价为用户预估/保守假设，实际以开标结果为准）

## ⑩ 技术方案抄袭检测

### 10.1 五维度概览

| 维度 | 问题数 | 严重度分布 | 状态 |
|------|--------|-----------|------|
| ① 残留他人信息 | {a} | ... | ... |
| ② 跨章节自重复 | {b} | ... | ... |
| ③ 与公开资料相似 | {c} | ... | {searched / skipped_no_tool} |
| ④ AI 痕迹 | {d} | ... | ... |
| ⑤ 引用未署名 | {e} | ... | ... |

### 10.2 跨章节自重复明细（维度② · 必含定位表）

| 编号 | 内容摘要 | 位置 A（章节/页/行） | 位置 B（章节/页/行） | 相似度 | 风险等级 | 研判建议 |
|------|---------|---------------------|---------------------|--------|----------|----------|
| D-01 | {重复内容首句 ≤60 字} | 技术方案 §8.2 / P56 / L1064 | 实施方案 §9.1 / P78 / L1587 | 1.00 | critical | 建议删除 L1064 整段，保留 L1587 |
| ... | ... | ... | ... | ... | ... | ... |

### 10.3 与公开资料相似明细（维度③ · 必含来源表）

| 编号 | 内容摘要 | 标书位置（章节/页/行） | 公开来源（标题 + URL） | 相似度 | 风险等级 | 研判建议 |
|------|---------|----------------------|----------------------|--------|----------|----------|
| E-01 | {摘要 ≤60 字} | 质保方案 §9.4 / P90 / L1959 | {厂商产品手册网页标题 + URL} | 0.78 | major | 建议改写并标注来源 |
| ... | ... | ... | ... | ... | ... | ... |

> **维度③ 状态警示**：若 `status=skipped_no_tool`（本环境未检索公开资料），10.3 表仅列"待检索"项，必须明确提示「本环境未检索公开资料，相似度未核验，需人工复核」，**禁止写成"无抄袭"**。若 `status=searched` 且计数为 0，方可写「已检索公开资料，未发现高相似内容」。

## ⑪ 改进建议（按优先级排序）

### P0 - 必须修复（critical）
1. 删除投标函签字位的"张三"
2. 更换过期的法人身份证
3. 补某资格审查材料（缺失一票否决项）
4. ...

### P1 - 强烈建议修复（major）
1. 第 5 章前插入分页符
2. 补充财务审计报告
3. ...

### P2 - 建议修复（minor）
1. 清理标签冒号后多余空格
2. ...

### P3 - 可选优化（info）
1. 清理残留 [[FILL:]] 标记
2. ...
```

### 6.4 Stage 6 收尾（报告交付，不暂停）

**展示内容**：
- 最终审核报告文件路径
- 报告核心结论（合规率 + 预估得分 + 关键风险点）
- 后续操作建议（导出 Excel / 生成修复版标书等）在最终回复中以纯文本提供，不阻塞、不等待

**展示话术模板（连续进度播报，不暂停）**：
```
✅ Stage 6 完成

📄 最终审核报告已生成：
- 路径：{WORK_DIR}/{项目名}_审核报告.md
- 大小：{size} KB

🎯 核心结论：
- 格式合规率：91%
- 预估得分：78/100 分（置信度：中）
- 主要风险：3 项 critical 违规 + 1 项 OCR 不合规

🚨 建议优先修复：
1. {critical_1}
2. {critical_2}
3. {critical_3}

➡️ 审核已完成。以下为可选后续操作（在最终回复中以纯文本列出，不阻塞、不等待）：
- 导出 Excel：将审核结果导出为 Excel 清单
- 生成修复建议：生成详细的修复操作指南
- 重新审核：调整规则后重新审核
```

---

## 附录 A：外部依赖

### 必需依赖

| 依赖 | 用途 | 缺失时行为 |
|------|------|-----------|
| python-docx | 解析 .docx 文件 | 直接报错，无法启动 |
| pdfplumber | 解析 PDF 文件 | 直接报错，无法启动 |
| Pillow | 图片处理 | 直接报错，无法启动 |
| openpyxl | Excel 处理 | 直接报错，无法启动 |
| lxml | XML 解析 | 直接报错，无法启动 |
| PyYAML | 配置文件 | 直接报错，无法启动 |

### 可选依赖

| 依赖 | 用途 | 缺失时行为 |
|------|------|-----------|
| z-ai CLI | LLM 调用（章节摘要、评分项评估） | 跳过 LLM 评估，仅做规则检查 |
| RapidOCR（本地，无需 API） | 资质文件 OCR | 跳过 OCR 比对，标注"OCR 不可用"，改用规则/关键词兜底 |
| pdf2docx | PDF→Word 转换 | 降级到 pdfplumber 重建（保真度低） |
| MS Word COM | .doc→.docx 转换（保真度最高） | 降级到下一引擎（WPS / LibreOffice / Aspose） |
| WPS COM | .doc→.docx 转换（国产 Office 常见） | 降级到下一引擎 |
| LibreOffice | .doc→.docx 转换 + 渲染 | 降级到 Aspose / 仅文本兜底（显式标注有损） |
| Aspose.Words | .doc→.docx 转换（pip 可装，程序化） | 降级到仅文本兜底（显式标注有损） |
| olefile / antiword | .doc 仅文本提取（最后兜底） | 结构有损，涉及表格的结论须人工复核 |
| Microsoft Word | 渲染（最佳保真度） | 降级到 LibreOffice |
| PyMuPDF (fitz) | PDF→PNG 渲染 | 跳过视觉核对 |

### 启动自检命令

```bash
# OCR 自检
python {SKILL_DIR}/scripts/ocr_selftest.py

# 渲染器自检
python -c "from bid_checker.core.renderer import detect_renderer; print(detect_renderer())"

# 文档转换自检
python {SKILL_DIR}/scripts/convert_to_docx.py --selftest
```

---

## 附录 B：与 bid-document-maker 的关系

| 维度 | bid-document-maker（旧） | bid-checker-pro（新） |
|------|--------------------------|----------------------|
| 核心理念 | AI 帮你**填**标书 | AI 帮你**查**标书 |
| 输入 | 招标文件 + 用户资料 | 招标文件 + 已完成的标书 |
| 输出 | 填充完成的标书 .docx | 审核报告 .md |
| 复用模块 | format_guardrails、parse_bid_document、convert_to_docx、ocr_engine、renderer、material_normalizer | 同左（共享前半段） |
| 差异模块 | stage4_fill_plan（填充执行器）、generate_framework_v5（框架生成） | evaluate_scoring_items（评分评估器）、ocr_evidence_check（OCR比对）、generate_audit_report（报告生成） |
| 触发场景 | "帮我做标书"、"生成响应文件" | "帮我查标书"、"审核标书" |

---

## 附录 C：常见问题

### Q1: 标书是 PDF 怎么办？
A: 自动调用 `convert_to_docx.py` 转 .docx，保真度可能下降。建议用户提供 .docx 原件。

### Q1.5: 标书是 .doc 老格式，转换会丢内容吗？
A: 不会轻易丢。转换按「MS Word COM → WPS COM → LibreOffice → Aspose.Words」高保真引擎
顺序尝试，**绝大多数用户电脑装有 Office / WPS**，可直接保真转换；沙箱也能
`pip install aspose-words`。仅当所有高保真引擎都不可用才落「仅文本兜底」（结构有损，
会显式告警并要求人工复核表格）。可先跑 `convert_to_docx.py --selftest` 自查。

### Q2: 标书有几百页，能审完吗？
A: 能。Stage 2 的"评分项驱动精读"策略会把上百页标书拆成章节切片，每个评分项只读 3-5 个相关章节，不会超长。

### Q3: OCR 不可用怎么办？
A: Stage 5 会跳过图片 OCR 详细比对，标注"OCR 不可用"，并自动改用规则/关键词兜底。如需启用本地 OCR，运行 `pip install rapidocr-onnxruntime onnxruntime`（无需任何 API 密钥）。

### Q4: 审核结果可信吗？
A: 格式合规检查是规则驱动的，可信度 100%。评分预估是 LLM 驱动的，置信度为中（主观分项预估误差 5-10 分），仅供参考。

### Q5: 审核后能直接修复吗？
A: 不能。本技能只检查不修复。如需修复，建议使用 bid-document-maker 重新生成相关章节。

### Q6: 多个评分项预估可以并行吗？
A: 可以。Stage 4 的 `evaluate_scoring_items.py` 支持 `--parallel N` 参数，N 为并发数。建议 N=3-5（避免 LLM API 限流）。
