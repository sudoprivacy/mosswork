# bid-checker-pro v1.1.0 — 标书审核专家

> **核心理念**：不是"AI替你重写标书"，而是"AI帮你审标书"——读招标文件抽要求+评分表，分段精读标书建索引，逐项核对格式合规性+评分项响应质量+价格分一致性+技术方案抄袭风险，输出带原文定位的Markdown审核报告。

## v1.1.0 新功能

- 🆕 **Stage 5.5: 价格分一致性检查**（5 项检查）
  - 大写金额合规性
  - 大小写一致性
  - 跨位置一致性（投标函/一览表/报价表/商务标/技术标）
  - 分项合计校验（含 Excel 报价表解析）
  - 文字-表格一致性
- 🆕 **Stage 5.5: 技术方案抄袭检测**（5 维度）
  - 残留他人信息检测（公司名/项目名/历史日期/异地地点）
  - 跨章节自重复检测（N-gram Jaccard 相似度）
  - 与公开资料相似度检测（调用 z-ai web-search + web-reader）
  - AI 痕迹检测（套话密度/过渡词/结构对仗，宽松阈值）
  - 引用未署名检测

## 适用场景

- ✅ 政府采购、工程类、IT信息化项目标书审核
- ✅ 标书格式合规检查（8 类检查项）
- ✅ 评分项响应质量评估（含主观分预估）
- ✅ 资质文件 OCR 详细比对
- ✅ 上百页大文档分段精读
- ✅ Word + PDF 混合输入

## 与 bid-document-maker 的区别

| 维度 | bid-document-maker | bid-checker-pro |
|------|-------------------|-----------------|
| 核心理念 | AI 帮你**填**标书 | AI 帮你**查**标书 |
| 输入 | 招标文件 + 用户资料 | 招标文件 + 已完成的标书 |
| 输出 | 填充完成的标书 .docx | 审核报告 .md |
| 触发场景 | "帮我做标书" | "帮我查标书" |

## 6 阶段审核流程

```
Stage 1: 解析招标文件（提取格式要求+评分表）
  ⏸️ 门控1: 确认要求清单+评分表
       ↓
Stage 2: 解析待审核标书（建立章节索引+摘要+关键词索引）
       ↓（自动推进）
Stage 3: 格式合规比对（8 类检查）
  ⏸️ 门控2: 确认格式违规清单
       ↓
Stage 4: 评分项响应质量评估（含主观分预估）
  ⏸️ 门控3: 确认评分预估结果
       ↓
Stage 5: OCR 资质详细比对 + 渲染视觉核对
       ↓（自动推进）
Stage 6: 生成最终审核报告（.md）
  ⏸️ 门控4: 报告交付确认
```

## 8 类格式合规检查

| 序号 | 检查类 | 严重度 | 检查内容 |
|------|--------|--------|---------|
| ① | 章节完整性 | critical | 招标要求的所有章节是否都有 |
| ② | 章节分页 | major | 每章是否另起一页 |
| ③ | 必填项完整性 | critical | 投标函/法人/项目编号/日期等必填项是否填写 |
| ④ | 签字盖章位 | critical | 签字/盖章位是否被误填或漏填 |
| ⑤ | 标签格式 | minor | 冒号空格、占位符残留、字体字号 |
| ⑥ | 图片合规 | major | 图片尺寸是否越界、是否插入正确位置 |
| ⑦ | 字段一致性 | major | 项目名/编号/金额多处出现是否一致 |
| ⑧ | 资质章节完整性 | major | 资质证明章节是否齐全 |

## 4 级严重度分类

| 级别 | 说明 | 处理 |
|------|------|------|
| 🔴 critical | 致命违规，可能导致废标 | 必须修复 |
| 🟡 major | 重大违规，扣分或废标风险 | 强烈建议修复 |
| 🔵 minor | 轻微违规，扣分 | 建议修复 |
| ⚪ info | 提示项，建议优化 | 可选修复 |

## 大文档分段读取策略

针对上百页标书，采用"评分项驱动的检索增强"策略：

```
全文档（N页，可能 300+）
    ↓
[Step 1] 章节切片（用 python-docx 扫描所有 Heading 段落）
    ↓
[Step 2] 章节摘要（一次 LLM 调用，所有章节标题+前500字 → 200字摘要）
    ↓
[Step 3] 评分项驱动精读（每个评分项独立调用）
    3-1. 摘要粗筛 → top-10 相关章节
    3-2. 关键词精筛 → top-3 章节
    3-3. 精读评估 → 只把这 3 个章节的全文喂给 LLM
```

## 目录结构

```
bid-checker-pro/
├── SKILL.md                          # 技能主文档（6阶段+4门控）
├── EXPERIENCES.md                    # 经验案例库（E1-E25）
├── README.md                         # 本文件
├── requirements.txt                  # Python 依赖
│
├── scripts/                          # 执行脚本
│   ├── convert_to_docx.py            # 文档格式统一（复用）
│   ├── pdf_to_word.py                # PDF转Word（复用）
│   ├── parse_bid_document.py         # 招标文件解析（复用）
│   ├── ocr_selftest.py               # OCR 自检（复用）
│   ├── material_deep_scanner.py      # 资料深度扫描（复用）
│   ├── template_scanner.py           # 模板扫描（复用，反向使用）
│   ├── matching_engine.py            # 匹配引擎（复用 FIELD_ALIAS_MAP）
│   ├── extract_format_requirements.py # 【新增】格式要求提取
│   ├── extract_scoring_table.py      # 【新增】评分表提取
│   ├── slice_chapters.py             # 【新增】章节切片
│   ├── generate_chapter_summaries.py # 【新增】章节摘要生成
│   ├── build_keyword_index.py        # 【新增】关键词倒排索引
│   ├── audit_format_compliance.py    # 【新增】8类格式合规检查
│   ├── evaluate_scoring_items.py     # 【新增】评分项响应质量评估
│   ├── ocr_evidence_check.py         # 【新增】OCR 资质详细比对
│   ├── render_key_pages.py           # 【新增】关键页渲染
│   └── generate_audit_report.py      # 【新增】审核报告生成
│
├── bid_checker/                      # Python 包
│   ├── core/
│   │   ├── format_guardrails.py      # 格式护栏（复用，6条不变量）
│   │   ├── image_format.py           # 图片格式（复用，verify_image_sizing）
│   │   ├── ocr_engine.py             # OCR 引擎（复用，双引擎）
│   │   ├── renderer.py               # 渲染器（复用）
│   │   ├── hitl_review.py            # HITL 确认（复用）
│   │   ├── template_review.py        # 资质章节识别（复用）
│   │   ├── extract_images.py         # 图片抽取（复用）
│   │   ├── material_normalizer.py    # 资料规范化（复用）
│   │   ├── source_material.py        # 源资料读取（复用）
│   │   ├── requirement_mapper.py     # 需求映射（复用 CHAPTER_KEYWORD_MAP）
│   │   ├── fill_plan.py              # 填充计划（复用 LABEL_RULES）
│   │   └── interactive_fill.py       # 交互填充（复用优先级分类）
│   └── utils/
│       ├── logger.py                 # 统一日志（复用）
│       └── doc_to_docx.py            # doc转docx（复用）
│
├── config/
│   ├── audit_rules.yaml              # 审核规则配置（核心）
│   ├── project_config_template.json  # 项目配置模板
│   └── ocr_config.example.json       # OCR 配置示例
│
├── tests/                            # 测试套件
│   ├── test_no_bare_except.py        # 守护测试
│   ├── test_dataclass_integrity.py   # 守护测试
│   └── ...                           # 行为契约测试
│
├── references/                       # 参考文档
└── assets/                           # 静态资源
```

## 安装

### 1. 安装 Python 依赖

```bash
pip install -r requirements.txt
```

### 2. 配置 OCR（本地，无需密钥）

本技能 OCR 使用本地 **RapidOCR** 引擎（基于 ONNX Runtime），**无需任何 API 密钥、无需注册、无需联网**。

首次运行会自动安装 `rapidocr-onnxruntime` + `onnxruntime` 并下载 ONNX 模型；也可提前手动安装：

```bash
pip install rapidocr-onnxruntime onnxruntime
```

> 注：早期版本使用 PaddleOCR，但 PaddleOCR 依赖的 paddlepaddle 3.x 在 Python 3.13 上存在 OneDNN/PIR 推理兼容性问题（无法降级到 2.6.2，因其无 3.13 轮子），故 v11 改用 RapidOCR（纯 ONNX，仅依赖 onnxruntime，CPU 即可，Python 3.13 原生可用）。

如需自定义配置，可复制 `config/ocr_config.example.json` 为 `config/ocr_config.json`（默认即本地 RapidOCR，无需填写任何密钥）。RapidOCR 不可用时，Stage 5 资质图片 OCR 比对自动降级为规则/关键词兜底，并在报告中标注。

### 3. 安装渲染器（视觉核对需要）

- **Windows**：安装 Microsoft Office
- **Linux/Mac**：安装 LibreOffice
  ```bash
  # Ubuntu/Debian
  sudo apt install libreoffice
  
  # Mac
  brew install libreoffice
  ```

### 4. 启动自检

```bash
# OCR 自检
python scripts/ocr_selftest.py

# 渲染器自检
python -c "from bid_checker.core.renderer import detect_renderer; print(detect_renderer())"
```

## 使用方式

在 WorkBuddy 中说：

> "帮我检查这份标书，招标文件是 xxx.docx，标书是 yyy.docx"

或更具体：

> "审核一下这份投标文件，预估能拿多少分"

技能会自动触发，按 6 阶段流程执行，每阶段门控等待用户确认。

## 输出文件

所有产物文件保存在 `{WORK_DIR}/` 下：

| 文件 | 阶段 | 说明 |
|------|------|------|
| `{项目名}_招标要求清单.json` | Stage 1 | 招标文件格式要求清单 |
| `{项目名}_评分表.json` | Stage 1 | 评分表（含主观分） |
| `{项目名}_标书章节索引.json` | Stage 2 | 标书章节树 |
| `{项目名}_标书章节摘要.json` | Stage 2 | 章节摘要（200字内） |
| `{项目名}_标书关键词索引.json` | Stage 2 | 关键词倒排索引 |
| `{项目名}_格式审核Plan.json` | Stage 3 | 8类格式合规检查结果 |
| `{项目名}_评分预估Plan.json` | Stage 4 | 评分项响应质量评估 |
| `{项目名}_OCR比对报告.json` | Stage 5 | OCR 资质详细比对 |
| `{项目名}_审核预览PNG/` | Stage 5 | 关键页渲染 PNG |
| **`{项目名}_审核报告.md`** | **Stage 6** | **最终审核报告（最终交付）** |

## 常见问题

### Q: 标书是 PDF 怎么办？
A: 自动调用 `convert_to_docx.py` 转 .docx，保真度可能下降。建议用户提供 .docx 原件。

### Q: 标书有几百页，能审完吗？
A: 能。Stage 2 的"评分项驱动精读"策略会把上百页标书拆成章节切片，每个评分项只读 3-5 个相关章节，不会超长。

### Q: OCR 不可用怎么办？
A: Stage 5 会跳过图片 OCR 详细比对，标注"OCR 不可用"，并自动改用规则/关键词兜底。如需启用本地 OCR，运行 `pip install rapidocr-onnxruntime onnxruntime`（无需任何 API 密钥）。

### Q: 审核结果可信吗？
A: 格式合规检查是规则驱动的，可信度 100%。评分预估是 LLM 驱动的，置信度为中（主观分项预估误差 5-10 分），仅供参考。

### Q: 审核后能直接修复吗？
A: 不能。本技能只检查不修复。如需修复，建议使用 bid-document-maker 重新生成相关章节。

## 版本历史

- **v1.1.0** (2026-07-16)：新增 Stage 5.5 价格分一致性检查（5 项）+ 技术方案抄袭检测（5 维度，含 web-search 调用）
- v1.0.0 (2026-07-16)：首发版本，6 阶段审核流程，8 类格式合规检查，评分项响应质量评估，OCR 详细比对

## 致谢

本技能的格式护栏、文档解析、OCR 引擎、渲染器、HITL 确认等核心模块复用自 `bid-document-maker v20.3.1`，特此致谢。
