---
name: skillhub-skill-us-patent-prior-art-analysis
description: "Analyze patent claims against prior art using 35 U.S.C. 102/103 framework. Use when the user wants prior art analysis, novelty assessment, or obviousness evaluation. 按 35 U.S.C. 102（新颖性）与 103（显而易见性）完整框架分析独立权利要求，含 Graham 因素与 KSR 论证路径。"
---

# Prior Art Analysis

Analyze independent patent claims against prior art using the full 35 U.S.C. 102 (anticipation) and 103 (obviousness) framework, including Graham v. John Deere factors and KSR rationales.

This skill benefits from **web search** to find relevant prior art references.

## Instructions

1. Read the instruction file at `${CLAUDE_SKILL_DIR}/references/prompt.md`
2. Ask the user for the required inputs if not already provided via `$ARGUMENTS`:
   - **Patent claims** (independent claims to analyze)
   - **Known prior art** (optional)
   - **Web search results** (optional, or use web search tool if available)
3. Fill in the `{{PLACEHOLDER}}` values with the user's content
4. If web search is available, search for relevant prior art references
5. Execute the prompt to perform the analysis
6. Present the output to the user

## Inputs

| Placeholder | What to put here |
|---|---|
| `{{INDEPENDENT_CLAIMS}}` | The independent claims to analyze. Include full claim text with claim numbers. Only independent claims — do not include dependent claims. |
| `{{WEB_SEARCH_RESULTS}}` | Results from web searches for prior art (e.g., Google Patents, USPTO, Google Scholar, Espacenet). If your LLM has built-in web search, you can leave this placeholder empty and instruct the model to search. |

## Attribution

Adapted from **arcprime-ip/patent-prompts** (MIT License) by ArcPrime — <https://github.com/arcprime-ip/patent-prompts>.
Original prompt text is reproduced with the license notice retained. Modifications: repackaged into a
standalone skill with `references/prompt.md`, bilingual description, and SkillHub metadata.

> This skill produces an analytical aid, not legal advice. Always have a qualified patent
> professional review any output before relying on it.

## Scope

Written for **US patent practice** — USPTO filing and prosecution, 35 U.S.C. §§ 101/102/103/112,
Alice/Mayo eligibility, Graham/KSR obviousness. For CNIPA or EPO practice, the statutory
frameworks differ and the analysis must be adapted.
