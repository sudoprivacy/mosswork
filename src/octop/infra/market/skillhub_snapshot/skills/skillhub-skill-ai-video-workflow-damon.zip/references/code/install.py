# -*- coding: utf-8 -*-
"""
标准视频工作流 统一环境检查脚本
================================
- 第一次使用前(或换了机器)运行一次,自动检测/安装 ffmpeg + Python 依赖。
- 幂等:重复跑不会覆盖/破坏已装环境。
- Windows 优先(本包是 Win 流水);Mac/Linux 大体能跑,部分字体/路径会回退到默认。

用法:
    python install.py            # 全自动检测+安装
    python install.py --check    # 只检查不装,缺则报错退出
    python install.py --verbose  # 打印每个子步骤的输出
"""
from __future__ import annotations
import os
import sys
import shutil
import subprocess
import argparse
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
IS_WIN = platform.system() == "Windows"

# ---------- 依赖表 ----------
PY_DEPS_CORE = [
    ("Pillow", "PIL", "图像处理"),
    ("edge-tts", "edge_tts", "微软免费 TTS"),
    ("imageio-ffmpeg", "imageio_ffmpeg", "内嵌 ffmpeg 兜底"),
    ("numpy", "numpy", "数值计算"),
]
PY_DEPS_OPTIONAL = [
    ("opencv-python", "cv2", "图像识别(字幕定位等)"),
    ("moviepy", "moviepy", "高级剪辑(可选)"),
    ("whisper", "whisper", "字幕对齐(可选,体积大)"),
]

# ---------- 工具函数 ----------
def color(s, c):
    if not sys.stdout.isatty() and "NO_COLOR" not in os.environ:
        return s
    return {
        "g": f"\033[32m{s}\033[0m",
        "y": f"\033[33m{s}\033[0m",
        "r": f"\033[31m{s}\033[0m",
        "b": f"\033[36m{s}\033[0m",
        "B": f"\033[1m{s}\033[0m",
    }.get(c, s)

def step(msg):
    print(f"\n{color('▶', 'b')} {color(msg, 'B')}")

def ok(msg):
    print(f"  {color('✓', 'g')} {msg}")

def warn(msg):
    print(f"  {color('!', 'y')} {msg}")

def fail(msg):
    print(f"  {color('✗', 'r')} {msg}")

def run(cmd, verbose=False, check=True, capture=True):
    """Run a shell command, return CompletedProcess."""
    if verbose:
        print(f"    $ {cmd if isinstance(cmd, str) else ' '.join(cmd)}")
    try:
        r = subprocess.run(
            cmd, shell=isinstance(cmd, str),
            capture_output=capture, text=True,
            check=check, timeout=600,
        )
        return r
    except subprocess.CalledProcessError as e:
        return e
    except Exception as e:
        fail(f"执行失败: {e}")
        return None

def pip_install(pkg, verbose=False):
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", pkg]
    return run(cmd, verbose=verbose, check=False, capture=not verbose)

# ---------- 检测/安装:ffmpeg ----------
def find_ffmpeg():
    """Try: PATH → imageio_ffmpeg."""
    # 1. PATH
    p = shutil.which("ffmpeg")
    if p and Path(p).exists():
        return p
    # 2. imageio_ffmpeg
    try:
        import imageio_ffmpeg
        p = imageio_ffmpeg.get_ffmpeg_exe()
        if p and Path(p).exists():
            return p
    except ImportError:
        pass
    return None

def install_imageio_ffmpeg(verbose=False):
    r = pip_install("imageio-ffmpeg", verbose=verbose)
    if r and r.returncode == 0:
        try:
            import imageio_ffmpeg
            p = imageio_ffmpeg.get_ffmpeg_exe()
            if p and Path(p).exists():
                return p
        except Exception as e:
            fail(f"imageio-ffmpeg 装上了但取路径失败: {e}")
    return None

def install_ffmpeg_winget(verbose=False):
    if not IS_WIN:
        return None
    if not shutil.which("winget"):
        warn("系统无 winget,无法自动装系统级 ffmpeg")
        return None
    print("    正在通过 winget 安装 ffmpeg (Gyan 渠道)...")
    r = run(
        ["winget", "install", "-e", "--id", "Gyan.FFmpeg",
         "--source", "winget", "--accept-package-agreements",
         "--accept-source-agreements"],
        verbose=verbose, check=False, capture=not verbose,
    )
    if r and r.returncode == 0:
        # winget 默认装到用户 AppData
        candidates = [
            Path(os.environ.get("LOCALAPPDATA", "")) /
                "Microsoft/WinGet/Packages/Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe",
        ]
        for c in candidates:
            if c.exists():
                ff = list(c.rglob("ffmpeg.exe"))
                if ff:
                    return str(ff[0])
    return None

def ensure_ffmpeg(check_only=False, verbose=False):
    step("检测 ffmpeg")
    p = find_ffmpeg()
    if p:
        ok(f"已就绪: {p}")
        return p
    warn("未检测到 ffmpeg,尝试自动安装")
    if check_only:
        fail("check 模式下不自动安装,exit")
        return None
    p = install_imageio_ffmpeg(verbose=verbose)
    if p:
        ok(f"imageio-ffmpeg 装好: {p}")
        return p
    p = install_ffmpeg_winget(verbose=verbose)
    if p:
        ok(f"winget ffmpeg 装好: {p}")
        return p
    fail("ffmpeg 装不上,需要手动装: https://www.gyan.dev/ffmpeg/builds/")
    return None

# ---------- 检测/安装:Python 依赖 ----------
def ensure_py_dep(pkg_name, mod_name, desc, check_only=False, verbose=False):
    try:
        __import__(mod_name)
        return True, "已装"
    except ImportError:
        if check_only:
            return False, f"缺 {pkg_name}({desc})"
        r = pip_install(pkg_name, verbose=verbose)
        if r and r.returncode == 0:
            try:
                __import__(mod_name)
                return True, "已装"
            except ImportError:
                return False, f"装了但 import 失败"
        return False, f"pip 失败 rc={r.returncode if r else 'N/A'}"

def ensure_python_deps(check_only=False, verbose=False):
    step("检测 Python 依赖")
    fail_list = []
    for pkg, mod, desc in PY_DEPS_CORE:
        ok2, msg = ensure_py_dep(pkg, mod, desc, check_only, verbose)
        if ok2:
            ok(f"{pkg:18s}  {desc:14s}  {msg}")
        else:
            fail(f"{pkg:18s}  {desc:14s}  {msg}")
            fail_list.append(pkg)
    # 可选依赖:只 warn,不 fail
    if PY_DEPS_OPTIONAL:
        print(f"  {color('— 可选依赖 —', 'y')}")
        for pkg, mod, desc in PY_DEPS_OPTIONAL:
            try:
                __import__(mod)
                ok(f"{pkg:18s}  {desc:14s}  已装(可选)")
            except ImportError:
                warn(f"{pkg:18s}  {desc:14s}  未装(可选,按需 pip install)")
    return fail_list

# ---------- 检测:Node(供 JS 子流程用) ----------
def ensure_node(check_only=False):
    step("检测 Node.js(供 JS 子流程用,如 list_scenarios.js)")
    p = shutil.which("node") or shutil.which("node.exe")
    if p and Path(p).exists():
        ok(f"已就绪: {p}")
        return p
    if check_only:
        fail("未装 Node.js,check 模式不自动装")
        return None
    warn("未装 Node.js。情景视频的 pipeline/ 下 JS 脚本需要它。")
    if IS_WIN and shutil.which("winget"):
        run(["winget", "install", "-e", "--id", "OpenJS.NodeJS.LTS",
             "--source", "winget", "--accept-package-agreements",
             "--accept-source-agreements"], check=False, capture=False)
        p = shutil.which("node")
        if p:
            ok(f"winget 装好: {p}")
            return p
    warn("Node 装不上,JS 子流程跑不了。Python-only 工作流不受影响。")
    return None

# ---------- 检测:Windows 字体 ----------
def check_fonts():
    step("检测 Windows 字体(字幕烧录用)")
    if not IS_WIN:
        warn("非 Windows,跳过字体检查(脚本会回退到默认字体)")
        return
    win_fonts = Path("C:/Windows/Fonts")
    if not win_fonts.exists():
        fail("C:/Windows/Fonts 不存在,字幕烧录可能失败")
        return
    needed = ["simhei.ttf", "msyh.ttc"]
    for f in needed:
        if (win_fonts / f).exists():
            ok(f"字体 {f} 在")
        else:
            warn(f"字体 {f} 缺,可能字幕中文显示走形")

# ---------- 检测:情景视频引擎(可选) ----------
def check_scenario_engine():
    step("检测 情景视频引擎(changhai_expert.html,可选)")
    candidates = [
        Path("D:/微信小程序/ima工作流/changhai_expert.html"),
        Path("D:/Workbuddy缓存位置/.workbuddy/skills/ship-hai-domain-expert-ima/assets/changhai_expert.html"),
    ]
    for c in candidates:
        if c.exists():
            ok(f"已就绪: {c}")
            return
    warn("未找到 changhai_expert.html。情景视频如需用引擎生成场景,先安装 ship-hai-domain-expert skill。")

# ---------- 总结 ----------
def summary(ffmpeg, py_fails, node):
    step("结果汇总")
    lines = []
    lines.append(f"  ffmpeg       : {color(ffmpeg or '❌ 未装', 'g' if ffmpeg else 'r')}")
    lines.append(f"  Python 依赖  : {color('全部 OK' if not py_fails else '缺 ' + ','.join(py_fails), 'g' if not py_fails else 'r')}")
    lines.append(f"  Node.js      : {color(node or '⚠ 未装(可选,JS 子流程不可用)', 'g' if node else 'y')}")
    print("\n".join(lines))
    print()
    if not ffmpeg or py_fails:
        print(color("✗ 关键依赖不全,部分工作流可能跑不起来。", "r"))
        return 1
    print(color("✓ 关键依赖已齐。可以开跑工作流。", "g"))
    print()
    print("下一步:")
    print("  • 情景视频生产链    cd 情景视频生产链 && python run.py hse lifting_stop --plan")
    # 注意:表格讲解的代码在伞根 render/,不在子目录里(子目录只放说明文档)
    print("  • 表格讲解视频      python render/render_fast.py      (在伞目录根执行)")
    print("  • 选其它工作流      python start.py")
    print("  • 成片交付前自检    python check.py <成片.mp4>")
    print("  • 先看避坑总纲      1_避坑总纲_血泪清单.md")
    print("  • 看完整产品清单    cat 0_README_先看这个.md")
    return 0

def main():
    ap = argparse.ArgumentParser(description="标准视频工作流 一键环境检查")
    ap.add_argument("--check", action="store_true", help="只检查不装")
    ap.add_argument("--verbose", action="store_true", help="打印每个子步骤输出")
    args = ap.parse_args()

    print(color("=" * 60, "B"))
    print(color(" 标准视频工作流  ·  环境检查脚本", "B"))
    print(color("=" * 60, "B"))
    print(f"  平台: {platform.system()} {platform.release()}")
    print(f"  Python: {sys.version.split()[0]}")
    print(f"  工作区: {ROOT}")

    ffmpeg = ensure_ffmpeg(check_only=args.check, verbose=args.verbose)
    py_fails = ensure_python_deps(check_only=args.check, verbose=args.verbose)
    node = ensure_node(check_only=args.check)
    check_fonts()
    check_scenario_engine()
    return summary(ffmpeg, py_fails, node)

if __name__ == "__main__":
    sys.exit(main())
