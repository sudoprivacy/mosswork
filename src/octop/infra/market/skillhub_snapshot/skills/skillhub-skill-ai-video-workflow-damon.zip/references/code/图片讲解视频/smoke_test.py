# -*- coding: utf-8 -*-
"""回归冒烟闸 —— 把"只改点名处、绝不改坏其他地方"从口头纪律变成可验证机制。

为什么需要它：
  工作流有 6 种风格 × 9 种版式，任何坐标/字体/安全区改动都可能让某个
  (风格,版式,方向) 组合悄悄超屏/重叠/图压字。人工逐个看不现实，所以这里
  用代码把全部组合穷举跑一遍严格质检（超屏/重叠/图压字），任意 FAIL 即视为
  "破坏了其他功能"，禁止出片。

用法：
  python smoke_test.py              # 跑 6风格×9版式×2方向=108 组合硬审核（默认，无需联网）
  python smoke_test.py --e2e       # 额外跑 2 个端到端 mini 渲染（竖屏+横屏，需联网走 edge-tts）
  python smoke_test.py --style mechanical --layout data   # 只测某一组合，快速定位

退出码：0 = 全部 PASS；1 = 有 FAIL 或异常（即"改坏了其他地方"，需回退/修正）。

纪律（见 SCOPE_GUARD.md）：每次改完代码，先跑本脚本，全 PASS 才算升版成功。
"""
import os
import sys
import argparse
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from framework import styles as S
from framework import layouts as L
from framework import canvas as C

ORIENTATIONS = [("portrait", 1080, 1920), ("landscape", 1920, 1080)]


def make_dummy_photo(path):
    img = Image.new("RGB", (600, 800), (110, 130, 155))
    ImageDraw = __import__("PIL.ImageDraw").ImageDraw
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 599, 799], outline=(200, 210, 230), width=6)
    d.text((40, 360), "SAMPLE", fill=(230, 235, 245))
    img.save(path)


def sample_scene(ltype, figure_path=""):
    """一个覆盖全部版式可能读取字段的样例场景（每个版式只取自己要的）。"""
    return {
        "scene_type": ltype,
        "title": "核心质量指标与里程碑达成情况",
        "kicker": "项目汇报",
        "subtitle": "海上增产项目质量管控总览",
        "caption": "一次焊接合格率不低于百分之九十四",
        "caption_en": "First-pass weld acceptance rate no less than 94%.",
        "steps": [
            {"n": "01", "t": "准备素材", "d": "把文案照片交给工作流自动审题"},
            {"n": "02", "t": "自动排版", "d": "按模板生成多场景画面"},
            {"n": "03", "t": "一键出片", "d": "质检通过后合成成片"},
        ],
        "body": "全流程执行 ISO 9001 与 API 标准，焊接一次合格率保持在行业前列，NDT 覆盖率达到百分之百。",
        "illustration": "diagram",
        "data": {
            "一次焊接合格率": "≥94%",
            "返修率": "≤5%",
            "NDT 覆盖率": "100%",
            "里程碑准时率": "≥90%",
        },
        "nodes": [
            {"t": "立项", "d": "可行性研究与预算审批"},
            {"t": "设计", "d": "详细设计与工艺评定"},
            {"t": "施工", "d": "现场焊接与检验"},
        ],
        "body_title": "质量管控要点",
        "keyword": "零缺陷",
        "sub": "一次做对，不让缺陷流向下道工序",
        "quote": "质量不是检出来的，是干出来的。",
        "source": "— 项目质量总监",
        "compare": {
            "left_title": "传统做法",
            "right_title": "本工作流",
            "left_items": ["人工排版慢", "易超屏", "无硬审核"],
            "right_items": ["自动排版快", "严格不超屏", "三道闸拦截"],
        },
        "figure": {
            "path": figure_path,
            "highlights": [
                {"x": 0.1, "y": 0.1, "w": 0.35, "h": 0.25, "label": "重点一"},
                {"x": 0.55, "y": 0.45, "w": 0.35, "h": 0.25, "label": "重点二"},
            ],
        },
    }


def run_matrix(style_filter=None, layout_filter=None):
    styles = [style_filter] if style_filter else list(S.STYLES.keys())
    layouts_ = [layout_filter] if layout_filter else list(L.LAYOUTS.keys())
    tmp = os.path.join(HERE, "_smoke_tmp")
    os.makedirs(tmp, exist_ok=True)
    dummy = os.path.join(tmp, "dummy.jpg")
    make_dummy_photo(dummy)

    total = 0
    fails = []
    # 引擎在调用 draw_scene 前会把路径加载成 (PIL.Image, framing) 元组，这里对齐该格式
    img = Image.open(dummy).convert("RGBA")
    photo_arg = [(img, None)]
    for st in styles:
        style = S.STYLES[st]
        for lt in layouts_:
            for oname, w, h in ORIENTATIONS:
                total += 1
                tag = f"{st}/{lt}/{oname}"
                try:
                    cv = C.Canvas(style, w, h)
                    sc = sample_scene(lt, figure_path=dummy)
                    # 传内容照片以覆盖"图压字"审核；主播位图压字由 --e2e 端到端覆盖
                    L.draw_scene(sc, cv, style, photos=photo_arg, t=1.0, dur=3.0)
                    cv.validate(strict=True)
                except Exception as e:
                    fails.append((tag, repr(e)))
    return total, fails


def run_e2e():
    """端到端 mini 渲染（竖屏+横屏），确认 ffmpeg 动态定位 + edge-tts + concat 全链路可用。"""
    from framework import engine as E
    import json
    tmp = os.path.join(HERE, "_smoke_tmp")
    os.makedirs(tmp, exist_ok=True)
    dummy = os.path.join(tmp, "dummy.jpg")
    make_dummy_photo(dummy)

    brief = {
        "title": "质量管控总览",
        "subtitle": "海上增产项目",
        "template": "business_promo",
        "style": "mechanical",
        "host_photos": [dummy, dummy],
        "photos": [dummy],
        "points": [
            {"type": "cover", "title": "质量管控总览", "caption_en": "Quality overview."},
            {"type": "steps", "title": "三步流程", "caption_en": "Three steps.",
             "steps": [{"n": "01", "t": "准备", "d": "收集素材"},
                       {"n": "02", "t": "排版", "d": "自动生成"},
                       {"n": "03", "t": "出片", "d": "质检合成"}]},
            {"type": "data", "title": "核心指标", "caption_en": "Key metrics.",
             "data": {"合格率": "≥94%", "返修率": "≤5%", "覆盖率": "100%"}},
            {"type": "highlight", "title": "核心卖点", "caption_en": "Zero defect.",
             "keyword": "零缺陷", "sub": "一次做对"},
        ],
        "caption": "马上行动",
        "caption_en": "Act now.",
    }
    results = []
    for oname in ("portrait", "landscape"):
        out = os.path.join(tmp, f"e2e_{oname}.mp4")
        try:
            rep = E.render(brief, out, orientation=oname, voice="female_warm",
                           host_position="right", strict=True)
            ok = os.path.exists(out) and os.path.getsize(out) > 1000
            results.append((oname, ok, rep.get("orientation"), rep.get("voice")))
        except Exception as e:
            results.append((oname, False, None, repr(e)))
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--e2e", action="store_true", help="额外跑端到端 mini 渲染（需联网）")
    ap.add_argument("--style", default=None, help="只测指定风格")
    ap.add_argument("--layout", default=None, help="只测指定版式")
    args = ap.parse_args()

    print("=" * 64)
    print("配照片讲解 PPT 视频工作流 · 回归冒烟闸")
    print("=" * 64)
    total, fails = run_matrix(args.style, args.layout)
    print(f"矩阵硬审核：{total} 组合（风格×版式×方向）")
    for tag, err in fails:
        print(f"  [FAIL] {tag}  ->  {err}")
    if not fails:
        print("  ✅ 全部 PASS（无超屏 / 无重叠 / 无图压字）")

    e2e_results = None
    if args.e2e:
        print("-" * 64)
        print("端到端 mini 渲染（ffmpeg 动态定位 + edge-tts + concat）：")
        e2e_results = run_e2e()
        for oname, ok, ori, voice in e2e_results:
            print(f"  [{'PASS' if ok else 'FAIL'}] {oname}: ok={ok} ori={ori} voice={voice}")

    print("=" * 64)
    ok = (not fails) and (e2e_results is None or all(r[1] for r in e2e_results))
    print("总判定:", "✅ 通过，可升版" if ok else "❌ 存在失败，禁止出片，请回退/修正")
    print("=" * 64)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
