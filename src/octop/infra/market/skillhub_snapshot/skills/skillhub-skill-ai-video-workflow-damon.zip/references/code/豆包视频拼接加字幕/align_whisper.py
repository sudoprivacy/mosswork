#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""用 Whisper 识别视频里真人实际发音的逐词时间戳，把脚本分句钉到真实发音区间。
不再用任何替身TTS。输出 ASS(yyb48, PlayRes 720x1280, MarginV200)。
用法: python align_whisper.py --video X.mp4 --json clauses.json --out out.ass
clauses.json: [{"en":..,"cn":..}, ...]
"""
import os, json, argparse, subprocess
from faster_whisper import WhisperModel

FF = "C:/Users/Damon/.workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"
LEAD = 0.15
MIN_DUR = 0.80

def extract_audio(video, wav):
    subprocess.run([FF, "-y", "-i", video, "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", wav],
                   capture_output=True)

def map_clauses(segments, N):
    """把 N 句顺序映射到识别出的真实发音区间（秒）。优先用 Whisper 自然句边界。"""
    if not segments:
        return [(0.0, 1.0)] * N
    if len(segments) >= N:
        # 取 N-1 个最大的句间停顿作为切分点（合并相邻段）
        gaps = []
        for i in range(1, len(segments)):
            gaps.append((segments[i][0] - segments[i - 1][1], i))
        gaps.sort(reverse=True)
        split_idx = sorted(segments[g[1]][0] for g in gaps[:N - 1])
        sps = set(split_idx)
        groups = []; cur = [segments[0][0], segments[0][1]]
        for i in range(1, len(segments)):
            if segments[i][0] in sps:
                groups.append(cur); cur = [segments[i][0], segments[i][1]]
            else:
                cur[1] = max(cur[1], segments[i][1])
        groups.append(cur)
        return groups[:N]
    # 段数不足：按词索引均分
    words = []
    for s in segments:
        words.extend(s[2])
    if not words:
        return [(segments[0][0], segments[-1][1])] * N
    bounds = [0]
    for k in range(1, N):
        bounds.append(len(words) * k // N)
    bounds.append(len(words))
    spans = []
    for k in range(N):
        a, b = bounds[k], min(bounds[k + 1], len(words))
        spans.append((words[a][0], words[b - 1][1]))
    return spans

def wrap_cn(s, n=15):
    return "\\N".join(s[i:i + n] for i in range(0, len(s), n))

def wrap_en(s, n=32):
    if len(s) <= n: return s
    words = s.split(" "); lines = []; cur = ""
    for wd in words:
        if cur and len(cur) + 1 + len(wd) > n: lines.append(cur); cur = wd
        else: cur = (cur + " " + wd).strip()
    if cur: lines.append(cur)
    return "\\N".join(lines)

def s2ass(t):
    h = int(t // 3600); m = int((t % 3600) // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--json", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="D:/Workbuddy缓存位置/.workbuddy/skills/video-edit-workflow/scripts/whisper_tiny_en")
    args = ap.parse_args()
    data = json.load(open(args.json, encoding="utf-8"))
    EN = [d["en"] for d in data]; CN = [d["cn"] for d in data]

    wav = "_whisper_src.wav"
    extract_audio(args.video, wav)
    print("加载 Whisper 模型 %s ..." % args.model)
    model = WhisperModel(args.model, device="cpu", compute_type="int8")
    segments_gen, info = model.transcribe(wav, language="en", word_timestamps=True,
                                          vad_filter=True, condition_on_previous_text=False)
    segs = []
    for seg in segments_gen:
        words = [(w.start, w.end, w.word) for w in (seg.words or [])]
        segs.append((seg.start, seg.end, words))
    recog = [" ".join(w[2] for w in s[2]) for s in segs]
    print("识别文本:", " | ".join(recog))
    for s in segs:
        txt = " ".join(w[2] for w in s[2]) if s[2] else ""
        print("  seg %.2f-%.2f: %s" % (s[0], s[1], txt))

    spans = map_clauses(segs, len(EN))
    print("分句映射(秒):", [(round(a, 2), round(b, 2)) for a, b in spans])

    lines = [
        "[Script Info]", "ScriptType: v4.00+", "PlayResX: 720", "PlayResY: 1280",
        "WrapStyle: 1", "", "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        "Style: Default,yyb,48,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,3,2,2,40,40,200,1",
        "", "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    for k in range(len(EN)):
        start = max(0.0, spans[k][0] - LEAD)
        end = spans[k][1]
        if k + 1 < len(spans):
            end = spans[k + 1][0] - LEAD
        if end - start < MIN_DUR: end = start + MIN_DUR
        text = wrap_en(EN[k]) + "\\N" + wrap_cn(CN[k])
        lines.append("Dialogue: 0,%s,%s,Default,,0,0,0,,%s" % (s2ass(start), s2ass(end), text))
        print("%2d  起%.2f 止%.2f  %s" % (k + 1, start, end, EN[k][:40]))
    open(args.out, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print("已生成:", args.out)

if __name__ == "__main__":
    main()
