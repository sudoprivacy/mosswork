#!/usr/bin/env node
// 用工作流自带的 Playwright 录制「3D 卡片开场 + WorkBuddy 聊天录屏」演示视频。
// 依赖：node workspace 下的 playwright + 已下载的 chromium（一次性免费安装，非云 API）。
// 用法：node render.js            -> 输出 output/app_demo.webm
//       node render.js --mp4      -> 录完直接转成 output/app_demo.mp4 (H.264)
//
// 注意：本机环境 chromium.launch 正常，但 browser.close() 会挂起；
// 视频已由 context.close() 落盘，故录制后跳过 browser.close() 直接 process.exit。
const PW = 'D:/Workbuddy缓存位置/.workbuddy/binaries/node/workspace/node_modules/playwright';
const { chromium } = require(PW);
const path = require('path');
const fs = require('fs');
const { execFileSync } = require('child_process');

const __dir = __dirname;
const outDir = path.join(__dir, 'output');
fs.mkdirSync(outDir, { recursive: true });
const toMp4 = process.argv.includes('--mp4');

(async () => {
  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--enable-gpu', '--use-gl=angle', '--use-angle=swiftshader'],
  });
  const context = await browser.newContext({
    viewport: { width: 1080, height: 1920 },
    deviceScaleFactor: 1,
    recordVideo: { dir: outDir, size: { width: 1080, height: 1920 } },
  });
  const page = await context.newPage();
  const htmlPath = 'file://' + path.resolve(__dir, 'index.html');
  console.log('加载', htmlPath);
  await page.goto(htmlPath);
  // 覆盖 intro(0-5s) + chat 打字/列表(5-14s)，留 1s 余量
  await page.waitForTimeout(15000);
  await context.close();   // 视频在此落盘
  console.log('context 已关闭，视频已落盘');

  const files = fs.readdirSync(outDir)
    .filter(f => f.endsWith('.webm'))
    .sort((a, b) => fs.statSync(path.join(outDir, b)).mtime - fs.statSync(path.join(outDir, a)).mtime);
  if (!files.length) { console.error('未找到录制的 webm'); process.exit(1); }
  const webm = path.join(outDir, files[0]);
  console.log('录制完成:', webm);

  if (toMp4) {
    const FF = 'C:/Users/Damon/AppData/Local/Programs/Python/Python312/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe';
    const mp4 = path.join(outDir, 'app_demo.mp4');
    execFileSync(FF, ['-y', '-i', webm, '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', mp4], { stdio: 'ignore' });
    console.log('已转 mp4:', mp4);
    fs.unlinkSync(webm);
  }
  // 跳过 browser.close()（本机挂起），直接退出
  process.exit(0);
})().catch(e => { console.error('渲染失败:', e); process.exit(1); });
