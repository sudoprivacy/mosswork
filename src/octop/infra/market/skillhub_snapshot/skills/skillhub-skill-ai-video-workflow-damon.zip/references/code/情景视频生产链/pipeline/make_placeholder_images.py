#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
占位图生成器 (仅用于流水线 mechanic 验证, 不是成片素材).
为某工程每一镜生成一张带标注的占位 PNG, 方便先跑通 配音+字幕+合成,
真图到位后覆盖 images/scene_XX.png 即可。

用法:
  python pipeline/make_placeholder_images.py --project _dlg_test
"""
import os, json, argparse
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(ROOT, 'pipeline', 'config.json'), encoding='utf-8'))

W, H = 1536, 1024
ROLE_COLOR = {'A': (91, 200, 255), 'B': (255, 183, 77), 'N': (207, 216, 220)}


def vgrad(c1, c2):
    base = Image.new('RGB', (1, H), c1)
    px = base.load()
    for y in range(H):
        t = y / (H - 1)
        r = int(c1[0] + (c2[0] - c1[0]) * t)
        g = int(c1[1] + (c2[1] - c1[1]) * t)
        b = int(c1[2] + (c2[2] - c1[2]) * t)
        px[0, y] = (r, g, b)
    return base.resize((W, H))


def wrap(s, n):
    out, cur = [], ''
    for ch in s:
        cur += ch
        if len(cur) >= n:
            out.append(cur); cur = ''
    if cur:
        out.append(cur)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', required=True)
    ap.add_argument('--keep', action='store_true', help='已有真图的分镜跳过(不覆盖)')
    a = ap.parse_args()

    proj = os.path.join(ROOT, 'projects', a.project)
    data = json.load(open(os.path.join(proj, 'scenes.json'), encoding='utf-8'))
    img_dir = os.path.join(proj, 'images')
    os.makedirs(img_dir, exist_ok=True)
    f = CFG['font']
    f_lg = ImageFont.truetype(f, 90)
    f_md = ImageFont.truetype(f, 46)
    f_sm = ImageFont.truetype(f, 34)

    bg = vgrad((20, 32, 46), (40, 58, 74))
    for sc in data['scenes']:
        i = sc['idx']
        dst = os.path.join(img_dir, sc['image_file'])
        if a.keep and os.path.exists(dst):
            print('[%02d] 已有图, 跳过' % i); continue
        im = bg.copy()
        d = ImageDraw.Draw(im)
        # 对角斜纹水印
        for k in range(-H, W, 220):
            d.line([(k, 0), (k + H, H)], fill=(255, 255, 255, 18) if False else (60, 80, 96), width=40)
        spk = sc.get('speaker', 'N')
        col = ROLE_COLOR.get(spk, (207, 216, 220))
        # 镜号
        d.text((60, 48), '镜 %02d' % i, font=f_lg, fill=(255, 255, 255))
        # 角色
        nm = sc.get('speaker_en', 'Narrator')
        nz = sc.get('speaker_zh', '')
        rlabel = ('%s｜%s' % (nm, nz)) if spk != 'N' else 'Narrator｜旁白'
        d.text((62, 168), rlabel, font=f_md, fill=col)
        # 中央提示
        hint = sc.get('image_hint_zh') or sc.get('narration_zh') or sc.get('narration_en', '')
        lines = wrap(hint, 16)
        y = H // 2 - len(lines) * 30
        for ln in lines:
            d.text((W // 2 - len(ln) * 23, y), ln, font=f_md, fill=(230, 238, 245))
            y += 60
        # 预览占位角标
        d.text((W - 360, H - 70), '预览占位 PREVIEW', font=f_sm, fill=(150, 170, 185))
        im.save(dst)
        print('[%02d] 占位图 -> %s' % (i, sc['image_file']))
    print('OK')


if __name__ == '__main__':
    main()
