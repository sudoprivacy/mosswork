#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
字幕占屏自检工具 (self-review)
精确计算每镜每句话的字幕黑底块高度 ÷ 画面高度 的比例,
对照行业标准(单语≈5%, 双语≤15%)判断是否过大。

用法:
  python pipeline/measure_bar.py --project monthly_report_july --lang en
  python pipeline/measure_bar.py --project monthly_report_july --lang en --aspect 16:9
"""
import os, sys, json, argparse
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import pipeline.build_video as BV

PAD = getattr(BV, 'PAD', 20)


def measure(aspect, project, lang, dialogue=False):
    W, H = BV.ASPECTS[aspect]
    LY = BV.LAYOUT[aspect]
    use_lb = LY.get('letterbox', False)
    lb_bottom = int(H * LY['lb_bottom']) if use_lb else 0
    proj = os.path.join(BV.ROOT, 'projects', project)
    data = json.load(open(os.path.join(proj, 'scenes.json'), encoding='utf-8'))
    meta, scenes = data['meta'], data['scenes']
    lang = lang or meta.get('lang') or 'en'
    trans_lang = 'zh' if lang == 'en' else 'en'
    rows = []
    for sc in scenes:
        spk = sc.get('speaker', 'N')
        speak = (sc.get('tts_%s' % lang) or sc.get('narration_%s' % lang) or '').strip()
        trans = (sc.get('narration_%s' % trans_lang) or '').strip()
        sp_l = BV.split_sentences(speak, lang)
        if not sp_l:
            continue
        tr_l = BV.split_sentences(trans, trans_lang)
        pairs = BV.pair_sentences(sp_l, tr_l, trans_lang)
        for k, (sp, tr) in enumerate(pairs):
            if lang == 'en':
                pri_raw, sec_raw = sp, tr
                fs_pri, fs_sec = LY['en_pri'], LY['zh_sec']
                lim_pri, lim_sec = LY['en_lim'], LY['zh_sec_lim']
                wp, ws = BV.wrap_en, BV.wrap_zh
            else:
                pri_raw, sec_raw = sp, tr
                fs_pri, fs_sec = LY['zh_pri'], LY['en_sec']
                lim_pri, lim_sec = LY['zh_lim'], LY['en_sec_lim']
                wp, ws = BV.wrap_zh, BV.wrap_en
            fs_name = LY['name']; ls_pri = ls_sec = 7
            block_gap = LY['block_gap']; show_name = dialogue
            fs_pri0, fs_sec0 = fs_pri, fs_sec
            pl = wp(pri_raw, lim_pri); sl = ws(sec_raw, lim_sec)
            for _ in range(5):
                h_pri = len(pl) * BV.lh(fs_pri, ls_pri)
                h_sec = len(sl) * BV.lh(fs_sec, ls_sec)
                name_h = BV.lh(fs_name, 0) + LY['name_gap'] if show_name else 0
                if use_lb:
                    total_h = h_pri + block_gap + h_sec + name_h
                    if total_h <= int(lb_bottom * 0.84) or fs_pri <= 24:
                        break
                else:
                    bar = LY['mb'] + h_sec + block_gap + h_pri + name_h + PAD
                    thr = LY.get('maxbar', 0.42)
                    if bar <= H * thr or fs_pri <= 22:
                        break
                fs_pri = max(24 if use_lb else 22, fs_pri - 4)
                fs_sec = max(22 if use_lb else 20, fs_sec - 2)
                fs_name = max(20, fs_name - 2)
                pl = wp(pri_raw, max(8, int(lim_pri * fs_pri0 / fs_pri)))
                sl = ws(sec_raw, max(8, int(lim_sec * fs_sec0 / fs_sec)))
            h_pri = len(pl) * BV.lh(fs_pri, ls_pri)
            h_sec = len(sl) * BV.lh(fs_sec, ls_sec)
            name_h = BV.lh(fs_name, 0) + LY['name_gap'] if show_name else 0
            if use_lb:
                total_h = h_pri + block_gap + h_sec + name_h
                bar = total_h
                pct_screen = total_h / H * 100.0
                pct_safe = total_h / lb_bottom * 100.0 if lb_bottom else 0
            else:
                bar = LY['mb'] + h_sec + block_gap + h_pri + name_h + PAD
                pct_screen = bar / H * 100.0
                pct_safe = pct_screen
            rows.append((sc['idx'], k, bar, pct_screen, pct_safe,
                         len(pl), len(sl), fs_pri, fs_sec))
    return H, lb_bottom, rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', required=True)
    ap.add_argument('--aspect', default='16:9')
    ap.add_argument('--lang', default=None)
    ap.add_argument('--dialogue', action='store_true')
    a = ap.parse_args()
    H, lb_bottom, rows = measure(a.aspect, a.project, a.lang, a.dialogue)
    if not rows:
        print('无口播句可量'); return
    rows.sort(key=lambda r: -r[3])
    pcts = [r[3] for r in rows]
    print('画面高度 H=%d  共 %d 句字幕' % (H, len(rows)))
    if lb_bottom:
        print('黑边模式: 下黑边高 %dpx (%.1f%% 画面高)' % (lb_bottom, lb_bottom / H * 100))
        print('字幕占整屏: 最大 %.1f%%  平均 %.1f%%  中位数 %.1f%%'
              % (max(pcts), sum(pcts) / len(pcts), sorted(pcts)[len(pcts) // 2]))
        safe_pcts = [r[4] for r in rows]
        print('字幕占黑边: 最大 %.1f%%  平均 %.1f%%  中位数 %.1f%%'
              % (max(safe_pcts), sum(safe_pcts) / len(safe_pcts),
                 sorted(safe_pcts)[len(safe_pcts) // 2]))
    else:
        print('占屏比例: 最大 %.1f%%  平均 %.1f%%  中位数 %.1f%%'
              % (max(pcts), sum(pcts) / len(pcts), sorted(pcts)[len(pcts) // 2]))
    print('行业对照: 单语≈5%  双语舒适≤15%  黑边模式下字幕宜≤黑边85%')
    print('--- 占屏最大 6 句 ---')
    for idx, k, bar, pct, pct_safe, npl, nsl, fp, fs in rows[:6]:
        if lb_bottom:
            flag = '⚠ 超出黑边' if pct_safe > 95 else ('OK' if pct_safe <= 85 else '—')
            extra = '/黑边%.0f%%' % pct_safe
        else:
            flag = '⚠ 偏大' if pct > 15 else ('OK' if pct <= 12 else '—')
            extra = ''
        print('  镜%02d句%d  bar=%3dpx 占屏%.1f%%%s  主%d行/副%d行 字号%d/%d  %s'
              % (idx, k, bar, pct, extra, npl, nsl, fp, fs, flag))


if __name__ == '__main__':
    main()
