# -*- coding: utf-8 -*-
"""元素登记器：记录每一处绘制元素的包围盒，供硬审核使用。
任何会被审核的绘制都应通过 Canvas 登记（文字、照片），
装饰性底图（卡片/线）不登记（它们本就该在文字下方）。
"""
from typing import List, Tuple

# 受审核的文本类元素（彼此不得重叠、不得超屏）
TEXT_KINDS = {
    "title", "subtitle", "kicker", "caption", "caption_en",
    "bullet", "big", "small", "accent", "label", "metric",
    "step_no", "step_title", "step_desc",
    "node_no", "node_title", "node_desc",
    "card_title", "card_body",
    "quote", "quote_src", "compare_l", "compare_r", "deco_text",
}

# 各文本类的纵向安全区（像素）。None 表示该方向不限制。
# 顶部系统 UI 安全区 SAFE_T=190；主内容下界 SAFE_B=1620；
# 底部字幕区允许到 1900。
KIND_BOUNDS = {
    "title":      (190, 1620),
    "subtitle":   (190, 1620),
    "kicker":     (190, 1620),
    "caption":    (1640, 1900),
    "caption_en": (1640, 1900),
    "bullet":     (190, 1620),
    "big":        (190, 1620),
    "small":      (190, 1620),
    "accent":     (190, 1620),
    "label":      (190, 1620),
    "metric":     (190, 1620),
    "step_no":    (190, 1620),
    "step_title": (190, 1620),
    "step_desc":  (190, 1620),
    "node_no":    (190, 1620),
    "node_title": (190, 1620),
    "node_desc":  (190, 1620),
    "card_title": (190, 1620),
    "card_body":  (190, 1620),
    "quote":      (190, 1620),
    "quote_src":  (190, 1620),
    "compare_l":  (190, 1620),
    "compare_r":  (190, 1620),
    "deco_text":  (190, 1620),
}


class ElementRegistry:
    def __init__(self):
        self.items: List[Tuple[Tuple[int, int, int, int], str, str]] = []

    def add(self, box, kind, label=""):
        x0, y0, x1, y1 = [int(round(v)) for v in box]
        self.items.append(((x0, y0, x1, y1), kind, label))

    def texts(self):
        return [it for it in self.items if it[1] in TEXT_KINDS]

    def photos(self):
        return [it for it in self.items if it[1] == "photo"]

    def reset(self):
        self.items.clear()

    def report(self):
        return f"登记元素 {len(self.items)} 个（文字 {len(self.texts())} / 照片 {len(self.photos())}）"
