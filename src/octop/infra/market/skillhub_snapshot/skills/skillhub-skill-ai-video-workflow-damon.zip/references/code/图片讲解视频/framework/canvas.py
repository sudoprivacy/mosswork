# -*- coding: utf-8 -*-
"""画布：绘制操作缓冲 + 按时间合成 + 自动登记元素 + 硬审核。

设计（解决"内容一次性全出 / 单调 / 文不对声 / 闪屏"）：
  - 所有"会被审核"的绘制（文字、照片）都通过 Canvas 登记包围盒；
    装饰性底图（卡片/线/分隔条）登记为 deco，不参加重叠审核。
  - 不再直接画到最终图，而是把每个元素渲染成"独立图层 + 出现时刻 + 入场形式"，
    存进 ops。最终画面由 compose(t) 在时刻 t 按入场动画逐元素合成。
  - 元素出现顺序 = 布局代码绘制顺序 = 配音朗读顺序，因此画面与声音天然同步。
  - 入场形式（fade/slide_left/...）按 (出现序号 + 场景种子) 轮换，保证多样性。

横竖屏自适应：
  - Canvas 以 (w, h) 初始化，自动判定 portrait(h>w) / landscape(w>h)。
  - metrics() 返回与方向相关的版式坐标；竖屏严格沿用旧版像素值（保证旧成片一致），
    横屏给出 1920x1080 专用布局，避免"文字被挤成竖条 / 背景没铺满"等问题。
"""
from typing import List, Optional, Tuple, Callable, Dict
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from .registry import ElementRegistry, TEXT_KINDS
from .validator import validate, LayoutError

# 每个元素之间的出现间隔（秒）
STAGGER = 0.14
# 单个元素入场动画时长（秒）——拉长到 0.55，让滑入/缩放"看得见"而非一闪而过
ENTER_DUR = 0.55

# 入场形式轮换表（多样性来源）
ENTER_STYLES = ["fade", "slide_left", "slide_right", "slide_up", "zoom", "pop", "slide_down"]


def wrap_cjk(text, font, max_w):
    """按字符宽度折行（CJK 逐字，ASCII 按词）。"""
    lines, cur = [], ""
    for ch in text:
        test = cur + ch
        if font.getlength(test) <= max_w or not cur:
            cur = test
        else:
            lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    return lines


# ---------------- 各文本类的纵向安全区（按方向） ----------------
def _bounds_portrait():
    b = {}
    for k in TEXT_KINDS:
        b[k] = (190, 1620)
    b["caption"] = (1640, 1900)
    b["caption_en"] = (1640, 1900)
    return b


def _bounds_landscape():
    b = {}
    for k in TEXT_KINDS:
        b[k] = (90, 960)
    # 横屏高度仅 1080，底部中英字幕两行需足够纵向空间：放宽到 [900,1075]，
    # 配合 subtitle_y=900，保证 caption + caption_en 两行都落在安全带内（不超屏）。
    b["caption"] = (900, 1075)
    b["caption_en"] = (900, 1075)
    return b


class Canvas:
    def __init__(self, style, w=1080, h=1920, registry=None):
        self.style = style
        self.w, self.h = w, h
        self.portrait = h >= w
        self.reg = registry if registry is not None else ElementRegistry()
        self.im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        self.base = None  # 背景层（由 engine 通过 set_background 注入）
        self.ops = []  # 绘制操作列表
        self._seq = 0  # 当前出现序号
        self._seed = 0  # 场景种子（engine 按场景序号设置，保证多样性）
        self._appear_base = 0.30  # 本场景首个元素出现时刻
        self._settled = None
        self._settle_t = 0.0
        self._synced = False  # sync_to_audio 之后为 True

    # ---------- 方向相关版式坐标 ----------
    def metrics(self) -> Dict:
        """返回当前方向的版式坐标。竖屏严格沿用旧值；横屏专属布局。"""
        if self.portrait:
            return {
                "header_y": 300,
                "subtitle_y": 1660,
                "content_left": 90,
                "content_right_none": 990,
                "content_right_host": 720,
                "content_right_photos": 1040,
                "photo_x": 60, "photo_top": 660, "photo_w": 460,
                "host_box": (760, 1220, 1040, 1580),
                "cover_photo_y": 720, "cover_photo_h": 760,
                "body_y": 700,
                "illus_top": 1080, "illus_bot": 1520,
                "data_cy": 720, "data_r": 150,
                "tl_y": 760,
                "glass_y": 680,
                "hl_kw_y": 760, "hl_sub_y": 1080,
                "quote_y": 720, "quote_src_y": 1180,
                "cmp_photo_boxes": [(90, 1180, 530, 1540), (550, 1180, 990, 1540)],
                "cmp_top": 660, "cmp_bot_photos": 1540, "cmp_bot_nohost": 1540,
                "step_start": 660, "step_gap": 200,
                "safe": (190, 1620, 40, 1040),
                "kind_bounds": _bounds_portrait(),
            }
        else:
            return {
                "header_y": 90,
                "subtitle_y": 900,
                "content_left": 120,
                "content_right_none": 1800,
                "content_right_host": 1480,
                "content_right_photos": 1820,
                "photo_x": 120, "photo_top": 520, "photo_w": 620,
                "host_box": (1560, 600, 1860, 940),
                "cover_photo_y": 360, "cover_photo_h": 560,
                "body_y": 360,
                "illus_top": 440, "illus_bot": 900,
                "data_cy": 470, "data_r": 150,
                "tl_y": 440,
                "glass_y": 360,
                "hl_kw_y": 430, "hl_sub_y": 740,
                "quote_y": 380, "quote_src_y": 770,
                "cmp_photo_boxes": [(150, 540, 820, 920), (1000, 540, 1670, 920)],
                "cmp_top": 360, "cmp_bot_photos": 940, "cmp_bot_nohost": 940,
                "step_start": 360, "step_gap": 150,
                "safe": (90, 960, 60, 1860),
                "kind_bounds": _bounds_landscape(),
            }

    def safe(self):
        return self.metrics()["safe"]

    # ---------- 背景 ----------
    def set_background(self, img):
        self.base = img.convert("RGBA") if img else None

    # ---------- 字体 / 测量 ----------
    def get_font(self, key, size):
        return self.style.get_font(key, size)

    def measure(self, text, font):
        tw = font.getlength(text)
        asc, desc = font.getmetrics()
        return tw, asc + desc

    # ---------- 出现序号 / 入场形式 ----------
    def _next_enter(self):
        return ENTER_STYLES[(self._seq + self._seed) % len(ENTER_STYLES)]

    # ---------- 登记 ----------
    def register(self, box, kind, label=""):
        self.reg.add(box, kind, label)

    # ---------- 通用捕获：把一个元素画到独立图层并登记 ----------
    def capture(self, box, draw_fn, kind, label="", enter=None,
                dur=ENTER_DUR, appear_at=None, register=True,
                fixed_enter=False, follow=None):
        """draw_fn(draw, layer) 在透明图层 layer 上以局部坐标绘制。
        显式传入 appear_at 时，sync_to_audio 会保留该时刻不做覆盖。
        fixed_enter=True 时，sync_to_audio 不会把 enter 改成 zoom/pop/slide，
        用于标准图场景：避免每个元素都缩放/弹入造成"一闪一闪"。"""
        x0, y0, x1, y1 = [int(round(v)) for v in box]
        if x1 <= x0 or y1 <= y0:
            return y1
        layer = Image.new("RGBA", (x1 - x0, y1 - y0), (0, 0, 0, 0))
        draw_fn(ImageDraw.Draw(layer), layer)
        if register:
            self.register((x0, y0, x1, y1), kind, label)
        fixed_appear = appear_at is not None
        if appear_at is None:
            appear_at = self._appear_base + self._seq * STAGGER
        self.ops.append({
            "layer": layer, "box": (x0, y0, x1, y1), "kind": kind,
            "label": label, "appear_at": appear_at,
            "enter": enter or self._next_enter(), "dur": dur,
            "fixed_appear": fixed_appear,
            "fixed_enter": fixed_enter,
            "follow": follow,
        })
        self._seq += 1
        return y1

    # ---------- 文字块（居中 / 左对齐）----------
    def text_block(self, lines, cx, y0, font, fill, kind, label="",
                   line_h=None, anchor_x="mm", alpha=255, shadow=True,
                   shadow_off=3, shadow_color=None, enter=None,
                   appear_at=None, fixed_enter=False, follow=None):
        if isinstance(lines, str):
            lines = [lines]
        if not lines:
            return y0
        asc, desc = font.getmetrics()
        th = asc + desc
        if line_h is None:
            line_h = int(th * 1.18)
        maxw = max(self.measure(ln, font)[0] for ln in lines)
        if anchor_x == "mm":
            x0, x1 = cx - maxw / 2, cx + maxw / 2
        else:  # la
            x0, x1 = cx, cx + maxw
        y1 = y0 + line_h * len(lines)
        pad = 14
        bx0, by0 = int(x0) - pad, int(y0) - pad
        bx1, by1 = int(x1) + pad, int(y1) + pad

        def _draw(d, layer):
            sc = shadow_color or self.style.c("shadow", (0, 0, 0, 180))
            main_fill = fill if alpha >= 255 else (*fill[:3], int(alpha))
            for i, ln in enumerate(lines):
                ly = pad + i * line_h + line_h / 2
                if anchor_x == "mm":
                    lx = cx - bx0
                    anc = "mm"
                else:
                    lx = (x0 - bx0)
                    anc = "lm"
                if shadow:
                    sh_a = int((sc[3] if len(sc) > 3 else 180) * (alpha / 255))
                    d.text((lx + shadow_off, ly + shadow_off), ln,
                           font=font, fill=(*sc[:3], sh_a), anchor=anc)
                d.text((lx, ly), ln, font=font, fill=main_fill, anchor=anc)

        self.capture((bx0, by0, bx1, by1), _draw, kind, label, enter=enter,
                     register=False,
                     appear_at=appear_at, fixed_enter=fixed_enter, follow=follow)
        # 质检用真实文字包围盒（不含 padding）
        self.register((x0, y0, x1, y1), kind, label)
        return y1

    # ---------- 顶部标题区 ----------
    def header(self, title, kicker=None, subtitle=None, calm=False):
        s = self.style
        m = self.metrics()
        y = m["header_y"]
        # calm 模式：标题与图一起直接淡入，不再单独 slide/pop，避免"一闪一闪"
        h_appear = 0.0 if calm else None
        h_enter = "fade" if calm else "slide_down"
        h_fixed = calm
        if kicker:
            kf = self.get_font("en_b", 30)
            self.text_block([kicker.upper()], self.w / 2, y, kf,
                            s.c("accent"), "kicker", "kicker", line_h=40,
                            anchor_x="mm", shadow=True,
                            enter=h_enter, appear_at=h_appear,
                            fixed_enter=h_fixed)
            y += 56
        tf = self.get_font("cn_b", 70)
        lines = wrap_cjk(title, tf, self.w - 160)
        lines = lines[:2]
        y = self.text_block(lines, self.w / 2, y, tf, s.c("text"),
                            "title", "title", line_h=int(tf.getmetrics()[0] * 1.25),
                            anchor_x="mm", shadow=True,
                            enter=h_enter, appear_at=h_appear,
                            fixed_enter=h_fixed)
        if subtitle:
            sf = self.get_font("cn", 38)
            slines = wrap_cjk(subtitle, sf, self.w - 200)
            slines = slines[:2]
            self.text_block(slines, self.w / 2, y + 18, sf, s.c("text_dim"),
                            "subtitle", "subtitle", line_h=50, anchor_x="mm",
                            shadow=True, enter=h_enter, appear_at=h_appear,
                            fixed_enter=h_fixed)

    # ---------- 底部中英字幕 ----------
    def subtitle(self, caption, caption_en=None):
        s = self.style
        m = self.metrics()
        cf = self.get_font("cn", 38)
        clines = wrap_cjk(caption, cf, self.w - 120)
        clines = clines[:2]
        y = m["subtitle_y"]
        y = self.text_block(clines, self.w / 2, y, cf, s.c("text"),
                            "caption", "caption", line_h=50, anchor_x="mm",
                            shadow=True, enter="fade")
        if caption_en:
            ef = self.get_font("en", 30)
            elines = wrap_cjk(caption_en, ef, self.w - 120)
            elines = elines[:2]
            self.text_block(elines, self.w / 2, y + 6, ef, s.c("text_dim"),
                            "caption_en", "caption_en", line_h=40, anchor_x="mm",
                            shadow=True, enter="fade")

    # ---------- 照片 ----------
    def paste_photo(self, layer, box, label="", enter=None,
                    appear_at=None, fixed_enter=False):
        x0, y0, x1, y1 = [int(round(v)) for v in box]
        if x1 <= x0 or y1 <= y0:
            return
        layer = layer.resize((x1 - x0, y1 - y0))

        def _draw(d, l):
            l.paste(layer, (0, 0), layer)

        self.capture((x0, y0, x1, y1), _draw, "photo", label, enter=enter,
                     appear_at=appear_at, fixed_enter=fixed_enter)

    # ---------- 装饰（不登记 / 不参加重叠审核）----------
    def divider(self, x0, y0, x1, y1, color, width=3):
        bx0, by0 = min(x0, x1) - 4, min(y0, y1) - 4
        bx1, by1 = max(x0, x1) + 4, max(y0, y1) + 4

        def _draw(d, l):
            d.line([(x0 - bx0, y0 - by0), (x1 - bx0, y1 - by0)],
                   fill=color, width=width)

        self.capture((bx0, by0, bx1, by1), _draw, "deco", "divider",
                     register=False, enter="fade")

    def accent_bar(self, x, y, w, h, color):
        def _draw(d, l):
            d.rectangle([0, 0, w, h], fill=color)

        self.capture((x, y, x + w, y + h), _draw, "deco", "accent_bar",
                     register=False, enter="fade")

    # ---------- 画重点原语（跟随 bullet 的多样高亮） ----------
    @staticmethod
    def _with_alpha(color, alpha):
        if isinstance(color, tuple):
            if len(color) == 4:
                return color[:3] + (alpha,)
            return color + (alpha,)
        return color

    def callout_arrow(self, x0, y0, x1, y1, color, width=5, arrow_size=14,
                      label="", follow=None, appear_at=None, fixed_enter=True):
        bx0, by0 = min(x0, x1) - 28, min(y0, y1) - 28
        bx1, by1 = max(x0, x1) + 28, max(y0, y1) + 28

        def _draw(d, l):
            d.line([(x0 - bx0, y0 - by0), (x1 - bx0, y1 - by0)],
                   fill=color, width=width)
            dx, dy = x1 - x0, y1 - y0
            length = max(1, (dx * dx + dy * dy) ** 0.5)
            ux, uy = dx / length, dy / length
            ax = int(x1 - arrow_size * ux + 8 * uy) - bx0
            ay = int(y1 - arrow_size * uy - 8 * ux) - by0
            cx = int(x1 - arrow_size * ux - 8 * uy) - bx0
            cy = int(y1 - arrow_size * uy + 8 * ux) - by0
            d.polygon([(ax, ay), (cx, cy), (x1 - bx0, y1 - by0)], fill=color)
            if label:
                lf = self.get_font("cn_b", 22)
                d.text((x1 - bx0 + 8, y1 - by0 - 12), label, font=lf,
                       fill=color)

        self.capture((bx0, by0, bx1, by1), _draw, "deco", "arrow_callout",
                     register=False, enter="fade", appear_at=appear_at,
                     fixed_enter=fixed_enter, follow=follow)

    def marker_dot(self, cx, cy, r, color, label="",
                   follow=None, appear_at=None, fixed_enter=True):
        bx0, by0 = cx - r - 20, cy - r - 20
        bx1, by1 = cx + r + 80, cy + r + 40

        def _draw(d, l):
            for i in range(4, 0, -1):
                rr = r + i * 3
                a = self._with_alpha(color, int(55 / i))
                d.ellipse([(cx - rr - bx0, cy - rr - by0),
                           (cx + rr - bx0, cy + rr - by0)], fill=a)
            d.ellipse([(cx - r - bx0, cy - r - by0),
                       (cx + r - bx0, cy + r - by0)],
                      fill=color, outline=(255, 255, 255, 220), width=3)
            if label:
                lf = self.get_font("cn_b", 24)
                d.text((cx + r + 8 - bx0, cy - 12 - by0), label, font=lf,
                       fill=(255, 255, 255, 255))

        self.capture((bx0, by0, bx1, by1), _draw, "deco", "marker_dot",
                     register=False, enter="zoom", appear_at=appear_at,
                     fixed_enter=fixed_enter, follow=follow)

    def row_band(self, x0, y0, x1, y1, color, alpha=38,
                 follow=None, appear_at=None, fixed_enter=True):
        # 关键修复：旧实现用 80~95 alpha 的实心色块盖在原文之上，直接把字糊掉。
        # 现改为：① 低 alpha 轻底色只做"这一行"提示（不糊字）；
        #        ② 强对比左标条贴在文字左侧外的 margin，绝不压字；
        #        ③ 清晰边框勾出范围。三者配合——既醒目又不挡原文。
        h = max(1, y1 - y0)
        bar_w = max(9, int(h * 0.55))
        mx = bar_w + 6
        def _draw(d, l):
            c = self._with_alpha(color, alpha)
            d.rectangle([mx, 0, x1 - x0, y1 - y0], fill=c)
            d.rectangle([0, 0, mx, y1 - y0], fill=color)          # 左标条（margin 内）
            d.rectangle([mx, 0, x1 - x0, y1 - y0], outline=color, width=5)
        self.capture((x0 - mx, y0, x1, y1), _draw, "deco", "row_band",
                     register=False, enter="fade", appear_at=appear_at,
                     fixed_enter=fixed_enter, follow=follow)

    def underline(self, x0, y0, x1, y1, color, width=6,
                  follow=None, appear_at=None, fixed_enter=True):
        # 关键修复：水平下划线常传入 y0==y1，若不预留高度，capture 层高度=0
        # 会被裁空导致整条线不显示。这里给层留出线宽高度，并把线画在层内中点。
        pad = width + 3
        bx0, by0 = min(x0, x1) - 2, min(y0, y1) - pad
        bx1, by1 = max(x0, x1) + 2, max(y0, y1) + pad
        ly = (y0 - by0 + y1 - by0) / 2.0

        def _draw(d, l):
            d.line([(x0 - bx0, ly), (x1 - bx0, ly)], fill=color, width=width)

        self.capture((bx0, by0, bx1, by1), _draw, "deco", "underline",
                     register=False, enter="fade", appear_at=appear_at,
                     fixed_enter=fixed_enter, follow=follow)

    def magnifier(self, cx, cy, r, color, follow=None, appear_at=None,
                  fixed_enter=True):
        bx0, by0 = cx - r - 16, cy - r - 16
        bx1, by1 = cx + r + 24, cy + r + 24

        def _draw(d, l):
            for i in range(4, 0, -1):
                rr = r + i * 4
                a = self._with_alpha(color, int(50 / i))
                d.ellipse([(cx - rr - bx0, cy - rr - by0),
                           (cx + rr - bx0, cy + rr - by0)], fill=a)
            d.ellipse([(cx - r - bx0, cy - r - by0),
                       (cx + r - bx0, cy + r - by0)],
                      outline=(255, 255, 255, 240), width=4)
            d.line([(cx + int(r * 0.65) - bx0, cy + int(r * 0.65) - by0),
                    (cx + r + 10 - bx0, cy + r + 10 - by0)],
                   fill=color, width=8)

        self.capture((bx0, by0, bx1, by1), _draw, "deco", "magnifier",
                     register=False, enter="zoom", appear_at=appear_at,
                     fixed_enter=fixed_enter, follow=follow)

    def glow_text(self, text, cx, cy, font, color, glow=None, kind="explain",
                  label="", follow=None, appear_at=None, fixed_enter=True,
                  enter="zoom"):
        tw, th = self.measure(text, font)
        box_w, box_h = int(tw + 60), int(th + 50)
        x0, y0 = int(cx - box_w / 2), int(cy - box_h / 2)

        def _draw(d, l):
            # 干净发光：先画一层同色文字并高斯模糊成光晕，再叠清晰实体字。
            # 绝不用多方向偏移叠加（那会看起来像"字体重影"）。
            g = glow if glow else self._with_alpha(color, 140)
            cxw, cyh = box_w // 2, box_h // 2
            glow_layer = Image.new("RGBA", (box_w, box_h), (0, 0, 0, 0))
            ImageDraw.Draw(glow_layer).text((cxw, cyh), text, font=font,
                                            fill=g, anchor="mm")
            glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(7))
            l.alpha_composite(glow_layer)
            d.text((cxw, cyh), text, font=font, fill=color, anchor="mm")

        self.capture((x0, y0, x0 + box_w, y0 + box_h), _draw, kind, label,
                     enter=enter, appear_at=appear_at, fixed_enter=fixed_enter,
                     follow=follow)

    # ---------- 合成：时刻 t 的画面 ----------
    def compose(self, t):
        img = self.base.copy() if self.base is not None else Image.new(
            "RGBA", (self.w, self.h), (0, 0, 0, 255))
        for op in self.ops:
            a, d = op["appear_at"], op["dur"]
            if t < a:
                continue
            p = 1.0 if d <= 0 else min(1.0, (t - a) / d)
            l, ox, oy = self._anim(op, p)
            x0, y0, x1, y1 = op["box"]
            nw, nh = l.size
            px = int(x0 + ox + ((x1 - x0) - nw) / 2)
            py = int(y0 + oy + ((y1 - y0) - nh) / 2)
            img.alpha_composite(l, (px, py))
        return img

    def _anim(self, op, p):
        layer = op["layer"]
        enter = op["enter"]
        ox = oy = 0
        l = layer
        # 让位移/缩放在入场过程中"看得见"：透明度快速拉满（约 45% 进度即全不透明），
        # 否则 motion 被淡入掩盖，用户会觉得"只有淡入、没有出场风格"。
        vis = min(1.0, p * 2.2)
        if enter == "fade":
            l = self._alpha(layer, p)
        elif enter == "slide_left":
            ox = int((1 - p) * 260)
            l = self._alpha(layer, vis)
        elif enter == "slide_right":
            ox = -int((1 - p) * 260)
            l = self._alpha(layer, vis)
        elif enter == "slide_up":
            oy = int((1 - p) * 200)
            l = self._alpha(layer, vis)
        elif enter == "slide_down":
            oy = -int((1 - p) * 200)
            l = self._alpha(layer, vis)
        elif enter == "zoom":
            sc = 0.70 + 0.30 * p  # 从 70% 放大到 100%，明显"长大"
            l = self._scale(layer, sc)
            l = self._alpha(l, vis)
        elif enter == "pop":
            sc = 0.62 + 0.38 * p  # 从 62% 弹出到 100%
            l = self._scale(layer, sc)
            l = self._alpha(l, vis)
        else:
            l = self._alpha(layer, p)
        return l, ox, oy

    @staticmethod
    def _alpha(layer, p):
        a = int(round(p * 255))
        if a >= 255:
            return layer
        l = layer.copy()
        l.putalpha(l.split()[3].point(lambda v: int(v * a / 255)))
        return l

    @staticmethod
    def _scale(layer, sc):
        nw = max(1, int(layer.width * sc))
        nh = max(1, int(layer.height * sc))
        return layer.resize((nw, nh), Image.LANCZOS)

    # ---------- 预合成稳定帧（用于持有期与转场）----------
    def settle(self):
        if getattr(self, "_synced", False):
            return self._settled
        n = len(self.ops)
        self._settle_t = self._appear_base + max(0, n - 1) * STAGGER + ENTER_DUR + 0.05
        if self._settled is None:
            self._settled = self.compose(self._settle_t + 1.0)
        return self._settled

    def sync_to_audio(self, audio_dur, lead=0.35, tail=0.4, early_span=1.4):
        """把元素出现时刻铺到真实配音时长上：结构元素先建立，内容元素随配音逐条跳出。

        这样画面与声音同步——配音念到哪一条，哪一条才出现，不再抢拍、不再滞后。
        结构元素（kicker/title/subtitle/deco/photo）在开场 lead..lead+early_span 内依次出现；
        内容元素（步骤/节点/数据/正文等）铺在 [lead+early_span, audio_dur-tail] 区间，
        出现顺序保持绘制顺序 = 配音朗读顺序。
        """
        early_kinds = {"kicker", "title", "subtitle", "deco", "photo"}
        early, content, deferred = [], [], []
        for op in self.ops:
            if op.get("fixed_appear"):
                continue
            if op.get("follow"):
                # 跟随目标元素（如高亮框跟随对应子弹点），不参与 early/content 通用铺开
                deferred.append(op)
                continue
            if op["kind"] in early_kinds:
                early.append(op)
            else:
                content.append(op)
        early_span = min(early_span, max(0.4, audio_dur * 0.25))
        for idx, op in enumerate(early):
            op["appear_at"] = lead + early_span * (idx / max(1, len(early) - 1))
        start = lead + early_span
        end = max(start + 0.4, audio_dur - tail)
        n = len(content)
        for idx, op in enumerate(content):
            op["appear_at"] = start + (end - start) * (idx / max(1, n - 1))
        # 配对 follow：让高亮框/标签 与对应子弹点同一时刻出现（略晚 0.03s 更自然）
        for op in deferred:
            f = op.get("follow")
            target = next((c for c in content if c.get("label") == f), None)
            if target is not None and target.get("appear_at") is not None:
                op["appear_at"] = target["appear_at"] + 0.03
            else:
                op["appear_at"] = start
        # 入场形式多样性：按出现顺序轮换（但尊重 fixed_enter，不破坏显式指定）
        ordered = sorted(self.ops, key=lambda o: o["appear_at"])
        for i, op in enumerate(ordered):
            if op.get("fixed_enter"):
                continue
            op["enter"] = ENTER_STYLES[(i + self._seed) % len(ENTER_STYLES)]
        self._settle_t = (end if content else (lead + early_span)) + ENTER_DUR + 0.05
        self._synced = True
        self._settled = self.compose(self._settle_t + 1.0)
        return self._settled

    # ---------- 质检 ----------
    def validate(self, strict=True):
        m = self.metrics()
        safe_t, safe_b, safe_l, safe_r = m["safe"]
        return validate(self.reg, self.w, self.h, safe_t, safe_b, safe_l, safe_r,
                        strict, kind_bounds=m["kind_bounds"])

    def reset_reg(self):
        self.reg.reset()
