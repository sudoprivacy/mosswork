# -*- coding: utf-8 -*-
"""配照片讲解 PPT 视频工作流 —— CLI 入口。

用法示例：
  # 直接跑内置 demo（同一素材渲染 3 种风格）
  python main.py --demo

  # 传入结构化 brief
  python main.py --brief brief.json --style business --out D:/workbuddy/outputs/my.mp4

brief.json 示例：
{
  "title": "如何用 AI 做出爆款 PPT 视频",
  "template": "business_promo",
  "style": "business",
  "photos": ["D:/workbuddy/cache/voice_sample_frames/blogger.png"],
  "bg_image": "D:/微信小程序/船海风云/人物角色示例图/焊接现场PPE检查Q版情景视频提示词.png",
  "points": [
    {"type": "steps", "title": "三步流程", "steps": [
      {"n": "01", "t": "准备素材", "d": "把文案、照片、参考风格交给工作流"},
      {"n": "02", "t": "自动排版", "d": "工作流审题并生成多风格版式"},
      {"n": "03", "t": "一键出片", "d": "质检通过后合成带配音的视频"}
    ]},
    {"type": "data", "title": "效率提升", "data": {"value": "78%", "label": "效率提升", "desc": "实测比传统剪辑快数倍"}},
    {"type": "highlight", "title": "核心卖点", "keyword": "不出错", "sub": "自动质检拦截超屏/重叠/图压字"}
  ]
}
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from framework import engine as E


SAMPLE_BRIEF = {
    "title": "如何用 AI 做出爆款 PPT 视频",
    "subtitle": "一套可卖的工作流：多风格 + 照片融入 + 硬审核",
    "template": "business_promo",
    "style": "business",
    "photos": [
        r"D:\workbuddy\cache\voice_sample_frames\blogger.png"
    ],
    "bg_image": r"D:\微信小程序\船海风云\人物角色示例图\焊接现场PPE检查Q版情景视频提示词.png",
    "points": [
        {"type": "steps", "title": "三步流程", "caption_en": "Prepare material, auto layout, one-click export.", "steps": [
            {"n": "01", "t": "准备素材", "d": "文案、照片、风格要求一次性交给工作流"},
            {"n": "02", "t": "自动排版", "d": "审题模块按模板生成多场景版式"},
            {"n": "03", "t": "一键出片", "d": "硬审核通过后再合成配音视频"}
        ]},
        {"type": "split", "title": "学习方式", "caption_en": "Learn the lesson and remember your face.", "body": "观众既能吸收干货，又能记住你的脸，账号粘性自然变高。", "illustration": "learn"},
        {"type": "data", "title": "效率提升", "caption_en": "78% faster than manual editing with zero layout errors.", "data": {"value": "78%", "label": "效率提升", "desc": "实测比传统剪辑快数倍，且不出版式错误"}},
        {"type": "timeline", "title": "执行链路", "caption_en": "Brief -> template -> render -> QC.", "nodes": [
            {"t": "1", "d": "解析 brief"},
            {"t": "2", "d": "匹配模板与风格"},
            {"t": "3", "d": "逐帧渲染并质检"}
        ]},
        {"type": "glass", "title": "审核铁律", "caption_en": "Three gates: safe zone, no overlap, text above photo.", "body_title": "三道闸", "body": "所有文字必须落在安全区内，文字之间不得重叠，照片不得压住文字。出现任一项，严格模式直接报错并指出具体元素。"},
        {"type": "highlight", "title": "核心卖点", "caption_en": "Auto QC catches layout errors before export.", "keyword": "不出错", "sub": "自动质检拦截超屏、重叠、图压字，绝不带病出片"},
    ],
    "caption": "把这套工作流落地，卖视频、卖服务都可以",
    "caption_en": "A sellable workflow for auto PPT videos."
}


def run_demo():
    base = dict(SAMPLE_BRIEF)
    out_dir = r"D:\workbuddy\outputs\photo_ppt_framework_demo"
    os.makedirs(out_dir, exist_ok=True)
    results = []
    for style_key in ["business", "manga", "mechanical"]:
        brief = dict(base)
        brief["style"] = style_key
        out = os.path.join(out_dir, f"demo_{style_key}.mp4")
        print(f"\n========== 渲染 demo：{style_key} ==========")
        try:
            res = E.render(brief, out, workdir=os.path.join(out_dir, f"_frames_{style_key}"))
            print(f"✅ 成片：{out}")
            print(f"   时长：{res['duration']:.2f}s  帧数：{res['n_frames']}  质检：{'通过' if res['qc_passed'] else '未通过'}")
            results.append((style_key, out, res))
        except Exception as e:
            print(f"❌ 失败：{e}")
            results.append((style_key, None, {"error": str(e)}))

    # 汇总质检报告
    qc_all = os.path.join(out_dir, "qc_all.txt")
    with open(qc_all, "w", encoding="utf-8") as f:
        for style_key, out, res in results:
            f.write(f"\n--- {style_key} ---\n")
            if "qc_report_path" in res:
                try:
                    with open(res["qc_report_path"], "r", encoding="utf-8") as rf:
                        f.write(rf.read())
                except Exception as e:
                    f.write(f"读取失败：{e}\n")
            else:
                f.write(str(res.get("error", "未知")) + "\n")
    print(f"\n汇总质检报告：{qc_all}")
    return results


def main():
    parser = argparse.ArgumentParser(description="配照片讲解 PPT 视频工作流")
    parser.add_argument("--demo", action="store_true", help="跑内置 demo")
    parser.add_argument("--brief", help="brief JSON 文件路径")
    parser.add_argument("--style", default="business", help="风格：business/manga/realistic/guofeng/mechanical/punk")
    parser.add_argument("--template", help="模板：student_lecture/business_promo/standard_explain/product_promo")
    parser.add_argument("--photos", help="照片路径，用逗号分隔")
    parser.add_argument("--bg", help="写实风背景图路径")
    parser.add_argument("--out", default=r"D:\workbuddy\outputs\photo_ppt_output.mp4", help="输出 mp4 路径")
    parser.add_argument("--orientation", default="portrait",
                        help="画面方向：portrait（竖屏 1080x1920）或 landscape（横屏 1920x1080）")
    parser.add_argument("--voice", default=None,
                        help="音色/性别预设：female_warm/female_calm/female_lyric/male_steady/male_young/male_narrator，或直接传 voice id")
    parser.add_argument("--no-natural", action="store_true", help="关闭去 AI 味（使用原始机械朗读）")
    parser.add_argument("--host-position", default="right",
                        help="主播位：right / left / center（center 用于突出用户指定内容）")
    parser.add_argument("--list", action="store_true", help="列出可用风格与模板")
    args = parser.parse_args()

    if args.list:
        print("可用风格：")
        for k, name, desc in E.available()["styles"]:
            print(f"  {k:<12} {name}  —— {desc}")
        print("\n可用模板：")
        for k, name, desc in E.available()["templates"]:
            print(f"  {k:<18} {name}  —— {desc}")
        return

    if args.demo:
        run_demo()
        return

    if args.brief:
        with open(args.brief, "r", encoding="utf-8") as f:
            brief = json.load(f)
    else:
        brief = dict(SAMPLE_BRIEF)

    if args.style:
        brief["style"] = args.style
    if args.template:
        brief["template"] = args.template
    if args.photos:
        brief["photos"] = [p.strip() for p in args.photos.split(",") if p.strip()]
    if args.bg:
        brief["bg_image"] = args.bg
    if args.voice:
        brief["voice"] = args.voice
    if args.host_position:
        brief["host_position"] = args.host_position

    base_name = os.path.splitext(os.path.basename(args.out))[0]
    res = E.render(brief, args.out,
                   workdir=os.path.join(os.path.dirname(args.out), f"_{base_name}_frames"),
                   orientation=args.orientation, voice=args.voice,
                   natural=not args.no_natural, host_position=args.host_position)
    print(f"\n✅ 成片：{res['mp4']}")
    print(f"   方向 {res['orientation']} | 时长 {res['duration']:.2f}s | 质检 {'通过' if res['qc_passed'] else '未通过'} | 音色 {res['voice']}")
    print(f"   报告：{res['qc_report_path']}")
    print("\n审题结论：")
    for r in res["review"]:
        print(f"  • {r}")


if __name__ == "__main__":
    main()
