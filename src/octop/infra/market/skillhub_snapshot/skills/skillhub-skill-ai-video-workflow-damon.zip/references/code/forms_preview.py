# -*- coding: utf-8 -*-
"""形式矩阵截图 —— 一眼看清这套工作流到底有多少种"形式"。

为什么需要它：
  出样片只能一次看一种形式，看不出全貌。这里把 6 种风格 × 9 种版式 × 2 种
  方向全部渲染成静帧网格，一眼可查、可对比、可挑。所有画面都走真实渲染链
  （generate_bg → Canvas → draw_scene → compose），**不造假图**。

用法：
  python forms_preview.py                 # 全量：2 张矩阵 + 2 张版式总览
  python forms_preview.py --only matrix   # 只要 6×9 矩阵
  python forms_preview.py --only gallery  # 只要 3×3 版式总览

输出：_forms_preview/*.png

复用：样例场景直接吃 smoke_test.sample_scene，与回归冒烟闸同源，
      不另造一份场景定义（避免"演示用的和实际跑的不一样"）。
"""
import argparse
import os
import sys
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
FW_PARENT = os.path.join(HERE, "图片讲解视频")
for _p in (FW_PARENT, HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import smoke_test as ST                      # noqa: E402
from framework import styles as S            # noqa: E402
from framework import layouts as L           # noqa: E402
from framework import canvas as C            # noqa: E402
from framework import backgrounds as B       # noqa: E402

OUT_DIR = os.path.join(HERE, "_forms_preview")

STYLES = list(S.STYLES.keys())
LAYOUTS = list(L.LAYOUTS.keys())

STYLE_CN = {
    "business": "商务", "manga": "漫感", "realistic": "写实",
    "guofeng": "国风", "mechanical": "机械", "punk": "赛博",
}
LAYOUT_CN = {
    "cover": "封面", "steps": "步骤", "split": "分栏", "data": "数据",
    "timeline": "时间线", "glass": "玻璃卡", "highlight": "重点",
    "quote": "引言", "compare": "对比",
}

DIMS = {"portrait": (1080, 1920), "landscape": (1920, 1080)}


def _font(sz):
    for p in (r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\msyh.ttc"):
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, sz)
            except Exception:
                pass
    return ImageFont.load_default()


def render_cell(style_name, layout_name, orientation, photo_path, seed=0):
    """渲染一格：走真实渲染链，t 取足够大让所有元素入场完成。"""
    w, h = DIMS[orientation]
    style = S.STYLES[style_name]
    cv = C.Canvas(style, w, h)
    cv.set_background(B.generate_bg(style, w, h))
    cv._seed = seed
    cv._appear_base = 0.1
    sc = ST.sample_scene(layout_name, figure_path=photo_path)
    photo = [(Image.open(photo_path).convert("RGBA"), None)]
    L.draw_scene(sc, cv, style, photos=photo, t=1.0, dur=3.0)
    return cv.compose(6.0).convert("RGB")


def _label(cn, en=""):
    return f"{cn} {en}".strip()


def build_matrix(orientation, photo_path, cell_w=190):
    """6 风格 × 9 版式 全矩阵。"""
    w, h = DIMS[orientation]
    cw = cell_w
    ch = int(round(cw * h / w))
    pad, lab_w, top = 14, 138, 68
    cols, rows = len(LAYOUTS), len(STYLES)
    W = lab_w + cols * (cw + pad) + pad
    H = top + rows * (ch + pad) + pad

    img = Image.new("RGB", (W, H), (22, 24, 30))
    d = ImageDraw.Draw(img)
    f_title = _font(30)
    f_lab = _font(22)

    d.text((pad, 18),
           f"形式矩阵 · {orientation}  {w}×{h} · 6 风格 × 9 版式 = {cols * rows} 种",
           font=f_title, fill=(235, 240, 250))

    for ci, lt in enumerate(LAYOUTS):
        d.text((lab_w + pad + ci * (cw + pad), 44),
               _label(LAYOUT_CN.get(lt, lt), lt),
               font=f_lab, fill=(150, 200, 255))

    for ri, st in enumerate(STYLES):
        y = top + ri * (ch + pad)
        d.text((pad, y + ch // 2 - 12),
               _label(STYLE_CN.get(st, st), st),
               font=f_lab, fill=(255, 210, 140))
        for ci, lt in enumerate(LAYOUTS):
            cell = render_cell(st, lt, orientation, photo_path, seed=ri * 10 + ci)
            x = lab_w + pad + ci * (cw + pad)
            img.paste(cell.resize((cw, ch), Image.LANCZOS), (x, y))
            d.rectangle([x - 1, y - 1, x + cw, y + ch], outline=(70, 78, 92), width=1)
    return img


def build_gallery(orientation, photo_path, style_name="mechanical", cell_w=340):
    """单风格 9 版式 3×3 全尺寸总览（看得清排版细节）。"""
    w, h = DIMS[orientation]
    cw = cell_w
    ch = int(round(cw * h / w))
    pad, top = 16, 58
    W = 3 * cw + 4 * pad
    H = top + 3 * (ch + pad) + pad

    img = Image.new("RGB", (W, H), (22, 24, 30))
    d = ImageDraw.Draw(img)
    f_title = _font(28)
    f_lab = _font(20)
    d.text((pad, 16),
           f"版式总览 · {orientation} · 风格 {STYLE_CN.get(style_name, style_name)}"
           f"（{style_name}） · 9 种版式",
           font=f_title, fill=(235, 240, 250))

    for i, lt in enumerate(LAYOUTS):
        r, c = divmod(i, 3)
        x = pad + c * (cw + pad)
        y = top + r * (ch + pad)
        cell = render_cell(style_name, lt, orientation, photo_path, seed=i)
        img.paste(cell.resize((cw, ch), Image.LANCZOS), (x, y))
        d.rectangle([x - 1, y - 1, x + cw, y + ch], outline=(80, 88, 104), width=1)
        d.text((x + 4, y + ch + 2),
               _label(LAYOUT_CN.get(lt, lt), lt),
               font=f_lab, fill=(150, 200, 255))
    return img


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default=None, choices=["matrix", "gallery"])
    args = ap.parse_args()

    os.makedirs(OUT_DIR, exist_ok=True)
    tmp = os.path.join(OUT_DIR, "_tmp")
    os.makedirs(tmp, exist_ok=True)
    photo = os.path.join(tmp, "dummy.jpg")
    ST.make_dummy_photo(photo)

    made = []
    jobs = []
    if args.only in (None, "matrix"):
        jobs += [("matrix", o) for o in ("portrait", "landscape")]
    if args.only in (None, "gallery"):
        jobs += [("gallery", o) for o in ("portrait", "landscape")]

    for kind, o in jobs:
        print(f"  渲染 {kind}/{o} ...", flush=True)
        if kind == "matrix":
            img = build_matrix(o, photo)
            name = f"形式矩阵_{'竖屏' if o == 'portrait' else '横屏'}_6风格x9版式.png"
        else:
            img = build_gallery(o, photo)
            name = f"版式总览_{'竖屏' if o == 'portrait' else '横屏'}_9版式.png"
        p = os.path.join(OUT_DIR, name)
        img.save(p)
        made.append((p, img.size))
        print(f"    -> {name}  {img.size[0]}×{img.size[1]}")

    print("=" * 60)
    print(f"共 {len(made)} 张，输出目录：{OUT_DIR}")
    for p, size in made:
        print(f"  {size[0]}×{size[1]}  {os.path.basename(p)}")
    print("=" * 60)


if __name__ == "__main__":
    main()
