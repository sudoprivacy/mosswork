#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""用 TTS 互相关得到的【真实出现位置】重建 hvac_07 字幕。
关键发现：hvac_07 视频对白顺序被豆包打乱，不能按脚本顺序 1:1 映射。
每句字幕钉在其真实说话位置（相关系数 0.94~0.99）。"""
import json

HERE = "D:/微信小程序/情景视频存放处/豆包视频加字幕工作流"
ALIGN = json.load(open(HERE + "/tts_align.json", encoding="utf-8"))

EN = [
    "Silencing and vibration isolation hold point.",
    "Confirm the silencer direction and the isolation hangers.",
    "Silencer installed with the flow arrow correct,",
    "isolation hangers on the fan and the duct near it.",
    "The silencer is upstream of the fan as drawn.",
    "But the duct is hard-coupled to the structure at this bracket — add an isolation hanger there.",
    "We will fit the isolation hanger and break the rigid link.",
    "Good.",
    "No rigid path to the structure.",
    "After the fix I sign the silencing and isolation.",
    "Hanger fitted, rigid link removed.",
    "Tagged as done.",
    "Good.",
    "Silencing and isolation accepted.",
    "Punch, rigid coupling.",
]
CN = [
    "消声与减震停止点。",
    "确认消声器方向与减震吊架。",
    "消声器按流向箭头装对，",
    "风机及邻近风管装了减震吊架。",
    "消声器在风机上游，与图一致。",
    "但这处支架把风管硬接到了结构——那里加减震吊架。",
    "我们装减震吊架、断开刚性连接。",
    "好。",
    "无通向结构的刚性传声路径。",
    "整改后我签消声与减震。",
    "吊架装好、刚性连接断开。",
    "标了完成。",
    "好。",
    "消声与减震接受。",
    "尾项，刚性连接。",
]

LEAD = 0.20          # 字幕提前量（覆盖 TTS 头部静音+让字幕压着说话起）
MIN_DUR = 0.80       # 最短显示时长，避免相邻近句零时长

def wrap_cn(s, n=18):
    return "\\N".join(s[i:i + n] for i in range(0, len(s), n))

def wrap_en(s, n=38):
    if len(s) <= n:
        return s
    words = s.split(" "); lines = []; cur = ""
    for wd in words:
        if cur and len(cur) + 1 + len(wd) > n:
            lines.append(cur); cur = wd
        else:
            cur = (cur + " " + wd).strip()
    if cur:
        lines.append(cur)
    return "\\N".join(lines)

def s2ass(t):
    h = int(t // 3600); m = int((t % 3600) // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"

# ALIGN: [[idx(1-based), pos, score, text], ...]
items = []
for idx, pos, score, text in ALIGN:
    items.append({"i": idx - 1, "pos": pos, "score": score})
# 按真实出现时间排序
items.sort(key=lambda x: x["pos"])

lines = [
    "[Script Info]", "ScriptType: v4.00+", "PlayResX: 1080", "PlayResY: 1920",
    "WrapStyle: 1", "", "[V4+ Styles]",
    "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
    "Style: Default,Microsoft YaHei,40,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,3,2,2,60,60,30,1",
    "", "[Events]",
    "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
]
for k, it in enumerate(items):
    start = max(0.0, it["pos"] - LEAD)
    if k + 1 < len(items):
        end = max(start + MIN_DUR, items[k + 1]["pos"] - LEAD)
    else:
        end = start + 3.0
    if end - start < MIN_DUR:
        end = start + MIN_DUR
    en = EN[it["i"]]; cn = CN[it["i"]]
    text = wrap_en(en) + "\\N" + wrap_cn(cn)
    lines.append("Dialogue: 0,%s,%s,Default,,0,0,0,,%s" % (s2ass(start), s2ass(end), text))
    print("%2d  真实%.2fs  相关%.3f  %s" % (it["i"] + 1, it["pos"], it["score"], en[:40]))

open(HERE + "/hvac_07_fixed.ass", "w", encoding="utf-8").write("\n".join(lines) + "\n")
print("\n已生成 hvac_07_fixed.ass（按真实位置，非脚本顺序）")
