#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""用 HVAC-07 原文(15句拆分) + 真实说话段(15段) 1:1 对齐，生成 ASS。
铁律：英上中下、不超屏、无黑幕、Shadow=2、竖屏1080x1920。
"""
import json

REGIONS = json.load(open("hvac_07_regions.json", encoding="utf-8"))

# 原文 englishContent / chineseContent 按 逗号/句号 拆分，顺序与说话段一致
EN = [
    "Silencing and vibration isolation hold point.",
    "Confirm the silencer direction and the isolation hangers.",
    "Silencer installed with the flow arrow correct,",
    "isolation hangers on the fan and the duct near it.",
    "The silencer is upstream of the fan as drawn.",
    "But the duct is hard-coupled to the structure at this bracket — add an isolation hanger there.",
    "We will fit the isolation hanger and break the rigid link.",
    "Good.",
    "No rigid path to the structure.",
    "After the fix I sign the silencing and isolation.",
    "Hanger fitted, rigid link removed.",
    "Tagged as done.",
    "Good.",
    "Silencing and isolation accepted.",
    "Punch, rigid coupling.",
]
CN = [
    "消声与减震停止点。",
    "确认消声器方向与减震吊架。",
    "消声器按流向箭头装对，",
    "风机及邻近风管装了减震吊架。",
    "消声器在风机上游，与图一致。",
    "但这处支架把风管硬接到了结构——那里加减震吊架。",
    "我们装减震吊架、断开刚性连接。",
    "好。",
    "无通向结构的刚性传声路径。",
    "整改后我签消声与减震。",
    "吊架装好、刚性连接断开。",
    "标了完成。",
    "好。",
    "消声与减震接受。",
    "尾项，刚性连接。",
]

def wrap_cn(s, n=18):
    if len(s) <= n:
        return s
    out = []
    for i in range(0, len(s), n):
        out.append(s[i:i + n])
    return "\\N".join(out)

def wrap_en(s, n=38):
    if len(s) <= n:
        return s
    words = s.split(" ")
    lines, cur = [], ""
    for w in words:
        if cur and len(cur) + 1 + len(w) > n:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return "\\N".join(lines)

assert len(EN) == len(CN) == len(REGIONS), (len(EN), len(CN), len(REGIONS))

def fmt(t):
    h = int(t // 3600); m = int((t % 3600) // 60); s = t % 60
    return "%d:%02d:%06.2f" % (h, m, s)

lines = []
lines.append("[Script Info]")
lines.append("ScriptType: v4.00+")
lines.append("PlayResX: 1080")
lines.append("PlayResY: 1920")
lines.append("WrapStyle: 1")
lines.append("")
lines.append("[V4+ Styles]")
lines.append("Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding")
lines.append("Style: Default,Microsoft YaHei,40,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,3,2,2,60,60,30,1")
lines.append("")
lines.append("[Events]")
lines.append("Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text")

for i in range(len(EN)):
    s, e = REGIONS[i]
    start = fmt(s)
    # 持续性：本句结束 -> 下一句开始（末句延展到本段结束+0.4s）
    if i + 1 < len(REGIONS):
        end = fmt(REGIONS[i + 1][0])
    else:
        end = fmt(e + 0.4)
    text = wrap_en(EN[i]) + "\\N" + wrap_cn(CN[i])
    lines.append("Dialogue: 0,%s,%s,Default,,0,0,0,,%s" % (start, end, text))

open("hvac_07_fixed.ass", "w", encoding="utf-8").write("\n".join(lines) + "\n")
print("已生成 hvac_07_fixed.ass，共 %d 句" % len(EN))
for i in range(len(EN)):
    s, e = REGIONS[i]
    print("%2d  %6.2f-%6.2f  %s" % (i + 1, s, e, EN[i][:42]))
