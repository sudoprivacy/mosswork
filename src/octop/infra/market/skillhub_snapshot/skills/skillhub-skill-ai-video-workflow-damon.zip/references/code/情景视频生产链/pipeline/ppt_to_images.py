#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PPT -> 每页 PNG: projects/<proj>/images/slide_01.png, slide_02.png ...

优先用本机已装的 PowerPoint(COM) 自动导出; 没有则给出手动导出指引。
这样"自己用 PPT + 脚本生成视频"就打通了: 先本脚本把每页变图,
再 make_ppt_scenes.py 把脚本文案对上每页, 最后 build_video.py 合成。

用法:
  python pipeline/ppt_to_images.py --ppt "D:/slides/培训.pptx" --project ppt_demo
"""
import os, sys, argparse, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(ROOT, 'pipeline', 'config.json'), encoding='utf-8'))
ASPECTS = {'16:9': (1920, 1080), '9:16': (1080, 1920), '1:1': (1080, 1080)}


def ppt_to_images(ppt_path, img_dir, aspect):
    W, H = ASPECTS[aspect]
    try:
        import win32com.client
    except Exception:
        sys.exit('需要 pywin32, 在 venv 里执行: pip install pywin32')
    try:
        ppt = win32com.client.Dispatch('PowerPoint.Application')
    except Exception as e:
        sys.exit('无法启动 PowerPoint(COM): %s\n如果你没装 Office, 请手动把每页导出为 PNG, '
                '命名为 slide_01.png, slide_02.png ... 放到 %s' % (e, img_dir))
    try:
        ppt.Visible = False
    except Exception:
        pass
    ap = os.path.abspath(ppt_path)
    pres = None
    try:
        pres = ppt.Presentations.Open(ap, WithWindow=False)
    except Exception:
        try:
            pres = ppt.Presentations.Open(ap)
        except Exception as e:
            sys.exit('打开 PPT 失败: %s' % e)
    os.makedirs(img_dir, exist_ok=True)
    n = pres.Slides.Count
    try:
        for k in range(1, n + 1):
            out = os.path.join(img_dir, 'slide_%02d.png' % k)
            try:
                pres.Slides.Item(k).Export(os.path.abspath(out), 'PNG', W, H)
            except Exception:
                # 个别版本 Export 不接受宽高参数, 退化为默认尺寸
                pres.Slides.Item(k).Export(os.path.abspath(out), 'PNG')
            print('  slide %d -> %s' % (k, out))
    finally:
        try:
            pres.Close()
        except Exception:
            pass
        try:
            ppt.Quit()
        except Exception:
            pass
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ppt', required=True, help='PPT / PPTX 文件路径')
    ap.add_argument('--project', required=True)
    ap.add_argument('--aspect', default=CFG.get('default_aspect', '16:9'),
                    choices=list(ASPECTS))
    a = ap.parse_args()
    img_dir = os.path.join(ROOT, 'projects', a.project, 'images')
    n = ppt_to_images(a.ppt, img_dir, a.aspect)
    print('PPT 导出完成: %d 页 -> %s' % (n, img_dir))


if __name__ == '__main__':
    main()
