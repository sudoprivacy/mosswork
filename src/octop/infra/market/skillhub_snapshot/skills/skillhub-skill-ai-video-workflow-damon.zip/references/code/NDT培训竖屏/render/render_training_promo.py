# -*- coding: utf-8 -*-
# 培训宣传 PPT 视频 —— 独立新流水线（不修改标准讲解视频工作流的任何脚本）。
# 基础设施沿用之前的思路：PIL 画图 + edge-tts 配音 + ffmpeg concat（veryfast/crf18）。
# 内容来源：D:\微信小程序\培训广告\关于开办2026年8月份TÜV奥地利认证无损检测人员资格培训认证通知1.pdf
# 隐私红线：不放入 银行账号/开户行、培训具体时间地点、邮箱/电话/微信/联系人。
#   费用只做中性说明，不写具体数字、不写银行。
import os, sys, json, time, argparse, subprocess, io
from PIL import Image, ImageDraw, ImageFont, ImageEnhance

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RENDER_DIR = os.path.join(ROOT, "render")
TMP = os.path.join(RENDER_DIR, "promo_tmp")
os.makedirs(TMP, exist_ok=True)

FFMPEG = r"C:\Users\Damon\AppData\Local\Programs\Python\Python312\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe"
BG_PATH = r"D:\微信小程序\船海风云\人物角色示例图\焊接现场PPE检查Q版情景视频提示词.png"
OUT_DIR = r"D:\微信小程序\标准视频库"
FINAL_NAME = "TUV无损检测培训宣传.mp4"

W, H = 1920, 1080
FPS = 30
PRESET = "veryfast"
CRF = 18

# ---- 字体（中文/英文分开，避免方块） ----
def F(path, size):
    return ImageFont.truetype(path, size)
FONTS = {
    "cn_b64": F(r"C:\Windows\Fonts\msyhbd.ttc", 64),
    "cn_b40": F(r"C:\Windows\Fonts\msyhbd.ttc", 40),
    "cn_b34": F(r"C:\Windows\Fonts\msyhbd.ttc", 34),
    "cn30":   F(r"C:\Windows\Fonts\msyh.ttc", 30),
    "cn26":   F(r"C:\Windows\Fonts\msyh.ttc", 26),
    "en30":   F(r"C:\Windows\Fonts\arialbd.ttf", 30),
    "en24":   F(r"C:\Windows\Fonts\arial.ttf", 24),
}

WHITE = (236, 243, 255, 255)
GOLD  = (255, 193, 7, 255)
CYAN  = (56, 189, 248, 255)
SUB   = (150, 172, 205, 255)
PANEL = (8, 12, 28, 205)

# ---- 背景：工业风钢蓝 HUD（与之前工作流同款逻辑） ----
def build_bg():
    bg = Image.open(BG_PATH).convert("RGB")
    # cover resize 到 1920x1080
    sw, sh = bg.size
    scale = max(W / sw, H / sh)
    bg = bg.resize((int(sw * scale), int(sh * scale)))
    lw, lh = bg.size
    bg = bg.crop(((lw - W) // 2, (lh - H) // 2, (lw - W) // 2 + W, (lh - H) // 2 + H))
    bg = ImageEnhance.Brightness(bg).enhance(0.42)
    bg = ImageEnhance.Color(bg).enhance(0.50)
    bg = ImageEnhance.Contrast(bg).enhance(1.08)
    tint = Image.new("RGB", (W, H), (10, 22, 46))
    bg = Image.blend(bg, tint, 0.45)
    g = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(g)
    step = 40
    for x in range(0, W, step):
        gd.line([(x, 0), (x, H)], fill=(56, 189, 248, 18), width=1)
    for y in range(0, H, step):
        gd.line([(0, y), (W, y)], fill=(56, 189, 248, 18), width=1)
    bg = Image.alpha_composite(bg.convert("RGBA"), g).convert("RGB")
    return bg

def rounded_rect(d, box, radius, fill=None, outline=None, width=2):
    d.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)

# ---- 幻灯片数据（仅公开宣传内容） ----
SLIDES = [
    {
        "title_cn": "TÜV奥地利认证 无损检测人员资格培训",
        "title_en": "TÜV AUSTRIA CERTIFIED NDT PERSONNEL TRAINING",
        "footer": "南通恩迪益无损检测培训中心 · TÜV奥地利中国唯一授权",
        "lead": "国际认可 · 全球通用 · 出海通行证",
        "narration": "想拿下国际认可的无损检测人员资格？TÜV奥地利认证培训，帮你拿到通往全球工业领域的通行证。",
    },
    {
        "title_cn": "证书权威性 · 国际互认",
        "title_en": "GLOBALLY RECOGNIZED & MUTUALLY ACCEPTED",
        "bullets": [
            ("标准", "符合 EN ISO 9712，满足 PED 2014/68/EU 欧盟压力设备指令"),
            ("认可", "TURKAK 依据 ISO/IEC 17024 认可，签署 IAF / ilac 互认协议"),
            ("范围", "欧盟及全球工业领域认可，适合出海项目与外企岗位"),
            ("可查", "证书唯一编号，官网在线验真"),
        ],
        "narration": "TÜV奥地利学院依据国际标准颁发证书，获欧盟认可机构认可并签署国际互认协议，在欧盟及全球工业领域广泛认可，还可在线验真。",
    },
    {
        "title_cn": "适用行业 · 应用广泛",
        "title_en": "WIDELY USED ACROSS INDUSTRIES",
        "bullets": [
            ("能源海工", "风电 · 海洋工程 · 石油 · 核电"),
            ("装备制造", "船舶修造 · 铁路 · 机械制造 · 钢构"),
            ("高端承压", "压力容器 · 锅炉 · 压力管道等欧标设备"),
        ],
        "narration": "这张证书广泛应用于风电、船舶修造、海洋工程、铁路、石油、机械制造、钢构等行业，是出海项目和外企岗位的有力资质。",
    },
    {
        "title_cn": "六大检测方法 · 任选报名",
        "title_en": "SIX NDT METHODS · CHOOSE YOURS",
        "layout": "grid6",
        "grid": [
            ("VT", "目视检测"), ("UT", "超声波检测"), ("RT", "射线检测"),
            ("MT", "磁粉检测"), ("PT", "渗透检测"), ("PAUT", "相控阵超声"),
        ],
        "narration": "培训涵盖目视、超声、射线、磁粉、渗透、相控阵超声六大类无损检测方法，学员可任选单一或多个方法报名。",
    },
    {
        "title_cn": "三个资格等级 · 能力递进",
        "title_en": "THREE LEVELS · PROGRESSIVE COMPETENCE",
        "bullets": [
            ("Ⅰ级 初级", "掌握基础理论，在Ⅱ/Ⅲ级指导下完成检测"),
            ("Ⅱ级 中级", "独立制定方案、操作设备并评定结果"),
            ("Ⅲ级 高级", "制定标准、审核方案、解决复杂技术问题"),
        ],
        "narration": "按 EN ISO 9712，分三个等级：一级在指导下作业，二级能独立操作与评定，三级具备制定标准和解决复杂问题的能力。",
    },
    {
        "title_cn": "培训模式 · 理实一体",
        "title_en": "INTEGRATED THEORY & PRACTICE",
        "bullets": [
            ("理论教学", "标准规范 · 设备原理 · 缺陷识别与评定"),
            ("实操训练", "行业设备实战，每人独立操作不少于 40 学时"),
            ("考核评估", "理论 + 实操双科，均达 70 分合格"),
        ],
        "narration": "培训采用理论教学、实操训练和考核评估相结合的方式，每人独立实操不少于40学时，理论与实操双科合格方可取证。",
    },
    {
        "title_cn": "适合人群 · 广泛覆盖",
        "title_en": "WHO SHOULD ATTEND",
        "bullets": [
            ("从业者", "拟从事或已从事无损检测，需取得资格认证"),
            ("技术质量岗", "制造·海工·石化·核电·船舶·轨交等技术与质量管理人员"),
            ("提升需求", "需资格续期、增项或技能提升的在职人员"),
        ],
        "narration": "无论你是准备入行的从业者，还是制造、海工、石化、核电等行业的技术与质量管理人员，或需要续期增项提升，都能找到适合的方向。",
    },
    {
        "title_cn": "报名基本条件",
        "title_en": "BASIC ELIGIBILITY",
        "bullets": [
            ("学历", "Ⅰ级高中及以上 · Ⅱ级大专及以上理工科"),
            ("资质", "报考Ⅱ/Ⅲ级需相应工作经验证明"),
            ("身体", "无色盲色弱，矫正视力达标"),
        ],
        "narration": "报名需满足学历、资质与身体条件：一级要求高中以上学历，二级要求大专以上理工科，并需提供工作经验证明，视力符合标准要求。",
    },
    {
        "title_cn": "培训费用说明",
        "title_en": "FEES & PAYMENT (OVERVIEW)",
        "bullets": [
            ("按项收取", "费用按检测方法与资格等级收取"),
            ("可选 PED", "PED 证书为可选项，按需自主选择"),
            ("以当期通知为准", "具体标准详见官方当期培训通知"),
        ],
        "narration": "培训费按检测方法和资格等级收取，PED证书为可选项。具体费用标准以官方当期培训通知为准。",
    },
    {
        "title_cn": "开启你的全球职业通道",
        "title_en": "OPEN YOUR GLOBAL CAREER PATH",
        "footer": "南通恩迪益无损检测培训中心",
        "lead": "获取国际认可无损检测人员资格，详情请关注官方当期培训通知",
        "narration": "获取一张国际认可的无损检测人员证书，为你的职业打开全球通道。详情请关注官方当期培训通知。",
    },
]

def draw_slide(slide):
    """渲染单张幻灯片为全不透明 RGB 图（静态，PPT 风）。"""
    im = BG.convert("RGBA")
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    # 主面板
    rounded_rect(d, [100, 70, 1820, 1000], radius=24, fill=PANEL)
    rounded_rect(d, [100, 70, 1820, 1000], radius=24, outline=CYAN, width=2)

    # 标题
    d.text((150, 110), slide["title_cn"], font=FONTS["cn_b64"], fill=WHITE, anchor="lt")
    d.text((152, 188), slide["title_en"], font=FONTS["en30"], fill=GOLD, anchor="lt")
    d.line([(150, 232), (1770, 232)], fill=CYAN, width=3)

    if slide.get("layout") == "grid6":
        cards = slide["grid"]
        cw, ch = 520, 230
        xs = [150, 150 + cw + 40, 150 + 2 * (cw + 40)]
        ys = [300, 300 + ch + 40]
        for i, (code, name) in enumerate(cards):
            cx, cy = xs[i % 3], ys[i // 3]
            rounded_rect(d, [cx, cy, cx + cw, cy + ch], radius=18, fill=(14, 22, 44, 230), outline=GOLD, width=2)
            d.text((cx + cw // 2, cy + 78), code, font=FONTS["cn_b64"], fill=GOLD, anchor="mm")
            d.text((cx + cw // 2, cy + 165), name, font=FONTS["cn_b34"], fill=WHITE, anchor="mm")
    elif slide.get("lead") and not slide.get("bullets"):
        # 封面 / 结尾：居中引导语
        d.text((W // 2, 470), slide.get("lead", ""), font=FONTS["cn_b40"], fill=CYAN, anchor="mm")
    else:
        for i, (lead, det) in enumerate(slide.get("bullets", [])):
            y = 300 + i * 128
            d.ellipse([162, y + 16, 188, y + 42], fill=GOLD)
            d.text((210, y), lead, font=FONTS["cn_b40"], fill=GOLD, anchor="lt")
            d.text((210, y + 52), det, font=FONTS["cn30"], fill=WHITE, anchor="lt")

    if slide.get("footer"):
        d.text((150, 1024), slide["footer"], font=FONTS["cn26"], fill=SUB, anchor="lt")

    im = Image.alpha_composite(im, layer).convert("RGB")
    return im

# ---- TTS ----
def tts(text, out_mp3):
    try:
        import edge_tts
        import asyncio
        voice = "zh-CN-YunxiNeural"
        async def _run():
            comm = edge_tts.Communicate(text, voice)
            await comm.save(out_mp3)
        for attempt in range(3):
            try:
                asyncio.new_event_loop().run_until_complete(_run())
                if os.path.getsize(out_mp3) > 0:
                    return True
            except Exception as e:
                print(f"  TTS 第{attempt+1}次失败:", e)
                time.sleep(1.5)
        return False
    except Exception as e:
        print("  TTS 失败:", e)
        return False

def make_silent(out_mp3, dur):
    subprocess.run([FFMPEG, "-y", "-f", "lavfi", "-i", f"anullsrc=r=24000:cl=mono",
                    "-t", str(dur), out_mp3], check=True, capture_output=True)

def audio_dur(mp3):
    r = subprocess.run([FFMPEG, "-i", mp3], capture_output=True, encoding="utf-8", errors="ignore")
    import re
    m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", r.stderr)
    if m:
        h, mi, s = map(float, (m.group(1), m.group(2), m.group(3)))
        return h * 3600 + mi * 60 + s
    return 0

# ---- 主流程 ----
def main():
    global BG
    BG = build_bg()
    segs = []
    for i, slide in enumerate(SLIDES):
        png = os.path.join(TMP, f"slide_{i:02d}.png")
        im = draw_slide(slide)
        im.save(png, "PNG")

        mp3 = os.path.join(TMP, f"slide_{i:02d}.mp3")
        ok = tts(slide["narration"], mp3)
        if not ok:
            est = len(slide["narration"]) * 0.28 + 1.5
            make_silent(mp3, est)
        dur = audio_dur(mp3)
        dur = max(dur + 0.4, 4.0)
        seg = os.path.join(TMP, f"seg_{i:02d}.mp4")
        subprocess.run([FFMPEG, "-y", "-loop", "1", "-i", png, "-i", mp3,
                        "-c:v", "libx264", "-preset", PRESET, "-crf", str(CRF),
                        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
                        "-t", f"{dur:.2f}", "-shortest", "-movflags", "+faststart", seg],
                       check=True, capture_output=True)
        segs.append(seg)
        print(f"  slide {i}: {dur:.1f}s  {slide['title_cn'][:14]}")

    # concat（ASCII 临时清单，避免中文路径乱码）
    list_txt = os.path.join(TMP, "promo_list.txt")
    with open(list_txt, "w", encoding="utf-8") as f:
        for s in segs:
            f.write(f"file '{s}'\n")
    out_path = os.path.join(OUT_DIR, FINAL_NAME)
    os.makedirs(OUT_DIR, exist_ok=True)
    subprocess.run([FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", list_txt,
                    "-c", "copy", out_path], check=True, capture_output=True)
    print("DONE ->", out_path)
    print("总时长约 %.1f 秒" % sum(audio_dur(s) + 0.4 for s in segs))

if __name__ == "__main__":
    main()
