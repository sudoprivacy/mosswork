# -*- coding: utf-8 -*-
"""
workflow.py — 固定工作流统一入口（六步法 + 红线闸门）

任何新视频任务都先走这套：
  ①审题 → ②定方向 → ③排版 → ④定形式 → ⑤质检校验 → ⑥出片验收

本入口把"图片讲解视频/framework"那条最完整的六步链（content.plan →
Canvas+layouts → validator 三道闸 → engine.render）串起来，并在出片后
强制跑 check.py 的 A0–A8 硬闸门。任一步踩红线 → 当场报错、指出元素、不出片。

用法:
    python workflow.py --demo                 # 跑内置样例（竖屏 + 横屏各一）
    python workflow.py --brief your.json      # 用结构化 Brief 走六步
    python workflow.py --title "..." --points "a;b;c" --orientation portrait

红线（违反即退出非 0，绝不出片）:
  - Brief 缺 title / 标准讲解无真实原图 → 审题拦截
  - 超屏 / 文本重叠 / 图压字 → validator strict 抛错
  - 话画不一致 / 配音空 / 时长脱钩 → engine 拦截
  - check.py A0–A8 任一 FAIL → 出片验收拦截
"""
from __future__ import annotations

import argparse
import io
import json
import os
import re
import sys
import traceback

# 让 framework 包可导入（图片讲解视频/ 是包父目录）
_HERE = os.path.dirname(os.path.abspath(__file__))
_FRAMEWORK_PARENT = os.path.join(_HERE, "图片讲解视频")
if _FRAMEWORK_PARENT not in sys.path:
    sys.path.insert(0, _FRAMEWORK_PARENT)

# check.py 在同目录，直接 import
sys.path.insert(0, _HERE)

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from framework import engine as ENG  # noqa: E402
import check as CHK  # noqa: E402

OUT_DIR = r"D:\微信小程序\标准视频库"


def _demo_brief(orientation: str) -> dict:
    """内置样例：纯文字学生讲义（不需要真实标准图），证明六步通。"""
    return {
        "title": "AWS D1.1 焊接位置评定速记",
        "subtitle": "焊工考试 vs 工艺评定",
        "template": "student_lecture",
        "style": "mechanical",
        "material": "",
        "points": [
            {"type": "steps", "title": "评定位置怎么读",
             "body": "1G 平焊 / 2G 横焊 / 3G 立焊 / 4G 仰焊，数字代表试件角度。",
             "explain": "焊工考试的位置代号由数字+字母组成：数字 1-4 表示试件空间角度，字母 G 表示坡口焊。",
             "keyword": "位置代号"},
            {"type": "data", "title": "合格率关键",
             "body": "评定合格位置覆盖所有更简易位置，例如 3G 立焊合格即覆盖 1G/2G。",
             "explain": "按 AWS D1.1，较高难度的评定位置合格，自动覆盖较低难度的位置，这是资格覆盖规则。",
             "keyword": "覆盖规则"},
            {"type": "highlight", "title": "别混淆两件事",
             "body": "WPS=工艺评定（焊接方法），焊工=考试（人）。Table 6.10 是焊工位置评定表。",
             "explain": "工艺术语与人员术语不能混：WPS 评定的是焊接工艺，焊工考试评定的是人的资格。",
             "keyword": "术语边界"},
        ],
        "cta_keyword": "关注 + 收藏",
        "cta_sub": "标准讲解持续更新",
        "orientation": orientation,
    }


# Windows 文件名非法字符。除此之外的一切（含中文、空格、点、连字符）全部保留。
_ILLEGAL = r'\/:*?"<>|'


def safe_filename(title: str, limit: int = 48) -> str:
    """标题 → 合法文件名，**标准编号必须原样保留**。

    红线：标准编号不是普通字符串。"AWS D1.1" 被洗成 "AWSD11" 是硬伤——
    空格和点承载语义（AWS 是协会、D1.1 是标准号），吃掉就无法辨认。
    所以这里**只过滤文件系统真正非法的字符**，绝不用 isalnum() 白名单。

    AWS D1.1 焊接位置评定  -> AWS D1.1 焊接位置评定      (空格和点都在)
    ASME B31.3 焊接缺陷    -> ASME B31.3 焊接缺陷
    ISO 9606-1:2013        -> ISO 9606-1-2013            (仅冒号被替换,合法化)
    """
    s = str(title)
    for sep in (":", "/", "\\"):   # 年版符/GB 分隔符：转连字符，删掉会黏成 9606-12013、GBT
        s = s.replace(sep, "-")
    s = re.sub(r"[-]{2,}", "-", s)  # GB//T 之类不会崩
    s = "".join("" if c in _ILLEGAL or ord(c) < 32 else c for c in s)
    s = re.sub(r"\s+", " ", s).strip(" .")   # 压缩空白；去首尾空格与点（尾点会让 Windows 误判无扩展名）
    return (s[:limit] or "video").strip(" .") or "video"


def run(brief: dict) -> int:
    orientation = (brief.get("orientation") or "portrait").lower()
    aspect = "9:16" if orientation == "portrait" else "16:9"
    title = brief.get("title", "untitled")
    safe = safe_filename(title)
    out_path = os.path.join(OUT_DIR, f"{safe}_{orientation}.mp4")

    print("=" * 64)
    print(f"  固定工作流 · 新任务：{title}")
    print(f"  方向={orientation} ({aspect})  输出={out_path}")
    print("=" * 64)

    # ---- ①~④ 审题/定方向/排版/定形式 + ⑤质检（engine.render 内部串起）----
    print("[①~④] 审题→定方向→排版→定形式（含 validator 三道闸 + 话画一致性闸）...")
    try:
        res = ENG.render(brief, out_path, orientation=orientation, strict=True)
    except Exception as e:
        print("\n❌ 渲染期被红线闸门拦截（⑤质检未过）：")
        print("  " + str(e).replace("\n", "\n  "))
        traceback.print_exc() if os.environ.get("WF_DEBUG") else None
        return 2

    dur = res.get("duration") or 0.0
    print(f"  ✓ 六步渲染完成：{res['n_frames']} 帧 / {dur:.2f}s")
    print(f"  ✓ 场景质检：{'全部 PASS' if res['qc_passed'] else '存在 FAIL'}")
    print(f"  ✓ QC 报告：{res['qc_report_path']}")

    # ---- ⑥ 出片验收：强制 check.py A0–A8 ----
    # expect 用「音频总时长」（成片真实时长由 -shortest 决定 = Σ配音），
    # 不用帧数估算值（那是未截断的上界，会虚高 0.5s）。
    expect_dur = res.get("audio_duration") or dur
    print(f"\n[⑥] 出片验收：跑 check.py 硬闸门 A0–A8（期望时长={expect_dur:.2f}s = Σ配音）...")
    chk = CHK.check(out_path, expect=round(expect_dur, 2), aspect=aspect)
    failed = chk.failed
    for it in chk.items:
        mark = "PASS" if it["pass"] else ("FAIL" if it["fatal"] else "WARN")
        print(f"  [{mark}] {it['code']:<5} {it['name']}")
    if failed:
        print(f"\n❌ 出片验收未过：{', '.join(i['code'] for i in failed)} —— 不出片")
        print("  对照 1_避坑总纲_血泪清单.md 查根因后重跑。")
        return 1

    print("\n✅ 固定工作流全部六步 PASS，可交付：")
    print(f"  成片：{out_path}")
    print(f"  质检：{res['qc_report_path']}")
    print(f"  时长：{dur:.2f}s / 方向：{aspect}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="固定工作流统一入口（六步法+红线闸门）")
    ap.add_argument("--brief", help="结构化 Brief JSON 路径")
    ap.add_argument("--demo", action="store_true", help="跑内置样例")
    ap.add_argument("--orientation", default="portrait", choices=["portrait", "landscape"])
    ap.add_argument("--title", help="快捷模式：直接给标题")
    ap.add_argument("--points", help="快捷模式：分号分隔的要点文本")
    ap.add_argument("--template", default="student_lecture")
    ap.add_argument("--style", default="mechanical")
    a = ap.parse_args()

    os.makedirs(OUT_DIR, exist_ok=True)

    if a.demo:
        rc = 0
        for ori in ("portrait", "landscape"):
            print("\n" + "#" * 64)
            print(f"#  DEMO · {ori}")
            print("#" * 64)
            rc = run(_demo_brief(ori)) or rc
        return rc

    if a.brief:
        with open(a.brief, encoding="utf-8") as f:
            brief = json.load(f)
        return run(brief)

    if a.title:
        pts = [{"type": "text", "title": p[:24], "body": p, "explain": p}
               for p in a.points.split(";") if p.strip()] if a.points else \
              [{"type": "text", "title": a.title, "body": a.title, "explain": a.title}]
        brief = {"title": a.title, "template": a.template, "style": a.style,
                 "points": pts, "orientation": a.orientation}
        return run(brief)

    print("用法：python workflow.py --demo  | --brief x.json | --title '...' --points 'a;b;c'")
    return 3


if __name__ == "__main__":
    sys.exit(main())
