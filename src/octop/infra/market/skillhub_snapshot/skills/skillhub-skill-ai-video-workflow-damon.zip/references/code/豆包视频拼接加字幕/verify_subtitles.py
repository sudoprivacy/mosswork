#!/usr/bin/env python3
"""Verify that subtitles in a video appear/disappear at expected times.

Usage:
  python verify_subtitles.py --video out.mp4 --times 1.0 3.0 6.1 7.0 11.0 \
      --expect present absent present present present

--times: list of seconds to sample
--expect: for each time, either 'present' or 'absent'
--bar-top: top of the subtitle black bar in pixels (default 504)
--bar-height: height of the black bar (default 216)
--threshold: minimum white pixels to count as "present" (default 500)
"""

import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image
import numpy as np


def extract_frame(video, t, out_path, ffmpeg):
    cmd = [str(ffmpeg), "-y", "-ss", str(t), "-i", str(video), "-frames:v", "1", str(out_path)]
    subprocess.run(cmd, capture_output=True)


def count_subtitle_pixels(frame_path, bar_top, bar_height):
    im = Image.open(str(frame_path))
    a = np.asarray(im.convert("RGB")).astype(int)
    r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    band = a[bar_top:bar_top + bar_height, :, :]
    white = (band[:, :, 0] > 200) & (band[:, :, 1] > 200) & (band[:, :, 2] > 200)
    return int(white.sum())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True)
    parser.add_argument("--times", nargs="+", type=float, required=True)
    parser.add_argument("--expect", nargs="+", choices=["present", "absent"], required=True)
    parser.add_argument("--ffmpeg", default=str(Path.home() / ".workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"))
    parser.add_argument("--bar-top", type=int, default=504)
    parser.add_argument("--bar-height", type=int, default=216)
    parser.add_argument("--threshold", type=int, default=500)
    args = parser.parse_args()

    if len(args.times) != len(args.expect):
        print("--times and --expect must have the same length", file=sys.stderr)
        sys.exit(1)

    all_ok = True
    with tempfile.TemporaryDirectory() as tmp:
        for t, exp in zip(args.times, args.expect):
            frame = Path(tmp) / f"frame_{t:.2f}.png"
            extract_frame(args.video, t, frame, args.ffmpeg)
            if not frame.exists():
                print(f"t={t:.2f}: failed to extract frame")
                all_ok = False
                continue
            count = count_subtitle_pixels(frame, args.bar_top, args.bar_height)
            is_present = count > args.threshold
            status = "OK" if (is_present == (exp == "present")) else "FAIL"
            if status == "FAIL":
                all_ok = False
            print(f"t={t:5.2f}: pixels={count:6}  expected={exp:7}  -> {status}")

    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
