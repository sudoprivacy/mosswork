#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把 `D:/微信小程序/情景文章库/{profession}/{profession}-NN.json` 的情景文章
转换成 ship-video-pipeline 的 scenes.json。

文章是「英文对话 + 中文对话」逐行对应格式（A/B/C 角色），本脚本：
  - 解析 EN/ZH 每句台词与角色标签
  - 逐句生成一个 scene（对话片：speaker + narration_en/zh + 角色标签）
  - 图片在 images/ 目录按文件名排序后循环分配
  - 关键词 = 文章 keyTerms + 一组核心中英专业词，用于字幕高亮（放大+变色）

用法:
  python pipeline/article_to_scenes.py \
      --article "D:/微信小程序/情景文章库/welding/welding-01.json" \
      --project welding_01 --lang en --mode dialogue \
      --images-dir "D:/.../projects/welding_01/images" \
      --out "D:/.../projects/welding_01/scenes.json"
"""
import json
import re
import os
import argparse


def parse_dialogue(text):
    """解析 'A (Role): text' / 'A（角色）：text' / 'A: text' 行 -> [{letter,role,text}]"""
    out = []
    for raw in text.split('\n'):
        line = raw.strip()
        if not line:
            continue
        # 带角色: A (Role): ... 或 A（角色）：...
        m = re.match(r'^\s*([A-Ca-c])\s*[\(（]([^\)）]*)[\)）]\s*[:：]\s*(.*)$', line)
        if m:
            letter, role, txt = m.group(1).upper(), m.group(2).strip(), m.group(3).strip()
        else:
            # 仅字母+冒号: A: ...
            m2 = re.match(r'^\s*([A-Ca-c])\s*[:：]\s*(.*)$', line)
            if m2:
                letter, role, txt = m2.group(1).upper(), None, m2.group(2).strip()
            else:
                # 非对话行（如空/说明），跳过
                continue
        out.append({'letter': letter, 'role': role, 'text': txt})
    return out


# 核心中英专业词（用于字幕高亮；渲染器只高亮正文中实际出现的子串）
CORE_KW_EN = ["WPS", "bevel", "root face", "root opening", "misalignment",
              "tack", "tacks", "RFI", "single-V", "feeler", "feelers"]
CORE_KW_ZH = ["坡口", "钝边", "根部间隙", "错边", "定位焊", "打底焊",
              "报检", "组对", "焊接工艺规程", "停止点"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--article', required=True, help='情景文章库 JSON 路径')
    ap.add_argument('--project', required=True, help='工程名(用于默认路径)')
    ap.add_argument('--lang', default='en', choices=['en', 'zh'])
    ap.add_argument('--mode', default='dialogue', choices=['dialogue', 'narration'])
    ap.add_argument('--images-dir', default=None, help='图片目录(默认 projects/<project>/images)')
    ap.add_argument('--out', default=None, help='输出 scenes.json(默认 projects/<project>/scenes.json)')
    ap.add_argument('--title-en', default=None, help='英文标题(标题卡用); 缺省回退到中文标题')
    args = ap.parse_args()

    art = json.load(open(args.article, encoding='utf-8'))
    en = parse_dialogue(art.get('englishContent', ''))
    zh = parse_dialogue(art.get('chineseContent', art.get('content', '')))
    n = min(len(en), len(zh))

    role_en, role_zh = {}, {}
    for p in en:
        if p['role']:
            role_en[p['letter']] = p['role']
    for p in zh:
        if p['role']:
            role_zh[p['letter']] = p['role']

    img_dir = args.images_dir or os.path.join('projects', args.project, 'images')
    if os.path.isdir(img_dir):
        imgs = sorted([f for f in os.listdir(img_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
    else:
        imgs = []
    if not imgs:
        imgs = ['scene_01.png']  # 兜底，避免缺图报错

    kws = list(art.get('keyTerms', [])) + CORE_KW_EN + CORE_KW_ZH
    seen, kw_uniq = set(), []
    for k in kws:
        if k and k not in seen:
            seen.add(k)
            kw_uniq.append(k)

    scenes = []
    for i in range(n):
        e, z = en[i], zh[i]
        letter = e['letter']
        scenes.append({
            'idx': i,
            'speaker': letter,
            'speaker_en': role_en.get(letter, 'Speaker ' + letter),
            'speaker_zh': role_zh.get(letter, '角色' + letter),
            'narration_en': e['text'],
            'narration_zh': z['text'],
            'image_file': imgs[i % len(imgs)],
            'keywords': kw_uniq,
        })

    meta = {
        'mode': args.mode,
        'lang': args.lang,
        'title': art.get('title', ''),
        'title_zh': art.get('title', ''),
        'title_en': args.title_en or art.get('title', ''),
        'professionId': art.get('professionId', ''),
        'professionName': art.get('professionName', ''),
    }
    out = args.out or os.path.join('projects', args.project, 'scenes.json')
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    json.dump({'meta': meta, 'scenes': scenes},
              open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('wrote %s  scenes=%d  imgs=%s' % (out, n, imgs))


if __name__ == '__main__':
    main()
