# app_demo · 3D 卡片开场 + App 聊天录屏

> 子产品定位：补齐我们 PIL 2D 框架做不了的两类「动态镜头」——
> **① 3D 卡片雨开场**（真透视 `perspective`+`rotateY` 飞入）
> **② WorkBuddy App 聊天录屏段**（界面滚动 + 输入框打字 + AI 回复逐字出现）
> 产出竖屏 9:16 的 mp4，可直接喂给 `豆包视频拼接加字幕` 拼进主成片。

---

## 一、实现路线（零付费）

- **主路线：HTML + CSS 3D + Playwright 录制**
  - 用浏览器 GPU 合成真 3D 变换，比 PIL 伪 3D 真实得多；文案/截图全参数化，改一次重渲。
  - 依赖：本地 Node + `playwright` + 已下载的 chromium（一次性免费安装，非云 API）。
- **降级路线（若本机无 chromium / 启动失败）：PIL 2D 伪 3D**
  - `render_fallback.py` 逐帧画圆角卡缩放+偏移模拟透视，纯 Python 零依赖。

---

## 二、怎么用

```bash
cd app_demo
# 1) 录制并直接转 mp4（推荐）
node render.js --mp4
#   产出 output/app_demo.mp4（约 15s，1080×1920）

# 2) 只录 webm（不转码）
node render.js
#   产出 output/<guid>.webm
```

> 若 `require('playwright')` 解析不到，用绝对路径版：render.js 已写死
> `D:/Workbuddy缓存位置/.workbuddy/binaries/node/workspace/node_modules/playwright`。

参数都在 `index.html` 里：
- 卡片标签数组 `labels`（开场 12 张卡）。
- 聊天内容：`提取这条视频的文案` / AI 回复文本 / 10 个标题数组。
- 时间轴：`introOut` 4.2s 淡出、`chatIn` 5s 淡入、`setTimeout(6200)` 启动打字。

改文案只需编辑 `index.html` 里的字符串，重跑 `node render.js --mp4`。

---

## 三、接入固定工作流

本子产品只负责「产出两个动态镜头片段」，不重复造排版/质检：
1. 用 `app_demo` 产出 `开场.mp4` + `聊天段.mp4`；
2. 把这两段 + 中间静态讲解帧，交给 `豆包视频拼接加字幕` 做横/竖屏拼接；
3. 最后过 `check.py` 红线闸门（A0–A8）。

红线提醒：App 界面属「第三方产品包装」，须遵守平台规范；本 demo 用自绘 UI，不涉及真实账号数据。

---

## 四、文件清单

- `index.html`：3D 开场 + 聊天 UI 的单页（自包含，无外链）。
- `render.js`：Playwright 录制脚本（viewport 1080×1920，录 15s，可选 `--mp4`）。
- `package.json`：声明 playwright 依赖。
- `output/`：录制产物（webm / mp4）。
