#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""检测 hvac_07 源视频真实说话段，输出用于字幕对齐的证据。"""
import wave, struct, json

WAV = "D:/微信小程序/情景视频存放处/豆包视频加字幕工作流/hvac_07_audio.wav"

def read_wav(path):
    w = wave.open(path, 'rb')
    n = w.getnframes()
    fr = w.getframerate()
    raw = w.readframes(n)
    samples = struct.unpack('<' + 'h' * n, raw)
    return samples, fr

def main():
    samples, fr = read_wav(WAV)
    # 每 20ms 一帧算 RMS 能量
    win = int(fr * 0.02)
    n = len(samples)
    frames = []
    for i in range(0, n, win):
        seg = samples[i:i + win]
        if not seg:
            continue
        rms = (sum(x * x for x in seg) / len(seg)) ** 0.5
        frames.append(rms)
    # 能量阈值：取中位数的倍数
    srt = sorted(frames)
    med = srt[len(srt) // 2] if srt else 0
    th = max(med * 2.0, 200)
    # 标记说话帧
    speech = [1 if f > th else 0 for f in frames]
    # 合并：说话段之间静音 < 1.0s 视为同一句
    min_sil_ms = 1000
    min_sil_frames = int(min_sil_ms / 20)
    regions = []
    i = 0
    L = len(speech)
    while i < L:
        if speech[i]:
            j = i
            while j < L:
                if speech[j]:
                    j += 1
                else:
                    # 看后面静音有多长
                    k = j
                    while k < L and not speech[k]:
                        k += 1
                    gap = k - j
                    if gap <= min_sil_frames:
                        j = k  # 静音短，继续算说话
                    else:
                        break
            start_t = i * 0.02
            end_t = j * 0.02
            regions.append((round(start_t, 2), round(end_t, 2)))
            i = j
        else:
            i += 1
    # 过滤极短(<0.25s)伪段
    regions = [r for r in regions if r[1] - r[0] >= 0.25]
    print("说话段数量:", len(regions))
    print("总说话时长: %.2fs / 65s" % sum(e - s for s, e in regions))
    for idx, (s, e) in enumerate(regions, 1):
        print("%2d: %6.2f - %6.2f  (%.2fs)" % (idx, s, e, e - s))
    with open("hvac_07_regions.json", "w", encoding="utf-8") as f:
        json.dump(regions, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    main()
