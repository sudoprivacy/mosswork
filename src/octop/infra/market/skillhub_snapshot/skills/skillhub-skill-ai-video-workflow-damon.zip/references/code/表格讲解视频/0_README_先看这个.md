# 表格讲解视频 — 先看这个

> ⚠️ **动手前先看**：[避坑总纲](../1_避坑总纲_血泪清单.md)（历史翻车 + 硬闸门）
> ✅ **交付前必跑**：`python ../check.py <成片.mp4>` ｜ 勾选表：[交付前自检清单](../2_交付前自检清单.md)

> 把标准/规范里的**表格**（如 AWS D1.1 Table 6.10 焊工焊接位置评定）讲成横屏逐行高亮讲解视频。
> 0 积分、纯本地 CPU。

## 一句话用法

> ⚠️ **本子目录只有说明文档，代码在伞目录根 `render/`**.
> 请在 **伞目录根**（`D:\Workbuddy缓存位置\标准讲解视频工作流\`）执行下面命令：

```bash
# 英文双语版（推荐定稿）
python render/render_table_walkthrough_l_pos_en.py

# 中文版（冻结）
python render/render_table_walkthrough_l_pos.py

# 加速渲染器（直接输出到标准视频库）
python render/render_fast.py
```

成片默认输出到 `D:\微信小程序\标准视频库\`（`render_fast.py` 常量 `FINAL_OUTPUT_DIR` 决定）。

## 工作区结构

```
标准讲解视频工作流/         ← 这就是当前伞目录本身,Table 6.10 是其原主战场
├── render/
│   ├── render_table_walkthrough_l_pos_en.py   # 英文双语定稿入口
│   ├── render_table_walkthrough_l_pos.py      # 中文版（冻结）
│   ├── render_table_walkthrough_l.py          # 早期基版（勿改）
│   ├── render_fast.py                          # 加速渲染器
│   └── plan_change.py                          # 计划变更
├── source/
│   ├── table610/
│   │   ├── table6_10_p183_base.png    # 整表截图
│   │   ├── table6_10_p183.json        # 元数据
│   │   └── positions/{1G,1F,2F,...4F}.png
├── docs/
│   └── TABLE6_10_生产交接与红线.md    # 操作级权威
├── output/                    # 中间产物/缓存,不作交付
└── audio_cache_en/            # TTS 缓存,按场景序号命名
```

## 核心特性

- **横版 16:9**（1920×1080）
- **卡片竖向排版**：标题/标签/金色评定条/正文/代码/字幕 严格不重叠
- **字幕不加框**：英上中下双语
- **TTS**：`rate="+30%"`、读法固定（"表 6.10"→"六点一零"、"AWS D1.1 2020" 中 1 与 2020 不换气）
- **冻结红线**：动坐标前必查 4 处铁律（标签↔金条、金条↔正文、代码↔小字、末行↔底圆角）

## 已知坑

- **TTS 缓存按场景序号命名**，改 `spoken` 文案后必清 `audio_cache_en/*.mp3`
- **ffmpeg concat 中文路径** — 脚本已用 ASCII 临时目录处理
- **渲染约 11 分钟** 属正常,不是卡死

## 客户交付检查

- [ ] 用 `render_table_walkthrough_l_pos_en.py` 跑
- [ ] 表格高亮严格在表内（无扫描线/无伪影/不截断脚注）
- [ ] 字幕 EN 上 CN 下,无边框
- [ ] 坐标未越界
