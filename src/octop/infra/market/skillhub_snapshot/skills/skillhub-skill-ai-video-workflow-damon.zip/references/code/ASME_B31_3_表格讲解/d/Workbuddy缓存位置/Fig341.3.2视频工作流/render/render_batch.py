# -*- coding: utf-8 -*-
"""Render a range of scenes as independent segments to avoid one long run."""
import os, sys, argparse, subprocess, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import render_asme_b31_3_table341_3_2 as R

FPS = R.FPS

def encode_segment(scene_dir, mp3, dur, out_path):
    n = len([f for f in os.listdir(scene_dir) if f.startswith("frame_")])
    cmd = [
        R.FFMPEG, "-y",
        "-framerate", str(FPS),
        "-i", os.path.join(scene_dir, "frame_%06d.png"),
        "-i", mp3,
        "-frames:v", str(n),
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
        "-c:a", "aac", "-b:a", "128k",
        "-shortest", out_path
    ]
    subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8", errors="ignore")

def render_scene(i, sc, dur, mp3, seg_path):
    scene_dir = os.path.join(R.FRAMES_DIR, f"scene_{i:02d}_batch")
    if os.path.exists(scene_dir):
        old = scene_dir + f"_old_{os.getpid()}"
        if os.path.exists(old):
            os.rename(old, old + "_x")
        os.rename(scene_dir, old)
    os.makedirs(scene_dir, exist_ok=True)
    n = int(dur * FPS) + 1
    row = sc if sc.get("key") else None
    card_in = 0.35
    card_out = 0.45
    print(f"  rendering scene {i}: {dur:.2f}s ({n} frames)")
    for f in range(n):
        t = f / FPS
        slide = 0.0
        if row:
            if t < card_in:
                slide = t / card_in
            elif t > dur - card_out:
                slide = max(0.0, (dur - t) / card_out)
            else:
                slide = 1.0
        im = R.Image.new("RGBA", (R.W, R.H), R.BG + (255,))
        d = R.ImageDraw.Draw(im)
        im.paste(R._BG, (0, 0))
        if i == 0:
            R.draw_intro(im, d, t)
        elif i == len(R.SCENES) - 1:
            R.draw_top(d, sc)
            R.draw_table(im, d, sc.get("key"), t)
            R.draw_summary_burst(im, d, t)
        else:
            R.draw_top(d, sc)
            R.draw_table(im, d, sc.get("key"), t)
            if row:
                R.draw_card(im, row, slide, t)
                R.draw_defect_summary(im, d, row, t)
        R.draw_subtitle(d, sc.get("caption_en", ""), sc["caption"])
        out_path = os.path.join(scene_dir, f"frame_{f:06d}.png")
        im.convert("RGB").save(out_path)
    print(f"  encoding scene {i}")
    encode_segment(scene_dir, mp3, dur, seg_path)
    # keep scene frames for now; bulk delete triggers safe-delete hook

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=int, default=0)
    ap.add_argument("--end", type=int, default=len(R.SCENES) - 1)
    args = ap.parse_args()
    R.load_assets()
    R.build_bg()
    durations = []
    audio_paths = []
    for i, sc in enumerate(R.SCENES):
        mp3 = R.get_audio(i, sc["spoken"])
        dur = R.audio_duration(mp3) + 0.6
        durations.append(dur)
        audio_paths.append(mp3)
        print(f"scene {i}: {dur:.2f}s")
    for i in range(args.start, min(args.end + 1, len(R.SCENES))):
        seg_path = os.path.join(R.FRAMES_DIR, f"seg_{i:02d}.mp4")
        render_scene(i, R.SCENES[i], durations[i], audio_paths[i], seg_path)
        print(f"  seg {i} done -> {seg_path}")

if __name__ == "__main__":
    main()
