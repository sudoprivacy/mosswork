# -*- coding: utf-8 -*-
# 竖屏爆感宣传视频 v2 —— 5 张静态关键帧预览（封面/数据/转折/证书/六宫格）。
# 修正：① 焦虑对象改为未考证人群；② 移除"奥地利"文案，统一用 TÜV；
# ③ 配色改为参考2深蓝+青+白，去掉大红；④ 去除发糊 glow，改用清晰投影；
# ⑤ 证书页使用 PDF 原证书模板完整展示；⑥ 新增招聘数据焦虑帧；
# ⑦ 增加文字出画自动校验，禁止任何文本溢出安全区。
import os
import sys
from PIL import Image, ImageDraw, ImageFont, ImageEnhance

W, H = 1080, 1920
SAFE_L = 40          # 左安全边距
SAFE_R = W - 40      # 右安全边距
SAFE_W = SAFE_R - SAFE_L
# 渲染前预检：文字元素登记器（文本出画由 crisp_text 拦，文本互相重叠由本器拦）
COLLECTOR = None


class Collector:
    """记录一帧内所有文字包围盒，用于渲染前重叠检测。rect 背景不计入。"""
    def __init__(self):
        self.items = []  # (box[x0,y0,x1,y1], label)

    def add(self, box, label):
        self.items.append((box, label))

    def overlaps(self, tol=4):
        bad = []
        n = len(self.items)
        for i in range(n):
            b1, l1 = self.items[i]
            for j in range(i + 1, n):
                b2, l2 = self.items[j]
                ix = min(b1[2], b2[2]) - max(b1[0], b2[0])
                iy = min(b1[3], b2[3]) - max(b1[1], b2[1])
                if ix > tol and iy > tol:
                    bad.append((l1, l2, int(ix), int(iy)))
        return bad


ROOT = r"D:\Workbuddy缓存位置\培训宣传视频工作流"
RENDER = os.path.join(ROOT, "render")
OUT = os.path.join(RENDER, "preview_frames")
os.makedirs(OUT, exist_ok=True)
BG = r"D:\微信小程序\船海风云\人物角色示例图\焊接现场PPE检查Q版情景视频提示词.png"
CERT_PATH = os.path.join(ROOT, "assets", "cert_template.png")


def F(p, s):
    return ImageFont.truetype(p, s)


FONTS = {
    "cn_b96": F(r"C:\Windows\Fonts\msyhbd.ttc", 96),
    "cn_b80": F(r"C:\Windows\Fonts\msyhbd.ttc", 80),
    "cn_b72": F(r"C:\Windows\Fonts\msyhbd.ttc", 72),
    "cn_b64": F(r"C:\Windows\Fonts\msyhbd.ttc", 64),
    "cn_b56": F(r"C:\Windows\Fonts\msyhbd.ttc", 56),
    "cn_b48": F(r"C:\Windows\Fonts\msyhbd.ttc", 48),
    "cn_b44": F(r"C:\Windows\Fonts\msyhbd.ttc", 44),
    "cn_b40": F(r"C:\Windows\Fonts\msyhbd.ttc", 40),
    "cn_b36": F(r"C:\Windows\Fonts\msyhbd.ttc", 36),
    "cn_b32": F(r"C:\Windows\Fonts\msyhbd.ttc", 32),
    "cn36":   F(r"C:\Windows\Fonts\msyh.ttc", 36),
    "cn32":   F(r"C:\Windows\Fonts\msyh.ttc", 32),
    "cn28":   F(r"C:\Windows\Fonts\msyh.ttc", 28),
    "cn24":   F(r"C:\Windows\Fonts\msyh.ttc", 24),
    "en56":   F(r"C:\Windows\Fonts\arialbd.ttf", 56),
    "en48":   F(r"C:\Windows\Fonts\arialbd.ttf", 48),
    "en40":   F(r"C:\Windows\Fonts\arialbd.ttf", 40),
    "en32":   F(r"C:\Windows\Fonts\arialbd.ttf", 32),
    "en28":   F(r"C:\Windows\Fonts\arialbd.ttf", 28),
    "en24":   F(r"C:\Windows\Fonts\arialbd.ttf", 24),
    "en20":   F(r"C:\Windows\Fonts\arial.ttf", 20),
    "badge18":F(r"C:\Windows\Fonts\msyhbd.ttc", 18),
    "badge16":F(r"C:\Windows\Fonts\msyh.ttc", 16),
}

# 参考2风格配色：深蓝底 + 青 + 白 + 灰，红色仅作极小面积点缀
DARK    = (8, 12, 24)
DARK2   = (12, 18, 36)
CYAN    = (34, 211, 238)
WHITE   = (248, 250, 252)
GRAY    = (148, 163, 184)
RED_ACC = (244, 63, 94)
GOLD    = (250, 204, 21)
PANEL   = (15, 23, 42, 210)
SHADOW  = (0, 0, 0, 180)


def build_bg():
    bg = Image.open(BG).convert("RGB")
    sw, sh = bg.size
    scale = max(W / sw, H / sh)
    bg = bg.resize((int(sw * scale), int(sh * scale)), Image.LANCZOS)
    lw, lh = bg.size
    bg = bg.crop(((lw - W) // 2, (lh - H) // 2, (lw - W) // 2 + W, (lh - H) // 2 + H))
    # 背景可见度（已与用户确认，2026-08-23 起固定）：亮度/饱和度调高，深蓝蒙版降到 45%，
    # 渐变只压底部 38% 区域以保证白字可读，不再全屏压黑。
    bg = ImageEnhance.Brightness(bg).enhance(0.55)
    bg = ImageEnhance.Color(bg).enhance(0.72)
    bg = ImageEnhance.Contrast(bg).enhance(1.22)
    overlay = Image.new("RGB", (W, H), DARK)
    bg = Image.blend(bg, overlay, 0.45)
    grad = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grad)
    for i in range(H):
        alpha = int(80 * (i - H * 0.62) / (H * 0.38)) if i > H * 0.62 else 0
        gd.line([(0, i), (W, i)], fill=(0, 0, 0, max(0, min(alpha, 255))))
    bg = Image.alpha_composite(bg.convert("RGBA"), grad).convert("RGB")
    return bg


def rr(d, box, r, fill=None, outline=None, width=2):
    d.rounded_rectangle(box, radius=r, fill=fill, outline=outline, width=width)


def text_size(font, text):
    """返回 (宽, 高)，不含描边/投影余量"""
    bbox = font.getbbox(text)
    return bbox[2] - bbox[0], bbox[3] - bbox[1]


def text_box(pos, text, font, anchor):
    """返回文字绝对包围盒 [x0, y0, x1, y1]（含字体度量，用于重叠/出画检测）。"""
    x, y = pos
    tw, th = text_size(font, text)
    if anchor == "mm":
        return [x - tw // 2, y - th // 2, x + tw // 2, y + th // 2]
    if anchor in ("lt", "lm"):
        return [x, y - th // 2, x + tw, y + th // 2]
    if anchor in ("rt", "rm"):
        return [x - tw, y - th // 2, x, y + th // 2]
    return [x - tw // 2, y - th // 2, x + tw // 2, y + th // 2]


def crisp_text(d, pos, text, font, fill, shadow=SHADOW, anchor="mm", max_w=None, strict=True, record=True):
    """清晰投影字，自动校验不溢出安全区，并登记包围盒供重叠检测。"""
    x, y = pos
    tw, th = text_size(font, text)
    box = text_box(pos, text, font, anchor)
    if anchor == "mm":
        if max_w is not None:
            limit_l, limit_r = x - max_w // 2, x + max_w // 2
        else:
            limit_l, limit_r = SAFE_L, SAFE_R
    elif anchor in ("lt", "lm"):
        if max_w is not None:
            limit_l, limit_r = x, x + max_w
        else:
            limit_l, limit_r = SAFE_L, SAFE_R
    elif anchor in ("rt", "rm"):
        if max_w is not None:
            limit_l, limit_r = x - max_w, x
        else:
            limit_l, limit_r = SAFE_L, SAFE_R
    else:
        limit_l, limit_r = SAFE_L, SAFE_R

    if strict and (box[0] < limit_l or box[2] > limit_r):
        raise ValueError(
            f"文字溢出: '{text}' 宽{tw}px 在 x={x} anchor={anchor}，"
            f"实际 [{box[0]}, {box[2]}] 超出安全区 [{limit_l}, {limit_r}]"
        )

    d.text((x + 2, y + 2), text, font=font, fill=shadow, anchor=anchor)
    d.text((x + 1, y + 1), text, font=font, fill=shadow, anchor=anchor)
    d.text(pos, text, font=font, fill=fill, anchor=anchor)
    if record and COLLECTOR is not None:
        COLLECTOR.add(box, text)
    return tw, th


def draw_lines(d, cx, cy, lines, font, fill, line_gap=16, shadow=SHADOW):
    total_h = len(lines) * font.size + (len(lines) - 1) * line_gap
    y_start = cy - total_h // 2 + font.size // 2
    for i, line in enumerate(lines):
        y = y_start + i * (font.size + line_gap)
        crisp_text(d, (cx, y), line, font, fill, shadow=shadow)


SAFE_T = 190  # 顶部系统状态栏+微信频道导航栏安全区
SAFE_B = 1620  # 底部操作栏安全区，字幕不超出


def draw_badges(d):
    # 左角标：TÜV（下移到安全区下方，避免被系统状态栏/导航栏遮挡）
    lw, lh = 280, 72
    lx, ly = SAFE_L, SAFE_T
    rr(d, [lx, ly, lx + lw, ly + lh], 12, fill=(*DARK2, 230), outline=CYAN, width=2)
    d.rounded_rectangle([lx + 10, ly + 12, lx + 66, ly + 60], radius=8,
                        fill=(20, 30, 60, 240), outline=GOLD, width=2)
    crisp_text(d, (lx + 38, ly + 36), "TÜV", font=FONTS["badge18"], fill=WHITE, anchor="mm")
    crisp_text(d, (lx + 78, ly + 24), "AUTHORIZED", font=FONTS["en24"], fill=WHITE, anchor="lt")
    crisp_text(d, (lx + 78, ly + 50), "NDT TRAINING", font=FONTS["en20"], fill=GRAY, anchor="lt")
    # 右角标
    rw, rh = 300, 72
    rx, ry = W - SAFE_L - rw, SAFE_T
    rr(d, [rx, ry, rx + rw, ry + rh], 12, fill=(*DARK2, 230), outline=CYAN, width=2)
    crisp_text(d, (rx + rw // 2, ry + 24), "ISO 9712 · EN", font=FONTS["en28"], fill=CYAN, anchor="mm")
    crisp_text(d, (rx + rw // 2, ry + 52), "PED · IAF / ilac", font=FONTS["badge16"], fill=GRAY, anchor="mm")


def subtitle_bar(d, text):
    crisp_text(d, (W // 2, SAFE_B), text, FONTS["cn32"], WHITE, max_w=SAFE_W)


def frame_cover():
    im = build_bg().convert("RGBA")
    d = ImageDraw.Draw(im)
    draw_badges(d)
    # 内容整体下移居中，填满可用区域，不再上半屏堆叠
    crisp_text(d, (W // 2, 300), "两个月真实招聘数据", FONTS["cn28"], GRAY)
    draw_lines(d, W // 2, 620,
               ["你的简历", "还在为没有 NDT 证书", "被卡住？"],
               FONTS["cn_b72"], CYAN, line_gap=18)
    crisp_text(d, (W // 2, 920), "NDT 已从加分项，变成硬门槛",
               FONTS["cn36"], GRAY)
    d.line([(W // 2 - 180, 990), (W // 2 + 180, 990)], fill=RED_ACC, width=3)
    crisp_text(d, (W // 2, 1040), "无证 = 硬门槛", FONTS["cn_b36"], RED_ACC)
    crisp_text(d, (W // 2, 1200), "项目卡壳 · 求职被刷 · 出海没门",
               FONTS["cn32"], WHITE)
    subtitle_bar(d, "没有这张证，门槛都摸不到")
    return im


def frame_turn():
    im = build_bg().convert("RGBA")
    d = ImageDraw.Draw(im)
    draw_badges(d)
    # 光晕与文字整体下移居中
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W // 2 - 340, 560, W // 2 + 340, 1240], fill=(34, 211, 238, 18))
    im = Image.alpha_composite(im, glow)
    d = ImageDraw.Draw(im)
    crisp_text(d, (W // 2, 700), "救星来了！", FONTS["cn_b56"], CYAN)
    draw_lines(d, W // 2, 880,
               ["TÜV NDT", "认证培训"],
               FONTS["cn_b72"], WHITE, line_gap=16)
    d.line([(W // 2 - 260, 1040), (W // 2 + 260, 1040)], fill=CYAN, width=3)
    crisp_text(d, (W // 2, 1110), "权威资质 · 系统课程 · 直通考核", FONTS["cn36"], GRAY)
    subtitle_bar(d, "救星来了：TÜV NDT 认证培训")
    return im


def frame_cert():
    im = build_bg().convert("RGBA")
    d = ImageDraw.Draw(im)
    draw_badges(d)
    # 标题/标签下移，证书居中
    crisp_text(d, (W // 2, 300), "全球互认的硬通货", FONTS["cn_b56"], WHITE)
    tags = [("TÜV 授权", CYAN), ("EN ISO 9712", WHITE), ("PED / SNT-TC-1A", GOLD)]
    total_w = sum([FONTS["cn28"].getlength(t[0]) + 40 for t in tags]) + 40
    x = (W - total_w) // 2
    y = 365
    for txt, col in tags:
        tw = FONTS["cn28"].getlength(txt) + 40
        rr(d, [x, y, x + tw, y + 56], 28, fill=(*DARK2, 200), outline=col, width=2)
        crisp_text(d, (x + tw // 2, y + 28), txt, FONTS["cn28"], col)
        x += tw + 20
    # 完整证书模板
    cert = Image.open(CERT_PATH).convert("RGBA")
    cw, ch = cert.size
    cert = cert.crop((40, 220, cw - 40, ch - 150))
    cw, ch = cert.size
    target_w = 960
    scale = target_w / cw
    cert = cert.resize((target_w, int(ch * scale)), Image.LANCZOS)
    cx = (W - cert.width) // 2
    cy = 960
    im.paste(cert, (cx, cy - cert.height // 2), cert)
    # 红色样张印章
    sd = ImageDraw.Draw(im)
    sx1, sx2 = W - 300, W - 80
    rr(sd, [sx1, cy + cert.height // 2 - 90, sx2, cy + cert.height // 2 - 20],
       8, fill=(244, 63, 94, 200), outline=WHITE, width=2)
    crisp_text(sd, ((sx1 + sx2) // 2, cy + cert.height // 2 - 55), "样张 SAMPLE",
               FONTS["cn_b32"], WHITE)
    subtitle_bar(d, "考核通过即颁 EN ISO 9712 证书，官网可查")
    return im


def frame_data():
    im = build_bg().convert("RGBA")
    d = ImageDraw.Draw(im)
    draw_badges(d)
    # 标题下移，卡片居中铺满
    crisp_text(d, (W // 2, 300), "两个月招聘数据，比焦虑更扎心", FONTS["cn_b48"], WHITE)
    crisp_text(d, (W // 2, 365),
               "全部来自真实招聘 · 船海先锋 2026.7.1–8.20", FONTS["cn28"], GRAY)
    stats = [
        ("289", "NDT/探伤招聘提及", "占全部 2.2% · 日均约 8 次", GOLD),
        ("45.8%", "NDT 需求集中在长三角", "南通·上海·江阴·启东·扬州", CYAN),
        ("109 次", "焊接证 + NDT 双证同现", "焊接检验也要持证探伤", GOLD),
        ("81.5%", "NDT 岗位要求 6 年以上经验", "企业不愿培养新人", CYAN),
        ("176 次", "英语 + NDT 同现", "涉外项目·海外驻场标配", GOLD),
    ]
    ch, gap = 200, 230
    y = 430
    for num, t1, t2, col in stats:
        rr(d, [SAFE_L, y, W - SAFE_L, y + ch], 16, fill=PANEL, outline=CYAN, width=2)
        # 红色警示条
        d.rectangle([SAFE_L, y, SAFE_L + 10, y + ch], fill=RED_ACC)
        # 数字右对齐，确保不溢出卡片左边缘
        crisp_text(d, (270, y + ch // 2), num, FONTS["cn_b56"], col, anchor="rm",
                   max_w=210)
        crisp_text(d, (310, y + 60), t1, FONTS["cn_b32"], WHITE, anchor="lm",
                   max_w=680)
        crisp_text(d, (310, y + 125), t2, FONTS["cn28"], GRAY, anchor="lm",
                   max_w=680)
        y += gap
    subtitle_bar(d, "NDT 从加分项，变成硬门槛")
    return im


def frame_grid():
    im = build_bg().convert("RGBA")
    d = ImageDraw.Draw(im)
    draw_badges(d)
    # 标题下移，六宫格在可用区域垂直居中
    crisp_text(d, (W // 2, 300), "覆盖六大主流检测方法", FONTS["cn_b56"], WHITE)
    cells = [
        ("VT", "目视检测", "表面缺陷直观"),
        ("UT", "超声检测", "内部缺陷精准"),
        ("RT", "射线检测", "厚壁内部透视"),
        ("MT", "磁粉检测", "铁磁表面裂纹"),
        ("PT", "渗透检测", "非磁表面开口"),
        ("PAUT", "相控阵", "多角度成像"),
    ]
    cols, cw, ch = 2, 440, 220
    gx, gy = 40, 45
    block_w = cols * cw + (cols - 1) * gx
    block_h = 3 * ch + 2 * gy
    sx = (W - block_w) // 2
    sy = (380 + SAFE_B - 80) // 2 - block_h // 2
    for i, (code, cn, desc) in enumerate(cells):
        r, c = divmod(i, cols)
        x = sx + c * (cw + gx)
        y = sy + r * (ch + gy)
        rr(d, [x, y, x + cw, y + ch], 18, fill=PANEL, outline=CYAN, width=2)
        crisp_text(d, (x + cw // 2, y + 60), code, FONTS["en56"], GOLD)
        crisp_text(d, (x + cw // 2, y + 115), cn, FONTS["cn_b40"], WHITE)
        crisp_text(d, (x + cw // 2, y + 170), desc, FONTS["cn28"], GRAY)
    subtitle_bar(d, "VT · UT · RT · MT · PT · PAUT 任选报名")
    return im


TARGETS = [
    ("preview_cover", frame_cover),
    ("preview_data", frame_data),
    ("preview_turn", frame_turn),
    ("preview_cert", frame_cert),
    ("preview_grid", frame_grid),
]

def validate_frame(name, fn):
    """渲染前预检：收集文字包围盒并检测互相重叠（出画由 crisp_text 内部拦）。"""
    global COLLECTOR
    c = Collector()
    COLLECTOR = c
    try:
        fn()  # 触发 crisp_text 登记 + 出画断言
    finally:
        COLLECTOR = None
    bad = c.overlaps()
    if bad:
        for l1, l2, ix, iy in bad:
            print(f"  [{name}] 文字重叠: '{l1}' × '{l2}' 重叠 {ix}×{iy}px", file=sys.stderr)
        return False
    return True


if __name__ == "__main__":
    errors = []
    for name, fn in TARGETS:
        # 第一步：渲染前布局校验（出画 / 重叠），不过则不出图
        if not validate_frame(name, fn):
            errors.append((name, "布局校验未通过（文字重叠）"))
            continue
        try:
            im = fn()
            p = os.path.join(OUT, name + ".png")
            im.convert("RGB").save(p, quality=95)
            print("saved", p, os.path.getsize(p))
        except Exception as e:
            errors.append((name, str(e)))
            print(f"ERROR in {name}: {e}", file=sys.stderr)
    if errors:
        print("\nFAILED FRAMES:")
        for name, err in errors:
            print(f"  {name}: {err}")
        sys.exit(1)
    print("ALL DONE · 布局校验通过")
