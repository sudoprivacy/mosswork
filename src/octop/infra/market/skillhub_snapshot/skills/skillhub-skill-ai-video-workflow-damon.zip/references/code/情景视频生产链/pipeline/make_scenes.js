// 从情景引擎自动拆分镜: genScenario -> scenes.json (+ script.md + 图片清单)
//
// 用法:
//   node pipeline/make_scenes.js <domain> <key> [platform] [选项]
// 选项:
//   --project <name>       工程名(默认 <domain>_<key>)
//   --mode narration|dialogue   旁白讲解片 / 双人对话片(默认 narration)
//   --lang zh|en           口播语言(默认 zh; dialogue 模式默认 en)
//
// 产出 projects/<工程>/ 下:
//   script.md              引擎原文(中英双语全文, 存档用)
//   scenes.json            分镜表
//   images_needed.json     尚缺的图 + 提示词
//   translate_needed.json  待补中文字幕的对话行(仅 dialogue 模式)

const fs = require('fs');
const path = require('path');
const { loadEngine } = require('./list_scenarios.js');

const ROOT = path.resolve(__dirname, '..');
const CFG = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));

const argv = process.argv.slice(2);
function opt(name, def) {
  const i = argv.indexOf('--' + name);
  return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : def;
}
// 位置参数 = 既不是 --flag 也不是 --flag 的取值
const pos = [];
for (let i = 0; i < argv.length; i++) {
  if (argv[i].startsWith('--')) {
    if (argv[i + 1] && !argv[i + 1].startsWith('--')) i += 1;   // 跳过取值
    continue;
  }
  pos.push(argv[i]);
}
const domain = pos[0] || 'hse';
const key = pos[1] || 'lifting_stop';
const platform = pos[2] || 'offshore';
const projName = opt('project', `${domain}_${key}`);
const mode = (opt('mode', CFG.default_mode || 'narration') || '').toLowerCase();
if (!['narration', 'dialogue'].includes(mode)) {
  console.error('--mode 只支持 narration | dialogue'); process.exit(1);
}
const lang = (opt('lang', mode === 'dialogue' ? 'en' : (CFG.default_lang || 'zh')) || '').toLowerCase();
if (!['zh', 'en'].includes(lang)) { console.error('--lang 只支持 zh | en'); process.exit(1); }

const eng = loadEngine();
const r = eng.genScenario(domain, key, platform, 'bi');
if (!r || !r.body) { console.error('genScenario 返回空, 检查 domain/key'); process.exit(1); }
const body = r.body;
const raw = ((eng.SCENARIOS || {})[domain] || []).find(x => x.key === key) || {};

// ---------- 标题 ----------
function grab(re) { const m = body.match(re); return m ? m[1].trim() : ''; }
const titleEn = grab(/EN:\s*(.+)/);
const titleZh = grab(/ZH:\s*(.+)/);

// ---------- 角色名(英文) ----------
// 头部形如: 【主持/发起 Chair】 EN名 / 中文名　|　【参与/接收 Participant】 EN名 / 中文名
function roleNames() {
  const line = (body.split('\n').find(l => l.includes('Chair')) || '');
  const segs = line.split(/[|｜]/);
  const clean = (seg, zh) => {
    let t = (seg || '').replace(/【[^】]*】/g, '').replace(/[　\s]+/g, ' ').trim();
    if (zh && t.endsWith(zh)) t = t.slice(0, t.length - zh.length).replace(/[\/\s]+$/, '');
    return t.trim();
  };
  return {
    aEn: clean(segs[0], raw.roleA) || 'Inspector',
    bEn: clean(segs[1], raw.roleB) || 'Counterpart',
    aZh: (raw.roleA || '我方').trim(),
    bZh: (raw.roleB || '对方').trim(),
  };
}
const ROLE = roleNames();

// ---------- 步骤(中英) ----------
function steps(l) {
  const seg = body.split(/【情景介绍 \/ Introduction】/)[1] || '';
  const part = l === 'en' ? seg.split(/\n\s*ZH:/)[0] : (seg.split(/\n\s*ZH:/)[1] || '');
  return part.split('\n').map(s => s.trim())
    .filter(s => /^\d+\.\s/.test(s))
    .map(s => s.replace(/^\d+\.\s*/, '').trim());
}
const enSteps = steps('en');
const zhSteps = steps('zh');

// ---------- 对话(英文 A/B) ----------
function dialogueTurns() {
  const seg = body.split(/【人物对话 \/ Dialogue】[^\n]*\n/)[1] || '';
  const stop = seg.search(/\n\s*(Applicable standards|脱敏占位符|【)/);
  const block = stop >= 0 ? seg.slice(0, stop) : seg;
  const out = [];
  for (const line of block.split('\n')) {
    const m = line.trim().match(/^([AB])\s*[:：]\s*(.+)$/);
    if (!m) continue;
    let text = m[2].trim();
    let tag = '';
    const p = text.match(/^\(([^)]{1,40})\)\s*(.*)$/);
    if (p) { tag = p[1].trim(); text = p[2].trim(); }
    out.push({ who: m[1], tag, text });
  }
  return out;
}

// ---------- 文本工具 ----------
function speakableZh(s, max = 60) {
  let t = s.replace(/\(([^)]*)\)/g, '').replace(/（[^）]*）/g, '')
    .replace(/\s+/g, ' ').replace(/\s*([，。；、：])\s*/g, '$1')
    .replace(/^[\s,、;；]+|[\s,、;；]+$/g, '').trim();
  if (t.length > max) {
    const cut = t.slice(0, max);
    const p = Math.max(cut.lastIndexOf('，'), cut.lastIndexOf('。'),
      cut.lastIndexOf('；'), cut.lastIndexOf('、'), cut.lastIndexOf(','), cut.lastIndexOf(';'));
    t = p > max * 0.5 ? cut.slice(0, p) : cut;
  }
  t = t.replace(/[，、；,;]$/, '');
  return /[。！？.]$/.test(t) ? t : t + '。';
}
const TTS_ZH = [
  [/≥/g, '不低于'], [/≤/g, '不超过'], [/＞|>/g, '大于'], [/＜|</g, '小于'],
  [/(\d)\s*×\s*\/\s*/g, '$1次每'], [/×/g, '乘'],
  [/℃/g, '摄氏度'], [/%/g, '％'], [/\//g, '、'], [/&/g, '和'], [/\+/g, '加'],
  [/[—–]{1,}/g, '，'], [/\s{2,}/g, ' '],
];
function toSpeechZh(s) {
  let t = s;
  for (const [re, rep] of TTS_ZH) t = t.replace(re, rep);
  return t.replace(/、{2,}/g, '、').replace(/，{2,}/g, '，').trim();
}
// 英文朗读: 符号口语化, 避免 TTS 读出奇怪字符
const TTS_EN = [
  [/\s*→\s*/g, ', then '], [/≥/g, 'no less than '], [/≤/g, 'no more than '],
  [/\s*[—–]\s*/g, ', '], [/\s*\/\s*/g, ' or '],
  [/℃/g, ' degrees Celsius'], [/&/g, ' and '],
  [/\s{2,}/g, ' '],
];
function toSpeechEn(s) {
  let t = s;
  for (const [re, rep] of TTS_EN) t = t.replace(re, rep);
  return t.replace(/\s+([,.;:])/g, '$1').replace(/,\s*,/g, ',').trim();
}
function enShort(s, max = 150) {
  let t = s.replace(/\s+/g, ' ').trim();
  if (t.length > max) {
    const cut = t.slice(0, max);
    const p = cut.lastIndexOf(' ');
    t = (p > max * 0.6 ? cut.slice(0, p) : cut);
  }
  return t.replace(/[,;:]$/, '');
}

// ---------- 人物形象设定(对话模式图片一致性) ----------
const CHARACTERS = {
  A: {
    role_en: ROLE.aEn, role_zh: ROLE.aZh,
    look: `Character A (${shortRole(ROLE.aEn)}): asian male in his 40s, short black hair, orange high-visibility vest over navy work shirt, white hard hat, clipboard and pen, exactly two arms and two hands`,
  },
  B: {
    role_en: ROLE.bEn, role_zh: ROLE.bZh,
    look: `Character B (${shortRole(ROLE.bEn)}): asian male in his 30s, stubble, blue coverall, yellow hard hat, two-way radio and work gloves, exactly two arms and two hands`,
  },
};
// 严格解剖学护栏: 杜绝"三只手/漂浮手/重复肢体/缺失肢体"等不合逻辑图
const ANATOMY = (' Strict anatomy, must be logically correct: every visible person has exactly '
  + 'two arms and two hands, no extra limbs, no extra or floating hands, no third arm, '
  + 'no duplicated or missing body parts; all limbs natural and unbroken. One person = '
  + 'two hands only.');
const CAST = `Two recurring characters, keep their faces, clothing and exactly two arms and two hands identical in every shot. ${CHARACTERS.A.look}. ${CHARACTERS.B.look}`;

function imgPrompt(subject, withCast) {
  const s = String(subject).replace(/\s+/g, ' ').trim().slice(0, 260).replace(/[.\s]+$/, '');
  return `${CFG.image_style}.${withCast ? ' ' + CAST + '.' : ''} Scene depicts: ${s}. No text, no watermark, no logos.${ANATOMY}`;
}
// 多角色名取第一个作显示名: "Lift Supervisor / Rigger / Nearby Workers" -> "Lift Supervisor"
function shortRole(s) {
  return String(s || '').split('/')[0]
    .replace(/\s*[\(\（][^\)\）]*[\)\）]\s*/g, '')
    .replace(/[\s\/]+$/g, '').trim() || String(s || '').trim();
}

// ---------- 组装分镜 ----------
const scenes = [];
let idx = 0;
function push(o) {
  o.image_file = `scene_${String(o.idx).padStart(2, '0')}.png`;
  o.tts_zh = o.narration_zh ? toSpeechZh(o.narration_zh) : '';
  o.tts_en = o.narration_en ? toSpeechEn(o.narration_en) : '';
  scenes.push(o);
}

const cleanTitleZh = titleZh.replace(/（.*?）/g, '').trim();
const cleanTitleEn = titleEn.replace(/\(.*?\)\s*$/, '').trim();

// 开场镜(旁白)
idx += 1;
push({
  idx, speaker: 'N',
  speaker_en: 'Narrator', speaker_zh: '旁白',
  caption_zh: '情景导入', caption_en: 'Context',
  narration_zh: speakableZh(cleanTitleZh, 40),
  narration_en: enShort(cleanTitleEn),
  image_prompt: imgPrompt(`wide establishing shot of the work front for ${cleanTitleEn}`, mode === 'dialogue'),
  image_hint_zh: `全景交代现场：${cleanTitleZh}`,
});

let turns = [];
if (mode === 'dialogue') {
  turns = dialogueTurns();
  if (!turns.length) {
    console.error('未解析到 A/B 对话, 该情景可能没有 Dialogue 段。前 800 字:\n' + body.slice(0, 800));
    process.exit(1);
  }
  turns.forEach((t, i) => {
    idx += 1;
    const c = CHARACTERS[t.who];
    const nameEn = t.tag ? t.tag.replace(/^\w/, m => m.toUpperCase()) : shortRole(c.role_en);
    const me = t.who === 'A' ? 'Character A' : 'Character B';
    const other = t.who === 'A' ? 'Character B' : 'Character A';
    push({
      idx, speaker: t.who,
      speaker_en: nameEn, speaker_zh: shortRole(c.role_zh),
      caption_zh: `对话 ${i + 1}`, caption_en: `Turn ${i + 1}`,
      narration_zh: '',                 // 待翻译
      narration_en: t.text,
      image_prompt: imgPrompt(
        `${me} talking to ${other} at the work front, ${me} is the one speaking and in focus. ` +
        `Show the physical situation behind these words (do not render the words): "${t.text}"`, true),
      image_hint_zh: `${t.who === 'A' ? '角色A' : '角色B'}（${shortRole(c.role_zh)}）在说话，镜头对着他`,
    });
  });
} else {
  const n = Math.min(enSteps.length, zhSteps.length);
  if (!n) { console.error('未解析到步骤, body 结构可能变了'); process.exit(1); }
  for (let i = 0; i < n; i++) {
    idx += 1;
    push({
      idx, speaker: 'N',
      speaker_en: 'Narrator', speaker_zh: '旁白',
      caption_zh: `步骤 ${i + 1}`, caption_en: `Step ${i + 1}`,
      narration_zh: speakableZh(zhSteps[i]),
      narration_en: enShort(enSteps[i]),
      image_prompt: imgPrompt(enSteps[i], false),
      image_hint_zh: zhSteps[i],
    });
  }
}

// 收尾镜(旁白)
const stds = (r.standards || raw.std || [])
  .map(s => (typeof s === 'string' ? s : (s.code || s.id || ''))).filter(Boolean);
idx += 1;
push({
  idx, speaker: 'N',
  speaker_en: 'Narrator', speaker_zh: '旁白',
  caption_zh: '依据与收口', caption_en: 'Standards & Close-out',
  narration_zh: stds.length
    ? `全过程依据 ${stds.slice(0, 3).join('、')} 执行，记录归档可追溯。`
    : '全过程按项目技术协议执行，记录归档可追溯。',
  narration_en: stds.length
    ? `Executed per ${stds.slice(0, 3).join(', ')}; records filed and traceable.`
    : 'Executed per project technical agreement; records filed and traceable.',
  image_prompt: imgPrompt('inspector filing signed inspection records and reports in a site office, documents and folders on desk', mode === 'dialogue'),
  image_hint_zh: '收尾：办公室里归档签署好的检验记录',
});

// ---------- 落盘 ----------
const projDir = path.join(ROOT, 'projects', projName);
fs.mkdirSync(path.join(projDir, 'images'), { recursive: true });
fs.mkdirSync(path.join(projDir, 'audio'), { recursive: true });

const out = {
  meta: {
    domain, key, platform, mode, lang,
    title_zh: cleanTitleZh, title_en: cleanTitleEn,
    role_a_en: ROLE.aEn, role_a_zh: ROLE.aZh,
    role_b_en: ROLE.bEn, role_b_zh: ROLE.bZh,
    characters: CHARACTERS,
    cast_prompt: CAST,
    source: `changhai_expert.html genScenario('${domain}','${key}','${platform}','bi')`,
    style: CFG.image_style,
    standards: stds,
    generated_at: new Date().toISOString(),
  },
  scenes,
};
fs.writeFileSync(path.join(projDir, 'scenes.json'), JSON.stringify(out, null, 2), 'utf8');
fs.writeFileSync(path.join(projDir, 'script.md'), body, 'utf8');

// 缺图清单
const needed = scenes
  .filter(s => !fs.existsSync(path.join(projDir, 'images', s.image_file)))
  .map(s => ({ idx: s.idx, image_file: s.image_file, prompt: s.image_prompt, hint_zh: s.image_hint_zh }));
fs.writeFileSync(path.join(projDir, 'images_needed.json'), JSON.stringify(needed, null, 2), 'utf8');

// 待翻译清单(对话模式: 中文字幕需另补)
const tneed = scenes.filter(s => s.narration_en && !s.narration_zh)
  .map(s => ({ idx: s.idx, speaker: s.speaker, speaker_en: s.speaker_en, en: s.narration_en, zh: '' }));
const tPath = path.join(projDir, 'translate_needed.json');
if (tneed.length) {
  fs.writeFileSync(tPath, JSON.stringify(tneed, null, 2), 'utf8');
} else if (fs.existsSync(tPath)) {
  fs.unlinkSync(tPath);
}

console.log(`OK  project: projects/${projName}`);
console.log(`    模式: ${mode}   口播: ${lang === 'en' ? '英语' : '中文'}`);
console.log(`    标题: ${out.meta.title_zh}`);
console.log(`    角色: A=${ROLE.aEn} (${ROLE.aZh})  |  B=${ROLE.bEn} (${ROLE.bZh})`);
console.log(`    分镜: ${scenes.length} 镜`);
console.log(`    标准: ${stds.join(', ') || '(无)'}`);
console.log(`    缺图: ${needed.length} 张 -> images_needed.json`);
if (tneed.length) console.log(`    待补中文字幕: ${tneed.length} 条 -> translate_needed.json`);
