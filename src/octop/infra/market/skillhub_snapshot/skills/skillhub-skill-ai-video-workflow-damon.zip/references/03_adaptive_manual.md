# 自适应能力手册 — 视频任务推断与排版规格

> 本文件是**接新视频任务时的查表工具** + **"做成功过什么"的可查参数库**。
> 所有数字都从 `framework/canvas.py`、`framework/styles.py`、`framework/backgrounds.py`、`framework/audio.py`、`framework/layouts.py` 实测提取，**不是凭感觉**。
> 任何在 `smoke_test.py` 验证过的组合都标记 "✅"。

## 零、5 步推断流程（接任何新任务先走一遍）

```
1. 看内容 (PPT/脚本/图/表/口播词)  →  选 工作流
2. 看风格需求 (商务/工业/科普/文化) →  选 style (6 选 1)
3. 看呈现方式 (开场/流程/对比/数据) →  选 版式 (10 选 1)
4. 看播放场景 (抖音/公众号/培训)  →  选 方向 (9:16/16:9/1:1) + 安全区
5. 看受众与语言 (中/英/双语)    →  选 音色 + caption 语言
```

走完这 5 步，剩下只是写 brief.json 跑命令。**任何一步不确定的，回到"决策表"对应章节查**。

---

## 一、工作流选择决策表（看内容定工具）

| 内容类型 | 工作流 | 入口命令 |
|---|---|---|
| 标准里的**表格**（AWS Table 6.10 / ASME Table 341.3.2） | 表格讲解视频 | `python render/render_table_walkthrough_l_pos_en.py`（伞根）|
| 标准里的**图**（AWS Figure 6.16 等） | 图片讲解视频 | `python 图片讲解视频/main.py --brief brief.json` |
| 行业知识网络 / 中英情景对话 | 情景视频生产链 | `cd 情景视频生产链 && python run.py <topic> --lang en` |
| 培训宣传（NDT / 探伤证 / 先焦虑后推产品） | NDT 培训竖屏 | `python NDT培训竖屏/render/render_training_promo_v2.py` |
| 周报 PPT | 周报视频 | `python 周报视频/pipeline/weekly_build.py --project <项目名>` |
| 干净视频（豆包/即梦）+ 加字幕 | 豆包视频拼接加字幕 | `python 豆包视频拼接加字幕/sync_subtitles.py --video in.mp4 ...`（横屏）/ `gen_vertical_sentences.py`（竖屏） |
| 剧本/梗概 → 分镜图 | 小短剧分镜 | `python 小短剧分镜/character_face_check.py` 等 |

**判断不出？** 走内容特征匹配：
- 一次要讲"标 准 原 图 + 多个点 高亮" → 一定是**图片讲解**的 figure 版式
- 要"逐行 / 逐格 / 逐条"高亮 → 表格讲解
- 要"两个人对话 + 多镜头" → 情景视频
- "演讲 + PPT 同步播" → 配照片讲解 PPT 视频工作流（图片讲解的母集）

---

## 二、风格矩阵（6 种内置，**必须按受众与场景挑**）

| Key | 中文名 | 背景类型 | 调色 | 字体键 | 适用场景 |
|---|---|---|---|---|---|
| `business` | 商务风 | gradient | 深蓝渐变+钢蓝 | cn:msyh, en:arial | 汇报/宣传/标准讲解 |
| `manga` | 漫画风 | dots | 柔粉+粗黑 | cn:simhei, en:arialbd | 学生/科普/轻松 |
| `realistic` | 写实风 | photo | 暗化+自然渐变 | cn:msyh, en:arial | 产品/人物/纪实 |
| `guofeng` | 国风 | ink | 米黄+朱红+楷体 | cn:simkai, en:arial | 文化/传统/知识 |
| `mechanical` | **机械风** | grid | 深蓝网格+青色辉光 | cn:msyh, en:arialbd | **重工业/工程/标准**（v18 焊工资格试板用）|
| `punk` | 朋克风 | scanline | 暗紫+品红霓虹 | cn:simhei, en:arialbd | 潮酷/科技/年轻向 |

新增风格协议（**不能改即兴写**）：
1. `framework/styles.py` 的 `STYLES` 字典加一条 `Style(...)`；
2. 必须填 `bg_type` / `palette` / `fonts(cn,cn_b,en,en_b)` / `decorations` / `transition`；
3. 跑 `python smoke_test.py` 验证 120 组合 ✅；
4. 必要时 `python smoke_test.py --e2e` 跑端到端横竖屏各一支。

---

## 三、版式矩阵（10 种 + 何时用）

| Key | 用途 | 典型 brief 字段 |
|---|---|---|
| `cover` | 开场/封面（kicker + title + 副图）| `kicker, title, figure.path` |
| `steps` | 3-5 步流程 | `steps=[{n,t,d},...]` |
| `split` | 左图右文 | `body, illustration` |
| `data` | 半圆图 + 列表指标 | `data={"指标":"值"}` |
| `timeline` | 时间线（项目里程碑）| `nodes=[{t,d}]` |
| `glass` | 玻璃卡 + 多信息 | `body, body_title, keyword` |
| `highlight` | 核心卖点（1 句话 + 关键词）| `keyword, sub` |
| `quote` | 引用 | `quote, source` |
| `compare` | 左右对比 | `compare={left_title,right_title,left_items,right_items}` |
| `figure` | **标准原图 + 多点高亮** | `figure={path, hl_rects=[{x,y,w,h,style,label}]}` |

**关键约束**：
- `compare` 在 `host_photos` 场景下布局有 bug（标题超屏）→ 改用 `split` 或 `steps`；
- `figure` 必须给 `hl_rects`（不是猜坐标的 `highlights`）→ 坐标按 `fx+fw*nx` 算，y 不翻转；
- `data` 的指标值用正则提数字，兼容 `≥94%` / `≤5` / `100%`；
- `glass` 的 `body_title` 默认空（避免与 caption 重复念）。

---

## 四、横竖屏排版规格 ✅（120 组合硬审核 PASS 验证）

`framework/canvas.py::Canvas.metrics()` 是权威。下面是实测过的完整两套常量。

### 4.1 竖屏 1080×1920（portrait）

| 字段 | 值 | 含义 |
|---|---|---|
| `safe` | (190, 1620, 40, 1040) | 平台 UI 安全区：顶 190 / 底 1620 / 左 40 / 右 1040 |
| `subtitle_y` | 1660 | 字幕起始 y（CN/EN 两行 1660+44=1704）|
| `header_y` | 300 | 标题起始 y |
| `content_left` / `content_right_none` | 90 / 990 | 无主播/无照片时文字区（宽 900）|
| `content_right_host` | 720 | 有主播时文字区右边（让出右 280 给主播竖条）|
| `content_right_photos` | 1040 | 有照片时文字区右边（几乎全宽）|
| `photo_x/top/w` | 60/660/460 | 左侧照片框 |
| `host_box` | (760, 1220, 1040, 1580) | 主播竖条（右下）|
| `body_y` | 700 | 正文起始 y |
| `illus_top / illus_bot` | 1080 / 1520 | 图说/插画纵向区间 |
| `data_cy / data_r` | 720 / 150 | 半圆图中心/半径 |
| `tl_y` | 760 | timeline 起始 y |
| `glass_y` | 680 | 玻璃卡起始 y |
| `hl_kw_y / hl_sub_y` | 760 / 1080 | highlight 关键词/副标 y |
| `cmp_photo_boxes` | [(90,1180,530,1540), (550,1180,990,1540)] | compare 2 张图框 |
| `step_start / step_gap` | 660 / 200 | steps 起始 y / 行距 |
| `kind_bounds.caption` | (1640, 1900) | 字幕纵向安全带 |

### 4.2 横屏 1920×1080（landscape）✅

| 字段 | 值 | 含义 |
|---|---|---|
| `safe` | (90, 960, 60, 1860) | 顶 90 / 底 960 / 左 60 / 右 1860 |
| `subtitle_y` | 900 | 字幕起始 y（两行 900+44=944 落在 900-1075）|
| `header_y` | 90 | 标题起始 y |
| `content_left / content_right_none` | 120 / 1800 | 文字区（宽 1680，是竖屏 1.87×）|
| `content_right_host` | 1480 | 有主播让出 1480-1860=380 |
| `content_right_photos` | 1820 | 有照片几乎全宽 |
| `photo_x/top/w` | 120/520/620 | 左侧照片框（比竖屏大 35%）|
| `host_box` | (1560, 600, 1860, 940) | 主播右下方 |
| `body_y` | 360 | 正文起始 y |
| `illus_top / illus_bot` | 440 / 900 | 图说区间（高度 460 vs 竖屏 440）|
| `data_cy / data_r` | 470 / 150 | 半圆图中心 |
| `cmp_photo_boxes` | [(150,540,820,920), (1000,540,1670,920)] | compare 2 张图框 |
| `step_start / step_gap` | 360 / 150 | steps 行距缩小（高度有限）|
| `kind_bounds.caption` | (900, 1075) | 字幕纵向安全带（为两行放宽到 1075）|

### 4.3 字号规则（已 120 组合 PASS 实测）

- **绝对字号不变**（横屏字相对高度反变大，无须缩放）：
  - `cn_b` 30/40/50/52/56/120；`cn` 28/30/32/34/40/46；`en_b` 28/30/44/46/64；`en` 28/30/32
- **已做横竖屏分支的字号**（2 处）：
  - `en_b` 44→52（横屏略大 18%）
  - `cn_b` 26→30（同上）
- **行长自动适配**：`wrap_cjk(text, font, width)` 用 `m["content_right_none"] - 140`（横屏=1660，竖屏=850），自动换行
- **glow_text 长关键词自适应**：`max(18, int(32*max_kw_w/tw))` 按卡片宽缩字号

### 4.4 已修的硬编码（2026-09-08 这次）

`framework/layouts.py` 三处按竖屏 1080 宽写死的坐标，导致横屏时右半边空着：

| 行 | 旧 | 新（方向自适应） |
|---|---|---|
| 228 (cover 图) | `fx0,fx1=70,1010; fy0,fy1=bar_y+30,1180` | 竖屏原值；横屏 `60→canvas.w*0.97` / `bar_y+30→min(canvas.h*0.92, 1010)` |
| 687 (figure 图) | `fx0,fx1=70,1010; fy0,fy1=yy+th+30,1050` | 竖屏原值；横屏 `60→canvas.w*0.97` / `yy+th+30→min(canvas.h*0.88, 1010)` |
| 775 (figure 下半区) | `px0,px1=60,1020; py0,py1=fy1+24,1620` | 竖屏原值；横屏 `60→canvas.w-60` / `fy1+24→min(canvas.h*0.96, 1040)` |

**改完 120 组合冒烟仍全 PASS**（覆盖原"超屏/重叠/图压字"风险）。

---

## 五、字体（仅 Windows 字体库）

`framework/styles.py::FONT_FILES`：

| key | 路径 | 用途 |
|---|---|---|
| `msyh` | `C:\Windows\Fonts\msyh.ttc` | 中文常规（business/realistic/mechanical 默认）|
| `msyhbd` | `msyhbd.ttc` | 中文加粗 |
| `simhei` | `simhei.ttf` | 中文粗黑（manga/punk 默认）|
| `simkai` | `simkai.ttf` | 楷体（guofeng 默认）|
| `simsun` | `simsun.ttc` | 宋体 |
| `simfang` | `simfang.ttf` | 仿宋 |
| `arial` | `arial.ttf` | 英文常规 |
| `arialbd` | `arialbd.ttf` | 英文加粗 |

**Linux/Mac fallback**：缺字体时回退 `PIL.ImageFont.load_default()`（中文会出 tofu 方块 → Linux 部署必须装思源黑体或自带字体）。

**双字体绘制**：中英分行各自取字体（`canvas._point_layer`），禁止用一个字体渲染两种语言（特别是 Arial 渲染中文会出方块）。

---

## 六、背景图规则

`framework/backgrounds.py`：

- **`_cover_crop(im, w, h)`** —— **等比 cover 裁剪，绝不拉伸**（填满 + 居中裁溢出）
- **写实风（realistic）压暗参数**（v18 焊工资格试板实测）：
  - `Brightness 0.55` / `Color 0.72` / `Contrast 1.22`
  - 深蓝蒙版 `Image.blend(im, (10,16,30), 0.45)`
  - 底部 38% 渐变压暗（让白字可读）
- **`bg_image` 对所有风格生效**（不只是 realistic）→ 6 风格都先压暗 bg_image 再做底
- 风格装饰叠在背景之上：grid / dots / ink / scanline / halftone / vignette

---

## 七、声音 / 音色 / 语言

`framework/audio.py`：

### 7.1 音色预设（`VOICE_PROFILES`）

| 预设名 | edge-tts 音色 id | 性别/风格 |
|---|---|---|
| `female_warm` (默认) | zh-CN-XiaoxiaoNeural | 女·自然温暖 |
| `female_calm` | zh-CN-XiaoruiNeural | 女·成熟专业 |
| `female_lyric` | zh-CN-XiaohanNeural | 女·抒情柔和 |
| `male_steady` | zh-CN-YunyangNeural | 男·沉稳播报 |
| `male_young` | zh-CN-YunxiNeural | 男·年轻活泼 |
| `male_narrator` | zh-CN-YunjianNeural | 男·叙事感 |

### 7.2 配音铁律（血泪清单 → 不允许违反）

1. **全片单一音色**（`voices=[v]`），重试不换音 → 防 v18 "忽男忽女"
2. **rate 默认 +30%**（edge-tts 原生参数，非 SSML）
3. **禁 SSML**（`<speak><prosody>` 包裹会让时长膨胀 5-6×，已弃用）
4. **volume 不能是 "medium"**（edge-tts 只接受百分比/Hz 字符串；用 `+0%` / `+10%`）
5. **TTS 缓存按场景序号命名** → 改 `spoken` 文案后必删 `render/audio_cache*/*.mp3` 再渲染
6. **先 TTS 再绘制**，用 `canvas.sync_to_audio()` 让画面元素铺开与配音对齐
7. **真实配音驱动时长**：`dur = max(2.2, dur)`，禁用 `min(7.0, ...)` 截断
8. **转场不跳帧**（`engine.py` 头部交叉溶解），视频时长 = Σ各场景配音时长（误差<0.1s）
9. **ffmpeg 必加 `-shortest` 防尾部空白**
10. **音轨必须单轨 aac mono** → `check.py` A3 自动校验

### 7.3 语言规则

- 视频语言分三类：**全中文 / 全英文 / 双语（caption + caption_en）**
- 选定后**全片一致**，禁止中途切换
- `caption_en` 必须**纯 ASCII**（非 ASCII 字符在中文字体下出 tofu）
- 未提供时**留空**（不留默认中文）
- 双语字幕顺序：EN 上 / CN 下（`canvas.subtitle()` 默认）
- 字幕**不加框**（`subtitle()` 函数无 bbox）

---

## 八、画重点（6 原语 + follow 绑定）

`framework/canvas.py` 提供的 6 个画重点原语：

| 原语 | API | 适用 |
|---|---|---|
| `callout_arrow` | `canvas.callout_arrow(sx,sy,ex,ey,color,w)` | 线+箭头引线 callout |
| `marker_dot` | `canvas.marker_dot(cx,cy,r,color)` | 脉冲圆点（左侧 margin）|
| `row_band` | `canvas.row_band(x0,y0,x1,y1,color,alpha=38)` | 半透明行高亮带 |
| `underline` | `canvas.underline(x0,y,x1,y,color,w=9)` | 文字下方留白下划线（不能压在字上）|
| `magnifier` | `canvas.magnifier(cx,cy,r,color)` | 放大镜圈 |
| `glow_text` | `canvas.glow_text(...)` | 多色发光大字（按卡片宽自动缩字号）|

**纪律**：
- 同一视频**至少用 3 种**（防"形式单一"）
- 高亮框 **4px 单线**（禁 8px+白边"大膏药"）
- **每点不同 enter 动画**（fade/zoom/pop/slide 轮换）
- `follow=f"bullet_{i}"` 绑定讲解句 → `appear_at = target+0.03s`（防 v18 "开场全蹦"）

---

## 九、标准引用正确性（血泪 → 必修）

- **同一图多个要点必须共用一张干净裁图**（讲 Figure 6.16 的所有点都引用 `shot_fig616.png`）
- **clip 严格止于该图注末行**（`fitz.Rect(x0,y0,x1,y_end)`）
- **裁完用 fitz 文本核验** clip 区不含邻图标题（`assert "Figure 6.17" not in text`）
- **引用标准号必须按 spec**（v11 R44 红线：**不锈钢焊接引用 AWS D1.1 应改 D1.6 或对应 GB**）
- 引用条文同时给**中文短译**（防翻译偏差）

---

## 十、硬闸门（自动拦截，绝不靠人记）

| 闸门 | 触发条件 | 出处 |
|---|---|---|
| `Canvas.validate(strict=True)` | 超屏 / 文字互叠 / 图压字 | `framework/canvas.py` |
| `_voice_title_check` | 配音为空或不含画面 title 主题词 | `framework/engine.py` |
| `smoke_test.py` | 6 风格×9 版式×2 方向=120 组合硬审核 | `图片讲解视频/smoke_test.py` |
| `smoke_test.py --e2e` | 端到端 mini 渲染（竖+横，需联网 edge-tts）| 同上 |
| `check.py` A1-A8 | 交付前 8 项自动自检 | 伞根 `check.py` |
| `audible.head_silence / tail_silence` | 头/尾静音突断 | `check.py` 内置 |

**任何新风格/版式/坐标改动 → 必须重跑 120 组合冒烟**，不跑就交付 = 失职。

---

## 十一、新任务最小执行清单

```
1. 明确: 内容/风格/版式/方向/语言/音色
2. 写 brief.json (参照 framework/content.py::plan 接受的字段)
3. python main.py --brief brief.json --style X --orientation Y --voice Z
4. python check.py output.mp4 --expect Σ配音时长秒
5. 抽 6 帧肉眼抽检 (1 次性,后续靠 check.py 自动)
6. 交付: 真实绝对路径 + QC 报告
```

---

## 十二、坐标系铁律（改坐标必查 4 处）

1. **标签 ↔ 金色评定条**（间距 ≥12px，不能压字）
2. **金色评定条 ↔ 正文首行**（不能压字）
3. **黄色大代码底部 ↔ 左下小字**（≥12px 留白）
4. **正文末行 ↔ 卡片底圆角**（≥18px 留白防裁剪）

**任一处重叠/裁剪 → 先给整体方案再一起改**，绝不只挪一个元素（历史反复返工根因）。

---

## 十三、自学习机制（接到从未见过的新形式时）

1. **先去 sample 找参考**：用 `webfetch` / `websearch` 查同类型的公开样片
2. **拆解到本手册已有的版式**：80% 的"新形式"是已有版式 + 不同风格/方向/语言的组合
3. **不重复造轮子**：能用 cover+steps+highlight 讲清楚的事，不新加版式
4. **新加版式必须走 Canvas 登记**（禁 `register=False` 脱管——三道闸会失效）
5. **新加版式后必须 120 组合冒烟 + --e2e 端到端双方向验证**
6. **新加风格必须加进 styles.py STYLES + 跑冒烟 + 写进本手册"风格矩阵"**

---

_本手册从 `framework/canvas.py`、`styles.py`、`backgrounds.py`、`audio.py`、`layouts.py` 实测提取。_
_2026-09-08 建立。后续新发现/新参数变化必须回写本文件（不只记在对话里）。_
