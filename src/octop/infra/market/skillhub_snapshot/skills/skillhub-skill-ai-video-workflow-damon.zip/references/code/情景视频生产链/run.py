#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
船海情景视频 —— 单入口编排器 (v2: 支持旁白/对话、中英口播、图片清单)

一条命令走完:
  引擎出文案(中英) -> 拆分镜 -> 出图片清单 -> 投喂图接入 -> 素材库复用
  -> 缺图/缺翻译检查 -> 配音 -> 合成 mp4

用法:
  python run.py hse lifting_stop                         # 横屏, 旁白中文, 自动找图
  python run.py hse lifting_stop --vertical              # 竖屏 9:16
  python run.py hse lifting_stop --mode dialogue --lang en   # 双人对话, 英语口播
  python run.py hse lifting_stop --mode dialogue --plan    # 只出分镜+图片清单, 等给图
  python run.py hse lifting_stop --images "D:/我的图"      # 用我喂的图
  python run.py hse lifting_stop --no-reuse --voice zh-CN-XiaoxiaoNeural

看有哪些情景可选:
  node pipeline/list_scenarios.js

取图优先级(自动):
  1) 我投喂的图   assets/inbox/<工程名>/ 或 assets/inbox/ 或 --images 指定目录
  2) 素材库复用   assets/library/
  3) AI 生图      仅剩下的镜, 清单写进 projects/<工程>/images_needed.json

成片输出: projects/<工程>/<工程>[_对话][_英语][_竖屏].mp4,
  并自动复制到 D:/微信小程序/情景视频存放处/ (见 pipeline/config.json 的 outputs_dir)
"""
import os, sys, json, argparse, subprocess

ROOT = os.path.dirname(os.path.abspath(__file__))
CFG = json.load(open(os.path.join(ROOT, 'pipeline', 'config.json'), encoding='utf-8'))
PY, NODE = CFG['python'], CFG['node']

ASPECT_ALIAS = {
    '横屏': '16:9', '横': '16:9', 'h': '16:9', 'landscape': '16:9', '16x9': '16:9',
    '竖屏': '9:16', '竖': '9:16', 'v': '9:16', 'portrait': '9:16', '9x16': '9:16',
    '方': '1:1', 'square': '1:1', '1x1': '1:1',
}


def run(cmd, title):
    print('\n' + '=' * 60)
    print('▶ ' + title)
    print('=' * 60)
    r = subprocess.run(cmd, cwd=ROOT)
    if r.returncode != 0:
        sys.exit('步骤失败: ' + title)


def translate_pending(path):
    """translate_needed.json 里是否还有未填的中文。"""
    if not os.path.exists(path):
        return []
    data = json.load(open(path, encoding='utf-8'))
    return [x['idx'] for x in data if not str(x.get('zh') or '').strip()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('domain')
    ap.add_argument('key')
    ap.add_argument('--platform', default='offshore')
    ap.add_argument('--project', default=None)

    # 画幅: --aspect 16:9 / 9:16 / 1:1, 或直接 --vertical / --horizontal
    ap.add_argument('--aspect', default=CFG.get('default_aspect', '16:9'),
                    help='16:9 | 9:16 | 1:1 (也认 横屏/竖屏/portrait/landscape)')
    ap.add_argument('--vertical', action='store_true', help='竖屏 9:16')
    ap.add_argument('--horizontal', action='store_true', help='横屏 16:9 (默认)')

    # 模式 / 口播语言 (新增)
    ap.add_argument('--mode', default=None, choices=['narration', 'dialogue'],
                    help='narration=旁白讲解(默认), dialogue=双人对话')
    ap.add_argument('--lang', default=None, choices=['zh', 'en'],
                    help='口播语言: zh 中文 / en 英语; dialogue 模式默认 en')

    # plan 模式 (新增): 出分镜 + 图片清单后停下, 让用户先准备图 / 填翻译
    ap.add_argument('--plan', action='store_true',
                    help='只出分镜和图片清单, 不合成(等你给图/填翻译)')

    # 投喂图
    ap.add_argument('--images', default=None,
                    help='我的图所在目录; 不填则自动找 assets/inbox/')
    ap.add_argument('--no-ingest', action='store_true', help='忽略投喂图')
    ap.add_argument('--keep-inbox', action='store_true', help='投喂图用完不搬走')
    ap.add_argument('--overwrite-images', action='store_true',
                    help='投喂图覆盖工程里已有的图')

    ap.add_argument('--voice', default=None, help='旁白音色(默认按 --lang 从 config 取)')
    ap.add_argument('--voice-a', default=None, help='对话角色 A 音色')
    ap.add_argument('--voice-b', default=None, help='对话角色 B 音色')
    ap.add_argument('--bgm', default=None)
    ap.add_argument('--no-reuse', action='store_true', help='不复用素材库, 全部重新生图')
    ap.add_argument('--min-score', type=int, default=3)
    ap.add_argument('--skip-scenes', action='store_true',
                    help='跳过重新拆分镜(已手工改过 scenes.json 时用)')

    # PPT 模式: PPT 每页变图 + 脚本文案 -> 双语视频
    ap.add_argument('--ppt', default=None, help='PPT/PPTX 文件; 给定后走 PPT->视频 流程')
    ap.add_argument('--script', default=None, help='PPT 配套脚本文案(.txt/.json)')
    ap.add_argument('--title', default='', help='PPT 视频标题(片头卡用)')
    a = ap.parse_args()

    aspect = ASPECT_ALIAS.get(str(a.aspect).lower(), a.aspect)
    if a.vertical:
        aspect = '9:16'
    if a.horizontal:
        aspect = '16:9'
    if aspect not in ('16:9', '9:16', '1:1'):
        sys.exit('画幅只支持 16:9 / 9:16 / 1:1, 收到: ' + str(a.aspect))
    sfx = {'16:9': '', '9:16': '_竖屏', '1:1': '_方屏'}[aspect]

    proj = a.project or f'{a.domain}_{a.key}'
    proj_dir = os.path.join(ROOT, 'projects', proj)

    # ---------- PPT 模式 ----------
    if a.ppt:
        if not a.script:
            sys.exit('--ppt 需要配合 --script <脚本.txt/.json>')
        lang = a.lang or 'en'
        run([PY, 'pipeline/ppt_to_images.py', '--ppt', a.ppt,
             '--project', proj, '--aspect', aspect],
            '1/3 PPT 每页导出为图')
        cmd = [PY, 'pipeline/make_ppt_scenes.py', '--project', proj,
               '--script', a.script, '--lang', lang, '--aspect', aspect]
        if a.title:
            cmd += ['--title', a.title]
        run(cmd, '2/3 脚本 + 图 -> scenes.json (双语字幕)')
        b = [PY, 'pipeline/build_video.py', '--project', proj,
             '--aspect', aspect, '--lang', lang]
        if a.voice:
            b += ['--voice', a.voice]
        if a.bgm:
            b += ['--bgm', a.bgm]
        run(b, '3/3 配音(免费 edge-tts) + ffmpeg 合成 [%s]' % aspect)
        print('\n✅ PPT 视频完成: %s%s.mp4  [%s, 英语口播+中英双语字幕]'
              % (proj, sfx, aspect))
        print('   已存入: %s' % CFG['outputs_dir'])
        return

    # 1. 引擎出文案 + 自动拆分镜
    if not a.skip_scenes:
        cmd = [NODE, 'pipeline/make_scenes.js', a.domain, a.key, a.platform,
               '--project', proj]
        if a.mode:
            cmd += ['--mode', a.mode]
        if a.lang:
            cmd += ['--lang', a.lang]
        run(cmd, '1/6 引擎出文案(中英双语) + 自动拆分镜')

    # 2. 生成图片清单 (提前提示用户需要哪些图)
    if not a.skip_scenes:
        run([PY, 'pipeline/shotlist.py', '--project', proj], '2/6 生成图片清单')

    # plan 模式: 出完清单就停, 等用户给图/填翻译
    if a.plan:
        shotlist = os.path.join(proj_dir, '图片清单.md')
        tpath = os.path.join(proj_dir, 'translate_needed.json')
        print('\n' + '!' * 60)
        print('【--plan 模式】分镜和图片清单已生成, 尚未合成。')
        print('  图片清单:', shotlist)
        if os.path.exists(tpath):
            missing = translate_pending(tpath)
            print('  待补中文字幕: %d 条 -> %s' % (len(missing), tpath))
            print('  填好后跑: node pipeline/apply_zh.js --project %s' % proj)
        print('  补齐图片/字幕后, 重跑(跳过拆镜):')
        resume = ['python', 'run.py', a.domain, a.key, '--skip-scenes', '--aspect', aspect]
        if a.mode:
            resume += ['--mode', a.mode]
        if a.lang:
            resume += ['--lang', a.lang]
        print('   ', ' '.join(resume))
        print('!' * 60)
        return

    # 3. 投喂图优先接入
    if not a.no_ingest:
        cmd = [PY, 'pipeline/ingest_images.py', '--project', proj]
        if a.images:
            cmd += ['--images', a.images]
        if a.keep_inbox:
            cmd += ['--keep-inbox']
        if a.overwrite_images:
            cmd += ['--overwrite']
        run(cmd, '3/6 接入我投喂的图(有就优先用)')

    # 4. 素材库复用
    if not a.no_reuse:
        run([PY, 'pipeline/reuse_assets.py', '--project', proj,
             '--min-score', str(a.min_score)], '4/6 素材库复用(省生图消耗)')

    # 5. 缺图检查
    needed_path = os.path.join(proj_dir, 'images_needed.json')
    needed = json.load(open(needed_path, encoding='utf-8')) if os.path.exists(needed_path) else []
    needed = [n for n in needed
              if not os.path.exists(os.path.join(proj_dir, 'images', n['image_file']))]
    if needed:
        print('\n' + '!' * 60)
        print('还缺 %d 张图, 无法合成。两条路二选一:' % len(needed))
        print('  A. 我自己给图 -> 丢进 %s 再重跑'
              % os.path.join(ROOT, 'assets', 'inbox', proj))
        print('  B. 让 AI 生图 -> 按图片清单生成后放入 %s'
              % os.path.join(proj_dir, 'images'))
        print('!' * 60)
        for n in needed:
            print('\n[%02d] %s' % (n['idx'], n['image_file']))
            print(n['prompt'])
        print('\n补齐后重跑(跳过拆分镜以保留分镜):')
        resume = ['python', 'run.py', a.domain, a.key, '--skip-scenes', '--aspect', aspect]
        if a.mode:
            resume += ['--mode', a.mode]
        if a.lang:
            resume += ['--lang', a.lang]
        print('   ', ' '.join(resume))
        sys.exit(2)

    # 6. 对话片: 检查并回填中文字幕
    tpath = os.path.join(proj_dir, 'translate_needed.json')
    if os.path.exists(tpath):
        missing = translate_pending(tpath)
        if missing:
            print('\n' + '!' * 60)
            print('对话片有中文字幕待填写: 第 %s 镜' % ', '.join(map(str, missing)))
            print('文件:', tpath)
            print('填好后跑: node pipeline/apply_zh.js --project %s' % proj)
            print('!' * 60)
            sys.exit(3)
        run([NODE, 'pipeline/apply_zh.js', '--project', proj], '5/6 回填中文字幕')

    # 7. 配音 + 合成
    cmd = [PY, 'pipeline/build_video.py', '--project', proj, '--aspect', aspect]
    if a.voice:
        cmd += ['--voice', a.voice]
    if a.voice_a:
        cmd += ['--voice-a', a.voice_a]
    if a.voice_b:
        cmd += ['--voice-b', a.voice_b]
    if a.bgm:
        cmd += ['--bgm', a.bgm]
    if a.lang:
        cmd += ['--lang', a.lang]
    run(cmd, '6/6 配音(edge-tts 免费) + ffmpeg 合成 [%s]' % aspect)

    print('\n✅ 完成: %s%s.mp4  [%s]' % (proj, sfx, aspect))
    print('   已存入: %s' % CFG['outputs_dir'])


if __name__ == '__main__':
    main()
