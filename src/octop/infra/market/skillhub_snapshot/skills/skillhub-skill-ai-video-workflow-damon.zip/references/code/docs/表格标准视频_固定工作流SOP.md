# 表格类标准讲解视频 · 固定工作流（SOP）

> 适用范围：所有「标准/规范 + 表格」类讲解视频（如 AWS D1.1 Table 6.10、ASME B31.3 Table 341.3.2，以及未来任何新标准）。
> 原则：**只做安全加法、不重构渲染数学；先验证，再做（交付）。**
> 本文件为唯一权威 SOP，取代各工作流内零散的「红线与检查清单」。

---

## 〇、铁律（先验证，再做）

1. **改坐标 / 字号 / 文案之前，先跑 `plan_change.py` 预判**会不会挡别处、出不出画框。只读，不落盘。
2. **渲染之前，先跑 `layout_guard.py`**，必须返回 `OK — no overlapping UI elements detected.`。
3. **渲染之后、覆盖正式文件之前，必须抽帧 + SSIM 核对**：与已知良好成片 `SSIM==1.000000` 或关键时间点（开场 / 卡片弹出 / 总结页）无乱码·无遮挡·无截断，才允许覆盖。
4. **原渲染脚本（`render_*.py` 的 `draw_*`）一字不改**；加速 / 预判 / 校验都做成外围工具（见第五节）。

---

## 一、问题台账（都记下来，固化）

| # | 问题 | 根因 | 固化方案（已落地） | 验证方式 |
|---|------|------|-------------------|----------|
| 1 | **中文方块 / 乱码（tofu）** | 用英文字体（Arial）渲染中文 | `get_font` 分 `cn_b`/`cn`（微软雅黑）与 `en_b`/`en`（Arial）；禁止英文渲染中文 | 抽帧看无 □；`layout_guard` 不报字体错 |
| 2 | **字幕 / 文字遮挡** | 字幕距卡片底仅 ~17px；上下分层行距算错；标签框重叠 | `plan_change` 把字幕当**纯文字块**判遮挡（无框也查）；`layout_guard` 查框级+框内；卡片底 968、字幕顶 984（安全上移上限 11px） | `plan_change` 预判 + `layout_guard` OK + 抽帧 |
| 3 | **截图 / 表不全（缺表头）** | 底图未含表头；`row_bbox` 按整行而非真实中心 | 底图 `img_size` 含表头；`row_bbox` 按实测行中心重算；高亮框 `clamp` 在表框内 | 抽帧确认表头完整、高亮行正确 |
| 4 | **中英左右并排重复** | 框内双语左右排，视觉像两份 | 全改**上下分层**（中文在上、英文在下小字） | 抽帧确认无左右重复 |
| 5 | **标签命名混乱**（裂纹类/表面类/显示类） | 分类维度混用 | 固定为「按检验方法」：禁止 Not Permitted / 射线检验 Radiographic / 目视检验 Visual | 抽帧确认命名清晰 |
| 6 | **开场 scene 0 漏渲** | 分批渲染漏场景 | 渲染前确认 `seg` 数 == 场景数；全部场景批量渲染 | 检查 seg 文件数 == SCENES 数 |
| 7 | **生成太慢（~11 分钟）** | 全量串行 + 编码档默认最慢 medium | `render_fast.py`：多核并行 + `-preset veryfast`（保留 `-crf 18`）+ 按场景缓存 | 8 核实测 4m39s，快 2.4 倍，SSIM=1.0 |
| 8 | **长进程被中断** | 单进程长跑被杀 | 每场景独立子进程（画帧+编码），不走管道（防死锁） | 渲染稳定完成 |

---

## 二、标准流程（6 步，固定顺序）

1. **准备资产**
   - 表底图（**必须含表头**），记录 `img_size` / `TABLE_FRAME` / `ROW_BBOX`（按真实行中心）。
   - 背景图逻辑（如需工业风）：参考船海 HUD 皮肤 `build_bg()`（暗化+网格），**仅做背景层，不搬对话框/水印**。
2. **写 / 改 `SCENES` 文案**（双语 `caption` / `caption_en` / `spoken`）。
   - ⚠️ 任何坐标 / 字号 / 文案改动前，先跑 `plan_change.py --scene N --shift ... / --grow ...` 预判。
3. **跑 `layout_guard.py`** → 必须 `OK`。
4. **渲染**：`python render_fast.py --workers 8`（输出正式文件；验证用可加 `--out 独立路径`）。
5. **验证门 GATE 2**：抽帧（开场 / 卡片 / 总结）+ `ffmpeg SSIM` 与已知良好成片比对 → 必须 `SSIM==1.000000` 或关键帧无问题，**通过才覆盖正式文件**。
6. **交付**：贴绝对路径给用户；记一笔工作日志（`.workbuddy/memory/YYYY-MM-DD.md`）。

---

## 三、验证门（GATE 0 / 1 / 2）

- **GATE 0 · 改前预判（plan_change.py，只读）**
  ```
  python plan_change.py --scene 2 --shift 40     # 字幕上移 40px 会不会挡？
  python plan_change.py --scene 2 --grow 30      # 字幕增高 30px 会不会被切？
  python plan_change.py --scene 2 --safe          # 只算字幕安全上移上限
  ```
  输出：各元素真实包围盒 + 是否遮挡 + 是否出画框 + 安全上限 + 修改建议。**绝不落盘。**
- **GATE 1 · 渲染前布局校验（layout_guard.py）**
  ```
  python layout_guard.py
  ```
  必须 `OK — no overlapping UI elements detected.`（查 intro / summary / defect 三帧的框级 + 框内文字重叠）。
- **GATE 2 · 渲染后像素核对（抽帧 + SSIM）**
  ```
  ffmpeg -i 新版.mp4 -i 已知良好.mp4 -lavfi "[0:v]scale=1280:720[a];[1:v]scale=1280:720[b];[a][b]ssim" -f null -
  ```
  必须 `All:1.000000`。否则不覆盖正式文件，回查 GATE 0/1。

---

## 四、适配新标准（换标准只换配置，不换引擎）

1. 复制 `render_fast.py` / `plan_change.py` / `layout_guard.py` 到新标准工作流的 `render/` 目录。
2. 把脚本里的 `import render_table_walkthrough_l_pos_en as R` 改为新标准的渲染模块名。
3. 提供新标准的：表底图（含表头）、`ROW_BBOX`、`SCENES`（双语文案）、背景图（可选）。
4. 跑 GATE 0 → 1 → 2，全过再交付。

> 当前已固化工具位置：
> - `标准讲解视频工作流/render/render_fast.py`、`plan_change.py`
> - `Fig341.3.2视频工作流/render/layout_guard.py`
> 未来每个标准工作流都应自备这三件套（复制并改 import 指向）。

---

## 五、工具清单（均为外围工具，不改原 `draw_*`）

| 工具 | 作用 | 是否落盘 |
|------|------|----------|
| `render_fast.py` | 多核并行 + veryfast + 按场景缓存，画面像素级不变 | 出片（覆盖前需过 GATE 2） |
| `plan_change.py` | 改前预判遮挡 / 出框，给安全上限 | **只读，不落盘** |
| `layout_guard.py` | 渲染前自动检测 UI 重叠（框级+框内） | **只读，不落盘** |

---

## 六、红线（不可逾越）

- 不重构原渲染脚本；只加外围工具。
- 中文必须用 `cn` 字体，英文用 `en` 字体。
- 双语一律上下分层，不左右并排。
- 表底图必须含表头；高亮框 clamp 在表框内。
- **未过 GATE 0/1/2，绝不覆盖正式成片。**
