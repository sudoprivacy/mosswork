#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
素材库复用器 —— 让重复出片趋近零成本。

按 scenes.json 里每镜的英文旁白/图像提示词, 与 assets/library/manifest.json
的标签做匹配打分, 命中就直接复用库里的图, 只把真正匹配不到的写进
images_needed.json 交给生图环节。

用法:
  python pipeline/reuse_assets.py --project quality_coating_inspection
  python pipeline/reuse_assets.py --project xxx --min-score 2   # 放宽复用
  python pipeline/reuse_assets.py --project xxx --dry-run       # 只看匹配结果
"""
import os, re, json, shutil, argparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB_DIR = os.path.join(ROOT, 'assets', 'library')
MANIFEST = os.path.join(LIB_DIR, 'manifest.json')


def tokens(text):
    text = text.lower()
    en = re.findall(r'[a-z]{3,}', text)
    zh = re.findall(r'[\u4e00-\u9fff]{2,}', text)
    return set(en) | set(zh)


def score(scene, asset):
    """标签命中计分: 英文整词命中 2 分, 中文子串命中 2 分, 描述词命中 1 分。"""
    hay = ' '.join([scene.get('narration_en', ''), scene.get('image_prompt', ''),
                    scene.get('caption_en', '')]).lower()
    hay_zh = ' '.join([scene.get('narration_zh', ''), scene.get('caption_zh', '')])
    s = 0
    for t in asset.get('tags', []):
        tl = t.lower()
        if re.search(r'[\u4e00-\u9fff]', t):
            if t in hay_zh:
                s += 2
        elif re.search(r'\b' + re.escape(tl) + r'\w{0,3}\b', hay):
            s += 2
    for w in tokens(asset.get('desc', '')):
        if w in hay or w in hay_zh:
            s += 1
    return s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', required=True)
    ap.add_argument('--min-score', type=int, default=3,
                    help='低于此分不复用, 转为待生图 (默认3, 越低越省钱但越不贴题)')
    ap.add_argument('--allow-repeat', action='store_true',
                    help='允许同一张图在一条片里重复使用')
    ap.add_argument('--dry-run', action='store_true')
    a = ap.parse_args()

    proj = os.path.join(ROOT, 'projects', a.project)
    sj = os.path.join(proj, 'scenes.json')
    if not os.path.exists(sj):
        raise SystemExit('找不到 ' + sj)
    data = json.load(open(sj, encoding='utf-8'))
    lib = json.load(open(MANIFEST, encoding='utf-8'))['assets']

    img_dir = os.path.join(proj, 'images')
    os.makedirs(img_dir, exist_ok=True)

    reused, needed = [], []

    # 待分配的镜(已有图的跳过)
    todo = []
    for sc in data['scenes']:
        if os.path.exists(os.path.join(img_dir, sc['image_file'])):
            reused.append((sc['idx'], '(已存在)', '-'))
        else:
            todo.append(sc)

    # 全局最优分配: 把所有(镜,素材)配对按分数从高到低贪心占位,
    # 避免"靠前的镜先抢走高价值素材"导致真正贴题的镜没图。
    pairs = []
    for sc in todo:
        for x in lib:
            s = score(sc, x)
            if s >= a.min_score:
                pairs.append((s, sc['idx'], x))
    pairs.sort(key=lambda t: -t[0])

    assign, used = {}, set()
    for s, idx, x in pairs:
        if idx in assign:
            continue
        if x['file'] in used and not a.allow_repeat:
            continue
        assign[idx] = (s, x)
        used.add(x['file'])

    best_of = {sc['idx']: max([score(sc, x) for x in lib] or [0]) for sc in todo}
    for sc in todo:
        idx = sc['idx']
        if idx in assign:
            s, x = assign[idx]
            reused.append((idx, x['file'], s))
            if not a.dry_run:
                shutil.copy(os.path.join(LIB_DIR, x['file']),
                            os.path.join(img_dir, sc['image_file']))
        else:
            needed.append({'idx': idx, 'image_file': sc['image_file'],
                           'prompt': sc['image_prompt'],
                           'best_score': best_of[idx]})
    reused.sort(key=lambda t: t[0])

    print('=== 复用结果 (min-score=%d) ===' % a.min_score)
    for idx, f, s in reused:
        print('  [%02d] 复用 %-32s 得分 %s' % (idx, f, s))
    print('=== 仍需生图 %d 张 ===' % len(needed))
    for n in needed:
        print('  [%02d] %s  (最高分 %d)' % (n['idx'], n['image_file'], n['best_score']))
        print('       %s' % n['prompt'][:150])

    if not a.dry_run:
        json.dump(needed, open(os.path.join(proj, 'images_needed.json'), 'w',
                               encoding='utf-8'), ensure_ascii=False, indent=2)
        print('\n待生图清单已更新: projects/%s/images_needed.json' % a.project)
        print('省下 %d 张生图消耗。' % len(reused))


if __name__ == '__main__':
    main()
