#!/usr/bin/env python3
# 竖屏逐句字幕生成（顺序无关 · 真实位置对齐版）
# 核心修正：豆包生成的对白经常不按脚本顺序，不能 1:1 顺序映射。
# 本脚本用 edge-tts 给每句生成参考音频，与源视频音频做能量包络互相关，
# 把每句字幕钉在其【真实出现位置】（相关系数通常 0.9+），彻底解决"字幕对不上发音"。
#
# 用法：
#   python gen_vertical_sentences.py                # 默认处理 hvac_07（演示）
#   python gen_vertical_sentences.py --video X.mp4 --json clauses.json --out out.ass
#   clauses.json: [{"en":"...","cn":"..."}, ...]
#
# 铁律（与横屏工作流一致，不动）：英上中下、无黑幕、Shadow=2、Outline=3、
#   WrapStyle=1、MarginL/R=60、Alignment=2、竖屏 PlayRes 1080x1920。
#   提示词逻辑不在此脚本范围内（见豆包提示词包_*.md）。
import os, sys, json, wave, struct, subprocess, asyncio
import edge_tts

HERE = os.path.dirname(os.path.abspath(__file__))
FF = "C:/Users/Damon/.workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"
VOICE = "en-US-GuyNeural"

# 默认演示：hvac_07 原文（englishContent / chineseContent 按逗号/句号拆分）
DEFAULT_VIDEO = os.path.join(HERE, "..", "hvac", "hvac_07_对话_英语_竖屏.mp4")
DEFAULT_OUT = os.path.join(HERE, "hvac_07_test.ass")
EN = [
    "Silencing and vibration isolation hold point.",
    "Confirm the silencer direction and the isolation hangers.",
    "Silencer installed with the flow arrow correct,",
    "isolation hangers on the fan and the duct near it.",
    "The silencer is upstream of the fan as drawn.",
    "But the duct is hard-coupled to the structure at this bracket — add an isolation hanger there.",
    "We will fit the isolation hanger and break the rigid link.",
    "Good.",
    "No rigid path to the structure.",
    "After the fix I sign the silencing and isolation.",
    "Hanger fitted, rigid link removed.",
    "Tagged as done.",
    "Good.",
    "Silencing and isolation accepted.",
    "Punch, rigid coupling.",
]
CN = [
    "消声与减震停止点。", "确认消声器方向与减震吊架。", "消声器按流向箭头装对，",
    "风机及邻近风管装了减震吊架。", "消声器在风机上游，与图一致。",
    "但这处支架把风管硬接到了结构——那里加减震吊架。", "我们装减震吊架、断开刚性连接。",
    "好。", "无通向结构的刚性传声路径。", "整改后我签消声与减震。",
    "吊架装好、刚性连接断开。", "标了完成。", "好。", "消声与减震接受。", "尾项，刚性连接。",
]

LEAD = 0.20
MIN_DUR = 0.80

def extract_audio(video, wav):
    subprocess.run([FF, "-y", "-i", video, "-vn", "-acodec", "pcm_s16le",
                    "-ar", "16000", "-ac", "1", wav], capture_output=True)

def envelope(wav_path):
    w = wave.open(wav_path, "rb"); n = w.getnframes(); sr = w.getframerate()
    raw = w.readframes(n); samples = struct.unpack("<" + "h" * n, raw)
    win = int(sr * 0.05)
    env = []
    for i in range(0, n, win):
        seg = samples[i:i + win]
        env.append((sum(x * x for x in seg) / len(seg)) ** 0.5 if seg else 0.0)
    k = 3; sm = []
    for i in range(len(env)):
        a, b = max(0, i - k), min(len(env), i + k + 1)
        sm.append(sum(env[a:b]) / (b - a))
    return sm

def norm(v):
    m = max(v) or 1
    return [x / m for x in v]

def ncc(a, b):
    na, nb = norm(a), norm(b)
    dot = sum(x * y for x, y in zip(na, nb))
    return dot / ((sum(x * x for x in na) ** 0.5) * (sum(x * x for x in nb) ** 0.5) + 1e-9)

async def gen_tts(idx, text, out_wav):
    mp3 = out_wav[:-4] + ".mp3"
    if not os.path.exists(mp3):
        await edge_tts.Communicate(text, VOICE).save(mp3)
    subprocess.run([FF, "-y", "-i", mp3, "-vn", "-acodec", "pcm_s16le",
                    "-ar", "16000", "-ac", "1", out_wav], capture_output=True)

def wrap_cn(s, n=18):
    return "\\N".join(s[i:i + n] for i in range(0, len(s), n))

def wrap_en(s, n=38):
    if len(s) <= n: return s
    words = s.split(" "); lines = []; cur = ""
    for wd in words:
        if cur and len(cur) + 1 + len(wd) > n: lines.append(cur); cur = wd
        else: cur = (cur + " " + wd).strip()
    if cur: lines.append(cur)
    return "\\N".join(lines)

def s2ass(t):
    h = int(t // 3600); m = int((t % 3600) // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"

async def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", default=DEFAULT_VIDEO)
    ap.add_argument("--json", default=None, help="[{en,cn},...]")
    ap.add_argument("--out", default=DEFAULT_OUT)
    args = ap.parse_args()

    if args.json:
        data = json.load(open(args.json, encoding="utf-8"))
        EN_ = [d["en"] for d in data]; CN_ = [d["cn"] for d in data]
    else:
        EN_ = EN; CN_ = CN  # 默认 hvac_07 演示

    wav = os.path.join(HERE, "_align_src.wav")
    extract_audio(args.video, wav)
    venv = envelope(wav)

    items = []
    for i, text in enumerate(EN_):
        twav = os.path.join(HERE, f"_align_{i}.wav")
        await gen_tts(i, text, twav)
        tenv = envelope(twav)
        Lv, Lt = len(venv), len(tenv)
        best_lag, best = 0, -1
        for lag in range(0, Lv - Lt):
            sc = ncc(venv[lag:lag + Lt], tenv)
            if sc > best: best, best_lag = sc, lag
        items.append({"i": i, "pos": best_lag * 0.05, "score": best})
    items.sort(key=lambda x: x["pos"])

    lines = [
        "[Script Info]", "ScriptType: v4.00+", "PlayResX: 1080", "PlayResY: 1920",
        "WrapStyle: 1", "", "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        "Style: Default,Microsoft YaHei,40,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,3,2,2,60,60,30,1",
        "", "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    for k, it in enumerate(items):
        start = max(0.0, it["pos"] - LEAD)
        end = items[k + 1]["pos"] - LEAD if k + 1 < len(items) else start + 3.0
        if end - start < MIN_DUR: end = start + MIN_DUR
        text = wrap_en(EN_[it["i"]]) + "\\N" + wrap_cn(CN_[it["i"]])
        lines.append("Dialogue: 0,%s,%s,Default,,0,0,0,,%s" % (s2ass(start), s2ass(end), text))
        print("%2d  真实%.2fs 相关%.3f %s" % (it["i"] + 1, it["pos"], it["score"], EN_[it["i"]][:38]))
    open(args.out, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print("已生成:", args.out, " 共 %d 句（按真实位置，顺序无关）" % len(EN_))

if __name__ == "__main__":
    asyncio.run(main())
