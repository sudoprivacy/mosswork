# -*- coding: utf-8 -*-
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import render_asme_b31_3_table341_3_2 as R
import shutil

def main():
    tmp = r"C:\wb_tmp_concat"
    if os.path.exists(tmp):
        shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp, exist_ok=True)
    seg_mp4s = []
    for i in range(len(R.SCENES)):
        src = os.path.join(R.FRAMES_DIR, f"seg_{i:02d}.mp4")
        if not os.path.exists(src):
            print(f"missing segment: {src}")
            return 1
        dst = os.path.join(tmp, os.path.basename(src))
        shutil.copy2(src, dst)
        seg_mp4s.append(dst)
    concat_file = os.path.join(tmp, "concat.txt")
    with open(concat_file, "w", encoding="utf-8") as cf:
        for mp4 in seg_mp4s:
            cf.write(f"file '{mp4.replace(chr(92), '/')}'\n")
    final = os.path.join(R.OUT_DIR, "asme_b31_3_table341_3_2_walkthrough.mp4")
    cmd = [
        R.FFMPEG, "-y",
        "-f", "concat", "-safe", "0", "-i", concat_file,
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
        "-c:a", "aac", "-b:a", "160k",
        "-movflags", "+faststart",
        final
    ]
    subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8", errors="ignore")
    shutil.rmtree(tmp, ignore_errors=True)
    print("final:", final)
    return 0

if __name__ == "__main__":
    sys.exit(main())
