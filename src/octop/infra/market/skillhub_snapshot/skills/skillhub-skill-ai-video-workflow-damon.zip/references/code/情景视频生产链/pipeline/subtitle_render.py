#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
字幕 PNG 渲染器 (PIL)
- 统一描边 + 投影, 不再依赖 ffmpeg drawtext 的边框
- 支持同一句内专业词高亮: 字号放大、颜色突出
- 支持多种字体/配色风格预设
"""
import os, re, json
from PIL import Image, ImageDraw, ImageFont

FONT_CACHE = {}


def _resolve_font(style, lang):
    """按语言选字体; 找不到就回退黑体。"""
    path = style.get('font_zh') if lang == 'zh' else style.get('font')
    if not path or not os.path.exists(path):
        path = style.get('font')
    if not path or not os.path.exists(path):
        path = 'C:/Windows/Fonts/simhei.ttf'
    return path


def get_font(style, size, lang):
    path = _resolve_font(style, lang)
    key = (path, size)
    if key not in FONT_CACHE:
        try:
            FONT_CACHE[key] = ImageFont.truetype(path, size, index=0)
        except Exception:
            FONT_CACHE[key] = ImageFont.truetype('C:/Windows/Fonts/simhei.ttf', size, index=0)
    return FONT_CACHE[key]


def hex_to_rgba(hex_color, alpha=255):
    hex_color = hex_color.lstrip('#')
    if len(hex_color) == 3:
        hex_color = ''.join([c * 2 for c in hex_color])
    return (int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16), alpha)


def text_metrics(text, font):
    """返回 (width, ascent, descent, line_height)。"""
    try:
        bbox = font.getbbox(text)
    except Exception:
        bbox = None
    if bbox:
        left, top, right, bottom = bbox
        ascent = -top
        descent = bottom
    else:
        ascent = int(font.size * 0.88)
        descent = int(font.size * 0.22)
    try:
        width = font.getlength(text)
    except Exception:
        width = (bbox[2] - bbox[0]) if bbox else ascent * len(text)
    return width, ascent, descent, ascent + descent


def segment_line(text, keywords, lang):
    """把一句字幕按关键词切成普通段/高亮段。

    keywords: set/list of strings
    lang: 'en' 按词边界大小写不敏感匹配; 'zh' 按子串匹配(优先长词)
    返回 [(subtext, is_keyword), ...]
    """
    if not keywords or not text:
        return [(text, False)]
    kw_list = sorted(keywords, key=len, reverse=True)
    if not kw_list:
        return [(text, False)]
    if lang == 'en':
        pattern = re.compile(
            r'(?<!\w)(?:' + '|'.join(re.escape(k) for k in kw_list) + r')(?!\w)',
            re.IGNORECASE)
    else:
        pattern = re.compile('|'.join(re.escape(k) for k in kw_list))
    segments = []
    last = 0
    for m in pattern.finditer(text):
        if m.start() > last:
            segments.append((text[last:m.start()], False))
        segments.append((m.group(), True))
        last = m.end()
    if last < len(text):
        segments.append((text[last:], False))
    return segments


def _measure_line(segments, base_fs, lang, style):
    """度量一行(含高亮分段)的总宽与行高。"""
    max_ascent = 0
    max_descent = 0
    total_w = 0.0
    seg_info = []
    scale = style.get('highlight_scale', 1.25)
    for text, is_kw in segments:
        fs = int(round(base_fs * (scale if is_kw else 1.0)))
        font = get_font(style, fs, lang)
        w, asc, desc, h = text_metrics(text, font)
        max_ascent = max(max_ascent, asc)
        max_descent = max(max_descent, desc)
        total_w += w
        seg_info.append({
            'text': text, 'is_kw': is_kw, 'font_size': fs,
            'width': w, 'ascent': asc, 'descent': desc,
        })
    line_h = max_ascent + max_descent
    return total_w, line_h, max_ascent, max_descent, seg_info


def measure_line_width(text, keywords, base_fs, lang, style):
    """度量一行含高亮放大后的真实总宽(供自动适配判断单行是否超宽)。"""
    segs = segment_line(text, keywords, lang)
    total_w, _, _, _, _ = _measure_line(segs, base_fs, lang, style)
    return total_w


def _draw_segments(draw, start_x, baseline_y, seg_info, line_color, style, lang):
    outline_w = int(style.get('outline_width', 5))
    outline_color = style.get('outline_color', '#000000')
    shadow = style.get('shadow', True)
    sx, sy = style.get('shadow_offset', (3, 3))
    shadow_alpha = int(style.get('shadow_alpha', 140))
    outline_rgba = hex_to_rgba(outline_color)
    shadow_rgba = hex_to_rgba(outline_color, shadow_alpha)
    highlight_color = style.get('highlight_color', '#40C4FF')

    for seg in seg_info:
        font = get_font(style, seg['font_size'], lang)
        color = highlight_color if seg['is_kw'] else line_color
        fill_rgba = hex_to_rgba(color)
        x = start_x
        if shadow:
            draw.text((x + sx, baseline_y + sy), seg['text'], font=font,
                      fill=shadow_rgba, anchor='ls')
        draw.text((x, baseline_y), seg['text'], font=font, fill=fill_rgba,
                  anchor='ls', stroke_width=outline_w, stroke_fill=outline_rgba)
        start_x += seg['width']


def layout_and_render(W, H, style, lines, use_lb=False, lb_bottom=0,
                      inner_gap=6, block_gap=12, name_gap=8,
                      base_margin=16, v_center=False,
                      out_path=None):
    """字幕布局 + 渲染。

    lines: 从上到下的行列表, 每项 dict:
        {
          'text': str,
          'lang': 'en' | 'zh',
          'base_fs': int,           # 普通字号
          'color': '#RRGGBB',       # 普通颜色
          'keywords': set,          # 要高亮的关键词(空则不高亮)
          'anchor': 'ls'|'ms'|'rs', # 水平对齐: 左/中/右
          'x': int/float,           # 对齐参考点
          'group': 'name'|'pri'|'sec'
        }
    若 out_path 为 None, 只测量不渲染, 返回 (total_height, None)。
    """
    measured = []
    for ln in lines:
        segs = segment_line(ln['text'], ln.get('keywords', set()), ln['lang'])
        total_w, line_h, asc, desc, seg_info = _measure_line(
            segs, ln['base_fs'], ln['lang'], style)
        measured.append({
            'line': ln,
            'segs': seg_info,
            'line_h': line_h,
            'ascent': asc,
            'descent': desc,
            'total_w': total_w,
        })

    # 总高度(含行间距)
    total_h = 0
    prev_group = None
    for m in measured:
        if prev_group is not None:
            if m['line']['group'] == prev_group:
                total_h += inner_gap
            elif prev_group == 'name' and m['line']['group'] == 'pri':
                total_h += name_gap
            else:
                # pri -> sec 或任何跨组
                total_h += block_gap
        total_h += m['line_h']
        prev_group = m['line']['group']

    # 底边位置
    if use_lb:
        spare = max(base_margin, (lb_bottom - total_h) // 2)
        base_bottom = H - spare
    elif v_center:
        base_bottom = H / 2 + total_h / 2
    else:
        base_bottom = H - base_margin

    # 从下往上排 baseline, 间隔规则与 total_h 计算严格一致
    cursor = base_bottom
    for idx in reversed(range(len(measured))):
        m = measured[idx]
        m['baseline'] = cursor - m['descent']
        cursor = m['baseline'] - m['ascent']
        if idx > 0:
            cur_group = m['line']['group']
            next_group = measured[idx - 1]['line']['group']
            if cur_group == next_group:
                gap = inner_gap
            elif cur_group == 'name' and next_group == 'pri':
                gap = name_gap
            else:
                gap = block_gap
            cursor -= gap

    if out_path is None:
        return total_h, None

    img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    for m in measured:
        ln = m['line']
        anchor = ln.get('anchor', 'ms')
        x = ln.get('x', W / 2)
        tw = m['total_w']
        if anchor == 'ls':
            start_x = x
        elif anchor == 'rs':
            start_x = x - tw
        else:  # ms
            start_x = x - tw / 2
        _draw_segments(draw, start_x, m['baseline'], m['segs'],
                       ln['color'], style, ln['lang'])
    img.save(out_path)
    return total_h, out_path


def render_title_png(W, H, style, zh_text, en_text, out_path,
                     zh_fs=64, en_fs=30, block_gap=24):
    """片头标题卡专用: 中文大标题 + 英文副标题, 居中。"""
    lines = [
        {'text': zh_text, 'lang': 'zh', 'base_fs': zh_fs,
         'color': style.get('pri_color', '#FFFFFF'),
         'keywords': set(), 'anchor': 'ms', 'x': W / 2, 'group': 'pri'},
        {'text': en_text, 'lang': 'en', 'base_fs': en_fs,
         'color': style.get('sec_color', '#FFD54A'),
         'keywords': set(), 'anchor': 'ms', 'x': W / 2, 'group': 'sec'},
    ]
    return layout_and_render(W, H, style, lines, use_lb=False, lb_bottom=0,
                             inner_gap=8, block_gap=block_gap, name_gap=8,
                             base_margin=0, v_center=True,
                             out_path=out_path)


def load_keywords(*sources):
    """从多个来源合并关键词集合。来源可以是:
      - list/set of str
      - .json 文件路径(内容 list of str)
      - .txt 文件路径(每行一词)
    """
    out = set()
    for src in sources:
        if not src:
            continue
        if isinstance(src, (set, list, tuple)):
            out.update(str(x).strip() for x in src if str(x).strip())
            continue
        if not os.path.exists(str(src)):
            continue
        try:
            with open(str(src), encoding='utf-8') as f:
                if str(src).lower().endswith('.json'):
                    data = json.load(f)
                    if isinstance(data, dict):
                        # 支持 {"en":[...], "zh":[...]} 或 {"keywords":[...]}
                        for v in data.values():
                            if isinstance(v, list):
                                out.update(str(x).strip() for x in v if str(x).strip())
                    elif isinstance(data, list):
                        out.update(str(x).strip() for x in data if str(x).strip())
                else:
                    for line in f:
                        w = line.strip()
                        if w:
                            out.add(w)
        except Exception as e:
            print('WARNING: 加载关键词失败 %s: %s' % (src, e))
    return out
