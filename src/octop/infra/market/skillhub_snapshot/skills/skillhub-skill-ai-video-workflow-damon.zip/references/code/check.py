# -*- coding: utf-8 -*-
"""
check.py — 成片交付前自动硬闸门
================================
把历史上反复复发的事故变成机器可判的 PASS/FAIL:

  A1 文件存在且可读
  A2 分辨率与画面方向
  A3 音轨数量 == 1          (防"结尾两个语音一起出来")
  A4 视频时长 >= 音频时长     (防 -shortest 把片尾切掉)
  A5 成片时长 == 期望时长     (需 --expect,防场景被压时长)
  A6 无长黑场/闪烁           (防"一闪一闪"、开场黑屏)
  A7 结尾有画面              (防片尾空白黑屏)
  A8 结尾音频不突断           (防"女音还没读完")

用法:
    python check.py <视频.mp4>
    python check.py <视频.mp4> --expect 129.14      # 期望总时长(Σ各场景配音时长)
    python check.py <视频.mp4> --full               # 全片逐帧查黑场(慢但最准)
    python check.py <视频.mp4> --json               # 机器可读输出

退出码: 0 = 全 PASS / 1 = 有 FAIL / 2 = 无法执行(缺 ffmpeg 等)
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


# ---------------- ffmpeg 定位 ----------------
def find_ffmpeg() -> str | None:
    # 1) 系统 PATH
    exe = "ffmpeg.exe" if os.name == "nt" else "ffmpeg"
    p = _which(exe)
    if p:
        return p
    # 2) imageio_ffmpeg 内嵌
    try:
        import imageio_ffmpeg  # type: ignore
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def _which(name: str) -> str | None:
    for d in os.environ.get("PATH", "").split(os.pathsep):
        if not d:
            continue
        cand = os.path.join(d, name)
        if os.path.isfile(cand):
            return cand
    return None


def run_ff(ff: str, args: list[str], timeout: int = 900) -> tuple[int, str]:
    try:
        r = subprocess.run(
            [ff, "-hide_banner", *args],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            timeout=timeout,
        )
        return r.returncode, r.stdout.decode("utf-8", errors="ignore")
    except subprocess.TimeoutExpired:
        return -1, "TIMEOUT"
    except Exception as e:  # noqa
        return -2, str(e)


# ---------------- 探测 ----------------
DUR_RE = re.compile(r"Duration:\s*(\d+):(\d+):(\d+\.?\d*)")
AUDIO_RE = re.compile(r"Stream #.*?:\s*Audio:")
VIDEO_RE = re.compile(r"Stream #.*?:\s*Video:.*?,\s*(\d{2,5})x(\d{2,5})")


def hms_to_s(m) -> float:
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def probe(ff: str, path: str) -> dict:
    rc, out = run_ff(ff, ["-i", path])
    info: dict = {"raw": out}
    m = DUR_RE.search(out)
    info["duration"] = hms_to_s(m) if m else None
    info["audio_streams"] = len(AUDIO_RE.findall(out))
    v = VIDEO_RE.search(out)
    if v:
        info["width"], info["height"] = int(v.group(1)), int(v.group(2))
    else:
        info["width"] = info["height"] = None
    return info


def stream_duration(ff: str, path: str, kind: str) -> float | None:
    """kind: 'v' 或 'a'。用 -f null 解码取最后一个 time=。"""
    args = ["-i", path, "-map", f"0:{kind}", "-f", "null", "-"]
    rc, out = run_ff(ff, args, timeout=900)
    times = re.findall(r"time=(\d+):(\d+):(\d+\.?\d*)", out)
    if not times:
        return None
    h, m, s = times[-1]
    return int(h) * 3600 + int(m) * 60 + float(s)


BLACK_RE = re.compile(r"frame:\s*(\d+)\s+pblack:\s*(\d+).*?t:\s*([\d.]+)")


def detect_black(ff: str, path: str, full: bool = False,
                 head_only_end: float | None = None) -> list[float]:
    """返回被判定为纯黑的帧时间戳列表。默认只解关键帧(快)。"""
    vf = "blackframe=amount=98:threshold=32"
    args = ["-i", path, "-an", "-sn", "-dn"]
    if not full:
        args += ["-skip_frame", "nokey"]
    if head_only_end:
        args += ["-t", str(head_only_end)]
    args += ["-vf", vf, "-f", "null", "-"]
    rc, out = run_ff(ff, args, timeout=1200)
    return [float(t) for _, pb, t in BLACK_RE.findall(out) if int(pb) >= 98]


def tail_black(ff: str, path: str, duration: float, tail: float = 2.5) -> list[float]:
    """检查最后 tail 秒是否有黑帧。"""
    ss = max(0.0, duration - tail)
    args = ["-ss", f"{ss:.3f}", "-i", path, "-an", "-sn", "-dn",
            "-vf", "blackframe=amount=98:threshold=32", "-f", "null", "-"]
    rc, out = run_ff(ff, args, timeout=300)
    return [float(t) for _, pb, t in BLACK_RE.findall(out) if int(pb) >= 98]


SIL_RE = re.compile(r"silence_(start|end):\s*([\d.]+)")


def tail_silence(ff: str, path: str, duration: float) -> tuple[bool, float]:
    """返回 (结尾是否静音, 最后一段静音起点)。静音判定 -40dB / 0.4s。"""
    args = ["-i", path, "-vn",
            "-af", "silencedetect=noise=-40dB:d=0.4", "-f", "null", "-"]
    rc, out = run_ff(ff, args, timeout=600)
    events = SIL_RE.findall(out)
    # 成对解析: start -> end
    open_at = None
    last_open = None
    for kind, t in events:
        if kind == "start":
            open_at = float(t)
        else:
            open_at = None
    if open_at is not None:
        last_open = open_at
    muted = last_open is not None and (duration - last_open) <= 0.6
    return muted, (last_open if last_open is not None else -1.0)


# ---------------- 判定 ----------------
class Result:
    def __init__(self) -> None:
        self.items: list[dict] = []

    def add(self, code: str, name: str, passed: bool, detail: str, fatal: bool = True):
        self.items.append({"code": code, "name": name, "pass": passed,
                           "detail": detail, "fatal": fatal})

    @property
    def failed(self) -> list[dict]:
        return [i for i in self.items if not i["pass"] and i["fatal"]]

    @property
    def warned(self) -> list[dict]:
        return [i for i in self.items if not i["pass"] and not i["fatal"]]


def check(path: str, expect: float | None = None, full: bool = False,
          aspect: str | None = None) -> Result:
    r = Result()
    ff = find_ffmpeg()
    if not ff:
        r.add("A0", "ffmpeg 可用", False,
              "未找到 ffmpeg,请先运行 install.bat / python install.py", fatal=True)
        return r
    r.add("A0", "ffmpeg 可用", True, ff)

    p = Path(path)
    ok_exists = p.is_file() and p.stat().st_size > 0
    r.add("A1", "文件存在且非空", ok_exists,
          f"{path} ({p.stat().st_size/1048576:.2f} MB)" if ok_exists else f"不存在: {path}")
    if not ok_exists:
        return r

    info = probe(ff, str(p))
    dur = info.get("duration")
    if dur is None:
        r.add("A2", "可解析时长", False, "ffmpeg 无法解析该文件的 Duration", fatal=True)
        return r

    # A2 分辨率/方向
    w, h = info.get("width"), info.get("height")
    if w and h:
        actual = "9:16" if h > w else ("16:9" if w > h else "1:1")
        detail = f"{w}x{h} ({actual})"
        if aspect:
            ok = (actual == aspect)
            r.add("A2", f"画面方向 == {aspect}", ok, detail)
        else:
            r.add("A2", "分辨率/方向", True, detail + "  (未指定 --aspect,仅记录)")
    else:
        r.add("A2", "分辨率/方向", False, "未解析到视频流", fatal=True)
        return r

    # A3 音轨数量
    na = info.get("audio_streams", 0)
    r.add("A3", "音轨数量 == 1", na == 1,
          f"检测到 {na} 条音轨" + ("" if na == 1 else "  ← 多音轨会导致两个语音叠加"))

    # A4 视频时长 vs 音频时长
    vd = stream_duration(ff, str(p), "v")
    ad = stream_duration(ff, str(p), "a") if na else None
    if vd is not None and ad is not None:
        diff = vd - ad
        r.add("A4", "视频时长 >= 音频时长", diff >= -0.2,
              f"视频 {vd:.2f}s / 音频 {ad:.2f}s / 差 {diff:+.2f}s"
              + ("" if diff >= -0.2 else "  ← 片尾音频会被 -shortest 截断"))
    elif vd is not None:
        r.add("A4", "视频时长 >= 音频时长", True,
              f"视频 {vd:.2f}s (无音轨,跳过比对)", fatal=False)
    else:
        r.add("A4", "视频时长", True, "未取到流时长,跳过", fatal=False)

    # A5 期望总时长（用视频解码流时长比对，比容器 Duration 更准确；
    # 容器 Duration 与帧数计算有 0.1~0.3s 正常抖动，阈值 0.5 容纳之。
    # 真正的"不截断"硬保由 A4（视频流时长 >= 音频流时长）负责。）
    if expect is not None:
        base = vd if vd is not None else dur
        delta = base - expect
        r.add("A5", f"总时长 == 期望 {expect:.2f}s", abs(delta) < 0.5,
              f"解码流 {base:.2f}s / 期望 {expect:.2f}s / 差 {delta:+.2f}s"
              + ("" if abs(delta) < 0.5 else "  ← 场景被压时长或音频被切(>0.5s)"))
    else:
        r.add("A5", "总时长 vs Σ配音时长", True,
              f"实际 {dur:.2f}s (未给 --expect,跳过)", fatal=False)

    # A6 黑场 / 闪烁
    blacks = detect_black(ff, str(p), full=full)
    head_black = [t for t in blacks if t <= 0.6]
    # 开场长黑
    ok_head = len(head_black) <= 1
    r.add("A6a", "开场无长黑场", ok_head,
          f"开头 0.6s 内黑帧 {len(head_black)} 个"
          + ("" if ok_head else "  ← 开场黑屏/闪黑"))
    # 中间黑场(排除开头 0.6s 与结尾 1.5s)
    mid = sorted(t for t in blacks if 0.6 < t < max(0.0, dur - 1.5))
    # 连续段判定
    segs = []
    for t in mid:
        if segs and t - segs[-1][-1] <= 0.25:
            segs[-1].append(t)
        else:
            segs.append([t])
    long_segs = [s for s in segs if (s[-1] - s[0]) >= 0.2 or len(s) >= 3]
    r.add("A6b", "中间无闪烁黑场", len(long_segs) == 0,
          ("无" if not long_segs else
           f"发现 {len(long_segs)} 段疑似闪烁,首个 t={long_segs[0][0]:.2f}s"
           + "  ← 每个场景独立黑场淡入会造成双重闪烁")
          + ("" if full else "  (关键帧采样,--full 可全片逐帧复核)"),
          fatal=full)  # 关键帧采样时降级为警告

    # A7 结尾有画面
    tb = tail_black(ff, str(p), dur, tail=2.5)
    r.add("A7", "结尾 2.5s 有画面", len(tb) == 0,
          ("正常" if not tb else f"结尾仍有 {len(tb)} 个黑帧  ← 片尾黑屏收尾"))

    # A8 结尾音频不突断
    if na:
        muted, at = tail_silence(ff, str(p), dur)
        r.add("A8", "结尾音频完整(未突断)", not muted,
              ("结尾有声音" if not muted else
               f"结尾 {dur - at:.2f}s 为静音 (起点 {at:.2f}s)  ← 音频可能被截断"))
    else:
        r.add("A8", "结尾音频完整", True, "无音轨,跳过", fatal=False)

    return r


def main() -> int:
    ap = argparse.ArgumentParser(description="成片交付前自动硬闸门")
    ap.add_argument("video", help="成片 mp4 路径")
    ap.add_argument("--expect", type=float, default=None,
                    help="期望总时长(秒)=各场景配音时长之和")
    ap.add_argument("--aspect", default=None, choices=["16:9", "9:16", "1:1"],
                    help="要求画面方向")
    ap.add_argument("--full", action="store_true", help="全片逐帧查黑场(慢但最准)")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    a = ap.parse_args()

    res = check(a.video, expect=a.expect, full=a.full, aspect=a.aspect)

    if a.json:
        print(json.dumps({"video": a.video, "items": res.items,
                          "failed": [i["code"] for i in res.failed]},
                         ensure_ascii=False, indent=2))
        return 1 if res.failed else 0

    print("=" * 62)
    print(f"  成片自检  {a.video}")
    print("=" * 62)
    for i in res.items:
        mark = "PASS" if i["pass"] else ("FAIL" if i["fatal"] else "WARN")
        print(f"  [{mark}] {i['code']:<5} {i['name']}")
        print(f"         {i['detail']}")
    print("-" * 62)
    if res.failed:
        print(f"  结论: 不合格 — {len(res.failed)} 项 FAIL"
              f"（{', '.join(i['code'] for i in res.failed)}）")
        print("  修复后重跑;对照 1_避坑总纲_血泪清单.md 查根因。")
        print("=" * 62)
        return 1
    if res.warned:
        print(f"  结论: 可用 — {len(res.warned)} 项 WARN（建议复核）")
    else:
        print("  结论: 全部 PASS ✅  可交付")
    print("=" * 62)
    return 0


if __name__ == "__main__":
    sys.exit(main())
