# -*- coding: utf-8 -*-
"""
PPE 自动拦截器（船海风云 · 现场 PPE 红线）
==========================================
扫描《分镜说明.md》：凡未标注「非现场」的镜头视为工业现场，必须含 PPE 关键词，
缺任一项即 FAIL 并阻断成片。依据 short-drama-storyboard SKILL.md 红线（现场 PPE）。

这是把"红线"从纸面变成代码拦截的关键一步：成片前必须运行本脚本，
任一现场镜头 FAIL 则 exit(1)，不得带违规图进成片。

用法：
  python ppe_check.py <分镜说明.md> [更多路径...]
退出码：
  0 = 全部现场镜头 PPE 合规，可进入成片
  1 = 存在违规（阻断成片）
  2 = 用法错误 / 文件不存在
"""
import sys, re, os

# 现场判定：仅当显式标注以下豁免标签才跳过（保守，宁严勿漏）。
# 这些标签必须由分镜说明作者**故意写入**，不是随意就能豁免——确保红线不被钻空子。
# 豁免口径（用户 2026-08-06 明确）：培训 briefing / 办公室 / 下班离场 不强制 PPE（常识）；
# 新人报到尚未领装备属剧情前置（仅陈砺报到段），非违规。其余工业现场作业区一律全套 PPE。
NON_SITE = ["非现场", "non-site", "non site",
            "培训", "下班", "离场", "新人报到前置", "报到前置", "剧情前置"]

HELMET = ["安全帽", "hard hat", "helmet"]
GLASS = ["劳保眼镜", "安全眼镜", "防护眼镜", "透明镜片",
         "safety glasses", "protective eyewear", "transparent lens", "transparent"]
GLOVE = ["劳保手套", "防切割手套", "work gloves", "gloves", "手套夹", "裤兜", "手套"]
SHOE = ["劳保鞋", "安全鞋", "钢头", "防砸", "safety shoes", "steel-toe", "steel toe"]
FEET = ["脚", "鞋", "背影", "走", "步行", "foot", "walk", "boots", "步伐"]


def has(text, kws):
    t = (text or "").lower()
    return any(k.lower() in t for k in kws)


def check_manifest(path):
    txt = open(path, encoding="utf-8").read()
    fails = 0

    # 1) 表格行：| 文件名 | 集数 | 镜头号 | 景别 | 剧本段落 | 画面描述 | 对应台词/情绪 |
    table_rows = re.findall(
        r"^\|\s*(EP\S+\.png)\s*\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|",
        txt, re.M)
    desc_by_shot = {}
    for row in table_rows:
        fn, ep, num, scale, script, desc = [c.strip() for c in row[:6]]
        m = re.search(r"镜头\s*(\d+)", num) or re.search(r"(\d+)", fn)
        if m:
            desc_by_shot[m.group(1)] = (script + " " + desc)

    # 2) **镜头NN** 块（含英文 prompt）
    parts = re.split(r"\n\*\*镜头(\d+)\*\*", txt)
    shots = []
    for i in range(1, len(parts), 2):
        num = parts[i]
        body = parts[i + 1] if i + 1 < len(parts) else ""
        table_desc = desc_by_shot.get(num, "")
        shots.append((num, body + "\n" + table_desc))

    if not shots:
        shots.append(("整篇", txt))

    for num, full in shots:
        if has(full, NON_SITE):
            print(f"[SKIP 镜头{num}] 标注非现场/豁免，跳过 PPE 检查")
            continue
        problems = []
        if not has(full, HELMET):
            problems.append("缺安全帽")
        if not has(full, GLASS):
            problems.append("缺透明劳保眼镜")
        if not has(full, GLOVE):
            problems.append("缺劳保手套(或手套夹兜)")
        if has(full, FEET) and not has(full, SHOE):
            problems.append("脚部入镜但缺劳保鞋")
        if problems:
            fails += 1
            print(f"[FAIL 镜头{num}] " + "；".join(problems))
        else:
            print(f"[PASS 镜头{num}] PPE 关键词齐全")
    return fails


def main():
    if len(sys.argv) < 2:
        print("用法: python ppe_check.py <分镜说明.md> [更多路径...]")
        sys.exit(2)
    total = 0
    for p in sys.argv[1:]:
        if not os.path.exists(p):
            print(f"[ERR] 文件不存在: {p}")
            total += 1
            continue
        print(f"=== 检查 {p} ===")
        total += check_manifest(p)
    if total:
        print(f"\n>>> 存在 {total} 处 PPE 违规，阻断成片！请补齐 PPE 后重跑。")
        sys.exit(1)
    print("\n>>> 全部现场镜头 PPE 合规，可进入成片。")
    sys.exit(0)


if __name__ == "__main__":
    main()
