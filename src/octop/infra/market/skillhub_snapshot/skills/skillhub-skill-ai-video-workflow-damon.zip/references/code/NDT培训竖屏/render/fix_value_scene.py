# -*- coding: utf-8 -*-
# 修复脚本：单独重渲染缺失的 value(专业性/待遇/职位) 场景，
# 用更强健的 TTS（多次重试 + 备用音色兜底），再与已有 6 段重新拼接。
import os, math, asyncio, importlib.util, subprocess

ROOT = r"D:\Workbuddy缓存位置\培训宣传视频工作流"
RENDER = os.path.join(ROOT, "render")
V2 = os.path.join(RENDER, "render_training_promo_v2.py")

spec = importlib.util.spec_from_file_location("v2", V2)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

WORK = m.WORK
OUT_MP4 = m.OUT_MP4
FFMPEG = m.FFMPEG
FPS = m.FPS

import edge_tts

VOICES = ["zh-CN-YunxiNeural", "zh-CN-XiaoxiaoNeural", "zh-CN-YunyangNeural"]

async def tts_hard(text, out, retries=18):
    for i in range(retries):
        voice = VOICES[i % len(VOICES)]
        try:
            comm = edge_tts.Communicate(text, voice)
            await comm.save(out)
            if os.path.getsize(out) > 2000:
                print(f"  TTS 成功 (voice={voice}, 尝试{i+1})")
                return True
            print(f"  TTS 空文件，换音色重试 {i+1}")
        except Exception as e:
            print(f"  TTS 错误 重试 {i+1}/{retries}: {e}")
        await asyncio.sleep(2 + i * 0.5)
    return False

idx = 4  # value 场景
name, narration, fn = m.SCENES[idx]
sdir = os.path.join(WORK, f"seg{idx:02d}")
os.makedirs(sdir, exist_ok=True)

print(f"=== 重渲染场景 {name} ===")
mp3 = os.path.join(sdir, "audio.mp3")
ok = asyncio.run(tts_hard(narration, mp3))
if not ok:
    raise SystemExit("TTS 仍失败，放弃")

dur = m.get_duration(mp3) or 15.0
dur = math.ceil(dur * FPS) / FPS
nframes = int(round(dur * FPS))
print(f"  时长 {dur:.2f}s，渲染 {nframes} 帧...")
for f in range(nframes):
    p = f / max(1, nframes - 1)
    im = fn(p)
    im.convert("RGB").save(os.path.join(sdir, f"{f:05d}.png"), quality=92)

seg_mp4 = os.path.join(sdir, "video.mp4")
m.run([FFMPEG, "-y", "-framerate", str(FPS), "-i", os.path.join(sdir, "%05d.png"),
       "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast", "-crf", "18", seg_mp4])
seg_mux = os.path.join(sdir, "mux.mp4")
m.run([FFMPEG, "-y", "-i", seg_mp4, "-i", mp3, "-c:v", "copy", "-c:a", "aac",
       "-b:a", "192k", "-shortest", "-movflags", "+faststart", seg_mux])
print(f"  场景 {name} 完成，mux={os.path.getsize(seg_mux)} bytes")

# 重新拼接全部 7 段（顺序 seg00..seg06）
list_txt = os.path.join(WORK, "concat_list.txt")
with open(list_txt, "w", encoding="utf-8") as f:
    for i in range(7):
        seg = os.path.join(WORK, f"seg{i:02d}", "mux.mp4")
        if not os.path.exists(seg):
            raise SystemExit(f"缺失分段 seg{i:02d}")
        f.write(f"file '{seg}'\n")
m.run([FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", list_txt, "-c", "copy", OUT_MP4])
print(f"\n成品重新拼接完成: {OUT_MP4}")
