# 周报视频 — 先看这个

> ⚠️ **动手前先看**：[避坑总纲](../1_避坑总纲_血泪清单.md)（历史翻车 + 硬闸门）

> 把每周的招聘/船海周报 PPT 做成横屏 16:9 英文朗读视频。
> 背景 = PPT 原图（零虚化、零运动），字幕逐句切换。
> 字幕为「一句英文 + 一句中文翻译」上下排列。
> 0 积分、纯本地 CPU + edge-tts。

## 一句话用法

```bat
:: 1) 把 PPT 每页导出为 images/slide_NN.png（PowerPoint 或 LibreOffice）
:: 2) 写 projects/<周名>/script.txt（EN/ZH 配对，格式见下）
:: 3) 生成
python pipeline/weekly_build.py --project <周名>
```

成片输出到 `projects/<周名>/<周名>_英语.mp4`。

---

## 硬约束（用户冻结，改前先走 CHANGE_CONTROL.md）

1. **横屏 16:9**（1920×1080），不要竖屏
2. **背景 = PPT 原图**，零虚化（cover 裁剪，不 scale/blur/kenburns）
3. **英语朗读**（edge-tts `en-US-GuyNeural`，语速 `-8%`）—— 只念英文，不念中文
4. **字幕逐句切换**，但**同一页背景在该页所有句子读完前绝不切换**（背景仅"页间"切换）
5. 字幕带半透明压在底部，不挡 PPT 主体
6. **每句英文对应一句中文翻译**：字幕「英文（上）+ 中文（下）」上下排列，中文用 CJK 字体
7. **读到一句换一句**：按 script.txt 的短 EN/ZH 对逐句念+显（不要读一大段）
8. 英文字号 48 / 中文字号 48 / 字幕带底部 200px

---

## 输入格式

### projects/<周名>/images/slide_NN.png
PPT 每页导出的 PNG（NN 两位页码，与 script.txt 的 `### slide_NN` 对应）。
导出方式（任选）：
- PowerPoint：`文件 → 导出 → 更改文件类型 → PNG`，或本机有 PowerPoint 时脚本可 `--start audio` 前的自动导出（需 win32com）
- LibreOffice：`soffice --headless --convert-to png --outdir images source.pptx`

### projects/<周名>/script.txt
```
### slide_01
EN: Welcome to the Chuanhai Vanguard Weekly Report for August 3rd to 7th, 2026.
ZH: 欢迎收看船海先锋招聘周报，2026年8月3日至7日。

EN: This week we tracked 1,596 offshore and marine positions.
ZH: 本周我们采集到 1,596 个海工招聘岗位。
```
- `### slide_NN` 一页开始（NN 对应 PNG 页码）
- 组内 `EN:` / `ZH:` 成对，一句英文 ↔ 一句中文
- 切得越短越好（按逗号也切），每对独立显+独立读

---

## 工作区结构

```
周报视频/
├── 0_README_先看这个.md
├── CHANGE_CONTROL.md          # 变更申报（改前必填）
├── pipeline/
│   └── weekly_build.py        # 生成器（自包含，零框架依赖）
└── projects/
    └── _selftest/             # 自带可跑样例（无需 PowerPoint）
        ├── make_sample.py     # 合成占位 PPT 图 + script.txt
        ├── images/slide_01.png, slide_02.png
        ├── script.txt
        └── _selftest_英语.mp4 # 已验证成片（check.py 8 项全 PASS）
```

跑样例：`python projects/_selftest/make_sample.py` 然后 `python pipeline/weekly_build.py --project _selftest`

---

## 关键参数（冻结，见 CHANGE_CONTROL.md）

| 项 | 值 |
|---|---|
| 分辨率 | 1920×1080（16:9）|
| 配音 | en-US-GuyNeural, rate `-8%` |
| 英/中字号 | 48 / 48 |
| 字幕带 | 底部 200px，半透明黑 (alpha 140) |
| 句尾静音 | 0.25s（ffmpeg 自动补齐尾部静音）|
| 编码器 | libx264 + aac（imageio_ffmpeg 自带）|
| ffmpeg | imageio_ffmpeg 优先，否则 PATH 中 ffmpeg |

---

## 交付前自检（必做，不验证不交付）

```bat
python ../check.py "projects/<周名>/<周名>_英语.mp4" --expect <Σ配音秒+句数*0.25>
```
- A1–A8 全 PASS 才可交付
- 程序化复核「同页背景不动」：页内两时刻顶部 MAE < 2.0、底部 MAE > 3.0（见避坑总纲）

## 已知坑

- 本机没 PowerPoint → 用 LibreOffice 导出 PNG，或自备 images/
- 中文不显示 → 确认 `C:\Windows\Fonts\msyh.ttc` 存在（CJK 字体）
- 改任何参数必须先在 `CHANGE_CONTROL.md` 申报
