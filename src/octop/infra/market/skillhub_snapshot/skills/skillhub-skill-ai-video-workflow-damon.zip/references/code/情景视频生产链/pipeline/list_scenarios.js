// 列出船海/海工专家知识网络引擎中所有可用情景 (domain / key)
// 用法:
//   node pipeline/list_scenarios.js            # 人读表格
//   node pipeline/list_scenarios.js --json     # 机器可读
//   node pipeline/list_scenarios.js hse        # 只看某个领域
const fs = require('fs');
const os = require('os');
const path = require('path');

const CFG = JSON.parse(fs.readFileSync(
  path.join(__dirname, 'config.json'), 'utf8'));

function loadEngine() {
  const html = fs.readFileSync(CFG.engine_html, 'utf8');
  const m = html.match(/<script>([\s\S]*?)<\/script>/);
  if (!m) throw new Error('NO SCRIPT in engine html');
  const tmp = path.join(os.tmpdir(), 'changhai_engine.cjs');
  fs.writeFileSync(tmp, m[1]);
  delete require.cache[require.resolve(tmp)];
  return require(tmp);
}
module.exports.loadEngine = loadEngine;

if (require.main === module) {
  const eng = loadEngine();
  const LIB = eng.SCENARIOS;
  const args = process.argv.slice(2);
  const asJson = args.includes('--json');
  const only = args.find(a => !a.startsWith('--'));

  const out = {};
  for (const domain of Object.keys(LIB)) {
    if (only && domain !== only) continue;
    out[domain] = LIB[domain].map(s => ({
      key: s.key,
      zh: s.zh,
      steps: (s.steps || []).length,
      std: s.std || [],
    }));
  }

  if (asJson) {
    console.log(JSON.stringify(out, null, 2));
  } else {
    let total = 0;
    for (const [domain, items] of Object.entries(out)) {
      console.log(`\n=== ${domain} (${items.length}) ===`);
      for (const it of items) {
        console.log(`  ${it.key.padEnd(22)} ${it.zh}   [${it.steps}步] ${it.std.join('/')}`);
      }
      total += items.length;
    }
    console.log(`\n合计 ${total} 个情景可直接出片`);
  }
}
