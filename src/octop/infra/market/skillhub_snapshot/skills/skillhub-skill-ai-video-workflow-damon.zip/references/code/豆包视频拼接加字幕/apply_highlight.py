# -*- coding: utf-8 -*-
"""
apply_highlight.py — 本工作流的「专业词高亮」封装（参数化版 demo_highlight.py）

只做一件事：读一篇情景文章 JSON -> 提取专业词 -> 对输入 ASS 每句 (en,cn) 包高亮标签 -> 输出新 ASS。
零修改老管线 / 豆包提示词逻辑；highlight_terms 模块来自授权目录，本脚本只 import 引用（不复制不修改）。

用法：
  python apply_highlight.py --ass in.ass --article 文章.json --out out.ass [--base-fs 40]
"""
import json, os, sys, argparse

# highlight_terms.py 由用户在授权目录抽出，本工作流只引用、不复制。
SRC_HL = r"D:/微信小程序/情景视频存放处/豆包视频加字幕工作流"
if os.path.isdir(SRC_HL) and SRC_HL not in sys.path:
    sys.path.insert(0, SRC_HL)
from highlight_terms import extract_hl_terms, apply_ass_highlight


def main():
    ap = argparse.ArgumentParser(description="专业词高亮：给 ASS 每句 (en,cn) 包金光放大标签")
    ap.add_argument("--ass", required=True, help="输入 ASS（已对齐时间轴，英文\\N中文格式）")
    ap.add_argument("--article", required=True, help="情景文章 JSON（含 termNotes/standards）")
    ap.add_argument("--out", required=True, help="输出高亮 ASS")
    ap.add_argument("--base-fs", type=int, default=40,
                    help="字幕基础字号；竖屏 40，横屏按对应字号传（默认 40）")
    args = ap.parse_args()

    if not os.path.isfile(args.ass):
        sys.exit("ERR: 找不到输入 ASS: %s" % args.ass)
    if not os.path.isfile(args.article):
        sys.exit("ERR: 找不到文章 JSON: %s" % args.article)

    art = json.load(open(args.article, encoding="utf-8"))
    en_set, zh_list = extract_hl_terms(art)
    print("== 英文专业词短语(%d) ==" % len(en_set))
    print("  ", sorted(en_set))
    print("== 中文高亮词(%d) ==" % len(zh_list))
    print("  ", zh_list)

    lines = open(args.ass, encoding="utf-8").read().split("\n")
    out = []
    n_total = n_hl = 0
    for ln in lines:
        if ln.startswith("Dialogue:"):
            rest = ln[len("Dialogue:"):].lstrip()
            fields = rest.split(",", 9)          # 10 字段，第10为 Text
            text = fields[9]
            if "\\N" in text:
                en, cn = text.rsplit("\\N", 1)   # 从右切一次：en 可能含内部折行\N，cn 是中文行
            else:
                en, cn = text, ""
            hl_text = apply_ass_highlight(en, cn, en_set, zh_list, args.base_fs)
            fields[9] = hl_text
            out.append("Dialogue: " + ",".join(fields))
            n_total += 1
            if "\\c" in hl_text:
                n_hl += 1
        else:
            out.append(ln)

    open(args.out, "w", encoding="utf-8").write("\n".join(out))
    print("\n== 字幕统计 ==")
    print("  总句数: %d | 含高亮句数: %d" % (n_total, n_hl))
    print("== 已生成: %s ==" % args.out)


if __name__ == "__main__":
    main()
