#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""按工作流A链合成单个情景：去水印→裁尾→Whisper读真人真实发音钉A/B句位置→yyb48字幕→金高亮→烧入→拼接。
配置(config json)提供：源镜头文件、每镜A/B对白、专业词表(term_notes)。
金高亮用临时构造的 article.json（来自 term_notes），不读用户情景文章库。
对齐强制用 Whisper 真发音（本地 tiny.en 模型），绝不用 edge-tts 替身音——替身音是此前字幕不跟发音的根因。
"""
import argparse, json, os, re, subprocess, sys, tempfile, shutil, glob
from pathlib import Path

FF = r"C:/Users/Damon/.workbuddy/binaries/python/versions/3.13.12/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"
SKILL_SCRIPTS = r"D:/Workbuddy缓存位置/.workbuddy/skills/video-edit-workflow/scripts"
# Whisper(本地模型) 需要 faster-whisper，装在 envs/default 这个 venv 里
PY_WHISPER = r"C:/Users/Damon/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
sys.path.insert(0, SKILL_SCRIPTS)
import sync_subtitles as syn

syn.FFMPEG = Path(FF)


def run(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0:
        print("CMD FAIL:", " ".join(cmd))
        print(r.stderr[-1200:])
        raise SystemExit(1)
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = json.load(open(args.config, encoding="utf-8"))
    parent = cfg["parent_dir"]
    final = cfg["final"]
    shots = cfg["shots"]
    term_notes = cfg.get("term_notes", {})

    work = os.path.join(parent, "_work")
    os.makedirs(work, exist_ok=True)
    article = os.path.join(work, "article.json")
    json.dump({"termNotes": term_notes, "standards": []}, open(article, "w", encoding="utf-8"), ensure_ascii=False)

    sub_files = []
    for i, sh in enumerate(shots, 1):
        src = os.path.join(parent, sh["file"])
        dewm = os.path.join(work, f"shot{i}_dewm.mp4")
        trim = os.path.join(work, f"shot{i}_trim.mp4")
        # 1) 去水印
        run([FF, "-i", src, "-vf", "crop=540:960:90:160,scale=720:1280", "-c:a", "copy", "-y", dewm])
        # 2) 裁尾（首尾静音定格）
        run([sys.executable, os.path.join(SKILL_SCRIPTS, "trim_silence.py"), dewm, trim])
        # 3) Whisper 识别视频里真人真实发音的逐词时间戳，把每句钉到真人嘴上
        #    （绝不用 edge-tts 替身音对齐——那是此前字幕不跟发音的根因）
        clauses_json = os.path.join(work, f"shot{i}_clauses.json")
        json.dump(sh["clauses"], open(clauses_json, "w", encoding="utf-8"), ensure_ascii=False)
        ass = os.path.join(work, f"shot{i}.ass")
        run([PY_WHISPER, os.path.join(SKILL_SCRIPTS, "align_whisper.py"),
             "--video", trim, "--json", clauses_json, "--out", ass], cwd=work)
        # 4) 金高亮
        hl = os.path.join(work, f"shot{i}_hl.ass")
        run([sys.executable, os.path.join(SKILL_SCRIPTS, "apply_highlight.py"),
             "--ass", os.path.basename(ass), "--article", os.path.basename(article),
             "--out", os.path.basename(hl), "--base-fs", "48"], cwd=work)
        # 5) 烧入（cd 进 work，相对路径 ass=）
        sub = os.path.join(work, f"shot{i}_sub.mp4")
        run([FF, "-i", trim, "-vf", f"ass={os.path.basename(hl)}",
             "-c:v", "libx264", "-preset", "medium", "-crf", "20",
             "-c:a", "copy", "-movflags", "+faststart", "-y", sub], cwd=work)
        sub_files.append(sub)

    # 6) 拼接
    final_path = os.path.join(parent, final)
    listfile = os.path.join(work, "files.txt")
    with open(listfile, "w", encoding="utf-8") as f:
        for s in sub_files:
            f.write(f"file '{os.path.basename(s)}'\n")
    run([FF, "-f", "concat", "-safe", "0", "-i", listfile, "-c", "copy", "-y", final_path], cwd=work)

    shutil.rmtree(work, ignore_errors=True)
    print(f"[OK] 合成完成: {final_path}")


if __name__ == "__main__":
    main()
