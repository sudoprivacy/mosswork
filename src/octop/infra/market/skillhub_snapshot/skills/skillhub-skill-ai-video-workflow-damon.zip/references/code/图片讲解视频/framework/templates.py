# -*- coding: utf-8 -*-
"""4 类应用模板（学生讲课 / 商务宣传 / 标准讲解 / 产品宣传）。

每个模板定义：
  - 默认风格（可被用户覆盖）
  - 场景序列模板（scene_type 轮转，保证"不断切换不枯燥"）
  - 片头/片尾固定文案钩子
模板与风格正交：任意模板 × 任意风格 可组合。
"""
from typing import Dict, List

TEMPLATES: Dict[str, dict] = {
    "student_lecture": {
        "name": "学生讲课视频",
        "default_style": "manga",
        "desc": "轻松、分镜感、重点突出，适合知识讲解/课程切片。",
        "rotation": ["steps", "split", "data", "highlight",
                     "timeline", "glass", "quote", "compare"],
        "kicker": "LEARN",
        "caption_tail": "关注我，持续更新干货",
    },
    "business_promo": {
        "name": "商务宣传视频",
        "default_style": "business",
        "desc": "沉稳专业，突出卖点/数据/信任背书，适合品牌/服务推广。",
        "rotation": ["highlight", "steps", "data", "glass",
                     "timeline", "compare", "split"],
        "kicker": "SOLUTION",
        "caption_tail": "了解更多，联系我们",
    },
    "standard_explain": {
        "name": "标准讲解视频",
        "default_style": "mechanical",
        "desc": "工程 HUD 风、表格/数据清晰，适合规范/标准/技术讲解。",
        "rotation": ["steps", "data", "compare", "timeline",
                     "glass", "highlight", "split"],
        "kicker": "STANDARD",
        "caption_tail": "收藏备用，规范不踩坑",
    },
    "product_promo": {
        "name": "产品宣传视频",
        "default_style": "realistic",
        "desc": "写实电影感、突出产品力与场景，适合实物/课程/工具推广。",
        "rotation": ["highlight", "split", "steps", "data",
                     "glass", "compare", "timeline"],
        "kicker": "PRODUCT",
        "caption_tail": "立即体验，限时优惠",
    },
    "training_promo": {
        "name": "培训宣传视频",
        "default_style": "mechanical",
        "desc": "先制造焦虑/痛点，再推培训解决方案，适合课程/认证/招生宣传（如 NDT、焊接证培训）。",
        "rotation": ["data", "highlight", "steps", "compare",
                     "glass", "timeline", "highlight"],
        "kicker": "TRAINING",
        "caption_tail": "评论区扣 1，领取报考指南",
    },
}


def get_template(key):
    return TEMPLATES.get(key, TEMPLATES["business_promo"])


def list_templates():
    return [(k, v["name"], v["desc"]) for k, v in TEMPLATES.items()]
