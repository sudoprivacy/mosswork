#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把内容片与"结尾视频"拼接成最终竖屏成片。
- 自动探测内容片分辨率/帧率/采样率
- 把结尾视频放大对齐到内容片分辨率后再拼接（保证整条竖屏一致）
- 输出统一的 libx264 / aac 竖屏 mp4
用法:
  python pipeline/stitch_ending.py --content <内容片.mp4> --ending <结尾视频.mp4> --out <最终.mp4>
"""
import argparse, subprocess, json, os, sys

FFDIR = "C:/Users/Damon/AppData/Local/Microsoft/WinGet/Packages/Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe/ffmpeg-8.1.2-full_build/bin"
FFMPEG = os.path.join(FFDIR, "ffmpeg.exe")
FFPROBE = os.path.join(FFDIR, "ffprobe.exe")


def probe(path):
    out = subprocess.check_output([
        FFPROBE, "-v", "error",
        "-show_entries", "stream=codec_type,width,height,r_frame_rate,sample_rate,channels",
        "-show_entries", "format=duration",
        "-of", "json", path
    ], text=True)
    d = json.loads(out)
    v = next(s for s in d["streams"] if s["codec_type"] == "video")
    a = next((s for s in d["streams"] if s["codec_type"] == "audio"), None)
    w, h = int(v["width"]), int(v["height"])
    fr = v.get("r_frame_rate", "30/1")
    ar = a.get("sample_rate", "44100") if a else "44100"
    ch = a.get("channels", 2) if a else 2
    dur = float(d["format"].get("duration", 0))
    return dict(w=w, h=h, fr=fr, ar=ar, ch=ch, dur=dur)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--ending", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--ending-scale", default="cover",
                    help="cover=铺满内容分辨率(可能裁切); contain=完整(可能留边)")
    args = ap.parse_args()

    c = probe(args.content)
    e = probe(args.ending)
    print("content:", c)
    print("ending :", e)

    W, H = c["w"], c["h"]
    # 结尾视频放大到内容片分辨率
    if args.ending_scale == "cover":
        scale_vf = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}"
    else:
        scale_vf = f"scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black"

    fc = (
        f"[0:v]scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black,setpts=PTS-STARTPTS[v0];"
        f"[1:v]{scale_vf},setpts=PTS-STARTPTS[v1];"
        f"[v0][v1]concat=n=2:v=1[vout];"
        f"[0:a]aformat=sample_fmts=fltp:sample_rates={c['ar']}:channel_layouts=stereo,asetpts=PTS-STARTPTS[a0];"
        f"[1:a]aformat=sample_fmts=fltp:sample_rates={c['ar']}:channel_layouts=stereo,asetpts=PTS-STARTPTS[a1];"
        f"[a0][a1]concat=n=2:v=0:a=1[aout]"
    )

    cmd = [
        FFMPEG, "-y",
        "-i", args.content,
        "-i", args.ending,
        "-filter_complex", fc,
        "-map", "[vout]", "-map", "[aout]",
        "-c:v", "libx264", "-preset", "medium", "-crf", "20",
        "-pix_fmt", "yuv420p", "-r", "30",
        "-c:a", "aac", "-b:a", "192k", "-ar", c["ar"], "-ac", "2",
        args.out
    ]
    print("RUN:", " ".join(cmd))
    subprocess.run(cmd, check=True)
    print("DONE ->", args.out)


if __name__ == "__main__":
    main()
