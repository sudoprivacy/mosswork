# -*- coding: utf-8 -*-
"""
角色形象自动核验器（船海风云 · 角色五官零瑕疵 + 杂物零冗余红线）
================================================================
扫描 `生成图片分镜存放处/角色设定/<角色>/`，对每个角色的「参考形象 v1」图做
结构兜底检查 + 输出目视核验清单。五官瑕疵（熊猫眼/黑眼圈/脸脏/鼻歪/嘴角撕裂）
和杂物冗余（手电筒/笔/算盘等与角色定位不符的随身物）是纯视觉问题，本脚本做
不了判定，必须由 agent 用 Read 工具目视打开每张图后人工判别。

本脚本负责的结构兜底：
  1) 每个角色目录至少 1 张主图（`*_参考形象_v1.png`）；
  2) 每次修订前必须有原图备份（`*_原图备份*.png`），可一键回滚；
  3) 文件命名规范（v1/v2/... 版本号在文件名内）；
  4) 输出「目视核验清单」——列出所有角色图，提示 agent 必须 Read 视觉复检。

依据 short-drama-storyboard SKILL.md 红线第 9 条（角色五官零瑕疵 + 杂物零冗余）。

用法：
  python character_face_check.py <角色设定目录> [更多目录...]
退出码：
  0 = 结构合规 + 已输出目视核验清单，可进入下游成片（前提是清单里的图已目视 PASS）
  1 = 结构违规（缺主图/缺备份/命名不规范），阻断下游成片
  2 = 用法错误 / 目录不存在
"""
import os, re, sys

# 角色主图命名规范：<角色名>_参考形象_v<n>.png
MAIN_RE = re.compile(r"^(?P<char>[^_]+)_参考形象_v(?P<v>\d+)\.png$")
# 原图备份命名规范：<原文件名>_原图备份[_瑕疵描述].png
BACKUP_RE = re.compile(r"^.*_原图备份.*\.png$")


def check_dir(d):
    fails = 0
    print(f"\n=== 扫描 {d} ===")
    if not os.path.isdir(d):
        print(f"[ERR] 目录不存在: {d}")
        return 1

    char_dirs = [p for p in sorted(os.listdir(d))
                 if os.path.isdir(os.path.join(d, p))]
    if not char_dirs:
        print(f"[WARN] 目录下没有任何角色子目录")
        return 0

    for ch in char_dirs:
        cdir = os.path.join(d, ch)
        files = sorted(os.listdir(cdir))
        pngs = [f for f in files if f.lower().endswith(".png")]

        # 1) 主图检查
        main_imgs = [f for f in pngs if MAIN_RE.match(f)]
        if not main_imgs:
            print(f"[FAIL 角色 {ch}] 缺主图 `*_参考形象_v1.png`")
            fails += 1
            continue
        if len(main_imgs) > 1:
            print(f"[WARN 角色 {ch}] 多张主图（{main_imgs}），确认是否需要清理历史版本")

        # 2) 备份检查：每次修订主图前必须 cp 备份
        backups = [f for f in pngs if BACKUP_RE.match(f)]
        if not backups:
            print(f"[WARN 角色 {ch}] 没有任何 `*_原图备份*.png`，无法回滚。补一次历史回滚备份。")

        # 3) 命名规范检查（非主图非备份的 PNG 文件应有合理命名）
        weird = [f for f in pngs
                 if not MAIN_RE.match(f)
                 and not BACKUP_RE.match(f)
                 and not f.startswith("Portrait_")]  # ImageGen 默认产物前缀
        if weird:
            print(f"[WARN 角色 {ch}] 命名不规范的 PNG: {weird}（建议重命名为 v2/原图备份 等）")

        # 4) 输出目视核验清单（agent 必须用 Read 工具逐张打开视觉复检）
        print(f"[CHECK 角色 {ch}] 必查图片清单：")
        for f in main_imgs:
            print(f"        - {os.path.join(cdir, f)}  ← Read 工具目视检查")
        for f in backups:
            print(f"        - {os.path.join(cdir, f)}  ← Read 工具目视检查")
        for f in weird:
            print(f"        - {os.path.join(cdir, f)}  ← Read 工具目视检查（如不需要可删除）")

    print(f"\n[{os.path.basename(d)}] 结构问题: {fails}；其余需目视复检 PASS 才能进下游成片")
    return fails


def main():
    if len(sys.argv) < 2:
        print("用法: python character_face_check.py <角色设定目录> [更多目录...]")
        sys.exit(2)
    total = 0
    for p in sys.argv[1:]:
        total += check_dir(p)
    if total:
        print(f"\n>>> 存在 {total} 处结构违规，阻断下游成片！请补齐主图/备份/命名后再跑。")
        sys.exit(1)
    print("\n>>> 结构兜底通过；目视核验清单已输出，agent 必须逐张 Read 视觉复检 PASS 后才能进成片。")
    sys.exit(0)


if __name__ == "__main__":
    main()