﻿# -*- coding: utf-8 -*-
# LANDSCAPE (16:9, 1920x1080) PPT-style walkthrough for AWS D1.1:2020 Table 6.10
# ENGLISH voice-over + BILINGUAL (EN-over-CN) on-screen content & subtitles.
# Variant of render_table_walkthrough_l_pos.py (Chinese-only frozen version untouched).
import os, json, math, subprocess, textwrap, shutil, re
from PIL import Image, ImageDraw, ImageFont
import fitz

# -----------------------------------------------------------------------------
W, H = 1920, 1080
FPS = 30

ROOT = r"D:\Workbuddy缓存位置\标准讲解视频工作流"
OUT_DIR = os.path.join(ROOT, "output")
SRC_DIR = os.path.join(ROOT, "source", "table610")
CACHE_DIR = os.path.join(ROOT, "render", "audio_cache_en")
FRAMES_DIR = os.path.join(ROOT, "render", "frames_land_pos_en")
FFMPEG = r"C:\Users\Damon\AppData\Local\Programs\Python\Python312\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe"

os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(FRAMES_DIR, exist_ok=True)

# -----------------------------------------------------------------------------
BG = (5, 5, 16)
CYAN = (0, 212, 255)
CYAN_D = (0, 140, 180)
GOLD = (255, 193, 7)
GOLD_D = (200, 145, 0)
RED = (255, 82, 82)
WHITE = (255, 255, 255)
LIGHT = (210, 225, 245)
DIM = (130, 145, 170)
CARD_BG = (10, 14, 34, 240)

# -----------------------------------------------------------------------------
_FONT_CACHE = {}

def get_font(name, size):
    key = (name, size)
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]
    candidates = {
        "cn": [r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\simhei.ttf"],
        "cn_b": [r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\msyh.ttc"],
        "en": [r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\msyh.ttc"],
        "en_b": [r"C:\Windows\Fonts\arialbd.ttf", r"C:\Windows\Fonts\msyhbd.ttc"],
    }
    for p in candidates.get(name, candidates["cn"]):
        if os.path.exists(p):
            try:
                f = ImageFont.truetype(p, size)
                _FONT_CACHE[key] = f
                return f
            except Exception:
                pass
    return ImageFont.load_default()

# -----------------------------------------------------------------------------
def ease_out_cubic(t):
    return 1 - pow(1 - t, 3)

def ease_out_back(t):
    c1, c3 = 1.70158, 2.70158
    return 1 + c3 * pow(t - 1, 3) + c1 * pow(t - 1, 2)

def clamp(v, a, b):
    return max(a, min(b, v))

# -----------------------------------------------------------------------------
TABLE_BASE = None
ROW_BBOX = None
LABEL_CELL = None
TABLE_FRAME = None
IMG_W = IMG_H = 0
POS_IMAGES = {}
POS_NAMES = {
    "1G": "坡口焊 · 平焊位", "2G": "坡口焊 · 横焊位",
    "3G": "坡口焊 · 立焊位", "4G": "坡口焊 · 仰焊位",
    "1F": "角焊缝 · 平焊位", "2F": "角焊缝 · 横焊位",
    "3F": "角焊缝 · 立焊位", "4F": "角焊缝 · 仰焊位",
}

def load_assets():
    global TABLE_BASE, ROW_BBOX, LABEL_CELL, TABLE_FRAME, IMG_W, IMG_H, POS_IMAGES
    base_path = os.path.join(SRC_DIR, "table6_10_p183_base.png")
    json_path = os.path.join(SRC_DIR, "table6_10_p183.json")
    TABLE_BASE = Image.open(base_path).convert("RGBA")
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    ROW_BBOX = data["row_bbox"]
    LABEL_CELL = data["label_cell"]
    TABLE_FRAME = data["table_frame"]
    IMG_W, IMG_H = data["img_size"]
    pos_dir = os.path.join(SRC_DIR, "positions")
    POS_IMAGES = {}
    for code in POS_NAMES:
        p = os.path.join(pos_dir, f"{code}.png")
        if os.path.exists(p):
            POS_IMAGES[code] = Image.open(p).convert("RGBA")

# -----------------------------------------------------------------------------
_BG = None

def build_bg():
    global _BG
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    cy = H // 2
    for y in range(H):
        dy = abs(y - cy) / (H / 2)
        r = int(5 + 8 * (1 - dy))
        g = int(5 + 10 * (1 - dy))
        b = int(16 + 24 * (1 - dy))
        d.line([(0, y), (W, y)], fill=(r, g, b))
    for i in range(60):
        a = int(255 * (i / 60) * 0.16)
        d.rectangle([i, i, W - 1 - i, H - 1 - i], outline=(0, 0, 0), width=1)
    for i in range(16):
        a = int(28 * (1 - i / 16))
        d.line([(0, 120 + i), (W, 120 + i)], fill=(0, 140, 180), width=1)
        d.line([(0, H - 120 - i), (W, H - 120 - i)], fill=(0, 140, 180), width=1)
    _BG = img

# -----------------------------------------------------------------------------
def rounded_rect(d, xy, radius, fill=None, outline=None, width=1):
    x0, y0, x1, y1 = xy
    r = min(radius, (x1 - x0) // 2, (y1 - y0) // 2)
    if fill is not None:
        d.rounded_rectangle(xy, radius=r, fill=fill)
    if outline is not None and width > 0:
        d.rounded_rectangle(xy, radius=r, outline=outline, width=width)

def text_size(d, text, font):
    bbox = d.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0], bbox[3] - bbox[1]

def draw_glow_rect(im, d, xy, color, radius, glow_radius=10):
    x0, y0, x1, y1 = xy
    r = min(radius, (x1 - x0) // 2, (y1 - y0) // 2)
    for i in range(glow_radius, 0, -2):
        alpha = int(35 * (1 - i / glow_radius))
        overlay = Image.new("RGBA", (x1 - x0 + i * 2, y1 - y0 + i * 2), (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        od.rounded_rectangle([0, 0, x1 - x0 + i * 2 - 1, y1 - y0 + i * 2 - 1],
                             radius=r + i, outline=color + (alpha,), width=2)
        im.paste(overlay, (x0 - i, y0 - i), overlay)

# -----------------------------------------------------------------------------
# Layout (landscape) -- adjusted so the two-line bilingual subtitle never covers content
TABLE_X = 70
TABLE_Y = 152
TABLE_W = 1040          # narrowed slightly to free vertical room for 2-line subtitle

CARD_X = 80
CARD_W = 1760
CARD_Y = 620            # moved up so the 2-line subtitle at bottom has clear space
CARD_H = 348

SUB_Y = 974             # two-line bilingual subtitle bar (EN over CN)
SUB_H = 106

def table_layout(slide=0):
    th = int(TABLE_W * IMG_H / IMG_W) if IMG_W else 455
    return TABLE_X, TABLE_Y, TABLE_W, th

# -----------------------------------------------------------------------------
_CARD_CACHE = {}

def build_card(row, card_w, card_h):
    key = (row["code"], card_w, card_h)
    if key in _CARD_CACHE:
        return _CARD_CACHE[key]
    card = Image.new("RGBA", (card_w, card_h), (0, 0, 0, 0))
    cd = ImageDraw.Draw(card)
    m = 36
    rounded_rect(cd, [0, 0, card_w, card_h], radius=26, fill=CARD_BG, outline=CYAN, width=3)
    rounded_rect(cd, [10, 10, card_w - 10, card_h - 10], radius=22, outline=(0, 212, 255, 45), width=1)
    # LEFT zone: tag pill (CN) + EN tag + big code (pop-in) + bilingual note
    tag_w, _ = text_size(cd, row["tag"], get_font("cn_b", 26))
    rounded_rect(cd, [m, 40, m + tag_w + 34, 86], radius=23,
                 fill=(0, 212, 255, 45), outline=CYAN, width=2)
    cd.text((m + 17, 49), row["tag"], font=get_font("cn_b", 26), fill=CYAN)
    cd.text((m, 96), row.get("tag_en", ""), font=get_font("en_b", 22), fill=GOLD)
    if row.get("big_sub"):
        cd.text((m, 288), row["big_sub"], font=get_font("cn", 22), fill=LIGHT)
    if row.get("big_sub_en"):
        cd.text((m, 310), row["big_sub_en"], font=get_font("en", 18), fill=DIM)
    # RIGHT zone: EN title (top) + CN title + bilingual label + value bar + bilingual bullets
    rx = 600
    cd.text((rx, 40), row.get("title_en", ""), font=get_font("en_b", 30), fill=GOLD)
    cd.text((rx, 78), row["title"], font=get_font("cn_b", 36), fill=WHITE)
    cd.text((rx, 116), "评定合格位置  Qualified Positions", font=get_font("cn", 22), fill=DIM)
    bar_h = 52
    bar_y = 158
    rounded_rect(cd, [rx, bar_y, card_w - m, bar_y + bar_h], radius=16,
                 fill=(255, 193, 7, 22), outline=GOLD, width=2)
    big_text = row.get("big", "")
    big_font = get_font("en_b", 54)
    btw, bth = text_size(cd, big_text, big_font)
    if btw > card_w - m - rx - 40:
        big_font = get_font("en_b", 44)
        btw, bth = text_size(cd, big_text, big_font)
    cd.text((rx + (card_w - m - rx) // 2 - btw // 2, bar_y + (bar_h - bth) // 2 - 2),
            big_text, font=big_font, fill=GOLD)
    y = 226
    for line in row["body"]:   # each body line already "CN  ·  EN"
        cd.text((rx, y), line, font=get_font("cn", 22), fill=LIGHT)
        y += 40
    _CARD_CACHE[key] = card
    return card

# code draw position (landscape left zone), used by draw_card pop-in
CODE_X = 36
CODE_TOP = 150

# -----------------------------------------------------------------------------
def draw_top(d, scene):
    pill_text = "AWS D1.1:2020  ·  TABLE 6.10"
    fw = get_font("en_b", 24)
    pw, ph = text_size(d, pill_text, fw)
    px, py = 80, 30
    rounded_rect(d, [px, py, px + pw + 44, py + 50], radius=25,
                 fill=(8, 18, 42, 220), outline=CYAN, width=2)
    d.text((px + 22, py + 11), pill_text, font=fw, fill=CYAN)
    # bilingual title: CN (big) over EN (gold, small)
    title = scene.get("top_title", "焊工焊接位置评定表")
    d.text((W // 2, 70), title, font=get_font("cn_b", 52), fill=WHITE, anchor="mm")
    d.text((W // 2, 116), scene.get("top_title_en", ""), font=get_font("en", 26), fill=GOLD, anchor="mm")

# -----------------------------------------------------------------------------
def draw_table(im, d, key, scene_t):
    tx, ty, tw, th = table_layout()
    table_img = TABLE_BASE.resize((tw, th), Image.LANCZOS)
    draw_glow_rect(im, d, [tx, ty, tx + tw, ty + th], CYAN, 12, 12)
    im.paste(table_img, (tx, ty))
    fdx0 = tx + int(TABLE_FRAME[0] / IMG_W * tw)
    fdy0 = ty + int(TABLE_FRAME[1] / IMG_H * th)
    fdx1 = tx + int(TABLE_FRAME[2] / IMG_W * tw)
    fdy1 = ty + int(TABLE_FRAME[3] / IMG_H * th)
    if key and key in ROW_BBOX:
        overlay = Image.new("RGBA", (tw, th), (0, 0, 0, 135))
        im.paste(overlay, (tx, ty), overlay)
        rb = ROW_BBOX[key]
        hx0 = clamp(tx + int(rb[0] / IMG_W * tw), fdx0, fdx1)
        hx1 = clamp(tx + int(rb[2] / IMG_W * tw), fdx0, fdx1)
        hy0 = clamp(ty + int(rb[1] / IMG_H * th), fdy0, fdy1)
        hy1 = clamp(ty + int(rb[3] / IMG_H * th), fdy0, fdy1)
        if hx1 > hx0 and hy1 > hy0:
            rc = table_img.crop((int(hx0 - tx), int(hy0 - ty), int(hx1 - tx), int(hy1 - ty)))
            im.paste(rc, (hx0, hy0))
            bright = Image.new("RGBA", (hx1 - hx0, hy1 - hy0), (255, 232, 150, 30))
            im.paste(bright, (hx0, hy0), bright)
            draw_glow_rect(im, d, [hx0, hy0, hx1, hy1], GOLD, 8, 14)
            d.rounded_rectangle([hx0, hy0, hx1, hy1], radius=6, outline=GOLD, width=4)

# -----------------------------------------------------------------------------
def draw_card(im, row, slide, scene_t):
    if slide <= 0:
        return
    card = build_card(row, CARD_W, CARD_H)
    if slide < 1.0:
        card = card.copy()
        r, g, b, a = card.split()
        a = a.point(lambda x: int(x * slide / 255))
        card = Image.merge("RGBA", (r, g, b, a))
    card_y = int(H + 40 + (CARD_Y - (H + 40)) * ease_out_cubic(slide))
    im.paste(card, (CARD_X, card_y), card)
    pop_dur = 0.45
    p = clamp(scene_t / pop_dur, 0, 1)
    sc = 3.0 - 2.0 * ease_out_back(p)
    op = int(255 * (0.4 + 0.6 * p))
    code = row["code"].upper()
    font_big = get_font("en_b", max(40, int(96 * sc)))
    tmp = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    cw, ch = text_size(tmp, code, font_big)
    local_cx = CODE_X + 150
    local_cy = CODE_TOP + 56
    cx_text = CARD_X + local_cx - cw // 2
    cy_text = card_y + local_cy - ch // 2
    d2 = ImageDraw.Draw(im)
    d2.text((cx_text + 3, cy_text + 3), code, font=font_big, fill=(0, 0, 0, op))
    d2.text((cx_text, cy_text), code, font=font_big, fill=GOLD + (op,))

# -----------------------------------------------------------------------------
# Subtitle: plain text, EN (top) over CN (bottom), NO box.
# Soft shadow only — never overlaps content (card ends at 968, text starts ~993).
def draw_subtitle(d, en_text, cn_text):
    f_en = get_font("en", 26)
    f_cn = get_font("cn", 26)
    en_y = SUB_Y + 20   # center of EN line (~994)
    cn_y = SUB_Y + 72   # center of CN line (~1046)
    # soft dark shadow for legibility over bright table areas
    d.text((W // 2 + 2, en_y + 2), en_text, font=f_en, fill=(0, 0, 0, 190), anchor="mm")
    d.text((W // 2 + 2, cn_y + 2), cn_text, font=f_cn, fill=(0, 0, 0, 190), anchor="mm")
    d.text((W // 2, en_y), en_text, font=f_en, fill=(150, 220, 255), anchor="mm")
    d.text((W // 2, cn_y), cn_text, font=f_cn, fill=WHITE, anchor="mm")

# -----------------------------------------------------------------------------
# Burst helpers
def _text_layer(text, font, color):
    tmp = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    bb = tmp.textbbox((0, 0), text, font=font)
    w = int(bb[2] - bb[0]); h = int(bb[3] - bb[1])
    layer = Image.new("RGBA", (w + 40, h + 40), (0, 0, 0, 0))
    ImageDraw.Draw(layer).text((20 - bb[0], 20 - bb[1]), text, font=font, fill=color + (255,))
    return layer

def _pill_layer(text, font, text_color, fill_bg, outline_col=None, pad_x=24, pad_y=12):
    tl = _text_layer(text, font, text_color)
    w, h = tl.size
    layer = Image.new("RGBA", (w + pad_x * 2, h + pad_y * 2), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    rounded_rect(ld, [0, 0, layer.width, layer.height], radius=min(layer.height // 2, 26),
                 fill=fill_bg, outline=outline_col, width=2 if outline_col else 0)
    layer.paste(tl, (pad_x, pad_y), tl)
    return layer

def _paste_scaled(im, layer, cx, cy, scale=1.0, alpha=255):
    if scale != 1.0:
        w, h = layer.size
        layer = layer.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.LANCZOS)
    if alpha < 255:
        r, g, b, a = layer.split()
        a = a.point(lambda x: int(x * alpha / 255))
        layer = Image.merge("RGBA", (r, g, b, a))
    w, h = layer.size
    im.paste(layer, (int(cx - w / 2), int(cy - h / 2)), layer)

def _appear(t, start, dur):
    p = clamp((t - start) / dur, 0, 1)
    return ease_out_back(p), int(255 * p)

def _tag_layer(code, cn_kind, en_kind, col):
    w, h = 290, 116
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    rounded_rect(ld, [0, 0, w, h], radius=18, fill=(col[0], col[1], col[2], 45), outline=col, width=3)
    ld.text((w // 2, 36), code, font=get_font("en_b", 44), fill=col + (255,), anchor="mm")
    ld.text((w // 2, 74), cn_kind, font=get_font("cn", 22), fill=LIGHT + (255,), anchor="mm")
    ld.text((w // 2, 98), en_kind, font=get_font("en", 18), fill=(150, 220, 255) + (255,), anchor="mm")
    return layer

def _point_layer(lab, val, col):
    w, h = 340, 66
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    rounded_rect(ld, [0, 0, w, h], radius=14, fill=(10, 14, 34, 240), outline=col, width=2)
    ld.text((16, h // 2), lab, font=get_font("cn_b", 24), fill=WHITE, anchor="lm")
    ld.text((w - 16, h // 2), val, font=get_font("en_b", 30), fill=col + (255,), anchor="rm")
    return layer

def _badge_layer(lab, name, col):
    w, h = 360, 200
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    rounded_rect(ld, [0, 0, w, h], radius=22, fill=(10, 14, 34, 245), outline=col, width=3)
    ld.text((w // 2, 70), lab, font=get_font("en_b", 64), fill=col + (255,), anchor="mm")
    ld.text((w // 2, 140), name, font=get_font("cn_b", 28), fill=WHITE, anchor="mm")
    return layer

# Intro scene: dense burst (bilingual)
def draw_intro(im, d, t):
    sc, al = _appear(t, 0.0, 0.6)
    if al > 0:
        yoff = -50 * (1 - ease_out_cubic(clamp(t / 0.6, 0, 1)))
        _paste_scaled(im, _text_layer("焊工焊接位置评定表", get_font("cn_b", 52), WHITE),
                     W // 2, 78 + yoff, scale=sc, alpha=al)
    sc, al = _appear(t, 0.2, 0.6)
    if al > 0:
        xoff = -320 * (1 - ease_out_cubic(clamp((t - 0.2) / 0.6, 0, 1)))
        _paste_scaled(im, _pill_layer("AWS D1.1:2020  ·  TABLE 6.10", get_font("en_b", 24),
                                      CYAN, (8, 18, 42, 220), CYAN),
                     230 + xoff, 59, scale=sc, alpha=al)
    sc, al = _appear(t, 0.4, 0.6)
    if al > 0:
        xoff = 300 * (1 - ease_out_cubic(clamp((t - 0.4) / 0.6, 0, 1)))
        _paste_scaled(im, _text_layer("Welder Qualification - Production Positions",
                                      get_font("en", 28), (205, 224, 248)),
                     W // 2 + xoff, 134, scale=sc, alpha=al)
    if t >= 0.6:
        p = ease_out_cubic(clamp((t - 0.6) / 1.2, 0, 1))
        tw = int(TABLE_W * (0.82 + 0.18 * p))
        th = int(tw * IMG_H / IMG_W)
        tbl = TABLE_BASE.resize((tw, th), Image.LANCZOS).convert("RGBA")
        _paste_scaled(im, tbl, TABLE_X + TABLE_W / 2, TABLE_Y + th / 2, scale=1.0, alpha=int(255 * p))
    tags = [
        ("1G", "坡口·平焊", "Groove-Flat", CYAN), ("2G", "坡口·横焊", "Groove-Horiz", CYAN),
        ("3G", "坡口·立焊", "Groove-Vert", CYAN), ("4G", "坡口·仰焊", "Groove-Ovhd", CYAN),
        ("1F", "角焊·平焊", "Fillet-Flat", GOLD), ("2F", "角焊·横焊", "Fillet-Horiz", GOLD),
        ("3F", "角焊·立焊", "Fillet-Vert", GOLD), ("4F", "角焊·仰焊", "Fillet-Ovhd", GOLD),
    ]
    base_t = 2.0
    for k, (code, cnk, enk, col) in enumerate(tags):
        sc, al = _appear(t, base_t + k * 0.4, 0.4)
        if al > 0:
            cx = TABLE_X + 155 + (k % 4) * 270
            cy = 700 + (k // 4) * 116
            _paste_scaled(im, _tag_layer(code, cnk, enk, col), cx, cy, scale=sc, alpha=al)
    points = [
        ("1G / 1F", "F", CYAN), ("2G / 2F", "F, H", GOLD),
        ("3G / 3F", "F, H, V", CYAN), ("4G / 4F", "F, H, OH", GOLD),
    ]
    for k, (lab, val, col) in enumerate(points):
        sc, al = _appear(t, 6.0 + k * 0.75, 0.5)
        if al > 0:
            _paste_scaled(im, _point_layer(lab, val, col), 1700, 690 + k * 72, scale=sc, alpha=al)

def draw_burst(im, d, row, t, dur):
    ap = clamp(t / 0.5, 0, 1)
    scale = 1.0 + 0.5 * (1 - ease_out_back(ap))
    al = int(255 * ap)
    if t > dur - 0.4:
        al = int(255 * clamp((dur - t) / 0.4, 0, 1))
    if al <= 0:
        return
    _paste_scaled(im, _badge_layer(row["big"], row["title"], GOLD), 1700, 320, scale=scale, alpha=al)

# Summary scene: bilingual recap
def draw_summary_burst(im, d, t):
    rules = [
        ("1G / 1F", "F", CYAN),
        ("2G / 2F", "F, H", GOLD),
        ("3G / 3F", "F, H, V", CYAN),
        ("4G / 4F", "F, H, OH", GOLD),
    ]
    for k, (lab, val, col) in enumerate(rules):
        sc, al = _appear(t, 0.3 + k * 0.55, 0.5)
        if al > 0:
            _paste_scaled(im, _point_layer(lab, val, col), 1700, 250 + k * 92, scale=sc, alpha=al)
    # bilingual plug/slot pill (two lines)
    sc, al = _appear(t, 2.5, 0.6)
    if al > 0:
        pw, ph = 720, 96
        layer = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
        ld = ImageDraw.Draw(layer)
        rounded_rect(ld, [0, 0, pw, ph], radius=18, fill=(10, 14, 34, 245), outline=GOLD, width=2)
        ld.text((pw // 2, 30), "塞焊和槽焊：仅在实际试验位置合格", font=get_font("cn_b", 24), fill=WHITE, anchor="mm")
        ld.text((pw // 2, 66), "Plug & slot: qualified only for positions actually tested", font=get_font("en", 20), fill=(150, 220, 255), anchor="mm")
        _paste_scaled(im, layer, W // 2, 938, scale=sc, alpha=al)
    tags = [
        ("1G", "坡口·平焊", "Groove-Flat", CYAN), ("2G", "坡口·横焊", "Groove-Horiz", CYAN),
        ("3G", "坡口·立焊", "Groove-Vert", CYAN), ("4G", "坡口·仰焊", "Groove-Ovhd", CYAN),
        ("1F", "角焊·平焊", "Fillet-Flat", GOLD), ("2F", "角焊·横焊", "Fillet-Horiz", GOLD),
        ("3F", "角焊·立焊", "Fillet-Vert", GOLD), ("4F", "角焊·仰焊", "Fillet-Ovhd", GOLD),
    ]
    for k, (code, cnk, enk, col) in enumerate(tags):
        sc, al = _appear(t, 3.2 + k * 0.22, 0.4)
        if al > 0:
            cx = 230 + (k % 4) * 250
            cy = 760 + (k // 4) * 110
            _paste_scaled(im, _tag_layer(code, cnk, enk, col), cx, cy, scale=sc, alpha=al)

# -----------------------------------------------------------------------------
# Per-position standard test-plate diagram (right panel)
DIAG_X, DIAG_Y, DIAG_W, DIAG_H = 1260, 150, 640, 460

def draw_position_diagram(im, d, code, t):
    if code not in POS_IMAGES:
        return
    ap = clamp(t / 0.4, 0, 1)
    scale = 1.12 - 0.12 * ease_out_cubic(ap)
    al = int(255 * ap)
    if al <= 0:
        return
    pw, ph = DIAG_W, DIAG_H
    panel = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
    pd = ImageDraw.Draw(panel)
    rounded_rect(pd, [0, 0, pw, ph], radius=20, fill=(246, 249, 255, 255), outline=GOLD, width=4)
    pd.text((22, 16), "标准试板简图  Test Plate", font=get_font("cn_b", 26), fill=(18, 40, 78))
    src = POS_IMAGES[code]
    sw, sh = src.size
    max_w, max_h = pw - 50, ph - 165
    r = min(max_w / sw, max_h / sh)
    dw, dh = max(1, int(sw * r)), max(1, int(sh * r))
    dia = src.resize((dw, dh), Image.LANCZOS)
    dx = (pw - dw) // 2
    dy = 58
    panel.paste(dia, (dx, dy), dia)
    pd.text((24, ph - 104), code, font=get_font("en_b", 58), fill=(20, 32, 56))
    pd.text((150, ph - 92), POS_NAMES.get(code, ""), font=get_font("cn_b", 28), fill=(20, 32, 56))
    fig = "AWS D1.1  Fig.4.3" if code.endswith("G") else "AWS D1.1  Fig.4.4"
    pd.text((24, ph - 42), fig, font=get_font("en", 22), fill=(90, 110, 145))
    if scale != 1.0:
        panel = panel.resize((max(1, int(pw * scale)), max(1, int(ph * scale))), Image.LANCZOS)
    if al < 255:
        rr, gg, bb, aa = panel.split()
        aa = aa.point(lambda x: int(x * al / 255))
        panel = Image.merge("RGBA", (rr, gg, bb, aa))
    w, h = panel.size
    im.paste(panel, (int(DIAG_X + (pw - w) / 2), int(DIAG_Y + (ph - h) / 2)), panel)
    draw_glow_rect(im, d, [DIAG_X, DIAG_Y, DIAG_X + pw, DIAG_Y + ph], GOLD, 16, 16)

# -----------------------------------------------------------------------------
# Scene data (bilingual; EN voice-over; EN-over-CN subtitles & content)
SCENES = [
    {
        "key": None,
        "top_title": "焊工焊接位置评定表",
        "top_title_en": "Welder Qualification Positions",
        "caption_en": "AWS D1.1:2020 — Table 6.10: Welder Qualification Positions.",
        "caption": "AWS D1.1:2020 表 6.10：焊工焊接位置评定表。",
        "spoken": "In this lesson we look at A W S D 1.1, 2020, Table 6.10, the Welder Qualification Positions table. It shows which production welding positions a welder is qualified for, based on the plate test position they passed."
    },
    {
        "key": "1G", "code": "1G", "tag": "坡口焊", "tag_en": "GROOVE", "title": "平焊试验位置", "title_en": "Flat Position",
        "big": "F", "big_sub": "坡口焊主体只有 F，角焊缝另含 H", "big_sub_en": "Groove only F; fillet adds H",
        "body": ["板材 CJP/PJP：F  ·  Plate CJP/PJP: F",
                 "管子、箱型管：F  ·  Pipe & box tube: F",
                 "角焊缝(板/管/箱型)：F,H  ·  Fillet: F,H"],
        "caption_en": "1G — Groove weld, flat. Plate/pipe/box groove welds qualify only F.",
        "caption": "1G 坡口焊平焊位。板材/管子/箱型管坡口焊仅评定 F。",
        "spoken": "1 G, groove weld, flat position. For plate, pipe and box-tube groove welds, the only qualified production position is flat, F."
    },
    {
        "key": "2G", "code": "2G", "tag": "坡口焊", "tag_en": "GROOVE", "title": "横焊试验位置", "title_en": "Horizontal Position",
        "big": "F, H", "big_sub": "", "big_sub_en": "",
        "body": ["对接焊 CJP/PJP：均 F,H  ·  All groove welds: F,H",
                 "板材·管子·箱型管 一致  ·  Plate/pipe/box: same",
                 "横焊覆盖平焊 + 横焊  ·  Horizontal covers Flat+Horiz"],
        "caption_en": "2G — Groove weld, horizontal. All groove welds qualify F and H.",
        "caption": "2G 坡口焊横焊位。各类坡口焊评定 F、H。",
        "spoken": "2 G, groove weld, horizontal position. For all types of groove weld, the qualified positions are F and H."
    },
    {
        "key": "3G", "code": "3G", "tag": "坡口焊", "tag_en": "GROOVE", "title": "立焊试验位置", "title_en": "Vertical Position",
        "big": "F, H, V", "big_sub": "", "big_sub_en": "",
        "body": ["对接焊 CJP/PJP：均 F,H,V  ·  All groove welds: F,H,V",
                 "立焊覆盖平、横、立  ·  Vertical covers F,H,V"],
        "caption_en": "3G — Groove weld, vertical. All groove welds qualify F, H, V.",
        "caption": "3G 坡口焊立焊位。各类坡口焊评定 F、H、V。",
        "spoken": "3 G, groove weld, vertical position. For all groove welds, the qualified positions are F, H and V."
    },
    {
        "key": "4G", "code": "4G", "tag": "坡口焊", "tag_en": "GROOVE", "title": "仰焊试验位置", "title_en": "Overhead Position",
        "big": "F, H, OH", "big_sub": "", "big_sub_en": "",
        "body": ["对接焊 CJP/PJP：均 F,H,OH  ·  All groove welds: F,H,OH",
                 "仰焊覆盖平、横、仰  ·  Overhead covers F,H,OH"],
        "caption_en": "4G — Groove weld, overhead. All groove welds qualify F, H, OH.",
        "caption": "4G 坡口焊仰焊位。各类坡口焊评定 F、H、OH。",
        "spoken": "4 G, groove weld, overhead position. For all groove welds, the qualified positions are F, H and O H."
    },
    {
        "key": "1F", "code": "1F", "tag": "角焊缝", "tag_en": "FILLET", "title": "平焊角焊缝", "title_en": "Fillet — Flat",
        "big": "F", "big_sub": "角焊缝平焊位只有 F", "big_sub_en": "Fillet flat position: F only",
        "body": ["板材角焊缝：F  ·  Plate fillet: F",
                 "管子/箱型管 T/Y/K：F  ·  Pipe/box T,Y,K: F",
                 "只评定合格平焊位  ·  Flat position only"],
        "caption_en": "1F — Fillet weld, flat. Plate/pipe/box fillet welds qualify only F.",
        "caption": "1F 角焊缝平焊位。板材/管子/箱型管角焊仅评定 F。",
        "spoken": "1 F, fillet weld, flat position. For plate, pipe and box-tube fillet welds, the only qualified position is flat, F."
    },
    {
        "key": "2F", "code": "2F", "tag": "角焊缝", "tag_en": "FILLET", "title": "横焊角焊缝", "title_en": "Fillet — Horizontal",
        "big": "F, H", "big_sub": "", "big_sub_en": "",
        "body": ["角焊缝(板/管/箱型)：均 F,H  ·  All fillet welds: F,H",
                 "横焊角焊缝覆盖平焊 + 横焊  ·  Horiz fillet: Flat+Horiz"],
        "caption_en": "2F — Fillet weld, horizontal. All fillet welds qualify F and H.",
        "caption": "2F 角焊缝横焊位。各类角焊评定 F、H。",
        "spoken": "2 F, fillet weld, horizontal position. For all fillet welds, the qualified positions are F and H."
    },
    {
        "key": "3F", "code": "3F", "tag": "角焊缝", "tag_en": "FILLET", "title": "立焊角焊缝", "title_en": "Fillet — Vertical",
        "big": "F, H, V", "big_sub": "", "big_sub_en": "",
        "body": ["角焊缝(板/管/箱型)：均 F,H,V  ·  All fillet welds: F,H,V",
                 "立焊角焊缝覆盖平、横、立  ·  Vert fillet: F,H,V"],
        "caption_en": "3F — Fillet weld, vertical. All fillet welds qualify F, H, V.",
        "caption": "3F 角焊缝立焊位。各类角焊评定 F、H、V。",
        "spoken": "3 F, fillet weld, vertical position. For all fillet welds, the qualified positions are F, H and V."
    },
    {
        "key": "4F", "code": "4F", "tag": "角焊缝", "tag_en": "FILLET", "title": "仰焊角焊缝", "title_en": "Fillet — Overhead",
        "big": "F, H, OH", "big_sub": "", "big_sub_en": "",
        "body": ["角焊缝(板/管/箱型)：均 F,H,OH  ·  All fillet welds: F,H,OH",
                 "仰焊角焊缝覆盖平、横、仰  ·  Overhead fillet: F,H,OH"],
        "caption_en": "4F — Fillet weld, overhead. All fillet welds qualify F, H, OH.",
        "caption": "4F 角焊缝仰焊位。各类角焊评定 F、H、OH。",
        "spoken": "4 F, fillet weld, overhead position. For all fillet welds, the qualified positions are F, H and O H."
    },
    {
        "key": None,
        "top_title": "核心规则",
        "top_title_en": "Key Rules",
        "caption_en": "Table 6.10: 1G/1F=F; 2G/2F=F,H; 3G/3F=F,H,V; 4G/4F=F,H,OH. Plug/slot: tested positions only.",
        "caption": "表 6.10：1G/1F=F；2G/2F=F,H；3G/3F=F,H,V；4G/4F=F,H,OH。塞焊/槽焊：仅试验位置。",
        "spoken": "Table 6.10 summary. A welder is qualified by plate test position. 1 G and 1 F qualify only F. 2 G and 2 F cover F and H. 3 G and 3 F cover F, H and V. 4 G and 4 F cover F, H and O H. Plug and slot welds are qualified only for the positions actually tested."
    }
]

# -----------------------------------------------------------------------------
def tts(text, out_path):
    cmd = ["edge-tts", "--voice", "en-US-AriaNeural", "--text", text, "--write-media", out_path]
    subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8")

def get_audio(i, text):
    path = os.path.join(CACHE_DIR, f"scene_{i:02d}.mp3")
    if not os.path.exists(path):
        print(f"  tts scene {i}")
        tts(text, path)
    return path

def audio_duration(path):
    r = subprocess.run([FFMPEG, "-i", path], capture_output=True, encoding="utf-8", errors="ignore")
    m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", r.stderr)
    if not m:
        return 5.0
    h, m_, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
    return h * 3600 + m_ * 60 + s

# -----------------------------------------------------------------------------
scene_dur_last = 1.0

def render():
    global scene_dur_last
    print("loading assets...")
    load_assets()
    build_bg()
    durations = []
    audio_paths = []
    for i, sc in enumerate(SCENES):
        mp3 = get_audio(i, sc["spoken"])
        dur = audio_duration(mp3) + 0.6
        durations.append(dur)
        audio_paths.append(mp3)
        print(f"scene {i}: {dur:.2f}s")

    print("rendering frames...")
    os.makedirs(FRAMES_DIR, exist_ok=True)
    frame_idx = 0
    seg_files = []
    for i, sc in enumerate(SCENES):
        dur = durations[i]
        n = int(dur * FPS) + 1
        row = sc if sc.get("key") else None
        card_in = 0.35
        card_out = 0.45
        scene_start = frame_idx
        for f in range(n):
            t = f / FPS
            slide = 0.0
            if row:
                if t < card_in:
                    slide = t / card_in
                elif t > dur - card_out:
                    slide = max(0.0, (dur - t) / card_out)
                else:
                    slide = 1.0
            scene_dur_last = dur
            im = Image.new("RGBA", (W, H), BG + (255,))
            d = ImageDraw.Draw(im)
            im.paste(_BG, (0, 0))
            if i == 0:
                draw_intro(im, d, t)
            elif i == len(SCENES) - 1:
                draw_top(d, sc)
                draw_table(im, d, sc.get("key"), t)
                draw_summary_burst(im, d, t)
            else:
                draw_top(d, sc)
                draw_table(im, d, sc.get("key"), t)
                if row:
                    draw_card(im, row, slide, t)
                    draw_position_diagram(im, d, row["code"], t)
            draw_subtitle(d, sc.get("caption_en", ""), sc["caption"])
            out_path = os.path.join(FRAMES_DIR, f"frame_{frame_idx:06d}.png")
            im.convert("RGB").save(out_path)
            frame_idx += 1
        seg_files.append((i, scene_start, n, audio_paths[i], dur))

    print("encoding segments...")
    seg_mp4s = []
    for i, start, n, mp3, dur in seg_files:
        seg_mp4 = os.path.join(FRAMES_DIR, f"seg_{i:02d}.mp4")
        cmd = [
            FFMPEG, "-y",
            "-framerate", str(FPS),
            "-start_number", str(start),
            "-i", os.path.join(FRAMES_DIR, "frame_%06d.png"),
            "-i", mp3,
            "-frames:v", str(n),
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
            "-c:a", "aac", "-b:a", "128k",
            "-shortest", seg_mp4
        ]
        subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8", errors="ignore")
        seg_mp4s.append(seg_mp4)
        print(f"  seg {i} done")

    print("concatenating...")
    import shutil as _shutil
    tmp = r"C:\wb_tmp_concat"
    if os.path.exists(tmp):
        _shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp, exist_ok=True)
    tmp_segs = []
    for mp4 in seg_mp4s:
        dst = os.path.join(tmp, os.path.basename(mp4))
        _shutil.copy2(mp4, dst)
        tmp_segs.append(dst)
    concat_file = os.path.join(tmp, "concat.txt")
    with open(concat_file, "w", encoding="utf-8") as cf:
        for mp4 in tmp_segs:
            cf.write(f"file '{mp4.replace(chr(92), '/')}'\n")
    final = os.path.join(OUT_DIR, "aws_table610_walkthrough_pos_en.mp4")
    cmd = [
        FFMPEG, "-y",
        "-f", "concat", "-safe", "0", "-i", concat_file,
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
        "-c:a", "aac", "-b:a", "160k",
        "-movflags", "+faststart",
        final
    ]
    subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8", errors="ignore")
    _shutil.rmtree(tmp, ignore_errors=True)
    print("final:", final)
    return final

if __name__ == "__main__":
    render()
