# -*- coding: utf-8 -*-
"""9 种版式（元素级入场动画 + 走质检），横竖屏自适应。

设计铁律（保证不出错）：
  1) 顶部 header 占据方向相关安全区，与下方内容纵向分离，不与照片争空间。
  2) 无主播位时：有内容照片 → 照片固定放左侧列，文字放右侧列；
     无内容照片 → 文字居中。
  3) 有主播位时：主播竖条固定在右侧（竖屏）/ 右侧（横屏），内容区左移避让；
     内容照片不再硬塞左侧，避免过窄。位置可由 host_position 调整（right/left/center）。
  4) 底部字幕固定在方向相关安全区，互不交叠。
  5) 所有文字/照片都通过 Canvas 登记包围盒，由 validator 在渲染期硬卡。
  6) 不再画空装饰框：玻璃卡仅在有内容时绘制，并随内容高度收缩。

竖屏坐标严格沿用旧版（保证旧成片一致）；横屏给出 1920x1080 专用布局，
杜绝"文字被挤成竖条 / 背景没铺满横屏"等竖屏搬到横屏的问题。

每个 layout 函数签名：
  draw(scene, canvas, style, photos, t, dur, host=None, host_box=None)
    photos: list[(PIL.Image, framing_or_None)]  题材内容照片
    host:   PIL.Image or None                    主播/博主头像
    host_box: 主播位包围盒（已由 engine 按 host_position 计算）
"""
import os
from PIL import Image, ImageDraw, ImageFilter
from .canvas import wrap_cjk
import re


# ---------------- 版式公共：列划分（方向相关） ----------------
def _text_col(has_photos, has_host, m):
    """返回文字内容区 (x0, x1)。有主播位时内容区左移，优先保证主播竖条。"""
    if has_host:
        return m["content_left"], m["content_right_host"]
    if has_photos:
        return m["content_left"], m["content_right_photos"]
    return m["content_left"], m["content_right_none"]


def _photo_boxes(n, m):
    """左侧竖列照片框（像素），支持 0/1/2 张。按方向返回。"""
    if n <= 0:
        return []
    if m["portrait"] if "portrait" in m else True:
        # 竖屏
        if n == 1:
            return [(60, 660, 520, 1540)]
        return [(60, 660, 520, 1120), (60, 1140, 520, 1540)]
    else:
        # 横屏
        x = m["photo_x"]
        w = m["photo_w"]
        top = m["photo_top"]
        if n == 1:
            return [(x, top, x + w, top + 560)]
        return [(x, top, x + w, top + 270), (x, top + 290, x + w, top + 560)]


# ---------------- 主播位 ----------------
def _draw_host(canvas, style, host, host_box):
    """在指定包围盒画主播竖条：圆角面板 + 照片 + 主播标签（随场景入场动画出现）。"""
    if not host or not host_box:
        return
    x0, y0, x1, y1 = host_box
    w, h = x1 - x0, y1 - y0
    p = style.palette

    def _draw(d, layer):
        # 阴影
        sh = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh)
        sd.rounded_rectangle([6, 12, w - 6, h - 4], radius=style.card_radius,
                             fill=(0, 0, 0, 140))
        sh = sh.filter(ImageFilter.GaussianBlur(12))
        layer.alpha_composite(sh, (0, 0))
        pd = ImageDraw.Draw(layer)
        pd.rounded_rectangle([2, 2, w - 2, h - 2], radius=style.card_radius,
                             fill=(*p["panel"], style.card_alpha))
        pd.rounded_rectangle([2, 2, w - 2, h - 2], radius=style.card_radius,
                             outline=(*p["panel_border"], style.border_alpha),
                             width=style.line_width)
        # 照片区：cover 裁剪填充，底部留 52px 给标签
        photo_h = h - 56
        aspect = host.width / host.height
        panel_aspect = w / photo_h
        if aspect > panel_aspect:
            new_h = photo_h
            new_w = int(photo_h * aspect)
            resized = host.resize((new_w, new_h))
            crop_x = (new_w - w) // 2
            photo_crop = resized.crop((crop_x, 0, crop_x + w, photo_h))
        else:
            new_w = w
            new_h = int(w / aspect)
            resized = host.resize((new_w, new_h))
            crop_y = (new_h - photo_h) // 2
            photo_crop = resized.crop((0, crop_y, w, crop_y + photo_h))
        mask = Image.new("L", (w, photo_h), 0)
        md = ImageDraw.Draw(mask)
        r = style.card_radius
        md.rounded_rectangle([2, 2, w - 2, photo_h + 2], radius=r, fill=255)
        layer.paste(photo_crop, (0, 0), mask)
        # 主播标签
        label = "主播"
        lf = canvas.get_font("cn_b", 24)
        tw, _ = canvas.measure(label, lf)
        chip_h = 36
        chip_y = h - chip_h - 6
        chip_x0 = int((w - tw) / 2) - 10
        chip_x1 = int((w + tw) / 2) + 10
        pd.rounded_rectangle([chip_x0, chip_y, chip_x1, chip_y + chip_h],
                             radius=chip_h // 2, fill=(*p["accent"], 235))
        pd.text((w // 2, chip_y + chip_h // 2), label, font=lf,
                fill=(255, 255, 255, 255), anchor="mm")

    canvas.capture((x0, y0, x1, y1), _draw, "photo", "host", enter="slide_right",
                   appear_at=0.0, fixed_enter=True)


def _place_photos(canvas, style, photos, boxes):
    """把 photos 按 boxes 摆放（自适应数量），居中 cover 裁剪，不越界。"""
    for i, box in enumerate(boxes):
        if i >= len(photos):
            break
        img, framing = photos[i]
        x0, y0, x1, y1 = box
        box_w = x1 - x0
        box_h = y1 - y0
        from . import photo as P
        layer = P.build_photo_layer(img, style, box_h, framing)
        lw, lh = layer.size
        if lw > box_w:
            crop_x = (lw - box_w) // 2
            layer = layer.crop((crop_x, 0, crop_x + box_w, lh))
            lw = box_w
        if lh > box_h:
            crop_y = (lh - box_h) // 2
            layer = layer.crop((0, crop_y, lw, crop_y + box_h))
            lh = box_h
        px = x0 + (box_w - lw) // 2
        py = y0 + (box_h - lh) // 2
        canvas.paste_photo(layer, (px, py, px + lw, py + lh), label=f"photo_{i}")


# ---------------- 装饰绘制（不登记，走 capture 动画）----------------
def _glass_panel_onto(d, x, y, w, h, style):
    p = style.palette
    border = p["panel_border"]
    d.rounded_rectangle([x, y, x + w, y + h], radius=style.card_radius,
                        fill=(*p["panel"], style.card_alpha))
    d.rounded_rectangle([x, y, x + w, y + h], radius=style.card_radius,
                        outline=(*border, style.border_alpha), width=style.line_width)


def _semicircle_onto(d, cx, cy, r, style, value):
    p = style.palette
    d.arc([cx - r, cy - r, cx + r, cy + r], start=180, end=360,
          fill=(*p["line"], 120), width=22)
    s = str(value)
    pct = 0.6
    try:
        import re
        nums = re.findall(r"\d+(?:\.\d+)?", s.replace(",", ""))
        if nums:
            v = float(nums[0])
            pct = v / 100.0 if v > 1.0 else v
    except Exception:
        pct = 0.6
    pct = max(0.05, min(0.98, pct))
    end = 180 + 180 * pct
    d.arc([cx - r, cy - r, cx + r, cy + r], start=180, end=int(end),
          fill=style.c("accent"), width=22)


def _draw_illustration_onto(d, box, style, kind):
    x0, y0, x1, y1 = box
    col = style.c("accent")
    w, h = x1 - x0, y1 - y0
    if kind in ("learn", "study"):
        cx, cy = x0 + w * 0.5, y0 + h * 0.4
        rad = min(w, h) * 0.22
        d.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], outline=col, width=4)
        d.line([cx, cy + rad, cx, cy + rad + h * 0.18], fill=col, width=4)
        d.line([cx - rad * 0.5, cy + rad + h * 0.18, cx + rad * 0.5, cy + rad + h * 0.18],
               fill=col, width=4)
    elif kind in ("face", "person"):
        cx, cy = x0 + w * 0.5, y0 + h * 0.42
        rad = min(w, h) * 0.2
        d.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], outline=col, width=4)
        d.line([cx - rad, cy + rad + 10, cx + rad, cy + rad + 10], fill=col, width=4)
    elif kind in ("grow", "chart"):
        d.line([x0 + 20, y1 - 20, x1 - 20, y1 - 20], fill=col, width=3)
        pts = [(x0 + 20, y1 - 40), (x0 + w * 0.4, y0 + h * 0.6),
               (x0 + w * 0.7, y0 + h * 0.4), (x1 - 20, y0 + 20)]
        d.line(pts, fill=col, width=4)
    else:
        d.rectangle([x0 + 20, y0 + 20, x1 - 20, y1 - 20], outline=col, width=3)


# ================= 1. 封面 cover =================
def cover(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    m = canvas.metrics()
    # 封面即出图：standard_explain 且首图存在时，封面直接铺大图（第一帧就出图）
    fig_spec = scene.get("figure", {}) or {}
    fig_path = fig_spec.get("path")
    if fig_path and os.path.exists(fig_path):
        kicker = scene.get("kicker", "")
        title = scene.get("title", "")
        tx = m["content_left"] + 22
        yy = 200
        if kicker:
            kf = canvas.get_font("en_b", 30)
            canvas.text_block([kicker.upper()], tx, yy, kf, style.c("accent"),
                              "kicker", "kicker", line_h=40, anchor_x="la",
                              shadow=True, enter="fade")
            yy += 44
        tf = canvas.get_font("cn_b", 56)
        tlines = wrap_cjk(title, tf, m["content_right_none"] - 140)[:2]
        th = int(tf.getmetrics()[0] * 1.18)
        canvas.text_block(tlines, tx, yy, tf, style.c("text"), "title", "title",
                          line_h=th, anchor_x="la", shadow=True, enter="fade")
        bar_y = yy + len(tlines) * th + 12
        canvas.accent_bar(tx, bar_y, 320, 9, style.c("accent"))
        try:
            fig = Image.open(fig_path).convert("RGBA")
        except Exception:
            fig = None
        if fig:
            # 方向自适应：竖屏 1080 宽保留原值；横屏 1920 宽撑开铺满
            if canvas.portrait:
                fx0, fx1 = 70, 1010
                fy0, fy1 = bar_y + 30, 1180
            else:
                fx0, fx1 = 60, int(canvas.w * 0.97)
                fy0, fy1 = bar_y + 30, min(int(canvas.h * 0.92), 1010)
            fw_box = fx1 - fx0; fh_box = fy1 - fy0
            aspect = fig.width / fig.height
            nw = fw_box; nh = nw / aspect
            if nh > fh_box:
                nh = fh_box; nw = nh * aspect
            nw, nh = max(1, int(nw)), max(1, int(nh))
            disp_x = fx0 + (fw_box - nw) // 2
            disp_y = fy0 + (fh_box - nh) // 2
            pad = 14

            def _panel(d, l, _w=nw + pad * 2, _h=nh + pad * 2):
                d.rounded_rectangle([0, 0, _w, _h], radius=style.card_radius,
                                    fill=(255, 255, 255, 46),
                                    outline=style.c("accent"), width=5)

            canvas.capture((disp_x - pad, disp_y - pad, disp_x + nw + pad, disp_y + nh + pad),
                           _panel, "deco", "cover_panel", register=False,
                           enter="fade", appear_at=0.0, fixed_enter=True)
            canvas.paste_photo(fig.resize((nw, nh), Image.LANCZOS),
                               (disp_x, disp_y, disp_x + nw, disp_y + nh),
                               label="figure", enter="fade", appear_at=0.0, fixed_enter=True)
        _draw_host(canvas, style, host, host_box)
        canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))
        return
    # 原逻辑
    canvas.header(scene.get("title", ""), scene.get("kicker"), scene.get("subtitle"))
    if host:
        _draw_host(canvas, style, host, host_box)
    elif photos:
        img, framing = photos[0]
        from . import photo as P
        target_h = m["cover_photo_h"]
        layer = P.build_photo_layer(img, style, target_h, framing)
        lw, lh = layer.size
        x0 = (canvas.w - lw) // 2
        y0 = m["cover_photo_y"]
        canvas.paste_photo(layer, (x0, y0, x0 + lw, y0 + lh), label="photo_0")
    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 2. 步骤 steps =================
def steps(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    m = canvas.metrics()
    canvas.header(scene.get("title", ""), scene.get("kicker"))
    has_host = bool(host)
    x0, x1 = _text_col(bool(photos) and not has_host, has_host, m)
    if not has_host:
        _place_photos(canvas, style, photos, _photo_boxes(len(photos), m))
    _draw_host(canvas, style, host, host_box)
    items = scene.get("steps", [])
    y = m["step_start"]
    cx = (x0 + x1) / 2
    for idx, it in enumerate(items[:4], start=1):
        if isinstance(it, dict):
            no = it.get("n", "") or str(idx)
            tt = it.get("t", "")
            dd = it.get("d", "")
        else:
            no = str(idx)
            tt = str(it)
            dd = ""
        nf = canvas.get_font("en_b", 46)
        canvas.text_block([no], x0 + 40, y, nf, style.c("accent"), "step_no", "step_no",
                          line_h=60, anchor_x="mm")
        tf = canvas.get_font("cn_b", 40)
        canvas.text_block([tt], x0 + 110, y + 4, tf, style.c("text"),
                          "step_title", "step_title", line_h=52, anchor_x="lm")
        df = canvas.get_font("cn", 30)
        dl = wrap_cjk(dd, df, x1 - x0 - 110)
        canvas.text_block(dl, x0 + 110, y + 60, df, style.c("text_dim"),
                          "step_desc", "step_desc", line_h=40, anchor_x="lm")
        y += m["step_gap"]
    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 3. 分屏插画 split =================
def split(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    m = canvas.metrics()
    canvas.header(scene.get("title", ""), scene.get("kicker"), scene.get("subtitle"))
    has_host = bool(host)
    x0, x1 = _text_col(bool(photos) and not has_host, has_host, m)
    if not has_host:
        _place_photos(canvas, style, photos, _photo_boxes(len(photos), m))
    _draw_host(canvas, style, host, host_box)
    cx = (x0 + x1) / 2
    body = scene.get("body", "")
    bf = canvas.get_font("cn", 42)
    bl = wrap_cjk(body, bf, x1 - x0)
    bl = bl[:6]
    canvas.text_block(bl, cx, m["body_y"], bf, style.c("text"), "bullet", "split_body",
                      line_h=58, anchor_x="mm")
    illu = scene.get("illustration")
    valid_illus = {"learn", "study", "face", "person", "grow", "chart"}
    if illu and illu in valid_illus:
        bx0, by0, bx1, by1 = x0, m["illus_top"], x1, m["illus_bot"]
        canvas.capture((bx0, by0, bx1, by1),
                       lambda d, l: _draw_illustration_onto(d, (0, 0, bx1 - bx0, by1 - by0), style, illu),
                       "deco", "illustration", register=False, enter="zoom")
    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 4. 半圆数据 data =================
def data(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    m = canvas.metrics()
    canvas.header(scene.get("title", ""), scene.get("kicker"))
    has_host = bool(host)
    x0, x1 = _text_col(bool(photos) and not has_host, has_host, m)
    if not has_host:
        _place_photos(canvas, style, photos, _photo_boxes(len(photos), m))
    _draw_host(canvas, style, host, host_box)
    # 内容区：若有内容照片（且无主播位），右侧排版区需避开左侧照片列
    if photos and not has_host:
        region_x0 = m["photo_x"] + m["photo_w"] + 40
        region_x1 = m["content_right_photos"]
    else:
        region_x0, region_x1 = x0, x1
    cx = (region_x0 + region_x1) / 2
    d = scene.get("data", {})

    # 单指标格式 {value, label, desc}：保留半圆仪表盘
    if d.get("value"):
        value = d.get("value", "0%")
        label = d.get("label", "")
        r = m["data_r"]
        cy = m["data_cy"]
        canvas.capture((int(cx - r), cy - r, int(cx + r), cy + r),
                       lambda d2, l: _semicircle_onto(d2, r, r, r, style, value),
                       "deco", "semicircle", register=False, enter="zoom")
        vf = canvas.get_font("en_b", 64)
        canvas.text_block([value], cx, cy - 60, vf, style.c("accent"), "metric", "metric",
                          line_h=72, anchor_x="mm")
        lf = canvas.get_font("cn_b", 40)
        canvas.text_block([label], cx, cy + 180, lf, style.c("text"), "label", "data_label",
                          line_h=50, anchor_x="mm")
        desc = d.get("desc", "")
        if desc:
            df = canvas.get_font("cn", 32)
            dl = wrap_cjk(desc, df, region_x1 - region_x0)
            canvas.text_block(dl, cx, cy + 260, df, style.c("text_dim"), "small", "data_desc",
                              line_h=44, anchor_x="mm")
    else:
        # 多指标格式 {"指标":"值", ...}：渲染 2x2 卡片网格，与配音逐项对应
        items = list(d.items())[:4]
        if not items:
            items = [("指标", "0%")]
        cols = 2 if len(items) >= 2 else 1
        rows = (len(items) + cols - 1) // cols

        if canvas.portrait:
            margin_x, gap_x = 40, 20
            cell_h, gap_y = 230, 30
            grid_top = 580          # 标题安全下界以下（标题框约到 542），避免撞标题
        else:
            margin_x, gap_x = 100, 40
            cell_h, gap_y = 180, 30
            grid_top = 240          # 横屏标题在顶部，网格从标题下方起排

        cell_w = ((region_x1 - region_x0) - margin_x * 2 - gap_x * (cols - 1)) / cols
        grid_h = rows * cell_h + (rows - 1) * gap_y
        # 底部不越界保护
        bottom_limit = m["safe"][1] - 40
        if grid_top + grid_h > bottom_limit:
            cell_h = (bottom_limit - grid_top - (rows - 1) * gap_y) / rows
            grid_h = rows * cell_h + (rows - 1) * gap_y

        # 配音把 4 个指标连读，画面必须在 3 秒内全部出现；
        # 显式固定每张卡片的出现时刻，避免被 sync_to_audio 铺得太散。
        metric_leads = [0.50, 1.20, 1.90, 2.60]

        for idx, (label, value) in enumerate(items):
            col = idx % cols
            row = idx // cols
            bx = region_x0 + margin_x + col * (cell_w + gap_x)
            by = grid_top + row * (cell_h + gap_y)
            bx1 = bx + cell_w
            by1 = by + cell_h
            vf = canvas.get_font("en_b", 44 if canvas.portrait else 52)
            lf = canvas.get_font("cn_b", 26 if canvas.portrait else 30)

            def _metric_card(d2, l, bw=cell_w, bh=cell_h,
                             vv=value, ll=label, vfont=vf, lfont=lf):
                _glass_panel_onto(d2, 0, 0, int(bw), int(bh), style)
                d2.text((bw / 2, bh * 0.35), vv, font=vfont,
                        fill=style.c("accent"), anchor="mm")
                d2.text((bw / 2, bh * 0.72), ll, font=lfont,
                        fill=style.c("text"), anchor="mm")

            canvas.capture((int(bx), int(by), int(bx1), int(by1)),
                           _metric_card, "metric", f"metric_card_{idx}",
                           register=True, enter="fade",
                           appear_at=metric_leads[idx])

    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 5. 时间线 timeline =================
def timeline(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    m = canvas.metrics()
    canvas.header(scene.get("title", ""), scene.get("kicker"))
    has_host = bool(host)
    x0, x1 = _text_col(bool(photos) and not has_host, has_host, m)
    if not has_host:
        _place_photos(canvas, style, photos, _photo_boxes(len(photos), m))
    _draw_host(canvas, style, host, host_box)
    nodes = scene.get("nodes", [])
    y = m["tl_y"]
    n = len(nodes)
    x_l, x_r = x0 + 20, x1 - 20
    span = x_r - x_l
    canvas.divider(x_l, y, x_r, y, style.c("line"), width=4)
    for i, nd in enumerate(nodes[:4]):
        px = x_l + span * (i + 0.5) / n if n > 1 else (x_l + x_r) / 2
        r = 26
        canvas.capture((int(px - r - 6), int(y - r - 6), int(px + r + 6), int(y + r + 6)),
                       lambda d, l, _px=px, _y=y, _r=r: d.ellipse(
                           [_px - r - (int(px - r - 6)), _y - r - (int(y - r - 6)),
                            _px + r - (int(px - r - 6)), _y + r - (int(y - r - 6))],
                           fill=style.c("accent")),
                       "deco", "node", register=False, enter="pop")
        nf = canvas.get_font("cn_b", 28)
        canvas.text_block([nd.get("t", "")], px, y - r - 60, nf, style.c("accent"),
                          "node_no", "node_no", line_h=40, anchor_x="mm")
        df = canvas.get_font("cn", 28)
        dl = wrap_cjk(nd.get("d", ""), df, (span / n) - 16)
        canvas.text_block(dl, px, y + r + 16, df, style.c("text_dim"),
                          "node_desc", "node_desc", line_h=36, anchor_x="mm")
    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 6. 玻璃文字卡 glass =================
def glass(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    m = canvas.metrics()
    canvas.header(scene.get("title", ""), scene.get("kicker"))
    has_host = bool(host)
    x0, x1 = _text_col(bool(photos) and not has_host, has_host, m)
    if not has_host:
        _place_photos(canvas, style, photos, _photo_boxes(len(photos), m))
    _draw_host(canvas, style, host, host_box)
    cx = (x0 + x1) / 2
    cw = (x1 - x0)
    bt = scene.get("body_title", "")
    bd = scene.get("body", "")
    tf = canvas.get_font("cn_b", 52)
    tl = wrap_cjk(bt, tf, cw - 80) if bt else []
    bf = canvas.get_font("cn", 34)
    bl = wrap_cjk(bd, bf, cw - 100)[:8] if bd else []
    if not (tl or bl):
        canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))
        return
    th_t = tf.getmetrics()[0] + tf.getmetrics()[1]
    th_b = bf.getmetrics()[0] + bf.getmetrics()[1]
    cy0 = m["glass_y"]
    ch = 120 + len(tl) * 64 + (30 if tl else 0) + len(bl) * 48 + 60
    bx0 = cx - cw / 2
    abs_x0, abs_y0 = int(bx0), int(cy0)

    def _draw(d, l):
        _glass_panel_onto(d, 0, 0, cw, ch, style)
        ty = 90
        if tl:
            line_h = 64
            for ln in tl:
                tw = canvas.measure(ln, tf)[0]
                lx = (cw - tw) / 2
                d.text((lx, ty), ln, font=tf, fill=style.c("text"), anchor="lm")
                canvas.register((abs_x0 + lx, abs_y0 + ty,
                                abs_x0 + lx + tw, abs_y0 + ty + th_t),
                                "card_title", "card_title")
                ty += line_h
            ty += 30
        if bl:
            line_h = 48
            for ln in bl:
                tw = canvas.measure(ln, bf)[0]
                lx = (cw - tw) / 2
                d.text((lx, ty), ln, font=bf, fill=style.c("text_dim"), anchor="lm")
                canvas.register((abs_x0 + lx, abs_y0 + ty,
                                abs_x0 + lx + tw, abs_y0 + ty + th_b),
                                "card_body", "card_body")
                ty += line_h

    canvas.capture((abs_x0, abs_y0, int(bx0 + cw), int(cy0 + ch)),
                   _draw, "card_body", "glass_card", register=False, enter="fade")
    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 7. 大字号重点 highlight =================
def highlight(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    m = canvas.metrics()
    canvas.header(scene.get("title", ""), scene.get("kicker"))
    has_host = bool(host)
    x0, x1 = _text_col(bool(photos) and not has_host, has_host, m)
    if not has_host:
        _place_photos(canvas, style, photos, _photo_boxes(len(photos), m))
    _draw_host(canvas, style, host, host_box)
    cx = (x0 + x1) / 2
    kw = scene.get("keyword", "")
    bf = canvas.get_font("cn_b", 120)
    kl = wrap_cjk(kw, bf, x1 - x0)
    kl = kl[:2]
    canvas.text_block(kl, cx, m["hl_kw_y"], bf, style.c("accent"), "big", "keyword",
                      line_h=130, anchor_x="mm", enter="pop")
    sub = scene.get("sub", "")
    if sub:
        sf = canvas.get_font("cn", 40)
        sl = wrap_cjk(sub, sf, x1 - x0)
        canvas.text_block(sl, cx, m["hl_sub_y"], sf, style.c("text"), "small", "hl_sub",
                          line_h=54, anchor_x="mm")
    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 8. 引述 quote =================
def quote(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    m = canvas.metrics()
    canvas.header(scene.get("title", ""), scene.get("kicker"))
    has_host = bool(host)
    x0, x1 = _text_col(bool(photos) and not has_host, has_host, m)
    if not has_host:
        _place_photos(canvas, style, photos, _photo_boxes(len(photos), m))
    _draw_host(canvas, style, host, host_box)
    cx = (x0 + x1) / 2
    qt = scene.get("quote", "")
    qf = canvas.get_font("cn", 46)
    ql = wrap_cjk(qt, qf, x1 - x0)
    ql = ql[:6]
    canvas.text_block(ql, cx, m["quote_y"], qf, style.c("text"), "quote", "quote",
                      line_h=64, anchor_x="mm")
    src = scene.get("source", "")
    if src:
        sf = canvas.get_font("cn_b", 34)
        canvas.text_block([f"—— {src}"], cx, m["quote_src_y"], sf, style.c("accent"),
                          "quote_src", "quote_src", line_h=44, anchor_x="mm")
    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 9. 对比 compare =================
def compare(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    m = canvas.metrics()
    canvas.header(scene.get("title", ""), scene.get("kicker"))
    has_host = bool(host)
    x0, x1 = (m["content_left"], m["content_right_host"]) if has_host else (m["content_left"], m["content_right_none"])
    boxes = []
    if photos and not has_host:
        boxes = m["cmp_photo_boxes"]
        _place_photos(canvas, style, photos, boxes)
        y_top = m["cmp_top"]
        y_bot = m["cmp_bot_photos"]
    else:
        y_top = m["cmp_top"]
        y_bot = m["cmp_bot_nohost"]
    _draw_host(canvas, style, host, host_box)
    cw = (x1 - x0 - 60) / 2
    lx = x0 + cw / 2
    rx = x0 + cw + 60 + cw / 2
    lt = scene.get("compare", {}).get("left_title", "")
    rt = scene.get("compare", {}).get("right_title", "")
    lf = canvas.get_font("cn_b", 44)
    canvas.text_block([lt], lx, y_top, lf, style.c("accent"), "compare_l", "cmp_lt",
                      line_h=54, anchor_x="mm")
    canvas.text_block([rt], rx, y_top, lf, style.c("accent2"), "compare_r", "cmp_rt",
                      line_h=54, anchor_x="mm")
    canvas.divider(x0 + cw + 30, y_top + 20, x0 + cw + 30, y_bot - 20,
                   style.c("line"), width=2)
    li = scene.get("compare", {}).get("left_items", [])
    ri = scene.get("compare", {}).get("right_items", [])
    y = y_top + 90
    ifont = canvas.get_font("cn", 32)
    for a in li[:8]:
        al = wrap_cjk(a, ifont, cw - 40)
        canvas.text_block(al, lx, y, ifont, style.c("text"), "compare_l", "cmp_li",
                          line_h=42, anchor_x="mm")
        y += 48
    y = y_top + 90
    for b in ri[:8]:
        bl = wrap_cjk(b, ifont, cw - 40)
        canvas.text_block(bl, rx, y, ifont, style.c("text"), "compare_r", "cmp_ri",
                          line_h=42, anchor_x="mm")
        y += 48
    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 10. 标准原图 + 重点高亮 figure =================
def _split_bullets(text, max_n=5):
    """把讲解文字按中英文句末标点 / 换行拆成子弹点。"""
    if not text:
        return []
    parts = re.split(r"[。；;！!？?\n]", text)
    out = [p.strip() for p in parts if p.strip()]
    return out[:max_n]


_BULLET_ENTERS = ["slide_right", "slide_left", "zoom", "pop"]


def _extract_keywords(text, n=3):
    """从讲解文字里提取数字+单位/关键词，用于右侧重点卡大字高亮。"""
    if not text:
        return []
    found = []
    patterns = [
        r"\d+(?:\.\d+)?\s*(?:mm|cm|m|inch|in|英寸|寸)\b",
        r"\d+(?:\.\d+)?(?:\"|英寸|in|寸)\b",
        r"≥\s*\d+[^。，；;！!？?\n]*",
        r"\d+%",
    ]
    for pat in patterns:
        for m in re.finditer(pat, text, flags=re.IGNORECASE):
            s = m.group().strip()
            if s and s not in found and len(s) < 30:
                found.append(s)
            if len(found) >= n:
                return found[:n]
    for p in _split_bullets(text):
        if p and p not in found and len(p) < 25:
            found.append(p)
        if len(found) >= n:
            break
    return found[:n]


def figure(scene, canvas, style, photos, t, dur, host=None, host_box=None):
    """标准讲解 figure 版式 v5：竖屏纵向——标准原图在上(放大)，重点提炼在下(紧凑)。

    修复（针对反复投诉）：
      1) 全部文字(标题/关键词/子弹点/徽标)均登记入库，文字互叠由三道闸机械拦截，
         渲染期 strict 直接报错；杜绝"字体重叠"再次带病出片。
      2) 取消"把标签压到卡片上"的旧做法，改在标准图上画编号徽标(①②③)，
         与下方编号子弹点一一对应，互不压字。
      3) glow_text 改为干净发光(非重影)；底栏用半透明(150 alpha)替代不透明卡，
         工业背景透过，恢复"背景图可见"。
    """
    m = canvas.metrics()
    s = style

    # ---- 顶部紧凑标题（落在背景上，带轻阴影保证可读）----
    kicker = scene.get("kicker", "")
    title = scene.get("title", "")
    tx = m["content_left"] + 22
    yy = 196
    if kicker:
        kf = canvas.get_font("en_b", 28)
        canvas.text_block([kicker.upper()], tx, yy, kf, s.c("accent"),
                          "kicker", "kicker", line_h=38, anchor_x="la",
                          shadow=True, enter="fade", appear_at=0.0, fixed_enter=True)
        yy += 44
    tf = canvas.get_font("cn_b", 50)
    tlines = wrap_cjk(title, tf, m["content_right_none"] - 140)[:2]
    th = int(tf.getmetrics()[0] * 1.18)
    canvas.text_block(tlines, tx, yy, tf, s.c("text"), "title", "title",
                      line_h=th, anchor_x="la", shadow=True, enter="fade",
                      appear_at=0.0, fixed_enter=True)

    # ---- 主播（右侧竖条，最后画在最上层，避免被底栏压住）----
    no_host = scene.get("no_host", False)
    has_host = bool(host) and not no_host

    # ---- 标准原图：方向自适应 ----
    if canvas.portrait:
        fx0, fx1 = 70, 1010
        fy0, fy1 = yy + th + 30, 1050
    else:
        fx0, fx1 = 60, int(canvas.w * 0.97)
        fy0, fy1 = yy + th + 30, min(int(canvas.h * 0.88), 1010)
    fw_box, fh_box = fx1 - fx0, fy1 - fy0

    fig_spec = scene.get("figure", {}) or {}
    fig_path = fig_spec.get("path")
    fx = fy = fw = fh = 0
    if fig_path and os.path.exists(fig_path):
        fig = Image.open(fig_path).convert("RGBA")
        aspect = fig.width / fig.height
        nw = fw_box
        nh = nw / aspect
        if nh > fh_box:
            nh = fh_box
            nw = nh * aspect
        nw, nh = max(1, int(nw)), max(1, int(nh))
        disp_x = fx0 + (fw_box - nw) // 2
        disp_y = fy0 + (fh_box - nh) // 2
        pad = 12

        def _frame(d, l, _w=nw + pad * 2, _h=nh + pad * 2):
            d.rounded_rectangle([0, 0, _w, _h], radius=style.card_radius,
                                fill=(255, 255, 255, 38), outline=s.c("accent"), width=5)

        canvas.capture((disp_x - pad, disp_y - pad, disp_x + nw + pad, disp_y + nh + pad),
                       _frame, "deco", "fig_frame", register=False,
                       enter="fade", appear_at=0.0, fixed_enter=True)
        resized = fig.resize((nw, nh), Image.LANCZOS)
        canvas.paste_photo(resized, (disp_x, disp_y, disp_x + nw, disp_y + nh),
                           label="figure", enter="fade", appear_at=0.0, fixed_enter=True)
        fx, fy, fw, fh = disp_x, disp_y, nw, nh
    else:
        fx, fy, fw, fh = fx0, fy0, fw_box, fh_box

    # ---- 标准图上画重点（高亮框由 brief 的 hl_rects 真实锚定，不再猜坐标）----
    highlights = fig_spec.get("hl_rects") or fig_spec.get("highlights") or []
    for i, hl in enumerate(highlights):
        nx = float(hl.get("x", 0)); ny = float(hl.get("y", 0))
        nw_hl = float(hl.get("w", 0.1)); nh_hl = float(hl.get("h", 0.1))
        ax0 = fx + fw * nx; ay0 = fy + fh * ny
        ax1 = ax0 + fw * nw_hl; ay1 = ay0 + fh * nh_hl
        ax0, ay0, ax1, ay1 = int(ax0), int(ay0), int(ax1), int(ay1)
        ax0 = max(fx, ax0); ay0 = max(fy, ay0)
        ax1 = min(fx + fw, ax1); ay1 = min(fy + fh, ay1)
        if ax1 <= ax0 or ay1 <= ay0:
            continue
        # 高亮色：用强对比的红橙（而非发白的浅金），白纸上清晰可辨，且区别于界面金饰。
        c = (235, 70, 35)
        style_hl = hl.get("style", "underline")
        if style_hl == "box":
            # 向内留 6px 间隙框住文字，绝不用实心填充压字
            m = 6
            bx0, by0, bx1, by1 = ax0 - m, ay0 - m, ax1 + m, ay1 + m
            def _b(d, l, _w=bx1 - bx0, _h=by1 - by0):
                d.rounded_rectangle([3, 3, _w - 3, _h - 3], radius=8, outline=c, width=6)
            # 读取 brief 指定的入场动画（zoom/pop/slide_left/...），让不同要点用不同 PPT 出场风格；
            # 不传则回退 fade，向后兼容其它视频。
            canvas.capture((bx0, by0, bx1, by1), _b, "deco", f"hl_{i}",
                           register=False, enter=hl.get("enter", "fade"), fixed_enter=True)
        elif style_hl == "underline":
            # 关键修复：线必须画在文字"下方"留白处（ay1+gap），不能压在字上
            uy = min(ay1 + 9, fy + fh - 8)
            canvas.underline(ax0, uy, ax1, uy, c, width=9, fixed_enter=True)
        elif style_hl == "row_band":
            # alpha 降到 38：轻底色提示行，不糊字（左标条在 margin，见 canvas.row_band）
            canvas.row_band(ax0, ay0, ax1, ay1, c, alpha=38, fixed_enter=True)
        elif style_hl == "dot":
            # 移到文字左侧 margin 的标记点，不压字
            canvas.marker_dot(ax0 - 24, (ay0 + ay1) // 2, 15, c, fixed_enter=True)
        elif style_hl == "magnifier":
            r = min(ax1 - ax0, ay1 - ay0) // 2
            canvas.magnifier((ax0 + ax1) // 2, (ay0 + ay1) // 2, r, c, fixed_enter=True)
        elif style_hl == "arrow":
            cx = (ax0 + ax1) // 2; cy = (ay0 + ay1) // 2
            sx = ax0 - 64 if (ax0 - fx) > 64 else ax1 + 64
            canvas.callout_arrow(sx, cy, cx, cy, c, width=6, fixed_enter=True)
            canvas.marker_dot(cx, cy, 14, c, fixed_enter=True)

    # ---- 下半区：方向自适应（竖屏保留原 60~1020/1620；横屏撑开且不超字幕 1075）----
    if canvas.portrait:
        px0, px1 = 60, 1020
        py0, py1 = fy1 + 24, 1620
    else:
        px0, px1 = 60, canvas.w - 60
        py0, py1 = fy1 + 24, min(int(canvas.h * 0.96), 1040)
    pw, ph = px1 - px0, py1 - py0

    def _panel(d, l):
        d.rounded_rectangle([0, 0, pw, ph], radius=style.card_radius,
                            fill=(14, 22, 46, 150), outline=s.c("accent2"), width=3)
        d.line([(20, 10), (pw - 20, 10)], fill=s.c("accent"), width=3)

    canvas.capture((px0, py0, px1, py1), _panel, "deco", "bottom_panel",
                   register=False, enter="fade", appear_at=0.0, fixed_enter=True)

    # 栏标题
    canvas.text_block(["要点提炼"], px0 + 30, py0 + 26, canvas.get_font("cn_b", 28),
                      s.c("accent2"), "explain", "panel_title", line_h=34,
                      anchor_x="la", shadow=False, enter="fade",
                      appear_at=0.0, fixed_enter=True)

    # 关键词（多色发光大字，横向排布，按测量间距保证不互叠）
    keywords = fig_spec.get("keywords") or _extract_keywords(scene.get("explain", ""), 3)
    gap = 44
    kw_font_size = 34
    max_kw_w = pw - 80

    def _measure_kw(size):
        boxes = []
        tot = 0
        for kw in keywords[:3]:
            has_cjk = any(0x4e00 <= ord(ch) <= 0x9fff for ch in kw)
            kf = canvas.get_font("cn_b" if has_cjk else "en_b", size)
            tw, th = canvas.measure(kw, kf)
            boxes.append((kw, kf, tw, th))
            tot += tw + gap
        tot -= gap
        return boxes, tot

    kw_boxes, total_w = _measure_kw(kw_font_size)
    if total_w > max_kw_w:
        scale = max_kw_w / total_w
        kw_font_size = max(20, int(kw_font_size * scale))
        kw_boxes, total_w = _measure_kw(kw_font_size)
    start_x = px0 + (pw - total_w) // 2
    kw_y = py0 + 100
    for idx, (kw, kf, tw, th) in enumerate(kw_boxes):
        cx = start_x + tw / 2
        col = s.c("accent") if idx % 2 == 0 else s.c("accent2")
        canvas.glow_text(kw, cx, kw_y + th / 2, kf, col,
                         kind="explain", label=f"kw_{idx}",
                         enter="zoom", appear_at=0.0, fixed_enter=True)
        start_x += tw + gap
    max_th = max((t[3] for t in kw_boxes), default=0)
    kw_block_bottom = kw_y + max_th + 30

    # 子弹点（编号与图上徽标对应，逐步飞入；右界避让主播）
    explain = scene.get("explain", "")
    bullets = _split_bullets(explain)
    bx = px0 + 30
    bw = (px1 - 30) - bx
    if has_host:
        bw = min(bw, 700 - bx)
    bl_font = canvas.get_font("cn", 27)
    line_h = 40
    y = kw_block_bottom + 6
    max_bullets = 5
    for i, b in enumerate(bullets[:max_bullets]):
        full = f"{i + 1}. " + b
        fl = wrap_cjk(full, bl_font, bw - 10)[:3]
        h = line_h * len(fl)
        if y + h > py1 - 24:
            break
        canvas.text_block(fl, bx, y, bl_font, s.c("text"), "explain", f"bullet_{i}",
                          line_h=line_h, anchor_x="la", shadow=False,
                          enter=_BULLET_ENTERS[i % len(_BULLET_ENTERS)])
        y += h + 10

    # 主播（最上层）
    _draw_host(canvas, style, host if has_host else None, host_box)

    canvas.subtitle(scene.get("caption", ""), scene.get("caption_en"))


# ================= 派发 =================
LAYOUTS = {
    "cover": cover,
    "steps": steps,
    "split": split,
    "data": data,
    "timeline": timeline,
    "glass": glass,
    "highlight": highlight,
    "quote": quote,
    "compare": compare,
    "figure": figure,
}


def draw_scene(scene, canvas, style, photos=None, host=None, t=1.0, dur=3.0,
               host_box=None):
    photos = photos or []
    fn = LAYOUTS.get(scene.get("scene_type", "cover"), cover)
    canvas.reset_reg()
    fn(scene, canvas, style, photos, t, dur, host=host, host_box=host_box)
