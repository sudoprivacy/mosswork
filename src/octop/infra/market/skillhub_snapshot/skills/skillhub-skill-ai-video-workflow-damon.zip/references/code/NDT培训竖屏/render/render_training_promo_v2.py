# -*- coding: utf-8 -*-
# 竖屏爆感培训宣传视频 v2 —— 完整动画成片渲染器。
# 结构（参考2深蓝青白风格）：焦虑开场 → 真实招聘数据焦虑 → 转折推 TÜV 培训
#   → 证书硬通货 → 专业性/待遇/职位提升 → 六宫格 → 行动号召。
# 复用 render_preview_frames.py 已通过布局预检的坐标；动画仅做入场/淡入/弹入，
# 不移动最终落点，确保不跑出安全区。
# 隐私红线：不放银行/时间地点/联系方式/真实证书人名编号，证书样张已加盖"样张"。
import os
import sys
import math
import asyncio
import importlib.util
import subprocess

ROOT = r"D:\Workbuddy缓存位置\培训宣传视频工作流"
RENDER = os.path.join(ROOT, "render")
PREVIEW_PATH = os.path.join(RENDER, "render_preview_frames.py")
WORK = r"D:\workbuddy\cache\promo_v3"
FINAL_OUTPUT_DIR = r"D:\微信小程序\标准视频库"
OUT_MP4 = os.path.join(FINAL_OUTPUT_DIR, "TUV_NDT_promo_vertical.mp4")
FFMPEG = r"C:\Users\Damon\AppData\Local\Programs\Python\Python312\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe"
TTS_PY = r"C:\Users\Damon\AppData\Local\Programs\Python\Python312\python.exe"
FPS = 30

# 复用 preview 脚本里的所有校验过坐标的 helper / 字体 / 配色
spec = importlib.util.spec_from_file_location("rpf", PREVIEW_PATH)
rpf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rpf)
W, H = rpf.W, rpf.H
SAFE_L, SAFE_R = rpf.SAFE_L, rpf.SAFE_R
FONTS = rpf.FONTS
DARK = rpf.DARK; DARK2 = rpf.DARK2; CYAN = rpf.CYAN; WHITE = rpf.WHITE
GRAY = rpf.GRAY; RED_ACC = rpf.RED_ACC; GOLD = rpf.GOLD; PANEL = rpf.PANEL
SHADOW = rpf.SHADOW
build_bg = rpf.build_bg
rr = rpf.rr
draw_badges = rpf.draw_badges
text_size = rpf.text_size
crisp_text = rpf.crisp_text
CERT_PATH = rpf.CERT_PATH

# 布局校验器（仅最终静止态 p=1.0 时启用，复用 preview 的 COLLECTOR 思路）
_REC = None


class _Collector:
    def __init__(self):
        self.items = []

    def add(self, box, label):
        self.items.append((box, label))

    def check(self, tol=4):
        bad = []
        for i in range(len(self.items)):
            b1, l1 = self.items[i]
            for j in range(i + 1, len(self.items)):
                b2, l2 = self.items[j]
                ix = min(b1[2], b2[2]) - max(b1[0], b2[0])
                iy = min(b1[3], b2[3]) - max(b1[1], b2[1])
                if ix > tol and iy > tol:
                    bad.append((l1, l2, int(ix), int(iy)))
        return bad


def validate_layout():
    """对每场景最终静止态做：出画 + 文字互相重叠 检测。返回问题列表。"""
    global _REC
    problems = []
    for name, _, fn in SCENES:
        c = _Collector()
        _REC = c
        rpf.COLLECTOR = c
        try:
            fn(1.0)
        finally:
            _REC = None
            rpf.COLLECTOR = None
        # 出画检测
        for box, label in c.items:
            if box[0] < SAFE_L - 2 or box[2] > SAFE_R + 2 or box[1] < 0 or box[3] > H:
                problems.append((name, "出画", label, box))
        # 重叠检测
        for l1, l2, ix, iy in c.check():
            problems.append((name, "重叠", f"{l1} × {l2} {ix}x{iy}", None))
    return problems
Image = rpf.Image
ImageDraw = rpf.ImageDraw
ImageFont = rpf.ImageFont
ImageEnhance = rpf.ImageEnhance

os.makedirs(WORK, exist_ok=True)
os.makedirs(FINAL_OUTPUT_DIR, exist_ok=True)


# ---------- 数学工具 ----------
def clamp(v, a=0.0, b=1.0):
    return max(a, min(b, v))


def ease_out(t):
    return 1 - (1 - t) ** 3


def ease_in_out(t):
    t = clamp(t)
    return t * t * (3 - 2 * t)


def lerp(a, b, t):
    return a + (b - a) * t


def appear(p, start, end):
    return clamp((p - start) / (end - start))


# ---------- 带 alpha/缩放 的文字合成 ----------
def blit_text(im, pos, text, font, fill, anchor="mm", alpha=255, scale=1.0,
              shadow=True, shadow_col=SHADOW):
    tw, th = text_size(font, text)
    pad = 26
    lw, lh = tw + pad * 2, th + pad * 2
    layer = Image.new("RGBA", (lw, lh), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    if shadow:
        ld.text((pad + 3, pad + 3), text, font=font, fill=shadow_col)
    ld.text((pad, pad), text, font=font, fill=fill)
    if scale != 1.0:
        layer = layer.resize((max(1, int(lw * scale)), max(1, int(lh * scale))),
                              Image.LANCZOS)
    if alpha < 255:
        layer.putalpha(layer.split()[3].point(lambda a: int(a * alpha / 255)))
    w, h = layer.size
    x = y = 0
    if anchor == "mm":
        x, y = pos[0] - w // 2, pos[1] - h // 2
    elif anchor == "lt":
        x, y = pos[0], pos[1]
    elif anchor == "lm":
        x, y = pos[0], pos[1] - h // 2
    elif anchor == "rm":
        x, y = pos[0] - w, pos[1] - h // 2
    elif anchor == "rt":
        x, y = pos[0] - w, pos[1]
    else:
        x, y = pos[0] - w // 2, pos[1] - h // 2
    # 记录最终落点包围盒供布局校验
    if _REC is not None:
        _REC.add((int(round(x + pad * scale)), int(round(y + pad * scale)),
                  int(round(x + w - pad * scale)), int(round(y + h - pad * scale))),
                 text)
    im.paste(layer, (int(round(x)), int(round(y))), layer)


def blit_panel(im, box, radius, fill, outline, width, alpha=255):
    """带 alpha 的圆角面板合成。"""
    x0, y0, x1, y1 = [int(round(v)) for v in box]
    w, h = x1 - x0, y1 - y0
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    ld.rounded_rectangle([0, 0, w - 1, h - 1], radius=radius,
                         fill=fill, outline=outline, width=width)
    if alpha < 255:
        layer.putalpha(layer.split()[3].point(lambda a: int(a * alpha / 255)))
    im.paste(layer, (x0, y0), layer)


# ---------- 场景定义 ----------
# 每个场景: (name, narration_text, render_fn)
# render_fn(im, p) 在已含 bg+badges 的 RGBA 图上叠加动画内容

_BASE_CACHE = None


def base_frame():
    """基础帧(背景+角标)只构建一次并缓存，逐帧 copy，避免每帧重做 ImageEnhance。"""
    global _BASE_CACHE
    if _BASE_CACHE is None:
        im = build_bg().convert("RGBA")
        d = ImageDraw.Draw(im)
        draw_badges(d)
        _BASE_CACHE = im
    base = _BASE_CACHE.copy()
    return base, ImageDraw.Draw(base)


_CERT_CACHE = None


def _get_cert():
    """证书模板只打开/缩放一次并缓存，逐帧仅调 alpha 与位置。"""
    global _CERT_CACHE
    if _CERT_CACHE is None:
        cert = Image.open(CERT_PATH).convert("RGBA")
        cw, ch = cert.size
        cert = cert.crop((40, 220, cw - 40, ch - 150))
        cw, ch = cert.size
        target_w = 960
        scale = target_w / cw
        _CERT_CACHE = cert.resize((target_w, int(ch * scale)), Image.LANCZOS)
    return _CERT_CACHE


def scene_cover(p):
    im, d = base_frame()
    # kicker 放顶部安全区下方，制造数据背书感
    kp = appear(p, 0.0, 0.08)
    blit_text(im, (W // 2, 300), "两个月真实招聘数据",
              FONTS["cn28"], GRAY, alpha=int(kp * 255))
    # 主标题：3 行短句，垂直居中
    lines = [("你的简历", CYAN), ("还在为没有 NDT 证书", CYAN), ("被卡住？", WHITE)]
    cy = 620
    base = 0.06
    for i, (txt, col) in enumerate(lines):
        lp = ease_out(appear(p, base + i * 0.05, base + i * 0.05 + 0.12))
        blit_text(im, (W // 2, cy - 144 + i * 144), txt, FONTS["cn_b72"], col,
                  alpha=int(lp * 255), scale=lerp(0.70, 1.0, lp))
    # 副标题 + 红色焦虑线，整体下移
    sp = appear(p, 0.28, 0.42)
    blit_text(im, (W // 2, 920), "NDT 已从加分项，变成硬门槛",
              FONTS["cn36"], GRAY, alpha=int(sp * 255))
    rp = appear(p, 0.46, 0.62)
    if rp > 0:
        d.line([(W // 2 - 180, 990), (W // 2 + 180, 990)],
               fill=RED_ACC, width=3)
        blit_text(im, (W // 2, 1040), "无证 = 硬门槛", FONTS["cn_b36"], RED_ACC,
                  alpha=int(rp * 255))
    # 再补一句场景化痛点，填起中下部
    ep = appear(p, 0.66, 0.82)
    blit_text(im, (W // 2, 1200), "项目卡壳 · 求职被刷 · 出海没门",
              FONTS["cn32"], WHITE, alpha=int(ep * 255))
    # 底部固定字幕，始终可见
    blit_text(im, (W // 2, rpf.SAFE_B), "没有这张证，门槛都摸不到",
              FONTS["cn32"], WHITE, alpha=255)
    return im


def scene_data(p):
    im, d = base_frame()
    # 标题区块适度下移，避开顶部状态栏+角标
    tp = appear(p, 0.0, 0.10)
    blit_text(im, (W // 2, 300), "两个月招聘数据，比焦虑更扎心",
              FONTS["cn_b48"], WHITE, alpha=int(tp * 255))
    blit_text(im, (W // 2, 365), "全部来自真实招聘 · 船海先锋 2026.7.1–8.20",
              FONTS["cn28"], GRAY, alpha=int(tp * 255))
    stats = [
        ("289", "NDT/探伤招聘提及", "占全部 2.2% · 日均约 8 次", GOLD),
        ("45.8%", "NDT 需求集中在长三角", "南通·上海·江阴·启东·扬州", CYAN),
        ("109 次", "焊接证 + NDT 双证同现", "焊接检验也要持证探伤", GOLD),
        ("81.5%", "NDT 岗位要求 6 年以上经验", "企业不愿培养新人", CYAN),
        ("176 次", "英语 + NDT 同现", "涉外项目·海外驻场标配", GOLD),
    ]
    # 卡片居中铺满，避免底部空荡
    ch, step = 200, 230
    y_start = 430
    for i, (num, t1, t2, col) in enumerate(stats):
        lp = ease_out(appear(p, 0.08 + i * 0.05, 0.08 + i * 0.05 + 0.12))
        if lp <= 0:
            continue
        yy = y_start + i * step
        blit_panel(im, [SAFE_L, yy, W - SAFE_L, yy + ch], 16, PANEL, CYAN, 2,
                   alpha=int(lp * 255))
        # 红色警示条，强化焦虑
        d.rectangle([SAFE_L, yy, SAFE_L + 10, yy + ch], fill=RED_ACC)
        blit_text(im, (270, yy + ch // 2), num, FONTS["cn_b56"], col, anchor="rm",
                  alpha=int(lp * 255), scale=lerp(0.70, 1.0, lp))
        blit_text(im, (310, yy + 60), t1, FONTS["cn_b32"], WHITE, anchor="lm",
                  alpha=int(lp * 255))
        blit_text(im, (310, yy + 125), t2, FONTS["cn28"], GRAY, anchor="lm",
                  alpha=int(lp * 255))
    blit_text(im, (W // 2, rpf.SAFE_B), "NDT 从加分项，变成硬门槛",
              FONTS["cn32"], WHITE, alpha=255)
    return im


def scene_turn(p):
    im, d = base_frame()
    # 青色光晕，整体下移居中
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gp = appear(p, 0.0, 0.5)
    gd.ellipse([W // 2 - 340, 560, W // 2 + 340, 1240],
               fill=(34, 211, 238, int(18 * gp)))
    im = Image.alpha_composite(im, glow)
    # 内容块整体下移，填补中下部
    sp = appear(p, 0.05, 0.25)
    blit_text(im, (W // 2, 700), "救星来了！", FONTS["cn_b56"], CYAN,
              alpha=int(sp * 255), scale=lerp(0.80, 1.0, ease_out(sp)))
    mp = ease_out(appear(p, 0.30, 0.55))
    blit_text(im, (W // 2, 880), "TÜV NDT", FONTS["cn_b72"], WHITE,
              alpha=int(mp * 255))
    blit_text(im, (W // 2, 960), "认证培训", FONTS["cn_b72"], WHITE,
              alpha=int(mp * 255))
    d.line([(W // 2 - 260, 1040), (W // 2 + 260, 1040)], fill=CYAN, width=3)
    bp = appear(p, 0.62, 0.85)
    blit_text(im, (W // 2, 1110), "权威资质 · 系统课程 · 直通考核",
              FONTS["cn36"], GRAY, alpha=int(bp * 255))
    blit_text(im, (W // 2, rpf.SAFE_B), "救星来了：TÜV NDT 认证培训",
              FONTS["cn32"], WHITE, alpha=255)
    return im


def scene_cert(p):
    im, d = base_frame()
    tp = appear(p, 0.0, 0.18)
    # 标题区块下移，避开顶部系统 UI
    blit_text(im, (W // 2, 300), "全球互认的硬通货", FONTS["cn_b56"], WHITE,
              alpha=int(tp * 255))
    tags = [("TÜV 授权", CYAN), ("EN ISO 9712", WHITE), ("PED / SNT-TC-1A", GOLD)]
    total_w = sum([FONTS["cn28"].getlength(t[0]) + 40 for t in tags]) + 40
    x = (W - total_w) // 2
    y = 365
    for i, (txt, col) in enumerate(tags):
        lp = appear(p, 0.12 + i * 0.07, 0.12 + i * 0.07 + 0.18)
        tw = FONTS["cn28"].getlength(txt) + 40
        blit_panel(im, [x, y, x + tw, y + 56], 28, (*DARK2, 200), col, 2,
                   alpha=int(lp * 255))
        blit_text(im, (x + tw // 2, y + 28), txt, FONTS["cn28"], col,
                  alpha=int(lp * 255))
        x += tw + 20
    # 证书模板淡入+轻微放大（缩放已缓存，仅调 alpha 与位置），整体下移居中
    cert = _get_cert().copy()
    cp = ease_out(appear(p, 0.30, 0.75))
    cert.putalpha(cert.split()[3].point(lambda a: int(a * cp)))
    cx = (W - cert.width) // 2
    cy = 960
    top = int(cy - cert.height // 2 - (1 - cp) * 40)
    im.paste(cert, (cx, top), cert)
    # 样张印章
    sd = ImageDraw.Draw(im)
    sx1, sx2 = W - 300, W - 80
    rr(sd, [sx1, cy + cert.height // 2 - 90, sx2, cy + cert.height // 2 - 20],
       8, fill=(244, 63, 94, 200), outline=WHITE, width=2)
    blit_text(im, ((sx1 + sx2) // 2, cy + cert.height // 2 - 55), "样张 SAMPLE",
              FONTS["cn_b32"], WHITE, alpha=255)
    blit_text(im, (W // 2, rpf.SAFE_B), "考核通过即颁 EN ISO 9712 证书，官网可查",
              FONTS["cn32"], WHITE, alpha=255)
    return im


def scene_value(p):
    im, d = base_frame()
    tp = appear(p, 0.0, 0.18)
    # 标题下移
    blit_text(im, (W // 2, 300), "一张证，打开门槛，也打开天花板",
              FONTS["cn_b56"], WHITE, alpha=int(tp * 255))
    cards = [
        ("专业性", CYAN, "国际互认 · 全球通行",
         "EN ISO 9712 / PED / SNT-TC-1A 全覆盖", "专"),
        ("待遇", GOLD, "复合资质，更高溢价",
         "焊接证+NDT 双证 109 次", "薪"),
        ("职位", CYAN, "持证才进得去",
         "长三角 45.8% · 涉外 176 次 · 6年+ 81.5%", "职"),
    ]
    # 三张卡片在可用区域内垂直居中
    ch, gap = 260, 40
    block_h = 3 * ch + 2 * gap
    top = (380 + rpf.SAFE_B - 80) // 2 - block_h // 2
    for i, (label, col, title, sub, icon) in enumerate(cards):
        lp = ease_out(appear(p, 0.10 + i * 0.10, 0.10 + i * 0.10 + 0.22))
        if lp <= 0:
            continue
        yy = top + i * (ch + gap)
        blit_panel(im, [60, yy, W - 60, yy + ch], 18, PANEL, col, 2,
                   alpha=int(lp * 255))
        # 左侧色块图标
        blit_panel(im, [92, yy + 70, 180, yy + 190], 16, (*col[:3], 60), col, 3,
                   alpha=int(lp * 255))
        blit_text(im, (136, yy + 130), icon, FONTS["cn_b72"], col,
                  alpha=int(lp * 255))
        blit_text(im, (220, yy + 68), label, FONTS["cn_b40"], col, anchor="lm",
                  alpha=int(lp * 255))
        blit_text(im, (220, yy + 130), title, FONTS["cn_b36"], WHITE, anchor="lm",
                  alpha=int(lp * 255))
        blit_text(im, (220, yy + 200), sub, FONTS["cn28"], GRAY, anchor="lm",
                  alpha=int(lp * 255))
    blit_text(im, (W // 2, rpf.SAFE_B), "证书不是纸，是议价权",
              FONTS["cn32"], WHITE, alpha=255)
    return im


def scene_grid(p):
    im, d = base_frame()
    tp = appear(p, 0.0, 0.18)
    # 标题下移
    blit_text(im, (W // 2, 300), "覆盖六大主流检测方法", FONTS["cn_b56"], WHITE,
              alpha=int(tp * 255))
    cells = [
        ("VT", "目视检测", "表面缺陷直观"),
        ("UT", "超声检测", "内部缺陷精准"),
        ("RT", "射线检测", "厚壁内部透视"),
        ("MT", "磁粉检测", "铁磁表面裂纹"),
        ("PT", "渗透检测", "非磁表面开口"),
        ("PAUT", "相控阵", "多角度成像"),
    ]
    # 六宫格在可用区域垂直居中
    cols, cw, ch = 2, 440, 220
    gx, gy = 40, 45
    block_w = cols * cw + (cols - 1) * gx
    block_h = 3 * ch + 2 * gy
    sx = (W - block_w) // 2
    sy = (380 + rpf.SAFE_B - 80) // 2 - block_h // 2
    for i, (code, cn, desc) in enumerate(cells):
        lp = ease_out(appear(p, 0.08 + i * 0.07, 0.08 + i * 0.07 + 0.22))
        if lp <= 0:
            continue
        r, c = divmod(i, cols)
        x = sx + c * (cw + gx)
        y = sy + r * (ch + gy)
        blit_panel(im, [x, y, x + cw, y + ch], 18, PANEL, CYAN, 2,
                   alpha=int(lp * 255))
        blit_text(im, (x + cw // 2, y + 60), code, FONTS["en56"], GOLD,
                  alpha=int(lp * 255), scale=lerp(0.80, 1.0, lp))
        blit_text(im, (x + cw // 2, y + 115), cn, FONTS["cn_b40"], WHITE,
                  alpha=int(lp * 255))
        blit_text(im, (x + cw // 2, y + 170), desc, FONTS["cn28"], GRAY,
                  alpha=int(lp * 255))
    blit_text(im, (W // 2, rpf.SAFE_B), "VT · UT · RT · MT · PT · PAUT 任选报名",
              FONTS["cn32"], WHITE, alpha=255)
    return im


def scene_cta(p):
    im, d = base_frame()
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gp = appear(p, 0.0, 0.5)
    gd.ellipse([W // 2 - 360, 560, W // 2 + 360, 1300],
               fill=(34, 211, 238, int(16 * gp)))
    im = Image.alpha_composite(im, glow)
    # 内容块整体下移居中
    sp = appear(p, 0.05, 0.25)
    blit_text(im, (W // 2, 700), "想摆脱被卡的感觉？", FONTS["cn_b64"], CYAN,
              alpha=int(sp * 255), scale=lerp(0.80, 1.0, ease_out(sp)))
    mp = ease_out(appear(p, 0.30, 0.60))
    blit_text(im, (W // 2, 880), "评论区扣 1", FONTS["cn_b80"], WHITE,
              alpha=int(mp * 255))
    blit_text(im, (W // 2, 970), "领一份报考指南", FONTS["cn_b80"], WHITE,
              alpha=int(mp * 255))
    bp = appear(p, 0.66, 0.90)
    d.line([(W // 2 - 260, 1050), (W // 2 + 260, 1050)], fill=CYAN, width=3)
    blit_text(im, (W // 2, 1120), "TÜV NDT 认证培训 · 等你来",
              FONTS["cn_b44"], GOLD, alpha=int(bp * 255))
    blit_text(im, (W // 2, rpf.SAFE_B), "TÜV NDT 认证培训",
              FONTS["cn32"], WHITE, alpha=255)
    return im


SCENES = [
    ("cover", "你的简历，还在因为没有 NDT 证书被卡住吗？在船海、石化、风电这些行业，NDT 已经从加分项，变成了硬门槛。", scene_cover),
    ("data", "这不是我说的。我们拉了两个月的真实招聘数据：NDT、探伤相关描述出现了 289 次；其中 45.8% 的需求集中在长三角；焊接证加 NDT 双证同岗，出现了 109 次；超过八成的 NDT 岗位，要求六年以上经验；英语加 NDT 同现，176 次。没有证，连门槛都摸不到。", scene_data),
    ("turn", "那怎么办？救星来了——TÜV NDT 认证培训，把权威资质、系统课程、直通考核，一次给你。", scene_turn),
    ("cert", "考过就拿 EN ISO 9712 证书，全球互认、官网可查。TÜV 授权、PED、SNT-TC-1A 全覆盖，这才是真正的硬通货。", scene_cert),
    ("value", "它的价值，不只是张纸。专业性上，国际互认，走到哪都认；待遇上，既懂焊接检验、又持 NDT 资质的人，溢价明显，双证同岗一大把；职位上，长三角机会最多，涉外项目要英语加 NDT，六年以上的经验岗抢着要持证的人。一张证，打开的是门槛，也是天花板。", scene_value),
    ("grid", "课程覆盖六大主流方法：VT 目视、UT 超声、RT 射线、MT 磁粉、PT 渗透、PAUT 相控阵。任选报名，按需打通。", scene_grid),
    ("cta", "想摆脱被卡的感觉？评论区扣个 1，领一份报考指南。TÜV NDT 认证培训，等你来。", scene_cta),
]

VOICE = "zh-CN-YunxiNeural"


# ---------- 音频 ----------
async def tts_one(text, out_mp3, retries=3):
    import edge_tts
    for attempt in range(retries):
        try:
            comm = edge_tts.Communicate(text, VOICE, rate="+30%")
            await comm.save(out_mp3)
            return True
        except Exception as e:
            print(f"  TTS 失败(尝试{attempt+1}/{retries}): {e}")
            await asyncio.sleep(2)
    return False


def get_duration(path):
    out = subprocess.run([FFMPEG, "-i", path], stderr=subprocess.PIPE,
                         stdout=subprocess.PIPE, text=True)
    for line in out.stderr.splitlines():
        if "Duration" in line:
            parts = line.split("Duration:")[1].split(",")[0].strip()
            h, m, s = parts.split(":")
            return int(h) * 3600 + int(m) * 60 + float(s)
    return None


def run(cmd):
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"命令失败: {' '.join(cmd)}\n{r.stderr[:2000]}")
    return r


def main():
    seg_mux_list = []
    total = 0.0
    for idx, (name, narration, fn) in enumerate(SCENES):
        sdir = os.path.join(WORK, f"seg{idx:02d}")
        mux = os.path.join(sdir, "mux.mp4")
        # 断点续渲：已完成的分段直接复用
        if os.path.exists(mux):
            d = get_duration(mux) or 0.0
            seg_mux_list.append(mux)
            total += d
            print(f"=== 场景 {idx+1}/{len(SCENES)}: {name} 已完成，跳过 (复用 {d:.1f}s) ===")
            continue
        print(f"\n=== 场景 {idx+1}/{len(SCENES)}: {name} ===")
        # 直接覆盖写帧即可（新帧数 >= 旧帧数，无残留混入）；不批量删避免触发 safe-delete
        os.makedirs(sdir, exist_ok=True)
        mp3 = os.path.join(sdir, "audio.mp3")
        print("  TTS 配音...")
        ok = asyncio.run(tts_one(narration, mp3))
        if not ok:
            print("  TTS 彻底失败，跳过该场景")
            continue
        dur = get_duration(mp3)
        if not dur or dur < 1:
            dur = 6.0
        dur = math.ceil(dur * FPS) / FPS  # 对齐到帧
        nframes = int(round(dur * FPS))
        print(f"  时长 {dur:.2f}s，渲染 {nframes} 帧...")
        # 渲染帧
        for f in range(nframes):
            p = f / max(1, nframes - 1)
            im = fn(p)
            im.convert("RGB").save(os.path.join(sdir, f"{f:05d}.png"), quality=92)
        # 编码无音视频段
        seg_mp4 = os.path.join(sdir, "video.mp4")
        run([FFMPEG, "-y", "-framerate", str(FPS),
             "-i", os.path.join(sdir, "%05d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p",
             "-preset", "veryfast", "-crf", "18",
             seg_mp4])
        # 合成音频
        seg_mux = os.path.join(sdir, "mux.mp4")
        run([FFMPEG, "-y", "-i", seg_mp4, "-i", mp3,
             "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
             "-shortest", "-movflags", "+faststart", seg_mux])
        seg_mux_list.append(seg_mux)
        total += dur
        print(f"  完成场景 {name}，累计 {total:.1f}s")

    if not seg_mux_list:
        print("没有可用场景，退出")
        sys.exit(1)

    # 拼接
    list_txt = os.path.join(WORK, "concat_list.txt")
    with open(list_txt, "w", encoding="utf-8") as f:
        for s in seg_mux_list:
            f.write(f"file '{s}'\n")
    run([FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", list_txt,
         "-c", "copy", OUT_MP4])
    print(f"\n成品: {OUT_MP4}")
    print(f"总时长约 {total:.1f}s")


if __name__ == "__main__":
    main()
