# -*- coding: utf-8 -*-
"""
start.py — 标准视频工作流 统一入口(菜单式)
==========================================
不知道从哪开始?就跑这个:

    python start.py            # 显示菜单,选一个子产品
    python start.py --list     # 只列清单
    python start.py 3          # 直接看第 3 个子产品的用法
    python start.py --run 3    # 直接执行第 3 个子产品的入口脚本
    python start.py --install  # 跑环境安装(等同 install.py)

设计原则:
  * 只做导航,不偷偷渲染 —— 选完先给命令,确认后才执行
  * 所有入口路径均已核实存在(不写"看起来对"的路径)
  * 每个产品带"专属避坑"提示,避免重蹈历史覆辙
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent

PRODUCTS = [
    {
        "name": "情景视频生产链",
        "desc": "船海/海工知识网络 → 中英双语短视频(旁白/对话,横/竖屏)",
        "entry": "情景视频生产链/run.py",
        "out": "D:\\微信小程序\\情景视频存放处\\",
        "watch": [
            "需要引擎 changanghai_expert.html,install.py 会校验",
            "字幕 EN 上 CN 下,英文必须纯 ASCII(防 tofu 方块)",
            "竖屏安全区:顶部 190px / 底部 260px",
        ],
    },
    {
        "name": "表格讲解视频 (Table 6.10 等)",
        "desc": "标准里的表格 → 横屏 16:9 逐行高亮讲解视频",
        "entry": "render/render_fast.py",
        "out": "D:\\微信小程序\\标准视频库\\",
        "watch": [
            "本子产品代码就在伞根 render/ 下(子目录只有说明文档)",
            "改卡片坐标必须按「改坐标必查四处」核对",
            "改了配音文案必须先删 render/audio_cache* 再渲染",
        ],
    },
    {
        "name": "图片讲解视频 (Figure 6.16 等)",
        "desc": "标准里的图 → 竖屏分镜讲解视频",
        "entry": "图片讲解视频/main.py",
        "out": "D:\\微信小程序\\标准视频库\\",
        "watch": [
            "讲同一张图的多个要点,必须共用同一张干净裁图(不切邻图)",
            "画重点至少用 3 种形式(箭头/圆点/行带/下划线/放大镜/发光字)",
            "高亮框用 follow 绑定讲解句,禁止开场一次性全蹦",
        ],
    },
    {
        "name": "NDT 探伤培训竖屏",
        "desc": "TÜV NDT 探伤证培训宣传短视频(先焦虑后推产品)",
        "entry": "NDT培训竖屏/render/render_training_promo_v2.py",
        "out": "D:\\微信小程序\\标准视频库\\",
        "watch": [
            "受众是检验员:术语用「焊接检验/焊接证」,禁用「焊工/会焊」",
            "隐私红线:不放真实证书人名编号,样张盖「样张」印",
            "背景透明度固定 Brightness0.55/Color0.72/Contrast1.22",
        ],
    },
    {
        "name": "ASME B31.3 表格讲解",
        "desc": "Table 341.3.2 焊缝缺陷射线验收 → 讲解视频",
        "entry": "ASME_B31_3_表格讲解/render/render_asme_b31_3_table341_3_2.py",
        "out": "D:\\微信小程序\\标准视频库\\",
        "watch": [
            "copy 素材时排除 frames_* / audio_cache*(曾留下 31GB 残骸)",
            "中英混排必须分字体绘制(Arial 渲染中文会成方块)",
            "ffmpeg concat 中文路径会乱码,先转 ASCII 临时目录",
        ],
    },
    {
        "name": "周报视频",
        "desc": "周报 PPT → 16:9 英文朗读视频",
        "entry": "周报视频/pipeline/weekly_build.py",
        "out": "D:\\微信小程序\\标准视频库\\",
        "watch": [
            "背景用 PPT 原图,零虚化零运动;同页背景在该页句子读完前不切换",
            "字幕一句英文 + 一句中文上下排列;en-US-GuyNeural + rate -8%",
            "脚本用法: python 周报视频/pipeline/weekly_build.py --project <项目名>",
        ],
    },
    {
        "name": "小短剧分镜",
        "desc": "剧本/梗概 → 最少关键帧分镜图 + 角色一致性",
        "entry": "小短剧分镜/ppe_check.py",
        "out": "自建分镜目录",
        "watch": [
            "全员(含儿童)必须安全帽 + 钢头鞋 + 手套",
            "匿名化:禁用真实船厂/人物/国家名,地名虚拟化",
            "无水印 / 无 AI 品牌 / 无文字角标",
        ],
    },
    {
        "name": "豆包视频拼接加字幕",
        "desc": "豆包/即梦文生视频 → 多片段拼接 → 中英硬字幕(英文上中文下 · 逐句切) → 抽帧验证",
        "entry": "豆包视频拼接加字幕/sync_subtitles.py",
        "out": "同输入目录(_修正字幕.mp4)",
        "watch": [
            "3 铁律:豆包必须生成无字幕视频(提示词写「画面无任何文字」) / 字幕跟音频走 / 字幕压画面+阴影不加黑幕",
            "ASS 冻结:WrapStyle=1 / Fontsize=40 / MarginV=30 / Shadow=2 / Outline=3 / BorderStyle=1(描边非黑底)",
            "烧入必须 cd 进目录 + ass 用相对路径(ass=fix.ass,Windows 绝对路径冒号被 libass 当分隔符导致静默失败)",
            "修改后必跑:verify_subtitles.py 抽帧(说话段 present / 停顿段 absent),+ 伞包 check.py A0–A8",
            "竖屏场景用 gen_vertical_sentences.py(顺序无关 · 真实位置对齐)+ verify_true.py,不按脚本顺序 1:1 映射",
        ],
    },
    {
        "name": "app_demo",
        "desc": "3D 卡片开场 + WorkBuddy App 聊天录屏段（HTML+Playwright，竖屏 9:16）",
        "entry": "app_demo/render.js",
        "out": "app_demo/output/app_demo.mp4",
        "watch": [
            "补齐 PIL 2D 框架做不了的「真 3D 透视开场」与「App 界面滚动/打字录屏」",
            "主路线 HTML+Playwright(需本地 chromium, 免费一次性装); 不可用降级 PIL 伪 3D",
            "产出片段交给「豆包视频拼接加字幕」拼进主成片, 再过 check.py A0–A8",
        ],
    },
]

PY = sys.executable


def hr(t=""):
    print("\n" + "=" * 66)
    if t:
        print(f"  {t}")
        print("=" * 66)


def show_list():
    hr("标准视频工作流 — 8 个子产品")
    for i, p in enumerate(PRODUCTS, 1):
        flag = "" if p["entry"] else "  (文档阶段)"
        print(f"  [{i}] {p['name']}{flag}")
        print(f"      {p['desc']}")
    print()
    print("  ★ 固定工作流(六步法 + 红线闸门,任何新视频先走这套):")
    print("      python start.py --workflow          跑内置样例(竖屏+横屏)")
    print("      python start.py --workflow --brief x.json   用你的 Brief 走六步")
    print("      详见: 固定工作流_总纲.md")
    print()
    print("  其它命令:")
    print("    python start.py --install      装环境(第一次必做)")
    print("    python start.py --check <mp4>  成片交付前自检")
    print()
    print("  第一次使用请先跑: python start.py --install")
    print("  动手前必读: 固定工作流_总纲.md  +  1_避坑总纲_血泪清单.md")
    print("=" * 66)


def show_one(idx: int, do_run: bool = False):
    p = PRODUCTS[idx - 1]
    hr(f"[{idx}] {p['name']}")
    print(f"  能做什么: {p['desc']}")
    print(f"  成片输出: {p['out']}")

    if p["entry"]:
        ep = ROOT / p["entry"]
        exists = ep.exists()
        print(f"  入口脚本: {ep if exists else p['entry'] + '   [!] 文件不存在'}")
        cmd = f'{PY} "{ep}"'
        print(f"\n  运行命令:\n      {cmd}")
        if not exists:
            print("\n  [!] 入口文件缺失,请检查路径或参考子目录 README。")
            return
        if do_run:
            print("\n  >>> 执行中(子脚本可能需要额外参数,如 --brief xxx.json) <<<")
            r = subprocess.run([PY, str(ep)], cwd=str(ep.parent))
            sys.exit(r.returncode)
    else:
        print("  入口脚本: (暂无可执行代码,本子产品目前是方法论文档)")
        print(f"  文档: {ROOT / p['name'] / '0_README_先看这个.md'}")

    print("\n  专属避坑:")
    for w in p["watch"]:
        print(f"    - {w}")
    rd = ROOT / p["name"] / "0_README_先看这个.md"
    if rd.exists():
        print(f"\n  详细说明: {rd}")
    print("=" * 66)


def main():
    args = sys.argv[1:]
    if not args:
        show_list()
        try:
            s = input("\n  输入编号查看详情(/ 直接回车退出): ").strip()
        except EOFError:
            return 0
        if not s.isdigit():
            return 0
        idx = int(s)
        if 1 <= idx <= len(PRODUCTS):
            show_one(idx)
            try:
                y = input("\n  是否立即执行入口脚本? (y/N): ").strip().lower()
            except EOFError:
                y = "n"
            if y == "y":
                show_one(idx, do_run=True)
        return 0

    if args[0] == "--list":
        show_list(); return 0
    if args[0] == "--install":
        sys.exit(subprocess.run([PY, str(ROOT / "install.py")], cwd=str(ROOT)).returncode)
    if args[0] == "--check":
        if len(args) < 2:
            print("用法: python start.py --check <成片.mp4>"); return 2
        sys.exit(subprocess.run([PY, str(ROOT / "check.py"), *args[1:]],
                                cwd=str(ROOT)).returncode)
    if args[0] == "--run" and len(args) >= 2 and args[1].isdigit():
        show_one(int(args[1]), do_run=True); return 0
    if args[0] == "--workflow":
        sys.exit(subprocess.run([PY, str(ROOT / "workflow.py"), *args[1:]],
                                cwd=str(ROOT)).returncode)
    if args[0].isdigit():
        show_one(int(args[0])); return 0

    show_list()
    return 0


if __name__ == "__main__":
    sys.exit(main())
