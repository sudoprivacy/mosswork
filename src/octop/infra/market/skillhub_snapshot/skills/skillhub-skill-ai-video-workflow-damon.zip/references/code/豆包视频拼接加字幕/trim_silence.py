#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
trim_silence.py —— 自动裁掉视频「首尾无对话的静音定格」废片。

用途：豆包文生视频单条约 10 秒，台词往往填不满，结尾常留 1–3 秒
「画面定格 + 没声音」的废片。本脚本用 silencedetect 找到：
  - 头部静音（silence_start≈0 且长度 > lead_min）→ 从 silence_end 起裁
  - 尾部静音（最后一段 silence_end≈总时长 且长度 > tail_min）→ 在 silence_start+pad 处断
把无对话的定格段切掉，避免成片「画面在那发呆」。

用法：
  python trim_silence.py <输入.mp4> [输出.mp4]
  python trim_silence.py shot1_dewm.mp4 shot1_trim.mp4
若不传输出，默认 输入名插入 _trim。
"""
import subprocess, re, sys, os
from pathlib import Path

def _resolve_ff():
    env = os.environ.get("FFMPEG")
    if env and os.path.exists(env):
        return env
    home = Path.home()
    candidates = [
        home / ".workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe",
        home / ".workbuddy/binaries/python/versions/3.13.12/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe",
    ]
    for c in candidates:
        if os.path.exists(str(c)):
            return str(c)
    return str(candidates[0])


FF = _resolve_ff()

NOISE = "-28dB"
DUR = "0.3"
LEAD_MIN = 0.35   # 头部静音超过此秒数才裁（避免误切正常起手）
TAIL_MIN = 0.40   # 尾部静音超过此秒数才裁
PAD = 0.15        # 尾部断点相对 silence_start 的安全余量（防切掉最后发音）


def probe_duration(path):
    out = subprocess.run([FF, "-i", path], stderr=subprocess.PIPE, text=True).stderr
    m = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", out)
    if not m:
        return None
    h, mi, s = map(float, m.groups())
    return h * 3600 + mi * 60 + s


def detect_silence(path):
    out = subprocess.run(
        [FF, "-i", path, "-af", f"silencedetect=noise={NOISE}:d={DUR}", "-f", "null", "-"],
        stderr=subprocess.PIPE, text=True,
    ).stderr
    starts, ends = [], []
    for line in out.splitlines():
        ms = re.search(r"silence_start: ([\d.]+)", line)
        me = re.search(r"silence_end: ([\d.]+)", line)
        if ms:
            starts.append(float(ms.group(1)))
        if me:
            ends.append(float(me.group(1)))
    return starts, ends


def main():
    if len(sys.argv) < 2:
        print("用法: python trim_silence.py <输入.mp4> [输出.mp4]")
        sys.exit(1)
    inp = sys.argv[1]
    outp = sys.argv[2] if len(sys.argv) > 2 else re.sub(r"\.mp4$", "_trim.mp4", inp)

    dur = probe_duration(inp)
    starts, ends = detect_silence(inp)
    if dur is None:
        print("无法读取时长，退出")
        sys.exit(1)

    start_at = 0.0
    if starts and abs(starts[0]) < 0.05 and ends and ends[0] > LEAD_MIN:
        start_at = ends[0]

    cut_at = dur
    if ends and abs(ends[-1] - dur) < 0.20 and starts and (dur - starts[-1]) > TAIL_MIN:
        cut_at = starts[-1] + PAD

    if start_at <= 0.001 and abs(cut_at - dur) < 0.05:
        print(f"[trim_silence] 无显著首尾静音（头 {start_at:.2f}s / 尾剩 {dur - cut_at:.2f}s），直接拷贝不重编码")
        subprocess.run([FF, "-i", inp, "-c", "copy", "-y", outp], check=True)
        return

    print(f"[trim_silence] 原时长 {dur:.2f}s → 裁头 {start_at:.2f}s / 断尾 {cut_at:.2f}s → 输出 {cut_at - start_at:.2f}s")
    seg_len = cut_at - start_at
    cmd = [
        FF, "-i", inp,
        "-ss", f"{start_at:.3f}",
        "-t", f"{seg_len:.3f}",
        "-c:v", "libx264", "-preset", "medium", "-crf", "20",
        "-c:a", "aac", "-b:a", "128k",
        "-movflags", "+faststart",
        "-y", outp,
    ]
    r = subprocess.run(cmd, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0:
        print("编码失败：")
        print(r.stderr[-800:])
        sys.exit(1)
    print(f"[trim_silence] 已写出: {outp}")


if __name__ == "__main__":
    main()
