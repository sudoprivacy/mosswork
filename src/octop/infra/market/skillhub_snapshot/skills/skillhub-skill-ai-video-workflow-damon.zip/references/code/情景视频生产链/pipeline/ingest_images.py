#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
投喂图接入器 —— 用户自己给的图优先, 不够的才走素材库/生图。

优先级(整条流水线的取图顺序):
  1) 用户投喂图 (本脚本)
  2) 素材库复用 (reuse_assets.py)
  3) AI 生图 (images_needed.json 交给会话里的图像工具)

投喂方式:
  A. 把图丢进 assets/inbox/<工程名>/  (推荐, 自动识别)
  B. 把图丢进 assets/inbox/          (无工程子目录时的通用投喂口)
  C. 命令行指定任意目录:  --images "D:/我的图"

命名 -> 分镜 的对应规则:
  * 文件名以数字开头  ->  该数字即分镜号。 例:  3_吊装.jpg  ->  第3镜
  * 其余文件          ->  按文件名排序, 依次填进"还没图"的分镜
  * 投喂数少于分镜数  ->  剩下的镜自动交给素材库/生图, 不报错
  * 投喂数多于分镜数  ->  多出的忽略并提示

用法:
  python pipeline/ingest_images.py --project hse_lifting_stop
  python pipeline/ingest_images.py --project xxx --images "D:/我的图" --keep-inbox
  python pipeline/ingest_images.py --project xxx --dry-run
"""
import os, re, sys, json, shutil, argparse, subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'pipeline'))
from ffbin import find_ffmpeg                      # noqa: E402

INBOX = os.path.join(ROOT, 'assets', 'inbox')
EXTS = {'.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tif', '.tiff', '.avif'}


def pick_source(project, explicit):
    """决定从哪个目录取投喂图。"""
    if explicit:
        return explicit if os.path.isdir(explicit) else None
    per_proj = os.path.join(INBOX, project)
    if os.path.isdir(per_proj) and list_images(per_proj):
        return per_proj
    if os.path.isdir(INBOX) and list_images(INBOX):
        return INBOX
    return None


def list_images(d):
    if not os.path.isdir(d):
        return []
    out = []
    for f in sorted(os.listdir(d)):
        p = os.path.join(d, f)
        if os.path.isfile(p) and os.path.splitext(f)[1].lower() in EXTS:
            out.append(p)
    return out


def to_png(ffmpeg, src, dst, dry=False):
    """统一转成 png(合成器只吃 png), 同名 png 直接拷。"""
    if dry:
        return True
    if os.path.splitext(src)[1].lower() == '.png':
        shutil.copy(src, dst)
        return True
    r = subprocess.run([ffmpeg, '-y', '-i', src, dst],
                       capture_output=True, text=True)
    return r.returncode == 0 and os.path.exists(dst)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', required=True)
    ap.add_argument('--images', default=None, help='投喂图目录(默认自动找 assets/inbox)')
    ap.add_argument('--keep-inbox', action='store_true',
                    help='用完不搬走投喂图(默认搬到 assets/inbox/_used/<工程>/ 防止串片)')
    ap.add_argument('--overwrite', action='store_true',
                    help='投喂图覆盖工程里已有的同号图')
    ap.add_argument('--dry-run', action='store_true')
    a = ap.parse_args()

    proj = os.path.join(ROOT, 'projects', a.project)
    sj = os.path.join(proj, 'scenes.json')
    if not os.path.exists(sj):
        raise SystemExit('找不到 ' + sj + ' (先跑 make_scenes.js)')
    scenes = json.load(open(sj, encoding='utf-8'))['scenes']

    src_dir = pick_source(a.project, a.images)
    if not src_dir:
        print('未发现投喂图 (查过: %s 与 %s)' % (os.path.join(INBOX, a.project), INBOX))
        print('-> 本条片全部走 素材库复用 / AI 生图')
        return

    files = list_images(src_dir)
    print('投喂目录: %s  (%d 张)' % (src_dir, len(files)))

    ffmpeg = find_ffmpeg()
    if not ffmpeg:
        raise SystemExit('未找到 ffmpeg, 无法转换图片格式')

    img_dir = os.path.join(proj, 'images')
    os.makedirs(img_dir, exist_ok=True)

    by_idx = {s['idx']: s for s in scenes}
    plan, seq_pool = {}, []

    # 1) 文件名带数字 -> 指定分镜
    for f in files:
        m = re.match(r'^0*(\d+)', os.path.basename(f))
        if m and int(m.group(1)) in by_idx:
            i = int(m.group(1))
            if i not in plan:
                plan[i] = f
                continue
        seq_pool.append(f)

    # 2) 其余按序填进"还没图 且 没被指定"的分镜
    for s in scenes:
        if not seq_pool:
            break
        i = s['idx']
        if i in plan:
            continue
        exists = os.path.exists(os.path.join(img_dir, s['image_file']))
        if exists and not a.overwrite:
            continue
        plan[i] = seq_pool.pop(0)

    if seq_pool:
        print('提示: 多出 %d 张没用上 -> %s'
              % (len(seq_pool), ', '.join(os.path.basename(x) for x in seq_pool)))

    used, failed = [], []
    for i in sorted(plan):
        src = plan[i]
        dst = os.path.join(img_dir, by_idx[i]['image_file'])
        ok = to_png(ffmpeg, src, dst, a.dry_run)
        (used if ok else failed).append((i, os.path.basename(src)))
        print('  [%02d] %s <- %s' % (i, by_idx[i]['image_file'],
                                     os.path.basename(src)))

    if failed:
        print('转换失败: %s' % failed)

    covered = sorted(plan)
    rest = [s['idx'] for s in scenes if s['idx'] not in plan
            and not os.path.exists(os.path.join(img_dir, s['image_file']))]
    print('=== 投喂覆盖 %d 镜: %s' % (len(covered), covered or '无'))
    print('=== 仍缺 %d 镜: %s  (交给素材库/生图)' % (len(rest), rest or '无'))

    if a.dry_run:
        return

    json.dump({'source': src_dir,
               'mapping': {str(i): os.path.basename(plan[i]) for i in plan}},
              open(os.path.join(proj, 'fed_images.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=2)

    # 搬走已消费的投喂图, 避免下一条片误用上一条的素材
    if not a.keep_inbox and src_dir.startswith(INBOX):
        done = os.path.join(INBOX, '_used', a.project)
        os.makedirs(done, exist_ok=True)
        for i in plan:
            src = plan[i]
            try:
                shutil.move(src, os.path.join(done, os.path.basename(src)))
            except Exception as e:
                print('搬移失败 %s: %s' % (src, e))
        print('已用图搬至: %s' % done)


if __name__ == '__main__':
    main()
