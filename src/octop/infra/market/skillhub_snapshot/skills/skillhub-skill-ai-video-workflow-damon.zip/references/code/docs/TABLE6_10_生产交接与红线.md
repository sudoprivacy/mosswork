﻿# AWS D1.1:2020 表 6.10 讲解视频 · 生产流水线交接文档

> 本目录是用纯本地 Python（PIL + ffmpeg + edge-tts，零积分、零云端）生成「标准现场讲解 PPT 视频」的**已定稿**流水线。
> 当前定稿对象：**AWS D1.1:2020 Table 6.10 焊工焊接位置评定表**（p183，8 行：1G/2G/3G/4G/1F/2F/3F/4F）。
> 概念设计见同级 `工作流设计.md`；本文件是**操作级交接**，另一个任务照着跑即可，不必再纠结布局。

---

## 1. 工作流根目录（交接位置）

```
D:\Workbuddy缓存位置\标准讲解视频工作流
```

---

## 2. 生产脚本（只动这三个，其余 `render/*.py` 全是实验/日志/探针，别碰）

| 脚本 | 产出 mp4 | 状态 |
|---|---|---|
| `render/render_table_walkthrough_l_pos_en.py` | `output/aws_table610_walkthrough_pos_en.mp4` | ✅ **最新定稿**：英文旁白 + 中英双语文案 + 中英双语字幕（用户已验收） |
| `render/render_table_walkthrough_l_pos.py` | `output/aws_table610_walkthrough_pos.mp4` | ✅ **冻结**：纯中文版，除非用户点名否则不要改 |
| `render/render_table_walkthrough_l.py` | （早期横版基版） | 仅参考，勿改 |

> 三个脚本里 `ROOT` 都是**绝对路径**写死的，所以脚本放哪个子目录都不影响找素材。但请原地运行，不要移动。

---

## 3. 运行方式

```bat
C:\Users\Damon\AppData\Local\Programs\Python\Python312\python.exe render/render_table_walkthrough_l_pos_en.py
```

- 依赖（已装，重装环境时需补）：`Pillow`、`PyMuPDF`、`edge-tts`（`pip install edge-tts`）。
- ffmpeg 走脚本内硬编码路径，不需要配环境变量。
- 渲染约 11 分钟（10 个场景从头重渲），最终 mp4 落到 `output/`。
- 若进程中途 shell 工具报错，用 Agent 子进程执行同一条命令即可（python/ffmpeg 路径如上）。

---

## 4. 源素材（别删、别改）

- `source/table610/table6_10_p183_base.png` —— 整表截图（含底部脚注），2998×1312
- `source/table610/table6_10_p183.json` —— 行框/表格框/尺寸元数据（`row_bbox` / `label_cell` / `table_frame` / `img_size`）
- `source/table610/positions/1G.png … 4F.png` —— 8 张标准试板简图（p191 Fig.4.3 / p192 Fig.4.4）

---

## 5. 已定稿的卡片竖向排版（EN 变体 · 绝对红线）

卡片尺寸 `CARD_W=1760, CARD_H=348`，预算很紧。**当前不重叠**的布局（卡片内局部坐标）：

| 元素 | 坐标（卡片内局部 y） |
|---|---|
| 标题 EN `title_en` | (rx=600, **40**) |
| 中文标题 `title` | (rx, **78**) |
| 标签「评定合格位置 Qualified Positions」 | (rx, **116**) |
| 金色评定条（F/FH） | `bar_y=158`, `bar_h=52` → 占 **158–210** |
| 正文 `body` 首行 | y=**226**，行距 40（226 / 266 / 306） |
| 左下小字 `big_sub` / `big_sub_en` | (m=36, **288**) / (m, **310**) |
| 黄色大代码（1G/1F 等）pop-in 中心 | 卡片局部 (186, **206**)，字体 96 |
| 字幕（纯文字无框） | EN 中心 ≈ **994**，CN 中心 ≈ **1046**（卡片底 968 以下） |

其他布局常量：`TABLE_X=70, TABLE_Y=152, TABLE_W=1040`；`CARD_X=80, CARD_Y=620, CARD_H=348`；`SUB_Y=974, SUB_H=106`。

**铁律（改任何 y 都必须执行）**：改上面任意一个坐标，**必须同时核对四处**：
1. 标签 ↔ 金色评定条 的间距（当前约 20px，不能变成重叠/半透明压字）；
2. 金色评定条 ↔ 正文首行 的间距（不能压字）；
3. 黄色大代码底部 ↔ 左下小字 的间距（代码底约 254，小字顶约 266，留 ≥12px）；
4. 正文末行 ↔ 卡片底圆角（末行底约 328，卡片高 348，留 ≥18px，否则被裁剪）。

任一处出现重叠/裁剪，**先给整体方案再一起改**，绝不要只挪一个元素（历史上反复踩过这个坑）。

---

## 6. 用户红线（逐条必须守）

1. **只改用户明确要求改的**；没让改的别动（含冻结版 `render_table_walkthrough_l_pos.py` 和已有成片，除非用户点名）。
2. **每次交付必须把视频文件绝对路径贴出来**。
3. 用户要新版本时，**绝不允许交付旧文件 / 旧路径**。
4. 改一个地方先想对其他地方的影响，有冲突先给方案再动（见第 5 节铁律）。
5. 目标是**横版 16:9（1920×1080）**；不要做竖版（参考片是横版 PPT 的手机竖录，目标是横版）。
6. 术语：WPS=工艺评定；焊工=考；Table 6.10=焊工焊接位置评定表；资格位置→评定位置。
7. 读法：「表 6.10」读「六点一零」；「AWS D1.1 2020」中 1 和 2020 之间不换气；「O H」分开读。
8. 表格高亮严格在表内，无扫描线、无 `??` 伪影；表格（含脚注）不得截断。
9. **字幕不加框**（用户明确：框显得乱且挡字）；双语 EN 上 CN 下，不得遮挡任何内容。
10. 内容中英文，英文在上中文在下（EN 变体的硬要求）。

---

## 7. 已知坑（别再踩）

- **改 `spoken` 文案后不重生成语音**：TTS 缓存按「场景序号」命名，不是按文案。场景序号不变时旧 mp3 不会自动覆盖。要强制重 TTS：
  - EN 版删 `render/audio_cache_en/*.mp3`
  - 中文版删 `render/audio_cache_ppt/*.mp3`
- **ffmpeg concat 中文路径乱码**：脚本已处理（先 cp 到 ASCII 临时目录 `C:\wb_tmp_concat` 再拼），重跑别改回中文清单写法。
- 渲染全程重渲（不增量），11 分钟左右属正常，不是卡死。

---

## 8. 成片位置（交接验收用）

- 英文双语：`D:\Workbuddy缓存位置\标准讲解视频工作流\output\aws_table610_walkthrough_pos_en.mp4`（≈6.5 MB，≈116 s）
- 中文：`D:\Workbuddy缓存位置\标准讲解视频工作流\output\aws_table610_walkthrough_pos.mp4`（≈5.7 MB，≈104 s）

---

## 9. 场景数据结构（改文案只看 `SCENES`，不要动渲染函数）

`SCENES` 是 10 个 dict：index 0=开场爆点、1–8=1G…4F、9=总结。每条字段：
`key`（表格行号或 None）、`code`、`tag`/`tag_en`、`title`/`title_en`、`big`（F/F,H/F,H,V/F,H,OH）、
`big_sub`/`big_sub_en`（仅 1G/1F 有）、`body`（每行已是「中文 · 英文」）、
`caption`/`caption_en`（字幕）、`spoken`（英文旁白文案）。

改某行的讲解文字，只改对应 dict 字段；改完记得按第 7 节清对应 TTS 缓存再重渲。
