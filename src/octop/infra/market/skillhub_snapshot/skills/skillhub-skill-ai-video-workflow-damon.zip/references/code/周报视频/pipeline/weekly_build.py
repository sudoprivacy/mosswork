# -*- coding: utf-8 -*-
"""
weekly-report-ppt-to-video · 生成器（卖货版，自包含，零框架依赖）

硬约束（用户冻结，禁止擅自改）：
  1. 横屏 16:9 (1920x1080)，不要竖屏
  2. 背景 = PPT 原图，零虚化（cover 裁剪，不 scale/blur/kenburns）
  3. 英语朗读 en-US-GuyNeural, rate='-8%'，只念英文
  4. 字幕逐句切换，但同一页背景在该页所有句子读完前绝不切换
  5. 字幕半透明带压底部，不挡 PPT 主体
  6. 每句英文对应一句中文翻译：EN(上)+ZH(下) 上下排列
  7. 读到一句换一句（script.txt 已按逗号/句号切短）
  8. 英 48 / 中 48 / 字幕带底部 200px

用法：
  python weekly_build.py --project <周名> [--root .] [--output <名>.mp4]
  --start audio : 跳过 PPT 截图（images/ 已存在）
  --start final : 只重做 concat（clip 已存在）
"""
import argparse
import os
import sys
import glob
import subprocess

from PIL import Image, ImageDraw, ImageFont
import edge_tts

try:
    import imageio_ffmpeg
    FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
except Exception:
    FFMPEG = "ffmpeg"

# ---------------- 冻结常量 ----------------
W, H = 1920, 1080
EN_VOICE = "en-US-GuyNeural"
RATE = "-8%"
EN_SIZE = 48
ZH_SIZE = 48
BAND_Y0 = H - 200          # 880，底部 200px 字幕带
TAIL = 0.25                # 每句尾静音秒
FPS = 25
FONT_DIR = r"C:\Windows\Fonts"
EN_FONT = os.path.join(FONT_DIR, "arial.ttf")
ZH_FONT = os.path.join(FONT_DIR, "msyh.ttc")


def log(*a):
    print("[weekly]", *a, flush=True)


def get_font(path, size):
    return ImageFont.truetype(path, size)


def has_cjk(s):
    return any("\u4e00" <= ch <= "\u9fff" for ch in s)


def wrap_text(draw, text, font, max_w):
    """按宽度换行：CJK 按字、拉丁按词。"""
    if has_cjk(text):
        chars = list(text)
        step = 1
    else:
        chars = text.split(" ")
        step = None
    lines, cur = [], ""
    for item in chars:
        trial = (cur + (item if step else item + " ")).strip() if step is None else (cur + item)
        if draw.textlength(trial, font=font) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = item if step is None else item
    if cur:
        lines.append(cur)
    return lines


def cover_crop(im, tw, th):
    """等比 cover 裁剪填满，不拉伸、不虚化。"""
    w, h = im.size
    scale = max(tw / w, th / h)
    nw, nh = int(w * scale), int(h * scale)
    im = im.resize((nw, nh), Image.LANCZOS)
    x0 = (nw - tw) // 2
    y0 = (nh - th) // 2
    return im.crop((x0, y0, x0 + tw, y0 + th))


def parse_script(path):
    """解析 script.txt → [(slide_str, en, zh), ...] 顺序保留。
    同一页内可有多对 EN/ZH；遇到新 EN: 且上一对已完整则先 flush。
    """
    pairs = []
    cur_slide = None
    buf = {}

    def flush():
        if cur_slide is not None and "en" in buf and "zh" in buf:
            pairs.append((cur_slide, buf["en"], buf["zh"]))

    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.rstrip("\n")
            s = line.strip()
            if s.startswith("###"):
                flush()
                cur_slide = s.replace("###", "").strip()
                buf = {}
            elif s.startswith("EN:"):
                if "en" in buf and "zh" in buf:
                    flush()
                buf = {"en": s[3:].strip()}
            elif s.startswith("ZH:"):
                buf["zh"] = s[3:].strip()
    flush()
    return pairs


def tts(en_text, out_mp3):
    import asyncio

    async def _run():
        comm = edge_tts.Communicate(en_text, EN_VOICE, rate=RATE)
        await comm.save(out_mp3)

    asyncio.run(_run())


def probe_dur(mp3):
    import re
    out = subprocess.run(
        [FFMPEG, "-i", mp3], stderr=subprocess.PIPE, text=True,
    ).stderr
    m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", out)
    if m:
        h, mn, s = m.groups()
        return int(h) * 3600 + int(mn) * 60 + float(s)
    return 3.0


def render_frame(bg_path, en, zh, out_png):
    bg = Image.open(bg_path).convert("RGB")
    bg = cover_crop(bg, W, H)
    d = ImageDraw.Draw(bg, "RGBA")
    # 底部半透明带（不挡主体，仅压字幕区）
    d.rectangle([0, BAND_Y0, W, H], fill=(0, 0, 0, 140))
    en_f = get_font(EN_FONT, EN_SIZE)
    zh_f = get_font(ZH_FONT, ZH_SIZE)
    max_w = W - 160
    en_lines = wrap_text(d, en, en_f, max_w)
    zh_lines = wrap_text(d, zh, zh_f, max_w)
    # EN 行簇在上半带，ZH 在下半带
    en_h = EN_SIZE + 8
    zh_h = ZH_SIZE + 8
    en_total = len(en_lines) * en_h
    zh_total = len(zh_lines) * zh_h
    y = BAND_Y0 + (200 - en_total - zh_total) // 2
    for ln in en_lines:
        d.text(((W - d.textlength(ln, font=en_f)) / 2, y), ln, font=en_f, fill=(255, 255, 255, 255))
        y += en_h
    y += 4
    for ln in zh_lines:
        d.text(((W - d.textlength(ln, font=zh_f)) / 2, y), ln, font=zh_f, fill=(255, 255, 255, 255))
        y += zh_h
    bg.convert("RGB").save(out_png)


def build_clip(bg_path, en, zh, tmp):
    frame = os.path.join(tmp, "frame.png")
    a_mp3 = os.path.join(tmp, "audio.mp3")
    clip = os.path.join(tmp, "clip.mp4")
    tts(en, a_mp3)
    dur = probe_dur(a_mp3)
    render_frame(bg_path, en, zh, frame)
    # 片段时长 = 配音时长 + 句尾静音(TAIL)；ffmpeg 自动用静音补齐音频尾部，
    # 背景与字幕在该尾巴内保持不动（满足"同页背景读完前不切"）。
    total = dur + TAIL
    subprocess.run(
        [FFMPEG, "-y", "-framerate", str(FPS), "-loop", "1", "-i", frame,
         "-i", a_mp3, "-t", f"{total:.3f}", "-c:v", "libx264",
         "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
         "-r", str(FPS), "-movflags", "+faststart", clip],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    return clip, dur


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True)
    ap.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    ap.add_argument("--output", default=None)
    ap.add_argument("--start", choices=["audio", "final"], default=None)
    args = ap.parse_args()

    proj = os.path.join(args.root, "projects", args.project)
    img_dir = os.path.join(proj, "images")
    script = os.path.join(proj, "script.txt")
    if not os.path.exists(script):
        log("缺少 script.txt:", script)
        sys.exit(1)
    if args.start != "audio" and not os.path.isdir(img_dir):
        # 尝试用 PowerPoint 导出（若可用）
        try:
            export_pptx(proj)
        except Exception as e:
            log("images/ 不存在且无法自动导出 PPTX:", e)
            log("请先用 PowerPoint 把每页导出为 images/slide_NN.png")
            sys.exit(1)

    pairs = parse_script(script)
    if not pairs:
        log("script.txt 未解析出任何 EN/ZH 对")
        sys.exit(1)
    log(f"解析到 {len(pairs)} 句（跨 {len(set(p[0] for p in pairs))} 页）")

    out_name = args.output or f"{args.project}_英语.mp4"
    if not out_name.lower().endswith(".mp4"):
        out_name += ".mp4"
    final = os.path.join(proj, out_name)

    clips = []
    for i, (slide, en, zh) in enumerate(pairs):
        bg = os.path.join(img_dir, f"{slide}.png")
        if not os.path.exists(bg):
            log(f"  [跳过] 找不到背景图: {bg}")
            continue
        tmp = os.path.join(proj, "_clips", f"{i:03d}")
        os.makedirs(tmp, exist_ok=True)
        if args.start == "final" and os.path.exists(os.path.join(tmp, "clip.mp4")):
            clip = os.path.join(tmp, "clip.mp4")
        else:
            clip, dur = build_clip(bg, en, zh, tmp)
            log(f"  [{i+1}/{len(pairs)}] slide {slide}: '{en[:40]}...' -> {dur:.2f}s")
        clips.append(clip)

    if not clips:
        log("无可用片段")
        sys.exit(1)

    lst = os.path.join(proj, "_clips", "concat.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for c in clips:
            f.write(f"file '{os.path.abspath(c)}'\n")
    subprocess.run(
        [FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", lst,
         "-c", "copy", final],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    log("成片:", final)


def export_pptx(proj):
    """可选：用 PowerPoint(win32com) 把 source.pptx 按页导出 PNG。"""
    import win32com.client
    pptx = os.path.join(proj, "source.pptx")
    if not os.path.exists(pptx):
        raise FileNotFoundError(pptx)
    out = os.path.join(proj, "images")
    os.makedirs(out, exist_ok=True)
    p = win32com.client.Dispatch("PowerPoint.Application")
    pres = p.Presentations.Open(os.path.abspath(pptx))
    pres.Export(out, "PNG")
    pres.Close()
    p.Quit()


if __name__ == "__main__":
    main()
