#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""用 edge-tts 生成每句参考音频，与 hvac_07 视频音频做能量包络互相关，
定位每句真实出现位置，验证前半段字幕是否对得上。"""
import asyncio, os, wave, struct, subprocess, json
import edge_tts

FF = "C:/Users/Damon/.workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"
HERE = os.path.dirname(os.path.abspath(__file__))
VIDEO_WAV = os.path.join(HERE, "hvac_07_audio.wav")
VOICE = "en-US-GuyNeural"

EN = [
    "Silencing and vibration isolation hold point.",
    "Confirm the silencer direction and the isolation hangers.",
    "Silencer installed with the flow arrow correct,",
    "isolation hangers on the fan and the duct near it.",
    "The silencer is upstream of the fan as drawn.",
    "But the duct is hard-coupled to the structure at this bracket — add an isolation hanger there.",
    "We will fit the isolation hanger and break the rigid link.",
    "Good.",
    "No rigid path to the structure.",
    "After the fix I sign the silencing and isolation.",
    "Hanger fitted, rigid link removed.",
    "Tagged as done.",
    "Good.",
    "Silencing and isolation accepted.",
    "Punch, rigid coupling.",
]

def envelope(wav_path, fr=16000, win_ms=50):
    w = wave.open(wav_path, "rb")
    n = w.getnframes(); sr = w.getframerate()
    raw = w.readframes(n)
    samples = struct.unpack("<" + "h" * n, raw)
    win = int(sr * win_ms / 1000)
    env = []
    for i in range(0, n, win):
        seg = samples[i:i + win]
        if seg:
            env.append((sum(x * x for x in seg) / len(seg)) ** 0.5)
        else:
            env.append(0.0)
    # 平滑
    k = 3
    sm = []
    for i in range(len(env)):
        a = max(0, i - k); b = min(len(env), i + k + 1)
        sm.append(sum(env[a:b]) / (b - a))
    return sm

def norm(v):
    m = max(v) if max(v) > 0 else 1
    return [x / m for x in v]

def ncc(a, b):
    # 归一化互相关（余弦相似度）
    na, nb = norm(a), norm(b)
    dot = sum(x * y for x, y in zip(na, nb))
    na2 = sum(x * x for x in na) ** 0.5
    nb2 = sum(x * x for x in nb) ** 0.5
    return dot / (na2 * nb2 + 1e-9)

async def gen_tts(idx, text):
    mp3 = os.path.join(HERE, f"_tts_{idx}.mp3")
    wav = os.path.join(HERE, f"_tts_{idx}.wav")
    if not os.path.exists(mp3):
        comm = edge_tts.Communicate(text, VOICE)
        await comm.save(mp3)
    subprocess.run([FF, "-y", "-i", mp3, "-vn", "-acodec", "pcm_s16le",
                    "-ar", "16000", "-ac", "1", wav], capture_output=True)
    return wav

async def main():
    # 视频包络
    venv = envelope(VIDEO_WAV)
    # 生成并定位每句
    results = []
    for i, text in enumerate(EN):
        wav = await gen_tts(i, text)
        tenv = envelope(wav)
        Lv, Lt = len(venv), len(tenv)
        best_lag, best_score = 0, -1
        step = 1
        for lag in range(0, Lv - Lt, step):
            score = ncc(venv[lag:lag + Lt], tenv)
            if score > best_score:
                best_score, best_lag = score, lag
        pos = best_lag * 0.05
        results.append((i + 1, pos, best_score, text))
        print("%2d  位置≈%6.2fs  相关=%.3f  %s" % (i + 1, pos, best_score, text[:40]))
    json.dump(results, open(os.path.join(HERE, "tts_align.json"), "w"), ensure_ascii=False, indent=2)
    print("\n(相关>0.5 视为可靠定位；<0.3 表示该句视频中可能不是原话)")

if __name__ == "__main__":
    asyncio.run(main())
