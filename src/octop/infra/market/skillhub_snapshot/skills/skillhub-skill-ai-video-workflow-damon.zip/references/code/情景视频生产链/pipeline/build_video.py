#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
船海情景视频合成器 (参数化, 可复用)

用法:
  python pipeline/build_video.py --project quality_coating_inspection
  python pipeline/build_video.py --project hse_lifting_stop --aspect 9:16
  python pipeline/build_video.py --project hse_talk --lang en          # 英语口播
  python pipeline/build_video.py --project hse_talk --voice-a en-US-GuyNeural \
                                 --voice-b en-US-JennyNeural

口播语言 --lang:
  zh  中文口播, 中文主字幕(大) + 英文副字幕(小)
  en  英语口播, 英文主字幕(大) + 中文副字幕(小)
  不传则用 scenes.json 里 meta.lang。

对话模式(scenes.json meta.mode == 'dialogue'):
  A/B 两个角色分别用不同音色, 屏幕上显示彩色角色名,
  A 靠左、B 靠右、旁白居中, 一眼看出谁在说话。

【字幕节奏 · 逐句推进】
  每镜画面固定不动, 该镜口播按"句子"切分:
    - 一句英语(口播)单独合成音频 + 单独显示(英上中下)
    - 读完这一句 -> 这句字幕消失 -> 下一句带翻译出现
    - 该镜所有句子读完, 才切到下一镜
  这样字幕只占底部一小条, 背景图始终看得见, 不再整段铺满屏幕。

字幕区高度按该句实际行数自适应, 底部对齐, 不裁切不重叠。

成本: 全本地 + edge-tts 免费在线合成, 零按量计费。
"""
import os, re, sys, json, glob, shutil, argparse, subprocess
import subtitle_render

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(ROOT, 'pipeline', 'config.json'), encoding='utf-8'))

ASPECTS = {'16:9': (1920, 1080), '9:16': (1080, 1920), '1:1': (1080, 1080)}

PAD = 10  # 字幕块上下额外留白(px), 计入占屏自检的 bar 高度

# 每种画幅的排版基线: 主字号/副字号/中文每行字数/英文每行字符/左右安全边距
LAYOUT = {
    # 字幕占屏自检基准(measure_bar.py): 单语字幕行业惯例约占画面高度 5%(国标 GB),
    # 双语(英+中)宜 ≤15%。maxbar=自动缩字号触发的占屏上限比例。
    # letterbox=True 时画面上下加黑边(电影遮幅), 字幕完全放在黑边里, 不挡主体。
    '16:9': dict(zh_pri=44, en_pri=38, zh_sec=30, en_sec=26,
                 zh_lim=22, en_lim=78, zh_sec_lim=34, en_sec_lim=40,
                 name=24, mx=80, mb=16, gap=20, name_gap=10,
                 t1=64, t2=30, block_gap=10, maxbar=0.15,
                 letterbox=True, lb_top=0.04, lb_bottom=0.19),
    '9:16': dict(zh_pri=56, en_pri=48, zh_sec=40, en_sec=34,
                 zh_lim=14, en_lim=36, zh_sec_lim=18, en_sec_lim=40,
                 name=32, mx=54, mb=16, gap=18, name_gap=10,
                 t1=68, t2=32, block_gap=20, maxbar=0.30,
                 letterbox=True, lb_top=0.02, lb_bottom=0.14),
    '1:1':  dict(zh_pri=46, en_pri=40, zh_sec=34, en_sec=30,
                 zh_lim=16, en_lim=42, zh_sec_lim=20, en_sec_lim=46,
                 name=28, mx=60, mb=40, gap=16, name_gap=9,
                 t1=58, t2=28, block_gap=16, maxbar=0.20,
                 letterbox=False, lb_top=0.03, lb_bottom=0.12),
}


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', required=True, help='projects/ 下的工程名')
    ap.add_argument('--aspect', default=CFG.get('default_aspect', '16:9'),
                    choices=list(ASPECTS))
    ap.add_argument('--lang', default=None, choices=['zh', 'en'],
                    help='口播语言; 不传则用 scenes.json 的 meta.lang')
    ap.add_argument('--voice', default=None, help='旁白音色(覆盖默认)')
    ap.add_argument('--voice-a', default=None, help='对话角色A音色')
    ap.add_argument('--voice-b', default=None, help='对话角色B音色')
    ap.add_argument('--rate', default=None)
    ap.add_argument('--bgm', default=None, help='背景音乐文件(可选)')
    ap.add_argument('--bgm-db', type=float, default=-22.0)
    ap.add_argument('--fps', type=int, default=25)
    ap.add_argument('--out', default=None)
    ap.add_argument('--no-copy', action='store_true')
    ap.add_argument('--no-letterbox', action='store_true',
                    help='关闭电影遮幅黑边(字幕直接叠在画面上)')
    ap.add_argument('--style', default=None,
                    help='字幕风格预设, 见 config.json styles (默认 news)')
    ap.add_argument('--keywords', default=None,
                    help='额外关键词文件(.json 列表 或 .txt 每行一词); 高亮字幕中命中词')
    ap.add_argument('--no-highlight', action='store_true',
                    help='关闭专业词高亮')
    return ap.parse_args()


def find_ffmpeg():
    p = shutil.which('ffmpeg')
    if p:
        return p
    for pat in [r"C:/Users/*/AppData/Local/Microsoft/WinGet/Packages/**/ffmpeg.exe",
                r"C:/Program Files/ffmpeg/bin/ffmpeg.exe",
                r"C:/ffmpeg/bin/ffmpeg.exe"]:
        hits = glob.glob(pat, recursive=True)
        if hits:
            return hits[0]
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


FFMPEG = find_ffmpeg()
if not FFMPEG:
    sys.exit("ERROR: 未找到 ffmpeg。装法: pip install imageio-ffmpeg")

_DUR = re.compile(r"Duration:\s*(\d+):(\d+):(\d+\.?\d*)")


def duration(path):
    r = subprocess.run([FFMPEG, '-i', path], capture_output=True, text=True)
    m = _DUR .search(r.stderr or '')
    if not m:
        raise RuntimeError('无法读取时长: ' + path)
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


def tts(text, out_path, voice, rate):
    import time
    last = ''
    for attempt in range(3):
        # 不预删: edge-tts --write-media 会覆盖写, 且沙箱安全删除 shim 会拦截 os.remove
        cmd = [CFG['edge_tts'], '--voice', voice, '--rate=' + rate,
               '--text', text, '--write-media', out_path]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode == 0 and os.path.exists(out_path) and os.path.getsize(out_path) > 0:
            return
        last = (r.stderr or '')[-300:]
        time.sleep(1.5 * (attempt + 1))
    raise RuntimeError('TTS 失败(%s): %s' % (voice, last))


# ---------- 折行: 返回行数组, 尽量在标点处断, 避免别扭硬切 ----------
ZH_PUNCT = '，。；！？、：；—.,?!;:'
ZH_SPLIT = '，。；、：'          # 优先在这些标点后断
EN_SPLIT = ',;:.-?!'            # 英文优先断行的标点


def _last_punct(s, puncts, after=0):
    """返回 s 中最后一个出现在 after 之后的标点下标, 没有则 -1。"""
    best = -1
    for p in puncts:
        j = s.rfind(p)
        if j >= after and j > best:
            best = j
    return best


def wrap_zh(s, limit, max_lines=5):
    s = (s or '').strip()
    if not s:
        return []
    lines, cur = [], ''
    for ch in s:
        cur += ch
        # 行够长就在标点后断, 避免一处塞太多标点造成碎片
        if ch in ZH_SPLIT and len(cur) >= limit * 0.6:
            lines.append(cur); cur = ''
        elif len(cur) >= limit:
            # 已满: 尽量在最近的标点断, 否则硬切(不把一个英文/数字词拆开)
            m = _last_punct(cur, ZH_SPLIT, int(limit * 0.45))
            if m > 0:
                lines.append(cur[:m + 1]); cur = cur[m + 1:]
            else:
                lines.append(cur); cur = ''
    if cur:
        lines.append(cur)
    # 尾部太碎(很短)就并进上一行
    if len(lines) >= 2 and len(lines[-1]) < limit * 0.35:
        lines[-2] = (lines[-2] + lines[-1]); lines = lines[:-1]
    if len(lines) > max_lines:
        lines = lines[:max_lines - 1] + [''.join(lines[max_lines - 1:])]
    return lines


def wrap_en(s, limit, max_lines=5):
    s = ' '.join((s or '').split())
    if not s:
        return []
    words = s.split()
    lines, cur = [], ''
    for wd in words:
        if cur and len(cur) + 1 + len(wd) > limit:
            lines.append(cur); cur = wd
        else:
            cur = (cur + ' ' + wd).strip()
    if cur:
        lines.append(cur)
    # 长行在最近标点处断, 而非生硬地按字数切
    out = []
    for ln in lines:
        if len(ln) <= limit:
            out.append(ln); continue
        m = _last_punct(ln, EN_SPLIT, int(limit * 0.5))
        if m > 0:
            out.append(ln[:m + 1].strip()); out.append(ln[m + 1:].strip())
        else:
            out.append(ln)
    lines = out
    # 孤字修复: 最后行若只有一个很短的词, 拉回上一行
    if len(lines) >= 2:
        last_w = lines[-1].split()
        prev_w = lines[-2].split()
        if len(last_w) == 1 and len(lines[-1]) <= 4 and len(prev_w) >= 2:
            lines[-2] = (lines[-2] + ' ' + lines[-1]).strip()
            lines = lines[:-1]
    if len(lines) > max_lines:
        lines = lines[:max_lines - 1] + [' '.join(lines[max_lines - 1:])]
    return lines


# ---------- 句子切分与配对(逐句推进的核心) ----------
def split_sentences(text, lang):
    """把一段口播按句子切开。en 按 .!? 后空格断; zh 按 。！？ 断。"""
    if not text or not text.strip():
        return []
    t = text.strip()
    if lang == 'en':
        parts = re.split(r'(?<=[.!?])\s+|\n+', t)
    else:
        parts = re.split(r'(?<=[。！？!?])\s*|\n+', t)
    return [p.strip() for p in parts if p.strip()]


def pair_sentences(spoken, trans, trans_lang):
    """把口播句与翻译句配对(用于逐句显示)。

    严格遵守"一句话一个字幕": 以口播(英文)句数为字幕条数, 每句英文配一句中文,
    各占一行(共两行)。中英文句子数通常不对等(中文更凝练), 用比例映射配对:
      第 i 句英文 -> 第 round(i*(m-1)/(n-1)) 句中文
    这样每句英文都分到一句中文(不漏译、不空行), 也绝不把多余中文拼成长串。
    若完全没有中文翻译, 则该字幕只显英文。
    """
    n, m = len(spoken), len(trans)
    if n == 0:
        return []
    if m == 0:
        return [(sp, '') for sp in spoken]
    if n == 1:
        return [(spoken[0], trans[0])]
    pairs = []
    denom = max(n - 1, 1)
    for i in range(n):
        j = int(round(i * (m - 1) / denom))
        j = max(0, min(m - 1, j))
        pairs.append((spoken[i], trans[j]))
    return pairs


def esc(p):
    """drawtext 路径转义(Windows 盘符冒号)。"""
    return p.replace('\\', '/').replace(':', '\\:')


def lh(fs, ls):
    """一行的像素高(含行距)。"""
    return int(fs * 1.22) + ls


def main():
    a = parse_args()
    W, H = ASPECTS[a.aspect]
    FPS = a.fps
    TAIL, FADE, SENT_TAIL, ZMAX = 0.6, 0.45, 0.45, 1.10
    LY = LAYOUT[a.aspect]

    # 字幕风格预设
    style_name = a.style or CFG.get('default_style', 'news')
    if style_name not in CFG.get('styles', {}):
        print('警告: 风格 %s 不存在, 使用 news' % style_name)
        style_name = 'news'
    STYLE = CFG['styles'][style_name]
    print('字幕风格:', style_name, STYLE.get('name', ''))

    # 电影遮幅黑边: 画面主体缩小居中, 字幕放在下方黑边里, 不挡主体
    use_lb = LY.get('letterbox', False) and not a.no_letterbox
    if use_lb:
        lb_top = int(H * LY['lb_top'])
        lb_bottom = int(H * LY['lb_bottom'])
        lb_h = H - lb_top - lb_bottom          # 画面主体高度
        lb_scale = lb_h / H                    # 画面缩放比例
        lb_y = lb_top                          # 画面主体上沿 y
    else:
        lb_top = lb_bottom = lb_y = 0
        lb_h = H
        lb_scale = 1.0

    proj = os.path.join(ROOT, 'projects', a.project)
    if not os.path.isdir(proj):
        sys.exit('工程不存在: ' + proj)
    img_dir = os.path.join(proj, 'images')
    aud_dir = os.path.join(proj, 'audio')
    clip_dir = os.path.join(proj, '_clips')
    cap_dir = os.path.join(proj, '_cap')
    for d in (aud_dir, clip_dir, cap_dir):
        os.makedirs(d, exist_ok=True)

    data = json.load(open(os.path.join(proj, 'scenes.json'), encoding='utf-8'))
    meta, scenes = data['meta'], data['scenes']
    mode = meta.get('mode', 'narration')
    lang = a.lang or meta.get('lang') or CFG.get('default_lang', 'zh')
    dialogue = (mode == 'dialogue')

    # ---- 音色 ----
    # 旁白音色独立, 必须 ≠ A/B, 否则"介绍剧情的人"和"角色"分不出来
    narr_voice = (a.voice or CFG.get('narrator_voice_%s' % lang)
                  or CFG['voice_%s' % lang])
    voice_a = a.voice_a or CFG['dialogue_voice_a_%s' % lang]
    voice_b = a.voice_b or CFG['dialogue_voice_b_%s' % lang]
    rate = a.rate or (CFG['rate_en'] if lang == 'en' else CFG['rate'])

    # ---- 缺料检查 ----
    missing = [s['image_file'] for s in scenes
               if not os.path.exists(os.path.join(img_dir, s['image_file']))]
    if missing:
        sys.exit('缺图 %d 张: %s\n先补齐 images/ 或跑 pipeline/reuse_assets.py'
                 % (len(missing), ', '.join(missing)))
    notext = [s['idx'] for s in scenes
              if not (s.get('narration_zh') if lang == 'zh' else s.get('narration_en'))]
    if notext:
        sys.exit('第 %s 镜缺 %s 文案。对话片请先补中文字幕:\n'
                 '  填好 projects/%s/translate_needed.json 后跑\n'
                 '  node pipeline/apply_zh.js --project %s'
                 % (', '.join(map(str, notext)), '中文' if lang == 'zh' else '英文',
                    a.project, a.project))

    print('ffmpeg :', FFMPEG)
    print('工程   : %s | %s | %s | 口播%s'
          % (a.project, a.aspect, '双人对话' if dialogue else '旁白讲解',
             '英语' if lang == 'en' else '中文'))
    print('音色   : 旁白 %s%s' % (narr_voice,
          ' | A %s | B %s' % (voice_a, voice_b) if dialogue else ''))
    print('字幕   : 逐句推进(一句口播+对应翻译, 画面固定, 读完一句切下一句)')

    clips = []

    # ---------- 片头标题卡 ----------
    intro = os.path.join(clip_dir, 'scene_00_title.mp4')
    idur = 3.0
    title_png = os.path.join(cap_dir, 'title.png')
    title_lines = []
    for txt in wrap_zh(meta['title_zh'], LY['zh_lim'] + 4, 3):
        title_lines.append({
            'text': txt, 'lang': 'zh', 'base_fs': LY['t1'],
            'color': STYLE.get('pri_color', '#FFFFFF'), 'keywords': set(),
            'anchor': 'ms', 'x': W / 2, 'group': 'pri'})
    for txt in wrap_en(meta['title_en'], LY['en_sec_lim'], 3):
        title_lines.append({
            'text': txt, 'lang': 'en', 'base_fs': LY['t2'],
            'color': STYLE.get('sec_color', '#FFD54A'), 'keywords': set(),
            'anchor': 'ms', 'x': W / 2, 'group': 'sec'})
    subtitle_render.layout_and_render(
        W, H, STYLE, title_lines,
        use_lb=False, lb_bottom=0, inner_gap=12, block_gap=24, name_gap=12,
        base_margin=0, v_center=True, out_path=title_png)

    bg_f = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}"
    if use_lb:
        bg_f += f",scale=-1:{lb_h}:force_original_aspect_ratio=decrease," \
                f"pad={W}:{H}:(ow-iw)/2:{lb_y}:black"
    vf_title = ','.join([
        bg_f, 'boxblur=12:1', 'eq=brightness=-0.22',
        f"fade=t=in:st=0:d=0.6,fade=t=out:st={idur-0.6:.2f}:d=0.6",
        'format=yuv420p',
    ])
    fc_title = (f"[0:v]{vf_title}[bg];"
                f"[1:v]format=rgba[sub];"
                f"[bg][sub]overlay=0:0[vout]")
    subprocess.run([FFMPEG, '-y', '-loop', '1', '-t', str(idur),
                    '-i', os.path.join(img_dir, scenes[0]['image_file']),
                    '-loop', '1', '-t', str(idur), '-i', title_png,
                    '-f', 'lavfi', '-t', str(idur),
                    '-i', 'anullsrc=channel_layout=stereo:sample_rate=48000',
                    '-filter_complex', fc_title,
                    '-map', '[vout]', '-map', '2:a',
                    '-c:v', 'libx264', '-preset', 'medium',
                    '-crf', '20', '-pix_fmt', 'yuv420p', '-r', str(FPS),
                    '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2',
                    '-shortest', intro], check=True, capture_output=True)
    print('[00] 标题卡 %.1fs' % idur)
    clips.append(intro)

    # ---------- 逐镜: 画面固定, 口播按句切分, 逐句推进 ----------
    for sc in scenes:
        i = sc['idx']
        spk = sc.get('speaker', 'N')

        # 该镜的音色与朗读文本
        if dialogue and spk == 'A':
            voice = voice_a
        elif dialogue and spk == 'B':
            voice = voice_b
        else:
            voice = narr_voice
        speak = (sc.get('tts_%s' % lang) or
                 sc.get('narration_%s' % lang) or '').strip()
        trans = (sc.get('narration_%s' % ('zh' if lang == 'en' else 'en')) or '').strip()

        spoken_lang = lang
        trans_lang = 'zh' if lang == 'en' else 'en'

        # ---- 按句切分: 一句口播 + 对应一句翻译 ----
        spoken_sents = split_sentences(speak, spoken_lang)
        if not spoken_sents:
            # 极端情况: 该镜无口播文案, 给一张静默空镜, 避免拼接错位
            silent = os.path.join(clip_dir, 'scene_%02d_empty.mp4' % i)
            subprocess.run([FFMPEG, '-y', '-loop', '1', '-t', '1.2',
                            '-i', os.path.join(img_dir, sc['image_file']),
                            '-f', 'lavfi', '-t', '1.2',
                            '-i', 'anullsrc=channel_layout=stereo:sample_rate=48000',
                            '-vf', f"scale={W}:{H}:force_original_aspect_ratio=increase,"
                                   f"crop={W}:{H},format=yuv420p,fps={FPS}",
                            '-c:v', 'libx264', '-preset', 'medium', '-crf', '20',
                            '-pix_fmt', 'yuv420p', '-r', str(FPS), '-c:a', 'aac',
                            '-b:a', '192k', '-ar', '48000', '-ac', '2', '-shortest',
                            silent], capture_output=True, text=True)
            clips.append(silent)
            continue
        trans_sents = split_sentences(trans, trans_lang)
        pairs = pair_sentences(spoken_sents, trans_sents, trans_lang)

        # ---- 预合成每句音频, 拿到各自时长(用于画面连续 zoom 与句子节奏) ----
        sent = []
        for k, (sp, tr) in enumerate(pairs):
            aud = os.path.join(aud_dir, 'scene_%02d_s%02d_%s.mp3' % (i, k, lang))
            need_tts = False
            if not os.path.exists(aud) or os.path.getsize(aud) == 0:
                need_tts = True
            else:
                try:
                    duration(aud)
                except RuntimeError:
                    need_tts = True  # 文件损坏(如中断的 0 字节), 重下
            if need_tts:
                print('[%02d-%d] 配音 %s ...' % (i, k, voice))
                tts(sp, aud, voice, rate)
            sd = duration(aud)
            sent.append((aud, sd, sp, tr))
        scene_total = sum(sd + SENT_TAIL for _, sd, _, _ in sent) or 1.0

        # ---- 逐句生成子片段(同一画面, 句子切换) ----
        t_cum = 0.0
        n = len(sent)
        for k, (aud, sd, sp, tr) in enumerate(sent):
            kdur = round(sd + SENT_TAIL, 2)
            frames = int(kdur * FPS)
            # 画面连续缓慢 zoom: 跨该镜所有句子平滑推进, 不每句重头缩
            z_start = 1.0 + (ZMAX - 1.0) * (t_cum / scene_total)
            z_end = 1.0 + (ZMAX - 1.0) * ((t_cum + kdur) / scene_total)
            t_cum += kdur

            # ---- 主/副字幕: PIL 渲染 PNG 后 overlay, 支持描边/投影/专业词高亮 ----
            if lang == 'en':
                pri_raw, sec_raw = sp, tr
                fs_pri, fs_sec = LY['en_pri'], LY['zh_sec']
                lim_pri, lim_sec = LY['en_lim'], LY['zh_sec_lim']
                wrap_pri, wrap_sec = wrap_en, wrap_zh
            else:
                pri_raw, sec_raw = sp, tr
                fs_pri, fs_sec = LY['zh_pri'], LY['en_sec']
                lim_pri, lim_sec = LY['zh_lim'], LY['en_sec_lim']
                wrap_pri, wrap_sec = wrap_zh, wrap_en
            pri_color = STYLE.get('pri_color', '#FFFFFF')
            sec_color = STYLE.get('sec_color', '#FFD54A')

            fs_name = LY['name']
            inner_gap = 8
            block_gap = LY['block_gap']
            show_name = dialogue

            # 关键词: scene.keywords / sentence_keywords / project keywords.json / --keywords
            kw_set = set()
            if not a.no_highlight:
                kw_set.update(sc.get('keywords', []))
                sent_kws = sc.get('sentence_keywords', [])
                if isinstance(sent_kws, list) and k < len(sent_kws):
                    sk = sent_kws[k]
                    if isinstance(sk, (list, tuple, set)):
                        kw_set.update(sk)
                proj_kw_file = os.path.join(proj, 'keywords.json')
                if os.path.exists(proj_kw_file):
                    kw_set.update(subtitle_render.load_keywords(proj_kw_file))
                if a.keywords:
                    kw_set.update(subtitle_render.load_keywords(a.keywords))

            # 对齐: A 靠左 / B 靠右 / 旁白居中
            if dialogue and spk == 'A':
                anchor, x_ref = 'ls', LY['mx']
            elif dialogue and spk == 'B':
                anchor, x_ref = 'rs', W - LY['mx']
            else:
                anchor, x_ref = 'ms', W / 2

            # 字号自适应: 用 PIL 实际度量
            # 严格遵守"一句话一个字幕": 每语强制单行(不内部折行); 放不下才缩字号, 再不行才折行兜底
            min_fs_pri = 22 if use_lb else 20
            min_fs_sec, min_fs_name = 18, 18
            max_h = int(lb_bottom * 0.84) if use_lb else int(H * LY.get('maxbar', 0.42))
            base_m = 16 if use_lb else LY['mb']
            if anchor == 'ls':
                avail_w = W - x_ref - base_m
            elif anchor == 'rs':
                avail_w = x_ref - base_m
            else:
                avail_w = W - 2 * base_m
            wfac = 0.90 if kw_set else 0.97  # 高亮词会放大, 留安全余量

            def _build_lines(fs_p, fs_s, fs_n, pri_txt, sec_txt):
                ls = []
                if show_name:
                    nm = sc.get('speaker_en', '') or 'Narrator'
                    nz = sc.get('speaker_zh', '')
                    if spk == 'N':
                        label = '▍%s' % nm
                    elif nz and nz != nm:
                        label = '▍%s｜%s' % (nm, nz)
                    else:
                        label = '▍%s' % nm
                    ls.append({
                        'text': label[:46], 'lang': lang, 'base_fs': fs_n,
                        'color': {'A': CFG['color_a'], 'B': CFG['color_b']}.get(spk, CFG['color_narrator']),
                        'keywords': set(), 'anchor': anchor, 'x': x_ref, 'group': 'name'})
                ls.append({
                    'text': pri_txt, 'lang': 'en' if lang == 'en' else 'zh',
                    'base_fs': fs_p, 'color': pri_color, 'keywords': kw_set,
                    'anchor': anchor, 'x': x_ref, 'group': 'pri'})
                ls.append({
                    'text': sec_txt, 'lang': 'zh' if lang == 'en' else 'en',
                    'base_fs': fs_s, 'color': sec_color, 'keywords': kw_set,
                    'anchor': anchor, 'x': x_ref, 'group': 'sec'})
                return ls

            fit = False
            for _ in range(12):
                lines = _build_lines(fs_pri, fs_sec, fs_name, pri_raw, sec_raw)
                total_h, _ = subtitle_render.layout_and_render(
                    W, H, STYLE, lines, use_lb=use_lb, lb_bottom=lb_bottom,
                    inner_gap=inner_gap, block_gap=block_gap, name_gap=LY['name_gap'],
                    base_margin=base_m,
                    out_path=None)
                # 量最宽行(含专业词高亮放大后的真实宽度), 确保单行不超屏宽
                maxw = 0
                for ln in lines:
                    ww = subtitle_render.measure_line_width(
                        ln['text'], ln.get('keywords', set()),
                        ln['base_fs'], ln['lang'], STYLE)
                    if ww > maxw:
                        maxw = ww
                if total_h <= max_h and maxw <= avail_w * wfac:
                    fit = True
                    break
                if fs_pri <= min_fs_pri:
                    break
                fs_pri = max(min_fs_pri, fs_pri - 3)
                fs_sec = max(min_fs_sec, fs_sec - 2)
                fs_name = max(min_fs_name, fs_name - 2)
            if not fit:
                # 缩到下限仍超宽: 兜底按原折行(极长句), 避免文字出框
                pl = wrap_pri(pri_raw, lim_pri)
                sl = wrap_sec(sec_raw, lim_sec)
                lines = []
                if show_name:
                    nm = sc.get('speaker_en', '') or 'Narrator'
                    nz = sc.get('speaker_zh', '')
                    label = ('▍%s｜%s' % (nm, nz)) if (nz and nz != nm) else ('▍%s' % nm)
                    lines.append({
                        'text': label[:46], 'lang': lang, 'base_fs': fs_name,
                        'color': {'A': CFG['color_a'], 'B': CFG['color_b']}.get(spk, CFG['color_narrator']),
                        'keywords': set(), 'anchor': anchor, 'x': x_ref, 'group': 'name'})
                for txt in pl:
                    lines.append({
                        'text': txt, 'lang': 'en' if lang == 'en' else 'zh',
                        'base_fs': fs_pri, 'color': pri_color, 'keywords': kw_set,
                        'anchor': anchor, 'x': x_ref, 'group': 'pri'})
                for txt in sl:
                    lines.append({
                        'text': txt, 'lang': 'zh' if lang == 'en' else 'en',
                        'base_fs': fs_sec, 'color': sec_color, 'keywords': kw_set,
                        'anchor': anchor, 'x': x_ref, 'group': 'sec'})

            # 渲染字幕 PNG
            sub_png = os.path.join(cap_dir, 'sub_%02d_%02d.png' % (i, k))
            subtitle_render.layout_and_render(
                W, H, STYLE, lines, use_lb=use_lb, lb_bottom=lb_bottom,
                inner_gap=inner_gap, block_gap=block_gap, name_gap=LY['name_gap'],
                base_margin=base_m,
                out_path=sub_png)

            # 画面固定: 仅首句淡入、末句淡出
            vfade = []
            if k == 0:
                vfade.append(f"fade=t=in:st=0:d={FADE}")
            if k == n - 1:
                vfade.append(f"fade=t=out:st={kdur-FADE:.2f}:d={FADE}")

            base_vf = [
                f"scale={W*2}:{H*2}:force_original_aspect_ratio=increase,crop={W*2}:{H*2}",
                f"zoompan=z='min({z_start:.4f}+({z_end-z_start:.4f})*on/{frames},{z_end:.4f})':"
                f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
                f"d={frames}:s={W}x{H}:fps={FPS}",
            ]
            if use_lb:
                base_vf.append(f"scale=-1:{lb_h}:force_original_aspect_ratio=decrease,"
                               f"pad={W}:{H}:(ow-iw)/2:{lb_y}:black")
            bg_vf = ','.join(base_vf + vfade + ['format=yuv420p'])
            fc = (f"[0:v]{bg_vf}[bg];"
                  f"[1:v]format=rgba[sub];"
                  f"[bg][sub]overlay=0:0[vout];"
                  f"[2:a]apad=whole_dur={kdur},"
                  f"afade=t=out:st={kdur-0.3:.2f}:d=0.3,"
                  "aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[a]")
            clip = os.path.join(clip_dir, 'scene_%02d_s%02d.mp4' % (i, k))
            cmd = [FFMPEG, '-y', '-loop', '1', '-t', str(kdur),
                   '-i', os.path.join(img_dir, sc['image_file']),
                   '-loop', '1', '-t', str(kdur), '-i', sub_png,
                   '-i', aud,
                   '-filter_complex', fc,
                   '-map', '[vout]', '-map', '[a]',
                   '-c:v', 'libx264', '-preset', 'medium', '-crf', '20',
                   '-pix_fmt', 'yuv420p', '-r', str(FPS),
                   '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2',
                   '-t', str(kdur), clip]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0:
                print('FFMPEG 失败 scene %d sent %d:\n%s' % (i, k, r.stderr[-1500:]))
                sys.exit(1)
            print('[%02d-%d] %-7s %.2fs  %s' % (i, k,
                  ('A' if spk == 'A' else 'B' if spk == 'B' else '旁白'),
                  kdur, (sp[:28] + '…') if len(sp) > 28 else sp))
            clips.append(clip)

    # ---------- 拼接 ----------
    tag = {'16:9': '', '9:16': '_竖屏', '1:1': '_方屏'}[a.aspect]
    if lang == 'en':
        tag = '_英语' + tag
    if dialogue:
        tag = '_对话' + tag
    out = a.out or os.path.join(proj, a.project + tag + '.mp4')
    lst = os.path.join(clip_dir, 'list.txt')
    with open(lst, 'w', encoding='utf-8') as f:
        for c in clips:
            f.write("file '%s'\n" % c.replace('\\', '/'))

    merged = out if not a.bgm else os.path.join(clip_dir, '_nobgm.mp4')
    r = subprocess.run([FFMPEG, '-y', '-f', 'concat', '-safe', '0', '-i', lst,
                        '-c', 'copy', '-movflags', '+faststart', merged],
                       capture_output=True, text=True)
    if r.returncode != 0:
        print('直拼失败, 转码重拼 ...')
        r = subprocess.run([FFMPEG, '-y', '-f', 'concat', '-safe', '0', '-i', lst,
                            '-c:v', 'libx264', '-preset', 'medium', '-crf', '20',
                            '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k',
                            '-movflags', '+faststart', merged],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print(r.stderr[-1500:]); sys.exit(1)

    if a.bgm:
        total = duration(merged)
        r = subprocess.run(
            [FFMPEG, '-y', '-i', merged, '-stream_loop', '-1', '-i', a.bgm,
             '-filter_complex',
             f"[1:a]volume={a.bgm_db}dB,afade=t=out:st={total-2:.2f}:d=2[bg];"
             '[0:a][bg]amix=inputs=2:duration=first:dropout_transition=0[a]',
             '-map', '0:v', '-map', '[a]', '-c:v', 'copy',
             '-c:a', 'aac', '-b:a', '192k', '-shortest',
             '-movflags', '+faststart', out],
            capture_output=True, text=True)
        if r.returncode != 0:
            print('BGM 混音失败, 输出无 BGM 版本'); shutil.copy(merged, out)

    print('DONE: %s  %.2fs  %.1fMB'
          % (out, duration(out), os.path.getsize(out) / 1048576))

    if not a.no_copy:
        os.makedirs(CFG['outputs_dir'], exist_ok=True)
        dst = os.path.join(CFG['outputs_dir'], os.path.basename(out))
        if os.path.normcase(os.path.abspath(out)) != os.path.normcase(os.path.abspath(dst)):
            shutil.copy(out, dst)
            print('副本:', dst)
        else:
            print('输出路径已在目标目录, 跳过复制')


if __name__ == '__main__':
    main()
