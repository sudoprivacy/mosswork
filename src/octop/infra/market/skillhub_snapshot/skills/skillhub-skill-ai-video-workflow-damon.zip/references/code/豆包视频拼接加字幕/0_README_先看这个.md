# 豆包视频拼接加字幕（视频拼接工作流 · 伞包子产品）

> 复制自：`D:\微信小程序\情景视频存放处\豆包视频加字幕工作流\`（2026-09-09 整体复制，已排除 `__pycache__/`）
> 实物 = 豆包文生视频 → 多片段拼接/处理 → 中英硬字幕（英文上中文下 · 逐句切） → 抽帧验证
> 适用范围：豆包 / 即梦等文生视频生成的短视频，要加"跟着说话走、逐句切"中英字幕
> 配套提示词模板：见本目录 `豆包提示词包_轴舵系核查_v4_无字幕版.md`（逻辑冻结，只加字幕、不出字幕）

---

## 〇、三条铁律（动任何东西前先记住）

1. **豆包生成时绝不让它出字幕**。文生视频模型不会写字，让它出必出乱码伪文字。提示词里必须写"画面无任何文字"，字幕 100% 后期加。
2. **字幕必须跟着音频走**：视频里说到哪句才显哪句，这句读完消失、下一句才出；英文在上、中文在下；绝不整段一起蹦。
3. **字幕直接压画面 + 阴影描边，不加黑幕**：渲染在原始画面上，靠 `Shadow` 阴影 + `Outline` 描边与背景区分；**不再用 `drawbox` 黑底条**。前提是源视频本身无字幕（按铁律 1）。

---

## 一、六步流水线 + 每步可单独修改 + 修改后验证

> **设计原则**：每步**独立命令 / 独立参数 / 独立脚本**，改任何一步都不会把其他步"带坏"——这是"可单步改"的基础。
> 改完任一步，必须跑对应的"修改后验证"列，**通过才能进下一步**；不通过 → 回退这步。

| # | 步骤 | 改什么 | 修改后验证 |
|---|---|---|---|
| 1 | **豆包生成干净无字幕视频** | 提示词包 `豆包提示词包_*.md` 里的"可直接复制给豆包的一段话" | **肉眼**：源视频里**绝无任何文字**（铁律 1）。ffprobe 抽 3 帧：底部无字幕条。失败 → 回到豆包按"无字幕"重生成，**不要**在后期试图"擦掉" |
| 2 | **抽音频 + 找真实停顿** | `silencedetect=noise=-35dB:d=0.08` 的 dB / 时长阈值 | ffmpeg 输出的 `silence_start / silence_end` 列表本身就是验证——边界是否落在真实停顿、是否有遗漏。失败 → 调 dB/时长阈值重抽 |
| 3 | **拆句** | `clauses.json` 的中英对照 + `--per-segment 1,1,4`（每段塞几句） | 每句 `en/cn` 字符数与第 2 段时间大致成比例（按字符数均分），**不能超段时长**。失败 → 调 `--per-segment` 或改 clauses |
| 4 | **写 ASS** | `PlayResX/Y` / `WrapStyle=1` / `Fontsize=40` / `MarginL/R=60` / `MarginV=30` / `Alignment=2` / `Shadow=2` / `Outline=3` / 每句 `English\N中文` | **关键参数静态检查**（见下方 §三）：`WrapStyle` 必须=1（=2 必超屏）、字号 ≥40、`Shadow`/`Outline` 非 0、不含 `\fad` 等花哨、英文 `\N` 中文顺序正确。失败 → 改回冻结参数 |
| 5 | **烧入字幕** | ffmpeg `-vf "ass=fix.ass"`（**必须相对路径 + `cd` 进目录**） | 烧入后再 ffprobe 抽 3 帧：底部有字幕。**绝不能**含 `drawbox` / `crop`。失败 → 99% 是 ASS 用了 Windows 绝对路径（冒号被 libass 当分隔符），改回 `ass=fix.ass` 相对路径 |
| 6 | **验证**（**必须做**，不能凭感觉） | `verify_subtitles.py --times ... --expect present absent present ...` | 说话段 → `present`，停顿间隙 → `absent`，每帧只一句、英文上中文下。**不通过 → 回到第 2/3/4 步重做**，不要带病出片 |

### 自动化脚本（实物里就有，按需用）

- `sync_subtitles.py` —— 横屏：抽音频 + silencedetect + 按 clauses.json 拆句 + 生成 ASS（省手写第 4 步）
  - `python sync_subtitles.py analyze --video xxx.mp4` 先看真实停顿
  - `python sync_subtitles.py build --video xxx.mp4 --json clauses.json --out fix.ass --per-segment 1,1,4`
- `gen_vertical_sentences.py` —— **竖屏通用**（顺序无关 · 真实位置对齐）：用 edge-tts 给每句生成参考音频，与源视频音频做能量包络互相关，把每句字幕钉在真实出现位置（豆包对白常被打乱，故不按脚本顺序 1:1 映射）
  - 配套 `verify_true.py` 核对每句是否钉在 TTS 真实位置
- `verify_subtitles.py` —— 第 6 步抽帧像素验证
- `highlight_terms.py` —— 专业词高亮（放大 + 变色），是独立模块，可并入第 4 步
  - 演示：`demo_highlight.py` → `hvac_07_highlight.ass` + `hvac_07_高亮演示.mp4`

---

## 二、入口命令（实物已就绪，照跑即可）

```bat
set PY=C:/Users/Damon/.workbuddy/binaries/python/envs/default/Scripts/python.exe
set FF=C:/Users/Damon/.workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe

:: 第 1 步：豆包按提示词生成 → 源视频 xxx.mp4
:: 第 2 步：抽音频 + 找停顿
%FF% -i xxx.mp4 -vn -acodec pcm_s16le -ar 16000 -ac 1 _audio_analysis/audio.wav -y
%FF% -i _audio_analysis/audio.wav -af "silencedetect=noise=-35dB:d=0.08" -f null - 2>&1 | findstr "silence_start silence_end"

:: 第 3 步：编辑 clauses.json（中英对照 + 期望段数）
:: 第 4 步：写 ASS（手写或用 sync_subtitles.py build 自动）
:: 第 5 步：烧入（cd 进目录，ass 用相对路径）
cd /d "D:\Workbuddy缓存位置\标准讲解视频工作流\豆包视频拼接加字幕"
%FF% -i xxx.mp4 -vf "ass=fix.ass" -c:a copy -y xxx_修正字幕.mp4

:: 第 6 步：验证（说话段 present，停顿段 absent）
%PY% verify_subtitles.py --video xxx_修正字幕.mp4 --times 1.0 1.76 3.0 6.1 7.0 11.0 --expect present absent present absent present present
```

> **逐句切核验**（实物同源要求）：同页/同段背景在所有句子读完前**不切换**，每句字幕独立 start/end；时间轴边界必须钉在 silencedetect 真实停顿。

---

## 三、ASS 关键参数（冻结 · 改回红线）

如果改坏了 ASS，回退到这套参数（已验证 · 不超屏 · 跟音频）：

```
PlayResX / PlayResY    = 视频实际分辨率
WrapStyle: 1            ← 必须 1（2 必超屏）
Style Fontsize: 40
MarginL = MarginR = 60  ← 防贴边
MarginV = 30
Alignment = 2           ← 底部居中
Shadow = 2              ← 阴影（与背景区分）
Outline = 3             ← 描边
BorderStyle = 1         ← 描边样式（不用黑底）
Dialogue Text = English\N中文   ← 最后 \N 分中英行
```

静态自检脚本（动手前一行 bash 就能过）：
```bat
findstr /C:"WrapStyle: 1" /C:"Fontsize: 40" /C:"Alignment: 2" /C:"Shadow:" /C:"Outline:" fix.ass
```

---

## 四、坑位清单（踩过的，别再踩 · 来自实物 md 第 8 节）

| 现象 | 根因 | 解决 |
|---|---|---|
| 字幕静默没烧进去 | ASS 用了 Windows 绝对路径（冒号被 libass 当分隔符） | 改相对路径 `ass=fix.ass`，`cd` 进目录再跑 |
| 源视频自带乱码透出 | 源视频本身有字幕（违反铁律 1） | 回到豆包按"无字幕"重生成源视频，再跑本工作流（已不加黑幕） |
| 字幕超屏 | `WrapStyle=2` 禁止换行 | 改 `WrapStyle=1` |
| 只有中文、英文没了 | 字号太小/沉底 | 字号 40 + `MarginV=30`，两行在画面底部垂直居中 |
| 整段一起蹦 | 时间轴是估的，没按音频 | 重跑 silencedetect，边界钉真实停顿 |
| 改了字幕但视频没变 | 旧缓存复用（存在即复用） | 输出文件名带哈希，或先删旧文件再压 |

---

## 五、本子产品如何接入伞包固定工作流

| 六步法 | 本工作流对应 | 红线闸门 |
|---|---|---|
| ①审题 | 确认豆包提示词包版本 + 镜头数 + 中英台词 | 提示词含"画面无任何文字" |
| ②定方向 | 横屏 1280×720 / 竖屏 1080×1920 | 视频实际分辨率 |
| ③排版（拼接） | 抽音频 → silencedetect → 拆句 → ASS | WrapStyle=1 / 字号40 / 阴影描边 / 不加黑幕 |
| ④定形式 | 英文上中文下 + 逐句切 + 阴影描边 | 铁律 2/3 |
| ⑤质检校验 | `verify_subtitles.py` 抽帧 + 肉眼复核 | 说话段 present / 停顿段 absent |
| ⑥出片验收 | `check.py xxx_修正字幕.mp4 --expect 12.0` 跑 A0–A8 | 单音轨 / 时长吻合 / 无黑场 / 结尾完整 |

> **修改后强制**：改完任何一步 → 跑对应"修改后验证"列 + ⑥ `check.py` A0–A8，**不通过不出片**。

---

## 六、文件清单（已复制 · 6.9MB）

| 类型 | 关键文件 |
|---|---|
| 流水线主脚本 | `sync_subtitles.py`（横屏）/ `gen_vertical_sentences.py`（竖屏真实位置对齐） |
| ASS 构建 | `build_ass_hvac07.py` / `build_ass_true.py` |
| 验证 | `verify_subtitles.py` / `verify_sentences.py` / `verify_true.py` / `verify_hvac07_sync.py` |
| 抽帧/检测 | `detect_regions.py` / `align_tts.py` |
| 高亮模块 | `highlight_terms.py` + `demo_highlight.py`（独立可用） |
| 完整工作流文档 | `豆包视频_加字幕_完整工作流.md`（必读）/ `情景文章→豆包视频_完整工作流.md` |
| 提示词模板 | `豆包提示词包_轴舵系核查_v4_无字幕版.md`（逻辑冻结） |
| 测试样本 | `hvac_07_竖屏字幕测试.mp4` / `hvac_07_高亮演示.mp4` + 配套 .ass / .json / .wav |
| 样板字体 | `样板字体.jpg` / `微信图片_*.jpg` |
