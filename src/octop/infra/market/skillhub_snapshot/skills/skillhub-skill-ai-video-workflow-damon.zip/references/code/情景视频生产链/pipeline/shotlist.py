#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图片清单生成器 —— 让你提前知道"要生成什么图"

用法:
  python pipeline/shotlist.py --project hse_lifting_stop
  python pipeline/shotlist.py --project X --aspect 9:16

产出: projects/<工程>/图片清单.md
  逐镜列出: 画面要什么(中文) / 英文提示词(可直接粘给任意生图工具) / 文件名怎么起
  已经有图的镜会标 ✅, 你只需要补没打勾的。
"""
import os, json, argparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(ROOT, 'pipeline', 'config.json'), encoding='utf-8'))

SIZE = {'16:9': '1920×1080（或 1536×1024）', '9:16': '1080×1920', '1:1': '1024×1024'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', required=True)
    ap.add_argument('--aspect', default=CFG.get('default_aspect', '16:9'))
    ap.add_argument('--out', default=None)
    a = ap.parse_args()

    proj = os.path.join(ROOT, 'projects', a.project)
    data = json.load(open(os.path.join(proj, 'scenes.json'), encoding='utf-8'))
    meta, scenes = data['meta'], data['scenes']
    img_dir = os.path.join(proj, 'images')
    inbox = os.path.join(ROOT, 'assets', 'inbox', a.project)

    def hint(s):
        """画面提示: 对话镜优先用中文台词(已回填的话), 更直观。"""
        base = s.get('image_hint_zh', '') or ''
        if s.get('speaker') in ('A', 'B') and s.get('narration_zh'):
            return '%s 说：「%s」' % (s.get('speaker_zh') or s['speaker'],
                                    s['narration_zh'])
        return base

    L = []
    w = L.append
    w('# 图片清单 · %s' % meta['title_zh'])
    w('')
    w('> 英文标题：%s  ' % meta['title_en'])
    w('> 工程名：`%s`　|　模式：%s　|　口播：%s  '
      % (a.project,
         '双人对话' if meta.get('mode') == 'dialogue' else '旁白讲解',
         '英语' if meta.get('lang') == 'en' else '中文'))
    w('> 建议画幅：**%s**，尺寸 %s' % (a.aspect, SIZE.get(a.aspect, '')))
    w('')
    w('## 怎么交给我')
    w('')
    w('1. 图片放这个目录（没有就新建）：')
    w('   ```')
    w('   %s' % inbox.replace('\\', '/'))
    w('   ```')
    w('2. 文件名**以镜号数字开头**即可对号入座，例如 `3_叫停.jpg` = 第 3 镜。')
    w('   不带数字的话，按文件名排序依次填补还缺图的镜。')
    w('3. jpg / png / webp / bmp / tif / avif 都行，我会自动转格式和缩放。')
    w('4. 你只给几张也没关系，剩下的镜我用素材库或 AI 补。')
    w('')
    w('## 全片统一要求')
    w('')
    w('- 风格：写实工业纪录片摄影，海工/船厂现场，白天自然光')
    w('- 画面里**不要出现文字、水印、logo、真实公司名**')
    w('- 人物统一戴安全帽、穿反光背心')
    w('- 同一条片子的图请保持色调一致（都偏冷灰工业感，或都偏暖日光）')
    w('- **人物解剖必须严谨**：每个人恰好两只手两条手臂，绝对不要出现第三只手、漂浮的手、重复肢体或缺失肢体等不合逻辑的图；生成后请先放大看一眼手和手臂再投喂。')
    w('')

    if meta.get('mode') == 'dialogue':
        ch = meta.get('characters', {})
        w('## 人物设定（对话片必须前后一致）')
        w('')
        w('| 角色 | 身份 | 形象要求 |')
        w('|---|---|---|')
        for k in ('A', 'B'):
            c = ch.get(k, {})
            role_en = c.get('role_en', '').split('/')[0].strip()
            role_zh = c.get('role_zh', '').split('/')[0].strip()
            w('| **%s** | %s / %s | %s |'
              % (k, role_en, role_zh,
                 c.get('look', '').split('):', 1)[-1].strip()))
        w('')
        w('> 两个人的**脸和衣服在每一镜都要一样**，不然观众会以为换人了。')
        w('> 如果你自己生图，建议先把 A、B 各出一张定妆照，再用同一张做参考图去生其余镜。')
        w('')

    w('## 逐镜清单')
    w('')
    w('| 镜 | 说话人 | 画面要什么 | 存成文件名 | 状态 |')
    w('|---|---|---|---|---|')
    for s in scenes:
        have = os.path.exists(os.path.join(img_dir, s['image_file']))
        spk = s.get('speaker_en', 'Narrator')
        if s.get('speaker') == 'A':
            spk = 'A · ' + spk
        elif s.get('speaker') == 'B':
            spk = 'B · ' + spk
        else:
            spk = '旁白'
        w('| %d | %s | %s | `%s` | %s |'
          % (s['idx'], spk,
             hint(s).replace('|', '/')[:70],
             s['image_file'], '✅ 已有' if have else '⬜ 待生成'))
    w('')
    w('## 英文提示词（可直接粘贴给任意生图工具）')
    w('')
    for s in scenes:
        have = os.path.exists(os.path.join(img_dir, s['image_file']))
        w('### 第 %d 镜　%s　%s' % (s['idx'], hint(s)[:50],
                                  '（已有图，可跳过）' if have else ''))
        w('')
        w('```text')
        w(s['image_prompt'])
        w('```')
        w('')

    out = a.out or os.path.join(proj, '图片清单.md')
    with open(out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(L))
    todo = sum(1 for s in scenes
               if not os.path.exists(os.path.join(img_dir, s['image_file'])))
    print('图片清单 -> %s' % out)
    print('共 %d 镜, 待生成 %d 张' % (len(scenes), todo))


if __name__ == '__main__':
    main()
