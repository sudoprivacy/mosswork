// 把 translate_needed.json 里填好的中文字幕合并回 scenes.json
//
// 用法:
//   node pipeline/apply_zh.js --project hse_lifting_stop
//   node pipeline/apply_zh.js --project X --from D:/某处/我的翻译.json
//
// 翻译文件格式: [{ "idx": 2, "en": "...", "zh": "这里填中文" }, ...]
// zh 留空的条目会被跳过并在最后列出。

const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');

const argv = process.argv.slice(2);
function opt(n, d) { const i = argv.indexOf('--' + n); return i >= 0 ? argv[i + 1] : d; }
const proj = opt('project');
if (!proj) { console.error('缺 --project'); process.exit(1); }

const projDir = path.join(ROOT, 'projects', proj);
const scenesPath = path.join(projDir, 'scenes.json');
const trPath = opt('from', path.join(projDir, 'translate_needed.json'));

if (!fs.existsSync(scenesPath)) { console.error('找不到 ' + scenesPath); process.exit(1); }
if (!fs.existsSync(trPath)) { console.log('没有待翻译文件, 跳过: ' + trPath); process.exit(0); }

const TTS_ZH = [
  [/≥/g, '不低于'], [/≤/g, '不超过'], [/＞|>/g, '大于'], [/＜|</g, '小于'],
  [/(\d)\s*×\s*\/\s*/g, '$1次每'], [/×/g, '乘'],
  [/℃/g, '摄氏度'], [/%/g, '％'], [/\//g, '、'], [/&/g, '和'], [/\+/g, '加'],
  [/[—–]{1,}/g, '，'], [/\s{2,}/g, ' '],
];
function toSpeechZh(s) {
  let t = s;
  for (const [re, rep] of TTS_ZH) t = t.replace(re, rep);
  return t.replace(/、{2,}/g, '、').replace(/，{2,}/g, '，').trim();
}

const data = JSON.parse(fs.readFileSync(scenesPath, 'utf8'));
const tr = JSON.parse(fs.readFileSync(trPath, 'utf8'));
const byIdx = new Map(data.scenes.map(s => [s.idx, s]));

let applied = 0;
const missing = [];
for (const t of tr) {
  const zh = (t.zh || '').trim();
  if (!zh) { missing.push(t.idx); continue; }
  const sc = byIdx.get(t.idx);
  if (!sc) { console.warn('scenes.json 里没有 idx=' + t.idx + ', 跳过'); continue; }
  sc.narration_zh = zh;
  sc.tts_zh = toSpeechZh(zh);
  applied += 1;
}

fs.writeFileSync(scenesPath, JSON.stringify(data, null, 2), 'utf8');
console.log(`已回填中文字幕 ${applied} 条 -> projects/${proj}/scenes.json`);
if (missing.length) {
  console.log(`仍缺 ${missing.length} 条(镜号 ${missing.join(', ')}), 请在 ${path.basename(trPath)} 里补 zh 字段`);
  process.exit(3);
}
