# -*- coding: utf-8 -*-
"""风格预设库（视觉方向储备）。
每个 Style 定义一套完整视觉参数：调色板 / 字体 / 卡片样式 / 背景类型 / 装饰 / 动画。
风格与模板正交——任意风格 × 任意应用模板 可组合。
新增风格 = 在 STYLES 里加一条配置，无需改渲染逻辑。
"""
from dataclasses import dataclass, field
from typing import Dict, List
import os

# ---------------- 字体文件映射 ----------------
FONT_FILES = {
    "msyh":   r"C:\Windows\Fonts\msyh.ttc",
    "msyhbd": r"C:\Windows\Fonts\msyhbd.ttc",
    "simhei": r"C:\Windows\Fonts\simhei.ttf",
    "simkai": r"C:\Windows\Fonts\simkai.ttf",
    "simsun": r"C:\Windows\Fonts\simsun.ttc",
    "simfang":r"C:\Windows\Fonts\simfang.ttf",
    "arial":  r"C:\Windows\Fonts\arial.ttf",
    "arialbd":r"C:\Windows\Fonts\arialbd.ttf",
}

_FONT_CACHE = {}


@dataclass
class Style:
    key: str
    name: str               # 中文名
    desc: str
    bg_type: str            # gradient|grid|ink|dots|scanline|photo|solid
    palette: Dict[str, tuple]
    fonts: Dict[str, str]   # cn, cn_b, en, en_b -> FONT_FILES key
    card_radius: int = 24
    card_alpha: int = 175
    border_alpha: int = 160
    line_width: int = 3
    appear_speed: float = 1.0   # >1 更快（更紧迫）
    transition: str = "crossfade"  # crossfade|zoom|slide
    decorations: List[str] = field(default_factory=list)
    default_bg: tuple = (12, 20, 40)

    def get_font(self, key, size):
        fk = self.fonts.get(key, "msyh")
        path = FONT_FILES.get(fk, FONT_FILES["msyh"])
        ck = (path, size)
        if ck in _FONT_CACHE:
            return _FONT_CACHE[ck]
        f = None
        if os.path.exists(path):
            try:
                f = __import__("PIL").ImageFont.truetype(path, size)
            except Exception:
                f = None
        if f is None:
            f = __import__("PIL").ImageFont.load_default()
        _FONT_CACHE[ck] = f
        return f

    # 便捷取色
    def c(self, name, default=(255, 255, 255)):
        return self.palette.get(name, default)


# ---------------- 6 个内置风格 ----------------
STYLES: Dict[str, Style] = {}

STYLES["business"] = Style(
    key="business", name="商务风",
    desc="沉稳、专业、克制。深蓝渐变 + 钢蓝强调，适合汇报/宣传/标准讲解。",
    bg_type="gradient",
    palette={
        "bg": (12, 20, 40), "bg2": (22, 34, 66), "panel": (18, 28, 54),
        "panel_border": (120, 150, 200), "text": (245, 248, 252), "text_dim": (160, 175, 200),
        "accent": (56, 140, 235), "accent2": (240, 180, 60), "line": (90, 120, 160),
        "shadow": (0, 0, 0, 175),
    },
    fonts={"cn": "msyh", "cn_b": "msyhbd", "en": "arial", "en_b": "arialbd"},
    card_radius=28, card_alpha=178, border_alpha=160, line_width=3,
    appear_speed=1.0, transition="crossfade",
    decorations=["soft_grid"], default_bg=(12, 20, 40),
)

STYLES["manga"] = Style(
    key="manga", name="漫画风",
    desc="明亮、夸张、分镜感。柔粉底 + 网点 + 粗黑描边，适合学生讲课/轻松科普。",
    bg_type="dots",
    palette={
        "bg": (255, 240, 236), "bg2": (255, 214, 226), "panel": (255, 255, 255),
        "panel_border": (28, 28, 38), "text": (25, 25, 35), "text_dim": (95, 95, 115),
        "accent": (255, 80, 120), "accent2": (60, 160, 255), "line": (28, 28, 38),
        "shadow": (0, 0, 0, 55),
    },
    fonts={"cn": "simhei", "cn_b": "simhei", "en": "arialbd", "en_b": "arialbd"},
    card_radius=16, card_alpha=235, border_alpha=255, line_width=5,
    appear_speed=1.35, transition="slide",
    decorations=["halftone", "bold_outline"], default_bg=(255, 240, 236),
)

STYLES["realistic"] = Style(
    key="realistic", name="写实风",
    desc="照片电影感。深色压暗 + 自然渐变，适合产品/人物/纪实类。",
    bg_type="photo",
    palette={
        "bg": (8, 12, 20), "bg2": (15, 22, 38), "panel": (15, 22, 40),
        "panel_border": (140, 180, 210), "text": (248, 250, 252), "text_dim": (180, 195, 215),
        "accent": (80, 200, 160), "accent2": (230, 200, 90), "line": (100, 130, 160),
        "shadow": (0, 0, 0, 205),
    },
    fonts={"cn": "msyh", "cn_b": "msyhbd", "en": "arial", "en_b": "arialbd"},
    card_radius=24, card_alpha=170, border_alpha=150, line_width=3,
    appear_speed=0.95, transition="crossfade",
    decorations=["vignette"], default_bg=(8, 12, 20),
)

STYLES["guofeng"] = Style(
    key="guofeng", name="国风",
    desc="水墨/宣纸/印章。米黄底 + 朱红 + 楷体，适合文化/传统/知识类。",
    bg_type="ink",
    palette={
        "bg": (238, 228, 205), "bg2": (214, 196, 166), "panel": (246, 239, 222),
        "panel_border": (170, 46, 46), "text": (40, 30, 25), "text_dim": (110, 88, 70),
        "accent": (180, 46, 46), "accent2": (190, 150, 60), "line": (120, 90, 60),
        "shadow": (60, 40, 30, 110),
    },
    fonts={"cn": "simkai", "cn_b": "simkai", "en": "arial", "en_b": "arialbd"},
    card_radius=8, card_alpha=210, border_alpha=220, line_width=3,
    appear_speed=0.9, transition="crossfade",
    decorations=["seal", "ink_splash", "vertical_accent"], default_bg=(238, 228, 205),
)

STYLES["mechanical"] = Style(
    key="mechanical", name="机械风",
    desc="重工业 HUD / 蓝图。深蓝网格 + 青色辉光 + 角标 + 警示条，适合标准/工程/工业。",
    bg_type="grid",
    palette={
        "bg": (10, 16, 30), "bg2": (14, 24, 46), "panel": (12, 22, 42),
        "panel_border": (60, 200, 230), "text": (220, 240, 250), "text_dim": (120, 160, 190),
        "accent": (56, 224, 235), "accent2": (250, 180, 40), "line": (40, 120, 160),
        "shadow": (0, 0, 0, 180),
    },
    fonts={"cn": "msyh", "cn_b": "msyhbd", "en": "arialbd", "en_b": "arialbd"},
    card_radius=4, card_alpha=165, border_alpha=200, line_width=2,
    appear_speed=1.15, transition="zoom",
    decorations=["grid", "scanlines", "corner_brackets", "warning_stripe"], default_bg=(10, 16, 30),
)

STYLES["punk"] = Style(
    key="punk", name="朋克风",
    desc="赛博朋克。暗紫底 + 品红/青霓虹 + 扫描线 + 故障感，适合潮酷/科技/年轻向。",
    bg_type="scanline",
    palette={
        "bg": (12, 6, 24), "bg2": (22, 8, 42), "panel": (20, 10, 38),
        "panel_border": (255, 40, 160), "text": (245, 240, 255), "text_dim": (185, 155, 215),
        "accent": (255, 40, 160), "accent2": (40, 230, 255), "line": (150, 40, 200),
        "shadow": (0, 0, 0, 205),
    },
    fonts={"cn": "simhei", "cn_b": "simhei", "en": "arialbd", "en_b": "arialbd"},
    card_radius=10, card_alpha=180, border_alpha=220, line_width=3,
    appear_speed=1.3, transition="zoom",
    decorations=["scanlines", "neon_glow", "glitch"], default_bg=(12, 6, 24),
)


def get_style(key):
    return STYLES.get(key, STYLES["business"])


def list_styles():
    return [(k, s.name, s.desc) for k, s in STYLES.items()]
