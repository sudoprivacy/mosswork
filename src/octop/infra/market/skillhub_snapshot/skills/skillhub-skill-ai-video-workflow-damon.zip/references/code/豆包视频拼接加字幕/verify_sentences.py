#!/usr/bin/env python3
# 竖屏逐句验证：抽帧确认逐句切换/间隙无字/不超两侧
import subprocess, os
from PIL import Image
import numpy as np

FF="C:/Users/Damon/.workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"
WK="D:/微信小程序/情景视频存放处/豆包视频加字幕工作流"
VID=os.path.join(WK,"hvac_07_竖屏字幕测试.mp4")
W,H=1080,1920
# 竖屏字幕带（底部，MarginV=30，字号40，两行）
BAND=(H-160, H-10)

tmp=os.path.join(WK,"_vchk"); os.makedirs(tmp,exist_ok=True)
samples=[1.5,3.5,5.5,7.5,12.0,33.5]
expect={1.5:"present",3.5:"present",5.5:"absent",7.5:"present",12.0:"present",33.5:"absent"}
for t in samples:
    subprocess.run([FF,"-ss",str(t),"-i",VID,"-frames:v","1","-y",os.path.join(tmp,f"v_{t}.png")],
                   stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
print(f"{'t(s)':>6} | {'字幕带白像素':>10} | {'x范围':>14} | {'判定':>6} | 预期")
allok=True
for t in samples:
    im=Image.open(os.path.join(tmp,f"v_{t}.png")).resize((W,H))
    a=np.asarray(im.convert('RGB')).astype(int)
    r,g,b=a[:,:,0],a[:,:,1],a[:,:,2]
    white=(r>200)&(g>200)&(b>200)
    band=white[BAND[0]:BAND[1],:]
    ys,xs=np.where(band)
    cnt=int(band.sum())
    if len(xs):
        xmin,xmax=xs.min(),xs.max()
        xr=f"[{xmin},{xmax}]"
        over = (xmin<40 or xmax>1040)
    else:
        xmin=xmax=None; xr="[]"; over=False
    got="present" if cnt>400 else "absent"
    ok = (got==expect[t]) and not over
    allok = allok and ok
    flag = "OK" if ok else ("OVERFLOW!" if over else "MISMATCH!")
    print(f"{t:>6} | {cnt:>10} | {xr:>14} | {got:>6} | {expect[t]:>6}  {flag}")
print("\n全部通过?" , "YES ✅" if allok else "NO ❌")
