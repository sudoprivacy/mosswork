# 生图提示词公式（ImageGen）

把分镜表的一行，翻译成 ImageGen 能稳定出图的提示词。结构固定，顺序固定。
**本文件里的 PPE / 匿名 / 重工业风格 / 宏大场景广角 约束段是红线强制项，不是建议。** 凡工业现场镜头，PPE_SUFFIX 必须复制追加到 prompt 末尾；**凡生成图必带 HEAVY_INDUSTRY_STYLE_SUFFIX**；**凡大型工业宏观场景必加 CINEMATIC_WIDE_ANGLE_SUFFIX**。漏一项即违规，成片前会被 `ppe_check.py` 拦截。

> 🚨 **全剧硬性机制（用户 2026-08-10 最终指令，每集必走、贯穿全漫剧）**：
> 1. **宏大广角建立镜头每集必含 ≥1 个**（大广角 + 大纵深 + 震撼 + 渺小人物 vs 宏大工业），否则成片检验线 `RL-WIDE-ANGLE` 直接 FAIL 拦截。
> 2. **开场（前 3 镜）必须有 1 个宏大广角钩子镜头**，一上来用大广角大纵深抓住观众（无则 WARN 敦促前移）。
> 3. **剧情需要时展示**：宏大广角场景只在"剧情写到大场面/到宏洋重工/到船坞/到龙门吊"时切入，不要无理由乱插；但凡写到这类场景，就必须用大广角呈现、给足震撼。
> 4. **人物融入宏大场景**：宏观镜头里若有人物，人物必须是**渺小剪影/孤独小人**被宏大工业结构压倒（tiny lone human figure dwarfed），绝不让人物"悬浮/突兀抢镜"；人物因剧情需要出现时才出现，且融入尺度对比。
> 详见第十节。

> 🎬 **风格基线（来自视频样板 G_CHUNG 风格）**：冷蓝电影感调色 + 钢铁混凝土质感 + 薄雾体积光 + 单一暖色点光 vs 冷蓝阴影 + 油渍锈迹 + 岁月沧桑 + 大国工匠/大国重工史诗尺度 + 渺小人物 vs 宏大工业对比。下面两个 SUFFIX 就是把这条基线机器化。

## 一、万能公式

```
[角色块(固定，见 character-design)]
+ [动作/姿态(具体，不写情绪)]
+ [环境/场景(具体地点+时间+内外)]
+ [镜头语言: 景别 + 机位/角度 + 运镜]
+ [光影]
+ [风格/画质：重工业电影感(必带，模板见第五节 HEAVY_INDUSTRY_STYLE_SUFFIX)]
+ [宏大场景大广角(仅宏观场景加，模板见第五节 CINEMATIC_WIDE_ANGLE_SUFFIX)]
+ [约束(稳定/无变)]
+ [PPE 强制约束段 · 凡工业现场必追加]   ← 第五节 PPE_SUFFIX，不可省略
+ [匿名约束段 · 船海风云必追加]         ← 第五节 ANON_SUFFIX，不可省略
```

## 二、各段写法要点

- **角色块**：原样复制角色卡段落，放最前。
- **动作/姿态**：写具体肢体动作 + 表情肌（`右手握拳从腰间缓缓抬起`、`低头，眉头微皱`），不写「愤怒」「悲伤」。
- **环境**：具体场景 + 时间 + 内外（`船体车间夜，冷白顶灯，钢板堆叠背景`）。
- **镜头语言**：常规 `中景, 平视, 固定镜头` / `近景, 慢推` / `过肩镜头, 从B肩后拍A`；**宏观场景必须升档为 `极端超广角, 大纵深, 大片感, 震撼, 渺小人物 vs 宏大工业结构`（见 CINEMATIC_WIDE_ANGLE_SUFFIX）**。
- **光影**：常规 `工业冷光` / `暖色窗光` / `侧光勾轮廓` / `平光`；**重工业场景级光影统一为 `冷蓝主调 + 单一远处暖色点光 vs 冷蓝阴影 + 体积光薄雾`（场景级光影，对应 HEAVY_INDUSTRY_STYLE_SUFFIX）**。
- **风格/画质（必带重工业）**：每图同一套重工业电影感（`冷蓝电影感调色, 钢铁混凝土质感, 薄雾体积光, 油渍锈迹, 岁月沧桑, 大国工匠大国重工史诗尺度, 电影级色彩科学, HDR 高动态, 4K 电影质感, 细微胶片颗粒`）—— 详见 HEAVY_INDUSTRY_STYLE_SUFFIX。**禁止退化为明亮/清新/暖色默认。**
- **约束（必写，防翻车）**：`画面稳定无抖动, 无模糊无重影, 人体结构正常, 面部清晰不变形, 同一角色服装一致发型不变`。
- **PPE 约束段（凡工业现场必追加）**：见第五节 PPE_SUFFIX，复制追加，不可省略。
- **匿名约束段（船海风云必追加）**：见第五节 ANON_SUFFIX，复制追加，不可省略。
- **重工业风格约束段（每图必追加）**：见第五节 HEAVY_INDUSTRY_STYLE_SUFFIX，复制追加，不可省略。
- **宏大场景大广角约束段（仅宏观场景追加）**：见第五节 CINEMATIC_WIDE_ANGLE_SUFFIX，复制追加，不可省略。

## 三、竖屏 vs 横屏

- 分镜图默认**横屏 16:9**（电影感、便于看构图）。
- 若用户要做竖屏短剧成片，改 **9:16**，提示词加「竖屏构图，人物居中，留好上下空间，避免头顶/脚被裁」。

## 四、示例（船海风云 · 工程师在中船坞 · 已含 PPE + 重工业 + 宏观场景广角）

```
deep-sea engineering technician, 35, oval face, narrow eyes, short crew cut,
sturdy build, wearing dark blue coverall with reflective stripe and white helmet,
silver whistle on lanyard,
transparent colorless safety glasses (protective eyewear, clear lens, visible frame, NOT tinted),
cut-resistant work gloves on hands.
He crouches beside a steel plate, running a probe along a weld seam, frowning slightly.
Giant shipbuilding drydock, night, colossal gantry crane overhead, towering steel hull side,
stacked steel plates in background, atmospheric haze.
Medium shot, eye level, fixed camera.
Industrial cold lighting, cinematic.
4K, highly detailed, natural color, stable frame no blur no ghosting,
correct human anatomy, face clearly defined, same character consistent costume.
Industrial heavy-industry cinematic aesthetic: moody cool blue color grading,
weathered steel and concrete textures, atmospheric haze and mist, volumetric industrial lighting,
a single warm accent light source contrasting cold blue shadows, oil-stained machinery,
rust patina, epic time-worn grandeur and national heavy-industry pride (大国工匠 / 大国重工),
cinematic film-grade color science, high dynamic range, 4K cinematic, subtle film grain.
Extreme ultra-wide establishing shot, massive depth of field, towering vertical industrial
structures (gantry cranes / ship hulls / drydock walls / steel factory buildings / colossal modules),
strong leading lines and convergent perspective with dramatic vanishing point,
a tiny lone human figure dwarfed by colossal industrial scale, fog and atmospheric haze for depth,
cold steel-blue palette with a single distant warm light source, monumental composition,
blockbuster cinematic frame, awe-inspiring sense of scale (中国重工震撼).
All on-site personnel wear hard hat (GB 2811) and transparent colorless safety glasses
(protective eyewear, clear lens, visible frame, GB 14866, NOT tinted/dark sunglasses/welding mask);
if hands visible wear cut-resistant work gloves, or tuck gloves in pocket / clip with a glove clip;
if feet visible wear steel-toe safety shoes (GB 21148).
No real person names, nationalities, or real company names; characters use functional labels
with visual identity only.
```

> 注意：示例里就已经写齐 `white helmet` + `transparent colorless safety glasses` + `cut-resistant work gloves` + 重工业风格 SUFFIX + 宏观场景广角 SUFFIX + 匿名 SUFFIX。**照模板生成的每一张现场图都必须带这些**，否则就是违规。

## 五、强制约束段模板（复制追加，红线）

### HEAVY_INDUSTRY_STYLE_SUFFIX（船海风云·每图必追加·覆盖场景与角色）
- **工业风 + 沧桑感 + 重工业氛围 + 大国重工风格** —— 覆盖每一张生成图（场景关键帧 + 角色参考形象）。
- 冷蓝电影感调色 + 工业钢铁/混凝土质感 + 薄雾/水汽 + 体积光 + 单一暖色点光 vs 冷蓝阴影 + 油渍锈迹 + 岁月打磨的宏伟感 + 大国工匠 / 大国重工的史诗尺度 + 电影级色彩科学 + HDR 高动态 + 4K 电影质感 + 细微胶片颗粒。

英文追加句（贴 prompt 末尾）：
> Industrial heavy-industry cinematic aesthetic: moody cool blue color grading, weathered steel and concrete textures, atmospheric haze and mist, volumetric industrial lighting, a single warm accent light source contrasting cold blue shadows, oil-stained machinery, rust patina, epic time-worn grandeur and national heavy-industry pride (大国工匠 / 大国重工), cinematic film-grade color science, high dynamic range, 4K cinematic, subtle film grain.

中文追加句：
> 工业风重工业电影感：冷蓝电影感调色 + 钢铁混凝土质感 + 薄雾体积光 + 单一暖色点光 vs 冷蓝阴影 + 油渍锈迹 + 岁月沧桑 + 大国工匠大国重工史诗尺度 + 电影级色彩科学 + HDR 高动态 + 4K 电影质感 + 细微胶片颗粒。

### CINEMATIC_WIDE_ANGLE_SUFFIX（仅宏观场景追加）
**触发条件（满足任一即追加）**：龙门吊 / 巨型龙门吊车 / 大型船坞 / 万吨级船坞 / 大型船体模块 / 巨型分段合龙 / 巨型厂房 / 钢塔 / 烟囱群 / 巨型船舶 / 重型运输设备 / 海岸大型船坞全景 / 铁矿石堆场 / 焊花飞溅全景 / 任何"非常庞大"的设备/船舶/建筑/分段。

- 极端超广角建立镜头 + 大纵深深景 + 大片感 + 震撼；渺小人物 vs 宏大工业结构对比；强引导线 + 汇聚透视 + 戏剧性消失点；薄雾纵深；冷钢蓝主调 + 单一远处暖光；纪念碑式构图 + 工业大片影视级。

英文追加句（贴 prompt 末尾）：
> Extreme ultra-wide establishing shot, massive depth of field, towering vertical industrial structures (gantry cranes / ship hulls / drydock walls / steel factory buildings / colossal modules), strong leading lines and convergent perspective with dramatic vanishing point, a tiny lone human figure dwarfed by colossal industrial scale, fog and atmospheric haze for depth, cold steel-blue palette with a single distant warm light source, monumental composition, blockbuster cinematic frame, awe-inspiring sense of scale (中国重工震撼).

中文追加句：
> 极端超广角建立镜头，大纵深深景，龙门吊 / 巨型船体 / 船坞 / 厂房 / 巨型模块等高耸工业结构，强引导线汇聚透视与戏剧性消失点，渺小孤独人物被宏大工业尺度压倒，薄雾纵深，冷钢蓝主调配单一远处暖光，纪念碑式构图，工业大片影视级框架，中国重工震撼。

### PPE_SUFFIX（凡工业现场：船厂/船坞/码头/平台/车间/项目部外/作业区 —— 必追加）

- 全员佩戴**安全帽**（GB 2811）；
- 全员佩戴**透明无色镜片劳保眼镜**（安全眼镜，镜片无色透明、可见镜框，GB 14866）；**禁止画成深色墨镜/焊接面罩/遮光护目镜，必须能透过镜片看到眼神**；
- 手部入镜 → 戴**劳保手套**（防切割/防化）；若动作不便未戴，须将劳保手套放入裤兜或用手套夹（一端夹手套、另一端夹裤兜）明确"带着手套"；
- 脚部入镜 → 穿**劳保鞋**（安全鞋，防砸防刺穿，GB 21148）；
- 即便路过/站立/对话，人在现场即全套 PPE 在身（手套可夹兜但在场）。
- **豁免**（以下场景不强制 PPE，须在 `分镜说明.md` 标注对应标签）：纯室内办公室 / 明确非工业环境 / 非现场闪回 / **入场安全培训·班前会等培训 briefing（标「培训」）** / **下班离场（标「下班」）** / **新人报到尚未领装备的剧情前置（标「新人报到前置」，仅陈砺报到段，非违规）**。标注后 `ppe_check.py` 对该镜头跳过 PPE 检查。

中文追加句（贴 prompt 末尾）：
> 现场所有人戴安全帽与透明无色劳保眼镜（镜片透明可见镜框，非墨镜/面罩）；手部入镜戴防切割劳保手套，不便戴则手套放裤兜或用手套夹夹住；脚部入镜穿防砸劳保鞋。

英文追加句（贴 prompt 末尾）：
> All on-site personnel wear hard hat (GB 2811) and transparent colorless safety glasses (protective eyewear, clear lens, visible frame, GB 14866, NOT tinted/dark sunglasses/welding mask); if hands visible wear cut-resistant work gloves, or tuck gloves in pocket / clip with a glove clip; if feet visible wear steel-toe safety shoes (GB 21148).

### ANON_SUFFIX（船海风云必追加）
- 无真实姓名/国籍/真实企业；角色用职能标签 + 视觉身份（制服色+体型+特征），不得出现可识别真实第三方。

英文追加句：`No real person names, nationalities, or real company names; characters use functional labels with visual identity only.`

### CHAR_FACE_SUFFIX（角色参考形象图 / 人物卡 专用，凡出现正脸/半身像必追加）
- **五官零瑕疵**：脸干净，无熊猫眼/黑眼圈/眼周深色阴影/脸脏/鼻歪/嘴角撕裂/脸部色斑/左右眼明显不对称。
- **眼神清透**：双眼自然有神，瞳孔与眼白对比正常。
- **杂物严丝合缝**：手持物品必须与角色职能强相关（检验员可拿卷尺/万用表、HSE 可拿对讲机/培训材料、焊工可拿焊枪、车间经理可拿水杯/文件），与角色定位无关的杂物（手电筒/笔/算盘/工具箱/不明物等）一律不放。
- **口袋干净**：胸前口袋/裤兜不插笔/不揣工具，与角色定位无关。
- **双手空原则**：除上述"职能强相关手持"外，默认双手自然下垂或背后。

英文追加句：
> Clean flawless face: no panda eye, no dark circles, no shadows or bruises around the eyes, no asymmetry, no crooked nose. Natural clear eyes. No objects in hands except role-relevant tools (measuring tape / multimeter / walkie-talkie / welding torch / cup / clipboard). Chest pockets and pants pockets empty, no pens clipped. Both hands empty at sides by default.

中文追加句：
> 干净无瑕的脸：无熊猫眼/黑眼圈/眼周阴影/瘀伤/不对称/歪鼻；双眼自然有神；口袋干净不插笔不揣工具；手持物品仅限与角色职能强相关（卷尺/万用表/对讲机/焊枪/水杯/文件夹），其余杂物一律不放；双手默认自然下垂。

> 反向触发：用户从成片中反馈脸脏/杂物不当 → 必须用图生图修复（保人物识别度，prompt 显式否定瑕疵项；input_fidelity 0.7 加大改动幅度），重渲引用该卡的成片场景，不得带瑕疵图继续出后续集。

## 六、PPE 核验关卡（强制，生成后必须过，未过不得进入成片）

每张现场分镜图生成后，**必须**执行：
1. 用 Read 工具目视打开生成的图片；
2. **逐人核查**：安全帽 ✓ / 透明劳保眼镜 ✓（镜片无色透明、可见镜框、能透见眼神）/ 手套或手套夹兜 ✓ / 劳保鞋 ✓；
3. 若任一人在场但缺项 → **必须重生成**（图生图保长相构图，prompt 强化缺失项 + 显式否定深色墨镜/面罩变体；必要时把 `input_fidelity` 降到 0.7 让眼镜更明显）；
4. 只有全部现场人物 PPE 合规，才写入 `分镜说明.md` 并交付下游成片。
5. **自动拦截**：成片前必须运行 `python ppe_check.py <分镜说明.md>`，任一现场镜头 FAIL 则阻断，不得带违规图进成片。

- 这是硬性关卡，禁止「先交付再补」；宁可重生成也不带违规图进成片。

## 七、宏观场景判定速查表（决定是否加 CINEMATIC_WIDE_ANGLE_SUFFIX）

| 场景关键词 | 是否宏观 | 加 CINEMATIC_WIDE_ANGLE_SUFFIX |
|---|---|---|
| 龙门吊 / 龙门吊车 / 巨型起重机 | ✅ | 加 |
| 大型船坞 / 万吨级船坞 | ✅ | 加 |
| 大型船体模块 / 巨型分段合龙 | ✅ | 加 |
| 巨型厂房 / 钢塔 / 烟囱群 | ✅ | 加 |
| 巨型船舶 / 重型运输设备 | ✅ | 加 |
| 海岸大型船坞全景 / 铁矿石堆场 | ✅ | 加 |
| 焊花飞溅全景 / 万吨水压机 | ✅ | 加 |
| 码头 / 跳板 / 培训教室 / 办公室 / 车间走廊 / 安教角 | ❌ | 不加（但仍需 HEAVY_INDUSTRY_STYLE_SUFFIX） |

> **判别口诀**："非常庞大 / 宏大 / 震撼 / 大国重工" → 触发；普通工业场景（码头/走廊/办公室）→ 不触发，但风格后缀仍必带。

## 八、常见翻车与排查

| 现象 | 排查 |
|---|---|
| 每段脸不一样 | 是否每段都用了同一角色块+参考图+一致句；是否锁了 seed |
| 画风/色调段间跳 | 是否每段带同一套风格词+画质词 |
| 动作/情绪接不上 | 分镜动作交叠是否写清；上段结尾与本段开头是否连贯 |
| 对白与口型对不上 | 分镜图阶段不要求口型；后期配音+字幕即可 |
| 竖屏构图怪 | 提示词是否写清景别与构图（人物居中、上半身、留白） |
| 生成不满意 | 90% 是描述不够具体；换 seed 重跑；微调而非重写 |
| **劳保眼镜被画成深色墨镜/焊接面罩/遮光护目镜** | prompt 必须显式否定深色/烟熏/遮光变体，强调「镜片完全透明无色、能透过看到眼神」，并把 `input_fidelity` 降到 0.7 让眼镜更明显；重生成 |
| **现场有人没戴安全帽/手套/鞋** | 必是 prompt 漏了 PPE_SUFFIX；重生成时把 PPE 写进角色块与约束，不要只靠结尾一句 |
| **ppe_check.py 报 FAIL** | 现场镜头 prompt / 分镜说明缺 PPE 关键词；补齐 PPE 重生成并通过拦截器后再成片 |
| **角色卡人物出现熊猫眼/黑眼圈/脸脏/鼻歪/嘴角撕裂等五官瑕疵** | prompt 未加 CHAR_FACE_SUFFIX，或 input_fidelity 过高把瑕疵锁死；用图生图重生成（input_fidelity=0.7，prompt 加 CHAR_FACE_SUFFIX 显式否定瑕疵项）；修复后必须重渲引用该卡的成片场景 |
| **角色卡人物手持与角色定位无关的杂物（手电筒/笔/算盘等）** | prompt 未加 CHAR_FACE_SUFFIX；同上用图生图修复 + 显式列明"双手空、口袋净、only role-relevant tools"；修复后必须重渲引用该卡的成片场景 |
| **画面偏明亮/清新/暖色，缺乏重工业沧桑感与大国重工气质** | prompt 未带 HEAVY_INDUSTRY_STYLE_SUFFIX，或被默认风格词覆盖；重生成并在 prompt 末尾强制追加该 SUFFIX，确保覆盖默认；2K 级以上模型务必显式写 HDR / 4K 电影质感 |
| **宏观场景（龙门吊/船坞/巨型模块）未呈现大广角大纵深震撼感** | prompt 未判定为宏观场景或漏加 CINEMATIC_WIDE_ANGLE_SUFFIX；按第七节速查表判定后追加，并显式写"渺小人物 vs 宏大工业结构" |
| **角色参考形象脸变 / 与旧版不像同一人** | 角色再生时 input_fidelity 过高锁死旧瑕疵，过低则丢脸；用旧版参考图 + input_fidelity=0.6 + prompt 加 CHAR_FACE_SUFFIX + HEAVY_INDUSTRY_STYLE_SUFFIX；图生图保留人物识别度 |
| **旁白说正午、画面却是深夜（时段错配）** | prompt 未锁定时段、生图默认偏暗；白昼镜显式写「正午烈日、明亮天光、柏油路面热浪蒸腾、无任何夜色」，并否定 night / dark / night scene；重生成后对照旁白时段核验（RL-13 自动拦截） |
| **新人报到镜主角戴了安全帽 / 劳保眼镜 / 手套（零PPE 违规）** | 豁免镜角色块带了 PPE 或漏写零PPE；豁免镜角色块去掉所有 PPE，显式写「休闲便装、无安全帽无劳保眼镜无手套」，否定 hard hat / safety glasses / gloves；重生成（RL-14 自动拦截） |
| **培训镜背景画成车间 / 管道 / 起重机（培训室≠车间）** | prompt 未定死培训室背景；显式写「室内安全培训角、白墙、宣讲板、桌椅、墙面红色 STOP WORK 标语，无车间无管道无起重机」，否定 workshop / pipe / crane；重生成（RL-15 自动拦截） |
| **画面中有漂浮 / 幽灵物体（鞋 / 衣 / 工具悬空）** | 生图随机幻觉；prompt 显式写「无漂浮物、所有物体落地或有明确支撑、无悬空无幽灵物体」，否定 floating / hovering / ghost；重生成 |

## 九、风格验收硬标准（每张生成图必须过的视觉自检）

> **生成完每张图立即用 Read 目视打开，按本表逐项核验，任一 ❌ 即重生成**：

1. **色调**：主调冷蓝，**禁**纯白/纯亮/纯暖黄/纯绿 —— ❌ 重生成。
2. **质感**：可见钢铁锈迹 / 混凝土风化 / 油渍 / 旧漆磨损 → 无沧桑感即 ❌。
3. **光影**：冷蓝阴影主导 + 单一暖色点光（焊花/远处窗/信号灯）→ 全平光即 ❌。
4. **氛围**：有薄雾/水汽/烟尘纵深 → 空气通透无雾即 ❌（除非特写特写人能占 60% 以上）。
5. **宏观场景（已加 CINEMATIC_WIDE_ANGLE_SUFFIX 的）**：画面有强烈引导线 / 汇聚透视 / 戏剧性消失点 / 渺小人物 vs 巨大结构 → 无震撼感即 ❌。
6. **角色参考形象**：五官净、口袋净、双手空或仅持角色职能相关工具 → 任意瑕疵即 ❌。
7. **PPE（现场镜头）**：全员白帽 + 透明无色劳保眼镜 + 手套或手套夹兜 + 钢头鞋 → 缺项即 ❌（已标豁免的镜跳过）。
8. **时段匹配（对应 RL-13）**：旁白明确时段（如「正午四十度」）→ 画面时段必须一致：白昼描写=明亮天光/烈日/热浪蒸腾，夜景描写=暗蓝夜色/灯光。**白昼描写绝不配夜景图，反之亦然** → 不一致即 ❌ 重生成。生图默认易偏暗，白昼镜 prompt 必须显式写「正午烈日、明亮天光、柏油路面热浪蒸腾、无任何夜色」，并否定 night/dark。
9. **零PPE 豁免场景（对应 RL-14）**：已标「新人报到前置 / 零PPE / 休闲」的镜，主角（新人）必为**休闲便装、零 PPE**（无安全帽、无劳保眼镜、无手套）；劳保鞋可正穿（喜剧焦点，正在套鞋）。**绝不可让新人第一天报到就全副武装** → 违规即 ❌ 重生成。豁免镜角色块需去掉 PPE 描述并显式写「休闲便装、无安全帽无劳保眼镜无手套」，同时否定 hard hat / safety glasses / gloves 词。
10. **培训室 ≠ 车间（对应 RL-15）**：标「培训 / 安全角」的镜，背景必须是**室内安全培训角 / 培训室**（白墙、宣讲板、桌椅、墙面安全标语如 STOP WORK AUTHORITY），**绝不可出现车间 / 管道 / 起重机 / 龙门吊 / 船坞 / 码头等露天或工业作业背景** → 错配即 ❌ 重生成。生图易把"培训"默认画成车间，必须显式写「室内安全培训角、白墙、宣讲板、桌椅、墙面红色 STOP WORK 标语，无车间无管道无起重机」，并否定 workshop / pipe / crane 词。
11. **无漂浮 / 幽灵物体（对应镜头04 飘鞋事故）**：画面中**不得出现悬空、漂浮、无支撑的衣物 / 鞋 / 工具等"闹鬼"物体**；所有物体必须落地或有明确支撑 → 出现即 ❌ 重生成。生图随机幻觉高发，prompt 必须显式写「无漂浮物、所有物体落地或有明确支撑、无悬空无幽灵物体」，并否定 floating / hovering / ghost。

## 十、全剧硬性机制：宏大广角建立镜头 + 人物融入 + 每集强制（用户 2026-08-10 最终指令）

> 这不是建议，是贯穿全漫剧每一集的强制机制。生图与成片都必须遵守，检验线 `RL-WIDE-ANGLE` 自动拦截不合规的集。

### 10.1 每集必含 ≥1 个宏大广角建立镜头
- 触发 CINEMATIC_WIDE_ANGLE_SUFFIX 的宏观场景（龙门吊 / 船坞 / 巨型船体 / 巨型模块 / 巨厂 / 鸟瞰等），**每一集都必须至少有 1 个**作为建立镜头或大场面。
- 背景图文件名须含宏观关键词（鸟瞰 / 广角 / 全景 / 船坞 / 龙门吊 / 巨 / 宏 / 震撼 / 建立镜头 / 史诗），或在 narration 的 scene 里显式写 `"macro": true`，便于检验线识别。

### 10.2 开场钩子（前 3 镜必须有 1 个宏大广角）
- 第一集更要"炸"：开场第一镜或前两镜就用**极端超广角大纵深的宏洋重工全景 / 大船坞 / 龙门吊群**抓住观众，给"大国重工震撼"的第一印象。
- 不要以平淡的近景对话开场。先给大场面钩子，再切到人物。

### 10.3 剧情需要时展示（不要乱插，但写到就必须给震撼）
- 宏大广角场景只在"剧情推进到大场面"时切入：主角初到宏洋重工遥望厂区、走到大船坞、仰望龙门吊、进入巨厂车间、船体合龙等。
- 凡剧本写到这些点，**必须用大广角大纵深呈现，绝不退化为平淡中景**。能多用几个宏大场景就用几个，让观众持续被尺度震撼。

### 10.4 人物融入宏大场景（人物绝不悬浮抢镜）
- 宏观镜头里若有人物，人物一律处理为 **tiny lone human figure dwarfed by colossal industrial scale（渺小孤独小人被宏大工业压倒）**：人物站位靠下、占比极小、与巨大结构形成尺度对比。
- 人物是"因剧情需要才出现"——例如主角提着纸箱站在轮渡甲板遥望远岸巨厂、或渺小身影走在巨型船体车间长卷里。人物融入尺度，不抢镜、不悬浮。
- 即便人物入镜，CINEMATIC_WIDE_ANGLE_SUFFIX 的"渺小人物 vs 宏大工业"描述词必须保留，PPE 仍按现场要求（除非该镜已标豁免）。

### 10.5 命名与标记约定（供检验线 RL-WIDE-ANGLE 识别）
- 宏大广角背景图文件名示例：`EPxx_镜头xx_宏洋重工鸟瞰.png`、`EPxx_镜头xx_大船坞广角.png`、`EPxx_镜头xx_龙门吊全景.png`。
- 或在 narration.json 该 scene 加 `"macro": true`（即使文件名未含关键词也能被识别）。

