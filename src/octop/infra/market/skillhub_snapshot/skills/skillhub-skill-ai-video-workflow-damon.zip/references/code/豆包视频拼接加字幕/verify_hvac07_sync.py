#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""验证 hvac_07_fixed.ass 的字幕窗与真实说话段完全对齐。"""
import json, re

REGIONS = json.load(open("hvac_07_regions.json", encoding="utf-8"))  # (start,end) 秒

def ts(t):
    h, m, s = t.split(":")
    return int(h) * 3600 + int(m) * 60 + float(s)

subs = []
for line in open("hvac_07_fixed.ass", encoding="utf-8"):
    m = re.match(r"Dialogue: 0,(\d+:\d+:\d+\.\d+),(\d+:\d+:\d+\.\d+),.*?,,(.*)", line)
    if m:
        subs.append((ts(m.group(1)), ts(m.group(2)), m.group(3)))

print("字幕条数:", len(subs), " 说话段数:", len(REGIONS))

# 检查1：每条字幕窗必须落在某个说话段内（字幕期间有说话）
bad1 = 0
for i, (s, e, txt) in enumerate(subs, 1):
    covered = any(not (e <= rs or s >= re) for rs, re in REGIONS)
    if not covered:
        bad1 += 1
        print("  [警告] 字幕%d 落在静音段: %.2f-%.2f %s" % (i, s, e, txt[:30]))

# 检查2：每段说话都必须被某条字幕覆盖（说话必有字幕）
bad2 = 0
for i, (rs, re) in enumerate(REGIONS, 1):
    covered = any(not (re <= s or rs >= e) for s, e, _ in subs)
    if not covered:
        bad2 += 1
        print("  [警告] 说话段%d 无字幕: %.2f-%.2f" % (i, rs, re))

# 检查3：字幕是否覆盖到视频结尾（之前只到32.93s的bug）
last_sub_end = max(e for _, e, _ in subs)
print("字幕覆盖到: %.2fs / 65s" % last_sub_end)

print("\n=== 结果 ===")
print("字幕落在静音段的条数:", bad1)
print("说话段无字幕的段数:", bad2)
print("全片覆盖:", "是 ✅" if last_sub_end > 60 else "否 ❌")
if bad1 == 0 and bad2 == 0 and last_sub_end > 60:
    print("判定: 字幕与发音完全同步 ✅")
else:
    print("判定: 仍存在不同步 ❌")
