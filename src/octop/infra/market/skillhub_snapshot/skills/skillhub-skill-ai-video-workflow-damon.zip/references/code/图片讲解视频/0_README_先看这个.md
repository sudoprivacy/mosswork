# 图片讲解视频 — 先看这个

> ⚠️ **动手前先看**：[避坑总纲](../1_避坑总纲_血泪清单.md)（历史翻车 + 硬闸门）
> ✅ **交付前必跑**：`python ../check.py <成片.mp4>` ｜ 勾选表：[交付前自检清单](../2_交付前自检清单.md)

> 把标准/规范里的**图**（如 AWS D1.1 Figure 6.16 焊工资格试板）讲成竖屏分镜讲解视频。
> 0 积分（除生图环节外）、纯本地 CPU。

## 一句话用法

```bash
# 1. 准备 brief（包含图 + 每点要讲什么 + 字幕/旁白）
#    参考 examples/brief.json 或 standard-figure-video-workflow skill 里的模板

# 2. 渲染
python main.py --brief ./brief.json
```

成片默认输出到 `D:\微信小程序\标准视频库\`。

## 工作区结构

```
图片讲解视频/
├── main.py                  # 主入口
├── framework/               # 渲染引擎（PIL+ffmpeg 视频合成）
│   ├── audio.py             # edge-tts 配音
│   ├── content.py           # brief→scenes
│   ├── engine.py            # 帧合成主循环
│   ├── layouts.py           # 9 种版式（cover/steps/split/data/timeline/glass/...）
│   ├── canvas.py            # 像素层
│   ├── styles.py            # 6 种风格（business/manga/realistic/...）
│   ├── templates.py         # 4 类模板
│   ├── validator.py         # 硬审核三道闸
│   ├── photo.py             # 照片自适应
│   ├── registry.py
│   └── backgrounds.py
├── check_env.py             # 依赖检查
├── requirements.txt
├── install.bat / install.sh # 子目录自带环境检查
└── docs/                    # 红线/规范
```

## 核心特性

- **54 组合**：9 版式 × 6 风格 程序化出图
- **硬审核**：文字超屏/压字/裁剪 → 直接报错
- **字幕**：中上英下双语，无英文时留空
- **多音色轮询**：Yunjian / Xiaoxiao / Yunxi / Xiaoyi
- **photo 自适应**：0/1/2 张照片都能排

## 已知坑

- TTS 缓存按场景序号命名，不是按文案 — 改文案后删 `framework/audio_cache/`
- ffmpeg concat 中文路径乱码 — 框架已用 ASCII 临时目录处理
- 不要在 `brief.json` 里塞未在 `validator` 注册的版式/风格/模板 — 直接报错

## 客户交付检查

跑 `python main.py --brief ./brief.json` 出片前，确认：
- [ ] brief.json 走完三道审核（`engine.py:validate(strict=True)`）
- [ ] 成片秒数与逐段 TTS 之和误差 < 0.1s
- [ ] 字幕中英对齐，无错位
- [ ] 无黑场闪烁（抽 1/2 fps 帧探针验）
