# -*- coding: utf-8 -*-
# LANDSCAPE (16:9, 1920x1080) PPT-style walkthrough for ASME B31.3-2020 Table 341.3.2
# ENGLISH voice-over + BILINGUAL (EN-over-CN) on-screen content & subtitles.
# Framework copied from the proven AWS D1.1 Table 6.10 production script.
import os, json, math, subprocess, textwrap, shutil, re
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
import fitz

# -----------------------------------------------------------------------------
W, H = 1920, 1080
FPS = 30

ROOT = r"D:\Workbuddy缓存位置\Fig341.3.2视频工作流"
OUT_DIR = os.path.join(ROOT, "output")
SRC_DIR = os.path.join(ROOT, "source")
CACHE_DIR = os.path.join(ROOT, "render", "audio_cache_en")
FRAMES_DIR = os.path.join(ROOT, "render", "frames_land_b31_341_3_2")
FFMPEG = r"C:\Users\Damon\AppData\Local\Programs\Python\Python312\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe"

os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(FRAMES_DIR, exist_ok=True)

# -----------------------------------------------------------------------------
BG = (5, 5, 16)
CYAN = (0, 212, 255)
CYAN_D = (0, 140, 180)
GOLD = (255, 193, 7)
GOLD_D = (200, 145, 0)
RED = (255, 82, 82)
WHITE = (255, 255, 255)
LIGHT = (210, 225, 245)
DIM = (130, 145, 170)
CARD_BG = (10, 14, 34, 240)

# -----------------------------------------------------------------------------
_FONT_CACHE = {}

def get_font(name, size):
    key = (name, size)
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]
    candidates = {
        "cn": [r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\simhei.ttf"],
        "cn_b": [r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\msyh.ttc"],
        "en": [r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\msyh.ttc"],
        "en_b": [r"C:\Windows\Fonts\arialbd.ttf", r"C:\Windows\Fonts\msyhbd.ttc"],
    }
    for p in candidates.get(name, candidates["cn"]):
        if os.path.exists(p):
            try:
                f = ImageFont.truetype(p, size)
                _FONT_CACHE[key] = f
                return f
            except Exception:
                pass
    return ImageFont.load_default()

# -----------------------------------------------------------------------------
def ease_out_cubic(t):
    return 1 - pow(1 - t, 3)

def ease_out_back(t):
    c1, c3 = 1.70158, 2.70158
    return 1 + c3 * pow(t - 1, 3) + c1 * pow(t - 1, 2)

def clamp(v, a, b):
    return max(a, min(b, v))

# -----------------------------------------------------------------------------
TABLE_BASE = None
ROW_BBOX = None
LABEL_CELL = None
TABLE_FRAME = None
IMG_W = IMG_H = 0

def load_assets():
    global TABLE_BASE, ROW_BBOX, LABEL_CELL, TABLE_FRAME, IMG_W, IMG_H
    base_path = os.path.join(SRC_DIR, "table341_3_2_base.png")
    json_path = os.path.join(SRC_DIR, "table341_3_2.json")
    TABLE_BASE = Image.open(base_path).convert("RGBA")
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    ROW_BBOX = data["row_bbox"]
    LABEL_CELL = data["label_cell"]
    TABLE_FRAME = data["table_frame"]
    IMG_W, IMG_H = data["img_size"]

# -----------------------------------------------------------------------------
_BG = None
# Shipyard / welding-site background photo (mirrors the WorkBuddy shipyard-HUD skin).
BG_PHOTO = r"D:\微信小程序\船海风云\人物角色示例图\焊接现场PPE检查Q版情景视频提示词.png"

def _cover_resize(im, tw, th):
    iw, ih = im.size
    scale = max(tw / iw, th / ih) * 1.03  # tiny overscan like CSS scale(1.02)
    nw, nh = int(iw * scale), int(ih * scale)
    im = im.resize((nw, nh), Image.LANCZOS)
    x0 = (nw - tw) // 2
    y0 = (nh - th) // 2
    return im.crop((x0, y0, x0 + tw, y0 + th))

def _vgrad(color, top_a, mid_a, bot_a, mid_f=0.4):
    """Vertical gradient overlay (alpha 0..1) — approximates CSS linear-gradient."""
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    for y in range(H):
        f = y / H
        if f < mid_f:
            a = top_a + (mid_a - top_a) * (f / mid_f)
        else:
            a = mid_a + (bot_a - mid_a) * ((f - mid_f) / (1 - mid_f))
        alpha = int(a * 255)
        if alpha > 0:
            od.line([(0, y), (W, y)], fill=color + (alpha,))
    return ov

def build_bg():
    global _BG
    # 1) Shipyard photo + steel-blue HUD filter (mirror .bg-layer CSS):
    #    hue-rotate(195deg) saturate(0.55) brightness(0.45) contrast(1.05)
    photo = Image.open(BG_PHOTO).convert("RGB")
    photo = _cover_resize(photo, W, H)
    hsv = photo.convert("HSV")
    Hc, Sc, Vc = hsv.split()
    Hc = Hc.point(lambda h: (h + 138) % 256)  # 195/360*255 ~= 138
    photo = Image.merge("HSV", (Hc, Sc, Vc)).convert("RGB")
    photo = ImageEnhance.Color(photo).enhance(0.55)      # saturate(0.55)
    photo = ImageEnhance.Brightness(photo).enhance(0.45)  # brightness(0.45)
    photo = ImageEnhance.Contrast(photo).enhance(1.05)    # contrast(1.05)
    base = photo.convert("RGBA")

    # 2) Dark overlay (mirror .bg-overlay): top azure glow + bottom black + linear base
    ov_linear = _vgrad((3, 8, 17), 0.70, 0.35, 0.80)
    ov_top = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    otd = ImageDraw.Draw(ov_top)
    for y in range(H):
        f = y / H
        if f < 0.55:
            alpha = int(0.42 * 255 * (1 - f / 0.55))
            if alpha > 0:
                otd.line([(0, y), (W, y)], fill=(15, 60, 110, alpha))
    ov_bot = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    obd = ImageDraw.Draw(ov_bot)
    for y in range(H):
        f = y / H
        if f > 0.4:
            alpha = int(0.95 * 255 * min(1.0, (f - 0.4) / 0.6))
            if alpha > 0:
                obd.line([(0, y), (W, y)], fill=(3, 8, 17, alpha))
    overlay = Image.alpha_composite(ov_linear, ov_top)
    overlay = Image.alpha_composite(overlay, ov_bot)
    bg = Image.alpha_composite(base, overlay)

    # 3) Faint engineering grid (mirror .hud-grid) — extremely subtle, non-distracting
    grid = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grid)
    ga = int(0.05 * 255)
    step = 40
    for x in range(0, W + 1, step):
        gd.line([(x, 0), (x, H)], fill=(56, 189, 248, ga))
    for y in range(0, H + 1, step):
        gd.line([(0, y), (W, y)], fill=(56, 189, 248, ga))
    bg = Image.alpha_composite(bg, grid)

    _BG = bg.convert("RGB")

# -----------------------------------------------------------------------------
def rounded_rect(d, xy, radius, fill=None, outline=None, width=1):
    x0, y0, x1, y1 = xy
    r = min(radius, (x1 - x0) // 2, (y1 - y0) // 2)
    if fill is not None:
        d.rounded_rectangle(xy, radius=r, fill=fill)
    if outline is not None and width > 0:
        d.rounded_rectangle(xy, radius=r, outline=outline, width=width)

def text_size(d, text, font):
    bbox = d.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0], bbox[3] - bbox[1]

def draw_glow_rect(im, d, xy, color, radius, glow_radius=10):
    x0, y0, x1, y1 = xy
    r = min(radius, (x1 - x0) // 2, (y1 - y0) // 2)
    for i in range(glow_radius, 0, -2):
        alpha = int(35 * (1 - i / glow_radius))
        overlay = Image.new("RGBA", (x1 - x0 + i * 2, y1 - y0 + i * 2), (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        od.rounded_rectangle([0, 0, x1 - x0 + i * 2 - 1, y1 - y0 + i * 2 - 1],
                             radius=r + i, outline=color + (alpha,), width=2)
        im.paste(overlay, (x0 - i, y0 - i), overlay)

# -----------------------------------------------------------------------------
# Layout: SAME as Table 6.10 proven coordinates.
TABLE_X = 70
TABLE_Y = 152
TABLE_W = 1040

CARD_X = 80
CARD_W = 1760
CARD_Y = 620
CARD_H = 348

SUB_Y = 974
SUB_H = 106

def table_layout(slide=0):
    th = int(TABLE_W * IMG_H / IMG_W) if IMG_W else 455
    return TABLE_X, TABLE_Y, TABLE_W, th

# -----------------------------------------------------------------------------
_CARD_CACHE = {}

def build_card(row, card_w, card_h):
    key = (row["code"], card_w, card_h)
    if key in _CARD_CACHE:
        return _CARD_CACHE[key]
    card = Image.new("RGBA", (card_w, card_h), (0, 0, 0, 0))
    cd = ImageDraw.Draw(card)
    m = 36
    rounded_rect(cd, [0, 0, card_w, card_h], radius=26, fill=CARD_BG, outline=CYAN, width=3)
    rounded_rect(cd, [10, 10, card_w - 10, card_h - 10], radius=22, outline=(0, 212, 255, 45), width=1)
    # LEFT zone: tag pill (CN) + EN tag + big code (pop-in) + bilingual note
    tag_w, _ = text_size(cd, row["tag"], get_font("cn_b", 26))
    rounded_rect(cd, [m, 40, m + tag_w + 34, 86], radius=23,
                 fill=(0, 212, 255, 45), outline=CYAN, width=2)
    cd.text((m + 17, 49), row["tag"], font=get_font("cn_b", 26), fill=CYAN)
    cd.text((m, 96), row.get("tag_en", ""), font=get_font("en_b", 22), fill=GOLD)
    if row.get("big_sub"):
        cd.text((m, 288), row["big_sub"], font=get_font("cn", 22), fill=LIGHT)
    if row.get("big_sub_en"):
        cd.text((m, 310), row["big_sub_en"], font=get_font("en", 18), fill=DIM)
    # RIGHT zone: EN title (top) + CN title + bilingual label + value bar + bilingual bullets
    rx = 600
    cd.text((rx, 40), row.get("title_en", ""), font=get_font("en_b", 30), fill=GOLD)
    cd.text((rx, 78), row["title"], font=get_font("cn_b", 36), fill=WHITE)
    cd.text((rx, 116), "验收准则  Acceptance Criterion", font=get_font("cn", 22), fill=DIM)
    bar_h = 52
    bar_y = 158
    rounded_rect(cd, [rx, bar_y, card_w - m, bar_y + bar_h], radius=16,
                 fill=(255, 193, 7, 22), outline=GOLD, width=2)
    big_text = row.get("big", "")
    big_font = get_font("en_b", 54)
    btw, bth = text_size(cd, big_text, big_font)
    if btw > card_w - m - rx - 40:
        big_font = get_font("en_b", 44)
        btw, bth = text_size(cd, big_text, big_font)
    cd.text((rx + (card_w - m - rx) // 2 - btw // 2, bar_y + (bar_h - bth) // 2 - 2),
            big_text, font=big_font, fill=GOLD)
    y = 226
    for line in row["body"]:
        cd.text((rx, y), line, font=get_font("cn", 22), fill=LIGHT)
        y += 40
    _CARD_CACHE[key] = card
    return card

# code draw position (landscape left zone), used by draw_card pop-in
CODE_X = 36
CODE_TOP = 150

# -----------------------------------------------------------------------------
def draw_top(d, scene):
    pill_text = "ASME B31.3:2020  ·  TABLE 341.3.2"
    fw = get_font("en_b", 24)
    pw, ph = text_size(d, pill_text, fw)
    px, py = 80, 30
    rounded_rect(d, [px, py, px + pw + 44, py + 50], radius=25,
                 fill=(8, 18, 42, 220), outline=CYAN, width=2)
    d.text((px + 22, py + 11), pill_text, font=fw, fill=CYAN)
    title = scene.get("top_title", "焊缝验收准则")
    d.text((W // 2, 70), title, font=get_font("cn_b", 52), fill=WHITE, anchor="mm")
    d.text((W // 2, 116), scene.get("top_title_en", ""), font=get_font("en", 26), fill=GOLD, anchor="mm")

# -----------------------------------------------------------------------------
def draw_table(im, d, key, scene_t):
    tx, ty, tw, th = table_layout()
    table_img = TABLE_BASE.resize((tw, th), Image.LANCZOS)
    draw_glow_rect(im, d, [tx, ty, tx + tw, ty + th], CYAN, 12, 12)
    im.paste(table_img, (tx, ty))
    fdx0 = tx + int(TABLE_FRAME[0] / IMG_W * tw)
    fdy0 = ty + int(TABLE_FRAME[1] / IMG_H * th)
    fdx1 = tx + int(TABLE_FRAME[2] / IMG_W * tw)
    fdy1 = ty + int(TABLE_FRAME[3] / IMG_H * th)
    if key and key in ROW_BBOX:
        overlay = Image.new("RGBA", (tw, th), (0, 0, 0, 135))
        im.paste(overlay, (tx, ty), overlay)
        rb = ROW_BBOX[key]
        hx0 = clamp(tx + int(rb[0] / IMG_W * tw), fdx0, fdx1)
        hx1 = clamp(tx + int(rb[2] / IMG_W * tw), fdx0, fdx1)
        hy0 = clamp(ty + int(rb[1] / IMG_H * th), fdy0, fdy1)
        hy1 = clamp(ty + int(rb[3] / IMG_H * th), fdy0, fdy1)
        if hx1 > hx0 and hy1 > hy0:
            rc = table_img.crop((int(hx0 - tx), int(hy0 - ty), int(hx1 - tx), int(hy1 - ty)))
            im.paste(rc, (hx0, hy0))
            bright = Image.new("RGBA", (hx1 - hx0, hy1 - hy0), (255, 232, 150, 30))
            im.paste(bright, (hx0, hy0), bright)
            draw_glow_rect(im, d, [hx0, hy0, hx1, hy1], GOLD, 8, 14)
            d.rounded_rectangle([hx0, hy0, hx1, hy1], radius=6, outline=GOLD, width=4)

# -----------------------------------------------------------------------------
def draw_card(im, row, slide, scene_t):
    if slide <= 0:
        return
    card = build_card(row, CARD_W, CARD_H)
    if slide < 1.0:
        card = card.copy()
        r, g, b, a = card.split()
        a = a.point(lambda x: int(x * slide / 255))
        card = Image.merge("RGBA", (r, g, b, a))
    card_y = int(H + 40 + (CARD_Y - (H + 40)) * ease_out_cubic(slide))
    im.paste(card, (CARD_X, card_y), card)
    pop_dur = 0.45
    p = clamp(scene_t / pop_dur, 0, 1)
    sc = 3.0 - 2.0 * ease_out_back(p)
    op = int(255 * (0.4 + 0.6 * p))
    code = row["code"].upper()
    font_big = get_font("en_b", max(40, int(96 * sc)))
    tmp = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    cw, ch = text_size(tmp, code, font_big)
    local_cx = CODE_X + 150
    local_cy = CODE_TOP + 56
    cx_text = CARD_X + local_cx - cw // 2
    cy_text = card_y + local_cy - ch // 2
    d2 = ImageDraw.Draw(im)
    d2.text((cx_text + 3, cy_text + 3), code, font=font_big, fill=(0, 0, 0, op))
    d2.text((cx_text, cy_text), code, font=font_big, fill=GOLD + (op,))

# -----------------------------------------------------------------------------
# Subtitle: plain text, EN (top) over CN (bottom), NO box.
def draw_subtitle(d, en_text, cn_text):
    f_en = get_font("en", 26)
    f_cn = get_font("cn", 26)
    en_y = SUB_Y + 20
    cn_y = SUB_Y + 72
    d.text((W // 2 + 2, en_y + 2), en_text, font=f_en, fill=(0, 0, 0, 190), anchor="mm")
    d.text((W // 2 + 2, cn_y + 2), cn_text, font=f_cn, fill=(0, 0, 0, 190), anchor="mm")
    d.text((W // 2, en_y), en_text, font=f_en, fill=(150, 220, 255), anchor="mm")
    d.text((W // 2, cn_y), cn_text, font=f_cn, fill=WHITE, anchor="mm")

# -----------------------------------------------------------------------------
# Burst helpers (unchanged from Table 6.10)
def _text_layer(text, font, color):
    tmp = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    bb = tmp.textbbox((0, 0), text, font=font)
    w = int(bb[2] - bb[0]); h = int(bb[3] - bb[1])
    layer = Image.new("RGBA", (w + 40, h + 40), (0, 0, 0, 0))
    ImageDraw.Draw(layer).text((20 - bb[0], 20 - bb[1]), text, font=font, fill=color + (255,))
    return layer

def _pill_layer(text, font, text_color, fill_bg, outline_col=None, pad_x=24, pad_y=12):
    tl = _text_layer(text, font, text_color)
    w, h = tl.size
    layer = Image.new("RGBA", (w + pad_x * 2, h + pad_y * 2), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    rounded_rect(ld, [0, 0, layer.width, layer.height], radius=min(layer.height // 2, 26),
                 fill=fill_bg, outline=outline_col, width=2 if outline_col else 0)
    layer.paste(tl, (pad_x, pad_y), tl)
    return layer

def _paste_scaled(im, layer, cx, cy, scale=1.0, alpha=255):
    if scale != 1.0:
        w, h = layer.size
        layer = layer.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.LANCZOS)
    if alpha < 255:
        r, g, b, a = layer.split()
        a = a.point(lambda x: int(x * alpha / 255))
        layer = Image.merge("RGBA", (r, g, b, a))
    w, h = layer.size
    im.paste(layer, (int(cx - w / 2), int(cy - h / 2)), layer)

def _appear(t, start, dur):
    p = clamp((t - start) / dur, 0, 1)
    return ease_out_back(p), int(255 * p)

def _tag_layer(code, cn_kind, en_kind, col):
    w, h = 290, 116
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    rounded_rect(ld, [0, 0, w, h], radius=18, fill=(col[0], col[1], col[2], 45), outline=col, width=3)
    ld.text((w // 2, 36), code, font=get_font("en_b", 44), fill=col + (255,), anchor="mm")
    ld.text((w // 2, 74), cn_kind, font=get_font("cn", 22), fill=LIGHT + (255,), anchor="mm")
    ld.text((w // 2, 98), en_kind, font=get_font("en", 18), fill=(150, 220, 255) + (255,), anchor="mm")
    return layer

def _point_layer(lab, val, col):
    # Stack CN on top, EN below (smaller) so each box is a single-language dominant stack,
    # avoiding the crowded side-by-side bilingual look that reads as "repeated" text.
    w, h = 340, 80
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    rounded_rect(ld, [0, 0, w, h], radius=14, fill=(10, 14, 34, 240), outline=col, width=2)
    # Chinese category name
    ld.text((w // 2, 18), lab, font=get_font("cn_b", 24), fill=WHITE, anchor="mm")
    # English keyword/value below, small and themed color
    en_val = val[1] if isinstance(val, tuple) else val
    ld.text((w // 2, 52), en_val, font=get_font("en_b", 20), fill=col + (255,), anchor="mm")
    return layer

def _badge_layer(lab, name, col):
    w, h = 360, 200
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    rounded_rect(ld, [0, 0, w, h], radius=22, fill=(10, 14, 34, 245), outline=col, width=3)
    ld.text((w // 2, 70), lab, font=get_font("en_b", 64), fill=col + (255,), anchor="mm")
    ld.text((w // 2, 140), name, font=get_font("cn_b", 28), fill=WHITE, anchor="mm")
    return layer

# Intro scene: dense burst (bilingual) for ASME
def draw_intro(im, d, t):
    sc, al = _appear(t, 0.0, 0.6)
    if al > 0:
        yoff = -50 * (1 - ease_out_cubic(clamp(t / 0.6, 0, 1)))
        _paste_scaled(im, _text_layer("焊缝验收准则", get_font("cn_b", 52), WHITE),
                     W // 2, 78 + yoff, scale=sc, alpha=al)
    sc, al = _appear(t, 0.2, 0.6)
    if al > 0:
        xoff = -320 * (1 - ease_out_cubic(clamp((t - 0.2) / 0.6, 0, 1)))
        _paste_scaled(im, _pill_layer("ASME B31.3:2020  ·  TABLE 341.3.2", get_font("en_b", 24),
                                      CYAN, (8, 18, 42, 220), CYAN),
                     280 + xoff, 59, scale=sc, alpha=al)
    sc, al = _appear(t, 0.4, 0.6)
    if al > 0:
        xoff = 300 * (1 - ease_out_cubic(clamp((t - 0.4) / 0.6, 0, 1)))
        _paste_scaled(im, _text_layer("Acceptance Criteria for Welds",
                                      get_font("en", 28), (205, 224, 248)),
                     W // 2 + xoff, 134, scale=sc, alpha=al)
    if t >= 0.6:
        p = ease_out_cubic(clamp((t - 0.6) / 1.2, 0, 1))
        tw = int(TABLE_W * (0.82 + 0.18 * p))
        th = int(tw * IMG_H / IMG_W)
        tbl = TABLE_BASE.resize((tw, th), Image.LANCZOS).convert("RGBA")
        _paste_scaled(im, tbl, TABLE_X + TABLE_W / 2, TABLE_Y + th / 2, scale=1.0, alpha=int(255 * p))
    tags = [
        ("A", "裂纹", "Crack", CYAN), ("A/C", "未熔合", "Lack of Fusion", CYAN),
        ("B/A", "未焊透", "Incomplete Pen.", CYAN), ("E/D", "圆形显示", "Rounded Ind.", GOLD),
        ("G/F", "线性显示", "Linear Ind.", GOLD), ("H/I", "咬边", "Undercutting", CYAN),
        ("A", "表面气孔", "Surface Porosity", GOLD), ("J", "表面质量", "Surface Finish", CYAN),
        ("K", "凹陷/烧穿", "Concave/Burn", GOLD), ("L/M", "余高/内凸", "Reinforcement", CYAN),
    ]
    base_t = 2.0
    for k, (code, cnk, enk, col) in enumerate(tags):
        sc, al = _appear(t, base_t + k * 0.35, 0.4)
        if al > 0:
            cx = TABLE_X + 155 + (k % 5) * 360
            cy = 700 + (k // 5) * 116
            _paste_scaled(im, _tag_layer(code, cnk, enk, col), cx, cy, scale=sc, alpha=al)
    points = [
        ("禁止", "Not Permitted", RED),
        ("射线检验", "Radiographic", GOLD),
        ("目视检验", "Visual", CYAN),
    ]
    for k, (lab, val, col) in enumerate(points):
        sc, al = _appear(t, 6.0 + k * 0.75, 0.5)
        if al > 0:
            _paste_scaled(im, _point_layer(lab, val, col), 1700, 260 + k * 92, scale=sc, alpha=al)

def draw_burst(im, d, row, t, dur):
    ap = clamp(t / 0.5, 0, 1)
    scale = 1.0 + 0.5 * (1 - ease_out_back(ap))
    al = int(255 * ap)
    if t > dur - 0.4:
        al = int(255 * clamp((dur - t) / 0.4, 0, 1))
    if al <= 0:
        return
    _paste_scaled(im, _badge_layer(row["big"], row["title"], GOLD), 1700, 320, scale=scale, alpha=al)

# Summary scene: bilingual recap
def draw_summary_burst(im, d, t):
    rules = [
        ("禁止", "Not Permitted", RED),
        ("射线检验", "Radiographic", GOLD),
        ("目视检验", "Visual", CYAN),
    ]
    for k, (lab, val, col) in enumerate(rules):
        sc, al = _appear(t, 0.3 + k * 0.55, 0.5)
        if al > 0:
            _paste_scaled(im, _point_layer(lab, val, col), 1700, 250 + k * 92, scale=sc, alpha=al)
    # bilingual bottom pill — compact, placed above the tag grid so it does not
    # overlap the first row (cy=720, h=116, top=662) or the subtitle area.
    sc, al = _appear(t, 2.5, 0.6)
    if al > 0:
        pw, ph = 760, 64
        layer = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
        ld = ImageDraw.Draw(layer)
        rounded_rect(ld, [0, 0, pw, ph], radius=14, fill=(10, 14, 34, 245), outline=GOLD, width=2)
        ld.text((pw // 2, 22), "按实际焊缝类型与工况核对验收准则", font=get_font("cn_b", 22), fill=WHITE, anchor="mm")
        ld.text((pw // 2, 46), "Verify acceptance criterion for actual weld type and service condition", font=get_font("en", 18), fill=(150, 220, 255), anchor="mm")
        _paste_scaled(im, layer, W // 2, 630, scale=sc, alpha=al)
    tags = [
        ("A", "裂纹", "Crack", CYAN), ("A/C", "未熔合", "LOF", CYAN),
        ("B/A", "未焊透", "IP", CYAN), ("E/D", "圆形显示", "RI", GOLD),
        ("G/F", "线性显示", "LI", GOLD), ("H/I", "咬边", "UC", CYAN),
        ("A", "表面气孔", "PO", GOLD), ("J", "表面质量", "SF", CYAN),
        ("K", "凹陷/烧穿", "CV", GOLD), ("L/M", "余高/内凸", "WR", CYAN),
    ]
    # tag grid: row spacing 125 guarantees h=116 tags do not touch each other.
    for k, (code, cnk, enk, col) in enumerate(tags):
        sc, al = _appear(t, 3.2 + k * 0.22, 0.4)
        if al > 0:
            cx = 230 + (k % 5) * 360
            cy = 720 + (k // 5) * 125
            _paste_scaled(im, _tag_layer(code, cnk, enk, col), cx, cy, scale=sc, alpha=al)

# -----------------------------------------------------------------------------
# Right panel: clean summary of the currently highlighted defect.
DIAG_X, DIAG_Y, DIAG_W, DIAG_H = 1260, 150, 640, 460

def draw_defect_summary(im, d, row, t):
    key = row.get("key")
    if not key or key not in ROW_BBOX:
        return
    ap = clamp(t / 0.4, 0, 1)
    al = int(255 * ap)
    if al <= 0:
        return
    pw, ph = DIAG_W, DIAG_H
    panel = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
    pd = ImageDraw.Draw(panel)
    rounded_rect(pd, [0, 0, pw, ph], radius=20, fill=(10, 14, 34, 245), outline=GOLD, width=4)
    rounded_rect(pd, [8, 8, pw - 8, ph - 8], radius=16, outline=(255, 193, 7, 45), width=1)
    pd.text((pw // 2, 30), "当前缺陷  Current Defect", font=get_font("cn_b", 24), fill=GOLD, anchor="mm")
    # EN defect name
    en = row.get("title_en", "")
    f_en = get_font("en_b", 30)
    ew, eh = text_size(pd, en, f_en)
    if ew > pw - 40:
        f_en = get_font("en_b", 24)
        ew, eh = text_size(pd, en, f_en)
    pd.text((pw // 2, 78), en, font=f_en, fill=WHITE, anchor="mm")
    # CN defect name
    pd.text((pw // 2, 118), row.get("title", ""), font=get_font("cn_b", 28), fill=CYAN, anchor="mm")
    # Acceptance criterion badge
    big = row.get("big", "")
    f_big = get_font("en_b", 64)
    bw, bh = text_size(pd, big, f_big)
    bx0 = (pw - bw) // 2 - 20
    bx1 = bx0 + bw + 40
    by0, by1 = 160, 230
    rounded_rect(pd, [bx0, by0, bx1, by1], radius=18, fill=(255, 193, 7, 30), outline=GOLD, width=3)
    pd.text((pw // 2, (by0 + by1) // 2 - 2), big, font=f_big, fill=GOLD, anchor="mm")
    # Examination method checks: stack CN label/value on top and EN below to avoid
    # side-by-side bilingual text that looks crowded / repeated.
    y = 260
    for label_cn, label_en, val_raw, col in [
        ("目视检验", "Visual", row.get("visual", "-"), CYAN),
        ("射线检验", "Radiography", row.get("radiography", "-"), GOLD),
    ]:
        rounded_rect(pd, [40, y, pw - 40, y + 70], radius=14, fill=(8, 18, 42, 220), outline=col, width=2)
        # Left: label (CN top, EN bottom small)
        pd.text((60, y + 20), label_cn, font=get_font("cn", 22), fill=WHITE, anchor="lm")
        pd.text((60, y + 48), label_en, font=get_font("en", 16), fill=DIM, anchor="lm")
        # Right: value (CN top, EN bottom small)
        if val_raw == "YES":
            val_cn, val_en, vcol = "适用", "Applicable", (0, 230, 130)
        elif val_raw == "NO":
            val_cn, val_en, vcol = "不适用", "N/A", DIM
        else:
            val_cn, val_en, vcol = val_raw, "", col
        right_x = pw - 60
        pd.text((right_x, y + 20), val_cn, font=get_font("cn_b", 24), fill=vcol, anchor="rm")
        if val_en:
            pd.text((right_x, y + 50), val_en, font=get_font("en_b", 18), fill=vcol, anchor="rm")
        y += 86
    if al < 255:
        rr, gg, bb, aa = panel.split()
        aa = aa.point(lambda x: int(x * al / 255))
        panel = Image.merge("RGBA", (rr, gg, bb, aa))
    im.paste(panel, (DIAG_X, DIAG_Y), panel)
    draw_glow_rect(im, d, [DIAG_X, DIAG_Y, DIAG_X + pw, DIAG_Y + ph], GOLD, 16, 16)

# -----------------------------------------------------------------------------
# Scene data (bilingual; EN voice-over; EN-over-CN subtitles & content)
SCENES = [
    {
        "key": None,
        "top_title": "焊缝验收准则",
        "top_title_en": "Acceptance Criteria for Welds",
        "caption_en": "ASME B31.3:2020 — Table 341.3.2: Acceptance Criteria for Welds.",
        "caption": "ASME B31.3:2020 表 341.3.2：焊缝验收准则。",
        "spoken": "In this lesson we look at A S M E B 31.3, 2020, Table 341.3.2, Acceptance Criteria for Welds. This table defines acceptance limits for common weld imperfections based on visual and radiographic examination."
    },
    {
        "key": "Crack", "code": "CRACK", "tag": "裂纹", "tag_en": "CRACK",
        "title": "裂纹", "title_en": "Crack",
        "big": "A", "big_sub": "所有焊缝与工况：A", "big_sub_en": "All welds & conditions: A",
        "visual": "YES", "radiography": "YES",
        "body": ["目视 + 射线均检查  ·  Visual + Radiography",
                 "任何裂纹均不可接受  ·  Cracks are not acceptable",
                 "注意分支连接焊缝  ·  Check branch connections"],
        "caption_en": "Crack — acceptance criterion A for every weld type and service condition.",
        "caption": "裂纹——所有焊缝类型与工况的验收准则均为 A。",
        "spoken": "Crack. For every weld type and service condition listed in the table, the acceptance criterion is A. Cracks are not acceptable. This imperfection is evaluated by both visual examination and radiography."
    },
    {
        "key": "Lack_of_fusion", "code": "LOF", "tag": "未熔合", "tag_en": "LACK OF FUSION",
        "title": "未熔合", "title_en": "Lack of Fusion",
        "big": "A / C", "big_sub": "多数工况 A；Category D 分支焊缝 C", "big_sub_en": "Most conditions A; Cat D branch C",
        "visual": "YES", "radiography": "YES",
        "body": ["目视 + 射线均检查  ·  Visual + Radiography",
                 "坡口与角焊缝均涉及  ·  Groove and fillet welds",
                 "未熔合属平面型缺陷  ·  Planar imperfection"],
        "caption_en": "Lack of fusion — mostly criterion A; Category D branch connection welds use criterion C.",
        "caption": "未熔合——多数工况为 A；Category D 分支连接焊缝为 C。",
        "spoken": "Lack of fusion. For most weld types and service conditions the acceptance criterion is A. Category D branch connection welds use criterion C. It is checked by both visual and radiographic examination."
    },
    {
        "key": "Incomplete_penetration", "code": "IP", "tag": "未焊透", "tag_en": "INCOMPLETE PENETRATION",
        "title": "未焊透", "title_en": "Incomplete Penetration",
        "big": "B / A", "big_sub": "Normal/Cat M 坡口焊缝 B；其余多为 A", "big_sub_en": "Normal Cat M groove: B; others mostly A",
        "visual": "YES", "radiography": "YES",
        "body": ["目视 + 射线均检查  ·  Visual + Radiography",
                 "主要见于坡口焊缝  ·  Mainly groove welds",
                 "根部未熔合风险  ·  Root fusion risk"],
        "caption_en": "Incomplete penetration — Normal/Category M groove welds use B; other conditions mostly A.",
        "caption": "未焊透——Normal/Category M 坡口焊缝为 B；其他工况多为 A。",
        "spoken": "Incomplete penetration. Normal and Category M fluid service groove welds use acceptance criterion B. Other conditions are mostly A. It is evaluated by visual and radiographic examination."
    },
    {
        "key": "Rounded_Indications", "code": "RI", "tag": "圆形显示", "tag_en": "ROUNDED INDICATIONS",
        "title": "圆形显示", "title_en": "Rounded Indications",
        "big": "E / D", "big_sub": "Normal/Cat M 为 E；Severe Cyclic 为 D", "big_sub_en": "Normal/Cat M: E; Severe Cyclic: D",
        "visual": "NO", "radiography": "YES",
        "body": ["主要用射线检查  ·  Radiography mainly",
                 "气孔、夹渣等球形缺陷  ·  Porosity / slag inclusions",
                 "Category D 不适用  ·  Not applicable for Category D"],
        "caption_en": "Rounded indications — Normal/Category M use E; Severe Cyclic uses D; Category D is not applicable.",
        "caption": "圆形显示——Normal/Category M 用 E；Severe Cyclic 用 D；Category D 不适用。",
        "spoken": "Rounded indications, such as porosity or slag inclusions. Normal and Category M fluid service use criterion E. Severe cyclic conditions use criterion D. Category D fluid service is not applicable. This imperfection is generally evaluated by radiography only."
    },
    {
        "key": "Linear_indications", "code": "LI", "tag": "线性显示", "tag_en": "LINEAR INDICATIONS",
        "title": "线性显示", "title_en": "Linear Indications",
        "big": "G / F", "big_sub": "Normal/Cat M 为 G；Severe Cyclic 为 F", "big_sub_en": "Normal/Cat M: G; Severe Cyclic: F",
        "visual": "NO", "radiography": "YES",
        "body": ["射线检查  ·  Radiography",
                 "裂纹、未熔合等条状显示  ·  Crack-like / linear flaws",
                 "Category D 不适用  ·  Not applicable for Category D"],
        "caption_en": "Linear indications — Normal/Category M use G; Severe Cyclic uses F; evaluated by radiography.",
        "caption": "线性显示——Normal/Category M 用 G；Severe Cyclic 用 F；射线检查。",
        "spoken": "Linear indications, such as crack-like or lack-of-fusion flaws. Normal and Category M fluid service use criterion G. Severe cyclic conditions use criterion F. Category D is not applicable. This is evaluated by radiography."
    },
    {
        "key": "Undercutting", "code": "UC", "tag": "咬边", "tag_en": "UNDERCUTTING",
        "title": "咬边", "title_en": "Undercutting",
        "big": "H / I", "big_sub": "多数为 H；Category D 纵向/角焊缝为 I", "big_sub_en": "Most H; Cat D long/fillet use I",
        "visual": "YES", "radiography": "YES",
        "body": ["目视 + 射线均检查  ·  Visual + Radiography",
                 "焊趾处母材凹陷  ·  Groove at weld toe",
                 "工况不同准则不同  ·  Criterion varies by condition"],
        "caption_en": "Undercutting — most conditions use H; Category D longitudinal and fillet welds use I.",
        "caption": "咬边——多数工况为 H；Category D 纵向/角焊缝为 I。",
        "spoken": "Undercutting. Most conditions use acceptance criterion H. Category D longitudinal groove welds and fillet welds use criterion I. Undercutting is evaluated by both visual examination and radiography."
    },
    {
        "key": "Surface_porosity_or_exposed_slag_inclusion", "code": "PO", "tag": "表面气孔/夹渣", "tag_en": "SURFACE POROSITY / SLAG",
        "title": "表面气孔或外露夹渣", "title_en": "Surface Porosity or Exposed Slag Inclusion",
        "big": "A", "big_sub": "所有适用工况均为 A", "big_sub_en": "All applicable conditions: A",
        "visual": "YES", "radiography": "NO",
        "body": ["主要用目视检查  ·  Visual mainly",
                 "暴露于表面的气孔或夹渣  ·  Surface-breaking pores/slag",
                 "射线栏为省略  ·  Radiography: not generally used"],
        "caption_en": "Surface porosity or exposed slag inclusion — acceptance A for all applicable conditions; visual examination.",
        "caption": "表面气孔或外露夹渣——所有适用工况均为 A；目视检查。",
        "spoken": "Surface porosity or exposed slag inclusion. For all applicable weld types and service conditions, the acceptance criterion is A. This imperfection is evaluated mainly by visual examination."
    },
    {
        "key": "Surface_finish", "code": "SF", "tag": "表面质量", "tag_en": "SURFACE FINISH",
        "title": "表面质量", "title_en": "Surface Finish",
        "big": "J", "big_sub": "Severe Cyclic / Category D 用 J", "big_sub_en": "Severe Cyclic & Cat D: J",
        "visual": "YES", "radiography": "NO",
        "body": ["目视检查  ·  Visual examination",
                 "焊缝表面成形要求  ·  Weld surface profile",
                 "Normal/Cat M 不适用  ·  Not applicable for Normal/Cat M"],
        "caption_en": "Surface finish — criterion J for Severe Cyclic and Category D; not applicable for Normal/Category M.",
        "caption": "表面质量——Severe Cyclic 与 Category D 用 J；Normal/Category M 不适用。",
        "spoken": "Surface finish. Criterion J applies to severe cyclic conditions and Category D fluid service. Normal and Category M fluid service are not applicable. Surface finish is evaluated by visual examination."
    },
    {
        "key": "Concave_surface_concave_root_or_burn_through", "code": "CV", "tag": "凹陷/烧穿", "tag_en": "CONCAVE / BURN-THROUGH",
        "title": "凹陷表面、凹根或烧穿", "title_en": "Concave Surface, Concave Root, or Burn-Through",
        "big": "K", "big_sub": "多数适用工况为 K", "big_sub_en": "Most applicable conditions: K",
        "visual": "YES", "radiography": "YES",
        "body": ["目视 + 射线均检查  ·  Visual + Radiography",
                 "根部凹陷或熔穿  ·  Root concavity / burn-through",
                 "Category D 部分不适用  ·  Some Cat D conditions N/A"],
        "caption_en": "Concave surface, concave root, or burn-through — most applicable conditions use K.",
        "caption": "凹陷表面、凹根或烧穿——多数适用工况为 K。",
        "spoken": "Concave surface, concave root, or burn-through. Most applicable conditions use acceptance criterion K. Some Category D conditions are not applicable. It is evaluated by both visual and radiographic examination."
    },
    {
        "key": "Weld_reinforcement_or_internal_protrusion", "code": "WR", "tag": "余高/内凸", "tag_en": "REINFORCEMENT / PROTRUSION",
        "title": "焊缝余高或内部凸起", "title_en": "Weld Reinforcement or Internal Protrusion",
        "big": "L / M", "big_sub": "Normal/Cat M/Severe Cyclic 为 L；Category D 为 M", "big_sub_en": "Normal/Cat M/Severe Cyclic: L; Cat D: M",
        "visual": "YES", "radiography": "NO",
        "body": ["目视检查  ·  Visual examination",
                 "焊缝表面余高或根部内凸  ·  Excess weld metal / internal protrusion",
                 "Category D 单独用 M  ·  Cat D uses M"],
        "caption_en": "Weld reinforcement or internal protrusion — Normal/Category M and Severe Cyclic use L; Category D uses M.",
        "caption": "焊缝余高或内部凸起——Normal/Category M 与 Severe Cyclic 用 L；Category D 用 M。",
        "spoken": "Weld reinforcement or internal protrusion. Normal and Category M fluid service, and severe cyclic conditions, use criterion L. Category D fluid service uses criterion M. This is evaluated by visual examination."
    },
    {
        "key": None,
        "top_title": "核心规则",
        "top_title_en": "Key Rules",
        "caption_en": "Table 341.3.2: cracks, lack of fusion and incomplete penetration are generally unacceptable; rounded and linear indications are radiography-only; surface and reinforcement issues are mainly visual.",
        "caption": "表 341.3.2：裂纹、未熔合、未焊透通常不可接受；圆形/线性显示主要用射线；表面/余高问题主要用目视。",
        "spoken": "Table 341.3.2 summary. Cracks, lack of fusion and incomplete penetration are generally not acceptable. Rounded and linear indications are evaluated mainly by radiography. Surface finish, porosity, concavity and reinforcement are evaluated mainly by visual examination. Always verify the specified acceptance criterion for the actual weld type and service condition."
    }
]

# -----------------------------------------------------------------------------
def tts(text, out_path):
    cmd = ["edge-tts", "--voice", "en-US-AriaNeural", "--text", text, "--write-media", out_path]
    subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8")

def get_audio(i, text):
    path = os.path.join(CACHE_DIR, f"scene_{i:02d}.mp3")
    if not os.path.exists(path):
        print(f"  tts scene {i}")
        tts(text, path)
    return path

def audio_duration(path):
    r = subprocess.run([FFMPEG, "-i", path], capture_output=True, encoding="utf-8", errors="ignore")
    m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", r.stderr)
    if not m:
        return 5.0
    h, m_, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
    return h * 3600 + m_ * 60 + s

# -----------------------------------------------------------------------------
scene_dur_last = 1.0

def render():
    global scene_dur_last
    print("loading assets...")
    load_assets()
    build_bg()
    durations = []
    audio_paths = []
    for i, sc in enumerate(SCENES):
        mp3 = get_audio(i, sc["spoken"])
        dur = audio_duration(mp3) + 0.6
        durations.append(dur)
        audio_paths.append(mp3)
        print(f"scene {i}: {dur:.2f}s")

    print("rendering frames...")
    os.makedirs(FRAMES_DIR, exist_ok=True)
    frame_idx = 0
    seg_files = []
    for i, sc in enumerate(SCENES):
        dur = durations[i]
        n = int(dur * FPS) + 1
        row = sc if sc.get("key") else None
        card_in = 0.35
        card_out = 0.45
        scene_start = frame_idx
        for f in range(n):
            t = f / FPS
            slide = 0.0
            if row:
                if t < card_in:
                    slide = t / card_in
                elif t > dur - card_out:
                    slide = max(0.0, (dur - t) / card_out)
                else:
                    slide = 1.0
            scene_dur_last = dur
            im = Image.new("RGBA", (W, H), BG + (255,))
            d = ImageDraw.Draw(im)
            im.paste(_BG, (0, 0))
            if i == 0:
                draw_intro(im, d, t)
            elif i == len(SCENES) - 1:
                draw_top(d, sc)
                draw_table(im, d, sc.get("key"), t)
                draw_summary_burst(im, d, t)
            else:
                draw_top(d, sc)
                draw_table(im, d, sc.get("key"), t)
                if row:
                    draw_card(im, row, slide, t)
                    draw_defect_summary(im, d, row, t)
            draw_subtitle(d, sc.get("caption_en", ""), sc["caption"])
            out_path = os.path.join(FRAMES_DIR, f"frame_{frame_idx:06d}.png")
            im.convert("RGB").save(out_path)
            frame_idx += 1
        seg_files.append((i, scene_start, n, audio_paths[i], dur))

    print("encoding segments...")
    seg_mp4s = []
    for i, start, n, mp3, dur in seg_files:
        seg_mp4 = os.path.join(FRAMES_DIR, f"seg_{i:02d}.mp4")
        cmd = [
            FFMPEG, "-y",
            "-framerate", str(FPS),
            "-start_number", str(start),
            "-i", os.path.join(FRAMES_DIR, "frame_%06d.png"),
            "-i", mp3,
            "-frames:v", str(n),
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
            "-c:a", "aac", "-b:a", "128k",
            "-shortest", seg_mp4
        ]
        subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8", errors="ignore")
        seg_mp4s.append(seg_mp4)
        print(f"  seg {i} done")

    print("concatenating...")
    import shutil as _shutil
    tmp = r"C:\wb_tmp_concat"
    if os.path.exists(tmp):
        _shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp, exist_ok=True)
    tmp_segs = []
    for mp4 in seg_mp4s:
        dst = os.path.join(tmp, os.path.basename(mp4))
        _shutil.copy2(mp4, dst)
        tmp_segs.append(dst)
    concat_file = os.path.join(tmp, "concat.txt")
    with open(concat_file, "w", encoding="utf-8") as cf:
        for mp4 in tmp_segs:
            cf.write(f"file '{mp4.replace(chr(92), '/')}'\n")
    final = os.path.join(OUT_DIR, "asme_b31_3_table341_3_2_walkthrough.mp4")
    cmd = [
        FFMPEG, "-y",
        "-f", "concat", "-safe", "0", "-i", concat_file,
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
        "-c:a", "aac", "-b:a", "160k",
        "-movflags", "+faststart",
        final
    ]
    subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8", errors="ignore")
    try:
        _shutil.rmtree(tmp, ignore_errors=True)
    except Exception:
        pass
    print("final:", final)
    return final

if __name__ == "__main__":
    render()
