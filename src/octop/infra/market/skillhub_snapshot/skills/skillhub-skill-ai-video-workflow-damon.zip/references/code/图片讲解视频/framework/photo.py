# -*- coding: utf-8 -*-
"""风格化照片融入（自适应 0/1/2 张）。

根据风格给出不同边框：
  business/realistic/mechanical/punk -> glass（半透深底+细亮边+柔影）
  manga                              -> white（白粗边+黑细描+柔影）
  guofeng                            -> seal（米白双线边+朱红印章）
  feather（写实左侧大图）            -> 无边框，右缘羽化融入背景

build_photo_layer 返回 RGBA 图层（已含边框/阴影），由 layouts 决定摆放位置。
"""
from PIL import Image, ImageDraw, ImageFilter

FRAME_BY_STYLE = {
    "business": "glass", "realistic": "glass", "mechanical": "glass",
    "punk": "glass", "manga": "white", "guofeng": "seal",
}


def framing_for_style(style, override=None):
    if override:
        return override
    return FRAME_BY_STYLE.get(style.key, "glass")


def _round(draw, box, r, fill=None, outline=None, width=1):
    draw.rounded_rectangle(box, radius=r, fill=fill, outline=outline, width=width)


def build_photo_layer(im, style, target_h, framing=None):
    framing = framing_for_style(style, framing)
    aspect = im.width / im.height
    w = int(target_h * aspect)
    photo = im.resize((w, target_h)).convert("RGBA")

    if framing == "feather":
        # 右缘羽化：水平 alpha 渐变
        mask = Image.new("L", (w, target_h), 255)
        md = ImageDraw.Draw(mask)
        fade = int(w * 0.35)
        for x in range(w - fade, w):
            a = int(255 * (1 - (x - (w - fade)) / fade))
            md.line([(x, 0), (x, target_h)], fill=a)
        photo.putalpha(mask)
        return photo

    pad = 22 if framing == "glass" else (20 if framing == "white" else 16)
    lw, lh = w + pad * 2, target_h + pad * 2
    layer = Image.new("RGBA", (lw, lh), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    p = style.palette
    border = p["panel_border"]

    if framing == "glass":
        # 柔影
        sh = Image.new("RGBA", (lw, lh), (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh)
        _round(sd, [6, 16, lw - 6, lh - 4], style.card_radius, fill=(0, 0, 0, 150))
        sh = sh.filter(ImageFilter.GaussianBlur(14))
        layer = Image.alpha_composite(sh, layer)
        ld = ImageDraw.Draw(layer)
        # 半透深底
        _round(ld, [2, 2, lw - 2, lh - 2], style.card_radius,
               fill=(*p["panel"], style.card_alpha))
        # 细亮边
        _round(ld, [2, 2, lw - 2, lh - 2], style.card_radius,
               outline=(*border, style.border_alpha), width=style.line_width)
        layer.paste(photo, (pad, pad))
    elif framing == "white":
        sh = Image.new("RGBA", (lw, lh), (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh)
        _round(sd, [6, 14, lw - 6, lh - 4], 12, fill=(0, 0, 0, 140))
        sh = sh.filter(ImageFilter.GaussianBlur(12))
        layer = Image.alpha_composite(sh, layer)
        ld = ImageDraw.Draw(layer)
        _round(ld, [2, 2, lw - 2, lh - 2], 12, fill=(255, 255, 255, 255))
        _round(ld, [2, 2, lw - 2, lh - 2], 12, outline=(20, 20, 30, 255), width=4)
        layer.paste(photo, (pad, pad))
    elif framing == "seal":
        _round(ld, [2, 2, lw - 2, lh - 2], 6, fill=(250, 245, 232, 255))
        _round(ld, [6, 6, lw - 6, lh - 6], 4, outline=(170, 46, 46, 255), width=3)
        _round(ld, [12, 12, lw - 12, lh - 12], 3, outline=(170, 46, 46, 180), width=1)
        layer.paste(photo, (pad, pad))
        # 朱红印章
        ss = 64
        sd2 = ImageDraw.Draw(layer)
        _round(sd2, [lw - pad - ss - 6, pad + 6, lw - pad - 6, pad + 6 + ss], 6,
               fill=(180, 46, 46, 235))
        tf = style.get_font("cn_b", 34)
        sd2.text((lw - pad - 6 - ss / 2, pad + 6 + ss / 2), "鉴",
                 font=tf, fill=(255, 255, 255, 255), anchor="mm")
    return layer
