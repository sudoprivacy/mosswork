# ASME B31.3 表格讲解 — 先看这个

> ⚠️ **动手前先看**：[避坑总纲](../1_避坑总纲_血泪清单.md)（历史翻车 + 硬闸门）
> ✅ **交付前必跑**：`python ../check.py <成片.mp4>` ｜ 勾选表：[交付前自检清单](../2_交付前自检清单.md)

> 把 ASME B31.3 Table 341.3.2（焊缝缺陷射线验收 / Longitudinal Weld Joint Quality Factor）讲成讲解视频。
> 0 积分、纯本地 CPU + edge-tts + ffmpeg。

## 一句话用法

```bash
# 主入口：渲染 ASME B31.3 Table 341.3.2
python render/render_asme_b31_3_table341_3_2.py

# 加速/批渲染（按场景独立子进程）
python render/render_batch.py

# GATE 0（遮挡/出框预判）
python render/layout_guard.py

# 段拼接
python render/concat_segments.py
```

## 工作区结构

```
ASME_B31_3_表格讲解/
├── render/
│   ├── render_asme_b31_3_table341_3_2.py    # ★ 主入口
│   ├── render_batch.py                        # 批渲染（多核）
│   ├── layout_guard.py                        # GATE 1 坐标护栏
│   ├── concat_segments.py                     # 段拼接
│   ├── test_bg.py                             # 背景测试
│   ├── frames_land_b31_341_3_2/               # 帧缓存（可重生成）
│   ├── audio_cache/                           # TTS 缓存（中文）
│   ├── audio_cache_en/                        # TTS 缓存（英文）
│   ├── layout_guard/                          # 护栏中间产物
│   ├── concat_list.txt                        # 拼接清单
│   └── render.log
├── source/                                    # 源素材（B31.3 Table 341.3.2 原图等）
├── docs/
│   └── 红线与检查清单.md                      # ★ 必读
├── output/                                    # 中间产物
│   └── test_frame.py
└── 0_README_先看这个.md
```

## 核心特性

- **横版 / 竖屏可切**：通过 `render_asme_b31_3_table341_3_2.py` 的参数
- **GATE 三道闸**：
  - GATE 0：`plan_change.py`（读 SCENES 预判遮挡/出框）
  - GATE 1：`layout_guard.py`（实跑一帧验证 UI 不重叠）
  - GATE 2：`render_fast.py` + SSIM（多核 veryfast、像素级一致）
- **TTS**：edge-tts、缓存按场景序号命名（改 spoken 必清缓存）
- **B31.3 Table 341.3.2 缺陷验收**：crack/undercut/lof/reinforcement/rounded 等 6 类典型缺陷

## 已知坑

- 改 SCENES 文案必清 `audio_cache_en/*.mp3` 和 `audio_cache/*.mp3`
- ffmpeg concat 中文路径已用 ASCII 临时目录处理
- GATE 1 跑不过不要交付

## 客户交付检查

- [ ] GATE 0/1/2 全过
- [ ] 表格高亮严格在表内
- [ ] 字幕 EN 上 CN 下
- [ ] 缺陷（crack/undercut/lof/reinforcement/rounded）逐类讲清
- [ ] 像素级一致（SSIM ≥ 0.99）
