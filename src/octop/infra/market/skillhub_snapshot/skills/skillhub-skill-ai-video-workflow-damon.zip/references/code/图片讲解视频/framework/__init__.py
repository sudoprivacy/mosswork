# -*- coding: utf-8 -*-
"""配照片讲解 PPT 视频工作流 —— 框架层。

模块：
  styles     风格预设库（商务/漫画/写实/国风/机械/朋克）
  registry   元素登记器（记录每处绘制包围盒）
  validator  硬审核（超屏/重叠/图压字，strict 卡死）
  canvas     画布（绘图 + 自动登记 + 即时校验）
  backgrounds 风格化背景
  photo      风格化照片融入（自适应 0/1/2 张）
  layouts    9 种版式
  content    审题（brief + 素材 -> 结构化大纲）
  templates  4 类应用模板
  engine     编排（审题->执行->质检->输出）
"""
from . import styles
from . import registry
from . import validator
from . import canvas
from . import backgrounds
from . import photo
from . import layouts
from . import content
from . import templates
from . import engine

__all__ = ["styles", "registry", "validator", "canvas", "backgrounds",
           "photo", "layouts", "content", "templates", "engine"]
