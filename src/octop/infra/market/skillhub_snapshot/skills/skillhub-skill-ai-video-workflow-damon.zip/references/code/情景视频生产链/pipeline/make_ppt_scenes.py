#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PPT -> scenes.json: 把"脚本文案"对到 PPT 导出的 slide_XX.png 上。

脚本格式(任选一种):
  A) 纯文本 .txt
       每页一块, 块与块之间用空行 或 一行 "---" 分隔;
       块内第一行 = 英语(口播), 第二行 = 汉语(字幕)。
       例:
         Offshore crane lifting requires a cleared radius.
         海上吊装作业要求清空作业半径。
         ---
         The HSE officer stops the lift when workers are too close.
         安全员在人员过近时叫停吊装。

  B) JSON .json
       [{"en":"...","zh":"..."}, ...]
       或 {"scenes":[{"en":"...","zh":"..."}]}

产物: projects/<proj>/scenes.json
   mode=narration(单旁白音色), lang 由 --lang 决定,
   每镜一张 slide 图 + 双语字幕(英语口播 + 汉语字幕, 或反过来)。

用法:
  python pipeline/make_ppt_scenes.py --project ppt_demo \
      --script "D:/scripts/ppt_demo.txt" --lang en
"""
import os, sys, json, re, glob, argparse
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(ROOT, 'pipeline', 'config.json'), encoding='utf-8'))


def read_script(path):
    if path.lower().endswith('.json'):
        d = json.load(open(path, encoding='utf-8'))
        if isinstance(d, dict) and 'scenes' in d:
            d = d['scenes']
        return [{'en': (x.get('en') or x.get('narration_en') or '').strip(),
                 'zh': (x.get('zh') or x.get('narration_zh') or '').strip()}
                for x in d]
    # 文本格式: 空行或 "---" 分隔块, 块内 第一行=英 第二行=中
    txt = open(path, encoding='utf-8').read()
    blocks = re.split(r'(?:\n[ \t]*---[ \t]*\n)|(?:\n[ \t]*\n[ \t]*\n)', txt)
    out = []
    for b in blocks:
        lines = [l.strip() for l in b.splitlines() if l.strip()]
        if not lines:
            continue
        out.append({'en': lines[0], 'zh': lines[1] if len(lines) > 1 else ''})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', required=True)
    ap.add_argument('--script', required=True, help='脚本 .txt 或 .json')
    ap.add_argument('--lang', default='en', choices=['zh', 'en'])
    ap.add_argument('--title', default='', help='标题(可选, 用于片头卡)')
    ap.add_argument('--aspect', default=CFG.get('default_aspect', '16:9'))
    a = ap.parse_args()

    proj = os.path.join(ROOT, 'projects', a.project)
    img_dir = os.path.join(proj, 'images')
    slides = sorted(glob.glob(os.path.join(img_dir, 'slide_*.png')))
    if not slides:
        sys.exit('没找到 slide_*.png, 请先跑:\n'
                 '  python pipeline/ppt_to_images.py --ppt X.pptx --project %s' % a.project)

    scripts = read_script(a.script)
    n = len(slides)
    if len(scripts) < n:
        print('⚠️ 脚本只有 %d 段, 但 PPT 有 %d 页; 多出的页字幕留空(可补脚本后重跑)' % (len(scripts), n))

    scenes = []
    for k, img in enumerate(slides, start=1):
        s = {'idx': k, 'speaker': 'N', 'speaker_en': 'Narrator', 'speaker_zh': '旁白',
             'caption_zh': '第 %d 页' % k, 'caption_en': 'Slide %d' % k,
             'image_file': os.path.basename(img),
             'narration_en': '', 'narration_zh': ''}
        if k - 1 < len(scripts):
            s['narration_en'] = scripts[k - 1]['en']
            s['narration_zh'] = scripts[k - 1]['zh']
        scenes.append(s)

    meta = {
        'domain': 'ppt', 'key': a.project, 'platform': '',
        'mode': 'narration', 'lang': a.lang,
        'title_zh': a.title or 'PPT 视频', 'title_en': a.title or 'PPT Video',
        'source': 'ppt_to_images + script', 'generated_at': datetime.now().isoformat(),
    }
    out = {'meta': meta, 'scenes': scenes}
    json.dump(out, open(os.path.join(proj, 'scenes.json'), 'w', encoding='utf-8'),
             ensure_ascii=False, indent=2)
    print('scenes.json -> %s (%d 镜)' % (os.path.join(proj, 'scenes.json'), n))
    print('提示: 双语字幕已写入, 直接跑 build_video.py 即可合成。')


if __name__ == '__main__':
    main()
