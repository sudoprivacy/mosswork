# -*- coding: utf-8 -*-
"""审题 + 执行准备（确定性，可复现）。

输入 Brief（结构化 dict），输出 scenes 列表 + 审题结论。
不含随机，保证同一输入恒定输出（用户要求"稳定不出错"）。

审题职责：
  - 缺失字段给默认/警告（title、points 必须有）
  - 确定 template（brief 指定或自动推断）与 style（brief 指定或模板默认）
  - 把素材要点映射成场景序列（cover + 各 point + 尾屏 cta）
  - 给每个场景补默认 kicker / caption，保证字段完整
执行准备职责：
  - 解析照片路径列表
  - 解析写实风背景图（如提供）
  - 输出可直接交给 engine 渲染的数据
"""
import os
from typing import Dict, List, Any
from . import templates as T
from . import layouts as L

# 默认工业背景（焊接现场 PPE 场景），brief 未指定 bg_image 时启用，保证"工业背景可见"。
_DEFAULT_BG = r"D:/微信小程序/船海风云/人物角色示例图/焊接现场PPE检查Q版情景视频提示词.png"


class BriefError(Exception):
    pass


def _default_points_from_text(text):
    """把一段自由文本按行/空行拆成要点（兜底，用户没给结构化 points 时用）。"""
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    pts = []
    for l in lines[:8]:
        pts.append({"type": "text", "title": l[:24], "body": l})
    return pts


def plan(brief: Dict[str, Any], strict: bool = True):
    """审题 + 执行准备。返回 (scenes, meta, review)。"""
    review = []

    # ---- 审题：必填校验 ----
    title = brief.get("title", "").strip()
    if not title:
        raise BriefError("Brief 缺少 title（视频主题标题），无法成片。")
    points = brief.get("points")
    if points is None:
        mat = brief.get("material", "")
        if mat:
            points = _default_points_from_text(mat)
            review.append("未提供结构化 points，已按素材文本自动拆成要点。")
        else:
            raise BriefError("Brief 既无 points 也无 material，没有可讲内容。")
    if not isinstance(points, list) or len(points) == 0:
        raise BriefError("points 必须为非空列表。")

    # ---- 定模板 ----
    tkey = brief.get("template")
    if not tkey or tkey not in T.TEMPLATES:
        # 自动推断：根据 title/素材关键词
        tkey = _infer_template(title, brief.get("material", ""))
        review.append(f"未指定 template，按内容自动推断为「{T.get_template(tkey)['name']}」")
    tpl = T.get_template(tkey)

    # ---- 定风格 ----
    skey = brief.get("style")
    if not skey:
        skey = tpl["default_style"]
        review.append(f"未指定 style，采用模板默认「{skey}」")
    # 风格合法性在 engine 加载时校验

    rotation = tpl["rotation"]
    kicker_default = brief.get("kicker") or tpl["kicker"]
    # 封面/尾屏的中文口号只在这两处出现，不再每屏重复
    cover_caption = brief.get("caption", "")

    # ---- 组装 scenes ----
    scenes = []
    # 片头
    first_fig = {}
    if points and isinstance(points[0].get("figure"), dict):
        first_fig = points[0]["figure"]
    scenes.append({
        "scene_type": "cover",
        "title": title,
        "subtitle": brief.get("subtitle", ""),
        "kicker": kicker_default,
        "caption": cover_caption,
        "caption_en": brief.get("caption_en", ""),
        "figure": first_fig,
    })

    for i, pt in enumerate(points):
        stype = pt.get("type")
        if not stype or stype not in L.LAYOUTS:  # 容错：未知 type 用轮转
            stype = rotation[i % len(rotation)]
        sc = {"scene_type": stype}
        sc["title"] = pt.get("title", f"要点 {i + 1}")
        sc["subtitle"] = pt.get("subtitle", "")
        sc["kicker"] = pt.get("kicker", kicker_default)
        sc["body"] = pt.get("body", "")
        # 关键修复：标准讲解(figure)场景的"逐要素讲解"内容放在 explain 字段，
        # layouts.py 与 audio.py 的 figure 分支都读 scene.get("explain")；
        # 之前漏拷贝 explain，导致画面说明与配音都只剩标题——“闪一下、啥也没讲”。
        sc["explain"] = pt.get("explain", "") or pt.get("body", "")
        sc["body_title"] = pt.get("body_title", "")  # 默认空，避免玻璃卡等场景重复念标题
        sc["keyword"] = pt.get("keyword", sc["title"])
        sc["sub"] = pt.get("sub", "")
        sc["steps"] = pt.get("steps", [])
        sc["nodes"] = pt.get("nodes", [])
        sc["data"] = pt.get("data", {})
        sc["compare"] = pt.get("compare", {})
        sc["quote"] = pt.get("quote", "")
        sc["source"] = pt.get("source", "")
        sc["illustration"] = pt.get("illustration", "")
        sc["figure"] = pt.get("figure", {})
        sc["no_host"] = pt.get("no_host", False)
        # 中间场景：中文 caption 只显式提供的才画，不把它设成英文，否则字幕会中英重复
        sc["caption"] = pt.get("caption", "")
        sc["caption_en"] = pt.get("caption_en", "")
        scenes.append(sc)

    # ---- 标准讲解类：必须有真实原图 + 重点高亮（防止“凭空捏造”）----
    if tkey == "standard_explain":
        for i, pt in enumerate(points):
            fig = pt.get("figure") if isinstance(pt.get("figure"), dict) else {}
            path = fig.get("path", "")
            hls = fig.get("highlights", [])
            if not path:
                msg = (f"标准讲解模板要求每个要点都必须提供 figure.path（截取的标准原图）。"
                       f"points[{i}]「{pt.get('title', '')}」缺少 figure.path。")
                if strict:
                    raise BriefError(msg)
                review.append("⚠ " + msg)
            elif not hls:
                # 条文原文截图（如 6.13.3 / 6.21.1）本身是标准参考，不需要在图上框重点；
                # 仅对"真实图/表"强求高亮。此处降级为警告，不再硬报错。
                review.append(
                    f"ℹ points[{i}]「{pt.get('title', '')}」有图但无高亮框"
                    f"（条文截图允许无高亮，已放行）。")

    # 片尾 cta
    scenes.append({
        "scene_type": "highlight",
        "title": "",   # highlight 用 keyword
        "keyword": brief.get("cta_keyword", "马上行动"),
        "sub": brief.get("cta_sub", cover_caption),
        "kicker": kicker_default,
        "caption": f"{brief.get('cta_keyword', '马上行动')}。{brief.get('cta_sub', cover_caption)}",
        "caption_en": "",   # 纯中文视频：片尾不显示英文，字幕对齐配音
    })

    meta = {
        "template_key": tkey,
        "template_name": tpl["name"],
        "style_key": skey,
        "photos": brief.get("photos", []),
        "host_photo": brief.get("host_photo"),
        "host_photos": brief.get("host_photos", []),
        "host_position": brief.get("host_position", "right"),
        "voice": brief.get("voice"),
        "bg_image": brief.get("bg_image") or (
            _DEFAULT_BG if os.path.exists(_DEFAULT_BG) else None),
        "title": title,
        "n_scenes": len(scenes),
    }
    review.append(f"共生成 {len(scenes)} 个场景（封面+{len(points)}要点+片尾）。")
    return scenes, meta, review


def _infer_template(title, material):
    txt = (title + " " + material).lower()
    if any(k in txt for k in ["培训", "认证", "考证", "招生", "课程", "证书", "ndt", "tuv", "焦虑", "硬门槛", "被卡"]):
        return "training_promo"
    if any(k in txt for k in ["标准", "规范", "gb", "aws", "asme", "焊接", "检验", "探伤", "规程"]):
        return "standard_explain"
    if any(k in txt for k in ["产品", "卖", "购", "优惠", "工具", "实物"]):
        return "product_promo"
    if any(k in txt for k in ["宣传", "品牌", "服务", "公司", "方案", "业务"]):
        return "business_promo"
    return "student_lecture"
