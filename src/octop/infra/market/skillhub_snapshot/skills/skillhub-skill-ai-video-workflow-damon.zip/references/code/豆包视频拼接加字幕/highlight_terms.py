# -*- coding: utf-8 -*-
"""
highlight_terms.py — 专业单词/短语字幕高亮模块（适配「豆包视频加字幕工作流」· ASS 字幕体系）

抽自老管线 ship-video-pipeline：
  · article_to_scenes.py -> _UNIV_HL / _HL_STOP / _leading_ascii / build_en2zh / build_hl_terms
  · build_video.py       -> _norm_word / _match_hl / 高亮语义(金色+放大 / 中文同色不放大)

作用：把「英文专业词放大+变色、对应中文同色(不放大)」做成 ASS 内联标签，
      可直接并入豆包工作流的字幕生成（竖屏/横屏皆可用，不改烧入方式 -vf ass=）。

与老管线一致的可调参数：
  highlight_color = [255, 200, 0]  (亮金；ASS 用 BGR 字节序 -> 00C8FF)
  highlight_scale = 1.75           (专业词放大倍数)
"""
import re

# ============ 与老管线 config.json 对齐 ============
HL_RGB = (255, 200, 0)        # 亮金
HL_SCALE = 1.75               # 放大倍数
HL_COLOR_ASS = "00C8FF"       # (255,200,0) 的 BGR 字节序，ASS 用 \c&H00C8FF&
WHITE_ASS = "FFFFFF"


# ============ 通用专业缩写与硬核短语（任何船海文章都可能用到）============
# 严禁把普通名词(root/face/weld 等)放进来，否则满屏高亮会失去重点。
_UNIV_HL = {
    'wps', 'rfi', 'ndt', 'pqr', 'abs', 'asme', 'aws', 'bpvc', 'ccs', 'ix',
    'single-v butt joint', 'single v butt joint', 'butt joint',
    'fit-up', 'fitup', 'fit-up accuracy', 'fitup accuracy',
    'misalignment', 'mismatch', 'root-face offset / mismatch',
    'root face', 'root opening', 'root pass', 'root-face offset',
    'bevel angle', 'bevel preparation',
    'tack weld', 'tack welding', 'hold point',
    'angle gauge', 'welding procedure specification',
    'back gouging', 'carbon arc gouging',
    'feeler gauge',
    'bevel', 'bevels', 'gouge', 'gouging', 'tack', 'tacks', 'tacked',
    'feeler', 'pass', 'passes',
}
# 即使术语释义被拆分，也绝不让这些普通词单独成为高亮词
_HL_STOP = {'the', 'and', 'for', 'with', 'this', 'that', 'from', 'into', 'per',
            'are', 'was', 'has', 'you', 'have', 'here', 'now', 'good', 'yes',
            'face', 'root', 'point', 'opening', 'weld', 'welding',
            'offset', 'accuracy', 'preparation', 'procedure', 'specification',
            'angle', 'gauge', 'block', 'plate', 'edge', 'seam', 'joint', 'single',
            'degree', 'mm', 'read', 'about'}


def normalize_word(w):
    """归一化英文词：去标点、转小写。用于短语匹配。"""
    return re.sub(r'[^a-z0-9]', '', w.lower())


def match_highlights(norms, hl_set):
    """在归一化英文词序列里做最长短语匹配(最多4词)，返回每词是否命中专业词。"""
    n = len(norms)
    is_hl = [False] * n
    i = 0
    while i < n:
        matched = False
        for L in range(min(4, n - i), 0, -1):
            phrase = ' '.join(norms[i:i + L])
            if phrase in hl_set:
                for k in range(i, i + L):
                    is_hl[k] = True
                i += L
                matched = True
                break
        if not matched:
            i += 1
    return is_hl


def _leading_ascii(s):
    """取术语英文释义里 CJK/中文逗号前的英文短语。"""
    s = (s or '').strip()
    if not s:
        return ''
    m = re.match(r'^([A-Za-z0-9 /()\-.,&]+?)[，,一-鿿]', s)
    if m:
        return m.group(1).strip().rstrip('.,&- ')
    if re.match(r'^[A-Za-z0-9 /()\-.,&]+$', s):
        return s.strip()
    return ''


def build_en2zh(article):
    """构建 英文专业词 -> 中文翻译 对照表，供中文行把对应词也染同色。"""
    m = {}
    for zh, v in (article.get('termNotes') or {}).items():
        en = _leading_ascii(v)
        if en:
            m[en.lower()] = zh
    m.update({
        'bevel': '坡口', 'bevels': '坡口', 'bevel angle': '坡口角度',
        'butt joint': '对接', 'single-v butt joint': '对接', 'single v butt joint': '对接',
        'single-v': '对接', 'single v': '对接',
        'wps': 'WPS', 'rfi': '报检',
        'tack': '定位焊', 'tacks': '定位焊', 'tacked': '定位焊', 'tack welding': '定位焊',
        'feeler': '塞尺', 'feeler gauge': '塞尺',
        'gouge': '气刨', 'gouging': '气刨',
        'misalignment': '错边', 'mismatch': '错边',
        'fit-up': '组对', 'fitup': '组对',
        'pass': '焊道', 'passes': '焊道',
        'angle gauge': '量角器', 'hold point': '停止点',
    })
    for s in ('asme', 'bpvc', 'ix', 'aws', 'ccs', 'abs'):
        m.setdefault(s, s.upper())
    return m


def extract_hl_terms(article):
    """从情景文章 JSON 提炼 (英文专业词短语集合, 中文高亮词列表)。

    返回:
      en_set  : set[str]  小写英文短语(用于英文行放大+变色)
      zh_list : list[str] 对应中文词(最长优先匹配，用于中文行同色不放大)
    """
    s = set()
    for v in (article.get('termNotes') or {}).values():
        p = _leading_ascii(v)
        if p:
            s.add(p.lower())
    for st in (article.get('standards') or []):
        for mm in re.findall(r'[A-Z]{2,}', st):
            s.add(mm.lower())
    s |= _UNIV_HL
    s -= _HL_STOP
    s = {t for t in s if re.search(r'[a-z]', t)}

    en2zh = build_en2zh(article)
    zh_seen = set()
    zh_list = []
    for t in s:
        zh = en2zh.get(t)
        if zh and zh not in zh_seen:
            zh_seen.add(zh)
            zh_list.append(zh)
    return s, zh_list


def _hl_en_segment(tok, hl_flag, base_fs, hl_fs, color=HL_COLOR_ASS, white=WHITE_ASS):
    """对单个英文 token 包 ASS 标签（命中则放大+变色）。"""
    if hl_flag:
        return '{\\c&H%s&\\fs%d&}%s{\\c&H%s&\\fs%d&}' % (color, hl_fs, tok, white, base_fs)
    return tok


def _hl_zh_text(text, zh_list, color=HL_COLOR_ASS, white=WHITE_ASS):
    """中文行：命中的中文专业词染同色(不放大)，其余纯白。最长优先匹配。"""
    if not zh_list:
        return text
    pat = re.compile('|'.join(re.escape(t) for t in sorted(zh_list, key=len, reverse=True)))
    out = []
    pos = 0
    for m in pat.finditer(text):
        if m.start() > pos:
            out.append(text[pos:m.start()])
        out.append('{\\c&H%s&}%s{\\c&H%s&}' % (color, m.group(), white))
        pos = m.end()
    if pos < len(text):
        out.append(text[pos:])
    return ''.join(out)


def apply_ass_highlight(en_text, zh_text, en_set, zh_list,
                        base_fs=40, hl_scale=HL_SCALE,
                        color=HL_COLOR_ASS, white=WHITE_ASS):
    """把一句「英文 + 中文」做成带高亮标签的 ASS 文本，返回 '{en_hl}\\N{zh_hl}'。

    英文主字幕：命中的专业词 放大(hl_scale) + 变色(金色)
    中文副字幕：对应中文词       同色(金色) 但不放大
    """
    hl_fs = int(round(base_fs * hl_scale))
    # 英文：把 \N / 空白都当分隔符保留(既支持跨行专业短语高亮，又保住显示换行)
    parts = re.split(r'(\\N|\s+)', en_text)
    words = [p for p in parts if p and not re.match(r'(\\N|\s+)$', p)]
    norms = [normalize_word(w) for w in words]
    is_hl = match_highlights(norms, en_set)
    out_tokens = []
    wi = 0
    for p in parts:
        if re.match(r'(\\N|\s+)$', p):
            out_tokens.append(p)
        else:
            f = is_hl[wi]
            wi += 1
            out_tokens.append(_hl_en_segment(p, f, base_fs, hl_fs, color, white))
    en_hl = ''.join(out_tokens)
    zh_hl = _hl_zh_text(zh_text, zh_list, color, white)
    return '%s\\N%s' % (en_hl, zh_hl)
