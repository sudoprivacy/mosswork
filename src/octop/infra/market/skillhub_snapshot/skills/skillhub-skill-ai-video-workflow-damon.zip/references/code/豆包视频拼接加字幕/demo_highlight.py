# -*- coding: utf-8 -*-
"""
demo_highlight.py — 用 hvac-07 验证「专业词高亮模块」

保留原字幕时间轴(TTS 真实位置对齐)，只把每句 en/cn 文本用 highlight_terms 重新包裹
ASS 高亮标签(英文放大+变色 / 中文同色不放大)，生成 hvac_07_highlight.ass 并烧演示片。
不修改任何现有工作流文件，仅产出 *highlight* 新文件。
"""
import json, re, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from highlight_terms import extract_hl_terms, apply_ass_highlight

ART = "D:/微信小程序/情景文章库/hvac/hvac-07.json"
SRC_VIDEO = "../hvac/hvac_07_对话_英语_竖屏.mp4"
ASS_IN = os.path.join(HERE, "hvac_07_test.ass")
ASS_OUT = os.path.join(HERE, "hvac_07_highlight.ass")
DEMO_OUT = os.path.join(HERE, "hvac_07_高亮演示.mp4")
BASE_FS = 40  # 豆包竖屏 ASS 字号(与 gen_vertical_sentences.py 一致)
FF = "C:/Users/Damon/.workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"

art = json.load(open(ART, encoding='utf-8'))
en_set, zh_list = extract_hl_terms(art)
print("== 英文专业词短语(%d) ==" % len(en_set))
print("  ", sorted(en_set))
print("== 中文高亮词(%d) ==" % len(zh_list))
print("  ", zh_list)

lines = open(ASS_IN, encoding='utf-8').read().split('\n')
out = []
n_total = 0
n_hl = 0
samples = []
for ln in lines:
    if ln.startswith('Dialogue:'):
        rest = ln[len('Dialogue:'):].lstrip()
        fields = rest.split(',', 9)          # 10 字段，第10为 Text
        text = fields[9]
        if '\\N' in text:
            en, cn = text.rsplit('\\N', 1)   # 从右切一次：en 可能含内部折行\N，cn 是中文行
        else:
            en, cn = text, ''
        hl_text = apply_ass_highlight(en, cn, en_set, zh_list, BASE_FS)
        fields[9] = hl_text
        out.append('Dialogue: ' + ','.join(fields))
        n_total += 1
        if '\\c' in hl_text:
            n_hl += 1
            if len(samples) < 4:
                samples.append(hl_text)
    else:
        out.append(ln)

open(ASS_OUT, 'w', encoding='utf-8').write('\n'.join(out))
print("\n== 字幕统计 ==")
print("  总句数: %d | 含高亮句数: %d" % (n_total, n_hl))
print("\n== 高亮示例(前4句) ==")
for s in samples:
    print("  " + s)
print("\n== ASS 已生成: %s ==" % ASS_OUT)
print("== 烧演示片请在 UTF-8 终端执行(规避 Windows GBK 中文路径)：==")
print('   cd "%s" && "%s" -y -i "%s" -vf "ass=%s" -c:a copy -y "%s"'
      % (HERE, FF, SRC_VIDEO, os.path.basename(ASS_OUT), os.path.basename(DEMO_OUT)))
