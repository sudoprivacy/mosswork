# -*- coding: utf-8 -*-
"""配音模块（本地可跑 = edge-tts 免费占位；克隆走 GPU 服务器）。

设计：
  - 默认 edge-tts 占位（零成本，不需要服务器），多音色轮询防限流。
  - 音色/性别可切换：VOICE_PROFILES 预设男女/冷暖多种；也支持直接传 voice id。
  - 去 AI 味（de-AI）：开启 natural 后走 edge-tts 原生参数（实测不膨胀时长）——
      ① 文本预处理（中英文间补空格、全大写缩写按字母拆分，减少机械断句/过长静音）；
      ② 原生 rate/pitch/volume（自然语速 + 轻微上扬 + 中等音量）加一点温度，
         不过度（过度反而更机械）；SSML 包裹会膨胀 5–6× 时长，已弃用。
  - 预留 clone_voice() 接口：部署 CosyVoice2/XTTS 后传入参考音即可克隆（需 GPU）。
"""
import os
import re
import asyncio
import subprocess
import shutil
import time

import edge_tts


def get_ffmpeg():
    """动态定位 ffmpeg，换电脑/换用户也能跑，不依赖写死路径。

    优先级：
      1) imageio-ffmpeg 自带的静态二进制（首次调用会自动下载到本地缓存目录）；
      2) 系统 PATH 里已安装的 ffmpeg。
    都不存在则抛清晰错误，提示跑 install.bat / install.sh。
    """
    try:
        import imageio_ffmpeg
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        if exe and os.path.exists(exe):
            return exe
    except Exception:
        pass
    sys_ff = shutil.which("ffmpeg")
    if sys_ff:
        return sys_ff
    raise RuntimeError(
        "未找到 ffmpeg，且 imageio-ffmpeg 自动下载失败。\n"
        "请运行 install.bat（Windows）或 install.sh（Linux/Mac）安装依赖，\n"
        "或手动把 ffmpeg.exe 放到系统 PATH 后重试。"
    )

# 中文音色轮询兜底（防止单音色被限流返回空音频）
CN_VOICES = [
    "zh-CN-YunjianNeural",
    "zh-CN-XiaoxiaoNeural",
    "zh-CN-YunxiNeural",
    "zh-CN-XiaoyiNeural",
]

# 音色/性别预设（用户可随要求切换）
VOICE_PROFILES = {
    "female_warm": "zh-CN-XiaoxiaoNeural",   # 女·自然温暖（默认，最有温度）
    "female_calm": "zh-CN-XiaoruiNeural",    # 女·成熟专业
    "female_lyric": "zh-CN-XiaohanNeural",   # 女·抒情柔和
    "male_steady": "zh-CN-YunyangNeural",    # 男·沉稳播报
    "male_young": "zh-CN-YunxiNeural",       # 男·年轻活泼
    "male_narrator": "zh-CN-YunjianNeural",  # 男·叙事感
}


def resolve_voice(voice):
    """voice 可以是预设名（female_warm 等）或原始 voice id（含 Neural）。"""
    if not voice:
        return VOICE_PROFILES["female_warm"]
    if voice in VOICE_PROFILES:
        return VOICE_PROFILES[voice]
    if "Neural" in voice:
        return voice
    # 容错：当作预设名未命中则回退默认
    return VOICE_PROFILES["female_warm"]


def _duration(path):
    r = subprocess.run([get_ffmpeg(), "-i", path], capture_output=True, encoding="utf-8", errors="ignore")
    m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", r.stderr)
    if not m:
        return 4.0
    h, m_, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
    return h * 3600 + m_ * 60 + s


# ---------------- 去 AI 味：文本预处理 + SSML ----------------
def _preprocess(text):
    """让中英文衔接更自然、缩写可读：
      - 中英文相邻处补一个空格（明确边界，减少粘连/过长静音）；
      - 2~4 位全大写缩写按字母拆分（API -> A P I），避免逐位生硬读或整词误读。
    """
    # 中 -> 英 补空格
    text = re.sub(r'([\u4e00-\u9fff])([A-Za-z0-9])', r'\1 \2', text)
    # 英 -> 中 补空格
    text = re.sub(r'([A-Za-z0-9])([\u4e00-\u9fff])', r'\1 \2', text)
    # 全大写缩写按字母拆分（长度 2~4）
    text = re.sub(r'(?<![A-Z])\b([A-Z]{2,4})\b(?![A-Z])',
                  lambda m: " ".join(m.group(1)), text)
    return text


# 去 AI 味原生参数（中性偏暖、不夸张——既加温度，又不像 SSML 那样膨胀 5–6× 时长）
# 注意：edge-tts 的 rate/pitch/volume 只接受百分比/Hz 字符串，不接受 "medium" 这类 SSML 关键字，
#       否则会抛 ValueError 导致整段落到静音兜底。volume 用 None（即默认）最稳。
NATURAL_RATE = "+0%"       # 保持自然语速（真人日常即此速度，过快反而机械）
NATURAL_PITCH = "+3Hz"     # 轻微上扬，添一点温度
NATURAL_VOLUME = None      # 默认音量（edge-tts 不接受 "medium" 关键字）


async def _synth(content, voice, out_path, rate=None, pitch=None, volume=None):
    """edge-tts 原生参数合成：rate/pitch/volume 不会像 SSML 那样膨胀时长。

    仅当参数非空时才透传，避免把 None 喂给 edge-tts（None 会被当成非法值导致合成失败）。
    """
    kwargs = {}
    if rate is not None:
        kwargs["rate"] = rate
    if pitch is not None:
        kwargs["pitch"] = pitch
    if volume is not None:
        kwargs["volume"] = volume
    comm = edge_tts.Communicate(content, voice, **kwargs)
    await comm.save(out_path)


def tts_edge(text, out_path, voice="zh-CN-XiaoxiaoNeural", natural=True, max_retry=4):
    """edge-tts 生成。natural=True 走去 AI 味原生参数（不膨胀时长）；返回 (path, duration)。"""
    text = (text or "").strip()
    if not text:
        return _silence(out_path, 0.3), 0.3
    v = resolve_voice(voice)
    # 去 AI 味①：文本预处理（中英文补空格、缩写按字母拆分，缓解机械断句/过长静音）
    content = _preprocess(text) if natural else text
    # 去 AI 味②：原生 rate/pitch/volume（实测不膨胀；SSML 会膨胀 5–6×）
    rate = NATURAL_RATE if natural else None
    pitch = NATURAL_PITCH if natural else None
    volume = NATURAL_VOLUME if natural else None
    voices = [v]  # 统一音色：重试不换音，避免成片忽男忽女
    last_err = ""
    for attempt in range(max_retry):
        vv = v
        try:
            if attempt > 0:
                time.sleep(1.2)  # 限流退避，避免立刻重试失败
            asyncio.run(_synth(content, vv, out_path, rate=rate, pitch=pitch, volume=volume))
            if os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
                return out_path, _duration(out_path)
        except Exception as e:
            last_err = str(e)
            if os.path.exists(out_path):
                try:
                    os.remove(out_path)
                except Exception:
                    pass
    return _silence(out_path, 3.0), 3.0


def _silence(out_path, secs):
    """生成静音 wav 占位。"""
    wav = out_path
    if not wav.endswith(".wav"):
        wav = out_path + ".wav"
    cmd = [get_ffmpeg(), "-y", "-f", "lavfi", "-i", f"anullsrc=r=16000:cl=mono",
           "-t", str(secs), wav]
    subprocess.run(cmd, capture_output=True, encoding="utf-8")
    return wav


def clone_voice(text, ref_wav, out_path, backend="cosyvoice"):
    """克隆音色（需 GPU 后端）。本地无 GPU 时调用会抛异常提示去服务器。

    集成位置：在 deploy_voice.sh 部署好 CosyVoice2/XTTS 后，
    由 engine 在渲染前调用本函数替换 edge-tts 占位。
    """
    raise RuntimeError(
        "clone_voice 需要 GPU 后端（CosyVoice2/XTTS）。\n"
        "请先在 RTX 3090 等服务器执行 deploy_voice.sh 部署，"
        "再调用 run_with_clone.py，本机 WorkBuddy 沙箱无 GPU 无法克隆。"
    )


def scene_narration(scene):
    """按场景类型把屏幕上真正出现的内容念出来，而不是只念标题。"""
    stype = scene.get("scene_type", "")
    title = scene.get("title", "")

    # 封面：标题 + 副标题
    if stype == "cover":
        parts = [title]
        if scene.get("subtitle"):
            parts.append(scene["subtitle"])
        return "。".join(p for p in parts if p)

    # 步骤：标题 + 每一步（兼容字符串列表与 {t,d} 字典两种写法）
    if stype == "steps":
        items = scene.get("steps", [])
        lines = [title]
        for it in items[:4]:
            if isinstance(it, dict):
                t = it.get("t", "")
                d = it.get("d", "")
                if t or d:
                    lines.append(f"{t}，{d}".rstrip("，"))
            else:
                s = str(it).strip()
                if s:
                    lines.append(s)
        return "。".join(lines)

    # 分屏：标题 + 正文
    if stype == "split":
        return "。".join(p for p in [title, scene.get("body", "")] if p)

    # 数据：标题 + 数值。兼容 {label,value,desc} 与 {"指标":"值", ...} 两种写法
    if stype == "data":
        d = scene.get("data", {})
        parts = [title]
        if d.get("label"):
            parts.append(f"{d['label']}为{d.get('value', '')}")
            if d.get("desc"):
                parts.append(d["desc"])
        else:
            for k, v in list(d.items())[:4]:
                parts.append(f"{k}为{v}")
        return "。".join(parts)

    # 时间线：标题 + 每个节点
    if stype == "timeline":
        nodes = scene.get("nodes", [])
        lines = [title]
        for nd in nodes[:4]:
            tt = nd.get("t", "")
            dd = nd.get("d", "")
            if tt or dd:
                lines.append(f"{tt}：{dd}".rstrip("："))
        return "。".join(lines)

    # 玻璃卡：标题 + 小标题 + 正文
    if stype == "glass":
        lines = [title]
        if scene.get("body_title"):
            lines.append(scene["body_title"])
        if scene.get("body"):
            lines.append(scene["body"])
        return "。".join(lines)

    # 重点/尾屏：先念顶部标题（画面标题与配音呼应），再念大字 keyword + sub
    if stype == "highlight":
        parts = []
        if scene.get("title"):
            parts.append(scene["title"])
        if scene.get("keyword"):
            parts.append(scene["keyword"])
        if scene.get("sub"):
            parts.append(scene["sub"])
        return "。".join(parts)

    # 引述
    if stype == "quote":
        parts = []
        if scene.get("quote"):
            parts.append(scene["quote"])
        if scene.get("source"):
            parts.append(f"来源：{scene['source']}")
        return "。".join(parts)

    # 对比
    if stype == "compare":
        c = scene.get("compare", {})
        parts = [title]
        if c.get("left_title"):
            parts.append(f"{c['left_title']}：{', '.join(c.get('left_items', [])[:4])}")
        if c.get("right_title"):
            parts.append(f"{c['right_title']}：{', '.join(c.get('right_items', [])[:4])}")
        return "。".join(parts)

    # 标准原图：念标题 + 图下方的说明文字（必须讲标准内容）
    if stype == "figure":
        parts = [title]
        if scene.get("explain"):
            parts.append(scene["explain"])
        else:
            # 兼容旧 brief：没有 explain 时才回退到高亮标签
            fig = scene.get("figure", {})
            for hl in fig.get("highlights", [])[:6]:
                lab = hl.get("label", "").strip()
                if lab:
                    parts.append(lab)
        return "。".join(parts)

    # 兜底
    parts = []
    for k in ("title", "subtitle", "body", "quote", "keyword", "sub"):
        v = scene.get(k)
        if v:
            parts.append(str(v))
    return "。".join(p for p in parts if p)
