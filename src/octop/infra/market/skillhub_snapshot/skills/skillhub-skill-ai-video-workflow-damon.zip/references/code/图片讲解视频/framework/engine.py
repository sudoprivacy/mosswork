# -*- coding: utf-8 -*-
"""引擎：审题 -> 执行 -> 质检 -> 输出。

主入口 render(brief, out_path) 串联：
  1. 审题：content.plan() 把 Brief 结构化
  2. 执行：按场景用 Canvas + layouts 绘制最终帧
  3. 质检：每场景严格校验（超屏/重叠/图压字），不过直接报错并指出元素
  4. 输出：入场+转场动画、edge-tts 配音（可去 AI 味）、ffmpeg 合成 mp4、产出质检报告

升版能力（只增不改，不影响旧成片）：
  - orientation：portrait(1080x1920) / landscape(1920x1080)，自动按方向重排版式与背景。
  - voice：可切换音色/性别（female_warm 等预设或原始 voice id）。
  - natural：去 AI 味配音（edge-tts 原生 rate/pitch/volume 参数，自然断句/温度，不膨胀时长）。
  - host_position：主播位可选 right/left/center（突出用户指定内容）。
"""
import os
import subprocess
from PIL import Image, ImageDraw

from . import styles as S
from . import backgrounds as B
from . import layouts as L
from . import content as C
from . import templates as T
from . import audio as A
from .canvas import Canvas
from .validator import validate, Report

FPS = 30
ENTER = 0.35      # 入场淡入时长（秒）
TRANS = 0.45      # 场景间交叉溶解时长（秒）


def _load_image(path):
    if not path or not os.path.exists(path):
        return None
    try:
        return Image.open(path).convert("RGBA")
    except Exception:
        return None


def _blend(a, b, t):
    """t=0 全 a，t=1 全 b。"""
    t = max(0.0, min(1.0, t))
    return Image.blend(a, b, t)


def _host_box_for(position, canvas):
    """按 host_position 计算主播位包围盒（right/left/center）。"""
    m = canvas.metrics()
    base = m["host_box"]
    if not position or position == "right":
        return base
    if position == "left":
        x0, y0, x1, y1 = base
        w = x1 - x0
        return (40, y0, 40 + w, y1) if canvas.portrait else (60, y0, 60 + w, y1)
    if position == "center":
        return (290, 360, 790, 1380) if canvas.portrait else (610, 180, 1310, 860)
    return base


def _voice_title_check(idx, scene, narration, strict):
    """话画一致性内容闸：配音必须开口呼应画面主题（含 scene title）。"""
    title = (scene.get("title") or "").strip()
    narr = (narration or "").strip()
    if not narr:
        msg = f"场景 {idx}（{scene.get('scene_type')}）配音文本为空——无法出片（话画一致性闸）"
        if strict:
            raise RuntimeError(msg)
        return
    if len(title) >= 3:
        # 取标题前半段作为主题词（如"参考线：整组符号的基线" -> "参考线"）
        core = (title.replace("，", "").replace(",", "").replace("。", ""))
        topic = ""
        for sep in ["：", ":"]:
            if sep in core:
                topic = core.split(sep)[0].replace(" ", "")
                break
        if not topic:
            topic = core.replace(" ", "")[:4]
        if topic and topic[:4] not in narr.replace(" ", ""):
            msg = (f"场景 {idx}（{scene.get('scene_type')}）配音未呼应画面标题"
                   f"「{title}」，话画不一致——已拦截（话画一致性闸）")
            if strict:
                raise RuntimeError(msg)


def render(brief, out_path, fps=FPS, workdir=None, strict=True,
           orientation="portrait", voice=None, natural=True, host_position="right"):
    """完整渲染。返回 dict: {mp4, scenes, meta, review, qc_report, qc_passed, orientation}。"""
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    if workdir is None:
        workdir = os.path.join(os.path.dirname(out_path), "_frames")
    os.makedirs(workdir, exist_ok=True)

    # 方向决定画布尺寸
    orientation = (orientation or "portrait").lower()
    if orientation == "landscape":
        W, H = 1920, 1080
    else:
        W, H = 1080, 1920
        orientation = "portrait"

    # ---- 1. 审题 + 执行准备 ----
    scenes, meta, review = C.plan(brief, strict=strict)
    style = S.get_style(meta["style_key"])
    if meta["style_key"] not in S.STYLES:
        review.append(f"⚠ 风格「{meta['style_key']}」不存在，已回退 business。")

    # 资源
    photos_paths = meta["photos"] or []
    photos = []
    for p in photos_paths[:2]:
        im = _load_image(p)
        if im:
            photos.append((im, None))
    bg_img = _load_image(meta["bg_image"]) if meta.get("bg_image") else None

    # 主播照片（你给的这些照片是用来做主播/博主的，不是当内容硬塞中间）
    raw_host = meta.get("host_photos") or []
    if not raw_host and meta.get("host_photo"):
        raw_host = [meta["host_photo"]]
    host_paths = []
    for h in raw_host[:4]:  # 最多 4 张轮播
        if isinstance(h, (list, tuple)):
            host_paths.extend(h[:4])
        else:
            host_paths.append(h)
    host_imgs = []
    for p in host_paths[:4]:
        im = _load_image(p)
        if im:
            host_imgs.append(im)
    if not host_imgs and photos:
        # 无主播图但有内容图时，拿第一张当主播（兼容旧用法）
        host_imgs = [photos[0][0]]

    # 音色 / 去 AI 味
    voice = voice or meta.get("voice")
    voice = A.resolve_voice(voice)

    # ---- 4a. 先生成配音，拿到真实时长（驱动画面节奏，保证话随画走、不抢拍）----
    TAIL = 0.6  # 配音结束后的尾拍（> TRANS，避免转场时上一句还没念完）
    audio_paths = []
    durations = []        # 帧节奏用：max(2.2, 真实)
    real_durations = []   # 成片真实音频时长（红线 §3.2 核对基准，未夹下限）
    for i, sc in enumerate(scenes):
        txt = A.scene_narration(sc)
        ap = os.path.join(workdir, f"aud_{i:02d}.mp3")
        _, real_dur = A.tts_edge(txt, ap, voice=voice, natural=natural)
        dur = max(2.2, real_dur)      # 仅设下限（极短留白），不再夹上限
        _voice_title_check(i, sc, txt, strict)
        audio_paths.append(ap)
        durations.append(dur)
        real_durations.append(real_dur)

    # ---- 2+3. 执行绘制 + 与配音对齐 + 严格质检 ----
    scene_canvases = []
    qc_reports = []
    for i, sc in enumerate(scenes):
        canvas = Canvas(style, W, H)
        bg = B.generate_bg(style, W, H, bg_image=bg_img)
        canvas.set_background(bg)
        canvas._seed = i
        canvas._appear_base = ENTER if i == 0 else (TRANS + 0.05)
        host = host_imgs[i % len(host_imgs)] if host_imgs else None
        host_box = _host_box_for(host_position, canvas) if host else None
        L.draw_scene(sc, canvas, style, photos, host=host, t=1.0, dur=3.0,
                     host_box=host_box)
        rep = canvas.validate(strict=True)
        qc_reports.append((i, sc.get("scene_type"), rep))
        if strict and not rep.passed:
            msg = (f"场景 {i}（{sc.get('scene_type')}）质检未通过：\n" + rep.text())
            raise RuntimeError(msg)
        lead = ENTER if i == 0 else (TRANS + 0.05)
        canvas.sync_to_audio(durations[i], lead=lead, tail=TAIL)
        scene_canvases.append(canvas)

    # ---- 4b. 帧时间线（元素入场 + 持有 + 无闪烁转场交叉溶解）----
    # 转场改为「头部交叉溶解」：每个非首场景的前 TRANS 帧与上一场混合淡入，
    # 不再跳过头部帧 —— 视频总长 = 各场配音之和，杜绝 -shortest 截断片尾音频。
    black = Image.new("RGB", (W, H), (0, 0, 0))
    ENTER_F = max(1, int(round(ENTER * fps)))
    TRANS_F = max(1, int(round(TRANS * fps)))
    settled_imgs = [cv._settled.convert("RGB") for cv in scene_canvases]
    settle_ts = [cv._settle_t for cv in scene_canvases]
    n_total = 0
    frame_files = []
    for i, canvas in enumerate(scene_canvases):
        n_i = int(round(durations[i] * fps))
        for f in range(n_i):                 # 不跳过头部：视频时长对齐音频，避免片尾被截
            lt = f / fps
            if i == 0 and f < ENTER_F:
                # 开场从封面背景出，不要从纯黑淡入（避免开场闪黑一下）
                fr = settled_imgs[0] if lt >= settle_ts[0] else canvas.compose(lt).convert("RGB")
            elif i > 0 and f < TRANS_F:
                # 与上一场交叉溶解进入（头部过渡，覆盖原尾过渡，不丢帧）
                tf = (f + 1) / TRANS_F
                tf = max(0.0, min(1.0, tf))
                prev_img = settled_imgs[i - 1]
                cur_local = f / fps
                cur_img = settled_imgs[i] if cur_local >= settle_ts[i] else canvas.compose(cur_local).convert("RGB")
                fr = _blend(prev_img, cur_img, tf)
            else:
                fr = settled_imgs[i] if lt >= settle_ts[i] else canvas.compose(lt).convert("RGB")
            fp = os.path.join(workdir, f"frame_{n_total:06d}.png")
            fr.save(fp, compress_level=3)
            frame_files.append(fp)
            n_total += 1

    # ---- 4c. 合并音频 ----
    concat_txt = os.path.join(workdir, "concat_audio.txt")
    with open(concat_txt, "w", encoding="utf-8") as f:
        for ap in audio_paths:
            f.write(f"file '{os.path.abspath(ap)}'\n")
    mixed_wav = os.path.join(workdir, "mixed.wav")
    subprocess.run([A.get_ffmpeg(), "-y", "-f", "concat", "-safe", "0", "-i", concat_txt,
                    "-c:a", "pcm_s16le", mixed_wav],
                   capture_output=True, encoding="utf-8")

    # ---- 4d. 合成 mp4 ----
    cmd = [A.get_ffmpeg(), "-y",
           "-framerate", str(fps),
           "-i", os.path.join(workdir, "frame_%06d.png"),
           "-i", mixed_wav,
           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19",
           "-c:a", "aac", "-b:a", "160k",
           "-shortest", out_path]
    r = subprocess.run(cmd, capture_output=True, encoding="utf-8", errors="ignore")
    if r.returncode != 0:
        raise RuntimeError("ffmpeg 合成失败:\n" + r.stderr[-1500:])

    # ---- 输出质检报告 ----
    qc_report = _build_qc_report(scenes, qc_reports, meta, orientation, voice, natural)
    base_name = os.path.splitext(os.path.basename(out_path))[0]
    qc_path = os.path.join(os.path.dirname(out_path), f"{base_name}_qc_report.txt")
    with open(qc_path, "w", encoding="utf-8") as f:
        f.write(qc_report)

    qc_passed = all(rep.passed for _, _, rep in qc_reports)
    # 成片真实时长由 ffmpeg -shortest 决定 = 音频总时长（Σ各场景配音真实时长）。
    # 注意：n_total/fps 是「未截断的帧数估算」，不能作为「成片时长=Σ配音」的核对基准；
    # 真正该核对的是音频总时长（红线 §3.2）。durations 里存的是 max(2.2, 真实)，
    # 当各场景配音均 >2.2s 时即等于 Σ真实音频时长，与 -shortest 成品一致。
    audio_duration = round(sum(real_durations), 3)  # Σ真实 TTS 时长 = 成片真实音频时长
    return {
        "mp4": out_path,
        "qc_report_path": qc_path,
        "qc_passed": qc_passed,
        "scenes": scenes,
        "meta": meta,
        "review": review,
        "orientation": orientation,
        "voice": voice,
        "natural": natural,
        "n_frames": n_total,
        "duration": n_total / fps,
        "audio_duration": round(audio_duration, 3),
    }


def _build_qc_report(scenes, qc_reports, meta, orientation, voice, natural):
    lines = []
    lines.append("=" * 60)
    lines.append("配照片讲解 PPT 视频 —— 质检报告（QC）")
    lines.append("=" * 60)
    lines.append(f"方向：{orientation}    音色：{voice}    去AI味：{'开' if natural else '关'}")
    lines.append(f"模板：{meta['template_name']}（{meta['template_key']}）")
    lines.append(f"风格：{meta['style_key']}")
    lines.append(f"场景数：{meta['n_scenes']}")
    lines.append("-" * 60)
    all_pass = True
    for i, stype, rep in qc_reports:
        status = "PASS" if rep.passed else "FAIL"
        if not rep.passed:
            all_pass = False
        lines.append(f"[{status}] 场景 {i:02d}  {stype}  | {rep.text()}")
    lines.append("-" * 60)
    lines.append("总判定：" + ("✅ 全部通过，无超屏 / 无重叠 / 无图压字" if all_pass
                              else "❌ 存在错误，详见上方 FAIL"))
    lines.append("=" * 60)
    return "\n".join(lines)


# 便捷：列出可用风格/模板（供 CLI / 前端）
def available():
    return {
        "styles": S.list_styles(),
        "templates": T.list_templates(),
    }
