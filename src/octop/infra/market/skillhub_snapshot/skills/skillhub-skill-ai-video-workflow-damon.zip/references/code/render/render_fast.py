# -*- coding: utf-8 -*-
# 加速版渲染器（优化 / 不重构）。
# 完整复用原脚本 render_table_walkthrough_l_pos_en.py 的全部 draw_* 绘制函数，
# 画面像素级不变；只在「调度」上加加速：
#   1) 多核并行：每个场景一个独立子进程（画帧 + 编码），多场景同时跑
#   2) 编码档 -preset veryfast（保留 -crf 18，画质肉眼不变；原脚本漏设=默认最慢 medium）
#   3) 不走原始管道（rawvideo 管道在多进程下会死锁），每场景写本地 PNG 后由 ffmpeg 读文件编码
# 原脚本保持不动。本文件默认输出 *_fast.mp4，验证无误后再用 --deploy 覆盖正式文件。
import os, sys, json, time, argparse, subprocess
import multiprocessing as mp
from PIL import Image, ImageDraw

RENDER_DIR = os.path.dirname(os.path.abspath(__file__))
if RENDER_DIR not in sys.path:
    sys.path.insert(0, RENDER_DIR)

import render_table_walkthrough_l_pos_en as R   # 原脚本：只读取其函数/常数，不修改

PRESET = "veryfast"          # 加速编码档；crf 维持 18
CACHE_SEG_DIR = os.path.join(RENDER_DIR, "cache_seg_fast")
FINAL_NAME = "aws_table610_walkthrough_pos_en.mp4"
FINAL_OUTPUT_DIR = r"D:\微信小程序\标准视频库"   # 用户指定：成品统一放此处


def _render_scene(task):
    """子进程：渲染单个场景的全部帧并编码为 seg。无管道，不死锁。"""
    i, sc, mp3, dur, is_intro, is_summary = task
    R.load_assets()
    R.build_bg()
    FPS = R.FPS
    W, H = R.W, R.H
    row = sc if sc.get("key") else None
    n = int(dur * FPS) + 1
    scene_dir = os.path.join(CACHE_SEG_DIR, f"scene_{i:02d}")
    os.makedirs(scene_dir, exist_ok=True)
    card_in, card_out = 0.35, 0.45
    for f in range(n):
        t = f / FPS
        slide = 0.0
        if row:
            if t < card_in:
                slide = t / card_in
            elif t > dur - card_out:
                slide = max(0.0, (dur - t) / card_out)
            else:
                slide = 1.0
        im = Image.new("RGBA", (W, H), R.BG + (255,))
        d = ImageDraw.Draw(im)
        im.paste(R._BG, (0, 0))
        if is_intro:
            R.draw_intro(im, d, t)
        elif is_summary:
            R.draw_top(d, sc)
            R.draw_table(im, d, sc.get("key"), t)
            R.draw_summary_burst(im, d, t)
        else:
            R.draw_top(d, sc)
            R.draw_table(im, d, sc.get("key"), t)
            if row:
                R.draw_card(im, row, slide, t)
                R.draw_position_diagram(im, d, row["code"], t)
        R.draw_subtitle(d, sc.get("caption_en", ""), sc["caption"])
        im.convert("RGB").save(os.path.join(scene_dir, f"frame_{f:06d}.png"))
    seg = os.path.join(CACHE_SEG_DIR, f"seg_{i:02d}.mp4")
    cmd = [
        R.FFMPEG, "-y",
        "-framerate", str(FPS),
        "-i", os.path.join(scene_dir, "frame_%06d.png"),
        "-i", mp3,
        "-frames:v", str(n),
        "-c:v", "libx264", "-preset", PRESET, "-pix_fmt", "yuv420p", "-crf", "18",
        "-c:a", "aac", "-b:a", "128k",
        "-shortest", seg
    ]
    subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8", errors="ignore")
    return seg


def _concat(segs, out_path):
    import shutil
    tmp = r"C:\wb_tmp_concat_fast"
    if os.path.exists(tmp):
        shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp, exist_ok=True)
    tmp_segs = []
    for mp4 in segs:
        dst = os.path.join(tmp, os.path.basename(mp4))
        shutil.copy2(mp4, dst)
        tmp_segs.append(dst)
    concat_file = os.path.join(tmp, "concat.txt")
    with open(concat_file, "w", encoding="utf-8") as cf:
        for mp4 in tmp_segs:
            cf.write(f"file '{mp4.replace(chr(92), '/')}'\n")
    cmd = [
        R.FFMPEG, "-y",
        "-f", "concat", "-safe", "0", "-i", concat_file,
        "-c:v", "libx264", "-preset", PRESET, "-pix_fmt", "yuv420p", "-crf", "18",
        "-c:a", "aac", "-b:a", "160k",
        "-movflags", "+faststart",
        out_path
    ]
    subprocess.run(cmd, check=True, capture_output=True, encoding="utf-8", errors="ignore")
    shutil.rmtree(tmp, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None, help="输出路径；默认 <原名>_fast.mp4（验证用）")
    ap.add_argument("--deploy", action="store_true", help="验证通过后覆盖正式文件")
    ap.add_argument("--workers", type=int, default=min(mp.cpu_count() or 4, 8))
    args = ap.parse_args()

    R.load_assets()
    R.build_bg()
    print("computing durations (cached audio)...")
    durations, audio_paths = [], []
    for i, sc in enumerate(R.SCENES):
        mp3 = R.get_audio(i, sc["spoken"])
        dur = R.audio_duration(mp3) + 0.6
        durations.append(dur)
        audio_paths.append(mp3)
        print(f"  scene {i}: {dur:.2f}s")

    n_sc = len(R.SCENES)
    tasks = []
    for i, sc in enumerate(R.SCENES):
        tasks.append((i, sc, audio_paths[i], durations[i],
                      i == 0, i == n_sc - 1))

    os.makedirs(CACHE_SEG_DIR, exist_ok=True)
    t0 = time.time()
    print(f"rendering {n_sc} scenes on {args.workers} workers (preset={PRESET})...")
    if args.workers <= 1:
        segs = [_render_scene(t) for t in tasks]
    else:
        with mp.Pool(args.workers) as pool:
            segs = pool.map(_render_scene, tasks)
    print(f"scenes done in {time.time()-t0:.1f}s")

    out_path = args.out or os.path.join(FINAL_OUTPUT_DIR, FINAL_NAME)
    print("concatenating ->", out_path)
    _concat(segs, out_path)
    print("DONE:", out_path, f"({time.time()-t0:.1f}s total)")

    if args.deploy:
        # 成品已直接输出到 FINAL_OUTPUT_DIR（用户指定的成品库），无需再复制。
        print("成品已落在成品库:", out_path)


if __name__ == "__main__":
    main()
