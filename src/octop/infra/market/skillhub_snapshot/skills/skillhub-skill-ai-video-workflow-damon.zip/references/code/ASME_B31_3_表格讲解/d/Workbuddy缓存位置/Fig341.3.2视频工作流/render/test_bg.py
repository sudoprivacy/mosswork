# -*- coding: utf-8 -*-
import sys, traceback
sys.path.insert(0, r"D:\Workbuddy缓存位置\Fig341.3.2视频工作流\render")
import render_asme_b31_3_table341_3_2 as M
from PIL import Image, ImageDraw

try:
    M.load_assets()
    print("assets loaded")
    M.build_bg()
    print("bg built", M._BG.size, M._BG.mode)
    M._BG.save(r"D:\Workbuddy缓存位置\Fig341.3.2视频工作流\render\test_bg.png")
    print("bg saved")
    # scene 0 frame at t=1.0
    im = Image.new("RGBA", (M.W, M.H), M.BG + (255,))
    d = ImageDraw.Draw(im)
    im.paste(M._BG, (0, 0))
    M.draw_intro(im, d, 1.0)
    M.draw_subtitle(d, "ASME B31.3", "测试")
    im.convert("RGB").save(r"D:\Workbuddy缓存位置\Fig341.3.2视频工作流\render\test_frame0.png")
    print("frame0 saved")
    # scene 1 (Crack) frame
    sc = M.SCENES[1]
    im2 = Image.new("RGBA", (M.W, M.H), M.BG + (255,))
    d2 = ImageDraw.Draw(im2)
    im2.paste(M._BG, (0, 0))
    M.draw_top(d2, sc)
    M.draw_table(im2, d2, sc.get("key"), 1.0)
    M.draw_card(im2, sc, 1.0, 1.0)
    M.draw_defect_summary(im2, d2, sc, 1.0)
    im2.convert("RGB").save(r"D:\Workbuddy缓存位置\Fig341.3.2视频工作流\render\test_frame1.png")
    print("frame1 saved")
except Exception:
    traceback.print_exc()
