# -*- coding: utf-8 -*-
"""风格化背景生成。

- 未提供题材背景图：纯程序化背景（渐变/网格/水墨/网点/扫描线）。
- 提供题材背景图：先以该图做暗化底（亮度/饱和度/对比度 + 深蓝蒙版 + 底部渐变压暗），
  再按当前风格叠网格/网点/扫描线/水墨等装饰。
"""
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
import math

W, H = 1080, 1920


def _vgrad(w, h, top, bottom):
    base = Image.new("RGB", (w, h), top)
    d = ImageDraw.Draw(base)
    for y in range(h):
        t = y / h
        r = int(top[0] + (bottom[0] - top[0]) * t)
        g = int(top[1] + (bottom[1] - top[1]) * t)
        b = int(top[2] + (bottom[2] - top[2]) * t)
        d.line([(0, y), (w, y)], fill=(r, g, b))
    return base


def _cover_crop(im, w, h):
    """等比 cover 裁剪，绝不拉伸：填满画布并居中裁剪溢出部分。"""
    im = im.convert("RGB")
    iw, ih = im.size
    if iw <= 0 or ih <= 0:
        return im.resize((w, h))
    s = max(w / iw, h / ih)
    nw, nh = int(round(iw * s)), int(round(ih * s))
    im = im.resize((nw, nh), Image.LANCZOS)
    left = (nw - w) // 2
    top = (nh - h) // 2
    im = im.crop((left, top, left + w, top + h))
    return im


def _vignette(img, strength=0.5):
    """中心明亮、四周向深蓝压暗，突出图片主体（人物/模块）。"""
    w, h = img.size
    mask = Image.new("L", (w, h), 0)
    md = ImageDraw.Draw(mask)
    md.ellipse([-int(w * 0.10), -int(h * 0.05), int(w * 1.10), int(h * 1.05)], fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(200))
    dark = Image.blend(img, Image.new("RGB", img.size, (8, 12, 22)), strength)
    return Image.composite(img, dark, mask)


def _photo_base(bg_image, w=W, h=H):
    """把用户题材图处理成可用的深色背景底（cover 裁剪 + 聚焦 + 风格化）。"""
    im = _cover_crop(bg_image, w, h)
    im = ImageEnhance.Brightness(im).enhance(0.55)
    im = ImageEnhance.Color(im).enhance(0.72)
    im = ImageEnhance.Contrast(im).enhance(1.22)
    # 深蓝/深色调蒙版，压暗保证白字可读
    overlay = Image.new("RGB", (w, h), (10, 16, 30))
    im = Image.blend(im, overlay, 0.45)
    # 中心聚焦：四周向深蓝压暗，突出主体
    im = _vignette(im.convert("RGB"), 0.5)
    # 仅底部渐变压暗，保护字幕区
    grad = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grad)
    for i in range(h):
        a = int(150 * max(0, (i - h * 0.62) / (h * 0.38)))
        if a > 0:
            gd.line([(0, i), (w, i)], fill=(0, 0, 0, min(a, 200)))
    im = Image.alpha_composite(im.convert("RGBA"), grad).convert("RGB")
    return im


def _radial_glow(img, cx, cy, radius, color, strength=0.5):
    glow = Image.new("RGB", img.size, (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([cx - radius, cy - radius, cx + radius, cy + radius],
               fill=color)
    glow = glow.filter(ImageFilter.GaussianBlur(radius / 2))
    return Image.blend(img, Image.blend(img, glow, strength), 0.0)


def generate_bg(style, w=W, h=H, bg_image=None):
    s = style
    p = s.palette
    bg, bg2 = p["bg"], p.get("bg2", p["bg"])

    # 先确定底色：有题材图优先用题材图，否则用风格渐变色
    if bg_image is not None:
        img = _photo_base(bg_image, w, h)
    else:
        img = _vgrad(w, h, bg, bg2)

    # 按风格叠装饰
    if s.bg_type == "gradient":
        img = _radial_glow(img, w // 2, int(h * 0.32), w * 0.9,
                           p["accent"], strength=0.10)
    elif s.bg_type == "grid":
        d = ImageDraw.Draw(img)
        step = 60
        lc = p["line"]
        for x in range(0, w, step):
            d.line([(x, 0), (x, h)], fill=(*lc, 60), width=1)
        for y in range(0, h, step):
            d.line([(0, y), (w, y)], fill=(*lc, 60), width=1)
        img = _radial_glow(img, w // 2, h // 2, w, p["accent"], strength=0.06)
    elif s.bg_type == "ink":
        d = ImageDraw.Draw(img, "RGBA")
        for i in range(6):
            rx = int(w * (0.2 + 0.6 * ((i * 37) % 100) / 100))
            ry = int(h * (0.2 + 0.6 * ((i * 53) % 100) / 100))
            rr = 120 + (i * 40) % 200
            d.ellipse([rx - rr, ry - rr, rx + rr, ry + rr],
                      fill=(*p["line"], 14))
    elif s.bg_type == "dots":
        d = ImageDraw.Draw(img, "RGBA")
        step = 38
        dc = p["line"]
        for y in range(step // 2, h, step):
            for x in range(step // 2, w, step):
                d.ellipse([x - 3, y - 3, x + 3, y + 3], fill=(*dc, 40))
    elif s.bg_type == "scanline":
        d = ImageDraw.Draw(img, "RGBA")
        for y in range(0, h, 4):
            d.line([(0, y), (w, y)], fill=(255, 255, 255, 10), width=1)
        img = _radial_glow(img, w // 2, int(h * 0.4), w * 0.8,
                           p["accent"], strength=0.12)
    elif s.bg_type == "photo":
        # photo 风格不做额外装饰，保持底图电影感
        pass
    return img
