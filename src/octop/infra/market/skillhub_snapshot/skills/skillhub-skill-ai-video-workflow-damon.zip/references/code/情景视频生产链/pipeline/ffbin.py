#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ffmpeg 定位(多处兜底), 供各步骤共用。"""
import glob, shutil


def find_ffmpeg():
    p = shutil.which('ffmpeg')
    if p:
        return p
    pats = [
        r"C:/Users/*/AppData/Local/Microsoft/WinGet/Packages/**/ffmpeg.exe",
        r"C:/Program Files/ffmpeg/bin/ffmpeg.exe",
        r"C:/ffmpeg/bin/ffmpeg.exe",
    ]
    for pat in pats:
        hits = glob.glob(pat, recursive=True)
        if hits:
            return hits[0]
    try:                      # 兜底: PyPI 静态二进制
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None
