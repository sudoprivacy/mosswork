# 船海专业情景视频生产链

把「船海/海工专家知识网络」(`changhai_expert.html` 的 `genScenario` 引擎) 生成的**专业情景文章**，或用户提供的 **PPT + 脚本**，一键做成带**配音 + 中英硬字幕 + 画面**的短视频。

支持两种模式：
- **旁白讲解片** (`--mode narration`): 单一中文/英文旁白，中文主字幕 + 英文副字幕（或反过来）
- **双人对话片** (`--mode dialogue`): A/B 两个角色分别配音，屏幕显示彩色角色名，A 靠左、B 靠右、旁白居中，英文口播 + 中英双语字幕

字幕采用 **逐句推进**：每镜画面固定不动，该镜口播按句子切分，一句英语（口播）单独显示（英上中下）并朗读，读完这一句→这句字幕消失→下一句带翻译出现，直到该镜所有句子读完才切下一镜。

16:9 默认启用 **电影遮幅黑边（letterbox）**：PPT/画面缩小居中，上下留出黑边，字幕完全放在下方黑边里，不再遮挡画面主体；字体用白色粗字 + 黑色描边/阴影，清晰醒目。需要关闭黑边、回到旧版“字幕直接叠画面+底托”模式时，加 `--no-letterbox`。行业参考：单语字幕约占画面 5%，双语舒适 ≤15%；黑边模式下字幕宜占黑边高度的 85% 以内。

## 目录结构
```
ship-video-pipeline/
├── run.py                    # 单入口: 输入 domain/key 出 mp4
├── pipeline/
│   ├── config.json           # 路径/音色/画幅/存放目录配置
│   ├── list_scenarios.js     # 列出引擎里全部可拍情景
│   ├── make_scenes.js        # 引擎出文案 + 自动拆分镜
│   ├── apply_zh.js           # 把 translate_needed.json 的中文回填进 scenes.json
│   ├── shotlist.py           # 生成 图片清单.md (提前提示每镜要什么图)
│   ├── make_placeholder_images.py  # 生成本地占位图(仅用于流水线 mechanic 验证)
│   ├── ingest_images.py      # 【我投喂的图】优先接入
│   ├── reuse_assets.py       # 素材库复用, 省下生图消耗
│   ├── ppt_to_images.py      # PPT→图片(每页 slide_XX.png)
│   ├── make_ppt_scenes.py    # 按 PPT 脚本生成 scenes.json
│   ├── subtitle_render.py     # PIL 字幕渲染器(描边/投影/专业词高亮/多风格)
│   ├── domain_terms.json       # 专家技能导出的专业词候选(高亮参考)
│   └── build_video.py          # 配音(edge-tts) + ffmpeg 合成(字幕 PNG overlay)
├── assets/
│   ├── inbox/                # 【投喂口】要用自己的图就丢这里
│   │   ├── <工程名>/          #   给指定工程用
│   │   └── _used/            #   用过的自动归档, 防串片
│   └── library/              # 可复用工业/安全素材图
├── projects/                 # 每个工程一个目录
│   └── hse_lifting_stop/
│       ├── script.md         # 引擎原文(中英双语 + 标准 + 免责)
│       ├── scenes.json       # 分镜表(说话人/台词/tts/图像/文件)
│       ├── 图片清单.md        # 每镜画面要求 + 英文提示词(给图前先看这份)
│       ├── translate_needed.json  # 对话片待补中文字幕(仅 dialogue 模式)
│       ├── fed_images.json   # 本片用了哪些投喂图
│       ├── images/           # 分镜图
│       ├── audio/            # 配音文件
│       └── *.mp4             # 成片
```

**成片统一存放**: `D:/微信小程序/情景视频存放处/`  
文件名后缀规则: `<工程>[_对话][_英语][_竖屏/_方屏].mp4`

## 一、看有哪些情景可拍
```bash
node pipeline/list_scenarios.js
node pipeline/list_scenarios.js hse   # 只看 HSE 领域
```

## 二、一条命令出片

```bash
# 默认横屏 16:9, 旁白中文
python run.py hse lifting_stop

# 竖屏 9:16
python run.py hse lifting_stop --vertical

# 双人对话 + 英语口播 + 中英双语字幕
python run.py hse lifting_stop --mode dialogue --lang en

# 只出分镜和图片清单, 先不给图也不合成(提前看需要哪些图)
python run.py hse lifting_stop --mode dialogue --lang en --plan

# 用我自己投喂的图
python run.py hse lifting_stop --images "D:/我的现场照片"

# 换女声 / 不复用素材库
python run.py hse lifting_stop --voice zh-CN-XiaoxiaoNeural
python run.py hse lifting_stop --no-reuse
```

`--aspect` 也认中文：`横屏` / `竖屏` / `方`。

`run.py` 六步:
1. `make_scenes.js` —— 调引擎生成中英双语文案, 拆成分镜
2. `shotlist.py` —— 生成 `图片清单.md`, 提前提示每镜画面
3. `ingest_images.py` —— **接入我投喂的图**(有就优先用)
4. `reuse_assets.py` —— 从 `assets/library/` 复用匹配的图
5. 缺图/缺翻译检查 —— 若还有空缺, 停下并输出清单
6. `build_video.py` —— edge-tts 免费配音 + ffmpeg 合成

## 三、先出图片清单, 再去生图(推荐)

对话片或生图前, 先用 `--plan` 出 `图片清单.md`, 看清楚每镜需要什么画面、人物长什么样、文件名怎么命名:

```bash
python run.py hse lifting_stop --mode dialogue --lang en --plan
```

产出:
- `projects/<工程>/图片清单.md` —— 含人物设定表 + 逐镜画面要求 + 可直接粘贴的生图英文提示词
- `projects/<工程>/translate_needed.json` —— 对话片待补中文字幕(英语口播时, 中文是副字幕)

补齐后重跑(跳过拆镜):
```bash
python run.py hse lifting_stop --mode dialogue --lang en --skip-scenes
```

## 四、我自己给图
把图丢进 `assets/inbox/<工程名>/`(没有就丢 `assets/inbox/`), 或用 `--images` 指目录。

| 文件名 | 用到第几镜 |
|---|---|
| `3_吊装.jpg` | 第 3 镜(数字开头 = 指定镜号) |
| `现场A.png` | 按文件名排序, 依次填还没图的镜 |

- jpg/png/webp/bmp/tif/avif 都行, 自动转 png
- 给少了: 剩下的自动走素材库/生图, 不报错
- 给多了: 多的忽略并提示
- 用过的图自动搬到 `assets/inbox/_used/<工程名>/`, 免得下条片串图(`--keep-inbox` 关掉)
- 默认不覆盖工程里已有的图, 要覆盖加 `--overwrite-images`

先看看会怎么分配, 不落地:
```bash
python pipeline/ingest_images.py --project hse_lifting_stop --dry-run
```

## 五、对话片的中文字幕

`--mode dialogue --lang en` 时, 口播是英文, 但屏幕上要同时出现中文翻译(双语字幕)。这些中文不会自动翻译, 需要填写:

```bash
# 1. 打开 translate_needed.json, 把每条 "zh": "" 填上中文
# 2. 回填
node pipeline/apply_zh.js --project hse_lifting_stop
# 3. 再跑合成
python run.py hse lifting_stop --mode dialogue --lang en --skip-scenes
```

`run.py` 会在第 5 步自动检查: 如果还有空的 `zh`, 会停下提示你填, 填完再跑。

## 六、生图(唯一消耗点)

`run.py` 停在缺图时会打印每镜的 `image_prompt`, 或看 `图片清单.md` 更直观。两条路二选一: 自己补图丢进 inbox, 或在 WorkBuddy 里调图像生成能力补齐后放入 `projects/<工程>/images/`, 然后:

```bash
python run.py hse lifting_stop --skip-scenes --vertical
```

也支持逐步手动:
```bash
node pipeline/make_scenes.js <domain> <key> offshore --project myname --mode dialogue --lang en
python pipeline/shotlist.py --project myname
python pipeline/ingest_images.py --project myname
python pipeline/reuse_assets.py --project myname
# 按 图片清单.md / images_needed.json 生图后, 填好 translate_needed.json:
node pipeline/apply_zh.js --project myname
python pipeline/build_video.py --project myname --aspect 9:16 --lang en
```

## 七、占位图验证(quota 紧张或 mechanic 验证时用)

如果只是想验证字幕/配音/对话标签是否正常, 不想消耗生图额度, 可以用占位图:

```bash
python pipeline/make_placeholder_images.py --project <工程>
python pipeline/build_video.py --project <工程> --lang en
```

成品会带 "预览占位 PREVIEW" 水印, 明显不是成片, 但 pipeline  mechanics 全通。

## 八、成本说明
| 环节 | 是否消耗 | 说明 |
|---|---|---|
| 文案+翻译 | **否** | 本地跑 `changhai_expert.html` 规则引擎 |
| 分镜 | 否 | 本地解析步骤 |
| 图片清单 | 否 | 本地文本输出 |
| 投喂图接入 | 否 | 本地拷贝/转格式; **自己给图越多越省** |
| **生图** | **是** | 唯一消耗点; 只补投喂+复用之后的缺口 |
| 配音 | 否 | edge-tts 微软免费在线音色, 零成本 |
| ffmpeg 合成 | 否 | 本地 CPU |

## 九、复用素材库(省钱核心)
把每次用过的通用场景图丢进 `assets/library/` 并在 `manifest.json` 里打 tag, 新片会优先匹配复用。

## 十、音色/画幅/背景音乐
在 `pipeline/config.json` 里改默认; 或每次命令行覆盖:

```bash
python run.py hse lifting_stop --vertical --voice zh-CN-XiaoxiaoNeural --bgm assets/bgm.mp3
```

`config.json` 音色键:
- `voice_zh` / `voice_en`: 旁白默认音色
- `narrator_voice_en` / `narrator_voice_zh`: 剧情/旁白解说音色(对话片里旁白/介绍剧情的人，必须与 A/B 角色音色不同)
- `dialogue_voice_a_en` / `dialogue_voice_b_en`: 对话片 A/B 英文音色
- `dialogue_voice_a_zh` / `dialogue_voice_b_zh`: 对话片 A/B 中文音色
- `color_a` / `color_b` / `color_narrator`: 角色标签颜色

| 画幅 | 分辨率 | 成片名 | 适用 |
|---|---|---|---|
| `16:9`(默认) | 1920×1080 | `<工程>.mp4` | 讲解/存档/横屏平台 |
| `9:16` | 1080×1920 | `<工程>_竖屏.mp4` | 抖音/快手/视频号 |
| `1:1` | 1080×1080 | `<工程>_方屏.mp4` | 朋友圈/部分信息流 |

## 十一、PPT→视频

如果你有一个 `.pptx` 和一段英中对照脚本（每页一句英文、一句中文），可以按 PPT 页生成视频：

```bash
# 1. PPT 导出为图片
python pipeline/ppt_to_images.py --ppt "D:/我的月报.pptx" --project monthly_demo

# 2. 写脚本 projects/monthly_demo/script.txt
#    格式：EN 英文句子
#          ZH 中文句子
#          空行分隔每一页

# 3. 生成 scenes.json
python pipeline/make_ppt_scenes.py --project monthly_demo --script projects/monthly_demo/script.txt --lang en --title "我的月报"

# 4. 合成(支持 --aspect 9:16/--vertical 等)
python pipeline/build_video.py --project monthly_demo --lang en
```

PPT 视频同样使用英语口播 + 中英双语字幕，成片复制到 `D:/微信小程序/情景视频存放处/`。

## 十二、字幕渲染方式（PIL 渲染 + ffmpeg overlay）
字幕不再用 ffmpeg `drawtext`，改由 `pipeline/subtitle_render.py` 用 **Pillow 渲染成透明 PNG**，再 `overlay` 到画面上。好处：
- **统一描边 + 投影**：黑边/浅底背景上都清晰（原来 drawtext 只能给整段一个色，遇到浅背景会糊）；
- **同一句内专业词可单独放大/变色**（drawtext 做不到同行混排不同字号）；
- **多套字体/配色风格**一键切换（见下一节）；
- 不再有 `%` 转义问题（PIL 直接按字符串画，`75%` 原样显示，无需 `\%`）。

> 注意：改成 PIL 后，`build_video.py` 对 `%` 不再做转义；若日后又换回 drawtext 风格，需重新加转义。

## 十三、逐句推进字幕（核心节奏）

默认不再把一整段口播+翻译一次性铺满整个镜长。改为：

- **画面固定**：一镜内画面不切，连续缓慢 zoom 平滑推进；
- **按句切分**：口播文本按 `.!?`（英文）或 `。！？`（中文）切句，每句单独用 edge-tts 合成音频；
- **逐句显示**：每句只显示「一句英语（上）+ 对应一句汉语（下）」，读完这一句→字幕消失→下一句带翻译出现；
- **句间配对**：口播句与翻译句按句序配对。若句数不等（常见：英文 2 句、中文 1 句），翻译多则把多余句并到最后一句口播下，口播多则末句翻译沿用最后一条，尽量不丢信息；
- **节奏自然**：仅每镜首句淡入、末句淡出，句中不闪，背景图始终可见。

想回到「整段一次性显示」的旧节奏？把 `build_video.py` 里 `split_sentences()` 返回的整段当作一句即可（或临时把每镜口播写成单句）。

## 十四、生图逻辑/解剖学护栏
所有生图提示词都会在末尾追加约束，禁止出现三只手、漂浮肢体、重复肢体、缺失肢体、脸部/手指严重畸形。喂图时也请避免这类图。

## 十五、豆包配音替换
`build_video.py` 里的 `tts()` 目前调用 edge-tts。如要豆包音色, 把该函数改成调用火山引擎/豆包 TTS API, 其余逻辑不变。注意你自己的免费额度。

## 十六、字幕风格预设与专业词高亮

### 1) 字体/配色风格（`--style`）
`pipeline/config.json` 的 `styles` 里预设了多套风格，合成时用 `--style <名字>` 切换，无需改代码：

| 名字 | 字体 | 主色 / 副色 | 高亮色 | 描边 | 专业词放大 |
|---|---|---|---|---|---|
| `news`（默认） | 黑体 | 白 / 金黄 | 蓝 `#40C4FF` | 6 | ×1.25 |
| `cinema` | 黑体 | 白 / 浅灰 | 黄 `#FFEB3B` | 7 | ×1.20 |
| `yahei` | 雅黑 | 白 / 金黄 | 青 `#18FFFF` | 6 | ×1.25 |
| `kai` | 楷体 | 米白 / 金黄 | 青 `#80DEEA` | 5 | ×1.25 |
| `song` | 宋体 | 白 / 米黄 | 绿 `#69F0AE` | 5 | ×1.25 |
| `fang` | 仿宋 | 白 / 橙 | 紫 `#B388FF` | 5 | ×1.25 |

想自己调色/换字体：直接改 `config.json` 里对应风格的字段（`pri_color`/`sec_color`/`highlight_color`/`outline_color`/`outline_width`/`shadow`/`highlight_scale`/`font`/`font_zh`），或新增一套。字体用 `C:/Windows/Fonts/` 下的 `.ttf`/`.ttc` 绝对路径。

```bash
# 用楷体国风风格出片
python pipeline/build_video.py --project xxx --lang en --style kai
```

### 2) 专业词高亮（放大 + 变色）
同一句内命中的专业词会用 `highlight_color` 上色，并整体放大 `highlight_scale` 倍（如 1.25×），突出但不抢主体。命中词来源（自动合并，空则不高亮）：
- 该镜 `scenes.json` 里的 `keywords`（整镜词）；
- 该镜 `sentence_keywords[k]`（第 k 句专属词，list）；
- 工程目录下的 `keywords.json`（`["词1","词2"]` 或 `{"en":[...],"zh":[...]}`）；
- 命令行 `--keywords 文件.json/词.txt` 额外追加。

```bash
# 关掉高亮（如月报类不需要专业词突出）
python pipeline/build_video.py --project monthly_report_july --lang en --no-highlight

# 额外追加高亮词
python pipeline/build_video.py --project hse_lifting_stop --lang en --keywords my_terms.txt
```

> 专业词清单：专家技能 `ship-hai-domain-expert-ima` 已把每个情景文章的专业词沉淀进文章本身（`generateScenario` 产出里有 `keywords`/`sentence_keywords`）。做专业情景视频时，只要用该情景的 `scenes.json` 直接合成，专业词会自动高亮；`domain_terms.json` 只是给不确定时查候选用，不必手动维护。

