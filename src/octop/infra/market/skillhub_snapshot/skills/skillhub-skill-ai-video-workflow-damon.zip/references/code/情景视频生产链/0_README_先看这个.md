# 情景视频生产链 — 先看这个

> ⚠️ **动手前先看**：[避坑总纲](../1_避坑总纲_血泪清单.md)（历史翻车 + 硬闸门）
> ✅ **交付前必跑**：`python ../check.py <成片.mp4>` ｜ 勾选表：[交付前自检清单](../2_交付前自检清单.md)

> 把船海/海工专家知识网络 `changhai_expert.html` 生成的中英双语情景文章，**或**用户给的 PPT + 脚本，
> 自动做成带配音、中英硬字幕、分镜图的短视频。
> 旁白/对话、中/英文口播、横/竖/方屏全支持。
> **唯一消耗点是生图**（豆包/即梦），其余 0 积分、纯本地。

## 一句话用法

```bash
# 1. 列出可选场景
node pipeline/list_scenarios.js

# 2. 先出图片清单（推荐）
python run.py hse lifting_stop --mode dialogue --lang en --plan

# 3. 一条龙出片
python run.py hse lifting_stop --mode dialogue --lang en
```

成片同时复制到 `D:\微信小程序\情景视频存放处\`。

## 工作区结构

```
情景视频生产链/
├── run.py                          # ★ 单入口
├── pipeline/
│   ├── config.json                 # 引擎路径/音色/字体/输出目录
│   ├── domain_terms.json           # 领域术语表
│   ├── list_scenarios.js           # 列场景
│   ├── make_scenes.js              # 引擎出文案+自动拆镜
│   ├── apply_zh.js                 # 回填 translate_needed.json 中文
│   ├── article_to_scenes.py
│   ├── shotlist.py                 # 生成图片清单.md
│   ├── make_placeholder_images.py  # 占位图（仅 mechanic 验证）
│   ├── ingest_images.py            # 【投喂图接入】用户给的图优先落位
│   ├── reuse_assets.py             # 素材库复用
│   ├── ffbin.py                    # ffmpeg 定位
│   ├── ppt_to_images.py            # PPT→slide_XX.png
│   ├── make_ppt_scenes.py          # 按 PPT 脚本生成 scenes.json
│   ├── build_video.py              # 配音+ffmpeg 合成 mp4
│   ├── subtitle_render.py          # 字幕烧录
│   ├── measure_bar.py              # 字幕占屏自检
│   └── stitch_ending.py
├── assets/
│   ├── inbox/                      # 投喂口
│   └── library/                    # 可复用素材
├── projects/<domain>_<key>/        # 每视频一工程
│   ├── script.md
│   ├── scenes.json
│   ├── 图片清单.md
│   ├── translate_needed.json       # 对话片必填
│   ├── fed_images.json
│   ├── images/
│   ├── audio/
│   └── *.mp4
├── _verify/                        # 验证帧
├── _verify_lb/                     # 验证帧（letterbox 版）
└── README.md                       # 完整方法论
```

## 核心特性

- **模式**：narration 旁白 / dialogue 双人对话
- **语言**：zh / en 口播
- **画幅**：横 16:9 / 竖 9:16 / 方 1:1
- **图片来源**：① 用户给图（最高优先）② 素材库复用 ③ 生图（唯一消耗点）
- **字幕**：中英双语、水平+垂直居中、半透明圆角卡片、无电影遮幅
- **占屏硬标准**：单语 ≤5% 画面高，双语 ≤15%（measure_bar.py 自检）
- **风格**：news/cinema/yahei/kai/song/fang 六种可切
- **音色**：A/B 角色独立 + 旁白独立，3 音色不混

## 已知坑

- **字幕含 `%` 必转义为 `\%`**（ffmpeg drawtext 把它当展开符）
- **ffmpeg concat 中文路径** 已用 ASCII 临时目录
- **ImageGen 并行调用时同秒完成**，输出文件名可能不按预期——生成后立刻重命名为 `scene_XX.png`
- **对话片 (`--mode dialogue --lang en`)**：必须填 `translate_needed.json` 的中文，`apply_zh.js` 回填
- 改任何字号/行距后必跑 `measure_bar.py`

## 客户交付检查

- [ ] `python run.py <domain> <key> --plan` 已跑,图片清单已审
- [ ] 用户投喂图全部接入（`fed_images.json` 记录）
- [ ] 缺图已补（生图/素材库）
- [ ] 对话片 `translate_needed.json` 全填了中文
- [ ] `measure_bar.py` 通过（最大≤15%,平均≤13%）
- [ ] 字幕无 `%` 截断
- [ ] 成片复制到 `D:\微信小程序\情景视频存放处\`
