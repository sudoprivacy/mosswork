# -*- coding: utf-8 -*-
"""硬审核系统（用户反复强调必须固定）。

三道闸：
  1) 文本超屏 —— 任何文字不得超出安全区（横向 SAFE_L..SAFE_R，纵向按 kind 限定）。
  2) 文本互叠 —— 任意两处文本不得重叠（杜绝"字体重叠"）。
  3) 图压字   —— 照片不得压住文字（警告级，避免"照片贴得生硬/挡字"）。

strict=True 时直接抛 LayoutError 并指出具体元素，渲染时卡死报错，绝不带病出片。
非 strict 模式返回 Report（passed / issues），用于产出最终质检报告。
"""
from typing import List
from .registry import ElementRegistry, TEXT_KINDS, KIND_BOUNDS

W_DEFAULT, H_DEFAULT = 1080, 1920
SAFE_T_DEFAULT, SAFE_B_DEFAULT = 190, 1620
SAFE_L_DEFAULT, SAFE_R_DEFAULT = 40, 1040

# 重叠判定容差（像素）—— 完全贴合的边不算重叠，留 2px 余量
OVERLAP_TOL = 2


class LayoutError(Exception):
    """渲染期硬错误：某场景出现超屏/重叠，必须指出具体元素。"""
    pass


class Issue:
    def __init__(self, level, kind, msg, a=None, b=None):
        self.level = level          # "error" | "warn"
        self.kind = kind            # "overflow_x"|"overflow_y"|"text_overlap"|"photo_over_text"
        self.msg = msg
        self.a = a
        self.b = b

    def __str__(self):
        return f"[{self.level.upper()}] {self.kind}: {self.msg}"


class Report:
    def __init__(self):
        self.issues: List[Issue] = []

    def add(self, issue: Issue):
        self.issues.append(issue)

    @property
    def errors(self):
        return [i for i in self.issues if i.level == "error"]

    @property
    def warnings(self):
        return [i for i in self.issues if i.level == "warn"]

    @property
    def passed(self):
        return len(self.errors) == 0

    def text(self):
        if not self.issues:
            return "PASS：无超屏 / 无重叠 / 无图压字"
        lines = []
        for i in self.issues:
            extra = ""
            if i.a and i.b:
                extra = f"  <{i.a[2]} ∩ {i.b[2]}>"
            elif i.a:
                extra = f"  <{i.a[2]}>"
            lines.append(f"  {i}")
        return "\n".join(lines)


def _boxes_overlap(a, b, tol=OVERLAP_TOL):
    ax0, ay0, ax1, ay1 = a[0]
    bx0, by0, bx1, by1 = b[0]
    return not (ax1 <= bx0 + tol or bx1 <= ax0 + tol or ay1 <= by0 + tol or by1 <= ay0 + tol)


def validate(reg: ElementRegistry, W=W_DEFAULT, H=H_DEFAULT,
             safe_t=SAFE_T_DEFAULT, safe_b=SAFE_B_DEFAULT,
             safe_l=SAFE_L_DEFAULT, safe_r=SAFE_R_DEFAULT,
             strict=True, kind_bounds=None) -> Report:
    """对登记的元素做三道闸审核。strict=True 时遇 error 直接抛 LayoutError。

    kind_bounds：各文本类的纵向安全区（按方向不同）。默认沿用竖屏常量。
    """
    rep = Report()
    texts = reg.texts()
    photos = reg.photos()
    if kind_bounds is None:
        kind_bounds = KIND_BOUNDS

    # ---- 闸 1：文本超屏 ----
    for box, kind, label in texts:
        x0, y0, x1, y1 = box
        # 横向
        if x0 < safe_l or x1 > safe_r:
            rep.add(Issue("error", "overflow_x",
                          f"{kind}/{label} 横向超屏 x=[{x0},{x1}] 安全区[{safe_l},{safe_r}]",
                          (box, kind, label)))
        # 纵向（按 kind 限定的上下界）
        bounds = kind_bounds.get(kind, (safe_t, safe_b))
        bt, bb = bounds
        if y0 < bt or y1 > bb:
            rep.add(Issue("error", "overflow_y",
                          f"{kind}/{label} 纵向超屏 y=[{y0},{y1}] 该类别安全区[{bt},{bb}]",
                          (box, kind, label)))

    # ---- 闸 2：文本互叠 ----
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            a = texts[i]
            b = texts[j]
            if _boxes_overlap(a, b):
                rep.add(Issue("error", "text_overlap",
                              f"{a[1]}/{a[2]} 与 {b[1]}/{b[2]} 文字重叠", a, b))

    # ---- 闸 3：图压字（警告级）----
    for ph in photos:
        for tx in texts:
            if _boxes_overlap(ph, tx):
                rep.add(Issue("warn", "photo_over_text",
                              f"照片 {ph[2]} 压住文字 {tx[1]}/{tx[2]}", ph, tx))

    if strict and rep.errors:
        msg = "质检未通过（strict）：\n" + rep.text()
        raise LayoutError(msg)

    return rep
