# -*- coding: utf-8 -*-
"""
Layout guard — static overlap checker for the B31.3 Table 341.3.2 video.

Run this BEFORE committing a render. It draws the intro / summary / one defect frame
and asserts that no two UI element bounding boxes overlap. If it fails, fix the layout
before burning CPU time on a full render.

Usage:
    C:/Users/Damon/AppData/Local/Programs/Python/Python312/python.exe render/layout_guard.py
"""
import os, sys, json
from PIL import Image, ImageDraw, ImageFont

ROOT = r"D:\Workbuddy缓存位置\Fig341.3.2视频工作流"
RENDER_ROOT = os.path.join(ROOT, "render")
sys.path.insert(0, RENDER_ROOT)

import render_asme_b31_3_table341_3_2 as R

W, H = R.W, R.H


def bbox_overlap(a, b):
    return not (a[2] <= b[0] or a[0] >= b[2] or a[3] <= b[1] or a[1] >= b[3])


def get_text_bbox(d, xy, text, font, anchor="mm"):
    bb = d.textbbox(xy, text, font=font, anchor=anchor)
    return bb


def build_frame(scene_index, t):
    """Render a single frame for the given scene at time t (seconds)."""
    R.load_assets()
    R.build_bg()
    scene = R.SCENES[scene_index]
    im = R._BG.copy().convert("RGBA")
    d = ImageDraw.Draw(im)
    R.draw_top(d, scene)
    R.draw_table(im, d, scene.get("key"), t)
    # Only non-intro/non-summary scenes show the bottom card.
    card_slide = 0.0 if scene_index in (0, len(R.SCENES) - 1) else 1.0
    R.draw_card(im, scene, card_slide, t)
    if scene_index == 0:
        R.draw_intro(im, d, t)
    elif scene_index == len(R.SCENES) - 1:
        R.draw_summary_burst(im, d, t)
    else:
        R.draw_burst(im, d, scene, t, scene.get("dur", 5.0))
        R.draw_defect_summary(im, d, scene, t)
    R.draw_subtitle(d, scene.get("caption_en", ""), scene.get("caption", ""))
    return im


def collect_elements(scene_index, t):
    """Return a list of (label, bbox) for all major UI blocks in one frame."""
    im = build_frame(scene_index, t)
    d = ImageDraw.Draw(im)
    elems = []

    # Table area
    tx, ty, tw, th = R.table_layout()
    elems.append(("table", (tx, ty, tx + tw, ty + th)))

    # Subtitle area
    elems.append(("subtitle", (0, R.SUB_Y, W, R.SUB_Y + R.SUB_H)))

    # Top title block
    elems.append(("top_title", (0, 0, W, 140)))

    # Card (if present)
    if scene_index not in (0, len(R.SCENES) - 1):
        elems.append(("card", (R.CARD_X, R.CARD_Y, R.CARD_X + R.CARD_W, R.CARD_Y + R.CARD_H)))
        elems.append(("badge", (1700 - 180, 320 - 100, 1700 + 180, 320 + 100)))
        elems.append(("diag_panel", (R.DIAG_X, R.DIAG_Y, R.DIAG_X + R.DIAG_W, R.DIAG_Y + R.DIAG_H)))

    # Intro tag grid + right points
    if scene_index == 0:
        for k in range(10):
            cx = R.TABLE_X + 155 + (k % 5) * 360
            cy = 700 + (k // 5) * 116
            elems.append((f"intro_tag_{k}", (cx - 145, cy - 58, cx + 145, cy + 58)))
        for k in range(3):
            cy = 260 + k * 92
            elems.append((f"intro_point_{k}", (1700 - 170, cy - 40, 1700 + 170, cy + 40)))

    # Summary tag grid + right points + bottom pill
    if scene_index == len(R.SCENES) - 1:
        for k in range(10):
            cx = 230 + (k % 5) * 360
            cy = 720 + (k // 5) * 125
            elems.append((f"summary_tag_{k}", (cx - 145, cy - 58, cx + 145, cy + 58)))
        for k in range(3):
            cy = 250 + k * 92
            elems.append((f"summary_point_{k}", (1700 - 170, cy - 40, 1700 + 170, cy + 40)))
        elems.append(("summary_pill", (W // 2 - 380, 630 - 32, W // 2 + 380, 630 + 32)))

    return im, elems


def check_scene(scene_index, t, out_dir):
    im, elems = collect_elements(scene_index, t)
    overlaps = []
    for i in range(len(elems)):
        for j in range(i + 1, len(elems)):
            la, ba = elems[i]
            lb, bb = elems[j]
            if bbox_overlap(ba, bb):
                # Ignore table/subtitle adjacency that is intentional.
                if {la, lb} == {"table", "subtitle"}:
                    continue
                # badge is a brief pop-in animation on top of the diag panel;
                # their overlap is intentional and short-lived.
                if {la, lb} == {"badge", "diag_panel"}:
                    continue
                overlaps.append((la, lb, ba, bb))

    debug = im.copy()
    dd = ImageDraw.Draw(debug)
    for label, bbox in elems:
        dd.rectangle(bbox, outline=(0, 255, 255, 255), width=1)
        dd.text((bbox[0] + 4, bbox[1] + 2), label, fill=(0, 255, 255, 255))
    for la, lb, ba, bb in overlaps:
        ix = (max(ba[0], bb[0]), max(ba[1], bb[1]), min(ba[2], bb[2]), min(ba[3], bb[3]))
        dd.rectangle(ix, fill=(255, 0, 0, 120))
        print(f"  OVERLAP: {la} {ba}  vs  {lb} {bb}")

    os.makedirs(out_dir, exist_ok=True)
    debug.save(os.path.join(out_dir, f"scene_{scene_index:02d}_t{int(t*100)}_debug.png"))
    return len(overlaps) == 0


def text_y_range(txt, name, size, y):
    f = R.get_font(name, size)
    d = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    bb = d.textbbox((0, 0), txt, font=f)
    return y + bb[1], y + bb[3]


def check_internal_spacing():
    """Static assertion: text INSIDE each box must not overlap.
    Uses the exact coordinates/fonts hardcoded in the render script."""
    problems = []

    # ---- Card (build_card) local coordinates ----
    # tag(cn_b26,y40)  tag_en(en_b22,y96)  title_en(en_b30,y40)  title(cn_b36,y78)
    # gold bar 158..210   body rows 226/266/306 (cn22 ~h22)
    _, tag_b = text_y_range("裂纹", "cn_b", 26, 40)
    tag_en_t, _ = text_y_range("CRACK", "en_b", 22, 96)
    if tag_b > tag_en_t:
        problems.append(f"card: tag bottom {tag_b} > tag_en top {tag_en_t}")
    _, title_en_b = text_y_range("Crack", "en_b", 30, 40)
    title_t, title_b = text_y_range("裂纹", "cn_b", 36, 78)
    if title_en_b > title_t:
        problems.append(f"card: title_en bottom {title_en_b} > title top {title_t}")
    if title_b > 158:
        problems.append(f"card: title bottom {title_b} > gold bar 158")
    # last body row
    if 306 + 11 > R.CARD_H:
        problems.append(f"card: body last row bottom > card height {R.CARD_H}")

    # ---- Defect summary panel (draw_defect_summary) local + DIAG_Y=150 ----
    # title_en(en_b30,y228)  title(cn_b28,y268)  bar 310..380
    # label/value rows: cn/val y430(h22/24)  en y458/460(h16/18)
    _, den_b = text_y_range("Crack", "en_b", 30, 150 + 78)
    dtitle_t, dtitle_b = text_y_range("裂纹", "cn_b", 28, 150 + 118)
    if den_b > dtitle_t:
        problems.append(f"diag: title_en bottom {den_b} > title top {dtitle_t}")
    if dtitle_b > 310:
        problems.append(f"diag: title bottom {dtitle_b} > bar 310")
    # label/value vertical pair spacing
    _, lcn_b = text_y_range("目视检验", "cn", 22, 150 + 260 + 20)
    len_t, _ = text_y_range("Visual", "en", 16, 150 + 260 + 48)
    if lcn_b > len_t:
        problems.append(f"diag: label_cn bottom {lcn_b} > label_en top {len_t}")
    _, vcn_b = text_y_range("适用", "cn_b", 24, 150 + 260 + 20)
    ven_t, _ = text_y_range("Applicable", "en_b", 18, 150 + 260 + 50)
    if vcn_b > ven_t:
        problems.append(f"diag: value_cn bottom {vcn_b} > value_en top {ven_t}")

    # ---- Tag layer (_tag_layer) local: code(y36) cn(y74) en(y98) ----
    _, code_b = text_y_range("A", "en_b", 44, 36)
    cn_t, _ = text_y_range("裂纹", "cn", 22, 74)
    if code_b > cn_t:
        problems.append(f"tag: code bottom {code_b} > cn top {cn_t}")

    # ---- Point layer (_point_layer) local: cn(y18) en(y52) ----
    _, pcn_b = text_y_range("禁止", "cn_b", 24, 18)
    pen_t, _ = text_y_range("Not Permitted", "en_b", 20, 52)
    if pcn_b > pen_t:
        problems.append(f"point: cn bottom {pcn_b} > en top {pen_t}")

    for p in problems:
        print(f"  INTERNAL SPACING FAIL: {p}")
    return len(problems) == 0


if __name__ == "__main__":
    out_dir = os.path.join(ROOT, "render", "layout_guard")
    ok = True
    # Check intro, a representative defect scene, and summary.
    for idx, t in [(0, 7.5), (2, 2.0), (len(R.SCENES) - 1, 5.0)]:
        scene = R.SCENES[idx]
        print(f"Checking scene {idx}: {scene.get('top_title', scene.get('title', 'summary'))}")
        if not check_scene(idx, t, out_dir):
            ok = False

    print("Checking internal text spacing (card / panel / tag / point)...")
    if not check_internal_spacing():
        ok = False

    if ok:
        print("\nOK — no overlapping UI elements detected.")
        sys.exit(0)
    else:
        print(f"\nFAIL — overlap detected. Debug frames saved to {out_dir}")
        sys.exit(1)
