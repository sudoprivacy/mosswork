#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""验证：每句字幕都钉在其 TTS 互相关真实位置，且文字与真实说话一致。"""
import json, re

HERE = "D:/微信小程序/情景视频存放处/豆包视频加字幕工作流"
ALIGN = json.load(open(HERE + "/tts_align.json", encoding="utf-8"))
EN = [
    "Silencing and vibration isolation hold point.",
    "Confirm the silencer direction and the isolation hangers.",
    "Silencer installed with the flow arrow correct,",
    "isolation hangers on the fan and the duct near it.",
    "The silencer is upstream of the fan as drawn.",
    "But the duct is hard-coupled to the structure at this bracket",
    "We will fit the isolation hanger and break the rigid link.",
    "Good.",
    "No rigid path to the structure.",
    "After the fix I sign the silencing and isolation.",
    "Hanger fitted, rigid link removed.",
    "Tagged as done.",
    "Good.",
    "Silencing and isolation accepted.",
    "Punch, rigid coupling.",
]

def ts(t):
    h, m, s = t.split(":"); return int(h)*3600+int(m)*60+float(s)

subs = []
for line in open(HERE + "/hvac_07_fixed.ass", encoding="utf-8"):
    m = re.match(r"Dialogue: 0,(\d+:\d+:\d+\.\d+),(\d+:\d+:\d+\.\d+),.*?,,(.*)", line)
    if m:
        subs.append((ts(m.group(1)), ts(m.group(2)), m.group(3)))

print("字幕条数:", len(subs))
ok = 0
for idx, pos, score, text in ALIGN:
    # 在 pos 附近(±0.5s)应有一句含该英文首词
    key = EN[idx-1].split(" ")[0].lower()
    hit = [s for s in subs if abs(s[0]-pos) < 0.6 and key in s[2].lower()]
    if hit:
        ok += 1
        print("  ✅ 句%d 真实%.2fs 字幕在 %.2fs 出现 (%.2f-%.2f)" % (idx, pos, hit[0][0], hit[0][0], hit[0][1]))
    else:
        print("  ❌ 句%d 真实%.2fs 未找到对应字幕" % (idx, pos))
print("\n匹配 %d/%d 句" % (ok, len(ALIGN)))
print("判定:", "字幕全部钉在真实说话位置 ✅" if ok == len(ALIGN) else "仍有错位 ❌")
