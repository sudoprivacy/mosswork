# -*- coding: utf-8 -*-
"""
plan_change.py  —  改动前影响预判器（只读，不修改任何文件）

用途：你提一个"想改的地方"（目前支持：字幕上移 N px / 字幕增高 H px），
本工具先用【真实的 draw_* 函数】把该场景渲染成单帧，按竖向 band 扫描出
每个元素的真实包围盒，再模拟改动后的位置，判定会不会遮挡其他内容，
并给出安全上限与修改建议。

设计原则（对应你的红线）：
  - 只读：import 原脚本 render_table_walkthrough_l_pos_en as R，只调用其函数，不写文件、不改 R。
  - 真实：判定依据是该场景实际渲染出的像素，不是我拍脑袋的坐标。
  - 出方案不出手：只 print 结论，绝不落盘。确认后你再让我改。

元素竖向 band（来自原脚本实测坐标）：
  top   : y[0,150]    胶囊标签 + 双语标题
  table : y[150,600]  标准表 + 高亮行
  card  : y[620,968]  缺陷卡片（CARD_Y=620, CARD_H=348）
  sub   : y[974,1080] 双语字幕（SUB_Y=974，EN 994 / CN 1046）

用法：
  python plan_change.py --scene 2 --shift 40        # 字幕上移 40px 会不会挡？
  python plan_change.py --scene 2 --grow 30         # 字幕带增高 30px 会不会挡？
  python plan_change.py --scene 2 --safe            # 只算字幕安全上移上限
"""
import os, sys, argparse
from PIL import Image, ImageDraw

RENDER_DIR = os.path.dirname(os.path.abspath(__file__))
if RENDER_DIR not in sys.path:
    sys.path.insert(0, RENDER_DIR)
import render_table_walkthrough_l_pos_en as R

# 竖向 band 定义（[y0, y1, 名称]）
BANDS = [
    (0, 150, "top"),
    (150, 600, "table"),
    (600, 980, "card"),
    (980, 1080, "sub"),
]

BG_TOL = 40  # 背景色容差，用于把"非背景油墨像素"抠出来


def _ink_mask(im, bg):
    """返回 (H, W) 的 bool 数组：True=非背景油墨像素（numpy 向量化，快）。"""
    import numpy as np
    arr = np.asarray(im.convert("RGB")).astype(int)
    bg_arr = np.array(bg, dtype=int)
    diff = np.abs(arr - bg_arr).sum(axis=2)   # 三通道总偏差
    return diff > (BG_TOL * 3)


def band_box(mask, y0, y1):
    """在 [y0,y1) 竖向带内，找油墨像素的最小/最大 y（全宽），返回 (ymin,ymax) 或 None。"""
    sub = mask[y0:y1, :]
    if not sub.any():
        return None
    rows = sub.any(axis=1)
    local_ymin = rows.argmax()
    local_ymax = len(rows) - 1 - rows[::-1].argmax()
    return (y0 + local_ymin, y0 + local_ymax)


def render_frame(i, t):
    """用真实 draw_* 渲染场景 i 在时刻 t 的单帧（RGBA）。"""
    R.load_assets()
    R.build_bg()
    FPS, W, H = R.FPS, R.W, R.H
    sc = R.SCENES[i]
    row = sc if sc.get("key") else None
    im = Image.new("RGBA", (W, H), R.BG + (255,))
    d = ImageDraw.Draw(im)
    im.paste(R._BG, (0, 0))
    n_sc = len(R.SCENES)
    if i == 0:
        R.draw_intro(im, d, t)
    elif i == n_sc - 1:
        R.draw_top(d, sc)
        R.draw_table(im, d, sc.get("key"), t)
        R.draw_summary_burst(im, d, t)
    else:
        R.draw_top(d, sc)
        R.draw_table(im, d, sc.get("key"), t)
        if row:
            R.draw_card(im, row, 1.0, t)
            R.draw_position_diagram(im, d, row["code"], t)
    R.draw_subtitle(d, sc.get("caption_en", ""), sc["caption"])
    return im


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scene", type=int, default=2, help="场景索引（缺陷场景 1..8）")
    ap.add_argument("--shift", type=int, default=0, help="字幕整体上移 N px（模拟）")
    ap.add_argument("--grow", type=int, default=0, help="字幕带向下增高 H px（模拟更长字幕）")
    ap.add_argument("--safe", action="store_true", help="只算字幕安全上移上限")
    args = ap.parse_args()

    t = 3.0  # 卡片已稳定出现、字幕已显示的时间点
    im = render_frame(args.scene, t)
    bg = R.BG
    mask = _ink_mask(im, bg)

    print(f"=== 场景 {args.scene} 当前各元素真实包围盒（竖向）===")
    boxes = {}
    for y0, y1, name in BANDS:
        bb = band_box(mask, y0, y1)
        boxes[name] = bb
        print(f"  {name:6s}: {bb if bb else '（该带无内容）'}")

    sub = boxes["sub"]
    card = boxes["card"]
    if sub is None:
        print("\n该场景无字幕，无法演示字幕遮挡分析。")
        return

    sub_top, sub_bot = sub
    print(f"\n字幕当前：top={sub_top} bottom={sub_bot} 高={sub_bot - sub_top}")

    # 安全上移上限：字幕顶不能高于卡片底（留 6px 间隙）
    if card:
        safe_gap = 6
        max_up = sub_top - (card[1] + safe_gap)
        print(f"卡片底={card[1]}，字幕安全上移上限 = {max_up} px（再高就会压到卡片）")
    else:
        max_up = sub_top - 150  # 顶到标题带
        print(f"无卡片，字幕安全上移上限≈{max_up} px（到标题带为止）")

    if args.safe:
        return

    # 模拟改动
    new_top = sub_top - args.shift
    new_bot = sub_bot - args.shift + args.grow
    print(f"\n--- 模拟改动：字幕上移 {args.shift}px" + (f" + 增高 {args.grow}px" if args.grow else "") + " ---")
    print(f"  改动后字幕：top={new_top} bottom={new_bot}")

    # 判定重叠（字幕 vs 每个其它元素）
    hit = []
    for name, bb in boxes.items():
        if name == "sub" or bb is None:
            continue
        if new_top < bb[1] and new_bot > bb[0]:
            hit.append((name, bb))
    if hit:
        print("  ❌ 会遮挡：")
        for name, bb in hit:
            print(f"     · {name}（{bb}）— 字幕底 {new_bot} > {name}顶 {bb[0]}")
        print("\n  建议（不擅自动手，供你拍板）：")
        print(f"     1) 字幕上移不超过 {max_up}px；当前改动 {args.shift}px 超限，需降到 {max_up}px 以内。")
        print("     2) 或把卡片 CARD_Y 上移 / 减小 CARD_H，给字幕腾空间（改动更大，需再跑本工具复核）。")
        print("     3) 或把字幕改为单行（去掉 CN 行），整体下移，避开卡片。")
    else:
        print("  ✅ 不会遮挡任何其它元素。")

    # 画幅边界判定（被切掉也算"影响其他地方"）
    H = R.H
    oob = []
    if new_top < 2:
        oob.append(f"字幕顶 {new_top} < 0（超出画幅上沿，会被切）")
    if new_bot > H - 2:
        oob.append(f"字幕底 {new_bot} > {H}（超出画幅下沿，会被切掉 {new_bot - (H - 2)}px）")
    if oob:
        print("  ⚠️ 出画框：")
        for m in oob:
            print("     · " + m)
        print("  建议：增高字幕时同步上移，或缩小字号，确保 bottom <= 1078。")
    elif not hit:
        print("  ✅ 且在画幅内，可以安全落地。")
    print("\n（本工具只读、未修改任何文件）")


if __name__ == "__main__":
    main()
