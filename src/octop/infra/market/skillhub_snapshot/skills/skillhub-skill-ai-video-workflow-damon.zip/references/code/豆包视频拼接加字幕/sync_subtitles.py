#!/usr/bin/env python3
"""Generate an ASS subtitle file for a Doubao/Jimeng video, synced to audio.

Usage examples:
  # 1) Print detected speech/silence structure
  python sync_subtitles.py analyze --video src.mp4

  # 2) Build ASS with manually provided times
  python sync_subtitles.py build --video src.mp4 --json clauses.json --out fix.ass

  # 3) Auto-fill missing times: map clauses to speech segments 1:1
  python sync_subtitles.py build --video src.mp4 --json clauses.json --out fix.ass --auto

  # 4) Auto-fill with explicit segment sizes, e.g. segment 1 has 1 clause,
  #    segment 2 has 1 clause, segment 3 has 4 clauses
  python sync_subtitles.py build --video src.mp4 --json clauses.json --out fix.ass \
      --per-segment 1,1,4

clauses.json format:
[
  {"en": "English clause", "cn": "中文分句", "start": 0.0, "end": 1.5},
  ...
]
start/end are optional if --auto or --per-segment is used.
"""

import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

FFMPEG_DEFAULT = Path.home() / ".workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"
FFMPEG = Path(os.environ.get("FFMPEG", str(FFMPEG_DEFAULT)))


def run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True, shell=False)
    if result.returncode != 0 and result.stderr:
        print(result.stderr, file=sys.stderr)
    return result.stdout + result.stderr


def extract_audio(video_path, wav_path):
    cmd = [
        str(FFMPEG),
        "-y", "-i", str(video_path),
        "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
        str(wav_path),
    ]
    run(cmd)


def detect_silence(wav_path, noise="-35dB", min_duration=0.08):
    """Return list of (speech_start, speech_end) in seconds."""
    cmd = [
        str(FFMPEG),
        "-i", str(wav_path),
        "-af", f"silencedetect=noise={noise}:d={min_duration}",
        "-f", "null", "-",
    ]
    output = run(cmd)

    silence_starts = []
    silence_ends = []
    for line in output.splitlines():
        m = re.search(r"silence_start:\s*([\d.]+)", line)
        if m:
            silence_starts.append(float(m.group(1)))
        m = re.search(r"silence_end:\s*([\d.]+)", line)
        if m:
            silence_ends.append(float(m.group(1)))

    # Derive speech segments from silence list
    if not silence_starts:
        # No silence detected: assume one long speech segment spanning the whole file
        return [(0.0, get_wav_duration(wav_path))]

    speech = []
    # If the first event is silence_start at 0, speech starts at first silence_end
    first_silence_at_zero = silence_starts and silence_starts[0] == 0.0
    if first_silence_at_zero:
        i = 0
        while i < len(silence_starts):
            speech_end = silence_starts[i] if i > 0 else 0.0
            if i == 0:
                # ignore the leading silence marker for speech start
                pass
            else:
                speech.append((silence_ends[i - 1], speech_end))
            i += 1
        # After last silence_end, speech continues to end of audio
        speech.append((silence_ends[-1], get_wav_duration(wav_path)))
    else:
        # First event is silence_end (audio starts with speech)
        speech.append((0.0, silence_starts[0]))
        for i in range(1, len(silence_starts)):
            speech.append((silence_ends[i - 1], silence_starts[i]))
        speech.append((silence_ends[-1], get_wav_duration(wav_path)))

    # Remove zero-length or invalid segments
    speech = [(s, e) for s, e in speech if e > s]
    return speech


def get_wav_duration(wav_path):
    import wave
    with wave.open(str(wav_path), "rb") as w:
        return w.getnframes() / w.getframerate()


def split_duration_by_length(clauses, start, end):
    """Within a continuous speech span, assign (start,end) to each clause proportionally by character length."""
    lengths = [len(c["en"]) for c in clauses]
    total = sum(lengths) or 1
    dur = end - start
    positions = [0.0]
    for L in lengths:
        positions.append(positions[-1] + L / total)
    times = [start + p * dur for p in positions]
    return [(times[i], times[i + 1]) for i in range(len(clauses))]


def fill_missing_times(clauses, speech_segments, per_segment=None):
    """Assign start/end to clauses missing them using detected speech segments.

    per_segment: optional list of integers telling how many clauses belong to each speech segment.
                 If omitted, assumes one clause per speech segment.
    """
    # Count clauses that need timing
    missing = [i for i, c in enumerate(clauses) if c.get("start") is None or c.get("end") is None]
    if not missing:
        return clauses

    if per_segment is None:
        if len(clauses) == len(speech_segments):
            per_segment = [1] * len(speech_segments)
        else:
            raise ValueError(
                f"{len(clauses)} clauses but {len(speech_segments)} speech segments. "
                "Provide --per-segment sizes, e.g. --per-segment 1,1,4"
            )

    if sum(per_segment) != len(clauses):
        raise ValueError(
            f"--per-segment sum {sum(per_segment)} != clause count {len(clauses)}"
        )

    clause_idx = 0
    new_clauses = list(clauses)
    for seg_idx, n in enumerate(per_segment):
        if seg_idx >= len(speech_segments):
            raise ValueError(f"--per-segment has more groups ({len(per_segment)}) than detected speech segments ({len(speech_segments)})")
        seg = speech_segments[seg_idx]
        group = new_clauses[clause_idx:clause_idx + n]
        times = split_duration_by_length(group, seg[0], seg[1])
        for c, (s, e) in zip(group, times):
            c["start"] = round(s, 2)
            c["end"] = round(e, 2)
        clause_idx += n
    return new_clauses


def seconds_to_ass(t):
    hours = int(t // 3600)
    minutes = int((t % 3600) // 60)
    secs = t % 60
    return f"{hours}:{minutes:02d}:{secs:05.2f}"


def build_ass(clauses, out_path, width=1280, height=720, font_size=40,
              margin_v=30, margin_lr=60, wrap_style=1, outline=3, shadow=2):
    lines = [
        "[Script Info]",
        "ScriptType: v4.00+",
        f"PlayResX: {width}",
        f"PlayResY: {height}",
        f"WrapStyle: {wrap_style}",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, "
        "Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        f"Style: Default,Microsoft YaHei,{font_size},&H00FFFFFF,&H000000FF,&H00000000,"
        f"&H80000000,0,0,0,0,100,100,0,0,1,{outline},{shadow},2,{margin_lr},{margin_lr},{margin_v},1",
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    for c in clauses:
        en = c["en"].replace("\n", " ")
        cn = c["cn"].replace("\n", " ")
        text = f"{en}\\N{cn}"
        start = seconds_to_ass(c["start"])
        end = seconds_to_ass(c["end"])
        lines.append(f"Dialogue: 0,{start},{end},Default,,0,0,0,,{text}")
    Path(out_path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_per_segment(s):
    if not s:
        return None
    return [int(x.strip()) for x in s.split(",")]


def cmd_analyze(args):
    with tempfile.TemporaryDirectory() as tmp:
        wav = Path(tmp) / "audio.wav"
        extract_audio(args.video, wav)
        speech = detect_silence(wav, args.noise, args.min_duration)
        dur = get_wav_duration(wav)
        print(f"Duration: {dur:.2f}s")
        print(f"Detected speech segments ({len(speech)}):")
        for i, (s, e) in enumerate(speech, 1):
            print(f"  {i}: {s:.2f}s -- {e:.2f}s  (len {e-s:.2f}s)")


def cmd_build(args):
    clauses = json.loads(Path(args.json).read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory() as tmp:
        wav = Path(tmp) / "audio.wav"
        extract_audio(args.video, wav)
        speech = detect_silence(wav, args.noise, args.min_duration)
        per_segment = parse_per_segment(args.per_segment)
        clauses = fill_missing_times(clauses, speech, per_segment)
    build_ass(
        clauses, args.out,
        width=args.width, height=args.height,
        font_size=args.font_size, margin_v=args.margin_v,
        margin_lr=args.margin_lr, wrap_style=args.wrap_style,
        outline=args.outline, shadow=args.shadow,
    )
    print(f"Wrote {args.out}")
    for c in clauses:
        print(f"  {c['start']:.2f}s -- {c['end']:.2f}s  {c['en']}")


def main():
    parser = argparse.ArgumentParser(description="Build audio-synced ASS subtitles for Doubao/Jimeng videos.")
    parser.add_argument("--ffmpeg", default=str(FFMPEG), help="Path to ffmpeg binary.")
    parser.add_argument("--noise", default="-35dB", help="silencedetect noise threshold.")
    parser.add_argument("--min-duration", type=float, default=0.08, help="Minimum silence duration in seconds.")
    sub = parser.add_subparsers(dest="command", required=True)

    p_ana = sub.add_parser("analyze", help="Print speech/silence structure of the video audio.")
    p_ana.add_argument("--video", required=True)
    p_ana.set_defaults(func=cmd_analyze)

    p_build = sub.add_parser("build", help="Generate ASS from clauses JSON.")
    p_build.add_argument("--video", required=True)
    p_build.add_argument("--json", required=True)
    p_build.add_argument("--out", required=True)
    p_build.add_argument("--per-segment", default=None,
                         help="Comma-separated clause counts per speech segment, e.g. 1,1,4")
    p_build.add_argument("--width", type=int, default=1280)
    p_build.add_argument("--height", type=int, default=720)
    p_build.add_argument("--font-size", type=int, default=40)
    p_build.add_argument("--margin-v", type=int, default=30)
    p_build.add_argument("--margin-lr", type=int, default=60)
    p_build.add_argument("--wrap-style", type=int, default=1)
    p_build.add_argument("--outline", type=int, default=3)
    p_build.add_argument("--shadow", type=int, default=2, help="Subtitle drop shadow size (default 2).")
    p_build.set_defaults(func=cmd_build)

    args = parser.parse_args()
    global FFMPEG
    FFMPEG = Path(args.ffmpeg)
    args.func(args)


if __name__ == "__main__":
    main()
