---
name: skillhub-skill-ai-video-workflow-damon
description: "## 支付宝 AI 按量付费改造声明"
---

## 支付宝 AI 按量付费改造声明

本 Skill 已按 SkillHub Pay Skill 规范完成支付宝 AI 按量付费改造：

- **402 账单下发**：调用入口 `/api/skill/ai-video-workflow-damon`，若请求未携带有效 `Payment-Proof`，服务返回 HTTP 402 并在响应头 `Payment-Needed` 中下发 Base64URL 编码的账单 JSON，包含 `out_trade_no`、`amount`、`currency`、`resource_id`、`pay_before`、`seller_sign_type`、`seller_signature`。
- **携带凭证重试**：用户端支付完成后，再次请求同一 `resource_id` 并在请求头携带 `Payment-Proof`（支付宝返回的支付凭证）。
- **验付调用**：服务端调用支付宝 `alipay.aipay.agent.payment.verify` 接口验证 `Payment-Proof` 真实性。
- **履约确认**：验证通过后执行业务逻辑，并异步调用 `alipay.aipay.agent.fulfillment.confirm` 完成履约确认（ack）。
- **订单持久化与幂等**：所有订单写入持久化存储，以 `out_trade_no` 为唯一键，重复请求直接返回已履约结果。
- **probe / pay / complete / ack**：后端提供 `probe` 探测、`pay` 账单下发、`complete` 业务执行、`ack` 履约确认完整链路。
- **支付依赖包**：后端 `skillpay-backend/package.json` 已声明调用支付宝网关所需依赖，完整服务端实现见同目录 `server.js`。

# AI 视频生产工作流 · 总入口 skill（通用）

> 本 skill 是**通用 AI 视频生产工作流产品包**的**单一总入口**——从文本 / 素材到成片的完整链路。
> **任何行业、任何主题都能用**：企业培训、安全宣贯、产品宣传、课程讲解、周报播报、短剧分镜、
> AI 生成视频（豆包/即梦）加字幕二次加工……**标准 / 规范讲解只是其中一类场景，不是全部**。
> 9 个子产品的**实际代码**都在包内 `code/` 目录，本 skill 做编排 + 方法论文档（见 `references/`）。
> 接任何视频任务，先读本 SKILL.md，再进对应子产品目录或跑统一入口。

## ★ 唯一权威代码位置（伞包）

```
D:\Workbuddy缓存位置\标准讲解视频工作流\
```

> **本发布包已自带 9 个子产品的全部代码**，位于包内 `code/` 目录（`install.bat` / `start.py` / `workflow.py` / `check.py` 及各子产品脚本），解压后直接可用。
> 为控制体积，打包时**剔除**了渲染产物与历史跑批：`output/`、`_forms_preview/`、`情景视频生产链/projects/`（这些是运行结果，不是能力本体，缺了不影响复现——重跑即生成）。
> `references/` 下 5 个 md 是方法论文档（总纲 / 避坑 / 自检 / 自适应手册 / 产品总览）。

---

## 〇、固定工作流六步法（任何新视频先走这套，铁律）

```
收到任务 → ①审题 → ②定方向 → ③排版 → ④定形式 → ⑤质检校验 → ⑥出片验收
              ↑________ 任一步踩红线 → 当场报错、指出元素、不出片 ________↑
```

- **①审题**：把需求 parse 成结构化 Brief（主题/要点/素材/红线）；`standard_explain` 必须给真实标准原图，无图=凭空捏造直接报错。
- **②定方向**：定模板（standard_explain / training_promo / product_promo / business_promo / student_lecture）+ 风格 + 横竖屏 + 语言 + 音色。
- **③排版**：逐场景绘制，横竖屏坐标全部基于画布尺寸自适应（不再硬编码 1080 宽）。
- **④定形式**：背景图 cover 不拉伸、入场动画多样、话画一致、配音去 AI 味。
- **⑤质检校验**：三道闸（超屏/重叠/图压字）+ 话画一致性闸 + `check.py` 硬闸门。
- **⑥出片验收**：ffmpeg 合成 → 跑 `check.py` A0–A8 全 PASS → 抽帧肉眼复核 → 给绝对路径。

**红线闸门总表**（用户怒批过的，全在这，详见 `references/01_pitfalls.md` 与 `references/04_fixed_workflow.md`）：

| 类别 | 红线（简要） |
|---|---|
| 截图 | 只讲这张图，严格裁到该图注末行，不切邻图 |
| 形式 | 画重点 ≥3 种原语轮换；高亮框 4px 单线禁大膏药；入场动画每点不同 |
| 绘制 | 所有绘制走 Canvas 登记，禁 `register=False` 脱管 |
| 音频 | 全片一个音色重试不换；成片时长=Σ配音误差<0.1s；配音讲内容禁只念标题；话画一致；单音轨 |
| 字幕 | 纯中文不掺英文；EN 上 ZH 下；英文行纯 ASCII 或留空（禁 tofu） |
| 布局 | 超屏/互叠/图压字三道闸；改坐标必查四处 |
| 转场 | 仅首场淡入，其余交叉溶解，禁每场独立黑场 |
| 背景 | cover 裁剪禁拉伸变形 |
| 标准引用 | 引用真实标准条文禁错引（不锈钢 AWS D1.1→D1.6）；**标准编号原样保留空格和点**（禁 `isalnum()` 洗成 AWSD11） |
| 交付 | 落 `D:\微信小程序\标准视频库\`；给真实绝对路径 + 自检报告；文档写路径必先 `ls` 核实 |

---

## 一、统一入口（首选）

在伞包根目录执行：

```bat
:: 第一次 / 换机器（幂等，装 ffmpeg+Pillow+edge-tts+numpy+Node+字体）：
python install.py
::（本发布包不含 .bat 启动器；如需双击启动，自建 install.bat 内容为一行：python install.py）

:: 选工作流 / 直连固定工作流：
python start.py
python workflow.py --demo          :: 竖屏+横屏各走一遍并强制跑 check.py 闸门
python workflow.py --brief x.json  :: 新任务 Brief 路由到对应渲染器，不过闸不出片

:: 成片交付前自检（不过不许交付）：
python check.py "D:\微信小程序\标准视频库\你的成片.mp4" --expect 129.14

:: 形式矩阵截图（6 风格 × 9 版式 × 横竖屏一次看全，输出 _forms_preview/）：
python forms_preview.py
```

---

## 二、9 个子产品索引（路径均已 `ls` 实核存在）

> 以下路径均在伞包 `D:\Workbuddy缓存位置\标准讲解视频工作流\` 之下。

| # | 子产品 | 用途 | 入口命令（在伞包根目录执行） | 备注 |
|---|---|---|---|---|
| 1 | **情景视频生产链** | 船海/海工专家知识网络 → 中英双语短视频（旁白/对话、横竖屏） | `cd 情景视频生产链 && python run.py <topic> --lang en` | 企业培训/安全宣贯；英中双语字幕，3 镜头固定机位 |
| 2 | **表格讲解视频** | 标准规范里的表格（AWS D1.1 Table 6.10 等）→ 逐行高亮讲解 | `python render/render_table_walkthrough_l_pos_en.py`（伞根 render/）<br>`python render/render_fast.py`（通用） | ⚠️ 代码在**伞根 `render/`**，不在 `表格讲解视频/render/`（`表格讲解视频/` 仅有 README）；高亮严格在表内禁扫描线伪影 |
| 3 | **图片讲解视频** | 标准里的图（AWS D1.1 Figure 6.16 等）→ 分镜讲解 | `python 图片讲解视频/main.py --brief brief.json` | **标准实现**，新任务首选；framework 在 `图片讲解视频/framework/` |
| 4 | **NDT 探伤培训竖屏** | TÜV NDT 探伤证培训宣传（先焦虑后推产品） | `python NDT培训竖屏/render/render_training_promo_v2.py` | 安全区 190/260，禁大红铺底 |
| 5 | **ASME B31.3 表格讲解** | ASME B31.3 Table 341.3.2 焊缝缺陷射线验收 | `python ASME_B31_3_表格讲解/render/*.py`（见该目录 README） | 同表格红线 |
| 6 | **周报视频** | 招聘/船海周报 PPT → 16:9 英文朗读视频 | `python 周报视频/pipeline/weekly_build.py --project <项目名>` | 同页背景不切、逐句切字幕 |
| 7 | **豆包视频拼接加字幕** | 豆包/即梦文生视频 → 拼接 → 中英硬字幕(EN上CN下·逐句切) → 抽帧验证 | 横屏：`python 豆包视频拼接加字幕/sync_subtitles.py --video in.mp4 ...`<br>竖屏：`python 豆包视频拼接加字幕/gen_vertical_sentences.py` | 3 铁律：豆包必须无字/字幕跟音频/不加黑幕；每步独立可改 |
| 8 | **小短剧分镜** | 剧本/梗概 → 最少关键帧分镜图 | `python 小短剧分镜/character_face_check.py` 等（见该目录 README） | 短剧/漫剧制作 |
| 9 | **app_demo** | 3D 卡片开场 + WorkBuddy App 聊天录屏段（HTML+Playwright，竖屏 9:16） | `node app_demo/render.js --mp4` | 只产动态镜头片段，拼接收口交给「豆包视频拼接加字幕」；`render_fallback.py` 为 PIL 降级 |

> 每个子目录第一件事看其 `0_README_先看这个.md`。

---

## 三、硬闸门（自动拦截，绝不靠人记）

| 闸门 | 触发条件 | 位置 |
|---|---|---|
| `Canvas.validate(strict=True)` | 超屏 / 文字互叠 / 图压字 | `图片讲解视频/framework/canvas.py` |
| `_voice_title_check` | 配音为空或不含画面 title 主题词 | `图片讲解视频/framework/engine.py` |
| `smoke_test.py` | 6 风格×9 版式×2 方向=120 组合硬审核 | `图片讲解视频/smoke_test.py` |
| `check.py` A0–A8 | 交付前 8 项自动自检（ffmpeg/分辨率/单音轨/时长/黑场/结尾/…） | 伞根 `check.py` |

**铁律**：不通过 ⑤质检 / ⑥`check.py` 闸门，绝不交付。同一类错误不允许出现第二次。

---

## 四、行为红线（给 AI / 协作方）

1. **frozen scope**：只改用户点名的部分，未授权不动。
2. **不画蛇添足**：图里没写、用户没问的内容禁止自己加。
3. **先给方案再动手**：改动影响其他元素时，先出整体方案确认再改。
4. **重大风格改动先出单帧示例**给用户确认，再写回脚本重渲。
5. **用户发火时**：先认错 → 给根因证据 → 给修法，不辩解。
6. **交付 = 结论 + 真实绝对路径 + 自检证据**，禁止空泛总结、禁止交付旧文件。
7. **标准编号神圣**：`AWS D1.1` 的空格和点一个都不能少（文件名清洗只用 `safe_filename()`，禁 `isalnum()` 白名单）。

---

## 五、方法论文档（本 skill 内置快照，路径见 `references/`）

- `references/README.md` — 产品包总览 + 三步上手 + 9 子产品清单（= 伞包 `0_README_先看这个.md`）
- `references/04_fixed_workflow.md` — 固定工作流总纲（六步法 + 红线闸门总表，权威）
- `references/01_pitfalls.md` — 避坑总纲·血泪清单（11 条铁律 + 全类翻车硬闸门）
- `references/02_delivery_checklist.md` — 交付前自检清单（check.py A0–A8 + 人工抽帧/听音/字幕项）
- `references/03_adaptive_manual.md` — 自适应能力手册（5 步推断 + 风格/版式/横竖屏/字体/音色实测参数矩阵）

> 接新任务时先读 `references/03_adaptive_manual.md` 的「5 步推断流程」选工具，再走六步法。

_本 skill = 总入口。任何子产品 README 与 `references/04_fixed_workflow.md` 冲突时，以总纲为准。_
