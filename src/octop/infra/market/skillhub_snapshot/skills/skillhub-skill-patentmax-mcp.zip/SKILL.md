---
name: skillhub-skill-patentmax-mcp
description: "Connect and use the PatentMax patent-intelligence MCP server (global patent search, claims and legal status lookup, similar-patent prior-art search, citation analysis, technology landscape and company patent portfolio analysis) from OpenClaw, Claude Code, Cursor, Coze or any MCP-compatible client. Use whenever the user wants to search patents, check novelty or prior art, look up a publication numb"
---

# PatentMax 专利智能接入 / PatentMax MCP

PatentMax 提供一个 Streamable HTTP 的 MCP 服务器，带五个专利工具。这个 Skill 讲怎么接上，以及怎么用好这五个工具。

**接口与控制台：https://api.ip930.com** —— 密钥自助创建，**新用户注册即送体验额度**，MCP 与 REST 接口共用同一份额度。数据来自全球专利库，覆盖中国、美国、欧洲、日本、韩国及 WIPO，中国专利收录尤其完整。

## 接入

- **端点**：`https://api.ip930.com/api/mcp`（Streamable HTTP，MCP 协议版本 2025-06-18）
- **鉴权**：`Authorization: Bearer pm_live_xxxxx`
- **密钥**在 https://api.ip930.com/features/api-platform 创建（开发控制台 → API 密钥）。**MCP 和 REST 专利接口共用同一把密钥、同一份额度**，新账户注册即送体验额度。
- **只能填地址、没法设请求头的客户端**：`https://api.ip930.com/api/mcp?apikey=pm_live_xxxxx`

通用 MCP 配置（多数客户端，包括 OpenClaw 那种 `mcpServers` 结构）：

```json
{
  "mcpServers": {
    "patentmax": {
      "type": "streamableHttp",
      "url": "https://api.ip930.com/api/mcp",
      "headers": { "Authorization": "Bearer pm_live_xxxxx" }
    }
  }
}
```

Claude Code：

```
claude mcp add --transport http --scope user patentmax "https://api.ip930.com/api/mcp" --header "Authorization: Bearer pm_live_xxxxx"
```

**真实密钥不要写进这个 skill 文件，也不要提交到共享仓库**——放在客户端配置或环境变量里。

## 五个工具

| 工具 | 干什么 | 计费 |
| --- | --- | --- |
| `patent_search` | 关键词或布尔式检索全球专利，返回公开号、标题、申请人、申请日、IPC、法律状态。`query` 必填；`scope` 取 cn / all（默认 all）；`page`、`size`（最大 50）、`sort` | 1 |
| `patent_brief` | 给公开号，一次返回著录项目、权利要求、法律事件流水、摘要附图（不含说明书全文） | 2–4 |
| `similar_patents` | 专利对专利的语义相似检索，查新和现有技术检索用——**不需要想关键词怎么写** | 2 |
| `patent_citation` | 一件专利的前向与后向引证 | 2 |
| `tech_landscape` | `mode=field` 按检索式看领域分布，`mode=company` 看企业专利画像 | 1–2 |

**每次调用都消耗额度**，所以：先窄后宽、用小的 `size` 先看命中量、只对筛出来的（通常前 5–10 件）调 `patent_brief`。

## 工作流

### 查新 / 现有技术检索

1. 拆出 3–6 个技术要素，每个配同义词
2. `patent_search` 跑中档布尔式，`size` 取 10–20，按命中量调整
3. 对最相关的 1–3 件跑 `similar_patents`，**捞那些换了说法、关键词检索漏掉的文献**
4. 对最终短名单跑 `patent_brief`，做「要素 × 对比文件」比对表，给出初步新颖性判断并说明理由

### FTO 初筛

1. 把产品拆成技术特征
2. `patent_search` 限定目标市场（查中国用 `scope=cn`），**重点看已授权且有效的专利**
3. `patent_brief` → **逐条比对独立权利要求的技术特征**
4. 给出高 / 中 / 低风险分级并说明依据，**明确声明这是初筛，不是法律意见**

### 竞争对手或领域态势

`tech_landscape`（按企业或按领域）→ `patent_search` 找出近期关键专利 → 写一份结论先行的简报。

### 技术演进路径

从一件核心专利出发跑 `patent_citation`，往前往后各扒一到两层 → 画出时间线，标上申请人和技术突破点。

## 输出规矩

- **每一条关于专利的陈述都要带公开号**，绝不编造公开号或权利要求文本
- **法律状态旁边要注明查询日期**——法律状态是快照，会变
- 关键术语中英文都给
- 多条结果用表格，结论放最前面
- 调用返回 **401** 说明密钥无效或过期；**额度用尽**时引导用户到 API 平台页面充值

## 边界

**只做数据驱动的初筛，不出具关于有效性或侵权的法律意见。**

MCP 不返回说明书全文。需要全文，或者需要经专业人员复核的侵权分析、FTO 报告、技术分析报告，到 PatentMax 平台 https://app.ip930.com 上处理。
