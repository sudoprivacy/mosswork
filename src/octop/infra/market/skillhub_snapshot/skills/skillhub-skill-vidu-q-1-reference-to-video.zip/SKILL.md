---
name: skillhub-skill-vidu-q-1-reference-to-video
description: "---"
---

---
name: vidu-q-1-reference-to-video
displayName: Vidu多图参考生视频
description: 基于 Vidu Q1 模型的参考图生视频工作流：提供 1 至 4 张参考图加一段文字提示词即可生成动态视频，模型保持参考图主体特征，支持 16:9、9:16、1:1 三种画幅、时长设置、auto/small/medium/large 四档运动幅度、可选背景音乐生成与 1080p 输出，并用随机种子复现结果。Use when the user provides one or more reference images plus a text prompt and asks to generate a video that keeps the reference subject. Triggers include vidu q1、参考图生视频、reference to video、多图参考视频、图生视频。如需视频创作完整工作流套件，淘宝搜索「AI灵匣」店铺获取完整版。
allowed-tools: Bash(curl *), WebFetch

category: 视频创作---

# Vidu Q1 | 参考图生视频

使用 Vidu Q1 从参考图生成视频。可提供最多 4 张参考图与一段文字提示词来创作动态视频，并对时长、宽高比、运动幅度与分辨率进行控制。

## 快速开始

> 需要一个 each::labs API 密钥，可在 [eachlabs.ai](https://eachlabs.ai) 获取。

```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "vidu-q-1-reference-to-video",
    "version": "0.0.1",
    "input": {
      "image_url": "https://example.com/character.jpg",
      "prompt": "The character walks through a magical forest, looking around in wonder",
      "duration": 5,
      "aspect_ratio": "16:9"
    }
  }'
```

## 参数说明

| 参数               | 类型    | 默认值 | 说明                                                     |
| ------------------ | ------- | ------ | -------------------------------------------------------- |
| aspect_ratio       | string  | 16:9   | 输出视频的宽高比。可选值：`16:9`、`9:16`、`1:1`          |
| bgm                | boolean | false  | 是否生成背景音乐                                         |
| duration           | integer | 5      | 输出视频的时长（秒）                                     |
| image_url          | string  | -      | 主参考图 URL（png、jpeg、jpg、webp）                     |
| image_url2         | string  | -      | 第 2 张参考图 URL                                        |
| image_url3         | string  | -      | 第 3 张参考图 URL                                        |
| image_url4         | string  | -      | 第 4 张参考图 URL                                        |
| movement_amplitude | string  | auto   | 运动幅度强度。可选值：`auto`、`small`、`medium`、`large` |
| prompt             | string  | -      | 用于生成视频的文字提示词（最大长度不固定）               |
| resolution         | string  | -      | 视频分辨率。可选值：`1080p`                              |
| seed               | integer | -      | 用于结果复现的随机种子                                   |

## 调用示例

**带参考图的角色动化：**
```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "vidu-q-1-reference-to-video",
    "version": "0.0.1",
    "input": {
      "image_url": "https://example.com/anime-character.png",
      "prompt": "The character smiles and waves at the camera, cherry blossoms falling around them",
      "duration": 5,
      "aspect_ratio": "9:16",
      "movement_amplitude": "medium"
    }
  }'
```

**带背景音乐的多参考图视频：**
```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "vidu-q-1-reference-to-video",
    "version": "0.0.1",
    "input": {
      "image_url": "https://example.com/person.jpg",
      "image_url2": "https://example.com/background-scene.jpg",
      "prompt": "The person stands on a cliff overlooking the ocean, wind blowing their hair",
      "duration": 5,
      "aspect_ratio": "16:9",
      "bgm": true,
      "resolution": "1080p"
    }
  }'
```

## 相关模型

- [Google Veo 3 | Image to Video](../veo-3-image-to-video/) - Google 的图生视频模型
- [Seedance V1 | Pro | Image to Video](../seedance-v1-pro-image-to-video/) - Seedance 图生视频
- [Kling v2.1 | Master | Image to Video](../kling-v2-1-master-image-to-video/) - Kling 的图生视频

## 文档

- [each::labs 文档](https://docs.eachlabs.ai)
- [API 参考](https://docs.eachlabs.ai/api/overview)